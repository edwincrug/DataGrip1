
-- =============================================                      
-- Author:  Alejandra Rivero  
-- Modif:	Issachar González                     
-- Create date:			2016-09-14
-- Modification date:	2020-02-12  
-- Modification date:	2020-05-07                   
-- Descripcion: Store para el portal de fondos fijos
-- Nota : Se debe ejecutar en la base cuentasxpagar                      
-- =============================================  

CREATE PROCEDURE sp_ordenesdegastocentralizadas

@pedido AS varchar(18) 
 
--WITH ENCRYPTION

as   

DECLARE @IDEMPRESA AS INT  
DECLARE @IDSUCURSAL AS INT  
DECLARE @Error INT  
declare @iP as varchar(50) 
declare @BD as varchar(50) 

------------------------INICIO---------------------------------  
SET NOCOUNT ON;  
  
      
select @IDEMPRESA= ppg_idempresa ,@IDSUCURSAL = ppg_idsucursal
from pre_pedidogastos  WHERE ppg_idprepedidogastos = @pedido  
  
IF @@ROWCOUNT >= 1  
BEGIN  

	SELECT @IP= '[' + suc_ipbd + '].' ,@BD = suc_nombrebd + '.DBO.'  
	FROM CONTROLAPLICACIONES.dbo.cat_sucursales 
	WHERE EMP_IDEMPRESA = @IDEMPRESA AND SUC_IDSUCURSAL = @IDSUCURSAL  

 	EXECUTE  (@IP+@BD+'sp_ordenesdegastocentralizadas ' + @pedido)

	SET @Error=@@ERROR           
	IF (@Error<>0) GOTO TratarError   
  
	TratarError:  
		If @@Error<>0   
			BEGIN  
				Select '2' as Respuesta
			END
END

/*

USE [cuentasxpagar]
GO

DECLARE	@return_value int

EXEC	@return_value = [dbo].[sp_ordenesdegastocentralizadas]
		@pedido = 1

SELECT	'Return Value' = @return_value

GO


*/


go

