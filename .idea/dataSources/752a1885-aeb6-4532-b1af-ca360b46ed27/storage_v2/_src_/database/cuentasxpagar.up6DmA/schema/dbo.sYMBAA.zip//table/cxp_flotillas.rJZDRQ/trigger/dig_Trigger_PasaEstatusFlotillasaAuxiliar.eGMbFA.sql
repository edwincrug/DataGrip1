
    CREATE TRIGGER dig_Trigger_PasaEstatusFlotillasaAuxiliar

    ON cxp_flotillas FOR INSERT

    AS

	declare @flo_idempresa int;
	declare @flo_idsucursal int;
	declare @flo_numeroflotilla int;	
	declare @sfl_idsituacion int;
	declare @observaciones varchar(250);

	select @flo_idempresa 		= i.flo_idempresa 		from inserted i;	
	select @flo_idsucursal 		= i.flo_idsucursal 		from inserted i;	
	select @flo_numeroflotilla 	= i.flo_numeroflotilla 	from inserted i;	
	
	select @sfl_idsituacion=1;	
	select @observaciones='Insercion inicial desde BPro';

       INSERT INTO [CentralizacionV2].[dbo].[DIG_FLOTILLAAUX] (flo_idempresa,flo_idsucursal, flt_numeroflotilla,sfl_idsituacion,aux_fecha,aux_observaciones)
       values (@flo_idempresa,@flo_idsucursal,@flo_numeroflotilla,@sfl_idsituacion,getdate(),@observaciones)

    go

