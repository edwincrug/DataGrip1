

CREATE TRIGGER [dbo].[dig_Trigger_SituacionOrdenesConfirmadas]
	ON [dbo].[cxp_ordencompra] FOR UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	IF UPDATE(sod_idsituacionorden)
	BEGIN
		--Se evalúa si la orden pertenece a compras varias
		IF (
				SELECT COUNT(*) FROM ControlAplicaciones.dbo.CAT_DEPARTAMENTOS
				WHERE dep_nombre = 'OTROS CONCEPTOS'
				AND dep_iddepartamento IN 
				(
					SELECT oce_iddepartamento FROM inserted
				)
			) > 0
		BEGIN 
			--Si el nuevo estatus es 2 Autorizado o 3 Rechazado valida el estatus anterior
			IF (SELECT sod_idsituacionorden FROM inserted) IN (2,3)
			BEGIN
				--Si el estatus anterior era 10 Documentación completa, mantiene este dato
				IF (SELECT sod_idsituacionorden FROM deleted) = 10
				BEGIN
					RAISERROR('No se puede regresar la situación de la orden de Documentación completa a Autorizado o Rechazado', 16, 1)
					ROLLBACK TRANSACTION
				END
			END
		END
		--Se evalúa si la orden pertenece a unidades seminuevas
		IF (
				SELECT COUNT(*) FROM ControlAplicaciones.dbo.CAT_DEPARTAMENTOS
				WHERE dep_nombre = 'UNIDADES SEMINUEVAS'
				AND dep_iddepartamento IN 
				(
					SELECT oce_iddepartamento FROM inserted
				)
			) > 0
		BEGIN 
			--Si el nuevo estatus es 1 Solicitado valida el estatus anterior
			IF (SELECT sod_idsituacionorden FROM inserted) = 1
			BEGIN
				--Si el estatus anterior era 2 Autorizado, mantiene este dato
				IF (SELECT sod_idsituacionorden FROM deleted) = 2
				BEGIN
					RAISERROR('No se puede regresar la situación de la orden de Autorizado a Solicitado', 16, 1)
					ROLLBACK TRANSACTION
				END
			END
		END
	END
END

go

