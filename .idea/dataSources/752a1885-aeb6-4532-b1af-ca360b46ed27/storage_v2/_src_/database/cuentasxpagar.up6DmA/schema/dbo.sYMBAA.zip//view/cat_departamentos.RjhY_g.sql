CREATE VIEW [dbo].[cat_departamentos]
AS
SELECT    *
FROM         [ControlAplicaciones].dbo.cat_departamentos

go

