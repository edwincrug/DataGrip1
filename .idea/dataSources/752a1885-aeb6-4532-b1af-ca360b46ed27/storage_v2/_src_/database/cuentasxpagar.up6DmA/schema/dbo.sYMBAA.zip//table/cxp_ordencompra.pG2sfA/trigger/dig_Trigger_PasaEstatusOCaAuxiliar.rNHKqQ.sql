
    CREATE TRIGGER dig_Trigger_PasaEstatusOCaAuxiliar

    ON cxp_ordencompra FOR INSERT

    AS

	declare @div_iddivision int;
	declare @emp_idempresa int;
	declare @suc_idsucursal int;
	declare @dep_iddepartamento int;
	declare @tipo_idtipoorden int;
	declare @Folio_Operacion varchar(30);
	declare @oce_idsituacionorden int;
	declare @oce_numeroflotilla int;
	declare @observaciones varchar(250);

	select @div_iddivision 		= i.oce_iddivision 				 from inserted i;
	select @emp_idempresa  		= i.oce_idempresa 				 from inserted i;	
	select @suc_idsucursal 		= i.oce_idsucursal 				 from inserted i;	
	select @dep_iddepartamento	= i.oce_iddepartamento 			 from inserted i;	
    select @tipo_idtipoorden 	= i.oce_idtipoorden 			 from inserted i;
	select @Folio_Operacion 	= ltrim(rtrim(i.oce_folioorden)) from inserted i;
	select @oce_idsituacionorden= i.sod_idsituacionorden 		 from inserted i;
	select @oce_numeroflotilla 	= Isnull(i.oce_numeroflotilla,0) from inserted i;
	set @observaciones			='Insercion inicial desde BPro';
	
          	INSERT INTO [CentralizacionV2].[dbo].[DIG_ORDENCOMPRAAUX] (div_iddivision,emp_idempresa,suc_idsucursal,dep_iddepartamento,tipo_idtipoorden,Folio_Operacion,oce_idsituacionorden,aux_fecha,aux_observaciones)
         	 values (@div_iddivision,@emp_idempresa,@suc_idsucursal,@dep_iddepartamento,@tipo_idtipoorden,@Folio_Operacion,@oce_idsituacionorden,getdate(),@observaciones)

    go

