CREATE VIEW [dbo].[cat_sucursales]
AS
SELECT     *
FROM        [ControlAplicaciones].dbo.cat_sucursales
go

