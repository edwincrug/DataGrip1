
CREATE TRIGGER dig_Trigger_UN_CambioPrecio ON [dbo].[cxp_detalleautosnuevos] 
FOR UPDATE
AS
	declare @div_iddivision int;
	declare @emp_idempresa int;
	declare @suc_idsucursal int;
	declare @dep_iddepartamento int;
	declare @tipo_idtipoorden int;
	declare @Folio_Operacion varchar(30);
	
	declare @oce_idsituacionorden int;
	declare @oce_numeroflotilla int;
	declare @observaciones varchar(250);

	
	select @Folio_Operacion = ltrim(rtrim(i.oce_folioorden)) from inserted i;

 if (ltrim(rtrim(Isnull(@Folio_Operacion,'')))<>'')
   begin	
					
	if update(anu_costosiniva)
	begin
  		
			select @div_iddivision  = oc.oce_iddivision, @emp_idempresa = oc.oce_idempresa,
				   @suc_idsucursal  = oc.oce_idsucursal, @dep_iddepartamento = oc.oce_iddepartamento,
				   @tipo_idtipoorden=oc.oce_idtipoorden, @oce_idsituacionorden = oc.sod_idsituacionorden 
				   from cxp_detalleautosnuevos d, cxp_ordencompra oc
				   where d.oce_folioorden= @Folio_Operacion
				   and oc.oce_folioorden=d.oce_folioorden

				set @observaciones='Actualizacion de Precio';

				set	@oce_idsituacionorden = 777  --Actualizacion de precio de la orden de compra en unidades nuevas detalle				
						
			If Not Exists(Select Folio_Operacion from [CentralizacionV2].[dbo].[DIG_ORDENCOMPRACAMBIOPRECIOAUX] as aux where aux.Folio_Operacion = @Folio_Operacion)
		    begin				   
			   select @div_iddivision = 2; --HARD CODE POR ELIMINAR
											   
			   set @observaciones = 'Actualizacion de Precio en Bpro';
			      INSERT INTO [CentralizacionV2].[dbo].[DIG_ORDENCOMPRACAMBIOPRECIOAUX] (div_iddivision,emp_idempresa,suc_idsucursal,dep_iddepartamento,tipo_idtipoorden,Folio_Operacion,oce_idsituacionorden,aux_fecha,aux_observaciones)
			      values (@div_iddivision,@emp_idempresa,@suc_idsucursal,@dep_iddepartamento,@tipo_idtipoorden,@Folio_Operacion,@oce_idsituacionorden,getdate(),@observaciones)
		    end
			else
            begin		       
			   set @observaciones = 'ACTUALIZACION DE PRECIO EN BPRO';	
					Update [CentralizacionV2].[dbo].[DIG_ORDENCOMPRACAMBIOPRECIOAUX] set oce_idsituacionorden = @oce_idsituacionorden, aux_fecha=getdate(), aux_observaciones = @observaciones
					where Folio_Operacion  = @Folio_Operacion and oce_idsituacionorden=@oce_idsituacionorden				
		    end			   
			
				INSERT INTO [CentralizacionV2].[dbo].[DIG_BITACORA] (fecha,quien,que,aquien)
				values (getdate(),'trigger',@observaciones,@Folio_Operacion)
			
	end	
    end
go

