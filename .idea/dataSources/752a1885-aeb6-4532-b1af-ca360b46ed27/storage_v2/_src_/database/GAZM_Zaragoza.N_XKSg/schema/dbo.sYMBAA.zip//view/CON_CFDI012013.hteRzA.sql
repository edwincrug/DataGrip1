create view [CON_CFDI012013] as select * from [GAZM_Concentra].dbo.[con_cfdi012013]
go

