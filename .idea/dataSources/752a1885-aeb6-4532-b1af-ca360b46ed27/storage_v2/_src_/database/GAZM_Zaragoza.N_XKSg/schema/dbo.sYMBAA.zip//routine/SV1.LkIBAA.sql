CREATE PROCEDURE SV1 
	@Fecha varchar(10) ,
	@Usuario varchar(5) 	
AS
BEGIN
	
	delete gen_sv1 where sv_idusuario=@Usuario
	
	--cargo en las tablas las fechas
	declare @i int
	set  @i= 0
	WHILE @i < 13
		BEGIN
			--llena las tablas con las fechas
			insert into gen_sv1 SELECT substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7),0,0,0,0,@Usuario
			
			--lleno refacciones
			update gen_sv1 set SV_Refacciones =
			(select  isnull(sum(Mensual),0) from
			(select isnull(sum(mod_total - mod_descto1),0) as Mensual
			from par_movdet, pnc_parametr where 
			MOD_TIPOMOV = PAR_IDENPARA AND PAR_TIPOPARA='MP' and
			(PAR_DESCRIP2 LIKE 'VM') 
			and substring(mod_fechope,4,7) = substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7)
			Union all
			select isnull(sum(mod_total - mod_descto1) * -1,0) as Mensual
			from par_movdet, pnc_parametr where 
			MOD_TIPOMOV = PAR_IDENPARA AND PAR_TIPOPARA='MP' and
			(PAR_DESCRIP2 LIKE 'DV%')
			and substring(mod_fechope,4,7) =substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7)) as dev)
			where sv_Fecha=substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7)
			and sv_idusuario=@Usuario
			--LLENO SERVICIO
			update gen_sv1 set SV_SERVICIO =
			(select  isnull(sum(Mensual),0) from
			(select isnull(sum(mod_total - mod_descto1),0) as Mensual
			from par_movdet, pnc_parametr where 
			MOD_TIPOMOV = PAR_IDENPARA AND PAR_TIPOPARA='MP' and
			(PAR_DESCRIP2 LIKE 'VT') 
			and substring(mod_fechope,4,7) = substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7)
			Union all
			select isnull(sum(mod_total - mod_descto1) * -1,0) as Mensual
			from par_movdet, pnc_parametr where 
			MOD_TIPOMOV = PAR_IDENPARA AND PAR_TIPOPARA='MP' and
			(PAR_DESCRIP2 LIKE 'DT%')
			and substring(mod_fechope,4,7) =substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7)) as dev)
			where sv_Fecha=substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7)
			and sv_idusuario=@Usuario
			--lleno nuevos
			update gen_sv1 set SV_Nuevos =
			(select isnull(sum(VTE_TOTAL),0) from ade_vtafi where vte_tipodocto = 'A' 
			and substring(vte_fechdocto,4,7) =substring(convert(varchar(10),dateadd(m, @i * -1,convert(varchar(10),'04/05/2008',103)),103),4,7)
			and vte_status = 'I') where sv_Fecha=substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7)
			and sv_idusuario=@Usuario
			
			--lleno nuevos
			update gen_sv1 set SV_SemiNuevos =
			(select isnull(sum(VTE_TOTAL),0) from ade_vtafi where vte_tipodocto = 'U' 
			and substring(vte_fechdocto,4,7) =substring(convert(varchar(10),dateadd(m, @i * -1,convert(varchar(10),'04/05/2008',103)),103),4,7)
			and vte_status = 'I') where sv_Fecha=substring(convert(varchar(19),dateadd(m, @i * -1,convert(varchar(10),@Fecha,103)),103),4,7)
			and sv_idusuario=@Usuario

			set  @i= @i+1
		CONTINUE
	END

 
END
go

