create view [dbo].[PER_OBSERVACIONES] as select * from GAZM_Concentra.dbo.PER_OBSERVACIONES
go

