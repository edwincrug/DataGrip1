create view [dbo].[CON_CARCON012005] as select * from GAZM_Concentra.dbo.CON_CARCON012005
go

