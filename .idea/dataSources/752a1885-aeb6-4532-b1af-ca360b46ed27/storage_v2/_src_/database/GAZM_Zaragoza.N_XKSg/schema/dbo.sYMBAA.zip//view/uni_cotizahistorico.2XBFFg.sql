---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[uni_cotizahistorico] AS 
select uch_idcotizahis, ucu_idcotizacion, uch_idestatuscotizahis, uch_usuarioalta, uch_fechaalta, uch_estatus
from cuentasporcobrar.dbo.uni_cotizahistorico;
go

