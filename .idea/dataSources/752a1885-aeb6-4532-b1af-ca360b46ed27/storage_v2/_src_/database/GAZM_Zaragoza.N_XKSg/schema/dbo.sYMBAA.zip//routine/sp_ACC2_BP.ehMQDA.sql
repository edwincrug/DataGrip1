
CREATE PROCEDURE dbo.sp_ACC2_BP -- '08/01/2019','08/07/2019','GAZM_ZARAGOZA'
	 @Fechaini DATE
	,@Fechafin DATE 
	,@db_p VARCHAR(MAX)

AS

BEGIN TRY

	DECLARE @Query AS VARCHAR (MAX)

SET @Query = '
INSERT INTO [dbo].[prodServicio_BP](
	serieNumero
	,facturaAuto
	,facturaServ
	,cliente
	,descProdServ
	,costo
	,venta
	,fecha
	,codigoTipo
	,codigoProdSer
	,cantidad
	,suc_nombrebd
	)

SELECT   VTE_SERIE AS serieNumero
	,VTE_DOCTO AS facturaAuto
	,UAW_IDDOCTO AS facturaServ
	,NULL AS cliente
	,uaw_descripcion AS descProdServ
	,ROUND(uaw_importe / 1.16, 2, 0) AS costo
	,ROUND(UAW_PRECIO / 1.16, 2, 0) AS venta
	,VTE_FECHDOCTO AS fecha
	,''NP'' AS coditoTipo
	,NULL AS codigoProdSer
	,1 AS cantidad
	,'+ '''' + @db_p + '''' + '
FROM '+@db_p+'.dbo.ade_vtafi
	,'+@db_p+'.dbo.uni_anticiposweb
WHERE VTE_TIPODOCTO = ''A''
	AND VTE_STATUS = ''I''
	AND vte_serie = uaw_noserie
	AND UAW_IDDOCTO IN (
		SELECT VTE_DOCTO
		FROM '+@db_p+'.dbo.ade_vtafi
		WHERE VTE_STATUS = ''I''
		)
	AND STR_IDSUBTRAM IN (
		SELECT STR_IDSUBTRAM
		FROM '+@db_p+'.dbo.CXC_SUBTRAMITE
		WHERE STR_SUBTRAM LIKE ''%pack%''
		)
	AND CEA_IdEstatusAdicionales = ''5''
	AND UAW_IDDOCTO IS NOT NULL
	AND UAW_IDDOCTO NOT IN ('''')
	AND CONVERT(DATE,VTE_FECHDOCTO,103)BETWEEN CONVERT(DATE,'+ ''''+ CONVERT (VARCHAR(10),@Fechaini) + ''''+ ') AND CONVERT(DATE,' + ''''+ CONVERT (VARCHAR(10),@Fechafin) + '''	

)UNION ALL

SELECT  VTE_SERIE AS VIN
	,VTE_DOCTO AS FacturaVTA
	,UAW_IDDOCTO AS FacturaOTROS
	,NULL AS cliente
	,uaw_descripcion AS Descripcion
	,ROUND(uaw_importe / 1.16, 2, 0) AS costo
	,ROUND(UAW_PRECIO / 1.16, 2, 0) AS Precio
	,VTE_FECHDOCTO AS fecha
	,''OS'' AS codigoTipo
	,NULL AS codigoProdSer
	,1 AS cantidad
	,'+ '''' + @db_p + '''' + '
FROM '+@db_p+'.dbo.ade_vtafi
	,'+@db_p+'.dbo.uni_anticiposweb
WHERE VTE_TIPODOCTO = ''A''
	AND VTE_STATUS = ''I''
	AND vte_serie = uaw_noserie
	AND UAW_IDDOCTO IN (
		SELECT VTE_DOCTO
		FROM '+@db_p+'.dbo.ade_vtafi
		WHERE VTE_STATUS = ''I''
		)
	AND STR_IDSUBTRAM IN (
		SELECT STR_IDSUBTRAM
		FROM '+@db_p+'.dbo.CXC_SUBTRAMITE
		WHERE STR_SUBTRAM NOT LIKE ''%garan%''
			AND STR_SUBTRAM NOT LIKE ''%pack%''
			AND uaw_descripcion NOT LIKE ''%GESTO%''
			AND STR_SUBTRAM NOT LIKE ''%VERI%''
		)
	AND CEA_IdEstatusAdicionales = ''5''
	AND UAW_IDDOCTO IS NOT NULL
	AND UAW_IDDOCTO NOT IN ('''')
	AND CONVERT(DATE,VTE_FECHDOCTO,103)BETWEEN CONVERT(DATE,'+ ''''+ CONVERT (VARCHAR(10),@Fechaini) + ''''+ ') AND CONVERT(DATE,' + ''''+ CONVERT (VARCHAR(10),@Fechafin) + '''	
	
)UNION ALL

SELECT PET_VINTOMA AS serieNumero
	,VTE_DOCTO AS facturaAuto
	,NULL AS facturaServ
	,NULL AS cliente
	,PET_VINTOMA AS descProdServ
	,(
		SELECT VEH_IMPFACTPLAN
		FROM '+@db_p+'.dbo.SER_VEHICULO
		WHERE PET_VINTOMA = veh_numserie
		) AS costo
	,(
		SELECT VEH_SIMPPVTA
		FROM '+@db_p+'.dbo.SER_VEHICULO
		WHERE PET_VINTOMA = veh_numserie
		) AS venta
	,PET_FECHOPE AS fecha
	,''TM'' AS codigoTipo
	,NULL AS codigoProdSer
	,1 AS cantidad
	,'+ '''' + @db_p + '''' + '
FROM '+@db_p+'.dbo.UNI_PEDITOMAUNI
	,'+@db_p+'.dbo.ADE_VTAFI
WHERE PET_IDPEDI = VTE_REFERENCIA1
	AND VTE_TIPODOCTO = ''A''
	AND VTE_STATUS = ''I''
AND CONVERT(DATE,VTE_FECHDOCTO,103)BETWEEN CONVERT(DATE,'+ ''''+ CONVERT (VARCHAR(10),@Fechaini) + ''''+ ') AND CONVERT(DATE,' + ''''+ CONVERT (VARCHAR(10),@Fechafin) + '''' + ')'
		EXEC (@query)
	END TRY 
BEGIN CATCH  
	INSERT INTO ERROR_CATCH
    SELECT   
        'NO SE PROCESO ACC2/ ' + @db_p + ' ' + CONVERT (VARCHAR (12),@Fechaini) + ',' + CONVERT (VARCHAR(12),@Fechafin) + ERROR_MESSAGE()
  
	IF @@TRANCOUNT > 0  
        ROLLBACK TRANSACTION;  
END CATCH;  
IF @@TRANCOUNT > 0  
    COMMIT TRANSACTION;

go

