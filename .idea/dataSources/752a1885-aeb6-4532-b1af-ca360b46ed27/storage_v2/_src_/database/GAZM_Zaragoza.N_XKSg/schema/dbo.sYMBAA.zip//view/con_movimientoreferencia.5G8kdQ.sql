CREATE VIEW [dbo].[con_movimientoreferencia]
AS
SELECT   *
FROM         GAZM_Concentra.dbo.con_movimientoreferencia
go

