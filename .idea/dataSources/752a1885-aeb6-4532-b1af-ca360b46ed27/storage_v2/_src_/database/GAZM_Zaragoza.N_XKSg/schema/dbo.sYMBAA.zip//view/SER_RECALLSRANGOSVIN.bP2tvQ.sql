create view [dbo].[SER_RECALLSRANGOSVIN] as select * from GAZM_Concentra.dbo.SER_RECALLSRANGOSVIN
go

