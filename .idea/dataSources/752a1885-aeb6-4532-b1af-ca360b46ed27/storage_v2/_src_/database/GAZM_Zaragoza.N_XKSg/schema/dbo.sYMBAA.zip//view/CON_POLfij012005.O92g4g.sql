create view [dbo].[CON_POLfij012005] as select * from GAZM_Concentra.dbo.CON_POLfij012005
go

