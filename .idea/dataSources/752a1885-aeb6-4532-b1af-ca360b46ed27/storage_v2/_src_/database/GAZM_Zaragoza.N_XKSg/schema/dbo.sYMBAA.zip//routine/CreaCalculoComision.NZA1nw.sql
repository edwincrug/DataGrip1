CREATE PROCEDURE [dbo].[CreaCalculoComision] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    EXEC [dbo].[ActualizaTablaComisionistas]

	Declare @Query as nvarchar(MAX)
	DECLARE @Formula as nvarchar(MAX)

	set @Query = 'select V.*, <<Formula>> [BaseComision], DT.[% Normal] [%Comision], ((<<Formula>>) * DT.[% Normal]) [ComisionCalculada] from ComisionesS2.dbo.Ventas V ' +
	'INNER JOIN ComisionesS2.dbo.Comision C '+
	'ON C.VENDEDOR = V.VENDEDOR '+
	'INNER JOIN ComisionesS2.dbo.Tabulador T '+
	'ON CAST(concat(substring(V.Fecha,7,4),substring(V.Fecha,4,2),substring(V.Fecha,1,2)) AS datetime) between T.Desde AND ISNULL(T.Hasta, CAST(concat(substring(V.Fecha,7,4),substring(V.Fecha,4,2),substring(V.Fecha,1,2)) AS datetime)) '+
	'And T.Autorizado = 1 '+
	'INNER JOIN ComisionesS2.dbo.DetalleTabulador DT '+
	'ON DT.idTabulador = T.idTabulador '+
	'AND C.Ventas between DT.Minimo AND DT.Maximo'

	select @Formula = Expresion
	from Formula

	
	SET @Query = REPLACE(@Query, '<<Formula>>', @Formula)
	--select @Query
	EXEC (@Query)

	--Crear CSV
	declare 
            @sqlcmd varchar(4000),
            @dos_cmd nvarchar(4000),
			@csvfile nvarchar(200),
			@queryHeaders nvarchar(MAX),
			@Path nvarchar(4000)

	SET @Path = 'C:\Temp\'
	SET @csvfile = 'Andrade.csv'

	DECLARE @columnHeader VARCHAR(8000)
	SELECT @columnHeader=COALESCE(@columnHeader+',' ,'')+ ''''+column_name +'''' FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='Ventas' AND TABLE_CATALOG = 'ComisionesS2'

	--select @columnHeader

	SET @queryHeaders = @columnHeader + ',''BaseComision'',''Comision'',''CalculoComision'''
	--SET @queryHeaders = '''Modelo'',''VIN'',''VIN2'',''Serie'',''INV'',''Factura'',''Fecha'',''Cliente'',''Precio Base'',''ISAN'',''IVA'',''Total'',''Costo'',''Incentivo'',''Costo1'',''Utilidad'',''% UB'',''Canal'',''Color Ext'',''Color'',''FAMILIA'',''VENDEDOR'',''MODELO1'',''NO'',''Fecha de reporte'',''NOTA DE CREDITO'',''SUBSIDIO '',''CC'',''UB'',''% COM'',''0.01'',''%'',''AUTO'',''CREDI'',''ACCESORIO'',''SATFINDER'',''UDIS'',''TOMA'',''SICREA'',''GE'',''OTROS'',''SUBTOTAL'',''ANTICIPO'',''TOTAL1'',''CREDI1'',''FACTURA1'',''SATFINDER1'',''FACTURA2'',''G EXT'',''UDIS1'',''TOMA1'',''FACTURA3'',''ACCESORIOS'',''VENDEDOR'',''VENTAS'',''COMISION'',''BaseComision'',''Comision'',''CalculoComision'''

	SELECT @dos_cmd='BCP " SELECT ' + @queryHeaders + '" ' + 
							'QUERYOUT "' + @Path + 'Header' + @csvfile + 
							'" -c -t, -T -S "(local)\SQLEXPRESS"'

	--SELECT @dos_cmd
	exec master.dbo.xp_cmdshell @dos_cmd, No_output

	SELECT @dos_cmd='BCP " ' + @Query + '" ' + 
							'QUERYOUT "' + @Path + 'Body' + @csvfile + 
							'" -c -t, -T -S "(local)\SQLEXPRESS"'

	SELECT @dos_cmd
	exec master.dbo.xp_cmdshell @dos_cmd, No_output


	SELECT @dos_cmd='copy /b ' + @Path + 'Header'+ @csvfile + ' + ' + @Path  + 'Body' + @csvfile + ' ' + @Path + @csvfile
	--select @dos_cmd
	exec master.dbo.xp_cmdshell @dos_cmd, No_output
END



go

