CREATE VIEW [dbo].[cat_usuarios]
AS
SELECT 
usu_idusuario, gpo_idgrupo, div_iddivision, emp_idempresa, suc_idsucursal, dep_iddepartamento, usu_nombreusu, usu_paterno, usu_materno, usu_nombre, usu_correo, usu_contrasenia, pto_idpuesto, usu_fechaalta, usu_usualta, usu_fechamodifica, usu_usumodifica, usu_estatus, usu_passbpro
FROM      [ControlAplicaciones].dbo.cat_usuarios
go

