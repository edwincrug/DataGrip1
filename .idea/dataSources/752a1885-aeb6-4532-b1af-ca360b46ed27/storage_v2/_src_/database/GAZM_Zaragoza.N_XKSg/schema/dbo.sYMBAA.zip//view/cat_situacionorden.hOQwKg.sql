CREATE VIEW [dbo].[cat_situacionorden] AS   SELECT  sod_idsituacionorden, sod_nombresituacion, sod_nombrecto, sod_statussituacion, sod_fechaalta, sod_idusuarioalta, sod_fechamodifica, sod_idusuariomodifica  FROM        CUENTASXPAGAR.dbo.cat_situacionorden
go

