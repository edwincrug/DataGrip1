
Create View [dbo].[cxp_ordenesmasivasdet] as 
select omd_idordenmasivadet, omd_areaafectacion, omd_conceptocontable, 
omd_cantidad, omd_producto, omd_preciounitario, omd_tasaiva, 
omd_descuento, odm_idordenmasiva 
from [GAZM_Concentra].dbo.cxp_ordenesmasivasdet
go

