CREATE VIEW [dbo].[unp_unificacionenc]
AS 
SELECT upe_idunificacion, upe_idempresa, upe_fecha, upe_estatus, upe_idusuario, upe_fechaunificacion
FROM GA_Corporativa.dbo.unp_unificacionenc
go

