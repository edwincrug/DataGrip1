CREATE VIEW [dbo].[cxc_reclant]
AS
SELECT 
ran_folio, ran_idempresa, ran_idsucursal, ran_iddepartamento, ran_concepto, ran_refconcepto, ran_idpersona, ran_cobrador, ran_moneda, ran_tipocambio, ran_referencia, ran_iddocto, ran_cotped, ran_consecutivo, ran_importe, ran_formapago, ran_numctabanc, ran_fecha, ran_banco, ran_referenciabancaria, ran_anno
FROM         [GA_Corporativa].dbo.cxc_reclant
go

