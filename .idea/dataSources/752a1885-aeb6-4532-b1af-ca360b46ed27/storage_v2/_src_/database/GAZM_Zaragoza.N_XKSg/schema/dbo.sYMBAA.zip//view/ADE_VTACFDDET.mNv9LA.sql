---(2)
create view [dbo].[ADE_VTACFDDET] as select * from GAZM_Concentra.dbo.ADE_VTACFDDET
go

