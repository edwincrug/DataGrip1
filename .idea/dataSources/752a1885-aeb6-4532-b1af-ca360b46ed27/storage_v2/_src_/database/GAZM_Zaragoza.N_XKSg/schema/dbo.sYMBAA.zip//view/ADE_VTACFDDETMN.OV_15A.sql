---(2)
create view [dbo].[ADE_VTACFDDETMN] as select * from GAZM_Concentra.dbo.ADE_VTACFDDETMN
go

