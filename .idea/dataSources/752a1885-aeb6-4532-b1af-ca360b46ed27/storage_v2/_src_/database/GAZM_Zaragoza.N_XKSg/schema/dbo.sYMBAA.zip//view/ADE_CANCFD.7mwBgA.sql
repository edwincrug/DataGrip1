---(3)
create view [dbo].[ADE_CANCFD] as select * from GAZM_Concentra.dbo.ADE_CANCFD
go

