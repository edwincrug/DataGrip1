create view [dbo].[ser_recallscampañas] as select * from GAZM_Concentra.dbo.ser_recallscampañas
go

