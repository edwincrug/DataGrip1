
CREATE VIEW [dbo].[pre_pedidoref]
AS
SELECT pre_idpedidoref, pre_idcliente, pre_tipomov, pre_idvendedor, pre_idvendedoralterno, pre_almacen, 
pre_rutaentrega, pre_idusuario, pre_fechaalta, pre_idempresa, pre_idsucursal, pre_idcotizacion, pre_pedidobpro,
pre_fechamod, pre_pedidopadre, pre_observaciones, pre_tipoprecio, spe_idsituacionpedido, pre_consec, pre_token,
pre_consruta, pre_tipobase, pre_nombrebd, pre_ipbd, pre_numsiniestro, pre_ordenglobal, pre_tareferencia, 
pre_pedidoinpart, pre_cotinpart, pre_porcentajeNCR
FROM PortalRefacciones.dbo.pre_pedidoref


go

