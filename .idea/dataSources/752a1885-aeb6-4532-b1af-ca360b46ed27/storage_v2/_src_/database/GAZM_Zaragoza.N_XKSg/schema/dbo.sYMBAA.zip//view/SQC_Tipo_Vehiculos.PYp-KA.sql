create view [dbo].[SQC_Tipo_Vehiculos] as select * from [GAZM_Concentra].[dbo].[SQC_Tipo_Vehiculos]
go

