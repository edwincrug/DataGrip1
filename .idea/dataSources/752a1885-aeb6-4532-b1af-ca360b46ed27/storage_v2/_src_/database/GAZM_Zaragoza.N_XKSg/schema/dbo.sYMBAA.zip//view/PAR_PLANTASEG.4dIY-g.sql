create view [dbo].[PAR_PLANTASEG] as select * from GAZM_Concentra.dbo.PAR_PLANTASEG
go

