
create view [dbo].[CON_MOVCHEQUE012010] as select * from GAZM_Concentra.dbo.CON_MOVCHEQUE012010

go

