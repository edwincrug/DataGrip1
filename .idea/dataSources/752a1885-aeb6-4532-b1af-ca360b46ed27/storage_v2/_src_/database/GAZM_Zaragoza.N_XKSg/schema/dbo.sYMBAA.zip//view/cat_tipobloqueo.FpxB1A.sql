CREATE VIEW [dbo].[cat_tipobloqueo]
AS
SELECT 
tbq_idtipobloqueo, tbq_nombre, tbq_nombrecto, tbq_fechaalta, tbq_usualta, tbq_fechamodifica, tbq_usumodifica, tbq_estatus
FROM         [GA_Corporativa].dbo.cat_tipobloqueo
go

