
CREATE PROCEDURE sp_ACC1_BP  --'01/08/2019','30/08/2019','GAZM_Zaragoza'

     @Fechaini DATE
	,@Fechafin DATE 
	,@db_p VARCHAR(MAX)

AS
BEGIN TRY

	DECLARE @Query AS VARCHAR (MAX)

	SET @Query = '
	INSERT INTO [dbo].[prodServicio_BP](
	serieNumero
	,facturaAuto
	,facturaServ
	,cliente
	,descProdServ
	,costo
	,venta
	,fecha
	,codigoTipo
	,codigoProdSer
	,cantidad
	,suc_nombrebd
	)
	SELECT
	cuu.ucn_noserie AS  serieNumero
	,VT.VTE_DOCTO AS facturaAuto
	,NULL AS facturaServ
	,p.PER_NOMRAZON + '' '' + p.PER_PATERNO + '' '' +p.PER_MATERNO AS cliente
	,VH.VEH_TIPOAUTO AS descProdServ
	,SUM(CCS.ucc_monto) AS costo
	,NULL AS venta
	,MAX(CCS.ucc_fechaalta) AS fecha
	,''CC''AS codigoTipo
	,NULL AS codigoProdSer
	,1 AS cantidad
	,'+ '''' + @db_p + '''' + '
	FROM	cuentasporcobrar.dbo.uni_ccs AS CCS
	INNER JOIN	cuentasporcobrar.dbo.uni_cotizacionuniversal  AS C ON C.ucu_idcotizacion = CCS.ucu_idcotizacion
	INNER JOIN	[cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] cuu on  C.ucu_idcotizacion = cuu.ucu_idcotizacion
	INNER JOIN	'+@db_p+'.dbo.ADE_VTAFI AS VT ON VT.VTE_SERIE = CUU.ucn_noserie
	INNER JOIN	'+@db_p+'.dbo.SER_VEHICULO AS VH ON VH.VEH_NUMSERIE = cuu.ucn_noserie
	INNER JOIN	[GA_CORPORATIVA].dbo.PER_PERSONAS AS P ON P.PER_IDPERSONA = c.ucu_idcliente
	WHERE ucc_estatus = 2 	
	AND  C.ucu_idempresa = 4 
	AND C.ucu_idsucursal = 6	
	AND VTE_TIPODOCTO = ''A'' AND VTE_STATUS = ''I''
	AND CONVERT(DATE,CCS.ucc_fechaalta,103)BETWEEN CONVERT(DATE,'+ ''''+ CONVERT (VARCHAR(10),@Fechaini) + ''''+ ') AND CONVERT(DATE,' + ''''+ CONVERT (VARCHAR(10),@Fechafin) + '''	'+')
	GROUP BY 
	VT.VTE_DOCTO
	,cuu.ucn_noserie
	,c.ucu_idcliente
	,p.PER_NOMRAZON
	,p.PER_PATERNO
	,p.PER_MATERNO
	,VT.VTE_TOTAL
	,VH.VEH_TIPOAUTO
	UNION ALL 
	SELECT
	 VTE_SERIE AS serieNumero
	 ,VTE_DOCTO AS facturaAuto
	 ,UAW_IDDOCTO AS facturaServ
	 ,NULL AS cliente
	 ,uaw_descripcion AS descProdServ
	 ,ROUND(uaw_importe/1.16,2,0) AS costo
	 ,ROUND(UAW_PRECIO/1.16,2,0) AS venta
	 ,VTE_FECHDOCTO AS fecha
	 ,''TG'' AS codigoTipo 
	 ,NULL AS codigoProdSer
	,1 AS cantidad
	,'+ '''' + @db_p + '''' + '
	FROM '+@db_p+'.dbo.ade_vtafi  
		,'+@db_p+'.dbo.uni_anticiposweb 
	WHERE VTE_TIPODOCTO = ''A''  
	AND VTE_STATUS = ''I''
	AND vte_serie = uaw_noserie
	AND STR_IDSUBTRAM IN (SELECT STR_IDSUBTRAM FROM '+@db_p+'.dbo.CXC_SUBTRAMITE WHERE STR_SUBTRAM NOT LIKE ''%garan%'' AND STR_SUBTRAM NOT LIKE ''%pack%'' AND STR_SUBTRAM NOT LIKE ''%kit%'') AND CEA_IdEstatusAdicionales = ''5'' AND UAW_IDDOCTO 
	IS NOT NULL AND UAW_IDDOCTO NOT IN ('''')
	AND convert(DATE, VTE_FECHDOCTO, 103) between convert(date,' +''''+ CONVERT (VARCHAR(10),@fechaIni) +''''+') and convert(date,'+''''+ CONVERT(VARCHAR(10),@fechaFin) +''''+ ')
UNION ALL 
	SELECT
		ORE_NUMSERIE AS serieNumero
		,ucn_idfactura	AS facturaAuto
		,VTE_DOCTO	AS facturaServ
		,NULL	AS cliente
		,VTE_REFERENCIA1	AS descProdServ
		,SUM(ORD_COSTO)	AS costo
		,(vte_total-VTE_IVA)	AS venta
		,VTE_FECHDOCTO	AS fecha
		,''STF'' AS codigoTipo
		, NULL AS codigoProdServ
		,1 AS cantidad
		,'+ '''' + @db_p + '''' + '
		FROM '+@db_p+'.dbo.ADE_VTAFI
		,GAZM_Zaragoza.dbo.SER_ORDEN
		,GAZM_Zaragoza.dbo.SER_ORDENDET
		,GAZM_Zaragoza.dbo.UNI_COTIZACIONUNIVERSALUNIDADES
		WHERE VTE_TIPODOCTO LIKE ''S%''
		AND VTE_REFERENCIA1 = ORE_IDORDEN AND VTE_STATUS = ''I''
		AND ORE_IDORDEN = ORD_IDORDEN AND ORE_STATUS = ''I''
		AND ORD_IDPAQUET IN (SELECT PQE_NOMPAQUETE FROM '+@db_p+'.dbo.SER_PAQUESER WHERE PQE_NOMPAQUETE LIKE ''%connect%'' ) AND ORE_IDCOTIZACIONUNIVERSAL IS NOT NULL AND ORD_STATUS = ''T''
		AND ORE_IDCOTIZACIONUNIVERSAL = ucu_idcotizacion AND ucn_situacionfact = ''18''
		AND convert(DATE, VTE_FECHDOCTO, 103) between convert(date,'+ ''''+ CONVERT (VARCHAR(10),@Fechaini) + ''''+ ') AND CONVERT(DATE,' + ''''+ CONVERT (VARCHAR(10),@Fechafin) + ''''+')
		GROUP BY 
		VTE_DOCTO
		,VTE_REFERENCIA1
		,ORE_PRESUPUESTO
		,ucn_idfactura
		,ORE_NUMSERIE
		,VTE_TOTAL
		,VTE_IVA
		,VTE_FECHDOCTO
UNION ALL
	SELECT
			B.VTE_SERIE	AS serieNumero
			,B.VTE_DOCTO AS facturaAuto
			,A.VTE_DOCTO AS FacturaServ
			,NULL	AS cliente
			,PMD_DESPARTE AS descProdServ
			,SUM(Mod_CunProm*PMD_CANTIDAD) AS costo
			,SUM(Mod_PCosVta*PMD_CANTIDAD) AS venta
			,A.VTE_FECHDOCTO AS fecha
			,''ACAN''	AS codigoTipo
			,PMD_CODIGO	AS codigoProdSer 
			,PMD_CANTIDAD AS Cantidad
			,'+ '''' + @db_p + '''' + '
		FROM '+@db_p+'.dbo.PAR_PEDMOST
			,'+@db_p+'.dbo.PAR_PEDMODE
			,'+@db_p+'.dbo.ADE_VTAFI A
			,'+@db_p+'.dbo.PAR_MOVDET
			,'+@db_p+'.dbo.ADE_VTAFI B
			,'+@db_p+'.dbo.UNI_COTIZACIONUNIVERSALUNIDADES
		WHERE PMD_NUMERO = PMM_NUMERO 
			AND PMD_IDALMA = PMM_IDALMA 
			AND PMD_CODIGO NOT IN (SELECT PTS_IDPARTE FROM '+@db_p+'.dbo.PAR_PARTES WHERE PTS_DESPARTE LIKE ''%satf%'')
			AND A.VTE_STATUS = ''I'' AND A.VTE_TIPODOCTO LIKE ''%R%'' AND PMM_REF2 = A.VTE_DOCTO
			AND Mod_TipoMov = A.VTE_REFERENCIA1 AND MOD_NUMERO = A.VTE_REFERENCIA2
			AND Mod_Idalmacen = PMD_IDALMA AND Mod_Idparte = PMD_CODIGO
			AND PMM_NUMSERIE = B.VTE_SERIE 
			AND B.VTE_TIPODOCTO = ''A'' AND B.VTE_STATUS = ''I''
			AND PMM_IDCOTIZACIONUNIVERSAL = ucu_idcotizacion AND ucn_situacionfact = ''18''
			AND convert(DATE, A.VTE_FECHDOCTO, 103) between convert(date,'+ ''''+ CONVERT (VARCHAR(10),@Fechaini) + ''''+ ') AND CONVERT(DATE,' + ''''+ CONVERT (VARCHAR(10),@Fechafin) + ''''+')
		GROUP BY 
				A.VTE_DOCTO
			,A.VTE_FECHDOCTO
			,PMD_CODIGO
			,PMD_DESPARTE
			,PMD_CANTIDAD
			,B.VTE_DOCTO
			,B.VTE_REFERENCIA1
			,B.VTE_SERIE
			,B.VTE_FECHDOCTO
			,PMM_OBSERVACIONES
		UNION ALL
		SELECT 
			VTN.VTE_SERIE	AS serieNumeor
			,VTN.VTE_DOCTO AS facturaAuto
			,VTS.VTE_DOCTO AS FacturaServ
			,NULL	AS cliente
			,B.ORD_DESCRIP AS Descripcion
			,SUM(B.ORD_COSTO*B.ORD_CANTSURT) AS Costo
			,SUM(B.ORD_PRECUNITARIO*B.ORD_CANTSURT) AS Venta
			,VTS.VTE_FECHDOCTO AS FechaFacAcc
			,''ACAN''
			,B.ORD_IDPAQUET AS codigoProdSer 
			,B.ORD_CANTSURT AS Cantidad
			,'+ '''' + @db_p + '''' + '
		FROM '+@db_p+'.dbo.SER_ORDEN A 
			INNER JOIN '+@db_p+'.dbo.SER_ORDENDET B ON A.ORE_IDORDEN = B.ORD_IDORDEN 
			INNER JOIN '+@db_p+'.dbo.ADE_VTAFI VTS ON A.ORE_IDORDEN = VTS.VTE_REFERENCIA1
			INNER JOIN '+@db_p+'.dbo.ADE_VTAFI VTN ON A.ORE_NUMSERIE = VTN.VTE_SERIE
			INNER JOIN '+@db_p+'.dbo.UNI_COTIZACIONUNIVERSALUNIDADES W ON A.ORE_IDCOTIZACIONUNIVERSAL = W.ucu_idcotizacion AND A.ORE_STATUS = ''I'' AND B.ORD_CLASIFIC = ''RE''
				AND B.ORD_STATUS = ''T'' AND VTS.VTE_TIPODOCTO LIKE ''S%'' AND VTS.VTE_STATUS = ''I''AND VTN.VTE_TIPODOCTO = ''A'' AND VTN.VTE_STATUS = ''I''
				AND A.ORE_NUMSERIE = VTN.VTE_SERIE AND B.ORD_IDPAQUET NOT IN (SELECT PQE_NOMPAQUETE FROM '+@db_p+'.dbo.SER_PAQUESER WHERE PQE_NOMPAQUETE LIKE ''%connect%'' )
				AND W.ucn_noserie = VTN.VTE_SERIE AND W.ucn_situacionfact = ''18''
				AND convert(DATE, VTS.VTE_FECHDOCTO, 103) between convert(date,'+ ''''+ CONVERT (VARCHAR(10),@Fechaini) + ''''+ ') AND CONVERT(DATE,' + ''''+ CONVERT (VARCHAR(10),@Fechafin) + ''''+')
		GROUP BY 
			VTS.VTE_DOCTO
			,VTS.VTE_FECHDOCTO
			,B.ORD_CODIGO
			,B.ORD_DESCRIP
			,B.ORD_CANTSURT
			,VTN.VTE_DOCTO
			,VTN.VTE_REFERENCIA1
			,VTN.VTE_SERIE
			,VTN.VTE_FECHDOCTO
			,B.ORD_IDPAQUET
		UNION ALL
	SELECT 
			VTE_SERIE AS serieNumero
			,VTE_DOCTO AS facturaAuto
			,UAW_IDDOCTO AS facturaServ
			,NULL AS Cliente
			,uaw_descripcion AS descProdServ
			,ROUND(uaw_importe/1.16,2,0) AS costo
			,ROUND(UAW_PRECIO/1.16,2,0) AS venta
			,VTE_FECHDOCTO	AS fecha
			,''GE''	AS codigoTipo
			,NULL	AS codigoProdSer
			,1 AS cantidad
			,'+ '''' + @db_p + '''' + '
		FROM '+@db_p+'.dbo.ade_vtafi
			,'+@db_p+'.dbo.uni_anticiposweb 
		WHERE VTE_TIPODOCTO = ''A''
			AND VTE_STATUS = ''I''
			AND vte_serie = uaw_noserie 
			AND UAW_IDDOCTO IN (SELECT VTE_DOCTO FROM '+@db_p+'.dbo.ade_vtafi WHERE VTE_STATUS = ''I'')
			AND STR_IDSUBTRAM IN (SELECT STR_IDSUBTRAM FROM '+@db_p+'.dbo.CXC_SUBTRAMITE WHERE STR_SUBTRAM LIKE ''%garan%'') 
			AND	UAW_IDDOCTO IS NOT NULL 
			AND UAW_IDDOCTO NOT IN ('''')
			AND convert(DATE, VTE_FECHDOCTO, 103) between convert(DATE,'+ ''''+ CONVERT (VARCHAR(10),@Fechaini) + ''''+ ') AND CONVERT(DATE,' + ''''+ CONVERT (VARCHAR(10),@Fechafin) + ''''+')'		
			
	EXEC (@query)

	END TRY 
BEGIN CATCH  
	INSERT INTO ERROR_CATCH
    SELECT   
        'NO SE PROCESO ACCESORIOS ACC1/ ' + @db_p + ' ' + CONVERT (VARCHAR (12),@Fechaini) + ',' + CONVERT (VARCHAR(12),@Fechafin) + ERROR_MESSAGE()
  
	IF @@TRANCOUNT > 0  
        ROLLBACK TRANSACTION;  
END CATCH;  
IF @@TRANCOUNT > 0  
    COMMIT TRANSACTION;



go

