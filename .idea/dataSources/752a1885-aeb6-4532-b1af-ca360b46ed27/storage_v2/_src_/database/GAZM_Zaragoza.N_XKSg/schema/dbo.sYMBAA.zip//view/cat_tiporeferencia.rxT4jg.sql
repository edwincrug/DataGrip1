CREATE VIEW [dbo].[cat_tiporeferencia]
AS
SELECT    *
FROM        GAZM_Concentra.dbo.cat_tiporeferencia
go

