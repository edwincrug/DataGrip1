create view [CON_GCFDI012011] as select * from [GAZM_Concentra].dbo.[CON_GCFDI012011]
go

