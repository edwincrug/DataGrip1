create view [dbo].[SER_PAQUETES] as select * from GAZM_Concentra.dbo.SER_PAQUETES
go

