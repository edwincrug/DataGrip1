
CREATE PROC [dbo].[SP_INVENTA_UNIDADES] @PAR1 VARCHAR(5),@PAR2 VARCHAR(5),@PAR3 VARCHAR(5),@PAR4 VARCHAR(5),@PAR5 VARCHAR(5),
@PAR6 VARCHAR(5),@PAR7 VARCHAR(5),@PAR8 VARCHAR(5),@PAR9 VARCHAR(5),@PAR10 VARCHAR(5),@PAR11 VARCHAR(5),@PAR12 VARCHAR(5)
AS

--BORRA REGISTROS ACTUALES
DELETE FROM BI_INVENTARIO_UNIDADES 

--INSERTA SEMINUEVOS
SELECT DISTINCT(veh_numserie),TipoUnidad = 'SEMINUEVOS',veh_noinventa as Inventario,VEH_COLOINTE,VEH_COLOEXTE,
VEH_ANMODELO,VEH_TIPOAUTO as DescModelo,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'MCAV' AND PAR_IDENPARA = VEH_SMARCA) AS Marca,Segmento='',
(SELECT PAR_DESCRIP1 FROM pnc_parametr WHERE PAR_TIPOPARA = 'CVE' AND PAR_IDENPARA = VEH_STIPO) AS Tipo,
Catalogo='',CarLine='',veh_puertas,veh_cilindros,UNC_POTENCIA='',veh_combustible,veh_capacidad,VEH_QCTRANSMISION,
(select par_descrip1 from pnc_parametr where PAR_TIPOPARA = 'UBI' and PAR_IDENPARA = VEH_UBICACION) as Ubicacion,
Tipomotor = VEH_QCTIPOMOTOR,NoMotor=VEH_NOMOTOR,veh_orgunidad as Procedencia,VEH_NOFACTPLAN = SUBSTRING(VEH_NOFACTPLAN,1,20),VEH_FECREMISION,
veh_nopedimtoext as NumPedimento,veh_fecpedimtoext as FechaPedimento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'TIPOCOMPRA' AND PAR_IDENPARA = veh_tipocompra) AS TipoCompra,
VEH_FECRETIRO as fecha_asignacion,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
DiasInventa=DATEDIFF(DAY,CONVERT(DATETIME,SUBSTRING(VEH_SFECADQUI,7,4) + SUBSTRING(VEH_SFECADQUI,4,2) + SUBSTRING(VEH_SFECADQUI,1,2)),GETDATE()),
PrecioLista=VEH_SIMPPVTA,inventario_final=0,COSTO_SIN_IVA = VEH_SSUBTOTAL,
valor_inventario=VEH_SSUBTOTAL+VEH_SCTOACOND,VEH_SCTOACOND,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'SN' AND PAR_IDMODULO = 'UNI' AND PAR_IDENPARA = VEH_SITUACION) AS Situacion,Unidades=1
INTO #INV_SEMINUEVOS
FROM 
ser_vehiculo V , pnc_parametr P ,pnc_parametr PP WHERE V.VEH_SMARCA = P.PAR_IDENPARA AND P.PAR_IDMODULO = 'UNI' 
AND P.PAR_TIPOPARA = 'MCAV' AND V.VEH_SITUACION IN ('SFIS','SPED','SSEP')
AND PP.PAR_TIPOPARA =  'UBI' AND V.VEH_UBICACION = PP.PAR_IDENPARA

SELECT *,RANGO = CASE 
WHEN DiasInventa <= 30 THEN 'De 1 a 30'
WHEN DiasInventa BETWEEN 31 AND 60 THEN 'De 31 a 60' 
WHEN DiasInventa BETWEEN 61 AND 90 THEN 'De 61 a 90'
WHEN DiasInventa BETWEEN 91 AND 120 THEN 'De 91 a 120'
WHEN DiasInventa BETWEEN 121 AND 180 THEN 'De 121 a 180'
WHEN DiasInventa BETWEEN 181 AND 240 THEN 'De 181 a 240'
WHEN DiasInventa BETWEEN 241 AND 360 THEN 'De 241 a 360'
WHEN DiasInventa > 360 THEN 'Mas de 360' END,
ORDEN = CASE 
WHEN DiasInventa <= 30 THEN 1
WHEN DiasInventa BETWEEN 31 AND 60 THEN 2
WHEN DiasInventa BETWEEN 61 AND 90 THEN 3
WHEN DiasInventa BETWEEN 91 AND 120 THEN 4
WHEN DiasInventa BETWEEN 121 AND 180 THEN 5
WHEN DiasInventa BETWEEN 181 AND 240 THEN 6
WHEN DiasInventa BETWEEN 241 AND 360 THEN 7
WHEN DiasInventa > 360 THEN 8 END
INTO #INV_SEMINUEVOS1 FROM #INV_SEMINUEVOS

INSERT INTO BI_INVENTARIO_UNIDADES
SELECT * FROM #INV_SEMINUEVOS1


------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
--INSERTA NUEVOS
Select DISTINCT(veh_numserie),TipoUnidad = 'NUEVOS',veh_noinventa as Inventario,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_colointe = col_clave and col_tipo = 'interior') as ColorInterior,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_coloexte = col_clave and col_tipo = 'exterior') as ColorExterior,
veh_anmodelo as Modelo,veh_tipoauto as DescModelo,
(select par_descrip1 from pnc_parametr where par_tipopara = 'MCAV' and par_idenpara = unc_marca) as Marca,
(select par_descrip1 from pnc_parametr where par_tipopara = 'LNA' and par_idenpara = unc_linea) as Segmento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA='CVE' AND PAR_IDENPARA = uni_catalogo.UNC_CLASE) as subtipo_unidad,
UNC_IDCATALOGO,
CarLine = (select PAR_DESCRIP1 from PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'CLI' AND PAR_IDENPARA = uni_catalogo.UNC_FAMILIA),
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'PTA' AND PAR_IDENPARA = unc_ptas) as Puertas,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'CIL' AND PAR_IDENPARA = unc_cilindros) as cilindros,UNC_POTENCIA,
(select par_descrip1 from pnc_parametr where par_tipopara = 'CMB'and par_idenpara = unc_combustible) as Combustible,
unc_capacidad as Capacidad,
(select par_descrip1 from pnc_parametr where par_tipopara = 'TRS' and par_idenpara = unc_transmision) as Transmision,
(select par_descrip1 from pnc_parametr where PAR_TIPOPARA = 'UBI' and PAR_IDENPARA = VEH_UBICACION) as Ubicacion,
unc_tipomotor as Tipomotor,NoMotor=VEH_NOMOTOR,veh_orgunidad as Procedencia,VEH_NOFACTPLAN = SUBSTRING(VEH_NOFACTPLAN,1,20),VEH_FECREMISION,
veh_nopedimtoext as NumPedimento,veh_fecpedimtoext as FechaPedimento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'TIPOCOMPRA' AND PAR_IDENPARA = veh_tipocompra) AS TipoCompra,
VEH_FECRETIRO as VEH_FECRECIBO,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
DiasInventa=DATEDIFF(DAY,CONVERT(DATETIME,SUBSTRING(VEH_FECRETIRO,7,4) + SUBSTRING(VEH_FECRETIRO,4,2) + SUBSTRING(VEH_FECRETIRO,1,2)),GETDATE()),
PrecioLista=UNC_PRECLISTA,inventario_final=0,
COSTO_SIN_IVA = (SELECT SUM(VHD_COSTO) FROM UNI_VEHDETA WHERE VHD_TIPO IN(@PAR1,@PAR2,@PAR3,@PAR4,@PAR5,@PAR6,@PAR7,@PAR8,@PAR9,@PAR10,@PAR12,@PAR12) AND VHD_NOSERIE = veh_numserie),
valor_inventario= (SELECT SUM(VHD_COSTO) FROM UNI_VEHDETA WHERE VHD_TIPO IN(@PAR1,@PAR2,@PAR3,@PAR4,@PAR5,@PAR6,@PAR7,@PAR8,@PAR9,@PAR10,@PAR12,@PAR12) AND VHD_NOSERIE = veh_numserie),VEH_SCTOACOND,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'SN' AND PAR_IDMODULO = 'UNI' AND PAR_IDENPARA = VEH_SITUACION) AS Situacion,Unidades=1
INTO #INV_NUEVOS 
FROM ser_vehiculo,uni_catalogo,UNI_VEHDETA 
where unc_idcatalogo = veh_catalogo and unc_modelo = veh_anmodelo AND VHD_NOSERIE = VEH_NUMSERIE AND
VEH_SITUACION IN ('ING','PRV','FIS','PED','SEP','SINI','TRAN','DEMO')

SELECT *,RANGO = CASE 
WHEN DiasInventa <= 30 THEN 'De 1 a 30'
WHEN DiasInventa BETWEEN 31 AND 60 THEN 'De 31 a 60' 
WHEN DiasInventa BETWEEN 61 AND 90 THEN 'De 61 a 90'
WHEN DiasInventa BETWEEN 91 AND 120 THEN 'De 91 a 120'
WHEN DiasInventa BETWEEN 121 AND 180 THEN 'De 121 a 180'
WHEN DiasInventa BETWEEN 181 AND 240 THEN 'De 181 a 240'
WHEN DiasInventa BETWEEN 241 AND 360 THEN 'De 241 a 360'
WHEN DiasInventa > 360 THEN 'Mas de 360' END,
ORDEN = CASE 
WHEN DiasInventa <= 30 THEN 1
WHEN DiasInventa BETWEEN 31 AND 60 THEN 2
WHEN DiasInventa BETWEEN 61 AND 90 THEN 3
WHEN DiasInventa BETWEEN 91 AND 120 THEN 4
WHEN DiasInventa BETWEEN 121 AND 180 THEN 5
WHEN DiasInventa BETWEEN 181 AND 240 THEN 6
WHEN DiasInventa BETWEEN 241 AND 360 THEN 7
WHEN DiasInventa > 360 THEN 8 END
INTO #INV_NUEVOS1 FROM #INV_NUEVOS

INSERT INTO BI_INVENTARIO_UNIDADES
SELECT * FROM #INV_NUEVOS1



go

