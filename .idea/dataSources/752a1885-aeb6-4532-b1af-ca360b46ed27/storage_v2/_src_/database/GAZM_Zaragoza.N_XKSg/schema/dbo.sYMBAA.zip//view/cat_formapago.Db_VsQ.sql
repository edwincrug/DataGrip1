CREATE VIEW [cat_formapago] AS Select * From GAZM_Concentra.dbo.cat_formapago

