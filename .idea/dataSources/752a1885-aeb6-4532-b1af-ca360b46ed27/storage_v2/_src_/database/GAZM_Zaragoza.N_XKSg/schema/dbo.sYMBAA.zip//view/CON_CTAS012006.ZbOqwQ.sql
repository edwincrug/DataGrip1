create view [dbo].[CON_CTAS012006] as select * from GAZM_Concentra.dbo.CON_CTAS012006
go

