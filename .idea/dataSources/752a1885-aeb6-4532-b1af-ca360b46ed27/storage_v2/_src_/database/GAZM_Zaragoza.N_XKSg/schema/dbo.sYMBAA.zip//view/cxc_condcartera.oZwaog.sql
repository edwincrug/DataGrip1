create view [dbo].[cxc_condcartera] as select * from GAZM_Concentra.dbo.cxc_condcartera
go

