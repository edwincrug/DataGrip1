
CREATE PROC SP_IPIN_VEN_REFACCIONES_INSERTA
AS

--INSERTA EN IPIN
update par_tmptiposmov set tmc_ref2 = a.tmc_ref2 From (select tmc_ref2,tmc_ref1 From par_tmptiposmov where 
tmc_ref2 <> '' and tmc_mpmov in ('dv','dt','dw')) a where a.tmc_ref1 = par_tmptiposmov.tmc_ref1 and 
par_tmptiposmov.tmc_mpmov in ('dv','dt','dw') and par_tmptiposmov.tmc_ref2 = ''

update par_tmptiposmov set tmc_idperinterno = a.tmc_idperinterno from (select tmc_idperinterno,tmc_ref1 from 
par_tmptiposmov where tmc_idperinterno <> '' and tmc_mpmov in ('dv','dt','dw') ) a where a.tmc_ref1 = 
par_tmptiposmov.tmc_ref1 and par_tmptiposmov.tmc_mpmov in ('dv','dt','dw') and 
isnull(par_tmptiposmov.tmc_idperinterno,'') = ''

UPDATE par_tmptiposmov SET tmc_subtotal = 1 WHERE tmc_subtotal = 0 AND TMC_CVEUSU='GMI'

Select convert(varchar(20),Factura) as Factura,convert(varchar(8),case when isnull(FechaFactura,'') = '' then 'ND' 
else replace(FechaFactura,'/','') end) as FechaFactura,convert(varchar(20),Pedido) as Pedido,convert(varchar(8),
case when isnull(FechaPedido,'') = '' then 'ND' else replace(FechaPedido,'/','') end) 
as FechaPedido,convert(varchar(8),case when isnull(FechaEntrega,'') = '' then 'ND' else replace(FechaEntrega,'/','')
end) as FechaEntrega,convert(varchar(50),Tipo_venta) as Tipo_venta,convert(varchar(100),Nombre_tipo_venta) as 
Nombre_tipo_venta,convert(varchar(50),Cliente) as Cliente,convert(varchar(50),condiciones_venta) as 
condiciones_venta,convert(decimal(17,5),saldo_cliente) as saldo_cliente,convert(decimal(17,5),saldo_financiera) 
as saldo_financiera,convert(varchar(50),Estatus) as Estatus,convert(varchar(100),Nombre_estatus) as Nombre_estatus,
convert(numeric(17,0),PlazoPago) as PlazoPago,convert(varchar(50),Promocion) as Promocion,convert(varchar(50),
Numero_empleado) as Numero_empleado,convert(varchar(8),case when isnull(FechaCancel,'') = '' then 'ND' else 
replace(FechaCancel,'/','') end) as FechaCancel,convert(varchar(50),tipo_poliza) as tipo_poliza,convert(varchar(100),
nombre_tipo_poliza) as nombre_tipo_poliza,convert(varchar(20),numero_poliza) as numero_poliza,convert(varchar(8),
case when isnull(fecha_poliza,'') = '' then 'ND' else replace(fecha_poliza,'/','') end) as fecha_poliza,
convert(varchar(100),Referencia) as Referencia,convert(varchar(100),Origen) as Origen,convert(decimal(17,5),Costo) as
Costo,convert(decimal(17,5),Precio_unitario) as Precio_unitario,convert(decimal(17,5),Descuento) as Descuento,
convert(decimal(17,5),impuesto_iva) as impuesto_iva,convert(decimal(17,5),Total) 
as Total,convert(decimal(17,5),utilidad) as utilidad,convert(varchar(50),TipoMoneda) as TipoMoneda,
convert(varchar(100),NombreMoneda) as NombreMoneda,convert(decimal(17, 5), Paridad) As Paridad 
into IPIN_VEN_REFACCIONES 
From (select case when tmc_mpmov in ('dv','dt','dw') then '9' + tmc_ref1 
else tmc_ref1 end as Factura,case when tmc_mpmov in ('dv','dt','dw') then tmc_fechmovdet else tmc_fechfact end as 
FechaFactura,tmc_ref2 as Pedido,tmc_fechfact as FechaPedido,NULL as FechaEntrega,tmc_idtipomov as Tipo_venta,
tmc_destipomov as Nombre_tipo_venta,tmc_idperexterno as Cliente,tmc_contcred as condiciones_venta,
(select sum(ccp_cargo - ccp_abono) from vis_concar01 where ccp_iddocto = tmc_ref1 and ccp_idpersona = 
tmc_idperexterno and substring(ccp_tipodocto,len(ccp_tipodocto)-2,3) <> 'iva') as saldo_cliente,0 as 
saldo_financiera,tmc_statusfact as Estatus,case when isnull(tmc_statusfact,'') <> '' then case when 
tmc_statusfact = 'I' then 'FACTURADO' else 'CANCELADO' end else '' end as Nombre_estatus,0 as PlazoPago,NULL as 
Promocion,tmc_idperinterno as Numero_empleado,'ND' as FechaCancel,tmc_tipo as tipo_poliza,
isnull((select par_descrip1 from pnc_parametr where par_tipopara = 'tipoli' and par_idenpara = tmc_tipo),'') 
as nombre_tipo_poliza,tmc_consecutivo as numero_poliza,tmc_fechmovdet as fecha_poliza,NULL as Referencia,NULL 
as Origen,sum(abs(tmc_cantidad) * tmc_costopromuni) as Costo,sum(tmc_subtotal) as Precio_unitario,sum(tmc_descuento)
as Descuento,sum(tmc_iva) as impuesto_iva,sum(tmc_total) as Total,
sum(((abs(tmc_subtotal)- abs(abs(tmc_cantidad) * tmc_costopromuni))/tmc_subtotal)*100) as utilidad,
tmc_ncr as TipoMoneda,(select par_descrip1 from pnc_parametr 
where par_idenpara = tmc_ncr and par_tipopara = 'MN') as NombreMoneda,0 as Paridad from par_tmptiposmov where 
tmc_cveusu = 'GMI' group by tmc_ref1,tmc_fechfact,tmc_fechfact,tmc_idtipomov,tmc_destipomov,tmc_idperexterno,
tmc_statusfact,tmc_ref2,tmc_idperinterno,tmc_mpmov,tmc_consecutivo,tmc_tipo,tmc_fechmovdet,tmc_ncr,tmc_contcred,tmc_subtotal) as 
VEN_REFACCIONES

update IPIN_VEN_REFACCIONES set Numero_empleado = mov_idcomvend from 
IPIN_VEN_REFACCIONES inner join par_movtos on Mov_Refer1  = factura and condiciones_venta = 
convert(varchar,mov_numero)

update IPIN_VEN_REFACCIONES set Numero_empleado = mov_idcomvend from 
IPIN_VEN_REFACCIONES inner join par_movtos on Mov_Refer1  = factura and condiciones_venta = 
convert(varchar,mov_numero)

go

