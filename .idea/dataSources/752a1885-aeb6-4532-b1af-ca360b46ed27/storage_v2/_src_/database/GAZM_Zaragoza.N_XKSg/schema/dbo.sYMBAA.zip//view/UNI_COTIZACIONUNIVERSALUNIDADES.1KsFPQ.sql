CREATE VIEW [dbo].[UNI_COTIZACIONUNIVERSALUNIDADES]
AS
SELECT     ucn_idcotizadetalle, ucn_idcatalogo, ucn_modelo, ucn_noserie, ucn_estatus, ucn_observaciones, ucn_colorext,
ucn_colorint, ucn_preciounidad, ucn_iva, ucn_total, ucn_costounidad, ucn_monedacosto, ucn_monedaventa, ucn_idusuarioalta, 
ucn_idausuariomodifica, ucn_fechaalta, ucn_fechamodifica, ucn_factoriva, ucn_fechaentregauni, ucu_idcotizacion, ucn_tipoprecio,
ucn_ordengenerada, ucu_hrpromesaent, ucn_vinasignado, ucn_idfactura, ucn_situacionfact, ucn_autoriza,ucn_reingreso,ucn_cveusocfdi
FROM       CUENTASPORCOBRAR.dbo.UNI_COTIZACIONUNIVERSALUNIDADES
go

