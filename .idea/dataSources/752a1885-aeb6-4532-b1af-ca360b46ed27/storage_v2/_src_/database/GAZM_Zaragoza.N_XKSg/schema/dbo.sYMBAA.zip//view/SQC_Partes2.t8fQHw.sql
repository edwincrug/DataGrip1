create view [dbo].[SQC_Partes2] as select * from [GAZM_Concentra].[dbo].[SQC_Partes2]
go

