CREATE VIEW [dbo].[cat_departamentos]
AS
SELECT dep_iddepartamento, gpo_idgrupo, div_iddivision, emp_idempresa, suc_idsucursal, idi_ididioma, dep_nombre, dep_nombrecto, dep_fechaalta, dep_usualta, dep_fechamodifica, dep_usumodifica, dep_estatus
FROM       [ControlAplicaciones].dbo.cat_departamentos
go

