
CREATE PROCEDURE sp_data_CM 
 
  @Fechaini DATE  --= '01/08/2019'
 ,@Fechafin DATE --= '07/08/2019'
 ,@db_p   VARCHAR (MAX)   --= 'GAZM_Zaragoza'

AS
BEGIN TRY
	DECLARE @Query AS NVARCHAR (MAX)

SET @Query = 
'INSERT INTO  data_BP 
		(	
		 [idCompania]
		,[idSucursal]
		,[Canal de venta]
		,[unidadDescripcion]
		,[Cantidad]
		,[idCliente]
		,[ClienteRazonSocial]
		,[ClienteRFC]
		,[Vendedor]
		,[Pedido]
		,[Factura]
		,[FacturaFecha]
		,[InventarioNumero]
		,[ColorInterior]
		,[DescripcionColorInt]
		,[ColorExterior]
		,[DescripcionColorExt]
		,[Familia]
		,[serieNumero]
		,[ModeloYear]
		,[Catalogo]
		,[Departamento]
		,[CarLine]
		,[precioBase]
		,[impuestoIsan]
		,[IvaPorcentaje]
		,[IvaImporte]
		,[importeTotal]
		,[Subsidio]
		,[Comisión]
		,[NotasdeCredito]
		,[Costo]
		,[Incentivo]
		,[CostoTotal]
		,[Utilidad]
		,[periodoYear]
		,[periodoMes]
		,[penIdCatalogo]
		,[vehQcTipoMotor]
		,[ubicacion]
		,[tipoUnidad]
		,[FechaEntregaReal]
		,[Fecha_inventario]
		,[ID_APV]
		,[FechaEmision]
	)
		SELECT  ucu_idempresa as idCompania, ucu_idsucursal as idSucursal, vnt.PAR_DESCRIP1 as ''Canal de venta'', 
		VEH_TIPOAUTO as unidadDescripcion, 1 as Cantidad, VTE_IDCLIENTE as idCliente, 
		rtrim(PVT_NOMRAZON + '' '' + PVT_PATERNO + '' '' + PVT_MATERNO) as ClienteRazonSocial, PVT_RFC as ClienteRFC, 
		rtrim(VEN.PER_NOMRAZON + '' '' + VEN.PER_PATERNO + '' '' + VEN.PER_MATERNO) as Vendedor,
		LTP.UPE_IDPEDI as Pedido, VTE_DOCTO as Factura, convert(date, VTE_FECHDOCTO, 103) as FacturaFecha, VEH_NOINVENTA as InventarioNumero, 
		LTU.PEN_COLORINT as ColorInterior, ci.COL_DESCRIPCION as DescripcionColorInt, LTU.PEN_COLOREXT as ColorExterior, 
		CE.COL_DESCRIPCION as DescripcionColorExt, UNC_FAMILIA as Familia, LTU.PEN_NUMSERIE as serieNumero, LTU.PEN_MODELO as ModeloYear, 
		LTU.PEN_IDCATALOGO as Catalogo, vnt.PAR_DESCRIP1 as Departamento, cli.PAR_DESCRIP1 as CarLine, 
		LTU.PEN_SUBTOTAL1 as precioBase, LTU.PEN_ISAN as impuestoIsan, LTU.PEN_FIVA as IvaPorcentaje, LTU.PEN_IVA as IvaImporte, LTU.PEN_TOTAL as importeTotal, 
		0 as Subsidio, 0 As Comisión, 
		isnull((select SUM(ROUND((PAM_IMPORTEMON /(CAST(PAM_PORIVA AS NUMERIC)/100+1)),2,0)) from  ' + @db_p + '.dbo.cxc_pagant where pam_tipodocto = ''NCRBONI'' 
				and PAM_IDCOTIZACIONWEB = ucu_idcotizacion), 0) as NotasdeCredito,
		(select sum(VHD_COSTO) from ' + @db_p + '.dbo.uni_ltvehdeta where vhd_docto = vte_docto AND vhd_tipo IN (SELECT par_idenpara FROM ' + @db_p + '.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''TPOEQ'' AND PAR_IMPORTE5 = 1) AND vhd_tipo not in (''DIM'', ''BON''))


 as Costo, 
		LTU.PEN_BONIFICACION As Incentivo, 
		(select sum(VHD_COSTO) from ' + @db_p + '.dbo.uni_ltvehdeta where vhd_docto = vte_docto AND vhd_tipo IN (SELECT par_idenpara FROM ' + @db_p + '.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''TPOEQ'' AND PAR_IMPORTE5 = 1) AND vhd_tipo  not in (''DIM'', ''BON'')


)+ LTU.PEN_BONIFICACION As CostoTotal, 
		LTU.PEN_SUBTOTAL1-((select sum(VHD_COSTO) from ' + @db_p + '.dbo.uni_ltvehdeta where vhd_docto = vte_docto AND vhd_tipo IN (SELECT par_idenpara FROM ' + @db_p + '.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''TPOEQ'' AND PAR_IMPORTE5 = 1) AND vhd_tipo not in 


(''DIM'', ''BON''))+ LTU.PEN_BONIFICACION) As Utilidad,
		right(VTE_FECHDOCTO, 4) As periodoYear, substring(VTE_FECHDOCTO, 4, 2) As periodoMes, LTU.PEN_IDCATALOGO as penIdCatalogo, 
		mot.PAR_DESCRIP1 as vehQcTipoMotor, ubi.PAR_DESCRIP1 as ubicacion, UNC_TIPO as tipoUnidad, PEN.PEN_FECHAENTREGA_REAL as FechaEntregaReal,VEH_FECRETIRO AS Fecha_inventario,LTP.UPE_IDAGTE AS ID_APV, convert(date, VHT_FECHOPE, 103)AS FechaEmision
		from ' + @db_p + '.dbo.ADE_VTAFI
		inner join ' + @db_p + '.dbo.UNI_PEDIDO on UPE_IDPEDI = VTE_REFERENCIA1
		inner join ' + @db_p + '.dbo.UNI_LTPEDIDO LTP on LTP.UPE_DOCTO = VTE_DOCTO
		inner join ' + @db_p + '.dbo.UNI_LTPEDIUNI LTU on LTU.PEN_DOCTO = VTE_DOCTO
		inner join ' + @db_p + '.dbo.UNI_PEDIUNI PEN on PEN.PEN_IDPEDI = LTP.UPE_IDPEDI and PEN.PEN_NUMSERIE = LTU.PEN_NUMSERIE
		inner join ' + @db_p + '.dbo.PNC_PARAMETR VNT on vnt.PAR_TIPOPARA = ''VNT'' and VNT.PAR_IDENPARA = LTU.PEN_VENTA
		inner join ' + @db_p + '.dbo.SER_VEHICULO on VEH_NUMSERIE = LTU.PEN_NUMSERIE
		inner join ' + @db_p + '.dbo.uni_cotizacionuniversal on ucu_idcotizacion = UPE_IDCOTIZACIONUNIVERSAL
		inner join ' + @db_p + '.dbo.ADE_PERSONAS on PVT_DOCTO = VTE_DOCTO
		inner join ' + @db_p + '.dbo.PER_PERSONAS VEN on VEN.PER_IDPERSONA = LTP.UPE_IDAGTE
		inner join ' + @db_p + '.dbo.UNI_CATACOLOR CI on CI.COL_CATALOGO = LTU.PEN_IDCATALOGO and CI.COL_MODELO = LTU.PEN_MODELO and CI.COL_CLAVE = LTU.PEN_COLORINT and CI.COL_TIPO = ''INTERIOR''
		inner join ' + @db_p + '.dbo.UNI_CATACOLOR CE on CE.COL_CATALOGO = LTU.PEN_IDCATALOGO and CE.COL_MODELO = LTU.PEN_MODELO and CE.COL_CLAVE = LTU.PEN_COLOREXT and CE.COL_TIPO = ''EXTERIOR''
		inner join ' + @db_p + '.dbo.UNI_CATALOGO on UNC_IDCATALOGO = LTU.PEN_IDCATALOGO and UNC_MODELO = LTU.PEN_MODELO
		inner join ' + @db_p + '.dbo.PNC_PARAMETR CLI on CLI.PAR_TIPOPARA = ''CLI'' and CLI.PAR_IDENPARA = UNC_FAMILIA
		inner join ' + @db_p + '.dbo.PNC_PARAMETR UBI on UBI.PAR_TIPOPARA = ''UBI'' and UBI.PAR_IDENPARA = VEH_UBICACION
		inner join ' + @db_p + '.dbo.PNC_PARAMETR MOT on MOT.PAR_TIPOPARA = ''TMO'' and MOT.PAR_IDENPARA = UNC_TIPOMOTOR
		INNER JOIN ' + @db_p + '.dbo.UNI_VEHICULOHIST HST ON HST.VHT_Documento = VTE_DOCTO AND HST.VHT_Operacion = ''FACTURACION''
		where VTE_TIPODOCTO = ''A'' and (convert(date, VTE_FECHDOCTO, 103) between ''' + CAST(CONVERT(date, @Fechaini, 103) AS nvarchar(10))+ ''' and ''' + CAST(CONVERT(date, @Fechafin, 103) AS nvarchar(10))+
		'''OR convert(date, PEN.PEN_FECHAENTREGA_REAL, 103) between ''' + CAST(CONVERT(date, @Fechaini, 103) AS nvarchar(10))+ ''' and ''' + CAST(CONVERT(date, @Fechafin, 103) AS nvarchar(10))+ '''
		 )UNION all
		select   ucu_idempresa as idCompania, ucu_idsucursal as idSucursal, vnt.PAR_DESCRIP1 as ''Canal de venta'', 
		VEH_TIPOAUTO as unidadDescripcion, -1 as Cantidad, VEC_IDCLIENTE as idCliente, 
		rtrim(PVT_NOMRAZON + '' '' + PVT_PATERNO + '' '' + PVT_MATERNO) as ClienteRazonSocial, PVT_RFC as ClienteRFC, 
		rtrim(VEN.PER_NOMRAZON + '' '' + VEN.PER_PATERNO + '' '' + VEN.PER_MATERNO) as Vendedor,
		LTP.UPE_IDPEDI as Pedido, VEC_DOCTO as Factura, convert(date, VEC_FECHDOCTO, 103) as FacturaFecha, VEH_NOINVENTA as InventarioNumero, 
		LTU.PEN_COLORINT as ColorInterior, ci.COL_DESCRIPCION as DescripcionColorInt, LTU.PEN_COLOREXT as ColorExterior, 
		CE.COL_DESCRIPCION as DescripcionColorExt, UNC_FAMILIA as Familia, LTU.PEN_NUMSERIE as serieNumero, LTU.PEN_MODELO as ModeloYear, 
		LTU.PEN_IDCATALOGO as Catalogo, vnt.PAR_DESCRIP1 as Departamento, cli.PAR_DESCRIP1 as CarLine, 
		-LTU.PEN_SUBTOTAL1 as precioBase, -LTU.PEN_ISAN as impuestoIsan, -LTU.PEN_FIVA as IvaPorcentaje, -LTU.PEN_IVA as IvaImporte, -LTU.PEN_TOTAL as importeTotal, 
		0 as Subsidio, 0 As Comisión, 
		isnull((select SUM(ROUND((PAM_IMPORTEMON /(CAST(PAM_PORIVA AS NUMERIC)/100+1)),2,0))*-1 from ' + @db_p + '.dbo.cxc_pagant where pam_tipodocto = ''NCRBONI''
				and pam_iddocto in (select cde_docto from ' + @db_p + '.dbo.ade_cancfd where cde_tipodocto = ''B'') 
				and PAM_IDCOTIZACIONWEB = ucu_idcotizacion), 0) as NotasdeCredito,
		(select -sum(VHD_COSTO) from ' + @db_p + '.dbo.uni_ltvehdeta where vhd_docto = VEC_docto AND vhd_tipo IN (SELECT par_idenpara FROM ' + @db_p + '.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''TPOEQ'' AND PAR_IMPORTE5 = 1) AND vhd_tipo not in (''DIM'', ''BON'')


) as Costo, 
		-LTU.PEN_BONIFICACION As Incentivo, 
		-((select sum(VHD_COSTO) from ' + @db_p + '.dbo.uni_ltvehdeta where vhd_docto = VEC_docto AND vhd_tipo IN (SELECT par_idenpara FROM ' + @db_p + '.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''TPOEQ'' AND PAR_IMPORTE5 = 1) AND vhd_tipo not in (''DIM'', ''BON''


))+ LTU.PEN_BONIFICACION) As CostoTotal, 
		-(LTU.PEN_SUBTOTAL1-((select sum(VHD_COSTO) from ' + @db_p + '.dbo.uni_ltvehdeta where vhd_docto = VEC_docto AND vhd_tipo IN (SELECT par_idenpara FROM ' + @db_p + '.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''TPOEQ'' AND PAR_IMPORTE5 = 1) AND vhd_tipo not in (''DIM'', ''BON''))+ LTU.PEN_BONIFICACION)) As Utilidad,
		right(VEC_FECHDOCTO, 4) As periodoYear, substring(VEC_FECHDOCTO, 4, 2) As periodoMes, LTU.PEN_IDCATALOGO as penIdCatalogo, 
		mot.PAR_DESCRIP1 as vehQcTipoMotor, ubi.PAR_DESCRIP1 as ubicacion, UNC_TIPO as tipoUnidad, PEN.PEN_FECHAENTREGA_REAL as FechaEntregaReal,VEH_FECRETIRO AS Fecha_inventario,LTP.UPE_IDAGTE AS ID_APV,convert(date, VHT_FECHOPE, 103)AS FechaEmision
		from ' + @db_p + '.dbo.ADE_CANFI
		inner join ' + @db_p + '.dbo.UNI_PEDIDO on UPE_IDPEDI = VEC_REFERENCIA1
		inner join ' + @db_p + '.dbo.UNI_LTPEDIDO LTP on LTP.UPE_DOCTO = VEC_DOCTO
		inner join ' + @db_p + '.dbo.UNI_LTPEDIUNI LTU on LTU.PEN_DOCTO = VEC_DOCTO
		inner join ' + @db_p + '.dbo.UNI_PEDIUNI PEN on PEN.PEN_IDPEDI = LTP.UPE_IDPEDI and PEN.PEN_NUMSERIE = LTU.PEN_NUMSERIE
		inner join ' + @db_p + '.dbo.PNC_PARAMETR VNT on vnt.PAR_TIPOPARA = ''VNT'' and VNT.PAR_IDENPARA = LTU.PEN_VENTA
		inner join ' + @db_p + '.dbo.SER_VEHICULO on VEH_NUMSERIE = LTU.PEN_NUMSERIE
		inner join ' + @db_p + '.dbo.uni_cotizacionuniversal on ucu_idcotizacion = UPE_IDCOTIZACIONUNIVERSAL
		inner join ' + @db_p + '.dbo.ADE_PERSONAS on PVT_DOCTO = VEC_DOCTO
		inner join ' + @db_p + '.dbo.PER_PERSONAS VEN on VEN.PER_IDPERSONA = LTP.UPE_IDAGTE
		inner join ' + @db_p + '.dbo.UNI_CATACOLOR CI on CI.COL_CATALOGO = LTU.PEN_IDCATALOGO and CI.COL_MODELO = LTU.PEN_MODELO and CI.COL_CLAVE = LTU.PEN_COLORINT and CI.COL_TIPO = ''INTERIOR''
		inner join ' + @db_p + '.dbo.UNI_CATACOLOR CE on CE.COL_CATALOGO = LTU.PEN_IDCATALOGO and CE.COL_MODELO = LTU.PEN_MODELO and CE.COL_CLAVE = LTU.PEN_COLOREXT and CE.COL_TIPO = ''EXTERIOR''
		inner join ' + @db_p + '.dbo.UNI_CATALOGO on UNC_IDCATALOGO = LTU.PEN_IDCATALOGO and UNC_MODELO = LTU.PEN_MODELO
		inner join ' + @db_p + '.dbo.PNC_PARAMETR CLI on CLI.PAR_TIPOPARA = ''CLI'' and CLI.PAR_IDENPARA = UNC_FAMILIA
		inner join ' + @db_p + '.dbo.PNC_PARAMETR UBI on UBI.PAR_TIPOPARA = ''UBI'' and UBI.PAR_IDENPARA = VEH_UBICACION
		inner join ' + @db_p + '.dbo.PNC_PARAMETR MOT on MOT.PAR_TIPOPARA = ''TMO'' and MOT.PAR_IDENPARA = UNC_TIPOMOTOR
		INNER JOIN ' + @db_p + '.dbo.UNI_VEHICULOHIST HST ON HST.VHT_Documento = VEC_DOCTO AND HST.VHT_Operacion = ''FACTURACION''
		where VEC_TIPODOCTO = ''A'' and convert(date, VEC_FECHDOCTO, 103) between ''' + CAST(CONVERT(date, @Fechaini, 103) AS nvarchar(10))+ ''' and ''' + CAST(CONVERT(date, @Fechafin, 103) AS nvarchar(10)) + ''''
	EXEC (@Query)
END TRY 
BEGIN CATCH  
	INSERT INTO ERROR_CATCH
    SELECT   
        'NO SE PROCESO / ' + @db_p + ' ' + CONVERT (VARCHAR (12),@Fechaini) + ',' + CONVERT (VARCHAR(12),@Fechafin) + ERROR_MESSAGE()
  
	IF @@TRANCOUNT > 0  
        ROLLBACK TRANSACTION;  
END CATCH;  
IF @@TRANCOUNT > 0  
    COMMIT TRANSACTION;

go

