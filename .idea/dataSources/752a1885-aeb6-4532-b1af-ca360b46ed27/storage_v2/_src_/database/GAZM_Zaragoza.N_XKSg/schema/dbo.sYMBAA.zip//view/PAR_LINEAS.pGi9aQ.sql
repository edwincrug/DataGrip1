create view [dbo].[PAR_LINEAS] as select * from GAZM_Concentra.dbo.PAR_LINEAS
go

