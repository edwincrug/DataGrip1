create view [dbo].[CON_POLfij012012] as select * from GAZM_Concentra.dbo.CON_POLfij012012
go

