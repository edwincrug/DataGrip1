-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SEL_GENERA_LAYOUT_PRUEBA
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT TOP 100
/*========================================
DATOS DEL CLIENTE COMPRADOR
========================================*/
per.PER_IDPERSONA AS numero_cliente
,CASE WHEN per.PER_PATERNO <> '' 
      THEN CASE WHEN charindex(' ',per.PER_NOMRAZON)>0
				THEN substring(per.PER_NOMRAZON,1,charindex(' ',per.PER_NOMRAZON))
				ELSE per.PER_NOMRAZON 
			END
	  ELSE per.PER_NOMRAZON 
END AS primer_nombre
,CASE WHEN per.PER_PATERNO <> '' 
	  THEN CASE WHEN charindex(' ',per.PER_NOMRAZON)>0
	            THEN  substring(per.PER_NOMRAZON,charindex(' ',per.PER_NOMRAZON)+1,len(per.PER_NOMRAZON)-charindex(' ',per.PER_NOMRAZON)) 
				ELSE ''
				end
	  ELSE ''
END as segundo_nombre
,per.PER_PATERNO AS apellido_paterno
,per.PER_MATERNO AS apellido_materno
,per.PER_SEXO AS genero
,per.PER_EDOCIVIL AS estado_civil
,per.PER_FECNAC AS fecha_nacimiento
,per.PER_RFC AS rfc
,per.PER_TIPO AS tipo_de_regimen_fiscal
/*========================================
DATOS DE CONTACTO DEL CLIENTE COMPRADOR
========================================*/
,perfac.PER_NOMRAZON AS nombre_de_empresa
,perfac.PER_CALLE1 AS calle
,perfac.PER_NUMEXTER AS no_exterior
,perfac.PER_NUMINER AS no_interior
,perfac.PER_CIUDAD AS ciudad
,perfac.PER_COLONIA AS colonia
,perfac.PER_DELEGAC AS municipio_delegacion
,para.PAR_DESCRIP1 AS estado
,perfac.PER_CODPOS AS codigo_postal
,perfac.PER_TELEFONO1 AS telefono_casa
,perfac.PER_TELEFONO1 AS telefono_oficina
,perfac.PER_EXT1 AS ext_telefono_oficina
,perfac.per_telcelular AS telefono_celular
,perfac.PER_TELEFONO2 AS telefono_casa_2
,perfac.PER_TELEFONO2 AS telefono_oficina_2
,perfac.PER_EMAIL AS email_personal
,perfac.PER_EMAIL2 AS email_trabajo
,'' AS vehiculo_actual_anterior
,'' AS marca_actual_anterior
,'' AS aniomodelo_actual_anterior
,'' AS color_actual_anterior
,perfac.PER_ESCOLAR AS escolaridad
,'' AS facebook
,'' AS twitter
,'' AS desea_ser_contacto
,perfac.PER_MEDIOCONTACTO AS medio_de_contacto_preferido_del_cliente
--/*========================================
--DATOS DEL CONTACTO 1 DE VENTAS
--========================================*/
--,pp.PER_NOMRAZON AS primer_nombre_c1
--,'' AS segundo_nombre_c1
--,pp.PER_PATERNO AS apellido_paterno_c1
--,pp.PER_MATERNO AS apellido_materno_c1
--,pp.PER_CALLE1 AS calle_c1
--,pp.PER_NUMEXTER AS no_exterior_c1
--,pp.PER_NUMINER AS no_interior_c1
--,pp.PER_CIUDAD AS ciudad_c1
--,pp.PER_COLONIA AS colonia_c1
--,pp.PER_DELEGAC AS municipio_delegacion_c1
--,'' AS estado_c1
--,pp.PER_CODPOS AS codigo_postal_c1
--,pp.PER_TELEFONO1 AS telefono_casa_c1
--,pp.PER_TELEFONO2 AS telefono_oficina_c1
--,pp.PER_EXT2 AS ext_telefono_oficina_c1
--,pp.per_telcelular AS telefono_celular_c1
--,'' AS telefono_casa_2_c1
--,'' AS telefono_oficina_2_c1
--,pp.PER_EMAIL AS email_personal_c1
--,pp.PER_EMAIL AS email_trabajo_c1
--,pp.PER_ESCOLAR AS escolaridad_c1
--,'' AS facebook_c1
--,'' AS twitter_c1
--,'' AS desea_ser_contacto_c1
--,'' AS pasatiempo_1_c1
--,'' AS pasatiempo_2_c1
--,'' AS vinculo_c1
--,'' AS medio_de_contacto_preferido_del_cliente_c1
/*========================================
DATOS DEL CONTACTO 2 DE VENTAS
========================================*/
,'' AS primer_nombre_c2
,'' AS segundo_nombre_c2
,'' AS apellido_paterno_c2
,'' AS apellido_materno_c2
,'' AS calle_c2
,'' AS no_exterior_c2
,'' AS no_interior_c2
,'' AS ciudad_c2
,'' AS colonia_c2
,'' AS municipio_delegacion_c2
,'' AS estado_c2
,'' AS codigo_postal_c2
,'' AS telefono_casa_c2
,'' AS telefono_oficina_c2
,'' AS ext_telefono_oficina_c2
,'' AS telefono_celular_c2
,'' AS telefono_casa_2_c2
,'' AS telefono_oficina_2_c2
,'' AS email_personal_c2
,'' AS email_trabajo_c2
,'' AS escolaridad_c2
,'' AS facebook_c2
,'' AS twitter_c2
,'' AS desea_ser_contacto_c2
,'' AS pasatiempo_1_c2
,'' AS pasatiempo_2_c2
,'' AS vinculo_c2
,'' AS medio_de_contacto_preferido_del_cliente_c2
/*========================================
DATOS DEL PRODUCTO
========================================*/
,sv.VEH_TIPOAUTO AS modelo
,cat.UNC_MARCA   AS marca
,sv.VEH_ANMODELO AS aniomodelo
,sv.VEH_CATALOGO AS [version]
,uce.COL_DESCRIPCION AS color_exterior
,uci.COL_DESCRIPCION AS color_interior
,sv.VEH_NUMSERIE AS vin
,sv.VEH_NOMOTOR AS motor
,case when cat.UNC_TRANSMISION <> 'MAN' THEN 'A' ELSE 'M' END  AS transmision
/*========================================
DATOS DE FACTURACION
========================================*/
,up.UPE_IDCLIEFAC AS factura_cliente
,fac.VTE_VTABRUT AS precio_base_vehiculo
,vdeta.precioAcc AS precio_accesorios	   
,fac.VTE_TOTAL AS precio_vehiculo		 
,up2.PEN_FECHAENTREGA_REAL AS fecha_entrega_delvehiculo
,fac.VTE_FECHDOCTO AS fecha_factura_cliente
,emi.EMR_IDPERSONA AS clave_distribuidor
,'' AS clave_promocion
,par.PAR_DESCRIP1 AS tipo_venta
,pp.PER_IDPERSONA AS idvendedor
,pp.PER_NOMRAZON AS vend_vnombre
,pp.PER_PATERNO AS vend_vapaterno
,pp.PER_MATERNO AS vend_vamaterno
--========================================
FROM dbo.PER_PERSONAS per
left JOIN ADE_VTAFI fac
on fac.VTE_STATUS = 'I' 
AND fac.VTE_TIPODOCTO = 'A'
AND fac.VTE_IDCLIENTE = per.PER_IDPERSONA
JOIN dbo.SER_VEHICULO sv
ON fac.VTE_SERIE = sv.VEH_NUMSERIE
AND sv.VEH_SITUACION = 'VEN'
JOIN UNI_CATALOGO cat
ON sv.VEH_CATALOGO = cat.UNC_IDCATALOGO
AND sv.VEH_ANMODELO = cat.UNC_MODELO
JOIN (SELECT distinct sum(VHD_PRECIO) OVER(PARTITION BY v.VHD_NOSERIE) AS precioAcc
		,v.VHD_NOSERIE
		FROM UNI_VEHDETA v
		WHERE v.VHD_FACT='n' AND v.VHD_PRECIO>0 
) AS vdeta
ON fac.VTE_SERIE = vdeta.VHD_NOSERIE
JOIN dbo.UNI_PEDIDO up
ON fac.VTE_REFERENCIA1 = up.UPE_IDPEDI
JOIN dbo.UNI_PEDIUNI up2
ON up.UPE_IDPEDI = up2.PEN_IDPEDI
AND fac.VTE_SERIE = up2.PEN_NUMSERIE
AND up2.PEN_FECHAENTREGA IS NOT NULL
--JOIN dbo.UNI_PEDIDODET up3
--ON up.UPE_IDPEDI = up3.UPD_IDPEDI
JOIN dbo.PER_PERSONAS pp
ON up.UPE_IDAGTE = pp.PER_IDPERSONA
JOIN dbo.PER_PERSONAS perfac
ON up.UPE_IDCLIEFAC = perfac.PER_IDPERSONA
JOIN PNC_PARAMETR para 
on para.PAR_TIPOPARA = 'EO'
AND para.PAR_IDENPARA = perfac.PER_ESTADO
JOIN PNC_PARAMETR par
ON fac.VTE_FORMAPAGO = par.PAR_IDENPARA
AND par.PAR_TIPOPARA = 'VNT'
left JOIN ADE_EMISRECEP emi
ON par.PAR_CVEUSU = emi.EMR_CVEUSU
JOIN dbo.UNI_CATACOLOR uce
ON sv.VEH_COLOEXTE = uce.COL_CLAVE
AND sv.VEH_ANMODELO = uce.COL_MODELO
AND sv.VEH_CATALOGO = uce.COL_CATALOGO
JOIN dbo.UNI_CATACOLOR uci
ON sv.VEH_COLOINTE = uci.COL_CLAVE
AND sv.VEH_ANMODELO = uci.COL_MODELO
AND sv.VEH_CATALOGO = uci.COL_CATALOGO
--WHERE convert(varchar,convert(datetime, fac.VTE_FECHDOCTO,103),112) = convert(varchar,getdate()-5,112)
--ORDER BY fac.VTE_IDCLIENTE desc

END
go

