create view [dbo].[SQC_Liquidos] as select * from [GAZM_Concentra].[dbo].[SQC_Liquidos]
go

