
CREATE VIEW [dbo].[cxp_cancelaordenesmasivas]
AS
SELECT *
FROM GAZM_Concentra.dbo.cxp_cancelaordenesmasivas

go

