CREATE VIEW [dbo].[dep_recepnotascredito]
AS
SELECT rnc_idrecepnotascredito, rnc_iddevolucion, rnc_idalmacen, rnc_idempresa, rnc_idsucursal, rnc_idusuario,
rnc_fechaalta, rnc_estatus, rnc_idfactura, rnc_observaciones
FROM PortalRefacciones.dbo.dep_recepnotascredito

go

