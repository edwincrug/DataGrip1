---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[UNI_SaldoAnticipoWeb] AS 
SELECT     usa_idsaldoanticipo, uaw_idanticipoweb, usa_folioanticipo, usa_abono, usa_fechahora
FROM         cuentasporcobrar.dbo.UNI_SaldoAnticipoWeb;
go

