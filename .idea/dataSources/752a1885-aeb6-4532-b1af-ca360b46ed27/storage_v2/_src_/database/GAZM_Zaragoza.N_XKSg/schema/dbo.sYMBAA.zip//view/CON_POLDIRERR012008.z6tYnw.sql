create view [dbo].[CON_POLDIRERR012008] as select * from GAZM_Concentra.dbo.CON_POLDIRERR012008
go

