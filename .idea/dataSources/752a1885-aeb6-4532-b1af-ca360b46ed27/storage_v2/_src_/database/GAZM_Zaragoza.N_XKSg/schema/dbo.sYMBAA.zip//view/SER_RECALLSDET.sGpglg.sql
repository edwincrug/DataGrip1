create view [dbo].[SER_RECALLSDET] as select * from GAZM_Concentra.dbo.SER_RECALLSDET
go

