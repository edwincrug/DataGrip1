CREATE VIEW [dbo].[unp_unificaciondet]
AS 
SELECT upd_idunificaciondet, upd_idpersonaunifica, upd_idpersonaunificada, upe_idunificacion 
FROM GA_Corporativa.dbo.unp_unificaciondet
go

