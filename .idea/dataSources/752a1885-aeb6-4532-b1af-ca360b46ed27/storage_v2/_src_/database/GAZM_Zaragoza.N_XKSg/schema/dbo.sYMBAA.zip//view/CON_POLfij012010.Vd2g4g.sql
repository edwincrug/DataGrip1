create view [dbo].[CON_POLfij012010] as select * from GAZM_Concentra.dbo.CON_POLfij012010
go

