create view [dbo].[CON_POL012012] as select * from GAZM_Concentra.dbo.CON_POL012012
go

