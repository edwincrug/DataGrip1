create view [dbo].[SER_PAQVEH] as select * from GAZM_Concentra.dbo.SER_PAQVEH
go

