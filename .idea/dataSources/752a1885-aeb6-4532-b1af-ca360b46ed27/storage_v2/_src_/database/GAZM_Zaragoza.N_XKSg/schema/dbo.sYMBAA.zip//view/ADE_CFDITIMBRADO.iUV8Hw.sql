---(13)
create view [dbo].[ADE_CFDITIMBRADO] as select * from GAZM_Concentra.dbo.ADE_CFDITIMBRADO
go

