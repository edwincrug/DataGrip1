-- =============================================
-- Author:		José Antonio Arana Abarca
-- Create date: 19-07-2019
-- Description:	Actualiza la tabla de comisionistas con el porcentaje de acuerdo a tabulador vigente
-- =============================================
CREATE PROCEDURE [dbo].[ActualizaTablaComisionistas]
AS
BEGIN
	SET NOCOUNT ON;

    TRUNCATE TABLE Comision

	INSERT INTO Comision
	select VENDEDOR, COUNT(*) VENTAS, 0.00 COMISION
	from Ventas
	group by VENDEDOR

	--UPDATE C SET
	--C.COMISION = DT.[% Normal]
	--FROM Comision C
	--INNER JOIN Tabulador T
	--ON C.VENTAS between T.Desde AND T.Hasta
	--And T.Autorizado = 1
	--INNER JOIN DetalleTabulador DT
	--ON DT.idTabulador = T.idTabulador
	--AND C.Ventas between DT.Minimo AND DT.Maximo
END

go

