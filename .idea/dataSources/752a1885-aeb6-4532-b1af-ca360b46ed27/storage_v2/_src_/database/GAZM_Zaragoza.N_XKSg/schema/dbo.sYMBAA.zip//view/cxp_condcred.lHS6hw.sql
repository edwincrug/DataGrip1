create view [dbo].[cxp_condcred] as select * from GAZM_Concentra.dbo.cxp_condcred
go

