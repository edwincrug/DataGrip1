create view [dbo].[PER_PREFENCIAS] as select * from GAZM_Concentra.dbo.PER_PREFENCIAS
go

