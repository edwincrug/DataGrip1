create view [CON_CFDI012011] as select * from [GAZM_Concentra].dbo.[con_cfdi012011]
go

