---(7)
create view [dbo].[ADE_CFDEMIREC] as select * from GAZM_Concentra.dbo.ADE_CFDEMIREC
go

