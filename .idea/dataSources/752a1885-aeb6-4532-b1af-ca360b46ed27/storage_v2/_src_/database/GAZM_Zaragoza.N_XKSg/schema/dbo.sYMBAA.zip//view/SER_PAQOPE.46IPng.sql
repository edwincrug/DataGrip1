create view [dbo].[SER_PAQOPE] as select * from GAZM_Concentra.dbo.SER_PAQOPE
go

