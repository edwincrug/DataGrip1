CREATE VIEW [dbo].[cxc_refantypaglog]
AS
SELECT 
rlg_folio, rap_folioreferencia, rlg_descripcion, rlg_fecha
FROM         [GA_Corporativa].dbo.cxc_refantypaglog
go

