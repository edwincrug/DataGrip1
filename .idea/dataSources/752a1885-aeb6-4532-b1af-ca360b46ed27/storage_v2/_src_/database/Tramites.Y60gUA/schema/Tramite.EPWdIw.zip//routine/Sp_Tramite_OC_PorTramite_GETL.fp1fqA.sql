-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 18/08/2020
-- Description:	Obtiene las OC generadas por tarmite
-- [Tramite].[Sp_Tramite_OC_Procesadas_GETL]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_OC_PorTramite_GETL]
	@id_perTra INT
AS
BEGIN 
	SET NOCOUNT ON;
	
	--DECLARE @id_perTra INT = 2342;

	DECLARE @IdEmpresa INT = 0,
			@idOrdenmasiva INT = 0,
			@query VARCHAR(500) = '';


	SELECT @IdEmpresa = TD.id_empresa
	FROM Tramite.TramiteGastosMas TGM 
	JOIN dbo.tramiteDevoluciones TD ON TGM.id_perTraPadre = TD.id_perTra
	WHERE TGM.id_perTra = @id_perTra;


	SELECT @idOrdenmasiva = odm_idordenmasivaBPRO
	FROM Bitacora.cxp_ordenesmasivas BI 
	WHERE bita_id_perTra = @id_perTra;


	SELECT
		@query = 'SELECT odm_ordencompra, odm_fechaproceso FROM ' + nombre_base + '.dbo.cxp_ordenesmasivas WHERE odm_estatus = 1 AND odm_idordenmasiva = ' + CONVERT(VARCHAR(10), @idOrdenmasiva)
	FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO C
	INNER JOIN ControlAplicaciones.dbo.cat_empresas EM ON C.emp_idempresa = EM.emp_idempresa
	WHERE C.emp_idempresa = @IdEmpresa AND tipo = 2

	EXEC( @query );
	SET NOCOUNT OFF
END
go

