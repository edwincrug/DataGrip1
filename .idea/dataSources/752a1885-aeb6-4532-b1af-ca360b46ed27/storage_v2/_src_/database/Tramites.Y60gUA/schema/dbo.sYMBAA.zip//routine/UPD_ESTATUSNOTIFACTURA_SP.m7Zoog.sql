-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/10/2019>
-- Description:	<SP que actualiza el estatus del vale>
-- [dbo].[UPD_ESTATUSNOTIFACTURA_SP]   37,3,''
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUSNOTIFACTURA_SP] 
	@idValeEvidencia INT,
	@tipo INT
AS
BEGIN

	UPDATE tramite.facturaVale
	SET estatusNotificacion =  @tipo
	WHERE idValeEvidencia= @idValeEvidencia
	
	SELECT success = 1, msg = 'Se actualizo correctamente' 

END

go

