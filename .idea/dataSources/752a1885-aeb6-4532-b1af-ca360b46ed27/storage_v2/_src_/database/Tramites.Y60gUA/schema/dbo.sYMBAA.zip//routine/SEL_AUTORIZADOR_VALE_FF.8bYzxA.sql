-- =============================================
-- Author:		Roberto almanza
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_AUTORIZADOR_VALE_FF]
	@idEmpresa int
	,@idSucursal int
	,@idDepartamento int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	--select idUsuario = cu.usu_idusuario
	--,autorizador = cu.usu_nombre+' '+cu.usu_paterno+' '+cu.usu_materno
	--from  ControlAplicaciones..cat_usuarios cu
	--join tramite.cat_DepartamentosFF dff
	--on cu.usu_idusuario = dff.idAutorizador
	--and dff.idEmpresa = @idEmpresa
	--and dff.idSucursal = @idSucursal
	--and (dff.idDepartamento = @idDepartamento or dff.idDepartamentoFF = @idDepartamento)

	IF EXISTS (select top 1 1 from Tramite.cat_Departamentos_Sucursal_FF where idEmpresa = @idEmpresa and idSucursal = @idSucursal and idDepartamento = @idDepartamento)
	BEGIN
	select idUsuario = cu.usu_idusuario
	,autorizador = cu.usu_nombre+' '+cu.usu_paterno+' '+cu.usu_materno
	from  ControlAplicaciones..cat_usuarios cu
	join tramite.cat_Departamentos_Sucursal_FF dff
	on cu.usu_idusuario = dff.idAutorizador
	and dff.idEmpresa = @idEmpresa
	and dff.idSucursal = @idSucursal
	and dff.idDepartamento = @idDepartamento
	END
	ELSE
	BEGIN
    -- Insert statements for procedure here
	select idUsuario = cu.usu_idusuario
	,autorizador = cu.usu_nombre+' '+cu.usu_paterno+' '+cu.usu_materno
	from  ControlAplicaciones..cat_usuarios cu
	join tramite.cat_DepartamentosFF dff
	on cu.usu_idusuario = dff.idAutorizador
	and dff.idEmpresa = @idEmpresa
	and dff.idSucursal = @idSucursal
	and (dff.idDepartamento = @idDepartamento or dff.idDepartamentoFF = @idDepartamento)
	END



END
go

