-- =============================================
-- Author:		Luis Garcia
-- Create date: 22/07/2019
-- Description:	Trae los documentos del cliente
-- TEST [SEL_DOCUMENTOS_USADOS_BY_TRAMITE_SP] 450725, 1, 3, 58
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_USADOS_BY_TRAMITE_SP]
	@idCliente INT,
	@idEmpresa INT,
	@idSucursal INT,
	@idPerTra INT
	
AS
BEGIN
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = '',
	@idTraDe INT,
	@queryCarteras VARCHAR(MAX) = '';

	SELECT 
		@idTrade = id_traDe 
	FROM tramiteDevoluciones WHERE id_perTra = @idPerTra

	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SET @queryCarteras = 'SELECT ' + CHAR(13) +
		CHAR(9) + 'CO.PAR_DESCRIP1' + CHAR(13) +
	'FROM ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] C,' + ' [' + @nombreBase + '].DBO.PNC_PARAMETR CO' + CHAR(13) +
	'WHERE C.PAR_TIPOPARA = ''COCOCXC'' AND' + CHAR(13) +
	'C.PAR_HORA1 = ''12:00''' + CHAR(13) +
	'AND C.PAR_DESCRIP4 <> ''''' + CHAR(13) +
	'AND C.PAR_DESCRIP5 <> ''''' + CHAR(13) +
	'AND CO.PAR_TIPOPARA = ''COCOCXCCAR''' + CHAR(13) +
	'AND C.PAR_IDENPARA = CO.PAR_IDENPARA' + CHAR(13) +
	'AND CO.PAR_DESCRIP2 = ''''' + CHAR(13) +
	'AND CO.PAR_DESCRIP1 IN (SELECT PAR_IDENPARA FROM ' + '[' + @nombreBase + '].DBO.PNC_PARAMETR WHERE PAR_TIPOPARA = ''CARTERA'' AND PAR_IDMODULO = ''CXC''' + CHAR(13) +
							'AND PAR_DESCRIP2 IN (SELECT PAR_DESCRIP2 FROM ' + '[' + @nombreBase + '].DBO.PNC_PARAMETR WHERE PAR_TIPOPARA = ''ibandrade''))';

	SET @query =  'SELECT ' + CHAR(13) +
							CHAR(9) + 'cartera.CCP_IDDOCTO AS documento,' + CHAR(13) +
							CHAR(9) + 'UPPER(SUBSTRING(PNC.PAR_DESCRIP1,    CHARINDEX(''. -'',PNC.PAR_DESCRIP1) + 3    ,LEN(PNC.PAR_DESCRIP1)))  as PAR_DESCRIP1,' + CHAR(13) +
							CHAR(9) + 'DD.docDe_tipoPago AS tipoPago' + CHAR(13) +
						'FROM' + '[' + @nombreBase + '].[DBO].[vis_concar01] AS cartera' + CHAR(13) +
						'INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] AS persona ON persona.PER_IDPERSONA = cartera.CCP_IDPERSONA' + CHAR(13) +
						'LEFT JOIN [documentosDevueltos] DD ON DD.docDe_documento = cartera.CCP_IDDOCTO COLLATE DATABASE_DEFAULT ' + CHAR(13) +
						'INNER JOIN ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] PNC ON PNC.PAR_IDENPARA = cartera.CCP_Cartera' + CHAR(13) +
						'WHERE cartera.CCP_Cartera IN (' + @queryCarteras + ')' + CHAR(13) +
						'AND cartera.CCP_IDPERSONA IN (' + CONVERT(VARCHAR(20), @idCliente ) + ')' + CHAR(13) +
						'AND DD.id_traDe = ' + CONVERT(VARCHAR(20), @idTrade) + CHAR(13) +
						'AND PNC.PAR_TIPOPARA = ''CARTERA''' + CHAR(13) +
						'GROUP BY cartera.CCP_IDPERSONA, persona.PER_NOMRAZON, cartera.CCP_IDDOCTO, DD.id_docDe, DD.docDe_estatus, DD.id_docDe, PNC.PAR_DESCRIP1, DD.docDe_tipoPago' --+ CHAR(13) +
						--'HAVING (SUM(CCP_ABONO)-SUM(CCP_CARGO)) > 0'
	PRINT (@query)
	EXECUTE (@query)
END

go

