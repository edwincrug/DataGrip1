CREATE VIEW RevisaHorasValeVencidos as
SELECT 
	v.id, 
	v.fechaEntregaEfectivo, 
	vds.FechaRegisro, 
	[dbo].[Fn_Tramites_ValeVencido_CalculaHoras_v2]( v.fechaEntregaEfectivo, vds.FechaRegisro, NULL ) horas,
	vds.id_perTraReembolso
FROM Tramite.vales v 
LEFT JOIN ValeDescuentoSolicitado VDS ON VDS.IdTramiteReembolso = V.id
WHERE estatusVale = 6 AND idValeDescuentoSolicitado IS NOT NULL
go

