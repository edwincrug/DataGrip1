-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <03/09/2020>
-- Description:	<Trae todas los departamentos por empresa y sucursal>
--TEST SEL_DEPARTAMENTOS_AREA_SP 18, 44 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOS_AREA_SP]
     @idEmpresa INT = 0
    ,@idSucursal INT = 0
AS
BEGIN
	SELECT 
		idDepartamento AS idDepartamento
		,descripcion AS nombre
		,par_idenPara AS nombreCorto
		,idEmpresa emp_idempresa
		,idSucursal suc_idsucursal
	FROM   Tramite.cat_Departamentos_Sucursal_FF
	WHERE  idEmpresa = @idempresa AND idSucursal = @idsucursal and estatus = 1
END


go

