
-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <27/10/2020>
-- Description:	<Inserta la poliza>
-- [dbo].[INS_FONDOFIJO_CANCELACOMPROBACION_SP] 293
-- =============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_CANCELACOMPROBACION_SP] 
@idComprobacion INT
AS
BEGIN
DECLARE @idusuario INT,
		@idempresa INT,
		@idsucursal INT,
		@id_perTra INT = 0,
		@producto VARCHAR(255),
		@precioUnitario DECIMAL(18,2), 
		@nombreBD  VARCHAR(100), 
		@SQLAgencia NVARCHAR(MAX),
		@ordenCompra VARCHAR(100),
		@idProveedor INT,
		@justificoMas INT,
		@compNoAutorizado INT,
		@montoPoliza DECIMAL(18,2),
		@montoExcedente DECIMAL (18,2),
		@canal varchar(10),
		@tipoGasto INT
SELECT 
@idusuario = ff.idResponsable,
@idempresa = ff.idEmpresa,
@idsucursal = ff.idSucursal,
@id_perTra = ff.id_perTra,
@producto = ve.idcomprobacionVale,
@precioUnitario = ve.monto,
@compNoAutorizado = ve.compNoAutorizado,
@justificoMas = case when ve.monto > ve.montoPoliza  then 1 else 0 end,
@montoPoliza = ve.montoPoliza,
@montoExcedente = case when ve.monto > ve.montoPoliza  then ve.monto - ve.montoPoliza  else ve.monto end,
@canal = d.dep_nombrecto,
@tipoGasto = ve.idGastoFondoFijo
FROM tramite.valesEvidencia ve
INNER JOIN tramite.vales v on v.id = ve.idVales
INNER JOIN Tramite.valesFondoFijo vff on vff.idVales = v.id
INNER JOIN Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
INNER JOIN ControlAplicaciones.dbo.cat_departamentos d on d.dep_iddepartamento = ff.idDepartamento
WHERE ve.id = @idComprobacion 

--Polizas Generadas
DECLARE @SQLAVFF NVARCHAR(MAX),
		@SQLCVFR NVARCHAR(MAX),
		@SQLCVFN NVARCHAR(MAX),
		@nombreBDOperativa varchar (100),
		@comprobadoAVFF DECIMAL(18,2) = 0,
		@comprobadoCVFR DECIMAL(18,2) = 0,
		@comprobadoCVFN DECIMAL(18,2) = 0,
		@complemento varchar(10),
		@polizaAplicacion varchar(15),
		@polizaAplicacionMasAceptada varchar(15) ,
		@polizaAplicacionMasNoAceptada varchar(15)
 
select @complemento = complemento from [Tramite].[cat_Polizas_FFAG] where idSucursal = @idsucursal
SET @polizaAplicacion = 'AVFF' + @complemento;
SET @polizaAplicacionMasAceptada = 'CVFR' + @complemento;
SET @polizaAplicacionMasNoAceptada = 'CVFN' + @complemento;
select @nombreBDOperativa = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
		
		SET @SQLAVFF =  'SELECT @comprobadoAVFF = sum(det.VentaUnitario)
		from  ['+@nombreBDOperativa+'].dbo.DSBPDetInfo det
		inner join ['+@nombreBDOperativa+'].dbo.DSBPEncInfo poli on poli.DocumentoOrigen = det.DocumentoOrigen and poli.Proceso = det.proceso and det.Partida = 1
		where det.DocumentoOrigen in ('''+@producto+''')  and det.proceso in ('''+@polizaAplicacion+''')
		'
		print @SQLAVFF
		EXECUTE sp_executeSQL @SQLAVFF, N' @comprobadoAVFF DECIMAL(18,2) OUTPUT',@comprobadoAVFF OUTPUT 
		SET @comprobadoAVFF = ISNULL(@comprobadoAVFF,0)
		
		SET @SQLCVFR = 'SELECT @comprobadoCVFR = sum(det.VentaUnitario)
		from  ['+@nombreBDOperativa+'].dbo.DSBPDetInfo det
		inner join ['+@nombreBDOperativa+'].dbo.DSBPEncInfo poli on poli.DocumentoOrigen = det.DocumentoOrigen and poli.Proceso = det.proceso and det.Partida = 1
		where det.DocumentoOrigen in ('''+@producto+''')  and det.proceso in ('''+@polizaAplicacionMasAceptada+''')
		'
		print @SQLCVFR
		EXECUTE sp_executeSQL @SQLCVFR, N' @comprobadoCVFR DECIMAL(18,2) OUTPUT',@comprobadoCVFR OUTPUT 
		SET @comprobadoCVFR = ISNULL(@comprobadoCVFR,0)

		SET @SQLCVFN = 'SELECT @comprobadoCVFN = sum(det.VentaUnitario)
		from  ['+@nombreBDOperativa+'].dbo.DSBPDetInfo det
		inner join ['+@nombreBDOperativa+'].dbo.DSBPEncInfo poli on poli.DocumentoOrigen = det.DocumentoOrigen and poli.Proceso = det.proceso and det.Partida = 0
		where det.DocumentoOrigen in ('''+@producto+''')  and det.proceso in ('''+@polizaAplicacionMasNoAceptada+''')
		'
		print @SQLCVFN
		EXECUTE sp_executeSQL @SQLCVFN, N' @comprobadoCVFN DECIMAL(18,2) OUTPUT',@comprobadoCVFN OUTPUT 
		SET @comprobadoCVFN = ISNULL(@comprobadoCVFN,0)



IF(@tipoGasto = 2)
BEGIN
select @nombreBD = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_idempresa = @idempresa

SET @SQLAgencia = 'select @ordenCompra = odm_ordencompra, @idProveedor = odm_idproveedor
				   from ['+@nombreBD+'].dbo.cxp_ordenesmasivas om
				   inner join ['+@nombreBD+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
				   where  omd.omd_producto = '''+@producto+''''	
EXECUTE sp_executeSQL @SQLAgencia, N' @ordenCompra VARCHAR(100) OUTPUT, @idProveedor INT OUTPUT', @ordenCompra OUTPUT, @idProveedor OUTPUT

DECLARE @cancelaOrden NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[cxp_cancelaordenesmasivas]
	 ([com_idsucursal]
	,[com_folioorden]
	,[com_fechainsercion]
	,[com_usuarioinsercion]
	,[com_estatus])
	  VALUES
	  ('''+ CONVERT(VARCHAR(10),@idsucursal)+'''
	  ,'''+@ordenCompra+'''
	  ,DATEADD(d,DATEDIFF(d,0,GETDATE()),0)
	  ,'''+ CONVERT(VARCHAR(10),@idProveedor)+'''
	  ,0)'
	  
	  print @cancelaOrden
	  EXEC(@cancelaOrden)

END

IF(@comprobadoAVFF > 0)
BEGIN
--Envio poliza 25 DAVFF
EXEC [Tramites].[dbo].[INS_FONDOFIJO_POLIZA_SP] @idusuario, @idsucursal, 25, @producto, @comprobadoAVFF, '', @canal, 0, '', '';
END

IF(@comprobadoCVFR > 0)
BEGIN
--Envio poliza 26 DCVFR
EXEC [Tramites].[dbo].[INS_FONDOFIJO_POLIZA_SP] @idusuario, @idsucursal, 26, @producto, @comprobadoCVFR, '', @canal, 0, '', '';
END

IF(@comprobadoCVFN > 0)
BEGIN
--Envio poliza 27 DCVFN
EXEC [Tramites].[dbo].[INS_FONDOFIJO_POLIZA_SP] @idusuario, @idsucursal, 27, @producto, @comprobadoCVFN, '', @canal, 0, '', '';
END

UPDATE v
SET v.montoJustificado = v.montoJustificado - ve.monto, v.estatusVale = 3, fechaEntregaEfectivo = DATEADD(DAY,-4,GETDATE())
FROM tramite.valesEvidencia ve
INNER JOIN tramite.vales v on v.id = ve.idVales
WHERE ve.id = @idComprobacion


UPDATE tramite.valesEvidencia
SET idestatus = 3, estatusReembolso = 3
where id = @idComprobacion

END

go

