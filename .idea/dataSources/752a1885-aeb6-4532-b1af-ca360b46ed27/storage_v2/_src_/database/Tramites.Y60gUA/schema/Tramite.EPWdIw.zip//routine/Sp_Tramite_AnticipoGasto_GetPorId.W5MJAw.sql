-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <13/08/2019>
-- Description:	<Recupera el detalle del anticipo de gasto por id>
--TEST EXEC [Tramite].[Sp_Tramite_AnticipoGasto_GetPorId]  2338, 1, 'localhosts'
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_AnticipoGasto_GetPorId] 
	@idAnticipoGasto INT,
	@idTipoProceso INT,
	@urlParametro VARCHAR(80)
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	DECLARE @urlDoctos VARCHAR(100), @correosTesoreria varchar(max), @correosFinanzas varchar(max)
	DECLARE @parmetros TABLE (correosTesoreria VARCHAR(MAX))
	DECLARE @parmetros2 TABLE (correosFinanzas VARCHAR(MAX)) --parametrosGVEmailFinanzas

	IF(@urlParametro != '' AND @urlParametro = 'localhost') --localhost
	BEGIN
		SELECT @urlDoctos = pr_descripcion FROM [dbo].[parametros] WHERE pr_identificador = 'Url_Local_ADG'
	END
	ELSE IF(@urlParametro != '') 
	BEGIN
	--SET @urlDoctos = 'C:/app/public/Imagenes/AnticipoGastos/';   --'C:\\app\\public\\Imagenes\\AnticipoGastos\'
		SELECT 
					@urlDoctos = pr_descripcion --+ 'AnticipoGastos/'
				FROM parametros 
				WHERE pr_identificador = 'Url_Server_ADG'
	END

	insert into @parmetros
	EXEC [dbo].[OBTIENE_PARAMETROS_V2] 'parametrosGV'

	insert into @parmetros2
	EXEC [dbo].[OBTIENE_PARAMETROS_V2] 'parametrosGVEmailFinanzas'
	
	select @correosTesoreria = correosTesoreria from @parmetros
	select @correosFinanzas = correosFinanzas from @parmetros2

	
SELECT DISTINCT
  TD.id_perTra AS [idSolicitud]
 ,TD.traDe_fechaInicio AS [fechaInicio]
 ,TD.traDe_fechaFin AS [fechaFin]
 ,TD.concepto
 ,ET.esDe_IdEstatus AS [idEstatus]
 ,ET.esDe_descripcion AS [estatus]
 ,TD.traDe_Observaciones AS [observaciones]
 ,TD.motivo
 ,TD.nombreCliente
 ,ET.esDe_icono AS [icono]
 ,COALESCE(SUM(TTI.importe), 0) AS [importe]
 ,COALESCE([TD].[id_empresa], 0) AS [idCompania]
 ,COALESCE([TD].[id_sucursal], 0) AS [idSucursal]
 ,COALESCE([TD].[id_departamento], 0) AS [idDepartamento]
 ,CD.dep_nombrecto
 ,COALESCE(CE.emp_nombre, '') AS [empresa]
 ,COALESCE(CS.suc_nombre, '') AS [sucursal]
 ,COALESCE(CD.dep_nombre, '') AS [departamento]
 ,@urlDoctos AS urlServerDoctos
 ,(SELECT
      MIN(ISNULL(idSalidaEfectivo, 0))
    FROM [Tramite].[TramiteConcepto]
    WHERE idTramitePersona = TD.id_perTra
    AND idEstatus <> 3)
  AS Comprobar
 ,ISNULL(TD.PER_IDPERSONA, 0) AS PER_IDPERSONA
 ,@correosTesoreria AS correoTesoreria
 ,@correosFinanzas AS correosFinanzas
 ,TD.cuentaBancaria
 ,TD.numeroCLABE
 ,tec.idSalidaEfectivo
 ,ISNULL(ca.ca_banconombre, '') AS ca_banconombre
 ,ISNULL(ca.ca_clabe, '') AS ca_clabe
 ,ISNULL(ca.idCuentaAutorizada, 0) AS idCuentaAutorizada
 ,ISNULL(te.IdPersona, 0) AS idUsuarioAdicional
 ,ISNULL(te.nombreEmpleado, '') AS nombreEmpleadoAdicional
 ,cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno AS usuario
 ,MAX(kilometro) kilometro
 ,ISNULL(hp.activo, 0) AS valePresupuesto
 ,cus.usu_idusuario AS idUsuarioSolicitante
 ,cus.usu_correo AS correoSolicitante
 ,cdsg.descripcion as departamentoArea
FROM tramiteDevoluciones TD
INNER JOIN personaTramite PT
  ON PT.id_perTra = TD.id_perTra
LEFT JOIN cat_tramites T
  ON T.id_tramite = PT.id_tramite
INNER JOIN cat_proceso_estatus ET
  ON ET.esDe_IdEstatus = PT.petr_estatus
    AND ET.idTipoTramite = 9
LEFT JOIN [Tramite].[TramiteEmpleado] TE
  ON TD.id_perTra = TE.idTramiteDevolucion
LEFT JOIN [Tramite].[TramiteConcepto] TEC
  ON PT.id_perTra = TEC.idTramitePersona
LEFT JOIN [Tramite].[TramiteImporte] TTI
  ON TEC.idTramiteConcepto = TTI.idTramiteConcepto
    AND TTI.idTipoProceso = @idTipoProceso
LEFT JOIN [ControlAplicaciones].[dbo].[cat_empresas] CE
  ON [TD].[id_empresa] = CE.emp_idempresa
LEFT JOIN [ControlAplicaciones].[dbo].[cat_sucursales] CS
  ON CS.suc_idsucursal = [TD].[id_sucursal]
LEFT JOIN Tramites.Tramite.cat_Departamentos_Sucursal_GV cdsg
	ON TD.id_departamento = cdsg.idDepartamento
LEFT JOIN ControlAplicaciones.dbo.cat_departamentos CD
  ON CD.dep_iddepartamento = [TD].[id_departamento]
LEFT JOIN [Tramites].[dbo].[cuentaAutorizada] ca
  ON td.numeroCLABE = ca.ca_clabe
    AND ca.ca_estatus = 3
LEFT JOIN ControlAplicaciones..cat_usuarios cu
  ON pt.id_persona = cu.usu_idusuario
LEFT JOIN tramites.dbo.HistoricoPresupuestosGVAprobados hp
  ON TD.id_perTra = hp.idPerTra
    AND hp.activo = 1
LEFT JOIN tramites.dbo.usuariosGastosViaje gv
  ON CASE WHEN te.IdPersona IS NULL 
    THEN cu.usu_idusuario 
  ELSE te.IdPersona END =CASE WHEN te.IdPersona IS NULL 
                                THEN gv.idUsuario 
                                ELSE gv.idPersona end
LEFT JOIN ControlAplicaciones.dbo.cat_usuarios cus
  ON gv.idUsuario = cus.usu_idusuario
--  ON cus.usu_nombre + cus.usu_paterno + cus.usu_materno =
--    CASE
--      WHEN ISNULL(te.nombreEmpleado, '') <> '' THEN REPLACE(te.nombreEmpleado, ' ', '')
--      ELSE cu.usu_nombre + cu.usu_paterno + cu.usu_materno
--    END
WHERE TD.id_perTra = @idAnticipoGasto
GROUP BY TD.id_perTra
        ,TD.traDe_devTotal
        ,TD.traDe_fechaInicio
        ,TD.traDe_fechaFin
        ,TD.cuentaBancaria
        ,TD.numeroCLABE
        ,TD.concepto
        ,ET.esDe_IdEstatus
        ,ET.esDe_descripcion
        ,TD.traDe_Observaciones
        ,TD.motivo
        ,[TD].[id_empresa]
        ,[TD].[id_sucursal]
        ,[TD].[id_departamento]
        ,CE.emp_nombre
        ,CS.suc_nombre
        ,CD.dep_nombre
        ,TD.nombreCliente
        ,ET.esDe_icono
        ,CD.dep_nombrecto
        ,TD.PER_IDPERSONA
        ,tec.idSalidaEfectivo
        ,ca.ca_banconombre
        ,ca.ca_clabe
        ,ca.idCuentaAutorizada
        ,te.nombreEmpleado
        ,cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
        ,te.IdPersona
        ,hp.activo
        ,cus.usu_idusuario
        ,cus.usu_correo
		,cdsg.descripcion
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

