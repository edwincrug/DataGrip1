-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Bitacora].[Sp_Tramites_ConsultaValesVencidos_GETL]
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    	DECLARE 
		@fecha DATETIME
		,@destinatarioContraloria VARCHAR(MAX)
		,@destinatarioNomina VARCHAR(MAX)
		,@destinatarioFinanzas VARCHAR(MAX)
		,@asunto VARCHAR(255)
		,@idBancoDestino INT
		,@idBancoOrigen INT
		,@idOrigenReferencia INT
		,@minutos INT
		,@inInicio INT = 1
		,@inFinal INT = 0

	DECLARE 
		@fechaIni DATETIME
		,@horaI INT = 0
		,@horaF INT = 24
		,@fechaActual DATETIME = GETDATE()
		,@escalamiento BIT = 0
		,@fechaInFinal datetime
		,@fechaNextDay datetime
		,@fechaNextDayFinal datetime

	DECLARE 
		@iDia DATETIME = CONVERT(VARCHAR(10), @fechaActual, 112)
		,@fDia DATETIME = CONVERT(VARCHAR(10), @fechaActual, 112)


	DECLARE @parametros TABLE (
		asunto VARCHAR(250)
		,destinatarioContraloria VARCHAR(MAX)
		,destinatarioFinanzas VARCHAR(MAX)
		,destinatarioNomina VARCHAR(MAX)
		,idBancoDestino INT
		,idBancoOrigen INT
		,idEmpresa INT
		,idOrigenReferencia INT
		,idSucursal INT
		,tiempoParaComprobar INT
	)

	DECLARE @PorProcesar TABLE (
		id INT
		,idEmpresa INT
		,idsucursal INT
		,idDepartamento INT
		,idVale VARCHAR(100)
		,PER_IDPERSONA INT
		,rfc VARCHAR(15)
		,NOMBRE VARCHAR(150)
		,mail VARCHAR(150)
		,montoSolicitado DECIMAL(18, 2)
		,montoJustificado DECIMAL(18, 2)
		,porJustificar DECIMAL(18, 2)
		,destinatarioContraloria VARCHAR(MAX)
		,destinatarioNomina VARCHAR(MAX)
		,destinatarioFinanzas VARCHAR(MAX)
		,asunto VARCHAR(255)
		,idBancoDestino INT
		,idBancoOrigen INT
		,idOrigenReferencia INT
		,idUsuario INT
		,fechaComprobacion DATETIME
		,id_perTra INT
		,HorasTranscurridas NUMERIC(5,2)
		,tiempoParaComprobar INT
	)

	DECLARE @ValeCencido TABLE(
		IdValeVencido int IDENTITY(1,1) PRIMARY KEY,
		id INT
	)


	INSERT INTO @parametros
	EXEC [OBTIENE_PARAMETROS_V2] 'FFValidaTiempoComprobante'


	SELECT
	@destinatarioContraloria = destinatarioContraloria
	,@destinatarioNomina = destinatarioNomina
	,@destinatarioFinanzas = destinatarioFinanzas
	,@asunto = asunto
	,@idBancoDestino = idBancoDestino
	,@idBancoOrigen = idBancoOrigen
	,@idOrigenReferencia = idOrigenReferencia
	FROM @parametros


	INSERT INTO @PorProcesar
	SELECT distinct
		v.id
		,f.idEmpresa
		,f.idSucursal
		,f.idDepartamento
		,idVale
		,v.PER_IDPERSONA
		,rfc = pp.PER_RFC
		,NOMBRE = pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO
		,mail = cu.usu_correo
		,montoSolicitado
		,montoJustificado
		,porJustificar =
			CASE
				WHEN (montoSolicitado - montoJustificado) < 0 THEN 0
				ELSE (montoSolicitado - montoJustificado)
			END
		,destinatarioContraloria = pa.destinatarioContraloria
		,destinatarioNomina = pa.destinatarioNomina
		,destinatarioFinanzas = pa.destinatarioFinanzas
		,asunto = @asunto
		,idBancoDestino = @idBancoDestino
		,idBancoOrigen = @idBancoOrigen
		,idOrigenReferencia = @idOrigenReferencia
		,f.idResponsable
		,fechaComprobacion = 
			CASE 
				WHEN v.fechaRechazoVale IS NULL THEN  
					v.fechaEntregaEfectivo 
				ELSE 
					v.fechaRechazoVale 
			END
		,f.id_perTra
		,HorasTranscurridas = 
			CASE 
				WHEN v.fechaRechazoVale IS NULL THEN  
					[dbo].[Fn_Tramites_ValeVencido_CalculaHoras]( v.fechaEntregaEfectivo, NULL )
				ELSE 
					[dbo].[Fn_Tramites_ValeVencido_CalculaHoras]( v.fechaRechazoVale, NULL ) 
			END
		, pa.tiempoParaComprobar
	FROM tramite.vales v
	JOIN GA_Corporativa.dbo.PER_PERSONAS pp ON v.PER_IDPERSONA = pp.PER_IDPERSONA
	JOIN tramite.valesFondoFijo ff ON ff.idVales = v.id
	JOIN tramite.fondoFijo f ON ff.idTablaFondoFijo = f.id
	LEFT JOIN ControlAplicaciones..cat_usuarios cu ON v.idEmpleado = cu.usu_idusuario
	LEFT JOIN @parametros pa ON cu.emp_idempresa = pa.idEmpresa AND cu.suc_idsucursal = pa.idSucursal
	WHERE 
		fechaEntregaEfectivo IS NOT NULL
		AND (montoSolicitado - montoJustificado) > 0
		AND descuentoSolicitado = 0
	ORDER BY v.id DESC

	SELECT * FROM @PorProcesar ORDER BY id
END
go

