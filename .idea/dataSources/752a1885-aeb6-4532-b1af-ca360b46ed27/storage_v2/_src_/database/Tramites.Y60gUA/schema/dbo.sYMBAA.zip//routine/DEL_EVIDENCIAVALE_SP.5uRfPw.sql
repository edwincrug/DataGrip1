-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <30/10/2019>
-- Description:	<SP que elimina la evidencia>
-- [dbo].[DEL_EVIDENCIAVALE_SP]  85
-- =============================================
CREATE PROCEDURE [dbo].[DEL_EVIDENCIAVALE_SP] 
	@idValeEvidencia INT
AS
BEGIN
	
	DELETE FROM Tramite.valesEvidencia 
	WHERE id = @idValeEvidencia

	SELECT success = 1, msg = 'Se elimino correctamente';

END
go

