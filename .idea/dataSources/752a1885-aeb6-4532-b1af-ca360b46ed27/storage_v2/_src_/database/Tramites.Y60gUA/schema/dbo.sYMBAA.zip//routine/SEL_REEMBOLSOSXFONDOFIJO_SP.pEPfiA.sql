-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 02/09/2020
-- Description:	SP para obtener los reembolsos x fondo
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REEMBOLSOSXFONDOFIJO_SP] 
	@idfondoFijo INT
AS

BEGIN
	
select distinct 
ve.id_pertraReembolso as idReembolso, 
d.traDe_devTotal as monto, 
CONVERT(varchar, pt.petr_fechaTramite, 103) as fecha
from tramite.fondofijo ff
inner join Tramites.Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join Tramites.Tramite.vales v on v.id = vff.idVales
inner join Tramites.Tramite.valesEvidencia ve on ve.idVales = v.id 
inner join Tramites.dbo.tramiteDevoluciones d on d.id_perTra = ve.id_pertraReembolso
inner join tramites.dbo.personatramite pt on pt.id_perTra =  d.id_perTra
where ff.id = @idfondoFijo and ve.id_pertraReembolso is not null

END

go

