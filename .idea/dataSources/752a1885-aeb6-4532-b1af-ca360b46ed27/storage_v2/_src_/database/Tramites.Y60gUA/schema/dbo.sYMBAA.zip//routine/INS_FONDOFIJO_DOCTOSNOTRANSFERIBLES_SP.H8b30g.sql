-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <31/01/2020>
-- Description:	<Inserta la poliza>
-- [dbo].[INS_FONDOFIJO_DOCTOSNOTRANSFERIBLES_SP] 
-- =============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_DOCTOSNOTRANSFERIBLES_SP] 
@idSucursal INT, 
@proceso varchar(60),
@documento varchar(60),
@id_perTra INT
AS
BEGIN

DECLARE @idEmpresa INT,
		@nombreBD VARCHAR(100),
		@persona1 INT


select @idEmpresa = emp_idempresa from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idSucursal
 
select @nombreBD = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_idempresa = @idEmpresa

select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra


DECLARE @doctosNoTransferibles NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[cxp_doctosnotransferibles]
	  ([DNT_IDEMPRESA]
      ,[DNT_IDSUCURSAL]
      ,[DNT_PROCESO]
      ,[DNT_DOCUMENTO]
      ,[DNT_IDPERSONA]
      ,[DNT_FECHAINSERCION])
	  VALUES
	  ('''+ CONVERT(VARCHAR(10),@idEmpresa)+'''
	  ,'''+ CONVERT(VARCHAR(10),@idSucursal)+'''
	  ,'''+@proceso+'''
	  ,'''+@documento+'''
	  ,'''+ CONVERT(VARCHAR(10),@persona1)+'''
	  ,GETDATE())'

exec(@doctosNoTransferibles)
--print @doctosNoTransferibles

END
go

