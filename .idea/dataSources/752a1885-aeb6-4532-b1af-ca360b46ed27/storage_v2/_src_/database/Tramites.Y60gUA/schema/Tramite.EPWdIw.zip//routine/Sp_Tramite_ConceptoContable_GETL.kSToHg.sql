-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <27/08/2019>
-- Description:	<Recupera los conceptos contables>
--TEST EXEC [Tramite].[Sp_Tramite_ConceptoContable_GETL]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ConceptoContable_GETL] 
	@idEmpleado INT = null,
	@nombreEmpleado VARCHAR(50),
	@idTramiteDevolucion INT	
AS
BEGIN 
SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	SELECT 
		[idConceptoContable]
		,[concepto]
		,[importeMaximo]
		,[estatus]
	FROM [Tramite].[ConceptoContable]

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

