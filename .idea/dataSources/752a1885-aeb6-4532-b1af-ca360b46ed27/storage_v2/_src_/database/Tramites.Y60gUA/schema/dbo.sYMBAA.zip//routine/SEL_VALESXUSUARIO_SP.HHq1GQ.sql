
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/10/2019>
-- Description:	<SP que trae los datos de los vales x usuario>
-- [SEL_VALESXUSUARIO_SP]   1993
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALESXUSUARIO_SP] 
	@idusuario INT
AS
BEGIN
	 DECLARE @idtipoUsuario INT;
	select @idtipoUsuario = idUsuariosFondoFijo from Tramite.UsuariosFondoFijo where idUsuario = @idusuario
	--DECLARE @url varchar(max)
	--select @url = pr_descripcion from parametros where pr_identificador = 'RUTA_SAVE_LOC'


IF(@idtipoUsuario = 4)
	BEGIN
SELECT
 V.id as idVale,
 V.idVale as nombreVale,
 FF.id,
 FF.idFondoFijo,
 CONVERT(varchar, V.fechaCreacionVale, 103) as fechaCreacion,
 V.estatusVale,
 EV.descripcion as estatus,
 V.idGastosFondoFijo as idtipotramite,
 V.montoSolicitado,
 V.descripcion,
 GFF.descripcion as tipoTramite,
  FF.id_perTra,
 (select pr_descripcion from [dbo].[parametros] where pr_identificador = 'RUTA_SAVE_LOC') as saveUrl,
 --'C:/app/public/Imagenes/' as saveUrl,
 V.comentario,
 V.idAutorizador,
  D.dep_nombre as departamento,
 U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno as solicitante
   ,FF.idSucursal
  ,FF.idEmpresa
  ,E.emp_nombre as nombreEmpresa
 FROM Tramite.vales V
INNER JOIN Tramite.valesFondoFijo VF ON VF.idVales = V.id
INNER JOIN Tramite.fondoFijo FF ON FF.id = VF.idTablaFondoFijo
INNER JOIN [Tramite].[cat_estatusVale] EV ON EV.id = V.estatusVale
LEFT JOIN [Tramite].[cat_gastosFondoFijo] GFF ON V.idGastosFondoFijo = GFF.id
INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] D ON D.dep_iddepartamento = FF.idDepartamento
INNER JOIN [ControlAplicaciones].[dbo].cat_empresas E ON E.emp_idempresa = FF.idEmpresa
INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = V.idEmpleado
ORDER BY V.id desc
END
ELSE
BEGIN
SELECT
 V.id as idVale,
 V.idVale as nombreVale,
 FF.id,
 FF.idFondoFijo,
 FF.id_perTra,
 CONVERT(varchar, V.fechaCreacionVale, 103) as fechaCreacion,
 V.estatusVale,
 EV.descripcion as estatus,
 V.idGastosFondoFijo as idtipotramite,
 V.montoSolicitado,
 V.descripcion,
 GFF.descripcion as tipoTramite,
 D.dep_nombre as departamento,
 U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno as solicitante,
 V.comentario,
 (select pr_descripcion from [dbo].[parametros] where pr_identificador = 'RUTA_SAVE_LOC') as saveUrl,
 --'C:/app/public/Imagenes/' as saveUrl,
  V.idAutorizador
  ,FF.idSucursal
  ,FF.idEmpresa
  ,E.emp_nombre as nombreEmpresa
 FROM Tramite.vales V
INNER JOIN Tramite.valesFondoFijo VF ON VF.idVales = V.id
INNER JOIN Tramite.fondoFijo FF ON FF.id = VF.idTablaFondoFijo
INNER JOIN [Tramite].[cat_estatusVale] EV ON EV.id = V.estatusVale
LEFT JOIN [Tramite].[cat_gastosFondoFijo] GFF ON V.idGastosFondoFijo = GFF.id
INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] D ON D.dep_iddepartamento = FF.idDepartamento
INNER JOIN [ControlAplicaciones].[dbo].cat_empresas E ON E.emp_idempresa = FF.idEmpresa
INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = V.idEmpleado
WHERE V.idEmpleado = @idusuario
ORDER BY V.id desc
END


END

go

