-- =============================================
-- Author:		<Luis García>
-- Create date: <09/07/2019>
-- Description:	<SP que trae los datos del tramite borrador>
-- TEST SEL_DEV_BORRADOR_SP 1332
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEV_BORRADOR_SP] 
	@idPerTra INT
AS
BEGIN
	SELECT 
		PT.id_perTra,
		PT.id_tramite,
		PT.petr_estatus,
		ISNULL(TD.traDe_Observaciones,'') AS observaciones,
		TD.id_traDe,
		TD.id_formaPago,
		TD.id_departamento,
		TD.id_empresa,
		TD.id_sucursal,
		E.est_nombre,
		ISNULL(PT.petr_observaciones, '') AS observacionesTramite,
		TD.traDe_devTotal AS devTotal,
		TD.traDe_fechaInicio AS fechaInicio,
		TD.traDe_fechaFin AS fechaFin,
		TD.PER_IDPERSONA AS persona,
		TD.esDe_idEstatus AS estatusDevolucion,
		TD.cuentaBancaria,
		ISNULL(TD.numeroCLABE,'') AS numeroCLABE,
		ISNULL(TD.cveBanxico,'') AS cveBanxico,
		ISNULL(TD.tipoCuentaBancaria,'') as tipoCuentaBancaria,
		TD.esDe_IdEstatus,
		ISNULL(TD.origenBpro,0) origenBpro,
		PE.orden
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN estatusTramites E ON E.id_estatus = PT.petr_estatus
	INNER JOIN cat_proceso_estatus AS PE ON PE.esDe_IdEstatus = TD.esDe_IdEstatus AND PT.id_tramite = PE.idTipoTramite
	WHERE PT.id_perTra = @idPerTra

END
go

