-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <27/08/2019>
-- Description:	<Inserta la relación del concepto con el tramite>
--TEST EXEC [Tramite].[Sp_Tramite_EmpleadoConcepto_INS]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_EmpleadoConcepto_INS] 
	@importe DECIMAL(18, 2),
	@idTramiteEmpleado INT,
	@idConceptoContable INT,
	@idPaso TINYINT
AS
BEGIN 
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	IF(@idPaso = 1) BEGIN

		INSERT INTO [Tramite].[TramiteEmpleadoConcepto] 
		(
			importeSolicitado
			,fechaRegistro
			,estatus
			,idTramiteEmpleado
			,idConceptoContable
		)
		VALUES
		(
			@importe
			,GETDATE()
			,1
			,@idTramiteEmpleado
			,@idConceptoContable
		)
	END



	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

