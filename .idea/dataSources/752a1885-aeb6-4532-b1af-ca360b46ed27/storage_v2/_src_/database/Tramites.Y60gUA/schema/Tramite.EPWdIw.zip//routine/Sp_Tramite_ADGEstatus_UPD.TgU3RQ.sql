-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <09/09/2019>
-- Description:	<Actualiza estatus a solicitud de saldo>
--TEST EXEC [Tramite].[Sp_Tramite_ADGEstatus_UPD] 967, 3
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ADGEstatus_UPD] 
	@idSolicitud INT,
	@idTipoProceso INT
AS
BEGIN 

	SET NOCOUNT ON;
DECLARE
    @VI_ZERO INT = 0 ,@VC_ErrorMessage NVARCHAR(4000) = '' ,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_ADGEstatus_UPD] :' ,@VI_ErrorSeverity INT = 0 ,@VI_ErrorState INT = 0 ,@VI_CountResult INT = 0
BEGIN
    TRY
    BEGIN
        TRANSACTION TrnxInsTramite
        IF(@idTipoProceso = 1)
            BEGIN
                UPDATE [dbo].[personaTramite] SET petr_estatus = 1 WHERE id_perTra = @idSolicitud
                UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = 1 WHERE id_perTra = @idSolicitud
                UPDATE [Tramite].[TramiteConcepto] SET idEstatus = 1 WHERE idTramitePersona = @idSolicitud AND idEstatus = 0
                SET @VI_CountResult  = 1
			END 
		 IF(@idTipoProceso = 2) 
			BEGIN
                UPDATE [dbo].[personaTramite] SET petr_estatus = 7 WHERE id_perTra = @idSolicitud 
                UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = 7 WHERE id_perTra = @idSolicitud
                UPDATE [Tramite].[TramiteConcepto] SET idEstatus = 7 WHERE idTramitePersona = @idSolicitud
                       AND idEstatus    = 2
                SET @VI_CountResult  = 1
			END
		 IF(@idTipoProceso = 3) 
		 BEGIN 
			IF EXISTS(select TOP 1 idReferencia from [Tramite].[ConceptoArchivo] where idReferencia = @idSolicitud)
				BEGIN
		 			UPDATE [dbo].[personaTramite] SET petr_estatus = 8 WHERE id_perTra = @idSolicitud
					UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = 8 WHERE id_perTra = @idSolicitud
					UPDATE [Tramite].[TramiteConcepto] SET idEstatus = 8 WHERE idTramitePersona = @idSolicitud AND idEstatus = 7
					UPDATE CA SET CA.idEstatus = 8
					FROM [Tramite].[ConceptoArchivo] CA
					INNER JOIN [Tramite].[TramiteConcepto] TC ON CA.idReferencia = TC.idTramiteConcepto
					WHERE TC.idTramitePersona = @idSolicitud AND CA.idEstatus = 7
					SET    @VI_CountResult  = 1
				END
			ELSE
				BEGIN
					IF EXISTS (SELECT TOP 1 TC.idTramiteConcepto
							FROM [Tramite].[TramiteConcepto] TC
                            INNER JOIN [Tramite].[TramiteImporte] TI ON TC.idTramiteConcepto = TI.idTramiteConcepto
							WHERE idTramitePersona = @idSolicitud 
							GROUP BY TC.idTramiteConcepto
							 HAVING COALESCE(SUM(TI.importe), 0) = 0)
						BEGIN
							SET    @VI_CountResult = -3
						END 
					ELSE IF EXISTS (SELECT TOP 1 TC.idTramiteConcepto
							FROM [Tramite].[TramiteConcepto] TC
                            LEFT JOIN [Tramite].[ConceptoArchivo] CA ON TC.idTramiteConcepto = CA.idReferencia
							WHERE idTramitePersona = @idSolicitud AND CA.idReferencia IS NULL AND TC.idEstatus <>3)
						BEGIN
							SET    @VI_CountResult = -2
						END 
					ELSE IF EXISTS (SELECT CA.idConceptoArchivo, CA.nombre, COALESCE(SUM(AD.porcentaje), 0) AS porcentaje 
							FROM [Tramite].[TramiteConcepto] TC
                            INNER JOIN [Tramite].[ConceptoArchivo] CA ON TC.idTramiteConcepto = CA.idReferencia
                            LEFT JOIN [Tramite].[ArchivoDepartamento] AD ON CA.idConceptoArchivo = AD.idConceptoArchivo
							WHERE idTramitePersona = @idSolicitud AND CA.extension = 'xml'
							GROUP BY CA.idConceptoArchivo, CA.nombre
							HAVING COALESCE(SUM(AD.porcentaje), 0) != 100)
						BEGIN
							SET    @VI_CountResult = -1
						END 
					ELSE IF( ( SELECT [Tramite].[Fn_Tramite_GDM_NotiEnviadas](@idSolicitud)  ) = 1)
						BEGIN
							SET    @VI_CountResult = -4
						END 
				ELSE 
					BEGIN
						UPDATE [dbo].[personaTramite] SET petr_estatus = 8 WHERE id_perTra = @idSolicitud
						UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = 8 WHERE id_perTra = @idSolicitud
						UPDATE [Tramite].[TramiteConcepto] SET idEstatus = 8 WHERE idTramitePersona = @idSolicitud AND idEstatus = 7
						--UPDATE CA SET CA.idEstatus = 8 
						--FROM [Tramite].[TramiteConcepto] TC
						--	INNER JOIN [Tramite].[ConceptoArchivo] CA ON TC.idTramiteConcepto = CA.idReferencia
						--	WHERE CA.idConceptoArchivo = @idSolicitud
						UPDATE CA SET CA.idEstatus = 8
						FROM [Tramite].[ConceptoArchivo] CA
						INNER JOIN [Tramite].[TramiteConcepto] TC ON CA.idReferencia = TC.idTramiteConcepto
						WHERE TC.idTramitePersona = @idSolicitud AND CA.idEstatus = 7
						SET    @VI_CountResult  = 1
					END
		END
		END COMMIT TRANSACTION TrnxInsTramite
		END TRY BEGIN CATCH
						SELECT
							   @VC_ErrorMessage  = ERROR_MESSAGE()
							 , @VI_ErrorSeverity = ERROR_SEVERITY()
							 , @VI_ErrorState    = ERROR_STATE()
						;
                
						IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
							BEGIN
								ROLLBACK TRANSACTION TrnxInsTramite
								SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
							END
						END CATCH
						SET NOCOUNT OFF
						SELECT
							   @VI_CountResult AS [resultado]
		END
go

