
-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 17/06/2019
-- Description:	SP que aprueba el tramite

-- TEST [UPD_FONDO_APROBAR_RECHAZAR_TRAMITE_SP] 245, 3, ''
-- =============================================
CREATE PROCEDURE [dbo].[UPD_FONDO_APROBAR_RECHAZAR_TRAMITE_SP]
	@id_perTra INT,
	@estatus INT,
	@observaciones VARCHAR(500)
AS
BEGIN
	DECLARE @idTraDe INT = 0,  @idTramite INT;
	
	SELECT 
		@idTraDe = id_traDe 
	FROM tramiteDevoluciones WHERE id_perTra = @id_perTra;

	UPDATE personaTramite
	SET petr_estatus = @estatus,
	petr_observaciones = @observaciones
	WHERE id_perTra = @id_perTra

	UPDATE tramiteDevoluciones
	SET traDe_fechaAutoriza = GETDATE(), esDe_IdEstatus = 6
	WHERE id_perTra = @id_perTra;

	IF( @estatus = 6 )
		BEGIN
			UPDATE documentosDevueltos SET docDe_valorDev = 0.00 WHERE id_traDe = @idTraDe
		END

	SELECT success = 1;

END

go

