
-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 13/04/2020
-- Description:	SP que aprueba el tramite
-- TEST [UPD_FONDO_APROBAR_RECHAZAR_TRAMITEAD_SP] 245, 3, ''
-- =============================================
CREATE PROCEDURE [dbo].[UPD_FONDO_APROBAR_RECHAZAR_TRAMITEAD_SP]
	@id_perTra INT,
	@estatus INT,
	@observaciones VARCHAR(500)
AS
BEGIN
	DECLARE @idFF INT = 0;
	
	select 
	@idFF = id
	from tramite.fondofijo where id_perTra = @id_perTra

	UPDATE personaTramite
	SET petr_estatus = 2,
	petr_observaciones = @observaciones
	WHERE id_perTra = @id_perTra

	UPDATE tramiteDevoluciones
	SET traDe_fechaAutoriza = GETDATE(), esDe_IdEstatus = 3
	WHERE id_perTra = @id_perTra;

	UPDATE ffc
	SET ffc.estatus = 2
	from Tramites.Tramite.fondofijo  ff
	inner join Tramites.Tramite.fondoFijoCambios ffc on ffc.id = ff.AumentoDisminucion
	where ff.id_perTra = @id_perTra


	SELECT success = 1;

END
go

