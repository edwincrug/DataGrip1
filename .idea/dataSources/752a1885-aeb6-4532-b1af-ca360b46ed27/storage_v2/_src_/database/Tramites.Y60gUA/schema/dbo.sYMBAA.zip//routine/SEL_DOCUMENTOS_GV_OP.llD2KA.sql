-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: <Create Date,,>
-- Description:	OBTIENE LA LISTA DE DOCUMENTOS QUE SE VAN A MOSTRAR EN LA ORDEN DE COMPRA DE GASTOS DE VIAJE
-- SEL_DOCUMENTOS_GV_OP 'localhost', 2584
-- =============================================
create PROCEDURE SEL_DOCUMENTOS_GV_OP
	-- Add the parameters for the stored procedure here
	@urlParam VARCHAR(30)
	,@idPerTra INT 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE 
  @url VARCHAR(500)
  ,@idUsuario INT
  ,@idUsuarioAdicional INT
  ,@nombreDocto varchar(255)
  ,@id_documento int
    ,@estatus int


	IF(@urlParam = 'localhost')
	BEGIN
		SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam);
	END
	ELSE
	BEGIN
		SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');		
	END

	DECLARE @saveUrl VARCHAR(100) = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC');

	--SELECT * FROM Tramites.dbo.tramiteDevoluciones d WHERE d.id_perTra = @idPerTra
	SELECT @idUsuario = gv.idPersona,@estatus = t.petr_estatus 
	  FROM tramites.dbo.personaTramite t
	  join tramites..usuariosGastosViaje gv
	  on t.id_persona = gv.idUsuario
	  WHERE t.id_perTra = @idPerTra

	SELECT @idUsuarioAdicional = gv.idPersona
	  FROM Tramites.Tramite.TramiteEmpleado te
	  JOIN Tramites.dbo.usuariosGastosViaje gv
	  ON te.IdPersona = gv.idPersona
	  WHERE te.idTramiteDevolucion = @idPerTra

	SELECT @nombreDocto = cd.doc_nomDocumento ,@id_documento = cd.id_documento FROM Tramites.dbo.cat_documentos cd WHERE cd.id_documento = 4

	  SELECT @urlParam AS urlParam
	  ,@idPerTra AS det_idPerTra
	  ,@url+'DocumentosGV/Persona_'+ CASE WHEN @idUsuarioAdicional IS NULL THEN CAST(@idUsuario AS VARCHAR(10)) ELSE CAST(@idUsuarioAdicional AS VARCHAR(10)) END + '/4_comprobacion.pdf'
	 AS url
	  ,@saveUrl+'DocumentosGV/Persona_'+ CASE WHEN @idUsuarioAdicional IS NULL THEN CAST(@idUsuario AS VARCHAR(10)) ELSE CAST(@idUsuarioAdicional AS VARCHAR(10)) END + '/4_comprobacion.pdf' AS saveUrl
	  ,@idUsuario AS idUsuario
	  ,@idUsuarioAdicional AS usuarioAdicional
	  ,@nombreDocto as doc_nomDocumento
	  ,@id_documento as id_documento
	  ,@estatus as estatusTramite
	  ,2 AS idExtension

END
go

