-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--VALIDA_CONCEPTO_LEY_DEDUCIBILIDAD 45, 50
-- =============================================
CREATE PROCEDURE [dbo].[VALIDA_CONCEPTO_LEY_DEDUCIBILIDAD] 
	@idConcepto  int
	,@kilometros int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    declare @Parametros table (idConcepto int, kilometrosMinimos int)
	declare @kilometrosMinimos int

	insert into @Parametros
	exec OBTIENE_PARAMETROS_V2 'LeyDeducibilidad'

	select @kilometrosMinimos = kilometrosMinimos 
	from @Parametros
	where idConcepto = @idConcepto

	if exists (select 1 from @Parametros where idConcepto = @idConcepto)
	begin
		if (@kilometros >= @kilometrosMinimos)
		begin
			select 1 as estatus, 'El concepto es viable' as mensaje 
		end
		else
		begin
			select 0 as estatus, 'La distancia mínima para el concepto seleccionado debe de ser de '+cast(@kilometrosMinimos as varchar(10)) + ' kilómetros' as mensaje
		end
	end
	else
	begin
		select 1 as estatus, 'El concepto es viable' as mensaje
	end

END
go

