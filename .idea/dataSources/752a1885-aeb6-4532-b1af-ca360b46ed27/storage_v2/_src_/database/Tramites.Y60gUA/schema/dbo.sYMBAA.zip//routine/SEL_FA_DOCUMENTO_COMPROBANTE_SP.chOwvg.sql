
-- =============================================
-- Author:		<JCPS>
-- Create date: <13/02/2020>
-- Description:	<Trae los documentos que éxisten y los que no éxisten>
--TEST [dbo].[SEL_FA_DOCUMENTO_COMPROBANTE_SP]  'localhost', 1101, 10,'FS', '5'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FA_DOCUMENTO_COMPROBANTE_SP] @urlParam VARCHAR(30),
@idPerTra INT,
@idTramite INT,
@tipo VARCHAR(50),
@consecutivoTramite VARCHAR(5)
AS
BEGIN

  DECLARE @url VARCHAR(500);
  IF (@urlParam = 'localhost')
  BEGIN
    SET @url = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = @urlParam);
  END
  ELSE
  BEGIN
    SET @url = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = 'GET_SERVER');
  END

	DECLARE @saveUrl VARCHAR(100)
  --DECLARE @saveUrl VARCHAR(100) = (SELECT
  --    pr_descripcion
  --  FROM parametros
  --  WHERE pr_identificador = 'Url_Local_ADG');--RUTA_SAVE_LOC
  DECLARE @tramite VARCHAR(100)
  IF (@idTramite = 10)
  BEGIN
    SET @tramite = 'FondoFijo'
    SET @saveUrl = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = 'RUTA_SAVE_LOC');
  END
  ELSE
  BEGIN
    SET @tramite = 'AnticipoGastos'
	SET @saveUrl = (SELECT
      pr_descripcion
    FROM parametros
    WHERE pr_identificador = 'Url_Local_ADG');--RUTA_SAVE_LOC
  END

  SELECT
    id_tramite
   ,B.id_perTra
   ,doc_nomDocumento AS nombreDoc
   ,doc_nomDocumento
   ,A.ext_nombre
   ,A.id_traDo
   ,id_documento
   ,ISNULL(b.existe, 0) existe
   ,ISNULL(det_observaciobes, '') Observaciones
   ,det_estatus estatusDocumento
   ,petr_estatus estatusTramite
   ,A.doc_infoAdicional
   ,A.doc_expira
   --,@url + 'Comprobaciones/comprobacion/' + 'Comprobacion_' + isnull(CONVERT(VARCHAR(20), b.id_perTra),'') + '/' + isnull(CONVERT(VARCHAR(10), a.id_documento),0) + '_comprobacion' + +'.' + A.ext_nombre [rutaDocumento] ----RAN
   ,@url + @tramite + '/' + @tramite + '_' + CONVERT(VARCHAR(20), id_perTra) + '/Documento_' + CONVERT(VARCHAR(10), id_documento) + '_' + @tipo + '-' + @consecutivoTramite + '.' + A.ext_nombre [rutaDocumento] --ORIGINAL
   ,@url + @tramite + '/' + @tramite + '_' + CONVERT(VARCHAR(20),id_perTra) + '/Documento_' + CONVERT(VARCHAR(10),id_documento)+'_'+ @tipo +'-'+ @consecutivoTramite +'.'+A.ext_nombre [url]	--ORIGINAL
   --,@url + 'Comprobaciones/comprobacion/' + 'Comprobacion_' + isnull(CONVERT(VARCHAR(20), b.id_perTra),'') + '/' + isnull(CONVERT(VARCHAR(10), a.id_documento),0) + '_comprobacion' + +'.' + A.ext_nombre [url]  ----RAN
   ,A.id_extension AS idExtension
   ,B.det_idPerTra
   ,@saveUrl saveUrl
   ,A.opcional
  FROM (SELECT
      T.id_tramite
     ,doc_nomDocumento
     ,TD.id_traDo
     ,TD.id_documento
     ,EXT.ext_nombre
     ,DOC.doc_infoAdicional
     ,doc_expira
     ,EXT.id_extension
     ,DOC.opcional
    FROM cat_tramites T
    INNER JOIN cat_tramiteDocumento TD
      ON TD.id_tramite = T.id_tramite
    INNER JOIN cat_documentos DOC
      ON DOC.id_documento = TD.id_documento
    INNER JOIN cat_extensiones EXT
      ON EXT.id_extension = DOC.id_extension
    WHERE T.id_tramite = @idTramite
   AND DOC.id_documento = 65
  ) AS A
  LEFT JOIN (SELECT
      id_tramite existe
     ,DPT.id_traDo
     ,DPT.det_observaciobes
     ,det_estatus
     ,petr_estatus
     ,PT.id_perTra
     ,DPT.det_idPerTra
    FROM [personaTramite] PT
    INNER JOIN [dbo].[detallePersonaTramite] DPT
      ON DPT.id_perTra = PT.id_perTra
    WHERE PT.id_perTra = @idPerTra) AS B
    ON B.Existe = A.id_tramite
      AND B.id_traDo = A.id_traDo
      AND B.det_observaciobes = @tipo + '-' + @consecutivoTramite
END
go

