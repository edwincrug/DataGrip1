-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATA_ORDEN_PAGO_FF_V1_SP]  
	@idPerTra INT,
	@tipoProceso INT = 0,
	@consecutivoTramite INT = 0
AS
BEGIN
	 
		DECLARE @id_perTraFF INT
		select top 1 @id_perTraFF = ff.id_perTra from Tramite.valesEvidencia ve
		inner join Tramite.vales v on v.id = ve.idVales
		inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
		inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
		where ve.id_perTraReembolso = @idPerTra 
		
		SELECT 
		TD.id_perTra,
		TD.id_traDe,
		CT.monto as traDe_devTotal,
		TD.id_empresa,
		TD.id_sucursal,
		TD.id_departamento,
		TD.PER_IDPERSONA,
		FFSE.idBancoSalida as efectivoBanco,
		FFSE.numCuentaSalida as efectivoCuenta,
		CT.estatus,
		'FR' as identificador,
		FF.cuentaContable,
		FFSE.cuentaContableSalida,
		FF.idFondoFijo,
		D.dep_nombrecto,
		U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno as cajero,
		U.usu_correo as correo
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN Tramite.fondofijo FF ON FF.id_perTra = TD.id_perTra
	INNER JOIN Tramite.fondoFijoReembolso FFSE ON FFSE.idFondoFijo = FF.id  and FFSE.id = @consecutivoTramite
	INNER JOIN cuentasTesoreriaFA CT ON CT.id_perTra = @idPerTra  and CT.tipo = 2 and CT.consecutivo = @consecutivoTramite
	INNER JOIN ControlAplicaciones.dbo.cat_departamentos D on D.dep_iddepartamento = TD.id_departamento
	INNER JOIN ControlAplicaciones.dbo.cat_usuarios U on U.usu_idusuario = FF.idResponsable
	WHERE PT.id_perTra =  @id_perTraFF
	
END


go

