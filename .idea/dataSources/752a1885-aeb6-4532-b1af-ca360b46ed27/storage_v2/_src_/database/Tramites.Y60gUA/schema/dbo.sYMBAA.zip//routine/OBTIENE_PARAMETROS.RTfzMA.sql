-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: <Create Date,,>
-- Description:	OBTIENE LOS PARAMETROS DE LA TABLA SOLICITADA
-- [dbo].[OBTIENE_PARAMETROS] 'FFValidaTiempoComprobante'
-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_PARAMETROS] 
	@tabla VARCHAR(150)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @cols NVARCHAR(MAX)
       ,@query NVARCHAR(MAX);
	SET @cols = STUFF((SELECT DISTINCT
		',' + QUOTENAME(c.nombreColumna)
	  FROM [dbo].parametrizacion c
	  WHERE nombreTabla = @tabla
	  FOR XML PATH (''), TYPE)
	.value('.', 'nvarchar(max)'), 1, 1, '');
	SET @query = 'SELECT nombreTabla, ' + @cols + 'from (SELECT nombreTabla,
			   nombreColumna,
			   valor
		FROM [dbo].parametrizacion
	  where nombreTabla = '''+@tabla+'''
		)x pivot (max(valor) for nombreColumna in (' + @cols + ')) p';

	PRINT @query
	EXECUTE (@query);

END
go

