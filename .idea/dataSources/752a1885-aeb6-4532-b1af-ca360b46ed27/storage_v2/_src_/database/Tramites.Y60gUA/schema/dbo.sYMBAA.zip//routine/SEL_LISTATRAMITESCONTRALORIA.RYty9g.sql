
-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [SEL_LISTATRAMITESCONTRALORIA] 2264
-- =============================================
CREATE PROCEDURE [dbo].[SEL_LISTATRAMITESCONTRALORIA]
	 @idUsuario int
AS
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON;
 declare @contadores table(idEmpresa int, idSucursal int, idUsuario int)
	declare @idEmpresa int, @idSucursal int, @rol INT
  DECLARE @respuesta TABLE(id int, idFondoFijo varchar(50), fecha varchar(10), hora varchar(8), agencia nvarchar(500), sucursal varchar(150), departamento varchar(30), responsable varchar(172), monto decimal(18, 5), usuario_captura varchar(172), MontoSaldoCaja varchar(50), fecha_ultimo_arqueo varchar(10), idEmpresa int, idSucursal int, idDepartamento int, idResponsable int)

	/*Obtenemos la lista de los contadores que puede capturar el arqueo*/
  insert into @contadores
  EXEC Tramites.dbo.OBTIENE_PARAMETROS_V2 'CapturaArqueo'

  /*Obtenemos el rol del usuario*/
  select @rol =  idRol from Tramites.dbo.usuarioRol where idUsuario = @idUsuario

  /*
  si es contralor puede ver todas las empresas sucursal
  */

  if(@rol = 13 or @rol = 1)
  begin

    ;WITH reporte
	  AS
	  (SELECT
		  id = f.id
		 ,idFondoFijo = f.idFondoFijo
		 ,CONVERT(VARCHAR(10), f.fechaCreacion, 103) AS fecha
		 ,CONVERT(VARCHAR(8), f.fechaCreacion, 108) AS hora
		 ,agencia = case when dcer.RazonSocial = 'VEHICULOS EUROPEOS DE MONTERREY SA DE CV' then 'ANDRADE AEROPUERTO S.A DE C.V' else dcer.RazonSocial end
		 ,sucursal = cs.suc_nombre
		 --,departamento = cd.dep_nombre
		 ,case when f.departamentoAreas = 1 then (select descripcion from tramites.Tramite.cat_Departamentos_Sucursal_FF where F.iddepartamento = iddepartamento)
		 else cd.dep_nombre end as departamento
		 ,responsable = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
		 ,monto = td.traDe_devTotal
		 ,f.idEmpresa
	   ,f.idSucursal
	   ,f.idDepartamento
	   ,idResponsable = cu.usu_idusuario
		FROM Tramites.Tramite.fondoFijo f
		JOIN ControlAplicaciones.dbo.cat_departamentos cd
		  ON f.idDepartamento = cd.dep_iddepartamento
		JOIN ControlAplicaciones.dbo.cat_sucursales cs
		  ON f.idSucursal = cs.suc_idsucursal
		JOIN ControlAplicaciones..cat_usuarios cu
		  ON f.idResponsable = cu.usu_idusuario
		JOIN Centralizacionv2.dbo.DIG_CAT_EMPRESA_RAZON dcer
		  ON dcer.IdEmpresa = f.idEmpresa
		JOIN Tramites..tramiteDevoluciones td
		  ON f.id_perTra = td.id_perTra
		JOIN personaTramite p
		  ON td.id_perTra = p.id_perTra
		  AND p.petr_estatus <> 3),
	  arqueo
	  AS
	  (SELECT
		  a.id
		 ,fecha_ultimo_arqueo = CONVERT(VARCHAR(10), a.fecha, 103) --+ '-' + CONVERT(VARCHAR(10), a.fecha, 108)
		 ,MontoSaldoCaja = ISNULL(a.MontoSaldoCaja, 0)
		 ,usuario_captura = ISNULL(cua.usu_nombre + ' ' + cua.usu_paterno + ' ' + cua.usu_materno, '')
		 ,a.idFondoFijo
		FROM Tramites.dbo.arqueo a
		JOIN ControlAplicaciones..cat_usuarios cua
		  ON a.idUsuario = cua.usu_idusuario
		WHERE id IN (SELECT
			MAX(id)
		  FROM Tramites.dbo.arqueo
		  GROUP BY idfondofijo))
	  SELECT
		r.id
	   ,r.idFondoFijo
	   ,r.fecha
	   ,r.hora
	   ,r.agencia
	   ,r.sucursal
	   ,r.departamento
	   ,r.responsable
	   ,r.monto
	   ,usuario_captura = ISNULL(a.usuario_captura, '')
	   ,MontoSaldoCaja = ISNULL(a.MontoSaldoCaja, '')
	   ,fecha_ultimo_arqueo = ISNULL(a.fecha_ultimo_arqueo, '')
		,r.idEmpresa
	 ,r.idSucursal
	 ,r.idDepartamento
	 ,r.idResponsable
	  FROM reporte r
	  LEFT JOIN arqueo a
		ON r.id = a.idFondoFijo

  end
  else
  BEGIN

    
    DECLARE cur CURSOR FAST_FORWARD READ_ONLY LOCAL FOR
    	select  idEmpresa, idSucursal
    	from @contadores
    	where idUsuario = @idUsuario
    
    OPEN cur
    
    FETCH NEXT FROM cur INTO @idEmpresa,@idSucursal
    
    WHILE @@FETCH_STATUS = 0 BEGIN
    
    	
	  ;WITH reporte
	  AS
	  (SELECT
		  id = f.id
		 ,idFondoFijo = f.idFondoFijo
		 ,CONVERT(VARCHAR(10), f.fechaCreacion, 103) AS fecha
		 ,CONVERT(VARCHAR(8), f.fechaCreacion, 108) AS hora
		 --,agencia = dcer.RazonSocial
		 ,agencia =  case when dcer.RazonSocial = 'VEHICULOS EUROPEOS DE MONTERREY SA DE CV' then 'ANDRADE AEROPUERTO S.A DE C.V' else dcer.RazonSocial end
		 ,sucursal = cs.suc_nombre
		 --,departamento = cd.dep_nombre
		 ,case when f.departamentoAreas = 1 then (select descripcion from tramites.Tramite.cat_Departamentos_Sucursal_FF where F.iddepartamento = iddepartamento)
		 else cd.dep_nombre end as departamento
		 ,responsable = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
		 ,monto = td.traDe_devTotal
		 ,f.idEmpresa
	   ,f.idSucursal
	   ,f.idDepartamento
	   ,idResponsable = cu.usu_idusuario
		FROM Tramites.Tramite.fondoFijo f
		JOIN ControlAplicaciones.dbo.cat_departamentos cd
		  ON f.idDepartamento = cd.dep_iddepartamento
		JOIN ControlAplicaciones.dbo.cat_sucursales cs
		  ON f.idSucursal = cs.suc_idsucursal
		JOIN ControlAplicaciones..cat_usuarios cu
		  ON f.idResponsable = cu.usu_idusuario
		JOIN Centralizacionv2.dbo.DIG_CAT_EMPRESA_RAZON dcer
		  ON dcer.IdEmpresa = f.idEmpresa
		JOIN Tramites..tramiteDevoluciones td
		  ON f.id_perTra = td.id_perTra
		JOIN personaTramite p
		  ON td.id_perTra = p.id_perTra
		  AND p.petr_estatus <> 3),
	  arqueo
	  AS
	  (SELECT
		  a.id
		 ,fecha_ultimo_arqueo = CONVERT(VARCHAR(10), a.fecha, 103) --+ '-' + CONVERT(VARCHAR(10), a.fecha, 108)
		 ,MontoSaldoCaja = ISNULL(a.MontoSaldoCaja, 0)
		 ,usuario_captura = ISNULL(cua.usu_nombre + ' ' + cua.usu_paterno + ' ' + cua.usu_materno, '')
		 ,a.idFondoFijo
		FROM Tramites.dbo.arqueo a
		JOIN ControlAplicaciones..cat_usuarios cua
		  ON a.idUsuario = cua.usu_idusuario
		WHERE id IN (SELECT
			MAX(id)
		  FROM Tramites.dbo.arqueo
		  GROUP BY idfondofijo))
      INSERT INTO @respuesta
	  SELECT
		r.id
	   ,r.idFondoFijo
	   ,r.fecha
	   ,r.hora
	   ,r.agencia
	   ,r.sucursal
	   ,r.departamento
	   ,r.responsable
	   ,r.monto
	   ,usuario_captura = ISNULL(a.usuario_captura, '')
	   ,MontoSaldoCaja = ISNULL(a.MontoSaldoCaja, '')
	   ,fecha_ultimo_arqueo = ISNULL(a.fecha_ultimo_arqueo, '')
		,r.idEmpresa
	 ,r.idSucursal
	 ,r.idDepartamento
	 ,r.idResponsable
	  FROM reporte r
	  LEFT JOIN arqueo a
		ON r.id = a.idFondoFijo
	  where r.idEmpresa = @idEmpresa
	  and r.idSucursal = @idSucursal
    
    	FETCH NEXT FROM cur INTO @idEmpresa,@idSucursal
    
    END
    
    CLOSE cur
    DEALLOCATE cur

      SELECT id
            ,idFondoFijo
            ,fecha
            ,hora
            ,agencia
            ,sucursal
            ,departamento
            ,responsable
            ,monto
            ,usuario_captura
            ,MontoSaldoCaja
            ,fecha_ultimo_arqueo
            ,idEmpresa
            ,idSucursal
            ,idDepartamento
            ,idResponsable
        FROM @respuesta
        ORDER BY id

  end

END
go

