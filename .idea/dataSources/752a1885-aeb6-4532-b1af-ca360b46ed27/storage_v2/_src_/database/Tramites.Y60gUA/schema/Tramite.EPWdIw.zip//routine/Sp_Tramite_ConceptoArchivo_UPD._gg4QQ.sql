-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <24/09/2019>
-- Description:	<Actualiza la info de un archivo>
--TEST EXEC [Tramite].[Sp_Tramite_Concepto_INS]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ConceptoArchivo_UPD] 
	@idConceptoArchivo INT
	,@folioDocumento VARCHAR(80)
	,@iva DECIMAL(18, 2)
	,@total DECIMAL(18, 2)
AS
BEGIN 

	SET NOCOUNT ON;
	
	DECLARE @resultado INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_Concepto_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
		
		UPDATE [Tramite].[ConceptoArchivo]
		SET total = @total
			,folioDocumento = @folioDocumento
			,iva = @iva
		WHERE idConceptoArchivo = @idConceptoArchivo
           	
		      
		SET @resultado = 1;

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @resultado AS [resultado]
END
go

