-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <12/09/2019>
-- Description:	<Aprueba/Rechaza un empleado con sus conceptos>
--TEST EXEC [Tramite].[Sp_Tramite_AprobarRechazarEmpleado_UPD]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_AprobarRechazarEmpleado_UPD] 
	@idTramiteEmpleado INT,
	@idEstatus INT,
	@idSolicitud INT
AS
BEGIN 

	SET NOCOUNT ON;	
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_ADGEstatus_UPD] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
		
		 --Evaluamos si es aprobación, insertamos los importes de los conceptos aprobados.
		IF(@idEstatus = 2) BEGIN
			--Insertamos el importe de cada concepto a actualizar estatus.
			INSERT INTO Tramite.TramiteImporte (importe, idTramiteConcepto, idUsuario, idTipoProceso)
			SELECT TI.importe, TI.idTramiteConcepto, TI.idUsuario, 2
			FROM Tramite.TramiteEmpleado TE 
			INNER JOIN Tramite.TramiteEmpleadoConcepto TEC ON TE.idTramiteEmpleado = TEC.idTramiteEmpleado
			INNER JOIN Tramite.TramiteImporte TI ON TEC.idTramiteConcepto = TI.idTramiteConcepto AND TI.idTipoProceso = 1
			WHERE TE.idTramiteEmpleado = @idTramiteEmpleado
			AND TEC.idEstatus = 1
		 END
		 --Actualizamos todos los conceptos aun sin aprobar/rechazar
		 UPDATE Tramite.TramiteEmpleadoConcepto SET idEstatus = @idEstatus
		WHERE idEstatus = 1 AND idTramiteEmpleado IN (
			SELECT DISTINCT idTramiteEmpleado
			FROM Tramite.TramiteEmpleado WHERE idTramiteEmpleado = @idTramiteEmpleado)	
		
		DECLARE @pendientesTotal INT,
			@aprobadosTotal INT, @pendientesEmpleado INT,
			@aprobadosEmpleado INT;
		SELECT @pendientesEmpleado = COUNT(*)
			FROM Tramite.TramiteEmpleado TE
			INNER JOIN Tramite.TramiteEmpleadoConcepto TEC ON TE.idTramiteEmpleado = TEC.idTramiteEmpleado
			WHERE TE.idTramiteEmpleado = @idTramiteEmpleado
			AND TEC.idEstatus = 1
		
		IF (@pendientesEmpleado = 0) BEGIN 
			SELECT @aprobadosEmpleado = COUNT(*)
			FROM Tramite.TramiteEmpleado TE 
			INNER JOIN Tramite.TramiteEmpleadoConcepto TEC ON TE.idTramiteEmpleado = TEC.idTramiteEmpleado
			WHERE TE.idTramiteEmpleado = @idTramiteEmpleado
			AND TEC.idEstatus = 2
			IF(@aprobadosEmpleado > 0) BEGIN
				UPDATE [Tramite].[TramiteEmpleado] SET idEstatus = 2 
				WHERE idTramiteEmpleado = @idTramiteEmpleado
			END
			ELSE BEGIN 
				UPDATE [Tramite].[TramiteEmpleado] SET idEstatus = 3 
				WHERE idTramiteEmpleado = @idTramiteEmpleado
			END
		END

		SELECT @pendientesTotal = COUNT(*)
			FROM tramiteDevoluciones TD
			INNER JOIN Tramite.TramiteEmpleado TE ON TD.id_perTra = TE.idTramiteDevolucion
			INNER JOIN Tramite.TramiteEmpleadoConcepto TEC ON TE.idTramiteEmpleado = TEC.idTramiteEmpleado
			WHERE TD.id_perTra = @idSolicitud
			AND TEC.idEstatus = 1

		IF (@pendientesTotal = 0) BEGIN 
			SELECT @aprobadosTotal = COUNT(*)
			FROM tramiteDevoluciones TD
			INNER JOIN Tramite.TramiteEmpleado TE ON TD.id_perTra = TE.idTramiteDevolucion
			INNER JOIN Tramite.TramiteEmpleadoConcepto TEC ON TE.idTramiteEmpleado = TEC.idTramiteEmpleado
			WHERE TD.id_perTra = @idSolicitud
			AND TEC.idEstatus = 2
			IF(@aprobadosTotal > 0) BEGIN
				UPDATE [dbo].[personaTramite] SET petr_estatus = 2 
				WHERE id_perTra = @idSolicitud
				SET @VI_CountResult = 2
			END
			ELSE BEGIN 
				UPDATE [dbo].[personaTramite] SET petr_estatus = 3 
				WHERE id_perTra = @idSolicitud
				SET @VI_CountResult = 3
			END
		END		
		ELSE BEGIN
			SET @VI_CountResult = 1
		END

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @VI_CountResult AS [resultado]
END
go

