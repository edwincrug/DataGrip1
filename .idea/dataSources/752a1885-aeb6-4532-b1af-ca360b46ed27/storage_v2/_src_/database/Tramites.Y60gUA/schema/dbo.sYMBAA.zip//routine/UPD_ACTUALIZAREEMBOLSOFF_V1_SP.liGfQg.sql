-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/10/2019>
-- Description:	<SP que actualiza el estatus del vale>
--  [dbo].[UPD_ACTUALIZAREEMBOLSOFF_V1_SP]    37,3,''
-- =============================================
CREATE  PROCEDURE [dbo].[UPD_ACTUALIZAREEMBOLSOFF_V1_SP] 
	@id_perTra INT,
	@idReembolso INT,
	@tipoUsuario INT,
	@monto DECIMAL (18,2)
AS
BEGIN

	DECLARE @identificador INT = 0 ,@idAprobacion INT = 0
	IF(@tipoUsuario = 6)
	BEGIN
	DECLARE @idSiguiente INT = 7, @correo varchar (max)
	
	select @idReembolso = id from Tramite.fondoFijoReembolso where id_perTraReembolso = @id_perTra

	UPDATE [Tramite].[fondoFijoReembolso] 
	SET estatus =  2
	WHERE id= @idReembolso
	
	UPDATE Tramite.valesEvidencia 
	SET estatusPerTraReembolso = 2 
	WHERE id_perTraReembolso = @id_perTra

	DECLARE @idEmpresa INT, @idSucursal INT

	select @idEmpresa = id_empresa, @idSucursal = id_sucursal from tramiteDevoluciones where id_perTra = @id_perTra
	
		SELECT @correo =  STUFF((
	SELECT ';' + usu_correo
	FROM [Tramite].[UsuariosFondoFijo] uff
	inner join [Tramites].[Tramite].[Reembolso_Autorizadores_FF] ra on ra.idUsuario = uff.idUsuario and ra.nivelFinanzas = uff.idUsuariosFondoFijo 
	inner join controlAplicaciones.dbo.cat_usuarios u on ra.idUsuario = u.usu_idusuario
	WHERE  ra.idempresa = @idEmpresa and ra.idsucursal = @idSucursal and  ra.nivelFinanzas = @idSiguiente
	FOR XML PATH('')
	),1,1,'')
	
	--SELECT @correo =  STUFF((
	--SELECT ';' + usu_correo
	--from Tramite.UsuariosFondoFijo UF
 --   inner join Tramite.cat_usuariosFondoFijo cuf on uf.idUsuariosFondofijo = cuf.id
 --   inner join controlAplicaciones.dbo.cat_usuarios u on UF.idusuario = u.usu_idusuario
 --   where UF.idUsuariosFondofijo = @idSiguiente
 --   FOR XML PATH('')
	--),1,1,'')
	
	--Se agrega para actualizar la notificacion de Finanzas 2
	DECLARE  @not_agrupacionF2 INT = 60
	select @idAprobacion = a.apr_id, @identificador=  a.not_id from Notificacion.dbo.not_notificacion n 
	inner join notificacion.dbo.not_aprobacion a  on a.not_id = n.not_id
	where n.not_identificador = CONVERT(varchar(10), CONVERT(varchar(10), @id_perTra)) and n.not_agrupacion = @not_agrupacionF2 and a.apr_escalado= 0

	IF(@idAprobacion > 0 and @identificador > 0)
	BEGIN
	UPDATE Notificacion.dbo.not_notificacion  set not_estatus = 3 where not_identificador = CONVERT(varchar(10), @id_perTra) and not_agrupacion = @not_agrupacionF2
	UPDATE Notificacion.dbo.NOT_APROBACION set apr_estatus = 3 where apr_id = @idAprobacion
	INSERT INTO Notificacion.[dbo].[NOT_APROBACION_RESPUESTA](not_id,[apr_id],[nar_fecha],[nar_comentario])
	VALUES (@identificador,@idAprobacion,GETDATE(),'OK')	
	END
	--Fin

	SELECT 1 as success,@idReembolso as idReembolso, @correo as correo, @idSiguiente as tipoUsuario, 'Solicitud de Revisión Reembolso de Fondo Fijo' as asunto;

	END
	
	IF(@tipoUsuario = 7)
	BEGIN
	
	DECLARE @tipo INT, @estatusreembolso INT
	
	select @idReembolso = id, @estatusreembolso = estatus from Tramite.fondoFijoReembolso where id_perTraReembolso = @id_perTra

	select @tipo = idSalidaReembolso from [Tramite].[fondoFijoReembolso] WHERE id= @idReembolso
	
	
	UPDATE tramite.fondofijo 
	SET montoDisponible = montoDisponible + @monto
	WHERE id_pertra = @id_perTra

	UPDATE Tramite.valesEvidencia 
	SET estatusPerTraReembolso = 3 
	WHERE id_perTraReembolso = @id_perTra

	UPDATE personaTramite
	SET petr_estatus = 2
	where id_perTra = @id_perTra
	
	--IF (@estatusreembolso <> 3)
	--BEGIN
	IF(@tipo = 1)
	BEGIN
	DECLARE @consecutivo INT = 0
	--select @consecutivo = count(id_cuenta) from cuentasTesoreriaFA where id_perTra = @id_perTra and tipo = 2
	--SET @consecutivo = @consecutivo +1;

	insert into cuentasTesoreriaFA (id_perTra, fechaInsercion, estatus,id_tipoTramite, tipo, consecutivo, monto)
	values (@id_perTra, GETDATE(),1, 1, 2, @idReembolso, @monto)

	END
	--END

	DECLARE @id_perTraFF INT
	select top 1 @id_perTraFF = ff.id_perTra from Tramite.valesEvidencia ve
	inner join Tramite.vales v on v.id = ve.idVales
	inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
	inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
	where ve.id_perTraReembolso = @id_perTra 
	
		--Se agrega para actualizar la notificacion de Finanzas 3
	DECLARE  @not_agrupacionF3 INT = 61
	select @idAprobacion = a.apr_id, @identificador=  a.not_id from Notificacion.dbo.not_notificacion n 
	inner join notificacion.dbo.not_aprobacion a  on a.not_id = n.not_id
	where n.not_identificador = CONVERT(varchar(10), CONVERT(varchar(10), @id_perTra)) and n.not_agrupacion = @not_agrupacionF3 and a.apr_escalado= 0

	IF(@idAprobacion > 0 and @identificador > 0)
	BEGIN
	UPDATE Notificacion.dbo.not_notificacion  set not_estatus = 3 where not_identificador = CONVERT(varchar(10), @id_perTra) and not_agrupacion = @not_agrupacionF3
	UPDATE Notificacion.dbo.NOT_APROBACION set apr_estatus = 3 where apr_id = @idAprobacion
	INSERT INTO Notificacion.[dbo].[NOT_APROBACION_RESPUESTA](not_id,[apr_id],[nar_fecha],[nar_comentario])
	VALUES (@identificador,@idAprobacion,GETDATE(),'OK')	
	END
	--Fin

	--IF (@estatusreembolso <> 3)
	--BEGIN
	SELECT 
		1 as success,
		TD.id_perTra,
		TD.id_traDe,
		TD.id_empresa,
		TD.id_sucursal,
		TD.id_departamento,
		TD.PER_IDPERSONA,
		E.emp_nombre,
		FFSE.idBancoSalida as efectivoBanco,
		FFSE.numCuentaSalida as efectivoCuenta,
		'FR' as identificador,
		FF.cuentaContable,
		FFSE.cuentaContableSalida,
		FF.idFondoFijo,
		D.dep_nombrecto,
		@tipo as tipo,
		bs.cuenta as bsNombre,
		bs.numeroCuenta as bsNumeroCuenta,
		bs.cuentaClabe as bsCuentaClabe,
		bs.cuentaContable as bsCuentaContable,
		be.cuenta as beNombre,
		be.numeroCuenta as beNumeroCuenta,
		be.cuentaClabe as beCuentaClabe,
		be.cuentaContable as beCuentaContable,
		@idReembolso as idReembolso
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN Tramite.fondofijo FF ON FF.id_perTra = TD.id_perTra
	INNER JOIN Tramite.fondoFijoReembolso FFSE ON FFSE.idFondoFijo = FF.id and FFSE.id = @idReembolso
	INNER JOIN ControlAplicaciones.dbo.cat_departamentos D on D.dep_iddepartamento = TD.id_departamento
	INNER JOIN ControlAplicaciones.dbo.cat_empresas E on E.emp_idempresa = TD.id_empresa
	INNER JOIN referencias.dbo.BancoCuenta bs on bs.idBanco = FFSE.idBancoSalida and bs.idEmpresa = FF.idEmpresa and FFSE.cuentaContableSalida = bs.cuentaContable
	LEFT JOIN referencias.dbo.BancoCuenta be on be.idBanco = FFSE.idBancoEntrada and be.idEmpresa = FF.idEmpresa and FFSE.cuentaContableEntrada = be.cuentaContable
	WHERE PT.id_perTra =  @id_perTraFF

	UPDATE [Tramite].[fondoFijoReembolso] 
	SET estatus =  3
	WHERE id= @idReembolso
	END
	--END
	
	--IF (@estatusreembolso = 3)
	--BEGIN
	--SELECT 2 as success
	--END



END



go

