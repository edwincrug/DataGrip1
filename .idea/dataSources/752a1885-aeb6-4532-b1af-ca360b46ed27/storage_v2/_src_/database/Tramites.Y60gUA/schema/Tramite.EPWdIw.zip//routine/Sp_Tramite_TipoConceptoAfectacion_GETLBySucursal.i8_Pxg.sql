
-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <10/02/2020>
-- Description:	<Recupera la descripción >
--TEST EXEC  [Tramite].[Sp_Tramite_TipoConceptoAfectacion_GETLBySucursal]  37
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_TipoConceptoAfectacion_GETLBySucursal] 
	@idSucursal INT
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = ''

	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SET @query = 'SELECT PAR_IDENPARA, PAR_DESCRIP1, PAR_IMPORTE1, PAR_IMPORTE2 FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''TCPEDVAR'''
	print @query
	EXECUTE (@query)

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

