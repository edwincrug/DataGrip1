CREATE PROCEDURE SEL_TIPO_TRAMITE_SP
@idUsuario INT =  NULL
AS
BEGIN
	select   id_tramite idTramite
			,tra_nomTramite nombreTramite
	from cat_tramites where id_tramite = 4
END
go

