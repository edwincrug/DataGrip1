-- =============================================
-- Author:		Roberto Almanza
-- Create date: 12-07-2020
-- Description:	Obtiene los datos para el reporte de comprobacion de gastos de viaje
-- [SEL_DATA_REPORTE_GASTOS_VIAJE] 9,18,40,2452
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATA_REPORTE_GASTOS_VIAJE]
	-- Add the parameters for the stored procedure here
	@idEmpresa int
	,@idSucursal int
	,@idDepartamento int
	,@idPerTra int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @datos TABLE( id INT, fecha VARCHAR(30), facRem VARCHAR(15), descripcion VARCHAR(150), importe DECIMAL(18,2), iva decimal(18,2), total DECIMAL(18,2), cuentaAplicacion varchar(50), ComprobacionDeMas varchar(50) )

	INSERT INTO @datos
	SELECT 
	  ti.idTramiteImporte
	  ,case when ca.fecha is not null 
			then ca.fecha 
			else convert(VARCHAR(10),tc.fechaRegistro,103)+' '+ CONVERT(VARCHAR(8),tc.fechaRegistro,108) 
		end  AS fecha
	  ,ISNULL(cast(ca.folioDocumento as varchar(20)),'Vale Azul') AS facRem
	 , cc.concepto
		  , CASE WHEN ca.uuid IS NULL -- es vale
				THEN  case when (ca.estatusNotificacionDeMas is null or ca.estatusNotificacionDeMas = 3) -- si no es comprobacion de mas o es comprobacion aceptada
							then ti.importe 
							else tiIni.importe -- si se rechazo la comprobacion de mas se toma el valor solicitado
						end
				ELSE case when (ca.estatusNotificacionDeMas is null or ca.estatusNotificacionDeMas = 3) -- si no es comprobacion de mas o es comprobacion aceptada
							then ROUND((ti.importe/1.16),2) -- es factura  
							else ROUND((tiIni.importe/1.16),2) -- si se rechazo la comprobacion de mas se toma el valor solicitado
						end 
				
				end AS importe
		  , CASE 
				WHEN ca.uuid IS NULL 
				THEN 0 
				ELSE case when (ca.estatusNotificacionDeMas is null or ca.estatusNotificacionDeMas = 3) -- si no es comprobacion de mas o es comprobacion aceptada
							then ROUND((ti.importe/1.16)*0.16,2)   -- es factura  
							else ROUND((tiIni.importe/1.16)*0.16,2)    -- si se rechazo la comprobacion de mas se toma el valor solicitado
						end  
				
				END AS iva
		  ,case when (ca.estatusNotificacionDeMas is null or ca.estatusNotificacionDeMas = 3) -- si no es comprobacion de mas o es comprobacion aceptada
							then ti.importe 
							else tiIni.importe -- si se rechazo la comprobacion de mas se toma el valor solicitado
						end AS total
		  ,tc.numeroCuenta
		  , case when (ca.estatusNotificacionDeMas is null ) 
							then 'No tiene'
							else case when ca.estatusNotificacionDeMas = 3
									then 'Aprobada'
									else 'Rechazada'
								end-- si se rechazo la comprobacion de mas se toma el valor solicitado
						end as ComprobacionDeMas
	FROM Tramites.dbo.tramiteDevoluciones d
	JOIN personaTramite PT 
	  ON PT.id_perTra = d.id_perTra
	  AND pt.id_tramite = 9
	LEFT JOIN [Tramite].[TramiteEmpleado] TE 
	  ON d.id_perTra = TE.idTramiteDevolucion
	JOIN ControlAplicaciones.dbo.cat_empresas ce
	  ON d.id_empresa = ce.emp_idempresa
	JOIN ControlAplicaciones.dbo.cat_sucursales cs
	  ON d.id_sucursal = cs.suc_idsucursal
	JOIN ControlAplicaciones.dbo.cat_departamentos cd
	  ON d.id_departamento = cd.dep_iddepartamento 
	JOIN [Tramite].[TramiteConcepto] tc
	  ON d.id_perTra = tc.idTramitePersona
	JOIN Tramite.TramiteImporte ti 
	  ON tc.idTramiteConcepto = ti.idTramiteConcepto
	AND ti.idtipoProceso = 4
	JOIN Tramite.TramiteImporte tiIni 
	  ON tc.idTramiteConcepto = tiIni.idTramiteConcepto
	AND tiIni.idtipoProceso = 2
	left join ControlAplicaciones..cat_usuarios cu
			on pt.id_persona = cu.usu_idusuario
	LEFT JOIN tramite.ConceptoArchivo ca
	  ON ti.idConceptoArchivo = ca.idConceptoArchivo
	LEFT JOIN Tramite.ConceptoContable cc 
	  ON tc.idConceptoContable = cc.idConceptoContable
	  and ce.emp_idempresa = cc.idEmpresa
	  and cs.suc_idsucursal = cc.idSucursal
	WHERE tc.idTramitePersona = @idPerTra
	AND d.id_empresa = @idEmpresa
	AND d.id_sucursal = @idSucursal
	AND d.id_departamento = @idDepartamento


	SELECT id
		  ,fecha
		  ,noFactura = ltrim(rtrim(facRem))
		  ,descripcion = COALESCE(descripcion, 'TOTAL')
		  ,monto = sum(importe)
		  ,iva = sum(iva)
		  ,total = SUM(total)
		  ,cuentaAplicacion
		  , ComprobacionDeMas
	  FROM @datos
	  GROUP BY GROUPING SETS((id, fecha, facRem, descripcion,importe, iva, cuentaAplicacion, ComprobacionDeMas),())

END
go

