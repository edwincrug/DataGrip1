-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <11/06/2019>
-- Description:	<Devuelve el estatus en el que se encuentra el tramite>
-- Test SEL_ESTATUS_TRAMITE_APP_SP 2
-- =============================================
CREATE PROCEDURE SEL_ESTATUS_TRAMITE_APP_SP
	@id_perTra INT
AS
BEGIN
	SELECT  
		PERT.petr_estatus,
		ESTR.est_nombre
	FROM personaTramite PERT
	INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PERT.petr_estatus
	WHERE id_perTra = @id_perTra
END
go

