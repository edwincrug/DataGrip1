--/****** Object:  StoredProcedure [dbo].[SEL_CLIENTE_BY_ID_SP]    Script Date: 30/04/2020 10:05:18 p. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--exec [SEL_CLIENTE_BY_ID_SP] 460296,3,5
CREATE PROCEDURE [dbo].[SEL_CLIENTE_BY_ID_SP] 
	@idCliente INT,
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN
--declare @idCliente INT = 460296 ,
--	@idEmpresa INT = 3,
--	@idSucursal INT = 5


	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = '',
	@queryCarteras VARCHAR(MAX) = '';

	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SET @queryCarteras = 'SELECT ' + CHAR(13) +
		CHAR(9) + 'CO.PAR_DESCRIP1' + CHAR(13) +
	'FROM ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] C,' + ' [' + @nombreBase + '].DBO.PNC_PARAMETR CO' + CHAR(13) +
	'WHERE C.PAR_TIPOPARA = ''COCOCXC'' AND' + CHAR(13) +
	'C.PAR_HORA1 = ''12:00''' + CHAR(13) +
	'AND C.PAR_DESCRIP4 <> ''''' + CHAR(13) +
	'AND C.PAR_DESCRIP5 <> ''''' + CHAR(13) +
	'AND CO.PAR_TIPOPARA = ''COCOCXCCAR''' + CHAR(13) +
	'AND C.PAR_IDENPARA = CO.PAR_IDENPARA' + CHAR(13) +
	'AND CO.PAR_DESCRIP2 = ''''' + CHAR(13) +
	'AND CO.PAR_DESCRIP1 IN (SELECT PAR_IDENPARA FROM ' + '[' + @nombreBase + '].DBO.PNC_PARAMETR WHERE PAR_TIPOPARA = ''CARTERA'' AND PAR_IDMODULO = ''CXC''' + CHAR(13) +
							'AND PAR_DESCRIP2 IN (SELECT PAR_DESCRIP2 FROM ' + '[' + @nombreBase + '].DBO.PNC_PARAMETR WHERE PAR_TIPOPARA = ''ibandrade'')
							AND SUBSTRING(C.PAR_DESCRIP1,    CHARINDEX(''. -'',C.PAR_DESCRIP1) + 3    ,LEN(C.PAR_DESCRIP1)) not like ''%IVA%''
							) ';

	print @queryCarteras

	SET @query = 'SELECT ' + CHAR(13) +
		CHAR(9) + 'cartera.CCP_IDPERSONA AS idPersona,' + CHAR(13) +
		CHAR(9) + 'persona.PER_RFC AS rfc,' + CHAR(13) +
		CHAR(9) + 'persona.PER_NOMRAZON AS nombre,' + CHAR(13) +
		CHAR(9) + 'persona.PER_PATERNO AS paterno,' + CHAR(13) +
		CHAR(9) + 'persona.PER_MATERNO AS materno,' + CHAR(13) +
		CHAR(9) + 'SUM(cartera.CCP_ABONO) - SUM(cartera.CCP_CARGO) AS saldo' + CHAR(13) +
	'FROM' + '[' + @nombreBase + '].[DBO].[vis_concar01] AS cartera' + CHAR(13) +
	'INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] AS persona ON persona.PER_IDPERSONA = cartera.CCP_IDPERSONA' + CHAR(13) +
	'WHERE cartera.CCP_Cartera IN (' + @queryCarteras + ')' + CHAR(13) +
	'AND cartera.CCP_IDPERSONA IN (' + CONVERT(VARCHAR(20), @idCliente ) + ')' + CHAR(13) +
	'GROUP BY cartera.CCP_IDPERSONA, persona.PER_NOMRAZON, persona.PER_RFC,persona.PER_PATERNO, persona.PER_MATERNO'

	print @query
	EXECUTE (@query)

END
go

