

-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <11/10/2019>
-- Description:	<Inserta el tramite de fondo fijo>
-- ============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_TRAMITE_SP]
	@idFF INT,
	@idEmpresa INT,
	@idSucursal INT,
	@idDepartamento INT,
	@idUsuario INT,
	@idAutorizador INT,
	@descripcion VARCHAR(MAX),
	@nombreFondoFijo VARCHAR(200),
	@estatus INT,
	@monto NUMERIC(18,5),
	@idTramite INT,
	@idPersona INT,
	@cuentaContable VARCHAR(200),
	@departamentoArea INT = 0
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	DECLARE @idFondoFijo  INT,
			@incremental INT,
			@fondofijo varchar(50),
			@emp_nombrecto  varchar(10),
			@suc_nombrecto  varchar(10),
			@dep_nombrecto  varchar(10);
	DECLARE @idPerTra INT;
	BEGIN TRAN TrnFondoIns
	
	----SELECT @incremental =  COUNT(id) FROM [Tramite].[fondoFijo]
	----WHERE idEmpresa = @idEmpresa and idSucursal=@idSucursal and idDepartamento=@idDepartamento
	----SET @incremental = @incremental + 1;


	----select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cd.dep_nombrecto 
	----from ControlAplicaciones.dbo.cat_empresas ce 
	----inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	----inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	----where ce.emp_idempresa = @idEmpresa and cs.suc_idsucursal = @idSucursal and cd.dep_iddepartamento=@idDepartamento

	----SET @fondofijo ='FF-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto + '-' + CONVERT(varchar(10), @incremental) 

	--SELECT @incremental =  COUNT(id) FROM [Tramite].[fondoFijo]
	--WHERE idEmpresa = @idEmpresa and idSucursal=@idSucursal and idDepartamento=@idDepartamento
	--SET @incremental = @incremental + 1;

	--IF(@departamentoArea = 1)
	--BEGIN 
	--select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto
	--from ControlAplicaciones.dbo.cat_empresas ce 
	--inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	--where ce.emp_idempresa = @idEmpresa and cs.suc_idsucursal = @idSucursal 
	
	--select @dep_nombrecto = par_idenPara from Tramite.cat_Departamentos_Sucursal_FF 
	--where idEmpresa = @idEmpresa and idSucursal = @idSucursal and idDepartamento = @idDepartamento
	--END
	--ELSE
	--BEGIN
	--select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cd.dep_nombrecto 
	--from ControlAplicaciones.dbo.cat_empresas ce 
	--inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	--inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	--where ce.emp_idempresa = @idEmpresa and cs.suc_idsucursal = @idSucursal and cd.dep_iddepartamento=@idDepartamento
	--END

	--SET @fondofijo ='FF-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto + '-' + CONVERT(varchar(10), @incremental) 

	


	----Insert PersonaTramite
	--INSERT INTO [dbo].[personaTramite]
 --          ([id_persona]
 --          ,[id_tramite]
 --          ,[petr_fechaTramite]
 --          ,[petr_estatus])
 --    VALUES
 --          (@idUsuario
 --          ,@idTramite
 --          ,GETDATE()
 --          ,@estatus)

	--SET @idPerTra = SCOPE_IDENTITY()

	---- tramiteDevoluciones
	
	--INSERT INTO [dbo].[tramiteDevoluciones]
 --          ([id_perTra]
 --          ,[id_formaPago]
 --          ,[id_departamento]
	--	   ,[traDe_devTotal]
 --          ,[traDe_Observaciones]
 --          ,[id_empresa]
 --          ,[id_sucursal]
	--	   ,[PER_IDPERSONA]
	--	   ,[esDe_IdEstatus])
 --    VALUES
 --          (@idPerTra
 --          ,1
 --          ,@idDepartamento
	--	   ,@monto
 --          ,@descripcion
 --          ,@idEmpresa
 --          ,@idSucursal
	--	   ,@idPersona
	--	   ,0)

	---- Insert FondoFijo
		
	--INSERT INTO [Tramite].[fondoFijo]
 --          ([id_perTra]
	--	   ,[idEmpresa]
 --          ,[idSucursal]
 --          ,[idDepartamento]
 --          ,[nombreFondoFijo]
 --          ,[idFondoFijo]
 --          ,[idResponsable]
 --          ,[idAutorizador]
 --          ,[rutaIdentificacion]
 --          ,[rutaPagare]
 --          ,[rutaCarta]
 --          ,[descripcion]
 --          ,[fechaCreacion]
 --          ,[estatusFondoFijo]
	--	   ,[cuentaContable]
	--	   ,[montoDisponible]
	--	   ,[departamentoAreas]
	--	   )
 --    VALUES
 --          (@idPerTra
	--	   ,@idEmpresa
 --          ,@idSucursal
 --          ,@idDepartamento
	--	   ,@nombreFondoFijo
	--	   ,@fondofijo
	--	   ,@idUsuario
	--	   ,@idAutorizador
 --          ,''
 --          ,''
 --          ,''
	--	   ,@descripcion
	--	   ,GETDATE()
	--	   ,0
	--	   ,@cuentaContable
	--	   ,@monto
	--	   ,@departamentoArea)		

	--	--SET @idFondoFijo = SCOPE_IDENTITY()

		
	----INSERT INTO [Tramite].[fondoFijoCambios]
	----	([idTablaFondoFijo]
	----	 ,[montoInicial]
	----	 ,[montoCambiado]
	----	 ,[RutaDocumento]
	----	 ,[fechaCambio])
 ----   VALUES
	----	 (
	----	 @monto
	----	 ,0
	----	 ,''
	----	 ,GETDATE()
	----	 )



	--COMMIT TRAN TrnFondoIns

	--DECLARE @correo varchar (100), @nombreAutorizador varchar (100)
	----select 
	----@correo = cu.usu_correo,
	------@correo = 'juan.peralta@coalmx.com',
	----@nombreAutorizador = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	----from Tramite.autorizadoresFondoFijo av
	----inner join ControlAplicaciones..cat_usuarios cu on cu.usu_idusuario = av.idAutorizador
	----where idAutorizador = @idAutorizador

	--IF(@departamentoArea = 1)
	--BEGIN
	--select 
	--@correo = cu.usu_correo,
	--@nombreAutorizador = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	--from Tramite.cat_Departamentos_Sucursal_FF av
	--inner join ControlAplicaciones..cat_usuarios cu on cu.usu_idusuario = av.idAutorizador
	--where idAutorizador = @idAutorizador
	--END
	--ELSE
	--BEGIN
	--select 
	--@correo = cu.usu_correo,
	--@nombreAutorizador = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	--from Tramite.autorizadoresFondoFijo av
	--inner join ControlAplicaciones..cat_usuarios cu on cu.usu_idusuario = av.idAutorizador
	--where idAutorizador = @idAutorizador
	--END



	--SELECT success = 1, msg = 'Se inserto correctamente el tramite', idPerTra = @idPerTra, 
	--saveUrl = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'), correo = @correo, asunto = 'Autorización Fondo FIjo ' + @fondofijo,nombreAutorizador =  @nombreAutorizador,fondo = @fondofijo; 


	SELECT @incremental =  COUNT(id) FROM [Tramite].[fondoFijo]
	WHERE idEmpresa = @idEmpresa and idSucursal=@idSucursal and idDepartamento=@idDepartamento
	SET @incremental = @incremental + 1;

	select @departamentoArea = estatusFondos from tramites.Tramite.SucursalesXAreasFF where idEmpresa = @idEmpresa and idSucursal = @idSucursal

	IF(@departamentoArea = 1)
	BEGIN 
	select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto
	from ControlAplicaciones.dbo.cat_empresas ce 
	inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	where ce.emp_idempresa = @idEmpresa and cs.suc_idsucursal = @idSucursal 
	
	select @dep_nombrecto = par_idenPara from Tramite.cat_Departamentos_Sucursal_FF 
	where idEmpresa = @idEmpresa and idSucursal = @idSucursal and idDepartamento = @idDepartamento
	END
	ELSE
	BEGIN
	select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cd.dep_nombrecto 
	from ControlAplicaciones.dbo.cat_empresas ce 
	inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	where ce.emp_idempresa = @idEmpresa and cs.suc_idsucursal = @idSucursal and cd.dep_iddepartamento=@idDepartamento
	END

	SET @fondofijo ='FF-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto + '-' + CONVERT(varchar(10), @incremental) 

	

	--Insert PersonaTramite
	INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus])
     VALUES
           (@idUsuario
           ,@idTramite
           ,GETDATE()
           ,@estatus)

	SET @idPerTra = SCOPE_IDENTITY()

	-- tramiteDevoluciones
	
	INSERT INTO [dbo].[tramiteDevoluciones]
           ([id_perTra]
           ,[id_formaPago]
           ,[id_departamento]
		   ,[traDe_devTotal]
           ,[traDe_Observaciones]
           ,[id_empresa]
           ,[id_sucursal]
		   ,[PER_IDPERSONA]
		   ,[esDe_IdEstatus])
     VALUES
           (@idPerTra
           ,1
           ,@idDepartamento
		   ,@monto
           ,@descripcion
           ,@idEmpresa
           ,@idSucursal
		   ,@idPersona
		   ,0)

	-- Insert FondoFijo
		
	INSERT INTO [Tramite].[fondoFijo]
           ([id_perTra]
		   ,[idEmpresa]
           ,[idSucursal]
           ,[idDepartamento]
           ,[nombreFondoFijo]
           ,[idFondoFijo]
           ,[idResponsable]
           ,[idAutorizador]
           ,[rutaIdentificacion]
           ,[rutaPagare]
           ,[rutaCarta]
           ,[descripcion]
           ,[fechaCreacion]
           ,[estatusFondoFijo]
		   ,[cuentaContable]
		   ,[montoDisponible]
		   ,[departamentoAreas]
		   )
     VALUES
           (@idPerTra
		   ,@idEmpresa
           ,@idSucursal
           ,@idDepartamento
		   ,@nombreFondoFijo
		   ,@fondofijo
		   ,@idUsuario
		   ,@idAutorizador
           ,''
           ,''
           ,''
		   ,@descripcion
		   ,GETDATE()
		   ,0
		   ,@cuentaContable
		   ,@monto
		   ,@departamentoArea)	

		--SET @idFondoFijo = SCOPE_IDENTITY()

		
	--INSERT INTO [Tramite].[fondoFijoCambios]
	--	([idTablaFondoFijo]
	--	 ,[montoInicial]
	--	 ,[montoCambiado]
	--	 ,[RutaDocumento]
	--	 ,[fechaCambio])
 --   VALUES
	--	 (
	--	 @monto
	--	 ,0
	--	 ,''
	--	 ,GETDATE()
	--	 )



	COMMIT TRAN TrnFondoIns

	DECLARE @correo varchar (100), @nombreAutorizador varchar (100)
	IF(@departamentoArea = 1)
	BEGIN
	select 
	@correo = cu.usu_correo,
	@nombreAutorizador = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	from Tramite.cat_Departamentos_Sucursal_FF av
	inner join ControlAplicaciones..cat_usuarios cu on cu.usu_idusuario = av.idAutorizador
	where idAutorizador = @idAutorizador
	END
	ELSE
	BEGIN
	select 
	@correo = cu.usu_correo,
	@nombreAutorizador = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	from Tramite.autorizadoresFondoFijo av
	inner join ControlAplicaciones..cat_usuarios cu on cu.usu_idusuario = av.idAutorizador
	where idAutorizador = @idAutorizador
	END

	SELECT success = 1, msg = 'Se inserto correctamente el tramite', idPerTra = @idPerTra, 
	saveUrl = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'), correo = @correo, asunto = 'Autorización Fondo FIjo ' + @fondofijo,nombreAutorizador =  @nombreAutorizador,fondo = @fondofijo; 



END TRY
	BEGIN CATCH
		ROLLBACK TRAN TrnFondoIns
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END


go

