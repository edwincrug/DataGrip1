-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <04/07/2020>
-- Description:	<SP que verifica el estatus del reembolso>
-- SEL_ESTATUSREEMBOLSO_SP 1298
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ESTATUSREEMBOLSO_SP] 
	@id_perTra INT
AS
BEGIN
	

	DECLARE @idFondoFijo INT, @idReembolso INT, @estatusFinanzas INT = 0
	select @idFondoFijo = id, @idReembolso = ISNULL(idReembolso, 0) from Tramite.fondoFijo where id_perTra = @id_perTra
	
	
	IF EXISTS (select top 1 1 from Tramite.fondoFijoReembolso where idFondoFijo = @idFondoFijo and id_perTraReembolso is null order by id desc) 
	BEGIN
	select top 1 @estatusFinanzas = estatus from Tramite.fondoFijoReembolso where idFondoFijo = @idFondoFijo and id_perTraReembolso is null order by id desc
	END
	ELSE
	BEGIN
		SET @estatusFinanzas = 0
	END
	
	IF(@idReembolso = 0)
	BEGIN
		SET @estatusFinanzas = 0
	END 

	Select @estatusFinanzas as estatusfinanzas
	
END



go

