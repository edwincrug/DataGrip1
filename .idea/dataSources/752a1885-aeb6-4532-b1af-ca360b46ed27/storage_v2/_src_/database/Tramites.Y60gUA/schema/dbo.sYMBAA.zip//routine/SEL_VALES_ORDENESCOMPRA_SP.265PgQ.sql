
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <25/03/2020>
-- Description:	<SP que trae las ordens de compra de diferentes concetradoras>
-- [dbo].[SEL_VALES_ORDENESCOMPRA_SP] 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALES_ORDENESCOMPRA_SP] 
	
AS
BEGIN
		
		DECLARE @CountBases INT = 1, 
				@registos INT = 0, 
				@base varchar (200),
				@idComprobacionVale varchar(100),
				@SQLAgencia NVARCHAR(MAX)
		DECLARE @db TABLE(id int identity(1,1),idempresa INT,idsucursal INT, idcomprobacion INT, base varchar(200), idComprobacionVale varchar(100), idusuario INT, idvale varchar(100), monto decimal(10,2), canal varchar(10), compNoAutorizado INT);
		DECLARE @vales TABLE(idvale varchar(100), montoSolicitado decimal(10,2), montoJustificado decimal(10,2), justificado INT, JustificoMas decimal(10,2));

INSERT INTO @db
select ff.idempresa, ff.idsucursal, ve.id idcomprobacion, e.emp_nombrebd, ve.idcomprobacionvale, ff.idResponsable, v.idVale, ve.monto, dep.dep_nombrecto, ISNULL(ve.compNoAutorizado,0) as compNoAutorizado
from Tramite.valesEvidencia ve
inner join Tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.FondoFijo ff on ff.id = idTablaFondoFijo
inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = ff.idempresa
inner join ControlAplicaciones.dbo.cat_departamentos dep ON dep.dep_iddepartamento = ff.idDepartamento
where ve.procesoPoliza is null and ve.idestatus = 2 --and ve.idFactura is null--  and ve.idestatus = 10   --v.estatusVale = 3  
SET @registos = (select COUNT(1) from @db)
			WHILE(@CountBases<= @registos)
					BEGIN
						SELECT 
						@base = base,
						@idComprobacionVale = idComprobacionVale
						FROM @db 
						WHERE id = @CountBases
					
						SET @SQLAgencia = 'select omd.omd_producto, odm_ordencompra 
						from ['+@base+'].dbo.cxp_ordenesmasivas om
						inner join ['+@base+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@idComprobacionVale+''''	

						print 	@SQLAgencia
						DECLARE @pedidos TABLE (idComprobacionVale varchar(100), ordencompra varchar(100));

						INSERT INTO @pedidos
						EXECUTE(@SQLAgencia)

						SET @CountBases= @CountBases+1     
					END
INSERT INTO @vales
select 
v.idVale,
v.montoSolicitado, 
sum(ve.monto) as montoJustificado, 
case when  sum(ve.monto) = v.montoSolicitado then  1 
when sum(ve.monto) > v.montoSolicitado then 1
else 0  end as justificado,
case when sum(ve.monto) > v.montoSolicitado then  sum(ve.monto) - v.montoSolicitado else 0  end as justificoMas
--,v.estatusVale
from Tramite.valesEvidencia ve 
inner join Tramite.vales v on v.id = ve.idVales
 where ve.idestatus = 2
 group by v.idVale, v.montoSolicitado

select d.*
,p.ordencompra
,v.montoSolicitado
,v.montoJustificado
,v.justificado
,v.JustificoMas 
from @db d 
left join @pedidos p on d.idComprobacionVale =  p.idComprobacionVale
left join @vales v on v.idvale = d.idvale
order by p.ordencompra asc

END
go

