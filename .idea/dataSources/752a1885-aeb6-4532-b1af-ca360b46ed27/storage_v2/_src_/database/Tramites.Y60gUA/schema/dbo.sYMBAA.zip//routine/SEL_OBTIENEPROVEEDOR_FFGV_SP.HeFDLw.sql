

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [SEL_OBTIENEPROVEEDOR_FFGV_SP]   1114, 335
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENEPROVEEDOR_FFGV_SP] 
	@idProveedor INT
AS
BEGIN
SELECT PER_IDPERSONA, PER_NOMRAZON, PER_TIPO FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @idProveedor
END
go

