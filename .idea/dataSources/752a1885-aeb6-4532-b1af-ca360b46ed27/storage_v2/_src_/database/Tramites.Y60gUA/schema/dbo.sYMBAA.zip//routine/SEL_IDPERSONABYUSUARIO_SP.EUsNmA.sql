

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/12/2019>
-- Description:	<SP que obtiene el idPersona de [GA_Corporativa]>
-- [SEL_IDPERSONABYUSUARIO_SP] 428
-- =============================================
CREATE PROCEDURE [dbo].[SEL_IDPERSONABYUSUARIO_SP] 
	@idUsuario INT
AS
BEGIN
	 
DECLARE @nombreUsuario varchar (255), @paterno varchar (255), @materno varchar (255)

	DECLARE @RfcNoValidos TABLE(RFC VARCHAR(50))
	INSERT INTO @RfcNoValidos(RFC)
	EXEC Tramites.dbo.OBTIENE_PARAMETROS_V2 'RfcNoValidos'

select @nombreUsuario = usu_nombre, @paterno = usu_paterno, @materno = usu_materno  from ControlAplicaciones..cat_usuarios where usu_idusuario = @idUsuario
--IF EXISTS (select * from [GA_Corporativa].[dbo].[PER_PERSONAS] where PER_STATUS = 'ACTIVO' and PER_NOMRAZON like '%'+ @nombreUsuario +'%' and PER_PATERNO like '%'+ @paterno +'%' and PER_MATERNO like '%'+ @materno +'%') 
--BEGIN
--select top 1 PER_IDPERSONA 
--from [GA_Corporativa].[dbo].[PER_PERSONAS] 
--where PER_STATUS = 'ACTIVO' 
--and PER_NOMRAZON like '%'+ @nombreUsuario +'%' 
--and PER_PATERNO like '%'+ @paterno +'%' 
--and PER_MATERNO like '%'+ @materno +'%'
--order by PER_IDPERSONA desc
--END
--ELSE
--BEGIN
--select 0 PER_IDPERSONA
--END 
 IF EXISTS (select * from  [Tramite].[cat_CuentasContableFFGV] where idUsuario = @idUsuario)
 BEGIN
 select 
 CONVERT(varchar(15), idpersona)  as PER_IDPERSONA, 
 cuenta as cuentaContable
 ,idsucursal

 from  [Tramite].[cat_CuentasContableFFGV] where idUsuario = @idUsuario
 END
 ELSE
 BEGIN
 IF EXISTS (select * from [GA_Corporativa].[dbo].[PER_PERSONAS] where PER_STATUS = 'ACTIVO' and PER_NOMRAZON like '%'+ @nombreUsuario +'%' and PER_PATERNO like '%'+ @paterno +'%' and PER_MATERNO like '%'+ @materno +'%') 
BEGIN
select 
top 1 CONVERT(varchar(10), PER_IDPERSONA) as PER_IDPERSONA,
'' as cuentaContable
,0 as idsucursal
from [GA_Corporativa].[dbo].[PER_PERSONAS] 
where PER_STATUS = 'ACTIVO' 
and PER_NOMRAZON like '%'+ @nombreUsuario +'%' 
and PER_PATERNO like '%'+ @paterno +'%' 
and PER_MATERNO like '%'+ @materno +'%'
and PER_RFC COLLATE Modern_Spanish_CI_AS not in (select RFC from @RfcNoValidos)
order by PER_IDPERSONA desc
END
ELSE
BEGIN
select '0' PER_IDPERSONA, '' as cuentaContable
END 
END

END
go

