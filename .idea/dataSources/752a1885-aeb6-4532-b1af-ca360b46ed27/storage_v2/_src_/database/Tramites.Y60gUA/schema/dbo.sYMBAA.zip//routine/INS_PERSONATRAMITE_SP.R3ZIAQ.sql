-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <07/06/2019>
-- Description:	<Inserta la persona y que tramite va a realizar>
-- =============================================
CREATE PROCEDURE [dbo].[INS_PERSONATRAMITE_SP]
	@idPersona INT,
	@idTramite INT
AS
BEGIN
	INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus]
		   ,esDe_IdEstatus)
     VALUES(
           @idPersona,
		   @idTramite,
		   GETDATE(),
		   0,
		   1)
	SELECT success = 1, msg = 'Se registro al usuario correctamente';
END
;
go

