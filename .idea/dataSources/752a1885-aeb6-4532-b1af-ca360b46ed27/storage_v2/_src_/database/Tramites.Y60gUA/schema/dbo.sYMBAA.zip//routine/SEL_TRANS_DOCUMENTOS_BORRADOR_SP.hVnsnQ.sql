-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: 16-01-2020
-- Description:	<Trae los documentos que éxisten y los que no éxisten>
--TEST SEL_DEV_DOCUMENTOS_BORRADOR_SP 'localhost', 283, 4
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TRANS_DOCUMENTOS_BORRADOR_SP] 
	@urlParam VARCHAR(30),
	@idPerTra INT,
	@idTramite INT
AS
BEGIN

	DECLARE @url VARCHAR(500);
	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam);
		END
	ELSE
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');		
		END

	DECLARE @saveUrl VARCHAR(100) = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_DOCTO_TRANS');

	SELECT	
		id_tramite
		,id_perTra
		,doc_nomDocumento
		,A.ext_nombre
		,A.id_traDo
		,id_documento
		,isnull(b.existe,0) existe
		,isnull(det_observaciobes,'') Observaciones 
		,b.det_estatus estatusDocumento 
		,b.petr_estatus estatusTramite
		,A.doc_infoAdicional
		,A.doc_expira
		,@url +'DoctosTransferencias/' + 'Transferencia_' + CONVERT(VARCHAR(20),id_perTra) + '/Documento_' + CONVERT(VARCHAR(10),id_documento)+'.'+A.ext_nombre [url]	
		,A.id_extension AS idExtension
		,B.det_idPerTra
		,@saveUrl saveUrl
		,A.opcional
	FROM (SELECT 
		T.id_tramite, 
		doc_nomDocumento, 
		TD.id_traDo,
		TD.id_documento, 
		EXT.ext_nombre ,  
		DOC.doc_infoAdicional, 
		doc_expira,
		EXT.id_extension,
		DOC.opcional
	FROM cat_tramites T
	INNER JOIN cat_tramiteDocumento TD ON TD.id_tramite = T.id_tramite
	INNER JOIN cat_documentos DOC ON DOC.id_documento = TD.id_documento
	INNER JOIN cat_extensiones EXT ON EXT.id_extension = DOC.id_extension
	WHERE T.id_tramite = @idTramite AND DOC.id_documento <> 64 ) AS A LEFT JOIN
	(

	SELECT	id_tramite existe
			,DPT.id_traDo
			,DPT.det_observaciobes
			,dpt.det_estatus
			,pt.petr_estatus
			,PT.id_perTra
			,DPT.det_idPerTra
	FROM  [personaTramite] PT
	JOIN  [dbo].[detallePersonaTramite] DPT 
  ON DPT.id_perTra = PT.id_perTra
	WHERE PT.id_perTra = @idPerTra ) AS B ON B.Existe = A.id_tramite AND B.id_traDo = A.id_traDo
END
go

