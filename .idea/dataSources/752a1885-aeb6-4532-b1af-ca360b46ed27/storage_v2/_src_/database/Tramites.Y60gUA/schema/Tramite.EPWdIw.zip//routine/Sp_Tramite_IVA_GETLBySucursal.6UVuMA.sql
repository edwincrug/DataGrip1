

-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <10/02/2020>
-- Description:	<Recupera la descripción >
--TEST EXEC  [Tramite].[Sp_Tramite_IVA_GETLBySucursal]  6 
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_IVA_GETLBySucursal] 
	@idSucursal INT
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = ''

	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SET @query = 'SELECT PAR_IDENPARA, PAR_DESCRIP1, PAR_IMPORTE1 FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''IV'''

	EXECUTE (@query)

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

