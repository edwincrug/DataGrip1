-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ID_DEPARTAMENTO_BY_CARTERA]
	@cartera VARCHAR(10),
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN
	SELECT 
		idDepartamento
	FROM [clientes].[dbo].[CatalogoDepartamento]
	WHERE idEmpresa = @idEmpresa AND idSucursal = @idSucursal AND claveCartera = @cartera
END
go

