-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <03/09/2020>
-- Description:	<Trae todas los departamentos por empresa y sucursal>
--TEST SEL_TIPOSOLICITUDFONDOFIJO_AREA_SP 18, 44 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOSOLICITUDFONDOFIJO_AREA_SP]
     @idEmpresa INT = 0
    ,@idSucursal INT = 0
AS
BEGIN
	SELECT 
	estatusFondos,
	estatusVales
	FROM   [Tramite].[SucursalesXAreasFF]
	WHERE  idEmpresa = @idempresa AND idSucursal = @idsucursal 
END


go

