-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_DOCUMENTOS_REPORTE_CONTRALORIA 'localhos', 126, 'FF-ZM-NZA-UN-1',71,4,6,26,428,1
-- c:\\app\\public\\Imagenes\\ReporteContraloria\\
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_REPORTE_CONTRALORIA]
	@urlParam VARCHAR(30),
	@idPerTra INT,
	@idFondoFijo varchar(50),
	@idUsuario int,
	@idEmpresa INT 
	,@idSucursal INT 
	,@idDepartamento INT
	,@idUsuarioResponsable int
	,@opcion int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		DECLARE @url VARCHAR(500);
		DECLARE @fecha DATETIME  = getdate()
		declare
				 
				 @nombreArchivo VARCHAR(100) 
				 ,@ruta VARCHAR(255) 
	

	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam);
		END
	ELSE
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');		
		END

	DECLARE @saveUrl VARCHAR(100) = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_DOCTO_CONTRA');

	set @ruta = @url +'ReporteContraloria/' + 'Tramite_' + CONVERT(VARCHAR(20),@idPerTra)+'/'
	set @nombreArchivo =  'Reporte_' + @idFondoFijo+'_'+replace(convert(varchar(30), getdate(), 103),'/','')+'_'+ replace(convert(varchar(30), getdate(), 108),':','')+'.pdf'

	if(@opcion=0)
	begin
	INSERT INTO Tramites.dbo.historicoEvidenciaArqueos( idFondoFijo ,idUsuario ,idEmpresa ,idSucursal ,idDepartamento ,fecha ,nombreArchivo ,ruta, idUsuarioResponsable)
	select @idFondoFijo as idFondoFijo
	,@idUsuario as isUsuarioCargaReporte
	,@idEmpresa as idEmpresa
	,@idSucursal as isSucursal
	,@idDepartamento as idDepartamento
	,@fecha as fecha
	, @nombreArchivo as nombreArchivo
	, @ruta as ruta
	,@idUsuarioResponsable
	end

	if(@opcion = 0)
	begin
		select 1 as success
		,@idFondoFijo as idFondoFijo
		,@idUsuario as isUsuarioCargaReporte
		,@idEmpresa as idEmpresa
		,@idSucursal as isSucursal
		,@idDepartamento as idDepartamento
		,@fecha as fecha
		, @nombreArchivo as nombreArchivo
		, @ruta as ruta
		,@ruta+@nombreArchivo as [url]
		,@saveUrl as saveUrl
		,1 as existe
		, 2 as idExtension	

	end

	if (@opcion = 1)
	begin
		select ea.id
      ,ea.idFondoFijo
      ,ea.idUsuario
	  ,cu.usu_nombre + ' '+ cu.usu_paterno+' '+cu.usu_materno as usuarioCarga
      ,ea.idEmpresa
      ,ea.idSucursal
      ,ea.idDepartamento
      ,convert( varchar(50),ea.fecha,103)+ ' '+ convert( varchar(50),ea.fecha,108) as fecha
      ,ea.nombreArchivo
      ,ea.ruta
      ,ea.idUsuarioResponsable
	  ,cur.usu_nombre + ' '+ cur.usu_paterno+' '+cur.usu_materno as usuarioResponsable
		from historicoEvidenciaArqueos ea
		join ControlAplicaciones..cat_usuarios cu
		on ea.idUsuario = cu.usu_idusuario
		join ControlAplicaciones..cat_usuarios cur
		on ea.idUsuarioResponsable = cur.usu_idusuario
		where idFondoFijo = @idFondoFijo
	end


	--select 1 as success, @url +'ReporteContraloria/' + 'Tramite_' + CONVERT(VARCHAR(20),@idPerTra) + '/Reporte_' + @idFondoFijo+'.pdf' [url] ,@saveUrl saveUrl, 1 as existe, 2 as idExtension	
	

    
END
go

