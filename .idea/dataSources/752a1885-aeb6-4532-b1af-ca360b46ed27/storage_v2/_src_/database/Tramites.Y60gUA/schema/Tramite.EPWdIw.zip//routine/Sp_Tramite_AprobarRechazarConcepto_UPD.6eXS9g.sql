-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <09/09/2019>
-- Description:	<Aprueba, Rechaza un concepto>
--TEST EXEC [Tramite].[Sp_Tramite_AprobarRechazarConcepto_UPD]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_AprobarRechazarConcepto_UPD] 
	@idTramiteConcepto INT,
	@idEstatus INT,
	@importe DECIMAL(18, 2),
	@comentario VARCHAR(150),
	@idUsuario INT,
	@idTipoProceso INT,
	@idSolicitud INT
AS
BEGIN 

SET NOCOUNT ON;
	
	DECLARE @resultado INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_ConceptoImporte_UPD] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite

		UPDATE [Tramite].[TramiteConcepto] 
			SET idEstatus = @idEstatus 
		WHERE idTramiteConcepto = @idTramiteConcepto
		
		IF(@idEstatus = 2 OR @idEstatus = 9) BEGIN
			DELETE FROM [Tramite].[TramiteImporte] WHERE idTramiteConcepto = @idTramiteConcepto AND idTipoProceso = @idTipoProceso
			INSERT INTO [Tramite].[TramiteImporte] (importe, idTramiteConcepto, idUsuario, idTipoProceso)
			VALUES (@importe, @idTramiteConcepto, @idUsuario, @idTipoProceso)
		END

		IF(COALESCE(@comentario, '') != '')
		BEGIN
			INSERT INTO [Tramite].[TramiteComentario] (
				comentario
				,idTramiteConcepto
				,idUsuario,
				idTipoProceso)
			VALUES (
				@comentario
				,@idTramiteConcepto
				,@idUsuario
				,@idTipoProceso)
		END

		DECLARE @pendientes INT,
			@aprobados INT;
		IF(@idTipoProceso = 2) BEGIN
			SELECT @pendientes = COUNT(*)
				FROM Tramite.TramiteConcepto
				WHERE idTramitePersona = @idSolicitud
				AND idEstatus = 1

			IF (@pendientes = 0) BEGIN 
				SELECT @aprobados = COUNT(*)
				FROM Tramite.TramiteConcepto
				WHERE idTramitePersona = @idSolicitud
				AND idEstatus = 2

				IF(@aprobados > 0) BEGIN
					UPDATE [dbo].[personaTramite] SET petr_estatus = 2 
					WHERE id_perTra = @idSolicitud
					SET @resultado = 2;
				END
				ELSE BEGIN 
					UPDATE [dbo].[personaTramite] SET petr_estatus = 3 
					WHERE id_perTra = @idSolicitud
					SET @resultado = 3;
				END
			END
			ELSE BEGIN		   
				SET @resultado = 1;
			END
		END
		IF(@idTipoProceso = 4) BEGIN
			SELECT @pendientes = COUNT(*)
				FROM Tramite.TramiteConcepto
				WHERE idTramitePersona = @idSolicitud
				AND idEstatus = 8

			IF (@pendientes = 0) BEGIN 
				SELECT @aprobados = COUNT(*)
				FROM Tramite.TramiteConcepto
				WHERE idTramitePersona = @idSolicitud
				AND idEstatus = 9

				IF(@aprobados > 0) BEGIN
					UPDATE [dbo].[personaTramite] SET petr_estatus = 9 
					WHERE id_perTra = @idSolicitud
					SET @resultado = 9;
				END
				ELSE BEGIN 
					UPDATE [dbo].[personaTramite] SET petr_estatus = 10 
					WHERE id_perTra = @idSolicitud
					SET @resultado = 10;
				END
			END
			ELSE BEGIN		   
				SET @resultado = 1;
			END
		END


		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH
	SET NOCOUNT OFF

	SELECT @resultado AS [resultado]

END
go

