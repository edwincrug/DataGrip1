-- =============================================
-- Author:		<Luis Garccía>
-- Create date: <03/07/2019>
-- Description:	<Trae todas las sucursales por empresa>
--TEST SEL_SUCURSALES_SP 27, 0
-- =============================================
CREATE PROCEDURE [dbo].[SEL_SUCURSALES_SP]
    @idEmpresa INT = 0,
	@usu_idusuario INT = 0
AS
BEGIN

IF (@idEmpresa = 14)
BEGIN

    SELECT DISTINCT
		SUC.suc_idsucursal AS idSucursal
        ,suc_nombre     AS nombre
    FROM [ControlAplicaciones].[dbo].[cat_sucursales] SUC
	INNER JOIN  [ControlAplicaciones].[dbo].[ope_organigrama] OPE ON OPE.suc_idsucursal = SUC.suc_idsucursal
    WHERE SUC.emp_idempresa = @idEmpresa AND OPE.usu_idusuario = 4250 

END
ELSE IF(@idEmpresa = 19 OR @idEmpresa = 16 OR @idEmpresa = 17 OR @idEmpresa = 18  OR @idEmpresa = 27 OR @idEmpresa = 26)
BEGIN
SELECT DISTINCT
		SUC.suc_idsucursal AS idSucursal
        ,suc_nombre     AS nombre
    FROM [ControlAplicaciones].[dbo].[cat_sucursales] SUC
	INNER JOIN  [ControlAplicaciones].[dbo].[ope_organigrama] OPE ON OPE.suc_idsucursal = SUC.suc_idsucursal
    WHERE SUC.emp_idempresa = @idEmpresa
END
ELSE
BEGIN

   SELECT DISTINCT
		SUC.suc_idsucursal AS idSucursal
        ,suc_nombre     AS nombre
    FROM [ControlAplicaciones].[dbo].[cat_sucursales] SUC
	INNER JOIN  [ControlAplicaciones].[dbo].[ope_organigrama] OPE ON OPE.suc_idsucursal = SUC.suc_idsucursal
    WHERE SUC.emp_idempresa = @idEmpresa AND OPE.usu_idusuario = @usu_idusuario


END

END


go

