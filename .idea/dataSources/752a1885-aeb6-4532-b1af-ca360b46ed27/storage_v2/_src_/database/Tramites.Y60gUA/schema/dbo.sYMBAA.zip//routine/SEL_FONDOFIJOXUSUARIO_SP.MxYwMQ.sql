
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <16/10/2019>
-- Description:	<SP que trae los datos de los FF x usuario>
-- SEL_FONDOFIJOXUSUARIO_SP 1350
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJOXUSUARIO_SP] 
	@idtramite INT
AS
BEGIN

	DECLARE @Vales TABLE(idVale VARCHAR(20), montoFaltante decimal(18,4));
	DECLARE @RegresaEfectivo decimal(18,4)
	insert into @Vales
	select v.idVale, 
	case when  v.montoSolicitado >  SUM(ve.monto) then v.montoSolicitado -  SUM(ve.monto) else 0 end montoFaltante
	from Tramite.valesFondoFijo vff
	inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
	inner join Tramite.vales v on v.id = vff.idVales
	inner join Tramite.valesEvidencia ve on ve.idVales = v.id
	where ff.id_perTra = @idtramite and v.estatusVale = 4 
	group by v.idVale, v.montoSolicitado

	select  @RegresaEfectivo = ISNULL(SUM(montoFaltante),0) from @Vales

	DECLARE @nombreBD VARCHAR(30)
       ,@idEmpresa INT
       ,@query NVARCHAR(MAX)
	   ,@idResponsable int
	   ,@cuentaContable VARCHAR(60)
	   ,@fondoFijo varchar(30)
	   ,@nombreResponsableFF varchar(150)
	   ,@clienteBPRO varchar(15)
	   ,@montoDisponible DECIMAL(18,4)

	SELECT 
	@idEmpresa = f.idEmpresa
	,@idResponsable = f.idResponsable
	,@fondoFijo = idFondoFijo
		FROM Tramites.Tramite.fondoFijo f
	JOIN ControlAplicaciones.dbo.cat_departamentos cd
	  ON f.idDepartamento = cd.dep_iddepartamento
	JOIN ControlAplicaciones.dbo.cat_sucursales cs
	  ON cd.suc_idsucursal = cs.suc_idsucursal
	JOIN ControlAplicaciones..cat_usuarios cu
	  ON f.idResponsable = cu.usu_idusuario
	WHERE f.id_perTra = @idtramite

	SELECT
	  @nombreBD = ce.emp_nombrebd
	FROM ControlAplicaciones.dbo.cat_empresas ce
	WHERE ce.emp_idempresa = @idEmpresa

	SELECT
	  @clienteBPRO = idpersona
	FROM [Tramite].[cat_CuentasContableFFGV]
	WHERE idUsuario = @idResponsable

	SET @query = '
	SELECT  @montoDisponible = isnull(SUM(CCP_CARGO),0) - isnull(SUM(CCP_ABONO),0) 
    FROM '+ @nombreBD +'.DBO.VIS_CONCAR01 
    WHERE CCP_IDDOCTO = '''+@fondoFijo+''' and CCP_IDPERSONA = '''+@clienteBPRO+''''
	EXECUTE sp_executeSQL @query, N' @montoDisponible DECIMAL(18,4) OUTPUT',@montoDisponible OUTPUT
	--select @montoDisponible


	 
SELECT 
	FF.id,
	TD.id_traDe,
	FF.idEmpresa, 
	FF.idSucursal, 
	FF.idDepartamento, 
	FF.idAutorizador, 
	FF.idResponsable, 
	TD.traDe_devTotal as monto,  
	--case when FFC.montoCambiado is null then  TD.traDe_devTotal 
	--else case when FF.aumentodisminucion = 1 then TD.traDe_devTotal + FFC.montoCambiado else TD.traDe_devTotal - FFC.montoCambiado end
	--end as monto,  
	ISNULL(TD.traDe_Observaciones,'') AS descripcion,
	FF.nombreFondoFijo,
	FF.idFondoFijo,
	CONVERT(varchar, FF.fechaCreacion, 103) as fechaCreacion,
	CASE WHEN PT.petr_estatus IN (2, 3, 5) 
	THEN ET.est_nombre 
	ELSE 
	PED.esDe_descripcion 
	END  AS est_nombre,
	--ISNULL(V.montoJustificado,0)   as montoFaltante
	(select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale = 2
	WHERE  VFF.idTablaFondoFijo = FF.id) as montoReservado,
	(select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale = 3
	WHERE  VFF.idTablaFondoFijo = FF.id) as montoEntregado,
	(select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale = 4
	WHERE  VFF.idTablaFondoFijo = FF.id) - @RegresaEfectivo as montoJustificado,
	(select ISNULL(sum(V.montoJustificado),0) from  Tramite.valesFondoFijo VFF 
	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale = 4
	WHERE  VFF.idTablaFondoFijo = FF.id) as montoFaltante,
	TD.esDe_IdEstatus,
	FF.estatusFondoFijo,
	(select  ISNULL(SUM(VE.monto),0) 
	from  Tramite.valesFondoFijo VFF 
	INNER JOIN Tramite.vales V on VFF.idVales = V.id 
	INNER JOIN Tramite.valesEvidencia VE on Ve.idVales = V.id and VE.idEstatus = 2
	WHERE  VFF.idTablaFondoFijo =  FF.id and VE.envioReembolso is null and V.enviaReembolso is null) as montoEnvioReembolso,
	(select  ISNULL(SUM(VE.monto),0) 
	from  Tramite.valesFondoFijo VFF 
	INNER JOIN Tramite.vales V on VFF.idVales = V.id 
	INNER JOIN Tramite.valesEvidencia VE on Ve.idVales = V.id and VE.idEstatus = 2
	WHERE  VFF.idTablaFondoFijo =  FF.id and VE.estatusReembolso in(1,2)) + @RegresaEfectivo as montoReembolso,
	(select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
	INNER JOIN Tramite.vales V on VFF.idVales = V.id 
	WHERE  VFF.idTablaFondoFijo =  FF.id and v.estatusVale in (3,4)) as montoVales,
	@montoDisponible as montoAuxiliar
FROM [Tramite].[fondoFijo] FF
INNER JOIN personaTramite PT ON PT.id_perTra = FF.id_perTra
INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
LEFT JOIN cat_proceso_estatus PED ON PED.esDe_IdEstatus = TD.esDe_IdEstatus AND PED.idTipoTramite = 10
--LEFT JOIN Tramite.fondoFijoCambios FFC ON FFC.idTablaFondoFijo = FF.id
--LEFT JOIN Tramite.valesFondoFijo VFF ON VFF.idTablaFondoFijo = FF.id
--LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale = 4
WHERE FF.id_perTra = @idtramite

END
go

