-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTACYC_SP] 
	@id_perTra INT = 0
AS
BEGIN
			SELECT 
					 DCT.[id_docCycTra] AS id_docCycTra
					,cd.descripcion AS descripcion
					,cd.renglones AS renglones
					,DCT.[observacion] AS observacion
			FROM [Tramites].[dbo].[docCycTramite] DCT
			INNER JOIN [Tramites].[dbo].[cat_documentaCyC] CD ON CD.id = DCT.id_docCyc
			WHERE DCT.id_perTra = @id_perTra
END
go

