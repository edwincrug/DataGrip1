-- =============================================
-- Author:		Luis Garcia
-- Create date: 14/06/2019
-- Description:	Actualiza el estatus del document0
-- TEST UPD_APROBAR_ESTATUS_DOCUMENTO_SP 1
-- =============================================
CREATE PROCEDURE [dbo].[UPD_APROBAR_ESTATUS_DOCUMENTO_SP] 
	@det_idPerTra INT,
	@idUsuario INT = NULL
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY

	DECLARE @idPerTra INT;
	SELECT 
		@idPerTra = id_perTra 
	FROM detallePersonaTramite WHERE det_idPerTra = @det_idPerTra

	UPDATE detallePersonaTramite
	SET det_estatus = 2,
	det_observaciobes = ''
	WHERE det_idPerTra = @det_idPerTra;

	IF( @idUsuario IS NOT NULL )
		BEGIN
			INSERT INTO BitacoraTramite
			SELECT @idUsuario, @idPerTra, 'Se aprobo el documento con idDetalle ' + CONVERT(VARCHAR(20), @det_idPerTra), GETDATE(), NULL
		END

	SELECT success = 1, msg = 'Se aprobo el documento con éxito.'

COMMIT TRANSACTION
END TRY

BEGIN CATCH
ROLLBACK TRANSACTION
	SELECT success = 0;
END CATCH
END
go

