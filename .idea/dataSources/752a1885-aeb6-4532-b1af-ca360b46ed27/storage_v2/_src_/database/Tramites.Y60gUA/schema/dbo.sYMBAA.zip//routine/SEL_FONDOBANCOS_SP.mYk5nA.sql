
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <14/11/2019>
-- Description:	<SP que manda a reembolso el FF>
-- SEL_FONDOBANCOS_SP 85,1 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOBANCOS_SP] 
	@id_perTra INT,
	@tipo INT
AS
BEGIN
	
	IF(@tipo = 1)
	BEGIN
	SELECT
	FSE.idBancoSalida,
	FSE.idBancoEntrada
	FROM Tramite.fondoFijo FF
	LEFT JOIN [Tramite].[fondoFijoSalidaEfectivo] FSE ON FSE.idFondoFijo = FF.id
	WHERE FF.id_perTra  = @id_perTra
	END

	IF(@tipo = 2)
	BEGIN
	SELECT
	FSE.idBancoSalida,
	FSE.idBancoEntrada
	FROM Tramite.fondoFijo FF
	LEFT JOIN [Tramite].[fondoFijoReembolso] FSE ON FSE.idFondoFijo = FF.id
	WHERE FF.id_perTra  = @id_perTra
	END
END
go

