
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <16/10/2019>
-- Description:	<SP que manda a reembolso el FF>
-- SEL_FONDOFIJOXUSUARIO_SP 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJOREEMBOLSO_SP] 
	@id_traDe INT
AS
BEGIN
	DECLARE @id_perTra INT

	SELECT @id_perTra = id_perTra FROM tramiteDevoluciones WHERE id_traDe = @id_traDe

	UPDATE tramiteDevoluciones
	SET esDe_IdEstatus = 5
	WHERE id_traDe = @id_traDe

	UPDATE Tramite.fondoFijo
	SET estatusFondoFijo = 2, idReembolso = null
	WHERE id_perTra = @id_perTra
	
	UPDATE ve
	set ve.envioReembolso = 1
	from tramite.fondofijo ff
	inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	inner join tramite.vales v on v.id = vff.idvales
	inner join tramite.valesEvidencia ve on ve.idVales = v.id and ve.idestatus = 2
	where ff.id_perTra = @id_perTra  
	
	SELECT success = 1;
END
go

