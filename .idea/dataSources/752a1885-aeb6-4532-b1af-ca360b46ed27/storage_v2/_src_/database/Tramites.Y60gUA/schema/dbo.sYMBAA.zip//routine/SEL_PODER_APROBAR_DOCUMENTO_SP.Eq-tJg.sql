-- =============================================
-- Author:		Luis Garcia
-- Create date: 17/06/2019
-- Description:	SP para saber si se puede aprobar el tramite
-- TEST SEL_PODER_APROBAR_DOCUMENTO_SP 241


-- =============================================
CREATE PROCEDURE [dbo].[SEL_PODER_APROBAR_DOCUMENTO_SP]
@id_perTra INT,
@noCuentas INT = 0
AS
BEGIN

--DECLARE @id_perTra INT = 1073,
--		@noCuentas INT = 1

DECLARE  @total INT
		,@totalAprobado INT
		,@idTramite INT
		,@estatusTesoreria INT
		,@success INT 

	SELECT @idTramite = id_tramite , @estatusTesoreria = petr_estatus  FROM Tramites.dbo.personaTramite WHERE id_perTra =@id_perTra 
	
	IF(@idTramite = 1 OR @idTramite = 5 OR @idTramite = 2)
	BEGIN	
			DECLARE @totalDocs INT
					,@docsCompletos INT
					,@totalUp INT
					,@totalUpCuentas INT
					,@totalUpCuentasCompletas INT
					,@totalAprobCuentasTesoreria INT
					,@totalCuentasTesoreria INT
				      
			SELECT	@totalDocs = COUNT(id_tramite)       
			FROM	cat_tramiteDocumento       
			WHERE	id_tramite = @idTramite     

			SET @docsCompletos= @totalDocs + @noCuentas
			
									
			SELECT       
				 @totalUp = COUNT(id_perTra)       
			FROM detallePersonaTramite       
			WHERE id_perTra = @id_perTra  AND det_estatus = 2 
			
			

			SELECT       
				 @totalUpCuentas = COUNT(id_perTra)       
			FROM detallePersonaCuenta       
			WHERE id_perTra = @id_perTra AND det_estatus = 2  
			
			
			SELECT  @totalAprobCuentasTesoreria = Count(id_perTra)
			FROM detallePersonaCuenta       
			WHERE id_perTra = @id_perTra AND estatusTesoreria is NOT NULL  

			SELECT  @totalCuentasTesoreria = Count(id_perTra)
			FROM detallePersonaCuenta       
			WHERE id_perTra = @id_perTra 

			SELECT       
				 @totalUpCuentas = COUNT(id_perTra)       
			FROM detallePersonaCuenta       
			WHERE id_perTra = @id_perTra AND det_estatus = 2  

			
			SET @totalUpCuentasCompletas  =  @totalUpCuentas+ @totalUp    

      
			IF( @totalUpCuentasCompletas = @docsCompletos )      
				BEGIN
					SET @success = 1
				END
			ELSE
				BEGIN
					SET @success = 0
				END 

			IF(@estatusTesoreria = 11)
			BEGIN
				IF(@totalAprobCuentasTesoreria = @totalCuentasTesoreria)
				BEGIN
					SET @success = 1
				END
				ELSE
				BEGIN
					SET @success = 0
				END

			END

			SELECT @success success

							


	END
	ELSE
	BEGIN
			
			IF((SELECT origenBpro FROM tramiteDevoluciones where id_perTra = @id_perTra) = 1)
			BEGIN
				IF Exists(select 1 from detallePersonaTramite where id_perTra = @id_perTra )
					BEGIN
						SELECT 
							 @total=COUNT(dt.det_estatus) 
						FROM detallePersonaTramite dt 
						INNER JOIN  [Tramites].[dbo].[cat_tramiteDocumento] ct on ct.id_traDo = dt.id_traDo --AND ct.id_documento <> 11 AND ct.id_documento <> 50 --  discrimina dictamen 11
						WHERE dt.id_perTra = @id_perTra 
					END
					ELSE
					BEGIN
						SET @total = 1
					END


				
			END
			ELSE
			BEGIN
				SELECT 
				@total = COUNT(dt.det_estatus) 
				FROM detallePersonaTramite dt 
				INNER JOIN  [Tramites].[dbo].[cat_tramiteDocumento] ct on ct.id_traDo = dt.id_traDo --AND ct.id_documento <> 11 AND ct.id_documento <> 50 --  discrimina dictamen 11
				WHERE dt.id_perTra = @id_perTra 
			END
			
		
			
			
			SELECT 
				@totalAprobado = COUNT(det_estatus) 
			FROM detallePersonaTramite WHERE id_perTra = @id_perTra AND det_estatus = 2  
			IF(@idTramite = 4)
				BEGIN
					IF( @total = @totalAprobado )
						BEGIN
							IF( (SELECT traDe_conCC FROM tramiteDevoluciones WHERE id_perTra = @id_perTra) = 1 )
								BEGIN
									IF( (SELECT trade_banderaCC FROM tramiteDevoluciones WHERE id_perTra = @id_perTra) = 2 )
										BEGIN
											SELECT success = 1;
										END
									ELSE
										BEGIN
											SELECT success = 0;
										END
								END
							ELSE
								BEGIN
									SELECT success = 1;
								END
						END
					ELSE
						BEGIN
							SELECT success = 0
						END
				END
			ELSE
				BEGIN
					IF( @total = @totalAprobado )
						BEGIN
							SELECT success = 1
						END
					ELSE
						BEGIN
							SELECT success = 0
						END
				END
	END

END
go

