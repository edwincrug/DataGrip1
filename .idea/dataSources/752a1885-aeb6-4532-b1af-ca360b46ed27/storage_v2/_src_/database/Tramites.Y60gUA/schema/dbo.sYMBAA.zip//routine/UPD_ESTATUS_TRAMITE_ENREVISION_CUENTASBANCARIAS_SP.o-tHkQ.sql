-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <17/10/2019>
-- Description:	<Actualiza el estatus del tramitye de las cuentas bancarias>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_TRAMITE_ENREVISION_CUENTASBANCARIAS_SP]
	@idPerTra INT
AS
BEGIN
	DECLARE  @idEstatus INT;
	SELECT 
		@idEstatus = estatus
	FROM cuentasTesoreria
	WHERE id_perTra = @idPerTra

	IF(@idEstatus = 0)
		BEGIN
			UPDATE cuentasTesoreria SET estatus = 1 WHERE id_perTra = @idPerTra
		END

		IF( (SELECT id_tipoTramite FROM cuentasTesoreria WHERE id_perTra = @idPerTra) = 3 OR (SELECT id_tipoTramite FROM cuentasTesoreria WHERE id_perTra = @idPerTra) = 2 )
			BEGIN
				SELECT success = 1, urlAprobar = '/aprobarDev';
			END
		ELSE IF ( (SELECT id_tipoTramite FROM cuentasTesoreria WHERE id_perTra = @idPerTra) = 1 )
			BEGIN
				SELECT success = 1, urlAprobar = '/comprarOrden';
			END
			ELSE IF ( (SELECT id_tipoTramite FROM cuentasTesoreria WHERE id_perTra = @idPerTra) = 11 )
			BEGIN
				SELECT success = 1, urlAprobar = '/transferencia';
			END
			ELSE IF ( (SELECT id_tipoTramite FROM cuentasTesoreria WHERE id_perTra = @idPerTra) = 13 )
			BEGIN
				SELECT success = 1, urlAprobar = '/traspasosFondoFijo';
			END
END
go

