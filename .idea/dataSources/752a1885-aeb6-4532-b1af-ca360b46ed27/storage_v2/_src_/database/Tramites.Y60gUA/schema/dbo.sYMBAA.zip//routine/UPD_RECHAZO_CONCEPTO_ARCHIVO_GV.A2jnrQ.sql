-- =============================================
-- Author:		ROBERTO ALMANZA NIETO
-- Create date: 17/08/2020
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_RECHAZO_CONCEPTO_ARCHIVO_GV] 
	@idConceptoArchivo INT
	,@motivo varchar(255)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    update ca 
	set ca.motivoRechazo = @motivo
	,ca.fechaRechazo = GETDATE()
	FROM Tramite.ConceptoArchivo ca
	WHERE CA.idConceptoArchivo = @idConceptoArchivo

	SELECT 1 AS estatus, 'Se actualizo el archivo correctamente' as mensaje

END
go

