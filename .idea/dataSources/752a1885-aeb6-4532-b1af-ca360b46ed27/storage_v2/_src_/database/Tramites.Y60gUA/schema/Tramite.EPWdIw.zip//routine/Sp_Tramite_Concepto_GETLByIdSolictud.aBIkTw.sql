-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <03/09/2019>
-- Description:	<Recupera los conceptos contables de un empleado>
--TEST EXEC [Tramite].[Sp_Tramite_Concepto_GETLByIdSolictud] 1137, 1
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_Concepto_GETLByIdSolictud] 
	@idSolicitud INT,
	@idTipoProceso TINYINT
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	IF(@idTipoProceso IN (1,2)) BEGIN
		SELECT DISTINCT
			TED.idTramiteConcepto AS [id]
			,CC.idConceptoContable
			,CC.concepto
			,COALESCE(TIS.importe, 0) AS importeSolicitado
			,COALESCE(TIAS.importe, 0) AS [importeAprobado]			
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 1
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioSolicitud]
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 2
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
			,ET.esDe_descripcion AS [estatus]
			,ET.esDe_icono AS [icono]
			,TED.idEstatus
			,NULL AS [archivo]
		,'' AS [comentario]
		, 0 AS [expanded]
		,TED.idTipoProceso
		,areaAfectacion
		,numeroCuenta
		,'' AS [areaDescripcion]
		,CASE WHEN TED.idSalidaEfectivo IS NULL THEN 0 ELSE 1 END salidaEfectivo
		,ted.idTipoViaje
		,isnull(ted.distanciaKilometros, 0) as distanciaKilometros
		FROM tramiteDevoluciones td
		join [Tramite].[TramiteConcepto] TED
			on td.id_perTra = ted.idTramitePersona
		INNER JOIN [Tramite].[ConceptoContable] CC 
			ON TED.idConceptoContable = CC.idConceptoContable
			and td.id_empresa = cc.idEmpresa
			and td.id_sucursal = cc.idSucursal
		LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
		LEFT JOIN [Tramite].[TramiteImporte] TIAS ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
		INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
		WHERE TED.idTramitePersona = @idSolicitud 
	ORDER BY TED.idTramiteConcepto
	END
	IF(@idTipoProceso = 3) BEGIN
	SELECT 
		TED.idTramiteConcepto AS [id]
		,CC.idConceptoContable
		,CC.concepto
		,COALESCE((SELECT SUM(importe) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 2)	
		  ,(SELECT SUM(importe) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 1), 0) AS [importeSolicitado]
			,(SELECT COALESCE(SUM(TI.importe), 0) FROM [Tramite].[TramiteImporte]  TI
			inner join Tramite.[ConceptoArchivo] TC ON TC.idConceptoArchivo = TI.idConceptoArchivo
			WHERE   TED.idTramiteConcepto = TI.idTramiteConcepto AND TI.idTipoProceso = 3 and idEstatus = 9 ) AS [importeComprobado]
		,(SELECT COALESCE(SUM(importeiVa), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 3) AS [importeComprobadoIva]	
			,(SELECT COALESCE(SUM(importe), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 4) AS [importeAprobado]				
			,COALESCE((SELECT STUFF(
			(SELECT ', ' + comentario 
				FROM [Tramite].[TramiteComentario] 
				WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 3
			FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
			,COALESCE((SELECT STUFF(
			(SELECT ', ' + comentario 
				FROM [Tramite].[TramiteComentario] 
				WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 4
			FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioApComprobacion]
			,ET.esDe_descripcion AS [estatus]
			,ET.esDe_icono AS [icono]
		,TED.idEstatus
		,NULL AS [archivo]
		,'' AS [comentario]
		, 0 AS [expanded]
		,TED.idTipoProceso 
		,(SELECT COALESCE(SUM(porcentaje), 0) AS porcentaje 
			FROM [Tramite].[ConceptoArchivo] TCA
			INNER JOIN [Tramite].[ArchivoDepartamento] TAD ON TCA.idConceptoArchivo = TAD.idConceptoArchivo
			WHERE TCA.idReferencia = TED.idTramiteConcepto) AS [porcentaje]
		,CASE WHEN TED.idSalidaEfectivo IS NULL THEN 0 ELSE 1 END salidaEfectivo
	FROM tramiteDevoluciones td
		join [Tramite].[TramiteConcepto] TED
			on td.id_perTra = ted.idTramitePersona
		INNER JOIN [Tramite].[ConceptoContable] CC 
			ON TED.idConceptoContable = CC.idConceptoContable
			and td.id_empresa = cc.idEmpresa
			and td.id_sucursal = cc.idSucursal
	INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
	WHERE TED.idTramitePersona = @idSolicitud AND TED.idEstatus IN (0,2, 7, 8, 9)
	ORDER BY TED.idTramiteConcepto

	END
	IF(@idTipoProceso = 4) BEGIN
		SELECT 
			TED.idTramiteConcepto AS [id]
			,CC.idConceptoContable
			,CC.concepto
		,(SELECT COALESCE(SUM(importe), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 2) AS [importeSolicitado]	
			,(SELECT COALESCE(SUM(importe), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 4) AS [importeAprobado]	
			,(SELECT  COALESCE(SUM(ti.importe), 0) 
			FROM [Tramite].[TramiteImporte] ti
			inner join [Tramite].[ConceptoArchivo]  ca on ca.idConceptoArchivo = ti.idConceptoArchivo
			WHERE ti.idTramiteConcepto = TED.idTramiteConcepto AND ti.idTipoProceso = 3 and ca.idEstatus in (8,9)) AS [importeComprobado]
	
		,(SELECT COALESCE(SUM(importeiVa), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 3) AS [importeComprobadoIva]				
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 3
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 4
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioApComprobacion]
			,ET.esDe_descripcion AS [estatus]
			,ET.esDe_icono AS [icono]
			,TED.idEstatus
		, 0 AS [expanded]
		,TED.idTipoProceso 
		,CASE WHEN 	(SELECT TOP 1 1 FROM [Tramite].[ConceptoArchivo] where idReferencia = TED.idTramiteConcepto and idEstatus = 8) = 1 THEN 1 ELSE 0 END AS revisar
		,CASE WHEN TED.idSalidaEfectivo IS NULL THEN 0 ELSE 1 END salidaEfectivo
		FROM tramiteDevoluciones td
		join [Tramite].[TramiteConcepto] TED
			on td.id_perTra = ted.idTramitePersona
		INNER JOIN [Tramite].[ConceptoContable] CC 
			ON TED.idConceptoContable = CC.idConceptoContable
			and td.id_empresa = cc.idEmpresa
			and td.id_sucursal = cc.idSucursal
		INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
		WHERE TED.idTramitePersona = @idSolicitud AND TED.idEstatus IN (0,8, 9, 10)
		ORDER BY TED.idTramiteConcepto
	END

	IF(@idTipoProceso = 5) -- Para entrega de efectivo para gastos de más
	BEGIN
		SELECT DISTINCT
			TED.idTramiteConcepto AS [id]
			,CC.idConceptoContable
			,CC.concepto
			,COALESCE(TIS.importe, 0) AS importeSolicitado
			,COALESCE(TIAS.importe, 0) AS [importeAprobado]			
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 1
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioSolicitud]
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 2
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
			,ET.esDe_descripcion AS [estatus]
			,ET.esDe_icono AS [icono]
			,TED.idEstatus
			,NULL AS [archivo]
			,'' AS [comentario]
			, 0 AS [expanded]
			,TED.idTipoProceso
			,areaAfectacion
			,numeroCuenta
			,'' AS [areaDescripcion]
			,0 salidaEfectivo
			,ted.idTipoViaje
			,isnull(ted.distanciaKilometros,0) as distanciaKilometros
		FROM tramiteDevoluciones td
		join [Tramite].[TramiteConcepto] TED
			on td.id_perTra = ted.idTramitePersona
		INNER JOIN [Tramite].[ConceptoContable] CC 
			ON TED.idConceptoContable = CC.idConceptoContable
			and td.id_empresa = cc.idEmpresa
			and td.id_sucursal = cc.idSucursal
		LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
		LEFT JOIN [Tramite].[TramiteImporte] TIAS ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
		INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
		WHERE TED.idTramitePersona = @idSolicitud 
		ORDER BY TED.idTramiteConcepto
	END
	

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

