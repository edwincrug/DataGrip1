-- =============================================
-- Author:		
-- Create date: 08/08/2019
-- Description:	Trae los documento sa aprobar del usuario
--TEST SEL_DOCUMENTOS_APROBAR_BANCARIOS_SP 134, 'localhost'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_APROBAR_BANCARIOS_SP]
	@id_perTra INT,
	@urlParam VARCHAR(50)
AS
BEGIN
DECLARE @ruta VARCHAR(50) = '';

		IF(@urlParam = 'localhost')
			BEGIN
				SELECT 
					@ruta = pr_descripcion 
				FROM parametros 
				WHERE pr_identificador = @urlParam
			END
		ELSE
			BEGIN
				SELECT 
					@ruta = pr_descripcion 
				FROM parametros 
				WHERE pr_identificador = 'GET_SERVER'
			END

		SELECT 
					9 id_documento,
					nombreBanco + ' No. Cuenta: ' + DPETR.noCuenta + ' CLABE: ' + ISNULL(PB.clabe,'') AS nombreDoc,
					--'Estado de Cuenta '+ nombreBanco  AS nombreDoc,
					DPETR.idDetPersonaTramite AS detIdPerTra,
					@ruta + 'Persona_' + PER.per_rfc + '_' + CONVERT(varchar(10), PERTR.id_tramite) + '/' + 'Documento_9_' 
					+ idBanxico + '.pdf'   AS rutaDocumento,
					'pdf' AS idExtension,
					CASE WHEN DPETR.det_estatus = 2 THEN 'TRUE' ELSE 'FALSE' END AS estatusDoc,
					DPETR.det_estatus AS estatus,
					DPETR.det_observaciobes,
					DPETR.noCuenta,
					ISNULL(PB.clabe,'') clabe,
					isNULL(estatusTesoreria,0) estatusTesoreria


						--ISNULL(DPETR.clabe,'') clabe
					FROM detallePersonaCuenta DPETR
					INNER JOIN personaTramite PERTR ON PERTR.id_perTra = DPETR.id_perTra
					INNER JOIN personas PER ON PER.id_persona = PERTR.id_persona
					inner join Centralizacionv2.dbo.PROV_CUENTA_BANCARIA PB ON PB.noCuenta = DPETR.noCuenta AND  (PB.idProspecto = PER.id_Prospecto OR PB.rfcProspecto = PER.per_rfc) 
					
		WHERE DPETR.id_perTra = @id_perTra  
		
END

go

