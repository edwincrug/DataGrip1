
CREATE PROCEDURE SEL_SUCURSAL_RESUMEN_SP
@idUsuario INT,
@idEmpresa INT
AS
BEGIN
		SELECT DISTINCT S.suc_idsucursal idSucursal
						, S.suc_nombre  nombreSucursal
		FROM ControlAplicaciones.dbo.cat_sucursales S 
		INNER JOIN ControlAplicaciones.dbo.ope_organigrama O ON O.suc_idsucursal = S.suc_idsucursal
		WHERE O.usu_idusuario = @idUsuario and O.emp_idempresa = @idEmpresa
END
go

