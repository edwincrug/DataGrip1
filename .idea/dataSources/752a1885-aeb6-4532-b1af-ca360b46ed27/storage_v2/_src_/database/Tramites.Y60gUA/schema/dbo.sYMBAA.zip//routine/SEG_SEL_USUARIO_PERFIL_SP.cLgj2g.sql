

CREATE PROCEDURE [dbo].[SEG_SEL_USUARIO_PERFIL_SP]
@idUsuario INT 
AS
BEGIN

 

SELECT   idModulo
		,nombre
		,descripcion
		,[path]
		,class 
FROM (
		SELECT	 M.idModulo
				,nombre
				,descripcion
				,M.[path]
				,class
		from	Tramites.dbo.SEG_MODULO M
		INNER JOIN Tramites.[dbo].[SEG_Perfil_Modulo] PM ON M.idModulo = PM.idModulo
		INNER JOIN Tramites.[dbo].[SEG_Perfil_Usuario] PU ON PU.idPerfil = PM.idPerfil
		WHERE PU.idUsuario = @idUsuario
		UNION ALL

		select	 M.idModulo
				,nombre
				,descripcion
				,M.[path]
				,class
		from	Tramites.dbo.SEG_MODULO M
		INNER JOIN Tramites.dbo.SEG_Privilegio_Usuario PU ON M.idModulo = PU.idModulo
		WHERE PU.idUsuario = @idUsuario )  A 
WHERE  A.idModulo NOT IN (SELECT idModulo FROM Tramites.[dbo].[SEG_Restriccion_Usuario] R WHERE R.idUsuario = @idUsuario )

END
go

