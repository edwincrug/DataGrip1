-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_BANCOS_CVEBANXICO_SP]
AS
BEGIN
	SELECT    
		pbx_numoficial cveBanxico
		,pbx_descripcion nombreBanco
		,pbx_par_idenpara cveBanco
	FROM Pagos.[dbo].[PAG_CAT_BANXICO]
	ORDER BY  nombreBanco
END
go

