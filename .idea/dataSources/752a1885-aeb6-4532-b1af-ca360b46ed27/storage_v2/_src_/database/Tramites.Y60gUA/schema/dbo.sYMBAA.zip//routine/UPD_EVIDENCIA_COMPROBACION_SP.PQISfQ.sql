

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <15/06/2020>
-- Description:	<SP Actualiza el nombre de la evidencia de la comprobacion Mas>
-- UPD_EVIDENCIASRECHAZOFONDO_SP 1071
-- =============================================
CREATE PROCEDURE [dbo].[UPD_EVIDENCIA_COMPROBACION_SP] 
	@idValeEvidencia INT,
	@extension varchar(10)
AS
BEGIN

UPDATE tramite.valesEvidencia
SET comprobacionMasArchivo = 'comprobacionMas_' +CONVERT(VARCHAR(20),@idValeEvidencia) + '.' + @extension
WHERE id = @idValeEvidencia

SELECT 1 success

END
go

