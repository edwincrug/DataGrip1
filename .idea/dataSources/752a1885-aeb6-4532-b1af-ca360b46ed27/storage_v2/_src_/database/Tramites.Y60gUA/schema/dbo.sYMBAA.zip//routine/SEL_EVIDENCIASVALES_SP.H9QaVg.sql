-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [SEL_EVIDENCIASVALES_SP]   1215, 367
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EVIDENCIASVALES_SP] 
	@id_perTra INT,
	@idVale INT
AS
BEGIN
	DECLARE @url VARCHAR(500), @urlPro VARCHAR(500), @urlSave VARCHAR(500);
	SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');	
	--SET @url ='http://localhost:1220/Imagenes/'
	SET @urlPro = 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores'	


	SELECT @urlSave = pr_descripcion FROM parametros where pr_identificador = 'RUTA_SAVE_LOC'

	SELECT
	case when VE.idestatus = 1 then row_number() over( order by VE.idVales desc) end as fila,
	VE.idVales as idVale,
	VE.id as idValeEvidencia,
	case when VE.idGastoFondoFijo = 1 then 'pdf'
	else VE.extension end as tipoEvidencia,
	--CASE WHEN FV.idValeEvidencia is null THEN VE.monto ELSE FV.subTotal END as monto, 
	 VE.monto,
	CONVERT(varchar, VE.fechaCreacion, 103) as fechaCreacion,
	CASE WHEN VE.idfactura is null THEN 'N' ELSE 'S' END as esFactura, 
	ED.est_docEstatus as estatus,
	VE.idestatus,
	case when VE.idGastoFondoFijo = 1 then @urlPro + (    	
		SELECT '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4),DATEPART(yyyy,fecha_factura))+  '_'+
			RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,fecha_factura)))),2) +
			'/' + rfc_emisor + 	'_' + case when serie <> '' then serie else '' end + 
			folio + '.pdf'
		FROM 
			Centralizacionv2..PPRO_DATOSFACTURAS 
		WHERE 
			folioorden = FV.ordenCompra)
	else @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),@id_perTra) +'/Vales_'+ CONVERT(VARCHAR(20),VE.idVales)   + '/' + VE.archivo + '.' + VE.extension end as evidencia,
	VE.comentario,
	GFF.descripcion
	,ISNULL((select sum(porcentaje) from [Tramite].[ValeEvidenciaDepartamento] where idValeEvidencia = VE.id),0) as porcentaje
	,VE.idComprobacionVale
	,VE.areaAfectacion
	,VE.conceptoAfectacion
	,VE.tipoComprobante
	,VE.tipoIVA
	,VE.idGastoFondoFijo as tipoGasto
	,FV.PER_IDPERSONA as idProveedor
	,VE.estatusReembolso
	,V.idVale as nombreVale
	,FF.idEmpresa
	,FF.idSucursal
	,FF.idDepartamento
	,FV.mesCorriente 
	,FV.tipoNotificacion
	,FV.estatusNotificacion
	,FF.id as idFondo
	,FF.idFondoFijo
	,FF.id_perTra
	,ISNULL(VE.envioNotificacion,0) as envioNotificacion
	,usu.usu_nombre + ' ' + usu.usu_paterno + ' ' + usu.usu_materno as nombreSolicitante
	,usu.usu_correo as correoSolicitante
	,ISNULL(VE.compNoAutorizado,0) as compNoAutorizado
	,ISNULL(VE.comprobacionMas,0) as comprobacionMas
	,case when VE.comprobacionMasArchivo is null then '' 
	else   @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),@id_perTra) +'/Vales_'+ CONVERT(VARCHAR(20),VE.idVales)   + '/' + VE.comprobacionMasArchivo end as rutaComprobacionMas
	,@urlSave as urlSave
	,v.idDepartamento as idDepVale
	,VE.motivo
	,VE.idGastoFondoFijo
	FROM Tramite.valesEvidencia VE
	INNER JOIN Tramite.valesFondoFijo VFF ON VFF.idVales = VE.idVales
	INNER JOIN Tramite.fondoFijo FF ON FF.id = VFF.idTablaFondoFijo
	INNER JOIN dbo.estatusDocumentos ED ON ED.id_estatus = VE.idestatus
	INNER JOIN Tramite.vales V on V.id = VE.idVales
	INNER JOIN ControlAplicaciones.dbo.cat_usuarios usu on usu.usu_idusuario = v.idEmpleado
	LEFT JOIN [Tramite].[FacturaVale] FV ON FV.idValeEvidencia = VE.id
	LEFT JOIN [Tramite].[cat_gastosFondoFijo] GFF ON VE.idGastoFondoFijo = GFF.id
	WHERE FF.id_perTra = @id_perTra and VFF.idVales = @idVale
	ORDER BY VE.idComprobacionVale asc
END
go

