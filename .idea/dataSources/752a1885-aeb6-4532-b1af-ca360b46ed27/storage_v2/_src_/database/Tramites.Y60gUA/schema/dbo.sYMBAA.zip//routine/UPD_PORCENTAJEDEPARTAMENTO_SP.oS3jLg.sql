
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <03/12/2019>
-- Description:	<SP que actualiza el porcentaje la evidencia>
-- [dbo].[UPD_PORCENTAJEDEPARTAMENTO_SP]   85
-- =============================================
CREATE PROCEDURE [dbo].[UPD_PORCENTAJEDEPARTAMENTO_SP] 
	@idArchivoDepartamento INT,
	@porcentaje decimal(18,0)
AS
BEGIN
	
	UPDATE Tramite.[ArchivoDepartamento]
	SET porcentaje =  @porcentaje
	WHERE idArchivoDepartamento = @idArchivoDepartamento

	SELECT success = 1, msg = 'Se actualizo correctamente';

END
go

