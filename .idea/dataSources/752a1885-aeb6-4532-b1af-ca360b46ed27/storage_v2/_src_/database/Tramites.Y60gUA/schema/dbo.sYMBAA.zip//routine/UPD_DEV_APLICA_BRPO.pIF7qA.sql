-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <01/10/2019>
-- Description:	<SP que actualiza el campo docDe_aplicaBPRO en la tabla documentos devueltos para que no sean tomados en cuenta en las restas>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_DEV_APLICA_BRPO]
AS
BEGIN
	UPDATE DD 
		SET DD.docDe_aplicaBPRO = 0
	FROM documentosDevueltos AS DD
	INNER JOIN GA_Corporativa.DBO.cxc_devoluciones AS GD ON GD.CDE_AGRUPADOR = DD.id_traDe AND DD.docDe_documento = GD.cde_iddocto
	WHERE DD.docDe_aplicaBPRO = 0 AND GD.cde_estatus = 1 

		INSERT INTO [dbo].[logJob]
           ([fechaEjecucion])
     VALUES
           (GETDATE())

END
go

