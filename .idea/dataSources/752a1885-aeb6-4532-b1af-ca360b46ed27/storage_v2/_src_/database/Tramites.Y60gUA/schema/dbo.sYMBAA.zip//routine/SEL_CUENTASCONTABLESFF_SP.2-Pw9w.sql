-- =============================================
-- Author:		<JCPS>
-- Create date: <18/08/2020>
-- Description:	<Trae las cuentas contables por empresa y sucursal>
--TEST SEL_CUENTASCONTABLESFF_SP 4, 6 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CUENTASCONTABLESFF_SP]
     @idEmpresa INT = 0
    ,@idSucursal INT = 0
AS
BEGIN
	SELECT DISTINCT idempresa, idsucursal, cuenta, descripcion FROM Tramite.cat_CuentasContableFFGV
	WHERE  idempresa = @idempresa AND idsucursal = @idsucursal
END
go

