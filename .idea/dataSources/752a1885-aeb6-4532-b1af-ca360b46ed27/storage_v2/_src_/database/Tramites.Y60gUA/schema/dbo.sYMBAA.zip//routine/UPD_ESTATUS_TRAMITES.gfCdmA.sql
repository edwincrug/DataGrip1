

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_TRAMITES]
	@idPerTra int,
	@idEstatus int = -1,
	@EsDeEstatus int = -1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if( @idEstatus <> -1 and @EsDeEstatus = -1)
	begin
	   update pt
	   set petr_estatus = @idEstatus
		FROM personaTramite pt
		WHERE id_perTra = @idPerTra

		SELECT estatus = 1, mensaje = 'El tramite se actualizo correctamente'
	end

	if( @idEstatus = -1 and @EsDeEstatus <> -1)
	begin
	   update pt
	   set esDe_IdEstatus = @EsDeEstatus
		FROM personaTramite pt
		WHERE id_perTra = @idPerTra

		SELECT estatus = 1, mensaje = 'El tramite se actualizo correctamente'
	end

	if( @idEstatus <> -1 and @EsDeEstatus <> -1)
	begin
	   update pt
	   set esDe_IdEstatus = @EsDeEstatus
	   ,petr_estatus = @idEstatus
		FROM personaTramite pt
		WHERE id_perTra = @idPerTra

		SELECT estatus = 1, mensaje = 'El tramite se actualizo correctamente'
	end
END
go

