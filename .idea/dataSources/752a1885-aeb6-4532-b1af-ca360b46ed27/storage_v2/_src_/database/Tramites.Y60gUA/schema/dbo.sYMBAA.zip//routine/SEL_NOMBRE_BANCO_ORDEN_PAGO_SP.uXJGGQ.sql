-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_NOMBRE_BANCO_ORDEN_PAGO_SP]
	@idEmpresa INT,
	@idBanco INT,
	@idSucursal INT
AS
BEGIN
	SELECT 
		DISTINCT UPPER(nombre) BancoNombre
	FROM referencias.dbo.Banco banco
	INNER JOIN referencias.dbo.BancoCuenta bc
	ON banco.idBanco = bc.idBanco
	WHERE bc.idEmpresa = @idEmpresa AND bc.idBanco = @idBanco

	SELECT 
		emp_nombre
	FROM [ControlAplicaciones].[dbo].[cat_empresas] 
	WHERE emp_idempresa = @idEmpresa

	SELECT 
		nombre_sucursal 
	FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal
END
go

