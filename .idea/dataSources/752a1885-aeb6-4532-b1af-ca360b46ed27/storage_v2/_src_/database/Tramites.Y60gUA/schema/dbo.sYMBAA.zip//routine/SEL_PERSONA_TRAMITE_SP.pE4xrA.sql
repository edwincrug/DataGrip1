
CREATE PROCEDURE [dbo].[SEL_PERSONA_TRAMITE_SP]
@rfc VARCHAR(20)
AS
BEGIN
--DECLARE @rfc VARCHAR(20) = 'NME610911L47'
		SELECT  id_persona
				,per_rfc
				,per_nombre
				,per_apellido1
				,per_apellido2
				,per_moralFisica
				,per_cuentaBancaria
				,id_Prospecto
				,id_TipoProspecto  
		FROM	personas 
		WHERE per_rfc = @rfc

END

go

