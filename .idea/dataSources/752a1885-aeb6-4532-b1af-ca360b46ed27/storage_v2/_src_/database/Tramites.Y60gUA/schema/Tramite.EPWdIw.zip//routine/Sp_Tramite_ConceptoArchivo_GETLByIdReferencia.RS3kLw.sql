-- =============================================
-- Author:		<Fidel Ortega>
-- Create date: <21/02/2020>
-- Description:	<Obtiene los archivos por concepto>
--TEST EXEC [Tramite].[Sp_Tramite_ConceptoArchivo_GETLByIdReferencia] 1508, 'localhost'
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ConceptoArchivo_GETLByIdReferencia] 
	@idReferencia INT
	,@urlParametro VARCHAR(50)
AS
BEGIN 

	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	DECLARE @urlDoctos VARCHAR(100)

	
	IF(@urlParametro != '' AND @urlParametro = 'localhost') 
	BEGIN
		SELECT @urlDoctos = pr_descripcion FROM [dbo].[parametros] WHERE pr_identificador = 'Url_Local_ADG'
	END
	ELSE IF(@urlParametro != '') 
	BEGIN
		SELECT @urlDoctos = pr_descripcion + 'AnticipoGastos/ComprobacionSolicitud_' FROM [dbo].[parametros] WHERE pr_identificador = 'GET_SERVER'
	END

		 DECLARE @url VARCHAR(500);
  IF (@urlParametro = 'localhost')
  BEGIN
    SET @url = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = @urlParametro);
  END
  ELSE
  BEGIN
    SET @url = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = 'GET_SERVER');
  END

	SELECT 
		TCA.idConceptoArchivo
		,nombre + '.' + extension AS [nombre]
		,extension
		,COALESCE(total, 0) AS [total]
		,iva
		,folioDocumento
		,CAST(TCA.idConceptoArchivo AS varchar) + '_' + nombre + '.' + extension AS [nombreArchivo]
		,@urlDoctos +'ComprobacionSolicitud_'+ CAST(idReferencia AS VARCHAR(8)) + '\\' + CAST(TCA.idConceptoArchivo AS VARCHAR(8)) + '_' + nombre + '.' + extension AS [urlArchivo1]
		,(SELECT COALESCE(SUM(porcentaje), 0) AS porcentaje 
			FROM [Tramite].[ArchivoDepartamento] TAD
			WHERE TAD.idConceptoArchivo = TCA.idConceptoArchivo) AS [porcentaje]
		,idEstatus
		,idReferencia
		,(SELECT COALESCE(SUM(importe), 0) 
			FROM Tramite.TramiteImporte 
			WHERE idTramiteConcepto = TCA.idReferencia AND idConceptoArchivo = TCA.idConceptoArchivo) AS [aprobado]
		,CASE WHEN (TCA.idEstatus = 7) THEN 'Registrado'
			WHEN (TCA.idEstatus = 8) THEN 'En Revisión'
			WHEN (TCA.idEstatus = 9) THEN 'Aprobado'			
			WHEN (TCA.idEstatus = 10) THEN 'Rechazado' END AS [estatus]
		,COALESCE((SELECT STUFF((SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idConceptoArchivo = TCA.idConceptoArchivo AND idTipoProceso = 3
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
		,COALESCE((SELECT STUFF((SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idConceptoArchivo = TCA.idConceptoArchivo AND idTipoProceso = 4
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioAprobacion]
		,'' AS comentario
		,TCA.idTipoProceso
		,COALESCE(TI.importe, 0) AS [importe]
		,(select idConceptoContable from Tramite.TramiteConcepto where idTramiteConcepto = TCA.idReferencia) as idConceptoContable
		,ISNULL(TCA.tipoDevolucion,0) as tipoDevolucion
		,@url +'Comprobaciones\Comprobacion\ComprobacionSolicitud_'+ CAST(idReferencia AS VARCHAR(8)) + '\' + CAST(TCA.idConceptoArchivo AS VARCHAR(8)) + '_' + nombre + '.' + extension as [urlArchivo]
	FROM [Tramite].[ConceptoArchivo] TCA
	INNER JOIN cat_proceso_estatus CPE ON idTipoTramite = 9 AND TCA.idEstatus = CPE.esDe_IdEstatus
	LEFT JOIN [Tramite].[TramiteImporte] TI ON TI.idTramiteConcepto = TCA.idReferencia and TI.idTipoProceso = 3
	WHERE idReferencia = @idReferencia

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

