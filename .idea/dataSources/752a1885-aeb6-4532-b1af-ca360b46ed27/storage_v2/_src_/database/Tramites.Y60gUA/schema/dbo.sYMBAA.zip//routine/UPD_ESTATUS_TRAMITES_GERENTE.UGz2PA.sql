-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <22/08/2019>
-- Description:	<Cambia el estatus del tramite para ser visible al aprovador del corporativo>
-- TESET UPD_ESTATUS_TRAMITES_GERENTE 242, 1, 2
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_TRAMITES_GERENTE]
	@idPerTra INT,
	@petr_estatus INT,
	@esDe_Idestatus INT,
	@idUsuario INT = NULL
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY

	DECLARE @idTrade INT, @idEmpresa INT, @idSucursal INT, @nombreBase VARCHAR(50), @query NVARCHAR(MAX), @tipoDePago VARCHAR(5), @ParmDefinition nvarchar(500);;
	SELECT 
		@idTrade = id_traDe,
		@idEmpresa = id_empresa,
		@idSucursal = id_sucursal
	FROM tramiteDevoluciones WHERE id_perTra = @idPerTra;
	
	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SET @query = N'SELECT ' + CHAR(13) +
					CHAR(9) + '@tipoPagoOUT = PNC.PAR_IDENPARA' + CHAR(13) +
				'FROM ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] AS PNC' + CHAR(13) +
				'WHERE PAR_TIPOPARA = ''FP'' AND' + CHAR(13) +
				'PAR_DESCRIP1 = ''C. EFECTIVO C.'''

	SET @ParmDefinition = N'@tipoPagoOUT VARCHAR(5) OUTPUT'
	EXECUTE sp_executesql @query, @ParmDefinition, @tipoPagoOUT = @tipoDePago OUTPUT;
	
		
	IF( (SELECT petr_estatus FROM personaTramite WHERE id_perTra = @idPerTra) = 6 AND (SELECT esDe_IdEstatus FROM tramiteDevoluciones WHERE id_traDe = @idTrade) = 1 )
		BEGIN
			IF EXISTS (SELECT docDe_tipoPago FROM documentosDevueltos WHERE id_traDe = @idTrade AND docDe_tipoPago = ISNULL(@tipoDePago, '0'))
				BEGIN
					UPDATE tramiteDevoluciones SET traDe_conCC = 1, traDe_banderaCC = 0 WHERE id_traDe = @idTrade
				END
			ELSE
				BEGIN
					UPDATE tramiteDevoluciones SET traDe_conCC = 0, trade_banderaCC = 0 WHERE id_traDe = @idTrade
				END

			UPDATE personaTramite SET petr_estatus = @petr_estatus WHERE id_perTra = @idPerTra;
			UPDATE tramiteDevoluciones SET esDe_IdEstatus = @esDe_Idestatus WHERE id_traDe = @idTrade;

			IF(@idUsuario IS NOT NULL)
				BEGIN
					INSERT INTO BitacoraTramite
					SELECT @idUsuario, @idPerTra, 'Se envio el tràmite al coporativo', GETDATE(),@esDe_Idestatus;
				END
			
			SELECT success = 1, msg = 'Se envió el trámite.';
		END
	ELSE
		BEGIN
			SELECT success = 0;
		END

COMMIT TRANSACTION
END TRY

BEGIN CATCH
ROLLBACK TRANSACTION
	SELECT success = 0;
END CATCH
END
go

