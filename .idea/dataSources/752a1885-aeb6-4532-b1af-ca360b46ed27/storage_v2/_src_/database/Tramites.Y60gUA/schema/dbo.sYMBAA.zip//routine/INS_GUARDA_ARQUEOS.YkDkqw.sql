
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_GUARDA_ARQUEOS] 
	-- Add the parameters for the stored procedure here
	@cabecero nvarchar(max),
	@detalle nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    INSERT INTO Tramites.dbo.arqueo (idUsuario)
	select cast(@cabecero as int)

	insert into Tramites.dbo.arqueoDetalle (idMoneda)
	select cast(@detalle as int)

	select 1 as estatus, 'Información almacenda correctamente' as mensaje--, @identity as folio
END
go

