


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATA_ORDEN_PAGO_FF_SP]  
	@idPerTra INT,
	@tipoProceso INT = 0,
	@consecutivoTramite INT = 0
AS
BEGIN
	 
		DECLARE @estatusFF INT
		SELECT @estatusFF = estatusFondoFijo FROM Tramite.fondofijo where id_perTra = @idPerTra 
		IF (@tipoProceso = 1)
		BEGIN
		SELECT 
		TD.id_perTra,
		TD.id_traDe,
		--TD.traDe_devTotal,
		CT.monto as traDe_devTotal,
		TD.id_empresa,
		TD.id_sucursal,
		TD.id_departamento,
		TD.PER_IDPERSONA,
		FFSE.idBancoSalida as efectivoBanco,
		FFSE.numCuentaSalida as efectivoCuenta,
		CT.estatus, 
		'FS' as identificador,
		FF.cuentaContable,
		FFSE.cuentaContableSalida,
		FF.idFondoFijo,
		D.dep_nombrecto
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN Tramite.fondofijo FF ON FF.id_perTra = TD.id_perTra
	INNER JOIN Tramite.fondoFijoSalidaEfectivo FFSE ON FFSE.idFondoFijo = FF.id and FFSE.id = @consecutivoTramite
	INNER JOIN cuentasTesoreriaFA CT ON CT.id_perTra = PT.id_perTra and CT.tipo = 1 and CT.consecutivo = @consecutivoTramite
	INNER JOIN ControlAplicaciones.dbo.cat_departamentos D on D.dep_iddepartamento = TD.id_departamento
	WHERE PT.id_perTra =  @idPerTra
	END
	ELSE
	BEGIN
		SELECT 
		TD.id_perTra,
		TD.id_traDe,
		--TD.traDe_devTotal,
		CT.monto as traDe_devTotal,
		TD.id_empresa,
		TD.id_sucursal,
		TD.id_departamento,
		TD.PER_IDPERSONA,
		FFSE.idBancoSalida as efectivoBanco,
		FFSE.numCuentaSalida as efectivoCuenta,
		CT.estatus,
		'FR' as identificador,
		FF.cuentaContable,
		FFSE.cuentaContableSalida,
		FF.idFondoFijo,
		D.dep_nombrecto
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN Tramite.fondofijo FF ON FF.id_perTra = TD.id_perTra
	INNER JOIN Tramite.fondoFijoReembolso FFSE ON FFSE.idFondoFijo = FF.id  and FFSE.id = @consecutivoTramite
	INNER JOIN cuentasTesoreriaFA CT ON CT.id_perTra = PT.id_perTra and CT.tipo = 2 and CT.consecutivo = @consecutivoTramite
	INNER JOIN ControlAplicaciones.dbo.cat_departamentos D on D.dep_iddepartamento = TD.id_departamento
	WHERE PT.id_perTra =  @idPerTra
	END
END
go

