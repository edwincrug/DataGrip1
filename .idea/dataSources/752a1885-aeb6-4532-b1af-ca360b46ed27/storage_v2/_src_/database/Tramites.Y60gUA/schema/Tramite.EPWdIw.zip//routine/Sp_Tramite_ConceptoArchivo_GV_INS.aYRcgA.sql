-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <03/09/2019>
-- Description:	<Almacena el concepto de una solicitud>
--TEST EXEC [Tramite].[Sp_Tramite_ConceptoArchivo_GV_INS] 'Vale_AnticipoGastos (10)', 'pdf', 1508, 1,0
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ConceptoArchivo_GV_INS] @nombre VARCHAR(150)
, @extension VARCHAR(10)
, @idTramiteConcepto INT
, @idProceso INT
, @tipoDevolucion INT = 0
AS
BEGIN

  SET NOCOUNT ON;

  DECLARE @resultado INT;
  DECLARE @VI_ZERO INT = 0
         ,@VC_ErrorMessage NVARCHAR(4000) = ''
         ,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_Concepto_INS] :'
         ,@VI_ErrorSeverity INT = 0
         ,@VI_ErrorState INT = 0
         ,@VI_CountResult INT = 0

  DECLARE @area VARCHAR(20)
         ,@idComprobacionConcepto VARCHAR(100)
         ,@incremental INT
         ,@documentoConcepto VARCHAR(100)
         ,@id_perTra INT
         ,@numTramite INT


  BEGIN TRY
    BEGIN TRANSACTION TrnxInsTramite

    IF EXISTS (SELECT
          1
        FROM [Tramite].[ConceptoArchivo]
        WHERE idReferencia = @idTramiteConcepto
        AND nombre = @nombre)
    BEGIN

      SET @idProceso = 1
      PRINT 'PROCESO ' + CAST(@idProceso AS VARCHAR(5))
    END
    ELSE
    BEGIN
      SET @idProceso = 2
      PRINT 'PROCESO ' + CAST(@idProceso AS VARCHAR(5))
    END

    IF (@idProceso = 1)
    BEGIN
      PRINT 'ENTRO EN 1'
      SELECT
        @resultado = COALESCE(idConceptoArchivo, 0)
      FROM [Tramite].[ConceptoArchivo]
      WHERE idReferencia = @idTramiteConcepto --AND idTipoProceso = @idProceso 

      IF (@resultado != 0)
      BEGIN
        UPDATE [Tramite].[ConceptoArchivo]
        SET nombre = @nombre
           ,extension = @extension
           ,tipoDevolucion = @tipoDevolucion
        WHERE idReferencia = @idTramiteConcepto
        AND idTipoProceso = @idProceso
      END
    END

       IF (@idProceso = 2)
       BEGIN

         PRINT 'ENTRO'
         PRINT CAST(@idTramiteConcepto AS VARCHAR(10))

         --SELECT DISTINCT
         --  @documentoConcepto = documentoConcepto
         --FROM tramite.TramiteConcepto
         --WHERE idTramitePersona = @idTramiteConcepto
         --SELECT DISTINCT
         --  @id_perTra = idtramitePersona
         -- ,@numTramite = ProcesadoOP
         --FROM tramite.tramiteconcepto
         --WHERE idTramitePersona = @idTramiteConcepto
         --SELECT
         --  @incremental = COUNT(idConceptoArchivo)
         --FROM [Tramite].[ConceptoArchivo]
         --WHERE idReferencia IN (SELECT
         --    idtramiteConcepto
         --  FROM tramite.tramiteconcepto
         --  WHERE idtramitePersona = @id_perTra
         --  AND ProcesadoOP = @numTramite)
         --SET @incremental = @incremental + 1;

         SET @idComprobacionConcepto = @documentoConcepto + '-' + CONVERT(VARCHAR(10), @incremental)
			select  @documentoConcepto = documentoConcepto from tramite.TramiteConcepto where idTramiteConcepto = @idTramiteConcepto
			select @id_perTra = idtramitePersona, @numTramite = ProcesadoOP  from tramite.tramiteconcepto where idtramiteconcepto = @idTramiteConcepto
			select @incremental =  COUNT(idConceptoArchivo) from [Tramite].[ConceptoArchivo] where idReferencia in 
			(select idtramiteConcepto from tramite.tramiteconcepto where idtramitePersona = @id_perTra and ProcesadoOP =  @numTramite)
			--select @incremental =  COUNT(idConceptoArchivo) from [Tramite].[ConceptoArchivo] where idReferencia = @idTramiteConcepto
			--select @area = areaAfectacion from Tramite.TramiteConcepto where idTramiteConcepto = @idTramiteConcepto
			SET @incremental = @incremental + 1;
			SET @idComprobacionConcepto = @documentoConcepto  + '-' + CONVERT(varchar(10), @incremental) 

         PRINT @documentoConcepto
         PRINT CAST(@id_perTra AS VARCHAR(10))
         PRINT CAST(@incremental AS VARCHAR(10))
         PRINT @idComprobacionConcepto

         INSERT INTO [Tramite].[ConceptoArchivo] (nombre, extension, idReferencia, idTipoProceso, idEstatus, idComprobacionConcepto, tipoDevolucion, fecha)
           VALUES (@nombre, @extension, @idTramiteConcepto, @idProceso, 7, @idComprobacionConcepto, @tipoDevolucion, GETDATE())
         SET @resultado = SCOPE_IDENTITY()
       END


    COMMIT TRANSACTION TrnxInsTramite
  END TRY
  BEGIN CATCH
    SELECT
      @VC_ErrorMessage = ERROR_MESSAGE()
     ,@VI_ErrorSeverity = ERROR_SEVERITY()
     ,@VI_ErrorState = ERROR_STATE();
    IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
    BEGIN
      ROLLBACK TRANSACTION TrnxInsTramite
      SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
      RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
    END
  END CATCH

  SET NOCOUNT OFF

  SELECT
    @resultado AS [resultado]
   ,@incremental AS consecutivo
END
go

