
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC [SEL_DATA_REPORTE_CONTRALORIA] 40
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATA_REPORTE_CONTRALORIA]
	@id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @idArqueo int = 0
	 DECLARE @valesabiertos TABLE(numero VARCHAR(10), fechaExpedicion VARCHAR(10), solicitante VARCHAR(150), cantidad DECIMAL(18,2),autorizadoDeMas decimal(18,2), comprobada DECIMAL(18,2), porComprobar  DECIMAL(18,2))

	/*
	  CABECERA
	 */

	SELECT
	 id = f.id
	 ,idFondoFijo = f.idFondoFijo
	 ,CONVERT(VARCHAR(10),GETDATE(),103) AS fecha--CONVERT(VARCHAR(10),f.fechaCreacion,103) AS fecha  
	 ,CONVERT(VARCHAR(8), GETDATE(), 108) AS hora --CONVERT(VARCHAR(8), f.fechaCreacion, 108) AS hora
	 ,agencia =  dcer.RazonSocial 
	 ,sucursal = cs.suc_nombre
	 ,departamento = cd.dep_nombre
	 ,responsable = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	 ,monto =td.traDe_devTotal
	FROM Tramites.Tramite.fondoFijo f
	JOIN ControlAplicaciones.dbo.cat_departamentos cd
	  ON f.idDepartamento = cd.dep_iddepartamento
	JOIN ControlAplicaciones.dbo.cat_sucursales cs
	  ON cd.suc_idsucursal = cs.suc_idsucursal
	JOIN ControlAplicaciones..cat_usuarios cu
	  ON f.idResponsable = cu.usu_idusuario
	JOIN Centralizacionv2.dbo.DIG_CAT_EMPRESA_RAZON dcer
	  on dcer.IdEmpresa = f.idEmpresa
	JOIN Tramites..tramiteDevoluciones td
	  ON f.id_perTra = td.id_perTra
	WHERE f.id = @id

	/*
	  VALES ABIERTOS
	*/
	INSERT INTO @valesabiertos
 --   SELECT distinct
 --     numero = v.id
 --    ,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fechaExpedicion
 --    ,(pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO) AS solicitante
 --    ,(v.montoSolicitado) AS cantidad
	-- ,CASE
 --       WHEN (v.montoSolicitado - v.montoJustificado) < 0 THEN (abs(v.montoSolicitado - v.montoJustificado))
 --       ELSE (0)
 --     END AS autorizadoDeMas
 --   ,(v.montoJustificado - SUM(ISNULL(e.monto,0)) OVER (PARTITION BY v.id)) AS comprobada --,(v.montoJustificado) AS comprobada
 --    ,CASE
 --       WHEN (v.montoSolicitado - v.montoJustificado) < 0 THEN (0)
 --       ELSE (v.montoSolicitado - v.montoJustificado) + SUM(ISNULL(e.monto,0)) OVER (PARTITION BY v.id)
 --     END AS porComprobar
 --   FROM Tramites.Tramite.vales v
 --   JOIN GA_Corporativa..PER_PERSONAS pp
 --     ON v.PER_IDPERSONA = pp.PER_IDPERSONA
	--LEFT JOIN Tramite.valesEvidencia e
	--    ON v.id = e.idVales
 --   --AND e.envioReembolso = 1
	----AND e.estatusReembolso = 2
 --   WHERE v.id IN (SELECT
 --       ff.idVales
 --     FROM Tramites.Tramite.valesFondoFijo ff
 --     WHERE ff.idTablaFondoFijo = @id)
 --   --AND v.estatusVale IN (2, 3)
	--AND v.estatusVale IN (3
	
	select 
	v.id as numero
	,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fechaExpedicion
    ,(pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO) AS solicitante
	,(v.montoSolicitado) AS cantidad
	,case when ISNULL((select SUM(monto) from Tramite.valesEvidencia where idVales  = v.id),0) > v.montoSolicitado
	then ISNULL((select SUM(monto) from Tramite.valesEvidencia where idVales  = v.id),0) - v.montoSolicitado
	else 0 end  as autorizadoDeMas
	--,ISNULL((select SUM(monto) from Tramite.valesEvidencia where idVales  = v.id),0) as comprobada
	,ISNULL((select SUM(monto) from Tramite.valesEvidencia where idVales  = v.id and procesoPoliza = 1 and idestatus not in (3)),0) as comprobada
	--,v.montoSolicitado - ISNULL((select SUM(monto) from Tramite.valesEvidencia where idVales  = v.id and procesoPoliza = 1 and idestatus = 2),0) as porComprobar
		,v.montoSolicitado + case when ISNULL((select SUM(monto) from Tramite.valesEvidencia where idVales  = v.id and idestatus in (2,3) and procesopoliza = 1),0) > v.montoSolicitado
	then ISNULL((select SUM(monto) from Tramite.valesEvidencia where idVales  = v.id and idestatus in (2,3) and procesopoliza = 1),0) - v.montoSolicitado
	else 0 end - ISNULL((select SUM(monto) from Tramite.valesEvidencia where idVales  = v.id and procesoPoliza = 1 and idestatus = 2),0) as porComprobar
	--,(v.montoSolicitado) as porComprobar
	from tramite.valesFondoFijo vff
	inner join Tramite.vales v on v.id = vff.idvales
	inner join GA_Corporativa..PER_PERSONAS pp ON v.PER_IDPERSONA = pp.PER_IDPERSONA
	where vff.idtablafondofijo = @id and v.estatusVale in (3)

	 
	 SELECT numero
          ,fechaExpedicion
          ,solicitante = COALESCE(solicitante, 'TOTALES')
          ,cantidad = SUM(cantidad)
		  ,autorizadoDeMas = sum(autorizadoDeMas)
          ,comprobada= SUM(comprobada)
          ,porComprobar= SUM(porComprobar) 
      FROM @valesabiertos
	GROUP BY GROUPING SETS((numero, fechaExpedicion, solicitante ),())
	--having sum(porComprobar) >0

	--SELECT
	-- numero = v.id
	-- ,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fechaExpedicion
	-- ,COALESCE(pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO, 'TOTALES') AS solicitante
	-- ,sum(v.montoSolicitado) AS cantidad
	-- ,sum(v.montoJustificado) AS comprobada
	-- ,case when  sum(v.montoSolicitado - v.montoJustificado) < 0 then sum(0) else sum(v.montoSolicitado - v.montoJustificado) end AS porComprobar
	--FROM Tramites.Tramite.vales v
	--JOIN GA_Corporativa..PER_PERSONAS pp
	--  ON v.PER_IDPERSONA = pp.PER_IDPERSONA
	--WHERE v.id IN (SELECT
	--	ff.idVales
	--  FROM Tramites.Tramite.valesFondoFijo ff
	--  WHERE ff.idTablaFondoFijo = @id)
	--AND v.estatusVale IN (2,3)
	--GROUP BY GROUPING SETS((v.id, CONVERT(VARCHAR(10), v.fechaCreacionVale, 103), pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO ),())


	/*
	  COMPROBANTES PENDIENTES
	*/
	--SELECT
	--isnull(fv.numFactura,e.archivo) AS factura
	--,isnull(COALESCE(v.descripcion,'TOTAL'),'') AS concepto
	--,isnull(pp.PER_NOMRAZON,'') AS proveedor
	--,isnull(convert(varchar(10),fv.fechaFactura,103),'') AS fecha
	--,sum(isnull(e.monto,0)) AS cantidad
	--FROM tramite.valesFondoFijo ff
	--JOIN tramite.vales v
	--ON ff.idVales = v.id
	--JOIN Tramite.valesEvidencia e
	--ON e.idVales = v.id
	----AND e.envioReembolso is NULL
	--LEFT JOIN tramites.[Tramite].[FacturaVale] fv
	--ON e.idfactura = fv.id
	--LEFT JOIN GA_Corporativa..PER_PERSONAS pp
	--ON fv.PER_IDPERSONA  = pp.PER_IDPERSONA
	--WHERE ff.idTablaFondoFijo = @id
	----AND v.estatusVale = 4
	--AND v.estatusVale = 4 AND e.envioReembolso IS NULL
	--GROUP BY GROUPING SETS((fv.numFactura,v.descripcion,pp.PER_NOMRAZON,convert(varchar(10),fv.fechaFactura,103),e.id,e.archivo),())
 
 --	SELECT
	--isnull(fv.numFactura,e.archivo) AS factura
	--,isnull(COALESCE(v.descripcion,'TOTAL'),'') AS concepto
	--,isnull(pp.PER_NOMRAZON,(select usu_nombre + ' '+ usu_paterno +' ' + usu_materno from controlaplicaciones.dbo.cat_usuarios where usu_idusuario = v.idempleado) ) AS proveedor
	--,isnull(convert(varchar(10),fv.fechaFactura,103),convert(varchar(10),e.fechaCreacion,103)) AS fecha
	--,sum(isnull(e.monto,0)) AS cantidad
	--from Tramite.valesEvidencia e 
	--inner join Tramite.vales v on v.id = e.idVales
	--inner join Tramite.valesFondoFijo ff on ff.idVales = v.id
	--LEFT JOIN tramites.[Tramite].[FacturaVale] fv ON e.idfactura = fv.id
	--LEFT JOIN GA_Corporativa..PER_PERSONAS pp ON fv.PER_IDPERSONA  = pp.PER_IDPERSONA
	--where ff.idTablaFondoFijo = @id and e.procesoPoliza = 1 and e.envioReembolso is null
	--GROUP BY GROUPING SETS((fv.numFactura,v.descripcion,pp.PER_NOMRAZON,convert(varchar(10),fv.fechaFactura,103),convert(varchar(10),e.fechaCreacion,103),e.id,e.archivo,  v.idempleado),())

	SELECT
	isnull(fv.numFactura,e.archivo) AS factura
	,isnull(COALESCE(e.motivo,'TOTAL'),'') AS concepto
	,isnull(pp.PER_NOMRAZON,(select usu_nombre + ' '+ usu_paterno +' ' + usu_materno from controlaplicaciones.dbo.cat_usuarios where usu_idusuario = v.idempleado) ) AS proveedor
	,isnull(convert(varchar(10),fv.fechaFactura,103),convert(varchar(10),e.fechaCreacion,103)) AS fecha
	,sum(isnull(e.monto,0)) AS cantidad
	from Tramite.valesEvidencia e 
	inner join Tramite.vales v on v.id = e.idVales
	inner join Tramite.valesFondoFijo ff on ff.idVales = v.id
	LEFT JOIN tramites.[Tramite].[FacturaVale] fv ON e.idfactura = fv.id
	LEFT JOIN GA_Corporativa..PER_PERSONAS pp ON fv.PER_IDPERSONA  = pp.PER_IDPERSONA
	where ff.idTablaFondoFijo = @id  and e.envioReembolso is null and e.idestatus = 2 --and e.procesoPoliza = 1
	GROUP BY GROUPING SETS((fv.numFactura,e.motivo,pp.PER_NOMRAZON,convert(varchar(10),fv.fechaFactura,103),convert(varchar(10),e.fechaCreacion,103),e.id,e.archivo,  v.idempleado),())


	--SELECT
	--  isnull(fv.numFactura,'') AS factura
	--  ,isnull(v.descripcion,'') AS concepto
	--  ,isnull(pp.PER_NOMRAZON,'') AS proveedor
	--  , isnull(COALESCE(convert(varchar(10),fv.fechaFactura,103),'TOTAL'),'') AS fecha
	--  , sum(isnull(fv.total,0)) AS cantidad
	--FROM Tramites.Tramite.vales v
	--JOIN tramites.Tramite.valesEvidencia e
	--ON v.id = e.idVales
	--and e.envioReembolso is null
	--LEFT JOIN tramites.[Tramite].[FacturaVale] fv
	--  ON e.idfactura = fv.id
	--LEFT JOIN GA_Corporativa..PER_PERSONAS pp
	--  ON fv.PER_IDPERSONA  = pp.PER_IDPERSONA
	--WHERE v.id IN (SELECT
	--	ff.idVales
	--  FROM Tramites.Tramite.valesFondoFijo ff
	--  WHERE ff.idTablaFondoFijo = @id)
	--AND v.estatusVale IN (4)
	--and len(convert(varchar(10),fv.fechaFactura,103))> 0
	--GROUP BY GROUPING SETS((fv.numFactura,v.descripcion,pp.PER_NOMRAZON,convert(varchar(10),fv.fechaFactura,103)),())

	/*
	  REEMBOLSO YA SOLICITADO
	*/
	--SELECT
	--  cast(v.id as varchar(10)) AS numero
	-- ,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fecha
 --,COALESCE(pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO,'TOTAL') AS solicitante
	-- ,sum(isnull(e.montoPoliza,0)) AS cantidad
	--FROM Tramites.Tramite.vales v
	--JOIN GA_Corporativa..PER_PERSONAS pp
	--  ON v.PER_IDPERSONA = pp.PER_IDPERSONA
	--JOIN Tramites.tramite.valesEvidencia e
 --   ON v.id = e.idVales 
	--and e.envioReembolso = 1
	----and montoPoliza is not null
	--and (e.estatusReembolso is null or e.estatusReembolso = 2)
	--WHERE v.id IN (SELECT
	--	ff.idVales
	--  FROM Tramites.Tramite.valesFondoFijo ff
	--  WHERE ff.idTablaFondoFijo = @id)
	--AND v.estatusVale IN (4)
	--GROUP BY GROUPING SETS((v.id, CONVERT(VARCHAR(10), v.fechaCreacionVale, 103), pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO ),())

	
	--SELECT
	--ISNULL(fv.numFactura, e.archivo) as numero
	--,ISNULL(CONVERT(VARCHAR(10), fv.fechaFactura, 103), CONVERT(VARCHAR(10), e.fechaCreacion, 103) ) AS fecha
 --   ,COALESCE(ISNULL(PER_NOMRAZON,(select usu_nombre + ' '+ usu_paterno +' ' + usu_materno from controlaplicaciones.dbo.cat_usuarios where usu_idusuario = v.idempleado )),'TOTAL') AS solicitante
	--,sum(isnull(e.monto,0)) AS cantidad
	--FROM Tramites.Tramite.vales v
	--JOIN Tramites.tramite.valesEvidencia e ON v.id = e.idVales  and e.envioReembolso = 1 and (e.estatusReembolso is null or e.estatusReembolso = 2)
	--LEFT JOIN Tramite.FacturaVale fv on fv.id = e.idfactura
	--INNER JOIN GA_Corporativa..PER_PERSONAS pp ON fv.PER_IDPERSONA = pp.PER_IDPERSONA
	--WHERE v.id IN (SELECT ff.idVales FROM Tramites.Tramite.valesFondoFijo ff WHERE ff.idTablaFondoFijo = @id)
	--AND v.estatusVale IN (4)
	----GROUP BY GROUPING SETS(( CONVERT(VARCHAR(10), v.fechaCreacionVale, 103), pp.PER_NOMRAZON),())
	--GROUP BY GROUPING SETS((fv.numFactura,e.archivo,convert(varchar(10),fv.fechaFactura,103),convert(varchar(10),e.fechaCreacion,103),pp.PER_NOMRAZON, v.idempleado),())


		SELECT
	 ISNULL(fv.numFactura, e.archivo) as numero
	 ,ISNULL(CONVERT(VARCHAR(10), fv.fechaFactura, 103), CONVERT(VARCHAR(10), e.fechaCreacion, 103)) AS fecha
      ,COALESCE(ISNULL(PER_NOMRAZON,(select usu_nombre + ' '+ usu_paterno +' ' + usu_materno from controlaplicaciones.dbo.cat_usuarios where usu_idusuario = v.idempleado )),'TOTAL') AS solicitante
	 ,sum(isnull(e.monto,0)) AS cantidad
	FROM Tramites.Tramite.vales v
	JOIN Tramites.tramite.valesEvidencia e ON v.id = e.idVales  and e.envioReembolso = 1 and (e.estatusReembolso is null or e.estatusReembolso = 2 or e.estatusReembolso = 0) and idestatus = 2
	LEFT JOIN Tramite.FacturaVale fv on fv.id = e.idfactura
	LEFT JOIN GA_Corporativa..PER_PERSONAS pp ON fv.PER_IDPERSONA = pp.PER_IDPERSONA
	WHERE v.id IN (SELECT ff.idVales FROM Tramites.Tramite.valesFondoFijo ff WHERE ff.idTablaFondoFijo = @id)
	AND v.estatusVale IN (3,4,6)  and envioReembolso = 1
	--GROUP BY GROUPING SETS(( CONVERT(VARCHAR(10), v.fechaCreacionVale, 103), pp.PER_NOMRAZON),())
	GROUP BY GROUPING SETS((fv.numFactura,e.archivo,convert(varchar(10),fv.fechaFactura,103),convert(varchar(10),e.fechaCreacion,103),pp.PER_NOMRAZON,v.idempleado  ),())
	

	/*arqueo*/
  SELECT
     @idArqueo = a.id
   FROM Tramites.dbo.arqueo a
   JOIN ControlAplicaciones..cat_usuarios cua
     ON a.idUsuario = cua.usu_idusuario
   WHERE id IN (SELECT
       MAX(id)
     FROM Tramites.dbo.arqueo
     GROUP BY idfondofijo)
 AND a.idFondoFijo = @id

   SELECT
    fecha = CONVERT(VARCHAR(10), a.fecha, 103) --+ '-' + CONVERT(VARCHAR(10), a.fecha, 108)
    ,realizo = ISNULL(cua.usu_nombre + ' ' + cua.usu_paterno + ' ' + cua.usu_materno, '')
    ,folioFF= ff.idFondoFijo
   FROM Tramites.dbo.arqueo a
   JOIN ControlAplicaciones..cat_usuarios cua
     ON a.idUsuario = cua.usu_idusuario
   JOIN Tramites.Tramite.fondoFijo fF
   ON a.idFondoFijo = ff.id
   WHERE a.id IN (SELECT
       MAX(id)
     FROM Tramites.dbo.arqueo
     GROUP BY idfondofijo)
	AND a.idFondoFijo = @id

	 SELECT
	 [nombre] = COALESCE(m.nombre, 'Suma Monedas')
	 -- ,cantidadMonedas =isnull(d.cantidadMonedas,'')
	  ,cantidadMonedas = case when d.cantidadMonedas = '' or d.cantidadMonedas is null then 0 else d.cantidadMonedas end 
	 ,sum(
			(case when d.cantidadMonedas = '' or d.cantidadMonedas is null or d.cantidadMonedas = ' ' then 0 else d.cantidadMonedas end)* ISNULL(m.valor,0)
	       --ISNULL((ISNULL(d.cantidadMonedas,0) * ISNULL(m.valor,0) ),0)
		) AS total
	FROM arqueoDetalle d
	JOIN monedas m
	  ON d.idMoneda = m.id
	   and m.tipo= 1
	WHERE d.idArqueo = @idArqueo
	GROUP BY GROUPING SETS(([nombre],d.cantidadMonedas,m.valor),())
	ORDER BY isnull(m.valor,3000) asc --Asignamos este valor para poder ordenar de forma ascendete, ya que al agregar 
	--la fila de la sumatoria obtenemos un valor null y nos desordena el resultado

	SELECT
	 [nombre] = COALESCE(m.nombre, 'Suma Billetes')
	  ,cantidadMonedas = case when d.cantidadMonedas = '' or d.cantidadMonedas is null then 0 else d.cantidadMonedas end 
	 ,sum(
			(case when d.cantidadMonedas = '' or d.cantidadMonedas is null or d.cantidadMonedas = ' '  then 0 else d.cantidadMonedas end)* ISNULL(m.valor,0)
	       --ISNULL((ISNULL(d.cantidadMonedas,0) * ISNULL(m.valor,0) ),0)
		) AS total
	FROM arqueoDetalle d
	JOIN monedas m
	  ON d.idMoneda = m.id
	   and m.tipo= 2
	WHERE d.idArqueo = @idArqueo
	GROUP BY GROUPING SETS(([nombre],d.cantidadMonedas,m.valor),())
	ORDER BY isnull(m.valor,3000) asc --Asignamos este valor para poder ordenar de forma ascendete, ya que al agregar 
	--la fila de la sumatoria obtenemos un valor null y nos desordena el resultado
	
	/*
		OBTENCION DEL SALDO AUXILIAR CONTABLE DEL FONDO FIJO
	*/
	DECLARE @nombreBD VARCHAR(30)
       ,@idEmpresa INT = 4
       ,@query NVARCHAR(MAX)
       ,@query1 NVARCHAR(MAX)
       ,@query2 NVARCHAR(MAX)
       ,@anio INT
	   ,@idResponsable int
	   ,@cuentaContable VARCHAR(60)
	   ,@fondoFijo varchar(30)
	   ,@nombreResponsableFF varchar(150)
	   ,@clienteBPRO varchar(15)

	SELECT 
	@idEmpresa = f.idEmpresa
	,@idResponsable = f.idResponsable
	,@fondoFijo = idFondoFijo
		FROM Tramites.Tramite.fondoFijo f
	JOIN ControlAplicaciones.dbo.cat_departamentos cd
	  ON f.idDepartamento = cd.dep_iddepartamento
	JOIN ControlAplicaciones.dbo.cat_sucursales cs
	  ON cd.suc_idsucursal = cs.suc_idsucursal
	JOIN ControlAplicaciones..cat_usuarios cu
	  ON f.idResponsable = cu.usu_idusuario
	WHERE id = @id


	SELECT
	  @nombreBD = ce.emp_nombrebd
	FROM ControlAplicaciones.dbo.cat_empresas ce
	WHERE ce.emp_idempresa = @idEmpresa

	SET @anio = YEAR(GETDATE())

	
	SELECT
	  @clienteBPRO = idpersona,
	  @cuentaContable = REPLACE(cuenta,'-','')
	FROM [Tramite].[cat_CuentasContableFFGV]
	WHERE idUsuario = @idResponsable
	
	--select @nombreResponsableFF =  replace(usu_nombre,' ', '')+usu_paterno+usu_materno
	--from ControlAplicaciones..cat_usuarios
	--where usu_idusuario = @idResponsable

	--select @clienteBPRO = PER_IDPERSONA from GA_Corporativa..PER_PERSONAS
	--where replace(PER_NOMRAZON,' ','')+PER_PATERNO+PER_MATERNO = @nombreResponsableFF

	--set @query = '
	--	SELECT isnull(SUM(MOV_DEBE),0) as DEBE ,isnull(SUM(MOV_HABER),0) as HABER,   isnull(SUM(MOV_DEBE),0) - isnull(SUM(MOV_HABER),0)  as SALDOFINAL
 --        FROM '+ @nombreBD +'.DBO.VIS_MOVDET01 
 --        WHERE MOV_IDDOCTO = '''+@fondoFijo+''' and MOV_IDCLIENTE = '''+@clienteBPRO+'''
	--'

		set @query = '
		select isnull(SUM(CCP_ABONO),0) as DEBE , isnull(SUM(CCP_CARGO),0) as HABER, isnull(SUM(CCP_CARGO),0) - isnull(SUM(CCP_ABONO),0)  as SALDOFINAL 
         FROM '+ @nombreBD +'.DBO.VIS_CONCAR01 
         WHERE CCP_IDDOCTO = '''+@fondoFijo+''' and CCP_IDPERSONA = '''+@clienteBPRO+'''
	'


	print  @query
	EXEC sp_executesql @query

	--SET @query = ('
	--	  SELECT ''GMI'',
	--	  CTA_NUMCTA AS CUENTA, 
	--	  CTA_DESCRIPCION AS DESCRIPCION,
	--	  SUBSTRING(CTA_NATURALEZA,1,1) AS TIPO,
	--	  ''SALDO_INICIAL'' = CASE WHEN CTA_NATURALEZA = ''DEUD'' 
	--	                           THEN (CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6)) - CTA_CARGO6 + CTA_ABONO6
	--					           ELSE (CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6)) + CTA_CARGO6 - CTA_ABONO6 END, 
 --         CTA_CARGO6 As Cargo, 
	--	  CTA_ABONO6 As Abono,
	--	 ')

	--SET @query1 = 'CTA_NATURALEZA As NATURALEZA,
	--G1.PAR_DESCRIP1,
	--G2.PAR_DESCRIP1,
	--G3.PAR_DESCRIP1,
	--G4.PAR_DESCRIP1,
	--G5.PAR_DESCRIP1,
	--CTA_ACUMDET ,
	--SUBSTRING(CTA_NUMCTA,1,4),
	--			(CASE WHEN CTA_NATURALEZA = ''DEUD'' THEN CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6)-(cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6) - CTA_CARGO6 + CTA_ABONO6 + CTA_CARGO6 - CTA_ABONO6
	--			Else CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6)+(cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6) + CTA_CARGO6 - CTA_ABONO6 - CTA_CARGO6 + CTA_ABONO6 END) SALDOFINAL 
	--			FROM ' + @nombreBD + '..CON_CTAS01' + CAST(@anio AS VARCHAR(10)) + '
	--			LEFT OUTER JOIN GAZM_Concentra..pnc_parametr as G1 ON CTA_GPOCONT = G1.PAR_IDENPARA AND G1.PAR_TIPOPARA= ''GPCON''
	--			LEFT OUTER JOIN GAZM_Concentra..pnc_parametr as G2 ON CTA_GPOCONT1 = G2.PAR_IDENPARA AND G2.PAR_TIPOPARA=''GPCON''
	--			LEFT OUTER JOIN GAZM_Concentra..pnc_parametr as G3 ON CTA_GPOCONT2 = G3.PAR_IDENPARA AND G3.PAR_TIPOPARA=''GPCON''
	--			LEFT OUTER JOIN GAZM_Concentra..pnc_parametr as G4 ON CTA_GPOCONT3 = G4.PAR_IDENPARA AND G4.PAR_TIPOPARA=''GPCON''
	--			LEFT OUTER JOIN GAZM_Concentra..pnc_parametr as G5 ON CTA_GPOCONT4 = G5.PAR_IDENPARA AND G5.PAR_TIPOPARA=''GPCONCA'' 
	--			WHERE CTA_SITUACION =''A'' AND (SUBSTRING(CTA_NUMCTA, 1, 4) + SUBSTRING(CTA_NUMCTA, 6, 4) + SUBSTRING(CTA_NUMCTA, 11, 4) + SUBSTRING(CTA_NUMCTA, 16, 4)) 
	--			Between '''+@cuentaContable+''' And '''+@cuentaContable+''''

	--EXECUTE (@query + @query1)

END
go

