CREATE VIEW [dbo].[cxp_ordenesmasivaslog]
AS
SELECT * FROM [GAZM_Zaragoza].dbo.cxp_ordenesmasivaslog
go

