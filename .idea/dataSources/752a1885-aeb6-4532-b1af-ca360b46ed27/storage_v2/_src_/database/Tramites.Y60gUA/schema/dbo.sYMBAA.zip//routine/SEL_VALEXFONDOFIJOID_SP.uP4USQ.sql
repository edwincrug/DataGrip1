

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <17/10/2019>
-- Description:	<SP que trae los datos de los FF x usuario>
-- [dbo].[SEL_VALEXFONDOFIJOID_SP]  1993
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALEXFONDOFIJOID_SP] 
	@idUsuario INT
AS
BEGIN
	 DECLARE @url varchar(max)
	 SELECT @url = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'
SELECT
 V.id as idVale,
 V.idVale  as nombreVale,
 U.usu_nombre + ' ' + U.usu_paterno  + ' ' + U.usu_materno as responsble,
 FF.idFondoFijo,
 CONVERT(varchar, V.fechaCreacionVale, 103) as fechaCreacion,
 V.montoSolicitado,
 V.montoJustificado as Justificar,
 V.estatusVale as idestatus,
 V.comentario,
 EV.descripcion as estatus,
 V.descripcion as razon,
 GFF.descripcion as tipoTramite,
 @url as saveUrl,
 FF.id_perTra,
 CASE WHEN V.estatusVale = 1 THEN ''
 ELSE @url + 'FondoFijo' + '/FondoFijo_' + CONVERT(VARCHAR(20), FF.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), V.id) + '/AutorizacionVale_' + CONVERT(VARCHAR(20), V.id) + '.pdf' END as rutaAutorizado,
 D.dep_nombrecto as nombreDepartamento,
 FF.idSucursal
 FROM Tramite.vales V
INNER JOIN Tramite.valesFondoFijo VF ON VF.idVales = V.id
INNER JOIN Tramite.fondoFijo FF ON FF.id = VF.idTablaFondoFijo
INNER JOIN [Tramite].[cat_estatusVale] EV ON EV.id = V.estatusVale
LEFT JOIN [Tramite].[cat_gastosFondoFijo] GFF ON V.idGastosFondoFijo = GFF.id
INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = V.idEmpleado
INNER JOIN [ControlAplicaciones].[dbo].cat_departamentos D ON D.dep_iddepartamento = FF.iddepartamento
WHERE V.idAutorizador = @idUsuario
ORDER BY V.id DESC

END
go

