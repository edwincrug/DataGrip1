
-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <11/06/2019>
-- Description:	Trae los tramites por area
--TEST SEL_TRAMITE_BY_AREA_FINALIZADOS_SP 3, 2865
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TRAMITE_BY_AREA_FINALIZADOS_SP] 
	@idArea INT,
	@usuario INT
AS
BEGIN
--declare 	@idArea INT = 3,
--	@usuario INT = 2865


	DECLARE @idRol INT = 0;
	SELECT 
		@idRol = idRol
	FROM usuarioRol WHERE idUsuario = @usuario

IF @idRol = 14  --DIRECTOR DE MARCA
BEGIN
					SELECT 
						CASE WHEN PETR.petr_estatus = 1 THEN PE.esDe_descripcion ELSE ESTR.est_nombre END est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus,
						DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario AND TD.id_empresa = ORG.emp_idempresa
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
			   LEFT JOIN Tramite.FlujoRolTramite frt
				ON frt.idArea = @idArea
				and tra.id_tramite = frt.idTramite
					WHERE 
					CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus >= frt.estatusPasoSiguiente or PETR.petr_estatus IN (2, 3) OR TD.esDe_IdEstatus > 1 THEN 1
								WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus IN (2, 3,14) then 1
						end = 1
					
					AND (TD.esDe_IdEstatus > 2 OR PETR.petr_estatus in (2,3,14))
					AND TRA.id_tramite = 4
					group by est_nombre,
						PETR.id_perTra,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						ESTR.id_estatus,
						PETR.id_persona,
						PETR.id_tramite,
						PE.esDe_descripcion,
						PETR.petr_estatus,
						PER.PER_NOMRAZON,
						PER.PER_PATERNO,
						PER.PER_MATERNO,
						DT.cuantos,
						DTR.cuantosRevisar,
						DTA.cuantosAprobados
					ORDER BY PETR.id_perTra DESC

END 
ELSE IF @idRol = 15  --ESCRUTADOR
BEGIN
					SELECT 
						CASE WHEN PETR.petr_estatus = 1 THEN PE.esDe_descripcion ELSE ESTR.est_nombre END est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus,
						DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = ORG.suc_idsucursal
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
			   LEFT JOIN Tramite.FlujoRolTramite frt
				ON frt.idArea = @idArea
				and tra.id_tramite = frt.idTramite
					WHERE 
					CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus >= frt.estatusPasoSiguiente or PETR.petr_estatus IN (2, 3) OR TD.esDe_IdEstatus > 1 THEN 1
								WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus IN (2, 3,14) then 1
						end = 1
					
					AND (TD.esDe_IdEstatus > 2 OR PETR.petr_estatus in (2,3,14))
					AND TRA.id_tramite = 4
					group by est_nombre,
						PETR.id_perTra,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						ESTR.id_estatus,
						PETR.id_persona,
						PETR.id_tramite,
						PE.esDe_descripcion,
						PETR.petr_estatus,
						PER.PER_NOMRAZON,
						PER.PER_PATERNO,
						PER.PER_MATERNO,
						DT.cuantos,
						DTR.cuantosRevisar,
						DTA.cuantosAprobados
					ORDER BY PETR.id_perTra DESC

END
ELSE IF @idRol = 12  --APROBACION
BEGIN
		SELECT 
			est_nombre,
			id_perTra,
			max(nombre) nombre,
			CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
			tra_nomTramite,
			max(id_persona) id_persona,
			max(per_rfc) per_rfc,
			max(id_TipoProspecto) id_TipoProspecto,
			id_estatus,
			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			,id_tramite,
			PER_PERSONA,
			noti,
			notiRevisar,
			notiDocsAprobar
		FROM (
		SELECT 
						PE.esDe_descripcion est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite IN (4, 9, 10) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus
						,PETR.id_tramite,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea AND tra.id_tramite = frt.idTramite
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					LEFT JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
					WHERE TRA.id_tramite IN (9) AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) AND TD.esDe_IdEstatus IN (9) AND
						CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
							WHEN frt.idRolSiguiente IS NOT NULL AND PETR.petr_estatus NOT IN (2, 3) and @idArea IN (1, 2) then 1
							WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) then 1
							END = 1 
		) x
			GROUP BY est_nombre,
				id_perTra,
				petr_fechaTramite,
				tra_nomTramite,
				id_estatus,
				id_tramite,
				PER_PERSONA,
				noti,
				notiRevisar,
				notiDocsAprobar
			ORDER BY id_perTra DESC

END
ELSE IF @idRol = 11  --EFECTIVO
BEGIN

		SELECT 
			est_nombre,
			id_perTra,
			max(nombre) nombre,
			CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
			tra_nomTramite,
			max(id_persona) id_persona,
			max(per_rfc) per_rfc,
			max(id_TipoProspecto) id_TipoProspecto,
			id_estatus,
			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			,id_tramite,
			PER_PERSONA,
			noti,
			notiRevisar,
			notiDocsAprobar
		FROM
		(SELECT 
			ESTR.est_nombre,
			PETR.id_perTra,
			PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre AS nombre,
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			PER.id_persona,
			PER.per_rfc,
			PER.id_TipoProspecto,
			ESTR.id_estatus AS id_estatus
			,PETR.id_tramite,
			'' PER_PERSONA,
			0 noti,
			0 notiRevisar,
			0 notiDocsAprobar
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
		WHERE  TRA.id_tramite = 9

		UNION ALL

		SELECT 
			CASE WHEN PETR.petr_estatus = 1 THEN PE.esDe_descripcion ELSE ESTR.est_nombre END est_nombre,
			PETR.id_perTra,
			CASE WHEN PETR.id_tramite IN (4, 9, 10) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			0 AS id_persona,
			'' AS per_rfc,
			0 AS id_TipoProspecto,
			ESTR.id_estatus
			,PETR.id_tramite,
			PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
			CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
			CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
			CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
		LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea AND tra.id_tramite = frt.idTramite
		INNER JOIN cat_proceso_estatus PE ON PE.esDe_IdEstatus = TD.esDe_IdEstatus AND PE.idTipoTramite = TRA.id_tramite
		LEFT JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
		WHERE TRA.id_tramite = 9
		AND CASE 
		WHEN  PETR.petr_estatus NOT IN (2,3, 4, 5, 6) THEN 1
		WHEN  TRA.id_tramite = 9 and  (select min(ISNULL(idSalidaEfectivo,0)) from Tramite.TramiteConcepto where idTramitePersona = PETR.id_perTra) > 0 then 1
		END = 1) x
			GROUP BY est_nombre,
				id_perTra,
				petr_fechaTramite,
				tra_nomTramite,
				id_estatus,
				id_tramite,
				PER_PERSONA,
				noti,
				notiRevisar,
				notiDocsAprobar
			ORDER BY id_perTra DESC

END
ELSE IF(@idRol = 10)
		BEGIN
			SELECT 
			est_nombre,
			id_perTra,
			max(nombre) nombre,
			CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
			tra_nomTramite,
			max(id_persona) id_persona,
			max(per_rfc) per_rfc,
			max(id_TipoProspecto) id_TipoProspecto,
			id_estatus,
			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			,id_tramite,
			PER_PERSONA,
			noti,
			notiRevisar,
			notiDocsAprobar
		FROM
		(SELECT 
			ESTR.est_nombre,
			PETR.id_perTra,
			UPPER(PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre)  +' - '+ UPPER(PER.per_rfc)  AS nombre, 
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			PER.id_persona,
			PER.per_rfc,
			PER.id_TipoProspecto,
			ESTR.id_estatus AS id_estatus
			,PETR.id_tramite,
			'' PER_PERSONA,
			0 noti,
			0 notiRevisar,
			0 notiDocsAprobar
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
		WHERE PETR.petr_estatus IN (2, 3,14) AND TRA.id_tramite IN (1, 2, 3, 4, 5, 6, 7, 8)

		UNION ALL

		SELECT 
			CASE WHEN PETR.petr_estatus = 1 THEN PE.esDe_descripcion ELSE ESTR.est_nombre END est_nombre,
			PETR.id_perTra,
			CASE WHEN PETR.id_tramite IN (4, 9, 10,16) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			0 AS id_persona,
			'' AS per_rfc,
			0 AS id_TipoProspecto,
			ESTR.id_estatus
			,PETR.id_tramite,
			PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
			CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
			CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
			CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
		LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea AND tra.id_tramite = frt.idTramite
		INNER JOIN cat_proceso_estatus PE ON PE.esDe_IdEstatus = TD.esDe_IdEstatus AND PE.idTipoTramite = TRA.id_tramite
		INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
		WHERE TRA.id_tramite IN (1, 2, 3, 4, 5, 6, 7, 8,16) AND (PETR.petr_estatus IN (2, 3,14) 
		--OR TD.esDe_IdEstatus IN (3, 4, 5,6))) x
		OR case when TRA.id_tramite =16 and PETR.petr_estatus = 1 then 0 when TD.esDe_IdEstatus IN (3, 4, 5,6) then 1 end = 1 )) x
			GROUP BY est_nombre,
				id_perTra,
				petr_fechaTramite,
				tra_nomTramite,
				id_estatus,
				id_tramite,
				PER_PERSONA,
				noti,
				notiRevisar,
				notiDocsAprobar
			ORDER BY id_perTra DESC
		END
	ELSE
		BEGIN
			IF( @idArea != 3)
				BEGIN
					SELECT 
						est_nombre,
						id_perTra,
						max(nombre) nombre,
						CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
						tra_nomTramite,
						max(id_persona) id_persona,
						max(per_rfc) per_rfc,
						max(id_TipoProspecto) id_TipoProspecto,
						id_estatus,
						DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
						,id_tramite,
						PER_PERSONA,
						noti,
						notiRevisar,
						notiDocsAprobar
					FROM
					(SELECT 
						ESTR.est_nombre,
						PETR.id_perTra,
						UPPER(PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre)  +' - '+ UPPER(PER.per_rfc)  AS nombre, 
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						PER.id_persona,
						PER.per_rfc,
						PER.id_TipoProspecto,
						ESTR.id_estatus AS id_estatus
						,PETR.id_tramite,
						'' PER_PERSONA,
						0 noti,
						0 notiRevisar,
						0 notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
					WHERE TRA.id_area = @idArea AND PETR.petr_estatus IN (2, 3,14)

					UNION ALL

					SELECT 
						CASE WHEN PETR.petr_estatus = 1 THEN PE.esDe_descripcion ELSE ESTR.est_nombre END est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus
						,PETR.id_tramite,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea and tra.id_tramite = frt.idTramite
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
					WHERE (PETR.petr_estatus IN (2, 3,14) OR TD.esDe_IdEstatus IN (4, 5,6)) AND (TRA.id_area = @idArea OR @idRol = 1)
					) x
					group by est_nombre,
						id_perTra,
						petr_fechaTramite,
						tra_nomTramite,
						id_estatus,
						id_tramite,
						PER_PERSONA,
						noti,
						notiRevisar,
						notiDocsAprobar
					ORDER BY id_perTra DESC
				END
			ELSE
					BEGIN
				IF EXISTS  (select 1 from Tramite.autorizadoresFondoFijo where idAutorizador = @usuario) 
				BEGIN
				print 'Usuarios Fondo'
					DECLARE @idTramite INT = 10
					SELECT 
						PE.esDe_descripcion est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus,
						DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					INNER JOIN Tramite.autorizadoresFondoFijo ORG  ON ORG.idAutorizador = @usuario
					--INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
					LEFT JOIN Tramite.FlujoRolTramite frt
					ON frt.idArea = @idArea
					AND tra.id_tramite = frt.idTramite
					WHERE  
					TD.id_empresa = ORG.idEmpresa 
					AND TD.id_sucursal = ORG.idSucursal
					AND TD.id_departamento = ORG.idDepartamento
					AND PETR.petr_estatus IN (2, 3)
					AND PETR.id_tramite = @idTramite
					group by est_nombre,
						PETR.id_perTra,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						ESTR.id_estatus,
						PETR.id_persona,
						PETR.id_tramite,
						PE.esDe_descripcion,
						PER.PER_NOMRAZON,
						PER.PER_PATERNO,
						PER.PER_MATERNO,
						DT.cuantos,
						DTR.cuantosRevisar,
						DTA.cuantosAprobados
					--ORDER BY id_perTra DESC
					UNION ALL
					SELECT 
						CASE WHEN PETR.petr_estatus = 1 THEN PE.esDe_descripcion ELSE ESTR.est_nombre END est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus,
						DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = ORG.suc_idsucursal
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
			   LEFT JOIN Tramite.FlujoRolTramite frt
				ON frt.idArea = @idArea
				and tra.id_tramite = frt.idTramite
					WHERE 
					CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus >= frt.estatusPasoSiguiente or PETR.petr_estatus IN (2, 3) OR TD.esDe_IdEstatus > 1 THEN 1
								WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus IN (2, 3) then 1
						end = 1
					
					AND (TD.esDe_IdEstatus > 2 OR PETR.petr_estatus in (2,3))
					AND TRA.id_tramite = 4
					group by est_nombre,
						PETR.id_perTra,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						ESTR.id_estatus,
						PETR.id_persona,
						PETR.id_tramite,
						PE.esDe_descripcion,
						PETR.petr_estatus,
						PER.PER_NOMRAZON,
						PER.PER_PATERNO,
						PER.PER_MATERNO,
						DT.cuantos,
						DTR.cuantosRevisar,
						DTA.cuantosAprobados






					END
					ELSE
					BEGIN
							print 'Usuarios'
							SELECT 
								CASE WHEN PETR.petr_estatus = 1 THEN PE.esDe_descripcion ELSE ESTR.est_nombre END est_nombre,
								PETR.id_perTra,
								CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
								CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
								TRA.tra_nomTramite,
								0 AS id_persona,
								'' AS per_rfc,
								0 AS id_TipoProspecto,
								ESTR.id_estatus,
								DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
								PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
								CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
								CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
								CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
							FROM personaTramite PETR
							INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
							INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
							INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
							INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
					   LEFT JOIN Tramite.FlujoRolTramite frt
						ON frt.idArea = @idArea
						and tra.id_tramite = frt.idTramite
							WHERE CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus >= frt.estatusPasoSiguiente or PETR.petr_estatus IN (2, 3) THEN 1
										WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus IN (2, 3,14) then 1
								end = 1
							AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = ORG.suc_idsucursal
							group by est_nombre,
								PETR.id_perTra,
								PETR.petr_fechaTramite,
								TRA.tra_nomTramite,
								ESTR.id_estatus,
								PETR.id_persona,
								PETR.id_tramite,
								PE.esDe_descripcion,
								PETR.petr_estatus,
								PER.PER_NOMRAZON,
								PER.PER_PATERNO,
								PER.PER_MATERNO,
								DT.cuantos,
								DTR.cuantosRevisar,
								DTA.cuantosAprobados
							--ORDER BY id_perTra DESC
				END
				
						
				END
		END
END



go

