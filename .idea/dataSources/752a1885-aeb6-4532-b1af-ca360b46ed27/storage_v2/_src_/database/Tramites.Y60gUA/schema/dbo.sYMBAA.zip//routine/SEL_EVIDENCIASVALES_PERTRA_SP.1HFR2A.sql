
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <14/11/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [SEL_EVIDENCIASVALES_PERTRA_SP]  85
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EVIDENCIASVALES_PERTRA_SP] 
	@id_perTra INT
AS
BEGIN
	
	SELECT
	V.idVale as nombreVale,
	VE.idVales as idVale,
	VE.id as idValeEvidencia,
	VE.extension as tipoEvidencia,
	--CASE WHEN FV.idValeEvidencia is null THEN VE.monto ELSE FV.subTotal END as monto, 
	 VE.monto,
	CONVERT(varchar, VE.fechaCreacion, 103) as fechaCreacion,
	CASE WHEN VE.idfactura is null THEN 'N' ELSE 'S' END as esFactura, 
	ED.est_docEstatus as estatus,
	VE.idestatus,
	VE.url + '/' + VE.archivo + '.' + VE.extension as evidencia,
	VE.comentario
	from tramiteDevoluciones td
	INNER JOIN Tramite.fondoFijo ff on td.id_perTra = ff.id_perTra
	INNER JOIN Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	INNER JOIN Tramite.vales v on v.id = vff.idVales
	INNER JOIN Tramite.valesEvidencia ve on ve.idVales = v.id
	INNER JOIN dbo.estatusDocumentos ED ON ED.id_estatus = VE.idestatus
	where td.id_perTra =  @id_perTra and v.estatusVale <> 5 and ve.idestatus <>3
	--WHERE FF.id_perTra = @id_perTra and VFF.idVales = @idVale

END

go

