
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [SEL_VALIDAVALESUSUARIO_SP] 5247
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDAVALESUSUARIO_SP] 
	@idUsuario INT
AS
BEGIN
--DECLARE @valesComprobados INT, @valesAbiertos INT
--SElECT @valesComprobados = MAX(estatusVale), @valesAbiertos = MIN(estatusVale) FROM tramite.vales where idEmpleado = @idUsuario and estatusVale not in (5,6)

--SET @valesComprobados = ISNULL(@valesComprobados,0)
--SET @valesAbiertos = ISNULL(@valesAbiertos,0)

--IF((@valesComprobados = 4 AND @valesAbiertos = 4) OR  (@valesComprobados = 0 AND @valesAbiertos = 0) )
--BEGIN
--select 1 success
--END
--ELSE
--BEGIN
--select 0 success
--END

--END

DECLARE @valesComprobados INT, @valesAbiertos INT
SElECT @valesComprobados = MAX(estatusVale), @valesAbiertos = MIN(estatusVale) FROM tramite.vales where idEmpleado = @idUsuario and estatusVale not in (5,6)

SET @valesComprobados = ISNULL(@valesComprobados,0)
SET @valesAbiertos = ISNULL(@valesAbiertos,0)

DECLARE @tieneRechazoFinanzas INT = 0
IF EXISTS (select TOP 1
u.usu_nombre +' '+ u.usu_paterno +' '+ u.usu_materno as Solicitante
,v.idVale
,v.montoSolicitado
,SUM (e.monto) as MontoRechazoFinanzas
,COUNT (e.id) as totalComprobaciones
from Tramites.Tramite.vales v
inner join Tramites.Tramite.valesEvidencia e on v.id = e.idVales
inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = v.idEmpleado 
where v.estatusVale in (3,4) and e.envioReembolso = 1 and e.estatusReembolso = 2 and v.idEmpleado = @idUsuario
group by u.usu_nombre, u.usu_paterno, u.usu_materno, v.idVale ,v.montoSolicitado)
BEGIN
   SET @tieneRechazoFinanzas = 1
END
ELSE
BEGIN
   SET @tieneRechazoFinanzas = 0
END

IF((@valesComprobados = 4 AND @valesAbiertos = 4) OR  (@valesComprobados = 0 AND @valesAbiertos = 0) )
BEGIN

IF(@tieneRechazoFinanzas = 0)
BEGIN
select 1 success
END
ELSE
BEGIN
select 2 success
END
END
ELSE
BEGIN
select 0 success
END


END
go

