-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <10/09/2019>
-- Description:	<Aprueba/Rechaza una solicitud>
--TEST EXEC [Tramite].[Sp_Tramite_AprobarRechazar_UPD]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_AprobarRechazar_UPD] 
	@idSolicitud INT,
	@idEstatus INT,
	@idUsuario int= 0
AS
BEGIN 

	SET NOCOUNT ON;	
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_ADGEstatus_UPD] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
		,@correo nvarchar(max) = ''
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
		
		 --Evaluamos si es aprobación, insertamos los importes de los conceptos aprobados.
		IF(@idEstatus = 2 OR @idEstatus = 2) 
		BEGIN
			

			--Insertamos el importe de cada concepto a actualizar estatus.
			INSERT INTO Tramite.TramiteImporte (importe, idTramiteConcepto, idUsuario, idTipoProceso)
			SELECT TI.importe
			, TI.idTramiteConcepto
			, case when @idUsuario = 0 then TI.idUsuario else @idUsuario end
			, 2
			FROM Tramite.TramiteConcepto TEC
			INNER JOIN Tramite.TramiteImporte TI ON TEC.idTramiteConcepto = TI.idTramiteConcepto AND TI.idTipoProceso = 1
			LEFT JOIN Tramite.TramiteImporte TIAS ON TEC.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
			WHERE TEC.idTramitePersona = @idSolicitud
			AND TEC.idEstatus = 1
			AND TIAS.idTramiteConcepto IS NULL
			 
			--Actualizamos todos los conceptos aun sin aprobar/rechazar
			UPDATE Tramite.TramiteConcepto SET idEstatus = @idEstatus
			WHERE idTramitePersona = @idSolicitud AND idEstatus = 1 
		 
			UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = @idEstatus 
			WHERE id_perTra = @idSolicitud

			UPDATE [dbo].[personaTramite] SET petr_estatus = @idEstatus 
			WHERE id_perTra = @idSolicitud

			

			select 1 as estatus, @correo as correo, 'Se autorizó correctamente el tramite: ' as mensaje


		END 
		ELSE IF(@idEstatus = 9 OR @idEstatus = 10) BEGIN
			IF(@idEstatus = 9) BEGIN
				--Insertamos el importe de cada concepto a actualizar estatus.
				INSERT INTO Tramite.TramiteImporte (importe, idTramiteConcepto, idUsuario, idTipoProceso)
				SELECT TI.importe, TI.idTramiteConcepto, TI.idUsuario, 4
				FROM Tramite.TramiteConcepto TEC
				INNER JOIN Tramite.TramiteImporte TI ON TEC.idTramiteConcepto = TI.idTramiteConcepto AND TI.idTipoProceso = 3
				INNER JOIN Tramite.ConceptoArchivo CA ON TI.idConceptoArchivo = CA.idConceptoArchivo
				WHERE TEC.idTramitePersona = @idSolicitud
				AND CA.idEstatus = 8
			 END
			 --Actualizamos todos los conceptos aun sin aprobar/rechazar
			 UPDATE Tramite.TramiteConcepto SET idEstatus = @idEstatus
			WHERE idTramitePersona = @idSolicitud AND idEstatus = 8 

			UPDATE CA SET CA.idEstatus = @idEstatus 
			FROM Tramite.ConceptoArchivo CA 
			INNER JOIN Tramite.TramiteImporte TI ON CA.idConceptoArchivo = TI.idConceptoArchivo
			INNER JOIN Tramite.TramiteConcepto TC ON CA.idReferencia = TC.idTramiteConcepto
			WHERE TC.idTramitePersona = @idSolicitud AND CA.idEstatus = 8 
		 
			UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = @idEstatus 
			WHERE id_perTra = @idSolicitud

			UPDATE [dbo].[personaTramite] SET petr_estatus = @idEstatus 
			WHERE id_perTra = @idSolicitud
		END

		ELSE IF(@idEstatus = 3) BEGIN
			
			--Insertamos el importe de cada concepto a actualizar estatus.
			INSERT INTO Tramite.TramiteImporte (importe, idTramiteConcepto, idUsuario, idTipoProceso)
			
			SELECT TI.importe
			, TI.idTramiteConcepto
			, case when @idUsuario = 0 then TI.idUsuario else @idUsuario end
			, 3
			FROM Tramite.TramiteConcepto TEC
			INNER JOIN Tramite.TramiteImporte TI ON TEC.idTramiteConcepto = TI.idTramiteConcepto AND TI.idTipoProceso = 1
			LEFT JOIN Tramite.TramiteImporte TIAS ON TEC.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
			WHERE TEC.idTramitePersona = @idSolicitud
			AND TEC.idEstatus = 1
			AND TIAS.idTramiteConcepto IS NULL
			 
			 --Actualizamos todos los conceptos aun sin aprobar/rechazar
			 UPDATE Tramite.TramiteConcepto SET idEstatus = @idEstatus
			WHERE idTramitePersona = @idSolicitud AND idEstatus = 1 
		 
			/*UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = @idEstatus 
			WHERE id_perTra = @idSolicitud

			UPDATE [dbo].[personaTramite] SET petr_estatus = @idEstatus 
			WHERE id_perTra = @idSolicitud*/


		END


		SET @VI_CountResult = 1

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @VI_CountResult AS [resultado]
END
go

