-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENE_IMPORTE_SOLICITUD_GV]
	-- Add the parameters for the stored procedure here
	@idPerTra int 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT CONVERT(varchar(10), tec.fechaRegistro, 103) as fecha
	,sum(tti.importe) as importe
	FROM tramiteDevoluciones TD
	INNER JOIN personaTramite PT
		ON PT.id_perTra = TD.id_perTra
	LEFT JOIN cat_tramites T
		ON T.id_tramite = PT.id_tramite
	INNER JOIN cat_proceso_estatus ET
		ON ET.esDe_IdEstatus = PT.petr_estatus
		AND ET.idTipoTramite = 9
	LEFT JOIN [Tramite].[TramiteEmpleado] TE
		ON TD.id_perTra = TE.idTramiteDevolucion
	LEFT JOIN [Tramite].[TramiteConcepto] TEC
		ON PT.id_perTra = TEC.idTramitePersona
	LEFT JOIN [Tramite].[TramiteImporte] TTI
		ON TEC.idTramiteConcepto = TTI.idTramiteConcepto
		AND TTI.idTipoProceso = 2
	where td.id_perTra = @idPerTra
	and importe is not null
	group by CONVERT(varchar(10), tec.fechaRegistro, 103)

END
go

