-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_PERSONATRAMITE_TRANFERENCIAS_SP]
	-- Add the parameters for the stored procedure here
	@idPersona INT,
	@idTramite INT,
	@idTransferencia int =11,
	@fueraHorario int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @idPerTra int = 0

    INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus]
		   ,esDe_IdEstatus)
     VALUES(
           @idPersona,
		   @idTramite,
		   case when @fueraHorario = 0 then GETDATE() else convert(varchar,GETDATE()+1,111) end,
		   0,
		   1)

	set @idPerTra = @@IDENTITY

	INSERT INTO cuentasTesoreria(
		id_perTra
		,fechaInsercion
		,estatus
		,fechaAtencion
		,id_tipoTramite
	)
	values(
	 @idPerTra
	 ,case when @fueraHorario = 0 then GETDATE() else convert(varchar,GETDATE()+1,111) end
	 ,1
	 ,NULL
	 ,@idTramite
	)

	update tl
	set tl.idPerTra = @idPerTra
	from Tesoreria.dbo.transferenciasLog tl
	where tl.idtransferencia = @idTransferencia
	
	select 'OK' as estatus, 'Se genero ha generado el tramite' as mensaje, cast(@idPerTra as varchar(6)) as idTramite

END
go

exec sp_addextendedproperty 'MS_Description', 'id de la persona que genera el tramite', 'SCHEMA', 'dbo', 'PROCEDURE',
     'INS_PERSONATRAMITE_TRANFERENCIAS_SP', 'PARAMETER', '@idPersona'
go

exec sp_addextendedproperty 'MS_Description', 'id del tipo de tramite', 'SCHEMA', 'dbo', 'PROCEDURE',
     'INS_PERSONATRAMITE_TRANFERENCIAS_SP', 'PARAMETER', '@idTramite'
go

exec sp_addextendedproperty 'MS_Description', 'id de la transferencia creada en las tablas de BPRO', 'SCHEMA', 'dbo',
     'PROCEDURE', 'INS_PERSONATRAMITE_TRANFERENCIAS_SP', 'PARAMETER', '@idTransferencia'
go

