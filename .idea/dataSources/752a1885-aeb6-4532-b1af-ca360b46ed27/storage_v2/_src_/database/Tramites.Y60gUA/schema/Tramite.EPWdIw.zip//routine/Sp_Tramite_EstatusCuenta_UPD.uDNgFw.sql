-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_EstatusCuenta_UPD]
	@perTra INT = NULL
	,@Estatus INT = NULL
	,@comentariorechazo VARCHAR(300) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @idEmpresa INT = ( SELECT idEmpresa FROM [dbo].[cuentaAutorizada] WHERE id_perTra = @perTra );
	DECLARE @Cuenta VARCHAR(20) = ( SELECT ca_cuenta FROM [dbo].[cuentaAutorizada] WHERE id_perTra = @perTra );

	UPDATE [dbo].[cuentasTesoreria] SET estatus = @Estatus WHERE id_perTra = @perTra;
	UPDATE [dbo].[cuentaAutorizada] SET ca_estatus = @Estatus, observaciones = @comentariorechazo WHERE id_perTra = @perTra;

	-- SELECT observaciones FROM [dbo].[cuentaAutorizada]

	-- comentariorechazo

	DECLARE @IpServer VARCHAR(300), @IpServerOnly VARCHAR(20);
			SELECT 
				@IpServer = '['+ [nombre_base]+'].[dbo].[CON_BANCOS]'
			FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
			WHERE emp_idempresa = @idEmpresa AND tipo = 2;

	IF( @Estatus = 3 )
		BEGIN
			

			DECLARE @QueryVal VARCHAR(MAX) = 'UPDATE ' + @IpServer + ' SET BCO_STATUS = ''ACTIVO'', BCO_AUTORIZADA = 1 WHERE BCO_NUMCUENTA = '''+@Cuenta+'''';

			EXEC( @QueryVal );		
		END

	IF(@Estatus = 4)
	BEGIN

		DECLARE @QueryDel VARCHAR(MAX) = 'DELETE FROM  ' + @IpServer + ' WHERE BCO_NUMCUENTA = '''+@Cuenta+'''';
		print @QueryDel
		EXEC( @QueryDel );	

	END

	SELECT 1 as success
END
go

