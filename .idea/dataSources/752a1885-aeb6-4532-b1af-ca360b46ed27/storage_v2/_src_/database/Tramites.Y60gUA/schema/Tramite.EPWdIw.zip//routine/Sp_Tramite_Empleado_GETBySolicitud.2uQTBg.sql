-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <03/09/2019>
-- Description:	<Recupera los empleados de una solicitud>
--TEST EXEC [Tramite].[Sp_Tramite_Empleado_GETBySolicitud] 1511
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_Empleado_GETBySolicitud] 
	@idTramiteDevolucion INT
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	DECLARE @IdPersona INT = 0 , @correo varchar(150) ='' ; 

	SELECT @IdPersona = IdPersona
	FROM [Tramite].[TramiteEmpleado] 
	WHERE idTramiteDevolucion = @idTramiteDevolucion


	DECLARE @nombreUsuario varchar (255), @paterno varchar (255), @materno varchar (255), @idUsuario INT = 0;

	SELECT @nombreUsuario = PER_NOMRAZON, @paterno = PER_PATERNO, @materno = PER_MATERNO FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @IdPersona AND PER_TIPO = 'FIS' AND  PER_STATUS = 'ACTIVO';
	SELECT @idUsuario = usu_idusuario, @correo = usu_correo FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombre  LIKE ('%' + @nombreUsuario + '%') AND usu_paterno LIKE ('%' + @paterno + '%') AND usu_materno LIKE ('%' + @materno + '%');


	SELECT
		idTramiteEmpleado
		,nombreEmpleado
		,IdPersona
		,@idUsuario idUsuario
		,@correo as correo
	FROM [Tramite].[TramiteEmpleado] 
	WHERE idTramiteDevolucion = @idTramiteDevolucion
	

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

