-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--[SEL_OBTIENE_DATOS_TRANSFERENCIA_SP] 1864
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENE_DATOS_TRANSFERENCIA_SP]
	-- Add the parameters for the stored procedure here
	@idPerTra int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @fechaAtencion datetime

	set @fechaAtencion = (
			select l.fechaAtencion
			FROM GA_Corporativa.dbo.tsb_traspasosaldobancos tt
			  JOIN Tesoreria.dbo.transferenciasLog l
			  ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
			  WHERE l.idPerTra = @idPerTra
			  )
	
	if(ISDATE(@fechaAtencion)=0)
	BEGIN
		UPDATE l
		  SET l.fechaAtencion = GETDATE()
		  FROM GA_Corporativa.dbo.tsb_traspasosaldobancos tt
		  JOIN Tesoreria.dbo.transferenciasLog l
		  ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
		  WHERE l.idPerTra = @idPerTra

		  UPDATE t
			SET fechaAtencion = GETDATE()
			FROM cuentasTesoreria t
			WHERE t.id_perTra  = @idPerTra
	END

	

    -- Insert statements for procedure here
	;with transferencia as(
	select tsb_idempresa as idEmpresa
	, emp_nombre as nomEmpresa
	,tl.idTransferencia
	,tsb_cuentaorigen as cuentaOrigen
	,tsb_cuentadestino as cuentaDestino
	,us.usu_nombre+' '+usu_paterno+' '+usu_materno as nombreSolicitante
	,us.usu_correo as email
	,tsb_importe as importe
	,isnull(tb.tsb_fechasolicita,'') as fechaSolicita
	,isnull(pt.esDe_IdEstatus,'') as esDe_IdEstatus
	,isnull(tl.fechaAtencion,'') as fechaAtencion
	,isnull(tl.fechaAutorizadaRechazada,'') as fechaAutorizadaRechazada
	,pt.petr_observaciones
	,isnull(tl.esCC,0) as esCC
	from Tesoreria..transferenciasLog tl
	join GA_Corporativa.dbo.tsb_traspasosaldobancos tb
	on tl.idtransferencia = tb.tsb_idtraspasosaldobancos
	join ControlAplicaciones.dbo.cat_usuarios us
	on tb.tsb_usuariosolicita = us.usu_idusuario
	join [ControlAplicaciones].[dbo].[cat_empresas] emp
	on tb.tsb_idempresa = emp.emp_idempresa
	join Tramites..personaTramite pt
	on tl.idPerTra = pt.id_perTra
	where tl.idPerTra = @idPerTra
),
origen as (
	select b.nombre as bancoOrigen, t.idEmpresa, bc.numeroCuenta
	from referencias.dbo.BancoCuenta bc
	join transferencia t
	on bc.idEmpresa = t.idEmpresa
	and bc.cuentaContable = t.cuentaOrigen
	join referencias.dbo.banco b
	on bc.idBanco = b.idBanco
),
destino as (
	select b.nombre as bancoDestino, t.idEmpresa, bc.numeroCuenta
	from referencias.dbo.BancoCuenta bc
	join transferencia t
	on bc.idEmpresa = t.idEmpresa
	and bc.cuentaContable = t.cuentaDestino
	join referencias.dbo.banco b
	on bc.idBanco = b.idBanco
)
select 
  t.idEmpresa
  ,t.nomEmpresa
  ,t.idtransferencia
  ,t.cuentaOrigen AS cuentaContableOrigen
  ,t.cuentaDestino AS CuentaContableDestino
  ,t.nombreSolicitante
  ,t.email
  ,t.importe
  ,t.fechaSolicita
  ,o.bancoOrigen
  , d.bancoDestino
  , o.numeroCuenta as cuentaOrigen
  , d.numeroCuenta as cuentaDestino
  , t.esDe_IdEstatus
  , t.fechaAtencion as fechaAtencion--convert(varchar (20),GETDATE(),120) as fechaAtencion
  ,t.fechaAutorizadaRechazada
  ,t.petr_observaciones as observaciones
  ,t.esCC
from  transferencia t
join origen o
on t.idEmpresa = o.idEmpresa
join destino d
on d.idEmpresa = t.idEmpresa


END
go

exec sp_addextendedproperty 'MS_Description', 'id del tramite creado', 'SCHEMA', 'dbo', 'PROCEDURE',
     'SEL_OBTIENE_DATOS_TRANSFERENCIA_SP', 'PARAMETER', '@idPerTra'
go

