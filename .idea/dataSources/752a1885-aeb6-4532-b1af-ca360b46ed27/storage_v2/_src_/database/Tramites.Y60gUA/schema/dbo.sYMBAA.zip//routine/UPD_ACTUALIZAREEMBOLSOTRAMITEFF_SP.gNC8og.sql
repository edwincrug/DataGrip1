-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/10/2019>
-- Description:	<SP que actualiza el estatus del vale>
-- [dbo].[UPD_ACTUALIZAREEMBOLSOTRAMITEFF_SP]   37,3,''
-- =============================================
CREATE  PROCEDURE [dbo].[UPD_ACTUALIZAREEMBOLSOTRAMITEFF_SP] 
	@idReembolso INT,
	@idTramite INT

AS
BEGIN

	UPDATE  Tramite.fondoFijoReembolso
	SET idTramiteTesoreria = @idTramite
	WHERE id = @idReembolso
	
	select 1 success;

END
go

