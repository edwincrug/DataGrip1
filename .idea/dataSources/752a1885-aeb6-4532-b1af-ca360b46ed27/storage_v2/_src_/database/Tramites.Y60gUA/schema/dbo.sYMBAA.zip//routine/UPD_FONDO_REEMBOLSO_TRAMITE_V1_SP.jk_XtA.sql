-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 14/11/2019
-- Description:	SP que aprueba el tramite
-- TEST [dbo].[UPD_FONDO_REEMBOLSO_TRAMITE_SP]
-- =============================================
CREATE PROCEDURE [dbo].[UPD_FONDO_REEMBOLSO_TRAMITE_V1_SP]
	@id_perTra INT,
	@bancoSalida INT,
	@bancoEntrada INT,
	@tipo INT,
	@estatus INT,
	@numCuentaSalida varchar(100) = NULL, 
	@cuentaContableSalida varchar(100) = NULL, 
	@numCuentaEntrada varchar(100) = NULL,
	@cuentaContableEntrada varchar(100) = NULL,
	@idTramiteTesoreria INT = 0
	
AS
BEGIN
	
	DECLARE @idSiguiente INT = 6, @correo varchar (max), @idReembolso INT

	DECLARE @idEmpresa INT, @idSucursal INT

	select @idEmpresa = id_empresa, @idSucursal = id_sucursal from tramiteDevoluciones where id_perTra = @id_perTra
			
	SELECT @correo =  STUFF((
	SELECT ';' + usu_correo
	FROM [Tramite].[UsuariosFondoFijo] uff
	inner join [Tramites].[Tramite].[Reembolso_Autorizadores_FF] ra on ra.idUsuario = uff.idUsuario and ra.nivelFinanzas = uff.idUsuariosFondoFijo 
	inner join controlAplicaciones.dbo.cat_usuarios u on ra.idUsuario = u.usu_idusuario
	WHERE  ra.idempresa = @idEmpresa and ra.idsucursal = @idSucursal and  ra.nivelFinanzas = @idSiguiente
	FOR XML PATH('')
	),1,1,'')
    
 --   SELECT @correo =  STUFF((
	--SELECT ';' + usu_correo
	--from Tramite.UsuariosFondoFijo UF
 --   inner join Tramite.cat_usuariosFondoFijo cuf on uf.idUsuariosFondofijo = cuf.id
 --   inner join controlAplicaciones.dbo.cat_usuarios u on UF.idusuario = u.usu_idusuario
 --   where UF.idUsuariosFondofijo = @idSiguiente
 --   FOR XML PATH('')
	--),1,1,'')
	
	IF (@estatus = 3)
	BEGIN
	--UPDATE Tramite.fondoFijo
	--SET idReembolso = @tipo, estatusFondoFijo = @estatus
	--WHERE id_perTra = @id_perTra;

	IF(@bancoSalida  > 0 or @bancoEntrada > 0)
	BEGIN
	DECLARE @idfondo INT
	--SELECT @idfondo = id FROM Tramite.fondoFijo WHERE id_perTra = @id_perTra;
	
	IF EXISTS (	select top 1 1 from Tramite.valesEvidencia where id_perTraReembolso = @id_perTra) 
	BEGIN 
	print 'Entra a las evidencias'
		select top 1 @idfondo = ff.id from Tramite.valesEvidencia ve 
		inner join Tramite.vales v on v.id = ve.idVales
		inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
		inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
		where ve.id_perTraReembolso = @id_perTra
	END
	ELSE
	BEGIN
	print 'Entra al Fondo'
		SELECT @idfondo = id FROM Tramite.fondoFijo WHERE id_perTra = @id_perTra;
	END


	INSERT INTO [Tramite].[fondoFijoReembolso] 
		   (idFondoFijo, 
		   idBancoSalida, 
		   idBancoEntrada,
		   numCuentaSalida,
		   cuentaContableSalida,
		   numCuentaEntrada,
		   cuentaContableEntrada,
		   idTramiteTesoreria,
		   estatus,
		   idSalidaReembolso,
		   id_perTraReembolso)
	VALUES
		   (@idfondo,
		   @bancoSalida,
		   @bancoEntrada,
		   @numCuentaSalida,
		   @cuentaContableSalida,
		   @numCuentaEntrada,
		   @cuentaContableEntrada,
		   @idTramiteTesoreria,
		   1,
		   @tipo,
		   @id_perTra)
	END

	SET @idReembolso = SCOPE_IDENTITY()

	
	--update Tramite.fondoFijo set idReembolso = @idReembolso where id_perTra = @id_perTra
	
	--IF EXISTS (	select top 1 1 from Tramite.valesEvidencia where id_perTraReembolso = @id_perTra) 
	--BEGIN
	--	print 'Entra a las evidencias'
	--	update Tramite.fondoFijo set idReembolso = @idReembolso where id = @idfondo
	--END
	--ELSE
	--BEGIN
	--	print 'Entra al Fondo'
	--	update Tramite.fondoFijo set idReembolso = @idReembolso where id_perTra = @id_perTra
	--END
	
	update Tramite.valesEvidencia set estatusPerTraReembolso = 1 where id_perTraReembolso = @id_perTra

	--SELECT @correo =  STUFF((
	--SELECT ';' + usu_correo
	--from Tramite.UsuariosFondoFijo UF
 --   inner join Tramite.cat_usuariosFondoFijo cuf on uf.idUsuariosFondofijo = cuf.id
 --   inner join controlAplicaciones.dbo.cat_usuarios u on UF.idusuario = u.usu_idusuario
 --   where UF.idUsuariosFondofijo = @idSiguiente
 --   FOR XML PATH('')
	--),1,1,'')
		
	SELECT 1 as success,@idReembolso as idReembolso, @correo as correo, @idSiguiente as tipoUsuario, 'Solicitud de Revisión Reembolso de Fondo Fijo' as asunto;

	END
	ELSE
	BEGIN
	UPDATE Tramite.fondoFijo
	SET estatusFondoFijo = @estatus
	WHERE id_perTra = @id_perTra;

	SELECT success = 1;
	END

END

go

