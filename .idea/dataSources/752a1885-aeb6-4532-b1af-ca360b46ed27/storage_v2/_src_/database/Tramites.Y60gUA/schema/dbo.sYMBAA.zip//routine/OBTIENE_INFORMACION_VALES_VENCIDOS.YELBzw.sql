-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- OBTIENE_INFORMACION_VALES_VENCIDOS
-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_INFORMACION_VALES_VENCIDOS]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

       DECLARE @fecha DATETIME
           ,@horas INT = 48
           ,@destinatarioContraloria VARCHAR(MAX)
           ,@destinatarioNomina VARCHAR(MAX)
           ,@asunto VARCHAR(255)
           ,@idBancoDestino INT
           ,@idBancoOrigen INT
           ,@idOrigenReferencia INT
           ,@minutos INT
          ,@inInicio INT = 1
      ,@inFinal INT = 0

      DECLARE @fechaIni DATETIME
             ,@horaI INT = 9
             ,@horaF INT = 18
             ,@fechaActual DATETIME = GETDATE()
             ,@escalamiento BIT = 0
			 ,@fechaInFinal datetime
			 ,@fechaNextDay datetime
			 ,@fechaNextDayFinal datetime

      DECLARE @iDia DATETIME = CONVERT(VARCHAR(10), @fechaActual, 112)
             ,@fDia DATETIME = CONVERT(VARCHAR(10), @fechaActual, 112)


      DECLARE @parametros TABLE (
       asunto VARCHAR(250)
       ,destinatarioContraloria VARCHAR(MAX)
       ,destinatarioNomina VARCHAR(MAX)
       ,idBancoDestino INT
       ,idBancoOrigen INT
	   ,idEmpresa INT
       ,idOrigenReferencia INT
	   ,idSucursal INT
       ,tiempoParaComprobar INT
      )

DECLARE @PorProcesar TABLE (
  id INT
 ,idEmpresa INT
 ,idsucursal INT
 ,idDepartamento INT
 ,idVale VARCHAR(100)
 ,PER_IDPERSONA INT
 ,rfc VARCHAR(15)
 ,NOMBRE VARCHAR(150)
 ,mail VARCHAR(150)
 ,montoSolicitado DECIMAL(18, 2)
 ,montoJustificado DECIMAL(18, 2)
 ,porJustificar DECIMAL(18, 2)
 ,destinatarioContraloria VARCHAR(MAX)
 ,destinatarioNomina VARCHAR(MAX)
 ,horas INT
 ,asunto VARCHAR(255)
 ,idBancoDestino INT
 ,idBancoOrigen INT
 ,idOrigenReferencia INT
 ,idUsuario INT
 ,indice INT
 ,fechaComprobacion DATETIME
)


      DECLARE @encontrados TABLE (
        id INT
       ,idEmpresa INT
       ,idsucursal INT
       ,idDepartamento INT
       ,idVale VARCHAR(100)
       ,PER_IDPERSONA INT
       ,rfc VARCHAR(15)
       ,NOMBRE VARCHAR(150)
       ,mail VARCHAR(150)
       ,montoSolicitado DECIMAL(18, 2)
       ,montoJustificado DECIMAL(18, 2)
       ,porJustificar DECIMAL(18, 2)
       ,destinatarioContraloria VARCHAR(MAX)
       ,destinatarioNomina VARCHAR(MAX)
       ,horas INT
       ,asunto VARCHAR(255)
       ,idBancoDestino INT
       ,idBancoOrigen INT
       ,idOrigenReferencia INT
       ,idUsuario INT
	   ,INDICE INT
	    ,fechaEntregadinero varchar(30)
	   ,fechaCierre varchar(30)
	   ,minutostranscurridos int
      )

  INSERT INTO @parametros
  EXEC [OBTIENE_PARAMETROS] 'FFValidaTiempoComprobante'
  --select 'FFValidaTiempoComprobante','== Prueba == Notificación de vale de fondo fijo vencido: ','roberto.almanza@coalmx.com','roberto.almanza@coalmx.com',1,1,3,48
  --select 'FFValidaTiempoComprobante','== PRUEBA == Descuento por nomina de vale vencido','manuel.lopez@grupoandrade.com','roberto.almanza@coalmx.com,luis.bonnet@grupoandrade.com,ignacio.jimenez@grupoandrade.com',1,1,3,48
  --select 'FFValidaTiempoComprobante',' Notificación de vale de fondo fijo vencido ','manuel.lopez@grupoandrade.com,roberto.almanza@coalmx.com,luis.bonnet@grupoandrade.com','laura.lora@grupoandrade.com,roberto.almanza@coalmx.com,luis.bonnet@grupoandrade.com',1,1,3,48
  --EXEC [OBTIENE_PARAMETROS] 'FFValidaTiempoComprobante'

  SELECT
    @horas = tiempoParaComprobar
   ,@destinatarioContraloria = destinatarioContraloria
   ,@destinatarioNomina = destinatarioNomina
   ,@asunto = asunto
   ,@idBancoDestino = idBancoDestino
   ,@idBancoOrigen = idBancoOrigen
   ,@idOrigenReferencia = idOrigenReferencia
  FROM @parametros

  SET @minutos = @horas * 60

      INSERT INTO @PorProcesar
        SELECT distinct
          v.id
         ,f.idEmpresa
         ,f.idSucursal
         ,f.idDepartamento
         ,idVale
         ,v.PER_IDPERSONA
         ,rfc = pp.PER_RFC
         ,NOMBRE = pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO
         ,mail = pp.PER_EMAIL
         ,montoSolicitado
         ,montoJustificado
         ,porJustificar =
          CASE
            WHEN (montoSolicitado - montoJustificado) < 0 THEN 0
            ELSE (montoSolicitado - montoJustificado)
          END
         ,destinatarioContraloria = pa.destinatarioContraloria -- @destinatarioContraloria
         ,destinatarioNomina = pa.destinatarioNomina -- @destinatarioNomina
         ,horas = 0
         ,asunto = @asunto
         ,idBancoDestino = @idBancoDestino
         ,idBancoOrigen = @idBancoOrigen
         ,idOrigenReferencia = @idOrigenReferencia
         ,f.idResponsable
         , ROW_NUMBER() OVER(ORDER BY v.id ASC) AS Row#
         ,CASE WHEN v.fechaRechazoVale IS NULL THEN  v.fechaEntregaEfectivo ELSE v.fechaRechazoVale END
        FROM tramite.vales v
        JOIN GA_Corporativa.dbo.PER_PERSONAS pp
          ON v.PER_IDPERSONA = pp.PER_IDPERSONA
        JOIN tramite.valesFondoFijo ff
          ON ff.idVales = v.id
        JOIN tramite.fondoFijo f
          ON ff.idTablaFondoFijo = f.id
		LEFT JOIN ControlAplicaciones..cat_usuarios cu
			on v.idEmpleado = cu.usu_idusuario
		left join @parametros pa
			on cu.emp_idempresa = pa.idEmpresa
			and cu.suc_idsucursal = pa.idSucursal
        WHERE fechaEntregaEfectivo IS NOT NULL
        AND (montoSolicitado - montoJustificado) > 0
        AND descuentoSolicitado = 0
			--and v.id in (142)
        ORDER BY v.id DESC

            SET @inFinal = ( SELECT COUNT(*) FROM @PorProcesar)

  --SELECT * FROM @PorProcesar
  --SELECT @inFinal
    DECLARE @minDia INT = 0, @fechaCominezo datetime

WHILE @inInicio < @inFinal+1 BEGIN  

    /*Leemos la fecha que vamos a comprobar*/
    SELECT @fechaIni = fechaComprobacion 
	,@iDia = fechaComprobacion
      FROM @PorProcesar  
	  WHERE indice = @inInicio

	  select @fechaInFinal =(DATEADD(HOUR, @horaF,  cast(convert(varchar(10), @iDia,23) as datetime2)))
	  --select @fechaInFinal

	   	 set @minDia = 0

	  while CONVERT(varchar(10), @fechaIni,112) <= convert(varchar(10),GETDATE(),112)
	  begin
	 
	
		IF( ((SELECT UPPER(DATENAME(DW, @fechaIni))) <> 'SUNDAY') AND ((SELECT UPPER(DATENAME(DW, @fechaIni))) <> 'DOMINGO') )-- OJO EN EL sp DEBE DE ESTAR EN INGLES
		begin
		 
		 print '==================================='
		  print UPPER(DATENAME(DW, @fechaIni))
		  print 'indice: '+ cast(@inInicio as varchar)
			
			if(convert(varchar(10), @fechaIni, 112) = convert(varchar(10),@fechaInFinal,112))
			begin
				
				print 'Obtenemos los minutos del dia en que se entrego el efectivo'
				print 'fecha hora de entregade efectivo: ' + cast(@fechaIni as varchar(30))
				print 'el dia de entregade efectivo termina: ' + cast(@fechaInFinal as varchar(30))
				
				set @minDia = DATEDIFF(MINUTE, @fechaIni, @fechaInFinal)
				set @fechaCominezo = @fechaIni
				--select @minDia, @fechaIni as diaEntrega, UPPER(DATENAME(DW, @fechaIni)) as diasemana
				set @fechaIni= DATEADD(DAY,1,@fechaIni) --@fechaIni+1

				
				select @fechaNextDay =(DATEADD(HOUR, @horai,  cast(convert(varchar(10), @fechaIni,23) as datetime2)))
				select @fechaNextDayFinal =(DATEADD(HOUR, @horaf,  cast(convert(varchar(10), @fechaIni,23) as datetime2)))
				--select @minDia as mindias
				print 'minutos transcurridos en el dia que se entrega el efectivo: '+ cast(@minDia as varchar(10))

			end
			else
			begin
				--select @fechaNextDay as diaIni, @fechaNextDayFinal as diaterm
				print 'Dia a procesar'

				if(convert(varchar(10),@fechaNextDay,112) =  convert(varchar(10), GETDATE(),112))
				begin

					print 'minutos dia anterior '+ cast(@minDia as varchar(8))
					PRINT 'minutos dia actual '+ cast(DATEDIFF(MINUTE, @fechaNextDay, GETDATE()) as varchar(8))
					
					if(DATEDIFF(MINUTE, @fechaNextDay, GETDATE())<=540)
					begin
						set @minDia = @minDia+DATEDIFF(MINUTE, @fechaNextDay,  GETDATE())
					end
					--select @minDia as mindias
					print 'dia actual'
					print 'minutos transcurridos: '+ cast(@minDia as varchar(8))
					--select @minDia as mindias, @fechaNextDay as diaActial, UPPER(DATENAME(DW, @fechaIni)) as diasemana
					
				end
				else
				begin
					print 'minutos dia anterior '+ cast(@minDia as varchar(8))
					PRINT 'minutos dia a procesar '+ cast(DATEDIFF(MINUTE, @fechaNextDay, @fechaNextDayFinal) as varchar(8))
			
					set @minDia = @minDia+DATEDIFF(MINUTE, @fechaNextDay, @fechaNextDayFinal)
					
					print 'siguiente dia'
					print 'minutos transcurridos: '+ cast(@minDia as varchar(8))
					--select @minDia as mindias, @fechaNextDay as dia, UPPER(DATENAME(DW, @fechaIni)) as diasemana
				end

				if(@minDia > @minutos)
				begin

				
					if not exists (select 1 from @encontrados WHERE indice = @inInicio)
					begin


						INSERT INTO @encontrados
						 SELECT
						  id
						 ,idEmpresa
						 ,idsucursal
						 ,idDepartamento
						 ,idVale
						 ,PER_IDPERSONA
						 ,rfc
						 ,NOMBRE
						 ,mail
						 ,montoSolicitado
						 ,montoJustificado
						 ,porJustificar
						 ,destinatarioContraloria
						 ,destinatarioNomina
						 ,horas
						 ,asunto
						 ,idBancoDestino
						 ,idBancoOrigen
						 ,idOrigenReferencia
						 ,idUsuario
						 ,@inInicio
						 ,cast(@fechaCominezo as varchar(30))
						 ,cast(@fechaNextDayFinal as varchar(30))
						 ,@minDia
						 FROM @PorProcesar
						 WHERE indice = @inInicio

						 						set @minDia = 0

					end

					set @minDia = 0

				end
	
				set @fechaNextDay = @fechaNextDay+1
				set @fechaNextDayFinal = @fechaNextDayFinal +1
				set @fechaIni= DATEADD(DAY,1,@fechaIni) 
				
			end
		end
		else
		begin
			print '**** Domingo *****'
			print 'No  suma horas'
			set @fechaIni= DATEADD(DAY,1,@fechaIni) 
			set @fechaNextDay = @fechaNextDay+1
			set @fechaNextDayFinal = @fechaNextDayFinal +1
		end


	  end

      SET @inInicio =  @inInicio + 1
  END --FIN WHILE PRINCIPAL



  	if((select count(*) from @encontrados) > 0)
	begin

	/*
		actualizamos el estatus para indicar que ya se proceso
	*/
    UPDATE v
    SET v.descuentoSolicitado = 1
       ,v.notificadoUsuario = 0
       ,v.notificadoNominas = 0
       ,v.notificadoContraloria = 0
       ,v.estatusVale = 6
    FROM tramite.vales v
    JOIN @encontrados en
      ON v.id = en.id

		insert Tramites.dbo.BITACORA_VALES_VENCIDOS( id ,idEmpresa ,idSucursal, idDepartamento ,idVale ,idPersona ,rfc ,nombre ,mail ,montoSolicitado ,montoJustificado ,porJustificar ,destinatarioContraloria ,destinatarioNomina ,horas ,asunto,idBancoDestino ,idBancoOrigen ,idOrgenReferencia ,idUsuario ,fechaPeticion )
		SELECT distinct
		  id
		 ,idEmpresa
		 ,idsucursal
		 ,idDepartamento
		 ,idVale
		 ,PER_IDPERSONA
		 ,rfc
		 ,NOMBRE
		 ,mail
		 ,montoSolicitado
		 ,montoJustificado
		 ,porJustificar
		 ,destinatarioContraloria
		 ,destinatarioNomina
		 ,horas
		 ,asunto
		 ,idBancoDestino
		 ,idBancoOrigen
		 ,idOrigenReferencia
		 ,idUsuario
		 ,getdate()
		FROM @encontrados

	end


  	SELECT distinct
      id
     ,idEmpresa
     ,idsucursal
     ,idDepartamento
     ,idVale
     ,PER_IDPERSONA
     ,rfc
     ,nombre
     ,e.mail+',roberto.almanza@coalmx.com,luis.bonnet@grupoandrade.com'  as mail
     ,montoSolicitado
     ,montoJustificado
     ,porJustificar
     ,destinatarioContraloria
     ,destinatarioNomina
     ,horas
     ,asunto
     ,idBancoDestino
     ,idBancoOrigen
     ,idOrigenReferencia
     ,idUsuario
	 ,fechaEntregadinero
	 ,fechaCierre
	 , minutostranscurridos
    FROM @encontrados e


END
go

