-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_DOCUMENTOS_REPORTE_CONTRALORIA 'localhost', 126, 10, 'FF-ZM-NZA-UN-1'
-- c:\\app\\public\\Imagenes\\ReporteContraloria\\
-- =============================================
create PROCEDURE SEL_DOCUMENTOS_REPORTE_CONTRALORIA
	@urlParam VARCHAR(30),
	@idPerTra INT,
	@idFondoFijo varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		DECLARE @url VARCHAR(500);
	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam);
		END
	ELSE
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');		
		END

	DECLARE @saveUrl VARCHAR(100) = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_DOCTO_CONTRA');

	select 1 as success, @url +'ReporteContraloria/' + 'Tramite_' + CONVERT(VARCHAR(20),@idPerTra) + '/Reporte_' + @idFondoFijo+'.pdf' [url] ,@saveUrl saveUrl, 1 as existe, 2 as idExtension	
	

    
END
go

