-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 18/08/2020
-- Description:	Obtiene las OC generadas
-- [Tramite].[Sp_Tramite_OC_Procesadas_GETL]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_OC_Procesadas_GETL]
	
AS
BEGIN 
	SET NOCOUNT ON;
	
	DECLARE @Bases TABLE (
		Indice INT,
		Base VARCHAR(300),
		idEmpresa INT,
		Empresa VARCHAR(300)
	)


	DECLARE @cxp_ordenesmasivas TABLE(
		[odm_empresa] [varchar](300) NOT NULL,
		[odm_idordenmasiva] [numeric](18, 0),
		[odm_idsucursal] [int] NOT NULL,
		[odm_idproveedor] [numeric](18, 0) NOT NULL,
		[odm_areaafectacion] [varchar](20) NOT NULL,
		[odm_observaciones] [varchar](250) NOT NULL,
		[odm_tipocomprobante] [varchar](20) NOT NULL,
		[odm_fechaorden] [datetime] NOT NULL,
		[odm_fechaaplicacion] [datetime] NOT NULL,
		[odm_fechaproceso] [datetime] NULL,
		[odm_estatus] [int] NOT NULL,
		[odm_ordencompra] [varchar](60) NULL,
		[odm_anticipos] [int] NULL,
		[odm_cantidadanticipo] [decimal](18, 5) NULL,
		[odm_porcentajeanticipo] [decimal](18, 5) NULL,
		[odm_fechaanticipo] [date] NULL
		)

	INSERT INTO @Bases
	SELECT
		ROW_NUMBER() OVER(ORDER BY suc_idsucursal)
		,nombre_base + '.dbo.cxp_ordenesmasivas'
		,C.emp_idempresa
		,EM.emp_nombre
	FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO C
	INNER JOIN ControlAplicaciones.dbo.cat_empresas EM ON C.emp_idempresa = EM.emp_idempresa
	WHERE C.emp_idempresa = (
		SELECT emp_idempresa
		FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO BA
		INNER JOIN (SELECT DISTINCT odm_idsucursal FROM Bitacora.cxp_ordenesmasivas) SUC ON BA.suc_idsucursal = odm_idsucursal
	) AND tipo = 2

	DECLARE @CurSuc INT,
			@MaxSuc INT;

	DECLARE @Query VARCHAR(500),
			@Base VARCHAR(300),
			@Empresa VARCHAR(300)

	SELECT @CurSuc = MIN(Indice), @MaxSuc = MAX(Indice) FROM @Bases


	WHILE( @CurSuc <= @MaxSuc )
		BEGIN 
			SELECT @Base = Base, @Empresa = Empresa FROM @Bases WHERE Indice = @CurSuc

			SET @Query = 'SELECT '''+ @Empresa +''',* FROM ' + @Base + ' WHERE odm_anticipos = 1 AND odm_estatus IN (1,2)'

			INSERT INTO @cxp_ordenesmasivas
			EXEC(@Query);

			SET @CurSuc = @CurSuc + 1;
		END

	SELECT * FROM @cxp_ordenesmasivas
	SET NOCOUNT OFF
END
go

