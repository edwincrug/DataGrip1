-- =============================================
-- Author:		Jorge Conelly
-- Create date: 21/02/2020
-- Description:	SP para obtener los datos del autorizador de anticipo de gastos
--[SEL_AUTORIZADOR_ANTICIPO_GASTOS_SP] 4, 6, 26, 112010, 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_AUTORIZADOR_ANTICIPO_GASTOS_SP]  --4
  @idEmpresa INT = 4,
  @idSucursal INT = 6,
  @idDepartamento INT = 26,
  @idUsuario INT = 109762,
  @tipoNotificacion int = 1

AS

BEGIN

	SET NOCOUNT ON;

	DECLARE @idUsuarioPadre INT
           ,@idUsuarioCat INT
           ,@idPadre INT


	--SELECT
	--@idUsuarioCat = cu.usu_idusuario
	-- FROM ControlAplicaciones..cat_usuarios cu
	-- WHERE RTRIM(LTRIM(REPLACE(cu.usu_nombre + cu.usu_paterno + cu.usu_materno, ' ', ''))) COLLATE Modern_Spanish_CI_AS IN (SELECT
	--	 RTRIM(LTRIM(REPLACE(pp.PER_NOMRAZON + pp.PER_PATERNO + pp.PER_MATERNO, ' ', '')))
	--   FROM GA_Corporativa..PER_PERSONAS pp
	--   WHERE RTRIM(LTRIM(REPLACE(pp.PER_NOMRAZON + pp.PER_PATERNO + pp.PER_MATERNO, ' ', ''))) <> ' MAURICIONAIMSANCHEZMONTELONGO         MAURICIONAIM     SANCHEZMONTELONGO'
	--   AND LEN(RTRIM(LTRIM(REPLACE(pp.PER_NOMRAZON + pp.PER_PATERNO + pp.PER_MATERNO, ' ', '')))) > 0
	--   AND pp.PER_IDPERSONA <> 271187
	--   AND pp.PER_TIPO = 'Fis'
	--   AND pp.PER_IDPERSONA = @idUsuario);

	select @idUsuarioCat = idUsuario
	from usuariosGastosViaje 
	where idPersona = @idUsuario
	--SELECT @idUsuarioCat

	 IF EXISTS (SELECT
		   1
		 FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO dej
		 WHERE dej.idUsuario = @idUsuarioCat
		 AND dej.idEmpresa = @idEmpresa
		 AND dej.idSucursal = @idSucursal
		 --AND dej.idDepartamento = @idDepartamento
		 and dej.idtipoNotificacionJeraquizada = @tipoNotificacion)
	 BEGIN

			   SELECT
		  @idPadre =  dej.idPadre
		  FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO dej
		  WHERE dej.idUsuario = @idUsuarioCat
		  AND dej.idEmpresa = @idEmpresa
		  AND dej.idSucursal = @idSucursal
		  --AND dej.idDepartamento = @idDepartamento
		  and dej.idtipoNotificacionJeraquizada = @tipoNotificacion

		  SELECT @idUsuarioPadre = dej.idUsuario
			FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO dej
			WHERE id = @idPadre
			and dej.idtipoNotificacionJeraquizada = @tipoNotificacion

		  SELECT estatus = 1, idAutorizador = cu.usu_idusuario
			,usu_correo = cu.usu_correo
			,nombreUsuario = cu.usu_nombre+' '+cu.usu_paterno+' '+cu.usu_materno
			FROM ControlAplicaciones.dbo.cat_usuarios cu
			WHERE cu.usu_idusuario = @idUsuarioPadre

	 END
	 ELSE
	 BEGIN
    		SELECT estatus = 0, mensaje='No se ha encontrado a su jefe inmediato, favor de solicitarle la configuración necesaria'
  

	 END


END
go

