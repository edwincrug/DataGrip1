-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: <Create Date,,>
-- Description:	Genera token
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENE_TOKEN_GV] 
	@idUsuarioSolicitante int 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @token varchar(6)
	, @idSelUsuario int
	, @duracionToken int
	, @fechaSolicitud datetime
	, @fechaVencimiento datetime
	, @correoSolicitante varchar(255)
	
	declare @parametros table(duracion int)

	insert into @parametros
	exec OBTIENE_PARAMETROS_V2 'Token'

	set @duracionToken = (select duracion from @parametros)

	set @token = substring(replace(newid(), 'AES', ''), 1, 6)
	
	select @idSelUsuario = idUsuario 
	from Tramites.dbo.usuariosGastosViaje
	where idUsuario = @idUsuarioSolicitante

	set @correoSolicitante = (select usu_correo from ControlAplicaciones..cat_usuarios where usu_idusuario = @idSelUsuario)

	set @fechaSolicitud = GETDATE()
	set @fechaVencimiento = DATEADD(minute,@duracionToken,@fechaSolicitud)

	insert into token(token ,idUsuarioSolicitante ,fechaSolicitud ,fechaVencimiento ,estatus)
	select @token as token
	,@idSelUsuario as usuario
	,@fechaSolicitud as fechaSolicitud
	,@fechaVencimiento as fechaVencimiento
	,0 as estatus

	select 1 as estatus
	, @token as token
	,convert(varchar(10), @fechaVencimiento, 103) +' '+ convert(varchar(10), @fechaVencimiento, 108)  as vence
	,@correoSolicitante as correo
	,'El token caduca en la fecha y hora que se indica, después de esta fecha sera necesario solicitar un nuevo token' as mensaje
	,'Solicitud de token para Gastos de viaje' as asunto
END
go

