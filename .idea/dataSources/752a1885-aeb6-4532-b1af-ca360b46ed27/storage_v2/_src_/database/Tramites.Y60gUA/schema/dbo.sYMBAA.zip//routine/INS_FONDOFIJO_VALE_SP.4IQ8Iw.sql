
-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <17/10/2019>
-- Description:	<Inserta el tramite de vale para el fondo fijo>
-- ============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_VALE_SP]
	@idVale INT,
	@idUsuario INT,
	@idFondoFijo INT,
	--@idtipoGasto INT,
	@idAutorizador INT = 0,
	@descripcion VARCHAR(MAX),
	@estatus INT,
	@importe NUMERIC(18,4),
	@valeCompuesto INT,
	@idFondoFijo2 INT,
	@importeFF1  NUMERIC(18,4),
	@importeFF2  NUMERIC(18,4),
	@idPersona INT,
	@idDep INT = 0
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE 
			@idEmpresa INT,
			@idSucursal INT,
			@idDepartamento INT,
			@fondoFijo varchar(50),
			@incremental INT,
			@vale varchar(50),
			@emp_nombrecto  varchar(10),
			@suc_nombrecto  varchar(10),
			@dep_nombrecto  varchar(10),
			@id_perTra INT;
	BEGIN TRAN TrnFondoIns
	
	IF(@idVale = 0)
	BEGIN

	SELECT @incremental =  COUNT(V.id) FROM [Tramite].[vales] V
	INNER JOIN [Tramite].[valesFondoFijo] VFF ON VFF.idVales = V.id
	WHERE VFF.idTablaFondoFijo = @idFondoFijo
	SET @incremental = @incremental + 1;

	SELECT @idEmpresa = idEmpresa, @idSucursal = idSucursal, @idDepartamento = idDepartamento, @fondoFijo = idfondoFijo, @id_perTra = id_perTra
	FROM Tramite.fondoFijo 
	WHERE id = @idFondoFijo

	--select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cd.dep_nombrecto 
	--from ControlAplicaciones.dbo.cat_empresas ce 
	--inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	--inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	--where ce.emp_idempresa = @idEmpresa and cs.suc_idsucursal = @idSucursal and cd.dep_iddepartamento=@idDepartamento

	--El identificador se genera con empresa + sucursal + departamento + idDeFondoFijo +incremental
	--SET @vale = @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto + '-' +  CONVERT(varchar(10), @fondoFijo)   + '-' + CONVERT(varchar(10), @incremental) 
	SET @vale = @fondoFijo  + '-' + CONVERT(varchar(10), @incremental) 
	--substring(@fondoFijo,4,20) 


	--Insert Vale
	INSERT INTO [Tramite].[vales]
           ([idVale],
		    [idEmpleado],
			--[idGastosFondoFijo],
			--[idAutorizador],
			[montoSolicitado],
			[montoJustificado],
			[descripcion],
			[fechaCreacionVale],
			[estatusVale],
			[valeCompuesto],
			[PER_IDPERSONA],
			[idDepartamento])
     VALUES
           (@vale,
		    @idUsuario,
            --@idtipoGasto,
			--@idAutorizador,
		    @importe,
			0,
			@descripcion,
            GETDATE(),
            @estatus,
			@valeCompuesto,
			@idPersona,
			@idDep)

	SET @idvale = SCOPE_IDENTITY()

	-- valesFondoFijo
	IF(@valeCompuesto = 0)
	BEGIN
	INSERT INTO [Tramite].[valesFondoFijo]
           ([idVales]
           ,[idTablaFondoFijo]
		   ,[monto])
     VALUES
           (@idvale
           ,@idFondoFijo
		   ,@importe)
	END
	ELSE
	BEGIN
	INSERT INTO [Tramite].[valesFondoFijo]
           ([idVales]
           ,[idTablaFondoFijo]
		   ,[monto])
     VALUES
           (@idvale
           ,@idFondoFijo
		   ,@importeFF1)

	INSERT INTO [Tramite].[valesFondoFijo]
           ([idVales]
           ,[idTablaFondoFijo]
		   ,[monto])
     VALUES
           (@idvale
           ,@idFondoFijo2
		   ,@importeFF2)
	END

	END
	ELSE

	BEGIN
	UPDATE[Tramite].[vales]
	SET descripcion = @descripcion, montoSolicitado = @importe--, idAutorizador = @idAutorizador
	WHERE id = @idVale

	UPDATE[Tramite].[valesFondoFijo]
	SET monto = @importe
	WHERE idVales = @idVale
	END
	COMMIT TRAN TrnFondoIns

	DECLARE @correo varchar (100), @nombreAutorizador varchar (100)
	--select 
	---- @correo = cu.usu_correo as correo
	--@correo = 'juan.peralta@coalmx.com',
	--@nombreAutorizador = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	--from Tramite.autorizadoresVales av
	--inner join ControlAplicaciones..cat_usuarios cu on cu.usu_idusuario = av.idAutorizador
	--where idAutorizador = @idAutorizador

	SELECT success = 1, msg = 'Se inserto correctamente', vale = @vale, descripcion = @descripcion, 
	--@correo, nombreAutorizador =  @nombreAutorizador, 
	asunto = 'Autorización Vale ' + @vale,importe = @importe,
	id_perTra = @id_perTra, id = @idVale, idEmpresa= @idEmpresa , idSucursal = @idSucursal, idDepartamento = @idDep

END TRY
	BEGIN CATCH
		ROLLBACK TRAN TrnFondoIns
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END



go

