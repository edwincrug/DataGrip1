-- =============================================
-- Author:		Francisco Javier Suárez Priego
-- Create date: 12/09/2019
-- Description:	Servicio para obtener los autorizadores del fondo fijo
-- =============================================
CREATE PROCEDURE [Tramite].[Sel_autorizadoresFondoFijo]
	--@tipo INT,
--@idUsuarioSolicitante INT
@idEmpresa INT,
@idSucursal INT,
@idDepartamento INT
AS

--Declare @total int
BEGIN
	
	--IF(@idUsuarioFondoFijo = 2)
	--BEGIN
	--Select usu_idusuario as idUsuario, usu_nombre as nombre, usu_paterno  as apellidoPaterno, usu_materno as apellidoMaterno
	--from Tramites.Tramite.UsuariosFondoFijo uff 
	--inner join ControlAplicaciones.dbo.cat_usuarios cu on uff.idUsuario= cu.usu_idusuario 
	--where uff.idUsuariosFondoFijo = @idUsuarioFondoFijo --autorizador
	--END
	--ELSE
	--BEGIN
	--Select usu_idusuario as idUsuario, usu_nombre as nombre, usu_paterno  as apellidoPaterno, usu_materno as apellidoMaterno
	--from Tramites.Tramite.UsuariosFondoFijo uff 
	--inner join ControlAplicaciones.dbo.cat_usuarios cu on uff.idUsuario= cu.usu_idusuario 
	--where uff.idUsuario not in (@idUsuarioSolicitante)
	--END
	--IF(@tipo = 1)
	--BEGIN
	--SELECT uff.idAutorizador 
	--FROM
	--[Tramite].[autorizadoresFondoFijo] uff
	----inner join ControlAplicaciones.dbo.cat_usuarios cu on uff.idAutorizador = cu.usu_idusuario 
	--where uff.idUsuarioFondoFijo = @idUsuarioSolicitante
	--END

	--IF(@tipo = 2)
	--BEGIN
	--SELECT uv.idAutorizador 
	--FROM
	--[Tramite].[autorizadoresVales] uv
	----inner join ControlAplicaciones.dbo.cat_usuarios cu on uff.idAutorizador = cu.usu_idusuario 
	--where uv.idUsuarioVale = @idUsuarioSolicitante
	--END
	
	
	select idAutorizador from [Tramite].[autorizadoresFondoFijo] where idEmpresa = @idEmpresa and idSucursal = @idSucursal and idDepartamento = @idDepartamento
	
END


go

