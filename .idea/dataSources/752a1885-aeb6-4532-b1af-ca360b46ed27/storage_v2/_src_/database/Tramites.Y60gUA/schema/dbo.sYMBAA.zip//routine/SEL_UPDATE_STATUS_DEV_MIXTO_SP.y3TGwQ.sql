-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_UPDATE_STATUS_DEV_MIXTO_SP]
	-- Add the parameters for the stored procedure here
	@opcion INT,
	@idPerTra INT
AS
BEGIN
	BEGIN TRANSACTION
		BEGIN TRY
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;

			DECLARE @RespuestaInsert INT
			DECLARE @tipotramite INT;

			SELECT 
				@tipotramite = id_tipoTramite 
			FROM cuentasTesoreria 
			WHERE id_perTra = @idPerTra

			IF(@tipotramite <> 3)
				BEGIN
					UPDATE cuentasTesoreria SET  estatus = 3 WHERE id_perTra = @idPerTra;
					UPDATE tramiteDevoluciones SET esDe_IdEstatus = 5 WHERE id_perTra = @idPerTra;

					EXEC [Tramites].[DBO].[INS_DATOS_CXC_DEVOLUCIONES] @idPerTra, @result = @RespuestaInsert OUTPUT
					IF(@RespuestaInsert = 0)
						BEGIN
							SELECT 1/0
						END
					SELECT success = 1;
				END
			ELSE
			BEGIN
				IF(@opcion = 1)
				BEGIN
					UPDATE emd
					SET e_noEfectivo = 1
					FROM EstatusMixtosDevoluciones emd
					WHERE id_perTra = @idPerTra
				END
				ELSE
				BEGIN
					UPDATE emd
					SET e_efectivo = 1
					FROM EstatusMixtosDevoluciones emd
					WHERE id_perTra = @idPerTra
				END

				IF( (SELECT e_efectivo+e_noEfectivo FROM EstatusMixtosDevoluciones emd WHERE id_perTra = @idPerTra) > 1)
				BEGIN
					UPDATE t
					SET t.estatus = 3
					FROM cuentasTesoreria t
					WHERE t.id_perTra = @idPerTra
					UPDATE tramiteDevoluciones SET esDe_IdEstatus = 5 WHERE id_perTra = @idPerTra;

					EXEC [Tramites].[DBO].[INS_DATOS_CXC_DEVOLUCIONES] @idPerTra, @result = @RespuestaInsert OUTPUT
					IF(@RespuestaInsert = 0)
						BEGIN
							SELECT 1/0
						END
				END

				SELECT success = 1;
			END 
	COMMIT TRANSACTION
	END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION
	SELECT success = 0
END CATCH
END
go

