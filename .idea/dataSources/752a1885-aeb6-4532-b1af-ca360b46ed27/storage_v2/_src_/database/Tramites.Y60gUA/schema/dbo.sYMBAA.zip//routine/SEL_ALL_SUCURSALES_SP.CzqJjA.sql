-- =============================================
-- Author:		<Luis Garccía>
-- Create date: <03/07/2019>
-- Description:	<Trae todas las sucursales por empresa>
--TEST SEL_SUCURSALES_SP 4
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ALL_SUCURSALES_SP]
    @idEmpresa INT = 0
AS
BEGIN
    SELECT DISTINCT
		SUC.suc_idsucursal AS idSucursal
        ,suc_nombre     AS nombre
    FROM [ControlAplicaciones].[dbo].[cat_sucursales] SUC
    WHERE SUC.emp_idempresa = @idEmpresa
END
go

