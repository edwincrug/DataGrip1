-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <03/09/2019>
-- Description:	<Recupera los conceptos contables>
--TEST EXEC [Tramite].[Sp_Tramite_Concepto_GETL] 2470,9,18
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_Concepto_GETL] 
	@idSolicitud INT
	,@idEmpresa INT
	,@idSucursal int
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	SELECT 
		 CC.idConceptoContable AS [id]
		,CC.concepto
		,CC.importeMaximo
		,CC.fechaRegistro
		,CC.estatus
		,COALESCE(CC.politicaGasto, '') AS [politicaGasto]
		,cc.PAR_IDENPARA as idConceptoContable 
		,COUNT(TC.idSalidaEfectivo) idSalidaEfectivo
	FROM [Tramite].[ConceptoContable] CC
    LEFT JOIN [Tramite].[TramiteConcepto] TC ON TC.idTramitePersona = @idSolicitud 
		AND CC.idConceptoContable = TC.idConceptoContable
	WHERE cc.idEmpresa = @idEmpresa
	and  cc.idSucursal = @idSucursal
GROUP BY CC.idConceptoContable
		,CC.concepto
		,CC.importeMaximo
		,CC.fechaRegistro
		,CC.estatus
        ,CC.politicaGasto
		,cc.PAR_IDENPARA 
  HAVING CC.estatus = 1 AND COUNT(TC.idConceptoContable) = COUNT(TC.idSalidaEfectivo)
  order by cc.concepto asc

	
/*	SELECT 
		CC.idConceptoContable AS [id]
		,concepto
		,importeMaximo
		,CC.fechaRegistro
		,estatus
		,COALESCE(politicaGasto, '') AS [politicaGasto]
	FROM [Tramite].[ConceptoContable] CC
	LEFT JOIN [Tramite].[TramiteConcepto] TC ON TC.idTramitePersona = @idSolicitud 
		AND CC.idConceptoContable = TC.idConceptoContable
 	WHERE estatus = 1 AND TC.idConceptoContable IS NULL */

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

