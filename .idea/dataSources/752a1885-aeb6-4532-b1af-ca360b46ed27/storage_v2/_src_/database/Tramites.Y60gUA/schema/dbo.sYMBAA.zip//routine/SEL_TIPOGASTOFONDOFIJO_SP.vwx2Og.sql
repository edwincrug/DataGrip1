
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <17/10/2019>
-- Description:	<SP que trae los tipos de gastos del FF>
-- SEL_TIPOGASTOFONDOFIJO_SP 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOGASTOFONDOFIJO_SP] 
AS
BEGIN
	 
	SELECT 
		id, 
		descripcion 
	FROM [Tramite].[cat_gastosFondoFijo]

END
go

