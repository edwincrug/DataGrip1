
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <31/03/2020>
-- Description:	<SP que trae la informacion del vale>
-- [dbo].[SEL_ESTATUSVALEORDEN_SP]  4, 6, 'FF-ZM-NZA-OT-4-3',500
-- =============================================

-- =============================================
-- Modificación:<Alejandro Grijalva Antonio>
-- Create date: <31/07/2020>
-- Description:	<Tolerancia de 10 centavos (Parametrizado) para comprobacion de más>
-- [dbo].[SEL_ESTATUSVALEORDEN_SP]  4, 6, 'FF-ZM-NZA-UN-14-15',500.1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ESTATUSVALEORDEN_SP] 
	@idempresa INT,
	@idsucursal INT,
	@idVale VARCHAR (100),
	@montoComprobacion DECIMAL (18,2)
AS
BEGIN
	DECLARE @comprobaciones varchar (MAX),
			@SQLAgencia NVARCHAR(MAX),
			@SQLComprbadoMas NVARCHAR(MAX),
			@nombreBDConsen varchar (100),
			@nombreBDOperativa varchar (100),
			@comprobado DECIMAL(18,2) = 0,
			@comprobadoMas DECIMAL(18,2) = 0

			 SELECT @comprobaciones = STUFF((
			 SELECT ',' + ''''+ ve.idComprobacionVale + ''''
             FROM tramite.vales v 
			 inner join tramite.valesEvidencia ve on v.id = ve.idvales
			 WHERE v.idvale = @idVale and ve.idEstatus not in (3)
             FOR XML PATH('')
			 ),1,1,'')
			 FROM tramite.vales WHERE idvale = @idVale
	
			select @nombreBDConsen = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_idempresa = @idempresa
			select @nombreBDOperativa = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
			
			--SET @SQLAgencia ='SELECT  @comprobado = sum(omd.omd_preciounitario)
			--	from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
			--	inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
			--	inner join ['+@nombreBDOperativa+'].dbo.DSBPEncInfo poli on poli.Documento = om.odm_ordencompra
			--	where  omd.omd_producto in ('+@comprobaciones+') and om.odm_ordencompra is not null'
				
				SET @SQLAgencia ='SELECT @comprobado = sum(det.VentaUnitario)
				from  ['+@nombreBDOperativa+'].dbo.DSBPDetInfo det
				inner join ['+@nombreBDOperativa+'].dbo.DSBPEncInfo poli on poli.DocumentoOrigen = det.DocumentoOrigen and poli.Proceso = det.proceso and det.Partida = 1
				where det.DocumentoOrigen in ('+@comprobaciones+')
					'		
				print @SQLAgencia
				EXECUTE sp_executeSQL @SQLAgencia, N' @comprobado DECIMAL(18,2) OUTPUT',@comprobado OUTPUT 

				SET @SQLComprbadoMas = 'SELECT @comprobadoMas = sum(det.VentaUnitario)
				from  ['+@nombreBDOperativa+'].dbo.DSBPDetInfo det
				inner join ['+@nombreBDOperativa+'].dbo.DSBPEncInfo poli on poli.DocumentoOrigen = det.DocumentoOrigen and poli.Proceso = det.proceso and det.Partida = 1
				where det.DocumentoOrigen in ('+@comprobaciones+')  and det.proceso in (''CVFR'',''CVFN'')
				'
				print @SQLComprbadoMas
				EXECUTE sp_executeSQL @SQLComprbadoMas, N' @comprobadoMas DECIMAL(18,2) OUTPUT', @comprobadoMas OUTPUT
				
				SET @comprobado = ISNULL(@comprobado,0) + @montoComprobacion;
				SET @comprobadoMas = ISNULL(@comprobadoMas,0);
	
	
	-- SE INTEGRA TOLERANCIA PARA EVIAR JSUTIFICAR DE MAS 10 CENTAVOS
	DECLARE @centavos NUMERIC(2, 2) = (SELECT pr_descripcion centavos FROM parametros WHERE pr_tipoParametro = 'tramite' AND pr_identificador = 'valesTolCentavos')
	DECLARE @centavosNegativo NUMERIC(2, 2) = @centavos * -1 ;

	-- SE SUMA TOLERACIA A LAS VALIDACIONES PARA COMPROBACION DE MAS
	PRINT('===============')
	PRINT(@comprobado)
	SELECT 
	@comprobado as montoJustificado, 
	-- montoSolicitado,
	CASE 
		--WHEN @comprobado = montoSolicitado THEN  1 
		WHEN (@comprobado >= (montoSolicitado - @centavos) AND @comprobado <= (montoSolicitado + @centavos) )  THEN  1 
		WHEN @comprobado > (montoSolicitado + @centavos) THEN 1
		ELSE 0  
	END AS justificado,
	CASE 
		WHEN(@comprobado > (montoSolicitado + @centavos)) THEN 
			@comprobado - montoSolicitado 
		ELSE 0  
	END AS JustificoMas,
	@idVale idVale,
	@comprobadoMas comprobadoMas
	from tramite.vales where idvale = @idVale  and estatusVale in(3,4)

END
go

