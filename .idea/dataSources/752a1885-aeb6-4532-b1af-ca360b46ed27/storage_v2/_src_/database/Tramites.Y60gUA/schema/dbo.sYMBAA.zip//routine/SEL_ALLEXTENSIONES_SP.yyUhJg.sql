-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <04/06/2019>
-- Description:	<Trae todas las extensiones de los documentos>
--TEST: SEL_ALLEXTENSIONES_SP
-- =============================================
CREATE PROCEDURE SEL_ALLEXTENSIONES_SP
AS
BEGIN
	SELECT 
		id_extension,
		ext_nombre 
	FROM cat_extensiones
END
go

