-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_DOCUMENTOS_REPORTE_CONTRALORIA_GV
/*
este SP esta basado en [SEL_DOCUMENTOS_REPORTE_CONTRALORIA] 
[SEL_DOCUMENTOS_REPORTE_CONTRALORIA_GV] 'localhost',2398,1
*/
-- =============================================
create PROCEDURE [dbo].[SEL_DOCUMENTOS_REPORTE_CONTRALORIA_GV] 
	@urlParam VARCHAR(30),
	@idPerTra INT,
	@opcion int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	 DECLARE @url VARCHAR(500);
		DECLARE @fecha DATETIME  = getdate()
		declare	@nombreArchivo VARCHAR(100) ,@ruta VARCHAR(255) 


  IF (@urlParam = 'localhost')
  BEGIN
    SET @url = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = @urlParam);
  END
  ELSE
  BEGIN
    SET @url = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = 'GET_SERVER');
  END

  DECLARE @saveUrl VARCHAR(100) = (SELECT
									  pr_descripcion
									FROM parametros
									WHERE pr_identificador = 'Url_Server_ADG');


	set @ruta = @url +'Comprobaciones/Comprobacion/ReporteGastosViaje/' + 'Tramite_' + CONVERT(VARCHAR(20),@idPerTra)+'/'
	set @nombreArchivo =  'PresupuestoViaje_' + CONVERT(VARCHAR(20),@idPerTra)+'_'+replace(convert(varchar(30), @fecha, 103),'/','')+'_'+ replace(convert(varchar(30), @fecha, 108),':','')+'.pdf'

	if(@opcion=0)
	begin
	INSERT INTO Tramites.dbo.HistoricoPresupuestosGVAprobados( idPerTra ,nombreArchivo, fecha ,ruta, activo)
	select @idPerTra as idFondoFijo
	, @nombreArchivo as nombreArchivo
	,@fecha
	, @ruta as ruta
	,1
	end

	if(@opcion = 0)
	begin
		select 1 as success
		,@idPerTra
		,@fecha as fecha
		, @nombreArchivo as nombreArchivo
		, @ruta as ruta
		,@ruta+@nombreArchivo as [url]
		,@saveUrl+'ReporteGastosViaje/Tramite' as saveUrl
		,1 as existe
		, 2 as idExtension	

	end

	if (@opcion = 1)
	begin
		select ea.id
		  ,convert( varchar(50),ea.fecha,103)+ ' '+ convert( varchar(50),ea.fecha,108) as fecha
		  ,ea.nombreArchivo
		  ,ea.ruta
		from HistoricoPresupuestosGVAprobados ea		
		where ea.idPerTra = @idPerTra
		--and ea.activo = 1
	end

END
go

