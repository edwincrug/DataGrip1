-- =============================================
-- Author:		Luis Garcia
-- Create date: 14/06/2019
-- Description:	Actualiza el estatus del documente
-- TEST UPD_RECHAZO_ESTATUS_DOCUMENTO_SP 1, 'Por que si'
-- =============================================
CREATE PROCEDURE [dbo].[UPD_RECHAZO_ESTATUS_DOCUMENTO_SP] 
	@det_idPerTra INT,
	@razonesRechazo VARCHAR(100),
	@id_perTra INT,
	@id_documento INT,
	@id_usuario INT = NULL
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY

	IF EXISTS(SELECT det_idPerTra FROM detallePersonaTramite WHERE det_idPerTra = @det_idPerTra)
		BEGIN 
			UPDATE detallePersonaTramite
			SET det_estatus = 3,
			det_observaciobes = @razonesRechazo
			WHERE det_idPerTra = @det_idPerTra;
			INSERT INTO BitacoraTramite
			SELECT @id_usuario, @id_perTra, 'Se rechazo el documento con det_idPerTra ' +  CONVERT(varchar(20), @det_idPerTra), GETDATE();
		END
	ELSE
		BEGIN
			DECLARE @id_traDo INT = (SELECT id_traDo FROM [Tramites].[dbo].[cat_tramiteDocumento] where id_documento = @id_documento)
		
			INSERT INTO detallePersonaTramite
			SELECT @id_perTra , @id_traDo, 3, @razonesRechazo

			IF(@id_usuario IS NOT NULL)
				BEGIN
					INSERT INTO BitacoraTramite
					SELECT @id_usuario, @id_perTra, 'Se pidio el documento con idTrado ' +  CONVERT(varchar(20), @id_traDo), GETDATE();
				END
		END


	SELECT success = 1, msg = 'Se rechazo el documento con éxito.'

COMMIT TRANSACTION
END TRY

BEGIN CATCH
ROLLBACK TRANSACTION
	SELECT success = 0;
END CATCH
END
go

