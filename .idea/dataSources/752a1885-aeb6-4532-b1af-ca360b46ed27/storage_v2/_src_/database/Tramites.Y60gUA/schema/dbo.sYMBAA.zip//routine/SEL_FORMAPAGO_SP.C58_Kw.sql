-- =============================================
-- Author:		<Luis García>
-- Create date: <03/07/2019>
-- Description:	<Trae todas las formas de pago>
--TEST SEL_FORMAPAGO_SP 
-- =============================================
CREATE PROCEDURE SEL_FORMAPAGO_SP
AS
BEGIN
	SELECT 
		id_formaPago,
		foPa_tipoPago 
	FROM cat_formaPago
END
go

