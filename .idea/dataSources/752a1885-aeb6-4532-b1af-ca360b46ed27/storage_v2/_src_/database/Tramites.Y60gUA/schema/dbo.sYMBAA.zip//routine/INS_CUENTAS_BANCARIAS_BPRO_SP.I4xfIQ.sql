-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_CUENTAS_BANCARIAS_BPRO_SP] 
	@idUsuario VARCHAR(50)
	,@idPerTra INT 
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
		/***************UNIFICAR CUENTAS*******************************/
		DECLARE @contBases INT = 1, 
				@numRegistros INT = 0, 
				@contBancos INT = 1, 
				@banxico VARCHAR(20), 
				@numRegistrosCuentas INT = 0, 
				@existe INT,
				@emp_idempresa INT,  
				@idRespuestaUni INT, 
				@cie VARCHAR(50), 
				@noCuenta VARCHAR(50),
				@tipoCuentaBancaria VARCHAR(5),
				@cveBanco VARCHAR(10)=''
		DECLARE @BASES TABLE(id int identity(1,1),emp_idempresa INT,base nvarchar(200));
		DECLARE @basePrincipal VARCHAR(50) = '', @queryCuentaSel NVARCHAR(MAX) = '', @queryBanco NVARCHAR(MAX) = '', @SQLString NVARCHAR(MAX), @sqlUni VARCHAR(MAX)
		DECLARE @ParmDefinition nvarchar(500) , @usuario VARCHAR(20)
        
		--SELECT  @usuario = usu_nombreusu 
		--FROM    ControlAplicaciones.dbo.Cat_usuarios 
		--WHERE   usu_idusuario  = @idUsuario

		select  @usuario = eqv_usubusiness  from controlAplicaciones.dbo.eqv_organigrama where usu_usuario = @idUsuario


		DECLARE  @idPersona NUMERIC(18,0)
    
   
		INSERT INTO @BASES
		SELECT 
			emp_idempresa,
			nombre_base  
		FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2
		SET @numRegistros = (select COUNT(1) from @BASES)
		PRINT @numRegistros
    
			select  @banxico = cveBanxico,@idPersona= PER_IDPERSONA , @noCuenta = cuentaBancaria, @cie = ''
			FROM    Tramites.dbo.tramiteDevoluciones t 
			inner join Tramites.dbo.PersonaTramite PT ON PT.id_perTra = T.id_perTra where t.id_perTra = @idPerTra
        
			--SELECT @cveBanco = pbx_par_idenpara 
			--FROM Pagos.[dbo].[PAG_CAT_BANXICO]  WHERE pbx_numoficial =  @banxico
			--ORDER BY  pbx_numoficial  
                        
				WHILE(@contBases<= @numRegistros)
					BEGIN
						--PRINT'ENTRO-2'
						SELECT 
							@basePrincipal = base, 
							@emp_idempresa = emp_idempresa 
						FROM @BASES 
						WHERE id = @contBases
						--PRINT @basePrincipal
						IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @basePrincipal)) 
							BEGIN
								SET @existe = 0
								--SET @SQLString = 'IF EXISTS (SELECT 1 from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''') BEGIN SET @res = 1 END '
								SET @SQLString = 'IF EXISTS (SELECT 1 from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''') BEGIN    SELECT @res= PAR_IDENPARA FROM ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''' END '
								
								
								SET @ParmDefinition = N' @res VARCHAR(10) OUTPUT'; 
								print (@SQLString)
								EXECUTE sp_executesql @SQLString, @ParmDefinition, @res= @cveBanco OUTPUT 
							END
							IF(  @cveBanco !='')
								BEGIN
									SET @sqlUni = 'INSERT INTO ' + @basePrincipal+'.[dbo].[CON_BANCOS]
																([BCO_IDPERSONA]
																,[BCO_BANCO]
																,[BCO_PLAZA]
																,[BCO_SUCURSAL]
																,[BCO_STATUS]
																,[BCO_TIPCUENTA]
																,[BCO_NUMCUENTA]
																,[BCO_CLABE]
																,[BCO_CVEUSU]
																,[BCO_FECHOPE]
																,[BCO_HORAOPE]
																,[BCO_REFERNUM]
																,[BCO_REFERALF]
																,[BCO_CONVENIOCIE]
																,[BCO_AUTORIZADA]) 
													SELECT '+ CONVERT(VARCHAR(10),@idPersona)+ '
															,'''+@cveBanco+'''
															,''1''
															,''1''
															,''ACTIVO''
															,tipoCuentaBancaria
															,cuentaBancaria
															,numeroClabe
															,''' + @usuario+ '''
															,CONVERT(VARCHAR(10), GETDATE(),103)
															,CONVERT(CHAR(8), GETDATE(), 108) 
															,''''
															,''''
															,''''
															,1 
													FROM Tramites.dbo.tramiteDevoluciones
													WHERE id_perTra = '+ CONVERT(VARCHAR(10), @idPerTra) 
									EXECUTE (@sqlUni)
									--SELECT @idPersona idPersona, @noCuenta noCuenta, @cie CIE, @emp_idempresa idEmpresa, @usuario Usuario
									--SELECT @idPersona idPersona, @noCuenta noCuenta, @cie CIE, @emp_idempresa idEmpresa, @idUsuario idUsuario
									EXEC Pagos.[dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP] @idProveedor = @idPersona , @cuenta = @noCuenta ,  @convenio = @cie, @idEmpresa =  @emp_idempresa, @idUsuario = @idUsuario, @result = @idRespuestaUni OUTPUT
									SET @contBases = @numRegistros
								END
								BEGIN
									SET @contBases= @contBases+1 
								END
                            
							END
        INSERT INTO BitacoraTramite 
        SELECT @idUsuario, @idPerTra, 'Se inserto la cuenta bancaria', GETDATE(), null
		   
		SELECT 1 result
		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		SELECT -1 result
	END CATCH
END
go

