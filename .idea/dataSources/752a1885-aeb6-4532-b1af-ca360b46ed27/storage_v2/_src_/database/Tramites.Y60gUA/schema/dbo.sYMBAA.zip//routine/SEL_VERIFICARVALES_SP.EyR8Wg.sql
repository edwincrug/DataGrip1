

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <24/01/2020>
-- Description:	<SP que verifica los vales>
-- [dbo].[SEL_VERIFICARVALES_SP] 451
-- =============================================

-- =============================================
-- Modificación:<Alejandro Grijalva Antonio>
-- Create date: <31/07/2020>
-- Description:	<Tolerancia de 10 centavos (Parametrizado) para comprobacion de más>
-- [dbo].[SEL_VERIFICARVALES_SP] 552
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VERIFICARVALES_SP] 
	@idVale INT
AS
BEGIN

DECLARE @nombreBD VARCHAR(100), @idsucursal INT, @vale VARCHAR(100), @proceso VARCHAR(100) = 'AVFF', @comprobado INT = 0
select @idsucursal = ff.idSucursal, @vale = v.idVale from Tramite.vales v
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
where v.id = @idVale
select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal

DECLARE @Tablevar TABLE(Result INT)
DECLARE @Query VARCHAR(MAX)
       
SET @Query = 'SELECT * FROM  ['+@nombreBD+'].[dbo].[DSBPEncInfo] WHERE DocumentoOrigen = '''+ CAST( @vale AS VARCHAR(100)) + ''' and Proceso = '''+ CAST( @proceso AS VARCHAR(100)) + ''''
SET @Query = 'IF EXISTS (' + @Query + ')
                BEGIN
                     select 1
                END
            ELSE
                BEGIN
                    select 0
                END
            '
INSERT INTO @Tablevar 
EXEC(@query)

	select @comprobado = Result FROM @Tablevar 

	-- SE INTEGRA TOLERANCIA PARA EVIAR JSUTIFICAR DE MAS 10 CENTAVOS
	DECLARE @centavos DECIMAL(2, 2) = (SELECT pr_descripcion centavos FROM parametros WHERE pr_tipoParametro = 'tramite' AND pr_identificador = 'valesTolCentavos')
	PRINT( @centavos )
	-- SE SUMA TOLERACIA A LAS VALIDACIONES PARA COMPROBACION DE MAS

	
	SELECT
		v.montoSolicitado as montoSolicitado,
		--+ ISNULL(v.montoExcedentePolizas,0))  
		SUM(ve.monto) as montoJustificado, 
		CASE WHEN (SUM(ve.monto) >= (v.montoSolicitado - @centavos) AND SUM(ve.monto) <= (v.montoSolicitado + @centavos)) THEN  1 
			when SUM(ve.monto) > (v.montoSolicitado + @centavos)  then 1
			else 0  end as justifico,
		case 
			when SUM(ve.monto) > (v.montoSolicitado + @centavos)  then  
				SUM(ve.monto) - v.montoSolicitado 
			else 0  
		end as justificoMas
		,@comprobado as comprobado
		--,v.estatusVale
	FROM Tramite.valesEvidencia ve 
	INNER JOIN Tramite.vales v on v.id = ve.idVales
	WHERE ve.idvales = @idVale and ve.idestatus = 2
	GROUP BY v.montoSolicitado--, v.estatusVale
END
go

