-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <16/10/2019>
-- Description:	<SP que manda a reembolso el FF>
-- [dbo].[SEL_FONDOFIJOREEMBOLSO_TRAMITE_SP]  
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJOREEMBOLSO_TRAMITE_SP] 
	@id_traDe INT,
	@idUsuario INT,
	@monto decimal(18,4)
AS
BEGIN
	DECLARE @id_perTra INT;
	DECLARE @idPerTraReembolso INT;
	
	DECLARE @idDepartamento INT, @idEmpresa INT, @idSucursal INT, @idPersona INT 
	SELECT @id_perTra = id_perTra,  @idDepartamento = id_departamento, @idEmpresa = id_empresa, @idSucursal = id_sucursal, @idPersona = PER_IDPERSONA FROM tramiteDevoluciones WHERE id_traDe = @id_traDe

	UPDATE tramiteDevoluciones
	SET esDe_IdEstatus = 5
	WHERE id_traDe = @id_traDe

	

	UPDATE Tramite.fondoFijo
	SET estatusFondoFijo = 2--, idReembolso = null
	WHERE id_perTra = @id_perTra

	INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus])
     VALUES
           (@idUsuario
           ,16
           ,GETDATE()
           ,1)

	SET @idPerTraReembolso = SCOPE_IDENTITY()

		INSERT INTO [dbo].[tramiteDevoluciones]
           ([id_perTra]
           ,[id_formaPago]
           ,[id_departamento]
		   ,[traDe_devTotal]
           ,[traDe_Observaciones]
           ,[id_empresa]
           ,[id_sucursal]
		   ,[PER_IDPERSONA]
		   ,[esDe_IdEstatus])
     VALUES
           (@idPerTraReembolso
           ,1
           ,@idDepartamento
		   ,@monto
           ,'Reembolso de fondo Fijo ' +  CONVERT(VARCHAR(20),@id_perTra)
           ,@idEmpresa
           ,@idSucursal
		   ,@idPersona
		   ,5)

	--// BI-VE-001 Bitacora para Vale Evidencias
	BEGIN TRY
		
		DECLARE @Temp TABLE( id INT );
		INSERT INTO @Temp
		SELECT ve.id
		from tramite.fondofijo ff
		inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
		inner join tramite.vales v on v.id = vff.idvales
		inner join tramite.valesEvidencia ve on ve.idVales = v.id and ve.idestatus = 2 and ve.envioReembolso is null
		where ff.id_perTra = @id_perTra
		 
		INSERT INTO [Bitacora].[valesEvidencia]
		SELECT
			[BitacoraFechaRegistro] = GETDATE()
				,[BitacoraTipoOperacion] = 'UPDATE 1'
				,[BitacoraSPExecuted] = '[dbo].[SEL_FONDOFIJOREEMBOLSO_TRAMITE_SP]'
				,[idValeEvidencia] = ve.id
				,ve.[idVales]
				,ve.[idfactura]
				,ve.[idestatus]
				,ve.[esFactura]
				,ve.[url]
				,ve.[archivo]
				,ve.[extension]
				,ve.[monto]
				,ve.[fechaCreacion]
				,ve.[comentario]
				,ve.[idGastoFondoFijo]
				,ve.[areaAfectacion]
				,ve.[conceptoAfectacion]
				,ve.[numeroCuenta]
				,ve.[tipoComprobante]
				,ve.[tipoIVA]
				,ve.[IVA]
				,ve.[IVAretencion]
				,ve.[ISRretencion]
				,ve.[subTotal]
				,ve.[idComprobacionVale]
				,ve.[procesoPoliza]
				,ve.[compNoAutorizado]
				,ve.[estatusReembolso]
				,ve.[envioReembolso]
				,ve.[montoPoliza]
				,ve.[motivo]
				,ve.[envioNotificacion]
				,ve.[fechaRechazo]
				,ve.[comprobacionMas]
				,ve.[comprobacionMasArchivo]
				,ve.[id_perTraReembolso]
				,ve.[estatusPerTraReembolso]
		from tramite.fondofijo ff
		inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
		inner join tramite.vales v on v.id = vff.idvales
		inner join tramite.valesEvidencia ve on ve.idVales = v.id and ve.idestatus = 2 and ve.envioReembolso is null
		INNER JOIN @Temp T ON T.id = ve.id

	END TRY
	BEGIN CATCH 
		PRINT('Ocurrio un error');
	END CATCH
	--// Fin Bitacora para Vale Evidencias


	UPDATE ve
	set ve.envioReembolso = 1, id_perTraReembolso = @idPerTraReembolso
	from tramite.fondofijo ff
	inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	inner join tramite.vales v on v.id = vff.idvales
	inner join tramite.valesEvidencia ve on ve.idVales = v.id and ve.idestatus = 2 and ve.envioReembolso is null
	where ff.id_perTra = @id_perTra  

	--// BI-VE-001 Bitacora para Vale Evidencias
	BEGIN TRY 
		INSERT INTO [Bitacora].[valesEvidencia]
		SELECT
			[BitacoraFechaRegistro] = GETDATE()
				,[BitacoraTipoOperacion] = 'UPDATE 2'
				,[BitacoraSPExecuted] = '[dbo].[SEL_FONDOFIJOREEMBOLSO_TRAMITE_SP]'
				,[idValeEvidencia] = ve.id
				,ve.[idVales]
				,ve.[idfactura]
				,ve.[idestatus]
				,ve.[esFactura]
				,ve.[url]
				,ve.[archivo]
				,ve.[extension]
				,ve.[monto]
				,ve.[fechaCreacion]
				,ve.[comentario]
				,ve.[idGastoFondoFijo]
				,ve.[areaAfectacion]
				,ve.[conceptoAfectacion]
				,ve.[numeroCuenta]
				,ve.[tipoComprobante]
				,ve.[tipoIVA]
				,ve.[IVA]
				,ve.[IVAretencion]
				,ve.[ISRretencion]
				,ve.[subTotal]
				,ve.[idComprobacionVale]
				,ve.[procesoPoliza]
				,ve.[compNoAutorizado]
				,ve.[estatusReembolso]
				,ve.[envioReembolso]
				,ve.[montoPoliza]
				,ve.[motivo]
				,ve.[envioNotificacion]
				,ve.[fechaRechazo]
				,ve.[comprobacionMas]
				,ve.[comprobacionMasArchivo]
				,ve.[id_perTraReembolso]
				,ve.[estatusPerTraReembolso]
		from tramite.fondofijo ff
		inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
		inner join tramite.vales v on v.id = vff.idvales
		inner join tramite.valesEvidencia ve on ve.idVales = v.id and ve.idestatus = 2 and ve.envioReembolso is null
		INNER JOIN @Temp T ON T.id = ve.id

	END TRY
	BEGIN CATCH 
		PRINT('Ocurrio un error');
	END CATCH
	--// Fin Bitacora para Vale Evidencias
	
	SELECT success = 1, id_perTraReembolso = @idPerTraReembolso
END



go

