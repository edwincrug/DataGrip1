-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <03/09/2019>
-- Description:	<Recupera los conceptos contables de un empleado>
--TEST EXEC [Tramite].[Sp_Tramite_EmpleadoConcepto_GETL] 26, 1
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_EmpleadoConcepto_GETL] 
	@idTramiteEmpleado INT,
	@idTipoProceso TINYINT
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	--IF(@idTipoProceso = 1) BEGIN
	--SELECT 
	--	TED.idTramiteConcepto AS [id]
	--	,CC.concepto
	--	,COALESCE(TIS.importe, 0) AS [importeSolicitado]		
	--		,COALESCE((SELECT STUFF(
	--		(SELECT ', ' + comentario 
	--			FROM [Tramite].[TramiteComentario] 
	--			WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 1
	--		FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioSolicitud]
	--	,idTramiteEmpleado
	--	,ET.est_nombre AS [estatus]
	--	,TED.idEstatus
	--FROM [Tramite].[TramiteEmpleadoConcepto] TED
	--INNER JOIN [Tramite].[ConceptoContable] CC ON TED.idConceptoContable = CC.idConceptoContable
	--LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
	--INNER JOIN estatusTramites ET ON TED.idEstatus = ET.id_estatus
	--WHERE idTramiteEmpleado = @idTramiteEmpleado 
	--END
	IF(@idTipoProceso IN (1,2)) BEGIN
		SELECT DISTINCT
			TED.idTramiteConcepto AS [id]
			,CC.concepto
			,COALESCE(TIS.importe, 0) AS [importeSolicitado]
			,COALESCE(TIAS.importe, 0) AS [importeAprobado]			
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 1
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioSolicitud]
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 2
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
			,idTramiteEmpleado
			,ET.esDe_descripcion AS [estatus]
			,ET.esDe_icono AS [icono]
			,TED.idEstatus
			,'MT-8338.pdf, SECFD_20170928_124946.pdf' AS [archivos]
			,NULL AS [archivo]
		,'' AS [comentario]
		, 0 AS [expanded] 
		FROM [Tramite].[TramiteEmpleadoConcepto] TED
		INNER JOIN [Tramite].[ConceptoContable] CC ON TED.idConceptoContable = CC.idConceptoContable
		LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
		LEFT JOIN [Tramite].[TramiteImporte] TIAS ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
		INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
		WHERE idTramiteEmpleado = @idTramiteEmpleado 
	END
	IF(@idTipoProceso = 3) BEGIN
	SELECT 
		TED.idTramiteConcepto AS [id]
		,CC.concepto
		,(SELECT COALESCE(SUM(importe), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 2) AS [importeAprobado]	
		,(SELECT COALESCE(SUM(importe), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 3) AS [importeComprobado]	
		,(SELECT COALESCE(SUM(importeiVa), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 3) AS [importeComprobadoIva]				
			,COALESCE((SELECT STUFF(
			(SELECT ', ' + comentario 
				FROM [Tramite].[TramiteComentario] 
				WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 3
			FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
			,COALESCE((SELECT STUFF(
			(SELECT ', ' + comentario 
				FROM [Tramite].[TramiteComentario] 
				WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 4
			FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioApComprobacion]
		,idTramiteEmpleado
			,ET.esDe_descripcion AS [estatus]
			,ET.esDe_icono AS [icono]
		,TED.idEstatus
			,'MT-8338.pdf, SECFD_20170928_124946.pdf' AS [archivos]
		,NULL AS [archivo]
		,'' AS [comentario]
		, 0 AS [expanded]
	FROM [Tramite].[TramiteEmpleadoConcepto] TED
	INNER JOIN [Tramite].[ConceptoContable] CC ON TED.idConceptoContable = CC.idConceptoContable
	INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
	WHERE idTramiteEmpleado = @idTramiteEmpleado AND TED.idEstatus = 2
	
	END
	IF(@idTipoProceso = 4) BEGIN
		SELECT 
			TED.idTramiteConcepto AS [id]
			,CC.concepto
			,(SELECT COALESCE(SUM(importe), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 4) AS [importeAprobado]	
		,(SELECT COALESCE(SUM(importe), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 3) AS [importeComprobado]	
		,(SELECT COALESCE(SUM(importeiVa), 0) FROM [Tramite].[TramiteImporte] 
			WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 3) AS [importeComprobadoIva]				
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 3
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
				,COALESCE((SELECT STUFF(
				(SELECT ', ' + comentario 
					FROM [Tramite].[TramiteComentario] 
					WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 4
				FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioApComprobacion]
			,idTramiteEmpleado
			,ET.esDe_descripcion AS [estatus]
			,ET.esDe_icono AS [icono]
			,TED.idEstatus
			,'MT-8338.pdf, SECFD_20170928_124946.pdf' AS [archivos]
			,'' AS [archivo]
		, 0 AS [expanded]
		FROM [Tramite].[TramiteEmpleadoConcepto] TED
		INNER JOIN [Tramite].[ConceptoContable] CC ON TED.idConceptoContable = CC.idConceptoContable
		--LEFT JOIN [Tramite].[TramiteImporte] TIC ON TED.idTramiteConcepto = TIC.idTramiteConcepto AND TIC.idTipoProceso = 3
		--LEFT JOIN [Tramite].[TramiteImporte] TIAC ON TED.idTramiteConcepto = TIAC.idTramiteConcepto AND TIAC.idTipoProceso = 4
		INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
		WHERE idTramiteEmpleado = @idTramiteEmpleado AND TED.idEstatus = 2
	END
	
	--SELECT 
	--	TED.idTramiteConcepto AS [id]
	--	,CC.concepto
	--	,COALESCE(TIS.importe, 0) AS [importeSolicitado]
	--	,COALESCE(TIAS.importe, 0) AS [importeAprobado]	
	--	,COALESCE(TIC.importe, 0) AS [importeComprobado]	
	--	,COALESCE(TIAC.importe, 0) AS [importeApComprobacion]			
	--		,COALESCE((SELECT STUFF(
	--		(SELECT ', ' + comentario 
	--			FROM [Tramite].[TramiteComentario] 
	--			WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 1
	--		FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioSolicitud]
	--		,COALESCE((SELECT STUFF(
	--		(SELECT ', ' + comentario 
	--			FROM [Tramite].[TramiteComentario] 
	--			WHERE idTramiteConcepto = 29 AND idTipoProceso = 2
	--		FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioComprobacion]
	--		,COALESCE((SELECT STUFF(
	--		(SELECT ', ' + comentario 
	--			FROM [Tramite].[TramiteComentario] 
	--			WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 3
	--		FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioApSolictud]
	--		,COALESCE((SELECT STUFF(
	--		(SELECT ', ' + comentario 
	--			FROM [Tramite].[TramiteComentario] 
	--			WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 2
	--		FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioCompSolicitud]
	--		,COALESCE((SELECT STUFF(
	--		(SELECT ', ' + comentario 
	--			FROM [Tramite].[TramiteComentario] 
	--			WHERE idTramiteConcepto = TED.idTramiteConcepto AND idTipoProceso = 3
	--		FOR XML PATH ('')), 1, 2, '')), '') AS [comentarioApComprobacion]
	--	,idTramiteEmpleado
	--	,ET.est_nombre AS [estatus]
	--	,TED.idEstatus
	--FROM [Tramite].[TramiteEmpleadoConcepto] TED
	--INNER JOIN [Tramite].[ConceptoContable] CC ON TED.idConceptoContable = CC.idConceptoContable
	--LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
	--LEFT JOIN [Tramite].[TramiteImporte] TIAS ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
	--LEFT JOIN [Tramite].[TramiteImporte] TIC ON TED.idTramiteConcepto = TIC.idTramiteConcepto AND TIC.idTipoProceso = 3
	--LEFT JOIN [Tramite].[TramiteImporte] TIAC ON TED.idTramiteConcepto = TIAC.idTramiteConcepto AND TIAC.idTipoProceso = 4
	--INNER JOIN estatusTramites ET ON TED.idEstatus = ET.id_estatus
	--WHERE idTramiteEmpleado = @idTramiteEmpleado 

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

