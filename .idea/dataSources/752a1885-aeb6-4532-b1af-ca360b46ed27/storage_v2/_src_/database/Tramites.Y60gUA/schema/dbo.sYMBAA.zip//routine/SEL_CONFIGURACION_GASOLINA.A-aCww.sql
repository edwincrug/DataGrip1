-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CONFIGURACION_GASOLINA]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT id
      ,distanciaMinima
      ,rendimientoPromedio
      ,litros
      ,precioPorLitro
      ,autorizadoPorKilometro
      ,fecha
      ,activo
  FROM Tramites.dbo.configuracionPrecioCombustiblesGV
  WHERE activo = 1

END
go

