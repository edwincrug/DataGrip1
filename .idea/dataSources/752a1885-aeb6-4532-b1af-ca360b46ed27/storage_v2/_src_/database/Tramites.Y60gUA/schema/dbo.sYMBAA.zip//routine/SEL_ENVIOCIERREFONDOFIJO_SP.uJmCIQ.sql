
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ENVIOCIERREFONDOFIJO_SP]  
	@id_perTra INT,
	@tipo INT,
	@comprobante varchar(100),
	@arqueo varchar(100)
AS
BEGIN

UPDATE tramite.fondofijo
SET estatusFondoFijo = 5, tipoCierre = @tipo, comprobanteCierre = @comprobante, arqueoCierre = @arqueo
WHERE id_perTra = @id_perTra

select 1 success
END
go

