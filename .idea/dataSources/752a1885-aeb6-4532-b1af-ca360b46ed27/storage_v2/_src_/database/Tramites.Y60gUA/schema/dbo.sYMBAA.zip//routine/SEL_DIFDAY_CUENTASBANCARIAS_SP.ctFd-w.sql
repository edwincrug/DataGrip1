-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <12/06/2019>
-- Description:	<Trae los dias de diferencia>
-- TEST SEL_DIFDAY_SP
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DIFDAY_CUENTASBANCARIAS_SP]
AS
BEGIN
	SELECT 
		PETR.id_perTra,
		DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
	FROM [Tramites].[dbo].[personaTramite] PETR
	INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
	INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
	INNER JOIN cuentasTesoreria CT ON CT.id_perTra = PETR.id_perTra
	WHERE PETR.petr_estatus IN (1, 2) AND CT.estatus != 3
	GROUP BY PETR.id_perTra, petr_fechaTramite

	SELECT 
		pr_descripcion 
	FROM parametros 
	WHERE id_parametro IN (7, 8)
END
go

