
CREATE PROCEDURE SEL_BANCO_POR_EMPRESA_SP
@idEmpresa INT 
AS
BEGIN
	DECLARE @bd VARCHAR(100),
		@sql VARCHAR(500)

	select @bd = nombre_base from Centralizacionv2.dbo.DIG_CAT_BASES_BPRO where emp_idempresa = @idEmpresa  and tipo = 2


	SET @sql = 'SELECT PAR_DESCRIP5 cveBanxico
			, PAR_DESCRIP1 nombreBanco
			, PAR_IDENPARA cveBanco 
			FROM	'+@bd+'.dbo.PNC_PARAMETR AS PG 
			WHERE PG.PAR_TIPOPARA = ''BA'' AND PG.PAR_STATUS = ''A'' AND PAR_DESCRIP5 != '''' order by 2'


	EXEC(@sql)
END
go

