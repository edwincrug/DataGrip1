-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	actualiza el estatus de las notificaciones de vales vencidos
-- =============================================

-- Se creo la columna notificadoFinanzas en tramite.vales
CREATE PROCEDURE [dbo].[ACTUALIZA_VALE_NOTIFICACION]
	@id INT
  ,@notificaUsuario BIT = 0
  ,@notificaNomina BIT = 0
  ,@notificaContraloria BIT = 0
  ,@notificaFinanzas BIT = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE 
		v
	SET 
		notificadoUsuario = @notificaUsuario, 
		notificadoNominas = @notificaNomina, 
		notificadoContraloria = @notificaContraloria,
		notificadoFinanzas = @notificaFinanzas
	FROM Tramites.tramite.vales v
	WHERE v.descuentoSolicitado = 1
	AND v.id = @id

	SELECT estatus = 1, mensaje = 'Se ha actualizado el registro'
END
go

