
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <07/05/2020>
-- Description:	<SP que inserta la factura de una orden de compra>
-- =============================================
CREATE PROCEDURE [dbo].[INS_FACTURA_VALE__ORDEN_SP]
    @idVale INT,
	@idestatus INT,
	@tipoGasto INT,
	@iva DECIMAL(18,2),
	@monto DECIMAL (8,2),
	@uuid VARCHAR(MAX),
	@rfcEmisor VARCHAR(MAX),
	@rfcReceptor VARCHAR(MAX),
	@fechafactura datetime,
	@PER_IDPERSONA INT,
	@ordenCompra VARCHAR(100),
	@motivoEvidencia varchar (max)

AS   
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY

DECLARE @incremental INT = 0, @nombreVale varchar(100), @idComprobacionVale varchar(100), @idValeEvidencia INT, @idFactura INT

	select @incremental =  COUNT(id)  from tramite.valesevidencia where idvales = @idVale
	select @nombreVale = idVale from tramite.vales where id = @idVale
	SET @incremental = @incremental + 1;
	SET @idComprobacionVale = @nombreVale  + '-' + CONVERT(varchar(10), @incremental) 

IF NOT EXISTS (SELECT 1 FROM tramite.valesEvidencia ve inner join Tramite.FacturaVale fv on fv.idValeEvidencia = ve.id
			   WHERE fv.uuid=@uuid and ve.idestatus not in (3))
BEGIN
	INSERT INTO [Tramite].[valesEvidencia] 
	(idVales,idestatus,archivo,extension,fechaCreacion,url,monto,idGastoFondoFijo,idComprobacionVale,motivo)
	VALUES
	(@idVale,@idestatus,'','',GETDATE(),'',@monto,@tipoGasto,@idComprobacionVale, @motivoEvidencia)
	SET @idValeEvidencia = SCOPE_IDENTITY()

	--// BI-VE-001 Bitacora para Vale Evidencias
	EXEC [Bitacora].[Sp_Tramite_ValeEvidencia_INS] 'INSERT', '[dbo].[INS_FACTURA_VALE__ORDEN_SP]', @idValeEvidencia
	--// Fin Bitacora para Vale Evidencias
	
	INSERT INTO Tramite.FacturaVale(idValeEvidencia,numFactura,uuid,fechaFactura,subTotal,iva,total,fechaCreacion,rfcEmisor,rfcReceptor,PER_IDPERSONA, ordenCompra)
	VALUES(@idValeEvidencia, '', @uuid, @fechaFactura, 0, @iva, @monto, GETDATE(), @rfcEmisor, @rfcReceptor,@PER_IDPERSONA, @ordenCompra);
	SET @idFactura = SCOPE_IDENTITY()

	UPDATE [Tramite].[valesEvidencia] 
	SET idfactura = @idFactura
	WHERE id = @idValeEvidencia

	
	SELECT success = 1, msg = 'Se inserto correctamente'
END
ELSE
BEGIN
SELECT success = 2, msg = 'La factura ya se encuentra registrada';
END
	
END TRY
	BEGIN CATCH
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END


go

