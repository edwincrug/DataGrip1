-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <11/06/2019>
-- Description:	Trae los tramites por area
--TEST SEL_TRAMITE_BY_AREA_SP 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TRAMITE_BY_AREA_SP_respaldo] 
	@idArea INT
AS
BEGIN
	SELECT 
		ESTR.est_nombre,
		PETR.id_perTra,
		PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre AS nombre,
		PETR.petr_fechaTramite,
		TRA.tra_nomTramite,
		PER.id_persona,
		PER.per_rfc
	FROM personaTramite PETR
	INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
	INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
	INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
	WHERE TRA.id_area = @idArea AND PETR.petr_estatus <> 4
	ORDER BY PETR.id_perTra ASC
END
go

