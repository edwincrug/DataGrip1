-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [Tramite].[Sp_Tramite_ObtieneCuenta_GET] 1993
CREATE PROCEDURE [Tramite].[Sp_Tramite_ObtieneCuenta_GET]
	@idPersona INT = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT TOP 1 *
	FROM [dbo].[cuentaAutorizada] PT 
	WHERE idPersona = @idPersona
	ORDER BY idCuentaAutorizada DESC
END
go

