-- =============================================
-- Author:		<Luis Garccía>
-- Create date: <03/07/2019>
-- Description:	<Trae todas las empresas>
--TEST SEL_EMPRESAS_SP
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EMPRESAS_SP]
@usu_idusuario INT
AS
BEGIN
	SELECT DISTINCT
		contrApp.emp_idempresa AS emp_idempresa, 
		contrApp.emp_nombre AS emp_nombre
	FROM [ControlAplicaciones].[dbo].[cat_empresas] contrApp
	INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] centBases ON contrApp.emp_idempresa = centBases.emp_idempresa
	INNER JOIN ControlAplicaciones..ope_organigrama OPE ON OPE.emp_idempresa = contrApp.emp_idempresa
	WHERE contrApp.emp_idempresa !=0 AND centBases.tipo = 2 AND OPE.usu_idusuario = @usu_idusuario
END
go

