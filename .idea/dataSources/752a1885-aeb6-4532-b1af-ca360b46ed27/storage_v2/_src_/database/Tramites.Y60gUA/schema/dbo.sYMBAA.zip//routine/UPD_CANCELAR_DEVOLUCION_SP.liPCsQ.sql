CREATE PROCEDURE [dbo].[UPD_CANCELAR_DEVOLUCION_SP]
@idPertra INT 
AS
BEGIN
BEGIN TRAN
BEGIN TRY

	DECLARE @idDetalle INT = (SELECT id_traDe FROM tramiteDevoluciones WHERE id_perTra =  @idPertra )

	UPDATE personaTramite 
	set	petr_estatus = 14
	WHERE id_perTra = @idPertra

	update documentosDevueltos 
	SET		docDe_valorDev = 0
	where id_traDe = @idDetalle

	select 1 result
COMMIT TRAN
END TRY
BEGIN CATCH
ROLLBACK TRAN
	select 0 result
END CATCH

END

go

