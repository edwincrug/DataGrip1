-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_CONSULTA_PRESUPUESTOS_FIRMADOS 2389,4,6,21
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CONSULTA_PRESUPUESTOS_FIRMADOS]
	 @idPerTra INT
	,@idEmpresa int
	,@idSucursal int
	,@idDepartamento int

	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE
	@maxIdPresupuesto INT
	,@numConceptosPresupuestoFirmado INT
	,@idToken INT
	,@token VARCHAR(6)
	,@numConceptostramite int
	,@idUsuario int

	SELECT  @maxIdPresupuesto = ISNULL(MAX(pg.idPresupuesto),0)
	FROM PresupuestosGVAutorizados pg
	WHERE pg.id_perTra = @idPerTra


	SELECT @numConceptostramite = count(ti.idTramiteImporte)
	FROM Tramites.dbo.tramiteDevoluciones d
	JOIN personaTramite PT 
	  ON PT.id_perTra = d.id_perTra
	  AND pt.id_tramite = 9
	LEFT JOIN [Tramite].[TramiteEmpleado] TE 
	  ON d.id_perTra = TE.idTramiteDevolucion
	JOIN ControlAplicaciones.dbo.cat_empresas ce
	  ON d.id_empresa = ce.emp_idempresa
	JOIN ControlAplicaciones.dbo.cat_sucursales cs
	  ON d.id_sucursal = cs.suc_idsucursal
	JOIN ControlAplicaciones.dbo.cat_departamentos cd
	  ON d.id_departamento = cd.dep_iddepartamento 
	JOIN [Tramite].[TramiteConcepto] tc
	  ON d.id_perTra = tc.idTramitePersona
	  and tc.idEstatus = 2
	  and idSalidaEfectivo is null
	JOIN Tramite.TramiteImporte ti 
	  ON tc.idTramiteConcepto = ti.idTramiteConcepto
	AND ti.idtipoProceso = 2
	left join ControlAplicaciones..cat_usuarios cu
			on pt.id_persona = cu.usu_idusuario
	LEFT JOIN tramite.ConceptoArchivo ca
	  ON ti.idConceptoArchivo = ca.idConceptoArchivo
	LEFT JOIN Tramite.ConceptoContable cc 
	  ON tc.idConceptoContable = cc.idConceptoContable
	  and ce.emp_idempresa = cc.idEmpresa
	  and cs.suc_idsucursal = cc.idSucursal
	WHERE tc.idTramitePersona = @idPerTra
	AND d.id_empresa = @idEmpresa
	AND d.id_sucursal = @idSucursal
	AND d.id_departamento = @idDepartamento

	IF @maxIdPresupuesto = 0 BEGIN  
		SELECT 0 AS estatus, 'No hay presupuestos almacenados' AS mensaje, 0 as numConceptos, '' as token
	END
	ELSE 
	BEGIN
  
	  SELECT @numConceptosPresupuestoFirmado = COUNT(*) 
		FROM PresupuestosGVAutorizados pg
		WHERE pg.id_perTra = @idPerTra
		AND pg.idPresupuesto = @maxIdPresupuesto


		SELECT DISTINCT
		 @token = t.token, @idToken = df.idToken, @idUsuario = t.idUsuarioSolicitante
		  FROM DocumentosFirmados df
		  JOIN PresupuestosGVAutorizados pg
		  ON df.idDocumento = @maxIdPresupuesto
		  JOIN Token t
		  ON df.idToken = t.id 

		  if(@numConceptosPresupuestoFirmado = @numConceptostramite)
		  begin
			SELECT 1 AS estatus, @numConceptosPresupuestoFirmado AS numConceptos, @token AS token, @idToken as idToken, @idUsuario as idUsuario
		  end
		  else
		  begin
			Select 0 as estatus, 'Es no coinciden los conceptos, es necesario firmar el presupuesto' as mensaje
		  end

	  
	END

END
go

