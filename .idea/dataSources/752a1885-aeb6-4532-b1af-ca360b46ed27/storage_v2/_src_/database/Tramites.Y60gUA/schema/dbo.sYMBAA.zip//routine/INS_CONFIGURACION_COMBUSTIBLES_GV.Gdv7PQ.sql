-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	guarda historico de precios de combustibles
-- INS_GUARDA_HISTORICO_COMBUSTIBLES 50, 8.75
-- =============================================
CREATE  PROCEDURE [dbo].[INS_CONFIGURACION_COMBUSTIBLES_GV]
	@distancia int = 50,
	@rendimientoPromedio decimal(18,2) = 8.75
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @litro decimal(18,2)
	,@montoPagar decimal(18,2)
	,@autorizaPorKilometro decimal(18,2)
	,@ultimoIndice int
	,@precioLitro decimal(18,2)


	set @precioLitro = (SELECT precio 
						FROM Tramites.dbo.PrecioGasolinas
						where activo = 1)

	set @litro = (@distancia/@rendimientoPromedio)
	set @montoPagar = (@litro*@precioLitro)
	set @autorizaPorKilometro = (@montoPagar/@distancia)


	set @ultimoIndice = (select isnull(max(id),0)
							from ConfiguracionPrecioCombustiblesGV)

	if(@ultimoIndice >= 1)
	begin
		update hpc
		set hpc.activo = 0
		from ConfiguracionPrecioCombustiblesGV hpc
		where id = @ultimoIndice
	end

	insert ConfiguracionPrecioCombustiblesGV(distanciaMinima, rendimientoPromedio, litros, precioPorLitro, autorizadoPorKilometro, fecha, activo)
	select @distancia as km
	,@rendimientoPromedio as Rendimiento_Promedio
	,@litro as litros
	,@precioLitro as Precio_por_litro
	,@autorizaPorKilometro as autorizado_por_kilometro
	,GETDATE() AS fecha
	,1

	select 1 as success,  @distancia as km
	,@rendimientoPromedio as Rendimiento_Promedio
	,@litro as litros
	,@precioLitro as Precio_por_litro
	,@autorizaPorKilometro as autorizado_por_kilometro
	,GETDATE() AS fecha
	,'Se insertaron los siguientes valores' as mensaje

END
go

