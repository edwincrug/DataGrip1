-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 13/08/2020
-- Description:	Guarda el detalle de la CXP orden de compra por anticipo de gastos de viaje y gastos de más
-- [Tramite].[Sp_Tramite_OC_AntGastoDetalle_INS]  'UZA', 44, 1, 'FF-ZM-NZA-OT-1-1-1', 579, 0, 0, 145
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_OC_AntGastoDetalle_INS]
	@omd_areaafectacion varchar(20)
	,@omd_conceptocontable varchar(20)
	,@omd_cantidad int
	,@omd_producto varchar(250)
	,@omd_preciounitario decimal(18, 5)
	,@omd_tasaiva decimal(18, 5)
	,@omd_descuento decimal(18, 5)
	,@odm_idordenmasiva numeric(18, 0)
AS
BEGIN 
	SET NOCOUNT ON;
	
	DECLARE @idordenmasivadet INT = 0;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_OC_AntGastoDetalle_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
			

			SELECT 
				  omd_areaafectacion	= @omd_areaafectacion
				  ,omd_conceptocontable = @omd_conceptocontable
				  ,omd_cantidad			= @omd_cantidad
				  ,omd_producto			= @omd_producto
				  ,omd_preciounitario	= @omd_preciounitario
				  ,omd_tasaiva			= @omd_tasaiva
				  ,omd_descuento		= @omd_descuento
				  ,odm_idordenmasiva	= @odm_idordenmasiva
		   
			SET @idordenmasivadet = 10
		
		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @idordenmasivadet AS [resultado]
END
go

