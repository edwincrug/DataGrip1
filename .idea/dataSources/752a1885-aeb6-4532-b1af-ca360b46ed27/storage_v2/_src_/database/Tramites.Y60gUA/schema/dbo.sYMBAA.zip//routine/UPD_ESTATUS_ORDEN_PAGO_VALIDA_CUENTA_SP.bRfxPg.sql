-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_ORDEN_PAGO_VALIDA_CUENTA_SP]
	@idPerTra INT
AS
BEGIN
	BEGIN TRANSACTION
		BEGIN TRY
			UPDATE cuentasTesoreria SET  estatus = 3 WHERE id_perTra = @idPerTra;
			UPDATE tramiteDevoluciones SET esDe_IdEstatus = 5 WHERE id_perTra = @idPerTra;
			DECLARE @RespuestaInsert INT
			EXEC [Tramites].[DBO].[INS_DATOS_CXC_DEVOLUCIONES] @idPerTra, @result = @RespuestaInsert OUTPUT
			IF(@RespuestaInsert = 0)
				BEGIN
					SELECT 1/0
				END
			INSERT INTO BitacoraTramite VALUES(4308,@idPerTra,'Validación de cuenta o compra orden de pago',getdate(),5);
			SELECT success = 1;
	COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
		SELECT success = 0;
	END CATCH
END


go

