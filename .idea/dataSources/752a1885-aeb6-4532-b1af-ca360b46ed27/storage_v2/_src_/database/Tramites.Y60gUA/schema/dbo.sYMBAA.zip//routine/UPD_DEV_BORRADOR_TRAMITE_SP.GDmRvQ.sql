-- =============================================
-- Author:		<Luis García>
-- Create date: <10/07/2019>
-- Description:	<Actualiza la informacion del borrador>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_DEV_BORRADOR_TRAMITE_SP]
	@idPerTra INT,
	@idEmpresa INT,
	@idFormaPago INT,
	@observaciones VARCHAR(500),
	@idSucursal INT,
	@idDepartamento INT,
	@devTotal NUMERIC(18,5),
	@idCliente INT,
	@cuentaBancaria VARCHAR(20) = '',
	@numeroCLABE VARCHAR(20) = '',
	@cveBanxico VARCHAR(5) = '',
	@bancoTipoCuenta VARCHAR(3)
AS
BEGIN
	UPDATE tramiteDevoluciones
	SET id_empresa = @idEmpresa,
	id_sucursal = @idSucursal,
	id_formaPago = @idFormaPago,
	id_departamento = @idDepartamento,
	traDe_Observaciones = @observaciones,
	traDe_devTotal = @devTotal,
	PER_IDPERSONA = @idCliente,
	cuentaBancaria = @cuentaBancaria,
	numeroCLABE = @numeroCLABE,
	cveBanxico = @cveBanxico,
	tipoCuentaBancaria = @bancoTipoCuenta
	WHERE id_perTra = @idPerTra

	SELECT success = 1, msg = 'Se actualizo el trámite correctamente'
 END
go

