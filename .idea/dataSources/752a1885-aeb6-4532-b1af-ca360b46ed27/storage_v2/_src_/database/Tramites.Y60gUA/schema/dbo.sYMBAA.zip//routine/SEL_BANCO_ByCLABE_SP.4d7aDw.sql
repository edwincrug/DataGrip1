-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2020/07/07
-- Description:	Se busca el banco mediante la cuenta CLABE
-- [dbo].[SEL_BANCO_ByCLABE_SP] '006000000000000001'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_BANCO_ByCLABE_SP]
	-- Add the parameters for the stored procedure here
	@CLABE VARCHAR(18) = null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Codigo VARCHAR(3) = SUBSTRING(@CLABE, 1, 3);
	DECLARE @cveBanxico VARCHAR(5), @NombreBanco VARCHAR(30), @IdBanco VARCHAR(10);
	SELECT
		@cveBanxico = pbx_numoficial
		,@NombreBanco = pbx_descripcion
		,@IdBanco = pbx_par_idenpara
	FROM Pagos.[dbo].[PAG_CAT_BANXICO]
	WHERE pbx_numoficial = @Codigo;

	IF EXISTS( SELECT ca_clabe FROM [dbo].[cuentaAutorizada] WHERE ca_clabe = @CLABE )
		BEGIN 
			SELECT 
				ca_clabe,
				ca_cuenta,
				ca_idbanco,
				ca_banconombre,
				ca_plaza,
				ca_sucursal,
				ca_cvebanxico,
				ca_estatus,
				@cveBanxico cveBanxico,
				@NombreBanco NombreBanco,
				@IdBanco IdBanco,
				observaciones
			FROM [dbo].[cuentaAutorizada] WHERE ca_clabe = @CLABE;
		END
	ELSE
		BEGIN 
			SELECT 
				@cveBanxico cveBanxico,
				@NombreBanco NombreBanco,
				@IdBanco IdBanco
		END
END


-- SELECT * FROM [dbo].[cuentaAutorizada] WHERE ca_clabe = '006000000000000010'
go

