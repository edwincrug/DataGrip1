-- =============================================
-- Author:		***********
-- Create date: 11/11/2020
-- Description:	Obtiene los documentos por tramite
-- =============================================
-- ============== Versionamiento ================
/*
	Fecha 11/11/2020		Autor: *********** 	 Description:	Obtiene los documentos por tramite

	*- Testing...
	EXEC [dbo].[SEL_DOCUMENTOS_TRAMITES_SP] @idTramite = 4, @idUsuario = 71
*/
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_TRAMITES_SP]
	@idTramite INT
	,@idUsuario INT
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		SELECT	TD.id_traDo
				,D.doc_nomDocumento
				,ISNULL(TD.mandatorioEfectivo, 0) AS mandatorioEfectivo
				,ISNULL(TD.efectivo,0) AS efectivo
				,ISNULL(TD.mandatorioBancario, 0) AS mandatorioBancario
				,ISNULL(TD.bancario,0) AS bancario
				,ISNULL(TD.activo,0) AS activo
				,ISNULL(MT.[activo], 0) AS modificar
				,D.id_documento
		FROM	cat_tramites AS T
				INNER JOIN cat_tramiteDocumento AS TD ON TD.id_tramite = T.id_tramite
				INNER JOIN cat_documentos AS D ON D.id_documento = TD.id_documento
				LEFT JOIN [dbo].[modificaTramite] AS MT ON MT.[id_tramite] = T.id_tramite AND MT.[id_usuario] = @idUsuario
		WHERE	T.id_tramite = @idTramite 
			
	END TRY

	BEGIN CATCH
		SELECT 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE() AS err;
	END CATCH
END
go

