-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <03/09/2019>
-- Description:	<Recupera los conceptos de un xml>
--TEST EXEC [Tramite].[Sp_Tramite_ArchivoDetalle_GETLByIdConceptoArchivo]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ArchivoDetalle_GETLByIdConceptoArchivo] 
	@idConceptoArchivo INT
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	SELECT 
		idArchivoDetalle
		,cantidad
		,unidad
		,numeroIdentificacion
		,descripcion
		,valorUnitario
		,importe
	FROM [Tramite].[ArchivoDetalle]
	WHERE idConceptoArchivo = @idConceptoArchivo

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

