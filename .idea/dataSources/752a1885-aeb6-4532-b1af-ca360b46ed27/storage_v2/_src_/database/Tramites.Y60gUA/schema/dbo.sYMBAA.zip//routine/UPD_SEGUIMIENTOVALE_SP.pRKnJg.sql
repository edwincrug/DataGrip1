		
			

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/10/2019>
-- Description:	<SP que actualiza el estatus del vale>
-- [dbo].[UPD_SEGUIMIENTOVALE_SP]  37,3,''
-- =============================================
CREATE PROCEDURE [dbo].[UPD_SEGUIMIENTOVALE_SP] 
	@idVale INT,
	@accion INT,
	@comentario varchar(MAX) 
AS
BEGIN

	DECLARE  @idAutorizador INT, @correo varchar (100), @nombreAutorizador varchar (100), @vale varchar (100), @id_perTra INT
	select @idAutorizador = idEmpleado, @vale = idVale from Tramite.vales where id = @idVale
	select 
	-- @correo = cu.usu_correo as correo
	@correo = 'juan.peralta@coalmx.com',
	@nombreAutorizador = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	from ControlAplicaciones..cat_usuarios cu 
	where cu.usu_idusuario = @idAutorizador

	select @id_perTra =  ff.id_perTra from Tramite.vales v 
	inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
	inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
	where v.id = @idVale 

	IF(@accion = 2)
	BEGIN

	DECLARE @idFondoFijo INT, @valido INT
	
	select @idFondoFijo = VFF.idTablaFondoFijo from Tramite.vales V
	inner join Tramite.valesFondoFijo VFF on VFF.idVales = V.id
	where V.id = @idVale

	select @valido = case when  sum(monto) <= TD.traDe_devTotal  then 1  else 0 end from Tramite.valesFondoFijo VFF
	inner join Tramite.vales V on VFF.idVales = V.id
	inner join Tramite.fondoFijo FF on FF.id = VFF.idTablaFondoFijo
	inner join tramiteDevoluciones TD on TD.id_perTra = FF.id_perTra
	where idTablaFondoFijo = @idFondoFijo and V.estatusVale not in (5) 
	group by TD.traDe_devTotal

	IF(@valido = 1)
	BEGIN
	UPDATE [Tramite].[vales]
	SET estatusVale = @accion
	WHERE id = @idVale
	SELECT success = 1, msg = 'Se actualizo correctamente', correo = @correo, asunto = 'Autorización Vale ' + @vale,nombreAutorizador =  @nombreAutorizador,vale = @vale, id_perTra = @id_perTra; 
	END
	ELSE
	BEGIN
	SELECT success = 2, msg = 'Se actualizo correctamente';
	END

	END

	IF(@accion = 3)
	BEGIN
	UPDATE [Tramite].[vales]
	SET estatusVale = @accion, fechaEntregaEfectivo = GETDATE()
	WHERE id = @idVale
	
	update ff
	set ff.montoDisponible = ff.montoDisponible - v.montoSolicitado 
	from tramite.vales v 
	inner join Tramite.valesFondoFijo vff on vff.idvales = v.id
	inner join tramite.fondofijo ff on ff.id = vff.idtablafondofijo
	where v.id = @idVale
	
	SELECT success = 1, msg = 'Se actualizo correctamente', correo = @correo, asunto = 'Entrega Efectivo  Vale ' + @vale,nombreAutorizador =  @nombreAutorizador,vale = @vale, id_perTra = @id_perTra; 
	END

	IF(@accion = 5)
	BEGIN
	UPDATE [Tramite].[vales]
	SET estatusVale = @accion, comentario = @comentario
	WHERE id = @idVale
	SELECT success = 1, msg = 'Se actualizo correctamente', correo = @correo, asunto = 'Vale Rechazado ' + @vale,nombreAutorizador =  @nombreAutorizador,vale = @vale, id_perTra = @id_perTra; 
	END


END

go

