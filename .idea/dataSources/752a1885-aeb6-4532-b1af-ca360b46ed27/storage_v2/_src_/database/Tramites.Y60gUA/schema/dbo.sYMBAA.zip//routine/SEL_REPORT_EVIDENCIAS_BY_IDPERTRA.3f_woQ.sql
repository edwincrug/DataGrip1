

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [SEL_REPORT_EVIDENCIAS_BY_IDPERTRA] 36,4
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORT_EVIDENCIAS_BY_IDPERTRA]
	@id INT
	,@estatus INT
AS
BEGIN
	SET NOCOUNT ON;
		DECLARE @url varchar(max)
		DECLARE @urlPro VARCHAR(500);
	select @url = pr_descripcion from parametros where pr_identificador = 'GET_SERVER'
	SET @urlPro = 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores';	
	
	

	--    SELECT
 --   numero = v.id
	--,v.idVale
 --  ,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fechaExpedicion
 --  ,pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO AS solicitante
 --  ,(v.montoSolicitado) AS cantidad
 --  ,(v.montoJustificado) AS comprobada
 --  ,(v.montoSolicitado - v.montoJustificado) AS porComprobar
 --  ,[url] = @url + SUBSTRING([URL], CHARINDEX('/Fondo',url),LEN(e.url))+'/'+e.archivo+'.pdf'
 --  ,[urlVale] = @url+ SUBSTRING([URL], CHARINDEX('/Fondo',url),LEN(e.url))+'/AutorizacionVale_'+cast(e.idvales as varchar(6))+'.pdf'
	--  FROM tramite.valesFondoFijo ff
	--JOIN tramite.vales v
	--ON ff.idVales = v.id
	--JOIN Tramite.valesEvidencia e
	--ON e.idVales = v.id
	----AND e.envioReembolso is NULL
	--LEFT JOIN tramites.[Tramite].[FacturaVale] fv
	--ON e.idfactura = fv.id
	--LEFT JOIN GA_Corporativa..PER_PERSONAS pp
	--ON fv.PER_IDPERSONA  = pp.PER_IDPERSONA
	--WHERE ff.idTablaFondoFijo = @id
	--AND v.estatusVale in (2,3,4)

	if(@estatus <> 7)
	BEGIN

		SELECT distinct
		numero = v.id
		,v.idVale
	   ,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fechaExpedicion
	   ,pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO AS solicitante
	   ,(v.montoSolicitado) AS cantidad
	   ,(v.montoJustificado) AS comprobada
	   ,(v.montoSolicitado - v.montoJustificado) AS porComprobar
	   --,[url] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id)  + '/' + e.archivo + '.' + e.extension 
		,case when e.idgastoFondoFijo  = 2 then @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id)  + '/' + e.archivo + '.' + e.extension 
		else @urlPro + (    	
			SELECT '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4),DATEPART(yyyy,fecha_factura))+  '_'+
				RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,fecha_factura)))),2) +
				'/' + rfc_emisor + 	'_' + case when serie <> '' then serie else '' end + 
				folio + '.pdf'
			FROM 
				Centralizacionv2..PPRO_DATOSFACTURAS 
			WHERE 
				folioorden = FV.ordenCompra) end as [url]
		--,[urlVale] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id) + '/AutorizacionVale_'+cast(e.idvales as varchar(6))+'.pdf'
		,[urlVale] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id) + '/AutorizacionVale_'+cast(v.id as varchar(6))+'.pdf'
		, case when isnull(v.enviaReembolso,0) = 1 then 'Solicitado' else '' end as reembolso
		FROM tramite.valesFondoFijo ff
		JOIN Tramite.fondoFijo f on f.id = ff.idtablafondofijo
		JOIN tramite.vales v ON ff.idVales = v.id
		LEFT JOIN Tramite.valesEvidencia e 
		ON e.idVales = v.id
		LEFT JOIN tramites.[Tramite].[FacturaVale] fv 
		ON e.idfactura = fv.id
		LEFT JOIN GA_Corporativa..PER_PERSONAS pp 
		ON v.PER_IDPERSONA  = pp.PER_IDPERSONA
		WHERE ff.idTablaFondoFijo = @id
		AND (v.estatusVale = @estatus or @estatus = 0)
		and e.idestatus <> 3
		--and pp.PER_NOMRAZON is not null

	END
	ELSE
	BEGIN

				SELECT distinct
		numero = v.id
		,v.idVale
	   ,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fechaExpedicion
	   ,pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO AS solicitante
	   ,(v.montoSolicitado) AS cantidad
	   ,(v.montoJustificado) AS comprobada
	   ,(v.montoSolicitado - v.montoJustificado) AS porComprobar
	   --,[url] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id)  + '/' + e.archivo + '.' + e.extension 
		,case when e.idgastoFondoFijo  = 2 then @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id)  + '/' + e.archivo + '.' + e.extension 
		else @urlPro + (    	
			SELECT '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4),DATEPART(yyyy,fecha_factura))+  '_'+
				RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,fecha_factura)))),2) +
				'/' + rfc_emisor + 	'_' + case when serie <> '' then serie else '' end + 
				folio + '.pdf'
			FROM 
				Centralizacionv2..PPRO_DATOSFACTURAS 
			WHERE 
				folioorden = FV.ordenCompra) end as [url]
		--,[urlVale] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id) + '/AutorizacionVale_'+cast(e.idvales as varchar(6))+'.pdf'
		,[urlVale] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id) + '/AutorizacionVale_'+cast(v.id as varchar(6))+'.pdf'
		, case when isnull(v.enviaReembolso,0) = 1 then 'Solicitado' else '' end as reembolso
		FROM tramite.valesFondoFijo ff
		JOIN Tramite.fondoFijo f on f.id = ff.idtablafondofijo
		JOIN tramite.vales v ON ff.idVales = v.id
		LEFT JOIN Tramite.valesEvidencia e 
		ON e.idVales = v.id
		and e.idestatus <> 3
		LEFT JOIN tramites.[Tramite].[FacturaVale] fv ON e.idfactura = fv.id
		LEFT JOIN GA_Corporativa..PER_PERSONAS pp ON v.PER_IDPERSONA  = pp.PER_IDPERSONA
		WHERE ff.idTablaFondoFijo = @id
		and v.enviaReembolso = 1

		--and pp.PER_NOMRAZON is not null
	END

	--SELECT
 --   numero = v.id
	--,v.idVale
 --  ,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fechaExpedicion
 --  ,pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO AS solicitante
 --  ,(v.montoSolicitado) AS cantidad
 --  ,(v.montoJustificado) AS comprobada
 --  ,(v.montoSolicitado - v.montoJustificado) AS porComprobar
 --  --,[url] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id)  + '/' + e.archivo + '.' + e.extension 
	--,case when e.idgastoFondoFijo  = 2 then @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id)  + '/' + e.archivo + '.' + e.extension 
	--else @urlPro + (    	
	--	SELECT '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4),DATEPART(yyyy,fecha_factura))+  '_'+
	--		RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,fecha_factura)))),2) +
	--		'/' + rfc_emisor + 	'_' + case when serie <> '' then serie else '' end + 
	--		folio + '.pdf'
	--	FROM 
	--		Centralizacionv2..PPRO_DATOSFACTURAS 
	--	WHERE 
	--		folioorden = FV.ordenCompra) end as [url]
	----,[urlVale] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id) + '/AutorizacionVale_'+cast(e.idvales as varchar(6))+'.pdf'
	--,[urlVale] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id) + '/AutorizacionVale_'+cast(v.id as varchar(6))+'.pdf'
	--FROM tramite.valesFondoFijo ff
	--JOIN Tramite.fondoFijo f on f.id = ff.idtablafondofijo
	--JOIN tramite.vales v ON ff.idVales = v.id
 --   LEFT JOIN Tramite.valesEvidencia e ON e.idVales = v.id
	--LEFT JOIN tramites.[Tramite].[FacturaVale] fv ON e.idfactura = fv.id
	--LEFT JOIN GA_Corporativa..PER_PERSONAS pp ON fv.PER_IDPERSONA  = pp.PER_IDPERSONA
	--WHERE ff.idTablaFondoFijo = @id
	--AND v.estatusVale in (2,3,4)

 --   SELECT
 --   numero = v.id
	--,v.idVale
 --  ,CONVERT(VARCHAR(10), v.fechaCreacionVale, 103) AS fechaExpedicion
 --  ,pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO AS solicitante
 --  ,(v.montoSolicitado) AS cantidad
 --  ,(v.montoJustificado) AS comprobada
 --  ,(v.montoSolicitado - v.montoJustificado) AS porComprobar
 --  ,[url] = 'http://localhost:1220'+ SUBSTRING([URL], CHARINDEX('/Image',url),LEN(e.url))+'.pdf'
 -- FROM Tramites.Tramite.vales v
 -- JOIN GA_Corporativa..PER_PERSONAS pp
 --   ON v.PER_IDPERSONA = pp.PER_IDPERSONA
 -- JOIN Tramites.tramite.valesEvidencia e
 --   ON v.id = e.idVales 
 --   AND v.montoSolicitado = e.monto
 -- WHERE v.id IN (SELECT
 --     ff.idVales
 --   FROM Tramites.Tramite.valesFondoFijo ff
 --   WHERE ff.idTablaFondoFijo = @id)
 -- AND v.estatusVale IN (3)
END



go

