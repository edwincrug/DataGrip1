-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 14/11/2019
-- Description:	SP que aprueba el tramite
-- TEST [dbo].[UPD_FONDO_REEMBOLSO_TRAMITE_SP]
-- =============================================
CREATE PROCEDURE [dbo].[UPD_FONDO_REEMBOLSO_TRAMITE_SP]
	@id_perTra INT,
	@bancoSalida INT,
	@bancoEntrada INT,
	@tipo INT,
	@estatus INT,
	@numCuentaSalida varchar(100) = NULL, 
	@cuentaContableSalida varchar(100) = NULL, 
	@numCuentaEntrada varchar(100) = NULL,
	@cuentaContableEntrada varchar(100) = NULL,
	@idTramiteTesoreria INT = 0
	
AS
BEGIN
	
	--UPDATE tramiteDevoluciones
	--SET traDe_fechaAutoriza = GETDATE(), esDe_IdEstatus = @estatus
	--WHERE id_perTra = @id_perTra;
	
	DECLARE @idSiguiente INT = 6, @correo varchar (max), @idReembolso INT
    
    SELECT @correo =  STUFF((
	SELECT ';' + usu_correo
	from Tramite.UsuariosFondoFijo UF
    inner join Tramite.cat_usuariosFondoFijo cuf on uf.idUsuariosFondofijo = cuf.id
    inner join controlAplicaciones.dbo.cat_usuarios u on UF.idusuario = u.usu_idusuario
    where UF.idUsuariosFondofijo = @idSiguiente
    FOR XML PATH('')
	),1,1,'')
	
	IF (@estatus = 3)
	BEGIN
	--UPDATE Tramite.fondoFijo
	--SET idReembolso = @tipo, estatusFondoFijo = @estatus
	--WHERE id_perTra = @id_perTra;

	IF(@bancoSalida  > 0 or @bancoEntrada > 0)
	BEGIN
	DECLARE @idfondo INT
	SELECT @idfondo = id FROM Tramite.fondoFijo WHERE id_perTra = @id_perTra;

	INSERT INTO [Tramite].[fondoFijoReembolso] 
		   (idFondoFijo, 
		   idBancoSalida, 
		   idBancoEntrada,
		   numCuentaSalida,
		   cuentaContableSalida,
		   numCuentaEntrada,
		   cuentaContableEntrada,
		   idTramiteTesoreria,
		   estatus,
		   idSalidaReembolso)
	VALUES
		   (@idfondo,
		   @bancoSalida,
		   @bancoEntrada,
		   @numCuentaSalida,
		   @cuentaContableSalida,
		   @numCuentaEntrada,
		   @cuentaContableEntrada,
		   @idTramiteTesoreria,
		   1,
		   @tipo)
	END

	SET @idReembolso = SCOPE_IDENTITY()

	update Tramite.fondoFijo set idReembolso = @idReembolso where id_perTra = @id_perTra
	--update tramiteDevoluciones
	--set esDe_IdEstatus = 4
	--where id_perTra = @id_perTra
	--UPDATE ve
	--SET ve.estatusReembolso = 1
	--from tramite.fondofijo ff
	--inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	--inner join tramite.vales v on v.id = vff.idvales
	--inner join tramite.valesEvidencia ve on ve.idVales = v.id 
	--where ff.id_perTra = @id_perTra and ve.envioReembolso = 1 and ve.estatusReembolso is null 
	
	--IF(@tipo = 1)
	--BEGIN
	--DECLARE @consecutivo INT = 0, @monto DECIMAL (18,2)
	--select @consecutivo = count(id_cuenta) from cuentasTesoreriaFA where id_perTra = @id_perTra and tipo = 2
	--SET @consecutivo = @consecutivo +1;
	
	--select 
	--@monto = SUM(ve.montoPoliza)
	--from tramite.fondofijo ff
	--inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	--inner join tramite.vales v on v.id = vff.idvales
	--inner join tramite.valesEvidencia ve on ve.idVales = v.id 
	--where ff.id_perTra = @id_perTra and ve.envioReembolso = 1 and ve.estatusReembolso = 1
	
	--insert into cuentasTesoreriaFA (id_perTra, fechaInsercion, estatus,id_tipoTramite, tipo, consecutivo, monto)
	--values (@id_perTra, GETDATE(),1, 1, 2, @consecutivo, @monto)

	--END
	
	SELECT @correo =  STUFF((
	SELECT ';' + usu_correo
	from Tramite.UsuariosFondoFijo UF
    inner join Tramite.cat_usuariosFondoFijo cuf on uf.idUsuariosFondofijo = cuf.id
    inner join controlAplicaciones.dbo.cat_usuarios u on UF.idusuario = u.usu_idusuario
    where UF.idUsuariosFondofijo = @idSiguiente
    FOR XML PATH('')
	),1,1,'')
	
	
	
	SELECT 1 as success,@idReembolso as idReembolso, @correo as correo, @idSiguiente as tipoUsuario, 'Solicitud de Revisión Reembolso de Fondo Fijo' as asunto;

	END
	ELSE
	BEGIN
	UPDATE Tramite.fondoFijo
	SET estatusFondoFijo = @estatus
	WHERE id_perTra = @id_perTra;

	SELECT success = 1;
	END

END


go

