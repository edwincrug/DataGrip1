
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <10/02/2020>
-- Description:	<Obtiene las evidencias vales por concepto>
--TEST EXEC [Tramite].[Sp_Tramite_ValeEvidenciaDepartamento_GETLByIdEvidencia] 77
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ValeEvidenciaDepartamento_GETLByIdEvidencia] 
	@idValeEvidencia INT
AS
BEGIN 

	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	SELECT 
		idValeEvidenciaDepartamento
		,idDepartamento
		,porcentaje
		,fechaCreacion
		,idValeEvidencia
		,COALESCE(CD.dep_nombre, '') AS [departamento]
	FROM [Tramite].[ValeEvidenciaDepartamento] AD
	LEFT JOIN ControlAplicaciones.dbo.cat_departamentos CD ON CD.dep_iddepartamento = [AD].[idDepartamento]
	WHERE idValeEvidencia = @idValeEvidencia

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

