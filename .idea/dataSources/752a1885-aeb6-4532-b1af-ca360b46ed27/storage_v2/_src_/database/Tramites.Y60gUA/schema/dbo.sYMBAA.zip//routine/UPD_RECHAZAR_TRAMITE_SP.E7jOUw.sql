-- =============================================
-- Author:		Luis Garcia
-- Create date: 17/06/2019
-- Description:	SP que aprueba el tramite
-- =============================================
CREATE PROCEDURE [dbo].[UPD_RECHAZAR_TRAMITE_SP]
	 @id_perTra INT
	,@idUsuario INT = NULL
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY
	UPDATE personaTramite
	SET petr_estatus = 3
	,esDe_IdEstatus = 2
	WHERE id_perTra = @id_perTra

	INSERT INTO dbo.BitacoraTramite
	SELECT @idUsuario,@id_perTra,'Se rechaza trámite', GETDATE(), null

	SELECT success = 1, msg = 'Se rechazo el tramite con éxito'
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	SELECT success = -1, msg = 'Ocurrio un error al realizar el rechazo'
END CATCH

END
go

