-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <03/06/2019>
-- Description:	<Trae el nombre del usuario y el rol>
--TEST: SEL_USUNOMBRE_ROL_SP 71, 2
-- =============================================
CREATE PROCEDURE [dbo].[SEL_USUNOMBRE_ROL_SP]
	@idUsuario INT,
	@entra INT = 0
AS
BEGIN
	DECLARE @idRol INT;
	SELECT 
		@idRol = idRol 
	FROM usuarioRol WHERE idUsuario = @idusuario

	IF EXISTS( SELECT idUsuario FROM loginOrigen WHERE idUsuario = @idUsuario AND idRol = @idRol AND idOrigen = @entra )
		BEGIN
			SELECT 
				USR.idRol,
				USR.id_area,
				CUS.usu_idusuario,
				CUS.usu_nombreusu,
				CUS.usu_paterno + ' ' + CUS.usu_materno + ' ' + CUS.usu_nombre AS nombre,
				LO.pathUrl
			FROM [ControlAplicaciones].[dbo].[cat_usuarios] CUS
			INNER JOIN usuarioRol USR ON USR.idUsuario = CUS.usu_idusuario
			INNER JOIN loginOrigen LO ON LO.idUsuario = USR.idUsuario
			WHERE CUS.usu_idusuario = @idUsuario AND LO.idRol = @idRol AND LO.idOrigen = @entra;
		END
	ELSE
		BEGIN
			SELECT 
				USR.idRol,
				USR.id_area,
				CUS.usu_idusuario,
				CUS.usu_nombreusu,
				CUS.usu_paterno + ' ' + CUS.usu_materno + ' ' + CUS.usu_nombre AS nombre,
				USR.pathUrl
			FROM [ControlAplicaciones].[dbo].[cat_usuarios] CUS
			INNER JOIN usuarioRol USR ON USR.idUsuario = CUS.usu_idusuario
			WHERE CUS.usu_idusuario = @idUsuario;
		END

END
go

