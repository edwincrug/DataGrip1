-- =============================================
-- Author:		Luis Garcia
-- Create date: 18/06/2019
-- Description:	Trae los datos del tramite a aprobar
-- TEST UPD_DEV_ESTATUS_AUTORIZAR_TRAMITE_SP 6
-- =============================================
CREATE PROCEDURE [dbo].[UPD_DEV_ESTATUS_AUTORIZAR_TRAMITE_SP]
	@idPerTra INT,
	@bancoActual INT,
	@cuentaActual VARCHAR(50),
	@idUsuario INT = NULL
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY

	DECLARE @idTraDe INT;

	SELECT 
		@idTraDe = id_traDe 
	FROM tramiteDevoluciones WHERE id_perTra = @idPerTra;

	UPDATE tramiteDevoluciones
	SET esDe_IdEstatus = 3, efectivoCuenta = @cuentaActual, efectivoBanco = @bancoActual
	WHERE id_traDe = @idTraDe;
	
	IF( @idUsuario IS NOT NULL )
		BEGIN
			INSERT INTO BitacoraTramite
			SELECT @idUsuario, @idPerTra, 'Se autorizo el trámite', GETDATE(), 3;
		END

	SELECT success = 1;

COMMIT TRANSACTION
END TRY

BEGIN CATCH
ROLLBACK TRANSACTION
	SELECT success = 0;
END CATCH
END
go

