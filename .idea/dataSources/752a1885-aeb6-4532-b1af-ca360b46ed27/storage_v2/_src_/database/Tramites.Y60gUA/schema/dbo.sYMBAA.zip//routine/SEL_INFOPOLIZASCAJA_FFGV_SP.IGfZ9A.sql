
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <13/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [dbo].[SEL_INFOPOLIZASCAJA_FFGV_SP]  1280
-- =============================================
CREATE PROCEDURE [dbo].[SEL_INFOPOLIZASCAJA_FFGV_SP] 
	@id_perTra INT 
AS
BEGIN

IF EXISTS (select top 1 1 from Tramite.fondoFijoSalidaEfectivo where idTramiteTesoreria = @id_perTra)
BEGIN
--Salida Efectivo
select 
ff.idResponsable as idUsuario, 
ff.idSucursal, 
ff.idFondoFijo, 
tff.tsb_importe as monto,
ff.id_perTra as id_perTraFF,
ffse.cuentaContableEntrada, 
ffse.cuentaContableSalida, 
ff.cuentaContable,
d.dep_nombrecto,
0 as esReembolso,
'FF' as tramite,
u.usu_correo as correo
from traspasosFondoFijoLog  tffl
inner join tsb_traspasosaldobancosFondoFijo tff on tff.tsb_idtraspasosaldobancos = tffl.idtransferencia
inner join Tramite.fondoFijoSalidaEfectivo ffse on ffse.idTramiteTesoreria =  tffl.idPerTra
inner join Tramite.FondoFijo ff on ff.id = ffse.idFondoFijo
inner join controlaplicaciones.dbo.cat_departamentos d on d.dep_iddepartamento = ff.iddepartamento
inner join controlaplicaciones.dbo.cat_usuarios u on u.usu_idusuario = ff.idResponsable
where tffl.idPerTra = @id_perTra
END
ELSE
BEGIN
--Reembolso
select 
ff.idResponsable as idUsuario, 
ff.idSucursal, 
ff.idFondoFijo, 
tff.tsb_importe as monto,
ff.id_perTra as id_perTraFF,
ffre.cuentaContableEntrada, 
ffre.cuentaContableSalida, 
ff.cuentaContable,
d.dep_nombrecto,
1 as esReembolso,
'FF' as tramite,
u.usu_correo as correo,
ISNULL(ffre.id_perTraReembolso,ff.id_perTra) as id_perTraReembolso
from traspasosFondoFijoLog  tffl
inner join tsb_traspasosaldobancosFondoFijo tff on tff.tsb_idtraspasosaldobancos = tffl.idtransferencia
inner join Tramite.fondoFijoReembolso ffre on ffre.idTramiteTesoreria =  tffl.idPerTra
inner join Tramite.FondoFijo ff on ff.id = ffre.idFondoFijo
inner join controlaplicaciones.dbo.cat_departamentos d on d.dep_iddepartamento = ff.iddepartamento
inner join controlaplicaciones.dbo.cat_usuarios u on u.usu_idusuario = ff.idResponsable
where tffl.idPerTra = @id_perTra
END


END



go

