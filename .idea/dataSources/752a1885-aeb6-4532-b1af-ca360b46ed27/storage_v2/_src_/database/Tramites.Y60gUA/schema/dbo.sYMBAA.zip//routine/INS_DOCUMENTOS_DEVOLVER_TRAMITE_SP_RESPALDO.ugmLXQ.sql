-- =============================================
-- Author:		Luis García
-- Create date: 23/07/2019
-- Description:	Inserta y/o actualiza los documentos que se deberan devolver el pago
-- =============================================
CREATE PROCEDURE [dbo].[INS_DOCUMENTOS_DEVOLVER_TRAMITE_SP_RESPALDO]
	@input VARCHAR(MAX),
	@idPerTra INT
AS
BEGIN
	--Declaramos las variables a usar
	DECLARE @idTraDe INT = 0,
	@maxCount INT = 0,
	@minCount INT = 0,
	@documento VARCHAR(500);

	DECLARE @dataInsertTemp TABLE (rowTable INT, idTraDe INT, documento VARCHAR(500), valorDev NUMERIC(18,2), estatusDoc BIT );

	--Obtenemos el id del tramite devolucion con el id persona tramite
	SELECT 
		@idTraDe = id_traDe 
	FROM tramiteDevoluciones WHERE id_perTra = @idPerTra;

	--Validamos que responde la funcion
	IF NOT EXISTS (SELECT idTramite FROM SplitDocumentos(@input) WHERE idTramite = 'Sin datos' )
		BEGIN

			--Obtenemos el maximo y minimo de rows que regresa la funcion
			SELECT 
				@maxCount = MAX(x.contador),
				@minCount = MIN(x.contador)
			FROM (	SELECT 
						ROW_NUMBER() OVER(ORDER BY @idTraDe ASC) AS contador
					FROM SplitDocumentos(@input)) x

			--Insertamos en la tabla temporal los datos y los rows obtenidos
			INSERT INTO @dataInsertTemp
			SELECT 
				ROW_NUMBER() OVER(ORDER BY @idTraDe ASC),
				@idTraDe,
				documento,
				valor,
				seleccionado
			FROM SPLIT_DOCS_3_COMAS(@input)

			-- Eliminamos todos los documentos de ese idTrade
			DELETE FROM documentosDevueltos WHERE id_traDe = @idTraDe;

			--Inicia el bucle para saber cuales insertar y cuales prender
			WHILE(@minCount <= @maxCount)
				BEGIN
					--Insertamos los documentos
					INSERT INTO documentosDevueltos
					SELECT 
						idTraDe,
						documento,
						valorDev,
						estatusDoc, 
						0
					FROM @dataInsertTemp
					WHERE rowTable = @minCount
						
					--Aumentamos el contador para el siguiente row
					SET @minCount = @minCount + 1;
				END
			--Regresamos una respuesta al frontEnd
			SELECT success = 1, msg = 'Se termino de insertar'
		END
	ELSE
		BEGIN
			-- Eliminamos todos los documentos de ese idTrade
			DELETE FROM documentosDevueltos WHERE id_traDe = @idTraDe;

			--Regresamos una respuesta al frontEnd
			SELECT success = 0, msg = 'No se guarda ningun documento'
		END
	END
go

