-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VALIDA_CUENTABANCARIA_SP]
	 @ctaBancaria    VARCHAR(25)
	 ,@convenio       VARCHAR(10)
AS
BEGIN
	EXEC [Centralizacionv2].[dbo].[PROV_SEL_VALIDA_CUENTA_BANCARIA_SP] @ctaBancaria , @convenio
END
go

