
-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [SEL_LISTATRAMITESCONTRALORIA]
-- =============================================
CREATE PROCEDURE [dbo].[SEL_LISTATRAMITESCONTRALORIA]
@idUsuario int = 2264
AS
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON;

  WITH reporte
  AS
  (SELECT
      id = f.id
     ,idFondoFijo = f.idFondoFijo
     ,CONVERT(VARCHAR(10), f.fechaCreacion, 103) AS fecha
     ,CONVERT(VARCHAR(8), f.fechaCreacion, 108) AS hora
     ,agencia = dcer.RazonSocial
     ,sucursal = cs.suc_nombre
     ,departamento = cd.dep_nombre
     ,responsable = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
     ,monto = td.traDe_devTotal
	 ,f.idEmpresa
   ,f.idSucursal
   ,f.idDepartamento
   ,idResponsable = cu.usu_idusuario
    FROM Tramites.Tramite.fondoFijo f
    JOIN ControlAplicaciones.dbo.cat_departamentos cd
      ON f.idDepartamento = cd.dep_iddepartamento
    JOIN ControlAplicaciones.dbo.cat_sucursales cs
      ON cd.suc_idsucursal = cs.suc_idsucursal
    JOIN ControlAplicaciones..cat_usuarios cu
      ON f.idResponsable = cu.usu_idusuario
    JOIN Centralizacionv2.dbo.DIG_CAT_EMPRESA_RAZON dcer
      ON dcer.IdEmpresa = f.idEmpresa
    JOIN Tramites..tramiteDevoluciones td
      ON f.id_perTra = td.id_perTra
    JOIN personaTramite p
      ON td.id_perTra = p.id_perTra
      AND p.petr_estatus <> 3),
  arqueo
  AS
  (SELECT
      a.id
     ,fecha_ultimo_arqueo = CONVERT(VARCHAR(10), a.fecha, 103) --+ '-' + CONVERT(VARCHAR(10), a.fecha, 108)
     ,MontoSaldoCaja = ISNULL(a.MontoSaldoCaja, 0)
     ,usuario_captura = ISNULL(cua.usu_nombre + ' ' + cua.usu_paterno + ' ' + cua.usu_materno, '')
     ,a.idFondoFijo
    FROM Tramites.dbo.arqueo a
    JOIN ControlAplicaciones..cat_usuarios cua
      ON a.idUsuario = cua.usu_idusuario
    WHERE id IN (SELECT
        MAX(id)
      FROM Tramites.dbo.arqueo
      GROUP BY idfondofijo))
  SELECT
    r.id
   ,r.idFondoFijo
   ,r.fecha
   ,r.hora
   ,r.agencia
   ,r.sucursal
   ,r.departamento
   ,r.responsable
   ,r.monto
   ,usuario_captura = ISNULL(a.usuario_captura, '')
   ,MontoSaldoCaja = ISNULL(a.MontoSaldoCaja, '')
   ,fecha_ultimo_arqueo = ISNULL(a.fecha_ultimo_arqueo, '')
    ,r.idEmpresa
 ,r.idSucursal
 ,r.idDepartamento
 ,r.idResponsable
  FROM reporte r
  LEFT JOIN arqueo a
    ON r.id = a.idFondoFijo



--   SELECT
-- id = f.id
-- ,idFondoFijo = f.idFondoFijo
-- ,CONVERT(VARCHAR(10),f.fechaCreacion,103) AS fecha  
-- , CONVERT(VARCHAR(8), f.fechaCreacion, 108) AS hora
-- ,agencia = dcer.RazonSocial
-- ,sucursal = cs.suc_nombre
-- ,departamento = cd.dep_nombre
-- ,responsable = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
-- ,monto =td.traDe_devTotal
--FROM Tramites.Tramite.fondoFijo f
--JOIN ControlAplicaciones.dbo.cat_departamentos cd
--  ON f.idDepartamento = cd.dep_iddepartamento
--JOIN ControlAplicaciones.dbo.cat_sucursales cs
--  ON cd.suc_idsucursal = cs.suc_idsucursal
--JOIN ControlAplicaciones..cat_usuarios cu
--  ON f.idResponsable = cu.usu_idusuario
--JOIN Centralizacionv2.dbo.DIG_CAT_EMPRESA_RAZON dcer
--  on dcer.IdEmpresa = f.idEmpresa
--JOIN Tramites..tramiteDevoluciones td
--  ON f.id_perTra = td.id_perTra

END
go

