-- =============================================
-- Author:		Luis Garcia
-- Create date: 14/08/2019
-- Description:	SP que trae el parametro de dinero para saber a quien mandarle la notificacion
-- =============================================
CREATE PROCEDURE SEL_PARAM_AMOUNT_NOTIFICACION_SP 
AS
BEGIN
	SELECT 
		pr_descripcion 
	FROM parametros WHERE pr_identificador = 'PARAM_AMOUNT'
END
go

