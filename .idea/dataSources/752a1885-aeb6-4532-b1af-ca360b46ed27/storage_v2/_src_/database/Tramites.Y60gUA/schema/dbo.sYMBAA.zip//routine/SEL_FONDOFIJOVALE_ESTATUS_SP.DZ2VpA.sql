
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <29/10/2019>
-- Description:	<SP que trae los datos estatus del tramite de Fondo Fijo>
-- TEST SEL_FONDOFIJOVALE_ESTATUS_SP 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJOVALE_ESTATUS_SP] 
@tipo INT
AS
BEGIN

	IF(@tipo =  1)
	BEGIN
	SELECT 
		esDe_IdEstatus AS idEstatus,
		esDe_descripcion AS descripcion,
		esDe_icono AS icono 
	FROM cat_proceso_estatus
	WHERE idTipoTramite = 10
	ORDER BY esDe_IdEstatus asc
	END
	
	IF(@tipo =  2)
	BEGIN
	SELECT 
		id as idEstatus, 
		descripcion, 
		icono 
	FROM Tramite.cat_estatusVale
	ORDER BY id ASC
	END

END
go

