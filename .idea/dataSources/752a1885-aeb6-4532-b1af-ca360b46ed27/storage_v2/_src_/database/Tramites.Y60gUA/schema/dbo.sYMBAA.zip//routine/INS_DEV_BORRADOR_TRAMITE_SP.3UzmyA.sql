-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <09/07/2019>
-- Description:	<Inserta el tramite de devoluciones en borrador>
-- =============================================
CREATE PROCEDURE [dbo].[INS_DEV_BORRADOR_TRAMITE_SP]
	@idUsuario INT,
	@idTramite INT,
	@idFormaPago INT,
	@idDepartamento INT,
	@observaciones VARCHAR(MAX),
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN
	DECLARE @idPerTra INT;

	INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus])
     VALUES
           (@idUsuario
           ,@idTramite
           ,GETDATE()
           ,5)

	SET @idPerTra = SCOPE_IDENTITY()

	INSERT INTO [dbo].[tramiteDevoluciones]
           ([id_perTra]
           ,[id_formaPago]
           ,[id_departamento]
           ,[traDe_Observaciones]
           ,[id_empresa]
           ,[id_sucursal])
     VALUES
           (@idPerTra
           ,@idFormaPago
           ,@idDepartamento
           ,@observaciones
           ,@idEmpresa
           ,@idSucursal)

		SELECT success = 1, msg = 'Se inserto correctamente el tramite', idPerTra = @idPerTra, 
		saveUrl = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC');
END
go

