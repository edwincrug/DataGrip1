

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <17/10/2019>
-- Description:	<SP que trae los datos de los FF x usuario>
-- SEL_TIPOUSUARIOFONDOFIJO_SP 4999,1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOUSUARIOFONDOFIJO_SP] 
	@idUsuario INT,
	@tipo INT
AS
BEGIN
	  
	SELECT
	idUsuario,
	idUsuariosFondoFijo as tipoUsuarioFF
	FROM [Tramite].[UsuariosFondoFijo]
	WHERE idUsuario = @idUsuario and idUsuariosFondoFijo = @tipo

END
go

