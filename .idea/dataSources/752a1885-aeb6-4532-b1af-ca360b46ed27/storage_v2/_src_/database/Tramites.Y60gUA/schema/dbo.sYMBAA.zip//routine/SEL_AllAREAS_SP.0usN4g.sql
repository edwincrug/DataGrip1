-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/06/2019>
-- Description:	<Trae todas las areas>
-- =============================================
CREATE PROCEDURE SEL_AllAREAS_SP
AS
BEGIN
	SELECT 
		id_area,
		are_nombreArea 
	FROM cat_areas
END
go

