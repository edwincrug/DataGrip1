-- =============================================
-- Author:		ROBERTO ALMANZA NIETO
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ValidaToken]
	-- Add the parameters for the stored procedure here
	 @token varchar(6)
	,@idPersona int 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare 
	@fechaFirma datetime = getdate()
	,@idUsuario int
	,@fechaVencimiento datetime
	,@usado int
	,@idtoken int

	select @idUsuario = idUsuario
	from usuariosGastosViaje
	where idUsuario = @idPersona

	/*
	buscamos que el usuario que captura el token, sea el mismo que lo solicito
	*/
	if EXISTS(select 1 from token where idUsuarioSolicitante = @idUsuario and token = @token)
	begin

		/*Obtenermos la fecha de vencimiento del token encontrado y el estatus de uso*/
		select @fechaVencimiento = fechavencimiento
		,@usado = estatus
		,@idtoken = id
		from token 
		where idUsuarioSolicitante = @idUsuario 
		and token = @token

		/*
		verificacmos que no haya vencido el token
		*/
		if(@fechaVencimiento > @fechaFirma)
		begin 
		
			/*
				verificamos si el token ya fue utilizado
			*/
			if(@usado = 0)
			begin
				update t
				set estatus = 1
				, fechaUso = @fechaFirma
				from token t
				where idUsuarioSolicitante = @idUsuario
				and token = @token

				select 1 as estatus, 'token valido' as mensaje, @token as token, @fechaFirma as fechaFirma, @idtoken as idToken, @idUsuario as idUsuario
			end
			else
			begin
				select 0 as estatus, 'El token ingresado ya fue utilizado previamente, es necesario solicitar un nuevo token' as mensaje
			end

		end
		else
		begin

			Select 0 as estatus, 'El token ingresado ha vencido' as mensaje

		end

	end
	/*En caso de que no exista la relacion usuario - token se manda mensaje de erro*/
	else
	begin
	

		select 0 as estatus
		, 'Verifique el token, no se encontro relación' as mensaje

	end
END
go

