
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <16/06/2020>
-- Description:	<SP que muestra los reembolsos>
-- SEL_REEMBOLSOSFONDOFIJO_SP 1264
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REEMBOLSOSFONDOFIJO_SP] 
	@id_perTra INT
AS
BEGIN

--Reembolso OP
select 
u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as cajero
,ff.idfondofijo as documento
,0 as importeOriginal
,ct.monto as importeReembolsado
,CONVERT(varchar, ct.fechaInsercion, 103) as fecha
,'' rutaDoc
from tramite.fondofijo ff
inner join Tramite.fondoFijoReembolso ffr on ffr.idFondoFijo = ff.id
inner join cuentasTesoreriaFA ct on ct.consecutivo = ffr.id
inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = ff.idResponsable
where ff.id_perTra = @id_perTra
UNION
--Reembolso CAJA
select 
u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as cajero
,ff.idfondofijo as documento
,0 as importeOriginal
,tsb.tsb_importe as importeReembolsado
,CONVERT(varchar, tffl.fechaAtencion, 103) as fecha
,'' rutaDoc
from tramite.fondofijo ff
inner join Tramite.fondoFijoReembolso ffr on ffr.idFondoFijo = ff.id
inner join traspasosFondoFijoLog tffl on  tffl.idPerTra = ffr.idTramiteTesoreria
inner join tsb_traspasosaldobancosFondoFijo tsb on tsb.tsb_idtraspasosaldobancos = tffl.idtransferencia
inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = ff.idResponsable
where ff.id_perTra = @id_perTra

END
go

