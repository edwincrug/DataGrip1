
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <24/01/2020>
-- Description:	<SP que verifica los vales>
-- [dbo].[SEL_VERIFICARVALES_SP] 37
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VERIFICARCONCEPTO_SP] 
	@idTramiteConcepto INT
AS
BEGIN


select 
ti.importe as montoSolicitado,
sum(ca.total) as montoJustificado,
case when  sum(ca.total) = ti.importe  then  1 
when sum(ca.total) > ti.importe  then 1
else 0  end as justifico,
case when sum(ca.total) > ti.importe then  sum(ca.total) - ti.importe else 0  end as justificoMas
from  Tramite.TramiteConcepto  tc 
inner join Tramite.TramiteImporte ti on ti.idTramiteConcepto =  tc.idTramiteConcepto and ti.idTipoProceso = 2
inner join  [Tramite].[ConceptoArchivo] ca on ca.idReferencia = tc.idTramiteConcepto
where tc.idTramiteConcepto = @idTramiteConcepto and ca.idEstatus = 9
group by ti.importe


END
go

