-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [Tramite].[Fn_Tramite_GDM_NotiEnviadas]
(
	@IdSolicitud INT 
)
RETURNS int
AS
BEGIN
	---------------------------------------------------------------------
	-----				Variable para calculos						-----
	---------------------------------------------------------------------
	DECLARE @Solicitado NUMERIC(18,2),
			@Comprobado NUMERIC(18,2),
			@GastoDeMas NUMERIC(18,2),
			@Diferencia NUMERIC(18,2),
			@FaltaNotificacio BIT = 0;

	DECLARE @Conceptos TABLE(
			Indice INT,
			Id INT,
			ImporteSolicitado NUMERIC(18,2)
	)

	DECLARE @Comprobaciones TABLE(
			idReferencia INT,
			Total NUMERIC(18,2),
			montoDeMas NUMERIC(18,2)
	)

	---------------------------------------------------------------------
	-----	  Se obtienen los conceptos y montos solicitados 		-----
	---------------------------------------------------------------------
	INSERT INTO @Conceptos
	SELECT 
		ROW_NUMBER() OVER(ORDER BY TED.idTramiteConcepto) Indice
		,TED.idTramiteConcepto AS [id]
		,COALESCE((SELECT SUM(importe) FROM [Tramite].[TramiteImporte] WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 2)	
		,(SELECT SUM(importe) FROM [Tramite].[TramiteImporte] WHERE TED.idTramiteConcepto = idTramiteConcepto AND idTipoProceso = 1), 0) AS [importeSolicitado]
	FROM tramiteDevoluciones td
		join [Tramite].[TramiteConcepto] TED
			on td.id_perTra = ted.idTramitePersona
		INNER JOIN [Tramite].[ConceptoContable] CC 
			ON TED.idConceptoContable = CC.idConceptoContable
			and td.id_empresa = cc.idEmpresa
			and td.id_sucursal = cc.idSucursal
	INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
	WHERE TED.idTramitePersona = @IdSolicitud AND TED.idEstatus IN (0,2, 7, 8, 9)
	ORDER BY TED.idTramiteConcepto


	---------------------------------------------------------------------
	-----			  Se obtienen las comprobaciones 				-----
	---------------------------------------------------------------------
	INSERT INTO @Comprobaciones
	SELECT 
		CA.idReferencia, CA.total, CA.montoDeMas
	FROM tramiteDevoluciones td
	join [Tramite].[TramiteConcepto] TC
		on td.id_perTra = TC.idTramitePersona
	JOIN Tramite.ConceptoContable CC 
		ON TC.idConceptoContable = CC.idConceptoContable
		and td.id_empresa = cc.idEmpresa
		and td.id_sucursal = cc.idSucursal
	JOIN Tramite.ConceptoArchivo CA 
	ON TC.idTramiteConcepto = CA.idReferencia
	
	-- No es necesario incluir TramiteImporte en esta validación --JOIN [Tramite].[TramiteImporte] TI ON TI.idTramiteConcepto = TC.idTramiteConcepto AND TI.idConceptoArchivo = CA.idConceptoArchivo
	WHERE 
		TC.idTramitePersona = @IdSolicitud
		AND CA.idEstatus != 10; -- Se descartan los cancelados


	---------------------------------------------------------------------
	-----	Comienza el ciclo para validar sus comprobaciones		-----
	---------------------------------------------------------------------
	DECLARE @CurConcepto INT,
			@MaxConcepto INT;



	SELECT @CurConcepto = MIN(Indice), @MaxConcepto = MAX(Indice) FROM @Conceptos;

	WHILE( @CurConcepto <= @MaxConcepto )
		BEGIN
			SELECT @Solicitado = SUM(importeSolicitado)  FROM @Conceptos WHERE Indice = @CurConcepto
			SELECT @Comprobado = SUM(total), @GastoDeMas = ISNULL( SUM(montoDeMas), 0 ) FROM @Comprobaciones WHERE idReferencia = ( SELECT id FROM @Conceptos WHERE Indice = @CurConcepto )

		

			IF( @Comprobado > @Solicitado )
				BEGIN
					--SELECT 'HAY UN GASTO DE MAS'
					IF( (@Solicitado + @GastoDeMas) != @Comprobado )
						BEGIN
							--SELECT 'Y ADEMAS NO SE HA NOTIFICADO'
							SET @FaltaNotificacio = 1;
						END
				END
			SET @CurConcepto = @CurConcepto + 1
		END

	-- Return the result of the function
	RETURN @FaltaNotificacio

END
go

