

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <30/03/2020>
-- Description:	<SP que trae las ordens de compra de diferentes concetradoras>
-- [dbo].[SEL_CONCEPTOS_ORDENESCOMPRA_V1_SP]  
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CONCEPTOS_ORDENESCOMPRA_V1_SP] 
	
AS
BEGIN
		DECLARE @CountBases INT = 1, 
				@registos INT = 0, 
				@base varchar (200),
				@idComprobacionVale varchar(100),
				@SQLAgencia NVARCHAR(MAX)
		DECLARE @db TABLE(id int identity(1,1),idempresa INT,idsucursal INT, idcomprobacion INT, base varchar(200), idComprobacionConcepto varchar(100), idusuario INT, idConcepto varchar(100), monto decimal(10,2), canal varchar(10), compNoAutorizado INT);
		--DECLARE @Conceptos TABLE(idvale varchar(100), montoSolicitado decimal(10,2), montoJustificado decimal(10,2), justificado INT, JustificoMas decimal(10,2));

INSERT INTO @db
select td.id_empresa, td.id_sucursal, ca.idConceptoArchivo idcomprobacion, e.emp_nombrebd, ca.idComprobacionConcepto, pt.id_persona as respondable , tc.idTramiteConcepto, ca.total , dep.dep_nombrecto, ISNULL(ca.compNoAutorizado,0) as compNoAutorizado
from Tramite.ConceptoArchivo ca
inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
inner join tramiteDevoluciones td on td.id_perTra = tc.idTramitepersona
inner join personaTramite pt on pt.id_perTra =  td.id_perTra
inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = td.id_empresa
inner join ControlAplicaciones.dbo.cat_departamentos dep ON dep.dep_iddepartamento = td.id_departamento
where ca.procesoPoliza is null and ca.idEstatus = 9 --and ca.idEstatus = 9

SET @registos = (select COUNT(1) from @db)
			WHILE(@CountBases<= @registos)
					BEGIN
						SELECT 
						@base = base,
						@idComprobacionVale = idComprobacionConcepto
						FROM @db 
						WHERE id = @CountBases
					
						SET @SQLAgencia = 'select omd.omd_producto, odm_ordencompra 
						from ['+@base+'].dbo.cxp_ordenesmasivas om
						inner join ['+@base+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@idComprobacionVale+''''	

						print 	@SQLAgencia
						DECLARE @pedidos TABLE (idComprobacionVale varchar(100), ordencompra varchar(100));

						INSERT INTO @pedidos
						EXECUTE(@SQLAgencia)

						SET @CountBases= @CountBases+1     
					END
--INSERT INTO @vales
--select 
--v.idVale,
--v.montoSolicitado, 
--sum(ve.monto) as montoJustificado, 
--case when  sum(ve.monto) = v.montoSolicitado then  1 
--when sum(ve.monto) > v.montoSolicitado then 1
--else 0  end as justificado,
--case when sum(ve.monto) > v.montoSolicitado then  sum(ve.monto) - v.montoSolicitado else 0  end as justificoMas
----,v.estatusVale
--from Tramite.valesEvidencia ve 
--inner join Tramite.vales v on v.id = ve.idVales
-- where ve.idestatus = 2
 --group by v.idVale, v.montoSolicitado

select d.*
,p.ordencompra
--,v.montoSolicitado
--,v.montoJustificado
--,v.justificado
--,v.JustificoMas 
from @db d 
left join @pedidos p on d.idComprobacionConcepto =  p.idComprobacionVale
order by d.idcomprobacion asc
--left join @vales v on v.idvale = d.idvale

END
go

