--'AUTOMOVILISTICA ANDRADE SA DE CV'
CREATE PROCEDURE [dbo].[SEL_RFC_POR_NOMBRE_RAZON_SP] 
	@nombreRazon VARCHAR(MAX)
AS
BEGIN
	BEGIN TRY
	--IF(@nombreRazon = 'ANDRADE ZARAGOZA SA DE CV')
	--BEGIN
	--SELECT TOP 1 [PER_RFC]
 --           FROM [GA_Corporativa]..[PER_PERSONAS]
 --           WHERE [PER_NOMRAZON]= 'ANDRADE ZARAGOZA SA DE CV'
	--END
	--ELSE IF(@nombreRazon = 'DISTRIBUIDORA DE VEHICULOS ANDRADE PEDREGAL SA DE CV')
	--BEGIN
	--select 'AIN140211U55' [PER_RFC]
	--END
	--ELSE IF(@nombreRazon = 'TRASINMEX SA DE CV')
	--BEGIN
	--select PAR_DESCRIP4 [PER_RFC] from GATrasinmex.[dbo].[pnc_parametr]  WHERE PAR_TIPOPARA = 'EM'
	--END
	--ELSE IF(@nombreRazon = 'ANGAR AZCAPOTZALCO')
	--BEGIN
	--select PAR_DESCRIP4 [PER_RFC] from GAAA_Concentra.[dbo].[pnc_parametr]  WHERE PAR_TIPOPARA = 'EM'
	--END
	--ELSE
	--BEGIN
	--	SELECT TOP 1 [PER_RFC]
 --           FROM [GA_Corporativa]..[PER_PERSONAS]
 --           WHERE [PER_NOMRAZON] LIKE '%' + REPLACE(@nombreRazon,'.','') +'%'
	--		Order by PER_IDPERSONA desc
	--END
	

	DECLARE @query nvarchar(max) ='', @selBase varchar (100)

     select @selBase = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_nombre = @nombreRazon

	SET @query ='
					  SELECT PAR_DESCRIP4 PER_RFC
					  FROM '+ @selBase +'.[dbo].[pnc_parametr] 
					  WHERE PAR_TIPOPARA = ''EM''
					'
					print @query
		EXEC sp_executesql @query

	END TRY
	BEGIN CATCH
	
	END CATCh
	RETURN 0;
END

go

