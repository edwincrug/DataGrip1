
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_GUARDA_ARQUEO]
	@cabecero  NVARCHAR(MAX)
	,@detalle  NVARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @identity int = 0;

	BEGIN TRY
	BEGIN TRANSACTION [Tran1]
	
	/*insertamos el cabecero*/
	 INSERT INTO Tramites.dbo.arqueo (idUsuario, fecha, MontoSaldoCaja,idFondoFijo)
	 SELECT
		MAX(CASE
		  WHEN name = 'idUsuario' THEN CONVERT(VARCHAR(50), StringValue)
		  ELSE ''
		END) AS [idUsuario]
	   ,GETDATE() AS [fecha]
	   ,MAX(CASE
		  WHEN name = 'montoSaldoCaja' THEN CONVERT(VARCHAR(50), StringValue)
		  ELSE '0'
		END) AS [montoSaldoCaja]
		,MAX(CASE
		  WHEN name = 'idFondoFijo' THEN CONVERT(VARCHAR(50), StringValue)
		  ELSE ''
		END) AS [idFondoFijo]
	  FROM Tesoreria.dbo.parseJSON(@cabecero)
	  WHERE ValueType = 'string'
	  OR ValueType = 'int'
	  OR ValueType = 'boolean'
	  OR ValueType = 'decimal'
	  OR ValueType = 'float'
	  OR ValueType = 'money'
	  OR ValueType = 'real'
	  GROUP BY parent_ID

	  /*
	  Recuperamos el id generado
	  */
	  SET @identity = @@identity
	   INSERT INTO Tramites.dbo.arqueoDetalle (idArqueo, idMoneda, cantidadMonedas)
		SELECT
		@identity AS idArqueo
		,MAX(CASE
			WHEN name = 'idMoneda' THEN CONVERT(VARCHAR(50), StringValue)
			ELSE ''
		END) AS [idMoneda]
		,MAX(CASE
			WHEN name = 'cantidadMonedas' THEN CONVERT(VARCHAR(50), StringValue)
			ELSE '0'
		END) AS [cantidadMonedas]
	  FROM Tesoreria.dbo.parseJSON(@detalle)
	  WHERE ValueType = 'string'
	  OR ValueType = 'int'
	  OR ValueType = 'boolean'
	  OR ValueType = 'decimal'
	  OR ValueType = 'float'
	  OR ValueType = 'money'
	  OR ValueType = 'real'
	  GROUP BY parent_ID


	
	/*Si todo funciona bien */
	COMMIT TRANSACTION [Tran1]
	select 1 as estatus, 'Información almacenda correctamente' as mensaje, @identity as folio

	END TRY
	BEGIN CATCH
	/*si se genera un error*/
	ROLLBACK TRANSACTION [Tran1]
		select 0 as estatus, 'Ocurrio un error al guardar los datos '+ERROR_MESSAGE() as mensaje
	END CATCH

END
go

