-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 13/08/2020
-- Description:	Guarda el cabecero de la CXP orden de compra por anticipo de gastos de viaje y agstos de más
-- [Tramite].[Sp_Tramite_OC_AntGastoCabecero_INS]  71, 2123, 1
-- [Tramite].[Sp_Tramite_OC_AntGastoCabecero_INS]  2045, 2208, 2
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_OC_AntGastoCabecero_INS] 
	@idusuario INT,
	@id_perTra INT,
	@proceso INT
AS
BEGIN 
	--SET NOCOUNT ON;
	
	DECLARE @idOrdenMasiva INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_OC_AntGastoCabecero_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
			
			IF EXISTS( SELECT * FROM Bitacora.cxp_ordenesmasivas WHERE bita_id_perTra = @id_perTra )
			--IF (1=0)
				BEGIN
					SET @idOrdenMasiva = -1; -- Ya existe una OC para este tramite.
				END
			ELSE
				BEGIN
					DECLARE @areaAfectacion varchar (50),
							@observaciones VARCHAR(255),
							@idempresa INT,
							@idsucursal INT


					DECLARE @idEncabezado INT,
							@ParamIVA VARCHAR(2) = '15',
							@nombreBD VARCHAR(100), 
							@idProveedor INT,  
							@tasaIVA VARCHAR(100) =  '15', 
							@queryIVA NVARCHAR(MAX),
							@tasaIVACal INT,
							@nombreBDSuc VARCHAR(100),
							@odm_cantidadanticipo DECIMAL(18,2)


					--SET @idempresa = 4;
					--SET @idsucursal = 6;

					


					-- // Obtenemos la lista de detalles que se trabajara
					DECLARE @Detalles TABLE(
							id INT
							,omd_areaafectacion varchar(20)
							,omd_conceptocontable varchar(20)
							,omd_cantidad int
							,omd_producto varchar(250)
							,omd_preciounitario decimal(18, 5)
							,omd_tasaiva decimal(18, 5)
							,omd_descuento decimal(18, 5)
							,odm_idordenmasiva numeric(18, 0)
						)


					IF( @proceso = 1 )
						BEGIN
							-- Se Obtienen los datos de empresa y sucursal
							SELECT @idempresa = id_empresa, @idsucursal = id_sucursal FROM tramiteDevoluciones WHERE id_perTra = @id_perTra


							INSERT INTO @Detalles
							SELECT DISTINCT
								ROW_NUMBER() OVER(ORDER BY TED.idTramiteConcepto)
								,[omd_areaafectacion] = areaAfectacion
								,[omd_conceptocontable] = CC.idConceptoContable
								,[omd_cantidad] = 1
								,[omd_producto] = CC.concepto
								,[omd_preciounitario] = COALESCE(TIAS.importe, 0)
								,[omd_tasaiva] = 0
								,[omd_descuento] = 0
								,[odm_idordenmasiva] = 0
							FROM tramiteDevoluciones td
							join [Tramite].[TramiteConcepto] TED
								on td.id_perTra = ted.idTramitePersona
							INNER JOIN [Tramite].[ConceptoContable] CC 
								ON TED.idConceptoContable = CC.idConceptoContable
							LEFT JOIN [Tramite].[TramiteImporte] TIS 
								ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
							LEFT JOIN [Tramite].[TramiteImporte] TIAS 
								ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
							INNER JOIN cat_proceso_estatus ET 
								ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
							WHERE TED.idTramitePersona = @id_perTra AND idEstatus = 2
						END
					ELSE -- Para Gastos de Mas
						BEGIN
							-- Se Obtienen los datos de empresa y sucursal
							SELECT @idempresa = id_empresa, @idsucursal = id_sucursal
							FROM Tramite.TramiteGastosMas TGM
							JOIN tramiteDevoluciones TD ON TGM.id_perTraPadre = TD.id_perTra
							WHERE TGM.id_perTra = @id_perTra


							INSERT INTO @Detalles
							SELECT DISTINCT
								ROW_NUMBER() OVER(ORDER BY TED.idTramiteConcepto)
								,[omd_areaafectacion] = areaAfectacion
								,[omd_conceptocontable] = CC.idConceptoContable
								,[omd_cantidad] = 1
								,[omd_producto] = CC.concepto
								,[omd_preciounitario] = COALESCE(GDM.importeDeMas, 0)
								,[omd_tasaiva] = 0
								,[omd_descuento] = 0
								,[odm_idordenmasiva] = 0
							FROM tramiteDevoluciones td
							join [Tramite].[TramiteConcepto] TED
							on td.id_perTra = ted.idTramitePersona
							INNER JOIN [Tramite].[TramiteGastosMas] GDM ON GDM.idTramiteConcepto = TED.idTramiteConcepto
							INNER JOIN [Tramite].[ConceptoContable] CC 
								ON TED.idConceptoContable = CC.idConceptoContable
								and td.id_empresa = cc.idEmpresa
								and td.id_sucursal = cc.idSucursal
							LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
							LEFT JOIN [Tramite].[TramiteImporte] TIAS ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
							INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
							WHERE GDM.id_perTra = @id_perTra-- AND idEstatus = 2
						END
					

					-- SELECT * FROM @Detalles

					

					--Anticipo de Gastos
					--Anticipo de Gastos
					--Anticipo de Gastos
					SET @observaciones = 'Anticipo de gastos de viaje Tramite No: ' + CONVERT(VARCHAR(10),@id_perTra)

					SET @areaAfectacion = (SELECT TOP 1 MAX(omd_areaafectacion) FROM @Detalles)
					SET @odm_cantidadanticipo = (SELECT SUM([omd_preciounitario]) FROM @Detalles)

	
					-- Proveedores varios
					-- Proveedores varios
					--SET @idProveedor = 410798
					IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
					BEGIN
					select @idProveedor =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
					END
					ELSE
					BEGIN 
					select @idProveedor = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
					END

					--// Obtenemos el iva en cuestion
					SELECT @nombreBDSuc = suc_nombrebd FROM ControlAplicaciones.dbo.cat_sucursales WHERE suc_idsucursal = @idsucursal
					SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBDSuc+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+ @ParamIVA +''' '
					EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal INT OUTPUT', @tasaIVACal OUTPUT 
					SET @tasaIVA = @tasaIVACal

 
					--Obtener la Base de datos para dinamic
					SELECT @nombreBD = emp_nombrebd FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa = @idempresa
					--select * FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa = @idempresa


					--Insert a cxp_ordenesmasivas
					--Insert a cxp_ordenesmasivas
					--Insert a cxp_ordenesmasivas
					DECLARE @ordenesmasivas NVARCHAR(MAX) = '
						INSERT INTO ['+@nombreBD+'].[dbo].[cxp_ordenesmasivas](
								odm_idsucursal
								,odm_idproveedor
								,odm_areaafectacion
								,odm_observaciones
								,odm_tipocomprobante
								,odm_fechaorden
								,odm_fechaaplicacion
								,odm_fechaproceso
								,odm_estatus
								,odm_ordencompra
								,odm_anticipos
								,odm_cantidadanticipo
								,odm_porcentajeanticipo
								,odm_fechaanticipo
								,odm_sinflujoiva
							)
							SELECT 
								[odm_idsucursal]			= '+ CONVERT(VARCHAR(10),@idsucursal)+'
								,[odm_idproveedor]			= '+ CONVERT(VARCHAR(10),@idProveedor)+'
								,[odm_areaafectacion]		= '''+ @areaAfectacion+'''
								,[odm_observaciones]		= '''+ @observaciones+'''
								,[odm_tipocomprobante]		= 1  -- Validar [Tramite].[Sp_Tramite_TipoConceptoAfectacion_GETLBySucursal]
								,[odm_fechaorden]			= CONVERT( DATE, GETDATE(), 111)
								,[odm_fechaaplicacion]		= CONVERT( DATE, GETDATE(), 111)
								,[odm_fechaproceso]			= NULL
								,[odm_estatus]				= 0
								,[odm_ordencompra]			= NULL
								,[odm_anticipo]				= 1
								,[odm_cantidadanticipo]		= '+ CONVERT(VARCHAR(10),@odm_cantidadanticipo)+'
								,[odm_porcentajeanticipo]	= 100
								,[odm_fechaanticipo]		= GETDATE()
								,[odm_sinflujoiva]          = 1'

					EXEC(@ordenesmasivas)
					PRINT(@ordenesmasivas)
					SET @idEncabezado= @@IDENTITY

					--// Creacion de bitacora de poliza
					--// Creacion de bitacora de poliza
					--// Creacion de bitacora de poliza
					DECLARE @ordenesmasivasBitacora NVARCHAR(MAX) = '
						INSERT INTO [Bitacora].[cxp_ordenesmasivas](
								odm_idsucursal
								,odm_idproveedor
								,odm_areaafectacion
								,odm_observaciones
								,odm_tipocomprobante
								,odm_fechaorden
								,odm_fechaaplicacion
								,odm_fechaproceso
								,odm_estatus
								,odm_ordencompra
								,odm_anticipos
								,odm_cantidadanticipo
								,odm_porcentajeanticipo
								,odm_fechaanticipo
								,bita_idUsuario
								,bita_id_perTra
								,bita_fecharegistro
								,odm_idordenmasivaBPRO
							)
							SELECT 
								[odm_idsucursal]			= '+ CONVERT(VARCHAR(10),@idsucursal)+'
								,[odm_idproveedor]			= '+ CONVERT(VARCHAR(10),@idProveedor)+'
								,[odm_areaafectacion]		= '''+ @areaAfectacion+'''
								,[odm_observaciones]		= '''+ @observaciones+'''
								,[odm_tipocomprobante]		= ''01''  -- Validar [Tramite].[Sp_Tramite_TipoConceptoAfectacion_GETLBySucursal]
								,[odm_fechaorden]			= CONVERT( DATE, GETDATE(), 111)
								,[odm_fechaaplicacion]		= CONVERT( DATE, GETDATE(), 111)
								,[odm_fechaproceso]			= NULL
								,[odm_estatus]				= 0
								,[odm_ordencompra]			= NULL
								,[odm_anticipo]				= 1
								,[odm_cantidadanticipo]		= '+ CONVERT(VARCHAR(10),@odm_cantidadanticipo)+'
								,[odm_porcentajeanticipo]	= 100
								,[odm_fechaanticipo]		= GETDATE()
								,[bita_idUsuario]		= '+ CONVERT(VARCHAR(10),@idusuario)+'
								,[bita_id_perTra]		= '+ CONVERT(VARCHAR(10),@id_perTra)+'
								,[bita_fecharegistro]		= '+ CONVERT(VARCHAR(10),@proceso)+'
								,[odm_idordenmasivaBPRO]		= '+ CONVERT(VARCHAR(10),@idEncabezado)+'
								'

					EXEC(@ordenesmasivasBitacora)
					--// Creacion de bitacora de poliza


					--insert a cxp_ordenesmasivasdet
					--insert a cxp_ordenesmasivasdet
					--insert a cxp_ordenesmasivasdet
					DECLARE @ordenesmasivasDet NVARCHAR(MAX)
					IF( @proceso = 1 ) 
						BEGIN
							SET @ordenesmasivasDet = '
							INSERT INTO ['+@nombreBD+'].[dbo].[cxp_ordenesmasivasdet]
								([omd_areaafectacion]
								,[omd_conceptocontable]
								,[omd_cantidad]
								,[omd_producto]
								,[omd_preciounitario]
								,[omd_tasaiva]
								,[omd_descuento]
								,[odm_idordenmasiva])
							SELECT DISTINCT
								[omd_areaafectacion] = areaAfectacion
								,[omd_conceptocontable] = CC.idConceptoContable
								,[omd_cantidad] = 1
								,[omd_producto] = CC.concepto
								,[omd_preciounitario] =  
									CASE 
										WHEN '+ @ParamIVA +' = 0 THEN 
											TIAS.importe
										ELSE
											CONVERT(DECIMAL(18,5), TIAS.importe / ((CAST( ( CAST( '+ CONVERT(VARCHAR(10), @tasaIVA) +' AS FLOAT) / 100) AS DECIMAL(18,5)) ) + 1)) 	
									END

								,[omd_tasaiva] = '+ CONVERT(VARCHAR(10), @tasaIVA) +'						
								,[omd_descuento] = 0
								,[odm_idordenmasiva] = '+ CONVERT( VARCHAR(10), @idEncabezado ) +'
							FROM tramiteDevoluciones td
							join [Tramite].[TramiteConcepto] TED
							on td.id_perTra = ted.idTramitePersona 
							INNER JOIN [Tramite].[ConceptoContable] CC
							ON TED.idConceptoContable = CC.idConceptoContable
								and td.id_empresa = cc.idEmpresa
								and td.id_sucursal = cc.idSucursal
							LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
							LEFT JOIN [Tramite].[TramiteImporte] TIAS ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
							INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
							WHERE TED.idTramitePersona = '+ CONVERT(VARCHAR(10),@id_perTra) +' AND idEstatus = 2'
						END
					ELSE -- Para Gastos de Mas
						BEGIN
							SET @ordenesmasivasDet = '
							INSERT INTO ['+@nombreBD+'].[dbo].[cxp_ordenesmasivasdet]
								([omd_areaafectacion]
								,[omd_conceptocontable]
								,[omd_cantidad]
								,[omd_producto]
								,[omd_preciounitario]
								,[omd_tasaiva]
								,[omd_descuento]
								,[odm_idordenmasiva])
							SELECT DISTINCT
								[omd_areaafectacion] = areaAfectacion
								,[omd_conceptocontable] = CC.idConceptoContable
								,[omd_cantidad] = 1
								,[omd_producto] = CC.concepto
								,[omd_preciounitario] =  
									CASE 
										WHEN '+ @ParamIVA +' = 0 THEN 
											GDM.importeDeMas
										ELSE
											CONVERT(DECIMAL(18,5), GDM.importeDeMas / ((CAST( ( CAST( '+ CONVERT(VARCHAR(10), @tasaIVA) +' AS FLOAT) / 100) AS DECIMAL(18,5)) ) + 1)) 	
									END

								,[omd_tasaiva] = '+ CONVERT(VARCHAR(10), @tasaIVA) +'						
								,[omd_descuento] = 0
								,[odm_idordenmasiva] = '+ CONVERT( VARCHAR(10), @idEncabezado ) +'
							FROM tramiteDevoluciones td
							join [Tramite].[TramiteConcepto] TED
							on td.id_perTra = ted.idTramitePersona
							INNER JOIN [Tramite].[TramiteGastosMas] GDM ON GDM.idTramiteConcepto = TED.idTramiteConcepto
							INNER JOIN [Tramite].[ConceptoContable] CC 
							ON TED.idConceptoContable = CC.idConceptoContable
								and td.id_empresa = cc.idEmpresa
								and td.id_sucursal = cc.idSucursal
							LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
							LEFT JOIN [Tramite].[TramiteImporte] TIAS ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
							INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
							WHERE GDM.id_perTra = '+ CONVERT(VARCHAR(10),@id_perTra) +''
						END
					
					EXEC(@ordenesmasivasDet) 
					PRINT @ordenesmasivasDet


					--// Creacion de bitacora de detalle de poliza
					--// Creacion de bitacora de detalle de poliza
					--// Creacion de bitacora de detalle de poliza
					DECLARE @ordenesmasivasDetBitacora NVARCHAR(MAX) = '
						INSERT INTO [Bitacora].[cxp_ordenesmasivasdet]
							([omd_areaafectacion]
							,[omd_conceptocontable]
							,[omd_cantidad]
							,[omd_producto]
							,[omd_preciounitario]
							,[omd_tasaiva]
							,[omd_descuento]
							,[odm_idordenmasiva])
						SELECT DISTINCT
							[omd_areaafectacion] = areaAfectacion
							,[omd_conceptocontable] = CC.idConceptoContable
							,[omd_cantidad] = 1
							,[omd_producto] = CC.concepto
							,[omd_preciounitario] =  
								CASE 
									WHEN '+ @ParamIVA +' = 0 THEN 
										TIAS.importe
									ELSE
										CONVERT(DECIMAL(18,5), TIAS.importe / ((CAST( ( CAST( '+ CONVERT(VARCHAR(10), @tasaIVA) +' AS FLOAT) / 100) AS DECIMAL(18,5)) ) + 1)) 	
								END

							,[omd_tasaiva] = '+ CONVERT(VARCHAR(10), @tasaIVA) +'						
							,[omd_descuento] = 0
							,[odm_idordenmasiva] = '+ CONVERT( VARCHAR(10), @idEncabezado ) +'
						FROM tramiteDevoluciones td
						join [Tramite].[TramiteConcepto] TED
							on td.id_perTra = ted.idTramitePersona
						INNER JOIN [Tramite].[ConceptoContable] CC 
						ON TED.idConceptoContable = CC.idConceptoContable
								and td.id_empresa = cc.idEmpresa
								and td.id_sucursal = cc.idSucursal
						LEFT JOIN [Tramite].[TramiteImporte] TIS ON TED.idTramiteConcepto = TIS.idTramiteConcepto AND TIS.idTipoProceso = 1
						LEFT JOIN [Tramite].[TramiteImporte] TIAS ON TED.idTramiteConcepto = TIAS.idTramiteConcepto AND TIAS.idTipoProceso = 2
						INNER JOIN cat_proceso_estatus ET ON TED.idEstatus = ET.esDe_IdEstatus AND ET.idTipoTramite = 9
						WHERE TED.idTramitePersona = '+ CONVERT(VARCHAR(10),@id_perTra) +' AND idEstatus = 2'
					EXEC(@ordenesmasivasDetBitacora) 
					--PRINT(@ordenesmasivasDetBitacora) 
					--// Creacion de bitacora de detalle de poliza




					-- Update
					DECLARE @idEmpresaGV INT,
							@idSucursalGV INT,
							@idDepartamentoGV INT,
							@emp_nombrecto VARCHAR(100),
							@suc_nombrecto VARCHAR(100),
							@dep_nombrecto VARCHAR(100)


					select @idEmpresaGV = id_empresa, @idSucursalGV = id_sucursal, @idDepartamentoGV = id_departamento from tramitedevoluciones where id_perTra = @id_perTra


					select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cdsg.par_idenPara--cd.dep_nombrecto 
					from ControlAplicaciones.dbo.cat_empresas ce 
					inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
					JOIN Tramites.Tramite.cat_Departamentos_Sucursal_GV cdsg
					ON ce.emp_idempresa = cdsg.idEmpresa
						AND cs.suc_idsucursal = cdsg.idSucursal
						AND cdsg.idDepartamento = @idDepartamentoGV
					--inner join ControlAplicaciones.dbo.cat_departamentos cd 
					--on cs.suc_idsucursal = cd.suc_idsucursal
					WHERE ce.emp_idempresa = @idEmpresaGV AND cs.suc_idsucursal = @idSucursalGV AND cdsg.idDepartamento = @idDepartamentoGV

					DECLARE @Incremento INT = (
					SELECT  
						CASE 
							WHEN MAX(procesadoOP) IS NULL THEN 1
							ELSE MAX(procesadoOP) + 1
						END Maximo
					FROM Tramite.TramiteConcepto where idTramitePersona =  @id_perTra and documentoConcepto is null
					)

					DECLARE @Folio VARCHAR(25) = 'AG-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto + '-' + CONVERT(VARCHAR(10), @id_perTra) + '-' + CONVERT(VARCHAR(10), @Incremento)

					UPDATE Tramite.TramiteConcepto SET documentoConcepto = @Folio, procesadoOP = @Incremento where idTramitePersona =  @id_perTra and documentoConcepto is null
					-- Fin Update

					SET @idOrdenMasiva = @idEncabezado
				END
			
		
		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @idOrdenMasiva AS [resultado]
END
go

