
-- =============================================
-- Author:		
-- Create date: 
-- Description:	Actualiza el estatus del document0
-- TEST UPD_RECHAZAR_ESTATUS_DOCUMENTO_BANCARIO_TESORERIA_SP 108,'sdfsdfsdfsdfsdf'
-- =============================================
CREATE PROCEDURE [dbo].[UPD_RECHAZAR_ESTATUS_DOCUMENTO_BANCARIO_TESORERIA_SP] 
	@det_idPerTra INT,
	@razonesRechazo VARCHAR(100),
	@idUsuario INT = 0
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY
	DECLARE @aprobados INT = 0
			,@numCuentas INT = 0
			,@rfc VARCHAR(250)
	DECLARE @idPerTra INT =  (SELECT id_perTra FROM detallePersonaCuenta WHERE idDetPersonaTramite = @det_idPerTra)
	
	
	SELECT @rfc = per_rfc  from personas p
	inner join personaTramite PT on P.id_persona = PT.id_persona 
	WHERE PT.id_perTra = @idPerTra


	UPDATE detallePersonaCuenta
	SET det_estatus = 3,
	det_observaciobes = @razonesRechazo,
	estatusTesoreria = NULL

	WHERE idDetPersonaTramite = @det_idPerTra;
	
	update  personaTramite
	SET petr_estatus = 12 
	where id_perTra = @idPerTra
	update  personaTramite
	SET esDe_IdEstatus = 1 
	where id_perTra = @idPerTra

	SELECT @numCuentas = count(1) from detallePersonaCuenta where id_perTra = @idPerTra 
	SELECT @aprobados =  count(1) from detallePersonaCuenta where id_perTra = @idPerTra AND det_estatus = 2

	IF(@numCuentas != @aprobados)
	BEGIN
		UPDATE  detallePersonaTramite SET det_estatus = 3 where id_perTra = @idPerTra and id_traDo IN (select id_traDo from cat_tramiteDocumento where id_documento = 9)
	END

	/***** Cambiar el estatus de la notificacion ****/
	DECLARE  @not_id NUMERIC(18,0)	
			,@idAprobacion NUMERIC(18,0)	
	
	SELECT @not_id =  N.not_id  from Notificacion.dbo.Not_Notificacion N 
	INNER JOIN Notificacion.dbo.Not_aprobacion A ON N.not_id = A.not_id
	where not_adjunto = Convert(varchar(20),@idPerTra) and not_estatus = 2 AND not_identificador = @rfc AND not_agrupacion = 23 --and emp_id =@idUsuario

	SELECT @idAprobacion = apr_id from Notificacion.dbo.NOT_APROBACION where not_id = @not_id

	--select @not_id,@idAprobacion
	

	--- Cambio estatus de notificacion
	--UPDATE Notificacion.dbo.NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = @not_id --(SELECT not_id FROM Notificacion.dbo.NOT_APROBACION WHERE apr_id = @idAprobacion)
	
	UPDATE Notificacion.dbo.NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id in ( select not_id  from Notificacion.dbo.Not_Notificacion N where not_adjunto = Convert(varchar(20),@idPerTra) and not_estatus = 2 AND not_identificador = @rfc AND not_agrupacion = 23)
	
	UPDATE Notificacion.dbo.NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion
		
	----------------------------------------------------------------
	-------Inserta una respuesta de aprobación
	----------------------------------------------------------------
	INSERT INTO Notificacion.dbo.[NOT_APROBACION_RESPUESTA]									
		(not_id,[apr_id],[nar_fecha],[nar_comentario])
	VALUES
		(@not_id,@idAprobacion,GETDATE(),'Se aprueba Trámite')	
	----------------------------------

	
	SELECT success = 1, msg = 'Se rechazo el documento con éxito.'
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	SELECT ERROR_MESSAGE()
	ROLLBACK TRANSACTION
	SELECT success = -1, msg = 'Error al realizar el rechazo.'
END CATCH
END
go

