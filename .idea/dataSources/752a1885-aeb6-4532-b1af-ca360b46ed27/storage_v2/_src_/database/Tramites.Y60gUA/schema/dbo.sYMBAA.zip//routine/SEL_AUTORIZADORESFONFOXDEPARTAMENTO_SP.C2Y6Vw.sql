-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 25/06/2020
-- Modify: Juan Carlos
-- Modify date: 19/05/2020
-- Description:	SP para obtener los departamentos x fondo
-- =============================================
CREATE PROCEDURE [dbo].[SEL_AUTORIZADORESFONFOXDEPARTAMENTO_SP] 
	@idEmpresa INT,
	@idSucursal INT
AS

BEGIN


--select 
--a.iddepartamento,
--a.descripcion,
--a.idAutorizador,
--u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as autorizador,
--u.usu_correo as correo
----from  Tramite.autorizadoresFondoFijo a 
--from  Tramite.cat_Departamentos_Sucursal_FF a 
--inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = a.idAutorizador
--where a.idEmpresa = @idEmpresa and a.idSucursal = @idSucursal 

--END
DECLARE @depWSF INT

select @depWSF = estatusFondos from tramites.Tramite.SucursalesXAreasFF where idEmpresa = @idEmpresa and idSucursal = @idSucursal
IF(@depWSF = 1)
BEGIN
select 
a.iddepartamento,
a.descripcion,
a.idAutorizador,
u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as autorizador,
u.usu_correo as correo
from  Tramite.cat_Departamentos_Sucursal_FF a 
inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = a.idAutorizador
where a.idEmpresa = @idEmpresa and a.idSucursal = @idSucursal 
END
ELSE
BEGIN
select iddepartamento, idAutorizador from [Tramite].[autorizadoresFondoFijo] 
where idEmpresa = @idEmpresa and idSucursal = @idSucursal 
END
END



go

