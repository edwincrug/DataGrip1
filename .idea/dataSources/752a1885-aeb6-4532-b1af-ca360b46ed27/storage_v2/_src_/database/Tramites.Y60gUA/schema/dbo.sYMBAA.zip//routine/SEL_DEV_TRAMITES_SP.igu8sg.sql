-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <02/07/2019>
-- Description:	<Regresa los tramites>
--TEST SEL_DEV_TRAMITES_SP 347
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEV_TRAMITES_SP] 
	@idUsuario INT
AS
BEGIN
	SELECT 
		T.id_tramite,
		T.tra_nomTramite
	FROM  cat_tramites T
	INNER JOIN cat_usuarioTramite UT ON UT.id_tramite = T.id_tramite
	WHERE UT.id_usuario = @idUsuario;
END
;
go

