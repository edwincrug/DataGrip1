-- =============================================
-- Author:		<Luis García>
-- Create date: <30/07/2019>
-- Description:	<SP que trae los datos estatus del tramite de devouciones>
-- TEST SEL_DEV_ESTATUS_SP 3557
--select * from BitacoraTramite where id_perTra = 3557
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEV_ESTATUS_SP] 
@idPerTra INT
AS
BEGIN
	--DECLARE @idPerTra INT = 3555	
	
	DECLARE @tblEstatus as TABLE (idEstatus int, descripcion VARCHAR(100), icono VARCHAR(50),orden INT, tiempo VARCHAR(20), esDe_idEstatus INT)


	IF ((SELECT traDe_devTotal from tramiteDevoluciones where id_perTra = @idPerTra) <= 	(SELECT  CONVERT(DECIMAL,pr_descripcion) FROM parametros WHERE pr_identificador = 'PARAM_AMOUNT'))
	BEGIN
			INSERT INTO @tblEstatus (idEstatus,descripcion,icono,orden, esDe_idEstatus)
			SELECT 
			orden AS idEstatus,
			esDe_descripcion AS descripcion,
			esDe_icono AS icono,
			orden, 
			esDe_IdEstatus
			FROM cat_proceso_estatus
			WHERE idTipoTramite = 4
			AND esDe_IdEstatus not in (8)
			ORDER BY orden asc
	END
	ELSE
	BEGIN
			INSERT INTO @tblEstatus (idEstatus,descripcion,icono,orden , esDe_idEstatus)
			SELECT 
			orden AS idEstatus,
			esDe_descripcion AS descripcion,
			esDe_icono AS icono,
			orden,
			esDe_IdEstatus
			FROM cat_proceso_estatus
			WHERE idTipoTramite = 4
			ORDER BY orden asc
	END

	
	DECLARE @tblAux as TABLE (id INT IDENTITY(1,1),esDe_IdEstatus INT, fechaMovimiento DATETIME)

	INSERT INTO @tblAux
	select B.esDe_IdEstatus,  min(fechaMovimiento) from BitacoraTramite B
	inner join cat_proceso_estatus P on B.esDe_IdEstatus = P.esDe_IdEstatus
	
	where id_perTra = @idPerTra
	and B.esDe_IdEstatus is not null and P.idTipoTramite = 4
	group by B.esDe_IdEstatus, fechaMovimiento

	--SELECT * FROm @tblAux
	DECLARE @cont INT = 1
	DECLARE @fecha1 datetime, @fecha2 Datetime
	DECLARE @idEstatus INT

	WHILE @cont <= (SELECT count(1) from @tblAux )
	BEGIN
		select @fecha1 = fechaMovimiento, @idEstatus = esDe_IdEstatus from @tblAux where id = @cont
		select @fecha2 = fechaMovimiento from @tblAux where id = @cont + 1

		

		--select DATEDIFF(mi,@fecha1,@fecha2)/60

		update @tblEstatus set tiempo = CONVERT(VARCHAR(10),DATEDIFF(mi,@fecha1,@fecha2)/60)+'Hrs. '+ CONVERT(VARCHAR(10), DATEDIFF(mi,@fecha1,@fecha2)%60)+ 'min.'  where esDe_idEstatus = @idEstatus
		SET @cont = @cont+1
		
	END

	Declare @fecha datetime
			,@idEst INT
	select top 1 @fecha=  fechaMovimiento , @idEst = B.esDe_IdEstatus from BitacoraTramite B
	inner join cat_proceso_estatus P on B.esDe_IdEstatus = P.esDe_IdEstatus
	
	where id_perTra = @idPerTra
	and B.esDe_IdEstatus is not null and P.idTipoTramite = 4
	group by B.esDe_IdEstatus, fechaMovimiento
	order by fechaMovimiento desc

	
		update @tblEstatus set tiempo = '0Hrs. 0min.'  where esDe_idEstatus = 0

		update @tblEstatus set tiempo = (select CONVERT(VARCHAR(10),DATEDIFF(mi,fechaMovimiento,GETDATE())/60)+'Hrs. '+ CONVERT(VARCHAR(10), DATEDIFF(mi,fechaMovimiento,GETDATE())%60)+ 'min.' from @tblAux where  fechaMovimiento = @fecha)  where esDe_idEstatus = @idEst
	

	--select * from BitacoraTramite WHERE id_perTra = 3555 

	select * from @tblEstatus


	

	
	--SELECT 
	--	esDe_IdEstatus AS idEstatus,
	--	esDe_descripcion AS descripcion,
	--	esDe_icono AS icono,
	--	orden
	--FROM cat_proceso_estatus
	--WHERE idTipoTramite = 4
	--ORDER BY orden asc




END



go

