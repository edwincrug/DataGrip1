CREATE PROCEDURE [dbo].[SEL_PROCESO_ESTATUS_SP] 

@IdTipoTramite INT 
,@monto	 NUMERIC(18,2) = 0
,@idPerTra INT 
		
AS
BEGIN
	DECLARE @estatus INT = -1
	IF(@IdTipoTramite = 3)
	BEGIN

		DECLARE @consulta NVARCHAR(MAX) = ''
		DECLARE @estatusTra INT = 0
	
		 SELECT @estatusTra = petr_estatus FROM [Tramites].[dbo].[personaTramite] where id_perTra = @idPerTra

		SET @consulta = 'SELECT	 esDe_IdEstatus AS id
								,esDe_descripcion  AS descripcion
								,esDe_icono AS icono
								,idTipoTramite
								FROM cat_proceso_estatus WHERE  idTipoTramite = '+ CONVERT(NVARCHAR(5),@IdTipoTramite) +' AND  esDe_IdEstatus <> 8 '

								IF(@monto <= 100000.00)
								BEGIN 
									SET @consulta += 'AND esDe_IdEstatus <> 5 '
								END
								ELSE
								BEGIN
									SET @consulta += 'AND esDe_IdEstatus <> 4 '
								END
								IF(@estatusTra  <> 3)
								BEGIN 
									SET @consulta += ' AND  esDe_IdEstatus <= 5 AND  esDe_IdEstatus <> 0 '
								END
								ELSE
								BEGIN 
									SET @consulta += ' AND  esDe_IdEstatus <= 6 '
								END 
		EXECUTE(@consulta)
		
	END

	IF(@IdTipoTramite = 1)
	BEGIN

	SELECT @estatus = esDe_IdEstatus  FROM personaTramite WHERE id_perTra = @idPerTra 

	IF(@estatus = 2)
	BEGIN
	SELECT esDe_IdEstatus id
			,esDe_descripcion descripcion 
			,esDe_icono icono
			,idTipoTramite
	FROM cat_proceso_estatus WHERE  idTipoTramite = @IdTipoTramite
	AND  esDe_IdEstatus <= @estatus
	END
	ELSE
	BEGIN
	SELECT esDe_IdEstatus id
			,esDe_descripcion descripcion 
			,esDe_icono icono
			,idTipoTramite
	FROM cat_proceso_estatus WHERE  idTipoTramite = @IdTipoTramite
	AND  esDe_IdEstatus NOT IN (2)
	END


	

	END
END



;
go

