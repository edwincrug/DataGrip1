



-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <03/12/2019>
-- Description:	<SP que actualiza la salida de efectivo de el concepto>
-- [dbo].[SEL_VALIDAPERIODOCONTABLE_SP]     6,'202004'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDAPERIODOCONTABLE_SP] 
	@idSucursal INT,
	@periodo varchar (10)
AS
BEGIN
	
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = ''

	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE suc_idsucursal = @idSucursal AND suc_estatus = 1;
 
	SET @query = 'SELECT PAR_IDENPARA, PAR_DESCRIP1, PAR_DESCRIP2 FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''MCERRCON''
				  AND substring(PAR_IDENPARA,1,6) =  ' + @periodo + '' 

	EXECUTE (@query)

END
go

