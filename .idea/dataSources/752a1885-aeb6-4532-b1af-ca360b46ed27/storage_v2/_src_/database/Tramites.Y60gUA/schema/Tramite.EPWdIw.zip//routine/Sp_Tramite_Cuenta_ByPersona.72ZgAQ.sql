-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Tramite].[Sp_Tramite_Cuenta_ByPersona] 1993
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_Cuenta_ByPersona]
	-- Add the parameters for the stored procedure here
	@idPersona INT = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT TOP (1) [ca_clabe] clabe
		  ,[ca_cuenta] cuenta
		  ,[ca_idbanco] idBanco
		  ,[ca_banconombre] banco
		  ,[ca_plaza] plaza
		  ,[ca_sucursal] sucursal
		  ,[ca_cvebanxico] cveBanxico
		  ,[ca_estatus] estatus
	FROM [Tramites].[dbo].[cuentaAutorizada]
	WHERE idPersona = @idPersona -- AND ca_estatus = 3
	ORDER BY idCuentaAutorizada DESC
END
go

