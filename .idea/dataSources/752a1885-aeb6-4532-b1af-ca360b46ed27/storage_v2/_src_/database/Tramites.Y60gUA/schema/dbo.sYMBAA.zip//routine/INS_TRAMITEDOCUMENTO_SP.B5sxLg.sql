-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/06/2019>
-- Description:	<Se guardan los documentos del tramite>
-- Test INS_TRAMITEDOCUMENTO_SP '8,5|8,4|8,1'
--INS_TRAMITEDOCUMENTO_SP 'id_tramite,id_documento|id_tramite,id_documento'
-- =============================================
CREATE PROCEDURE [dbo].[INS_TRAMITEDOCUMENTO_SP]
	@input VARCHAR(MAX)
AS
BEGIN
	BEGIN TRY
		INSERT INTO cat_tramiteDocumento(
			id_tramite,
			id_documento)
		SELECT 
			idTramite,
			idDocumento
		FROM dbo.[SplitDocumentos](@input)
		SELECT success = 1, msg = 'Se guardo con éxito el tramite.'
	END TRY
	BEGIN CATCH
		SELECT success = 0, msg = 'Error al guardar los datos.' 
	END CATCH
END
go

