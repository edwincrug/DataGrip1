-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <11/06/2019>
-- Description:	Trae los tramites por area
--TEST SEL_TRAMITE_BY_AREA_SP 1, 2166
-- =============================================


create PROCEDURE SEL_TRAMITE_BY_AREA_SP_RESP_20201030
	@idArea INT,
	@usuario INT
AS
BEGIN

--DECLARE @idArea INT = 3
--		,@usuario INT = 2196

DECLARE @idRol INT = 0;

SELECT 
	@idRol = idRol
FROM usuarioRol WHERE idUsuario = @usuario

print 'Rol: '+ cast(@idRol as varchar(5))

IF @idRol = 14  --DIRECTOR DE MARCA
BEGIN

							SELECT 
								est_nombre,
								id_perTra,
								max(nombre) nombre,
								CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
								tra_nomTramite,
								max(id_persona) id_persona,
								max(per_rfc) per_rfc,
								max(id_TipoProspecto) id_TipoProspecto,
								id_estatus,
								DATEDIFF(DAY, fecha, GETDATE() ) AS dias
								,id_tramite,
								noti,
								notiRevisar,
								notiDocsAprobar
							FROM(
							--(SELECT 
							--	ESTR.est_nombre,
							--	PETR.id_perTra,
							--	PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre AS nombre,
							--	PETR.petr_fechaTramite,
							--	TRA.tra_nomTramite,
							--	PER.id_persona,
							--	PER.per_rfc,
							--	PER.id_TipoProspecto,
							--	ESTR.id_estatus AS id_estatus
							--	,PETR.id_tramite,
							--	'' PER_PERSONA,
							--	0 noti,
							--	0 notiRevisar,
							--	0 notiDocsAprobar
							--FROM personaTramite PETR
							--INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							--INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							--INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
							--INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
							--inner join UsuariosAreas ua on ua.usu_idusuario =  @usuario
							--inner join clientes.dbo.TramiteCliente t on PETR.id_perTra = t.tramites_Id
							--WHERE 
							
							--PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) 
							--AND T.idEmpresa = ORG.emp_idempresa 
							--AND T.idSucursal = ORG.suc_idsucursal
							

							--UNION ALL

								SELECT DISTINCT
								PE.esDe_descripcion est_nombre,
								PETR.id_perTra,
								CASE WHEN PETR.id_tramite in (4,10) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
								PETR.petr_fechaTramite,
								TRA.tra_nomTramite,
								0 AS id_persona,
								'' AS per_rfc,
								0 AS id_TipoProspecto,
								ESTR.id_estatus,
								[petr_fechaTramite] as fecha, 
								PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
								TRA.id_tramite,
								CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
								CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
								CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
							FROM personaTramite PETR
							INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
							INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario AND TD.id_empresa = ORG.emp_idempresa
							INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
							INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
							LEFT JOIN Tramite.FlujoRolTramite frt
							ON frt.idArea = @idArea
							AND tra.id_tramite = frt.idTramite
							--WHERE  CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
							--		WHEN  frt.idRolSiguiente IS NULL AND  (PETR.petr_estatus NOT IN (2, 3, 4, 5)) THEN 1
							--		END = 1
						
							--AND PETR.petr_estatus NOT IN (2, 3)
							--AND TD.esDe_IdEstatus = 2
							--AND TRA.id_tramite = 4
							WHERE  CASE WHEN TRA.id_tramite in (10) THEN 1
							WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
									WHEN  frt.idRolSiguiente IS NULL AND  (PETR.petr_estatus NOT IN (2, 3, 4, 5)) THEN 1
									END = 1	
							AND PETR.petr_estatus NOT IN (2, 3)
							AND CASE WHEN TRA.id_tramite in (10) THEN 1
							    WHEN TD.esDe_IdEstatus = 2 THEN 1
								END = 1 
							AND TRA.id_tramite in (4,10)

							 ) x
								GROUP BY est_nombre, id_perTra,	petr_fechaTramite, tra_nomTramite, id_estatus, id_tramite, 	noti, notiRevisar, notiDocsAprobar, fecha
								ORDER BY id_perTra DESC

END 
ELSE IF @idRol = 15  --ESCRUTADOR
BEGIN						
							SELECT 
								est_nombre,
								id_perTra,
								max(nombre) nombre,
								CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
								tra_nomTramite,
								max(id_persona) id_persona,
								max(per_rfc) per_rfc,
								max(id_TipoProspecto) id_TipoProspecto,
								id_estatus,
								DATEDIFF(DAY, fecha, GETDATE() ) AS dias
								,id_tramite,
								noti,
								notiRevisar,
								notiDocsAprobar
							FROM(
							--(SELECT 
							--	ESTR.est_nombre,
							--	PETR.id_perTra,
							--	PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre AS nombre,
							--	PETR.petr_fechaTramite,
							--	TRA.tra_nomTramite,
							--	PER.id_persona,
							--	PER.per_rfc,
							--	PER.id_TipoProspecto,
							--	ESTR.id_estatus AS id_estatus
							--	,PETR.id_tramite,
							--	'' PER_PERSONA,
							--	0 noti,
							--	0 notiRevisar,
							--	0 notiDocsAprobar
							--FROM personaTramite PETR
							--INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							--INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							--INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
							--INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
							--inner join UsuariosAreas ua on ua.usu_idusuario =  @usuario
							--inner join clientes.dbo.TramiteCliente t on PETR.id_perTra = t.tramites_Id
							--WHERE 
							
							--PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) 
							--AND T.idEmpresa = ORG.emp_idempresa 
							--AND T.idSucursal = ORG.suc_idsucursal
							

							--UNION ALL

								SELECT DISTINCT
								PE.esDe_descripcion est_nombre,
								PETR.id_perTra,
								CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
								PETR.petr_fechaTramite,
								TRA.tra_nomTramite,
								0 AS id_persona,
								'' AS per_rfc,
								0 AS id_TipoProspecto,
								ESTR.id_estatus,
								[petr_fechaTramite] as fecha, 
								PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
								TRA.id_tramite,
								CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
								CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
								CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
							FROM personaTramite PETR
							INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
							INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = org.suc_idsucursal
							INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
							INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
							LEFT JOIN Tramite.FlujoRolTramite frt
							ON frt.idArea = @idArea
							AND tra.id_tramite = frt.idTramite
							WHERE  CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
									WHEN  frt.idRolSiguiente IS NULL AND  (PETR.petr_estatus NOT IN (2, 3, 4, 5)) THEN 1
									END = 1
						
							AND PETR.petr_estatus NOT IN (2, 3)
							AND TD.esDe_IdEstatus = 2
							AND TRA.id_tramite = 4
						
							 ) x
								GROUP BY est_nombre, id_perTra,	petr_fechaTramite, tra_nomTramite, id_estatus, id_tramite, 	noti, notiRevisar, notiDocsAprobar, fecha
								ORDER BY id_perTra DESC

END
ELSE IF @idRol = 12  --APROBACION
BEGIN
		SELECT 
			est_nombre,
			id_perTra,
			max(nombre) nombre,
			CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
			tra_nomTramite,
			max(id_persona) id_persona,
			max(per_rfc) per_rfc,
			max(id_TipoProspecto) id_TipoProspecto,
			id_estatus,
			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			,id_tramite,
			PER_PERSONA,
			noti,
			notiRevisar,
			notiDocsAprobar
		FROM (
		SELECT 
						PE.esDe_descripcion est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite IN (4, 9, 10) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus
						,PETR.id_tramite,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea AND tra.id_tramite = frt.idTramite
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					LEFT JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
					WHERE TRA.id_tramite IN (9) AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) AND TD.esDe_IdEstatus IN (0,1,2,8,4,10) AND
						CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
							WHEN frt.idRolSiguiente IS NOT NULL AND PETR.petr_estatus NOT IN (2, 3) and @idArea IN (1, 2) then 1
							WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) then 1
							END = 1 
		) x
			GROUP BY est_nombre,
				id_perTra,
				petr_fechaTramite,
				tra_nomTramite,
				id_estatus,
				id_tramite,
				PER_PERSONA,
				noti,
				notiRevisar,
				notiDocsAprobar
			ORDER BY id_perTra DESC

END
ELSE IF @idRol = 11  --EFECTIVO
BEGIN

		SELECT 
			est_nombre,
			id_perTra,
			max(nombre) nombre,
			CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
			tra_nomTramite,
			max(id_persona) id_persona,
			max(per_rfc) per_rfc,
			max(id_TipoProspecto) id_TipoProspecto,
			id_estatus,
			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			,id_tramite,
			PER_PERSONA,
			noti,
			notiRevisar,
			notiDocsAprobar
		FROM (SELECT 
			PE.esDe_descripcion est_nombre,
			PETR.id_perTra,
			CASE WHEN PETR.id_tramite IN (4, 9, 10) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			0 AS id_persona,
			'' AS per_rfc,
			0 AS id_TipoProspecto,
			ESTR.id_estatus
			,PETR.id_tramite,
			PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
			CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
			CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
			CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
		LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea AND tra.id_tramite = frt.idTramite
		INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
		LEFT JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
		WHERE TRA.id_tramite = 9 
		AND CASE 
			WHEN  TRA.id_tramite = 9 and  (select min(ISNULL(idSalidaEfectivo,0)) from Tramite.TramiteConcepto where idTramitePersona = PETR.id_perTra) > 0 then 0
			WHEN  TRA.id_tramite IN (9,10) then 1
			WHEN  PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) THEN 1
			END = 1
		--AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) 
		AND TD.esDe_IdEstatus IN (2) AND
			CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
				WHEN frt.idRolSiguiente IS NOT NULL AND PETR.petr_estatus NOT IN (2, 3) and @idArea IN (1, 2) then 1
				WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6, 9, 10) then 1
				END = 1) x
			GROUP BY est_nombre,
				id_perTra,
				petr_fechaTramite,
				tra_nomTramite,
				id_estatus,
				id_tramite,
				PER_PERSONA,
				noti,
				notiRevisar,
				notiDocsAprobar
				
			UNION ALL
			
			SELECT 
				est_nombre = 'Aprobado'
				,TGM.id_perTra,
				(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
				CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
				T.tra_nomTramite,
				id_persona = 0,
				per_rfc = '',
				id_TipoProspecto = 0,
				ET.id_estatus,
				DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
				T.id_tramite,
				'' as PER_PERSONA, --PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,--'' as PER_PERSONA,
				0 noti,
				0 notiRevisar,
				0 notiDocsAprobar
			FROM [Tramite].[TramiteGastosMas] TGM
			INNER JOIN personaTramite PT ON TGM.id_perTra = PT.id_perTra
			INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
			INNER JOIN estatusTesoreria ET ON ET.id_estatus = TGM.estatus
			LEFT JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = PT.id_persona
			WHERE
				TGM.estatus = 1
				AND T.id_tramite = 15
			ORDER BY id_perTra DESC

END
ELSE IF(@idRol = 10)
	BEGIN
		SELECT 
			est_nombre,
			id_perTra,
			max(nombre) nombre,
			CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
			tra_nomTramite,
			max(id_persona) id_persona,
			max(per_rfc) per_rfc,
			max(id_TipoProspecto) id_TipoProspecto,
			id_estatus,
			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			,id_tramite,
			PER_PERSONA,
			noti,
			notiRevisar,
			notiDocsAprobar
		FROM
		(SELECT 
			
			--CASE WHEN PETR.id_tramite in (1,2,5) THEN PE2.esDe_descripcion ELSE PE.esDe_descripcion END est_nombre,
			case WHEN PETR.id_tramite in (1,2,5) THEN est_nombre ELSE PE.esDe_descripcion END est_nombre,
			PETR.id_perTra,
			UPPER(PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre) +' - '+ UPPER(PER.per_rfc)  AS nombre,
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			PER.id_persona,
			PER.per_rfc,
			PER.id_TipoProspecto,
			ESTR.id_estatus AS id_estatus
			,PETR.id_tramite,
			'' PER_PERSONA,
			CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
			CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
			CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
		 FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
		LEFT JOIN clientes.dbo.TramiteCliente TC ON TC.tramites_Id = PETR.id_perTra
		LEFT JOIN cat_proceso_estatus PE ON PE.idTipoTramite = (CASE WHEN TRA.id_tramite IN (3,6,7,8)  THEN 3 ELSE TRA.id_tramite END) AND PE.esDe_IdEstatus = (CASE WHEN TRA.id_tramite IN (3,6,7,8) THEN TC.estatus ELSE PETR.esDe_IdEstatus END)
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
		WHERE PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) AND TRA.id_tramite IN (1, 2, 3, 5, 6, 7, 8)
		
		UNION ALL
SELECT 
			case when PETR.id_tramite IN (16)  then PE.esDe_descripcion + ' - ' + 
			(select 
			case 
			when ISNULL(MAX(estatusPerTraReembolso),0 ) = 0 and isnull (MAX(estatusReembolso),0) = 0  then 'Finanzas 1'
			when ISNULL(MAX(estatusPerTraReembolso),0 ) = 1 and isnull (MAX(estatusReembolso),0) = 0  then 'Finanzas 2'
			when ISNULL(MAX(estatusPerTraReembolso),0 ) = 2 and isnull (MAX(estatusReembolso),0) = 0  then 'Finanzas 3'
			when ISNULL(MAX(estatusPerTraReembolso),0 ) = 3 and isnull (MAX(estatusReembolso),0) = 0  then 'Tesoreria'
			when MAX(estatusReembolso) = 2 then 'Rechazado' 
			when MAX(estatusReembolso) = 1 then 'Pagado' 
			end	as Estatus	
			from tramites.tramite.valesEvidencia where id_pertraReembolso = PETR.id_perTra and idestatus = 2-- group by id_perTraReembolso, estatusPerTraReembolso, estatusReembolso
			)
			else PE.esDe_descripcion end est_nombre,
			--PE.esDe_descripcion est_nombre,
			PETR.id_perTra,
			CASE WHEN PETR.id_tramite IN (4, 9, 10, 16) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
			PETR.petr_fechaTramite,
			CASE WHEN PETR.id_tramite = 10 THEN  TRA.tra_nomTramite + ' - ' + (select idFondoFijo from Tramite.fondoFijo where id_perTra = PETR.id_perTra) ELSE TRA.tra_nomTramite END as tra_nomTramite,
			--TRA.tra_nomTramite,
			0 AS id_persona,
			'' AS per_rfc,
			0 AS id_TipoProspecto,
			ESTR.id_estatus
			,PETR.id_tramite,
			PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
			CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
			CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
			CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
		LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea AND tra.id_tramite = frt.idTramite
		INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
		LEFT JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
		WHERE TRA.id_tramite IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 16) -- Quitar tramite 9 de rol 10 
		AND CASE 
			WHEN  TRA.id_tramite in (10) and (select esDe_IdEstatus from tramiteDevoluciones where id_perTra = TD.id_perTra) = 5 THEN 1
			WHEN  TRA.id_tramite = 10 and (select top 1 1 from tramite.fondofijo where id_perTra =PETR.id_perTra and estatusfondofijo = 2) = 1 then 1
			WHEN  TRA.id_tramite = 9 and  (select min(ISNULL(idSalidaEfectivo,0)) from Tramite.TramiteConcepto where idTramitePersona = PETR.id_perTra) = 1 then 0
			WHEN  TRA.id_tramite IN (9,10) then 1
			WHEN  PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) THEN 1
			END = 1
		--AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) 
		AND TD.esDe_IdEstatus IN (2,5) AND
			CASE 
				WHEN  TRA.id_tramite in (10) and (select esDe_IdEstatus from tramiteDevoluciones where id_perTra = TD.id_perTra) = 5 THEN 1
				WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
				WHEN frt.idRolSiguiente IS NOT NULL AND PETR.petr_estatus NOT IN (2, 3) and @idArea IN (1, 2) then 1
				WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6,9, 10) then 1
				END = 1
		union ALL -- gastos de viaje

	  SELECT 
			PE.esDe_descripcion est_nombre,
			PETR.id_perTra,
			CASE WHEN PETR.id_tramite IN (4, 9, 10, 16) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
			PETR.petr_fechaTramite,
			CASE WHEN PETR.id_tramite = 10 THEN  TRA.tra_nomTramite + ' - ' + (select idFondoFijo from Tramite.fondoFijo where id_perTra = PETR.id_perTra) ELSE TRA.tra_nomTramite END as tra_nomTramite,
			--TRA.tra_nomTramite,
			0 AS id_persona,
			'' AS per_rfc,
			0 AS id_TipoProspecto,
			ESTR.id_estatus
			,PETR.id_tramite,
			PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
			CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
			CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
			CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
		LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea AND tra.id_tramite = frt.idTramite
		INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
		LEFT JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
		LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
		WHERE TRA.id_tramite IN (9) -- Quitar tramite 9 de rol 10 
		AND CASE 
			WHEN  TRA.id_tramite = 9 and  (select min(ISNULL(idSalidaEfectivo,0)) from Tramite.TramiteConcepto where idTramitePersona = PETR.id_perTra) = 1 then 0
			WHEN  TRA.id_tramite IN (9) then 1
			WHEN  PETR.petr_estatus NOT IN ( 3, 4, 5, 6) THEN 1
			END = 1
		AND PETR.petr_estatus NOT IN ( 3, 4, 5, 6)  
				
				) x
			GROUP BY est_nombre,
				id_perTra,
				petr_fechaTramite,
				tra_nomTramite,
				id_estatus,
				id_tramite,
				PER_PERSONA,
				noti,
				notiRevisar,
				notiDocsAprobar

							UNION ALL
			SELECT 
				est_nombre = 'Aprobado'
				,TGM.id_perTra,
				(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
				CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
				T.tra_nomTramite,
				id_persona = 0,
				per_rfc = '',
				id_TipoProspecto = 0,
				ET.id_estatus,
				DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
				T.id_tramite,
				'' as PER_PERSONA, --PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,--'' as PER_PERSONA,
				0 noti,
				0 notiRevisar,
				0 notiDocsAprobar
			FROM [Tramite].[TramiteGastosMas] TGM
			INNER JOIN personaTramite PT ON TGM.id_perTra = PT.id_perTra
			INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
			INNER JOIN estatusTesoreria ET ON ET.id_estatus = TGM.estatus
			LEFT JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = PT.id_persona
			WHERE
				TGM.estatus = 1
				AND T.id_tramite = 15
			ORDER BY id_perTra DESC
	END
ELSE
	BEGIN
		IF(@idArea != 3)
				BEGIN

				
					SELECT 
						est_nombre,
						id_perTra,
						max(nombre) nombre,
						CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
						tra_nomTramite,
						max(id_persona) id_persona,
						max(per_rfc) per_rfc,
						max(id_TipoProspecto) id_TipoProspecto,
						id_estatus,
						DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
						,id_tramite,
						noti,
						notiRevisar,
						notiDocsAprobar
					FROM
					(SELECT 
						ESTR.est_nombre,
						PETR.id_perTra,
						UPPER(PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre)  +' - '+ UPPER(PER.per_rfc)  AS nombre, 
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						PER.id_persona,
						PER.per_rfc,
						PER.id_TipoProspecto,
						ESTR.id_estatus AS id_estatus
						,PETR.id_tramite,
						'' PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
					INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
					WHERE TRA.id_area = @idArea AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) 
					-- CLIENTES
					--AND CASE WHEN PETR.id_tramite IN (3,6,7,8) THEN (
					--	SELECT t.idRol
					--	FROM clientes.DBO.TramiteCliente c
					--	INNER JOIN  [Tramites].[dbo].[rolEstatus] t on t.idEstatus = c.estatus
					--	WHERE tramites_Id = PETR.id_perTra AND  PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) 
					--	AND c.idempresa = ORG.emp_idempresa 
					--	AND c.idsucursal = ORG.suc_idsucursal
					--) END = @idRol

					UNION ALL

					SELECT 
			case when PETR.id_tramite IN (16)  then PE.esDe_descripcion + ' - ' + 
			(select 
			case 
			when ISNULL(MAX(estatusPerTraReembolso),0 ) = 0 and isnull (MAX(estatusReembolso),0) = 0  then 'Finanzas 1'
			when ISNULL(MAX(estatusPerTraReembolso),0 ) = 1 and isnull (MAX(estatusReembolso),0) = 0  then 'Finanzas 2'
			when ISNULL(MAX(estatusPerTraReembolso),0 ) = 2 and isnull (MAX(estatusReembolso),0) = 0  then 'Finanzas 3'
			when ISNULL(MAX(estatusPerTraReembolso),0 ) = 3 and isnull (MAX(estatusReembolso),0) = 0  then 'Tesoreria'
			when MAX(estatusReembolso) = 2 then 'Rechazado' 
			when MAX(estatusReembolso) = 1 then 'Pagado' 
			end	as Estatus	
			from tramites.tramite.valesEvidencia where id_pertraReembolso = PETR.id_perTra and idestatus = 2-- group by id_perTraReembolso, estatusPerTraReembolso, estatusReembolso
			)
			else PE.esDe_descripcion end est_nombre,
						--PE.esDe_descripcion est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite IN (4, 9, 10, 16) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus
						,PETR.id_tramite,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					LEFT JOIN Tramite.FlujoRolTramite frt ON frt.idArea = @idArea AND tra.id_tramite = frt.idTramite
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra
					--WHERE TRA.id_tramite IN (1, 2, 3, 4, 5, 6, 7, 8) AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6,14) AND TD.esDe_IdEstatus IN (2,3) AND ----- SE AGREGO EL ESTATUS 3 para que rol 1 vea su tramite
					--	CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
					--		WHEN frt.idRolSiguiente IS NOT NULL AND PETR.petr_estatus NOT IN (2, 3) and @idArea IN (1, 2) then 1
					--		WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6,9, 10) then 1
					--		END = 1 
					WHERE TRA.id_tramite IN (1, 2, 3, 4, 5, 6, 7, 8,10,16) 
						AND CASE 
						WHEN  TRA.id_tramite in (10)  THEN 1
						WHEN  PETR.petr_estatus NOT IN (2, 3, 4, 5, 6,14) THEN 1
						END = 1
					 AND CASE 
						WHEN  TRA.id_tramite in (10,16)  THEN 1
						WHEN TD.esDe_IdEstatus IN (2,3) THEN 1
						END = 1							
						AND CASE
							WHEN  TRA.id_tramite in (10)  THEN 1
						    WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
							WHEN frt.idRolSiguiente IS NOT NULL AND PETR.petr_estatus NOT IN (2, 3) and @idArea IN (1, 2) then 1
							WHEN  frt.idRolSiguiente IS NULL AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6,9, 10) then 1
							END = 1 
							) x
						GROUP BY est_nombre,
							id_perTra,
							petr_fechaTramite,
							tra_nomTramite,
							id_estatus,
							id_tramite,
							noti,
							notiRevisar,
							notiDocsAprobar
						ORDER BY id_perTra DESC
				END
			ELSE
				BEGIN
				

				IF EXISTS  (select * from Tramite.autorizadoresFondoFijo where idAutorizador = @usuario ) 
				BEGIN
				print 'Usuarios Fondo'
					DECLARE @idTramite INT = 10

					IF EXISTS(select top 1 * from Tramite.cat_Departamentos_Sucursal_FF DS
							inner join [Tramite].[SucursalesXAreasFF] SA on DS.idempresa = SA.idEmpresa
							 where idAutorizador = @usuario and estatusfondos = 1 )
					BEGIN
						SELECT 
						PE.esDe_descripcion est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus,
						DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					INNER JOIN Tramite.cat_Departamentos_Sucursal_FF ORG  ON ORG.idAutorizador = @usuario
					--INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
					LEFT JOIN Tramite.FlujoRolTramite frt
					ON frt.idArea = @idArea
					AND tra.id_tramite = frt.idTramite
					WHERE  
					TD.id_empresa = ORG.idEmpresa 
					AND TD.id_sucursal = ORG.idSucursal
					AND TD.id_departamento = ORG.idDepartamento
					AND CASE WHEN (Select estatusFondoFijo from tramite.fondoFijo where id_perTra = PETR.id_perTra) = 5 THEN 1 
					WHEN PETR.petr_estatus NOT IN (2, 3) THEN 1 END = 1
					AND PETR.id_tramite = @idTramite
					group by est_nombre,
						PETR.id_perTra,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						ESTR.id_estatus,
						PETR.id_persona,
						PETR.id_tramite,
						PE.esDe_descripcion,
						PER.PER_NOMRAZON,
						PER.PER_PATERNO,
						PER.PER_MATERNO,
						DT.cuantos,
						DTR.cuantosRevisar,
						DTA.cuantosAprobados
					union all
					SELECT DISTINCT
								PE.esDe_descripcion est_nombre,
								PETR.id_perTra,
								CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
								CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
								TRA.tra_nomTramite,
								0 AS id_persona,
								'' AS per_rfc,
								0 AS id_TipoProspecto,
								ESTR.id_estatus,
								[petr_fechaTramite], 
								PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
								CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
								CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
								CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
							FROM personaTramite PETR
							INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
							INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
							INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
							INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
							LEFT JOIN Tramite.FlujoRolTramite frt
							ON frt.idArea = @idArea 
							AND tra.id_tramite = frt.idTramite 
							WHERE  CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
									WHEN  frt.idRolSiguiente IS NULL AND  (PETR.petr_estatus NOT IN (2, 3, 4, 5)) THEN 1
									END = 1
							AND TD.id_empresa = ORG.emp_idempresa 
							AND TD.id_sucursal = ORG.suc_idsucursal
							AND PETR.petr_estatus NOT IN (2, 3)
							AND TD.esDe_IdEstatus = 1

					ORDER BY id_perTra DESC
					END
					ELSE
					BEGIN
					print 'usuarios Fondo centralizacion'
					SELECT * FROM (
					SELECT 
						PE.esDe_descripcion est_nombre,
						PETR.id_perTra,
						CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
						CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
						TRA.tra_nomTramite,
						0 AS id_persona,
						'' AS per_rfc,
						0 AS id_TipoProspecto,
						ESTR.id_estatus,
						DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
						PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
						CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
						CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
						CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
					FROM personaTramite PETR
					INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
					INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
					INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
					INNER JOIN Tramite.autorizadoresFondoFijo ORG  ON ORG.idAutorizador = @usuario
					--INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
					INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
					INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
					LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
					LEFT JOIN Tramite.FlujoRolTramite frt
					ON frt.idArea = @idArea
					AND tra.id_tramite = frt.idTramite
					WHERE  
					TD.id_empresa = ORG.idEmpresa 
					AND TD.id_sucursal = ORG.idSucursal
					AND TD.id_departamento = ORG.idDepartamento
					AND CASE WHEN (Select estatusFondoFijo from tramite.fondoFijo where id_perTra = PETR.id_perTra) = 5 THEN 1 
					WHEN PETR.petr_estatus NOT IN (2, 3) THEN 1 END = 1
					AND PETR.id_tramite = @idTramite
					group by est_nombre,
						PETR.id_perTra,
						PETR.petr_fechaTramite,
						TRA.tra_nomTramite,
						ESTR.id_estatus,
						PETR.id_persona,
						PETR.id_tramite,
						PE.esDe_descripcion,
						PER.PER_NOMRAZON,
						PER.PER_PATERNO,
						PER.PER_MATERNO,
						DT.cuantos,
						DTR.cuantosRevisar,
						DTA.cuantosAprobados
					
					UNION ALL
							SELECT DISTINCT
								PE.esDe_descripcion est_nombre,
								PETR.id_perTra,
								CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
								CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
								TRA.tra_nomTramite,
								0 AS id_persona,
								'' AS per_rfc,
								0 AS id_TipoProspecto,
								ESTR.id_estatus,
								[petr_fechaTramite], 
								PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
								CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
								CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
								CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
							FROM personaTramite PETR
							INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
							INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
							INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
							INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
							LEFT JOIN Tramite.FlujoRolTramite frt
							ON frt.idArea = @idArea
							AND tra.id_tramite = frt.idTramite 
							WHERE  CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
									WHEN  frt.idRolSiguiente IS NULL AND  (PETR.petr_estatus NOT IN (2, 3, 4, 5)) THEN 1
									END = 1
							AND TD.id_empresa = ORG.emp_idempresa 
							AND TD.id_sucursal = ORG.suc_idsucursal
							AND PETR.petr_estatus NOT IN (2, 3)
							AND TD.esDe_IdEstatus = 1) AS A
							
							
							ORDER BY A.id_perTra DESC




					END
				END
				--select * from (
				--	SELECT 
				--		PE.esDe_descripcion est_nombre,
				--		PETR.id_perTra,
				--		CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
				--		CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
				--		TRA.tra_nomTramite,
				--		0 AS id_persona,
				--		'' AS per_rfc,
				--		0 AS id_TipoProspecto,
				--		ESTR.id_estatus,
				--		DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
				--		TRA.id_tramite,
				--		PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
				--		CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
				--		CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
				--		CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
				--	FROM personaTramite PETR
				--	INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
				--	INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
				--	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
				--	INNER JOIN Tramite.autorizadoresFondoFijo ORG  ON ORG.idAutorizador = @usuario
				--	--INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
				--	INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
				--	INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
				--	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
				--	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
				--	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
				--	LEFT JOIN Tramite.FlujoRolTramite frt
				--	ON frt.idArea = @idArea
				--	AND tra.id_tramite = frt.idTramite
				--	WHERE  
				--	TD.id_empresa = ORG.idEmpresa 
				--	AND TD.id_sucursal = ORG.idSucursal
				--	AND TD.id_departamento = ORG.idDepartamento
				--	AND CASE WHEN (Select estatusFondoFijo from tramite.fondoFijo where id_perTra = PETR.id_perTra) = 5 THEN 1 
				--	WHEN PETR.petr_estatus NOT IN (2, 3) THEN 1 END = 1
				--	AND PETR.id_tramite = @idTramite
				--	group by est_nombre,
				--		PETR.id_perTra,
				--		PETR.petr_fechaTramite,
				--		TRA.tra_nomTramite,
				--		ESTR.id_estatus,
				--		PETR.id_persona,
				--		PETR.id_tramite,
				--		PE.esDe_descripcion,
				--		PER.PER_NOMRAZON,
				--		PER.PER_PATERNO,
				--		PER.PER_MATERNO,
				--		DT.cuantos,
				--		DTR.cuantosRevisar,
				--		DTA.cuantosAprobados,
				--		TRA.id_tramite
				--	--ORDER BY id_perTra DESC

				--	union all
				--	SELECT 
				--				est_nombre,
				--				id_perTra,
				--				max(nombre) nombre,
				--				CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
				--				tra_nomTramite,
				--				max(id_persona) id_persona,
				--				max(per_rfc) per_rfc,
				--				max(id_TipoProspecto) id_TipoProspecto,
				--				id_estatus,
				--				DATEDIFF(DAY, fecha, GETDATE() ) AS dias
				--				,id_tramite
				--				,PER_PERSONA,
				--				noti,
				--				notiRevisar,
				--				notiDocsAprobar
				--			FROM(
							

				--				SELECT DISTINCT
				--				PE.esDe_descripcion est_nombre,
				--				PETR.id_perTra,
				--				CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
				--				PETR.petr_fechaTramite,
				--				TRA.tra_nomTramite,
				--				0 AS id_persona,
				--				'' AS per_rfc,
				--				0 AS id_TipoProspecto,
				--				ESTR.id_estatus,
				--				[petr_fechaTramite] as fecha, 
				--				PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
				--				TRA.id_tramite,
				--				CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
				--				CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
				--				CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
				--			FROM personaTramite PETR
				--			INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
				--			INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
				--			INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
				--			INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = org.suc_idsucursal
				--			INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
				--			INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
				--			LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
				--			LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
				--			LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
				--			LEFT JOIN Tramite.FlujoRolTramite frt
				--			ON frt.idArea = @idArea
				--			AND tra.id_tramite = frt.idTramite
				--			WHERE  CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
				--					WHEN  frt.idRolSiguiente IS NULL AND  (PETR.petr_estatus NOT IN (2, 3, 4, 5)) THEN 1
				--					END = 1
						
				--			AND PETR.petr_estatus NOT IN (2, 3)
				--			AND TD.esDe_IdEstatus = 1
				--			AND TRA.id_tramite = 4
				--			AND 1= (SELECT top 1 1 from  Tramite.autorizadoresFondoFijo F inner join usuarioRol U on F.idAutorizador = U.idUsuario AND U.idRol = 7 WHERE U.idUsuario = @usuario)
						
				--			 ) x
				--				GROUP BY est_nombre, id_perTra,	petr_fechaTramite, tra_nomTramite, id_estatus, id_tramite, 	noti, notiRevisar, notiDocsAprobar, fecha,PER_PERSONA) AS A
				--				ORDER BY A.id_perTra

					
					
					
					--END
					ELSE
					BEGIN
							PRINT 'usuarios'


							-- inicio se agrega select para usuarios con mas de una area


							SELECT 
								est_nombre,
								id_perTra,
								max(nombre) nombre,
								CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
								tra_nomTramite,
								max(id_persona) id_persona,
								max(per_rfc) per_rfc,
								max(id_TipoProspecto) id_TipoProspecto,
								id_estatus,
								DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
								,id_tramite,
								noti,
								notiRevisar,
								notiDocsAprobar
							FROM
							(SELECT 
								ESTR.est_nombre,
								PETR.id_perTra,
								PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre AS nombre,
								PETR.petr_fechaTramite,
								TRA.tra_nomTramite,
								PER.id_persona,
								PER.per_rfc,
								PER.id_TipoProspecto,
								ESTR.id_estatus AS id_estatus
								,PETR.id_tramite,
								'' PER_PERSONA,
								0 noti,
								0 notiRevisar,
								0 notiDocsAprobar
							FROM personaTramite PETR
							INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
							INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
							inner join UsuariosAreas ua on ua.usu_idusuario =  @usuario
							inner join clientes.dbo.TramiteCliente t on PETR.id_perTra = t.tramites_Id
							WHERE 
							--TRA.id_area = @idArea AND 
							PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) 
							AND T.idEmpresa = ORG.emp_idempresa 
							AND T.idSucursal = ORG.suc_idsucursal
							-- CLIENTES
							--AND CASE WHEN PETR.id_tramite IN (3,6,7,8) THEN (
							--	SELECT t.idRol
							--	FROM clientes.DBO.TramiteCliente c
							--	INNER JOIN  [Tramites].[dbo].[rolEstatus] t on t.idEstatus = c.estatus
							--	WHERE tramites_Id = PETR.id_perTra AND  PETR.petr_estatus NOT IN (2, 3, 4, 5, 6) 
							--	AND c.idempresa = ORG.emp_idempresa 
							--	AND c.idsucursal = ORG.suc_idsucursal
							--) END = @idRol

							UNION ALL

								SELECT DISTINCT
								PE.esDe_descripcion est_nombre,
								PETR.id_perTra,
								CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
								PETR.petr_fechaTramite,
								TRA.tra_nomTramite,
								0 AS id_persona,
								'' AS per_rfc,
								0 AS id_TipoProspecto,
								ESTR.id_estatus,
								[petr_fechaTramite], 
								PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
								CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
								CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
								CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PETR.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
							FROM personaTramite PETR
							INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
							INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
							INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
							INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
							INNER JOIN cat_proceso_estatus PE ON PE.idTipoTramite = TRA.id_tramite AND PE.esDe_IdEstatus = TD.esDe_IdEstatus
							INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PETR.id_perTra
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PETR.id_perTra 
							LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PETR.id_perTra 
							LEFT JOIN Tramite.FlujoRolTramite frt
							ON frt.idArea = @idArea
							AND tra.id_tramite = frt.idTramite 
							WHERE  CASE WHEN frt.idRolSiguiente IS NOT NULL AND TD.esDe_IdEstatus = frt.estatusPasoActual THEN 1
									WHEN  frt.idRolSiguiente IS NULL AND  (PETR.petr_estatus NOT IN (2, 3, 4, 5)) THEN 1
									END = 1
							AND TD.id_empresa = ORG.emp_idempresa 
							AND TD.id_sucursal = ORG.suc_idsucursal
							AND PETR.petr_estatus NOT IN (2, 3)
							AND TD.esDe_IdEstatus = 1

					
							
							 ) x
								GROUP BY est_nombre,
									id_perTra,
									petr_fechaTramite,
									tra_nomTramite,
									id_estatus,
									id_tramite,
									noti,
									notiRevisar,
									notiDocsAprobar
								ORDER BY id_perTra DESC


					
				END
		 END
	END

END
go

