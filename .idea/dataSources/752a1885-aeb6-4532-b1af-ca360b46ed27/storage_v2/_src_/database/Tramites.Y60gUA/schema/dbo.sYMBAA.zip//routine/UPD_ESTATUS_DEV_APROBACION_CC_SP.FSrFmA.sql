-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_DEV_APROBACION_CC_SP]
	@idPerTra INT
AS
BEGIN
	UPDATE tramiteDevoluciones SET trade_banderaCC = 1 WHERE id_perTra = @idPerTra

	SELECT success = 1
END
go

