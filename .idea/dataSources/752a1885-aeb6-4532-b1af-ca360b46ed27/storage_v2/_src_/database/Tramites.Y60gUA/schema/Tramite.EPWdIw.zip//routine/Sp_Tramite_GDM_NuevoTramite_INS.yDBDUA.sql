-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_GDM_NuevoTramite_INS]
	-- Add the parameters for the stored procedure here
	@perTraPadre INT = 1634,
	@idConceptoArhivo INT = 949,
	@importe NUMERIC(18,2) = 250,
	@idTramiteConcepto INT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @idPerTra INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_AnticipoSaldo_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
			--/ Inicia proceso de insercion
			DECLARE @perTra INT = 0;
			DECLARE @idTramiteGastosMas INT = 0;
		
			INSERT INTO [dbo].[personaTramite]
			SELECT [id_persona]
				  ,[id_tramite] = 15
				  ,[petr_fechaTramite] = GETDATE()
				  ,[petr_estatus]
				  ,[petr_observaciones] = 'Entrega de efectivo de gastos de mas'
				  ,[esDe_IdEstatus] = NULL
			FROM [dbo].[personaTramite]
			WHERE id_perTra = @perTraPadre;

			SET @perTra = @@IDENTITY;

			INSERT INTO [Tramite].[TramiteGastosMas]
			SELECT [id_perTra] = @perTra
				  ,[estatus] = 1
				  ,[id_perTraPadre] = @perTraPadre
				  ,[idConceptoArhivo] = @idConceptoArhivo
				  ,[importeDeMas] = @importe
				  ,[fechaRegistro] = GETDATE()
				  ,[fechaSalida] = NULL
				  ,NULL
				  ,NULL
				  ,@idTramiteConcepto

			SET @idTramiteGastosMas = @@IDENTITY;

			SELECT @idTramiteGastosMas idTramiteGastosMas, @perTra id_perTra
			--/ Termina proceso de insercion

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
END
go

