-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <08/08/2019>
-- Description:	<Recupera los anticipos de saldo por usuario>
--TEST Usp_Tramite_AnticipoSaldo_GETByUsuario 1993
-- =============================================
CREATE PROCEDURE [Tramite].[Usp_Tramite_AnticipoSaldo_GetPorUsuario] 
	@idUsuario INT
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	SELECT 
		TD.id_traDe AS [idTramite],
		ET.est_nombre AS [estatus],
		PT.id_perTra AS [idPersona],
		PT.petr_fechaTramite AS [fechaRegistro],
		T.tra_nomTramite AS [tipoTramite],
		T.id_tramite AS [idTipoTramite],
		TD.concepto
	FROM  tramiteDevoluciones TD
	INNER JOIN personaTramite PT ON PT.id_perTra = TD.id_perTra
	INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
	INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
	WHERE PT.id_persona = @idUsuario

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

