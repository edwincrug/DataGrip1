-- =============================================
-- Author:		
-- Create date: 
-- Description:	Actualiza el estatus del document0
-- TEST UPD_APROBAR_ESTATUS_DOCUMENTO_BANCARIO_SP 1
-- =============================================
CREATE PROCEDURE [dbo].[UPD_APROBAR_ESTATUS_DOCUMENTO_BANCARIO_SP] 
	@det_idPerTra INT
AS
BEGIN
	
	DECLARE @aprobados INT = 0
			,@numCuentas INT = 0
	DECLARE @idPerTra INT =  (SELECT id_perTra FROM detallePersonaCuenta WHERE idDetPersonaTramite = @det_idPerTra)
	DECLARE @estatusTesoreria INT = (SELECT petr_estatus from personaTramite where id_perTra = @idPerTra) 
	
	UPDATE detallePersonaCuenta
	SET det_estatus = 2,
	det_observaciobes = ''
	WHERE idDetPersonaTramite = @det_idPerTra;

	if(@estatusTesoreria = 11)
		UPDATE detallePersonaCuenta SET estatusTesoreria = 1 WHERE idDetPersonaTramite = @det_idPerTra;

	SELECT @numCuentas = count(1) from detallePersonaCuenta where id_perTra = @idPerTra 
	SELECT @aprobados =  count(1) from detallePersonaCuenta where id_perTra = @idPerTra AND det_estatus = 2

	IF(@numCuentas = @aprobados)
	BEGIN
		UPDATE  detallePersonaTramite SET det_estatus = 2 where id_perTra = @idPerTra and id_traDo IN (select id_traDo from cat_tramiteDocumento where id_documento = 9)
	END
	

	SELECT success = 1, msg = 'Se aprobo el documento con éxito.'
END
go

