
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP inserta las evidencias de Vales>
-- =============================================
CREATE PROCEDURE [dbo].[INS_VALE_EVIDENCIA_SP] 
	@idVale INT,
	--@idFactura INT = null,
	@tipoGasto INT,
	@idEstatus INT,
	@extension VARCHAR(10),
	@saveUrl VARCHAR(MAX),
	@archivo VARCHAR(MAX),
	@monto NUMERIC(18,4),
	@areaAfectacion VARCHAR(50),
	@conceptoAfectacion VARCHAR(50),
	@numeroCuenta VARCHAR(100),
	@tipoComprobante  VARCHAR(50),
	@tipoIVA  VARCHAR(50),
	@IVA  NUMERIC(18,4),
	@IVAretencion  NUMERIC(18,4),
	@ISRretencion  NUMERIC(18,4),
	@subTotal  NUMERIC(18,4),
	@idComprobacion INT = 0,
	@motivoEvidencia VARCHAR(MAX) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @incremental INT = 0, @nombreVale varchar(100), @idComprobacionVale varchar(100)

	select @incremental =  COUNT(id)  from tramite.valesevidencia where idvales = @idVale
	select @nombreVale = idVale from tramite.vales where id = @idVale
	SET @incremental = @incremental + 1;
	SET @idComprobacionVale = @nombreVale  + '-' + CONVERT(varchar(10), @incremental) 

	BEGIN TRY
	DECLARE @idValeEvidencia INT
	BEGIN TRAN TrnValeIns
	IF NOT EXISTS (SELECT 1 FROM [Tramite].[valesEvidencia] WHERE idVales=@idVale and id = @idComprobacion )
	BEGIN
	INSERT INTO [Tramite].[valesEvidencia] 
	(idVales,
	idestatus,
	archivo,
	extension,
	fechaCreacion,
	url,
	monto,
	idGastoFondoFijo,
	areaAfectacion,
	conceptoAfectacion,
	numeroCuenta,
	tipoComprobante,
	tipoIVA,
	IVA,
	IVAretencion,
	ISRretencion,
	subTotal,
	idComprobacionVale,
	motivo)
	VALUES
	(@idVale,
	@idEstatus,
	@archivo,
	@extension,
	GETDATE(),
	@saveUrl,
	@monto,
	@tipoGasto,
	@areaAfectacion,
	@conceptoAfectacion,
	@numeroCuenta,
	@tipoComprobante,
	@tipoIVA,
	@IVA,
	@IVAretencion,
	@ISRretencion,
	@subTotal,
	@idComprobacionVale,
	@motivoEvidencia)
	SET @idValeEvidencia = SCOPE_IDENTITY()

	--// BI-VE-001 Bitacora para Vale Evidencias
	EXEC [Bitacora].[Sp_Tramite_ValeEvidencia_INS] 'INSERT', '[dbo].[INS_VALE_EVIDENCIA_SP]', @idValeEvidencia
	--// Fin Bitacora para Vale Evidencias

	END
	ELSE
	BEGIN
	UPDATE [Tramite].[valesEvidencia]
	set extension = @extension, archivo = @archivo
	WHERE idVales=@idVale  and id = @idComprobacion
	select @idValeEvidencia = id from [Tramite].[valesEvidencia] WHERE idVales=@idVale  and id = @idComprobacion
	END

	COMMIT TRAN TrnValeIns
IF(@idComprobacion > 0)
BEGIN
SELECT 
1 success,
1 estatus,
'Se inserto correctamente' as msg, 
@saveUrl + '/' +  @archivo  + '.' + @extension as ruta, 
@idValeEvidencia as idValeEvidencia,
ff.id_perTra,
ff.idFondoFijo,
v.idVale,
ve.idComprobacionVale,
ve.monto,
ff.idResponsable,
uf.usu_correo as correoFondo,
uf.usu_nombre + ' ' + uf.usu_paterno + ' ' + uf.usu_materno as usuFondo
FROM tramite.valesEvidencia ve
INNER JOIN tramite.vales v on v.id = ve.idVales
INNER JOIN Tramite.valesFondoFijo vff on vff.idVales = v.id
INNER JOIN Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
INNER JOIN ControlAplicaciones.dbo.cat_usuarios uf on uf.usu_idusuario =  ff.idResponsable
WHERE ve.id = @idComprobacion
END
ELSE
BEGIN
SELECT success = 1, estatus = 1, msg = 'Se inserto correctamente', ruta = @saveUrl + '/' +  @archivo  + '.' + @extension, idValeEvidencia = @idValeEvidencia;
END
	

END TRY
	BEGIN CATCH
		ROLLBACK TRAN TrnValeIns
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END

go

