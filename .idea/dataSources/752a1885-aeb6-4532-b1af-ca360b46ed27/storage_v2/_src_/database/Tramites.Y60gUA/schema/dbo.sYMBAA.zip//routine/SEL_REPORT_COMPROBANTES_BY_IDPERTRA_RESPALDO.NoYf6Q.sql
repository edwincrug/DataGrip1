
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_REPORT_COMPROBANTES_BY_IDPERTRA 149
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORT_COMPROBANTES_BY_IDPERTRA] 
	@id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		
	DECLARE @url varchar(max)
	DECLARE @urlPro VARCHAR(500);
	select @url = pr_descripcion from parametros where pr_identificador = 'GET_SERVER'
	SET @urlPro = 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores';	
	

   SELECT
	isnull(fv.numFactura,e.archivo) AS factura
	,isnull(COALESCE(v.descripcion,'Total'),'') AS concepto
	,isnull(pp.PER_NOMRAZON,'') AS proveedor
	,isnull(convert(varchar(10),e.fechaCreacion,103),'') AS fecha
	,isnull(e.monto,0) AS cantidad
	--,[url] = 'http://localhost:1220'+ SUBSTRING([URL], CHARINDEX('/Image',url),LEN(e.url))+'/'+e.archivo+'.pdf'
	--,[url] = @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id)  + '/' + e.archivo + '.' + e.extension 
	,case when e.idgastoFondoFijo  = 2 then @url + 'FondoFijo/FondoFijo_' +  CONVERT(VARCHAR(20),f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20),v.id)  + '/' + e.archivo + '.' + e.extension 
	else @urlPro + (    	
		SELECT '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4),DATEPART(yyyy,fecha_factura))+  '_'+
			RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,fecha_factura)))),2) +
			'/' + rfc_emisor + 	'_' + case when serie <> '' then serie else '' end + 
			folio + '.pdf'
		FROM 
			Centralizacionv2..PPRO_DATOSFACTURAS 
		WHERE 
			folioorden = FV.ordenCompra) end as [url]
	FROM tramite.valesFondoFijo ff
	JOIN Tramite.fondoFijo f on f.id = ff.idtablafondofijo
	JOIN tramite.vales v ON ff.idVales = v.id
	JOIN Tramite.valesEvidencia e 	ON e.idVales = v.id --AND e.envioReembolso is NULL
	LEFT JOIN tramites.[Tramite].[FacturaVale] fv
	ON e.idfactura = fv.id
	LEFT JOIN GA_Corporativa..PER_PERSONAS pp
	ON fv.PER_IDPERSONA  = pp.PER_IDPERSONA
	WHERE ff.idTablaFondoFijo = @id
	AND v.estatusVale = 4

END
go

