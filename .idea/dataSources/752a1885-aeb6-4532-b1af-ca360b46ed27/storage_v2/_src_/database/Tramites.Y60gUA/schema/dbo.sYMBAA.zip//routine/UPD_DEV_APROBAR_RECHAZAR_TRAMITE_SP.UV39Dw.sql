-- =============================================
-- Author:		Luis Garcia
-- Create date: 17/06/2019
-- Description:	SP que aprueba el tramite

-- TEST [UPD_DEV_APROBAR_RECHAZAR_TRAMITE_SP] 245, 3, ''
-- =============================================
CREATE PROCEDURE [dbo].[UPD_DEV_APROBAR_RECHAZAR_TRAMITE_SP]
	@id_perTra INT,
	@estatus INT,
	@observaciones VARCHAR(500),
	@idUsuario INT = NULL
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY

	DECLARE @idTraDe INT = 0
	
	SELECT 
		@idTraDe = id_traDe 
	FROM tramiteDevoluciones WHERE id_perTra = @id_perTra;

	UPDATE personaTramite
	SET petr_estatus = @estatus,
	petr_observaciones = @observaciones
	WHERE id_perTra = @id_perTra

	UPDATE tramiteDevoluciones
	SET traDe_fechaAutoriza = GETDATE()
	WHERE id_perTra = @id_perTra;

	IF( @estatus = 3 )
		BEGIN
			UPDATE documentosDevueltos SET docDe_valorDev = 0.00 WHERE id_traDe = @idTraDe

			IF(@idUsuario IS NOT NULL)
				BEGIN
					INSERT INTO BitacoraTramite
					SELECT @idUsuario, @id_perTra, 'Se rechaza el trámite de devoluciones', GETDATE(),null
				END
		END
	ELSE
		BEGIN
			IF(@idUsuario IS NOT NULL)
				BEGIN
					INSERT INTO BitacoraTramite
					SELECT @idUsuario, @id_perTra, 'Se aprueba el trámite de devoluciones', GETDATE(), null
				END
		END

	SELECT success = 1;

COMMIT TRANSACTION
END TRY

BEGIN CATCH
ROLLBACK TRANSACTION
	SELECT success = 0;
END CATCH
END
go

