-- =============================================
-- Author:		<Luis García>
-- Create date: <10/07/2019>
-- Description:	<Actualiza la el estaus del detalle del borrador>
-- UPD_DEV_BORRADOR_DETALLE_SP 1849
-- =============================================
CREATE PROCEDURE [dbo].[UPD_DEV_BORRADOR_DETALLE_SP]
	@det_idPerTra INT
AS
BEGIN
	DECLARE @estatusActual INT = (SELECT det_estatus FROM detallePersonaTramite WHERE det_idPerTra = @det_idPerTra);
	
	DECLARE @estatusDevolcuion INT = (SELECT TD.esDe_IdEstatus FROM detallePersonaTramite DPT
									 INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = DPT.id_perTra
									 WHERE det_idPerTra = @det_idPerTra)

	IF(@estatusActual != 2)
		BEGIN
			IF(@estatusDevolcuion IN (3, 4))
				BEGIN
					UPDATE detallePersonaTramite
					SET det_estatus = 2, det_observaciobes = ''
					WHERE det_idPerTra = @det_idPerTra;
					SELECT success = 1;
				END
			ELSE
				BEGIN
					UPDATE detallePersonaTramite
					SET det_estatus = 1, det_observaciobes = ''
					WHERE det_idPerTra = @det_idPerTra;
					SELECT success = 1;
				END
		END
	ELSE
		BEGIN
			SELECT success = 2;
		END
 END
go

