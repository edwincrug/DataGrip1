-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <24/09/2019>
-- Description:	<Obtiene los archivos por concepto>
--TEST EXEC [Tramite].[Sp_Tramite_ArchivoDepartamento_GETLByIdArchivo] 77
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ArchivoDepartamento_GETLByIdArchivo] 
	@idConceptoArchivo INT
AS
BEGIN 

	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	SELECT 
		idArchivoDepartamento
		,idDepartamento
		,porcentaje
		,fechaCreacion
		,idConceptoArchivo
		,COALESCE(CD.dep_nombre, '') AS [departamento]
	FROM [Tramite].[ArchivoDepartamento] AD
	LEFT JOIN ControlAplicaciones.dbo.cat_departamentos CD ON CD.dep_iddepartamento = [AD].[idDepartamento]
	WHERE idConceptoArchivo = @idConceptoArchivo

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

