-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- OBTIENE_INFORMACION_VALES_VENCIDOS
-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_INFORMACION_VALES_VENCIDOS_PRUEBA]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	EXEC [dbo].[OBTIENE_INFORMACION_VALES_VENCIDOS]
END
go

