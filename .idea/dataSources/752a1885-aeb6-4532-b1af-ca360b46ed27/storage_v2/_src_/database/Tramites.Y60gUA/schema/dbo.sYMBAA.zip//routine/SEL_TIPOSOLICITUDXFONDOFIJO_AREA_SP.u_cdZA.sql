-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <03/09/2020>
-- Description:	<Trae todas los departamentos por empresa y sucursal>
--TEST SEL_TIPOSOLICITUDXFONDOFIJO_AREA_SP 18 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOSOLICITUDXFONDOFIJO_AREA_SP]
     @idFondo INT = 0
AS
BEGIN

DECLARE @idEmpresa INT, @idSucursal INT
select @idempresa = idEmpresa, @idsucursal = idSucursal from tramite.fondofijo where id = @idFondo


	SELECT 
	estatusFondos,
	estatusVales
	FROM   [Tramite].[SucursalesXAreasFF]
	WHERE  idEmpresa = @idempresa AND idSucursal = @idsucursal 
END
go

