
-- =============================================
-- Author:		
-- Create date: 
-- Description:	Actualiza el estatus del document0
-- TEST UPD_RECHAZAR_ESTATUS_DOCUMENTO_BANCARIO_SP 110,'
-- select * from detallePersonaCuenta where idDetPersonaTramite = 110
-- =============================================
CREATE PROCEDURE [dbo].[UPD_RECHAZAR_ESTATUS_DOCUMENTO_BANCARIO_SP] 
	@det_idPerTra INT,
	@razonesRechazo VARCHAR(100)
AS
BEGIN
--declare @det_idPerTra INT = 108,
--		@razonesRechazo VARCHAR(100) = 'No se ve bien'
BEGIN TRANSACTION
BEGIN TRY
	DECLARE @aprobados INT = 0
			,@numCuentas INT = 0
			
	DECLARE @idPerTra INT =  (SELECT id_perTra FROM detallePersonaCuenta WHERE idDetPersonaTramite = @det_idPerTra)
	


	UPDATE detallePersonaCuenta
	SET det_estatus = 3,
	det_observaciobes = @razonesRechazo
	WHERE idDetPersonaTramite = @det_idPerTra;

	SELECT @numCuentas = count(1) from detallePersonaCuenta where id_perTra = @idPerTra 
	SELECT @aprobados =  count(1) from detallePersonaCuenta where id_perTra = @idPerTra AND det_estatus = 2

	IF(@numCuentas != @aprobados)
	BEGIN
		UPDATE  detallePersonaTramite SET det_estatus = 3 where id_perTra = @idPerTra and id_traDo IN (select id_traDo from cat_tramiteDocumento where id_documento = 9)
	END

	
				


	SELECT success = 1, msg = 'Se rechazo el documento con éxito.'
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	SELECT success = -1, msg = 'Error al realizar el rechazo.'
END CATCH
--rollback tran
END
go

