-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <11/06/2019>
-- Description:	<Devuelve el estatus en el que se encuentra el tramite>
-- Test SEL_ESTATUS_TRAMITE_SP  2,31,1

-- =============================================
CREATE PROCEDURE [dbo].[SEL_ESTATUS_TRAMITE_SP] 
	@idTramite INT,
	@idProspecto INT,
	@tipoProspecto INT
AS
BEGIN
	--DECLARE @idTramite INT = 2,
	--@idProspecto INT = 31,
	--@tipoProspecto INT= 1
	
	DECLARE @idPersona INT = (SELECT id_persona FROM personas WHERE id_Prospecto = @idProspecto AND id_TipoProspecto = @tipoProspecto)
	DECLARE @estatusTramite  INT 
	DECLARE @estatus VARCHAR(50)
					,@estatusId INT
					,@idPerTra INT

	SELECT @estatusTramite = PETR.petr_estatus , @estatus = est_nombre FROM personaTramite PETR INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus 
				WHERE id_persona = @idPersona AND id_tramite = @idTramite

	IF(@estatusTramite = 3)
	BEGIN
		SELECT success = 3, estatus = @estatus ,   msg = 'Tiene un tramite rechazado puede volver a solicitar', estatusId = @estatusTramite, idPerTra = 0;
	END
	ELSE IF EXISTS (SELECT 1 FROM personaTramite PETR INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus 
				WHERE id_persona = @idPersona AND id_tramite = @idTramite)
		BEGIN
			

			SELECT 
				@estatus = ESTR.est_nombre 
				,@estatusId = ESTR.id_estatus
				,@idPerTra = id_perTra
			FROM personaTramite PETR
			INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
			WHERE id_persona = @idPersona AND id_tramite = @idTramite
			order by id_perTra asc

			SELECT success = 1,  estatus = @estatus , estatusId = @estatusId, idPerTra = @idPerTra;
		END
	ELSE
		BEGIN
			SELECT success = 0,  msg = 'No se encontro ningun estatus para este tramite y persona', estatusId = -1, idPerTra = 0;
		END

END



go

