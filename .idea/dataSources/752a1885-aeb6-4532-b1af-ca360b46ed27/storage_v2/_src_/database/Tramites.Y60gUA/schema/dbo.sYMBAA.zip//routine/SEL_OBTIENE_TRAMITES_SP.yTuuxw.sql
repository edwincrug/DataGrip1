-- =============================================
-- Author:		**********
-- Create date: 11/11/2020
-- Description:	Obtiene todos los tramites sin filtro de área
-- =============================================
-- ============== Versionamiento ================
/*
	Fecha 11/11/2020		Autor: *********** 	 Description:	Obtiene todos los tramites sin filtro de área 

	*- Testing...
	EXEC [dbo].[SEL_OBTIENE_TRAMITES_SP] 
*/
-- =============================================

CREATE PROCEDURE SEL_OBTIENE_TRAMITES_SP 
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		SELECT	id_tramite
				,tra_nomTramite
				,id_area
		FROM	cat_tramites
			
	END TRY

	BEGIN CATCH
		SELECT 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE() AS err;
	END CATCH
END
go

