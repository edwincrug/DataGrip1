

-- =============================================
-- Author:		
-- Create date: 
-- Description:	<Inserta el tramite de devoluciones>
-- =============================================
create PROCEDURE [dbo].[INS_DEV_TRAMITE_BPRO_SP]
@idUsuario INT 
,@observaciones VARCHAR(MAX)
,@idEmpresa INT
,@idSucursal INT 
,@idDepartamento INT = NULL
,@devTotal NUMERIC(18,5)
,@idPersona INT 
,@documento1 VARCHAR(20) 
,@valorDocumento1 DECIMAL(18,2) 
,@carteraDocumento1 VARCHAR(15) 
,@formaPago1 INT					
,@tipoPago1 VARCHAR(10)				
,@documento2 VARCHAR(20)			= NULL
,@valorDocumento2 DECIMAL(18,2)		= NULL
,@carteraDocumento2 VARCHAR(15)		= NULL
,@formaPago2 INT					= NULL
,@tipoPago2 VARCHAR(10)				= NULL
,@documento3 VARCHAR(20)			= NULL
,@valorDocumento3 DECIMAL(18,2)		= NULL
,@carteraDocumento3 VARCHAR(15)		= NULL
,@formaPago3 INT					= NULL
,@tipoPago3 VARCHAR(10)				= NULL
,@documento4 VARCHAR(20)			= NULL
,@valorDocumento4 DECIMAL(18,2)		= NULL
,@carteraDocumento4 VARCHAR(15)		= NULL
,@formaPago4 INT					= NULL
,@tipoPago4 VARCHAR(10)				= NULL
,@documento5 VARCHAR(20)			= NULL
,@valorDocumento5 DECIMAL(18,2)		= NULL
,@carteraDocumento5 VARCHAR(15)		= NULL
,@formaPago5 INT					= NULL
,@tipoPago5 VARCHAR(10)				= NULL
AS
BEGIN
--- 2 NoEfectivo
--- 1 Efectivo
--- 3 Mixto 

BEGIN TRANSACTION
BEGIN TRY

	--DECLARE 	@idUsuario INT = 4599
	--			,@observaciones VARCHAR(MAX)
	--			,@idEmpresa INT = 4
	--			,@idSucursal INT = 7
	--			,@idDepartamento INT
	--			,@devTotal NUMERIC(18,5) = 3100.00000
	--			,@idPersona INT = 67572
	--		--	,@folioCotizacion	VARCHAR(30)  =   
	--			,@documento1 VARCHAR(20) = 'MS000034722'
	--			,@valorDocumento1 DECIMAL(18,2) = 3100.00
	--			,@carteraDocumento1 VARCHAR(15) = 'A41'
	--			,@formaPago1 INT					= 1
	--			,@tipoPago1 VARCHAR(10)				= '01'
	--			,@documento2 VARCHAR(20)			= NULL
	--			,@valorDocumento2 DECIMAL(18,2)		= NULL
	--			,@carteraDocumento2 VARCHAR(15)		= NULL
	--			,@formaPago2 INT					= NULL
	--			,@tipoPago2 VARCHAR(10)				= NULL
	--			,@documento3 VARCHAR(20)			= NULL
	--			,@valorDocumento3 DECIMAL(18,2)		= NULL
	--			,@carteraDocumento3 VARCHAR(15)		= NULL
	--			,@formaPago3 INT					= NULL
	--			,@tipoPago3 VARCHAR(10)				= NULL
	--			,@documento4 VARCHAR(20)			= NULL
	--			,@valorDocumento4 DECIMAL(18,2)		= NULL
	--			,@carteraDocumento4 VARCHAR(15)		= NULL
	--			,@formaPago4 INT					= NULL
	--			,@tipoPago4 VARCHAR(10)				= NULL
	--			,@documento5 VARCHAR(20)			= NULL
	--			,@valorDocumento5 DECIMAL(18,2)		= NULL
	--			,@carteraDocumento5 VARCHAR(15)		= NULL
	--			,@formaPago5 INT					= NULL
	--			,@tipoPago5 VARCHAR(10)				= NULL
				
				



	DECLARE @idPerTra INT = 0
			,@idTraDe INT = 0
			,@tipoDevolucion INT
			
	DECLARE @tblFormaPago AS TABLE(idFormaPago INT)
		


	insert into @tblFormaPago 
	SELECT @formaPago1 union all
	SELECT @formaPago2 union all
	SELECT @formaPago3 union all
	SELECT @formaPago4 union all
	SELECT @formaPago5  

	
	IF EXISTS (SELECT 1 FROM @tblFormaPago WHERE idFormaPago = 1 AND idFormaPago = 2 )
	BEGIN
		SET @tipoDevolucion = 3
	END 
	ELSE 
	BEGIN
		SELECT distinct @tipoDevolucion = idFormaPago  from @tblFormaPago where idFormaPago IS NOT NULL
	END

	--select @tipoDevolucion
	--select  * from personaTramite where id_tramite = 4
	INSERT INTO [dbo].[personaTramite] 
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus])
     VALUES
           (@idUsuario
           ,4
           ,GETDATE()
           ,1)

	SET @idPerTra = SCOPE_IDENTITY()

	--SELECT * FROM [dbo].[personaTramite] WHERE id_perTra = @idPerTra

	INSERT INTO [dbo].[tramiteDevoluciones]
           ([id_perTra]
           ,[id_formaPago]
           ,[id_departamento]
		   ,[traDe_devTotal]
           ,[traDe_Observaciones]
           ,[id_empresa]
           ,[id_sucursal]
		   ,[PER_IDPERSONA]
		   ,[esDe_IdEstatus]
		   ,[cuentaBancaria]
		   ,[numeroCLABE]
		   ,[cveBanxico]
		   ,[tipoCuentaBancaria]
		   ,origenBpro)
     VALUES
           (@idPerTra
           ,@tipoDevolucion
           ,@idDepartamento
		   ,@devTotal
           ,@observaciones
           ,@idEmpresa
           ,@idSucursal
		   ,@idPersona
		   ,2--@esDeIdEstatus
		   ,''--@cuentaBancaria
		   ,''--@numeroCLABE
		   ,''--@cveBanxico
		   ,''--@bancoTipoCuenta
		   ,1
		   )
		SET @idTraDe =  SCOPE_IDENTITY()

		--SELECT * FROM [dbo].[tramiteDevoluciones] WHERE id_perTra = @idPerTra


		/***************************************************************/
		--	INSERTAR DETALLE DOCUMENTOS
		/***************************************************************/
		
		INSERT INTO dbo.documentosDevueltos
		SELECT * FROM (
		SELECT  @idTraDe id_traDe, @documento1 docDe_documento,@valorDocumento1 docDe_valorDev ,1 docDe_estatus,0 docDe_aplicaBPRO,@carteraDocumento1 docDe_cartera,'ANT' docDe_tipoDoc,@tipoPago1 docDe_tipoPago UNION ALL
		SELECT  @idTraDe id_traDe, @documento2 docDe_documento,@valorDocumento2 docDe_valorDev ,1 docDe_estatus,0 docDe_aplicaBPRO,@carteraDocumento2 docDe_cartera,'ANT' docDe_tipoDoc,@tipoPago2 docDe_tipoPago UNION ALL
		SELECT  @idTraDe id_traDe, @documento3 docDe_documento,@valorDocumento3 docDe_valorDev ,1 docDe_estatus,0 docDe_aplicaBPRO,@carteraDocumento3 docDe_cartera,'ANT' docDe_tipoDoc,@tipoPago3 docDe_tipoPago UNION ALL
		SELECT  @idTraDe id_traDe, @documento4 docDe_documento,@valorDocumento4 docDe_valorDev ,1 docDe_estatus,0 docDe_aplicaBPRO,@carteraDocumento4 docDe_cartera,'ANT' docDe_tipoDoc,@tipoPago4 docDe_tipoPago UNION ALL
		SELECT  @idTraDe id_traDe, @documento5 docDe_documento,@valorDocumento5 docDe_valorDev ,1 docDe_estatus,0 docDe_aplicaBPRO,@carteraDocumento5 docDe_cartera,'ANT' docDe_tipoDoc,@tipoPago5 docDe_tipoPago 
				) A where A.docDe_documento IS NOT NULL

		
		insert into Tramites.dbo.detallePersonaTramite 
		SELECT @idPerTra,TD.id_traDo,1,'' from Tramites.dbo.cat_tramiteDocumento	TD 
		INNER JOIN [Centralizacionv2].dbo.[DIG_EXP_DEV_DOCUMENTO] D on TD.id_documento = D.Doc_dev_id
		WHERE TD.id_tramite = 4
				
				


		--select * from dbo.documentosDevueltos where id_traDe = @idTraDe 
		--select * from dbo.detallePersonaTramite where id_perTra = @idPerTra  
		SELECT success = 1, msg = 'Se inserto correctamente el trámite', idPerTra = @idPerTra

COMMIT TRANSACTION
END TRY
BEGIN CATCH
ROLLBACK TRANSACTION
		SELECT success = 0, msg = 'Ocurrio un error al insertar el trámite', idPerTra = @idPerTra
END CATCH


		
END
go

