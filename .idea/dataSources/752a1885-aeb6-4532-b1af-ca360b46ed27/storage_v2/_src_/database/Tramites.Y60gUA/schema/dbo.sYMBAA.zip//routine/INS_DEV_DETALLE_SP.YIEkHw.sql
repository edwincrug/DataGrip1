-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/07/2019>
-- Description:	<Guarda detalle del tramite>
-- =============================================
CREATE PROCEDURE [dbo].[INS_DEV_DETALLE_SP]
	@idDocumento INT,
	@idTramite INT,
	@idPerTra INT
AS
BEGIN

	DECLARE @idTrado INT = (SELECT id_traDo FROM cat_tramiteDocumento WHERE id_documento = @idDocumento AND id_tramite = @idTramite)

	IF( @idTramite = 4 )
		BEGIN
			IF( (SELECT esDe_IdEstatus FROM tramiteDevoluciones WHERE id_perTra = @idPerTra) > 3 )
				BEGIN
					IF NOT EXISTS( SELECT 1 FROM detallePersonaTramite WHERE id_traDo = @idTrado AND id_perTra = @idPerTra )
						BEGIN
							INSERT INTO [dbo].[detallePersonaTramite]
							   ([id_perTra]
							   ,[id_traDo]
							   ,[det_estatus]
							   ,[det_observaciobes])
						 VALUES
							   (@idPerTra
							   ,@idTrado
							   ,2
							   ,'')
						END
				END
			ELSE
				BEGIN
					INSERT INTO [dbo].[detallePersonaTramite]
					   ([id_perTra]
					   ,[id_traDo]
					   ,[det_estatus]
					   ,[det_observaciobes])
				 VALUES
					   (@idPerTra
					   ,@idTrado
					   ,1
					   ,'')
				END
		END
	ELSE
		BEGIN
			INSERT INTO [dbo].[detallePersonaTramite]
					   ([id_perTra]
					   ,[id_traDo]
					   ,[det_estatus]
					   ,[det_observaciobes])
				 VALUES
					   (@idPerTra
					   ,@idTrado
					   ,1
					   ,'')
		END

	SELECT success = 1, msg = 'Se inserto corectamente';
END
go

