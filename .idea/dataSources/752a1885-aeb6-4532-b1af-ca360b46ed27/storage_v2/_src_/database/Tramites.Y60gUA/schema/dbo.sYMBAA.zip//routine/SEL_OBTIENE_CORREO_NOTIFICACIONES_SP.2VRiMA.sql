-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- EXEC SEL_OBTIENE_CORREO_NOTIFICACIONES_SP 14
-- =============================================
create PROCEDURE [dbo].[SEL_OBTIENE_CORREO_NOTIFICACIONES_SP]
	-- Add the parameters for the stored procedure here
	@idTipoNotificacion INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @email NVARCHAR(255)
	,@nombre NVARCHAR(255)

    -- Insert statements for procedure here
	SELECT @nombre = cu.usu_nombre+' '+cu.usu_paterno+' '+ cu.usu_materno
	, @email = cu.usu_correo
	FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT def
	LEFT JOIN ControlAplicaciones.dbo.cat_usuarios cu
	  ON def.usuario_autoriza = cu.usu_idusuario
	WHERE def.idTipoNotificacion = @idTipoNotificacion

	--VERIFICAMOS QUE EL CORRREO TENGA UN FORMATO CORRECTO
	IF (@email like '[a-z,0-9,_,-]%@[a-z,0-9,_,-]%.[a-z][a-z]%'  
		 AND @email NOT like '%@%@%'  
		 AND CHARINDEX('.@',@email) = 0  
		 AND CHARINDEX('..',@email) = 0  
		 AND CHARINDEX(',',@email) = 0  
		 AND RIGHT(@email,1) between 'a' AND 'z'  )
	BEGIN
	   SELECT 1 AS success, @email AS email, @nombre AS nombreUsuarioMail
	END
	ELSE
	BEGIN
	   SELECT 0 AS success, @email AS email, @nombre AS nombreUsuarioMail
	END

END
go

