
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <25/10/2019>
-- Description:	<SP que actualiza el parametro del fondo fijo por empresa y sucursal>
-- [dbo].[UPD_PARAMETROFONDOFIJO_SP]   2953
-- =============================================
CREATE PROCEDURE [dbo].[UPD_PARAMETROFONDOFIJO_SP] 
	@idUsuario INT,
	@porcentaje DECIMAL (18,4)
AS
BEGIN

	DECLARE @idSucursal INT, @idEmpresa INT
	SELECT @idSucursal = suc_idsucursal, @idEmpresa = emp_idempresa FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @idUsuario

	UPDATE  [Tramite].[ParametroFondoFijo]
	SET porcentaje =  @porcentaje
	WHERE idEmpresa = @idEmpresa AND idSucursal = @idSucursal

	SELECT success = 1, msg = 'Se actualizo Correctamente'
END
go

