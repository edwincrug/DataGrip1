
-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <31/01/2020>
-- Description:	<Inserta la poliza>
-- [dbo].[INS_FONDOFIJO_ORDENMASIVA_NOTI_SP] 293,1
-- =============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_ORDENMASIVA_NOTI_SP] 
@idComprobacion INT,
@tipo INT
AS
BEGIN

DECLARE @idusuario INT,
		@idempresa INT,
		@idsucursal INT,
		@id_perTra INT = 0,
		@producto VARCHAR(255),
		@precioUnitario DECIMAL(18,2), 
		@areaAfectacion varchar (50),
		@conceptoContable varchar (50),
		@tipoComprobante varchar (50),
		@observaciones VARCHAR(255),
		@descuento decimal(18,2) = 0,
		@idVale INT,
		@tipoGasto INT,
		@departamento varchar(10)

SELECT 
@idempresa = ff.idEmpresa,
@idsucursal = ff.idSucursal,
@id_perTra = ff.id_perTra,
@producto = ve.idcomprobacionVale,
@precioUnitario = ve.monto,
@tipoGasto  = 	ve.idGastoFondoFijo,
@departamento = d.dep_nombrecto
FROM tramite.valesEvidencia ve
INNER JOIN tramite.vales v on v.id = ve.idVales
INNER JOIN Tramite.valesFondoFijo vff on vff.idVales = v.id
INNER JOIN Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
INNER JOIN ControlAplicaciones.dbo.cat_usuarios uf on uf.usu_idusuario =  ff.idResponsable
INNER JOIN ControlAplicaciones.dbo.cat_usuarios uv on uv.usu_idusuario =  v.idEmpleado
INNER JOIN ControlAplicaciones.dbo.cat_departamentos d on d.dep_iddepartamento = ff.idDepartamento
WHERE ve.id = @idComprobacion

DECLARE @idEncabezado INT, 
		@idDetalle INT,
		@nombreBD VARCHAR(100), 
		@idProveedor INT,  
		@tasaIVA VARCHAR(100) =  '15', 
		--@tasaIVA VARCHAR(100),
		@cantidad INT = 1,
		@tipoIVA   VARCHAR(100),
		@queryIVA NVARCHAR(MAX),
		@tasaIVACal INT,
		@nombreBDSuc VARCHAR(100),
		@porc varchar(50),
		@esFactura INT,
		@fecha DATETIME = GETDATE()
	
--Inicia actualizacion de tipo de Comprobacion
IF(@tipo = 1)
BEGIN
UPDATE tramites.tramite.valesEvidencia SET idestatus = 2, compNoAutorizado = 0 where id = @idComprobacion
END
ELSE
BEGIN
UPDATE tramites.tramite.valesEvidencia SET idestatus = 2, compNoAutorizado = 1 where id = @idComprobacion
END
--Fin actualizacion de tipo de Comprobacion

--Inicia Validacion de lo comprobado
DECLARE @monto DECIMAL(18,4)
select @idVale = VE.idVales, @monto = CASE WHEN FV.idValeEvidencia is null THEN VE.monto ELSE FV.Total END   
from Tramite.valesEvidencia VE
LEFT JOIN [Tramite].[FacturaVale] FV ON FV.idValeEvidencia = VE.id
WHERE VE.id = @idComprobacion

UPDATE Tramite.vales
SET montoJustificado = montoJustificado + @monto, estatusVale = CASE WHEN (montoJustificado + @monto) >= montoSolicitado THEN 4 ELSE estatusVale END
WHERE id = @idVale
--Fin Validacion de lo comprobado

IF (@tipoGasto = 2)
BEGIN
SET @observaciones = 'Comprobacion ' + @producto
select 
@precioUnitario = monto, 
@areaAfectacion = areaAfectacion, 
@conceptoContable = conceptoAfectacion,
@tipoComprobante = tipoComprobante,
@tipoIVA = tipoIVA,
@esFactura = case when idfactura is null then 0 else 1 end
from tramite.valesevidencia 
where idComprobacionVale = @producto

select @nombreBDSuc = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBDSuc+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal INT OUTPUT', @tasaIVACal OUTPUT 

SET @tasaIVA = @tasaIVACal

IF(@tasaIVACal> 0)
BEGIN
	SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACal) 
	SET @precioUnitario = @precioUnitario / @porc
END

IF (@esFactura = 1)
BEGIN 

select 
@idProveedor = fv.PER_IDPERSONA,
@fecha = DATEADD(d,DATEDIFF(d,0,fv.fechaFactura),0)
from tramite.valesevidencia ve
inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.idComprobacionVale = @producto

END
ELSE
BEGIN

SET @idProveedor = 410798
SELECT @fecha = DATEADD(d,DATEDIFF(d,0,fechaCreacion),0)
FROM Tramite.valesEvidencia
WHERE idComprobacionVale = @producto

END


select @nombreBD = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_idempresa = @idempresa
DECLARE @ordenesmasivas NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[cxp_ordenesmasivas]
	([odm_idsucursal]
	,[odm_idproveedor]
	,[odm_areaafectacion]
	,[odm_observaciones]
	,[odm_tipocomprobante]
	,[odm_fechaorden]
	,[odm_fechaaplicacion]
	,[odm_fechaproceso]
	,[odm_estatus]
	,[odm_ordencompra])
	  VALUES
	  ('''+ CONVERT(VARCHAR(10),@idsucursal)+'''
	  ,'''+ CONVERT(VARCHAR(10),@idProveedor)+'''
	  ,'''+@areaAfectacion+'''
	  ,'''+@observaciones+'''
	  ,'''+@tipoComprobante+'''
	  ,'''+ CONVERT(VARCHAR(30),@fecha)+'''
	  ,'''+ CONVERT(VARCHAR(30),@fecha)+'''
	  ,NULL
	  ,0
	  ,NULL)'
exec(@ordenesmasivas)
print @ordenesmasivas
SET @idEncabezado= @@IDENTITY

-- DATEADD(d,DATEDIFF(d,0,GETDATE()),0)
DECLARE @ordenesmasivasDet NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[cxp_ordenesmasivasdet]
	([omd_areaafectacion]
	,[omd_conceptocontable]
	,[omd_cantidad]
	,[omd_producto]
	,[omd_preciounitario]
	,[omd_tasaiva]
	,[omd_descuento]
	,[odm_idordenmasiva])
	  VALUES
	  ( '''+@areaAfectacion+'''
	  ,'''+@conceptoContable+'''
	 ,'''+ CAST(@cantidad AS varchar(10))+'''
	  ,'''+@producto+'''
	  ,'''+ CONVERT(VARCHAR(10),@precioUnitario)+'''
	  ,'''+@tasaIVA+'''
	  ,'''+ CAST(@descuento AS varchar(10))+'''
	  ,'''+ CAST(@idEncabezado AS varchar(10))+''')
'
exec(@ordenesmasivasDet) 
print @ordenesmasivasDet
SET @idDetalle= @@IDENTITY
--select @idEncabezado encabezado,@idDetalle detalle
END
ELSE
BEGIN

DECLARE @CompNoAutorizada INT
select @CompNoAutorizada = compNoAutorizado from tramite.valesEvidencia where id =@idComprobacion
DECLARE @comprobaciones varchar (MAX),
			@SQLAgencia NVARCHAR(MAX),
			@nombreBDConsen varchar (100),
			@nombreBDOperativa varchar (100),
			@comprobado DECIMAL(18,2) = 0

			 SELECT @comprobaciones = STUFF((
			 SELECT ',' + ''''+ ve.idComprobacionVale + ''''
             FROM tramite.vales v 
			 inner join tramite.valesEvidencia ve on v.id = ve.idvales
			 WHERE v.id = @idVale 
             FOR XML PATH('')
			 ),1,1,'')
			 FROM tramite.vales WHERE id = @idVale
	
			select @nombreBDConsen = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_idempresa = @idempresa
			select @nombreBDOperativa = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
			
			SET @SQLAgencia ='SELECT @comprobado = sum(det.VentaUnitario)
				from  ['+@nombreBDOperativa+'].dbo.DSBPDetInfo det
				inner join ['+@nombreBDOperativa+'].dbo.DSBPEncInfo poli on poli.DocumentoOrigen = det.DocumentoOrigen and poli.Proceso = det.proceso and det.Partida = 1
				where det.DocumentoOrigen in ('+@comprobaciones+')
					'		
				print @SQLAgencia
				EXECUTE sp_executeSQL @SQLAgencia, N' @comprobado DECIMAL(18,2) OUTPUT',@comprobado OUTPUT 
				
SET @comprobado = ISNULL(@comprobado,0) + @precioUnitario;	
			
DECLARE @Justifico INT, @JustificoMas DECIMAL(18,2)
select  
@Justifico = case when @comprobado = montoSolicitado then  1 
when @comprobado > montoSolicitado then 1
else 0  end,
@JustificoMas = case when @comprobado > montoSolicitado then @comprobado - montoSolicitado else 0  end
from tramite.vales where idvale = @idVale  and estatusVale in(3,4)


--IF(@Justifico = 0)
--BEGIN
--EXEC  [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP] @idusuario, @idsucursal, 7, @producto, @precioUnitario, '',@departamento, 0,'',''
--END

DECLARE @montoAVFF DECIMAL (18,2)
SET @montoAVFF = @precioUnitario - @JustificoMas
IF(@Justifico = 1 AND @CompNoAutorizada = 0)
BEGIN
 IF(@montoAVFF = 0)
 BEGIN
	EXEC  [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP] @idusuario, @idsucursal, 8, @producto, @JustificoMas, '',@departamento, 0,'',''
 END
 ELSE
 BEGIN
	EXEC  [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP] @idusuario, @idsucursal, 7, @producto, @montoAVFF, '',@departamento, 0,'',''
	EXEC  [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP] @idusuario, @idsucursal, 8, @producto, @JustificoMas, '',@departamento, 0,'',''
 END
END

IF(@Justifico = 1 AND @CompNoAutorizada = 1)
BEGIN
 IF(@montoAVFF = 0)
 BEGIN
	EXEC  [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP] @idusuario, @idsucursal, 8, @producto, @JustificoMas, '',@departamento, 0,'',''
 END
 ELSE
 BEGIN
	EXEC  [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP] @idusuario, @idsucursal, 7, @producto, @montoAVFF, '',@departamento, 0,'',''
	EXEC  [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP] @idusuario, @idsucursal, 8, @producto, @JustificoMas, '',@departamento, 0,'',''
 END
END


END

END
go

