
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <25/10/2019>
-- Description:	<SP que trae el parametro del fondo fijo por empresa y sucursal>
-- [dbo].[SEL_PARAMETROFONDOFIJO_SP]   2953
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PARAMETROFONDOFIJO_SP] 
	@idUsuario INT
AS
BEGIN

	DECLARE @idSucursal INT, @idEmpresa INT
	SELECT @idSucursal = suc_idsucursal, @idEmpresa = emp_idempresa FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @idUsuario

	SELECT 
	porcentaje
	FROM [Tramite].[ParametroFondoFijo]
	WHERE idEmpresa = @idEmpresa AND idSucursal = @idSucursal

END

--
go

