-- Author:		JCPS
-- Create date: 19/03/2020
-- Description: SP Actualiza a autorizado el FF
-- [dbo].[UPD_AUTORIZAFONDOFIJO_SP] 1993
-- =============================================
CREATE PROCEDURE [dbo].[UPD_AUTORIZAFONDOFIJO_SP] 
@id_perTra INT
AS

BEGIN

UPDATE 	Tramite.fondoFijo
SET Autorizado = 1
WHERE id_perTra = @id_perTra

SELECT success = 1
END
go

