-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <28/11/2019>
-- Description:	<SP que trae los datos estatus del tramite de Anticipo Gasto>
-- TEST SEL_ANTICIPOGASTO_ESTATUS_SP
-- =============================================

CREATE PROCEDURE [dbo].[SEL_ANTICIPOGASTO_ESTATUS_SP] 
AS
BEGIN


	SELECT 
		esDe_IdEstatus as idEstatus, 
		esDe_descripcion as descripcion, 
		esDe_icono as  icono 
	FROM cat_proceso_estatus 
	WHERE idTipoTramite = 9
	ORDER BY esDe_IdEstatus ASC

END
go

