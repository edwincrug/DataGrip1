-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [SEL_PARAMETROS_GV_BY_USUARIO] 112010,1,42
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PARAMETROS_GV_BY_USUARIO] 
	-- Add the parameters for the stored procedure here
	@idUsuario INT = 275494, 
	@nacional INT = 1, 
	@concepto INT = 42
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE
  @idNivelJerarquico INT, @idUsuarioCat INT

  --SELECT top 1
  --    @idUsuarioCat = cu.usu_idusuario
  --FROM ControlAplicaciones..cat_usuarios cu
  --WHERE RTRIM(LTRIM(REPLACE(cu.usu_nombre + cu.usu_paterno + cu.usu_materno, ' ', ''))) COLLATE Modern_Spanish_CI_AS IN (SELECT
  --    RTRIM(LTRIM(REPLACE(pp.PER_NOMRAZON + pp.PER_PATERNO + pp.PER_MATERNO, ' ', '')))
  --  FROM GA_Corporativa..PER_PERSONAS pp
  --  WHERE RTRIM(LTRIM(REPLACE(pp.PER_NOMRAZON + pp.PER_PATERNO + pp.PER_MATERNO, ' ', ''))) <> ' MAURICIONAIMSANCHEZMONTELONGO         MAURICIONAIM     SANCHEZMONTELONGO'
  --  AND LEN(RTRIM(LTRIM(REPLACE(pp.PER_NOMRAZON + pp.PER_PATERNO + pp.PER_MATERNO, ' ', '')))) > 0
  --  AND pp.PER_IDPERSONA <> 271187
  --  AND pp.PER_TIPO = 'Fis'
  --  AND pp.PER_IDPERSONA = @idUsuario);

  select @idUsuarioCat = idUsuario
  from usuariosGastosViaje 
  where idPersona = @idUsuario

	print cast(@idUsuarioCat as varchar(10))

   IF EXISTS(
     	SELECT 1
     	FROM Tramites.dbo.CategoriasUsuarios cu
      WHERE cu.idUsuario = @idUsuarioCat
     ) BEGIN
     
         SELECT
           @idNivelJerarquico = cu.idNivelJerarquico
         FROM Tramites.dbo.CategoriasUsuarios cu;

        SELECT
            estatus = 1
           ,mensaje = 'Parametro encontrado'
          ,ccp.id
         ,ccp.idConceptoContable
         ,ccp.distancia
         ,ccp.nacional
         ,ccp.idnivelJerarquico
         ,ccp.montoTope
         ,ccp.fiscal
        FROM Tramites.Tramite.ConceptoContableParametros ccp
          WHERE ccp.nacional = @nacional
          AND ccp.idnivelJerarquico = @idNivelJerarquico
          AND ccp.idConceptoContable = @concepto
     
     END
  ELSE 
    BEGIN
      -- 	SELECT estatus = 0, mensaje='El usuario no ha sido categorizado'
		 SELECT
            estatus = 0
           ,mensaje = 'El usuario no ha sido categorizado, el monto máximo sera el de la categoría mas baja'
          ,ccp.id
         ,ccp.idConceptoContable
         ,ccp.distancia
         ,ccp.nacional
         ,ccp.idnivelJerarquico
         ,ccp.montoTope
         ,ccp.fiscal
        FROM Tramites.Tramite.ConceptoContableParametros ccp
          WHERE ccp.nacional = @nacional
          AND ccp.idnivelJerarquico = 3
          AND ccp.idConceptoContable = @concepto
    END


END
go

