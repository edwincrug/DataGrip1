-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_EMPRESAS_RAZON_SOCIAL 428
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EMPRESAS_RAZON_SOCIAL] 
	@usu_idusuario INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @empresas TABLE(emp_idempresa INT, nombreBase VARCHAR(150), emp_nombre VARCHAR(MAX))
	DECLARE @respuesta TABLE(razon NVARCHAR(255))
	DECLARE @query nvarchar(max) ='', @razon NVARCHAR(150) = ''

	INSERT INTO @empresas(emp_idempresa, nombreBase)
	SELECT DISTINCT
	  contrApp.emp_idempresa AS emp_idempresa
	 --,contrApp.emp_nombre AS emp_nombre
	 , centBases.nombre_base
	FROM [ControlAplicaciones].[dbo].[cat_empresas] contrApp
	INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] centBases
	  ON contrApp.emp_idempresa = centBases.emp_idempresa
	INNER JOIN ControlAplicaciones..ope_organigrama OPE
	  ON OPE.emp_idempresa = contrApp.emp_idempresa
	WHERE contrApp.emp_idempresa != 0
	AND centBases.tipo = 2
	AND OPE.usu_idusuario = @usu_idusuario

	--SELECT emp_idempresa
	--	  ,nombreBase
	--	  ,emp_nombre 
	--  FROM @empresas

	  DECLARE @selEmpresa INT, @selBase VARCHAR(150)
  
	  DECLARE cur CURSOR FAST_FORWARD READ_ONLY LOCAL FOR
	   SELECT
		 emp_idempresa
		,nombreBase
	   FROM @empresas
  
	  OPEN cur
  
	  FETCH NEXT FROM cur INTO @selEmpresa, @selBase
  
	  WHILE @@FETCH_STATUS = 0 BEGIN
  
  	
		SET @query ='
					  SELECT  case when PAR_DESCRIP1  = ''VEHICULOS EUROPEOS DE MONTERREY SA DE CV'' then ''ANDRADE AEROPUERTO S.A DE C.V''
					  else PAR_DESCRIP1 end PAR_DESCRIP1
					  FROM '+ @selBase +'.[dbo].[pnc_parametr] 
					  WHERE PAR_TIPOPARA = ''EM''
					'

		INSERT INTO @respuesta
		EXEC sp_executesql @query

		  SELECT @razon = razon FROM @respuesta

		UPDATE e SET e.emp_nombre = @razon
		  FROM @empresas e
		  WHERE e.emp_idempresa = @selEmpresa

		  DELETE FROM @respuesta

  		FETCH NEXT FROM cur INTO @selEmpresa, @selBase
  
	  END
  
	  CLOSE cur
	  DEALLOCATE cur

	SELECT emp_idempresa
		  ,emp_nombre 
	  FROM @empresas
END
go

