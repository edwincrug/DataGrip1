-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <13/08/2019>
-- Description:	<Recupera el detalle del anticipo de gasto por id>
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_AnticipoGasto_INS] 
	@idUsuario INT,
	@idTramite INT,
	@idFormaPago INT,
	@idDepartamento INT,
	@observaciones VARCHAR(MAX),
	@idEmpresa INT,
	@idSucursal INT,
	@idEstatus INT,
	@devTotal NUMERIC(18,5),
	@idPersona INT,
	@fechaInicio VARCHAR(10),
	@fechaFin VARCHAR(10),
	@concepto VARCHAR(150),
	@motivo VARCHAR(150),
	@nombreCliente VARCHAR(150),
	@cuentaBancaria VARCHAR(20) =  NULL,
	@numeroCLABE VARCHAR(18) = NULL,
	@cveBanxico VARCHAR(5) = NULL,
	@kilometro INT = NULL
AS
BEGIN 

	SET NOCOUNT ON;
	
	DECLARE @idPerTra INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_SolicitudDevolucion_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
		INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus])
		VALUES 
			(@idUsuario
           ,@idTramite
           ,GETDATE()
           ,@idEstatus)
		   
		SET @idPerTra = SCOPE_IDENTITY()
		INSERT INTO [dbo].[tramiteDevoluciones]
           ([id_perTra]
           ,[id_formaPago]
           ,[id_departamento]
		   ,[traDe_devTotal]
           ,[traDe_Observaciones]
           ,[id_empresa]
           ,[id_sucursal]
		   ,[PER_IDPERSONA]
		   ,[esDe_IdEstatus]
		   ,[traDe_fechaInicio]
		   ,[traDe_fechaFin]
		   ,[concepto]
		   ,[motivo]
		   ,[nombreCliente]
		   ,cuentaBancaria
		   ,numeroCLABE
		   ,cveBanxico
		   ,kilometro
		   )
     VALUES
           (@idPerTra
           ,@idFormaPago
           ,@idDepartamento
		   ,@devTotal
           ,@observaciones
           ,@idEmpresa
           ,@idSucursal
		   ,@idPersona
		   ,0
		   ,@fechaInicio
		   ,@fechaFin
		   ,@concepto
		   ,@motivo
		   ,@nombreCliente
		   ,@cuentaBancaria
		   ,@numeroCLABE
		   ,@cveBanxico
		   ,@kilometro)

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @idPerTra AS [resultado]
END
go

