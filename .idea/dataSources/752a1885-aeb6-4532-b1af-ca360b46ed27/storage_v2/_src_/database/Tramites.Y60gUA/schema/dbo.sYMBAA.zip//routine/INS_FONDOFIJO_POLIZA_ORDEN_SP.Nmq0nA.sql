-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <26/02/2020>
-- Description:	<SP que inserta la poliza y genera la orden de compra>
-- [dbo].[INS_FONDOFIJO_POLIZA_ORDEN_SP]  4,6, 'FFOP', 'ZM-NZA-RE-300', 5000
-- =============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_POLIZA_ORDEN_SP] 
   @idempresa INT,
   @idsucursal INT,
   @proceso VARCHAR(100),
   @foliofondo VARCHAR(100),
   @venta decimal(18,2),
   @id_perTra INT = 0
  

AS
BEGIN
 DECLARE @persona1  INT , -- parametro que me van a pasar 471
		 @nombreBD VARCHAR(100),
		 @tipoProducto VARCHAR(100) = 'FONFIJ',
		 @origen VARCHAR(10) = 'FF',
		 @moneda VARCHAR(10) = 'PE',
		 @Query NVARCHAR(MAX),
		 @id INT,
		 @value INT

select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal

IF(@proceso = 'FFOP' or @proceso = 'FFCE' or @proceso = 'FFCS' or @proceso = 'DFFD' or @proceso =  'DFFC' or @proceso = 'RFOP' or @proceso = 'RFCE' or @proceso = 'RFCS' or @proceso = 'GVCE' or @proceso = 'GVCS')
BEGIN
SET @Query ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
EXECUTE sp_executeSQL @Query, N'@persona1 INT OUTPUT', @persona1 OUTPUT
END

IF(@proceso = 'PVFF' or @proceso = 'CVFM' or  @proceso = 'CVFD')
BEGIN
select @persona1 = PER_IDPERSONA from tramite.vales where idvale = @foliofondo
END

IF(@proceso = 'AVFF' or @proceso = 'CVFR' or @proceso = 'CVFN')
BEGIN
select @persona1 = td.PER_IDPERSONA from tramite.vales v
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where v.idvale =@foliofondo
END

IF(@proceso = 'GVOP' or  @proceso = 'GVTE' or @proceso = 'AGVV' or @proceso = 'CGFR' or @proceso = 'CGFN' or @proceso = 'CGFM' or @proceso = 'CGFC' or @proceso = 'CGFD')
BEGIN
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END



INSERT INTO [cuentasxpagar].[dbo].[cxp_fondosfijos] 
            ([gff_idempresa],[gff_idsucursal],[gff_proceso],[gff_documento],[gff_tipoproducto], [gff_origen], [gff_tipocambio], [gff_cantidad],
			[gff_costounitario], [gff_ventaunitario], [gff_descuentounitario], [gff_tasaiva], [gff_iva], [gff_persona1], [gff_persona2],
			[gff_fechasolicitud], [gff_estatus], [gff_fechaproceso], [gff_ordencompra], [gff_moneda])
VALUES      (@idempresa, @idsucursal, @proceso, @foliofondo, @tipoProducto, @origen, 1, 1, 0, @venta, 0, 0, 0, @persona1, 0, GETDATE(), 1, NULL, NULL, @moneda)

SET @id = @@IDENTITY

EXEC @value = [cuentasxpagar].[dbo].[sp_fondosfijos] @id


END


go

