
-- =============================================
-- Author:		<JCPS>
-- Create date: <28/04/2020>
-- Description:	<Recupera el revisor de la comprobacion>
--TEST EXEC [Tramite].[Sp_Tramite_RevisorComprobacion] 
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_RevisorComprobacion] 

AS
BEGIN 
DECLARE @idusuario INT, @correo varchar(100), @nombreUsuario varchar(max)

select top 1 @idusuario = idUsuario from usuarioRol where idRol = 12

--Se actualiza el usuario a Maria Chena debe ser uno por empresa, se debe bajar al nivel de agencia/sucursal
select @correo = usu_correo, @nombreUsuario = usu_nombre + ' ' + usu_paterno + ' ' + usu_materno from ControlAplicaciones..cat_usuarios where usu_idusuario = 2166 --@idusuario

select  @nombreUsuario as nombreUsuario,  @correo as correoAutorizador, 'Autorizar la comprobación de Anticipo de Gastos' as asunto

END



go

