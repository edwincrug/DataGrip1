CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_CLIENTE_SP]
@idCliente INT 
,@idEmpresa INT 
,@idSucursal INT 
,@tipo INT 
,@idPerTra INT 

AS
BEGIN
--DECLARE @idCliente INT = 489091,
--		@idEmpresa INT = 3,
--		@idSucursal INT = 5,
--		@tipo INT = 1,
--		@idPerTra INT = 2866

	IF(@idPerTra > 0)
	BEGIN
		-- identificar la fecha del tramite
		IF EXISTS(select 1 from personaTramite WHERE id_tramite = 4 AND id_perTra = @idPerTra AND petr_fechaTramite < CONVERT(DATETIME,'04-07-2020',103) OR @idPerTra in ( 2689,2866)  )
		BEGIN
			Print 'Viejo'
			EXEC [dbo].[SEL_DOCUMENTOS_CLIENTE_ANT_SP] @idCliente, @idEmpresa, @idSucursal, @tipo, @idPerTra
		END
		ELSE
		BEGIN
			Print 'Nuevo'
			EXEC [dbo].[SEL_DOCUMENTOS_CLIENTE_ORIGEN_PAGO_SP] @idCliente, @idEmpresa, @idSucursal, @tipo, @idPerTra
		END
	END
	ELSE
	BEGIN
			Print 'Nuevo 0'
			EXEC [dbo].[SEL_DOCUMENTOS_CLIENTE_ORIGEN_PAGO_SP] @idCliente, @idEmpresa, @idSucursal, @tipo, @idPerTra
	END
END

go

