
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <03/12/2019>
-- Description:	<SP que actualizar el concepto>
--  [dbo].[UPD_CONCEPTO_SP]   85
-- =============================================
CREATE  PROCEDURE [dbo].[UPD_TRAMITECONCEPTO_SP] 
	@idTramiteConcepto INT
AS
BEGIN
	--3 rechazado
	UPDATE Tramite.TramiteConcepto 
	SET idEstatus = 3
	WHERE idTramiteConcepto = @idTramiteConcepto

	SELECT success = 1, msg = 'Se actualizo correctamente';

END
go

