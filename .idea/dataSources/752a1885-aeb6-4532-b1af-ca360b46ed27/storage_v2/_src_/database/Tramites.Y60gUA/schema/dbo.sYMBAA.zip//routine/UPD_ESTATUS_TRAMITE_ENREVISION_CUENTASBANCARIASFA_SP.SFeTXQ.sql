

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <17/10/2019>
-- Description:	<Actualiza el estatus del tramitye de las cuentas bancarias>
/*
	Modificacion: se Agrega el ELSE IF  para el id tramite 11 que es tranferencias
*/
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_TRAMITE_ENREVISION_CUENTASBANCARIASFA_SP]
	@idPerTra INT,
	@tipo INT,
	@consecutivo INT
AS
BEGIN
	DECLARE  @idEstatus INT;
	SELECT 
		@idEstatus = estatus
	FROM cuentasTesoreriaFA
	WHERE id_perTra = @idPerTra and tipo = @tipo and consecutivo = @consecutivo

	--SE agrega para identificar el tramite
	DECLARE  @id_tramite INT;
	SELECT @id_tramite = PT.id_tramite
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	WHERE PT.id_perTra = @idPerTra

	IF(@idEstatus = 0)
		BEGIN
			UPDATE cuentasTesoreriaFA SET estatus = 1 WHERE id_perTra = @idPerTra and tipo = @tipo and consecutivo = @consecutivo

		END

		IF( (SELECT id_tipoTramite FROM cuentasTesoreriaFA WHERE id_perTra = @idPerTra and tipo = @tipo and consecutivo = @consecutivo) = 3 OR (SELECT id_tipoTramite FROM cuentasTesoreriaFA WHERE id_perTra = @idPerTra and tipo = @tipo and consecutivo = @consecutivo) = 2 )
			BEGIN
				SELECT success = 1, urlAprobar = CASE WHEN @id_tramite = 10 THEN '/aprobarFondoFijo' 
													  WHEN @id_tramite = 9 THEN '/aprobarAnticipoGasto' END;
			END
		ELSE IF ( (SELECT id_tipoTramite FROM cuentasTesoreriaFA WHERE id_perTra = @idPerTra and tipo = @tipo and consecutivo = @consecutivo ) = 1 )
			BEGIN
				SELECT success = 1, urlAprobar = '/comprarOrdenFFAG';
			END
END
go

