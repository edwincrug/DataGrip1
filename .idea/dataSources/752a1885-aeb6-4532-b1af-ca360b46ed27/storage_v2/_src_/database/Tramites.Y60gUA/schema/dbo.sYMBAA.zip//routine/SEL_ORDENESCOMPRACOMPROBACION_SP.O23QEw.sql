


-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [dbo].[SEL_ORDENESCOMPRACOMPROBACION_SP]  308119, 4,6, 30
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ORDENESCOMPRACOMPROBACION_SP] 
	@idProveedor INT,
	@idEmpresa INT,
	@idSucursal INT,
	@idDepartamento INT
AS
BEGIN



DECLARE @nomCorto VARCHAR (10)

select @nomCorto = dep_nombrecto from ControlAplicaciones.dbo.cat_departamentos where dep_iddepartamento = @idDepartamento

IF(@nomCorto = 'OT')
BEGIN
--Ordenes que vienen del cotizador Universal
select distinct
oce_idproveedor,
sod_idsituacionorden,
oce_folioorden as orden,
oce_iddepartamento,
p.PER_NOMRAZON as nombreProveedor
from cuentasxpagar.dbo.cxp_ordencompra o
inner join GA_Corporativa.dbo.PER_PERSONAS p on p.PER_IDPERSONA = o.oce_idproveedor
inner join cuentasporcobrar.dbo.uni_anticiposweb aw on   aw.UAW_FOLIOORDENCOMPRAOT COLLATE Modern_Spanish_CI_AS = o.oce_folioorden
where  
sod_idsituacionorden in (6,7,8,10) 
and oce_idproveedor = @idProveedor   
and oce_idempresa = @idEmpresa
and oce_idsucursal = @idSucursal
and oce_iddepartamento = @idDepartamento

END
ELSE
BEGIN
--Ordenes normales
select 
oce_idproveedor,
sod_idsituacionorden,
oce_folioorden as orden,
oce_iddepartamento,
p.PER_NOMRAZON as nombreProveedor
from cuentasxpagar.dbo.cxp_ordencompra o
inner join GA_Corporativa.dbo.PER_PERSONAS p on p.PER_IDPERSONA = o.oce_idproveedor
where  
sod_idsituacionorden in (6,7,8,10) 
and oce_idproveedor = @idProveedor   
and oce_idempresa = @idEmpresa
and oce_idsucursal = @idSucursal
and oce_iddepartamento = @idDepartamento

END


--select 
--oce_idproveedor,
--sod_idsituacionorden,
--oce_folioorden as orden,
--oce_iddepartamento,
--p.PER_NOMRAZON as nombreProveedor
--from cuentasxpagar.dbo.cxp_ordencompra o
--inner join GA_Corporativa.dbo.PER_PERSONAS p on p.PER_IDPERSONA = o.oce_idproveedor
--where  
--sod_idsituacionorden in (6,7,8,10) 
--and oce_idproveedor = @idProveedor   
--and oce_idempresa = @idEmpresa
--and oce_idsucursal = @idSucursal
--and oce_iddepartamento = @idDepartamento

END
go

