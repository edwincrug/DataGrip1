 

-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <09/07/2019>
-- Description:	<Trae los documentos que éxisten y los que no éxisten>
--TEST SEL_DEV_DOCUMENTOS_BORRADOR_SP 'localhost', 3484, 4
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEV_DOCUMENTOS_BORRADOR_SP]
	@urlParam VARCHAR(30),
	@idPerTra INT,
	@idTramite INT
AS
BEGIN
	--DECLARE @urlParam VARCHAR(30) = 'localhost',
	--@idPerTra INT = 3484,
	--@idTramite INT = 4



	DECLARE @url VARCHAR(500)
			,@urlCentral VARCHAR(500)
			,@origenBpro BIT
			,@idSucursal INT
			,@bdSucursal VARCHAR(50)
			,@SQLString NVARCHAR(MAX)
			,@sqlUni VARCHAR(MAX)
			,@ParmDefinition nvarchar(500) 
			,@folioCotizacion VARCHAR(30) =''
	
	
	
	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam);
		END
	ELSE
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');		
		END

	select @origenBpro = origenBpro, @idSucursal = id_sucursal from tramiteDevoluciones WHERE id_perTra = @idPerTra
	SET @urlCentral = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GA_CENTRAL')	
	
	if(@origenBpro = 1)
	BEGIN
		select @bdSucursal = nombre_base from Centralizacionv2.dbo.DIG_CAT_BASES_BPRO where suc_idsucursal = @idSucursal and tipo = 1
	

		SET @SQLString = ' SELECT TOP 1 @folio = CU.ucu_foliocotizacion
							FROM '+ @bdSucursal+'.dbo.CXC_PAGANT P
							inner join documentosDevueltos DD ON  DD.docDe_documento  = P.PAM_IDDOCTO COLLATE DATABASE_DEFAULT
							inner join tramiteDevoluciones D ON D.id_traDe = DD.id_traDe
							inner join cuentasporcobrar.dbo.uni_cotizacionuniversal CU ON CU.ucu_idcotizacion = P.PAM_IDCOTIZACIONWEB
							where D.id_perTra = '+ CONVERT(VARCHAR(10),@idPerTra)
								
	
	
		
		SET @ParmDefinition = N' @folio  VARCHAR(30) OUTPUT';

		EXECUTE sp_executesql @SQLString, @ParmDefinition, @folio= @folioCotizacion OUTPUT

		
	END



	DECLARE @saveUrl VARCHAR(100) = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC');

	SELECT	
		id_tramite
		,id_perTra
		,doc_nomDocumento
		,A.ext_nombre
		,A.id_traDo
		,id_documento
		,isnull(existe,0) existe
		,isnull(det_observaciobes,'') Observaciones 
		,det_estatus estatusDocumento 
		,petr_estatus estatusTramite
		,A.doc_infoAdicional
		,A.doc_expira

		,CASE WHEN docExp is not null AND @origenBpro = 1 THEN @urlCentral+@folioCotizacion+'/'+CONVERT(VARCHAR(10),Doc_id)+'.pdf' ELSE @url +'Devoluciones/' + 'Devolucion_' + CONVERT(VARCHAR(20),id_perTra) + '/Documento_' + CONVERT(VARCHAR(10),id_documento)+'.'+A.ext_nombre  END [url]
		--,@url +'Devoluciones/' + 'Devolucion_' + CONVERT(VARCHAR(20),id_perTra) + '/Documento_' + CONVERT(VARCHAR(10),id_documento)+'.'+A.ext_nombre [url]	
		,A.id_extension AS idExtension
		,B.det_idPerTra
		,@saveUrl saveUrl
		,A.opcional
		,docExp
		,Doc_id
	FROM (SELECT 
		T.id_tramite, 
		doc_nomDocumento, 
		TD.id_traDo,
		TD.id_documento, 
		EXT.ext_nombre ,  
		DOC.doc_infoAdicional, 
		doc_expira,
		EXT.id_extension,
		DOC.opcional,
		D.idDocumento docExp,
		Doc_id

	FROM cat_tramites T
	INNER JOIN cat_tramiteDocumento TD ON TD.id_tramite = T.id_tramite
	INNER JOIN cat_documentos DOC ON DOC.id_documento = TD.id_documento
	INNER JOIN cat_extensiones EXT ON EXT.id_extension = DOC.id_extension
	LEFT JOIN Centralizacionv2.[dbo].[DIG_EXP_DEV_DOCUMENTO] D on DOC.id_documento = D.Doc_dev_id
	WHERE T.id_tramite = @idTramite AND DOC.id_documento <> 65 ) AS A LEFT JOIN
	(

	SELECT	id_tramite existe
			,DPT.id_traDo
			,DPT.det_observaciobes
			,det_estatus,petr_estatus
			,PT.id_perTra
			,DPT.det_idPerTra
	FROM  [personaTramite] PT
	INNER JOIN  [dbo].[detallePersonaTramite] DPT ON DPT.id_perTra = PT.id_perTra
	WHERE PT.id_perTra = @idPerTra ) AS B ON B.Existe = A.id_tramite AND B.id_traDo = A.id_traDo
END


go

