-- =============================================
-- Author:		
-- Create date: 
-- Description:	
--TEST EXEC [Tramite].[Sp_Tramite_GDM_SalidaEfectivoEstatus_UPD] 1748
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_GDM_SalidaEfectivoEstatus_UPD] 
	@perTra INT = 0,
	@idTramiteTransferencia INT = 0,
	@idCuenta INT = 0
AS
BEGIN 

SET NOCOUNT ON;
	
	DECLARE @resultado INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_GDM_SalidaEfectivoEstatus_UPD] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite

		IF( @idTramiteTransferencia = 0)
			BEGIN
				UPDATE 
					Tramite.TramiteGastosMas
				SET 
					estatus = 2
				WHERE 
					id_perTra = @perTra;
			END
		ELSE
			BEGIN
				UPDATE 
					Tramite.TramiteGastosMas
				SET 
					estatus = 2,
					idTramiteTransferencia = @idTramiteTransferencia
				WHERE 
					id_perTra = @perTra;
			END

		IF( @idCuenta != 0)
			BEGIN
				UPDATE 
					Tramite.TramiteGastosMas
				SET 
					id_cuenta = @idCuenta
				WHERE 
					id_perTra = @perTra;
			END

		   
		SET @resultado = 1;

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH
	SET NOCOUNT OFF
	
	SELECT @resultado AS [resultado]

END
go

