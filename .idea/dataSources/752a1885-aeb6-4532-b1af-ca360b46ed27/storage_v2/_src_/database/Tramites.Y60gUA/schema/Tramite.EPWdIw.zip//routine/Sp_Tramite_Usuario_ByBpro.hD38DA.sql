-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Tramite].[Sp_Tramite_Usuario_ByBpro] 109762
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_Usuario_ByBpro]
	-- Add the parameters for the stored procedure here
	@IdPersona INT  = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @nombreUsuario varchar (255), @paterno varchar (255), @materno varchar (255);

	SELECT @nombreUsuario = PER_NOMRAZON, @paterno = PER_PATERNO, @materno = PER_MATERNO FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @IdPersona AND PER_TIPO = 'FIS' AND  PER_STATUS = 'ACTIVO';
	SELECT usu_idusuario FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombre  LIKE ('%' + @nombreUsuario + '%') AND usu_paterno LIKE ('%' + @paterno + '%') AND usu_materno LIKE ('%' + @materno + '%');
END
go

