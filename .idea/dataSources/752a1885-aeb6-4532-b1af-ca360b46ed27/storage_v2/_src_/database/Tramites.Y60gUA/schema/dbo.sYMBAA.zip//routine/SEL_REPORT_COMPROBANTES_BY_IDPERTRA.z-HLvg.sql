-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_REPORT_COMPROBANTES_BY_IDPERTRA 16
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORT_COMPROBANTES_BY_IDPERTRA] 
	@id int
	, @tipo INT = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @url varchar(max)
	DECLARE @urlPro VARCHAR(500);
	select @url = pr_descripcion from parametros where pr_identificador = 'GET_SERVER'
	SET @urlPro = 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores';	

	IF(@tipo = 1)
  BEGIN
  
   SELECT DISTINCT
     ISNULL(fv.numFactura, e.archivo) AS factura
    ,ISNULL(COALESCE(v.descripcion, 'Total'), '') AS concepto
    ,ISNULL(pp.PER_NOMRAZON, '') AS proveedor
    ,ISNULL(CONVERT(VARCHAR(10), e.fechaCreacion, 103), '') AS fecha
    ,ISNULL(e.monto, 0) AS cantidad 
    ,CASE
       WHEN e.idgastoFondoFijo = 2 THEN @url + 'FondoFijo/FondoFijo_' + CONVERT(VARCHAR(20), f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), v.id) + '/' + e.archivo + '.' + e.extension
       ELSE @urlPro + (SELECT
             '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4), DATEPART(yyyy, fecha_factura)) + '_' +
             RIGHT('00' + LTRIM(RTRIM(CONVERT(VARCHAR(2), DATEPART(mm, fecha_factura)))), 2) +
             '/' + rfc_emisor + '_' +
             CASE
               WHEN serie <> '' THEN serie
               ELSE ''
             END +
             folio + '.pdf'
           FROM Centralizacionv2..PPRO_DATOSFACTURAS
           WHERE folioorden = FV.ordenCompra)
     END AS [url]
   FROM tramite.valesFondoFijo ff
   JOIN Tramite.fondoFijo f
     ON f.id = ff.idtablafondofijo
   JOIN tramite.vales v
     ON ff.idVales = v.id
   JOIN Tramite.valesEvidencia e
     ON e.idVales = v.id
     AND ISNULL(e.envioReembolso,0) = 0
      AND e.procesoPoliza = 1
   LEFT JOIN tramites.[Tramite].[FacturaVale] fv
     ON e.idfactura = fv.id
   LEFT JOIN GA_Corporativa..PER_PERSONAS pp
     ON fv.PER_IDPERSONA = pp.PER_IDPERSONA
   WHERE ff.idTablaFondoFijo = @id
  -- AND v.estatusVale = 4
  END
ELSE IF(@tipo = 2)
  BEGIN
  
   SELECT
     ISNULL(fv.numFactura, e.archivo) AS factura
    ,ISNULL(COALESCE(v.descripcion, 'Total'), '') AS concepto
    ,ISNULL(pp.PER_NOMRAZON, '') AS proveedor
    ,ISNULL(CONVERT(VARCHAR(10), e.fechaCreacion, 103), '') AS fecha
    ,ISNULL(e.monto, 0) AS cantidad
    ,CASE
       WHEN e.idgastoFondoFijo = 2 THEN @url + 'FondoFijo/FondoFijo_' + CONVERT(VARCHAR(20), f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), v.id) + '/' + e.archivo + '.' + e.extension
       ELSE @urlPro + (SELECT
             '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4), DATEPART(yyyy, fecha_factura)) + '_' +
             RIGHT('00' + LTRIM(RTRIM(CONVERT(VARCHAR(2), DATEPART(mm, fecha_factura)))), 2) +
             '/' + rfc_emisor + '_' +
             CASE
               WHEN serie <> '' THEN serie
               ELSE ''
             END +
             folio + '.pdf'
           FROM Centralizacionv2..PPRO_DATOSFACTURAS
           WHERE folioorden = FV.ordenCompra)
     END AS [url]
   FROM tramite.valesFondoFijo ff
   JOIN Tramite.fondoFijo f
     ON f.id = ff.idtablafondofijo
   JOIN tramite.vales v
     ON ff.idVales = v.id
   JOIN Tramite.valesEvidencia e
     ON e.idVales = v.id
    AND e.envioReembolso = 1
    AND e.estatusReembolso IS NULL 
    AND e.procesoPoliza = 1
   LEFT JOIN tramites.[Tramite].[FacturaVale] fv
     ON e.idfactura = fv.id
   LEFT JOIN GA_Corporativa..PER_PERSONAS pp
     ON fv.PER_IDPERSONA = pp.PER_IDPERSONA
   WHERE ff.idTablaFondoFijo = @id
   --AND v.estatusVale = 4
  END
ELSE IF(@tipo = 3)
  BEGIN
    
   SELECT
     ISNULL(fv.numFactura, e.archivo) AS factura
    ,ISNULL(COALESCE(v.descripcion, 'Total'), '') AS concepto
    ,ISNULL(pp.PER_NOMRAZON, '') AS proveedor
    ,ISNULL(CONVERT(VARCHAR(10), e.fechaCreacion, 103), '') AS fecha
    ,ISNULL(e.monto, 0) AS cantidad
     ,CASE
       WHEN e.idgastoFondoFijo = 2 THEN @url + 'FondoFijo/FondoFijo_' + CONVERT(VARCHAR(20), f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), v.id) + '/' + e.archivo + '.' + e.extension
       ELSE @urlPro + (SELECT
             '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4), DATEPART(yyyy, fecha_factura)) + '_' +
             RIGHT('00' + LTRIM(RTRIM(CONVERT(VARCHAR(2), DATEPART(mm, fecha_factura)))), 2) +
             '/' + rfc_emisor + '_' +
             CASE
               WHEN serie <> '' THEN serie
               ELSE ''
             END +
             folio + '.pdf'
           FROM Centralizacionv2..PPRO_DATOSFACTURAS
           WHERE folioorden = FV.ordenCompra)
     END AS [url]
   FROM tramite.valesFondoFijo ff
   JOIN Tramite.fondoFijo f
     ON f.id = ff.idtablafondofijo
   JOIN tramite.vales v
     ON ff.idVales = v.id
   JOIN Tramite.valesEvidencia e
     ON e.idVales = v.id
    AND e.envioReembolso = 1
    AND e.estatusReembolso = 1
    AND e.procesoPoliza = 1
   LEFT JOIN tramites.[Tramite].[FacturaVale] fv
     ON e.idfactura = fv.id
   LEFT JOIN GA_Corporativa..PER_PERSONAS pp
     ON fv.PER_IDPERSONA = pp.PER_IDPERSONA
   WHERE ff.idTablaFondoFijo = @id
   --AND v.estatusVale = 4
  END
ELSE IF(@tipo = 4)
  BEGIN
   SELECT
     ISNULL(fv.numFactura, e.archivo) AS factura
    ,ISNULL(COALESCE(v.descripcion, 'Total'), '') AS concepto
    ,ISNULL(pp.PER_NOMRAZON, '') AS proveedor
    ,ISNULL(CONVERT(VARCHAR(10), e.fechaCreacion, 103), '') AS fecha
    ,ISNULL(e.monto, 0) AS cantidad
    ,CASE
       WHEN e.idgastoFondoFijo = 2 THEN @url + 'FondoFijo/FondoFijo_' + CONVERT(VARCHAR(20), f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), v.id) + '/' + e.archivo + '.' + e.extension
       ELSE @urlPro + (SELECT
             '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4), DATEPART(yyyy, fecha_factura)) + '_' +
             RIGHT('00' + LTRIM(RTRIM(CONVERT(VARCHAR(2), DATEPART(mm, fecha_factura)))), 2) +
             '/' + rfc_emisor + '_' +
             CASE
               WHEN serie <> '' THEN serie
               ELSE ''
             END +
             folio + '.pdf'
           FROM Centralizacionv2..PPRO_DATOSFACTURAS
           WHERE folioorden = FV.ordenCompra)
     END AS [url]
   FROM tramite.valesFondoFijo ff
   JOIN Tramite.fondoFijo f
     ON f.id = ff.idtablafondofijo
   JOIN tramite.vales v
     ON ff.idVales = v.id
   JOIN Tramite.valesEvidencia e
     ON e.idVales = v.id
       AND e.envioReembolso = 1
       AND e.estatusReembolso = 2
       AND e.procesoPoliza = 1
   LEFT JOIN tramites.[Tramite].[FacturaVale] fv
     ON e.idfactura = fv.id
   LEFT JOIN GA_Corporativa..PER_PERSONAS pp
     ON fv.PER_IDPERSONA = pp.PER_IDPERSONA
   WHERE ff.idTablaFondoFijo = @id
   --AND v.estatusVale = 4
  END
ELSE
  BEGIN
     SELECT
       ISNULL(fv.numFactura, e.archivo) AS factura
      ,ISNULL(COALESCE(v.descripcion, 'Total'), '') AS concepto
      ,ISNULL(pp.PER_NOMRAZON, '') AS proveedor
      ,ISNULL(CONVERT(VARCHAR(10), e.fechaCreacion, 103), '') AS fecha
      ,ISNULL(e.monto, 0) AS cantidad
      ,CASE
         WHEN e.idgastoFondoFijo = 2 THEN @url + 'FondoFijo/FondoFijo_' + CONVERT(VARCHAR(20), f.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), v.id) + '/' + e.archivo + '.' + e.extension
         ELSE @urlPro + (SELECT
               '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4), DATEPART(yyyy, fecha_factura)) + '_' +
               RIGHT('00' + LTRIM(RTRIM(CONVERT(VARCHAR(2), DATEPART(mm, fecha_factura)))), 2) +
               '/' + rfc_emisor + '_' +
               CASE
                 WHEN serie <> '' THEN serie
                 ELSE ''
               END +
               folio + '.pdf'
             FROM Centralizacionv2..PPRO_DATOSFACTURAS
             WHERE folioorden = FV.ordenCompra)
       END AS [url]
     FROM tramite.valesFondoFijo ff
     JOIN Tramite.fondoFijo f
       ON f.id = ff.idtablafondofijo
     JOIN tramite.vales v
       ON ff.idVales = v.id
     JOIN Tramite.valesEvidencia e
       ON e.idVales = v.id
         AND e.envioReembolso = 1
         AND e.estatusReembolso = 3
         AND e.procesoPoliza = 1
     LEFT JOIN tramites.[Tramite].[FacturaVale] fv
       ON e.idfactura = fv.id
     LEFT JOIN GA_Corporativa..PER_PERSONAS pp
       ON fv.PER_IDPERSONA = pp.PER_IDPERSONA
     WHERE ff.idTablaFondoFijo = @id
   --AND v.estatusVale = 4
    END

END
go

