-- =============================================
-- Author:
-- Create date:
-- Description:
--[TransferenciasBancariasFFGV_SP] 4,6,'1100-0020-0001-0010','1100-0020-0001-0001',50000,495
-- =============================================
CREATE PROCEDURE [dbo].[TransferenciasBancariasFFGV_SP]
@idempresa int
,@idSucursal int
,@cuentaOrigen varchar(150)
,@cuentaDestino varchar(150)
,@monto decimal(18,2)
,@idUsuario int
,@referencia varchar(30) = ''
,@idOrigenReferencia int = ''


AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
declare @folio int =0, @empresa varchar(300), @nombreUsuario varchar(max)
begin try
  
insert into tsb_traspasosaldobancosFondoFijo (
tsb_idempresa
      ,tsb_idsucursal
      ,tsb_cuentaorigen
      ,tsb_cuentadestino
      ,tsb_importe
      ,tsb_moneda
      ,tsb_concepto
      ,tsb_estatus
      ,tsb_fechasolicita
      ,tsb_usuariosolicita)
values( 
@idempresa
,@idSucursal
,@cuentaOrigen
,@cuentaDestino
,@monto
,'PE'
,'DTRASSALDOINGTS'
,0 
,GETDATE() 
,@idUsuario
)
set @folio = @@IDENTITY

insert into traspasosFondoFijoLog(idtransferencia, referencia, idOrigenReferencia)
values(@folio, @referencia, @idOrigenReferencia)

select @empresa = emp_nombre from controlaplicaciones.dbo.cat_empresas where emp_idempresa = @idempresa
select @nombreUsuario =  usu_nombre + ' ' + usu_paterno + ' ' + usu_materno from controlaplicaciones.dbo.cat_usuarios where usu_idusuario = @idUsuario

select 'Ok' as estatus, 'La transferencia se realizó con exito' as mensaje, @folio  as folio, @folio as Folio, 
convert(nvarchar(MAX), getdate(), 101) Fecha, @empresa as Empresa, @nombreUsuario as Usuario

end try
begin catch
select 'error' as Estatus, 'Ocurrio un error durante la transferencia' as mensaje,   ERROR_NUMBER() AS ErrorNumber,
    ERROR_STATE() AS ErrorState,
    ERROR_SEVERITY() AS ErrorSeverity,
    ERROR_PROCEDURE() AS ErrorProcedure,
    ERROR_LINE() AS ErrorLine,
    ERROR_MESSAGE() AS ErrorMessage;
end catch
END
go

