-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <23/04/2020>
-- Description:	<SP que trae el idPersona de GA_Corporativa>
-- SEL_BUSCARPERSONA_V2_SP '111035', 1, 0, 0, ''
-- =============================================
CREATE PROCEDURE [dbo].[SEL_BUSCARPERSONA_V2_SP] 
	@idPersona varchar(50),
	@esid int,
	@esRFC int,
	@esnombre int,
	@nombre varchar(max)
AS
BEGIN
	--DECLARE @nombreBD VARCHAR(100),
	--@query NVARCHAR(MAX),
	--@esEmpleado INT =  0,
	--@BPRO INT = 0

	DECLARE @nombreUsuario varchar (255), @paterno varchar (255), @materno varchar (255), @idUsuario INT = 0;

	SELECT @nombreUsuario = PER_NOMRAZON, @paterno = PER_PATERNO, @materno = PER_MATERNO FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @IdPersona AND PER_TIPO = 'FIS' AND  PER_STATUS = 'ACTIVO';
	SELECT @idUsuario = usu_idusuario FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombre  LIKE ('%' + @nombreUsuario + '%') AND usu_paterno LIKE ('%' + @paterno + '%') AND usu_materno LIKE ('%' + @materno + '%');






	IF(@esid = 1)
	BEGIN 
	print 'esId'
		IF EXISTS (select top 1 1 from GA_Corporativa.dbo.PER_PERSONAS where PER_IDPERSONA = @idPersona and PER_TIPO = 'FIS')
		BEGIN

		--select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
		--SET @query ='SELECT  @esEmpleado = 1 
		--			from ['+@nombreBD+'].dbo.PER_ROLES pr
		--			inner join ['+@nombreBD+'].dbo.PNC_PARAMETR p on p.par_idenpara = rol_rol
		--			where p.PAR_TIPOPARA = ''PA'' and  p.par_idenpara = ''EMP'' and  pr.ROL_IDPERSONA = '''+@idPersona+''''	
		--PRINT @query
		--EXECUTE sp_executeSQL @query, N' @esEmpleado INT OUTPUT', @esEmpleado OUTPUT
		--IF(@esEmpleado = 1)
			IF EXISTS (SELECT TOP 1 1 FROM Tramites.dbo.usuariosGastosViaje GV WHERE GV.idPersona = @idPersona )
			BEGIN
			--	BEGIN
				select 
				1 estatus, 
				PER_NOMRAZON + ' ' + PER_PATERNO + ' ' + PER_MATERNO   as nombre,
				PER_IDPERSONA as idPersona
				,@idUsuario idUsuario
				,cu.usu_correo as correo
				from GA_Corporativa.dbo.PER_PERSONAS pp
				join Tramites.dbo.usuariosGastosViaje ugv
					on pp.PER_IDPERSONA = ugv.idPersona
				join ControlAplicaciones..cat_usuarios cu
					on ugv.idUsuario = cu.usu_idusuario
				where PER_IDPERSONA = @idPersona
				--END
				--ELSE
				--BEGIN
				--select 0 estatus, '' nombre, 0 idPersona, 'El ID BPRO no tiene rol de Empleado.' msj
				--END
			END
			ELSE
			BEGIN
				SELECT 0 AS estatus, '' as nombre, 0 as idPersona, 'La persona no ha sido configurada como usuario de anticipos de gastos de viaje, favor de levantar un ticket solicitando la configuración para el sistema Gastos de Viaje' as msj --
			END
		END
		ELSE
		BEGIN
		select 0 estatus, '' nombre, 0 idPersona, 'El ID BPRO no existe.' msj
		END
	END
	ELSE IF (@esRFC = 1)
	BEGIN
	print 'esRFC'
		IF EXISTS (select top 1 1 from GA_Corporativa.dbo.PER_PERSONAS where PER_RFC = @idPersona and PER_TIPO = 'FIS')
		BEGIN

		--select @BPRO = PER_IDPERSONA  from GA_Corporativa.dbo.PER_PERSONAS where PER_RFC = @idPersona and PER_TIPO = 'FIS'
		--select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal

		--SET @query ='SELECT  @esEmpleado = 1 
		--			from ['+@nombreBD+'].dbo.PER_ROLES pr
		--			inner join ['+@nombreBD+'].dbo.PNC_PARAMETR p on p.par_idenpara = rol_rol
		--			where p.PAR_TIPOPARA = ''PA'' and  p.par_idenpara = ''EMP'' and  pr.ROL_IDPERSONA = '''+CAST(@BPRO AS VARCHAR(50))+''''	
		--PRINT @query
		--EXECUTE sp_executeSQL @query, N' @esEmpleado INT OUTPUT', @esEmpleado OUTPUT
		--IF(@esEmpleado = 1)
		--	BEGIN
			select 
			1 estatus, 
			PER_NOMRAZON + ' ' + PER_PATERNO + ' ' + PER_MATERNO   as nombre,
			PER_IDPERSONA as idPersona
			,@idUsuario idUsuario
			,cu.usu_correo as correo
			from GA_Corporativa.dbo.PER_PERSONAS pp
			join Tramites.dbo.usuariosGastosViaje ugv
				on pp.PER_IDPERSONA = ugv.idPersona
			join ControlAplicaciones..cat_usuarios cu
				on ugv.idUsuario = cu.usu_idusuario
			where PER_RFC = @idPersona
		--	END
		--ELSE
		--	BEGIN
		--	select 0 estatus, '' nombre, 0 idPersona, 'El ID BPRO no tiene rol de Empleado.' msj
		--	END
		END
		ELSE
		BEGIN
		select 0 estatus, '' nombre, 0 idPersona, 'El ID BPRO no existe.' msj
		END
	END
	ELSE
	BEGIN
	print 'esnombre'
		DECLARE @Personas TABLE
		(IdPersona varchar(50), NombreCompleto varchar(max), rfc varchar(100), correo varchar(150))
		INSERT INTO @Personas
		select PER_IDPERSONA
		, PER_NOMRAZON  + ' ' +  PER_PATERNO + ' ' + PER_MATERNO
		, PER_RFC
		, cu.usu_correo
		from GA_Corporativa.dbo.PER_PERSONAS pp
		left join Tramites.dbo.usuariosGastosViaje ugv
				on pp.PER_IDPERSONA = ugv.idPersona
		left join ControlAplicaciones..cat_usuarios cu
				on ugv.idUsuario = cu.usu_idusuario
		where PER_TIPO = 'FIS' 
		and (PER_NOMRAZON like '%' +  @nombre  + '%'  OR PER_PATERNO like '%' +  @nombre  + '%' )
		
		IF EXISTS (select top 1 1 from @Personas where NombreCompleto like '%' + @idPersona  + '%')
		BEGIN
		--select @BPRO = IdPersona  from @Personas where NombreCompleto like '%' + @idPersona  + '%'
		--select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal

		--SET @query ='SELECT  @esEmpleado = 1 
		--			from ['+@nombreBD+'].dbo.PER_ROLES pr
		--			inner join ['+@nombreBD+'].dbo.PNC_PARAMETR p on p.par_idenpara = rol_rol
		--			where p.PAR_TIPOPARA = ''PA'' and  p.par_idenpara = ''EMP'' and  pr.ROL_IDPERSONA = '''+CAST(@BPRO AS VARCHAR(50))+''''	
		--PRINT @query
		--EXECUTE sp_executeSQL @query, N' @esEmpleado INT OUTPUT', @esEmpleado OUTPUT
		--IF(@esEmpleado = 1)
		--BEGIN
		
		select 
		1 estatus, 
		NombreCompleto as nombre,
		IdPersona as idPersona
		,@idUsuario idUsuario
		,correo
		from @Personas 
		where NombreCompleto  like '%' + @idPersona  + '%'
		--END
		--ELSE
		--BEGIN
		--		select 0 estatus, '' nombre, 0 idPersona, 'El ID BPRO no tiene rol de Empleado.' msj
		--END
		END
		ELSE
		BEGIN
		select 0 estatus, '' nombre, 0 idPersona, 'El ID BPRO no existe.' msj
		END

	END
	
END
go

