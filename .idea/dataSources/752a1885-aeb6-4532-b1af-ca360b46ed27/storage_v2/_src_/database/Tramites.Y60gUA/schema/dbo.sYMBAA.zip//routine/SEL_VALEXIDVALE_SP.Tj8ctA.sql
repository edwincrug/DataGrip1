-- =============================================
-- Author:		<Jorge Conelly>
-- Create date: <12/02/2020>
-- Description:	<SP que trae los datos de los vales x idVale>
-- [dbo].[SEL_VALEXIDVALE_SP]
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALEXIDVALE_SP] 
	@idVale VARCHAR(50)
AS
BEGIN
	 DECLARE @url varchar(max)
	 SELECT @url = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'

SELECT V.id, 
       V.idVale,  
       U.usu_nombre + ' ' + U.usu_paterno  + ' ' + U.usu_materno as nombreUsuario,
       FF.idFondoFijo, CONVERT(varchar, V.fechaCreacionVale, 103) as fechaCreacion,
       V.montoSolicitado, 
	   V.montoJustificado as Justificar, 
	   V.estatusVale,  
	   V.comentario,
	   V.descripcion,
       EV.descripcion as estatus, 
	   GFF.descripcion as tipoTramite,
	   @url as saveUrl,
       FF.id_perTra,
       DEP.dep_nombrecto, 
	   FF.idSucursal,
	   CASE WHEN V.estatusVale = 1 THEN ''
	   ELSE @url + 'FondoFijo' + '/FondoFijo_' + CONVERT(VARCHAR(20), FF.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), V.id) + '/AutorizacionVale_' + CONVERT(VARCHAR(20), V.id) + '.pdf' END as rutaAutorizado
 FROM [Tramites].[Tramite].[vales] V
  INNER JOIN Tramite.valesFondoFijo VF ON VF.idVales = V.id
  INNER JOIN Tramite.fondoFijo FF ON FF.id = VF.idTablaFondoFijo
  INNER JOIN [Tramite].[cat_estatusVale] EV ON EV.id = V.estatusVale
  LEFT JOIN [Tramite].[cat_gastosFondoFijo] GFF ON V.idGastosFondoFijo = GFF.id
  INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = V.idEmpleado
  INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON DEP.dep_iddepartamento = v.idDepartamento
 WHERE V.idVale = @idVale;

END
go

