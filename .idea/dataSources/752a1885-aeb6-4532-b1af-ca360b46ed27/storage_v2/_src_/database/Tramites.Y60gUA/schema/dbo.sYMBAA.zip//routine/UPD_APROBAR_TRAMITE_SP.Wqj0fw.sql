-- =============================================
-- Author:		Luis Garcia
-- Create date: 17/06/2019
-- Description:	SP que aprueba el tramite
-- =============================================
CREATE PROCEDURE [dbo].[UPD_APROBAR_TRAMITE_SP]
	@id_perTra INT,
	@cambioMF INT,
	@moralFisica INT,
	@idUsuario	 INT = NULL
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY

	UPDATE personaTramite
	SET petr_estatus = 2
		,esDe_IdEstatus = 4
	WHERE id_perTra = @id_perTra	

	IF (@cambioMF = 1)
		BEGIN
			DECLARE @idPerosna INT;

			SELECT 
				@idPerosna = id_persona 
			FROM personaTramite WHERE id_perTra = @id_perTra;

			UPDATE personas
			SET per_moralFisica = @moralFisica
			WHERE id_persona = @idPerosna
		END

	INSERT INTO dbo.BitacoraTramite
	SELECT @idUsuario,@id_perTra,'Se aprueba trámite', GETDATE(), null



	SELECT success = 1, msg = 'Se aprobo el tramite con éxito.'
COMMIT TRANSACTION
END TRY
BEGIN CATCH
ROLLBACK TRANSACTION
	SELECT success = -1, msg = 'Ocurrió un error al aprobar el trámite.'

END CATCH
END
;
go

