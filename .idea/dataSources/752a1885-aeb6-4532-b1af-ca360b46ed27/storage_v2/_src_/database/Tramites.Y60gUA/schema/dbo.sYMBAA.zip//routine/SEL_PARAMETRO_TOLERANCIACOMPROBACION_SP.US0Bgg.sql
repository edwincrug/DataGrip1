-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PARAMETRO_TOLERANCIACOMPROBACION_SP] AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT pr_descripcion centavos FROM parametros WHERE pr_tipoParametro = 'tramite' AND pr_identificador = 'compTolCentavos'
END
go

