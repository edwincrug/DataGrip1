

-- =============================================
-- Author:		Fidel Ortega
-- Create date: 12/02/2020
-- Description:	Devuelve los datos de una empresa para mostrarlos al usuario
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATOS_EMPRESA_SP] 
	-- Add the parameters for the stored procedure here
	@idEmpresa int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
	DECLARE @nombreBD VARCHAR(100),
	@query NVARCHAR(MAX),
	@descrip2 varchar(max) , 
	@descrip3 varchar(max)

	select @nombreBD = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_idempresa = @idEmpresa

	SET @query ='SELECT @descrip2 = PAR_DESCRIP2, @descrip3 = PAR_DESCRIP3  
					  FROM '+ @nombreBD +'.[dbo].[pnc_parametr] 
					  WHERE PAR_TIPOPARA = ''EM'''
	PRINT @query
	EXECUTE sp_executeSQL @query, N' @descrip2 varchar(max) OUTPUT, @descrip3 varchar(max) OUTPUT',@descrip2 OUTPUT, @descrip3 OUTPUT 


    -- Insert statements for procedure here
	SELECT ER.[IdEmpresa] AS [idEmpresa]
	  ,E.[emp_nombre] AS [nombre]
      ,ER.[RazonSocial] AS [razon_social]
   --   ,ER.[Calle] + ' NO. ' + ER.[NumeroExterior]
	  --+ (CASE WHEN ER.[NumeroInterior] <> NULL THEN ', INT ' ELSE '' END) + ISNULL(ER.[NumeroInterior], '') + ', COL. ' + ER.[Colonia]
   --   + ' ' + ER.[Localidad] + ' ' + ER.[Estado] + ' C.P. ' + ER.[CP] AS [direccion]
      ,@descrip2 + ' ' + @descrip3 as[direccion]
      ,ER.[Telefono] AS [telefono]
      ,ER.[RFC] AS [registro_federal]
	  ,E.[emp_cveempresa] AS [cveempresa]
	  ,E.[emp_paginaweb] AS [paginaweb]
	  ,E.[emp_nombrecto] AS [nombre_corto]
	  ,E.[emp_alias] AS [alias]
	  ,E.[emp_observaciones] AS [observaciones]
  FROM [Centralizacionv2].[dbo].[DIG_CAT_EMPRESA_RAZON] ER
  INNER JOIN ControlAplicaciones.dbo.cat_empresas E ON ER.IdEmpresa = E.emp_idempresa
  WHERE idEmpresa = @idEmpresa
END
go

