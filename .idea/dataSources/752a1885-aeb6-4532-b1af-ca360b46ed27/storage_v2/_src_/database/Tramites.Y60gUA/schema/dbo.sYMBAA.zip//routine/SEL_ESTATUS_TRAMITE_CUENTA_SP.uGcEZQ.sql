-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <11/06/2019>
-- Description:	<Devuelve el estatus en el que se encuentra el tramite>
-- Test SEL_ESTATUS_TRAMITE_SP  1,11,1

-- =============================================
CREATE PROCEDURE [dbo].[SEL_ESTATUS_TRAMITE_CUENTA_SP] 
	@idTramite INT,
	@rfc VARCHAR(50),
	@tipoProspecto INT
AS
BEGIN
	DECLARE @idPersona INT = (SELECT id_persona FROM personas WHERE per_rfc = @rfc AND id_TipoProspecto = @tipoProspecto)

	IF EXISTS (SELECT 1 FROM personaTramite PETR INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus 
				WHERE id_persona = @idPersona AND id_tramite = @idTramite AND PETR.petr_estatus not in (3,2))
		BEGIN
			DECLARE @estatus VARCHAR(50)
					,@estatusId INT
					,@idPerTra INT

			SELECT 
				@estatus = ESTR.est_nombre 
				,@estatusId = ESTR.id_estatus
				,@idPerTra = id_perTra
			FROM personaTramite PETR
			INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
			WHERE id_persona = @idPersona AND id_tramite = @idTramite
			order by id_perTra asc

			SELECT success = 1,  estatus = @estatus , estatusId = @estatusId, idPerTra = @idPerTra;
		END
	ELSE
		BEGIN
			SELECT success = 0,  msg = 'No se encontro ningun estatus para este tramite y persona', estatusId = -1, idPerTra = 0;
		END

END



go

