

-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <10/02/2020>
-- Description:	<Recupera la descripción >
--TEST EXEC  [Tramite].[Sp_Tramite_ConceptoAfectacion_GETLBySucursal]   26,52
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ConceptoAfectacion_GETLBySucursal] 
	@idEmpresa INT,
	@idSucursal INT,
	@areaAfec varchar(20) = NULL,
	@retencion varchar(200) = NULL
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = ''
	--IF EXISTS (SELECT TOP 1 1 FROM [Tramite].[RetencionesFondoFijo] WHERE idSucursal = @idSucursal AND retencion = @retencion)
	--BEGIN
	--SELECT PAR_IDENPARA, PAR_DESCRIP1 FROM [Tramite].[RetencionesFondoFijo] WHERE idSucursal = @idSucursal AND retencion = @retencion
	--END
	--ELSE
	--BEGIN
	--SELECT 
	--	@nombreBase = suc_nombrebd 
	--FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	--WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	--SET @query = 'SELECT PAR_IDENPARA, PAR_DESCRIP1 FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND  PAR_IDMODULO = ''CON'''

	--EXECUTE (@query)
	--END
	SELECT 
	@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	--SET @query = 'SELECT PAR_IDENPARA, PAR_DESCRIP1 FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND PAR_STATUS = ''A'' AND PAR_IDMODULO = ''CON'''

	IF(@idSucursal = 37 OR @idSucursal = 38 OR @idSucursal =39 )
	BEGIN
		SET @query = 'SELECT PAR_IDENPARA, 
		case when PAR_DESCRIP1 = ''No deducibles diversos'' then ''NO DEDUCIBLES''  else PAR_DESCRIP1 end as PAR_DESCRIP1 
		FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP1 not  like ''%ACT%'''
	END
	ELSE IF (@idSucursal = 22 )
	BEGIN
	SET @query = 'SELECT PAR_IDENPARA, 
		case when PAR_DESCRIP1 = ''No deducibles diversos'' then ''NO DEDUCIBLES''  else PAR_DESCRIP1 end as PAR_DESCRIP1 
		FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP1 not like ''%Casanova%'''
	END
	ELSE IF (@idSucursal = 23 )
	BEGIN
	SET @query = 'SELECT PAR_IDENPARA, 
		case when PAR_DESCRIP1 = ''No deducibles diversos'' then ''NO DEDUCIBLES''  else PAR_DESCRIP1 end as PAR_DESCRIP1 
		FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND PAR_STATUS = ''A'' OR PAR_DESCRIP1 LIKE ''NO DEDU%'''
	END
	ELSE IF (@idSucursal = 45 )
	BEGIN
	SET @query = 'SELECT PAR_IDENPARA, 
		case when PAR_DESCRIP1 = ''No deducibles diversos'' then ''NO DEDUCIBLES''  else PAR_DESCRIP1 end as PAR_DESCRIP1 
		FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND PAR_STATUS = ''A'''
	END
	ELSE IF (@idSucursal = 52 )
	BEGIN
	SET @query = 'SELECT PAR_IDENPARA, 
		case when PAR_DESCRIP1 = ''NO DEDUCIBLES DIVERSOS'' then ''NO DEDUCIBLES''  else PAR_DESCRIP1 end as PAR_DESCRIP1 
		FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND PAR_STATUS = ''A''  AND PAR_DESCRIP1 not like ''%Casanova%'' AND PAR_DESCRIP1 not  like ''%ACT%'''
	END
	ELSE
	BEGIN
		SET @query = 'SELECT PAR_IDENPARA, 
		case when PAR_DESCRIP1 = ''No deducibles diversos'' then ''NO DEDUCIBLES''  else PAR_DESCRIP1 end as PAR_DESCRIP1 
		FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND PAR_STATUS = ''A'' AND PAR_IDMODULO = ''CON'''
	END
	


	EXECUTE (@query)
	print @query
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

