-- =============================================
-- Author:		Luis Garcia
-- Create date: 25/06/2019
-- Description:	Regresa la url en donde se retornara la aplicacion
-- TEST SEL_URL_RETURN_PARAMS_SP
-- =============================================
CREATE PROCEDURE SEL_URL_RETURN_PARAMS_SP 
AS
BEGIN
	SELECT 
		pr_descripcion
	FROM parametros 
	WHERE pr_identificador = 'RETURN_URL'
END
go

