-- =============================================
-- Author:	
-- Create date: 
-- Description:	<Se guardan los documentos del tramite>
-- Test [SEL_DOCUMENTOS_CUENTA_API_SP] 5,6,1,'localhost'
-- =============================================


CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_CUENTA_API_SP] 
	 @idTramite INT
	,@idProspecto INT
	,@idTipoProspecto INT
	,@urlParam VARCHAR(50)
	
AS
BEGIN
	
	DECLARE @url VARCHAR(500);
	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam)
		END
	ELSE
		BEGIN 
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER')
		END

		SELECT	id_tramite
				,'Estado de Cuenta ' + nombreBanco doc_nomDocumento
				,'pdf' ext_nombre
				, 16 id_traDo
				, 9 id_documento
				,isnull(id_tramite,0) existe
				,isnull(det_observaciobes,'') Observaciones 
				,det_estatus estatusDocumento 
				,petr_estatus estatusTramite
				,'' doc_infoAdicional
				,0 doc_expira
				,@url +'Persona_'+ per_rfc + '_' + CONVERT(VARCHAR(10), id_tramite) +'/Documento_9_'+ idBanxico+'.pdf'[url]
				,DPT.id_perTra
				,idBanxico
				,nombreBanco
		FROM   dbo.personas P 
		INNER join  [personaTramite] PT ON PT.id_persona = P.id_persona 
		INNER JOIN  [dbo].detallePersonaCuenta DPT ON DPT.id_perTra = PT.id_perTra
		WHERE P.id_Prospecto = @idProspecto AND P.id_TipoProspecto = @idTipoProspecto AND petr_estatus <> 3 and DPT.det_estatus = 2 and id_tramite = @idTramite
	


END



go

