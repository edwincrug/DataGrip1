

-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 14/08/2019
-- Description:	SP que trae el parametro de Fondo Fijo
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PARAM_FONDOFIJO_SP]
@parametro varchar(50) 
AS
BEGIN
	SELECT 
		pr_descripcion 
	FROM parametros WHERE pr_identificador = @parametro
END
go

