

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <06/05/2020>
-- Description:	<SP que obtiene las evidencias del reembolso el FF>
-- SEL_EVIDENCIASREEMBOLSOFONDOFIJO_SP 1345
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EVIDENCIASREEMBOLSOFONDOFIJO_SP] 
	@idPerTra INT
AS
BEGIN

DECLARE @url VARCHAR(500);
DECLARE @urlPro VARCHAR(500);
SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');	
SET @urlPro = 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores';	

----Envio a Reembolso
--select 
--ff.idFondoFijo,
--v.idVale,
--ve.idComprobacionVale,
--ve.id as idComprobacion,
--v.montoSolicitado,
--v.estatusVale,
--v.montoSolicitado,
--case when ve.idfactura is null then ve.monto else ve.monto/1.16 end as importe,
--case when ve.idfactura is null then 0 else ve.monto * .16 end as IVA,
--ve.monto,
--ve.montoPoliza,
--case when ve.idgastoFondoFijo  = 2 then @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),ff.id_perTra) +'/Vales_'+ CONVERT(VARCHAR(20),VE.idVales)   + '/' + VE.archivo + '.' + VE.extension
--else @urlPro + (    	
--		SELECT '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4),DATEPART(yyyy,fecha_factura))+  '_'+
--			RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,fecha_factura)))),2) +
--			'/' + rfc_emisor + 	'_' + case when serie <> '' then serie else '' end + 
--			folio + '.pdf'
--		FROM 
--			Centralizacionv2..PPRO_DATOSFACTURAS 
--		WHERE 
--			folioorden = FV.ordenCompra) end as urlEvidencia,
--CONVERT(varchar, VE.fechaCreacion, 103) as fechaCreacion,
--case when ve.idfactura is null then 0 else 1 end as esFactura,
--ISNULL(ve.estatusReembolso,0) as estatusReembolso,
--ve.extension as tipoEvidencia,
--ve.comentario,
--ve.motivo
--from tramite.fondofijo ff
--inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
--inner join tramite.vales v on v.id = vff.idvales
--inner join tramite.valesEvidencia ve on ve.idVales = v.id 
--LEFT JOIN [Tramite].[FacturaVale] FV ON FV.idValeEvidencia = VE.id
--where ff.id_perTra = @idPerTra and ve.envioReembolso = 1 and (ve.estatusReembolso is null or ve.estatusReembolso = 2 or ve.estatusReembolso = 0 ) and ve.idestatus not in (3)
--order by v.id, ve.idComprobacionVale

--Envio a Reembolso
select 
ff.idFondoFijo,
v.idVale,
ve.idComprobacionVale,
ve.id as idComprobacion,
v.montoSolicitado,
v.estatusVale,
v.montoSolicitado,
case when ve.idfactura is null then ve.monto else ve.monto/1.16 end as importe,
case when ve.idfactura is null then 0 else ve.monto * .16 end as IVA,
ve.monto,
ve.montoPoliza,
case when ve.idgastoFondoFijo  = 2 then @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),ff.id_perTra) +'/Vales_'+ CONVERT(VARCHAR(20),VE.idVales)   + '/' + VE.archivo + '.' + VE.extension
else @urlPro + (    	
		SELECT '/' + rfc_receptor + '/' + CONVERT(VARCHAR(4),DATEPART(yyyy,fecha_factura))+  '_'+
			RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,fecha_factura)))),2) +
			'/' + rfc_emisor + 	'_' + case when serie <> '' then serie else '' end + 
			folio + '.pdf'
		FROM 
			Centralizacionv2..PPRO_DATOSFACTURAS 
		WHERE 
			folioorden = FV.ordenCompra) end as urlEvidencia,
CONVERT(varchar, VE.fechaCreacion, 103) as fechaCreacion,
case when ve.idfactura is null then 0 else 1 end as esFactura,
ISNULL(ve.estatusReembolso,0) as estatusReembolso,
case when ve.idgastoFondoFijo  = 2 then  ve.extension else 'pdf' end as tipoEvidencia,
ve.comentario,
ve.motivo
from tramite.fondofijo ff
inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join tramite.vales v on v.id = vff.idvales
inner join tramite.valesEvidencia ve on ve.idVales = v.id 
LEFT JOIN [Tramite].[FacturaVale] FV ON FV.idValeEvidencia = VE.id
where ff.id_perTra = @idPerTra and ve.envioReembolso = 1 and (ve.estatusReembolso is null or ve.estatusReembolso = 2 or ve.estatusReembolso = 0 ) and ve.idestatus not in (3)
and ve.id_perTraReembolso is null
order by v.id, ve.idComprobacionVale


--Historico a Reembolso
select 
ff.idFondoFijo,
v.idVale,
ve.idComprobacionVale,
ve.id as idComprobacion,
v.estatusVale,
v.montoSolicitado,
case when ve.idfactura is null then ve.monto else ve.monto/1.16 end as importe,
case when ve.idfactura is null then 0 else ve.monto * .16 end as IVA,
ve.monto,
ve.montoPoliza,
@url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),ff.id_perTra) +'/Vales_'+ CONVERT(VARCHAR(20),VE.idVales)   + '/' + VE.archivo + '.' + VE.extension as urlEvidencia,
CONVERT(varchar, VE.fechaCreacion, 103) as fechaCreacion,
case when ve.idfactura is null then 0 else 1 end as esFactura,
ISNULL(ve.estatusReembolso,0) as estatusReembolso,
ve.extension as tipoEvidencia,
ve.comentario,
ve.motivo
from tramite.fondofijo ff
inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join tramite.vales v on v.id = vff.idvales
inner join tramite.valesEvidencia ve on ve.idVales = v.id 
where ff.id_perTra = @idPerTra and ve.envioReembolso = 1 and ve.estatusReembolso = 1  and ve.idestatus not in (3)
order by v.id, ve.idComprobacionVale


END


go

