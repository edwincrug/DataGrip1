
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <07/05/2020>
-- Description:	<SP que manda a reembolso el FF>
-- SEL_PolizasCompFFGV_SP 1107
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PolizasCompFFGV_SP] 
	@id_perTra INT
AS
BEGIN
	
	select 
	p.id_perTra,
	v.id as idVale, 
	v.idVale as nombreVale, 
	ve.idComprobacionVale,
	p.monto,
	ISNULL(p.salidaEfectivo,0) as salidaEfectivo
	from Tramite.PolizasCompFFGV p
	inner join Tramite.vales v on v.id = p.idVale
	inner join Tramite.valesEvidencia ve on ve.id = p.idComprobacionVale
	where p.id_perTra = @id_perTra
	
END

go

