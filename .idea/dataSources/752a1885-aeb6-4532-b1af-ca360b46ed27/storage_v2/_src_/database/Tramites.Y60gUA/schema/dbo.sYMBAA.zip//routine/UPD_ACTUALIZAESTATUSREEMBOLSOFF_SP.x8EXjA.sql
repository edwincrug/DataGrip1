-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/10/2019>
-- Description:	<SP que actualiza el estatus del vale>
-- [dbo].[UPD_ACTUALIZAESTATUSREEMBOLSOFF_SP]   
-- =============================================
CREATE  PROCEDURE [dbo].[UPD_ACTUALIZAESTATUSREEMBOLSOFF_SP] 
	@idperTra INT
AS
BEGIN


IF EXISTS (SELECT top 1 1  FROM Tramite.valesEvidencia where id_perTraReembolso =  @idPerTra) 
BEGIN
update tramite.valesEvidencia
set estatusReembolso = 1
where id_perTraReembolso = @idperTra and envioReembolso = 1 and estatusReembolso is null
END
ELSE
BEGIN
	UPDATE ve
	SET ve.estatusReembolso = 1
	from tramite.fondofijo ff
	inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	inner join tramite.vales v on v.id = vff.idvales
	inner join tramite.valesEvidencia ve on ve.idVales = v.id 
	where ff.id_perTra = @idperTra and ve.envioReembolso = 1 and ve.estatusReembolso is null and ve.id_perTraReembolso is null 

	--UPDATE ve
	--SET ve.estatusReembolso = 1
	--from tramite.fondofijo ff
	--inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	--inner join tramite.vales v on v.id = vff.idvales
	--inner join tramite.valesEvidencia ve on ve.idVales = v.id 
	--where ff.id_perTra = @idperTra and ve.envioReembolso = 1 and ve.estatusReembolso is null and ve.estatusPerTraReembolso = 3
END

	--UPDATE ve
	--SET ve.estatusReembolso = 1
	--from tramite.fondofijo ff
	--inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	--inner join tramite.vales v on v.id = vff.idvales
	--inner join tramite.valesEvidencia ve on ve.idVales = v.id 
	--where ff.id_perTra = @idperTra and ve.envioReembolso = 1 and ve.estatusReembolso is null 
	
	SELECT 1 as success	

END

go

