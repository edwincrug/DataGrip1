-- =============================================
-- Author:		<Mauricio Salgado>
-- Create date: <11/06/2019>
-- Description:	Trae los tramites por area (Respaldo)
--TEST SEL_TRAMITE_BY_AREA_SP 3, 423
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TRAMITE_BY_AREA_SP_TEMP_MAU] 
	@idArea INT,
	@usuario INT
AS
BEGIN

IF(@idArea != 3)
	BEGIN
		SELECT 
			est_nombre,
			id_perTra,
			max(nombre) nombre,
			CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
			tra_nomTramite,
			max(id_persona) id_persona,
			max(per_rfc) per_rfc,
			max(id_TipoProspecto) id_TipoProspecto,
			id_estatus,
			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
		FROM
		(SELECT 
			ESTR.est_nombre,
			PETR.id_perTra,
			PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre AS nombre,
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			PER.id_persona,
			PER.per_rfc,
			PER.id_TipoProspecto,
			ESTR.id_estatus AS id_estatus
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
		WHERE TRA.id_area = @idArea AND PETR.petr_estatus NOT IN (2, 3, 4, 5, 6)

		UNION ALL

		SELECT 
			ESTR.esDe_descripcion AS est_nombre,
			PETR.id_perTra,
			CASE WHEN PETR.id_tramite IN (4, 9) THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			0 AS id_persona,
			'' AS per_rfc,
			0 AS id_TipoProspecto,
			ESTR.esDe_IdEstatus AS id_estatus

		FROM personaTramite PETR
		INNER JOIN cat_proceso_estatus ESTR ON ESTR.esDe_IdEstatus = PETR.petr_estatus AND ESTR.idTipoTramite = 9
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		WHERE TRA.id_area =  2 AND PETR.petr_estatus IN (1, 2, 6, 8)) x
		group by est_nombre,
			id_perTra,
			petr_fechaTramite,
			tra_nomTramite,
			id_estatus
	
		ORDER BY id_perTra DESC
	END
ELSE
	BEGIN
		SELECT 
			ESTR.est_nombre,
			PETR.id_perTra,
			CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
			CONVERT(VARCHAR,PETR.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PETR.petr_fechaTramite,24) AS petr_fechaTramite,
			TRA.tra_nomTramite,
			0 AS id_persona,
			'' AS per_rfc,
			0 AS id_TipoProspecto,
			ESTR.id_estatus,
			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
		FROM personaTramite PETR
		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
		INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
		INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
		WHERE PETR.petr_estatus NOT IN (2, 3, 4, 5) AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = ORG.suc_idsucursal
		group by est_nombre,
			PETR.id_perTra,
			PETR.petr_fechaTramite,
			TRA.tra_nomTramite,
			ESTR.id_estatus,
			PETR.id_persona,
			PETR.id_tramite
	
		ORDER BY id_perTra DESC
	END

--IF(@idArea != 3)
--	BEGIN
--		SELECT 
--			est_nombre,
--			id_perTra,
--			max(nombre) nombre,
--			CONVERT(VARCHAR,petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),petr_fechaTramite,24) AS petr_fechaTramite,
--			tra_nomTramite,
--			max(id_persona) id_persona,
--			max(per_rfc) per_rfc,
--			max(id_TipoProspecto) id_TipoProspecto,
--			id_estatus,
--			DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
--		FROM
--		(SELECT 
--			ESTR.est_nombre,
--			PETR.id_perTra,
--			PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre AS nombre,
--			PETR.petr_fechaTramite,
--			TRA.tra_nomTramite,
--			PER.id_persona,
--			PER.per_rfc,
--			PER.id_TipoProspecto,
--			ESTR.id_estatus AS id_estatus
--		FROM personaTramite PETR
--		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
--		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
--		INNER JOIN personas PER ON PER.id_persona = PETR.id_persona
--		WHERE TRA.id_area = 2 AND PETR.petr_estatus IN (1, 2, 6)--NOT IN (2, 3, 4, 5, 6)

--		UNION ALL

--		SELECT 
--			ESTR.est_nombre,
--			PETR.id_perTra,
--			CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
--			PETR.petr_fechaTramite,
--			TRA.tra_nomTramite,
--			0 AS id_persona,
--			'' AS per_rfc,
--			0 AS id_TipoProspecto,
--			ESTR.id_estatus

--		FROM personaTramite PETR
--		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
--		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
--		WHERE TRA.id_area =  2 AND PETR.petr_estatus IN (1, 2, 6)--NOT IN (2, 3, 4, 5, 6)
--		) x
--		group by est_nombre,
--			id_perTra,
--			petr_fechaTramite,
--			tra_nomTramite,
--			id_estatus
	
--		ORDER BY id_perTra DESC
--	END
--ELSE
--	BEGIN
--		SELECT 
--			ESTR.est_nombre,
--			PETR.id_perTra,
--			CASE WHEN PETR.id_tramite = 4 THEN (SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PETR.id_persona) ELSE '' END AS nombre,
--			PETR.petr_fechaTramite,
--			TRA.tra_nomTramite,
--			0 AS id_persona,
--			'' AS per_rfc,
--			0 AS id_TipoProspecto,
--			ESTR.id_estatus
--		FROM personaTramite PETR
--		INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
--		INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
--		INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
--		--INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
--		WHERE PETR.petr_estatus IN (1, 2, 6)--NOT IN (2, 3, 4, 5) --AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = ORG.suc_idsucursal
--		group by est_nombre,
--			PETR.id_perTra,
--			PETR.petr_fechaTramite,
--			TRA.tra_nomTramite,
--			ESTR.id_estatus,
--			PETR.id_persona,
--			PETR.id_tramite
	
--		ORDER BY id_perTra DESC
--	END
END


go

