
-- =============================================
-- Author:		JCPS
-- Create date: 19/03/2020
-- Description: SP Actualiza a autorizado el FF
-- [dbo].[UPD_CIERREAFONDOFIJO_SP] 1071
-- =============================================
CREATE PROCEDURE [dbo].[UPD_CIERREAFONDOFIJO_SP] 
@id_perTra INT
AS

BEGIN

	UPDATE [Tramites].[dbo].tramitedevoluciones 
	SET esDe_IdEstatus = 7 
	WHERE id_pertra =  @id_perTra

SELECT success = 1

END
go

