-- =============================================
-- Author:		Francisco Javier Suárez Priego
-- Create date: 10/09/2019
-- Description: funcion para obtener las empresas a las que tiene acceso un usuario
-- =============================================
--Tramite.Sel_EmpresaByUserID 347
CREATE PROCEDURE Tramite.Sel_EmpresaByUserID
	-- Add the parameters for the stored procedure here
	@userId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT cE.emp_idempresa, cE.emp_nombre, empR.Calle, empR.NumeroExterior, empR.NumeroInterior, empR.Colonia, empR.Estado, empR.CP

	from ControlAplicaciones.dbo.cat_empresas cE 
	inner join ControlAplicaciones.dbo.cat_usuarios cU on cU.emp_idempresa=CE.emp_idempresa
	inner Join [Centralizacionv2].[dbo].[DIG_CAT_EMPRESA_RAZON] empR on cE.emp_idempresa = empR.IdEmpresa
	 where cU.usu_idusuario = @userId
END
go

