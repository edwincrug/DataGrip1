-- =============================================
-- Author:		Luis Garcia
-- Create date: 13/06/2019
-- Description:	Trae los datos del usuario para moestrar en aprobador
-- TEST SEL_USUARIO_APROBAR_SEL 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_USUARIO_APROBAR_SEL] 
	@id_perTra INT
AS
BEGIN
	SELECT 
		PERTR.id_perTra,
		PER.id_persona,
		UPPER(PER.per_rfc) per_rfc,
		UPPER(PER.per_apellido1 + ' ' + PER.per_apellido2 + ' ' + PER.per_nombre) AS nombre,
		PER.per_moralFisica,
		PER.per_cuentaBancaria,
		TRA.tra_nomTramite,
		TRA.id_tramite,
		PER.id_Prospecto,
		PER.id_TipoProspecto,
		ISNULL(PERTR.esDe_IdEstatus,1) esDe_IdEstatus
	FROM personaTramite PERTR
	INNER JOIN personas PER ON PER.id_persona = PERTR.id_persona
	INNER JOIN cat_tramites TRA ON TRA.id_tramite = PERTR.id_tramite 
	WHERE PERTR.id_perTra = @id_perTra
	
END



;
go

