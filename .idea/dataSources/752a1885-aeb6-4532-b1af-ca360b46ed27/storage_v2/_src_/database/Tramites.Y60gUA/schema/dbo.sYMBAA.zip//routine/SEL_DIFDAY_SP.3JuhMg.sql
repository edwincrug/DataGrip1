-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <12/06/2019>
-- Description:	<Trae los dias de diferencia>
-- TEST SEL_DIFDAY_SP 2, 423
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DIFDAY_SP] 
	@idArea INT,
	@usuario INT
AS
BEGIN
	
--DECLARE @idArea INT = 3,
--	@usuario INT = 4297


	DECLARE @idRol INT = 0;
	SELECT 
		@idRol = idRol
	FROM usuarioRol WHERE idUsuario = @usuario
	
	
	IF @idRol = 14  --DIRECTOR DE MARCA
	BEGIN
	SELECT 
				PETR.id_perTra, id_empresa, id_sucursal,PETR.petr_estatus,
				DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			FROM [Tramites].[dbo].[personaTramite] PETR
			INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
			INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
			INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
			INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario  AND TD.id_empresa = ORG.emp_idempresa 
			WHERE  PETR.petr_estatus IN (6, 1)
			AND td.esDe_IdEstatus = 2
			
			GROUP BY PETR.id_perTra, petr_fechaTramite, id_empresa, id_sucursal,PETR.petr_estatus

			SELECT 
				pr_descripcion 
			FROM parametros 
			WHERE id_parametro IN (7, 8)

END
ELSE IF @idRol = 15  --ESCRUTADOR
BEGIN
	SELECT 
				PETR.id_perTra, id_empresa, id_sucursal,PETR.petr_estatus,
				DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			FROM [Tramites].[dbo].[personaTramite] PETR
			INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
			INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
			INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
			INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario  AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = ORG.suc_idsucursal
			WHERE  PETR.petr_estatus IN (6, 1)
			AND td.esDe_IdEstatus = 2
			GROUP BY PETR.id_perTra, petr_fechaTramite, id_empresa, id_sucursal,PETR.petr_estatus

			SELECT 
				pr_descripcion 
			FROM parametros 
			WHERE id_parametro IN (7, 8)

END 
ELSE IF(@idArea != 3)
		BEGIN
			SELECT 
				id_perTra,
				DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			FROM [Tramites].[dbo].[personaTramite] PETR
			INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
			INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
			WHERE PETR.petr_estatus IN (0,1,12,11) AND TRA.id_area = @idArea

			SELECT 
				pr_descripcion 
			FROM parametros 
			WHERE id_parametro IN (7, 8)
		END
	ELSE
		BEGIN
			SELECT 
				PETR.id_perTra,
				DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias
			FROM [Tramites].[dbo].[personaTramite] PETR
			INNER JOIN estatusTramites ESTR ON ESTR.id_estatus = PETR.petr_estatus
			INNER JOIN cat_tramites TRA ON TRA.id_tramite = PETR.id_tramite
			INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PETR.id_perTra
			INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] ORG ON usu_idusuario = @usuario
			WHERE PETR.petr_estatus IN (6, 1) AND TD.id_empresa = ORG.emp_idempresa AND TD.id_sucursal = ORG.suc_idsucursal
			GROUP BY PETR.id_perTra, petr_fechaTramite

			SELECT 
				pr_descripcion 
			FROM parametros 
			WHERE id_parametro IN (7, 8)
		END
END
go

