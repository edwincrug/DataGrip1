-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <03/09/2019>
-- Description:	<Almacena el importe para un concepto>
--TEST EXEC [Tramite].[Sp_Tramite_ImporteConcepto_INS]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ImporteConcepto_INS] 
	@importe DECIMAL(18, 2),
	@idUsuario INT,
	@idTipoProceso INT,
	@idTramiteConcepto INT,
	@importeIva DECIMAL(18, 2),
	@folio VARCHAR(80),
	@fecha VARCHAR(30),
	@idConceptoArchivo INT,
	@UUID VARCHAR(50),
	@rfc VARCHAR(20),
	@xmlConceptos Xml,
	@mesCorriente INT = 0,
	@tipoNotificacion INT = 0,
	@estatusNotificacion INT = 0
AS
BEGIN 

	SET NOCOUNT ON;
		
	DECLARE @resultado INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_ImporteConcepto_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite

		INSERT INTO [Tramite].[TramiteImporte] (importe, idTramiteConcepto, idUsuario, idTipoProceso, importeIva, idConceptoArchivo)
		VALUES (@importe, @idTramiteConcepto, @idUsuario, @idTipoProceso, @importeIva, @idConceptoArchivo)

		UPDATE [Tramite].[ConceptoArchivo]
		SET total = @importe, folioDocumento = @folio, uuid = @UUID, iva = @importeIva, rfc = @rfc, tipoIVA = 15, mesCorriente = @mesCorriente, tipoNotificacion = @tipoNotificacion, estatusNotificacion = @estatusNotificacion, fecha = @fecha
		WHERE idConceptoArchivo = @idConceptoArchivo
		
		INSERT INTO [Tramite].[ArchivoDetalle]
		(cantidad, unidad, numeroIdentificacion, descripcion, valorUnitario, importe, idConceptoArchivo)
		Select conceptosXML.Columnas.value('cantidad[1]','Varchar(30)') [cantidad]
			,conceptosXML.Columnas.value('unidad[1]','Varchar(100)') [unidad]
			,conceptosXML.Columnas.value('noIdentificacion[1]','Varchar(80)') [noIdentificacion]
			,conceptosXML.Columnas.value('descripcion[1]','Varchar(150)') [descripcion]
			,conceptosXML.Columnas.value('valorUnitario[1]','DECIMAL(18, 2)') [valorUnitario]
			,conceptosXML.Columnas.value('importe[1]','DECIMAL(18, 2)') [importe]
			,@idConceptoArchivo AS idConceptoArchivo
		From @xmlConceptos.nodes('//Conceptos/Concepto') AS conceptosXML(Columnas) 

		SET @resultado = 1

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @resultado AS [resultado]
END
go

