-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Tramite].[Sp_Tramite_GDM_perTraPadre_GET] 1675
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_GDM_perTraPadre_GET]
	@perTra INT = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT
		TGM.[id_perTraPadre]
		,TGM.[importeDeMas]
		,TGM.[estatus]
		,TGM.[idTramiteTransferencia]
		,CA.*
	FROM [Tramite].[TramiteGastosMas] TGM
	INNER JOIN [Tramite].[ConceptoArchivo] CA ON TGM.idConceptoArhivo = CA.idConceptoArchivo
	WHERE id_perTra = @perTra

 --   SELECT [id_perTraPadre]
	--FROM [Tramite].[TramiteGastosMas]
	--WHERE id_perTra = @perTra
END
go

