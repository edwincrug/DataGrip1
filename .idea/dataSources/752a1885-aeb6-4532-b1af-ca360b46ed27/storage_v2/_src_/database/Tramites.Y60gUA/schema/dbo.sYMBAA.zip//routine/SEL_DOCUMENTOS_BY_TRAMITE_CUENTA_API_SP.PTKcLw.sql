-- =============================================
-- Author:	
-- Create date: 
-- Description:	<Se guardan los documentos del tramite>
-- Test [SEL_DOCUMENTOS_BY_TRAMITE_CUENTA_API_SP] 1, 0, 1,'localhost', 'BOAL7206308S4'
-- =============================================


CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_BY_TRAMITE_CUENTA_API_SP] 
	 @idTramite INT
	,@idProspecto INT
	,@idTipoProspecto INT
	,@urlParam VARCHAR(50)
	,@rfc VARCHAR(50) = ''
AS
BEGIN
	
	DECLARE @url VARCHAR(500);
	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam)
		END
	ELSE
		BEGIN 
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER')
		END
	IF(@rfc='')
	BEGIN    
		SELECT	PT.id_tramite
				,'Estado de Cuenta ' + nombreBanco + ' ('+upper(ext_nombre)+')' AS doc_nomDocumento
				,'pdf' ext_nombre
				, 16 id_traDo
				, 9 id_documento
				,isnull(PT.id_tramite,0) existe
				,isnull(det_observaciobes,'') Observaciones 
				,det_estatus estatusDocumento 
				,petr_estatus estatusTramite
				,'' doc_infoAdicional
				,0 doc_expira
				,@url +'Persona_'+ per_rfc + '_' + CONVERT(VARCHAR(10), PT.id_tramite) +'/Documento_9_'+ idBanxico+'.pdf'[url]
				,DPT.id_perTra
				,idBanxico
				,nombreBanco
				,noCuenta
				,DPT.clabe
				,DPT.idDetPersonaTramite
		FROM   dbo.personas P 
		INNER join  [personaTramite] PT ON PT.id_persona = P.id_persona 
		INNER JOIN  [dbo].detallePersonaCuenta DPT ON DPT.id_perTra = PT.id_perTra
		inner join cat_tramiteDocumento TD on DPT.id_traDo = TD.id_traDo
		inner join cat_documentos D on TD.id_documento = D.id_documento
		inner join cat_extensiones E on E.id_extension = D.id_extension
		WHERE P.id_Prospecto = @idProspecto AND P.id_TipoProspecto = @idTipoProspecto 
		--and PT.id_tramite = @idTramite 
		AND petr_estatus not in (2,3) 
	END
	ELSE
	BEGIN
		SELECT	PT.id_tramite
				,'Estado de Cuenta ' + nombreBanco + ' ('+upper(ext_nombre)+')' AS doc_nomDocumento
				,'pdf' ext_nombre
				, 16 id_traDo
				, 9 id_documento
				,isnull(PT.id_tramite,0) existe
				,isnull(det_observaciobes,'') Observaciones 
				,det_estatus estatusDocumento 
				,petr_estatus estatusTramite
				,'' doc_infoAdicional
				,0 doc_expira
				,@url +'Persona_'+ per_rfc + '_' + CONVERT(VARCHAR(10), PT.id_tramite) +'/Documento_9_'+ idBanxico+'.pdf'[url]
				,DPT.id_perTra
				,idBanxico
				,nombreBanco
				,noCuenta
				,DPT.clabe
				,DPT.idDetPersonaTramite
		FROM   dbo.personas P 
		INNER join  [personaTramite] PT ON PT.id_persona = P.id_persona 
		INNER JOIN  [dbo].detallePersonaCuenta DPT ON DPT.id_perTra = PT.id_perTra
		inner join cat_tramiteDocumento TD on DPT.id_traDo = TD.id_traDo
		inner join cat_documentos D on TD.id_documento = D.id_documento
		inner join cat_extensiones E on E.id_extension = D.id_extension
		WHERE P.per_rfc = @rfc AND P.id_TipoProspecto = @idTipoProspecto 
		--and PT.id_tramite = @idTramite 
		AND petr_estatus not in (2,3) 
		
	END
	


END
go

