-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Tramite].[Sp_Tramite_CuentasBanco_GetCorreos]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_CuentasBanco_GetCorreos]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT 
		valor correoTesoreria
	FROM [dbo].parametrizacion
	WHERE nombreColumna = 'correosTesoreria'
END
go

