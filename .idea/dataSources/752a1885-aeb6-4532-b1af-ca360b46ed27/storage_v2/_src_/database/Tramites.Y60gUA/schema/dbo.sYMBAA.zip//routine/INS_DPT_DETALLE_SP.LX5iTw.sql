-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/07/2019>
-- Description:	<Guarda detalle del tramite>
-- =============================================
CREATE PROCEDURE [dbo].[INS_DPT_DETALLE_SP]
	@idDocumento INT,
	@idTramite INT,
	@idPerTra INT, 
	@observaciones varchar(50)
AS
BEGIN
	
	DECLARE @idTrado INT = (SELECT id_traDo FROM cat_tramiteDocumento WHERE id_documento = @idDocumento AND id_tramite = @idTramite)

			INSERT INTO [dbo].[detallePersonaTramite]
					   ([id_perTra]
					   ,[id_traDo]
					   ,[det_estatus]
					   ,[det_observaciobes])
				 VALUES
					   (@idPerTra
					   ,@idTrado
					   ,1
					   ,@observaciones)
	
	SELECT success = 1, msg = 'Se inserto corectamente';
END


go

