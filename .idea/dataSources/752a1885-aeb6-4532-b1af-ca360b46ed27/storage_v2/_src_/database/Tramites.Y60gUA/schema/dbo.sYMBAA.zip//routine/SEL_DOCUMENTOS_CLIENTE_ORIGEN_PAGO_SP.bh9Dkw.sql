
-- =============================================
-- Author:		Luis Garcia
-- Create date: 22/07/2019
-- Description:	Trae los documentos del cliente pruebas
-- exec SEL_DOCUMENTOS_CLIENTE_SP 452640, 4, 6, 1, 1388
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_CLIENTE_ORIGEN_PAGO_SP]
	@idCliente INT,
	@idEmpresa INT,
	@idSucursal INT,
	@tipo INT,
	@idPerTra INT
	
AS
BEGIN
	--DECLARE @idCliente INT = 452640,
	--	@idEmpresa INT = 4,
	--	@idSucursal INT = 6,
	--	@tipo INT = 1,
	--	@idPerTra INT = 1389

	DECLARE @nombreBase VARCHAR(30) = '',
			@query VARCHAR(MAX) = '',
			@query2 VARCHAR(MAX) = '',
			@queryCarteras VARCHAR(MAX) = '',
			@idTraDe INT,
			@cartera VARCHAR(50),
			@queryTipoPago  NVARCHAR(max),
			@ParmDefinition  NVARCHAR(max),
			@tipoDePago  NVARCHAR(max);

	DECLARE @dataTemp TABLE (idPersona INT, documento VARCHAR(500), personaRazon VARCHAR(200), saldo NUMERIC(18,2), checado BIT, idDocumentoDevuelto INT, departamento VARCHAR(200), id_perTra INT, devFinal NUMERIC(18, 2), aplicaBPRO INT, idTrade INT, dineroOcupado NUMERIC(18, 2), docEstatus BIT, cartera VARCHAR(100), tipoDoc VARCHAR(100), efectivo INT, tipoPago VARCHAR(5) );

	SELECT 
		@idTrade = id_traDe 
	FROM tramiteDevoluciones WHERE id_perTra = @idPerTra

	

	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SET @queryTipoPago = N'SELECT @tipoPagoOUT = PNC.PAR_IDENPARA' +
						' FROM ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] AS PNC' + 
						' WHERE PAR_TIPOPARA = ''FP'' AND PAR_DESCRIP1 = ''C. EFECTIVO C.'''

	SET @ParmDefinition = N'@tipoPagoOUT VARCHAR(5) OUTPUT'

	EXECUTE sp_executesql @queryTipoPago, @ParmDefinition, @tipoPagoOUT = @tipoDePago OUTPUT;


	SELECT 
		@cartera = cartera 
	FROM cat_carterasDevoluciones WHERE id_empresa = @idEmpresa AND id_sucursal = @idSucursal

	DECLARE @carterasTemp TABLE (consecutivo INT, cartera VARCHAR(10))
	SET @queryCarteras = 'SELECT ' + CHAR(13) +
		CHAR(9) + 'CO.PAR_DESCRIP1' + CHAR(13) +
	'FROM ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] C,' + ' [' + @nombreBase + '].DBO.PNC_PARAMETR CO' + CHAR(13) +
	'WHERE C.PAR_TIPOPARA = ''COCOCXC'' AND' + CHAR(13) +
	'C.PAR_HORA1 = ''12:00''' + CHAR(13) +
	'AND C.PAR_DESCRIP4 <> ''''' + CHAR(13) +
	'AND C.PAR_DESCRIP5 <> ''''' + CHAR(13) +
	'AND CO.PAR_TIPOPARA = ''COCOCXCCAR''' + CHAR(13) +
	'AND C.PAR_IDENPARA = CO.PAR_IDENPARA' + CHAR(13) +
	'AND CO.PAR_DESCRIP2 = ''''' + CHAR(13) +
	'AND CO.PAR_DESCRIP1 IN (SELECT PAR_IDENPARA FROM ' + '[' + @nombreBase + '].DBO.PNC_PARAMETR WHERE PAR_TIPOPARA = ''CARTERA'' AND PAR_IDMODULO = ''CXC''' + CHAR(13) +
							'AND PAR_DESCRIP2 IN (SELECT PAR_DESCRIP2 FROM ' + '[' + @nombreBase + '].DBO.PNC_PARAMETR WHERE PAR_TIPOPARA = ''ibandrade''))';

	DECLARE  @inner VARCHAR(100) = ''
			,@having  VARCHAR(100) = ''	
	
	IF (@idPerTra != 0) 
	BEGIN
	if((select petr_estatus from personaTramite where id_perTra = @idPerTra) = 5)
	BEGIN
		SET @inner = 'LEFT '
		SET @having = 'HAVING (SUM(CCP_ABONO)-SUM(CCP_CARGO)) > 0 '
	END
	ELSE
	BEGIN
	SET @inner = 'INNER '
		SET @having = ' '
	END

		
	END
	ELSE
	BEGIN
		SET @inner = 'LEFT '
		SET @having = 'HAVING (SUM(CCP_ABONO)-SUM(CCP_CARGO)) > 0 '
	END


	SET @query = 'SELECT DISTINCT idPersona, documento ,nombre, saldo, checado, id_docDe, PAR_DESCRIP1, id_perTra, devFinal, aplicaBPRO, id_traDe, dineroOcupado, docEstatus,  '''' cartera, C.PAM_TIPODOCTO tipoDoc, '''' efectivo, tipoPago' + CHAR(13) +
					'FROM(SELECT ' + CHAR(13) +
					CHAR(9) + 'CAR.CCP_IDPERSONA AS idPersona,' + CHAR(13) +
					CHAR(9) + 'CAR.CCP_IDDOCTO AS documento,' + CHAR(13) +
					CHAR(9) + 'PER.PER_NOMRAZON AS nombre,' + CHAR(13) +
					CHAR(9) + 'SUM(CAR.CCP_ABONO) - SUM(CAR.CCP_CARGO) AS saldo,' + CHAR(13) +
					CHAR(9) + 'CASE WHEN DD.id_docDe IS NULL THEN CONVERT(BIT, 0) ELSE DD.docDe_estatus END checado,' + CHAR(13) +
					CHAR(9) + 'DD.id_docDe,' + CHAR(13) +
					CHAR(9) + 'SUBSTRING(PNC.PAR_DESCRIP1,    CHARINDEX(''. -'',PNC.PAR_DESCRIP1) + 3    ,LEN(PNC.PAR_DESCRIP1))  as PAR_DESCRIP1,' + CHAR(13) +
					CHAR(9) + 'TD.id_perTra,' + CHAR(13) +
					CHAR(9) + 'DD.docDe_valorDev AS devFinal,' + CHAR(13) +
					CHAR(9) + 'DD.docDe_aplicaBPRO AS aplicaBPRO,' + CHAR(13) +
					CHAR(9) + 'TD.id_traDe, CONVERT(NUMERIC(18,2), 0.00) dineroOcupado ,' + CHAR(13) +
					CHAR(9) + 'ISNULL(DD.docDe_estatus, 0) AS docEstatus,' + CHAR(13) +
					CHAR(9) + ''''' AS cartera,' + CHAR(13) +
					CHAR(9) + ''''' AS tipoDoc,' + CHAR(13) +
					CHAR(9) + ''''' AS efectivo,' + CHAR(13) +
					CHAR(9) + 'DD.docDe_tipoPago AS tipoPago' + CHAR(13) +
				'FROM ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] AS PNC' + CHAR(13) +
				'INNER JOIN ' + '[' + @nombreBase + '].[DBO].[VIS_CONCAR01] AS CAR ON CAR.CCP_CARTERA = PNC.PAR_IDENPARA' + CHAR(13) +
				'INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] AS PER ON PER.PER_IDPERSONA = CAR.CCP_IDPERSONA' + CHAR(13)
				IF(@idPerTra = 0)
				BEGIN SET @query = @query +' LEFT JOIN [documentosDevueltos] DD ON DD.docDe_documento = CAR.CCP_IDDOCTO COLLATE DATABASE_DEFAULT AND DD.docDe_aplicaBPRO = 0' + CHAR(13) END
				ELSE 
				BEGIN SET @query = @query + @inner+ 'JOIN [documentosDevueltos] DD ON DD.docDe_documento = CAR.CCP_IDDOCTO COLLATE DATABASE_DEFAULT' + CHAR(13) END				
												
				SET @query = @query + 'LEFT JOIN [tramiteDevoluciones] TD ON TD.id_traDe = DD.id_traDe' + CHAR(13) +
				'WHERE PNC.PAR_TIPOPARA LIKE ''CARTERA''' + CHAR(13) +
				'AND CAR.CCP_IDPERSONA IN (' + CONVERT(VARCHAR(20), @idCliente ) + ')' + CHAR(13) +
				'AND PNC.PAR_IDENPARA IN (' + @queryCarteras + ')' + CHAR(13) +
				'GROUP BY CAR.CCP_IDPERSONA, PER.PER_NOMRAZON, CAR.CCP_IDDOCTO, DD.id_docDe, DD.docDe_estatus, DD.id_docDe, PNC.PAR_DESCRIP1, TD.id_perTra, DD.docDe_valorDev, DD.docDe_aplicaBPRO, TD.id_traDe, DD.docDe_tipoPago' + CHAR(13) +
				''+ @having +'  ) x left JOIN ' + '[' + @nombreBase + '].[dbo].[CXC_PAGANT] C ON C.PAM_IDDOCTO = x.documento COLLATE DATABASE_DEFAULT' + CHAR(13) +
				'WHERE PAR_DESCRIP1 not like ''%IVA%'''

	print @query
	INSERT INTO @dataTemp
	EXECUTE (@query)
	
	DECLARE @aux INT = 1,
	@countDocs INT = (SELECT COUNT(documento) FROM @dataTemp),
	@strDocumentos VARCHAR(MAX) = '';

	DECLARE @DocsTemp TABLE (dataRow INT, documento VARCHAR(500) );
	DECLARE @tiposPagosTemp TABLE ( PAR_IDENPARA VARCHAR(5), tipoPago VARCHAR(50), documento VARCHAR(500), saldo NUMERIC(18,2) )
	
	INSERT INTO @DocsTemp
	SELECT 
		ROW_NUMBER() OVER (ORDER BY documento ASC),
		documento
	FROM @dataTemp

	WHILE (@aux <= @countDocs)
		BEGIN
			SELECT 
				 @strDocumentos = @strDocumentos + '''' + documento + ''','
			FROM @DocsTemp WHERE dataRow = @aux;
			SET @aux = @aux + 1;
		END

	SET @query2 = 'SELECT' + CHAR(13) +
		CHAR(9) + 'P.PAR_IDENPARA,' + CHAR(13) +
		CHAR(9) + 'P.PAR_DESCRIP1,' + CHAR(13) +
		CHAR(9) + 'VC.CCP_IDDOCTO,' + CHAR(13) +
		CHAR(9) + 'VD.CCD_IMPORTE' + CHAR(13) +
	'FROM ' + '[' + @nombreBase + '].[DBO].[VIS_CONCAR01] AS VC,' + '[' + @nombreBase + '].[DBO].[VIS_CONCARDETA01] AS VD,' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] AS P' + CHAR(13) +
	'WHERE VC.CCP_IDDOCTO IN ( '+ SUBSTRING(@strDocumentos, 1, LEN(@strDocumentos) - 1) +' )' + CHAR(13) +
	'AND VC.CCP_TIPODOCTO = ''ANT''' + CHAR(13) +
	'AND VD.CCD_CONSCARTERA = VC.CCP_CONSCARTERA' + CHAR(13) +
	'AND VD.Vcd_Anno = VC.Vcc_Anno' + CHAR(13) +
	'AND P.PAR_TIPOPARA = ''FP''' + CHAR(13) +
	'AND P.PAR_IDENPARA = CCD_TIPOPAGO'

	INSERT INTO @tiposPagosTemp
	EXEC (@query2)

	DECLARE @dataTemp2 TABLE (PAR_IDENPARA VARCHAR(5), tipoPago VARCHAR(50), idPersona INT, documento VARCHAR(500), personaRazon VARCHAR(200), saldo NUMERIC(18,2), checado BIT, idDocumentoDevuelto INT, departamento VARCHAR(200), id_perTra INT, devFinal NUMERIC(18, 2), aplicaBPRO INT, idTrade INT, dineroOcupado NUMERIC(18, 2), docEstatus BIT, cartera VARCHAR(100), tipoDoc VARCHAR(100), efectivo INT );

	INSERT INTO @dataTemp2
	select distinct * from (
	SELECT 
		PT.PAR_IDENPARA, 
		PT.tipoPago, 
		DT.idPersona, 
		DT.documento, 
		DT.personaRazon, 
		PT.saldo, 
		CASE WHEN DT.tipoPago = PT.PAR_IDENPARA THEN DT.checado ELSE 0 END checado, 
		CASE WHEN DT.tipoPago = PT.PAR_IDENPARA THEN DT.idDocumentoDevuelto ELSE 0 END idDocumentoDevuelto, 
		DT.departamento, 
		CASE WHEN DT.tipoPago = PT.PAR_IDENPARA THEN DT.id_perTra ELSE null END id_perTra, 
		CASE WHEN DT.tipoPago = PT.PAR_IDENPARA THEN DT.devFinal ELSE 0 END devFinal, 
		CASE WHEN DT.tipoPago = PT.PAR_IDENPARA THEN DT.aplicaBPRO ELSE 0 END aplicaBPRO, 
		CASE WHEN DT.tipoPago = PT.PAR_IDENPARA THEN DT.idTrade ELSE null END idTrade, 
		DT.dineroOcupado, 
		CASE WHEN DT.tipoPago = PT.PAR_IDENPARA THEN DT.docEstatus ELSE 0 END docEstatus, 
		DT.cartera, 
		DT.tipoDoc, 
		DT.efectivo 
	FROM @dataTemp DT
	LEFT JOIN @tiposPagosTemp PT ON DT.documento = PT.documento ) x
	order by documento asc, tipoPago

	--SELECT * FROM @dataTemp
	--SELECT * FROM @dataTemp2 ORDER BY documento ASC
	--SELECT * FROM @tiposPagosTemp

	UPDATE di SET di.dineroOcupado = ISNULL(do.devfinal,0) 
	FROM @dataTemp2 di
	INNER JOIN
	(SELECT 
		documento, 
		SUM(devfinal) devfinal,
		PAR_IDENPARA
	FROM  @dataTemp2 d
	WHERE aplicaBPRO = 0 OR aplicaBPRO IS NULL
	GROUP BY documento, PAR_IDENPARA) do
	ON di.documento = do.documento AND di.PAR_IDENPARA = do.PAR_IDENPARA
	

	IF @idPerTra = 0
		BEGIN
			SELECT 
				idPersona,
				d.documento,
				personaRazon,
				MAX(saldo) saldo,
				CONVERT(BIT, 0) checado,
				0 iddocumentoDevuelto, 
				departamento,
				0 id_perTra,
				NULL devFinal,
				APLICABPRO,0 idTrade,
				0 dineroOcupado,
				max(saldo) - isnull(sum(devFinal),0) AS saldofinal,
				@cartera AS cartera,
				tipoDoc,
				PAR_IDENPARA,
				CASE WHEN tipoPago = 'C. EFECTIVO C.' THEN tipoPago ELSE SUBSTRING(tipoPago, 5, LEN(tipoPago)) END tipoPago,
				CASE WHEN (PAR_IDENPARA = 'EF' ) OR (PAR_IDENPARA = @tipoDePago) OR (PAR_IDENPARA = '39' ) THEN 0 ELSE 1 END efectivo --Poner el PAR_IDENPARA de la sucursal
				--CASE WHEN (PAR_IDENPARA = 'EF' AND departamento LIKE '%UNIDADES%') OR (PAR_IDENPARA = @tipoDePago) OR (PAR_IDENPARA = '39' AND departamento LIKE '%UNIDADES%') THEN 0 ELSE 1 END efectivo --Poner el PAR_IDENPARA de la sucursal
			FROM @dataTemp2 d
			WHERE idpersona = @idCliente and id_perTra IS NOT NULL  AND APLICABPRO = 0
			GROUP BY idPersona,d.documento,personaRazon,checado, departamento,APLICABPRO, cartera, tipoDoc, PAR_IDENPARA, tipoPago, efectivo

			UNION ALL

			SELECT 
				idPersona,
				d.documento,
				personaRazon,
				saldo,
				CONVERT(BIT,checado) checado,
				idDocumentoDevuelto,
				departamento,
				id_perTra,
				devFinal,
				aplicaBPRO,
				idTrade,
				dineroOcupado, 
				saldo - dineroOcupado + isnull(devFinal,0) AS saldofinal,
				@cartera AS cartera,
				tipoDoc,
				PAR_IDENPARA,
				CASE WHEN tipoPago = 'C. EFECTIVO C.' THEN tipoPago ELSE SUBSTRING(tipoPago, 5, LEN(tipoPago)) END tipoPago,
				CASE WHEN (PAR_IDENPARA = 'EF' ) OR (PAR_IDENPARA = @tipoDePago) OR (PAR_IDENPARA = '39' ) THEN 0 ELSE 1 END efectivo
			FROM @dataTemp2 d
			WHERE idTrade IS NULL AND idpersona = @idCliente AND dineroOcupado = 0
		END
	ELSE
		BEGIN
		--SELECT documento FROM @dataTemp WHERE idTrade = @idTraDe
			IF EXISTS (SELECT documento FROM @dataTemp WHERE idTrade = @idTraDe)
				BEGIN
				Print '1'
					SELECT * from (
					SELECT 
						idPersona,
						d.documento,
						personaRazon,
						saldo,
						CONVERT(BIT,checado) checado,
						idDocumentoDevuelto,
						departamento,
						id_perTra,
						devFinal,
						aplicaBPRO,
						idTrade,
						dineroOcupado, 
						CONVERT(NUMERIC(18, 2), saldo) - CONVERT(NUMERIC(18, 2), dineroOcupado) + CONVERT(NUMERIC(18, 2), devFinal) AS saldofinal,
						@cartera AS cartera,
						tipoDoc,
						PAR_IDENPARA,
						CASE WHEN tipoPago = 'C. EFECTIVO C.' THEN tipoPago ELSE SUBSTRING(tipoPago, 5, LEN(tipoPago)) END tipoPago,
						CASE WHEN (PAR_IDENPARA = 'EF' ) OR (PAR_IDENPARA = @tipoDePago) OR (PAR_IDENPARA = '39') THEN 0 ELSE 1 END efectivo
					FROM @dataTemp2 d WHERE idTrade = @idTrade AND docEstatus = 1

					UNION ALL
			
					SELECT distinct
						d.idPersona,
						d.documento,
						d.personaRazon,
						d.saldo,
						CONVERT(BIT, 0) checado,
						0 idDocumentoDevuelto,
						d.departamento,
						0 id_perTra,
						NULL devFinal,
						d.aplicaBPRO,
						0 idTrade,
						d.dineroOcupado, 
						d.saldo - d.dineroOcupado AS saldofinal,
						@cartera AS cartera,
						d.tipoDoc,
						d.PAR_IDENPARA,
						CASE WHEN d.tipoPago = 'C. EFECTIVO C.' THEN d.tipoPago ELSE SUBSTRING(d.tipoPago, 5, LEN(d.tipoPago)) END tipoPago,
						CASE WHEN (d.PAR_IDENPARA = 'EF') OR (d.PAR_IDENPARA = @tipoDePago) OR (d.PAR_IDENPARA = '39') THEN 0 ELSE 1 END efectivo
					FROM @dataTemp2 d 
					LEFT JOIN (SELECT * FROM @dataTemp2 d WHERE idTrade = @idTrade AND docEstatus = 1) d2
					ON d.documento = d2.documento AND d.PAR_IDENPARA = d2.PAR_IDENPARA
					WHERE d.idPersona = @idCliente AND d2.documento IS NULL
					) x WHERE x.id_perTra = @idPerTra 
				END
			ELSE
				BEGIN
					Print '2'
					SELECT * FROM (
					SELECT 
						idPersona,
						d.documento,
						personaRazon,
						MAX(saldo) saldo,
						CONVERT(BIT, 0) checado,
						0 iddocumentoDevuelto, 
						departamento,
						0 id_perTra,
						NULL devFinal,
						APLICABPRO,0 idTrade,
						0 dineroOcupado,
						max(saldo) - isnull(sum(devFinal),0) AS saldofinal,
						@cartera AS cartera,
						tipoDoc,
						PAR_IDENPARA,
						CASE WHEN tipoPago = 'C. EFECTIVO C.' THEN tipoPago ELSE SUBSTRING(tipoPago, 5, LEN(tipoPago)) END tipoPago,
						CASE WHEN (PAR_IDENPARA = 'EF' ) OR (PAR_IDENPARA = @tipoDePago) OR (PAR_IDENPARA = '39'  ) THEN 0 ELSE 1 END efectivo
					FROM @dataTemp2 d
					WHERE idpersona = @idCliente and id_perTra IS NOT NULL  AND APLICABPRO = 0
					GROUP BY idPersona,d.documento,personaRazon,checado, departamento,APLICABPRO, cartera, tipoDoc, PAR_IDENPARA, tipoPago, efectivo

					UNION ALL

					SELECT 
						idPersona,
						d.documento,
						personaRazon,
						saldo,
						CONVERT(BIT,checado) checado,
						idDocumentoDevuelto,
						departamento,
						id_perTra,
						devFinal,
						aplicaBPRO,
						idTrade,
						dineroOcupado, 
						saldo - dineroOcupado + isnull(devFinal,0) AS saldofinal,
						@cartera AS cartera,
						tipoDoc,
						PAR_IDENPARA,
						CASE WHEN tipoPago = 'C. EFECTIVO C.' THEN tipoPago ELSE SUBSTRING(tipoPago, 5, LEN(tipoPago)) END tipoPago,
						CASE WHEN (PAR_IDENPARA = 'EF') OR (PAR_IDENPARA = @tipoDePago) OR (PAR_IDENPARA = '39' ) THEN 0 ELSE 1 END efectivo
					FROM @dataTemp2 d
					WHERE idTrade IS NULL AND idpersona = @idCliente AND dineroOcupado = 0
					) x WHERE x.id_perTra = @idPerTra 
				END
		END
END
go

