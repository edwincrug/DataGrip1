
-- =============================================
-- Author:		<Jorge Conelly>
-- Create date: <27/02/2020>
-- Description:	<SP que elimina un vale>
-- [dbo].[DEL_VALE_SP] 74, 'ZM-NZA-UN-35-1'
-- =============================================
CREATE PROCEDURE [dbo].[DEL_VALE_SP] 
	@id INT,
	@idVale NVARCHAR(50)
AS
BEGIN
	
	DELETE FROM [Tramites].[Tramite].[vales] 
	WHERE id = @id
	AND idVale = @idVale

	SELECT success = 1, msg = 'Se elimino el vale correctamente';

END
go

