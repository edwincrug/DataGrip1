
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <31/03/2020>
-- Description:	<SP que trae la informacion del concepto>
-- [dbo].[SEL_ESTATUSCONCEPTOORDEN_SP]  4, 6, '555',2000
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ESTATUSCONCEPTOORDEN_SP] 
	@idempresa INT,
	@idsucursal INT,
	@idComprobacion VARCHAR (100),
	@montoComprobacion DECIMAL (18,2)
AS
BEGIN
	DECLARE @comprobaciones varchar (MAX),
			@SQLAgencia NVARCHAR(MAX),
			@nombreBDConsen varchar (100),
			@nombreBDOperativa varchar (100),
			@comprobado DECIMAL(18,2) = 0

			 SELECT @comprobaciones=   STUFF((
			 SELECT ',' + ''''+ ca.idComprobacionConcepto + ''''
			 from Tramite.ConceptoArchivo ca
			inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
			where  tc.idTramiteConcepto = @idComprobacion
			FOR XML PATH('')
			 ),1,1,'')
			 FROM Tramite.TramiteConcepto WHERE idTramiteConcepto = @idComprobacion
	
			select @nombreBDConsen = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_idempresa = @idempresa
			select @nombreBDOperativa = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
			
				--SET @SQLAgencia ='SELECT  @comprobado = sum(omd.omd_preciounitario)
				SET @SQLAgencia ='SELECT  @comprobado = sum(ca.total)
				from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
				inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
				inner join ['+@nombreBDOperativa+'].dbo.DSBPEncInfo poli on poli.Documento = om.odm_ordencompra
				inner join tramite.ConceptoArchivo ca on ca.idComprobacionConcepto =  omd.omd_producto COLLATE Modern_Spanish_CI_AS
				where  omd.omd_producto in ('+@comprobaciones+') and om.odm_ordencompra is not null'	
				print @SQLAgencia
				EXECUTE sp_executeSQL @SQLAgencia, N' @comprobado DECIMAL(18,2) OUTPUT',@comprobado OUTPUT 
				
				SET @comprobado = ISNULL(@comprobado,0) + @montoComprobacion;
select 
@comprobado as montoJustificado, 
case when  @comprobado = ti.importe then  1 
when @comprobado > ti.importe then 1
else 0  end as justificado,
case when @comprobado > ti.importe then @comprobado - ti.importe else 0  end as JustificoMas,
@idComprobacion idComprobacion
from Tramite.TramiteConcepto  tc
inner join [Tramite].[TramiteImporte] ti on ti.idTramiteConcepto = tc.idTramiteConcepto and ti.idTipoProceso = 2
where  tc.idTramiteConcepto = @idComprobacion

END


go

