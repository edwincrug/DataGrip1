
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <12/11/2019>
-- Description:	<SP Aumenta/Disminuye el Fondo Fijo>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_AUMENTODISMINUCIONFONDO_SP] 
	@id_perTra INT,
	@ADmonto NUMERIC(18,4),
	@tipo INT,
	@tomarVales INT
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	DECLARE @idFondo INT, @monto DECIMAL (18,4)
	Declare @idCambio INT
	SELECT @idFondo = id FROM Tramite.fondoFijo WHERE id_perTra = @id_perTra
	select @monto =traDe_devTotal  from tramiteDevoluciones where id_perTra = @id_perTra

	IF(@tomarVales = 1)
	BEGIN
	update v
	Set enviaReembolso = 1
	from Tramite.fondoFijo ff
	inner join Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	inner join Tramite.vales v on v.id = vff.idVales 
	where ff.id_perTra = @id_perTra and v.estatusVale in (2,3) 

	END

INSERT INTO [Tramite].[fondoFijoCambios]
		([idTablaFondoFijo]
		 ,[montoInicial]
		 ,[montoCambiado]
		 ,[RutaDocumento]
		 ,[fechaCambio]
		 ,[aumentoDecrementoFF])
    VALUES
		 (@idFondo
		 ,@monto
		 ,@ADmonto
		 ,''
		 ,GETDATE()
		 ,@tipo)

	SET @idCambio = SCOPE_IDENTITY()
	
	UPDATE Tramite.fondoFijo 
	SET AumentoDisminucion = @idCambio, Autorizado = 0
	WHERE id_perTra = @id_perTra 

	UPDATE tramiteDevoluciones
	SET esDe_IdEstatus = 4
	WHERE id_perTra = @id_perTra
			
	UPDATE personaTramite
	SET petr_estatus =13
	WHERE id_perTra = @id_perTra

	DECLARE @correo varchar (100), @nombreAutorizador varchar (100), @idAutorizador INT, @fondofijo varchar(100)
	select @idAutorizador = idAutorizador, @fondofijo = idFondoFijo from Tramite.fondoFijo where id_perTra = @id_perTra
	select 
	@correo = cu.usu_correo,
	--@correo = 'juan.peralta@coalmx.com',
	@nombreAutorizador = cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
	from Tramite.autorizadoresFondoFijo av
	inner join ControlAplicaciones..cat_usuarios cu on cu.usu_idusuario = av.idAutorizador
	where idAutorizador = @idAutorizador

	SELECT success = 1, msg = 'Se inserto correctamente', idPerTra = @id_perTra, idCambio = @idCambio ,
	correo = @correo, asunto = 'Aumento/Disminucion Fondo FIjo ' + @fondofijo,nombreAutorizador =  @nombreAutorizador,fondo = @fondofijo; 
END TRY
	BEGIN CATCH
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

