-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 25/06/2020
-- Modify: Juan Carlos
-- Modify date: 19/05/2020
-- Description:	SP para obtener los departamentos x fondo
-- =============================================
CREATE PROCEDURE [dbo].[SEL_AUTORIZADORESVALESXDEPARTAMENTO_SP]  
	@idEmpresa INT,
	@idSucursal INT,
	@idDepartamento INT
AS

BEGIN
	
--select 
--a.idAutorizador,
--u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as autorizador,
--u.usu_correo as correo
--from  Tramite.autorizadoresFondoFijo a 
--inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = a.idAutorizador
--where a.idEmpresa = @idEmpresa and a.idSucursal = @idSucursal and a.idDepartamento = @idDepartamento

select 
a.idAutorizador,
u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as autorizador,
u.usu_correo as correo
from  Tramite.cat_DepartamentosFF a 
inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = a.idAutorizador
where a.idEmpresa = @idEmpresa and a.idSucursal = @idSucursal and (a.idDepartamento = @idDepartamento OR a.idDepartamentoFF = @idDepartamento)


END


go

