
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/10/2019>
-- Description:	<SP que actualiza el estatus del vale>
-- [dbo].[UPD_ESTATUSNOTIFACTURA_SP]   37,3,''
-- =============================================
CREATE  PROCEDURE [dbo].[UPD_ACTUALIZAREEMBOLSOFF_SP] 
	@id_perTra INT,
	@idReembolso INT,
	@tipoUsuario INT,
	@monto DECIMAL (18,2)
AS
BEGIN

	IF(@tipoUsuario = 6)
	BEGIN
	DECLARE @idSiguiente INT = 7, @correo varchar (max)
	
	UPDATE [Tramite].[fondoFijoReembolso] 
	SET estatus =  2
	WHERE id= @idReembolso
	
	SELECT @correo =  STUFF((
	SELECT ';' + usu_correo
	from Tramite.UsuariosFondoFijo UF
    inner join Tramite.cat_usuariosFondoFijo cuf on uf.idUsuariosFondofijo = cuf.id
    inner join controlAplicaciones.dbo.cat_usuarios u on UF.idusuario = u.usu_idusuario
    where UF.idUsuariosFondofijo = @idSiguiente
    FOR XML PATH('')
	),1,1,'')
	
	SELECT 1 as success,@idReembolso as idReembolso, @correo as correo, @idSiguiente as tipoUsuario, 'Solicitud de Revisión Reembolso de Fondo Fijo' as asunto;

	END
	
	IF(@tipoUsuario = 7)
	BEGIN
	
	DECLARE @tipo INT
	
	select @tipo = idSalidaReembolso from [Tramite].[fondoFijoReembolso] WHERE id= @idReembolso
	
	UPDATE [Tramite].[fondoFijoReembolso] 
	SET estatus =  3
	WHERE id= @idReembolso
	
	--UPDATE ve
	--SET ve.estatusReembolso = 1
	--from tramite.fondofijo ff
	--inner join tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
	--inner join tramite.vales v on v.id = vff.idvales
	--inner join tramite.valesEvidencia ve on ve.idVales = v.id 
	--where ff.id_perTra = @id_perTra and ve.envioReembolso = 1 and ve.estatusReembolso is null 
	
	UPDATE tramite.fondofijo 
	SET montoDisponible = montoDisponible + @monto
	WHERE id_pertra = @id_perTra
	
	IF(@tipo = 1)
	BEGIN
	DECLARE @consecutivo INT = 0
	--select @consecutivo = count(id_cuenta) from cuentasTesoreriaFA where id_perTra = @id_perTra and tipo = 2
	--SET @consecutivo = @consecutivo +1;

	insert into cuentasTesoreriaFA (id_perTra, fechaInsercion, estatus,id_tipoTramite, tipo, consecutivo, monto)
	values (@id_perTra, GETDATE(),1, 1, 2, @idReembolso, @monto)

	END
	
	SELECT 
		1 as success,
		TD.id_perTra,
		TD.id_traDe,
		TD.id_empresa,
		TD.id_sucursal,
		TD.id_departamento,
		TD.PER_IDPERSONA,
		FFSE.idBancoSalida as efectivoBanco,
		FFSE.numCuentaSalida as efectivoCuenta,
		'FR' as identificador,
		FF.cuentaContable,
		FFSE.cuentaContableSalida,
		FF.idFondoFijo,
		D.dep_nombrecto,
		@tipo as tipo,
		bs.cuenta as bsNombre,
		bs.numeroCuenta as bsNumeroCuenta,
		bs.cuentaClabe as bsCuentaClabe,
		bs.cuentaContable as bsCuentaContable,
		be.cuenta as beNombre,
		be.numeroCuenta as beNumeroCuenta,
		be.cuentaClabe as beCuentaClabe,
		be.cuentaContable as beCuentaContable
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN Tramite.fondofijo FF ON FF.id_perTra = TD.id_perTra
	INNER JOIN Tramite.fondoFijoReembolso FFSE ON FFSE.idFondoFijo = FF.id and FFSE.id = @idReembolso
	INNER JOIN ControlAplicaciones.dbo.cat_departamentos D on D.dep_iddepartamento = TD.id_departamento
	INNER JOIN referencias.dbo.BancoCuenta bs on bs.idBanco = FFSE.idBancoSalida and bs.idEmpresa = FF.idEmpresa and FFSE.cuentaContableSalida = bs.cuentaContable
	LEFT JOIN referencias.dbo.BancoCuenta be on be.idBanco = FFSE.idBancoEntrada and be.idEmpresa = FF.idEmpresa and FFSE.cuentaContableEntrada = be.cuentaContable
	WHERE PT.id_perTra =  @id_perTra
	END
	

END

go

