-- =============================================
-- Author:		<Luis García>
-- Create date: <03/07/2019>
-- Description:	<Trae todas los departamentos por empresa y sucursal>
--TEST SEL_DOCUMENTOS_BY_TRAMITE_SP 4
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_BY_TRAMITE_SP]
     @idTramite INT
AS
BEGIN
	
	IF(@idTramite = 10)
	BEGIN
		SELECT 
			TD.id_tramite, 
			D.id_documento,
			D.doc_nomDocumento,
			E.ext_nombre,
			D.opcional
		FROM cat_tramiteDocumento TD 
		INNER JOIN cat_documentos D ON D.id_documento = TD.id_documento
		INNER JOIN cat_extensiones E ON D.id_extension = E.id_extension
		WHERE id_tramite = @idTramite 
		AND D.id_documento <> 64 
		AND D.id_documento <> 65;
	END
	ELSE IF(@idTramite = 4)
	BEGIN 
		SELECT
			TD.id_tramite, 
			D.id_documento,
			D.doc_nomDocumento,
			E.ext_nombre
			--D.opcional
			,CASE WHEN TD.mandatorioEfectivo = 1 OR TD.mandatorioBancario = 1 THEN 0 ELSE 1 END AS opcional
			,TD.efectivo
			,TD.mandatorioEfectivo
			,TD.bancario
			,TD.mandatorioBancario
			,TD.activo
		FROM cat_tramiteDocumento TD 
		INNER JOIN cat_documentos D ON D.id_documento = TD.id_documento
		INNER JOIN cat_extensiones E ON D.id_extension = E.id_extension
		WHERE id_tramite = @idTramite AND activo = 1
		AND D.id_documento <> 64 
		AND D.id_documento <> 65;
	END
	ELSE
	BEGIN
			SELECT
			TD.id_tramite, 
			D.id_documento,
			D.doc_nomDocumento,
			E.ext_nombre,
			D.opcional
		FROM cat_tramiteDocumento TD 
		INNER JOIN cat_documentos D ON D.id_documento = TD.id_documento
		INNER JOIN cat_extensiones E ON D.id_extension = E.id_extension
		WHERE id_tramite = @idTramite 
		AND D.id_documento <> 64 
	END 
END
go

