-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_EstatusCuenta_GET]
	@cuentaBancaria INT = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT 
		ca_plaza,
		ca_sucursal,
		ca_estatus,
		ca_banconombre,
		ca_cvebanxico,
		ca_idbanco,
		observaciones
	FROM [dbo].[cuentaAutorizada] 
	WHERE ca_cuenta = @cuentaBancaria 
	order by idCuentaAutorizada desc
	--AND ca_estatus = 3;
END
go

