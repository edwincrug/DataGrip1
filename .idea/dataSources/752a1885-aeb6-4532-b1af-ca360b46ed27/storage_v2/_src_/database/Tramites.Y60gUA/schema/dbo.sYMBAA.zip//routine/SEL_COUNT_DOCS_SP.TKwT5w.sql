-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_COUNT_DOCS_SP]
	@idPerTra INT,
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN

	DECLARE @nombreBase VARCHAR(30) = '',
			@query VARCHAR(MAX) = '';

	SELECT 
		 @nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SELECT 
		COUNT(DD.id_docDe) AS totalDocs
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN documentosDevueltos DD ON DD.id_traDe = TD.id_traDe
	WHERE PT.id_perTra = @idPerTra
	and dd.docDe_tipoPago = 'EF'

	SET @query = 'SELECT' + CHAR(13) +
		CHAR(9) + 'VC.CCP_CARTERA,' + CHAR(13) +
		CHAR(9) + 'DD.docDe_documento' + CHAR(13) +
	'FROM personaTramite PT' + CHAR(13) +
	'INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra' + CHAR(13) +
	'INNER JOIN documentosDevueltos DD ON DD.id_traDe = TD.id_traDe' + CHAR(13) +
	'INNER JOIN [' + @nombreBase + '].[dbo].[VIS_CONCAR01] VC ON VC.CCP_IDDOCTO = DD.docDe_documento COLLATE DATABASE_DEFAULT' + CHAR(13) +
	'WHERE PT.id_perTra =' + CONVERT(varchar(20), @idPerTra) + 'AND DD.docDe_tipoPago = ''EF'' AND VC.CCP_TIPODOCTO = ''ANT'''
	PRINT @query
	EXEC(@query)
END
go

