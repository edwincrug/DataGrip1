


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_BANCOS_FF_SP 3
-- =============================================
CREATE PROCEDURE [dbo].[SEL_BANCOS_FF_SP]
@id INT,
@idSucursal INT = 0
AS
BEGIN
--DECLARE @nombreBD VARCHAR(100)
--select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @id

--DECLARE @bancos NVARCHAR(MAX) = 'SELECT  PAR_DESCRIP2, PAR_DESCRIP4 FROM ['+@nombreBD+'].[dbo].[PNC_PARAMETR]
--WHERE PAR_TIPOPARA = ''CCHEQ'' and PAR_STATUS = ''A'''

--exec (@bancos)


SELECT 
	DISTINCT(bc.idBanco) AS IdBanco, 
	UPPER(bc.cuenta) AS Nombre,
	bc.Carga_Layout AS Layout ,
	bc.cuentaContable,
	bc.IdPersona,
	bc.numeroCuenta,
	bc.cuentaClabe,
	bc.convenio,
	bc.tipoCuenta,
	nombreBanco = banco.nombre
FROM referencias.dbo.Banco banco
INNER JOIN referencias.dbo.BancoCuenta bc
ON banco.idBanco = bc.idBanco
and bc.cuentaClabe is not null
WHERE bc.idEmpresa = @id
ORDER BY bc.idBanco asc
--IF(@id= 1)
--BEGIN
--SELECT 
--	DISTINCT(bc.idBanco) AS IdBanco, 
--	UPPER(bc.cuenta) AS Nombre,
--	bc.Carga_Layout AS Layout ,
--	bc.cuentaContable,
--	bc.IdPersona,
--	bc.numeroCuenta,
--	bc.cuentaClabe,
--	bc.convenio,
--	bc.tipoCuenta,
--	nombreBanco = banco.nombre
--FROM referencias.dbo.Banco banco
--INNER JOIN referencias.dbo.BancoCuenta bc
--ON banco.idBanco = bc.idBanco
--WHERE bc.idEmpresa = @id
--ORDER BY bc.idBanco asc
--END
--ELSE
--BEGIN
--SELECT 
--	DISTINCT(bc.idBanco) AS IdBanco, 
--	UPPER(bc.cuenta) AS Nombre,
--	bc.Carga_Layout AS Layout ,
--	bc.cuentaContable,
--	bc.IdPersona,
--	bc.numeroCuenta,
--	bc.cuentaClabe,
--	bc.convenio,
--	bc.tipoCuenta,
--	nombreBanco = banco.nombre
--FROM referencias.dbo.Banco banco
--INNER JOIN referencias.dbo.BancoCuenta bc ON banco.idBanco = bc.idBanco
--INNER JOIN Tramite.cat_CuentasContableBancosFFGV cbf ON LTRIM(RTRIM(cbf.cuenta)) = bc.cuentaContable
--WHERE bc.idEmpresa = @id and cbf.idsucursal = @idSucursal
--ORDER BY bc.idBanco asc
--END

END

go

