-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <04/08/2020>
-- Description:	<SP que obtiene los departamentos de las sucursales>
-- [dbo].[SEL_DEPARTAMENTOS_FF_TRAMITE_SP]  6
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOS_FF_TRAMITE_SP] 
	@idSucursal INT
AS
BEGIN

DECLARE @nombreBD varchar (100), @query VARCHAR(MAX) = ''

select @nombreBD = suc_nombrebd from controlaplicaciones.dbo.cat_sucursales where suc_idsucursal = @idSucursal

SET @query = 'SELECT distinct par.PAR_IDENPARA,par.PAR_DESCRIP1 
FROM [' + @nombreBD + '].[DBO].[CON_CONFCONTA] cc
INNER JOIN  [' + @nombreBD + '].[DBO].[PNC_PARAMETR] par on  cc.CNC_CONCEPTO1 = par.par_idenpara
WHERE PAR_TIPOPARA = ''AREPED''
AND CNC_CONCEPTO = ''COMPRA'' 
AND  LEFT (CNC_CUENTA,4) = ''600'' + (select Convert(char(1),consecutivo_contable) from Centralizacionv2.dbo.DIG_CAT_BASES_BPRO where suc_idsucursal = '  +  CAST(@idSucursal AS NVARCHAR(10))+')
ORDER BY 2'
print @query

EXECUTE (@query)

END
go

