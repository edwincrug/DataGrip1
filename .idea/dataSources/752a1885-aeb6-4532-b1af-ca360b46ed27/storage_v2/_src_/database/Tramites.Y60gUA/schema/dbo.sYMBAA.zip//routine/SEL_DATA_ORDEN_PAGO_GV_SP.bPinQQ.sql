-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [SEL_DATA_ORDEN_PAGO_GV_SP] 3043,4,1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATA_ORDEN_PAGO_GV_SP]
	@idPerTra INT,
	@tipoProceso INT = 0,
	@consecutivoTramite INT = 0
AS
BEGIN
	--IF EXISTS( SELECT idTramiteGastosMas FROM [Tramite].[TramiteGastosMas] WHERE id_perTraPadre = @idPerTra )
	--	BEGIN
	--		SELECT @consecutivoTramite = MAX(consecutivo) FROM cuentasTesoreriaFA CT WHERE CT.id_perTra = @idPerTra and CT.tipo = @tipoProceso
	--	END


	SELECT 
		TD.id_perTra,
		TD.id_traDe,
		--sum(TI.importe) as traDe_devTotal,
		--sum(CT.monto) as traDe_devTotal,
		--(CT.monto) as traDe_devTotal,
		CASE WHEN TGM.id_cuenta IS NULL THEN CT.monto ELSE MAX(TGM.importeDeMas) END traDe_devTotal,
		TD.id_empresa,
		TD.id_sucursal,
		TD.id_departamento,
		CASE WHEN te.IdPersona IS NULL 
      THEN TD.PER_IDPERSONA 
    ELSE te.IdPersona END as PER_IDPERSONA,
		TC.idBancoSalida as efectivoBanco,
		TC.numCuentaSalida as efectivoCuenta,
		CT.estatus, 
		'GV' as identificador,
		TC.cuentaContableSalida,
		D.dep_nombrecto,
		CASE WHEN TGM.id_cuenta IS NULL THEN 0 ELSE 1 END EsTGM,
		ISNULL(TGM.id_cuenta, 0) id_cuenta
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN [Tramite].[TramiteConcepto] TC ON TC.idTramitePersona  = PT.id_perTra
	INNER JOIN  [Tramite].[TramiteImporte] TI ON TI.idTramiteConcepto = TC.idTramiteConcepto and TI.idTipoProceso = 2
	INNER JOIN cuentasTesoreriaFA CT ON CT.id_perTra = PT.id_perTra and CT.tipo = @tipoProceso and CT.consecutivo = @consecutivoTramite
	INNER JOIN ControlAplicaciones.dbo.cat_departamentos D on D.dep_iddepartamento = TD.id_departamento
	LEFT JOIN [Tramite].[TramiteGastosMas] TGM ON CT.id_cuenta = TGM.id_cuenta
    LEFT JOIN Tramites.Tramite.TramiteEmpleado te
    ON td.id_perTra = te.idTramiteDevolucion
	WHERE PT.id_perTra =  @idPerTra --and TC.procesadoOP is null
	GROUP BY TD.id_perTra, TD.id_traDe, TD.id_empresa, TD.id_sucursal, TD.id_departamento, TD.PER_IDPERSONA, TC.idBancoSalida,
	TC.numCuentaSalida, CT.estatus, TC.cuentaContableSalida, D.dep_nombrecto, CT.monto, TGM.id_cuenta,te.IdPersona
	
END
go

