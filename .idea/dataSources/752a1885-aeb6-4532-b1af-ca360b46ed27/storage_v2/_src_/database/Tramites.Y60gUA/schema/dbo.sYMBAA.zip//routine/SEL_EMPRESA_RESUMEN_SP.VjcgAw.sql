
CREATE PROCEDURE SEL_EMPRESA_RESUMEN_SP 
@idUsuario INT
AS
BEGIN
		SELECT DISTINCT E.emp_idempresa idEmpresa
						, E.emp_nombre  nombreEmpresa
		FROM ControlAplicaciones.dbo.cat_empresas E 
		INNER JOIN ControlAplicaciones.dbo.ope_organigrama O ON O.emp_idempresa = E.emp_idempresa 
		WHERE O.usu_idusuario = @idUsuario
END
go

