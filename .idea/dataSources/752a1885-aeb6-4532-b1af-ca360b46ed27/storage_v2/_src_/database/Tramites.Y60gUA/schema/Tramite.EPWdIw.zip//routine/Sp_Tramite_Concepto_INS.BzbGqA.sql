-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <03/09/2019>
-- Description:	<Almacena el concepto de una solicitud>
--TEST EXEC [Tramite].[Sp_Tramite_Concepto_INS]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_Concepto_INS] 
	@idEstatus INT,
	@idConceptoContable INT,
	@importe DECIMAL(18, 2),
	@comentario VARCHAR(150),
	@idUsuario INT,
	@idTipoProceso INT,
	@idSolicitud INT,
	@areaAfectacion VARCHAR(10),
	@numeroCuenta VARCHAR(20),
	@idTipoViaje int = 1,
	@distancia int = 0
AS
BEGIN 

	SET NOCOUNT ON;
	
	DECLARE @idTramiteConcepto INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_Concepto_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
		IF (@idTipoProceso = 0) 
		BEGIN
			UPDATE [dbo].[personaTramite] SET petr_estatus = 0 
			WHERE id_perTra = @idSolicitud			
		END 
		IF (@idTipoProceso = 1) 
		BEGIN
			UPDATE [dbo].[personaTramite] SET petr_estatus = 1
			WHERE id_perTra = @idSolicitud
			UPDATE [dbo].[tramiteDevoluciones] SET esDe_idEstatus = 1
			WHERE id_perTra = @idSolicitud
		END 
		IF (@idTipoProceso = 3) 
		BEGIN
			UPDATE [dbo].[personaTramite] SET petr_estatus = 8 
			WHERE id_perTra = @idSolicitud			
		END 

		INSERT INTO [Tramite].[TramiteConcepto] (idEstatus, idTramitePersona, idConceptoContable, fechaRegistro, idTipoProceso, areaAfectacion, numeroCuenta, idTipoViaje, distanciaKilometros)
		VALUES (@idEstatus, @idSolicitud, @idConceptoContable, GETDATE(), @idTipoProceso, @areaAfectacion, @numeroCuenta, @idTipoViaje, @distancia)		
		      
		SET @idTramiteConcepto = SCOPE_IDENTITY()

		INSERT INTO [Tramite].[TramiteImporte] (importe, idTramiteConcepto, idUsuario, idTipoProceso)
		VALUES (@importe, @idTramiteConcepto, @idUsuario, @idTipoProceso)

		IF(COALESCE(@comentario, '') != '')
		BEGIN
			INSERT INTO [Tramite].[TramiteComentario] (comentario, idTramiteConcepto, idUsuario, idTipoProceso)
			VALUES (@comentario, @idTramiteConcepto, @idUsuario, @idTipoProceso)
		END

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @idTramiteConcepto AS [resultado]
END
go

