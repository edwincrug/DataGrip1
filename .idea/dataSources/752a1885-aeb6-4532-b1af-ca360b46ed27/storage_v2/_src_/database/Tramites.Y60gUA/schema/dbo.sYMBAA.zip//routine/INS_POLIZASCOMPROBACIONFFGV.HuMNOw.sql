


-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [INS_POLIZASCOMPROBACIONFFGV] 
-- =============================================
CREATE PROCEDURE [dbo].[INS_POLIZASCOMPROBACIONFFGV] 
	@id_perTra INT,
	@idVale INT,
	@idComprobacionVale INT,
	@idTramiteConcepto INT,
	@idComprobacionConcepto INT,
	@monto DECIMAL (18,2),
	@idTramite INT
AS
BEGIN
	
	INSERT INTO [Tramite].[PolizasCompFFGV](id_perTra,idVale,idComprobacionVale,idTramiteConcepto,idComprobacionConcepto,monto,idTramite,fechaCreacion)
	VALUES (@id_perTra, @idVale, @idComprobacionVale, @idTramiteConcepto, @idComprobacionConcepto, @monto, @idTramite, GETDATE())
	
	SELECT 1 success
END
go

