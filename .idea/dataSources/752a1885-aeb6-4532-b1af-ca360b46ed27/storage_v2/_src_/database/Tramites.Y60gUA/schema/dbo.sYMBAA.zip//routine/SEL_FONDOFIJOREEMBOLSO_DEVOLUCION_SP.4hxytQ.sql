-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <16/10/2019>
-- Description:	<SP que manda a reembolso el FF>
-- [dbo].[SEL_FONDOFIJOREEMBOLSO_TRAMITE_SP]  
-- =============================================

-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 10/08/2020
-- Description:	Se creo con base al SP [dbo].[SEL_FONDOFIJOREEMBOLSO_TRAMITE_SP] omitiendo el Update @idPerTraReembolso
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJOREEMBOLSO_DEVOLUCION_SP] 
	@id_traDe INT,
	@idUsuario INT,
	@monto decimal(18,4)
AS
BEGIN
	DECLARE @id_perTra INT;
	DECLARE @idPerTraReembolso INT;
	
	DECLARE @idDepartamento INT, @idEmpresa INT, @idSucursal INT, @idPersona INT 
	SELECT @id_perTra = id_perTra,  @idDepartamento = id_departamento, @idEmpresa = id_empresa, @idSucursal = id_sucursal, @idPersona = PER_IDPERSONA FROM tramiteDevoluciones WHERE id_traDe = @id_traDe

	UPDATE tramiteDevoluciones
	SET esDe_IdEstatus = 5
	WHERE id_traDe = @id_traDe

	UPDATE Tramite.fondoFijo
	SET estatusFondoFijo = 2--, idReembolso = null
	WHERE id_perTra = @id_perTra

	INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus])
     VALUES
           (@idUsuario
           ,16
           ,GETDATE()
           ,1)

	SET @idPerTraReembolso = SCOPE_IDENTITY()

		INSERT INTO [dbo].[tramiteDevoluciones]
           ([id_perTra]
           ,[id_formaPago]
           ,[id_departamento]
		   ,[traDe_devTotal]
           ,[traDe_Observaciones]
           ,[id_empresa]
           ,[id_sucursal]
		   ,[PER_IDPERSONA]
		   ,[esDe_IdEstatus])
     VALUES
           (@idPerTraReembolso
           ,1
           ,@idDepartamento
		   ,@monto
           ,'Reembolso de fondo Fijo ' +  CONVERT(VARCHAR(20),@id_perTra)
           ,@idEmpresa
           ,@idSucursal
		   ,@idPersona
		   ,5)
	
	SELECT success = 1, id_perTraReembolso = @idPerTraReembolso
END



go

