-- =============================================      
-- Author:  <Luis Garcia>      
-- Create date: <10/06/2019>      
-- Description: <Guarda el documento qe subio la persona>      
-- TEST INS_DOCUMENTO_PERSONTA_DETALLE_SP 67, 2, 3  ,11   
-- =============================================      
    
CREATE PROCEDURE [dbo].[INS_DOCUMENTO_PERSONTA_DETALLE_SP]      
 @idProspecto INT = 0,      
 @idTipoProspecto INT,      
 @idTramite INT,      
 @idDocumento INT,
 @id_PerTra INT = NULL,
 @numCuentas INT = 0,
 @idBanxico VARCHAR(20) = '',
 @banco		VARCHAR(50) = '',
 @rfc		VARCHAR(50) = '',
 @cuentaBancaria VARCHAR(50) = '',
 @clabe VARCHAR(50) = ''
AS      
BEGIN 

--DECLARE		@idProspecto INT = 12 ,      
--			@idTipoProspecto INT = 1,      
--			@idTramite INT = 1,      
--			@idDocumento INT = 9 ,
--			@id_PerTra INT = 12,
--			@numCuentas INT = 3,
--			@idBanxico VARCHAR(20) = '127',
--			@banco		VARCHAR(50) = 'AZTECA'


--  begin tran   
 DECLARE  @idPerTra INT      
   ,@idTraDo INT      
   ,@idPersona INT --= (SELECT id_persona FROM personas WHERE id_Prospecto = @idProspecto AND id_TipoProspecto =  @idTipoProspecto  )      

 IF(@rfc='')
 BEGIN
 	SELECT @idPersona =  id_persona FROM personas WHERE id_Prospecto = @idProspecto AND id_TipoProspecto =  @idTipoProspecto  
 END
 ELSE
 BEGIN
 	SELECT @idPersona =  id_persona FROM personas WHERE per_rfc = @rfc --AND id_TipoProspecto =  @idTipoProspecto  
 END



         
 DECLARE @rutaSave VARCHAR(500);  
 DECLARE @totalDocs INT, @totalUp INT;     
       
    IF(@idTipoProspecto <>  2)
	BEGIN  
		 IF EXISTS (SELECT id_perTra FROM personaTramite WHERE id_persona = @idPersona AND id_tramite = @idTramite AND petr_estatus not in (2,3)) --- Discriminar los estatus rechazado  
		  BEGIN      
				   SELECT  @idPerTra =  id_perTra       
				   FROM personaTramite       
				   WHERE id_persona = @idPersona AND id_tramite = @idTramite   AND petr_estatus not in (2,3)   --- Discriminar los estatus rechazado 
				    
				   IF(@idDocumento<>9)
				   BEGIN
						IF EXISTS (SELECT id_traDo FROM cat_tramiteDocumento WHERE id_documento = @idDocumento AND id_tramite = @idTramite)      
						BEGIN      
							 SELECT       
							  @idTraDo = id_traDo       
							 FROM cat_tramiteDocumento       
							 WHERE id_documento = @idDocumento AND id_tramite = @idTramite      
      
								-----------------------------------------------------------------------------------------------      
							 IF NOT EXISTS (SELECT det_idPerTra FROM detallePersonaTramite WHERE id_perTra = @idPerTra AND id_traDo = @idTraDo)      
							  BEGIN      
          
									SELECT @rutaSave = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'      
      
									INSERT INTO [dbo].[detallePersonaTramite]      
											([id_perTra]      
											,[id_traDo]      
											,[det_estatus]      
											,[det_observaciobes])      
										 VALUES      
											(@idPerTra      
											,@idTraDo      
											,1      
											,'')      
      
									SELECT       
										@totalDocs = COUNT(id_tramite)       
									FROM cat_tramiteDocumento       
									WHERE id_tramite =@idTramite     
      
									SELECT       
										@totalUp = COUNT(id_perTra)       
									FROM detallePersonaTramite       
									WHERE id_perTra = @idPerTra     
									
																		 
      
									IF( @totalUp = @totalDocs )      
										BEGIN      
										 UPDATE personaTramite      
										 SET petr_estatus = 0, petr_fechaTramite = GETDATE()      
										 WHERE id_perTra = @idPerTra      
										END      
      
									SELECT success = 1, msg = 'Se inserto el documento con éxito.', rutaSave = @rutaSave , id_PerTra = @idPerTra;        
							  END      
							 ELSE      
								  BEGIN      
									   IF EXISTS( SELECT det_idPerTra FROM detallePersonaTramite WHERE id_perTra = @idPerTra AND id_traDo = @idTraDo AND det_estatus = 3 )      
										BEGIN      
										 SELECT @rutaSave = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'      
      
										 UPDATE detallePersonaTramite      
										 SET det_estatus = 1, det_observaciobes = ''      
										 WHERE id_perTra = @idPerTra AND id_traDo = @idTraDo AND det_estatus = 3      
      
										 SELECT success = 2, msg = 'El documento se actualizo', rutaSave = @rutaSave ,id_PerTra = @idPerTra;    
										END      
									   ELSE      
										BEGIN      
										 SELECT success = 3;      
										END      
								  END      
							 END      
						ELSE      
							BEGIN      
							 SELECT success = 0, msg = 'No existe ese documento para le tramite que solicita'      
							END 
				   END
				   ELSE
				   BEGIN
				  
							 IF NOT EXISTS (SELECT 1 FROM detallePersonaCuenta WHERE id_perTra = @idPerTra AND idBanxico = @idBanxico)      
							  BEGIN  
									DECLARE @idDoc INT = (SELECT id_traDo FROM  cat_tramiteDocumento WHERE id_tramite = @idTramite and id_documento = 9    )
									DECLARE @docsCompletos INT
											,@totalUpCuentas INT
											,@totalUpCuentasCompletas INT
									IF NOT EXISTS (SELECT det_idPerTra FROM detallePersonaTramite WHERE id_perTra = @idPerTra AND id_traDo = @idDoc)
									BEGIN
										 INSERT INTO [dbo].[detallePersonaTramite]      
											([id_perTra]      
											,[id_traDo]      
											,[det_estatus]      
											,[det_observaciobes])      
										 VALUES      
											(@idPerTra   
											,@idDoc  
											,1      
											,'')   
									END
									
							      
          
									SELECT @rutaSave = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'   
									
									INSERT INTO [dbo].[detallePersonaCuenta]
										   ([id_perTra]
										   ,[id_traDo]
										   ,[idBanxico]
										   ,[det_estatus]
										   ,[det_observaciobes]
										   ,[nombreBanco]
										   ,noCuenta
										   ,clabe)
									 VALUES
										   (@idPerTra   
										   ,@idDoc
										   ,@idBanxico
										   ,1
										   ,''
										   ,@banco
										   ,@cuentaBancaria
										   ,@clabe)
									
									
														   
      
									      
									SELECT       
										@totalDocs = COUNT(id_tramite)       
									FROM cat_tramiteDocumento       
									WHERE id_tramite = @idTramite     

									SET @docsCompletos= @totalDocs + @numCuentas

															
									SELECT       
										 @totalUp = COUNT(id_perTra)       
									FROM detallePersonaTramite       
									WHERE id_perTra = @idPerTra      

									SELECT       
										 @totalUpCuentas = COUNT(id_perTra)       
									FROM detallePersonaCuenta       
									WHERE id_perTra = @idPerTra 
									
									SET @totalUpCuentasCompletas  =  @totalUpCuentas+ @totalUp    
							
      
									IF( @totalUpCuentasCompletas = @docsCompletos )      
										BEGIN      
										 UPDATE personaTramite      
										 SET petr_estatus = 0, petr_fechaTramite = GETDATE()      
										 WHERE id_perTra = @idPerTra      
										END      
      
									SELECT success = 1, msg = 'Se inserto el documento con éxito.', rutaSave = @rutaSave , id_PerTra = @idPerTra;        
							  END      
							 ELSE      
								  BEGIN      
									   IF EXISTS( SELECT 1 FROM detallePersonaCuenta WHERE id_perTra = @idPerTra AND idBanxico = @idBanxico AND noCuenta = @cuentaBancaria AND det_estatus = 3 )      
										BEGIN      
										 SELECT @rutaSave = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'      
      
										 UPDATE detallePersonaCuenta      
										 SET det_estatus = 1, det_observaciobes = ''      
										 WHERE id_perTra = @idPerTra AND idBanxico = @idBanxico AND det_estatus = 3 
										 
										 UPDATE  detallePersonaTramite SET det_estatus = 1 where id_perTra = @idPerTra and id_traDo IN (select id_traDo from cat_tramiteDocumento where id_documento = 9)

										      
      
										 SELECT success = 2, msg = 'El documento se actualizo', rutaSave = @rutaSave ,id_PerTra = @idPerTra;    
										END      
									   ELSE      
										BEGIN      
										 SELECT success = 3;      
										END      
								  END      
							 END      
		   
		  END      
		 ELSE      
		  BEGIN      
		   SELECT success = 0, msg = 'No existe esa persona para el tramite que solicita'      
		  END   
  
     END 
	 ELSE
	 BEGIN
	  
	 -- CLIENTES
		       DECLARE @idRecPersona INT, @idPersonaIdentity INT,  @totalDocs2 INT, @totalUp2 INT;

			   SELECT @idTraDo = id_traDo FROM cat_tramiteDocumento  WHERE id_documento = @idDocumento AND id_tramite = @idTramite 
			   SELECT @rutaSave = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'           
                 
				  IF  (@id_PerTra = 0)
                    BEGIN
					 -- SI ES TRAMITE NUEVO LO INSERTA E INSERTA EL 1ER DOCUMENTO 
                        INSERT INTO [dbo].[personatramite] ([id_persona],[id_tramite],[petr_fechatramite],[petr_estatus])
                        VALUES  ( @idPersona,@idTramite,Getdate(),4)

						SET @id_PerTra  = Scope_identity()
						
						IF (@idTraDo > 0)      
						BEGIN   				
								IF NOT EXISTS (SELECT det_idPerTra FROM detallePersonaTramite WHERE id_perTra = @id_PerTra AND id_traDo = @idTraDo)      
								BEGIN            
									INSERT INTO [dbo].[detallePersonaTramite] ([id_perTra] ,[id_traDo] ,[det_estatus],[det_observaciobes])      
									VALUES  (@id_PerTra,@idTraDo,1 ,'')  
									
									DECLARE @idTraDoBci INT = 0
									SELECT @idTraDoBci = id_traDo FROM cat_tramiteDocumento  WHERE id_documento = 45 AND id_tramite = @idTramite 
									INSERT INTO [dbo].[detallePersonaTramite] ([id_perTra] ,[id_traDo] ,[det_estatus],[det_observaciobes])      
									VALUES  (@id_PerTra,@idTraDoBci,2 ,'')
								END
								
									
								

						    -- REGRESAMOS EL id_PerTra PARA IDENTIFICARLO EN CLIENTES
							SELECT success = 1, msg = 'Se registro el tramite correctamente del cliente', id_PerTra = @id_PerTra, rutaSave = @rutaSave;
						END
						ELSE
						BEGIN
							SELECT success = 0, msg = 'No existe ese documento para le tramite que solicita';
						END    
				 END
				 ELSE
				 BEGIN
				 -- ACTUALIZA 
						IF (@idTraDo > 0)      
						BEGIN   
						   	-- SI YA EXISTE REGISTRO DEL TRAMITRE AGREGAMOS NUEVOS DOCUMENTOS O ACTUALIZAMOS 					
							IF NOT EXISTS (SELECT det_idPerTra FROM detallePersonaTramite WHERE id_perTra = @id_PerTra AND id_traDo = @idTraDo)      
							BEGIN    
							
									INSERT INTO [dbo].[detallePersonaTramite] ([id_perTra] ,[id_traDo] ,[det_estatus],[det_observaciobes])      
									VALUES  (@id_PerTra,@idTraDo,1 ,'')   

									SELECT success = 1, msg = 'Se registro el tramite correctamente del cliente', id_PerTra = @id_PerTra, rutaSave = @rutaSave;   
							END
							ELSE
							BEGIN
									IF EXISTS( SELECT det_idPerTra FROM detallePersonaTramite WHERE id_perTra = @id_PerTra AND id_traDo = @idTraDo AND det_estatus = 3 ) 
									BEGIN
										UPDATE detallePersonaTramite      
										SET det_estatus = 1, det_observaciobes = ''      
										WHERE id_perTra = @id_PerTra AND id_traDo = @idTraDo AND det_estatus = 3      
      
										SELECT success = 2, msg = 'El documento se actualizo', rutaSave = @rutaSave  , id_PerTra = @id_PerTra;
									END  
									ELSE
									BEGIN
									 SELECT success = 3 , id_PerTra = @id_PerTra;   
									END
							END
						
						END
						ELSE
						BEGIN
										SELECT success = 0, msg = 'No existe ese documento para le tramite que solicita';
						END 
						


						IF(@idTramite = 3 or @idTramite = 6)
						BEGIN
							SELECT       
							@totalDocs = COUNT(TD.id_tramite)      
							FROM Tramites.dbo.cat_tramiteDocumento  TD
							INNER JOIN Tramites.dbo.cat_documentos D ON D.id_documento = TD.id_documento
							WHERE TD.id_tramite = @idTramite  AND TD.id_documento <> 11  AND TD.id_documento <> 50 AND D.opcional = 0
						END
						ELSE
						BEGIN
							SELECT       
							@totalDocs = COUNT(TD.id_tramite)       
							FROM cat_tramiteDocumento TD   
							INNER JOIN Tramites.dbo.cat_documentos D ON D.id_documento = TD.id_documento  
							WHERE TD.id_tramite = @idTramite AND TD.id_documento <> 11 AND D.opcional = 0
						END


	
						SELECT       
						@totalUp = COUNT(id_perTra)       
						FROM detallePersonaTramite       
						WHERE id_perTra = @id_PerTra      
      
						IF( @totalUp >= @totalDocs )      
						BEGIN      
							UPDATE personaTramite      
							SET petr_estatus = 0, petr_fechaTramite = GETDATE()      
							WHERE id_perTra = @id_PerTra      
						END 

						IF(@idTramite = 3 or @idTramite = 6)
						BEGIN
								IF(@idDocumento = 11 OR @idDocumento = 50 )
								BEGIN
										UPDATE detallePersonaTramite      
										SET det_estatus = 2      
										WHERE id_perTra = @id_PerTra AND id_traDo = @idTraDo 
								END      
						END
						ELSE
						BEGIN
							IF(@idDocumento = 11 )
							BEGIN
									UPDATE detallePersonaTramite      
									SET det_estatus = 2      
									WHERE id_perTra = @id_PerTra AND id_traDo = @idTraDo 
							END      
							 
						END	  
				 END 
				 -- FIN CLIENTES
	  END    
END 

--rollback TRAN
;
go

