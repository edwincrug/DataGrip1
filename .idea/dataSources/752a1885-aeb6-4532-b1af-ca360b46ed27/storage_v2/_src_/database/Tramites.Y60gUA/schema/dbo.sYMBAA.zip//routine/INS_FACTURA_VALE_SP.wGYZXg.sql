
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que inserta la factura>
-- =============================================
CREATE PROCEDURE [dbo].[INS_FACTURA_VALE_SP]
    @idVale NUMERIC(18,0),
	@numFactura VARCHAR(MAX),
	@uuid VARCHAR(MAX),
	@fechaFactura DATETIME,
	@subTotal DECIMAL(18,4),
	@iva DECIMAL(18,4),
	@total DECIMAL(18,4),
	--@xml VARCHAR(MAX),
	@rfcEmisor VARCHAR(MAX),
	@rfcEmisorRazon  VARCHAR(MAX),
	@rfcReceptor VARCHAR(MAX),
	@mesCorriente INT = 1,
	@tipoNotificacion INT = 0,
	@estatusNotificacion INT = 0
	
AS   
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY

	DECLARE @idFactura INT
	DECLARE @idFac INT, @idValeEvidencia INT, @subtotalFac DECIMAL(18,2), @montototal DECIMAL(18,2),@monto DECIMAL(18,2)  
	IF NOT EXISTS (SELECT 1 FROM tramites.Tramite.FacturaVale fv
	left join Tramites.Tramite.valesEvidencia ve on ve.idFactura = fv.id
	WHERE fv.uuid= @uuid and ve.idestatus in (1,2))
	BEGIN
	
	--410798
	DECLARE @PER_IDPERSONA INT = 0, @existe INT = 0
	
	IF  EXISTS (select  top 1 1 from GA_Corporativa..per_personas where per_rfc = @rfcEmisor)
	BEGIN
		select  top 1 @PER_IDPERSONA = PER_IDPERSONA  from GA_Corporativa..per_personas where per_rfc = @rfcEmisor
		SET @existe = 1
	END
	ELSE
	BEGIN
		SET @PER_IDPERSONA = 410798
	END


	--SET @subtotalFac = @subTotal
	--select @monto = monto from Tramite.valesEvidencia where id = @idVale
	--IF(@subtotalFac >= @monto)
	--BEGIN 
		INSERT INTO Tramite.FacturaVale(idValeEvidencia,numFactura,uuid,fechaFactura,subTotal,iva,total,fechaCreacion,rfcEmisor,rfcReceptor,PER_IDPERSONA, mesCorriente, tipoNotificacion, estatusNotificacion)
		VALUES(@idVale, @numFactura, @uuid, @fechaFactura, @subTotal, @iva, @total, GETDATE(), @rfcEmisor, @rfcReceptor,@PER_IDPERSONA, @mesCorriente, @tipoNotificacion, @estatusNotificacion);
		SET @idFactura = SCOPE_IDENTITY()
		UPDATE Tramite.valesEvidencia
		SET idfactura = @idFactura
		WHERE id = @idVale
		SELECT success = 1, msg = 'Se inserto correctamente', @existe existeProveedor
	--END
	--ELSE
	--BEGIN
	--	SELECT success = 3, msg = 'El monto de la factura no es suficiente';
	--END


	    --SELECT success = 1, msg = 'Se inserto correctamente', @existe existeProveedor

	  
	--		IF EXISTS (SELECT TOP 1 * FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_RFC = @rfcEmisor) 
	--		BEGIN
	--		SELECT TOP 1 @PER_IDPERSONA = PER_IDPERSONA FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_RFC = @rfcEmisor
	--		END
	--		ELSE
	--		BEGIN
	--			INSERT INTO GA_CORPORATIVA.DBO.PER_PERSONAS (
	--				 PER_NOMRAZON  
	--				,PER_RFC)
	--				VALUES
	--				(
	--				@rfcEmisorRazon,
	--				@rfcEmisor
	--				)
	--				SET @PER_IDPERSONA = SCOPE_IDENTITY()
	--DECLARE @Sucursales TABLE(id int identity(1,1),emp_idempresa INT,base nvarchar(200))
	--DECLARE @contR INT = 1
	--		,@bdRol VARCHAR(100)
	--		,@sqlRol VARCHAR(max)
	--		,@empId INT 
	--		,@usuario VARCHAR(10)
	--		,@idUsuario INT = 71
		
	--SELECT  @usuario = usu_nombreusu 
	--FROM	ControlAplicaciones.dbo.Cat_usuarios 
	--WHERE	usu_idusuario  = @idUsuario

	--INSERT INTO @Sucursales
	--SELECT emp_idempresa ,nombre_base  FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo != 3 


	--	WHILE(@contR <= (SELECT COUNT(1) FROM @Sucursales  ) )
	--	BEGIN
	--		SELECT @bdRol = base, @empId = emp_idempresa  FROM @Sucursales WHERE id = @contR

	--		IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @bdRol)) 
	--				BEGIN
	--						SET @sqlRol = ' INSERT INTO ' +@bdRol+'.[dbo].[PER_ROLES]
	--									([ROL_IDPERSONA]
	--									,[ROL_ROL]
	--									,[ROL_CVEUSU]
	--									,[ROL_FECHOPE]
	--									,[ROL_SUCURSAL]
	--									,[ROL_ESTATUS])
							
	--								SELECT '	+ CONVERT(VARCHAR(10),@PER_IDPERSONA)+ ' as ROL_IDPERSONA
	--											,''PVE''
	--											,''' + @usuario + ''' ROL_CVEUSU
	--											, CONVERT(VARCHAR(10), GETDATE(),103) ROL_FECHOPE
	--											, '''' ROL_SUCURSAL
	--											, 1 ROL_ESTATUS'
												
									
	--				EXEC (@sqlRol)
	--				END
	--		SET @contR = @contR +1
	--	END
	--END
			
END
	ELSE
		BEGIN
		--DECLARE @vale INT, @valeEvidencia INT
		--select @vale = EV.idVales from Tramite.FacturaVale FV 
		--inner join Tramite.valesEvidencia EV on EV.id = FV.idValeEvidencia
		--where FV.uuid = @uuid
		--select @valeEvidencia = idVales from Tramite.valesEvidencia where id = @idVale
		--IF(@vale = @valeEvidencia)
		--BEGIN
		SELECT success = 2, msg = 'La factura ya se encuentra registrada';
		--END
		--ELSE
		--BEGIN

		--select @idFac = id, @idValeEvidencia = idValeEvidencia, @subtotalFac = total  from Tramite.FacturaVale where uuid = @uuid
		--select @monto = monto from Tramite.valesEvidencia where id = @idVale
		--select @montototal = SUM(monto) + @monto from Tramite.valesEvidencia where idfactura = @idFac
		--IF(@subtotalFac >= @montototal)
		--BEGIN 
		--UPDATE Tramite.valesEvidencia
		--	SET idfactura = @idFac
		--	WHERE id = @idVale
		--	SELECT success = 1, msg = 'Se inserto correctamente', @existe existeProveedor
		--END
		--ELSE
		--BEGIN
		--SELECT success = 3, msg = 'El monto de la factura no es suficiente';
		--END
		
		--END	

		END
	
END TRY
	BEGIN CATCH
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END


go

