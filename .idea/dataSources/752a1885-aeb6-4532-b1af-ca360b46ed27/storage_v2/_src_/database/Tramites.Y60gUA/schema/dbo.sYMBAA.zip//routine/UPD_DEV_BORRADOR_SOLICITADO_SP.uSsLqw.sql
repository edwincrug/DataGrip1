-- =============================================
-- Author:		<Luis García>
-- Create date: <11/07/2019>
-- Description:	<Actualiza la el estaus del tramite del borrador a solicitado>
-- UPD_DEV_BORRADOR_SOLICITADO_SP 71
-- =============================================
CREATE PROCEDURE [dbo].[UPD_DEV_BORRADOR_SOLICITADO_SP]
	@idPerTra INT
AS
BEGIN
	DECLARE @estatusActual INT = (SELECT petr_estatus FROM personaTramite WHERE id_perTra = @idPerTra);
	
	IF(@estatusActual = 5)
		BEGIN
			UPDATE personaTramite
			SET petr_estatus = 6,
			petr_fechaTramite = GETDATE()
			WHERE id_perTra = @idPerTra

			update d
			set d.esDe_IdEstatus = 1
			FROM tramites.dbo.tramiteDevoluciones d
			where d.id_perTra = @idPerTra

			SELECT success = 1;
		END
	ELSE
		BEGIN
			SELECT success = 2;
		END
 END
go

