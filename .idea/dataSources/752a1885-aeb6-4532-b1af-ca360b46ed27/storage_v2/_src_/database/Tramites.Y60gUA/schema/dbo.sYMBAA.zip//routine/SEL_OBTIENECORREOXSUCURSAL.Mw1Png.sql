-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [SEL_OBTIENECORREOXSUCURSAL] 4,6
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENECORREOXSUCURSAL] 
	@idEmpresa INT,
	@idSucursal INT
	
AS
BEGIN
	DECLARE @idUsuario INT
	DECLARE @usu_correo VARCHAR(130)
	DECLARE @nombreUsuario VARCHAR(300)
	DECLARE @nivelFinanzas INT = 5


	--Obtener los datos del usuario al que se le va a notificar
	SELECT  @idUsuario =  cu.usu_idusuario,
			@usu_correo =  cu.usu_correo, 
		    @nombreUsuario = cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno
	FROM ControlAplicaciones.dbo.cat_usuarios cu
	inner join Tramites.[Tramite].[Reembolso_Autorizadores_FF] r on r.idUsuario = cu.usu_idusuario 
	WHERE r.idEmpresa = @idEmpresa and r.idSucursal = @idSucursal and r.nivelFinanzas = @nivelFinanzas
	
	SELECT @idUsuario idUsuario, @usu_correo correo, @nombreUsuario nombreUsuario
	
	
END



go

