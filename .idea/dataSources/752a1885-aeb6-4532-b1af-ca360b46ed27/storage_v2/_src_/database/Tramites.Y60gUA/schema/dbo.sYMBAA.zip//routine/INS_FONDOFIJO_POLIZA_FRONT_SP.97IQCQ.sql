

-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <13/01/2020>
-- Description:	<Inserta la poliza>
--  [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP] 2045, 6, 7, 'FF-ZM-NZA-OT-1-2-3', 350, '', 'OT', 0, '',''
-- ============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_POLIZA_FRONT_SP]
	@idusuario INT,
	@idsucursal INT,
	@tipoProceso INT,
	@documentoOrigen VARCHAR(100),
	@ventaUnitario numeric(18,2),
	@tipoProducto VARCHAR(100),
	@canal VARCHAR(100),
	@id_perTra INT = 0,
	@banco VARCHAR (100) = NULL,
	@departamento VARCHAR (100) = NULL

AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	--Parametros dentro SP
DECLARE @nombreBD VARCHAR(100),
		@nombreBDConsen VARCHAR(100),
	    @ipBD VARCHAR(100),
		@proceso VARCHAR(100),
		@fecha VARCHAR(100),
		@hora VARCHAR(100),
		@fiscalOInterna VARCHAR(100) = 'I',
		@referencia2 VARCHAR(100),
		@claveUsuario VARCHAR(100) = 'GMI',
		@subproducto VARCHAR(100) = '',
		@origen VARCHAR(100),
		@moneda VARCHAR(100) = 'PE',
		@idEncabezado INT = 0,
		@idDetalle INT = 0,
		@insertaEncabezado INT = 1,
		@insertaDet INT  = 1,
		@documento  VARCHAR(100) = '',
		@documentoAfectado  VARCHAR(100) = '',
		@estatusCartera   VARCHAR(100) = '',
		@persona1 INT = 0,
		@Count INT = 0,
		@referencia1  VARCHAR(100) = '',
		@referencia3  VARCHAR(100) = '',
		@tasaIVA INT = 0,
		@IVA DECIMAL(18,2) = 0,
		@QueryE NVARCHAR(MAX),
		@ventaO DECIMAL (18,2),
		@queryConcentradora NVARCHAR(MAX),
		@queryIVA NVARCHAR(MAX),
		@queryRetencion NVARCHAR(MAX),
		@retIVA DECIMAL (18,2) = 0,
        @retISR DECIMAL (18,2) = 0,
		@tasaRetIVA DECIMAL (18,2) = 0,
		@tasaRetISR DECIMAL (18,2) = 0,
		@tasaIVACal DECIMAL (18,2) = 16,
		@referenciaE2  VARCHAR(100),
		@referenciaE1  VARCHAR(100) = '',
		@tipoComprobante VARCHAR(100),
		@tipoIVA  VARCHAR(100),
		@Destino varchar (100) = '',
		@incremental INT = 0,
		@GV varchar(50),
		@emp_nombrecto  varchar(10),
		@suc_nombrecto  varchar(10),
		@dep_nombrecto  varchar(10),
		@idEmpresaGV INT,
		@idSucursalGV INT,
		@idDepartamentoGV INT,
		@idFondoFijo varchar(100),
		@idAnticipoGasto varchar(100),
		@porc varchar(50),
		@tasaIVACalculado INT,
		@esFactura INT,
		@complemento varchar(10),
		@cuentaContable varchar(50),
		@agenciaBD VARCHAR(100) = ''
		SET @documento = @documentoOrigen
	

select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
select @complemento = complemento from [Tramite].[cat_Polizas_FFAG] where idSucursal = @idsucursal
Select @fecha = CONVERT(varchar,GETDATE(),103) 
Select @hora = CONVERT(varchar,GETDATE(),108) 

SET @agenciaBD = @nombreBD;

---- 7.-Aplicación vale ----
IF(@tipoProceso = 7)
--Dos detalles
BEGIN

select @documento=  fv.ordenCompra from Tramite.FacturaVale fv
inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
where idComprobacionVale = @documentoOrigen

select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
where oce_folioorden= @documento

SET @subproducto = 'DD'
SET @proceso = 'AVFF' + @complemento
SET @referenciaE2 = @documento 
SET @referencia2 = @documentoOrigen
--SET @tipoProducto = @canal
SET @estatusCartera = 'ENTREGADO'
SET @ventaO = @ventaUnitario / 1.16
--SET @documentoAfectado = @documento
SET @referencia1 = @documento
SET @IVA = (@tasaIVACal/100) * @ventaO
SET  @Count = 1

select  @documentoAfectado = v.idVale from Tramite.valesEvidencia ve
inner join Tramite.vales v on v.id = ve.idVales
where idComprobacionVale = @documentoOrigen

select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'



--USUARIO QUE TRAMITA EL VALE
select  @persona1 = v.PER_IDPERSONA 
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
where ve.idComprobacionVale = @documentoOrigen
UPDATE tramite.valesEvidencia SET procesoPoliza = 1 WHERE idcomprobacionvale = @documentoOrigen
	
END

---- 8.-Comp. de más Autorizado ----
IF(@tipoProceso = 8)
BEGIN

--	SET @subproducto = 'PA'
--select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'
--	SET  @Count = 1
	
--select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
--INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
--where oce_folioorden= @documento


--SET @proceso = 'CVFR' + @complemento
--SET @referenciaE2 = @documento 
--SET @referencia2 = @documento  
--SET @estatusCartera = 'ENTREGADO'
--SET @tipoProducto = @canal
--SET @documentoAfectado = @documento
--SET @referencia1 = @documento
--SET @ventaO = @ventaUnitario / 1.16
--SET @IVA = (@tasaIVACal/100) * @ventaO
--select  @persona1 =  td.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
--where ve.idComprobacionVale =@documentoOrigen

select @documento=  fv.ordenCompra from Tramite.FacturaVale fv
inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
where idComprobacionVale = @documentoOrigen

SET @subproducto = 'PA'
select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'
SET  @Count = 1
	
select  @documentoAfectado = v.idVale from Tramite.valesEvidencia ve
inner join Tramite.vales v on v.id = ve.idVales
where idComprobacionVale = @documentoOrigen


select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
where oce_folioorden= @documento


SET @proceso = 'CVFR' + @complemento
SET @referenciaE2 = @documento 
SET @referencia2 = @documento  
SET @estatusCartera = 'ENTREGADO'
SET @tipoProducto = @canal
SET @documentoAfectado = @documento
SET @referencia1 = @documento
SET @ventaO = @ventaUnitario / 1.16
SET @IVA = (@tasaIVACal/100) * @ventaO
select  @persona1 =  td.PER_IDPERSONA 
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen




UPDATE tramite.valesEvidencia SET procesoPoliza = 1 WHERE idcomprobacionvale = @documentoOrigen

END

IF(@tipoProceso = 9)
BEGIN

--SET @subproducto = 'PA'
--select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'

--select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
--INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
--where oce_folioorden= @documento

----select *from [Tramite].[cat_TiposComprobantesFFGV] 	
--SET @proceso = 'CVFN' + @complemento
--SET @referenciaE2 = @documento  
--SET @referencia2 = @documento
--SET @estatusCartera = 'ENTREGADO'
--SET @tipoProducto = @canal
--SET @documentoAfectado = @documento
--SET @referencia1 = @documento
--SET @ventaO = @ventaUnitario / 1.16
--SET @IVA = (@tasaIVACal/100) * @ventaO

--select @documento=  fv.ordenCompra from Tramite.FacturaVale fv
--inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
--where idComprobacionVale = @documentoOrigen


select @documento=  fv.ordenCompra from Tramite.FacturaVale fv
inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
where idComprobacionVale = @documentoOrigen

SET @subproducto = 'PA'
select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'

select  @documentoAfectado = v.idVale from Tramite.valesEvidencia ve
inner join Tramite.vales v on v.id = ve.idVales
where idComprobacionVale = @documentoOrigen

select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
where oce_folioorden= @documento

--select *from [Tramite].[cat_TiposComprobantesFFGV] 	
SET @proceso = 'CVFN' + @complemento
SET @referenciaE2 = @documento  
SET @referencia2 = @documento
SET @estatusCartera = 'ENTREGADO'
SET @tipoProducto = @canal
SET @documentoAfectado = @documento
SET @referencia1 = @documento
SET @ventaO = @ventaUnitario / 1.16
SET @IVA = (@tasaIVACal/100) * @ventaO

UPDATE tramite.valesEvidencia SET procesoPoliza = 1 WHERE idcomprobacionvale = @documentoOrigen


END

---- 25.-DesAplicación vale ----
IF(@tipoProceso = 25)
--Dos detalles
BEGIN

select @documento=  fv.ordenCompra from Tramite.FacturaVale fv
inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
where idComprobacionVale = @documentoOrigen


select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
where oce_folioorden= @documento

SET @subproducto = 'DD'
SET @proceso = 'DAVFF' + @complemento
SET @referenciaE2 = @documento 
SET @referencia2 = @documentoOrigen
--SET @tipoProducto = @canal
SET @estatusCartera = 'ENTREGADO'
SET @ventaO = @ventaUnitario / 1.16
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @documentoAfectado = @documento
SET @referencia1 = @documento
SET  @Count = 1
select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'

--USUARIO QUE TRAMITA EL VALE
select  @persona1 = v.PER_IDPERSONA 
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
where ve.idComprobacionVale = @documentoOrigen
UPDATE tramite.valesEvidencia SET procesoPoliza = 1 WHERE idcomprobacionvale = @documentoOrigen
	
END

---- 26.-DES Comp. de más Autorizado ----
IF(@tipoProceso = 26)
BEGIN

--	SET @subproducto = 'PA'
--select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'
--	SET  @Count = 1

	
--	select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
--	INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
--	where oce_folioorden= @documento
select @documento=  fv.ordenCompra from Tramite.FacturaVale fv
inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
where idComprobacionVale = @documentoOrigen

SET @subproducto = 'PA'
select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'
SET  @Count = 1
	
select  @documentoAfectado = v.idVale from Tramite.valesEvidencia ve
inner join Tramite.vales v on v.id = ve.idVales
where idComprobacionVale = @documentoOrigen


select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
where oce_folioorden= @documento


SET @proceso = 'DCVFR' + @complemento
SET @referenciaE2 = @documento 
SET @referencia2 = @documento  
SET @estatusCartera = 'ENTREGADO'
SET @tipoProducto = @canal
SET @documentoAfectado = @documento
SET @referencia1 = @documento
SET @ventaO = @ventaUnitario / 1.16
SET @IVA = (@tasaIVACal/100) * @ventaO
select  @persona1 =  td.PER_IDPERSONA 
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen

UPDATE tramite.valesEvidencia SET procesoPoliza = 1 WHERE idcomprobacionvale = @documentoOrigen

END


IF(@tipoProceso = 27)
BEGIN


select @documento=  fv.ordenCompra from Tramite.FacturaVale fv
inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
where idComprobacionVale = @documentoOrigen

SET @subproducto = 'PA'
select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'

select  @documentoAfectado = v.idVale from Tramite.valesEvidencia ve
inner join Tramite.vales v on v.id = ve.idVales
where idComprobacionVale = @documentoOrigen

select @tipoProducto = d.dep_nombrecto from Cuentasxpagar.dbo.cxp_ordencompra o
INNER JOIN ControlAplicaciones.dbo.Cat_departamentos d on d.dep_iddepartamento = o.oce_iddepartamento
where oce_folioorden= @documento

--SET @subproducto = 'PA'
--select top 1 @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and abreviatura = 'FAC'
--select *from [Tramite].[cat_TiposComprobantesFFGV] 	
SET @proceso = 'DCVFN' + @complemento
SET @referenciaE2 = @documento  
SET @referencia2 = @documento
SET @estatusCartera = 'ENTREGADO'
SET @tipoProducto = @canal
SET @documentoAfectado = @documento
SET @referencia1 = @documento
SET @ventaO = @ventaUnitario / 1.16
SET @IVA = (@tasaIVACal/100) * @ventaO

END



SET @canal = @proceso

IF(@idsucursal = 1)
BEGIN
SET @agenciaBD = 'Cuautitlan'
END

IF(@idsucursal = 2)
BEGIN
SET @agenciaBD = 'Pedregal'
END

IF(@idsucursal = 3)
BEGIN
SET @agenciaBD = 'Universidad'
END

IF(@idsucursal = 25)
BEGIN
SET @agenciaBD = 'Infiniti'
END

IF(@idsucursal = 18)
BEGIN
SET @agenciaBD = 'Ermita'
END

IF(@idsucursal = 20)
BEGIN
SET @agenciaBD = 'Tlahuac'
END

IF(@idsucursal = 24)
BEGIN
SET @agenciaBD = 'Tepepan'
END

IF(@idsucursal = 22)
BEGIN
SET @agenciaBD = 'Cuautitlan'
END

IF(@idsucursal = 23)
BEGIN
SET @agenciaBD = 'Ecatepec'
END

IF(@idsucursal = 45)
BEGIN
SET @agenciaBD = 'Trasinmex'
END


DECLARE @insertEncabezado NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[DSBPEncInfo]
	  ([Agencia]
      ,[Proceso]
      ,[DocumentoOrigen]
      ,[Fecha]
      ,[Hora]
      ,[Canal]
      ,[NumeroControl]
      ,[Documento]
      ,[UUID]
      ,[EstatusContabilizacion]
      ,[EstatusCartera]
      ,[FiscalOInterna]
      ,[Referencia1]
      ,[Referencia2]
      ,[Referencia3]
      ,[ClaveUsuario]
      ,[FechaOperacion]
      ,[HoraOperacion]
      ,[FyHReg_EBp]
      ,[StatusFacturaDalton]
      ,[TipoPol]
      ,[ConsPol]
      ,[MesPol]
      ,[AñoPol]
      ,[EmpresaPol]
      ,[TS])
	  VALUES
	  ('''+@agenciaBD+'''
	  ,'''+@proceso+'''
	  ,'''+@documentoOrigen+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,'''+@canal+'''
	  ,''''
	  ,'''+@documento+'''
	  ,''''
	  ,0
	  ,'''+@estatusCartera+''' 
	  ,'''+@fiscalOInterna+'''
	  ,'''+@referenciaE1+'''
	  ,'''+@referenciaE2+'''
	  ,'''+@referencia3+'''
	  ,'''+@claveUsuario+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,GETDATE()
	  ,NULL
	  ,NULL
	  ,0
	  ,0
	  ,0
	  ,0
	  ,NULL)
'
print @insertEncabezado
EXEC(@insertEncabezado)
SET @idEncabezado = @@IDENTITY


DECLARE @insertDetalle NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[DSBPDetInfo]
	  ([Agencia]
      ,[Proceso]
      ,[DocumentoOrigen]
      ,[Fecha]
      ,[Hora]
      ,[Partida]
      ,[TipoProducto]
      ,[SubProducto]
      ,[Origen]
      ,[Destino]
      ,[Moneda]
      ,[TipoCambio]
      ,[Cantidad]
      ,[CostoUnitario]
      ,[VentaUnitario]
      ,[DescuentoUnitario]
      ,[TasaIva]
      ,[IVA]
      ,[ISAN]
      ,[RetIVA]
      ,[RetISR]
      ,[IEPS]
      ,[Persona1]
      ,[Persona2]
      ,[DocumentoAfectado]
      ,[Referencia1]
      ,[Auto]
      ,[Version]
      ,[Color]
      ,[AnioAuto]
      ,[VIN]
      ,[FyHRegDet]
      ,[Referencia2]
      ,[TasaRetIva]
      ,[TasaRetIsr]
      ,[AntiTipoPol]
      ,[AntiConsPol]
      ,[AntiMesPol]
      ,[AntiAñoPol]
      ,[AntiEmpresaPol]
      ,[Importado]
      ,[UUID]
      ,[UUIDNOMBREPDF]
      ,[UUIDNOMBREXML]
      ,[UUIDRUTAPDF]
      ,[UUIDRUTAXML]
      ,[FechaVencimientoDS]
      ,[ISN]
      ,[TasaRetISN])
VALUES
	  ('''+@agenciaBD+'''
	  ,'''+@proceso+'''
	  ,'''+@documentoOrigen+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,'''+ CONVERT(VARCHAR(10),@Count)+'''  
	  ,'''+@tipoProducto+''' 
	  ,'''+@subproducto+'''
	  ,'''+@origen+''' 
	  ,'''+@Destino+''' 
	  ,'''+@moneda+''' 
	  ,1
	  ,1
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@ventaUnitario)+'''
	  ,0 
	  ,'''+ CONVERT(VARCHAR(10),@tasaIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@IVA)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@retIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@retISR)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@persona1)+''' 
	  ,0
	  ,'''+@documentoAfectado+'''  
	  ,'''+ @referencia1+''' 
	  ,''''
	  ,''''
	  ,''''
	  ,''''
	  ,''''
	  ,GETDATE()
	  ,'''+@referencia2+'''  
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetISR)+'''
	  ,''''
	  ,0
	  ,0
	  ,0
	  ,''''
	  ,0
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL)
'


IF(@tipoProceso = 7)
BEGIN

select @idFondoFijo = idfondoFijo from tramite.fondofijo where id_perTra = @id_perTra
SET @subproducto = 'PA'
SET @documentoAfectado = @documento
--PERSONA Factura
select @persona1 = fv.PER_IDPERSONA from Tramite.FacturaVale fv
inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
where idComprobacionVale = @documentoOrigen
SET @Count = 2 -- segundo registro
END

IF(@tipoProceso = 8)
BEGIN

select
@persona1 =  td.PER_IDPERSONA,
@cuentaContable = ff.cuentaContable
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen


select
@documentoAfectado = ff.idfondofijo
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen

select top 1  @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal and idpersona = @persona1 and cuenta = @cuentaContable order by id asc

--select top 1  @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal order by id asc
--select  @persona1 =  td.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
--where ve.idComprobacionVale =@documentoOrigen
SET @Count = 2
END

IF(@tipoProceso = 25)
BEGIN

select @idFondoFijo = idfondoFijo from tramite.fondofijo where id_perTra = @id_perTra
SET @subproducto = 'PA'
select
@persona1 =  td.PER_IDPERSONA,
@cuentaContable = ff.cuentaContable
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen

select
@documentoAfectado = ff.idfondofijo
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen


SET @subproducto = 'PA'
--PERSONA Factura
select @persona1 = fv.PER_IDPERSONA from Tramite.FacturaVale fv
inner join Tramite.valesEvidencia ve on ve.idfactura = fv.id
where idComprobacionVale = @documentoOrigen
SET @Count = 2 -- segundo registro
END

IF(@tipoProceso = 26)
BEGIN
select
@persona1 =  td.PER_IDPERSONA,
@cuentaContable = ff.cuentaContable
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen

select
@documentoAfectado = ff.idfondofijo
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen

select top 1  @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal and idpersona = @persona1 and cuenta = @cuentaContable order by id asc

--select top 1  @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal order by id asc
--select  @persona1 =  td.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
--where ve.idComprobacionVale =@documentoOrigen
SET @Count = 2
END


DECLARE @insertDetalle2 NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[DSBPDetInfo]
	  ([Agencia]
      ,[Proceso]
      ,[DocumentoOrigen]
      ,[Fecha]
      ,[Hora]
      ,[Partida]
      ,[TipoProducto]
      ,[SubProducto]
      ,[Origen]
      ,[Destino]
      ,[Moneda]
      ,[TipoCambio]
      ,[Cantidad]
      ,[CostoUnitario]
      ,[VentaUnitario]
      ,[DescuentoUnitario]
      ,[TasaIva]
      ,[IVA]
      ,[ISAN]
      ,[RetIVA]
      ,[RetISR]
      ,[IEPS]
      ,[Persona1]
      ,[Persona2]
      ,[DocumentoAfectado]
      ,[Referencia1]
      ,[Auto]
      ,[Version]
      ,[Color]
      ,[AnioAuto]
      ,[VIN]
      ,[FyHRegDet]
      ,[Referencia2]
      ,[TasaRetIva]
      ,[TasaRetIsr]
      ,[AntiTipoPol]
      ,[AntiConsPol]
      ,[AntiMesPol]
      ,[AntiAñoPol]
      ,[AntiEmpresaPol]
      ,[Importado]
      ,[UUID]
      ,[UUIDNOMBREPDF]
      ,[UUIDNOMBREXML]
      ,[UUIDRUTAPDF]
      ,[UUIDRUTAXML]
      ,[FechaVencimientoDS]
      ,[ISN]
      ,[TasaRetISN])
VALUES
	  ('''+@agenciaBD+'''
	  ,'''+@proceso+'''
	  ,'''+@documentoOrigen+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,'''+ CONVERT(VARCHAR(10),@Count)+'''  
	  ,'''+@tipoProducto+''' 
	  ,'''+@subproducto+'''
	  ,'''+@origen+''' 
	  ,'''+@Destino+''' 
	  ,'''+@moneda+''' 
	  ,1
	  ,1
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@ventaUnitario)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@tasaIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@IVA)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@retIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@retISR)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@persona1)+''' 
	  ,0
	  ,'''+@documentoAfectado+'''  
	  ,'''+ @referencia1+''' 
	  ,''''
	  ,''''
	  ,''''
	  ,''''
	  ,''''
	  ,GETDATE()
	  ,'''+@referencia2+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetISR)+'''
	  ,''''
	  ,0
	  ,0
	  ,0
	  ,''''
	  ,0
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL)
'

print @insertDetalle
EXEC(@insertDetalle)
SET @idDetalle = @@IDENTITY


IF( @tipoProceso = 7 or @tipoProceso = 8 or @tipoProceso = 25 or @tipoProceso = 26)
BEGIN
print @insertDetalle2
EXEC(@insertDetalle2)
END

select @idEncabezado idEncabezado, @idDetalle idDetalle
	
	END TRY
	BEGIN CATCH
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH
	SET NOCOUNT OFF;
END


go

