

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_ORDEN_PAGO_VALIDA_CUENTA_FA_SP]
	@idPerTra INT,
	@tipoProceso INT = 0,
	@consecutivoTramite INT = 0
AS
BEGIN
	BEGIN TRANSACTION
		BEGIN TRY
			--SE agrega para identificar el tramite
			--DECLARE  @id_tramite INT;
			--SELECT @id_tramite = PT.id_tramite
			--FROM personaTramite PT
			--INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
			--WHERE PT.id_perTra = @idPerTra


		
			UPDATE cuentasTesoreriaFA SET  estatus = 3 WHERE id_perTra = @idPerTra and tipo = @tipoProceso and consecutivo =  @consecutivoTramite;
			

			SELECT success = 1;
	COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
		SELECT success = 0;
	END CATCH
END



go

