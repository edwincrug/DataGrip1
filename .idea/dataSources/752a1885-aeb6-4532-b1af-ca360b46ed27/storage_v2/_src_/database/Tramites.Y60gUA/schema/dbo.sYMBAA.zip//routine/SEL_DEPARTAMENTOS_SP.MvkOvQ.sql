-- =============================================
-- Author:		<Luis García>
-- Create date: <03/07/2019>
-- Description:	<Trae todas los departamentos por empresa y sucursal>
--TEST SEL_DEPARTAMENTOS_SP 1, 1 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOS_SP]
     @idEmpresa INT = 0
    ,@idSucursal INT = 0
AS
BEGIN
	SELECT 
		dep_iddepartamento AS idDepartamento
		,dep_nombre AS nombre
		,dep_nombrecto AS nombreCorto
		,emp_idempresa
		,suc_idsucursal
	FROM   ControlAplicaciones.dbo.cat_departamentos 
	WHERE  emp_idempresa = @idempresa AND suc_idsucursal = @idsucursal and dep_nombrecto in ('UN','US','RE','SE','OT','ACN','ACS')
	--dep_nombrecto in ('UN','US','RE','SE','OT','ACN','ACS')
END

go

