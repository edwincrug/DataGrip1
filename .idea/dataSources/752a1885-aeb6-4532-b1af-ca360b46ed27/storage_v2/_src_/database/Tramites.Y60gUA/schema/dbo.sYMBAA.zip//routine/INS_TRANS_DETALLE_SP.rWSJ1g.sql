-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_TRANS_DETALLE_SP]
	-- Add the parameters for the stored procedure here
		@idDocumento INT,
	@idTramite INT,
	@idPerTra INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @idTrado INT = (SELECT id_traDo FROM cat_tramiteDocumento WHERE id_documento = @idDocumento AND id_tramite = @idTramite)

	begin try
    INSERT INTO [dbo].[detallePersonaTramite]
					   ([id_perTra]
					   ,[id_traDo]
					   ,[det_estatus]
					   ,[det_observaciobes])
				 VALUES
					   (@idPerTra
					   ,@idTrado
					   ,2
					   ,'')
	end try
	begin catch
		print 'error'
	end catch

	SELECT success = 1, msg = 'Se inserto corectamente';
END
go

exec sp_addextendedproperty 'MS_Description', 'id del tipo de documento que se requiere en el tramite', 'SCHEMA', 'dbo',
     'PROCEDURE', 'INS_TRANS_DETALLE_SP', 'PARAMETER', '@idDocumento'
go

exec sp_addextendedproperty 'MS_Description', 'id del tipo de tramite', 'SCHEMA', 'dbo', 'PROCEDURE',
     'INS_TRANS_DETALLE_SP', 'PARAMETER', '@idTramite'
go

exec sp_addextendedproperty 'MS_Description', 'id del tramite creado en personatramite', 'SCHEMA', 'dbo', 'PROCEDURE',
     'INS_TRANS_DETALLE_SP', 'PARAMETER', '@idPerTra'
go

