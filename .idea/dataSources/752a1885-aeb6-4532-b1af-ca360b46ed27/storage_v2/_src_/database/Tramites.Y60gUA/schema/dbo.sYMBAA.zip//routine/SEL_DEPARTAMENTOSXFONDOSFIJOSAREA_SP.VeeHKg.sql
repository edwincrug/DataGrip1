-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 25/06/2020
-- Modify: Juan Carlos
-- Modify date: 19/05/2020
-- Description:	SP para obtener los departamentos x fondo
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOSXFONDOSFIJOSAREA_SP]  
	@idFondo int
AS

BEGIN
	
DECLARE @idEmpresa INT, @idSucursal INT
select @idEmpresa = idEmpresa, @idsucursal = idSucursal from tramite.fondofijo where id = @idFondo

select 
d.idDepartamento as idDepartamento,
d.descripcion as departamento,
d.idAutorizador,
u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as autorizador,
u.usu_correo as correo
from [Tramite].[cat_Departamentos_Sucursal_FF] d
inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = d.idAutorizador
where d.idEmpresa = @idEmpresa and d.idSucursal = @idsucursal and d.estatus = 1

END

go

