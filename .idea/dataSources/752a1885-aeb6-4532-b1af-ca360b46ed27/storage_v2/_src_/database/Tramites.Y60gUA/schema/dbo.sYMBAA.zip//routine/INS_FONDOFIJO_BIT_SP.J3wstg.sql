
-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <05/02/2020>
-- Description:	<Inserta la bitacora y proceso del tramite>
-- ============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_BIT_SP]
	@idUsuario INT,
	@id_perTra INT,
	@idEstatus INT = 0,
	@accion varchar(max) = '',
	@bitacora INT = 0,
	@proceso INT = 0
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY

	IF(@bitacora = 1)
	BEGIN
		INSERT INTO BitacoraTramite ([idUsuario], [id_perTra], [accion],[fechaMovimiento])
		VALUES (@idUsuario, @id_perTra, @accion, GETDATE())
	END

	IF(@proceso = 1)
	BEGIN
		INSERT INTO ProcesoTramite ([id_perTra], [idUsuario], [idEstatus], [hrInicio], [hrFin])
		VALUES (@id_perTra, @idUsuario, @idEstatus, GETDATE(), NULL)
	END
	
	SELECT success = 1, msg = 'Se inserto correctamente'

END TRY
	BEGIN CATCH
		
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

