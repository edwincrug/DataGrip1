
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <23/04/2020>
-- Description:	<SP que trae el idPersona de GA_Corporativa>
-- SEL_BUSCARPERSONA_SP 111035
-- =============================================
CREATE PROCEDURE [dbo].[SEL_BUSCARPERSONA_SP] 
	@idPersona INT
AS
BEGIN
	 
	 IF EXISTS (select top 1 1 from GA_Corporativa.dbo.PER_PERSONAS where PER_IDPERSONA = @idPersona and PER_TIPO = 'FIS')
	 BEGIN
	 select 
	 1 estatus, 
	 PER_PATERNO + ' ' + PER_MATERNO + ' ' + PER_NOMRAZON as nombre,
	 PER_IDPERSONA as idPersona
	 from GA_Corporativa.dbo.PER_PERSONAS
	 where PER_IDPERSONA = @idPersona
	 END
	 ELSE
	 BEGIN
	 select 0 estatus, '' nombre, 0 idPersona
	 END

END
go

