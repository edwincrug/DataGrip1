-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CUENTA_SP]
	@idEmpresa INT = 0
	,@idBanco INT = 0
AS
BEGIN
	SELECT 
		   BANCO.NOMBRE
		  ,BACU.[IdEmpresa]
		  ,BACU.[IdBanco]
		  -- ,BACU.[Cuenta]
		  ,BACU.[numeroCuenta] as Cuenta
		  ,BACU.[Convenio]
		  ,BACU.[TipoCuenta]
		  ,BACU.[CuentaContable] 
	FROM [referencias].[dbo].[BancoCuenta] BACU
		 INNER JOIN [referencias].[dbo].[Banco] BANCO ON BANCO.idBanco = BACU.idBanco
	WHERE BACU.idBanco = @idBanco AND BACU.idEmpresa = @idEmpresa 
END

go

