-- =============================================
-- Author:		
-- Create date: 
-- Description:	<Obtiene los archivos por concepto>
--TEST EXEC [Tramite].[Sp_Tramite_ConceptoArchivo_GETLByIdConcepto_GV] 783, 'localhost'
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ConceptoArchivo_GETLByIdConcepto_GV] @idTramiteConcepto INT
, @urlParametro VARCHAR(50)
AS
BEGIN -- 713_CartaResponsiva (3).pdf

  SET NOCOUNT ON;
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

  DECLARE @urlDoctos VARCHAR(100)

  IF (@urlParametro = 'localhost')
  BEGIN
    SET @urlDoctos = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = @urlParametro);
  END
  ELSE
  BEGIN
    SET @urlDoctos = (SELECT
        pr_descripcion
      FROM parametros
      WHERE pr_identificador = 'GET_SERVER');
  END

  DECLARE @saveUrl VARCHAR(100) = (SELECT
      pr_descripcion
    FROM parametros
    WHERE pr_identificador = 'Url_Local_ADG');

  PRINT @urlDoctos

  SELECT
    TCA.idConceptoArchivo
   ,nombre + '.' + extension AS [nombre]
   ,extension
   ,COALESCE(total, 0) AS [total]
   ,CASE
      WHEN TCA.uuid IS NULL THEN 0
      ELSE (([total] / 1.16) * .16)
    END AS iva
   ,folioDocumento
   ,CAST(TCA.idConceptoArchivo AS VARCHAR) + '_' + nombre + '.' + extension AS [nombreArchivo]
   --,@urlDoctos + 'Comprobaciones/comprobacion/' + 'Comprobacion_' + CAST(idReferencia AS VARCHAR(8)) + '/' + CAST(TCA.idConceptoArchivo AS VARCHAR(8)) + '_' + nombre + '_' + ISNULL(SUBSTRING(idComprobacionConcepto, LEN(idComprobacionConcepto), 1),'1') + '.' + extension AS [urlArchivo]
   ,@urlDoctos + 'Comprobaciones/comprobacion/' + 'Comprobacion_' + CAST(idReferencia AS VARCHAR(8)) + '/' + CAST(TCA.idConceptoArchivo AS VARCHAR(8)) + '_' + nombre  + '.' + extension AS [urlArchivo]
   ,(SELECT
        COALESCE(SUM(porcentaje), 0) AS porcentaje
      FROM [Tramite].[ArchivoDepartamento] TAD
      WHERE TAD.idConceptoArchivo = TCA.idConceptoArchivo)
    AS [porcentaje]
   ,idEstatus
   ,idReferencia
   ,(SELECT
        COALESCE(SUM(importe), 0)
      FROM Tramite.TramiteImporte
      WHERE idTramiteConcepto = TCA.idReferencia
      AND idConceptoArchivo = TCA.idConceptoArchivo)
    AS [aprobado]
   ,CASE
      WHEN (TCA.idEstatus = 7) THEN 'Registrado'
      WHEN (TCA.idEstatus = 8) THEN 'En Revisión'
      WHEN (TCA.idEstatus = 9) THEN 'Aprobado'
      WHEN (TCA.idEstatus = 10) THEN 'Rechazado'
    END AS [estatus]
   ,COALESCE((SELECT
        STUFF((SELECT
            ', ' + comentario
          FROM [Tramite].[TramiteComentario]
          WHERE idConceptoArchivo = TCA.idConceptoArchivo
          AND idTipoProceso = 3
          FOR XML PATH (''))
        , 1, 2, ''))
    , '') AS [comentarioComprobacion]
   ,COALESCE((SELECT
        STUFF((SELECT
            ', ' + comentario
          FROM [Tramite].[TramiteComentario]
          WHERE idConceptoArchivo = TCA.idConceptoArchivo
          AND idTipoProceso = 4
          FOR XML PATH (''))
        , 1, 2, ''))
    , '') AS [comentarioAprobacion]
   ,'' AS comentario
   ,TCA.idTipoProceso
   ,TI.importe
   ,(SELECT
        idConceptoContable
      FROM Tramite.TramiteConcepto
      WHERE idTramiteConcepto = TCA.idReferencia)
    AS idConceptoContable
   ,TCA.idComprobacionConcepto
   ,CASE
      WHEN TCA.uuid IS NULL THEN 0
      ELSE 1
    END AS esFactura
	,CASE WHEN TCA.fecha IS NULL THEN NULL ELSE CONVERT(VARCHAR(10), TCA.fecha, 111) END fecha
	,ISNULL(TCA.mesCorriente,0) as mesCorriente
	,ISNULL(TCA.tipoNotificacion,0) as tipoNotificacion
	,ISNULL(TCA.estatusNotificacion,0) as  estatusNotificacion
	,ISNULL(TCA.estatusNotificacionDeMas,0) as  estatusNotificacionDeMas
  FROM [Tramite].[ConceptoArchivo] TCA
  INNER JOIN cat_proceso_estatus CPE
    ON idTipoTramite = 9
      AND TCA.idEstatus = CPE.esDe_IdEstatus
  INNER JOIN [Tramite].[TramiteImporte] TI
    ON TI.idTramiteConcepto = TCA.idReferencia
      AND TI.idTipoProceso = 2
  WHERE idReferencia = @idTramiteConcepto --and TCA.total  > 0

  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  SET NOCOUNT OFF;
END



--select * from  [Tramite].[ConceptoArchivo] TCA
--	INNER JOIN cat_proceso_estatus CPE ON idTipoTramite = 9 AND TCA.idEstatus = CPE.esDe_IdEstatus
--	INNER JOIN [Tramite].[TramiteImporte] TI ON TI.idTramiteConcepto = TCA.idReferencia and TI.idTipoProceso = 2
--	WHERE idReferencia = 542
go

