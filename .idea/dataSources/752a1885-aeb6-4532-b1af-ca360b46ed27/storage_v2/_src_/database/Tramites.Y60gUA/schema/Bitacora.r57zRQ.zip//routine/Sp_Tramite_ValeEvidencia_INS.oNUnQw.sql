-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- EXEC [Bitacora].[Sp_Tramite_ValeEvidencia_INS] 'UPDATE', '[Bitacora].[valesEvidencia]', 566
-- =============================================
CREATE PROCEDURE [Bitacora].[Sp_Tramite_ValeEvidencia_INS]
	@TipoOpe VARCHAR(10) = '',
	@SPExecuted VARCHAR(50) = '',
	@IdValeEvidencia INT = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		INSERT INTO [Bitacora].[valesEvidencia]
		SELECT 
			[BitacoraFechaRegistro] = GETDATE()
			  ,[BitacoraTipoOperacion] = @TipoOpe
			  ,[BitacoraSPExecuted] = @SPExecuted
			  ,[idValeEvidencia] = @IdValeEvidencia
			  ,[idVales]
			  ,[idfactura]
			  ,[idestatus]
			  ,[esFactura]
			  ,[url]
			  ,[archivo]
			  ,[extension]
			  ,[monto]
			  ,[fechaCreacion]
			  ,[comentario]
			  ,[idGastoFondoFijo]
			  ,[areaAfectacion]
			  ,[conceptoAfectacion]
			  ,[numeroCuenta]
			  ,[tipoComprobante]
			  ,[tipoIVA]
			  ,[IVA]
			  ,[IVAretencion]
			  ,[ISRretencion]
			  ,[subTotal]
			  ,[idComprobacionVale]
			  ,[procesoPoliza]
			  ,[compNoAutorizado]
			  ,[estatusReembolso]
			  ,[envioReembolso]
			  ,[montoPoliza]
			  ,[motivo]
			  ,[envioNotificacion]
			  ,[fechaRechazo]
			  ,[comprobacionMas]
			  ,[comprobacionMasArchivo]
			  ,[id_perTraReembolso]
			  ,[estatusPerTraReembolso]
		FROM [Tramite].[valesEvidencia]
		WHERE id = @IdValeEvidencia
	END TRY
	BEGIN CATCH
		PRINT('Ocurrio un error')
	END CATCH
    
END
go

