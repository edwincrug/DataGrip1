-- =============================================
-- Author:		Luis Garcia
-- Create date: 22/07/2019
-- Description:	Trae los documentos del cliente
-- TEST [SEL_DOCUMENTOS_DEPA_APROBAR_SP] 94587, 4, 7, 245
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_DEPA_APROBAR_SP]
	@idCliente INT,
	@idEmpresa INT,
	@idSucursal INT,
	@idPerTra INT
	
AS
BEGIN
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = '',
	@idTraDe INT

	SELECT 
		@idTrade = id_traDe 
	FROM tramiteDevoluciones WHERE id_perTra = @idPerTra

	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SET @query =  'SELECT ' + CHAR(13) +
							CHAR(9) + 'cartera.CCP_IDDOCTO AS documento,' + CHAR(13) +
							CHAR(9) + 'SUBSTRING(PNC.PAR_DESCRIP1,    CHARINDEX(''. -'',PNC.PAR_DESCRIP1) + 3    ,LEN(PNC.PAR_DESCRIP1))  as PAR_DESCRIP1' + CHAR(13) +
						'FROM' + '[' + @nombreBase + '].[DBO].[vis_concar01] AS cartera' + CHAR(13) +
						'INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] AS persona ON persona.PER_IDPERSONA = cartera.CCP_IDPERSONA' + CHAR(13) +
						'LEFT JOIN [documentosDevueltos] DD ON DD.docDe_documento = cartera.CCP_IDDOCTO COLLATE DATABASE_DEFAULT ' + CHAR(13) +
						'INNER JOIN ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] PNC ON PNC.PAR_IDENPARA = cartera.CCP_Cartera' + CHAR(13) +
						'WHERE cartera.CCP_Cartera IN (''Z116'',''Z3'',''Z4'',''Z5'',''Z6'',''Z7'',''Z8'',''Z9'',''Z10'',''Z11'',''Z56'',''Z57'',''Z58'',''Z59'',''Z63'',''Z64'',''ZIX20'')' + CHAR(13) +
						'AND cartera.CCP_IDPERSONA IN (' + CONVERT(VARCHAR(20), @idCliente ) + ')' + CHAR(13) +
						'AND DD.id_traDe = ' + CONVERT(VARCHAR(20), @idTrade) + CHAR(13) +
						'AND PNC.PAR_TIPOPARA = ''CARTERA''' + CHAR(13) +
						'GROUP BY cartera.CCP_IDPERSONA, persona.PER_NOMRAZON, cartera.CCP_IDDOCTO, DD.id_docDe, DD.docDe_estatus, DD.id_docDe, PNC.PAR_DESCRIP1' + CHAR(13) +
						'HAVING (SUM(CCP_ABONO)-SUM(CCP_CARGO)) > 0'
	
	EXECUTE (@query)
END
go

