
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <16/10/2019>
-- Description:	<SP que trae las CC de los FF x sucursal>
-- [SEL_CUENTASCONTABLESFONDO_SP] 85
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CUENTASCONTABLESFONDO_SP] 
	@idsucursal INT
AS
BEGIN
	select cuenta as cuentaContable, idpersona from  [Tramite].[cat_CuentasContableFFGV]  where idsucursal = @idsucursal
END
go

