-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <01/06/2020>
-- Description:	<SP que actualiza el estatus de la evidencia>
-- [dbo].[UPD_ESTATUSNOTIEVIDENCIA_SP]   37,3,''
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUSNOTIEVIDENCIA_SP] 
	@idValeEvidencia INT,
	@estatus INT
AS
BEGIN

	UPDATE Tramite.valesEvidencia
	SET envioNotificacion =  @estatus
	WHERE id = @idValeEvidencia
	
	SELECT success = 1, msg = 'Se actualizo correctamente' 

END

go

