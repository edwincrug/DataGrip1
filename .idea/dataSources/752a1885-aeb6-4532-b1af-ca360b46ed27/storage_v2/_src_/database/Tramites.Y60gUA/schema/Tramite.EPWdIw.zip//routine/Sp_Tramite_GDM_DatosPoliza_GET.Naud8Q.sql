-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Tramite].[Sp_Tramite_GDM_perTraPadre_GET] 1675
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_GDM_DatosPoliza_GET]
	@idPerTraPoliza INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--DECLARE @idPerTraPoliza INT = 1783;

	DECLARE @CountBases INT = 1, 
					@registos INT = 0, 
					@base varchar (200),
					@idComprobacionVale varchar(100),
					@SQLAgencia NVARCHAR(MAX)
			DECLARE @db TABLE(id int identity(1,1),idempresa INT,idsucursal INT, idcomprobacion INT, base varchar(200), idComprobacionConcepto varchar(100), idusuario INT, idConcepto varchar(100), monto decimal(10,2), canal varchar(10), compNoAutorizado INT);
		

	INSERT INTO @db
	select td.id_empresa, td.id_sucursal, ca.idConceptoArchivo idcomprobacion, e.emp_nombrebd, ca.idComprobacionConcepto, pt.id_persona as respondable , tc.idTramiteConcepto, ca.total , dep.dep_nombrecto, ISNULL(ca.compNoAutorizado,0) as compNoAutorizado
	--select td.id_perTra , ca.*
	from Tramite.ConceptoArchivo ca
	inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
	inner join tramiteDevoluciones td on td.id_perTra = tc.idTramitepersona
	inner join personaTramite pt on pt.id_perTra =  td.id_perTra
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = td.id_empresa
	inner join ControlAplicaciones.dbo.cat_departamentos dep ON dep.dep_iddepartamento = td.id_departamento
	inner join tramite.TramiteGastosMas TGM ON TGM.idConceptoArhivo = ca.idConceptoArchivo
	where ca.procesoPoliza is null  AND TGM.idTramiteTransferencia = @idPerTraPoliza AND ca.estatusNotificacionDeMas = 3

	SET @registos = (select COUNT(1) from @db)
				WHILE(@CountBases<= @registos)
						BEGIN
							SELECT 
							@base = base,
							@idComprobacionVale = idComprobacionConcepto
							FROM @db 
							WHERE id = @CountBases
					
							SET @SQLAgencia = 'select omd.omd_producto, odm_ordencompra 
							from ['+@base+'].dbo.cxp_ordenesmasivas om
							inner join ['+@base+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
							where  omd.omd_producto = '''+@idComprobacionVale+''''	

							print 	@SQLAgencia
							DECLARE @pedidos TABLE (idComprobacionVale varchar(100), ordencompra varchar(100));

							INSERT INTO @pedidos
							EXECUTE(@SQLAgencia)

							SET @CountBases= @CountBases+1     
						END
	select d.*
	,p.ordencompra
	from @db d 
	left join @pedidos p on d.idComprobacionConcepto =  p.idComprobacionVale

END
go

