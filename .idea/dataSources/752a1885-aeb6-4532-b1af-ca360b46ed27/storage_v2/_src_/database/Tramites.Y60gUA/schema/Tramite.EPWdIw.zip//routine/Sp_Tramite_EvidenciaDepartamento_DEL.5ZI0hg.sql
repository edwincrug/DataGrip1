
-- =============================================
-- Author:		<Juan Carlos Peralta	Sotelo>
-- Create date: <10/02/2020>
-- Description:	<Elimina un departamento en especifico>
--TEST EXEC [Tramite].[Sp_Tramite_EvidenciaDepartamento_DEL] 1
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_EvidenciaDepartamento_DEL] 
	@idValeEvidenciaDepartamento INT
AS
BEGIN 

	SET NOCOUNT ON;
	
	DECLARE @resultado INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[ValeEvidenciaDepartamento] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite

		DELETE FROM [Tramite].[ValeEvidenciaDepartamento] 
		WHERE idValeEvidenciaDepartamento = @idValeEvidenciaDepartamento
		      
		SET @resultado = SCOPE_IDENTITY()

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @resultado AS [resultado]
END
go

