-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--SEL_DEPARTAMENTO_AREA_AFECTACION_GV 4,6
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTO_AREA_AFECTACION_GV] 
	@idEmpresa int
	,@idSucursal int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT cdsf.idDepartamento
      ,cdsf.idEmpresa
      ,cdsf.idSucursal
      ,cdsf.par_idenPara as PAR_IDENPARA
      ,cdsf.descripcion
      ,cdsf.idAutorizador
      ,cdsf.estatus
	FROM Tramites.tramite.cat_Departamentos_Sucursal_gv cdsf
	where cdsf.idEmpresa = @idEmpresa
	and cdsf.idSucursal = @idSucursal
	and cdsf.estatus = 1
	order by descripcion asc

END
go

