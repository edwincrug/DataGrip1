-- =============================================
-- Author:		Luis Garcia
-- Create date: 12/08/2019
-- Description:	Funcion que desarma un string con pipe y comas
--SELECT * FROM dbo.[SPLIT_DOCS_3_COMAS]('MK000033038-1,true,1201|MK000033038-2,true,1202|MK000033038-3,true,1203|MK000033038-4,true,1204|MK000033038-5,true,1205|MK000033038-6,true,1206|MK000033038-7,true,1207')
-- =============================================
CREATE FUNCTION SPLIT_DOCS_3_COMAS (@input AS Varchar(8000))
RETURNS 
	@Result TABLE(documento VARCHAR(50), seleccionado VARCHAR(50), valor VARCHAR(50))
AS
	BEGIN
		IF( Len(@input) > 0 )
		  BEGIN
			  DECLARE @str  VARCHAR(50),
					  @str1 VARCHAR(50),
					  @str2 VARCHAR(50),
					  @pos  INT,
					  @ind  INT,
					  @ind2 INT,
					  @contComa INT,
					  @str3     VARCHAR(100);

			  IF( @input IS NOT NULL )
				BEGIN
					SET @ind = Charindex('|', @input)

					IF @ind > 0
					  BEGIN
						  WHILE @ind > 0
							BEGIN
								SET @str = Substring(@input, 1, @ind - 1)
								SET @ind2 = Charindex(',', @str)
								SET @input = Substring(@input, @ind + 1, Len(@input) - @ind)
								SET @pos = Charindex(',', @input)
								SET @str1 = Substring(@str, 1, @pos - 1)
								SET @str2 = Substring(@str, @pos + 1, Len(@str) - @pos)
								SET @contComa = Charindex(',', @str2)
								SET @str3 = Substring(@str2, @contComa + 1, Len(@str))
								SET @str2 = Substring(@str2, 1, @contComa - 1)

								INSERT INTO @Result VALUES (@str1, @str2, @str3)

								SET @ind = Charindex('|', @input)
							END

						  SET @str = @input
						  SET @pos= Charindex(',', @input)
						  SET @str = @input
						  SET @str1=Substring(@str, 1, @pos - 1)
						  SET @str2=Substring(@str, @pos + 1, Len(@str) - @pos)
						  SET @contComa = Charindex(',', @str2)
						  SET @str3 = Substring(@str2, @contComa + 1, Len(@str))
						  SET @str2 = Substring(@str2, 1, @contComa - 1)

						  INSERT INTO @Result VALUES (@str1, @str2, @str3)
					  END
					ELSE
					  BEGIN
						  SET @pos= Charindex(',', @input)
						  SET @str = @input
						  SET @str1=Substring(@str, 1, @pos - 1)
						  SET @str2=Substring(@str, @pos + 1, Len(@str) - @pos)
						  SET @contComa = Charindex(',', @str2)
						  SET @str3 = Substring(@str2, @contComa + 1, Len(@str))
						  SET @str2 = Substring(@str2, 1, @contComa - 1)

						  INSERT INTO @Result VALUES (@str1, @str2, @str3)
					  END
				END
		  END
		ELSE
		  BEGIN
			  INSERT INTO @Result VALUES ('Sin datos', 'Sin datos', 'Sin datos')
		  END
		RETURN 
	END
go

