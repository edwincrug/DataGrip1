-- =============================================
-- Author:		Luis García
-- Create date: 23/07/2019
-- Description:	Inserta y/o actualiza los documentos que se deberan devolver el pago
-- TEST [INS_DOCUMENTOS_DEVOLVER_TRAMITE_SP] 'MK000028374,true,1300.00,ANT,Z56|MK000028397,true,1200.00,ANT,Z56|MK000028397,true,1200.00,ANT,Z56|MK000028397,true,1200.00,ANT,Z56', 1
-- =============================================
CREATE PROCEDURE [dbo].[INS_DOCUMENTOS_DEVOLVER_TRAMITE_SP]
	@input VARCHAR(MAX),
	@idPerTra INT
AS
BEGIN
	--Declaramos las variables a usar
	DECLARE @idTraDe INT = 0,
	@maxCount INT = 0,
	@minCount INT = 0,
	@documento VARCHAR(500),
	@formaPago VARCHAR(10)

	DECLARE @dataInsertTemp TABLE (rowTable INT, idTraDe INT, documento VARCHAR(500), valorDev NUMERIC(18,2), estatusDoc BIT, cartera VARCHAR(100), tipoDoc VARCHAR(100), tipoPago VARCHAR(50), formaPago VARCHAR(10) );

	--Obtenemos el id del tramite devolucion con el id persona tramite
	SELECT 
		@idTraDe = id_traDe 
	FROM tramiteDevoluciones WHERE id_perTra = @idPerTra;

	--Validamos que responde la funcion
	IF NOT EXISTS (SELECT documento FROM SPLIT_DOCS_6_CAMPOS_FORMA(@input) WHERE documento = 'Sin datos' )
		BEGIN
			--Obtenemos el maximo y minimo de rows que regresa la funcion
			SELECT 
				@maxCount = MAX(x.contador),
				@minCount = MIN(x.contador)
			FROM (	SELECT 
						ROW_NUMBER() OVER(ORDER BY @idTraDe ASC) AS contador
					FROM SPLIT_DOCS_6_CAMPOS(@input)) x

			--Insertamos en la tabla temporal los datos y los rows obtenidos
			INSERT INTO @dataInsertTemp
			SELECT 
				ROW_NUMBER() OVER(ORDER BY @idTraDe ASC),
				@idTraDe,
				documento,
				valor,
				seleccionado,
				cartera,
				tipoDoc,
				tipoPago,
				formaPago
			FROM SPLIT_DOCS_6_CAMPOS_FORMA(@input)

			-- Eliminamos todos los documentos de ese idTrade
			DELETE FROM documentosDevueltos WHERE id_traDe = @idTraDe;

			--Inicia el bucle para saber cuales insertar y cuales prender
			WHILE(@minCount <= @maxCount)
				BEGIN
					select @formaPago = formaPago  	FROM @dataInsertTemp
					WHERE rowTable = @minCount

					--Insertamos los documentos
					INSERT INTO documentosDevueltos
					SELECT 
						idTraDe,
						documento,
						valorDev,
						estatusDoc, 
						0,
						cartera,
						tipoDoc,
						tipoPago						
					FROM @dataInsertTemp
					WHERE rowTable = @minCount

					update tramiteDevoluciones set id_formaPago = @formaPago where id_perTra = @idPerTra
						
					--Aumentamos el contador para el siguiente row
					SET @minCount = @minCount + 1;
				END
			--Regresamos una respuesta al frontEnd
			SELECT success = 1, msg = 'Se termino de insertar'
		END
	ELSE
		BEGIN
			insert into BitacoraDocsError
			select (SELECT top 1 documento FROM SPLIT_DOCS_6_CAMPOS('')),@idTraDe, getdate()

			-- Eliminamos todos los documentos de ese idTrade
			--DELETE FROM documentosDevueltos WHERE id_traDe = @idTraDe;

			--Regresamos una respuesta al frontEnd
			SELECT success = 0, msg = 'No se guarda ningun documento'
		END
	END
go

