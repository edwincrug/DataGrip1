-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <23/10/2019>
-- Description:	<SP que actualiza el estatus de la evidencia del vale>
-- [dbo].[UPD_SEGUIMIENTOVALEEVIDENCIA_SP]  85
-- =============================================

-- =============================================
-- Modificación:<Alejandro Grijalva Antonio>
-- Create date: <31/07/2020>
-- Description:	<Tolerancia de 10 centavos (Parametrizado) para comprobacion de más>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_SEGUIMIENTOVALEEVIDENCIA_SP] 
	@idValeEvidencia INT,
	@accion INT,
	@comentario varchar(MAX) = null,
	@compNoAutorizado INT = 0
AS
BEGIN
	DECLARE @monto DECIMAL(18,4)
	DECLARE @idVale INT
	IF(@accion = 2)
	BEGIN
	----Actualiar Vales Evidencias----
	UPDATE Tramite.valesEvidencia
	SET idestatus = @accion--, compNoAutorizado = @compNoAutorizado 
	WHERE id = @idValeEvidencia
	
	select @idVale = VE.idVales, @monto = CASE WHEN FV.idValeEvidencia is null THEN VE.monto ELSE FV.Total END   
	from Tramite.valesEvidencia VE
	LEFT JOIN [Tramite].[FacturaVale] FV ON FV.idValeEvidencia = VE.id
	WHERE VE.id = @idValeEvidencia

	-- SE INTEGRA TOLERANCIA PARA EVIAR JSUTIFICAR DE MAS 10 CENTAVOS
	DECLARE @centavos DECIMAL(2, 2) = (SELECT pr_descripcion centavos FROM parametros WHERE pr_tipoParametro = 'tramite' AND pr_identificador = 'valesTolCentavos')
	PRINT( @centavos )
	-- SE RESTA TOLERACIA A LAS VALIDACIONES PARA COMPROBACION DE MAS

	----Actualiar Vales----
	UPDATE 
		Tramite.vales
	SET 
		montoJustificado = montoJustificado + @monto, 
		estatusVale = 
			CASE WHEN (montoJustificado + @monto) >= (montoSolicitado - @centavos) THEN 4
			ELSE estatusVale END
	WHERE id = @idVale

	END

	IF(@accion = 3)
		BEGIN
			UPDATE Tramite.valesEvidencia
			SET idestatus = @accion, comentario = @comentario
			WHERE id = @idValeEvidencia
		END

	SELECT success = 1, msg = 'Se actualizo correctamente';

END
go

