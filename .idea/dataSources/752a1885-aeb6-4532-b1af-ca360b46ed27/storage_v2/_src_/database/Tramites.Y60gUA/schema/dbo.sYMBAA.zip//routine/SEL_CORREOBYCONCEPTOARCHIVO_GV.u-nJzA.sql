-- =============================================
-- Author:		Juan Carlos Peralta
-- Create date: 19/08/2020
-- Description:	<Description,,>
-- SEL_CORREOBYCONCEPTOARCHIVO_GV 1218
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CORREOBYCONCEPTOARCHIVO_GV] 
	@idConceptoArchivo INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	select 
	1 as estatus
	,ca.nombre as documento
	,ca.total
	,ca.motivoRechazo as motivo
	,d.id_pertra as idSolicitud
	,case when te.IdPersona is null then u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno else (select PER_NOMRAZON + ' ' + PER_PATERNO + ' ' + PER_MATERNO  COLLATE SQL_Latin1_General_CP1_CI_AS from GA_Corporativa.dbo.PER_PERSONAS where PER_IDPERSONA = te.IdPersona ) end as Empleado
	,u.usu_correo as correo
	,e.emp_nombre as empresa
	,s.suc_nombre as sucursal
	FROM Tramite.ConceptoArchivo ca
	inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
	inner join personaTramite p on tc.idTramitePersona = p.id_perTra
	inner join tramiteDevoluciones d on d.id_perTra = p.id_perTra
	inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = p.id_persona
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = d.id_empresa
	inner join ControlAplicaciones.dbo.cat_sucursales s on s.suc_idsucursal = d.id_sucursal
	left join Tramite.TramiteEmpleado te on tc.idTramitePersona = te.idTramiteDevolucion
	WHERE CA.idConceptoArchivo = @idConceptoArchivo

END
go

