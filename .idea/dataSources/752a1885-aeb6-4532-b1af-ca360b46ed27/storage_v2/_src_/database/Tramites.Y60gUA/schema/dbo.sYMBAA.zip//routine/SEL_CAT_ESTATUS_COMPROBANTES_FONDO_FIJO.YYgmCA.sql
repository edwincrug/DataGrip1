-- =============================================
-- Author:		Roberto Almanza 
-- Create date: <Create Date,,>
-- Description:	Catalogo de estatus para la vista de comprobantes de vales de FF en la vista de reportes de contraloria
-- =============================================
CREATE PROCEDURE SEL_CAT_ESTATUS_COMPROBANTES_FONDO_FIJO 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	exec Tramites.dbo.OBTIENE_PARAMETROS_V2 'estatusComprobantesValesFF'
END
go

