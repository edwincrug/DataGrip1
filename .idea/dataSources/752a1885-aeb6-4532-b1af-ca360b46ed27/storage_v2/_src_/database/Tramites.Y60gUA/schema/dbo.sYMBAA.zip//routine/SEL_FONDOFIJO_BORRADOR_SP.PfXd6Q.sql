-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <14/10/2019>
-- Description:	<SP que trae los datos del tramite FF borrador>
-- SEL_FONDOFIJO_BORRADOR_SP 1093
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJO_BORRADOR_SP] 
	@idPerTra INT
AS
BEGIN
	DECLARE @url varchar(max), @urlSave varchar(max)
	SELECT @url = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'

	SET @urlSave = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');	

	declare @parametros table(tabla varchar(60),correo varchar(max), idrol int, idUsuario int)
	
	--insert into @parametros
	--EXEC OBTIENE_PARAMETROS 'tesoreriaFondoFijo'
	 
    DECLARE @idRolSiguiente INT, @correo varchar (max)
    
    SELECT @idRolSiguiente = idRolSiguiente FROM Tramite.FlujoRolTramite
    where idtramite = 10 and estatusPasoActual = 2   

	--select @correo = correo from @parametros
 
 --   SELECT @correo =  STUFF((
	--SELECT ';' + usu_correo
	-- from dbo.usuarioRol r
 --   inner join controlaplicaciones.dbo.cat_usuarios u on r.idUsuario = u.usu_idusuario
 --   where idrol = @idRolSiguiente
 --   FOR XML PATH('')
	--),1,1,'')

	SET @correo = 'victor.jimenez@grupoandrade.com.mx,margarita.davila@grupoandrade.com.mx,efren.ruiz@grupoandrade.com.mx,rosalba.lara@grupoandrade.com.mx'

	--Se agrega para saber el monto disponible del fondo fijo--

		DECLARE @nombreBD VARCHAR(30)
       ,@idEmpresa INT
       ,@query NVARCHAR(MAX)
	   ,@idResponsable int
	   ,@cuentaContable VARCHAR(60)
	   ,@fondoFijo varchar(30)
	   ,@nombreResponsableFF varchar(150)
	   ,@clienteBPRO varchar(15)
	   ,@montoDisponible DECIMAL(18,4)

	SELECT 
	@idEmpresa = f.idEmpresa
	,@idResponsable = f.idResponsable
	,@fondoFijo = idFondoFijo
		FROM Tramites.Tramite.fondoFijo f
	JOIN ControlAplicaciones.dbo.cat_departamentos cd
	  ON f.idDepartamento = cd.dep_iddepartamento
	JOIN ControlAplicaciones.dbo.cat_sucursales cs
	  ON cd.suc_idsucursal = cs.suc_idsucursal
	JOIN ControlAplicaciones..cat_usuarios cu
	  ON f.idResponsable = cu.usu_idusuario
	WHERE f.id_perTra = @idPerTra

	SELECT
	  @nombreBD = ce.emp_nombrebd
	FROM ControlAplicaciones.dbo.cat_empresas ce
	WHERE ce.emp_idempresa = @idEmpresa

	SELECT
	  @clienteBPRO = idpersona
	FROM [Tramite].[cat_CuentasContableFFGV]
	WHERE idUsuario = @idResponsable

	SET @query = '
	SELECT  @montoDisponible = isnull(SUM(CCP_CARGO),0) - isnull(SUM(CCP_ABONO),0) 
    FROM '+ @nombreBD +'.DBO.VIS_CONCAR01 
    WHERE CCP_IDDOCTO = '''+@fondoFijo+''' and CCP_IDPERSONA = '''+@clienteBPRO+''''
	EXECUTE sp_executeSQL @query, N' @montoDisponible DECIMAL(18,4) OUTPUT',@montoDisponible OUTPUT

SELECT
	FF.id,
	FF.idEmpresa, 
	FF.idSucursal, 
	FF.idDepartamento, 
	FF.idAutorizador, 
	FF.idResponsable, 
	TD.traDe_devTotal as monto,
	--case when FFC.montoCambiado is null then  TD.traDe_devTotal 
	--else case when FF.aumentodisminucion = 1 then TD.traDe_devTotal + FFC.montoCambiado else TD.traDe_devTotal - FFC.montoCambiado end
	--end as monto,  
	ISNULL(FFC.aumentoDecrementoFF,0)  as aumentodisminucion, 
	ISNULL(TD.traDe_Observaciones,'') AS descripcion,
	FF.nombreFondoFijo,
	FF.idFondoFijo, 
	U.usu_materno  + ' ' + U.usu_paterno + ' ' + U.usu_nombre as solicitante,
	ET.id_estatus,
	TD.esDe_IdEstatus,
	ISNULL(FF.idSalidaEfectivo,0) as idSalidaEfectivo,
	ISNULL(FF.idReembolso,0) as idReembolso,
	@url as url,
	FFC.montoCambiado,
	FF.estatusFondoFijo,
	--@correo as correo,
	--'juan.peralta@coalmx.com' as correoTesoreria,
	--@nombreAutorizador as nombreAutorizador,
	@correo as correoTesoreria,
	'Autorización Fondo FIjo ' + FF.idFondoFijo as asunto,
	D.dep_nombrecto,
	TD.PER_IDPERSONA,
	ISNULL(FF.Autorizado,0) as Autorizado,
	FF.cuentaContable,
	--FF.montoDisponible,
	@montoDisponible montoDisponible,
	FF.tipoCierre,
	FF.comprobanteCierre,
	FF.arqueoCierre,
	@urlSave as urlSave,
	U.usu_correo as correoCajero,
	FFC.id as idAumentoDecremento,
	ISNULL(FF.departamentoAreas,0) as departamentoAreas
FROM [Tramite].[fondoFijo] FF
INNER JOIN personaTramite PT ON PT.id_perTra = FF.id_perTra
INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus 
INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = idResponsable
INNER JOIN ControlAplicaciones.dbo.cat_departamentos D ON D.dep_iddepartamento = TD.id_departamento
LEFT JOIN Tramite.fondoFijoCambios FFC ON FFC.id = FF.AumentoDisminucion
WHERE FF.id_perTra = @idPerTra

END

go

