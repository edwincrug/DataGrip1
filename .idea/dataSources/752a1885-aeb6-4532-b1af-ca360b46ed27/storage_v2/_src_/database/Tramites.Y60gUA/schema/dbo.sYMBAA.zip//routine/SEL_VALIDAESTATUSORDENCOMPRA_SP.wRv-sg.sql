
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <06/05/2020>
-- Description:	<SP que obtiene las evidencias del reembolso el FF>
-- SEL_VALIDAESTATUSORDENCOMPRA_SP 1071
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDAESTATUSORDENCOMPRA_SP] 
	@idsucursal INT,
	@orden varchar(100)
AS
BEGIN

		 --el encabezado de la orden de compra. 
         select sod_idsituacionorden, oce_idproveedor,oce_importetotal
         from Cuentasxpagar..cxp_ordencompra 
         where oce_folioorden=@orden

         --PERSONA QUE ES PLANTA
         select PAR_IMPORTE1
         from GAZM_Zaragoza..PNC_PARAMETR 
         where PAR_IDENPARA = 'PLANTA' 

         --ESTATUS DEL PERIODO
         select PAR_DESCRIP2 
         from GAZM_Zaragoza..PNC_PARAMETR 
         where PAR_TIPOPARA = 'MCERRCON'  and PAR_IDENPARA = '20200401' 
         --siempre es al primer día del mes. 
       
         ----Catalogo de documentos de Digitalizacion.
         --select * from Centralizacionv2..DIG_CATDOCUMENTO

         --NOTA: Debe estar funcionando el sensor de ordenes de compra para que le cree expediente de digitalizacion y tengas registros en esta tabla.
         -- Validacion si ya cuenta con la factura y documento comprobante de recepcion de la orden de compra
         --si Fecha_Creacion es diferente de Null entonces si tiene documento.
         SELECT * FROM Centralizacionv2..DIG_EXPNODO_DOC where Doc_Id in (20,15) and proc_id=1 and nodo_id =7
		 and Folio_Operacion= @orden  
         --doc : 20 es factura  doc: 15 es comprobante.

         --DATOS DE LA FACTURA cargada a una orden de compra en el portal de proveedores.
		 select top 100 * 
		 from Centralizacionv2..PPRO_DATOSFACTURAS 
		 where folioorden = @orden 



END
go

