-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [SEL_DATA_VALE_CAJA_GASTOS_VIAJE] 4,6,21,2389
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATA_VALE_CAJA_GASTOS_VIAJE_TOKEN] 
	-- Add the parameters for the stored procedure here
	@idEmpresa int
	,@idSucursal int
	,@idDepartamento int
	,@idPerTra int
	,@idToken int
	,@fecha datetime
	,@idUsuario int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

     DECLARE @datos TABLE( id INT, fecha VARCHAR(30), facRem VARCHAR(15), descripcion VARCHAR(150), importe DECIMAL(18,2), iva decimal(18,2), total DECIMAL(18,2), cuentaAplicacion varchar(50), idUsuario int, idAutorizador int )

	 DECLARE @idPresupuesto int

	INSERT INTO @datos
SELECT 
  ti.idTramiteImporte
  ,convert(VARCHAR(10),tc.fechaRegistro,103)--+' '+ CONVERT(VARCHAR(8),tc.fechaRegistro,108) AS fecha
  ,ISNULL(cast(ca.folioDocumento as varchar(20)),'Vale Azul') AS facRem
 , cc.concepto
      , CASE WHEN ca.uuid IS NULL THEN 0 ELSE ROUND((ti.importe/1.16),2) end AS importe
      , CASE WHEN ca.uuid IS NULL THEN 0 ELSE ROUND((ti.importe/1.16)*0.16,2)  END AS iva
      ,ti.importe AS total
      ,tc.numeroCuenta
	  ,pt.id_persona as idUsuario
	  ,ti.idUsuario as autorizador
FROM Tramites.dbo.tramiteDevoluciones d
JOIN personaTramite PT 
  ON PT.id_perTra = d.id_perTra
  AND pt.id_tramite = 9
LEFT JOIN [Tramite].[TramiteEmpleado] TE 
  ON d.id_perTra = TE.idTramiteDevolucion
JOIN ControlAplicaciones.dbo.cat_empresas ce
  ON d.id_empresa = ce.emp_idempresa
JOIN ControlAplicaciones.dbo.cat_sucursales cs
  ON d.id_sucursal = cs.suc_idsucursal
JOIN ControlAplicaciones.dbo.cat_departamentos cd
  ON d.id_departamento = cd.dep_iddepartamento 
JOIN [Tramite].[TramiteConcepto] tc
  ON d.id_perTra = tc.idTramitePersona
  and tc.idEstatus = 2
  and idSalidaEfectivo is null
JOIN Tramite.TramiteImporte ti 
  ON tc.idTramiteConcepto = ti.idTramiteConcepto
AND ti.idtipoProceso = 2
left join ControlAplicaciones..cat_usuarios cu
		on pt.id_persona = cu.usu_idusuario
LEFT JOIN tramite.ConceptoArchivo ca
  ON ti.idConceptoArchivo = ca.idConceptoArchivo
LEFT JOIN Tramite.ConceptoContable cc 
  ON tc.idConceptoContable = cc.idConceptoContable
WHERE tc.idTramitePersona = @idPerTra
AND d.id_empresa = @idEmpresa
AND d.id_sucursal = @idSucursal
AND d.id_departamento = @idDepartamento


--select * from @datos

/*
obtenemos el ultimo id generado
*/
select @idPresupuesto = isnull( MAX(idPresupuesto),0) 
from PresupuestosGVAutorizados

insert into PresupuestosGVAutorizados(idPresupuesto,id_perTra,idTramiteImporte,idUsuarioSolicita,idUsuarioAutoriza,descripcion)
select @idPresupuesto+1, @idPerTra, id, idUsuario, idAutorizador, descripcion
from @datos

insert into DocumentosFirmados(id_pertra, idOrigen, idDocumento, idUsuarioFirma, idToken, fecha)
select @idPerTra, 1, @idPresupuesto+1, @idUsuario,@idToken,GETDATE()


SELECT id
      ,fecha
      ,noFactura = ltrim(rtrim(facRem))
      ,descripcion = COALESCE(descripcion, 'TOTAL')
      ,monto = importe
      ,iva
      ,total = SUM(total)
      ,cuentaAplicacion
  FROM @datos
  GROUP BY GROUPING SETS((id, fecha, facRem, descripcion,importe, iva, cuentaAplicacion),())


END
go

