-- =============================================
-- Author:		<Luis Garccía>
-- Create date: <23/08/2019>
-- Description:	<Se actualiza el ultimo estatus>
--TEST UPD_DEV_ESTATUS_GENERAL 178
-- =============================================
CREATE PROCEDURE UPD_DEV_ESTATUS_GENERAL
	@idPerTra INT
AS
BEGIN
	UPDATE personaTramite SET petr_estatus = 2 WHERE id_perTra = @idPerTra;

	SELECT success = 1;
END
go

