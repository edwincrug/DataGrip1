

-- =============================================
-- Author:		Jorge Conelly
-- Create date: 20/02/2020
-- Modify: Juan Carlos
-- Modify date: 19/05/2020
-- Description:	SP para obtener los datos del autorizador de vales
-- =============================================
CREATE PROCEDURE [dbo].[SEL_AUTORIZADOR_VALES_SP]  
	@idFondoFijo int
AS

BEGIN
	--SET NOCOUNT ON;

    -- select  @idEmpresa = idEmpresa FROM Tramite.fondoFijo WHERE id = @idFondoFijo

	--SELECT uv.idAutorizador, 
	--	cu.usu_correo, 
	--	cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno as nombreUsuario
	--FROM [Tramite].[autorizadoresValesPorEmpresa] uv
	--INNER JOIN ControlAplicaciones.dbo.cat_usuarios cu on uv.idAutorizador = cu.usu_idusuario 
	--WHERE uv.idEmpresa = @idEmpresa
	DECLARE @idEmpresa INT, @idSucursal INT, @idDepartamento INT
	
	SELECT @idEmpresa = idEmpresa, @idSucursal = idSucursal, @idDepartamento = idDepartamento
	FROM Tramite.fondoFijo 
	WHERE id = @idFondoFijo
	
	SELECT aff.idAutorizador, 
	cu.usu_correo, 
	cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno as nombreUsuario 
	FROM [Tramite].[autorizadoresFondoFijo] aff
	INNER JOIN ControlAplicaciones.dbo.cat_usuarios cu on aff.idAutorizador = cu.usu_idusuario 
	WHERE aff.idEmpresa = @idEmpresa AND aff.idSucursal = @idSucursal AND aff.idDepartamento = @idDepartamento

END

go

