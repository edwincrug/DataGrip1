-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CORREOS_USUARIOS_PAGOS] 
AS
BEGIN
	DECLARE @mailPagos TABLE (numberRow INT, mail VARCHAR(100), nombre VARCHAR(100))
	DECLARE @maxCount INT = 0, @minCount INT = 0, @email VARCHAR(255), @correos VARCHAR(MAX) = '', @nombreUsuarioMail nvarchar(MAX) = '';

	SELECT
		@maxCount = MAX(x.contador),
		@minCount = MIN(x.contador)
	FROM(
	SELECT 
		ROW_NUMBER() OVER(ORDER BY usu_correo ASC) AS contador,
		usu_correo, 
		USU.usu_nombre + ' ' + USU.usu_paterno + ' ' + USU.usu_materno As nombreCompleto
	FROM usuariosPagos UP
	INNER JOIN ControlAplicaciones.dbo.cat_usuarios USU ON UP.idUsuario = USU.usu_idusuario) x

	INSERT INTO @mailPagos
	SELECT 
		ROW_NUMBER() OVER(ORDER BY usu_correo ASC) AS contador,
		usu_correo, 
		USU.usu_nombre + ' ' + USU.usu_paterno + ' ' + USU.usu_materno As nombreCompleto
	FROM usuariosPagos UP
	INNER JOIN ControlAplicaciones.dbo.cat_usuarios USU ON UP.idUsuario = USU.usu_idusuario

	WHILE(@minCount <= @maxCount)
		BEGIN
			SELECT 
				@email = mail
			FROM @mailPagos WHERE numberRow = @minCount

			IF (@email like '[a-z,0-9,_,-]%@[a-z,0-9,_,-]%.[a-z][a-z]%' AND @email NOT like '%@%@%'  
			AND CHARINDEX('.@',@email) = 0  
			AND CHARINDEX('..',@email) = 0  
			AND CHARINDEX(',',@email) = 0  
			AND RIGHT(@email,1) between 'a' AND 'z'  )
				BEGIN
					SELECT 
						@correos = @correos + ' ' + MP.mail + ';',
						@nombreUsuarioMail = @nombreUsuarioMail + ' ' + MP.nombre + ','
					FROM @mailPagos MP WHERE numberRow = @minCount
				END

			SET @minCount = @minCount + 1;
		END

	IF( LEN(@correos) > 0 )
		BEGIN
				SELECT 1 AS success, @correos AS email, SUBSTRING(@nombreUsuarioMail, 0, LEN(@nombreUsuarioMail)) AS nombreUsuarioMail
		END
	ELSE
		BEGIN
			SELECT 0 AS success, @correos AS email, @nombreUsuarioMail AS nombreUsuarioMail
		END
END
go

