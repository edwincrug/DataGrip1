-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/06/2019>
-- Description:	<Se guardan los documentos del tramite>
-- Test [SEL_DOCUMENTOS_BY_TRAMITE_API_SP_CLIENTES] 6, 567,'192.168.20.29'
-- =============================================


CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_BY_TRAMITE_API_SP_CLIENTES] 
	 @idTramite INT
	,@id_perTra INT
	,@urlParam VARCHAR(50)
AS
BEGIN

	DECLARE @url VARCHAR(500);
	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam)
		END
	ELSE
		BEGIN 
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER')
		END

	SELECT	id_tramite
		,doc_nomDocumento
		,A.ext_nombre
		,A.id_traDo
		,id_documento
		,isnull(existe,0) existe
		,isnull(det_observaciobes,'') Observaciones 
		,det_estatus estatusDocumento 
		,petr_estatus estatusTramite
		,A.doc_infoAdicional
		,A.doc_expira
		,@url +'Persona_'+ rfc + '_' + CONVERT(VARCHAR(10), id_tramite) +'/Documento_'+ CONVERT(VARCHAR(10),id_documento)+'.'+A.ext_nombre [url]
		,B.id_perTra
		,A.opcional
FROM (

SELECT T.id_tramite, doc_nomDocumento, TD.id_traDo,TD.id_documento, EXT.ext_nombre ,  DOC.doc_infoAdicional, doc_expira ,DOC.opcional from cat_tramites T
INNER JOIN cat_tramiteDocumento TD ON TD.id_tramite = T.id_tramite
INNER JOIN cat_documentos DOC ON DOC.id_documento = TD.id_documento
INNER JOIN cat_extensiones EXT ON EXT.id_extension = DOC.id_extension
WHERE T.id_tramite = @idTramite AND DOC.doc_subeUsuarioRol <> 4 AND DOC.doc_subeUsuarioRol <> 7
)
 AS A LEFT JOIN 
(
SELECT	id_tramite existe
		,DPT.id_traDo
		,DPT.det_observaciobes
		,det_estatus,petr_estatus
		,P.per_rfc  rfc,
		PT.id_perTra
FROM   dbo.personas P 
INNER join  [personaTramite] PT ON PT.id_persona = P.id_persona --AND  PT.petr_estatus <> 2
INNER JOIN  [dbo].[detallePersonaTramite] DPT ON DPT.id_perTra = PT.id_perTra

WHERE
PT.id_perTra = @id_perTra
) as B ON B.Existe = A.id_tramite AND B.id_traDo = A.id_traDo

END
go

