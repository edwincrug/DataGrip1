-- =============================================
-- Author:		Luis Garcia
-- Create date: 13/06/2019
-- Description:	Trae los documento sa aprobar del tramite
--TEST SEL_DEV_DOCUMENTOS_APROBAR_SP 154, 'localhost'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEV_DOCUMENTOS_APROBAR_SP]
	@id_perTra INT,
	@urlParam VARCHAR(50)
AS
BEGIN

	DECLARE @url VARCHAR(50);
	IF(@urlParam = 'localhost')
		BEGIN
			SELECT 
				@url = pr_descripcion 
			FROM parametros WHERE pr_identificador = @urlParam
		END
	ELSE
		BEGIN
			SELECT 
				@url = pr_descripcion 
			FROM parametros WHERE pr_identificador = 'GET_SERVER'
		END

		SELECT 
				 A.id_documento
				,isnull(X.det_idPerTra,0) detIdPerTra
				,A.doc_nomDocumento AS nombreDoc
				,X.rutaDocumento AS rutaDocumento
				,X.idExtension AS idExtension 
				,X.estatusDoc AS estatusDoc
				,X.estatus AS estatus
				,x.observaciones
				,x.estatusDocumento
		FROM
		(
		 SELECT 
				  CT.id_documento AS id_documento
				 ,DOC.doc_nomDocumento
				 ,'' AS detIdPerTra
				 ,'' AS rutaDocumento
				 ,'' AS idExtension
				 ,'' AS estatusDoc
				 ,'' AS estatus
				 ,'' AS observaciones
				 ,'' AS estatusDocumento
		 FROM cat_tramiteDocumento CT
				 INNER JOIN personaTramite  PT ON PT.id_tramite = CT.id_tramite
				 INNER JOIN cat_documentos DOC ON DOC.id_documento = CT.id_documento
		 WHERE PT.id_perTra = @id_perTra  AND DOC.id_documento <> 65
		)  A
		LEFT JOIN(
		SELECT 
				TDOC.id_documento,
				D.doc_nomDocumento AS nombreDoc,
				DPT.det_idPerTra,
				@url + 'Devoluciones/' + 'Devolucion_' + CONVERT(VARCHAR(10),PT.id_perTra) + '/Documento_' + CONVERT(VARCHAR(10), D.id_documento) + '.' + E.ext_nombre AS rutaDocumento,
				E.id_extension AS idExtension,
				CASE WHEN DPT.det_estatus = 2 THEN 'TRUE' ELSE 'FALSE' END AS estatusDoc,
				DPT.det_estatus AS estatus,
				DPT.det_observaciobes observaciones,
				DPT.det_estatus estatusDocumento

			FROM detallePersonaTramite DPT
			INNER JOIN personaTramite PT ON PT.id_perTra = DPT.id_perTra
			INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
			LEFT JOIN cat_tramiteDocumento TDOC ON TDOC.id_traDo = DPT.id_traDo
			INNER JOIN cat_documentos D ON D.id_documento = TDOC.id_documento
			INNER JOIN cat_extensiones E ON E.id_extension = D.id_extension
			WHERE PT.id_perTra = @id_perTra AND D.id_documento <> 65
		) X ON A.ID_DOCUMENTO = x.id_documento  
	
END
go

