

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_LISTA_USUARIOS] 
	-- Add the parameters for the stored procedure here
	@idEmpresa int
	,@idSucursal int
	,@idDepartamento int
	,@idUsuario int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT id = cu.usu_idusuario, 
    nombre = RTRIM( LTRIM(cu.usu_nombre+' '+cu.usu_paterno+' '+cu.usu_materno))
    FROM ControlAplicaciones..cat_usuarios cu
    WHERE cu.emp_idempresa = @idEmpresa
    AND cu.suc_idsucursal = @idSucursal
    AND cu.dep_iddepartamento = @idDepartamento
    AND (cu.usu_correo IS NOT NULL OR LEN(cu.usu_correo)>0 AND cu.usu_idusuario>0)
    AND  cu.usu_nombre+' '+cu.usu_paterno+' '+cu.usu_materno NOT LIKE '%contact%'
	and cu.usu_idusuario <> @idUsuario
    ORDER BY nombre
END
go

