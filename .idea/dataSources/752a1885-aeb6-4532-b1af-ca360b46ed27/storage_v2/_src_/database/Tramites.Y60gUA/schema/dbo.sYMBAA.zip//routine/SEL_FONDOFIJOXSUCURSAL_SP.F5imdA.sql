
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <17/10/2019>
-- Description:	<SP que trae los datos de los FF x sucursal>
-- SEL_FONDOFIJOXSUCURSAL_SP 1993
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJOXSUCURSAL_SP] 
	@idSucursal INT
AS
BEGIN
	 
SELECT 
	FF.id,
	FF.idEmpresa, 
	FF.idSucursal, 
	FF.idDepartamento, 
	FF.idAutorizador, 
	FF.idResponsable, 
	TD.traDe_devTotal as monto, 
	'' as montoFaltante, 
	ISNULL(TD.traDe_Observaciones,'') AS descripcion,
	FF.nombreFondoFijo,
	FF.idFondoFijo,
	CONVERT(varchar, FF.fechaCreacion, 103) as fechaCreacion,
	CASE WHEN PT.petr_estatus IN (2, 3, 5) 
	THEN ET.est_nombre 
	ELSE 
	PED.esDe_descripcion 
	END  AS est_nombre
FROM [Tramite].[fondoFijo] FF
INNER JOIN personaTramite PT ON PT.id_perTra = FF.id_perTra
INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
LEFT JOIN cat_proceso_estatus PED ON PED.esDe_IdEstatus = TD.esDe_IdEstatus AND PED.idTipoTramite = 10
WHERE FF.idSucursal = @idSucursal

END

go

