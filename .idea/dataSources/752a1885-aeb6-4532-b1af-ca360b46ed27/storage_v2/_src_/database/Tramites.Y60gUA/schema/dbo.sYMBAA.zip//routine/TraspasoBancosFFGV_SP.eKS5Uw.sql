-- =============================================
-- Author:
-- Create date:
-- Description:
-- =============================================
CREATE PROCEDURE [dbo].[TraspasoBancosFFGV_SP]
@idempresa int
,@idSucursal int
,@cuentaOrigen varchar(150)
,@cuentaDestino varchar(150)
,@monto decimal(18,2)
,@idUsuario int
,@id_perTra int


AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
declare @folio int =0
begin try
  
insert into GA_Corporativa.dbo.tsb_traspasosaldobancos (
tsb_idempresa
      ,tsb_idsucursal
      ,tsb_cuentaorigen
      ,tsb_cuentadestino
      ,tsb_importe
      ,tsb_moneda
      ,tsb_concepto
      ,tsb_estatus
      ,tsb_fechasolicita
      ,tsb_usuariosolicita)
values( 
@idempresa
,@idSucursal
,@cuentaOrigen
,@cuentaDestino
,@monto
,'PE'
,'DTRASSALDOINGTS'
,0 
,GETDATE() 
,@idUsuario
)
set @folio = @@IDENTITY


insert into Tesoreria.dbo.transferenciasLog(idtransferencia,idPerTraFondoFijo)
values(@folio,@id_perTra)

select 'Ok' as estatus, 'La transferencia se realizó con exito' as mensaje, @folio  as folio

end try
begin catch
select 'error' as Estatus, 'Ocurrio un error durante la transferencia' as mensaje,   ERROR_NUMBER() AS ErrorNumber,
    ERROR_STATE() AS ErrorState,
    ERROR_SEVERITY() AS ErrorSeverity,
    ERROR_PROCEDURE() AS ErrorProcedure,
    ERROR_LINE() AS ErrorLine,
    ERROR_MESSAGE() AS ErrorMessage;
end catch
END
go

