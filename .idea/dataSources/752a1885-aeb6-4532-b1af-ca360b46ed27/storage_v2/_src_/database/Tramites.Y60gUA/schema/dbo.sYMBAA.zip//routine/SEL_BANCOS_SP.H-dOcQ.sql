-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_BANCOS_SP]
	@idEmpresa INT
AS
BEGIN
SELECT 
	DISTINCT(bc.idBanco) AS IdBanco, 
	UPPER(banco.nombre) AS Nombre,
	bc.Carga_Layout AS Layout  
FROM referencias.dbo.Banco banco
INNER JOIN referencias.dbo.BancoCuenta bc
ON banco.idBanco = bc.idBanco
WHERE bc.idEmpresa = @idEmpresa
ORDER BY bc.idBanco asc
END
go

