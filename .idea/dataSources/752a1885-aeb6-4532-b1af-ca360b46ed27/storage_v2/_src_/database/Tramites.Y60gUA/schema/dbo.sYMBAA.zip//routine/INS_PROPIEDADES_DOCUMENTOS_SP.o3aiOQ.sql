-- =============================================
-- Author:		***********
-- Create date: 12/11/2020
-- Description:	Cambia las propiedades de los documentos 
-- =============================================
-- ============== Versionamiento ================
/*
	Fecha 12/11/2020		Autor: *********** 	 Description:	Cambia las propiedades de los documentos

	*- Testing...
	EXEC [dbo].[INS_PROPIEDADES_DOCUMENTOS_SP] 
	@id_traDo =12 
	,@mandatorio =0 
	,@bancario =1
	,@efectivo =0
	,@activo =1 
	,@doc_nomDocumento = 'cambio texto'
*/
-- =============================================
CREATE PROCEDURE [dbo].[INS_PROPIEDADES_DOCUMENTOS_SP]
	@id_traDo INT 
	,@mandatorioBancario INT 
	,@bancario INT
	,@mandatorioEfectivo INT
	,@efectivo INT
	,@activo INT
	,@doc_nomDocumento VARCHAR(500) 
	,@id_documento INT
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		UPDATE cat_tramiteDocumento 
		SET mandatorioEfectivo =  @mandatorioEfectivo, bancario =  @bancario, efectivo =  @efectivo, activo = @activo, mandatorioBancario = @mandatorioBancario
		WHERE id_traDo = @id_traDo 
		UPDATE cat_documentos
		SET doc_nomDocumento = @doc_nomDocumento
		WHERE id_documento = @id_documento
		SELECT 1 AS result
	END TRY

	BEGIN CATCH
		SELECT 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE() AS result;
	END CATCH
END
go

