
-- =============================================
-- Author:    	<Luis Garcia>
-- Create date: <07/06/2016>
-- Description:	<Inserta un registro de persona>
-- [INS_PERSONA_CUENTA_BANCARIA_SP] 5, 'DAVEAAAAAAA323', 'Adolfo', 'Lopez', 'Gonzalez', 
-- =============================================
CREATE PROCEDURE [dbo].[INS_PERSONA_CUENTA_BANCARIA_SP] 
	@idTramite       INT,
	@rfc             VARCHAR(50),
	@nombre          VARCHAR(50),
	@apellido1       VARCHAR(50),
	@apellido2       VARCHAR(50),
	@moralFisica	 INT,
	@cuentaBancaria  VARCHAR(50),
	@idProspecto	 INT,
	@idTipoProspecto INT
AS
  BEGIN
	DECLARE @IdPerTra INT


      
            IF NOT EXISTS (SELECT 1 FROM personas WHERE  per_rfc = @rfc)
              BEGIN
                  INSERT INTO [dbo].[personas]
						([per_rfc],
						[per_nombre],
						[per_apellido1],
						[per_apellido2],
						[per_moralFisica],
						[per_cuentaBancaria],
						[id_Prospecto],
						[id_TipoProspecto])
                  VALUES (		
						@rfc,
						@nombre,
						@apellido1,
						@apellido2,
						@moralFisica,
						@cuentaBancaria,
						@idProspecto,
						@idTipoProspecto)

                  DECLARE @idPersona INT = Scope_identity()

				  -- cuando se guarda un clinete no insertar el tramite al crear usario ya que no sabemos cual realizara (nueo ó incremento)
		
                  INSERT INTO [dbo].[personatramite]
						([id_persona],
						[id_tramite],
						[petr_fechatramite],
						[petr_estatus])
                  VALUES ( 
						@idPersona,
                        @idTramite,
                        Getdate(),
                        4)
				  
				  SET @IdPerTra = SCOPE_IDENTITY()	
		
			
                  SELECT success = 1, msg = 'Se insertó correctamente el usuario.', @IdPerTra idPerTra;
              END
            ELSE
              BEGIN
                  DECLARE @idRecPersona INT;

                  SELECT  @idRecPersona = id_persona
                  FROM   personas
                  WHERE  per_rfc = @rfc;
				  IF(@idTramite = 5)
				  BEGIN
					IF NOT  EXISTS (SELECT 1 FROM personatramite WHERE  id_tramite = @idTramite AND id_persona = @idRecPersona  AND petr_estatus NOT IN( 3,2)  )
                    BEGIN
                        INSERT INTO [dbo].[personatramite]
							([id_persona],
							[id_tramite],
							[petr_fechatramite],
							[petr_estatus])
                        VALUES  ( 
							@idRecPersona,
                            @idTramite,
                            Getdate(),
                            4)
						 SET @IdPerTra = SCOPE_IDENTITY()	
                        SELECT success = 1, msg = 'Se registró el trámite correctamente', @IdPerTra idPerTra ;
                    END

					ELSE
					BEGIN
						SELECT @IdPerTra = id_perTra FROM personatramite WHERE  id_tramite = @idTramite AND id_persona = @idRecPersona  --AND petr_estatus IN( 3,2)
                        SELECT success = 0, msg = 'Existe un usuario para este trámite', @IdPerTra idPerTra;
                    END

				  END
				  ELSE
				  BEGIN
					IF NOT EXISTS (SELECT 1 FROM personatramite WHERE  id_tramite = @idTramite AND id_persona = @idRecPersona  AND petr_estatus NOT IN( 3,2)  )
                    BEGIN
                        INSERT INTO [dbo].[personatramite]
							([id_persona],
							[id_tramite],
							[petr_fechatramite],
							[petr_estatus])
                        VALUES  ( 
							@idRecPersona,
                            @idTramite,
                            Getdate(),
                            4)
						 SET @IdPerTra = SCOPE_IDENTITY()	
                        SELECT success = 1, msg = 'Se registró el trámite correctamente', @IdPerTra idPerTra ;
                    END

					ELSE
					BEGIN
						SELECT @IdPerTra = id_perTra FROM personatramite WHERE  id_tramite = @idTramite AND id_persona = @idRecPersona  --AND petr_estatus IN( 3,2)
                        SELECT success = 0, msg = 'Existe un usuario para este trámite', @IdPerTra idPerTra;
                    END
				  END
					
                  
              END
       
    
  END--FIN


go

