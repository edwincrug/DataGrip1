
-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <09/10/2019>
-- Description:	<Recupera la descripción del gasto de una sucursal>
--TEST EXEC  [Tramite].[Sp_Tramite_areaAfectacion_GETLBySucursal] 
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_areaAfectacion_GETLBySucursal] 
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = ''

	--SELECT 
	--	@nombreBase = suc_nombrebd 
	--FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	--WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	--SET @query = 'SELECT PAR_IDENPARA, PAR_DESCRIP1 FROM [' + @nombreBase + '].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''AREPED''' 

	--EXECUTE (@query)
	
	select par_idenpara as PAR_IDENPARA, otc_area as PAR_DESCRIP1 from Centralizacionv2.dbo.DIG_ESCALAMIENTO_AREA_AFECT where suc_idsucursal = @idSucursal 

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

