-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[Ins_Gastos_GuardaBanco_SP]
	@IdUsuario INT = NULL,
	@IdPersona INT = NULL,
	@IdBanco VARCHAR(3) = NULL,
	@Plaza VARCHAR(5) = NULL,
	@Sucursal VARCHAR(5) = NULL,
	@Cuenta VARCHAR(20) = NULL,
	@CLABE VARCHAR(18) = NULL,
	@idEmpresa INT = NULL,
	@bancoNombre VARCHAR(200) = NULL,
	@cvebanxico VARCHAR(5) = NULL,
	@idSolicitante INT = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF( @CLABE = '' OR @CLABE IS NULL  )
		BEGIN
			SELECT success = 0, msg = 'No se ha solicitado ingresar cuenta'
		END
	ELSE
		BEGIN
			DECLARE @BCO_CONSE INT = (SELECT MAX(BCO_CONSE) + 1 FROM GAZM_Concentra..con_bancos)
			DECLARE @Usu VARCHAR(10) = (SELECT usu_nombreusu FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_idusuario = @IdUsuario);

			DECLARE @IpServer VARCHAR(300), @IpServerOnly VARCHAR(20);
			SELECT 
				@IpServer = '['+ [nombre_base]+'].[dbo].[CON_BANCOS]'
			FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
			WHERE emp_idempresa = @idEmpresa AND tipo = 2;

			DECLARE @Validacion TABLE (BCO_CONSE INT)
			DECLARE @QueryVal VARCHAR(MAX) = 'SELECT BCO_CONSE FROM ' + @IpServer + ' WHERE BCO_NUMCUENTA = '''+@Cuenta+'''';




			INSERT INTO @Validacion
			EXEC(@QueryVal)
			PRINT(@QueryVal)
			--SELECT * FROM  @Validacion
			-- Validamos que la cuenta exista en la empresa que se indico
			IF ( (SELECT COUNT(*) FROM @Validacion) = 0 )
				BEGIN
					DECLARE @Query VARCHAR(1000);
					-- Validamos que la empresa exista en otra empresa
					IF EXISTS( SELECT * FROM [dbo].[cuentaAutorizada] WHERE idPersona = @IdUsuario AND ca_clabe = @CLABE and ca_estatus = 3 )
						BEGIN
							-- Existe en otra empresa
							SET @Query = 
							'INSERT INTO '+ @IpServer +'
								SELECT BCO_IDPERSONA = ' + CONVERT(VARCHAR(10), @IdPersona) + '
								,BCO_BANCO = ' + @IdBanco + '
								,BCO_PLAZA = ' + @Plaza + '
								,BCO_SUCURSAL = ' + @Sucursal + '
								,BCO_STATUS = ''ACTIVO''
								,BCO_TIPCUENTA = ''CC''
								,BCO_NUMCUENTA = ''' + @Cuenta + '''
								,BCO_CLABE = ''' + @CLABE + '''
								,BCO_CVEUSU = ''' + @Usu + '''
								,BCO_FECHOPE = CONVERT( VARCHAR(10), GETDATE(), 103 ) 
								,BCO_HORAOPE = convert(VARCHAR(10), GETDATE(), 108)
								,BCO_REFERNUM = ''''
								,BCO_REFERALF = ''''
								,BCO_CONVENIOCIE = ''''
								,BCO_AUTORIZADA = 1'
							EXEC(@Query);
							PRINT(@Query);

							SELECT success = 0, msg = 'La cuenta bancaria se ha sincronizado a la empresa solicitada.';
						END
					ELSE
						BEGIN
							-- Se cancelan las cuentas anteriores del usuario
							UPDATE [dbo].[cuentaAutorizada] SET [ca_estatus] = 4 WHERE idPersona = @IdUsuario
							SET @QueryVal = 'UPDATE ' + @IpServer + ' SET BCO_AUTORIZADA = 1, BCO_STATUS = ''INACTIVO'' WHERE BCO_IDPERSONA = '''+CONVERT(VARCHAR(10), @IdPersona)+'''';


							SET @Query = 
							'INSERT INTO '+ @IpServer +'
							SELECT BCO_IDPERSONA = ' + CONVERT(VARCHAR(10), @IdPersona) + '
							,BCO_BANCO = ' + @IdBanco + '
							,BCO_PLAZA = ' + @Plaza + '
							,BCO_SUCURSAL = ' + @Sucursal + '
							,BCO_STATUS = ''INACTIVO''
							,BCO_TIPCUENTA = ''CC''
							,BCO_NUMCUENTA = ''' + @Cuenta + '''
							,BCO_CLABE = ''' + @CLABE + '''
							,BCO_CVEUSU = ''' + @Usu + '''
							,BCO_FECHOPE = CONVERT( VARCHAR(10), GETDATE(), 103 ) 
							,BCO_HORAOPE = convert(VARCHAR(10), GETDATE(), 108)
							,BCO_REFERNUM = ''''
							,BCO_REFERALF = ''''
							,BCO_CONVENIOCIE = ''''
							,BCO_AUTORIZADA = 0'
						EXEC(@Query);
						PRINT(@Query);

						INSERT INTO [dbo].[personaTramite]
						SELECT 
							[id_persona] = @IdUsuario,
							[id_tramite] = 14,
							[petr_fechaTramite] = GETDATE(),
							[petr_estatus] = 1,
							[petr_observaciones] = 'Validación de cuenta',
							[esDe_IdEstatus] = NULL;

						DECLARE @perTra INT = @@IDENTITY;

						INSERT INTO [dbo].[cuentasTesoreria]
						SELECT
							[id_perTra] = @perTra,
							[fechaInsercion] = GETDATE(),
							[estatus] = 1,
							[fechaAtencion] = NULL,
							[id_tipoTramite] = 1

						INSERT INTO [dbo].[cuentaAutorizada](
							[ca_clabe],
							[ca_cuenta],
							[ca_idbanco],
							[ca_banconombre],
							[ca_plaza],
							[ca_sucursal],
							[ca_cvebanxico],
							[ca_estatus],
							[ca_fecha],
							[idEmpresa],
							[idPersona],
							[id_perTra],
							[idSolicitante]
						)
						SELECT
							[ca_clabe] = @CLABE,
							[ca_cuenta] = @Cuenta,
							[ca_idbanco] = @IdBanco,
							[ca_banconombre] = @bancoNombre,
							[ca_plaza] = @Plaza,
							[ca_sucursal] = @Sucursal,
							[ca_cvebanxico] = @cvebanxico,
							[ca_estatus] = 1,
							[ca_fecha] = GETDATE(),
							[idEmpresa] = @idEmpresa,
							[idPersona] = @IdUsuario,
							[id_perTra] = @perTra,
							[idSolicitante] = @idSolicitante

						SELECT success = 1, msg = 'Se ha insertado los datos bancarios', perTra = @perTra
						END

		
				END
			ELSE
				BEGIN
					SELECT success = 0, msg = 'La cuenta bancaria ya se encuentra registrada';
					SET @QueryVal =  'SELECT BCO_AUTORIZADA FROM ' + @IpServer + ' WHERE BCO_CLABE = ''' + @CLABE + '''';
					EXEC(@QueryVal)
				END
		END
END
go

