-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/06/2019>
-- Description:	<Se guardan los documentos del tramite>
-- Test SEL_DOCUMENTOS_SUBIDOS_SP 3, 72, 2,'192.168.20.92'
-- =============================================


CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_SUBIDOS_SP] 
	 @idTramite INT
	,@idProspecto INT
	,@idTipoProspecto INT
	,@urlParam VARCHAR(50)
AS
BEGIN
	DECLARE @ta table(doc_nomDocumento nvarchar(200),id_documento int,doc_infoAdicional nvarchar(500) ,url nvarchar(500),id_tramite INT)
	DECLARE @url VARCHAR(500);
	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam)
		END
	ELSE
		BEGIN 
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER')
		END

	INSERT INTO @ta
	SELECT	
		 doc_nomDocumento
		,A.id_documento
		,A.doc_infoAdicional
		,@url +'Persona_'+ rfc + '_' + CONVERT(VARCHAR(10), id_tramite) +'/Documento_'+ CONVERT(VARCHAR(10),id_documento)+'.'+A.ext_nombre [url]
		,A.id_tramite
FROM (
SELECT T.id_tramite, doc_nomDocumento, TD.id_traDo,TD.id_documento, EXT.ext_nombre ,  DOC.doc_infoAdicional, doc_expira from cat_tramites T
INNER JOIN cat_tramiteDocumento TD ON TD.id_tramite = T.id_tramite
INNER JOIN cat_documentos DOC ON DOC.id_documento = TD.id_documento
INNER JOIN cat_extensiones EXT ON EXT.id_extension = DOC.id_extension
WHERE  DOC.doc_subeUsuarioRol <> 4) AS A
 INNER JOIN  
(
SELECT	id_tramite existe
		,DPT.id_traDo
		,DPT.det_observaciobes
		,det_estatus,petr_estatus
		,P.per_rfc  rfc,
		PT.id_perTra
FROM   dbo.personas P 
INNER join  [personaTramite] PT ON PT.id_persona = P.id_persona --AND  PT.petr_estatus <> 2
INNER JOIN  [dbo].[detallePersonaTramite] DPT ON DPT.id_perTra = PT.id_perTra
WHERE P.id_Prospecto = @idProspecto AND P.id_TipoProspecto = @idTipoProspecto  
AND petr_estatus <> 3 ) as B ON B.Existe = A.id_tramite AND B.id_traDo = A.id_traDo


SELECT DISTINCT(T.id_documento),T.doc_nomDocumento + '  -  ' +CT.tra_nomTramite AS doc_nomDocumento,T.url,T.id_tramite FROM @ta T
INNER JOIN  [Tramites].[dbo].[cat_tramites] CT ON CT.id_tramite = T.id_tramite

END
go

