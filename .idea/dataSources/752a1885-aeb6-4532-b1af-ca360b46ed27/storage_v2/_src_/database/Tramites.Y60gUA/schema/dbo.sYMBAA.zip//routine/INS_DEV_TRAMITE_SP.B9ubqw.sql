-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <04/07/2019>
-- Description:	<Inserta el tramite de devoluciones>
-- =============================================
CREATE PROCEDURE [dbo].[INS_DEV_TRAMITE_SP]
	@idUsuario INT,
	@idTramite INT,
	@idFormaPago INT,
	@idDepartamento INT,
	@observaciones VARCHAR(MAX),
	@idEmpresa INT,
	@idSucursal INT,
	@estatus INT,
	@devTotal NUMERIC(18,5),
	@idPersona INT,
	@cuentaBancaria VARCHAR(20) = '',
	@numeroCLABE VARCHAR(20) = '',
	@cveBanxico varchar(5) = '',
	@bancoTipoCuenta varchar(3) = '',
	@esDeIdEstatus int = 0
AS
BEGIN
	DECLARE @idPerTra INT;

	INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus])
     VALUES
           (@idUsuario
           ,@idTramite
           ,GETDATE()
           ,@estatus)

	SET @idPerTra = SCOPE_IDENTITY()

	INSERT INTO [dbo].[tramiteDevoluciones]
           ([id_perTra]
           ,[id_formaPago]
           ,[id_departamento]
		   ,[traDe_devTotal]
           ,[traDe_Observaciones]
           ,[id_empresa]
           ,[id_sucursal]
		   ,[PER_IDPERSONA]
		   ,[esDe_IdEstatus]
		   ,[cuentaBancaria]
		   ,[numeroCLABE]
		   ,[cveBanxico]
		   ,[tipoCuentaBancaria])
     VALUES
           (@idPerTra
           ,@idFormaPago
           ,@idDepartamento
		   ,@devTotal
           ,@observaciones
           ,@idEmpresa
           ,@idSucursal
		   ,@idPersona
		   ,@esDeIdEstatus
		   ,@cuentaBancaria
		   ,@numeroCLABE
		   ,@cveBanxico
		   ,@bancoTipoCuenta)

		insert into BitacoraTramite values (@idUsuario,@idPerTra, 'Solicitud de Trámite', getdate(),@esDeIdEstatus)

		SELECT success = 1, msg = 'Se inserto correctamente el tramite', idPerTra = @idPerTra, 
		saveUrl = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC');
END
go

