-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Tramite].[Sp_Tramite_CuentaAtorizada_GET] 2582,localhost
-- 2560
CREATE PROCEDURE [Tramite].[Sp_Tramite_CuentaAtorizada_GET]
	@perTra INT
	,@urlParam varchar(150)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		DECLARE @Correos VARCHAR(500), @ruta VARCHAR(255),  @url VARCHAR(500), @rutaINE VARCHAR(255), @idpersona int, @idPersonaAdicional int;

	  IF (@urlParam = 'localhost')
	  BEGIN
		SET @url = (SELECT
			pr_descripcion
		  FROM parametros
		  WHERE pr_identificador = @urlParam);
	  END
	  ELSE
	  BEGIN
		SET @url = (SELECT
			pr_descripcion
		  FROM parametros
		  WHERE pr_identificador = 'GET_SERVER');
	  END

	select @idpersona = gv.idPersona
	from Tramites..personaTramite t
	join tramites..usuariosGastosViaje gv
	on t.id_persona = gv.idUsuario
	where  t.id_perTra = @perTra

   
	SELECT @Correos = usu_correo FROM [dbo].[cuentaAutorizada] CA
	LEFT JOIN ControlAplicaciones.dbo.cat_usuarios USU ON CA.idSolicitante = USU.usu_idusuario
	WHERE id_perTra = @perTra;

	set @ruta = @url+'DocumentosGV/Persona_'+ CAST(@idpersona AS VARCHAR(10))  + '/13_comprobacion.pdf'
	set @rutaINE = @url+'DocumentosGV/Persona_'+ CAST(@idpersona AS VARCHAR(10))  + '/4_comprobacion.pdf'


	SELECT 
		CA.* 
		 --,EstadoCuenta = 'C:\\NodeApps\\Tramites\\app\\static\\documentos\\Comprobacion\\Comprobacion_'+ CONVERT( VARCHAR(10), @perTra ) +'\\13_comprobacion_1.pdf'
		--,EstadoCuenta = 'http://localhost:1200/documentos/Comprobaciones/Comprobacion/Comprobacion_'+ CONVERT( VARCHAR(10), @perTra ) +'/13_comprobacion.pdf'
		,EstadoCuenta = @ruta
		,INE = @rutaINE
		,@Correos sorreoSilicitante
	FROM [dbo].[personaTramite] PT
	INNER JOIN [dbo].[cuentasTesoreria] CT ON PT.id_perTra = CT.id_perTra
	INNER JOIN [dbo].[cuentaAutorizada] CA ON CA.id_perTra = PT.id_perTra
	WHERE PT.id_perTra = @perTra;
END


go

