-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [dbo].[SEL_OBTIENE_CORREO_ROL] 4, 7, 10, 22
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENE_CORREO_ROL]
	-- Add the parameters for the stored procedure here
  @idTramite INT
, @idRol INT
, @idEmpresa INT
, @idSucursal INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
	DECLARE
	  @idRolSiguiente INT
	  ,@idArea INT
	  ,@email NVARCHAR(255)
	  ,@nombreUsuarioMail nvarchar(MAX) = '';
	  
		DECLARE @maxCount INT, @minCount INT, @correos VARCHAR(MAX) = '';

		DECLARE @totalMail TABLE (rowNumber INT, correo VARCHAR(100), nombre VARCHAR(100))


	-- Obtenemos el rol siguiente
	SELECT 
		@idRolSiguiente = frt.idRolSiguiente
	FROM Tramites.Tramite.FlujoRolTramite frt
	WHERE frt.idTramite = @idTramite
	AND frt.idRol = @idRol

	--obtenemos el area del rolsiguiente
	SELECT 
		@idArea = frt.idArea
	FROM Tramites.Tramite.FlujoRolTramite frt
	WHERE frt.idTramite = @idTramite
	AND frt.idRol = @idRol

	--Obtenemos el correo del rol siguiente
	--si el rol es 7 es necesaria la informacion de la empresa y sucursal
	IF (@idRolSiguiente = 7)
	 BEGIN  
			SELECT 
				@maxCount = MAX(x.contador),
				@minCount = MIN(x.contador)
			FROM (
					SELECT 
						ROW_NUMBER() OVER(ORDER BY usu_correo ASC) AS contador,
						usu_correo, 
						ca.usu_nombre+' '+ca.usu_paterno+' '+ ca.usu_materno As nombreCompleto
					  FROM usuarioRol UR
					  INNER JOIN ControlAplicaciones.DBO.cat_usuarios CA ON CA.usu_idusuario = UR.idUsuario
					  WHERE UR.idRol = @idRolSiguiente 
					  AND UR.id_area = @idArea
					  AND CA.emp_idempresa = @idEmpresa 
					  AND CA.suc_idsucursal = @idSucursal
					GROUP BY usu_correo, ca.usu_nombre, ca.usu_paterno, ca.usu_materno) x

			INSERT INTO @totalMail
			SELECT 
				ROW_NUMBER() OVER(ORDER BY usu_correo ASC) AS contador,
				usu_correo, 
				ca.usu_nombre+' '+ca.usu_paterno+' '+ ca.usu_materno As nombreCompleto
			FROM usuarioRol UR
			INNER JOIN ControlAplicaciones.DBO.cat_usuarios CA ON CA.usu_idusuario = UR.idUsuario
			WHERE UR.idRol = @idRolSiguiente 
			AND UR.id_area = @idArea
			AND CA.emp_idempresa = @idEmpresa 
			AND CA.suc_idsucursal = @idSucursal
			GROUP BY usu_correo, ca.usu_nombre, ca.usu_paterno, ca.usu_materno

			WHILE (@minCount <= @maxCount)
				BEGIN
		
					SELECT 
						@email = correo
					FROM @totalMail WHERE rowNumber = @minCount

					IF (@email like '[a-z,0-9,_,-]%@[a-z,0-9,_,-]%.[a-z][a-z]%' AND @email NOT like '%@%@%'  
						 AND CHARINDEX('.@',@email) = 0  
						 AND CHARINDEX('..',@email) = 0  
						 AND CHARINDEX(',',@email) = 0  
						 AND RIGHT(@email,1) between 'a' AND 'z'  )
					BEGIN
					   SELECT 
							@correos = @correos + ' ' + TM.correo + ';',
							@nombreUsuarioMail = @nombreUsuarioMail + ' ' + TM.nombre + ','
						FROM @totalMail TM WHERE rowNumber = @minCount
					END
					SET @minCount = @minCount + 1;
				END

				IF( LEN(@correos) > 0 )
					BEGIN
						 SELECT 1 AS success, @correos AS email, SUBSTRING(@nombreUsuarioMail, 0, LEN(@nombreUsuarioMail)) AS nombreUsuarioMail
					END
				ELSE
					BEGIN
						SELECT 0 AS success, @correos AS email, @nombreUsuarioMail AS nombreUsuarioMail
					END
	END
	ELSE 
		BEGIN
			SELECT 
				@maxCount = MAX(x.contador),
				@minCount = MIN(x.contador)
			FROM (
					SELECT 
						ROW_NUMBER() OVER(ORDER BY usu_correo ASC) AS contador,
						usu_correo, 
						ca.usu_nombre + ' ' + ca.usu_paterno + ' ' + ca.usu_materno AS nombreCompleto
					FROM usuarioRol UR
					INNER JOIN ControlAplicaciones.DBO.cat_usuarios CA 
					ON CA.usu_idusuario = UR.idUsuario
					WHERE UR.idRol = @idRolSiguiente
					AND UR.id_area = @idArea
					GROUP BY usu_correo, ca.usu_nombre, ca.usu_paterno, ca.usu_materno) x

			INSERT INTO @totalMail
			SELECT 
				ROW_NUMBER() OVER(ORDER BY usu_correo ASC) AS contador,
				usu_correo, 
				ca.usu_nombre + ' ' + ca.usu_paterno + ' ' + ca.usu_materno AS nombreCompleto
			FROM usuarioRol UR
			INNER JOIN ControlAplicaciones.DBO.cat_usuarios CA 
			ON CA.usu_idusuario = UR.idUsuario
			WHERE UR.idRol = @idRolSiguiente
			AND UR.id_area = @idArea
			GROUP BY usu_correo, ca.usu_nombre, ca.usu_paterno, ca.usu_materno

			WHILE (@minCount <= @maxCount)
				BEGIN
		
					SELECT 
						@email = correo
					FROM @totalMail WHERE rowNumber = @minCount

					IF (@email like '[a-z,0-9,_,-]%@[a-z,0-9,_,-]%.[a-z][a-z]%' AND @email NOT like '%@%@%'  
						 AND CHARINDEX('.@',@email) = 0  
						 AND CHARINDEX('..',@email) = 0  
						 AND CHARINDEX(',',@email) = 0  
						 AND RIGHT(@email,1) between 'a' AND 'z'  )
					BEGIN
					   SELECT 
							@correos = @correos + ' ' + TM.correo + ';',
							@nombreUsuarioMail = @nombreUsuarioMail + ' ' + TM.nombre + ','
						FROM @totalMail TM WHERE rowNumber = @minCount
					END
					SET @minCount = @minCount + 1;
				END

				IF( LEN(@correos) > 0 )
					BEGIN
						 SELECT 1 AS success, @correos AS email, SUBSTRING(@nombreUsuarioMail, 0, LEN(@nombreUsuarioMail)) AS nombreUsuarioMail
					END
				ELSE
					BEGIN
						SELECT 0 AS success, @correos AS email, @nombreUsuarioMail AS nombreUsuarioMail
					END
		END

END
go

