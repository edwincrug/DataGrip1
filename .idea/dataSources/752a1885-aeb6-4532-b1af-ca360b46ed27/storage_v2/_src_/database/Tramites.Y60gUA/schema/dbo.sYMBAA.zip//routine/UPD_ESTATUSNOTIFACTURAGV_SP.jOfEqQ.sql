-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <18/10/2019>
-- Description:	<SP que actualiza el estatus del vale>
-- [dbo].[UPD_ESTATUSNOTIFACTURAGV_SP]   37,3,''
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUSNOTIFACTURAGV_SP] 
	@idConceptoArchivo INT,
	@tipo INT
AS
BEGIN

	UPDATE tramite.ConceptoArchivo
	SET estatusNotificacion =  @tipo
	WHERE idConceptoArchivo= @idConceptoArchivo
	
	SELECT success = 1, msg = 'Se actualizo correctamente' 

END
go

