
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC UPD_APROBAR_RECHAZAR_TRAMITE_FF_SP 1112, 2, ''
-- =============================================
CREATE PROCEDURE [dbo].[UPD_APROBAR_RECHAZAR_TRAMITE_FF_SP]
	@id_perTra INT,
	@estatus INT,
	@observaciones nvarchar(max) =''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    /*
	petr_estatus = 3 para indicar que el tramite termino
	esDe_IdEstatus indica el estatus del paso 
	*/
	UPDATE personaTramite
	SET petr_estatus = 3
		,esDe_IdEstatus = @estatus
		,petr_observaciones = @observaciones
	WHERE id_perTra = @id_perTra

	 UPDATE tt
    SET tt.tsb_estatus = case when @estatus = 2 then 1 else -1 end
    FROM Tramites.dbo.tsb_traspasosaldobancosFondoFijo tt
    JOIN Tramites.dbo.traspasosFondoFijoLog l
    ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
    WHERE l.idPerTra = @id_perTra

	UPDATE l
	SET l.fechaAutorizadaRechazada = GETDATE()
	FROM Tramites.dbo.tsb_traspasosaldobancosFondoFijo tt
    JOIN Tramites.dbo.traspasosFondoFijoLog l
	ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
	WHERE l.idPerTra = @id_perTra


	UPDATE t
    SET estatus = 3
	FROM cuentasTesoreria t
	WHERE t.id_perTra  = @id_perTra

	SELECT success = 1, pr_descripcion as ruta FROM parametros WHERE pr_identificador = 'RUTA_DOCTO_TRANS'

END
go

