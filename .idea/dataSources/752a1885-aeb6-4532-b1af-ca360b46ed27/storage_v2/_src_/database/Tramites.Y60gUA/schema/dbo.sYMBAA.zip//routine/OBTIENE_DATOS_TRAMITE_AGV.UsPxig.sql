-- =============================================
-- Author:	ROBERTO ALMANZA
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_DATOS_TRAMITE_AGV] 
	-- Add the parameters for the stored procedure here
	@idPerTra INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
	SELECT d.id_perTra
	  ,t.id_tramite
	  ,d.id_empresa
	  ,d.id_sucursal
	  ,d.id_departamento
	  ,destinoViaje = d.concepto
	  ,iniciaViaje = d.traDe_fechaInicio
	  ,finViaje = d.traDe_fechaFin
	  ,idUsuarioSolicitante =  d.PER_IDPERSONA
	  ,idUsuarioAdicional = te.IdPersona
	  ,rfc = pp.PER_RFC
	  ,nombreUsuario = pp.PER_NOMRAZON+' '+pp.PER_PATERNO+' '+pp.PER_MATERNO
	  FROM personaTramite t
	  JOIN tramiteDevoluciones d
	  ON t.id_perTra = d.id_perTra
	  LEFT JOIN tramite.TramiteEmpleado te
	  ON t.id_perTra = te.idTramiteDevolucion
	  JOIN GA_Corporativa.dbo.PER_PERSONAS pp
		ON CASE WHEN te.IdPersona IS NULL 
				THEN d.PER_IDPERSONA 
				ELSE te.IdPersona 
			end = pp.PER_IDPERSONA
	  WHERE t.id_perTra = @idPerTra
END
go

