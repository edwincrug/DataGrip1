-- =============================================
-- Author:		Luis Garcia
-- Create date: 13/06/2019
-- Description:	Trae los documento sa aprobar del usuario
--TEST SEL_DOCUMENTOS_APROBAR_SP 693, 'localhost'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_APROBAR_SP] 
	@id_perTra INT,
	@urlParam VARCHAR(50)
AS
BEGIN
DECLARE @ruta VARCHAR(50) = '';

		IF(@urlParam = 'localhost')
			BEGIN
				SELECT 
					@ruta = pr_descripcion 
				FROM parametros 
				WHERE pr_identificador = @urlParam
			END
		ELSE
			BEGIN
				SELECT 
					@ruta = pr_descripcion 
				FROM parametros 
				WHERE pr_identificador = 'GET_SERVER'
			END

		SELECT 
				 A.id_documento
				,X.detIdPerTra AS detIdPerTra
				,A.doc_nomDocumento AS nombreDoc
				,X.rutaDocumento AS rutaDocumento
				,X.idExtension AS idExtension
				,X.estatusDoc AS estatusDoc
				,X.estatus AS estatus
				,X.det_observaciobes 
		FROM
		(
		 SELECT 
				  CT.id_documento AS id_documento
				 ,DOC.doc_nomDocumento
				 ,'' AS detIdPerTra
				 ,'' AS rutaDocumento
				 ,'' AS idExtension
				 ,'' AS estatusDoc
				 ,'' AS estatus
				 ,'' AS det_observaciobes
		 FROM cat_tramiteDocumento CT
				 INNER JOIN personaTramite  PT ON PT.id_tramite = CT.id_tramite
				 INNER JOIN cat_documentos DOC ON DOC.id_documento = CT.id_documento
		 WHERE PT.id_perTra = @id_perTra  
		 AND  DOC.id_documento <> 65

		)  A
		LEFT JOIN(
		SELECT 
					TRADO.id_documento,
					DOC.doc_nomDocumento AS nombreDoc,
					DPETR.det_idPerTra AS detIdPerTra,
					@ruta + 'Persona_' + PER.per_rfc + '_' + CONVERT(varchar(10), PERTR.id_tramite) + '/' + 'Documento_' 
					--+ CASE WHEN DOC.id_documento = 11 THEN CONVERT(varchar(10), DOC.id_documento) + '_' +  CONVERT(varchar(10), DPETR.id_perTra)  ELSE  CONVERT(varchar(10), DOC.id_documento) END		
					+ CONVERT(varchar(10), DOC.id_documento) 			
					+ '.' + EXT.ext_nombre AS rutaDocumento,
					EXT.id_extension AS idExtension,
					CASE WHEN DPETR.det_estatus = 2 THEN 'TRUE' ELSE 'FALSE' END AS estatusDoc,
					DPETR.det_estatus AS estatus,
					DPETR.det_observaciobes
					
		FROM detallePersonaTramite DPETR
					INNER JOIN personaTramite PERTR ON PERTR.id_perTra = DPETR.id_perTra
					INNER JOIN personas PER ON PER.id_persona = PERTR.id_persona
					INNER JOIN cat_tramiteDocumento TRADO ON TRADO.id_traDo = DPETR.id_traDo
					INNER JOIN cat_documentos DOC ON DOC.id_documento = TRADO.id_documento
					JOIN cat_extensiones EXT ON EXT.id_extension = DOC.id_extension
		WHERE DPETR.id_perTra = @id_perTra  
		) X ON A.ID_DOCUMENTO = x.id_documento 
		
		--SELECT 
		--	DPETR.det_idPerTra AS detIdPerTra,
		--	DOC.doc_nomDocumento AS nombreDoc,
		--	@ruta + 'Persona_' + PER.per_rfc + '_' + CONVERT(varchar(10), PERTR.id_tramite) + '/' + 'Documento_' + CONVERT(varchar(10), DOC.id_documento) + '.' + EXT.ext_nombre AS rutaDocumento,
		--	EXT.id_extension AS idExtension,
		--	CASE WHEN DPETR.det_estatus = 2 THEN 'TRUE' ELSE 'FALSE' END AS estatusDoc,
		--	DPETR.det_estatus AS estatus
		--FROM detallePersonaTramite DPETR
		--INNER JOIN personaTramite PERTR ON PERTR.id_perTra = DPETR.id_perTra
		--INNER JOIN personas PER ON PER.id_persona = PERTR.id_persona
		--INNER JOIN cat_tramiteDocumento TRADO ON TRADO.id_traDo = DPETR.id_traDo
		--INNER JOIN cat_documentos DOC ON DOC.id_documento = TRADO.id_documento
		--INNER JOIN cat_extensiones EXT ON EXT.id_extension = DOC.id_extension
		--WHERE DPETR.id_perTra = @id_perTra;
END
go

