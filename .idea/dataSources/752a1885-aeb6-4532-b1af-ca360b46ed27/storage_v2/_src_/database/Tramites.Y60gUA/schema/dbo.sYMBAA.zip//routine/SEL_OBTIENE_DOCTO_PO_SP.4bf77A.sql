-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================


CREATE PROCEDURE [dbo].[SEL_OBTIENE_DOCTO_PO_SP] 
   @idPerTra int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	


	DECLARE @nombreBase varchar(20)=''
	, @query nvarchar(max)=''
	,@idEmpresa int
    ,@idSucursal int

   select @idEmpresa = pd.id_empresa
   ,@idSucursal = pd.id_sucursal
   FROM tramiteDevoluciones PD
   where PD.id_perTra = @idPerTra

    SELECT
	@nombreBase =  suc_nombrebd
	FROM [ControlAplicaciones].[dbo].[cat_sucursales]
	WHERE emp_idempresa = @idEmpresa 
	AND suc_idsucursal = @idSucursal 
	AND suc_estatus = 1;

	set @query ='SELECT
    TD.id_perTra,
    TD.id_traDe,
    SUM(dd.docDe_valorDev) as traDe_devTotal,
    TD.id_empresa,
    TD.id_sucursal,
    TD.PER_IDPERSONA,
    TD.efectivoBanco,
    TD.efectivoCuenta,
    CT.estatus,
	EMD.e_efectivo,
	EMD.e_noEfectivo
	FROM personaTramite PT' + CHAR(13) +
	'INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra' + CHAR(13) +
	'INNER JOIN cuentasTesoreria CT ON CT.id_perTra = PT.id_perTra' + CHAR(13) +
	'INNER JOIN documentosDevueltos DD ON DD.id_traDe = TD.id_traDe' + CHAR(13) +
	'INNER JOIN EstatusMixtosDevoluciones EMD ON EMD.id_perTra = PT.id_perTra' + CHAR(13) +
	'INNER JOIN' + '[' + @nombreBase + '].[DBO].[VIS_CONCAR01] AS CAR ON CCP_TIPODOCTO = ''ANT'' AND DD.docDe_documento = CAR.CCP_IDDOCTO COLLATE DATABASE_DEFAULT' + CHAR(13) +
	'INNER JOIN ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] AS PNC ON CAR.CCP_CARTERA = PNC.PAR_IDENPARA AND PAR_TIPOPARA = ''CARTERA''' + CHAR(13) + --AND PAR_DESCRIP1 LIKE ''%UNIDADES%'''  
	'WHERE PT.id_perTra = ' + CONVERT(varchar(10), @idPerTra) + '
	AND (docDe_tipoPago = ''EF'' OR docDe_tipoPago = ''39'')
	GROUP BY TD.id_perTra,TD.id_traDe,TD.id_empresa, TD.id_sucursal, TD.PER_IDPERSONA,TD.efectivoBanco, TD.efectivoCuenta, CT.estatus, EMD.e_efectivo, EMD.e_noEfectivo';

	PRINT @query
	EXEC(@query)

END
go

