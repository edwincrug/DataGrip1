
-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <05/02/2020>
-- Description:	<Inserta la bitacora y proceso del tramite>
-- ============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_BITCORREO_SP]
	@id_perTra INT,
	@proceso varchar(255),
	@destinatarios varchar(max),
	@encabezado varchar(max),
	@cuerpo nvarchar(max),
	@enviado INT,
	@comentario  nvarchar(max)

AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY

	
		INSERT INTO [Tramite].[BitacoraCorreos_FFGV] ( [id_perTra], [proceso],[destinatarios],[encabezado],[cuerpo],[fecha],[enviado], [comentario])
		VALUES  (@id_perTra, @proceso, @destinatarios, @encabezado, @cuerpo, GETDATE(), @enviado, @comentario)

	
	SELECT success = 1, msg = 'Se inserto correctamente'

END TRY
	BEGIN CATCH
		
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

