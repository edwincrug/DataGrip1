-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[Fn_Tramites_ValeVencido_CalculaHoras_v2]
(
	-- Add the parameters for the function here
	@dt1 varchar(30),
	@dt2 varchar(30),
	@validaDiaActual INT = NULL
)
RETURNS NUMERIC(5,2)
AS
BEGIN

	DECLARE @Debug BIT = 0;



	SET @dt1 = CONVERT( datetime, @dt1, 120 );
	SET @dt2 = CONVERT( datetime, @dt2, 120 );

	--DECLARE @dt2 DATETIME = GETDATE();

	--SET @dt2 = CONVERT( varchar(300), @dt2, 120 );

	-- Fechas para el ciclo de dias que intervienen en el calculo
	DECLARE @shortDateInit DATE = CONVERT( DATE, @dt1, 111 )
	DECLARE @shortDateEnd DATE = CONVERT( DATE, @dt2, 111 )

	-- Variables para control del calculo
	DECLARE @flagFirstDay INT = 1;
	DECLARE @HorasSumatoria NUMERIC(5,2) = 0;
	DECLARE @UltimaHrDia DATETIME;
	DECLARE @Minutos INT

	-- ALIDA QUE LA FECHA INICIO NO SEA MAYOR QUE LA FECHA FIN
	--IF( @dt1 < @dt2 )
	IF( 1 = 1 )
		BEGIN
			-- Ciclo de los dias que intervienen en el cálculo
			-- Ciclo de los dias que intervienen en el cálculo
			-- Ciclo de los dias que intervienen en el cálculo
			WHILE( @shortDateInit <= @shortDateEnd)
				BEGIN
					IF( UPPER(DATENAME(DW, @shortDateInit)) = 'DOMINGO'  OR UPPER(DATENAME(DW, @shortDateInit)) = 'SUNDAY' )
						BEGIN
							-- PRINT(DATENAME(DW, @shortDateInit) + ' No suma horas')
							SET @Minutos = 0;
						END
					ELSE
						BEGIN
							IF( 
								@flagFirstDay = 1 -- Valida si es el primer dia
								AND ( CONVERT(VARCHAR(10), @dt1) != CONVERT(VARCHAR(10), @dt2) )  -- Valida que las fechas inicio y fin sean diferente
								AND ( UPPER(DATENAME(DW, @shortDateInit)) != 'DOMINGO'  OR UPPER(DATENAME(DW, @shortDateInit)) != 'SUNDAY' ) -- Valida que ademas no sea domingo
							)
								BEGIN
									-- Calculamos las horas del primer día
									-- PRINT(DATENAME(DW, @shortDateInit) + ' Primer día')

									-- Validación dia actual (Ocurre si la entrega del efectivo ocurre a una detarminada hora )
									-- Por ejemplo, si la entrega del efectivo se dio a las 5 de la tarde ya no deberia sumar las horas restantes 
									-- del día, siempre y cuando esto aplica de lo contrario ocurrira de forma normal
									IF( @validaDiaActual IS NULL )
										BEGIN
											-- Valida las horas normales del resto del día

											SET @UltimaHrDia = DATEADD( SECOND, -1, ( DATEADD( HOUR, 24, CONVERT(DATETIME,@shortDateInit)) ) );
											SET @Minutos = DATEDIFF(MINUTE, @dt1, @UltimaHrDia)
										END
									ELSE
										BEGIN
											-- Valida si la Hr de entrega de efectivo supera la hora a partir de la cual no suma al conteo
											SET @UltimaHrDia = ( DATEADD( HOUR, @validaDiaActual, CONVERT(DATETIME,@shortDateInit)) );
											IF( @dt1 > @UltimaHrDia  ) 
												BEGIN
													-- Supera la Hr No Suma horas
													SET @UltimaHrDia = DATEADD( SECOND, -1, ( DATEADD( HOUR, 24, CONVERT(DATETIME,@shortDateInit)) ) );
													SET @Minutos = 0;
												END
											ELSE
												BEGIN
													-- NO Supera la Hr 
													SET @UltimaHrDia = DATEADD( SECOND, -1, ( DATEADD( HOUR, 24, CONVERT(DATETIME,@shortDateInit)) ) );
													SET @Minutos = DATEDIFF(MINUTE, @dt1, @UltimaHrDia)
												END
										END
									SET @flagFirstDay = 0;
								END
							ELSE IF( @shortDateInit = @shortDateEnd ) 
								BEGIN
									--PRINT(DATENAME(DW, @shortDateInit) + ' Último día')
									-- Calculamos las horas del dia actual
									IF( @flagFirstDay = 1 )
										BEGIN
											-- Valida cuando la fecha inicio y fin es la misma
											SET @UltimaHrDia = ( DATEADD( HOUR, @validaDiaActual, CONVERT(DATETIME,@shortDateInit)) );
											IF( @dt1 > @UltimaHrDia  ) 
												BEGIN
													-- Supera la Hr - NO Suma horas
													SET @Minutos = 0;
												END
											ELSE
												BEGIN
													-- NO Supera la Hr - SI Suma horas
													SET @Minutos = DATEDIFF(MINUTE, @dt1, @dt2)
												END
										END
									ELSE
										BEGIN
											SET @Minutos = DATEDIFF(MINUTE, CONVERT(DATETIME,@shortDateInit), @dt2)
										END
						
								END
							ELSE
								BEGIN
									-- PRINT(DATENAME(DW, @shortDateInit) + ' Días intermedios')
									-- Calculamos las horas de los dias intermedios
									SET @Minutos = 1440;
								END
				
							-- Se realiza la sumatoria
							SET @HorasSumatoria = @HorasSumatoria + ( CAST(@Minutos AS FLOAT) / 60 );
						END
				
					SET @shortDateInit = DATEADD( day, 1,  @shortDateInit );
				END
			-- / Fin del ciclo de los dias que intervienen en el cálculo
			-- / Fin del ciclo de los dias que intervienen en el cálculo
			-- / Fin del ciclo de los dias que intervienen en el cálculo
		END
	ELSE
		BEGIN
			SET @HorasSumatoria = NULL
		END


	--SELECT @HorasSumatoria HorasSumatoria

	-- Return the result of the function
	RETURN @HorasSumatoria

END
go

