-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <26/09/2019,>
-- Description:	<Inserta los datos en la tabla de paso de BPRO>
-- TEST INS_DATOS_CXC_DEVOLUCIONES 15
-- =============================================
CREATE PROCEDURE [dbo].[INS_DATOS_CXC_DEVOLUCIONES] 
	@idPerTra INT,
	@result INT OUTPUT
AS
BEGIN
	BEGIN TRY
		IF((SELECT ISNULL(origenBpro,0) from tramiteDevoluciones where id_perTra = @idPerTra) = 0 )
		BEGIN
			INSERT INTO cxc_devoluciones(
			   [cde_idempresa]
			  ,[cde_idsucursal]
			  ,[cde_tipodocto]
			  ,[cde_iddocto]
			  ,[cde_carteracxp]
			  ,[cde_importeadevolver]
			  ,[cde_estatus]
			  ,[cde_fechasolicitud]
			  ,[CDE_AGRUPADOR])
			SELECT 
				TD.id_empresa,
				td.id_sucursal,
				DD.docDe_tipoDoc,
				DD.docDe_documento,
				DD.docDe_cartera,
				DD.docDe_valorDev,
				0,
				GETDATE(),
				DD.id_traDe
			FROM personaTramite PT
			INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
			INNER JOIN documentosDevueltos DD ON DD.id_traDe = TD.id_traDe
			WHERE PT.id_perTra = @idPerTra

			INSERT INTO [GA_Corporativa].[DBO].[cxc_devoluciones](
			   [cde_idempresa]
			  ,[cde_idsucursal]
			  ,[cde_tipodocto]
			  ,[cde_iddocto]
			  ,[cde_carteracxp]
			  ,[cde_importeadevolver]
			  ,[cde_estatus]
			  ,[cde_fechasolicitud]
			  ,[CDE_AGRUPADOR])
			SELECT 
				TD.id_empresa,
				td.id_sucursal,
				DD.docDe_tipoDoc,
				DD.docDe_documento,
				DD.docDe_cartera,
				DD.docDe_valorDev,
				0,
				GETDATE(),
				DD.id_traDe
			FROM personaTramite PT
			INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
			INNER JOIN documentosDevueltos DD ON DD.id_traDe = TD.id_traDe
			WHERE PT.id_perTra = @idPerTra
		END

		 SET  @result = 1
		 RETURN @result
	END TRY

	BEGIN CATCH
		SET  @result = 0
		RETURN @result
	END CATCH
END
go

