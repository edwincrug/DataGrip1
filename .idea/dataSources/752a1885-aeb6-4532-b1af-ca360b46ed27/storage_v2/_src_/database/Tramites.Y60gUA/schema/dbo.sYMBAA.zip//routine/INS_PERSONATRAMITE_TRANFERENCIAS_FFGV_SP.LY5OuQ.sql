

-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_PERSONATRAMITE_TRANFERENCIAS_FFGV_SP]
	-- Add the parameters for the stored procedure here
	@idPersona INT,
	@idTramite INT,
	@idTransferencia int,
	@idPertraFFyGV int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @idPerTra int = 0, @consecutivo int

    INSERT INTO [dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus]
		   ,esDe_IdEstatus)
     VALUES(
           @idPersona,
		   @idTramite,
		   GETDATE(),
		   0,
		   1)

	set @idPerTra = @@IDENTITY

	INSERT INTO cuentasTesoreria(
		id_perTra
		,fechaInsercion
		,estatus
		,fechaAtencion
		,id_tipoTramite
	)
	values(
	 @idPerTra
	 ,GETDATE()
	 ,1
	 ,NULL
	 ,@idTramite
	)

	/*Obtenemos el ultimo consecutivo*/
	
	SELECT @consecutivo = ISNULL(MAX(tf.consecutivo),0)+1
	FROM traspasosFondoFijoLog ffl
	JOIN Tramites..tsb_traspasosaldobancosFondoFijo tff
	  ON ffl.idtransferencia = tff.tsb_idtraspasosaldobancos
	JOIN cuentasTesoreriaFA tf
	  ON tff.tsb_importe = tf.monto
		AND tf.id_perTra = ffl.idPerTraFFyGV
	WHERE ffl.idPerTraFFyGV = @idPertraFFyGV
	--AND ffl.idPerTra = @idPerTra
	AND ffl.consecutivo IS NULL

	update tl
	set tl.idPerTra = @idPerTra, tl.idPerTraFFyGV = @idPertraFFyGV, tl.consecutivo = @consecutivo
	from traspasosFondoFijoLog tl
	where tl.idtransferencia = @idTransferencia
	
	select 'OK' as estatus, 'Se genero ha generado el tramite' as mensaje, cast(@idPerTra as varchar(6)) as idTramite

END
go

