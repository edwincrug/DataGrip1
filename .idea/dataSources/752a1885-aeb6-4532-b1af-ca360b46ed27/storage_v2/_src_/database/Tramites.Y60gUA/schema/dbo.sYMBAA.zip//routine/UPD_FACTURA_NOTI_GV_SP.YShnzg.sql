-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <31/01/2020>
-- Description:	<Inserta la poliza>
-- [dbo].[UPD_FACTURA_NOTI_GV_SP]  334
-- =============================================
CREATE PROCEDURE [dbo].[UPD_FACTURA_NOTI_GV_SP] 
@idComprobacion INT

AS
BEGIN

DECLARE @idusuario INT,
		@idempresa INT,
		@idsucursal INT,
		@id_perTra INT = 0,
		@producto VARCHAR(255),
		@precioUnitario DECIMAL(18,2), 
		@areaAfectacion varchar (50),
		@conceptoContable varchar (50),
		@tipoComprobante varchar (50),
		@observaciones VARCHAR(255),
		@descuento decimal(18,2) = 0,
		@idVale INT,
		@mesCorriente INT

--SELECT 
--@idempresa = ff.idEmpresa,
--@idsucursal = ff.idSucursal,
--@id_perTra = ff.id_perTra,
--@producto = ve.idcomprobacionVale,
--@precioUnitario = ve.monto,
--@mesCorriente = fv.mesCorriente	
--FROM tramite.valesEvidencia ve
--INNER JOIN tramite.vales v on v.id = ve.idVales
--INNER JOIN Tramite.valesFondoFijo vff on vff.idVales = v.id
--INNER JOIN Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--INNER JOIN Tramite.facturaVale fv  on fv.idValeEvidencia = ve.id
--WHERE ve.id = @idComprobacion


select @mesCorriente = mesCorriente	 from tramite.conceptoarchivo where idconceptoarchivo = @idComprobacion

IF(@mesCorriente = 3 OR @mesCorriente = 4)
BEGIN
UPDATE tramite.conceptoarchivo
--SET fecha = FechaCreacion, estatusNotificacion = 3
SET fecha = getdate(), estatusNotificacion = 3
where idconceptoarchivo = @idComprobacion
END

IF(@mesCorriente = 5)
BEGIN
UPDATE tramite.conceptoarchivo
--SET fechaFactura = FechaCreacion, estatusNotificacion = 5
SET fecha = getdate(), estatusNotificacion = 3
where idconceptoarchivo = @idComprobacion

UPDATE tramite.conceptoarchivo
--SET tipoIVA = 0 , conceptoAfectacion = '9031'
SET tipoIVA = 0 
where idconceptoarchivo = @idComprobacion

END

 
END
go

