
-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <13/01/2020>
-- Description:	<Inserta la poliza>
--  [dbo].[INS_FONDOFIJO_POLIZA_SP] 2045, 6, 27, 'FF-ZM-NZA-SE-1-4-2', 200, '', 'SE', 0, '',''
-- ============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_POLIZA_SP]
	@idusuario INT,
	@idsucursal INT,
	@tipoProceso INT,
	@documentoOrigen VARCHAR(100),
	@ventaUnitario numeric(18,2),
	@tipoProducto VARCHAR(100),
	@canal VARCHAR(100),
	@id_perTra INT = 0,
	@banco VARCHAR (100) = NULL,
	@departamento VARCHAR (100) = NULL,
	@ordenCompra varchar(100) = NULL,
	@ordenMasiva int = 0
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	--Parametros dentro SP
DECLARE @nombreBD VARCHAR(100),
		@nombreBDConsen VARCHAR(100),
	    @ipBD VARCHAR(100),
		@proceso VARCHAR(100),
		@fecha VARCHAR(100),
		@hora VARCHAR(100),
		@fiscalOInterna VARCHAR(100) = 'I',
		@referencia2 VARCHAR(100),
		@claveUsuario VARCHAR(100) = 'GMI',
		@subproducto VARCHAR(100) = '',
		@origen VARCHAR(100),
		@moneda VARCHAR(100) = 'PE',
		@idEncabezado INT = 0,
		@idDetalle INT = 0,
		@insertaEncabezado INT = 1,
		@insertaDet INT  = 1,
		@documento  VARCHAR(100) = '',
		@documentoAfectado  VARCHAR(100) = '',
		@estatusCartera   VARCHAR(100) = '',
		@persona1 INT = 0,
		@Count INT = 0,
		@referencia1  VARCHAR(100) = '',
		@referencia3  VARCHAR(100) = '',
		@tasaIVA INT = 0,
		@IVA DECIMAL(18,2) = 0,
		@QueryE NVARCHAR(MAX),
		@ventaO DECIMAL (18,2),
		@queryConcentradora NVARCHAR(MAX),
		@queryIVA NVARCHAR(MAX),
		@queryRetencion NVARCHAR(MAX),
		@retIVA DECIMAL (18,2) = 0,
        @retISR DECIMAL (18,2) = 0,
		@tasaRetIVA DECIMAL (18,4) = 0,
		@tasaRetISR DECIMAL (18,4) = 0,
		@tasaIVACal DECIMAL (18,4) = 0,
		@referenciaE2  VARCHAR(100),
		@referenciaE1  VARCHAR(100) = '',
		@tipoComprobante VARCHAR(100),
		@tipoIVA  VARCHAR(100),
		@Destino varchar (100) = '',
		@incremental INT = 0,
		@GV varchar(50),
		@emp_nombrecto  varchar(10),
		@suc_nombrecto  varchar(10),
		@dep_nombrecto  varchar(10),
		@idEmpresaGV INT,
		@idSucursalGV INT,
		@idDepartamentoGV INT,
		@idFondoFijo varchar(100),
		@idAnticipoGasto varchar(100),
		@porc varchar(50),
		@tasaIVACalculado INT,
		@esFactura INT,
		@version varchar(200) = '',
		@complemento varchar(10),
		@rfcFac varchar(50),
		@cuentaContable varchar(50),
		@agenciaBD VARCHAR(100) = '',
		@persona2 INT = 0
		DECLARE @tipoCompAbreviatura varchar(20)

		SET @documento = @documentoOrigen

		

select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
select @complemento = complemento from [Tramite].[cat_Polizas_FFAG] where idSucursal = @idsucursal
Select @fecha = CONVERT(varchar,GETDATE(),103)  --CONVERT(varchar,DATEADD(DAY,-1,GETDATE()),103)  
Select @hora =  CONVERT(varchar,GETDATE(),108)  --CONVERT(varchar,DATEADD(DAY,-1,GETDATE()),108)  
--select @nombreBD 
SET @agenciaBD = @nombreBD;

---- 1.-Solicitar FF OP ----
IF(@tipoProceso = 1)
BEGIN
SET @proceso = 'FFOP' + @complemento
SET @canal = @proceso 
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @documentoAfectado = @documentoOrigen
SET @tipoProducto = 'FONFIJ'
SET @subproducto = @departamento
SET @origen = @banco
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
--SET @origen = 'FF'
--SET @referencia3 = @banco
--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT

END

---- 2.-Solicitar FF por C Entrada ----
IF(@tipoProceso = 2)
BEGIN
SET @proceso = 'FFCE' + @complemento
SET @canal = @proceso
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @documentoAfectado = @documentoOrigen
SET @tipoProducto = 'FONFIJ'
SET @origen = @banco
--SET @origen = 'FF'
--SET @referencia3 = @banco
--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT
EXEC  [dbo].[INS_FONDOFIJO_DOCTOSNOTRANSFERIBLES_SP]  @idsucursal, @proceso, @documento, @id_perTra

END

---- 3.-Solicitar FF por C Salida ----
IF(@tipoProceso = 3)
BEGIN
SET @proceso = 'FFCS' + @complemento
SET @canal = @proceso
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @documentoAfectado = @documentoOrigen
SET @tipoProducto = 'FONFIJ'
SET @subproducto = @departamento
SET @origen = @banco
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
--SET @origen = 'FF' 
--SET @referencia3 = @banco
--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT
EXEC  [dbo].[INS_FONDOFIJO_DOCTOSNOTRANSFERIBLES_SP]  @idsucursal, @proceso, @documento, @id_perTra

END

---- 4.-Decrementar el Fondo fijo OP ----
IF(@tipoProceso = 4)
BEGIN
SET @proceso = 'DFFD' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @documentoAfectado = @documentoOrigen
SET @tipoProducto = 'FONFIJ'
SET @subproducto = @departamento
IF(@banco = '')
BEGIN
select @origen = cuentaEnvio from [Tramite].[cat_CuentasContableBancosFFGV] where polizaEnvio = 1 and idsucursal = @idsucursal
END
ELSE
BEGIN
SET @origen = @banco
END
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
--SET @origen = 'FF' 
END

---- 5.-Decrementar el Fondo fijo CAJ ----
IF(@tipoProceso = 5)
BEGIN
SET @proceso = 'DFFC' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @documentoAfectado = @documentoOrigen
SET @tipoProducto = 'FONFIJ'
SET @subproducto = @departamento
SET @origen = ''
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
--SET @origen = 'FF' 

END

---- 6.-Provisión vale ----
IF(@tipoProceso = 6)
BEGIN
SET @proceso = 'PVFF' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @documentoAfectado = @documentoOrigen
SET @estatusCartera = 'ENTREGADO'
--SET @origen = '' 
SET @origen = 'DD' 
SET @subproducto = @departamento
select @persona1 = PER_IDPERSONA from tramite.vales where idvale = @documentoOrigen
SET @Count = 1
--SET @origen = 'FF' 
--SET @tipoProducto = 'SE'

END

---- 7.-Aplicación vale ----
IF(@tipoProceso = 7)
--Dos detalles
BEGIN
	--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del vale
	select 
	--@subproducto = conceptoAfectacion, 
	--@origen= areaAfectacion, 
	--@retIVA = IVAretencion, 
	--@retISR = ISRretencion, 
	--@IVA = IVA, 
	--@ventaUnitario = subTotal,
	@tipoIVA = tipoIVA,
	@tipoComprobante = tipoComprobante,
	@esFactura = case when idfactura is null then 0 else 1 end
	from  tramite.valesEvidencia where idComprobacionVale = @documentoOrigen
	
	SET @subproducto = 'DD'
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento VARCHAR(100) OUTPUT', @documento OUTPUT
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario / @porc
SET @IVA = (@tasaIVACal/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - @IVA
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
--SET @ventaO = @ventaUnitario / @porc
select @tipoCompAbreviatura = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante

IF(@tipoCompAbreviatura = 'COMI')
BEGIN
SET @ventaO = @ventaUnitario * 0.949367089
END
IF(@tipoCompAbreviatura = 'FLET')
BEGIN
SET @ventaO = @ventaUnitario / 1.12
END
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario

--SET @ventaUnitario = @ventaUnitario - (@IVA - @retIVA)
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario * 1.048951049
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
SET @retISR = (@tasaRetISR/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
--SET @retISR = (@tasaRetISR/100) * @ventaUnitario

--SET @ventaUnitario = @ventaUnitario + @IVA - @retIVA - @retISR
END

SET @proceso = 'AVFF' + @complemento
--SET @referenciaE2 = substring(@documento,0,20) 
SET @referenciaE2 = @documento 
SET @referencia2 = @documentoOrigen
--SET @tipoProducto = @canal
SET @tipoProducto = 'OT'
SET @estatusCartera = 'ENTREGADO'
SET @ventaO = @ventaUnitario
--SET @documentoAfectado = substring(@documento,0,20)

--SET @documentoAfectado = @documento
select  @documentoAfectado = v.idVale from Tramite.valesEvidencia ve
  inner join Tramite.vales v on v.id = ve.idVales
  where idComprobacionVale = @documentoOrigen
SET @referencia1 = @documento
SET  @Count = 1

--USUARIO QUE TRAMITA EL VALE
select  @persona1 = v.PER_IDPERSONA 
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
where ve.idComprobacionVale = @documentoOrigen

----DUEÑO DEL FF
--select  @persona1 =  td.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
--where ve.idComprobacionVale =@documentoOrigen

UPDATE tramite.valesEvidencia SET procesoPoliza = 1, montoPoliza = @ventaUnitario WHERE idcomprobacionvale = @documentoOrigen
	
	
	--SET @origen = 'FF' 
	--SET @tasaIVA = 16
	--SET @IVA = (@ventaUnitario * @tasaIVA) / 100
	--SET @ventaUnitario = @ventaUnitario + @IVA
	--SET @tasaIVA = 0
	--SET @IVA = 0
	--select @persona1 = td.PER_IDPERSONA from tramite.vales v
	--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
	--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
	--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
	--where v.idvale =@documentoOrigen
	----Se agrega para que tome la orden de compra del FF
	--DECLARE @idFondoFijo varchar(200)
	--select @idFondoFijo = FF.idFondoFijo from Tramite.vales V
	--inner join Tramite.valesFondoFijo VFF on VFF.idVales = V.id
	--inner join Tramite.fondoFijo FF on FF.id = VFF.idTablaFondoFijo
	--where V.idVale = @documentoOrigen --@documentoOrigen
	----select @documento = gff_ordencompra from [cuentasxpagar].[dbo].[cxp_fondosfijos]  where gff_documento = @idFondoFijo
	--SET @persona1 = 453547  --Id del acreedor

--DECLARE @Tablevar TABLE(Result INT)
--DECLARE @Query VARCHAR(MAX), @Query2 VARCHAR(MAX), @idvale INT, @montoSolicitado decimal (18,4), @montoVales decimal (18,4), @numVales INT
       

--SET @Query = 'SELECT * FROM  ['+@nombreBD+'].[dbo].[DSBPEncInfo] WHERE DocumentoOrigen = '''+ CAST( @documentoOrigen AS VARCHAR(100)) + ''' and Proceso = '''+ CAST( @proceso AS VARCHAR(100)) + ''''
--SET @Query = 'IF EXISTS (' + @Query + ')
--                BEGIN
--                     select 0
--                END
--            ELSE
--                BEGIN
--                    select 1
--                END
--            '
--INSERT INTO @Tablevar 
--EXEC(@query)

--select @insertaEncabezado = Result FROM @Tablevar 

--IF(@insertaEncabezado = 0)
--BEGIN
		
--SET @query2 ='SELECT  @Count = COUNT(DocumentoOrigen) FROM  ['+@nombreBD+'].[dbo].[DSBPDetInfo] WHERE DocumentoOrigen = '''+ CAST( @documentoOrigen AS VARCHAR(100)) + ''''

--EXECUTE sp_executeSQL @query2, N'@Count INT OUTPUT', @Count OUTPUT
--SET @Count =  @Count + 1
--END
--ELSE
--BEGIN
--select @idvale = id, @montoSolicitado = montoSolicitado  from Tramite.vales where idVale = @documentoOrigen
--select @Count = case when  count(id) = 0 and sum(monto) = @montoSolicitado  then 0 else 1 end  from Tramite.valesEvidencia  where idVales = @idvale and idestatus = 1
--SET @IVA = @montoSolicitado * @tasaIVA
--END
END

---- 8.-Comp. de más Autorizado ----
IF(@tipoProceso = 8)
BEGIN
	--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del vale
	select 
	--@subproducto = conceptoAfectacion, 
	--@origen= areaAfectacion, 
	--@retIVA = IVAretencion, 
	--@retISR = ISRretencion, 
	--@IVA = IVA, 
	--@ventaUnitario = subTotal,
	@tipoIVA = tipoIVA,
	@tipoComprobante = tipoComprobante,
	@esFactura = case when idfactura is null then 0 else 1 end
	from  tramite.valesEvidencia where idComprobacionVale = @documentoOrigen

	SET @subproducto = 'PA'
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	SET  @Count = 1
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento  VARCHAR(100) OUTPUT', @documento OUTPUT
	
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario / @porc
SET @IVA = (@tasaIVACal/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - @IVA
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
select @tipoCompAbreviatura = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante

IF(@tipoCompAbreviatura = 'COMI')
BEGIN
SET @ventaO = @ventaUnitario * 0.949367089
END
IF(@tipoCompAbreviatura = 'FLET')
BEGIN
SET @ventaO = @ventaUnitario / 1.12
END
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - (@IVA - @retIVA)
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
--SET @ventaO = @ventaUnitario / @porc
SET @ventaO = @ventaUnitario * 1.048951049
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
SET @retISR = (@tasaRetISR/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
--SET @retISR = (@tasaRetISR/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario + @IVA - @retIVA - @retISR
END

SET @proceso = 'CVFR' + @complemento
--SET @referenciaE2 = substring(@documento,0,20) 
--SET @referencia2 = substring(@documento,0,20) 
SET @referenciaE2 = @documento 
SET @referencia2 = @documento  
SET @estatusCartera = 'ENTREGADO'
--SET @tipoProducto = @
SET @tipoProducto = 'OT'
--SET @documentoAfectado = substring(@documento,0,20)
SET @documentoAfectado = @documento
SET @referencia1 = @documento


										
								
												 
															 
																 
																  
											   

IF (@esFactura = 1)
BEGIN 
select 
@persona1 = fv.PER_IDPERSONA
from tramite.valesevidencia ve
inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.idComprobacionVale = @documentoOrigen
END
ELSE
BEGIN
SET @persona1 = 410798
END


UPDATE tramite.valesEvidencia SET procesoPoliza = 1 WHERE idcomprobacionvale = @documentoOrigen

update ff
set ff.montoDisponible =ff. montoDisponible - @ventaUnitario
from Tramite.fondoFijo ff
inner join Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join Tramite.vales v on v.id = vff.idVales
inner join Tramite.valesEvidencia ve on ve.idVales = v.id
where ve.idComprobacionVale = @documentoOrigen

update v
set v.montoExcedentePolizas = ISNULL(v.montoExcedentePolizas,0) + @ventaUnitario
from  Tramite.vales v 
inner join Tramite.valesEvidencia ve on ve.idVales = v.id
where ve.idComprobacionVale = @documentoOrigen


--SET @origen = 'FF' 
--SET @documentoAfectado = @documentoOrigen
--SET @tasaIVA = 16 
--SET @IVA = (@ventaUnitario * @tasaIVA) / 100
--SET @ventaUnitario = @ventaUnitario + @IVA
--SET @persona1 = 453547 --Id del acreedor o proveedor

END

---- 9.-Comp. de más No Autorizado ----
IF(@tipoProceso = 9)
BEGIN


--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del vale
	select 
	--@subproducto = conceptoAfectacion, 
	--@origen= areaAfectacion, 
	--@retIVA = IVAretencion, 
	--@retISR = ISRretencion, 
	--@IVA = IVA, 
	--@ventaUnitario = subTotal,
	@tipoIVA = tipoIVA,
	@tipoComprobante = tipoComprobante,
	@esFactura = case when idfactura is null then 0 else 1 end
	from  tramite.valesEvidencia where idComprobacionVale = @documentoOrigen
	
	SET @subproducto = 'PA'
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento  VARCHAR(100) OUTPUT', @documento OUTPUT
	
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario / @porc
SET @IVA = (@tasaIVACal/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - @IVA
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 

select @tipoCompAbreviatura = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante

IF(@tipoCompAbreviatura = 'COMI')
BEGIN
SET @ventaO = @ventaUnitario * 0.949367089
END
IF(@tipoCompAbreviatura = 'FLET')
BEGIN
SET @ventaO = @ventaUnitario / 1.12
END
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - (@IVA - @retIVA)
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
--SET @ventaO = @ventaUnitario / @porc
SET @ventaO = @ventaUnitario * 1.048951049
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
SET @retISR = (@tasaRetISR/100) * @ventaO
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
--SET @retISR = (@tasaRetISR/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario + @IVA - @retIVA - @retISR
END



SET @proceso = 'CVFN' + @complemento
--SET @referenciaE2 = substring(@documento,0,20)  
--SET @referencia2 = substring(@documento,0,20) -- documento generado en la CXP
SET @referenciaE2 = @documento  
SET @referencia2 = @documento
SET @estatusCartera = 'ENTREGADO'
--SET @tipoProducto = @canal
SET @tipoProducto = 'OT'
--SET @documentoAfectado = substring(@documento,0,20) 
--SET @referencia1 = substring(@documento,0,20) 
SET @documentoAfectado = @documento
SET @referencia1 = @documento

--select  @persona1 =  td.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
--where ve.idComprobacionVale =@documentoOrigen

IF (@esFactura = 1)
BEGIN 
select 
@persona1 = fv.PER_IDPERSONA
from tramite.valesevidencia ve
inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.idComprobacionVale = @documentoOrigen
END
ELSE
BEGIN
SET @persona1 = 410798
END

--SET @origen = 'FF' 
--SET @tasaIVA = 16
--SET @IVA = (@ventaUnitario * @tasaIVA) / 100 
--SET @ventaUnitario = @ventaUnitario + @IVA
--SET @persona1 = 453547 --Id del deudor

END

---- 10.-Comp. de menos ----
IF(@tipoProceso = 10)
BEGIN
SET @proceso = 'CVFM' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @estatusCartera = 'ENTREGADO'
SET @tipoProducto = @canal
--SET @origen = '' 
SET @origen = 'DD'
--SET @subproducto = @departamento

select  @persona1=  td.PER_IDPERSONA 
from tramite.vales v 
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where v.idVale = @documentoOrigen

select top 1 @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal and idpersona = @persona1 and cuentaEnvio = @departamento order by id asc
SET @documentoAfectado = @documentoOrigen
SET @Count = 1
select @persona1 = PER_IDPERSONA from tramite.vales where idvale = @documentoOrigen
END

---- 11.-Comp. Descuento nomina ----
IF(@tipoProceso = 11)
BEGIN
SET @proceso = 'CVFD' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @tipoProducto = @canal
SET @estatusCartera = 'ENTREGADO'
--SET @origen = 'FF' 
select @origen = cuentaEnvio from [Tramite].[cat_CuentasContableBancosFFGV] where idsucursal = @idsucursal and polizaEnvio =1
SET @documentoAfectado = @documentoOrigen
--SET @persona1 = 453547 --Id del deudor
select @persona1 = PER_IDPERSONA from tramite.vales where idvale = @documentoOrigen
END

---- 12.-Reem. Por orden de pago ----
IF(@tipoProceso = 12)
BEGIN
SET @proceso = 'RFOP' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @tipoProducto = @canal
SET @estatusCartera = 'ENTREGADO'
--SET @origen = 'FF' 
SET @origen = @banco
SET @documentoAfectado = @documentoOrigen
SET @subproducto = @departamento
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END

---- 13.-Reem. por caja (entrada) ----
IF(@tipoProceso = 13)
BEGIN
SET @proceso = 'RFCE' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @tipoProducto = @canal
SET @estatusCartera = 'ENTREGADO'
--SET @origen = 'FF' 
SET @documentoAfectado = @documentoOrigen
--SET @referencia3 = @banco
SET @origen = @banco
EXEC  [dbo].[INS_FONDOFIJO_DOCTOSNOTRANSFERIBLES_SP]  @idsucursal, @proceso, @documento, @id_perTra

END

---- 14.-Reem. por caja (salida) ----
IF(@tipoProceso = 14)
BEGIN
SET @proceso = 'RFCS' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @estatusCartera = 'ENTREGADO'
SET @tipoProducto = @canal
--SET @origen = 'FF' 
SET @subproducto = @departamento
SET @origen = @banco
SET @documentoAfectado = @documentoOrigen
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra 
EXEC  [dbo].[INS_FONDOFIJO_DOCTOSNOTRANSFERIBLES_SP]  @idsucursal, @proceso, @documento, @id_perTra																									
--SET @referencia3 = @banco


END

---- 15.-Gtos. viaje por orden de pago ----
--Dos detalles
IF(@tipoProceso = 15)
BEGIN
	select @idEmpresaGV = id_empresa, @idSucursalGV = id_sucursal, @idDepartamentoGV = id_departamento from tramitedevoluciones where id_perTra = @id_perTra
	select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cdsg.par_idenPara --cd.dep_nombrecto 
	from ControlAplicaciones.dbo.cat_empresas ce 
	inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	JOIN Tramites.Tramite.cat_Departamentos_Sucursal_GV cdsg
    ON ce.emp_idempresa = cdsg.idEmpresa
    AND cs.suc_idsucursal = cdsg.idSucursal
    AND cdsg.idDepartamento = @idDepartamentoGV
	--inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	where ce.emp_idempresa = @idEmpresaGV 
	and cs.suc_idsucursal = @idSucursalGV 
	--and cd.dep_iddepartamento=@idDepartamentoGV
	
	SELECT @incremental =  ISNULL(MAX(procesadoOP),0) FROM [Tramite].[TramiteConcepto]
	WHERE idTramitePersona =  @id_perTra and procesadoOP is not null
	SET @incremental = @incremental + 1;
    
	SET @GV ='AG-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto  + '-' + CONVERT(varchar(10),@id_perTra)  + '-' + CONVERT(varchar(10), @incremental) 

SET @proceso = 'GVOP' + @complemento
SET @referencia2 = @GV
SET @referenciaE2 = @GV
SET @tipoProducto = 'AC'
SET @origen = 'FF' 
SET @documentoAfectado = @GV
SET @documentoOrigen = @GV
SET @documento = @GV
--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END
SET @Count = 1 -- primer registro
SET @estatusCartera = 'ENTREGADO'

UPDATE Tramite.TramiteConcepto SET documentoConcepto = @GV, procesadoOP = @incremental where idTramitePersona =  @id_perTra and documentoConcepto is null
--UPDATE Tramite.TramiteConcepto SET documentoConcepto = @documentoOrigen where idTramitePersona =  @id_perTra and documentoConcepto is null
END

---- 16.-Gtos. viaje por transferencia ----
IF(@tipoProceso = 16)
BEGIN

	select @idEmpresaGV = id_empresa, @idSucursalGV = id_sucursal, @idDepartamentoGV = id_departamento from tramitedevoluciones where id_perTra = @id_perTra
	select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cdsg.par_idenPara --cd.dep_nombrecto 
	from ControlAplicaciones.dbo.cat_empresas ce 
	inner join ControlAplicaciones.dbo.cat_sucursales cs 
	on ce.emp_idempresa=cs.emp_idempresa
	JOIN Tramites.Tramite.cat_Departamentos_Sucursal_GV cdsg
    ON ce.emp_idempresa = cdsg.idEmpresa
    AND cs.suc_idsucursal = cdsg.idSucursal
    AND cdsg.idDepartamento = @idDepartamentoGV
	--inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	where ce.emp_idempresa = @idEmpresaGV 
	and cs.suc_idsucursal = @idSucursalGV 
	--and cd.dep_iddepartamento=@idDepartamentoGV
	
	SELECT @incremental =  ISNULL(MAX(procesadoOP),0) FROM [Tramite].[TramiteConcepto]
	WHERE idTramitePersona =  @id_perTra and procesadoOP is not null
	--SET @incremental = @incremental + 1;

	SET @GV ='AG-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto  + '-' + CONVERT(varchar(10),@id_perTra)  + '-' + CONVERT(varchar(10), @incremental) 

SET @tipoProducto = 'AC' --@canal
SET @origen = @banco
SET @proceso = 'GVTE' + @complemento
SET @referencia2 = @GV -- Docuemnto a comprobar?
SET @referenciaE2 = @GV
--SET @tipoProducto = 'AC'
--SET @origen = 'FF' 
SET @estatusCartera = 'ENTREGADO'
SET @documentoAfectado = @GV
SET @documentoOrigen = @GV
SET @documento = @GV
--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END

SET @Count = 0 -- primer registro

UPDATE Tramite.TramiteConcepto SET documentoConcepto = @GV, procesadoOP = @incremental where idTramitePersona =  @id_perTra and documentoConcepto is null
--UPDATE Tramite.TramiteConcepto SET documentoConcepto = @documentoOrigen where idTramitePersona =  @id_perTra and documentoConcepto is null

--SET @referencia3 = @banco
--SET @persona1 = 453480 -- es el acreedor es el ID de la sucursal
END

---- 17.-Gtos. viaje por caja ent ----
IF(@tipoProceso = 17)
BEGIN
	select @idEmpresaGV = id_empresa, @idSucursalGV = id_sucursal, @idDepartamentoGV = id_departamento from tramitedevoluciones where id_perTra = @id_perTra
	select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cdsg.par_idenPara --cd.dep_nombrecto 
	from ControlAplicaciones.dbo.cat_empresas ce 
	inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	JOIN Tramites.Tramite.cat_Departamentos_Sucursal_GV cdsg
    ON ce.emp_idempresa = cdsg.idEmpresa
    AND cs.suc_idsucursal = cdsg.idSucursal
    AND cdsg.idDepartamento = @idDepartamentoGV
	--inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	where ce.emp_idempresa = @idEmpresaGV 
	and cs.suc_idsucursal = @idSucursalGV 
	--and cd.dep_iddepartamento=@idDepartamentoGV
	SELECT @incremental =  ISNULL(MAX(procesadoOP),0) FROM [Tramite].[TramiteConcepto]
	WHERE idTramitePersona =  @id_perTra and procesadoOP is not null
	SET @incremental = @incremental + 1;

	SET @GV ='AG-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto  + '-' + CONVERT(varchar(10),@id_perTra)  + '-' + CONVERT(varchar(10), @incremental) 

SET @proceso = 'GVCE' + @complemento
SET @referencia2 = @GV -- Documento a comprobar?
SET @referenciaE2 = @GV
SET @tipoProducto = @canal
--SET @origen = 'FF' 
SET @estatusCartera = 'ENTREGADO'
SET @documentoAfectado = @GV
SET @documentoOrigen = @GV
SET @documento = @GV
SET @origen = @banco
    
UPDATE Tramite.TramiteConcepto SET documentoConcepto = @GV, procesadoOP = @incremental where idTramitePersona =  @id_perTra and documentoConcepto is null
--UPDATE Tramite.TramiteConcepto SET documentoConcepto = @documentoOrigen where idTramitePersona =  @id_perTra and documentoConcepto is null

--SET @referencia3 = @banco
--EXEC  [dbo].[INS_FONDOFIJO_DOCTOSNOTRANSFERIBLES_SP]  @idsucursal, @proceso, @documento, @id_perTra																							   
END

---- 18.-Gtos. viaje por caja sal ----
IF(@tipoProceso = 18)
BEGIN

	select @idEmpresaGV = id_empresa, @idSucursalGV = id_sucursal, @idDepartamentoGV = id_departamento from tramitedevoluciones where id_perTra = @id_perTra
	select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cdsg.par_idenPara  --cd.dep_nombrecto 
	from ControlAplicaciones.dbo.cat_empresas ce 
	inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	  JOIN Tramites.Tramite.cat_Departamentos_Sucursal_GV cdsg
    ON ce.emp_idempresa = cdsg.idEmpresa
    AND cs.suc_idsucursal = cdsg.idSucursal
    AND cdsg.idDepartamento = @idDepartamentoGV
	--inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	where ce.emp_idempresa = @idEmpresaGV 
	and cs.suc_idsucursal = @idSucursalGV 
	--and cd.dep_iddepartamento=@idDepartamentoGV
	
	SELECT @incremental =  ISNULL(MAX(procesadoOP),0) FROM [Tramite].[TramiteConcepto]
	WHERE idTramitePersona =  @id_perTra and procesadoOP is not null

	SET @GV ='AG-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto  + '-' + CONVERT(varchar(10),@id_perTra)  + '-' + CONVERT(varchar(10), @incremental) 

SET @proceso = 'GVCS' + @complemento
SET @referencia2 = @GV -- Documento a comprobar?
SET @referenciaE2 = @GV
SET @tipoProducto = @canal
--SET @origen = 'FF' 
SET @estatusCartera = 'ENTREGADO'
SET @referencia1 = ''
SET @documentoAfectado = @GV
SET @documentoOrigen = @GV
SET @documento = @GV
SET @origen = @banco
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END

UPDATE Tramite.TramiteConcepto SET documentoConcepto = @GV, procesadoOP = @incremental where idTramitePersona =  @id_perTra and documentoConcepto is null

--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
--SET @persona1 = 453480 -- es el acreedor es el ID de la sucursal
--SET @referencia3 = @banco
--EXEC  [dbo].[INS_FONDOFIJO_DOCTOSNOTRANSFERIBLES_SP]  @idsucursal, @proceso, @documento, @id_perTra
END

---- 19.-Ap. Gtos de viaje ----
--Dos detalles
IF(@tipoProceso = 19)
BEGIN
--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del Concepto
	 select 
	 --@subproducto = tc.idConceptoContable, 
	 --@origen= tc.areaAfectacion, 
	 @tipoIVA = ca.tipoIVA,
	 @tipoComprobante = ca.tipoComprobante,
	 @esFactura = case when ca.uuid is null then 0 else 1 end,
	 @rfcFac = ca.rfc
	 from Tramite.ConceptoArchivo ca
	 inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
	 where  ca.idComprobacionConcepto =  @documentoOrigen
	
	SET @subproducto = 'DD'
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento VARCHAR(100) OUTPUT', @documento OUTPUT
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario / @porc
SET @IVA = (@tasaIVACal/100) * @ventaO
--SET @ventaUnitario = @ventaUnitario - @IVA
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @IVA = (@tasaIVACal/100) * @ventaUnitario
SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - (@IVA - @retIVA)
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @IVA = (@tasaIVACal/100) * @ventaUnitario
SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
SET @retISR = (@tasaRetISR/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario + @IVA - @retIVA - @retISR
END

SET @proceso = 'AGVV' + @complemento
--SET @referenciaE2 = substring(@documento,0,20) 
SET @referenciaE2 = @documento 
SET @referencia2 = @documentoOrigen
----SET @tipoProducto = @canal
SET @tipoProducto = 'OT'
SET @estatusCartera = 'ENTREGADO'
SET @ventaO = @ventaUnitario
--SET @documentoAfectado = substring(@documento,0,20)
--SET @documentoAfectado = @documento
SET @referencia1 = @documento
SET  @Count = 1

select @idAnticipoGasto = documentoConcepto from  Tramite.ConceptoArchivo ca 
inner join tramite.tramiteconcepto tc on tc.idtramiteconcepto = ca.idreferencia
where ca.idcomprobacionConcepto = @DocumentoOrigen

SET @documentoAfectado = @idAnticipoGasto

select @id_perTra = tc.idTramitePersona from Tramite.ConceptoArchivo ca
inner join Tramite.TramiteConcepto tc on tc.idtramiteconcepto = ca.idreferencia
where idComprobacionConcepto = @documentoOrigen
--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT

IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END

----IF(@esFactura = 0)
----BEGIN
----SET @persona1 = 410798
----END
----ELSE
----BEGIN
----IF EXISTS (select top 1 * from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac) 
----		BEGIN
----			select top 1  @persona1 = PER_IDPERSONA from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac
----		END
----	ELSE
----		BEGIN
----		SET  @persona1 = 410798
----	END	
----END


UPDATE Tramite.ConceptoArchivo SET procesoPoliza = 1 WHERE idComprobacionConcepto = @documentoOrigen

--SET @proceso = 'AGVV'
--SET @referencia2 = @documentoOrigen
--SET @referenciaE2 = @documentoOrigen
--SET @tipoProducto = 'AC'
--SET @origen = 'FF' 
--SET @estatusCartera = 'ENTREGADO'
--SET @tasaIVA = 16
--SET @IVA = (@ventaUnitario * @tasaIVA) / 100 
--SET @documentoAfectado = @documentoOrigen
--SET @persona1 = 453480 -- es el acreedor es el ID de la sucursal
--SET @Count = 1
--SET @referencia1 = @documentoOrigen

END

---- 20.-Comp. Gtos viaje aut ----
IF(@tipoProceso = 20)
BEGIN
--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del Concepto
	 select 
	 --@subproducto = tc.idConceptoContable, 
	 @Destino = tc.idConceptoContable,
	 --@origen= tc.areaAfectacion, 
	 @tipoIVA = ca.tipoIVA,
	 @tipoComprobante = ca.tipoComprobante,
	 @esFactura = case when ca.uuid is null then 0 else 1 end,
	 @rfcFac = ca.rfc
	 from Tramite.ConceptoArchivo ca
	 inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
	 where  ca.idComprobacionConcepto =  @documentoOrigen
	
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	SET @subproducto = 'PA'
	--select top 1 @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal order by id asc
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento VARCHAR(100) OUTPUT', @documento OUTPUT
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

--IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
--BEGIN
--SET @IVA = (@tasaIVACal/100) * @ventaUnitario
----SET @ventaUnitario = @ventaUnitario - @IVA
--END

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario / @porc
SET @IVA = (@tasaIVACal/100) * @ventaO
--SET @ventaUnitario = @ventaUnitario - @IVA
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @IVA = (@tasaIVACal/100) * @ventaUnitario
SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - (@IVA - @retIVA)
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @IVA = (@tasaIVACal/100) * @ventaUnitario
SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
SET @retISR = (@tasaRetISR/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario + @IVA - @retIVA - @retISR
END

SET @proceso = 'CGFR' + @complemento
--SET @referenciaE2 = substring(@documento,0,20) 
SET @referenciaE2 = @documento 
SET @referencia2 = @documentoOrigen
--SET @tipoProducto = @canal
SET @tipoProducto = 'OT'
SET @estatusCartera = 'ENTREGADO'
SET @ventaO = @ventaUnitario
--SET @documentoAfectado = substring(@documento,0,20)
SET @documentoAfectado = @documento
SET @referencia1 = @documento
SET @Count = 1


select @id_perTra = tc.idTramitePersona from Tramite.ConceptoArchivo ca
inner join Tramite.TramiteConcepto tc on tc.idtramiteconcepto = ca.idreferencia
where idComprobacionConcepto = @documentoOrigen
----IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
----BEGIN
----select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
----END
----ELSE
----BEGIN 
----select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
----END

IF(@esFactura = 0)
BEGIN
SET @persona1 = 410798

END
ELSE
BEGIN

IF EXISTS (select top 1 * from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac) 
		BEGIN
			select top 1  @persona1 = PER_IDPERSONA from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac
		END
	ELSE
		BEGIN
		SET  @persona1 = 410798
	END
END


--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT

UPDATE Tramite.ConceptoArchivo SET procesoPoliza = 1 WHERE idComprobacionConcepto = @documentoOrigen



--SET @proceso = 'CGFR'
--SET @referencia2 = @documentoOrigen
--SET @referenciaE2 = @documentoOrigen
--SET @tipoProducto = @canal
--SET @origen = 'FF' 
--SET @estatusCartera = 'ENTREGADO'
--SET @referencia1 = ''
--SET @tasaIVA = 16
--SET @IVA = (@ventaUnitario * @tasaIVA) / 100 
--SET @documentoAfectado = @documentoOrigen
--SET @persona1 = 453480 -- es el acreedor es el ID de la sucursal
END

---- 21.-Comp. Gtos viaje no aut ----
IF(@tipoProceso = 21)
BEGIN
DECLARE @AreaAfectacionPoliza varchar(10), @DescripcionArea varchar (100), @cuentaenvio varchar(30), @queryCTA Nvarchar(max), @queryConfConta Nvarchar(max)
--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del Concepto
	 select 
	 --@subproducto = tc.idConceptoContable, 
	 --@origen= tc.areaAfectacion, 
	 @AreaAfectacionPoliza = tc.areaAfectacion,
	 @tipoIVA = ca.tipoIVA,
	 @tipoComprobante = ca.tipoComprobante,
	 @esFactura = case when ca.uuid is null then 0 else 1 end, 
	 @rfcFac = ca.rfc
	 from Tramite.ConceptoArchivo ca
	 inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
	 where  ca.idComprobacionConcepto =  @documentoOrigen
	
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	--SET @subproducto = 'PA'		 
select @DescripcionArea = RTRIM(REPLACE(otc_area, (select suc_nombre from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idSucursal), ''))   
from Centralizacionv2.dbo.DIG_ESCALAMIENTO_AREA_AFECT where suc_idsucursal = @idsucursal and PAR_IDENPARA = @AreaAfectacionPoliza

SET @queryCTA ='SELECT  @cuentaenvio = SUBSTRING(CTA_NUMCTA, 1, 9)
FROM ['+@nombreBD+'].[DBO].[CON_CTAS012020] 
WHERE CTA_NUMCTA LIKE ''8001%''
AND CTA_ACUMDET = ''ACUM''
AND CTA_Descripcion like ''%'+@DescripcionArea + '%'''
EXECUTE sp_executeSQL @queryCTA, N' @cuentaenvio varchar(30) OUTPUT',@cuentaenvio OUTPUT
print @queryCTA

SET @queryConfConta = 'select @subproducto = CFG_TIPOEQUIPOGRUPONIVEL
from ['+@nombreBD+'].[DBO].[con_configconta] 
where cfg_proceso = ''CGFN''
and CFG_CONCEPTOCONTABLE = ''OTROS INGRESOS'' 
and CFG_CUENTA like ''%'+@cuentaenvio + '%'''
EXECUTE sp_executeSQL @queryConfConta, N' @subproducto varchar(20) OUTPUT',@subproducto OUTPUT
print @queryConfConta																																							 
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento VARCHAR(100) OUTPUT', @documento OUTPUT
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @IVA = (@tasaIVACal/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - @IVA
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @IVA = (@tasaIVACal/100) * @ventaUnitario
SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario - (@IVA - @retIVA)
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @IVA = (@tasaIVACal/100) * @ventaUnitario
SET @retIVA = (@tasaRetIVA/100) * @ventaUnitario
SET @retISR = (@tasaRetISR/100) * @ventaUnitario
--SET @ventaUnitario = @ventaUnitario + @IVA - @retIVA - @retISR
END

SET @proceso = 'CGFN' + @complemento
--SET @referenciaE2 = substring(@documento,0,20) 
SET @referenciaE2 = @documento 
SET @referencia2 = @documentoOrigen
--SET @tipoProducto = @canal
SET @tipoProducto = 'OT'
SET @estatusCartera = 'ENTREGADO'
SET @ventaO = @ventaUnitario
--SET @documentoAfectado = substring(@documento,0,20)
SET @documentoAfectado = @documento
SET @referencia1 = @documento
--SET @version = 'Excedente de gasto de viaje - CARLA HERNANDEZ' 

--select @idAnticipoGasto = documentoConcepto from  Tramite.ConceptoArchivo ca 
--	inner join tramite.tramiteconcepto tc on tc.idtramiteconcepto = ca.idreferencia
--	where ca.idcomprobacionConcepto = @DocumentoOrigen
--SET @documentoAfectado = @idAnticipoGasto

select @id_perTra = tc.idTramitePersona from Tramite.ConceptoArchivo ca
inner join Tramite.TramiteConcepto tc on tc.idtramiteconcepto = ca.idreferencia
where idComprobacionConcepto = @documentoOrigen
--IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
--BEGIN
--select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
--select  @version = 'Excedente de gasto de viaje -  ' + PER_NOMRAZON + ' ' + PER_PATERNO + ' '+ PER_MATERNO from GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @persona1
--END
--ELSE
--BEGIN 
--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
--select @version = 'Excedente de gasto de viaje -  ' + PER_NOMRAZON + ' ' + PER_PATERNO + ' '+ PER_MATERNO from GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @persona1
--END

IF(@esFactura = 0)
BEGIN
SET @persona1 = 410798
select @version = 'Excedente de gasto de viaje -  ' + PER_NOMRAZON + ' ' + PER_PATERNO + ' '+ PER_MATERNO from GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @persona1
END
ELSE
BEGIN
IF EXISTS (select top 1 * from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac) 
		BEGIN
			select top 1  @persona1 = PER_IDPERSONA from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac
			select @version = 'Excedente de gasto de viaje -  ' + PER_NOMRAZON + ' ' + PER_PATERNO + ' '+ PER_MATERNO from GA_Corporativa.dbo.PER_PERSONAS WHERE  PER_RFC = @rfcFac
		END
	ELSE
		BEGIN
		SET @persona1 = 410798
		select @version = 'Excedente de gasto de viaje -  ' + PER_NOMRAZON + ' ' + PER_PATERNO + ' '+ PER_MATERNO from GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = 410798
	END
END

--END



--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT

UPDATE Tramite.ConceptoArchivo SET procesoPoliza = 1 WHERE idComprobacionConcepto = @documentoOrigen

--SET @proceso = 'CGFN'
--SET @referencia2 = @documentoOrigen
--SET @referenciaE2 = @documentoOrigen
--SET @tipoProducto = @canal
--SET @origen = 'FF' 
--SET @estatusCartera = 'ENTREGADO'
--SET @referencia1 = ''
--SET @tasaIVA = 16
--SET @IVA = (@ventaUnitario * @tasaIVA) / 100 
--SET @documentoAfectado = @documentoOrigen
--SET @persona1 = 453480 -- es el acreedor es el ID de la sucursal
----SET @persona1 = 0 -- es el Id del acreedor o proveedor
END

---- 22.-Comp. Gtos viaje menos por dep ----
IF(@tipoProceso = 22)
BEGIN
SET @proceso = 'CGFM' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @tipoProducto = @canal
select @origen = cuentaEnvio from [Tramite].[cat_CuentasContableBancosFFGV] where idsucursal = @idsucursal and polizaEnvio =1
SET @estatusCartera = 'ENTREGADO'
SET @referencia1 = ''
SET @documentoAfectado = @documentoOrigen
--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END
END																					
	
	
---- 23.-Comp. Gtos viaje menos por caja ----
IF(@tipoProceso = 23)
BEGIN
SET @proceso = 'CGFC' + @complemento
SET @referencia2 = @documentoOrigen
SET @referenciaE2 = @documentoOrigen
SET @tipoProducto = @canal
SET @origen = 'FF' 
SET @estatusCartera = 'ENTREGADO'
--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END																						
SET @documentoAfectado = @documentoOrigen
SET @referencia1 = ''
END

---- 24.-Comp. Gtos viaje descuento nómi ----
IF(@tipoProceso = 24)
BEGIN
SET @proceso = 'CGFD' + @complemento
SET @referencia2 = @documentoOrigen --Documento a comprobar
SET @referenciaE2 = @documentoOrigen
SET @tipoProducto = @canal
select @origen = cuentaEnvio from [Tramite].[cat_CuentasContableBancosFFGV] where idsucursal = @idsucursal and polizaEnvio = 1
SET @estatusCartera = 'ENTREGADO'
SET @documentoAfectado = @documentoOrigen

--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END
SET @referencia1 = ''
END

---- 25.-Desaplicacion Aplicación Vale AVFF ----
IF(@tipoProceso = 25)
--Dos detalles
BEGIN
	--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del vale
	select 
	@tipoIVA = tipoIVA,
	@tipoComprobante = tipoComprobante,
	@esFactura = case when idfactura is null then 0 else 1 end
	from  tramite.valesEvidencia where idComprobacionVale = @documentoOrigen
	
	SET @subproducto = 'DD'
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento VARCHAR(100) OUTPUT', @documento OUTPUT
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario / @porc
SET @IVA = (@tasaIVACal/100) * @ventaO

END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 

select @tipoCompAbreviatura = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante

IF(@tipoCompAbreviatura = 'COMI')
BEGIN
SET @ventaO = @ventaUnitario * 0.949367089
END
IF(@tipoCompAbreviatura = 'FLET')
BEGIN
SET @ventaO = @ventaUnitario / 1.12
END
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO

END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario * 1.048951049
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
SET @retISR = (@tasaRetISR/100) * @ventaO

END

SET @proceso = 'DAVFF' + @complemento
SET @referenciaE2 = @documento 
SET @referencia2 = @documentoOrigen
--SET @tipoProducto = @canal
SET @tipoProducto = 'OT'
SET @estatusCartera = 'ENTREGADO'
SET @ventaO = @ventaUnitario

select  @documentoAfectado = v.idVale from Tramite.valesEvidencia ve
  inner join Tramite.vales v on v.id = ve.idVales
  where idComprobacionVale = @documentoOrigen
SET @referencia1 = @documento
SET  @Count = 1

--USUARIO QUE TRAMITA EL VALE
select  @persona1 = v.PER_IDPERSONA 
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
where ve.idComprobacionVale = @documentoOrigen

--update ff
--set ff.montoDisponible =ff. montoDisponible + @ventaUnitario
--from Tramite.fondoFijo ff
--inner join Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
--inner join Tramite.vales v on v.id = vff.idVales
--inner join Tramite.valesEvidencia ve on ve.idVales = v.id
--where ve.idComprobacionVale = @documentoOrigen
--UPDATE tramite.valesEvidencia SET procesoPoliza = 1, montoPoliza = @ventaUnitario WHERE idcomprobacionvale = @documentoOrigen
	
END

---- 26.-Desaplicacion Comp. de más Autorizado ----
IF(@tipoProceso = 26)
BEGIN
	--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del vale
	select 
	--@subproducto = conceptoAfectacion, 
	--@origen= areaAfectacion, 
	--@retIVA = IVAretencion, 
	--@retISR = ISRretencion, 
	--@IVA = IVA, 
	--@ventaUnitario = subTotal,
	@tipoIVA = tipoIVA,
	@tipoComprobante = tipoComprobante,
	@esFactura = case when idfactura is null then 0 else 1 end
	from  tramite.valesEvidencia where idComprobacionVale = @documentoOrigen

	SET @subproducto = 'PA'
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	SET  @Count = 1
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento  VARCHAR(100) OUTPUT', @documento OUTPUT
	
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario / @porc
SET @IVA = (@tasaIVACal/100) * @ventaO

END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 

select @tipoCompAbreviatura = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante

IF(@tipoCompAbreviatura = 'COMI')
BEGIN
SET @ventaO = @ventaUnitario * 0.949367089
END
IF(@tipoCompAbreviatura = 'FLET')
BEGIN
SET @ventaO = @ventaUnitario / 1.12
END
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario * 1.048951049
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
SET @retISR = (@tasaRetISR/100) * @ventaO
END

SET @proceso = 'DCVFR' + @complemento
SET @referenciaE2 = @documento 
SET @referencia2 = @documento  
SET @estatusCartera = 'ENTREGADO'
--SET @tipoProducto = @canal
SET @tipoProducto = 'OT'
SET @documentoAfectado = @documento
SET @referencia1 = @documento
--select  @persona1 =  td.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
--where ve.idComprobacionVale =@documentoOrigen


IF (@esFactura = 1)
BEGIN 
select 
@persona1 = fv.PER_IDPERSONA
from tramite.valesevidencia ve
inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.idComprobacionVale = @documentoOrigen
END
ELSE
BEGIN
SET @persona1 = 410798
END

--UPDATE tramite.valesEvidencia SET procesoPoliza = 1 WHERE idcomprobacionvale = @documentoOrigen

END

---- 27.-Comp. de más No Autorizado ----
IF(@tipoProceso = 27)
BEGIN

--Se obtiene la concentradora de la agencia
	select @nombreBDConsen = e.emp_nombrebd from ControlAplicaciones.dbo.cat_sucursales s
	inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = s.emp_idempresa
	where s.suc_idsucursal = @idsucursal
	
	--Se obtiene los datos de la comprobacion del vale
	select 
	@tipoIVA = tipoIVA,
	@tipoComprobante = tipoComprobante,
	@esFactura = case when idfactura is null then 0 else 1 end
	from  tramite.valesEvidencia where idComprobacionVale = @documentoOrigen
	
	SET @subproducto = 'PA'
	select @origen = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante
	--Se obtiene la orden de compra 
	SET @queryConcentradora ='SELECT  @documento = odm_ordencompra 
						from ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivas om
						inner join ['+@nombreBDConsen+'].dbo.cxp_ordenesmasivasdet omd on omd.odm_idordenmasiva = om.odm_idordenmasiva
						where  omd.omd_producto = '''+@documentoOrigen+''''	
	EXECUTE sp_executeSQL @queryConcentradora, N'@documento  VARCHAR(100) OUTPUT', @documento OUTPUT
	
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,4) OUTPUT, @tasaRetISR DECIMAL(18,4) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal DECIMAL(18,2) OUTPUT', @tasaIVACal OUTPUT 

IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario / @porc
SET @IVA = (@tasaIVACal/100) * @ventaO
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 

select @tipoCompAbreviatura = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante

IF(@tipoCompAbreviatura = 'COMI')
BEGIN
SET @ventaO = @ventaUnitario * 0.949367089
END
IF(@tipoCompAbreviatura = 'FLET')
BEGIN
SET @ventaO = @ventaUnitario / 1.12
END
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
SET @tasaIVACalculado = CONVERT(INT,@tasaIVACal)
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACalculado) 
SET @ventaO = @ventaUnitario * 1.048951049
SET @IVA = (@tasaIVACal/100) * @ventaO
SET @retIVA = (@tasaRetIVA/100) * @ventaO
SET @retISR = (@tasaRetISR/100) * @ventaO
END

SET @proceso = 'DCVFN' + @complemento
SET @referenciaE2 = @documento  
SET @referencia2 = @documento
SET @estatusCartera = 'ENTREGADO'
--SET @tipoProducto = @canal
SET @tipoProducto = 'OT'
SET @documentoAfectado = @documento
SET @referencia1 = @documento

--select  @persona1 =  td.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
--where ve.idComprobacionVale =@documentoOrigen

IF (@esFactura = 1)
BEGIN 
select 
@persona1 = fv.PER_IDPERSONA
from tramite.valesevidencia ve
inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.idComprobacionVale = @documentoOrigen
END
ELSE
BEGIN
SET @persona1 = 410798
END

END

---- 28.-  ----
IF(@tipoProceso = 28)
BEGIN

	select @idEmpresaGV = id_empresa, @idSucursalGV = id_sucursal, @idDepartamentoGV = id_departamento from tramitedevoluciones where id_perTra = @id_perTra
	
	select @emp_nombrecto = ce.emp_nombrecto, @suc_nombrecto = cs.suc_nombrecto, @dep_nombrecto = cdsg.par_idenPara --cd.dep_nombrecto 
	from ControlAplicaciones.dbo.cat_empresas ce 
	inner join ControlAplicaciones.dbo.cat_sucursales cs 
	on ce.emp_idempresa=cs.emp_idempresa
	JOIN Tramites.Tramite.cat_Departamentos_Sucursal_GV cdsg
    ON ce.emp_idempresa = cdsg.idEmpresa
    AND cs.suc_idsucursal = cdsg.idSucursal
    AND cdsg.idDepartamento = @idDepartamentoGV
	--inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	where ce.emp_idempresa = @idEmpresaGV 
	and cs.suc_idsucursal = @idSucursalGV 
	--and cd.dep_iddepartamento=@idDepartamentoGV

	SELECT @incremental =  ISNULL(MAX(procesadoOP),0) FROM [Tramite].[TramiteConcepto]
	WHERE idTramitePersona =  @id_perTra and procesadoOP is not null
	--SET @incremental = @incremental + 1;
   

	SET @GV ='AG-' + @emp_nombrecto + '-' + @suc_nombrecto + '-' + @dep_nombrecto  + '-' + CONVERT(varchar(10),@id_perTra)  + '-' + CONVERT(varchar(10), @incremental) 
	 
						   
   

SET @tipoProducto = 'OT' --@canal
SET @origen = @banco
SET @proceso = 'GVOC' + @complemento
SET @referencia2 = @GV -- Docuemnto a comprobar?
SET @referenciaE2 = @ordenCompra
set @referencia1 = @ordenCompra
set @subproducto = 'PA'
--SET @tipoProducto = 'AC'
SET @origen = 'FAC' --'FF' 
SET @estatusCartera = 'ENTREGADO'
SET @documentoAfectado = @GV
SET @documentoOrigen = @GV
SET @documento = @ordenCompra
set @persona2  = @ordenMasiva

SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
						 
END

SET @Count = 1 -- primer registro
	 
						  
   

	update tc
	set tc.procesoPoliza = 1
	FROM Tramite.TramiteConcepto TC
	where tc.idTramitePersona = @id_perTra
--UPDATE Tramite.TramiteConcepto SET documentoConcepto = @GV, procesadoOP = @incremental where idTramitePersona =  @id_perTra and documentoConcepto is null
--UPDATE Tramite.TramiteConcepto SET documentoConcepto = @documentoOrigen where idTramitePersona =  @id_perTra and documentoConcepto is null

--SET @referencia3 = @banco
--SET @persona1 = 453480 -- es el acreedor es el ID de la sucursal
							 
END






SET @canal = @proceso


IF(@idsucursal = 1)
BEGIN
SET @agenciaBD = 'Cuautitlan'
END

IF(@idsucursal = 2)
BEGIN
SET @agenciaBD = 'Pedregal'
END

IF(@idsucursal = 3)
BEGIN
SET @agenciaBD = 'Universidad'
END

IF(@idsucursal = 25)
BEGIN
SET @agenciaBD = 'Infiniti'
END

IF(@idsucursal = 18)
BEGIN
SET @agenciaBD = 'Ermita'
END

IF(@idsucursal = 20)
BEGIN
SET @agenciaBD = 'Tlahuac'
END

IF(@idsucursal = 24)
BEGIN
SET @agenciaBD = 'Tepepan'
END

IF(@idsucursal = 22)
BEGIN
SET @agenciaBD = 'Cuautitlan'
END

IF(@idsucursal = 23)
BEGIN
SET @agenciaBD = 'Ecatepec'
END

IF(@idsucursal = 45)
BEGIN
SET @agenciaBD = 'Trasinmex'
END

IF(@idsucursal = 42)
BEGIN
SET @agenciaBD = 'Comunicaciones'
END

IF(@idsucursal = 43)
BEGIN
SET @agenciaBD = 'Operadora'
END

IF(@idsucursal = 44)
BEGIN
SET @agenciaBD = 'Television'
END

IF(@idsucursal = 26)
BEGIN
SET @agenciaBD = 'Comunicaciones'
END

IF(@idsucursal = 54)
BEGIN
SET @agenciaBD = 'Integra'
END

IF(@idsucursal = 52)
BEGIN
SET @agenciaBD = 'Aeropuerto'
END

IF(@idsucursal = 53)
BEGIN
SET @agenciaBD = 'Tepepan'
END


DECLARE @insertEncabezado NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[DSBPEncInfo]
	  ([Agencia]
      ,[Proceso]
      ,[DocumentoOrigen]
      ,[Fecha]
      ,[Hora]
      ,[Canal]
      ,[NumeroControl]
      ,[Documento]
      ,[UUID]
      ,[EstatusContabilizacion]
      ,[EstatusCartera]
      ,[FiscalOInterna]
      ,[Referencia1]
      ,[Referencia2]
      ,[Referencia3]
      ,[ClaveUsuario]
      ,[FechaOperacion]
      ,[HoraOperacion]
      ,[FyHReg_EBp]
      ,[StatusFacturaDalton]
      ,[TipoPol]
      ,[ConsPol]
      ,[MesPol]
      ,[AñoPol]
      ,[EmpresaPol]
      ,[TS])
	  VALUES
	  ('''+@agenciaBD+'''
	  ,'''+@proceso+'''
	  ,'''+@documentoOrigen+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,'''+@canal+'''
	  ,''''
	  ,'''+@documento+'''
	  ,''''
	  ,0
	  ,'''+@estatusCartera+''' 
	  ,'''+@fiscalOInterna+'''
	  ,'''+@referenciaE1+'''
	  ,'''+@referenciaE2+'''
	  ,'''+@referencia3+'''
	  ,'''+@claveUsuario+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,GETDATE()
	  ,NULL
	  ,NULL
	  ,0
	  ,0
	  ,0
	  ,0
	  ,NULL)
'


DECLARE @QueryExiste nvarchar(max)
DECLARE @Tablevar TABLE(Result INT)

SET @QueryExiste = 'SELECT * FROM  ['+@nombreBD+'].[dbo].[DSBPEncInfo] WHERE DocumentoOrigen = '''+ CAST( @documentoOrigen AS VARCHAR(100)) + ''' and Proceso = '''+ CAST( @proceso AS VARCHAR(100)) + ''''
print @QueryExiste
SET @QueryExiste = 'IF EXISTS (' + @QueryExiste + ')
					BEGIN
						select 0
					END
					ELSE
					BEGIN
						select 1
					END
					'
			print @QueryExiste

INSERT INTO @Tablevar 
EXEC(@QueryExiste)
select @insertaEncabezado = Result FROM @Tablevar 


IF(@tipoProceso = 1 OR @tipoProceso = 2 OR @tipoProceso = 3 OR @tipoProceso = 12 OR @tipoProceso = 13 OR @tipoProceso = 14)
BEGIN
SET @insertaEncabezado = 1
END


IF(@insertaEncabezado = 1)
BEGIN
print @insertEncabezado
EXEC(@insertEncabezado)
SET @idEncabezado = @@IDENTITY
END
ELSE
BEGIN
SET @idEncabezado = 1
END

--print @insertEncabezado
--EXEC(@insertEncabezado)
--SET @idEncabezado = @@IDENTITY


DECLARE @insertDetalle NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[DSBPDetInfo]
	  ([Agencia]
      ,[Proceso]
      ,[DocumentoOrigen]
      ,[Fecha]
      ,[Hora]
      ,[Partida]
      ,[TipoProducto]
      ,[SubProducto]
      ,[Origen]
      ,[Destino]
      ,[Moneda]
      ,[TipoCambio]
      ,[Cantidad]
      ,[CostoUnitario]
      ,[VentaUnitario]
      ,[DescuentoUnitario]
      ,[TasaIva]
      ,[IVA]
      ,[ISAN]
      ,[RetIVA]
      ,[RetISR]
      ,[IEPS]
      ,[Persona1]
      ,[Persona2]
      ,[DocumentoAfectado]
      ,[Referencia1]
      ,[Auto]
      ,[Version]
      ,[Color]
      ,[AnioAuto]
      ,[VIN]
      ,[FyHRegDet]
      ,[Referencia2]
      ,[TasaRetIva]
      ,[TasaRetIsr]
      ,[AntiTipoPol]
      ,[AntiConsPol]
      ,[AntiMesPol]
      ,[AntiAñoPol]
      ,[AntiEmpresaPol]
      ,[Importado]
      ,[UUID]
      ,[UUIDNOMBREPDF]
      ,[UUIDNOMBREXML]
      ,[UUIDRUTAPDF]
      ,[UUIDRUTAXML]
      ,[FechaVencimientoDS]
      ,[ISN]
      ,[TasaRetISN])
VALUES
	  ('''+@agenciaBD+'''
	  ,'''+@proceso+'''
	  ,'''+@documentoOrigen+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,'''+ CONVERT(VARCHAR(10),@Count)+'''  
	  ,'''+@tipoProducto+''' 
	  ,'''+@subproducto+'''
	  ,'''+@origen+''' 
	  ,'''+@Destino+''' 
	  ,'''+@moneda+''' 
	  ,1
	  ,1
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@ventaUnitario)+'''
	  ,0 
	  ,'''+ CONVERT(VARCHAR(10),@tasaIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@IVA)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@retIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@retISR)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@persona1)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@persona2)+''' 
	  ,'''+@documentoAfectado+'''  
	  ,'''+ @referencia1+''' 
	  ,''''
	  ,'''+@version+'''
	  ,''''
	  ,''''
	  ,''''
	  ,GETDATE()
	  ,'''+@referencia2+'''  
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetISR)+'''
	  ,''''
	  ,0
	  ,0
	  ,0
	  ,''''
	  ,0
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL)
'

IF(@tipoProceso = 6)
BEGIN
SET @origen = 'FF' 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
select @idFondoFijo = idFondoFijo from Tramite.fondoFijo where id_perTra = @id_perTra
--SET @documentoOrigen = @idFondoFijo
SET @documentoAfectado = @idFondoFijo
--SET @referencia2 = @idFondoFijo
SET @Count = 2 -- segundo registro
END


IF(@tipoProceso = 7)
BEGIN
--SET @tipoProducto= 'DD'
select @idFondoFijo = idfondoFijo from tramite.fondofijo where id_perTra = @id_perTra
SET @subproducto = 'PA'
SET @documentoAfectado = @documento
IF (@esFactura = 1)
BEGIN 
select 
@persona1 = fv.PER_IDPERSONA
from tramite.valesevidencia ve
inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.idComprobacionVale = @documentoOrigen
END
ELSE
BEGIN
SET @persona1 = 410798
END

----USUARIO QUE TRAMITA EL VALE
--select  @persona1 = v.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--where ve.idComprobacionVale = @documentoOrigen

--SET  @documentoAfectado = @idFondoFijo
SET @Count = 2 -- segundo registro
END

IF(@tipoProceso = 8)
BEGIN
--Se obtiene el id del cajero
select
@persona1 =  td.PER_IDPERSONA,
@cuentaContable = ff.cuentaContable
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen

select top 1  @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal and idpersona = @persona1 and cuenta = @cuentaContable order by id asc

	  
	   
							
							  
													
					  
   

--IF (@esFactura = 1)
--BEGIN 
--select 
--@persona1 = fv.PER_IDPERSONA
--from tramite.valesevidencia ve
--inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
--where ve.idComprobacionVale = @documentoOrigen
--END
--ELSE
--BEGIN
--SET @persona1 = 410798
--END

select @documentoAfectado = ff.idfondofijo
from Tramite.fondoFijo ff
inner join Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join Tramite.vales v on v.id = vff.idVales
inner join Tramite.valesEvidencia ve on ve.idVales = v.id
where ve.idComprobacionVale = @documentoOrigen


SET @Count = 2
END

IF(@tipoProceso = 10)
BEGIN
SET @origen = 'FF'
select @documentoAfectado = idFondoFijo from Tramite.fondoFijo where id_perTra = @id_perTra
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
SET @Count = 2 -- segundo registro
END


IF(@tipoProceso = 15)
BEGIN
SET @tipoProducto= 'DD'
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END
--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
SET @Count = 2 -- segundo registro
END

IF(@tipoProceso = 16)
BEGIN
SET @tipoProducto= 'DD'
--SET @persona1 = 453480 -- es el acredor

IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END
--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
SET @Count = 2 -- segundo registro
END


IF(@tipoProceso = 19)
BEGIN

--SET @tipoProducto= 'DD'
--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
--SET @persona1 = 453480 -- es el asesor

--SET @QueryE ='SELECT  @persona1 =  CAST(PAR_IMPORTE1 AS INT)  FROM  ['+@nombreBD+'].[dbo].[pnc_parametr] WHERE PAR_TIPOPARA = ''EM'''
--EXECUTE sp_executeSQL @QueryE, N'@persona1 INT OUTPUT', @persona1 OUTPUT

SET @subproducto = 'PA'
																																	 
																		
SET @documentoAfectado = @documento
--IF(@esFactura = 0)
--BEGIN
--SET @persona1 = 410798
--END

IF(@esFactura = 0)
BEGIN
SET @persona1 = 410798
END
ELSE
BEGIN
IF EXISTS (select top 1 * from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac) 
		BEGIN
			select top 1  @persona1 = PER_IDPERSONA from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac
		END
	ELSE
		BEGIN
		SET  @persona1 = 410798
	END	
END


--	select @idAnticipoGasto = documentoConcepto from  Tramite.ConceptoArchivo ca 
--	inner join tramite.tramiteconcepto tc on tc.idtramiteconcepto = ca.idreferencia
--	where ca.idcomprobacionConcepto = @DocumentoOrigen
--SET @documentoAfectado = @idAnticipoGasto


--select @persona1 = td.PER_IDPERSONA
--from Tramite.ConceptoArchivo ca
--inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
--inner join tramiteDevoluciones td on td.id_perTra = tc.idTramitepersona
--where ca.idComprobacionConcepto = @documentoOrigen
SET @Count = 2 -- segundo registro
END

IF(@tipoProceso = 20)
BEGIN
--select top 1 @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal order by id asc
select  @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableBancosFFGV] where idsucursal = @idsucursal and polizaEnvio = 1
--select top 1 @persona1 = idpersona from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal order by id asc
IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END
	select @idAnticipoGasto = documentoConcepto from  Tramite.ConceptoArchivo ca 
	inner join tramite.tramiteconcepto tc on tc.idtramiteconcepto = ca.idreferencia
	where ca.idcomprobacionConcepto = @DocumentoOrigen
SET @documentoAfectado = @idAnticipoGasto
SET @Count = 2 -- segundo registro
END


IF(@tipoProceso = 25)
BEGIN
--SET @tipoProducto= 'DD'
select @idFondoFijo = idfondoFijo from tramite.fondofijo where id_perTra = @id_perTra
SET @subproducto = 'PA'
SET @documentoAfectado = @documento
IF (@esFactura = 1)
BEGIN 
select 
@persona1 = fv.PER_IDPERSONA
from tramite.valesevidencia ve
inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.idComprobacionVale = @documentoOrigen
END
ELSE
BEGIN
SET @persona1 = 410798
END
SET @Count = 2 -- segundo registro
END

IF(@tipoProceso = 26)
BEGIN
--select top 1  @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal order by id asc
--select  @persona1 =  td.PER_IDPERSONA 
--from tramite.valesEvidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
--inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
--inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
--where ve.idComprobacionVale =@documentoOrigen

select
@persona1 =  td.PER_IDPERSONA,
@cuentaContable = ff.cuentaContable
from tramite.valesEvidencia ve
inner join tramite.vales v on v.id = ve.idvales
inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
inner join tramiteDevoluciones td on td.id_perTra = ff.id_perTra
where ve.idComprobacionVale =@documentoOrigen

select top 1  @subproducto = cuentaEnvio from [Tramite].[cat_CuentasContableFFGV] where idsucursal = @idsucursal and idpersona = @persona1 and cuenta = @cuentaContable order by id asc



select @documentoAfectado = ff.idfondofijo
from Tramite.fondoFijo ff
inner join Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join Tramite.vales v on v.id = vff.idVales
inner join Tramite.valesEvidencia ve on ve.idVales = v.id
where ve.idComprobacionVale = @documentoOrigen

SET @Count = 2
END
IF(@tipoProceso = 28)
BEGIN
SET @tipoProducto= 'OT'
--SET @persona1 = 453480 -- es el acredor

IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
BEGIN
select @persona1 =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra

END
ELSE
BEGIN 
select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra
END
--select @persona1 = PER_IDPERSONA from tramiteDevoluciones where id_perTra = @id_perTra

SET @documentoAfectado = @ordenCompra
set @referencia1 = @ordenCompra
SET @Count = 2 -- segundo registro
SET @subproducto = 'DD'
set @persona2  = @ordenMasiva
SET @origen = 'FAC'


END					 
DECLARE @insertDetalle2 NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[DSBPDetInfo]
	  ([Agencia]
      ,[Proceso]
      ,[DocumentoOrigen]
      ,[Fecha]
      ,[Hora]
      ,[Partida]
      ,[TipoProducto]
      ,[SubProducto]
      ,[Origen]
      ,[Destino]
      ,[Moneda]
      ,[TipoCambio]
      ,[Cantidad]
      ,[CostoUnitario]
      ,[VentaUnitario]
      ,[DescuentoUnitario]
      ,[TasaIva]
      ,[IVA]
      ,[ISAN]
      ,[RetIVA]
      ,[RetISR]
      ,[IEPS]
      ,[Persona1]
      ,[Persona2]
      ,[DocumentoAfectado]
      ,[Referencia1]
      ,[Auto]
      ,[Version]
      ,[Color]
      ,[AnioAuto]
      ,[VIN]
      ,[FyHRegDet]
      ,[Referencia2]
      ,[TasaRetIva]
      ,[TasaRetIsr]
      ,[AntiTipoPol]
      ,[AntiConsPol]
      ,[AntiMesPol]
      ,[AntiAñoPol]
      ,[AntiEmpresaPol]
      ,[Importado]
      ,[UUID]
      ,[UUIDNOMBREPDF]
      ,[UUIDNOMBREXML]
      ,[UUIDRUTAPDF]
      ,[UUIDRUTAXML]
      ,[FechaVencimientoDS]
      ,[ISN]
      ,[TasaRetISN])
VALUES
	  ('''+@agenciaBD+'''
	  ,'''+@proceso+'''
	  ,'''+@documentoOrigen+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,'''+ CONVERT(VARCHAR(10),@Count)+'''  
	  ,'''+@tipoProducto+''' 
	  ,'''+@subproducto+'''
	  ,'''+@origen+''' 
	  ,'''+@Destino+''' 
	  ,'''+@moneda+''' 
	  ,1
	  ,1
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@ventaUnitario)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@tasaIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@IVA)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@retIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@retISR)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@persona1)+''' 
	  ,0
	  ,'''+@documentoAfectado+'''  
	  ,'''+ @referencia1+''' 
	  ,''''
	   ,'''+@version+'''
	  ,''''
	  ,''''
	  ,''''
	  ,GETDATE()
	  ,'''+@referencia2+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetISR)+'''
	  ,''''
	  ,0
	  ,0
	  ,0
	  ,''''
	  ,0
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL)
'

IF(@insertaEncabezado = 1)
BEGIN
print @insertDetalle
EXEC(@insertDetalle)
SET @idDetalle = @@IDENTITY
END
ELSE
BEGIN
SET @idDetalle = null
END

--print @insertEncabezado
--print @insertDetalle
--print @insertDetalle
--EXEC(@insertDetalle)
--SET @idDetalle = @@IDENTITY


IF(@tipoProceso = 6 or @tipoProceso = 7 or @tipoProceso = 8 or @tipoProceso = 10 or  @tipoProceso = 15 --or  @tipoProceso = 16 
or @tipoProceso = 19 or @tipoProceso = 20 or @tipoProceso = 25 or @tipoProceso = 26 or @tipoProceso = 28 )
BEGIN
IF(@insertaEncabezado = 1)
BEGIN
print @insertDetalle2
EXEC(@insertDetalle2)
END
--print @insertDetalle2
--EXEC(@insertDetalle2)
END


--IF(@tipoProceso = 7)
--BEGIN
--SET @tipoProducto = 'IV'
--SET @tasaIVA = 16
--SET @IVA = (@ventaO * @tasaIVA) / 100
--SET @persona1 = 0 
--SET  @Count = 3
--END

IF(@tipoProceso = 15)
BEGIN
SET @tipoProducto = @canal
SET @origen = @banco
SET  @Count = 3
END

IF(@tipoProceso = 16)
BEGIN
SET @tipoProducto = @canal
SET @origen = @banco
SET  @Count = 3
END

DECLARE @insertDetalle3 NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[DSBPDetInfo]
	  ([Agencia]
      ,[Proceso]
      ,[DocumentoOrigen]
      ,[Fecha]
      ,[Hora]
      ,[Partida]
      ,[TipoProducto]
      ,[SubProducto]
      ,[Origen]
      ,[Destino]
      ,[Moneda]
      ,[TipoCambio]
      ,[Cantidad]
      ,[CostoUnitario]
      ,[VentaUnitario]
      ,[DescuentoUnitario]
      ,[TasaIva]
      ,[IVA]
      ,[ISAN]
      ,[RetIVA]
      ,[RetISR]
      ,[IEPS]
      ,[Persona1]
      ,[Persona2]
      ,[DocumentoAfectado]
      ,[Referencia1]
      ,[Auto]
      ,[Version]
      ,[Color]
      ,[AnioAuto]
      ,[VIN]
      ,[FyHRegDet]
      ,[Referencia2]
      ,[TasaRetIva]
      ,[TasaRetIsr]
      ,[AntiTipoPol]
      ,[AntiConsPol]
      ,[AntiMesPol]
      ,[AntiAñoPol]
      ,[AntiEmpresaPol]
      ,[Importado]
      ,[UUID]
      ,[UUIDNOMBREPDF]
      ,[UUIDNOMBREXML]
      ,[UUIDRUTAPDF]
      ,[UUIDRUTAXML]
      ,[FechaVencimientoDS]
      ,[ISN]
      ,[TasaRetISN])
VALUES
	  ('''+@agenciaBD+'''
	  ,'''+@proceso+'''
	  ,'''+@documentoOrigen+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,'''+ CONVERT(VARCHAR(10),@Count)+'''  
	  ,'''+@tipoProducto+''' 
	  ,'''+@subproducto+'''
	  ,'''+@origen+''' 
	  ,'''+@Destino+''' 
	  ,'''+@moneda+''' 
	  ,1
	  ,1
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@ventaUnitario)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@tasaIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@IVA)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@retIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@retISR)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@persona1)+''' 
	  ,0
	  ,'''+@documentoAfectado+'''  
	  ,'''+ @referencia1+''' 
	  ,''''
	  ,''''
	  ,''''
	  ,''''
	  ,''''
	  ,GETDATE()
	  ,'''+@referencia2+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetISR)+'''
	  ,''''
	  ,0
	  ,0
	  ,0
	  ,''''
	  ,0
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL)
'

--IF(@tipoProceso = 15 or @tipoProceso = 16)
--BEGIN
--print @insertDetalle3
--EXEC(@insertDetalle3)
--END

--IF(@tipoProceso = 7)
--BEGIN
--SET @tipoProducto = 'IV1'
----SET @tasaIVA = 16
----SET @IVA = (@ventaUnitario * @tasaIVA) / 100
----SET @persona1 = 0 
--SET  @Count = 4
--END

DECLARE @insertDetalle4 NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[DSBPDetInfo]
	  ([Agencia]
      ,[Proceso]
      ,[DocumentoOrigen]
      ,[Fecha]
      ,[Hora]
      ,[Partida]
      ,[TipoProducto]
      ,[SubProducto]
      ,[Origen]
      ,[Destino]
      ,[Moneda]
      ,[TipoCambio]
      ,[Cantidad]
      ,[CostoUnitario]
      ,[VentaUnitario]
      ,[DescuentoUnitario]
      ,[TasaIva]
      ,[IVA]
      ,[ISAN]
      ,[RetIVA]
      ,[RetISR]
      ,[IEPS]
      ,[Persona1]
      ,[Persona2]
      ,[DocumentoAfectado]
      ,[Referencia1]
      ,[Auto]
      ,[Version]
      ,[Color]
      ,[AnioAuto]
      ,[VIN]
      ,[FyHRegDet]
      ,[Referencia2]
      ,[TasaRetIva]
      ,[TasaRetIsr]
      ,[AntiTipoPol]
      ,[AntiConsPol]
      ,[AntiMesPol]
      ,[AntiAñoPol]
      ,[AntiEmpresaPol]
      ,[Importado]
      ,[UUID]
      ,[UUIDNOMBREPDF]
      ,[UUIDNOMBREXML]
      ,[UUIDRUTAPDF]
      ,[UUIDRUTAXML]
      ,[FechaVencimientoDS]
      ,[ISN]
      ,[TasaRetISN])
VALUES
	  ('''+@agenciaBD+'''
	  ,'''+@proceso+'''
	  ,'''+@documentoOrigen+'''
	  ,'''+@fecha+'''
	  ,'''+@hora+'''
	  ,'''+ CONVERT(VARCHAR(10),@Count)+'''  
	  ,'''+@tipoProducto+''' 
	  ,'''+@subproducto+'''
	  ,'''+@origen+''' 
	  ,'''+@Destino+''' 
	  ,'''+@moneda+''' 
	  ,1
	  ,1
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@ventaUnitario)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@tasaIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@IVA)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@retIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@retISR)+''' 
	  ,0
	  ,'''+ CONVERT(VARCHAR(10),@persona1)+''' 
	  ,0
	  ,'''+@documentoAfectado+'''  
	  ,'''+ @referencia1+''' 
	  ,''''
	  ,''''
	  ,''''
	  ,''''
	  ,''''
	  ,GETDATE()
	  ,'''+@referencia2+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetIVA)+''' 
	  ,'''+ CONVERT(VARCHAR(10),@tasaRetISR)+'''
	  ,''''
	  ,0
	  ,0
	  ,0
	  ,''''
	  ,0
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL
	  ,NULL)
'

--IF(@tipoProceso = 7)
--BEGIN
--print @insertDetalle4
--EXEC(@insertDetalle4)
--END

select @idEncabezado idEncabezado, @idDetalle idDetalle

IF(@insertaEncabezado = 1)
BEGIN
INSERT INTO Tramites.Tramite.BitacoraPolizas_FFGV
(idSucursal, agencia, tipoProceso, proceso, comprobacion, monto, encabezado, detalle1, detalle2, fecha)
VALUES 
(@idsucursal, @nombreBD, @tipoProceso, @proceso, @documentoOrigen, @ventaUnitario, @insertEncabezado, @insertDetalle, @insertDetalle2, GETDATE())
END
	
	END TRY
	BEGIN CATCH
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH
	SET NOCOUNT OFF;
END


go

