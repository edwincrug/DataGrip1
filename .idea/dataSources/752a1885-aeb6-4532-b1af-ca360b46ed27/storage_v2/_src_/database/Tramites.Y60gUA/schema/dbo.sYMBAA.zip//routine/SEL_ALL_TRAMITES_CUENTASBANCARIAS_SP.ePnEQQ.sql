-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <17/10/2019>
-- Description:	<Trae los tramites para validar cuenta bancaria>
/*
Modificacion: Se agrega el union
*/
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ALL_TRAMITES_CUENTASBANCARIAS_SP] 
	@idEstatus INT
AS
BEGIN
	--SELECT 
	--	CT.id_perTra,
	--	(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
	--	CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
	--	T.tra_nomTramite,
	--	TD.id_traDe,
	--	DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
	--	ET.id_estatus,
	--	PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
	--	CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
	--	CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
	--	CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PT.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
	--FROM cuentasTesoreria CT
	--INNER JOIN personaTramite PT ON PT.id_perTra = CT.id_perTra
	--INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = CT.id_perTra
	--INNER JOIN estatusTesoreria ET ON ET.id_estatus = CT.estatus
	--INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
	--INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
	--LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PT.id_perTra
	--LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PT.id_perTra 
	--LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PT.id_perTra
	--WHERE estatus = @idEstatus
	--UNION ALL     
	--SELECT 
	--	CT.id_perTra,
	--	(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
	--	CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
	--	T.tra_nomTramite,
	--	td.idtransferencia as id_traDe,
	--	DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
	--	ET.id_estatus,
	--	'' as PER_PERSONA,
	--	0 noti,
	--	0 notiRevisar,
	--	0 notiDocsAprobar
	--FROM cuentasTesoreria CT
	--INNER JOIN personaTramite PT ON PT.id_perTra = CT.id_perTra
	--LEFT JOIN tesoreria.dbo.transferenciasLog TD ON TD.idperTra = CT.id_perTra
	--INNER JOIN estatusTesoreria ET ON ET.id_estatus = CT.estatus
	--INNER JOIN cat_tramites T 
	--ON T.id_tramite = PT.id_tramite
	--and t.id_tramite = 11
	--and estatus = @idEstatus
	--WHERE CONVERT(varchar(10),petr_fechaTramite,112) <= CONVERT(VARCHAR(10),GETDATE(),112) --se agrego este where

	SELECT 
		CT.id_perTra,
		(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
		CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
		T.tra_nomTramite,
		TD.id_traDe,
		DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
		ET.id_estatus,
		PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
		CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
		CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
		CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PT.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
		,PT.id_tramite
		, 1 as consecutivo
		
	FROM cuentasTesoreria CT
	INNER JOIN personaTramite PT ON PT.id_perTra = CT.id_perTra
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = CT.id_perTra
	INNER JOIN estatusTesoreria ET ON ET.id_estatus = CT.estatus
	INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
	INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PT.id_perTra
	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PT.id_perTra 
	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PT.id_perTra
	WHERE (@idEstatus = 3  and  pt.petr_estatus IN (2,3) or @idEstatus = 1  and  pt.petr_estatus IN (1)) 
	
	UNION ALL /*TRANSFERENCIAS BANCARIAS*/
	SELECT 
		CT.id_perTra,
		(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
		CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
		T.tra_nomTramite,
		td.idtransferencia as id_traDe,
		DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
		ET.id_estatus,
		'' as PER_PERSONA,
		0 noti,
		0 notiRevisar,
		0 notiDocsAprobar
		,PT.id_tramite
		,1 as consecutivo
	FROM cuentasTesoreria CT
	INNER JOIN personaTramite PT ON PT.id_perTra = CT.id_perTra
	LEFT JOIN tesoreria.dbo.transferenciasLog TD ON TD.idperTra = CT.id_perTra
	INNER JOIN estatusTesoreria ET ON ET.id_estatus = CT.estatus
	INNER JOIN cat_tramites T 
	ON T.id_tramite = PT.id_tramite
	and t.id_tramite = 11
	and estatus = @idEstatus
	WHERE CONVERT(varchar(10),petr_fechaTramite,112) <= CONVERT(VARCHAR(10),GETDATE(),112) --se agrego este where
	UNION ALL /* FF y GV */
		SELECT 
			CT.id_perTra,
		(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
		CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
		CASE WHEN CT.tipo = 1 THEN T.tra_nomTramite + '-' + 'Salida Efectivo' 
			 WHEN CT.tipo = 2 THEN T.tra_nomTramite + '-' + 'Reembolso Efectivo' 
			 WHEN CT.tipo = 4 THEN T.tra_nomTramite + ' - '+ 'Orden de Pago'
			 --WHEN CT.tipo = 5 THEN T.tra_nomTramite + ' - '+ 'Transferencias'
			 END as tra_nomTramite,
		TD.id_traDe,
		DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
		ET.id_estatus,
		PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
		CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
		CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
		CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PT.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
		,PT.id_tramite
		,CT.consecutivo
	FROM cuentasTesoreriaFA CT
	INNER JOIN personaTramite PT ON PT.id_perTra = CT.id_perTra
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = CT.id_perTra
	INNER JOIN estatusTesoreria ET ON ET.id_estatus = CT.estatus
	INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
	INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PT.id_perTra
	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PT.id_perTra 
	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PT.id_perTra
	WHERE estatus = @idEstatus
	and CASE WHEN CT.tipo = 1 THEN T.tra_nomTramite + '-' + 'Salida Efectivo' 
			 WHEN CT.tipo = 2 THEN T.tra_nomTramite + '-' + 'Reembolso Efectivo' 
			 WHEN CT.tipo = 4 THEN T.tra_nomTramite + ' - '+ 'Orden de Pago'
			 --WHEN CT.tipo = 5 THEN T.tra_nomTramite + ' - '+ 'Transferencias'
			 END is not null 
	union all /* traspasos FF*/
	SELECT 
		CT.id_perTra,
		(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
		CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
		T.tra_nomTramite,
		td.idtransferencia as id_traDe,
		DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
		ET.id_estatus,
		'' as PER_PERSONA,
		0 noti,
		0 notiRevisar,
		0 notiDocsAprobar
		,PT.id_tramite
		,1 as consecutivo
	FROM cuentasTesoreria CT
	INNER JOIN personaTramite PT ON PT.id_perTra = CT.id_perTra
	LEFT JOIN tesoreria.dbo.transferenciasLog TD ON TD.idperTra = CT.id_perTra
	INNER JOIN estatusTesoreria ET ON ET.id_estatus = CT.estatus
	INNER JOIN cat_tramites T 
	ON T.id_tramite = PT.id_tramite
	and t.id_tramite = 13
	and ct.estatus = @idEstatus

	UNION ALL
	SELECT 
		CT.id_perTra,
		(SELECT usu_paterno + ' ' + usu_materno + ' ' + usu_nombre FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = PT.id_persona) AS nombre,
		CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
		T.tra_nomTramite,
		id_traDe = 0,
		DATEDIFF(DAY, [petr_fechaTramite], GETDATE() ) AS dias,
		ET.id_estatus,
		'' as PER_PERSONA,
		0 noti,
		0 notiRevisar,
		0 notiDocsAprobar
		,PT.id_tramite
		,1 as consecutivo
	FROM cuentasTesoreria CT
	INNER JOIN personaTramite PT ON PT.id_perTra = CT.id_perTra
	INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
	INNER JOIN estatusTesoreria ET ON ET.id_estatus = CT.estatus
	WHERE
		CT.estatus = @idEstatus
		AND T.id_tramite = 14
END
go

exec sp_addextendedproperty 'MS_Description',
     'Obtiene todos los tramites creados para devoluciones que se encuentren en el status indicados', 'SCHEMA', 'dbo',
     'PROCEDURE', 'SEL_ALL_TRAMITES_CUENTASBANCARIAS_SP'
go

