-- =============================================
-- Author:		Luis Garcia
-- Create date: 17/10/2019
-- Description:	Inserta en la tabla para las cuentas
-- [dbo].[INS_TESORERIA_CUENTAS_SP] 537
-- =============================================
CREATE PROCEDURE [dbo].[INS_TESORERIA_CUENTAS_ANT_SP]
	@idPerTra INT
AS
BEGIN
	BEGIN TRY
		DECLARE @maxVal INT = 0, @minVal INT = 0, @efectivo INT = 0, @noEfectivo INT = 0;
		DECLARE @data TABLE (idPerTra INT, rowCont INT, tipo VARCHAR(10), PAR_DESCRIP1 VARCHAR(200));
		DECLARE @idEmpresa INT, @idSucursal INT, @nombreBase VARCHAR(30), @query VARCHAR(MAX),	@queryTipoPago  NVARCHAR(max),@ParmDefinition  NVARCHAR(max),@tipoDePago  NVARCHAR(max);

		SELECT 
			@idEmpresa = id_empresa,
			@idSucursal = id_sucursal
		FROM tramiteDevoluciones WHERE id_perTra = @idPerTra

		SELECT 
			@nombreBase = suc_nombrebd 
		FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
		WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

		SET @queryTipoPago = N'SELECT @tipoPagoOUT = PNC.PAR_IDENPARA' +
						' FROM ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] AS PNC' + 
						' WHERE PAR_TIPOPARA = ''FP'' AND PAR_DESCRIP1 = ''C. EFECTIVO C.'''

		SET @ParmDefinition = N'@tipoPagoOUT VARCHAR(5) OUTPUT'

	EXECUTE sp_executesql @queryTipoPago, @ParmDefinition, @tipoPagoOUT = @tipoDePago OUTPUT;
		
		SET @query = 'SELECT' + CHAR(13) +
				CHAR(9) + 'PT.id_perTra,' + CHAR(13) +
				CHAR(9) + 'ROW_NUMBER() OVER(ORDER BY PT.id_perTra ASC) AS contador,' + CHAR(13) +
				CHAR(9) + 'docDe_tipoPago,' + CHAR(13) +
				CHAR(9) + 'SUBSTRING(PNC.PAR_DESCRIP1,    CHARINDEX(''. -'',PNC.PAR_DESCRIP1) + 3    ,LEN(PNC.PAR_DESCRIP1))  as PAR_DESCRIP1' + CHAR(13) +
		'FROM personaTramite PT' + CHAR(13) +
		'INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra' + CHAR(13) +
		'INNER JOIN documentosDevueltos DD ON DD.id_traDe = TD.id_traDe' + CHAR(13) +
		'INNER JOIN' + '[' + @nombreBase + '].[DBO].[VIS_CONCAR01] AS CAR ON CCP_TIPODOCTO = ''ANT'' AND DD.docDe_documento = CAR.CCP_IDDOCTO COLLATE DATABASE_DEFAULT' + CHAR(13) +
		'INNER JOIN ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] AS PNC ON CAR.CCP_CARTERA = PNC.PAR_IDENPARA' + CHAR(13) +
		'WHERE PT.id_perTra = ' + CONVERT(varchar(10), @idPerTra);

		INSERT INTO @data
		EXEC(@query)

		--SELECT * FROM @data
		SELECT 
			@maxVal = MAX(x.rowCont),
			@minVal = MIN(x.rowCont)
		FROM (SELECT * FROM @data ) x
		--SELECT * FROM @data WHERE PAR_DESCRIP1 LIKE '%UNIDADES%'

		WHILE ( @minVal <= @maxVal )
			BEGIN
				IF( (SELECT tipo FROM @data WHERE rowCont = @minVal) = 'EF' OR (SELECT tipo FROM @data WHERE rowCont = @minVal) = '39')
					BEGIN
						IF EXISTS (SELECT PAR_DESCRIP1 FROM @data WHERE rowCont = @minVal AND PAR_DESCRIP1 LIKE '%UNIDADES%')
							BEGIN
								SET @efectivo = @efectivo + 1
							END
						ELSE
							BEGIN
								SET @noEfectivo = @noEfectivo + 1
							END
					END
				ELSE
					BEGIN
						IF( (SELECT tipo FROM @data WHERE rowCont = @minVal) = @tipoDePago) --Poner el PARIDENPARA DE SUCURSAL
							BEGIN
								SET @efectivo = @efectivo + 1
							END
						ELSE
							BEGIN
								SET @noEfectivo = @noEfectivo + 1
							END
					END
				SET @minVal = @minVal + 1;
			END
			--PRINT 'Efectivo' + CONVERT(VARCHAR(5), @efectivo)
			--PRINT 'NoEfectivo' + CONVERT(VARCHAR(5), @noEfectivo)
			IF( @efectivo > 0 AND @noEfectivo > 0 )
				BEGIN
					IF NOT EXISTS(SELECT id_perTra FROM cuentasTesoreria WHERE id_perTra = @idPerTra)
						BEGIN
							INSERT INTO cuentasTesoreria ( id_perTra, fechaInsercion, estatus, id_tipoTramite )
							VALUES( @idPertra, GETDATE(), 1, 3)

							/*
							se agrega insert para uso del modulo de devoluciones en tramitres mixtos
							*/
							insert into EstatusMixtosDevoluciones(id_perTra, e_efectivo, e_noEfectivo)
							values(@idPerTra,0,0)

							SELECT success = 1, idInsertado = 3;
						END
				END
			ELSE IF (@efectivo > 0)
				BEGIN
					IF NOT EXISTS(SELECT id_perTra FROM cuentasTesoreria WHERE id_perTra = @idPerTra)
						BEGIN
							INSERT INTO cuentasTesoreria ( id_perTra, fechaInsercion, estatus, id_tipoTramite )
							VALUES( @idPertra, GETDATE(), 1, 1)

							SELECT success = 1, idInsertado = 1;
						END
				END
			ELSE IF (@noEfectivo > 0)
				BEGIN
					IF NOT EXISTS(SELECT id_perTra FROM cuentasTesoreria WHERE id_perTra = @idPerTra)
						BEGIN
							INSERT INTO cuentasTesoreria ( id_perTra, fechaInsercion, estatus, id_tipoTramite )
							VALUES( @idPertra, GETDATE(), 1, 2)

							SELECT success = 1, idInsertado = 2;
						END
				END
	END TRY

	BEGIN CATCH
		SELECT success = 0 ;
	END CATCH
END
go

