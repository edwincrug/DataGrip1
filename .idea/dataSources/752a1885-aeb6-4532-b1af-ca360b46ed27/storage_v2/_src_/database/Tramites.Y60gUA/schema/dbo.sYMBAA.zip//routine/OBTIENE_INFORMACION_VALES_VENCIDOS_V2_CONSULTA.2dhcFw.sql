-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_INFORMACION_VALES_VENCIDOS_V2_CONSULTA]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

       DECLARE @fecha DATETIME
           ,@horas INT = 48
           ,@destinatarioContraloria VARCHAR(MAX)
           ,@destinatarioNomina VARCHAR(MAX)
		   ,@destinatarioFinanzas VARCHAR(MAX)
           ,@asunto VARCHAR(255)
           ,@idBancoDestino INT
           ,@idBancoOrigen INT
           ,@idOrigenReferencia INT
           ,@minutos INT
          ,@inInicio INT = 1
      ,@inFinal INT = 0
	  ,@DIA VARCHAR(20) = ''

      DECLARE @fechaIni DATETIME
             ,@horaI INT = 0
             ,@horaF INT = 24
             ,@fechaActual DATETIME = CONVERT(DATETIME, '2020-08-02 19:08:48.230', 102) --GETDATE()
             ,@escalamiento BIT = 0
			 ,@fechaInFinal datetime
			 ,@fechaNextDay datetime
			 ,@fechaNextDayFinal datetime

      DECLARE @iDia DATETIME = CONVERT(VARCHAR(10), @fechaActual, 112)
             ,@fDia DATETIME = CONVERT(VARCHAR(10), @fechaActual, 112)


      DECLARE @parametros TABLE (
       asunto VARCHAR(250)
       ,destinatarioContraloria VARCHAR(MAX)
	   ,destinatarioFinanzas VARCHAR(MAX)
       ,destinatarioNomina VARCHAR(MAX)
       ,idBancoDestino INT
       ,idBancoOrigen INT
	   ,idEmpresa INT
       ,idOrigenReferencia INT
	   ,idSucursal INT
       ,tiempoParaComprobar INT
      )

DECLARE @PorProcesar TABLE (
  id INT
 ,idEmpresa INT
 ,idsucursal INT
 ,idDepartamento INT
 ,idVale VARCHAR(100)
 ,PER_IDPERSONA INT
 ,rfc VARCHAR(15)
 ,NOMBRE VARCHAR(150)
 ,mail VARCHAR(150)
 ,montoSolicitado DECIMAL(18, 2)
 ,montoJustificado DECIMAL(18, 2)
 ,porJustificar DECIMAL(18, 2)
 ,destinatarioContraloria VARCHAR(MAX)
 ,destinatarioNomina VARCHAR(MAX)
 ,destinatarioFinanzas VARCHAR(MAX)
 ,horas INT
 ,asunto VARCHAR(255)
 ,idBancoDestino INT
 ,idBancoOrigen INT
 ,idOrigenReferencia INT
 ,idUsuario INT
 ,indice INT
 ,fechaComprobacion DATETIME
 ,id_perTra INT
)


      DECLARE @encontrados TABLE (
        id INT
       ,idEmpresa INT
       ,idsucursal INT
       ,idDepartamento INT
       ,idVale VARCHAR(100)
       ,PER_IDPERSONA INT
       ,rfc VARCHAR(15)
       ,NOMBRE VARCHAR(150)
       ,mail VARCHAR(150)
       ,montoSolicitado DECIMAL(18, 2)
       ,montoJustificado DECIMAL(18, 2)
       ,porJustificar DECIMAL(18, 2)
       ,destinatarioContraloria VARCHAR(MAX)
       ,destinatarioNomina VARCHAR(MAX)
	   ,destinatarioFinanzas VARCHAR(MAX)
       ,horas INT
       ,asunto VARCHAR(255)
       ,idBancoDestino INT
       ,idBancoOrigen INT
       ,idOrigenReferencia INT
       ,idUsuario INT
	   ,INDICE INT
	    ,fechaEntregadinero varchar(30)
	   ,fechaCierre varchar(30)
	   ,minutostranscurridos int
	   ,id_perTra INT
	   ,id_perTraRembolso INT
      )

  INSERT INTO @parametros
  EXEC [OBTIENE_PARAMETROS_V2] 'FFValidaTiempoComprobante'
  --select 'FFValidaTiempoComprobante','== Prueba == Notificación de vale de fondo fijo vencido: ','roberto.almanza@coalmx.com','roberto.almanza@coalmx.com',1,1,3,48
  --select 'FFValidaTiempoComprobante','== PRUEBA == Descuento por nomina de vale vencido','manuel.lopez@grupoandrade.com','roberto.almanza@coalmx.com,luis.bonnet@grupoandrade.com,ignacio.jimenez@grupoandrade.com',1,1,3,48
  --select 'FFValidaTiempoComprobante',' Notificación de vale de fondo fijo vencido ','manuel.lopez@grupoandrade.com,roberto.almanza@coalmx.com,luis.bonnet@grupoandrade.com','laura.lora@grupoandrade.com,roberto.almanza@coalmx.com,luis.bonnet@grupoandrade.com',1,1,3,48
  --EXEC [OBTIENE_PARAMETROS] 'FFValidaTiempoComprobante'

  SELECT
    @horas = tiempoParaComprobar
   ,@destinatarioContraloria = destinatarioContraloria
   ,@destinatarioNomina = destinatarioNomina
   ,@destinatarioFinanzas = destinatarioFinanzas
   ,@asunto = asunto
   ,@idBancoDestino = idBancoDestino
   ,@idBancoOrigen = idBancoOrigen
   ,@idOrigenReferencia = idOrigenReferencia
  FROM @parametros

  SET @minutos = @horas * 60

      INSERT INTO @PorProcesar
        SELECT distinct
          v.id
         ,f.idEmpresa
         ,f.idSucursal
         ,f.idDepartamento
         ,idVale
         ,v.PER_IDPERSONA
         ,rfc = pp.PER_RFC
         ,NOMBRE = pp.PER_NOMRAZON + ' ' + pp.PER_PATERNO + ' ' + pp.PER_MATERNO
         ,mail = pp.PER_EMAIL
         ,montoSolicitado
         ,montoJustificado
         ,porJustificar =
          CASE
            WHEN (montoSolicitado - montoJustificado) < 0 THEN 0
            ELSE (montoSolicitado - montoJustificado)
          END
         ,destinatarioContraloria = pa.destinatarioContraloria --@destinatarioContraloria
         ,destinatarioNomina = pa.destinatarioNomina--@destinatarioNomina
		 ,destinatarioFinanzas = pa.destinatarioFinanzas--@destinatarioFinanzas
         ,horas = 0
         ,asunto = @asunto
         ,idBancoDestino = @idBancoDestino
         ,idBancoOrigen = @idBancoOrigen
         ,idOrigenReferencia = @idOrigenReferencia
         ,f.idResponsable
         , ROW_NUMBER() OVER(ORDER BY v.id ASC) AS Row#
         ,CASE WHEN v.fechaRechazoVale IS NULL THEN  v.fechaEntregaEfectivo ELSE v.fechaRechazoVale END
		 ,f.id_perTra
        FROM tramite.vales v
        JOIN GA_Corporativa.dbo.PER_PERSONAS pp
          ON v.PER_IDPERSONA = pp.PER_IDPERSONA
        JOIN tramite.valesFondoFijo ff
          ON ff.idVales = v.id
        JOIN tramite.fondoFijo f
          ON ff.idTablaFondoFijo = f.id
		LEFT JOIN ControlAplicaciones..cat_usuarios cu
			on v.idEmpleado = cu.usu_idusuario
		left join @parametros pa
			on cu.emp_idempresa = pa.idEmpresa
			and cu.suc_idsucursal = pa.idSucursal
        WHERE fechaEntregaEfectivo IS NOT NULL
        AND (montoSolicitado - montoJustificado) > 0
        --AND descuentoSolicitado = 0
		and v.id in (
		245
		,268
		,285
		)
        ORDER BY v.id DESC

		--SELECT * FROM @PorProcesar


		SET @inFinal = ( SELECT COUNT(*) FROM @PorProcesar)

  --SELECT * FROM @PorProcesar
  --SELECT @inFinal
    DECLARE @minDia INT = 0, @fechaCominezo datetime

WHILE @inInicio < @inFinal+1 BEGIN  

    /*Leemos la fecha que vamos a comprobar*/
    SELECT @fechaIni = fechaComprobacion 
	,@iDia = fechaComprobacion
      FROM @PorProcesar  
	  WHERE indice = @inInicio

	  SELECT @fechaInFinal =(DATEADD(HOUR, @horaF,  cast(convert(varchar(10), @iDia,23) as datetime2)))
	  SET @fechaInFinal = DATEADD( SECOND, -1, @fechaInFinal);
	  --select @fechaInFinal

	   	 set @minDia = 0

	  while CONVERT(varchar(10), @fechaIni,112) <= convert(varchar(10),GETDATE(),112)
	  begin
	 
	
		IF( ((SELECT UPPER(DATENAME(DW, @fechaIni))) <> 'SUNDAY') AND ((SELECT UPPER(DATENAME(DW, @fechaIni))) <> 'DOMINGO') )-- OJO EN EL sp DEBE DE ESTAR EN INGLES
		begin
		 
		 print '==================================='
		  print UPPER(DATENAME(DW, @fechaIni))
		  print 'indice: '+ cast(@inInicio as varchar)
			
			if(convert(varchar(10), @fechaIni, 112) = convert(varchar(10),@fechaInFinal,112))
			begin
				
				print 'Obtenemos los minutos del dia en que se entrego el efectivo'
				print 'fecha hora de entregade efectivo: ' + cast(@fechaIni as varchar(30))
				print 'el dia de entregade efectivo termina: ' + cast(@fechaInFinal as varchar(30))
				
				set @minDia = DATEDIFF(MINUTE, @fechaIni, @fechaInFinal)
				set @fechaCominezo = @fechaIni
				--select @minDia, @fechaIni as diaEntrega, UPPER(DATENAME(DW, @fechaIni)) as diasemana
				set @fechaIni= DATEADD(DAY,1,@fechaIni) --@fechaIni+1

				
				select @fechaNextDay =(DATEADD(HOUR, @horai,  cast(convert(varchar(10), @fechaIni,23) as datetime2)))
				select @fechaNextDayFinal =(DATEADD(HOUR, @horaf,  cast(convert(varchar(10), @fechaIni,23) as datetime2)))
				--select @minDia as mindias
				print 'minutos transcurridos en el dia que se entrega el efectivo: '+ cast(@minDia as varchar(10))

			end
			else
			begin
				--select @fechaNextDay as diaIni, @fechaNextDayFinal as diaterm
				print 'Dia a procesar'

				if(convert(varchar(10),@fechaNextDay,112) =  convert(varchar(10), GETDATE(),112))
				begin

					print 'minutos dia anterior '+ cast(@minDia as varchar(8))
					PRINT 'minutos dia actual '+ cast(DATEDIFF(MINUTE, @fechaNextDay, GETDATE()) as varchar(8))
					
					if(DATEDIFF(MINUTE, @fechaNextDay, GETDATE())<=540)
					begin
						set @minDia = @minDia+DATEDIFF(MINUTE, @fechaNextDay,  GETDATE())
					end
					--select @minDia as mindias
					print 'dia actual'
					print 'minutos transcurridos: '+ cast(@minDia as varchar(8))
					--select @minDia as mindias, @fechaNextDay as diaActial, UPPER(DATENAME(DW, @fechaIni)) as diasemana
					
				end
				else
				begin
					print 'minutos dia anterior '+ cast(@minDia as varchar(8))
					PRINT 'minutos dia a procesar '+ cast(DATEDIFF(MINUTE, @fechaNextDay, @fechaNextDayFinal) as varchar(8))
			
					set @minDia = @minDia+DATEDIFF(MINUTE, @fechaNextDay, @fechaNextDayFinal)
					
					print 'siguiente dia'
					print 'minutos transcurridos: '+ cast(@minDia as varchar(8))
					--select @minDia as mindias, @fechaNextDay as dia, UPPER(DATENAME(DW, @fechaIni)) as diasemana
				end

				if(@minDia > @minutos)
				begin

				
					if not exists (select 1 from @encontrados WHERE indice = @inInicio)
					begin


						INSERT INTO @encontrados
						 SELECT
						  id
						 ,idEmpresa
						 ,idsucursal
						 ,idDepartamento
						 ,idVale
						 ,PER_IDPERSONA
						 ,rfc
						 ,NOMBRE
						 ,mail
						 ,montoSolicitado
						 ,montoJustificado
						 ,porJustificar
						 ,destinatarioContraloria
						 ,destinatarioNomina
						 ,destinatarioFinanzas
						 ,horas
						 ,asunto
						 ,idBancoDestino
						 ,idBancoOrigen
						 ,idOrigenReferencia
						 ,idUsuario
						 ,@inInicio
						 ,cast(@fechaCominezo as varchar(30))
						 ,cast(@fechaNextDayFinal as varchar(30))
						 ,@minDia
						 ,id_perTra
						 ,null
						 FROM @PorProcesar
						 WHERE indice = @inInicio

						 						set @minDia = 0

					end

					set @minDia = 0

				end
	
				set @fechaNextDay = @fechaNextDay+1
				set @fechaNextDayFinal = @fechaNextDayFinal +1
				set @fechaIni= DATEADD(DAY,1,@fechaIni) 
				
			end
		end
		else
		begin
			print '**** Domingo *****'
			print 'No  suma horas'
			set @fechaIni= DATEADD(DAY,1,@fechaIni) 
			set @fechaNextDay = @fechaNextDay+1
			set @fechaNextDayFinal = @fechaNextDayFinal +1
		end


	  end

      SET @inInicio =  @inInicio + 1
  END --FIN WHILE PRINCIPAL
	
	-- Tablas de apoyo
	DECLARE @tramites TABLE(
		RowId INT,
		id INT,
		id_traDe INT,
		idUsuario INT,
		monto NUMERIC(18,2),
		id_perTra INT
	);

	DECLARE @RespuestaRembolso TABLE(
		success INT,
		id_perTraReembolso INT
	);

  	IF((select count(*) from @encontrados) > 0)
		BEGIN
			/*
				actualizamos el estatus para indicar que ya se proceso
			*/
			--DESCOMENTAR
			--UPDATE v
			--SET v.descuentoSolicitado = 1
			--   ,v.notificadoUsuario = 0
			--   ,v.notificadoNominas = 0
			--   ,v.notificadoContraloria = 0
			--   ,v.estatusVale = 6   --- Antes 6 ahora 7 de la tabla de estatus
			SELECT * 
			FROM tramite.vales v
			JOIN @encontrados en ON v.id = en.id

			--DESCOMENTAR
			--insert Tramites.dbo.BITACORA_VALES_VENCIDOS( id ,idEmpresa ,idSucursal, idDepartamento ,idVale ,idPersona ,rfc ,nombre ,mail ,montoSolicitado ,montoJustificado ,porJustificar ,destinatarioContraloria ,destinatarioNomina ,horas ,asunto,idBancoDestino ,idBancoOrigen ,idOrgenReferencia ,idUsuario ,fechaPeticion )
			SELECT distinct
			 id
			 ,idEmpresa
			 ,idsucursal
			 ,idDepartamento
			 ,idVale
			 ,PER_IDPERSONA
			 ,rfc
			 ,NOMBRE
			 ,mail
			 ,montoSolicitado
			 ,montoJustificado
			 ,porJustificar
			 ,destinatarioContraloria
			 ,destinatarioNomina
			 ,horas
			 ,asunto
			 ,idBancoDestino
			 ,idBancoOrigen
			 ,idOrigenReferencia
			 ,idUsuario
			 ,getdate()
			FROM @encontrados

			-- Se inserta en tabla @tramites para control del ciclo
			INSERT INTO @tramites
			SELECT
				ROW_NUMBER() OVER(ORDER BY id) AS RowNum
				,id
				,TDEV.id_traDe
				,idUsuario
				,porJustificar
				,TMP.id_perTra
			FROM @encontrados TMP
			INNER JOIN tramiteDevoluciones TDEV ON TMP.id_perTra = TDEV.id_perTra

			-- Se declara variables para recorrer el ciclo
			DECLARE @CurTramite INT,
					@MaxTramite INT;

			-- Se declara variables para usarse en el SP de insertar ramites de reembolsos
			DECLARE @TR_id_traDe INT,
					@TR_idUsuario INT,
					@TR_id INT,
					@TR_monto decimal(18,4),
					@TR_CurTra INT,
					@TR_URL VARCHAR(500)
		
			-- Seteamos los valores para recorrer el ciclo
			SELECT @CurTramite = MIN(RowId), @MaxTramite = MAX(RowId) FROM @tramites;

			-- Ciclo para insertar los tramites de todas las solicitudes de devoluciones de vales
			WHILE ( @CurTramite <= @MaxTramite )
				BEGIN
					SELECT 
						@TR_id_traDe = id_traDe
						,@TR_id = id
						,@TR_idUsuario = idUsuario
						,@TR_monto = monto
					FROM @tramites
					WHERE RowId = @CurTramite;

					
					-- DESCOMENTAR
					-- INSERT INTO @RespuestaRembolso
					-- EXEC [dbo].[SEL_FONDOFIJOREEMBOLSO_TRAMITE_SP] @TR_id_traDe, @TR_idUsuario, @TR_monto;
					INSERT INTO @RespuestaRembolso VALUES(1, 1728)
					
					update 
						@encontrados 
					set 
						id_perTraRembolso = (SELECT TOP 1 id_perTraReembolso FROM @RespuestaRembolso)
					where 
						id = @TR_id;
					-- Se hace operacion con la respuesta
					--
					--
					-- Se obtienen la ruta
					SET @TR_URL = (select pr_descripcion + '\\FondoFijo\\FondoFijo_' from parametros WHERE pr_tipoParametro ='Save' AND pr_identificador = 'RUTA_SAVE_LOC' );

					-- INSERT INTO [Tramite].[valesEvidencia] ([idVales], [idfactura] ,[idestatus] ,[esFactura] ,[url] ,[archivo] ,[extension] ,[monto] ,[fechaCreacion] ,[comentario] ,[idGastoFondoFijo] ,[areaAfectacion] ,[conceptoAfectacion] ,[numeroCuenta] ,[tipoComprobante] ,[tipoIVA] ,[IVA] ,[IVAretencion] ,[ISRretencion] ,[subTotal] ,[idComprobacionVale] ,[procesoPoliza] ,[compNoAutorizado] ,[estatusReembolso] ,[envioReembolso] ,[montoPoliza] ,[motivo] ,[envioNotificacion] ,[fechaRechazo] ,[comprobacionMas] ,[comprobacionMasArchivo] ,[id_perTraReembolso] ,[estatusPerTraReembolso])
					SELECT
						--[id] = NULL, -- Autoincrement, no aplica para insercion
						[idVales] = T.id,
						[idfactura] = NULL, -- N/A (No Aplica)
						[idestatus] = 2,
						[esFactura] = NULL, -- N/A
						[url] = @TR_URL + CONVERT(VARCHAR(10), T.id_perTra) + '\\Vales_' + CONVERT(VARCHAR(10), T.id),
						[archivo] = 'AutorizacionVale_' + CONVERT(VARCHAR(10), T.id ),--V.idVale,
						[extension] = 'pdf',
						[monto] = monto,
						[fechaCreacion] = GETDATE(),
						[comentario] = '',
						[idGastoFondoFijo] = 2,--V.idGastosFondoFijo, 
						[areaAfectacion] = '', -- N/A
						[conceptoAfectacion] = '', -- N/A
						[numeroCuenta] = '', -- N/A
						[tipoComprobante] = 0, -- N/A
						[tipoIVA] = 0, -- N/A
						[IVA] = 0, -- N/A
						[IVAretencion] = 0, -- N/A
						[ISRretencion] = 0, -- N/A
						[subTotal] = 0, -- N/A
						[idComprobacionVale] = '',
						[procesoPoliza] = 1,
						[compNoAutorizado] = 0,
						[estatusReembolso] = null,
						[envioReembolso] = 1,
						[montoPoliza] = monto,
						[motivo] = 'Evidencia vales con solicitud de descuento', -- N/A
						[envioNotificacion] = NULL, -- N/A
						[fechaRechazo] = NULL, -- N/A
						[comprobacionMas] = NULL, -- N/A
						[comprobacionMasArchivo] = NULL, -- N/A
						[id_perTraReembolso] = (SELECT TOP 1 id_perTraReembolso FROM @RespuestaRembolso), -- N/A
						[estatusPerTraReembolso] = NULL -- N/A
					FROM @tramites T
					INNER JOIN tramite.vales V ON t.id = V.id
					WHERE RowId = @CurTramite;

					SET @TR_CurTra = @@IDENTITY;

					--INSERT INTO ValeDescuentoSolicitado(success, id_perTraReembolso, IdTramiteReembolso, IdValeEvidencia, idUsuario, FechaRegisro)
					SELECT success, id_perTraReembolso, @TR_id IdTramiteReembolso, @TR_CurTra IdValeEvidencia, @TR_idUsuario idUsuario, GETDATE() FechaRegistro FROM @RespuestaRembolso;
					DELETE FROM @RespuestaRembolso;
		
					-- select * from Tramite.valesEvidencia where id = 269

					SET @CurTramite = @CurTramite + 1;
				END

		END


  	SELECT distinct
      id
     ,idEmpresa
     ,idsucursal
     ,idDepartamento
     ,idVale
     ,PER_IDPERSONA
     ,rfc
     ,nombre
     ,mail
     ,montoSolicitado
     ,montoJustificado
     ,porJustificar
     ,destinatarioContraloria
     ,destinatarioNomina
	 ,destinatarioFinanzas
     ,horas
     ,asunto
     ,idBancoDestino
     ,idBancoOrigen
     ,idOrigenReferencia
     ,idUsuario
	 ,fechaEntregadinero
	 ,fechaCierre
	 , minutostranscurridos
	 ,id_perTraRembolso
    FROM @encontrados


END
go

