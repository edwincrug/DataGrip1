-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <17/10/2019>
-- Description:	<SP que trae los datos de los FF x usuario>
-- SEL_TIPOUSUARIOFONDOFIJOXSUCURSALTIPO_SP 6, 2611
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOUSUARIOFONDOFIJOXSUCURSALTIPO_SP] 
	@tipo INT,
	@idperta INT
AS
BEGIN

	DECLARE @idEmpresa INT, @idSucursal INT

	select @idEmpresa = id_empresa, @idSucursal = id_sucursal from tramiteDevoluciones where id_perTra = @idperta

	IF (@tipo = 7)
	BEGIN
	SELECT
	uff.idUsuario,
	uff.idUsuariosFondoFijo as tipoUsuarioFF,
	u.usu_paterno + ' ' + u.usu_materno + ' ' + u.usu_nombre  as usuarioFinanzas
	FROM [Tramite].[UsuariosFondoFijo] uff
	inner join [Tramites].[Tramite].[Reembolso_Autorizadores_FF] ra on ra.idUsuario = uff.idUsuario and ra.nivelFinanzas = uff.idUsuariosFondoFijo 
	inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = uff.idUsuario
	and ra.idempresa = @idEmpresa and ra.idsucursal = @idSucursal
	WHERE uff.idUsuariosFondoFijo = @tipo and uff.idUsuariosFondoFijo in(5,6,7) and uff.idUsuario = 82
	END
	ELSE
	BEGIN
	SELECT
	uff.idUsuario,
	uff.idUsuariosFondoFijo as tipoUsuarioFF,
	u.usu_paterno + ' ' + u.usu_materno + ' ' + u.usu_nombre  as usuarioFinanzas
	FROM [Tramite].[UsuariosFondoFijo] uff
	inner join [Tramites].[Tramite].[Reembolso_Autorizadores_FF] ra on ra.idUsuario = uff.idUsuario and ra.nivelFinanzas = uff.idUsuariosFondoFijo 
	inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = uff.idUsuario
	and ra.idempresa = @idEmpresa and ra.idsucursal = @idSucursal
	WHERE uff.idUsuariosFondoFijo = @tipo and uff.idUsuariosFondoFijo in(5,6,7)
	END
END

go

