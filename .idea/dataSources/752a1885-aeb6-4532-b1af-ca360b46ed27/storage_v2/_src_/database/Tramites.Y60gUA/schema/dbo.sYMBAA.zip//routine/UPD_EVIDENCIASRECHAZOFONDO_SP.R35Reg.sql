
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <06/05/2020>
-- Description:	<SP que obtiene las evidencias del reembolso el FF>
-- UPD_EVIDENCIASRECHAZOFONDO_SP 1071
-- =============================================
CREATE PROCEDURE [dbo].[UPD_EVIDENCIASRECHAZOFONDO_SP] 
	@idComprobacion INT,
	@razon varchar(max)
AS
BEGIN

UPDATE tramite.valesEvidencia
SET comentario = @razon, estatusReembolso = 2, fechaRechazo = GETDATE()
WHERE id = @idComprobacion

--SELECT 1 success

SELECT 
1 success,
ff.id_perTra,
ff.idFondoFijo,
v.idVale,
ve.idComprobacionVale,
ve.monto,
v.idEmpleado, 
uv.usu_correo as correoVale,
uv.usu_nombre + ' ' + uv.usu_paterno + ' ' + uv.usu_materno as usuVale,
ff.idResponsable,
uf.usu_correo as correoFondo,
uf.usu_nombre + ' ' + uf.usu_paterno + ' ' + uf.usu_materno as usuFondo
FROM tramite.valesEvidencia ve
INNER JOIN tramite.vales v on v.id = ve.idVales
INNER JOIN Tramite.valesFondoFijo vff on vff.idVales = v.id
INNER JOIN Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
INNER JOIN ControlAplicaciones.dbo.cat_usuarios uf on uf.usu_idusuario =  ff.idResponsable
INNER JOIN ControlAplicaciones.dbo.cat_usuarios uv on uv.usu_idusuario =  v.idEmpleado
WHERE ve.id = @idComprobacion

END
go

