-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <06/09/2019>
-- Description:	<Actualiza el importe de un concepto en especifico>
--TEST EXEC [Tramite].[Sp_Tramite_ConceptoImporte_UPD]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ConceptoImporte_UPD] 
	@idTramiteConcepto INT,
	@importe DECIMAL(18, 2),
	@idEstatus INT,
	@comentario VARCHAR(150),
	@idUsuario INT,
	@idTipoProceso INT,
	@idTipoViaje INT = 1,
	@distanciaKm int = 0
AS
BEGIN 

SET NOCOUNT ON;
	
	DECLARE @resultado INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_ConceptoImporte_UPD] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
		
		UPDATE [Tramite].[TramiteConcepto] 
		SET idEstatus = @idEstatus, idTipoViaje = @idTipoViaje, distanciaKilometros= @distanciaKm 
		WHERE idTramiteConcepto = @idTramiteConcepto

		UPDATE [Tramite].[TramiteImporte] 
		SET importe = @importe
		WHERE idTramiteConcepto = @idTramiteConcepto
			AND idTipoProceso = @idTipoProceso

		IF(COALESCE(@comentario, '') != '')
		BEGIN		
			INSERT INTO [Tramite].[TramiteComentario] (
				comentario
				,idTramiteConcepto
				,idUsuario,
				idTipoProceso)
			VALUES (
				@comentario
				,@idTramiteConcepto
				,@idUsuario
				,@idTipoProceso)
		END
		   
		SET @resultado = 1;

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH
	SET NOCOUNT OFF
	
	SELECT @resultado AS [resultado]

END
go

