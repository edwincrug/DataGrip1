-- =============================================
-- Author:		Roberto Almanza
-- Create date: 14-01-2020
-- Description:	<SP que trae los datos estatus por idTramite>
-- TEST SEL_DEV_ESTATUS_SP
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEV_ESTATUS_BY_TRAMITE_SP] 
@idTramite int
AS
BEGIN
	SELECT 
		esDe_IdEstatus AS idEstatus,
		esDe_descripcion AS descripcion,
		esDe_icono AS icono 
	FROM cat_proceso_estatus
	WHERE idTipoTramite = @idTramite
	ORDER BY esDe_IdEstatus asc
END
;
go

exec sp_addextendedproperty 'MS_Description', 'Obtiene la lista de estatus del tramite', 'SCHEMA', 'dbo', 'PROCEDURE',
     'SEL_DEV_ESTATUS_BY_TRAMITE_SP'
go

exec sp_addextendedproperty 'MS_Description', 'id del tipo de tramite', 'SCHEMA', 'dbo', 'PROCEDURE',
     'SEL_DEV_ESTATUS_BY_TRAMITE_SP', 'PARAMETER', '@idTramite'
go

