-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/06/2019>
-- Description:	<Se guarda un tramite>
-- =============================================
CREATE PROCEDURE [dbo].[INS_TRAMITE_SP]
	@tramNombre VARCHAR(150),
	@idArea INT,
	@idUsuario INT
AS
BEGIN
	IF NOT EXISTS( SELECT * FROM cat_tramites WHERE tra_nomTramite = @tramNombre )
		BEGIN
			INSERT INTO cat_tramites
			VALUES(
				@tramNombre,
				@idArea,
				@idUsuario
			)
			SELECT success = 1, msg = 'Se inserto con éxito el tramite.', idTramite = SCOPE_IDENTITY();
		END
	ELSE
		BEGIN
			SELECT success = 0, msg = 'Ya éxiste un tramite con ese nombre.';
		END
END
go

