
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <21/04/2020>
-- Description:	<SP que valida los parametros de Retenciones>
-- [dbo].[SEL_VALIDARETENCIONESORDENCOMPRA_SP]  9, '639', 'FL5','08'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDARETENCIONESORDENCOMPRA_SP] 
		@idsucursal INT,
        @tipoComprobante varchar(20),
		@areaAfectacion varchar(20),
		@conceptoContable varchar(20)
AS
BEGIN
	
DECLARE @nombreBD VARCHAR(100),
		@queryRetencion NVARCHAR(MAX),
		@query NVARCHAR(MAX),
		@tasaRetIVA DECIMAL (18,2) = 0,
		@tasaRetISR DECIMAL (18,2) = 0,
		@msj VARCHAR(MAX),
		@contador INT = 0,
		@rentenciones INT = 0

	select @nombreBD = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
	
	--Se obtienen los porcentajes de retencion de IVA, ISR
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBD+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,2) OUTPUT, @tasaRetISR DECIMAL(18,2) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 
	print @queryRetencion
IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @msj ='success'
select @msj mensaje, 1 estatus, 'Sin retenciones' tipoRetenciones, @contador contador
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
	SET @contador = 1
	
	SET @query ='SELECT @rentenciones = COUNT(*)  FROM ['+@nombreBD+'].[DBO].[CON_CONFCONTA] 
	WHERE  CNC_CONFIGURA = ''PEDIDOS ESPECIALES''
	AND CNC_CONCEPTO IN (''RETIVA'')
	AND CNC_CONCEPTO1 = '''+@areaAfectacion+'''
	AND CNC_CONCEPTO2 = '''+@conceptoContable+'''
	'	
	PRINT @query
	EXECUTE sp_executeSQL @query, N' @rentenciones INT OUTPUT', @rentenciones OUTPUT 
	IF(@rentenciones = @contador)
	BEGIN
	SET @msj ='success'
	select @msj mensaje, 1 estatus, 'Con retancion de IVA y sin retencion de ISR' tipoRetenciones,@contador contador 
	END
	ELSE
	BEGIN
	SET @msj ='No existe configuración Contable, pongase en contacto con Sistemas'
	select @msj mensaje, 0 estatus, 'Con retancion de IVA y sin retencion de ISR' tipoRetenciones,@contador contador
	END
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN
	SET @contador = 2
	SET @query ='SELECT @rentenciones = COUNT(*) FROM ['+@nombreBD+'].[DBO].[CON_CONFCONTA] 
	WHERE  CNC_CONFIGURA = ''PEDIDOS ESPECIALES'' 
	AND CNC_CONCEPTO IN (''RETIVA'', ''RETISR'')
	AND CNC_CONCEPTO1 = '''+@areaAfectacion+'''
	AND CNC_CONCEPTO2 = '''+@conceptoContable+'''
	'	
	PRINT @query
	EXECUTE sp_executeSQL @query, N' @rentenciones INT OUTPUT', @rentenciones OUTPUT 
	
	IF(@rentenciones = @contador)
	BEGIN
	SET @msj ='success'
	select @msj mensaje, 1 estatus, 'Con retancion de IVA y con retencion de ISR' tipoRetenciones, @contador contador
	END
	ELSE
	BEGIN
	SET @msj ='No existe configuración Contable, pongase en contacto con Sistemas'
	select @msj mensaje, 0 estatus, 'Con retancion de IVA y con retencion de ISR' tipoRetenciones, @contador contador
	END
END

END
go

