
-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 06/11/2019
-- Description:	SP que aprueba el tramite
-- TEST [dbo].[UPD_FONDO_SALIDAEFECTIVO_TRAMITE_SP]
-- =============================================
CREATE PROCEDURE [dbo].[UPD_FONDO_SALIDAEFECTIVO_TRAMITE_SP]
	@id_perTra INT,
	@tipo INT,
	@estatus INT,
	@bancoSalida INT,
	@bancoEntrada INT,
	@numCuentaSalida varchar(100) = NULL, 
	@cuentaContableSalida varchar(100) = NULL, 
	@numCuentaEntrada varchar(100) = NULL,
	@cuentaContableEntrada varchar(100) = NULL,
	@idTramiteTesoreria INT = 0,
	@monto DECIMAL (18,2)
AS
BEGIN
	DECLARE  @idSalida INT
	UPDATE tramiteDevoluciones
	SET traDe_fechaAutoriza = GETDATE(), esDe_IdEstatus = @estatus
	WHERE id_perTra = @id_perTra;

	UPDATE Tramite.fondoFijo
	SET idSalidaEfectivo = @tipo, estatusFondoFijo = 1
	WHERE id_perTra = @id_perTra;

	IF(@bancoSalida  > 0 or @bancoEntrada > 0)
	BEGIN
	DECLARE @idfondo INT
	SELECT @idfondo = id FROM Tramite.fondoFijo WHERE id_perTra = @id_perTra;

	INSERT INTO [Tramite].[fondoFijoSalidaEfectivo]
		   (idFondoFijo, 
		   idBancoSalida, 
		   idBancoEntrada,
		   numCuentaSalida,
		   cuentaContableSalida,
		   numCuentaEntrada,
		   cuentaContableEntrada,
		   idTramiteTesoreria)
	VALUES
		   (@idfondo,
		   @bancoSalida,
		   @bancoEntrada,
		   @numCuentaSalida,
		   @cuentaContableSalida,
		   @numCuentaEntrada,
		   @cuentaContableEntrada,
		   @idTramiteTesoreria)
	END
	SET @idSalida = SCOPE_IDENTITY()

	IF(@tipo = 1)
	BEGIN
	DECLARE @disminucion INT
	Select @disminucion = ISNULL(AumentoDisminucion,0) from tramite.fondofijo where id_perTra = @id_perTra
	IF(@disminucion <> 2)
	BEGIN
	DECLARE @consecutivo INT = 0--, @monto DECIMAL (18,2)
	--select @consecutivo = count(id_cuenta) from cuentasTesoreriaFA where id_perTra = @id_perTra and tipo = 1
	--SET @consecutivo = @consecutivo +1;
	--IF(@consecutivo = 0)
	--BEGIN
	--select @monto = traDe_devTotal from tramiteDevoluciones where id_perTra = @id_perTra
	--END
	insert into cuentasTesoreriaFA (id_perTra, fechaInsercion, estatus,id_tipoTramite, tipo, consecutivo, monto)
	values (@id_perTra, GETDATE(),1, 1, 1, @idSalida, @monto)
	END
	END

	SELECT success = 1;

END
go

