-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <06/06/2019>
-- Description:	<Trae todas los documentos>
-- Test [SEL_ALLDOCUMENTOS_SP]
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ALLDOCUMENTOS_SP]
AS
BEGIN
	SELECT 
		id_documento,
		doc_nomDocumento
	FROM cat_documentos 
END
go

