
-- =============================================
-- Author:		<JCPS>
-- Create date: <17/03/2020>
-- Description:	<SP que obtiene CC>
-- [dbo].[SEL_CUENTACONTABLEFONDO_SP]  6, 'FFOP', 13
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CUENTACONTABLEFONDO_SP] 
	@idsucursal INT,
	@poliza VARCHAR(100),
	@idDepartamento INT
AS
BEGIN
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = ''

	SELECT @nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE suc_idsucursal = @idsucursal AND suc_estatus = 1;

	SET @query = 'SELECT TOP 1 CFG_CUENTA FROM [' + @nombreBase + '].[DBO].[CON_CONFIGCONTA] WHERE CFG_PROCESO =  '''+@poliza+'''' 

	EXECUTE (@query)

END

go

