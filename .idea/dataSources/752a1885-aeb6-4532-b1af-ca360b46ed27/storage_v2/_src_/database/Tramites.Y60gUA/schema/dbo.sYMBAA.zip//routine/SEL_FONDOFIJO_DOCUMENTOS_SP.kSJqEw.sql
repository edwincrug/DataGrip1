

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <15/10/2019>
-- Description:	<Trae los documentos de FF>
-- SEL_FONDOFIJO_DOCUMENTOS_SP 'localh', 1312, 10
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJO_DOCUMENTOS_SP]
	@urlParam VARCHAR(30),
	@idPerTra INT,
	@idTramite INT=  null
AS
BEGIN

	DECLARE @url VARCHAR(500);
	IF(@urlParam = 'localhost')
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = @urlParam);
		END
	ELSE
		BEGIN
			SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');		
		END

	DECLARE @saveUrl VARCHAR(100) = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC');

	DECLARE @esAumentoDecremento INT, @AumentoDecremento INT = 0
	select @esAumentoDecremento = AumentoDisminucion from Tramite.fondoFijo where id_perTra = @idPerTra
	SET @esAumentoDecremento = ISNULL(@esAumentoDecremento,0)
	IF(@esAumentoDecremento > 0)
		BEGIN
			select  @AumentoDecremento = ffc.id 
			from Tramites.Tramite.fondofijo  ff
			inner join Tramites.Tramite.fondoFijoCambios ffc on ffc.id = ff.AumentoDisminucion
			where ff.id_perTra = @idPerTra and ffc.estatus = 1
			SET @AumentoDecremento = ISNULL(@AumentoDecremento,0)

		END

	SELECT distinct
		DPT.det_idPerTra,
		T.id_tramite, 
		PT.id_perTra,
		EXT.ext_nombre,
		TD.id_traDo,
		TD.id_documento,
		1 existe,
		DPT.det_estatus estatusDocumento,
		PT.petr_estatus estatusTramite,
		case when @AumentoDecremento > 0 and  DPT.det_observaciobes = '' then 
		case when TD.id_documento = 46 then @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),PT.id_perTra) + '/CartaResponsiva_' + CONVERT(VARCHAR(10),@AumentoDecremento)+'.pdf'
		when TD.id_documento = 47 then  @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),PT.id_perTra) + '/Pagare_' + CONVERT(VARCHAR(10),@AumentoDecremento)+'.pdf'
		when TD.id_documento = 4 then @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),PT.id_perTra) + '/Documento_' + CONVERT(VARCHAR(10),TD.id_documento)+'.'+EXT.ext_nombre end
		when  @AumentoDecremento = 0 and DPT.det_observaciobes = '' then @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),PT.id_perTra) + '/Documento_' + CONVERT(VARCHAR(10),TD.id_documento)+'.'+EXT.ext_nombre
		else @url +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),PT.id_perTra) + '/Documento_' + CONVERT(VARCHAR(10),TD.id_documento)+ '_' + DPT.det_observaciobes +'.'+EXT.ext_nombre end [url],	
		--'C:/app/public/Imagenes/' +'FondoFijo/' + 'FondoFijo_' + CONVERT(VARCHAR(20),PT.id_perTra) + '/Documento_' + CONVERT(VARCHAR(10),TD.id_documento)+'.'+EXT.ext_nombre [url],	
		doc_nomDocumento, 
		TD.id_traDo,
		EXT.ext_nombre ,   
		DOC.doc_infoAdicional, 
		doc_expira,
		EXT.id_extension idExtension, 
		DOC.opcional,
		@saveUrl saveUrl
		,det_observaciobes as Observaciones
	FROM cat_tramites T
	INNER JOIN [personaTramite] PT ON PT.id_tramite = T.id_tramite
	INNER JOIN  [dbo].[detallePersonaTramite] DPT ON DPT.id_perTra = PT.id_perTra
	INNER JOIN cat_tramiteDocumento TD ON TD.id_tramite = T.id_tramite and TD.id_traDo = DPT.id_traDo
	INNER JOIN cat_documentos DOC ON DOC.id_documento = TD.id_documento
	INNER JOIN cat_extensiones EXT ON EXT.id_extension = DOC.id_extension
	WHERE PT.id_perTra = @idPerTra --and T.id_tramite = @idTramite  
END

go

