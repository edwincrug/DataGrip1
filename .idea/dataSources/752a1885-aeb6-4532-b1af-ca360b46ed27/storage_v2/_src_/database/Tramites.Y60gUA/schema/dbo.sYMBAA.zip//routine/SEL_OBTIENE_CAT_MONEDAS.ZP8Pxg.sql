
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENE_CAT_MONEDAS] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  SELECT id
  ,nombre
  ,imagen
  ,valor
  ,tipo  
  FROM Tramites.dbo.monedas
  order by valor, tipo

END
go

