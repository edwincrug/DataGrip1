-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2020/07/08
-- Description:	Se obtienen el primer registro de banco por usuario/empresa
-- [dbo].[Sel_Gatos_GetBancoData_SP] 71, 4
-- =============================================
create PROCEDURE [dbo].[Sel_Gastos_GetData_ByCuenta]
	-- Add the parameters for the stored procedure here
	@Cuenta VARCHAR(20),
	@IdEmpresa INT = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @IpServer VARCHAR(300), @IpServerOnly VARCHAR(20);
	SELECT 
		@IpServer = '['+ [nombre_base]+'].[dbo].[CON_BANCOS]'
	FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
	WHERE emp_idempresa = @IdEmpresa AND tipo = 2;

	DECLARE @table TABLE(
		BCO_NUMCUENTA VARCHAR(20), 
		BCO_CLABE VARCHAR(20), 
		BCO_PLAZA VARCHAR(10), 
		BCO_SUCURSAL VARCHAR(10)
	);

	DECLARE @Validacion TABLE (BCO_CONSE INT);
	DECLARE @QueryVal VARCHAR(MAX) = 'SELECT TOP 1 BCO_NUMCUENTA, BCO_CLABE, BCO_PLAZA, BCO_SUCURSAL FROM ' + @IpServer + ' WHERE BCO_NUMCUENTA = '''+@Cuenta+'''';

	INSERT INTO @table
	EXEC(@QueryVal)

	SELECT TEM.*, CA.ca_banconombre BCO_NOMBREBANCO
	FROM [cuentaAutorizada] CA
	INNER JOIN @table TEM ON CA.ca_cuenta = TEM.BCO_NUMCUENTA
END


go

