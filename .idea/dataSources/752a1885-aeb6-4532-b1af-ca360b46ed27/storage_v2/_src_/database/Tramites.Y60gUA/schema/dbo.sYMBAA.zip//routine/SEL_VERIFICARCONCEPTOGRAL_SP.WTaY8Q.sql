

-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <24/01/2020>
-- Description:	<SP que verifica los vales>
-- [dbo].[SEL_VERIFICARCONCEPTOGRAL_SP] 1001
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VERIFICARCONCEPTOGRAL_SP] 
	@idTramiteConcepto INT
AS
BEGIN

--select 
--sum(ti.importe) as montoSolicitado,
--sum(ca.total) as montoJustificado,
--case when  sum(ca.total) = sum(ti.importe)  then  1 
--when sum(ca.total) > sum(ti.importe)  then 1
--else 0  end as justifico,
--case when sum(ca.total) > sum(ti.importe) then  sum(ca.total) - sum(ti.importe) else 0  end as justificoMas
--from  Tramite.TramiteConcepto  tc 
--inner join Tramite.TramiteImporte ti on ti.idTramiteConcepto =  tc.idTramiteConcepto and ti.idTipoProceso = 2
--left join  [Tramite].[ConceptoArchivo] ca on ca.idReferencia = tc.idTramiteConcepto  and ca.idEstatus = 9
--where tc.idTramitePersona =  @idTramiteConcepto
--group by ti.importe

select
tc.documentoConcepto, 
ti.importe as montoSolicitado,
ISNULL(sum(ca.total),0) as montoJustificado,
case when  sum(ca.total) = ti.importe  then  1 
when sum(ca.total) > ti.importe  then 1
else 0  end as justifico,
case when sum(ca.total) > ti.importe then  sum(ca.total) - ti.importe else 0  end as justificoMas
--select ti.*,ca.*
from  Tramite.TramiteConcepto  tc 
inner join Tramite.TramiteImporte ti on ti.idTramiteConcepto =  tc.idTramiteConcepto and ti.idTipoProceso = 2
left join  [Tramite].[ConceptoArchivo] ca on ca.idReferencia = tc.idTramiteConcepto  and ca.idEstatus = 9
where tc.idTramitePersona =  @idTramiteConcepto
group by ti.importe,  tc.documentoConcepto

END
go

