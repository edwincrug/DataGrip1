
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <25/10/2019>
-- Description:	<SP que trae los datos de los FF x sucursal>
-- [dbo].[SEL_FONDOFIJOXSUCURSALUSUARIO_SP]  2622
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJOXSUCURSALUSUARIO_SP] 
	@idUsuario INT
AS
BEGIN

	DECLARE @idSucursal INT, @idEmpresa INT
--	SELECT @idSucursal = suc_idsucursal, @idEmpresa = emp_idempresa FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @idUsuario

--	SELECT 
--	FF.id,
--	FF.idEmpresa, 
--	FF.idSucursal, 
--	FF.idDepartamento, 
--	FF.idAutorizador, 
--	FF.idResponsable, 
--	TD.traDe_devTotal as monto, 
--	(select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
--	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale in (2,3,4)
--	WHERE  VFF.idTablaFondoFijo = FF.id) as Gastado,
--	'' as montoFaltante, 
--	ISNULL(TD.traDe_Observaciones,'') AS descripcion,
--	FF.nombreFondoFijo,
--	FF.idFondoFijo + ' - ' + A.are_nombreArea + ' - ' + U.usu_nombre + ' ' + U.usu_paterno  + ' ' +  U.usu_materno      as idFondoFijo,
--	CONVERT(varchar, FF.fechaCreacion, 103) as fechaCreacion,
--	CASE WHEN PT.petr_estatus IN (2, 3, 5) 
--	THEN ET.est_nombre 
--	ELSE 
--	PED.esDe_descripcion 
--	END  AS est_nombre
--FROM [Tramite].[fondoFijo] FF
--INNER JOIN personaTramite PT ON PT.id_perTra = FF.id_perTra
--INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
--INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
----LEFT JOIN Tramite.valesFondoFijo VFF ON VFF.idTablaFondoFijo = FF.id
----LEFT JOIN Tramite.vales V ON V.id = VFF.idVales
--INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = FF.idResponsable
--INNER JOIN usuarioRol UR ON UR.idUsuario = FF.idResponsable
--INNER JOIN cat_areas A ON A.id_area = UR.id_area
--LEFT JOIN cat_proceso_estatus PED ON PED.esDe_IdEstatus = TD.esDe_IdEstatus AND PED.idTipoTramite = 10
--WHERE FF.idEmpresa = @idEmpresa AND FF.estatusFondoFijo not in (4) AND  PT.petr_estatus = 2--TD.esDe_IdEstatus in (3,5)
----AND TD.traDe_devTotal > (select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
----	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale in (2,3,4)
----	WHERE  VFF.idTablaFondoFijo = FF.id)
--ORDER  BY FF.id desc


IF EXISTS (SELECT TOP 1 1 FROM [Tramite].[UsuariosMultiMarcaFF] where idUsuario =  @idUsuario and estatus = 1) 
BEGIN

   	SELECT 
	FF.id,
	FF.idEmpresa, 
	FF.idSucursal, 
	FF.idDepartamento, 
	FF.idAutorizador, 
	FF.idResponsable, 
	TD.traDe_devTotal as monto, 
	(select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale in (2,3,4)
	WHERE  VFF.idTablaFondoFijo = FF.id) as Gastado,
	'' as montoFaltante, 
	ISNULL(TD.traDe_Observaciones,'') AS descripcion,
	FF.nombreFondoFijo,
	FF.idFondoFijo + ' - ' + A.are_nombreArea + ' - ' + U.usu_nombre + ' ' + U.usu_paterno  + ' ' +  U.usu_materno      as idFondoFijo,
	CONVERT(varchar, FF.fechaCreacion, 103) as fechaCreacion,
	CASE WHEN PT.petr_estatus IN (2, 3, 5) 
	THEN ET.est_nombre 
	ELSE 
	PED.esDe_descripcion 
	END  AS est_nombre
FROM [Tramite].[fondoFijo] FF
INNER JOIN personaTramite PT ON PT.id_perTra = FF.id_perTra
INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = FF.idResponsable
INNER JOIN usuarioRol UR ON UR.idUsuario = FF.idResponsable
INNER JOIN cat_areas A ON A.id_area = UR.id_area
LEFT JOIN cat_proceso_estatus PED ON PED.esDe_IdEstatus = TD.esDe_IdEstatus AND PED.idTipoTramite = 10
WHERE FF.estatusFondoFijo not in (4) AND  PT.petr_estatus = 2 AND  FF.idSucursal in (SELECT idSucursal FROM [Tramite].[UsuariosMultiMarcaFF] where idUsuario =  @idUsuario and estatus = 1) AND FF.tipoCierre is null
ORDER  BY FF.id desc

END
ELSE
BEGIN
    
	SELECT @idSucursal = suc_idsucursal, @idEmpresa = emp_idempresa FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @idUsuario

	SELECT 
	FF.id,
	FF.idEmpresa, 
	FF.idSucursal, 
	FF.idDepartamento, 
	FF.idAutorizador, 
	FF.idResponsable, 
	TD.traDe_devTotal as monto, 
	(select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale in (2,3,4)
	WHERE  VFF.idTablaFondoFijo = FF.id) as Gastado,
	'' as montoFaltante, 
	ISNULL(TD.traDe_Observaciones,'') AS descripcion,
	FF.nombreFondoFijo,
	FF.idFondoFijo + ' - ' + A.are_nombreArea + ' - ' + U.usu_nombre + ' ' + U.usu_paterno  + ' ' +  U.usu_materno      as idFondoFijo,
	CONVERT(varchar, FF.fechaCreacion, 103) as fechaCreacion,
	CASE WHEN PT.petr_estatus IN (2, 3, 5) 
	THEN ET.est_nombre 
	ELSE 
	PED.esDe_descripcion 
	END  AS est_nombre
FROM [Tramite].[fondoFijo] FF
INNER JOIN personaTramite PT ON PT.id_perTra = FF.id_perTra
INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
--LEFT JOIN Tramite.valesFondoFijo VFF ON VFF.idTablaFondoFijo = FF.id
--LEFT JOIN Tramite.vales V ON V.id = VFF.idVales
INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = FF.idResponsable
INNER JOIN usuarioRol UR ON UR.idUsuario = FF.idResponsable
INNER JOIN cat_areas A ON A.id_area = UR.id_area
LEFT JOIN cat_proceso_estatus PED ON PED.esDe_IdEstatus = TD.esDe_IdEstatus AND PED.idTipoTramite = 10
WHERE FF.idEmpresa = @idEmpresa AND FF.estatusFondoFijo not in (4) AND  PT.petr_estatus = 2 AND FF.tipoCierre is null --TD.esDe_IdEstatus in (3,5)
--AND TD.traDe_devTotal > (select ISNULL(SUM(V.montoSolicitado),0) from  Tramite.valesFondoFijo VFF 
--	LEFT JOIN Tramite.vales V on VFF.idVales = V.id and V.estatusVale in (2,3,4)
--	WHERE  VFF.idTablaFondoFijo = FF.id)
ORDER  BY FF.id desc

END

END



go

