-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <03/12/2019>
-- Description:	<SP que actualiza la salida de efectivo de el concepto>
-- [dbo].[UPD_SALIDAEFECTIVOCONCEPTO_SP]    85
-- =============================================
CREATE PROCEDURE [dbo].[UPD_SALIDAEFECTIVOCONCEPTO_SP] 
	@idTramitePersona INT,
	@idSalida INT,
	@bancoSalida INT,
	@bancoEntrada INT,
	@numCuentaSalida varchar(100) = NULL, 
	@cuentaContableSalida varchar(100) = NULL, 
	@numCuentaEntrada varchar(100) = NULL,
	@cuentaContableEntrada varchar(100) = NULL,
	@monto Decimal (18,2)
AS
BEGIN
	DECLARE @id_cuenta INT;

	UPDATE  [Tramite].[TramiteConcepto]
	SET  idSalidaEfectivo =  @idSalida,
		 idBancoSalida = @bancoSalida, 
		 idBancoEntrada = @bancoEntrada, 
		 numCuentaSalida = @numCuentaSalida,
		 cuentaContableSalida = @cuentaContableSalida,
		 numCuentaEntrada = @numCuentaEntrada,
		 cuentaContableEntrada = @cuentaContableEntrada
	WHERE idTramitePersona = @idTramitePersona-- and idSalidaEfectivo is null

	update hp
	set hp.activo = 0
	from tramites.dbo.HistoricoPresupuestosGVAprobados hp
	where hp.idPerTra = @idTramitePersona
	
	DECLARE @consecutivo INT = 0
	IF(@idSalida = 1)
	BEGIN
		
		select @consecutivo = count(id_cuenta) from cuentasTesoreriaFA where id_perTra = @idTramitePersona and tipo = 4
		SET @consecutivo = @consecutivo +1;
		insert into cuentasTesoreriaFA (id_perTra, fechaInsercion, estatus,id_tipoTramite, tipo, consecutivo, monto)
		values (@idTramitePersona, GETDATE(),1, 1, 4, @consecutivo, @monto)

		SET @id_cuenta = @@IDENTITY;
	END
	
	if(@idSalida = 3)
	begin
	
		select @consecutivo = count(id_cuenta) from cuentasTesoreriaFA where id_perTra = @idTramitePersona and tipo = 5
		SET @consecutivo = @consecutivo +1;
		insert into cuentasTesoreriaFA (id_perTra, fechaInsercion, estatus,id_tipoTramite, tipo, consecutivo, monto)
		values (@idTramitePersona, GETDATE(),1, 1, 5, @consecutivo, @monto)

		SET @id_cuenta = @@IDENTITY;
	end

	SELECT success = 1, msg = 'Se actualizo correctamente', @id_cuenta  as id_cuenta;

END
go

