-- =============================================
-- Author:		<Luis garcia>
-- Create date: <17/09/2019>
-- Description:	<Guarda los documento al vuelo>
-- INS_DOCUMENTOS_EN_PROCESO_DE_TRAMITE 47, 'VOUCHER', 2, 21, 4, 'Se necesita'
-- =============================================
CREATE PROCEDURE [dbo].[INS_DOCUMENTOS_EN_PROCESO_DE_TRAMITE]
	@idPerTra INT,
	@nombreDocumento VARCHAR(500),
	@extension INT,
	@idUsuario INT,
	@idTramite INT,
	@porSolicita VARCHAR(500)
AS
BEGIN
	BEGIN TRY
		DECLARE @idDocumento INT, @idTraDo INT, @idDocumentoNext INT;

		SELECT 
			@idDocumentoNext = MAX(id_documento) + 1
		FROM cat_documentos

		INSERT INTO cat_documentos
		VALUES(
			@idDocumentoNext,
			@nombreDocumento,
			@extension,
			0,
			0,
			'',
			@idUsuario,
			3,
			1)

		----SET @idDocumento = SCOPE_IDENTITY();

		INSERT INTO cat_tramiteDocumento
		VALUES(
			@idTramite,
			@idDocumentoNext)

		SET @idTraDo = SCOPE_IDENTITY();

		INSERT INTO detallePersonaTramite
		VALUES(
			@idPerTra,
			@idTraDo,
			3,
			@porSolicita)

		SELECT success = 1, msg = 'Se guardo el documento éxito.'
	END TRY
	BEGIN CATCH
		SELECT success = 0, msg = ERROR_MESSAGE();
	END CATCH
END
go

