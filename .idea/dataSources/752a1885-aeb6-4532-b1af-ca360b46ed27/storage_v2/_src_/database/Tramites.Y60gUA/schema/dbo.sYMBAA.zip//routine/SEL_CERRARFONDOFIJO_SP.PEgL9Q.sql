-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <16/10/2019>
-- Description:	<SP que cierra un Fondo Fijo>
-- [SEL_CERRARFONDOFIJO_SP] 1130
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CERRARFONDOFIJO_SP] 
	@idfondo INT
AS
BEGIN
	
	
DECLARE @ValesCancelacion TABLE
(id INT)

INSERT INTO @ValesCancelacion
select 
v.id
from Tramite.fondoFijo ff
inner join Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join Tramite.vales v on v.id = vff.idVales
where ff.id = @idfondo and v.estatusVale in (1,2)

--Rechazamos vales en procesos 1,2
UPDATE v
SET v.estatusVale = 5
FROM Tramite.fondoFijo ff
inner join Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join Tramite.vales v on v.id = vff.idVales
where ff.id = @idfondo and v.estatusVale in (1,2)


--Actualizamos el Fondo fijo a cerrado
UPDATE Tramite.fondoFijo
SET estatusFondoFijo = 4
WHERE id = @idfondo 

select 1 success

select 
v.id, 
v.idVale, 
v.montoSolicitado,
ev.descripcion as estatusVale,
u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as nombre,
u.usu_correo as correo,
'Rechazo de Vale por Cierre de Fondo Fijo ' + ff.idfondofijo as asunto
 from Tramite.fondoFijo ff
inner join Tramite.valesFondoFijo vff on vff.idTablaFondoFijo = ff.id
inner join Tramite.vales v on v.id = vff.idVales
inner join Tramite.cat_estatusVale ev on ev.id = v.estatusVale
inner join ControlAplicaciones.dbo.cat_Usuarios u on u.usu_idusuario = v.idEmpleado
where v.id in (SELECT id FROM @ValesCancelacion)

 


END
go

