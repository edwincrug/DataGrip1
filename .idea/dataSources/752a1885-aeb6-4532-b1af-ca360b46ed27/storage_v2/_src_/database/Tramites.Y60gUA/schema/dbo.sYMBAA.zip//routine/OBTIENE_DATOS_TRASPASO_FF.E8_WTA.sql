-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [OBTIENE_DATOS_TRASPASO_FF] 1280
-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_DATOS_TRASPASO_FF]
	@idPerTra INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON; 

	DECLARE @fechaAtencion DATETIME, @tipoSalida INT = 0, @idPerTraFFyGV INT = 0, @monto DECIMAL(18,2), @consecutivo int, @idtramiteOriginal int



	SET @fechaAtencion = (SELECT
		l.fechaAtencion
	  FROM tramites.dbo.tsb_traspasosaldobancosFondoFijo tt
	  JOIN Tramites.dbo.traspasosFondoFijoLog l
		ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
	  WHERE l.idPerTra = @idPerTra)



	IF (ISDATE(@fechaAtencion) = 0)
	BEGIN
	  UPDATE l
	  SET l.fechaAtencion = GETDATE()
	  FROM tramites.dbo.tsb_traspasosaldobancosFondoFijo tt
	  JOIN Tramites.dbo.traspasosFondoFijoLog l
		ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
	  WHERE l.idPerTra = @idPerTra

	  UPDATE t
	  SET fechaAtencion = GETDATE()
	  FROM cuentasTesoreria t
	  WHERE t.id_perTra = @idPerTra
	END

	/*buscamos el tramite que detono la trasnferecia*/
	IF EXISTS(
	SELECT 1
	 FROM personaTramite t
	  JOIN Tramite.fondoFijo f
	  ON t.id_pertra = f.id_perTra
	  JOIN tramite.fondoFijoSalidaEfectivo fse
	  ON f.id = fse.idFondoFijo
	  AND fse.idTramiteTesoreria = @idPerTra
	) BEGIN

		SELECT @idPerTraFFyGV = t.id_perTra, @monto = f.montoDisponible,@idtramiteOriginal = t.id_tramite
		 FROM personaTramite t
		  JOIN Tramite.fondoFijo f
		  ON t.id_pertra = f.id_perTra
		  JOIN tramite.fondoFijoSalidaEfectivo fse
		  ON f.id = fse.idFondoFijo
		  AND fse.idTramiteTesoreria = @idPerTra

	END
	else if exists(	SELECT 1
	 FROM personaTramite t
	  JOIN Tramite.fondoFijo f
	  ON t.id_pertra = f.id_perTra
	  JOIN tramite.fondoFijoReembolso fse
	  ON f.id = fse.idFondoFijo
	  AND fse.idTramiteTesoreria = @idPerTra)
	begin
		
		SELECT @idPerTraFFyGV = t.id_perTra, @monto = f.montoDisponible, @idtramiteOriginal = t.id_tramite
		 FROM personaTramite t
		  JOIN Tramite.fondoFijo f
		  ON t.id_pertra = f.id_perTra
		  JOIN tramite.fondoFijoReembolso fse
		  ON f.id = fse.idFondoFijo
		  AND fse.idTramiteTesoreria = @idPerTra

	end
	else
	begin
		SELECT @idPerTraFFyGV = tl.idPerTraFFyGV, @monto = tff.tsb_importe
		FROM Tramites.dbo.traspasosFondoFijoLog tl
		  JOIN Tramites.dbo.tsb_traspasosaldobancosFondoFijo tff
		  ON tl.idTransferencia = tff.tsb_idtraspasosaldobancos
		WHERE tl.idPerTra = @idPerTra

			/* 
			buscamos el tipo de salida de GV
			tipo 0 significa que es salida por caja
			*/
		SELECT
		@tipoSalida = isnull(tipo,0), @idtramiteOriginal= t.id_tramite
		FROM tramites..cuentasTesoreriaFA tf
		join personaTramite t
		on tf.id_pertra= t.id_pertra
		WHERE tf.id_perTra = @idPerTraFFyGV

		if(@idtramiteOriginal is null)
		begin
			select @idtramiteOriginal = t.id_tramite
			from personaTramite t
			where t.id_perTra = @idPerTraFFyGV 
		end

		print 'entro'
	end
	


	IF (@tipoSalida = 4 OR @tipoSalida = 0 OR @tipoSalida IS NULL)
	BEGIN
	  ;
	  WITH transferencia
	  AS
	  (SELECT
		  tsb_idempresa AS idEmpresa
		 ,emp_nombre AS nomEmpresa
		 ,tl.idTransferencia
		 ,tsb_cuentaorigen AS cuentaOrigen
		 ,tsb_cuentadestino AS cuentaDestino
		 ,us.usu_nombre + ' ' + usu_paterno + ' ' + usu_materno AS nombreSolicitante
		 ,us.usu_correo AS email
		 ,tsb_importe AS importe
		 ,ISNULL(tb.tsb_fechasolicita, '') AS fechaSolicita
		 ,ISNULL(pt.esDe_IdEstatus, '') AS esDe_IdEstatus
		 ,ISNULL(tl.fechaAtencion, '') AS fechaAtencion
		 ,ISNULL(tl.fechaAutorizadaRechazada, '') AS fechaAutorizadaRechazada
		 ,pt.petr_observaciones
		 ,idPerTraFFyGV = tl.idPerTra
		     ,tl.consecutivo
		FROM Tramites.dbo.traspasosFondoFijoLog tl
		JOIN tramites.dbo.tsb_traspasosaldobancosFondoFijo tb
		  ON tl.idtransferencia = tb.tsb_idtraspasosaldobancos
		JOIN ControlAplicaciones.dbo.cat_usuarios us
		  ON tb.tsb_usuariosolicita = us.usu_idusuario
		JOIN [ControlAplicaciones].[dbo].[cat_empresas] emp
		  ON tb.tsb_idempresa = emp.emp_idempresa
		JOIN Tramites..personaTramite pt
		  ON tl.idPerTra = pt.id_perTra
		WHERE tl.idPerTra = @idPerTra),
	  origen
	  AS
	  (SELECT
		  b.nombre AS bancoOrigen
		 ,t.idEmpresa
		 ,bc.numeroCuenta
		FROM referencias.dbo.BancoCuenta bc
		JOIN transferencia t
		  ON bc.idEmpresa = t.idEmpresa
		  AND bc.cuentaContable = t.cuentaOrigen
		JOIN referencias.dbo.banco b
		  ON bc.idBanco = b.idBanco),
	  destino
	  AS
	  (SELECT
		  b.nombre AS bancoDestino
		 ,t.idEmpresa
		 ,bc.numeroCuenta
		FROM referencias.dbo.BancoCuenta bc
		JOIN transferencia t
		  ON bc.idEmpresa = t.idEmpresa
		  AND bc.cuentaContable = t.cuentaDestino
		JOIN referencias.dbo.banco b
		  ON bc.idBanco = b.idBanco)
	  SELECT
		t.idEmpresa
	   ,t.nomEmpresa
	   ,t.idtransferencia
	   ,t.cuentaOrigen AS cuentaContableOrigen
	   ,t.cuentaDestino AS CuentaContableDestino
	   ,t.nombreSolicitante
	   ,t.email
	   ,t.importe
	   ,t.fechaSolicita
	   ,o.bancoOrigen
	   ,d.bancoDestino
	   ,o.numeroCuenta AS cuentaOrigen
	   ,d.numeroCuenta AS cuentaDestino
	   ,t.esDe_IdEstatus
	   ,t.fechaAtencion AS fechaAtencion--convert(varchar (20),GETDATE(),120) as fechaAtencion
	   ,t.fechaAutorizadaRechazada
	   ,t.petr_observaciones AS observaciones
	   ,t.idPerTraFFyGV
	   ,tiposalida = @tipoSalida
	   ,idPerTraSolicitante = @idPerTraFFyGV
	    ,t.consecutivo
		 ,idTramiteSolicitud = @idtramiteOriginal
	  FROM transferencia t
	  JOIN origen o
		ON t.idEmpresa = o.idEmpresa
	  JOIN destino d
		ON d.idEmpresa = t.idEmpresa
	END
	/*
	  Salida por transferencia en GV
	*/
	IF (@tipoSalida = 5)
	BEGIN
	  ;
	  WITH transferencia
	  AS
	  (SELECT
		  tsb_idempresa AS idEmpresa
		 ,emp_nombre AS nomEmpresa
		 ,tl.idTransferencia
		 ,tsb_cuentaorigen AS cuentaOrigen
		 ,tsb_cuentadestino AS cuentaDestino
		 ,us.usu_nombre + ' ' + usu_paterno + ' ' + usu_materno AS nombreSolicitante
		 ,us.usu_correo AS email
		 ,tsb_importe AS importe
		 ,ISNULL(tb.tsb_fechasolicita, '') AS fechaSolicita
		 ,ISNULL(pt.esDe_IdEstatus, '') AS esDe_IdEstatus
		 ,ISNULL(tl.fechaAtencion, '') AS fechaAtencion
		 ,ISNULL(tl.fechaAutorizadaRechazada, '') AS fechaAutorizadaRechazada
		 ,pt.petr_observaciones
		 ,idPerTraFFyGV = tl.idPerTra
		 ,tl.consecutivo
		FROM Tramites.dbo.traspasosFondoFijoLog tl
		JOIN tramites.dbo.tsb_traspasosaldobancosFondoFijo tb
		  ON tl.idtransferencia = tb.tsb_idtraspasosaldobancos
		JOIN ControlAplicaciones.dbo.cat_usuarios us
		  ON tb.tsb_usuariosolicita = us.usu_idusuario
		JOIN [ControlAplicaciones].[dbo].[cat_empresas] emp
		  ON tb.tsb_idempresa = emp.emp_idempresa
		JOIN Tramites..personaTramite pt
		  ON tl.idPerTra = pt.id_perTra
		WHERE tl.idPerTra = @idPerTra),
	  origen
	  AS
	  (SELECT
		  b.nombre AS bancoOrigen
		 ,t.idEmpresa
		 ,bc.numeroCuenta
		FROM referencias.dbo.BancoCuenta bc
		JOIN transferencia t
		  ON bc.idEmpresa = t.idEmpresa
		  AND bc.cuentaContable = t.cuentaOrigen
		JOIN referencias.dbo.banco b
		  ON bc.idBanco = b.idBanco),
	  destino
	  AS
	  (SELECT
		  b.nombre AS bancoDestino
		 ,t.idEmpresa
		 ,bc.numeroCuenta
		FROM referencias.dbo.BancoCuenta bc
		JOIN transferencia t
		  ON bc.idEmpresa = t.idEmpresa
		  AND bc.cuentaContable = t.cuentaDestino
		JOIN referencias.dbo.banco b
		  ON bc.idBanco = b.idBanco)
	  SELECT
		t.idEmpresa
	   ,t.nomEmpresa
	   ,t.idtransferencia
	   ,t.cuentaOrigen AS cuentaContableOrigen
	   ,t.cuentaDestino AS CuentaContableDestino
	   ,t.nombreSolicitante
	   ,t.email
	   ,t.importe
	   ,t.fechaSolicita
	   ,o.bancoOrigen
	   ,d.bancoDestino
	   ,o.numeroCuenta AS cuentaOrigen
	   ,t.cuentaDestino AS cuentaDestino
	   ,t.esDe_IdEstatus
	   ,t.fechaAtencion AS fechaAtencion--convert(varchar (20),GETDATE(),120) as fechaAtencion
	   ,t.fechaAutorizadaRechazada
	   ,t.petr_observaciones AS observaciones
	   ,t.idPerTraFFyGV
	   ,tiposalida = @tipoSalida
	   ,idPerTraSolicitante = @idPerTraFFyGV
	   ,t.consecutivo
	   ,idTramiteSolicitud = @idtramiteOriginal
	  FROM transferencia t
	  JOIN origen o
		ON t.idEmpresa = o.idEmpresa
	  LEFT JOIN destino d
		ON d.idEmpresa = t.idEmpresa
	END


END
go

