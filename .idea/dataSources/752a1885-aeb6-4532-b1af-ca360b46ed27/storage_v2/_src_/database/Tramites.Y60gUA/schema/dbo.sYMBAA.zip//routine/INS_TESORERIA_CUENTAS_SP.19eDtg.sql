CREATE PROCEDURE [dbo].[INS_TESORERIA_CUENTAS_SP]
@idPerTra INT
AS
BEGIN

		-- identificar la fecha del tramite
		IF EXISTS(select 1 from personaTramite WHERE id_perTra = @idPerTra AND petr_fechaTramite < CONVERT(DATETIME,'04-07-2020',103) )
		BEGIN
			Print 'Viejo'
			EXEC [dbo].[INS_TESORERIA_CUENTAS_ANT_SP] @idPerTra
		END
		ELSE
		BEGIN
			Print 'Nuevo'
			EXEC [dbo].[INS_TESORERIA_CUENTAS_ORIGEN_PAGO_SP] @idPerTra
		END
	
END

go

