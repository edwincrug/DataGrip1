-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <02/09/2019>
-- Description:	<Almacena el empleado>
--TEST EXEC  [Tramite].[Sp_Tramite_Empleado_INS] 
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_Empleado_INS] 
	@idEmpleado INT,
	@nombreEmpleado VARCHAR(50),
	@idEstatus INT,
	@idTramiteDevolucion INT,
	@idPersona INT = 0
AS
BEGIN 

	SET NOCOUNT ON;
	
	DECLARE @idPerTra INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_AnticipoSaldo_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite
		INSERT INTO [Tramite].[TramiteEmpleado]
           ([idEmpleado]
           ,[nombreEmpleado]
           ,[fechaRegistro]
           ,[idEstatus]
		   ,[idTramiteDevolucion]
		   ,[IdPersona])
		VALUES 
			(@idEmpleado
           ,@nombreEmpleado
           ,GETDATE()
           ,@idEstatus
		   ,@idTramiteDevolucion
		   ,@idPersona)
		   
		SET @idPerTra = SCOPE_IDENTITY()

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH

	SET NOCOUNT OFF
	
	SELECT @idPerTra AS [resultado]
END
go

