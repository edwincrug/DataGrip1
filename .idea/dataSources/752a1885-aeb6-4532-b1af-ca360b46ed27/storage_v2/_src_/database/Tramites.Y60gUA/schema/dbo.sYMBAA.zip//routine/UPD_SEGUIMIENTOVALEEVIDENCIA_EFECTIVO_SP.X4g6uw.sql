-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <23/10/2019>
-- Description:	<SP que actualiza el estatus de la evidencia del vale>
-- [dbo].[UPD_SEGUIMIENTOVALEEVIDENCIA_SP]  85
-- =============================================
CREATE PROCEDURE [dbo].[UPD_SEGUIMIENTOVALEEVIDENCIA_EFECTIVO_SP] 
	@idVale INT,
	@monto DECIMAL(18,2)
AS
BEGIN
	

	----Actualiar Vales----
	UPDATE Tramite.vales
	SET montoJustificado = montoJustificado + @monto, estatusVale = CASE WHEN (montoJustificado + @monto) >= montoSolicitado THEN 4 ELSE estatusVale END
	WHERE id = @idVale

	
	

	SELECT success = 1, msg = 'Se actualizo correctamente';

END
go

