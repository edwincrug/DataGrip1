-- =============================================
-- Author:		<Author,,Name>
 --Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ORDENES_COMPRA_TRANSFERENCIA_GV]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	 DECLARE @CountBases INT = 1, 
				@registos INT = 0, 
				@base varchar (200),
				@idComprobacionVale varchar(100),
				@SQLAgencia NVARCHAR(MAX) 
 
 DECLARE @db TABLE (id int identity(1,1),id_empresa int, id_sucursal int, base varchar(25), respondable int, idTramiteConcepto int, dep_nombrecto varchar(10), compNoAutorizado int, id_perTra int, documentoOrigen  VARCHAR(50), monto DECIMAL(18,2))
 
 INSERT INTO @db
 SELECT DISTINCT td.id_empresa
  , td.id_sucursal
  , e.emp_nombrebd
  , pt.id_persona as respondable 
  , tc.idTramiteConcepto
  , dep.dep_nombrecto
  , 0
  , pt.id_perTra
  , tc.documentoConcepto
  , SUM(ti.importe) OVER(PARTITION BY td.id_perTra) 
from Tramite.TramiteConcepto tc
inner join tramiteDevoluciones td on td.id_perTra = tc.idTramitepersona
inner join personaTramite pt on pt.id_perTra =  td.id_perTra
inner join ControlAplicaciones.dbo.cat_empresas e on e.emp_idempresa = td.id_empresa
inner join ControlAplicaciones.dbo.cat_departamentos dep ON dep.dep_iddepartamento = td.id_departamento
JOIN Tramite.TramiteImporte ti
  ON tc.idTramiteConcepto = ti.idTramiteConcepto
  AND ti.idTipoProceso = 2
where tc.procesoPoliza IS NULL
AND tc.idSalidaEfectivo = 3


SET @registos = (select COUNT(1) from @db)

WHILE (@CountBases<= @registos) BEGIN  

  SELECT 
  @base = base
  FROM @db 
  WHERE id = @CountBases


  SET @SQLAgencia = 'select  CAST( SUBSTRING(co.odm_observaciones,CHARINDEX('': '', co.odm_observaciones)+2, LEN(co.odm_observaciones)-(CHARINDEX('': '', co.odm_observaciones)+1)) AS INT) AS idperTra
   ,odm_ordencompra
   ,odm_idordenmasiva
  from ['+@base+'].dbo.cxp_ordenesmasivas co
  where  co.odm_sinflujoiva = 1
  AND co.odm_observaciones LIKE ''%: %''
'	

  print 	@SQLAgencia
	DECLARE @pedidos TABLE (idPertra varchar(100), ordencompra varchar(100), ordenesMasivas int);
  
  INSERT INTO @pedidos
  EXECUTE(@SQLAgencia)
  
  SET @CountBases= @CountBases+1 
	
END

	

SELECT distinct idPertra
      ,ordencompra
  ,d.id_empresa
  ,d.id_sucursal as idsucursal
  ,d.documentoOrigen
  ,d.monto
  ,ordenesMasivas
  FROM @pedidos p
  JOIN @db d
    ON p.idPertra = d.id_perTra
	where ordencompra is not null


END
go

