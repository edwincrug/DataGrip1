-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: 11-07-2020
-- Description:	OBTENEMOS LOS TRAMITES QUE YA ESTAN EN APROBACION
-- SEL_OBTIENE_COMPROBANTES_GV_APROBADOS 4, 'localhost'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENE_COMPROBANTES_GV_APROBADOS]
	-- Add the parameters for the stored procedure here
	@idTipoProceso INT = 4,
	@urlParametro VARCHAR(80)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	DECLARE @urlDoctos VARCHAR(100)
		   ,@correosTesoreria VARCHAR(MAX)
	DECLARE @parmetros TABLE (
	  nombreTabla VARCHAR(255)
	 ,correosTesoreria VARCHAR(MAX)
	)

	IF (@urlParametro != ''
	  AND @urlParametro = 'localhost') --localhost
	BEGIN
	  SELECT
		@urlDoctos = pr_descripcion
	  FROM [dbo].[parametros]
	  WHERE pr_identificador = 'Url_Local_ADG'
	END
	ELSE
	IF (@urlParametro != '')
	BEGIN
	  --SET @urlDoctos = 'C:/app/public/Imagenes/AnticipoGastos/';   --'C:\\app\\public\\Imagenes\\AnticipoGastos\'
	  SELECT
		@urlDoctos = pr_descripcion --+ 'AnticipoGastos/'
	  FROM parametros
	  WHERE pr_identificador = 'Url_Server_ADG'
	END

	INSERT INTO @parmetros
	EXEC [dbo].[OBTIENE_PARAMETROS] 'parametrosGV'

	SELECT
	  @correosTesoreria = correosTesoreria
	FROM @parmetros

	SELECT distinct
	  TD.id_perTra AS [id]
	 ,tti.idTipoProceso
	 ,TD.traDe_fechaInicio AS [fechaInicio]
	 ,TD.traDe_fechaFin AS [fechaFin]
	 ,TD.concepto as viajeA
	 ,ET.esDe_IdEstatus AS [idEstatus]
	 ,ET.esDe_descripcion AS [estatus]
	 ,TD.traDe_Observaciones AS [observaciones]
	 ,TD.motivo
	 ,TD.nombreCliente
	 ,ET.esDe_icono AS [icono]
	 ,COALESCE(SUM(TTI.importe), 0) AS [importe]
	 ,COALESCE([TD].[id_empresa], 0) AS [idCompania]
	 ,COALESCE([TD].[id_sucursal], 0) AS [idSucursal]
	 ,COALESCE([TD].[id_departamento], 0) AS [idDepartamento]
	 ,CD.dep_nombrecto
	 ,COALESCE(CE.emp_nombre, '') AS [empresa]
	 ,COALESCE(CS.suc_nombre, '') AS [sucursal]
	 ,COALESCE(CD.dep_nombre, '') AS [departamento]
	 ,@urlDoctos AS urlServerDoctos
	 ,(SELECT
		  MIN(ISNULL(idSalidaEfectivo, 0))
		FROM [Tramite].[TramiteConcepto]
		WHERE idTramitePersona = TD.id_perTra
		AND idEstatus <> 3)
	  AS Comprobar
	 ,ISNULL(TD.PER_IDPERSONA, 0) AS PER_IDPERSONA
	 ,@correosTesoreria AS correoTesoreria
	 ,TD.cuentaBancaria
	 ,TD.numeroCLABE
	 ,tec.idSalidaEfectivo
	 ,ISNULL(ca.ca_banconombre, '') AS ca_banconombre
	 ,ISNULL(ca.ca_clabe, '') AS ca_clabe
	 ,ISNULL(ca.idCuentaAutorizada, 0) AS idCuentaAutorizada
	 ,ISNULL(te.IdPersona, 0) AS idUsuarioAdicional
	 ,isnull(cusol.usu_idusuario, 0) as idEmpleadoAdicional
	 ,ISNULL(te.nombreEmpleado, '') AS nombreEmpleadoAdicional
	 ,cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno AS usuario
	 , case when ISNULL(te.nombreEmpleado, '') = '' then cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno else te.nombreEmpleado end as solicitante
	 , TTI2.idUsuario
	 ,cusol.usu_idusuario as idSolicitante
	 ,pp.PER_IDPERSONA as idpersona
	 ,cuAuto.usu_nombre + ' ' + cuAuto.usu_paterno + ' ' + cuAuto.usu_materno as autorizador
	 ,cuAuto.usu_nombreusu as idAutorizador--cuAuto.usu_idusuario as idAutorizador
	 , convert(varchar(10), cast(dev.fecha as date),103 ) as fechaRegistroDevolucion
	 , dev.idConceptoArchivo as idDevolucion
	FROM tramiteDevoluciones TD
	INNER JOIN personaTramite PT
	  ON PT.id_perTra = TD.id_perTra
	LEFT JOIN cat_tramites T
	  ON T.id_tramite = PT.id_tramite
	INNER JOIN cat_proceso_estatus ET
	  ON ET.esDe_IdEstatus = PT.petr_estatus
		AND ET.idTipoTramite = 9
	LEFT JOIN [Tramite].[TramiteEmpleado] TE
	  ON TD.id_perTra = TE.idTramiteDevolucion
	LEFT JOIN [Tramite].[TramiteConcepto] TEC
	  ON PT.id_perTra = TEC.idTramitePersona
	LEFT JOIN [Tramite].[TramiteImporte] TTI
	  ON TEC.idTramiteConcepto = TTI.idTramiteConcepto
		AND TTI.idTipoProceso = @idTipoProceso
	LEFT JOIN [ControlAplicaciones].[dbo].[cat_empresas] CE
	  ON [TD].[id_empresa] = CE.emp_idempresa
	LEFT JOIN [ControlAplicaciones].[dbo].[cat_sucursales] CS
	  ON CS.suc_idsucursal = [TD].[id_sucursal]
	LEFT JOIN ControlAplicaciones.dbo.cat_departamentos CD
	  ON CD.dep_iddepartamento = [TD].[id_departamento]
	LEFT JOIN [Tramites].[dbo].[cuentaAutorizada] ca
	  ON pt.id_perTra = ca.id_perTra
		AND ca.ca_estatus = 3
	LEFT JOIN ControlAplicaciones..cat_usuarios cu
	  ON pt.id_persona = cu.usu_idusuario
	LEFT JOIN [Tramite].[TramiteImporte] TTI2
	ON TEC.idTramiteConcepto = TTI2.idTramiteConcepto
		AND TTI2.idTipoProceso = 2
	left join usuariosGastosViaje ugv
		on cu.usu_idusuario = ugv.idUsuario
	LEFT join GA_Corporativa..PER_PERSONAS pp
		on ugv.idPersona = pp.PER_IDPERSONA
		--on pp.PER_NOMRAZON+' '+pp.PER_PATERNO+' '+pp.PER_MATERNO =  case when ISNULL(te.nombreEmpleado, '') = '' then cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno else te.nombreEmpleado end COLLATE Modern_Spanish_CI_AS
	left join ControlAplicaciones.dbo.cat_usuarios cusol
	on ugv.idUsuario = cusol.usu_idusuario
		--on ce.emp_idempresa = cusol.emp_idempresa
		--and ugv.idUsuario = cusol.usu_idusuario
		--and cs.suc_idsucursal = cusol.suc_idsucursal
		--and cd.dep_iddepartamento = cusol.dep_iddepartamento
		--and  cusol.usu_nombre +' ' +cusol.usu_paterno+ ' '+ cusol.usu_materno = case when ISNULL(te.nombreEmpleado, '') = '' then cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno else te.nombreEmpleado end
	left join Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO dej
	on cusol.usu_idusuario = dej.idUsuario
	and dej.idtipoNotificacionJeraquizada = 1
	left join Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO dejsup
	on dej.idPadre = dejsup.id
	and dejsup.idtipoNotificacionJeraquizada = 1
	left join ControlAplicaciones..cat_usuarios cuAuto
	on dejsup.idUsuario = cuAuto.usu_idusuario
	left join Tramite.ConceptoArchivo dev
		on td.id_perTra = dev.idReferencia
		and dev.tipoDevolucion > 0
	WHERE TTI.idTipoProceso = @idTipoProceso --TD.id_perTra = @idAnticipoGasto
	GROUP BY TD.id_perTra
			,TD.traDe_devTotal
			,TD.traDe_fechaInicio
			,TD.traDe_fechaFin
			,TD.cuentaBancaria
			,TD.numeroCLABE
			,TD.concepto
			,ET.esDe_IdEstatus
			,ET.esDe_descripcion
			,TD.traDe_Observaciones
			,TD.motivo
			,[TD].[id_empresa]
			,[TD].[id_sucursal]
			,[TD].[id_departamento]
			,CE.emp_nombre
			,CS.suc_nombre
			,CD.dep_nombre
			,TD.nombreCliente
			,ET.esDe_icono
			,CD.dep_nombrecto
			,TD.PER_IDPERSONA
			,tec.idSalidaEfectivo
			,ca.ca_banconombre
			,ca.ca_clabe
			,ca.idCuentaAutorizada
			,te.nombreEmpleado
			,cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno
			,te.IdPersona
			,cusol.usu_idusuario
	,tti.idTipoProceso
	 , TTI2.idUsuario
	,case when ISNULL(te.nombreEmpleado, '') = '' then cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno else te.nombreEmpleado end
	,cuAuto.usu_nombre + ' ' + cuAuto.usu_paterno + ' ' + cuAuto.usu_materno 
	 ,cuAuto.usu_idusuario 
	  , dev.fecha
	 , dev.idConceptoArchivo
	 ,cuAuto.usu_nombreusu
	 ,pp.PER_IDPERSONA 
	order by 1 desc
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
	SET NOCOUNT OFF;
END
go

