-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <09/10/2019>
-- Description:	<Recupera la descripción del gasto de una sucursal>
--TEST EXEC  [Tramite].[Sp_Tramite_CuentaContable_GETLByConcepto] 9,18, 'AADM',62
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_CuentaContable_GETLByConcepto] 
	@idEmpresa INT,
	@idSucursal INT,
	@CNC_CONCEPTO1 VARCHAR(50),
	@CNC_CONCEPTO2 VARCHAR(50)

AS
BEGIN 
	SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
	
	DECLARE @nombreBase VARCHAR(30) = '',
	@query VARCHAR(MAX) = ''

	SELECT 
		@nombreBase = suc_nombrebd 
	FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

	SET @query = 'SELECT TOP 1 CNC_ID, CNC_CUENTA FROM [' + @nombreBase + '].[DBO].[CON_CONFCONTA] WHERE CNC_CONFIGURA = ''PEDIDOS ESPECIALES'' 
	AND CNC_CONCEPTO = ''COMPRA'' AND CNC_CONCEPTO1 = ''' + @CNC_CONCEPTO1 + ''' AND CNC_CONCEPTO2 = ' + @CNC_CONCEPTO2
	print @query
	EXECUTE (@query)

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    SET NOCOUNT OFF;
END
go

