-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Tramite].[Sp_Tramite_Cuenta_Search_GETL] '002000000000000210'
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_Cuenta_Search_GETL]
	-- Add the parameters for the stored procedure here
	@busqueda VARCHAR(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- DECLARE @busqueda VARCHAR(20) = '006%200'

	SELECT TOP (1000) [idCuentaAutorizada]
		  ,[ca_clabe] CLABE
		  ,[ca_cuenta] cuenta
		  ,[ca_banconombre] banco
		  ,[ca_plaza] plaza
		  ,[ca_sucursal] sucursal
		  ,[ca_estatus] estatus
		  ,[ca_fecha] fecha
		  ,[idEmpresa] 
		  ,[idPersona]
		  ,CA.[id_perTra]
		  ,usu_nombre + ' ' + usu_paterno + ' ' + usu_materno nombre
		  ,usu_correo correo
	  FROM [Tramites].[dbo].[cuentaAutorizada] CA
	  INNER JOIN personaTramite PT ON CA.id_perTra = PT.id_perTra
	  INNER JOIN ControlAplicaciones..cat_usuarios USU ON USU.usu_idusuario = idPersona
	  WHERE ca_estatus = 3
			AND (
				ca_clabe LIKE '%' + @busqueda + '%'
				OR ca_cuenta LIKE '%' + @busqueda + '%'
				OR idPersona LIKE '%' + @busqueda + '%'
			)
END
go

