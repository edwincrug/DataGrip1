-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <17/10/2019>
-- Description:	<SP que trae los datos de los FF x usuario>
-- SEL_TIPOUSUARIOFONDOFIJOREEMBOLSO_SP 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOUSUARIOFONDOFIJOREEMBOLSO_SP] 
	@idUsuario INT
AS
BEGIN
	  
	SELECT
	idUsuario,
	idUsuariosFondoFijo as tipoUsuarioFF
	FROM [Tramite].[UsuariosFondoFijo]
	WHERE idUsuario = @idUsuario and idUsuariosFondoFijo in(5,6,7)

END

go

