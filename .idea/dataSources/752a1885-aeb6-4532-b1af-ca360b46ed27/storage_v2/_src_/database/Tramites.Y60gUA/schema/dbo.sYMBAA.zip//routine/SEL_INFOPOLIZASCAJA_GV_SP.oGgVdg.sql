
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <13/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [dbo].[SEL_INFOPOLIZASCAJA_FFGV_SP]  1280
-- =============================================
CREATE PROCEDURE [dbo].[SEL_INFOPOLIZASCAJA_GV_SP] 
	@id_perTra INT 
AS
BEGIN

select 
tff.tsb_usuarioSolicita as idUsuario, 
td.id_sucursal as idSucursal, 
'' as idAnticipo, 
tff.tsb_importe as monto,
td.id_perTra  as id_perTraGV,
tff.tsb_cuentadestino as cuentaContableEntrada, 
tff.tsb_cuentaorigen as cuentaContableSalida, 
'' as cuentaContable,
d.dep_nombrecto,
0 as esReembolso,
'GV' as tramite,
u.usu_correo as correo
from traspasosFondoFijoLog  tffl
inner join tsb_traspasosaldobancosFondoFijo tff on tff.tsb_idtraspasosaldobancos = tffl.idtransferencia
inner join tramiteDevoluciones td on td.id_perTra = tffl.idPerTraFFyGV
inner join personaTramite pt on pt.id_perTra = td.id_perTra
inner join controlaplicaciones.dbo.cat_departamentos d on d.dep_iddepartamento = td.id_departamento
inner join controlaplicaciones.dbo.cat_usuarios u on u.usu_idusuario = pt.id_persona
where tffl.idPerTra = @id_perTra

END

go

