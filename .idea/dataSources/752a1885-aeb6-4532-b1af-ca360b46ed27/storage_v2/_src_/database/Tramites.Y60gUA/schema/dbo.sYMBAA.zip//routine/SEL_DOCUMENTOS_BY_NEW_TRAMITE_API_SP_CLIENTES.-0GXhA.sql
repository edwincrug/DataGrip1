-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/06/2019>
-- Description:	<Se guardan los documentos del tramite>
-- Test [SEL_DOCUMENTOS_BY_NEW_TRAMITE_API_SP_CLIENTES] 3
-- =============================================


CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_BY_NEW_TRAMITE_API_SP_CLIENTES] 
	 @idTramite INT
AS
BEGIN
	


	SELECT T.id_tramite,doc_nomDocumento, TD.id_traDo,TD.id_documento, EXT.ext_nombre ,  DOC.doc_infoAdicional, doc_expira , 0 AS existe,DOC.opcional from cat_tramites T
	INNER JOIN cat_tramiteDocumento TD ON TD.id_tramite = T.id_tramite
	INNER JOIN cat_documentos DOC ON DOC.id_documento = TD.id_documento
	INNER JOIN cat_extensiones EXT ON EXT.id_extension = DOC.id_extension
	WHERE T.id_tramite = @idTramite AND DOC.doc_subeUsuarioRol <> 4 and DOC.doc_subeUsuarioRol <> 7


END
go

