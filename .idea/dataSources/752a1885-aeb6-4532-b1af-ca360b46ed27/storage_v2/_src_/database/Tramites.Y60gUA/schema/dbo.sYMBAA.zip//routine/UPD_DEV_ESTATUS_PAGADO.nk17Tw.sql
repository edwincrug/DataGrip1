-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <03/10/2019>
-- Description:	<SP que actualiza el campo esDe_IdEstatus en la tabla tramiteDevoluciones para que pase a pagado>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_DEV_ESTATUS_PAGADO]
AS
BEGIN
	UPDATE TD
		SET TD.esDe_IdEstatus = 6
	FROM documentosDevueltos DD
	INNER JOIN GA_Corporativa.DBO.cxc_devoluciones D ON DD.id_traDe = D.CDE_AGRUPADOR AND DD.docDe_documento = D.cde_iddocto
	INNER JOIN tramiteDevoluciones TD ON TD.id_traDe = DD.id_traDe
	INNER JOIN cuentasxpagar.DBO.cxp_doctospagados DP ON DP.dpa_iddocumento = D.cde_foliogenerado
	WHERE D.CDE_AGRUPADOR IS NOT NULL AND TD.esDe_IdEstatus = 5

		INSERT INTO [dbo].[logJobProcesado]
           ([fechaEjecucion])
     VALUES
           (GETDATE())

END

go

