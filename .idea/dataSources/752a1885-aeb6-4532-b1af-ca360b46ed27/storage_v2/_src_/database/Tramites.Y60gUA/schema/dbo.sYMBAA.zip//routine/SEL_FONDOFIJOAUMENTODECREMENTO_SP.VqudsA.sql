
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <16/10/2019>
-- Description:	<SP que trae los datos de los FF x usuario>
-- SEL_FONDOFIJOAUMENTODECREMENTO_SP 1264
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJOAUMENTODECREMENTO_SP] 
	@idtramite INT
AS
BEGIN

select 
ffc.id,
case when ffc.aumentoDecrementoFF = 1 then 'Aumento' else 'Decremento' end as tipo,
case when ffc.estatus = 1 then 'Autorizado' 
	when  ffc.estatus = 2 then 'Rechazado'
	else 'Pendiente' end as estatus,
ffc.montoInicial as montoI,
ffc.montoCambiado as montoS,
CONVERT(varchar, ffc.fechaCambio, 103) as fechaCambio,
'' as [url]
from Tramite.fondoFijo ff
inner join Tramite.fondoFijoCambios ffc on ff.id = ffc.idtablafondofijo
where ff.id_perTra = @idtramite
order by ffc.id desc 

END

go

