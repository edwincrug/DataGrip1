-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_NOTIFICACION_pARAMETROS_FAC_GV]
	@idTramite int = 1207
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   
	DECLARE @idNotificacion INT= 0



    -- Insert statements for procedure here
	SELECT top 1
	@idNotificacion = ISNULL(not_id,0)
	FROM notificacion.dbo.NOT_NOTIFICACION
	WHERE not_identificador = CAST(@idTramite AS VARCHAR(50))
	and not_estatus = 2
	AND not_agrupacion = 50
	order by not_id desc

	IF(@idNotificacion > 0)
	BEGIN
		SELECT
		idAprobacion = ISNULL(apr_id,-1)
		,identificador = ISNULL(not_id,-1)
		,idUsuarioAuto = emp_id
		FROM notificacion.[dbo].[NOT_APROBACION]
		WHERE not_id = @idNotificacion
		AND apr_estatus = 2 --apr_id = 491065
	END
	ELSE
	BEGIN
		SELECT idAprobacion = -1
				,identificador = -1

	END
END
go

