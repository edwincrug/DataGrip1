-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <02/07/2019>
-- Description:	<Regresa los tramites de devoluciones por usuario>
-- Modified By:		<Mauricio Salgado>
-- Create date: <19/09/2019>
-- Description:	<Se agrega el tipo de tramite 9 en PE.idTipoTramite IN (4, 9) antes: PE.idTipoTramite = 4>
-- Modified By:	 <Juan Carlos Peralta>
-- Create date: <06/11/2019>
-- Description:	<Se agrega el tipo de tramite 10 y busca por Area en caso de que sea un perfil de tipo 9>
--TEST SEL_DEV_MISTRAMITES_SP 1993
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEV_MISTRAMITES_SP_FINALIZADOS]
	@idUsuario INT
AS
BEGIN

DECLARE @idRol INT, @idArea INT
SELECT 
	@idRol = idRol, 
	@idArea = id_area 
FROM usuarioRol where idUsuario = @idUsuario

IF (@idRol = 16)
BEGIN
	SELECT DISTINCT 
		TD.id_traDe,
		CASE WHEN PT.petr_estatus IN (2, 3, 5,14) THEN ET.est_nombre 
		ELSE 
		CASE WHEN PT.id_tramite = 4 THEN PED.esDe_descripcion 
		WHEN PT.id_tramite = 10 THEN PFF.esDe_descripcion 
		ELSE PEA.esDe_descripcion END END AS est_nombre,
		PT.id_perTra,
		CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
		T.tra_nomTramite,
		T.id_tramite,
		CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
		PT.petr_estatus
	FROM  tramiteDevoluciones TD
	INNER JOIN personaTramite PT ON PT.id_perTra = TD.id_perTra
	INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
	INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
	LEFT JOIN cat_proceso_estatus PED ON PED.esDe_IdEstatus = TD.esDe_IdEstatus AND PED.idTipoTramite = 4
	LEFT JOIN cat_proceso_estatus PEA ON PEA.esDe_IdEstatus = TD.esDe_IdEstatus AND PEA.idTipoTramite = 9
	LEFT JOIN cat_proceso_estatus PFF ON PFF.esDe_IdEstatus = TD.esDe_IdEstatus AND PFF.idTipoTramite = 10
	LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PT.id_perTra 
	WHERE T.id_area = @idArea and T.id_tramite = 10 AND PT.petr_estatus IN (2, 3)
	ORDER BY PT.id_perTra DESC
END
	ELSE
		BEGIN
			SELECT DISTINCT 
				TD.id_traDe,
				CASE WHEN PT.petr_estatus IN (2, 3, 5,14) THEN ET.est_nombre 
				ELSE 
				CASE WHEN PT.id_tramite = 4 THEN PED.esDe_descripcion 
				WHEN PT.id_tramite = 10 THEN PFF.esDe_descripcion 
				ELSE PEA.esDe_descripcion END END AS est_nombre,
				PT.id_perTra,
				CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
				T.tra_nomTramite,
				T.id_tramite,
				CASE WHEN cuantos > 0 THEN 1 ELSE 0 END AS noti,
				PT.petr_estatus,
				PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO as PER_PERSONA,
				CASE WHEN DTR.cuantosRevisar > 0 THEN 1 ELSE 0 END AS notiRevisar,
				CASE WHEN DTA.cuantosAprobados = (SELECT COUNT(det_idPerTra) FROM detallePersonaTramite WHERE id_perTra = PT.id_perTra) THEN 1 ELSE 0 END notiDocsAprobar
			FROM  tramiteDevoluciones TD
			INNER JOIN personaTramite PT ON PT.id_perTra = TD.id_perTra
			INNER JOIN cat_tramites T ON T.id_tramite = PT.id_tramite
			INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
			LEFT JOIN cat_proceso_estatus PED ON PED.esDe_IdEstatus = TD.esDe_IdEstatus AND PED.idTipoTramite = 4
			LEFT JOIN cat_proceso_estatus PEA ON PEA.esDe_IdEstatus = TD.esDe_IdEstatus AND PEA.idTipoTramite = 9
			LEFT JOIN cat_proceso_estatus PFF ON PFF.esDe_IdEstatus = TD.esDe_IdEstatus AND PFF.idTipoTramite = 10
			LEFT JOIN (SELECT COUNT(det_idPerTra) cuantos, id_perTra FROM detallePersonaTramite WHERE det_estatus = 3 GROUP BY id_perTra)  DT ON DT.id_perTra = PT.id_perTra
			LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosRevisar, id_perTra FROM detallePersonaTramite WHERE det_estatus = 1 GROUP BY id_perTra) DTR ON DTR.id_perTra = PT.id_perTra 
			LEFT JOIN (SELECT COUNT(det_idPerTra) cuantosAprobados, id_perTra FROM detallePersonaTramite WHERE det_estatus = 2 GROUP BY id_perTra) DTA ON DTA.id_perTra = PT.id_perTra
			INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] PER ON PER.PER_IDPERSONA = TD.PER_IDPERSONA
			WHERE PT.id_persona = @idUsuario AND PT.petr_estatus IN (2, 3,14) AND PT.id_tramite not in (16) 
			ORDER BY PT.id_perTra DESC
		END
END

go

