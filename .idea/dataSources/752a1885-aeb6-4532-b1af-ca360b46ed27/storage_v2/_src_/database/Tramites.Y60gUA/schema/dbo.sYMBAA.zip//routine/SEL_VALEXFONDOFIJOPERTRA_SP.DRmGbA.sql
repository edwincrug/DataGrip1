-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <17/10/2019>
-- Description:	<SP que trae los datos de los FF x usuario>
-- [dbo].[SEL_VALEXFONDOFIJOPERTRA_SP]   1336
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALEXFONDOFIJOPERTRA_SP] 
	@id_perTra INT
AS
BEGIN
	 --DECLARE @url varchar(max)
	 --SELECT @url = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'

--	 	DECLARE @url VARCHAR(500);
--		SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');		
--		DECLARE @saveUrl VARCHAR(100) = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC');
--SELECT
-- V.id as idVale,
-- V.idVale  as nombreVale,
-- U.usu_nombre + ' ' + U.usu_paterno  + ' ' + U.usu_materno as responsble,
-- FF.idFondoFijo,
-- CONVERT(varchar, V.fechaCreacionVale, 103) as fechaCreacion,
-- V.montoSolicitado,
-- V.montoJustificado as Justificar,
-- V.estatusVale as idestatus,
-- V.comentario,
-- EV.descripcion as estatus,
-- V.descripcion as razon,
-- GFF.descripcion as tipoTramite,
-- @saveUrl as saveUrl,
-- FF.id_perTra,
-- CASE WHEN V.estatusVale = 1 THEN ''
-- ELSE @url + 'FondoFijo' + '/FondoFijo_' + CONVERT(VARCHAR(20), FF.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), V.id) + '/AutorizacionVale_' + CONVERT(VARCHAR(20), V.id) + '.pdf' END as rutaAutorizado,
-- --SUC.suc_nombre,
-- DEP.dep_nombre,
-- DEP.dep_nombrecto,
-- FF.idSucursal,
-- (select count(idvales) from Tramite.valesEvidencia where idvales= v.id) as numEvidencias,
-- (select sum(monto) from Tramite.valesEvidencia where idvales= v.id and idestatus = 1) as montoEvidencias
-- ,P.PER_NOMRAZON + ' ' + P.PER_PATERNO + ' ' +  P.PER_MATERNO as nombrePersona
--  ,v.idDepartamento
-- FROM Tramite.vales V
--INNER JOIN Tramite.valesFondoFijo VF ON VF.idVales = V.id
--INNER JOIN Tramite.fondoFijo FF ON FF.id = VF.idTablaFondoFijo
--INNER JOIN [Tramite].[cat_estatusVale] EV ON EV.id = V.estatusVale
--LEFT JOIN [Tramite].[cat_gastosFondoFijo] GFF ON V.idGastosFondoFijo = GFF.id
--INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = V.idEmpleado
----INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON SUC.suc_idsucursal = FF.idSucursal
--INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON DEP.dep_iddepartamento = FF.idDepartamento
--LEFT JOIN [GA_Corporativa].dbo.PER_PERSONAS P ON P.PER_IDPERSONA = V.PER_IDPERSONA
--WHERE FF.id_perTra = @id_perTra 
--ORDER BY V.id DESC

DECLARE @url VARCHAR(500);
		SET @url = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');		
		DECLARE @saveUrl VARCHAR(100) = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC');
SELECT
 V.id as idVale,
 V.idVale  as nombreVale,
 U.usu_nombre + ' ' + U.usu_paterno  + ' ' + U.usu_materno as responsble,
 FF.idFondoFijo,
 CONVERT(varchar, V.fechaCreacionVale, 103) as fechaCreacion,
 V.montoSolicitado,
 V.montoJustificado as Justificar,
 V.estatusVale as idestatus,
 V.comentario,
 EV.descripcion as estatus,
 V.descripcion as razon,
 GFF.descripcion as tipoTramite,
 @saveUrl as saveUrl,
 FF.id_perTra,
 CASE WHEN V.estatusVale = 1 THEN ''
 ELSE @url + 'FondoFijo' + '/FondoFijo_' + CONVERT(VARCHAR(20), FF.id_perTra) + '/Vales_' + CONVERT(VARCHAR(20), V.id) + '/AutorizacionVale_' + CONVERT(VARCHAR(20), V.id) + '.pdf' END as rutaAutorizado,
 --SUC.suc_nombre,
 DEP.dep_nombre,
 case when ISNULL(FF.departamentoAreas,0) = 0 then DEP.dep_nombrecto else 'OT' end as dep_nombrecto,
 FF.idSucursal,
 (select count(idvales) from Tramite.valesEvidencia where idvales= v.id) as numEvidencias,
 (select sum(monto) from Tramite.valesEvidencia where idvales= v.id and idestatus = 1) as montoEvidencias
 ,P.PER_NOMRAZON + ' ' + P.PER_PATERNO + ' ' +  P.PER_MATERNO as nombrePersona
 ,v.idDepartamento
 FROM Tramite.vales V
INNER JOIN Tramite.valesFondoFijo VF ON VF.idVales = V.id
INNER JOIN Tramite.fondoFijo FF ON FF.id = VF.idTablaFondoFijo
INNER JOIN [Tramite].[cat_estatusVale] EV ON EV.id = V.estatusVale
LEFT JOIN [Tramite].[cat_gastosFondoFijo] GFF ON V.idGastosFondoFijo = GFF.id
INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = V.idEmpleado
--INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON SUC.suc_idsucursal = FF.idSucursal
LEFT JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON DEP.dep_iddepartamento = FF.idDepartamento
LEFT JOIN [GA_Corporativa].dbo.PER_PERSONAS P ON P.PER_IDPERSONA = V.PER_IDPERSONA
WHERE FF.id_perTra = @id_perTra 
ORDER BY V.id DESC



END


go

