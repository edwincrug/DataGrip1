-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <26/09/2019>
-- Description:	<Funcion que separa un string con 6 campos y con pipes>
-- =============================================
CREATE FUNCTION [dbo].[SPLIT_DOCS_6_CAMPOS] (@input AS Varchar(8000))
RETURNS 
@Result TABLE(documento VARCHAR(50), seleccionado VARCHAR(50), valor VARCHAR(50), tipoDoc VARCHAR(100), cartera VARCHAR(50), tipoPago VARCHAR(10))
AS
BEGIN
	IF( LEN(@input) > 0 )
		BEGIN
			DECLARE @str  VARCHAR(50),
					@str1 VARCHAR(50),
					@str2 VARCHAR(50),
					@pos  INT,
					@ind  INT,
					@ind2 INT,
					@contComa INT,
					@str3 VARCHAR(100),
					@str4 VARCHAR(100),
					@str5 VARCHAR(100),
					@str6 VARCHAR(100);

			IF( @input IS NOT NULL )
			BEGIN
				SET @ind = Charindex('|', @input)
				IF @ind > 0
					BEGIN

						WHILE @ind > 0
						BEGIN
							SET @pos= Charindex(',', @input)

							SET @str = @input
							SET @str1 = Substring(@str, 1, @pos - 1)

							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos)
							SET @pos = CHARINDEX(',', @str);
							SET @str2 = Substring(@str, 1, @pos - 1)

							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos)
							SET @pos = CHARINDEX(',', @str);
							SET @str3 = Substring(@str, 1, @pos - 1)

							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos);
							SET @pos = CHARINDEX(',', @str);
							SET @str4 = Substring(@str, 1, @pos - 1)

							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos);
							SET @pos = CHARINDEX(',', @str);
							SET @str5 = Substring(@str, 1, @pos - 1)

							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos);
							SET @pos = CHARINDEX('|', @str)
							SET @str6 = SUBSTRING(@str, 1, @pos - 1)

							INSERT INTO @Result VALUES (@str1, @str2, @str3, @str4, @str5, @str6)

							SET @input = Substring(@input, @ind + 1, LEN(@input) - @ind);
							SET @ind = Charindex('|', @input)

						END
							SET @pos= Charindex(',', @input)

							SET @str = @input
							SET @str1 = Substring(@str, 1, @pos - 1)

							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos)
							SET @pos = CHARINDEX(',', @str);
							SET @str2 = Substring(@str, 1, @pos - 1)

							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos)
							SET @pos = CHARINDEX(',', @str);
							SET @str3 = Substring(@str, 1, @pos - 1)

							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos);
							SET @pos = CHARINDEX(',', @str);
							SET @str4 = Substring(@str, 1, @pos - 1)
					
							SET @str = Substring(@str, @pos + 1, Len(@str) - @pos);
							SET @pos = CHARINDEX(',', @str);
							SET @str5 = Substring(@str, 1, @pos - 1)

							SET @str6 = SUBSTRING(@str, @pos + 1, LEN(@str) - @pos)
							INSERT INTO @Result VALUES (@str1, @str2, @str3, @str4, @str5, @str6)
					END
				ELSE
					BEGIN
						SET @pos= Charindex(',', @input)

						SET @str = @input
						SET @str1 = Substring(@str, 1, @pos - 1)

						SET @str = Substring(@str, @pos + 1, Len(@str) - @pos)
						SET @pos = CHARINDEX(',', @str);
						SET @str2 = Substring(@str, 1, @pos - 1)

						SET @str = Substring(@str, @pos + 1, Len(@str) - @pos)
						SET @pos = CHARINDEX(',', @str);
						SET @str3 = Substring(@str, 1, @pos - 1)

						SET @str = Substring(@str, @pos + 1, Len(@str) - @pos);
						SET @pos = CHARINDEX(',', @str);
						SET @str4 = Substring(@str, 1, @pos - 1)
					
						SET @str = Substring(@str, @pos + 1, Len(@str) - @pos);
						SET @pos = CHARINDEX(',', @str);
						SET @str5 = Substring(@str, 1, @pos - 1)

						SET @str6 = SUBSTRING(@str, @pos + 1, LEN(@str) - @pos)
						INSERT INTO @Result VALUES (@str1, @str2, @str3, @str4, @str5, @str6)
					END
			END
		END
	ELSE
		BEGIN
			INSERT INTO @Result VALUES ('Sin datos', 'Sin datos', 'Sin datos', 'Sin datos', 'Sin datos', 'Sin datos')
		END
	RETURN
END
go

