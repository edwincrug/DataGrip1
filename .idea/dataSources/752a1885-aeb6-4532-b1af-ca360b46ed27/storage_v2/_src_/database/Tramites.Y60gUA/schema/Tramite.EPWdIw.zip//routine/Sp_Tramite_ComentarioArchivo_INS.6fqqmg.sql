-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <09/09/2019>
-- Description:	<Guarda un comentario para un concepto>
--TEST EXEC [Tramite].[Sp_Tramite_ComentarioArchivo_INS]
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_ComentarioArchivo_INS] 
	@idConceptoArchivo INT,
	@idTramiteConcepto INT,
	@comentario VARCHAR(150),
	@importe DECIMAL(18, 2),
	@idUsuario INT,
	@idTipoProceso INT,
	@fecha VARCHAR(150) = NULL
AS
BEGIN 

SET NOCOUNT ON;
	
	DECLARE @resultado INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_ComentarioArchivo_INS] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite

		IF(@comentario != '') BEGIN
			INSERT INTO [Tramite].[TramiteComentario] (comentario, idTramiteConcepto, idUsuario, idTipoProceso, idConceptoArchivo)
			VALUES (@comentario, @idTramiteConcepto, @idUsuario, @idTipoProceso, @idConceptoArchivo)
		END
		IF(@importe > 0) BEGIN
			DELETE FROM [Tramite].[TramiteImporte] WHERE idTramiteConcepto = @idTramiteConcepto AND idConceptoArchivo = @idConceptoArchivo 
			INSERT INTO [Tramite].[TramiteImporte] (importe, idTramiteConcepto, idUsuario, idTipoProceso, importeIva, idConceptoArchivo)
			VALUES (@importe, @idTramiteConcepto, @idUsuario, @idTipoProceso, 0, @idConceptoArchivo)
			UPDATE [Tramite].[ConceptoArchivo] SET total = @importe, fecha = @fecha  WHERE idConceptoArchivo = @idConceptoArchivo
		END
		SET @resultado = 1;

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH
	SET NOCOUNT OFF

	SELECT @resultado AS [resultado]

END
go

