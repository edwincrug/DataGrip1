-- =============================================
-- Author:		Luis Garcia
-- Create date: 18/06/2019
-- Description:	Trae los datos del tramite a aprobar
-- TEST SEL_DEV_APROBAR_TRAMITE_SP 481
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEV_APROBAR_TRAMITE_SP] 
	@idPerTra INT
AS
BEGIN
		DECLARE @idEmpresa INT, @idSucursal INT, @nombreBase VARCHAR(30), @query VARCHAR(MAX),	
		@queryTipoPago  NVARCHAR(max),@ParmDefinition  NVARCHAR(max),@tipoDePago  NVARCHAR(max), @cveBanxico varchar(10) = '', @nombreBanco VARCHAR(100);

		SELECT 
			@idEmpresa = id_empresa,
			@idSucursal = id_sucursal,
			@cveBanxico = cveBanxico
		FROM tramiteDevoluciones WHERE id_perTra = @idPerTra

		SELECT @nombreBase = suc_nombrebd FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
		WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal AND suc_estatus = 1;

		SET @queryTipoPago = N'SELECT @tipoPagoOUT = PNC.PAR_IDENPARA' +
							' FROM ' + '[' + @nombreBase + '].[DBO].[PNC_PARAMETR] AS PNC' + 
							' WHERE PAR_TIPOPARA = ''FP'' AND PAR_DESCRIP1 = ''C. EFECTIVO C.'''

		SET @ParmDefinition = N'@tipoPagoOUT VARCHAR(5) OUTPUT'
		EXECUTE sp_executesql @queryTipoPago, @ParmDefinition, @tipoPagoOUT = @tipoDePago OUTPUT;

		IF ( @cveBanxico <> '' OR @cveBanxico IS NOT NULL)
			BEGIN
				SELECT    
					@nombreBanco = pbx_descripcion
				FROM Pagos.[dbo].[PAG_CAT_BANXICO] WHERE pbx_numoficial = @cveBanxico
			END
	SELECT 
		PT.id_perTra,
		PT.id_tramite,
		CONVERT(VARCHAR,PT.petr_fechaTramite,103) + ' - ' + CONVERT(VARCHAR(5),PT.petr_fechaTramite,24) AS petr_fechaTramite,
		ET.est_nombre,
		ET.id_estatus,
		TD.id_formaPago,
		TD.id_departamento,
		CONVERT(VARCHAR,TD.traDe_fechaAtencion,103) + ' - ' + CONVERT(VARCHAR(5),TD.traDe_fechaAtencion,24) AS traDe_fechaAtencion,
		CONVERT(VARCHAR,TD.traDe_fechaAutoriza,103) + ' - ' + CONVERT(VARCHAR(5),TD.traDe_fechaAutoriza,24) AS traDe_fechaAutoriza,
		CONVERT(VARCHAR,TD.traDe_fechaPago,103) + ' - ' + CONVERT(VARCHAR(5),TD.traDe_fechaPago,24) AS traDe_fechaPago,
		TD.traDe_Observaciones,
		TD.id_empresa,
		TD.id_sucursal,
		TD.traDe_devTotal,
		TD.PER_IDPERSONA,
		TD.esDe_IdEstatus,
		TD.cuentaBancaria,
		TD.numeroCLABE,
		TD.efectivoBanco,
		TD.efectivoCuenta,
		CT.id_tipoTramite,
		CT.estatus,
		ISNULL(MIX.e_efectivo,0) AS e_efectivo,
		ISNULL(MIX.e_noEfectivo,0) AS e_noEfectivo,
		TD.traDe_conCC,
		TD.traDe_banderaCC,
		@tipoDePago AS tipoPago,
		@nombreBanco AS nombreBanco,
		PE.orden
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus
	LEFT JOIN cuentasTesoreria CT ON CT.id_perTra = TD.id_perTra
	LEFT JOIN EstatusMixtosDevoluciones MIX on pt.id_perTra = MIX.id_perTra
	INNER JOIN cat_proceso_estatus AS PE ON PE.esDe_IdEstatus = TD.esDe_IdEstatus AND PT.id_tramite = PE.idTipoTramite 
	WHERE PT.id_perTra = @idPerTra
END
;
go

