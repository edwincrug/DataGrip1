
-- =============================================
-- Author:		<Juan Carlos Peralta>
-- Create date: <31/01/2020>
-- Description:	<Inserta la poliza>
-- [dbo].[INS_FONDOFIJO_ORDENMASIVA_SP] 347, 4, 6, 890,1, 1000, 'AAB', '01', '1', 'ZM-NZA-UN-68-1', 'Vale ZM-NZA-UN-68-1',0 
-- [dbo].[INS_FONDOFIJO_ORDENMASIVA_SP] 428, 4, 6, 896,1, 'ZM-NZA-UN-70-2-1'
-- =============================================
CREATE PROCEDURE [dbo].[INS_FONDOFIJO_ORDENMASIVA_SP] 
		@idusuario INT,
		@idempresa INT,
		@idsucursal INT,
		@id_perTra INT = 0,
		@proceso INT,
		@producto VARCHAR(255)

AS
BEGIN

DECLARE @precioUnitario DECIMAL(18,2), 
		@areaAfectacion varchar (50),
		@conceptoContable varchar (50),
		@tipoComprobante varchar (50),
		@observaciones VARCHAR(255),
		@descuento decimal(18,2) = 0,
		--
		@idVale INT


DECLARE @idEncabezado INT, 
		@idDetalle INT,
		@nombreBD VARCHAR(100), 
		@idProveedor INT,  
		@tasaIVA VARCHAR(100) =  '15', 
		--@tasaIVA VARCHAR(100),
		@cantidad INT = 1,
		@tipoIVA   VARCHAR(100),
		@queryIVA NVARCHAR(MAX),
		@tasaIVACal INT,
		@nombreBDSuc VARCHAR(100),
		@porc varchar(50),
		@esFactura INT,
		@fecha DATETIME = DATEADD(d,DATEDIFF(d,0,GETDATE()),0),
		@rfcFac varchar(50) 
	
DECLARE @queryRetencion NVARCHAR(MAX),
		@tasaRetIVA DECIMAL (18,2) = 0,
		@tasaRetISR DECIMAL (18,2) = 0

DECLARE @tipoCompAbreviatura varchar(20)

--SELECT @area = PAR_IDENPARA FROM [GAZM_Zaragoza].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = 'AREPED' AND PAR_DESCRIP1 = 'TRAMITES' 
--SELECT @conceptoContable = PAR_IDENPARA FROM [GAZM_Zaragoza].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = 'CONVEN' AND PAR_DESCRIP1 = 'TRAMITES'

--Fondo Fijo	
IF(@proceso =1)
BEGIN
--SELECT @idVale = id FROM Tramite.vales where idVale = @producto
SET @observaciones = 'Comprobacion ' + @producto
select 
@precioUnitario = monto, 
@areaAfectacion = areaAfectacion, 
@conceptoContable = conceptoAfectacion,
@tipoComprobante = tipoComprobante,
@tipoIVA = tipoIVA,
@esFactura = case when idfactura is null then 0 else 1 end
from tramite.valesevidencia 
where idComprobacionVale = @producto

select @nombreBDSuc = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBDSuc+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal INT OUTPUT', @tasaIVACal OUTPUT 

	--Se obtiene las retenciones
	SET @queryRetencion ='SELECT @tasaRetIVA = PAR_IMPORTE1, @tasaRetISR = PAR_IMPORTE2 FROM ['+@nombreBDSuc+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''TCPEDVAR'' AND PAR_IDENPARA = '''+@tipoComprobante+''''	
	EXECUTE sp_executeSQL @queryRetencion, N' @tasaRetIVA DECIMAL(18,2) OUTPUT, @tasaRetISR DECIMAL(18,2) OUTPUT',@tasaRetIVA OUTPUT, @tasaRetISR OUTPUT 

SET @tasaIVA = @tasaIVACal


IF(@tasaRetIVA = 0 AND @tasaRetISR = 0)
BEGIN
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACal) 
SET @precioUnitario = @precioUnitario / @porc
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR = 0)
BEGIN
SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACal) 
--SET @precioUnitario = @precioUnitario / @porc
select top 1 @tipoCompAbreviatura = abreviatura from [Tramite].[cat_TiposComprobantesFFGV] where idsucursal = @idsucursal and PAR_IDENPARA = @tipoComprobante

IF(@tipoCompAbreviatura = 'COMI')
BEGIN
SET @precioUnitario = @precioUnitario * 0.949367089
END
IF(@tipoCompAbreviatura = 'FLET')
BEGIN
SET @precioUnitario = @precioUnitario / 1.12
END
END

IF(@tasaRetIVA <> 0 AND @tasaRetISR <> 0)
BEGIN

SET @precioUnitario = @precioUnitario * 1.048951049

END

--IF(@tasaIVACal> 0)
--BEGIN
--	SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACal) 
--	SET @precioUnitario = @precioUnitario / @porc
--END



--select 
----@precioUnitario = traDe_devTotal, 
--@idProveedor = PER_IDPERSONA 
--from tramiteDevoluciones
--where id_perTra = @id_perTra

IF (@esFactura = 1)
BEGIN 

select 
@idProveedor = fv.PER_IDPERSONA,
@fecha = DATEADD(d,DATEDIFF(d,0,fv.fechaFactura),0)
from tramite.valesevidencia ve
inner join Tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.idComprobacionVale = @producto

END
ELSE
BEGIN

SET @idProveedor = 410798
SELECT @fecha = DATEADD(d,DATEDIFF(d,0,fechaCreacion),0)
FROM Tramite.valesEvidencia
WHERE idComprobacionVale = @producto

END

-- select @idProveedor = v.PER_IDPERSONA from tramite.valesevidencia ve
--inner join tramite.vales v on v.id = ve.idvales
--where idcomprobacionVale = @producto
--select @producto = idFondoFijo from tramite.fondofijo where id_perTra = @id_perTra
END

--Anticipo de Gastos
ELSE
BEGIN
SET @observaciones = 'AnticipoGasto ' + @producto

select  
@precioUnitario = ca.total, 
@areaAfectacion= tc.areaAfectacion, 
@conceptoContable = tc.idConceptoContable, 
@tipoComprobante = ca.tipoComprobante ,
@tipoIVA = ca.tipoIVA,
@rfcFac = ca.rfc
from Tramite.ConceptoArchivo ca
inner join Tramite.TramiteConcepto tc on tc.idTramiteConcepto = ca.idReferencia
where ca.idComprobacionConcepto = @producto

select @nombreBDSuc = suc_nombrebd from ControlAplicaciones.dbo.cat_sucursales where suc_idsucursal = @idsucursal
	--Se obtiene el IVA
	SET @queryIVA ='SELECT @tasaIVACal = PAR_IMPORTE1  FROM ['+@nombreBDSuc+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA =''IV'' AND PAR_IDENPARA = '''+@tipoIVA+''''	
	EXECUTE sp_executeSQL @queryIVA, N' @tasaIVACal INT OUTPUT', @tasaIVACal OUTPUT 

SET @tasaIVA = @tasaIVACal

--IF(@tasaIVACal> 0)
--BEGIN
--	SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACal) 
--	SET @precioUnitario = @precioUnitario / @porc
--END

--IF EXISTS (select top 1 1 from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra)
--BEGIN 
--select @idProveedor =  idpersona from [Tramite].[TramiteEmpleado] where idtramitedevolucion = @id_perTra
--END
--ELSE
--BEGIN
--select 
--@idProveedor = PER_IDPERSONA 
--from tramiteDevoluciones
--where id_perTra = @id_perTra
--END
--SET @idProveedor = 410798

IF(@tasaIVACal> 0)
BEGIN
	SET @porc = '1.' +  CONVERT(varchar(10), @tasaIVACal) 
	SET @precioUnitario = @precioUnitario / @porc

	IF EXISTS (select top 1 * from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac) 
		BEGIN
			select top 1 @idProveedor = PER_IDPERSONA from GA_Corporativa..PER_PERSONAS where PER_RFC = @rfcFac
		END
	ELSE
		BEGIN
		SET @idProveedor = 410798
		END
	END
ELSE
BEGIN
--SET @conceptoContable = 126
	DECLARE @queryNoDeducibles NVARCHAR(MAX), @Nodeducibles varchar(10)
	SET @queryNoDeducibles ='SELECT @Nodeducibles = PAR_IDENPARA  FROM ['+@nombreBDSuc+'].[DBO].[PNC_PARAMETR] WHERE PAR_TIPOPARA = ''CONVEN'' AND PAR_STATUS = ''A'' AND PAR_IDMODULO = ''CON'' AND PAR_DESCRIP1 like ''%No deducibles%'''	
	EXECUTE sp_executeSQL @queryNoDeducibles, N' @Nodeducibles varchar(10) OUTPUT', @Nodeducibles OUTPUT 

SET @conceptoContable = @Nodeducibles
SET @idProveedor = 410798
END


END		
 
 
select @nombreBD = emp_nombrebd from ControlAplicaciones.dbo.cat_empresas where emp_idempresa = @idempresa


DECLARE @ordenesmasivas NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[cxp_ordenesmasivas]
	([odm_idsucursal]
	,[odm_idproveedor]
	,[odm_areaafectacion]
	,[odm_observaciones]
	,[odm_tipocomprobante]
	,[odm_fechaorden]
	,[odm_fechaaplicacion]
	,[odm_fechaproceso]
	,[odm_estatus]
	,[odm_ordencompra])
	  VALUES
	  ('''+ CONVERT(VARCHAR(10),@idsucursal)+'''
	  ,'''+ CONVERT(VARCHAR(10),@idProveedor)+'''
	  ,'''+@areaAfectacion+'''
	  ,'''+@observaciones+'''
	  ,'''+@tipoComprobante+'''
	  ,'''+ CONVERT(VARCHAR(30),@fecha)+'''
	  ,'''+ CONVERT(VARCHAR(30),@fecha)+'''
	  ,NULL
	  ,0
	  ,NULL)'
exec(@ordenesmasivas)
print @ordenesmasivas
SET @idEncabezado= @@IDENTITY

-- DATEADD(d,DATEDIFF(d,0,GETDATE()),0)

DECLARE @ordenesmasivasDet NVARCHAR(MAX) = '
INSERT INTO ['+@nombreBD+'].[dbo].[cxp_ordenesmasivasdet]
	([omd_areaafectacion]
	,[omd_conceptocontable]
	,[omd_cantidad]
	,[omd_producto]
	,[omd_preciounitario]
	,[omd_tasaiva]
	,[omd_descuento]
	,[odm_idordenmasiva])
	  VALUES
	  ( '''+@areaAfectacion+'''
	  ,'''+@conceptoContable+'''
	 ,'''+ CAST(@cantidad AS varchar(10))+'''
	  ,'''+@producto+'''
	  ,'''+ CONVERT(VARCHAR(10),@precioUnitario)+'''
	  ,'''+@tasaIVA+'''
	  ,'''+ CAST(@descuento AS varchar(10))+'''
	  ,'''+ CAST(@idEncabezado AS varchar(10))+''')
'
exec(@ordenesmasivasDet) 
print @ordenesmasivasDet
SET @idDetalle= @@IDENTITY

select @idEncabezado encabezado,@idDetalle detalle
END
go

