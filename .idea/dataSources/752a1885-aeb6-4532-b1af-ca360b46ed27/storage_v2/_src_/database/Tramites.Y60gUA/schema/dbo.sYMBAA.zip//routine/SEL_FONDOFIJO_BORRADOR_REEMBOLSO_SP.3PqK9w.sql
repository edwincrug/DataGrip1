-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <14/10/2019>
-- Description:	<SP que trae los datos del tramite FF borrador>
-- SEL_FONDOFIJO_BORRADOR_REEMBOLSO_SP 1336
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FONDOFIJO_BORRADOR_REEMBOLSO_SP] 
	@idPerTra INT
AS
BEGIN
	DECLARE @url varchar(max), @urlSave varchar(max)
	SELECT @url = pr_descripcion FROM parametros WHERE pr_identificador = 'RUTA_SAVE_LOC'

	SET @urlSave = (SELECT pr_descripcion FROM parametros WHERE pr_identificador = 'GET_SERVER');	

	declare @parametros table(tabla varchar(60),correo varchar(max), idrol int, idUsuario int)
	
	--insert into @parametros
	--EXEC OBTIENE_PARAMETROS 'tesoreriaFondoFijo'
	 
    DECLARE @idRolSiguiente INT, @correo varchar (max)
    
    SELECT @idRolSiguiente = idRolSiguiente FROM Tramite.FlujoRolTramite
    where idtramite = 10 and estatusPasoActual = 2   

	DECLARE @id_perTraFF INT
	select top 1 @id_perTraFF = ff.id_perTra from Tramite.valesEvidencia ve
	inner join Tramite.vales v on v.id = ve.idVales
	inner join Tramite.valesFondoFijo vff on vff.idVales = v.id
	inner join Tramite.fondoFijo ff on ff.id = vff.idTablaFondoFijo
	where ve.id_perTraReembolso = @idPerTra 

	--select @correo = correo from @parametros
 
	SET @correo = 'victor.jimenez@grupoandrade.com.mx,margarita.davila@grupoandrade.com.mx,efren.ruiz@grupoandrade.com.mx,rosalba.lara@grupoandrade.com.mx'

SELECT
	FF.id,
	FF.idEmpresa, 
	FF.idSucursal, 
	FF.idDepartamento, 
	FF.idAutorizador, 
	FF.idResponsable, 
	TD.traDe_devTotal as monto,
	ISNULL(FFC.aumentoDecrementoFF,0)  as aumentodisminucion, 
	ISNULL(TD.traDe_Observaciones,'') AS descripcion,
	FF.nombreFondoFijo,
	FF.idFondoFijo, 
	U.usu_materno  + ' ' + U.usu_paterno + ' ' + U.usu_nombre as solicitante,
	ET.id_estatus,
	TD.esDe_IdEstatus,
	ISNULL(FF.idSalidaEfectivo,0) as idSalidaEfectivo,
	ISNULL(FF.idReembolso,0) as idReembolso,
	@url as url,
	FFC.montoCambiado,
	FF.estatusFondoFijo,
	@correo as correoTesoreria,
	'Autorización Fondo FIjo ' + FF.idFondoFijo as asunto,
	D.dep_nombrecto,
	TD.PER_IDPERSONA,
	ISNULL(FF.Autorizado,0) as Autorizado,
	FF.cuentaContable,
	FF.montoDisponible,
	FF.tipoCierre,
	FF.comprobanteCierre,
	FF.arqueoCierre,
	@urlSave as urlSave,
	U.usu_correo as correoCajero,
	FFC.id as idAumentoDecremento,
	ISNULL(FF.departamentoAreas,0) as departamentoAreas
FROM [Tramite].[fondoFijo] FF
INNER JOIN personaTramite PT ON PT.id_perTra = FF.id_perTra
INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
INNER JOIN estatusTramites ET ON ET.id_estatus = PT.petr_estatus 
INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = idResponsable
INNER JOIN ControlAplicaciones.dbo.cat_departamentos D ON D.dep_iddepartamento = TD.id_departamento
LEFT JOIN Tramite.fondoFijoCambios FFC ON FFC.id = FF.AumentoDisminucion
WHERE FF.id_perTra = @id_perTraFF

END

go

