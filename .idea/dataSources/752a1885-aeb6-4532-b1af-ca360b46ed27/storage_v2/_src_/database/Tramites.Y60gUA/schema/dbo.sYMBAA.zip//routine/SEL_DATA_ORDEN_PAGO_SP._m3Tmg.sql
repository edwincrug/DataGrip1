-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATA_ORDEN_PAGO_SP]
	@idPerTra INT
AS
BEGIN
	SELECT 
		TD.id_perTra,
		TD.id_traDe,
		TD.traDe_devTotal,
		TD.id_empresa,
		TD.id_sucursal,
		TD.PER_IDPERSONA,
		TD.efectivoBanco,
		TD.efectivoCuenta,
		CT.estatus
	FROM personaTramite PT
	INNER JOIN tramiteDevoluciones TD ON TD.id_perTra = PT.id_perTra
	INNER JOIN cuentasTesoreria CT ON CT.id_perTra = PT.id_perTra
	WHERE PT.id_perTra = @idPerTra
END
go

