-- =============================================
-- Author:		Roberto Almanza
-- Create date: 
-- Description:	SP que aprueba el tramite
-- =============================================
CREATE PROCEDURE [dbo].[UPD_APROBAR_RECHAZAR_TRAMITE_SP]
	@id_perTra INT,
	@estatus INT,
	@observaciones nvarchar(max) =''

AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY

	/*
	petr_estatus = 3 para indicar que el tramite termino
	esDe_IdEstatus indica el estatus del paso 
	*/
	UPDATE personaTramite
	SET petr_estatus = 3
		,esDe_IdEstatus = @estatus
		,petr_observaciones = @observaciones
	WHERE id_perTra = @id_perTra
	
    UPDATE tt
    SET tt.tsb_estatus = case when @estatus = 2 then 0 else -2 end
    FROM GA_Corporativa.dbo.tsb_traspasosaldobancos tt
    JOIN Tesoreria.dbo.transferenciasLog l
    ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
	and ISNULL(l.esCC,0) = 0
    WHERE l.idPerTra = @id_perTra

	UPDATE l
	SET l.fechaAutorizadaRechazada = GETDATE()
	FROM GA_Corporativa.dbo.tsb_traspasosaldobancos tt
	JOIN Tesoreria.dbo.transferenciasLog l
	ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
	WHERE l.idPerTra = @id_perTra

	/*
	actializamos a estatus 3 para que el sistema 
	detecte que el tramite finalizo
	*/
	UPDATE t
    SET estatus = 3
	FROM cuentasTesoreria t
	WHERE t.id_perTra  = @id_perTra

	SELECT success = 1, pr_descripcion as ruta FROM parametros WHERE pr_identificador = 'RUTA_DOCTO_TRANS'

COMMIT TRANSACTION
END TRY

BEGIN CATCH
ROLLBACK TRANSACTION
	SELECT success = 0;
END CATCH
END
go

