-- =============================================
-- Author:		Francisco Javier Suárez Priego
-- Create date: 12/09/2019
-- Description:	Servicio para crear el identificador del fondo fijo
-- =============================================
CREATE PROCEDURE Tramite.Sel_FondoFijoId
	-- Add the parameters for the stored procedure here
	@idEmpresa int=0,
	@idSucursal int=0,
	@idDepartamento int=0
AS

Declare @total int
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select @total = count(*) from Tramites.Tramite.fondoFijo
	where idEmpresa = @idEmpresa and idSucursal=@idSucursal and idDepartamento=@idDepartamento



	select ce.emp_nombrecto, cs.suc_nombrecto, cd.dep_nombrecto, @total+1 as num from ControlAplicaciones.dbo.cat_empresas ce 
	inner join ControlAplicaciones.dbo.cat_sucursales cs on ce.emp_idempresa=cs.emp_idempresa
	inner join ControlAplicaciones.dbo.cat_departamentos cd on cs.suc_idsucursal = cd.suc_idsucursal
	where ce.emp_idempresa = @idEmpresa and cs.suc_idsucursal = @idSucursal and cd.dep_iddepartamento=@idDepartamento
END
go

