-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <23/10/2019>
-- Description:	<SP que actualiza el estatus de la evidencia del vale>
-- [dbo].[UPD_SEGUIMIENTOCONCEPTOEVIDENCIA_EFECTIVO_SP]  2267
-- =============================================
CREATE PROCEDURE [dbo].[UPD_SEGUIMIENTOCONCEPTOEVIDENCIA_EFECTIVO_SP] 
	@idsolicitud INT
AS
BEGIN
	

	----Actualiar Conceptos----
	update tramite.tramiteconcepto set idEstatus = 9 where idTramitePersona = @idsolicitud and idEstatus = 8
	update personaTramite set petr_estatus = 9 where id_perTra = @idsolicitud
	update  tramiteDevoluciones set esde_idestatus = 9 where id_perTra = @idsolicitud

	insert into tramites.tramite.TramiteImporte
	SELECT
      ti.importe
      ,ti.idTramiteConcepto
      ,ti.idUsuario
      ,4
      ,ti.importeIva
      ,ca.idConceptoArchivo
  FROM Tramite.TramiteImporte ti
  JOIN tramite.TramiteConcepto tc
  ON ti.idTramiteConcepto = tc.idTramiteConcepto
  AND tc.idEstatus = 9
  AND tc.idTramitePersona = @idsolicitud
  LEFT JOIN Tramite.ConceptoArchivo ca
  on ca.idReferencia = @idsolicitud
WHERE ti.idTipoProceso = 1

	SELECT success = 1, msg = 'Se actualizo correctamente';

END
go

