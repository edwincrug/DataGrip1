-- =============================================
-- Author:		Juan Carlos Peralta Sotelo
-- Create date: 25/06/2020
-- Modify: Juan Carlos
-- Modify date: 19/05/2020
-- Description:	SP para obtener los departamentos x fondo
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOSXFONDO_SP]  
	@idFondo int
AS

BEGIN
	
DECLARE @idEmpresa INT, @idSucursal INT
select @idEmpresa = idEmpresa, @idsucursal = idSucursal from tramite.fondofijo where id = @idFondo

select 
d.dep_iddepartamento as idDepartamento,
d.dep_nombre as departamento,
a.idAutorizador,
u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as autorizador,
u.usu_correo as correo
from ControlAplicaciones..cat_departamentos d
inner join Tramite.autorizadoresFondoFijo a on a.idDepartamento = d.dep_iddepartamento
inner join ControlAplicaciones.dbo.cat_usuarios u on u.usu_idusuario = a.idAutorizador
where d.emp_idempresa = @idEmpresa and d.suc_idsucursal = @idSucursal and d.dep_estatus = 1

END

go

