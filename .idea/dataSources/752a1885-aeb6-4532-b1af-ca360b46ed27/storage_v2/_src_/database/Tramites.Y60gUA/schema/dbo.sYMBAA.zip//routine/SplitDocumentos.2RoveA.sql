
-- =============================================
-- Author:		Irving Solorio	
-- Create date: 06/06/2019
-- Description:	Descompone string de pipes y comas
-- =============================================
--select * from dbo.[SplitDocumentos]('MK000033038,true|ANT12622-1,true|MK000033038,true|ANT12622-1,true')
 

CREATE FUNCTION [dbo].[SplitDocumentos](@input AS Varchar(8000) )

RETURNS

     @Result TABLE(idTramite VARCHAR(50),idDocumento VARCHAR(50))

AS

BEGIN
	IF(LEN(@input) > 0 )
	BEGIN
      DECLARE @str VARCHAR(50),@str1 VARCHAR(50), @str2 VARCHAR(50),@pos int

      DECLARE @ind Int

      IF(@input is not null)

      BEGIN

            SET @ind = CharIndex('|',@input)

           if @ind >0
			begin
					WHILE @ind > 0

					BEGIN

						SET @str = SUBSTRING(@input,1,@ind-1)

						SET @input = SUBSTRING(@input,@ind+1,LEN(@input)-@ind)
						Set @pos= charindex(',',@str)
						Set @str1=substring(@str,1,@pos-1)
						set @str2=substring(@str,@pos+1,len(@str)-@pos)
						INSERT INTO @Result values (@str1,@str2)

						SET @ind = CharIndex('|',@input)

					END

					SET @str = @input
					Set @pos= charindex(',',@input)
					Set @str1=substring(@str,1,@pos-1)
					set @str2=substring(@str,@pos+1,len(@str)-@pos)
					INSERT INTO @Result values (@str1,@str2)
			end
			else
			begin
					Set @pos= charindex(',',@input)
					SET @str = @input
					Set @str1=substring(@str,1,@pos-1)
					set @str2=substring(@str,@pos+1,len(@str)-@pos)

					INSERT INTO @Result values (@str1,@str2)
			end

      END
	  END
	  ELSE
		BEGIN
			INSERT INTO @Result values ('Sin datos','Sin datos')
		END
      RETURN
END



go

