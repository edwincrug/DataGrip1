-- =============================================
-- Author:		Luis Garcia
-- Create date: 18/06/2019
-- Description:	Cambia al estatus en revision del tramite
-- Update By:		Mauricio Salgado
-- Create date: 04/09/2019
-- Description:	Valida si el tramite es diferente a 9 para actualizar
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_TRAMITE_ENREVISION_SP] 
	@id_perTra INT
AS
BEGIN
	DECLARE  @idEstatus INT, @idTramite INT;
	SELECT 
		@idEstatus = petr_estatus
		,@idTramite = id_tramite
	FROM personaTramite 
	WHERE id_perTra = @id_perTra

	IF(@idTramite != 9) BEGIN
		IF( @idEstatus = 0)
			BEGIN
				UPDATE personaTramite
				SET petr_estatus = 1
				WHERE id_perTra = @id_perTra

				--UPDATE tramiteDevoluciones
				--SET traDe_fechaAtencion = GETDATE(), esDe_IdEstatus = 1
				--WHERE id_perTra = @id_perTra;

				IF(@idTramite = 10)
				BEGIN
				DECLARE @esDe_IdEstatus INT
				select @esDe_IdEstatus = esDe_IdEstatus from tramiteDevoluciones WHERE id_perTra = @id_perTra;
				IF(@esDe_IdEstatus = 4)
				BEGIN
				UPDATE personaTramite
				SET petr_estatus = 11
				WHERE id_perTra = @id_perTra
				END
				ELSE
				BEGIN
				UPDATE tramiteDevoluciones
				SET traDe_fechaAtencion = GETDATE(), esDe_IdEstatus = 1
				WHERE id_perTra = @id_perTra;
				END
				END
			END
		ELSE IF( @idEstatus = 6 )
			BEGIN
				UPDATE tramiteDevoluciones
				SET traDe_fechaAtencion = GETDATE(), esDe_IdEstatus = 1
				WHERE id_perTra = @id_perTra;
			END
	END
	SELECT success = 1, urlAprobar = (
										SELECT DISTINCT
											apro_url 
										FROM cat_aprobarTramite APT
										INNER JOIN personaTramite PM ON PM.id_tramite = APT.id_tramite
										WHERE id_perTra = @id_perTra);
END
go

