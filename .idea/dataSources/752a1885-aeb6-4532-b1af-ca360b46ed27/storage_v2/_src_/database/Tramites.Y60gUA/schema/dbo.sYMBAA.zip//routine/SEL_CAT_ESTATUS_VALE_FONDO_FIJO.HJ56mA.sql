-- =============================================
-- Author:		Roberto Almanza
-- Create date: <Create Date,,>
-- Description:	Obtiene el catalogo de los estatus de vale de fondo fijo
-- =============================================
create PROCEDURE [dbo].[SEL_CAT_ESTATUS_VALE_FONDO_FIJO]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT cv.id
      ,cv.descripcion
	  ,CASE WHEN cv.id = 3 THEN 1 ELSE 0 END selected
	  FROM Tramite.cat_estatusVale cv
	UNION
	SELECT 0 AS id,
	  'Todos' AS descripcion
	  ,0 AS selected
	ORDER BY 1 asc

END
go

