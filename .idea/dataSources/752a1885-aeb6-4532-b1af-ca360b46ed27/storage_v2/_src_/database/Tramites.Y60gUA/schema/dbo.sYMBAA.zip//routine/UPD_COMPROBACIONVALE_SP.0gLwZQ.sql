
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [SEL_EVIDENCIASVALES_SP]   
-- =============================================
CREATE PROCEDURE [dbo].[UPD_COMPROBACIONVALE_SP] 
	@areaAfectacion varchar(50),
	@tipoConcepto varchar(50),
	@tipoComprobante varchar(50),
	@tipoIva varchar(50),
	@idComprobacionVale INT,
	@idProveedor INT = 0
AS
BEGIN
	
	UPDATE Tramite.valesEvidencia
	SET areaAfectacion = @areaAfectacion, conceptoAfectacion = @tipoConcepto, tipoComprobante = @tipoComprobante, tipoIVA = @tipoIva
	where id = @idComprobacionVale
	
	IF(@idProveedor > 0)
	BEGIN
	UPDATE fv
	SET fv.PER_IDPERSONA = @idProveedor
	FROM Tramite.valesEvidencia ve 
	INNER JOIN Tramite.FacturaVale fv on fv.id = ve.idfactura
	WHERE ve.id = @idComprobacionVale
	END

	SELECT success = 1;
END

go

