
-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <22/10/2019>
-- Description:	<SP que trae las evidencias de los vales>
-- [SEL_OBTIENECORREOFINANZASFFAG] 10
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENECORREOFINANZASFFAG] 
	@idRol INT
	
AS
BEGIN
	DECLARE @idUsuario INT
	DECLARE @usu_correo VARCHAR(130)
	DECLARE @nombreUsuario VARCHAR(300)


	--Obtener los datos del usuario al que se le va a notificar
	SELECT  @idUsuario =  cu.usu_idusuario,
			@usu_correo =  cu.usu_correo, 
		    @nombreUsuario = cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno
	FROM ControlAplicaciones.dbo.cat_usuarios cu
	INNER JOIN Tramites.dbo.usuarioRol ur on cu.usu_idusuario  = ur.idUsuario 
	WHERE ur.idRol = @idRol and cu.usu_idusuario = 2189
	
	SELECT @idUsuario idUsuario, @usu_correo correo, @nombreUsuario nombreUsuario
	
	
END
go

