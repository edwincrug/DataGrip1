-- =============================================
-- Author:		<Mauricio Salgado Estrada>
-- Create date: <02/10/2019>
-- Description:	<Aprueba, Rechaza un archivo>
--TEST EXEC [Tramite].[Sp_Tramite_AprobarRechazarArchivo_UPD] 549, 1700,9,2046,506,4,'',1040
-- =============================================
CREATE PROCEDURE [Tramite].[Sp_Tramite_AprobarRechazarArchivo_UPD] 
	@idConceptoArchivo INT,
	@importe DECIMAL(18, 2),
	@idEstatus INT,
	@idUsuario INT,
	@idTramiteConcepto INT,
	@idTipoProceso INT,
	@comentario VARCHAR(150),
	@idSolicitud INT,
	@compNoAutorizado INT = 0
AS
BEGIN 

SET NOCOUNT ON;
	
	DECLARE @resultado INT;
	DECLARE @VI_ZERO INT = 0
		,@VC_ErrorMessage NVARCHAR(4000) = ''
		,@VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Tramite].[Sp_Tramite_ConceptoImporte_UPD] :'
		,@VI_ErrorSeverity INT = 0
		,@VI_ErrorState INT = 0
		,@VI_CountResult INT = 0
	
	BEGIN TRY
		BEGIN TRANSACTION TrnxInsTramite

		UPDATE [Tramite].[ConceptoArchivo] 
			SET idEstatus = @idEstatus, compNoAutorizado = @compNoAutorizado
		WHERE idConceptoArchivo = @idConceptoArchivo
		
		IF(@idEstatus = 9) BEGIN
			DELETE FROM [Tramite].[TramiteImporte] 
			WHERE idTramiteConcepto = @idTramiteConcepto 
				AND idConceptoArchivo = @idConceptoArchivo
				AND idTipoProceso = @idTipoProceso

			INSERT INTO [Tramite].[TramiteImporte] (importe, idTramiteConcepto, idUsuario, idTipoProceso, idConceptoArchivo)
			VALUES (@importe, @idTramiteConcepto, @idUsuario, @idTipoProceso, @idConceptoArchivo)
		END

		IF(COALESCE(@comentario, '') != '')
		BEGIN
			INSERT INTO [Tramite].[TramiteComentario] (
				comentario
				,idTramiteConcepto
				,idUsuario,
				idTipoProceso,
				idConceptoArchivo)
			VALUES (
				@comentario
				,@idTramiteConcepto
				,@idUsuario
				,@idTipoProceso
				,@idConceptoArchivo)
		END

		DECLARE @pendientes INT, @aprobados INT, @justificado INT
		IF(@idTipoProceso = 4) BEGIN
			
			select 
			@justificado =case when sum(ca.total) >= sum(ti.importe) then 1
			else 0
			end 
			from Tramite.TramiteConcepto  tc 
			inner join Tramite.TramiteImporte ti on ti.idTramiteConcepto =  tc.idTramiteConcepto and ti.idTipoProceso = 2
			left join  [Tramite].[ConceptoArchivo] ca on ca.idReferencia = tc.idTramiteConcepto  and ca.idEstatus = 9
			where tc.idTramitePersona =  @idSolicitud

			SELECT @pendientes = COUNT(*) FROM Tramite.ConceptoArchivo CA
			INNER JOIN Tramite.TramiteConcepto TC ON CA.idReferencia = TC.idTramiteConcepto
			WHERE TC.idTramitePersona = @idSolicitud
			AND CA.idEstatus = 8

			IF (@pendientes = 0) 
			BEGIN 
				SELECT @aprobados = COUNT(*) FROM Tramite.ConceptoArchivo CA
				INNER JOIN Tramite.TramiteConcepto TC ON CA.idReferencia = TC.idTramiteConcepto
				WHERE TC.idTramitePersona = @idSolicitud
				AND CA.idEstatus = 9

				IF(@aprobados > 0 ) 
				BEGIN
					IF(@justificado = 1)
					BEGIN
						UPDATE [dbo].[personaTramite] SET petr_estatus = 9 WHERE id_perTra = @idSolicitud 
						UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = 9 WHERE id_perTra = @idSolicitud 
						SET @resultado = 9;
						END
				END
				ELSE 
				BEGIN 
				IF(@justificado = 1)
					BEGIN
					UPDATE [dbo].[personaTramite] SET petr_estatus = 10 WHERE id_perTra = @idSolicitud 
					UPDATE [dbo].[tramiteDevoluciones] SET esDe_IdEstatus = 10 WHERE id_perTra = @idSolicitud 
					SET @resultado = 10;
					END
				END
			END
			ELSE BEGIN		   
				SET @resultado = 1;
			END
		END

		COMMIT TRANSACTION TrnxInsTramite
	END TRY	
	BEGIN CATCH
		SELECT @VC_ErrorMessage = ERROR_MESSAGE()
			,@VI_ErrorSeverity = ERROR_SEVERITY()
			,@VI_ErrorState = ERROR_STATE();
		IF COALESCE(ERROR_NUMBER(), 0) > @VI_ZERO
		BEGIN
			ROLLBACK TRANSACTION TrnxInsTramite
			SET @VC_ErrorMessage = @VC_ThrowMessage + ' ' + @VC_ErrorMessage
			RAISERROR (@VC_ErrorMessage, @VI_ErrorSeverity, @VI_ErrorState);
		END
	END CATCH
	SET NOCOUNT OFF

	SELECT @resultado AS [resultado]

END
go

