-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <05/06/2019>
-- Description:	<Se guarda un documento>
-- =============================================
CREATE PROCEDURE [dbo].[INS_DOCUMENTO_SP]
	@nombreDocumento VARCHAR(50),
	@extension INT,
	@expiracion INT,
	@plusInfo INT,
	@infAdicional VARCHAR(20),
	@idUsuario INT
AS
BEGIN
	IF NOT EXISTS( SELECT * FROM cat_documentos WHERE doc_nomDocumento = @nombreDocumento )
		BEGIN
			INSERT INTO cat_documentos
			VALUES(
				@nombreDocumento,
				@extension,
				@expiracion,
				@plusInfo,
				@infAdicional,
				@idUsuario,
				3,
				0
			)
			SELECT success = 1, msg = 'Se inserto con éxito el documento.';
		END
	ELSE
		BEGIN
			SELECT success = 0, msg = 'Ya éxiste un documento con ese nombre.';
		END
END
go

