CREATE VIEW [dbo].[cat_tiposorden] AS   SELECT   tip_idtipoorden, tip_nombre, tip_nombrecorto, tip_status, tip_fechaalta, tip_idusuarioalta, tip_fechamodifica, tip_idusuariomodifica  FROM    CUENTASXPAGAR.dbo.cat_tiposorden

go

