create view [dbo].[CON_MOVCHEQUE012011] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012011
go

