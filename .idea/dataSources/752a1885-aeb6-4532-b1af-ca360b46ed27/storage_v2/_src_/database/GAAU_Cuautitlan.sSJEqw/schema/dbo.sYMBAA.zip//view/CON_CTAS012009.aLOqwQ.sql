create view 	[dbo].[CON_CTAS012009]	 as select * from GAAU_Concentra.dbo.CON_CTAS012009
go

