CREATE     PROCEDURE [SICOP_LIST_PROS_RECEP_DIA]
@p_str_clave_ejecutivo nvarchar(15)
AS
Select C_Clave, N_Nombre, Call_Center,Motivo_Call_Center
From Prospecto
Where
convert(varchar,[Fecha de registro],101)<=convert(varchar,getdate(),101) AND
Aviso_Reg_recibido<>0 And
C_Promotor=@p_str_clave_ejecutivo
go

