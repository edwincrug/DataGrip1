create view 	[dbo].[CON_POLDIRERR012009]	 as select * from GAAU_Concentra.dbo.CON_POLDIRERR012009
go

