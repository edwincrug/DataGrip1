create view 	[dbo].[CON_POLFIJ012009]	 as select * from GAAU_Concentra.dbo.CON_POLFIJ012009
go

