create view [dbo].[CON_MOVTRANSFER012013] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012013
go

