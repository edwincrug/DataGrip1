CREATE PROCEDURE CAMBIAPOLIZADEV
@NOMBRE VARCHAR (100)=NULL
AS
IF @NOMBRE IS NULL
PRINT 'FALTA EL NOMBRE DE LA CONFIGURACION'
ELSE
SET @NOMBRE = UPPER(@NOMBRE)
declare 
@configura varchar(100),@conceto varchar(50), @carabo varchar(10),@nuevocarabo varchar(10)
declare rs cursor for 
select  cnc_configura, cnc_concepto, cnc_carabo from con_confconta
where cnc_configura = @NOMBRE
open   rs
FETCH NEXT FROM rs
into @configura,@conceto,@carabo
IF  @@FETCH_STATUS <> 0
BEGIN 
PRINT 'NO EXISTE LA CONFIGURACION'
END 
ELSE
BEGIN
WHILE @@FETCH_STATUS = 0
if @carabo='A' 
begin
set @nuevocarabo='C'
            update con_confconta SET cnc_carabo= @nuevocarabo where cnc_configura = 'DEVOLUCION ' + @configura                  
            AND cnc_concepto=@conceto
FETCH NEXT FROM rs
into @configura,@conceto,@carabo
end
else
begin
set @nuevocarabo='A'
            update con_confconta SET cnc_carabo= @nuevocarabo where  cnc_configura = 'DEVOLUCION ' + @configura                 
            AND cnc_concepto=@conceto
FETCH NEXT FROM rs
into @configura,@conceto,@carabo
end
END 
CLOSE rs
DEALLOCATE rs
go

