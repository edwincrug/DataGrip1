CREATE VIEW [dbo].[cat_tiporeferencia] AS SELECT * From  GAAU_Concentra.dbo.cat_tiporeferencia
go

