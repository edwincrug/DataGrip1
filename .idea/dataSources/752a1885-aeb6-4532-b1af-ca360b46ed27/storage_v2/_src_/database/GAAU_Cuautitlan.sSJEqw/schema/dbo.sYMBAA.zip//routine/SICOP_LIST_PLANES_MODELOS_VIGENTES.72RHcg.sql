 Create proc SICOP_LIST_PLANES_MODELOS_VIGENTES
   @Modelo nvarchar(15),
    @Ano nvarchar( 15 )
 As
 SELECT
 C.C_Clave , C.Descripcion
 From
 SICOP_PLANES_MODELOS AS A,
 SICOP_Planes_Credito AS B,
 SICOP_TIPO_PLANES As C
 Where
 C.C_Clave=B.[C_Tipo_Plan] AND
 B.Clave_Plan=A.[Clave_plan] and
 A.C_Producto=@Modelo and
 B.[Año]=@Ano
 ORDER BY
 C.Descripcion
 go

