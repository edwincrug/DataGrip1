create view [dbo].[CON_MOVCHEQUE012015] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012015
go

