create view [dbo].[SER_PAQVEH] as select * from GAAU_Concentra.dbo.SER_PAQVEH
go

