
CREATE VIEW [dbo].[cxp_cancelaordenesmasivas]
AS
SELECT *
FROM GAAU_Concentra.dbo.cxp_cancelaordenesmasivas

go

