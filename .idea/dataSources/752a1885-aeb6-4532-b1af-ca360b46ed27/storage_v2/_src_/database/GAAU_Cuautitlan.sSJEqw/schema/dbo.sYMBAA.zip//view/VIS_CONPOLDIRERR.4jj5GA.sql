CREATE VIEW VIS_CONPOLDIRERR AS Select '01' as VCOE_Empresa,'2013' as VCOE_Anno,* FROM CON_POLDIRERR012013
 union all Select '01' as VCOE_Empresa,'2014' as VCOE_Anno,* FROM CON_POLDIRERR012014
 union all Select '01' as VCOE_Empresa,'2015' as VCOE_Anno,* FROM CON_POLDIRERR012015
 union all Select '01' as VCOE_Empresa,'2016' as VCOE_Anno,* FROM CON_POLDIRERR012016
 union all Select '01' as VCOE_Empresa,'2017' as VCOE_Anno,* FROM CON_POLDIRERR012017
 union all Select '01' as VCOE_Empresa,'2018' as VCOE_Anno,* FROM CON_POLDIRERR012018
 union all Select '01' as VCOE_Empresa,'2019' as VCOE_Anno,* FROM CON_POLDIRERR012019
 union all Select '01' as VCOE_Empresa,'2020' as VCOE_Anno,* FROM CON_POLDIRERR012020
go

