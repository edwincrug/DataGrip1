create view [dbo].[ADE_ADDENDASCONFIG] as select * from GAAU_Concentra.dbo.ADE_ADDENDASCONFIG
go

