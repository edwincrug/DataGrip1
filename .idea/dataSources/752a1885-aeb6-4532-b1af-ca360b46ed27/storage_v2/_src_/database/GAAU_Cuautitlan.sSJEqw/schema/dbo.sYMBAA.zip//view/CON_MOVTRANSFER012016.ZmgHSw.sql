create view [dbo].[CON_MOVTRANSFER012016] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012016
go

