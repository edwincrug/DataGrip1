
CREATE VIEW [dbo].[CON_CancelaSATEnc] AS SELECT * FROM GAAU_Concentra.dbo.CON_CancelaSATEnc
go

