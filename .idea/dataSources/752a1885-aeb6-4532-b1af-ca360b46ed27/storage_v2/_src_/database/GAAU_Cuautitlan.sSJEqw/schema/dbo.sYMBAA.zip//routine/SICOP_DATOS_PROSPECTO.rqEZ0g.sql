CREATE      PROCEDURE SICOP_DATOS_PROSPECTO
@p_str_id_prospecto NVARCHAR(15)
AS
SELECT P.C_Clave,
P.N_Nombre,
P.N_NombreCorto,
P.Contacto,
P.Recomendo,
P.[Clave Influencia],
N.[Descripción  Influencia],
P.[Estado Civil],
P.[Club Social],
P.[Fecha  de cumpleaños],
P.[Numero de hijos mayores],
P.[Aficiones particulares],
P.Puesto,
U.N_descripcion AS Desc_Puesto,
P.Calle,
P.Colonia,
P.Delegacion,
P.Ciudad,
P.Cp,
P.[País],
P.Telefono1,
P.Telefono2,
P.Fax,
P.[E-mail],
P.[Envío de correo a dirección particular],
P.[Calle Trabajo],
P.[Colonia Trabajo],
P.[Delegacion Trabajo],
P.[Ciudad Trabajo],
P.[CP Trabajo],
P.[País Trabajo],
P.[Telefono1 Trabajo],
P.[Telefono2  Trabajo],
P.[Fax Trabajo],
P.[E-mail Trabajo],
P.[Envío de correo a dirección de trabajo],
P.C_Promotor,
RTrim(R.N_nombre)+' '+RTrim(R.A_paterno)+' '+RTrim(R.A_Materno) AS Nombre_Vendedor,
P.C_Sector,
S.N_descripcion AS Desc_Sector,
P.C_CierreVenta,
C.[N_descripcion] AS Desc_Cierre,
P.Status,
T.[N_descripcion],
P.fuente,
F.[N_descripcion] AS Desc_Fuente,
P.[Fecha Primer contacto],
P.ObservacionesCliente,
P.[Monto a invertir],
P.[Tiempo para adquirir auto],
P.[Tipo de persona],
[Auto nuevo],
P.[Tipo primer contacto],
P.[Tipo de Compra],
P.Apellido_Paterno,
P.Apellido_Materno,
P.Nombre_Pila,
P.Clave_Titulo,
L.Descripcion_Titulo,
P.Cargo,
P.Sexo,
P.[Registro editado],
P.Reg_Recibido,
P.TRATAMIENTO,
P.Ext_Trabajo1,
P.Ext_Trabajo2,
(Select Count(*) from SICOP_REASIGNABLES_EXT A where a.C_Prospecto=P.C_Clave) as SWAT
FROM Promotor AS R
RIGHT JOIN (Sicop_Titulos AS L
RIGHT JOIN (Sector AS S
RIGHT JOIN ([Nivel de influencia] AS N
RIGHT JOIN (Status AS T
RIGHT JOIN (Puestos AS U
RIGHT JOIN ([Cierres de venta] AS C
RIGHT JOIN (Fuente AS F
RIGHT JOIN Prospecto AS P
ON F.C_Clave = P.fuente)
ON C.C_Clave = P.C_CierreVenta)
ON U.C_Clave = P.Puesto)
ON T.C_Clave = P.Status)
ON N.[Clave Influencia] = P.[Clave Influencia])
ON S.C_Clave = P.C_Sector)
ON L.Clave_Titulo = P.Clave_Titulo)
ON R.C_clave = P.C_Promotor
Where
P.C_Clave= @p_str_id_prospecto
go

