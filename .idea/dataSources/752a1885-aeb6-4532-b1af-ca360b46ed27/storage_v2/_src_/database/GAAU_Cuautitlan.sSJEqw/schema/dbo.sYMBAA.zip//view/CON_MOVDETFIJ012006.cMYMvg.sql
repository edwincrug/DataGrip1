create view 	[dbo].[CON_MOVDETFIJ012006]	 as select * from GAAU_Concentra.dbo.CON_MOVDETFIJ012006
go

