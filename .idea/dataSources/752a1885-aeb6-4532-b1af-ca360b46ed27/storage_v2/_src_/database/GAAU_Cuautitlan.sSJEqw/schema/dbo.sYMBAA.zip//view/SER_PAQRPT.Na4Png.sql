create view [dbo].[SER_PAQRPT] as select * from GAAU_Concentra.dbo.SER_PAQRPT
go

