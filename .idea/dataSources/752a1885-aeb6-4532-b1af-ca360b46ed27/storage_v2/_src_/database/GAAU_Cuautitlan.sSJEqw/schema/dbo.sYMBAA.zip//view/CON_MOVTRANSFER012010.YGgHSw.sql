create view [dbo].[CON_MOVTRANSFER012010] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012010
go

