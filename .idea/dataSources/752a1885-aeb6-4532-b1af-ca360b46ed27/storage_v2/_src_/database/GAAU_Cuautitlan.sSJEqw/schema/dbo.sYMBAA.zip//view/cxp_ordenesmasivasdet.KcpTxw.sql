Create View [dbo].[cxp_ordenesmasivasdet] as select * from [GAAU_Concentra].dbo.cxp_ordenesmasivasdet
go

