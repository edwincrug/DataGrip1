create view 	[dbo].[CON_POLFIJ012012]	 as select * from GAAU_Concentra.dbo.CON_POLFIJ012012
go

