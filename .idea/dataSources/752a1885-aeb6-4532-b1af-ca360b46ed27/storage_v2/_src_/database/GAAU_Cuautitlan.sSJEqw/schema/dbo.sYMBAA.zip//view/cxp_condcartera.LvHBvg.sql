create view [dbo].[cxp_condcartera] as select * from GAAU_Concentra.dbo.cxp_condcartera
go

