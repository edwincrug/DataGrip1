create view 	[dbo].[CON_POLFIJ012005]	 as select * from GAAU_Concentra.dbo.CON_POLFIJ012005
go

