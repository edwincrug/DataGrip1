create view 	[dbo].[CON_POLFIJ012007]	 as select * from GAAU_Concentra.dbo.CON_POLFIJ012007
go

