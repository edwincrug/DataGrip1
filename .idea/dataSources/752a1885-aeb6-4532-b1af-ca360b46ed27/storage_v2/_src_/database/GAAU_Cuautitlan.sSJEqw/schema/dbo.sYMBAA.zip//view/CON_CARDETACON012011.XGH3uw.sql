create view 	[dbo].[CON_CARDETACON012011]	as select * from GAAU_Concentra.dbo.CON_CARDETACON012011
go

