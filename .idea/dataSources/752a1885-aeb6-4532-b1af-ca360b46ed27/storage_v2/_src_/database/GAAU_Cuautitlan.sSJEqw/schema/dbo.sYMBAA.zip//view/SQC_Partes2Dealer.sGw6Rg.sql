create view [dbo].[SQC_Partes2Dealer] as select * from GAAU_Concentra.dbo.SQC_Partes2Dealer
go

