create view 	[dbo].[CON_MOVDET012003]	 as select * from GAAU_Concentra.dbo.CON_MOVDET012003
go

