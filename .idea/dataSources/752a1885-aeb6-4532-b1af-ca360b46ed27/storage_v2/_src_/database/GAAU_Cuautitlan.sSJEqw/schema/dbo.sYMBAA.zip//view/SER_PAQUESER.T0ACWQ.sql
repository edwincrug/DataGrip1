Create VIEW [dbo].[SER_PAQUESER] as select * from GAAU_Concentra.[dbo].SER_PAQUESER
go

