create view 	[dbo].[CON_CARCON012010]	as select * from GAAU_Concentra.dbo.CON_CARCON012010
go

