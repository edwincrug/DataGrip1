create view [dbo].[ADE_CANCFDMN] as select * from GAAU_Concentra.dbo.ADE_CANCFDMN
go

