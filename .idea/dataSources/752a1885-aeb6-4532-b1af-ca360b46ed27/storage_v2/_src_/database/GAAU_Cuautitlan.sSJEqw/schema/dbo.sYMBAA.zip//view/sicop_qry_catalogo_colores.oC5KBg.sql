CREATE VIEW [dbo].[sicop_qry_catalogo_colores]
AS
SELECT DISTINCT 
    COL_CLAVE AS Clave_color, 
    COL_DESCRIPCION + ' int' AS Nombre_color
FROM UNI_CATACOLOR
WHERE (COL_TIPO = 'INTERIOR') AND (COL_MODELO = '2002')
go

