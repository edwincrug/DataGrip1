CREATE VIEW [dbo].[FAE_ASOCCATSAT] AS Select * From GAAU_Concentra.dbo.FAE_ASOCCATSAT
go

