create view [dbo].[CON_MOVCHEQUE012005] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012005
go

