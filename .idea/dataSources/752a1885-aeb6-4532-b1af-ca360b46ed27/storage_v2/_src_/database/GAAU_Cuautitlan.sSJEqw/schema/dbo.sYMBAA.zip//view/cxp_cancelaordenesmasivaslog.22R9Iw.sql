CREATE VIEW [dbo].[cxp_cancelaordenesmasivaslog]
AS
SELECT        oml_idcancelaordenesmasivaslog, oml_descripcionerror, oml_fechaerror, oml_estatus, com_idcancelaordenesmasivas
FROM GAAU_Concentra.dbo.cxp_cancelaordenesmasivaslog
go

