CREATE VIEW [dbo].[cat_tipocomprobante] AS Select * From GAAU_Concentra.dbo.cat_tipocomprobante
go

