create view [dbo].[cxp_condcred] as select * from GAAU_Concentra.dbo.cxp_condcred
go

