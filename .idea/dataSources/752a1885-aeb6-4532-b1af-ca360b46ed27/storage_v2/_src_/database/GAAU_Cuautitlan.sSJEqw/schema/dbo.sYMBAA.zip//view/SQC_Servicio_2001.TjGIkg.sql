create view [dbo].[SQC_Servicio_2001] as select * from GAAU_Concentra.dbo.SQC_Servicio_2001
go

