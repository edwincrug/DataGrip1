CREATE  Procedure SICOP_UP_FEC_PRI_CTO_PROS
 @p_str_clave_prospecto NVARCHAR(15),
 @Fecha datetime = Null
As
Declare @FechaFinal datetime
if @Fecha is null
  Begin
Set @FechaFinal =convert(NVARCHAR,getdate(),101)
  End
 Else
  Begin
    Set @FechaFinal =@Fecha
  End
Update
Prospecto
Set
[Fecha Primer contacto]=@FechaFinal
Where
[C_clave]=@p_str_clave_prospecto
go

