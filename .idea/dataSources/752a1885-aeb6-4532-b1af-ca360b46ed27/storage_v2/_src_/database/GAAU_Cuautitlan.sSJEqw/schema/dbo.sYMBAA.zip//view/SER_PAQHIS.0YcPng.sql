create view [dbo].[SER_PAQHIS] as select * from GAAU_Concentra.dbo.SER_PAQHIS
go

