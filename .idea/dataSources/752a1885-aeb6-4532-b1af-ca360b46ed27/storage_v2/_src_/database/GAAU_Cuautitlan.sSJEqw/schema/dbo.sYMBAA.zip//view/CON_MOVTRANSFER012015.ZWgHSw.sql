create view [dbo].[CON_MOVTRANSFER012015] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012015
go

