create view 	[dbo].[CON_POL012009]	 as select * from GAAU_Concentra.dbo.CON_POL012009
go

