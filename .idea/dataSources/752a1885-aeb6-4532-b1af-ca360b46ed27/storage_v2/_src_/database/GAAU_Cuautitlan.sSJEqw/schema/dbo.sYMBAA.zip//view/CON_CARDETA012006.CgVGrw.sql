create view 	[dbo].[CON_CARDETA012006]	as select * from GAAU_Concentra.dbo.CON_CARDETA012006
go

