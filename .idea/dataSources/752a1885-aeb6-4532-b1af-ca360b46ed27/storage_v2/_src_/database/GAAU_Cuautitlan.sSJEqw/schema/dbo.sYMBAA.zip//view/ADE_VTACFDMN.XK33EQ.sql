create view [dbo].[ADE_VTACFDMN] as select * from GAAU_Concentra.dbo.ADE_VTACFDMN
go

