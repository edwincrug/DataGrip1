CREATE VIEW [dbo].[cat_tipoorden] AS 
SELECT 
ctc_idtipoorden, ctc_nombrecorto, ctc_nombre, ctc_descripcion, ctc_idusuarioalta, ctc_fechaalta, ctc_idusuariomodifica, ctc_fechamodifica, ctc_estatus
FROM       CUENTASPORCOBRAR.dbo.cat_tipoorden;
go

