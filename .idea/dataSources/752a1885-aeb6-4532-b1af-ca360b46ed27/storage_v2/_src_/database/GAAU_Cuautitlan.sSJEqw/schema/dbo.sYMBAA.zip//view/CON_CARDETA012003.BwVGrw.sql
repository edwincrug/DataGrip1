create view 	[dbo].[CON_CARDETA012003]	as select * from GAAU_Concentra.dbo.CON_CARDETA012003
go

