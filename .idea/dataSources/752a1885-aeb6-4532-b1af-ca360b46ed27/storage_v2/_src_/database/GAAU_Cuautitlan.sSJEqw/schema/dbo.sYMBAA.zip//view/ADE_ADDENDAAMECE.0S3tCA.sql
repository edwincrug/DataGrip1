create view [dbo].[ADE_ADDENDAAMECE] as select * from GAAU_Concentra.dbo.ADE_ADDENDAAMECE
go

