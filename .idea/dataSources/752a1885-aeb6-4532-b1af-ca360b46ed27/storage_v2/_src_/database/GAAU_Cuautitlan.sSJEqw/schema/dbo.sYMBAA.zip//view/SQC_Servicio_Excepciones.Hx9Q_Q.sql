create view [dbo].[SQC_Servicio_Excepciones] as select * from GAAU_Concentra.dbo.SQC_Servicio_Excepciones
go

