create view [dbo].[CON_GCFDI012016] as select * from [GAAU_Concentra].dbo.[CON_GCFDI012016]
go

