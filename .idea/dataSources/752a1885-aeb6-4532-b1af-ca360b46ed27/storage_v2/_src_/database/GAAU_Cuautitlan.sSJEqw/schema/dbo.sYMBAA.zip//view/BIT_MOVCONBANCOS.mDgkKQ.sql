-- vista en operativa con relacion a concentradora

CREATE VIEW [dbo].[BIT_MOVCONBANCOS]
AS
SELECT * FROM GAAU_Concentra.DBO.BIT_MOVCONBANCOS
go

