create view [dbo].[PAR_REEMPLAZOS] as select * from GAAU_Concentra.dbo.PAR_REEMPLAZOS
go

