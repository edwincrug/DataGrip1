create view [dbo].[CON_CFDI012005] as select * from [GAAU_Concentra].dbo.[con_cfdi012005]
go

