create view [dbo].[SQC_Servicio_99] as select * from GAAU_Concentra.dbo.SQC_Servicio_99
go

