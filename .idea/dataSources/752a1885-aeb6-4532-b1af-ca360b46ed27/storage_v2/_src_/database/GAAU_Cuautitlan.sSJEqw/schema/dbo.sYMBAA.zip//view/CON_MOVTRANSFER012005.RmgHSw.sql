create view [dbo].[CON_MOVTRANSFER012005] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012005
go

