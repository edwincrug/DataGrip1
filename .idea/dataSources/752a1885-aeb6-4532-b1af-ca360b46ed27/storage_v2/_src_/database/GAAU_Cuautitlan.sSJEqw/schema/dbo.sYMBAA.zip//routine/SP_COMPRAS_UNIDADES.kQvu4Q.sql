
CREATE PROC [dbo].[SP_COMPRAS_UNIDADES] @FECHA_INI VARCHAR(10), @FECHA_FIN VARCHAR(10),@IDPLANTA VARCHAR(5),
@C1 VARCHAR(10),@C2 VARCHAR(10),@C3 VARCHAR(10),@C4 VARCHAR(10),@C5 VARCHAR(10),@C6 VARCHAR(10),@C7 VARCHAR(10),
@C8 VARCHAR(10),@C9 VARCHAR(10),@G1 VARCHAR(10),@G2 VARCHAR(10),@G3 VARCHAR(10),@G4 VARCHAR(10),@G5 VARCHAR(10),
@G6 VARCHAR(10),@G7 VARCHAR(10),@G8 VARCHAR(10),@G9 VARCHAR(10),@A1 VARCHAR(10),@A2 VARCHAR(10),@A3 VARCHAR(10),
@A4 VARCHAR(10),@A5 VARCHAR(10),@A6 VARCHAR(10),@A7 VARCHAR(10),@A8 VARCHAR(10),@A9 VARCHAR(10)
AS

DELETE FROM BI_COMPRA_UNIDADES

SELECT NUMSERIE = VEH_NUMSERIE,STA=0,
sum(case when VHD_TIPO = @C1 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C2 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C3 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C4 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @C5 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C6 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C7 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C8 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @C9 then VHD_COSTO else 0 end) AS COSTO,
sum(case when VHD_TIPO = @G1 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G2 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G3 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G4 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @G5 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G6 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G7 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G8 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @G9 then VHD_COSTO else 0 end) AS GASTOS,  
sum(case when VHD_TIPO = @A1 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A2 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A3 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A4 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @A4 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A6 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A7 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A8 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @A9 then VHD_COSTO else 0 end) AS ADICIONAL, 
SUBTOTAL=CONVERT(DECIMAL(17,2),0), sum(case when VHD_APLICAIVA = 'S' then ROUND((VHD_COSTO * VEH_IVACOM / 100),2) else 0 end) AS IVA, TOTAL =CONVERT(DECIMAL(17,2),0)
INTO #COMPRAS_IMPORTES FROM SER_VEHICULO INNER JOIN UNI_VEHDETA ON VHD_NOSERIE = VEH_NUMSERIE WHERE 
CONVERT(DATETIME,substring(veh_fechreg,1,10),103) BETWEEN CONVERT(DATETIME, @FECHA_INI,103) AND 
CONVERT(DATETIME, @FECHA_FIN,103) GROUP BY VEH_NUMSERIE


INSERT INTO #COMPRAS_IMPORTES 
SELECT NUMSERIE = VEH_NUMSERIE,STA=1,
sum(case when VHD_TIPO = @C1 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C2 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C3 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C4 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @C5 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C6 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C7 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @C8 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @C9 then VHD_COSTO else 0 end) AS COSTO,
sum(case when VHD_TIPO = @G1 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G2 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G3 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G4 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @G5 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G6 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G7 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @G8 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @G9 then VHD_COSTO else 0 end) AS GASTOS,  
sum(case when VHD_TIPO = @A1 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A2 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A3 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A4 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @A4 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A6 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A7 then VHD_COSTO else 0 end) + sum(case when VHD_TIPO = @A8 then VHD_COSTO else 0 end) + 
sum(case when VHD_TIPO = @A9 then VHD_COSTO else 0 end) AS ADICIONAL, 
SUBTOTAL=CONVERT(DECIMAL(17,2),0), sum(case when VHD_APLICAIVA = 'S' then ROUND((VHD_COSTO * VEH_IVACOM / 100),2) else 0 end) AS IVA, TOTAL =CONVERT(DECIMAL(17,2),0)
FROM SER_VEHICULO INNER JOIN UNI_VEHDETA ON VHD_NOSERIE = VEH_NUMSERIE WHERE 
CONVERT(DATETIME,substring(veh_fechcan,1,10),103) BETWEEN CONVERT(DATETIME, @FECHA_INI,103) AND 
CONVERT(DATETIME, @FECHA_FIN,103) GROUP BY VEH_NUMSERIE

UPDATE #COMPRAS_IMPORTES SET SUBTOTAL = COSTO + GASTOS + ADICIONAL , TOTAL = COSTO + GASTOS + ADICIONAL + IVA

--COMPRAS
Select TipoUnidad = 'NUEVOS',NUMSERIE,veh_noinventa as Inventario,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_colointe = col_clave and col_tipo = 'interior') as ColorInterior,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_coloexte = col_clave and col_tipo = 'exterior') as ColorExterior,
veh_anmodelo as Modelo,veh_tipoauto as DescModelo,
(select par_descrip1 from pnc_parametr where par_tipopara = 'MCAV' and par_idenpara = unc_marca) as Marca,
(select par_descrip1 from pnc_parametr where par_tipopara = 'LNA' and par_idenpara = unc_linea) as Segmento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA='CVE' AND PAR_IDENPARA = uni_catalogo.UNC_CLASE) as subtipo_unidad,
UNC_IDCATALOGO,
CarLine = (select PAR_DESCRIP1 from PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'CLI' AND PAR_IDENPARA = uni_catalogo.UNC_FAMILIA),
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'PTA' AND PAR_IDENPARA = unc_ptas) as Puertas,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'CIL' AND PAR_IDENPARA = unc_cilindros) as cilindros,UNC_POTENCIA,
(select par_descrip1 from pnc_parametr where par_tipopara = 'CMB'and par_idenpara = unc_combustible) as Combustible,
unc_capacidad as Capacidad,
(select par_descrip1 from pnc_parametr where par_tipopara = 'TRS' and par_idenpara = unc_transmision) as Transmision,
unc_tipomotor as Tipomotor,veh_orgunidad as Procedencia,
VEH_NOFACTPLAN,VEH_FECREMISION,veh_nopedimtoext as NumPedimento,
veh_fecpedimtoext as FechaPedimento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'TIPOCOMPRA' AND PAR_IDENPARA = veh_tipocompra) AS TipoCompra,
VEH_FECRETIRO as fecha_asignacion,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
VEH_TIPFINANC,B.PAR_DESCRIP1,C.PAR_DESCRIP1 AS PROVEEDOR,
DESCRIPCION_PROVEEDOR = CASE WHEN VEH_CONCCANJE <> '' THEN 
(SELECT PER_NOMRAZON+ ' '+ PER_PATERNO+' '+PER_MATERNO FROM PER_PERSONAS WHERE PER_IDPERSONA = VEH_CONCCANJE)
ELSE (SELECT PER_NOMRAZON+ ' '+ PER_PATERNO+' '+PER_MATERNO FROM PER_PERSONAS WHERE PER_IDPERSONA = @IDPLANTA) END,
ISNULL((SELECT USU_APUSUARI+' '+USU_AMUSUARI+' '+USU_NOUSUARI 
FROM PNC_USUARIOS WHERE USU_IDUSUARI =(SELECT TOP 1 VHT_CVEUSU FROM UNI_VEHICULOHIST WHERE VHT_NUMSERIE = 
VEH_NUMSERIE  ORDER BY VHT_ID, VHT_NUMSERIE)),'') AS COMPRADOR,
(SELECT PAR_DESCRIP1 from pnc_parametr where PAR_TIPOPARA='SN' AND PAR_IDENPARA= VEH_SITUACION) AS  VEH_SITUACION,
COSTO,GASTOS,ADICIONAL,SUBTOTAL,IVA,TOTAL,
--campos seminuevos
veh_noplacas='',veh_nomotor='',veh_kilometr='',veh_sfecadqui='',tipoauto='',origen='',veh_nofact='',
situacion_clave='',nombre='',tipoprv='', veh_spol='',vendedor='', acuenta='',veh_fechreg='',veh_fechcan='',SEM_Comprador ='',
VENDEDOR_NVO='',TP='', veh_impfactplan=0,veh_simppvta=0,veh_impfact=0,veh_ssubtotal=0,veh_siva=0,veh_sctoacond=0,
total_compra=0,accesorios=0,STA
, CASE WHEN (VEH_FOLIOORDEN IS NULL OR VEH_FOLIOORDEN = '') AND (VEH_CONCCANJE IS NOT NULL AND VEH_CONCCANJE <> '')
	THEN (
			SELECT O.oce_folioorden
			FROM controlaplicaciones.dbo.cat_sucursales S
			INNER JOIN cuentasxpagar.dbo.cxp_ordencompra O WITH(NOLOCK) ON S.emp_idempresa = O.oce_idempresa AND S.suc_idsucursal = O.oce_idsucursal
			INNER JOIN cuentasxpagar.dbo.cxp_detalleautosnuevos D WITH(NOLOCK) ON O.oce_folioorden = D.oce_folioorden
			WHERE S.suc_nombrebd = (DB_NAME())
			AND D.anu_numeroserie = NUMSERIE COLLATE Modern_Spanish_CI_AS
			AND O.oce_idproveedor = VEH_CONCCANJE COLLATE Modern_Spanish_CI_AS
	) ELSE ISNULL(VEH_FOLIOORDEN COLLATE Modern_Spanish_CI_AS, '') END FolioOrden
INTO #COMPRA
from ser_vehiculo,#COMPRAS_IMPORTES,uni_catalogo,PNC_PARAMETR AS B, PNC_PARAMETR AS C
where veh_numserie = NUMSERIE AND unc_idcatalogo = veh_catalogo and unc_modelo = veh_anmodelo
AND VEH_TIPFINANC = B.PAR_IDENPARA AND B.PAR_TIPOPARA = 'TIPFIN'
AND VEH_TIPENTRADA = C.PAR_IDENPARA AND C.PAR_TIPOPARA = 'TIPENT'


UPDATE #COMPRA SET VEH_SITUACION = 'CANCELADA', COSTO = COSTO * -1, GASTOS = GASTOS * -1, 
ADICIONAL = ADICIONAL * -1, SUBTOTAL = SUBTOTAL * -1, IVA = IVA * -1, TOTAL = TOTAL * -1 WHERE STA = 1

--INSERTA NUEVOS
INSERT INTO BI_COMPRA_UNIDADES 
SELECT TipoUnidad,NUMSERIE,Inventario,ColorInterior,ColorExterior,Modelo,DescModelo,Marca,Segmento,subtipo_unidad,UNC_IDCATALOGO,
CarLine,Puertas,cilindros,UNC_POTENCIA,Combustible,Capacidad,Transmision,Tipomotor,Procedencia,VEH_NOFACTPLAN,
VEH_FECREMISION,NumPedimento,FechaPedimento,TipoCompra,fecha_asignacion,financiera,VEH_TIPFINANC,
PAR_DESCRIP1,PROVEEDOR,DESCRIPCION_PROVEEDOR,COMPRADOR,VEH_SITUACION,COSTO,GASTOS,ADICIONAL,SUBTOTAL,IVA,TOTAL,
veh_noplacas,veh_nomotor,veh_kilometr,veh_sfecadqui,tipoauto,origen,veh_nofact,situacion_clave,nombre,tipoprv, 
veh_spol,vendedor,acuenta,veh_fechreg,veh_fechcan,SEM_Comprador,VENDEDOR_NVO,TP,veh_impfactplan,veh_simppvta,
veh_impfact,veh_ssubtotal,veh_siva,veh_sctoacond,total_compra,accesorios,Unidades = CASE WHEN STA = 0 THEN 1 ELSE -1 END
, FolioOrden 
FROM #COMPRA

--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------

INSERT INTO BI_COMPRA_UNIDADES 
select TipoUnidad = 'SEMINUEVOS',veh_numserie,veh_noinventa,veh_colointe,veh_coloexte,veh_anmodelo,veh_tipoauto,
b.par_descrip1 as marca,'AUTOS' as Segmento,'AUTOS' as subtipo_unidad,UNC_IDCATALOGO = '',CarLine = '',
case when veh_puertas = 'ISNULL' or ltrim(rtrim(veh_puertas)) = '' or isnumeric (veh_puertas)<> 1 then '0' else veh_puertas end as Puertas,
case when veh_cilindros = 'ISNULL' or ltrim(rtrim(veh_cilindros)) = '' then '0' else veh_cilindros end as cilindros,
UNC_POTENCIA = '',veh_combustible as Combustible,
case when veh_capacidad = 'ISNULL' or ltrim(rtrim(veh_capacidad)) = '' then '0' else '0' end  as Capacidad,
'' as Transmision,'' as Tipomotor,veh_orgunidad as Procedencia,
VEH_NOFACTPLAN,VEH_FECREMISION,veh_nopedimtoext as NumPedimento,veh_fecpedimtoext as FechaPedimento,
tipoadq.par_descrip1 as tipocomp,VEH_FECRETIRO as fecha_asignacion,'' AS financiera,'' AS VEH_TIPFINANC,
'' AS OTRO,'' AS PROVEEDOR,DESCRIPCION_PROVEEDOR = '','' AS COMPRADOR,a.par_descrip1 as situacion,
COSTO=0,GASTOS=0,ADICIONAL=0,SUBTOTAL=0,IVA=0,TOTAL=0,
veh_noplacas,veh_nomotor,veh_kilometr,veh_sfecadqui,c.par_descrip1 as tipoauto,d.par_descrip1 as origen,
veh_nofact,a.par_idenpara as situacion_clave,
(case personas.per_tipo when 'mor' then personas.per_nomrazon else personas.per_nomrazon + ' ' + personas.per_paterno + ' ' + personas.per_materno end) as nombre,
(case personas.per_tipo when 'mor' then 'MORAL' when 'fis' then 'FISICA' when 'fie'then 'FISICA C/ ACT. EMP.' end) as tipoprv, 
case when isnull(veh_spol,0) = 0 then 'UNIDAD SEMINUEVA PROPIA' else 'UNIDAD SEMINUEVA EN CONSIGANCION' end as veh_spol,
(Select VEN.PAR_DESCRIP1 From Pnc_parametr AS VEN Where VEN.Par_Tipopara ='EV' AND VEN.par_status='A' AND VEN.PAR_IDENPARA = PEDI.PMS_VENDEDOR) AS vendedor, 
acuenta.par_descrip2 as acuenta,substring(veh_fechreg,1,10) as veh_fechreg, substring(veh_fechcan ,1,10) as veh_fechcan,
rtrim(ltrim(isnull(USU_NOUSUARI,'') + ' ' + isnull(USU_APUSUARI,'') + ' ' + isnull(USU_AMUSUARI,''))) as SEM_Comprador,
(Select VEN.par_descrip1 From Pnc_parametr AS VEN Where VEN.Par_Tipopara = 'EV' AND VEN.PAR_IDENPARA = SER_VEHICULO.VEH_TOMAUSNVEND) AS VENDEDOR_NVO,
TP.PAR_DESCRIP1 AS TP, veh_impfactplan,veh_simppvta,veh_impfact,veh_ssubtotal,veh_siva,veh_sctoacond,
isnull(sum(usd_total),0) + veh_impfactplan as total_compra,
isnull(sum(usd_total),0) as accesorios,Unidades=1
, CASE WHEN (VEH_FOLIOORDEN IS NULL OR VEH_FOLIOORDEN = '') AND (VEH_NOFACTPLAN IS NOT NULL AND VEH_NOFACTPLAN <> '')
	THEN (
			SELECT O.oce_folioorden
			FROM controlaplicaciones.dbo.cat_sucursales S
			INNER JOIN cuentasxpagar.dbo.cxp_ordencompra O WITH(NOLOCK) ON S.emp_idempresa = O.oce_idempresa AND S.suc_idsucursal = O.oce_idsucursal
			INNER JOIN cuentasxpagar.dbo.cxp_detalleseminuevos D WITH(NOLOCK) ON O.oce_folioorden = D.oce_folioorden
			WHERE S.suc_nombrebd = (DB_NAME())
			AND D.asn_numeroserie = veh_numserie COLLATE Modern_Spanish_CI_AS
			AND O.oce_factura = VEH_NOFACTPLAN COLLATE Modern_Spanish_CI_AS
	) ELSE ISNULL(VEH_FOLIOORDEN COLLATE Modern_Spanish_CI_AS, '') END FolioOrden
FROM ser_vehiculo LEFT OUTER JOIN usn_semideta ON 
veh_numserie = usd_numserie AND usd_estatus = '1' INNER JOIN pnc_parametr AS a ON veh_situacion = a.par_idenpara 
INNER JOIN  pnc_parametr AS b ON veh_smarca = b.par_idenpara INNER JOIN  pnc_parametr AS c ON veh_stipo = c.par_idenpara
INNER JOIN pnc_parametr AS d ON veh_orgunidad = d.par_idenpara LEFT OUTER JOIN pnc_parametr AS tipoadq ON 
veh_stipadqui = tipoadq.par_idenpara AND tipoadq.par_tipopara ='tadq' and tipoadq.par_status = 'a' LEFT OUTER JOIN 
per_personas AS personas ON veh_distvend = convert( varchar, personas.per_idpersona ) LEFT OUTER JOIN usn_pedido 
AS pedi ON Veh_Numserie = pedi.PMS_Numserie AND pedi.PMS_STATUS = 'I' LEFT OUTER JOIN pnc_parametr AS acuenta ON 
veh_acuenta = acuenta.par_idenpara AND acuenta.par_tipopara = 'unacam' and acuenta.par_status = 'A' 
LEFT OUTER JOIN PNC_USUARIOS AS USU ON VEH_CVEUSU = USU.USU_IDUSUARI LEFT OUTER JOIN PNC_PARAMETR AS TP ON 
veh_stipadqui = TP.PAR_IDENPARA AND TP.PAR_TIPOPARA = 'TADQ'  WHERE a.par_tipopara = 'sn' and 
a.par_descrip2 = 'seminuevos' and b.par_tipopara = 'mcav' and c.par_tipopara = 'cve' and d.par_tipopara = 'or' 
and veh_sfecadqui <> '' and convert(datetime,substring(veh_fechreg,1,10),103) between convert(datetime,substring(@FECHA_INI,1,10),103) 
and convert(datetime,substring(@FECHA_FIN,1,10),103) group by veh_noinventa,veh_numserie,veh_tipoauto,veh_noplacas,veh_coloexte,
veh_colointe,veh_nomotor,veh_impfactplan,veh_simppvta,veh_anmodelo,veh_kilometr,veh_sfecadqui,a.par_descrip1, 
b.par_descrip1,c.par_descrip1,d.par_descrip1,veh_nofact,veh_impfact,veh_ssubtotal,veh_siva,veh_sctoacond,
veh_nofactplan,tipoadq.par_descrip1,a.par_idenpara,personas.per_tipo,personas.per_nomrazon,personas.per_paterno, 
personas.per_materno,veh_spol ,pedi.PMS_VENDEDOR, acuenta.par_descrip2,veh_sfecadqui,veh_fechreg,veh_fechcan ,
USU_NOUSUARI,USU_APUSUARI,USU_AMUSUARI,TP.PAR_DESCRIP1, VEH_TOMAUSNVEND,ser_vehiculo.veh_puertas,
veh_cilindros,veh_combustible,veh_capacidad,VEH_ORGUNIDAD,
VEH_FECREMISION,veh_fecpedimtoext,VEH_NOPEDIMTOEXT,VEH_FECRETIRO, VEH_FOLIOORDEN
order by convert(datetime, veh_sfecadqui, 103)


INSERT INTO BI_COMPRA_UNIDADES 
select TipoUnidad = 'SEMINUEVOS',veh_numserie,veh_noinventa,veh_colointe,veh_coloexte,veh_anmodelo,veh_tipoauto,
b.par_descrip1 as marca,'AUTOS' as Segmento,'AUTOS' as subtipo_unidad,UNC_IDCATALOGO = '',CarLine = '',
case when veh_puertas = 'ISNULL' or ltrim(rtrim(veh_puertas)) = '' or isnumeric (veh_puertas)<> 1 then '0' else veh_puertas end as Puertas,
case when veh_cilindros = 'ISNULL' or ltrim(rtrim(veh_cilindros)) = '' then '0' else veh_cilindros end as cilindros,
UNC_POTENCIA = '',veh_combustible as Combustible,
case when veh_capacidad = 'ISNULL' or ltrim(rtrim(veh_capacidad)) = '' then '0' else '0' end  as Capacidad,
'' as Transmision,'' as Tipomotor,veh_orgunidad as Procedencia,
VEH_NOFACTPLAN,VEH_FECREMISION,veh_nopedimtoext as NumPedimento,veh_fecpedimtoext as FechaPedimento,
tipoadq.par_descrip1 as tipocomp,VEH_FECRETIRO as fecha_asignacion,'' AS financiera,'' AS VEH_TIPFINANC,
'' AS OTRO,'' AS PROVEEDOR,DESCRIPCION_PROVEEDOR = '','' AS COMPRADOR,a.par_descrip1 as situacion,
COSTO=0,GASTOS=0,ADICIONAL=0,SUBTOTAL=0,IVA=0,TOTAL=0,
veh_noplacas,veh_nomotor,veh_kilometr,veh_sfecadqui,c.par_descrip1 as tipoauto,d.par_descrip1 as origen,
veh_nofact,a.par_idenpara as situacion_clave,
(case personas.per_tipo when 'mor' then personas.per_nomrazon else personas.per_nomrazon + ' ' + personas.per_paterno + ' ' + personas.per_materno end) as nombre,
(case personas.per_tipo when 'mor' then 'MORAL' when 'fis' then 'FISICA' when 'fie'then 'FISICA C/ ACT. EMP.' end) as tipoprv, 
case when isnull(veh_spol,0) = 0 then 'UNIDAD SEMINUEVA PROPIA' else 'UNIDAD SEMINUEVA EN CONSIGANCION' end as veh_spol,
(Select VEN.PAR_DESCRIP1 From Pnc_parametr AS VEN Where VEN.Par_Tipopara ='EV' AND VEN.par_status='A' AND VEN.PAR_IDENPARA = PEDI.PMS_VENDEDOR) AS vendedor, 
acuenta.par_descrip2 as acuenta,substring(veh_fechreg,1,10) as veh_fechreg, substring(veh_fechcan ,1,10) as veh_fechcan,
rtrim(ltrim(isnull(USU_NOUSUARI,'') + ' ' + isnull(USU_APUSUARI,'') + ' ' + isnull(USU_AMUSUARI,''))) as SEM_Comprador,
(Select VEN.par_descrip1 From Pnc_parametr AS VEN Where VEN.Par_Tipopara = 'EV' AND VEN.PAR_IDENPARA = SER_VEHICULO.VEH_TOMAUSNVEND) AS VENDEDOR_NVO,
TP.PAR_DESCRIP1 AS TP, veh_impfactplan = ISNULL(veh_impfactplan,0) * -1 ,veh_simppvta = ISNULL(veh_simppvta,0) * -1,
veh_impfact = ISNULL(veh_impfact,0) * -1, veh_ssubtotal = ISNULL(veh_ssubtotal,0) * -1, 
veh_siva = ISNULL(veh_siva,0) * -1, veh_sctoacond = ISNULL(veh_sctoacond,0) * -1,
isnull(sum(usd_total),0) * -1 + ISNULL(veh_impfactplan,0) * -1 as total_compra,
isnull(sum(usd_total),0) * -1 as accesorios,Unidad=-1
, CASE WHEN (VEH_FOLIOORDEN IS NULL OR VEH_FOLIOORDEN = '') AND (VEH_NOFACTPLAN IS NOT NULL AND VEH_NOFACTPLAN <> '')
	THEN (
			SELECT O.oce_folioorden
			FROM controlaplicaciones.dbo.cat_sucursales S
			INNER JOIN cuentasxpagar.dbo.cxp_ordencompra O WITH(NOLOCK) ON S.emp_idempresa = O.oce_idempresa AND S.suc_idsucursal = O.oce_idsucursal
			INNER JOIN cuentasxpagar.dbo.cxp_detalleseminuevos D WITH(NOLOCK) ON O.oce_folioorden = D.oce_folioorden
			WHERE S.suc_nombrebd = (DB_NAME())
			AND D.asn_numeroserie = veh_numserie COLLATE Modern_Spanish_CI_AS
			AND O.oce_factura = VEH_NOFACTPLAN COLLATE Modern_Spanish_CI_AS
	) ELSE ISNULL(VEH_FOLIOORDEN COLLATE Modern_Spanish_CI_AS, '') END FolioOrden
FROM ser_vehiculo LEFT OUTER JOIN usn_semideta ON 
veh_numserie = usd_numserie AND usd_estatus = '1' INNER JOIN pnc_parametr AS a ON veh_situacion = a.par_idenpara 
INNER JOIN  pnc_parametr AS b ON veh_smarca = b.par_idenpara INNER JOIN  pnc_parametr AS c ON veh_stipo = c.par_idenpara
INNER JOIN pnc_parametr AS d ON veh_orgunidad = d.par_idenpara LEFT OUTER JOIN pnc_parametr AS tipoadq ON 
veh_stipadqui = tipoadq.par_idenpara AND tipoadq.par_tipopara ='tadq' and tipoadq.par_status = 'a' LEFT OUTER JOIN 
per_personas AS personas ON veh_distvend = convert( varchar, personas.per_idpersona ) LEFT OUTER JOIN usn_pedido 
AS pedi ON Veh_Numserie = pedi.PMS_Numserie AND pedi.PMS_STATUS = 'I' LEFT OUTER JOIN pnc_parametr AS acuenta ON 
veh_acuenta = acuenta.par_idenpara AND acuenta.par_tipopara = 'unacam' and acuenta.par_status = 'A' 
LEFT OUTER JOIN PNC_USUARIOS AS USU ON VEH_CVEUSU = USU.USU_IDUSUARI LEFT OUTER JOIN PNC_PARAMETR AS TP ON 
veh_stipadqui = TP.PAR_IDENPARA AND TP.PAR_TIPOPARA = 'TADQ'  WHERE a.par_tipopara = 'sn' and 
a.par_descrip2 = 'seminuevos' and b.par_tipopara = 'mcav' and c.par_tipopara = 'cve' and d.par_tipopara = 'or' 
and veh_sfecadqui <> '' and convert(datetime,substring(veh_fechcan,1,10),103) between convert(datetime,substring(@FECHA_INI,1,10),103)
and convert(datetime,substring(@FECHA_FIN,1,10),103) group by VEH_IDCLIENT,veh_noinventa,
veh_numserie,veh_tipoauto,veh_noplacas,veh_tomausn,veh_coloexte,veh_colointe,veh_nomotor,(veh_impfactplan*-1),
(veh_simppvta*-1),veh_anmodelo,veh_kilometr,veh_sfecadqui,a.par_descrip1, b.par_descrip1,c.par_descrip1,d.par_descrip1,
veh_nofact,veh_impfact,(isnull(veh_ssubtotal,0)*-1),(isnull(veh_siva,0)*-1),veh_sctoacond,veh_nofactplan,tipoadq.par_descrip1,a.par_idenpara,
personas.per_tipo,personas.per_nomrazon,personas.per_paterno, personas.per_materno,veh_spol ,pedi.PMS_VENDEDOR, 
acuenta.par_descrip2,veh_sfecadqui,veh_fechreg,veh_fechcan,USU_NOUSUARI,USU_APUSUARI,USU_AMUSUARI,tp.par_descrip1, 
VEH_TOMAUSNVEND,veh_puertas,veh_cilindros,veh_combustible,veh_capacidad,VEH_ORGUNIDAD,VEH_FECREMISION,VEH_NOPEDIMTOEXT,
VEH_FECPEDIMTOEXT,VEH_FECRETIRO,VEH_IMPFACTPLAN,VEH_SIMPPVTA,VEH_SSUBTOTAL,VEH_SIVA, VEH_FOLIOORDEN

go

