create view [dbo].[CON_CFDI012014] as select * from [GAAU_Concentra].dbo.[con_cfdi012014]
go

