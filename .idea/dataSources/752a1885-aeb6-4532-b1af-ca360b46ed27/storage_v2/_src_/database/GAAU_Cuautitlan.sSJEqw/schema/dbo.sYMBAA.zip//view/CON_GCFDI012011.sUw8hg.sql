create view [dbo].[CON_GCFDI012011] as select * from [GAAU_Concentra].dbo.[CON_GCFDI012011]
go

