create view 	[dbo].[CON_CAR012008]	as select * from GAAU_Concentra.dbo.CON_CAR012008
go

