create view [dbo].[ADE_CANCFD] as select * from GAAU_Concentra.dbo.ADE_CANCFD
go

