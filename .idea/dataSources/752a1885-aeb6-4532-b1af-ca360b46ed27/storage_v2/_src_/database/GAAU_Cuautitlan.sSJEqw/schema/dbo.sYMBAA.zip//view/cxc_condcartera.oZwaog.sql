create view [dbo].[cxc_condcartera] as select * from GAAU_Concentra.dbo.cxc_condcartera
go

