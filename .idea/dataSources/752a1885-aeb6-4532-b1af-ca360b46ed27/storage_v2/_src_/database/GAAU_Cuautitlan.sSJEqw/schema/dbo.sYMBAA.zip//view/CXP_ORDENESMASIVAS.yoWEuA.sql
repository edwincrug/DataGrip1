
Create VIEW [dbo].[CXP_ORDENESMASIVAS] as select * from GAAU_Concentra.[dbo].CXP_ORDENESMASIVAS
go

