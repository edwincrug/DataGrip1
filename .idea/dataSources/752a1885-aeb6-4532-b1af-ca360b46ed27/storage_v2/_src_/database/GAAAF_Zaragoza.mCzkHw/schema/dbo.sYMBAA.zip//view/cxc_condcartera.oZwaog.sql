create view [dbo].[cxc_condcartera] as select * from GAAAF_CONCENTRA.dbo.cxc_condcartera
go

