create view [dbo].[ADE_ADDENDAAMECE] as select * from GAAAF_Concentra.dbo.ADE_ADDENDAAMECE
go

