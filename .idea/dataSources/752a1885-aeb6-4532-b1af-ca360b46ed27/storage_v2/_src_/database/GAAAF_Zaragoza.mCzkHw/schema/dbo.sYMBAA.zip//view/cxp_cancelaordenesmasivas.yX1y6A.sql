
CREATE VIEW [dbo].[cxp_cancelaordenesmasivas]
AS
SELECT *
FROM GAAAF_Concentra.dbo.cxp_cancelaordenesmasivas

go

