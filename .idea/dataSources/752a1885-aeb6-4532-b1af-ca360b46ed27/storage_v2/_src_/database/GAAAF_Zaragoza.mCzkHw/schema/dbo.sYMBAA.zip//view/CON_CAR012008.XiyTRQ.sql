create view 	[dbo].[CON_CAR012008]	as select * from GAAAF_Concentra.dbo.CON_CAR012008
go

