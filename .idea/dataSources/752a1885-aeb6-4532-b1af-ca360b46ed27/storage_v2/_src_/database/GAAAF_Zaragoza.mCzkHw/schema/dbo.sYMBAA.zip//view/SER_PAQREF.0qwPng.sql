create view [dbo].[SER_PAQREF] as select * from GAAAF_Concentra.dbo.SER_PAQREF
go

