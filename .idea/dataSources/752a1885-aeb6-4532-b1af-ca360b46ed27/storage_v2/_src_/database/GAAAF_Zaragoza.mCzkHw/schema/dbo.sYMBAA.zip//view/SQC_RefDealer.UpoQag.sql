create view [dbo].[SQC_RefDealer] as select * from GAAAF_Concentra.dbo.SQC_RefDealer
go

