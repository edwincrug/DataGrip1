create view [dbo].[CON_MOVTRANSFER012006] as select * from GAAAF_Concentra.dbo.CON_MOVTRANSFER012006
go

