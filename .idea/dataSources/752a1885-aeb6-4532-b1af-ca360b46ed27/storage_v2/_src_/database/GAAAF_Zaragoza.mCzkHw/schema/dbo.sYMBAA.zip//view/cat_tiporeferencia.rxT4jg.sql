CREATE VIEW [dbo].[cat_tiporeferencia]
AS
SELECT    *
FROM        GAAAF_CONCENTRA.dbo.cat_tiporeferencia
go

