create view [dbo].[CON_MOVTRANSFER012017] as select * from GAAAF_Concentra.dbo.CON_MOVTRANSFER012017
go

