create view [dbo].[CON_MOVTRANSFER012014] as select * from GAAAF_Concentra.dbo.CON_MOVTRANSFER012014
go

