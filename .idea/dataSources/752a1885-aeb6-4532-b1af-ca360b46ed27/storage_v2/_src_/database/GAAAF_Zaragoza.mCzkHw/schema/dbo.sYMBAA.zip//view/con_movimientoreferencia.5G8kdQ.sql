CREATE VIEW [dbo].[con_movimientoreferencia] AS SELECT * From GAAAF_Concentra.dbo.con_movimientoreferencia
go

