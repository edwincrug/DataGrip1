---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[UNI_ANTICIPOXUNIDADSEM] AS 
SELECT 
AUS_IDCOTIZACIONUNIVERSAL, AUS_NUMSERIE, AUS_FOLIOANTICIPO, AUS_BASETOMA, AUS_CVEUSU, AUS_FECHOPE, AUS_HORAOPE
FROM cuentasporcobrar.dbo.UNI_ANTICIPOXUNIDADSEM;
go

