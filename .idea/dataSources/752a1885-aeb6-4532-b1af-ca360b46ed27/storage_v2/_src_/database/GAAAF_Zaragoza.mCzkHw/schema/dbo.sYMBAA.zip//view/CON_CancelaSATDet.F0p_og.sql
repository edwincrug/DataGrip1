CREATE VIEW [dbo].[CON_CancelaSATDet] AS SELECT * FROM GAAAF_Concentra.dbo.CON_CancelaSATDet
go

