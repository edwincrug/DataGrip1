create view [dbo].[SER_PAQUETES] as select * from GAAAF_Concentra.dbo.SER_PAQUETES
go

