CREATE VIEW [dbo].[cat_situacionpedido]
AS
SELECT spe_idsituacionpedido, spe_nombre, spe_nombrecto, spe_fechaalta, spe_usualta, 
spe_fechamodifica, spe_usumodifica, spe_estatus
FROM PortalRefacciones.dbo.cat_situacionpedido
go

