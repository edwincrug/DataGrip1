

CREATE TRIGGER [dbo].[dig_Trigger_ActualizaEstatusFechaEntregaSEMI] ON [dbo].[USN_PEDIDO] 
FOR UPDATE
AS
	declare @Pen_FechaEntrega_Real varchar(10);
	declare @sBaseDatos varchar(50);
	declare @nucu_idpedidobpro numeric (18,0);
	declare @sucn_noserie varchar(20);
	declare @sipservidorsp varchar(50);
	DECLARE @ipLocal VARCHAR(50);
	DECLARE @sQ nvarchar(1500); 

	select @sipservidorsp='192.168.20.29';
	select @sBaseDatos = DB_NAME() 
	select @Pen_FechaEntrega_Real = i.PMS_FECHAREALENTREGA 		 from inserted i;
	select @nucu_idpedidobpro	 = i.PMS_NUMPEDIDO  			 from inserted i;	
	select @sucn_noserie		 = i.PMS_NUMSERIE				 from inserted i;	
	
 if (ltrim(rtrim(Isnull(@Pen_FechaEntrega_Real,'')))<>'')
   begin	
					
		if update(PMS_FECHAREALENTREGA)
		begin
  				-- Averiguamos si este trigguer se está ejecutando en el servidor donde está el store procedure				
				SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
				FROM sys.dm_exec_connections c
				ORDER BY local_net_address DESC

				if (@ipLocal = @sipservidorsp) --la base de datos está en el mismo servidor donde está la base de Centralizacionv2 la cual contiene al storeprocedure
				begin
					select @sipservidorsp = '';
				end
			else
				begin
					select @sipservidorsp = '[' + @sipservidorsp + '].'
				end

				--spU_UNIDAD_ENTREGADA(@sBaseDatos varchar(50),@nucu_idpedidobpro numeric(18,0) , @sucn_noserie varchar(20))
				
				select @sQ = ''
				set @sQ = @sQ + N' execute '  
				set @sQ = @sQ + N' ' + @sipservidorsp + '[Centralizacionv2].[dbo].[spU_UNIDAD_ENTREGADA] ''' + @sBaseDatos + ''',' + ltrim(rtrim(Convert(char(10),@nucu_idpedidobpro))) + ',''' + @sucn_noserie + '''' 
				--set @sQ = @sQ + N' where PAR_TIPOPARA = ''CONFPGRUP'''

				--set @sParmDefinition = N'@ddblResultado numeric(18,6) OUTPUT'

				 --print @sQ

				--print @sParmDefinition

				--execute sp_executesql @sQ,@sParmDefinition,@ddblResultado = @dblResultado OUTPUT
				 execute sp_executesql @sQ --,@sParmDefinition
						
		end
    end
go

