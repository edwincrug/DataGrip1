create view [dbo].[SER_PAQOPE] as select * from GAAAF_Concentra.dbo.SER_PAQOPE
go

