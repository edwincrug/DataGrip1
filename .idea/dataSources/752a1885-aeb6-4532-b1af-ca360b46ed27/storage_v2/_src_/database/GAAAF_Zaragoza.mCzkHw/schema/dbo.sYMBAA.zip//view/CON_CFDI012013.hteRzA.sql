create view [dbo].[CON_CFDI012013] as select * from [GAAAF_Concentra].dbo.[con_cfdi012013]
go

