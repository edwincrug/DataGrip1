CREATE VIEW [dbo].[DIG_ESCALAMIENTO_AREA_AFECT]
AS
SELECT 
id, emp_idempresa, suc_idsucursal, par_idenpara, otc_area, usuario_autoriza1
FROM      [Centralizacionv2].dbo.DIG_ESCALAMIENTO_AREA_AFECT
go

