create view [dbo].[PAR_ALTERNOS] as select * from GAAAF_Concentra.dbo.PAR_ALTERNOS
go

