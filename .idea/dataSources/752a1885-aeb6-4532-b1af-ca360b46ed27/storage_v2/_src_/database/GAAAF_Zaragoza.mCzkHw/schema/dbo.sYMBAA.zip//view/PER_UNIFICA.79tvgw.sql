create view [dbo].[PER_UNIFICA] as select * from GAAAF_Concentra.dbo.PER_UNIFICA
go

