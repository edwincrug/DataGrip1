create view [dbo].[SQC_OperacionA] as select * from GAAAF_Concentra.dbo.SQC_OperacionA
go

