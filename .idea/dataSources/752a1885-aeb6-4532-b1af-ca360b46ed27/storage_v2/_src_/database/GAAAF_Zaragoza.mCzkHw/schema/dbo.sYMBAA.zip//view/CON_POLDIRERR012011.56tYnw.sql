create view 	[dbo].[CON_POLDIRERR012011]	 as select * from GAAAF_Concentra.dbo.CON_POLDIRERR012011
go

