CREATE VIEW [dbo].[cat_usoCFDI] AS Select * From GAAAF_CONCENTRA.dbo.cat_usoCFDI
go

