create view [dbo].[ADE_ADDENDASCONFIG] as select * from GAAAF_Concentra.dbo.ADE_ADDENDASCONFIG
go

