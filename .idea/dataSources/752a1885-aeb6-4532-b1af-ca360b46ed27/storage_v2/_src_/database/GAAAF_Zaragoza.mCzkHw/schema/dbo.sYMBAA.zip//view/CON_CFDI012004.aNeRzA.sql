create view [dbo].[CON_CFDI012004] as select * from [GAAAF_Concentra].dbo.[con_cfdi012004]
go

