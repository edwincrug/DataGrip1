create view 	[dbo].[CON_MOVDET012012]	 as select * from GAAAF_Concentra.dbo.CON_MOVDET012012
go

