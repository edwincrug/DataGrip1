create view [dbo].[cxp_condcartera] as select * from GAAAF_CONCENTRA.dbo.cxp_condcartera
go

