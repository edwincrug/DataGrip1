create view 	[dbo].[CON_MOVDET012008]	 as select * from GAAAF_Concentra.dbo.CON_MOVDET012008
go

