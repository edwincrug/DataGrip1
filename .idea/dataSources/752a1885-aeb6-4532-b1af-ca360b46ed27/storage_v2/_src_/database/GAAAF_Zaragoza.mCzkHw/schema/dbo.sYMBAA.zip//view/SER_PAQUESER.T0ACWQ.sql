Create VIEW [dbo].[SER_PAQUESER] as select * from GAAAF_Concentra.[dbo].SER_PAQUESER
go

