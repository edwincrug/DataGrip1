create view [dbo].[ADE_CFDREPMENSUAL] as select * from GAAAF_Concentra.dbo.ADE_CFDREPMENSUAL
go

