CREATE VIEW [dbo].[cat_claveprodserv] AS Select * From GAAAF_CONCENTRA.dbo.cat_claveprodserv
go

