create view [dbo].[CON_MOVTRANSFER012007] as select * from GAAAF_Concentra.dbo.CON_MOVTRANSFER012007
go

