create view [dbo].[cxp_condcred] as select * from GAAAF_CONCENTRA.dbo.cxp_condcred
go

