create view [dbo].[SQC_Operacion] as select * from GAAAF_Concentra.dbo.SQC_Operacion
go

