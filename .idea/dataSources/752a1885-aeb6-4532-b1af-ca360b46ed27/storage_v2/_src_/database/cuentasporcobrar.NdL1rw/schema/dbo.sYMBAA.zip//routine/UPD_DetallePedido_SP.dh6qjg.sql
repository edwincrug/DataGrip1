CREATE PROCEDURE [dbo].[UPD_DetallePedido_SP]

@Folio VARCHAR(50) ,
@EstatusAutorizacion INT

AS
BEGIN

DECLARE @IdEn INT
        ,@FolioCotizacion VARCHAR(50)
		,@IdCotizacion INT

DECLARE @Detalles TABLE
(
IdCotizaDetalle INT NULL

)
--select * from uni_cotizacionuniversal where ucu_idcotizacion = 10416

--SELECT @IdEn = SUBSTRING(@Folio,CHARINDEX('|', @Folio)+1, len(@Folio)-CHARINDEX('|', @Folio)+1)
--SELECT @FolioCotizacion = SUBSTRING(@FolioCotizacion,0, CHARINDEX('|', @FolioCotizacion))
SELECT @IdCotizacion = ucu_idcotizacion FROM uni_cotizacionuniversal WHERE ucu_foliocotizacion = @Folio

BEGIN TRY
	INSERT INTO @Detalles
    SELECT ucn_idcotizadetalle FROM UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucu_idcotizacion = @IdCotizacion
	

	


	--ACTUALIZA TRAMITES
	UPDATE cuentasporcobrar.dbo.uni_anticiposweb 
	SET pmd_estatusautorizacion = @EstatusAutorizacion  
	WHERE CEA_IdEstatusAdicionales = 2 AND (pmd_estatusautorizacion is null  OR pmd_estatusautorizacion = 0)
	AND ucn_idcotizadetallepost in (SELECT IdCotizaDetalle FROM @Detalles)

	--ACTUALIZA ACCESORIOS
	UPDATE cuentasporcobrar.dbo.par_pedmostdet
	SET pmd_estatusautorizacion = @EstatusAutorizacion  
	WHERE CEA_IdEstatusAdicionales = 2  AND (pmd_estatusautorizacion is null  OR pmd_estatusautorizacion = 0)
	AND ucn_idcotizadetallepost in (SELECT IdCotizaDetalle FROM @Detalles)

	--ACTUALIZA OTROS CONCEPTOS
	UPDATE cuentasporcobrar.dbo.[uni_otroconceptosdet] 
	SET pmd_estatusautorizacion = @EstatusAutorizacion  
	WHERE CEA_IdEstatusAdicionales = 2 and  (pmd_estatusautorizacion is null  OR pmd_estatusautorizacion = 0)
	AND ucn_idcotizadetallepost in (SELECT IdCotizaDetalle FROM @Detalles)

	--ACTUALIZA PAQUETES DE SERVICIO
	UPDATE cuentasporcobrar.dbo.[uni_preordenser] 
	SET pmd_estatusautorizacion = @EstatusAutorizacion 
	WHERE CEA_IdEstatusAdicionales = 2  and  (pmd_estatusautorizacion is null  OR pmd_estatusautorizacion = 0)
	AND ucn_idcotizadetallepost in (SELECT IdCotizaDetalle FROM @Detalles)


    SELECT @@ROWCOUNT  Result, 'SE PROCESÓ CORRECTAMENTE LA SOLICITUD' Mensaje

END TRY
BEGIN CATCH
    SELECT -1 Result, 'OCURRIÓ UN ERROR AL PROCESAR SOLICITUD' Mensaje

END CATCH

END
go

