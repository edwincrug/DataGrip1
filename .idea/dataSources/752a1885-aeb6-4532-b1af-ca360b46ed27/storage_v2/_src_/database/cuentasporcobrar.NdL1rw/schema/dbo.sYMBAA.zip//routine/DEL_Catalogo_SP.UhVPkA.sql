-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 borra los catalogos
-- [SEL_Catalogo_SP] 71,4,6
-- ==========================================================================================

create PROCEDURE [dbo].[DEL_Catalogo_SP]
	@idUsuario  int = 0,
	@idempresa  int = 0,
	@idsucursal  int = 0,
	@idsubtramite  int = 0,
	@estatus  int = 0
AS
BEGIN
	SET NOCOUNT ON;
		Declare @serverDB varchar(200) ,@ipDB varchar(200) ,@queryText varchar(8000)
	     DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	set @serverDB= ''
	set @ipDB= ''

	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			select top 1	@serverDB=
			'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal = @idSucursal
		END
	ELSE
		BEGIN
			select top 1	@serverDB=
			'['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal  = @idSucursal
		END
	
         if @serverDB is null or len(@serverDB) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 return 0;
		 end

		  Set @queryText='update '+@serverDB+'.CXC_SUBTRAMITE set STR_ESTATUS='+convert(nvarchar(20),@estatus)+',STR_CENTRALIZACION='''+convert(nvarchar(6),@idUsuario)+''',STR_FECHMOD=convert(nvarchar(10),getdate(),103)
							where 	STR_IDSUBTRAM='+convert(nvarchar(6),@idsubtramite)
print @queryText
exec(@queryText)
        select 1 success, '' msg
END

go

