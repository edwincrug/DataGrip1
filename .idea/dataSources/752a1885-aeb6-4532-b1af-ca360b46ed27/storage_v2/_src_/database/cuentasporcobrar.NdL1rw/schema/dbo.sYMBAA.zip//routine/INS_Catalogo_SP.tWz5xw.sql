-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Inserta los catalogos
-- [dbo].[INS_Catalogo_SP] 71,4,6,'lero lero','46F',733,1000,1200,1
-- ==========================================================================================

CREATE PROCEDURE [dbo].[INS_Catalogo_SP]
	@idUsuario  int,
	@idempresa  int,
	@idsucursal  int ,
	@subtramite  nvarchar(250),
	@idclasificacion  nvarchar(10),
	@idpersona int,
	@costo decimal(18,2),
	@precio decimal(18,2),
	@conUtilidad int
AS
BEGIN
	SET NOCOUNT ON;
		Declare @serverDB varchar(200) ,@ipDB varchar(200) ,@queryText varchar(8000),
	@tipotramite  nvarchar(1) = 'E',
	@financiado  int = 1,
	@financiera numeric(18,0) = 0,
	@cuantos int = 0
	     DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	set @serverDB= ''
	set @ipDB= ''

	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			select top 1	@serverDB=
			'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal = @idSucursal
		END
	ELSE
		BEGIN
			select top 1	@serverDB=
			'['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal  = @idSucursal
		END
	
         if @serverDB is null or len(@serverDB) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 return 0;
		 end
		 declare @selectQueryTrazabilidad nvarchar(max),@PARAMETROS nvarchar(100)

SET @selectQueryTrazabilidad = 'SELECT @cuantos=count(*) from '+@serverDB+'.CXC_SUBTRAMITE s inner join '+@serverDB+'.[CXC_PROVSUBTRAMITE] p on s.[STR_IDSUBTRAM]=p.[PST_IDSUBTRAM] where rtrim(ltrim(s.STR_SUBTRAM)) ='''+@subtramite+'''  and s.STR_TRAMITE='''+@idclasificacion+''' and p.PST_PROVEEDOR='+convert(nvarchar(6),@idpersona)+' and p.PST_PRECIO='+convert(nvarchar(20),@precio)
                SET @PARAMETROS = N'@cuantos int OUTPUT';
				print @selectQueryTrazabilidad
                EXEC sp_executesql @selectQueryTrazabilidad,@PARAMETROS, @cuantos OUTPUT;
				print @cuantos

	 if (@cuantos=0)
	 begin
		   if (@conUtilidad=1 and @costo<@precio) or (@conUtilidad=0 and @costo=@precio)
		   begin
				  Set @queryText='Declare @id int

		INSERT INTO '+@serverDB+'.[CXC_SUBTRAMITE]
				   ([STR_SUBTRAM]
				   ,[STR_TRAMITE]
				   ,[STR_CVEUSU]
				   ,[STR_FECHOPE]
				   ,[STR_FECHMOD]
				   ,[STR_ESTATUS]
				   ,[STR_CENTRALIZACION])
			 VALUES
				   ('''+@subtramite+'''
				   ,'''+@idclasificacion+'''
				   ,''GMI''
				   ,convert(nvarchar(10),getdate(),103)
				   ,convert(nvarchar(10),getdate(),103)
				   ,''1''
				   ,'+convert(nvarchar(6),@idUsuario)+')

		select @id=SCOPE_IDENTITY()

		INSERT INTO '+@serverDB+'.[CXC_PROVSUBTRAMITE]
				   ([PST_IDSUBTRAM]
				   ,[PST_PROVEEDOR]
				   ,[PST_COSTO]
				   ,[PST_CVEUSU]
				   ,[PST_FECHOPE]
				   ,[PST_PRECIO]
				   ,[PST_CONUTILIDAD]
				   ,[PST_TIPOTRAMITE]
				   ,[PST_FINANCIADO]
				   ,[PST_FINANCIERA])
			 VALUES
				   (@id
				   ,'+convert(nvarchar(6),@idpersona)+'
				   ,'+convert(nvarchar(20),@costo)+'
				   ,''GMI''
				   ,convert(nvarchar(10),getdate(),103)
				   ,'+convert(nvarchar(20),@precio)+'
				   ,'+convert(nvarchar(6),@conUtilidad)+'
				   ,'''+@tipotramite+'''
				   ,'+convert(nvarchar(20),@financiado)+'
				   ,'+convert(nvarchar(20),@financiera)+')'
		print @queryText
		exec(@queryText)

		select 1 success,'' msg
		end
		else
		begin
			select 0 success,'El costo debe ser igual al precio para trámites de placas, tenencias o seguros. En otro caso el precio debe ser mayor' msg
		end
	end
	else 
	begin 
		select 0 success,'Ya existe este registro.(Trámite + clasificación + proveedor + precio)' msg
	end   

EXECUTE  [dbo].[INS_Rol_SP] @idpersona

END

go

