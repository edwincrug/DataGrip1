
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--select* from  ObtenfechasCCs('09/01/2021')
CREATE FUNCTION [dbo].[ObtenfechasCCs]
(	
	-- Add the parameters for the function here
	@fecha date
)
RETURNS @result TABLE ( dia int,
 fecha date,diasem int ,nombredelasemana varchar(10),fechainicio date,nombrediainicio varchar(10),fechafin date,nombrediafin nvarchar(10),fechafinmes date,tipo nvarchar(20)
)
AS
begin
--Declare @fecha date='01/10/2020'
Declare @fechainicio date,@fechafin date,@mes int,@anio int , @dia int,@diasem int,@nombrediainicio nvarchar(10),@nombrediafin nvarchar(10),@fechafinmes date,@fechaLunes date,@nombredelasemana nvarchar(10) ,@tipo nvarchar(20)
SELECT @dia=DATEPART(d, @fecha),@diasem=DATEPART(dw, @fecha),@nombredelasemana= DATENAME(dw, @fecha)  ,@mes= DATEPART(m, @fecha) ,@anio= DATEPART(yy, @fecha)
Select @fechafinmes=case when @mes=12 and @dia <> 1 then DateAdd(day,-1, dbo.construyefecha(1,1,@anio+1)) when @dia = 1 then DateAdd(day,-1, dbo.construyefecha(1,@mes,@anio)) else DateAdd(day,-1, dbo.construyefecha(1,@mes+1,@anio)) end
select @fechaLunes=dbo.[EncuentraLunesPasado](@fecha)
	if  @dia = 1 and @diasem <>6
	begin 
--	print 'dia 1'
		select @fechainicio=DateAdd(day,0,@fechaLunes), @nombrediainicio=DATENAME(dw,DateAdd(day,0,@fechaLunes)),@fechafin=DateAdd(day,-1,@fecha), @nombrediafin=DATENAME(dw,DateAdd(day,-1,@fecha)),@tipo='1 diferente 1'
	end
	else if  @dia = 1 and @diasem=6
	begin 
		select @fechainicio=DateAdd(day,-7,@fechaLunes), @nombrediainicio=DATENAME(dw,DateAdd(day,-7,@fechaLunes)),@fechafin=DateAdd(day,-1,@fecha), @nombrediafin=DATENAME(dw,DateAdd(day,-1,@fecha)),@tipo='1 = 1'
	end
	else if @dia > 1 and @dia<12
	begin
--	print 'entre 11'
		if @diasem=6
		begin
			if @dia<=3
			begin
			select @fechainicio=dbo.construyefecha(1,@mes,@anio), @nombrediainicio=DATENAME(dw,dbo.construyefecha(1,@mes,@anio)),@fechafin=DateAdd(day,-1,@fechaLunes), @nombrediafin=DATENAME(dw,DateAdd(day,-1,@fechaLunes)),@tipo='entre 111'
			end 
			else
			begin 
				--select @fechainicio=dbo.construyefecha(1,@mes,@anio), @nombrediainicio=DATENAME(dw,dbo.construyefecha(1,@mes,@anio)),@fechafin=DateAdd(day,-1,@fechaLunes), @nombrediafin=DATENAME(dw,DateAdd(day,-1,@fechaLunes)),@tipo='entre 112'
				select @fechainicio=DateAdd(day,-7,@fechaLunes), @nombrediainicio=DATENAME(dw,DateAdd(day,-7,@fechaLunes)),@fechafin=DateAdd(day,-1,@fechaLunes), @nombrediafin=DATENAME(dw,DateAdd(day,-1,@fechaLunes)),@tipo='entre 112'
			end
		End
	end
	else if @dia>=12
	begin
--	print 'mayor 11'
		if @diasem=6
		begin
			select @fechainicio=DateAdd(day,-7,@fechaLunes), @nombrediainicio=DATENAME(dw,DateAdd(day,-7,@fechaLunes)),@fechafin=DateAdd(day,-1,@fechaLunes), @nombrediafin=DATENAME(dw,DateAdd(day,-1,@fechaLunes)),@tipo='mayor 11'
		End
	end
	


	insert into @result
	SELECT @dia,@fecha fechadiahoy,@diasem diadelasemana,@nombredelasemana nombredeldiadelasemana,@fechainicio inicio,@nombrediainicio diainicio,@fechafin fin,@nombrediafin diafin,@fechafinmes findemes,@tipo
RETURN 
End
go

