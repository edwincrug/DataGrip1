-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Obtiene los tramites
-- [SEL_Tramites_SP] 71,4,6
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_Tramites_SP]
	@idUsuario  int = 0,
	@idEmpresa  int = 0,
	@idSucursal  int = 0
AS
BEGIN
	SET NOCOUNT ON;
		Declare @serverDB varchar(200) ,@ipDB varchar(200) ,@queryText varchar(8000),@tipo nvarchar(20),@consecutivo_contable int
	     DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	set @serverDB= ''
	set @ipDB= ''

	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			select top 1	@serverDB=
			'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].',@consecutivo_contable= consecutivo_contable
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal = @idSucursal
		END
	ELSE
		BEGIN
			select top 1	@serverDB=
			'['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].',@consecutivo_contable= consecutivo_contable
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal  = @idSucursal
		END
	
         if @serverDB is null or len(@serverDB) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 return 0;
		 end
		 select top 1 @tipo = (case when sup_idPerfil= 10 then '2.0,2.1,1.0,1.1' when sup_idPerfil= 11 then '2.0,2.1' when sup_idPerfil= 12 then '1.0,1.1' else '3.0' end)   from seguridad.dbo.SEG_USUARIO_PERFIL s where s.sup_idUsuario=@idUsuario and s.sup_idPerfil in (10,11,12)
		 print @tipo
		  Set @queryText='	SELECT  COCO.PAR_IDENPARA idtramite,COCO.PAR_DESCRIP1 tramite,case when coco.PAR_IMPORTE4 in (1.1,2.1) then 1 when coco.PAR_IMPORTE4 in (1.0,2.0) then 0 end conUtilidad-- ,coco.*
		    FROM '+@serverDB+'.PNC_PARAMETR COCO 
			INNER JOIN '+@serverDB+'.PNC_PARAMETR COCOCAR ON COCO.PAR_IDENPARA = COCOCAR.PAR_IDENPARA
			WHERE COCOCAR.PAR_DESCRIP2 <> '''' AND COCO.PAR_TIPOPARA = ''COCOCXC''
			AND COCOCAR.PAR_TIPOPARA = ''COCOCXCCAR'' and coco.PAR_IMPORTE4 in ('+@tipo+') and substring(coco.PAR_DESCRIP2,14,1) ='+convert(nvarchar(2),@consecutivo_contable)+'
			order by tramite' 
			 
print @queryText
exec(@queryText)
        
END
go

