
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
--select dbo.[EncuentraLunesPasado]('30/10/2020'),DATENAME(dw,dbo.[EncuentraLunesPasado]('30/10/2020'))
CREATE FUNCTION [dbo].[EncuentraLunesPasado]
(
	@fecha date
)
RETURNS date
AS
BEGIN
	
	--declare @fecha date='13/04/2020'
declare @diatemp int ,@nombredia nvarchar(10),@numdiasrestar int = 0
select @diatemp=DATEPART(dw,@fecha),@nombredia= DATEName(dw,@fecha)

if @diatemp=5
begin
Set @numdiasrestar=6
end
else if @diatemp=4
begin
Set @numdiasrestar=5
end
else if @diatemp=3
begin
Set @numdiasrestar=4
end
else if @diatemp=2
begin
Set @numdiasrestar=3
end
else if @diatemp=1
begin
Set @numdiasrestar=2
end
else if @diatemp=7
begin
Set @numdiasrestar=1
end
else if @diatemp=6
begin
Set @numdiasrestar=0
end


--select @diatemp,@nombredia,DateAdd(day,-@numdiasrestar,@fecha),DATENAME(dw,DateAdd(day,-@numdiasrestar,@fecha))
	-- Return the result of the function
	RETURN DateAdd(day,-@numdiasrestar,@fecha)

END
go

