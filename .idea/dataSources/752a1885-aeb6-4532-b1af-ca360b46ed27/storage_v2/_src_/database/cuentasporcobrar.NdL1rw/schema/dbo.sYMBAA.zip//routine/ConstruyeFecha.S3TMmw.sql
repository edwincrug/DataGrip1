
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
--select construyefecha(1,4,2020)
CREATE FUNCTION [dbo].[ConstruyeFecha]
(
	@dia int,
	@mes int,
	@anio int
)
RETURNS date
AS
BEGIN
	-- Declare the return variable here
	DECLARE @fecha date

	-- Add the T-SQL statements to compute the return value here
	SELECT @fecha=right('0' + convert(nvarchar(2),@dia),2)+'/'+right('0' + convert(nvarchar(2),@mes),2)+'/'+convert(nvarchar(4),@anio)

	-- Return the result of the function
	RETURN @fecha

END
go

