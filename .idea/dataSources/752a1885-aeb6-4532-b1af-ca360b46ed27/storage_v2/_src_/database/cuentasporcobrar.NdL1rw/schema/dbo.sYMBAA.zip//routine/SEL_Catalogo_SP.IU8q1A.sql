-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Obtiene los catalogos
-- [SEL_Catalogo_SP] 71,4,6
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_Catalogo_SP]
	@idUsuario  int = 0,
	@idEmpresa  int = 0,
	@idSucursal  int = 0
AS
BEGIN
	SET NOCOUNT ON;
		Declare @serverDB varchar(200) ,@ipDB varchar(200) ,@queryText varchar(8000),@tipo nvarchar(50)
	     DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	set @serverDB= ''
	set @ipDB= ''

	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			select top 1	@serverDB=
			'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal = @idSucursal
		END
	ELSE
		BEGIN
			select top 1	@serverDB=
			'['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal  = @idSucursal
		END
	
         if @serverDB is null or len(@serverDB) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 return 0;
		 end
		  select top 1 @tipo = (case when sup_idPerfil= 10 then '2.0,2.1,1.0,1.1' when sup_idPerfil= 11 then '2.0,2.1' when sup_idPerfil= 12 then '1.0,1.1' else '3.0' end)   from seguridad.dbo.SEG_USUARIO_PERFIL s where s.sup_idUsuario=@idUsuario and s.sup_idPerfil in (10,11,12)
		 print @tipo
		  Set @queryText='SELECT s.STR_IDSUBTRAM idsubtramite,
							s.STR_SUBTRAM subtramite,
							c.PAR_IDENPARA idclasificacion,
							c.PAR_DESCRIP1 clasificacion,
							pp.PER_IDPERSONA idpersona,
							case when per_tipo=''mor'' then PER_NOMRAZON else  LTRIM(LTRIM(PER_PATERNO) + '' '' + LTRIM(PER_MATERNO) + '' '' + LTRIM(PER_NOMRAZON)) end proveedor,
							p.PST_COSTO costo,
							p.PST_PRECIO precio,
							
							p.PST_TIPOTRAMITE tipotramite,
							p.PST_FINANCIADO financiado,
							p.PST_FINANCIERA financiera,
							convert(bit,s.str_estatus) estatus,
							case when s.str_estatus=1 then ''Activo'' else ''Desactivado'' end nombreEstatus,
							pp.per_rfc rfc,
							case convert(int,c.PAR_IMPORTE4) when 2 then ''Flotillas'' when 1 then ''Menudeo'' end tipoTramite,
							convert(bit,substring(convert(nvarchar(18),c.PAR_IMPORTE4),3,1)) conUtilidad

							 FROM '+@serverDB+'.CXC_SUBTRAMITE s
							inner join '+@serverDB+'.CXC_PROVSUBTRAMITE p on s.STR_IDSUBTRAM=p.PST_IDSUBTRAM
							inner join GA_Corporativa.dbo.PER_PERSONAS pp on p.PST_PROVEEDOR=pp.PER_IDPERSONA
							inner join (SELECT  COCO.PAR_IDENPARA,COCO.PAR_DESCRIP1,coco.PAR_IMPORTE4  FROM
							'+@serverDB+'.PNC_PARAMETR COCO 
							INNER JOIN '+@serverDB+'.PNC_PARAMETR COCOCAR ON COCO.PAR_IDENPARA = COCOCAR.PAR_IDENPARA
							WHERE COCOCAR.PAR_DESCRIP2 <> '''' AND COCO.PAR_TIPOPARA = ''COCOCXC''
							AND COCOCAR.PAR_TIPOPARA = ''COCOCXCCAR'' and coco.PAR_IMPORTE4 in ('+@tipo+')) c on s.STR_TRAMITE=c.PAR_IDENPARA 
							order by clasificacion,subtramite,proveedor'  
print @queryText
exec(@queryText)
        
END

go

