-- =============================================
-- Author:		<Jocelyn Hernández>
-- Create date: <06032017	>
-- Description:	<prueba para que funcione cxc>
-- =============================================
CREATE PROCEDURE SEL_REFERENCIA_NUEVO_SP

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

END
go

