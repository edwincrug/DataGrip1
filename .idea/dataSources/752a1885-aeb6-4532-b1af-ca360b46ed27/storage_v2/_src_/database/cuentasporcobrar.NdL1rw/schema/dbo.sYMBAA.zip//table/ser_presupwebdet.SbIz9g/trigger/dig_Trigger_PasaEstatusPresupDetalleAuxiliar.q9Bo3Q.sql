
    CREATE TRIGGER dig_Trigger_PasaEstatusPresupDetalleAuxiliar

    ON ser_presupwebdet FOR INSERT

    AS

	declare @prw_iddivision int;
	declare @prw_idempresa int;
	declare @prw_idsucursal int;
	declare @prw_iddepartamento int;	
	declare @prw_tiporden varchar(1);	
	declare @prw_idusuario int;
	declare @prw_nopresupuesto int; --esta es la llave.
	declare @prw_idlocal int;
	declare @prw_idcliente int;
	declare @prw_noserie varchar(17);
    declare @prw_estatus int;
	declare @cec_idestatuspresuint int;
	declare @prw_idasesor varchar(5);
	declare @observaciones varchar(250);

	declare @prw_idpresuorden int;
	
	select @prw_idpresuorden = i.prw_idpresuorden from inserted i;
	
	select @prw_idlocal = i.pwd_idordendet from inserted i;
	select @cec_idestatuspresuint = i.cec_idestatuspresuint from inserted i;

	
	set @observaciones='Insercion más trabajos desde BPro';

	select @prw_iddivision = prw_iddivision, @prw_idempresa = prw_idempresa, @prw_idsucursal = prw_idsucursal,@prw_iddepartamento=prw_iddepartamento,  
		   @prw_tiporden=prw_tiporden,@prw_idusuario = prw_idusuario,@prw_nopresupuesto = prw_nopresupuesto,@prw_idcliente=prw_idcliente,  
		   @prw_noserie=prw_noserie,@prw_estatus=prw_estatus,@prw_idasesor=prw_idasesor
		   From ser_presupweb where prw_idpresuorden = @prw_idpresuorden
	
		if (@cec_idestatuspresuint=3) --PorRevisar
		Begin
		    select @cec_idestatuspresuint = 100 --para identificar de donde proviene en el sensor.
			
			If Not Exists(Select 1 from Centralizacionv2..DIG_PRESUPUESTOAUX as aux where aux.prw_nopresupuesto = @prw_nopresupuesto)
		    begin	
          	  INSERT INTO Centralizacionv2..DIG_PRESUPUESTOAUX (div_iddivision,emp_idempresa,suc_idsucursal,dep_iddepartamento,prw_tiporden,id_usuario,prw_nopresupuesto,prw_idpresuorden,prw_idcliente,prw_noserie,prw_estatus,cec_idestatuspresuint,prw_idasesor,aux_fecha,aux_observaciones)
         	  values (@prw_iddivision,@prw_idempresa,@prw_idsucursal,@prw_iddepartamento,@prw_tiporden,@prw_idusuario,@prw_nopresupuesto,@prw_idlocal,@prw_idcliente,@prw_noserie,@prw_estatus,@cec_idestatuspresuint,@prw_idasesor,getdate(),@observaciones)
			end
			else
			begin
			  	Update Centralizacionv2..DIG_PRESUPUESTOAUX set  prw_estatus = @prw_estatus, cec_idestatuspresuint=@cec_idestatuspresuint  , aux_fecha=getdate(), aux_observaciones = @observaciones
				where prw_nopresupuesto  = @prw_nopresupuesto
			end
		End
    go

