
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
--select dbo.[EncuentraNombre]('AC000015725-CC1')
CREATE FUNCTION [dbo].[EncuentraNombre]
(
	@nombre nvarchar(60)
)
RETURNS nvarchar(60)
AS
BEGIN
	-- Declare the return variable here
	--Declare @nombre nvarchar(60)='AC000015725-CC'
	DECLARE @name nvarchar(60),@num int,@partea nvarchar(30)='',@parteb nvarchar(30)=''
SELECT top 1 @name=[abd_doctofactura]
     
  FROM [cuentasporcobrar].[dbo].[cxc_polizasccsdet]
  where [abd_doctofactura] like @nombre+'%'
  order by [abd_doctofactura] desc

  if len(@name)>0
  begin
  set @num=CHARINDEX('-', @name)+2; 
  set @partea=substring(@name,1,@num)
  set @parteb=substring(@name,@num+1,len(@name)-@num)
	if @num=len(@name)
	set @parteb='0'
  Set @name =@partea+convert(nvarchar(30),convert(int,@parteb)+1)
  End
  else
  begin
  Set @name=@nombre
  End

 -- select @name,@nombre,@num,len(@name),@partea,@parteb
	RETURN @name

END
go

