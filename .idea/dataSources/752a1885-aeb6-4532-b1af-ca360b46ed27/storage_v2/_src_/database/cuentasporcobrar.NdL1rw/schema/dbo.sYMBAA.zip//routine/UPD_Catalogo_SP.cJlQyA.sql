-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Actualiza los catalogos
-- [UPD_Catalogo_SP] 71,4,6,140,'nuevo tramite','11ZF1',20,40,0
-- ==========================================================================================

CREATE PROCEDURE [dbo].[UPD_Catalogo_SP]
	@idUsuario  int = 0,
	@idempresa  int = 0,
	@idsucursal  int = 0,
	@idsubtramite  int = 0,
	@subtramite  nvarchar(50) = 0,
	@idclasificacion  nvarchar(250) = '',
	@clasificacion  nvarchar(250) = 0,
	@costo decimal(18,2),
	@precio decimal(18,2),
	@conUtilidad int = 0
AS
BEGIN
	SET NOCOUNT ON;
		Declare @serverDB varchar(200) ,@ipDB varchar(200) ,@queryText varchar(8000)
	     DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	set @serverDB= ''
	set @ipDB= ''

	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			select top 1	@serverDB=
			'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal = @idSucursal
		END
	ELSE
		BEGIN
			select top 1	@serverDB=
			'['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal  = @idSucursal
		END
	
         if @serverDB is null or len(@serverDB) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 return 0;
		 end
declare @selectQueryTrazabilidad nvarchar(max),@PARAMETROS nvarchar(max),@idPenultimo nvarchar(250)=@idclasificacion

SET @selectQueryTrazabilidad = 'SELECT @conUtilidad =case when PAR_IMPORTE4 in (1.1,2.1) then 1 when PAR_IMPORTE4 in (1.0,2.0) then 0 end from '+@serverDB+'.PNC_PARAMETR where PAR_IDENPARA=@idPenultimo  and PAR_IMPORTE4>0'
                SET @PARAMETROS = N'@idPenultimo nvarchar(5), @conUtilidad int OUTPUT';
				print @selectQueryTrazabilidad
                EXEC sp_executesql @selectQueryTrazabilidad, @PARAMETROS, @idPenultimo, @conUtilidad OUTPUT;
          --      select @conUtilidad
 
 

   if (@conUtilidad=1 and @costo<@precio) or (@conUtilidad=0 and @costo=@precio)
   begin
		  Set @queryText='update '+@serverDB+'.CXC_SUBTRAMITE set STR_SUBTRAM='''+@subtramite+''',STR_CENTRALIZACION='''+convert(nvarchar(6),@idUsuario)+''',STR_FECHMOD=convert(nvarchar(10),getdate(),103)
							where 	STR_IDSUBTRAM='+convert(nvarchar(6),@idsubtramite)+'
							update '+@serverDB+'.CXC_PROVSUBTRAMITE set PST_COSTO='+convert(nvarchar(20),@costo)+',
							PST_PRECIO='+convert(nvarchar(20),@precio)+',PST_CONUTILIDAD='+convert(nvarchar(2),@conUtilidad)+'
							where 	PST_IDSUBTRAM='+convert(nvarchar(6),@idsubtramite)
print @queryText
exec(@queryText)
        
select 1 success,'' msg
end
else
begin
select 0 success,'El costo debe ser igual al precio para trámites de placas, tenencias o seguros. En otro caso el precio debe ser mayor' msg
end

END
go

