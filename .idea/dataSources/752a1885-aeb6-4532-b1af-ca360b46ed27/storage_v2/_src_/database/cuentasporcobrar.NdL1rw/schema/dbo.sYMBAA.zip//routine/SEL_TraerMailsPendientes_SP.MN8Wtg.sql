-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Obtiene los catalogos
-- [SEL_Catalogo_SP] 71,4,6
-- ==========================================================================================
--[dbo].[SEL_TraerMailsPendientes_SP]
CREATE PROCEDURE [dbo].[SEL_TraerMailsPendientes_SP]
AS
BEGIN
	
	SELECT TOP (1000) [idmandacorreo]
      ,[idpertra]
      ,m.[idempresa]
	  ,d.nombre_sucursal
      ,[idsucursal]
      ,[idbancoorigen]
      ,[CLABEorigen]
	  ,a.cuenta bancoorigen
	  ,a.numeroCuenta numcuentaOrigen
      ,[idbancodestino]
      ,[CLABEdestino]
	  ,b.cuenta bancodestino
	  ,b.numeroCuenta numcuentaDestino
      ,[importe]
      ,[fecha]
      ,[referencia]
      ,[idCCs]
      ,[idtransferencia]
      ,[idestatus]
      ,[fechaenviado]
	  ,r.idpersona
	  ,cu.usu_paterno+ ' '+ usu_materno+ ' '+usu_nombre nombre
  FROM [cuentasporcobrar].[dbo].[MandarCorreo] m
  inner join Centralizacionv2.dbo.DIG_CAT_BASES_BPRO d on m.idempresa=d.emp_idempresa and m.idsucursal=d.suc_idsucursal
  inner join Rel_empresabanco r on m.idempresa=r.idempresa
  inner join ControlAplicaciones.dbo.cat_usuarios cu on r.idpersona=cu.usu_idusuario
  left join referencias.dbo.BancoCuenta a on m.idbancoorigen=a.idBanco and m.idempresa=a.idEmpresa and ltrim(rtrim(m.CLABEorigen)) =ltrim(rtrim(a.cuentaClabe)) collate database_default
  left join referencias.dbo.BancoCuenta b on m.idbancodestino=b.idBanco and m.idempresa=b.idEmpresa and ltrim(rtrim(m.CLABEdestino)) =ltrim(rtrim(b.cuentaClabe)) collate database_default
  where idestatus=0

  SELECT * FROM Tesoreria.dbo.parametrosConsultaMovimientos cm WHERE cm.tipo =1 AND cm.modulo = 5

END


go

