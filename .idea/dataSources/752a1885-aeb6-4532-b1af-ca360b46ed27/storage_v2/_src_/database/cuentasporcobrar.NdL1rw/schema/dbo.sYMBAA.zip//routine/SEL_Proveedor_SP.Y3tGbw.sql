-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Obtiene los proveedores
-- [SEL_Proveedor_SP] 71,4,6
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_Proveedor_SP]
	@idUsuario  int = 0,
	@idEmpresa  int = 0,
	@idSucursal  int = 0
AS
BEGIN
	SET NOCOUNT ON;
		Declare @serverDB varchar(200) ,@ipDB varchar(200) ,@queryText varchar(8000)
	     DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	set @serverDB= ''
	set @ipDB= ''

	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			select top 1	@serverDB=
			'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal = @idSucursal
		END
	ELSE
		BEGIN
			select top 1	@serverDB=
			'['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal  = @idSucursal
		END
	
         if @serverDB is null or len(@serverDB) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 return 0;
		 end

		  Set @queryText='	 SELECT ROL_IDPERSONA idpersona,case when per_tipo=''mor'' then PER_NOMRAZON else  LTRIM(LTRIM(PER_PATERNO) + '' '' + LTRIM(PER_MATERNO) + '' '' + LTRIM(PER_NOMRAZON)) end proveedor,p.per_rfc rfc
							FROM '+@serverDB+'.PER_ROLES r
							inner join ga_corporativa.dbo.per_personas p on r.ROL_IDPERSONA=p.PER_IDPERSONA
							where ROL_ROL = ''PROTER''
							AND ROL_ESTATUS = 1
							order by proveedor'  
print @queryText
exec(@queryText)
        
END

go

