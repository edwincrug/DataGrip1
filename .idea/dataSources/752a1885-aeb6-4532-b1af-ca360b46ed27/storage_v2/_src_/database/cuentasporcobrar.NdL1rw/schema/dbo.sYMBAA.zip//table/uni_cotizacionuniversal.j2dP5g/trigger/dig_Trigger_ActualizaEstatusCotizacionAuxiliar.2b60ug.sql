
CREATE TRIGGER [dbo].[dig_Trigger_ActualizaEstatusCotizacionAuxiliar] ON [dbo].[uni_cotizacionuniversal] 
FOR UPDATE
AS

	declare @ucu_idcotizacion int;
	declare @ucu_foliocotizacion varchar(50);
	declare @ucu_idusuarioalta int;
	declare @ucu_iddivision int;
	declare @ucu_idempresa int;
	declare @ucu_idsucursal int;
	declare @ucu_iddepartamento int;	
	declare @cec_idestatuscotiza int;
	declare @observaciones varchar(250);
	declare @ucu_idpedidobpro numeric(18,0);

	select @ucu_idcotizacion = i.ucu_idcotizacion from inserted i;
	select @ucu_foliocotizacion = i.ucu_foliocotizacion from inserted i;
	select @ucu_idusuarioalta = i.ucu_idusuarioalta from inserted i;
	select @ucu_iddivision = i.ucu_iddivision from inserted i;	
	select @ucu_idempresa = i.ucu_idempresa from inserted i;	
	select @ucu_idsucursal = i.ucu_idsucursal from inserted i;
	select @ucu_iddepartamento = i.ucu_iddepartamento from inserted i;	
	select @cec_idestatuscotiza = i.cec_idestatuscotiza from inserted i;
	select @ucu_idpedidobpro = i.ucu_idpedidobpro from inserted i;	
 					
	if update(cec_idestatuscotiza)
	begin  						
			If Not Exists(Select 1 from CentralizacionV2..DIG_COTIZACIONAUX as aux where aux.ucu_idcotizacion = @ucu_idcotizacion)
		    begin				   			   
					set @observaciones = 'Actualizacion de estatus en Bpro';
					INSERT INTO CentralizacionV2..DIG_COTIZACIONAUX (ucu_idcotizacion,ucu_foliocotizacion,ucu_idusuarioalta,ucu_iddivision,ucu_idempresa,ucu_idsucursal,ucu_iddepartamento,cec_idestatuscotiza,aux_fecha,aux_observaciones)
					values (@ucu_idcotizacion,@ucu_foliocotizacion,@ucu_idusuarioalta,@ucu_iddivision,@ucu_idempresa,@ucu_idsucursal,@ucu_iddepartamento,@cec_idestatuscotiza,getdate(),@observaciones)
		    end
			else
            begin		       
					set @observaciones = 'ACTUALIZACION DE ESTATUS EN BPRO';	
					Update CentralizacionV2..DIG_COTIZACIONAUX set  cec_idestatuscotiza = @cec_idestatuscotiza, aux_fecha=getdate(), aux_observaciones = @observaciones
					where ucu_idcotizacion  = @ucu_idcotizacion				
		    end			   
	end
     
	if update(ucu_idpedidobpro)
	begin
	   if (Isnull(@ucu_idpedidobpro,0)<>0)
	   begin
	        select @cec_idestatuscotiza=1500;

			If Not Exists(Select 1 from CentralizacionV2..DIG_COTIZACIONAUX as aux where aux.ucu_idcotizacion = @ucu_idcotizacion)
		    begin				   			   
					set @observaciones = 'Actualizacion de ucu_idpedidobpro: '  + ltrim(rtrim(Convert(char(8),@ucu_idpedidobpro))) + ' en Bpro';
					INSERT INTO CentralizacionV2..DIG_COTIZACIONAUX (ucu_idcotizacion,ucu_foliocotizacion,ucu_idusuarioalta,ucu_iddivision,ucu_idempresa,ucu_idsucursal,ucu_iddepartamento,cec_idestatuscotiza,aux_fecha,aux_observaciones)
					values (@ucu_idcotizacion,@ucu_foliocotizacion,@ucu_idusuarioalta,@ucu_iddivision,@ucu_idempresa,@ucu_idsucursal,@ucu_iddepartamento,@cec_idestatuscotiza,getdate(),@observaciones)
		    end
			else
            begin		       
					set @observaciones = 'ACTUALIZACION de ucu_idpedidobpro: '  + ltrim(rtrim(Convert(char(8),@ucu_idpedidobpro))) + ' en Bpro';	
					Update CentralizacionV2..DIG_COTIZACIONAUX set  cec_idestatuscotiza = @cec_idestatuscotiza, aux_fecha=getdate(), aux_observaciones = @observaciones
					where ucu_idcotizacion  = @ucu_idcotizacion				
		    end			   
	   end
	end
go

