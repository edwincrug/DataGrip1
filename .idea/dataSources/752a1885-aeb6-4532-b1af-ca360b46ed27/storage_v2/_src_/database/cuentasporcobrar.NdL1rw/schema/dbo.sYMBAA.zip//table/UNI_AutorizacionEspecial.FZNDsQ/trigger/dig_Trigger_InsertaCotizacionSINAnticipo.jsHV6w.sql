
CREATE TRIGGER [dbo].[dig_Trigger_InsertaCotizacionSINAnticipo] ON [dbo].[UNI_AutorizacionEspecial] 
FOR INSERT
AS

	declare @UAE_IdAutorizacionEspecial	 int;
	declare @ucu_idcotizacion 	 int;
	declare @ucu_foliocotizacion varchar(50);
			
	declare @ucu_idusuarioalta 	 int;
	declare @ucu_iddivision 	 int;
	declare @ucu_idempresa 		 int;
	declare @ucu_idsucursal 	 int;
	declare @ucu_iddepartamento  int;	
	declare @cec_idestatuscotiza int;	
	
	declare @observaciones 		 varchar(250);    
    declare @ucn_idFactura 		 varchar(20);  
	declare @ucn_situacionfact 	 int;
	
	select @ucu_idcotizacion = i.UCU_IdCotizacion from inserted i;		 					
	select @UAE_IdAutorizacionEspecial 		 = i.UAE_IdAutorizacionEspecial from inserted i; 
 				
			select @ucu_iddivision = cu.ucu_iddivision, @ucu_idempresa = cu.ucu_idempresa, @ucu_idsucursal = cu.ucu_idsucursal,
		    @ucu_iddepartamento = cu.ucu_iddepartamento, @cec_idestatuscotiza = cu.cec_idestatuscotiza, @ucu_foliocotizacion = cu.ucu_foliocotizacion, 
		    @ucu_idusuarioalta = cu.ucu_idusuarioalta
		    from uni_cotizacionuniversal cu
		    where cu.ucu_idcotizacion = @ucu_idcotizacion									
			
			select @cec_idestatuscotiza=800;
			
			If Not Exists(Select 1 from [CentralizacionV2].[dbo].[DIG_COTIZACION_SINANTICIPOAUX] as aux where aux.ucu_idcotizacion = @ucu_idcotizacion)
		    begin				   			   
					set @observaciones = 'Insercion de cotizacion sin anticipo en : ' + ltrim(rtrim(CONVERT(varchar(20),@UAE_IdAutorizacionEspecial))) ;
					INSERT INTO [CentralizacionV2].[dbo].[DIG_COTIZACION_SINANTICIPOAUX] (ucu_idcotizacion,ucu_foliocotizacion,ucu_idusuarioalta,ucu_iddivision,ucu_idempresa,ucu_idsucursal,ucu_iddepartamento,cec_idestatuscotiza,aux_fecha,aux_observaciones)
					values (@ucu_idcotizacion,@ucu_foliocotizacion,@ucu_idusuarioalta,@ucu_iddivision,@ucu_idempresa,@ucu_idsucursal,@ucu_iddepartamento,@cec_idestatuscotiza,getdate(),@observaciones)
		    end
			else
            begin		       
					set @observaciones = 'ACTUALIZACION DE cotizacion sin anticipo en EN BPRO' + ltrim(rtrim(CONVERT(varchar(20),@UAE_IdAutorizacionEspecial)));	
					Update [CentralizacionV2].[dbo].[DIG_COTIZACION_SINANTICIPOAUX] set  cec_idestatuscotiza = @cec_idestatuscotiza, aux_fecha=getdate(), aux_observaciones = @observaciones
					where ucu_idcotizacion  = @ucu_idcotizacion				
		    end

go

