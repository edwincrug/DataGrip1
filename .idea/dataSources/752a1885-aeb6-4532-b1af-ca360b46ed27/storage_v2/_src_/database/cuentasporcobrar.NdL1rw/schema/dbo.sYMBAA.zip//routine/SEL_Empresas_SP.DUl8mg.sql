-- ==========================================================================================
-- Author:	 Ing. Alejandro Grijalva Antonio e Ing. Luis Antonio García Perrusquía
-- Create date:  21/04/2018
-- Description:	 Valida Usuario proveniente de BPRO
-- [SEL_Empresas_SP] 71
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_Empresas_SP]
	@idUsuario  int = 0
AS
BEGIN
	SET NOCOUNT ON;
		
	  SELECT DISTINCT 
                c.emp_idempresa AS idempresa, 
				c.emp_nombre AS nombre, 
				d.tipo_poliza_pago AS polizaPago
  FROM [ControlAplicaciones].[dbo].[ope_organigrama] o
  INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] d  ON o.emp_idempresa = d.emp_idempresa 
  INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] c ON d.emp_idempresa = c.emp_idempresa 
  WHERE o.usu_idusuario=  @idUsuario
        AND d.tipo = 2  
END

go

