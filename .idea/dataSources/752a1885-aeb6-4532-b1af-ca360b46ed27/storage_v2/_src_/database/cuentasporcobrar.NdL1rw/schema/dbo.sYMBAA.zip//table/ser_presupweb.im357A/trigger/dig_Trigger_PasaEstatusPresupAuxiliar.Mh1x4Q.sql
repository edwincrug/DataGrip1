CREATE TRIGGER dig_Trigger_PasaEstatusPresupAuxiliar

    ON dbo.ser_presupweb FOR INSERT

    AS

	declare @prw_iddivision int;
	declare @prw_idempresa int;
	declare @prw_idsucursal int;
	declare @prw_iddepartamento int;	
	declare @prw_tiporden varchar(1);	
	declare @prw_idusuario int;
	declare @prw_nopresupuesto int; --esta es la llave.
	declare @prw_idlocal int;
	declare @prw_idcliente int;
	declare @prw_noserie varchar(17);
        declare @prw_estatus int;
	declare @cec_idestatuspresuint int;
	declare @prw_idasesor varchar(5);
	declare @observaciones varchar(250);

	select @prw_iddivision = i.prw_iddivision from inserted i;
	select @prw_idempresa = i.prw_idempresa from inserted i;
	select @prw_idsucursal = i.prw_idsucursal from inserted i;
	select @prw_iddepartamento = i.prw_iddepartamento from inserted i;	
	select @prw_tiporden = i.prw_tiporden from inserted i;	
	
	select @prw_idusuario = i.prw_idusuario from inserted i;
	select @prw_nopresupuesto = i.prw_nopresupuesto from inserted i;
	select @prw_idlocal = i.prw_idpresuorden from inserted i;
	select @prw_idcliente = i.prw_idcliente from inserted i;
	select @prw_noserie = i.prw_noserie from inserted i;
    select @prw_estatus = i.prw_estatus from inserted i;
	select @cec_idestatuspresuint = i.cec_idestatuspresuint from inserted i;
	select @prw_idasesor = i.prw_idasesor from inserted i;
	set @observaciones='Insercion inicial desde BPro';

          	 INSERT INTO CentralizacionV2..DIG_PRESUPUESTOAUX (div_iddivision,emp_idempresa,suc_idsucursal,dep_iddepartamento,prw_tiporden,id_usuario,prw_nopresupuesto,prw_idpresuorden,prw_idcliente,prw_noserie,prw_estatus,cec_idestatuspresuint,prw_idasesor,aux_fecha,aux_observaciones)
         	 values (@prw_iddivision,@prw_idempresa,@prw_idsucursal,@prw_iddepartamento,@prw_tiporden,@prw_idusuario,@prw_nopresupuesto,@prw_idlocal,@prw_idcliente,@prw_noserie,@prw_estatus,@cec_idestatuspresuint,@prw_idasesor,getdate(),@observaciones)
go

