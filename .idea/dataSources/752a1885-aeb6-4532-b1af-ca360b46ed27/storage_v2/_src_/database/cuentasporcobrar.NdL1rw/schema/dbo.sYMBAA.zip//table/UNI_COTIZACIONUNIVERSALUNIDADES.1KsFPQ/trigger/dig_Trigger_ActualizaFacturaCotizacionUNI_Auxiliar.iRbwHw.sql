
CREATE TRIGGER dig_Trigger_ActualizaFacturaCotizacionUNI_Auxiliar ON [dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] 
FOR UPDATE
AS

	declare @ucu_idcotizacion int;
	declare @ucu_foliocotizacion varchar(50);
			
	declare @ucu_idusuarioalta int;
	declare @ucu_iddivision int;
	declare @ucu_idempresa int;
	declare @ucu_idsucursal int;
	declare @ucu_iddepartamento int;	
	declare @cec_idestatuscotiza int;	
	
	declare @observaciones varchar(250);    
    declare @ucn_idFactura varchar(20);  
	declare @ucn_situacionfact int;
	
	select @ucu_idcotizacion = i.ucu_idcotizacion from inserted i;		
	select @ucn_idFactura = i.ucn_idFactura	from inserted i;
    select @ucn_situacionfact = i.ucn_situacionfact from inserted i;
 					
	if update(ucn_situacionfact)
	begin  				
			select @ucu_iddivision = cu.ucu_iddivision, @ucu_idempresa = cu.ucu_idempresa, @ucu_idsucursal = cu.ucu_idsucursal,
		    @ucu_iddepartamento = cu.ucu_iddepartamento, @cec_idestatuscotiza = cu.cec_idestatuscotiza, @ucu_foliocotizacion = cu.ucu_foliocotizacion, 
		    @ucu_idusuarioalta = cu.ucu_idusuarioalta
		    from uni_cotizacionuniversal cu
		    where cu.ucu_idcotizacion = @ucu_idcotizacion
									
			
			If Not Exists(Select 1 from CentralizacionV2..DIG_COTIZACIONAUX as aux where aux.ucu_idcotizacion = @ucu_idcotizacion)
		    begin				   			   
					set @observaciones = 'Actualizacion Factura en Bpro';
					INSERT INTO CentralizacionV2..DIG_COTIZACIONAUX (ucu_idcotizacion,ucu_foliocotizacion,ucu_idusuarioalta,ucu_iddivision,ucu_idempresa,ucu_idsucursal,ucu_iddepartamento,cec_idestatuscotiza,aux_fecha,aux_observaciones)
					values (@ucu_idcotizacion,@ucu_foliocotizacion,@ucu_idusuarioalta,@ucu_iddivision,@ucu_idempresa,@ucu_idsucursal,@ucu_iddepartamento,@ucn_situacionfact,getdate(),@ucn_idFactura)
		    end
			else
            begin		       
					set @observaciones = 'ACTUALIZACION DE ESTATUS EN BPRO';	
					Update CentralizacionV2..DIG_COTIZACIONAUX set  cec_idestatuscotiza = @ucn_situacionfact, aux_fecha=getdate(), aux_observaciones = @ucn_idFactura
					where ucu_idcotizacion  = @ucu_idcotizacion				
		    end			   
	end
go

