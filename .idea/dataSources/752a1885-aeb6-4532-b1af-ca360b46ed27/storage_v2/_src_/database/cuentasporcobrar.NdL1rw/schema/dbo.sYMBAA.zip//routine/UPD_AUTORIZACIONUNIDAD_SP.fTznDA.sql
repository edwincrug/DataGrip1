create PROCEDURE [dbo].[UPD_AUTORIZACIONUNIDAD_SP] 
@FolioCotizacion VARCHAR(50),
@Autoriza INT
AS
BEGIN
DECLARE @IdCotizacion INT


SELECT	@IdCotizacion = ucu_idcotizacion  
FROM	cuentasporcobrar.dbo.uni_cotizacionuniversal 
WHERE	ucu_foliocotizacion = @FolioCotizacion

BEGIN TRY
	IF(@Autoriza = 1)
		BEGIN
			UPDATE cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES 
			SET ucn_autoriza = 'SI' 
			WHERE ucu_idcotizacion = @IdCotizacion
		END


SELECT 1 Result, 'Procesado Correctamente' Mensaje
END TRY

BEGIN CATCH

SELECT -1 Result, 'Ocurrio un error al autorizar la unidad' Mensaje
END CATCH
END



go

