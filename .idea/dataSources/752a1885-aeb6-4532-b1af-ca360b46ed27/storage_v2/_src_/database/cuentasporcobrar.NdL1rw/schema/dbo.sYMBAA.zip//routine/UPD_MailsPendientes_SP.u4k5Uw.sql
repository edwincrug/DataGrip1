-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Obtiene los catalogos
-- [SEL_Catalogo_SP] 71,4,6
-- ==========================================================================================
--[dbo].[SEL_Traer MailsPendientes_SP]
create PROCEDURE [dbo].[UPD_MailsPendientes_SP]
@idmandacorreo int
AS
BEGIN
	update [cuentasporcobrar].[dbo].[MandarCorreo] set idestatus=1,fechaenviado=getdate()
    where idmandacorreo=@idmandacorreo

END


go

