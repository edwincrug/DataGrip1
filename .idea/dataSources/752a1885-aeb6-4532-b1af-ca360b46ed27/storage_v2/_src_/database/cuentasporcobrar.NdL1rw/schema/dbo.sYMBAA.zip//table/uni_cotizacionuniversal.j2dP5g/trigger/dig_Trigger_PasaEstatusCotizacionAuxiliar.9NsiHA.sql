
    CREATE TRIGGER dig_Trigger_PasaEstatusCotizacionAuxiliar

    ON uni_cotizacionuniversal FOR INSERT

    AS

	declare @ucu_idcotizacion int;
	declare @ucu_foliocotizacion varchar(50);
	declare @ucu_idusuarioalta int;
	declare @ucu_iddivision int;
	declare @ucu_idempresa int;
	declare @ucu_idsucursal int;
	declare @ucu_iddepartamento int;	
	declare @cec_idestatuscotiza int;
	declare @observaciones varchar(250);

	select @ucu_idcotizacion = i.ucu_idcotizacion from inserted i;
	select @ucu_foliocotizacion = i.ucu_foliocotizacion from inserted i;
	select @ucu_idusuarioalta = i.ucu_idusuarioalta from inserted i;
	select @ucu_iddivision = i.ucu_iddivision from inserted i;	
	select @ucu_idempresa = i.ucu_idempresa from inserted i;	
	select @ucu_idsucursal = i.ucu_idsucursal from inserted i;
	select @ucu_iddepartamento = i.ucu_iddepartamento from inserted i;	
	select @cec_idestatuscotiza = i.cec_idestatuscotiza from inserted i;	

	set @observaciones='Insercion inicial desde BPro';

          	 INSERT INTO CentralizacionV2..DIG_COTIZACIONAUX (ucu_idcotizacion,ucu_foliocotizacion,ucu_idusuarioalta,ucu_iddivision,ucu_idempresa,ucu_idsucursal,ucu_iddepartamento,cec_idestatuscotiza,aux_fecha,aux_observaciones)
         	 values (@ucu_idcotizacion,@ucu_foliocotizacion,@ucu_idusuarioalta,@ucu_iddivision,@ucu_idempresa,@ucu_idsucursal,@ucu_iddepartamento,@cec_idestatuscotiza,getdate(),@observaciones)

    go

