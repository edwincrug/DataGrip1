-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Obtiene los catalogos
-- [SEL_Catalogo_SP] 71,4,6
-- ==========================================================================================
--[dbo].[SEL_ObtenerCCsAnual_SP] '11/06/2021'
CREATE PROCEDURE [dbo].[SEL_ObtenerCCsAnual_SP]
--dECLARE
--@fecha date
AS
BEGIN
	dECLARE @fecha date=getdate()
DECLARE @max INT
			,@aux INT = 1
			,@pab_idpolizasccs numeric(18, 0)
			,@idenca int

		DECLARE @basesConcentra TABLE(id INT IDENTITY,[pab_idpolizasccs] [numeric](18, 0),
	[pab_idempresa] [int],
	[pab_idsucursal] [int] ,
	[pab_bancodestino] [varchar](50) ,
	[pab_estatus] [int] ,
	[pag_importetotalbanco] [decimal](18, 5),
	[pab_tipopoliza] [int],
	[pab_fechaingreso] [datetime],
	[pab_fechaproceso] [datetime])
	INSERt INTO @basesConcentra
	select * from cxc_polizasccs where DATEDIFF(YEAR,pab_fechaingreso,@fecha)>0 AND pab_idpolizasccs NOT IN (select pab_idpolizasccs from cxc_polizasccs WHERE pab_tipopoliza=2)

	SELECT * FROM @basesConcentra

	SELECT @max = COUNT(1) FROM @basesConcentra
	WHILE(@aux <= @max)
		BEGIN
			SELECT @pab_idpolizasccs=pab_idpolizasccs FROM @basesConcentra WHERE id = @aux
		if exists(	select c.pab_idempresa,			--<pab_idempresa, int,>
				c.pab_idsucursal,					--<pab_idsucursal, int,>
				c.pab_bancodestino,							--<pab_bancodestino, varchar(50),>
				0,							--<pab_estatus, int,>
				sum(d.abd_importeanticipo),		--<pag_importetotalbanco, decimal(18,5),>
				2,							--<pab_tipopoliza, int,>
				getdate(),					--<pab_fechaingreso, datetime,>
				null						--<pab_fechaproceso, datetime,>
				from cxc_polizasccs c
				inner join cxc_polizasccsdet d on c.pab_idpolizasccs=d.pab_idpolizasccs
				where c.pab_idpolizasccs=@pab_idpolizasccs
				group by c.pab_idempresa,			
				c.pab_idsucursal,					
				c.pab_bancodestino
) 
		begin
				--select * from @saldo
			INSERT INTO [dbo].[cxc_polizasccs]
						([pab_idempresa]
						,[pab_idsucursal]
						,[pab_bancodestino]
						,[pab_estatus]
						,[pag_importetotalbanco]
						,[pab_tipopoliza]
						,[pab_fechaingreso]
						,[pab_fechaproceso])
				select c.pab_idempresa,			--<pab_idempresa, int,>
				c.pab_idsucursal,					--<pab_idsucursal, int,>
				c.pab_bancodestino,							--<pab_bancodestino, varchar(50),>
				0,							--<pab_estatus, int,>
				sum(d.abd_importeanticipo-abd_ivamovimiento),		--<pag_importetotalbanco, decimal(18,5),>
				2,							--<pab_tipopoliza, int,>
				getdate(),					--<pab_fechaingreso, datetime,>
				null						--<pab_fechaproceso, datetime,>
				from cxc_polizasccs c
				inner join cxc_polizasccsdet d on c.pab_idpolizasccs=d.pab_idpolizasccs
				where c.pab_idpolizasccs=@pab_idpolizasccs and d.abd_movimientocan=0
				group by c.pab_idempresa,			
				c.pab_idsucursal,					
				c.pab_bancodestino

			Set @idenca=SCOPE_IDENTITY()

			INSERT INTO [dbo].[cxc_polizasccsdet]
						([abd_idcliente]
						,[abd_doctoanticipo]
						,[abd_doctofactura]
						,[abd_importeanticipo]
						,[abd_importefactura]
						,[pab_idpolizasccs]
						,[abd_movimientocan]
						,[abd_ivamovimiento])
			select
					[abd_idcliente],		--           (<abd_idcliente, numeric(18,0),>
					'',		--           ,<abd_doctoanticipo, varchar(60),>
					[abd_doctofactura],		--           ,<abd_doctofactura, varchar(60),>
					0	,				--           ,<abd_importeanticipo, decimal(18,5),>
					abd_importeanticipo,			--           ,<abd_importefactura, decimal(18,5),>
					@idenca,			--           ,<pab_idpolizasccs, numeric(18,0),>
					0,					--           ,<abd_cancelacion, int,>
					abd_ivamovimiento				--           ,<abd_ivamovimiento, decimal(18,5),>)
					from cxc_polizasccsdet
					where pab_idpolizasccs=@pab_idpolizasccs  and abd_movimientocan=0


	INSERT INTO [dbo].[LOG_polizasccs]
			   ([pab_idpolizasccs]
			   ,[idempresa]
			   ,[idsucursal]
			   ,[ucc_idcc]
			   ,[fecha]
			   ,[PAM_IDPERSONA]
			   ,[PAM_NOANTICIPO]
			   ,[PAM_IMPORTEMON]
			   ,[PAM_IVA]
			   ,[ucn_idFactura]
			   ,[ucn_total]
			   ,[fechaejecucion]
			   ,[diasemejecucion]
			   ,[nombrediadelasemanaejecucion]
			   ,[fechainicio]
			   ,[nombrediainicio]
			   ,[fechafin]
			   ,[nombrediafin]
			   ,[fechafinmes])
			select distinct @idenca
			   ,c.pab_idempresa
			   ,c.pab_idsucursal
			   ,l.ucc_idcc
			   ,getdate()
			   ,[PAM_IDPERSONA]
			   ,[PAM_NOANTICIPO]
			   ,[PAM_IMPORTEMON]
			   ,[PAM_IVA]
			   ,[ucn_idFactura]
			   ,[ucn_total]
			   ,getdate()
			   ,l.diasemejecucion
			   ,l.nombrediadelasemanaejecucion
			   ,l.fechainicio
			   ,l.nombrediainicio
			   ,l.fechafin
			   ,l.nombrediafin
			   ,l.fechafinmes
			   from cxc_polizasccs c
					inner join cxc_polizasccsdet d on c.pab_idpolizasccs=d.pab_idpolizasccs
					inner join LOG_polizasccs l on c.pab_idpolizasccs=l.pab_idpolizasccs
					where c.pab_idpolizasccs=@pab_idpolizasccs


		
				set @idenca=0
				SET @aux = @aux + 1
		END

		End
		
	
	
select * from [dbo].[cxc_polizasccs]
	select * from [dbo].[cxc_polizasccsdet]
	select * from dbo.LOG_polizasccs

END
	--truncate table [dbo].[cxc_polizasccs]
	--truncate table [dbo].[cxc_polizasccsdet]
	--truncate table dbo.LOG_polizasccs
	--delete from cxc_polizasccsdet where pab_idpolizasccs>8
	--delete from [cxc_polizasccs] where pab_tipopoliza=2
go

