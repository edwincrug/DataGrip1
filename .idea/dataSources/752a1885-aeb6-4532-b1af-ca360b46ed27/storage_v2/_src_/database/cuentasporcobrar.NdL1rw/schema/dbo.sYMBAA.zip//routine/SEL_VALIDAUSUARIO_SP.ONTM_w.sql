-- ==========================================================================================
-- Author:	 Ing. Alejandro Grijalva Antonio e Ing. Luis Antonio García Perrusquía
-- Create date:  21/04/2018
-- Description:	 Valida Usuario proveniente de BPRO
-- TEST [SEL_VALIDAUSUARIO_PRUEBA_SP] 71
-- ==========================================================================================
create PROCEDURE [dbo].[SEL_VALIDAUSUARIO_SP]
	@idUsuario  varchar(50)
AS
BEGIN
	SELECT
		usu_idusuario AS idUsuario,
		5 AS idPerfil,
		(usu_nombre + ' '+ usu_paterno + ' ' + usu_materno) AS nombreUsuario,
		'Administrador Total' AS nombrePerfil
	FROM [ControlAplicaciones].[dbo].[cat_usuarios]
	WHERE usu_idusuario = @idUsuario;

	-- Se obtiene los Botones
	DECLARE @Btn TABLE( Id INT IDENTITY, Accion INT, Boton VARCHAR(30) );
	-- DECLARE @idUsuario INT = 71;

	INSERT INTO @Btn
	SELECT sac_idAccion, sac_nombre
	FROM Seguridad.dbo.SEG_ACCION 
	WHERE smo_idModulo = 7;

	DECLARE @Current INT = 0, @Max INT = 0;
	SELECT @Current = MIN(Id), @Max = MAX(Id) FROM @Btn;
	DECLARE @Boton VARCHAR(30) = '', @Valor INT = 0; 
	DECLARE @Query VARCHAR(MAX) = '';
	WHILE( @Current <= @Max )
		BEGIN
			SELECT 
				@Valor = COUNT(seg_idCentralizacion), 
				@Boton = ( SELECT Boton FROM @Btn WHERE Id = @Current )
			FROM Seguridad.dbo.SEG_CENTRALIZACION CEN
			INNER JOIN @Btn TEM ON CEN.seg_idAccion = TEM.Accion AND Id = @Current
			WHERE seg_idUsuario = @idUsuario;

			SET @Query = @Query + @Boton + ' = ' + CONVERT( VARCHAR(1), @Valor) + ',';

			SET @Current = @Current + 1;
		END

	SET @Query = SUBSTRING( @Query, 1, ( LEN(@Query) - 1 ) );
	EXECUTE( 'SELECT ' + @Query  );
END
go

