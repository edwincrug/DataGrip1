-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Obtiene los catalogos
-- [SEL_Catalogo_SP] 71,4,6
-- ==========================================================================================
--[dbo].[SEL_ObtenerCCsMensualfechashow_SP] '26/10/2020'
CREATE PROCEDURE [dbo].[SEL_ObtenerCCsMensualfechashow_SP]
@fecha date
AS
BEGIN
--	Declare @fecha date='20/07/2020'
--select top 1000 * from GAZM_Zaragoza..cxc_pagant where month(convert(date,pam_fechope,103))=5 and  year(convert(date,pam_fechope,103))=2019 and PAM_IDCOTIZACIONWEB is not null and len(PAM_IDCOTIZACIONWEB)>1
--select * from cuentasporcobrar..uni_cotizacionuniversal where ucu_idcotizacion in(select PAM_IDCOTIZACIONWEB from GAZM_Zaragoza..cxc_pagant where month(convert(date,pam_fechope,103))=5 and  year(convert(date,pam_fechope,103))=2019 and PAM_IDCOTIZACIONWEB is not null and len(PAM_IDCOTIZACIONWEB)>1)
--select u.ucc_idcc,ucc_monto,ucu_foliocotizacion,ucu_idcliente,PAM_IDPERSONA,PAM_IDDOCTO,PAM_IMPORTEMON,PAM_OBSGEN,PAM_NOANTICIPO,c.ucu_idcotizacion from cuentasporcobrar..uni_ccs u
--inner join cuentasporcobrar..uni_cotizacionuniversal c on u.ucu_idcotizacion=c.ucu_idcotizacion
--inner join (select * from GAZM_Zaragoza..cxc_pagant where month(convert(date,pam_fechope,103))=5 and  year(convert(date,pam_fechope,103))=2019 and ucc_idcc is not null and len(ucc_idcc)>1) p on u.ucc_idcc=p.ucc_idcc
--where u.ucc_idcc=14144
DECLARE @ipLocal VARCHAR(50) = ''
			,@ipServer VARCHAR(50) = ''
			,@concentradora VARCHAR(70) = ''
			,@max INT
			,@aux INT = 1
			,@idempresa INT =0
			,@idsucursal INT=0
			,@idenca int=0
			,@monto decimal(18,2)
			,@cuentaContable nvarchar(25)
	DECLARE @basesConcentra TABLE(id INT IDENTITY,ip_server VARCHAR(50), nombre_base VARCHAR(70),idempresa INT,idsucursal INT)
		DECLARE @saldo TABLE(id INT IDENTITY, idempresa int,idsucursal int,ucc_idcc int ,fecha datetime,PAM_IDPERSONA numeric(18,0),PAM_NOANTICIPO NVARCHAR(20),PAM_IMPORTEMON decimal(18,5),PAM_IVA decimal(18,5),ucn_idFactura NVARCHAR(50),ucn_total decimal(18,5),ucu_iddepartamento int,tipo int,ucc_monto decimal(18,5))
		DECLARE @saldoneg TABLE(id INT IDENTITY, idempresa int,idsucursal int,ucc_idcc int ,fecha datetime,PAM_IDPERSONA numeric(18,0),PAM_NOANTICIPO NVARCHAR(20),PAM_IMPORTEMON decimal(18,5),PAM_IVA decimal(18,5),ucn_idFactura NVARCHAR(50),ucn_total decimal(18,5),ucu_iddepartamento int,tipo int,ucc_monto decimal(18,5))
	Declare @fechainicio date,@fechafin date, @dia int,@diasem int,@nombrediainicio nvarchar(10),@nombrediafin nvarchar(10),@fechafinmes date,@fechaLunes date,@nombredelasemana nvarchar(10),@cuentaContableOrigen nvarchar(50),@idbanco int, @idbancoOrigen int 
		,@clabeDestino nvarchar(20),@clabeOrigen nvarchar(20),@idpersona int
	SELECT	@ipLocal = local_net_address
	FROM	sys.dm_exec_connections
	WHERE	Session_id = @@SPID;

	select @diasem= diasem,
	@nombredelasemana=nombredelasemana,
	@fechainicio=fechainicio,
	@fechafin=fechafin,
	@nombrediainicio=nombrediainicio,
	@nombrediafin=nombrediafin,
	@fechafinmes=fechafinmes
	from  ObtenfechasCCs(@fecha)

	if @fechainicio is not null and @fechafin is not null
	begin
	INSERt INTO @basesConcentra
	SELECT	ip_servidor 
			,nombre_base 
			,emp_idempresa
			,suc_idsucursal
	FROM	Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
	WHERE	 tipo = 1 --and emp_idempresa in (5)
	order by emp_idempresa,suc_idsucursal
	--SELECT * FROM @basesConcentra
	--begin try
	--	 BEGIN TRANSACTION referenciaTramites
	SELECT @max = COUNT(1) FROM @basesConcentra
	WHILE(@aux <= @max)
		BEGIN
		
  			SELECT @concentradora = nombre_base, @ipServer = (CASE WHEN @ipLocal = ip_server THEN '' ELSE ip_server END),@idempresa=idempresa,@idsucursal=idsucursal FROM @basesConcentra WHERE id = @aux
				--SELECT @concentradora, @ipServer
	
				select top 1 @cuentaContable=b.cuentaContable,@idbanco=b.idBanco,@clabeDestino=cuentaClabe,@idpersona=r.idpersona from Rel_empresabanco r
			inner join referencias.dbo.BancoCuenta b on r.idCuenta=b.idCuenta
			where r.idempresa=@idempresa 
			select top 1 @cuentaContableOrigen=b.cuentaContable,@idbancoOrigen=b.idBanco,@clabeOrigen=cuentaClabe from Rel_empresabanco r
			inner join referencias.dbo.BancoCuenta b on r.idCuentaOrigen=b.idCuenta
			where r.idempresa=@idempresa 

			
				DECLARE @queryInserta VARCHAR(MAX) = 
			
	
'select '+convert(nvarchar(3),@idempresa)+' idempresa,'+convert(nvarchar(3),@idsucursal)+' idsucursal,cs.ucc_idcc,p.PAM_FECHOPE ucc_fechaalta,PAM_IDPERSONA,PAM_NOANTICIPO,PAM_IMPORTEMON,PAM_IMPORTEMON/(1.00+(PAM_PORIVA/100.00))*(PAM_PORIVA/100.00) PAM_IVA,ucn_idFactura+''-CC'' ucn_idfatura,ucn_total,c.[ucu_iddepartamento],1 tipo,cs.ucc_monto ' + CHAR(13) + 
'INTO #ANT_CORTE' + CHAR(13) + 
'from cuentasporcobrar..uni_ccs cs' + CHAR(13) + 
'inner join cuentasporcobrar..uni_cotizacionuniversal c on cs.ucu_idcotizacion=c.ucu_idcotizacion' + CHAR(13) + 
'inner join cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES u on c.ucu_idcotizacion=u.ucu_idcotizacion' + CHAR(13) + 
'inner join (select * from ' +  @ipServer + @concentradora + '..cxc_pagant ' + CHAR(13) + 
'where  ucc_idcc is not null and len(ucc_idcc)>1) p on cs.ucc_idcc=p.ucc_idcc' + CHAR(13) + 
'left join ' +  @ipServer + @concentradora + '..ade_cancfd f on p.PAM_IDDOCTO=f.CDE_DOCTO and f.CDE_TIPODOCTO = ''ANT'' and CONVERT(DATE,f.CDE_FECHAORACAR) between  '''+convert(nvarchar(10),@fechainicio)+''' and  '''+convert(nvarchar(10),@fechafin)+'''' + CHAR(13) + 
'where   f.cde_docto is null  and convert(date,p.PAM_FECHOPE,103) >= ''2020-06-23'' and  convert(date,p.PAM_FECHOPE,103) between  '''+convert(nvarchar(10),@fechainicio)+''' and   '''+convert(nvarchar(10),@fechafin)+'''  and len(ucn_idFactura)>0 and cs.ucc_idcc not in (select ucc_idcc from log_polizasccs) ' + CHAR(13) + 
'select  '+convert(nvarchar(3),@idempresa)+' idempresa,'+convert(nvarchar(3),@idsucursal)+' idsucursal,cs.ucc_idcc,cs.ucc_fechaalta,PAM_IDPERSONA,PAM_NOANTICIPO,PAM_IMPORTEMON,PAM_IMPORTEMON/(1.00+(PAM_PORIVA/100.00))*(PAM_PORIVA/100.00) PAM_IVA,ucn_idFactura+''-CC'' ucn_idfatura,ucn_total,c.[ucu_iddepartamento],-1 tipo,cs.ucc_monto ' + CHAR(13) + 
'INTO #ANTCAN_CORTE ' + CHAR(13) + 
'from cuentasporcobrar..uni_ccs cs ' + CHAR(13) + 
'inner join cuentasporcobrar..uni_cotizacionuniversal c on cs.ucu_idcotizacion=c.ucu_idcotizacion ' + CHAR(13) + 
'inner join cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES u on c.ucu_idcotizacion=u.ucu_idcotizacion ' + CHAR(13) + 
'inner join (select * from ' +  @ipServer + @concentradora + '..cxc_pagant p ' + CHAR(13) + 
'inner join ' +  @ipServer + @concentradora + '.dbo.ade_cancfd f on p.PAM_IDDOCTO=f.CDE_DOCTO and f.CDE_TIPODOCTO = ''ANT'' ' + CHAR(13) + 
'where  ucc_idcc is not null and len(ucc_idcc)>1 and CONVERT(DATE,f.CDE_FECHAORACAR) between  '''+convert(nvarchar(10),@fechainicio)+''' and  '''+convert(nvarchar(10),@fechafin)+''') p on cs.ucc_idcc=p.ucc_idcc  ' + CHAR(13) + 
'where len(ucn_idFactura)>0 and cs.ucc_idcc not in (select ucc_idcc from log_polizasccs) and cs.ucc_estatus=3 ' + CHAR(13) + 
'--ANTICIPOS GENERADOS Y CANCELADOS EN EL MISMO CORTE ' + CHAR(13) + 
'--SELECT * FROM #ANT_CORTE WHERE PAM_NOANTICIPO IN (SELECT PAM_NOANTICIPO FROM #ANTCAN_CORTE) ' + CHAR(13) + 
'--SI HAY ANTICPOS GENERADOS Y CANCELADOS EN EL CORTE SE ELIMINAN DE LAS 2 TABLAS ' + CHAR(13) + 
'DELETE FROM #ANT_CORTE WHERE PAM_NOANTICIPO IN ( ' + CHAR(13) + 
'SELECT PAM_NOANTICIPO FROM #ANT_CORTE WHERE PAM_NOANTICIPO IN (SELECT PAM_NOANTICIPO FROM #ANTCAN_CORTE)) ' + CHAR(13) + 
'DELETE FROM #ANTCAN_CORTE WHERE PAM_NOANTICIPO IN ( ' + CHAR(13) + 
'SELECT PAM_NOANTICIPO FROM #ANT_CORTE WHERE PAM_NOANTICIPO IN (SELECT PAM_NOANTICIPO FROM #ANTCAN_CORTE)) ' + CHAR(13) + 
'--SE DEBEN CONTEMPLAR ANTICIPOS CANCELADOS EN EL CORTE Y GENERADOS ANTES DEL CORTE PERO DEPUES DEL ARRANQUE ' + CHAR(13) + 
'SELECT * ' + CHAR(13) + 
'INTO #ANTCAN_OTRCORTES ' + CHAR(13) + 
'FROM #ANTCAN_CORTE WHERE PAM_NOANTICIPO IN  ' + CHAR(13) + 
'(SELECT PAM_IDDOCTO FROM ' +  @ipServer + @concentradora + '..CXC_PAGANT WHERE PAM_TIPODOCTO = ''ANT'' AND ucc_idcc IS NOT NULL AND CONVERT(DATE,PAM_FECHOPE) BETWEEN ''25/06/2020'' AND '''+convert(nvarchar(10),dateadd(day,-1,@fechainicio),103)+''') ' + CHAR(13) + 
' --ELIMINAR DE LA TABLA #ANTCAN_CORTE LOS ANTICIPOS QUE NO SE ENCUENTREN EN ESTA TABLA DE CANCELACONES DE OTROS CORTES ' + CHAR(13) + 
'DELETE FROM #ANTCAN_CORTE WHERE PAM_NOANTICIPO NOT IN (SELECT PAM_NOANTICIPO FROM #ANTCAN_OTRCORTES) ' + CHAR(13) + 
'SELECT * FROM #ANT_CORTE ' + CHAR(13) + 
'union all ' + CHAR(13) + 
'SELECT * FROM #ANTCAN_CORTE ' 
	
				PRINT (@queryInserta) 
				INSERT INTO @saldo
				EXEC(@queryInserta)
			
		-----------------------------------------------
				-------------------------------------------------
				DECLARE @Counter INT ,@countermax int
				DECLARE @name nvarchar(60),@num int,@partea nvarchar(30)='',@parteb nvarchar(30)='',@nombre nvarchar(60),@tempnombre nvarchar(60),@tempnum int
					SET @Counter=1
					select @countermax=max(id) from @saldo
					WHILE ( @Counter <= @countermax)
					BEGIN
					 set @tempnombre=''
					 set @tempnum=0
					 select @nombre=ucn_idfactura from @saldo where id=@counter

					 
					SELECT @tempnombre=ucn_idFactura,@tempnum=count(*)
     
					  FROM @saldo
					  where ucn_idFactura like @nombre+'%'
					  group by ucn_idFactura
					  having count(*)>1
					  
					  if @tempnum >1
					  begin
					  SELECT top 1 @name=ucn_idFactura
     
					  FROM @saldo
					  where ucn_idFactura like @nombre+'%'
					--  group by ucn_idFactura
					  order by ucn_idFactura desc

					  if len(@name)>0
					  begin
					  set @num=CHARINDEX('-', @name)+2; 
					  set @partea=substring(@name,1,@num)
					  set @parteb=substring(@name,@num+1,len(@name)-@num)
						if @num=len(@name)
						begin
						 set @parteb='0'
						Set @name =@partea+convert(nvarchar(30),convert(int,@parteb)+1)
						end
						else
						begin
						  Set @name =@partea+convert(nvarchar(30),convert(int,@parteb)+1)
						end
					  End
					  else
					  begin
					  Set @name=@nombre
					  End

					 -- select @name,@nombre,@num,len(@name),@partea,@parteb
						update @saldo set ucn_idFactura=@name where id=@Counter
					  end
					


						SET @Counter  = @Counter  + 1
					END
				-------------------------------------------------
				if (select	sum((PAM_IMPORTEMON)*tipo) from @saldo)<>0
					 begin
				INSERT INTO [dbo].[polizacss_temp]
							([pab_idempresa]
							,[pab_idsucursal]
							,[pab_bancodestino]
							,[pab_estatus]
							,[pag_importetotalbanco]
							,[pab_tipopoliza]
							,[pab_fechaingreso]
							,[pab_fechaproceso])
					select idempresa pab_idempresa,			--<pab_idempresa, int,>
					idsucursal pab_idsucursal,					--<pab_idsucursal, int,>
					@cuentaContable pab_bancodestino,							--<pab_bancodestino, varchar(50),>
					-1 pab_estatus,							--<pab_estatus, int,>
					sum(PAM_IMPORTEMON*tipo) pag_importetotalbanco,		--<pag_importetotalbanco, decimal(18,5),>
					1 pab_tipopoliza,							--<pab_tipopoliza, int,>
					getdate() pab_fechaingreso,					--<pab_fechaingreso, datetime,>
					null	pab_fechaproceso					--<pab_fechaproceso, datetime,>
					from @saldo
					group by idempresa,idsucursal

				Set @idenca=SCOPE_IDENTITY()

				INSERT INTO [dbo].[polizacssdet_temp]
							([abd_idcliente]
							,[abd_doctoanticipo]
							,[abd_doctofactura]
							,[abd_importeanticipo]
							,[abd_importefactura]
							,[pab_idpolizasccs]
							,[abd_movimientocan]
							,[abd_ivamovimiento])
				select
						PAM_IDPERSONA abd_idcliente,		--           (<abd_idcliente, numeric(18,0),>
						PAM_NOANTICIPO abd_doctoanticipo,		--           ,<abd_doctoanticipo, varchar(60),>
						dbo.[EncuentraNombre](ucn_idFactura) abd_doctofactura,		--           ,<abd_doctofactura, varchar(60),>
						PAM_IMPORTEMON	abd_importeanticipo,				--           ,<abd_importeanticipo, decimal(18,5),>
						ucn_total abd_importefactura,			--           ,<abd_importefactura, decimal(18,5),>
						@idenca pab_idpolizasccs,			--           ,<pab_idpolizasccs, numeric(18,0),>
						case when tipo=-1 then 1 else 0 end abd_cancelacion,					--           ,<abd_cancelacion, int,>
						PAM_IVA		abd_ivamovimiento		--           ,<abd_ivamovimiento, decimal(18,5),>)
						from @saldo


			INSERT INTO [dbo].[polizacsslog_temp]
					   ([pab_idpolizasccs]
					   ,[idempresa]
					   ,[idsucursal]
					   ,[ucc_idcc]
					   ,[fecha]
					   ,[PAM_IDPERSONA]
					   ,[PAM_NOANTICIPO]
					   ,[PAM_IMPORTEMON]
					   ,[PAM_IVA]
					   ,[ucn_idFactura]
					   ,[ucn_total]
					   ,ucn_monto
					   ,[fechaejecucion]
					   ,[diasemejecucion]
					   ,[nombrediadelasemanaejecucion]
					   ,[fechainicio]
					   ,[nombrediainicio]
					   ,[fechafin]
					   ,[nombrediafin]
					   ,[fechafinmes])
					select @idenca
					   ,[idempresa]
					   ,[idsucursal]
					   ,[ucc_idcc]
					   ,[fecha]
					   ,[PAM_IDPERSONA]
					   ,[PAM_NOANTICIPO]
					   ,[PAM_IMPORTEMON]
					   ,[PAM_IVA]
					   ,dbo.[EncuentraNombre](ucn_idFactura)
					   ,ucn_total
					   ,ucc_monto
					   ,@fecha
					   ,@diasem
					   ,@nombredelasemana
					   ,@fechainicio
					   ,@nombrediainicio
					   ,@fechafin
					   ,@nombrediafin
					   ,@fechafinmes
					   from @saldo

	------------------------------Crear la referencia

	--DECLARE @cuentaOrigen varchar(150)=@cuentaContableOrigen
	--		DECLARE @cuentaDestino varchar(150)=@cuentaContable
			
	--		DECLARE @idUsuario int=1
	--		DECLARE @solicitaAuto int=1
	--		DECLARE @fueraHorario int=0
	--		DECLARE @automatico bit=1
	--		DECLARE @idDepartamento int
	--		DECLARE @idOrigenSistema int=5 --referencias.dbo.[CatalogoReferenciaOrigen]
	--		DECLARE @idBancoDestino int=@idbanco
	--		DECLARE @documento varchar(100)
	--		select @idempresa=idempresa,		
	--						@idSucursal=idsucursal,				
	--						@monto=sum(PAM_IMPORTEMON*tipo),
	--						@idDepartamento=max(ucu_iddepartamento)
	--						from @saldo
	--						group by idempresa,idsucursal


	--	DECLARE @referencia VARCHAR(20) = ''
	--	DECLARE @consecutivo INT = 0
	--	DECLARE @idReferencia INT = 0
	--	SET @referencia = RIGHT('000' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @idEmpresa))), 3)
	--	+ REPLACE(CONVERT(VARCHAR(20), GETDATE(), 103), '/', '')
	--	+ RIGHT('000' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @idBancoOrigen))), 3)
	--	+ RIGHT('000' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @idBancoDestino))), 3)
	--	+ CONVERT(VARCHAR(4), @idOrigenSistema)
	--	--SELECT @referencia
	--	--SELECT * FROM [dbo].[ReferenciaTramite] WHERE SUBSTRING(referencia,1,18) = @referencia
	--	SELECT
	--	  @consecutivo = ISNULL(COUNT(idReferenciaTramite), 0) + 1
	--	FROM [referencias].dbo.[ReferenciaTramite]
	--	WHERE SUBSTRING(referencia, 1, 18) = @referencia
	--	SET @referencia = @referencia + RIGHT('00' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @consecutivo))), 2)
	--	--SELECT @referencia 
	--	INSERT INTO [referencias].[dbo].[ReferenciaTramite] (idEmpresa
	--	, fecha
	--	, referencia
	--	, idOrigenReferencia
	--	, consecutivo
	--	, estatus)
	--	select idempresa,getdate(),@referencia,@idOrigenSistema,@consecutivo,1
	--	from @saldo
	--	group by idempresa,idsucursal
	--	--  VALUES (@idEmpresa, GETDATE(), @referencia, @idOrigenSistema, @consecutivo, 1)
	--	SET @idReferencia = @@IDENTITY;
	--	INSERT INTO [referencias].dbo.[DetalleReferenciaTramite]
	--	select @idReferencia,
	--	idsucursal,
	--	ucu_iddepartamento,
	--	@idbancoOrigen,
	--	@idbanco,
	--	s.ucn_idFactura,
	--	PAM_IMPORTEMON,
	--	PAM_IDPERSONA
	--	from @saldo s
	
	--  DECLARE @respuestaReferencia TABLE (
	--  estatus nvarchar(50)
	--  ,mensaje VARCHAR(150)
	--	,folio int
  
	--    )
     
	 
	--  DECLARE @respuestaReferenciaTramite TABLE (
	--	estatus VARCHAR(50)
	--   ,mensaje VARCHAR(50)
	--   ,idpertra VARCHAR(50)
	--   )
	--   select  @idempresa
	--		  ,@idSucursal
	--		  ,@cuentaOrigen
	--		  ,@cuentaDestino
	--		  ,@monto
	--		  ,@idpersona
	--		  ,@solicitaAuto
	--		  ,@fueraHorario
	--		  ,@automatico
	--		  ,@idOrigenSistema
	--		  ,@referencia

	--		-- TODO: Set parameter values here.
	--		 INSERT INTO @respuestaReferencia
	--		EXEC tesoreria.[dbo].[TransferenciasBancariasCCS_SP] 
	--		   @idempresa
	--		  ,@idSucursal
	--		  ,@cuentaOrigen
	--		  ,@cuentaDestino
	--		  ,@monto
	--		  ,@idpersona
	--		  ,@solicitaAuto
	--		  ,@fueraHorario
	--		  ,@automatico
	--		  ,@idOrigenSistema
	--		  ,@referencia




	--		DECLARE @idTramite int=11
	--		DECLARE @idTransferencia int
	--		select @idTransferencia=folio from @respuestaReferencia

	--		INSERT INTO @respuestaReferenciaTramite
	--		EXEC tramites.[dbo].[INS_PERSONATRAMITE_TRANFERENCIAS_SP] 
	--		   @idPersona
	--		  ,@idTramite
	--		  ,@idTransferencia
	--		  ,0

	--		 ------ mandar correo
			 
	--		INSERT INTO [cuentasporcobrar].dbo.[MandarCorreo]
	--				   ([idpertra]
	--				   ,[idempresa]
	--				   ,[idsucursal]
	--				   ,[idbancoorigen]
	--				   ,[CLABEorigen]
	--				   ,[idbancodestino]
	--				   ,[CLABEdestino]
	--				   ,[importe]
	--				   ,[fecha]
	--				   ,[referencia]
	--				   ,[idCCs]
	--				   ,[idtransferencia]
	--				   ,[idestatus]
	--				   ,[fechaenviado])
	--		 select top 1 idpertra+@aux-1,
	--		 @idempresa,
	--		 @idsucursal,
	--		 @idbancoOrigen,
	--		 @clabeOrigen,
	--		 @idBancoDestino,
	--		 @clabeDestino,
	--		 @monto,
	--		 getdate(),
	--		 @referencia,
	--		 @idenca,
	--		 @idTransferencia,
	--		 0,
	--		 null
	--		 from    @respuestaReferenciaTramite

	select * from @saldo

			  delete from @saldo
			 
   

	

			
	
	end

	
			set @idenca=0
			Set @monto=0
			SET @aux = @aux + 1

END

	 --COMMIT TRANSACTION referenciaTramites
	 -- END TRY
	 -- BEGIN CATCH
		--ROLLBACK TRANSACTION referenciaTramites
		--SELECT
		--  0 AS estatus
		-- ,ERROR_MESSAGE() AS mensaje
	 -- END CATCH

select * from  [dbo].[polizacss_temp]
	select * from [dbo].[polizacssdet_temp]
	select * from [dbo].[polizacsslog_temp]
End
	else
	begin
	Select 'Hoy no es primero o dia lunes, no se puede ejecutar'
	End
END
	--truncate table [dbo].[polizacss_temp]
	--truncate table [dbo].[polizacssdet_temp]
	--truncate table [dbo].[polizacsslog_temp]

go

