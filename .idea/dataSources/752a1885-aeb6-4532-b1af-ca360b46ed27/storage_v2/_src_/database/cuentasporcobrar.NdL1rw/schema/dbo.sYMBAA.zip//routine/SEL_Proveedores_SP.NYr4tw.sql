-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Obtiene los proveedores
-- ==========================================================================================
--[dbo].[SEL_Proveedores_SP] 2,'morales'
create PROCEDURE [dbo].[SEL_Proveedores_SP]
@tipo int,
@busqueda nvarchar(150)
AS
BEGIN
if @tipo = 1
 SELECT PER_IDPERSONA idpersona,case when per_tipo='mor' then PER_NOMRAZON else  LTRIM(LTRIM(PER_PATERNO) + ' ' + LTRIM(PER_MATERNO) + ' ' + LTRIM(PER_NOMRAZON)) end proveedor,p.per_rfc rfc
							FROM  ga_corporativa.dbo.per_personas p 
							where PER_IDPERSONA = @busqueda
							order by proveedor
else if @tipo= 2
 SELECT top 1000 PER_IDPERSONA idpersona,case when per_tipo='mor' then PER_NOMRAZON else  LTRIM(LTRIM(PER_PATERNO) + ' ' + LTRIM(PER_MATERNO) + ' ' + LTRIM(PER_NOMRAZON)) end proveedor,p.per_rfc rfc
							FROM  ga_corporativa.dbo.per_personas p 
							where   LTRIM(rTRIM(PER_NOMRAZON+PER_PATERNO+PER_MATERNO)) like '%'+@busqueda+'%'
							order by proveedor
else if @tipo= 3
 SELECT PER_IDPERSONA idpersona,case when per_tipo='mor' then PER_NOMRAZON else  LTRIM(LTRIM(PER_PATERNO) + ' ' + LTRIM(PER_MATERNO) + ' ' + LTRIM(PER_NOMRAZON)) end proveedor,p.per_rfc rfc
							FROM  ga_corporativa.dbo.per_personas p 
							where  per_rfc like '%'+@busqueda+'%'
							order by proveedor

        
END
go

