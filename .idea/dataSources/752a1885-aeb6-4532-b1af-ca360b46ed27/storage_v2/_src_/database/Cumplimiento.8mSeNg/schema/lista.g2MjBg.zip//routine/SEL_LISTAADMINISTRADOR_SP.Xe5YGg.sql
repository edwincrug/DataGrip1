-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-10-29
-- Description:	Devuelve listas de cumplimiento para los admin
-- [lista].[SEL_LISTAADMINISTRADOR_SP] 29, ''
-- =============================================
CREATE PROCEDURE [lista].[SEL_LISTAADMINISTRADOR_SP]
	@idUsuario INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET LANGUAGE Español;

	SET @err = '';
	SELECT 
		[nombreLista] = LC.nombreLista,
		[tipoEntrega] = TE.nombreTipoEntrega,
		[idEntrega] = E.idEntrega, 
		[fechaEntrega] = CONVERT(varchar,E.fechaEntrega,100),
		[avance] = ISNULL( [entrega].[OBTIENEAVANCELISTA_FN]( E.idEntrega ), 0 ),
		[color] = 'danger'
	FROM entrega.Entrega E
	JOIN entrega.EstatusEntregaHistorico HIS ON E.idEntrega = HIS.idEntrega
	JOIN lista.ListaCumplimiento LC ON LC.idListaCumplimiento = E.idListaCumplimiento
	JOIN catalogo.TipoEntrega TE ON TE.idTipoEntrega = LC.idTipoEntrega
	WHERE 
		HIS.idEstatusEntrega = 1
		AND LC.idUsuario = @idUsuario
	ORDER BY E.fechaEntrega DESC
END
go

