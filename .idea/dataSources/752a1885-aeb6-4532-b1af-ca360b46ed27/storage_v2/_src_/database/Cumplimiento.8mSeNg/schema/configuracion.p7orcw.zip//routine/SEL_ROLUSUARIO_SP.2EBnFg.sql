-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-25
-- Description:	Obtiene el rol de un usuario
-- =============================================
CREATE PROCEDURE [configuracion].[SEL_ROLUSUARIO_SP]
	@idUsuario INT
AS
BEGIN
	SET NOCOUNT ON;
	SET LANGUAGE Español;

	SELECT [rolId] FROM [Seguridad].[relacion].[UsuarioRol] WHERE [usuarioId] = @idUsuario
END
go

