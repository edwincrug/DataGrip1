-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <22/10/2020>
-- Description:	<Obtiene el historial de amarre de caja>
-- COPIA DE PRUEBA
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [caja].[SEL_AMARRECAJA_SP] @idusuario = 3,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [dbo].[SEL_AMARRECAJA_SP]
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS

BEGIN
	SET @err = '';

	SELECT 
	   [idHistorialCaja]
      ,'cumplimiento prueba' [sucursal]
      ,[fecha]
      ,[totalBanco]
      ,[totalDepositar]
      ,[saldoFinal]
      ,[diferencia]
      ,[importe]
      ,[activo]
      ,[idUsuario]
	FROM [AmarreCaja].[caja].[HistorialCaja]
	WHERE activo = 1
END
go

