-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-19
-- Description:	Devuelve listas de los comentarios por estatus
-- [comentario].[SEL_COMENTARIO_SP] 38, 29, ''
-- =============================================
CREATE PROCEDURE [comentario].[SEL_COMENTARIO_SP]
	@idEstatusEntregaReporteHistorico INT,
	@idUsuario INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET LANGUAGE Español;

	SET @err = '';
	
	SELECT 
		idComentario, 
		mensaje, 
		C.idUsuario, 
		[usuarioNombre] = [primerNombre] + ' ' + [segundoNombre] + ' ' + [primerApellido] + ' ' + [segundoApellido],
		idDocumentos, 
		C.IdEntregaReporte, 
		C.idEstatusEntregaReporteHistorico,
		C.fechaRegistro,
		[configuracion].[FORMATOFECHA_FN]( C.fechaRegistro ) fecha,
		EST.nombreEstatusEntregaReporte,
		EST.rgb
	FROM comentario.Comentario C
	JOIN [Seguridad].[catalogo].[Usuario] U ON C.idUsuario = U.id
	JOIN [entrega].[EstatusEntregaReporteHistorico] HIS ON HIS.idEstatusEntregaReporteHistorico = C.idEstatusEntregaReporteHistorico
	JOIN [catalogo].[EstatusEntregaReporte] EST ON EST.idEstatusEntregaReporte = HIS.idEstatusEntregaReporte
	WHERE C.idEstatusEntregaReporteHistorico = @idEstatusEntregaReporteHistorico
	ORDER BY idComentario DESC
END
go

