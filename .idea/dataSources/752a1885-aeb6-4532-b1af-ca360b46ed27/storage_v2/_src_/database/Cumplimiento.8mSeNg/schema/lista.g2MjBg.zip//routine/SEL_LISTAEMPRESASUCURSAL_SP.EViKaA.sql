CREATE PROCEDURE [lista].[SEL_LISTAEMPRESASUCURSAL_SP]
	@idReporte				int,
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SELECT
		EMP.emp_idempresa idEmpresa, 
		max(EMP.emp_nombre) empresaNombre
	FROM lista.ListaCumplimientoSucursalUsuario LCSU
	JOIN lista.ListaCumplimientoReporte LCR ON LCSU.idListaCumplimiento = LCR.idListaCumplimiento
	JOIN entrega.Entrega ENT ON ENT.idListaCumplimiento = LCSU.idListaCumplimiento
	JOIN entrega.EstatusEntregaHistorico EENT ON ENT.idEntrega = EENT.idEntrega AND idEstatusEntrega = 1
	JOIN entrega.EntregaReporte ER ON ER.idListaCumplimientoSucursalUsuario = LCSU.idListaCumplimientoSucursalUsuario
	JOIN entrega.EstatusEntregaReporteHistorico EERH ON ER.idEntregaReporte = EERH.idEntregaReporte AND EERH.esActivo = 1
	JOIN catalogo.EstatusEntregaReporte EER ON EERH.idEstatusEntregaReporte = EER.idEstatusEntregaReporte
	JOIN temp.cat_sucursales SUC ON LCSU.idSucursal = SUC.suc_idsucursal
	JOIN temp.cat_empresas EMP ON EMP.emp_idempresa = SUC.emp_idempresa 
	WHERE LCR.idReporte = @idReporte 
	GROUP BY EMP.emp_idempresa
	
	--AND LCSU.idUsuario = @idUsuario

	SELECT
		S.idEmpresa,
		EMP.emp_nombre,
		S.idSucursal suc_idsucursal, 
		CS.suc_nombre,
		ER.idEntregaReporte,
		ERH.idEstatusEntregaReporteHistorico,
		CER.idEstatusEntregaReporte,
		CER.nombreEstatusEntregaReporte,
		CER.color,
		CER.icono,
		CER.rgb
	FROM entrega.EntregaReporte ER
	JOIN entrega.EstatusEntregaReporteHistorico ERH ON ER.idEntregaReporte = ERH.idEntregaReporte AND ERH.esActivo = 1
	JOIN catalogo.EstatusEntregaReporte CER ON CER.idEstatusEntregaReporte = ERH.idEstatusEntregaReporte
	JOIN lista.ListaCumplimientoReporte CR ON CR.idListaCumplimientoReporte = ER.idListaCumplimientoReporte
	JOIN lista.ListaCumplimientoSucursalUsuario SUC ON SUC.idListaCumplimientoSucursalUsuario = ER.idListaCumplimientoSucursalUsuario
	JOIN configuracion.Sucursal S ON S.idSucursal = SUC.idSucursal
	JOIN temp.cat_sucursales CS ON CS.suc_idsucursal = S.idSucursal
	JOIN temp.cat_empresas EMP ON EMP.emp_idempresa = CS.emp_idempresa 
	WHERE	
		CR.idReporte = @idReporte
		AND SUC.idUsuario = 31
	ORDER BY EMP.emp_idempresa, CS.suc_idsucursal ASC

	--SELECT
	--	EMP.emp_idempresa idEmpresa, 
	--	SUC.suc_idsucursal, 
	--	SUC.suc_nombre,
	--	EERH.idEntregaReporte,
	--	EERH.idEstatusEntregaReporteHistorico,
	--	EER.idEstatusEntregaReporte, 
	--	EER.nombreEstatusEntregaReporte, 
	--	EER.color,
	--	EER.icono,
	--	EER.rgb
	--FROM lista.ListaCumplimientoSucursalUsuario LCSU
	--JOIN lista.ListaCumplimientoReporte LCR ON LCSU.idListaCumplimiento = LCR.idListaCumplimiento
	--JOIN entrega.Entrega ENT ON ENT.idListaCumplimiento = LCSU.idListaCumplimiento
	--JOIN entrega.EstatusEntregaHistorico EENT ON ENT.idEntrega = EENT.idEntrega AND idEstatusEntrega = 1
	--JOIN entrega.EntregaReporte ER ON ER.idListaCumplimientoSucursalUsuario = LCSU.idListaCumplimientoSucursalUsuario
	--JOIN entrega.EstatusEntregaReporteHistorico EERH ON ER.idEntregaReporte = EERH.idEntregaReporte AND EERH.esActivo = 1
	--JOIN catalogo.EstatusEntregaReporte EER ON EERH.idEstatusEntregaReporte = EER.idEstatusEntregaReporte
	--JOIN temp.cat_sucursales SUC ON LCSU.idSucursal = SUC.suc_idsucursal
	--JOIN temp.cat_empresas EMP ON EMP.emp_idempresa = SUC.emp_idempresa 
	--WHERE LCR.idReporte = @idReporte 
END
go

