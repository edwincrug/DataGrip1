
-- =============================================
-- Author: Alejandro Grijalva Antonio
-- Create date: 18-11-2020
-- Description: Devuelve la lista de los documentos
-- [entrega].[SEL_DOCUMENTOSPORREPORTE_SP] 21,1,''
-- =============================================

CREATE PROCEDURE [entrega].[SEL_DOCUMENTOSPORREPORTE_SP]
	@idEntregaReporte INT,
	@idUsuario		  INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SELECT idDocumento FROM entrega.ReporteArchivo WHERE idEntregaReporte = @idEntregaReporte-- AND esActivo = 1
END
go

