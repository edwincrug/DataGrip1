-- =============================================
-- Author:		Fernando Tamanis Pérez
-- Create date: 25-11-2020
-- Description: actualiza el campo esActivo a la tabla notificacion.Notificacion
-- EXEC			[notificacion].[UPD_LISTANOTIFICACION_SP]
-- =============================================

CREATE PROCEDURE [notificacion].[UPD_LISTANOTIFICACION_SP]
	@idNotificacion BIGINT,
	@idUsuario	INT,
	@err	VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
	BEGIN TRY

		UPDATE [notificacion].[Notificacion]
		SET esActivo = 0
		WHERE idNotificacion = @idNotificacion AND idUsuarioDestinatario = @idUsuario;
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

