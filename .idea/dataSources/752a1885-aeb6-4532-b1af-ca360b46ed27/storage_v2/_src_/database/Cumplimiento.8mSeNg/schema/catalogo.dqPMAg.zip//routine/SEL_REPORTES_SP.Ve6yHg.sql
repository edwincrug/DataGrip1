-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-10-30
-- Description:	Devuelve el catalogo de reportes
-- [catalogo].[SEL_REPORTES_SP] 29, ''
-- =============================================
CREATE PROCEDURE [catalogo].[SEL_REPORTES_SP]
	@idUsuario INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET LANGUAGE Español;

	SET @err = '';

	SELECT 
		RES.idResponsable [id], RES.nombreResponsable [name], [completed] = 0
	FROM [catalogo].[Reporte] REP
	JOIN [catalogo].[Area] A ON REP.idArea = A.idArea
	JOIN [catalogo].[Responsable] RES ON RES.idResponsable = REP.idResponsable
	GROUP BY RES.idResponsable, RES.nombreResponsable
	ORDER BY RES.nombreResponsable

	SELECT 
		A.idArea [id], A.nombreArea [name], [completed] = 0
	FROM [catalogo].[Reporte] REP
	JOIN [catalogo].[Area] A ON REP.idArea = A.idArea
	JOIN [catalogo].[Responsable] RES ON RES.idResponsable = REP.idResponsable
	GROUP BY A.idArea, A.nombreArea
	ORDER BY A.nombreArea

	SELECT 
		REP.idReporte, claveReporte, A.nombreArea, RES.nombreResponsable, nombreReporte, descripcionReporte
	FROM [catalogo].[Reporte] REP
	JOIN [catalogo].[Area] A ON REP.idArea = A.idArea
	JOIN [catalogo].[Responsable] RES ON RES.idResponsable = REP.idResponsable
END
go

