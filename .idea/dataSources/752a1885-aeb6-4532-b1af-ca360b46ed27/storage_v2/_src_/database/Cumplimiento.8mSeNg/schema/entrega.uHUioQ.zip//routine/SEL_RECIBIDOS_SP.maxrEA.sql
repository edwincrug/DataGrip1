-- =============================================
-- Author: Alejandro Grijalva Antonio
-- Create date: 24-11-2020
-- Description: Devuelve lista de reporte recibidos
-- =============================================

CREATE PROCEDURE [entrega].[SEL_RECIBIDOS_SP]
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS
BEGIN
	/****** Script for SelectTopNRows command from SSMS  ******/
	SELECT
		[idEstatusEntregaReporteHistorico]
		,sucursal = S.suc_nombre
		,empresa = E.emp_nombre
		,reporte = R.nombreReporte
		,lista = L.nombreLista
		,fechaEntrega = [configuracion].[FORMATOFECHA_FN]( HIS.[fechaRegistro] )
		,visto = isnull([visto], 0)
		,s.suc_idsucursal idSucursal
	FROM [entrega].[EstatusEntregaReporteHistorico] HIS
	JOIN [entrega].[EntregaReporte] ER ON HIS.idEntregaReporte = ER.idEntregaReporte
	JOIN [lista].[ListaCumplimientoReporte] LR ON LR.idListaCumplimientoReporte = ER.idListaCumplimientoReporte
	JOIN [catalogo].[Reporte] R ON R.idReporte = LR.idReporte
	JOIN [lista].[ListaCumplimiento] L ON L.idListaCumplimiento = LR.idListaCumplimiento
	JOIN [lista].[ListaCumplimientoSucursalUsuario] LS ON ER.idListaCumplimientoSucursalUsuario = LS.idListaCumplimientoSucursalUsuario
	JOIN [ControlAplicaciones].[dbo].[cat_sucursales] S ON LS.idSucursal = S.suc_idsucursal
	JOIN [ControlAplicaciones].[dbo].[cat_empresas] E ON S.emp_idempresa = E.emp_idempresa
	WHERE
		[esActivo] = 1
		AND idEstatusEntregaReporte = 2
	ORDER BY HIS.[fechaRegistro] DESC
END
go

