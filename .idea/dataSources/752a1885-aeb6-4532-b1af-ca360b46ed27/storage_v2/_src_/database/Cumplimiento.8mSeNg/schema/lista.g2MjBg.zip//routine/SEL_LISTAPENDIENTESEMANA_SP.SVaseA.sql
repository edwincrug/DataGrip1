
-- =============================================
-- Author: Fernando Tamanis Pérez
-- Create date: 19-11-2020
-- Description: Devuelve la lista de cumplimiento de reportes con fecha superior a la actual
-- EXEC			[lista].[SEL_LISTAPENDIENTESEMANA_SP]
-- =============================================
CREATE PROCEDURE [lista].[SEL_LISTAPENDIENTESEMANA_SP]
	@fechaActual			date,
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS
BEGIN
SELECT DISTINCT
	LC.idListaCumplimiento, 
	nombreLista, 
	LC.descripcionLista, 
	TE.nombreTipoEntrega, 
	[fechaEntrega] = CONVERT(VARCHAR,fechaEntrega),
	EE.nombreEstatusEntrega, 
	EL.nombreEstatusLista
FROM entrega.Entrega E
JOIN lista.ListaCumplimiento LC ON E.idListaCumplimiento = LC.idListaCumplimiento
JOIN lista.ListaCumplimientoSucursalUsuario CSU ON LC.idListaCumplimiento = CSU.idListaCumplimiento
JOIN catalogo.TipoEntrega TE ON TE.idTipoEntrega = LC.idTipoEntrega
JOIN entrega.EstatusEntregaHistorico EH ON EH.idEntrega = E.idEntrega AND EH.idEstatusEntrega = 1
JOIN catalogo.EstatusEntrega EE ON EH.idEstatusEntrega = EE.idEstatusEntrega
JOIN lista.EstatusListaHistorial LH ON LH.idListaCumplimiento = LC.idListaCumplimiento AND LH.idEstatusLista = 3
JOIN catalogo.EstatusLista EL ON LH.idEstatusLista = EL.idEstatusLista
WHERE CSU.idUsuario = @idUsuario AND EL.idEstatusLista = 3 AND EE.idEstatusEntrega = 1 AND fechaEntrega > CONVERT(date,@fechaActual) ORDER BY fechaEntrega ASC
END
go

