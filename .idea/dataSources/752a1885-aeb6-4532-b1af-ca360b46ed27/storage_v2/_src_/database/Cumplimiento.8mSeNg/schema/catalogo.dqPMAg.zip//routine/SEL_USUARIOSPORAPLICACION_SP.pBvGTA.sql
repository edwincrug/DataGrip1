-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-12
-- Description:	Devuelve el catalogo de usuarios por aplicacion y rol especifico
-- [catalogo].[SEL_USUARIOSPORAPLICACION_SP] 29, ''
-- =============================================
CREATE PROCEDURE [catalogo].[SEL_USUARIOSPORAPLICACION_SP]
	@idUsuario		INT,
	@err			varchar(max) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET LANGUAGE Español;

	SET @err = '';

	SELECT 
			[id] position
			,ISNULL(u.PrimerNombre,'') + ' ' + ISNULL(U.SegundoNombre,'')+' '+ ISNULL(u.PrimerApellido,'') + ' ' +ISNULL(u.SegundoApellido,'') 'name'
			,[EstatusId] weight
			,REPLACE((SUBSTRING(username,1,(CHARINDEX('@',[userName])))),'@','') 'symbol'
	FROM	[Seguridad].[catalogo].[Usuario] U
			JOIN [Seguridad].[relacion].[UsuarioRol] UR ON U.id = UR.usuarioId
	WHERE	
			U.UID IS NOT NULL
			AND estatusId != 3
			AND UR.aplicacionId = 6
			AND rolId IN (21)
	ORDER BY u.PrimerNombre ASC
			

	--SELECT 
	--		[id]
	--		,ISNULL(u.PrimerNombre,'') + ' ' + ISNULL(U.SegundoNombre,'')+' '+ ISNULL(u.PrimerApellido,'') + ' ' +ISNULL(u.SegundoApellido,'') 'nombreCompleto'
	--		,REPLACE((SUBSTRING(username,1,(CHARINDEX('@',[userName])))),'@','') usuarioBPRO
	--		,[primerNombre]
	--		,[segundoNombre]
	--		,[primerApellido]
	--		,[segundoApellido]
	--		,[email]
	--		,[avatar]
	--		,[EstatusId]
	--		,CASE u.EstatusId WHEN 1 THEN 'Activo' WHEN 2 THEN 'Inactivo' ELSE 'Eliminado' END 'estatusId'
	--		,UR.*
	--FROM	[Seguridad].[catalogo].[Usuario] U
	--		JOIN [Seguridad].[relacion].[UsuarioRol] UR ON U.id = UR.usuarioId
	--WHERE	
	--		U.UID IS NOT NULL
	--		AND estatusId != 3
	--		AND UR.aplicacionId = 6
	--		AND rolId IN (21)
END
go

