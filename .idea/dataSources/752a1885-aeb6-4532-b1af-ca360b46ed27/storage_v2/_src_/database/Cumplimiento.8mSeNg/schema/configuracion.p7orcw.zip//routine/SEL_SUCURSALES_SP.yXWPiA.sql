-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-05
-- Description:	Devuelve listas de las empresas y sucursales configuradas en la aplicación
-- [configuracion].[SEL_SUCURSALES_SP]
-- =============================================
CREATE PROCEDURE [configuracion].[SEL_SUCURSALES_SP]
	@idUsuario INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET LANGUAGE Español;

	SET @err = '';
	SELECT 
		[tipo], 
		[idEmpresa], 
		[idSucursal], 
		[nombreEmpresa],
		[userResponsable] = null,
		[userValidador]
	FROM (
		SELECT 
			[tipo] = 1, 
			[idEmpresa] = SUC.idEmpresa, 
			[idSucursal] = 0, 
			[nombreEmpresa] = MAX(C_EMP.emp_nombre),
			[userResponsable] = '',
			[userValidador] = ''
		FROM configuracion.Sucursal SUC
		JOIN temp.cat_empresas C_EMP ON C_EMP.emp_idempresa = SUC.idEmpresa
		GROUP BY SUC.idEmpresa
		UNION ALL
		SELECT
			[tipo] = 2, 
			[idEmpresa] = SUC.idEmpresa, 
			[idSucursal] = SUC.idSucursal, 
			[nombreEmpresa] = C_SUC.suc_nombre,
			[userResponsable] = '',
			[userValidador] = ''
		FROM configuracion.Sucursal SUC
		JOIN TEMP.cat_sucursales C_SUC ON C_SUC.suc_idsucursal = SUC.idSucursal
	) A
	WHERE tipo = 1
	ORDER BY [idEmpresa],[tipo]
END
go

