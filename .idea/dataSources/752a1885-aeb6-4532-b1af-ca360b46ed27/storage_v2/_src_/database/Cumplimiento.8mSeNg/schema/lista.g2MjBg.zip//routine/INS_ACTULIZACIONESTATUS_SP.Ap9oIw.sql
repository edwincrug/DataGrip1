-- =============================================
-- Author: Fernando Tamanis
-- Create date: 16-11-2020
-- Description: Inserta y Actualiza las tablas EstatusEntregaReporteHistorico y ReporteArchivo
-- EXEC [lista].[INS_ACTULIZACIONESTATUS_SP]
-- =============================================

CREATE PROCEDURE [lista].[INS_ACTULIZACIONESTATUS_SP]
	@idUsuario	INT,
	@idEntregaReporte BIGINT,
	@err	VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @idNuevoEstatus BIGINT;

		UPDATE [entrega].[EstatusEntregaReporteHistorico]
		SET esActivo = 0
		WHERE idEntregaReporte = @idEntregaReporte;

		INSERT INTO [entrega].[EstatusEntregaReporteHistorico]
		SELECT 
			[idEstatusEntregaReporte] = 2,
		    [fechaRegistro] = GETDATE(),
			[idUsuario] = @idUsuario,
			[idEntregaReporte] = @idEntregaReporte,
			[esActivo] = 1
		SET @idNuevoEstatus = @@IDENTITY

		UPDATE [entrega].[ReporteArchivo]
		SET idEstatusEntregaReporteHistorico = @idNuevoEstatus
		WHERE idEntregaReporte = @idEntregaReporte AND idEstatusEntregaReporteHistorico IS NULL

	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

