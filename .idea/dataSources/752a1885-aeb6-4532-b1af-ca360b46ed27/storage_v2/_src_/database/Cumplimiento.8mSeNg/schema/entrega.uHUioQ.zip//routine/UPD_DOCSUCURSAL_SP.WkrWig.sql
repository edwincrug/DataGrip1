-- =============================================
-- Author: Alejandro Grijalva Antonio
-- Create date: 23-11-2020
-- Description: Deshabilita un documento
-- =============================================

CREATE PROCEDURE [entrega].[UPD_DOCSUCURSAL_SP]
	@idDocumento BIGINT,
	@idUsuario	INT,
	@err	VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @idReporteArchivo INT

		UPDATE 
			[entrega].[ReporteArchivo]
		SET 
			esActivo = 0
		WHERE
			[idDocumento] = @idDocumento
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

