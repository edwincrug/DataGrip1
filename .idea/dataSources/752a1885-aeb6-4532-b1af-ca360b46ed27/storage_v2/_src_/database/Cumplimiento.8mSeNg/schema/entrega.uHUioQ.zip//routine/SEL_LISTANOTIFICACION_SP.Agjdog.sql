
-- =============================================
-- Author: Fernando Tamanis Pérez
-- Create date: 24-11-2020
-- Description: Devuelve la lista de notificaciones
-- EXEC [entrega].[SEL_LISTANOTIFICACION_SP] 29, ''
-- =============================================
CREATE PROCEDURE [entrega].[SEL_LISTANOTIFICACION_SP]
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS
BEGIN
	DECLARE @tblRol table( rol INT );
	DECLARE @rol INT;
	DECLARE @tipo INT = 0;

	INSERT INTO @tblRol
	EXEC [configuracion].[SEL_ROLUSUARIO_SP] @idUsuario

	SET @rol = (SELECT rol FROM @tblRol )

	IF( @rol = 19 )
		BEGIN
			SET @tipo = 2		
		END
	

	SELECT 
		idNotificacion,
		icono,
		nombreTipo,
		mensaje,
		fecha,
		esActivo,
		idReferencia,
		idTipoNotificacion,
		idSucursal
	INTO #tmpNotificacion
	FROM 
	(
	SELECT 
		idNotificacion,
		CCT.icono,
		CCT.nombreTipo,
		mensaje,
		[configuracion].[FORMATOFECHA_FN]( CNN.fechaRegistro ) fecha,
		CNN.fechaRegistro,
		CNN.esActivo,
		idReferencia,
		CNN.idTipoNotificacion,
		SUC.idSucursal
	  FROM Cumplimiento.notificacion.Notificacion CNN
	  JOIN Cumplimiento.catalogo.TipoNotificacion CCT ON CNN.idTipoNotificacion = CCT.idTipoNotificacion
	  JOIN entrega.EstatusEntregaReporteHistorico HIS ON HIS.idEstatusEntregaReporteHistorico = CNN.idReferencia
	  JOIN catalogo.EstatusEntregaReporte CR ON CR.idEstatusEntregaReporte = HIS.idEstatusEntregaReporte
	  JOIN entrega.EntregaReporte ER ON ER.idEntregaReporte = HIS.idEntregaReporte
	  JOIN lista.ListaCumplimientoSucursalUsuario SUC ON SUC.idListaCumplimientoSucursalUsuario = ER.idListaCumplimientoSucursalUsuario
	  where cct.idTipoNotificacion != 2
		AND CNN.idUsuarioDestinatario = @idUsuario

	  UNION ALL

	  SELECT 
		idNotificacion,
		CR.icono,
		CCT.nombreTipo,
		mensaje,
		[configuracion].[FORMATOFECHA_FN]( CNN.fechaRegistro ) fecha,
		CNN.fechaRegistro,
		CNN.esActivo,
		idReferencia,
		CNN.idTipoNotificacion,
		SUC.idSucursal
	  FROM Cumplimiento.notificacion.Notificacion CNN
	  JOIN Cumplimiento.catalogo.TipoNotificacion CCT ON CNN.idTipoNotificacion = CCT.idTipoNotificacion
	  JOIN entrega.EstatusEntregaReporteHistorico HIS ON HIS.idEstatusEntregaReporteHistorico = CNN.idReferencia
	  JOIN catalogo.EstatusEntregaReporte CR ON CR.idEstatusEntregaReporte = HIS.idEstatusEntregaReporte
	  JOIN entrega.EntregaReporte ER ON ER.idEntregaReporte = HIS.idEntregaReporte
	  JOIN lista.ListaCumplimientoSucursalUsuario SUC ON SUC.idListaCumplimientoSucursalUsuario = ER.idListaCumplimientoSucursalUsuario
	  where cct.idTipoNotificacion = 2
		AND CNN.idUsuarioDestinatario = @idUsuario
		AND CNN.idTipoNotificacion != @tipo
	  ) A
	  ORDER BY fechaRegistro DESC



	  


	  SELECT * 
	  FROM #tmpNotificacion

	  SELECT 
		COUNT(esActivo) esActivo
	  FROM
		#tmpNotificacion
	  WHERE 
		esActivo = 1

	  DROP TABLE #tmpNotificacion;
 -- SELECT 
	--idNotificacion,
	--CCT.icono,
	--CCT.nombreTipo,
	--mensaje,
	--[configuracion].[FORMATOFECHA_FN]( fechaRegistro ) fechaRegistro
 -- FROM Cumplimiento.notificacion.Notificacion CNN
 -- JOIN Cumplimiento.catalogo.TipoNotificacion CCT ON CNN.idTipoNotificacion = CCT.idTipoNotificacion
 -- where cct.idTipoNotificacion != 2
 -- order by fechaRegistro desc
END
go

