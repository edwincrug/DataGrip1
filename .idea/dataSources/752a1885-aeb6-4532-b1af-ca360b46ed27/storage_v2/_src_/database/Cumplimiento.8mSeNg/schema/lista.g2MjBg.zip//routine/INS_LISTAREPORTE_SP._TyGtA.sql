-- =============================================
-- Author: Alejandro Grijalva Antonio
-- Create date: 13-11-2020
-- Description: Registra cada reporte asignado a la lista
-- exec [lista].[INS_LISTAREPORTE_SP] 6, 1, 31, ''
-- =============================================

CREATE PROCEDURE [lista].[INS_LISTAREPORTE_SP]
	@idListaCumplimiento INT,
	@idReporte NUMERIC(18,2),
	@idUsuario		INT,
	@err			VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @AUX INT;
		SET @AUX = ( SELECT idReporte FROM catalogo.Reporte WHERE claveReporte = @idReporte);
		INSERT INTO [lista].[ListaCumplimientoReporte]
		SELECT
			[idListaCumplimiento] = @idListaCumplimiento,
			[idReporte] = @AUX,
			[fechaRegistro] = GETDATE(),
			[estatus] = 1

		SELECT 1 success;
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

