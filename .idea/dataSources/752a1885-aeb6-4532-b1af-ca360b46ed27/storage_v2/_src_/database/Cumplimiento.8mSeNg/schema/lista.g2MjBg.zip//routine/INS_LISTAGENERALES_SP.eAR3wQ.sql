-- =============================================
-- Author: Alejandro Grijalva Antonio
-- Create date: 13-11-2020
-- Description: Inserta generales del checklist
-- EXEC [lista].[INS_LISTAGENERALES_SP] 'Ejemplo', 'Ejemplo 2', 1,'1,2,3,4,5','1,24,13','2020-11-13', '10:56', 31, ''
-- =============================================

CREATE PROCEDURE [lista].[INS_LISTAGENERALES_SP]
	@nombreLista VARCHAR(250),
	@descripcionLista VARCHAR(250),
	@idTipoEntrega INT,
	@diasSemana VARCHAR(20),
	@diasMes VARCHAR(100),
	@fechaEntrega VARCHAR(20),
	@horaEntrega VARCHAR(5),
	@idUsuario	INT,
	@err	VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @idListaCumplimiento INT;
		DECLARE @idProgramacionEntrega INT;
		DECLARE @idEntrega INT;

		SET @idTipoEntrega = @idTipoEntrega + 1;

		INSERT INTO [lista].[ListaCumplimiento]
		SELECT
			[nombreLista]		= @nombreLista,
			[descripcionLista]	= @descripcionLista,
			[idUsuario]			= @idUsuario,
			[fechaRegistro]		= GETDATE(),
			[idTipoEntrega]		= @idTipoEntrega,
			[aplicaValidador]	= 0

		SET @idListaCumplimiento = @@IDENTITY;

		INSERT INTO [lista].[ProgramacionEntrega]
		SELECT 
			[idTipoEntrega] = @idTipoEntrega,
		    [fechaRegistro] = GETDATE(),
			[idUsuario] = @idUsuario,
			[diasSemana] = @diasSemana,
			[diasMes] = @diasMes,
			[fechaEntrega] = ISNULL(CONVERT(DATE,@fechaEntrega, 111), NULL),
			[horaEntrega] = ISNULL(CONVERT(TIME,(@horaEntrega + ':00')), NULL),
			[esActivo] = 1,
			[idListaCumplimiento] = @idListaCumplimiento
		SET @idProgramacionEntrega = @@IDENTITY;


		INSERT INTO [lista].[EstatusListaHistorial]
		SELECT
			[idListaCumplimiento] = @idListaCumplimiento,
			[idEstatusLista] = 3,
			[fechaRegistro] = GETDATE(),
			[idUsuario] = @idUsuario,
			[observaciones] = '',
			[esActivo] = 1

		--IF( @idTipoEntrega = 1 )
		--BEGIN
		--	INSERT INTO [entrega].[Entrega]
		--	SELECT 
		--		[fechaEntrega] = CONVERT(DATE,@fechaEntrega, 111),
		--		[idListaCumplimiento] = @idListaCumplimiento,
		--		[fechaCreacion] = GETDATE(),
		--		[idProgramacionEntrega] = @idProgramacionEntrega
		--	SET @idEntrega = @@IDENTITY;

		--	INSERT INTO [entrega].[EstatusEntregaHistorico]
		--	SELECT 
		--		[idEntrega] = @idEntrega,
		--		[idEstatusEntrega] = 1,
		--		[fechaRegistro] = GETDATE(),
		--		[idUsuario] = @idUsuario,
		--		[esActivo] = 1
		--END

		SELECT @idListaCumplimiento idListaCumplimiento;
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

