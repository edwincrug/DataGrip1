CREATE VIEW [entrega].[VW_REPORTEAVANCE] AS
SELECT
	E.idEntrega,
	R.claveReporte clave,
	R.idReporte,
	LR.idListaCumplimientoReporte,
	[avance] = [entrega].[OBTIENEAVANCE_FN]( LR.idListaCumplimientoReporte )
FROM lista.ListaCumplimientoReporte LR
JOIN catalogo.Reporte R ON LR.idReporte = R.idReporte
JOIN entrega.Entrega E ON E.idListaCumplimiento = LR.idListaCumplimiento
JOIN catalogo.Area A ON A.idArea = R.idArea
JOIN catalogo.Responsable RES ON RES.idResponsable = R.idResponsable
go

