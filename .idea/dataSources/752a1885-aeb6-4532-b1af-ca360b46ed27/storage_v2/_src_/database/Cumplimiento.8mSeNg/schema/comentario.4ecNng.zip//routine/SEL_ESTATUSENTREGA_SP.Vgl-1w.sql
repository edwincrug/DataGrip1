-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-19
-- Description:	Devuelve listas de los estatus de una entrega
-- [comentario].[SEL_ESTATUSENTREGA_SP] 9, 0, 29, ''
-- =============================================
CREATE PROCEDURE [comentario].[SEL_ESTATUSENTREGA_SP]
	@IdEntregaReporte INT,
	@aplica INT,
	@idUsuario INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET LANGUAGE Español;

	SET @err = '';
	
	SELECT 
		HIS.idEstatusEntregaReporteHistorico,
		HIS.idEstatusEntregaReporte,
		HIS.fechaRegistro,
		HIS.esActivo,
		HIS.idEntregaReporte,
		EST.nombreEstatusEntregaReporte,
		EST.descripcion,
		EST.rgb,
		EST.img
	FROM [entrega].[EstatusEntregaReporteHistorico] HIS
	JOIN [catalogo].[EstatusEntregaReporte] EST ON EST.idEstatusEntregaReporte = HIS.idEstatusEntregaReporte
	WHERE HIS.IdEntregaReporte = @IdEntregaReporte
		--AND HIS.idEstatusEntregaReporte > 1
	ORDER BY HIS.idEstatusEntregaReporteHistorico DESC

	SELECT 
		HIS.idEstatusEntregaReporteHistorico,
		HIS.idEstatusEntregaReporte,
		HIS.fechaRegistro,
		HIS.esActivo,
		HIS.idEntregaReporte,
		EST.nombreEstatusEntregaReporte,
		EST.descripcion,
		EST.rgb,
		EST.img
	FROM [entrega].[EstatusEntregaReporteHistorico] HIS
	JOIN [catalogo].[EstatusEntregaReporte] EST ON EST.idEstatusEntregaReporte = HIS.idEstatusEntregaReporte
	WHERE HIS.IdEntregaReporte = @IdEntregaReporte
		AND HIS.esActivo = 1
	ORDER BY HIS.idEstatusEntregaReporteHistorico DESC

	IF( @aplica = 1 )
		BEGIN
			UPDATE 
				[entrega].[EstatusEntregaReporteHistorico]
			SET 
				visto = 1
			WHERE 
				idEntregaReporte = @IdEntregaReporte
		END
	
END
go

