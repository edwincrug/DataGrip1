-- =============================================
-- Author: Alejandro Grijalva Antonio
-- Create date: 24-11-2020
-- Description: Devuelve el detalle para poder entrar al detalle de una entrega

-- =============================================

CREATE PROCEDURE [entrega].[SEL_RECIBIDOSDETALLE_SP]
	@idEstatusEntregaReporteHistorico int,
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS
BEGIN
	--DECLARE @idEstatusEntregaReporteHistorico INT = 360

	DECLARE @idEntrega INT = 0,
			@idReporte INT = 0;

	SELECT
		@idEntrega = ER.idEntrega,
		@idReporte = R.idReporte
	FROM [entrega].[EstatusEntregaReporteHistorico] HIS
	JOIN [entrega].[EntregaReporte] ER ON HIS.idEntregaReporte = ER.idEntregaReporte
	JOIN [lista].[ListaCumplimientoReporte] LR ON LR.idListaCumplimientoReporte = ER.idListaCumplimientoReporte
	JOIN [catalogo].[Reporte] R ON R.idReporte = LR.idReporte
	JOIN [lista].[ListaCumplimiento] L ON L.idListaCumplimiento = LR.idListaCumplimiento
	JOIN [lista].[ListaCumplimientoSucursalUsuario] LS ON ER.idListaCumplimientoSucursalUsuario = LS.idListaCumplimientoSucursalUsuario
	JOIN [ControlAplicaciones].[dbo].[cat_sucursales] S ON LS.idSucursal = S.suc_idsucursal
	JOIN [ControlAplicaciones].[dbo].[cat_empresas] E ON S.emp_idempresa = E.emp_idempresa
	WHERE
		HIS.idEstatusEntregaReporteHistorico = @idEstatusEntregaReporteHistorico

	SELECT 
		[nombreLista] = LC.nombreLista,
		[tipoEntrega] = TE.nombreTipoEntrega,
		[idEntrega] = E.idEntrega, 
		[fechaEntrega] = CONVERT(varchar,E.fechaEntrega,100),
		[avance] = 0,
		[color] = 'danger'
	FROM entrega.Entrega E
	JOIN entrega.EstatusEntregaHistorico HIS ON E.idEntrega = HIS.idEntrega
	JOIN lista.ListaCumplimiento LC ON LC.idListaCumplimiento = E.idListaCumplimiento
	JOIN catalogo.TipoEntrega TE ON TE.idTipoEntrega = LC.idTipoEntrega
	WHERE 
		E.idEntrega = @idEntrega
	ORDER BY E.fechaEntrega DESC


	SELECT
		R.claveReporte clave,
		R.idReporte,
		R.nombreReporte,
		A.nombreArea area,
		res.nombreResponsable responsable,
		[avance] = 0,
		[color] = 'danger',
		[rgb] = '#dc3545',
		LR.idListaCumplimientoReporte
	FROM lista.ListaCumplimientoReporte LR
	JOIN catalogo.Reporte R ON LR.idReporte = R.idReporte
	JOIN entrega.Entrega E ON E.idListaCumplimiento = LR.idListaCumplimiento
	JOIN catalogo.Area A ON A.idArea = R.idArea
	JOIN catalogo.Responsable RES ON RES.idResponsable = R.idResponsable
	WHERE 
		E.idEntrega = @idEntrega
		AND R.idReporte = @idReporte
	ORDER BY R.claveReporte
END
go

