-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-16
-- Description:	Devuelve listas de reportes por entrega
-- [lista].[SEL_LISTAREPORTEADMIN_SP] 
-- =============================================
CREATE PROCEDURE [lista].[SEL_LISTAREPORTEADMIN_SP]
	@idEntrega INT,
	@idUsuario INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET LANGUAGE Español;

	SET @err = '';
	SELECT
		R.claveReporte clave,
		R.idReporte,
		R.nombreReporte,
		A.nombreArea area,
		res.nombreResponsable responsable,
		[avance] = [entrega].[OBTIENEAVANCE_FN]( LR.idListaCumplimientoReporte ),
		[color] = 'danger',
		[rgb] = '#dc3545',
		LR.idListaCumplimientoReporte
	FROM lista.ListaCumplimientoReporte LR
	JOIN catalogo.Reporte R ON LR.idReporte = R.idReporte
	JOIN entrega.Entrega E ON E.idListaCumplimiento = LR.idListaCumplimiento
	JOIN catalogo.Area A ON A.idArea = R.idArea
	JOIN catalogo.Responsable RES ON RES.idResponsable = R.idResponsable
	WHERE 
		E.idEntrega = @idEntrega
	ORDER BY R.claveReporte
END
go

