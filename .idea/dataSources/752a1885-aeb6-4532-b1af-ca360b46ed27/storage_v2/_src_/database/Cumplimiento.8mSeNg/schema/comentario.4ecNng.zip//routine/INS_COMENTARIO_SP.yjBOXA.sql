-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-20
-- Description:	Inserta un comentario de una reporte
-- 
-- =============================================
CREATE PROCEDURE [comentario].[INS_COMENTARIO_SP]
	@mensaje VARCHAR(700),
	@IdEntregaReporte BIGINT,
	@idEstatusEntregaReporteHistorico BIGINT,
	@idUsuario INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	BEGIN TRY
		INSERT INTO [comentario].[Comentario]
		SELECT 
			[mensaje] = @mensaje,
			[idUsuario] = @idUsuario,
			[idDocumentos] = NULL,
			[IdEntregaReporte] = @IdEntregaReporte,
			[idEstatusEntregaReporteHistorico] = @idEstatusEntregaReporteHistorico,
			[fechaRegistro] = GETDATE(),
			[titulo] = NULL

		

		INSERT INTO [notificacion].[Notificacion]
		SELECT
			[idTipoNotificacion] = 3
			,[idUsuarioEmisor] =  @idUsuario
			,[idUsuarioDestinatario] = CASE WHEN @idUsuario = 29 THEN 31 ELSE 29 END
			,[mensaje] = CONVERT(VARCHAR(500), @mensaje)
			,[fechaRegistro] = GETDATE()
			,[idReferencia] = @idEstatusEntregaReporteHistorico
			,[esActivo] = 1

		SELECT 1 success;
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

