-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-19
-- Description:	Regresa la fecha customizada al usuario final
-- =============================================
CREATE FUNCTION [configuracion].[FORMATOFECHA_FN]
(
	@Fecha VARCHAR(30)
)
RETURNS VARCHAR(10)
AS
	BEGIN
		DECLARE @Minutos INT = 0;
		DECLARE @Horas INT = 0;
		DECLARE @Dia INT = 0;
		DECLARE @Mes VARCHAR(3);
		DECLARE @Tiempo VARCHAR(50);

		SET @Minutos = DATEDIFF(mi, @Fecha, GETDATE());

		IF (@Minutos < 59)
			BEGIN
				SET @Tiempo = CONVERT(VARCHAR(2), @Minutos ) + ' min' 
			END
		ELSE IF( @Minutos > 60 )
			BEGIN
				SET @Horas = (@Minutos / 60);
				IF( @Horas < 24 )
					BEGIN
						SET @Tiempo = CONVERT(VARCHAR(2), @Horas ) + CASE WHEN @Horas = 1 THEN ' hora' ELSE ' horas' END
					END
				ELSE
					BEGIN
						SET @Dia = @Horas / 24;
						IF( @Dia < 15 )
							BEGIN
								SET @Tiempo = CONVERT(VARCHAR(2), @Dia ) + CASE WHEN @Dia = 1 THEN ' día' ELSE ' días' END
							END
						ELSE
							BEGIN
								IF( YEAR( @Fecha ) = YEAR(GETDATE()) )
									BEGIN
										--SET LANGUAGE 'spanish'
										SET @Mes = DATENAME(MONTH,@Fecha)
										SET @Tiempo = CONVERT( VARCHAR(2), DAY( @Fecha ) ) + ' ' + LOWER( @Mes );
									END
								ELSE
									BEGIN
										SET @Tiempo = CONVERT( VARCHAR(10), @Fecha, 131 );
									END
							END
					END
			END

		RETURN @Tiempo

	END
go

