-- =============================================
-- Author: Alejandro Grijalva Antonio
-- Create date: 23-11-2020
-- Description: Inserta las nuevas entregas programadas
--
-- =============================================

CREATE PROCEDURE [entrega].[INS_GENERAENTREGAS_SP]
	@idListaCumplimiento INT,
	@idUsuario	INT,
	@err	VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE 
			@fechaEntrega VARCHAR(10),
			@idProgramacionEntrega INT,
			@idEntrega INT,
			@idTipoEntrega INT,
			@Result INT -- 0 No agregado, 1 Agregado


		SELECT
			@fechaEntrega = fechaEntrega,
			@idProgramacionEntrega = idProgramacionEntrega ,
			@idTipoEntrega = LC.idTipoEntrega
		FROM lista.ListaCumplimiento LC
		JOIN [lista].[ProgramacionEntrega] PE ON LC.idListaCumplimiento = PE.idListaCumplimiento
		WHERE LC.idListaCumplimiento = @idListaCumplimiento


		IF( @idTipoEntrega = 1 )
			BEGIN
				-- Control de entrega Única
				IF EXISTS( SELECT * FROM entrega.Entrega WHERE idListaCumplimiento = @idListaCumplimiento ) 
					BEGIN
						SET @Result = 0;
					END
				ELSE
					BEGIN
						INSERT INTO [entrega].[Entrega]
						SELECT 
							[fechaEntrega] = CONVERT(DATE,@fechaEntrega, 111),
							[idListaCumplimiento] = @idListaCumplimiento,
							[fechaCreacion] = GETDATE(),
							[idProgramacionEntrega] = @idProgramacionEntrega
						SET @idEntrega = @@IDENTITY;

						INSERT INTO [entrega].[EstatusEntregaHistorico]
						SELECT 
							[idEntrega] = @idEntrega,
							[idEstatusEntrega] = 1,
							[fechaRegistro] = GETDATE(),
							[idUsuario] = @idUsuario,
							[esActivo] = 1

						INSERT INTO [entrega].[EntregaReporte]
						SELECT
							[idEntrega] =EN.idEntrega
							,[idListaCumplimientoSucursalUsuario] = USU.idListaCumplimientoSucursalUsuario
							,[idUsuario] = @idUsuario
							,[idListaCumplimientoReporte] = REP.idListaCumplimientoReporte
						FROM entrega.Entrega EN
						JOIN lista.ListaCumplimientoSucursalUsuario USU ON EN.idListaCumplimiento = USU.idListaCumplimiento
						JOIN lista.ListaCumplimientoReporte REP ON REP.idListaCumplimiento = EN.idListaCumplimiento
						WHERE EN.idListaCumplimiento = @idListaCumplimiento
						ORDER BY REP.idListaCumplimientoReporte, USU.idSucursal

						INSERT INTO [entrega].[EstatusEntregaReporteHistorico]
						SELECT
							[idEstatusEntregaReporte] = 1
							,[fechaRegistro] = GETDATE()
							,[idUsuario] = @idUsuario
							,[idEntregaReporte] = EREP.idEntregaReporte
							,[esActivo] = 1
							,visto = 1
						FROM entrega.Entrega EN
						JOIN lista.ListaCumplimientoSucursalUsuario USU ON EN.idListaCumplimiento = USU.idListaCumplimiento
						JOIN lista.ListaCumplimientoReporte REP ON REP.idListaCumplimiento = EN.idListaCumplimiento
						JOIN [entrega].[EntregaReporte] EREP ON EREP.idListaCumplimientoSucursalUsuario = USU.idListaCumplimientoSucursalUsuario AND EREP.idListaCumplimientoReporte = REP.idListaCumplimientoReporte
						WHERE EN.idListaCumplimiento = @idListaCumplimiento
						ORDER BY REP.idListaCumplimientoReporte, USU.idSucursal

						SET @Result = 1;
					END
			END

		SELECT @Result Result
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

