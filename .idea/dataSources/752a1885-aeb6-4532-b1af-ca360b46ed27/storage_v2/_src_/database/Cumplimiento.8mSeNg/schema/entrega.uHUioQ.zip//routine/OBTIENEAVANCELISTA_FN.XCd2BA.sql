-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 29 Nov, 2020
-- Description:	Obtiene avance por entregaReporte
-- =============================================
CREATE FUNCTION [entrega].[OBTIENEAVANCELISTA_FN]
(
	-- Add the parameters for the function here
	@idEntrega INT
)
RETURNS INT
AS
BEGIN
	DECLARE @Porcentaje NUMERIC(18,2)

	SELECT
		@Porcentaje = SUM(avance) / COUNT(avance)
	FROM 
	[entrega].[VW_REPORTEAVANCE]
	WHERE idEntrega = @idEntrega


	RETURN @Porcentaje

END
go

