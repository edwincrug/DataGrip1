-- =============================================
-- Author: Fernando Tamanis Pérez
-- Create date: 16-11-2020
-- Description: Inserta idDocumento obtenido de FileServer
-- EXEC [lista].[INS_DOCSUCURSAL_SP]
-- =============================================

CREATE PROCEDURE [lista].[INS_DOCSUCURSAL_SP]
	@idEntregaReporte BIGINT,
	@fechaRegistro DATETIME,
	@idDocumento BIGINT,
	@idUsuario	INT,
	@idEstatusEntregaReporteHistorico BIGINT,
	@err	VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @idReporteArchivo INT

		INSERT INTO [entrega].[ReporteArchivo]
		SELECT
			[idEntregaReporte]					= @idEntregaReporte,
			[fechaRegistro]						= CONVERT(DATE,@fechaRegistro),
			[idDocumento]						= @idDocumento,
			[idUsuario]							= @idUsuario,
			[idEstatusEntregaReporteHistorico]	= NULL,
			1
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

