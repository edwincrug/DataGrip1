-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 2020-11-16
-- Description:	Inserta los responsables de los reportes
-- 
-- =============================================
CREATE PROCEDURE [lista].[INS_LISTARESPONSABLE_SP]
	@idListaCumplimiento	INT,
	@idEmpresa				INT,
	@idResponsable			INT,
	@idUsuario				INT,
	@err					varchar(max) OUTPUT
AS
BEGIN
	BEGIN TRY
		INSERT INTO [lista].[ListaCumplimientoSucursalUsuario]
		SELECT 
			[idListaCumplimiento] = @idListaCumplimiento,
			[idSucursal],
			[idUsuario] = @idResponsable,
			[idTipoIntervencion] = 1,
			[fechaRegistro] = GETDATE(),
			[estatus] = 1
		FROM configuracion.Sucursal 
		WHERE idEmpresa = @idEmpresa

		SELECT 1 success;
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

