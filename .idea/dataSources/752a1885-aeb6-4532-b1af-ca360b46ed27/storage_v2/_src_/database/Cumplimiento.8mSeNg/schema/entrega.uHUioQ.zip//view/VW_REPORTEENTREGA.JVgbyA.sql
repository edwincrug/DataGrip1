CREATE VIEW [entrega].[VW_REPORTEENTREGA] AS
SELECT
	E.idEntrega,
	R.claveReporte clave,
	R.idReporte,
	R.nombreReporte,
	A.nombreArea area,
	res.nombreResponsable responsable,
	[avance] = [entrega].[OBTIENEAVANCE_FN]( LR.idListaCumplimientoReporte ),
	[color] = 'danger',
	[rgb] = '#dc3545',
	LR.idListaCumplimientoReporte
FROM lista.ListaCumplimientoReporte LR
JOIN catalogo.Reporte R ON LR.idReporte = R.idReporte
JOIN entrega.Entrega E ON E.idListaCumplimiento = LR.idListaCumplimiento
JOIN catalogo.Area A ON A.idArea = R.idArea
JOIN catalogo.Responsable RES ON RES.idResponsable = R.idResponsable
WHERE 
	E.idEntrega = 37
go

