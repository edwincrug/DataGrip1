-- =============================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 29 Nov, 2020
-- Description:	Obtiene avance por entregaReporte
-- =============================================
CREATE FUNCTION [entrega].[OBTIENEAVANCE_FN]
(
	-- Add the parameters for the function here
	@idListaCumplimientoReporte INT
)
RETURNS INT
AS
BEGIN
	DECLARE @Porcentaje NUMERIC(18,2)

	SELECT @Porcentaje = SUM( CER.ponderacion ) / COUNT( CER.ponderacion )
	FROM entrega.EntregaReporte ER
	JOIN entrega.EstatusEntregaReporteHistorico ERH ON ER.idEntregaReporte = ERH.idEntregaReporte AND ERH.esActivo = 1
	JOIN catalogo.EstatusEntregaReporte CER ON CER.idEstatusEntregaReporte = ERH.idEstatusEntregaReporte
	JOIN lista.ListaCumplimientoReporte CR ON CR.idListaCumplimientoReporte = ER.idListaCumplimientoReporte
	JOIN lista.ListaCumplimientoSucursalUsuario SUC ON SUC.idListaCumplimientoSucursalUsuario = ER.idListaCumplimientoSucursalUsuario
	JOIN configuracion.Sucursal S ON S.idSucursal = SUC.idSucursal
	JOIN temp.cat_sucursales CS ON CS.suc_idsucursal = S.idSucursal
	JOIN temp.cat_empresas EMP ON EMP.emp_idempresa = CS.emp_idempresa
	WHERE
		CR.idListaCumplimientoReporte = @idListaCumplimientoReporte

	RETURN @Porcentaje

END
go

