

-- =============================================
-- Author: Fernando Tamanis Pérez
-- Create date: 29-10-2020
-- Description: Devuelve la lista de reportes de una lista en especifico, recibe como parametro idListaCumplimiento
--				[lista].[SEL_LISTAPENDIENTEREPORTE_SP]
-- =============================================

CREATE PROCEDURE [lista].[SEL_LISTAPENDIENTEREPORTE_SP]
	@idListaCumplimiento	int,
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS
BEGIN

	SELECT DISTINCT LCR.idReporte, LCR.idListaCumplimientoReporte, R.claveReporte, A.nombreArea, RE.nombreResponsable, R.nombreReporte, [estatus] = 'Pendiente'
	FROM lista.ListaCumplimientoReporte LCR
	JOIN catalogo.Reporte R ON LCR.idReporte = R.idReporte
	JOIN catalogo.Area A ON R.idArea = A.idArea
	JOIN catalogo.Responsable RE ON R.idResponsable = RE.idResponsable
	WHERE LCR.idListaCumplimiento = @idListaCumplimiento
	ORDER BY R.claveReporte ASC;
END

go

