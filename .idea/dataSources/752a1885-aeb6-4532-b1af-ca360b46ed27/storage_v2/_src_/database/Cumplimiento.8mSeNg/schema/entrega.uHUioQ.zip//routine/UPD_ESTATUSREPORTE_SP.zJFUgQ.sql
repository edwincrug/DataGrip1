-- =============================================
-- Author: Alejandro Grijalva
-- Create date: 18-11-2020
-- Description: Actualiza el estatus de cada reporte
-- 
-- =============================================

CREATE PROCEDURE [entrega].[UPD_ESTATUSREPORTE_SP]
	@idEstatus INT,
	@idEntregaReporte BIGINT,
	@idUsuario	INT,
	@err	VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @idNuevoEstatus BIGINT;

		UPDATE [entrega].[EstatusEntregaReporteHistorico]
		SET esActivo = 0
		WHERE idEntregaReporte = @idEntregaReporte;

		INSERT INTO [entrega].[EstatusEntregaReporteHistorico]
		SELECT
			[idEstatusEntregaReporte] = @idEstatus,
		    [fechaRegistro] = GETDATE(),
			[idUsuario] = @idUsuario,
			[idEntregaReporte] = @idEntregaReporte,
			[esActivo] = 1,
			visto = CASE WHEN @idEstatus = 2 THEN 0 ELSE 1 END;
		SET @idNuevoEstatus = @@IDENTITY

		DECLARE @Estatus VARCHAR(50) = (SELECT [descripcion] FROM [catalogo].[EstatusEntregaReporte] WHERE idEstatusEntregaReporte = @idEstatus)

		IF( @idEstatus = 2 )
			BEGIN
				UPDATE [entrega].[ReporteArchivo]
				SET idEstatusEntregaReporteHistorico = @idNuevoEstatus
				WHERE idEntregaReporte = @idEntregaReporte AND idEstatusEntregaReporteHistorico IS NULL

				INSERT INTO [notificacion].[Notificacion]
				SELECT
					[idTipoNotificacion] = 2
					,[idUsuarioEmisor] = 31
					,[idUsuarioDestinatario] = 29
					,[mensaje] = 'El reporte ha sido cambiado a ' + @Estatus
					,[fechaRegistro] = GETDATE()
					,[idReferencia] = @idNuevoEstatus
					,[esActivo] = 1
			END
		ELSE
			BEGIN
				INSERT INTO [notificacion].[Notificacion]
				SELECT
					[idTipoNotificacion] = 2
					,[idUsuarioEmisor] = 29
					,[idUsuarioDestinatario] = 31
					,[mensaje] = 'El reporte ha sido cambiado a ' + @Estatus
					,[fechaRegistro] = GETDATE()
					,[idReferencia] = @idNuevoEstatus
					,[esActivo] = 1
			END

		SELECT @idNuevoEstatus idEstatusEntregaReporteHistorico
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

