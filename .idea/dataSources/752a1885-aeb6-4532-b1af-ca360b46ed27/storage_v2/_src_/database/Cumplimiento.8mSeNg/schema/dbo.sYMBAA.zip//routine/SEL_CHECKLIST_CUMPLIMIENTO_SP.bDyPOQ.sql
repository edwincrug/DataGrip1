CREATE PROCEDURE [dbo].[SEL_CHECKLIST_CUMPLIMIENTO_SP]
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS
BEGIN
	SET @err = '';

	SELECT * FROM checklist
END
go

