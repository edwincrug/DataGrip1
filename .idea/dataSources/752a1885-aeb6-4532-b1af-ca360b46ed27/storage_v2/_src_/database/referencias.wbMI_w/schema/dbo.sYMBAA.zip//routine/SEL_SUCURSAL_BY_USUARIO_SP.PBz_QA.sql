CREATE PROCEDURE [dbo].[SEL_SUCURSAL_BY_USUARIO_SP]
@idUsuario INT,
@idEmpresa INT
AS
BEGIN
	-- select @idUsuario as TUsuario, @idEmpresa as TEmpresa;
  select distinct (Sucur.suc_nombre), Sucur.suc_idsucursal from [ControlAplicaciones].[dbo].[ope_organigrama] Orga
  INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] Sucur ON Orga.suc_idsucursal = Sucur.suc_idsucursal
  where Orga.usu_idusuario = @idUsuario and Orga.emp_idempresa = @idEmpresa
 END
go

