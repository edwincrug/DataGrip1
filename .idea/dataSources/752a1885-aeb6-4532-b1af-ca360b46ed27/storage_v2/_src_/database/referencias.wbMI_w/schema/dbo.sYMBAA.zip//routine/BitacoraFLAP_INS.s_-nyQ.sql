-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <11/07/2018>
-- Description:	<Inserta la bitacora en dpi>
-- =============================================
CREATE PROCEDURE [dbo].[BitacoraFLAP_INS]
			@idRegistro INT,
			@idEmpresa INT,
			@idBanco INT,
			@noCuenta nvarchar(50),
			@CONSPOL INT ,
			@noPaso INT,
			@mensaje nvarchar(250),
			@idUsuario INT
AS
BEGIN

INSERT INTO [dbo].[BitacoraFLAP]
           ([idregistro]
           ,[idEmpresa]
           ,[idBanco]
           ,[noCuenta]
           ,[conspol]
           ,[fecha]
           ,[idUsuario]
           ,[noPaso]
           ,[mensaje]
		   ,seatendio)
     VALUES
           (@idregistro
           ,@idEmpresa
           ,@idBanco
           ,@noCuenta
           ,@CONSPOL
		   ,getdate()
           ,@idUsuario
           ,@noPaso
           ,@mensaje
		   ,0)

END

go

