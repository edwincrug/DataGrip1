
-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 29-10-2019
-- Description:	Obtiene toda la informacion de la Transaccion
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_Transaccion]
(
	@idTrans numeric(18,0)
)
AS
BEGIN

BEGIN TRY  --Estar TryCatch
		  
		  DECLARE @AUTORIZACION VARCHAR(50)=NULL
		   --Get codigo autorizacion
		  SELECT  @AUTORIZACION =  [numeroAutorizacion]
		  FROM [referencias].[dbo].[PagoRespuesta]
		  WHERE idTrans=@idTrans;
		  /*
		--print  @AUTORIZACION
		--Get Respuesta 

			SELECT 
				   [idPago] AS 'IdPago'
				  ,[idTrans] AS 'IdTransaccion'
			      ,[referencia] As 'Referencia'
			      ,[nodo] As 'Sucursal'
			      ,[idConcepto] AS 'IdConcepto'
			      ,[moneda] AS 'Moneda'
			      ,[importe] AS 'Importe'
			      ,[idComercio] AS 'IdComercio'
			      ,[accion] AS 'Accion'
				  ,@AUTORIZACION AS 'Autorizacion'
			  FROM [referencias].[dbo].[Pago]
			  WHERE [idOrigen]=1 and [idTrans]=@idTrans;
			  */
			    SELECT 
				   P.idPago AS 'IdPago'
				  ,P.idTrans AS 'IdTransaccion'
			      ,P.referencia As 'Referencia'
			      ,C.mp_node AS 'Sucursal'
			      ,P.idConcepto AS 'IdConcepto'
			      ,P.moneda AS 'Moneda'
			      ,P.importe AS 'Importe'
			      ,P.idComercio AS 'IdComercio'
			      ,P.accion AS 'Accion'
				  ,@autorizacion AS 'Autorizacion'
			  FROM [referencias].[dbo].[Pago] AS P
			  INNER JOIN [referencias].[dbo].[Cat_DivisionOrg_BBVA] AS C ON C.idSucursal=P.nodo
			  WHERE P.idOrigen=1 and P.idTrans=@idTrans;

END TRY  
BEGIN CATCH  
	--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[Pago]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro  

END CATCH; --End TryCatch



	

END
go

