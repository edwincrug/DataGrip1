-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetReference](@DocTypeID int, @Reference varchar(50))
RETURNS varchar(100)
AS
BEGIN

	--catalogo de tipos de documentos 
	--select * from tipodocumento

	declare @result varchar(100)


	-----------------------------factura-----------------------------------------------------------------------------------------------------
		
	if(@DocTypeID = 1 )  
	begin
		return  @Reference
	end


	-----------------------------Cotización-----------------------------------------------------------------------------------------------------

	if(@DocTypeID = 2 )  
	begin
		-----------------------------Unidades Nuevas--------------------------------------
		
		SELECT @result= ucu_foliocotizacion 
		FROM cuentasporcobrar.dbo.uni_cotizacionuniversal 
		WHERE ucu_idempresa = 4 AND 
		ucu_idsucursal = 12 AND 
		ucu_iddepartamento = 67 AND 
		ucu_idcliente = 345 AND  --ucu_idcliente ES IGUAL AL CAMPO idCliente de la tabla referencias
		ucu_idcotizacion = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			)

		
		
		SELECT @result = UPE_IDPEDI 
		FROM GAZM_Zaragoza..UNI_PEDIDO -- DEPENDE DE LA EMPRESA Y SUCURSAL
		WHERE UPE_IDCLIENTE = 345 AND 
		UPE_IDPEDI = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			) 

		

		-----------------------------Unidades Seminuevas--------------------------------------

		SELECT @result = ucu_foliocotizacion 
		FROM cuentasporcobrar.dbo.uni_cotizacionuniversal 
		WHERE ucu_idempresa = 4 AND 
		ucu_idsucursal = 12 AND 
		ucu_iddepartamento = 68 AND
		ucu_idcliente = 345 AND --ucu_idcliente ES IGUAL AL CAMPO idCliente de la tabla referencias
		ucu_idcotizacion = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			)


		SELECT @result = PMS_NUMPEDIDO 
		FROM GAZM_Zaragoza..USN_PEDIDO -- DEPENDE DE LA EMPRESA Y SUCURSAL
		WHERE PMS_IDPERSONA = 345 AND PMS_NUMPEDIDO = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			) 

			
		-----------------------------Refacciones--------------------------------------

		SELECT @Reference= CONVERT(VARCHAR(50),PMM_NUMERO) + '-' + CONVERT(VARCHAR(50),PMM_IDALMA) + '-' + CONVERT(VARCHAR(50),PMM_COTPED)
		FROM GAZM_Zaragoza..PAR_PEDMOST -- DEPENDE DE LA EMPRESA Y SUCURSAL
		WHERE PMM_IDCLIENTE = 345 --PMM_IDCLIENTE ES IGUAL AL CAMPO idCliente de la tabla referencias
		AND PMM_COTPED = 'COTIZACION' 
		AND PMM_IDALMA = 'GEN'    --ESTE CAMPO SALE DE LA TABLA referencia en el campo idAlm ES UN NUEVO CAMPO QUE DEBE INSERTARSE DESDE LA CREACION DE LA REFERENCIA, SOLO SI ES DE REFACCIONES
		AND PMM_NUMERO = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			)

			
			
		return  @result
	end


	-----------------------------Pedido-----------------------------------------------------------------------------------------------------

	if(@DocTypeID = 3 ) 
	begin


		-----------------------------Unidades Nuevas--------------------------------------
		SELECT @result=ucu_foliocotizacion 
		FROM cuentasporcobrar.dbo.uni_cotizacionuniversal 
		WHERE ucu_idempresa = 4 AND 
		ucu_idsucursal = 12 AND 
		ucu_iddepartamento = 67 AND 
		ucu_idcliente = 345 --ucu_idcliente ES IGUAL AL CAMPO idCliente de la tabla referencias
		AND ucu_idcotizacion = 
		(	
			SELECT documento 
			FROM Referencia 
			where referencia = @Reference
		)


		SELECT @result=UPE_IDPEDI 
		FROM GAZM_Zaragoza..UNI_PEDIDO -- DEPENDE DE LA EMPRESA Y SUCURSAL
		WHERE UPE_IDCLIENTE = 345 
		AND UPE_IDPEDI = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			) 
		--UPE_IDCLIENTE ES IGUAL AL CAMPO idCliente de la tabla referencias


		-----------------------------Unidades Seminuevas--------------------------------------

		SELECT @result=ucu_foliocotizacion 
		FROM cuentasporcobrar.dbo.uni_cotizacionuniversal 
		WHERE ucu_idempresa = 4 AND 
		ucu_idsucursal = 12 AND 
		ucu_iddepartamento = 68 
		AND ucu_idcliente = 345 --ucu_idcliente ES IGUAL AL CAMPO idCliente de la tabla referencias
		AND ucu_idcotizacion = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			)


		SELECT @result=PMS_NUMPEDIDO 
		FROM GAZM_Zaragoza..USN_PEDIDO -- DEPENDE DE LA EMPRESA Y SUCURSAL
		WHERE PMS_IDPERSONA = 345 AND 
		PMS_NUMPEDIDO = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			)	

		-----------------------------Refacciones--------------------------------------

		SELECT @result= CONVERT(VARCHAR(50),PMM_NUMERO) + '-' + CONVERT(VARCHAR(50),PMM_IDALMA) + '-' + CONVERT(VARCHAR(50),PMM_COTPED)
		FROM GAZM_Zaragoza..PAR_PEDMOST -- DEPENDE DE LA EMPRESA Y SUCURSAL
		WHERE PMM_IDCLIENTE = 345 --PMM_IDCLIENTE ES IGUAL AL CAMPO idCliente de la tabla referencias
		AND PMM_COTPED = 'PEDIDO' 
		AND PMM_IDALMA = 'GEN'    --ESTE CAMPO SALE DE LA TABLA referencia en el campo idAlm ES UN NUEVO CAMPO QUE DEBE INSERTARSE DESDE LA CREACION DE LA REFERENCIA, SOLO SI ES DE REFACCIONES
		AND PMM_NUMERO = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			)



		return @result
	end


	-----------------------------Presupuesto-----------------------------------------------------------------------------------------------------

	if(@DocTypeID = 4 ) 
	begin
		
		SELECT @result= PRE_IDORDEN 
		FROM GAZM_Zaragoza..SER_PRESUP  --DEPENDE DE LA EMPRESA Y SUCURSAL
		WHERE PRE_IDCLIENTE = 345 AND --PRE_IDCLIENTE ES IGUAL AL CAMPO idCliente de la tabla referencias
		CONVERT(VARCHAR(6),CONVERT(NUMERIC,SUBSTRING(PRE_IDORDEN,2,(LEN(PRE_IDORDEN))))) = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			)

		return @result
	end
	
	-----------------------------Orden de Servicio----------------------------------------------------------------------------------------------
	if(@DocTypeID = 5 ) 
	begin

		SELECT @result= ORE_IDORDEN FROM GAZM_Zaragoza..SER_ORDEN  --DEPENDE DE LA EMPRESA Y SUCURSAL
		WHERE ORE_IDCLIENTE = 345 AND --ORE_IDCLIENTE ES IGUAL AL CAMPO idCliente de la tabla referencia
		SUBSTRING(ORE_IDORDEN,1,1) = 'A' AND  --SUBSTRING(ORE_IDORDEN,1,1) ES IdTipoOrdenSer de la tabla Referencia
		CONVERT(VARCHAR(6),CONVERT(NUMERIC,SUBSTRING(ORE_IDORDEN,2,(LEN(ORE_IDORDEN))))) = 
			(
				SELECT documento 
				FROM Referencia 
				where referencia = @Reference
			)
		
	end


	return ''
	

END

go

