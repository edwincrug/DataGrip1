



-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 03-01-2020
-- Description:	obtiene un parametro mediante su tipo e identificador
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_ParametrosConfiguracion]
(
	@TipoParametro varchar(10),
	@Identificador varchar(50)
)
AS
BEGIN

BEGIN TRY  --Star TryCatch
	SELECT TOP (1) 
	   [pr_IdParametro]
      ,[pr_TipoParametro]
      ,[pr_Identificador]
      ,[pr_Descripcion]
      ,[pr_ValorString1]
      ,[pr_ValorString2]
      ,[pr_ValorString3]
      ,[pr_Valor1]
      ,[pr_Valor2]
      ,[pr_Valor3]
      ,[pr_Empresa]
      ,[pr_Sucursal]
      ,[pr_FechaCreacion]
	FROM [referencias].[dbo].[Parametros]
	 WHERE [pr_TipoParametro]=@TipoParametro AND [pr_Identificador]=@Identificador;

END TRY  
BEGIN CATCH  
    SELECT  
        ERROR_NUMBER() AS ErrorNumber  
        ,ERROR_SEVERITY() AS ErrorSeverity  
        ,ERROR_STATE() AS ErrorState  
        ,ERROR_PROCEDURE() AS ErrorProcedure  
        ,ERROR_LINE() AS ErrorLine  
        ,ERROR_MESSAGE() AS ErrorMessage;  
END CATCH; --End TryCatch



	

END
go

