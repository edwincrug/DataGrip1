-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<crea poliza de la tabla [dbo].[datosFlap]>
-- =============================================
-- [dbo].[ValidacionDatosFlapPINPAD_INS] '26/10/2020'
CREATE PROCEDURE [dbo].[ValidacionDatosFlapPINPAD_INS]
@fecha date
AS
BEGIN

	--drop table #tempData
	--Declare @fecha date='01/09/2020'
	Declare @serverDB varchar(200) 
	,@ipDB varchar(200) 
	,@idempresa int
	,@idsucursal int
	,@unidadNegocio int
	,@categoriaCobranza int
	,@tipoPago nvarchar(20)
	,@tipo_poliza_traspaso nvarchar(20)
	,@importe decimal(18,2)
	,@noCuenta nvarchar(20)
	,@mov_conspol int
	DECLARE @datosflapBP TABLE (
	id int identity,
	fecha date,
	referencia [nvarchar](50),
	idtrans [int],
	[importe] [decimal](18, 2) ,
	documento nvarchar(50),
	idempresa int,
	idsucursal int
)
	DECLARE @datospolBP TABLE (
	id int identity,
	idempresa int,
	idsucursal int,
	mov_tipopol [nvarchar](50),
	mov_conspol [int],
	mov_debe [decimal](18, 2) ,
	mov_observa nvarchar(50),
	serverDB nvarchar(200) 
	
)
	DECLARE @datosBanco TABLE (
	id int identity,
	idempresa int,
	idsucursal int,
	idbmer int,
	refampliada [nvarchar](250),
	concepto [nvarchar](250),
	estatus int,
	importe decimal(18,2)
	
)

	select  ROW_NUMBER() OVER(
			ORDER BY unidadNegocio,dbo.replacecat(categoriacobranza)) AS RowNum,convert(date,fechapago) fechapago,unidadNegocio,dbo.replacecat(categoriacobranza) categoriacobranza,idempresa,idsucursal,tipopago,max(referenciaConciliacion) referenciaConciliacion,cuentaBancaria,SUM(d.IMPORTE) IMPORTE 
			into #tempData
			from datosFlap d
			inner join pago p on d.referencia=p.referencia and idTrans=d.numeroOrden
	where  convert(date,fechapago)=@fecha and p.idOrigen != 4--and estatusProcesado=0
	--and unidadNegocio=3
	GROUP BY convert(date,fechapago),unidadNegocio,dbo.replacecat(categoriacobranza),idempresa,idsucursal,tipopago,cuentaBancaria

	--select * from #tempData
	DECLARE @Counter INT ,@CounterMax INT ,@query varchar(max)
	
	select @CounterMax=max(rownum) from #tempData
	SET @Counter=1
	WHILE ( @Counter <= @CounterMax)
	BEGIN
		select @idempresa=idEmpresa,@idsucursal=idSucursal,@unidadNegocio=unidadNegocio,@categoriaCobranza=categoriaCobranza,@importe=importe,@noCuenta=cuentaBancaria from #tempdata where rownum=@counter
		select @serverDB=nombre_base,@tipo_poliza_traspaso= tipo_poliza_traspaso from Centralizacionv2..dig_cat_bases_bpro where emp_idempresa=@idempresa and suc_idsucursal=@idsucursal and tipo=1

		SET @query  = 
	('SELECT VTE_FECHDOCTO,RX.referencia,PA.idTrans,PA.IMPORTE,RX.documento,'+convert(nvarchar(6),@idempresa)+' idempresa,'+convert(nvarchar(6),@idsucursal)+' idsucursal FROM '+@serverDB+'.DBO.ADE_VTAFI V INNER JOIN '+@serverDB+'.DBO.ADE_VTAFP P ON V.VTE_DOCTO = P.VFP_DOCTO
	INNER JOIN '+@serverDB+'.DBO.PNC_PARAMETR R ON P.VFP_TIPOPAGO =  R.PAR_IDENPARA 
	inner join (select d.documento,referencia,r.idEmpresa,d.idSucursal from Referencia r inner join DetalleReferencia d on r.idReferencia=d.idReferencia ) rx
	on  rx.documento like ''%''+substring(v.VTE_DOCTO,1,2)+''%''+replace(ltrim(replace(substring(v.vte_docto,3,len(vte_docto)-2),''0'','' '')),'' '',''0'') collate database_default
	inner join referencias..Pago pa on rx.referencia=pa.referencia and v.VTE_TOTAL=pa.IMPORTE
	WHERE VTE_FECHDOCTO ='''+convert(nvarchar(10),@fecha,103)+''' AND PAR_TIPOPARA = ''FP'' AND PAR_DESCRIP1 LIKE ''%PINPAD%''')

	print @query
	/*LIMPIO LA TABLA*/
	--DELETE FROM @datosflapBP;
	/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
	insert @datosflapBP
	EXEC( @query)

		SET @query  = 
	('select '+convert(nvarchar(6),@idempresa)+' idempresa,'+convert(nvarchar(6),@idsucursal)+' idsucursal,mov_tipopol,mov_conspol,mov_debe,mov_observa,'''+@serverDB+''' serverDB from '+@serverDB+'.[dbo].CON_MOVDET012020 where MOV_TIPOPOL = '''+@tipo_poliza_traspaso+'''  and mov_mes>='+Convert(nvarchar(2),month(@fecha))+' and mov_debe='+convert(nvarchar(21),@importe))
	print @query
	insert @datospolBP
	EXEC( @query)
	insert @datosBanco
select @idempresa idEmpresa,@idsucursal idSucursal,idbmer,refAmpliada,concepto,estatusRevision,importe from bancomer where importe=@importe and noCuenta=@noCuenta and refAmpliada like '%multipago%'		

		SET @Counter  = @Counter  + 1
	END
	
	--select * from #tempData
	--select * from @datosflapBP
	--select * from @datospolBP
	--select idempresa,idsucursal,sum(importe) importe from @datosflapBP group by idempresa,idsucursal

	select ROW_NUMBER() OVER(
			ORDER BY t.idempresa,t.idsucursal) rownum,t.fechapago,t.idempresa,t.idsucursal,unidadNegocio unidadNegocioDF,categoriaCobranza categoriaCobranzaDF,t.importe importeDF,df.importe importeBP,case when t.importe=df.importe then 'Igual' else 'No igual' end comparacionfactura,
	ba.idbmer,ba.refampliada,ba.concepto,ba.estatus,ba.importe importebanco,cuentaBancaria,
	serverDB,mov_tipopol,mov_conspol,mov_debe ,case when t.importe=mov_debe then 'Igual' else 'No igual' end comparacionconmovdet,10000.00 mov_debeimporte
	
	into #tempDatamovdebe
	from #tempData t
	left join (select idempresa,idsucursal,sum(importe) importe from @datosflapBP group by idempresa,idsucursal) df on t.idEmpresa=df.idempresa and t.idSucursal=df.idsucursal
	left join @datospolBP bp on t.idEmpresa=bp.idempresa and t.idSucursal=bp.idsucursal and t.referenciaConciliacion=bp.mov_observa
	left join @datosBanco ba on t.idEmpresa=ba.idempresa and t.idSucursal=ba.idsucursal and t.importe=ba.importe
	order by t.idEmpresa,t.idSucursal

	select b.idEmpresa,b.idSucursal, b.referencia,b.idtrans,b.importe,b.documento,d.id_registro 
	from @datosflapBP b 
	left join datosFlap d on b.referencia=d.referencia and convert(date,d.fechapago)=@fecha and b.idempresa=d.idEmpresa and b.idsucursal=d.idSucursal
	where id_registro is null
	order by b.idEmpresa,b.idSucursal

	--	select @CounterMax=max(rownum) from #tempDatamovdebe
	--SET @Counter=1
	--WHILE ( @Counter <= @CounterMax)
	--BEGIN
	--select @idempresa=idEmpresa,@idsucursal=idSucursal,@serverDB=serverDB,@tipo_poliza_traspaso=mov_tipopol,@mov_conspol=mov_conspol from #tempDatamovdebe where rownum=@counter

	--	SET @query  = 
	--('update #tempDatamovdebe set mov_debeimporte=isnull(( select sum(mov_debe) 
	--from '+@serverDB+'.[dbo].CON_MOVDET012020 where MOV_TIPOPOL = '''+@tipo_poliza_traspaso+'''  and mov_mes='+Convert(nvarchar(2),month(@fecha))+' and mov_conspol='+convert(nvarchar(5),@mov_conspol))+' ),0)
	--where rownum='+convert(nvarchar(10),@counter)
	--print @query
	
	--EXEC( @query)
	--	SET @Counter  = @Counter  + 1
	--END
	select * from #tempDatamovdebe
END





--select * from datosFlap d
--where  convert(date,fechapago)='2020-08-28' and unidadNegocio=3 --and categoriaCobranza in(11)
--select sum(d.importe) from datosFlap d
--inner join Pago p on d.referencia=p.referencia
--where unidadNegocio=3  and convert(date,fechapago)='2020-08-28' 
--select * from bancomer where fechaOperacion>='2020-08-20' and refAmpliada like '%multipago%' and noCuenta='000000000195334667' and importe=11704.99
--select * from gaau_concentra.[dbo].CON_MOVDET012020 where MOV_TIPOPOL = 'SALDOINGun'  and mov_mes=9  and MOV_CONSPOL=11


go

