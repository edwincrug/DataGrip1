-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<crea poliza de la tabla [dbo].[datosFlap]>
-- =============================================
--[dbo].[CreaPoliza_INS] 
/*
RESPALDO DE PRODUCCION 29/06/2020
*/
CREATE PROCEDURE [dbo].[CreaPoliza_INS]

AS
BEGIN
--exec  [dbo].[CreaPolizaPINPAD_INS]
--exec dbo.[CreaPolizaMailOrder_INS]
print 'poiii'
END
go

