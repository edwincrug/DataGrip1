-- ==========================================================================================
-- Modified by:	Lourdes Maldonado Sanchez
-- Create date: 02/08/2018
-- Description:	Stored que busca el nombre de un cliente en las tablas de BPRO.
-- 111035, 'BONNET','XAXX010101000'  
-- ==========================================================================================
-- EXECUTE [dbo].[SEL_BUSCA_CLIENTES_SP_LMS] @busca= '24401', @tipo= 3
CREATE PROCEDURE [dbo].[SEL_BUSCA_CLIENTES_SP_LMS] 
	 @busca VARCHAR(100)
	,@tipo  INT
	,@idEmpresa INT
AS
BEGIN
	
	IF (@tipo = 1)
	BEGIN
	 	PRINT '1)Busco por nombre'
		SELECT TOP 5 PER_IDPERSONA as idCliente
				, RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre
				, PER_RFC as RFC
				, PER_TIPO as Tipo
			FROM GA_Corporativa.dbo.PER_PERSONAS
		WHERE RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) Like '%'+ @busca +'%'
	END
		ELSE IF (@tipo = 2)
		BEGIN
			PRINT '2)Busco por RFC'
			SELECT TOP 5 PER_IDPERSONA as idCliente
				 , RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre
				 , PER_RFC as RFC
				 , PER_TIPO as Tipo
			 FROM GA_Corporativa.dbo.PER_PERSONAS
			WHERE RTRIM(LTRIM(PER_RFC)) Like '%'+ @busca +'%'
		END
			ELSE IF (@tipo = 3)
			BEGIN		
				 PRINT '3)Busco por ID'
				 SELECT TOP 5 PER_IDPERSONA as idCliente
						, RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre
						, PER_RFC as RFC
						, PER_TIPO as Tipo
				FROM GA_Corporativa.dbo.PER_PERSONAS
				WHERE PER_IDPERSONA LIKE @busca + '%'
			END

END


go

