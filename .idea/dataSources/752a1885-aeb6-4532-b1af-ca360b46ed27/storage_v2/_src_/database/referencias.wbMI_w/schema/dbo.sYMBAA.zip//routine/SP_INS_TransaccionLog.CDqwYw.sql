



-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 30-09-2019
-- Description: Inserta las Transacciones Proceso de Estatus
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_TransaccionLog] 
	 (	@idTrans numeric(18,0)
        ,@idEstatus int
		)

AS
BEGIN
	BEGIN TRY  --Estar TryCatch

			INSERT INTO [dbo].[TransaccionLog]
						([idTrans]
						,[idEstatus]
						,[fechaRegistro])
				VALUES
						(@idTrans
						,@idEstatus
						,GETDATE())

	END TRY  
	BEGIN CATCH  
		--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[TransaccionLog]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro  

	END CATCH; --End TryCatch

END
go

