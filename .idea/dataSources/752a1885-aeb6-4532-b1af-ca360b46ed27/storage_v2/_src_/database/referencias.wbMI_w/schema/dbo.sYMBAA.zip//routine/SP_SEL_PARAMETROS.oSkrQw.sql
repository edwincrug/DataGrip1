-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_PARAMETROS]
	--@idEmpresa INT
AS
BEGIN

	SELECT 
		parametro_lectura,
		parametro_procesado 
	FROM ParametrosProcesos
END
go

