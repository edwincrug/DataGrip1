CREATE FUNCTION [dbo].[fnReferenciaSantanderFactura](
	@CurrentBase varchar(50),
	@idDeposito NUMERIC(18)
)  
RETURNS varchar(max)   
AS   
-- Returns the stock level for the product.
BEGIN 
	DECLARE @DepartamentosNissan VARCHAR(MAX) = 
	'CASE R.idEmpresa 
							WHEN 2 THEN (
											CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DR.idSucursal
																		WHEN 4 THEN 16
																	END
																)
												ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
											END
										)
							WHEN 3 THEN (
											CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DR.idSucursal
																		WHEN 5 THEN 21
																	END
																)
												ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
											END
										)
							WHEN 4 THEN (
											CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DR.idSucursal
																		WHEN 6 THEN 26
																		WHEN 7 THEN 31
																		WHEN 8 THEN 36
																	END
																)
												ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
											END
										)
							WHEN 5 THEN (
											CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DR.idSucursal
																		WHEN 9 THEN 41
																		WHEN 10 THEN 46
																		WHEN 11 THEN 51
																	END
																)
												ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
											END
										)
							WHEN 6 THEN (
											CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DR.idSucursal
																		WHEN 12 THEN 56
																		WHEN 13 THEN 61
																		WHEN 14 THEN 66
																	END
																)
												ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
											END
										)
							WHEN 8 THEN (
											CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DR.idSucursal
																		WHEN 17 THEN 81
																	END
																)
												ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
											END
										)
							WHEN 9 THEN (
											CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DR.idSucursal
																		WHEN 18 THEN 86
																		WHEN 19 THEN 91
																		WHEN 20 THEN 96
																		WHEN 21 THEN 105
																	END
																)
												WHEN ''US'' THEN (
																	CASE DR.idSucursal
																		WHEN 18 THEN 86
																		WHEN 19 THEN 91
																		WHEN 20 THEN 96
																		WHEN 21 THEN 105
																	END
																)
												ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
											END
										)
							WHEN 10 THEN (
												CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
													WHEN ''OT'' THEN (
																		CASE DR.idSucursal
																			WHEN 22 THEN 110
																			WHEN 23 THEN 115
																		END
																	)
													ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
												END
											)
							WHEN 11 THEN (
												CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento)
													WHEN ''OT'' THEN (
																		CASE DR.idSucursal
																			
																			WHEN 25 THEN 125
																		END
																	)
													ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
												END
											)
							ELSE CONVERT(VARCHAR(18),DR.idDepartamento)
						END';
	
	DECLARE @RAPreferencia VARCHAR(MAX) = 
	'CASE  -- Unidades Nuevas y Seminuevas
						WHEN (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT CONVERT(VARCHAR(18),ucu_idcotizacion) FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DR.documento ) IS NOT NULL
										 THEN (SELECT ucu_foliocotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL WHERE ucu_idcotizacion = (SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DR.documento)) COLLATE Modern_Spanish_CS_AS
										ELSE DR.documento
									END
								)
						ELSE DR.documento
				   END';
	
	DECLARE @RAPiddocto VARCHAR(MAX) = 
	'CASE  -- Unidades Nuevas y Seminuevas
						WHEN (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DR.documento ) IS NOT NULL
										 THEN DR.documento
										ELSE ''''
									END
								)
						ELSE ''''
				   END';
	
	DECLARE @RAPcotped VARCHAR(MAX) = 
	'CASE  -- Unidades Nuevas y Seminuevas
						WHEN (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DR.documento ) IS NOT NULL
										 THEN ''COTIZACION UNIVERSAL''
										ELSE ''''
									END
								)
						ELSE ''''
				   END';
				   
	DECLARE @Consecutivo VARCHAR(MAX) = '( SELECT
													CASE WHEN MAX(RAP_NumDeposito) IS NULL
														THEN 1
													ELSE (MAX(RAP_NumDeposito) + 1 ) END
												FROM GA_Corporativa.DBO.cxc_refantypag
												WHERE rap_referenciabancaria = R.referencia)';
						 
	DECLARE @queryText VARCHAR(MAX) = 
		-- 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno )'+ char(13) + -- DESCOMENTAR LINEA
		'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )'+ char(13) + -- DESCOMENTAR LINEA
		'SELECT' + char(13) + 
		'	rap_idempresa = R.idEmpresa,' + char(13) + 
		'	rap_idsucursal = DR.idSucursal,' + char(13) + 
		'	rap_iddepartamento = '+ @DepartamentosNissan +',' + char(13) + 
		'	rap_idpersona = DR.idCliente,' + char(13) + 
		'	rap_cobrador = '+char(39)+'MMK'+char(39)+',' + char(13) + 
		'	rap_moneda = '+char(39)+'PE'+char(39)+',' + char(13) + 
		'	rap_tipocambio = 1,' + char(13) + 
		'	-- rap_referencia = ltrim(SAN.concepto) COLLATE SQL_Latin1_General_CP1_CI_AS,' + char(13) + 
		'	rap_referencia = '+ @RAPreferencia +',' + char(13) + 
		'	-- rap_iddocto =  dr.documento,'+ char(13) + 
		'	rap_iddocto =  '+ @RAPiddocto +','+ char(13) + 
		'	-- rap_cotped = '+char(39)+''+char(39)+',' + char(13) + 		
		'	rap_cotped = '+ @RAPcotped +',' + char(13) + 		
		'	rap_consecutivo = (SELECT CCP_CONSCARTERA FROM '+ @CurrentBase +'.VIS_CONCAR01 WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente),' + char(13) + 
		'	-- rap_consecutivo = 400000,' + char(13) + 
		'	rap_importe = convert(decimal,SAN.importe),' + char(13) + 
		'	rap_formapago = (select top 1 co.CodigoBPRO  from Santander S inner join  CodigoIdentificacion co on co.CodigoBanco = S.clacon where S.concepto =  R.referencia),' + char(13) + 
		'	rap_numctabanc = SAN.noCuenta,' + char(13) + 
		'	rap_fecha = GETDATE(),' + char(13) + 
		'	rap_idusuari = (SELECT usu_idusuario FROM ControlAplicaciones..cat_usuarios WHERE usu_nombreusu = '+char(39)+'GMI'+char(39)+'),' + char(13) + 
		'	rap_idstatus = '+char(39)+'1'+char(39)+',' + char(13) + 
		--'	rap_banco = C.IdBanco_bpro,' + char(13) + 
		'	rap_banco = (SELECT idBancoBPRO FROM referencias.dbo.BancoCuenta WHERE idEmpresa = R.idEmpresa AND idBanco = SAN.idbanco AND numeroCuenta = SAN.noCuenta),' + char(13) + 
		'	rap_referenciabancaria = R.referencia,' + char(13) + 	  
		'	rap_anno = (SELECT Vcc_Anno FROM '+ @CurrentBase +'.VIS_CONCAR01 WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente), ' + char(13) + 
		'	RAP_AplicaPago = convert(numeric(18,2),SAN.importe),' + char(13) + 
		'	RAP_NumDeposito = ' + @Consecutivo + ' ' + char(13) + 
		'FROM Referencia R ' + char(13) + 
		'INNER JOIN Santander SAN ON R.Referencia = SAN.concepto' + char(13) + 
		'INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa ' + char(13) + 
		--'LEFT JOIN Rel_BancoCobro C ON R.idEmpresa = C.emp_idempresa' + char(13) + 
		'INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal' + char(13) + 
		'WHERE SAN.estatusRevision = 1 ' + char(13) + 
		'	   AND SAN.signo = ''+'' ' + char(13) + 
		'	   AND DR.idTipoDocumento = 1' + char(13) + 
		'	   AND SAN.IdBanco = 3' + char(13) +
		'	   AND SAN.idSantander = ' + CONVERT( VARCHAR(10), @idDeposito ) + char(13)  
		
		
    RETURN @queryText
END;



go

