
CREATE PROC VALIDA_COBROS_2018 @Empresa varchar(2)
AS

IF @Empresa = 1 
BEGIN

	--SUZUKI----------------------------------------------------------------------
	--BANCOMER 4667
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '00741820000195334667'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAU_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '00741820000195334667'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAU_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))

	--SANTANDER 8249
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65504258249'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAU_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0018' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65504258249'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAU_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0018' AND MOV_MES = MONTH(GETDATE()))

END

ELSE IF  @Empresa = 2

BEGIN 

	--PEUGEOT----------------------------------------------------------------------
	--BANCOMER 8154
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '00741820000195368154'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAT_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0002-0001' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '00741820000195368154'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAT_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0002-0001' AND MOV_MES = MONTH(GETDATE()))

	--SANTANDER 9012
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65504569012'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAT_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0002-0004' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65504569012'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAT_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0002-0004' AND MOV_MES = MONTH(GETDATE()))

END

ELSE IF  @Empresa = 3

BEGIN 

	--HONDA----------------------------------------------------------------------
	--BANCOMER 1464
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000110861464'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAHondaConcen.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000110861464'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAHondaConcen.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))

	--SANTANDER 3972
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65506313972'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAHondaConcen.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0005' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65506313972'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAHondaConcen.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0005' AND MOV_MES = MONTH(GETDATE()))

END

ELSE IF  @Empresa = 4

BEGIN 

	--NISSAN----------------------------------------------------------------------
	--BANCOMER 1289
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000190701289'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAZM_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0010' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000190701289'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAZM_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0010' AND MOV_MES = MONTH(GETDATE()))
	
	--BANCOMER 0351
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000445990351'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAZM_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000445990351'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAZM_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))

	--SANTANDER 7299
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65500507299'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAZM_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0005' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65500507299'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAZM_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0005' AND MOV_MES = MONTH(GETDATE()))

END

ELSE IF  @Empresa = 5

BEGIN 

	--CHEVROLET----------------------------------------------------------------------
	--BANCOMER 1986
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000145881986'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAA_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000145881986'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAA_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))
	
	--BANCOMER 0517
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000195520517'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAA_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0010' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000195520517'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAA_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0010' AND MOV_MES = MONTH(GETDATE()))

	--SANTANDER 0378
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '92000250378'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAA_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0005' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '92000250378'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM GAAA_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0005' AND MOV_MES = MONTH(GETDATE()))

END

ELSE IF  @Empresa = 6

BEGIN 

	--GMI----------------------------------------------------------------------
	--BANCOMER 3084
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000148333084'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAS_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000148333084'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAS_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_MES = MONTH(GETDATE()))
	
	--BANCOMER 3324
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000152643324'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAS_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0002' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000152643324'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAS_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0002' AND MOV_MES = MONTH(GETDATE()))

	--BANCOMER 1521
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000195521521'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAS_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0003-0001' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '000000000195521521'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAS_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0003-0001' AND MOV_MES = MONTH(GETDATE()))
	
	--SANTANDER 3160
	INSERT INTO [referencias].[dbo].[cxc_refantypag]
	SELECT rap_folio,rap_idempresa,rap_idsucursal,rap_iddepartamento,rap_idpersona,rap_cobrador,rap_moneda,rap_tipocambio,rap_referencia,rap_iddocto,rap_cotped,
	rap_consecutivo,rap_importe,rap_formapago,rap_numctabanc,rap_fecha,rap_idusuari,rap_idstatus,rap_banco,rap_referenciabancaria,rap_anno,RAP_AplicaPago,RAP_NumDeposito
	FROM [GA_Corporativa].[dbo].[cxc_refantypag] WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65502403160'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAS_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0006' AND MOV_MES = MONTH(GETDATE()))

	UPDATE [GA_Corporativa].[dbo].[cxc_refantypag] SET rap_idstatus = 2 WHERE rap_idstatus = 1 AND rap_idempresa = @Empresa AND rap_numctabanc = '65502403160'
	AND rap_referenciabancaria + '-' + CONVERT(VARCHAR(1),RAP_NumDeposito) 
	IN(SELECT  MOV_OBSERVA COLLATE SQL_Latin1_General_CP1_CI_AS FROM [192.168.20.31].GAAS_Concentra.DBO.CON_MOVDET012018 
	WHERE MOV_NUMCTA = '1100-0020-0001-0006' AND MOV_MES = MONTH(GETDATE()))

END
go

