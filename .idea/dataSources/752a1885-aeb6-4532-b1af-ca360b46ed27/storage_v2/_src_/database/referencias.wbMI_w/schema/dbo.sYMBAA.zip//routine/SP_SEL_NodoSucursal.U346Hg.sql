
-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 11-09-2019
-- Description:	obtiene el nodo mediante idEmpresa y idSucursal
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_NodoSucursal]
(
	@idEmpresa int=0,
	@idSucursal int=0
)
AS
BEGIN

BEGIN TRY  --Init TryCatch
		SELECT * FROM [dbo].[Cat_DivisionOrg_BBVA] 
		WHERE idEmpresa=@idEmpresa AND idSucursal=@idSucursal AND estatus=1;

END TRY  
BEGIN CATCH  
	--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[Cat_DivisionOrg_BBVA]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro  
				   
END CATCH; --End TryCatch

END
go

