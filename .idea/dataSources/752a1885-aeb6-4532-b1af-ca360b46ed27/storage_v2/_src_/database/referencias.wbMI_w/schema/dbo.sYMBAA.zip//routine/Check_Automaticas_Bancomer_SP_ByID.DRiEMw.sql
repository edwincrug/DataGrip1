

-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-01-04
-- Description:	Referencias aplicadas de manera automatica
-- =============================================
CREATE PROCEDURE [dbo].[Check_Automaticas_Bancomer_SP_ByID] 
	
AS
BEGIN
    DECLARE @idEmpresa INT = 1

    SET NOCOUNT ON;

    DECLARE @FacturaQuery varchar(max)  = '';
    DECLARE @Base VARCHAR(MAX)			= '';
    DECLARE @idDeposito INT				= '';
    DECLARE @idBanco INT				= 1;

    DECLARE @countDep INT				= 0;
    DECLARE @rap_folio INT				= 0;

    -- Consulta de las bases de datos y sucursales activas
    DECLARE @tableConf  TABLE(idEmpresa INT, idSucursal INT, servidor VARCHAR(250), baseConcentra VARCHAR(250), sqlCmd VARCHAR(8000), cargaDiaria VARCHAR(8000));
    DECLARE @tableBancoFactura TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT);
    DECLARE @tableBancoCotizacion TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT);
    INSERT INTO @tableConf Execute [dbo].[SEL_ACTIVE_DATABASES_SP];
    -- SELECT * FROM @tableConf;
    DECLARE @CountSuc INT = (SELECT COUNT(idSucursal) Sucursales FROM @tableConf WHERE idEmpresa = @idEmpresa);
    PRINT( '========================= [ RAP_Automaticas_Bancomer_SP ] =========================' );
    PRINT( 'EMPRESA ' + CONVERT(VARCHAR(2), @idEmpresa) + ': SUCURSALES ' + CONVERT(VARCHAR(3), @CountSuc) );

    DECLARE @Current INT = 0, @Max INT = 0;
    DECLARE @CurrentBanco INT = 0, @MaxBanco INT = 0;
    DECLARE @CurrentBancoCoti INT = 0, @MaxBancoCoti INT = 0;

    SELECT @Current = MIN(idSucursal),@Max = MAX(idSucursal) FROM @tableConf WHERE idEmpresa = @idEmpresa;
    WHILE(@Current <= @Max )
        BEGIN
            -- FUNCIONAMIENTO PARA COTIZACIONES
            -- FUNCIONAMIENTO PARA COTIZACIONES
            -- FUNCIONAMIENTO PARA COTIZACIONES			
            SET @FacturaQuery = 'SELECT
                                    B.idBmer
                                    FROM Referencia R 
                                    INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.concepto,3,20)
                                    INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
                                    INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
                                    WHERE B.idBmer = 129926 AND
                                        DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + ';';

            INSERT INTO @tableBancoCotizacion
            EXECUTE( @FacturaQuery );
            
            --SELECT * FROM @tableBancoCotizacion;
            --DELETE FROM @tableBancoCotizacion;
            --SELECT * FROM @tableBancoCotizacion;
            -- Inicia segundo While
            SELECT @CurrentBancoCoti = MIN(consecutivo),@MaxBancoCoti = MAX(consecutivo) FROM @tableBancoCotizacion;
            WHILE(@CurrentBancoCoti <= @MaxBancoCoti )
                BEGIN
                    -- Funcionamiento de meter en cxc_refantypag
                    -- Funcionamiento de meter en cxc_refantypag
                    BEGIN TRY
                        SET @idDeposito			  = ( SELECT TOP 1 idDeposito FROM @tableBancoCotizacion WHERE consecutivo = @CurrentBancoCoti );
                        SELECT @FacturaQuery	  = [dbo].[fnReferenciaBancomerCotizacion_TEST]( @Base, @idDeposito );						
                        SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
                        EXECUTE( @FacturaQuery );
                        
                        PRINT( @FacturaQuery );
                        PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] COTIZACIÓN: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
                    END TRY
                    BEGIN CATCH	
                        PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] COTIZACIÓN: ' + ERROR_MESSAGE() );
                        --PRINT( '====================================================================================' );
                        --PRINT( @FacturaQuery );
                        --PRINT( '====================================================================================' );
                    END CATCH
                    -- Funcionamiento de meter en cxc_refantypag
                    -- Funcionamiento de meter en cxc_refantypag
                SET	@CurrentBancoCoti = @CurrentBancoCoti + 1;
                END	
            
            
            PRINT('');
            -- /FUNCIONAMIENTO PARA COTIZACIONES
            -- /FUNCIONAMIENTO PARA COTIZACIONES
            -- /FUNCIONAMIENTO PARA COTIZACIONES
            
            
            SET	@Current = @Current + 1;
        END  

END


go

