
-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 30-09-2019
-- Description: Inserta las Transacciones
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_Transaccion] 
	 (	    @idEmpresa numeric(18,0)=0
           ,@idSucursal numeric(18,0)=0
           ,@idDepartamento numeric(18,0)=0
           ,@idTipoDocumento numeric(18,0)=0
           ,@importeDocumento decimal(18,2)=0
           ,@serie varchar(100)=NULL
           ,@folio varchar(100)=NULL
           ,@idCliente numeric(18,0)=0
           ,@idAlmacen VARCHAR(10)=0
           ,@idTipoReferencia int=0
           ,@idEstatus int=0
		   ,@idOrigen int=0
		   ,@idEmisor int=0
		   ,@Id numeric(18,0) OUTPUT
	)

AS
BEGIN

		BEGIN TRY  --Estar TryCatch

				INSERT INTO [dbo].[Transaccion]
			       ([idEmpresa]
			       ,[idSucursal]
			       ,[idDepartamento]
			       ,[idTipoDocumento]
			       ,[importeDocumento]
			       ,[serie]
			       ,[folio]
			       ,[idCliente]
			       ,[idAlmacen]
			       ,[idTipoReferencia]
			       ,[idEstatus]
				   ,[idOrigen]
				   ,[idEmisor]
			       ,[fechaRegistro])
			 VALUES
			       (@idEmpresa
			       ,@idSucursal
			       ,@idDepartamento
			       ,@idTipoDocumento
			       ,@importeDocumento
			       ,@serie
			       ,@folio
			       ,@idCliente
			       ,@idAlmacen
			       ,@idTipoReferencia
			       ,@idEstatus
				   ,@idOrigen
				   ,@idEmisor
			       ,GETDATE())
				
				--SELECT @outId= @@ROWCOUNT
				--SELECT @Id=@@IDENTITY
				SET @Id=@@IDENTITY;
				SELECT @Id AS Id;

		END TRY  
		BEGIN CATCH  
				--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[Transaccion]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro

		END CATCH; --End TryCatch

END
go

