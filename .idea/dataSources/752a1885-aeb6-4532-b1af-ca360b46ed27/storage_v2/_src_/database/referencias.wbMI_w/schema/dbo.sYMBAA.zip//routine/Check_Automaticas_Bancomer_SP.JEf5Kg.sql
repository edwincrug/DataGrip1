

-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-01-04
-- Description:	Referencias aplicadas de manera automatica
-- =============================================
--[dbo].[Check_Automaticas_Bancomer_SP]5
CREATE PROCEDURE [dbo].[Check_Automaticas_Bancomer_SP] 
	@idEmpresa INT = 0
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @FacturaQuery varchar(max)  = '';
	DECLARE @Base VARCHAR(MAX)			= '';
	DECLARE @idDeposito INT				= '';
	DECLARE @referencia nvarchar(20)    = '';
	DECLARE @idBanco INT				= 1;
	
	DECLARE @countDep INT				= 0;
	DECLARE @rap_folio INT				= 0;

	-- Consulta de las bases de datos y sucursales activas
	DECLARE @tableConf  TABLE(idEmpresa INT, idSucursal INT, servidor VARCHAR(250), baseConcentra VARCHAR(250), sqlCmd VARCHAR(8000), cargaDiaria VARCHAR(8000));
	DECLARE @tableBancoFactura TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT,referencia nvarchar(20));
	DECLARE @tableBancoCotizacion TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT,referencia nvarchar(20));
	DECLARE @tableBancoOrden TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT,referencia nvarchar(20));
	DECLARE @tableBancoPedido TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT,referencia nvarchar(20));
	INSERT INTO @tableConf Execute [dbo].[SEL_ACTIVE_DATABASES_SP];
	DECLARE @CountSuc INT = (SELECT COUNT(idSucursal) Sucursales FROM @tableConf WHERE idEmpresa = @idEmpresa);
	PRINT( '========================= [ RAP_Automaticas_Bancomer_SP ] =========================' );
	PRINT( 'EMPRESA ' + CONVERT(VARCHAR(2), @idEmpresa) + ': SUCURSALES ' + CONVERT(VARCHAR(3), @CountSuc) );

	DECLARE @Current INT = 0, @Max INT = 0;
	DECLARE @CurrentBanco INT = 0, @MaxBanco INT = 0;
	DECLARE @CurrentBancoCoti INT = 0, @MaxBancoCoti INT = 0;

	SELECT @Current = MIN(idSucursal),@Max = MAX(idSucursal) FROM @tableConf WHERE idEmpresa = @idEmpresa;
	WHILE(@Current <= @Max )
		BEGIN
			-- FUNCIONAMIENTO PARA FACTURAS
			-- FUNCIONAMIENTO PARA FACTURAS
			-- FUNCIONAMIENTO PARA FACTURAS
			SET @FacturaQuery = 'SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.concepto,3,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,1,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,2,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,3,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,4,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,5,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,6,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,7,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,8,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,9,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 1
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())';

			INSERT INTO @tableBancoFactura
			EXECUTE( @FacturaQuery );
			
			SET @countDep = (SELECT COUNT(consecutivo) FROM @tableBancoFactura);
			PRINT( '    Sucursal ' + CONVERT( VARCHAR(3), @Current ) + ': '+ CONVERT(VARCHAR(5), @countDep) +' Referencias');
					
			-- SET del parametro Base		
			--SET @Base = (SELECT servidor FROM @tableConf WHERE idSucursal = @Current);

			-- VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL MISMO
			-- VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL MISMO
			-- VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL MISMO
			DECLARE @ipLocal VARCHAR(15) = (
				SELECT	dec.local_net_address
				FROM	sys.dm_exec_connections AS dec
				WHERE	dec.session_id = @@SPID
			);

			-- DECLARE @Base VARCHAR(300) = ''
			IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
				BEGIN
					SET @Base = (SELECT '[' + nombre_base + '].[dbo]' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
				END
			ELSE
				BEGIN
					SET @Base = (SELECT '[' + ip_servidor + '].[' + nombre_base + '].[dbo]' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
				END
			-- / VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL MISMO
			
			-- Inicia segundo While
			SELECT @CurrentBanco = MIN(consecutivo),@MaxBanco = MAX(consecutivo) FROM @tableBancoFactura;
			WHILE(@CurrentBanco <= @MaxBanco )
				BEGIN
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
					BEGIN TRY						
							 SELECT TOP 1 @idDeposito=idDeposito,@referencia=referencia FROM @tableBancoFactura WHERE consecutivo = @CurrentBanco 
						select @idDeposito,@referencia,'fact'
						SELECT @FacturaQuery	  = [dbo].[fnReferenciaBancomerFactura]( @Base, @idDeposito,@referencia );						
						SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						EXECUTE( @FacturaQuery ); 
						PRINT( @FacturaQuery ); 
						
						--IF( @@ROWCOUNT > 0 )
						--	BEGIN
						--		SET @rap_folio = @@IDENTITY;
						--		INSERT INTO [referencias].[dbo].[RAPDeposito](idEmpresa, idSucursal, rap_folio,idBanco,idDeposito,idOrigenReferencia,fecha) VALUES (@idEmpresa, @Current, @rap_folio, @idBanco, @idDeposito, 'Procesos Automáticos | Factura', GETDATE());
						--		UPDATE [referencias].[dbo].[Bancomer] SET estatusRevision = 2 WHERE idBmer = @idDeposito;
						--	END
						
						PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] FACTURA: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
					END TRY
					BEGIN CATCH
						--INSERT INTO LogRAP(log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal) VALUES( ERROR_MESSAGE(), 'Procesos Automáticos | Factura', GETDATE(), @idBanco, @idDeposito, @idEmpresa, @Current );
						PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] FACTURA: ' + ERROR_MESSAGE() );
					END CATCH
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
				SET	@CurrentBanco = @CurrentBanco + 1;
				END				
			-- /FUNCIONAMIENTO PARA FACTURAS
			-- /FUNCIONAMIENTO PARA FACTURAS
			-- /FUNCIONAMIENTO PARA FACTURAS
			
			
			-- FUNCIONAMIENTO PARA COTIZACIONES
			-- FUNCIONAMIENTO PARA COTIZACIONES
			-- FUNCIONAMIENTO PARA COTIZACIONES			
				SET @FacturaQuery = 'SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.concepto,3,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,1,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,2,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,3,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,4,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,5,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,6,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,7,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,8,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,9,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 2
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())';

			INSERT INTO @tableBancoCotizacion
			EXECUTE( @FacturaQuery );
			print @FacturaQuery
			
			-- Inicia segundo While
			SELECT @CurrentBancoCoti = MIN(consecutivo),@MaxBancoCoti = MAX(consecutivo) FROM @tableBancoCotizacion;
			WHILE(@CurrentBancoCoti <= @MaxBancoCoti )
				BEGIN
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
					BEGIN TRY
						 SELECT TOP 1  @idDeposito=idDeposito,@referencia=referencia FROM @tableBancoCotizacion WHERE consecutivo = @CurrentBancoCoti
						SELECT @FacturaQuery	  = [dbo].[fnReferenciaBancomerCotizacion]( @Base, @idDeposito ,@referencia);
						select @idDeposito,@referencia,'cotiza'
						SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						EXECUTE( @FacturaQuery ); 
						PRINT( @FacturaQuery );
						
						--IF( @@ROWCOUNT > 0 )
						--	BEGIN
						--		SET @rap_folio = @@IDENTITY;
						--		INSERT INTO [referencias].[dbo].[RAPDeposito](idEmpresa, idSucursal, rap_folio,idBanco,idDeposito,idOrigenReferencia, fecha) VALUES (@idEmpresa, @Current, @rap_folio, @idBanco, @idDeposito,'Procesos Automáticos | Cotización', GETDATE());
						--		UPDATE [referencias].[dbo].[Bancomer] SET estatusRevision = 2 WHERE idBmer = @idDeposito;
						--	END
						
						PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] COTIZACIÓN: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
					END TRY
					BEGIN CATCH	
						--INSERT INTO LogRAP(log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal) VALUES( ERROR_MESSAGE(), 'Procesos Automáticos | Cotización', GETDATE(), @idBanco, @idDeposito, @idEmpresa, @Current );
						PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] FACTURA: ' + ERROR_MESSAGE() );
					END CATCH
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
				SET	@CurrentBancoCoti = @CurrentBancoCoti + 1;
				END	
			
			
			PRINT('');
			-- /FUNCIONAMIENTO PARA COTIZACIONES
			-- /FUNCIONAMIENTO PARA COTIZACIONES
			-- /FUNCIONAMIENTO PARA COTIZACIONES
			
			-- FUNCIONAMIENTO PARA PEDIDO
			-- FUNCIONAMIENTO PARA PEDIDO
			-- FUNCIONAMIENTO PARA PEDIDO			
		SET @FacturaQuery = 'SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.concepto,3,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,1,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,2,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,3,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,4,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,5,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,6,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,7,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,8,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,9,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	= 3
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())';

			INSERT INTO @tableBancoPedido
			EXECUTE( @FacturaQuery );
			
			-- Inicia segundo While
			SELECT @CurrentBancoCoti = MIN(consecutivo),@MaxBancoCoti = MAX(consecutivo) FROM @tableBancoPedido;
			WHILE(@CurrentBancoCoti <= @MaxBancoCoti )
				BEGIN
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
					BEGIN TRY
						 SELECT TOP 1  @idDeposito=idDeposito,@referencia=referencia FROM @tableBancoPedido WHERE consecutivo = @CurrentBancoCoti 
						SELECT @FacturaQuery	  = [dbo].[fnReferenciaBancomerPedido]( @Base, @idDeposito,@referencia );
						select @idDeposito,@referencia,'pedido'
						SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						EXECUTE( @FacturaQuery ); 
						PRINT( @FacturaQuery );
						
						--IF( @@ROWCOUNT > 0 )
						--	BEGIN
						--		SET @rap_folio = @@IDENTITY;
						--		INSERT INTO [referencias].[dbo].[RAPDeposito](idEmpresa, idSucursal, rap_folio,idBanco,idDeposito,idOrigenReferencia, fecha) VALUES (@idEmpresa, @Current, @rap_folio, @idBanco, @idDeposito,'Procesos Automáticos | Cotización', GETDATE());
						--		UPDATE [referencias].[dbo].[Bancomer] SET estatusRevision = 2 WHERE idBmer = @idDeposito;
						--	END
						
						PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] PEDIDO: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
					END TRY
					BEGIN CATCH	
						--INSERT INTO LogRAP(log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal) VALUES( ERROR_MESSAGE(), 'Procesos Automáticos | PEDIDO', GETDATE(), @idBanco, @idDeposito, @idEmpresa, @Current );
						PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] PEDIDO: ' + ERROR_MESSAGE() );
					END CATCH
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
				SET	@CurrentBancoCoti = @CurrentBancoCoti + 1;
				END	
			
			
			PRINT('');
			-- /FUNCIONAMIENTO PARA PEDIDO
			-- /FUNCIONAMIENTO PARA PEDIDO
			-- /FUNCIONAMIENTO PARA PEDIDO

			-- FUNCIONAMIENTO PARA ORDEN
			-- FUNCIONAMIENTO PARA ORDEN
			-- FUNCIONAMIENTO PARA ORDEN			
					SET @FacturaQuery = 'SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.concepto,3,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,1,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,2,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,3,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,4,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,5,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,6,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,7,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,8,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())
									  union all
								SELECT
									B.idBmer,r.referencia
								 FROM Referencia R 
								 INNER JOIN Bancomer B ON R.Referencia = SUBSTRING(b.refAmpliada,9,20)
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
								  AND DR.idSucursal		 = ' + CONVERT( VARCHAR(3), @Current ) + '
									  AND B.estatusRevision		= 1
									  AND B.esCargo				= 0
									  AND DR.idTipoDocumento	in (4, 5)
									  and month(b.fechaOperacion)=month(getdate()) and year(b.fechaOperacion)=year(getdate())';

			INSERT INTO @tableBancoOrden
			EXECUTE( @FacturaQuery );
			
			-- Inicia segundo While
			SELECT @CurrentBancoCoti = MIN(consecutivo),@MaxBancoCoti = MAX(consecutivo) FROM @tableBancoOrden;
			WHILE(@CurrentBancoCoti <= @MaxBancoCoti )
				BEGIN
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
					BEGIN TRY
					 SELECT TOP 1  @idDeposito=idDeposito,@referencia=referencia FROM @tableBancoOrden WHERE consecutivo = @CurrentBancoCoti 
						SELECT @FacturaQuery	  = [dbo].[fnReferenciaBancomerOrden]( @Base, @idDeposito,@referencia );
						select @idDeposito,@referencia,'Orden'
						SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						EXECUTE( @FacturaQuery ); 
						PRINT( @FacturaQuery );
						--IF( @@ROWCOUNT > 0 )
						--	BEGIN
						--		SET @rap_folio = @@IDENTITY;
						--		INSERT INTO [referencias].[dbo].[RAPDeposito](idEmpresa, idSucursal, rap_folio,idBanco,idDeposito,idOrigenReferencia, fecha) VALUES (@idEmpresa, @Current, @rap_folio, @idBanco, @idDeposito,'Procesos Automáticos | Cotización', GETDATE());
						--		UPDATE [referencias].[dbo].[Bancomer] SET estatusRevision = 2 WHERE idBmer = @idDeposito;
						--	END
						
						PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] ORDEN: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
					END TRY
					BEGIN CATCH	
						--INSERT INTO LogRAP(log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal) VALUES( ERROR_MESSAGE(), 'Procesos Automáticos | ORDEN', GETDATE(), @idBanco, @idDeposito, @idEmpresa, @Current );
						PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] ORDENg: ' + ERROR_MESSAGE() );
					END CATCH
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
				SET	@CurrentBancoCoti = @CurrentBancoCoti + 1;
				END	
			
			
			PRINT('');
			-- /FUNCIONAMIENTO PARA ORDEN
			-- /FUNCIONAMIENTO PARA ORDEN
			-- /FUNCIONAMIENTO PARA ORDEN
			select * FROM @tableBancoOrden;
			select * FROM @tableBancoPedido;
			select * FROM @tableBancoCotizacion;
			select * FROM @tableBancoFactura;

			DELETE FROM @tableBancoOrden;
			DELETE FROM @tableBancoPedido;
			DELETE FROM @tableBancoCotizacion;
			DELETE FROM @tableBancoFactura;
			SET	@Current = @Current + 1;
		END 
END


go

