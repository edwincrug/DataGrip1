




-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 30-09-2019
-- Description: Inserta las respuestas de pagos ya sean Pin Pad o Web
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PagoRespuesta] 
	 (					@idTrans numeric(18,0)
				       ,@numeroAutorizacion varchar(10)=NULL
				       ,@mensaje varchar(300)=NULL
				       ,@codigoRespuesta varchar(10)=NULL
				       ,@indicadorImpresion varchar(100)=NULL
				       ,@fecha varchar(10)=NULL
				       ,@hora varchar(10)=NULL
				       ,@indicadorTransaccion varchar(10)=NULL
				       ,@script varchar(250)=NULL
				       ,@criptograma varchar(250)=NULL
				       ,@tokenET nvarchar(300)=NULL
				       ,@tokenEX nvarchar(300)=NULL
				       ,@banderaLlave int=NULL
				       ,@banderaBines int=NULL
				       ,@banderaTelecarga int=NULL
					   ,@respuestaBBVA nvarchar(max)=NULL
					   ,@mp_signature nvarchar(max)=NULL
					   ,@cli_signature nvarchar(max)=NULL
					   ,@mp_reference nvarchar(300)=NULL
					   ,@mp_amount numeric(18,2)=NULL
					   ,@estatus bit = NULL
					   ,@mp_cardType nvarchar(10)=NULL
					   ,@mp_paymentMethod nvarchar(50)=NULL
					   ,@mp_bankcode nvarchar(25)=NULL
					   ,@mp_bankname nvarchar(100)=NULL
					   ,@mp_pan nvarchar(max)=NULL
	)

AS
BEGIN
      --Star TryCatch
		BEGIN TRY  
		--SET @idPagRes =  ISNULL( (SELECT id FROM [referencias].dbo.[PagoRespuesta] 
		--	WHERE [idTrans] = @idTrans AND [numeroAutorizacion] = @numeroAutorizacion AND [estatus]=1),0)

			DECLARE @idPagRes INT = 0
			SET @idPagRes =  ISNULL( (SELECT id FROM [referencias].dbo.[PagoRespuesta] 
			WHERE [idTrans] = @idTrans AND [numeroAutorizacion] = @numeroAutorizacion AND [codigoRespuesta] = @codigoRespuesta),0)

			IF @idPagRes = 0
			BEGIN
				INSERT INTO [dbo].[PagoRespuesta]
				       ([idTrans]
				       ,[numeroAutorizacion]
				       ,[mensaje]
				       ,[codigoRespuesta]
				       ,[indicadorImpresion]
				       ,[fecha]
				       ,[hora]
				       ,[indicadorTransaccion]
				       ,[script]
				       ,[criptograma]
				       ,[tokenET]
				       ,[tokenEX]
				       ,[banderaLlave]
				       ,[banderaBines]
				       ,[banderaTelecarga]
					   ,[respuestaBBVA]
					   ,[mp_signature]
					   ,[cli_signature]
					   ,[mp_reference]
					   ,[mp_amount]
					   ,[mp_cardType]
					   ,[mp_paymentMethod]
					   ,[mp_bankcode]
					   ,[mp_bankname]
					   ,[mp_pan]
					   ,[estatus]
				       ,[fechaRegistro])
				 VALUES
				       (@idTrans
				       ,@numeroAutorizacion
				       ,@mensaje
				       ,@codigoRespuesta
				       ,@indicadorImpresion
				       ,@fecha
				       ,@hora
				       ,@indicadorTransaccion
				       ,@script
				       ,@criptograma
				       ,@tokenET
				       ,@tokenEX
				       ,@banderaLlave
				       ,@banderaBines
				       ,@banderaTelecarga
					   ,@respuestaBBVA
					   ,@mp_signature 
					   ,@cli_signature 
					   ,@mp_reference 
					   ,@mp_amount
					   ,@mp_cardType
					   ,@mp_paymentMethod
					   ,@mp_bankcode
					   ,@mp_bankname
					   ,@mp_pan
					   ,@estatus
				       ,GETDATE())

					   SELECT 'Sesión finalizada el pago sera procesado en automático ... puede cerrar la ventana.' AS respuesta, 1 AS bandera;

					   END
				ELSE
				BEGIN
					
					SELECT 'Se género el comprobante de pago ... puede cerrar la ventana.' AS respuesta, 1 AS bandera;

				END

		END TRY  
		BEGIN CATCH  
			--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[PagoRespuesta]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro 

		END CATCH; --End TryCatch

END
go

