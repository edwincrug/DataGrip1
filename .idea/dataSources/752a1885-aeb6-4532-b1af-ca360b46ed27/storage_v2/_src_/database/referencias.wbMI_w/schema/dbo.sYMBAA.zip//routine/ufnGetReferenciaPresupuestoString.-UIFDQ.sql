CREATE FUNCTION [dbo].[ufnGetReferenciaPresupuestoString](@bankTableName varchar(100) , @CurrentBase varchar(50))  
RETURNS varchar(max)   
AS   
-- Returns the stock level for the product.  
BEGIN  


		declare @ISSE varchar(max) = 
		'ISNULL' + char(13) + 
		'		(' + char(13) + 
		'			(' + char(13) + 
		'			SELECT PRE_IDORDEN ' + char(13) + 
		'			FROM '+@CurrentBase+'..SER_PRESUP  ' + char(13) + 
		'			WHERE PRE_IDCLIENTE  = DR.idCliente AND ' + char(13) + 		
		'			CONVERT(VARCHAR(6),CONVERT(NUMERIC,SUBSTRING(PRE_IDORDEN,2,(LEN(PRE_IDORDEN))))) = DR.documento' + char(13) + 
		'			),' + char(13) + 
		'			'+char(39)+''+char(39)+'' + char(13) + 
		'		)' + char(13) + 
		'' 
 

		declare @QueryA varchar(max) = 
		'(select ' + char(13) + 
		'	CASE  [dep_nombrecto]  ' + char(13) + 
		'	WHEN '+char(39)+'SE'+char(39)+' THEN '+ @ISSE  + char(13) + 		
		'	ELSE '+char(39)+''+char(39)+'	' + char(13) + 
		'	END referencia	' + char(13) + 
		'from [ControlAplicaciones].[dbo].[cat_departamentos] ' + char(13) + 
		'where  dep_iddepartamento = DR.idDepartamento)' + char(13) + 
		'' 



		declare @queryText varchar(max) = 
		'SELECT' + char(13) + 
		'	rap_idempresa = R.idEmpresa,' + char(13) + 
		'	rap_idsucursal = DR.idSucursal,' + char(13) + 
		'	rap_iddepartamento = DR.idDepartamento,' + char(13) + 
		'	rap_idpersona = DR.idCliente,' + char(13) + 
		'	rap_cobrador = '+char(39)+'MMK'+char(39)+',' + char(13) + 
		'	rap_moneda = '+char(39)+'PE'+char(39)+',' + char(13) + 
		'	rap_tipocambio = 0,' + char(13) + 
		'	rap_referencia = '+@QueryA+',' + char(13) + 
		'	rap_iddocto = '+char(39)+''+char(39)+',' + char(13) + 
		'	rap_cotped = '+char(39)+'COTIZACION'+char(39)+',' + char(13) + 
		'	rap_consecutivo = '+char(39)+''+char(39)+',' + char(13) + 
		'	rap_importe = convert(decimal,b.importe),' + char(13) + 
		'	rap_formapago = BP.idformapago,' + char(13) + 
		'	rap_numctabanc = SUBSTRING(txtOrigen,5,20),' + char(13) + 
		'	rap_fecha = GETDATE(),' + char(13) + 
		'	rap_idusuari = (SELECT usu_idusuario FROM ControlAplicaciones..cat_usuarios WHERE usu_nombreusu = '+char(39)+'CEL'+char(39)+'),' + char(13) + 
		'	rap_idstatus = '+char(39)+'1'+char(39)+',' + char(13) + 
		'	rap_banco = C.IdBanco_bpro,' + char(13) + 
		'	rap_referenciabancaria = R.referencia,' + char(13) + 
		'	rap_anno = year(getdate()) ' + char(13) + 
		'FROM Referencia R ' + char(13) + 
		'INNER JOIN '+@bankTableName+' B ' + char(13) + 
		'ON R.Referencia = B.refAmpliada' + char(13) + 
		'INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ' + char(13) + 
		'ON R.idEmpresa = BP.emp_idempresa ' + char(13) + 
		'INNER JOIN Rel_BancoCobro C ' + char(13) + 
		'ON R.idEmpresa = C.emp_idempresa' + char(13) + 
		'INNER JOIN DetalleReferencia DR' + char(13) + 
		'ON  DR.idReferencia = R.idReferencia' + char(13) + 
		'AND DR.idSucursal = BP.suc_idsucursal' + char(13) + 
		'WHERE B.estatus = 1 ' + char(13) + 
		'AND B.esCargo = 0 ' + char(13) + 
		'AND DR.idTipoDocumento = 4' + char(13) + 
		'AND C.IdBanco = 1' + char(13) + 
		''         
    RETURN @queryText
	
END;


go

