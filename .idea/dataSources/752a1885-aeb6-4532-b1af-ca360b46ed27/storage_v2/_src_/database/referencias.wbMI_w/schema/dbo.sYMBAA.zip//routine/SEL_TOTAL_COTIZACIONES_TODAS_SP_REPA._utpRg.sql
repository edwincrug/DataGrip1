-- ==========================================================================================
-- Author:     
-- Create date: 
-- Description: Detalle de todos las COTIZACIONES|REFACCIONES|  
--				Filtrando por cliente.	 
--              Para hacer diferencia entre empresas es cambiando el nombre de la base
--				falta buscar por empresa, sucursal y departamento
-- ==========================================================================================
--  [SEL_TOTAL_COTIZACIONES_TODAS_SP_REPA]  @idCliente = 23551 
--345 74990  345     74990     @idempresa, idsucursal, idDepartamento  --  --40078 --11 --40078        
CREATE  PROCEDURE [dbo].[SEL_TOTAL_COTIZACIONES_TODAS_SP_REPA] 
      @idCliente     int = 0
AS
BEGIN
    SET NOCOUNT ON;    
    DECLARE @aux               INT = 1
	DECLARE @cadIpServidor VARCHAR(100);
    DECLARE @max               INT = 0
    DECLARE @idEmpresaBusca    INT = 0
    DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
	DECLARE @nomBaseMatrizNuevo     NVARCHAR(50) =NULL
    DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @select         VARCHAR(max);
	DECLARE @selectPreCot         VARCHAR(max);
	DECLARE @selectCotNu         VARCHAR(max);
	DECLARE	@idSucursal		NVARCHAR(50) =NULL
	DECLARE	@nombreSucursal NVARCHAR(50) =NULL
	DECLARE @nombreEmpresa  NVARCHAR(50) =NULL
	DECLARE	@idEmpresa	NVARCHAR(50) =NULL
	DECLARE @ipServidor NVARCHAR(50)
	DECLARE @sIpaux         VARCHAR(100) = ''  --1) LMS 28/08/2018

	----------------------------------------------------------------
	-- OBTENGO LA IP LOCAL                     --2) LMS 28/08/2018
	----------------------------------------------------------------
	SELECT @sIpaux= local_net_address
	  FROM sys.dm_exec_connections c
	 WHERE c.session_id = @@SPID
    
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
							idSucursal nvarchar(30),
                            idEmpresa         nvarchar(30)
                            ,nombreEmpresa     nvarchar(100)
                            ,nomCtoEmpresa     nvarchar(5)
                            ,nomBaseConcentra  nvarchar(50)
							,nomBaseSucursal  nvarchar(50)
                            ,nomBaseMatriz     nvarchar(50)
                            ,ipServidor        nvarchar(20)
                            )

-- SE HACE LA BUSQUEDA DE LAS EMPRESAS Y SUCURSALES DISPONIBLES CON EL NOMBRE Y DIRECCIÓN IP DONDE SE ENCUENTRAN
     INSERT INTO @Bases
	   	SELECT 
				sucursales.suc_idsucursal
				,EMP.emp_idempresa
                ,EMP.emp_nombre
                ,EMP.emp_nombrecto
                ,BASEMP.nombre_base
				,BASEMP.nombre_sucursal
				--,BASEMP.
                ,ISNULL(BASEMP.nombre_base_matriz,BASEMP.nombre_base)
                ,BASEMP.ip_servidor 
			FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
                INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				inner join [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
          WHERE  BASEMP.estatus = 1  and sucursales.emp_idempresa= EMP.emp_idempresa
       ORDER BY sucursales.suc_idsucursal

     SET @max = (SELECT MAX(IDB) FROM @Bases)
     WHILE(@aux <= @max)
     BEGIN

         
         SELECT  @idEmpresaBusca   = DB.idEmpresa 
				,@idEmpresa = DB.idEmpresa
                ,@nomBaseConcentra = DB.nomBaseConcentra
                ,@nomBaseMatriz    = DB.nomBaseMatriz
				,@idSucursal = DB.idSucursal
				,@nombreSucursal = DB.nomBaseSucursal
				,@nombreEmpresa = DB.nombreEmpresa
				,@ipServidor = DB.ipServidor
           FROM @Bases AS DB 
          WHERE DB.IDB = @aux
		  select 
		   @nomBaseMatrizNuevo    = DB.nomBaseMatriz
		   FROM @Bases AS DB 
          WHERE DB.IDB = @aux and DB.idEmpresa != 2
		--print @nomBaseMatrizNuevo +'matris'
		--print @nomBaseMatriz + 'local'
		IF (@ipServidor = @sIpaux)             --3) LMS 28/08/2018
		BEGIN
		set @cadIpServidor =''
		END
		ELSE
		BEGIN
		set @cadIpServidor =' [' + @ipServidor + '].'
		END
		--select @cadIpServidor

	DECLARE @todo TABLE  ( IDB INT IDENTITY(1,1),
                            idDocumento         nvarchar(MAX)
							,idEmpresa nvarchar(30)
							,nombreEmpresa nvarchar(MAX)
							,idSucursal nvarchar(30)
							,nombreSucursal nvarchar(MAX)
							,idDepartamento  nvarchar(30)
							,nombreDepartamento nvarchar(MAX)
							,saldo nvarchar(max)
						    ,tipoDocumento nvarchar(MAX)
                            ,nombreCliente     nvarchar(MAX)
                            ,fecha  nvarchar(30)
							,idCliente  nvarchar(30)
							,estatus nvarchar(30)
							,referencia nvarchar(max)
                            )

			--Unidades Nuevas| Semi Nuevas
				SET @selectCotNu = 
				'SELECT  ' + char(13) + 
					'cotizacion.ucu_foliocotizacion AS idDocumento' + char(13) + 
					',cotizacion.ucu_idempresa AS idEmpresa' + char(13) +  
					',empresas.emp_nombre as nombreEmpresa' + char(13) +
					',cotizacion.ucu_idsucursal AS idSucursal' + char(13) + 
					',sucursales.suc_nombre AS nombreSucursal' + char(13) + 
					',cotizacion.ucu_iddepartamento AS idDepartamento' + char(13) + 
					--',departamentos.dep_nombre AS nombreDepartamento' + char(13) + 
					',(select [referencias].[dbo].[nombresSucursal](cotizacion.ucu_iddepartamento )) as idDepartamento'+ char(13) + 
					',(SELECT ' + char(13) + 
					'	TOTALVTA = ISNULL(SUM(CUU.ucn_total), 0)' + char(13) + 
					'FROM 	cuentasporcobrar..uni_cotizacionuniversalunidades CUU' + char(13) + 
					'	INNER JOIN cuentasporcobrar..UNI_CotizacionUniversal CU ON CU.ucu_idcotizacion = CUU.ucu_idcotizacion' + char(13) + 
					'	LEFT JOIN		(SELECT' + char(13) + 
					'				CUU.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(PS.PQE_MOVENTA + PS.PQE_REVENTA + PS.PQE_TTVENTA) AS PS_VENTA' + char(13) + 
					'				,SUM(PS.PQE_MOCOSTO + PS.PQE_RECOSTO + PS.PQE_TTCOSTO) AS PS_COSTO' + char(13) + 
					'			FROM ' + char(13) + 
					'				cuentasporcobrar..UNI_CotizacionUniversalUnidades CUU' + char(13) + 
					'					INNER JOIN ' + char(13) + 
					'						['+ @nomBaseMatrizNuevo  +']..SER_PQVEHICULO PV ON PV.PQV_IDCATALOGO = CUU.ucn_idcatalogo COLLATE Modern_Spanish_CI_AS AND PV.PQV_MODELO = CUU.ucn_modelo COLLATE Modern_Spanish_CI_AS' + char(13) + 
					'					INNER JOIN ' + char(13) + 
					'						['+ @nomBaseMatrizNuevo  +']..SER_PAQUESER PS ON PS.PQE_IDPAQUETE = PV.PQV_IDPAQUETE' + char(13) + 
					'			WHERE ' + char(13) + 
					'				EXISTS' + char(13) + 
					'					(' + char(13) + 
					'						SELECT ' + char(13) + 
					'							ucn_idcotizadetalle, ' + char(13) + 
					'							upo_idpaquete ' + char(13) + 
					'						FROM ' + char(13) + 
					'							cuentasporcobrar..uni_preordenser POS ' + char(13) + 
					'						WHERE ' + char(13) + 
					'								(POS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle) ' + char(13) + 
					'							AND (POS.upo_idpaquete = PS.PQE_IDPAQUETE)' + char(13) + 
					'							AND (POS.upo_estatus = 1)' + char(13) + 
					'					)' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				CUU.ucn_idcotizadetalle' + char(13) + 
					'		) NUPS ON NUPS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(' + char(13) + 
					'			SELECT' + char(13) + 
					'				POS.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(PS.PQE_MOVENTA + PS.PQE_REVENTA + PS.PQE_TTVENTA) AS PS_VENTA' + char(13) + 
					'				,SUM(PS.PQE_MOCOSTO + PS.PQE_RECOSTO + PS.PQE_TTCOSTO) AS PS_COSTO' + char(13) + 
					'			FROM' + char(13) + 
					'				cuentasporcobrar..uni_preordenser POS' + char(13) + 
					'					INNER JOIN ['+ @nomBaseMatrizNuevo  +']..SER_PAQUESER PS ON (PS.PQE_IDPAQUETE = POS.upo_idpaquete) AND (POS.upo_estatus = 1) AND (PS.PQE_IDPAQUETE LIKE '+char(39)+'SEMI%'+char(39)+')' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				POS.ucn_idcotizadetalle' + char(13) + 
					'		) SNPS ON SNPS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(' + char(13) + 
					'			SELECT ' + char(13) + 
					'				aw.ucn_idcotizadetalle' + char(13) + 
					'				,SUM([uaw_importe]) AS Importe' + char(13) + 
					'			FROM ' + char(13) + 
					'				cuentasporcobrar.[dbo].[uni_anticiposweb] aw' + char(13) + 
					'			WHERE ' + char(13) + 
					'				(aw.uaw_estatus = 1)' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				aw.ucn_idcotizadetalle' + char(13) + 
					'		) TG ON TG.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(' + char(13) + 
					'			SELECT ' + char(13) + 
					'				PMD.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(PMD.pmd_total) AS Refa_TOTAL' + char(13) + 
					'			FROM ' + char(13) + 
					'				['+ @nomBaseMatrizNuevo  +']..par_pedmostdet PMD' + char(13) + 
					'			WHERE ' + char(13) + 
					'				PMD.pmd_estatus = 1' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				PMD.ucn_idcotizadetalle' + char(13) + 
					'		) Refa ON Refa.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(' + char(13) + 
					'			SELECT ' + char(13) + 
					'				OCD.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(OCD.ucd_cantidad * OCD.ucd_preciounitario) AS Otros_TOTAL' + char(13) + 
					'			FROM ' + char(13) + 
					'				cuentasporcobrar..uni_otroconceptosdet OCD' + char(13) + 
					'			WHERE ' + char(13) + 
					'				OCD.ucd_estatus = 1' + char(13) + 
					'			GROUP BY ' + char(13) + 
					'				OCD.ucn_idcotizadetalle' + char(13) + 
					'		) Otros ON Otros.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'WHERE ' + char(13) + 
					'	CUU.ucu_idcotizacion =  cotizacion.ucu_idcotizacion ) as saldo' + char(13) + ''+ 
					',2 as idTipoDocumento'+
					',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
					',convert(date, cotizacion.ucu_fechacotiza,113)AS fechaDocumento' + char(13) +
					',cotizacion.ucu_idcliente as idCliente' + char(13) + 
					',null as estatus' + char(13) + 
					',(SELECT referencia from [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia WHERE documento = cotizacion.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS and REF.tipoReferencia = 1)as Referencia '+
					'FROM cuentasporcobrar.dbo.uni_cotizacionuniversal cotizacion  ' + char(13) + 
					'INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = cotizacion.ucu_idcliente' + char(13) + 
					'INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = cotizacion.ucu_idempresa' + char(13) + 
					'INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = cotizacion.ucu_idsucursal' + char(13) + 
					--'INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] departamentos  ON departamentos.dep_iddepartamento = cotizacion.ucu_iddepartamento  ' + char(13) + 
					'WHERE ucu_estatus != 14'+
					''        
         SET @aux = @aux + 1
     END
	   INSERT INTO @todo EXECUTE (@selectCotNu)
	 select * from @todo where idCliente = @idCliente
END
go

