/*
	SEL_REFERENCIA_PERSONA_SP 111035
*/

CREATE PROCEDURE [dbo].[SEL_REFERENCIA_PERSONA_SP]
@idCliente INT = 0
AS
			SELECT DISTINCT REF.idReferencia,REF.fecha,REF.referencia,REF.numeroConsecutivo,REF.tipoReferencia 
				   ,DETREF.documento,d.ucn_total importeDocumento,emp.emp_nombre,suc.suc_nombre,dep.dep_nombre
			FROM referencias.dbo.referencia REF
				
			LEFT JOIN referencias.dbo.detallereferencia DETREF ON REF.idReferencia = DETREF.idReferencia
			inner join cuentasporcobrar.dbo.uni_cotizacionuniversal u on DETREF.documento=u.ucu_foliocotizacion  collate database_default
            inner join  cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES d on u.ucu_idcotizacion=d.ucu_idcotizacion
			LEFT JOIN ControlAplicaciones.[dbo].[cat_empresas] emp ON REF.idEmpresa = emp.emp_idempresa
			LEFT JOIN ControlAplicaciones.[dbo].[cat_sucursales] suc ON DETREF.idSucursal = suc.suc_idsucursal
			LEFT JOIN ControlAplicaciones.[dbo].[cat_departamentos] dep ON DETREF.idDepartamento = dep.dep_iddepartamento
			WHERE DETREF.idCliente = @idCliente

 --SELECT * FROM ControlAplicaciones.[dbo].[cat_empresas] emp_idempresa, emp_nombre
 --SELECT * FROM ControlAplicaciones.[dbo].[cat_sucursales] suc_nombre, suc_idsucursal
 --SELECT * FROM ControlAplicaciones.[dbo].[cat_departamentos] dep_iddepartamento, dep_nombre

	--		DETREF.idSucursal, DETREF.idDepartamento, REF.idEmpresa
			
			--SELECT * FROM referencias.dbo.detallereferencia
			--SELECT * FROM referencias.dbo.referencia	
go

