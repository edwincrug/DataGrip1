


-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 11-09-2019
-- Description: Inserta la respuesta del servicio de referencia
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_TransaccionReferencia] 
	 (	    @idTrans numeric(18,0)
           ,@referencia varchar(100)
           ,@idReferencia numeric(18,0)
           ,@estatus varchar(100)
	)

AS
BEGIN

	BEGIN TRY  --Star TryCatch

			INSERT INTO [dbo].[TransaccionReferencia]
           ([idTrans]
           ,[referencia]
           ,[idReferencia]
           ,[estatus]
           ,[fechaRegistro])
     VALUES
           (@idTrans
           ,@referencia
           ,@idReferencia
           ,@estatus
           ,GETDATE())

	END TRY  
	BEGIN CATCH  
				--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[TransaccionReferencia]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro   

	END CATCH; --End TryCatch



END
go

