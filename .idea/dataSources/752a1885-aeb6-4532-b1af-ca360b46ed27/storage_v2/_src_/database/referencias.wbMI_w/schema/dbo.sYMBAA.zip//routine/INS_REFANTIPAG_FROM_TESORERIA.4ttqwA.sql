
CREATE PROCEDURE [dbo].[INS_REFANTIPAG_FROM_TESORERIA]
@bankTableName varchar(100),
@CurrentBase varchar(50)
AS
BEGIN
	-- Verificar el buen origen de rap_formapago
	INSERT INTO GA_Corporativa.dbo.cxc_refantypag 
	SELECT
		rap_idempresa = R.idEmpresa,
		rap_idsucursal = DR.idSucursal,
		rap_iddepartamento = DR.idDepartamento,
		rap_idpersona = DR.idCliente,
		rap_cobrador = 'MMK',
		rap_moneda = 'PE',
		rap_tipocambio = 1,	
		rap_referencia = '',-- ltrim(B.refAmpliada) COLLATE SQL_Latin1_General_CP1_CI_AS,
		rap_iddocto =  dr.documento,	rap_cotped = '',
		rap_consecutivo = (SELECT top 1 CCP_CONSCARTERA FROM GAAU_UNIVERSIDAD..VIS_CONCAR01 WHERE CCP_VFDOCTO COLLATE Modern_Spanish_CS_AS = DR.documento AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente),
		rap_importe = convert(decimal,b.importe),
		-- rap_formapago = (select top 1 co.CodigoBPRO  from Bancomer b inner join  CodigoIdentificacion co  on co.CodigoBanco = b.codigoLeyenda where SUBSTRING(b.concepto,3,20) =  R.referencia),
		rap_formapago = (select top 1 co.CodigoBPRO  from Bancomer b inner join  CodigoIdentificacion co  on co.CodigoBanco = b.codigoLeyenda),
		rap_numctabanc = SUBSTRING(txtOrigen,5,20),
		rap_fecha = GETDATE(),
		rap_idusuari = (SELECT top 1 usu_idusuario FROM ControlAplicaciones..cat_usuarios WHERE usu_nombreusu = 'GMI'),
		rap_idstatus = '1',
		rap_banco = C.IdBanco_bpro,
		rap_referenciabancaria = R.referencia,
		rap_anno = (SELECT top 1 Vcc_Anno FROM GAAU_UNIVERSIDAD..VIS_CONCAR01 WHERE CCP_VFDOCTO COLLATE Modern_Spanish_CS_AS = DR.documento  AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente) 
	FROM Referencia R 
	INNER JOIN BANCOMER B ON R.Referencia = b.referencia
	INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa 
	INNER JOIN Rel_BancoCobro C ON R.idEmpresa = C.emp_idempresa 
	INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
	WHERE B.estatus = 1 
		AND DR.idTipoDocumento = 1
		AND C.IdBanco = 1
		AND tipoReferencia in ( 3,4)
END
go

