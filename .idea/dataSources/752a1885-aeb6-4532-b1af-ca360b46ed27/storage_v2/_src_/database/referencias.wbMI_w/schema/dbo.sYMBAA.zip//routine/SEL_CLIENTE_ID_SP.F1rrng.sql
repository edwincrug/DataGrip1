-- =============================================
-- Author:     
-- Create date: 21/07/2016
-- Description: Busqueda de clientes por ID
-- =============================================
--EXECUTE [SEL_CLIENTE_ID_SP] 1755 --'HEHJ520304R36'  --'javier.hernandezr@grupoandrade.com.mx' --'JAVIER HERNANDEZ'
CREATE PROCEDURE [dbo].[SEL_CLIENTE_ID_SP] 
    @idBusqueda  int = 0 --varchar(150) = null
AS
BEGIN
    SET NOCOUNT ON;
		
	   SELECT C.[per_idpersona]    AS idCliente
              ,C.[per_rfc]          AS rfc 
              ,C.[per_paterno]      AS paterno
              ,C.[per_materno]      AS materno
              ,RTRIM(LTRIM(C.[per_nomrazon]  + ' ' + C.[per_paterno] + ' ' + C.[per_materno])) AS nombre
              ,RTRIM(LTRIM(C.[per_nomrazon]  + ' ' + C.[per_paterno] + ' ' + C.[per_materno])) AS nombreCliente  --Contrato
              ,C.[per_curp]         AS curp
              ,D.[dir_calle]        AS calle
              ,D.[dir_numeroext]    AS numero
              ,D.[dir_colonia]      AS colonia
              ,D.[dir_municipio]    AS delegacion
              ,D.[dir_codigopostal] AS codigoPostal
              ,M.[cor_dircorreo]    AS email
              ,ISNULL (T.[tel_numero], 55555555)  AS telefono
              ,C.[per_status]      AS estatus
              ,ISNULL (T.[tel_numero], 55555555)  AS telefonoCelular
          FROM GA_Corporativa.dbo.PER_PERSONAS AS C
               INNER JOIN [BDPersonas].[dbo].[per_relacionroles] AS R ON C.[per_idpersona] = R.[per_idpersona] AND R.[rol_idrol] = 5 
               LEFT JOIN [BDPersonas].[dbo].[per_direcciones] AS D ON  R.[per_idpersona] = D.[per_idpersona] 
               LEFT JOIN [BDPersonas].[dbo].[per_correos] AS M ON D.[per_idpersona] = M.[per_idpersona] 
               LEFT JOIN [BDPersonas].[dbo].[per_telefonos] AS T ON M.[per_idpersona] = T.[per_idpersona]
         WHERE C.[per_idpersona] = CAST(@idBusqueda AS INT) 
END
go

