/*
EXECUTE [SEL_TOTAL_COTIZACIONES_FILTROS_SP]
	@idCliente		= 111035
	,@idEmpresaP	= 0
	,@idSucursalP	= 0
	,@idDeptoP		= -1
	,@fechaIniP		= ''
	,@fechaFinP		= ''
	,@documento		= ''

*/
CREATE PROCEDURE [dbo].[SEL_TOTAL_COTIZACIONES_FILTROS_SP]
	@idCliente		INT = 0,
	@idEmpresaP		INT = 0,
	@idSucursalP	INT = 0,
	@idDeptoP		INT = -1,
	@fechaIniP		VARCHAR(10) = '',
	@fechaFinP		VARCHAR(10) = '',
	@documento		VARCHAR(20) = ''
AS
	BEGIN
		SET NOCOUNT ON;
			---------------------------------------------------------------
			--Declaracion de variables
			---------------------------------------------------------------
			DECLARE @sIpaux							VARCHAR(100) = '';
			DECLARE @aux							INT = 1
			DECLARE @max							INT = 0
			DECLARE @nomBase						NVARCHAR(50) = NULL
			DECLARE	@idSucursal						NVARCHAR(50) = NULL
			DECLARE	@nombreSucursal					NVARCHAR(50) = NULL
			DECLARE @nombreEmpresa					NVARCHAR(50) = NULL
			DECLARE	@idEmpresa						NVARCHAR(50) = NULL
			DECLARE @ipServidor						NVARCHAR(50)
			DECLARE @query							VARCHAR(max);
			DECLARE @idDepartamentoRE				INT 
			DECLARE	@nombreDeparRE					NVARCHAR(30)
			DECLARE @idDepartamentoSE				INT 
			DECLARE @nombreDeparSE					NVARCHAR(30)
			
			--Variables tabla
			DECLARE @Bases TABLE ( IDB INT IDENTITY(1,1)
								   ,idSucursal nvarchar(30)
								   ,idEmpresa nvarchar(30)
								   ,nombreEmpresa nvarchar(100)
								   ,nomCtoEmpresa nvarchar(5)
								   ,nomBase  nvarchar(50)
								   ,nomBaseSucursal  nvarchar(50)
								   ,ipServidor nvarchar(200)
								  )
			DECLARE @cotizaciones TABLE (	IDB INT IDENTITY(1,1)
											,idDocumento  nvarchar(MAX)
											,idEmpresa nvarchar(30)
											,nombreEmpresa nvarchar(MAX)
											,idSucursal nvarchar(30)
											,nombreSucursal nvarchar(MAX)
											,idDepartamento  nvarchar(30)
											,nombreDepartamento nvarchar(MAX)
											,saldo nvarchar(max)
											,tipoDocumento nvarchar(30)
											,nombreCliente     nvarchar(MAX)
											,fecha  nvarchar(30)
											,idCliente  nvarchar(30)
											,estatus nvarchar(30)
											,referencia nvarchar(max)
										)
			---------------------------------------------------------------
			--Cambio Variables
			---------------------------------------------------------------
			IF(@idEmpresaP = 0)
				SET @idEmpresaP = NULL
			IF(@idSucursalP = 0)
				SET @idSucursalP = NULL
			IF(@idDeptoP = -1)
				SET @idDeptoP = NULL
			IF(@fechaIniP = '')
				SET @fechaIniP = '20000101'
			IF(@fechaFinP = '') 
				SET @fechaFinP = CONVERT(VARCHAR(8),GETDATE(),112)
			---------------------------------------------------------------
			--Obtiene IP Servidor
			---------------------------------------------------------------
			SELECT	@sIpaux= local_net_address
			FROM	sys.dm_exec_connections c
			WHERE	c.session_id = @@SPID
			--SELECT @sIpaux
			---------------------------------------------------------------
			INSERT INTO @Bases
			SELECT	sucursales.suc_idsucursal
					,EMP.emp_idempresa
					,EMP.emp_nombre
					,EMP.emp_nombrecto
					,BASEMP.nombre_base
					,BASEMP.nombre_sucursal
					,(CASE	WHEN BASEMP.ip_servidor =  @sIpaux THEN '[' + BASEMP.nombre_base + '].[dbo].'
							ELSE '[' + BASEMP.ip_servidor + '].[' + BASEMP.nombre_base + '].[dbo].' END) 
			FROM	Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP   
					INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
					INNER JOIN  [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on  BASEMP.suc_idsucursal=sucursales.suc_idsucursal
			WHERE	BASEMP.estatus = 1 AND BASEMP.tipo = 1 
					AND BASEMP.emp_idempresa = COALESCE(@idEmpresaP,BASEMP.emp_idempresa)
					AND BASEMP.suc_idsucursal = COALESCE(@idSucursalP,BASEMP.suc_idsucursal)
			ORDER BY sucursales.suc_idsucursal
			--SELECT * FROM @Bases
			---------------------------------------------------------------
			--
			---------------------------------------------------------------
			 SET @max = (SELECT MAX(IDB) FROM @Bases)
			 WHILE(@aux <= @max)
				BEGIN
					SELECT	@idEmpresa = DB.idEmpresa
							,@nomBase  = DB.nomBase
							,@idSucursal = DB.idSucursal
							,@nombreSucursal = DB.nomBaseSucursal
							,@nombreEmpresa = DB.nombreEmpresa
							,@ipServidor = DB.ipServidor
					FROM	@Bases AS DB 
					WHERE	DB.IDB = @aux 
					SET @aux = @aux + 1
					--SELECT @idEmpresa, @nomBase , @idSucursal, @nombreSucursal, @nombreEmpresa, @ipServidor
					----------------------------------------------------------------------------
					SELECT	@idDepartamentoRE = dep_iddepartamento
							,@nombreDeparRE = dep_nombre 
					FROM	[ControlAplicaciones].[dbo].[cat_departamentos] 
					WHERE	emp_idempresa = @idEmpresa  
							AND suc_idsucursal = @idSucursal 
							AND dep_nombrecto = 'RE' AND dep_iddepartamento = COALESCE(@idDeptoP,dep_iddepartamento) 
					--SELECT @idDepartamentoRE,@nombreDeparRE
					-------------------------------------------------------------------------------------------
					-------------------------------------------------------------------------------------------
					SET @query =	'SELECT ' + char(13) + 
									'cotizacion.ucu_foliocotizacion AS idDocumento' + char(13) + 
									',cotizacion.ucu_idempresa AS idEmpresa' + char(13) +  
									',empresas.emp_nombre as nombreEmpresa' + char(13) +
									',cotizacion.ucu_idsucursal AS idSucursal' + char(13) + 
									',sucursales.suc_nombre AS nombreSucursal' + char(13) + 
									',cotizacion.ucu_iddepartamento AS idDepartamento' + char(13) + 
									',(select [referencias].[dbo].[nombresSucursal](cotizacion.ucu_iddepartamento )) as idDepartamento'+ char(13) + 
									',CU.ucn_total as saldo' + char(13) + ''+ 
									',2 as idTipoDocumento'+
									',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
									',convert(date, cotizacion.ucu_fechacotiza,113)AS fechaDocumento' + char(13) +
									',cotizacion.ucu_idcliente as idCliente' + char(13) + 
									',null as estatus' + char(13) + 
									',REF.referencia' + char(13) + 
									'FROM cuentasporcobrar.dbo.uni_cotizacionuniversal cotizacion  ' + char(13) + 
									'INNER JOIN cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES AS CU ON cotizacion.ucu_idcotizacion = CU.ucu_idcotizacion' + char(13) +
									'INNER JOIN GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = cotizacion.ucu_idcliente' + char(13) + 
									'INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = cotizacion.ucu_idempresa' + char(13) + 
									'INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = cotizacion.ucu_idsucursal' + char(13) + 
									'LEFT JOIN [referencias].[dbo].[DetalleReferencia] DTR ON DTR.documento=cotizacion.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS ' + char(13) + 
									'LEFT JOIN  [referencias].[dbo].[Referencia]  REF ON REF.idReferencia=DTR.idReferencia' + char(13) + 
									'WHERE ucu_estatus != 14 AND ucu_estatus != 20'+ 
									'AND empresas.emp_idempresa = ' + CONVERT(VARCHAR(10),@idEmpresa) + ' ' +
									'AND sucursales.suc_idsucursal = ' + CONVERT(VARCHAR(10),@idSucursal) 
					IF(@idDeptoP IS NOT NULL)
						SET @query = @query + 'AND cotizacion.ucu_iddepartamento = '+CONVERT(VARCHAR(10),@idDeptoP)+''  
					IF(@documento <> '')
						SET @query = @query +  ' AND cotizacion.ucu_foliocotizacion LIKE  ''%' + @documento + '%'' '
			
					IF(@idCliente <> 0)	 
						SET @query = @query +  ' AND cotizacion.ucu_idcliente = ' + CONVERT(VARCHAR(10),@idCliente)

                    PRINT '************************************************************************************************'
					PRINT 'Empieza COTIZACIONES'
					PRINT(@query)
					INSERT INTO @cotizaciones
					EXECUTE(@query)
		
				END



			SELECT	IDB, idDocumento , idEmpresa, nombreEmpresa, idSucursal, nombreSucursal, idDepartamento , nombreDepartamento, saldo, tipoDocumento, nombreCliente    , fecha , idCliente , estatus, referencia
			  FROM	@cotizaciones
			 WHERE	CONVERT(DATE,REPLACE(fecha,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
			
		SET NOCOUNT OFF
	END
go

