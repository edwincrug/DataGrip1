-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03/07/2017
-- execute [SEL_CUENTA_BANCO_REFERENCIA_SP] 7
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CUENTA_BANCO_REFERENCIA_SP]  
	@idEmpresa int
AS
BEGIN
	SET NOCOUNT ON;

	--select BC.idBanco, BC.numeroCuenta cuenta, BC.convenio 
	--  from BancoCuenta BC
	--       inner join dbo.Banco B on B.idBanco = BC.idBanco
	-- where BC.idEmpresa = @idEmpresa  
	--   and B.activo = 1 and tipoCuenta = '1' 
	--   and BC.convenio <> '0' 
	-- order by BC.idBanco asc
		SELECT BC.idBanco
	      ,BC.numeroCuenta cuenta
		  ,BC.convenio
	      ,B.nombre                    
		  ,CASE WHEN (BC.idBanco = 1)
		        THEN 'http://192.168.20.92//GA_Centralizacion//CuentasXPagar//LogoBancos//Bancomer.png'
		        WHEN (BC.idBanco = 2)
		        THEN '\images\banamex_logo.jpg'   --http://192.168.20.92//GA_Centralizacion//CuentasXPagar//LogoBancos//Banamex.png'
				WHEN (BC.idBanco = 3)
		        THEN '\images\santander_logo.jpg' --http://192.168.20.92//GA_Centralizacion//CuentasXPagar//LogoBancos//Santander.png
            ELSE ''
           END AS rutaLogo
		   --,B.urlLogo  AS rutaLogo   
	  FROM BancoCuenta BC
	       INNER JOIN dbo.Banco B on B.idBanco = BC.idBanco
	 WHERE BC.idEmpresa = @idEmpresa  
	   AND B.activo = 1  
	   AND BC.activo = 1
	   AND tipoCuenta = '1' 
	   AND BC.convenio <> '0'    
	   AND BC.tipoPago = 1	--ADD DVR
	 ORDER BY BC.idBanco ASC
END
go

