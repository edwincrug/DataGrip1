

-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 07-10-2020
-- Description: Inserta las respuestas de pagos Avanzados Flap
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PagoRespuesta2] 
	 (					
		    @idTrans numeric(18,0)= 0
           ,@numeroAutorizacion varchar(10)= NULL
           ,@mensaje varchar(300)= NULL
           ,@codigoRespuesta varchar(10)= NULL
           ,@mp_signature nvarchar(max)= NULL
           ,@cli_signature nvarchar(max)= NULL
           ,@mp_reference varchar(100)= NULL
           ,@mp_account nvarchar(50)= NULL
           ,@mp_node nvarchar(50)= NULL
           ,@mp_amount decimal(18,2)= NULL
           ,@mp_currency nvarchar(10)= NULL
           ,@mp_cardType nvarchar(10)= NULL
           ,@mp_paymentMethod nvarchar(50)= NULL
           ,@mp_paymentMethodCode nvarchar(50)= NULL
           ,@mp_bankcode nvarchar(25)= NULL
           ,@mp_bankname nvarchar(100)= NULL
           ,@mp_pan nvarchar(max)= NULL
           ,@mp_customername nvarchar(50)= NULL
           ,@mp_saleid nvarchar(50)= NULL
           ,@mp_sale_historyid nvarchar(50)= NULL
           ,@mp_trx_historyid nvarchar(50)= NULL
           ,@mp_folio nvarchar(50)= NULL
           ,@mp_cardholdername nvarchar(150)= NULL
           ,@mp_authorization_mp1 nvarchar(150)= NULL
           ,@mp_phone nvarchar(50)= NULL
           ,@mp_email nvarchar(150)= NULL
           ,@mp_promo_msi nvarchar(50)= NULL
           ,@mp_promo nvarchar(50)= NULL
           ,@mp_promo_msi_bank nvarchar(50)= NULL
           ,@mp_securepayment nvarchar(50)= NULL
           ,@mp_platform nvarchar(50)= NULL
           ,@mp_contract nvarchar(50)= NULL
           ,@mp_cieinter_clabe nvarchar(50)= NULL
           ,@mp_commerceName nvarchar(50)= NULL
           ,@mp_commerceNameLegal nvarchar(50)= NULL
           ,@mp_cieinter_reference nvarchar(50)= NULL
           ,@mp_cieinter_concept nvarchar(50)= NULL
           ,@mp_sbtoken nvarchar(50)= NULL
           ,@mp_v2view nvarchar(50)= NULL
           ,@mp_date nvarchar(100)= NULL
           ,@estatus bit= NULL
	 
	)

AS
BEGIN

		BEGIN TRY  --Star TryCatch

		--Guardando Log
		INSERT INTO [dbo].[PagoRespuesta2]
           ([idTrans]
           ,[numeroAutorizacion]
           ,[mensaje]
           ,[codigoRespuesta]
           ,[mp_signature]
           ,[cli_signature]
           ,[mp_reference]
           ,[mp_account]
           ,[mp_node]
           ,[mp_amount]
           ,[mp_currency]
           ,[mp_cardType]
           ,[mp_paymentMethod]
           ,[mp_paymentMethodCode]
           ,[mp_bankcode]
           ,[mp_bankname]
           ,[mp_pan]
           ,[mp_customername]
           ,[mp_saleid]
           ,[mp_sale_historyid]
           ,[mp_trx_historyid]
           ,[mp_folio]
           ,[mp_cardholdername]
           ,[mp_authorization_mp1]
           ,[mp_phone]
           ,[mp_email]
           ,[mp_promo_msi]
           ,[mp_promo]
           ,[mp_promo_msi_bank]
           ,[mp_securepayment]
           ,[mp_platform]
           ,[mp_contract]
           ,[mp_cieinter_clabe]
           ,[mp_commerceName]
           ,[mp_commerceNameLegal]
           ,[mp_cieinter_reference]
           ,[mp_cieinter_concept]
           ,[mp_sbtoken]
           ,[mp_v2view]
           ,[mp_date]
           ,[estatus]
           ,[fechaRegistro])
     VALUES
           (
		    @idTrans
           ,@numeroAutorizacion
           ,@mensaje
           ,@codigoRespuesta
           ,@mp_signature
           ,@cli_signature
           ,@mp_reference
           ,@mp_account
           ,@mp_node
           ,@mp_amount
           ,@mp_currency
           ,@mp_cardType
           ,@mp_paymentMethod
           ,@mp_paymentMethodCode
           ,@mp_bankcode
           ,@mp_bankname
           ,@mp_pan
           ,@mp_customername
           ,@mp_saleid
           ,@mp_sale_historyid
           ,@mp_trx_historyid
           ,@mp_folio
           ,@mp_cardholdername
           ,@mp_authorization_mp1
           ,@mp_phone
           ,@mp_email
           ,@mp_promo_msi
           ,@mp_promo
           ,@mp_promo_msi_bank
           ,@mp_securepayment
           ,@mp_platform
           ,@mp_contract
           ,@mp_cieinter_clabe
           ,@mp_commerceName
           ,@mp_commerceNameLegal
           ,@mp_cieinter_reference
           ,@mp_cieinter_concept
           ,@mp_sbtoken
           ,@mp_v2view
           ,@mp_date
           ,@estatus
		   ,GETDATE()
		   )

--Actualizando Pago Respuesta
EXEC [referencias].[dbo].[SP_INS_PagoRespuesta] 
														 @idTrans = @idTrans
														,@numeroAutorizacion = @numeroAutorizacion
														,@mensaje = @mensaje
														,@codigoRespuesta = @codigoRespuesta
														,@mp_signature = @mp_signature
														,@cli_signature = @cli_signature
														,@mp_reference = @mp_reference
														,@mp_amount = @mp_amount
														,@estatus = @estatus
														,@mp_cardType =@mp_cardType
														,@mp_paymentMethod =@mp_paymentMethod
														,@mp_bankcode =@mp_bankcode
														,@mp_bankname =@mp_bankname
														,@mp_pan =@mp_pan








		END TRY  
		BEGIN CATCH  
			--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[PagoRespuesta]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro 

		END CATCH; --End TryCatch

END
go

