



-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 30-09-2019
-- Description: Actualiza el estatus la Transaccion
-- =============================================
CREATE PROCEDURE [dbo].[SP_UPD_Transaccion] 
	 (	    @idTrans numeric(18,0)
           ,@idEstatus int
	)

AS
BEGIN
	BEGIN TRY  --Estar TryCatch

		UPDATE [dbo].[Transaccion]
			SET [idEstatus] = @idEstatus
				,[fechaRegistro] = GETDATE()
		   WHERE idTrans=@idTrans


	END TRY  
	BEGIN CATCH  
		--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[Transaccion]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro

	END CATCH; --End TryCatch


END
go

