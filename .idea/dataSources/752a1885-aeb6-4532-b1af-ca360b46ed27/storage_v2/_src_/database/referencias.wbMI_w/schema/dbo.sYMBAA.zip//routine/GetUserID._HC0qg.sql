-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetUserID](@DocTypeID int)
RETURNS varchar(100)
AS
BEGIN

	--catalogo de tipos de documentos select * from tipodocumento
	declare @result varchar(100)


	-----------------------------factura----------------------------------------------------------------------------------------------------
		
	if(@DocTypeID = 1 )  
	begin

		SELECT @result = usu_idusuario 
		FROM ControlAplicaciones..cat_usuarios 
		WHERE usu_nombreusu = 'CEL' 
		
		return @result
	end

	
	-----------------------------Cotización-----------------------------------------------------------------------------------------------------
	if(@DocTypeID = 2 )  
	begin
	
		SELECT @result = usu_idusuario 
		FROM ControlAplicaciones..cat_usuarios 
		WHERE usu_nombreusu = 'CEL' 
		
		return @result
	end

	
	-----------------------------Pedido-----------------------------------------------------------------------------------------------------
	if(@DocTypeID = 3 ) 
	begin
		
		SELECT @result = usu_idusuario 
		FROM ControlAplicaciones..cat_usuarios 
		WHERE usu_nombreusu = 'CEL' 
		
		return @result
	end


	
	-----------------------------Presupuesto-----------------------------------------------------------------------------------------------------
	if(@DocTypeID = 4 ) 
	begin
		SELECT @result = usu_idusuario 
		FROM ControlAplicaciones..cat_usuarios 
		WHERE usu_nombreusu = 'CEL' 
		
		return @result
	end
	
	-----------------------------Orden de Servicio----------------------------------------------------------------------------------------------
	if(@DocTypeID = 5 ) 
	begin
		SELECT @result = usu_idusuario 
		FROM ControlAplicaciones..cat_usuarios 
		WHERE usu_nombreusu = 'CEL' 
		
		return @result
	end


	return ''
	

END

go

