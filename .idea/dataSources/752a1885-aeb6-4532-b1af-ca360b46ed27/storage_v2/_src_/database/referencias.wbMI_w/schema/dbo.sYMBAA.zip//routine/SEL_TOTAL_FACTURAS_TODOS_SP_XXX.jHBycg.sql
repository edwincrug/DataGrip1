-- ==========================================================================================
-- Author:     
-- Create date: 
-- Description: Detalle de todos las COTIZACIONES|REFACCIONES|  
--				Filtrando por cliente.	 
--              Para hacer diferencia entre empresas es cambiando el nombre de la base
--				falta buscar por empresa, sucursal y departamento
-- ==========================================================================================
--  [SEL_TOTAL_FACTURAS_TODOS_SP]    @idCliente = 19590  
-- 45764   51112  173578 , @idEmpresas = 4    74990     @idempresa, idsucursal, idDepartamento  --  --40078 --11 --40078        
CREATE PROCEDURE [dbo].[SEL_TOTAL_FACTURAS_TODOS_SP_XXX] 
      @idCliente     INT = 0
	  --,@idEmpresas    int = 0
	  ,--LQMA 11092017 add parametros filtros
	  @idEmpresaP INT = 0,
	  @idSucursalP INT = 0,
	  @idDeptoP INT = 0,
	  @fechaIniP VARCHAR(10) = '',
	  @fechaFinP VARCHAR(10) = '',
	  @documento VARCHAR(20) = ''
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @aux               INT = 1
    DECLARE @max               INT = 0
    DECLARE @idEmpresaBusca    INT = 0
    DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
    DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @select         VARCHAR(max);
	DECLARE @selectPreCot         VARCHAR(max);
	DECLARE @selectCotNu         VARCHAR(max);
	DECLARE @selectCotSE         VARCHAR(max);
	DECLARE @selectPeOr        VARCHAR(max);
	DECLARE	@idSucursal		NVARCHAR(50) =NULL
	DECLARE	@nombreSucursal NVARCHAR(50) =NULL
	DECLARE @nombreEmpresa  NVARCHAR(50) =NULL
	DECLARE	@idEmpresa	NVARCHAR(50) =NULL
	DECLARE @ipServidor NVARCHAR(50)
	DECLARE @cadIpServidor VARCHAR(100);
	DECLARE @sIpaux         VARCHAR(100) = ''  --1) LMS 28/08/2018

	----------------------------------------------------------------
	-- OBTENGO LA IP LOCAL                     --2) LMS 28/08/2018
	----------------------------------------------------------------
	SELECT @sIpaux= local_net_address
	  FROM sys.dm_exec_connections c
	 WHERE c.session_id = @@SPID

	--LQMA add 13092017
	IF(@fechaIniP = '')
	   SET @fechaIniP = '20000101'
	IF(@fechaFinP = '') 
	   SET @fechaFinP = CONVERT(VARCHAR(8),GETDATE(),112)
    
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
							idSucursal nvarchar(30),
                            idEmpresa         nvarchar(30)
                            ,nombreEmpresa     nvarchar(100)
                            ,nomCtoEmpresa     nvarchar(5)
                            ,nomBaseConcentra  nvarchar(50)
							,nomBaseSucursal  nvarchar(50)
                            ,nomBaseMatriz     nvarchar(50)
                            ,ipServidor        nvarchar(20)
                            )

-- SE HACE LA BUSQUEDA DE LAS EMPRESAS Y SUCURSALES DISPONIBLES CON EL NOMBRE Y DIRECCIÓN IP DONDE SE ENCUENTRAN
     INSERT INTO @Bases
	   	SELECT 
				sucursales.suc_idsucursal
				,EMP.emp_idempresa
                ,EMP.emp_nombre
                ,EMP.emp_nombrecto
                ,BASEMP.nombre_base
				,BASEMP.nombre_sucursal
				--,BASEMP.
                ,ISNULL(BASEMP.nombre_base_matriz,BASEMP.nombre_base)
                ,BASEMP.ip_servidor 
           FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
                INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				inner join [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
          WHERE  BASEMP.estatus = 1 AND BASEMP.tipo = 1 
				 --LQMA add 12092017		  
				 --and sucursales.emp_idempresa= EMP.emp_idempresa
				 AND ((sucursales.emp_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
				 AND ((sucursales.suc_idsucursal = @idSucursalP) OR (@idSucursalP = 0))  
				 AND BASEMP.nombre_sucursal != 'CRA Guadalajara' AND BASEMP.nombre_sucursal !='CRA Cuautitlan'
       ORDER BY sucursales.suc_idsucursal
     
     SET @max = (SELECT MAX(IDB) FROM @Bases)
     WHILE(@aux <= @max)
     BEGIN
         
         SELECT  @idEmpresaBusca   = DB.idEmpresa 
				,@idEmpresa = DB.idEmpresa
                ,@nomBaseConcentra = DB.nomBaseConcentra
                ,@nomBaseMatriz    = DB.nomBaseMatriz
				,@idSucursal = DB.idSucursal
				,@nombreSucursal = DB.nomBaseSucursal
				,@nombreEmpresa = DB.nombreEmpresa
				,@ipServidor = DB.ipServidor
           FROM @Bases AS DB 
          WHERE DB.IDB = @aux --DB.idEmpresa = @aux 
          --EXECUTE [SEL_PRESUPUESTO_DETALLE_SP] @idEmpresaBusca

		  
		IF (@ipServidor = @sIpaux)             --3) LMS 28/08/2018
		BEGIN
		set @cadIpServidor =''
		END
		ELSE
		BEGIN
		set @cadIpServidor =' [' + @ipServidor + '].'
		END
		--select @cadIpServidor

	DECLARE @todo TABLE  ( IDB INT IDENTITY(1,1),
                            folio         nvarchar(30)
							,serie nvarchar(20)
							,idDocumento nvarchar(30)
							,idEmpresa nvarchar(30)
							,nombreEmpresa nvarchar(30)
							,idSucursal nvarchar(30)
							,nombreSucursal nvarchar(30)
							,idDepartamento  nvarchar(30)
							,nombreDepartamento nvarchar(30)
							,origenMovimiento nvarchar(30)
							,importe nvarchar(30)
							,saldo nvarchar(30)
                            ,nombreCliente     nvarchar(100)
                            ,fecha  nvarchar(30)
							,idCliente  nvarchar(30)
							,referencia nvarchar(20)
							,tipoDocumento int
                            )
		  -- Refacciones|Cotizaciones dep_nombre
		  SET @select =

				
				'SELECT ' + char(13) + 
					'CCP_IDDOCTO' + char(13) + 
					',(select dbo.[fn_BuscaLetras](CCP_IDDOCTO)) as serie'+
					',(select dbo.[fn_BuscaNumeros](CCP_IDDOCTO)) as folio'+
					',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
					',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) + 
					',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
					',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) +
					',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +' ' + char(13) + 
					'and  dep_nombrecto = ' + char(13) + 
					'(select case when OrigenMovimiento = '+char(39)+'NUEVOS'+char(39)+' THEN '+char(39)+'UN'+char(39)+' ' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'SEMINUEVOS'+char(39)+' THEN '+char(39)+'US'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'REFACCIONES'+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'SERVICIO'+char(39)+' THEN '+char(39)+'SE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'NEGOCIOS'+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'AUDITORIA'+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'ND'+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) +
					'when OrigenMovimiento = '+char(39)+'ADMINISTRACION'+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'HOJALATERIA Y PINTURA'+char(39)+' THEN '+char(39)+'SE'+char(39)+'end)) AS idDepartamento' + char(13) + 
					',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +' ' + char(13) + 
					'and  dep_nombrecto = ' + char(13) + 
					'(select case when OrigenMovimiento = '+char(39)+'NUEVOS'+char(39)+' THEN '+char(39)+'UN'+char(39)+' ' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'SEMINUEVOS'+char(39)+' THEN '+char(39)+'US'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'REFACCIONES'+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'SERVICIO'+char(39)+' THEN '+char(39)+'SE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'ADMINISTRACION'+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'NEGOCIOS'+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'AUDITORIA'+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'ND'+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'HOJALATERIA Y PINTURA '+char(39)+' THEN '+char(39)+'SE'+char(39)+'end)) AS nombreDepa' + char(13) +
					',OrigenMovimiento' + char(13) + 
					',IMPORTE' + char(13) + 
					',SALDO' + char(13) + 
					',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
					',CCP_FECHADOCTO' + char(13) + 
					',CCP_IDPERSONA' + char(13) + 
					',(SELECT referencia FROM [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia 
					WHERE DEREF.documento = CCP_IDDOCTO  COLLATE Modern_Spanish_CI_AS 
					AND REF.idEmpresa ='+@idEmpresa +' AND  DEREF.idSucursal = '+@idSucursal +' AND REF.tipoReferencia = 1) AS referencia'+
					',1 AS idTipoDocumento' + char(13) + 
					'FROM '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[BI_CARTERA_CLIENTES_C] facturas ' + char(13) + 					
					'INNER JOIN GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = facturas.CCP_IDPERSONA ' + char(13) + 
					+' WHERE 1 = 1 '
					--+' WHERE CCP_IDPERSONA='+ cast (@idCliente as varchar(10))
				
				IF(@documento <> '')
					SET @select = @select +  ' AND CCP_IDDOCTO LIKE ''%' + @documento + '%'' '
			
				IF(@idCliente <> 0)	 
					SET @select = @select +  ' AND CCP_IDPERSONA = ' + CONVERT(VARCHAR(10),@idCliente)
				
				print @select
                
				INSERT INTO @todo EXECUTE (@select)        
         SET @aux = @aux + 1
     END   
	 
	 DECLARE @filter VARCHAR(10) = '%|%'
		IF(@idEmpresaP <> 0)
			SET @filter = '%' + CONVERT(VARCHAR(5),@idEmpresaP) + '|%'
		IF(@idSucursalP <> 0)
			SET @filter = '%|' + CONVERT(VARCHAR(5),@idSucursalP) + '%'		
	   
	 SELECT IDB 
			,folio         
			,serie 
			,idDocumento 
			,idEmpresa 
			,nombreEmpresa 
			,idSucursal 
			,nombreSucursal 
			,idDepartamento  
			,nombreDepartamento 
			,origenMovimiento 
			,importe 
			,saldo 
			,nombreCliente     
			,fecha  
			,idCliente  
			,referencia 
			,tipoDocumento FROM @todo 
	 --LQMA 12092017	 
	 WHERE ((idEmpresa = @idEmpresaP) OR (@idEmpresaP = 0))
	 AND ((idSucursal = @idSucursalP) OR (@idSucursalP = 0))	  
	 AND((idDepartamento = @idDeptoP) OR (@idDeptoP = -1))
	 AND CONVERT(DATE,REPLACE(fecha,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
	 AND SUBSTRING(folio,1,2) NOT IN (SELECT cat_valor FROM Centralizacionv2..DIG_CATALOGOS WHERE cat_id_padre = 500 AND cat_nombre LIKE @filter)

	 --SELECT cat_valor FROM Centralizacionv2..DIG_CATALOGOS WHERE cat_id_padre = 500 AND cat_nombre LIKE @filter

END



go

