



-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 30-09-2019
-- Description: Inserta los pagos ya sean Pin Pad o Web
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_Pago] 
	 (	 @idOrigen int
		,@idTrans numeric(18,0)
		,@idCliente numeric(18,0)
		,@referencia varchar(100)
		,@nodo numeric(18,0)
		,@idConcepto int=0
		,@moneda int=0
		,@importe decimal(18,2)
		,@titularTarjeta varchar(50)=NULL
		,@numeroTarjeta nvarchar(300)=NULL
		,@firma varchar(100)=NULL
		,@correo varchar(100)=NULL
		,@telefono varchar(15)=NULL
		,@idComercio int=NULL
		,@idTipoTarjeta int=NULL
		,@idTipoPlan int=NULL
		,@mesesPago int=NULL
		,@accion varchar(20)=NULL
		,@emvTarjeta varchar(100)=NULL
		,@puntos int=NULL
		,@hmac varchar(600)=NULL
		,@Id numeric(18,0) OUTPUT
		,@payMethodtype int = NULL
		,@mp_paymentmethod varchar(100) = NULL
	)

AS
BEGIN

		BEGIN TRY  --Estar TryCatch

			DECLARE @idPag INT = 0
			SET @idPag =  ISNULL( (SELECT idTrans FROM [dbo].[Pago] WHERE idTrans = @idTrans) ,0)

			IF @idPag = 0
			BEGIN

				INSERT INTO [dbo].[Pago]
						     ([idOrigen]
						     ,[idTrans]
						     ,[idCliente]
						     ,[referencia]
						     ,[nodo]
						     ,[idConcepto]
						     ,[moneda]
						     ,[importe]
						     ,[titularTarjeta]
						     ,[numeroTarjeta]
						     ,[firma]
						     ,[correo]
						     ,[telefono]
						     ,[idComercio]
						     ,[idTipoTarjeta]
						     ,[idTipoPlan]
						     ,[mesesPago]
						     ,[accion]
						     ,[emvTarjeta]
						     ,[puntos]
							 ,[hmac]
						     ,[fechaRegistro]
							  ,[cli_payMethodtype]
							 ,[mp_paymentmethod])
    					VALUES
						     (@idOrigen 
							 ,@idTrans
							 ,@idCliente
							 ,@referencia
							 ,@nodo
							 ,@idConcepto
							 ,@moneda
							 ,@importe
							 ,@titularTarjeta
							 ,@numeroTarjeta
							 ,@firma
							 ,@correo
							 ,@telefono
							 ,@idComercio
							 ,@idTipoTarjeta
							 ,@idTipoPlan
							 ,@mesesPago
							 ,@accion
							 ,@emvTarjeta
							 ,@puntos
							 ,@hmac
						     ,GETDATE()
							 ,@payMethodtype 
							 ,@mp_paymentmethod)

							 --SELECT @outId= @@ROWCOUNT
				--SELECT @Id = @@IDENTITY

				SET @Id = @@IDENTITY;
				SELECT @Id AS Id;

				END
				ELSE
				BEGIN
					
					SELECT @idPag AS Id

				END

		END TRY  
		BEGIN CATCH  
			--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[Pago]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro

		END CATCH; --End TryCatch

END
go

