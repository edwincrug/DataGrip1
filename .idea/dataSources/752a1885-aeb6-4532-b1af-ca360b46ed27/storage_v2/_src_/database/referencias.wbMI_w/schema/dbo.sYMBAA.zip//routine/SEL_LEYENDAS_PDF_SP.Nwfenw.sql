/****** Script for SelectTopNRows command from SSMS  ******/
CREATE PROCEDURE [dbo].[SEL_LEYENDAS_PDF_SP] 
@idEmpresa INT = 0,
@tipoReferencia int = 0

AS
BEGIN
	if @tipoReferencia = 1
		BEGIN
			SELECT  
				idEmpresa
				,[descripcion]
				,orden
			FROM [referencias].[dbo].[Leyenda] 
				WHERE idEmpresa = @idEmpresa AND tipoReferencia = 1  order by orden asc
		END
	ELSE
		BEGIN
			SELECT  
				idEmpresa
				,[descripcion]
				,orden
			FROM [referencias].[dbo].[Leyenda] 
				WHERE idEmpresa = @idEmpresa AND tipoReferencia = 2 order by orden asc
		END

ENd



go

