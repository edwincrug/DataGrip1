-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PROCESO_LOGERROR]
	@tipoError VARCHAR(1500),
	@error VARCHAR(MAX)
AS
BEGIN
	BEGIN TRY
		IF(LEN(@error) > 8000)
			BEGIN
				INSERT INTO ProcesosLogError (dateError, tipoError,	error)
				VALUES (GETDATE(), @tipoError, SUBSTRING(@error, 0, 7999) )
			END
		ELSE
			BEGIN
				INSERT INTO ProcesosLogError (dateError, tipoError,	error)
				VALUES (GETDATE(), @tipoError, @error)
			END
				
		SELECT success = 1;
	END TRY

	BEGIN CATCH
		SELECT success = 0;
	END CATCH
	
END

go

