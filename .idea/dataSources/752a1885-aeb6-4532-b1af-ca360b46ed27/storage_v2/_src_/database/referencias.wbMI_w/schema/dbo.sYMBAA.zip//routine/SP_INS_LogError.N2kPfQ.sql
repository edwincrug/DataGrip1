

-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 11-09-2019
-- Description: Inserta los errores del proceso de pagos
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_LogError] 
	 (	   @Servicio varchar(100)=NULL,
           @Metodo varchar(100)=NULL,          
           @Error_Descripcion varchar(500) =NULL,
           @Error_Pila varchar(max)=NULL
	)

AS
BEGIN

	BEGIN TRY  --Estar TryCatch

			INSERT INTO [dbo].[LogError]
			   (
				[Servicio]
			   ,[Metodo]
			   ,[Error_Descripcion]
			   ,[Error_Pila]
			   ,[FechaRegistro])
		 VALUES
			   (
				@Servicio
			   ,@Metodo
			   ,@Error_Descripcion
			   ,@Error_Pila
			   ,GETDATE()
			   )

	END TRY  
	BEGIN CATCH  
		SELECT  ERROR_NUMBER() AS ErrorNumber
				,ERROR_SEVERITY() AS ErrorSeverity  
				,ERROR_STATE() AS ErrorState  
				,ERROR_PROCEDURE() AS ErrorProcedure  
				,ERROR_LINE() AS ErrorLine  
				,ERROR_MESSAGE() AS ErrorMessage;  

	END CATCH; --End TryCatch



END
go

