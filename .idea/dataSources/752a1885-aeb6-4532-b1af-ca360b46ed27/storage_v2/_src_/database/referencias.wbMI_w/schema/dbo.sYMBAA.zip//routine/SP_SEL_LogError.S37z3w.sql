

-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 11-09-2019
-- Description:	Lista tabla de errores
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_LogError]

AS
BEGIN

BEGIN TRY  --Estar TryCatch
		SELECT * FROM dbo.LogError;
END TRY  
BEGIN CATCH  
    SELECT  
        ERROR_NUMBER() AS ErrorNumber  
        ,ERROR_SEVERITY() AS ErrorSeverity  
        ,ERROR_STATE() AS ErrorState  
        ,ERROR_PROCEDURE() AS ErrorProcedure  
        ,ERROR_LINE() AS ErrorLine  
        ,ERROR_MESSAGE() AS ErrorMessage;  
END CATCH; --End TryCatch



	

END
go

