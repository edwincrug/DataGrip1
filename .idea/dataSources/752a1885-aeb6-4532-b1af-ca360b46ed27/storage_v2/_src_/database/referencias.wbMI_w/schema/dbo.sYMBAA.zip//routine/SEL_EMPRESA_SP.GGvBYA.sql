CREATE PROCEDURE [dbo].[SEL_EMPRESA_SP]
	AS
	BEGIN
	select distinct emp_nombre, emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas]
	END
go

