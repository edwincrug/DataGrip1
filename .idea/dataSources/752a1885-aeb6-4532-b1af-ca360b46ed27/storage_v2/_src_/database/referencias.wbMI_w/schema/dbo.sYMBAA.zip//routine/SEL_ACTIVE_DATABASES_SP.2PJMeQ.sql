



CREATE PROCEDURE [dbo].[SEL_ACTIVE_DATABASES_SP]

AS
BEGIN

	DECLARE @tableConf  TABLE
	(
		idEmpresa  INT,
		idSucursal INT,
		servidor   VARCHAR(250),
		baseConcentra   VARCHAR(250),
		sqlCmd VARCHAR(8000),
		cargaDiaria VARCHAR(8000)
	)

	INSERT INTO @tableConf
	SELECT  BP. emp_idempresa AS idEmpresa,
			BP.suc_idsucursal AS idSucursal,				
			
			'['+ BP.ip_servidor +'].' +'['+ BP.nombre_base+'].'+'[dbo]' AS servidor	,
			(SELECT '['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]'															
			FROM    [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
			WHERE   emp_idempresa = BP.emp_idempresa and tipo=2) AS baseConcentra,
			
			'Vacio', 'Vacio'
			/*
			'INS_PRECARGA ' +
			+ CHAR(39) +'['+ BP.ip_servidor +'].' +'['+ BP.nombre_base+'].'+'[dbo]' + CHAR(39) + ','+
			+ CHAR(39) + (SELECT '['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]' FROM    [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = BP.emp_idempresa and tipo=2)  +  CHAR(39) + ','+
			  CONVERT(VARCHAR(5),BP. emp_idempresa) +','+
			  CONVERT(VARCHAR(5),BP.suc_idsucursal) AS sqlcmd,

			'INS_CARGADIARIA ' +
			  CHAR(39) +'['+ BP.nombre_base+'].'+'[dbo].' + CHAR(39) + ','+
			  CONVERT(VARCHAR(5),BP. emp_idempresa) +','+
			  CONVERT(VARCHAR(5),BP.suc_idsucursal) AS sqlcmd
			  */

	FROM    [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] BP,
			[ControlAplicaciones].[dbo].[cat_empresas]    CE
	WHERE   BP.emp_idempresa = CE.emp_idempresa
	AND		BP.estatus=1 
	AND		BP.tipo=1
	AND		BP.suc_idsucursal  IS NOT NULL

	SELECT  * FROM @tableConf;

END
go

