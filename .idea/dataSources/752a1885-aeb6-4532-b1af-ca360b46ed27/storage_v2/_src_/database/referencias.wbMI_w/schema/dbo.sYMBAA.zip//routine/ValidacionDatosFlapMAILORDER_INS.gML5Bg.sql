-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<crea poliza de la tabla [dbo].[datosFlap]>
-- =============================================
-- [dbo].[ValidacionDatosFlapMAILORDER_INS] '17/09/2020'
CREATE PROCEDURE [dbo].[ValidacionDatosFlapMAILORDER_INS]
@fecha date
AS
BEGIN

	--drop table #tempData
	--Declare @fecha date='01/09/2020'
	Declare @serverDB varchar(200) 
	,@ipDB varchar(200) 
	,@idempresa int
	,@idsucursal int
	,@unidadNegocio int
	,@categoriaCobranza int
	,@tipoPago nvarchar(20)
	,@tipo_poliza_traspaso nvarchar(20)
	,@importe decimal(18,2)
	DECLARE @datosflapBP TABLE (
	id int identity,
	idempresa int,
	idsucursal int,
	documento nvarchar(50)
)
	DECLARE @datospolBP TABLE (
	id int identity,
	idempresa int,
	idsucursal int,
	mov_tipopol [nvarchar](50),
	mov_conspol [int],
	mov_debe [decimal](18, 2) ,
	mov_observa nvarchar(50),
	basedatos nvarchar(250)
	
)

	select  ROW_NUMBER() OVER(
			ORDER BY unidadNegocio,categoriaCobranza) AS RowNum,convert(date,fechapago) fechapago,unidadNegocio,categoriaCobranza,idempresa,idsucursal,Replace(tipoPago,'CIE','TDX') tipopago,referenciaConciliacion,SUM(df.IMPORTE) IMPORTE ,cuentabancaria,df.referencia
			into #tempData
			from datosFlap df
			inner join pago p on df.numeroOrden=p.idTrans and df.referencia=p.referencia and p.idOrigen=4
	where  convert(date,fechapago)=@fecha and p.idOrigen = 4--and estatusProcesado=0
	--and unidadNegocio=3
	GROUP BY convert(date,fechapago),unidadNegocio,categoriaCobranza,idempresa,idsucursal,Replace(tipoPago,'CIE','TDX'),referenciaConciliacion,cuentabancaria,df.referencia
	DECLARE @Counter INT ,@CounterMax INT ,@query varchar(max)
	
	select @CounterMax=max(rownum) from #tempData
	SET @Counter=1
	WHILE ( @Counter <= @CounterMax)
	BEGIN
		select @idempresa=idEmpresa,@idsucursal=idSucursal,@unidadNegocio=unidadNegocio,@categoriaCobranza=categoriaCobranza,@importe=importe from #tempdata where rownum=@counter
		select @serverDB=nombre_base,@tipo_poliza_traspaso= tipo_poliza_traspaso from Centralizacionv2..dig_cat_bases_bpro where emp_idempresa=@idempresa and suc_idsucursal=@idsucursal and tipo=1

		SET @query  = 
	('select '+convert(nvarchar(6),@idempresa)+' idempresa,'+convert(nvarchar(6),@idsucursal)+' idsucursal,vde_docto
						from '+@serverDB+'..ADE_VTACFD fac
						inner join DetalleReferencia d on d.documento = fac.VDE_DOCTO collate database_default
						inner join referencia r on d.idReferencia=r.idReferencia
						inner join datosflap df on df.referencia=r.referencia
						inner join pago p on df.numeroOrden=p.idTrans and df.referencia=p.referencia and p.idOrigen=4
						left join '+@serverDB+'..ADE_CANCFD can
							on fac.VDE_DOCTO = can.CDE_DOCTO
						WHERE convert(date,fechapago)='''+convert(nvarchar(10),@fecha,103)+'''')

	print @query
	/*LIMPIO LA TABLA*/
	--DELETE FROM @datosflapBP;
	/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
	insert @datosflapBP
	EXEC( @query)

		SET @query  = 
	('select '+convert(nvarchar(6),@idempresa)+' idempresa,'+convert(nvarchar(6),@idsucursal)+' idsucursal,mov_tipopol,mov_conspol,mov_debe,mov_observa,'''+@serverDB+''' basedatos from '+@serverDB+'.[dbo].CON_MOVDET012020 where MOV_TIPOPOL = '''+@tipo_poliza_traspaso+'''  and mov_mes='+Convert(nvarchar(2),month(@fecha))+' and mov_debe='+convert(nvarchar(21),@importe))
	print @query
	insert @datospolBP
	EXEC( @query)
				

		SET @Counter  = @Counter  + 1
	END
	
	--select * from #tempData
	--select * from @datosflapBP
	--select * from @datospolBP
	--select idempresa,idsucursal,sum(importe) importe from @datosflapBP group by idempresa,idsucursal

	select distinct t.fechapago,t.idempresa,t.idsucursal,unidadNegocio unidadNegocioDF,categoriaCobranza categoriaCobranzaDF,t.importe importeDF,tipopago,cuentaBancaria,
	rap_folio,t.referencia
	,df.documento
	cuentabancaria,documento factura,case when documento is null then 'SinFactura' else 'ConFactura' end comparacionfactura,
	basedatos,mov_tipopol,mov_conspol,mov_debe ,case when t.importe=mov_debe then 'Igual' else 'No igual' end comparacionconmovdet
	
	
	from #tempData t
	left join (select idempresa,idsucursal,documento from @datosflapBP ) df on t.idEmpresa=df.idempresa and t.idSucursal=df.idsucursal
	left join @datospolBP bp on t.idEmpresa=bp.idempresa and t.idSucursal=bp.idsucursal and t.referenciaConciliacion=bp.mov_observa
	left join GA_Corporativa..cxc_refantypag cx on t.referencia=cx.rap_referenciabancaria
	order by t.idEmpresa,t.idSucursal

	
END


--select * from datosFlap d
--inner join Pago p on d.referencia=p.referencia
--where idOrigen=4


--select * from datosFlap d
--where  convert(date,fechapago)='2020-08-28' and unidadNegocio=3 --and categoriaCobranza in(11)
--select sum(d.importe) from datosFlap d
--inner join Pago p on d.referencia=p.referencia
--where unidadNegocio=3  and convert(date,fechapago)='2020-08-28' 
--select * from bancomer where fechaOperacion>='2020-08-20' and refAmpliada like '%multipago%' and noCuenta='000000000195334667' and importe=11704.99
--select * from gaau_concentra.[dbo].CON_MOVDET012020 where MOV_TIPOPOL = 'SALDOINGun'  and mov_mes=9  and MOV_CONSPOL=11


go

