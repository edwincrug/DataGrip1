
-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<Inserta el dpi en bpro>
-- =============================================
--[dbo].[CreaPolizaUNI_INS] 5,4,1,'GMI',71,'HHHH123456GME','1100-0020-001-0018','cafr',23,2,2,2020,1857425,0,'TRANSFERIR INGRESOS DE CAJA/DB000022437/03- Tarjeta de Crédito/BANAMEX6439','asdsdyuyiasdufyiads','12/02/2020','12/02/2020',0
CREATE PROCEDURE [dbo].[CreaPolizaUNI_INS]
			@cuentaBancaria  nvarchar(20)='',
			@importe decimal(18,2),
			@idempresa INT,
			@sucursal INT,
			@fechaPago date,
			@referencia nvarchar(50),
			@unidadNegocio int,
			@categoriaCobranza int,
			@tipopago nvarchar(20),
			@Usuario int
			
		   

AS
	BEGIN
	DECLARE @idbmer INT = 0, 
	@cuentaContableDebe NVARCHAR(20) = '',
	@cuentaContableHaber NVARCHAR(20) = '', 
	@nombrebase NVARCHAR(150), 
	@sql NVARCHAR(max) = '', 
	@ParmDefinition NVARCHAR(max),
	@MOV_IDCLIENTE INT = 0, 
	@rfc NVARCHAR(20) = '', 
	@MOV_MES INT, @anio INT, 
	@MOV_CONSPOL INT, 
	@MOV_CONSPOLOUT NVARCHAR(10) = '', 
	@consecutivocontable INT = 0, 
	@nuevareferencia NVARCHAR(22),
	@idbanco INT,
	@poliza_traspaso nvarchar(10)
	DECLARE @idRegistro int=0
							DECLARE @idUsuario nvarchar(4)='GMI'
							DECLARE @MOV_TIPOPOL nvarchar(10)
							DECLARE @MOV_DEBE decimal(18,5)
							DECLARE @MOV_HABER decimal(18,5)
							DECLARE @MOV_CONSMOV int 
							DECLARE @fechaoper datetime
							DECLARE @mov_fecha datetime
							DECLARE @MOV_CONCEPTO nvarchar(100)
	DECLARE @serie NVARCHAR(2), @idTipoReferencia INT = 1, @folio NVARCHAR(4)
	DECLARE @MaxIdInt INT = 0, @CounterInt INT = 1, @id_registro INT,  @MOV_CONCEPTOOUT NVARCHAR(250) = '';
				PRINT 'Paso 2 si existe'

				SELECT @anio = YEAR(GETDATE()), @mov_mes= MONTH(GETDATE())

				SELECT 
					@idbmer = idbmer, 
					@idbanco = IDBanco 
				FROM Bancomer WHERE noCuenta = @cuentaBancaria AND importe = @importe AND refampliada LIKE '%Multipagos%'

				SELECT 
					@cuentaContableDebe = cuentaContable 
				FROM BancoCuenta WHERE numeroCuenta = @cuentaBancaria
 
				-- select *  from BancoCuenta b where b.numeroCuenta=@cuentaBancaria

 
				SELECT 
					@nombrebase = nombre_base 
				FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
				WHERE emp_idempresa = @idempresa AND tipo = 2

				SELECT 
					@consecutivocontable = consecutivo_contable ,@poliza_traspaso = tipo_poliza_traspaso
				FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
				WHERE emp_idempresa = @idempresa AND suc_idsucursal = @sucursal

			if len(@poliza_traspaso)>5
			begin
					--  select @idbanco,@idbmer,@cuentaBancaria,@MOV_IDCLIENTE
				SET @cuentaContableHaber = '1100-0010-000' + CONVERT(NVARCHAR(1), @consecutivocontable) + '-0001'

				set @serie  = RIGHT('0' + CONVERT(NVARCHAR(4), FLOOR(RAND()*(99-0+1))),2)
				set @idTipoReferencia = 1
				set @folio = RIGHT('000' + CONVERT(NVARCHAR(4), FLOOR(RAND()*(9999-0+1))),4)

				SET @nuevareferencia = [dbo].[referencia_fn](@serie, @folio, @sucursal, @idTipoReferencia) + '-1'
										-- [dbo].[digito_verificador_fn]([dbo].[referencia_fn](@serie, @folio, @sucursal, @idTipoReferencia)) 
				SELECT @nuevareferencia
				SET @sql = N'SELECT @MOV_CONSPOLOUT = ISNULL(max(pol_consecutivo),0) + 1 FROM ' + @nombrebase + '.dbo.con_pol01' + CONVERT(NVARCHAR(8), @anio) + ' WHERE pol_tipo = '''+@poliza_traspaso+''' AND pol_mes = ' + CONVERT(NVARCHAR(2), @MOV_MES) + ' '
				SET @ParmDefinition = N'@MOV_CONSPOLOUT NVARCHAR(10) OUTPUT'
				EXECUTE sp_executesql @sql, @ParmDefinition,@MOV_CONSPOLOUT OUTPUT;
				---Actualizar en bancomer el estatus y la referencia
				update Bancomer set estatus=5,referencia= replace(substring(@nuevareferencia,1,20),'-','') where idBmer=@idbmer
 
						
				set @MOV_TIPOPOL =@poliza_traspaso
				set @MOV_DEBE =@importe
				set @MOV_HABER =0

				set @MOV_CONSMOV  = 2
				SET  @MOV_CONSPOL   = convert(int,@MOV_CONSPOLOUT)
				Set @fechaoper= getdate()
				Set @mov_fecha=@fechaoper
				set @MOV_CONCEPTO ='Transferencia Multipagos '+convert(nvarchar(10),@mov_fecha,103)
				set @idbanco=isnull(@idBanco,1)

				-- TODO: Set parameter values here.
					PRINT 'Paso 3 poliza debe'
				EXECUTE  [dbo].[CreaPolizaDebe_INS] 
			--	SELECT
					@idRegistro
					,@idEmpresa
					,@idBanco
					,@idUsuario
					,@Usuario
					,@rfc
					,@cuentaContableDebe
					,@MOV_TIPOPOL
					,@MOV_CONSPOL
					,@MOV_CONSMOV
					,@MOV_MES
					,@anio
					,@MOV_DEBE
					,@MOV_HABER
					,@MOV_CONCEPTO
					,@nuevareferencia
					,@fechaoper
					,@mov_fecha
					,@MOV_IDCLIENTE

				--Insertar uno por uno
				Set @MaxIdInt  = 0
				Set @CounterInt  = 1
				Set @MOV_CONCEPTOOUT = '';
				SELECT 
					ROW_NUMBER() OVER(ORDER BY fechaPago,idempresa ASC) AS rowNumber,
					id_registro,
					fechaPago,
					tipoPago,
					referencia,
					importe,
					cuentaBancaria,
					idEmpresa,
					idSucursal,
					idBanco 
				INTO #datoflap
				FROM datosFlap 
				WHERE fechapago = @fechaPago AND cuentaBancaria = @cuentaBancaria AND idEmpresa = @idempresa AND idSucursal = @sucursal and unidadNegocio=@unidadNegocio and dbo.replacecat(categoriacobranza)=@categoriacobranza
				and tipoPago=@tipoPago
				--select MAX(rowNumber) from #datoflap
				SELECT 
					@MaxIdInt = MAX(rowNumber) 
				FROM #datoflap

				PRINT 'Paso 4 poliza individuales'
				--SELECT * FROM #datoflap

				WHILE( @CounterInt <= @MaxIdInt)
					BEGIN
					set @MOV_CONCEPTOOUT=''
						SELECT 
							@id_registro = id_registro,
							@fechaPago = fechaPago,
							@tipoPago = tipoPago,
							@referencia = referencia+'-1',
							@importe = importe, 
							@fechaPago = fechaPago,
							@cuentaBancaria = cuentaBancaria  
						FROM #datoflap
						WHERE rowNumber = @CounterInt
						update datosFlap set referenciaConciliacion=@nuevareferencia,estatusProcesado=1 where id_registro=@id_registro
						SELECT * FROM #datoflap WHERE rowNumber = @CounterInt
						select @MOV_CONCEPTOOUT=documento from Referencia r inner join  DetalleReferencia d on r.idReferencia=d.idReferencia
						where referencia=replace(@referencia,'-1','')


						--select @MOV_CONCEPTOOUT
				
						SET @MOV_CONSMOV = CASE WHEN @CounterInt < 2 THEN @CounterInt ELSE @CounterInt + 1 END
			
						SET @MOV_DEBE = 0
						SET @MOV_HABER = @importe
						SET @MOV_CONCEPTO = 'Transferencia Ingresos ' + @MOV_CONCEPTOOUT

						--TODO: Set parameter values here.

					EXECUTE  [dbo].[CreaPolizaHaber_INS] 
					--	SELECT
							@idRegistro
							,@idEmpresa
							,@idBanco
							,@idUsuario
							,@Usuario
							,@rfc
							,@cuentaContableHaber
							,@MOV_TIPOPOL
							,@MOV_CONSPOL
							,@MOV_CONSMOV
							,@MOV_MES
							,@anio
							,@MOV_DEBE
							,@MOV_HABER
							,@MOV_CONCEPTO
							,@referencia
							,@fechaoper
							,@mov_fecha
							,@MOV_IDCLIENTE
 
						SET @CounterInt  = @CounterInt  + 1 
				
						END
						IF OBJECT_ID('tempdb..#datoflap') IS NOT NULL
							DROP TABLE #datoflap
				END
			End


go

