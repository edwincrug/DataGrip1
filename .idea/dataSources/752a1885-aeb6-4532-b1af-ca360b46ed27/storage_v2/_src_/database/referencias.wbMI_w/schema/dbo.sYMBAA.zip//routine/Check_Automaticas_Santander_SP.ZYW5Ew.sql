
-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- alter date: 2018-01-04
-- Description:	Referencias aplicadas de manera automatica
-- =============================================
--[dbo].[Check_Automaticas_Santander_SP] 6
CREATE PROCEDURE [dbo].[Check_Automaticas_Santander_SP] 
	@idEmpresa INT = 0
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @FacturaQuery varchar(max)  = '';
	DECLARE @Base VARCHAR(MAX)			= '';
	DECLARE @idDeposito INT				= '';
	DECLARE @idBanco INT				= 3;
	
	DECLARE @countDep INT				= 0;
	DECLARE @rap_folio INT				= 0;

	-- Consulta de las bases de datos y sucursales activas
	DECLARE @tableConf  TABLE(idEmpresa INT, idSucursal INT, servidor VARCHAR(250), baseConcentra VARCHAR(250), sqlCmd VARCHAR(8000), cargaDiaria VARCHAR(8000));
	DECLARE @tableBancoFactura TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT);
	DECLARE @tableBancoCotizacion TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT);
	DECLARE @tableBancoPedido TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT);
	DECLARE @tableBancoOrden TABLE(consecutivo INT IDENTITY(1,1), idDeposito INT);
	INSERT INTO @tableConf Execute [dbo].[SEL_ACTIVE_DATABASES_SP];
	DECLARE @CountSuc INT = (SELECT COUNT(idSucursal) Sucursales FROM @tableConf WHERE idEmpresa = @idEmpresa);
	PRINT( '========================= [ RAP_Automaticas_Santander_SP ] =========================' );
	PRINT( 'EMPRESA ' + CONVERT(VARCHAR(2), @idEmpresa) + ': SUCURSALES ' + CONVERT(VARCHAR(3), @CountSuc) );
	
	DECLARE @Current INT = 0, @Max INT = 0;
	DECLARE @CurrentBanco INT = 0, @MaxBanco INT = 0;
	DECLARE @CurrentBancoCoti INT = 0, @MaxBancoCoti INT = 0;

	SELECT @Current = MIN(idSucursal),@Max = MAX(idSucursal) FROM @tableConf WHERE idEmpresa = @idEmpresa;
	WHILE(@Current <= @Max )
		BEGIN
			-- FUNCIONAMIENTO PARA FACTURAS
			-- FUNCIONAMIENTO PARA FACTURAS
			-- FUNCIONAMIENTO PARA FACTURAS
			SET @FacturaQuery = 'SELECT
									SAN.idSantander
								 FROM Referencia R
								 INNER JOIN Santander SAN ON R.Referencia = SAN.concepto
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
								 --LEFT JOIN Rel_BancoCobro C ON R.idEmpresa = C.emp_idempresa
								 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
									   AND DR.idSucursal		= ' + CONVERT( VARCHAR(3), @Current ) + '
									   AND SAN.estatusRevision	= 1
									   AND SAN.signo			= ''+''
									   AND DR.idTipoDocumento	= 1
									   AND SAN.IdBanco			= 3;';
            
			INSERT INTO @tableBancoFactura
			EXECUTE( @FacturaQuery );
			
			SET @countDep = (SELECT COUNT(consecutivo) FROM @tableBancoFactura);
			PRINT( '    Sucursal ' + CONVERT( VARCHAR(3), @Current ) + ': '+ CONVERT(VARCHAR(5), @countDep) +' Referencias');
			
			-- SET del parametro Base		
			-- SET @Base = (SELECT servidor FROM @tableConf WHERE idSucursal = @Current);



			-- VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL MISMO
			-- VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL MISMO
			-- VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL MISMO
			DECLARE @ipLocal VARCHAR(15) = (
				SELECT	dec.local_net_address
				FROM	sys.dm_exec_connections AS dec
				WHERE	dec.session_id = @@SPID
			);

			-- DECLARE @Base VARCHAR(300) = ''
			IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
				BEGIN
					SET @Base = (SELECT '[' + nombre_base + '].[dbo]' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
				END
			ELSE
				BEGIN
					SET @Base = (SELECT '[' + ip_servidor + '].[' + nombre_base + '].[dbo]' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
				END
			-- / VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL MISMO

			
			-- Inicia segundo While
			SELECT @CurrentBanco = MIN(consecutivo),@MaxBanco = MAX(consecutivo) FROM @tableBancoFactura;
			WHILE(@CurrentBanco <= @MaxBanco )
				BEGIN
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag				
					BEGIN TRY		
						SET @idDeposito			  = ( SELECT TOP 1 idDeposito FROM @tableBancoFactura WHERE consecutivo = @CurrentBanco );
						SELECT @FacturaQuery	  = [dbo].[fnReferenciaSantanderFactura]( @Base, @idDeposito );
						SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						EXECUTE( @FacturaQuery ); 						
						PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] FACTURA: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
						PRINT( @FacturaQuery );
					END TRY
					BEGIN CATCH	
						PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] FACTURA: ' + ERROR_MESSAGE() );
						PRINT( @FacturaQuery );
					END CATCH				
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
				SET	@CurrentBanco = @CurrentBanco + 1;
				END	
			-- /FUNCIONAMIENTO PARA FACTURAS
			-- /FUNCIONAMIENTO PARA FACTURAS
			-- /FUNCIONAMIENTO PARA FACTURAS
			
			
			-- FUNCIONAMIENTO PARA COTIZACIONES
			-- FUNCIONAMIENTO PARA COTIZACIONES
			-- FUNCIONAMIENTO PARA COTIZACIONES
			SET @FacturaQuery = 'SELECT SAN.idSantander
								 FROM Referencia R
								 INNER JOIN Santander SAN ON R.referencia = SAN.concepto
								 INNER JOIN DetalleReferencia DR ON DR.idReferencia = R.idReferencia
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa AND BP.suc_idsucursal = DR.idSucursal
								 --LEFT JOIN Rel_BancoCobro C ON C.emp_idempresa = R.idEmpresa
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
									   AND DR.idSucursal		= ' + CONVERT( VARCHAR(3), @Current ) + '
									   AND SAN.estatusRevision	= 1
									   AND SAN.signo			= ''+''
									   AND DR.idTipoDocumento	= 2
									   AND SAN.IdBanco			= 3;';

			--print(@FacturaQuery);
            INSERT INTO @tableBancoCotizacion
			EXECUTE( @FacturaQuery );		
            
			
			-- Inicia segundo while
			SELECT @CurrentBancoCoti = MIN(consecutivo),@MaxBancoCoti = MAX(consecutivo) FROM @tableBancoCotizacion;
			WHILE(@CurrentBancoCoti <= @MaxBancoCoti )
				BEGIN
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag				
					BEGIN TRY		
						SET @idDeposito			  = ( SELECT TOP 1 idDeposito FROM @tableBancoCotizacion WHERE consecutivo = @CurrentBancoCoti );
						SELECT @FacturaQuery	  = [dbo].[fnReferenciaSantanderCotizacion]( @Base, @idDeposito );
						SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						EXECUTE( @FacturaQuery ); 
						PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] COTIZACIÓN: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
						--PRINT( @FacturaQuery );
					END TRY
					BEGIN CATCH	
						PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] FACTURA: ' + ERROR_MESSAGE() );
					END CATCH
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
				SET	@CurrentBancoCoti = @CurrentBancoCoti + 1;
				END		
				
			PRINT('');	
			-- /FUNCIONAMIENTO PARA COTIZACIONES
			-- /FUNCIONAMIENTO PARA COTIZACIONES
			-- /FUNCIONAMIENTO PARA COTIZACIONES

			-- FUNCIONAMIENTO PARA Pedido
			-- FUNCIONAMIENTO PARA Pedido
			-- FUNCIONAMIENTO PARA Pedido
			SET @FacturaQuery = 'SELECT SAN.idSantander
								 FROM Referencia R
								 INNER JOIN Santander SAN ON R.referencia = SAN.concepto
								 INNER JOIN DetalleReferencia DR ON DR.idReferencia = R.idReferencia
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa AND BP.suc_idsucursal = DR.idSucursal
								 --LEFT JOIN Rel_BancoCobro C ON C.emp_idempresa = R.idEmpresa
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
									   AND DR.idSucursal		= ' + CONVERT( VARCHAR(3), @Current ) + '
									   AND SAN.estatusRevision	= 1
									   AND SAN.signo			= ''+''
									   AND DR.idTipoDocumento	= 3
									   AND SAN.IdBanco			= 3;';

			--print(@FacturaQuery);
            INSERT INTO @tableBancoPedido
			EXECUTE( @FacturaQuery );		
            
			
			-- Inicia segundo while
			SELECT @CurrentBancoCoti = MIN(consecutivo),@MaxBancoCoti = MAX(consecutivo) FROM @tableBancoPedido;
			WHILE(@CurrentBancoCoti <= @MaxBancoCoti )
				BEGIN
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag				
					BEGIN TRY		
						SET @idDeposito			  = ( SELECT TOP 1 idDeposito FROM @tableBancoPedido WHERE consecutivo = @CurrentBancoCoti );
						SELECT @FacturaQuery	  = [dbo].[fnReferenciaSantanderPedido]( @Base, @idDeposito );
						SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						EXECUTE( @FacturaQuery );
						print @FacturaQuery
						PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] COTIZACIÓN: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
						--PRINT( @FacturaQuery );
					END TRY
					BEGIN CATCH	
						PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] FACTURA: ' + ERROR_MESSAGE() );
					END CATCH
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
				SET	@CurrentBancoCoti = @CurrentBancoCoti + 1;
				END		
				
			PRINT('');	
			-- /FUNCIONAMIENTO PARA Pedido
			-- /FUNCIONAMIENTO PARA Pedido
			-- /FUNCIONAMIENTO PARA Pedido

			-- FUNCIONAMIENTO PARA Orden
			-- FUNCIONAMIENTO PARA Orden
			-- FUNCIONAMIENTO PARA Orden
			SET @FacturaQuery = 'SELECT SAN.idSantander
								 FROM Referencia R
								 INNER JOIN Santander SAN ON R.referencia = SAN.concepto
								 INNER JOIN DetalleReferencia DR ON DR.idReferencia = R.idReferencia
								 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa AND BP.suc_idsucursal = DR.idSucursal
								 WHERE R.idEmpresa				= ' + CONVERT( VARCHAR(3), @idEmpresa ) + '
									   AND DR.idSucursal		= ' + CONVERT( VARCHAR(3), @Current ) + '
									   AND SAN.estatusRevision	= 1
									   AND SAN.signo			= ''+''
									   AND DR.idTipoDocumento	= 5
									   AND SAN.IdBanco			= 3;';

--			print(@FacturaQuery);
            INSERT INTO @tableBancoOrden
			EXECUTE( @FacturaQuery );		
            
	--		select *,@Base from @tableBancoOrden
			-- Inicia segundo while
			SELECT @CurrentBancoCoti = MIN(consecutivo),@MaxBancoCoti = MAX(consecutivo) FROM @tableBancoOrden;
			WHILE(@CurrentBancoCoti <= @MaxBancoCoti )
				BEGIN
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag				
					BEGIN TRY		
						SET @idDeposito			  = ( SELECT TOP 1 idDeposito FROM @tableBancoOrden WHERE consecutivo = @CurrentBancoCoti );
						SELECT @FacturaQuery	  = [dbo].[fnReferenciaSantanderOrden]( @Base, @idDeposito );
						SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
				--		PRINT( @FacturaQuery );
						EXECUTE( @FacturaQuery ); 
						PRINT( '        SUCCESS: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] COTIZACIÓN: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
						
					END TRY
					BEGIN CATCH	
						PRINT( '        ERROR: Depósito ['+ CONVERT(VARCHAR(10), @idDeposito) +'] FACTURA: ' + ERROR_MESSAGE() );
					END CATCH
					-- Funcionamiento de meter en cxc_refantypag
					-- Funcionamiento de meter en cxc_refantypag
				SET	@CurrentBancoCoti = @CurrentBancoCoti + 1;
				END		
				
			PRINT('');	
			-- /FUNCIONAMIENTO PARA Orden
			-- /FUNCIONAMIENTO PARA Orden
			-- /FUNCIONAMIENTO PARA Orden	
			DELETE FROM @tableBancoPedido;
			DELETE FROM @tableBancoOrden;					
			DELETE FROM @tableBancoCotizacion;
			DELETE FROM @tableBancoFactura;
			SET	@Current = @Current + 1;
		END 
END


go

