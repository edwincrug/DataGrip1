-- =============================================
-- Author:		Luis García
-- Create date: 04/12/2019
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_CXC_DOCTOS]
	@fechaPago VARCHAR(30),
	@nombreRazonSocial VARCHAR(50),
	@unidadNegocio INT,
	@categoriaCobranza INT,
	@tipoPago VARCHAR(10),
	@referencia VARCHAR(40),
	@numeroOrden VARCHAR(100),
	@aprobacionBancaria VARCHAR(10),
	@identificadorVenta INT,
	@referenciaMedioDePago VARCHAR(20),
	@importe DECIMAL(18, 2),
	@comision DECIMAL(18, 2),
	@ivaComisión DECIMAL(18, 2),
	@fechaDispersión VARCHAR(10),
	@periodoFinanciamiento INT,
	@moneda INT,
	@bancoEmisor VARCHAR(100),
	@nombrePagador VARCHAR(100),
	@mail VARCHAR(50),
	@telefono VARCHAR(50)
AS
BEGIN
	BEGIN TRY
		IF(@aprobacionBancaria = '' OR @aprobacionBancaria IS NULL)
			BEGIN
				SELECT success = 1;
				RETURN
			END
		IF NOT EXISTS(SELECT aprobacionBancaria FROM datosFlap WHERE aprobacionBancaria = LTRIM(RTRIM(@aprobacionBancaria)))
			BEGIN

				DECLARE @cuentaBancaria VARCHAR(100), @idEmpresa INT, @idSucursal INT, @idBanco INT;

				SELECT TOP 1
					@idEmpresa = BC.idEmpresa,
					@idSucursal = T.idSucursal,
					@idBanco = BC.idBanco,
					@cuentaBancaria = BC.numeroCuenta
				FROM Pago P 
				INNER JOIN Transaccion T ON T.idTrans = P.idTrans
				INNER JOIN referencias.dbo.BancoCuenta BC ON BC.idEmpresa = T.idEmpresa AND BC.pagoPinPad = 1
				WHERE P.referencia = LTRIM(RTRIM(@referencia))

				IF ( @cuentaBancaria = '' OR @cuentaBancaria IS NULL)
					BEGIN
						DECLARE @tipoError VARCHAR(100) = 'No se inserto la cuenta bancaria en el registro no se encontro en la tabla de Pago ' + LTRIM(RTRIM(@aprobacionBancaria)),
						@error VARCHAR(50) = 'No se encontra la referencia en la tabla de "Pago" en la BD "referencias".';
						EXEC [DBO].[SP_INS_PROCESO_LOGERROR] @tipoError, @error
					END


				INSERT INTO [dbo].[datosFlap]
				   ([fechaPago]
				   ,[nombreRazonSocial]
				   ,[unidadNegocio]
				   ,[categoriaCobranza]
				   ,[tipoPago]
				   ,[referencia]
				   ,[numeroOrden]
				   ,[aprobacionBancaria]
				   ,[identificadorVenta]
				   ,[referenciaMedioDePago]
				   ,[importe]
				   ,[comision]
				   ,[ivaComision]
				   ,[fechaDispersion]
				   ,[periodoFinanciamiento]
				   ,[moneda]
				   ,[bancoEmisor]
				   ,[nombrePagador]
				   ,[mail]
				   ,[telefono]
				   ,[cuentaBancaria]
				   ,[idEmpresa]
				   ,[idSucursal]
				   ,[idBanco]
				   ,[estatusProcesado]
				   ,[fechaInsercion])
			 VALUES
				   (LTRIM(RTRIM(@fechaPago)),
					LTRIM(RTRIM(@nombreRazonSocial)),
					LTRIM(RTRIM(@unidadNegocio)),
					LTRIM(RTRIM(@categoriaCobranza)),
					LTRIM(RTRIM(@tipoPago)),
					LTRIM(RTRIM(@referencia)),
					LTRIM(RTRIM(@numeroOrden)),
					LTRIM(RTRIM(@aprobacionBancaria)),
					LTRIM(RTRIM(@identificadorVenta)),
					LTRIM(RTRIM(@referenciaMedioDePago)),
					LTRIM(RTRIM(@importe)),
					LTRIM(RTRIM(@comision)),
					LTRIM(RTRIM(@ivaComisión)),
					LTRIM(RTRIM(@fechaDispersión)),
					LTRIM(RTRIM(@periodoFinanciamiento)),
					LTRIM(RTRIM(@moneda)),
					LTRIM(RTRIM(@bancoEmisor)),
					LTRIM(RTRIM(@nombrePagador)),
					LTRIM(RTRIM(@mail)),
					LTRIM(RTRIM(@telefono)),
					@cuentaBancaria,
					@idEmpresa,
					@idSucursal,
					@idBanco,
					0,
					GETDATE())
			END

			SELECT success = 1;
	END TRY
	BEGIN CATCH
		SELECT success = 0, msj = ERROR_MESSAGE(); 
	END CATCH
END
go

