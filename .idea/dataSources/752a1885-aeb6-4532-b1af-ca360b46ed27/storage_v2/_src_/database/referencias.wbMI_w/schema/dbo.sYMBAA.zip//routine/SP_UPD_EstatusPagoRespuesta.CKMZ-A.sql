




-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 30-09-2019
-- Description: Actualiza el estatus las Cancelaciones de Pagos
-- =============================================
CREATE PROCEDURE [dbo].[SP_UPD_EstatusPagoRespuesta] 
		(  @codAutorizacion varchar(10)
           ,@estatus bit
		)

AS
BEGIN
	BEGIN TRY  --Estar TryCatch

		   UPDATE [dbo].[PagoRespuesta]
			SET 
				 [estatus] = @estatus
				,[fechaRegistro] = GETDATE()
		WHERE [numeroAutorizacion] = @codAutorizacion


	END TRY  
	BEGIN CATCH  
		--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[PagoRespuesta]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro

	END CATCH; --End TryCatch


END
go

