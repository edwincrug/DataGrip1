



-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 11-09-2019
-- Description:	Obtiene los datos del Cliente en [GA_Corporativa] mediante su ID
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_ClientePorId]
(
	 @idCliente  INT = 0
)
AS
BEGIN

BEGIN TRY  --Star TryCatch

		SELECT C.[PER_IDPERSONA]  AS idCliente
			  ,C.[PER_RFC]        AS rfc 
			  ,C.[PER_PATERNO]    AS paterno
			  ,C.[PER_MATERNO]    AS materno
			  ,RTRIM(LTRIM(C.[PER_NOMRAZON]  + ' ' + C.[PER_PATERNO]  + ' ' + C.[PER_MATERNO])) AS nombre
			  ,C.[PER_CURP]       AS curp
			  ,C.[PER_CALLE1]     AS calle
			  ,C.[PER_NUMEXTER]   AS numero
			  ,C.[PER_COLONIA]    AS colonia
			  ,C.[PER_DELEGAC]    AS delegacion
			  ,C.[PER_CODPOS]     AS codigoPostal
			  ,RTRIM(LTRIM(C.[PER_CALLE1]  + ' NUM.' + C.[PER_NUMEXTER] + ' ' + ' COL.' + C.[PER_COLONIA] + ' DEL.'+ C.[PER_DELEGAC] +' C.P.'+ CAST(C.[PER_CODPOS] AS NVARCHAR(20)))) AS direccion
			  ,C.[PER_EMAIL]      AS email
			  ,ISNULL (C.[PER_TELEFONO1], 55555555) AS telefono
			  ,C.[PER_STATUS]     AS estatus
			  ,ISNULL (C.[PER_TELEFONO2], 55555555)  AS telefonoCelular
			  ,CONVERT(nvarchar(10),getdate(), 103)  AS fechaConsulta
			  ,'datos'              AS tabla
		  FROM [GA_Corporativa].[dbo].[PER_PERSONAS] AS C
		 WHERE C.[PER_IDPERSONA] = @idCliente


END TRY  
BEGIN CATCH  
    SELECT  
        ERROR_NUMBER() AS ErrorNumber  
        ,ERROR_SEVERITY() AS ErrorSeverity  
        ,ERROR_STATE() AS ErrorState  
        ,ERROR_PROCEDURE() AS ErrorProcedure  
        ,ERROR_LINE() AS ErrorLine  
        ,ERROR_MESSAGE() AS ErrorMessage;  
END CATCH; --End TryCatch



	

END
go

