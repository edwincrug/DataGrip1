-- ==========================================================================================
-- Author:     
-- Create date: 
-- Description: Detalle de todos las COTIZACIONES|REFACCIONES|  
--				Filtrando por cliente.	 
--              Para hacer diferencia entre empresas es cambiando el nombre de la base
--				falta buscar por empresa, sucursal y departamento
-- ==========================================================================================
--  [SEL_TOTAL_PEDIDOS_TODOS_SUCURSAL_SP]       @idCliente =  186756 , @idEmpresas = 4, @idSucursales = 12   
--173578   74990       
	CREATE PROCEDURE [dbo].[SEL_TOTAL_PEDIDOS_TODOS_SUCURSAL_SP] 
      @idCliente     int = 0
	  ,@idEmpresas    int = 0
	  ,@idSucursales int = 0
AS
BEGIN
    SET NOCOUNT ON;
   
    DECLARE @aux               INT = 1
    DECLARE @max               INT = 0
    DECLARE @idEmpresaBusca    INT = 0
    DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
    DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @select         VARCHAR(max);
	DECLARE @selectPreCot         VARCHAR(max);
	DECLARE @selectCotNu         VARCHAR(max);
	DECLARE @selectCotSE         VARCHAR(max);
	DECLARE @selectPeOr        VARCHAR(max);
	DECLARE	@idSucursal		NVARCHAR(50) =NULL
	DECLARE	@nombreSucursal NVARCHAR(50) =NULL
	DECLARE @nombreEmpresa  NVARCHAR(50) =NULL
	DECLARE	@idEmpresa	NVARCHAR(50) =NULL
	DECLARE @cadIpServidor VARCHAR(100);
	DECLARE @ipServidor NVARCHAR(50)
	DECLARE @sIpaux         VARCHAR(100) = ''  --1) LMS 28/08/2018

	----------------------------------------------------------------
	-- OBTENGO LA IP LOCAL                     --2) LMS 28/08/2018
	----------------------------------------------------------------
	SELECT @sIpaux= local_net_address
	  FROM sys.dm_exec_connections c
	 WHERE c.session_id = @@SPID
    
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
							idSucursal nvarchar(30),
                            idEmpresa         nvarchar(30)
                            ,nombreEmpresa     nvarchar(100)
                            ,nomCtoEmpresa     nvarchar(5)
                            ,nomBaseConcentra  nvarchar(50)
							,nomBaseSucursal  nvarchar(50)
                            ,nomBaseMatriz     nvarchar(50)
                            ,ipServidor        nvarchar(20)
                            )

-- SE HACE LA BUSQUEDA DE LAS EMPRESAS Y SUCURSALES DISPONIBLES CON EL NOMBRE Y DIRECCIÓN IP DONDE SE ENCUENTRAN
     INSERT INTO @Bases
	   	SELECT 
				sucursales.suc_idsucursal
				,EMP.emp_idempresa
                ,EMP.emp_nombre
                ,EMP.emp_nombrecto
                ,BASEMP.nombre_base
				,BASEMP.nombre_sucursal
				--,BASEMP.
                ,ISNULL(BASEMP.nombre_base_matriz,BASEMP.nombre_base)
                ,BASEMP.ip_servidor 
           FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
                INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				inner join [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
          WHERE  BASEMP.estatus = 1 AND BASEMP.tipo = 1 and sucursales.emp_idempresa= EMP.emp_idempresa AND BASEMP.nombre_sucursal != 'CRA Guadalajara'
       ORDER BY sucursales.suc_idsucursal
     
     SET @max = (SELECT MAX(IDB) FROM @Bases)
     WHILE(@aux <= @max)
     BEGIN
         
         SELECT  @idEmpresaBusca   = DB.idEmpresa 
				,@idEmpresa = DB.idEmpresa
                ,@nomBaseConcentra = DB.nomBaseConcentra
                ,@nomBaseMatriz    = DB.nomBaseMatriz
				,@idSucursal = DB.idSucursal
				,@nombreSucursal = DB.nomBaseSucursal
				,@nombreEmpresa = DB.nombreEmpresa
				,@ipServidor = DB.ipServidor
           FROM @Bases AS DB 
          WHERE DB.IDB = @aux --DB.idEmpresa = @aux 
          --EXECUTE [SEL_PRESUPUESTO_DETALLE_SP] @idEmpresaBusca
		  IF (@ipServidor = @sIpaux)             --3) LMS 28/08/2018
			BEGIN
				set @cadIpServidor =''
			END
		ELSE
			BEGIN
				set @cadIpServidor =' [' + @ipServidor + '].'
			END

	DECLARE @todo TABLE  ( IDB INT IDENTITY(1,1),
                            idDocumento         nvarchar(30)
							,idEmpresa nvarchar(30)
							,nombreEmpresa nvarchar(30)
							,idSucursal nvarchar(30)
							,nombreSucursal nvarchar(30)
							,idDepartamento  nvarchar(30)
							,nombreDepartamento nvarchar(30)
							,saldo nvarchar(30)
						    ,tipoDocumento nvarchar(30)
                            ,nombreCliente     nvarchar(100)
                            ,fecha  nvarchar(30)
							,idCliente  nvarchar(30)
							,estatus nvarchar(30)
							,referencia nvarchar(20)
                            )
		  -- Refacciones|Pedidos dep_nombre
		  SET @select =
				'SELECT ' + char(13) + 
				'refacciones.PMM_NUMERO AS idDocumento' + char(13) + 
				',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
				',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) + 
				',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
				',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) + 
				',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+')as idDepartamento' + char(13) +
				',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+')as nombreDepartamento' + char(13) +  
				',refacciones.PMM_TOTAL AS saldo -- ES CON IVA' + char(13) + 
				',3 AS idTipoDocumento' + char(13) + 
				',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
				',refacciones.PMM_FECHOPE AS fecha' + char(13) + 
				',refacciones.PMM_IDCLIENTE AS idCliente ' + char(13) + 
				',PMM_IDALMA as estatus' + char(13) + 
				',(SELECT referencia FROM [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia  WHERE DEREF.documento = ( SELECT CONVERT(nvarchar(30),refacciones.PMM_NUMERO ))   AND DEREF.idSucursal = '+@idSucursal +' AND  DEREF.idDepartamento = (select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+' AND REF.tipoReferencia = 1))as Referencia '+
				'FROM  '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[PAR_PEDMOST]  refacciones  ' + char(13) + 
				'INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = refacciones.PMM_IDCLIENTE ' + char(13) + 
				'WHERE refacciones.PMM_COTPED LIKE '+char(39)+'PEDIDO%'+char(39)+'' + char(13) + 'AND PMM_STATUS != ''X'' AND PMM_STATUS != ''C'''+' AND refacciones.PMM_IDCLIENTE='+ cast (@idCliente as varchar(10)) + 
				'' 

			-- Semi Nuevas
			SET @selectCotSE = 

				'SELECT '+
					'seminuevos.PMS_NUMPEDIDO AS idDocumento' + char(13) + 
					',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
					',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) + 
					',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
					',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) + 
					',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
					'and dep_nombrecto = '+char(39)+'US'+char(39)+')as idDepartamento' + char(13) +
					',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
					'and dep_nombrecto = '+char(39)+'US'+char(39)+')as nombreDepartamento' + char(13) +  
					',seminuevos.PMS_TOTAL AS saldo' + char(13) + 
					',3 AS idTipoDocumento' + char(13) +
					',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
					',seminuevos.PMS_FECPEDIDO AS fechaDocumento ' + char(13) + 
					',seminuevos.PMS_IDPERSONA AS idCliente' + char(13) + 
					','+char(39)+''+char(39)+' AS estatus' + char(13) +
					',(SELECT referencia FROM [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia  WHERE DEREF.documento = ( SELECT CONVERT(nvarchar(30),seminuevos.PMS_NUMPEDIDO))   AND DEREF.idSucursal = '+@idSucursal +' AND  DEREF.idDepartamento = (select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
					'and dep_nombrecto = '+char(39)+'US'+char(39)+' AND REF.tipoReferencia = 1))as Referencia '+
					'FROM  '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[USN_PEDIDO] seminuevos	' + char(13) + 
					'INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = seminuevos.PMS_IDPERSONA AND PMS_STATUS='+char(39)+'E'+char(39)+'' + char(13) + 
					'WHERE seminuevos.PMS_IDPERSONA = '+ cast (@idCliente as varchar(10)) +
					''

-- Ordenes de Servicio
			SET @selectPeOr = 
 				'SELECT' + char(13) + 
					'distinct(detalle.ORD_IDORDEN) as idDocumento' + char(13) + 
					',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
					',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) + 
					',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
					',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) + 
					',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
						'and dep_nombrecto = '+char(39)+'SE'+char(39)+')as idDepartamento' + char(13) +
					',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
						'and dep_nombrecto = '+char(39)+'SE'+char(39)+')as nombreDepartamento' + char(13) +  
					',SUM(detalle.ORD_SUBTOTAL) as importe' + char(13) + 
					',5 AS idTipoDocumento' + char(13) +
					',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
					',orden.ORE_FECHAORD AS fechaDocumento' + char(13) + 
					',orden.ORE_IDCLIENTE AS idCliente'+ char(13) +
					','+char(39)+''+char(39)+' AS estatus' + char(13) +
					',(SELECT referencia FROM [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia  WHERE DEREF.documento = detalle.ORD_IDORDEN  COLLATE Modern_Spanish_CI_AS   AND DEREF.idSucursal = '+@idSucursal +' AND  DEREF.idDepartamento = (select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
					'and dep_nombrecto = '+char(39)+'SE'+char(39)+' AND REF.tipoReferencia = 1))as Referencia '+
					'FROM  '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[SER_ORDEN] orden' + char(13) + 
					'INNER JOIN   '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[SER_ORDENDET] detalle ON orden.ORE_IDORDEN = detalle.ORD_IDORDEN ' + char(13) + 
					'INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = orden.ORE_IDCLIENTE ' + char(13) + 
					'WHERE orden.ORE_STATUS != '+char(39)+'C'+char(39)+' AND orden.ORE_STATUS !='+char(39)+'I'+char(39)+'' + char(13) + ' AND orden.ORE_IDCLIENTE  = ' + cast (@idCliente as varchar(10)) +
					'group by detalle.ORD_IDORDEN' + char(13) + 
					',personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno' + char(13) + 
					',orden.ORE_FECHAORD' + char(13) + 
					',orden.ORE_IDCLIENTE' + char(13) + 
					'' 

		SET @selectPreCot =
			 	'SELECT ' + char(13) + 
					'nuevos.UPE_IDPEDI AS idDocumento' + char(13) + 
					',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
					',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) + 
					',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
					',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) + 
					',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
						'and dep_nombrecto = '+char(39)+'UN'+char(39)+')as idDepartamento' + char(13) +	
					',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
						'and dep_nombrecto = '+char(39)+'UN'+char(39)+')as nombreDepartamento' + char(13) +
					',detalle.PEN_SUBTOTAL1 AS saldo' + char(13) + 
					',3 AS idTipoDocumento' + char(13) +
					',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS Nombre' + char(13) + 
					',nuevos.UPE_FECHPEDI AS fechaDocumento ' + char(13) +
					',nuevos.UPE_IDCLIENTE AS idCliente' + char(13) +  
					','+char(39)+''+char(39)+' AS estatus' + char(13) +
					',(SELECT referencia FROM [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia  WHERE DEREF.documento = ( SELECT CONVERT(nvarchar(30),nuevos.UPE_IDPEDI))   AND DEREF.idSucursal = '+@idSucursal +' AND  DEREF.idDepartamento = (select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
					'and dep_nombrecto = '+char(39)+'UN'+char(39)+' AND REF.tipoReferencia = 1))as Referencia '+
					'FROM   '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[UNI_PEDIDO] nuevos	' + char(13) + 
					'INNER JOIN   '+@cadIpServidor +' ['+ @nomBaseMatriz +'].[dbo].[UNI_PEDIUNI] detalle ON nuevos.UPE_IDPEDI = detalle.PEN_IDPEDI' + char(13) + 
					'INNER JOIN GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = nuevos.UPE_IDCLIENTE '+
					'WHERE UPE_STATUS = '+char(39)+'P'+char(39)+'' + char(13) + ' AND nuevos.UPE_IDCLIENTE = ' + cast (@idCliente as varchar(10)) + 
					'' 

				INSERT INTO @todo EXECUTE (@selectPreCot)
				INSERT INTO @todo EXECUTE (@selectPeOr)
				INSERT INTO @todo EXECUTE (@selectCotSE)
				INSERT INTO @todo EXECUTE (@select)        
         SET @aux = @aux + 1
     END
	 select IDB 
			,idDocumento       
			,idEmpresa 
			,nombreEmpresa 
			,idSucursal 
			,nombreSucursal 
			,idDepartamento  
			,nombreDepartamento 
			,saldo 
			,tipoDocumento 
			,nombreCliente     
			,fecha  
			,idCliente  
			,estatus 
			,referencia  from @todo where idCliente = @idCliente and idEmpresa = @idEmpresas and idSucursal = @idSucursales
END



go

