-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
Create FUNCTION [dbo].[GetCotPed](@idTipoDocto int)
RETURNS varchar(100)
AS
BEGIN

	--catalogo de tipos de documentos select * from tipodocumento

	DECLARE @Result varchar(100)
		
	select @Result = case @idTipoDocto 
	when 1 then NULL
	when 2 then 'COTIZACION'
	when 3 then 'PEDIDO'
	when 4 then 'COTIZACION'
	when 5 then 'PEDIDO'
	else NULL END

	RETURN @Result

END

go

