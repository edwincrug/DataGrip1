CREATE PROCEDURE [dbo].[SEL_EMPRESA_BY_USUARIO_SP]
@idUsuario INT
AS
BEGIN
  SELECT DISTINCT (Empre.emp_nombre), Empre.emp_idempresa from [ControlAplicaciones].[dbo].[ope_organigrama] Orga
  INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] Empre ON Orga.emp_idempresa = Empre.emp_idempresa
  where Orga.usu_idusuario  = @idUsuario 
END
go

