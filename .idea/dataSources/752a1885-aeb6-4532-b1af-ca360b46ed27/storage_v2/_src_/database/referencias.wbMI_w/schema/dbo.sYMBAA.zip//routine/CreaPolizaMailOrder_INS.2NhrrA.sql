-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<crea poliza de la tabla [dbo].[datosFlap]>
-- =============================================
--[dbo].[CreaPoliza_INS] 
/*
RESPALDO DE PRODUCCION 29/06/2020
*/
CREATE PROCEDURE [dbo].[CreaPolizaMailOrder_INS]

AS
BEGIN

	--select id_registro,tipoPago,referencia,importe,comision,ivaComision,fechaPago,cuentaBancaria,idEmpresa,idBanco,estatusProcesado 
	--from datosFlap 
	--where cuentaBancaria is not null and estatusProcesado= 0

	--select * from Bancomer where noCuenta='000000000195334667' and importe=2.5 and refampliada like '%Multipagos%'

	DECLARE @Counter INT = 1, 
			@MaxId INT, 
			@fechaPago DATE,
			@cuentaBancaria NVARCHAR(20),
			@idbanco INT,
			@importe DECIMAL(18,2),
			@idempresa INT,
			@referencia NVARCHAR(50),
			@sucursal INT,
			@unidadNegocio INT,
			@categoriacobranza INT,
			@poliza_traspaso nvarchar(10),
			@importeBanco decimal(18,2),
			@idTipoDocumento int
	DECLARE @idbmer INT = 0, @cuentaContableDebe NVARCHAR(20) = '', @cuentaContableHaber NVARCHAR(20) = '', @nombrebase NVARCHAR(150), @sql NVARCHAR(max) = '', @ParmDefinition NVARCHAR(max)
	DECLARE @MOV_IDCLIENTE INT = 0, @rfc NVARCHAR(20) = '', @MOV_MES INT, @anio INT, @MOV_CONSPOL INT, @MOV_CONSPOLOUT NVARCHAR(10) = '', @consecutivocontable INT = 0, @nuevareferencia NVARCHAR(22)
		DECLARE @serie NVARCHAR(2), @idTipoReferencia INT = 1, @folio NVARCHAR(4)
			DECLARE @RC int
							DECLARE @idRegistro int=0
							DECLARE @idUsuario nvarchar(4)='GMI'
							DECLARE @Usuario int=0
							DECLARE @MOV_TIPOPOL nvarchar(10)
							DECLARE @MOV_DEBE decimal(18,5)
							DECLARE @MOV_HABER decimal(18,5)
							DECLARE @MOV_CONSMOV int 
							DECLARE @fechaoper datetime
							DECLARE @mov_fecha datetime
							DECLARE @MOV_CONCEPTO nvarchar(100)
	DECLARE @MaxIdInt INT = 0, @CounterInt INT = 1, @id_registro INT,  @tipoPago NVARCHAR(10), @MOV_CONCEPTOOUT NVARCHAR(250) = '';

DECLARE @datosflaptemp TABLE (
	[rowNumber] [bigint] NULL,
	[fechaPago] [date] NULL,
	[cuentaBancaria] [varchar](100) NULL,
	[idEmpresa] [int] NULL,
	[idSucursal] [int] NULL,
	[importe] [decimal](38, 2) NULL,
	[unidadNegocio] [int] NULL,
	[categoriacobranza] [int] NULL,
	[tipopago] [varchar](10) NULL
)

DECLARE @tempeval TABLE (
	rowNumber int identity,
	[idbmer] [int] NULL,
	[importeBanco] [decimal](18, 2) NULL,
	[fechaPago] [varchar](30) NULL,
	[cuentaBancaria] [varchar](100) NULL,
	[idEmpresa] [int] NULL,
	[idSucursal] [int] NULL,
	[importe] [decimal](18, 2) NULL,
	[unidadNegocio] [int] NULL,
	[categoriacobranza] [int] NULL,
	[idorigen] [int] NOT NULL,
	[tipoPago] [varchar](10) NULL,
	[documento] [varchar](max) NOT NULL,
	[idCliente] [numeric](18, 0) NOT NULL,
	[referencia] [char](20) NOT NULL,
	[idTipoDocumento] [numeric](18, 0) NOT NULL
) 
DECLARE @tempeval2 TABLE (
	rowNumber int identity,
	[idbmer] [int] NULL,
	[importeBanco] [decimal](18, 2) NULL,
	[fechaPago] [varchar](30) NULL,
	[cuentaBancaria] [varchar](100) NULL,
	[idEmpresa] [int] NULL,
	[idSucursal] [int] NULL,
	[importe] [decimal](18, 2) NULL,
	[unidadNegocio] [int] NULL,
	[categoriacobranza] [int] NULL,
	[idorigen] [int] NOT NULL,
	[tipoPago] [varchar](10) NULL,
	[documento] [varchar](max) NOT NULL,
	[idCliente] [numeric](18, 0) NOT NULL,
	[referencia] [char](20) NOT NULL,
	[idTipoDocumento] [numeric](18, 0) NOT NULL
) 


insert into @datosflaptemp
	SELECT 
		ROW_NUMBER() OVER(ORDER BY fechaPago,idempresa ASC) AS rowNumber,
		fechaPago,
		cuentaBancaria,
		idEmpresa,
		idSucursal,
		SUM(importe) importe,
		unidadNegocio,
		replace(categoriacobranza,7,3),
		tipopago
	
	FROM (select convert(date,fechaPago) fechaPago,
		fl.cuentaBancaria,
		fl.idEmpresa,
		fl.idSucursal,
		fl.importe,
		fl.estatusProcesado,
		fl.unidadNegocio,
		fl.categoriacobranza,
		Replace(fl.tipoPago,'CIE','TDX') tipoPago
		from datosFlap fl
		inner join pago a on fl.referencia=a.referencia and fl.numeroOrden=a.idTrans
		where a.idOrigen =4
		 ) x
	WHERE cuentaBancaria is not null and estatusProcesado= 0 --and fechaPago='2020-10-21'
	GROUP BY fechaPago,unidadNegocio,
		categoriacobranza,cuentaBancaria,idEmpresa,idSucursal,TipoPago


			--PRINT 'Paso 1' 
			--SELECT * FROM @datosflaptemp
			--end
			SELECT 
				@MaxId = MAX(rowNumber) 
			FROM @datosflaptemp
			select * 	FROM @datosflaptemp
			WHILE(@Counter IS NOT NULL AND @Counter <= @MaxId)
			BEGIN
				Set @poliza_traspaso=''
					 SELECT  
						@fechaPago=fechaPago,
						@cuentaBancaria=cuentaBancaria,
						@idempresa=idempresa,
						@importe=importe,
						@sucursal=idSucursal,
						@unidadNegocio=unidadNegocio,
						@categoriaCobranza=categoriaCobranza,
						@tipoPago=tipoPago
						
					FROM @datosflaptemp
					WHERE rowNumber = @Counter

					
						--Sacar registros de datos flap
					 PRINT 'Paso 1prima'
					 --	SELECT  
						--@fechaPago fechaPago,
						--@cuentaBancaria cuentaBancaria,
						--@idempresa idempresa,
						--@importe importe,
						--@sucursal,
						--@unidadNegocio,
						--@categoriaCobranza,
						--@tipoPago
		IF EXISTS(SELECT * FROM Bancomer where noCuenta = @cuentaBancaria AND importe = @importe AND refampliada LIKE '%Multipagos%' AND fechaOperacion >= @fechaPago AND estatus != 5)
		BEGIN
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		---------------------------------------------------------------------------------------------------------------------------------------------------
		select 'Paso 2 Mailorder'
			SELECT @idbmer=idbmer,@importeBanco=importe FROM Bancomer where noCuenta = @cuentaBancaria AND importe = @importe AND refampliada LIKE '%Multipagos%' AND fechaOperacion >= @fechaPago AND estatus != 5
				
					Delete  from @tempeval;
					insert into @tempeval
					select distinct 
					@idbmer idbmer,
					@importeBanco importeBanco,
					f.fechaPago,
					f.cuentaBancaria,
					f.idEmpresa,
					f.idSucursal,
					f.importe,
					f.unidadNegocio,
					f.categoriacobranza,
					p.idorigen,
					f.tipoPago,
					d.documento,
					d.idCliente,
					r.referencia,
					d.idTipoDocumento
					from datosFlap f
						inner join pago p  on f.referencia = p.referencia and f.numeroOrden=p.idTrans
						inner join Referencia r on f.referencia=r.referencia
						inner join detalleReferencia d on r.idReferencia=d.idReferencia
						where convert(date,f.fechapago)=@fechaPago
						and f.unidadNegocio=@unidadNegocio
						and f.categoriaCobranza=@categoriaCobranza
						and f.tipoPago=@tipoPago
						and estatusProcesado= 0
						and p.idOrigen =4
						
			
			PRINT 'Paso 2 Mailorder'
			Declare @countMO int=1 , @countMOMAX int=0 
			

			select @countMOMAX=max(rowNumber) from @tempeval
			WHILE( @countMO <= @countMOMAX)
					BEGIN
					Declare @documento nvarchar(50),@idcliente int 
					

						select @documento=documento,@idcliente=idcliente,@cuentaBancaria=cuentaBancaria
						  ,@importe=importe
						  ,@idempresa=idEmpresa
						  ,@sucursal=idSucursal
						  ,@fechaPago=fechaPago
						  ,@referencia=referencia
						  ,@unidadNegocio=unidadNegocio
						  ,@categoriaCobranza=categoriaCobranza
						  ,@tipopago=tipoPago
						  ,@idTipoDocumento=idTipoDocumento
						
						from @tempeval where  rowNumber=@countMO
					select *	from @tempeval where  rowNumber=@countMO
					declare @facturada table(documento varchar(20))
					Declare @BaseValidacion varchar(50)
					declare @query nvarchar(max) =''

					SELECT
					@BaseValidacion = nombre_base+'.dbo.'
					FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
					WHERE emp_idempresa = @idEmpresa
					and suc_idsucursal = @Sucursal
					AND tipo = 1
				 if @idTipoDocumento in(4,5)
				 begin
					SET @query  = 
					('select TOP 1 fac.vte_docto
					from '+ @BaseValidacion+'ADE_VTAFI fac
					left join '+ @BaseValidacion+'ADE_CANCFD can
					on fac.VTE_DOCTO = can.CDE_DOCTO
					WHERE VTE_REFERENCIA1 = '''+@documento+'''
					and can.CDE_DOCTO is null and substring(fac.VTE_DOCTO,1,2) collate database_default 
					in (select serie from [dbo].[rel_TipoFacturaDatosFlap] r where  r.idempresa='+convert(nvarchar(2),@idempresa)+' and idsucursal='+convert(nvarchar(2),@sucursal)+' and TipoDocumento='+convert(nvarchar(2),replace(@idTipoDocumento,4,5))+') ')
					
					
				
						

					print @query
					/*LIMPIO LA TABLA*/
					DELETE FROM @facturada;
					/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
					insert @facturada
					EXEC sp_executesql @query
					end
					else if @idTipoDocumento= 3
					begin
						SET @query  = 
					('select TOP 1 fac.vte_docto
					FROM '+ @BaseValidacion+'PAR_PEDMOST p
					inner join '+ @BaseValidacion+'ADE_VTAFI fac on p.PMM_REF2=fac.VTE_DOCTO
					left join '+ @BaseValidacion+'ADE_CANCFD can
					on fac.VTE_DOCTO = can.CDE_DOCTO
					WHERE PMM_NUMERO = '''+@documento+'''
					and can.CDE_DOCTO is null and substring(fac.VTE_DOCTO,1,2) collate database_default 
					in (select serie from [dbo].[rel_TipoFacturaDatosFlap] r where  r.idempresa='+convert(nvarchar(2),@idempresa)+' and idsucursal='+convert(nvarchar(2),@sucursal)+' and TipoDocumento='+convert(nvarchar(2),replace(@idTipoDocumento,4,5))+') ')
					
					
					print @query
					/*LIMPIO LA TABLA*/
					DELETE FROM @facturada;
					/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
					insert @facturada
					EXEC sp_executesql @query
					end
					select * from @facturada
						IF EXISTS(	SELECT TOP 1 *	FROM @facturada	) 
						BEGIN -- INICIO SI EXISTE
						PRINT 'Paso 3 Si existe'
							------------------------------------------------------------------------------------------------------------
							--------------------------------------------------------------------------------------------------------------
							EXECUTE [dbo].[CreaPolizaUNISING_INS] 
							--select
						   @cuentaBancaria
						  ,@importe
						  ,@idempresa
						  ,@sucursal
						  ,@fechaPago
						  ,@referencia
						  ,@unidadNegocio
						  ,@categoriaCobranza
						  ,@tipopago
						  ,@Usuario
						  ,@idbmer
						  select '[dbo].[CreaPolizaUNISING_INS]'
						   ,@cuentaBancaria
						  ,@importe
						  ,@idempresa
						  ,@sucursal
						  ,@fechaPago
						  ,@referencia
						  ,@unidadNegocio
						  ,@categoriaCobranza
						  ,@tipopago
						  ,@Usuario
						  ,@idbmer


					INSERT INTO [dbo].[RelLogMailOrder]
					           ([idbmer]
					           ,[importeBanco]
					           ,[fechaPago]
					           ,[cuentaBancaria]
					           ,[idEmpresa]
					           ,[idSucursal]
					           ,[importe]
					           ,[unidadNegocio]
					           ,[categoriacobranza]
					           ,[idorigen]
					           ,[tipoPago]
					           ,[documento]
					           ,[idCliente]
					           ,[referencia])
   						select [idbmer]
							   ,[importeBanco]
							   ,[fechaPago]
							   ,[cuentaBancaria]
							   ,[idEmpresa]
							   ,[idSucursal]
							   ,[importe]
							   ,[unidadNegocio]
							   ,[categoriacobranza]
							   ,[idorigen]
							   ,[tipoPago]
							   ,[documento]
							   ,[idCliente]
							   ,[referencia]
						
						from @tempeval where  rowNumber=@countMO
							-------------------------------------------------------------------------------------------------------------
							------------------------------------------------------------------------------------------------------------
						End
						else
						BEGIN
						PRINT 'Paso 3 No existe'


-- TODO: Set parameter values here.
						if not exists(select * from ga_corporativa..cxc_refantypag where rap_referenciabancaria=@referencia and rap_importe=@importe)
						begin
						EXECUTE [dbo].[PROCESAMIENTO_MAILORDER_UNI] 
						--select
						   @idEmpresa
						  ,@documento
						  ,@sucursal
						  ,@referencia
						  ,@idTipoDocumento
						  ,@idbmer
						  select '[dbo].[PROCESAMIENTO_MAILORDER_UNI]'
						   ,@idEmpresa
						  ,@documento
						  ,@sucursal
						  ,@referencia
						  ,@idTipoDocumento
						  ,@idbmer
						 End
						 else
						 begin 
						 select 'si existe en refantypag'
						 select *,@idbmer from ga_corporativa..cxc_refantypag where rap_referenciabancaria=@referencia and rap_importe=@importe
						 update datosFlap set estatusProcesado=1 where referencia=@referencia
						 update bancomer set estatus=5 where idbmer=@idbmer
						 end
 

							
					INSERT INTO [dbo].[RelLogMailOrder]
					           ([idbmer]
					           ,[importeBanco]
					           ,[fechaPago]
					           ,[cuentaBancaria]
					           ,[idEmpresa]
					           ,[idSucursal]
					           ,[importe]
					           ,[unidadNegocio]
					           ,[categoriacobranza]
					           ,[idorigen]
					           ,[tipoPago]
					           ,[documento]
					           ,[idCliente]
					           ,[referencia])
   								select [idbmer]
							   ,[importeBanco]
							   ,[fechaPago]
							   ,[cuentaBancaria]
							   ,[idEmpresa]
							   ,[idSucursal]
							   ,[importe]
							   ,[unidadNegocio]
							   ,[categoriacobranza]
							   ,[idorigen]
							   ,[tipoPago]
							   ,[documento]
							   ,[idCliente]
							   ,[referencia]
						from @tempeval where  rowNumber=@countMO
						END
					
				select @countMO
					SET @countMO  = @countMO  + 1 
					END
					
			

			
  END

		---------------------------------------------------------------------------------------------------------------------------------------------------
		---------------------------------------------------------------------------------------------------------------------------------------------------
		
		
				

   
 --   BEGIN TRY
 --     /* COLOCAR AQUI LO DE MAIL ORDER */
	--	  EXEC PROCESAMIENTO_MAILORDER @idempresa
	--END TRY
	--BEGIN CATCH
	--PRINT 'fallo sp PROCESAMIENTO_MAILORDER' + cast(@idempresa as varchar(5))
	--END CATCH
	--=============================================


   select @Counter
SET @Counter  = @Counter  + 1  
END

END
go

