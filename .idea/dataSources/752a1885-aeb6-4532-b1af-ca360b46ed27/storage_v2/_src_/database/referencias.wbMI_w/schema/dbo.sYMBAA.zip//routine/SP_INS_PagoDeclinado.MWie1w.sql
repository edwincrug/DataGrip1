

-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 11-10-2019
-- Description: Inserta la solicitud del metodo imprimeDeclinado de la Pin Pad
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PagoDeclinado] 
	 (		@idTrans numeric(18,0)=0
           ,@autorizacion varchar(20)=NULL
           ,@entidad varchar(10)=NULL
           ,@nodo varchar(10)=NULL
           ,@moneda char(1)=NULL
           ,@servicio varchar(10)=NULL
           ,@tarjeta varchar(100)=NULL
           ,@importe varchar(20)=NULL
           ,@titular varchar(50)=NULL
           ,@plazo varchar(10)=NULL
	)

AS
BEGIN

		BEGIN TRY  --Estar TryCatch
		INSERT INTO [dbo].[PagoDeclinado]
           ([idTrans]
           ,[autorizacion]
           ,[entidad]
           ,[nodo]
           ,[moneda]
           ,[servicio]
           ,[tarjeta]
           ,[importe]
           ,[titular]
           ,[plazo]
           ,[fechaRegistro])
     VALUES
           (@idTrans 
           ,@autorizacion
           ,@entidad 
           ,@nodo 
           ,@moneda 
           ,@servicio 
           ,@tarjeta 
           ,@importe 
           ,@titular 
           ,@plazo 
           ,GETDATE())

		END TRY  
		BEGIN CATCH  
			--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[PagoDeclinado]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro

		END CATCH; --End TryCatch

END
go

