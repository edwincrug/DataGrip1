-- [SEL_DETALLE_REFERENCIA_SP] 42
CREATE PROCEDURE [dbo].[SEL_DETALLE_REFERENCIA_SP]
@idReferencia INT = 0
AS
BEGIN
	DECLARE @tipoDocumento INT
	SELECT	@tipoDocumento = idTipoDocumento  
	FROM	[referencias].DBO.[Referencia] REF
			INNER JOIN [referencias].DBO.[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia
	WHERE	REF.idReferencia = @idReferencia

	IF(@tipoDocumento = 2)
		BEGIN
			SELECT	REF.idReferencia
					,REF.idEmpresa
					,DEREF.idCliente
					,REF.tipoReferencia
					,empresas.emp_nombre
					,sucursales.suc_nombre
					,DEREF.documento
					,departamentos.dep_nombre
					, CONVERT(varchar(50), CONVERT(money, CD.ucn_total), 1) importeDocumento
					,CONVERT(money, CD.ucn_total) as Total
					,(personas.per_nomrazon +' '+ personas.per_paterno +' '+ personas.per_materno) AS nombreCliente
					,DOC.nombreDocumento
					,REF.referencia
					,UPPER(DOC.nombreDocumento) as titulo
			FROM	[referencias].DBO.[Referencia] REF
					INNER JOIN [referencias].DBO.[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia 
					INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = DEREF.idcliente
					INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = REF.idEmpresa
					INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = DEREF.idSucursal
					INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] departamentos  ON departamentos.dep_iddepartamento = DEREF.idDepartamento 
					INNER JOIN [referencias].DBO.[TipoDocumento] DOC ON DOC.idTipoDocumento = DEREF.idTipoDocumento
					INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS C ON C.ucu_foliocotizacion = DEREF.documento COLLATE Modern_Spanish_CI_AS
					INNER JOIN cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES AS CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
			WHERE	REF.idReferencia = @idReferencia
		END
	ELSE 
		BEGIN
			SELECT	REF.idReferencia
					,REF.idEmpresa
					,DEREF.idCliente
					,REF.tipoReferencia
					,empresas.emp_nombre
					,sucursales.suc_nombre
					,DEREF.documento
					,departamentos.dep_nombre
					, CONVERT(varchar(50), CONVERT(money, DEREF.importeDocumento), 1) importeDocumento
					,CONVERT(money, DEREF.importeDocumento) as Total
					,(personas.per_nomrazon +' '+ personas.per_paterno +' '+ personas.per_materno) AS nombreCliente
					,DOC.nombreDocumento
					,REF.referencia
					,UPPER(DOC.nombreDocumento) as titulo
			FROM	[referencias].DBO.[Referencia] REF
					INNER JOIN [referencias].DBO.[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia 
					INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = DEREF.idcliente
					INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = REF.idEmpresa
					INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = DEREF.idSucursal
					INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] departamentos  ON departamentos.dep_iddepartamento = DEREF.idDepartamento 
					INNER JOIN [referencias].DBO.[TipoDocumento] DOC ON DOC.idTipoDocumento = DEREF.idTipoDocumento
			WHERE	REF.idReferencia = @idReferencia
		END
END



go

