




-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 11-10-2019
-- Description: Inserta la respuesta del metodo impresionde de la Pin Pad
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PagoImprime] 
	 (		@idTrans numeric(18,0)=0
           ,@numeroAutorizacion varchar(10)=NULL
           ,@afiliacion varchar(300)=NULL
           ,@comercio varchar(300)=NULL
           ,@criptograma varchar(500)=NULL
           ,@direccion varchar(100)=NULL
           ,@emisor varchar(100)=NULL
           ,@fechaTransaccion varchar(10)=NULL
           ,@fechaVencimiento varchar(10)=NULL
           ,@leyendaFirma varchar(500)=NULL
           ,@horaTransaccion varchar(10)=NULL
           ,@monto varchar(20)=NULL
           ,@promocion varchar(200)=NULL
           ,@razonSocial varchar(100)=NULL
           ,@serie varchar(50)=NULL
           ,@tarjeta nvarchar(100)=NULL
           ,@tarjetaEnmascarada nvarchar(100)=NULL
           ,@tipoOperacion varchar(10)=NULL
		   ,@tipoPago varchar(10)=NULL
           ,@titular varchar(50)=NULL
		   ,@referencia varchar(100)=NULL
           ,@mensaje varchar(300)=NULL
           ,@plan varchar(300)=NULL
           ,@total varchar(20)=NULL
           ,@moneda varchar(20)=NULL
           ,@consulta varchar(50)=NULL
           ,@puntos varchar(50)=NULL
           ,@linea varchar(100)=NULL
           ,@total2 varchar(20)=NULL
           ,@saldoAnteriorPuntos varchar(20)=NULL
           ,@saldoAnteriorPesos varchar(20)=NULL
           ,@saldoActualPuntos varchar(20)=NULL
           ,@saldoActualPesos varchar(20)=NULL
           ,@saldoRedimidoPuntos varchar(20)=NULL
           ,@saldoRedimidoPesos varchar(20)=NULL
           ,@vigencia varchar(10)=NULL
           ,@poolid varchar(20)=NULL
           ,@label varchar(30)=NULL
           ,@aid varchar(30)=NULL
		   ,@respuestaBBVA varchar(max)=NULL
	)

AS
BEGIN

		BEGIN TRY  --Estar TryCatch

			INSERT INTO [dbo].[PagoImprime]
           ([idTrans]
           ,[numeroAutorizacion]
           ,[afiliacion]
           ,[comercio]
           ,[criptograma]
           ,[direccion]
           ,[emisor]
           ,[fechaTransaccion]
           ,[fechaVencimiento]
           ,[leyendaFirma]
           ,[horaTransaccion]
           ,[monto]
           ,[promocion]
           ,[razonSocial]
           ,[serie]
           ,[tarjeta]
           ,[tarjetaEnmascarada]
           ,[tipoOperacion]
		   ,[tipoPago]
           ,[titular]
		   ,[referencia]
           ,[mensaje]
           ,[plan]
           ,[total]
           ,[moneda]
           ,[consulta]
           ,[puntos]
           ,[linea]
           ,[total2]
           ,[saldoAnteriorPuntos]
           ,[saldoAnteriorPesos]
           ,[saldoActualPuntos]
           ,[saldoActualPesos]
           ,[saldoRedimidoPuntos]
           ,[saldoRedimidoPesos]
           ,[vigencia]
           ,[poolid]
           ,[label]
           ,[aid]
		   ,[respuestaBBVA]
           ,[fechaRegistro])
     VALUES
           (
		    @idTrans
           ,@numeroAutorizacion
           ,@afiliacion
           ,@comercio
           ,@criptograma
           ,@direccion
           ,@emisor
           ,@fechaTransaccion
           ,@fechaVencimiento
           ,@leyendaFirma
           ,@horaTransaccion
           ,@monto
           ,@promocion
           ,@razonSocial
           ,@serie
           ,@tarjeta
           ,@tarjetaEnmascarada
           ,@tipoOperacion
		   ,@tipoPago
           ,@titular
		   ,@referencia
           ,@mensaje
           ,@plan
           ,@total
           ,@moneda
           ,@consulta
           ,@puntos
           ,@linea
           ,@total2
           ,@saldoAnteriorPuntos
           ,@saldoAnteriorPesos
           ,@saldoActualPuntos
           ,@saldoActualPesos
           ,@saldoRedimidoPuntos
           ,@saldoRedimidoPesos
           ,@vigencia
           ,@poolid
           ,@label
           ,@aid
		   ,@respuestaBBVA
           ,GETDATE()
		   )

		END TRY  
		BEGIN CATCH  
			--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[PagoImprime]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro

		END CATCH; --End TryCatch

END
go

