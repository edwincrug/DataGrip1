-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	INSERTA EN REFANTYPAG LAS REFERENCIAS QUE VENGAN DE DATOSFLAP
--              QUE SEAN DE TIPO MAILORDER Y QUE NO ESTEN FACTURADAS PARA 
--				SERVICIOS Y REFACCIONES
-- [PROCESAMIENTO_MAILORDER] 10
-- =============================================
--
CREATE PROCEDURE [dbo].[PROCESAMIENTO_MAILORDER_UNI] 
	@idEmpresa INT,
	@documento nvarchar(50),
	@idSucursal int,
	@referenciaPorProcesar  NVARCHAR(50),
	@tipodocumento int,
	@idDeposito int
AS
BEGIN
--declare @idEmpresa INT=5,
--	@documento nvarchar(50)='N00020064',
--	@idSucursal int=18,
--	@referenciaPorProcesar  NVARCHAR(50)='09TF150B1IC100200646',
--	@tipodocumento int=3,
--	@idDeposito int=383113
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		DECLARE @FacturaQuery VARCHAR(MAX) = '';
		  DECLARE @Base VARCHAR(MAX) = '';
		  
		  DECLARE @idBanco INT = 1;

		  DECLARE @countDep INT = 0;
		  DECLARE @rap_folio INT = 0;
		 
		  -- Consulta de las bases de datos y sucursales activas
		  DECLARE @tableConf TABLE (
			idEmpresa INT
		   ,idSucursal INT
		   ,servidor VARCHAR(250)
		   ,baseConcentra VARCHAR(250)
		   ,sqlCmd VARCHAR(8000)
		   ,cargaDiaria VARCHAR(8000)
		  );
	
	
		
		  PRINT ('========================= [ RAP_Automaticas Mail Order _Bancomer_SP ] =========================');
		  PRINT ('EMPRESA ' + CONVERT(VARCHAR(2), @idEmpresa) + ': SUCURSALES ' + CONVERT(VARCHAR(3), @idSucursal));

		


		 declare @idEmpresaBD int, @idSucursalBD int, @BaseValidacion varchar(50)

		 declare @facturada table(documento varchar(20))
		 declare @query nvarchar(max) =''

		

		 -- print @FacturaQuery

		  -- Inicia segundo While
		  /*
		  VALIDAMOS QUE LA REFERENCIA SEA DE FLAP - MAILORDER
		  */
		  DECLARE @tableBancoPedidoMailOrder table( 
		  consecutivo INT IDENTITY (1, 1)
		   ,idDeposito INT
		   ,referencia varchar(50)
		   ,documento varchar(50)
		   ,idEmpresa int
		   ,idSucursal int)


		 if @tipodocumento = 3
		 --- INICIO WHILE MAIL-ORDER
		  BEGIN
		  -- Funcionamiento de meter en cxc_refantypag
		  BEGIN TRY

			/*obtenemos el documento de la referencia*/

			SELECT
			  @BaseValidacion = nombre_base+'.dbo.'
			FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
			WHERE emp_idempresa = @idEmpresa
			and suc_idsucursal = @idSucursal
			AND tipo = 1
			SELECT @idEmpresa,@idSucursal,
			  @BaseValidacion
			SET @query  = 	('select TOP 1 fac.vte_docto
					from '+ @BaseValidacion+'ADE_VTAFI fac
					left join '+ @BaseValidacion+'ADE_CANCFD can
					on fac.VTE_DOCTO = can.CDE_DOCTO
					WHERE VTE_REFERENCIA1 = '''+@documento+'''
					and can.CDE_DOCTO is null and substring(fac.VTE_DOCTO,1,2) collate database_default 
					in (select serie from [dbo].[rel_TipoFacturaDatosFlap] r where  r.idempresa='+convert(nvarchar(2),@idempresa)+' and idsucursal='+convert(nvarchar(2),@idsucursal)+' and TipoDocumento='+convert(nvarchar(2),replace(@tipodocumento,4,5))+') ')
					
					

			print @query
			/*LIMPIO LA TABLA*/
			DELETE FROM @facturada;
			/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
			insert @facturada
			EXEC sp_executesql @query

			/*SI LA TABLA TIENE DATOS QUIERE DECIR QUE YA SE FACTURO, DE LO CONTRARIO NO ESTA FACTURADA*/
			--SELECT * FROM @facturada

			/*validamos que no este facturada*/
			IF NOT EXISTS(
				SELECT TOP 1 * FROM @facturada
			) BEGIN

				SELECT
				  @FacturaQuery = [dbo].[fnReferenciaBancomerPedidoMailOrder](@BaseValidacion, @referenciaPorProcesar,@idDeposito);
				  /*COMENTAR ESTO EN PRODUCCION*/
	    		--	SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
				--//////////////////////////
				EXECUTE (@FacturaQuery);
				PRINT @FacturaQuery
				  IF (@@ROWCOUNT > 0)
					BEGIN
					  SET @rap_folio = @@IDENTITY;
					  INSERT INTO [referencias].[dbo].[RAPDeposito] (idEmpresa, idSucursal, rap_folio, idBanco, idDeposito, idOrigenReferencia, fecha)
						VALUES (@idEmpresa, @idSucursal, @rap_folio, @idBanco, @idDeposito, 'Procesos Automáticos | MAILORDER', GETDATE());
					  --UPDATE [referencias].[dbo].[Bancomer]
					  --SET estatusRevision = 2
					  --WHERE idBmer = @idDeposito;
					END
					--PRINT (@FacturaQuery);
					PRINT ('        SUCCESS: Depósito [' + CONVERT(VARCHAR(10), @idDeposito) + '] PEDIDO: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio));

			END

		  END TRY
		  BEGIN CATCH
			INSERT INTO LogRAP (log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal)
			  VALUES (ERROR_MESSAGE(), 'Procesos Automáticos | PEDIDO', GETDATE(), @idBanco, @idDeposito, @idEmpresa, @idSucursal);
			PRINT ('        ERROR: Depósito [' + CONVERT(VARCHAR(10), @idDeposito) + '] PEDIDO: ' + ERROR_MESSAGE());
		  END CATCH
 
		 

		  END
		  else
		   if @tipodocumento in (4,5)
		   Begin
  			  -- Funcionamiento de meter en cxc_refantypag
				  BEGIN TRY
					SELECT
					  @BaseValidacion = nombre_base+'.dbo.'
					FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
					WHERE emp_idempresa = @idEmpresa
					and suc_idsucursal = @idSucursal
					AND tipo = 1

					SET @query  = 	('select TOP 1 fac.vte_docto
					from '+ @BaseValidacion+'ADE_VTAFI fac
					left join '+ @BaseValidacion+'ADE_CANCFD can
					on fac.VTE_DOCTO = can.CDE_DOCTO
					WHERE VTE_REFERENCIA1 = '''+@documento+'''
					and can.CDE_DOCTO is null and substring(fac.VTE_DOCTO,1,2) collate database_default 
					in (select serie from [dbo].[rel_TipoFacturaDatosFlap] r where  r.idempresa='+convert(nvarchar(2),@idempresa)+' and idsucursal='+convert(nvarchar(2),@idsucursal)+' and TipoDocumento='+convert(nvarchar(2),replace(@tipodocumento,4,5))+') ')
	

					print @query
					/*LIMPIO LA TABLA*/
					DELETE FROM @facturada;
					/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
					insert @facturada
					EXEC sp_executesql @query

					/*SI LA TABLA TIENE DATOS QUIERE DECIR QUE YA SE FACTURO, DE LO CONTRARIO NO ESTA FACTURADA*/
					SELECT * FROM @facturada

					/*validamos que no este facturada*/
					IF NOT EXISTS(
						SELECT TOP 1 *
						FROM @facturada
					) BEGIN -- INICIO SI EXISTE

					  print @referenciaPorProcesar

						SELECT
						  @FacturaQuery = [dbo].[fnReferenciaBancomerOrdenMailOrder](@BaseValidacion, @referenciaPorProcesar,@idDeposito);

						  --SELECT
						  --@FacturaQuery = [dbo].[fnReferenciaBancomerOrdenMailOrder](@Base,@idDeposito);
				
						/*COMENTAR ESTO EN PRODUCCION*/
	    				--SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						--//////////////////////////
						INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )
						EXECUTE (@FacturaQuery);
						PRINT '@FacturaQuery: '+ @FacturaQuery
						print '@@ROWCOUNT: '+ cast(@@IDENTITY as varchar(10))
						IF (@@IDENTITY > 0)
						BEGIN
						  SET @rap_folio = @@IDENTITY;
						  select @rap_folio as rap_folio
						  INSERT INTO [referencias].[dbo].[RAPDeposito] (idEmpresa, idSucursal, rap_folio, idBanco, idDeposito, idOrigenReferencia, fecha)
							VALUES (@idEmpresa, @idSucursal, @rap_folio, @idBanco, @idDeposito, 'Procesos Automáticos | MAILORDER', GETDATE());
						  --UPDATE [referencias].[dbo].[Bancomer]
						  --SET estatusRevision = 2
						  --WHERE idBmer = @idDeposito;
						END
						PRINT (@FacturaQuery);
						PRINT ('        SUCCESS: Depósito [' + CONVERT(VARCHAR(10), @idDeposito) + '] ORDEN: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio));

					END -- FIN SI EXISTE
				  END TRY
				  BEGIN CATCH
					INSERT INTO LogRAP (log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal)
					  VALUES (ERROR_MESSAGE(), 'Procesos Automáticos | ORDEN', GETDATE(), @idBanco, @idDeposito, @idEmpresa, @idSucursal);
					PRINT ('        ERROR: Depósito [' + CONVERT(VARCHAR(10), @idDeposito) + '] ORDENg: ' + ERROR_MESSAGE());
				  END CATCH
	  
  
				-- FIN WHILE MAIL-ORDER
		  END


END
go

