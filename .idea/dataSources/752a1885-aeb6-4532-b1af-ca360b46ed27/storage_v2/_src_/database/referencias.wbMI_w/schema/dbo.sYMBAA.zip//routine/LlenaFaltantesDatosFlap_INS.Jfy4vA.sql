-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<crea poliza de la tabla [dbo].[datosFlap]>
-- =============================================
 --[dbo].[LlenaFaltantesDatosFlap_INS] '15/10/2020'
CREATE PROCEDURE [dbo].[LlenaFaltantesDatosFlap_INS]
@fecha date
AS
BEGIN

	--drop table #tempData
	--Declare @fecha date='29/08/2020'
	Declare @serverDB varchar(200) 
	,@ipDB varchar(200) 
	,@idempresa int
	,@idsucursal int
	,@unidadNegocio int
	,@categoriaCobranza int
	,@tipoPago nvarchar(20)
	DECLARE @datosflapBP TABLE (
	id int identity,
	referencia [nvarchar](50),
	idtrans [int],
	[importe] [decimal](18, 2) ,
	documento nvarchar(50)
)

	select  ROW_NUMBER() OVER(
			ORDER BY unidadNegocio,categoriaCobranza) AS RowNum,convert(date,fechapago) fechapago,unidadNegocio,categoriaCobranza,idempresa,idsucursal,SUM(IMPORTE) IMPORTE 
			into #tempData
			from datosFlap d
	where  convert(date,fechapago)=@fecha and estatusProcesado=0
	--and unidadNegocio=3
	GROUP BY convert(date,fechapago),unidadNegocio,categoriaCobranza,idempresa,idsucursal
	DECLARE @Counter INT ,@CounterMax INT ,@query varchar(max)
	--select * from #tempData
	select @CounterMax=max(rownum) from #tempData
	SET @Counter=1
	WHILE ( @Counter <= @CounterMax)
	BEGIN
		select @idempresa=idEmpresa,@idsucursal=idSucursal,@unidadNegocio=unidadNegocio,@categoriaCobranza=categoriaCobranza from #tempdata where rownum=@counter
		select @serverDB=nombre_base from Centralizacionv2..dig_cat_bases_bpro where emp_idempresa=@idempresa and suc_idsucursal=@idsucursal and tipo=1

		SET @query  = 
	('SELECT RX.referencia,PA.idTrans,PA.IMPORTE,RX.documento FROM '+@serverDB+'.DBO.ADE_VTAFI V INNER JOIN '+@serverDB+'.DBO.ADE_VTAFP P ON V.VTE_DOCTO = P.VFP_DOCTO
	INNER JOIN '+@serverDB+'.DBO.PNC_PARAMETR R ON P.VFP_TIPOPAGO =  R.PAR_IDENPARA 
	inner join (select d.documento,referencia,r.idEmpresa,d.idSucursal from Referencia r inner join DetalleReferencia d on r.idReferencia=d.idReferencia ) rx
	on  rx.documento like ''%''+substring(v.VTE_DOCTO,1,2)+''%''+replace(ltrim(replace(substring(v.vte_docto,3,len(vte_docto)-2),''0'','' '')),'' '',''0'') collate database_default
	inner join referencias..Pago pa on rx.referencia=pa.referencia and v.VTE_TOTAL=pa.IMPORTE
	WHERE VTE_FECHDOCTO ='''+convert(nvarchar(10),@fecha,103)+''' AND PAR_TIPOPARA = ''FP'' AND PAR_DESCRIP1 LIKE ''%PINPAD%''')

	print @query
	/*LIMPIO LA TABLA*/
	DELETE FROM @datosflapBP;
	/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
	insert @datosflapBP
	EXEC( @query)

	--select * from @datosflapBP
	INSERT INTO [dbo].[datosFlap]
				([fechaPago]
				,[nombreRazonSocial]
				,[unidadNegocio]
				,[categoriaCobranza]
				,[tipoPago]
				,[referencia]
				,[numeroOrden]
				,[aprobacionBancaria]
				,[identificadorVenta]
				,[referenciaMedioDePago]
				,[importe]
				,[comision]
				,[ivaComision]
				,[fechaDispersion]
				,[periodoFinanciamiento]
				,[moneda]
				,[bancoEmisor]
				,[nombrePagador]
				,[mail]
				,[telefono]
				,[cuentaBancaria]
				,[idEmpresa]
				,[idSucursal]
				,[idBanco]
				,[referenciaConciliacion]
				,[estatusProcesado]
				,[fechaInsercion])
 
		select  
				d.[fechaPago]
				,d.[nombreRazonSocial]
				,d.[unidadNegocio]
				,d.[categoriaCobranza]
				,d.[tipoPago]
				,z.referencia [referencia]
				,z.idtrans [numeroOrden]
				,d.[aprobacionBancaria]
				,d.[identificadorVenta]
				,'*'[referenciaMedioDePago]
				,z.importe [importe]
				,d.[comision]
				,d.[ivaComision]
				,d.[fechaDispersion]
				,d.[periodoFinanciamiento]
				,d.[moneda]
				,d.[bancoEmisor]
				,d.[nombrePagador]
				,d.[mail]
				,d.[telefono]
				,d.[cuentaBancaria]
				,d.[idEmpresa]
				,d.[idSucursal]
				,d.[idBanco]
				,d.[referenciaConciliacion]
				,0 [estatusProcesado]
				,d.[fechaInsercion] from datosFlap d
				cross join (
				select b.referencia,b.idtrans,b.importe,b.documento,d.id_registro from @datosflapBP b 
				left join datosFlap d on b.referencia=d.referencia and convert(date,d.fechapago)=@fecha and d.unidadNegocio=@unidadNegocio and d.categoriaCobranza=@categoriaCobranza
				where d.id_registro is null

				) z
				where  convert(date,fechapago)=@fecha and unidadNegocio=@unidadNegocio and categoriaCobranza=@categoriaCobranza and d.id_registro in(select TOP 1 id_registro from datosflap where  convert(date,fechapago)=@fecha and unidadNegocio=@unidadNegocio and categoriaCobranza=@categoriaCobranza)


		SET @Counter  = @Counter  + 1
	END

END





--select * from datosFlap d
--where  convert(date,fechapago)='2020-08-28' and unidadNegocio=3 --and categoriaCobranza in(11)
--select sum(d.importe) from datosFlap d
--inner join Pago p on d.referencia=p.referencia
--where unidadNegocio=3  and convert(date,fechapago)='2020-08-28' 
--select * from bancomer where fechaOperacion>='2020-08-20' and refAmpliada like '%multipago%' and noCuenta='000000000195334667' and importe=11704.99
--select * from gaau_concentra.[dbo].CON_MOVDET012020 where MOV_TIPOPOL = 'SALDOINGun'  and mov_mes=9  and MOV_CONSPOL=11


go

