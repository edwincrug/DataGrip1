-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 11-09-2019
-- Description:	obtiene el servicio mediando una clave
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_SucursalFlap]
(
	@idSucursal int=0
)
AS
BEGIN

BEGIN TRY  --Star TryCatch
		SELECT TOP (1) 
				[Id]
				,[Nivel]
		FROM [referencias].[dbo].[CatalogoSucursalFlap]
		WHERE [Id]=@idSucursal

END TRY  
BEGIN CATCH  
    SELECT  
        ERROR_NUMBER() AS ErrorNumber  
        ,ERROR_SEVERITY() AS ErrorSeverity  
        ,ERROR_STATE() AS ErrorState  
        ,ERROR_PROCEDURE() AS ErrorProcedure  
        ,ERROR_LINE() AS ErrorLine  
        ,ERROR_MESSAGE() AS ErrorMessage;  
END CATCH; --End TryCatch

END
go

