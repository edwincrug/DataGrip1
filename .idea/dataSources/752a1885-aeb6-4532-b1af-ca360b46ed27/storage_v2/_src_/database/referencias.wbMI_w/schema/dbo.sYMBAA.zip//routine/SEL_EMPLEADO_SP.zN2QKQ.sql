CREATE PROCEDURE [dbo].[SEL_EMPLEADO_SP]
	@idEmpleado  int = 0
AS
BEGIN
	SET NOCOUNT ON;


      SELECT  U.usu_idusuario AS idusuario
			, U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS nombre
			, U.usu_correo AS correo
			, U.dep_iddepartamento AS iddepartamento
			, D.suc_idsucursal AS idsucursal
			, S.emp_idempresa
		FROM  ControlAplicaciones.dbo.cat_usuarios U INNER JOIN
			  ControlAplicaciones.dbo.cat_departamentos D ON U.dep_iddepartamento = D.dep_iddepartamento INNER JOIN
			  ControlAplicaciones.dbo.cat_sucursales S ON D.suc_idsucursal = S.suc_idsucursal
		WHERE U.usu_idusuario = @idEmpleado OR @idEmpleado = 0
END
go

