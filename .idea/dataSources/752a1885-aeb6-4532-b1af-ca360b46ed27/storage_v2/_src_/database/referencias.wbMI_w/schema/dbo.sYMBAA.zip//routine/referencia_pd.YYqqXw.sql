-- =============================================
-- Author:		
-- Create date: 21092016
-- Description:	genera y regresa referencia bancaria
-- =============================================
-- select [dbo].[referencia_pd]('019679',45,23,2,4)
CREATE FUNCTION [dbo].[referencia_pd]
(	
	@serie VARCHAR(8),
	@idDepartamento int = 0,
	@idSucursal int = 0,
	@tipo INT = 0,
	@idTipoReferencia varchar(2)
	--@consecutivo TINYINT = 0
)
RETURNS VARCHAR(19)
AS
BEGIN	
	
	DECLARE @referencia VARCHAR(19) = '' 
	declare @tipoDoc varchar(1) = '';

	SET @serie = REPLICATE('0',7-LEN(@serie)) + CONVERT(VARCHAR(7),@serie)  

	if @tipo = 3
		
		set @tipoDoc = 'P';
	else
		set @tipoDoc = 'C';
		         
	SELECT  @referencia = --0 +
		 REPLICATE('0',1-LEN(CONVERT(VARCHAR(1),CONVERT(VARCHAR(1),0)))) + CONVERT(VARCHAR(1),0) +
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(MM,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(MM,GETDATE())),'0123456789AB') + -- conversion a base 12
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(DD,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(DD,GETDATE())),'0123456789ABCDEFGHIJKLMNOPQRSTUV') + -- conversion a base 31
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE())) ,'0123456789ABCDEFGHIJKLMN') + -- conversion a base 24
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())) + -- conversión base 10
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),CONVERT(VARCHAR(2),[dbo].[intToBase]( @idSucursal ,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'))))) + CONVERT(VARCHAR(2),[dbo].[intToBase]( @idSucursal ,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ')) + --conversión a base 36, investigar que es Suc
		 --REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),CONVERT(VARCHAR(2),@consecutivo)))) + CONVERT(VARCHAR(2),@consecutivo) +  
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),CONVERT(VARCHAR(2),[dbo].[intToBase]( @idDepartamento ,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'))))) + CONVERT(VARCHAR(2),[dbo].[intToBase]( @idDepartamento ,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ')) + --conversión a base 36, investigar que es Dep
		 @tipoDoc + @idTipoReferencia + @serie 
	RETURN @referencia
END
go

