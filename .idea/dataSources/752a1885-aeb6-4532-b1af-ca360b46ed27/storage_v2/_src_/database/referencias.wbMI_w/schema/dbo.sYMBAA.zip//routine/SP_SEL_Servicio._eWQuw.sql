

-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 11-09-2019
-- Description:	obtiene el servicio mediando una clave
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_Servicio]
(
	@clave int=7
)
AS
BEGIN

BEGIN TRY  --Estar TryCatch
		SELECT TOP (1) [Clave],[Servicio] FROM [referencias].[dbo].[CatalogoServicios] WHERE Clave=@clave;
END TRY  
BEGIN CATCH  
    SELECT  
        ERROR_NUMBER() AS ErrorNumber  
        ,ERROR_SEVERITY() AS ErrorSeverity  
        ,ERROR_STATE() AS ErrorState  
        ,ERROR_PROCEDURE() AS ErrorProcedure  
        ,ERROR_LINE() AS ErrorLine  
        ,ERROR_MESSAGE() AS ErrorMessage;  
END CATCH; --End TryCatch



	

END
go

