CREATE PROCEDURE [dbo].[INS_APLICA_REFERENCIAS_REFANTIPAGTESORERIA_SP]
@idReferencia INT
as
begin
insert into GA_Corporativa.dbo.cxc_refantypag
SELECT
	rap_idempresa = R.idEmpresa,
	rap_idsucursal = DR.idSucursal,
	rap_iddepartamento = DR.idDepartamento,
	rap_idpersona = DR.idCliente,
	rap_cobrador = 'MMK',
	rap_moneda = 'PE',
	rap_tipocambio = 1,
	rap_referencia = left(ltrim(B.refAmpliada),20) COLLATE SQL_Latin1_General_CP1_CI_AS,
	rap_iddocto =  dr.documento,	rap_cotped = '',
	rap_consecutivo = isnull((SELECT CCP_CONSCARTERA FROM GAAU_UNIVERSIDAD..VIS_CONCAR01 WHERE CCP_VFDOCTO COLLATE Modern_Spanish_CS_AS = DR.documento AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente),0),
	rap_importe = convert(decimal,b.importe),
	rap_formapago = (select top 1  co.CodigoBPRO  from Bancomer b inner join  CodigoIdentificacion co  on co.CodigoBanco = b.codigoLeyenda where b.referencia =  R.referencia),
	rap_numctabanc = SUBSTRING(txtOrigen,5,20),
	rap_fecha = GETDATE(),
	rap_idusuari = (SELECT usu_idusuario FROM ControlAplicaciones..cat_usuarios WHERE usu_nombreusu = 'GMI'),
	rap_idstatus = '1',
	rap_banco = C.IdBanco_bpro,
	rap_referenciabancaria = R.referencia,
	rap_anno = isnull( (SELECT Vcc_Anno FROM GAAU_UNIVERSIDAD..VIS_CONCAR01 WHERE CCP_VFDOCTO COLLATE Modern_Spanish_CS_AS = DR.documento  AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente),year(getdate())) 
FROM Referencia R 
INNER JOIN BANCOMER B 
ON R.Referencia = b.referencia --SUBSTRING(b.concepto,3,20)
INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP 
ON R.idEmpresa = BP.emp_idempresa 
INNER JOIN Rel_BancoCobro C 
ON R.idEmpresa = C.emp_idempresa
INNER JOIN DetalleReferencia DR
ON  DR.idReferencia = R.idReferencia
AND DR.idSucursal = BP.suc_idsucursal
WHERE B.estatus = 1  
AND DR.idTipoDocumento = 1
AND C.IdBanco = 1
AND R.tipoReferencia in (3,4)
AND R.idReferencia =@idReferencia 

end
go

