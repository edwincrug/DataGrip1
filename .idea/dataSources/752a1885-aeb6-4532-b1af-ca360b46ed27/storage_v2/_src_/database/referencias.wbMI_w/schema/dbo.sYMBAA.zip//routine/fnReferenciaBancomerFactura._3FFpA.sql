--print [dbo].[fnReferenciaBancomerFactura]('GAZM_Concentra.dbo',206243,'07TC490610BA00096665')
CREATE FUNCTION [dbo].[fnReferenciaBancomerFactura](
	@CurrentBase varchar(50),
	@idDeposito NUMERIC(18),
	@referencia nvarchar(20)
)  
RETURNS varchar(max)   
AS   
-- Returns the stock level for the product.
BEGIN  
	DECLARE @queryText VARCHAR(MAX);
	DECLARE @validaId  VARCHAR(MAX);
	
	DECLARE @DepartamentosNissan VARCHAR(MAX) = 
'CASE R.idEmpresa  ' + char(13) + 
'WHEN 2 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'		CASE DR.idSucursal ' + char(13) + 
'			WHEN 4 THEN 16 ' + char(13) + 
'		END ' + char(13) + 
'	) ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'WHEN 3 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'		CASE DR.idSucursal ' + char(13) + 
'			WHEN 5 THEN 21 ' + char(13) + 
'		END ' + char(13) + 
'	) ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'WHEN 4 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'		CASE DR.idSucursal ' + char(13) + 
'			WHEN 6 THEN 26 ' + char(13) + 
'			WHEN 7 THEN 31 ' + char(13) + 
'			WHEN 8 THEN 36 ' + char(13) + 
'		END ' + char(13) + 
'	) ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'WHEN 5 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'		CASE DR.idSucursal ' + char(13) + 
'			WHEN 9 THEN 41 ' + char(13) + 
'			WHEN 10 THEN 46 ' + char(13) + 
'			WHEN 11 THEN 51 ' + char(13) + 
'		END ' + char(13) + 
'	) ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'WHEN 6 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'		CASE DR.idSucursal ' + char(13) + 
'			WHEN 12 THEN 56 ' + char(13) + 
'			WHEN 13 THEN 61 ' + char(13) + 
'			WHEN 14 THEN 66 ' + char(13) + 
'		END ' + char(13) + 
'	) ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'WHEN 8 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'		CASE DR.idSucursal ' + char(13) + 
'			WHEN 17 THEN 81 ' + char(13) + 
'		END ' + char(13) + 
'	) ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'WHEN 9 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'		CASE DR.idSucursal ' + char(13) + 
'			WHEN 18 THEN 86 ' + char(13) + 
'			WHEN 19 THEN 91 ' + char(13) + 
'			WHEN 20 THEN 96 ' + char(13) + 
'			WHEN 21 THEN 105 ' + char(13) + 
'		END ' + char(13) + 
'	) ' + char(13) + 
'WHEN ''US'' THEN ( ' + char(13) + 
'CASE DR.idSucursal ' + char(13) + 
'WHEN 18 THEN 86 ' + char(13) + 
'WHEN 19 THEN 91 ' + char(13) + 
'WHEN 20 THEN 96 ' + char(13) + 
'WHEN 21 THEN 105 ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'WHEN 10 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'			CASE DR.idSucursal ' + char(13) + 
'				WHEN 22 THEN 110 ' + char(13) + 
'				WHEN 23 THEN 115 ' + char(13) + 
'			END ' + char(13) + 
'		) ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'WHEN 11 THEN ( ' + char(13) + 
'CASE (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) ' + char(13) + 
'WHEN ''OT'' THEN ( ' + char(13) + 
'			CASE DR.idSucursal ' + char(13) + 
'				WHEN 25 THEN 125 ' + char(13) + 
'			END ' + char(13) + 
'		) ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
'END ' + char(13) + 
') ' + char(13) + 
'ELSE CONVERT(VARCHAR(18),DR.idDepartamento) ' + char(13) + 
						'END';
	
	DECLARE @RAPreferencia VARCHAR(MAX) = 
	'CASE  -- Unidades Nuevas y Seminuevas
						WHEN (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT CONVERT(VARCHAR(18),ucu_idcotizacion) FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DR.documento ) IS NOT NULL
										 THEN (SELECT ucu_foliocotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL WHERE ucu_idcotizacion = (SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DR.documento)) COLLATE Modern_Spanish_CS_AS
										ELSE DR.documento
									END
								)
						ELSE DR.documento
				   END';
	
	DECLARE @RAPiddocto VARCHAR(MAX) = 
	'CASE  -- Unidades Nuevas y Seminuevas
						WHEN (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DR.documento ) IS NOT NULL
										 THEN DR.documento
										ELSE ''''
									END
								)
						ELSE ''''
				   END';
	
	DECLARE @RAPcotped VARCHAR(MAX) = 
	'CASE  -- Unidades Nuevas y Seminuevas
						WHEN (SELECT dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DR.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DR.documento ) IS NOT NULL
										 THEN ''COTIZACION UNIVERSAL''
										ELSE ''''
									END
								)
						ELSE ''''
				   END';
				   
	DECLARE @Consecutivo VARCHAR(MAX) = '( SELECT
													CASE WHEN MAX(RAP_NumDeposito) IS NULL
														THEN 1
													ELSE (MAX(RAP_NumDeposito) + 1 ) END
												FROM GA_Corporativa.DBO.cxc_refantypag
												WHERE rap_referenciabancaria = R.referencia)';
	
	SET @queryText =
		-- 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno )'+ char(13) + -- DESCOMENTAR LINEA
		'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )'+ char(13) + -- DESCOMENTAR LINEA
		'SELECT' + char(13) + 
		'	rap_idempresa		= R.idEmpresa,' + char(13) + 
		'	rap_idsucursal		= DR.idSucursal,' + char(13) + 
		'	rap_iddepartamento	= '+ @DepartamentosNissan +',' + char(13) + 
		'	rap_idpersona		= DR.idCliente,' + char(13) + 
		'	rap_cobrador		= '+char(39)+'MMK'+char(39)+',' + char(13) + 
		'	rap_moneda			= '+char(39)+'PE'+char(39)+',' + char(13) + 
		'	rap_tipocambio		= 1,' + char(13) + 
		'	-- rap_referencia		= ltrim(B.refAmpliada) COLLATE SQL_Latin1_General_CP1_CI_AS, ' + char(13) + 
		'	rap_referencia		= '+ @RAPreferencia +',' + char(13) + 
		'	-- rap_iddocto			=  dr.documento,'+ char(13) + 
		'	rap_iddocto			=  '+ @RAPiddocto +','+ char(13) + 
		'	-- rap_cotped			= '+char(39)+''+char(39)+',' + char(13) + 		
		'	rap_cotped			= '+ @RAPcotped +',' + char(13) + 		
		'	---rap_consecutivo		= (SELECT CCP_CONSCARTERA FROM '+ @CurrentBase +'.VIS_CONCAR01 WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente),' + char(13) + 
		'	rap_consecutivo		= 400000,' + char(13) + 
		'	rap_importe			= convert(numeric(18,2),b.importe),' + char(13) + 
		'	rap_formapago		= (select top 1 co.CodigoBPRO  from Bancomer b inner join  CodigoIdentificacion co  on co.CodigoBanco = b.codigoLeyenda where B.idBmer	 =  ' + CONVERT( VARCHAR( 18 ), @idDeposito )+'),' + char(13) + 
		'	rap_numctabanc		= SUBSTRING(txtOrigen,5,20),' + char(13) + 
		'	rap_fecha			= GETDATE(),' + char(13) + 
		'	rap_idusuari		= (SELECT usu_idusuario FROM ControlAplicaciones..cat_usuarios WHERE usu_nombreusu = '+char(39)+'GMI'+char(39)+'),' + char(13) + 
		'	rap_idstatus		= '+char(39)+'1'+char(39)+',' + char(13) + 
		--'	rap_banco			= C.IdBanco_bpro,' + char(13) + 
		'	rap_banco = (SELECT idBancoBPRO FROM referencias.dbo.BancoCuenta WHERE idEmpresa = R.idEmpresa AND idBanco = B.idBanco AND numeroCuenta = B.noCuenta),' + char(13) + 
		'	rap_referenciabancaria	= R.referencia,' + char(13) + 	  
		'	---rap_anno				= (SELECT Vcc_Anno FROM '+ @CurrentBase +'.VIS_CONCAR01 WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente) ' + char(13)+
		'	rap_anno				= 9999, ' + char(13)+
		'	RAP_AplicaPago = convert(numeric(18,2),b.importe),' + char(13) + 
		'	RAP_NumDeposito = ' + @Consecutivo + ' ' + char(13) + 
		'FROM Referencia R ' + char(13) + 
		'INNER JOIN Bancomer							B		ON	R.Referencia = '''+@referencia+''' ' + char(13) + 
		'INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP		ON	R.idEmpresa = BP.emp_idempresa ' + char(13) + 
		--'LEFT JOIN Rel_BancoCobro						 C		ON	R.idEmpresa = C.emp_idempresa' + char(13) + 
		'INNER JOIN DetalleReferencia					 DR		ON	DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal' + char(13) + 
		'WHERE B.estatusRevision			= 1 ' + char(13) + 
		'	   AND B.esCargo			= 0 ' + char(13) + 
		'	   AND DR.idTipoDocumento	= 1' + char(13) + 
		'	   AND B.IdBanco			= 1' + char(13) +
		'	   AND (SELECT CCP_CONSCARTERA FROM '+ @CurrentBase +'.VIS_CONCAR01 WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DR.documento AND CCP_IDPERSONA = DR.IdCliente) IS not NULL' + char(13) +
		'	   AND B.idBmer		= ' + CONVERT( VARCHAR( 18 ), @idDeposito ) + char(13)
		
    RETURN @queryText
END;



go

