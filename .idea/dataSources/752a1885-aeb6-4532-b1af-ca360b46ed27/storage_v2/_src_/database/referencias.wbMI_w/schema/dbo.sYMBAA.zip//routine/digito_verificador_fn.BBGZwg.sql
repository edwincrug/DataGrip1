-- =============================================
-- Author:		ALEJANDRO LOPEZ
-- Create date: 27052016
-- Description:	genera y regresa digito verificador
-- =============================================

--select [dbo].[digito_verificador_fn]('09LC3214000AA123456')


 
CREATE FUNCTION [dbo].[digito_verificador_fn]
(	
	@referencia VARCHAR(20)
)
RETURNS CHAR(1)
AS
BEGIN

	DECLARE @letrasNumeros TABLE(num CHAR(1), letra VARCHAR(4))
	--declare @referencia varchar(20)
	--set @referencia = '09LC3214000AA123456'
	--select @referencia
	INSERT INTO @letrasNumeros VALUES('1','1AJS') INSERT INTO @letrasNumeros VALUES('2','2BKT') INSERT INTO @letrasNumeros VALUES('3','3CLU')
	INSERT INTO @letrasNumeros VALUES('4','4DMV') INSERT INTO @letrasNumeros VALUES('5','5ENW') INSERT INTO @letrasNumeros VALUES('6','6FOX')
	INSERT INTO @letrasNumeros VALUES('7','7GPY') INSERT INTO @letrasNumeros VALUES('8','8HQZ') INSERT INTO @letrasNumeros VALUES('9','9IR')
	INSERT INTO @letrasNumeros VALUES('0','0')
	
	--DECLARE @serie VARCHAR(3) = SUBSTRING(@referencia,11,3)

	DECLARE @serie VARCHAR(19) = @referencia
		
	SELECT @serie = (SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,1,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,2,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,3,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,4,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,5,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,6,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,7,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,8,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,9,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,10,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,11,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,12,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,13,1) + '%') +
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,14,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,15,1) + '%') +
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,16,1) + '%') + 
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,17,1) + '%') +
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,18,1) + '%') +
					(SELECT num FROM @letrasNumeros WHERE letra LIKE '%' + SUBSTRING(@serie,19,1) + '%') 

	--SET @referencia =  STUFF(@referencia, 11, 3, @serie);
	--SET @referencia =  STUFF(@referencia, 0, 19, @serie);
	SET @referencia =   @serie;
	--select @serie



	DECLARE @DV CHAR(1) = ''
	DECLARE @aux  INT = 0, @index INT = 19, @num INT = 0
		
	WHILE(@index > 1)
		BEGIN
				SELECT @aux = CONVERT(INT,SUBSTRING(@referencia,@index,1))
				
				IF(@index%2 = 0) --numero por 1
						SET @num = @num + @aux
				ELSE --numero por 2
						SET @num = @num + CASE 
											   WHEN (@aux * 2) > 9 THEN  (@aux * 2) - 9
											   ELSE (@aux * 2)
										  END
				SET @index = @index - 1
		END

	SELECT @num = (@num + (10 - CONVERT(INT,SUBSTRING(REPLICATE('0',3-LEN(CONVERT(VARCHAR(3),@num))) +  CONVERT(VARCHAR(3),@num),3,1)))) - @num
	
	IF(@num %10 = 0)
		SET @DV = '0'
	ELSE 
		SET @DV = CONVERT(CHAR(1),@num) 
	
	RETURN @DV

END


--SELECT STUFF('09LC3214000AA123456', 2, 3, 'ijklmn');  
go

