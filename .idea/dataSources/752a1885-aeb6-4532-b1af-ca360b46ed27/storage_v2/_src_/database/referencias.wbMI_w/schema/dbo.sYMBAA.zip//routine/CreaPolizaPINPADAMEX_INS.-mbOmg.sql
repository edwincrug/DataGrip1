-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<crea poliza de la tabla [dbo].[datosFlap]>
-- =============================================
--[dbo].[CreaPoliza_INS] 
/*
RESPALDO DE PRODUCCION 29/06/2020
*/
--[CreaPolizaPINPADAMEX_INS] '099D16030EC100587092'
CREATE PROCEDURE [dbo].[CreaPolizaPINPADAMEX_INS]
@referencia nvarchar(50)
AS
BEGIN

	--select id_registro,tipoPago,referencia,importe,comision,ivaComision,fechaPago,cuentaBancaria,idEmpresa,idBanco,estatusProcesado ,'select * from '+c.nombre_base+'..con_movdet01'+convert(nvarchar(4),year(fechapago))+' where mov_mes ='+convert(nvarchar(2),month(getdate())) +' and  mov_tipopol ='''+c.tipo_poliza_traspaso+''' and mov_debe ='+convert(nvarchar(19),d.importe)
	--from datosFlap d
	--inner join Centralizacionv2..DIG_CAT_BASES_BPRO c on d.idEmpresa=c.emp_idempresa and d.idSucursal=c.suc_idsucursal and c.tipo=1
	--where tipopago='amex' and estatusProcesado=0

	--select * from Bancomer where noCuenta='000000000195334667' and importe=2.5 and refampliada like '%Multipagos%'

	DECLARE @Counter INT = 1, 
			@MaxId INT, 
			@fechaPago DATE,
			@cuentaBancaria NVARCHAR(20),
			@idbanco INT,
			@importe DECIMAL(18,2),
			@idempresa INT,
			@sucursal INT,
			@unidadNegocio INT,
			@categoriacobranza INT,
			@poliza_traspaso nvarchar(10),
			@importeBanco decimal(18,2),
			@idTipoDocumento int
	DECLARE @idbmer INT = 0, @cuentaContableDebe NVARCHAR(20) = '', @cuentaContableHaber NVARCHAR(20) = '', @nombrebase NVARCHAR(150), @sql NVARCHAR(max) = '', @ParmDefinition NVARCHAR(max)
	DECLARE @MOV_IDCLIENTE INT = 0, @rfc NVARCHAR(20) = '', @MOV_MES INT, @anio INT, @MOV_CONSPOL INT, @MOV_CONSPOLOUT NVARCHAR(10) = '', @consecutivocontable INT = 0, @nuevareferencia NVARCHAR(22)
		DECLARE @serie NVARCHAR(2), @idTipoReferencia INT = 1, @folio NVARCHAR(4)
			DECLARE @RC int
							DECLARE @idRegistro int=0
							DECLARE @idUsuario nvarchar(4)='GMI'
							DECLARE @Usuario int=0
							DECLARE @MOV_TIPOPOL nvarchar(10)
							DECLARE @MOV_DEBE decimal(18,5)
							DECLARE @MOV_HABER decimal(18,5)
							DECLARE @MOV_CONSMOV int 
							DECLARE @fechaoper datetime
							DECLARE @tipopago nvarchar(10)
							DECLARE @MOV_CONCEPTO nvarchar(100)

SELECT @cuentaBancaria = cuentaBancaria
				  ,@importe = importe
				  ,@idempresa = idEmpresa
				  ,@sucursal = idSucursal
				  ,@fechaPago =fechaPago
				  ,@unidadNegocio=unidadNegocio
				  ,@categoriaCobranza=categoriaCobranza
				  ,@tipopago=tipoPago
				  ,@Usuario=71
  FROM [referencias].[dbo].[datosFlap]
  where  referencia=@referencia
  select  @cuentaBancaria
				  ,@importe
				  ,@idempresa
				  ,@sucursal
				  ,@fechaPago
				  ,@referencia
				  ,@unidadNegocio
				  ,@categoriaCobranza
				  ,@tipopago
				  ,@Usuario

	EXECUTE [dbo].[CreaPolizaUNI_INS] 
				   @cuentaBancaria
				  ,@importe
				  ,@idempresa
				  ,@sucursal
				  ,@fechaPago
				  ,@referencia
				  ,@unidadNegocio
				  ,@categoriaCobranza
				  ,@tipopago
				  ,@Usuario
select id_registro,tipoPago,referencia,importe,comision,ivaComision,fechaPago,cuentaBancaria,idEmpresa,idBanco,estatusProcesado ,'select * from '+c.nombre_base+'..con_movdet01'+convert(nvarchar(4),year(fechapago))+' where mov_mes ='+convert(nvarchar(2),month(getdate())) +' and  mov_tipopol ='''+c.tipo_poliza_traspaso+''' and mov_debe ='+convert(nvarchar(19),d.importe)
	from datosFlap d
	inner join Centralizacionv2..DIG_CAT_BASES_BPRO c on d.idEmpresa=c.emp_idempresa and d.idSucursal=c.suc_idsucursal and c.tipo=1
	where referencia=@referencia			
  END

		---------------------------------------------------------------------------------------------------------------------------------------------------
		---------------------------------------------------------------------------------------------------------------------------------------------------


go

