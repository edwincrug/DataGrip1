-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-03-21
-- Description:	Lista de correos a quien se enviara reporte
-- =============================================
CREATE PROCEDURE [dbo].[CORREOSREPORTE_SP] AS
BEGIN
	SELECT correo FROM envioReporte WHERE activo = 1
END
go

