




-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 15-10-2019
-- Description: Inserta los pagos Cancelado realizado por la Pin Pad
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PagoCancelado] 
	 (	 @idOrigen int
		,@referencia varchar(100)
		,@nodo numeric(18,0)
		,@idConcepto int
		,@moneda int
		,@importe decimal(18,2)
		,@titularTarjeta varchar(50)=NULL
		,@numeroTarjeta nvarchar(300)=NULL
		,@firma varchar(100)=NULL
		,@correo varchar(100)=NULL
		,@telefono varchar(15)=NULL
		,@idComercio int=NULL
		,@idTipoTarjeta int=NULL
		,@idTipoPlan int=NULL
		,@mesesPago int=NULL
		,@accion varchar(20)=NULL
		,@emvTarjeta varchar(100)=NULL
		,@puntos int=NULL
		,@hmac varchar(600)=NULL
		,@Id numeric(18,0) OUTPUT
	)

AS
BEGIN

		BEGIN TRY  --Estar TryCatch

				INSERT INTO [dbo].[PagoCancelado]
						     ([idOrigen]
							 ,[referencia]
							 ,[nodo]
							 ,[idConcepto]
							 ,[moneda]
							 ,[importe]
							 ,[titularTarjeta]
							 ,[numeroTarjeta]
							 ,[firma]
							 ,[correo]
							 ,[telefono]
							 ,[idComercio]
							 ,[idTipoTarjeta]
							 ,[idTipoPlan]
							 ,[mesesPago]
							 ,[accion]
							 ,[emvTarjeta]
							 ,[puntos]
							 ,[hmac]
							 ,[fechaRegistro])
    					VALUES
						     (@idOrigen 
							 ,@referencia
							 ,@nodo
							 ,@idConcepto
							 ,@moneda
							 ,@importe
							 ,@titularTarjeta
							 ,@numeroTarjeta
							 ,@firma
							 ,@correo
							 ,@telefono
							 ,@idComercio
							 ,@idTipoTarjeta
							 ,@idTipoPlan
							 ,@mesesPago
							 ,@accion
							 ,@emvTarjeta
							 ,@puntos
							 ,@hmac
						     ,GETDATE())

							 --SELECT @outId= @@ROWCOUNT
				SELECT @Id = @@IDENTITY
				

		END TRY  
		BEGIN CATCH  
			--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[SP_INS_PagoCancelado]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro

		END CATCH; --End TryCatch

END
go

