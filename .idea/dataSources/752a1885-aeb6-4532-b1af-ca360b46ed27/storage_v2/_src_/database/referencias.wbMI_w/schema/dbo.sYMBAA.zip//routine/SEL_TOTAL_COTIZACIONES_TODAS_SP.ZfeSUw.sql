-- ==========================================================================================
-- Author:     
-- Create date: 
-- Description: Detalle de todos las COTIZACIONES|REFACCIONES|  
--				Filtrando por cliente.	 
--              Para hacer diferencia entre empresas es cambiando el nombre de la base
--				falta buscar por empresa, sucursal y departamento
-- ==========================================================================================
--  [SEL_TOTAL_COTIZACIONES_TODAS_SP]  @idCliente = 16906 
--345 74990  345     74990     @idempresa, idsucursal, idDepartamento  --  --40078 --11 --40078        
CREATE PROCEDURE [dbo].[SEL_TOTAL_COTIZACIONES_TODAS_SP] 
      @idCliente     int = 0
	  ,--LQMA 11092017 add parametros filtros
	  @idEmpresaP INT = 0,
	  @idSucursalP INT = 0,
	  @idDeptoP INT = 0,
	  @fechaIniP VARCHAR(10) = '',
	  @fechaFinP VARCHAR(10) = ''
AS
BEGIN
    SET NOCOUNT ON;    
    DECLARE @aux               INT = 1
	DECLARE @cadIpServidor VARCHAR(100);
    DECLARE @max               INT = 0
    DECLARE @idEmpresaBusca    INT = 0
    DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
	DECLARE @nomBaseMatrizNuevo     NVARCHAR(50) =NULL
    DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @select         VARCHAR(max);
	DECLARE @selectPreCot         VARCHAR(max);
	DECLARE @selectCotNu         VARCHAR(MAX);
	DECLARE	@idSucursal		NVARCHAR(50) =NULL
	DECLARE	@nombreSucursal NVARCHAR(50) =NULL
	DECLARE @nombreEmpresa  NVARCHAR(50) =NULL
	DECLARE	@idEmpresa	NVARCHAR(50) =NULL
	DECLARE @ipServidor NVARCHAR(50)
	DECLARE @sIpaux         VARCHAR(100) = ''  --1) LMS 28/08/2018

	----------------------------------------------------------------
	-- OBTENGO LA IP LOCAL                     --2) LMS 28/08/2018
	----------------------------------------------------------------
	SELECT @sIpaux= local_net_address
	  FROM sys.dm_exec_connections c
	 WHERE c.session_id = @@SPID
    
	--LQMA add 13092017
	IF(@fechaIniP = '')
	   SET @fechaIniP = '20000101'
	IF(@fechaFinP = '') 
	   SET @fechaFinP = CONVERT(VARCHAR(8),GETDATE(),112)

    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
							idSucursal nvarchar(30),
                            idEmpresa         nvarchar(30)
                            ,nombreEmpresa     nvarchar(100)
                            ,nomCtoEmpresa     nvarchar(5)
                            ,nomBaseConcentra  nvarchar(50)
							,nomBaseSucursal  nvarchar(50)
                            ,nomBaseMatriz     nvarchar(50)
                            ,ipServidor        nvarchar(20)
                            )

-- SE HACE LA BUSQUEDA DE LAS EMPRESAS Y SUCURSALES DISPONIBLES CON EL NOMBRE Y DIRECCIÓN IP DONDE SE ENCUENTRAN
     INSERT INTO @Bases
	   	SELECT 
				sucursales.suc_idsucursal
				,EMP.emp_idempresa
                ,EMP.emp_nombre
                ,EMP.emp_nombrecto
                ,BASEMP.nombre_base
				,BASEMP.nombre_sucursal
				--,BASEMP.
                ,ISNULL(BASEMP.nombre_base_matriz,BASEMP.nombre_base)
                ,BASEMP.ip_servidor 
           FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
                INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				inner join [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
           WHERE  BASEMP.estatus = 1 AND BASEMP.tipo = 1 
				 --LQMA add 12092017		  
				 --and sucursales.emp_idempresa= EMP.emp_idempresa
				 AND ((sucursales.emp_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
				 AND ((sucursales.suc_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
       ORDER BY sucursales.suc_idsucursal
     
	 
     
	 SET @max = (SELECT MAX(IDB) FROM @Bases)
     WHILE(@aux <= @max)
     BEGIN

         
         SELECT  @idEmpresaBusca   = DB.idEmpresa 
				,@idEmpresa = DB.idEmpresa
                ,@nomBaseConcentra = DB.nomBaseConcentra
                ,@nomBaseMatriz    = DB.nomBaseMatriz
				,@idSucursal = DB.idSucursal
				,@nombreSucursal = DB.nomBaseSucursal
				,@nombreEmpresa = DB.nombreEmpresa
				,@ipServidor = DB.ipServidor
				--,@nomBaseMatrizNuevos = DB.nomBaseMatriz where DB.idEmpresa != 5
           FROM @Bases AS DB 
          WHERE DB.IDB = @aux --DB.idEmpresa = @aux 
          --EXECUTE [SEL_PRESUPUESTO_DETALLE_SP] @idEmpresaBusca
		  select 
		   @nomBaseMatrizNuevo    = DB.nomBaseMatriz
		   FROM @Bases AS DB 
          WHERE DB.IDB = @aux and DB.idEmpresa != 2--DB.idEmpresa = @aux 
		
		IF (@ipServidor = @sIpaux)             --3) LMS 28/08/2018
		BEGIN
		set @cadIpServidor =''
		END
		ELSE
		BEGIN
		set @cadIpServidor =' [' + @ipServidor + '].'
		END
		--select @cadIpServidor

	DECLARE @todo TABLE  ( IDB INT IDENTITY(1,1),
                            idDocumento         nvarchar(MAX)
							,idEmpresa nvarchar(30)
							,nombreEmpresa nvarchar(MAX)
							,idSucursal nvarchar(30)
							,nombreSucursal nvarchar(MAX)
							,idDepartamento  nvarchar(30)
							,nombreDepartamento nvarchar(MAX)
							,saldo nvarchar(max)
						    ,tipoDocumento nvarchar(30)
                            ,nombreCliente     nvarchar(MAX)
                            ,fecha  nvarchar(30)
							,idCliente  nvarchar(30)
							,estatus nvarchar(30)
							,referencia nvarchar(max)
							--,nombreEmpresa nvarchar(30)
                            )
		  -- Refacciones|Cotizaciones dep_nombre
		  SET @select =
				'SELECT ' + char(13) + 
				'refacciones.PMM_NUMERO AS idDocumento' + char(13) + 
				',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
				',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) +  
				',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
				',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) + 
				',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+')as idDepartamento' + char(13) +
				',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+')as nombreDepartamento' + char(13) +  
				',refacciones.PMM_TOTAL AS saldo' + char(13) + 
				',2 as idTipoDocumento'+
				',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
				',refacciones.PMM_FECHOPE AS fecha' + char(13) + 
				',refacciones.PMM_IDCLIENTE AS idCliente ' + char(13) + 
				',PMM_IDALMA as estatus' + char(13) + 
				',(SELECT referencia FROM [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia  WHERE DEREF.documento = refacciones.PMM_NUMERO   AND DEREF.idSucursal = '+@idSucursal +' AND  DEREF.idDepartamento = (select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+' AND REF.tipoReferencia = 1))as Referencia '+
				'FROM '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[PAR_PEDMOST]  refacciones  ' + char(13) + 
				'INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = refacciones.PMM_IDCLIENTE ' + char(13) + 
				'WHERE refacciones.PMM_COTPED LIKE '+char(39)+'COTIZACION%'+char(39)+' ' + char(13) +'AND PMM_STATUS != ''X'' AND PMM_STATUS != ''C'''+ --'AND  refacciones.PMM_IDCLIENTE='+ cast (@idCliente as varchar(10)) +
			'' 
			

			--Unidades Nuevas| Semi Nuevas
				/*SET @selectCotNu = 
				'SELECT ' + char(13) + 
				'refacciones.PMM_NUMERO AS idDocumento' + char(13) + 
				',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
				',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) +  
				',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
				',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) + 
				',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+')as idDepartamento' + char(13) +
				',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+')as nombreDepartamento' + char(13) +  
				',refacciones.PMM_TOTAL AS saldo' + char(13) + 
				',2 as idTipoDocumento'+
				',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
				',refacciones.PMM_FECHOPE AS fecha' + char(13) + 
				',refacciones.PMM_IDCLIENTE AS idCliente ' + char(13) + 
				',PMM_IDALMA as estatus' + char(13) + 
				',(SELECT referencia from [referencias].[dbo].[Referencia] WHERE documento = refacciones.PMM_NUMERO  AND idSucursal = '+@idSucursal +' AND  idDepartamento = (select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'RE'+char(39)+'))as Referencia '+
				--',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) + 
				'FROM '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[PAR_PEDMOST]  refacciones  ' + char(13) + 
				'INNER JOIN  BDPersonas.dbo.cat_personas personas ON personas.per_idpersona = refacciones.PMM_IDCLIENTE ' + char(13) + 
				'WHERE refacciones.PMM_COTPED LIKE '+char(39)+'COTIZACION%'+char(39)+' ' + char(13) +'AND PMM_STATUS != ''X'' AND PMM_STATUS != ''C'''+ --'AND  refacciones.PMM_IDCLIENTE='+ cast (@idCliente as varchar(10)) +
				'' */
			
			--Unidades Nuevas| Semi Nuevas
				--SET @selectCotNu = 
				--'SELECT  ' + char(13) + 
				--			'cotizacion.ucu_foliocotizacion AS idDocumento' + char(13) + 
				--			',cotizacion.ucu_idempresa AS idEmpresa' + char(13) + 
				--			',empresas.emp_nombre as nombreEmpresa' + char(13) + 
				--			',cotizacion.ucu_idsucursal AS idSucursal' + char(13) + 
				--			',sucursales.suc_nombre AS nombreSucursal' + char(13) + 
				--			',cotizacion.ucu_iddepartamento AS idDepartamento' + char(13) + 
				--			',departamentos.dep_nombre AS nombreDepartamento' + char(13) + 
				--			',(SELECT ' + char(13) + 
				--			'	TOTALVTA = ISNULL(SUM(CUU.ucn_total), 0)' + char(13) + 
				--			'FROM 	[cuentasporcobrar].[dbo].[uni_cotizacionuniversalunidades] CUU' + char(13) + 
				--			'	INNER JOIN [cuentasporcobrar].[dbo].[UNI_CotizacionUniversal] CU ON CU.ucu_idcotizacion = CUU.ucu_idcotizacion' + char(13) + 
				--			'	LEFT JOIN		(SELECT' + char(13) + 
				--			'				CUU.ucn_idcotizadetalle' + char(13) + 
				--			'				,SUM(PS.PQE_MOVENTA + PS.PQE_REVENTA + PS.PQE_TTVENTA) AS PS_VENTA' + char(13) + 
				--			'				,SUM(PS.PQE_MOCOSTO + PS.PQE_RECOSTO + PS.PQE_TTCOSTO) AS PS_COSTO' + char(13) + 
				--			'			FROM ' + char(13) + 
				--			'				[cuentasporcobrar].[dbo].[UNI_CotizacionUniversalUnidades] CUU' + char(13) + 
				--			'					INNER JOIN ' + char(13) + 
				--			'						[192.168.20.31].[GAAU_Concentra_P].[dbo].[SER_PQVEHICULO] PV ON PV.PQV_IDCATALOGO = CUU.ucn_idcatalogo COLLATE Modern_Spanish_CI_AS AND PV.PQV_MODELO = CUU.ucn_modelo COLLATE Modern_Spanish_CI_AS' + char(13) + 
				--			'					INNER JOIN ' + char(13) + 
				--			'						[192.168.20.31].[GAAU_Concentra_P].[dbo].[SER_PAQUESER] PS ON PS.PQE_IDPAQUETE = PV.PQV_IDPAQUETE' + char(13) + 
				--			'			WHERE ' + char(13) + 
				--			'				EXISTS' + char(13) + 
				--			'					(' + char(13) + 
				--			'						SELECT ' + char(13) + 
				--			'							ucn_idcotizadetalle, ' + char(13) + 
				--			'							upo_idpaquete ' + char(13) + 
				--			'						FROM ' + char(13) + 
				--			'							[cuentasporcobrar].[dbo].[uni_preordenser] POS ' + char(13) + 
				--			'						WHERE ' + char(13) + 
				--			'								(POS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle) ' + char(13) + 
				--			'							AND (POS.upo_idpaquete = PS.PQE_IDPAQUETE)' + char(13) + 
				--			'							AND (POS.upo_estatus = 1)' + char(13) + 
				--			'					)' + char(13) + 
				--			'			GROUP BY' + char(13) + 
				--			'				CUU.ucn_idcotizadetalle' + char(13) + 
				--			'		) NUPS ON NUPS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
				--			'	LEFT JOIN' + char(13) + 
				--			'		(' + char(13) + 
				--			'			SELECT' + char(13) + 
				--			'				POS.ucn_idcotizadetalle' + char(13) + 
				--			'				,SUM(PS.PQE_MOVENTA + PS.PQE_REVENTA + PS.PQE_TTVENTA) AS PS_VENTA' + char(13) + 
				--			'				,SUM(PS.PQE_MOCOSTO + PS.PQE_RECOSTO + PS.PQE_TTCOSTO) AS PS_COSTO' + char(13) + 
				--			'			FROM' + char(13) + 
				--			'				[cuentasporcobrar].[dbo].[uni_preordenser] POS' + char(13) + 
				--			'					INNER JOIN [192.168.20.31].[GAAU_Concentra_P].[dbo].[SER_PAQUESER] PS ON (PS.PQE_IDPAQUETE = POS.upo_idpaquete) AND (POS.upo_estatus = 1) AND (PS.PQE_IDPAQUETE LIKE '+char(39)+'SEMI%'+char(39)+')' + char(13) + 
				--			'			GROUP BY' + char(13) + 
				--			'				POS.ucn_idcotizadetalle' + char(13) + 
				--			'		) SNPS ON SNPS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
				--			'	LEFT JOIN' + char(13) + 
				--			'		(' + char(13) + 
				--			'			SELECT ' + char(13) + 
				--			'				aw.ucn_idcotizadetalle' + char(13) + 
				--			'				,SUM([uaw_importe]) AS Importe' + char(13) + 
				--			'			FROM ' + char(13) + 
				--			'				[cuentasporcobrar].[dbo].[uni_anticiposweb] aw' + char(13) + 
				--			'			WHERE ' + char(13) + 
				--			'				(aw.uaw_estatus = 1)' + char(13) + 
				--			'			GROUP BY' + char(13) + 
				--			'				aw.ucn_idcotizadetalle' + char(13) + 
				--			'		) TG ON TG.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
				--			'	LEFT JOIN' + char(13) + 
				--			'		(' + char(13) + 
				--			'			SELECT ' + char(13) + 
				--			'				PMD.ucn_idcotizadetalle' + char(13) + 
				--			'				,SUM(PMD.pmd_total) AS Refa_TOTAL' + char(13) + 
				--			'			FROM ' + char(13) + 
				--			'				[192.168.20.31].[GAAU_Concentra_P].[dbo].[par_pedmostdet] PMD' + char(13) + 
				--			'			WHERE ' + char(13) + 
				--			'				PMD.pmd_estatus = 1' + char(13) + 
				--			'			GROUP BY' + char(13) + 
				--			'				PMD.ucn_idcotizadetalle' + char(13) + 
				--			'		) Refa ON Refa.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
				--			'	LEFT JOIN' + char(13) + 
				--			'		(' + char(13) + 
				--			'			SELECT ' + char(13) + 
				--			'				OCD.ucn_idcotizadetalle' + char(13) + 
				--			'				,SUM(OCD.ucd_cantidad * OCD.ucd_preciounitario) AS Otros_TOTAL' + char(13) + 
				--			'			FROM ' + char(13) + 
				--			'				[cuentasporcobrar].[dbo].[uni_otroconceptosdet] OCD' + char(13) + 
				--			'			WHERE ' + char(13) + 
				--			'				OCD.ucd_estatus = 1' + char(13) + 
				--			'			GROUP BY ' + char(13) + 
				--			'				OCD.ucn_idcotizadetalle' + char(13) + 
				--			'		) Otros ON Otros.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
				--			'WHERE ' + char(13) + 
				--			'	CUU.ucu_idcotizacion =  cotizacion.ucu_idempresa )as saldo' + char(13) + 
				--			',2 as idTipoDocumento' + char(13) + 
				--			',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
				--			',cotizacion.ucu_fechacotiza AS fechaDocumento' + char(13) + 
				--			',cotizacion.ucu_idcliente as idCliente' + char(13) + 
				--			',null as estatus' + char(13) + 
				--			',(SELECT referencia from [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia WHERE documento = cotizacion.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS and REF.tipoReferencia = 1)as Referencia' + char(13) + 
				--			'FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] cotizacion  ' + char(13) + 
				--			'INNER JOIN  [BDPersonas].[dbo].[cat_personas] personas ON personas.per_idpersona = cotizacion.ucu_idcliente' + char(13) + 
				--			'INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = cotizacion.ucu_idempresa' + char(13) + 
				--			'INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = cotizacion.ucu_idsucursal' + char(13) + 
				--			'INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] departamentos  ON departamentos.dep_iddepartamento = cotizacion.ucu_iddepartamento  ' + char(13) + 
				--			'WHERE ucu_estatus != 14 ' + char(13) + 
				--			''        
				SET @selectCotNu = 
				'SELECT ' + char(13) + 
					'cotizacion.ucu_foliocotizacion AS idDocumento' + char(13) + 
					',cotizacion.ucu_idempresa AS idEmpresa' + char(13) +  
					',empresas.emp_nombre as nombreEmpresa' + char(13) +
					',cotizacion.ucu_idsucursal AS idSucursal' + char(13) + 
					',sucursales.suc_nombre AS nombreSucursal' + char(13) + 
					',cotizacion.ucu_iddepartamento AS idDepartamento' + char(13) + 
					--',departamentos.dep_nombre AS nombreDepartamento' + char(13) + 
					',(select [referencias].[dbo].[nombresSucursal](cotizacion.ucu_iddepartamento )) as idDepartamento'+ char(13) + 
					',(SELECT ' + char(13) + 
					'	TOTALVTA = ISNULL(SUM(CUU.ucn_total), 0)' + char(13) + 
					'FROM 	cuentasporcobrar..uni_cotizacionuniversalunidades CUU' + char(13) + 
					'	INNER JOIN cuentasporcobrar..UNI_CotizacionUniversal CU ON CU.ucu_idcotizacion = CUU.ucu_idcotizacion' + char(13) + 
					'	LEFT JOIN (SELECT' + char(13) + 
					'				CUU.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(PS.PQE_MOVENTA + PS.PQE_REVENTA + PS.PQE_TTVENTA) AS PS_VENTA' + char(13) + 
					'				,SUM(PS.PQE_MOCOSTO + PS.PQE_RECOSTO + PS.PQE_TTCOSTO) AS PS_COSTO' + char(13) + 
					'			FROM ' + char(13) + 
					'				cuentasporcobrar..UNI_CotizacionUniversalUnidades CUU' + char(13) + 
					'					INNER JOIN '+@cadIpServidor +' ['+ @nomBaseMatriz +'].[DBO].SER_PQVEHICULO PV ON PV.PQV_IDCATALOGO = CUU.ucn_idcatalogo COLLATE Modern_Spanish_CI_AS AND PV.PQV_MODELO = CUU.ucn_modelo COLLATE Modern_Spanish_CI_AS' + char(13) + 
					'					INNER JOIN '+@cadIpServidor +' ['+ @nomBaseMatriz +'].[DBO].SER_PAQUESER PS ON PS.PQE_IDPAQUETE = PV.PQV_IDPAQUETE' + char(13) + 
					'			WHERE ' + char(13) + 
					'				EXISTS' + char(13) + 
					'					(' + char(13) + 
					'						SELECT ' + char(13) + 
					'							ucn_idcotizadetalle, ' + char(13) + 
					'							upo_idpaquete ' + char(13) + 
					'						FROM ' + char(13) + 
					'							cuentasporcobrar..uni_preordenser POS ' + char(13) + 
					'						WHERE ' + char(13) + 
					'								(POS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle) ' + char(13) + 
					'							AND (POS.upo_idpaquete = PS.PQE_IDPAQUETE)' + char(13) + 
					'							AND (POS.upo_estatus = 1)' + char(13) + 
					'					)' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				CUU.ucn_idcotizadetalle' + char(13) + 
					'		) NUPS ON NUPS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(SELECT POS.ucn_idcotizadetalle,SUM(PS.PQE_MOVENTA + PS.PQE_REVENTA + PS.PQE_TTVENTA) AS PS_VENTA' + char(13) + 
								' ,SUM(PS.PQE_MOCOSTO + PS.PQE_RECOSTO + PS.PQE_TTCOSTO) AS PS_COSTO' + char(13) + 
							' FROM cuentasporcobrar..uni_preordenser POS' + char(13) + 
							' INNER JOIN '+@cadIpServidor +' ['+ @nomBaseMatriz +'].[DBO].SER_PAQUESER PS ON (PS.PQE_IDPAQUETE = POS.upo_idpaquete) AND (POS.upo_estatus = 1) AND (PS.PQE_IDPAQUETE LIKE '+char(39)+'SEMI%'+char(39)+')' + char(13) + 
							' GROUP BY POS.ucn_idcotizadetalle' + char(13) + 
					'		) SNPS ON SNPS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(SELECT aw.ucn_idcotizadetalle ,SUM([uaw_importe]) AS Importe' + char(13) + 
								' FROM cuentasporcobrar.[dbo].[uni_anticiposweb] aw' + char(13) + 
								' WHERE (aw.uaw_estatus = 1) GROUP BY' + char(13) + 
					'				aw.ucn_idcotizadetalle' + char(13) + 
					'		) TG ON TG.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(SELECT ' + char(13) + 
								' PMD.ucn_idcotizadetalle' + char(13) + 
								' ,SUM(PMD.pmd_total) AS Refa_TOTAL' + char(13) + 
							' FROM '+@cadIpServidor +' ['+ @nomBaseMatriz +'].[DBO].par_pedmostdet PMD' + char(13) + 
							' WHERE PMD.pmd_estatus = 1 GROUP BY' + char(13) + 
					'				PMD.ucn_idcotizadetalle' + char(13) + 
					'		) Refa ON Refa.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		( SELECT OCD.ucn_idcotizadetalle,SUM(OCD.ucd_cantidad * OCD.ucd_preciounitario) AS Otros_TOTAL ' + char(13) + 
							 ' FROM cuentasporcobrar..uni_otroconceptosdet OCD' + char(13) + 
						' WHERE OCD.ucd_estatus = 1 GROUP BY OCD.ucn_idcotizadetalle' + char(13) + 
					'		) Otros ON Otros.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'WHERE ' + char(13) + 
					'	CUU.ucu_idcotizacion =  cotizacion.ucu_idcotizacion ) as saldo' + char(13) + ''+ 
					',2 as idTipoDocumento'+
					',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
					',convert(date, cotizacion.ucu_fechacotiza,113)AS fechaDocumento' + char(13) +
					',cotizacion.ucu_idcliente as idCliente' + char(13) + 
					',null as estatus' + char(13) + 
					',(SELECT referencia from [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia WHERE documento = cotizacion.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS and REF.tipoReferencia = 1)as Referencia '+
					'FROM cuentasporcobrar.dbo.uni_cotizacionuniversal cotizacion  ' + char(13) + 
					'INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = cotizacion.ucu_idcliente' + char(13) + 
					'INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = cotizacion.ucu_idempresa' + char(13) + 
					'INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = cotizacion.ucu_idsucursal' + char(13) + 
					--'INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] departamentos  ON departamentos.dep_iddepartamento = cotizacion.ucu_iddepartamento  ' + char(13) + 
					'WHERE ucu_estatus != 14 AND cotizacion.ucu_idcliente = ' + CONVERT(VARCHAR(15),@idCliente) + ' ' +
					'AND empresas.emp_idempresa = ' + CONVERT(VARCHAR(10),@idEmpresa) + ' ' +
					'AND sucursales.suc_idsucursal = ' + CONVERT(VARCHAR(10),@idSucursal)

		print @selectCotNu
				--PResupuesto | Servicio
		SET @selectPreCot =
				'SELECT ' + char(13) + 
				'DISTINCT(PRD_IDORDEN) AS idDocumento' + char(13) + 
				',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
				',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) +  
				',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
				',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) + 
				',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'SE'+char(39)+')as idDepartamento' + char(13) + 
				',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'SE'+char(39)+')as nombreDepartamento' + char(13) +
				',SUM(PRD_SUBTOTAL)   AS total' + char(13) + 
				',4 as idTipoDocumento'+
				',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente ' + char(13) + 
				',detalle.PRD_FECHOPE AS fecha' + char(13) + 
				',presupuesto.PRE_IDCLIENTE AS idCliente' + char(13) + 
				','+char(39)+'NULL'+char(39)+' as estatus' + char(13) + 
				',(SELECT referencia FROM [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia  WHERE DEREF.documento = PRD_IDORDEN COLLATE Modern_Spanish_CI_AS   AND DEREF.idSucursal = '+@idSucursal +' AND  DEREF.idDepartamento = (select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +'  and suc_idsucursal = '+@idSucursal +'  ' + char(13) + 
				'and dep_nombrecto = '+char(39)+'SE'+char(39)+' AND REF.tipoReferencia = 1))as Referencia '+
				'FROM '+@cadIpServidor +' ['+ @nomBaseMatriz +'].[dbo].[SER_PRESUPDET] detalle ' + char(13) + 
				'INNER JOIN  '+@cadIpServidor +'['+ @nomBaseMatriz +'].[dbo].[SER_PRESUP] presupuesto  ON detalle.PRD_IDORDEN = presupuesto.PRE_IDORDEN  ' + char(13) + 
				'INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = presupuesto.PRE_IDCLIENTE ' + char(13) + 
				'GROUP BY PRD_IDORDEN ' + char(13) + 
				',personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno' + char(13) + 
				',PRD_FECHOPE' + char(13) + 
				',PRE_IDCLIENTE '

				INSERT INTO @todo EXECUTE (@selectPreCot)
				INSERT INTO @todo EXECUTE (@select)        
				INSERT INTO @todo EXECUTE (@selectCotNu)

         SET @aux = @aux + 1
     END
	 --INSERT INTO @todo EXECUTE (@selectCotNu)
	 select IDB 
			,idDocumento      
			,idEmpresa 
			,nombreEmpresa 
			,idSucursal 
			,nombreSucursal 
			,idDepartamento  
			,nombreDepartamento 
			,saldo 
			,tipoDocumento 
			,nombreCliente     
			,fecha  
			,idCliente  
			,estatus 
			,referencia  from @todo where idCliente = @idCliente
	 --LQMA 12092017
	 AND ((idEmpresa = @idEmpresaP) OR (@idEmpresaP = 0))
	 AND ((idSucursal = @idSucursalP) OR (@idSucursalP = 0))
	 AND ((idDepartamento = @idDeptoP) OR (@idDeptoP = -1))
	 AND CONVERT(DATE,REPLACE(fecha,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
END
-- quitar tipo de documentpo
go

