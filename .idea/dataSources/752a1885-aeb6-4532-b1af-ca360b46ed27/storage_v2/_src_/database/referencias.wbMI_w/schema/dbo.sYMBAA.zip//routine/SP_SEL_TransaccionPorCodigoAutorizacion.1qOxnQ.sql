

-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 06-08-2020
-- Description:	Obtiene toda la informacion de la Transaccion mediante l Numero de Atorizacion en Ticket...
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_TransaccionPorCodigoAutorizacion]
(
	@autorizacion varchar(15)
)
AS
BEGIN

BEGIN TRY  --TryCatch

		 --Get id Transaccion
		  DECLARE @idTrans numeric(18,0)=0;	
		  DECLARE @refAmexAux varchar(50)='0';-- Ref Aux
		  DECLARE @refAmex varchar(50)='0';--Referencia American Express
		  DECLARE @ticket nvarchar(MAX)='';--Pagare Ticket
		  DECLARE @iSnumericRef int=0;--Flag numeric


		  SELECT TOP 1 @idTrans=idTrans,
					@ticket=respuestaBBVA,
					@refAmexAux = indicadorTransaccion
		  FROM [referencias].[dbo].[PagoRespuesta]
		  WHERE  [numeroAutorizacion]=@autorizacion AND estatus=1
		  ORDER BY fechaRegistro DESC;


		  --Valdando Referencia Amex
		 SELECT @iSnumericRef=ISNUMERIC(@refAmexAux);

		--print  @iSnumericRef

		IF @iSnumericRef = 1
		   BEGIN
				SELECT @refAmex=@refAmexAux;
		   END
		ELSE
		   BEGIN
				SELECT @refAmex='0';
		   END

		 --  PRINT @idTrans
		  --  PRINT @refAmex

			SELECT 
				   P.idPago AS 'IdPago'
				  ,P.idTrans AS 'IdTransaccion'
			      ,P.referencia As 'Referencia'
			      ,C.mp_node AS 'Sucursal'
			      ,P.idConcepto AS 'IdConcepto'
			      ,P.moneda AS 'Moneda'
			      ,P.importe AS 'Importe'
			      ,P.idComercio AS 'IdComercio'
			      ,P.accion AS 'Accion'
				  ,@autorizacion AS 'Autorizacion'
				  ,@refAmex AS 'RefAmex'
				  ,@ticket AS 'Ticket'
			  FROM [referencias].[dbo].[Pago] AS P
			  INNER JOIN [referencias].[dbo].[Cat_DivisionOrg_BBVA] AS C ON C.idSucursal=P.nodo
			  WHERE P.idOrigen=1 AND P.idTrans=@idTrans AND C.estatus=1;
END TRY  
BEGIN CATCH  
	--Log Error
			INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[Pago]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro  

END CATCH; --End TryCatch



	

END
go

