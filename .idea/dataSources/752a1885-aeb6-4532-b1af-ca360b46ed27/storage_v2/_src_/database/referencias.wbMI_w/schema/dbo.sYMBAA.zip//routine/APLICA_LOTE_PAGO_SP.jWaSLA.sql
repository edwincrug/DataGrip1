-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE APLICA_LOTE_PAGO_SP
AS
BEGIN

INSERT INTO prueba
SELECT GETDATE()


END
go

