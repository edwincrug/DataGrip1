





-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 30-09-2019
-- Description: Inserta las respuestas de pagos cancelados realizados de la  Pin Pad
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PagoCanceladoRespuesta] 
	 (					@idPago numeric(18,0)
				       ,@numeroAutorizacion varchar(10)=NULL
				       ,@mensaje varchar(300)=NULL
				       ,@codigoRespuesta varchar(10)=NULL
				       ,@indicadorImpresion varchar(100)=NULL
				       ,@fecha varchar(10)=NULL
				       ,@hora varchar(10)=NULL
				       ,@indicadorTransaccion varchar(10)=NULL
				       ,@script varchar(250)=NULL
				       ,@criptograma varchar(250)=NULL
				       ,@tokenET nvarchar(300)=NULL
				       ,@tokenEX nvarchar(300)=NULL
				       ,@banderaLlave int=NULL
				       ,@banderaBines int=NULL
				       ,@banderaTelecarga int=NULL
					   ,@respuestaBBVA varchar(max)=null
					   ,@estatus bit = NULL
	)

AS
BEGIN

		BEGIN TRY  --Estar TryCatch

			INSERT INTO [dbo].[PagoCanceladoRespuesta]
							([idPago]
							,[numeroAutorizacion]
							,[mensaje]
							,[codigoRespuesta]
							,[indicadorImpresion]
							,[fecha]
							,[hora]
							,[indicadorTransaccion]
							,[script]
							,[criptograma]
							,[tokenET]
							,[tokenEX]
							,[banderaLlave]
							,[banderaBines]
							,[banderaTelecarga]
							,[respuestaBBVA]
							,[estatus]
							,[fechaRegistro])
           VALUES
				       (@idPago
				       ,@numeroAutorizacion
				       ,@mensaje
				       ,@codigoRespuesta
				       ,@indicadorImpresion
				       ,@fecha
				       ,@hora
				       ,@indicadorTransaccion
				       ,@script
				       ,@criptograma
				       ,@tokenET
				       ,@tokenEX
				       ,@banderaLlave
				       ,@banderaBines
				       ,@banderaTelecarga
					   ,@respuestaBBVA
					   ,@estatus
				       ,GETDATE())

		END TRY  
		BEGIN CATCH  
			--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[PagoCanceladoRespuesta]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro 

		END CATCH; --End TryCatch

END
go

