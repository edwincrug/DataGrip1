-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetDocType](@DocTypeID int, @Reference varchar(50))
RETURNS varchar(100)
AS
BEGIN

	--catalogo de tipos de documentos select * from tipodocumento
	declare @result varchar(100)
		
	if(@DocTypeID = 1 )  ---factura
	begin
		SELECT @result =CCP_IDDOCTO 
		FROM GAZM_Zaragoza..VIS_CONCAR01 
		WHERE CCP_IDDOCTO = 'FAC' AND 
		CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS =
			(	
				SELECT documento 
				FROM Referencia
				WHERE Referencia = 
					(
						SELECT refAmpliada 
						FROM BancomerLayout22 
						WHERE estatus = 1 AND 
						esCargo = 0 AND 
						refAmpliada =   @Reference --'09TG320N0AA000196792'
					)
			)
		AND CCP_IDPERSONA = 31723  

		return  @result
	end

	if(@DocTypeID = 2 )  --Cotización
	begin
		return 'Cotización'
	end


	if(@DocTypeID = 3 ) --Pedido
	begin
		return 'Pedido'
	end


	if(@DocTypeID = 4 ) --Presupuesto
	begin
		return 'Presupuesto'
	end
	
	if(@DocTypeID = 5 ) --Orden de Servicio
	begin
		return 'Orden de Servicio'
	end


	return ''
	

END

go

