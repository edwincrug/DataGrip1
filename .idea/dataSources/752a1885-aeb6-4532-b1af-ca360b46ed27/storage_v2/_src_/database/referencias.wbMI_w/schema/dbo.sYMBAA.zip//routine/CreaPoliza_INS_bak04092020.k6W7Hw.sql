-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<crea poliza de la tabla [dbo].[datosFlap]>
-- =============================================
--[dbo].[CreaPoliza_INS] 
/*
RESPALDO DE PRODUCCION 29/06/2020
*/
create PROCEDURE [dbo].[CreaPoliza_INS_bak04092020]

AS
BEGIN

	--select id_registro,tipoPago,referencia,importe,comision,ivaComision,fechaDispersion,cuentaBancaria,idEmpresa,idBanco,estatusProcesado 
	--from datosFlap 
	--where cuentaBancaria is not null and estatusProcesado= 0

	--select * from Bancomer where noCuenta='000000000195334667' and importe=2.5 and refampliada like '%Multipagos%'

	DECLARE @Counter INT = 1, 
			@MaxId INT, 
			@fechadispersion DATE,
			@cuentaBancaria NVARCHAR(20),
			@idbanco INT,
			@importe DECIMAL(18,2),
			@idempresa INT,
			@referencia NVARCHAR(22),
			@sucursal INT,
			@unidadNegocio INT,
			@categoriacobranza INT,
			@poliza_traspaso nvarchar(10);
			

	SELECT 
		ROW_NUMBER() OVER(ORDER BY fechaDispersion,idempresa ASC) AS rowNumber,
		fechaDispersion,
		cuentaBancaria,
		idEmpresa,
		idSucursal,
		SUM(importe) importe,
		unidadNegocio,
		categoriacobranza
	INTO #datosflaptemp
	FROM (select convert(date,fechaPago) fechaDispersion,
		cuentaBancaria,
		idEmpresa,
		idSucursal,importe,estatusProcesado,unidadNegocio,
		categoriacobranza
		from datosFlap ) x
	WHERE cuentaBancaria is not null and estatusProcesado= 0
	GROUP BY fechaDispersion,unidadNegocio,
		categoriacobranza,cuentaBancaria,idEmpresa,idSucursal

	IF OBJECT_ID('tempdb..#datosflaptemp') IS NOT NULL
		BEGIN
			--PRINT 'Paso 1' 
			SELECT * FROM #datosflaptemp
			--end
			SELECT 
				@MaxId = MAX(rowNumber) 
			FROM #datosflaptemp

			WHILE(@Counter IS NOT NULL AND @Counter <= @MaxId)
				BEGIN
				Set @poliza_traspaso=''
					 SELECT  
						@fechadispersion=fechadispersion,
						@cuentaBancaria=cuentaBancaria,
						@idempresa=idempresa,
						@importe=importe,
						@sucursal=idSucursal,
						@unidadNegocio=unidadNegocio,
						@categoriaCobranza=categoriaCobranza
					FROM #datosflaptemp
					WHERE rowNumber = @Counter

					SELECT  
						@fechadispersion fechadispersion,
						@cuentaBancaria cuentaBancaria,
						@idempresa idempresa,
						@importe importe,
						@sucursal,
						@unidadNegocio,
						@categoriaCobranza
						--Sacar registros de datos flap
					 PRINT 'Paso 1prima'

					IF EXISTS(SELECT * FROM Bancomer where noCuenta = @cuentaBancaria AND importe = @importe AND refampliada LIKE '%Multipagos%' AND fechaOperacion >= @fechadispersion AND estatus != 5)
						BEGIN
							PRINT 'Paso 2 si existe'
							DECLARE @idbmer INT = 0, @cuentaContableDebe NVARCHAR(20) = '', @cuentaContableHaber NVARCHAR(20) = '', @nombrebase NVARCHAR(150), @sql NVARCHAR(max) = '', @ParmDefinition NVARCHAR(max)
							DECLARE @MOV_IDCLIENTE INT = 0, @rfc NVARCHAR(20) = '', @MOV_MES INT, @anio INT, @MOV_CONSPOL INT, @MOV_CONSPOLOUT NVARCHAR(10) = '', @consecutivocontable INT = 0, @nuevareferencia NVARCHAR(22)

							SELECT @anio = YEAR(GETDATE()), @mov_mes= MONTH(GETDATE())

							SELECT 
								@idbmer = idbmer, 
								@idbanco = IDBanco 
							FROM Bancomer WHERE noCuenta = @cuentaBancaria AND importe = @importe AND refampliada LIKE '%Multipagos%'

							SELECT 
								@cuentaContableDebe = cuentaContable 
							FROM BancoCuenta WHERE numeroCuenta = @cuentaBancaria
 
							-- select *  from BancoCuenta b where b.numeroCuenta=@cuentaBancaria

 
							SELECT 
								@nombrebase = nombre_base 
							FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							WHERE emp_idempresa = @idempresa AND tipo = 2

							SELECT 
								@consecutivocontable = consecutivo_contable ,@poliza_traspaso = tipo_poliza_traspaso
							FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							WHERE emp_idempresa = @idempresa AND suc_idsucursal = @sucursal

						if len(@poliza_traspaso)>5
						begin
							 --  select @idbanco,@idbmer,@cuentaBancaria,@MOV_IDCLIENTE
							SET @cuentaContableHaber = '1100-0010-000' + CONVERT(NVARCHAR(1), @consecutivocontable) + '-0001'

							DECLARE @serie NVARCHAR(2) = RIGHT('0' + CONVERT(NVARCHAR(4), FLOOR(RAND()*(99-0+1))),2), @idTipoReferencia INT = 1, @folio NVARCHAR(4) = RIGHT('000' + CONVERT(NVARCHAR(4), FLOOR(RAND()*(9999-0+1))),4)

							SET @nuevareferencia = [dbo].[referencia_fn](@serie, @folio, @sucursal, @idTipoReferencia) + '-1'
												  -- [dbo].[digito_verificador_fn]([dbo].[referencia_fn](@serie, @folio, @sucursal, @idTipoReferencia)) 
							SELECT @nuevareferencia
							SET @sql = N'SELECT @MOV_CONSPOLOUT = ISNULL(max(pol_consecutivo),0) + 1 FROM ' + @nombrebase + '.dbo.con_pol01' + CONVERT(NVARCHAR(8), @anio) + ' WHERE pol_tipo = '''+@poliza_traspaso+''' AND pol_mes = ' + CONVERT(NVARCHAR(2), @MOV_MES) + ' '
							SET @ParmDefinition = N'@MOV_CONSPOLOUT NVARCHAR(10) OUTPUT'
							EXECUTE sp_executesql @sql, @ParmDefinition,@MOV_CONSPOLOUT OUTPUT;
							---Actualizar en bancomer el estatus y la referencia
							update Bancomer set estatus=5,referencia= replace(substring(@nuevareferencia,1,20),'-','') where idBmer=@idbmer
 
							DECLARE @RC int
							DECLARE @idRegistro int=0
							DECLARE @idUsuario nvarchar(4)='GMI'
							DECLARE @Usuario int=0
							DECLARE @MOV_TIPOPOL nvarchar(10)=@poliza_traspaso
							DECLARE @MOV_DEBE decimal(18,5)=@importe
							DECLARE @MOV_HABER decimal(18,5)=0

							DECLARE @MOV_CONSMOV int = 2
							SET  @MOV_CONSPOL   = convert(int,@MOV_CONSPOLOUT)
							DECLARE @fechaoper datetime= getdate()
							DECLARE @mov_fecha datetime=@fechaoper
							DECLARE @MOV_CONCEPTO nvarchar(100)='Transferencia Multipagos '+convert(nvarchar(10),@mov_fecha,103)


							-- TODO: Set parameter values here.
							 PRINT 'Paso 3 poliza debe'
							EXECUTE @RC = [dbo].[CreaPolizaDebe_INS] 
						--	SELECT
							   @idRegistro
							  ,@idEmpresa
							  ,@idBanco
							  ,@idUsuario
							  ,@Usuario
							  ,@rfc
							  ,@cuentaContableDebe
							  ,@MOV_TIPOPOL
							  ,@MOV_CONSPOL
							  ,@MOV_CONSMOV
							  ,@MOV_MES
							  ,@anio
							  ,@MOV_DEBE
							  ,@MOV_HABER
							  ,@MOV_CONCEPTO
							  ,@nuevareferencia
							  ,@fechaoper
							  ,@mov_fecha
							  ,@MOV_IDCLIENTE

							--Insertar uno por uno
							DECLARE @MaxIdInt INT = 0, @CounterInt INT = 1, @id_registro INT, @fechaPago DATE, @tipoPago NVARCHAR(10), @MOV_CONCEPTOOUT NVARCHAR(250) = '';
							SELECT 
								ROW_NUMBER() OVER(ORDER BY fechaDispersion,idempresa ASC) AS rowNumber,
								id_registro,
								fechaPago,
								tipoPago,
								referencia,
								importe,
								fechaDispersion,
								cuentaBancaria,
								idEmpresa,
								idSucursal,
								idBanco 
							INTO #datoflap
							FROM datosFlap 
							WHERE fechapago = @fechadispersion AND cuentaBancaria = @cuentaBancaria AND idEmpresa = @idempresa AND idSucursal = @sucursal and unidadNegocio=@unidadNegocio and categoriaCobranza=@categoriacobranza
							--select MAX(rowNumber) from #datoflap
							SELECT 
								@MaxIdInt = MAX(rowNumber) 
							FROM #datoflap

							PRINT 'Paso 4 poliza individuales'
							--SELECT * FROM #datoflap

							WHILE( @CounterInt <= @MaxIdInt)
								BEGIN
								set @MOV_CONCEPTOOUT=''
									SELECT 
										@id_registro = id_registro,
										@fechaPago = fechaPago,
										@tipoPago = tipoPago,
										@referencia = referencia+'-1',
										@importe = importe, 
										@fechadispersion = fechaDispersion,
										@cuentaBancaria = cuentaBancaria  
									FROM #datoflap
									WHERE rowNumber = @CounterInt
									update datosFlap set referenciaConciliacion=@nuevareferencia,estatusProcesado=1 where id_registro=@id_registro
									SELECT * FROM #datoflap WHERE rowNumber = @CounterInt
									select @MOV_CONCEPTOOUT=documento from Referencia r inner join  DetalleReferencia d on r.idReferencia=d.idReferencia
									where referencia=replace(@referencia,'-1','')


									--select @MOV_CONCEPTOOUT
				
									SET @MOV_CONSMOV = CASE WHEN @CounterInt < 2 THEN @CounterInt ELSE @CounterInt + 1 END
			
									SET @MOV_DEBE = 0
									SET @MOV_HABER = @importe
									SET @MOV_CONCEPTO = 'Transferencia Ingresos ' + @MOV_CONCEPTOOUT

									--TODO: Set parameter values here.

									EXECUTE @RC = [dbo].[CreaPolizaHaber_INS] 
								--	SELECT
									   @idRegistro
									  ,@idEmpresa
									  ,@idBanco
									  ,@idUsuario
									  ,@Usuario
									  ,@rfc
									  ,@cuentaContableHaber
									  ,@MOV_TIPOPOL
									  ,@MOV_CONSPOL
									  ,@MOV_CONSMOV
									  ,@MOV_MES
									  ,@anio
									  ,@MOV_DEBE
									  ,@MOV_HABER
									  ,@MOV_CONCEPTO
									  ,@referencia
									  ,@fechaoper
									  ,@mov_fecha
									  ,@MOV_IDCLIENTE
 
									SET @CounterInt  = @CounterInt  + 1 
				
								  END
								   IF OBJECT_ID('tempdb..#datoflap') IS NOT NULL
									   DROP TABLE #datoflap
							END
						End

   SET @Counter  = @Counter  + 1  
  
    BEGIN TRY
      /* COLOCAR AQUI LO DE MAIL ORDER */
		  EXEC PROCESAMIENTO_MAILORDER @idempresa
	END TRY
	BEGIN CATCH
	PRINT 'fallo sp PROCESAMIENTO_MAILORDER' + cast(@idempresa as varchar(5))
	END CATCH
	--=============================================

END
   IF OBJECT_ID('tempdb..#datosflaptemp') IS NOT NULL
    DROP TABLE #datosflaptemp
  END
END

go

