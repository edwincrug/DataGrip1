
create PROCEDURE [dbo].[INS_REFERENCIAS_TRAMITES_SP] 
	@idEmpresa INT 
	,@idSucursal INT 
	,@idDepartamento INT 
	,@idOrigenReferencia INT 
	,@idBancoOrigen INT 
	,@idBancoDestino INT 
	,@documento VARCHAR(100) 
	,@importe NUMERIC(18,4) 
	,@idPersona NUMERIC(18,0) 
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY 
		BEGIN TRANSACTION referenciaTramites
			--IDempresa|fecha|ctabancori|ctabacdest|sisemaori|cons <-- Como se compone la referencia
			----001|12052020|001|002|1|01 <--Ejemplo de la referencia
			DECLARE @referencia VARCHAR(20) = ''
			DECLARE @consecutivo INT = 0
			DECLARE @idReferencia INT = 0
			SET @referencia =	RIGHT('000' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @idEmpresa))),3)  
								+ REPLACE(CONVERT(VARCHAR(20), GETDATE(), 103), '/', '') 
								+ RIGHT('000' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @idBancoOrigen))),3)  
								+ RIGHT('000' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @idBancoDestino))),3)  
								+ CONVERT(VARCHAR(4), @idOrigenReferencia) 
			--SELECT @referencia
			--SELECT * FROM [dbo].[ReferenciaTramite] WHERE SUBSTRING(referencia,1,18) = @referencia
			SELECT @consecutivo = ISNULL(COUNT(idReferenciaTramite),0) + 1 FROM [dbo].[ReferenciaTramite] WHERE SUBSTRING(referencia,1,18) = @referencia
			SET @referencia = @referencia + RIGHT('00' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @consecutivo))),2) 
			--SELECT @referencia 
			INSERT INTO [dbo].[ReferenciaTramite]  (idEmpresa
													,fecha
													,referencia
													,idOrigenReferencia
													,consecutivo
													,estatus)
			VALUES(@idEmpresa, GETDATE(),  @referencia, @idOrigenReferencia, @consecutivo, 1)
			SET @idReferencia = @@IDENTITY;
			INSERT INTO [DetalleReferenciaTramite] (idReferenciaTramite
													,idSucursal
													,idDepartamento
													,idBancoOrigen
													,idBancoDestino
													,documento
													,importe
													,idPersona)
			VALUES(@idReferencia, @idSucursal, @idDepartamento,@idBancoOrigen, @idBancoDestino, @documento, @importe, @idPersona)
			SELECT 1 AS estatus,'Se inserto correctamente la referencia' AS mensaje, @referencia AS referencia
		COMMIT TRANSACTION referenciaTramites		
	END TRY
	BEGIN CATCH		
		ROLLBACK TRANSACTION referenciaTramites
		SELECT 0 AS estatus,ERROR_MESSAGE() AS mensaje
	END CATCH
END
go

