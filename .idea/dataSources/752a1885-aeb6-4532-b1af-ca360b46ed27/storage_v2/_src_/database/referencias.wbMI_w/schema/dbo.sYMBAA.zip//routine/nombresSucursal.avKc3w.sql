
CREATE FUNCTION [dbo].[nombresSucursal](@idDepartamento int)
RETURNS varchar(100)
AS
BEGIN

	declare @result varchar(100)

set @result = (select dep_nombre from [ControlAplicaciones].[DBO].[cat_departamentos] departamentos where dep_iddepartamento = @idDepartamento)
	return @result


END

go

