


-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 06-10-2020
-- Description: Inserta resgistro del proceso de Pago Avanzado Flap
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_LogPagosFlap2] 
	 (	    @Servicio varchar(100)=NULL
           ,@Metodo varchar(100)=NULL
           ,@OrigenPago  int=NULL
           ,@Descripcion varchar(500)=NULL
           ,@Contenido nvarchar(max)=NULL
	)

AS
BEGIN
   --Star TryCatch
	BEGIN TRY  
	INSERT INTO [dbo].[LogPagosFlap2]
           ([Servicio]
           ,[Metodo]
           ,[OrigenPago]
           ,[Descripcion]
           ,[Contenido]
           ,[FechaRegistro]
		   )
		 VALUES
			   (
				@Servicio
			   ,@Metodo
			   ,@OrigenPago
			   ,@Descripcion
			   ,@Contenido
			   ,GETDATE()
			   )

	END TRY  
	BEGIN CATCH  
		SELECT  ERROR_NUMBER() AS ErrorNumber
				,ERROR_SEVERITY() AS ErrorSeverity  
				,ERROR_STATE() AS ErrorState  
				,ERROR_PROCEDURE() AS ErrorProcedure  
				,ERROR_LINE() AS ErrorLine  
				,ERROR_MESSAGE() AS ErrorMessage;  

	END CATCH; 
	--End TryCatch



END
go

