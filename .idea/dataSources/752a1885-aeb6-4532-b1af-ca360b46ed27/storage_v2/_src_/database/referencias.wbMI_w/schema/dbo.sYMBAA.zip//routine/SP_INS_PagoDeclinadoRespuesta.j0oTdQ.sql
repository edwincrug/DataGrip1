


-- =============================================
-- Author:		Emiliano Damazo Gallardo
-- Create date: 11-10-2019
-- Description: Inserta la respuesta de solicitud del metodo imprimeDeclinado de la Pin Pad
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PagoDeclinadoRespuesta] 
	 (		@idTrans numeric(18,0)=0
           ,@autorizacion varchar(20)=NULL
		   ,@titular varchar(50)=NULL
		   ,@importe varchar(20)=NULL
		   ,@tarjeta varchar(100)=NULL

           ,@afiliacion varchar(20)=NULL                             
           ,@comercio varchar(100)=NULL
           ,@criptograma varchar(300)=NULL
           ,@direccion varchar(100)=NULL
           ,@emisor varchar(50)=NULL
           ,@fechaTransaccion varchar(10)=NULL
           ,@horaTransaccion varchar(10)=NULL
           ,@promocion varchar(50)=NULL
           ,@razonSocial varchar(50)=NULL
           ,@serie varchar(50)=NULL
           ,@tipoOperacion varchar(30)=NULL
           ,@mensaje varchar(300)=NULL
	)

AS
BEGIN

		BEGIN TRY  --Estar TryCatch

		INSERT INTO [dbo].[PagoDeclinadoRespuesta]
           ([idTrans]
           ,[afiliacion]
           ,[autorizacion]
           ,[comercio]
           ,[criptograma]
           ,[direccion]
           ,[emisor]
           ,[fechaTransaccion]
           ,[horaTransaccion]
           ,[monto]
           ,[promocion]
           ,[razonSocial]
           ,[serie]
           ,[tarjeta]
           ,[tipoOperacion]
           ,[titular]
           ,[mensaje]
           ,[fechaRegistro])
     VALUES
           (@idTrans
           ,@afiliacion
           ,@autorizacion
           ,@comercio
           ,@criptograma
           ,@direccion
           ,@emisor
           ,@fechaTransaccion
           ,@horaTransaccion
           ,@importe
           ,@promocion
           ,@razonSocial
           ,@serie
           ,@tarjeta
           ,@tipoOperacion
           ,@titular
           ,@mensaje
           ,GETDATE())

		END TRY  
		BEGIN CATCH  
			--Log Error
				INSERT INTO [dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[PagoDeclinadoRespuesta]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro

		END CATCH; --End TryCatch

END
go

