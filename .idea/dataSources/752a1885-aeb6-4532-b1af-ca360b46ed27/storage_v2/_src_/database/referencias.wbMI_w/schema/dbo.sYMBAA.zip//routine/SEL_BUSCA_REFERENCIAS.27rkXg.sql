/*

SEL_BUSCA_REFERENCIAS @idUsuario = 71,@textoBuscar = '04OH13070XC100572412', @idTipoBusqueda = 1, @idEmpresa = 0, @idSucursal = 0, @idDepartamento = -1,@idCliente = 0

*/

CREATE PROCEDURE [dbo].[SEL_BUSCA_REFERENCIAS]
@idUsuario INT = 0,
@textoBuscar VARCHAR(200) = '', --<referencia,factura,cotizacion,persona>
@idTipoBusqueda INT = 0, --<referencia: 1,factura: 2,cotizacion: 3,persona: 4>
@idEmpresa INT = 0,
@idSucursal INT = 0,
@idDepartamento INT = 0,
@idCliente INT = 0
AS

	DECLARE @idReferencia NUMERIC(18,0) = 0, @referencia VARCHAR(200) = @textoBuscar 

	IF @idTipoBusqueda = 1 --referencia
		BEGIN
			SELECT DISTINCT @idReferencia = idReferencia 
			FROM referencias.dbo.referencia
			WHERE referencia = @textoBuscar
		END
	
	IF @idTipoBusqueda = 2 --factura / cotizacion (buscar en el detalle y obtener el idReferencia, mostrar todo
		BEGIN
			SELECT TOP(1) @referencia = referencia, @idReferencia = REF.idReferencia
			FROM referencias.dbo.referencia REF
			JOIN referencias.dbo.detallereferencia DETREF ON REF.idReferencia = DETREF.idReferencia
			WHERE documento = @textoBuscar
		END
			
			--referencias
			SELECT idReferencia, fecha,referencia, numeroConsecutivo, tipoReferencia 
			FROM referencias.dbo.referencia WHERE idReferencia = @idReferencia 
			
			--detalle referencias / documentos
			SELECT DETREF.idDetalleReferencia,DETREF.idCliente,
				   CLI.per_nomrazon  + ' ' + ISNULL(CLI.per_paterno,'') + ' ' + ISNULL(CLI.per_materno,'') per_nomrazon,
				   ISNULL(d.ucn_total,importeDocumento) importeDocumento,DETREF.documento,
				   DETREF.idReferencia
				   ,emp.emp_nombre
				   ,suc.suc_nombre
				   ,dep.dep_nombre 
			FROM referencias.dbo.detallereferencia DETREF
			LEFT JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal u on DETREF.documento=u.ucu_foliocotizacion collate database_default
            LEFT JOIN  cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES d on u.ucu_idcotizacion=d.ucu_idcotizacion

			LEFT JOIN referencias.dbo.referencia REF ON DETREF.idReferencia = REF.idReferencia
			LEFT JOIN ControlAplicaciones.[dbo].[cat_empresas] emp ON REF.idEmpresa = emp.emp_idempresa
			LEFT JOIN ControlAplicaciones.[dbo].[cat_sucursales] suc ON DETREF.idSucursal = suc.suc_idsucursal
			LEFT JOIN ControlAplicaciones.[dbo].[cat_departamentos] dep ON DETREF.idDepartamento = dep.dep_iddepartamento
			LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS CLI ON DETREF.idCliente = CLI.per_idpersona
			WHERE DETREF.idReferencia = @idReferencia

			--movimientos
			SELECT rap_referencia, rap_iddocto, rap_importe, rap_numctabanc,rap_fecha, rap_referenciabancaria, rap_anno,
				   CASE  
						WHEN rap_idstatus IN (2,3) THEN 'PROCESADO'
						ELSE 'POR PROCESAR'
				   END estatus	 
			FROM GA_Corporativa.dbo.cxc_refantypag REFPAG
			WHERE rap_referenciabancaria = @referencia
			
--IF @idTipoBusqueda = 1 --referencia
--	BEGIN

--		SELECT REFPAG.rap_folio, 
--			   REFPAG.rap_idempresa, 
--			   REFPAG.rap_idsucursal, 
--			   REFPAG.rap_iddepartamento,
--			   REFPAG.rap_idpersona, --BDPersonas ?
--			   REFPAG.rap_cobrador,
--			   REFPAG.rap_referencia,
--			   REFPAG.rap_iddocto,
--			   REFPAG.rap_cotped,
--			   REFPAG.rap_importe,
--			   REFPAG.rap_numctabanc,
--			   REFPAG.rap_fecha,
--			   REFPAG.rap_idusuari,
--			   --REFPAG.			   
--			   REFPAG.rap_anno
--		FROM GA_Corporativa.dbo.cxc_refantypag REFPAG
--		--LEFT JOIN BDPersonas
--		WHERE REFPAG.rap_referenciabancaria = @textoBuscar AND REFPAG.rap_idstatus = 2
--		AND ((REFPAG.rap_idempresa = @idEmpresa) OR (@idEmpresa = 0)) 
--		AND	((REFPAG.rap_idsucursal = @idSucursal) OR (@idSucursal = 0)) 
--		AND	((REFPAG.rap_iddepartamento = @idDepartamento) OR (@idDepartamento = -1))

--		/*SELECT * FROM Referencia REF 
--		LEFT JOIN Referencias.dbo.DetalleReferencia REFDET ON REFDET.idReferencia =  REF.referencia--1169
--		LEFT JOIN GA_Corporativa.dbo.cxc_refantypag REFPAG ON 
--		WHERE REF.referencia = @textoBuscar
--		--SELECT * FROM Referencias.dbo.DetalleReferencia REFDET where REFDET.idReferencia =  REF.referencia--1169
--		--SELECT * FROM GA_Corporativa.dbo.cxc_refantypag WHERE rap_referenciabancaria = '0BDD170206C100035735' AND rap_idstatus = 2
--		*/
--	END
--ELSE
--IF @idTipoBusqueda = 2 --factura / cotizacion (buscar en el detalle y obtener el idReferencia, mostrar todo
--	BEGIN

--		SELECT REF.idReferencia,
--			   REF.referencia,
--			   DETREF.importeDocumento,
--			   DETREF.documento,
--			   DETREF.idCliente,
--			   CLI.per_nomrazon  + ' ' + ISNULL(CLI.per_paterno,'') + ' ' + ISNULL(CLI.per_materno,'') per_nomrazon,
--			   REF.fecha
--		FROM Referencia REF
--		LEFT JOIN DetalleReferencia DETREF ON REF.idReferencia = DETREF.idReferencia 
--		LEFT JOIN BDPersonas.dbo.cat_personas CLI ON DETREF.idCliente = CLI.per_idpersona 
--		WHERE DETREF.documento = @textoBuscar
--		AND ((REF.idEmpresa = @idEmpresa) OR (@idEmpresa = 0)) 
--		AND	((DETREF.idSucursal = @idSucursal) OR (@idSucursal = 0)) 
--		AND	((DETREF.idDepartamento = @idDepartamento) OR (@idDepartamento = -1))
--		--SELECT * FROM Referencia
--		--SELECT * FROM DetalleReferencia
--		--SELECT * FROM BDPersonas.dbo.cat_personas WHERE per_idpersona = 42165
		
--	END
--ELSE
--/*IF @idTipoBusqueda = 3 --cotizacion
--	BEGIN

--		SELECT REF.idReferencia,
--			   REF.referencia,
--			   DETREF.importeDocumento,
--			   DETREF.documento,
--			   DETREF.idCliente,
--			   CLI.per_nomrazon + ' ' + ISNULL(CLI.per_paterno,'') + ' ' + ISNULL(CLI.per_materno,'') per_nomrazon,
--			   REF.fecha
--		FROM Referencia REF
--		LEFT JOIN DetalleReferencia DETREF ON REF.idReferencia = DETREF.idReferencia 
--		LEFT JOIN BDPersonas.dbo.cat_personas CLI ON DETREF.idCliente = CLI.per_idpersona 
--		WHERE DETREF.documento = @textoBuscar
--		AND ((REF.idEmpresa = @idEmpresa) OR (@idEmpresa = 0)) 
--		AND	((DETREF.idSucursal = @idSucursal) OR (@idSucursal = 0)) 
--		AND	((DETREF.idDepartamento = @idDepartamento) OR (@idDepartamento = -1))

--	END
--ELSE*/
--IF @idTipoBusqueda = 3 --persona
--	BEGIN
		
--		SELECT REF.idReferencia,
--			   REF.referencia,
--			   DETREF.importeDocumento,
--			   DETREF.documento,
--			   DETREF.idCliente,
--			   CLI.per_nomrazon + ' ' + ISNULL(CLI.per_paterno,'') + ' ' + ISNULL(CLI.per_materno,'') per_nomrazon,
--			   REF.fecha
--		FROM Referencia REF
--		LEFT JOIN DetalleReferencia DETREF ON REF.idReferencia = DETREF.idReferencia 
--		LEFT JOIN BDPersonas.dbo.cat_personas CLI ON DETREF.idCliente = CLI.per_idpersona 
--		WHERE DETREF.idCliente = @idCliente
--		AND ((REF.idEmpresa = @idEmpresa) OR (@idEmpresa = 0)) 
--		AND	((DETREF.idSucursal = @idSucursal) OR (@idSucursal = 0)) 
--		AND	((DETREF.idDepartamento = @idDepartamento) OR (@idDepartamento = -1))

--		--SELECT * FROM DetalleReferencia WHERE idCliente = @idCliente	    
--	END


----referencia
--/*
--SELECT * FROM Referencias.dbo.Referencia where referencia = '0BDD170206C100035735'
--SELECT * FROM Referencias.dbo.DetalleReferencia where idReferencia = 1169
--SELECT * FROM GA_Corporativa.dbo.cxc_refantypag WHERE rap_referenciabancaria = '0BDD170206C100035735' AND rap_idstatus = 2
--*/
go

