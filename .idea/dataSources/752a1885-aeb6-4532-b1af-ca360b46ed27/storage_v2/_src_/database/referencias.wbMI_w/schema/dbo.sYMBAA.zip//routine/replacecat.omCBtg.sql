
-- =============================================
-- Author:		Gibran A. Quintero
-- Create date: 27052016
-- Description:	convierte numeros en base decimal a  base X
-- =============================================
CREATE Function [dbo].[replacecat]
(
	@n int
)
Returns int As
Begin
	--Set @base = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'

	Declare @baseNum int
	if @n in(11,7,6,1)
	set @baseNum= 3
	else
	Set @basenum=@n

	Return @baseNum
End

go

