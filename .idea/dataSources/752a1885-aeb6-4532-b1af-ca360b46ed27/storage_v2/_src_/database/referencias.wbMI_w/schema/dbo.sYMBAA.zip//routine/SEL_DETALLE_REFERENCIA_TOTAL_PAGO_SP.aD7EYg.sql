-- [SEL_DETALLE_REFERENCIA_TOTAL_PAGO_SP] 9
CREATE PROCEDURE [dbo].[SEL_DETALLE_REFERENCIA_TOTAL_PAGO_SP]
@idReferencia INT = 0
AS
BEGIN
	DECLARE @tipoDocumento INT


	SELECT	@tipoDocumento = idTipoDocumento  
	FROM	[referencias].DBO.[Referencia] REF
			INNER JOIN [referencias].DBO.[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia
	WHERE	REF.idReferencia = @idReferencia

	IF(@tipoDocumento = 2)
		BEGIN
			SELECT	CONVERT(varchar(50), CONVERT(money, sum(CD.ucn_total)), 1) totalPago		--CONVERT(money, DEREF.importeDocumento) as Total
			FROM	[referencias].DBO.[Referencia] REF
					INNER JOIN [referencias].DBO.[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia
					INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS C ON C.ucu_foliocotizacion = DEREF.documento COLLATE Modern_Spanish_CI_AS
					INNER JOIN cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES AS CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
			WHERE	REF.idReferencia = @idReferencia
		END
	ELSE 
		BEGIN
			SELECT	CONVERT(varchar(50), CONVERT(money, sum(DEREF.importeDocumento)), 1) totalPago		--CONVERT(money, DEREF.importeDocumento) as Total
			FROM	[referencias].DBO.[Referencia] REF
					INNER JOIN [referencias].DBO.[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia
			WHERE	REF.idReferencia = @idReferencia
		END
END



go

