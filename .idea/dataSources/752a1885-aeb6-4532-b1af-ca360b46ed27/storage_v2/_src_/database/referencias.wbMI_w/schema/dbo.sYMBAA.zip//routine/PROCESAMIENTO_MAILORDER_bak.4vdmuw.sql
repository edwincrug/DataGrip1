-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	INSERTA EN REFANTYPAG LAS REFERENCIAS QUE VENGAN DE DATOSFLAP
--              QUE SEAN DE TIPO MAILORDER Y QUE NO ESTEN FACTURADAS PARA 
--				SERVICIOS Y REFACCIONES
-- [PROCESAMIENTO_MAILORDER] 10
-- =============================================
CREATE PROCEDURE [dbo].[PROCESAMIENTO_MAILORDER] 
	@idEmpresa INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		DECLARE @FacturaQuery VARCHAR(MAX) = '';
		  DECLARE @Base VARCHAR(MAX) = '';
		  DECLARE @idDeposito INT = '';
		  DECLARE @idBanco INT = 1;

		  DECLARE @countDep INT = 0;
		  DECLARE @rap_folio INT = 0;
		  DECLARE @documento varchar(50) = ''
		  declare @referenciaPorProcesar varchar(100) =''

		  -- Consulta de las bases de datos y sucursales activas
		  DECLARE @tableConf TABLE (
			idEmpresa INT
		   ,idSucursal INT
		   ,servidor VARCHAR(250)
		   ,baseConcentra VARCHAR(250)
		   ,sqlCmd VARCHAR(8000)
		   ,cargaDiaria VARCHAR(8000)
		  );
		  DECLARE @tableBancoFactura TABLE (
			consecutivo INT IDENTITY (1, 1)
		   ,idDeposito INT
		  );
		  DECLARE @tableBancoCotizacion TABLE (
			consecutivo INT IDENTITY (1, 1)
		   ,idDeposito INT
		  );
		  DECLARE @tableBancoOrden TABLE (
			consecutivo INT IDENTITY (1, 1)
		   ,idDeposito INT
		   ,referencia varchar(50)
		   ,documento varchar(50)
		   ,idEmpresa int
		   ,idSucursal int
		  );
		  DECLARE @tableBancoPedido TABLE (
			consecutivo INT IDENTITY (1, 1)
		   ,idDeposito INT
		   ,referencia varchar(50)
		   ,documento varchar(50)
		   ,idEmpresa int
		   ,idSucursal int
		  );
		  INSERT INTO @tableConf EXECUTE [dbo].[SEL_ACTIVE_DATABASES_SP];
		  DECLARE @CountSuc INT = (SELECT
			  COUNT(idSucursal) Sucursales
			FROM @tableConf
			WHERE idEmpresa = @idEmpresa);
		  PRINT ('========================= [ RAP_Automaticas Mail Order _Bancomer_SP ] =========================');
		  PRINT ('EMPRESA ' + CONVERT(VARCHAR(2), @idEmpresa) + ': SUCURSALES ' + CONVERT(VARCHAR(3), @CountSuc));

		  DECLARE @Current INT = 0
				 ,@Max INT = 0;
		  DECLARE @CurrentBanco INT = 0
				 ,@MaxBanco INT = 0;
		  DECLARE @CurrentBancoCoti INT = 0
				 ,@MaxBancoCoti INT = 0;


		 declare @idEmpresaBD int, @idSucursalBD int, @BaseValidacion varchar(50)

		 declare @facturada table(documento varchar(20))
		 declare @query nvarchar(max) =''

		  SELECT
			@Current = MIN(idSucursal)
		   ,@Max = MAX(idSucursal)
		  FROM @tableConf
		  WHERE idEmpresa = @idEmpresa;
		  WHILE (@Current <= @Max)
		  BEGIN

		  DECLARE @ipLocal VARCHAR(15) = (SELECT
			  dec.local_net_address
			FROM sys.dm_exec_connections AS dec
			WHERE dec.session_id = @@SPID);

		  -- DECLARE @Base VARCHAR(300) = ''
		  IF (@ipLocal = (SELECT
				ip_servidor
			  FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
			  WHERE emp_idempresa = @idEmpresa
			  AND tipo = 2)
			)
		  BEGIN
			SET @Base = (SELECT
				'[' + nombre_base + '].[dbo]'
			  FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
			  WHERE emp_idempresa = @idEmpresa
			  AND tipo = 2);
		  END
		  ELSE
		  BEGIN
			SET @Base = (SELECT
				'[' + ip_servidor + '].[' + nombre_base + '].[dbo]'
			  FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
			  WHERE emp_idempresa = @idEmpresa
			  AND tipo = 2);
		  END

		  -- / VALIDACION PARA NO ESPECIFICAR EL SERVER DE UN PUNTO AL  -- FUNCIONAMIENTO PARA PEDIDO
		  -- FUNCIONAMIENTO PARA PEDIDO		
		  SET @FacturaQuery = 'SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.concepto,3,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP 
											ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR 
											ON  DR.idReferencia = R.idReferencia 
											AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
											AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R 
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,1,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP 
											ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R 
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,2,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R 
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,3,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP 
											ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,4,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R 
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,5,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,6,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R 
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,7,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,8,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = b.referencia
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	= 3
											  
											  ';

		  INSERT INTO @tableBancoPedido
		  EXECUTE (@FacturaQuery);

		 -- print @FacturaQuery

		  -- Inicia segundo While
		  /*
		  VALIDAMOS QUE LA REFERENCIA SEA DE FLAP - MAILORDER
		  */
		  DECLARE @tableBancoPedidoMailOrder table( 
		  consecutivo INT IDENTITY (1, 1)
		   ,idDeposito INT
		   ,referencia varchar(50)
		   ,documento varchar(50)
		   ,idEmpresa int
		   ,idSucursal int)

		   /*
		   OBTENEMOS LOS DEPOSITOS QUE SON DE MAILORDER
		   */
		   DELETE FROM @tableBancoPedidoMailOrder
		   insert into @tableBancoPedidoMailOrder(idDeposito,referencia,documento,idEmpresa,idSucursal)
		   select DISTINCT  bo.idDeposito
					,bo.referencia
					,bo.documento
					,bo.idEmpresa
					,bo.idSucursal
		   from @tableBancoPedido bo
		  join datosFlap fl
		  on bo.referencia = fl.referencia
		  join pago p
		  on fl.referencia = p.referencia
		  where P.idOrigen= 4 -- DE ACUERDO AL EJECICIO QUE REALIZO JAVIER 4 CORRESPONDE A MAIL ORDER

		  select distinct  
			@CurrentBancoCoti = MIN(consecutivo)
		   ,@MaxBancoCoti = MAX(consecutivo)
		  from @tableBancoPedidoMailOrder


		  IF(@CurrentBancoCoti >0 AND @MaxBancoCoti >0)
		  BEGIN

		  WHILE (@CurrentBancoCoti <= @MaxBancoCoti) ---- INICIO WHILE MAIL-ORDER
		  BEGIN
		  -- Funcionamiento de meter en cxc_refantypag
		  BEGIN TRY

			/*obtenemos el documento de la referencia*/
			select @documento = documento
			,@idEmpresaBD = idEmpresa
			,@idSucursalBD = idSucursal
			,@referenciaPorProcesar = referencia
			from @tableBancoPedidoMailOrder
			where consecutivo = @CurrentBancoCoti

			SELECT
			  @BaseValidacion = nombre_base+'.dbo.'
			FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
			WHERE emp_idempresa = @idEmpresaBD
			and suc_idsucursal = @idSucursalBD
			AND tipo = 1

			SET @query  = ('
						select TOP 1 fac.CDE_DOCTO
						from '+ @BaseValidacion+'ADE_VTACFD fac
						left join '+ @BaseValidacion+'ADE_CANCFD can
							on fac.VDE_DOCTO = can.CDE_DOCTO
						WHERE VDE_DOCTO = '''+@documento+'''
						and can.CDE_DOCTO is null
					')

			print @query
			/*LIMPIO LA TABLA*/
			DELETE FROM @facturada;
			/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
			insert @facturada
			EXEC sp_executesql @query

			/*SI LA TABLA TIENE DATOS QUIERE DECIR QUE YA SE FACTURO, DE LO CONTRARIO NO ESTA FACTURADA*/
			--SELECT * FROM @facturada

			/*validamos que no este facturada*/
			IF NOT EXISTS(
				SELECT TOP 1 * FROM @facturada
			) BEGIN

				SET @idDeposito = (SELECT TOP 1
									idDeposito
								  FROM @tableBancoPedidoMailOrder
								  WHERE consecutivo = @CurrentBancoCoti);


				SELECT
				  @FacturaQuery = [dbo].[fnReferenciaBancomerPedidoMailOrder](@Base,@idDeposito);
				  /*COMENTAR ESTO EN PRODUCCION*/
	    			SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
				--//////////////////////////
				EXECUTE (@FacturaQuery);

				  IF (@@ROWCOUNT > 0)
					BEGIN
					  SET @rap_folio = @@IDENTITY;
					  INSERT INTO [referencias].[dbo].[RAPDeposito] (idEmpresa, idSucursal, rap_folio, idBanco, idDeposito, idOrigenReferencia, fecha)
						VALUES (@idEmpresa, @Current, @rap_folio, @idBanco, @idDeposito, 'Procesos Automáticos | MAILORDER', GETDATE());
					  UPDATE [referencias].[dbo].[Bancomer]
					  SET estatusRevision = 2
					  WHERE idBmer = @idDeposito;
					END
					--PRINT (@FacturaQuery);
					PRINT ('        SUCCESS: Depósito [' + CONVERT(VARCHAR(10), @idDeposito) + '] PEDIDO: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio));

			END

		  END TRY
		  BEGIN CATCH
			INSERT INTO LogRAP (log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal)
			  VALUES (ERROR_MESSAGE(), 'Procesos Automáticos | PEDIDO', GETDATE(), @idBanco, @idDeposito, @idEmpresa, @Current);
			PRINT ('        ERROR: Depósito [' + CONVERT(VARCHAR(10), @idDeposito) + '] PEDIDO: ' + ERROR_MESSAGE());
		  END CATCH
 
		  SET @CurrentBancoCoti = @CurrentBancoCoti + 1;
		  END

		  END

  


		  PRINT ('');
		  -- /FUNCIONAMIENTO PARA PEDIDO
  
	
		  SET @FacturaQuery = 'SELECT distinct
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R 
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.concepto,3,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento  in (4,5)
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,1,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,2,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,3,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)5
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,4,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,5,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,6,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,7,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = SUBSTRING(b.refAmpliada,8,20)
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)
											  union all
										SELECT
											B.idBmer, r.referencia, dr.documento,r.idEmpresa, dr.idSucursal
										 FROM Referencia R
										 JOIN datosFlap f
											ON R.referencia = f.referencia
										 INNER JOIN Bancomer B 
											ON SUBSTRING(f.referenciaConciliacion, 0, CHARINDEX(''-'', f.referenciaConciliacion)) = b.referencia
										 INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP ON R.idEmpresa = BP.emp_idempresa
										 INNER JOIN DetalleReferencia DR ON  DR.idReferencia = R.idReferencia AND DR.idSucursal = BP.suc_idsucursal
										 WHERE R.idEmpresa				= ' + CONVERT(VARCHAR(3), @idEmpresa) + '
										  AND DR.idSucursal		 = ' + CONVERT(VARCHAR(3), @Current) + '
											  AND B.estatusRevision		= 1
											  AND B.esCargo				= 0
											  AND DR.idTipoDocumento	in (4,5)
											  
											  ';

		  INSERT INTO @tableBancoOrden
		  EXECUTE (@FacturaQuery);
		  -- print @FacturaQuery
		  -- Inicia segundo While
		  /*
		  VALIDAMOS QUE LA REFERENCIA SEA DE FLAP - MAILORDER
		  */

		  DECLARE @tableBancoOrdenMailOrder table( 
		  consecutivo INT IDENTITY (1, 1)
		   ,idDeposito INT
		   ,referencia varchar(50)
		   ,documento varchar(50)
		   ,idEmpresa int
		   ,idSucursal int)

		   /*
		   OBTENEMOS LOS DEPOSITOS QUE SON DE MAILORDER
		   */
		   DELETE FROM @tableBancoOrdenMailOrder
		   insert into @tableBancoOrdenMailOrder(idDeposito,referencia,documento,idEmpresa,idSucursal)
		   select DISTINCT  bo.idDeposito
					,bo.referencia
					,bo.documento
					,bo.idEmpresa
					,bo.idSucursal
		   from @tableBancoOrden bo
		  join datosFlap fl
		  on bo.referencia = fl.referencia
		  join pago p
		  on fl.referencia = p.referencia
		  where P.idOrigen= 4 -- DE ACUERDO AL EJECICIO QUE REALIZO JAVIER 4 CORRESPONDE A MAIL ORDER

		  select * from @tableBancoOrdenMailOrder

		  select distinct  
			@CurrentBancoCoti = ISNULL(MIN(consecutivo),0)
		   ,@MaxBancoCoti = ISNULL(MAX(consecutivo),0)
		  from @tableBancoOrdenMailOrder

		  --SELECT @CurrentBancoCoti AS MINI, @MaxBancoCoti AS MAXI

		  IF(@CurrentBancoCoti >0 AND @MaxBancoCoti >0)
		  BEGIN
			  WHILE (@CurrentBancoCoti <= @MaxBancoCoti) ---- INICIO WHILE MAIL-ORDER
			  BEGIN
			  -- Funcionamiento de meter en cxc_refantypag
				  BEGIN TRY
  			
					/*obtenemos el documento de la referencia*/
					select @documento = documento
					,@idEmpresaBD = idEmpresa
					,@idSucursalBD = idSucursal
					,@referenciaPorProcesar = referencia
					from @tableBancoOrdenMailOrder
					where consecutivo = @CurrentBancoCoti

					SELECT
					  @BaseValidacion = nombre_base+'.dbo.'
					FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
					WHERE emp_idempresa = @idEmpresaBD
					and suc_idsucursal = @idSucursalBD
					AND tipo = 1

					SET @query  = ('
						select TOP 1 fac.vte_docto
						from '+ @BaseValidacion+'ADE_VTAFI fac
						left join '+ @BaseValidacion+'ADE_CANCFD can
							on fac.VTE_DOCTO = can.CDE_DOCTO
						WHERE VTE_REFERENCIA1 = '''+@documento+'''
						and can.CDE_DOCTO is null
					')

					print @query
					/*LIMPIO LA TABLA*/
					DELETE FROM @facturada;
					/*INSERTO RESULTADO DE BUSQUEDA DE FACTURA*/
					insert @facturada
					EXEC sp_executesql @query

					/*SI LA TABLA TIENE DATOS QUIERE DECIR QUE YA SE FACTURO, DE LO CONTRARIO NO ESTA FACTURADA*/
					SELECT * FROM @facturada

					/*validamos que no este facturada*/
					IF NOT EXISTS(
						SELECT TOP 1 *
						FROM @facturada
					) BEGIN -- INICIO SI EXISTE

						SET @idDeposito = (SELECT TOP 1
							idDeposito
						  FROM @tableBancoOrdenMailOrder
						  WHERE consecutivo = @CurrentBancoCoti);

						  print @referenciaPorProcesar

						SELECT
						  @FacturaQuery = [dbo].[fnReferenciaBancomerOrdenMailOrder](@Base, @referenciaPorProcesar,@idDeposito);

						  --SELECT
						  --@FacturaQuery = [dbo].[fnReferenciaBancomerOrdenMailOrder](@Base,@idDeposito);
				
						/*COMENTAR ESTO EN PRODUCCION*/
	    				--SET @FacturaQuery = REPLACE( @FacturaQuery, 'INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )', '' );
						--//////////////////////////
						INSERT INTO GA_Corporativa.dbo.cxc_refantypag( rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito )
						EXECUTE (@FacturaQuery);
						PRINT '@FacturaQuery: '+ @FacturaQuery
						print '@@ROWCOUNT: '+ cast(@@IDENTITY as varchar(10))
						IF (@@IDENTITY > 0)
						BEGIN
						  SET @rap_folio = @@IDENTITY;
						  select @rap_folio as rap_folio
						  INSERT INTO [referencias].[dbo].[RAPDeposito] (idEmpresa, idSucursal, rap_folio, idBanco, idDeposito, idOrigenReferencia, fecha)
							VALUES (@idEmpresa, @Current, @rap_folio, @idBanco, @idDeposito, 'Procesos Automáticos | MAILORDER', GETDATE());
						  UPDATE [referencias].[dbo].[Bancomer]
						  SET estatusRevision = 2
						  WHERE idBmer = @idDeposito;
						END
						PRINT (@FacturaQuery);
						PRINT ('        SUCCESS: Depósito [' + CONVERT(VARCHAR(10), @idDeposito) + '] ORDEN: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio));

					END -- FIN SI EXISTE
				  END TRY
				  BEGIN CATCH
					--INSERT INTO LogRAP (log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal)
					--  VALUES (ERROR_MESSAGE(), 'Procesos Automáticos | ORDEN', GETDATE(), @idBanco, @idDeposito, @idEmpresa, @Current);
					PRINT ('        ERROR: Depósito [' + CONVERT(VARCHAR(10), @idDeposito) + '] ORDENg: ' + ERROR_MESSAGE());
				  END CATCH
	  
  
				SET @CurrentBancoCoti = @CurrentBancoCoti + 1;
			  END ---- FIN WHILE MAIL-ORDER
		  END
		  -- /FUNCIONAMIENTO PARA ORDEN


		  DELETE FROM @tableBancoOrden;
  
		  SET @Current = @Current + 1;
		  END




END
go

