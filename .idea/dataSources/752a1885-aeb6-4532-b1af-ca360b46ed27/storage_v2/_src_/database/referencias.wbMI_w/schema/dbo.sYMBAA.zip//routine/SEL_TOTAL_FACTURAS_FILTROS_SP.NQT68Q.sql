-- ==========================================================================================
-- Modified by   : Lourdes Maldonado Sanchez    
-- Date          : 03/09/2018 
-- Description   : Detalle de todas las Facturas en BI_CARTERA_CLIENTES
--                 Filtrando por idCliente, Empresa, Sucursal, Depto, Documento y/o Fechas
-- ========================================================================================== 
/*--8474
EXECUTE [SEL_TOTAL_FACTURAS_FILTROS_SP]
	  @idCliente     = 0,
	  @idEmpresaP    = 2,
	  @idSucursalP   = 0,
	  @idDeptoP      = -1,
	  @fechaIniP     = '',
	  @fechaFinP     = '',
	  @documento     = ''
*/
CREATE PROCEDURE [dbo].[SEL_TOTAL_FACTURAS_FILTROS_SP] 
      @idCliente     INT = 0,
	  @idEmpresaP    INT = 0,
	  @idSucursalP   INT = 0,
	  @idDeptoP      INT = 0,
	  @fechaIniP     VARCHAR(10) = '',
	  @fechaFinP     VARCHAR(10) = '',
	  @documento     VARCHAR(20) = ''
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @sIpaux            VARCHAR(100) = ''  
	DECLARE @aux               INT = 1
    DECLARE @max               INT = 0
    DECLARE	@idEmpresa	       NVARCHAR(50) =NULL
	DECLARE @nombreEmpresa     NVARCHAR(50) =NULL
	DECLARE	@idSucursal		   NVARCHAR(50) =NULL
	DECLARE	@nombreSucursal    NVARCHAR(50) =NULL
	DECLARE @nomBaseSucursal   NVARCHAR(50) =NULL
	DECLARE @ipServidor        NVARCHAR(50);
	DECLARE @cadIpServidor     VARCHAR(100);
	DECLARE @select            VARCHAR(MAX);

	--==========================================================================================--    
	--  INFORMACION DE CADA EMPRESA
	--==========================================================================================--
	SELECT @sIpaux= local_net_address
	  FROM sys.dm_exec_connections c
	 WHERE c.session_id = @@SPID

	DECLARE @Bases TABLE  ( IDB                INT IDENTITY(1,1)
							,ipServidor        nvarchar(20)
							,idEmpresa         nvarchar(30)
							,nombreEmpresa     nvarchar(100)
							,nomBaseSucursal   nvarchar(50)
							,idSucursal        nvarchar(30)
							,nombreSucursal    nvarchar(50)
							)

    IF(@idEmpresaP = 0)
	   SET @idEmpresaP = NULL	
	IF(@idSucursalP = 0)
	   SET @idSucursalP = NULL

		INSERT INTO @Bases
    		 SELECT B.[ip_servidor] 
				   ,B.[emp_idempresa] 
				   ,A.[emp_nombre] 
				   ,B.[nombre_base] 
				   ,S.[suc_idSucursal]         
				   ,S.[suc_nombre]           
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B 
				   INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON  B.catemp_nombrecto = A.emp_nombrecto 
				   INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] AS S ON B.catsuc_nombrecto = S.suc_nombrecto  
			 WHERE B.estatus = 1 
			   AND B.tipo = 1 
			   AND S.emp_idempresa= A.emp_idempresa AND A.emp_idempresa <> 7
			   AND B.[emp_idempresa] = COALESCE(@idEmpresaP, B.[emp_idempresa])
			   AND S.[suc_idSucursal] = COALESCE(@idSucursalP, B.[suc_idSucursal])
		  ORDER BY B.[emp_idempresa],S.[suc_idSucursal]

    --==========================================================================================--   
	--  RECORRIENDO CADA EMPRESA POR SUCURSAL
	--==========================================================================================--
    SET @max = (SELECT MAX(IDB) FROM @Bases)

	WHILE(@aux <= @max)
    BEGIN
		SELECT  @idEmpresa        = DB.idEmpresa
               ,@nombreEmpresa    = DB.nombreEmpresa
			   ,@idSucursal       = DB.idSucursal
			   ,@nombreSucursal   = ISNULL(DB.nombreSucursal,'N/A')	
               ,@nomBaseSucursal  = DB.nomBaseSucursal
			   ,@ipServidor       = DB.ipServidor
           FROM @Bases AS DB 
          WHERE DB.IDB = @aux  

        IF (@ipServidor = @sIpaux)   
		BEGIN
			SET @cadIpServidor =''
		END
		ELSE
		BEGIN
			SET @cadIpServidor =' [' + @ipServidor + '].'
		END
		--SELECT @cadIpServidor, @idEmpresa, @nombreEmpresa, @idSucursal, @nombreSucursal

		IF OBJECT_ID( @cadIpServidor +'['+ @nomBaseSucursal +'].[dbo].[BI_CARTERA_CLIENTES]') IS NOT NULL
			BEGIN
				    --INICIO
					--==========================================================================================--
					-- VARIABLE TABLA DE RESULTADO DE BUSQUEDA
					--==========================================================================================--

			 	 	DECLARE @todo TABLE  ( IDB                 INT IDENTITY(1,1)
											,idDocumento        nvarchar(30)
											,serie              nvarchar(20)
											,folio              nvarchar(30)
											,idEmpresa          nvarchar(30)
											,nombreEmpresa      nvarchar(30)
											,idSucursal         nvarchar(30)
											,nombreSucursal     nvarchar(30)
											,idDepartamento     nvarchar(30)
											,nombreDepartamento nvarchar(30)
											,origenMovimiento   nvarchar(30)
											,importe            nvarchar(30)
											,saldo              nvarchar(30)
											,nombreCliente      nvarchar(150)
											,fecha              nvarchar(30)
											,idCliente          nvarchar(30)
											,referencia         nvarchar(20)
											,tipoDocumento      int
											)
        
				  --
			  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  		  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  	  SET @select =	'SELECT ' + char(13) + 
						'BI.CCP_IDDOCTO' + char(13) + 
						',(select dbo.[fn_BuscaLetras](BI.CCP_IDDOCTO)) AS serie'+
						',(select dbo.[fn_BuscaNumeros](BI.CCP_IDDOCTO)) AS folio'+
						',E.emp_idempresa       AS idEmpresa' + char(13) + 
						',E.emp_nombre          AS nombreEmpresa' + char(13) + 
						',S.suc_idsucursal      AS idSucursal' + char(13) + 
						',S.suc_nombre          AS nombreSucursal' + char(13) + 
						',D.dep_iddepartamento  AS idDepartamento' + char(13) + 
						',D.dep_nombre          AS nombreDepa' + char(13) +
						',BI.OrigenMovimiento' + char(13) + 
						',BI.IMPORTE' + char(13) + 
						',BI.SALDO' + char(13) + 
						',RTRIM(LTRIM(P.per_nomrazon))  +'+char(39)+' '+char(39)+'+ RTRIM(LTRIM(P.per_paterno)) +'+char(39)+' '+char(39)+'+ RTRIM(LTRIM(P.per_materno))AS nombreCliente' + char(13) +
						',BI.CCP_FECHADOCTO' + char(13) + 
						',BI.CCP_IDPERSONA' + char(13) + 
						',(SELECT referencia 
							 FROM [referencias].[dbo].[Referencia] REF 
								  INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia 
							WHERE DEREF.documento = BI.CCP_IDDOCTO  COLLATE Modern_Spanish_CI_AS 
							  AND REF.idEmpresa ='+@idEmpresa +' AND  DEREF.idSucursal = '+@idSucursal +' AND REF.tipoReferencia = 1) AS referencia'+
						',1 AS idTipoDocumento' + char(13) + 
			     ' FROM '+ @cadIpServidor +'['+ @nomBaseSucursal +'].[dbo].[BI_CARTERA_CLIENTES] AS BI ' + char(13) + 					
					    ' INNER JOIN GA_Corporativa.dbo.PER_PERSONAS AS P ON P.per_idpersona = BI.CCP_IDPERSONA ' + char(13) + 
						' INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS E ON E.emp_idempresa = '+@idEmpresa +'' + char(13) + 
						' INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] AS S ON S.emp_idempresa = '+@idEmpresa +' AND S.suc_idsucursal = '+@idSucursal +'' + char(13) + 
						' INNER JOIN [dbo].[CatOrigenMovimiento] AS C ON BI.OrigenMovimiento COLLATE Modern_Spanish_CI_AS = C.OrigenMovimiento AND C.emp_idempresa = E.emp_idempresa AND C.suc_idsucursal = S.suc_idsucursal' + char(13) + 
						' INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] AS D ON D.emp_idempresa = '+@idEmpresa +' AND D.suc_idsucursal = '+@idSucursal +' AND D.dep_nombrecto = C.dep_nombrecto' + char(13) + 
                 'WHERE BI.MODULO = '+ char(39) +'CXC'+ char(39) +
				  ' AND SUBSTRING(BI.CCP_IDDOCTO,1,2) IN ( SELECT SUBSTRING(A.FCF_SERIE,1,2) FROM '+ @cadIpServidor +'['+ @nomBaseSucursal +'].dbo.ADE_CFDFOLIOS AS A) '              

					IF (@idCliente <> 0)   
					BEGIN
						PRINT 'SI HAY CLIENTE'
						SET @select = @select + ' AND BI.CCP_IDPERSONA = ' + cast (@idCliente  as varchar(10))
					END
					IF (@idDeptoP <> -1)   
					BEGIN
						PRINT 'SI HAY DEPTO'
						SET @select = @select + ' AND D.dep_iddepartamento = ' + cast (@idDeptoP  as varchar(10))
					END
					IF (@documento <> '')   
					BEGIN
						PRINT 'SI HAY DOCUMENTO'
						SET @select = @select + ' AND BI.CCP_IDDOCTO = ' + ''''+ @documento +''''
					END
					IF (@fechaIniP <> '' OR @fechaFinP <> '')
					BEGIN
						PRINT 'VALIDA FECHAS'
						SET @select = @select + ' AND CONVERT(DATE,REPLACE(BI.CCP_FECHADOCTO,'+''''+'-'+''''+','+''''+''''+'),105) BETWEEN CONVERT(DATE,'+''''+ @fechaIniP +''''+') AND CONVERT(DATE,'+''''+ @fechaFinP +''''+' ) '
					END
			
				PRINT @select	  
				INSERT INTO @todo EXECUTE (@select)
				--FIN
            END
		SET @aux = @aux + 1
	END

	--==========================================================================================--   
	--  CONSULTA FINAL DE TODAS LAS EMPRESAS SEGUN LOS FILTROS
	--==========================================================================================--
	 SELECT IDB 
			,folio       as idDocumento
			,serie 
			,idDocumento as folio
			,idEmpresa 
			,nombreEmpresa 
			,idSucursal 
			,nombreSucursal 
			,idDepartamento  
			,nombreDepartamento 
			,origenMovimiento 
			,importe 
			,saldo 
			,nombreCliente     
			,fecha  
			,idCliente  
			,referencia 
			,tipoDocumento 
		FROM @todo
 
END
go

