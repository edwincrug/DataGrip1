-- =============================================
-- Author:		
-- Create date: 21092016
-- Description:	genera y regresa referencia bancaria
-- =============================================
-- select [dbo].[referencia_lote]('1',1,3)
CREATE FUNCTION [dbo].[referencia_lote]
(	
	@idRefereciaLotePago VARCHAR(10),
	@idEmpresa int = 0,
	@tipo INT = 0
	--@consecutivo TINYINT = 0
)
RETURNS VARCHAR(19)
AS
BEGIN	
	
	DECLARE @referencia VARCHAR(19) = '' 
	declare @tipoDoc varchar(1) = '';

	SET @idRefereciaLotePago = REPLICATE('0',10-LEN(@idRefereciaLotePago)) + CONVERT(VARCHAR(10),@idRefereciaLotePago)  

	IF @tipo = 1
		SET @tipoDoc = 'F';
	ELSE
		IF @tipo = 2
			SET @tipoDoc = 'C';
		ELSE
			SET @tipoDoc = 'P';
		         
	SELECT  @referencia = --0 +
		 REPLICATE('0',1-LEN(CONVERT(VARCHAR(1),CONVERT(VARCHAR(1),0)))) + CONVERT(VARCHAR(1),0) +
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(MM,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(MM,GETDATE())),'0123456789AB') + -- conversion a base 12
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(DD,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(DD,GETDATE())),'0123456789ABCDEFGHIJKLMNOPQRSTUV') + -- conversion a base 31
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE())) ,'0123456789ABCDEFGHIJKLMN') + -- conversion a base 24
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())) + -- conversión base 10
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),CONVERT(VARCHAR(2),[dbo].[intToBase]( @idEmpresa ,'0123456789'))))) + CONVERT(VARCHAR(2),[dbo].[intToBase]( @idEmpresa ,'0123456789')) + --conversión a base 36, investigar que es Suc
		 @tipoDoc + @idRefereciaLotePago 
	RETURN @referencia
END


go

