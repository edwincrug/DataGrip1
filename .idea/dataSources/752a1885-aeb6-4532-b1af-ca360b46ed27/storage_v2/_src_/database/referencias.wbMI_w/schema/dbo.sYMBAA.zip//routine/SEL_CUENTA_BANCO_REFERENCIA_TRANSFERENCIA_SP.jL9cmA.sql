-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CUENTA_BANCO_REFERENCIA_TRANSFERENCIA_SP]
	@idEmpresa int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT BC.idBanco
	      ,BC.numeroCuenta cuenta
		  ,BC.convenio
	      ,B.nombre                    --ADD LMS 22/08/2018
		  ,CASE WHEN (BC.idBanco = 1)
		        THEN 'http://192.168.20.92//GA_Centralizacion//CuentasXPagar//LogoBancos//Bancomer.png'
		        WHEN (BC.idBanco = 2)
		        THEN '\images\banamex_logo.jpg'   --http://192.168.20.92//GA_Centralizacion//CuentasXPagar//LogoBancos//Banamex.png'
				WHEN (BC.idBanco = 3)
		        THEN '\images\santander_logo.jpg' --http://192.168.20.92//GA_Centralizacion//CuentasXPagar//LogoBancos//Santander.png
            ELSE ''
           END AS rutaLogo
		   --,B.urlLogo  AS rutaLogo   --ADD LMS 22/08/2018
	  FROM BancoCuenta BC
	       INNER JOIN dbo.Banco B on B.idBanco = BC.idBanco
	 WHERE BC.idEmpresa = @idEmpresa  
	   AND B.activo = 1  
	   AND BC.activo = 1
	   AND tipoCuenta = '1' 
	   AND BC.convenio <> '0'    --ADD LMS
	   AND BC.tipoPago = 2	--ADD DVR
	 ORDER BY BC.idBanco ASC
END
go

