-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<crea poliza de la tabla [dbo].[datosFlap]>
-- =============================================
--[dbo].[CreaPoliza_INS] 
/*
RESPALDO DE PRODUCCION 29/06/2020
*/
CREATE PROCEDURE [dbo].[CreaPolizaPINPAD_INS]

AS
BEGIN

	--select id_registro,tipoPago,referencia,importe,comision,ivaComision,fechaPago,cuentaBancaria,idEmpresa,idBanco,estatusProcesado 
	--from datosFlap 
	--where cuentaBancaria is not null and estatusProcesado= 0

	--select * from Bancomer where noCuenta='000000000195334667' and importe=2.5 and refampliada like '%Multipagos%'

	DECLARE @Counter INT = 1, 
			@MaxId INT, 
			@fechaPago DATE,
			@cuentaBancaria NVARCHAR(20),
			@idbanco INT,
			@importe DECIMAL(18,2),
			@idempresa INT,
			@referencia NVARCHAR(50),
			@sucursal INT,
			@unidadNegocio INT,
			@categoriacobranza INT,
			@poliza_traspaso nvarchar(10),
			@importeBanco decimal(18,2),
			@idTipoDocumento int
	DECLARE @idbmer INT = 0, @cuentaContableDebe NVARCHAR(20) = '', @cuentaContableHaber NVARCHAR(20) = '', @nombrebase NVARCHAR(150), @sql NVARCHAR(max) = '', @ParmDefinition NVARCHAR(max)
	DECLARE @MOV_IDCLIENTE INT = 0, @rfc NVARCHAR(20) = '', @MOV_MES INT, @anio INT, @MOV_CONSPOL INT, @MOV_CONSPOLOUT NVARCHAR(10) = '', @consecutivocontable INT = 0, @nuevareferencia NVARCHAR(22)
		DECLARE @serie NVARCHAR(2), @idTipoReferencia INT = 1, @folio NVARCHAR(4)
			DECLARE @RC int
							DECLARE @idRegistro int=0
							DECLARE @idUsuario nvarchar(4)='GMI'
							DECLARE @Usuario int=0
							DECLARE @MOV_TIPOPOL nvarchar(10)
							DECLARE @MOV_DEBE decimal(18,5)
							DECLARE @MOV_HABER decimal(18,5)
							DECLARE @MOV_CONSMOV int 
							DECLARE @fechaoper datetime
							DECLARE @mov_fecha datetime
							DECLARE @MOV_CONCEPTO nvarchar(100)
	DECLARE @MaxIdInt INT = 0, @CounterInt INT = 1, @id_registro INT,  @tipoPago NVARCHAR(10), @MOV_CONCEPTOOUT NVARCHAR(250) = '';

DECLARE @datosflaptemp TABLE (
	[rowNumber] [bigint] NULL,
	[fechaPago] [date] NULL,
	[cuentaBancaria] [varchar](100) NULL,
	[idEmpresa] [int] NULL,
	[idSucursal] [int] NULL,
	[importe] [decimal](38, 2) NULL,
	[unidadNegocio] [int] NULL,
	[categoriacobranza] [int] NULL,
	[tipopago] [varchar](10) NULL
)

DECLARE @tempeval TABLE (
	rowNumber int identity,
	[idbmer] [int] NULL,
	[importeBanco] [decimal](18, 2) NULL,
	[fechaPago] [varchar](30) NULL,
	[cuentaBancaria] [varchar](100) NULL,
	[idEmpresa] [int] NULL,
	[idSucursal] [int] NULL,
	[importe] [decimal](18, 2) NULL,
	[unidadNegocio] [int] NULL,
	[categoriacobranza] [int] NULL,
	[idorigen] [int] NOT NULL,
	[tipoPago] [varchar](10) NULL,
	[documento] [varchar](max) NOT NULL,
	[idCliente] [numeric](18, 0) NOT NULL,
	[referencia] [char](20) NOT NULL,
	[idTipoDocumento] [numeric](18, 0) NOT NULL
) 
DECLARE @tempeval2 TABLE (
	rowNumber int identity,
	[idbmer] [int] NULL,
	[importeBanco] [decimal](18, 2) NULL,
	[fechaPago] [varchar](30) NULL,
	[cuentaBancaria] [varchar](100) NULL,
	[idEmpresa] [int] NULL,
	[idSucursal] [int] NULL,
	[importe] [decimal](18, 2) NULL,
	[unidadNegocio] [int] NULL,
	[categoriacobranza] [int] NULL,
	[idorigen] [int] NOT NULL,
	[tipoPago] [varchar](10) NULL,
	[documento] [varchar](max) NOT NULL,
	[idCliente] [numeric](18, 0) NOT NULL,
	[referencia] [char](20) NOT NULL,
	[idTipoDocumento] [numeric](18, 0) NOT NULL
) 


insert into @datosflaptemp
	SELECT 
		ROW_NUMBER() OVER(ORDER BY fechaPago,idempresa ASC) AS rowNumber,
		fechaPago,
		cuentaBancaria,
		idEmpresa,
		idSucursal,
		SUM(importe) importe,
		unidadNegocio,
		dbo.replacecat(categoriacobranza),
		tipopago
	
	FROM (select convert(date,fechaPago) fechaPago,
		fl.cuentaBancaria,
		fl.idEmpresa,
		fl.idSucursal,
		fl.importe,
		fl.estatusProcesado,
		fl.unidadNegocio,
		fl.categoriacobranza,
		Replace(fl.tipoPago,'CIE','TDX') tipoPago
		from datosFlap fl
		inner join pago p on fl.numeroOrden=p.idtrans and p.idOrigen!=4
	
		 ) x
	WHERE cuentaBancaria is not null and estatusProcesado= 0 --and fechaPago='2020-09-11'
	GROUP BY fechaPago,unidadNegocio,
		dbo.replacecat(categoriacobranza),cuentaBancaria,idEmpresa,idSucursal,TipoPago


			--PRINT 'Paso 1' 
			--SELECT * FROM @datosflaptemp
			--end
			SELECT 
				@MaxId = MAX(rowNumber) 
			FROM @datosflaptemp
			select * 	FROM @datosflaptemp
			WHILE(@Counter IS NOT NULL AND @Counter <= @MaxId)
			BEGIN
				Set @poliza_traspaso=''
					 SELECT  
						@fechaPago=fechaPago,
						@cuentaBancaria=cuentaBancaria,
						@idempresa=idempresa,
						@importe=importe,
						@sucursal=idSucursal,
						@unidadNegocio=unidadNegocio,
						@categoriaCobranza=categoriaCobranza,
						@tipoPago=tipoPago
						
					FROM @datosflaptemp
					WHERE rowNumber = @Counter

					
						--Sacar registros de datos flap
					 PRINT 'Paso 1prima'
					 	SELECT  
						@fechaPago fechaPago,
						@cuentaBancaria cuentaBancaria,
						@idempresa idempresa,
						@importe importe,
						@sucursal,
						@unidadNegocio,
						@categoriaCobranza,
						@tipoPago
		IF EXISTS(SELECT * FROM Bancomer where noCuenta = @cuentaBancaria AND importe = @importe AND refampliada LIKE '%Multipagos%' AND fechaOperacion >= @fechaPago AND estatus != 5)
		BEGIN
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		---------------------------------------------------------------------------------------------------------------------------------------------------
		
			SELECT @idbmer=idbmer,@importeBanco=importe FROM Bancomer where noCuenta = @cuentaBancaria AND importe = @importe AND refampliada LIKE '%Multipagos%' AND fechaOperacion >= @fechaPago AND estatus != 5
				
					Delete  from @tempeval;
					insert into @tempeval
					select distinct 
					@idbmer idbmer,
					@importeBanco importeBanco,
					f.fechaPago,
					f.cuentaBancaria,
					f.idEmpresa,
					f.idSucursal,
					f.importe,
					f.unidadNegocio,
					f.categoriacobranza,
					p.idorigen,
					f.tipoPago,
					d.documento,
					d.idCliente,
					r.referencia,
					d.idTipoDocumento
					from datosFlap f
						inner join pago p  on f.referencia = p.referencia and f.numeroOrden=p.idTrans
						inner join Referencia r on f.referencia=r.referencia
						inner join detalleReferencia d on r.idReferencia=d.idReferencia
						where convert(date,f.fechapago)=@fechaPago
						and f.unidadNegocio=@unidadNegocio
						and f.categoriaCobranza=@categoriaCobranza
						and f.tipoPago=@tipoPago
						and estatusProcesado= 0

		
				PRINT 'Paso 2 Normal'
				EXECUTE [dbo].[CreaPolizaUNI_INS] 
				   @cuentaBancaria
				  ,@importe
				  ,@idempresa
				  ,@sucursal
				  ,@fechaPago
				  ,@referencia
				  ,@unidadNegocio
				  ,@categoriaCobranza
				  ,@tipopago
				  ,@Usuario

	


			
  END

		---------------------------------------------------------------------------------------------------------------------------------------------------
		---------------------------------------------------------------------------------------------------------------------------------------------------
		
		
				

   
 --   BEGIN TRY
 --     /* COLOCAR AQUI LO DE MAIL ORDER */
	--	  EXEC PROCESAMIENTO_MAILORDER @idempresa
	--END TRY
	--BEGIN CATCH
	--PRINT 'fallo sp PROCESAMIENTO_MAILORDER' + cast(@idempresa as varchar(5))
	--END CATCH
	--=============================================


   
SET @Counter  = @Counter  + 1  
END

END
go

