-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-03-20
-- Description:	Se obtienen los registros encesarios para enviarlos por email.
-- =============================================
-- [DEPOSITOSEMAIL_SP] 1, 58337

CREATE PROCEDURE [dbo].[DEPOSITOSEMAIL_SP]
	@idBanco INT = 0,
	@idDeposito INT = 0
AS
BEGIN
	SELECT 
		*
	INTO #controlDepositosView
	FROM
	(
	SELECT     idBmer, IDBanco, txtOrigen, registro, noMovimiento, referencia, concepto, refAmpliada, esCargo, importe, saldoOperativo, codigoLeyenda, oficinaOperadora, 
						  fechaOperacion, horaOperacion, fechaValor, fechaContable, estatus, noCuenta
	FROM         [referencias].[dbo].[Bancomer]
	UNION
	SELECT     idSantander AS idBmer, idbanco AS IDBanco, txtOrigen AS txtOrigen, 0 AS registro, clacon AS noMovimiento, referencia AS referencia, concepto AS concepto, 
						  descripcion AS refAmpliada, CASE signo WHEN '+' THEN 0 ELSE 1 END AS esCargo, importe AS importe, saldo AS saldoOperativo, clacon AS codigoLeyenda, 
						  sucursal AS oficinaOperadora, fechaMovimiento AS fechaOperacion, horaMovimiento AS horaOperacion, getdate() AS fechaValor, getdate() AS fechaContable, 
						  estatus AS estatus, noCuenta AS noCuenta
	FROM         [referencias].[dbo].[Santander]
	UNION
	SELECT     idBmer, BMEX.idBanco, '' AS txtOrigen, 0 AS registro, 0 AS noMovimiento, CONVERT(VARCHAR(30), ReferenciaNumerica) AS referencia, 
						  BMEX.Descripcion AS concepto, ReferenciaAlfaNumerica AS refAmpliada, CASE BMEX.Depositos WHEN 0 THEN 1 ELSE 0 END AS esCargo, 
						  CASE BMEX.Depositos WHEN 0 THEN BMEX.Retiros ELSE BMEX.Depositos END AS importe, 0 AS saldoOperativo, BMEX.Tipo_Transaccion AS codigoLeyenda, 
						  BMEX.sucursal AS oficinaOperadora, BMEX.fecha AS fechaOperacion, CONVERT(time, getdate(), 108) AS horaOperacion, getdate() AS fechaValor, getdate() 
						  AS fechaContable, 1 AS estatus, noCuenta
	FROM         [referencias].[dbo].[Banamex_Layout] BMEX
	) VISTA

	SELECT 
		'EMPRESA'	= emp_nombre,
		'idBmer'	= CD.idBmer,
		'BANCO'		= BC.cuenta,
		'LAYOUT ORIGEN' = txtOrigen,
		'REGISTRO' = registro,
		'MOVIMIENTO' = noMovimiento,
		'REFERENCIA' = referencia,
		'CONCEPTO' = concepto,
		'REFERENCIA AMPLIADA' = refAmpliada,
		'CARGO/ABONO' = CASE esCargo WHEN 1 THEN 'CARGO' WHEN 0 THEN 'ABONO' END,
		'IMPORTE' = importe,
		'SALDO OPERATIVO' = saldoOperativo,
		'CODIGO LEYENDA' = codigoLeyenda,
		'OFICINA OPERADORA' = oficinaOperadora,
		'FECHA OPERACION' = CONVERT(VARCHAR(10),CONVERT(DATE,fechaOperacion,111)),
		'HORA OPERACION' = CONVERT(VARCHAR(8),horaOperacion),
		'FECHA VALOR' = CONVERT(VARCHAR(10),CONVERT(DATE,fechaValor,111)),
		'FECHA CONTABLE' = CONVERT(VARCHAR(10),CONVERT(DATE,fechaContable,111)),
		'ESTATUS' = estatus,
		'NUMERO DE CUENTA' = noCuenta
	FROM #controlDepositosView CD
	INNER JOIN [referencias].[dbo].[CodigoIdentificacion] CI ON CD.codigoLeyenda = CI.CodigoBanco
	INNER JOIN [referencias].[dbo].[BancoCuenta] BC ON CD.noCuenta = BC.numeroCuenta
	INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BC.idEmpresa = EMP.emp_idempresa
	LEFT JOIN (
		SELECT idBmer FROM [Tesoreria].[dbo].[controlDepositosView] 
		WHERE ((concepto LIKE 'SPEI%' AND refAmpliada LIKE '1234567%-%-%') OR(concepto LIKE 'TRASPASO%' AND refAmpliada LIKE '%-%-%')) 
			  AND idBanco = @idBanco
			  AND esCargo = 1 
	) Excluye ON Excluye.idBmer = CD.idBmer
	WHERE CD.idBanco = @idBanco
		  AND CD.esCargo = 1 
		  AND Excluye.idBmer IS NULL
		  AND CD.idBmer > @idDeposito
		  AND CI.Tipo = 0
	ORDER BY CD.idBmer ASC;

	DROP TABLE #controlDepositosView;
	--SELECT 
	--	CD.idBmer,
	--	CD.IDBanco,
	--	txtOrigen,
	--	registro,
	--	noMovimiento,
	--	referencia,
	--	concepto,
	--	refAmpliada,
	--	esCargo,
	--	importe,
	--	saldoOperativo,
	--	codigoLeyenda,
	--	oficinaOperadora,
	--	CONVERT(VARCHAR(10),CONVERT(DATE,fechaOperacion,111)) fechaOperacion,
	--	CONVERT(VARCHAR(8),horaOperacion) horaOperacion,
	--	CONVERT(VARCHAR(10),CONVERT(DATE,fechaValor,111)) fechaValor,
	--	CONVERT(VARCHAR(10),CONVERT(DATE,fechaContable,111)) fechaContable,
	--	estatus,
	--	noCuenta
	--FROM [Tesoreria].[dbo].[controlDepositosView] CD
	--INNER JOIN [referencias].[dbo].[CodigoIdentificacion] CI ON CD.codigoLeyenda = CI.CodigoBanco
	--LEFT JOIN (
	--	SELECT idBmer FROM [Tesoreria].[dbo].[controlDepositosView] 
	--	WHERE ((concepto LIKE 'SPEI%' AND refAmpliada LIKE '1234567%-%-%') OR(concepto LIKE 'TRASPASO%' AND refAmpliada LIKE '%-%-%')) 
	--		  AND idBanco = @idBanco
	--		  AND esCargo = 1 
	--) Excluye ON Excluye.idBmer = CD.idBmer
	--WHERE CD.idBanco = @idBanco
	--	  AND CD.esCargo = 1 
	--	  AND Excluye.idBmer IS NULL
	--	  AND CD.idBmer > @idDeposito
	--ORDER BY CD.idBmer ASC;
END
go

