--SEL_UNIDADES_COTIZACION_SP  'AU-AU-UNI-UN-2038'
CREATE PROCEDURE [dbo].[SEL_UNIDADES_COTIZACION_SP]
	@folio VARCHAR(50)
AS 
BEGIN
	SELECT	ucn_idcotizadetalle AS idCotizacionDetalle
			,ucn_noserie AS numSerie
			,ISNULL(ucn_idFactura,'') AS idFactura
			,CD.ucu_idcotizacion AS idCotizacion
			,0  Seleccionado
			,CD.ucn_idcatalogo AS clave
			,CD.ucn_modelo AS modelo
			,ucn_colorint AS colorInt
			,ucn_colorext AS colorExt
			
	FROM	[cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS C
			INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON C.ucu_idcotizacion = CD.ucu_idcotizacion
	WHERE	ucu_foliocotizacion = @folio
END;

go

