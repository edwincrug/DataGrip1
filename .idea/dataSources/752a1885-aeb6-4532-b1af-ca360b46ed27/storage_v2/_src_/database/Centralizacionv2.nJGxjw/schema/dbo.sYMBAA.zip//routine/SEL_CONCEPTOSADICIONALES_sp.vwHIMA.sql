--EXEC	 [dbo].[SEL_CONCEPTOSADICIONALES_sp]		@IdCotizacion = '10968' 		,@idCotizacionDetalle = '12808' 
--select * from cuentasporcobrar..uni_cotizacionuniversal where ucu_foliocotizacion = 'AU-AU-UNI-UN-2417'
--dbo.SEL_CONCEPTOSADICIONALES_sp 10968, 12808
CREATE PROCEDURE [dbo].[SEL_CONCEPTOSADICIONALES_sp]  

@IdCotizacion VARCHAR(100) 
,@idCotizacionDetalle VARCHAR(100)
AS
BEGIN


 DECLARE @Base                 VARCHAR(100)
 DECLARE @BaseConcentra        VARCHAR(100)
 DECLARE @BaseLocal            VARCHAR(100)
 DECLARE @TipoCotizacion       VARCHAR(3)
 DECLARE @ConsultaUnidad       VARCHAR(max)
 DECLARE @ConsultaRefacciones  VARCHAR(max)
 DECLARE @ConsultaTramites     VARCHAR(max)
 DECLARE @ConsultaOtros        VARCHAR(max)
 DECLARE @ConsultaServicio     VARCHAR(max)  
 DECLARE @ConsultaUnidadTotal       VARCHAR(max)
 DECLARE @ConsultaRefaccionesTotal  VARCHAR(max)
 DECLARE @ConsultaTramitesTotal     VARCHAR(max)
 DECLARE @ConsultaOtrosTotal        VARCHAR(max)
 DECLARE @ConsultaServicioTotal     VARCHAR(max) 
 DECLARE @idBpro	VARCHAR(50)
 DECLARE @ConsultaRefaccionesPosteriorTotalA  VARCHAR(max)
 DECLARE @ConsultaTramitesPosteriorTotal     VARCHAR(max)
 DECLARE @ConsultaOtrosPosteriorTotal        VARCHAR(max)
 DECLARE @ConsultaServicioPosteriorTotal     VARCHAR(max) 

 DECLARE @ConsultaRefaccionesPosterior  VARCHAR(max)
 DECLARE @ConsultaTramitesPosterior     VARCHAR(max)
 DECLARE @ConsultaOtrosPosterior        VARCHAR(max)
 DECLARE @ConsultaServicioPosterior     VARCHAR(max)  
 DECLARE @ConsultaUnidadTotalPosterior       VARCHAR(max)

 DECLARE @facturaUnidad VARCHAR(MAX)
		,@idCliente NUMERIC(18,0)
		,@facturaTramites VARCHAR(MAX)
		,@facturaServicios VARCHAR(MAX)
		,@facturaOtrosConceptos VARCHAR(MAX)
		,@facturaAccesorios VARCHAR(MAX)
		,@idPedido NUMERIC(18,0)
		,@idAlmacen VARCHAR(20)
		,@idPedidoTramite VARCHAR(20)
		,@FolioCotizacion VARCHAR(100)



	SELECT @FolioCotizacion= ucu_foliocotizacion  
	FROM cuentasporcobrar.DBO.uni_cotizacionuniversal 
	WHERE ucu_idcotizacion = @IdCotizacion
 
 --INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE DONDE SE BUSCARA LA POLIZA 
	SET @Base = [dbo].[base_Cotizacion](@FolioCotizacion)
	PRINT @Base
	--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE CONCENTRADORA
	SET @BaseConcentra = [dbo].[base_concentradora_cotizacion](@FolioCotizacion)
	PRINT @BaseConcentra
	--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE LOCAL
	SET @BaseLocal = [dbo].[base_Cotizacion](@FolioCotizacion)
	PRINT @BaseLocal
 
  
--SET @Base = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
--(SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa = 
--(SELECT ucu_idempresa FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_idcotizacion = @IdCotizacion)) 
--AND suc_idsucursal = (SELECT ucu_idsucursal FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_idcotizacion = @IdCotizacion))

----INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE CONCENTRADORA
--SET @BaseConcentra = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE tipo = 2 and catemp_nombrecto = 
--(SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa = 
--(SELECT ucu_idempresa FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_idcotizacion = @IdCotizacion)))

----INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE LOCAL
--SET @BaseLocal = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE tipo = 1 and suc_idsucursal = 
--(SELECT ucu_idsucursal FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_idcotizacion = @IdCotizacion))

SELECT @idCliente = CU.ucu_idcliente FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL CU WHERE  CU.ucu_idcotizacion = @IdCotizacion
--Incicio Variable consecutivo de cotizacion
--SET @IdCotizacion = (SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)
--SET @TipoCotizacion = (SELECT ucu_tipocotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_idcotizacion = @IdCotizacion) 

SELECT @TipoCotizacion = ucu_tipocotizacion, @idBpro = ISNULL(ucu_idpedidobpro,0)  FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_idcotizacion = @IdCotizacion 

----------------------------------------------QUERY CONSULTA REFACCIONES-------------------------------------------------------------  
SET @ConsultaRefacciones = 'SELECT  '+char(39)+'ACCESORIOS'+char(39)+'' + char(13) + 
							'		,C.ucn_idcotizadetalle' + char(13) + 
							'		,CONVERT(INT' + char(13) + 
							'		,P.pmd_cantidad) AS pmd_cantidad' + char(13) + 
							'		,P.pmd_idparte' + char(13) + 
							'		,PP.PTS_DESPARTE' + char(13) + 
							'		,P.pmd_preciounitario / 1.16' + char(13) + 
							'		,P.pmd_preciounitario - (P.pmd_preciounitario / 1.16)' + char(13) + 
							'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN V.VTE_IMPORTEMON ELSE P.pmd_total END AS pmd_total' + char(13) + 
							'		,PE.pmm_nopedmost AS idBpro' + char(13) + 
							'		,VTE_DOCTO AS factura   ' + char(13) + 
							'		,ISNULL(SUM(CCP_ABONO),0) AS importe   ' + char(13) + 
							'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN ISNULL(SUM(CCP_CARGO),0) - ISNULL(SUM(CCP_ABONO),0) ELSE P.pmd_total END  As saldo   ' + char(13) + 
							'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
							'		INNER JOIN cuentasporcobrar.dbo.par_pedmostdet P ON C.ucn_idcotizadetalle = P.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = P.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
							'		INNER JOIN ' + @BaseConcentra + 'PAR_PARTES PP ON P.pmd_idparte = PP.PTS_IDPARTE ' + char(13) + 
							'		INNER JOIN cuentasporcobrar.dbo.par_pedmostenc PE ON PE.pmm_idpedmostenc = P.pmm_idpedmostenc' + char(13) + 
							'		LEFT JOIN ' + @Base + '[PAR_PEDMOST] AS PEM ON PE.pmm_nopedmost = PEM.PMM_NUMERO AND PMM_IDALMA = '+char(39)+'NEG'+char(39)+'' + char(13) + 
							'		LEFT JOIN ' + @Base + '[ADE_VTAFI] AS V ON V.VTE_DOCTO = PMM_REF2' + char(13) + 
							'		LEFT JOIN ' + @Base + '[VIS_CONCAR01] AS VIS ON V.VTE_DOCTO = VIS.CCP_IDDOCTO AND CCP_TIPODOCTO IN(''FAC'',''NCR'',''ANT'',''PCA'')' + char(13) + 
							'WHERE 	P.pmd_estatus = 1 AND C.ucu_idcotizacion = ' + @IdCotizacion + ' AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + ' AND P.[CEA_IdEstatusAdicionales] <> 4 ' + char(13) + 
							'GROUP BY C.ucn_idcotizadetalle, P.pmd_cantidad, P.pmd_idparte,PP.PTS_DESPARTE, P.pmd_preciounitario, P.pmd_total, PE.pmm_nopedmost, VTE_DOCTO, V.VTE_IMPORTEMON' + char(13) +
							'' 
--V.VTE_IMPORTEMON
PRINT @ConsultaRefacciones
EXECUTE (@ConsultaRefacciones)
-------------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------QUERY CONSULTA TRAMITES ---------------------------------------------     



set @ConsultaTramites =	'SELECT '+char(39)+'TRAMITES'+char(39)+'' + char(13) + 
						'		, C.ucn_idcotizadetalle' + char(13) + 
						'		,1 cantidad' + char(13) + 
						'		,P.PAR_DESCRIP1' + char(13) + 
						'		,a.uaw_descripcion' + char(13) + 
						'		,a.UAW_PRECIO as precioUni' + char(13) + 
						'		,a.UAW_PRECIO - (a.UAW_PRECIO /1.16) as iva' + char(13) + 
						'		,CASE WHEN uaw_IDDOCTO IS NOT NULL THEN SUM(CCP_CARGO) ELSE a.UAW_PRECIO END AS uaw_importe' + char(13) + 
						'		,ISNULL(A.UAW_IDPEDIDOVAR,'+char(39)+''+char(39)+') AS idBpro' + char(13) + 
						'		,ISNULL(uaw_IDDOCTO,'+char(39)+''+char(39)+') AS factura    ' + char(13) +
						'		,ISNULL(SUM(CCP_ABONO),0) AS importe   ' + char(13) + 
						'		,CASE WHEN uaw_IDDOCTO IS NOT NULL THEN ISNULL(SUM(CCP_CARGO),0) - ISNULL(SUM(CCP_ABONO),0) ELSE a.UAW_PRECIO END  As saldo   ' + char(13) + 
						'FROM	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
						'		INNER JOIN cuentasporcobrar.dbo.uni_anticiposweb A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
						'		INNER JOIN ' + @Base + 'PNC_PARAMETR P ON A.uaw_idconceptopago = P.PAR_IDENPARA ' + char(13) + 
						'		LEFT JOIN ' + @Base + '[VIS_CONCAR01] AS VIS ON uaw_IDDOCTO = VIS.CCP_IDDOCTO  AND CCP_TIPODOCTO IN(''FAC'',''NCR'',''ANT'',''PCA'', ''NCA'',''APAN'')' + char(13) + 
						'WHERE	C.ucu_idcotizacion = ' + @IdCotizacion + ' AND A.uaw_estatus = 1 ' + char(13) + 
						'		AND P.PAR_TIPOPARA = '+char(39)+'COCOCXC'+char(39)+' ' + char(13) + 
						'		AND C.ucn_idcotizadetalle = '+@idCotizacionDetalle+' ' + char(13) + 
						'		AND A.[CEA_IdEstatusAdicionales] <> 4' + char(13) + 
						'GROUP BY C.ucn_idcotizadetalle, P.PAR_DESCRIP1, a.uaw_descripcion,a.UAW_PRECIO, A.UAW_IDPEDIDOVAR, uaw_IDDOCTO ' + char(13) +
						'' 
print (@ConsultaTramites)
EXECUTE (@ConsultaTramites) 


-------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------QUERY CONSULTA OTROS---------------------------------------------------------         


set @ConsultaOtros =	'SELECT '+char(39)+'OTROS'+char(39)+'' + char(13) + 
						'		,C.ucn_idcotizadetalle' + char(13) + 
						'		,A.ucd_cantidad' + char(13) + 
						'		,'+char(39)+''+char(39)+' catalogo' + char(13) + 
						'		,A.ucd_descripcion' + char(13) + 
						'		,A.ucd_preciounitario / 1.16' + char(13) + 
						'		,A.ucd_preciounitario - (A.ucd_preciounitario / 1.16)' + char(13) + 
						'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN V.VTE_IMPORTEMON ELSE A.ucd_preciounitario END AS ucd_preciounitario' + char(13) + 
						'		,AD.uoc_idpedidobpro AS idBpro' + char(13) + 
						'		,VTE_DOCTO AS factura    ' + char(13) + 
						'		,ISNULL(SUM(CCP_ABONO),0) AS importe   ' + char(13) + 
						'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN ISNULL(SUM(CCP_CARGO),0) - ISNULL(SUM(CCP_ABONO),0) ELSE A.ucd_preciounitario END  As saldo   ' + char(13) +
						'FROM	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
						'		INNER JOIN cuentasporcobrar.dbo.uni_otroconceptosdet A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
						'		INNER JOIN cuentasporcobrar.dbo.uni_otrosconceptosenc AS AD ON AD.uoc_idotrosconceptosenc = A.uoc_idotrosconceptosenc ' + char(13) + 
						'		LEFT JOIN ' + @Base + 'ADE_VTAFI AS V ON AD.uoc_idpedidobpro = V.VTE_REFERENCIA1' + char(13) + 
						'		LEFT JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS D ON D.ucu_idcliente = V.VTE_IDCLIENTE AND D.ucu_idcotizacion = C.ucu_idcotizacion ' + char(13) + 
						'		LEFT JOIN ' + @Base + '[VIS_CONCAR01] AS VIS ON V.VTE_DOCTO = VIS.CCP_IDDOCTO AND CCP_TIPODOCTO IN(''FAC'',''NCR'',''ANT'',''PCA'',  ''NCA'')' + char(13) + 
						'WHERE	A.ucd_estatus = 1 AND C.ucu_idcotizacion = ' + @IdCotizacion + ' AND C.ucn_idcotizadetalle = '+@idCotizacionDetalle+' AND A.[CEA_IdEstatusAdicionales] <> 4 ' + char(13) + 
						'GROUP BY C.ucn_idcotizadetalle, A.ucd_cantidad, A.ucd_descripcion, A.ucd_preciounitario, AD.uoc_idpedidobpro, VTE_DOCTO, V.VTE_IMPORTEMON ' + char(13) + 
						'' 

print  (@ConsultaOtros) 
EXECUTE (@ConsultaOtros) 


----------------------------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------QUERY CONSULTA SERVICIO----------------------------------------------------------        
SET @ConsultaServicio = 'SELECT	'+char(39)+'SERVICIO'+char(39)+'' + char(13) + 
						'		,C.ucn_idcotizadetalle' + char(13) + 
						'		,1 cantidad' + char(13) + 
						'		,PS.PQE_IDPAQUETE' + char(13) + 
						'		,PS.PQE_NOMPAQUETE' + char(13) + 
						'		,PS.PQE_DESCRIPCION' + char(13) + 
						'		,A.upo_precio / 1.16 ' + char(13) + 
						'		,A.upo_precio - (A.upo_precio / 1.16)' + char(13) + 
						'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN SUM(CCP_CARGO) ELSE A.upo_precio END AS upo_precio' + char(13) + 
						'		,OS.ORE_IDORDEN AS idBpro' + char(13) + 
						'		,VTE_DOCTO AS factura     ' + char(13) +
						'		,ISNULL(SUM(CCP_ABONO),0) AS importe   ' + char(13) + 
						'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN ISNULL(SUM(CCP_CARGO),0) - ISNULL(SUM(CCP_ABONO),0) ELSE A.upo_precio END As saldo   ' + char(13) + 
						'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
						'		INNER JOIN cuentasporcobrar.dbo.uni_preordenser A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
						'		INNER JOIN ' + @Base + 'SER_PAQUESER PS ON A.upo_idpaquete = PS.PQE_IDPAQUETE ' + char(13) + 
						'		LEFT JOIN ' + @Base + 'SER_ORDEN AS OS ON OS.ORE_PRESUPUESTO=Substring(A.UPO_IDORDEN,2,len(A.UPO_IDORDEN)) ' + char(13) +
						'		--LEFT JOIN ' + @Base + 'SER_PRESUP AS PRE ON PRE.ORE_IDCOTIZACIONUNIVERSAL = C.ucu_idcotizacion ' + char(13) +
						'		--LEFT JOIN ' + @Base + 'SER_ORDENDET AS ODET ON (OS.ORE_IDORDEN = ODET.ORD_IDORDEN /*OR PRE.PRE_IDORDEN = ODET.ORD_IDORDEN*/) AND ORD_FACSER IS NOT NULL ' + char(13) +
						'		LEFT JOIN ' + @Base + 'ADE_VTAFI AS V ON V.VTE_REFERENCIA1 = OS.ORE_IDORDEN ' + char(13) + 
						'		LEFT JOIN ' + @Base + '[VIS_CONCAR01] AS VIS ON V.VTE_DOCTO = VIS.CCP_IDDOCTO  AND CCP_TIPODOCTO IN(''FAC'',''NCR'',''ANT'',''PCA'')' + char(13) + 
						'WHERE 	A.upo_estatus = 1 ' + char(13) + 
						'		AND C.ucu_idcotizacion = ' + @IdCotizacion + ' ' + char(13) + 
						'		AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + ' ' + char(13) + 
						'		AND A.[CEA_IdEstatusAdicionales] <> 4 ' + char(13) + 
						'GROUP BY C.ucn_idcotizadetalle, PS.PQE_IDPAQUETE, PS.PQE_NOMPAQUETE, PS.PQE_DESCRIPCION, A.upo_precio, A.upo_idorden, VTE_DOCTO, V.VTE_IMPORTEMON, OS.ORE_IDORDEN ' + char(13) + 
						'' 
PRINT @ConsultaServicio 
EXECUTE  (@ConsultaServicio) 
----------------------------------------------------------------------------------------------------------------------------------------------------------------



END;


go

