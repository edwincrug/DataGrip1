
CREATE PROCEDURE [dbo].[PROV_SEL_PROSPECTO_BANCO_TIPOCUENTA_SP] --143,1,''
@idProspecto INT
,@opcion INT
,@rfc  VARCHAR(50)
AS
BEGIN

IF(@opcion=1)
BEGIN
	if(@rfc = '')
	BEGIN
		SELECT   idCuentaBancaria
			,idProspecto
			,titular
			,'Banco: '+ banco +' No. Cuenta: '+ noCuenta  as banco
			,sucursal
			,noCuenta
			,clabe
			,cie
			,referencia
			,cveBanxico
			,cveBanco
			,tipoCtaBancaria
			,nombreTipoCtaBancaria
			
		FROM PROV_CUENTA_BANCARIA 
		WHERE (idProspecto = @idProspecto OR rfcProspecto in (SELECT PER_RFC FROM PROV_PROSPECTO WHERE PER_IDPERSONA = @idProspecto))
		AND  tipoCtaBancaria IS NULL OR tipoCtaBancaria = ''
	END
	ELSE
	BEGIN
		SELECT   idCuentaBancaria
			,idProspecto
			,titular
			,'Banco: '+ banco +' No. Cuenta: '+ noCuenta  as banco
			,sucursal
			,noCuenta
			,clabe
			,cie
			,referencia
			,cveBanxico
			,cveBanco
			,tipoCtaBancaria
			,nombreTipoCtaBancaria
		FROM PROV_CUENTA_BANCARIA 
		WHERE rfcProspecto = @rfc
		AND  tipoCtaBancaria IS NULL OR tipoCtaBancaria = ''
	END
	

END
ELSE
BEGIN
	IF(@rfc = '')
	BEGIN
		SELECT   idCuentaBancaria
			,idProspecto
			,titular
			,'Banco: '+ banco +' No. Cuenta: '+ noCuenta  as banco
			,sucursal
			,noCuenta
			,clabe
			,cie
			,referencia
			,cveBanxico
			,cveBanco
			,tipoCtaBancaria
			,nombreTipoCtaBancaria
		FROM PROV_CUENTA_BANCARIA 
		WHERE (idProspecto = @idProspecto OR rfcProspecto in (SELECT PER_RFC FROM PROV_PROSPECTO WHERE PER_IDPERSONA = @idProspecto))
		
		AND  (tipoCtaBancaria IS NOT NULL AND tipoCtaBancaria <> '')  
		and Aprobada is null
		
	END
	ELSE
	BEGIN 
		SELECT   idCuentaBancaria
			,idProspecto
			,titular
			,'Banco: '+ banco +' No. Cuenta: '+ noCuenta  as banco
			,sucursal
			,noCuenta
			,clabe
			,cie
			,referencia
			,cveBanxico
			,cveBanco
			,tipoCtaBancaria
			,nombreTipoCtaBancaria
			
		FROM PROV_CUENTA_BANCARIA 
		WHERE rfcProspecto =  @rfc
		and Aprobada is null
		AND  (tipoCtaBancaria IS NOT NULL AND tipoCtaBancaria <> '')  

	END
	

END


END
go

