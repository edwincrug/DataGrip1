-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[INS_BITACORA_DOCUMENTOS]
	@tipoAccion VARCHAR(500),
	@idDocumento INT,
	@idUsuario INT,
	@idExpediente INT
AS
BEGIN

	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE @nombreCompleto VARCHAR(100)
		SELECT 
			@nombreCompleto = (usu_nombre + ' ' + usu_paterno + ' ' + usu_materno)
		FROM [ControlAplicaciones].[DBO].[cat_usuarios] WHERE usu_idUsuario = @idUsuario;

		INSERT INTO [expedienteSeminuevo].[bitacoraAccionesDocumentos]
			   ([bit_tipoAccion]
			   ,[bit_idDocumento]
			   ,[bit_nombreUsuario]
			   ,[bit_idUsuario]
			   ,[bit_fechaAccion]
			   ,[bit_idExpediente])
		 VALUES
			   (@tipoAccion
			   ,@idDocumento
			   ,@nombreCompleto
			   ,@idUsuario
			   ,GETDATE()
			   ,@idExpediente)
		SELECT succcess = 1;
	END TRY

	BEGIN CATCH
		SELECT succcess = 0;
	END CATCH
END

go

