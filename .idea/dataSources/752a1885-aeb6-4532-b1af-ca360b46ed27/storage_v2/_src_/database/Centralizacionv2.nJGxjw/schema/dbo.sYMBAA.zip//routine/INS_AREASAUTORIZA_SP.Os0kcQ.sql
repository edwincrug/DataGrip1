
CREATE PROCEDURE [dbo].[INS_AREASAUTORIZA_SP] (@sIdUSR VARCHAR(5),@sIdUSR2 VARCHAR(5) , @sIdUSR3 VARCHAR(5), @sNombre_base varchar(100)) --with recompile
 As

BEGIN

SET NOCOUNT ON;

DECLARE @sQ nvarchar(1500); 
--DECLARE @sIdUSR VARCHAR(5);
DECLARE @ipServidor    VARCHAR(100);
DECLARE @ipLocal VARCHAR(50);
DECLARE  @emp_idempresa int;
DECLARE  @suc_idsucursal int;
--DECLARE  @sNombre_base varchar(100);


--select @sNombre_base = 'GAAU_Pedregal'
--select @sIdUSR = '15'

select @ipServidor=ip_servidor, @emp_idempresa =  emp_idempresa  from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] where nombre_base = @sNombre_base and tipo=1
select @suc_idsucursal = suc_idsucursal from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] where nombre_base = @sNombre_base and tipo=1

SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC

if (@ipLocal = @ipServidor)
begin
   select @ipServidor = ''
end
else
	begin
	   select @ipServidor = '[' + @ipServidor + '].'
	end

--select @sNombre_base = 'GAUU_Pedregal'
select @sNombre_base = '[' + @sNombre_base + ']'

if EXISTS (Select 1  from [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] where emp_idempresa=@emp_idempresa and suc_idsucursal = @suc_idsucursal)
begin	
	Delete [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT]
	where emp_idempresa=@emp_idempresa and suc_idsucursal = @suc_idsucursal
end

-- Poblando la tabla
select @sQ = ''

set @sQ = N'Insert into [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] (emp_idempresa,suc_idsucursal,par_idenpara,otc_area,usuario_autoriza1,usuario_autoriza2,usuario_autoriza3,Minutos_Escalar) '
set @sQ = @sQ + N' Select ' + rtrim(ltrim(Convert(char(2),@emp_idempresa))) + ',' + rtrim(ltrim(Convert(char(2),@suc_idsucursal))) + ','
set @sQ = @sQ + N' PAR_IDENPARA,PAR_DESCRIP1,' + @sIdUSR + ',' + @sIdUSR2 + ',' + @sIdUSR3 + ',200'
set @sQ = @sQ + N' from ' + @ipServidor + @sNombre_base + '.[dbo].[PNC_PARAMETR] '
set @sQ = @sQ + N' where PAR_TIPOPARA = ''AREPED '''
set @sQ = @sQ + N' and PAR_IDMODULO=''CON'' order by PAR_DESCRIP1 '

print '@sQ: '  + @sQ
execute sp_executesql @sQ


	set nocount off
END
/*
Declare @sNombre_base Varchar(100);
Declare @sIdUSR varchar(5);
Declare @sIdUSR2 varchar(5);
Declare @sIdUSR3 varchar(5);

select @sNombre_base = 'GATPartsDHLGdl'
select @sIdUSR = '1909'
select @sIdUSR2 = '3177'
select @sIdUSR3 = '1929'

Execute [dbo].[INS_AREASAUTORIZA_SP] @sIdUSR,@sIdUSR2,@sIdUSR3,@sNombre_base

select * from Centralizacionv2..DIG_ESCALAMIENTO_AREA_AFECT where emp_idempresa=13

select * from Centralizacionv2..DIG_CAT_BASES_BPRO where emp_idempresa=12

------------------------------------------------------------
--Select 5,19, PAR_IDENPARA,PAR_DESCRIP1,15 from [GAUU_Pedregal].[dbo].[PNC_PARAMETR]  where PAR_TIPOPARA = 'AREPED ' and PAR_IDMODULO='CON' order by PAR_DESCRIP1
Select * from [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] 
where emp_idempresa=12 and suc_idsucursal = 19

select * from [Centralizacionv2].[dbo].DIG_CAT_BASES_BPRO

---------------------------------------------------------------------------------------
----------------------CONSULTA DE LOS USUARIOS EN BPRO X SU  ACRONIMO DE 3 CARACTERES

Select * from [ControlAplicaciones].[dbo].[cat_usuarios]
where usu_nombreusu = 'MPI'

--------------------- ACTUALIZACION DEL USUARIO POR AREA ------------------------------
Declare @iusu_idusuario int;
select @iusu_idusuario = 3223;

update [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] 
set usuario_autoriza1 = 2239,usuario_autoriza3 = 1909  
where emp_idempresa=13
and suc_idsucursal=32
and id in (502,503,504)

SELECT * FROM [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT]
where emp_idempresa=13
and suc_idsucursal=32
order by id


*/
go

