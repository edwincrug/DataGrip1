
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--[dbo].[SEL_USUARIO_CXP_SP] 'AU-AU-CUA-OT-PE-18'
CREATE PROCEDURE [dbo].[SEL_USUARIO_CXP_SP] 
	@folio  VARCHAR(50) = ''
AS
BEGIN
	IF(EXISTs(SELECT	[oce_idusuario] AS idUsuarioCXP
				FROM	[cuentasxpagar].[dbo].[cxp_ordencompra]
			   WHERE	[oce_folioorden]	=	@folio
						AND [sod_idsituacionorden] IN (2,5)
			 )
	   )
		BEGIN 
			SELECT	[oce_idusuario] AS idUsuarioCXP
			FROM	[cuentasxpagar].[dbo].[cxp_ordencompra]
			WHERE	[oce_folioorden]	=	@folio
					AND [sod_idsituacionorden] IN (2,5)
		END
	ELSE
		BEGIN
		SELECT -1 AS idUsuarioCXP 
		END
END

go

