CREATE PROCEDURE [dbo].[PPROV_ORDCOMPRA_PROV_FITRO_VAL]   -- [dbo].[PPROV_ordcompra_prov]  4,null,null,1
@idProveedor INT = 0,
@monto DECIMAL = NULL,
@orden VARCHAR(50) = NULL,
@Empresa VARCHAR(5)=NULL,
@Sucursal VARCHAR(5) = NULL

AS  
  SET NOCOUNT ON    
        IF(@orden IS NOT NULL AND @Empresa IS NOT NULL AND @Sucursal IS NOT NULL )
			BEGIN
					SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,
						depto.dep_nombre,
						suc.suc_nombre,  
						emp.emp_nombre,
						ordComp.oce_importetotal,
						emp.emp_nombrecto,  
						CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
						sit.sod_nombresituacion estatus,
						per.per_rfc,
						df.folioorden as ppro_nombrearchivo,
						df.serie + ISNULL(df.folio,'') factura,
						df.uuid,
						df.fecha_carga as fechaValidacion,
						CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
						df.serie,
						df.fecha_factura fecha_pago,
						df.rfc_emisor,
						df.rfc_receptor,
						df.importe as importe_total,
						ordComp.oce_uuid,
						Recepcion =
						CASE ordComp.sod_idsituacionorden
						WHEN 1 THEN 'Pendiente'
						WHEN 2 THEN 'Pendiente'
						WHEN 3 THEN 'Pendiente'
						WHEN 4 THEN 'Pendiente'
						WHEN 5 THEN 'Pendiente'
						WHEN 6 THEN 'Recepción Completa'
						WHEN 7 THEN 'Recepción Incompleta'
						ELSE  'Recepción Incompleta'	 
						END,
						Estado =
						CASE ordComp.sod_idsituacionorden
						WHEN 12 THEN 'Pagada'
						WHEN 13 THEN 'Pagada'
						WHEN 16 THEN 'Pagada'
						WHEN 18 THEN 'Pagada'
						ELSE  'Por Pagar'
						END 
					FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] DF
						JOIN cuentasxpagar.dbo.cxp_ordencompra ordComp on DF.folioorden = ordComp.oce_folioorden
						LEFT JOIN BDPersonas.dbo.cat_personas per ON ordComp.oce_idproveedor = per.per_idpersona
						LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
						LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
						LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
					WHERE ordComp.oce_idproveedor = @idProveedor  
						AND (@monto IS NULL OR ordComp.oce_importetotal = @monto)
						AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))	
						AND ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18)						
						AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
						AND ordComp.oce_idempresa = @Empresa
						AND ordComp.oce_idsucursal = @Sucursal
						order by ordComp.oce_fechaorden ASC
		END
		ELSE IF (@Empresa IS NULL AND @Sucursal IS NULL )
			BEGIN

					SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,
						depto.dep_nombre,
						suc.suc_nombre,  
						emp.emp_nombre,
						ordComp.oce_importetotal,
						emp.emp_nombrecto,  
						CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
						sit.sod_nombresituacion estatus,
						per.per_rfc,
						df.folioorden as ppro_nombrearchivo,
						df.serie + ISNULL(df.folio,'') factura,
						df.uuid,
						df.fecha_carga as fechaValidacion,
						CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
						df.serie,
						df.fecha_factura fecha_pago,
						df.rfc_emisor,
						df.rfc_receptor,
						df.importe as importe_total,
						ordComp.oce_uuid,
						Recepcion =
						CASE ordComp.sod_idsituacionorden
						WHEN 1 THEN 'Pendiente'
						WHEN 2 THEN 'Pendiente'
						WHEN 3 THEN 'Pendiente'
						WHEN 4 THEN 'Pendiente'
						WHEN 5 THEN 'Pendiente'
						WHEN 6 THEN 'Recepción Completa'
						WHEN 7 THEN 'Recepción Incompleta'
						ELSE  'Recepción Incompleta'	 
						END,
						Estado =
						CASE ordComp.sod_idsituacionorden
						WHEN 12 THEN 'Pagada'
						WHEN 13 THEN 'Pagada'
						WHEN 16 THEN 'Pagada'
						WHEN 18 THEN 'Pagada'
						ELSE  'Por Pagar'
						END 
					FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] DF
						JOIN cuentasxpagar.dbo.cxp_ordencompra ordComp on DF.folioorden = ordComp.oce_folioorden
						LEFT JOIN BDPersonas.dbo.cat_personas per ON ordComp.oce_idproveedor = per.per_idpersona
						LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
						LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
						LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
					WHERE ordComp.oce_idproveedor = @idProveedor   AND
						-- (@monto IS NULL OR ordComp.oce_importetotal = @monto)AND
						 (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))	
							AND ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18)
						  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					order by ordComp.oce_fechaorden ASC
			END
		ELSE IF (@Empresa IS NOT NULL AND @Sucursal IS NULL)
			BEGIN 
			  -- SET @Empresa=(select CAST(@Empresa AS int))

					SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,
						depto.dep_nombre,
						suc.suc_nombre,  
						emp.emp_nombre,
						ordComp.oce_importetotal,
						emp.emp_nombrecto,  
						CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
						sit.sod_nombresituacion estatus,
						per.per_rfc,
						df.folioorden as ppro_nombrearchivo,
						df.serie + ISNULL(df.folio,'') factura,
						df.uuid,
						df.fecha_carga as fechaValidacion,
						CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
						df.serie,
						df.fecha_factura fecha_pago,
						df.rfc_emisor,
						df.rfc_receptor,
						df.importe as importe_total,
						ordComp.oce_uuid,
						Recepcion =
						CASE ordComp.sod_idsituacionorden
						WHEN 1 THEN 'Pendiente'
						WHEN 2 THEN 'Pendiente'
						WHEN 3 THEN 'Pendiente'
						WHEN 4 THEN 'Pendiente'
						WHEN 5 THEN 'Pendiente'
						WHEN 6 THEN 'Recepción Completa'
						WHEN 7 THEN 'Recepción Incompleta'
						ELSE  'Recepción Incompleta'	 
						END,
						Estado =
						CASE ordComp.sod_idsituacionorden
						WHEN 12 THEN 'Pagada'
						WHEN 13 THEN 'Pagada'
						WHEN 16 THEN 'Pagada'
						WHEN 18 THEN 'Pagada'
						ELSE  'Por Pagar'
						END 
					FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] DF
						JOIN cuentasxpagar.dbo.cxp_ordencompra ordComp on DF.folioorden = ordComp.oce_folioorden
						LEFT JOIN BDPersonas.dbo.cat_personas per ON ordComp.oce_idproveedor = per.per_idpersona
						LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
						LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
						LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
					WHERE ordComp.oce_idproveedor = @idProveedor  
						AND (@monto IS NULL OR ordComp.oce_importetotal = @monto)
						AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))	
						AND ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18)
						  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					AND ordComp.oce_idempresa = @Empresa
					order by ordComp.oce_fechaorden ASC
			END
		ELSE IF (@Sucursal IS NOT NULL )
			BEGIN
			  --  SET @Sucursal=(select CAST(@Empresa AS int))
					SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,
						depto.dep_nombre,
						suc.suc_nombre,  
						emp.emp_nombre,
						ordComp.oce_importetotal,
						emp.emp_nombrecto,  
						CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
						sit.sod_nombresituacion estatus,
						per.per_rfc,
						df.folioorden as ppro_nombrearchivo,
						df.serie + ISNULL(df.folio,'') factura,
						df.uuid,
						df.fecha_carga as fechaValidacion,
						CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
						df.serie,
						df.fecha_factura fecha_pago,
						df.rfc_emisor,
						df.rfc_receptor,
						df.importe as importe_total,
						ordComp.oce_uuid,
						Recepcion =
						CASE ordComp.sod_idsituacionorden
						WHEN 1 THEN 'Pendiente'
						WHEN 2 THEN 'Pendiente'
						WHEN 3 THEN 'Pendiente'
						WHEN 4 THEN 'Pendiente'
						WHEN 5 THEN 'Pendiente'
						WHEN 6 THEN 'Recepción Completa'
						WHEN 7 THEN 'Recepción Incompleta'
						ELSE  'Recepción Incompleta'	 
						END,
						Estado =
						CASE ordComp.sod_idsituacionorden
						WHEN 12 THEN 'Pagada'
						WHEN 13 THEN 'Pagada'
						WHEN 16 THEN 'Pagada'
						WHEN 18 THEN 'Pagada'
						ELSE  'Por Pagar'
						END 
					FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] DF
						JOIN cuentasxpagar.dbo.cxp_ordencompra ordComp on DF.folioorden = ordComp.oce_folioorden
						LEFT JOIN BDPersonas.dbo.cat_personas per ON ordComp.oce_idproveedor = per.per_idpersona
						LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
						LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
						LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
					WHERE ordComp.oce_idproveedor = @idProveedor  
						AND (@monto IS NULL OR ordComp.oce_importetotal = @monto)
						AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))	
						AND ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18)
						  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					AND ordComp.oce_idsucursal = @Sucursal
					order by ordComp.oce_fechaorden ASC
			END
SET NOCOUNT OFF

go

