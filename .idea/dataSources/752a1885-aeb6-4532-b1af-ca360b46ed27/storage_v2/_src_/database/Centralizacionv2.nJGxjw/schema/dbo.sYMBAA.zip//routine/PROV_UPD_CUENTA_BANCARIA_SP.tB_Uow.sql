
 CREATE PROCEDURE [dbo].[PROV_UPD_CUENTA_BANCARIA_SP]
 
    @titular	 VARCHAR(100)
    
    ,@sucursal	 VARCHAR(50)
    ,@noCuenta	 VARCHAR(30)
    ,@clabe		 VARCHAR(30)
    ,@cie		 VARCHAR(30) = ''
    ,@referencia	 VARCHAR(50) 
	,@idCuentaBancaria INT
	,@idDetPersonaTramite INT
	
AS
BEGIN
BEGIN TRY

		IF(@sucursal = '')
		BEGIN
		SET @sucursal = NULL
		END


		IF(@referencia = '')
		BEGIN
		SET @referencia = NULL
		END

		UPDATE  [dbo].[PROV_CUENTA_BANCARIA]
		   SET
			   [titular] = @titular
			  ,[sucursal] =@sucursal
			  ,[noCuenta] =@noCuenta
			  ,[clabe] =@clabe
			  ,[cie] = @cie
			  ,[referencia] = @referencia
		WHERE idCuentaBancaria = @idCuentaBancaria

		UPDATE Tramites.[dbo].[DetallePersonaCuenta] 
		SET	   noCuenta = @noCuenta
			  ,[clabe] =@clabe
		WHERE idDetPersonaTramite = @idDetPersonaTramite


		select 1 result
END TRY
BEGIN CATCH
SELECT 0 result
END CATCH
END
 go

