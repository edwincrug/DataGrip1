-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez.
-- Create date: 19/02/2019
-- Description:	Nuevo Token de un proveedor
-- ==========================================================================================
-- EXECUTE [PPROV_SEL_NUEVO_TOKEN_SP] 'EET140204420'    
CREATE PROCEDURE [dbo].[PPROV_SEL_NUEVO_TOKEN_SP] 
	@rfc VARCHAR(13) = ''
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @estatus VARCHAR(10) = 'error'
BEGIN TRY	

	DECLARE @correoUser VARCHAR(100) = ''
	DECLARE @tokenID uniqueidentifier
	
	SET @tokenID = NEWID()

	SELECT @correoUser = [correo] 
	  FROM [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV] 
	 WHERE [ppro_user] = @rfc
   

	UPDATE [Proveedores].[dbo].[CorreoActivacion]
	   SET [token] = @tokenID
	 WHERE per_rfc = @rfc
	
	SET @estatus = 'ok'
 	
	SELECT @estatus      AS estatus
	      ,@rfc          AS rfc
		  ,@correoUser   AS correo 
		  ,@tokenID      AS token

END TRY
BEGIN CATCH
	PRINT('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'PPROV_SEL_NUEVO_TOKEN_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
END CATCH
END
go

