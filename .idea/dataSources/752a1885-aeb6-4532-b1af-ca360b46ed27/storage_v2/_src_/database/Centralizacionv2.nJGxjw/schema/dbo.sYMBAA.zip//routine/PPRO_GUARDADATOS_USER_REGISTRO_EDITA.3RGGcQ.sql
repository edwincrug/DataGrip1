

CREATE PROCEDURE [dbo].[PPRO_GUARDADATOS_USER_REGISTRO_EDITA]     --  [dbo].[PPRO_GUARDADATOS_USER_REGISTRO]  'CMI950920TR8','CRA130717JE6','C','49055',42212.59,'4f289c8f-9886-4e7f-8d5d-ea07f9a9c17b','30/11/2015','MARJ820822PG3','AU-AUA-ZAR-UN-PF-39'
@razonSocial VARCHAR(max) = '',
@rfc VARCHAR(50),
@correoUsuario VARCHAR(150),
@contrasena VARCHAR(50),
@opcion INT = 0
AS

SET NOCOUNT ON	

BEGIN TRY	
	DECLARE @msg VARCHAR(100) = '', @estatus VARCHAR(10) = 'ok'
	DECLARE @per_idpersona SMALLINT	

					IF(@opcion = 1) --correo
						BEGIN
							
							UPDATE PPRO_USERSPORTALPROV 
							SET	correoTemporal = @correoUsuario
							WHERE ppro_user=@rfc

							DECLARE @tokenID uniqueidentifier
							SET @tokenID = NEWID()
					
							INSERT INTO [proveedores].[dbo].[CorreoActivacion]([token],[per_rfc],[fechaCreacion],[fechaActivacion],[idEstatus])
							VALUES (@tokenID,@rfc,GETDATE(),NULL,1)

							EXEC [proveedores].[dbo].[SEL_ACTIVACION_CORREO_SP] @rfcProveedor = @rfc,@correo = @correoUsuario,@token = @tokenID, @opcion = 2

							SET @msg = 'Cambio de correo correcto. Se ha enviado un mail para activar el nuevo correo.'
						END

					IF(@opcion = 2)--pass
						BEGIN
							
							DECLARE @cadena VARBINARY(200),  @cadenaEncrypt VARCHAR(200)   
							SELECT @cadena = EncryptByPassPhrase('4ndr4d3', @contrasena)  

							SET @cadenaEncrypt = (SELECT CONVERT(VARCHAR(MAX), @cadena,1))

							UPDATE PPRO_USERSPORTALPROV 
							SET	ppro_pass = @cadenaEncrypt
							WHERE ppro_user=@rfc

							SET @msg = 'Cambio de contraseña correcto.'
						END
	
		--SELECT TOP 1 ppro_userId FROM PPRO_USERSPORTALPROV WHERE ppro_user=@rfc 
		SELECT @estatus estatus,@msg mensaje

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[PPRO_GUARDADATOS_USER_REGISTRO_EDITA]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,'Error al Editar usuario, intente de nuevo.' mensaje--@msg

END CATCH
;
go

