
---- EXECUTE [dbo].[PROV_SEL_CUENTAS_ACTIVAS_PROVEEDOR_SP] @rfc  = 'BACF7207175D8'
CREATE PROCEDURE [dbo].[PROV_SEL_CUENTAS_ACTIVAS_PROVEEDOR_SP] 
      @rfc    VARCHAR(20)
	 
	
AS
BEGIN

	BEGIN TRY
	SET NOCOUNT ON;

	--DECLARE @rfc VARCHAR(20) = 'BACF7207175D8'

    DECLARE @aux               INT = 1
	DECLARE @max               INT = 0
	DECLARE @idEmpresaBusca    INT = 0
	DECLARE @idSucursal        INT = 0
	DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
	DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @nomEmpresa        NVARCHAR(100)=NULL
	DECLARE @ipServidor        NVARCHAR(100)=NULL
	DECLARE @cadIpServidor     NVARCHAR(100)=NULL
	DECLARE @consulta          NVARCHAR(MAX)=NULL
	DECLARE @ipServer		   NVARCHAR(20)
	DECLARE @cont               INT = 1


	DECLARE @idPersona NUMERIC(18,0)

	DECLARE @tblUsuarios TABLE
		(
			id INT IDENTITY(1,1)
			,idPersona NUMERIC
			,rfc VARCHAR(20)
		)

	INSERT INTO @tblUsuarios
	SELECT  PER_IDPERSONA, PER_RFC  FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_RFC  = @rfc

	--SELECT * from  @tblUsuarios
	
	DECLARE @existeCuenta TABLE  (  id INT IDENTITY(1,1),
								    idEmpresa         int
								   ,nombreEmpresa     nvarchar(100)
								   ,idPersona       int 
								   ,cuentaBancaria    VARCHAR(25)
								   ,convenio		  VARCHAR(25)
								   ,clabe			  VARCHAR(20)
								   ,tipoCuenta		  VARCHAR(200)	
								   ,banco			  VARCHAR(50)
								   ,autorizado		  INT
								   ,banxico			  VARCHAR(20)	
								  )     

    ------------------------------------------------------------
	-- BUSCAMOS EN TODAS LAS CONCENTRADORAS
	------------------------------------------------------------	
    DECLARE @Bases TABLE  ( id INT IDENTITY(1,1),
	                        idEmpresa         int
							,nombreEmpresa     nvarchar(100)
							,nombreSucursal    nvarchar(100)
							,nomBaseConcentra  nvarchar(50)
							,nomBaseMatriz     nvarchar(50)
							,ipServidor        nvarchar(20)
							,idSucursal        int 
							)     

	 INSERT INTO @Bases
            SELECT B.[emp_idempresa]
			      ,A.[emp_nombre]
			      ,B.[nombre_sucursal]
				  ,B.[nombre_base]
				  ,B.[nombre_base_matriz]
				  ,B.[ip_servidor]
				  ,B.[sucursal_matriz]
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
			       INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON A.[emp_idempresa]= B.[emp_idempresa]
			WHERE B.tipo = 2
	
	
	 ------------------------------------------------------------
	 -- RECORREMOS LAS CONCENTRADORAS PARA BUSCAR EL PROVEEDOR
	 ------------------------------------------------------------

	 WHILE (@cont <= (SELECT count(1) FROM @tblUsuarios) )
	 BEGIN
	 
			SELECT @idPersona =  idPersona from @tblUsuarios WHERE id = @cont

			
			
			SET @aux = 0
			SET @max = (SELECT count(1) FROM @Bases)
	 
			 WHILE(@aux <= @max)
			 BEGIN
	 
				 --SELECT @aux
				 SELECT  @idEmpresaBusca   = DB.idEmpresa 
						,@nomEmpresa       = DB.nombreEmpresa
						,@nomBaseConcentra = DB.nomBaseConcentra
						,@nomBaseMatriz    = DB.nomBaseMatriz
						,@idSucursal       = DB.idSucursal
						,@ipServidor       = DB.ipServidor
				
				   FROM @Bases AS DB 
				  WHERE DB.id = @aux 

				  SET @cadIpServidor = '['+ @ipServidor  +'].'
		  
				  SELECT @ipServer = local_net_address
				  FROM sys.dm_exec_connections
				  WHERE Session_id = @@SPID
		
		
				IF (@ipServidor = @ipServer)
				BEGIN
				set @cadIpServidor =''
				END

				IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @nomBaseConcentra)) 
				BEGIN
		
						SET @consulta = ' SELECT  ' + cast (@idEmpresaBusca as varchar(20)) +' ,' +''''+ @nomEmpresa +'''' + '          
												 ,BCO_IDPERSONA 
												 ,BCO_NUMCUENTA
												 ,BCO_CONVENIOCIE
												 ,BCO_CLABE
												 ,BCO_TIPCUENTA
												 ,PAR_DESCRIP1
												 ,BCO_AUTORIZADA
												 ,PAR_DESCRIP5 
								
										FROM '+ @cadIpServidor + @nomBaseConcentra +'.DBO.CON_BANCOS B INNER JOIN  ' + + @cadIpServidor + @nomBaseConcentra + + '.dbo.PNC_PARAMETR AS PG ON B.BCO_BANCO = PG.PAR_IDENPARA AND PG.PAR_TIPOPARA = ''BA'' AND PG.PAR_STATUS = ''A''' + char(13) +  
										' WHERE BCO_AUTORIZADA = 1 AND BCO_IDPERSONA = ' + cast (@idPersona as varchar(20)) 
				print @consulta
					
				INSERT INTO @existeCuenta
				EXECUTE (@consulta)
				END
		
 
				 SET @aux = @aux + 1
				
			 END
			SET @cont = @cont + 1
	END 



	 
	 --select * from GAZM_CONCENTRA.dbo.CON_BANCOS
	 --SELECT * from GAZM_CONCENTRA.dbo.PNC_PARAMETR PG WHERE PG.PAR_TIPOPARA = 'BA' AND PG.PAR_STATUS = 'A' 
	 ------------------------------------------------------------
	 -- RESULTADO FINAL
	 ------------------------------------------------------------
	 
	 SELECT  DISTINCT
				--				    idEmpresa 
					--			   ,nombreEmpresa
								   idPersona  
								   ,cuentaBancaria    
								   ,convenio		  
								   ,clabe			  
								   ,tipoCuenta		  	
								   ,B.pbx_descripcion banco			  
								   ,CASE WHEN autorizado = 1 THEN 'ACTIVO' ELSE 'NO ACTIVA' END autorizado		
								   ,banxico  
	FROM @existeCuenta E
	INNER JOIN Pagos.[dbo].[PAG_CAT_BANXICO] B ON B.pbx_numoficial COLLATE Modern_Spanish_CI_AS = E.banxico 
	
	 
	   
	END TRY

    BEGIN CATCH
	select 'Error'
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_VALIDA_CUENTA_PROV_SP'
		SELECT  ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END

go

