/*
LQMA 21062017
*/
/*
INS_APLICA_PAGO_EX_SP @idUsuario = 71, @folio = 'AU-ZM-NFA-SE-PE-1165'
*/

CREATE PROCEDURE [dbo].[INS_APLICA_PAGO_EX_SP]
@idUsuario INT = 0,
@folio VARCHAR(50) = ''
AS
BEGIN
	
	DECLARE @estatus INT = 0, @Mensaje VARCHAR(MAX) = ''
	
	BEGIN TRANSACTION TRAN_APLICA_PAGO_EX
	
		BEGIN TRY

			DECLARE	@idEmpresa INT = 0, @idSucursal INT = 0, @base VARCHAR(100) = '', @server VARCHAR(20) = '',@ipLocal VARCHAR(20) = ''
		
			SELECT	@idEmpresa    = oce_idempresa
					,@idSucursal   = oce_idsucursal
			FROM	cuentasxpagar..cxp_ordencompra
			WHERE	oce_folioorden = @folio
		 
			SELECT	@base = '['+ nombre_base + ']', @server = ip_servidor 
			FROM	Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
			WHERE	tipo = 2--catsuc_nombrecto = 'CONCENTRA'
					AND emp_idempresa = @idEmpresa
					--AND suc_idsucursal = @idSucursal

			SELECT	TOP 1 @ipLocal=local_net_address 
			FROM	sys.dm_exec_connections c
			ORDER BY local_net_address DESC
  
			IF(LTRIM(RTRIM(@ipLocal))!=RTRIM(LTRIM(@server)))
				SET @base = '['+ @server +'].'+@base	
	
			IF NOT EXISTS(SELECT folioorden FROM Centralizacionv2.dbo.PPRO_DATOSFACTURAS WHERE folioorden = @folio  ) 
				BEGIN

					INSERT INTO [Centralizacionv2].[dbo].[BITACORA_AVANZA_NODOS] (folio, descripcion,fecha)
							SELECT @folio,'Error Pago Externo - La orden no tiene Factura',GETDATE()	

					SELECT @mensaje = 'La orden no tiene Factura.', @estatus = 1
		
				END
			ELSE
				BEGIN
					IF NOT EXISTS(SELECT top(1) * FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] WHERE Nodo_Id = 7 AND Doc_Id = 15 AND Fecha_Creacion IS NOT NULL AND Folio_Operacion = @folio)
						BEGIN
							INSERT INTO [Centralizacionv2].[dbo].[BITACORA_AVANZA_NODOS] (folio, descripcion,fecha)
							SELECT @folio,'Error Pago Externo - La orden no tiene Comprobante recepción de material o servicio',GETDATE()
							SELECT @mensaje = 'La orden no tiene Comprobante recepción de material o servicio.', @estatus = 1
						END
					ELSE
						BEGIN
							IF NOT EXISTS(SELECT * FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @folio AND sod_idsituacionorden IN (6,7,8,10)) --IN(3,4,10,11,12,13,16,18) 
								BEGIN											
									SELECT @mensaje = 'La orden no se encuentra en los estatus permitidos para realizar pago externo.', @estatus = 1
								END
							ELSE
								BEGIN
									IF (SELECT sod_idsituacionorden FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @folio) = 4 --cancelado
										BEGIN
											SELECT @estatus = 1, @mensaje = 'La Orden ha sido cancelada, no es posible aplicar pago externo.'
										END
									ELSE
										BEGIN
											DECLARE @query VARCHAR(2000) = ''
											SET @query = '	SELECT	SUM(CAR_EXTERNA.CCP_ABONO) - SUM(CAR_EXTERNA.CCP_CARGO)
															FROM ' + @base + '.DBO.[VIS_CONCAR01] AS CAR_EXTERNA 
															INNER JOIN ' + @base + '.DBO.PNC_PARAMETR AS [A] ON [CAR_EXTERNA].CCP_CARTERA = [A].PAR_IDENPARA AND [A].PAR_TIPOPARA = ''CARTERA'' AND [A].PAR_IDMODULO = ''CXP'' AND [A].PAR_IMPORTE5 <> 1   
															LEFT JOIN CUENTASXPAGAR.DBO.CXP_ORDENCOMPRA AS [Z] ON [CAR_EXTERNA].CCP_IDDOCTO = [Z].OCE_FOLIOORDEN COLLATE MODERN_SPANISH_CI_AS
															LEFT JOIN CUENTASXPAGAR.DBO.CXP_DETALLEAUTOSNUEVOS AS [ZZ] ON [Z].OCE_FOLIOORDEN = [ZZ].OCE_FOLIOORDEN
															LEFT JOIN ' + @base + '.DBO.SER_VEHICULO ON [CAR_EXTERNA].CCP_OBSGEN = VEH_NUMSERIE COLLATE MODERN_SPANISH_CI_AS 
															INNER JOIN CENTRALIZACIONV2.DBO.PPRO_DATOSFACTURAS ON [CAR_EXTERNA].CCP_IDDOCTO = FOLIOORDEN COLLATE MODERN_SPANISH_CI_AS
															WHERE [Z].oce_folioorden = ''' + @folio + '''
															AND  [Z].[sod_idsituacionorden] IN (6,7,8,10)'
				
											print @query
	
											DECLARE @total TABLE(ID TINYINT IDENTITY(1,1), monto DECIMAL(18,5))

											INSERT INTO @total 
											EXECUTE(@query)
												IF(SELECT TOP(1) monto FROM @total) = 0
													BEGIN			
														--SI ES 0 ENTONCES
														print 'ESTATUS A PAGADA (12) ' + @folio
														UPDATE cuentasxpagar.dbo.cxp_ordencompra
														SET sod_idsituacionorden = 12
														WHERE oce_folioorden = @folio 	

														--LQMA add 08012018																
														UPDATE DIG_EXPNODO_DOC 
														SET Fecha_Creacion = GETDATE()
														WHERE Folio_Operacion = @folio
														AND Doc_Id = 68

														DECLARE @nodoE INT = 7

														UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
														SET		FechaFin = GETDATE(), Nodo_Estatus_Id = 3
														WHERE	Folio_Operacion IN (@folio) AND Nodo_Id = @nodoE

														UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
														SET		FechaInicio =  GETDATE(), FechaFin = GETDATE(), Nodo_Estatus_Id = 3
														WHERE	Folio_Operacion IN (@folio) AND Nodo_Id BETWEEN @nodoE + 1 AND 14 -1

														UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
														SET		FechaInicio =  GETDATE(), Nodo_Estatus_Id = 2
														WHERE	Folio_Operacion IN (@folio) AND Nodo_Id = 14

														UPDATE DIG_EXPNODO_DOC 
														SET Fecha_Creacion = GETDATE()
														WHERE Folio_Operacion = @folio 
														AND Doc_Id = 64													

														SET @mensaje = 'Se ha aplicado el pago a la orden: ' + @folio
													END
												ELSE
													BEGIN								
														SELECT @mensaje = 'No se ha aplicado el pago. Aun tiene saldo en cartera.', @estatus = 1
													END
								END							
						END	
						END
					

				INSERT INTO [Centralizacionv2].[dbo].[BITACORA_AVANZA_NODOS] (folio, descripcion,fecha)
					SELECT @folio,'Aplicacion Pago Externo',GETDATE()				
		END
	
				COMMIT TRANSACTION TRAN_APLICA_PAGO_EX	
			
				SELECT @estatus estatus, @mensaje mensaje
			 
	END TRY
	BEGIN CATCH

		ROLLBACK TRANSACTION TRAN_APLICA_PAGO_EX
		
		INSERT INTO BITACORA_PROCESOS
		VALUES (8,'Error CATCH INS_APLICA_PAGO_EX_SP : ' + @folio,GETDATE())
				
		SELECT @Mensaje = ERROR_MESSAGE() + ' @folio : ' + @folio
		
		DECLARE @resp TABLE (id INT IDENTITY(1,1), respuesta INT)		
		INSERT INTO @resp	
		EXECUTE INS_ERROR_SP 'INS_APLICA_PAGO_EX_SP', @Mensaje
		
		SELECT ERROR_NUMBER() estatus, 'Error al intentar aplicar pago.' mensaje  

	END CATCH  

END
go

