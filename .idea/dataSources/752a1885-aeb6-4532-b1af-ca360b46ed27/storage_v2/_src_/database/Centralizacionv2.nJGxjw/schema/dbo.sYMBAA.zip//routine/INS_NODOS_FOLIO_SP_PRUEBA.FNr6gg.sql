-- =================================================================
-- Modified date: 30/06/2016 Lourdes Maldonado Sánchez
-- Description:	  22/11/2016 Insetar Expediente Cuentas por Cobrar
-- =================================================================
--EXECUTE [INS_NODOS_FOLIO_SP_PRUEBA] 'AU-ZM-ZAR-UN-17', 2
CREATE PROCEDURE [dbo].[INS_NODOS_FOLIO_SP_PRUEBA]
	 @folio		varchar(50)
	,@idproceso	int
	
AS
BEGIN
	--SET NOCOUNT ON;
	--SET IMPLICIT_TRANSACTIONS ON

	BEGIN TRY

			DECLARE @Nodo	   Int
			DECLARE @tipoOrden Int = 0
			DECLARE @aux       Int = 1
			-- =================================================================
			-- Primero necesitamos saber si el folio ya tiene nodos.
			-- =================================================================
			IF EXISTS (Select Nodo_Id FROM DIG_EXP_NODO WHERE Folio_Operacion = @folio)
			BEGIN
			    PRINT('Existe Expediente');
				SELECT -1;				
			END
			ELSE 
			-- =================================================================
			-- Si No tiene expediente creado, se crea
			-- =================================================================
			-- =================================================================
			-- PROCESO 1
			-- =================================================================
			IF (@idproceso = 1)
				BEGIN
				        PRINT('CXP: Orden normal');
						--1) Insertar el expediente
						INSERT INTO DIG_EXPEDIENTE (Proc_Id, Fecha_Inicio, Estatus_Id, Folio_Operacion)
						VALUES (@idproceso, GETDATE(), 1, @folio)
			
						-- Declaración del cursor para insertar la totalidad de nodos en DIG_EXP_NODO
						DECLARE cNodos CURSOR FOR
								SELECT Nodo_Id
								  FROM DIG_NODO
								 WHERE Proc_Id = @idproceso
						-- Apertura del cursor
							OPEN cNodos
					    -- Lectura de la primera fila del cursor
						FETCH cNodos INTO  @Nodo
							WHILE (@@FETCH_STATUS = 0 )
							BEGIN   --2) Inserta OC por todos los nodos
									INSERT INTO DIG_EXP_NODO (Proc_ID, Nodo_Id, Folio_Operacion, Nodo_Estatus_Id) 
									     VALUES (@idproceso, @Nodo, @folio, 1)
									--3) Inserta Documento por Nodo
									INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
										SELECT Proc_Id, Nodo_Id, @folio, Doc_Id FROM DIG_NODO_DOC 
										WHERE Proc_Id = @idproceso AND Nodo_Id = @Nodo ORDER BY Orden ASC	

								FETCH cNodos INTO  @Nodo
							 END
					-- Cierre del cursor
						CLOSE cNodos
					-- Liberar los recursos
						DEALLOCATE cNodos
					
					--3)Actualiza fecha de creacion a los documentos que son de Origen 2
					UPDATE [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
					   SET [Fecha_Creacion] = GETDATE()
					  FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
					 WHERE folio_operacion = @folio
					   AND doc_id in (SELECT [Doc_Id]
										FROM [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO]
									   WHERE [Doc_Origen] =2)
		
					--4)Buscamos el tipo de Orden  4.-PI  5.-IF
					SELECT @tipoOrden = [oce_idtipoorden]
					  FROM [cuentasxpagar].[dbo].[cxp_ordencompra]
					 WHERE oce_folioorden = @folio
                    SELECT  @tipoOrden
					----------------------------------------------------
					-- 5)Actualiza el estatus del NODO 1 a vigente
					----------------------------------------------------
					IF (@tipoOrden <> 4 and @tipoOrden <> 5 )    
					BEGIN
					    PRINT('CXP: Orden normal');
						EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
						   @proc_Id = @idproceso
						  ,@nodo_Id = 1
						  ,@folio_Operacion = @folio
						  ,@accion_Id = 1
                        --UPDATE dbo.DIG_EXP_NODO SET Nodo_Estatus_Id = 2 where folio_operacion = @folio AND nodo_id = 1 and proc_id = @idproceso 
					END
					ELSE 
					----------------------------------------------------
					-- ELSE Actualiza el estatus del NODO 1 a vigente
					----------------------------------------------------
					    BEGIN
							IF (@tipoOrden = 4 )  ----4 PI
							BEGIN
							    WHILE(@aux < 4)
						        BEGIN
							    PRINT('CXP: Orden PI');
								EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
								   @proc_Id = @idproceso
								  ,@nodo_Id = @aux
								  ,@folio_Operacion = @folio
								  ,@accion_Id = 1
                                --INS_CIERRA_NODO_SP  
								EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
													   @proc_Id = @idproceso  
													  ,@nodo_Id = @aux 
													  ,@folio_Operacion = @folio
								SET @aux = @aux + 1
						        END
							END
							ELSE 
								BEGIN
									IF (@tipoOrden = 5 )  --5 IF
									BEGIN
									    WHILE(@aux < 7)
						                BEGIN
									    PRINT('CXP: Orden IF');
										EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
										   @proc_Id = @idproceso
										  ,@nodo_Id = @aux
										  ,@folio_Operacion = @folio
										  ,@accion_Id = 1
                                        --INS_CIERRA_NODO_SP  
								        EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
													   @proc_Id = @idproceso  
													  ,@nodo_Id = @aux 
													  ,@folio_Operacion = @folio
										SET @aux = @aux + 1
						                END
									END
								END
						END
                    ----------------------------------------------------
					--6) Termina Regresa 0
					----------------------------------------------------
					SELECT 0; 

		END  --END ELSE EXISTE EXPEDIENTE
		    -- =================================================================
			-- PROCESO 2
			-- =================================================================
	        ELSE IF (@idproceso = 2)
			BEGIN
			            PRINT('CXC: Inicia Orden normal');
			            --1) Insertar el expediente
						PRINT('CXC: Inserto el expediente');
						INSERT INTO DIG_EXPEDIENTE (Proc_Id, Fecha_Inicio, Estatus_Id, Folio_Operacion)
						VALUES (@idproceso, GETDATE(), 1, @folio)
			
						-- Declaración del cursor para insertar la totalidad de nodos en DIG_EXP_NODO
						DECLARE cNodos CURSOR FOR
								SELECT Nodo_Id
								  FROM DIG_NODO
								 WHERE Proc_Id = @idproceso
						-- Apertura del cursor
							OPEN cNodos
					    -- Lectura de la primera fila del cursor
						PRINT('CXC: Comienza inserta Nodos y documentos por Nodo');
						FETCH cNodos INTO  @Nodo
							WHILE (@@FETCH_STATUS = 0 )
							BEGIN   --2) Inserta OC por todos los nodos
									INSERT INTO DIG_EXP_NODO (Proc_ID, Nodo_Id, Folio_Operacion, Nodo_Estatus_Id) 
									     VALUES (@idproceso, @Nodo, @folio, 1)
									--3) Inserta Documento por Nodo
									INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
										SELECT  ND.Proc_Id
										       ,ND.Nodo_Id
											   ,@folio
											   ,ND.Doc_Id
										  FROM DIG_NODO_DOC  AS ND
											   INNER JOIN  Centralizacionv2.dbo.DIG_DOC_TIPO_VENTA AS DT ON DT.Doc_Id = ND.Doc_Id AND DT.Tip_Id = (SELECT Tip_Id
																																					  FROM Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA AS T
																																						   INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O 
																																						   ON O.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS = @folio AND T.Tip_Clave = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS
																																					)
										 WHERE Proc_Id = @idproceso 
										   AND Nodo_Id = @Nodo 

									ORDER BY Orden ASC	

								FETCH cNodos INTO  @Nodo
							 END
					-- Cierre del cursor
						CLOSE cNodos
					-- Liberar los recursos
						DEALLOCATE cNodos
					
					--3)Actualiza fecha de creacion a los documentos que son de Origen 2
					PRINT('CXC: Actualizo Fecha en doc Origen 2');
					UPDATE [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
					   SET [Fecha_Creacion] = GETDATE()
					  FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
					 WHERE folio_operacion = @folio AND Proc_Id = @idproceso
					   AND doc_id in (SELECT [Doc_Id]
										FROM [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO]
									   WHERE [Doc_Origen] =2 AND Proc_Id = @idproceso)

                    --4)Activo Nodos 
					PRINT('CXC: Activo nodos del 1 al 2');
					UPDATE [Centralizacionv2].[dbo].[DIG_EXP_NODO]
					  SET  fechaInicio = getdate()
					      ,fechaFin    = getdate()
					      ,Nodo_Estatus_Id = 3
					WHERE [Proc_Id] =2 
					  AND [Folio_Operacion] = @folio
					  AND [Nodo_Id] > 0 AND [Nodo_Id] <= 2

			    SELECT 0;
				PRINT('CXC: Termino');
			END --END ELSE idproceso = 2 
	END TRY
	BEGIN CATCH		
		DECLARE @Mensaje  nvarchar(max)		
		SELECT @Mensaje = ERROR_MESSAGE()	
		EXECUTE INS_ERROR_SP 'INS_NODOS_FOLIO_SP', @Mensaje
		SELECT  ERROR_NUMBER() 
	END CATCH  
END


go

