-- =============================================
-- Author:		<JJSY>
-- Create date: <SP que regresa reporte de documentos proceso 2 por periodo de fechas>
-- Description:	<Description,,>
--TEST [expedienteSeminuevo].[SEL_REPORTE_DOCUMENTOS_BY_PERIODO_PROCESO2] '05/06/2020', '18/06/2020', 2, 4,6
-- =============================================
CREATE  PROCEDURE [expedienteSeminuevo].[SEL_REPORTE_DOCUMENTOS_BY_PERIODO_PROCESO2]
	 @F1 VARCHAR(10),
	 @F2 VARCHAR(10), 
	 @idProceso INT,
	 @idEmpresa INT, 
	 @idSucursal INT 

	
AS
BEGIN

DECLARE @nombresucursal VARCHAR(MAX);
DECLARE @bd VARCHAR(50) = '', @query VARCHAR(MAX) = '';
DECLARE @maxId INT = 0, @minId INT = 0;
DECLARE @tableVines TABLE (id INT IDENTITY, idExpediente INT, vinExpediente VARCHAR(100));
DECLARE @tableFinal TABLE (id INT IDENTITY, idExpediente INT, idDocumento INT, idDocumentoInsertado INT, nombreDocumento VARCHAR(200), vinExpediente VARCHAR(100));
DECLARE @tempSerVehiculo TABLE (id INT IDENTITY, numeroSerie VARCHAR(100), idCliente INT);

SELECT 
	@bd = nombre_base 
FROM DIG_CAT_BASES_BPRO 
WHERE emp_idEmpresa = @idEmpresa AND suc_idSucursal = @idSucursal;


 SELECT @nombresucursal = nombre_sucursal
	   FROM DIG_CAT_BASES_BPRO 
		WHERE emp_idEmpresa = @idEmpresa
		AND suc_idSucursal = @idSucursal


INSERT INTO @tableVines
SELECT 
	id_expediente,
	exp_vin
FROM [expedienteSeminuevo].[expedientes] 
WHERE exp_empresa = @idEmpresa AND exp_sucursal = @idSucursal AND CONVERT(DATE,exp_fechaCreacion, 103) BETWEEN CONVERT(DATE,@F1,103) AND CONVERT(DATE,@F2,103)

SELECT 
	@maxId = MAX(id),
	@minId = MIN (id)
FROM @tableVines

WHILE ( @minId <= @maxId )
	BEGIN
		DECLARE @documentosExistentes TABLE ( id INT IDENTITY, idExpedienteIns INT, idDocumentoIns INT);
		DECLARE @idExpediente INT = 0, @vinExpediente VARCHAR(100);

		SELECT 
			@idExpediente = idExpediente,
			@vinExpediente = vinExpediente
		FROM @tableVines WHERE id = @minId

		INSERT INTO @documentosExistentes
		SELECT 
			TV.idExpediente,
			DE.id_documento
		FROM @tableVines TV
		INNER JOIN [expedienteSeminuevo].[documentosExpediente] DE ON DE.id_expediente = TV.idExpediente
		WHERE id = @minId AND DE.id_proceso = @idProceso AND DE.id_expediente = @idExpediente
		GROUP BY DE.id_documento, TV.idExpediente

		INSERT INTO @tableFinal
		SELECT 
			@idExpediente AS idExpediente,
			A.id_documento,
			B.idDocumentoIns, 
			A.doc_Nombre,
			@vinExpediente AS vinExpediente
		FROM (
				SELECT 
						id_documento, 
						doc_nombre, 
						doc_extencion, 
						doc_opcional,
						doc_usuarios, 
						doc_proceso,
						doc_varios
					FROM [expedienteSeminuevo].[cat_documentos] 
					WHERE doc_proceso = @idProceso) AS A
				LEFT JOIN (
				SELECT 
					* 
				FROM @documentosExistentes 
				WHERE idExpedienteIns = @idExpediente) AS B ON B.idDocumentoIns = A.id_documento AND A.doc_proceso = @idProceso

		SET @query = 'SELECT VEH_NUMSERIE, VEH_IDCLIENT FROM [' + @bd + '].[DBO].[SER_VEHICULO] WHERE VEH_NUMSERIE = ''' + @vinExpediente + '''' + ' AND VEH_SITUACION LIKE ''%SVEN%'''; 
		PRINT @query

		INSERT INTO @tempSerVehiculo
		EXEC (@query)
		SET @minId = @minId + 1
	END


			BEGIN TRY

			SELECT 
				sucursal,
				vin,
				nombreCliente,
		isnull(MAX([24]),'NO APLICA') as [Facturadeunidadseminueva],
		isnull(MAX([25]),'NO APLICA') as [PedidooriginalBproyDigitalizacion],
		isnull(MAX([26]),'NO APLICA') AS [Recibosdepago],
		isnull(MAX([27]),'NO APLICA')AS [Documentossoportesderecibosdecaja],
		isnull(MAX([28]),'NO APLICA')AS [NotasdeCargo],
		isnull(MAX([29]),'NO APLICA') AS [NotasdeCredito],
		isnull(MAX([30]),'NO APLICA') AS [FacturasdeAccesorios],
		isnull(MAX([31]),'NO APLICA') AS [CaratulaPolizadeseguro],
		isnull(MAX([32]),'NO APLICA')AS [RFC],
		isnull(MAX([33]),'NO APLICA')AS [IdentificacionOficialVigente],
		isnull(MAX([34]),'NO APLICA')AS [Comprobantededomiciliovigente],
		isnull(MAX([35]),'NO APLICA')AS [Autorizaciondelafinancieracorridadeautorizacion],
		isnull(MAX([36]),'NO APLICA')AS [Actaconstitutiva],
		isnull(MAX([37]),'NO APLICA')AS [Poderderepresentantelegal],
		isnull(MAX([38]),'NO APLICA')AS [Salidadeunidad],
		isnull(MAX([39]),'NO APLICA')AS [CONTRATODECOMPRAVENTA],
		isnull(MAX([40]),'NO APLICA')AS [FormatodeIdentificaciondePLD],
		isnull(MAX([41]),'NO APLICA') AS [Polizadegarantia] ,
		isnull(MAX([42]),'NO APLICA') AS [Recibodeunidad] ,
		isnull(MAX([43]),'NO APLICA')AS [CartaFactura],
		isnull(MAX([44]),'NO APLICA')AS [Certificadodeunidadgarantizada],
		isnull(MAX([45]),'NO APLICA')AS [Copiadelengomadodelasplacasydelatarjetadecirculacion],
		isnull(MAX([46]),'NO APLICA')AS [AvisodePrivacidad],
		isnull(MAX([47]),'NO APLICA')AS [Copiadecaratuladelcontratoconlafinanciera]
	FROM (
	
			SELECT 
			@nombresucursal as sucursal,
			idExpediente, 
			vinExpediente as vin,
			TSV.idCliente as idCliente,
			(P.PER_PATERNO + ' ' + P.PER_MATERNO + ' ' + P.PER_NOMRAZON) AS nombreCliente,
			idDocumento,
			nombreDocumento,
			CASE WHEN TF.idDocumentoInsertado > 0
					THEN 'OK'
				WHEN TF.idDocumentoInsertado IS NULL AND  (P.PER_TIPO  = 'MOR' AND CT.doc_moral = 1)
					THEN 'FALTA'
				WHEN TF.idDocumentoInsertado IS NULL AND  (P.PER_TIPO  = 'MOR' AND CT.doc_moral = 0)
					THEN 'NO AP'

				WHEN TF.idDocumentoInsertado > 0
					THEN 'OK'
				WHEN TF.idDocumentoInsertado IS NULL AND  P.PER_TIPO  = 'FIS' AND CT.doc_fisica= 1
					THEN 'FALTA' 
				WHEN TF.idDocumentoInsertado IS NULL AND  P.PER_TIPO  = 'FIS' AND CT.doc_fisica = 0
					THEN 'NO AP'

				WHEN TF.idDocumentoInsertado > 0
					THEN 'OK'
				WHEN TF.idDocumentoInsertado IS NULL AND  P.PER_TIPO  = 'FIE' AND CT.doc_fisicaAE= 1
					THEN 'FALTA' 
				WHEN TF.idDocumentoInsertado IS NULL AND  P.PER_TIPO  = 'FIE' AND CT.doc_fisicaAE = 0
					THEN 'NO AP'
				
				END AS existe
			--CASE WHEN idDocumentoInsertado IS NULL THEN 'No existe' ELSE 'Existe' END AS existe
			FROM @tableFinal TF
			INNER JOIN @tempSerVehiculo TSV ON TF.vinExpediente = TSV.numeroSerie
			INNER JOIN [GA_Corporativa].[DBO].[PER_PERSONAS] P ON P.PER_IDPERSONA = TSV.idCliente
			INNER JOIN [expedienteSeminuevo].[cat_documentos] CT ON TF.idDocumento =CT.id_documento	
		) x
		PIVOT
		(
			MAX(existe)
			FOR idDocumento in 
			(
			[24],
			[25],
			[26],
			[27],
			[28],
			[29],
			[30],
			[31],
			[32],
			[33],
			[34],
			[35],
			[36],
			[37],
			[38],
			[39],
			[40],  
			[41],
			[42],
			[43],
			[44],
			[45],
			[46],
			[47]
			) )AS p
			GROUP BY sucursal,vin,nombreCliente 

    END TRY

	BEGIN CATCH
		PRINT (ERROR_MESSAGE())
		SELECT success = 0
		SELECT msg = ERROR_MESSAGE();
	END CATCH


END

go

