-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 07/12/2016
-- Description: Regresa Serie, Folio y RFCEmisor de las diferentes Notas de Crédito 
--              Segun el folio de la Orden de CXC
-- ==========================================================================================
-- EXECUTE [dbo].[SEL_NOTA_CREDITO_CXC_SP] @folio = 'AU-ZM-ZAR-UN-52'
CREATE PROCEDURE [dbo].[SEL_NOTA_CREDITO_CXC_SP] 
	@folio    NVARCHAR(50) = ''
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY

	DECLARE @idCotizacion   INT = 0;
	DECLARE @idEmpresa      INT = 0;
	DECLARE @idSucursal     INT = 0;
	DECLARE @rfc            VARCHAR(30) = 0;
	DECLARE @nomBaseMatriz  VARCHAR(30) = 0;
	DECLARE @query          NVARCHAR(MAX) = null

	DECLARE @ipServidor        NVARCHAR(100);
	DECLARE @cadIpServidor     NVARCHAR(200);
	DECLARE @bdSucursal			NVARCHAR(100);

	---------------------------------------------------------------
	--  Obtenemos la consulta dinamicamente                      --
	---------------------------------------------------------------
	DECLARE     @VariableTabla TABLE (idNotaCredito	    nvarchar(30)
									  ,serie	        nvarchar(10)
									  ,folio	        nvarchar(20)
									  ,rfcEmisor	    nvarchar(30)
									  )
   

		
		SELECT @idCotizacion  = ucu_idcotizacion 
		       ,@idEmpresa    = ucu_idempresa
			   ,@idSucursal   = ucu_idsucursal
		  FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
		 WHERE ucu_foliocotizacion = @folio

		  SELECT @rfc = rfc
		   FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
		  WHERE catsuc_nombrecto = 'CONCENTRA'
            AND emp_idempresa    = @idEmpresa

			SET @bdSucursal =[dbo].[base_Cotizacion](@folio)

        SET @cadIpServidor = [dbo].[base_Concentradora](@idEmpresa)

		 --SELECT @rfc = rfc
		 --       ,@nomBaseMatriz = nombre_base_matriz
			--	,@ipServidor = ip_servidor
		 --  FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
		 -- WHERE catsuc_nombrecto = 'CONCENTRA'
   --         AND emp_idempresa    = @idEmpresa

   --     SET @cadIpServidor = '[' + @ipServidor + '].'
		
        --SELECT  @cadIpServidor, @nombreBase
		--SELECT @rfc,@nomBaseMatriz 

		
		SET @query = ' SELECT D.CCP_IDDOCTO         AS idNotaCredito '+
							  ',(SELECT dbo.[fn_BuscaLetras](D.CCP_IDDOCTO ))  AS serie '+
							  ',(SELECT dbo.[fn_BuscaNumeros](D.CCP_IDDOCTO )) AS folio '+
							  ','+''''+ @rfc+''''+' AS rfcEmisor '+
						'FROM [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSAL] AS A '+ 
							   'INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] B ON A.ucu_idcotizacion=B.ucu_idcotizacion '+
							   'INNER JOIN '+ @bdSucursal +'ADE_VTAFI C   ON C.VTE_TIPODOCTO= '+''''+'A'+''''+' AND C.VTE_STATUS= '+''''+'I'+''''+' AND B.ucn_noserie=C.VTE_SERIE '+
							   'LEFT JOIN '+ @bdSucursal +'VIS_CONCAR01 D ON CCP_TIPODOCTO= '+''''+'NCRBON'+''''+' AND CCP_REFERNCRBONI = C.VTE_DOCTO   '+
					   'WHERE A.ucu_foliocotizacion ='+''''+ @folio +''''+' AND D.CCP_IDDOCTO IS NOT NULL AND D.CCP_IDDOCTO <> '+''''+''''
        
		--SELECT @query
		PRINT (@query);
		INSERT INTO  @VariableTabla
		    EXECUTE (@query);

        SELECT idNotaCredito	 
			   ,serie	     
			   ,folio	     
			   ,rfcEmisor
		FROM @VariableTabla

	END TRY

	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_NOTA_CREDITO_CXC_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END

go

