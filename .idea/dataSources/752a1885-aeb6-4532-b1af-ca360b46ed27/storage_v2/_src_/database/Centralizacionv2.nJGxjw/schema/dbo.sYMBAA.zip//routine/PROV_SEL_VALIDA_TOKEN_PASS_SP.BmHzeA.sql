CREATE PROCEDURE [dbo].[PROV_SEL_VALIDA_TOKEN_PASS_SP]
@rfc VARCHAR(20)
,@token uniqueidentifier
AS
BEGIN
IF EXISTS(SELECT 1 FROM Centralizacionv2.dbo.[PROV_TokenRecuperaPass] WHERE rfc = @rfc AND tokenRecupera = @token )
BEGIN 
	SELECT 1 success
END
ELSE
BEGIN
	SELECT 0 success
END

END
go

