/*
Quita la fecha de Creacion de la factura en todos los nodos del expediente de la orden de compra
Quita del portal de facturacion la fecha promesa de pago.
Pone en estatus de edicion la factura en el portal de pago para permitir la carga nuevamente de la factura.
Coloca un registro en DIG_MSGREPET para que otro componente envie diariamente un correo al proveedor solicitando una factura válida.
El componente enviará un correo hasta que el estatus de la factura sea distinto de 1 y/o esté finalizada la o.c.


Regresa 1 si se pudo hacer la desvinculacion de la factura.
Regresa 0 si hubo un error al hacer la desvinculacion de la factura.

Esta dentro de una transaccion.

*/

CREATE PROCEDURE spU_DESVINCULA_FACTURA(@iProc_Id int,@sFolio_Operacion varchar(50), @iResultado int OUTPUT) --with recompile
 AS
declare
@iDoc_Id int,
@iIdProv int,
@sRFCProv varchar(20),
@sCuentaEnvia varchar(50),
@dFecha_Creacion smalldatetime

begin 

set nocount on

select @iDoc_Id=20
select @iResultado=0
select @sCuentaEnvia=''

BEGIN TRANSACTION DesvinculandoFactura

		update [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] set Fecha_Creacion=null
		where Proc_Id=@iProc_Id
		and Doc_Id = @iDoc_Id
		and Folio_Operacion = @sFolio_Operacion
		
		update [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] set estatus = 1
		where folioorden=@sFolio_Operacion
		
   		      --Enviar correo al proveedor 1 vez al día solicitando se cambie la factura en el portal.
		       select @iIdProv = oce_idproveedor from cuentasxpagar..cxp_ordencompra where oce_folioorden=@sFolio_Operacion
		       select @sRFCProv = per_rfc from [BDPersonas].[dbo].[cat_personas] where per_idpersona = @iIdProv    		       
		       
		       select @sCuentaEnvia = isnull(correo,'') from  [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV] r1
		       where r1.ppro_user= @sRFCProv

		       if (@sCuentaEnvia='')
				begin	
					select @sCuentaEnvia='Sin cuenta de correo'	
				end		

				if Exists (select 1 from [Centralizacionv2].[dbo].[DIG_MSGREPET] where folio_operacion=@sFolio_Operacion)			
				   begin
						update [Centralizacionv2].[dbo].[DIG_MSGREPET] set fecha_ins=getdate(), fecha_env=null,cuenta_env=@sCuentaEnvia, estatus='x enviar', fecha_prox_env=getdate() where folio_operacion=@sFolio_Operacion 	                   
				   end
				else
				   begin
						   insert into [Centralizacionv2].[dbo].[DIG_MSGREPET] (id_prov,folio_operacion,fecha_ins,fecha_env,veces_env,cuenta_env,estatus,fecha_prox_env)
						   values (@iIdProv,@sFolio_Operacion,getdate(),null,0,@sCuentaEnvia,'x enviar',getdate())	
				   end
                --
		select @iResultado=1

COMMIT TRANSACTION DesvinculandoFactura

Return @iResultado

set nocount off
end
go

