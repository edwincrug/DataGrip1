-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 22/10/2015
-- Description:	Stored que presenta la información de un folio, con sus nodos y permisos
-- =============================================
-- [SEL_NODO_FOLIO_SP] 'AU-AU-CUA-UN-PE-576', 1, 1 
CREATE PROCEDURE [dbo].[SEL_NODO_FOLIO_SP] 
	 @id_folio varchar(50)
	,@id_proceso int
	,@id_perfil int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @folioPlanPiso VARCHAR(50) = null
	SET @folioPlanPiso = (SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @id_folio)
	SELECT  EN.Folio_Operacion as folio
			, EN.FechaInicio AS fechaInicio
			, EN.FechaFin AS fechaFin
			, EN.Nodo_Id as id
			, N.Nodo_Nombre as nombre
			, N.Nodo_Descripcion as descripcion
			,(CASE WHEN nal.Alerta_Id IS NULL THEN 0 ELSE 1 END) as alertas
			, EN.Nodo_Estatus_Id as estatus
			, CASE WHEN DNP.Perfil_Id IS NOT NULL THEN 1 ELSE 0 END AS [enabled]
			,0 as active
			,N.Nodo_Imagen as imagen
	FROM    dbo.DIG_EXP_NODO AS EN 
			INNER JOIN dbo.DIG_NODO AS N ON N.Nodo_Id = EN.Nodo_Id AND N.Proc_Id = EN.Proc_Id
			LEFT JOIN dbo.DIG_NODO_ALERTA AS nal ON nal.Proc_Id = EN.Proc_id AND nal.Nodo_Id = EN.Nodo_Id AND nal.Folio_Operacion = EN.Folio_Operacion
			LEFT JOIN DIG_NODOPERFIL AS DNP ON DNP.Nodo_Id = EN.Nodo_Id AND DNP.Proc_Id = EN.Proc_Id AND DNP.Perfil_Id = @id_perfil
	WHERE	EN.Folio_Operacion IN ( @id_folio,@folioPlanPiso) 
			AND EN.Proc_Id = @id_proceso		
	ORDER BY EN.Nodo_Id
END
go

