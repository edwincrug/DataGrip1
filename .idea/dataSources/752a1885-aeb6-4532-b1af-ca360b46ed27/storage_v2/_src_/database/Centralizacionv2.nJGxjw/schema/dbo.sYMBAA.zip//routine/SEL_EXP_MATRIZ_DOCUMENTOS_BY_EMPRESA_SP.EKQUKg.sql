-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_EXP_MATRIZ_DOCUMENTOS_BY_EMPRESA_SP 2, 4, 6, '2019/05/01', '2019/05/02'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EXP_MATRIZ_DOCUMENTOS_BY_EMPRESA_SP]
	@proceso INT,
	@idEmpresa INT,
	@idSucursal INT,
	@fechaInicio VARCHAR(50),
	@fechaFin VARCHAR(50)
AS
BEGIN

	SET NOCOUNT ON;

    IF(@proceso = 1)
		BEGIN

			SELECT 
				BD.nombre_sucursal AS sucursal,
				'ORDENES DE COMPRA' AS proceso
			FROM [DIG_CAT_BASES_BPRO] BD 
			WHERE BD.emp_idempresa = @idEmpresa AND BD.suc_idsucursal = @idSucursal

			SELECT 
				DISTINCT EXPDOC.[Doc_Id]
				,EXPDOC.[Folio_Operacion] AS folio
				,CASE WHEN [Fecha_Creacion] IS NOT NULL THEN 'OK' ELSE '' END existe
				,CASE WHEN Doc_Origen = 1 THEN 'Carga Usuario' WHEN Doc_Origen = 2 AND EXPDOC.Doc_Id = 67 THEN 'Ambos'  ELSE 'Creado Sistema' END origen
				,[Doc_Nombre] AS nombre
			FROM [DIG_EXPEDIENTE] E
			INNER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] OC ON OC.oce_folioorden = E.Folio_Operacion
			INNER JOIN [DIG_EXPNODO_DOC] EXPDOC ON EXPDOC.Folio_Operacion = E.Folio_Operacion
			INNER JOIN [DIG_CATDOCUMENTO] CATDOC ON EXPDOC.Doc_Id = CATDOC.Doc_Id
			WHERE oce_idempresa = @idEmpresa AND oce_idsucursal = @idSucursal AND EXPDOC.[Proc_Id] = @proceso AND EXPDOC.Folio_Operacion <> ''
			ORDER BY EXPDOC.Folio_Operacion
		END
	ELSE
		BEGIN
			SELECT 
				BD.nombre_sucursal AS sucursal,
				'COTIZACIONES' AS proceso 
			FROM [DIG_CAT_BASES_BPRO] BD 
			WHERE BD.emp_idempresa = @idEmpresa AND BD.suc_idsucursal = @idSucursal

			SELECT 
				DISTINCT EXPDOC.[Doc_Id]
				,CD.ucn_noserie AS serie
				,U.usu_nombre + ' ' + U.usu_paterno + '  ' + U.usu_materno AS vendedor
				,EXPDOC.[Folio_Operacion] AS folio
				,CASE WHEN [Fecha_Creacion] IS NOT NULL THEN 'OK' ELSE '' END existe
				,CASE WHEN Doc_Origen = 1 THEN 'Carga Usuario' WHEN Doc_Origen = 2 AND EXPDOC.Doc_Id = 67 THEN 'Ambos'  ELSE 'Creado Sistema' END origen
				,[Doc_Nombre] AS nombre,
				CU.ucu_idcliente,
				PER_NOMRAZON + ' ' + PER_PATERNO + ' ' + PER_MATERNO AS NombreCliente,
				VW.PEN_FECHAENTREGA_REAL,
				B.nombre_sucursal
			FROM [DIG_EXPEDIENTE] E
			INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_foliocotizacion = E.Folio_Operacion COLLATE DATABASE_DEFAULT
			INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = CU.ucu_idcotizacion
			INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = CU.ucu_idusuarioalta
			INNER JOIN [DIG_EXPNODO_DOC] EXPDOC ON EXPDOC.Folio_Operacion = E.Folio_Operacion
			INNER JOIN [DIG_CATDOCUMENTO] CATDOC ON EXPDOC.Doc_Id = CATDOC.Doc_Id
			INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = CU.ucu_idempresa AND B.suc_idsucursal = CU.ucu_idsucursal
			INNER JOIN GA_Corporativa.DBO.PER_PERSONAS P ON P.PER_IDPERSONA = CU.ucu_idcliente
			INNER JOIN [VW_FECHA_ENTREGA_UNIDAD] VW ON VW.PEN_NUMSERIE = CD.ucn_noserie
			WHERE CU.ucu_idempresa = 4 AND CU.ucu_idsucursal = 6 AND EXPDOC.[Proc_Id] = 2 AND VW.PEN_FECHAENTREGA_REAL IS NOT NULL 
			AND convert(varchar, ucu_fechacotiza, 111) BETWEEN convert(varchar, @fechaInicio, 111) AND convert(varchar, @fechaFin, 111) AND EXPDOC.Folio_Operacion = 'AU-ZM-NZA-UN-5425'
			ORDER BY 2,4

			--SELECT 
			--	DISTINCT EXPDOC.[Doc_Id]
			--	,EXPDOC.[Folio_Operacion] AS folio
			--	,CASE WHEN [Fecha_Creacion] IS NOT NULL THEN 'OK' ELSE '' END existe
			--	,CASE WHEN Doc_Origen = 1 THEN 'Carga Usuario' WHEN Doc_Origen = 2 AND EXPDOC.Doc_Id = 67 THEN 'Ambos'  ELSE 'Creado Sistema' END origen
			--	,[Doc_Nombre] AS nombre
			--FROM [DIG_EXPEDIENTE] E
			--INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_foliocotizacion = E.Folio_Operacion COLLATE DATABASE_DEFAULT
			--INNER JOIN [DIG_EXPNODO_DOC] EXPDOC ON EXPDOC.Folio_Operacion = E.Folio_Operacion
			--INNER JOIN [DIG_CATDOCUMENTO] CATDOC ON EXPDOC.Doc_Id = CATDOC.Doc_Id
			--WHERE CU.ucu_idempresa = @idEmpresa AND CU.ucu_idsucursal = @idSucursal AND EXPDOC.[Proc_Id] = @proceso AND convert(varchar, ucu_fechacotiza, 111) BETWEEN convert(varchar, @fechaInicio, 111) AND convert(varchar, @fechaFin, 111)
			--ORDER BY EXPDOC.Folio_Operacion
		END
END


go

