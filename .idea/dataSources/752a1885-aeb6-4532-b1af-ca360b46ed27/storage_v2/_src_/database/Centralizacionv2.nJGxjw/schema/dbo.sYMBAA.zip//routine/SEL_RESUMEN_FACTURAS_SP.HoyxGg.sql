--[dbo].[SEL_RESUMEN_FACTURAS_SP] 'AU-AU-UNI-UN-2417','12808'
CREATE PROCEDURE [dbo].[SEL_RESUMEN_FACTURAS_SP]
	@folio NVARCHAR(50)
	,@idCotDet NVARCHAR(20)
AS 
BEGIN
	------------------------------------------------------------
	--Otengo la ip y el nombre de la base de la sucursal, y el id de la cotización 
	------------------------------------------------------------
	DECLARE @baseSucursal VARCHAR(100) 
			,@idCotizacion NUMERIC(18,0)
			,@idCliente NUMERIC(18,0)
			,@idPedido NUMERIC(18,0)
			,@idAlmacen VARCHAR(20)
			,@idCotizacionDetalle NUMERIC(18,0)
			,@auxFactura VARCHAR(100)
			,@idPedidoTramite VARCHAR(20)
			,@saldo NUMERIC(18,2) = 0

	SELECT	@idCotizacion = CU.ucu_idcotizacion
			,@idCliente = CU.ucu_idcliente
	FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL CU
	WHERE	ucu_foliocotizacion = @folio 
	sET @baseSucursal = [dbo].[base_Cotizacion](@folio)
	--SELECT	@baseSucursal = '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' 
	--		,@idCotizacion = CU.ucu_idcotizacion
	--		,@idCliente = CU.ucu_idcliente
	--	FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL CU
	--		INNER JOIN DIG_CAT_BASES_BPRO PRO ON CU.ucu_idempresa = PRO.emp_idEmpresa AND CU.ucu_idsucursal = PRO.suc_idSucursal AND PRO.estatus = 1 AND PRO.tipo = 1
	--	WHERE	ucu_foliocotizacion = @folio 
	-----------------------------------------------------------
	--Declaro variable tabla para guardar datos de todas las facturas
	-----------------------------------------------------------
	DECLARE @facturas TABLE(id INT IDENTITY(1,1), tipoFactura VARCHAR(100),cargo NUMERIC(18,2),iva NUMERIC(18,2), total NUMERIC(18,2), fecha VARCHAR(20), factura VARCHAR(100),numeroSerie VARCHAR(100),saldo NUMERIC(18,2))
	DECLARE @facturaUnidad VARCHAR(MAX)
			--,@facturaRefacciones VARCHAR(MAX)
			,@facturaTramites VARCHAR(MAX)
			,@facturaServicios VARCHAR(MAX)
			,@facturaOtrosConceptos VARCHAR(MAX)
			,@facturaAccesorios VARCHAR(MAX)
	-----------------------------------------------------------
	--Declaro variable tabla para guardar las facturas y poder ir por el saldo 
	-----------------------------------------------------------
	DECLARE @auxTablaFactura TABLE(factura NVARCHAR(100))
	-----------------------------------------------------------
	--Obtengo la Factura de Unidad
	-----------------------------------------------------------
	--SELECT @idCotizacion AS idCotizacion
	SELECT @auxFactura = ucn_idFactura FROM [cuentasporcobrar].[dbo].UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucu_idcotizacion = @idCotizacion AND ucn_idcotizadetalle = @idCotDet
	--SELECT @auxFactura
	-----------------------------------------------------------
	--Obtengo la Informacion de todas las faturas
	-----------------------------------------------------------
	--FACTURA UNIDADES
	IF(@auxFactura <> '' AND @auxFactura IS NOT NULL)
		BEGIN
			EXECUTE [dbo].[SEL_SALDO_FACTURA_SP] @auxFactura,@folio, @saldo output
			SET @facturaUnidad = 'SELECT ''Factura Unidad'', VTE_VTABRUT AS cargo, VTE_IVA AS iva, VTE_TOTAL AS total, VTE_FECHDOCTO AS fecha, VTE_DOCTO AS factura, VTE_SERIE AS numeroSerie, '+CONVERT(VARCHAR(500),@saldo)+' FROM '+@baseSucursal+'ADE_VTAFI WHERE VTE_DOCTO = '''+@auxFactura+''''
			--PRINT (@facturaUnidad)
			INSERT INTO @facturas
			EXECUTE(@facturaUnidad)
		END

	-----------------------------------------------------------
	--Obtengo la Factura de Otros Conceptos
	-----------------------------------------------------------
	SET @facturaOtrosConceptos =	'SELECT	'+char(39)+'Factura Otros Conceptos'+char(39)+'' + char(13) + 
									'		,VTE_VTABRUT AS cargo' + char(13) + 
									'		,VTE_IVA AS iva' + char(13) + 
									'		,VTE_TOTAL AS total' + char(13) + 
									'		,VTE_FECHDOCTO AS fecha' + char(13) + 
									'		,VTE_DOCTO AS factura' + char(13) + 
									'		,VTE_SERIE AS numeroSerie' + char(13) + 
									'		,0.00' + char(13) + 
									'FROM	[cuentasporcobrar].[dbo].[uni_otrosconceptosenc] AS OCE' + char(13) + 
									'		INNER JOIN ' + @baseSucursal + 'ADE_VTAFI AS V ON OCE.uoc_idpedidobpro = V.VTE_REFERENCIA1 AND VTE_STATUS = ''I''' + char(13) + 
									'		INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS C ON C.ucu_idcliente = V.VTE_IDCLIENTE' + char(13) + 
									'WHERE	C.ucu_idcotizacion = ' + CONVERT(VARCHAR(20),@idCotizacion) + '' + char(13) + 
									'' 
	--PRINT (@facturaOtrosConceptos)
	INSERT INTO @facturas
	EXECUTE(@facturaOtrosConceptos)
	-----------------------------------------------------------
	--Obtengo la Factura de Orden de Servicio
	-----------------------------------------------------------
	SET @facturaServicios =	'SELECT	'+char(39)+'Factura Servicio'+char(39)+'' + char(13) + 
							'		,ISNULL(VTE_VTABRUT,(VTE_TOTAL - VTE_IVA))  AS cargo' + char(13) + 
							'		,VTE_IVA AS iva' + char(13) + 
							'		,VTE_TOTAL AS total' + char(13) + 
							'		,VTE_FECHDOCTO AS fecha' + char(13) + 
							'		,VTE_DOCTO AS factura' + char(13) + 
							'		,VTE_SERIE AS numeroSerie' + char(13) + 
							'		,0.00  ' + char(13) + 
							'FROM	' + @baseSucursal + 'SER_ORDEN AS OS' + char(13) +  
							'		INNER JOIN ' + @baseSucursal + 'ADE_VTAFI AS V ON V.VTE_REFERENCIA1 = OS.ORE_IDORDEN AND VTE_STATUS = ''I'' ' + char(13) +  
							'WHERE	OS.ORE_IDCOTIZACIONUNIVERSAL = ' + CONVERT(VARCHAR(20),@idCotizacion) + '' + char(13) + 
							'' 
	--PRINT (@facturaServicios)
	INSERT INTO @facturas
	EXECUTE(@facturaServicios)
	

	-----------------------------------------------------------
	--Obtengo la Factura de Accesorios
	-----------------------------------------------------------
	SET @facturaAccesorios =	'SELECT  '+char(39)+'Factura Accesorios'+char(39)+'' + char(13) + 
								'		,VTE_VTABRUT AS cargo' + char(13) + 
								'		,VTE_IVA AS iva' + char(13) + 
								'		,VTE_TOTAL AS total' + char(13) + 
								'		,VTE_FECHDOCTO AS fecha' + char(13) + 
								'		,VTE_DOCTO AS factura' + char(13) + 
								'		,VTE_SERIE AS numeroSerie' + char(13) + 
								'		,0.00  ' + char(13) + 
								'FROM	[cuentasporcobrar].[dbo].[par_pedmostenc] AS P' + char(13) + 
								'		INNER JOIN ' + @baseSucursal + '[PAR_PEDMOST] AS PE ON P.pmm_nopedmost = PE.PMM_NUMERO AND PMM_IDALMA = '+char(39)+'NEG'+char(39)+'' + char(13) + 
								'		INNER JOIN ' + @baseSucursal + '[ADE_VTAFI] AS V ON V.VTE_DOCTO = PMM_REF2 AND VTE_STATUS = ''I'''  + char(13) + 
								'WHERE	ucu_idcotizacion = ' + CONVERT(VARCHAR(20),@idCotizacion) + ' ' + char(13) + 
								''
	PRINT (@facturaAccesorios)
	INSERT INTO @facturas
	EXECUTE(@facturaAccesorios)

	-----------------------------------------------------------
	--Obtengo la Factura de Tramites
	-----------------------------------------------------------
	SET @facturaTramites =	'SELECT	'+char(39)+'Factura Tramites'+char(39)+'' + char(13) + 
							'		,SUM(CCP_CARGO) AS cargo' + char(13) + 
							'		 ,SUM(CCP_CARGO) *  0.16  AS iva' + char(13) + 
							'		 , SUM(CCP_CARGO) * 1.16  AS total' + char(13) + 
							'		,ISNULL(VTE_FECHDOCTO, CCP_FECHADOCTO) AS fecha' + char(13) + 
							'		 ,ISNULL(CCP_IDDOCTO,uaw_IDDOCTO ) AS factura' + char(13) + 
							'		 ,ISNULL(VTE_SERIE,'''') AS numeroSerie' + char(13) + 
							'		,0.00  ' + char(13) + 
							'FROM	[cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS C' + char(13) + 
							'		INNER JOIN cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES AS CD ON C.ucu_idcotizacion = CD.ucu_idcotizacion' + char(13) + 
							'		INNER JOIN cuentasporcobrar.dbo.uni_anticiposweb AS CA ON CA.ucn_idcotizadetalle = CD.ucn_idcotizadetalle  OR CD.ucn_idcotizadetalle = CA.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
							'		LEFT JOIN ' + @baseSucursal + 'ADE_VTAFI AS V ON V.VTE_REFERENCIA1 = CA.UAW_IDPEDIDOOTR AND V.VTE_IDCLIENTE = C.ucu_idcliente  AND VTE_STATUS = ''I''' + char(13) + 
							'       LEFT JOIN ' + @baseSucursal + '[VIS_CONCAR01] AS VIS ON uaw_IDDOCTO = VIS.CCP_IDDOCTO  AND CCP_TIPODOCTO IN(''FAC'',''NCA'') ' + char(13) + 
							'WHERE	CD.ucn_idcotizadetalle = ' + @idCotDet + '' + char(13) + 
							'GROUP BY VTE_VTABRUT, VTE_IVA, VTE_TOTAL, VTE_FECHDOCTO, CCP_IDDOCTO, uaw_IDDOCTO, VTE_SERIE, CCP_FECHADOCTO'  + char(13) + 
							''



 -- LEFT JOIN [192.168.20.92].[GAAU_Universidad].DBO.[VIS_CONCAR01] AS VIS ON uaw_IDDOCTO = VIS.CCP_IDDOCTO  AND CCP_TIPODOCTO IN('FAC','NCR','ANT','PCA')

	PRINT (@facturaTramites)
	INSERT INTO @facturas
	EXECUTE(@facturaTramites)
	DECLARE @aux INT = 1, @max INT = 0
	SET @max = (SELECT COUNT(id) FROM @facturas)
	WHILE(@aux <= @max)
		BEGIN
			SELECT @auxFactura = factura FROM @facturas WHERE id = @aux
			EXECUTE [dbo].[SEL_SALDO_FACTURA_SP] @auxFactura,@folio, @saldo output
			UPDATE @facturas
			SET saldo = @saldo
			WHERE factura = @auxFactura
			SET @aux = @aux + 1
		END
	SELECT tipoFactura, ISNULL(cargo,0) as cargo, ISNULL(iva,0) as iva, ISNULL(total,0) as total, fecha, factura, numeroSerie, saldo FROM @facturas where factura is not null
END;

go

