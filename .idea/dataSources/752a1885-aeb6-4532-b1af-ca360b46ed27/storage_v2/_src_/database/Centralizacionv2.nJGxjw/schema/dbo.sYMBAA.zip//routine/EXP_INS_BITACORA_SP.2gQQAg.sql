-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[EXP_INS_BITACORA_SP]
	@idUsuario INT,
	@documento VARCHAR(100),
	@vinAuto VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;

	INSERT INTO [dbo].[EXP_BITACORA_DOCUMENTOS]
           ([idUsuario]
           ,[documentoGuardado]
		   ,[vinAuto]
           ,[fechaIsercion])
     VALUES
           (@idUsuario
           ,@documento
		   ,@vinAuto
           ,GETDATE());

	SELECT success = 1;
END

go

