CREATE PROCEDURE [dbo].[PPROV_VALIDA_TOTAL]   -- [dbo].[PPROV_ordcompra_prov]  4,null,null,1
@totalXml varchar(50),
@folioOrden VARCHAR(50)
AS  
  SET NOCOUNT ON          
	  set @totalXml= REPLACE(@totalXml,',',''); 

SELECT CASE (oce_importetotal) 
        WHEN @totalXml THEN 1
		ELSE 0
		END AS oce_importeTotal
 FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_folioorden=@folioOrden

SET NOCOUNT OFF
go

