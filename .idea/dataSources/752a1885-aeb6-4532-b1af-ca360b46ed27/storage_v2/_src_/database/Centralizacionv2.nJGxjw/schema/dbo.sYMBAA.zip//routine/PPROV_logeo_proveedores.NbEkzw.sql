--PPROV_logeo_proveedores 'GRI161214FE0','123456'
CREATE PROCEDURE [dbo].[PPROV_logeo_proveedores] 
@user VARCHAR(15) = '',
@pass VARCHAR(50) = '',
@idAdmin INT = NULL
AS

IF (@idAdmin IS NOT NULL)
	BEGIN
		SELECT	usu_idusuario ppro_userId
				,LTRIM(RTRIM(replace(replace(usu_paterno,'Ñ',''),'.','')  +' '+ replace(replace(usu_materno,'Ñ',''),'.','') +' '+ usu_nombreusu)) razonSocial
				,' ' rfc
				,[usu_correo] correo
				,'' urlLogo
				,[usu_estatus] estatus
				,0 pprov_usersStatus
				,2 ppro_idUserRol
		FROM
		[ControlAplicaciones].[dbo].[cat_usuarios]
		WHERE usu_idusuario = @idAdmin
	END
ELSE
	BEGIN
		DECLARE @passEnc VARCHAR(100)
		DECLARE @passDecry  VARCHAR(50)
		DECLARE @SQLString nvarchar(500)
		DECLARE @ParmDefinition nvarchar(500) 
		
		SELECT @passEnc = ppro_pass FROM PPRO_USERSPORTALPROV WHERE ppro_User = @user
							
		SET @SQLString =N'SELECT @passD = convert(varchar(MAX),DecryptByPassPhrase(''4ndr4d3'',  '+ @passEnc +' )) '	 
		SET @ParmDefinition = N' @passD varchar(MAX) OUTPUT'; 
		
		
		EXECUTE sp_executesql @SQLString, @ParmDefinition, @passD=@passDecry OUTPUT;



		SELECT users.ppro_userId, users.razonSocial,@user rfc, correo,ISNULL(urlLogo,'') AS urlLogo, estatus, pprov_usersStatus, users.ppro_idUserRol --Se coloco isnull debido a que marcaba error al ser null 
		FROM dbo.PPRO_USERSPORTALPROV users
		WHERE users.ppro_user = @user AND @passDecry =  @pass --users.ppro_pass = @pass --AND users.pprov_usersStatus = 1 
		ORDER BY ppro_userId
	END
go

