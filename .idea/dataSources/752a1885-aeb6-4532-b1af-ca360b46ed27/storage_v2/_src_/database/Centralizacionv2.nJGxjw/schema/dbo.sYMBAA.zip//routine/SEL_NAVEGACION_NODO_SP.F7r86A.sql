-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 27/01/2016
-- Description:	Recupera los Flujos de Orden, Remision y Factura en diferentes sentidos Adelante o Atras
-- =============================================
--AU-AUA-VIG-SE-PE-46 Y AU-AUA-VIG-SE-PE-47  --> AU-AUA-VIG-SE-IF
--EXECUTE [dbo].[SEL_NAVEGACION_NODO_SP] 'AU-ZM-ZAR-RE-PI-10',2,1 --'CA-CRA-CUA-SE-PE-26',1,5 -- --'AU-ZM-ZAR-RE-PE-26',1,3   --AU-ZM-ZAR-RE-IF-15 , AU-ZM-ZAR-RE-PE-101  , AU-ZM-ZAR-RE-PI-41
--AU-ZM-ZAR-RE-PE-26 ORD
--AU-ZM-ZAR-RE-PI-10 REM
--AU-ZM-ZAR-RE-IF-8  FAC

--CA-CRA-CUA-SE-PE-26
--AU-ZM-ZAR-OT-PS-23
CREATE PROCEDURE [dbo].[SEL_NAVEGACION_NODO_SP]
	 @folio		    nvarchar(50) = ''
	,@tipoFolio		int = 0  --1.-Orden 2.-Remision 3.-Factura
	,@tipoRegreso	int = 0  --1.-Orden 2.-Remision 3.-Factura

AS
BEGIN

	SET NOCOUNT ON;
	--Es una Orden de Servicio de cualquier de cualquier Sucursal
	DECLARE @depto int = 0
	SELECT @depto   =    CASE WHEN EXISTS( --SE: SERVICIO
										SELECT [oce_folioorden]
										  FROM [cuentasxpagar].[dbo].[cxp_ordencompra]
										 WHERE [oce_folioorden] = @folio
										   AND [oce_iddepartamento] IN  (SELECT [dep_iddepartamento]   
																		   FROM [ControlAplicaciones].[dbo].[cat_departamentos]
																		  WHERE [dep_nombrecto] ='SE')  --Ordenes de Servicio
																				)
									THEN 1
                               WHEN EXISTS( --OT: OTROS CONCEPTOS(COMPRAS VARIAS)
										SELECT [oce_folioorden]
										  FROM [cuentasxpagar].[dbo].[cxp_ordencompra]
										 WHERE [oce_folioorden] = @folio
										   AND [oce_iddepartamento] IN  (SELECT [dep_iddepartamento]   
																		   FROM [ControlAplicaciones].[dbo].[cat_departamentos]
																		  WHERE [dep_nombrecto] ='OT')  --Ordenes Compras Varias
																				)
									THEN 2   
									ELSE 0 
									END		

   
    PRINT 'Que tipo de Depto es: ' + cast(@depto as varchar)  
	IF(@depto = 0)
	BEGIN
	SET @depto = 2
	END  


		BEGIN TRY 
	    --Comenzamos salto hacia adelante	     
					-------------------------------------------------------
					--Tengo una Orden y se desglosa en N Remisiones
					--EXECUTE [dbo].[SEL_NAVEGACION_NODO_SP] 'AU-ZM-ZAR-RE-PE-26',1,2
					-------------------------------------------------------
					IF (@tipoFolio = 1 AND  @tipoRegreso = 2)
					BEGIN
						SELECT [irr_folioinicial]  folioinicial    --Folio_Orden 
							   ,[irr_folionuevo]   folionuevo      --Folio_Remision 
							   ,2 tipoFolioNav
						  FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac]
						 WHERE [irr_folioinicial] = @folio  --Var_Orden
						GROUP BY  [irr_folioinicial]
								 ,[irr_folionuevo]
					END
					-------------------------------------------------------
					--Tengo una Remision y se desglosa en N Facturas
					--EXECUTE [dbo].[SEL_NAVEGACION_NODO_SP] 'AU-ZM-ZAR-RE-PI-10',2,3
					-------------------------------------------------------
					ELSE IF (@tipoFolio = 2 AND  @tipoRegreso = 3)
					BEGIN 
						SELECT [ifr_folioinicial] folioinicial --Folio_Remision
							  ,[ifr_folionuevo]   folionuevo   --Folio_Factura
							  ,3 tipoFolioNav
						  FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac]
						 WHERE [ifr_folioinicial] = @folio     --Var_Remision
					  GROUP BY [ifr_folioinicial]
							  ,[ifr_folionuevo]
					END
					-------------------------------------------------------
					--Tengo una Orden y se desglosa en N Facturas
					--EXECUTE [dbo].[SEL_NAVEGACION_NODO_SP] 'AU-ZM-ZAR-RE-PE-26',1,3 
					-------------------------------------------------------
					ELSE IF (@tipoFolio = 1 AND  @tipoRegreso = 3)
					BEGIN
					SELECT [irr_folioinicial]  folioinicial     --Folio_Orden 
						  ,[irr_folionuevo]    folionuevo       --Folio_Remision 
						  ,2 tipoFolioNav
						  --,[ifr_folionuevo]   FACTURA
					 FROM  [cuentasxpagar].[dbo].[cxp_integracionremrefac]
						  ,[cuentasxpagar].[dbo].[cxp_integracionfacrefac]
					WHERE [irr_folionuevo]   = [ifr_folioinicial] --Folio_Remision
					  AND [irr_folioinicial] = @folio             --Var_Orden
					GROUP BY    [irr_folioinicial]
								,[irr_folionuevo]
								--,[ifr_folionuevo]
                    END
					---*****************--
					ELSE IF (@tipoFolio = 1 AND  @tipoRegreso = 5 AND @depto = 1)
					BEGIN
					 SELECT  [ifs_folioanterior]  folioinicial     --Folio_Orden 
					  	    ,[ifs_folionuevo]     folionuevo       --Folio_Factura
							,5 tipoFolioNav
					  FROM [cuentasxpagar].[dbo].[cxp_integracionfacser]
					 WHERE [ifs_folioanterior] = @folio 
				     GROUP BY [ifs_folioanterior]
	 					  ,[ifs_folionuevo]
                    END
					---*****************--
					ELSE IF (@tipoFolio = 1 AND  @tipoRegreso = 5 AND @depto = 2)
					BEGIN
					  SELECT [ifp_folioanterior] folioinicial     --Folio_Orden 
							,[ifp_folionuevo]    folionuevo       --Folio_Factura
							,5 tipoFolioNav
						FROM [cuentasxpagar].[dbo].[cxp_integracionfacpv]	
					   WHERE [ifp_folioanterior] = @folio
					   GROUP BY [ifp_folioanterior]
						       ,[ifp_folionuevo] 
                    END

		--Comenzamos salto hacia atras
		            -------------------------------------------------------
					--Tengo una Factura y se desglosa en N Remisiones
					--EXECUTE [dbo].[SEL_NAVEGACION_NODO_SP] 'AU-ZM-ZAR-RE-IF-8',3,2 
					-------------------------------------------------------
					IF (@tipoFolio = 3 AND  @tipoRegreso = 2)
					BEGIN
					    --SELECT 'ATRAS: Tengo una Factura y se desglosa en N Remisiones' Paso
						SELECT [ifr_folionuevo]   folioinicial   --Folio_Factura
							  ,[ifr_folioinicial] folionuevo     --Folio_Remision
							  ,2 tipoFolioNav
						  FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac]
						 WHERE [ifr_folionuevo]  = @folio        --Var_Factura
					  GROUP BY [ifr_folionuevo]
							  ,[ifr_folioinicial]
					END

					-------------------------------------------------------
					--Tengo una Remision y se desglosa en N Ordenes
					--EXECUTE [dbo].[SEL_NAVEGACION_NODO_SP] 'AU-ZM-ZAR-RE-PI-10',2,1
					-------------------------------------------------------
                    ELSE IF (@tipoFolio = 2 AND  @tipoRegreso = 1)
					BEGIN
					    --SELECT 'ATRAS: Tengo una Remision y se desglosa en N Ordenes' Paso
						SELECT  [irr_folionuevo]   folioinicial   --Folio_Remision 
							   ,[irr_folioinicial] folionuevo     --Folio_Orden
							   ,1 tipoFolioNav
						  FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac]
						 WHERE [irr_folionuevo] = @folio          --Var_Remision
						GROUP BY  [irr_folionuevo] 
							     ,[irr_folioinicial]
					END
					-------------------------------------------------------
					--Tengo una Factura y se desglosa en N Ordenes
					--EXECUTE [dbo].[SEL_NAVEGACION_NODO_SP] 'AU-ZM-ZAR-RE-IF-8',3,1
					-------------------------------------------------------
					ELSE IF (@tipoFolio = 3 AND  @tipoRegreso = 1)
					BEGIN
					    --SELECT 'ATRAS: Tengo una Factura y se desglosa en N Ordenes' Paso
						SELECT  [ifr_folionuevo]   folioinicial    --Folio_Factura
							   ,[irr_folionuevo]   folionuevo      --Folio_Remision 
							   ,2 tipoFolioNav
							   --,[irr_folioinicial]  ORDEN        --Folio_Orden 
						  FROM   [cuentasxpagar].[dbo].[cxp_integracionremrefac]
					    		,[cuentasxpagar].[dbo].[cxp_integracionfacrefac]
						 WHERE [irr_folionuevo] = [ifr_folioinicial] --Folio_Remision
						   AND [ifr_folionuevo] = @folio             --Var_Factura
						GROUP BY [ifr_folionuevo]
						        ,[irr_folionuevo]
								--,[irr_folioinicial]
                    END
					----*********************
					ELSE IF (@tipoFolio = 5 AND  @tipoRegreso = 1  AND @depto = 1)
					BEGIN
					    SELECT  [ifs_folionuevo]      folioinicial    --Folio_Factura
							   ,[ifs_folioanterior]   folionuevo      --Folio_Orden
							   ,1 tipoFolioNav
						  FROM [cuentasxpagar].[dbo].[cxp_integracionfacser]
						 WHERE [ifs_folionuevo] = @folio 
					  GROUP BY [ifs_folionuevo]
							  ,[ifs_folioanterior]
                    END
					----*********************
					ELSE IF (@tipoFolio = 5 AND  @tipoRegreso = 1  AND @depto = 2)
					BEGIN
                        SELECT [ifp_folionuevo]       folioinicial     --Folio_Orden 
							  ,[ifp_folioanterior]    folionuevo       --Folio_Factura
							  ,1 tipoFolioNav
						 FROM [cuentasxpagar].[dbo].[cxp_integracionfacpv]	
					    WHERE [ifp_folionuevo] = @folio
					    GROUP BY [ifp_folioanterior]
						       ,[ifp_folionuevo] 
                    END
	END TRY
	
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_NAVEGACION_NODO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

