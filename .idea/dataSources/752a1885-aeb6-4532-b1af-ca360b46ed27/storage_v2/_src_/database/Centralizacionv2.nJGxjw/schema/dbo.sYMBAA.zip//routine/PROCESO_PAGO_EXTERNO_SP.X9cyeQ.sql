--============================================================================================================--
-- PROCEDIMIENTO PAGO EXTERNO CIERRA NODOS EN CXP  
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 14/12/2018
-- Description:	Revisa OC que estan en Nodo 7 y avanza nodos si el documento no tiene saldo
--============================================================================================================--
-- EXECUTE [PROCESO_PAGO_EXTERNO_SP] @idEmpresa = 4
CREATE PROCEDURE [dbo].[PROCESO_PAGO_EXTERNO_SP] 
      @idEmpresa   INT = 0 
AS
BEGIN
    SET NOCOUNT ON;
		BEGIN TRY
			BEGIN TRANSACTION
				DECLARE @folio				VARCHAR(50) = ''
				DECLARE @nombre_base		VARCHAR(50) = ''
				DECLARE @queryFolios		NVARCHAR(MAX) = ''
				--DECLARE @ipLocal			VARCHAR(50) = ''
				--IP LOCAL
				--SELECT	@ipLocal = local_net_address
				--FROM	sys.dm_exec_connections
				--WHERE	Session_id = @@SPID;
				-----------------------------------------
				SELECT  @nombre_base = nombre_base
				FROM	Centralizacionv2.dbo.DIG_CAT_BASES_BPRO 
				WHERE	tipo = 2 
						AND emp_idempresa = @idEmpresa

				--ORDENES PARADAS EN EL NODO 7  (NO TERMINADAS NI CERRADAS)  --79,756
				DECLARE @tablaFoliosP TABLE  (  folio      VARCHAR(50) COLLATE Modern_Spanish_CI_AS, tipoOrden INT)
				SET @queryFolios = 'SELECT	 EN.[Folio_Operacion], OC.oce_idtipoorden
									FROM	[Centralizacionv2].[dbo].[DIG_EXPEDIENTE] AS E
									INNER JOIN [Centralizacionv2].[dbo].[DIG_EXP_NODO] AS EN ON E.Folio_Operacion = EN.Folio_Operacion
									INNER JOIN [cuentasxpagar].[DBO].[cxp_ordencompra] AS OC ON EN.[Folio_Operacion] = OC.[oce_folioorden] AND OC.[sod_idsituacionorden] IN (6,7,8,10,15) AND OC.[oce_idempresa] =  ' + CONVERT(VARCHAR(10), @idEmpresa	) + '
									INNER JOIN ' + @nombre_base + '.[dbo].[VIS_CONCAR01] AS VC	ON VC.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS = OC.[oce_folioorden]
									INNER JOIN ' + @nombre_base + '.[dbo].PNC_PARAMETR AS[A] ON VC.CCP_CARTERA = [A].PAR_IDENPARA AND[A].PAR_TIPOPARA = ''CARTERA'' AND[A].PAR_IDMODULO = ''CXP'' AND [A].PAR_IMPORTE5 < > 1
									INNER JOIN [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] AS ED ON ED.Folio_Operacion = OC.[oce_folioorden] AND Doc_Id = 15 AND Fecha_Creacion IS NOT NULL
									LEFT JOIN CUENTASXPAGAR.DBO.CXP_DETALLEAUTOSNUEVOS AS [ZZ] ON OC.OCE_FOLIOORDEN = [ZZ].OCE_FOLIOORDEN
									LEFT JOIN ' + @nombre_base + '.[dbo].SER_VEHICULO ON VC.CCP_OBSGEN = VEH_NUMSERIE COLLATE MODERN_SPANISH_CI_AS
									INNER JOIN CENTRALIZACIONV2.DBO.PPRO_DATOSFACTURAS ON VC.CCP_IDDOCTO = FOLIOORDEN COLLATE MODERN_SPANISH_CI_AS
									WHERE	EN.[Proc_Id] = 1 
									AND EN.[Folio_Operacion] IS NOT NULL 
									AND EN.[Folio_Operacion] <> ''''
									AND EN.[Nodo_Estatus_Id] = 2  
									AND EN.[Nodo_Id] = 7     
									AND E.Estatus_Id = 1
									AND OC.oce_idtipoorden <> 4 
									GROUP BY EN.[Folio_Operacion]
									,OC.[oce_idempresa]
									,OC.[sod_idsituacionorden]
									,OC.oce_idtipoorden
									HAVING	SUM(VC.CCP_ABONO) - SUM(VC.CCP_CARGO) = 0'
				INSERT INTO @tablaFoliosP
				EXECUTE (@queryFolios)
				--PRINT @queryFolios
				--SELECT * FROM @tablaFolios
				--------------------------------------------------------------
				--Se obtienen las IF son saldo 0 
				--------------------------------------------------------------
				DECLARE @tablaFoliosIF TABLE  (  folio      VARCHAR(50) COLLATE Modern_Spanish_CI_AS)
				INSERT	@tablaFoliosIF
				SELECT folio FROM @tablaFoliosP WHERE tipoOrden = 5
				--SELECT * FROM @tablaFoliosIF

				DECLARE @tablaFoliosDescartar TABLE  (  folio      VARCHAR(50) COLLATE Modern_Spanish_CI_AS)
				--------------------------------------------------------------
				--Se insertan las PE que pertenecen a una IF para poder descar dichas PE
				--------------------------------------------------------------
				INSERT	@tablaFoliosDescartar
				SELECT	ifr_folioinicial
				FROM	@tablaFoliosIF AS TIF
						INNER JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS I ON TIF.folio = I.ifr_folionuevo
				WHERE	I.ifr_folioinicial LIKE '%-PE-%'
				--------------------------------------------------------------
				--Se obtienen las PI
				--------------------------------------------------------------
				DECLARE @tablaFoliosPI TABLE  (  folio      VARCHAR(50) COLLATE Modern_Spanish_CI_AS)
				INSERT	@tablaFoliosPI

				SELECT	ifr_folioinicial
				FROM	@tablaFoliosIF AS TIF
						INNER JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS I ON TIF.folio = I.ifr_folionuevo
				WHERE	I.ifr_folioinicial LIKE '%-PI-%'
				--------------------------------------------------------------
				--Se insertan las PE que pertenecen a una PI para poder descar dichas PE
				--------------------------------------------------------------
				INSERT	@tablaFoliosDescartar
				SELECT	irr_folioinicial 
				FROM	@tablaFoliosPI AS TPI
						INNER JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS P ON P.irr_folionuevo = TPI.folio
				--------------------------------------------------------------
				--Se insertan las PE que pertenecen a una IF para poder descar dichas PE
				--------------------------------------------------------------
				INSERT	@tablaFoliosDescartar
				SELECT	ifs_folioanterior
				FROM	@tablaFoliosIF AS TIF
						INNER JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser] AS S ON TIF.folio = S.ifs_folionuevo
				--------------------------------------------------------------
				--Obtengo los Folios para avanzar nodos 
				--------------------------------------------------------------
				DECLARE @tablaFolios TABLE  (  folio      VARCHAR(50) COLLATE Modern_Spanish_CI_AS)
				INSERT INTO @tablaFolios
				SELECT folio FROM @tablaFoliosP WHERE folio NOT IN (SELECT  folio FROM @tablaFoliosDescartar) 
				--SELECT * FROM @tablaFolios
				-------------------------------------------------------------
				--INSERT BITACORA
				-------------------------------------------------------------
				INSERT INTO Centralizacionv2.dbo.BITACORA_PROCESOS
				SELECT 100,'INICIA PROC PAGO EXTERNO Folio: ' + folio, GETDATE() FROM @tablaFolios
				-------------------------------------------------------------
				--UPDATE CXP
				-------------------------------------------------------------
				UPDATE	cuentasxpagar.dbo.cxp_ordencompra
				SET		sod_idsituacionorden = 12
				WHERE		oce_folioorden IN (SELECT folio FROM @tablaFolios) 
				-------------------------------------------------------------
				--Inserta movimientos de orden de compra
				-------------------------------------------------------------				 
				INSERT INTO [cuentasxpagar].[dbo].[cxp_movimientosorden] (	[mov_idusuariomovimiento]
																			,[mov_fechamovimiento]
																			,[mov_horamovimiento]
																			,[oce_folioorden]
																			,[sod_idsituacionorden]) 
				SELECT	71
						,GETDATE()
						,GETDATE()
						,folio
						,12
				FROM	@tablaFolios
				--SELECT sod_idsituacionorden FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_folioorden  IN (SELECT folio FROM @tablaFolios)	
				-------------------------------------------------------------
				--UPDATE FECHA CREACION
				-------------------------------------------------------------														
				UPDATE	Centralizacionv2.dbo.DIG_EXPNODO_DOC 
				SET		Fecha_Creacion = GETDATE()
				WHERE		Folio_Operacion IN (SELECT folio FROM @tablaFolios)
				AND		Doc_Id IN (68,64)
				--SELECT Fecha_Creacion FROM Centralizacionv2.dbo.DIG_EXPNODO_DOC WHERE Folio_Operacion IN (SELECT folio FROM @tablaFolios) AND Doc_Id = 68
				----------------------------------------------------------------------------------------
				--Avanza nodos expedientes
				----------------------------------------------------------------------------------------
				DECLARE @nodoE INT = 7

				UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
				SET		FechaFin = GETDATE(), Nodo_Estatus_Id = 3
				WHERE	Folio_Operacion IN (SELECT folio FROM @tablaFolios) AND Nodo_Id = @nodoE

				UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
				SET		FechaInicio =  GETDATE(), FechaFin = GETDATE(), Nodo_Estatus_Id = 3
				WHERE	Folio_Operacion IN (SELECT folio FROM @tablaFolios) AND Nodo_Id BETWEEN @nodoE + 1 AND 14 -1

				UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
				SET		FechaInicio =  GETDATE(), Nodo_Estatus_Id = 2
				WHERE	Folio_Operacion IN (SELECT folio FROM @tablaFolios) AND Nodo_Id = 14


				INSERT INTO [Centralizacionv2].[dbo].[BITACORA_AVANZA_NODOS] (folio, descripcion,fecha)
				SELECT folio,'[dbo].[PROCESO_PAGO_EXTERNO_SP]', GETDATE() FROM @tablaFolios


			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			SELECT	ERROR_NUMBER() AS errNumber		
					,ERROR_SEVERITY() AS errSeverity 		
					,ERROR_STATE() AS errState		
					,ERROR_PROCEDURE() AS errProcedure		
					,ERROR_LINE() AS errLine		
					,ERROR_MESSAGE() AS errMessage
			ROLLBACK TRANSACTION
		END CATCH
	SET NOCOUNT OFF;
END
go

