-- =============================================
-- Author:		Genaro Mora Valencia
-- Create date: 20/11/2015
-- Description:	Procedimiento para guardar un movimiento en bitácora de Nodo. (DIG_EXPEDIENT_NODO_BITACORA)
-- =============================================
--Antes  [UPD_DIG_EXP_NODO_FECHA_SP] 1,7,'AU-ZM-ZAR-OT-PE-21',2

CREATE PROCEDURE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP]
	 @proc_Id	int
	,@nodo_Id	int
	,@folio_Operacion varchar(80)
	,@accion_Id int
	 
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
				
	IF(@accion_Id=1)
		BEGIN
			UPDATE DIG_EXP_NODO 
			 SET   FechaInicio = GETDATE()	
			       ,Nodo_Estatus_Id = @accion_Id + 1					 		   
			WHERE  Proc_Id=@proc_Id AND 
					Nodo_Id=@nodo_Id AND 
					Folio_Operacion=@folio_Operacion		
		 END
	 IF(@accion_Id=2)	
		BEGIN		   		
			UPDATE DIG_EXP_NODO 
			 SET   FechaFin = GETDATE(),
				   Nodo_Estatus_Id = @accion_Id + 1		   
			WHERE  Proc_Id=@proc_Id AND 
					Nodo_Id=@nodo_Id AND 
					Folio_Operacion=@folio_Operacion
			print 'lo hizo'
		END		  		  
				
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'UPD_DIG_EXP_NODO_FECHA_SP'
	SELECT @Mensaje = ERROR_MESSAGE() + '@proc_Id: ' + CONVERT(VARCHAR(20),@proc_Id) + '- @nodo_Id: ' + CONVERT(VARCHAR(20),@nodo_Id) + ' - @folio_Operacion: ' + CONVERT(VARCHAR(20),@folio_Operacion) + ' - @accion_Id: ' + CONVERT(VARCHAR(20),@accion_Id)
    EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END

go

