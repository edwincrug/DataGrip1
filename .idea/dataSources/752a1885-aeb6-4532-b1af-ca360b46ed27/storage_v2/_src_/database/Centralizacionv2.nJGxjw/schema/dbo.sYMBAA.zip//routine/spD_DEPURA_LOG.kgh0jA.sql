Create PROCEDURE [dbo].[spD_DEPURA_LOG](@sDatabaseName varchar(50),@iMegas int, @iError int OUTPUT) --with recompile
 AS
declare 
@sTransactionLogName varchar(500),
@iTamanioActual int, --está dado en MB
@sAuxTamanio varchar(50)
begin
	
drop  table #temp
create table #temp
(
  name varchar(100)
,fileid nvarchar(2)
,namefile varchar(200)
,groupfile varchar(100)
,sizeinkb nvarchar(50)
,mxsize nvarchar(600)
,crecimiento nvarchar(100)
,usage nvarchar(100)
)
insert into #temp 
exec sp_helpfile 

--obtenemos el nombre del dispositivo del log
select @sTransactionLogName = ''
--Select @sTransactionLogName = physical_name from sys.database_files where type=1 --contine toda la ruta completa y nombre y extension del archivo del dispositivo del log
Select @sTransactionLogName = name from sys.database_files where type=1


--obtenemos el tamaño actual del dispositivo del log de la bd. 5 605 504 KB = 5 GB
select @sAuxTamanio = sizeinkb from #temp where fileid='2' --solo del archivo log
print 'El tamanio actual del log ' + @sTransactionLogName + ' es: ' + @sAuxTamanio
select @sAuxTamanio = REPLACE(@sAuxTamanio,' KB','') --nos quedamos solo con la cantidad de KB

--El tamaño actual mayor a 1 Gyga y el tamaño deseado a truncar menor a 1 Gyga.
if ((Convert(int,@sAuxTamanio)>1000000) and (@iMegas<1000)) 
begin
	print 'Se truncará el archivo log: ' + @sTransactionLogName + ' a ' + Convert(char(10),@iMegas) + ' MegaBytes'
	if (@sTransactionLogName<>'')
	begin
		DBCC SHRINKFILE(@sTransactionLogName, @iMegas)
		--BACKUP LOG @sDatabaseName WITH TRUNCATE_ONLY
		BACKUP LOG @sDatabaseName TO DISK='NUL:'
		DBCC SHRINKFILE(@sTransactionLogName, @iMegas)		     
	end
end

select @iError=@@Error		
if (@iError=0)
	begin
		print 'El archivo log: ' + @sTransactionLogName + ' ha sido correctamente reducido a ' + Convert(char(10),@iMegas) + ' MegaBytes'
	end
end
/*
Declare 
@sDatabaseName varchar(50),
@iMegas int, 
@iError int

select @sDatabaseName='FACYCON'
select @iMegas = 1  --se debe reducir a x Megas 'NOTA esto solo lo hace si el tamaño actual del archivo log es mayor a 1 Gigabyte.
select @iError = 0  

--Hace el truncamiento del Log de transacciones siempre y cuando este sea mayor a 1 Gygabyte.

execute spD_DEPURA_LOG @sDatabaseName, @iMegas, @iError OUTPUT 
print Convert(char(10),@iError)

*/
go

