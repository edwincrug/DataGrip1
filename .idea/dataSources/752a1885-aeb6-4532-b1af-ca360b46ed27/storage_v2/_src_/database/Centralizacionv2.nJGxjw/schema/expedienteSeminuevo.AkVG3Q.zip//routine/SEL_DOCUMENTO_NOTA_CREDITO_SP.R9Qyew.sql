-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [expedienteSeminuevo].[SEL_DOCUMENTO_NOTA_CREDITO_SP] 'JM1BM1K31F1244253', 4, 6
-- Referencia cortada con varias notas de credito en prod AA13469
-- Referencia cortada con una nota de credito en prod AA40283
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_DOCUMENTO_NOTA_CREDITO_SP]
	@vin VARCHAR(150),
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN

	SET NOCOUNT ON;

    DECLARE @idFactura VARCHAR(100) = '', @facturaRecortada VARCHAR(100) = '', @base VARCHAR(100);
	DECLARE @query VARCHAR(MAX) = '';

	SELECT 
		@base = nombre_base 
	FROM DIG_CAT_BASES_BPRO 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal

	SELECT 
		 @idFactura = CUD.ucn_idFactura
	FROM [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES]  CUD
	INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSAL] CU ON CU.ucu_idcotizacion = CUD.ucu_idcotizacion 
	WHERE ucn_noserie = @vin AND ucu_idempresa = @idEmpresa AND ucu_idsucursal = @idSucursal AND ucu_tipocotizacion = 'SN'AND cec_idestatuscotiza IN (18, 20) --Estatus la cotizacion 18, 20 --- QUITAR EL 15 SOLO ES PARA PRUEBAS

	IF(@idFactura = '' OR @idFactura IS NULL)
		BEGIN
			SELECT success = 0 
			SELECT msg = 'Error el buscar los datos'
            RETURN
		END

	SET @facturaRecortada = (SELECT [expedienteSeminuevo].[SEL_REDUCCION_SERIE_FOLIO] (@idFactura));

	SET @query = 'SELECT' + CHAR(13) +
						CHAR(9) + 'PAM_IDDOCTO AS docto,' + CHAR(13) +
						CHAR(9) + 'SUBSTRING(PAM_IDDOCTO, 0, 3) AS serie,' + CHAR(13) +
						CHAR(9) + 'SUBSTRING(PAM_IDDOCTO, 3, LEN(PAM_IDDOCTO)) AS folio' + CHAR(13) +
						--'FROM [192.168.20.29].[' + @base + '].[DBO].[CXC_PAGANT] WHERE PAM_REFERENCIA = ''AA13469'''
						'FROM [' + @base + '].[DBO].[CXC_PAGANT] WHERE PAM_REFERENCIA = ''' + @facturaRecortada + '''' --QUITAR EL SERVIDOR Y QUITAR EN DURO LA FACUTARA RECORTADA

	DECLARE @tempTabla TABLE( docto VARCHAR(100), serie VARCHAR(5), folio VARCHAR(15) )

	INSERT INTO @tempTabla
	EXEC(@query)

	IF( (SELECT COUNT(docto) FROM @tempTabla) > 0 )
		BEGIN
			SELECT success = 1
			SELECT * FROM @tempTabla
		END
	ELSE
		BEGIN
			SELECT success = 0
			SELECT msg = 'No se encontraron datos'
		END
END
go

