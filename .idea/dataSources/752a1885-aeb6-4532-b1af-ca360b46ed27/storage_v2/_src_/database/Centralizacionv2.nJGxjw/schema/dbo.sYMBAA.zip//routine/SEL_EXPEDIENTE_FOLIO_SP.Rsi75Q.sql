-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 14/10/2015
-- Description:	Stored que recupera los datos de los documentos de un expediente por folio.
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EXPEDIENTE_FOLIO_SP]
	@id_folio varchar(18)
	,@id_proceso int
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
SELECT      DISTINCT E.Proc_Id
		, E.Folio_Operacion
		, E.Fecha_Inicio
		, E.Fecha_Fin
		, E.Estatus_Id
		, EN.Nodo_Id
		, N.Nodo_Nombre
		, N.Nodo_Descripcion
		, 0 as Alerta_Id
		, ED.Doc_Id
		, ND.Es_Mandatorio
		, CD.Doc_Nombre
		, CD.Doc_Descripcion
		, CD.Doc_Icono
		, CD.Doc_Origen
		, NP.Perfil_Id
		, PD.Consultar
		, PD.Imprimir
		, PD.Enviar_Email
		, PD.Descargar
		, PD.Cargar
	FROM     dbo.DIG_EXPEDIENTE AS E INNER JOIN
                         dbo.DIG_EXP_NODO AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion INNER JOIN
                         dbo.DIG_NODO AS N ON EN.Nodo_Id = N.Nodo_Id INNER JOIN
                         dbo.DIG_EXPNODO_DOC AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id INNER JOIN
                         dbo.DIG_NODO_DOC AS ND ON ED.Proc_Id = ND.Proc_Id AND ED.Nodo_Id = ND.Nodo_Id AND ED.Doc_Id = ND.Doc_Id INNER JOIN
                         dbo.DIG_CATDOCUMENTO AS CD ON ND.Doc_Id = CD.Doc_Id INNER JOIN
                         dbo.DIG_PERFIL_DOCUMENTO AS PD ON CD.Doc_Id = PD.Doc_Id LEFT OUTER JOIN
                         dbo.DIG_NODOPERFIL AS NP ON PD.Perfil_Id = NP.Perfil_Id AND E.Proc_Id = NP.Proc_Id
WHERE E.Folio_Operacion = @id_folio
OR E.Folio_Operacion IN ( 
				SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @id_folio
			  )
END TRY
  BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_EXPEDIENTE_FOLIO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

