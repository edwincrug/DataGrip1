
-------------------------------------------------------------------------------------------------------

-- EXECUTE [SEL_ORDENES_FILTROS_SP_pruebaVa] @idProceso=1 ,@folioorden = 'un',@idusuariosolicitante =2 ,@idempresa = 0,@idSucursal = 0,@iddepartamento = 0 --,  --AU-ZM-ZAR-RE-PE-133  --AU-ZM-ZAR-UN-31
CREATE PROCEDURE [dbo].[SEL_ORDENES_FILTROS_SP] --[dbo].[SEL_ORDENES_FILTROS_SP_pruebaVa] 
		 @iddepartamento int = 0
		,@iddivision int = 0
		,@idempresa int = 0
		,@idproveedor int = 0
		,@folioorden varchar(20) = ''
		,@idusuariosolicitante int = 0
		,@estatusorden int = 0
		,@fechaini datetime = null
		,@fechafin datetime = null
		,@idSucursal int = 0
		,@idTipoOrden int = -1
		,@idProceso   int=0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY   
        IF(@fechaini = @fechafin)
		BEGIN
		    SET @fechaini = @fechaini +' 00:00:00.000'
			SET @fechafin = @fechafin +' 23:59:59.000'
			--SELECT  @fechaini,@fechafin
		END
		IF(@fechaini IS NULL)
			SET @fechaini = '20000101'
		IF(@fechafin IS NULL)
			SET @fechafin = GETDATE()

IF(@idProceso = 1)
BEGIN
PRINT('1.-Comienza Proceso 1');
      SELECT     OC.oce_folioorden AS Folio_Operacion 
				, TIPOR.tip_nombre AS tipoorden--OC.oce_idtipoorden AS oce_idtipoorden --[dbo].[cat_tiposorden]
				, OC.oce_fechaorden AS oce_fechaorden
				, SITOR.sod_nombresituacion AS situacionOrden --OC.sod_idsituacionorden AS sod_idsituacionorden --[dbo].[cat_situacionorden]
				, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
				, EMP.emp_nombre AS empNombre   --[oce_idempresa]
				, SUC.suc_nombre AS sucursal --[oce_idsucursal]
				, DEP.[dep_nombre] AS depto --[oce_iddepartamento]
				, OC.oce_importetotal AS oce_importetotal
				,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
					  ELSE 0 END as esPlanta
				------ LMS Nodo Actual
				,(select TOP 1 D.Nodo_Id 
									  FROM [Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
									 WHERE D.Proc_Id         = DG.Proc_Id 
									  AND  D.Folio_Operacion = OC.oce_folioorden 
									  AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual       
				 --,@tipo AS tipofolio
				 ,CASE WHEN EXISTS (SELECT irr_folioinicial FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac] WHERE [irr_folioinicial] = OC.oce_folioorden) THEN
						1 
					   WHEN EXISTS(SELECT irr_folionuevo FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac] WHERE [irr_folionuevo] =  OC.oce_folioorden) THEN
						2
					   WHEN EXISTS(SELECT ifr_folionuevo FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac] WHERE [ifr_folionuevo] = OC.oce_folioorden) THEN
						3
					   ---
					   WHEN EXISTS(SELECT ifs_folionuevo 
									 FROM [cuentasxpagar].[dbo].[cxp_integracionfacser] 
									WHERE [ifs_folionuevo] = OC.oce_folioorden) THEN
						5
					   ---
					   ELSE 1
				   end AS tipofolio
				 ------ LMS
		FROM          
					--GA_Corporativa.dbo.PER_PERSONAS AS PER 
					[BDPersonas].[dbo].[cat_personas] AS PER
					LEFT JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
					LEFT JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
					LEFT JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
					LEFT JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
					LEFT JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
					LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
					LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
		WHERE
				(	oce_iddivision = @iddivision OR (@iddivision = 0 AND (	OC.oce_iddivision IN (	SELECT	DISTINCT div_iddivision 
																								FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																								WHERE	usu_idusuario = @idusuariosolicitante 
																										AND div_iddivision = (CASE WHEN @iddivision = 0 THEN  div_iddivision ELSE  @iddivision END)))))
				AND (	OC.oce_idempresa = @idempresa OR (@idempresa=0 AND (	OC.oce_idempresa IN (	SELECT	DISTINCT emp_idempresa 
																										FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																										WHERE	usu_idusuario = @idusuariosolicitante 
																												AND emp_idempresa = (CASE WHEN @idempresa = 0 THEN  emp_idempresa ELSE  @idempresa END)))))
				AND (	OC.oce_idsucursal = @idSucursal OR (@idSucursal=0 AND (OC.oce_idsucursal IN(	SELECT	DISTINCT suc_idsucursal 
																										FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																										WHERE	usu_idusuario = @idusuariosolicitante 
																												AND suc_idsucursal = (CASE WHEN @idSucursal = 0 THEN  suc_idsucursal ELSE  @idSucursal END)))))
				AND (	OC.oce_iddepartamento = @iddepartamento OR (@iddepartamento=0 AND (OC.oce_iddepartamento IN (	SELECT	DISTINCT dep_iddepartamento 
																														FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																														WHERE	usu_idusuario = @idusuariosolicitante 
																															AND dep_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN  dep_iddepartamento ELSE  @iddepartamento END)))))		
				AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
				AND ((@folioorden = '') OR (OC.oce_folioorden LIKE '%' + @folioorden + '%'))
				AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
				AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
END 
ELSE

IF(@idProceso = 2)
BEGIN
    PRINT('1.-Comienza Proceso 2');
    --==========================================================================================--
    -- BUSQUEDA EN LA BASE DE CADA SUCURSAL EL MONTO COTIZACION
    --==========================================================================================-- 
    
    DECLARE @aux               INT = 1
    DECLARE @max               INT = 0
    DECLARE @idEmpresaBusca    INT = 0
    DECLARE @nomBaseMatriz       NVARCHAR(50) =NULL
	DECLARE @nomBaseMatrizNuevo  NVARCHAR(50) =NULL
    DECLARE @nomBaseConcentra    NVARCHAR(50) =NULL
	
	DECLARE @selectCotNu         VARCHAR(max);
	DECLARE	@idSuc		     NVARCHAR(50) =NULL
	DECLARE	@nombreSucursal      NVARCHAR(50) =NULL
	DECLARE @nombreEmpresa       NVARCHAR(50) =NULL
	DECLARE	@idEmp	         NVARCHAR(50) =NULL
	--------------------------------------------------------------------------------------------------
	--Obtiene la ip local
	--------------------------------------------------------------------------------------------------
	DECLARE @ipLocal NVARCHAR(50)
	SELECT	@ipLocal = dec.local_net_address
	FROM	sys.dm_exec_connections AS dec
	WHERE	dec.session_id = @@SPID;
    --------------------------------------------------------------------------------------------------
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
							idSucursal nvarchar(30),
                            idEmpresa         nvarchar(30)
                            ,nombreEmpresa     nvarchar(100)
                            ,nomCtoEmpresa     nvarchar(5)
                            ,nomBaseConcentra  nvarchar(50)
							,nomBaseSucursal  nvarchar(50)
                            ,nomBaseMatriz     nvarchar(50)
                            ,ipServidor        nvarchar(20)
                            )

     -- SE HACE LA BUSQUEDA DE LAS EMPRESAS Y SUCURSALES DISPONIBLES CON EL NOMBRE Y DIRECCIÓN IP DONDE SE ENCUENTRAN
     INSERT INTO @Bases
	   	SELECT 
				sucursales.suc_idsucursal
				,EMP.emp_idempresa
                ,EMP.emp_nombre
                ,EMP.emp_nombrecto
                ,BASEMP.nombre_base
				,BASEMP.nombre_sucursal
                ,ISNULL(BASEMP.nombre_base_matriz,BASEMP.nombre_base)
                ,BASEMP.ip_servidor 
           FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
                INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				inner join [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
          WHERE  BASEMP.estatus = 1 AND BASEMP.tipo = 1 and sucursales.emp_idempresa= EMP.emp_idempresa AND BASEMP.nombre_sucursal != 'CRA Guadalajara'
       ORDER BY sucursales.suc_idsucursal
     --SELECT * FROM @Bases
     SET @max = (SELECT MAX(IDB) FROM @Bases)
     WHILE(@aux <= @max)
     BEGIN
         
         SELECT  @idEmpresaBusca   = DB.idEmpresa 
				,@idEmp        = DB.idEmpresa
                ,@nomBaseConcentra = DB.nomBaseConcentra
                ,@nomBaseMatriz    = DB.nomBaseMatriz
				,@idSuc       = DB.idSucursal
				,@nombreSucursal   = DB.nomBaseSucursal
				,@nombreEmpresa    = DB.nombreEmpresa
           FROM @Bases AS DB 
          WHERE DB.IDB = @aux
		  
		 SELECT 
		   @nomBaseMatrizNuevo   =  (CASE WHEN @ipLocal = DB.ipServidor THEN '['+DB.nomBaseMatriz+'].[dbo]' ELSE '['+DB.ipServidor+'].['+DB.nomBaseMatriz+'].[dbo]' END)
		   FROM @Bases AS DB 
          WHERE DB.IDB = @aux --and DB.idEmpresa != 2--DB.idEmpresa = @aux 

	     DECLARE @todo TABLE  ( IDB            INT IDENTITY(1,1),
								idDocumento   nvarchar(MAX)
								,saldo        numeric(18,2)
								)
		  
			--Unidades Nuevas| Semi Nuevas
				SET @selectCotNu = 
				'SELECT  ' + char(13) + 
					'cotizacion.ucu_foliocotizacion AS idDocumento' + char(13) + 
					',(SELECT ' + char(13) + 
					'	TOTALVTA = ISNULL(SUM(CUU.ucn_total), 0)' + char(13) + 
					--'	,TOTALOtrosConceptos = ISNULL(SUM((CASE WHEN (CU.ucu_tipocotizacion = '+char(39)+'SN'+char(39)+') THEN ISNULL(SNPS.PS_VENTA, 0) ELSE ISNULL(NUPS.PS_VENTA, 0) END) + ISNULL(TG.Importe, 0) + ISNULL(Refa.Refa_TOTAL, 0) + ISNULL(Otros_TOTAL, 0)), 0)' + char(13) + 
					'FROM 	cuentasporcobrar..uni_cotizacionuniversalunidades CUU' + char(13) + 
					'	INNER JOIN cuentasporcobrar..UNI_CotizacionUniversal CU ON CU.ucu_idcotizacion = CUU.ucu_idcotizacion' + char(13) + 
					'	LEFT JOIN		(SELECT' + char(13) + 
					'				CUU.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(PS.PQE_MOVENTA + PS.PQE_REVENTA + PS.PQE_TTVENTA) AS PS_VENTA' + char(13) + 
					'				,SUM(PS.PQE_MOCOSTO + PS.PQE_RECOSTO + PS.PQE_TTCOSTO) AS PS_COSTO' + char(13) + 
					'			FROM ' + char(13) + 
					'				cuentasporcobrar..UNI_CotizacionUniversalUnidades CUU' + char(13) + 
					'					INNER JOIN ' + char(13) + 
					'						'+ @nomBaseMatrizNuevo  +'.SER_PQVEHICULO PV ON PV.PQV_IDCATALOGO = CUU.ucn_idcatalogo COLLATE Modern_Spanish_CI_AS AND PV.PQV_MODELO = CUU.ucn_modelo COLLATE Modern_Spanish_CI_AS' + char(13) + 
					'					INNER JOIN ' + char(13) + 
					'						'+ @nomBaseMatrizNuevo  +'.SER_PAQUESER PS ON PS.PQE_IDPAQUETE = PV.PQV_IDPAQUETE' + char(13) + 
					'			WHERE ' + char(13) + 
					'				EXISTS' + char(13) + 
					'					(' + char(13) + 
					'						SELECT ' + char(13) + 
					'							ucn_idcotizadetalle, ' + char(13) + 
					'							upo_idpaquete ' + char(13) + 
					'						FROM ' + char(13) + 
					'							cuentasporcobrar..uni_preordenser POS ' + char(13) + 
					'						WHERE ' + char(13) + 
					'								(POS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle) ' + char(13) + 
					'							AND (POS.upo_idpaquete = PS.PQE_IDPAQUETE)' + char(13) + 
					'							AND (POS.upo_estatus = 1)' + char(13) + 
					'					)' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				CUU.ucn_idcotizadetalle' + char(13) + 
					'		) NUPS ON NUPS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(' + char(13) + 
					'			SELECT' + char(13) + 
					'				POS.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(PS.PQE_MOVENTA + PS.PQE_REVENTA + PS.PQE_TTVENTA) AS PS_VENTA' + char(13) + 
					'				,SUM(PS.PQE_MOCOSTO + PS.PQE_RECOSTO + PS.PQE_TTCOSTO) AS PS_COSTO' + char(13) + 
					'			FROM' + char(13) + 
					'				cuentasporcobrar..uni_preordenser POS' + char(13) + 
					'					INNER JOIN '+ @nomBaseMatrizNuevo  +'.SER_PAQUESER PS ON (PS.PQE_IDPAQUETE = POS.upo_idpaquete) AND (POS.upo_estatus = 1) AND (PS.PQE_IDPAQUETE LIKE '+char(39)+'SEMI%'+char(39)+')' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				POS.ucn_idcotizadetalle' + char(13) + 
					'		) SNPS ON SNPS.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(' + char(13) + 
					'			SELECT ' + char(13) + 
					'				aw.ucn_idcotizadetalle' + char(13) + 
					'				,SUM([uaw_importe]) AS Importe' + char(13) + 
					'			FROM ' + char(13) + 
					'				cuentasporcobrar.[dbo].[uni_anticiposweb] aw' + char(13) + 
					'			WHERE ' + char(13) + 
					'				(aw.uaw_estatus = 1)' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				aw.ucn_idcotizadetalle' + char(13) + 
					'		) TG ON TG.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(' + char(13) + 
					'			SELECT ' + char(13) + 
					'				PMD.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(PMD.pmd_total) AS Refa_TOTAL' + char(13) + 
					'			FROM ' + char(13) + 
					'				'+ @nomBaseMatrizNuevo  +'.par_pedmostdet PMD' + char(13) + 
					'			WHERE ' + char(13) + 
					'				PMD.pmd_estatus = 1' + char(13) + 
					'			GROUP BY' + char(13) + 
					'				PMD.ucn_idcotizadetalle' + char(13) + 
					'		) Refa ON Refa.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'	LEFT JOIN' + char(13) + 
					'		(' + char(13) + 
					'			SELECT ' + char(13) + 
					'				OCD.ucn_idcotizadetalle' + char(13) + 
					'				,SUM(OCD.ucd_cantidad * OCD.ucd_preciounitario) AS Otros_TOTAL' + char(13) + 
					'			FROM ' + char(13) + 
					'				cuentasporcobrar..uni_otroconceptosdet OCD' + char(13) + 
					'			WHERE ' + char(13) + 
					'				OCD.ucd_estatus = 1' + char(13) + 
					'			GROUP BY ' + char(13) + 
					'				OCD.ucn_idcotizadetalle' + char(13) + 
					'		) Otros ON Otros.ucn_idcotizadetalle = CUU.ucn_idcotizadetalle' + char(13) + 
					'WHERE ' + char(13) + 
					'	CUU.ucu_idcotizacion =  cotizacion.ucu_idcotizacion ) as saldo' + char(13) + ''+ 
			   'FROM cuentasporcobrar.dbo.uni_cotizacionuniversal cotizacion  ' + char(13) + 
					'INNER JOIN  BDPersonas.dbo.cat_personas personas ON personas.per_idpersona = cotizacion.ucu_idcliente ' + char(13) +
					'INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = cotizacion.ucu_idempresa' + char(13) + 
					'INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = cotizacion.ucu_idsucursal' + char(13) + 
					'INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] departamentos  ON departamentos.dep_iddepartamento = cotizacion.ucu_iddepartamento  ' + char(13) + 
					'WHERE ucu_estatus != 14'+
					''        
         SET @aux = @aux + 1
		 print @selectCotNu
     END
	 INSERT INTO @todo EXECUTE (@selectCotNu)
	 --SELECT * FROM @todo --WHERE idDocumento = @idDocumento  
	--==========================================================================================--
    -- FIN BUSCA MONTO COTIZACION
    --==========================================================================================--
    
	PRINT('2.-Termino Insert @todo');
	SELECT  E.Folio_Operacion    AS Folio_Operacion
	        ,'N/A'               AS tipoorden
			,O.ucu_fechacotiza   AS oce_fechaorden
			,(SELECT ST.cec_nombre
				FROM cuentasporcobrar.dbo.cat_estatuscotiza as ST
			   WHERE ST.cec_idestatuscotiza = O.cec_idestatuscotiza)           AS situacionOrden 
			,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
                FROM BDPersonas.dbo.cat_personas AS PER 
               WHERE PER.per_idpersona = O.ucu_idcliente) AS Proveedor   --NombreCliente
	        ,EM.emp_nombre     AS empNombre
	        ,S.suc_nombre      AS sucursal
			,D.dep_nombre      AS depto
			--,350000.00  AS oce_importetotal
			,Saldo.saldo  AS oce_importetotal
			,O.ucu_idcliente   AS esPlanta            --idCliente para CXC
			,1                 AS nodoactual          --NodoAcutal
		    ,1                 AS tipofolio
	  FROM  dbo.DIG_EXPEDIENTE AS E 
			INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
			INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
			INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
			INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
			INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
			INNER JOIN @todo AS Saldo ON Saldo.idDocumento = E.Folio_Operacion
     WHERE   (O.ucu_iddepartamento = @iddepartamento 
						OR (O.ucu_iddepartamento IN(select distinct dep_iddepartamento from ControlAplicaciones.dbo.OPE_ORGANIGRAMA where usu_idusuario = @idusuariosolicitante 
						AND ((emp_idempresa = @idempresa) OR(@idempresa = 0)) AND((suc_idsucursal = @idSucursal)OR (@idSucursal = 0)))))
			AND ((O.ucu_idsucursal = @idSucursal) 
						OR (O.ucu_idsucursal IN(select distinct suc_idsucursal from ControlAplicaciones.dbo.OPE_ORGANIGRAMA  where usu_idusuario = @idusuariosolicitante 
						AND (emp_idempresa = @idempresa) OR(@idempresa = 0))))
			AND ((O.ucu_idempresa = @idempresa) 
						OR (O.ucu_idempresa in(select distinct emp_idempresa from ControlAplicaciones.dbo.OPE_ORGANIGRAMA where usu_idusuario = @idusuariosolicitante)) )
			AND ((@idproveedor = 0) OR (O.ucu_idcliente = @idproveedor))
			AND E.Folio_Operacion  LIKE '%' + @folioorden + '%' 
			AND (O.ucu_fechacotiza BETWEEN @fechaini AND @fechafin)
	
PRINT('3.-Fin');	 	        
END
        


END TRY
  BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_ORDENES_FILTROS_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END

go

