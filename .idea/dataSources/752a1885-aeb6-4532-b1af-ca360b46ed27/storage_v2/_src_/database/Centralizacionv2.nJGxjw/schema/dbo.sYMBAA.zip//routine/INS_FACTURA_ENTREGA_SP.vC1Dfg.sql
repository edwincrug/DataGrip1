-- ==========================================================================================
-- Author:		Alejandro Lopez Quiroz
-- Create date: 10/02/2016
-- Modified date: 08/06/2016 LMS  Mando a llamar al sp [UPD_APROBACION_SP]
-- Description: Inserta la factura de entrega
-- ==========================================================================================
--EXECUTE [INS_FACTURA_ENTREGA_SP] 'AU-AA-AAZ-OT-PE-189', 71,1,0   --OPC 1: Coincide OPC 2:No coincide
CREATE PROCEDURE [dbo].[INS_FACTURA_ENTREGA_SP]
	 @folio VARCHAR(50) = ''
	,@idperfil     INT = 1
	,@opcion       INT = 0
	,@idAprobacion INT = 0--No se esta utilizando viene como 0
AS
BEGIN

	--LQMA 11052017
	INSERT INTO BITACORA_PROCESOS
	VALUES (4,'Inicia INS_FACTURA_ENTREGA_SP : ' + @folio + ' -- @opcion: ' + CONVERT(VARCHAR(5),@opcion),GETDATE())

	SET XACT_ABORT ON;

	BEGIN TRANSACTION TRAN_FACTURA_ENTREGA
	--Contexto de transacción en uso por otra sesión
	--[SP_INSERTA_UUID_XML] utiliza otro servidor, se necesita linkear

	BEGIN TRY
	
							DECLARE @iResultadoOut INT = -1
							DECLARE @resulatdoSP varchar(5)

							----------------------------------------------------------------------
							-- Determino Tipo de Proceso   --AU-ZM-ZAR-UN-TPP-24
							----------------------------------------------------------------------
							DECLARE @idProceso      INT=0;
							DECLARE @folioPlanPiso  nvarchar(50)

							SELECT @idProceso = E.Proc_Id        
							  FROM dbo.DIG_EXPEDIENTE AS E 
							 WHERE E.Folio_Operacion = @folio

							----------------------------------------------------------------------
							-- Determino si es una orden Padre, busco la orden Hijo
							----------------------------------------------------------------------
							SELECT @folioPlanPiso = Folio_Alias  
							  FROM dbo.DIG_EXP_PLAN_PISO 
							 WHERE Folio_Operacion = @folio
							PRINT('PLAN PISO:'+ @folioPlanPiso);

							IF EXISTS (SELECT Folio_Alias  
										  FROM dbo.DIG_EXP_PLAN_PISO 
										 WHERE Folio_Operacion = @folio)
							BEGIN
								SET @folio = @folioPlanPiso
							END
							PRINT('FINAL:'+ @folio);

							IF(@opcion = 1) --Si coincide
								BEGIN
								   --Agregado LMS
								   --Si es 0 hubo error y se deja la pantalla como estaba y se notifica al usuario que la
								   --'El importe de la factura es diferente al de la Orden de Compra' lo dejo en la misma pantalla
								   --Si es 1 se queda como esta 
								   INSERT INTO BITACORA_PROCESOS
								   VALUES (4,'Factura coincide, spC_REVISA_DOCUMENTACIONCOMPLETA : SP_INSERTA_UUID_XML :' + @folio,GETDATE())

								   EXECUTE @iResultadoOut = [SP_INSERTA_UUID_XML] @folio
									PRINT @iResultadoOut
								   --------------------------------------------------
								   ---LBONNET 20062017 									
									--DECLARE
									--@iProc_Id INT = 1,			
									--@iNodo_Hasta INT = 7,
									--@iResultado INT = -1

									--INSERT INTO BITACORA_PROCESOS
									--VALUES (4,'Inicia spC_REVISA_DOCUMENTACIONCOMPLETA : ' + @folio,GETDATE())
			
									--EXECUTE spC_REVISA_DOCUMENTACIONCOMPLETA @iProc_Id,@folio, @iNodo_Hasta,@iResultado OUTPUT
									
									--INSERT INTO BITACORA_PROCESOS
									--VALUES (4,'Termino spC_REVISA_DOCUMENTACIONCOMPLETA : ' + @folio + ': resultado @iResultado : ' + Convert(char(20),@iResultado),GETDATE()) 
			
									--print 'Resultado afuera ' + Convert(char(20),@iResultado)								   
								   ----------------------------------------
								   --------------------------------------------------------------------------
								   --Modificación 11-10-2017 LGV
								   --------------------------------------------------------------------------
								   --Verifico si en [SP_INSERTA_UUID_XML] coincidieron los montos
								   IF(@iResultadoOut = 0)
										BEGIN 
											SELECT @iResultadoOut
										END
								   ELSE
										BEGIN 
			
										 --Verifico si el expediente tiene todos los documentos mandatorios 
										IF(EXISTS(	SELECT	1
													FROM	[Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] EXPDOC
															INNER JOIN [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] CATDOC ON EXPDOC.Doc_Id = CATDOC.Doc_Id
															INNER JOIN [Centralizacionv2].[dbo].[DIG_NODO_DOC] ND ON ND.Proc_Id = EXPDOC.Proc_Id AND ND.Nodo_Id = EXPDOC.[Nodo_Id] AND EXPDOC.[Doc_Id] = ND.[Doc_Id]
															INNER JOIN [Centralizacionv2].[dbo].[DIG_EXPEDIENTE] E ON E.Folio_Operacion = EXPDOC.Folio_Operacion
													WHERE	EXPDOC.[Folio_Operacion] = @folio AND Es_Mandatorio = 1 AND Fecha_Creacion IS NULL AND E.Estatus_Id !=2 and ND.Nodo_Id<=7))
											BEGIN
												DECLARE @respuesta INT 
												EXECUTE @respuesta = [SEL_PERMISOS_SIN_FACTURA] @folio
												IF(@respuesta = 1)
													BEGIN
														IF EXISTS(SELECT 1 FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_folioorden = @folio AND sod_idsituacionorden <> 10)
															BEGIN
																UPDATE [cuentasxpagar].[dbo].[cxp_ordencompra] SET sod_idsituacionorden = 10 where oce_folioorden = @folio 
																INSERT INTO [cuentasxpagar].[dbo].[cxp_movimientosorden] (mov_idusuariomovimiento,mov_fechamovimiento,mov_horamovimiento,oce_folioorden,sod_idsituacionorden)
																VALUES(@idperfil,getdate(),getdate(),@folio,10)
																INSERT INTO BITACORA_PROCESOS
																VALUES (4,'Documentos Completos : ' + @folio + ': resultado  : 1',GETDATE()) 
																--Modificacion
																UPDATE PPRO_DATOSFACTURAS SET estatus = 2 WHERE folioorden = @folio
																--
																PRINT 'La Factura Coincide'
																SELECT @iResultadoOut 
															END
													END
												ELSE	
													BEGIN
														INSERT INTO BITACORA_PROCESOS
														VALUES (4,'Documentos Incompletos : ' + @folio + ': resultado  : 0',GETDATE())
														SET @iResultadoOut = 0
														SELECT @iResultadoOut 
													END												
											END
										ELSE 
											BEGIN
												IF EXISTS(SELECT 1 FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_folioorden = @folio AND sod_idsituacionorden <> 10)
													BEGIN
														UPDATE [cuentasxpagar].[dbo].[cxp_ordencompra] SET sod_idsituacionorden = 10 where oce_folioorden = @folio 
														INSERT INTO [cuentasxpagar].[dbo].[cxp_movimientosorden] (mov_idusuariomovimiento,mov_fechamovimiento,mov_horamovimiento,oce_folioorden,sod_idsituacionorden)
														VALUES(@idperfil,getdate(),getdate(),@folio,10)
														INSERT INTO BITACORA_PROCESOS
														VALUES (4,'Documentos Completos : ' + @folio + ': resultado  : 1',GETDATE()) 
														--Modificacion
														UPDATE PPRO_DATOSFACTURAS SET estatus = 2 WHERE folioorden = @folio
														--
														PRINT 'La Factura Coincide'
														SELECT @iResultadoOut 
													END
												ELSE
													BEGIN
														SELECT @iResultadoOut = 0
													END											
											END

										END
								  
									-------------------------------------------------------------------------
									--
									-------------------------------------------------------------------------
		   
								   --print 'La Factura Coincide' 
								   --SELECT @iResultadoOut  
		   
								END
							ELSE		----No coincide 
								BEGIN

									INSERT INTO BITACORA_PROCESOS
									VALUES (4,'Factura no coincide INS_FACTURA_ENTREGA_SP : ' + @folio ,GETDATE())
								  --select 10
									--Al ejecutar este SP pone las Fecha_Creacion en Null por eso aparece como si no existiera la factura
									--Regresa 1 si se pudo hacer la desvinculacion de la factura.
									--Regresa 0 si hubo un error al hacer la desvinculacion de la factura.
									--EXECUTE [spU_DESVINCULA_FACTURA] @iProc_Id = 1, @sFolio_Operacion = @folio, @iResultado = @iResultadoOut OUTPUT
									EXECUTE @iResultadoOut = [spU_DESVINCULA_FACTURA] @iProc_Id = 1, @sFolio_Operacion = @folio ,@iResultado = 0
									print 'La Factura No Coincide' 
									SELECT @iResultadoOut 
									--print @iResultadoOut
								END
		
							--LMS  Mando a llamar al sp [UPD_APROBACION_SP] @idAprobacion,@respuesta,@observacion
							--EXECUTE [Notificacion].[dbo].[UPD_APROBACION_SP] @idAprobacion, 1, 'Factura Validada'		
							COMMIT TRANSACTION TRAN_FACTURA_ENTREGA
	END TRY
	BEGIN CATCH

		ROLLBACK TRANSACTION TRAN_FACTURA_ENTREGA			

		DECLARE @Mensaje  nvarchar(max)		
		SELECT @Mensaje = ERROR_MESSAGE() + ' @folio : ' + @folio
		
		INSERT INTO BITACORA_PROCESOS
		VALUES (4,'Error CATCH INS_FACTURA_ENTREGA_SP : ' + @Mensaje,GETDATE())

		DECLARE @resp TABLE (id INT IDENTITY(1,1), respuesta INT)		
		INSERT INTO @resp	
		EXECUTE INS_ERROR_SP 'INS_FACTURA_ENTREGA_SP', @Mensaje
		
		SELECT  ERROR_NUMBER() 

	END CATCH  

END
go

