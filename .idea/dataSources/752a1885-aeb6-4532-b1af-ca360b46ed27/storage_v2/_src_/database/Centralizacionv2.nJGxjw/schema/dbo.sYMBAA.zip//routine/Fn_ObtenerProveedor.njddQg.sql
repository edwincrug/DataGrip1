
--select * from fn_ObtenerProveedor(312483,4)
CREATE FUNCTION [dbo].[Fn_ObtenerProveedor]
(    
      @IdProveedor NVARCHAR(MAX),
      @IdEmpresa INT
)
RETURNS @Output TABLE (
      per_idpersona NVARCHAR(1000)
	  ,persona		NVARCHAR(500)
)
AS
BEGIN
	DECLARE @server NVARCHAR(1000)
			,@sql NVARCHAR(1000)

	SELECT @server = ip_servidor  
	FROM	[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
	WHERE	tipo  = 2 
	AND		emp_idempresa = @IdEmpresa

	--IF(@server = '192.168.20.29')
	--BEGIN
		INSERT INTO @Output
		SELECT	distinct PER_IDPERSONA
				,RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno])) Persona 
		FROM GA_Corporativa.dbo.PER_PERSONAS PER
		WHERE PER_IDPERSONA = @IdProveedor
	
	--END
	--ELSE
	--BEGIN
	--	INSERT INTO @Output
	--	SELECT	PER_IDPERSONA
	--			,RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno])) Persona 
	--	FROM [192.168.20.31].GA_Corporativa.dbo.PER_PERSONAS PER
	--	WHERE PER_IDPERSONA = @IdProveedor
	
	--END

    RETURN
END



go

