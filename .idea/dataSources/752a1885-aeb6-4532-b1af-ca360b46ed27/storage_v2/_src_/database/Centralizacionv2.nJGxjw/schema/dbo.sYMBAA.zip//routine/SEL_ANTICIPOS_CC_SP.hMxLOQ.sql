
-- [dbo].[SEL_ANTICIPOS_CC_SP] 10914
CREATE PROCEDURE [dbo].[SEL_ANTICIPOS_CC_SP]
	 @idCotizacion   VARCHAR(50)
AS
BEGIN
		SET NOCOUNT ON;
	DECLARE @folio VARCHAR(50) = ''
	DECLARE @idEmpresa      INT = 0;
	DECLARE @idSucursal     INT = 0;
	DECLARE @rfc            VARCHAR(30) = 0;
	DECLARE @nomBaseMatriz  VARCHAR(30) = 0;
	DECLARE @query          NVARCHAR(MAX) = null

	DECLARE @ipServidor        NVARCHAR(100);
	DECLARE @cadIpServidor     NVARCHAR(200);
	DECLARE @baseCC	NVARCHAR(300)
	---------------------------------------------------------------
	--  Obtenemos la consulta dinamicamente                      --
	---------------------------------------------------------------
	DECLARE @VariableTabla TABLE (	id				INT IDENTITY(1,1)
									,PAM_IDDOCTO	nvarchar(30)
									,anio	        nvarchar(10)
									,ipServidor	    nvarchar(200)
								  )
	
	DECLARE @Sucursales TABLE(id INT IDENTITY(1,1)
							  , nombre VARCHAR(50)
							  , ipServidor VARCHAR(20)
							  )   	
	---------------------------------------------------------------
	--Obtengo la informacion de la cotizacion 
	---------------------------------------------------------------
	--SELECT * FROM cuentasporcobrar.dbo.uni_cotizacionuniversal WHERE ucu_foliocotizacion = 'AU-AU-UNI-UN-2102'
	SELECT	@folio  = ucu_foliocotizacion 
		    ,@idEmpresa    = ucu_idempresa
			,@idSucursal   = ucu_idsucursal
	FROM	[cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
	WHERE	ucu_idcotizacion = @idCotizacion	
	--SELECT	@idCotizacion  = ucu_idcotizacion 
	--	    ,@idEmpresa    = ucu_idempresa
	--		,@idSucursal   = ucu_idsucursal
	--FROM	[cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
	--WHERE	ucu_foliocotizacion = @folio

	SELECT	@rfc = rfc
			,@nomBaseMatriz = nombre_base_matriz
			,@ipServidor = ip_servidor
	FROM	Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
	WHERE	catsuc_nombrecto = 'CONCENTRA'
			AND emp_idempresa    = @idEmpresa
    
	INSERT INTO @Sucursales
	SELECT nombre_base, ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE tipo = 1 AND emp_idempresa = @idEmpresa
	SELECT @baseCC = '['+ nombre_base + '].[dbo].' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE tipo = 1 AND emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal
	--SELECT @baseCC

    SET @cadIpServidor = '[' + @ipServidor + '].'

	DECLARE @aux INT = 1, @max INT = 0
	SELECT @max = MAX(id) FROM @Sucursales

	WHILE @aux <= @max 
		BEGIN

			SELECT @cadIpServidor = ipServidor, @nomBaseMatriz =nombre FROM @Sucursales WHERE id = @aux

			SET @query =	'SELECT P.PAM_IDDOCTO ' + 
							',V.Vcc_Anno' +
							',''[' + @nomBaseMatriz +'].dbo.'' ' +
							'FROM [' + @nomBaseMatriz +'].dbo.CXC_PAGANT P ' +
							'INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal U ON P.PAM_IDCOTIZACIONWEB = U.ucu_idcotizacion ' +
							'INNER JOIN [' + @nomBaseMatriz +'].dbo.VIS_CONCAR01 V ON V.CCP_IDDOCTO = P.PAM_IDDOCTO ' +					  
							'WHERE u.ucu_foliocotizacion = ''' + @folio + ''' AND PAM_TIPODOCTO = ''ANT''' +
							'GROUP BY V.Vcc_Anno,P.PAM_IDDOCTO'				
			print @query
									
			INSERT INTO  @VariableTabla
			EXECUTE (@query);
			SET @aux =  @aux + 1
		END
	DECLARE @aux2 INT = 1, @max2 INT = 0, @idDocto VARCHAR(50), @anio VARCHAR(10), @ipBd VARCHAR(200)
	SELECT @max2 = MAX(id) FROM @VariableTabla
	DECLARE @Respuesta TABLE (	PAM_IDDOCTO		nvarchar(MAX)
								,saldo			numeric(18,2)
								,tipo			nvarchar(50)
								,cargo			numeric(18,2)
								  )
	WHILE @aux2 <= @max2 
		BEGIN
			 SELECT @idDocto = PAM_IDDOCTO, @anio = anio, @ipBd = ipServidor FROM @VariableTabla WHERE id = @aux2
			 --SELECT @idDocto, @anio, @ipBd
			 SET @query =   'SELECT	MOV_IDDOCTO ' +
							'		,SUM(MOV_HABER)-SUM(MOV_DEBE)' +
							'		,''Anticipo'' '+
							'		,SUM(MOV_HABER)' +
							'FROM	' + @ipBd + 'con_movdet01' + @anio + ' ' +
							'WHERE	MOV_IDDOCTO = ''' + @idDocto + ''' '+
							'		AND MOV_TIPODOCTO IN (''ANT'', ''ANAP'') '+
							'GROUP BY MOV_IDDOCTO ' 
			 print (@query)
			 INSERT INTO @Respuesta
			 EXECUTE (@query)
			 SET @aux2 = @aux2 +1 
		END

		
		SET @query = 'SELECT	[PAR_DESCRIP1] as Cartera  ' +
								',[ucc_monto] as Monto  ' +
								','''' ' +
								',[ucc_monto]'+
						'FROM	cuentasporcobrar.dbo.[uni_ccs] ' +
								'LEFT JOIN  ' + @baseCC + 'PNC_PARAMETR PM on ucc_cartera = PM.PAR_IDENPARA  AND PM.PAR_TIPOPARA=''COCOCXC'' '+
						'WHERE	ucc_idcc in (SELECT ucc_idcc FROM cuentasporcobrar.dbo.[uni_ccs] WHERE ucu_idcotizacion = '+@idCotizacion+' AND UCC_ESTATUS = 1)' 

		PRINT (@query)
		INSERT INTO @Respuesta
		EXECUTE (@query)
		SET @query =	'SELECT  PAM_DOCAFECTADO  ' +
						'		,PAM_IMPORTEMON ' +
						'		,''Recibo de Caja'' ' +
						'		,PAM_IMPORTEMON ' +
						'FROM  	' + @baseCC + 'CXC_PAGANT P ' +						
						'		INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversalunidades U ON P.PAM_DOCAFECTADO = U.ucn_idFactura AND U.ucn_idFactura <> '''' ' +
						'		INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal UE ON U.ucu_idcotizacion = UE.ucu_idcotizacion ' +
						'		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] E ON E.emp_idempresa = UE.ucu_idempresa ' +
						'		INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] PP ON PP.PER_IDPERSONA = P.PAM_IDPERSONA ' +
						'WHERE	UE.ucu_idcotizacion = ' + @idCotizacion + '  ' 
		PRINT @query
		INSERT INTO @Respuesta
		EXECUTE (@query) 
		SET @query =	'SELECT		CCP_IDDOCTO, ' +
						'		''SALDO'' = CCP_ABONO-CCP_CARGO+ ' +
						'		(SELECT ISNULL(SUM(CCP_ABONO-CCP_CARGO),0) ' +
						'		 FROM	' + @baseCC + 'VIS_CONCAR01 as MOVIMIENTO      ' +
						'		 WHERE	MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO  ' +
						'				AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA  ' +
						'				AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA  ' +
						'				AND MOVIMIENTO.CCP_DOCORI<>''S'' ' +
						'		)     ' +
						'		,''Anticipo'' ' +
						'		,CCP_IMPORTEMON ' +
						'FROM	' + @baseCC + 'VIS_CONCAR01 AS DOCUMENTO     ' +
						'        LEFT JOIN ' + @baseCC + 'PNC_PARAMETR as CARTERA ON CARTERA.PAR_TIPOPARA=''CARTERA'' AND CCP_CARTERA=CARTERA.PAR_IDENPARA    ' +
						'		INNER JOIN ' + @baseCC + 'CXC_PAGANT ON PAM_TIPODOCTO=CCP_TIPODOCTO AND PAM_IDDOCTO=CCP_REFER AND CCP_IDPERSONA=PAM_IDPERSONA           ' +
						'WHERE	CCP_DOCORI=''S''  ' +
						'		AND CCP_TIPODOCTO=''ANT''  ' +
						'		AND PAM_IDCOTIZACIONWEB = ' + @idCotizacion + ' ' 
		PRINT @query
		INSERT INTO @Respuesta
		EXECUTE (@query)
		SELECT DISTINCT PAM_IDDOCTO AS Cartera, saldo AS Monto, tipo AS Tipo, cargo AS Cargo FROM @Respuesta
		SET NOCOUNT OFF;
END;

go

