-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION base_Concentradora 
(
	@idEmpresa INT
)
RETURNS VARCHAR(100)
AS
BEGIN
	DECLARE @baseConcentradora VARCHAR(100)
	DECLARE @ipLocal VARCHAR(50) = ''
	SELECT	@ipLocal = local_net_address
	FROM	sys.dm_exec_connections
	WHERE	Session_id = @@SPID;
	SELECT	@baseConcentradora = (CASE WHEN @ipLocal = ip_servidor THEN '[' + nombre_base + '].[dbo].'
									   ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END)
	  FROM	DIG_CAT_BASES_BPRO 
	 WHERE	catsuc_nombrecto = 'CONCENTRA'
            AND emp_idempresa = @idEmpresa

	RETURN @baseConcentradora

END
go

