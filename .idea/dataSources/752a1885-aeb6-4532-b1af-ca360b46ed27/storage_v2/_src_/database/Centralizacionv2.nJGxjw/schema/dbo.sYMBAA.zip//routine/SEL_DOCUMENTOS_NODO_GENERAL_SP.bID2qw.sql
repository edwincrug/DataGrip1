-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	Ejecuta el store para la obtencion de los documentos por nodo dependiendo de la fecha de creacion 
-- =============================================
--[dbo].[SEL_DOCUMENTOS_NODO_GENERAL_SP] 7,'AU-AU-UNI-OT-PE-826',1
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_NODO_GENERAL_SP] 
	@idNodo int
	, @folio nvarchar(50)
	, @idperfil int
AS
BEGIN
	DECLARE @FechaModificacion DATETIME 
			,@FechaInicio DATETIME = (SELECT Fecha_Inicio FROM DIG_EXPEDIENTE WHERE Folio_Operacion =@folio)
	SET @FechaModificacion = CONVERT(DATETIME,'2018/01/08')
	PRINT @FechaModificacion
	PRINT @FechaInicio
	IF(@FechaInicio < @FechaModificacion)
		BEGIN
			PRINT 'entre'
			EXECUTE [dbo].[SEL_DOCUMENTOS_NODO_SP] @idNodo,@folio,@idperfil
		END
	ELSE
		BEGIN
			EXECUTE [dbo].[SEL_DOCUMENTOS_NODO_V2_SP] @idNodo,@folio,@idperfil
		END
END
go

