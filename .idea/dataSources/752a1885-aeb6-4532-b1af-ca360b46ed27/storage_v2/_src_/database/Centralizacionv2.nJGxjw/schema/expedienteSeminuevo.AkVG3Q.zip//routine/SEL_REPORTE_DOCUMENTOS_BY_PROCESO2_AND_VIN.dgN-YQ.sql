-- =============================================
-- Author:		<JJSY>
-- Create date: <SP que regresa reporte de documentos proceso 2>
-- Description:	<Description,,>
--TEST [expedienteSeminuevo].[SEL_REPORTE_DOCUMENTOS_BY_PROCESO2_AND_VIN] 'JM1BM1K31F1244253', 4, 6, 2
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_REPORTE_DOCUMENTOS_BY_PROCESO2_AND_VIN]
	@vin VARCHAR(50),
	@idEmpresa INT,
	@idSucursal INT,
	@idProceso INT
AS
BEGIN
DECLARE @nombreCliente NVARCHAR(MAX);
DECLARE @nombresucursal VARCHAR(MAX);
DECLARE @idCliente INT
DECLARE @bd VARCHAR(MAX);

DECLARE @sqlCommand VARCHAR(MAX)
DECLARE @idExpediente INT = 0;
DECLARE @queryDinamicoSeminuevos NVARCHAR(MAX);
DECLARE @seminuevos INT
DECLARE @complementoQuery VARCHAR(MAX)
	
DECLARE @queryFisicaMoral NVARCHAR(MAX) = '', @fisicaMoral VARCHAR(5), @querynombrecliente NVARCHAR (MAX);
	
    IF (@idProceso = 1)
        BEGIN
            SET @complementoQuery= ''''
        END
    ELSE IF (@idProceso = 2)
        BEGIN
            SET @complementoQuery = ''' AND VEH_SITUACION LIKE ''%SVEN%'''
        END


		SELECT @idExpediente = id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
			AND exp_empresa = @idEmpresa 
			AND exp_sucursal = @idSucursal


		SELECT @bd = nombre_base
	    FROM DIG_CAT_BASES_BPRO 
		WHERE emp_idEmpresa = @idEmpresa
		AND suc_idSucursal = @idSucursal

		
		SET @querynombrecliente = 'SELECT 
									@clienteNombre = PP.PER_NOMRAZON +''''+ PP.PER_PATERNO + '''' + PP.PER_MATERNO 
									FROM ' + @bd + '.DBO.SER_VEHICULO SV 
									INNER JOIN cuentasporcobrar.[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucn_noserie = SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
									INNER JOIN cuentasporcobrar.[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_idCotizacion = CD.ucu_idCotizacion
									INNER JOIN GA_corporativa..PER_PERSONAS PP ON CU.ucu_idcliente = PP.PER_IDPERSONA 
									WHERE SV.VEH_NUMSERIE = ''' + @vin + @complementoQuery
		EXEC sp_executesql @querynombrecliente, N'@clienteNombre nvarchar(200) OUTPUT', @clienteNombre = @nombreCliente OUTPUT

	   SELECT @nombresucursal = nombre_sucursal
	   FROM DIG_CAT_BASES_BPRO 
		WHERE emp_idEmpresa = @idEmpresa
		AND suc_idSucursal = @idSucursal

			BEGIN TRY

			IF NOT EXISTS(SELECT id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
				AND exp_empresa = @idEmpresa 
				AND exp_sucursal = @idSucursal)
			BEGIN
				SET @queryDinamicoSeminuevos = 'SELECT @C = COUNT(*) FROM ' + @bd + '.DBO.SER_VEHICULO WHERE VEH_NUMSERIE = ''' + @vin + @complementoQuery
				PRINT(@queryDinamicoSeminuevos)
				
				EXEC sp_executesql @queryDinamicoSeminuevos, N'@C INT OUTPUT', @C=@seminuevos OUTPUT
				PRINT(@seminuevos)

				IF (@seminuevos > 0)
					BEGIN
						INSERT INTO [expedienteSeminuevo].[expedientes] ([exp_vin], [exp_empresa], [exp_sucursal], [exp_fechaCreacion])
							VALUES (@vin, @idEmpresa, @idSucursal, GETDATE())
					END
				ELSE
					BEGIN
						SELECT success = 0
						SELECT msg = 'No se encontró registro del VIN en la empresa y/o sucursal indicada.'
						RETURN
					END
			END
		
			SELECT @idExpediente = id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
				AND exp_empresa = @idEmpresa 
				AND exp_sucursal = @idSucursal
		
			SELECT 
				@idCliente = ucu_idcliente
			FROM cuentasporcobrar.[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] CD
			INNER JOIN cuentasporcobrar.[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_idCotizacion = CD.ucu_idCotizacion
			WHERE CD.ucn_noserie = @vin AND cec_idestatuscotiza <> 14 AND ucu_tipocotizacion = 'SN' AND ucu_idEmpresa = @idEmpresa AND ucu_idSucursal = @idSucursal

        IF (@idCliente IS NULL)
            BEGIN
                SELECT success = 0
                SELECT msg = 'No se encontró registro del VIN en la empresa y/o sucursal indicada.'
                RETURN
            END
	
		SELECT @fisicaMoral = PER_TIPO FROM GA_corporativa.DBO.PER_PERSONAS WHERE PER_IDPERSONA = @idCliente
		--TEST [expedienteSeminuevo].[SEL_DOCUMENTOS_BY_PROCESO_AND_VIN] 'JM1BM1K31F1244253', 4, 6, 1, 139, 71
		DECLARE @rutaSave VARCHAR(500), @rutaGet VARCHAR(500);

		SELECT success = 1;


SET @sqlCommand = '

		SELECT 
		sucursal,
		vin,
		nombreCliente,
		isnull(MAX([24]),''NO APLICA'') as [Facturadeunidadseminueva],
		isnull(MAX([25]),''NO APLICA'') as [PedidooriginalBproyDigitalizacion],
		isnull(MAX([26]),''NO APLICA'') AS [Recibosdepago],
		isnull(MAX([27]),''NO APLICA'')AS [Documentossoportesderecibosdecaja],
		isnull(MAX([28]),''NO APLICA'')AS [NotasdeCargo],
		isnull(MAX([29]),''NO APLICA'') AS [NotasdeCredito],
		isnull(MAX([30]),''NO APLICA'') AS [FacturasdeAccesorios],
		isnull(MAX([31]),''NO APLICA'') AS [CaratulaPolizadeseguro],
		isnull(MAX([32]),''NO APLICA'')AS [RFC],
		isnull(MAX([33]),''NO APLICA'')AS [IdentificacionOficialVigente],
		isnull(MAX([34]),''NO APLICA'')AS [Comprobantededomiciliovigente],
		isnull(MAX([35]),''NO APLICA'')AS [Autorizaciondelafinancieracorridadeautorizacion],
		isnull(MAX([36]),''NO APLICA'')AS [Actaconstitutiva],
		isnull(MAX([37]),''NO APLICA'')AS [Poderderepresentantelegal],
		isnull(MAX([38]),''NO APLICA'')AS [Salidadeunidad],
		isnull(MAX([39]),''NO APLICA'')AS [CONTRATODECOMPRAVENTA],
		isnull(MAX([40]),''NO APLICA'')AS [FormatodeIdentificaciondePLD],
		isnull(MAX([41]),''NO APLICA'') AS [Polizadegarantia] ,
		isnull(MAX([42]),''NO APLICA'') AS [Recibodeunidad] ,
		isnull(MAX([43]),''NO APLICA'')AS [CartaFactura],
		isnull(MAX([44]),''NO APLICA'')AS [Certificadodeunidadgarantizada],
		isnull(MAX([45]),''NO APLICA'')AS [Copiadelengomadodelasplacasydelatarjetadecirculacion],
		isnull(MAX([46]),''NO APLICA'')AS [AvisodePrivacidad],
		isnull(MAX([47]),''NO APLICA'')AS [Copiadecaratuladelcontratoconlafinanciera]
	FROM (


SELECT 
			A.id_documento as iddocumento,
		    --B.id_documentoGuardado,
			''' + @nombresucursal + ''' as sucursal,
			''' + @vin + ''' as vin,
			'''+ @nombreCliente + ''' AS nombreCliente,
			A.doc_nombre as nombre,
			CASE WHEN ISNULL(B.id_documentoGuardado, 0) > 0 THEN ''OK'' ELSE ''FALTA'' END AS existe
		FROM ( 
			SELECT 
				id_documento, 
				doc_nombre, 
				doc_extencion, 
				doc_opcional, 
				doc_proceso,
				doc_varios
			FROM [expedienteSeminuevo].[cat_documentos] 
			WHERE doc_proceso =  '+ CAST(@idProceso AS NVARCHAR(10))+'  AND (('''+ @fisicaMoral + ''' = ''MOR'' AND doc_moral = 1) OR ('''+ @fisicaMoral +'''  = ''FIS'' AND doc_fisica = 1) OR ('''+ @fisicaMoral +'''  = ''FIE'' AND doc_fisicaAE = 1))) AS A
		LEFT JOIN ( 
			SELECT
				max(DE.id_documentoGuardado) as id_documentoGuardado, 
				E.exp_vin,
				DE.id_expediente, 
				DE.id_proceso, 
				MAX(DE.id_estatus) AS id_estatus,
				MAX(ED.est_descripcion) AS est_descripcion, 
				MAX(DE.observacionesDocumento) observacionesDocumento,  
				--max(id_documento) as idDoc,
				DE.id_documento,
				max (nombreDocumento) as nombreDocumento
			FROM [Centralizacionv2].[expedienteSeminuevo].[documentosExpediente] DE
			INNER JOIN [expedienteSeminuevo].[estatusDocumentos] ED ON DE.id_estatus = ED.id_estatus 
		    inner JOIN [expedienteSeminuevo].[expedientes] E ON DE.id_expediente = E.id_expediente
			INNER JOIN ' + @bd + '.DBO.SER_VEHICULO SV ON E.exp_vin COLLATE Modern_Spanish_CI_AS = SV.VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS
		    INNER JOIN GA_corporativa.DBO.PER_PERSONAS PP ON SV.VEH_IDCLIENT = PP.PER_IDPERSONA
			WHERE DE.id_expediente = '+ CAST(@idExpediente AS NVARCHAR(10))+' 
			group by  E.exp_vin,DE.id_expediente, DE.id_proceso, DE.id_documento) AS B ON B.id_documento = A.id_documento AND B.id_proceso = A.doc_proceso
		INNER JOIN [expedienteSeminuevo].[documentoPerfil] DP ON DP.id_documento = A.id_documento AND DP.id_proceso = A.doc_proceso
		LEFT JOIN [expedienteSeminuevo].[documentosVarios] DV ON DV.doc_idDocumento = A.id_documento
		) x
		PIVOT
		(
			MAX(existe)
			FOR iddocumento in 
			(
			[24],
			[25],
			[26],
			[27],
			[28],
			[29],
			[30],
			[31],
			[32],
			[33],
			[34],
			[35],
			[36],
			[37],
			[38],
			[39],
			[40],  
			[41],
			[42],
			[43],
			[44],
			[45],
			[46],
			[47]
			) )AS p
			GROUP BY vin,sucursal,nombreCliente,nombreCliente'

			PRINT @sqlCommand
			EXEC (@sqlCommand)

    END TRY

	BEGIN CATCH
		PRINT (ERROR_MESSAGE())
		SELECT success = 0
		SELECT msg = 'Error al regresar los datos del expediente.';
	END CATCH

END

go

