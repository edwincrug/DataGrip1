CREATE procedure [dbo].[SEL_PRUEBA_SP] (
	@id bigint,
	@salida bigint OUTPUT
)
as
--insert procedure body here

	SET @salida = @id;
	SELECT @id as numero;
go

