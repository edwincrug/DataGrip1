-- =============================================
-- Author:		Genaro Mora 
-- Create date: 24/11/2015
-- Description: Stored que valida la autenticación del login
-- =============================================
-- [SEL_VALIDA_lOGIN_SP] GMI,GMI

CREATE PROCEDURE [dbo].[SEL_VALIDA_lOGIN_SP]
	  @usu_nombreusu varchar(35)  
	, @usu_contrasenia binary(1)
	
	
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
	
	SELECT   
	
	   usa.usu_idusuario AS usu_idusuario
      ,usa.usu_nombreusu AS usu_nombreusu
      ,usa.usu_paterno AS usu_paterno
      ,usa.usu_materno AS usu_materno
      ,usa.usu_nombre AS usu_nombre
      ,usa.usu_correo AS usu_correo
      ,usa.usu_contrasenia AS usu_contrasenia
      ,usa.usu_estatus AS usu_estatus
      ,usa.dep_iddepartamento AS dep_iddepartamento
      ,usa.usu_fechaalta AS usu_fechaalta
      ,usa.usu_usualta AS usu_usualta
      ,usa.usu_fechamodifica AS usu_fechamodifica
      ,usa.usu_usumodifica AS usu_usumodifica
      ,usa.pto_idpuesto AS pto_idpuesto
	FROM  [dbo].[Usuario_ControlAplicaciones] as usa

		WHERE usa.usu_nombreusu  = @usu_nombreusu 
		AND usa.usu_contrasenia =CONVERT(varbinary(1),@usu_contrasenia,0) 		
		END TRY

		BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_VALIDA_lOGIN_SP'
	SELECT @Mensaje = ERROR_MESSAGE()	
END CATCH 
END
go

