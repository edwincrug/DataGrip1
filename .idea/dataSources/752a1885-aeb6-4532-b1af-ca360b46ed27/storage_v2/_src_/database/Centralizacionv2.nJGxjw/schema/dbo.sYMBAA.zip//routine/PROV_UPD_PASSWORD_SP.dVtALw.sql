CREATE PROCEDURE [dbo].[PROV_UPD_PASSWORD_SP] 
@rfc VARCHAR(50),
@contrasena VARCHAR(50)

AS

SET NOCOUNT ON	

BEGIN TRY	
	DECLARE @msg VARCHAR(100) = '', @estatus VARCHAR(10) = 'ok'
	DECLARE @per_idpersona SMALLINT	

				

				
							
							DECLARE @cadena VARBINARY(200),  @cadenaEncrypt VARCHAR(200)   
							SELECT @cadena = EncryptByPassPhrase('4ndr4d3', @contrasena)  

							SET @cadenaEncrypt = (SELECT CONVERT(VARCHAR(MAX), @cadena,1))

							UPDATE PPRO_USERSPORTALPROV 
							SET	ppro_pass = @cadenaEncrypt
							WHERE ppro_user=@rfc
							

							UPDATE PROV_tokenRecuperaPass SET tokenRecupera = '' WHERE rfc = @rfc



							SET @msg = 'Cambio de contraseña correcto.'
	
	
		SELECT @estatus estatus,@msg mensaje

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[PRO_UPD_PASSWORD_SP]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,'Error al Editar usuario, intente de nuevo.' mensaje--@msg

END CATCH
;
go

