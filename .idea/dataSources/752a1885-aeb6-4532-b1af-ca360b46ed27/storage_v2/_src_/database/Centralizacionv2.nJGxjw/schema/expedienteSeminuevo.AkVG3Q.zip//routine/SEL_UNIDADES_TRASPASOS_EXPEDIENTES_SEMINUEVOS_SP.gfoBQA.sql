-- =============================================
-- Author:			
-- Create date: 
-- Description:	obtiene informacion de la unidades Trapasadas de una fecha determinada
-- TEST [expedienteSeminuevo].[SEL_UNIDADES_TRASPASOS_EXPEDIENTES_SEMINUEVOS_SP] 2
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_UNIDADES_TRASPASOS_EXPEDIENTES_SEMINUEVOS_SP]
@numDias   int

AS
BEGIN
DECLARE @dias INT = @numdias
DECLARE @UnidadesTraspasadas TABLE (
			[ut_Id] [int] IDENTITY(1,1) NOT NULL,
			[ut_numtraspaso] [int] NULL,
			[ut_numserie] [varchar](17) NULL,
			[ut_bdSucEnvia] [varchar](50) NULL,
			[ut_bdSucRecibe] [varchar](50) NULL,
			[ut_idEmpresaEnvia] [int] NULL,
			[ut_idSucEnvia] [int] NULL,
			[ut_idEmpresaRecibe] [int] NULL,
			[ut_idSucRecibe] [int] NULL,
			[ut_codeUnitId] [varchar](50) NULL)

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAA_Concentra.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAA_Concentra.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))


INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAAF_Concentra.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAAF_Concentra.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))
 
INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GADVAP_Concentra.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))
  
INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GADVAP_Concentra.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAS_Concentra.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAS_Concentra.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAT_Concentra.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAT_Concentra.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))

  INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAU_Concentra.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAU_Concentra.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAutoAngarConcen.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))
 
  INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAAutoAngarConcen.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAHondaConcen.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAHondaConcen.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAHyundaiConcentra.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAHyundaiConcentra.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRU_NUMTRASPASO, TR.TRU_NUMSERIE AS VIN, TRU_SUCENVIA AS SUCENVIA, TRU_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAZM_Concentra.dbo.USN_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRU_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRU_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRU_FECRECEPCION = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRU_STATUS = 'R'
 --AND TR.TRU_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRU_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRU_NUMTRASPASO))

INSERT INTO @UnidadesTraspasadas
SELECT TR.TRA_NUMTRASPASO, TR.TRA_NUMSERIE AS VIN, TRA_SUCENVIA AS SUCENVIA, TRA_SUCRECIBE AS SUCRECIBE, 
SucE.emp_idempresa AS EMPRESA_ENVIA, sucE.suc_idsucursal AS SUCURSAL_ENVIA, sucR.emp_idempresa AS EMPRESA_RECIBE,
 sucR.suc_idsucursal AS SUCURSAL_RECIBE, idInt.code AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM GAZM_Concentra.dbo.UNI_TRASPASOS TR
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucE ON TR.TRA_SUCENVIA COLLATE Modern_Spanish_CI_AS = SucE.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS SucR ON TR.TRA_SUCRECIBE COLLATE Modern_Spanish_CI_AS = SucR.suc_nombrebd COLLATE Modern_Spanish_CI_AS
INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] AS idInt ON CONVERT(INT, sucR.suc_idsucursal) = idInt.idSucursal
WHERE TR.TRA_FECHOPE = (Select CONVERT(varchar,GETDATE() - @dias,103))
 AND TR.TRA_STATUS = 'R'
 --AND TR.TRA_NUMTRASPASO NOT IN (SELECT CASE WHEN ISNUMERIC(descripcion) = 1 THEN CONVERT(INT,descripcion) ELSE 0 END  FROM [Intelimotors].[dbo].[BitacoraSeminuevos]
 -- WHERE NoSerie = TR.TRA_NUMSERIE AND estado = 'transferida' AND idEmpresa = SUCE.emp_idempresa and idSucursal = SUCE.suc_idsucursal  and descripcion = CONVERT(VARCHAR(6),TR.TRA_NUMTRASPASO))

SELECT 
    [ut_numtraspaso] AS IDTRASPASO, 
	[ut_numserie] AS VIN, 
	[ut_bdSucEnvia] AS SUCENVIA, 
	[ut_bdSucRecibe] AS SUCRECIBE, 
	[ut_idEmpresaEnvia] AS EMPRESA_ENVIA, 
	[ut_idSucEnvia] AS SUCURSAL_ENVIA, 
	[ut_idEmpresaRecibe] AS EMPRESA_RECIBE,
	[ut_idSucRecibe] AS SUCURSAL_RECIBE, 
	[ut_codeUnitId] AS ID_INTELIMOTORS_SUCURSAL_RECIBE
FROM @UnidadesTraspasadas
 --WHERE ut_numserie = '1GCNC9EH0HZ218625'

END
go

