
CREATE PROCEDURE [dbo].[INS_EXP_DOC_BITACORA_SP]
	 @proc_Id	int
	,@nodo_Id	int
	,@folio_Operacion varchar(80)
	,@doc_Id int
	,@usuario_BPRO varchar(500)
	,@accion_Realizada varchar(500)
	 
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
BEGIN TRAN

	  INSERT INTO [Centralizacionv2].[dbo].[DIG_EXPNODO_BITACORA]
			(
			 [Proc_Id]
			,[Nodo_Id]
			,[Folio_Operacion]
			,[Doc_Id]
			,[Fecha]
			,[Usuario_BPRO]
			,[Accion_Realizada]
			)
			values 
			(
			 @proc_Id	
			,@nodo_Id	
			,@folio_Operacion
			,@doc_Id 
			,GETDATE()
			,@usuario_BPRO
			,@accion_Realizada
			)
				

COMMIT TRAN
select 0;
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_BITACORA_DIG_EXPNODO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END

go

