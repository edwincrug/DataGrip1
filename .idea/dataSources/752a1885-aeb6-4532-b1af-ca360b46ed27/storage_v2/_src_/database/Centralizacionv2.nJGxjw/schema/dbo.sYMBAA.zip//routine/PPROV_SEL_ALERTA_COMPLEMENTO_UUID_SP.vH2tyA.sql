-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez
-- Create date: 10/01/2019
-- Description:	Alerta UUID Registrado 
-- ==========================================================================================
-- EXECUTE [dbo].[PPROV_SEL_ALERTA_COMPLEMENTO_UUID_SP] 'B7C134CA-4699-4BA5-BEF7-1B1C4C825A16'

CREATE PROCEDURE [dbo].[PPROV_SEL_ALERTA_COMPLEMENTO_UUID_SP] 
	   @uuid VARCHAR(50)=''	
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	 DECLARE @msj     VARCHAR(200) = 'disponible'
	 DECLARE @folio   VARCHAR(50)  = ''
	 	 
	 IF EXISTS ( SELECT 1 FROM [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC] WHERE [uuid] = @uuid )
	 BEGIN
	    SELECT  @folio =  [folioorden]
	      FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]
	     WHERE [uuid] = @uuid
		
		SET @msj = 'UUID Registrado con la Orden de compra: '+ @folio +'. Los archivos no fueron registrados.'		
	 END

	 SELECT  @msj as mensaje
	 
     	
END TRY
BEGIN CATCH
	PRINT('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'PPROV_SEL_ALERTA_COMPLEMENTO_UUID_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

