-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [dbo].[Sp_Documentos_PorVIN_GETL] 'AU-ZM-NZA-UN-7754', '3N6AD35A3LK854762'
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Documentos_PorVIN_GETL]
	@folio VARCHAR(50),
	@vin VARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	EXEC [dbo].[Sp_Documentos_ExpNodoFlotVin_INS] @folio, @vin;


	DECLARE @idProceso INT = 2
	DECLARE @imgCXP VARCHAR(100), @imgCXC VARCHAR(100);

	SELECT 
		@imgCXP = par_valor 
	FROM DIG_PARAMETROS WHERE par_descripcion = 'IMGCXP'
	SELECT 
		@imgCXC = par_valor 
	FROM DIG_PARAMETROS WHERE par_descripcion = 'IMGCXC'
	--SET @imgCXC = 'http://localhost:8001/CuentasXCobrar/Cargas/';
	PRINT @imgCXP
	PRINT @imgCXC

	--
	-- Validamos el estatus de la cotización para indicar si aplica o no carga de documentos
	--
	DECLARE @Result INT = 1; -- 1 Puede cargar, 0 No puede cargar
	-- =====================================================================================
	-- Validamos que la cotizacion no este cancelada (14) ni Entregada (20)
	-- =====================================================================================
	IF EXISTS( SELECT ucu_foliocotizacion FROM cuentasporcobrar.dbo.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @Folio AND cec_idestatuscotiza IN (14) )
		BEGIN
			-- Esta cancelada o entregada
			SET @Result = 0;
		END


	SELECT  DISTINCT Doc_Nombre
			,Doc_Descripcion
			,ND.Doc_Id 
			,CASE	WHEN DNF.Fecha_Creacion IS NULL THEN ''
					ELSE @imgCXC + CU.ucu_foliocotizacion + '/' + CONVERT(VARCHAR(30), DNF.No_serie) COLLATE SQL_Latin1_General_CP1_CI_AS + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf' 
				END AS existeDoc
			,CASE	WHEN DNF.Fecha_Creacion IS NULL THEN 1
				ELSE 0
			END AS  cargar
			,isNULL(DM.idMandatorio,0) mandatorio
			,RVD.PorUnidad
			,active = @Result
	FROM	DIG_NODO_DOC  AS ND	 
			INNER JOIN [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] AS CD ON CD.Doc_Id = ND.Doc_Id AND CD.Doc_Origen <> 2
			INNER JOIN [Centralizacionv2].[dbo].[DIG_RELACION_VENTA_DOCUMENTOS] AS RVD ON ND.Doc_Id = RVD.Doc_Id AND RVD.PorUnidad = 1
			INNER JOIN [Centralizacionv2].[dbo].[DIG_CANAL_VENTA] AS CV ON RVD.IdTipoVenta = CV.idTipoVenta
			INNER JOIN [Centralizacionv2].[dbo].[DIG_CATALOGO_TIPO_VENTA] AS TV ON TV.IdTipoVenta = RVD.IdTipoVenta
			INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU ON CU.ucu_idtipoventa = CV.canalVenta COLLATE SQL_Latin1_General_CP1_CI_AS  AND CU.ucu_idempresa = CV.idEmpresa AND CU.ucu_idsucursal = CV.idSucursal
			INNER JOIN [Centralizacionv2].[dbo].[DIG_PERFIL_DOCUMENTO] AS PD ON PD.Doc_Id = CD.Doc_Id AND Cargar = 1
			INNER JOIN [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] AS DN ON DN.Nodo_Id = ND.Nodo_Id  AND DN.[Folio_Operacion] = CU.ucu_foliocotizacion COLLATE SQL_Latin1_General_CP1_CI_AS AND DN.[Doc_Id] = ND.[Doc_Id]
			LEFT JOIN [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC_FLOT] AS DNF ON DN.[Folio_Operacion] = DNF.Folio_Operacion AND DN.[Doc_Id] = DNF.[Doc_Id] AND DNF.No_serie = @vin
			LEFT JOIN Centralizacionv2.dbo.EXP_DOCUMENTOS_MANDATORIO AS DM ON DM.idTipoVenta = CV.idTipoVenta AND DM.idEmpresa = CU.ucu_idempresa AND DM.idSucursal = CU.ucu_idsucursal AND DM.Doc_Id = ND.Doc_Id
	WHERE	ND.Proc_Id = @idProceso 
			AND CU.ucu_foliocotizacion = @folio
END
go

