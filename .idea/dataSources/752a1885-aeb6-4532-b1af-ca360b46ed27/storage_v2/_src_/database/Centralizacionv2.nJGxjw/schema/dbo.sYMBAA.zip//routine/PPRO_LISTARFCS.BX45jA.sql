-- =============================================    
-- Author:  <Author,,Name>    
-- Create date: <Create Date,,>    
-- Description: <Description,,>    
-- =============================================    
CREATE PROCEDURE [dbo].[PPRO_LISTARFCS]    --   '4f289c8f-9886-4e7f-8d5d-ea07f9a9c17b'
@RFCRECEPTOR VARCHAR(15)= '',    
@RFCEMISOR VARCHAR(15) = ''    
AS    
BEGIN    
     
   
 SELECT RFC receptor FROM PPRO_RFCRECEPTOR WHERE UPPER(RFC) = UPPER(@RFCRECEPTOR)  
 
      
END

go

