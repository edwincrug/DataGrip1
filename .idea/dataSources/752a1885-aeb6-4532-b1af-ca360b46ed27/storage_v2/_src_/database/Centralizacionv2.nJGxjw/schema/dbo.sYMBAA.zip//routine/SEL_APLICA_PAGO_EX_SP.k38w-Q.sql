/*
LQMA 21062017
*/
/*
SEL_APLICA_PAGO_EX_SP @idUsuario = 437, @folio = 'AU-MZ-NZA-OT-PE-21'
*/

CREATE PROCEDURE [dbo].[SEL_APLICA_PAGO_EX_SP]
@idUsuario INT = 0,
@folio VARCHAR(50) = ''
AS
BEGIN
	
	DECLARE @activo INT = 1, @mensaje VARCHAR(200) = '', @idEmpresa INT = 0, @idSucursal INT = 0, @base VARCHAR(100) = '', @server VARCHAR(20) = '',@ipLocal VARCHAR(20) = ''
		
	IF NOT EXISTS ( SELECT 1 FROM Seguridad.dbo.SEG_CENTRALIZACION 
											WHERE seg_idUsuario = @idUsuario 
												AND seg_idAccion = 6  -- Aplicar Pago Externo
												AND seg_idModulo = 1  -- Factura
												AND seg_idPortal = 1) -- Digitalizacion
								BEGIN						
									SET @activo = 0
									SET @mensaje = 'Solo usuarios con permiso pueden aplicar pago externo.'
								END
	
	SELECT @activo activo, @mensaje mensaje
END
go

