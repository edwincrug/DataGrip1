-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION base_Agencia 
(
	@idEmpresa INT
	,@idSucursal INT
)
RETURNS VARCHAR(100)
AS
BEGIN
	DECLARE @base VARCHAR(100)
	DECLARE @ipLocal VARCHAR(50) = ''
	SELECT	@ipLocal = local_net_address
	FROM	sys.dm_exec_connections
	WHERE	Session_id = @@SPID;
	SELECT	@base = (CASE WHEN @ipLocal = ip_servidor THEN  '[' + nombre_base + '].[dbo].'
						  ELSE '[' + ip_servidor + '].[' + nombre_base + '].[dbo].' END) 
	FROM	[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
	WHERE	emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal
	RETURN @base
END
go

