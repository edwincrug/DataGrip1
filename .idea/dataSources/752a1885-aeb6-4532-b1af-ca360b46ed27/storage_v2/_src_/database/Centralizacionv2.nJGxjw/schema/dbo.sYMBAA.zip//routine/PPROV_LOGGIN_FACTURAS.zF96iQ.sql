CREATE PROCEDURE [dbo].[PPROV_LOGGIN_FACTURAS]  
@user VARCHAR(15) = '',    
@pass VARCHAR(15) = ''    
AS    
    
SELECT 'Nissan' MARCA,'prueba' NOMBRE,'xxxxxxxxxxxx' RFC  
--FROM dbo.PPRO_USUARIOSFACTURAS  
--WHERE ID_USER = @user AND USERPASS = @pass  


--per.per_paterno = @user AND per.per_materno = @pass       
--SELECT * FROM BDPersonas.dbo.cat_roles --(2:clientes,3:proveedor)    
--SELECT * FROM BDPersonas.dbo.per_relacionroles

go

