-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[PPRO_LISTARFCSPRUEBA]
@RFCEMISOR VARCHAR(15)= '',
@RFCRECEPTOR VARCHAR(15) = ''
AS
BEGIN
	
	DECLARE @RFCs TABLE(
    emisor varchar(15) NOT NULL,
    receptor varchar(15) NOT NULL );
    
    INSERT INTO @RFCs VALUES('ZMO841221BJ4','QCS931209G49')
    INSERT INTO @RFCs VALUES('RRR841221POU','XAXX010101000')
    INSERT INTO @RFCs VALUES('VVVV41221XXX','AAYY010101099')
    INSERT INTO @RFCs VALUES('HHHH41221POU','WWWW010108888')
    INSERT INTO @RFCs VALUES('TTTT41221ZZZ','FFFF010101777')	
	
	SELECT receptor FROM @RFCs WHERE UPPER(receptor) = UPPER(@RFCEMISOR)
		
END


go

