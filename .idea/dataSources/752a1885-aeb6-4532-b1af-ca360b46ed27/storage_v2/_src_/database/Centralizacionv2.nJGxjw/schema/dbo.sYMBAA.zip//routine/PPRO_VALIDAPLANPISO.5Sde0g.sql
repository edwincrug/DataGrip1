CREATE PROCEDURE [dbo].[PPRO_VALIDAPLANPISO] 
@OC VARCHAR(50),
@RFCEMISORXML VARCHAR(20) 
AS  
BEGIN  
	
	DECLARE @RESP INT = 0
		
	--LQMA add 25102017 obtener parametros para validar si es plan piso BEGIN
	DECLARE @empresa INT = 0, @depto INT = 0, @sucursal INT = 0 ,@ipLocal VARCHAR(20) = '', @base VARCHAR(50) = ''
	       ,@server VARCHAR(50) = '',@query VARCHAR(MAX) = ''
	SELECT @empresa = oce_idempresa, @depto = oce_iddepartamento, @sucursal = oce_idsucursal FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_folioorden = @OC
	--SELECT @empresa = 4, @depto = 35 

	
	print '@empresa: ' + CONVERT(VARCHAR(10),@empresa) + ' @depto ' + CONVERT(VARCHAR(10),@depto) + ' @suc ' + CONVERT(VARCHAR(10),@sucursal)
		
	IF EXISTS(SELECT 1 FROM DIG_CATALOGOS WHERE cat_nombre = CONVERT(VARCHAR(5),@empresa) + '|' + CONVERT(VARCHAR(5),@depto) AND cat_valor = '1')
	BEGIN		
			---unidades nuevas
			IF EXISTS(SELECT dep_iddepartamento FROM [ControlAplicaciones].dbo.cat_departamentos WHERE dep_nombrecto = 'UN' AND dep_iddepartamento = @depto)			 
				BEGIN
						IF EXISTS(SELECT anu_cvetipocompra FROM cuentasxpagar.dbo.cxp_detalleautosnuevos WHERE oce_folioorden = @OC AND anu_cvetipocompra IN ('CANMRS','CANAGE'))
							BEGIN
									--valida contra rfc de proveedor que trae la orden																		
									IF(SELECT per.per_rfc FROM [cuentasxpagar].[dbo].[cxp_ordencompra] OC 
										LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = OC.oce_idproveedor
										WHERE OC.oce_folioorden = @OC) != @RFCEMISORXML
									SET @RESP = 1
							END	
						ELSE
						   SET @RESP = 2 				
				END
			ELSE
			--refacciones	
			IF EXISTS(SELECT dep_iddepartamento FROM [ControlAplicaciones].dbo.cat_departamentos WHERE dep_nombrecto = 'RE' AND dep_iddepartamento = @depto)
				BEGIN
						IF(SELECT TOP 1 ref_tipocompra FROM cuentasxpagar.dbo.cxp_detallerefacciones WHERE oce_folioorden = @OC) != 'PLANTA'
							BEGIN
								--valida contra rfc de proveedor que trae la orden																		
									IF(SELECT per.per_rfc FROM [cuentasxpagar].[dbo].[cxp_ordencompra] OC 
										LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = OC.oce_idproveedor
										WHERE OC.oce_folioorden = @OC) != @RFCEMISORXML
									SET @RESP = 1		
							END
						ELSE
						   SET @RESP = 2 				
				END			

			IF @RESP = 2
				BEGIN
						SET @RESP = 0
			
							SELECT @base ='['+ nombre_base + ']', @server = ip_servidor 
									FROM CentralizacionV2..DIG_CAT_BASES_BPRO 
									WHERE emp_idempresa = @empresa 
											AND suc_idSucursal = @sucursal
											AND tipo = 1
					
									SELECT @ipLocal=local_net_address 
									FROM sys.dm_exec_connections c
									WHERE Session_id = @@SPID;
									
  
									IF(LTRIM(RTRIM(@ipLocal))!=RTRIM(LTRIM(@server)))
										SET @base = '['+ @server +'].'+@base
										
									SELECT @query = 'SELECT PAR_DESCRIP2 FROM ' + @base + '.[dbo].PNC_PARAMETR WHERE PAR_TIPOPARA = ''PLANTA'''
									print @query


									DECLARE @tablaPlanta TABLE(Id INT IDENTITY(1,1),idPlanta INT)										
									print @query

									INSERT INTO @tablaPlanta
									EXECUTE(@query)
							
									DECLARE @idPanta INT = 0
					
									SELECT TOP(1) @idPanta = idPlanta FROM @tablaPlanta					
		    	
									--SELECT PER_RFC FROM [BDPersonas].[dbo].[cat_personas] PER WHERE PER.per_idpersona = @idPanta

									IF(SELECT PER_RFC FROM GA_Corporativa.dbo.PER_PERSONAS PER WHERE PER.per_idpersona = @idPanta) != @RFCEMISORXML
										BEGIN
											SET @RESP = 1
										END
			END	
			--SELECT SUBSTRING(cat_nombre,1,CHARINDEX('|',cat_nombre)-1) empresa,SUBSTRING(cat_nombre,CHARINDEX('|',cat_nombre) + 1,4) depto  FROM DIG_CATALOGOS WHERE cat_id_padre = 300
	END	
	ELSE
	IF EXISTS(SELECT 1 FROM [Centralizacionv2].[dbo].[DIG_EXP_PLAN_PISO] WHERE Folio_Alias = @OC) 
		BEGIN			--- es plan piso			
			DECLARE @OC_ORIGINAL VARCHAR(80) = ''

			IF(LTRIM(RTRIM(@RFCEMISORXML)) != (SELECT TOP(1) LTRIM(RTRIM(PER.per_rfc)) FROM [Centralizacionv2].[dbo].[DIG_EXP_PLAN_PISO] PPISO 
								 LEFT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] OCS ON PPISO.Folio_Operacion = OCS.oce_folioorden
								 LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS PER ON OCS.oce_idproveedor = PER.per_idpersona
								 WHERE PPISO.Folio_Alias = @OC))
			SET @RESP = 1
		END			

	SELECT @RESP    --0 valido, 1 no valido
END
go

