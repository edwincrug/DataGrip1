
CREATE FUNCTION [dbo].[base_concentradora_cotizacion]
(
	@folio VARCHAR(50)
)
RETURNS VARCHAR(100)
AS 
BEGIN
	DECLARE @baseConcentradora VARCHAR(100)
	DECLARE @ipLocal VARCHAR(50) = ''
	SELECT	@ipLocal = local_net_address
	FROM	sys.dm_exec_connections
	WHERE	Session_id = @@SPID;
	SELECT	@baseConcentradora = (CASE WHEN @ipLocal = ip_servidor THEN '[' + nombre_base + '].[dbo].'
									   ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END)
	  FROM	DIG_CAT_BASES_BPRO AS BPRO 
			INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU ON CU.ucu_idempresa = BPRO.emp_idempresa
	 WHERE	CU.ucu_foliocotizacion = @folio AND BPRO.tipo = 2

	RETURN @baseConcentradora
END;
go

