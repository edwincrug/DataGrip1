-- ================================================
-- Create date: 14/08/2017
-- Description:	Verifica las condiciones para mostra el botón de cerrar nodo en el nodo 14 
-- =============================================
-- [dbo].[SEL_BOTON_CERRAR_NODO_SP] 0, 'AU-AU-CUA-OT-PE-150'
CREATE PROCEDURE [dbo].[SEL_BOTON_CERRAR_NODO_SP]
	@idUsuario INT
	,@folio NVARCHAR(30)
AS
BEGIN
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Verifica si el usuario tiene permisos para Cerra el nodo 14 Donde		[seg_idAccion] = 7 <--Cerrar nodos 
--																		AND [seg_idPortal]=1 <--Centralizacion
--																		AND [seg_idModulo] =2 <--Nodo 14 Cerrar 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
IF(EXISTS(SELECT  1 FROM [Seguridad].[dbo].[SEG_CENTRALIZACION] WHERE [seg_idUsuario] = @idUsuario AND [seg_idAccion] = 7 AND [seg_idPortal]=1 AND [seg_idModulo] =2))
	BEGIN
		IF(EXISTS (SELECT 1 FROM [Centralizacionv2].[dbo].[DIG_EXP_NODO] WHERE [Folio_Operacion] = @folio AND Nodo_Estatus_Id = 3 AND Nodo_Id = 14))
			BEGIN
				SELECT 0 AS respuesta, 'El nodo 14 ya esta cerrado' AS mensaje
			END
		ELSE
			BEGIN				
				IF(EXISTS(	SELECT	1
							FROM	[Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] EXPDOC
									INNER JOIN [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] CATDOC ON EXPDOC.Doc_Id = CATDOC.Doc_Id
									INNER JOIN [Centralizacionv2].[dbo].[DIG_NODO_DOC] ND ON ND.Proc_Id = EXPDOC.Proc_Id AND ND.Nodo_Id = EXPDOC.[Nodo_Id] AND EXPDOC.[Doc_Id] = ND.[Doc_Id]
									INNER JOIN [Centralizacionv2].[dbo].[DIG_EXPEDIENTE] E ON E.Folio_Operacion = EXPDOC.Folio_Operacion
							WHERE	EXPDOC.[Folio_Operacion] = @folio AND Es_Mandatorio = 1 AND Fecha_Creacion IS NULL AND E.Estatus_Id !=2))
					BEGIN
						SELECT 0 AS respuesta, 'El folio: ' + @folio + ' tiene documentos pendientes' AS mensaje
					END
				ELSE IF(EXISTS(SELECT 1 FROM [Centralizacionv2].[dbo].[DIG_EXPEDIENTE] WHERE [Folio_Operacion] = @folio AND Estatus_Id = 2))
					BEGIN
						SELECT 1 AS respuesta, 'El folio: ' + @folio + ' Orden de Compra Cancelada' AS mensaje
					END 
				ELSE
					BEGIN
						SELECT 1 AS respuesta, 'El usuario tiene los permisos necesarios y los documentos mandatorios estan completos' as mensaje
					END
			END
	END
ELSE
	BEGIN
		SELECT 0 AS respuesta, 'El usuario no tiene los permisos necesarios para cerrar el nodo 14' AS mensaje
	END


END
go

