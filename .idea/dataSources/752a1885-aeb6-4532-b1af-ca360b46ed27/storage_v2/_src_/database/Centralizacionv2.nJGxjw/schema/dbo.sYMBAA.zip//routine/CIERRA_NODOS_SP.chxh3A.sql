

--  CIERRA_NODOS_SP  @proc_Id = 1, @nodo_Id = 7, @folio_Operacion = 'AU-AU-UNI-RE-PI-193'
CREATE PROCEDURE [dbo].[CIERRA_NODOS_SP]  
 @proc_Id  INT = 0--- 1: CxP; 2: CxC
,@nodo_Id INT = 0 ----  hasta el numero de nodo donde se cerrara
,@folio_Operacion VARCHAR(50) = ''--- Folio de orden a cerrar --'AU-AU-UNI-RE-PI-193'
 
AS
		DECLARE @aux INT = 1	

		INSERT INTO BITACORA_PROCESOS
		VALUES (3,'CIERRA_NODOS_SP Inicia cierre de nodos folio: ' + @folio_Operacion,GETDATE())
			    		
		BEGIN TRANSACTION TRAN_CIERRA_NODOS

	BEGIN TRY
			
			--recorre los nodos desde el 1 al nodo a cerrar	
			WHILE(@aux <= @nodo_Id)
				BEGIN					
					
					--Verifica si alguna de las fechas del nodo esta null, entonces lo cierra
					IF EXISTS(SELECT  Proc_Id,Nodo_Id,Folio_Operacion,FechaInicio,FechaFin,Nodo_Estatus_Id	FROM DIG_EXP_NODO 
					          WHERE  Proc_Id= @proc_Id 
									 AND	Nodo_Id= @aux 
						             AND	Folio_Operacion= @folio_Operacion	
						             AND (FechaInicio IS NULL OR FechaFin IS NULL))
						BEGIN --cierra nodo sin abrir/cerrar
							
							--cierra nodo actual
							EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
									@proc_Id = @proc_Id  
									,@nodo_Id = @aux
									,@folio_Operacion = @folio_Operacion
					
							INSERT INTO BITACORA_PROCESOS
							VALUES (3,'CIERRA_NODOS_SP cierra nodo: ' + CONVERT(VARCHAR(2),@aux) + ' -- folio: ' + @folio_Operacion,GETDATE())
							--PRINT 'Cerro nodo, folio: ' + @folio_Operacion +' , nodo: ' + CONVERT(VARCHAR(2), @nodoInicio)
						
						END -- end cierra nodo sin abrir/cerrar

					--incrementa en 1 el nodo a recorrer
					SET @aux = @aux + 1

				END--fin ciclo WHILE
		SELECT 0
		
		COMMIT TRANSACTION TRAN_CIERRA_NODOS

	END TRY
	BEGIN CATCH		
		
		ROLLBACK TRANSACTION TRAN_CIERRA_NODOS
		
		DECLARE @Mensaje  nvarchar(max)		
		SELECT @Mensaje = ERROR_MESSAGE() + ' @folio : ' + @folio_Operacion	
		EXECUTE INS_ERROR_SP 'CIERRA_NODOS_SP', @Mensaje
		SELECT  ERROR_NUMBER() 

	END CATCH
go

