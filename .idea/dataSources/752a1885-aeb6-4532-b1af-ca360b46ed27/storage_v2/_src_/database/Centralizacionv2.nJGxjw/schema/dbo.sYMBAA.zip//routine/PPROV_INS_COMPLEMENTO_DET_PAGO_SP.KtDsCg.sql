-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 10/01/2019
-- Description:	Insert a la Tabla Detalle
-- ==========================================================================================
/*
EXECUTE [dbo].[PPROV_INS_COMPLEMENTO_DET_PAGO_SP] 
				 @id_Complemento 	 = 4
				,@folio_orden        = '4531'
				,@serie_oden         = 'DA'
				,@orden_UUID         = '3b9dd10b-3322-4f84-9bbd-768fb8e93xx0a'
				,@imp_saldo_insoluto = 0.00
				,@imp_pagado         = 1535.20
				,@imp_saldo_ant      = 200.20
				,@num_parcialidad    = 10
				,@metodo_pago_DR     = 'PPD'
				,@moneda_DR          = 'MXN'
				,@tipo               = 4   
*/				
CREATE PROCEDURE [dbo].[PPROV_INS_COMPLEMENTO_DET_PAGO_SP]
				 @id_Complemento 	 INT
				,@folio_orden        VARCHAR(5)
				,@serie_oden         VARCHAR(5)
				,@orden_UUID         VARCHAR(50)
				,@imp_saldo_insoluto DECIMAL(18,2)
				,@imp_pagado         DECIMAL(18,2)
				,@imp_saldo_ant      DECIMAL(18,2)
				,@num_parcialidad    INT
				,@metodo_pago_DR     VARCHAR(5)
				,@moneda_DR          VARCHAR(5)
				,@tipo               INT
AS
BEGIN
    SET NOCOUNT ON;	
    BEGIN TRY
	    DECLARE @idDetalle  INT = 0;
		-------------------------------------------------------------------------------------
		-- Validamos tipo en PPRO_DATOSFACTURAS (0:UUID existe, 1:No existe )
		-------------------------------------------------------------------------------------
		IF EXISTS(SELECT 1 FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] WHERE [uuid] = @orden_UUID)
		   SET @tipo = 0
        ELSE
		   SET @tipo = 1

	    -------------------------------------------------------------------------------------
		-- Si No existe detalle lo inserto
		-------------------------------------------------------------------------------------
		IF NOT EXISTS(SELECT 1 FROM [dbo].[PPRO_COMPLEMENTODET] WHERE serie_orden = @serie_oden AND folio_orden = @folio_orden)
			BEGIN
				IF NOT EXISTS(SELECT 1 FROM [Centralizacionv2].[dbo].[PPRO_COMPLEMENTODET] WHERE [orden_UUID] = @orden_UUID)
				   BEGIN
				   		PRINT 'NO EXISTE, INSERTO'
						INSERT INTO [dbo].[PPRO_COMPLEMENTODET]
									([id_Complemento]
									,[folio_orden]
									,[serie_orden]
									,[orden_UUID]
									,[imp_saldo_insoluto]
									,[imp_pagado]
									,[imp_saldo_ant]
									,[num_parcialidad]
									,[metodo_pago_DR]
									,[moneda_DR]
									,[tipo])
						     VALUES( @id_Complemento 	
									,@folio_orden        
									,@serie_oden         
									,@orden_UUID         
									,@imp_saldo_insoluto 
									,@imp_pagado         
									,@imp_saldo_ant      
									,@num_parcialidad    
									,@metodo_pago_DR     
									,@moneda_DR          
									,@tipo)

					   SELECT @idDetalle = @@IDENTITY 
					   SELECT @idDetalle AS idDetalle, 'Ok' AS msj
					END
				ELSE
					BEGIN
					   PRINT 'EXISTE UUID'
					   SELECT 0 AS idDetalle, 'No insertado, UUID ya registrado anteriormente' AS msj 
					   EXECUTE [dbo].[PPROV_DEL_COMPLEMENTO_PAGO_SP] @id_Complemento       
					END  				   
			END
		ELSE 
		-------------------------------------------------------------------------------------
		-- Existe detalle No se inserta
		-------------------------------------------------------------------------------------
			BEGIN
			    PRINT 'EXISTE, SERIE Y FOLIO'
				SELECT 0 AS idDetalle, 'No insertado, serie y folio registrados anteriormente' AS msj
				EXECUTE [dbo].[PPROV_DEL_COMPLEMENTO_PAGO_SP] @id_Complemento 
			END
	END TRY
	BEGIN CATCH
	     EXECUTE [dbo].[PPROV_DEL_COMPLEMENTO_PAGO_SP] @id_Complemento
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 DECLARE @Mensaje  nvarchar(max),
		 @Componente nvarchar(50) = '[PPROV_INS_COMPLEMENTO_DET_PAGO_SP]'
		 SELECT @Mensaje = ERROR_MESSAGE()
		 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
		 SELECT 1  --Encontro error
	END CATCH
END
go

