-- =============================================
-- Author:		<DVR>
-- Create date: <29/07/2020>
-- Description:	<Se ejecuta aparatir del Api saveDocumento>
-- TEST [expedienteSeminuevo].[SEL_DOCUMENTOS_BY_PROCESO_AND_VIN_API] 'MMBMG46H4FD051272', 4, 6, 1, 139, 71
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_DOCUMENTOS_BY_PROCESO_AND_VIN_API]
	@vin VARCHAR(50),
	@idEmpresa INT,
	@idSucursal INT,
	@idProceso INT,
	@idPerfil INT,
	@idUsuario INT
AS
BEGIN

	DECLARE @idExpediente INT = 0;
	DECLARE @bd VARCHAR(MAX);
	DECLARE @msgAccion VARCHAR(50) = 'Consulta de Expediente existente';

	SELECT @bd = nombre_base
	FROM DIG_CAT_BASES_BPRO 
		WHERE emp_idEmpresa = @idEmpresa
		AND suc_idSucursal = @idSucursal

    IF NOT EXISTS(SELECT usu_idusuario FROM controlAplicaciones..ope_organigrama 
				  WHERE usu_idUsuario = @idUsuario
						AND emp_idempresa = @idEmpresa
						AND suc_idsucursal = @idSucursal)
        BEGIN
			SELECT success = 0
            SELECT msg = 'El usuario no tiene acceso a la empresa y/o sucursal indicada.'
            RETURN
        END


	BEGIN TRY

		IF NOT EXISTS(SELECT id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
				AND exp_empresa = @idEmpresa 
				AND exp_sucursal = @idSucursal)
		BEGIN				
				INSERT INTO [expedienteSeminuevo].[expedientes] ([exp_vin], [exp_empresa], [exp_sucursal], [exp_fechaCreacion])
				VALUES (@vin, @idEmpresa, @idSucursal, GETDATE())
				SET @msgAccion = 'Se Creo el nuevo Expediente'
		END
					
		
		SELECT @idExpediente = id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
				AND exp_empresa = @idEmpresa 
				AND exp_sucursal = @idSucursal


		
		DECLARE @rutaSave VARCHAR(500), @rutaGet VARCHAR(500);
		SELECT @rutaSave = par_valor FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'SAVE_IMG' 
		SELECT @rutaGet = par_valor FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'GET_IMG'
		 
		SELECT success = 1;
		SELECT 
			@idExpediente AS idExpediente,
			@rutaSave AS rutaSave,
			CASE 
				WHEN @idProceso = 1 AND B.id_documento  IN (select doc_idDocumento from [expedienteSeminuevo].[documentosVarios]) 
				THEN  
						@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXP' + '/' + DV.var_carpetaSave
				WHEN @idProceso = 1  
				THEN 
					@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXP' + '/' + B.nombreDocumento 

			ELSE 
			    CASE
					WHEN @idProceso = 2 AND B.id_documento  IN (select doc_idDocumento from [expedienteSeminuevo].[documentosVarios])  /* proceso 2 con documentos multiples */
					THEN 
						@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXC' + '/' + DV.var_carpetaSave
					ELSE 
						@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXC' + '/' + B.nombreDocumento 
				END
			END AS rutaGet,
			CASE WHEN @idProceso = 1 THEN 'CXP' ELSE 'CXC' END AS proceso,
			ISNULL(DV.var_carpetaSave, '') AS carpetaVarios,
			A.doc_varios,
			A.id_documento,
			A.doc_nombre,
			A.doc_extencion,
			CASE WHEN A.doc_opcional = 0 THEN 'Obligatorio' 
			ELSE  'Opcional'  
			END AS doctoOpcional,
			A.doc_opcional,
			A.doc_usuarios,
			CASE WHEN ISNULL(B.id_documentoGuardado, 0) > 0 THEN 1 ELSE 0 END AS existe,
			B.nombreDocumento AS nombreActual,
			B.id_documentoGuardado,
			B.id_expediente,
			B.id_proceso,
			B.id_estatus,
			B.est_descripcion,
			B.observacionesDocumento,
			A.doc_nombreCorto
		FROM ( 
			SELECT 
				id_documento, 
				doc_nombre, 
				doc_extencion, 
				doc_opcional,
				doc_usuarios, 
				doc_proceso,
				doc_varios,
				doc_nombreCorto
			FROM [expedienteSeminuevo].[cat_documentos] 
			WHERE doc_proceso = @idProceso ) AS A
		LEFT JOIN ( 
			SELECT
				max(DE.id_documentoGuardado) as id_documentoGuardado, 
				DE.id_expediente, 
				DE.id_proceso, 
				MAX(DE.id_estatus) AS id_estatus,
				MAX(ED.est_descripcion) AS est_descripcion, 
				MAX(DE.observacionesDocumento) observacionesDocumento, 
				DE.id_documento,
				max (nombreDocumento) as nombreDocumento
			FROM [Centralizacionv2].[expedienteSeminuevo].[documentosExpediente] DE
			INNER JOIN [expedienteSeminuevo].[estatusDocumentos] ED ON DE.id_estatus = ED.id_estatus 
			WHERE id_expediente = @idExpediente 
			group by DE.id_expediente, DE.id_proceso, DE.id_documento ) AS B ON B.id_documento = A.id_documento AND B.id_proceso = A.doc_proceso
		INNER JOIN [expedienteSeminuevo].[documentoPerfil] DP ON DP.id_perfil = @idPerfil AND DP.id_documento = A.id_documento AND DP.id_proceso = A.doc_proceso
		LEFT JOIN [expedienteSeminuevo].[documentosVarios] DV ON DV.doc_idDocumento = A.id_documento

	SELECT @msgAccion AS accion

    END TRY

	BEGIN CATCH
		PRINT (ERROR_MESSAGE())
		SELECT success = 0
		SELECT msg = 'Error al regresar los datos del expediente.';
	END CATCH
END

go

