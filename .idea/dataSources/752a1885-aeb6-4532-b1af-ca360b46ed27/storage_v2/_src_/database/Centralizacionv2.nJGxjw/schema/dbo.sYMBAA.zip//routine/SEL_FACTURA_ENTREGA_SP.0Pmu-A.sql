-- =============================================
-- Author:		Alejandro Lopez Quiroz
-- Create date: 10/02/2016
-- Modified date: 
-- Description: recupera verifica si existe la factura (docto ID 20) y regresa la ruta
-- =============================================
--execute [SEL_FACTURA_ENTREGA_SP] 'AU-ZM-ZAR-SE-PE-36', 1,11
CREATE PROCEDURE [dbo].[SEL_FACTURA_ENTREGA_SP]
	  @folio VARCHAR(50) = ''
	, @idperfil int	= 0 
	,@Doc_Id INT = 0 --20 factura, 15 entrega
AS
BEGIN

	--LQMA 18072017 add, comprueba si existe fisicamente el comprobante recepcion
	DECLARE @Archivo varchar(255) = 'E:\GA_Centralizacion\CuentasXPagar\Cargas\' + @folio + '\15.pdf'
	DECLARE @Existe int
	EXEC Master.dbo.xp_fileexist @Archivo , @Existe OUT	
	IF(@Existe = 0)
		BEGIN
		print ''
			/*UPDATE DIG_EXPNODO_DOC 
			SET Fecha_Creacion = NULL, 
				Doc_Extencion = NULL
			WHERE Folio_Operacion = @folio 
			  AND Doc_Id = 15 
			  */--AND Nodo_Id = 7
		END

	DECLARE	@nombreArchivo VARCHAR(100) = '' --rfc_emisor +  FROM PPRO_DATOSFACTURAS WHERE [folioorden]
	DECLARE @fecha VARCHAR(100) = '', @rfc_receptor VARCHAR(20) = ''
	
	SELECT @nombreArchivo = rfc_emisor + '_' + CASE folio 
											WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
											ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
										 END,
		   @fecha = CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' +SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2),
		   @rfc_receptor = rfc_receptor
	FROM PPRO_DATOSFACTURAS WHERE [folioorden] = @folio	

	print 'receptor: ' + @rfc_receptor
	print 'fecha: ' + @fecha
	print 'archivo: ' + @nombreArchivo

	SELECT CASE WHEN ED.Fecha_Creacion is null THEN ''
		          WHEN ED.Fecha_Creacion is not null THEN --'Si'
														CASE @Doc_Id 
														    WHEN 11 THEN 'http:\\192.168.20.89\GA_Centralizacion\CuentasXPagar\TempPdf\OrdenCompra\Orden_' + ED.Folio_Operacion + '.' +  ISNULL(ED.[Doc_Extencion],'pdf')
															WHEN 15 THEN 'http:\\192.168.20.89\GA_Centralizacion\CuentasXPagar\Cargas\' + ED.Folio_Operacion + '\' + CONVERT(VARCHAR(5),ED.Doc_Id) + '.' + ISNULL(ED.[Doc_Extencion],'pdf')
															WHEN 20 THEN 'http:\\192.168.20.89\GA_Centralizacion\FacturasProveedores\'+ @rfc_receptor +'\'+ @fecha + '\' + @nombreArchivo + '.' + ISNULL(ED.[Doc_Extencion],'pdf') --\Facturas\' + ED.Folio_Operacion + '\' + CONVERT(VARCHAR(5),ED.Doc_Id) + '.' + ISNULL(ED.[Doc_Extencion],'pdf')
														END
		          END AS existeDoc
	FROM     dbo.DIG_EXPNODO_DOC AS ED
	LEFT JOIN DIG_PERFIL_DOCUMENTO PD ON ED.Doc_Id = PD.Doc_Id
	WHERE ED.Folio_Operacion = @folio AND ED.Doc_Id = @Doc_Id --Id Factura 20, 
	AND PD.Perfil_Id = 1--@idperfil arreglar este desmadre
	AND ED.Nodo_Id =  CASE @Doc_Id 	WHEN 20 THEN 6 -- puede ser cualquer id_nodo donde se id_doc contenga 20(factura)
									WHEN 15 THEN 7 --
									WHEN 11 THEN 6 -- Checar esta parte
			     	  END
END
go

