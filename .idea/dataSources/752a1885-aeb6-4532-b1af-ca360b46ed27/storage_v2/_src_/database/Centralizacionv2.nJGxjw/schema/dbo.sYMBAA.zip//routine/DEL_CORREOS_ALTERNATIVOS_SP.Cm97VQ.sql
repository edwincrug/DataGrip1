CREATE PROCEDURE [dbo].[DEL_CORREOS_ALTERNATIVOS_SP] --DEL_CORREOS_ALTERNATIVOS_SP 1
@idUsuarioCorreo INT

AS
BEGIN
	DELETE FROM UsuarioCorreo
	WHERE idUsuarioCorreo=@idUsuarioCorreo

	SELECT @idUsuarioCorreo  Mensaje
END
go

