
CREATE PROCEDURE [dbo].[SEL_ABONOSCONTABLES_NOBANCOS]  (@iAnio int,@iMes int,@snoCuenta varchar(100),@sConciliados varchar(1), @dResultado numeric(18,6) Output)   
As
Declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@iIdBanco int,
@iIdEmpresa int,
@noCtaContable varchar(50),
@stipo_poliza_pago varchar(10),
@snombre_base varchar(20),
@ipServidor    VARCHAR(100),
@ipLocal VARCHAR(50)
begin

set nocount on

--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#ABONOS_COMPLETO]'))
--begin
--	drop table #ABONOS_COMPLETO
--end
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#ABONOS_PAGO]'))
--begin
--	drop table #ABONOS_PAGO
--end
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#CARTERA_PAGOS]'))
--begin
--	drop table #CARTERA_PAGOS
--end
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#DOCTOSPAGADOS]'))
--begin
--	drop table #DOCTOSPAGADOS
--end
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#REGISTROSCONCILIADOS]'))
--begin
--	drop table #REGISTROSCONCILIADOS
--end
--- se quitaron las tablas temporales
DECLARE @ABONOS_COMPLETO TABLE
(
		id_local [int] IDENTITY (1, 1),
		MOV_TIPOPOL varchar(10),
		MOV_CONSPOL numeric(18,0),
		MOV_CONSMOV numeric(18,0),
		MOV_MES numeric(18,0),
		MOV_NUMCTA varchar(50),
		MOV_DEBE decimal(18,5),
		MOV_HABER decimal(18,5),
		Tipo varchar(1)
)

DECLARE @ABONOS_PAGO TABLE 
(
		id_local [int] IDENTITY (1, 1),
		MOV_TIPOPOL varchar(10),
		MOV_CONSPOL numeric(18,0),
		MOV_CONSMOV numeric(18,0),
		MOV_MES numeric(18,0),
		MOV_NUMCTA varchar(50),
		MOV_DEBE decimal(18,5),
		MOV_HABER decimal(18,5),
		Tipo varchar(1)
)

DECLARE @CARTERA_PAGOS TABLE
(
CCP_CONSCARTERA numeric(18,0),
CCP_TIPOPOL varchar(10),
CCP_CONSPOL numeric(18,0),
CCP_CONSMOV numeric(18,0),
CCP_MES numeric(18,0),
CCP_IDDOCTO varchar(20),
CCP_IDPERSONA numeric(18,0)
)

DECLARE @DOCTOSPAGADOS TABLE
(
dpa_iddocumento varchar(20),
dpa_idpersona int,
dpa_cuentapagadora varchar(20),
dpa_lote int,
dpa_fechaaplicacion datetime,
dpa_pagoaplicado int
)

DECLARE @REGISTROSCONCILIADOS TABLE
(--CCP_TIPOPOL,CCP_CONSPOL,CCP_MES
CCP_TIPOPOL varchar(10),
CCP_CONSPOL numeric(18,0),
CCP_MES numeric(18,0)
)

           select @iIdBanco = idBanco,@iIdEmpresa = idEmpresa, @noCtaContable = cuentaContable from referencias..BancoCuenta where numeroCuenta = @snoCuenta  
		   select @ipServidor = ip_servidor, @stipo_poliza_pago=tipo_poliza_pago, @snombre_base = nombre_base  from Centralizacionv2..DIG_CAT_BASES_BPRO where emp_idempresa = @iIdEmpresa and tipo=2 

			SELECT @ipLocal=local_net_address 
			FROM sys.dm_exec_connections c
			WHERE session_id = @@SPID;
			 

			if (@ipLocal = @ipServidor)
			begin
			   select @ipServidor = '';
			end
			else
				begin
				   select @ipServidor = '[' + @ipServidor + '].'
				end
		   select @snombre_base = '[' + @snombre_base + ']'

		   set @sQ = N'INSERT INTO @ABONOS_COMPLETO (MOV_TIPOPOL,MOV_CONSPOL,MOV_CONSMOV,MOV_MES,MOV_NUMCTA,MOV_DEBE,MOV_HABER,Tipo)'
		   set @sQ = @sQ + N' SELECT MOV_TIPOPOL,MOV_CONSPOL,MOV_CONSMOV,MOV_MES,MOV_NUMCTA,MOV_DEBE,MOV_HABER,''0'' as TIPO FROM ' +ltrim(rtrim(@snombre_base)) + '.DBO.CON_MOVDET01' + Convert(char(4),@iAnio) + ' WHERE MOV_MES = @iMes AND MOV_NUMCTA = @noCtaContable AND MOV_HABER <> 0 '
		   --SELECT *,Tipo='0' INTO #ABONOS_COMPLETO FROM GAAU_Universidad.DBO.CON_MOVDET012018  WHERE MOV_MES = 2 AND MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_HABER > 0
		   execute sp_executesql @sQ,N'@noCtaContable varchar(50),@iMes int',@noCtaContable=@noCtaContable,@iMes=@iMes


		   set @sQ = N'INSERT INTO	@ABONOS_PAGO (MOV_TIPOPOL,MOV_CONSPOL,MOV_CONSMOV,MOV_MES,MOV_NUMCTA,MOV_DEBE,MOV_HABER,Tipo)'
		   set @sQ = @sQ + N' SELECT MOV_TIPOPOL,MOV_CONSPOL,MOV_CONSMOV,MOV_MES,MOV_NUMCTA,MOV_DEBE,MOV_HABER,Tipo from #ABONOS_COMPLETO WHERE MOV_TIPOPOL = @stipo_poliza_pago' 
		   execute sp_executesql @sQ,N'@stipo_poliza_pago varchar(10)',@stipo_poliza_pago=@stipo_poliza_pago
		   --SELECT * INTO #ABONOS_PAGO FROM  #ABONOS_COMPLETO WHERE MOV_TIPOPOL = 'TREEUN'

		   --BUSCO LA CARTERA DE ESTOS PAGOS
		   set @sQ = N'INSERT INTO @CARTERA_PAGOS (CCP_CONSCARTERA,CCP_TIPOPOL,CCP_CONSPOL,CCP_CONSMOV,CCP_MES,CCP_IDDOCTO,CCP_IDPERSONA)'
		   set @sQ = @sQ + N' SELECT CCP_CONSCARTERA,CCP_TIPOPOL,CCP_CONSPOL,CCP_CONSMOV,CCP_MES,CCP_IDDOCTO,CCP_IDPERSONA '			
		   set @sQ = @sQ + N' FROM #ABONOS_PAGO P INNER JOIN ' + @ipServidor + ltrim(rtrim(@snombre_base)) + '.DBO.CON_CAR01' + Convert(char(4),@iAnio) + ' ON MOV_CONSPOL = CCP_CONSPOL AND MOV_MES = CCP_MES'
		   set @sQ = @sQ + N' WHERE CCP_TIPOPOL = @stipo_poliza_pago  AND CCP_MES = @iMes AND CCP_TIPODOCTO = ''PAGO'''
		   execute sp_executesql @sQ,N'@stipo_poliza_pago varchar(10),@iMes int',@stipo_poliza_pago=@stipo_poliza_pago,@iMes=@iMes


		   --BUSCO LOS PAGOS POR TXT POR CUENTA, LA CUENTA ESTA PARAMETRIZADA POR BANCO
			set @sQ = N'INSERT INTO @DOCTOSPAGADOS (dpa_iddocumento,dpa_idpersona,dpa_cuentapagadora,dpa_lote,dpa_fechaaplicacion,dpa_pagoaplicado)'
			set @sQ = @sQ + N' SELECT dpa_iddocumento,dpa_idpersona,dpa_cuentapagadora,dpa_lote,dpa_fechaaplicacion,dpa_pagoaplicado FROM [cuentasxpagar].[dbo].[cxp_doctospagados] D INNER JOIN Pagos.DBO.PAG_LOTE_PAGO ON dpa_lote = pal_id_lote_pago'
			set @sQ = @sQ + N' WHERE Year(dpa_fechaaplicacion)=@iAnio AND Month(dpa_fechaaplicacion)=@iMes AND dpa_cuentapagadora = @snoCuenta AND pal_id_tipoLotePago = 1'
			set @sQ = @sQ + N' AND dpa_pagoaplicado = 1'
			execute sp_executesql @sQ,N'@snoCuenta varchar(50),@iMes int,@iAnio int',@snoCuenta=@snoCuenta,@iMes=@iMes,@iAnio=@iAnio

			--REGISTROS CONCILIADOS
			INSERT INTO @REGISTROSCONCILIADOS (CCP_TIPOPOL,CCP_CONSPOL,CCP_MES)
			SELECT CCP_TIPOPOL,CCP_CONSPOL,CCP_MES FROM @CARTERA_PAGOS INNER JOIN @DOCTOSPAGADOS ON CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS = dpa_iddocumento COLLATE Modern_Spanish_CS_AS
			AND CCP_IDPERSONA = dpa_idpersona GROUP BY  CCP_TIPOPOL,CCP_CONSPOL,CCP_MES


			--CAMBIO EL TIPO DE REGISTRO EN #ABONOS_COMPLETO
			UPDATE @ABONOS_COMPLETO SET Tipo = '1' FROM  @ABONOS_COMPLETO A 
			INNER JOIN @REGISTROSCONCILIADOS C ON  MOV_TIPOPOL = CCP_TIPOPOL AND MOV_MES = CCP_MES AND MOV_CONSPOL = CCP_CONSPOL

			--ABONOS EN CONTABILIDAD NO CONSIDERADOS EN BANCOS
			--SELECT * FROM #ABONOS_COMPLETO WHERE TIPO = 0
			select @dResultado = sum(MOV_HABER) from @ABONOS_COMPLETO WHERE Tipo = @sConciliados
			--ABONOS EN CONTABILIDAD SI CONSIDERADOS EN BANCOS
		    --SELECT * FROM #ABONOS_COMPLETO WHERE TIPO = 1

	set nocount off
end --Del Store

/*
Declare
@iAnio int,
@iMes int,
@snoCuenta varchar(100),
@sConciliados varchar(1),
@dResultado numeric(18,6)

select @iAnio = 2018
select @iMes = 2
select @snoCuenta ='000000000195334667'  --'000000000195334667'  --Bancomer Suzuky  --Santander Suzuky 65504258249
select @sConciliados = '0' --0 No CONSIDERADOS en Bancos, 1 Si Considerados
select @dResultado = 0


execute [SEL_ABONOSCONTABLES_NOBANCOS]  @iAnio, @iMes,@snoCuenta,@sConciliados, @dResultado Output
print 'Resultado: ' + CAST(CONVERT(varchar, CAST(@dResultado AS money), 1) AS varchar)




*/
go

