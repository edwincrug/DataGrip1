
/*******************************************************************************************************************/
--                                 CREANDO FUNCIONES
/*******************************************************************************************************************/
CREATE FUNCTION [dbo].[fn_BuscaLetras] (@str varchar(100)) 
RETURNS VARCHAR (3) 
AS 
BEGIN 
--DECLARE @STR AS VARCHAR(50) 
--SET @STR='HYHYHHA564564568239' 

DECLARE @CUENTA AS TINYINT
DECLARE @NUMEROS AS VARCHAR(100)
SET @NUMEROS=''
SET @CUENTA=1

WHILE (@CUENTA < 100)
BEGIN
IF SUBSTRING(@STR, @CUENTA,1) IN ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z')
SET @NUMEROS = @NUMEROS + SUBSTRING(@STR, @CUENTA,1)

SET @CUENTA=@CUENTA+1
END

RETURN @NUMEROS

END

go

