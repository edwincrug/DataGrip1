-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[INS_BITACORA_PUBLICA_INTELIMOTORS]
	@tipoAccion VARCHAR(1000),
	@vin VARCHAR(150),
	@unitId VARCHAR(200)

AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [expedienteSeminuevo].[bitacoraPublicaIntelimotor]
           ([accionPublica]
           ,[vinPublica]
           ,[unidIdPublica]
           ,[fechaPublica])
     VALUES
           (@tipoAccion
           ,@vin
           ,@unitId
           ,GETDATE())

	SELECT success = 1;
END

go

