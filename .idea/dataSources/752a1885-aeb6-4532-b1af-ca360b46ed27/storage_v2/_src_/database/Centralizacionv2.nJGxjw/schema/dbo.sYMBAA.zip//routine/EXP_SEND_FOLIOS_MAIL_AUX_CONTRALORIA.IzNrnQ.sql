-- =============================================
-- Author:
-- Create date:
-- Description:
-- =============================================
CREATE PROCEDURE dbo.EXP_SEND_FOLIOS_MAIL_AUX_CONTRALORIA
AS
BEGIN
		DECLARE @maxDays INT;
		DECLARE @tblContralor AS TABLE (nombre VARCHAR(50), correo VARCHAR(50), idEmpresa int)

		SELECT @maxDays = par_valor FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MAXESCALAR';

		--INSERT INTO @tblContralor
		--SELECT UPPER(usu_nombre + ' ' + usu_paterno + ' ' + usu_materno), U.usu_correo, cat_nombre idEmpresa
		--FROM Centralizacionv2.dbo.DIG_CATALOGOS C
		--INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = C.cat_valor
		--WHERE cat_id_padre = 2650

		SELECT      CD.ucn_noserie AS folio,
					C.ucu_idusuarioalta,
					ISNULL(PP.PER_NOMRAZON + ' ' + PP.PER_PATERNO + ' ' + PP.PER_MATERNO,'SIN AGENTE') AS nombre,
					ISNULL(PP.PER_Email, 'notiene@notiene.com') usu_correo,
					--U.usu_correo,
					C.ucu_idempresa,
					C.ucu_idsucursal,
					B.nombre_sucursal,
					C.ucu_idcliente,
					P.PER_NOMRAZON + ' ' + P.PER_PATERNO + ' ' + P.PER_MATERNO AS NombreCliente,
					C.ucu_foliocotizacion,
					convert(VARCHAR(10),VW.PEN_FECHAENTREGA_REAL,103) AS PEN_FECHAENTREGA_REAL,
					CD.ucn_idFactura,
					CO.nombre auxNombre,
					CO.correo auxCorreo,
					UPPER(Marca) Marca
					--(SELECT nombre FROM [DATOS_PUESTOS](135, C.ucu_idempresa, C.ucu_idsucursal)) auxNombre,
					--(SELECT correo FROM [DATOS_PUESTOS](135, C.ucu_idempresa, C.ucu_idsucursal)) auxCorreo
		FROM EXP_FOLIOS_MAIL M
					INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = M.folio COLLATE DATABASE_DEFAULT
					INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
					INNER JOIN GA_Corporativa.DBO.PER_PERSONAS PP ON PP.PER_IDPERSONA = C.ucu_idagente
					INNER JOIN @tblContralor CO ON CO.idEmpresa = C.ucu_idempresa
					INNER JOIN GA_Corporativa.DBO.PER_PERSONAS P ON P.PER_IDPERSONA = C.ucu_idcliente
					--INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = C.ucu_idusuarioalta
					INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = C.ucu_idempresa AND B.suc_idsucursal = C.ucu_idsucursal
					INNER JOIN [VW_FECHA_ENTREGA_UNIDAD] VW ON VW.PEN_NUMSERIE = CD.ucn_noserie AND ucu_idusuarioalta NOT IN (0) AND VW.PEN_FECHAENTREGA_REAL IS NOT NULL
					INNER JOIN Centralizacionv2.dbo.PPRO_RFCRECEPTOR R on C.ucu_idempresa = R.IDEMPRESA
		WHERE M.dias > @maxDays
		GROUP BY ucu_idusuarioalta, CD.ucn_noserie,PP.PER_EMAIL, PP.PER_NOMRAZON,PP.PER_PATERNO,PP.PER_MATERNO, C.ucu_idempresa, C.ucu_idsucursal, B.nombre_sucursal,CO.nombre ,
					CO.correo, C.ucu_idcliente, P.PER_NOMRAZON, P.PER_PATERNO, P.PER_MATERNO,C.ucu_foliocotizacion,CD.ucn_idFactura,PEN_FECHAENTREGA_REAL, Marca
		ORDER BY 5,6 ASC
		--DECLARE @maxDays INT;
		--SELECT
		-- @maxDays = par_valor
		--FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MAXESCALAR';
		--SELECT
		-- CD.ucn_noserie AS folio,
		-- C.ucu_idusuarioalta,
		-- U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS nombre,
		-- U.usu_correo,
		-- C.ucu_idempresa,
		-- C.ucu_idsucursal,
		-- B.nombre_sucursal,
		-- (SELECT nombre FROM [DATOS_PUESTOS](135, C.ucu_idempresa, C.ucu_idsucursal)) auxNombre,
		-- (SELECT correo FROM [DATOS_PUESTOS](135, C.ucu_idempresa, C.ucu_idsucursal)) auxCorreo
		--FROM EXP_FOLIOS_MAIL M
		--INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = M.folio COLLATE DATABASE_DEFAULT
		--INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
		--INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = C.ucu_idusuarioalta
		--INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = C.ucu_idempresa AND B.suc_idsucursal = C.ucu_idsucursal
		--WHERE M.dias > @maxDays
		--GROUP BY ucu_idusuarioalta, CD.ucn_noserie, U.usu_correo, U.usu_nombre, U.usu_paterno, U.usu_materno, U.usu_correo, C.ucu_idempresa, C.ucu_idsucursal, B.nombre_sucursal
		--ORDER BY 5 ASC
END
go

