-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST [expedienteSeminuevo].[SEL_UNIDAD_FACTURADA_SP] '3N1CN7AD4GK458347', 4, 6
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_UNIDAD_FACTURADA_SP]
	@vin VARCHAR(150), 
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @base VARCHAR(150) = '', @query NVARCHAR(MAX) = '', @totalFacturas INT;

	SELECT 
		@base = nombre_base
	FROM DIG_CAT_BASES_BPRO 
	WHERE emp_idEmpresa = @idEmpresa AND suc_idSucursal = @idSucursal;

	SET @query = 'SELECT
					@totaL = COUNT(VTE_SERIE)
				FROM [' + @base + '].[DBO].[ADE_VTAFI] 
				WHERE VTE_SERIE = ''' + @vin + '''' +
				' AND VTE_STATUS = ''I'''

	EXEC sp_executesql @query, N'@totaL INT OUTPUT', @totaL = @totalFacturas OUTPUT

	IF( @totalFacturas > 0 )
		BEGIN
			--SELECT success = 1, msg = 'Atención: La unidad fue facturada, ya no se pueden realizar modificaciones en el expediente.'
			SELECT success = 0, msg = '';
		END
	ELSE
		BEGIN
			SELECT success = 0, msg = '';
		END
END
go

