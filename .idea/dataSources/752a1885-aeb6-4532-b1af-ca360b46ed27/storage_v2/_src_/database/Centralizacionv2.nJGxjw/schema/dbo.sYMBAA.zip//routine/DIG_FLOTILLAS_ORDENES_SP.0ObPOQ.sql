-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- DIG_FLOTILLAS_ORDENES_SP 'AU-HY-HEC-UN-2120'   Primeras Pruebas -->   'AU-ZM-NZA-UN-7503'
-- =============================================
CREATE PROCEDURE [dbo].[DIG_FLOTILLAS_ORDENES_SP]
	@cotizacionGlobal VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	--DECLARE @numeroFlotilla INT, @ordenCompraRef INT, @floIdEmpresa INT, @floIdSucursal INT;

	--SELECT 
	--	@numeroFlotilla = flo_numeroflotilla,
	--	@floIdEmpresa = flo_idempresa,
	--	@floIdSucursal = flo_idsucursal
	--FROM cuentasxpagar.dbo.cxp_flotillas 
	--WHERE flo_idcotizacionglobal = @cotizacionGlobal

	--SELECT 
	--	@ordenCompraRef = ocr_idordencomprefacciones
	--FROM cuentasxpagar.dbo.cot_ordencomprefacciones 
	--WHERE ocr_idcotizacionglobal = @cotizacionGlobal

	--SELECT	
	--	DISTINCT OC.oce_folioorden AS Folio_Operacion
	--	,OC.oce_idtipoorden  AS tipoorden
	--	,CONVERT(VARCHAR(20), OC.oce_fechaorden,103)  AS oce_fechaorden
	--	,SITOR.sod_nombresituacion  AS situacionOrden
	--	,OC.oce_idproveedor  AS idProveedor
	--	,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--
	--	,OC.oce_importetotal AS oce_importetotal
	--	,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
	--	ELSE 0 
	--	END AS esPlanta
	--	,OC.oce_idempresa AS idEmpresa
	--	,OC.oce_idsucursal AS idSucursal
	--	,OC.oce_iddepartamento AS idDepartamento
	--	,EMP.emp_nombre  AS empNombre
	--	,SUC.suc_nombre AS sucursal
	--	,DEP.dep_nombre AS depto 
	--FROM [DBO].[DIG_EXPEDIENTE] AS  E
	--	RIGHT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
	--	INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] AS OPE ON OPE.usu_idusuario = 71 AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
	--	INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
	--	INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
	--	INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
	--	INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
	--	INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER-- ON OC.oce_idproveedor =  PER.PER_IDPERSONA  -- [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor				
	--WHERE OC.oce_numeroflotilla = @numeroFlotilla AND oce_idempresa = @floIdEmpresa AND oce_idsucursal = @floIdSucursal

	DECLARE @idEmpresa INT, @idSucursal INT,  @base VARCHAR(100);
	DECLARE @query VARCHAR(MAX) = '';

	SELECT 
		 @idEmpresa = ucu_idempresa,
		 @idSucursal = ucu_idsucursal
	FROM cuentasporcobrar.dbo.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @cotizacionGlobal

	SELECT 
		@base = nombre_base 
	FROM DIG_CAT_BASES_BPRO WHERE emp_idEmpresa = @idEmpresa AND suc_idSucursal = @idSucursal

	SET @query = 'SELECT 
				DISTINCT OC.oce_folioorden AS Folio_Operacion
				,OC.oce_idtipoorden  AS tipoorden
				,CONVERT(VARCHAR(20), OC.oce_fechaorden,103)  AS oce_fechaorden
				,SITOR.sod_nombresituacion  AS situacionOrden
				,OC.oce_idproveedor  AS idProveedor
				,RTRIM(LTRIM(PER.PER_NOMRAZON +' + ''' ''' + ' + PER.PER_PATERNO + ' + ''' ''' + ' + PER.PER_MATERNO)) as Proveedor
				,OC.oce_importetotal AS oce_importetotal
				,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
				ELSE 0 
				END AS esPlanta
				,OC.oce_idempresa AS idEmpresa
				,OC.oce_idsucursal AS idSucursal
				,OC.oce_iddepartamento AS idDepartamento
				,EMP.emp_nombre  AS empNombre
				,SUC.suc_nombre AS sucursal
				,DEP.dep_nombre AS depto 
			  FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU
			  INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CUD ON CUD.ucu_idcotizacion = CU.ucu_idcotizacion
			  INNER JOIN [' + @base + '].[DBO].[SER_VEHICULO] V ON V.VEH_NUMSERIE = CUD.ucn_noserie
			  RIGHT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] OC ON OC.oce_folioorden = V.veh_folioorden COLLATE DATABASE_DEFAULT
			  INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
			  INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
			  INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
			  INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
			  INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA
			  WHERE CU.ucu_foliocotizacion = ''' + @cotizacionGlobal + ''''

	EXEC(@query)

	SELECT 
		DISTINCT REF.ocr_folioorden AS Folio_Operacion,
		ocrd_idparte,
		ocrd_desparte,
		ocrd_costo,
		0 esPlanta
	FROM cuentasxpagar.dbo.cot_ordencomprefacciones REF
	INNER JOIN cuentasxpagar.dbo.cot_ordencomprefaccionesdet DET ON DET.ocr_idordencomprefacciones = REF.ocr_idordencomprefacciones
	WHERE ocr_idcotizacionglobal = @cotizacionGlobal

	SELECT 
		CUD.ucn_idcotizadetalle,
		CUD.ucn_idcatalogo,
		CUD.ucn_modelo,
		CUD.ucn_noserie 
	FROM cuentasporcobrar.dbo.uni_cotizacionuniversal CU
	INNER JOIN cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES CUD ON CUD.ucu_idcotizacion = CU.ucu_idcotizacion
	WHERE ucu_foliocotizacion = @cotizacionGlobal
END
go

