CREATE PROCEDURE [dbo].[INS_CORREOS_ALTERNATIVOS_SP]
@ppro_user VARCHAR(15),
@correo NVARCHAR(50), 
@idTipoCorreo INT
AS
BEGIN
	INSERT INTO UsuarioCorreo VALUES (@ppro_user, @correo, @idTipoCorreo)
	SELECT @correo   Mensaje
END
go

