-- ===================================================================================================
-- Author:	     Lourdes Maldonado Sanchez 
-- Date:         09/01/2019 
-- Description:  Regreso el UUID de la orden de Compra
-- ===================================================================================================
-- EXECUTE [dbo].[PPROV_RECUPERA_UUID]  'AU-AU-UNI-OT-PE-4' 
CREATE PROCEDURE [dbo].[PPROV_RECUPERA_UUID]
       @orden       VARCHAR(20) = NULL
AS	    
BEGIN
     DECLARE @UUID  VARCHAR(50) = NULL  

      IF EXISTS( SELECT [uuid] FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] WHERE [folioorden] =  @orden)
      BEGIN
		  SELECT @UUID = [uuid] 
			FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]
		   WHERE [folioorden] =  @orden

          SELECT 1 AS existe, @UUID AS uuid
      END
	  ELSE
	  BEGIN
		  SELECT 0 AS existe, 'N/A' AS uuid
	  END
END
go

