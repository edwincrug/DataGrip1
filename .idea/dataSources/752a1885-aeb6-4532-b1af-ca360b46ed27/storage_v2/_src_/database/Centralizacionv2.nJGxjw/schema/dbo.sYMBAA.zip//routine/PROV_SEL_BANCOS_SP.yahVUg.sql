
CREATE PROCEDURE [dbo].[PROV_SEL_BANCOS_SP] 
--@nombreBD VARCHAR(50)


AS
BEGIN
--DECLARE @sql VARCHAR(500)
BEGIN TRY

SELECT	pbx_numoficial cveBanxico
		,pbx_descripcion nombreBanco
		,pbx_par_idenpara cveBanco
		 FROM Pagos.[dbo].[PAG_CAT_BANXICO]
		 ORDER BY  nombreBanco
	--SET @sql = 'SELECT   PAR_IDENPARA cveBanco
	--					,PAR_DESCRIP1 nombreBanco
	--					,PAR_DESCRIP5 cveBanxico 
	--			FROM '+ @nombreBD +'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' 
	--			AND PAR_IDMODULO = ''CXC'' ORDER BY PAR_DESCRIP1'

	--EXEC (@sql)
END TRY
BEGIN CATCH
	SELECT -1 result
END CATCH
	
END
go

