-- =============================================
-- Author:		<Aldo Ortiz>
-- Create date: <11/06/20>
-- Description:	<SP que ingresa un documento para el expediente>
-- EXEC [expedienteSeminuevo].[INS_DOCUMENTO_EXPEDIENTE] 1, 1, 1, 1, '', 'Prueba.pdf', 71
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[INS_DOCUMENTO_EXPEDIENTE]
	@id_expediente INT,
	@id_documento INT,
	@id_proceso INT,
	@id_estatus INT,
	@observacionesDocumento VARCHAR(MAX),
	@nombreDocumento VARCHAR(200),
	@idUsuario INT
AS
BEGIN
	BEGIN TRY
        INSERT INTO [expedienteSeminuevo].[documentosExpediente] (
            [id_expediente],
            [id_documento],
            [id_proceso],
            [id_estatus],
            [observacionesDocumento],
			[nombreDocumento],
			[idUsuario]
        ) VALUES (
            @id_expediente,
            @id_documento,
            @id_proceso,
            @id_estatus,
            @observacionesDocumento,
			@nombreDocumento,
			@idUsuario
        )
    
		SELECT success = 1
	END TRY
	BEGIN CATCH
		PRINT (ERROR_MESSAGE())
		SELECT success = 0
	END CATCH
END

go

