


CREATE PROCEDURE [dbo].[PROV_SEL_TIPOCUENTA_SP]-- 12
@idProspecto INT 


AS
BEGIN

BEGIN TRY

	

	
	
	SELECT cveTipoCuenta 
		   ,tipoCuenta
		  , modulo
	from PROV_CAT_TIPO_CUENTA
	
	
	

END TRY
BEGIN CATCH
	SELECT -1 result
END CATCH
	
END
go

