-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 27/01/2016
-- Description:	Recupera los Flujos de Orden, Remision y Factura en diferentes sentidos Adelante o atras
-- =============================================
--EXECUTE [dbo].[SEL_NAVEGACION_NODOS_SP] 'AU-ZM-ZAR-RE-IF-8',14,4   
--AU-ZM-ZAR-RE-PE-26 ORD
--AU-ZM-ZAR-RE-PI-10 REM
--AU-ZM-ZAR-RE-IF-8  FAC
CREATE PROCEDURE [dbo].[SEL_NAVEGACION_NODOS_SP]
	 @folio				nvarchar(50) = ''
	,@idnodoActual		int = 0  --Nodo_actual
	,@idnodoDestino		int = 0  --Nodo_destino

AS
BEGIN
  DECLARE @corte1     INT= 6
  DECLARE @corte2     INT= 13
  DECLARE @grupo     VARCHAR(20)= NULL


	SET NOCOUNT ON;
		BEGIN TRY
		
		IF(@idnodoDestino <= @corte1 AND @idnodoActual <= @corte1)
		   SET @grupo ='Misma Orden'
        ELSE IF (@idnodoDestino > @corte1 AND @idnodoDestino <= @corte2 AND @idnodoActual > @corte1 AND  @idnodoActual <= @corte2)
		         SET @grupo ='Misma Remision'
             ELSE IF (@idnodoDestino > @corte2 AND  @idnodoActual > @corte2)
		              SET @grupo ='Misma Factura'

        SELECT @grupo Grupo
	 
	    --Comenzamos salto hacia adelante	     
		IF ((@idnodoDestino - @idnodoActual) > 0 AND @grupo IS NULL)
		BEGIN
					-------------------------------------------------------
					--Tengo una Orden y se desglosa en N Remisiones
					--EXECUTE [dbo].[SEL_NAVEGACION_NODOS_SP] 'AU-ZM-ZAR-RE-PE-26',1,14
					-------------------------------------------------------
					IF (@idnodoActual <= @corte1 AND @idnodoDestino > @corte1 AND @idnodoDestino <= @corte2 )
					BEGIN
						SELECT [irr_folioinicial]  ORDEN    --Folio_Orden 
							   ,[irr_folionuevo]   REMISION --Folio_Remision 
						  FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac]
						 WHERE [irr_folioinicial] = @folio  --Var_Orden
						GROUP BY  [irr_folioinicial]
								 ,[irr_folionuevo]
					END
					-------------------------------------------------------
					--Tengo una Remision y se desglosa en N Facturas
					--EXECUTE [dbo].[SEL_NAVEGACION_NODOS_SP] 'AU-ZM-ZAR-RE-PI-10',10,2
					-------------------------------------------------------
					ELSE IF (@idnodoActual > @corte1 AND @idnodoActual <= @corte2 AND @idnodoDestino > @corte2)
					BEGIN
						SELECT [ifr_folioinicial] REMISION --Folio_Remision
							  ,[ifr_folionuevo]   FACTURA  --Folio_Factura
						  FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac]
						 WHERE [ifr_folioinicial] = @folio --Var_Remision
					  GROUP BY [ifr_folioinicial]
							  ,[ifr_folionuevo]
					END
					-------------------------------------------------------
					--Tengo una Orden y se desglosa en N Facturas
					--EXECUTE [dbo].[SEL_NAVEGACION_NODOS_SP] 'AU-ZM-ZAR-RE-PE-26',4,14 
					-------------------------------------------------------
					ELSE IF (@idnodoActual <= @corte1 AND @idnodoDestino > @corte2 )
					BEGIN
					SELECT [irr_folioinicial]  ORDEN     --Folio_Orden 
						  ,[irr_folionuevo]   REMISION   --Folio_Remision 
						  ,[ifr_folionuevo]   FACTURA
					 FROM  [cuentasxpagar].[dbo].[cxp_integracionremrefac]
						  ,[cuentasxpagar].[dbo].[cxp_integracionfacrefac]
					WHERE [irr_folionuevo]   = [ifr_folioinicial] --Folio_Remision
					  AND [irr_folioinicial] = @folio             --Var_Orden
					GROUP BY    [irr_folioinicial]
								,[irr_folionuevo]
								,[ifr_folionuevo]
                    END

		END
		--Comenzamos salto hacia atras
		ELSE IF ((@idnodoActual - @idnodoDestino) > 0 AND @grupo IS NULL)
		BEGIN
		            -------------------------------------------------------
					--Tengo una Factura y se desglosa en N Remisiones
					--EXECUTE [dbo].[SEL_NAVEGACION_NODOS_SP] 'AU-ZM-ZAR-RE-IF-8',13,8 
					-------------------------------------------------------
					IF (@idnodoActual > @corte2 AND @idnodoDestino > @corte1 AND @idnodoDestino <= @corte2 )
					BEGIN
					    SELECT 'ATRAS: Tengo una Factura y se desglosa en N Remisiones' Paso
						SELECT [ifr_folionuevo]   FACTURA  --Folio_Factura
							  ,[ifr_folioinicial] REMISION --Folio_Remision
						  FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac]
						 WHERE [ifr_folionuevo]  = @folio --Var_Factura
					  GROUP BY [ifr_folionuevo]
							  ,[ifr_folioinicial]
					END

					-------------------------------------------------------
					--Tengo una Remision y se desglosa en N Ordenes
					--EXECUTE [dbo].[SEL_NAVEGACION_NODOS_SP] 'AU-ZM-ZAR-RE-PI-10',10,4
					-------------------------------------------------------
                    ELSE IF (@idnodoActual > @corte1 AND @idnodoActual <= @corte2 AND @idnodoDestino <= @corte1 )
					BEGIN
					    SELECT 'ATRAS: Tengo una Remision y se desglosa en N Ordenes' Paso
						SELECT  [irr_folionuevo]   REMISION  --Folio_Remision 
							   ,[irr_folioinicial] ORDEN     --Folio_Orden
						  FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac]
						 WHERE [irr_folionuevo] = @folio  --Var_Remision
						GROUP BY  [irr_folionuevo] 
							     ,[irr_folioinicial]
					END
					-------------------------------------------------------
					--Tengo una Factura y se desglosa en N Ordenes
					--EXECUTE [dbo].[SEL_NAVEGACION_NODOS_SP] 'AU-ZM-ZAR-RE-IF-8',14,3
					-------------------------------------------------------
					ELSE IF (@idnodoActual > @corte2 AND @idnodoDestino <= @corte1 )
					BEGIN
					    SELECT 'ATRAS: Tengo una Factura y se desglosa en N Ordenes' Paso
						SELECT  [ifr_folionuevo]   FACTURA    --Folio_Factura
							   ,[irr_folionuevo]   REMISION --Folio_Remision 
							   ,[irr_folioinicial]  ORDEN     --Folio_Orden 
						  FROM   [cuentasxpagar].[dbo].[cxp_integracionremrefac]
					    		,[cuentasxpagar].[dbo].[cxp_integracionfacrefac]
						 WHERE [irr_folionuevo] = [ifr_folioinicial] --Folio_Remision
						   AND [ifr_folionuevo] = @folio             --Var_Factura
						GROUP BY [ifr_folionuevo]
						        ,[irr_folionuevo]
								,[irr_folioinicial]
                    END
       END
	END TRY
	
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_NAVEGACION_NODOS_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

