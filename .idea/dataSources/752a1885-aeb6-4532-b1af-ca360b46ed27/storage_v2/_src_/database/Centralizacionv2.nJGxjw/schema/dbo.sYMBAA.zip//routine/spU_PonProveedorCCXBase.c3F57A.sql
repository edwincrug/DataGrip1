/*
Establece el proveedor de los CC´s de una Base de datos.
Valida que la base de datos tenga la tabla PNC_PARAMETR
Solo trabaja sobre el parametro Ccsconf

Declare @sBase varchar(50) = 'GAZM_Zaragoza';
Declare @iProveedor_id int = 2020;  
Declare @sMes varchar(2) = '01'; -- solo sirve para mandar un mensaje de confirmacion. 
Declare @iError int = 0;

Execute Centralizacionv2.dbo.spU_PonProveedorCCXBase @sBase,@iProveedor_id,@sMes,@iError OUTPUT
print Convert(char(2),@iError)

*/

CREATE PROCEDURE [dbo].[spU_PonProveedorCCXBase](@sBase varchar(50),@iProveedor_id int,@sMes varchar(2), @iResultado int OUTPUT) --with recompile
 AS
declare
@iIndice int,
@sTabla varchar(200),
@situa varchar(20),
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500)

begin 
set nocount on

DECLARE @db_id int;  
DECLARE @object_id int;  
SET @db_id = DB_ID(@sBase);  
set @sTabla = @sBase + '.dbo.PNC_PARAMETR' 
SET @object_id = OBJECT_ID(@sTabla);  

--print 'El id de la tabla:' + convert(varchar(50),@object_id)

IF @db_id IS NULL   
  BEGIN;  
    PRINT N'No se encuentra la Base de datos: ' + @sBase; 
	select @iResultado = 1 
  END;  
ELSE IF @object_id IS NULL  
  BEGIN;  
    PRINT N'La base de datos: ' +  @sBase + ' No tiene la tabla PNC_PARAMETR';  
	select @iResultado = 2
  END;  
ELSE  
  BEGIN; 
	
			    Declare @sPAR_IMPORTE1 decimal(18,5) = 0;

				--update GAAT_Peugeot..pnc_parametr set PAR_IMPORTE1=14489  where PAR_TIPOPARA = 'ccsconf' and PAR_IMPORTE1=69720
				--Select TOP 1 PAR_IMPORTE1 from GAZM_Zaragoza..PNC_PARAMETR where PAR_TIPOPARA = 'Ccsconf'
       			set @sQ = N'Select distinct @ssPAR_IMPORTE1  = PAR_IMPORTE1 from ' + @sTabla
				set @sQ = @sQ + N' where par_tipopara=' + char(39) +  'Ccsconf' + char(39) 
				set @sParmDefinition = N'@ssPAR_IMPORTE1 decimal(18,5) OUTPUT'
				--print @sQ
				--print @sParmDefinition
				execute sp_executesql @sQ,@sParmDefinition, @ssPAR_IMPORTE1 = @sPAR_IMPORTE1 OUTPUT
				print 'Proveedor actual para: ' + @sTabla  + ' es : ' + ltrim(rtrim(Convert(char(18),@sPAR_IMPORTE1)))
				  --solo actualizamos si el proveedor actual es diferente del que se pasa como parámetro.
				  if (CONVERT(int,@sPAR_IMPORTE1) <> @iProveedor_id)
				   begin
						set @sQ = N'UPDATE ' + @sTabla + ' SET PAR_IMPORTE1=' + ltrim(rtrim(Convert(char(18),@iProveedor_id)))
						set @sQ = @sQ + N' where par_tipopara=' + char(39) + 'Ccsconf' + char(39) + ' AND PAR_IMPORTE1=' + ltrim(rtrim(Convert(char(18),@sPAR_IMPORTE1)))			    
						execute sp_executesql @sQ

							--Validamos que el cambio se haya realizado
						   select @sPAR_IMPORTE1 = 0;
						   set @sQ = N'Select distinct @ssPAR_IMPORTE1  = PAR_IMPORTE1 from ' + @sTabla
						   set @sQ = @sQ + N' where par_tipopara=' + char(39) +  'Ccsconf' + char(39) 
						   set @sParmDefinition = N'@ssPAR_IMPORTE1 decimal(18,5) OUTPUT'
						   execute sp_executesql @sQ,@sParmDefinition, @ssPAR_IMPORTE1 = @sPAR_IMPORTE1 OUTPUT
				   
						   if (CONVERT(int,@sPAR_IMPORTE1) = @iProveedor_id)
						   begin
								select @iResultado = 0;
								print 'Se establecio el Proveedor de CC´s para: ' + @sBase + ' del Mes: ' + @sMes + ' en: ' + ltrim(rtrim(Convert(char(18),@sPAR_IMPORTE1)))
						   end
						   else
						   begin
								 select @iResultado = 1;
								 print 'No se establecio el Proveedor de CC´s, sucedio un error el proveedor que se queda es: ' + ltrim(rtrim(Convert(char(18),@sPAR_IMPORTE1)))
						   end				
				   end
				   else
				   begin
				     print 'El proveedor es el mismo que el que ya está registrado no se modifica nada.'
					 select @iResultado = 0;
				   end 	
  END;  

Return @iResultado

set nocount off
end
go

