

CREATE PROCEDURE [dbo].[UPD_FOLIO_EXPEDIENTE_DOCUMENTO_SP]
 @folio VARCHAR (50)
,@Doc_id INT
AS
BEGIN
 
	UPDATE	Centralizacionv2.dbo.DIG_EXPNODO_DOC 
	SET		Fecha_Creacion =  GETDATE() 
	WHERE	Folio_Operacion = @folio 
	AND		Doc_Id = @Doc_id

END
go

