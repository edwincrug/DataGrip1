CREATE PROCEDURE [dbo].[SEL_REGLA_ESCALAMIENTO_SP] 
	@emp_idempresa int,
	@suc_idsucursal int,
	@dep_iddepartamento int,
	@tipo_idtipoorden int
AS
BEGIN

	SET NOCOUNT ON;

	select DIE.Nivel_Escalamiento AS nivel,
		   UC1.usu_nombreusu +  ' ' + UC1.usu_paterno + ' ' + UC1.usu_materno AS usuarioAutoriza1,
		   UC2.usu_nombreusu +  ' ' + UC2.usu_paterno + ' ' + UC2.usu_materno AS usuarioAutoriza2,
		   UC3.usu_nombreusu +  ' ' + UC3.usu_paterno + ' ' + UC3.usu_materno AS usuarioAutoriza3,
		   Minutos_Escalar AS minutos,
		   'Nivel '+ CONVERT(VARCHAR(10),DIE.Nivel_Escalamiento) AS nivelTexto,
		   UC1.usu_idusuario AS idUsuarioAutoriza1,
		   UC2.usu_idusuario AS idUsuarioAutoriza2,
		   UC3.usu_idusuario AS idUsuarioAutoriza3
	from DIG_ESCALAMIENTO DIE
	LEFT JOIN [dbo].[Usuario_ControlAplicaciones] UC1 on UC1.usu_idusuario = die.Usuario_Autoriza1
	LEFT JOIN [dbo].[Usuario_ControlAplicaciones] UC2 on UC2.usu_idusuario = die.Usuario_Autoriza2
	LEFT JOIN [dbo].[Usuario_ControlAplicaciones] UC3 on UC3.usu_idusuario = die.Usuario_Autoriza3
	where DIE.suc_idsucursal = @suc_idsucursal 
	AND	DIE.dep_iddepartaamento = @dep_iddepartamento 
	AND DIE.tipo_idtipoorden = @tipo_idtipoorden
	AND DIE.emp_idempresa = @emp_idempresa
END
go

