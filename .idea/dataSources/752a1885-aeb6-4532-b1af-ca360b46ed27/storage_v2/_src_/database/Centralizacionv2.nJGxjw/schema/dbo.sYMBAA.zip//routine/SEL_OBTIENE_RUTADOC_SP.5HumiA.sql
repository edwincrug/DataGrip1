
CREATE PROCEDURE [dbo].[SEL_OBTIENE_RUTADOC_SP]
@folio VARCHAR(50) = '',
@idDocumento INT = 0	

AS
	--DECLARE @folio VARCHAR(50) = 'AU-AU-UNI-RE-PE-14'	
	DECLARE @ipServerWeb VARCHAR(30) = '192.168.20.89'
	DECLARE	@nombreArchivo VARCHAR(100) = '' --rfc_emisor +  FROM PPRO_DATOSFACTURAS WHERE [folioorden]
	DECLARE @fecha VARCHAR(100) = '', @rfc_receptor VARCHAR(20) = ''
	
	SELECT @nombreArchivo = rfc_emisor + '_' + CASE folio 
											WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
											ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
										 END,
		   @fecha = CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' +SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2),
		   @rfc_receptor = rfc_receptor
	FROM PPRO_DATOSFACTURAS WHERE [folioorden] = @folio	
	
	--SELECT 'http:\\'+ @ipServerWeb +'\GA_Centralizacion\FacturasProveedores\'+ @rfc_receptor +'\'+ @fecha + '\' ruta, @nombreArchivo + '.pdf' pdf
	SELECT 'E:\GA_Centralizacion\FacturasProveedores\'+ @rfc_receptor +'\'+ @fecha + '\' ruta, @nombreArchivo + '.pdf' pdf

go

