-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	Obtiene los anticipos que pueden ser aplicados 
-- =============================================
--[dbo].[SEL_RESUMEN_ANTICIPOS_SP] 'AA000000015', 'AU-AZ-ZAR-UN-1'
CREATE PROCEDURE [dbo].[SEL_RESUMEN_ANTICIPOS_SP]	
	@factura NVARCHAR(50) 
	,@folio NVARCHAR(50)
AS
BEGIN
	------------------------------------------------------------
	--Otengo la ip del servidor + el nombre de la base de la sucursal y el id de la cotizacion 
	------------------------------------------------------------
	DECLARE @baseSucursal VARCHAR(100) 
			,@idCotizacion INT
	
	SELECT	@idCotizacion = ucu_idcotizacion
	FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL
	WHERE	ucu_foliocotizacion = @folio

	set @baseSucursal = [dbo].[base_Cotizacion](@folio)

	PRINT	@baseSucursal

	--SELECT	@baseSucursal = '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' 
	--		,@idCotizacion = ucu_idcotizacion
	--FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL CU
	--		INNER JOIN DIG_CAT_BASES_BPRO PRO ON CU.ucu_idempresa = PRO.emp_idEmpresa AND CU.ucu_idsucursal = PRO.suc_idSucursal AND PRO.estatus = 1 AND PRO.tipo = 1
	--WHERE ucu_foliocotizacion = @folio
	--PRINT @baseSucursal
	-----------------------------------------------------------
	--Obtengo anticipo relacionado a la cotizacion 
	-----------------------------------------------------------
	DECLARE @anticipo VARCHAR(MAX)
			,@idAnticipo VARCHAR(50)
			,@max INT
			,@contador INT = 1
	DECLARE @auxiliar TABLE(id INT IDENTITY(1,1),idAnticipo VARCHAR(50))
	SET @anticipo = 'SELECT PAM_IDDOCTO FROM '+ @baseSucursal +'CXC_PAGANT WHERE PAM_IDCOTIZACIONWEB = '+CONVERT(VARCHAR(50),@idCotizacion)+''
	INSERT INTO @auxiliar
	EXECUTE(@anticipo)
	SELECT @max = COUNT(id) FROM @auxiliar
	DECLARE @diferencia NUMERIC(18,2)
			,@diferenciString NVARCHAR(MAX)
	DECLARE @auxiliarNumerico TABLE(monto NUMERIC(18,2))
	DECLARE @resumenAnticipo TABLE (tipoPago VARCHAR(100),tipoDocumento VARCHAR(100),idDocumento VARCHAR(100), fecha VARCHAR(20), saldo NUMERIC(18,2),abono NUMERIC(18,2))
	WHILE(@contador <= @max)
		BEGIN
			SELECT @idAnticipo = idAnticipo FROM @auxiliar WHERE id = @contador 
			PRINT @idAnticipo
			-----------------------------------------------------------
			--Obtengo la diferencia del anticipo
			-----------------------------------------------------------
			SET @diferenciString =	'SELECT	SUM(CCP_ABONO) - SUM(CCP_CARGO)  ' + char(13) + 
									'FROM	'+@baseSucursal+'VIS_CONCAR01  AS Car_Externa ' + char(13) + 
									'		INNER JOIN '+@baseSucursal+'pnc_parametr As A ON CCP_CARTERA = A.PAR_IDENPARA ' + char(13) + 
									'		LEFT OUTER JOIN '+@baseSucursal+'pnc_parametr As B ON CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = '+char(39)+'TIMO'+char(39)+' ' + char(13) + 
									'		INNER JOIN GA_Corporativa.dbo.PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA  ' + char(13) + 
									'		LEFT JOIN '+@baseSucursal+'cxp_ordencompra Z ON Car_Externa.ccp_iddocto = Z.oce_folioorden COLLATE Modern_Spanish_CI_AS ' + char(13) + 
									'		LEFT JOIN '+@baseSucursal+'cxp_detalleautosnuevos ZZ ON Z.oce_folioorden = ZZ.oce_folioorden ' + char(13) + 
									'		LEFT JOIN '+@baseSucursal+'SER_VEHICULO On Car_Externa.CCP_OBSGEN=VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS ' + char(13) + 
									'		LEFT JOIN '+@baseSucursal+'ppro_datosfacturas on Car_Externa.CCP_IDDOCTO = folioorden COLLATE Modern_Spanish_CI_AS '+ char(13)+
									' WHERE A.PAR_TIPOPARA = '+char(39)+'CARTERA'+char(39)+'  AND A.PAR_IDMODULO = '+char(39)+'CXC'+char(39)+'  ' + char(13) + 
									'		AND CCP_IDDOCTO = ''' + ISNULL(@idAnticipo,'') + '''  and a.par_importe5 <> 1 ' + char(13) + 
									''
			PRINT @diferenciString
			INSERT INTO @auxiliarNumerico
			EXECUTE (@diferenciString)
			SET @diferencia =(SELECT monto FROM @auxiliarNumerico)
			PRINT @diferencia
			IF(@diferencia IS NOT NULL AND @diferencia != 0 )
				BEGIN 
					SET @anticipo = 'SELECT	PARAME.PAR_DESCRIP1,CCP_TIPODOCTO,CCP_IDDOCTO,CCP_FECHOPE,'+CONVERT(varchar(50),@diferencia)+',CCP_ABONO ' + char(13) + 
									'FROM	'+@baseSucursal+'VIS_CONCAR01  AS Car_Externa ' + char(13) + 
									'		INNER JOIN '+@baseSucursal+'pnc_parametr As A ON CCP_CARTERA = A.PAR_IDENPARA ' + char(13) + 
									'		LEFT OUTER JOIN '+@baseSucursal+'pnc_parametr As B ON CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = '+char(39)+'TIMO'+char(39)+' ' + char(13) + 
									'		INNER JOIN GA_Corporativa.dbo.PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA  ' + char(13) + 
									'		LEFT JOIN '+@baseSucursal+'cxp_ordencompra Z ON Car_Externa.ccp_iddocto = Z.oce_folioorden COLLATE Modern_Spanish_CI_AS ' + char(13) + 
									'		LEFT JOIN '+@baseSucursal+'cxp_detalleautosnuevos ZZ ON Z.oce_folioorden = ZZ.oce_folioorden ' + char(13) + 
									'		LEFT JOIN '+@baseSucursal+'SER_VEHICULO On Car_Externa.CCP_OBSGEN=VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS ' + char(13) + 
									'		LEFT JOIN '+@baseSucursal+'ppro_datosfacturas on Car_Externa.CCP_IDDOCTO = folioorden COLLATE Modern_Spanish_CI_AS '+ char(13) + 
									'		INNER JOIN '+@baseSucursal+'PNC_PARAMETR PARAME ON PARAME.PAR_TIPOPARA = ''TIMO'' AND PARAME.PAR_IDENPARA = Car_Externa.CCP_TIPODOCTO '+ char(13) + 
									' WHERE A.PAR_TIPOPARA = '+char(39)+'CARTERA'+char(39)+'  AND A.PAR_IDMODULO = '+char(39)+'CXC'+char(39)+'  ' + char(13) + 
									'		AND CCP_IDDOCTO = ''' + ISNULL(@idAnticipo,'') + '''  and a.par_importe5 <> 1 AND CCP_TIPODOCTO = ''ANT'' ' + char(13) + 
									''
					INSERT INTO @resumenAnticipo
					EXECUTE (@anticipo)
				END
			DELETE FROM @auxiliarNumerico
			SET @contador = @contador +1
		END		
	SELECT tipoPago, tipoDocumento, idDocumento, fecha, saldo,abono FROM @resumenAnticipo
END
go

