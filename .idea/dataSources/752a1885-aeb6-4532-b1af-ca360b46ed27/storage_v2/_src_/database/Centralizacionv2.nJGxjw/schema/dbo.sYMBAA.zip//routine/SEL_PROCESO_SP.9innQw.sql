-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 17/10/2016
-- Description:	Recupero los procesos 
-- =============================================
-- EXECUTE [SEL_PROCESO_SP] 
CREATE PROCEDURE [dbo].[SEL_PROCESO_SP]
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
          SELECT [Proc_Id]          AS Proc_Id
			    ,[Proc_Nombre]      AS Proc_Nombre
			    ,[Proc_Descripcion] AS Proc_Descripcion
			    ,[Proc_Orden]       AS Proc_Orden
		    FROM [dbo].[DIG_PROCESO]  
	END TRY

BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_PROCESO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

