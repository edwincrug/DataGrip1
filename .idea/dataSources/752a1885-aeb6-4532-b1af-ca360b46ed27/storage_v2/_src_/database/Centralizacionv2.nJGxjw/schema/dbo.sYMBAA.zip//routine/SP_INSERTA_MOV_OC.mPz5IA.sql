-- =============================================
-- Author:		Javier Hernandez Rodriguez
-- Create date: 26/04/2016
-- Inserta en la tabla de movimientos de OC el cambio de status
-- =============================================
  
CREATE PROCEDURE [dbo].[SP_INSERTA_MOV_OC]

@FolioOrden VARCHAR(100),
@Usuario VARCHAR(10),
@ClaveStatus VARCHAR(10)

AS
BEGIN
SET NOCOUNT ON
BEGIN TRY	   

INSERT INTO cuentasxpagar.DBO.cxp_movimientosorden VALUES(@Usuario, CAST(GETDATE() AS date), CAST(GETDATE() AS time), @FolioOrden, @ClaveStatus)

END TRY

BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SP_INSERTA_MOV_OC]'
	 SELECT @Mensaje = ERROR_MESSAGE()	 	 
END CATCH		     
END

go

