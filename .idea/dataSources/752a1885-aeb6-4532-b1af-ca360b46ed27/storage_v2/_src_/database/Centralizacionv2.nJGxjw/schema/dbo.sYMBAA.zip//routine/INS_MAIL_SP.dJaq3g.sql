CREATE PROCEDURE [dbo].[INS_MAIL_SP]
		@correo		nvarchar(150)
		,@copia		nvarchar(150) = ''
		,@copiaO	nvarchar(150) = ''
		,@asunto	nvarchar(500)
		,@cuerpo	nvarchar(max)
		,@anexo		nvarchar(500) = ''
		,@correoRemitente nvarchar(100) 

--  Los parámetros obligatorios son: @correo, @tipoNotificacion, @idNotificacion, @asunto y @cuerpo
-- el resto de los parametros son opcionales
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @idmails	numeric(18,0) ;
	print @anexo

	EXEC msdb.dbo.sp_send_dbmail	@profile_name= 'SMTPDigitalizacion',
		@recipients=@correo,
		@copy_recipients = @copia,
		@blind_copy_recipients = @copiaO,
		@subject  = @asunto,
		@from_address = @correoRemitente,  --Remitente LMS
		@body = @cuerpo,
		@importance= 'High',
		@body_format = 'HTML',
		--@file_attachments = @anexo,
		@mailitem_id = @idmails OUTPUT;


END

go

