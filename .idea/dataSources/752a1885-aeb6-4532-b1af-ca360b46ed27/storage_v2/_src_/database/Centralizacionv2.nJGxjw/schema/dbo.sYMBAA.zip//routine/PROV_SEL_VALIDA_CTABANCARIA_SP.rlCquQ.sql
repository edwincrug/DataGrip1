

CREATE PROCEDURE [dbo].[PROV_SEL_VALIDA_CTABANCARIA_SP] 
 @idProspecto NUMERIC(18,0) 
,@idPerTra	INT
AS
BEGIN

DECLARE @idPerPersona NUMERIC(18,0)
		,@estatus INT = 1


SELECT @idPerPersona= PER_IDPERSONA_GA FROM PROV_PROSPECTO WHERE PER_IDPERSONA = @idProspecto


IF EXISTS(SELECT 1  from Centralizacionv2.[dbo].[PROV_CUENTA_BANCARIA] WHERE autorizada = 1  AND idPerTra = @idPerTra )
BEGIN
	set @estatus = 5
END

SELECT @estatus estatusProceso


END
go

