-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 04/11/2015
-- Description:	Procedimeitno que obtiene las alertas de un nodo
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ALERTA_NODO_SP]
	@idproceso	int
	,@idnodo	int
	,@folio		nvarchar(50)
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
	SELECT   dna.Proc_Id idProceso
			, dna.Nodo_Id nodo
			, dna.Folio_Operacion folio
			, dca.Alerta_Id idAlerta
			, dca.Alerta_Nombre nombre
			, dca.Alerta_Descripcion descripcion
	FROM     dbo.DIG_NODO_ALERTA dna
             INNER JOIN dbo.DIG_CAT_ALERTA dca ON dca.Alerta_Id = dna.Alerta_Id
	WHERE	 dna.Proc_Id = @idproceso
			 AND dna.Nodo_Id = @idnodo
			 AND dna.Folio_Operacion = @folio
	END TRY
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_ALERTA_NODO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

