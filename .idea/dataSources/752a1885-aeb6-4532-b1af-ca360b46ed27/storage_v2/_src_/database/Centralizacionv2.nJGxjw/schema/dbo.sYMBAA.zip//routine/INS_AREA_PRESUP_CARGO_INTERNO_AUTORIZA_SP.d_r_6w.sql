
/*
válida que esté definido este parametro en la BD Operativa: select * from GAZM_Zaragoza..PNC_PARAMETR where PAR_TIPOPARA='CONFPGRUP'
si existe hace upsert en: select * from Centralizacionv2..DIG_ESCALAMIENTO_AREA_PRESUP por empresa sucursal
si no esta definido, manda un aviso a la pantalla.
*/
CREATE PROCEDURE [dbo].[INS_AREA_PRESUP_CARGO_INTERNO_AUTORIZA_SP] (@sIdUSR VARCHAR(5),@sIdUSR2 VARCHAR(5),@sIdUSR3 VARCHAR(5), @sNombre_base varchar(100)) --with recompile
 As

BEGIN

SET NOCOUNT ON;

DECLARE @sQ nvarchar(1500); 
--DECLARE @sIdUSR VARCHAR(5);
DECLARE @ipServidor    VARCHAR(100);
DECLARE @ipLocal VARCHAR(50);
DECLARE @emp_idempresa int;
DECLARE @suc_idsucursal int;
DECLARE @sParmDefinition nvarchar(500);
DECLARE @dblResultado numeric(10,2);

select @dblResultado = 0;
select @ipServidor=ip_servidor, @emp_idempresa =  emp_idempresa  from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] where nombre_base = @sNombre_base
select @suc_idsucursal = suc_idsucursal from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] where nombre_base = @sNombre_base

SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC

if (@ipLocal = @ipServidor)
begin
   select @ipServidor = '';
end
else
	begin
	   select @ipServidor = '[' + @ipServidor + '].'
	end

--select @sNombre_base = 'GAUU_Pedregal'
select @sNombre_base = '[' + @sNombre_base + ']'

--Validamos que exista definido el parámetro en la base de datos operativa
select @sQ = ''
set @sQ = @sQ + N' Select @ddblResultado = Count(*) '  
set @sQ = @sQ + N' from ' + @ipServidor + @sNombre_base + '.[dbo].[PNC_PARAMETR] '
set @sQ = @sQ + N' where PAR_TIPOPARA = ''CONFPGRUP'''

set @sParmDefinition = N'@ddblResultado numeric(18,6) OUTPUT'

--print @sQ

--print @sParmDefinition

execute sp_executesql @sQ,@sParmDefinition,@ddblResultado = @dblResultado OUTPUT


if (@dblResultado=0)
begin
   print 'LOS PERMISOS NO FUERON REGISTRADOS'
   print 'No se ha definido el parámetro:  CONFPGRUP en la base de datos ' +  @ipServidor + @sNombre_base;
   print 'Este parámetro define el Area en los presupuestos de Cargo Interno a la que se le hará el cargo del presupuesto';
   print 'En el campo forma de pago cuentasporcobrar..ser_presupweb!prw_formapago  guardan   el departamento que se le hace el cargo interno'
   print 'Es necesario para determinar la persona que autorizará el presupuesto';
   
end 
else
begin
     if Exists (Select 1 from [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_PRESUP] where emp_idempresa = @emp_idempresa and suc_idsucursal = @suc_idsucursal)
      begin
			Delete [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_PRESUP] where emp_idempresa = @emp_idempresa and suc_idsucursal = @suc_idsucursal
      end
      
		select @sQ = ''
		set @sQ = @sQ + N' Insert into [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_PRESUP] (emp_idempresa,suc_idsucursal,par_idenpara,par_descripcion1,usuario_autoriza1,usuario_autoriza2,usuario_autoriza3)'      
		set @sQ = @sQ + N' Select ' + ltrim(rtrim(Convert(char(3),@emp_idempresa))) + ',' + ltrim(rtrim(Convert(char(3),@suc_idsucursal))) + ',PAR_IDENPARA,PAR_DESCRIP1,' + @sIdUSR + ',' + @sIdUSR2 + ',' + @sIdUSR3     
		set @sQ = @sQ + N' from ' + @ipServidor + @sNombre_base + '.[dbo].[PNC_PARAMETR] '
		set @sQ = @sQ + N' where PAR_TIPOPARA = ''CONFPGRUP'''    
		print @sQ
		execute sp_executesql @sQ
		
		print 'PERMISOS ESTABLECIDOS'
        Select * from [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_PRESUP] where emp_idempresa = @emp_idempresa and suc_idsucursal = @suc_idsucursal    
end

	set nocount off
END
/*
Declare @sNombre_base Varchar(100);
Declare @sIdUSR varchar(5);
Declare @sIdUSR2 VARCHAR(5);
Declare @sIdUSR3 VARCHAR(5);

select @sNombre_base = 'GAAU_Pedregal'
select @sIdUSR = '15'
select @sIdUSR2 = '14'
select @sIdUSR3 = '17'


Execute [dbo].[INS_AREA_PRESUP_CARGO_INTERNO_AUTORIZA_SP] @sIdUSR,@sIdUSR2,@sIdUSR3, @sNombre_base

------------------------------------------------------------
--Select 5,19, PAR_IDENPARA,PAR_DESCRIP1,15 from [GAUU_Pedregal].[dbo].[PNC_PARAMETR]  where PAR_TIPOPARA = 'AREPED ' and PAR_IDMODULO='CON' order by PAR_DESCRIP1
Select * from [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] 
where emp_idempresa=5 and suc_idsucursal = 19

select * from [Centralizacionv2].[dbo].DIG_CAT_BASES_BPRO

---------------------------------------------------------------------------------------
----------------------CONSULTA DE LOS USUARIOS EN BPRO X SU  ACRONIMO DE 3 CARACTERES

Select * from [ControlAplicaciones].[dbo].[cat_usuarios]
where usu_nombreusu = 'MPI'

--------------------- ACTUALIZACION DEL USUARIO POR AREA ------------------------------
Declare @iusu_idusuario int;
select @iusu_idsuario = 15;

update [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] set usuario_autoriza = @iusu_idsuario
where emp_idempresa=5
and suc_idsucursal=19
and par_idenpara='PFL1'
*/
go

