-- SP DEPARTAMENTOS----------------------------------------------------

CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOS_SP]--1,2,103
	@idempresa  int = 0
	,@idsucursal int = 0
	,@idempleado int = 0
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
	   SELECT 
				DISTINCT orga.dep_iddepartamento as idDepartamento
				,d.dep_nombre AS nombre
				,D.dep_nombrecto AS nombreCorto  
			FROM ControlAplicaciones.dbo.OPE_ORGANIGRAMA orga
				inner join  ControlAplicaciones.dbo.cat_departamentos D ON d.dep_iddepartamento = orga.dep_iddepartamento
			WHERE usu_idusuario = @idempleado 
					and orga.emp_idempresa = @idempresa 
					and orga.suc_idsucursal = @idsucursal

		END TRY
		BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_DEPARTAMENTOS_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
		END CATCH
END

go

