-- =================================================================
-- Modified date: 30/06/2016 Lourdes Maldonado Sánchez
-- Description:	  22/11/2016 Insetar Expediente Cuentas por Cobrar
-- =================================================================
--EXECUTE [INS_NODOS_FOLIO_SP] 'AU-ZM-ZAR-UN-23', 2
CREATE PROCEDURE [dbo].[INS_NODOS_FOLIO_SP]
	 @folio		varchar(50)
	,@idproceso	int
	
AS
BEGIN
	--SET NOCOUNT ON;
	--SET IMPLICIT_TRANSACTIONS ON

	--LQMA 11052017
	INSERT INTO BITACORA_PROCESOS
	VALUES (1,'Inicia INS_NODOS_FOLIO_SP : ' + @folio,GETDATE())

	BEGIN TRANSACTION TRAN_NODOS_FOLIO

	BEGIN TRY

			DECLARE @Nodo	   Int = 0
			DECLARE @tipoOrden Int = 0
			DECLARE @aux       Int = 1

			--LQMA ADD 16052017 para recorrer nodos por proceso en vez de CURSOR
			DECLARE @nodos TABLE(id INT IDENTITY(1,1), nodo INT)
			DECLARE @auxNodo INT = 1
			--LQMA 19062017
			DECLARE @resultados TABLE(id INT IDENTITY(1,1), res INT NULL)

			-- =================================================================
			-- Primero necesitamos saber si el folio ya tiene nodos.
			-- =================================================================			

			IF EXISTS (Select Nodo_Id FROM DIG_EXP_NODO WHERE Folio_Operacion = @folio)
			BEGIN
			    PRINT('Existe Expediente');
				--LQMA 11052017
				INSERT INTO BITACORA_PROCESOS
				VALUES (1,'Existe expediente : ' + @folio,GETDATE())

				SELECT 0;
			END
			ELSE 
			-- =================================================================
			-- Si No tiene expediente creado, se crea
			-- =================================================================
			-- =================================================================
			-- PROCESO 1
			-- =================================================================
			IF (@idproceso = 1)
				BEGIN
				        PRINT('CXP: Orden normal');
						--1) Insertar el expediente
						INSERT INTO DIG_EXPEDIENTE (Proc_Id, Fecha_Inicio, Estatus_Id, Folio_Operacion)
						VALUES (@idproceso, GETDATE(), 1, @folio)
			
						--LQMA 11052017
						INSERT INTO BITACORA_PROCESOS	
						VALUES (1,'Empieza cursor, empieza WHILE : ' + @folio,GETDATE())
						
						--COMENT LQMA 16052017 se quito cursor para evitar bloqueos de tabla, se puso WHILE
						/*
						-- Declaración del cursor para insertar la totalidad de nodos en DIG_EXP_NODO
						DECLARE cNodos CURSOR FOR
								SELECT Nodo_Id
								  FROM DIG_NODO
								 WHERE Proc_Id = @idproceso
						-- Apertura del cursor
							OPEN cNodos
					    -- Lectura de la primera fila del cursor
						FETCH cNodos INTO  @Nodo
							WHILE (@@FETCH_STATUS = 0 )
							BEGIN   --2) Inserta OC por todos los nodos
									INSERT INTO DIG_EXP_NODO (Proc_ID, Nodo_Id, Folio_Operacion, Nodo_Estatus_Id) 
									     VALUES (@idproceso, @Nodo, @folio, 1)
									--3) Inserta Documento por Nodo
									INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
										SELECT Proc_Id, Nodo_Id, @folio, Doc_Id FROM DIG_NODO_DOC 
										WHERE Proc_Id = @idproceso AND Nodo_Id = @Nodo ORDER BY Orden ASC	

								FETCH cNodos INTO  @Nodo
							 END
					-- Cierre del cursor
						CLOSE cNodos
					-- Liberar los recursos
						DEALLOCATE cNodos
						*/

						/*LQMA ADD 16052017  ciclo para insertar nodos por proceso*/						

						INSERT INTO @nodos
						SELECT Nodo_Id FROM DIG_NODO WHERE Proc_Id = @idproceso

						WHILE (@auxNodo <=  (SELECT MAX(id) FROM @nodos))
							BEGIN		
								SELECT @Nodo = nodo FROM @nodos WHERE id = @auxNodo

								INSERT INTO DIG_EXP_NODO (Proc_ID, Nodo_Id, Folio_Operacion, Nodo_Estatus_Id)   
								VALUES (@idproceso, @Nodo, @folio, 1)		
								--3) Inserta Documento por Nodo
								--INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
								--SELECT Proc_Id, Nodo_Id, @folio, Doc_Id FROM DIG_NODO_DOC 
								--WHERE Proc_Id = @idproceso AND Nodo_Id = @Nodo ORDER BY Orden ASC


								IF (@Nodo = 4 OR @Nodo = 7)
								BEGIN

									 IF EXISTS (SELECT oce_anticipo FROM cuentasxpagar.DBO.cxp_ordencompra  WHERE oce_folioorden =  @folio   AND  oce_anticipo = 1 AND sod_idsituacionorden != 4)
									 BEGIN

										INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
										SELECT Proc_Id, Nodo_Id, @folio, Doc_Id FROM DIG_NODO_DOC 
										WHERE Proc_Id = @idproceso AND Nodo_Id = @Nodo ORDER BY Orden ASC
										INSERT INTO BITACORA_PROCESOS	
										VALUES (1,'Generado con documento 70 : ' + @folio,GETDATE())
										--UPDATE [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
										--SET [Fecha_Creacion] = GETDATE()
										--FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
										--WHERE folio_operacion = @folio
										--AND doc_id in (SELECT [Doc_Id]
										--FROM [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO]
										--WHERE [Doc_id] IN (70))

									 END
									 ELSE
									 BEGIN
										INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
										SELECT Proc_Id, Nodo_Id, @folio, Doc_Id FROM DIG_NODO_DOC 
										WHERE Proc_Id = @idproceso AND Nodo_Id = @Nodo AND Doc_Id <> 70 ORDER BY Orden ASC
										INSERT INTO BITACORA_PROCESOS	
										VALUES (1,'Generado sin documento 70 : ' + @folio,GETDATE())
									 END
								END
								ELSE 
								BEGIN
									--3) Inserta Documento por Nodo
									INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
									SELECT Proc_Id, Nodo_Id, @folio, Doc_Id FROM DIG_NODO_DOC 
									WHERE Proc_Id = @idproceso AND Nodo_Id = @Nodo ORDER BY Orden ASC
								END

								SELECT @auxNodo = @auxNodo + 1
							END
						/*-----------------------------------------------------*/

						--LQMA 11052017
						INSERT INTO BITACORA_PROCESOS
						VALUES (1,'Termina cursor, termina WHILE : ' + @folio,GETDATE())	
					
					--3)Actualiza fecha de creacion a los documentos que son de Origen 2
					UPDATE [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
					   SET [Fecha_Creacion] = GETDATE()
					  FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
					 WHERE folio_operacion = @folio
					   AND doc_id in (SELECT [Doc_Id]
										FROM [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO]
									   WHERE [Doc_id] IN (11))
					
					PRINT 'Seleccionamos tipo orden'
					--4)Buscamos el tipo de Orden  4.-PI  5.-IF
					SELECT @tipoOrden = [oce_idtipoorden]
					  FROM [cuentasxpagar].[dbo].[cxp_ordencompra]
					 WHERE oce_folioorden = @folio
                    --SELECT  @tipoOrden
					
					PRINT 'tipo Orden: ' + CONVERT(VARCHAR(5),@tipoOrden)
					----------------------------------------------------
					-- 5)Actualiza el estatus del NODO 1 a vigente
					----------------------------------------------------
					IF (@tipoOrden <> 4 and @tipoOrden <> 5 )   
					BEGIN
					    PRINT('CXP: Orden normal');
						EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
						   @proc_Id = @idproceso
						  ,@nodo_Id = 1
						  ,@folio_Operacion = @folio
						  ,@accion_Id = 1
                        --UPDATE dbo.DIG_EXP_NODO SET Nodo_Estatus_Id = 2 where folio_operacion = @folio AND nodo_id = 1 and proc_id = @idproceso 
					END
					ELSE 
					----------------------------------------------------
					-- ELSE Actualiza el estatus del NODO 1 a vigente
					----------------------------------------------------
					    BEGIN
							IF (@tipoOrden = 4 )  ----4 PI
							BEGIN
							    WHILE(@aux < 4)
									BEGIN
										PRINT('CXP: Orden PI');
										--LQMA 19062017
										INSERT INTO @resultados
										EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
										   @proc_Id = @idproceso
										  ,@nodo_Id = @aux
										  ,@folio_Operacion = @folio
										  ,@accion_Id = 1
										--INS_CIERRA_NODO_SP  

										--LQMA 19062017
										INSERT INTO @resultados
										EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
															   @proc_Id = @idproceso  
															  ,@nodo_Id = @aux 
															  ,@folio_Operacion = @folio

										PRINT 'Cerro nodo, folio: ' + @folio +' , nodo: ' + CONVERT(VARCHAR(2), @aux)

										SET @aux = @aux + 1
									END
							END
							ELSE 
								BEGIN
									IF (@tipoOrden = 5 )  --5 IF
									BEGIN
									    WHILE(@aux < 7)
											BEGIN
												PRINT('CXP: Orden IF');

												--LQMA 19062017
												INSERT INTO @resultados
												EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
												   @proc_Id = @idproceso
												  ,@nodo_Id = @aux
												  ,@folio_Operacion = @folio
												  ,@accion_Id = 1
												--INS_CIERRA_NODO_SP
												
												--LQMA 19062017
												INSERT INTO @resultados    
												EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
															   @proc_Id = @idproceso  
															  ,@nodo_Id = @aux 
															  ,@folio_Operacion = @folio

												PRINT 'Cerro nodo, folio: ' + @folio +' , nodo: ' + CONVERT(VARCHAR(2), @aux)
												
												SET @aux = @aux + 1
											END
									END
								END
						END
                    ----------------------------------------------------
					--6) Termina Regresa 0
					----------------------------------------------------
					--LQMA 11052017
					INSERT INTO BITACORA_PROCESOS
					VALUES (1,'Termina proceso 1: ' + @folio,GETDATE())

					SELECT 0; 

		END  --END ELSE EXISTE EXPEDIENTE
		    -- =================================================================
			-- PROCESO 2
			-- =================================================================
	        ELSE IF (@idproceso = 2)
			BEGIN
			            PRINT('CXC: Inicia Orden normal');
			            --1) Insertar el expediente
						PRINT('CXC: Inserto el expediente');
						INSERT INTO DIG_EXPEDIENTE (Proc_Id, Fecha_Inicio, Estatus_Id, Folio_Operacion)
						VALUES (@idproceso, GETDATE(), 1, @folio)
						

						--LQMA 11052017
						INSERT INTO BITACORA_PROCESOS	
						VALUES (1,'Empieza cursor, empieza WHILE CXC : ' + @folio,GETDATE())
						
						--COMENT LQMA 16052017 se quito cursor para evitar bloqueos de tabla, se puso WHILE
						/*
						-- Declaración del cursor para insertar la totalidad de nodos en DIG_EXP_NODO
						DECLARE cNodos CURSOR FOR
								SELECT Nodo_Id
								  FROM DIG_NODO
								 WHERE Proc_Id = @idproceso
						-- Apertura del cursor
							OPEN cNodos
					    -- Lectura de la primera fila del cursor
						PRINT('CXC: Comienza inserta Nodos y documentos por Nodo');
						FETCH cNodos INTO  @Nodo
							WHILE (@@FETCH_STATUS = 0 )
							BEGIN   --2) Inserta OC por todos los nodos
									INSERT INTO DIG_EXP_NODO (Proc_ID, Nodo_Id, Folio_Operacion, Nodo_Estatus_Id) 
									     VALUES (@idproceso, @Nodo, @folio, 1)
									--3) Inserta Documento por Nodo
									INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
										SELECT  ND.Proc_Id
										       ,ND.Nodo_Id
											   ,@folio
											   ,ND.Doc_Id
										  FROM DIG_NODO_DOC  AS ND
										  --*******************************************************************************************************************************************
										  --Laura Modificación agregar cuando exista la relación tipo venta con el tipo de documento
											   --INNER JOIN  Centralizacionv2.dbo.DIG_DOC_TIPO_VENTA AS DT ON DT.Doc_Id = ND.Doc_Id AND DT.Tip_Id = (SELECT Tip_Id
														--																							  FROM Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA AS T
														--																								   INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O 
														--																								   ON O.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS = @folio AND T.Tip_Clave = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS
														--	
										 --																						)
										 WHERE Proc_Id = @idproceso 
										   AND Nodo_Id = @Nodo 

									ORDER BY Orden ASC	

								FETCH cNodos INTO  @Nodo
							 END
					-- Cierre del cursor
						CLOSE cNodos
					-- Liberar los recursos
						DEALLOCATE cNodos

					*/
					/*LQMA ADD 16052017  ciclo para insertar nodos por proceso*/						

						INSERT INTO @nodos
						SELECT Nodo_Id FROM DIG_NODO WHERE Proc_Id = @idproceso

						WHILE (@auxNodo <=  (SELECT MAX(id) FROM @nodos))
							BEGIN		
								SELECT @Nodo = nodo FROM @nodos WHERE id = @auxNodo

								--2) Inserta OC por todos los nodos
									INSERT INTO DIG_EXP_NODO (Proc_ID, Nodo_Id, Folio_Operacion, Nodo_Estatus_Id) 
									     VALUES (@idproceso, @Nodo, @folio, 1)
									--3) Inserta Documento por Nodo
									INSERT INTO DIG_EXPNODO_DOC(Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id)		
										SELECT  ND.Proc_Id
										       ,ND.Nodo_Id
											   ,@folio
											   ,ND.Doc_Id
										  FROM DIG_NODO_DOC  AS ND
										  --*******************************************************************************************************************************************
										  --Laura Modificación agregar cuando exista la relación tipo venta con el tipo de documento
											   --INNER JOIN  Centralizacionv2.dbo.DIG_DOC_TIPO_VENTA AS DT ON DT.Doc_Id = ND.Doc_Id AND DT.Tip_Id = (SELECT Tip_Id
														--																							  FROM Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA AS T
														--																								   INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O 
														--																								   ON O.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS = @folio AND T.Tip_Clave = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS
														--	
										 --
										 --Ya Existe una relación 
												INNER JOIN [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] AS CD ON CD.Doc_Id = ND.Doc_Id
												INNER JOIN [Centralizacionv2].[dbo].[DIG_RELACION_VENTA_DOCUMENTOS] AS RVD ON ND.Doc_Id = RVD.Doc_Id
												INNER JOIN [Centralizacionv2].[dbo].[DIG_CANAL_VENTA] AS CV ON RVD.IdTipoVenta = CV.idTipoVenta
												INNER JOIN [Centralizacionv2].[dbo].[DIG_CATALOGO_TIPO_VENTA] AS TV ON TV.IdTipoVenta = RVD.IdTipoVenta
												INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU ON CU.ucu_idtipoventa = CV.canalVenta COLLATE SQL_Latin1_General_CP1_CI_AS  AND CU.ucu_idempresa = CV.idEmpresa AND CU.ucu_idsucursal = CV.idSucursal
										 WHERE ND.Proc_Id = @idproceso 
											   AND ND.Nodo_Id = @Nodo 
											   AND CU.ucu_foliocotizacion = @folio

									ORDER BY Orden ASC

								SELECT @auxNodo = @auxNodo + 1
							END
						/*-----------------------------------------------------*/

						--LQMA ADD 16052017 bitacora rastreo
						INSERT INTO BITACORA_PROCESOS
						VALUES (1,'Termina cursor, termina WHILE CXC : ' + @folio,GETDATE())	
					
					--3)Actualiza fecha de creacion a los documentos que son de Origen 2
					PRINT('CXC: Actualizo Fecha en doc Origen 2');
					UPDATE [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
					   SET [Fecha_Creacion] = GETDATE()
					  FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
					 WHERE folio_operacion = @folio AND Proc_Id = @idproceso
					   AND doc_id in (SELECT [Doc_Id]
										FROM [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO]
									   WHERE [Doc_Origen] =2 AND Proc_Id = @idproceso)

                    --4)Activo Nodos 
					PRINT('CXC: Activo nodos del 1 al 2');
					UPDATE [Centralizacionv2].[dbo].[DIG_EXP_NODO]
					  SET  fechaInicio = getdate()
					   --      --,fechaFin    = getdate()
					   --      ,Nodo_Estatus_Id = 2
					WHERE [Proc_Id] =2 
					  AND [Folio_Operacion] = @folio
					  AND [Nodo_Id] = 1
					EXECUTE [INS_CIERRA_NODO_SP] @proc_Id = @idproceso, @nodo_Id = 1 ,@folio_Operacion = @folio

					--5) Se inserta el expediente de las unidades de una cotización
					-- Alejandro Grijalva Antonio
					-- 02/09/2020
					-- [dbo].[Sp_Documentos_ExpNodoFlotCoti_INS] @Cotizacion
					EXEC [dbo].[Sp_Documentos_ExpNodoFlotCoti_INS] @folio;
					
                --PRINT('CXC: Termino');
				--LQMA 11052017
				INSERT INTO BITACORA_PROCESOS
				VALUES (1,'Termina proceso 2 CXC: ' + @folio,GETDATE())
			    
				SELECT 0;		
			END --END ELSE idproceso = 2
			COMMIT TRANSACTION TRAN_NODOS_FOLIO
	END TRY
	BEGIN CATCH		
		
		ROLLBACK TRANSACTION TRAN_NODOS_FOLIO
		
		DECLARE @Mensaje  nvarchar(max)		
		SELECT @Mensaje = ERROR_MESSAGE() + ' @folio : ' + @folio	
		EXECUTE INS_ERROR_SP 'INS_NODOS_FOLIO_SP', @Mensaje
		SELECT  ERROR_NUMBER() 
	END CATCH  
END


go

