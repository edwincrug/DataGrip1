-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_SHOW_CARGAR_DOCUMENTOS_EXP_SP 80
-- =============================================
CREATE PROCEDURE [dbo].[SEL_SHOW_CARGAR_DOCUMENTOS_EXP_SP]
	@idPuesto INT
AS
BEGIN
	IF EXISTS(SELECT * FROM EXP_PERFILES_SNCARGA WHERE idPuesto = @idPuesto)
		BEGIN
			SELECT mostrarBtn = 0;
		END
	ELSE
		BEGIN
			SELECT mostrarBtn = 1;
		END
END

go

