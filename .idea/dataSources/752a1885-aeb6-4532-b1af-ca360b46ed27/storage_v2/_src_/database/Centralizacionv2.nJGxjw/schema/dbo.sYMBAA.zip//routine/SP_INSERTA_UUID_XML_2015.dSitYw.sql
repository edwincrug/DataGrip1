-- =============================================
-- Author:		Laura Gordillo
-- Create date: 
-- Description:	
--[SP_INSERTA_UUID_XML_2015] 'EF1DD17E-5ED3-45D1-9388-CDF12D835E7F'
-- =============================================
CREATE PROCEDURE [dbo].[SP_INSERTA_UUID_XML_2015]
	@uuid VARCHAR(100)
AS
BEGIN
	BEGIN TRY
DECLARE @Serie VARCHAR(5);
DECLARE @Folio VARCHAR(30);
DECLARE @Rfc_Emisor VARCHAR(60);
DECLARE @Rfc_Receptor VARCHAR(60);
DECLARE @Fecha_Factura VARCHAR(60);
DECLARE @Importe VARCHAR(60);
DECLARE @Iva VARCHAR(60);
DECLARE @Estatus VARCHAR(60);
DECLARE @Tipopol VARCHAR(60);
DECLARE @Conspol VARCHAR(60);
DECLARE @Consmov VARCHAR(60);
DECLARE @Mes VARCHAR(60);
DECLARE @Iddocto VARCHAR(60);
DECLARE @Idpersona VARCHAR(60);
DECLARE @Cvesu VARCHAR(60);
DECLARE @Fechope VARCHAR(60);
DECLARE @Horaope VARCHAR(60);
DECLARE @Pdf VARCHAR(60)='';
DECLARE @Rutapdf VARCHAR(60)='';
DECLARE @queryAnno  VARCHAR(max);
DECLARE @queryFac  VARCHAR(max);
DECLARE @queryFaciva  VARCHAR(max);
DECLARE @queryCuatro  VARCHAR(max);
DECLARE @queryDatosFactura  VARCHAR(max);
DECLARE @Insertar VARCHAR(max);
DECLARE @Base VARCHAR(100)=(SELECT nombre_base FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE RFC = (SELECT rfc_receptor FROM [192.168.20.55].[Facturas_Proveedores].[DBO].[PPRO_DATOSFACTURAS_2015] WHERE uuid = @uuid GROUP BY rfc_receptor));

--Le declaro valores del 55 
SELECT	@Rfc_Emisor=ISNULL(rfc_emisor,''),
		@Rfc_Receptor=ISNULL(rfc_receptor,''),
		@Serie=ISNULL(serie,''),
		@Folio=ISNULL(folio,''),
		@Importe=ISNULL(importe,''),
		@Iva=ISNULL(iva,''),
		@Estatus=ISNULL(Status,''),
		@Fecha_Factura=ISNULL(fecha_factura,'')
		FROM [192.168.20.55].[Facturas_Proveedores].[DBO].[PPRO_DATOSFACTURAS_2015] 
		WHERE uuid = @uuid
--Dependiendo del rfc_emisor busca en la bd correspondiente y consigue el año para saber en que CON_CAR corresponde
SET @queryAnno='SELECT VC.Vcc_Anno FROM ['+@Base+'].[DBO].[VIS_CONCAR01] VC' + char(13) + 
'INNER JOIN ['+@Base+'].[DBO].[PNC_PARAMETR] P ON VC.CCP_TIPOPOL = P.PAR_IDENPARA ' + char(13) + 
'INNER JOIN ['+@Base+'].[DBO].[PNC_PARAMETR] PP ON VC.CCP_CARTERA = PP.PAR_IDENPARA' + char(13) + 
'INNER JOIN ['+@Base+'].[DBO].[PER_PERSONAS] R ON VC.CCP_IDPERSONA = R.PER_IDPERSONA' + char(13) + 
'WHERE PP.PAR_TIPOPARA = '+char(39)+'CARTERA'+char(39)+' AND PP.PAR_IDMODULO = '+char(39)+'CXP'+char(39)+' AND CCP_TIPOPOL <> '+char(39)+'REVALCU'+char(39)+' AND  ' + char(13) + 
'P.PAR_TIPOPARA = '+char(39)+'TIPOLI'+char(39)+' AND VC.CCP_TIPODOCTO = '+char(39)+'FAC'+char(39)+'' + char(13)+
'AND VC.CCP_IDDOCTO = '+char(39)+@Serie+@Folio+char(39)+'' + char(13)+ 
'AND R.PER_RFC = '+char(39)+@Rfc_Emisor+char(39)+' ' + char(13) 

--Variable tabla para conseguir el año 
DECLARE @tablaAnno TABLE(resultado VARCHAR(MAX))
INSERT INTO @tablaAnno 
execute(@queryAnno) 
DECLARE @Anno VARCHAR(100)=(SELECT resultado FROM @tablaAnno);

--query factura
SET @queryFac='SELECT	CCP_TIPOPOL,' + char(13) + 
				 'CCP_CONSPOL,' + char(13) + 
				 'CCP_CONSMOV,' + char(13) + 
				 'CCP_MES,' + char(13) + 
				 'CCP_IDDOCTO,' + char(13) + 
				 'CCP_IDPERSONA,' + char(13) + 
				 'CCP_CVEUSU,' + char(13) + 
				 'CCP_FECHOPE,' + char(13) + 
				 'CCP_HORAOPE,' + char(13) +
				 'CCP_TIPODOCTO' + char(13) +
				 'FROM ['+@Base+'].[DBO].[CON_CAR01'+@Anno+'] WHERE CCP_TIPODOCTO ='+char(39)+'FAC'+char(39) +'AND CCP_IDDOCTO ='+char(39)+@Serie+@Folio+char(39) + char(13) 

DECLARE @tablaFac TABLE(	tipopol VARCHAR(MAX),
							conspol VARCHAR(MAX),
							consmov VARCHAR(MAX),
							mes VARCHAR(MAX),
							iddocto VARCHAR(MAX),
							idpersona VARCHAR(MAX),
							cvesu VARCHAR(MAX),
							fechope VARCHAR(MAX),
							horaope VARCHAR(MAX),
							tipodocto VARCHAR(MAX)
						   )
INSERT INTO @tablaFac 
execute(@queryFac) 
SELECT @Tipopol=ISNULL(tipopol,''),
	   @Conspol=ISNULL(conspol,''),
	   @Consmov=ISNULL(consmov,''),
	   @Mes=ISNULL(mes,''),
	   @Iddocto=ISNULL(iddocto,''),
	   @Idpersona=ISNULL(idpersona,''),
	   @Cvesu=ISNULL(cvesu,''),
	   @Fechope=ISNULL(Fechope,''),
	   @Horaope=horaope FROM @tablaFac

--select * from @tablaFac
DECLARE @AnnoFactura VARCHAR(10)=(SELECT YEAR(@Fecha_Factura));
DECLARE @MesFactura VARCHAR(10)=(SELECT MONTH(@Fecha_Factura));
DECLARE @rutadestino  VARCHAR(max)='C:\PROV_XML\2015\'+@Rfc_Receptor+'\'+@AnnoFactura+'_'+@MesFactura+'\'+@Rfc_Emisor+'_'+@Serie+@Folio+'.XML';

DECLARE @nombreDocumento  VARCHAR(max)=@Rfc_Emisor+'_'+@Serie+@Folio+'.XML';



IF EXISTS (select * from @tablaFac)
BEGIN 

SET @Estatus=2;
	SET @Insertar='INSERT INTO ['+@Base+'].[DBO].[CON_CFDI01'+@Anno+']' + char(13) + 
'			([CFI_TIPOPOL],' + char(13) + 
'			[CFI_CONSPOL],' + char(13) + 
'			[CFI_CONSMOV],' + char(13) + 
'			[CFI_MES],' + char(13) + 
'			[CFI_IDDOCTO],' + char(13) + 
'			[CFI_UUID],' + char(13) + 
'			[CFI_MONTO],' + char(13) + 
'			[CFI_IDPERSONA],' + char(13) + 
'			[CFI_RFC],' + char(13) + 
'			[CFI_RUTAXML],' + char(13) + 
'			[CFI_RUTAPDF],' + char(13) + 
'			[CFI_NOMBREXML],' + char(13) + 
'			[CFI_NOMBREPDF],' + char(13) + 
'			[CFI_ESTATUS],' + char(13) + 
'			[CFI_CVEUSU],' + char(13) + 
'			[CFI_FECHOPE],' + char(13) + 
'			[CFI_HORAOPE])' + char(13) + 
'VALUES	    ('+char(39)+@Tipopol+char(39)+',' + char(13) + 
'			 '+char(39)+@Conspol+char(39)+',' + char(13) + 
'			 '+char(39)+@Consmov+char(39)+',' + char(13) + 
'			 '+char(39)+@mes+char(39)+',' + char(13) + 
'			 '+char(39)+@Iddocto+char(39)+',' + char(13) + 
'			 '+char(39)+@uuid+char(39)+',' + char(13) + 
'			 '+char(39)+@Importe+char(39)+',' + char(13) + 
'			 '+char(39)+@Idpersona+char(39)+',' + char(13) + 
'			 '+char(39)+@Rfc_Emisor+char(39)+',' + char(13) + 
'			 '+char(39)+@rutadestino+char(39)+',' + char(13) + 
'			 '+char(39)+@Rutapdf+char(39)+',' + char(13) + 
'			 '+char(39)+@nombreDocumento+char(39)+',' + char(13) + 
'			 '+char(39)+''+char(39)+',' + char(13) + 
'			 '+char(39)+@Estatus+char(39)+',' + char(13) + 
'			 '+char(39)+@Cvesu+char(39)+',' + char(13) + 
'			 '+char(39)+@Fechope+char(39)+',' + char(13) + 
'			 '+char(39)+@Horaope+char(39)+'' + char(13) + 
'			)' + char(13) + 
'' 
--select @Insertar
EXECUTE(@Insertar)
UPDATE [192.168.20.55].[Facturas_Proveedores].[DBO].[PPRO_DATOSFACTURAS_2015]
SET Status=2
WHERE uuid=@uuid;
	--query IVA
SET @queryFaciva='SELECT CCP_TIPOPOL,' + char(13) + 
				 'CCP_CONSPOL,' + char(13) + 
				 'CCP_CONSMOV,' + char(13) + 
				 'CCP_MES,' + char(13) + 
				 'CCP_IDDOCTO,' + char(13) + 
				 'CCP_IDPERSONA,' + char(13) + 
				 'CCP_CVEUSU,' + char(13) + 
				 'CCP_FECHOPE,' + char(13) + 
				 'CCP_HORAOPE,' + char(13) +
				 'CCP_TIPODOCTO' + char(13) +
				 'FROM ['+@Base+'].[DBO].[CON_CAR01'+@Anno+'] WHERE CCP_TIPODOCTO ='+char(39)+'FACIVA'+char(39) +'AND CCP_IDDOCTO ='+char(39)+@Serie+@Folio+char(39) + char(13) 

DECLARE @tablaFaciva TABLE(	tipopol VARCHAR(MAX),
							conspol VARCHAR(MAX),
							consmov VARCHAR(MAX),
							mes VARCHAR(MAX),
							iddocto VARCHAR(MAX),
							idpersona VARCHAR(MAX),
							cvesu VARCHAR(MAX),
							fechope VARCHAR(MAX),
							horaope VARCHAR(MAX),
							tipodocto VARCHAR(MAX)
						   )
INSERT INTO @tablaFaciva 
execute(@queryFaciva) 
SELECT @Tipopol=ISNULL(tipopol,''),
	   @Conspol=ISNULL(conspol,''),
	   @Consmov=ISNULL(consmov,''),
	   @Mes=ISNULL(mes,''),
	   @Iddocto=ISNULL(iddocto,''),
	   @Idpersona=ISNULL(idpersona,''),
	   @Cvesu=ISNULL(cvesu,''),
	   @Fechope=ISNULL(Fechope,''),
	   @Horaope=horaope FROM @tablaFaciva 
	IF EXISTS(SELECT * FROM @tablaFaciva)
	BEGIN
	
	SET @Insertar='INSERT INTO ['+@Base+'].[DBO].[CON_CFDI01'+@Anno+']' + char(13) + 
'			([CFI_TIPOPOL],' + char(13) + 
'			[CFI_CONSPOL],' + char(13) + 
'			[CFI_CONSMOV],' + char(13) + 
'			[CFI_MES],' + char(13) + 
'			[CFI_IDDOCTO],' + char(13) + 
'			[CFI_UUID],' + char(13) + 
'			[CFI_MONTO],' + char(13) + 
'			[CFI_IDPERSONA],' + char(13) + 
'			[CFI_RFC],' + char(13) + 
'			[CFI_RUTAXML],' + char(13) + 
'			[CFI_RUTAPDF],' + char(13) + 
'			[CFI_NOMBREXML],' + char(13) + 
'			[CFI_NOMBREPDF],' + char(13) + 
'			[CFI_ESTATUS],' + char(13) + 
'			[CFI_CVEUSU],' + char(13) + 
'			[CFI_FECHOPE],' + char(13) + 
'			[CFI_HORAOPE])' + char(13) + 
'VALUES	    ('+char(39)+@Tipopol+char(39)+',' + char(13) + 
'			 '+char(39)+@Conspol+char(39)+',' + char(13) + 
'			 '+char(39)+@Consmov+char(39)+',' + char(13) + 
'			 '+char(39)+@mes+char(39)+',' + char(13) + 
'			 '+char(39)+@Iddocto+char(39)+',' + char(13) + 
'			 '+char(39)+@uuid+char(39)+',' + char(13) + 
'			 '+char(39)+@Iva+char(39)+',' + char(13) + 
'			 '+char(39)+@Idpersona+char(39)+',' + char(13) + 
'			 '+char(39)+@Rfc_Emisor+char(39)+',' + char(13) + 
'			 '+char(39)+@rutadestino+char(39)+',' + char(13) + 
'			 '+char(39)+@Rutapdf+char(39)+',' + char(13) + 
'			 '+char(39)+@nombreDocumento+char(39)+',' + char(13) + 
'			 '+char(39)+''+char(39)+',' + char(13) + 
'			 '+char(39)+@Estatus+char(39)+',' + char(13) + 
'			 '+char(39)+@Cvesu+char(39)+',' + char(13) + 
'			 '+char(39)+@Fechope+char(39)+',' + char(13) + 
'			 '+char(39)+@Horaope+char(39)+'' + char(13) +  
'			)' + char(13) + 
'' 
--print @Insertar
		EXECUTE(@Insertar)
	END
END
ELSE 
BEGIN
UPDATE [192.168.20.55].[Facturas_Proveedores].[DBO].[PPRO_DATOSFACTURAS_2015]
SET Status=3
WHERE uuid=@uuid;
END
END TRY
BEGIN CATCH
DECLARE @Mensaje  nvarchar(max);
SELECT @Mensaje = ERROR_MESSAGE()
END CATCH
END

go

