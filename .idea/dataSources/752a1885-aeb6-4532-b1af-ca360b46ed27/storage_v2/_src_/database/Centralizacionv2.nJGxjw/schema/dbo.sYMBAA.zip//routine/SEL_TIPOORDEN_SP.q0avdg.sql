-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 20/10/2015
-- Description:	Stored que recupera el catálogo de tipos de orden
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOORDEN_SP]

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
SELECT tip_idtipoorden
	, tip_nombre
	, tip_nombrecorto
FROM [cuentasxpagar].[dbo].[cat_tiposorden]
WHERE tip_status = 1
END TRY
  BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_TIPOORDEN_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

