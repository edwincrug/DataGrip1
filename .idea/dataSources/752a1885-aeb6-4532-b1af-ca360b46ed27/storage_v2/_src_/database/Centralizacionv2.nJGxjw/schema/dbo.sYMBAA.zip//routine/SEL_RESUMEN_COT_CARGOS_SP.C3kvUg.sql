-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	Obtiene el resumen de las cotizaciones las facturas 
-- =============================================
--[dbo].[SEL_RESUMEN_COT_CARGOS_SP] 'AA000028217','AU-ZM-NZA-UN-1013'
CREATE PROCEDURE [dbo].[SEL_RESUMEN_COT_CARGOS_SP] 
	@factura NVARCHAR(50)
	,@folio NVARCHAR(50) 
AS
BEGIN
	------------------------------------------------------------
	--Otengo la ip y el nombre de la base de la sucursal 
	------------------------------------------------------------
	DECLARE @baseSucursal VARCHAR(100) 

	SET @baseSucursal = [dbo].[base_Cotizacion](@folio)
	--SELECT	@baseSucursal = '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' 
	--FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL CU
	--		INNER JOIN DIG_CAT_BASES_BPRO PRO ON CU.ucu_idempresa = PRO.emp_idEmpresa AND CU.ucu_idsucursal = PRO.suc_idSucursal AND PRO.estatus = 1 AND PRO.tipo = 1
	--WHERE ucu_foliocotizacion = @folio 
	-----------------------------------------------------------
	--Declaro variable tabla para guardar datos de todas las facturas
	-----------------------------------------------------------
	DECLARE @facturas TABLE(tipoFactura VARCHAR(100),cargo NUMERIC(18,2),iva NUMERIC(18,2), total NUMERIC(18,2), fecha VARCHAR(20), factura VARCHAR(100),numeroSerie VARCHAR(100))
	DECLARE @facturaUnidad VARCHAR(MAX)
			,@facturaRefacciones VARCHAR(MAX)
			,@facturaTramites VARCHAR(MAX)
			,@facturaServicios VARCHAR(MAX)
			,@facturaOtrosConceptos VARCHAR(MAX)
	--FACTURA UNIDADES
	SET @facturaUnidad = 'SELECT ''Factura Unidad'', VTE_VTABRUT AS cargo, VTE_IVA AS iva, VTE_TOTAL AS total, VTE_FECHDOCTO AS fecha, VTE_DOCTO AS factura, VTE_SERIE AS numeroSerie FROM '+@baseSucursal+'ADE_VTAFI WHERE VTE_DOCTO = '''+@factura+''''
	PRINT (@facturaUnidad)
	INSERT INTO @facturas
	EXECUTE(@facturaUnidad)
	-------------------------------------------------------------------------------------------------------------------
	--FACTURAS REFACCIONES 
	--SET @facturaRefacciones = 'SELECT ''Factura Refacciones'', VTE_VTABRUT AS cargo, VTE_IVA AS iva, VTE_TOTAL AS total, VTE_FECHDOCTO AS fecha FROM '+@baseSucursal+'ADE_VTAFI WHERE VTE_DOCTO = '''+@factura+''''
	--INSERT INTO @facturas
	--EXECUTE(@facturaRefacciones)
	-------------------------------------------------------------------------------------------------------------------
	--FACTURAS TRAMITES 
	--SET @facturaTramites = 'SELECT ''Factura Tramites'', VTE_VTABRUT AS cargo, VTE_IVA AS iva, VTE_TOTAL AS total, VTE_FECHDOCTO AS fecha FROM '+@baseSucursal+'ADE_VTAFI WHERE VTE_DOCTO = '''+@factura+''''
	--INSERT INTO @facturas
	--EXECUTE(@facturaTramites)
	-------------------------------------------------------------------------------------------------------------------
	--FACTURAS DE SERVICIO
	--SET @facturaServicios = 'SELECT ''Factura Servicio'', VTE_VTABRUT AS cargo, VTE_IVA AS iva, VTE_TOTAL AS total, VTE_FECHDOCTO AS fecha FROM '+@baseSucursal+'ADE_VTAFI WHERE VTE_DOCTO = '''+@factura+''''
	--INSERT INTO @facturas
	--EXECUTE(@facturaServicios)
	-------------------------------------------------------------------------------------------------------------------
	--FACTURAS DE OTROS CONCEPTOS
	--SET @facturaOtrosConceptos = 'SELECT ''Factura Otros Conceptos'', VTE_VTABRUT AS cargo, VTE_IVA AS iva, VTE_TOTAL AS total, VTE_FECHDOCTO AS fecha FROM '+@baseSucursal+'ADE_VTAFI WHERE VTE_DOCTO = '''+@factura+''''
	--INSERT INTO @facturas
	--EXECUTE(@facturaOtrosConceptos)
	-------------------------------------------------------------------------------------------------------------------
	SELECT tipoFactura, cargo, iva, total, fecha, factura, numeroSerie  FROM @facturas
END
go

