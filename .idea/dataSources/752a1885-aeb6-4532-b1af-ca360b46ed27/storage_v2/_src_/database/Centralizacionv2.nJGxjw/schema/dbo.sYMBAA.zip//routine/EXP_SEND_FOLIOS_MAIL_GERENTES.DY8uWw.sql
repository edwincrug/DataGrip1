-- =============================================
-- Author:
-- Create date:
-- Description:
-- =============================================
CREATE PROCEDURE dbo.EXP_SEND_FOLIOS_MAIL_GERENTES
AS
BEGIN
		DECLARE @minDays INT, @maxDays INT;
		DECLARE @tblGerentes AS TABLE (nombre VARCHAR(50), correo VARCHAR(250), idEmpresa int, idSucursal int)
		DECLARE @tblDirectores AS TABLE (nombre VARCHAR(50), correo VARCHAR(250), idEmpresa int)
		DECLARE @tblOtrosSucursal AS TABLE (id int identity(1,1),idEmpresa int, idSucursal int)
		DECLARE @tblOtros AS TABLE (correo VARCHAR(250), idEmpresa int, idSucursal int)
		DECLARE @tblOtrosCorreo AS TABLE (correo VARCHAR(250), idEmpresa int, idSucursal int)
		SELECT 	@minDays = par_valor FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MINESCALAR'
		SELECT  @maxDays = par_valor FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MAXESCALAR'


		INSERT INTO @tblGerentes 
		SELECT	UPPER(usu_nombre + ' ' + usu_paterno + ' ' + usu_materno)
				, LTRIM(RTRIM(U.usu_correo))
				, idEmpresa
				, idSucursal FROM (
				SELECT   substring (cat_nombre,0,CHARINDEX('|', cat_nombre)) as idEmpresa
				,substring (cat_nombre,CHARINDEX('|', cat_nombre)+1, LEN(cat_nombre)) as idSucursal
				,cat_valor idUsuario
				FROM Centralizacionv2.dbo.DIG_CATALOGOS C
				WHERE cat_id_padre = 87) A
				INNER JOIN  [ControlAplicaciones].[DBO].[cat_usuarios] U ON A.idUsuario = U.usu_idusuario
		
		
		INSERT INTO @tblDirectores 
		SELECT   UPPER(usu_nombre + ' ' + usu_paterno + ' ' + usu_materno)
				,RTRIM(LTRIM(U.usu_correo)) +';javier.hernandezr@grupoandrade.com;nikkosteel0310@gmail.com' usu_correo
				,cat_nombre as idEmpresa
		FROM Centralizacionv2.dbo.DIG_CATALOGOS C
			INNER JOIN  [ControlAplicaciones].[DBO].[cat_usuarios] U ON C.cat_valor = U.usu_idusuario
		WHERE cat_id_padre = 120
		
		INSERT INTO @tblOtrosSucursal 
		SELECT distinct substring (cat_nombre,0,CHARINDEX('|', cat_nombre)) 
						,substring (cat_nombre,CHARINDEX('|', cat_nombre)+1, LEN(cat_nombre)) 
		FROM Centralizacionv2.dbo.DIG_CATALOGOS C
		WHERE cat_id_padre = 2700

		INSERT INTO @tblOtros
		SELECT 	LTRIM(RTRIM(U.usu_correo))
				, idEmpresa
				, idSucursal FROM (
				SELECT   substring (cat_nombre,0,CHARINDEX('|', cat_nombre)) as idEmpresa
				,substring (cat_nombre,CHARINDEX('|', cat_nombre)+1, LEN(cat_nombre)) as idSucursal
				,cat_valor idUsuario
		FROM Centralizacionv2.dbo.DIG_CATALOGOS C
		WHERE cat_id_padre = 2700) A
				INNER JOIN  [ControlAplicaciones].[DBO].[cat_usuarios] U ON A.idUsuario = U.usu_idusuario
		
		DECLARE @cont int = 1
		DECLARE @valores VARCHAR(MAX)
		DECLARE @idSucursal INT, @idEmpresa INT
		
		WHILE (@cont <= (SELECT count(1) from @tblOtrosSucursal ))
		BEGIN
				SET @valores = ''
				select @idSucursal = idSucursal, @idEmpresa = idEmpresa from @tblOtrosSucursal where id = @cont

				SELECT  @valores = COALESCE(@valores + ';', '') + correo FROM @tblOtros where idSucursal = @idSucursal 
				insert into @tblOtrosCorreo
				SELECT substring(@valores,2,len(@valores))+';',@idEmpresa,@idSucursal
				--SELECT @valores,@idEmpresa,@idSucursal
				SET @cont = @cont + 1
		END
		-- select * from @tblOtrosCorreo
		--SELECT @minDays, @maxDays
		SELECT 		CD.ucn_noserie AS folio,
					C.ucu_idusuarioalta,
					ISNULL(PP.PER_NOMRAZON + ' ' + PP.PER_PATERNO + ' ' + PP.PER_MATERNO,'SIN AGENTE') AS nombre,
					ISNULL(PP.PER_Email, 'notiene@notiene.com') usu_correo,
					C.ucu_idempresa,
					C.ucu_idsucursal,
					B.nombre_sucursal,
					C.ucu_idcliente,
					P.PER_NOMRAZON + ' ' + P.PER_PATERNO + ' ' + P.PER_MATERNO AS NombreCliente,
					C.ucu_foliocotizacion,
					convert(VARCHAR(10),VW.PEN_FECHAENTREGA_REAL,103) AS PEN_FECHAENTREGA_REAL,
					CD.ucn_idFactura,
					ISNULL(DIR.nombre,'Sin Nombre') directorMarca,
					ISNULL(DIR.correo,'notiene@notiene.com') maildirectorMarca,
					ISNULL(G.nombre,'Sin nombre') gerente,
					ISNULL(G.correo,'notiene@notiene.com') mailGerente,
					ISNULL(OC.correo,'') mailOtros
					--ISNULL((SELECT nombre FROM [DATOS_PUESTOS](116, C.ucu_idempresa, C.ucu_idsucursal)),'Sin Nombre') directorMarca,
					--ISNULL((SELECT correo FROM [DATOS_PUESTOS](116, C.ucu_idempresa, C.ucu_idsucursal)),'notiene@notiene.com') maildirectorMarca,
					--ISNULL((SELECT nombre FROM [DATOS_PUESTOS](174, C.ucu_idempresa, C.ucu_idsucursal)),'Sin nombre') gerente,
					--ISNULL((SELECT correo FROM [DATOS_PUESTOS](174, C.ucu_idempresa, C.ucu_idsucursal)),'notiene@notiene.com') mailGerente
					FROM EXP_FOLIOS_MAIL M
					INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = M.folio COLLATE DATABASE_DEFAULT
					INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
					INNER JOIN GA_Corporativa.DBO.PER_PERSONAS PP ON PP.PER_IDPERSONA = C.ucu_idagente
					--INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = C.ucu_idusuarioalta
					INNER JOIN GA_Corporativa.DBO.PER_PERSONAS P ON P.PER_IDPERSONA = C.ucu_idcliente
					INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = C.ucu_idempresa AND B.suc_idsucursal = C.ucu_idsucursal
					INNER JOIN @tblDirectores DIR on DIR.idEmpresa = C.ucu_idempresa
					INNER JOIN @tblGerentes G on G.idEmpresa = C.ucu_idempresa AND G.idSucursal = C.ucu_idsucursal 
					LEFT JOIN @tblOtrosCorreo OC on OC.idEmpresa = C.ucu_idEmpresa AND OC.idSucursal = C.ucu_idSucursal
					INNER JOIN [VW_FECHA_ENTREGA_UNIDAD] VW ON VW.PEN_NUMSERIE = CD.ucn_noserie AND ucu_idusuarioalta NOT IN (0) AND VW.PEN_FECHAENTREGA_REAL IS NOT NULL
					--INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] D ON D.emp_idempresa = C.ucu_idempresa AND D.suc_idsucursal = C.ucu_idsucursal AND D.dep_nombrecto = 'UN'
					--INNER JOIN [DIG_ESCALAMIENTO] E ON E.emp_idempresa = C.ucu_idempresa AND B.suc_idsucursal = C.ucu_idsucursal AND E.dep_iddepartaamento = D.dep_iddepartamento
					---WHERE M.dias BETWEEN @minDays AND @maxDays
		WHERE		M.dias > @minDays -- AND @maxDays
		GROUP BY ucu_idusuarioalta , CD.ucn_noserie, PP.PER_NOMRAZON, PP.PER_PATERNO, PP.PER_MATERNO, PP.PER_EMAIL, C.ucu_idempresa, C.ucu_idsucursal, B.nombre_sucursal
				,DIR.nombre,DIR.correo, G.nombre,G.correo, C.ucu_idcliente, P.PER_NOMRAZON, P.PER_PATERNO, P.PER_MATERNO,C.ucu_foliocotizacion,CD.ucn_idFactura,PEN_FECHAENTREGA_REAL,OC.correo
		ORDER BY 5,6,4 ASC

		--DECLARE @minDays INT, @maxDays INT;
		--SELECT
		-- @minDays = par_valor
		--FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MINESCALAR'
		--SELECT
		-- @maxDays = par_valor
		--FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MAXESCALAR'

		--SELECT
		-- CD.ucn_noserie AS folio,
		-- C.ucu_idusuarioalta,
		-- U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS nombre,
		-- U.usu_correo,
		-- C.ucu_idempresa,
		-- C.ucu_idsucursal,
		-- B.nombre_sucursal,
		-- ISNULL((SELECT nombre FROM [DATOS_PUESTOS](116, C.ucu_idempresa, C.ucu_idsucursal)),'Sin Nombre') directorMarca,
		-- ISNULL((SELECT correo FROM [DATOS_PUESTOS](116, C.ucu_idempresa, C.ucu_idsucursal)),'notiene@notiene.com') maildirectorMarca,
		-- ISNULL((SELECT nombre FROM [DATOS_PUESTOS](174, C.ucu_idempresa, C.ucu_idsucursal)),'Sin nombre') gerente,
		-- ISNULL((SELECT correo FROM [DATOS_PUESTOS](174, C.ucu_idempresa, C.ucu_idsucursal)),'notiene@notiene.com') mailGerente
		--FROM EXP_FOLIOS_MAIL M
		--INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = M.folio COLLATE DATABASE_DEFAULT
		--INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
		--INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = C.ucu_idusuarioalta
		--INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = C.ucu_idempresa AND B.suc_idsucursal = C.ucu_idsucursal
		--INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] D ON D.emp_idempresa = C.ucu_idempresa AND D.suc_idsucursal = C.ucu_idsucursal AND D.dep_nombrecto = 'UN'
		--INNER JOIN [DIG_ESCALAMIENTO] E ON E.emp_idempresa = C.ucu_idempresa AND B.suc_idsucursal = C.ucu_idsucursal AND E.dep_iddepartaamento = D.dep_iddepartamento
		--WHERE M.dias BETWEEN @minDays AND @maxDays
		--GROUP BY ucu_idusuarioalta , CD.ucn_noserie, U.usu_correo, U.usu_nombre, U.usu_paterno, U.usu_materno, U.usu_correo, C.ucu_idempresa, C.ucu_idsucursal, B.nombre_sucursal, E.Usuario_Autoriza1
		--ORDER BY 4, 5 ASC
END
go

