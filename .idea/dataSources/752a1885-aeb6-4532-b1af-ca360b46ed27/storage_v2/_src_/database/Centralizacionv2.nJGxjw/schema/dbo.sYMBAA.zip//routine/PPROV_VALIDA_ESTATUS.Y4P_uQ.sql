CREATE PROCEDURE [dbo].[PPROV_VALIDA_ESTATUS]   -- [dbo].[PPROV_ordcompra_prov]  4,null,null,1
@folioOrden VARCHAR(50)
AS  
   
SELECT estatus,folioorden,uuid FROM PPRO_DATOSFACTURAS WHERE folioorden = @folioOrden

SET NOCOUNT OFF
go

