
CREATE PROCEDURE [dbo].[sp_RESPALDA_RESAGADOS]  
As

DECLARE @iResultado int

begin 
set nocount on

select @iResultado=0
					
 if Exists( select 1 from Centralizacionv2..DIG_ORDENCOMPRAAUX where DATEDIFF(mi,aux_fecha,GETDATE())>20 )
     begin 

	   --BEGIN TRANSACTION pasaResagados
	 	
	    insert into Centralizacionv2..DIG_ORDENCOMPRAAUX1(div_iddivision, emp_idempresa, suc_idsucursal, dep_iddepartamento, tipo_idtipoorden, Folio_Operacion,oce_idsituacionorden, aux_fecha,aux_observaciones)
		select div_iddivision, emp_idempresa, suc_idsucursal, dep_iddepartamento, tipo_idtipoorden, Folio_Operacion,oce_idsituacionorden, aux_fecha,'*' + aux_observaciones
		From Centralizacionv2..DIG_ORDENCOMPRAAUX
		where DATEDIFF(mi,aux_fecha,GETDATE())>20
		and oce_idsituacionorden not in (1)
		--and DATEDIFF(mi,aux_fecha,GETDATE())<1440

		Delete Centralizacionv2..DIG_ORDENCOMPRAAUX where DATEDIFF(mi,aux_fecha,GETDATE())>20
			
		Insert into Centralizacionv2..DIG_BITACORA (fecha,quien,que,aquien)
		values (GETDATE(),'CXP sp_RESPALDA_RESAGADOS','Se pasaron los registros a DIG_ORDENCOMPRAAUX','los que tienen *')
	
		select @iResultado=1

        --COMMIT TRANSACTION pasaResagados
	end	
	
	Return @iResultado
	select @iResultado

set nocount off

end
go

