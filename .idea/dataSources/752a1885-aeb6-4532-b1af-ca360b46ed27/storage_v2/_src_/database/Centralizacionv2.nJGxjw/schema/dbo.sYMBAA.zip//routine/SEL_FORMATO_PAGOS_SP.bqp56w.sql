-- ================================================
-- Create date: 24/09/2017
-- Description:	Obtiene la informacion formato de pago del RPT
-- =============================================
--[dbo].[SEL_FORMATO_PAGOS_SP] 'AU-AU-UNI-UN-PE-3495', 1
CREATE PROCEDURE [dbo].[SEL_FORMATO_PAGOS_SP]
	@folio VARCHAR(50) 
	,@banco INT
AS
BEGIN
DECLARE @logo VARCHAR(500)
		,@razonSocial VARCHAR(500)
		,@contrato VARCHAR(500)
		,@nombreCliente VARCHAR(500)
		,@cuentaRetiro VARCHAR(500)
		,@importe VARCHAR(500)
		,@cunetaDeposito VARCHAR(500)
SELECT	@logo = B.urlLogo 
		,@razonSocial = B.razonSocial 
		,@contrato = dpa_cuentapagadora 
		--,@nombreCliente = PER.Persona
		,@nombreCliente = LTRIM(RTRIM(LTRIM(P.per_paterno)) + ' ' + RTRIM(LTRIM(P.per_materno)) + ' ' + RTRIM(LTRIM(P.per_nomrazon))) 
		--,@nombreCliente = LTRIM(RTRIM(LTRIM(P.per_paterno)) + ' ' + RTRIM(LTRIM(P.per_materno)) + ' ' + RTRIM(LTRIM(P.per_nomrazon))) 
		,@cuentaRetiro = dpa_cuentapagadora 
		,@importe = DP.dpa_importepagado 
		,@cunetaDeposito = DP.dpa_cuentabeneficiario 
FROM	[referencias].[dbo].[Banco] AS B 
		INNER JOIN [cuentasxpagar].[DBO].[cxp_doctospagados] AS DP ON DP.dpa_iddocumento = @folio
		--CROSS APPLY fn_ObtenerProveedor(DP.dpa_idpersona,dpa_idempresa) PER
		INNER JOIN GA_Corporativa.dbo.PER_PERSONAS P ON P.per_idpersona = DP.dpa_idpersona
		--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS P ON P.per_idpersona = DP.dpa_idpersona
WHERE	B.idBanco = @banco


IF(@banco = 1)
	BEGIN
		IF EXISTS(SELECT	1
					FROM	[PAGOS].[DBO].[PAG_PROGRA_PAGOS_DETALLE] AS PD
							INNER JOIN [referencias].[DBO].[Bancomer] AS B ON B.refAmpliada LIKE '%' + pad_polReferencia  + '%'
							INNER JOIN [referencias].[dbo].[Banco] AS BC ON B.IDBanco = BC.idBanco
							INNER JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] AS DP ON DP.dpa_iddocumento = PD.pad_documento AND DP.dpa_cuentapagadora = B.noCuenta AND DP.dpa_importepagado = B.importe
					WHERE	PD.pad_documento = @folio)
			BEGIN
				PRINT 'BANCOMER'
				SELECT	CONVERT(varchar, B.fechaOperacion, 103) AS fechaConsulta
						,(CASE	WHEN B.concepto LIKE '%TRASPASO%' THEN 'BBVA Bancomer - Pago mismo banco'
								WHEN B.concepto LIKE '%SPEI%' THEN 'BBVA Bancomer - Pago Interbancario'
								ELSE 'Verificar'
								END) AS tipoOperacion
						,LTRIM(RTRIM(LTRIM(U.usu_paterno)) + ' ' + RTRIM(LTRIM(U.usu_materno)) + ' ' + RTRIM(LTRIM(U.usu_nombre)))  As usuario
						,'Pago Documento: ' + pad_documento AS descripcion
						,PD.pad_cuentaDestino AS bancoBeneficiario 
						,'PAGO' AS motivoPago
						,B.horaOperacion AS horaAplicacion
						,'Mismo Día' AS disponibilidadPago
						,referencia AS referencia
						,CONVERT(varchar(50),B.noMovimiento) AS folioInterbancario
						,@logo AS logo
						,@razonSocial AS razonSocial
						,@contrato AS contrato
						,@nombreCliente AS nombreCliente
						,@cuentaRetiro AS cuentaRetiro
						,CONVERT(NUMERIC(18,2),@importe) AS importe
						,@cunetaDeposito AS cunetaDeposito
						,E.emp_nombre AS empresa
				FROM	[PAGOS].[DBO].[PAG_PROGRA_PAGOS_DETALLE] AS PD
						INNER JOIN [referencias].[DBO].[Bancomer] AS B ON B.refAmpliada LIKE '%' + pad_polReferencia  + '%'
						INNER JOIN [referencias].[dbo].[Banco] AS BC ON B.IDBanco = BC.idBanco
						INNER JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] AS DP ON DP.dpa_iddocumento = PD.pad_documento AND DP.dpa_cuentapagadora = B.noCuenta AND DP.dpa_importepagado = B.importe
						INNER JOIN [Pagos].[dbo].[PAG_LOTE_PAGO] AS LP ON LP.pal_id_lote_pago = PD.pal_id_lote_pago
						INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] AS U ON U.usu_idusuario = LP.pal_id_usuario
						INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS E ON E.emp_idempresa = LP.pal_id_empresa
				WHERE	PD.pad_documento = @folio	
			END
		ELSE
			BEGIN
				PRINT 'BANCOMER'
				SELECT	CONVERT(varchar, B.fechaOperacion, 103) AS fechaConsulta
						,(CASE	WHEN B.concepto LIKE '%TRASPASO%' THEN 'BBVA Bancomer - Pago mismo banco'
								WHEN B.concepto LIKE '%SPEI%' THEN 'BBVA Bancomer - Pago Interbancario'
								ELSE 'Verificar'
								END) AS tipoOperacion
						,LTRIM(RTRIM(LTRIM(U.usu_paterno)) + ' ' + RTRIM(LTRIM(U.usu_materno)) + ' ' + RTRIM(LTRIM(U.usu_nombre)))  As usuario
						,'Pago Documento: ' + pad_documento AS descripcion
						,PD.pad_cuentaDestino AS bancoBeneficiario 
						,'PAGO' AS motivoPago
						,B.horaOperacion AS horaAplicacion
						,'Mismo Día' AS disponibilidadPago
						,referencia AS referencia
						,CONVERT(varchar(50),B.noMovimiento) AS folioInterbancario
						,@logo AS logo
						,@razonSocial AS razonSocial
						,@contrato AS contrato
						,@nombreCliente AS nombreCliente
						,@cuentaRetiro AS cuentaRetiro
						,CONVERT(NUMERIC(18,2),@importe) AS importe
						,@cunetaDeposito AS cunetaDeposito
						,E.emp_nombre AS empresa
				FROM	[PAGOS].[DBO].[PAG_PROGRA_PAGOS_DETALLE] AS PD
						INNER JOIN [referencias].[DBO].[Bancomer] AS B ON B.refAmpliada LIKE '%' + pad_polReferencia  + '%'
						INNER JOIN [referencias].[dbo].[Banco] AS BC ON B.IDBanco = BC.idBanco
						INNER JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] AS DP ON DP.dpa_iddocumento = PD.pad_documento --AND DP.dpa_cuentapagadora = B.noCuenta AND DP.dpa_importepagado = B.importe
						INNER JOIN [Pagos].[dbo].[PAG_LOTE_PAGO] AS LP ON LP.pal_id_lote_pago = PD.pal_id_lote_pago
						INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] AS U ON U.usu_idusuario = LP.pal_id_usuario
						INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS E ON E.emp_idempresa = LP.pal_id_empresa
				WHERE	PD.pad_documento = @folio	
			END
			
	END
ELSE IF(@banco = 2)
	BEGIN
		PRINT 'Banamex'
		SELECT	S.SLFechaTransaccion  AS fechaConsulta
				,(CASE	WHEN S.AODescripcion NOT LIKE '%SPEI%' THEN 'Banamex - Pago mismo banco'
						WHEN S.AODescripcion LIKE '%SPEI%' THEN 'Banamex - Pago Interbancario'
						ELSE 'Verificar'
						END)  AS tipoOperacion
				,LTRIM(RTRIM(LTRIM(U.usu_paterno)) + ' ' + RTRIM(LTRIM(U.usu_materno)) + ' ' + RTRIM(LTRIM(U.usu_nombre))) As usuario
				,'Pago Documento: ' + pad_documento AS descripcion
				,PD.pad_cuentaDestino AS bancoBeneficiario
				,'PAGO' AS motivoPago
				, CONVERT(time, getdate(), 108) AS horaAplicacion
				,'Mismo Día' AS disponibilidadPago
				,SLTipoReferencia AS referencia
				,SLTipoReferencia AS folioInterbancario 
				,@logo AS logo
				,@razonSocial AS razonSocial
				,@contrato AS contrato
				,@nombreCliente AS nombreCliente
				,@cuentaRetiro AS cuentaRetiro
				,CONVERT(NUMERIC(18,2),@importe) AS importe
				,@cunetaDeposito AS cunetaDeposito
				,E.emp_nombre AS empresa
		FROM	[PAGOS].[DBO].[PAG_PROGRA_PAGOS_DETALLE] AS PD
				INNER JOIN [referencias].[DBO].[Banamex] As S ON S.SLTipoReferencia LIKE '%' + pad_polReferencia  + '%'
				INNER JOIN [Pagos].[dbo].[PAG_LOTE_PAGO] AS LP ON LP.pal_id_lote_pago = PD.pal_id_lote_pago
				INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] AS U ON U.usu_idusuario = LP.pal_id_usuario
				INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS E ON E.emp_idempresa = LP.pal_id_empresa
		WHERE	PD.pad_documento = @folio	
	END
ELSE IF(@banco = 3)
	BEGIN
		PRINT 'SANTANDER'
		SELECT	S.fechaMovimiento  AS fechaConsulta
				,(CASE	WHEN S.descripcion NOT LIKE '%SPEI%' THEN 'Santander - Pago mismo banco'
						WHEN S.descripcion LIKE '%SPEI%' THEN 'Santander - Pago Interbancario'
						ELSE 'Verificar'
						END)  AS tipoOperacion
				,LTRIM(RTRIM(LTRIM(U.usu_paterno)) + ' ' + RTRIM(LTRIM(U.usu_materno)) + ' ' + RTRIM(LTRIM(U.usu_nombre))) As usuario
				,'Pago Documento: ' + pad_documento AS descripcion
				,PD.pad_cuentaDestino AS bancoBeneficiario
				,'PAGO' AS motivoPago
				,horaMovimiento AS horaAplicacion
				,'Mismo Día' AS disponibilidadPago
				,referencia AS referencia
				,referencia AS folioInterbancario 
				,@logo AS logo
				,@razonSocial AS razonSocial
				,@contrato AS contrato
				,@nombreCliente AS nombreCliente
				,@cuentaRetiro AS cuentaRetiro
				,@importe AS importe
				,@cunetaDeposito AS cunetaDeposito
				,E.emp_nombre AS empresa
		FROM	[PAGOS].[DBO].[PAG_PROGRA_PAGOS_DETALLE] AS PD
				INNER JOIN [referencias].[DBO].[Santander] As S ON S.referencia LIKE '%' + pad_polReferencia  + '%'
				INNER JOIN [Pagos].[dbo].[PAG_LOTE_PAGO] AS LP ON LP.pal_id_lote_pago = PD.pal_id_lote_pago
				INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] AS U ON U.usu_idusuario = LP.pal_id_usuario
				INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS E ON E.emp_idempresa = LP.pal_id_empresa
		WHERE	PD.pad_documento = @folio	
	END
END
go

