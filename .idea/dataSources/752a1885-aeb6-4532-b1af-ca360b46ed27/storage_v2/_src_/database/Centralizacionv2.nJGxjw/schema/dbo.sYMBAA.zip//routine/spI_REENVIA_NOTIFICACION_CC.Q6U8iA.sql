

CREATE PROCEDURE [dbo].[spI_REENVIA_NOTIFICACION_CC](@sFolioOperacion varchar(20)) --with recompile
 AS
declare
@iucu_idcotizacion int
begin 

set nocount on
select @iucu_idcotizacion=0;

select @iucu_idcotizacion = ISNULL(ccs.ucu_idcotizacion,0)  from cuentasporcobrar..UNI_COTIZACIONUNIVERSAL cu, cuentasporcobrar..uni_ccs ccs WHERE cu.UCU_FOLIOCOTIZACION=@sFolioOperacion and ccs.ucu_idcotizacion=cu.ucu_idcotizacion

		if (@iucu_idcotizacion>0)
		begin
		  BEGIN TRY
				BEGIN TRANSACTION pasoNotificacionCCS
			   --borramos la tabla puente
				delete Centralizacionv2..uni_ccs1
			   --insertamos el registro actual en la tabla puente
				insert  into Centralizacionv2..uni_ccs1
				select ucu_idcotizacion,ucc_monto,ucc_cartera,ucc_usuarioalta,ucc_fechaalta,ucc_fechamodifica,ucc_usuariomodifica,ucc_estatus,ucc_idpoliticadescuentos 
				from cuentasporcobrar..uni_ccs where ucu_idcotizacion=@iucu_idcotizacion
				--Borramos el registro original del CC
				delete cuentasporcobrar..uni_ccs WHERE ucu_idcotizacion=@iucu_idcotizacion
				--reinsertamos el valor en la tabla original. Provocando que se dispare nuevamente el trigguer.
				insert into cuentasporcobrar..uni_ccs
				select ucu_idcotizacion,ucc_monto,ucc_cartera,ucc_usuarioalta,ucc_fechaalta,ucc_fechamodifica,ucc_usuariomodifica,ucc_estatus,ucc_idpoliticadescuentos from Centralizacionv2..uni_ccs1 where ucu_idcotizacion=@iucu_idcotizacion
				insert into Centralizacionv2..DIG_BITACORA (fecha,quien,que,aquien)
				values (getdate(),'spI_REENVIA_NOTIFICACION_CC','Reenvio de solicitud de autorizacion de CC',@sFolioOperacion)
				 				
				SELECT 0 --decimos que no hubo error al reenviar la notificación.
				COMMIT TRANSACTION pasoNotificacionCCS
			END TRY
			BEGIN CATCH	
				ROLLBACK TRANSACTION pasoNotificacionCCS		
				DECLARE @Mensaje  nvarchar(max)		
				SELECT @Mensaje = ERROR_MESSAGE() + ' @folio : ' + @sFolioOperacion			
				SELECT  ERROR_NUMBER() 
			END CATCH
		end 

set nocount off
end


/*
Declare @sFolioOperacion varchar(20);

select @sFolioOperacion='AU-ZM-NFA-SE-PE-252'
select @iError = 0

execute spI_REENVIA_NOTIFICACION_CC @sFolioOperacion

*/
go

