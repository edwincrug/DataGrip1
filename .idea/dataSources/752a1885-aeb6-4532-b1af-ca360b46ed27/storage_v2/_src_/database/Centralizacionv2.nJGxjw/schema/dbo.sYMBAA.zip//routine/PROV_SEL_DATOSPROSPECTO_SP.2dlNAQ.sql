CREATE  PROCEDURE [dbo].[PROV_SEL_DATOSPROSPECTO_SP] 
@idProspecto INT
AS
BEGIN
	SELECT	 PER_IDPERSONA idProspecto
			,PER_EMAIL email
			,PER_NOMRAZON nombre
			,ISNULL(PER_PATERNO,'') paterno
			,ISNULL(PER_MATERNO,'') materno
			,PER_RFC  rfc
			,PER_GIRO giro
			,PER_CLICON contacto
			,ISNULL(PER_TELEFONO1,'') telefono
			,ISNULL(PER_CALLE1,'') calle
			,PER_CALLE2 calle2
			,ISNULL(PER_NUMEXTER,'')  exterior
			,ISNULL(PER_NUMINER,'')  interior
			,ISNULL(PER_CODPOS,'')  cp
			,ISNULL(PER_COLONIA,'')  colonia
			,ISNULL(PER_DELEGAC,'') localidad
			,ISNULL(PER_CIUDAD,'')  ciudad
			,ISNULL(PER_PAGWEB,'') pagina
			,ISNULL(PER_RLNOMRAZON,'')  comercial 
			,PER_DEALERID docContacto
			,PER_TIPO tipoPersona
			,token
			,empresaId
			,empresaBD
			,limiteCredito limite
			,diasCredito dias
			,representante
			,legales
			
	FROM	Centralizacionv2.dbo.PROV_PROSPECTO
	WHERE   PER_IDPERSONA = @idProspecto
END

go

