-- ================================================
-- Create date: 05/09/2017
-- Description:	Obtiene el historial de los movimientos realizados en la orde de compra 
-- =============================================
--[dbo].[SEL_RESUMEN_PROCESOS_SP] 'AU-AU-CUA-RE-IF-191',1
CREATE PROCEDURE [dbo].[SEL_RESUMEN_PROCESOS_SP] 
	 @folio NVARCHAR(30)
	 ,@idProceso INT
AS
BEGIN
	IF(@idProceso= 1)
		BEGIN
			IF(EXISTS(SELECT ifr_folionuevo FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac] WHERE [ifr_folionuevo] = @folio))
				BEGIN
					SELECT	SO.sod_nombresituacion AS proceso 
							,CONVERT(varchar, MO.mov_fechamovimiento, 103) AS fechaMovimiento
							,CONVERT(varchar, MO.mov_horamovimiento, 108) AS horaMovimiento
							,CASE WHEN (SO.sod_idsituacionorden = 12) THEN (SELECT	U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno 
																			FROM	[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] PD 
																					INNER JOIN [Pagos].[dbo].[PAG_LOTE_PAGO] PL ON PL.pal_id_lote_pago = PD.pal_id_lote_pago
																					INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = PL.pal_id_usuario
																			WHERE	PD.pad_documento = @folio) 
																	  ELSE U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno END AS nombreUsuario
					FROM	[cuentasxpagar].[dbo].[cxp_movimientosorden] MO
							INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SO ON MO.sod_idsituacionorden = SO.sod_idsituacionorden
							INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON MO.mov_idusuariomovimiento = U.usu_idusuario		
					WHERE	oce_folioorden =@folio --'AU-AU-CUA-RE-PI-234'--'AU-AU-CUA-RE-IF-191'--'AU-AU-CUA-UN-PE-119
					UNION
					SELECT 'Solicitado'
							,CONVERT(varchar, OC.oce_fechaorden, 103)
							,CONVERT(varchar, OC.oce_horaorden, 108)
							,U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno
					FROM	cuentasxpagar.dbo.cxp_ordencompra OC
							INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON OC.oce_idusuario = U.usu_idusuario 
					WHERE   oce_folioorden=@folio
					ORDER BY fechaMovimiento, proceso DESC
				END
			ELSE
				BEGIN
					SELECT	SO.sod_nombresituacion AS proceso 
							,CONVERT(varchar, MO.mov_fechamovimiento, 103) AS fechaMovimiento
							,CONVERT(varchar, MO.mov_horamovimiento, 108) AS horaMovimiento
							--, U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS nombreUsuario
							,CASE WHEN (SO.sod_idsituacionorden = 12) THEN (SELECT	U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno 
																			FROM	[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] PD 
																					INNER JOIN [Pagos].[dbo].[PAG_LOTE_PAGO] PL ON PL.pal_id_lote_pago = PD.pal_id_lote_pago
																					INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = PL.pal_id_usuario
																			WHERE	PD.pad_documento = @folio) 
																	  ELSE U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno END AS nombreUsuario
					FROM	[cuentasxpagar].[dbo].[cxp_movimientosorden] MO
							INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SO ON MO.sod_idsituacionorden = SO.sod_idsituacionorden
							INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON MO.mov_idusuariomovimiento = U.usu_idusuario
							LEFT JOIN  [cuentasxpagar].[dbo].[cxp_integracionfacrefac] IR ON IR.ifr_folionuevo = MO.oce_folioorden
					WHERE	oce_folioorden =@folio
				END
			
		END
END
go

