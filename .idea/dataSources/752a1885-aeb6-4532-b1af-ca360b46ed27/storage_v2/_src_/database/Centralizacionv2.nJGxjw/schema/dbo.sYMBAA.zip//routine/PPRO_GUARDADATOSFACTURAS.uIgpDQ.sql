-- [PPRO_GUARDADATOSFACTURAS]
CREATE PROCEDURE [dbo].[PPRO_GUARDADATOSFACTURAS]
@rfc_emisor VARCHAR(15) = '',
@rfc_receptor VARCHAR(15) = '',
@serie VARCHAR(30) = '',
@folio VARCHAR(30) = '',
@importe MONEY = NULL,
@iva MONEY = NULL,
@uuid VARCHAR(50) = '',
@fecha_factura DATETIME = NULL,
@usuario_carga VARCHAR(15) = '',
@folioOrden VARCHAR(40) = '',
@tipoDocumento int 
AS

BEGIN TRY  
	BEGIN TRAN		
	
	declare @folioPadre varchar(50)

		IF NOT EXISTS (select folioorden from PPRO_DATOSFACTURAS where  folioorden= @folioOrden and tipoDocumento = @tipoDocumento)
			BEGIN
			-----------------------------  Si no existe guarda por primera vez   -----------------------------
					INSERT INTO dbo.PPRO_DATOSFACTURAS(rfc_emisor,rfc_receptor,serie,folio,importe,iva,uuid,
											   fecha_factura,fecha_carga,usuario_carga,estatus,folioorden,tipoDocumento)
				                        VALUES(@rfc_emisor,@rfc_receptor,@serie,@folio,@importe,@iva,@uuid,
											   @fecha_factura,GETDATE(),@usuario_carga,1,@folioOrden,@tipoDocumento)
										
					if exists (SELECT top 1 Folio_Operacion   FROM [Centralizacionv2].[dbo].[DIG_EXP_PLAN_PISO] 
								WHERE Folio_Alias = @folioOrden order by Folio_Operacion asc)
							begin
								select @folioPadre = (SELECT top 1 Folio_Operacion   FROM [Centralizacionv2].[dbo].[DIG_EXP_PLAN_PISO] 
									WHERE Folio_Alias = @folioOrden order by Folio_Operacion asc)
								if(@tipoDocumento = 1)
									begin
										UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
										WHERE Folio_Operacion=@folioPadre AND Proc_Id=1 and Doc_Id=20
									end
								else
									if(@tipoDocumento = 2)
										begin
											UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
											WHERE Folio_Operacion=@folioPadre AND Proc_Id=1 and Doc_Id=10
										end
							end
					else
							begin
							if(@tipoDocumento = 1)
									begin
										UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
										WHERE Folio_Operacion=@folioOrden AND Proc_Id=1 and Doc_Id=20
									end
								else
									if(@tipoDocumento = 2)
										begin
											UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
											WHERE Folio_Operacion=@folioOrden AND Proc_Id=1 and Doc_Id=10
										end
							end
							--UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
							--WHERE Folio_Operacion=@folioOrden AND Proc_Id=1 and Doc_Id=20
							--Proc_Id Es el flujo o procedimiento de cuentas por paga
							--Doc_Id  Esla factura

							--LQMA ADD 30062017 obtenemos departamento y ordenes PE en caso de que sea tipo SE u OT y sea de tipo IF
							-----------------------------------------------------------------------------
							-----------------------------------------------------------------------------
							DECLARE @depto VARCHAR(10) = '', @tipoOrden INT = 0
 	
							SELECT @depto = DEPTOS.[dep_nombrecto], @tipoOrden = CXP.oce_idtipoorden
							FROM [cuentasxpagar].[dbo].[cxp_ordencompra] CXP
							LEFT JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEPTOS ON CXP.oce_iddepartamento = DEPTOS.dep_iddepartamento
							WHERE CXP.[oce_folioorden] = @folioOrden

							IF(@depto IN ('SE','OT') AND @tipoOrden = 5) --5 : tipo IF
								BEGIN
										--DECLARE @ordenesPE TABLE(Id INT IDENTITY(1,1),folio VARCHAR(50))

										IF(@depto = 'SE') --ordenes de servicio
											BEGIN

													--INSERT INTO @ordenesPE
													DELETE FROM PPRO_DATOSFACTURAS
													WHERE folioorden IN (SELECT  --[ifs_folionuevo],      folioinicial    --Folio_Factura
																				[ifs_folioanterior]   folionuevo      --Folio_Orden
																				--,1 tipoFolioNav
																		 FROM [cuentasxpagar].[dbo].[cxp_integracionfacser]
																		 WHERE [ifs_folionuevo] = @folioOrden 
																		 GROUP BY [ifs_folionuevo],[ifs_folioanterior])

											END
										ELSE              --OT ordenes de otros conceptos
										   BEGIN
				   
													--INSERT INTO @ordenesPE
													DELETE FROM PPRO_DATOSFACTURAS
													WHERE folioorden IN (SELECT --[ifp_folionuevo],       folioinicial     --Folio_Orden 
																			    [ifp_folioanterior]    folionuevo       --Folio_Factura
																				--,1 tipoFolioNav
																		 FROM [cuentasxpagar].[dbo].[cxp_integracionfacpv]	
																		 WHERE [ifp_folionuevo] = @folioOrden
																		 GROUP BY [ifp_folioanterior],[ifp_folionuevo])
										   END	

								END
							-------------------------------------------
							-------------------------------------------
			END
		ELSE
		BEGIN
--------------------------  Si existe actualiza el campo ---------------------------------------------------------
		    UPDATE PPRO_DATOSFACTURAS SET 
									rfc_emisor = @rfc_emisor,
									rfc_receptor = @rfc_receptor,
									serie = @serie,
									folio = @folio,
									importe = @importe,
									iva = @iva,
									uuid = @uuid,
									fecha_factura = @fecha_factura,
									fecha_carga = GETDATE(),
									usuario_carga = @usuario_carga,
									estatus = 1,
									tipoDocumento = @tipoDocumento
			WHERE folioorden= @folioOrden and tipoDocumento = @tipoDocumento

			-- Agrege esto
			if exists (SELECT top 1 Folio_Operacion   FROM [Centralizacionv2].[dbo].[DIG_EXP_PLAN_PISO] 
							WHERE Folio_Alias = @folioOrden order by Folio_Operacion asc)
						begin
							select @folioPadre = (SELECT top 1 Folio_Operacion   FROM [Centralizacionv2].[dbo].[DIG_EXP_PLAN_PISO] 
								WHERE Folio_Alias = @folioOrden order by Folio_Operacion asc)
							if(@tipoDocumento = 1)
								begin
									UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
									WHERE Folio_Operacion=@folioPadre AND Proc_Id=1 and Doc_Id=20
								end
							else
								if(@tipoDocumento = 2)
									begin
										UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
										WHERE Folio_Operacion=@folioPadre AND Proc_Id=1 and Doc_Id=10
									end
						end
				else
						begin
						if(@tipoDocumento = 1)
								begin
									UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
									WHERE Folio_Operacion=@folioOrden AND Proc_Id=1 and Doc_Id=20
								end
							else
								if(@tipoDocumento = 2)
									begin
										UPDATE DIG_EXPNODO_DOC set Fecha_Creacion=GETDATE() 
										WHERE Folio_Operacion=@folioOrden AND Proc_Id=1 and Doc_Id=10
									end
						end
		-- termina agrege esto
								
		END
			
	COMMIT TRAN;  
	SELECT 0
END TRY  
BEGIN CATCH  

		 PRINT ('Error: ' + ERROR_MESSAGE())  
		 DECLARE @Mensaje  nvarchar(max),  
		 @Componente nvarchar(50) = 'PPRO_GUARDADATOSFACTURAS'  
		 SELECT @Mensaje = ERROR_MESSAGE()  
		 RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje;   
	ROLLBACK TRAN;   
	
	SELECT 1	 
END CATCH


--USE [Centralizacionv2]
--GO
--/****** Object:  StoredProcedure [dbo].[PPRO_GUARDADATOSFACTURAS]    Script Date: 09/04/2016 05:06:17 p. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--ALTER PROCEDURE [dbo].[PPRO_GUARDADATOSFACTURAS]     --  [dbo].[PPRO_GUARDADATOSFACTURAS]  'CMI950920TR8','CRA130717JE6','C','49055',42212.59,'4f289c8f-9886-4e7f-8d5d-ea07f9a9c17b','30/11/2015','MARJ820822PG3','AU-AUA-ZAR-UN-PF-39'
--@rfc_emisor VARCHAR(15) = '',
--@rfc_receptor VARCHAR(15) = '',
--@serie VARCHAR(5) = '',
--@folio VARCHAR(30) = '',
--@importe MONEY = NULL,
--@uuid VARCHAR(50) = '',
--@fecha_factura DATETIME = NULL,
--@usuario_carga VARCHAR(15) = '',
--@folioorden VARCHAR(50) 
--AS

--BEGIN TRY  
--	BEGIN TRAN		

--	DECLARE @serieFolio VARCHAR(35) 
--	DECLARE @estatus nvarchar(5)
	        
--			IF EXISTS(SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS WHERE folioorden=@folioorden)
--			BEGIN
------------------------Actualiza datos si ya existe-----------------------------------------------------
--			     UPDATE dbo.PPRO_DATOSFACTURAS SET rfc_emisor = @rfc_emisor,
--												   rfc_receptor =@rfc_receptor,
--												   serie =@serie,
--												   folio =@folio,
--												   importe =@importe,
--												   uuid = @uuid,
--											       fecha_factura =@fecha_factura,
--												   fecha_carga = GETDATE(),
--												   usuario_carga = @usuario_carga,
--												   folioorden =@folioorden,
--												   Estatus=NULL where folioorden=@folioorden
--			END
--			ELSE
--			BEGIN
----------------------------Inserta Datos del XML----------------------------------------------------

--			INSERT INTO dbo.PPRO_DATOSFACTURAS(rfc_emisor,rfc_receptor,serie,folio,importe,uuid,
--											   fecha_factura,fecha_carga,usuario_carga,folioorden)
--				                        VALUES(@rfc_emisor,@rfc_receptor,@serie,@folio,@importe,@uuid,
--											   @fecha_factura,GETDATE(),@usuario_carga,@folioorden)

--			END
---------------------------Actualiza Estatus si es factura recibida----------------------------------------


--			DEClARE @EstatusRecibido VARCHAR(5)			

--			SET @EstatusRecibido =(SELECT sod_idsituacionorden FROM [cuentasxpagar].[dbo].[cxp_ordencompra] 
--			WHERE oce_folioorden=@folioorden)
			
--			IF(@EstatusRecibido='6' OR @EstatusRecibido='7')
--			BEGIN
--			UPDATE dbo.PPRO_DATOSFACTURAS SET Estatus=2 where folioorden=@folioorden
--			END
			
---------------------------Actualiza campos en la tabla [cxp_ordencompra]-------------------------------------
											   
--			--UPDATE [cuentasxpagar].[dbo].[cxp_ordencompra]
--   --         SET [oce_uuid] = @uuid
--   --         WHERE oce_folioorden = @folioorden
--			SET @serieFolio= @serie + @folio
--			 UPDATE [cuentasxpagar].[dbo].[cxp_ordencompra]
--            SET [oce_factura] = @serieFolio, oce_uuid = @uuid,oce_fechafactura = @fecha_factura
--            WHERE oce_folioorden = @folioorden

			
--------------------------Actualiza el estatus a 10 en caso de tener estatus 8-------------------------------

--			SET @estatus=(SELECT TOP 1 sod_idsituacionorden FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE oce_folioorden=@folioorden ORDER BY mov_horamovimiento DESC)

--			IF(@estatus=8)
--				BEGIN
--					INSERT INTO [cuentasxpagar].[dbo].[cxp_movimientosorden](
--						mov_idusuariomovimiento,
--						mov_fechamovimiento,
--						mov_horamovimiento,
--						oce_folioorden,
--						sod_idsituacionorden)
--					VALUES
--						(@usuario_carga,
--						(CONVERT (CHAR(10), getdate(), 126)), 
--						(CAST(GETDATE() AS TIME)),
--						@folioorden,
--						10)
--			END

--	COMMIT TRAN;  

--END TRY  
--BEGIN CATCH  

--		 PRINT ('Error: ' + ERROR_MESSAGE())  
--		 DECLARE @Mensaje  nvarchar(max),  
--		 @Componente nvarchar(50) = 'PPRO_GUARDADATOSFACTURAS'  
--		 SELECT @Mensaje = ERROR_MESSAGE()  
--		 RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje;   
--	ROLLBACK TRAN;   
		 
--END CATCH

go

