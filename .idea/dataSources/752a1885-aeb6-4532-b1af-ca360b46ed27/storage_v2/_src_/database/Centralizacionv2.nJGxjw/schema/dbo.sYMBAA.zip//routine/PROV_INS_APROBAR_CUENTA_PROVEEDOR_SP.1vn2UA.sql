-- [PROV_INS_APROBAR_CUENTA_PROVEEDOR_SP]  14,71,19
CREATE PROCEDURE [dbo].[PROV_INS_APROBAR_CUENTA_PROVEEDOR_SP] -- 'NME610911L47',71,10
 @rfc VARCHAR(50) 
,@idUsuario VARCHAR(50) 
,@idPerTra INT
AS
BEGIN
--DECLARE @rfc VARCHAR(50)  = 'NME610911L47'
--,@idUsuario INT  = 71
--,@idPerTra INT = 10
BEGIN TRY
BEGIN TRANSACTION
	
	
	/***************UNIFICAR CUENTAS*******************************/
		DECLARE @BASES TABLE(id int identity(1,1),emp_idempresa INT,base nvarchar(200))
		DECLARE @contBases INT = 1, @numRegistros INT = 0, @contBancos INT = 1, @banxico VARCHAR(20), @numRegistrosCuentas INT = 0, @existe INT,@emp_idempresa INT,  @idRespuestaUni   INT, @cie VARCHAR(50), @noCuenta VARCHAR(50)
		DECLARE @basePrincipal VARCHAR(50) = '', @queryCuentaSel NVARCHAR(MAX) = '', @queryBanco NVARCHAR(MAX) = '', @SQLString NVARCHAR(MAX), @sqlUni VARCHAR(MAX)
		DECLARE @ParmDefinition nvarchar(500) , @usuario VARCHAR(20)
		
		SELECT  @usuario = usu_nombreusu 
		FROM	ControlAplicaciones.dbo.Cat_usuarios 
		WHERE	usu_idusuario  = @idUsuario

		DECLARE  @idPersona NUMERIC(18,0)
		--SELECT  PER_IDPERSONA,* FROM GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfc
		SELECT TOP 1 @idPersona = PER_IDPERSONA FROM GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfc order by PER_IDPERSONA asc
		--select @idPersona
		--select BCO_IDPERSONA, count(1)  from GAZM_Concentra.dbo.CON_BANCOS group by BCO_IDPERSONA
		--select BCO_IDPERSONA, count(1)  from GAAU_Concentra.dbo.CON_BANCOS group by BCO_IDPERSONA

		DECLARE @provBanco TABLE (
				id int identity(1,1),
				[idProspecto] [int] NULL,
				[titular] [varchar](100) NULL,
				[banco] [varchar](50) NULL,
				[sucursal] [varchar](50) NULL,
				[noCuenta] [varchar](30) NULL,
				[clabe] [varchar](30) NULL,
				[cie] [varchar](10) NULL,
				[referencia] [varchar](50) NULL,
				[cveBanxico] [varchar](10) NULL,
				[cveBanco] [varchar](50) NULL,
				[tipoCtaBancaria] [varchar](20) NULL,
				[nombreTipoCtaBancaria] [varchar](50) NULL,
				[empresaId] [int] NULL
			)

		INSERT INTO @BASES
		SELECT emp_idempresa ,nombre_base  FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 

		SET @numRegistros = (select COUNT(1) from @BASES)

		INSERT INTO @provBanco
		SELECT 
			  [idProspecto]
			  ,[titular]
			  ,[banco]
			  ,[sucursal]
			  ,[noCuenta]
			  ,[clabe]
			  ,[cie]
			  ,[referencia]
			  ,[cveBanxico]
			  ,[cveBanco]
			  ,[tipoCtaBancaria]
			  ,[nombreTipoCtaBancaria]
			  ,[empresaId]
		  FROM [dbo].[PROV_CUENTA_BANCARIA]
		  WHERE rfcProspecto = @rfc


		  SET  @numRegistrosCuentas = (select  COUNT(1) from @provBanco)


		  WHILE(@contBancos<= @numRegistrosCuentas)
		  BEGIN
			--SELECT @contBancos '@contBancos'
			SET @contBases  = 1
				select @banxico = cveBanxico, @cie = cie, @noCuenta = noCuenta FROM @provBanco WHERE id = @contBancos
				--select @banxico, @cie, @noCuenta
				
				WHILE(@contBases<= @numRegistros)
				BEGIN
				
					
					SELECT @basePrincipal = base, @emp_idempresa = emp_idempresa FROM @BASES WHERE id = @contBases
					--select @basePrincipal
					IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @basePrincipal)) 
					BEGIN
						--SELECT @basePrincipal
						SET @existe = 0
						SET @SQLString = 'IF EXISTS (SELECT 1 from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''') BEGIN SET @res = 1 END '
						SET @ParmDefinition = N' @res INT OUTPUT'; 
						--select * from GAZM_Concentra.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = 'BA' AND PAR_STATUS = 'A' AND PAR_DESCRIP5 = '072'
						
						
						EXECUTE sp_executesql @SQLString, @ParmDefinition, @res= @existe OUTPUT
						
						
						IF( @existe =1)
						BEGIN
							SET @sqlUni = 'INSERT INTO ' +@basePrincipal+'.[dbo].[CON_BANCOS]
													 ([BCO_IDPERSONA]
													 ,[BCO_BANCO]
													 ,[BCO_PLAZA]
													 ,[BCO_SUCURSAL]
													 ,[BCO_STATUS]
													 ,[BCO_TIPCUENTA]
													 ,[BCO_NUMCUENTA]
													 ,[BCO_CLABE]
													 ,[BCO_CVEUSU]
													 ,[BCO_FECHOPE]
													 ,[BCO_HORAOPE]
													 ,[BCO_REFERNUM]
													 ,[BCO_REFERALF]
													 ,[BCO_CONVENIOCIE]
													 ,[BCO_AUTORIZADA]) 
									   	SELECT '+ CONVERT(VARCHAR(10),@idPersona)+ '
												,cveBanco
												,''0000''
												,sucursal
												,''ACTIVO''
												,tipoCtaBancaria
												,noCuenta
												,clabe
												,''' + @usuario+ '''
												,CONVERT(VARCHAR(10), GETDATE(),103)
												,CONVERT(CHAR(8), GETDATE(), 108) 
												,referencia
												,''''
												,cie
												,1 
										FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
										INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_IDPERSONA  = CB.idProspecto
										WHERE CB.cveBanxico = '''+ @banxico +''' AND rfcProspecto = '''+@rfc+'''' 

							--SELECT (@sqlUni)
							EXEC (@sqlUni)
						--	SELECT @emp_idempresa
						EXEC Pagos.[dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP] @idProveedor =@idPersona , @cuenta =@noCuenta ,	@convenio = @cie, @idEmpresa =  @emp_idempresa,@idUsuario = @usuario, @result = @idRespuestaUni OUTPUT
						--SELECT @idRespuestaUni 'Unifica'
						SET	@contBases = @numRegistros
						END
						ELSE 
						BEGIN
							SET @contBases= @contBases+1  
						END
					END
					

					
						BEGIN
							SET @contBases= @contBases+1 
						END
				END
				SET @contBancos = @contBancos+1
		  END

		 -- SELECT * from  GAAU_Concentra.[dbo].[CON_BANCOS]  WHERE BCO_IDPERSONA =@idPersona
		 
		  UPDATE PROV_CUENTA_BANCARIA 
		  SET	aprobada = 1
				,PER_IDPERSONA = @idPersona
		  WHERE rfcProspecto= @rfc
		  AND idPerTra = @idPerTra 

		  --UPDATE PROV_CUENTA_BANCARIA 
		  --SET aprobada = 1
		  --WHERE rfcProspecto= @rfc



		  DECLARE @cont INT = 1
				, @idRespuesta   NUMERIC(18,0)
				, @msg VARCHAR(MAX) = ''
				, @cuenta VARCHAR(500)
				, @nombreProveedor VARCHAR(100) = (SELECT TOP 1 'Proveedor: '+ ISNULL(PER_NOMRAZON,'')+' '+ ISNULL(PER_PATERNO,'')+ ' '+ ISNULL(PER_MATERNO,'') + ' RFC : '+ ISNULL(PER_RFC,'') from 	 GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfc)
				,@email VARCHAR(100) = (SELECT correo FROM CENTRALIZACIONv2.DBO.PPRO_USERSPORTALPROV WHERE ppro_user = @rfc)
				
			--SELECT @email

		DECLARE @tblCuentas AS TABLE
		(
		 id INT IDENTITY(1,1)
		,cuenta VARCHAR(MAX)
		
		)

		
		INSERT INTO @tblCuentas 
		SELECT @nombreProveedor
		--SELECT  Distinct 'Proveedor: '+ ISNULL(PER_NOMRAZON,'')+' '+ ISNULL(PER_PATERNO,'')+ ' '+ ISNULL(PER_MATERNO,'') + ' RFC : '+ ISNULL(PER_RFC,'')
		--FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
		--WHERE   CB.rfcProspecto = @rfc

		INSERT INTO @tblCuentas 
		SELECT ' No. cuenta: ' + noCuenta + ' Tipo de cuenta: ' + nombreTipoCtaBancaria + ' Titular Cuenta: ' + titular	+ ' CONVENIO CIE: ' + isnull(cie,'') + ' CLABE: ' + isnull(clabe,'')
		FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
		WHERE   CB.rfcProspecto = @rfc
		
		WHILE(@cont <= (SELECT count(1) FROM @tblCuentas)  )
		BEGIN
				SELECT @msg= @msg +' '+ cuenta + '<br/>'  FROM @tblCuentas where id =@cont
				SET @cont = @cont + 1 
		END
		--SELECT @msg
		
		DECLARE @ip VARCHAR(20) = (SELECT  local_net_address    FROM sys.dm_exec_connections    WHERE Session_id = @@SPID ) 
				,@link VARCHAR(250)
				,@usuario_Autoriza INT
				,@usuarioCorreoAutoriza VARCHAR(250)

		
		SELECT	 @usuario_Autoriza= usuario_autoriza
				,@usuarioCorreoAutoriza = usu_correo 
		FROM	Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION N 
		INNER JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT F ON N.idTipoNotificacion = F.idTipoNotificacion
		INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = F.usuario_autoriza
		WHERE	N.idTipoNotificacion = 4 
		AND		nivel_escalamiento = 0
			
		
		IF(@ip != '192.168.20.29')
		BEGIN
			--SET @link = 'http://'+ @ip+':1200/aprobar?employee=88&idTramite='+CONVERT(VARCHAR(10),@idPerTra)
			SET @link = 'http://'+ @ip+':4010/aprobar?employee='+CONVERT(VARCHAR(10),@usuario_Autoriza)+'&idTramite='+CONVERT(VARCHAR(10),@idPerTra)
		END 
		ELSE
		BEGIN
			SET @link = 'http://192.168.20.89:1200/aprobar?employee='+CONVERT(VARCHAR(10),@usuario_Autoriza)+'&idTramite='+CONVERT(VARCHAR(10),@idPerTra)
		END		 
				
							
				
		EXEC Notificacion.[dbo].[INS_NOTIFICACION_OUTPUT_SP] @rfc,@msg,@usuario_Autoriza,4,null,null,@link,@idPerTra , @result = @idRespuesta OUTPUT
		
		IF(@idRespuesta = -1)
		BEGIN
		   --Provocamos el error  para enviar al catch y hacer  rollback si es que el stored de INS_ESCALAMIENTO_SP nos devuelve un error
			SELECT 1/0
		END


		  SELECT 1 result, @email email, @usuarioCorreoAutoriza usuarioCorreoAutoriza
COMMIT TRANSACTION
END TRY
BEGIN CATCH
ROLLBACK TRANSACTION



		SELECT -1 result, '' email, '' usuarioCorreoAutoriza


END CATCH
   
END
go

