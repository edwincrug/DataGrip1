-- =============================================    
-- Author:  Ricardo Montero Escudero 
-- Create date: 16/12/2015   
-- Description: obtener todas las Sucursales  
-- =============================================    
CREATE PROCEDURE [dbo].[PPRO_ObtenerSucursales]   -- [dbo].[PPRO_ObtenerSucursales]   4
@idProveedor AS INT
AS    
BEGIN    
     
  SELECT DISTINCT([suc_idsucursal])
      ,[suc_nombre]
      ,[suc_nombrecto]
  FROM cuentasxpagar.dbo.cxp_ordencompra OC
  LEFT JOIN [ControlAplicaciones].[dbo].cat_sucursales SC on OC.oce_idsucursal = SC.suc_idsucursal
  WHERE OC.oce_idproveedor = @idProveedor

      
END
go

