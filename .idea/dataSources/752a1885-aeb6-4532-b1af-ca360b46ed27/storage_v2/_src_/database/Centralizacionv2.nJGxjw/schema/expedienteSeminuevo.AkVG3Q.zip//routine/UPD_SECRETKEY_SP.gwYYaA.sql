-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[UPD_SECRETKEY_SP]
	@secretKey VARCHAR(50)
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [expedienteSeminuevo].[parametros] SET par_valor = @secretKey WHERE par_nombre = 'SECRET_KEY';

END

go

