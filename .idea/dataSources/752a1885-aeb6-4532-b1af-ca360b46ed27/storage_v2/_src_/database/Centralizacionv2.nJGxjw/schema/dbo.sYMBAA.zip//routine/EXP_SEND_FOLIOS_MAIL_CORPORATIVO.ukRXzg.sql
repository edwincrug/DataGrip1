-- =============================================
-- Author:
-- Create date:
-- Description:
-- EXP_SEND_FOLIOS_MAIL_CORPORATIVO 5
-- =============================================
CREATE PROCEDURE dbo.EXP_SEND_FOLIOS_MAIL_CORPORATIVO 
@idEmpresa INT
AS
BEGIN
			DECLARE @minDays INT, @maxDays INT;
			SELECT 	@maxDays = par_valor FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MAXESCALAR';
			SELECT 	@minDays = par_valor FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MINESCALAR'
			
			SELECT 		CD.ucn_noserie AS folio,
						C.ucu_idusuarioalta,
						ISNULL(A.PER_NOMRAZON + ' ' + A.PER_PATERNO + ' ' + A.PER_MATERNO,'SIN AGENTE') AS nombre,
						ISNULL(A.PER_Email, 'notiene@notiene.com') usu_correo,
						--U.usu_correo,
						C.ucu_idempresa,
						C.ucu_idsucursal,
						C.ucu_fechacotiza,
						B.nombre_sucursal,
						C.ucu_idcliente,
						P.PER_NOMRAZON + ' ' + P.PER_PATERNO + ' ' + P.PER_MATERNO AS NombreCliente,
						C.ucu_foliocotizacion
						,convert(VARCHAR(10),VW.PEN_FECHAENTREGA_REAL,103) AS PEN_FECHAENTREGA_REAL,
						CD.ucn_idFactura
						FROM EXP_FOLIOS_MAIL M
						INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = M.folio COLLATE DATABASE_DEFAULT
						INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
						--INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = C.ucu_idusuarioalta
						LEFT JOIN GA_Corporativa.DBO.PER_PERSONAS A ON A.PER_IDPERSONA = C.ucu_idagente
						INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = C.ucu_idempresa AND B.suc_idsucursal = C.ucu_idsucursal
						INNER JOIN GA_Corporativa.DBO.PER_PERSONAS P ON P.PER_IDPERSONA = C.ucu_idcliente
						INNER JOIN [VW_FECHA_ENTREGA_UNIDAD] VW ON VW.PEN_NUMSERIE = CD.ucn_noserie AND ucu_idusuarioalta NOT IN (0)
			WHERE M.dias > 6 --@minDays--@maxDays
						AND VW.PEN_FECHAENTREGA_REAL IS NOT NULL AND ucu_idempresa = @idEmpresa
			GROUP BY ucu_idusuarioalta, CD.ucn_noserie, A.PER_NOMRAZON , A.PER_PATERNO , A.PER_MATERNO, A.PER_EMAIL, C.ucu_idempresa, C.ucu_idsucursal, B.nombre_sucursal, C.ucu_idcliente, P.PER_NOMRAZON, P.PER_PATERNO, P.PER_MATERNO, C.ucu_foliocotizacion, VW.PEN_FECHAENTREGA_REAL, CD.ucn_idFactura, C.ucu_fechacotiza
			ORDER BY 6 ASC, 12 ASC

			SELECT 
			usu_correo

			FROM [ControlAplicaciones].[dbo].[cat_usuarios] U
			INNER JOIN Centralizacionv2.dbo.DIG_CATALOGOS C ON U.usu_idusuario = C.cat_valor
			WHERE C.cat_id_padre = 2600
			union all
			SELECT 'javier.hernandezr@grupoandrade.com' usu_correo
			union all
			SELECT 'nikkosteel0310@gmail.com' usu_correo
			--WHERE pto_idpuesto IN (114, 80, 135)
END
go

