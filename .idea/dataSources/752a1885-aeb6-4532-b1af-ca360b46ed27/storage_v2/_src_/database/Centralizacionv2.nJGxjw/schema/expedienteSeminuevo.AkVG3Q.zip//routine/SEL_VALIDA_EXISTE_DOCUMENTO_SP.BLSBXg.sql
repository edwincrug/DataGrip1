-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST SEL_VALIDA_EXISTE_DOCUMENTO_SP 1, 1, 4
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_VALIDA_EXISTE_DOCUMENTO_SP]
	@idProceso INT,
	@idDocumento INT,
	@idExpediente INT
AS
BEGIN

	SET NOCOUNT ON;

	IF NOT EXISTS( SELECT * FROM [expedienteSeminuevo].[documentosExpediente] WHERE id_proceso = @idProceso AND id_documento = @idDocumento AND id_expediente = @idExpediente )
		BEGIN
			SELECT success = 0;
		END
	ELSE
		BEGIN
			SELECT sucess = 1;
		END
END

go

