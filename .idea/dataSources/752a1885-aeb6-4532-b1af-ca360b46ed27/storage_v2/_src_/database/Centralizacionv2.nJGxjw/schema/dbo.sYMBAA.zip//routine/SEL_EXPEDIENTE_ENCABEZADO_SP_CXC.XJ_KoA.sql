-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 19/11/2015
-- Description:	recupera el encabezado del expediente
-- ============================================= ----'AU-ZM-ZAR-UN-22'
-- SEL_EXPEDIENTE_ENCABEZADO_SP_CXC 'AU-ZM-ZAR-UN-22', 1
CREATE PROCEDURE [dbo].[SEL_EXPEDIENTE_ENCABEZADO_SP_CXC]
	 @folio		nvarchar(30)
	,@idusuario	int
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @idProceso  INT=0;

	SELECT @idProceso = E.Proc_Id        
	  FROM  dbo.DIG_EXPEDIENTE AS E 
     WHERE E.Folio_Operacion = @folio

    IF(@idProceso = 1)
	BEGIN
		DECLARE @planta int=0	
		EXECUTE [Centralizacionv2].[dbo].[ES_REFACCIONES_PLANTA_SP]  @folio, @planta output

		SELECT   EM.emp_nombre as empresa
				, S.suc_nombre as agencia
				, D.dep_nombre as departamento
				, E.Folio_Operacion as folio
				, (select TOP 1 Nodo_Id FROM dbo.DIG_EXP_NODO DENT WHERE Proc_Id = E.Proc_Id AND Folio_Operacion = OC.oce_folioorden AND Nodo_Estatus_Id = 2 ) as nodoActual
				, CASE E.Estatus_Id WHEN 1 THEN 'En Proceso' WHEN 2 THEN 'Cancelado' END as estatusExpediente
				, U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno as nombreUsuario
				, (SELECT MAX( CONVERT(DATETIME, CONVERT(CHAR(8),[mov_fechamovimiento], 112) + ' ' + CONVERT(CHAR(8),[mov_horamovimiento], 108))
				) FROM [cuentasxpagar].dbo.cxp_movimientosorden WHERE oce_folioorden = E.Folio_Operacion) as fechaUltimoMovimiento
				,ISNULL(OC.oce_foliopadre , '') folioPadre
				,(SELECT ISNULL(oce_folioorden,'') FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_foliopadre = OC.oce_folioorden AND NOT EXISTS(SELECT 1 FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Operacion = OC.oce_folioorden AND Folio_Alias = oce_folioorden ) ) folioHijo
				,(SELECT Folio_Alias FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Operacion = OC.oce_folioorden) alias--,
				,CASE WHEN @planta = 1 OR oce_idtipoorden IN (4,5) THEN 1 ELSE 0 END as esPlanta
		FROM      dbo.DIG_EXPEDIENTE AS E INNER JOIN
				  --dbo.DIG_EXP_NODO AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion INNER JOIN
				  cuentasxpagar.dbo.cxp_ordencompra AS OC ON OC.oce_folioorden = E.Folio_Operacion INNER JOIN
				  ControlAplicaciones.dbo.cat_usuarios AS U ON OC.oce_idusuario = U.usu_idusuario INNER JOIN
				  ControlAplicaciones.dbo.cat_departamentos AS D ON OC.oce_iddepartamento = D.dep_iddepartamento INNER JOIN
				  ControlAplicaciones.dbo.cat_sucursales AS S ON D.suc_idsucursal = S.suc_idsucursal INNER JOIN
				  ControlAplicaciones.dbo.cat_empresas AS EM ON S.emp_idempresa = EM.emp_idempresa INNER JOIN
				  ControlAplicaciones.dbo.cat_divisiones AS DIV ON EM.div_iddivision = DIV.div_iddivision
		WHERE	  E.Folio_Operacion = @folio
				  OR E.Folio_Operacion IN ( 					  
					SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
				  )
    END

	IF(@idProceso = 2)
	BEGIN

     SELECT  EM.emp_nombre     as empresa
	        ,S.suc_nombre      as agencia
			,D.dep_nombre      as departamento
	        ,E.Folio_Operacion as folio 
			,1                 as nodoActual
			,CASE E.Estatus_Id 
			    WHEN 1 
			        THEN 'En Proceso' 
			    WHEN 2 
			        THEN 'Cancelado' 
			  END              as estatusExpediente
			,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
                FROM BDPersonas.dbo.cat_personas AS PER 
               WHERE PER.per_idpersona = O.ucu_idcliente)     as nombreUsuario
			, GETDATE()        as fechaUltimoMovimiento
			,''                as folioPadre
			,null              as folioHijo
			,null              as alias  
			,O.ucu_idcliente   as esPlanta
			,(SELECT Tip_Id
                FROM Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA
               WHERE Tip_Clave = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS)  as idTipoVenta
            ,(SELECT Tip_Nombre
                FROM Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA
               WHERE Tip_Clave = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS)  as nombreTipoVenta
	  FROM  dbo.DIG_EXPEDIENTE AS E 
			INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
			INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
			INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
			INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
			INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
     WHERE E.Folio_Operacion = @folio
	
	END
	
	
	

END
go

