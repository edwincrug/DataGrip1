-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--[dbo].[SEL_OTRAS_FACTURAS_CXC] 'AU-AU-PED-UN-1', 7
CREATE PROCEDURE [dbo].[SEL_OTRAS_FACTURAS_CXC]
	@folio NVARCHAR(50)  
	,@idCotizacion INT=0
AS
BEGIN
	
	DECLARE @baseSucursal VARCHAR(100) 
	DECLARE @facturaUnidad VARCHAR(MAX) 
	DECLARE @facturaa   INT = 0;
	DECLARE @rfc  VARCHAR(MAX); 
	DECLARE @idEmpresa INT;


	SELECT	@idEmpresa=ucu_idempresa
	FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL 
	WHERE	ucu_foliocotizacion = @folio 

	sET @baseSucursal = [dbo].[base_Cotizacion](@folio)

	--SELECT	@baseSucursal = '['+ ip_servidor + '].[' + nombre_base + '].[dbo].',@idEmpresa=ucu_idempresa
	--FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL CU
	--		INNER JOIN DIG_CAT_BASES_BPRO PRO ON CU.ucu_idempresa = PRO.emp_idEmpresa AND CU.ucu_idsucursal = PRO.suc_idSucursal AND PRO.estatus = 1 AND PRO.tipo = 1
	--WHERE CU.ucu_foliocotizacion = @folio 


	SELECT @rfc=rfc 
	   FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
		WHERE catsuc_nombrecto = 'CONCENTRA' AND  emp_idempresa = @idEmpresa

		SET @facturaUnidad=
							'SELECT     CTUNI.ucn_noserie							  AS numSerie' + char(13) + 
							'			   ,CTUNI.ucn_idFactura                           AS idFactura' + char(13) + 
							'			   ,(SELECT dbo.[fn_BuscaLetras](ucn_idFactura))  AS serie' + char(13) + 
							'			   ,(SELECT dbo.[fn_BuscaNumeros](ucn_idFactura)) AS folio' + char(13) + 
							'			   ,CONVERT(varchar, CAST(SUC.VTE_VTABRUT as money), 1) AS subTotal' + char(13) + 
							'			   ,CONVERT(varchar, CAST(SUC.VTE_IVA as money), 1) as iva' + char(13) + 
							'			   ,CONVERT(varchar, CAST(SUC.VTE_TOTAL as money), 1) as total' + char(13) + 
							'			   ,SUC.VTE_FECHDOCTO' + char(13) + 
							'			   ,'''+@rfc+'''AS rfc'+
							'		  FROM [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] CTUNI' + char(13) + 
							'		  INNER JOIN '+@baseSucursal+'ADE_VTAFI SUC ON SUC.VTE_DOCTO=CTUNI.ucn_idFactura' + char(13) + 
							'         WHERE CTUNI.ucu_idcotizacion  = '''+CONVERT(VARCHAR(MAX),@idCotizacion)+'''' + char(13) + 
							'' 
print(@baseSucursal)
EXECUTE(@facturaUnidad)
	
END
go

