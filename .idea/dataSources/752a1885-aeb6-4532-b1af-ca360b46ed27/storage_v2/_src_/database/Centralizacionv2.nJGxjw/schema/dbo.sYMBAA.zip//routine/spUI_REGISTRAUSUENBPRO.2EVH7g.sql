/*
NOTA: falta validar cuando copia los parametros desde otro usuario que no son la misma base
el parametro AREPED no es el mismo... faltaria integrar el store que crea las Areas de integracion.

SIRVE: Para registrar [ó corregir] usuarios en BPRO
REQUIERE: Nombre de la Base de Datos a Afectar. si se declara como [192.168.20.XX].[NombreBase] indica que no está centralizada.
												si solo se da el nombre de la base de datos la busca en DIG_CAT_BASES_BPRO

FUNCIONAMIENTO: 
Cicla por cada registro en la tabla DIG_USERSPASO
Si el campo 3 letras es nulo en esta tabla, descompone el nombre en sus 3 letras.
busca a este usuario por sus 3 letras y apellido paterno, materno y nombre y si no esta dado de alta, 
lo registra en [@sBaseDatos].[dbo].[PNC_USUARIOS]. (resuelve el conflicto cuando ya hay un usuario con sus mismas 3 letras)
le clona el menu a partir del usuario DIG_USERSPASO!USRBASECLONAR.
si el puesto es APV lo da de alta en el parámetro EV requiere el campo DIG_USERSPASO!IDPERSONA 
si el puesto es APV le registra el AREAFEUSU

Si el usuario ya esta dado de alta agrega lo que tenga que agregar al registro de este usuario.
Corrige el registro al borrar y setear en transaccion la configuracion del DIG_USERSPASO!USRBASECLON

CREATE TABLE [dbo].[DIG_USERSPASO](
	[ID_LOCAL] [int] IDENTITY(1,1) NOT NULL,	
	[USR3LETRAS] [varchar](10) NULL,  --si es nulo lo deduce del apaterno, amaterno + nombre
	[APATERNO] [varchar](80) NOT NULL,
	[AMATERNO] [varchar](80) NULL,
	[NOMBRE] [varchar](80) NOT NULL,
	[BASEDESTINO] [varchar](80) NOT NULL,   --Nombre de la base de datos Puede ser con IP o no donde se va a registrar el usuario.
	[USRBASECLONAR] [varchar](80) NOT NULL, --Son las 3letras del usuario base (tal y como esta en PNC_USUARIOS en BPRO), que se toma como base a clonar todo sus parametros, "Copiale al usuario destino, toda la configuracion que tenga el usuario "USRBASECLONAR" 
	[BASEORIGENCLONAR] [varchar](80) NULL,  --Donde ya existe el usuario "USRBASECLONAR" y se le va a copiar todo lo que tenga en esa base. Puede estar en otro servidor (poner ruta completa si es el caso), Centralizada o no.
	[IDPUESTO] [varchar](10) NULL,          --La clave del puesto del usuario necesaria para saber si es APV u otro tipo de usuario se lee de: SELECT USU_PUESTO,* FROM GAAA_Azcapo..PNC_USUARIOS where USU_IDUSUARI = 'APB'.
	[IDPERSONA] [int] NULL			        --si es APV necesita ser registrada su id_persona en el parámetro EV
) ON [PRIMARY]
GO


*/

CREATE PROCEDURE [dbo].[spUI_REGISTRAUSUENBPRO]  --with recompile
 AS
declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@sIp nvarchar(20),
@sIpbase nvarchar(20),
@iIdEmpresa int,
@iIdSucursal int,
@ipLocal VARCHAR(50),
@sAuxIP varchar(50),
@sAuxIPbase varchar(50),
@sNomBase varchar(100)
begin 

set nocount on

Declare @sUsr3letras varchar(10)='';
Declare @iMin int = 0;
Declare @iTope int = 0;
Declare @iIndice int = 0;
Declare @iIdPersona int = 0;
Declare @sUsr3letrasAux varchar(10) = '';
Declare @sQueHacer varchar(50)='';
Declare @sBDCentralizada varchar(2)='NO';


Select @iIndice = Isnull(Min(ID_LOCAL),0) from DIG_USERSPASO
select @iTope = Isnull(Max(ID_LOCAL),0) from DIG_USERSPASO

if (@iIndice>0)
begin
		
	WHILE (@iIndice<=@iTope) 
		  BEGIN				
			 Select @sUsr3letras = Isnull(USR3LETRAS,''), @sNomBase = BASEDESTINO from DIG_USERSPASO  where ID_LOCAL = @iIndice
------------INICIA VALIDACION DE LA BASE   -------------
						--Validamos si esta centralizada la base de datos.
						--Es mejor buscarla en la tabla de Centralizacion..DIG_CAT_BASES_BPRO. 
						 if Exists (Select 1 from Centralizacionv2..DIG_CAT_BASES_BPRO where nombre_base = @sNomBase)
						   begin
							  --print 'Centralizada'
							  select @iIdEmpresa = emp_idempresa, @iIdSucursal =  suc_idsucursal from Centralizacionv2..DIG_CAT_BASES_BPRO where nombre_base = @sNomBase
							  --print Convert(char(1),@iIdEmpresa)
							  --print Convert(char(2),@iIdSucursal)
							 Select @sIP = ip_servidor, @sNomBase = nombre_base from Centralizacionv2..DIG_CAT_BASES_BPRO where emp_idempresa = @iIdEmpresa and suc_idsucursal = @iIdSucursal
							 select @sBDCentralizada='SI'
						   end
						else
							begin
	 									Select @sIP  = SUBSTRING(@sNomBase,1,PATINDEX('%]%',@sNomBase))
										Select @sIP = Replace(@sIP,'[','');
										Select @sIP = Replace(@sIP,']','');
										select @sNomBase = SUBSTRING(@sNomBase,PATINDEX('%]%',@sNomBase)+2,len(@sNomBase)) 
										Select @sNomBase = Replace(@sNomBase,'[','');
										Select @sNomBase = Replace(@sNomBase,']','');
		   								--print '@sIP: ' +  @sIP
										--print '@sNomBase: ' + @sNomBase

										if Not Exists (Select 1 from Centralizacionv2..DIG_CAT_BASES_BPRO where nombre_base = @sNomBase)
										begin
											select @sBDCentralizada='NO'
										end
							end

						--validar si se corre en el servidor local
						SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
						  FROM sys.dm_exec_connections c
						 ORDER BY local_net_address DESC
						if (@ipLocal = @sIP)
						begin   
							   select @sAuxIP = ''
						end
						else
						begin	   
							   select @sAuxIP = '[' + @sIP + '].'
						end
						------------------------- TERMINA LO DE LA BASE   --------------------
			 			 			 			 
			 if (@sUsr3letras='')
			 begin 
			     Select @sUsr3letras =  SUBSTRING(APATERNO,1,1) + SUBSTRING(AMATERNO,1,1) + SUBSTRING(NOMBRE,1,1)  From  DIG_USERSPASO  where ID_LOCAL = @iIndice
				 print 'Usuario 3 letras calculado: ' + @sUsr3letras
			 end			  	    
			 --Teniendo el usuairo 3 letras validamos si ya esta registrado en la base de datos.
			 --BUSCAMOS AL USUARIO de las 3 letras en la Base Operativa.				
				--nos quedamos solo con el usuario de Bpro es decir solo las 3 letras de BPRO, puede o no venir con los dígitos de la sucursal
				SELECT @sUsr3letrasAux = substring(@sUsr3letras,PATINDEX('%[^0-9]%',@sUsr3letras),len(@sUsr3letras)) --as usuario3Letras				
				
				--consultamos el nombre desde la base de BPRo.
				Declare @sUSU_APUSUARI varchar(50) = '';
				Declare @sUSU_AMUSUARI varchar(50) = '';
				Declare @sUSU_NOUSUARI varchar(50) = '';
				Declare @sUSU_CVEACCES varchar(20) = null;
				Declare @susu_idusuari varchar(10) = '';
				Declare @sUSU_BASE varchar(10) = '';
				Declare @iID_PERSONA int = 0;
				Declare @sID_PUESTO varchar(50)='';
				Declare @iHayParametros int = 0;
				Declare @sPuesto varchar(150) = '';
				DEclare @sBaseOrigenClonar varchar(300)='';
				declare @sapate_dig  varchar(100) = '';
				declare @snombre_dig varchar(100) = '';
				declare @samate_dig  varchar(100) = '';


				select @sUSU_BASE = USRBASECLONAR , @sBaseOrigenClonar = BASEORIGENCLONAR from DIG_USERSPASO where ID_LOCAL = @iIndice
				Select @sIpbase  = SUBSTRING(@sBaseOrigenClonar,1,PATINDEX('%]%',@sBaseOrigenClonar))
				Select @sIpbase = Replace(@sIpbase,'[','');
				Select @sIpbase = Replace(@sIpbase,']','');
				select @sBaseOrigenClonar = SUBSTRING(@sBaseOrigenClonar,PATINDEX('%]%',@sBaseOrigenClonar)+2,len(@sBaseOrigenClonar)) 
				Select @sBaseOrigenClonar = Replace(@sBaseOrigenClonar,'[','');
				Select @sBaseOrigenClonar = Replace(@sBaseOrigenClonar,']','');
				--print 'ip obtenida desde DIG_USERSPASO!BASEORIGENCLONAR @sIPbase: ' +  @sIPbase
				print '@sBaseOrigenClonar: ' + @sBaseOrigenClonar
				if (@ipLocal = @sIPbase)
					begin   
						select @sAuxIPbase = ''
					end
					else
					begin	   
						select @sAuxIPbase = '[' + @sIPbase + '].'
					end


				set @sQ = N'select @sUSU_APUSUARIOUT = USU_APUSUARI,@sUSU_AMUSUARIOUT = USU_AMUSUARI,@sUSU_NOUSUARIOUT = USU_NOUSUARI,@sUSU_CVEACCESOUT = USU_CVEACCES, @susu_idusuariOUT = usu_idusuari  from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_USUARIOS] where usu_idusuari like ' + char(39) + @sUsr3letrasAux + char(37) + char(39)
				SET @sParmDefinition = N'@sUSU_APUSUARIOUT varchar(50) OUTPUT, @sUSU_AMUSUARIOUT varchar(50) OUTPUT, @sUSU_NOUSUARIOUT varchar(50) OUTPUT, @sUSU_CVEACCESOUT varchar(20) OUTPUT, @susu_idusuariOUT varchar(10) OUTPUT';
				--print @sQ
				EXECUTE sp_executesql @sQ, @sParmDefinition, @sUSU_APUSUARIOUT=@sUSU_APUSUARI OUTPUT,@sUSU_AMUSUARIOUT = @sUSU_AMUSUARI OUTPUT,@sUSU_NOUSUARIOUT = @sUSU_NOUSUARI OUTPUT, @sUSU_CVEACCESOUT = @sUSU_CVEACCES OUTPUT, @susu_idusuariOUT = @susu_idusuari OUTPUT; 

			if (@sUSU_APUSUARI='' and @sUSU_NOUSUARI='')	
			begin			  
					Print 'NO SE ENCONTRO AL USUARIO ' + @sUsr3letrasAux + ' EN la base: ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_USUARIOS] where usu_idusuari like ' + char(39) + @sUsr3letrasAux + CHAR(37) + char(39)
					select @sQueHacer='RegistrarCompleto'
					select @sUSU_APUSUARI = APATERNO, @sUSU_AMUSUARI = AMATERNO , @sUSU_NOUSUARI = NOMBRE,@sUSU_BASE = USRBASECLONAR  from DIG_USERSPASO where ID_LOCAL = @iIndice

			end -- de que el usuairo 3 letras no se encontró
			else
			  begin
			     
			     --se encontro un usuario con las 3 letras vemos si es el mismo deben coincidir apellido paterno y nombre
				 print 'El usuario: ' + @sUsr3letrasAux  + '  ' + @susu_idusuari  +  ' ' + @sUSU_APUSUARI + ' ' + @sUSU_AMUSUARI + ' ' + @sUSU_NOUSUARI + ' ya existe en la base: ' + @sNomBase +  '  validando que sea el mismo: ' 
				 If Exists (select 1 from DIG_USERSPASO where APATERNO=@sUSU_APUSUARI and Replace(NOMBRE,' ','')=@sUSU_NOUSUARI and AMATERNO=@sUSU_AMUSUARI and  ID_LOCAL = @iIndice)
				 begin
				   select  @sUsr3letrasAux = @susu_idusuari;				   
				   select @sQueHacer='UsuarioExisteCorregirRegistro'
				   print 'se trata del mismo usuario se procede a su correccion en la base: ' + @sNomBase;
				 end 				 
			  end

							select @iID_PERSONA = isnull(IDPERSONA,0),  @sID_PUESTO = IDPUESTO from DIG_USERSPASO where ID_LOCAL = @iIndice			  				
							set @sQ = N'select @sPuestoOUT = PAR_DESCRIP1  from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] where PAR_TIPOPARA = ' + char(39) + 'PO' + char(39) + ' and PAR_IDENPARA=' + char(39) +  ltrim(rtrim(@sID_PUESTO))  + char(39)
							SET @sParmDefinition = N'@sPuestoOUT varchar(150) OUTPUT';
							--print @sQ
							EXECUTE sp_executesql @sQ, @sParmDefinition, @sPuestoOUT= @sPuesto OUTPUT; 

			  ------------------------------------------------------------------------

			  						   --buscamos al usuairo en cat_usuarios...									   
									   -- Tecnico parámetro EM
									   Declare @iusu_idusuario int = -1;									   
									   --ltrim(rtrim(convert(char(10),@iIdSucursal) ))
									   Declare @susu_nombreusu varchar(10)									     

											Declare	@sUsr3letrasALTA varchar(10);
											Declare  @sOPCION varchar(50) = 'AMBOS'; --'CXP'| 'CXC' si el perfil no es APV debemos cambiar a CXP
											Declare @sCSVDeptos varchar(200) = char(39) + 'UN' + char(39) + ',' + char(39) + 'US' + char(39) + ',' + char(39) + 'RE' + char(39) + ',' + char(39) + 'SE' + char(39) + ',' + char(39) + 'OT' + char(39)
											DECLARE @sPerfilDigitalizacion varchar(50) = 'BASICO'; --'CORPORATIVO'
											Declare @iResultado int = -1;

											print 'Buscando al usuario en cat_usuarios ' 
											--print '@sUSU_APUSUARI : ' + @sUSU_APUSUARI
											--print '@sUSU_AMUSUARI : ' + @sUSU_AMUSUARI
											--print '@sUSU_NOUSUARI : '  + @sUSU_NOUSUARI
											--print ' usu_nombreusu like ' + char(39) + char(37) + @sUsr3letrasAux +  char(37) + char(39) 
											select top 1 @iusu_idusuario = usu_idusuario, @susu_nombreusu = usu_nombreusu, @snombre_dig = usu_nombre, @sapate_dig = usu_paterno,@samate_dig = usu_materno 
											from ControlAplicaciones..cat_usuarios 
											where usu_paterno=rtrim(ltrim(@sUSU_APUSUARI)) 
											  and usu_materno=rtrim(ltrim(@sUSU_AMUSUARI)) 
											  and usu_nombre = rtrim(ltrim(@sUSU_NOUSUARI)) 											  
											  and usu_nombreusu like + char(37) + rtrim(ltrim(@sUsr3letrasAux))											   
											print '@iusu_idusuario :' + Convert(char(10),@iusu_idusuario) 

			  if (@sQueHacer='RegistrarCompleto')
			  begin
			     BEGIN TRANSACTION RegistraUsuarioEnBPro
				    BEGIN TRY
			           set @sQ = N'	INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_USUARIOS]'
							set @sQ = @sQ + N'([USU_IDUSUARI]'
							set @sQ = @sQ + N',[USU_APUSUARI]'
							set @sQ = @sQ + N',[USU_AMUSUARI]'
							set @sQ = @sQ + N',[USU_NOUSUARI]'
							set @sQ = @sQ + N',[USU_DEPTO]'
							set @sQ = @sQ + N',[USU_CVEACCES]'
							set @sQ = @sQ + N',[USU_STATUS]'
							set @sQ = @sQ + N',[USU_CVEUSU]'
							set @sQ = @sQ + N',[USU_FECHOPE]'
							set @sQ = @sQ + N',[USU_CVEEMP]'
							set @sQ = @sQ + N',[USU_PUESTO]'
							set @sQ = @sQ + N',[USU_FECHA]'
							set @sQ = @sQ + N',[USU_DIAS]'
							set @sQ = @sQ + N',[USU_IDPERSONA]'
							set @sQ = @sQ + N',[USU_IDEMPRESA]'
							set @sQ = @sQ + N',[USU_CVEMOVIL])'
							set @sQ = @sQ + N'select '		
							set @sQ = @sQ + N' ' + char(39) + ltrim(rtrim(@sUsr3letrasAux)) + char(39) + ',' -- (<USU_IDUSUARI, varchar(10),>
							set @sQ = @sQ + N' ' + char(39) + ltrim(rtrim(@sUSU_APUSUARI))  + char(39) + ',' -- ,<USU_APUSUARI, varchar(40),>
							set @sQ = @sQ + N' ' + char(39) + ltrim(rtrim(@sUSU_AMUSUARI))  + char(39) + ',' --        ,<USU_AMUSUARI, varchar(40),>
							set @sQ = @sQ + N' ' + char(39) + ltrim(rtrim(@sUSU_NOUSUARI))  + char(39) + ',' --,<USU_NOUSUARI, varchar(40),>
							set @sQ = @sQ + N' USU_DEPTO,' 				 			   --,<USU_DEPTO, varchar(10),>
							set @sQ = @sQ + N'' + char(39) +  '0604050C' + char(39) + ','  --,<USU_CVEACCES, varchar(200),> 1234
							set @sQ = @sQ + N'' + char(39) +  'A' + char(39) + ','  --,<USU_STATUS, varchar(1),>
							set @sQ = @sQ + N'' + char(39) +  'STOR' + char(39) + ','  --,<USU_CVEUSU, varchar(10),>
							set @sQ = @sQ + N'' + char(39) +  Convert(char(10),getdate(),103) + char(39) + ','  --,<USU_FECHOPE, varchar(10),>
							set @sQ = @sQ + N'' + char(39) +  '' + char(39) + ','  --,<USU_CVEEMP, varchar(10),>
							set @sQ = @sQ + N' USU_PUESTO,' 				 			   --,<USU_PUESTO, varchar(20),>
							set @sQ = @sQ + N'' + char(39) +  Convert(char(10),getdate(),103) + char(39) + ','  --,<USU_FECHA, varchar(10),>
							set @sQ = @sQ + N'' + char(39) +  '999' + char(39) + ','  --,<USU_DIAS, varchar(5),>
							set @sQ = @sQ + N' -1,'   								 --,<USU_IDPERSONA, numeric(18,0),>
							set @sQ = @sQ + N'  USU_IDEMPRESA,'  --,<USU_IDEMPRESA, varchar(3),>
							set @sQ = @sQ + N'' + char(39) +  ' ' + char(39)   --,<USU_CVEMOVIL, varchar(200),>)
							set @sQ = @sQ + N' from ' + @sAuxIPbase + '[' + @sBaseOrigenClonar + '].[dbo].[PNC_USUARIOS] WHERE USU_IDUSUARI = ' + char(39) + @sUSU_BASE + char(39)
							print @sQ
							EXECUTE sp_executesql @sQ
							print 'Se inserto en PNC_USUARIOS'

							--Clonamos el menu 
							set @sQ = N'	INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_OPCUSUAR]'
							set @sQ = @sQ + N'([OPC_IDUSUARI]'
							set @sQ = @sQ + N',[OPC_IDMENUGR]'
							set @sQ = @sQ + N',[OPC_ORDENOPC]'
							set @sQ = @sQ + N',[OPC_NIVEL]'
							set @sQ = @sQ + N',[OPC_CVEUSU]'
							set @sQ = @sQ + N',[OPC_FECHOPE])'     
							set @sQ = @sQ + N' select '	 
							set @sQ = @sQ + N' ' + char(39) + ltrim(rtrim(@sUsr3letrasAux)) + char(39) + ',' --(<OPC_IDUSUARI, varchar(10),>
							set @sQ = @sQ + N' OPC_IDMENUGR,' --,<OPC_IDMENUGR, numeric(18,0),>
							set @sQ = @sQ + N' OPC_ORDENOPC,' --,<OPC_ORDENOPC, numeric(18,0),>
							set @sQ = @sQ + N' OPC_NIVEL,' --,<OPC_NIVEL, numeric(18,0),>
							set @sQ = @sQ + N' OPC_CVEUSU,' --,<OPC_CVEUSU, varchar(10),>
							set @sQ = @sQ + N' OPC_FECHOPE ' --,<OPC_FECHOPE, varchar(10),>)
							set @sQ = @sQ + N' from ' + @sAuxIPbase + '[' + @sBaseOrigenClonar + '].[dbo].[PNC_OPCUSUAR] WHERE OPC_IDUSUARI = ' + char(39) + @sUSU_BASE + char(39)
							print @sQ
							EXECUTE sp_executesql @sQ
							print 'Se clonó el menú'

							if (@sPuesto='APV' or @sPuesto = 'EJECUTIVO DE VENTAS')
							begin
							   --se trata de un vendedor buscamos si está declarado en el parámetro EV
							    Declare @sNombreEnEV varchar(500)='';
							    set @sQ = N'select @sNombreEnEVOUT = PAR_DESCRIP1  from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] where PAR_TIPOPARA = ' + char(39) + 'EV' + char(39) + ' and PAR_IDENPARA=' + char(39) +  ltrim(rtrim(convert(CHAR(10),@iID_PERSONA)))   + char(39)
								SET @sParmDefinition = N'@sNombreEnEVOUT varchar(500) OUTPUT';
								--print @sQ
								EXECUTE sp_executesql @sQ, @sParmDefinition, @sNombreEnEVOUT= @sNombreEnEV OUTPUT; 
								if (@sNombreEnEV='' and @iID_PERSONA<>0)
								begin
								   --no esta en el parametro EV lo insertamos.
								   set @sQ = N'	INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR]'
									set @sQ = @sQ + N'	([PAR_TIPOPARA],[PAR_IDENPARA],[PAR_IDMODULO],[PAR_DESCRIP1],[PAR_DESCRIP2],[PAR_DESCRIP3],[PAR_DESCRIP4],[PAR_DESCRIP5]'
									set @sQ = @sQ + N'	,[PAR_STATUS],[PAR_IMPORTE1],[PAR_IMPORTE2],[PAR_IMPORTE3],[PAR_IMPORTE4],[PAR_IMPORTE5],[PAR_FECHA1],[PAR_FECHA2],[PAR_FECHA3]'
									set @sQ = @sQ + N'	,[PAR_HORA1],[PAR_HORA2],[PAR_HORA3],[PAR_CVEUSU],[PAR_FECHOPE],[PAR_HORAOPE])'
									set @sQ = @sQ + N'	     VALUES ('
									set @sQ = @sQ + N'' + char(39) + 'EV' + char(39) + ',' --(<PAR_TIPOPARA, varchar(10),>
									set @sQ = @sQ + N'' + char(39) + ltrim(rtrim(convert(char(15),@iID_PERSONA))) + char(39) + ',' --,<PAR_IDENPARA, varchar(20),>
									set @sQ = @sQ + N'' + char(39) + 'UNI' + char(39) + ',' --,<PAR_IDMODULO, varchar(3),>
									set @sQ = @sQ + N' ' + char(39) + ltrim(rtrim(@sUSU_NOUSUARI))  +  ' ' +  ltrim(rtrim(@sUSU_APUSUARI))  + ' ' + ltrim(rtrim(@sUSU_AMUSUARI))  + char(39) + ',' --,<PAR_DESCRIP1, varchar(100),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_DESCRIP2, varchar(100),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_DESCRIP3, varchar(100),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_DESCRIP4, varchar(100),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_DESCRIP5, varchar(100),>
									set @sQ = @sQ + N'' + char(39) + 'A' + char(39) + ',' --,<PAR_STATUS, varchar(60),>
									set @sQ = @sQ + N'' + ltrim(rtrim(convert(char(15),@iID_PERSONA))) + ',' --,<PAR_IMPORTE1, decimal(18,5),>
									set @sQ = @sQ + N'0,' --,<PAR_IMPORTE2, decimal(18,5),>
									set @sQ = @sQ + N'0,' --,<PAR_IMPORTE3, decimal(18,5),>
									set @sQ = @sQ + N'0,' --,<PAR_IMPORTE4, decimal(18,5),>
									set @sQ = @sQ + N'0,' --,<PAR_IMPORTE5, decimal(18,5),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_FECHA1, char(10),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_FECHA2, char(10),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_FECHA3, char(10),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_HORA1, char(5),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_HORA2, char(5),>
									set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_HORA3, char(5),>
									set @sQ = @sQ + N'' + char(39) + 'STOR' + char(39) + ',' --,<PAR_CVEUSU, varchar(10),>
									set @sQ = @sQ + N'' + char(39) +  Convert(char(10),getdate(),103) + char(39) + ',' --,<PAR_FECHOPE, varchar(10),>
									set @sQ = @sQ + N'NULL)' --,<PAR_HORAOPE, varchar(5),>)
									print @sQ
									EXECUTE sp_executesql @sQ
									print 'Se insertó en el parametro EV'
								end
							end							
							--clonamos toda su parametrizacion:							
							set @sQ = N'select @iHayParametrosOUT = Count(PAR_TIPOPARA) from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] where PAR_IDENPARA = ' + char(39) + @sUsr3letrasAux + char(39) 
							SET @sParmDefinition = N'@iHayParametrosOUT int OUTPUT';
							--print @sQ
							EXECUTE sp_executesql @sQ, @sParmDefinition, @iHayParametrosOUT= @iHayParametros OUTPUT; 
							if (@iHayParametros>0)
							begin
							   set @sQ = N'Delete ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] where PAR_IDENPARA = ' + char(39) + @sUsr3letrasAux + char(39)
							   EXECUTE sp_executesql @sQ
							end
									set @sQ = N'	INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] '
									set @sQ = @sQ + N'	([PAR_TIPOPARA],[PAR_IDENPARA],[PAR_IDMODULO],[PAR_DESCRIP1],[PAR_DESCRIP2],[PAR_DESCRIP3],[PAR_DESCRIP4],[PAR_DESCRIP5]'
									set @sQ = @sQ + N'	,[PAR_STATUS],[PAR_IMPORTE1],[PAR_IMPORTE2],[PAR_IMPORTE3],[PAR_IMPORTE4],[PAR_IMPORTE5],[PAR_FECHA1],[PAR_FECHA2],[PAR_FECHA3]'
									set @sQ = @sQ + N'	,[PAR_HORA1],[PAR_HORA2],[PAR_HORA3],[PAR_CVEUSU],[PAR_FECHOPE],[PAR_HORAOPE])'
									set @sQ = @sQ + N'	select PAR_TIPOPARA, ' + char(39) + @sUsr3letrasAux + char(39) + ',[PAR_IDMODULO],[PAR_DESCRIP1],[PAR_DESCRIP2],[PAR_DESCRIP3],[PAR_DESCRIP4],[PAR_DESCRIP5]'
									set @sQ = @sQ + N'	,[PAR_STATUS],[PAR_IMPORTE1],[PAR_IMPORTE2],[PAR_IMPORTE3],[PAR_IMPORTE4],[PAR_IMPORTE5],[PAR_FECHA1],[PAR_FECHA2],[PAR_FECHA3]'
									set @sQ = @sQ + N'	,[PAR_HORA1],[PAR_HORA2],[PAR_HORA3],[PAR_CVEUSU],[PAR_FECHOPE],[PAR_HORAOPE]'
									set @sQ = @sQ + N'	from ' + @sAuxIPbase + '[' + @sBaseOrigenClonar + '].[dbo].[PNC_PARAMETR] where PAR_IDENPARA = ' +char(39) + @sUSU_BASE + char(39)
									print @sQ
									EXECUTE sp_executesql @sQ
									print 'Se clonaron todos los parametros de :' + @sUSU_BASE +  ' en  PNC_PARAMETR hacia ' + @sUsr3letrasAux
									
									
									if (@sBDCentralizada='SI')
									begin
										    --select @iusu_idusuario= usu_idusuario, @susu_nombreusu = usu_nombreusu, @snombre_dig = usu_nombre, @sapate_dig = usu_paterno,@samate_dig = usu_materno from ControlAplicaciones..cat_usuarios where usu_paterno=@sUSU_APUSUARI and usu_materno=@sUSU_AMUSUARI and usu_nombre = @sUSU_NOUSUARI and usu_nombreusu like  + char(39) + char(37) + @sUsr3letrasAux + char(39)

											if (@sPuesto='APV' or @sPuesto = 'EJECUTIVO DE VENTAS')
											begin
											  select @sOPCION = 'AMBOS';
											  select @sCSVDeptos = char(39) + 'UN' + char(39) + ',' + char(39) + 'OT' + char(39)
											end
											else
											begin
											  select @sOPCION = 'CXP';
											  select @sCSVDeptos = char(39) + 'UN' + char(39) + ',' + char(39) + 'US' + char(39) + ',' + char(39) + 'RE' + char(39) + ',' + char(39) + 'SE' + char(39) + ',' + char(39) + 'OT' + char(39)
											end
									
									   if (@iusu_idusuario=-1)
									   begin
									        print 'No se encontró al asuario en digitalizacion se dará de alta.'
											select @sUsr3letrasALTA =  ltrim(rtrim(convert(char(10),@iIdSucursal) )) + @sUsr3letrasAux;
											Execute Centralizacionv2..spI_INSERTAUSUARIODIGITALIZACION_Correcto @sUsr3letrasALTA,@sNomBase, @sOPCION,@sCSVDeptos, @sPerfilDigitalizacion,@iResultado OUTPUT
											print 'Usuario dado de alta con el id: ' + ltrim(rtrim(Convert(char(5),@iResultado)))
											print '-------------TERMINA REGISTRO DE USUARIO EN DIGITALIZACION--------------'
									   end	--de que no se encontro a un usuario con las 3 letras en digitalizacion
									   else
									   begin									        
										   print 'Se encontró al usuario en DIGITALIZACION ControlAplicaciones..cat_usuarios se agrega o corrige equivalencia:' + ltrim(rtrim(Convert(char(10),@iusu_idusuario)))  + ' ' + ltrim(rtrim(@susu_nombreusu)) + ' base:  ' + ltrim(rtrim(@sNomBase))												   
										   Execute Centralizacionv2..spI_INSERTAUSUARIODIGITALIZACION_Correcto @susu_nombreusu,@sNomBase, @sOPCION,@sCSVDeptos, @sPerfilDigitalizacion,@iResultado OUTPUT
										   print '--------------TERMINA CORRECCIONES DE USUARIO EN DIGITALIZACION ------------'
									   end
									end
									
									COMMIT TRANSACTION RegistraUsuarioEnBPro
									print 'Usuario:' + @sUsr3letrasAux +  ' Registrado CORRECTAMENTE en  BPRO'
				 
				 END TRY
				 BEGIN CATCH	
					ROLLBACK TRAN RegistraUsuarioEnBPro
					PRINT ('Error: ' + ERROR_MESSAGE())	
					print 'Hubo errores el usuario: '  + @sUsr3letrasAux +  ' NO fue Registrado en  BPRO'
				END CATCH
			  end
			  -------------------------------------------------------------------------
			   if (@sQueHacer='UsuarioExisteCorregirRegistro')
			  begin
			     print 'Corrigiendo El registro del usuario, menu y parametros.'
				  BEGIN TRANSACTION CorrigeUsuarioEnBPro
				  Begin Try	
							--select * from GAAA_Azcapo..pnc_opcusuar where opc_idusuari = 'BAL'
				 			Declare @iHayMenu int = 0;
							set @sQ = N'select @iHayMenuOUT = Count(OPC_IDUSUARI) from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[pnc_opcusuar] where OPC_IDUSUARI = ' + char(39) + @sUsr3letrasAux + char(39) 
							SET @sParmDefinition = N'@iHayMenuOUT int OUTPUT';
							--print @sQ
							EXECUTE sp_executesql @sQ, @sParmDefinition, @iHayMenuOUT= @iHayMenu OUTPUT; 
							if (@iHayMenu>0)
							begin
							   set @sQ = N'Delete ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[pnc_opcusuar] where OPC_IDUSUARI = ' + char(39) + @sUsr3letrasAux + char(39)
							   EXECUTE sp_executesql @sQ
							end
							--Clonamos el menu 
							set @sQ = N'	INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_OPCUSUAR]'
							set @sQ = @sQ + N'([OPC_IDUSUARI]'
							set @sQ = @sQ + N',[OPC_IDMENUGR]'
							set @sQ = @sQ + N',[OPC_ORDENOPC]'
							set @sQ = @sQ + N',[OPC_NIVEL]'
							set @sQ = @sQ + N',[OPC_CVEUSU]'
							set @sQ = @sQ + N',[OPC_FECHOPE])'     
							set @sQ = @sQ + N' select '	 
							set @sQ = @sQ + N' ' + char(39) + ltrim(rtrim(@sUsr3letrasAux)) + char(39) + ',' --(<OPC_IDUSUARI, varchar(10),>
							set @sQ = @sQ + N' OPC_IDMENUGR,' --,<OPC_IDMENUGR, numeric(18,0),>
							set @sQ = @sQ + N' OPC_ORDENOPC,' --,<OPC_ORDENOPC, numeric(18,0),>
							set @sQ = @sQ + N' OPC_NIVEL,' --,<OPC_NIVEL, numeric(18,0),>
							set @sQ = @sQ + N' OPC_CVEUSU,' --,<OPC_CVEUSU, varchar(10),>
							set @sQ = @sQ + N' OPC_FECHOPE ' --,<OPC_FECHOPE, varchar(10),>)
							set @sQ = @sQ + N' from ' + @sAuxIPbase + '[' + @sBaseOrigenClonar + '].[dbo].[PNC_OPCUSUAR] WHERE OPC_IDUSUARI = ' + char(39) + @sUSU_BASE + char(39)
							print @sQ
							EXECUTE sp_executesql @sQ
							print 'Se clonó el menú en correccion de usuario'

							--clonamos toda su parametrizacion:							
							set @sQ = N'select @iHayParametrosOUT = Count(PAR_TIPOPARA) from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] where PAR_IDENPARA = ' + char(39) + @sUsr3letrasAux + char(39) 
							SET @sParmDefinition = N'@iHayParametrosOUT int OUTPUT';
							--print @sQ
							EXECUTE sp_executesql @sQ, @sParmDefinition, @iHayParametrosOUT= @iHayParametros OUTPUT; 
							if (@iHayParametros>0)
							begin
							   set @sQ = N'Delete ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] where PAR_IDENPARA = ' + char(39) + @sUsr3letrasAux + char(39)
							   EXECUTE sp_executesql @sQ
							end
									set @sQ = N'	INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] '
									set @sQ = @sQ + N'	([PAR_TIPOPARA],[PAR_IDENPARA],[PAR_IDMODULO],[PAR_DESCRIP1],[PAR_DESCRIP2],[PAR_DESCRIP3],[PAR_DESCRIP4],[PAR_DESCRIP5]'
									set @sQ = @sQ + N'	,[PAR_STATUS],[PAR_IMPORTE1],[PAR_IMPORTE2],[PAR_IMPORTE3],[PAR_IMPORTE4],[PAR_IMPORTE5],[PAR_FECHA1],[PAR_FECHA2],[PAR_FECHA3]'
									set @sQ = @sQ + N'	,[PAR_HORA1],[PAR_HORA2],[PAR_HORA3],[PAR_CVEUSU],[PAR_FECHOPE],[PAR_HORAOPE])'
									set @sQ = @sQ + N'	select PAR_TIPOPARA, ' + char(39) + @sUsr3letrasAux + char(39) + ',[PAR_IDMODULO],[PAR_DESCRIP1],[PAR_DESCRIP2],[PAR_DESCRIP3],[PAR_DESCRIP4],[PAR_DESCRIP5]'
									set @sQ = @sQ + N'	,[PAR_STATUS],[PAR_IMPORTE1],[PAR_IMPORTE2],[PAR_IMPORTE3],[PAR_IMPORTE4],[PAR_IMPORTE5],[PAR_FECHA1],[PAR_FECHA2],[PAR_FECHA3]'
									set @sQ = @sQ + N'	,[PAR_HORA1],[PAR_HORA2],[PAR_HORA3],[PAR_CVEUSU],[PAR_FECHOPE],[PAR_HORAOPE] '
									set @sQ = @sQ + N'	from ' + @sAuxIPbase + '[' + @sBaseOrigenClonar + '].[dbo].[PNC_PARAMETR] where PAR_IDENPARA = ' +char(39) + @sUSU_BASE + char(39)
									print @sQ
									EXECUTE sp_executesql @sQ
									print 'Se clonaron todos los parametros de :' + @sUSU_BASE +  ' en  PNC_PARAMETR hacia ' + @sUsr3letrasAux


								if (@sBDCentralizada='SI')
									begin
									   --buscamos al usuairo en cat_usuarios...									   
									   -- Tecnico parámetro EM
									   

											if (@sPuesto='APV' or @sPuesto = 'EJECUTIVO DE VENTAS')
											begin
											  select @sOPCION = 'AMBOS';
											  select @sCSVDeptos = char(39) + 'UN' + char(39) + ',' + char(39) + 'OT' + char(39)
											end
											else
											begin
											  select @sOPCION = 'CXP';
											  select @sCSVDeptos = char(39) + 'UN' + char(39) + ',' + char(39) + 'US' + char(39) + ',' + char(39) + 'RE' + char(39) + ',' + char(39) + 'SE' + char(39) + ',' + char(39) + 'OT' + char(39)
											end
									
									   if (@iusu_idusuario=-1)
									   begin
									        print 'No se encontró al asuario en digitalizacion se dará de alta.'
											select @sUsr3letrasALTA =  ltrim(rtrim(convert(char(10),@iIdSucursal) )) + @sUsr3letrasAux;
											Execute Centralizacionv2..spI_INSERTAUSUARIODIGITALIZACION_Correcto @sUsr3letrasALTA,@sNomBase, @sOPCION,@sCSVDeptos, @sPerfilDigitalizacion,@iResultado OUTPUT
											print 'Usuario dado de alta con el id: ' + ltrim(rtrim(Convert(char(5),@iResultado)))
											print '-------------TERMINA REGISTRO DE USUARIO EN DIGITALIZACION--------------'
									   end	--de que no se encontro a un usuario con las 3 letras en digitalizacion
									   else
									   begin									        
										   print 'Se encontró al usuario en DIGITALIZACION ControlAplicaciones..cat_usuarios se agrega o corrige equivalencia:' + ltrim(rtrim(Convert(char(10),@iusu_idusuario)))  + ' ' + ltrim(rtrim(@susu_nombreusu)) + ' base:  ' + ltrim(rtrim(@sNomBase))											   
										   Execute Centralizacionv2..spI_INSERTAUSUARIODIGITALIZACION_Correcto @susu_nombreusu,@sNomBase, @sOPCION,@sCSVDeptos, @sPerfilDigitalizacion,@iResultado OUTPUT
										   print '--------------TERMINA CORRECCIONES DE USUARIO EN DIGITALIZACION ------------'
									   end
									end


							COMMIT TRANSACTION CorrigeUsuarioEnBPro
							print 'Usuario:' + @sUsr3letrasAux +  ' Se corrigió  CORRECTAMENTE en  BPRO'

				 END TRY
				 BEGIN CATCH	
					ROLLBACK TRAN CorrigeUsuarioEnBPro
					PRINT ('Error: ' + ERROR_MESSAGE())	
					 print 'Hubo errores el usuario: '  + @sUsr3letrasAux +  ' NO fue corregido en  BPRO'
				END CATCH
			  end
				   --LIMPIEZA DE VARIABLES
				   Select @sNomBase='', @sUsr3letrasAux='',@sUsr3letras='', @sUSU_APUSUARI = '', @sUSU_AMUSUARI = '',  @sUSU_NOUSUARI = '' , @sUSU_NOUSUARI ='',@sUSU_CVEACCES='',@susu_idusuari='',@sUSU_BASE='',@iID_PERSONA='',@iID_PERSONA=0,@sID_PUESTO='',@iHayParametros=0,@iHayMenu=0,@sPuesto = '',@sAuxIPbase='',@sBaseOrigenClonar='';				
				select @iIndice = @iIndice + 1
        END --del while en cada registro en DIG_USERSPASO
end --de que hay registros en DIG_USERSPASO


set nocount off
end

/*
MODO DE USO:
Poblar la tabla: Centralizacionv2..DIG_USERSPASO con los usuarios a Registrar

select * from Centralizacionv2..DIG_USERSPASO

Execute Centralizacionv2..[spUI_REGISTRAUSUENBPRO]

							-- INICIALES o de ORIGEN
							select * from ControlAplicaciones..cat_usuarios where usu_nombreusu like '%APB%'
							select * from ControlAplicaciones..eqv_organigrama where usu_usuario=2568

							select * from GAAA_Azcapo..pnc_usuarios where usu_idusuari = 'APB'
							select * from GAAA_Azcapo..pnc_opcusuar where opc_idusuari = 'APB'
							select * from GAAA_Azcapo..PNC_PARAMETR where PAR_TIPOPARA = 'EV' and PAR_IDENPARA=111035
							select * from [GAAA_Azcapo].[dbo].PNC_PARAMETR where PAR_TIPOPARA='PO'
							select * from GAAA_Azcapo..PNC_PARAMETR where PAR_TIPOPARA = 'AREAFEUSU' and PAR_IDENPARA='IRF'
							select * from GAAA_Azcapo..PNC_PARAMETR where PAR_IDENPARA = 'APB'
							
							--RESULTADO
							select * from GAZM_Abasto..pnc_usuarios where usu_idusuari = 'APB'
							select * from GAZM_Abasto..pnc_opcusuar where opc_idusuari = 'APB'
							select * from GAZM_Abasto..PNC_PARAMETR where PAR_TIPOPARA = 'EV' and PAR_IDENPARA=111035
							select * from [GAZM_Abasto].[dbo].PNC_PARAMETR where PAR_TIPOPARA='PO'
							select * from GAZM_Abasto..PNC_PARAMETR where PAR_TIPOPARA = 'AREAFEUSU' and PAR_IDENPARA='APB'
							select * from GAZM_Abasto..PNC_PARAMETR where PAR_IDENPARA = 'APB'




*/
go

