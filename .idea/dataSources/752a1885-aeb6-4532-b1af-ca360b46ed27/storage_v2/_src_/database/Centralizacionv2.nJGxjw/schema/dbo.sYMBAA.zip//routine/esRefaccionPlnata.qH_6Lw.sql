
--SELECT [dbo].[esRefaccionPlnata]('AU-AU-CUA-RE-IF-18', 1)
CREATE FUNCTION [dbo].[esRefaccionPlnata] (@folio varchar(100),@planta INT )
RETURNS INT
AS 
BEGIN 
	--DECLARE @planta int=0
	DECLARE @idEstatusPlanta INT
		--EXECUTE [Centralizacionv2].[dbo].[ES_REFACCIONES_PLANTA_SP]  @folio, @planta  OUTPUT
	--IF @planta = 1
	--	BEGIN
			IF @folio like '%RE-PE%' OR  @folio like '%RE-PI%'
				BEGIN
					SET @idEstatusPlanta = 1
					RETURN @idEstatusPlanta
				END
			ELSE
				BEGIN
					SET @idEstatusPlanta = 2
					RETURN @idEstatusPlanta
				END
	--	END
	--ELSE
	--	BEGIN
	--		SET @idEstatusPlanta = 0
	--		RETURN @idEstatusPlanta
	--	END
	RETURN @idEstatusPlanta
END
go

