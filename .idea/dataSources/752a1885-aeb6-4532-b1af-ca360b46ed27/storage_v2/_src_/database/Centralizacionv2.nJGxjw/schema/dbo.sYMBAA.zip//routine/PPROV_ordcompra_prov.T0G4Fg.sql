-- ===================================================================================================
-- Author:	     LQMA 11092017 add parametros filtros	
-- Modified by:  Lourdes Maldonado Sanchez 
-- Modified date: 25/04/2018 Cambio a consulta dinamica
-- Description: Stored que recupera las ordenes de compra de Proveedores   --AU-ZM-NZA-US-PE-106
-- ===================================================================================================
--EXECUTE [dbo].[PPROV_ordcompra_prov]  71,NULL,NULL,'',2,1,2,10,'20180730','20180801'    --71,null,null,'HEHJ520304R36',2
--EXECUTE [dbo].[PPROV_ordcompra_prov]  71,NULL,NULL,'',2,4,6,-1,'20170101','20180530','SARF720811BV0'  --3621 en       8seg     2:58 seg con fechas 2,406
--EXECUTE [dbo].[PPROV_ordcompra_prov]  71,NULL,NULL,'',2,4,0,-1,'20170101','20180530'  --3621 en 5min:15seg     3:36 seg 2,406
CREATE PROCEDURE [dbo].[PPROV_ordcompra_prov]   
		@idProveedor  INT = 0,
		@monto        DECIMAL = NULL,
		@orden        VARCHAR(50) = NULL,
		@user         VARCHAR(15) = '',
		@idUserRol    INT = 0, 
		@idEmpresaP   INT = 0, 
		@idSucursalP  INT = 0,
		@idDeptoP     INT = 0,
		@fechaIniP    VARCHAR(10) = '',
		@fechaFinP    VARCHAR(10) = '',
		@rfcProveedor VARCHAR(20) = ''

AS  

BEGIN
	DECLARE @rfcProv      VARCHAR(15)  = ''
	DECLARE @query        VARCHAR(MAX) = ''
	DECLARE @campos       VARCHAR(MAX) = ''
	DECLARE @from_Rol_1   VARCHAR(MAX) = ''
    DECLARE @from_Rol_2   VARCHAR(MAX) = ''
	DECLARE @where_Rol_1  VARCHAR(MAX) = ''
    DECLARE @where_Rol_2  VARCHAR(MAX) = ''
	DECLARE @cond_emp     VARCHAR(100) = ' '
	DECLARE @cond_suc     VARCHAR(100) = ' '
	DECLARE @cond_dep     VARCHAR(100) = ' '
	DECLARE @cond_rfc     VARCHAR(100) = ' '
	
	--==========================================================================================--
	-- VARIABLE TABLA DE RESULTADO DE BUSQUEDA
	--==========================================================================================--

	DECLARE @TablaResult TABLE ( rowID	           INT
								,oce_folioorden	   VARCHAR(50)
								,dep_nombre	       VARCHAR(30)
								,suc_nombre	       VARCHAR(150)
								,emp_nombre	       VARCHAR(150)
								,oce_importetotal  DECIMAL(18, 7)
								,emp_nombrecto	   VARCHAR(10)
								,oce_fechaorden	   DATE
								,estatus	       VARCHAR(1)
								,per_rfc	       VARCHAR(20)
								,oce_uuid	       VARCHAR(70)
								,oce_imptotalrecibido DECIMAL(18, 7)
								,suc_idsucursal	   INT
								,emp_idempresa	   INT
								,idEstatusPlanta   INT
								,visto	           INT
								,idEstatusOrden	   INT
								,nombreProveedor   VARCHAR(150)
								,Recepcion	       VARCHAR(20)
								,Estado	           VARCHAR(30)
								,NumSerie	       VARCHAR(20)
								,ordenServicio	   VARCHAR(20)
                            )

	--==========================================================================================--
	-- CREO QUERY DINAMICO
	--==========================================================================================--
	
	SELECT  @rfcProv = per_rfc 
	  FROM GA_Corporativa.dbo.PER_PERSONAS 
	 WHERE per_idpersona = @idProveedor

	--SELECT @idEmpresaP,@idSucursalP,@idDeptoP,@fechaIniP,@fechaFinP

	IF (@idEmpresaP <> 0) 
	   SET @cond_emp = ' AND ordComp.oce_idempresa = ' + cast (@idEmpresaP as varchar(4))   
	IF (@idSucursalP <> 0)
	   SET @cond_suc = ' AND ordComp.oce_idsucursal = ' + cast (@idSucursalP as varchar(4))    
	IF (@idDeptoP <> -1)
	   SET @cond_dep = ' AND ordComp.oce_iddepartamento = ' + cast (@idDeptoP as varchar(4))    
	IF (@rfcProveedor <> '') 
	   SET @cond_rfc =  'AND per.per_rfc = '+''''+ @rfcProveedor +''''

	IF @idUserRol = 1 
	BEGIN
	     --PRINT '1)Entro en Rol 1'
	     SET @campos = 'SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID ' +
								',ordComp.oce_folioorden ' +
								',depto.dep_nombre ' +
								',suc.suc_nombre ' +  
								',emp.emp_nombre ' +
								',ordComp.oce_importetotal ' +
								',emp.emp_nombrecto ' +  
								',ordComp.oce_fechaorden ' +
								','+''''+'1'+''''+' AS estatus ' +
								',per.per_rfc ' +
								',ordComp.oce_uuid ' +
								',ordComp.oce_imptotalrecibido ' +
								',suc.suc_idsucursal ' + 
								',emp.emp_idempresa ' + 
								',(SELECT [dbo].[esRefaccionPlnata](ordComp.oce_folioorden,1)) AS idEstatusPlanta ' +
								',CASE WHEN oeVista.[idOrdenEstatusVista] IS NULL ' +  
								'		THEN 1 ' +
								'		ELSE 2 ' +
								'	END visto ' +
								',(SELECT TOP 1 ordComp.sod_idsituacionorden ' + 
								'	FROM cuentasxpagar.dbo.cxp_ordencompra ' +  
								'   ORDER BY ordComp.sod_idsituacionorden desc) as idEstatusOrden ' +
								',LTRIM(RTRIM(replace(replace(per.per_paterno,'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+')  +'+''''+' '+''''+'+ replace(replace(per.per_materno,'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+') +'+''''+' '+''''+'+ per.per_nomrazon)) AS nombreProveedor ' +
								',Recepcion = CASE WHEN (SELECT TOP 1 [sod_idsituacionorden] ' + 
								'						  FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] ' + 
								'						 WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6 ' +
								'					THEN '+''''+'Recepción Completa'+'''' + 
								'				  WHEN (SELECT TOP 1 [sod_idsituacionorden] ' + 
								'						  FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] ' + 
								'						 WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7 ' +
								'					THEN '+''''+'Recepción Incompleta'+'''' +
								'					ELSE '+''''+'Pendiente'+'''' +
								'				END ' +
								',Estado = CASE ordComp.sod_idsituacionorden ' +
								'			WHEN 12 THEN '+''''+'Pagada'+'''' +
								'			WHEN 13 THEN '+''''+'Pagada'+'''' +
								'			WHEN 16 THEN '+''''+'Pagada'+'''' +
								'			WHEN 18 THEN '+''''+'Pagada'+'''' +
								'			ELSE  '+''''+'Por Pagar'+'''' +
								'		END ' +
								',CASE  WHEN oce_iddepartamento  in (SELECT dep_iddepartamento ' + 
								'									  FROM ControlAplicaciones.dbo.cat_departamentos ' + 
								'									 WHERE dep_nombrecto ='+''''+'UN'+''''+') ' + 
								'		THEN  (SELECT anu_numeroserie ' + 
								'				 FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] ' + 
								'				WHERE oce_folioorden = ordComp.oce_folioorden) ' +
								'	   WHEN oce_iddepartamento  in (SELECT dep_iddepartamento ' + 
								'									  FROM ControlAplicaciones.dbo.cat_departamentos ' + 
								'									 WHERE dep_nombrecto ='+''''+'US'+''''+') ' + 
								'		THEN  (SELECT asn_numeroserie ' + 
								'				 FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] ' + 
								'				WHERE oce_folioorden = ordComp.oce_folioorden  ) ' +
								'	   ELSE '+''''+''+'''' +
								'END AS NumSerie ' +
								',OC.ser_ordenservicio AS ordenServicio ' 
		 SET @from_Rol_1 = ' FROM	cuentasxpagar.dbo.cxp_ordencompra ordComp ' +  
									'LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden ' +  
									'LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa ' +  
									'LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal ' +  
									'LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento ' +  
									'LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor ' +
									'LEFT JOIN proveedores.dbo.OrdenEstatusVista oeVista ON ordComp.oce_folioorden = oeVista.Folio_Operacion ' +
									'LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL ' 

	     SET @where_Rol_1 = ' WHERE	ordComp.oce_folioorden NOT IN (SELECT folioorden FROM PPRO_DATOSFACTURAS) ' +				  
							    'AND (ordComp.oce_uuid = '+''''+''+''''+' or ordComp.oce_uuid IS NULL) ' +
								'AND ordComp.sod_idsituacionorden IN (2,5,6,7,8,15,17,23) ' +
								'AND ordComp.oce_folioorden IN (SELECT oce_folioorden ' + 
								'								  FROM cuentasxpagar.dbo.cxp_ordencompra ' + 
								'								 WHERE oce_idproveedor IN (SELECT per_idpersona ' + 
								'															 FROM GA_Corporativa.dbo.PER_PERSONAS ' + 
								'														    WHERE per_rfc = '+''''+ @user +''''+')) ' 
								 

		 SET @query = @campos + ' ' + @from_Rol_1 + ' ' + @where_Rol_1

         -------------------------------------------------
		 --       ARMO EL QUERY 1 CON LAS CONDICIONES   --
		 -------------------------------------------------
		 SET @query = @query + ' ' + @cond_emp + ' ' + @cond_suc + ' ' + @cond_dep + ' ' + @cond_rfc  
		 --SELECT @query
		 INSERT INTO @TablaResult
				EXECUTE (@query) 
         
		 IF (@fechaIniP <> '' OR @fechaFinP <> '')
			 BEGIN
			     --PRINT '2)Entro en valida fechas'
				 SELECT  rowID	           
						,oce_folioorden	   
						,dep_nombre	       
						,suc_nombre	       
						,emp_nombre	       
						,oce_importetotal  
						,emp_nombrecto	   
						,oce_fechaorden	   
						,estatus	       
						,per_rfc	       
						,oce_uuid	       
						,oce_imptotalrecibido 
						,suc_idsucursal	   
						,emp_idempresa	   
						,idEstatusPlanta   
						,visto	           
						,idEstatusOrden	   
						,nombreProveedor   
						,Recepcion	       
						,Estado	           
						,NumSerie	       
						,ordenServicio	   
				  FROM @TablaResult AS T 
				  WHERE CONVERT(DATE,REPLACE(T.oce_fechaorden,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
	              ORDER BY T.oce_fechaorden ASC
			 END
		 ELSE
			 BEGIN
			     --PRINT '3)Entro en consulta normal'
			     SELECT  rowID	           
						,oce_folioorden	   
						,dep_nombre	       
						,suc_nombre	       
						,emp_nombre	       
						,oce_importetotal  
						,emp_nombrecto	   
						,oce_fechaorden	   
						,estatus	       
						,per_rfc	       
						,oce_uuid	       
						,oce_imptotalrecibido 
						,suc_idsucursal	   
						,emp_idempresa	   
						,idEstatusPlanta   
						,visto	           
						,idEstatusOrden	   
						,nombreProveedor   
						,Recepcion	       
						,Estado	           
						,NumSerie	       
						,ordenServicio	   
				   FROM @TablaResult AS T 
                  ORDER BY T.oce_fechaorden ASC
			 END 
	END
	ELSE
	BEGIN
	       PRINT '1)Entro en Rol 2'
	       IF @idProveedor = 67
				BEGIN
					SET @idProveedor = 15
				END
			--Creamos tabla para guardar empresas y sucursales por usuario	
			DECLARE @EmpresaSucursal TABLE
			(	
				idEmpSuc INT NOT NULL IDENTITY(1,1),
				empresa INT,
				sucursal INT
			)
			
			--Insertamos empresas y sucursales por usuario
			INSERT INTO @EmpresaSucursal
			SELECT DISTINCT emp_idempresa,suc_idsucursal FROM [ControlAplicaciones].[dbo].[ope_organigrama]
			WHERE [usu_idusuario] = @idProveedor
			--WHERE [usu_idusuario] = (SELECT usu_idusuario FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombreusu = @user)

			--SELECT * FROM @EmpresaSucursal

			 SET @campos = 'SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID ' +
									',ordComp.oce_folioorden ' +
									',depto.dep_nombre ' +
									',suc.suc_nombre ' +  
									',emp.emp_nombre ' +
									',ordComp.oce_importetotal ' +
									',emp.emp_nombrecto ' +  
									',ordComp.oce_fechaorden ' +
									','+''''+'1'+''''+' AS estatus ' +
									',per.per_rfc ' +
									',ordComp.oce_uuid ' +
									',ordComp.oce_imptotalrecibido ' +
									',suc.suc_idsucursal ' + 
									',emp.emp_idempresa ' + 
									',(SELECT [dbo].[esRefaccionPlnata](ordComp.oce_folioorden,1)) AS idEstatusPlanta ' +
									',CASE WHEN oeVista.[idOrdenEstatusVista] IS NULL ' +  
									'		THEN 1 ' +
									'		ELSE 2 ' +
									'	END visto ' +
									',(SELECT TOP 1 ordComp.sod_idsituacionorden ' + 
									'	FROM cuentasxpagar.dbo.cxp_ordencompra ' +  
									'   ORDER BY ordComp.sod_idsituacionorden desc) as idEstatusOrden ' +
									',LTRIM(RTRIM(replace(replace(per.per_paterno,'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+')  +'+''''+' '+''''+'+ replace(replace(per.per_materno,'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+') +'+''''+' '+''''+'+ per.per_nomrazon)) AS nombreProveedor ' +
									',Recepcion = CASE WHEN (SELECT TOP 1 [sod_idsituacionorden] ' + 
									'						  FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] ' + 
									'						 WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6 ' +
									'					THEN '+''''+'Recepción Completa'+'''' + 
									'				  WHEN (SELECT TOP 1 [sod_idsituacionorden] ' + 
									'						  FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] ' + 
									'						 WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7 ' +
									'					THEN '+''''+'Recepción Incompleta'+'''' +
									'					ELSE '+''''+'Pendiente'+'''' +
									'				END ' +
									',Estado = CASE ordComp.sod_idsituacionorden ' +
									'			WHEN 12 THEN '+''''+'Pagada'+'''' +
									'			WHEN 13 THEN '+''''+'Pagada'+'''' +
									'			WHEN 16 THEN '+''''+'Pagada'+'''' +
									'			WHEN 18 THEN '+''''+'Pagada'+'''' +
									'			ELSE  '+''''+'Por Pagar'+'''' +
									'		END ' +
									',CASE  WHEN oce_iddepartamento  in (SELECT dep_iddepartamento ' + 
									'									  FROM ControlAplicaciones.dbo.cat_departamentos ' + 
									'									 WHERE dep_nombrecto ='+''''+'UN'+''''+') ' + 
									'		THEN  (SELECT anu_numeroserie ' + 
									'				 FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] ' + 
									'				WHERE oce_folioorden = ordComp.oce_folioorden) ' +
									'	   WHEN oce_iddepartamento  in (SELECT dep_iddepartamento ' + 
									'									  FROM ControlAplicaciones.dbo.cat_departamentos ' + 
									'									 WHERE dep_nombrecto ='+''''+'US'+''''+') ' + 
									'		THEN  (SELECT asn_numeroserie ' + 
									'				 FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] ' + 
									'				WHERE oce_folioorden = ordComp.oce_folioorden  ) ' +
									'	   ELSE '+''''+''+'''' +
									'END AS NumSerie ' +
									',OC.ser_ordenservicio AS ordenServicio ' 
			 SET @from_Rol_2 = ' FROM cuentasxpagar.dbo.cxp_ordencompra ordComp ' +  
					  				'LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden ' +  
									'LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa ' +  
									'LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal ' +  
									'LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento ' +  
									'LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor ' +
									'LEFT JOIN proveedores.dbo.OrdenEstatusVista oeVista ON ordComp.oce_folioorden = oeVista.Folio_Operacion ' +
									'LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL '  

			 SET @where_Rol_2 = ' WHERE	ordComp.oce_folioorden NOT IN (SELECT folioorden FROM PPRO_DATOSFACTURAS) ' +				  
									'AND (ordComp.oce_uuid = '+''''+''+''''+' or ordComp.oce_uuid IS NULL) ' +
									'AND ordComp.sod_idsituacionorden IN (2,5,6,7,8,15,17,23) ' 
								
			 SET @query = @campos + ' ' + @from_Rol_2 + ' ' + @where_Rol_2

			 -------------------------------------------------
			 --       ARMO EL QUERY 2 CON LAS CONDICIONES   --
			 -------------------------------------------------
			 SET @query = @query + ' ' + @cond_emp + ' ' + @cond_suc + ' ' + @cond_dep + ' ' + @cond_rfc 
			 --SELECT @query
			 INSERT INTO @TablaResult
			 		EXECUTE (@query) 
             
			 IF (@fechaIniP <> '' OR @fechaFinP <> '')
			 BEGIN
			     PRINT '2)Entro en validacion fechas'
				 SELECT rowID	          
						,oce_folioorden
						,dep_nombre	    
						,suc_nombre	      
						,emp_nombre	    
						,oce_importetotal  
						,emp_nombrecto	  
						,CONVERT(varchar(30), oce_fechaorden, 103) as oce_fechaorden
						,estatus	       
						,per_rfc	      
						,oce_uuid	       
						,oce_imptotalrecibido 
						,suc_idsucursal	 
						,emp_idempresa	   
						,idEstatusPlanta   
						,visto	          
						,idEstatusOrden	  
						,nombreProveedor   
						,Recepcion	       
						,Estado	          
						,NumSerie	       
						,ordenServicio	 
				   FROM @TablaResult AS T
				  WHERE T.suc_idsucursal IN (SELECT sucursal FROM @EmpresaSucursal) 
				    AND CONVERT(DATE,REPLACE(T.oce_fechaorden,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
	              ORDER BY T.oce_fechaorden ASC  
			 END
			 ELSE
			 BEGIN
			     PRINT '3)Entro en consulta sencilla'
				 SELECT rowID	          
						,oce_folioorden
						,dep_nombre	    
						,suc_nombre	      
						,emp_nombre	    
						,oce_importetotal  
						,emp_nombrecto	  
						,CONVERT(varchar(30), oce_fechaorden, 103) as oce_fechaorden
						,estatus	       
						,per_rfc	      
						,oce_uuid	       
						,oce_imptotalrecibido 
						,suc_idsucursal	 
						,emp_idempresa	   
						,idEstatusPlanta   
						,visto	          
						,idEstatusOrden	  
						,nombreProveedor   
						,Recepcion	       
						,Estado	          
						,NumSerie	       
						,ordenServicio	 
				   FROM @TablaResult AS T
				  WHERE T.suc_idsucursal IN (SELECT sucursal FROM @EmpresaSucursal) 
			      ORDER BY T.oce_fechaorden ASC
			 END
	END


END
go

