

/*
Por cada departamento  en ControlAplicaciones..cat_departamentos perteneciente a la empresa que se pasa como parametro @iId_empresa
upserta un registro en DIG_ESCALAMIENTO con los usuarios pasados como parámetro.
*/

CREATE PROCEDURE [dbo].[sp_UpsertDIG_ESCALAMIENTO] (@iId_empresa int, @isuc_idsucursal int, @iUsuario_Autoriza1 int, @iUsuario_Autoriza2 int, @iUsuario_Autoriza3 int) --with recompile
 AS

Declare @idep_iddepartaamento int;
Declare @iIndice int;
Declare @iTope int;

begin 

set nocount on


CREATE TABLE #Deptos
	(
     POSICION [smallint] IDENTITY (1, 1),
	 dep_iddepartaamento int,
	 emp_idempresa int,
	 suc_idsucursal int,
	 dep_nombre varchar(400)
	)

if (@isuc_idsucursal=0 )  --0 significa todas las sucursales de la empresa
	    begin
		insert into #Deptos(dep_iddepartaamento,emp_idempresa,suc_idsucursal,dep_nombre )
		select dep_iddepartamento, emp_idempresa,suc_idsucursal,dep_nombre From ControlAplicaciones..cat_departamentos where emp_idempresa = @iId_empresa
		order by suc_idsucursal,dep_iddepartamento  
	    end
	else
	    begin
		-- especificamente la sucursal que se pasa por parámetro
		insert into #Deptos(dep_iddepartaamento,emp_idempresa,suc_idsucursal,dep_nombre )
		select dep_iddepartamento, emp_idempresa,suc_idsucursal,dep_nombre From ControlAplicaciones..cat_departamentos where emp_idempresa = @iId_empresa
		and    suc_idsucursal = @isuc_idsucursal
		order by suc_idsucursal,dep_iddepartamento  
	    end


	select @iIndice = 1;
	select @iTope = Max(POSICION) from #Deptos

	while (@iIndice <= @iTope)
	BEGIN
		SET ROWCOUNT 1 
		   Select @idep_iddepartaamento = dep_iddepartaamento, @isuc_idsucursal=suc_idsucursal  FROM #Deptos where POSICION = @iIndice
	    SET ROWCOUNT 0  

		if Exists(Select 1 from Centralizacionv2..DIG_ESCALAMIENTO where suc_idsucursal=@isuc_idsucursal and dep_iddepartaamento = @idep_iddepartaamento)
			begin
			    update Centralizacionv2..DIG_ESCALAMIENTO set Usuario_Autoriza1 = @iUsuario_Autoriza1, Usuario_Autoriza2 = @iUsuario_Autoriza2, Usuario_Autoriza3 = @iUsuario_Autoriza3 
				where dep_iddepartaamento = @idep_iddepartaamento and suc_idsucursal = @isuc_idsucursal
			end
        else
		   begin
		      insert into Centralizacionv2..DIG_ESCALAMIENTO(Proc_Id,Nodo_Id,emp_idempresa,suc_idsucursal,dep_iddepartaamento,tipo_idtipoorden,Nivel_Escalamiento,Usuario_Autoriza2,Usuario_Autoriza1,Usuario_Autoriza3,Minutos_Escalar)
			  values (1,1,@iId_empresa,@isuc_idsucursal,@idep_iddepartaamento,0,0,@iUsuario_Autoriza2,@iUsuario_Autoriza1,@iUsuario_Autoriza3,200)
		   end

	     select @iIndice = @iIndice + 1
	END

	set nocount off
end

/*

declare
@iId_empresa int,
@iSuc_idsucursal int,
@iUsuario_Autoriza1 int,
@iUsuario_Autoriza2 int,
@iUsuario_Autoriza3 int

select @iId_empresa=9
select @iSuc_idsucursal =24 --0 significa todas las sucursales de la empresa
select @iUsuario_Autoriza1 = 71
select @iUsuario_Autoriza2 = 87
select @iUsuario_Autoriza3 = 82


execute sp_UpsertDIG_ESCALAMIENTO @iId_empresa,@iSuc_idsucursal, @iUsuario_Autoriza1, @iUsuario_Autoriza2, @iUsuario_Autoriza3 

select * from Centralizacionv2..DIG_ESCALAMIENTO where emp_idempresa=9

select top 10 * from ControlAplicaciones..cat_usuarios where usu_nombreusu like '%GMI%'
--87
select top 10 * from ControlAplicaciones..cat_usuarios where usu_idusuario = '72' 

*/
go

