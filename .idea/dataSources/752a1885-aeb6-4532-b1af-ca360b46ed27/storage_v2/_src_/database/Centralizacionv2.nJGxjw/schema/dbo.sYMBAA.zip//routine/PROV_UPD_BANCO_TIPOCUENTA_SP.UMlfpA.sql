CREATE PROCEDURE [dbo].[PROV_UPD_BANCO_TIPOCUENTA_SP]
@tipoCta		VARCHAR(10)
,@idCuentaBancaria	INT
,@nombreTipoCta		VARCHAR(50)
,@idPerTra			INT
AS
BEGIN
BEGIN TRY
	UPDATE PROV_CUENTA_BANCARIA
	SET  tipoCtaBancaria = @tipoCta
		,nombreTipoCtaBancaria = @nombreTipoCta
		,idPerTra = @idPerTra
	WHERE idCuentaBancaria = @idCuentaBancaria

	SELECT 1 result

END TRY
BEGIN CATCH
	SELECT 0 result
END CATCH	

END
go

