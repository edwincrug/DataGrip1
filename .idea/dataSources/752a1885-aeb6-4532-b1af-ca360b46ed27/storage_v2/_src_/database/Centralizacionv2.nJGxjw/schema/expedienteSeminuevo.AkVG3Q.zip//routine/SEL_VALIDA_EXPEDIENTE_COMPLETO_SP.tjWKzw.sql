-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST [expedienteSeminuevo].[SEL_VALIDA_EXPEDIENTE_COMPLETO_SP] 185
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_VALIDA_EXPEDIENTE_COMPLETO_SP]
	@idExpediente INT
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @vin VARCHAR(100), @idEmpresa INT, @idSucursal INT;
	DECLARE @base VARCHAR(50), @query NVARCHAR(MAX), @idCliente INT, @fisMor VARCHAR(10);
	DECLARE @tableAllDocumentos TABLE (id INT IDENTITY, idDocumento INT, nombreDocumento VARCHAR(500));
	DECLARE @count INT;

	SELECT 
		@vin = exp_vin,
		@idEmpresa = exp_empresa,
		@idSUcursal = exp_sucursal
	FROM [expedienteSeminuevo].[expedientes] WHERE id_expediente = @idExpediente

	SELECT @base = nombre_base FROM [DBO].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND suc_idSucursal = @idSucursal

	SET @query = 'SELECT 
						@clienteId = OC.oce_idproveedor 
					FROM ' + @base + '.DBO.SER_VEHICULO SV
					INNER JOIN cuentasxpagar.[dbo].[cxp_detalleseminuevos] DS ON DS.asn_numeroserie =  SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
					INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] OC ON OC.oce_folioOrden = DS.oce_folioorden
					WHERE OC.sod_idsituacionorden <> 4 AND VEH_NUMSERIE = ''' + @vin + ''''
	PRINT @query
	EXEC sp_executesql @query, N'@clienteId INT OUTPUT', @clienteId = @idCliente OUTPUT
	
	SELECT @fisMor = PER_TIPO FROM [GA_Corporativa].[DBO].[PER_PERSONAS] WHERE PER_IDPERSONA = @idCliente
	PRINT @fisMor
	IF(@fisMor = 'MOR')
		BEGIN
			INSERT INTO @tableAllDocumentos
			SELECT 
				id_documento,
				doc_nombre 
			FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_moral = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
		END
	ELSE IF(@fisMor = 'FIS')
		BEGIN
			INSERT INTO @tableAllDocumentos
			SELECT 
				id_documento,
				doc_nombre  
			FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisica = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
		END
	ELSE IF(@fisMor = 'FIE')
		BEGIN
			INSERT INTO @tableAllDocumentos
			SELECT 
				id_documento,
				doc_nombre  
			FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisicaAE = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
		END
	ELSE
		BEGIN
			SELECT totalImagenes = 99999;
			RETURN
		END

		-- TEST [expedienteSeminuevo].[SEL_VALIDA_EXPEDIENTE_COMPLETO_SP] 'JM1BM1K31F1244253'
		SELECT @count = COUNT(A.idDocumento) FROM (
					SELECT 
						* 
					FROM @tableAllDocumentos) AS A
		LEFT JOIN ( SELECT 
						DISTINCT id_documento 
					FROM [expedienteSeminuevo].[documentosExpediente] 
					WHERE id_expediente = @idExpediente) AS B ON A.idDocumento = B.id_documento
		WHERE B.id_documento IS NULL

		SELECT totalImagenes = @count
END
go

