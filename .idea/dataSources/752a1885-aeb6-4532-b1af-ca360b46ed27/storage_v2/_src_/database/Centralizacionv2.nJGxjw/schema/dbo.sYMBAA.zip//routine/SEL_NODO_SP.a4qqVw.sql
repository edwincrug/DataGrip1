-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 04/11/2015
-- Description:	Procediminto que recupera los documentos de un nodo de un folio de ordenes de compra
-- =============================================
CREATE PROCEDURE [dbo].[SEL_NODO_SP]
	@folio      nvarchar(50)
	,@idnodo	int
	,@idperfil	int
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
    SELECT    EN.Proc_Id
			, EN.Nodo_Id
			, EN.Folio_Operacion
			, EN.Nodo_Estatus_Id
			, CD.Doc_Nombre
			, CD.Doc_Descripcion
			, CD.Doc_Origen
			, ND.Es_Mandatorio
			, PD.Consultar
			, PD.Imprimir
			, PD.Enviar_Email
			, PD.Descargar
			, PD.Cargar
			, PD.Perfil_Id
			, ED.Fecha_Creacion
			, ED.Usuario_BPRO
			, 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/OtrosDoc/' + LTRIM(RTRIM(EN.Folio_Operacion)) as Ruta
	FROM    dbo.DIG_EXP_NODO EN INNER JOIN
            dbo.DIG_NODO_DOC ND ON EN.Nodo_Id = ND.Nodo_Id INNER JOIN
            dbo.DIG_CATDOCUMENTO CD ON ND.Doc_Id = CD.Doc_Id INNER JOIN
            dbo.DIG_PERFIL_DOCUMENTO PD ON CD.Doc_Id = PD.Doc_Id LEFT OUTER JOIN
            dbo.DIG_EXPNODO_DOC ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND 
            EN.Nodo_Id = ED.Nodo_Id AND ND.Proc_Id = ED.Proc_Id AND 
            ND.Nodo_Id = ED.Nodo_Id AND ND.Doc_Id = ED.Doc_Id
	WHERE	EN.Folio_Operacion = @folio
			AND EN.Nodo_Id = @idnodo
			AND PD.Perfil_Id = @idperfil
			END TRY
			BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_NODO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

