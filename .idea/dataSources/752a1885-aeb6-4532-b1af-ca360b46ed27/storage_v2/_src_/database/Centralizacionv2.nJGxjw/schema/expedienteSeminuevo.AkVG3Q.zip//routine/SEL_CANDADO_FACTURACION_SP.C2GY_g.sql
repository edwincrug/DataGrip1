-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST [expedienteSeminuevo].[SEL_CANDADO_FACTURACION_SP] 'MMBMG46H4FD051272', 4, 6
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_CANDADO_FACTURACION_SP]
	@vin VARCHAR(100),
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN

	SET NOCOUNT ON;

    DECLARE @base VARCHAR(200);
	DECLARE @query NVARCHAR(MAX), @idCliente INT, @fisMorFie VARCHAR(20);
	DECLARE @tableAllDocumentos TABLE (id INT IDENTITY, idDocumento INT, nombreDocumento VARCHAR(500));
	DECLARE @countCXP INT, @idExpediente INT;

	SELECT @idExpediente = id_expediente FROM [expedienteSeminuevo].[expedientes] WHERE exp_vin = @vin AND exp_empresa = @idEmpresa AND exp_sucursal = @idSucursal
	
	SELECT @base = nombre_base FROM [DBO].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND suc_idSucursal = @idSucursal

	SET @query = 'SELECT 
					@clienteId = OC.oce_idproveedor 
				FROM ' + @base + '.DBO.SER_VEHICULO SV
				INNER JOIN cuentasxpagar.[dbo].[cxp_detalleseminuevos] DS ON DS.asn_numeroserie =  SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
				INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] OC ON OC.oce_folioOrden = DS.oce_folioorden
				WHERE VEH_NUMSERIE = ''' + @vin + ''' AND OC.sod_idsituacionorden <> 4'
	EXEC sp_executesql @query, N'@clienteId INT OUTPUT', @clienteId = @idCliente OUTPUT
	PRINT @idCliente
	SELECT @fisMorFie = PER_TIPO FROM [GA_Corporativa].[DBO].[PER_PERSONAS] WHERE PER_IDPERSONA = @idCliente
	
	IF(@fisMorFie = 'MOR')
		BEGIN
			INSERT INTO @tableAllDocumentos
			SELECT 
				id_documento,
				doc_nombre 
			FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_moral = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
		END
	ELSE IF(@fisMorFie = 'FIS')
		BEGIN
			INSERT INTO @tableAllDocumentos
			SELECT 
				id_documento,
				doc_nombre  
			FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisica = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
		END
	ELSE IF(@fisMorFie = 'FIE')
		BEGIN
			INSERT INTO @tableAllDocumentos
			SELECT 
				id_documento,
				doc_nombre  
			FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisicaAE = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
		END
	ELSE
		BEGIN
			INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
			VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de facturacion', 0, 'No se encontro Idcliente', GETDATE());

			SELECT success = 0, msg = 'No se encontro Idcliente';
			RETURN
		END

	-- TEST [expedienteSeminuevo].[SEL_CANDADO_FACTURACION_SP] 'JM1BM1K31F1244253', 4, 6
	SELECT @countCXP = COUNT(A.idDocumento) FROM (
			SELECT 
				* 
			FROM @tableAllDocumentos) AS A
			LEFT JOIN ( SELECT 
							DISTINCT id_documento 
						FROM [expedienteSeminuevo].[documentosExpediente] 
						WHERE id_expediente = @idExpediente AND id_proceso = 1) AS B ON A.idDocumento = B.id_documento
			WHERE B.id_documento IS NULL

	IF(@countCXP = 0)
		BEGIN
			INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
			VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de facturacion', 1, 'Unidad con expediente de compra completo.', GETDATE());
			SELECT success = 1, msg = 'Unidad con expediente de compra completo.'
		END
	ELSE
		BEGIN
			INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
			VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de facturacion', 0, 'Unidad con expediente de compra incompleto.', GETDATE());
			SELECT success = 0, msg = 'Unidad con expediente de compra incompleto.'
		END
END
go

