
-- =============================================
-- Author:		Alejandro Lopez
-- Create date: 09/04/2016
-- Description:	recibe una cadena con diferentes caracteres de separacion (AV-AVA-VIG-RE), el caracter separador (-), regresa todos los 
--		caracteres despues del ultimo separador
-- =============================================
CREATE FUNCTION [dbo].[splitCadena_fn]
(
	@cadena VARCHAR(100),
	@separador VARCHAR(5),
	@posicion INT = 0,
	@opcion  INT = 0
)
RETURNS VARCHAR(100)
AS
BEGIN
	
	DECLARE @aux INT = 0
	DECLARE @cadenaAux VARCHAR(50) = ''	

	IF @opcion = 0 -- regresa fragmentos de la cadena en base a la posicion
		BEGIN
				WHILE(@aux < @posicion)
				BEGIN	
						IF @cadenaAux = ''
								SELECT @cadenaAux = SUBSTRING(@cadena,1,CHARINDEX(@separador,@cadena))		
						ELSE		
								SELECT @cadenaAux = @cadenaAux + SUBSTRING(SUBSTRING(@cadena,LEN(@cadenaAux) + 1,100), 1,CHARINDEX(@separador,SUBSTRING(@cadena,LEN(@cadenaAux)+1,100)))
				
						SET @aux = @aux + 1
				END	
		END

	IF @opcion = 1 -- regresa los caracteres despues del ultimo separador
		BEGIN			  
			  WHILE(@aux = 0)
				   BEGIN
						   IF (SELECT CHARINDEX('-',@cadena)) > 0
								SET @cadena = SUBSTRING(@cadena, CHARINDEX('-',@cadena) + 1,50)
							ELSE 
								SET @aux = 1
				   END
				
			 SELECT @cadenaAux = @cadena
		END	

RETURN @cadenaAux

END
go

