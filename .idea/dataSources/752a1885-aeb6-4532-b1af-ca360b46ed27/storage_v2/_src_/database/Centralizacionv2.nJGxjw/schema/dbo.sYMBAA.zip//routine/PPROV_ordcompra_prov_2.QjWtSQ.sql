-- ===================================================================================================
-- Author:	     LQMA 11092017 add parametros filtros	
-- Modified by:  Lourdes Maldonado Sanchez
-- Modified date: 25/04/2018  
-- Description: Stored que recupera las ordenes de compra de Proveedores   --AU-ZM-NZA-US-PE-106
-- ===================================================================================================
--EXECUTE [dbo].[PPROV_ordcompra_prov_2]  71,NULL,NULL,'SARF720811BV0',1,4,7,null,null,null,'SARF720811BV0'    --71,null,null,'HEHJ520304R36',2
--EXECUTE [dbo].[PPROV_ordcompra_prov_2]  71,NULL,NULL,'',2,4,6,26 
/*
  [dbo].[PPROV_ordcompra_prov_2]
		@idProveedor  = 157,
		@monto  = NULL,
		@orden  = NULL,
		@user   = 'SARF720811BV0',
		@idUserRol   = 1, 
		@idEmpresaP  = 4, 
		@idSucursalP  = 7,
		@idDeptoP    = 0,
		--@fechaIniP   = '',
		--@fechaFinP    = '',
		--@rfcProveedor  = ''
*/
CREATE PROCEDURE [dbo].[PPROV_ordcompra_prov_2]   
		@idProveedor  INT = 0,
		@monto        DECIMAL = NULL,
		@orden        VARCHAR(50) = NULL,
		@user         VARCHAR(15) = '',
		@idUserRol    INT = 0, 
		@idEmpresaP   INT = 0, 
		@idSucursalP  INT = 0,
		@idDeptoP     INT = 0,
		@fechaIniP    VARCHAR(10) = '',
		@fechaFinP    VARCHAR(10) = '',
		@rfcProveedor VARCHAR(20) = ''

AS  

DECLARE @rfcProv VARCHAR(15) = ''

/*--LQMA add 13092017
	IF(@fechaIniP = '')
	   SET @fechaIniP = '20000101'
	IF(@fechaFinP = '') 
	   SET @fechaFinP = CONVERT(VARCHAR(8),GETDATE(),112)
*/
--SELECT @idProveedor = 4, @user = 'HEHJ520304R36', @idUserRol = 0 


SELECT @rfcProv = per_rfc FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_idpersona = @idProveedor
--EL RFC ES CON EL QUE SE FIRMA EL PROV
/*SELECT * FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = 'HEHJ520304R36'

SELECT * FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_idproveedor IN(
SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = 'HEHJ520304R36')*/

IF(@idUserRol = 1)
	BEGIN
		PRINT '1)Entro en Rol 1'
		---------------
		PRINT '2)Edito Fechas'
		--LQMA add 13092017
		IF(@fechaIniP = '')
		   SET @fechaIniP = '20000101'
		IF(@fechaFinP = '') 
		   SET @fechaFinP = CONVERT(VARCHAR(8),GETDATE(),112)
		---------------
					SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID
							,ordComp.oce_folioorden,depto.dep_nombre, suc.suc_nombre  
							,emp.emp_nombre
							,ordComp.oce_importetotal
							,emp.emp_nombrecto  
							,ordComp.oce_fechaorden,'1' estatus
							,per.per_rfc
							,ordComp.oce_uuid
							,ordComp.oce_imptotalrecibido
							,suc.suc_idsucursal 
							,emp.emp_idempresa 
							,(SELECT [dbo].[esRefaccionPlnata](ordComp.oce_folioorden,1)) as idEstatusPlanta
							,CASE WHEN oeVista.[idOrdenEstatusVista] IS NULL  --ADD LQMA 09052016
									THEN 1
									ELSE 2
								END visto
							,(select top 1 ordComp.sod_idsituacionorden from cuentasxpagar.dbo.cxp_ordencompra  order by ordComp.sod_idsituacionorden desc) as idEstatusOrden
							,LTRIM(RTRIM(replace(replace(per.per_paterno,'Ñ',''),'.','')  +' '+ replace(replace(per.per_materno,'Ñ',''),'.','') +' '+ per.per_nomrazon)) nombreProveedor
							,Recepcion = case when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6
										      then 'Recepción Completa'
										      when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7
										      THEN 'Recepción Incompleta'
										      else 'Pendiente'
										 end
							,Estado = CASE ordComp.sod_idsituacionorden
										WHEN 12 THEN 'Pagada'
										WHEN 13 THEN 'Pagada'
										WHEN 16 THEN 'Pagada'
										WHEN 18 THEN 'Pagada'
										ELSE  'Por Pagar'
									END
							,CASE  
								 WHEN oce_iddepartamento  in (select dep_iddepartamento 
																from ControlAplicaciones.dbo.cat_departamentos 
																where dep_nombrecto ='UN') 
								 THEN  (SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
								 WHEN oce_iddepartamento  in (select dep_iddepartamento 
																from ControlAplicaciones.dbo.cat_departamentos 
																where dep_nombrecto ='US') 
								 THEN  (SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
								 ELSE ''
								 END AS NumSerie
							,OC.ser_ordenservicio ordenServicio
					   FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
							LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
							LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
							LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
							LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
							LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
							LEFT JOIN proveedores.dbo.OrdenEstatusVista oeVista ON ordComp.oce_folioorden = oeVista.Folio_Operacion
							LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL
					  WHERE --ordComp.oce_idproveedor IN (SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = 'HEHJ520304R36') --@idProveedor AND -- oce_idproveedor este en los IDS de la tabla cat_personas que coincida con el RFC de proveedor logueado
							(@monto IS NULL OR ordComp.oce_importetotal = @monto)
							AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
							--AND ordComp.oce_folioorden NOT IN (SELECT oce_folioorden FROM dbo.PPRO_ORDENARCHIVOXML) --ORIGINAL --comentado LQMA 28042016
							AND ordComp.oce_folioorden NOT IN (SELECT folioorden FROM PPRO_DATOSFACTURAS)				  
							AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
							AND ordComp.sod_idsituacionorden IN (2,5,6,7,8,15,17)
							AND ordComp.oce_folioorden IN (SELECT oce_folioorden 
															FROM cuentasxpagar.dbo.cxp_ordencompra 
															WHERE oce_idproveedor IN(SELECT per_idpersona 
																					   FROM GA_Corporativa.dbo.PER_PERSONAS 
																					WHERE per_rfc = @user))
							AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
							AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
							AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
							AND CONVERT(DATE,REPLACE(ordComp.oce_fechaorden,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)											
							AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))
							order by ordComp.oce_fechaorden ASC
	END
ELSE
	BEGIN
	if @idProveedor = 67
	begin
		set @idProveedor = 15
	end
			--Creamos tabla para guardar empresas y sucursales por usuario	
			DECLARE @EmpresaSucursal TABLE
			(	
				idEmpSuc INT NOT NULL IDENTITY(1,1),
				empresa INT,
				sucursal INT
			)
			
			PRINT 'variable tabla'

			--Insertamos empresas y sucursales por usuario
			INSERT INTO @EmpresaSucursal
			SELECT DISTINCT emp_idempresa,suc_idsucursal FROM [ControlAplicaciones].[dbo].[ope_organigrama]
			WHERE [usu_idusuario] = @idProveedor
			--WHERE [usu_idusuario] = (SELECT usu_idusuario FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombreusu = @user)

			IF (@fechaIniP = '') and (@fechaIniP='')
				BEGIN
				PRINT 'SIN FECHAS'
			         SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
								ordComp.oce_folioorden,depto.dep_nombre, suc.suc_nombre,  
								emp.emp_nombre,ordComp.oce_importetotal, emp.emp_nombrecto,  
								ordComp.oce_fechaorden,'1' estatus,per.per_rfc
								,ordComp.oce_uuid
								,ordComp.oce_imptotalrecibido 
								,suc.suc_idsucursal 
								,emp.emp_idempresa 
								,(SELECT [dbo].[esRefaccionPlnata](ordComp.oce_folioorden,1)) as idEstatusPlanta
								,CASE WHEN oeVista.[idOrdenEstatusVista] IS NULL  
									  THEN 1
									  ELSE 2
								 END visto
								,(select top 1 ordComp.sod_idsituacionorden from cuentasxpagar.dbo.cxp_ordencompra  order by ordComp.sod_idsituacionorden desc) as idEstatusOrden
								,LTRIM(RTRIM(replace(replace(per.per_paterno,'Ñ',''),'.','')  +' '+ replace(replace(per.per_materno,'Ñ',''),'.','') +' '+ per.per_nomrazon)) nombreProveedor
								,Recepcion = case when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6
										          then 'Recepción Completa'
										          when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7
										          THEN 'Recepción Incompleta'
										          else 'Pendiente'
										           end
								,Estado = CASE ordComp.sod_idsituacionorden
												 WHEN 12 THEN 'Pagada'
												 WHEN 13 THEN 'Pagada'
												 WHEN 16 THEN 'Pagada'
												 WHEN 18 THEN 'Pagada'
												 ELSE  'Por Pagar'
										   END
								 ,CASE  
										WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
										(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
										WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
										(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
										ELSE ''
									END AS NumSerie
								 ,OC.ser_ordenservicio ordenServicio
						 FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
					  	        LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
								LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
								LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
								LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
								LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
								LEFT JOIN proveedores.dbo.OrdenEstatusVista oeVista ON ordComp.oce_folioorden = oeVista.Folio_Operacion
								--Diferencia en este Join a EmpresaSucursal
								JOIN @EmpresaSucursal EmpSuc ON ordComp.oce_idempresa = EmpSuc.empresa AND ordComp.oce_idsucursal = EmpSuc.sucursal
								LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL
						WHERE --ordComp.oce_idproveedor = @idProveedor AND -- oce_idproveedor este en los IDS de la tabla cat_personas que coincida con el RFC de proveedor logueado
							   (@monto IS NULL OR ordComp.oce_importetotal = @monto)
							  AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
							  AND ordComp.oce_folioorden NOT IN (SELECT folioorden FROM PPRO_DATOSFACTURAS)				  
							  AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
							  AND ordComp.sod_idsituacionorden IN (2,5,6,7,8,15,17)
							  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
							  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
							  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
							  --AND CONVERT(DATE,REPLACE(ordComp.oce_fechaorden,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)		
							  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))
							  order by ordComp.oce_fechaorden ASC

				END
			ELSE
				BEGIN
				     PRINT 'CON FECHAS'
			         SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
								ordComp.oce_folioorden,depto.dep_nombre, suc.suc_nombre,  
								emp.emp_nombre,ordComp.oce_importetotal, emp.emp_nombrecto,  
								ordComp.oce_fechaorden,'1' estatus,per.per_rfc
								,ordComp.oce_uuid
								,ordComp.oce_imptotalrecibido 
								,suc.suc_idsucursal 
								,emp.emp_idempresa 
								,(SELECT [dbo].[esRefaccionPlnata](ordComp.oce_folioorden,1)) as idEstatusPlanta
								,CASE WHEN oeVista.[idOrdenEstatusVista] IS NULL  
									  THEN 1
									  ELSE 2
								 END visto
								,(select top 1 ordComp.sod_idsituacionorden from cuentasxpagar.dbo.cxp_ordencompra  order by ordComp.sod_idsituacionorden desc) as idEstatusOrden
								,LTRIM(RTRIM(replace(replace(per.per_paterno,'Ñ',''),'.','')  +' '+ replace(replace(per.per_materno,'Ñ',''),'.','') +' '+ per.per_nomrazon)) nombreProveedor
								,Recepcion = case when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6
										          then 'Recepción Completa'
										          when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7
										          THEN 'Recepción Incompleta'
										          else 'Pendiente'
										           end
								,Estado = CASE ordComp.sod_idsituacionorden
												 WHEN 12 THEN 'Pagada'
												 WHEN 13 THEN 'Pagada'
												 WHEN 16 THEN 'Pagada'
												 WHEN 18 THEN 'Pagada'
												 ELSE  'Por Pagar'
										   END
								 ,CASE  
										WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
										(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
										WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
										(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
										ELSE ''
									END AS NumSerie
								 ,OC.ser_ordenservicio ordenServicio
						 FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
					  	        LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
								LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
								LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
								LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
								LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
								LEFT JOIN proveedores.dbo.OrdenEstatusVista oeVista ON ordComp.oce_folioorden = oeVista.Folio_Operacion
								--Diferencia en este Join a EmpresaSucursal
								JOIN @EmpresaSucursal EmpSuc ON ordComp.oce_idempresa = EmpSuc.empresa AND ordComp.oce_idsucursal = EmpSuc.sucursal
								LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL
						WHERE --ordComp.oce_idproveedor = @idProveedor AND -- oce_idproveedor este en los IDS de la tabla cat_personas que coincida con el RFC de proveedor logueado
							   (@monto IS NULL OR ordComp.oce_importetotal = @monto)
							  AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
							  AND ordComp.oce_folioorden NOT IN (SELECT folioorden FROM PPRO_DATOSFACTURAS)				  
							  AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
							  AND ordComp.sod_idsituacionorden IN (2,5,6,7,8,15,17)
							  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
							  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
							  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
							  AND CONVERT(DATE,REPLACE(ordComp.oce_fechaorden,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)		
							  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))
							  order by ordComp.oce_fechaorden ASC

				END
						
	END

	-- poner condición si recepcion dice Recepción Incompleta mostrar modal para subir nota de credito
go

