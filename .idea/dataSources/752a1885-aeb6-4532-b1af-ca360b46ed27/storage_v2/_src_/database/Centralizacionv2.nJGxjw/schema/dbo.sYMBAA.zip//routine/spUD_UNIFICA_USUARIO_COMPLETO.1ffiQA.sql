

------------------------------ UNIFICANDO UN USUARIO COINCIDENCIA ABSOLUTA POR NOMBRE
--Declare @sUsr3letras varchar(10) = 'IRF';  --EL usuario donde se unificaran todas las coincidencias de su nombre.
--BUSCA TODOS LOS USUARIOS QUE CONCIDEN CON EL NOMBRE COMPLETO DEL USUARIO QUE SE QUEDA
--RECORRE TODAS LAS COINCIDENCIAS UNIFICANDO EN EL USUARIO QUE SE QUEDA

CREATE PROCEDURE [dbo].[spUD_UNIFICA_USUARIO_COMPLETO](@sUsr3letras varchar(10)) --with recompile
as

begin 
set nocount on

CREATE TABLE #temporal
(
  POSICION [int] IDENTITY (1, 1),
  usu_nombreusu varchar(10),
  usu_paterno varchar(100),
  usu_materno varchar(100),
  usu_nombre varchar(100)
 )

Declare @susu_paterno varchar(100) = '';
DEclare @susu_materno varchar(100) = '';
Declare @susu_nombre varchar(100) =  '';

select @susu_paterno = usu_paterno, @susu_materno=usu_materno, @susu_nombre = usu_nombre from ControlAplicaciones..cat_usuarios where usu_nombreusu = @sUsr3letras  

   insert into #temporal
   select usu_nombreusu, usu_paterno, usu_materno, usu_nombre 
   from ControlAplicaciones..cat_usuarios 
   where usu_paterno = ltrim(rtrim(@susu_paterno)) and  usu_materno=ltrim(rtrim(@susu_materno)) and usu_nombre = ltrim(rtrim(@susu_nombre)) 
   and usu_nombreusu <> @sUsr3letras

declare @susu_nombreusu varchar(10) = '';
declare @iIndice int = 1;
Declare @ReturnValue int;

while exists (Select top 1 usu_nombreusu from #temporal) 
begin
      select @susu_nombreusu = usu_nombreusu,@susu_paterno = usu_paterno, @susu_materno=usu_materno, @susu_nombre = usu_nombre from #temporal where POSICION = @iIndice

			Execute Centralizacionv2.[dbo].[spUD_UNIFICA_USUARIO] @sUsr3letras, @susu_nombreusu --este es el que se borra.			
			print 'Procesado: ' + @susu_nombreusu + ' ' + @susu_paterno + ' ' +  @susu_materno + ' ' + @susu_nombre

			delete #temporal where POSICION = @iIndice
			select @iIndice = @iIndice + 1
 end

 set nocount off
end


Execute Centralizacionv2..spUD_UNIFICA_USUARIO_COMPLETO '8CTS'
go

