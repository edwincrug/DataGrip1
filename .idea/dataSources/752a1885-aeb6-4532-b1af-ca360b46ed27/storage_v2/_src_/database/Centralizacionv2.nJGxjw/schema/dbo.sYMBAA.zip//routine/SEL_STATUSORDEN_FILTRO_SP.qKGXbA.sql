-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 20/10/2015
-- Description:	Stored que muestra los estatus disponibles de una orden para filtro
-- =============================================
CREATE PROCEDURE [dbo].[SEL_STATUSORDEN_FILTRO_SP]

AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
	SELECT sod_idsituacionorden
		, sod_nombresituacion
		, sod_nombrecto
	FROM [cuentasxpagar].[dbo].[cat_situacionorden]
	END TRY
  BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_STATUSORDEN_FILTRO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

