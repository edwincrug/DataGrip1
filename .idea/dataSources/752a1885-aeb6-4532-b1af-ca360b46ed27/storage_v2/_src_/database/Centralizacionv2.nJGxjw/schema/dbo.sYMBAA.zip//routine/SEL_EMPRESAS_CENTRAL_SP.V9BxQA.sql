-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 06/11/2015
-- Description:	Recupera las empresas de la base de datos que tienen usuarios asignados
--				Si la empresa no tiene asignado a un usuario, no se presenta en el listado.
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EMPRESAS_CENTRAL_SP]

AS
BEGIN
	SET NOCOUNT ON;
	SELECT    DISTINCT E.emp_idempresa
		, E.emp_cveempresa
		, E.emp_nombre
		, E.emp_nombrecto
		--, ControlAplicaciones.dbo.cat_usuarios.usu_idusuario
FROM  ControlAplicaciones.dbo.cat_departamentos D INNER JOIN
      ControlAplicaciones.dbo.cat_usuarios U ON D.dep_iddepartamento = U.dep_iddepartamento INNER JOIN
      ControlAplicaciones.dbo.cat_sucursales S ON D.suc_idsucursal = S.suc_idsucursal INNER JOIN
      ControlAplicaciones.dbo.cat_empresas E ON S.emp_idempresa = E.emp_idempresa
--WHERE (E.div_iddivision = @iddivision OR @iddivision = 0)
--	AND (U.usu_idusuario = @idempleado OR @idempleado = 0)
--	AND E.emp_idempresa <> 0
END


go

