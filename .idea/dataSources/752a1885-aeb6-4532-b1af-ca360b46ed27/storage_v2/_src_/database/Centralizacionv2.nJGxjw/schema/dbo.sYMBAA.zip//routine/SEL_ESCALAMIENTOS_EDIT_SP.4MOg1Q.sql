--EXECUTE [dbo].[SEL_ESCALAMIENTOS_EDIT_SP] 1,3,13,1,2,3,7,0,5
-- ================================================================================================================
-- Author: Lourdes Maldonado Sánchez
-- Create date: 19/01/2016
-- Description:	Procedimiento editar autorizadores de un tipo_idtipoorden.
-- ================================================================================================================
CREATE PROCEDURE [dbo].[SEL_ESCALAMIENTOS_EDIT_SP] 
	@emp_idempresa       INT = null,   --1
	@suc_idsucursal      INT = null,   --3
	@dep_iddepartamento  INT = null,   --13
	@tipo_idtipoorden    INT = null,   --1
	@idusuarioAutoriza1  INT = null,   --2 -- 3  --Que me va a dar un Id o un nombre???????
	@idusuarioAutoriza2  INT = null,   --3 --
	@idusuarioAutoriza3  INT = null,   --7 --
	@nivelEscalamiento   INT = null,   --0
	@minutosEscala       INT = null    --5
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
	    BEGIN TRAN
        --        SELECT  DE.Proc_Id             AS procId 
	       --            ,DE.emp_idempresa       AS empIdempresa
					   --,DE.suc_idsucursal      AS sucIdsucursal
					   --,DE.dep_iddepartaamento AS depIddepartamento
					   --,DE.tipo_idtipoorden    AS tipoidtipoorden 
					   --,DE.Nivel_Escalamiento  AS nivelEscalamiento
					   --,DE.Usuario_Autoriza1   AS idusuarioAutoriza1
					   --,DE.Usuario_Autoriza2   AS idusuarioAutoriza2
					   --,DE.Usuario_Autoriza3   AS idusuarioAutoriza3
					   --,DE.Minutos_Escalar     AS minutosEscala
                 UPDATE [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO] 
				    SET Usuario_Autoriza1     =    @idusuarioAutoriza1
					   ,Usuario_Autoriza2  =    @idusuarioAutoriza2
					   ,Usuario_Autoriza3  =    @idusuarioAutoriza3
					   --,DE.Nivel_Escalamiento =    @nivelEscalamiento
					   --,DE.Minutos_Escalar    =    @minutosEscala
				   FROM  [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO] 
				  WHERE  emp_idempresa       = @emp_idempresa
					AND  suc_idsucursal      = @suc_idsucursal 
					AND  dep_iddepartaamento = @dep_iddepartamento
					AND  tipo_idtipoorden    = @tipo_idtipoorden    --TABULADOR 0 1 2 3 4 5
		   COMMIT TRAN 
	END TRY
	BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_ESCALAMIENTOS_EDIT_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	END CATCH
END

go

