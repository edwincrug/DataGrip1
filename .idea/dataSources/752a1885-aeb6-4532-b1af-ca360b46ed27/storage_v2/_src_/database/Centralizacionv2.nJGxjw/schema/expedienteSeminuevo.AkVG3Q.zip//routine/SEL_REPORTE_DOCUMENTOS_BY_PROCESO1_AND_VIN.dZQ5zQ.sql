-- =============================================
-- Author:		<JJSY>
-- Create date: <SP que regresa reporte de documentos proceso 1>
-- Description:	<Description,,>
--TEST [expedienteSeminuevo].[SEL_REPORTE_DOCUMENTOS_BY_PROCESO1_AND_VIN] 'JM1BM1K31F1244253', 4, 6, 1
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_REPORTE_DOCUMENTOS_BY_PROCESO1_AND_VIN]
	@vin VARCHAR(50),
	@idEmpresa INT,
	@idSucursal INT,
	@idProceso INT
AS
BEGIN
DECLARE @nombreCliente NVARCHAR(MAX);
DECLARE @nombresucursal VARCHAR(MAX);
DECLARE @idCliente INT
DECLARE @bd VARCHAR(MAX);

DECLARE @sqlCommand VARCHAR(MAX)
DECLARE @idExpediente INT = 0;
DECLARE @queryDinamicoSeminuevos NVARCHAR(MAX);
DECLARE @seminuevos INT
DECLARE @complementoQuery VARCHAR(MAX)
	
DECLARE @queryFisicaMoral NVARCHAR(MAX) = '', @fisicaMoral VARCHAR(5), @querynombrecliente NVARCHAR (MAX);
	
    IF (@idProceso = 1)
        BEGIN
            SET @complementoQuery= ''''
        END
    ELSE IF (@idProceso = 2)
        BEGIN
            SET @complementoQuery = ''' AND VEH_SITUACION LIKE ''%SVEN%'''
        END


		SELECT @idExpediente = id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
			AND exp_empresa = @idEmpresa 
			AND exp_sucursal = @idSucursal


		SELECT @bd = nombre_base
	    FROM DIG_CAT_BASES_BPRO 
		WHERE emp_idEmpresa = @idEmpresa
		AND suc_idSucursal = @idSucursal

		SET @querynombrecliente = 'SELECT 
										@clienteNombre = PP.PER_NOMRAZON +''''+ PP.PER_PATERNO + '''' + PP.PER_MATERNO 
									FROM ' + @bd + '.DBO.SER_VEHICULO SV 
									INNER JOIN cuentasxpagar.[dbo].[cxp_detalleseminuevos] DS ON DS.asn_numeroserie =  SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
									INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] OC ON OC.oce_folioOrden = DS.oce_folioorden
									INNER JOIN GA_corporativa..PER_PERSONAS PP ON OC.oce_idproveedor = PP.PER_IDPERSONA 
									WHERE OC.sod_idsituacionorden <> 4 AND SV.VEH_NUMSERIE = ''' + @vin + @complementoQuery
		EXEC sp_executesql @querynombrecliente, N'@clienteNombre nvarchar(200) OUTPUT', @clienteNombre = @nombreCliente OUTPUT
		--select  @nombreCliente as name
		--print @querynombrecliente


	   SELECT @nombresucursal = nombre_sucursal
	   FROM DIG_CAT_BASES_BPRO 
		WHERE emp_idEmpresa = @idEmpresa
		AND suc_idSucursal = @idSucursal

			BEGIN TRY

			IF NOT EXISTS(SELECT id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
				AND exp_empresa = @idEmpresa 
				AND exp_sucursal = @idSucursal)
			BEGIN
				SET @queryDinamicoSeminuevos = 'SELECT @C = COUNT(*) FROM ' + @bd + '.DBO.SER_VEHICULO WHERE VEH_NUMSERIE = ''' + @vin + @complementoQuery
				PRINT(@queryDinamicoSeminuevos)
				
				EXEC sp_executesql @queryDinamicoSeminuevos, N'@C INT OUTPUT', @C=@seminuevos OUTPUT
				PRINT(@seminuevos)

				IF (@seminuevos > 0)
					BEGIN
						INSERT INTO [expedienteSeminuevo].[expedientes] ([exp_vin], [exp_empresa], [exp_sucursal], [exp_fechaCreacion])
							VALUES (@vin, @idEmpresa, @idSucursal, GETDATE())
					END
				ELSE
					BEGIN
						SELECT success = 0
						SELECT msg = 'No se encontró registro del VIN en la empresa y/o sucursal indicada.'
						RETURN
					END
			END
		
			SELECT @idExpediente = id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
				AND exp_empresa = @idEmpresa 
				AND exp_sucursal = @idSucursal
		
		SET @queryFisicaMoral = 'SELECT 
								@clienteId = OC.oce_idproveedor 
							FROM ' + @bd + '.DBO.SER_VEHICULO SV
							INNER JOIN cuentasxpagar.[dbo].[cxp_detalleseminuevos] DS ON DS.asn_numeroserie =  SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
							INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] OC ON OC.oce_folioOrden = DS.oce_folioorden
							WHERE OC.sod_idsituacionorden <> 4 AND VEH_NUMSERIE = ''' + @vin + @complementoQuery
		EXEC sp_executesql @queryFisicaMoral, N'@clienteId INT OUTPUT', @clienteId = @idCliente OUTPUT

        IF (@idCliente IS NULL)
            BEGIN
                SELECT success = 0
                SELECT msg = 'No se encontró registro del VIN en la empresa y/o sucursal indicada.'
                RETURN
            END
	
		SELECT @fisicaMoral = PER_TIPO FROM GA_corporativa.DBO.PER_PERSONAS WHERE PER_IDPERSONA = @idCliente
		--TEST [expedienteSeminuevo].[SEL_DOCUMENTOS_BY_PROCESO_AND_VIN] 'JM1BM1K31F1244253', 4, 6, 1, 139, 71
		DECLARE @rutaSave VARCHAR(500), @rutaGet VARCHAR(500);

		SELECT success = 1;


SET @sqlCommand = '

		SELECT 
		sucursal,
		vin,
		nombreCliente,
		isnull(MAX([1]),''NO APLICA'') as [AvaluoAutorizadoporIntelimotors],
		isnull(MAX([2]),''NO APLICA'') AS [ConsultaTransunion],
		isnull(MAX([3]),''NO APLICA'')AS [Ordendecompra],
		isnull(MAX([4]),''NO APLICA'')AS [ContratoCompraVentadeVehiculosAutomotores],
		isnull(MAX([5]),''NO APLICA'') AS [FacturadeOrigen],
		isnull(MAX([6]),''NO APLICA'') AS [Facturaemitidaanombredeladistribuidora],
		isnull(MAX([7]),''NO APLICA'') AS [FacturasAnteriores],
		isnull(MAX([8]),''NO APLICA'')AS [ContratodeCompraVenta],
		isnull(MAX([9]),''NO APLICA'')AS [TenenciasOriginales],
		isnull(MAX([10]),''NO APLICA'')AS [TarjetadeCirculacion],
		isnull(MAX([11]),''NO APLICA'')AS [ComprobantedeBajadePlacasoPlacasdeCirculacion],
		isnull(MAX([12]),''NO APLICA'')AS [OriginalCertificadodeVerificacionVehicularFolio],
		isnull(MAX([13]),''NO APLICA'')AS [CopiadeIdentificacionOficial],
		isnull(MAX([14]),''NO APLICA'')AS [RegistroFederaldeCausantes],
		isnull(MAX([15]),''NO APLICA'')AS [ComprobantedeDomicilio],
		isnull(MAX([16]),''NO APLICA'')AS [CURP],
		isnull(MAX([17]),''NO APLICA'') AS [EstadodeCuentaanombredeltitulardelaunidad] ,
		isnull(MAX([18]),''NO APLICA'') AS [ActaConstituvainscritaenRPP] ,
		isnull(MAX([19]),''NO APLICA'')AS [PoderRepresentanteconactadedominio],
		isnull(MAX([20]),''NO APLICA'')AS [IdentificacionoficialdelRepresentenateLegal],
		isnull(MAX([21]),''NO APLICA'')AS [CartaautorizacionparaAutofacturacion],
		isnull(MAX([22]),''NO APLICA'')AS [Autofacturacion],
		isnull(MAX([23]),''NO APLICA'')AS [PagodeTenencias]
	FROM (


SELECT 
			A.id_documento as iddocumento,
		    --B.id_documentoGuardado,
			''' + @nombresucursal + ''' as sucursal,
			''' + @vin + ''' as vin,
			'''+ @nombreCliente + ''' AS nombreCliente,
			A.doc_nombre as nombre,
			CASE WHEN ISNULL(B.id_documentoGuardado, 0) > 0 THEN ''OK'' ELSE ''FALTA'' END AS existe
		FROM ( 
			SELECT 
				id_documento, 
				doc_nombre, 
				doc_extencion, 
				doc_opcional, 
				doc_proceso,
				doc_varios
			FROM [expedienteSeminuevo].[cat_documentos] 
			WHERE doc_proceso =  '+ CAST(@idProceso AS NVARCHAR(10))+'  AND (('''+ @fisicaMoral + ''' = ''MOR'' AND doc_moral = 1) OR ('''+ @fisicaMoral +'''  = ''FIS'' AND doc_fisica = 1) OR ('''+ @fisicaMoral +'''  = ''FIE'' AND doc_fisicaAE = 1))) AS A
		LEFT JOIN ( 
			SELECT
				max(DE.id_documentoGuardado) as id_documentoGuardado, 
				E.exp_vin,
				DE.id_expediente, 
				DE.id_proceso, 
				MAX(DE.id_estatus) AS id_estatus,
				MAX(ED.est_descripcion) AS est_descripcion, 
				MAX(DE.observacionesDocumento) observacionesDocumento,  
				--max(id_documento) as idDoc,
				DE.id_documento,
				max (nombreDocumento) as nombreDocumento
			FROM [Centralizacionv2].[expedienteSeminuevo].[documentosExpediente] DE
			INNER JOIN [expedienteSeminuevo].[estatusDocumentos] ED ON DE.id_estatus = ED.id_estatus 
		    inner JOIN [expedienteSeminuevo].[expedientes] E ON DE.id_expediente = E.id_expediente
			INNER JOIN ' + @bd + '.DBO.SER_VEHICULO SV ON E.exp_vin COLLATE Modern_Spanish_CI_AS = SV.VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS
		    INNER JOIN GA_corporativa.DBO.PER_PERSONAS PP ON SV.VEH_IDCLIENT = PP.PER_IDPERSONA
			WHERE DE.id_expediente = '+ CAST(@idExpediente AS NVARCHAR(10))+' 
			group by  E.exp_vin,DE.id_expediente, DE.id_proceso, DE.id_documento) AS B ON B.id_documento = A.id_documento AND B.id_proceso = A.doc_proceso
		INNER JOIN [expedienteSeminuevo].[documentoPerfil] DP ON DP.id_documento = A.id_documento AND DP.id_proceso = A.doc_proceso
		LEFT JOIN [expedienteSeminuevo].[documentosVarios] DV ON DV.doc_idDocumento = A.id_documento
		) x
		PIVOT
		(
			MAX(existe)
			FOR iddocumento in 
			(
			[1],
			[2],
			[3],
			[4],
			[5],
			[6],
			[7],
			[8],
			[9],
			[10],
			[11],
			[12],
			[13],
			[14],
			[15],
			[16],
			[17],  
			[18],
			[19],
			[20],
			[21],
			[22],
			[23]
			) )AS p
			GROUP BY vin,sucursal,nombreCliente,nombreCliente'

			PRINT @sqlCommand
			EXEC (@sqlCommand)

    END TRY

	BEGIN CATCH
		PRINT (ERROR_MESSAGE())
		SELECT success = 0
		SELECT msg = 'Error al regresar los datos del expediente.';
	END CATCH

END

go

