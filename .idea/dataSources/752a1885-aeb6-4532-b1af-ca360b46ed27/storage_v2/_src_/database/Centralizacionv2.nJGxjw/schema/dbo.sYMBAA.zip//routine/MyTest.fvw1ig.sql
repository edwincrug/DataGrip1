
CREATE PROCEDURE [dbo].[MyTest]
  @Data1 int = 0
 ,@Data2 int = 0
 ,@Data3 int = null output

AS

PRINT @Data1
PRINT @Data2
PRINT isnull(@Data3, -1)

SET @Data3 = @Data3 + 1

RETURN 0


------------------
------------------
--DECLARE @Output int

--SET @Output = 3

--EXECUTE MyTest
--  @Data1 = 1
-- ,@Data2 = 2
-- ,@Data3 = @Output output

--PRINT '---------'
--PRINT @Output
go

