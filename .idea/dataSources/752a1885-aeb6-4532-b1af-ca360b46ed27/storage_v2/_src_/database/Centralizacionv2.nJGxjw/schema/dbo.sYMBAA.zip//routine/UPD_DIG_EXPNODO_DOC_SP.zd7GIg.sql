-- =============================================
-- Author:		Alejandro Lopez
-- Create date: 05/02/2016
-- Description:	Actualizar tabla DIG_EXPNODO_DOC
-- =============================================

CREATE PROCEDURE [dbo].[UPD_DIG_EXPNODO_DOC_SP]
	 @proc_Id	int = 0
	,@doc_Id	int = 0
	,@folio_Operacion varchar(80) = ''	
	 
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY				

	UPDATE DIG_EXPNODO_DOC SET
			Fecha_Creacion = GETDATE()
	WHERE [Proc_Id] = @proc_Id 
	AND	  [Doc_Id] = @doc_Id
	AND	  [Folio_Operacion]	= @folio_Operacion
				
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[UPD_DIG_EXPNODO_DOC_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
    EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

