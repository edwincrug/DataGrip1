/*

declare @Pen_FechaEntregaReal varchar(10);
	declare @sBaseDatos varchar(50);
	declare @nucu_idpedidobpro numeric (18,0);
	declare @sucn_noserie varchar(20);
	
Esta dentro de una transaccion.

este store lo dispara el trigguer  dig_Trigger_ActualizaEstatusFechaEntrega en UNI_PEDIUNI en cada operativa al actualizar la fecha real de entrega 
*/

CREATE PROCEDURE [dbo].[spU_UNIDAD_ENTREGADA](@sBaseDatos varchar(50),@nucu_idpedidobpro numeric(18,0) , @sucn_noserie varchar(20)) --with recompile
 AS
declare
@sFolio_Operacion varchar(50)

begin 

set nocount on

BEGIN TRANSACTION PonFolioEnUnidadEntregada
        
		-- lo primero es encontrar el expediente de la cotización
		select  @sFolio_Operacion = cu.ucu_foliocotizacion 
		from cuentasporcobrar..uni_cotizacionuniversal cu, cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud
		where cu.ucu_idcotizacion = cud.ucu_idcotizacion
		and ucn_noserie=@sucn_noserie
		and ucu_idpedidobpro=@nucu_idpedidobpro

		--Teniendo el folio de la cotizacion cargamos todas las unidades de la cotizacion en tabla temporal, solo las unidades que ya tengan FECHAREALDEENTREGA.
		declare  @sTipoCotizacion varchar(3) = '';
		select @sTipoCotizacion = ucu_tipocotizacion from  cuentasporcobrar..uni_cotizacionuniversal where ucu_foliocotizacion =  @sFolio_Operacion
		--NU SN
		declare @iHayUnidadesSinEscanear int = 0;
		
		-------------------------
		--BEGIN TRY
			--DROP TABLE #VINS_ESCANEADOS
		--END TRY
		--BEGIN CATCH SELECT 1 END CATCH

			CREATE TABLE #VINS_ESCANEADOS
			(
			 num_serie varchar(20) NOT NULL PRIMARY KEY,
			 fecha_entrega_real datetime NULL,
			 id_pedido int NOT NULL
			 )

		Declare @sQ nvarchar(1500) = '';
		declare @sParmDefinition nvarchar(500) = '';
		--declare @nucu_idpedidobpro int = 29965;
		--declare @sBaseDatos varchar(50) = 'GAZM_Zaragoza';
		--declare @sFolio_Operacion varchar(50) = 'AU-ZM-NZA-UN-294'	
		
		set @sQ = N' Insert into #VINS_ESCANEADOS (num_serie,fecha_entrega_real, id_pedido) '
		
		if (@sTipoCotizacion='NU') --nuevos
		begin
			set @sQ = @sQ + N' select PEN_NUMSERIE, PEN_FECHAENTREGA_REAL,PEN_IDPEDI'
			set @sQ = @sQ + N' from ' + @sBaseDatos + '..' + 'UNI_PEDIUNI where PEN_NUMSERIE in ('
		end
		else
		begin
			set @sQ = @sQ + N' select PMS_NUMSERIE, PMS_FECHAREALENTREGA,PMS_NUMPEDIDO'
			set @sQ = @sQ + N' from ' + @sBaseDatos + '..' + 'USN_PEDIDO where PMS_NUMSERIE in ('
		end

		set @sQ = @sQ + N' select ucn_noserie from cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud, cuentasporcobrar..uni_cotizacionuniversal cu'
		set @sQ = @sQ + N' where cud.ucu_idcotizacion=cu.ucu_idcotizacion)' 

		if (@sTipoCotizacion='NU') --nuevos
		begin
			set @sQ = @sQ + N' and PEN_IDPEDI = ' + ltrim(rtrim(Convert(char(10),@nucu_idpedidobpro)))
			set @sQ = @sQ + N' and PEN_STATUS = ' + char(39) + 'I' + char(39)
			set @sQ = @sQ + N' and Isnull(PEN_FECHAENTREGA_REAL,' + char(39) + '01/01/1900' +char(39) +') <> ' + char(39) + '01/01/1900' +char(39) --solo los que tienen fecha de escaneo.
		end		
		else
		begin
			set @sQ = @sQ + N' and PMS_NUMPEDIDO = ' + ltrim(rtrim(Convert(char(10),@nucu_idpedidobpro)))
			set @sQ = @sQ + N' and PMS_STATUS = ' + char(39) + 'I' + char(39)
			set @sQ = @sQ + N' and Isnull(PMS_FECHAREALENTREGA,' + char(39) + '01/01/1900' +char(39) +') <> ' + char(39) + '01/01/1900' +char(39) --solo los que tienen fecha de escaneo.
		end
		
		print @sQ
		SET @sParmDefinition = N'';
		EXECUTE sp_executesql @sQ
		--ahora buscamos que todos las unidades en la cotizacion universal ya esten en la tabla temporal donde estan todos los escaneados
		select @iHayUnidadesSinEscanear = Count(num_serie) from #VINS_ESCANEADOS

		declare @iUnidadesEnCotizacion int =  0;		

		select @iUnidadesEnCotizacion = Count(ucn_noserie) from cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud, cuentasporcobrar..uni_cotizacionuniversal cu
		where cu.ucu_idcotizacion = cud.ucu_idcotizacion
		and cu.ucu_foliocotizacion = @sFolio_Operacion  

		declare @iDiferencia int = 0;
		select @iDiferencia = @iUnidadesEnCotizacion - @iHayUnidadesSinEscanear
		--------------------------
		if (ltrim(rtrim(@sFolio_Operacion))<>'' and @iDiferencia = 0)
		begin
			update [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] set cec_idestatuscotiza=20 --Unidad Entregada ***cuidado en Desarrollo es 21 --
			where ucu_foliocotizacion = @sFolio_Operacion

			insert into [Centralizacionv2].[dbo].[DIG_BITACORA] (fecha, quien, que, aquien)						   
			values (getdate(),'sp_UNIDAD_ENTREGADA', 'Cambio de estatus en Cotizacion a 20 UNIDAD ENTREGADA no Serie:' + @sucn_noserie, @sFolio_Operacion )			
		end 

		if (ltrim(rtrim(@sFolio_Operacion))<>'' and @iDiferencia > 0)
		begin
			insert into [Centralizacionv2].[dbo].[DIG_BITACORA] (fecha, quien, que, aquien)						   
			values (getdate(),'sp_UNIDAD_ENTREGADA', 'Aun hay unidades sin escanear no Serie:' + @sucn_noserie, @sFolio_Operacion );		
		end 

		if (ltrim(rtrim(@sFolio_Operacion))='')
		begin
			insert into [Centralizacionv2].[dbo].[DIG_BITACORA] (fecha, quien, que, aquien)						   
			values (getdate(),'sp_UNIDAD_ENTREGADA', 'No se encontró cotizacion para BD:' + @sBaseDatos + ' No pedido: ' + Convert(char(10),@nucu_idpedidobpro), @sucn_noserie)			
		end
	
COMMIT TRANSACTION PonFolioEnUnidadEntregada

set nocount off
end

/*
select   cu.ucu_foliocotizacion , cu.* 
		from cuentasporcobrar..uni_cotizacionuniversal cu, cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud
		where cu.ucu_idcotizacion = cud.ucu_idcotizacion
		and ucn_noserie=''
		and ucu_idpedidobpro=@nucu_idpedidobpro


		select top 100* from cuentasporcobrar..uni_cotizacionuniversal cu
		where ucu_foliocotizacion like 'AU-ZM-NZA-UN-%' 
		--and ucu_idcotizacion in (2979)  
		order by ucu_fechacotiza desc  --15
		
		select ucu_idcotizacion,* from cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud
		where ucu_idcotizacion in	(select ucu_idcotizacion from cuentasporcobrar..uni_cotizacionuniversal cu
		where ucu_foliocotizacion like 'AU-ZM-NZA-UN-%')
		order by 1

		2979 --AU-ZM-NZA-UN-294   --15
        2980

		select * from [192.168.20.59].[PortalClientes].[dbo].[SICOP_BITACORA] where aquien collate SQL_Latin1_General_CP1_CI_AS in (
		select ucn_noserie from cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud where ucu_idcotizacion=2979)

		select * from cuentasporcobrar..uni_cotizacionuniversal cu where ucu_idcotizacion=2979
		select ucn_noserie,* from cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud where ucu_idcotizacion=2979

		select top 10 * from GAZM_Zaragoza..UNI_PEDIUNI where PEN_NUMSERIE in ('3N6AD35C3JK861497' ,'3N6AD35C6JK861591')  --29965


		--DECLARE @VINS_ESCANEADOS AS TABLE 
		BEGIN TRY
			DROP TABLE #VINS_ESCANEADOS
		END TRY
		BEGIN CATCH SELECT 1 END CATCH

			CREATE TABLE #VINS_ESCANEADOS
			(
			 num_serie varchar(20) NOT NULL PRIMARY KEY,
			 fecha_entrega_real datetime NULL,
			 id_pedido int NOT NULL
			 )

		Declare @sQ nvarchar(1500) = '';
		declare @sParmDefinition nvarchar(500) = '';
		declare @nucu_idpedidobpro int = 29965;
		declare @sBaseDatos varchar(50) = 'GAZM_Zaragoza';
		declare @sFolio_Operacion varchar(50) = 'AU-ZM-NZA-UN-294'

		--set @sQ = N'select @sUSU_APUSUARIOUT = USU_APUSUARI,@sUSU_AMUSUARIOUT = USU_AMUSUARI,@sUSU_NOUSUARIOUT = USU_NOUSUARI,@sUSU_CVEACCESOUT = USU_CVEACCES, @susu_idusuariOUT = usu_idusuari  from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_USUARIOS] where usu_idusuari like ' + char(39) + @sUsr3letrasAux + char(37) + char(39)
		
		set @sQ = N' Insert into #VINS_ESCANEADOS (num_serie,fecha_entrega_real, id_pedido) '
		set @sQ = @sQ + N' select PEN_NUMSERIE, PEN_FECHAENTREGA_REAL,PEN_IDPEDI'
		set @sQ = @sQ + N' from ' + @sBaseDatos + '..' + 'UNI_PEDIUNI where PEN_NUMSERIE in ('
		set @sQ = @sQ + N' select ucn_noserie from cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud, cuentasporcobrar..uni_cotizacionuniversal cu'
		set @sQ = @sQ + N' where cud.ucu_idcotizacion=cu.ucu_idcotizacion)' 
		set @sQ = @sQ + N' and PEN_IDPEDI = ' + ltrim(rtrim(Convert(char(10),@nucu_idpedidobpro)))
		set @sQ = @sQ + N' and PEN_STATUS = ' + char(39) + 'I' + char(39)
		set @sQ = @sQ + N' and Isnull(PEN_FECHAENTREGA_REAL,' + char(39) + '01/01/1900' +char(39) +')=' + char(39) + '01/01/1900' +char(39)
		--print @sQ
		SET @sParmDefinition = N'';
		EXECUTE sp_executesql @sQ
		--ahora buscamos que todos las unidades en la cotizacion universal ya esten en la tabla temporal donde estan todos los escaneados
		select esc.*  from #VINS_ESCANEADOS esc, cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud, cuentasporcobrar..uni_cotizacionuniversal cu
		where esc.num_serie = ucn_noserie
		and cu.ucu_idcotizacion = cud.ucu_idcotizacion
		and cu.ucu_foliocotizacion = @sFolio_Operacion  
		


				select  @sFolio_Operacion = cu.ucu_foliocotizacion 
		from cuentasporcobrar..uni_cotizacionuniversal cu, cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud
		where cu.ucu_idcotizacion = cud.ucu_idcotizacion
		and ucn_noserie=@sucn_noserie
		and ucu_idpedidobpro=@nucu_idpedidobpro



		select PEN_NUMSERIE, PEN_FECHAENTREGA_REAL,PEN_IDPEDI  
		from GAZM_Zaragoza..UNI_PEDIUNI where PEN_NUMSERIE in (
		select ucn_noserie from cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES cud, cuentasporcobrar..uni_cotizacionuniversal cu 
		where cud.ucu_idcotizacion=cu.ucu_idcotizacion) 
		and PEN_IDPEDI = 29965 --este es dinamico
		and PEN_STATUS = 'I'
		and Isnull(PEN_FECHAENTREGA_REAL,'01/01/1900')='01/01/1900' --solo los que ya fueron escaneados.


		--se compara contra las unidades en la cotizacion, si ya todas fueron escaneadas entonces se actualiza a Unidad Entregada.

		select top 10 * From GA_Corporativa..Cat_idSicop where scp_idbpro = 479439
		--delete GA_Corporativa..Cat_idSicop where scp_idbpro = 479439

		josafat perez olmedo
		*/
go

