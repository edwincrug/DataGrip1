
CREATE PROCEDURE [dbo].[SP_INSERTA_UUID_XML]
	@FolioOrden VARCHAR(100)
AS
BEGIN
 SET NOCOUNT ON;
    
 
 DECLARE @Base                 VARCHAR(100);
 DECLARE @ConsultaPoliza       VARCHAR(max)
 DECLARE @ConsultaPolizaCFDI   VARCHAR(max)
 DECLARE @ConsultaConsFac      VARCHAR(max)
 DECLARE @ConsultaConsIva      VARCHAR(max)
 DECLARE @InsertaRegistroFac   VARCHAR(max)
 DECLARE @InsertaRegistroIva   VARCHAR(max)
 
 DECLARE @ImporteOrden         NUMERIC(18,0)
 DECLARE @ImporteOrdenRec      NUMERIC(18,0)
 DECLARE @ImporteIva           NUMERIC(18,0)
 DECLARE @ImporteXML           NUMERIC(18,0)  
 DECLARE @AnioPoliza           VARCHAR(4)
 DECLARE @MesPoliza            VARCHAR(4)
 DECLARE @TipoPoliza           VARCHAR(10)
 DECLARE @NumeroPoliza         VARCHAR(20)
 DECLARE @NumeroPolCons        VARCHAR(20)
 DECLARE @NumeroPolConsFac     VARCHAR(20) 
 DECLARE @NumeroPolConsIva     VARCHAR(20) 
 DECLARE @FacturaFolio         VARCHAR(50) 
 DECLARE @UUID                 VARCHAR(200) 
 DECLARE @IdPersona            VARCHAR(20) 
 DECLARE @RfcPersona           VARCHAR(20) 
 DECLARE @RutaXml              VARCHAR(200) 
 DECLARE @RutaPdf              VARCHAR(200) 
 DECLARE @NombreXml            VARCHAR(200) 
 DECLARE @NombrePdf            VARCHAR(200) 
 DECLARE @CorreoProv           VARCHAR(200) 
 DECLARE @ipLocal              VARCHAR(50) 
 DECLARE @ip_catbases          VARCHAR(50) 
 
 --INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE DONDE SE BUSCARA LA POLIZA
 
 SELECT TOP 1 @ipLocal=local_net_address 
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC
 
 select @ip_catbases = ip_servidor FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
 (SELECT emp_nombrecto FROM ControlAplicaciones.DBO.cat_empresas WHERE emp_idempresa = 
 (SELECT oce_idempresa FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)) AND catsuc_nombrecto = 'CONCENTRA'
 
 if (ltrim(rtrim(@ipLocal))=rtrim(ltrim(@ip_catbases)))
  begin
	SET @Base = (SELECT '[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
	(SELECT emp_nombrecto FROM ControlAplicaciones.DBO.cat_empresas WHERE emp_idempresa = 
	(SELECT oce_idempresa FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)) AND catsuc_nombrecto = 'CONCENTRA')  
  end 
 else
 begin
 SET @Base = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
 (SELECT emp_nombrecto FROM ControlAplicaciones.DBO.cat_empresas WHERE emp_idempresa = 
 (SELECT oce_idempresa FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)) AND catsuc_nombrecto = 'CONCENTRA')
 end
 
 
 --QUERY CONSULTA          
 set @ConsultaPoliza = 'SELECT mre_numeropoliza,mre_tipoliza,mre_anio,mre_mes,mre_movimiento FROM ' + @Base + 
 'con_movimientoreferencia WHERE mre_folioorden = ''' + @FolioOrden + ''' AND mre_tipoliza IN 
 (SELECT PAR_IDENPARA FROM ' + @Base + 'pnc_parametr WHERE  par_tipopara = ''TIPOLI'' and PAR_DESCRIP2 
 IN(''COMACC'',''COMACCS'',''CU'',''CR'',''COSE'',''APORDCOM'',''CPV'',''CXPTOT''))
 GROUP BY mre_anio,mre_tipoliza,mre_numeropoliza,mre_mes,mre_movimiento'
          
 --VERIFICA SI EXISTE LA POLIZA
 DECLARE @Pol TABLE (mre_numeropoliza VARCHAR(MAX),mre_tipoliza VARCHAR(MAX),mre_anio VARCHAR(MAX),mre_mes VARCHAR(MAX),mre_movimiento VARCHAR(MAX) )          
 INSERT INTO @Pol              
 EXEC (@ConsultaPoliza)                   
                
 --BUSCA EL AÑO
 SET @AnioPoliza = (SELECT mre_anio FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol))
 SET @MesPoliza = (SELECT mre_mes FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol))
 SET @TipoPoliza = (SELECT mre_tipoliza FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol))
 SET @NumeroPoliza = (SELECT mre_numeropoliza FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol))            
 SET @NumeroPolCons = (SELECT mre_movimiento FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol)) 
          
 SET @ConsultaPolizaCFDI = 'SELECT GFI_CONSPOL FROM ' + @Base + 'CON_GCFDI01' + @AnioPoliza + ' where GFI_TIPOPOL= ''' + @TipoPoliza + ''' and GFI_CONSPOL=' + @NumeroPoliza + ' and GFI_MES=' + @MesPoliza + ' AND GFI_CONSEC = ' + @NumeroPolCons
          
 --VERIFICA SI EXISTE EL REGISTRO
 DECLARE @RegPol TABLE (mre_numeropoliza VARCHAR(MAX))         
 INSERT INTO @RegPol          
 EXEC (@ConsultaPolizaCFDI)                     
 IF (SELECT mre_numeropoliza FROM @RegPol) <> ''
   BEGIN     
     RETURN 0
   END
 ELSE    
   --A1 
   BEGIN
     --BUSCA DATOS DEL XML EN TABLA DE REGISTRO
     SELECT @FacturaFolio = LTRIM(RTRIM(CONVERT(VARCHAR(20),serie))) + LTRIM(RTRIM(CONVERT(VARCHAR(20),folio))), @UUID = uuid, @RfcPersona = rfc_emisor,
     @RutaXml = 'Z:\' + rfc_emisor, @RutaPdf = 'Z:\' + rfc_emisor, 
     @NombreXml = rfc_emisor + '_' + LTRIM(RTRIM(CONVERT(VARCHAR(20),serie))) + LTRIM(RTRIM(CONVERT(VARCHAR(20),folio))) + '.xml',
     @NombrePdf = rfc_emisor + '_' + LTRIM(RTRIM(CONVERT(VARCHAR(20),serie))) + LTRIM(RTRIM(CONVERT(VARCHAR(20),folio))) + '.pdf',
     @ImporteOrden = ISNULL(importe,0),
     @ImporteIva = ISNULL(iva,0)
     FROM PPRO_DATOSFACTURAS WHERE folioorden = @FolioOrden    
      
     --BUSCA ID PERSONA EN LA TABLA DE ORDENES DE COMPRA
     SET @IdPersona = (SELECT oce_idproveedor FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)
         
     --BUSCA IMPORTE DE LA ORDEN DE COMPRA   
     
     IF (SELECT dep_nombrecto FROM ControlAplicaciones.dbo.cat_departamentos where dep_iddepartamento = (SELECT oce_iddepartamento FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)) IN ('RE','OT')
       BEGIN
        SET @ImporteOrdenRec = (SELECT oce_imptotalrecibido FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)
       END
       ELSE
       BEGIN
        SET @ImporteOrdenRec = (SELECT oce_importetotal FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)
       END       
     -------------------------------------------------------------------------
	 --Modificacion Servicio 
	 -------------------------------------------------------------------------
		DECLARE @folio VARCHAR(50) = @FolioOrden
		DECLARE @total NUMERIC(18,2) = 0, @queryTotal VARCHAR(MAX) = ''
		DECLARE @tablaTotal TABLE(total NUMERIC(18,2))
		DECLARE @idEmpresa INT, @idSucursal INT
		SELECT @idEmpresa = oce_idempresa, @idSucursal = oce_idsucursal FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_folioorden = @folio
		DECLARE @baseAgencia VARCHAR(200) = dbo.base_Agencia(@idEmpresa,@idSucursal)
		--SELECT @baseAgencia
		--DECLARE @baseAgencia VARCHAR(200) = (SELECT	'[' + B.ip_servidor + '].[' + B.nombre_base + '].[dbo].'
		--										FROM	[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
		--												INNER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON B.emp_idempresa = OC.oce_idempresa AND B.suc_idsucursal = OC.oce_idsucursal
		--										WHERE	OC.oce_folioorden = @folio)
		--SELECT @baseAgencia
		IF ( EXISTS (SELECT 1 FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac] WHERE ifr_folionuevo = @folio))
			BEGIN
				DECLARE @folioNuevo TABLE(id INT IDENTITY, folio VARCHAR(50)) 
				DECLARE @max INT, @aux INT = 1, @folioAuxiliar VARCHAR(50)
				INSERT INTO @folioNuevo
				SELECT	DISTINCT ifr_folioinicial 
				FROM	[cuentasxpagar].[dbo].[cxp_integracionfacrefac] 
				WHERE	ifr_folionuevo = @folio
				SELECT @max = COUNT(1) FROM @folioNuevo
				WHILE (@aux <= @max)
					BEGIN
						SELECT @folioAuxiliar = folio FROM @folioNuevo WHERE id = @aux
						SET @queryTotal = '(SELECT	SUM(ISNULL(mov_flete,0.00)) + SUM(ISNULL(mov_seguro,0.00)) + SUM(ISNULL(mov_maniobras,0.00)) 
											FROM	'+ @baseAgencia +'PAR_MOVTOS 
											WHERE	Mov_Refer1 = '''+ @folioAuxiliar +''')'
						INSERT INTO @tablaTotal 
						EXECUTE (@queryTotal)
						SET @aux = @aux + 1;
					END
				--SET @folioNuevo = (SELECT	DISTINCT ifr_folioinicial 
				--					FROM	[cuentasxpagar].[dbo].[cxp_integracionfacrefac] 
				--					WHERE	ifr_folionuevo = @folio) 
				--SELECT SUM(total) FROM @tablaTotal
				SELECT @total = SUM(total) FROM @tablaTotal
				SET @total = ISNULL(@total,0.00) * 1.16
				--SELECT @total
		
			END
		ELSE
			BEGIN
				SET @queryTotal = '(SELECT SUM(ISNULL(mov_flete,0.00)) + SUM(ISNULL(mov_seguro,0.00)) + SUM(ISNULL(mov_maniobras,0.00))
										FROM	'+ @baseAgencia +'PAR_MOVTOS 
										WHERE	Mov_Refer1 ='''+@folio+''')'
				INSERT INTO @tablaTotal
				EXECUTE (@queryTotal)
				SELECT @total = total FROM @tablaTotal
				SET @total = ISNULL(@total,0.00) * 1.16
				--SELECT @total
		
			END
	 -------------------------------------------------------------------------
	 ------------------------------------------------------------------------- 
     IF (ABS((@ImporteOrdenRec + @total) - @ImporteOrden)) > 10
       BEGIN
         
         IF Exists (SELECT correo FROM PPRO_USERSPORTALPROV WHERE ppro_user = @RfcPersona) 
         BEGIN
           SET @CorreoProv = (SELECT correo FROM PPRO_USERSPORTALPROV WHERE ppro_user = @RfcPersona)
         END
         ELSE
         BEGIN
           SET @CorreoProv = 'javier.hernandezr@grupoadrade.com.mx'
         END  
         
         IF Exists (SELECT folio_operacion FROM DIG_MSGREPET WHERE folio_operacion = @FolioOrden) 
         BEGIN
           update DIG_MSGREPET set fecha_ins=getdate(), fecha_env=null,cuenta_env=@CorreoProv, estatus='x enviar', fecha_prox_env=getdate() where folio_operacion=@FolioOrden
         END
         ELSE
         BEGIN
           INSERT INTO DIG_MSGREPET VALUES(@IdPersona,@FolioOrden,GETDATE(),GETDATE(),1,@CorreoProv,'x enviar',GETDATE()) 
         END                 
         RETURN 0
       END
       
     ELSE
       --A2
       BEGIN             
                       
         --BUSCA CONSECUTIVO DEL REGISTRO DE LA POLIZA PARA LA FACTURA
         ------------------------------------------------------------------------------------------------------------
         set @ConsultaConsFac = 'SELECT CCP_CONSMOV=MIN(CCP_CONSMOV) FROM ' + @Base + 'CON_CAR01' + @AnioPoliza + ' WHERE CCP_CONSPOL = ''' + @NumeroPoliza + ''' 
                                 AND CCP_TIPOPOL = ''' + @TipoPoliza + ''' AND CCP_MES = ' + @MesPoliza + ' AND CCP_TIPODOCTO = ''FAC'''
                                      
         DECLARE @PolConsFac TABLE (CCP_CONSMOV VARCHAR(MAX))          
         INSERT INTO @PolConsFac          
         EXEC (@ConsultaConsFac)
               
         set @NumeroPolConsFac = (SELECT CCP_CONSMOV FROM @PolConsFac)
                           
         ------------------------------------------------------------------------------------------------------------
         --BUSCA CONSECUTIVO DEL REGISTRO DE LA POLIZA PARA EL IVA
              
         set @ConsultaConsIva = 'SELECT CCP_CONSMOV=MIN(CCP_CONSMOV) FROM ' + @Base + 'CON_CAR01' + @AnioPoliza + ' WHERE CCP_CONSPOL = ''' + @NumeroPoliza + ''' 
                                 AND CCP_TIPOPOL = ''' + @TipoPoliza + ''' AND CCP_MES = ' + @MesPoliza + ' AND CCP_TIPODOCTO = ''FACIVA'''
                                      
         DECLARE @PolConsIva TABLE (CCP_CONSMOV VARCHAR(MAX))          
         INSERT INTO @PolConsIva          
         EXEC (@ConsultaConsIva)
              
         set @NumeroPolConsIva = (SELECT CCP_CONSMOV FROM @PolConsIva)
              
         ------------------------------------------------------------------------------------------------------------  
         --INSERTA REGSITRO EN LA BASE DE BPRO
         --INSERTA IMPORTE                  
         set @InsertaRegistroFac = 'INSERT INTO ' + @Base + 'CON_GCFDI01' + @AnioPoliza + ' (GFI_TIPOPOL,GFI_CONSPOL,GFI_CONSEC,GFI_MES,GFI_IDDOCTO,
                                    GFI_UUID,GFI_MONTO,GFI_IDPERSONA,GFI_RFC,GFI_RUTAXML,GFI_RUTAPDF,GFI_NOMBREXML,GFI_NOMBREPDF,GFI_ESTATUS,GFI_CVEUSU,
                                    GFI_FECHOPE,GFI_HORAOPE)VALUES(''' + @TipoPoliza + ''',''' + @NumeroPoliza + ''',''' + @NumeroPolConsFac + 
                                    ''',''' + @MesPoliza + ''',''' + @FacturaFolio + ''',''' + @UUID + ''',''' + CONVERT(VARCHAR(20),@ImporteOrden) + ''',''' + @IdPersona +
                                    ''',''' + @RfcPersona + ''',''' + @RutaXml + ''',''' + @RutaPdf + ''',''' + @NombreXml + ''',''' + @NombrePdf + 
                                    ''',''R'',''GMI'',convert(VarChar(10), getdate(), 103),CONVERT(VARCHAR(5), getdate(), 108))'
         
         --EXEC (@InsertaRegistroFac)
         
         --SELECT @InsertaRegistroFac        
              
         --INSERTA IVA         
         set @InsertaRegistroIva = 'INSERT INTO ' + @Base + 'CON_GCFDI01' + @AnioPoliza + ' (GFI_TIPOPOL,GFI_CONSPOL,GFI_CONSEC,GFI_MES,GFI_IDDOCTO,
                                    GFI_UUID,GFI_MONTO,GFI_IDPERSONA,GFI_RFC,GFI_RUTAXML,GFI_RUTAPDF,GFI_NOMBREXML,GFI_NOMBREPDF,GFI_ESTATUS,GFI_CVEUSU,
                                    GFI_FECHOPE,GFI_HORAOPE)VALUES(''' + @TipoPoliza + ''',''' + @NumeroPoliza + ''',''' + @NumeroPolConsIva + 
                                    ''',''' + @MesPoliza + ''',''' + @FacturaFolio + ''',''' + @UUID + ''',''' + CONVERT(VARCHAR(20),@ImporteIva) + ''',''' + @IdPersona +
                                    ''',''' + @RfcPersona + ''',''' + @RutaXml + ''',''' + @RutaPdf + ''',''' + @NombreXml + ''',''' + @NombrePdf + 
                                    ''',''R'',''GMI'',convert(VarChar(10), getdate(), 103),CONVERT(VARCHAR(5), getdate(), 108))'
                            
         --EXEC (@InsertaRegistroIva)  
         --SELECT @InsertaRegistroIva                               
         --UPDATE PPRO_DATOSFACTURAS SET estatus = 2 WHERE folioorden = @FolioOrden                   
         --UPDATE DIG_EXPNODO_DOC set Fecha_Creacion = GETDATE() WHERE Folio_Operacion=@FolioOrden AND Nodo_Id = 7 AND Doc_Id = 20                                
         RETURN 1
               
       END
       --A2
     END
     --A1
END

go

