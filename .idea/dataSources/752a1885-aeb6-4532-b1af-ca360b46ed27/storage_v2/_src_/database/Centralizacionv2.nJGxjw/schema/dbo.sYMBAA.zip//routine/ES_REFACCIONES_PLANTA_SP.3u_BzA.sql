-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 30/06/2016
-- Description:	Teniendo una orden de compra me dice si es PLANTA regresa 1
-- ==========================================================================================
--EXECUTE [dbo].[ES_REFACCIONES_PLANTA_SP] 'AU-ZM-ZAR-RE-PE-89'         --AU-ZM-ZAR-RE-PE-112
CREATE PROCEDURE [dbo].[ES_REFACCIONES_PLANTA_SP]
     @folio		 nvarchar(30)
	,@esPlanta   int = 0 output
AS
BEGIN

	SET NOCOUNT ON;

	BEGIN TRY 
	--DECLARE @cadenaAux      INT = 0	
	DECLARE @ipServidor     VARCHAR(100) = ''
	DECLARE @cadIpServidor  VARCHAR(100) = ''
	DECLARE @nombreBase     VARCHAR(100) = ''
    DECLARE @VarPlantas     TABLE (ID INT IDENTITY(1,1),IDPROVEEDOR int)
    DECLARE @sIpaux         VARCHAR(100) = ''

	DECLARE @IdEmpresa      INT = 0
	DECLARE @IdSucursal     INT = 0
	DECLARE @IdProveedor    INT = 0
	DECLARE @idDepartamento INT = 0

	SELECT @IdEmpresa  = OC.oce_idempresa
		  ,@IdSucursal = OC.oce_idsucursal
		  ,@IdProveedor = OC.oce_idproveedor
		  ,@idDepartamento =OC.oce_iddepartamento
		  FROM cuentasxpagar.dbo.cxp_ordencompra AS OC 
	WHERE OC.oce_folioorden = @folio


    --SI ES REFACCIONES
    IF( SELECT [dep_nombrecto] FROM [ControlAplicaciones].[dbo].[cat_departamentos] WHERE dep_iddepartamento = @idDepartamento) = 'RE'	 
	   BEGIN
			--SI ES PLANTA
			SELECT @nombreBase = [nombre_base]
			      ,@ipServidor = [ip_servidor]
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
			 WHERE [catemp_nombrecto] IN (SELECT [emp_nombrecto]  empNombreCto 
			       						    FROM [ControlAplicaciones].[dbo].[cat_empresas]
										   WHERE [emp_idempresa] = @IdEmpresa)		  
			   AND [catsuc_nombrecto] = (SELECT [suc_nombrecto] sucNombreCto 
			                               FROM [ControlAplicaciones].[dbo].[CAT_SUCURSALES]
										  WHERE suc_idsucursal = @IdSucursal)
            
            
            SELECT @sIpaux=local_net_address --, local_tcp_port
			FROM sys.dm_exec_connections c
			WHERE c.session_id = @@SPID
            
            IF (@sIpaux<>@ipServidor) 
            begin
				SET @cadIpServidor ='['+ @ipServidor +'].' 
            end
            else
            begin
               SET @cadIpServidor =''
            end  
            
            
            --SELECT @nombreBase, @ipServidor,@cadIpServidor
			--SELECT 'SELECT PAR_DESCRIP2 FROM  ' + @cadIpServidor + @nombreBase + '.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ' + '''' + 'PLANTA' + ''''
			
			INSERT INTO @VarPlantas EXECUTE('SELECT PAR_DESCRIP2 FROM  ' + @cadIpServidor + @nombreBase + '.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ' + '''' + 'PLANTA' + '''')

			--SELECT * FROM @VarPlantas
				
			IF EXISTS(SELECT * FROM @VarPlantas WHERE IDPROVEEDOR = @IdProveedor)
			    --'PLANTA'
				BEGIN
				PRINT ('ES REFACCIONES Y ES PLANTA');
				--RETURN 1--SELECT 1 --
					SET @esPlanta = 1 
					RETURN  @esPlanta
				END	
			ELSE
			    --'NO ES PLANTA'
			    BEGIN
				PRINT ('ES REFACCIONES Y NO ES PLANTA');
					SET @esPlanta = 0 
				--SELECT 0 
				--RETURN 0
					RETURN  @esPlanta
				END
	   END
     ELSE 
	    --'NO ES REFACCIONES, NI PLANTA
	    BEGIN
		PRINT ('NO ES PLANTA NI REFACCIONES');
	    --RETURN 0 --
			SET @esPlanta = 0 
			RETURN  @esPlanta 
		END

--SELECT @esPlanta

END	 TRY    
	
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[ES_REFACCIONES_PLANTA_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

