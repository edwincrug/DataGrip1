-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [dbo].[Sp_Documentos_VIN_GETL] 'AU-ZM-NZA-UN-7754'
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Documentos_VINCargaDoc_UPD]
	@Cotizacion VARCHAR(30) = '',
	@No_Serie VARCHAR(30) = '',
	@Doc_Id INT = 0,
	@IdUsuario VARCHAR(10) = ''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Usuario VARCHAR(10) = ( SELECT usu_nombreusu FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @IdUsuario );

	UPDATE 
		DIG_EXPNODO_DOC_FLOT
	SET 
		[Fecha_Creacion] = GETDATE(),
		[Usuario_BPRO] = @Usuario
	WHERE
		[Folio_Operacion] = @Cotizacion
		AND [No_Serie] = @No_Serie
		AND [Doc_Id] = @Doc_Id

	SELECT  1 success
END
go

