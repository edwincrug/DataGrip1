
-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 28/09/2015
-- Description:	Stored de control de excepciones
-- Regresa el número del último registro insertado.
-- =============================================
CREATE PROCEDURE [dbo].[INS_ERROR_SP] 
	@componente		nvarchar(500)
	,@mensaje		nvarchar(max)
AS
BEGIN
DECLARE @parametros  nvarchar(500)
	SET NOCOUNT ON;
BEGIN TRY
-- si el componente es parte de la base de datos obtiene sus parámetros
IF EXISTS (SELECT * FROM sysobjects WHERE name=@componente) 
BEGIN
	SELECT @parametros = COALESCE(@parametros + ', ', '') + PARAMETER_NAME  from INFORMATION_SCHEMA.PARAMETERS Where SPECIFIC_NAME = @componente
END	
ELSE
BEGIN
-- En caso de que el componente no esté en la base de datos ingresa una etiqueta.
SET @parametros = 'Componente externo a BD'
END
INSERT INTO [Centralizacionv2].[dbo].Error (
		componente
		, parametros
		, mensaje
		, fecha) 
		VALUES (
		@componente
		, @parametros
		, @mensaje
		, GETDATE())
--COMMIT TRANSACTION
SELECT @@IDENTITY
END TRY
BEGIN CATCH
SELECT ERROR_MESSAGE(); 
END CATCH
END
go

