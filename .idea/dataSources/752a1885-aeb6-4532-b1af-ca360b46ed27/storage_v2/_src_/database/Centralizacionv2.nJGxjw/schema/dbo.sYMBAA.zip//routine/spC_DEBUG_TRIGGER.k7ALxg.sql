/*



*/

CREATE PROCEDURE [dbo].[spC_DEBUG_TRIGGER](@sFolio_Operacion varchar(50)) --with recompile
 AS
declare
@dFecha_Creacion smalldatetime

begin 
set nocount on

UPDATE cuentasxpagar..cxp_ordencompra set sod_idsituacionorden = 2
where oce_folioorden = @sFolio_Operacion

set nocount off
end

/*

execute spC_DEBUG_TRIGGER 'AU-ZM-ZAR-OT-PE-57'

select * from DIG_ORDENCOMPRAAUX




*/
go

