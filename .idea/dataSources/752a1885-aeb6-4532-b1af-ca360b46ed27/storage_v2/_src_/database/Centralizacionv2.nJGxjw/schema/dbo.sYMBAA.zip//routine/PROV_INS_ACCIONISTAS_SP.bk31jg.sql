CREATE PROCEDURE [dbo].[PROV_INS_ACCIONISTAS_SP]
 @idProspecto INT 
,@nombreAccionista VARCHAR(50)


AS
BEGIN
BEGIN TRY
	INSERT INTO dbo.PROV_ACCIONISTAS
	VALUES ( @idProspecto 
			,@nombreAccionista
		   )

	SELECT 1 result

END TRY
BEGIN CATCH
	SELECT 0 result
END CATCH
END
go

