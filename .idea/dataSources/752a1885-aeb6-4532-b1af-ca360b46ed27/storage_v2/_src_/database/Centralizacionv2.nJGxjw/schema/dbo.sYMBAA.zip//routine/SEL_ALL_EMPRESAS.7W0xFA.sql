-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SEL_ALL_EMPRESAS
AS
BEGIN
	SET NOCOUNT ON;

    SELECT
		nombre_sucursal,
		nombre_base,
		emp_idempresa 
	FROM DIG_CAT_BASES_BPRO WHERE tipo = 2
	ORDER BY 3 ASC
END
go

