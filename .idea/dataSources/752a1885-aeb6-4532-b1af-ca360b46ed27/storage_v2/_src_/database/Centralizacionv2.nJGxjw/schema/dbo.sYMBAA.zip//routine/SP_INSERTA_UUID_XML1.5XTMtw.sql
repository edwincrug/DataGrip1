
CREATE PROCEDURE [dbo].[SP_INSERTA_UUID_XML1]
	@FolioOrden VARCHAR(100)
AS
BEGIN
 SET NOCOUNT ON;
    
 
 DECLARE @Base                 VARCHAR(100);
 DECLARE @ConsultaPoliza       VARCHAR(max)
 DECLARE @ConsultaPolizaCFDI   VARCHAR(max)
 DECLARE @ConsultaConsFac      VARCHAR(max)
 DECLARE @ConsultaConsIva      VARCHAR(max)
 DECLARE @InsertaRegistroFac   VARCHAR(max)
 DECLARE @InsertaRegistroIva   VARCHAR(max)
 
 DECLARE @ImporteOrden         NUMERIC(18,0)
 DECLARE @ImporteIva           NUMERIC(18,0)
 DECLARE @ImporteXML           NUMERIC(18,0)  
 DECLARE @AnioPoliza           VARCHAR(4)
 DECLARE @MesPoliza            VARCHAR(4)
 DECLARE @TipoPoliza           VARCHAR(10)
 DECLARE @NumeroPoliza         VARCHAR(20)
 DECLARE @NumeroPolCons        VARCHAR(20)
 DECLARE @NumeroPolConsFac     VARCHAR(20) 
 DECLARE @NumeroPolConsIva     VARCHAR(20) 
 DECLARE @FacturaFolio         VARCHAR(50) 
 DECLARE @UUID                 VARCHAR(200) 
 DECLARE @IdPersona            VARCHAR(20) 
 DECLARE @RfcPersona           VARCHAR(20) 
 DECLARE @RutaXml              VARCHAR(200) 
 DECLARE @RutaPdf              VARCHAR(200) 
 DECLARE @NombreXml            VARCHAR(200) 
 DECLARE @NombrePdf            VARCHAR(200) 
 
 
   --VALIDA SI EXISTE LA ORDEN DE COMPRA
  --INICIO (1)
  IF (SELECT oce_folioorden FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden) IS NULL 
    BEGIN
     SELECT 'No Existe la Orden de Compra'
     --ENVIA CORREO
    END 
  ELSE
  BEGIN   
  
    --VALIDA SI EXISTE EL XML
    IF (SELECT folioorden FROM PPRO_DATOSFACTURAS WHERE folioorden = @FolioOrden) IS NULL
      BEGIN
       SELECT 'No Existe XML'
       --ENVIA CORREO
      END
    ELSE
    BEGIN
      SET @ImporteOrden = (SELECT ISNULL(oce_imptotalrecibido,0) FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)
      SET @ImporteXML = (SELECT ISNULL(importe,0) FROM PPRO_DATOSFACTURAS WHERE folioorden = @FolioOrden)    
 
      --VALIDA QUE EL IMPORTE SEA DIFERENTE A 0
      IF @ImporteOrden = 0 AND @ImporteXML = 0 
        BEGIN
          SELECT 'EL importe del XML debe ser diferente de 0'  
          --ENVIA CORREO      
        END
      ELSE
      BEGIN 
        --VALIDA QUE LOS IMPORTES SEAN IGUALES
        IF @ImporteOrden <> @ImporteXML 
          BEGIN
            SELECT 'EL importe del XML debe ser Igual al importe de la orden de compra'    
            --ENVIA CORREO    
          END
        ELSE
        BEGIN
          --INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE DONDE SE BUSCARA LA POLIZA
          SET @Base = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
          (SELECT emp_nombrecto FROM ControlAplicaciones.DBO.cat_empresas WHERE emp_idempresa = 
          (SELECT oce_idempresa FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)) AND catsuc_nombrecto = 'CONCENTRA')
          
          --QUERY CONSULTA          
          set @ConsultaPoliza = 'SELECT mre_numeropoliza,mre_tipoliza,mre_anio,mre_mes,mre_movimiento FROM ' + @Base + 
          'con_movimientoreferencia WHERE mre_folioorden = ''' + @FolioOrden + ''' AND mre_tipoliza <> 
          (SELECT DISTINCT(PAR_DESCRIP4) FROM ' + @Base + 'DBO.pnc_parametr WHERE  par_tipopara = ''TRANSBCO'') 
          GROUP BY mre_anio,mre_tipoliza,mre_numeropoliza,mre_mes and mre_conscartera <> 0'
          
          --VERIFICA SI EXISTE LA POLIZA
          DECLARE @Pol TABLE (mre_numeropoliza VARCHAR(MAX),mre_tipoliza VARCHAR(MAX),mre_anio VARCHAR(MAX),mre_mes VARCHAR(MAX),mre_movimiento VARCHAR(MAX) )          
          INSERT INTO @Pol          
          EXEC (@ConsultaPoliza)
          
          IF (SELECT count(mre_numeropoliza) FROM @Pol) = 0
            BEGIN
              SELECT 'No existe la poliza contable de compra'
            END
          ELSE    
          BEGIN      
            --BUSCA EL AÑO
            SET @AnioPoliza = (SELECT mre_anio FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol))
            SET @MesPoliza = (SELECT mre_mes FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol))
            SET @TipoPoliza = (SELECT mre_tipoliza FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol))
            SET @NumeroPoliza = (SELECT mre_numeropoliza FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol))            
            SET @NumeroPolCons = (SELECT mre_movimiento FROM @Pol WHERE mre_movimiento = (SELECT MIN(mre_movimiento) FROM @Pol)) 
          
            SET @ConsultaPolizaCFDI = 'SELECT GFI_CONSPOL FROM ' + @Base + 'CON_GCFDI01' + @AnioPoliza + ' where GFI_TIPOPOL= ''' + @TipoPoliza + ''' and GFI_CONSPOL=' + @NumeroPoliza + 
                ' and GFI_MES=' + @MesPoliza + ' AND GFI_CONSEC = ' + @NumeroPolCons
          
            --VERIFICA SI EXISTE EL REGISTRO
            DECLARE @RegPol TABLE (mre_numeropoliza VARCHAR(MAX))         
            INSERT INTO @RegPol          
            EXEC (@ConsultaPolizaCFDI)
            
            IF (SELECT mre_numeropoliza FROM @RegPol) <> ''
              BEGIN
                SELECT 'Ya existe un registro con esos datos'
              END
            ELSE    
            BEGIN
              --BUSCA DATOS DEL XML EN TABLA DE REGISTRO
              SELECT @FacturaFolio = LTRIM(RTRIM(CONVERT(VARCHAR(20),serie))) + LTRIM(RTRIM(CONVERT(VARCHAR(20),folio))), @UUID = uuid, @RfcPersona = rfc_emisor,
              @RutaXml = 'Z:\' + rfc_emisor, @RutaPdf = 'Z:\' + rfc_emisor, 
              @NombreXml = rfc_emisor + '_' + LTRIM(RTRIM(CONVERT(VARCHAR(20),serie))) + LTRIM(RTRIM(CONVERT(VARCHAR(20),folio))) + '.xml',
              @NombrePdf = rfc_emisor + '_' + LTRIM(RTRIM(CONVERT(VARCHAR(20),serie))) + LTRIM(RTRIM(CONVERT(VARCHAR(20),folio))) + '.pdf',
              @ImporteIva = ISNULL(iva,0)
              FROM PPRO_DATOSFACTURAS WHERE folioorden = @FolioOrden    
      
              --BUSCA ID PERSONA EN LA TABLA DE ORDENES DE COMPRA
              SET @IdPersona = (SELECT oce_idproveedor FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @FolioOrden)
              
              --BUSCA CONSECUTIVO DEL REGISTRO DE LA POLIZA PARA LA FACTURA
              ------------------------------------------------------------------------------------------------------------
              set @ConsultaConsFac = 'SELECT CCP_CONSMOV=MIN(CCP_CONSMOV) FROM ´' + @Base + 'CON_CAR01' + @AnioPoliza + ' WHERE CCP_CONSPOL = ''' + @NumeroPoliza + ''' 
                                      AND CCP_TIPOPOL = ''' + @TipoPoliza + ''' AND CCP_MES = ' + @MesPoliza + ' AND CCP_TIPODOCTO = ''FAC'''
                                      
              DECLARE @PolConsFac TABLE (CCP_CONSMOV VARCHAR(MAX))          
              INSERT INTO @PolConsFac          
              EXEC (@ConsultaConsFac)
              
              set @NumeroPolConsFac = (SELECT CCP_CONSMOV FROM @PolConsFac)
                           
              ------------------------------------------------------------------------------------------------------------
              --BUSCA CONSECUTIVO DEL REGISTRO DE LA POLIZA PARA EL IVA
              
              set @ConsultaConsIva = 'SELECT CCP_CONSMOV=MIN(CCP_CONSMOV) FROM ' + @Base + 'CON_CAR01' + @AnioPoliza + ' WHERE CCP_CONSPOL = ''' + @NumeroPoliza + ''' 
                                      AND CCP_TIPOPOL = ''' + @TipoPoliza + ''' AND CCP_MES = ' + @MesPoliza + ' AND CCP_TIPODOCTO = ''FACIVA'''
                                      
              DECLARE @PolConsIva TABLE (CCP_CONSMOV VARCHAR(MAX))          
              INSERT INTO @PolConsIva          
              EXEC (@ConsultaConsIva)
              
              set @NumeroPolConsIva = (SELECT CCP_CONSMOV FROM @PolConsIva)
              
              ------------------------------------------------------------------------------------------------------------  
              --INSERTA REGSITRO EN LA BASE DE BPRO
              --INSERTA IMPORTE
              
              set @InsertaRegistroFac = 'INSERT INTO ' + @Base + 'CON_GCFDI01' + @AnioPoliza + ' (GFI_TIPOPOL,GFI_CONSPOL,GFI_CONSEC,GFI_MES,GFI_IDDOCTO,
                                      GFI_UUID,GFI_MONTO,GFI_IDPERSONA,GFI_RFC,GFI_RUTAXML,GFI_RUTAPDF,GFI_NOMBREXML,GFI_NOMBREPDF,GFI_ESTATUS,GFI_CVEUSU,
                                      GFI_FECHOPE,GFI_HORAOPE)VALUES(''' + @TipoPoliza + ''',''' + @NumeroPoliza + ''',''' + @NumeroPolConsFac + 
                                      ''',''' + @MesPoliza + ''',''' + @FacturaFolio + ''',''' + @UUID + ''',''' + CONVERT(VARCHAR(20),@ImporteOrden) + ''',''' + @IdPersona +
                                      ''',''' + @RfcPersona + ''',''' + @RutaXml + ''',''' + @RutaPdf + ''',''' + @NombreXml + ''',''' + @NombrePdf + 
                                      ''',''R'',''GMI'',convert(VarChar(10), getdate(), 103),CONVERT(VARCHAR(5), getdate(), 108))'
                            
              EXEC (@InsertaRegistroFac)
              
              --INSERTA IVA
              set @InsertaRegistroFac = 'INSERT INTO ' + @Base + 'CON_GCFDI01' + @AnioPoliza + ' (GFI_TIPOPOL,GFI_CONSPOL,GFI_CONSEC,GFI_MES,GFI_IDDOCTO,
                                      GFI_UUID,GFI_MONTO,GFI_IDPERSONA,GFI_RFC,GFI_RUTAXML,GFI_RUTAPDF,GFI_NOMBREXML,GFI_NOMBREPDF,GFI_ESTATUS,GFI_CVEUSU,
                                      GFI_FECHOPE,GFI_HORAOPE)VALUES(''' + @TipoPoliza + ''',''' + @NumeroPoliza + ''',''' + @NumeroPolConsIva + 
                                      ''',''' + @MesPoliza + ''',''' + @FacturaFolio + ''',''' + @UUID + ''',''' + CONVERT(VARCHAR(20),@ImporteIva) + ''',''' + @IdPersona +
                                      ''',''' + @RfcPersona + ''',''' + @RutaXml + ''',''' + @RutaPdf + ''',''' + @NombreXml + ''',''' + @NombrePdf + 
                                      ''',''R'',''GMI'',convert(VarChar(10), getdate(), 103),CONVERT(VARCHAR(5), getdate(), 108))'
                            
              EXEC (@InsertaRegistroFac)
              
              SELECT '1'
              END
           END
         END              
        END              
    END
  --FIN (1)  
  END
END

go

