
/*
Cada que se ejecuta: 

Busca las bases de DIG_CAT_BASES_BPRO operativas.
Barre una a una estas bases validando si tiene o no la tabla 
si tiene la tabla la respalda en AAPNC_PARAM

declare @iResultado int
Execute [Centralizacionv2].[dbo].[spU_RESPALDA_CXC_SUBTRAMITE_Y_CXC_PROVSUBTRAMITE] @iResultado OUTPUT

select * from sys.databases where nombre = 'GAAA_PERISUR_PNC_PARAMETR_20190319_162829';
select OBJECT_ID('AAPNC_PARAM.dbo.GAAA_PERISUR_PNC_PARAMETR_20190319_162829'); 

*/

CREATE PROCEDURE [dbo].[spU_RESPALDA_CXC_SUBTRAMITE_Y_CXC_PROVSUBTRAMITE](@iResultado int OUTPUT) --with recompile
 AS
declare
@sBase varchar(200),
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@sTabla nvarchar(200),
@sFechaHora nvarchar(30),
@sNombreTablaDestino nvarchar(150)

begin 
set nocount on


CREATE TABLE #BasesDeDatosEnEsteServidor
(
  POSICION [int] IDENTITY (1, 1), 
  nombreBD varchar(300)
)

insert into #BasesDeDatosEnEsteServidor (nombreBD)
SELECT nombre_base FROM Centralizacionv2..DIG_CAT_BASES_BPRO where tipo=1  

Declare @iIndice int = 1;
Declare @iTope int = 0;
Declare @sAuxFecha varchar(10);
Declare @sHoy varchar(10);
Declare @sAnio varchar(4);
Declare @sMes varchar(2);
Declare @sUltimoDiaMesActual varchar(10);

DECLARE @db_id int;  
DECLARE @object_id int;  


declare @mydate datetime
set dateformat dmy;
SELECT @mydate = GETDATE();

select @iTope = Isnull(Max(POSICION),0) from #BasesDeDatosEnEsteServidor

--queda en formato dd/mm/yyyy
SELECT @sAuxFecha = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@mydate))-1),DATEADD(mm,1,@mydate)),103) --, 'Primer día del mes siguiente'
select @sAnio = substring(@sAuxFecha,7,4);
select @sMes = substring(@sAuxFecha,4,2);

--print 'fecha del primer dia del mes siguiente:' + @sAuxFecha
--print 'Anio: ' + @sAnio
--print 'Mes: ' + @sMes

SELECT @sUltimoDiaMesActual = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@mydate))),DATEADD(mm,1,@mydate)),103) --, ultimo día del mes actual
SELECT @sHoy = CONVERT(VARCHAR(25),@mydate,103) --AS Date_Value, 'Hoy' AS Date_Type

			WHILE  (@iIndice <= @iTope)    ---EXISTS (Select * from #Pagas)		
				 begin
						SET ROWCOUNT 1 
			   				Select @sBase=nombreBD FROM #BasesDeDatosEnEsteServidor where POSICION = @iIndice		     						
	  					SET ROWCOUNT 0                               
						Declare @iErrorLocal int = 0;

						SET @db_id = DB_ID(@sBase);  
					    set @sTabla = @sBase + '.dbo.CXC_SUBTRAMITE' 						 
						SET @object_id = OBJECT_ID(@sTabla);  

						IF @db_id IS NULL   
						  BEGIN;  
							--PRINT N'No se encuentra la Base de datos: ' + @sBase; 
							select @iResultado = 1 
						  END;  
						ELSE IF @object_id IS NULL  
						  BEGIN;  
							--PRINT N'La base de datos: ' +  @sBase + ' No tiene la tabla PNC_PARAMETR';  
							select @iResultado = 2
						  END;  
						ELSE  
						  BEGIN; 
						     select @sFechaHora = Convert(char(8),GetDate(),112) + '_' + convert(char(8), getdate(), 108);
							 select @sFechaHora = Replace(@sFechaHora,':',''); 							   
							   --select convert(char(8), getdate(), 108) as [hh:mm:ss];
						     set @sNombreTablaDestino = @sBase + '_CXC_SUBTRAMITE_' + 'RESPALDO_' + @sFechaHora;

						     set @sQ = N'select * into AAPNC_PARAM..' + @sNombreTablaDestino
							 set @sQ = @sQ + N' from ' + @sTabla
							 print @sQ
								--print @sParmDefinition
								--execute sp_executesql @sQ,@sParmDefinition,@ssPAR_IDENPARA = @sPAR_IDENPARA OUTPUT
							 execute sp_executesql @sQ

							 set @sTabla = @sBase + '.dbo.CXC_PROVSUBTRAMITE'
							 set @sNombreTablaDestino = @sBase + '_CXC_PROVSUBTRAMITE_' + 'RESPALDO_' + @sFechaHora;
							 						     set @sQ = N'select * into AAPNC_PARAM..' + @sNombreTablaDestino
							 set @sQ = @sQ + N' from ' + @sTabla 
							 print @sQ
								--print @sParmDefinition
								--execute sp_executesql @sQ,@sParmDefinition,@ssPAR_IDENPARA = @sPAR_IDENPARA OUTPUT
							 execute sp_executesql @sQ

						  END; -- Si tiene la tabla y hay que respaldar  						
						select @iIndice = @iIndice + 1; 		    
				 end -- Del while principal sobre cada Base de Datos.

Return @iResultado
set nocount off
end
go

