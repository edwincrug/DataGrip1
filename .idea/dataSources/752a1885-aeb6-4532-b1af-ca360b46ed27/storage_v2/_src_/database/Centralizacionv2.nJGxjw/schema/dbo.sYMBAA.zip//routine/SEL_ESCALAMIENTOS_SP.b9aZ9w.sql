--EXECUTE [dbo].[SEL_ESCALAMIENTOS_SP] 1,2,2,5,27,0
CREATE PROCEDURE [dbo].[SEL_ESCALAMIENTOS_SP] 
	@procId INT = NULL,
	@usuario_idusuario INT = null,
	@emp_idempresa INT = null,
	@suc_idsucursal INT = null,
	@dep_iddepartamento INT = null,
	@tipo_idtipoorden INT = null
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
				
		SELECT DISTINCT  --die.escalamientoid AS escalamientoId ,		
			  die.Proc_Id
			  ,dig.Proc_Nombre AS procNombre
			  ,die.Nodo_Id AS nodoId
			  ,din.Nodo_Nombre AS nodoNombre 
			  ,dge.emp_idempresa AS empIdempresa
			  ,emp.emp_nombre AS empNombre
			  ,dge.suc_idsucursal AS sucIdsucursal 
			  ,suc.suc_nombre AS sucNombre
			  ,dge.dep_iddepartamento AS depIddepartamento 
			  ,dep.dep_nombre AS depNombre
			  ,dge.tipo_idtipoorden AS tipoidtipoorden 
			  ,occ.tip_nombre AS tipOrden
		 FROM DIG_PERFIL_ESCALAMIENTO AS dge	 
		INNER JOIN [dbo].[DIG_ESCALAMIENTO] AS die ON die.emp_idempresa=@emp_idempresa
		AND die.Proc_Id=@procId
		AND die.suc_idsucursal = @suc_idsucursal
		AND die.dep_iddepartaamento = @dep_iddepartamento
		AND die.tipo_idtipoorden = @tipo_idtipoorden
		INNER JOIN [dbo].[DIG_PROCESO] AS dig ON dig.Proc_Id = die.Proc_Id
		INNER JOIN [dbo].[DIG_NODO] AS din ON din.Nodo_Id = die.Nodo_Id
		AND din.Proc_Id = die.Proc_Id 
		INNER JOIN [dbo].[Empresas_ControlAplicaciones] AS emp ON emp.emp_idempresa = dge.emp_idempresa
		INNER JOIN [dbo].[Sucursale_ControlAplicaciones] AS suc ON suc.suc_idsucursal = dge.suc_idsucursal
		INNER JOIN [dbo].[departamento_ControlAplicaciones] AS dep ON dep.dep_iddepartamento = dge.dep_iddepartamento
		INNER JOIN [dbo].[Tipos_OCCompra_Cuentasxpagar] AS occ ON occ.tip_idtipoorden = dge.tipo_idtipoorden						
		WHERE die.suc_idsucursal = COALESCE(@suc_idsucursal,die.suc_idsucursal)
		AND die.dep_iddepartaamento = COALESCE(@dep_iddepartamento,die.dep_iddepartaamento)
		AND die.tipo_idtipoorden = COALESCE(@tipo_idtipoorden,die.tipo_idtipoorden)
		AND dge.usuario_idusuario = COALESCE(@usuario_idusuario,dge.usuario_idusuario)
		--AND die.Nivel_Escalamiento=0			
		
	END TRY
	BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_EMPLEADO_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	END CATCH
END


go

