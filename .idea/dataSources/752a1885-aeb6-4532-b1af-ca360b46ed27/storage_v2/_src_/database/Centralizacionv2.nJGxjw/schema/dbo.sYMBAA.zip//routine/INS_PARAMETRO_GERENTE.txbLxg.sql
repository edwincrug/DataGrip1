
/*
Upsert en [Centralizacionv2].[dbo].[DIG_CATALOGOS]
el gerente de la empresa|sucursal 
*/


CREATE PROCEDURE [dbo].[INS_PARAMETRO_GERENTE] (@sIdUSR VARCHAR(5),@sNombre_base varchar(50),@sAREAGERENTE varchar(100) ) --with recompile
 As

BEGIN

SET NOCOUNT ON;

DECLARE @sQ nvarchar(1500); 
DECLARE @ipServidor    VARCHAR(100);
DECLARE @ipLocal VARCHAR(50);
DECLARE @emp_idempresa int;
DECLARE @suc_idsucursal int;
DECLARE @sCat_nombre varchar(10);
DECLARE @iCat_id_padre int;
DECLARE @iSiguiente int;

select @ipServidor=ip_servidor, @emp_idempresa =  emp_idempresa  from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] where nombre_base = @sNombre_base
select @suc_idsucursal = suc_idsucursal from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] where nombre_base = @sNombre_base

if (@sAREAGERENTE='NUEVOS')
begin
   select @iCat_id_padre = 87
end
if (@sAREAGERENTE='SERVICIO')
begin
select @iCat_id_padre = 74
end


SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC

if (@ipLocal = @ipServidor)
begin
   select @ipServidor = ''
end
else
	begin
	   select @ipServidor = '[' + @ipServidor + '].'
	end
	
select @sNombre_base = '[' + @sNombre_base + ']'

select @sCat_nombre = ltrim(rtrim(Convert(varchar(3),@emp_idempresa))) + '|' + ltrim(rtrim(Convert(varchar(3),@suc_idsucursal)))


if EXISTS (Select 1  from [Centralizacionv2].[dbo].[DIG_CATALOGOS] where cat_id_padre=@iCat_id_padre and cat_nombre = @sCat_nombre)
begin	
	update [Centralizacionv2].[dbo].[DIG_CATALOGOS] set cat_valor = @sIdUSR
	where cat_id_padre=@iCat_id_padre and cat_nombre = @sCat_nombre
end
else
begin
		Select @iSiguiente = Isnull(MAX(cat_id),0) + 1 from [Centralizacionv2].[dbo].[DIG_CATALOGOS]
		insert into [Centralizacionv2].[dbo].[DIG_CATALOGOS] (cat_id,cat_id_padre,cat_nombre,cat_valor,cat_estatus)
		values (@iSiguiente,@iCat_id_padre,@sCat_nombre,@sIdUSR,1)
end
	set nocount off
END
/*
Declare @sNombre_base Varchar(100);
Declare @sIdUSR varchar(5);
Declare @sAREAGERENTE varchar(100);

select @sNombre_base = 'GAAU_Pedregal' --5|19
select @sIdUSR = '15'
select @sAREAGERENTE = 'NUEVOS' -- 'SERVICIO'

Execute [dbo].[INS_PARAMETRO_GERENTE] @sIdUSR, @sNombre_base, @sAREAGERENTE


------------------------------------------------------------
Select * from [Centralizacionv2].[dbo].[DIG_CATALOGOS] 
where cat_id_padre=87 

select * from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 

---------------------------------------------------------------------------------------
----------------------CONSULTA DE LOS USUARIOS EN BPRO X SU  ACRONIMO DE 3 CARACTERES

Select * from [ControlAplicaciones].[dbo].[cat_usuarios]
where usu_nombreusu = 'MFG'


*/
go

