-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	Obtiene los folios relacionados con los parametros de busqueda enviadas desde la aplciación 
-- =============================================
/*
EXECUTE [dbo].[SEL_ORDENES_FILTROS_V2_SP]  
	@idProceso = 1
	,@tipoBusqueda = 1
	,@folioorden = 'au-au-uni-se-pe-10323'
	,@idusuariosolicitante=71
	,@factura=''
	,@ordenServicio = ''
	,@numeroSerie = '12'
*/
/* EXECUTE [dbo].[SEL_ORDENES_FILTROS_V2_SP]
	@iddepartamento  = 0
	,@iddivision  = 0
	,@idempresa  = 4
	,@idproveedor  = 0
	,@folioorden  = ''
	,@idusuariosolicitante  = 71
	,@estatusorden  = 0
	,@fechaini  = '20200301'
	,@fechafin  = '20200312'
	,@idSucursal  = 6
	,@idTipoOrden  = -1
	,@idProceso    = 2
	,@factura  = ''
	,@numeroSerie  = ''
	,@ordenServicio  = ''
	,@tipoBusqueda  =1
*/
CREATE PROCEDURE [dbo].[SEL_ORDENES_FILTROS_V2_SP]
	@iddepartamento int = 0
	,@iddivision int = 0
	,@idempresa int = 0
	,@idproveedor int = 0
	,@folioorden varchar(50) = ''
	,@idusuariosolicitante int = 0
	,@estatusorden int = 0
	,@fechaini datetime = null
	,@fechafin datetime = null
	,@idSucursal int = 0
	,@idTipoOrden int = -1
	,@idProceso   int = 1
	,@factura NVARCHAR(20) = ''
	,@numeroSerie NVARCHAR(20) = ''
	,@ordenServicio NVARCHAR(20) = ''
	,@tipoBusqueda int =0
AS
BEGIN
	IF(@fechaini = @fechafin)
		BEGIN
			SET @fechaini = @fechaini +' 00:00:00.000'
			SET @fechafin = @fechafin +' 23:59:59.000'
			--SELECT  @fechaini,@fechafin
		END
	IF(@fechaini IS NULL)
		SET @fechaini = '20000101'
	IF(@fechafin IS NULL)
		SET @fechafin = GETDATE()
	----------------------------------------------------
	--Busqueda para Cuentas por Pagar @idProceso = 1
	----------------------------------------------------
	IF(@idProceso = 1)
		BEGIN
			----------------------------------------------------
			--Búsqueda por folio
			----------------------------------------------------
			IF(@tipoBusqueda = 1)
				BEGIN
					PRINT '11 Entre en busqueda por folio'
					----------------------------------------------------
					--Verifico si variable de busqueda viene vacio
					----------------------------------------------------
					IF @folioorden = '' 
					SET @folioorden = 'AU'
					----------------------------------------------------
					--Verifico si el folio enviado obtiene un solo resultado
					----------------------------------------------------
					DECLARE @numeroFolio INT
					SELECT @numeroFolio = COUNT(oce_folioorden) FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_folioorden = @folioorden
					IF(@numeroFolio = 1)
						BEGIN
							PRINT '111 Entre a busqueda exacta'
							----------------------------------------------------
							--Realizo una busqueda general solo por folio y usuario 
							----------------------------------------------------
							SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion
									,OC.oce_idtipoorden  AS tipoorden
									,CONVERT(VARCHAR(20), OC.oce_fechaorden,103)  AS oce_fechaorden
									,SITOR.sod_nombresituacion  AS situacionOrden
									,OC.oce_idproveedor  AS idProveedor
									--,
									,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor --RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor
									,OC.oce_importetotal AS oce_importetotal
									,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
															ELSE 0 
															END AS esPlanta
									,OC.oce_idempresa AS idEmpresa
									,OC.oce_idsucursal AS idSucursal
									,OC.oce_iddepartamento AS idDepartamento
									,EMP.emp_nombre  AS empNombre
									,SUC.suc_nombre AS sucursal
									,DEP.dep_nombre AS depto 
									--,*
							FROM	[DBO].[DIG_EXPEDIENTE] AS  E
									RIGHT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
									INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
									INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER-- ON OC.oce_idproveedor =  PER.PER_IDPERSONA  -- [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor				
							WHERE	OC.oce_folioorden = @folioorden				
						END	
					ELSE
						BEGIN
							PRINT '112 Entre a la búsqueda no exacta'
							----------------------------------------------------
							--Realizo una busqueda general solo por folio y usuario 
							----------------------------------------------------
							IF @iddivision = 0
							SET @iddivision =  null 
							IF @idempresa = 0 
							SET @idempresa = null
							IF @idSucursal = 0 
							SET @idSucursal = null
							IF @iddepartamento = 0 
							SET @iddepartamento = null
							IF @idproveedor = 0 
							SET @idproveedor = null
							IF @idTipoOrden = -1 
							SET @idTipoOrden = null

							-----------------------------------------------------------------
							--Obtengo la empresa y sucursal en las que el usuario tiene permisos 
							--y con los filtros de empresa, sucursal, departamento enviados desde el portal
							-----------------------------------------------------------------
							DECLARE @permisos TABLE (idEmpresa INT, empresa VARCHAR(100),idSucursal INT, sucursal VARCHAR(100), idDepartamento INT, departamento VARCHAR(100))
							INSERT INTO @permisos
							SELECT	DISTINCT EMP.emp_idempresa AS idEmpresa	
									,EMP.emp_nombre AS empNombre   
									,SUC.suc_idsucursal AS idSucursal
									,SUC.suc_nombre AS nomSucursal
									,DEP.dep_iddepartamento
									,DEP.dep_nombre 
							FROM	[ControlAplicaciones].[dbo].[ope_organigrama] AS OPE
									INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS EMP ON EMP.emp_idempresa = OPE.emp_idempresa
									INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] AS SUC ON SUC.suc_idsucursal = OPE.suc_idsucursal
									INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] AS DEP ON DEP.dep_iddepartamento = OPE.dep_iddepartamento
							WHERE	OPE.usu_idusuario = @idusuariosolicitante 
									AND OPE.div_iddivision = COALESCE(@iddivision, OPE.div_iddivision)  
									AND OPE.emp_idempresa = COALESCE(@idempresa, OPE.emp_idempresa) 
									AND OPE.suc_idsucursal = COALESCE(@idSucursal, OPE.suc_idsucursal) 
									AND OPE.dep_iddepartamento = COALESCE(@iddepartamento, OPE.dep_iddepartamento)
							--SELECT	* FROM @permisos

							SELECT	 OC.oce_folioorden AS Folio_Operacion
									,OC.oce_idtipoorden  AS tipoorden
									,CONVERT(VARCHAR(20), OC.oce_fechaorden,103) AS oce_fechaorden
									,SITOR.sod_nombresituacion  AS situacionOrden
									,OC.oce_idproveedor  AS idProveedor
									,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor--
									--, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor
									,OC.oce_importetotal AS oce_importetotal
									,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
															ELSE 0 
															END AS esPlanta
									,OC.oce_idempresa AS idEmpresa
									,OC.oce_idsucursal AS idSucursal
									,OC.oce_iddepartamento AS idDepartamento
									,P.empresa  AS empNombre
									,P.sucursal AS sucursal
									,P.departamento	 AS depto 
									--,*
							FROM	[DBO].[DIG_EXPEDIENTE] AS  E
									RIGHT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
									INNER JOIN  @permisos AS P ON P.idEmpresa = OC.oce_idempresa AND P.idSucursal = OC.oce_idsucursal AND P.idDepartamento = oce_iddepartamento
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
									INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER
									--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor		
							WHERE	OC.oce_folioorden LIKE '%' + @folioorden + '%'
									AND  OC.oce_idproveedor = COALESCE(@idproveedor, OC.oce_idproveedor) 
									AND  OC.oce_idtipoorden = COALESCE(@idTipoOrden, OC.oce_idtipoorden) 
									AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)	
	--AU-ZM-NZA-UN-PE-32	0	14/10/2017	Pagado por TPP	49421	NISSAN MEXICANA SA DE CV	194417.1000000	0	4	6	26	ZARAGOZA MOTRIZ	ZARAGOZA	UNIDADES NUEVAS							
						END
				END
			----------------------------------------------------
			--Búsqueda por factura
			----------------------------------------------------
			IF(@tipoBusqueda = 2)
				BEGIN
					PRINT '12 Entre en busqueda por factura'
					----------------------------------------------------
					--Verifico si variable de busqueda viene vacio
					----------------------------------------------------
					IF @factura = '' 
					SET @factura = null
					----------------------------------------------------
					--Verifico si la factura enviada obtiene un solo resultado
					----------------------------------------------------
					DECLARE @numeroFactura INT
					DECLARE @tablaFactura TABLE(factura VARCHAR(50))
					INSERT INTO @tablaFactura
					SELECT DISTINCT ISNULL(serie,'') + ISNULL(folio,'') FROM [dbo].[PPRO_DATOSFACTURAS] WHERE ISNULL(serie,'') + ISNULL(folio,'') LIKE '%'+ @factura +'%'
					SELECT @numeroFactura = COUNT(factura) FROM @tablaFactura

					DECLARE @foliosFactura TABLE (folio VARCHAR(50))

					IF(@numeroFactura = 1)
						BEGIN
							PRINT '121 Entre a busqueda exacta'
							----------------------------------------------------
							--Busca el o los folio relacionado con la factura
							----------------------------------------------------
							INSERT INTO @foliosFactura
							SELECT folioorden  FROM [dbo].[PPRO_DATOSFACTURAS] WHERE ISNULL(serie,'') + ISNULL(folio,'') =  @factura							
							----------------------------------------------------
							--Realizo una busqueda general solo por folio y usuario 
							----------------------------------------------------
							SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion
									,OC.oce_idtipoorden  AS tipoorden
									,OC.oce_fechaorden  AS oce_fechaorden
									,SITOR.sod_nombresituacion  AS situacionOrden
									,OC.oce_idproveedor  AS idProveedor
									,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor--, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor
									,OC.oce_importetotal AS oce_importetotal
									,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
															ELSE 0 
															END AS esPlanta
									,OC.oce_idempresa AS idEmpresa
									,OC.oce_idsucursal AS idSucursal
									,OC.oce_iddepartamento AS idDepartamento
									,EMP.emp_nombre  AS empNombre
									,SUC.suc_nombre AS sucursal
									,DEP.dep_nombre AS depto 
									--,*
							FROM	[DBO].[DIG_EXPEDIENTE] AS  E
									INNER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
									INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]	
									INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER
									--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor				
							WHERE	E.Folio_Operacion IN (SELECT folio FROM @foliosFactura)
						END
					ELSE
						BEGIN
							PRINT '122 Entre a la búsqueda no exacta'
							----------------------------------------------------
							--Busca el o los folio relacionado con las coincidencias para @numeroSerie
							----------------------------------------------------	
							INSERT INTO @foliosFactura
							SELECT folioorden  FROM [dbo].[PPRO_DATOSFACTURAS] WHERE ISNULL(serie,'') + ISNULL(folio,'') LIKE COALESCE('%'+ @factura + '%',ISNULL(serie,'') + ISNULL(folio,''))
							--SELECT folio FROM @foliosSerie	
							----------------------------------------------------
							--Realizo una busqueda general solo por folio y usuario 
							----------------------------------------------------
							IF @idempresa = 0 
							SET @idempresa = null
							IF @idSucursal = 0 
							SET @idSucursal = null
							IF @iddepartamento = 0 
							SET @iddepartamento = null
							IF @idproveedor = 0 
							SET @idproveedor = null
							IF @idTipoOrden = -1 
							SET @idTipoOrden = null
							SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion
									,OC.oce_idtipoorden  AS tipoorden
									,CONVERT(VARCHAR(20), OC.oce_fechaorden,103)   AS oce_fechaorden
									,SITOR.sod_nombresituacion  AS situacionOrden
									,OC.oce_idproveedor  AS idProveedor
									,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor--, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor
									,OC.oce_importetotal AS oce_importetotal
									,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
															ELSE 0 
															END AS esPlanta
									,OC.oce_idempresa AS idEmpresa
									,OC.oce_idsucursal AS idSucursal
									,OC.oce_iddepartamento AS idDepartamento
									,EMP.emp_nombre  AS empNombre
									,SUC.suc_nombre AS sucursal
									,DEP.dep_nombre AS depto 
									--,*
							FROM	[DBO].[DIG_EXPEDIENTE] AS  E
									INNER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
									INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
									INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor					
							WHERE	
									  OC.oce_idempresa = COALESCE(@idempresa, OC.oce_idempresa)
									AND  OC.oce_idsucursal = COALESCE(@idSucursal, OC.oce_idsucursal)
									AND E.Folio_Operacion IN (SELECT folio FROM @foliosFactura)	
									AND  OC.oce_iddepartamento = COALESCE(@iddepartamento, OC.oce_iddepartamento)
									AND  OC.oce_idproveedor = COALESCE(@idproveedor, OC.oce_idproveedor) 
									AND  OC.oce_idtipoorden = COALESCE(@idTipoOrden, OC.oce_idtipoorden) 
									--AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
						END
				END
			----------------------------------------------------
			--Búsqueda por numero de serie
			----------------------------------------------------
			IF(@tipoBusqueda = 3)
				BEGIN
					PRINT '13 Entre en busqueda por numero de serie'
					----------------------------------------------------
					--Verifico si variable de busqueda viene vacio
					----------------------------------------------------
					IF @numeroSerie = '' 
					SET @numeroSerie = null
					----------------------------------------------------
					--Verifico si el el número de serie enviado obtiene un solo resultado
					----------------------------------------------------
					DECLARE @numeroSerieN INT, @numeroSerieSn INT
					DECLARE @tablaNumeroSerie TABLE(numero VARCHAR(50))
					INSERT INTO @tablaNumeroSerie
					SELECT anu_numeroserie FROM	[cuentasxpagar].[dbo].[cxp_detalleautosnuevos] AS dn where anu_numeroserie = @numeroSerie GROUP BY anu_numeroserie
					INSERT INTO @tablaNumeroSerie
					SELECT asn_numeroserie FROM	[cuentasxpagar].[dbo].[cxp_detalleseminuevos] WHERE asn_numeroserie =  @numeroSerie	GROUP BY asn_numeroserie
					SELECT @numeroSerieN = COUNT(numero) FROM @tablaNumeroSerie	
		
					DECLARE @foliosSerie TABLE (folio VARCHAR(50))
		
					IF(@numeroSerieN = 1 OR @numeroSerieSn = 1)
						BEGIN 
							PRINT '131 Entre a busqueda exacta'
							----------------------------------------------------
							--Busca el o los folio relacionado con el numero de serie @numeroSerie
							----------------------------------------------------
							INSERT INTO @foliosSerie				
							SELECT oce_folioorden FROM	[cuentasxpagar].[dbo].[cxp_detalleautosnuevos] AS dn where anu_numeroserie = @numeroSerie
							INSERT INTO @foliosSerie				
							SELECT oce_folioorden FROM	[cuentasxpagar].[dbo].[cxp_detalleseminuevos] WHERE asn_numeroserie =  @numeroSerie
							--SELECT folio FROM @foliosSerie							
							----------------------------------------------------
							--Realizo una busqueda general solo por folio y usuario 
							----------------------------------------------------
							SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion
									,OC.oce_idtipoorden  AS tipoorden
									,CONVERT(VARCHAR(20), OC.oce_fechaorden,103)   AS oce_fechaorden
									,SITOR.sod_nombresituacion  AS situacionOrden
									,OC.oce_idproveedor  AS idProveedor
									,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor--, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor
									,OC.oce_importetotal AS oce_importetotal
									,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
															ELSE 0 
															END AS esPlanta
									,OC.oce_idempresa AS idEmpresa
									,OC.oce_idsucursal AS idSucursal
									,OC.oce_iddepartamento AS idDepartamento
									,EMP.emp_nombre  AS empNombre
									,SUC.suc_nombre AS sucursal
									,DEP.dep_nombre AS depto 
									--,*
							FROM	[DBO].[DIG_EXPEDIENTE] AS  E
									INNER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
									INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]	
									INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor				
							WHERE	E.Folio_Operacion IN (SELECT folio FROM @foliosSerie)
								
						END	
					ELSE
						BEGIN
							PRINT '132 Entre a la búsqueda no exacta'
							----------------------------------------------------
							--Busca el o los folio relacionado con las coincidencias para @numeroSerie
							----------------------------------------------------	
							INSERT INTO @foliosSerie				
							SELECT oce_folioorden FROM	[cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where anu_numeroserie LIKE COALESCE('%' + @numeroSerie + '%',anu_numeroserie)
							INSERT INTO @foliosSerie				
							SELECT oce_folioorden FROM	[cuentasxpagar].[dbo].[cxp_detalleseminuevos] WHERE asn_numeroserie LIKE COALESCE('%' + @numeroSerie + '%',asn_numeroserie)
							--SELECT folio FROM @foliosSerie	
							----------------------------------------------------
							--Realizo una busqueda general solo por folio y usuario 
							----------------------------------------------------
							IF @idempresa = 0 
							SET @idempresa = null
							IF @idSucursal = 0 
							SET @idSucursal = null
							IF @iddepartamento = 0 
							SET @iddepartamento = null
							IF @idproveedor = 0 
							SET @idproveedor = null
							IF @idTipoOrden = -1 
							SET @idTipoOrden = null
							SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion
									,OC.oce_idtipoorden  AS tipoorden
									,CONVERT(VARCHAR(20), OC.oce_fechaorden,103)   AS oce_fechaorden
									,SITOR.sod_nombresituacion  AS situacionOrden
									,OC.oce_idproveedor  AS idProveedor
									,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor--, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor
									,OC.oce_importetotal AS oce_importetotal
									,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
															ELSE 0 
															END AS esPlanta
									,OC.oce_idempresa AS idEmpresa
									,OC.oce_idsucursal AS idSucursal
									,OC.oce_iddepartamento AS idDepartamento
									,EMP.emp_nombre  AS empNombre
									,SUC.suc_nombre AS sucursal
									,DEP.dep_nombre AS depto 
									--,*
							FROM	[DBO].[DIG_EXPEDIENTE] AS  E
									INNER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
									INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
									INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor				
							WHERE	E.Folio_Operacion IN (SELECT folio FROM @foliosSerie)	
									AND  OC.oce_idempresa = COALESCE(@idempresa, OC.oce_idempresa)
									AND  OC.oce_idsucursal = COALESCE(@idSucursal, OC.oce_idsucursal)
									AND  OC.oce_iddepartamento = COALESCE(@iddepartamento, OC.oce_iddepartamento)
									AND  OC.oce_idproveedor = COALESCE(@idproveedor, OC.oce_idproveedor) 
									AND  OC.oce_idtipoorden = COALESCE(@idTipoOrden, OC.oce_idtipoorden) 
									AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)	
						END					
				END	
			----------------------------------------------------
			--Búsqueda por ORden de Servicio
			----------------------------------------------------
			IF(@tipoBusqueda = 4)
				BEGIN
					PRINT '14 Entre en busqueda por orden de servicio'
					----------------------------------------------------
					--Verifico si variable de busqueda viene vacio
					----------------------------------------------------
					IF @ordenServicio = '' 
					SET @ordenServicio = null
					----------------------------------------------------
					--Verifico si el número de orden enviado obtiene un solo resultado
					----------------------------------------------------
					DECLARE @numeroSErvicio INT
					DECLARE @tablaSErvicio TABLE(numero VARCHAR(50))
					INSERT INTO @tablaSErvicio
					SELECT DISTINCT ser_ordenservicio FROM	[cuentasxpagar].[dbo].[cxp_detalleservicio] WHERE ser_ordenservicio = @ordenServicio 
					SELECT @numeroSErvicio = COUNT(numero) FROM @tablaSErvicio	
					--SELECT @numeroSErvicio
					DECLARE @foliosServicios TABLE (folio VARCHAR(50))
					IF(@numeroSErvicio = 1)
						BEGIN
							PRINT '141 Entre a busqueda exacta'
							----------------------------------------------------
							--Busca el o los folio relacionado con la orden de servicio @numeroSerie
							----------------------------------------------------
							INSERT INTO @foliosServicios				
							SELECT oce_folioorden FROM [cuentasxpagar].[dbo].[cxp_detalleservicio] WHERE ser_ordenservicio = @ordenServicio						
							----------------------------------------------------
							--Realizo una busqueda general solo por folio y usuario 
							----------------------------------------------------
							SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion
									,OC.oce_idtipoorden  AS tipoorden
									,CONVERT(VARCHAR(20), OC.oce_fechaorden,103)   AS oce_fechaorden
									,SITOR.sod_nombresituacion  AS situacionOrden
									,OC.oce_idproveedor  AS idProveedor
									,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor--, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor
									,OC.oce_importetotal AS oce_importetotal
									,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
															ELSE 0 
															END AS esPlanta
									,OC.oce_idempresa AS idEmpresa
									,OC.oce_idsucursal AS idSucursal
									,OC.oce_iddepartamento AS idDepartamento
									,EMP.emp_nombre  AS empNombre
									,SUC.suc_nombre AS sucursal
									,DEP.dep_nombre AS depto 
									--,*
							FROM	[DBO].[DIG_EXPEDIENTE] AS  E
									INNER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
									INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]	
									INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor						
							WHERE	E.Folio_Operacion IN (SELECT folio FROM @foliosServicios)
						END
					ELSE
						BEGIN
							PRINT '142 Entre a la búsqueda no exacta'
							----------------------------------------------------
							--Busca el o los folio relacionado con las coincidencias para @ordenServicio
							----------------------------------------------------	
							INSERT INTO @foliosServicios				
							SELECT oce_folioorden FROM [cuentasxpagar].[dbo].[cxp_detalleservicio] WHERE ser_ordenservicio LIKE COALESCE('%'+ @ordenServicio + '%',ser_ordenservicio)
							--SELECT folio FROM @foliosSerie	
							----------------------------------------------------
							--Realizo una busqueda general solo por folio y usuario 
							----------------------------------------------------
							IF @idempresa = 0 
							SET @idempresa = null
							IF @idSucursal = 0 
							SET @idSucursal = null
							IF @iddepartamento = 0 
							SET @iddepartamento = null
							IF @idproveedor = 0 
							SET @idproveedor = null
							IF @idTipoOrden = -1 
							SET @idTipoOrden = null
							SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion
									,OC.oce_idtipoorden  AS tipoorden
									,CONVERT(VARCHAR(20), OC.oce_fechaorden,103) AS oce_fechaorden
									,SITOR.sod_nombresituacion  AS situacionOrden
									,OC.oce_idproveedor  AS idProveedor
									,RTRIM(LTRIM(PER.PER_NOMRAZON  + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor--, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor
									,OC.oce_importetotal AS oce_importetotal
									,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
															ELSE 0 
															END AS esPlanta
									,OC.oce_idempresa AS idEmpresa
									,OC.oce_idsucursal AS idSucursal
									,OC.oce_iddepartamento AS idDepartamento
									,EMP.emp_nombre  AS empNombre
									,SUC.suc_nombre AS sucursal
									,DEP.dep_nombre AS depto 
									--,*
							FROM	[DBO].[DIG_EXPEDIENTE] AS  E
									INNER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] AS OC ON E.Folio_Operacion = OC.oce_folioorden
									INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
									INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
									INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON OC.oce_idproveedor =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(OC.oce_idproveedor,OC.oce_idempresa) PER--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor										
							WHERE	E.Folio_Operacion IN (SELECT folio FROM @foliosServicios)	
									AND  OC.oce_idempresa = COALESCE(@idempresa, OC.oce_idempresa)
									AND  OC.oce_idsucursal = COALESCE(@idSucursal, OC.oce_idsucursal)
									AND  OC.oce_iddepartamento = COALESCE(@iddepartamento, OC.oce_iddepartamento)
									AND  OC.oce_idproveedor = COALESCE(@idproveedor, OC.oce_idproveedor) 
									AND  OC.oce_idtipoorden = COALESCE(@idTipoOrden, OC.oce_idtipoorden) 
									AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)	
						END
				END

		END
	----------------------------------------------------
	--Busqueda para Cuentas por Cobrar @idProceso = 2
	----------------------------------------------------	
	IF(@idProceso = 2)
		BEGIN

		IF(@tipoBusqueda = 3)
			BEGIN
				SELECT  
					E.Folio_Operacion    AS Folio_Operacion
					,'N/A'               AS tipoorden
					,CONVERT(VARCHAR(20), O.ucu_fechacotiza,103)    AS oce_fechaorden
					,ST.cec_nombre AS situacionOrden
					--,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
					--	FROM BDPersonas.dbo.cat_personas AS PER 
					--	WHERE PER.per_idpersona = O.ucu_idcliente) AS Proveedor   --NombreCliente
					,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor
					,EM.emp_nombre     AS empNombre
					,S.suc_nombre      AS sucursal
					,D.dep_nombre      AS depto
					--,350000.00  AS oce_importetotal
					,SUM(CD.ucn_total)  AS oce_importetotal
					,O.ucu_idcliente   AS esPlanta            --idCliente para CXC
					,1                 AS nodoactual          --NodoAcutal
					,1                 AS tipofolio
				FROM  dbo.DIG_EXPEDIENTE AS E 
				INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
				INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON CD.ucu_idcotizacion = O.ucu_idcotizacion
				INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
				INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
				INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
				INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
				INNER JOIN cuentasporcobrar.dbo.cat_estatuscotiza AS ST ON  ST.cec_idestatuscotiza = O.cec_idestatuscotiza
				INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON O.ucu_idcliente =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(O.ucu_idcliente,EM.emp_idempresa) PER--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor						
				WHERE CD.ucn_noserie = @numeroSerie --AND O.ucu_tipoventaunidad = 'UN'
				GROUP BY Folio_Operacion, O.ucu_fechacotiza, EM.emp_nombre, S.suc_nombre, D.dep_nombre, O.ucu_idcliente,ST.cec_nombre, PER.PER_NOMRAZON, PER.PER_PATERNO, PER.PER_MATERNO--,PER.Persona
			END
		ELSE
			BEGIN
				----------------------------------------------------
				--Verifico si variable de busqueda viene vacio
				----------------------------------------------------
				IF @folioorden = '' 
				SET @folioorden = 'AU'
				----------------------------------------------------
				--Verifico si el folio enviado obtiene un solo resultado
				----------------------------------------------------
				DECLARE @numeroCotizacion INT
				SELECT @numeroCotizacion = COUNT(ucu_foliocotizacion) FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE ucu_foliocotizacion = @folioorden 
				IF(@numeroCotizacion = 1)
					BEGIN
						PRINT '2 Entre a busqueda exacta'
						----------------------------------------------------
						--Realizo una busqueda general solo por folio y usuario 
						----------------------------------------------------
						SELECT  E.Folio_Operacion    AS Folio_Operacion
								,'N/A'               AS tipoorden
								,CONVERT(VARCHAR(20), O.ucu_fechacotiza,103)    AS oce_fechaorden
								,ST.cec_nombre AS situacionOrden
								--,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
								--	FROM BDPersonas.dbo.cat_personas AS PER 
								--	WHERE PER.per_idpersona = O.ucu_idcliente) AS Proveedor   --NombreCliente
								,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor
								,EM.emp_nombre     AS empNombre
								,S.suc_nombre      AS sucursal
								,D.dep_nombre      AS depto
								--,350000.00  AS oce_importetotal
								,SUM(CD.ucn_total)  AS oce_importetotal
								,O.ucu_idcliente   AS esPlanta            --idCliente para CXC
								,1                 AS nodoactual          --NodoAcutal
								,1                 AS tipofolio
							FROM  dbo.DIG_EXPEDIENTE AS E 
								INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
								INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON CD.ucu_idcotizacion = O.ucu_idcotizacion
								INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
								INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
								INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
								INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
								INNER JOIN cuentasporcobrar.dbo.cat_estatuscotiza AS ST ON  ST.cec_idestatuscotiza = O.cec_idestatuscotiza
								INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON O.ucu_idcliente =  PER.PER_IDPERSONA--CROSS APPLY fn_ObtenerProveedor(O.ucu_idcliente,EM.emp_idempresa) PER--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS PER ON PER.per_idpersona = OC.oce_idproveedor						
							WHERE   E.Folio_Operacion = @folioorden 
						GROUP BY Folio_Operacion, O.ucu_fechacotiza, EM.emp_nombre, S.suc_nombre, D.dep_nombre, O.ucu_idcliente,ST.cec_nombre, PER.PER_NOMRAZON, PER.PER_PATERNO, PER.PER_MATERNO--,PER.Persona
					END
				ELSE
					BEGIN
						PRINT '222 Entre a la búsqueda no exacta'
						----------------------------------------------------
						--Realizo una busqueda general solo por folio y usuario 
						----------------------------------------------------
						IF @idempresa = 0 
						SET @idempresa = null
						IF @idSucursal = 0 
						SET @idSucursal = null
						IF @iddepartamento = 0 
						SET @iddepartamento = null
						IF @idproveedor = 0 
						SET @idproveedor = null
						IF @idTipoOrden = -1 
						SET @idTipoOrden = null
						IF @numeroSerie = ''
						SET @numeroSerie = null
						----------------------------------------------------
						--Busqueda con filtros
						----------------------------------------------------
						if len(@numeroSerie)>5
						begin
						SELECT  E.Folio_Operacion    AS Folio_Operacion
								,'N/A'               AS tipoorden
								,CONVERT(VARCHAR(20), O.ucu_fechacotiza,103) AS oce_fechaorden
								,ST.cec_nombre AS situacionOrden
								--,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
								--	FROM BDPersonas.dbo.cat_personas AS PER 
								--	WHERE PER.per_idpersona = O.ucu_idcliente) AS Proveedor   --NombreCliente
								,EM.emp_nombre     AS empNombre
								,S.suc_nombre      AS sucursal
								,D.dep_nombre      AS depto
								--,350000.00  AS oce_importetotal
								,SUM(CD.ucn_total)  AS oce_importetotal
								,O.ucu_idcliente   AS esPlanta            --idCliente para CXC
								,1                 AS nodoactual          --NodoAcutal
								,1                 AS tipofolio
								,ucn_noserie
							FROM  dbo.DIG_EXPEDIENTE AS E 
								INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
								INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON CD.ucu_idcotizacion = O.ucu_idcotizacion
								INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
								INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
								INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
								INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
								INNER JOIN cuentasporcobrar.dbo.cat_estatuscotiza AS ST ON  ST.cec_idestatuscotiza = O.cec_idestatuscotiza
							WHERE   E.Folio_Operacion LIKE '%' + @folioorden + '%' AND
									O.ucu_idempresa = COALESCE(@idempresa, O.ucu_idempresa)
									AND  O.ucu_idsucursal = COALESCE(@idSucursal, O.ucu_idsucursal)
									AND  O.ucu_iddepartamento = COALESCE(@iddepartamento, O.ucu_iddepartamento)
									AND  O.ucu_idcliente = COALESCE(@idproveedor, O.ucu_idcliente) 
									AND (O.ucu_fechacotiza BETWEEN @fechaini AND @fechafin)
									and cd.ucn_noserie  like '%'+@numeroSerie 
						GROUP BY Folio_Operacion, O.ucu_fechacotiza, EM.emp_nombre, S.suc_nombre, D.dep_nombre, O.ucu_idcliente,ST.cec_nombre,ucn_noserie
						end
						else
						begin
						SELECT  E.Folio_Operacion    AS Folio_Operacion
								,'N/A'               AS tipoorden
								,CONVERT(VARCHAR(20), O.ucu_fechacotiza,103) AS oce_fechaorden
								,ST.cec_nombre AS situacionOrden
								--,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
								--	FROM BDPersonas.dbo.cat_personas AS PER 
								--	WHERE PER.per_idpersona = O.ucu_idcliente) AS Proveedor   --NombreCliente
								,EM.emp_nombre     AS empNombre
								,S.suc_nombre      AS sucursal
								,D.dep_nombre      AS depto
								--,350000.00  AS oce_importetotal
								,SUM(CD.ucn_total)  AS oce_importetotal
								,O.ucu_idcliente   AS esPlanta            --idCliente para CXC
								,1                 AS nodoactual          --NodoAcutal
								,1                 AS tipofolio
								,ucn_noserie       AS noserie
							FROM  dbo.DIG_EXPEDIENTE AS E 
								INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
								INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON CD.ucu_idcotizacion = O.ucu_idcotizacion
								INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
								INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
								INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
								INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
								INNER JOIN cuentasporcobrar.dbo.cat_estatuscotiza AS ST ON  ST.cec_idestatuscotiza = O.cec_idestatuscotiza
							WHERE   E.Folio_Operacion LIKE '%' + @folioorden + '%' AND
									O.ucu_idempresa = COALESCE(@idempresa, O.ucu_idempresa)
									AND  O.ucu_idsucursal = COALESCE(@idSucursal, O.ucu_idsucursal)
									AND  O.ucu_iddepartamento = COALESCE(@iddepartamento, O.ucu_iddepartamento)
									AND  O.ucu_idcliente = COALESCE(@idproveedor, O.ucu_idcliente) 
									AND (O.ucu_fechacotiza BETWEEN @fechaini AND @fechafin)
									and cd.ucn_noserie =  COALESCE(@numeroSerie, cd.ucn_noserie) 
						GROUP BY Folio_Operacion, O.ucu_fechacotiza, EM.emp_nombre, S.suc_nombre, D.dep_nombre, O.ucu_idcliente,ST.cec_nombre,ucn_noserie
						end
					END
		END
	END
END

go

