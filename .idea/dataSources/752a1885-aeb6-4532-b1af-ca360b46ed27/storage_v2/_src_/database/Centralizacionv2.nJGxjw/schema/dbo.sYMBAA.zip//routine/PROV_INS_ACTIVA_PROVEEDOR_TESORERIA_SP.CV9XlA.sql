---- PROV_INS_ACTIVA_PROVEEDOR_SP 7,71,7
CREATE PROCEDURE [dbo].[PROV_INS_ACTIVA_PROVEEDOR_TESORERIA_SP]
@idProspecto INT 
,@idUsuario INT 
,@idPerTra INT
AS
BEGIN
--DECLARE  @idProspecto INT  = 289
--		,@idUsuario INT  = 342
--		,@idPerTra INT = 1163

BEGIN TRY
BEGIN TRANSACTION



	DECLARE  @sql VARCHAR(max)
		,@bd VARCHAR(100)
		,@idPersona NUMERIC(18,0)
		,@usuario VARCHAR(10)
		,@usuarioCorreoAutoriza VARCHAR(250)
		, @cuentaBancaria VARCHAR (500)
		,@portal	INT = 0
	
		DECLARE @provBanco TABLE (
				id int identity(1,1),
				[idProspecto] [int] NULL,
				[titular] [varchar](100) NULL,
				[banco] [varchar](50) NULL,
				[sucursal] [varchar](50) NULL,
				[noCuenta] [varchar](30) NULL,
				[clabe] [varchar](30) NULL,
				[cie] [varchar](10) NULL,
				[referencia] [varchar](50) NULL,
				[cveBanxico] [varchar](10) NULL,
				[cveBanco] [varchar](50) NULL,
				[tipoCtaBancaria] [varchar](20) NULL,
				[nombreTipoCtaBancaria] [varchar](50) NULL,
				[empresaId] [int] NULL
							)
	/***************UNIFICAR CUENTAS*******************************/
	DECLARE @BASES TABLE(id int identity(1,1),emp_idempresa INT,base nvarchar(200))
	
	DECLARE @contBases INT = 1, @numRegistros INT = 0, @contBancos INT = 1, @banxico VARCHAR(20), @numRegistrosCuentas INT = 0, @cveBanco VARCHAR(10) = '',@emp_idempresa INT,  @idRespuestaUni   INT, @cie VARCHAR(50), @noCuenta VARCHAR(50)
	DECLARE @basePrincipal VARCHAR(50) = '', @queryCuentaSel NVARCHAR(MAX) = '', @queryBanco NVARCHAR(MAX) = '', @SQLString NVARCHAR(MAX), @sqlUni VARCHAR(MAX)
	DECLARE @ParmDefinition nvarchar(500) 
	DECLARE @rfcProspecto VARCHAR(20) = (select PER_RFC from DBO.PROV_PROSPECTO where PER_IDPERSONA = @idProspecto)



	  DECLARE @cont INT = 1
				, @idRespuesta   NUMERIC(18,0)
				, @msg VARCHAR(MAX) = ''
				, @cuenta VARCHAR(500)
			    ,@usuario_Autoriza INT
	
	


	
	INSERT INTO @BASES
	SELECT emp_idempresa ,nombre_base  FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 

	SET @numRegistros = (select COUNT(1) from @BASES)

	SELECT @portal = portal FROM PROV_PROSPECTO WHERE PER_IDPERSONA = @idProspecto
	--select @portal
	--SELECT  @usuario = usu_nombreusu 
	--	FROM	ControlAplicaciones.dbo.Cat_usuarios 
	--	WHERE	usu_idusuario  = @idUsuario

   select  @usuario = eqv_usubusiness  from controlAplicaciones.dbo.eqv_organigrama where usu_usuario = @idUsuario
		


	IF (@portal = 1)
	BEGIN
	
	

		--select @rfcProspecto
		--SELECT  PER_IDPERSONA,* FROM GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfc
		SELECT  @idPersona = PER_IDPERSONA FROM GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfcProspecto 
		--select @idPersona

		
		INSERT INTO @provBanco
		SELECT 
			  [idProspecto]
			  ,[titular]
			  ,[banco]
			  ,[sucursal]
			  ,[noCuenta]
			  ,[clabe]
			  ,[cie]
			  ,[referencia]
			  ,[cveBanxico]
			  ,[cveBanco]
			  ,[tipoCtaBancaria]
			  ,[nombreTipoCtaBancaria]
			  ,[empresaId]
		  FROM [dbo].[PROV_CUENTA_BANCARIA]
		  WHERE (idProspecto = @idProspecto OR rfcProspecto = @rfcProspecto) AND aprobada is null AND idPerTra = @idPerTra

		  
		  
		   SET  @numRegistrosCuentas = (select  COUNT(1) from @provBanco)


		  WHILE(@contBancos<= @numRegistrosCuentas)
		  BEGIN
		--	SELECT @contBancos '@contBancos'
			SET @contBases  = 1
				select @banxico = cveBanxico, @cie = cie, @noCuenta = noCuenta FROM @provBanco WHERE id = @contBancos
				--select @banxico, @cie, @noCuenta
				
				WHILE(@contBases<= @numRegistros)
				BEGIN
				
					
					SELECT @basePrincipal = base, @emp_idempresa = emp_idempresa FROM @BASES WHERE id = @contBases
					--	select @basePrincipal
					IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @basePrincipal)) 
					BEGIN
						--SELECT @basePrincipal
						SET @cveBanco = ''
						SET @SQLString = 'IF EXISTS (SELECT 1 from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''') BEGIN  SELECT @res = PAR_IDENPARA from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''' END '
						SET @ParmDefinition = N' @res  VARCHAR(10) OUTPUT'; 
						--select * from GAAU_Concentra.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = 'BA' AND PAR_STATUS = 'A' AND PAR_DESCRIP5 = '044'
						
						
						EXECUTE sp_executesql @SQLString, @ParmDefinition, @res= @cveBanco OUTPUT
						--select @cveBanco 'clave' 
						
						IF( @cveBanco != '')
						BEGIN
						--	select 'Entre'

						--select @idPerTra, @idPersona, @usuario,@idProspecto
							
							SET @sqlUni = ' IF EXISTS(SELECT 1 FROM '+@basePrincipal+'.[dbo].[CON_BANCOS] WHERE BCO_NUMCUENTA ='''+ @noCuenta+''' AND BCO_IDPERSONA = '+CONVERT(VARCHAR(10),@idPersona)+')
											BEGIN 
												UPDATE  ' +@basePrincipal+'.[dbo].[CON_BANCOS] SET 
													  BCO_AUTORIZADA = 1
													, BCO_CVEUSU = ''' + @usuario+ '''
													, BCO_FECHOPE = CONVERT(VARCHAR(10), GETDATE(),103)
													, BCO_HORAOPE = CONVERT(CHAR(8), GETDATE(), 108)    
												WHERE  BCO_NUMCUENTA ='''+ @noCuenta+''' AND BCO_IDPERSONA = '+CONVERT(VARCHAR(10),@idPersona)+'
											END
											ELSE
											BEGIN
							
											INSERT INTO ' +@basePrincipal+'.[dbo].[CON_BANCOS]
													 ([BCO_IDPERSONA]
													 ,[BCO_BANCO]
													 ,[BCO_PLAZA]
													 ,[BCO_SUCURSAL]
													 ,[BCO_STATUS]
													 ,[BCO_TIPCUENTA]
													 ,[BCO_NUMCUENTA]
													 ,[BCO_CLABE]
													 ,[BCO_CVEUSU]
													 ,[BCO_FECHOPE]
													 ,[BCO_HORAOPE]
													 ,[BCO_REFERNUM]
													 ,[BCO_REFERALF]
													 ,[BCO_CONVENIOCIE]
													 ,[BCO_AUTORIZADA]) 
									   	SELECT '+ CONVERT(VARCHAR(10),@idPersona)+ '
												,'''+@cveBanco+'''
												,''1''
												,ISNULL(sucursal,''1'')
												,''ACTIVO''
												,tipoCtaBancaria
												,noCuenta
												,clabe
												,''' + @usuario+ '''
												,CONVERT(VARCHAR(10), GETDATE(),103)
												,CONVERT(CHAR(8), GETDATE(), 108) 
												,ISNULL(referencia,'''')
												,''''
												,cie
												,1 
										FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
										INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO]  PP ON PP.PER_RFC  = CB.rfcProspecto    
										WHERE CB.cveBanxico = '''+ @banxico +''' AND idPerTra = '+CONVERT(VARCHAR(10),@idPerTra)+' END' --+' AND PP.PER_IDPERSONA = '+ CONVERT(VARCHAR(10),@idProspecto)  

							print @sqlUni 
							EXEC (@sqlUni)
						--	SELECT @emp_idempresa

						--select * from GAAU_Concentra.dbo.CON_BANCOS where BCO_IDPERSONA = @idPersona
						
							EXEC Pagos.[dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP] @idProveedor =@idPersona , @cuenta =@noCuenta ,	@convenio = @cie, @idEmpresa =  @emp_idempresa,@idUsuario = @idUsuario, @result = @idRespuestaUni OUTPUT
							--SELECT @idRespuestaUni 'Unifica'
							--select * from GAZM_Concentra.dbo.CON_BANCOS where BCO_IDPERSONA = 446278
							SET	@contBases = @numRegistros + 1
						END
						ELSE 
						BEGIN
							SET @contBases= @contBases+1  
						END
					END
						BEGIN
							SET @contBases= @contBases+1 
						END
				END
				SET @contBancos = @contBancos+1
		  END

		 

		  UPDATE [dbo].[PROV_PROSPECTO] 
		  SET PER_IDPERSONA_GA = @idPersona
		  WHERE PER_IDPERSONA = @idProspecto

		


		   UPDATE PROV_CUENTA_BANCARIA 
     		  SET	aprobada = 1
	     			,autorizada = 1
					,PER_IDPERSONA = @idPersona
		   WHERE --idProspecto= @idProspecto
		    idPerTra = @idPerTra 

			

		   


		  declare @nombreProveedor VARCHAR(100) = (SELECT TOP 1 'Proveedor: '+ ISNULL(PER_NOMRAZON,'')+' '+ ISNULL(PER_PATERNO,'')+ ' '+ ISNULL(PER_MATERNO,'') + ' RFC : '+ ISNULL(PER_RFC,'') from 	 GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfcProspecto)
				,@email VARCHAR(100) = (SELECT correo FROM CENTRALIZACIONv2.DBO.PPRO_USERSPORTALPROV WHERE ppro_user in (select PER_RFC from DBO.PROV_PROSPECTO where PER_IDPERSONA = @idProspecto))
				
			--SELECT @email

		SELECT	 @usuario_Autoriza= usuario_autoriza
				,@usuarioCorreoAutoriza = usu_correo 
		FROM	Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION N 
		INNER JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT F ON N.idTipoNotificacion = F.idTipoNotificacion
		INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = F.usuario_autoriza
		WHERE	N.idTipoNotificacion = 4 
		AND		nivel_escalamiento = 0
				


		SELECT 1 result, @rfcProspecto RFC, @email correo,'' token, @usuarioCorreoAutoriza correoAutorizaCuentas ,''    cuentaBancariaProveedor,@idPersona idPersona, @portal portal

					


		
	END
	ELSE
	BEGIN
	
		
	--SELECT  @usuario = usu_nombreusu 
	--FROM	ControlAplicaciones.dbo.Cat_usuarios 
	--WHERE	usu_idusuario  = @idUsuario

	select  @usuario = eqv_usubusiness  from controlAplicaciones.dbo.eqv_organigrama where usu_usuario = @idUsuario

		----Validar que exista el autorizador de cuentas
		SELECT	 @usuarioCorreoAutoriza = ISNULL(usu_correo,'') 
		 FROM	Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION N 
		INNER JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT F ON N.idTipoNotificacion = F.idTipoNotificacion
		INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = F.usuario_autoriza
		WHERE	N.idTipoNotificacion = 4 
		AND		nivel_escalamiento = 0

		

		IF(@usuarioCorreoAutoriza = 'NA' OR @usuarioCorreoAutoriza = '' )
		BEGIN
			SELECT -2 result, '' as rfc,  '' correo, '' token,'' correoAutorizaCuentas
		END
		ELSE
		BEGIN
			IF((SELECT ISNULL(PER_IDPERSONA_GA,0) FROM   [dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto ) != 0)
			BEGIN
					SELECT @idPersona = ISNULL(PER_IDPERSONA_GA,0) FROM   [dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto

					-------------------------------------------------------------
						SET @numRegistros = (select COUNT(1) from @BASES)

						INSERT INTO @provBanco
						SELECT 
							  [idProspecto]
							  ,[titular]
							  ,[banco]
							  ,[sucursal]
							  ,[noCuenta]
							  ,[clabe]
							  ,[cie]
							  ,[referencia]
							  ,[cveBanxico]
							  ,[cveBanco]
							  ,[tipoCtaBancaria]
							  ,[nombreTipoCtaBancaria]
							  ,[empresaId]
						  FROM [dbo].[PROV_CUENTA_BANCARIA]
						  WHERE  aprobada is null AND idPerTra = @idPerTra

						  


						  SET  @numRegistrosCuentas = (select  COUNT(1) from @provBanco)


						  WHILE(@contBancos<= @numRegistrosCuentas)
						  BEGIN
							--SELECT @contBancos '@contBancos'
							SET @contBases  = 1
								select @banxico = cveBanxico, @cie = cie, @noCuenta = noCuenta FROM @provBanco WHERE id = @contBancos
								--select @banxico, @cie, @noCuenta
				
								WHILE(@contBases<= @numRegistros)
								BEGIN
				
					
									SELECT @basePrincipal = base, @emp_idempresa = emp_idempresa FROM @BASES WHERE id = @contBases
									IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @basePrincipal)) 
									BEGIN
										--SELECT @basePrincipal
										SET @cveBanco = ''
										SET @SQLString = 'IF EXISTS (SELECT 1 from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''') BEGIN    SELECT @res = PAR_IDENPARA from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''' END '
										SET @ParmDefinition = N' @res  VARCHAR(10) OUTPUT'; 
										--select * from GAZM_Concentra.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = 'BA' AND PAR_STATUS = 'A' AND PAR_DESCRIP5 = '072'
										print @sql
						
										EXECUTE sp_executesql @SQLString, @ParmDefinition, @res= @cveBanco OUTPUT
											
										--print (@sql)
										IF( @cveBanco != '')
										BEGIN
												SET @sqlUni = ' IF EXISTS(SELECT 1 FROM '+@basePrincipal+'.[dbo].[CON_BANCOS] WHERE BCO_NUMCUENTA ='''+ @noCuenta+''' AND BCO_IDPERSONA = '+CONVERT(VARCHAR(10),@idPersona)+')
																BEGIN 
																	UPDATE  ' +@basePrincipal+'.[dbo].[CON_BANCOS] SET 
																		  BCO_AUTORIZADA = 1
																		, BCO_CVEUSU = ''' + @usuario+ '''
																		, BCO_FECHOPE = CONVERT(VARCHAR(10), GETDATE(),103)
																		, BCO_HORAOPE = CONVERT(CHAR(8), GETDATE(), 108)    
																	WHERE  BCO_NUMCUENTA ='''+ @noCuenta+''' AND BCO_IDPERSONA = '+CONVERT(VARCHAR(10),@idPersona)+'
																END
																ELSE
																BEGIN
																INSERT INTO ' +@basePrincipal+'.[dbo].[CON_BANCOS]
																		 ([BCO_IDPERSONA]
																		 ,[BCO_BANCO]
																		 ,[BCO_PLAZA]
																		 ,[BCO_SUCURSAL]
																		 ,[BCO_STATUS]
																		 ,[BCO_TIPCUENTA]
																		 ,[BCO_NUMCUENTA]
																		 ,[BCO_CLABE]
																		 ,[BCO_CVEUSU]
																		 ,[BCO_FECHOPE]
																		 ,[BCO_HORAOPE]
																		 ,[BCO_REFERNUM]
																		 ,[BCO_REFERALF]
																		 ,[BCO_CONVENIOCIE]
																		 ,[BCO_AUTORIZADA]) 
									   						SELECT '+ CONVERT(VARCHAR(10),@idPersona)+ '
																	,'''+@cveBanco+'''
																	,''1''
																	,ISNULL(sucursal,''1'')
																	,''ACTIVO''
																	,tipoCtaBancaria
																	,noCuenta
																	,clabe
																	,''' + @usuario+ '''
																	,CONVERT(VARCHAR(10), GETDATE(),103)
																	,CONVERT(CHAR(8), GETDATE(), 108) 
																	,ISNULL(referencia,'''')
																	,''''
																	,cie
																	,1 
															FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
															INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_IDPERSONA  = CB.idProspecto OR (PP.PER_RFC = CB.rfcProspecto)
															WHERE CB.cveBanxico = '''+ @banxico +'''   AND CB.idPerTra = '+ CONVERT(VARCHAR(10),@idPerTra) +' END '
												--SELECT @sql
												EXEC (@sqlUni)
											--	SELECT @emp_idempresa
											EXEC Pagos.[dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP] @idProveedor =@idPersona , @cuenta =@noCuenta ,	@convenio = @cie, @idEmpresa =  @emp_idempresa,@idUsuario = @usuario, @result = @idRespuestaUni OUTPUT
											--SELECT @idRespuestaUni 'Unifica'
											SET	@contBases = @numRegistros + 1
										END
										ELSE 
											BEGIN 
												SET @contBases= @contBases+1  
											END
								END
								ELSE
									BEGIN
										SET @contBases= @contBases+1 
									END
								END
								SET @contBancos = @contBancos+1
						  END

						--  SELECT * from  GAAU_Concentra.[dbo].[CON_BANCOS]  WHERE BCO_IDPERSONA =@idPersona
		 
						  UPDATE PROV_CUENTA_BANCARIA 
						  SET	aprobada = 1
								,autorizada = 1
								,PER_IDPERSONA = @idPersona
						  WHERE 
						   idPerTra = @idPerTra 

						-------------------------------------------------------------------------------------
					SELECT TOP 1 @cuentaBancaria =  'Banco: '+ banco +  ' No. cuenta: ' + noCuenta + ' Tipo de cuenta: ' + isnull(nombreTipoCtaBancaria,'') + ' Titular Cuenta: ' + titular	+ ' CONVENIO CIE: ' + isnull(cie,'') + ' CLABE: ' + isnull(clabe,'')
					FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
					INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_IDPERSONA  = CB.idProspecto OR (PP.PER_RFC = CB.rfcProspecto)
					WHERE  CB.idPerTra = @idPerTra
					SELECT	1 result
							,ppro_user as rfc
							,PP.correo, CA.token 
							,@usuarioCorreoAutoriza correoAutorizaCuentas
							,@cuentaBancaria    cuentaBancariaProveedor
							,@idPersona idPersona
							, 1 portal
					FROM CentralizacionV2.dbo.PPRO_USERSPORTALPROV PP 
					INNER JOIN [Proveedores].[dbo].[CorreoActivacion] CA ON CA.per_rfc = ppro_user
					INNER JOIN  CentralizacionV2.[dbo].[PROV_PROSPECTO] P ON P.token = CA.token
					WHERE PER_IDPERSONA = @idProspecto 
			END
			ELSE
			BEGIN
			print 'aqui ando'
								--SELECT @bd = empresaBD  FROM [dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto
						SET @bd = 'GAZM_Concentra'

						INSERT INTO GA_CORPORATIVA.DBO.PER_PERSONAS (
									PER_EMAIL
									,PER_NOMRAZON 
									,PER_PATERNO 
									,PER_MATERNO 
									,PER_RFC  
									,PER_GIRO 
									--,PER_CLICON 
									,PER_TELEFONO1 
									,PER_CALLE1 
									,PER_CALLE2 
									,PER_NUMEXTER  
									,PER_NUMINER  
									,PER_CODPOS  
									,PER_COLONIA  
									,PER_DELEGAC 
									,PER_CIUDAD  
									,PER_PAGWEB
									,PER_TIPO
									,PER_STATUS
									,PER_SUCURSAL
									,PER_CVEUSU
									,PER_FECHOPE
									,PER_ESTADO )

						SELECT		-- PER_IDPERSONA 
									 PER_EMAIL
									,PER_NOMRAZON 
									,PER_PATERNO 
									,PER_MATERNO 
									,PER_RFC  
									,PER_GIRO 
									--,PER_CLICON 
									,PER_TELEFONO1 
									,PER_CALLE1 
									,PER_CALLE2 
									,PER_NUMEXTER  
									,PER_NUMINER  
									,PER_CODPOS  
									,PER_COLONIA  
									,PER_DELEGAC 
									,PER_CIUDAD  
									,PER_PAGWEB 
								--	,PER_RLNOMRAZON  comercial 
								--	,PER_DEALERID docContacto
									,CASE WHEN PER_TIPO = 'FIS' THEN 'FIE' ELSE 'MOR' END PER_TIPO
									,'ACTIVO'
									,'GEN' 
									,@usuario
									,CONVERT(VARCHAR(10), GETDATE(),103)
									,'09'
						FROM [dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto


						SET @idPersona = SCOPE_IDENTITY()

						--select @idPersona

						UPDATE [dbo].[PROV_PROSPECTO] 
						SET PER_IDPERSONA_GA = @idPersona
						WHERE PER_IDPERSONA = @idProspecto

						--select * from [dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto
						SET @numRegistros = (select COUNT(1) from @BASES)

						INSERT INTO @provBanco
						SELECT 
							  [idProspecto]
							  ,[titular]
							  ,[banco]
							  ,[sucursal]
							  ,[noCuenta]
							  ,[clabe]
							  ,[cie]
							  ,[referencia]
							  ,[cveBanxico]
							  ,[cveBanco]
							  ,[tipoCtaBancaria]
							  ,[nombreTipoCtaBancaria]
							  ,[empresaId]
						  FROM [dbo].[PROV_CUENTA_BANCARIA]
						  WHERE  aprobada is null AND idPerTra = @idPerTra

						  SET  @numRegistrosCuentas = (select  COUNT(1) from @provBanco)
						  WHILE(@contBancos<= @numRegistrosCuentas)
						  BEGIN
							--SELECT @contBancos '@contBancos'
							SET @contBases  = 1
								select @banxico = cveBanxico, @cie = cie, @noCuenta = noCuenta FROM @provBanco WHERE id = @contBancos
								--select @banxico, @cie, @noCuenta
				
								WHILE(@contBases<= @numRegistros)
								BEGIN
								
									SELECT @basePrincipal = base, @emp_idempresa = emp_idempresa FROM @BASES WHERE id = @contBases
									
									IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE name = @basePrincipal) 
									BEGIN
									
										SET @cveBanco = ''
										SET @SQLString = 'IF EXISTS (SELECT 1 from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''') BEGIN    SELECT @res = PAR_IDENPARA from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''' END '
										SET @ParmDefinition = N' @res  VARCHAR(10) OUTPUT'; 
										--select * from GAZM_Concentra.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = 'BA' AND PAR_STATUS = 'A' AND PAR_DESCRIP5 = '072'
										print @sql
						
										EXECUTE sp_executesql @SQLString, @ParmDefinition, @res= @cveBanco OUTPUT
										--print (@sql)
										IF( @cveBanco != '')
										BEGIN
										
												SET @sqlUni = ' IF EXISTS(SELECT 1 FROM '+@basePrincipal+'.[dbo].[CON_BANCOS] WHERE BCO_NUMCUENTA ='''+ @noCuenta+''' AND BCO_IDPERSONA = '+CONVERT(VARCHAR(10),@idPersona)+')
																BEGIN 
																	UPDATE  ' +@basePrincipal+'.[dbo].[CON_BANCOS] SET 
																		  BCO_AUTORIZADA = 1
																		, BCO_CVEUSU = ''' + @usuario+ '''
																		, BCO_FECHOPE = CONVERT(VARCHAR(10), GETDATE(),103)
																		, BCO_HORAOPE = CONVERT(CHAR(8), GETDATE(), 108)    
																	WHERE  BCO_NUMCUENTA ='''+ @noCuenta+''' AND BCO_IDPERSONA = '+CONVERT(VARCHAR(10),@idPersona)+'
																END
																ELSE
																BEGIN
																INSERT INTO ' +@basePrincipal+'.[dbo].[CON_BANCOS]
																		 ([BCO_IDPERSONA]
																		 ,[BCO_BANCO]
																		 ,[BCO_PLAZA]
																		 ,[BCO_SUCURSAL]
																		 ,[BCO_STATUS]
																		 ,[BCO_TIPCUENTA]
																		 ,[BCO_NUMCUENTA]
																		 ,[BCO_CLABE]
																		 ,[BCO_CVEUSU]
																		 ,[BCO_FECHOPE]
																		 ,[BCO_HORAOPE]
																		 ,[BCO_REFERNUM]
																		 ,[BCO_REFERALF]
																		 ,[BCO_CONVENIOCIE]
																		 ,[BCO_AUTORIZADA]) 
									   						SELECT '+ CONVERT(VARCHAR(10),@idPersona)+ '
																	,'''+@cveBanco+'''
																	,''1''
																	,ISNULL(sucursal,''1'')
																	,''ACTIVO''
																	,tipoCtaBancaria
																	,noCuenta
																	,clabe
																	,''' + @usuario+ '''
																	,CONVERT(VARCHAR(10), GETDATE(),103)
																	,CONVERT(CHAR(8), GETDATE(), 108) 
																	,ISNULL(referencia,'''')
																	,''''
																	,cie
																	,1 
															FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
															INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_IDPERSONA  = CB.idProspecto OR (PP.PER_RFC = CB.rfcProspecto)
															WHERE CB.cveBanxico = '''+ @banxico +'''   AND CB.idPerTra = '+ CONVERT(VARCHAR(10),@idPerTra) +' END '
											
												EXEC (@sqlUni)
											--	SELECT @emp_idempresa
												EXEC Pagos.[dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP] @idProveedor =@idPersona , @cuenta =@noCuenta ,	@convenio = @cie, @idEmpresa =  @emp_idempresa,@idUsuario = @usuario, @result = @idRespuestaUni OUTPUT

											SET	@contBases = @numRegistros +1
										END
										ELSE 
											BEGIN 
												SET @contBases= @contBases+1  
											END
									END
									ELSE
									BEGIN
										SET @contBases= @contBases+1 
									END
								END
								SET @contBancos = @contBancos+1
						  END

						  
		 		  

						  UPDATE PROV_CUENTA_BANCARIA 
						  SET	aprobada = 1
								,autorizada = 1
								,PER_IDPERSONA = @idPersona
						  WHERE idProspecto= @idProspecto
						  AND idPerTra = @idPerTra 

						  --select 'activar',* from PROV_CUENTA_BANCARIA
						  --  WHERE idProspecto= @idProspecto
						  --AND idPerTra = @idPerTra 

		
		
						DECLARE @contR INT = 1
								,@bdRol VARCHAR(100)
								,@empId INT 
								,@sqlRol VARCHAR(max)
				
						DECLARE @tblRol as TABLE
						(
							id INT identity(1,1)
							,rol VARCHAR(20) 
							,nombreRol VARCHAR(100)
							,empresaId INT
							,empresaBD VARCHAR(100)
						)
						DECLARE @Sucursales TABLE(id int identity(1,1),emp_idempresa INT,base nvarchar(200))

						INSERT INTO @tblRol
						SELECT rol,nombreRol, empresaId, empresaBD FROM [dbo].[PROV_PROSPECTO_ROL] where IdProspecto = @idProspecto ORDER BY idProspectoRol ASC

						INSERT INTO @Sucursales
						SELECT distinct emp_idempresa ,nombre_base FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo != 3 --  emp_idEmpresa in (select empresaId FROM @tblRol )
			
		
				
						WHILE(@contR <= (SELECT COUNT(1) FROM @Sucursales  ) )
						BEGIN
							SELECT @bdRol = base, @empId = emp_idempresa  FROM @Sucursales WHERE id = @contR

							IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @bdRol)) 
									BEGIN
						
											SET @sqlRol = ' INSERT INTO ' +@bdRol+'.[dbo].[PER_ROLES]
														([ROL_IDPERSONA]
														,[ROL_ROL]
														,[ROL_CVEUSU]
														,[ROL_FECHOPE]
														,[ROL_SUCURSAL]
														,[ROL_ESTATUS])
							
													SELECT '	+ CONVERT(VARCHAR(10),@idPersona)+ ' as ROL_IDPERSONA
																,''PVE''
																,''' + @usuario + ''' ROL_CVEUSU
																, CONVERT(VARCHAR(10), GETDATE(),103) ROL_FECHOPE
																, '''' ROL_SUCURSAL
																, 1 ROL_ESTATUS'
												
											print @sqlRol		

										
									EXEC (@sqlRol)
									END
			

		
							SET @contR = @contR +1
						END
			


						UPDATE CentralizacionV2.[dbo].[PROV_PROSPECTO] 
						SET PER_STATUS = 1
						WHERE PER_IDPERSONA = @idProspecto


		
						DECLARE  @rfc VARCHAR(15) = (SELECT PER_RFC FROM  CentralizacionV2.[dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto)
								, @empresaId INT = (SELECT empresaId FROM  CentralizacionV2.[dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto)
						
				

						DECLARE @tblCuentas AS TABLE
						(
						 id INT IDENTITY(1,1)
						,cuenta VARCHAR(MAX)
		
						)

						SELECT TOP 1 @cuentaBancaria =  'Banco: '+ banco +  ' No. cuenta: ' + noCuenta + ' Tipo de cuenta: ' + isnull(nombreTipoCtaBancaria,'') + ' Titular Cuenta: ' + titular	+ ' CONVENIO CIE: ' + isnull(cie,'') + ' CLABE: ' + isnull(clabe,'')
						FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
						INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_IDPERSONA  = CB.idProspecto OR (PP.PER_RFC = CB.rfcProspecto)
						WHERE  CB.idPerTra = @idPerTra
		
					
				
						
						SELECT	 @usuario_Autoriza= usuario_autoriza
								,@usuarioCorreoAutoriza = usu_correo 
						FROM	Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION N 
						INNER JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT F ON N.idTipoNotificacion = F.idTipoNotificacion
						INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = F.usuario_autoriza
						WHERE	N.idTipoNotificacion = 4 
						AND		nivel_escalamiento = 0
			
	
			


		
						SELECT	1 result
								,ppro_user as rfc
								,PP.correo, CA.token 
								,@usuarioCorreoAutoriza correoAutorizaCuentas
								,@cuentaBancaria    cuentaBancariaProveedor
								,@idPersona idPersona
								,@portal portal 
						FROM CentralizacionV2.dbo.PPRO_USERSPORTALPROV PP 
						INNER JOIN [Proveedores].[dbo].[CorreoActivacion] CA ON CA.per_rfc = ppro_user
						INNER JOIN  CentralizacionV2.[dbo].[PROV_PROSPECTO] P ON P.token = CA.token
						WHERE PER_IDPERSONA = @idProspecto 

			END

		END
	END

	
		/***** Cambiar el estatus de la notificacion ****/
	DECLARE  @not_id NUMERIC(18,0)	
			,@idAprobacion NUMERIC(18,0)	
	SELECT @not_id =  N.not_id  from Notificacion.dbo.Not_Notificacion N
	inner join Notificacion.dbo.not_aprobacion A on N.not_id = A.not_id
	where not_adjunto = Convert(varchar(20),@idPerTra) and not_estatus = 2 AND not_identificador = @rfcProspecto AND not_agrupacion = 23 and emp_id =@idUsuario
	--where not_adjunto = Convert(varchar(20),@idPerTra) and not_estatus = 2 AND not_identificador = @rfcProspecto
	SELECT @idAprobacion = apr_id from Notificacion.dbo.NOT_APROBACION where not_id = @not_id
	

	--- Cambio estatus de notificacion
	UPDATE Notificacion.dbo.NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = @not_id --(SELECT not_id FROM Notificacion.dbo.NOT_APROBACION WHERE apr_id = @idAprobacion)
	UPDATE Notificacion.dbo.NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion
		
	----------------------------------------------------------------
	-------Inserta una respuesta de aprobación
	----------------------------------------------------------------
	INSERT INTO Notificacion.dbo.[NOT_APROBACION_RESPUESTA]									
		(not_id,[apr_id],[nar_fecha],[nar_comentario])
	VALUES
		(@not_id,@idAprobacion,GETDATE(),'Se aprueba Trámite')	
	----------------------------------
				
	


		-------------------------------------------------


		--select * from GA_CORPORATIVA.DBO.PER_PERSONAS where PER_IDPERSONA = @idPersona

COMMIT TRANSACTION
END TRY
BEGIN CATCH

ROLLBACK TRANSACTION
--select ERROR_MESSAGE()

		SELECT -1 result, '' as rfc,  '' correo, '' token,'' correoAutorizaCuentas, 0 portal


END CATCH
   
END
go

