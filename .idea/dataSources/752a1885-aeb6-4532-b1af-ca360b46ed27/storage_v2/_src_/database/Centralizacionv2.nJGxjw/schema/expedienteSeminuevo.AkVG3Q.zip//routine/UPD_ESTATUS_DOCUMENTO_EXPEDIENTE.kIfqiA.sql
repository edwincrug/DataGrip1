-- =============================================
-- Author:		<Aldo Ortiz>
-- Create date: <11/06/20>
-- Description:	<SP que actualiza el estatus de un documento del expediente>
-- EXEC [expedienteSeminuevo].[UPD_ESTATUS_DOCUMENTO_EXPEDIENTE] 5, 2,'RechazoPrueba'
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[UPD_ESTATUS_DOCUMENTO_EXPEDIENTE]
	@id_documentoGuardado INT,
	@id_estatus INT,
	@observaciones VARCHAR(500) = ''
AS
BEGIN
	BEGIN TRY
        UPDATE [expedienteSeminuevo].[documentosExpediente]
            SET [id_estatus] = @id_estatus, observacionesDocumento = @observaciones
            WHERE [id_documentoGuardado] = @id_documentoGuardado

			DECLARE @idDocumento INT, @idExpediente INT;

			SELECT
				@idDocumento = id_documento,
				@idExpediente = id_expediente
			FROM [expedienteSeminuevo].[documentosExpediente] WHERE id_documentoGuardado = @id_documentoGuardado
    
		SELECT success = 1, idDocumento = @idDocumento, idExpediente = @idExpediente;
	END TRY
	BEGIN CATCH
		PRINT (ERROR_MESSAGE())
		SELECT success = 0
	END CATCH
END



go

