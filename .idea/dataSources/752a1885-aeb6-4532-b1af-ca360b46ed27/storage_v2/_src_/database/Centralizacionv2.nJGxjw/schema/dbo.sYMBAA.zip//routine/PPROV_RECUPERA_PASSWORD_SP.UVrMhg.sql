CREATE PROCEDURE [dbo].[PPROV_RECUPERA_PASSWORD_SP] 
	@rfc VARCHAR(13) = ''
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY

   DECLARE @correo         VARCHAR(255)=''
   DECLARE @correoMascara  VARCHAR(255)=''
   DECLARE @pass           VARCHAR(255)=''
   DECLARE @msg            VARCHAR(500) = ''
   DECLARE @estatus        VARCHAR(10) = ''
   DECLARE @tokenID uniqueidentifier

   IF EXISTS (SELECT 1 FROM [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV] WHERE [ppro_user] = @rfc)
   BEGIN
   	   SET @estatus = 'ok'
	   SET @msg ='RFC encontrado con exito'


	   DECLARE @passEnc VARCHAR(100)
		DECLARE @passDecry  VARCHAR(50)
		DECLARE @SQLString nvarchar(500)
		DECLARE @ParmDefinition nvarchar(500) 
		
		SELECT @passEnc = ppro_pass FROM PPRO_USERSPORTALPROV WHERE ppro_User = @rfc
							
		SET @SQLString =N'SELECT @passD = convert(varchar(MAX),DecryptByPassPhrase(''4ndr4d3'',  '+ @passEnc +' )) '	 
		SET @ParmDefinition = N' @passD varchar(MAX) OUTPUT'; 
		
		
		EXECUTE sp_executesql @SQLString, @ParmDefinition, @passD=@passDecry OUTPUT;




	   SELECT  @correo = correo
			  ,@pass   = @passDecry 
			  ,@correoMascara = SUBSTRING(@correo, 1, 2) +                   
			   REPLICATE('*', CHARINDEX('@',@correo)-3) +   
			   RIGHT(@correo, LEN(@correo) - CHARINDEX('@',@correo) + 1 )
		 FROM [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV]
		WHERE [ppro_user] = @rfc

		SET @tokenID = NEWID()

		IF NOT EXISTS(SELECT 1 FROM Centralizacionv2.dbo.[PROV_TokenRecuperaPass] WHERE rfc = @rfc )
		BEGIN
			INSERT INTO Centralizacionv2.dbo.[PROV_TokenRecuperaPass]
			SELECT @rfc, @tokenID
		END
		ELSE 
		BEGIN 
			UPDATE Centralizacionv2.dbo.[PROV_TokenRecuperaPass]
			SET tokenRecupera =  @tokenID
			WHERE rfc = @rfc
		END


   END
   ELSE
   BEGIN
   	   SET @estatus = 'error'
	   SET @msg ='RFC no registrado en el Portal. Favor de crear una cuenta nueva.'
   END


   SELECT  @rfc            AS rfc
	      ,@pass           AS pass
		  ,@correoMascara  AS correoMascara
	      ,@correo         AS correo
		  ,@msg            AS mensaje
		  ,@estatus        AS estatus
		  ,@tokenID		   AS token		

END TRY
BEGIN CATCH
	Print('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'PPROV_RECUPERA_PASSWORD_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
END CATCH
END

go

