-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 15/10/2015
-- Description:	Stored que busca el nombre de un proveedor en las tablas de BPRO.
-- [dbo].[SEL_PROVEEDOR_BUSCA_SP]  'PAPELERIA PRINCIPADO',1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_BUSCA_SP] 
     @nombre_proveedor varchar(150)
	,@idEmpresa INT
AS
BEGIN
	BEGIN TRY
	SET NOCOUNT ON;

		SELECT PER_IDPERSONA as idProveedor
			  ,RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre
			  ,PER_RFC as RFC
			  ,PER_TIPO as Tipo
		 FROM GA_Corporativa.dbo.PER_PERSONAS
		WHERE RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) Like '%'+ @nombre_proveedor +'%'
		   OR PER_RFC like '%' + @nombre_proveedor + '%'

	END TRY
  BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_PROVEEDOR_BUSCA_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

