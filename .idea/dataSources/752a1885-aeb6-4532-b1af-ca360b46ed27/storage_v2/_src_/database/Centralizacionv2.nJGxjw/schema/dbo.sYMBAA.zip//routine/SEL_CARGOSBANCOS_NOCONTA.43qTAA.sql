
Create PROCEDURE [dbo].[SEL_CARGOSBANCOS_NOCONTA]  (@iAnio int,@iMes int,@snoCuenta varchar(100),@sConciliados varchar(1), @dResultado numeric(18,6) Output)   
As
Declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@iIdBanco int
begin

set nocount on

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#CARGOSBANCOS]'))
begin
	drop table #CARGOSBANCOS
end

Create Table #CARGOSBANCOS
(
		id_local [int] IDENTITY (1, 1),
		idBmer int,
		importe numeric(18,6),
		idBanco int,
		noCuenta varchar(50),
		Tipo varchar(1)
)

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#PAGOSRELACION]'))
begin
	drop table #PAGOSRELACION
end

Create table #PAGOSRELACION
(
     dpa_iddoctopagado int,
	 idBanco_Registro int,
	 idBanco int
)

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#PAGOSRELACIONFINAL]'))
begin
	drop table #PAGOSRELACIONFINAL
end

Create table #PAGOSRELACIONFINAL
(
     dpa_iddoctopagado int,
	 idBanco_Registro int,
	 idBanco int
)


           select @iIdBanco = idBanco from referencias..BancoCuenta where numeroCuenta = @snoCuenta  

			if (@iIdBanco = 1)
			Begin
			    set @sQ = N'Insert INTO #CARGOSBANCOS (idBmer,importe,idBanco,noCuenta,Tipo) '
				set @sQ = @sQ + N' SELECT idBmer,importe,idBanco,noCuenta,''0'' as Tipo'				
				set @sQ = @sQ + N' FROM Referencias.dbo.BANCOMER WHERE '
				set @sQ = @sQ + N' Month(fechaOperacion) = @iMes and Year(fechaOperacion)=@iAnio' 
				set @sQ = @sQ + N' AND noCuenta = @snoCuenta AND esCargo = 1'
			end
			else
			begin				
				set @sQ = N'Insert INTO #CARGOSBANCOS (idBmer,importe,idBanco,noCuenta,Tipo) '
				set @sQ = @sQ + N' SELECT idSantander,Convert(numeric(18,6),importe),idbanco,noCuenta,''0'' as Tipo'
				set @sQ = @sQ + N' FROM Referencias.dbo.Santander WHERE '
				set @sQ = @sQ + N' Month(fechaMovimiento) = @iMes and Year(fechaMovimiento)=@iAnio' 
				set @sQ = @sQ + N' AND noCuenta = @snoCuenta AND signo = ''-'''
			end

			--print @sQ

			execute sp_executesql @sQ,N'@snoCuenta varchar(50),@iMes int,@iAnio int',@snoCuenta=@snoCuenta,@iMes=@iMes,@iAnio=@iAnio
			
			--SELECT * FROM #ABONOSBANCOS
			--select top 10000 * from referencias..Santander 
			--select * from referencias..BancoCuenta 

			--BUSCO LOS PAGOS EN TABLA DE RELACION
			insert into #PAGOSRELACION 
			SELECT D.* FROM #CARGOSBANCOS C INNER JOIN [Pagos].[dbo].[PAG_REL_DOCTOS_BANCOS] D ON idBmer = idBanco_Registro where D.idBanco = @iIdBanco



			--DISCRIMINO LOS REGISTROS POR ESTATUS DE DOCTOS PAGADOS
			INSERT INTO #PAGOSRELACIONFINAL
			SELECT R.* FROM #PAGOSRELACION R INNER JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] P ON R.dpa_iddoctopagado = P.dpa_iddoctopagado WHERE dpa_pagoaplicado = 1

			--IDENTIFICO LOS REGISTROS CONCILIADOS Y NO CONCILIADOS, 0 = NO CONCILAIDOS, 1 = CONCILIADOS

			UPDATE #CARGOSBANCOS SET Tipo = '1' FROM #CARGOSBANCOS C INNER JOIN #PAGOSRELACIONFINAL P ON idBmer = idBanco_Registro

		    select @dResultado = sum(importe) from #CARGOSBANCOS  WHERE Tipo = @sConciliados

	set nocount off
end --Del Store

/*
Declare
@iAnio int,
@iMes int,
@snoCuenta varchar(50),
@sConciliados varchar(1),
@dResultado numeric(18,6)

select @iAnio = 2018
select @iMes = 2
select @snoCuenta ='000000000195334667'  --'000000000195334667'  --Bancomer Suzuky  --Santander Suzuky 65504258249
select @sConciliados = '0' --0 No conciliados, 1 Conciliados
select @dResultado = 0


execute [SEL_CARGOSBANCOS_NOCONTA]  @iAnio, @iMes,@snoCuenta,@sConciliados, @dResultado Output
print 'Resultado: ' + CAST(CONVERT(varchar, CAST(@dResultado AS money), 1) AS varchar)




*/
go

