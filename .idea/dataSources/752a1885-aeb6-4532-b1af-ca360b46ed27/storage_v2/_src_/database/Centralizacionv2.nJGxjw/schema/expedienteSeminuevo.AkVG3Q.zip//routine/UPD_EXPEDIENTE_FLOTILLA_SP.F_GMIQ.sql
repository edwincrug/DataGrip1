-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[UPD_EXPEDIENTE_FLOTILLA_SP]
	@idExpediente INT,
	@flotilla INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRY
		UPDATE [expedienteSeminuevo].[expedientes] SET exp_flotilla = @flotilla WHERE id_expediente = @idExpediente

		SELECT succes = 1;
	END TRY

	BEGIN CATCH
		SELECT succes = 0
	END CATCH

	
END
go

