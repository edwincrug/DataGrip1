-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [dbo].[Sp_Documentos_ExpNodoFlotCoti_INS] 'AU-ZM-NZA-UN-7754'
-- [dbo].[Sp_Documentos_ExpNodoFlotCoti_INS] 'AU-ZM-NZA-UN-7923'
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Documentos_ExpNodoFlotCoti_INS]
	@Cotizacion VARCHAR( 50 ) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @CurVin INT = 0,
			@VinMax INT = 0,
			@No_Serie VARCHAR(30);

	DECLARE @Vin TABLE(
		[Index] INT,
		[VIN] NVARCHAR(50)
	);


	BEGIN TRY
		INSERT INTO @Vin( [Index], [VIN] )
		SELECT	ROW_NUMBER() OVER(ORDER BY ucn_idcotizadetalle ASC) [Index], UNI.ucn_noserie VIN-- UNI.*, UNI.ucn_noserie VIN
		FROM	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES UNI
				JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal COTI ON UNI.ucu_idcotizacion = COTI.ucu_idcotizacion
		WHERE	COTI.ucu_foliocotizacion = @Cotizacion

		SELECT @CurVin = MIN([Index]), @VinMax = MAX([Index]) FROM @Vin;

		WHILE( @CurVin <= @VinMax )
			BEGIN
				SELECT @No_Serie = VIN FROM @Vin WHERE [Index] = @CurVin;
				EXEC [dbo].[Sp_Documentos_ExpNodoFlotVin_INS] @Cotizacion, @No_Serie;

				SET @CurVin = @CurVin + 1
			END
	END TRY
	BEGIN CATCH
		DECLARE @Mensaje  NVARCHAR(MAX)		
		SELECT @Mensaje = ERROR_MESSAGE() + ' @Cotizacion : ' + @Cotizacion
		EXECUTE INS_ERROR_SP '[dbo].[Sp_Documentos_ExpNodoFlot_INS]', @Mensaje
	END CATCH
END
go

