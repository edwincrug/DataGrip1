-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[INS_BITACORA_ACCION_API_SP]
	@accion VARCHAR(200),
	@vin VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;

	INSERT INTO [expedienteSeminuevo].[bitacoraAccionApi]
           ([bit_accion]
           ,[bit_vin]
           ,[bit_fechaAccion])
     VALUES
           (@accion
           ,@vin
           ,GETDATE());

END

go

