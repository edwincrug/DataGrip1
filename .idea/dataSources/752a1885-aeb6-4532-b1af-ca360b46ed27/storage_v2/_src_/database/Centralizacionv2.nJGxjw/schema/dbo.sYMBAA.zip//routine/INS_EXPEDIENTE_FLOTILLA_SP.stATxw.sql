
--LQMA 30052017 CREATE
--Crea expedientes de una flotilla. Inserta un expediente por orden de compra de la flotilla
-- INS_EXPEDIENTE_FLOTILLA_SP @idFlotilla = 1
CREATE PROCEDURE [dbo].[INS_EXPEDIENTE_FLOTILLA_SP]
@idFlotilla INT = 0
,@idSucursal INT 
AS 

	DECLARE @folios TABLE(id INT IDENTITY(1,1), folio VARCHAR(50))
	DECLARE @aux INT = 1, @max INT = 0, @folio VARCHAR(50) = ''
	DECLARE @Resultados TABLE(ID INT IDENTITY(1,1), RES INT) 

	--Obtenemos todos los folios de orden de compra de la flotilla
	INSERT INTO @folios
	SELECT oce_folioorden FROM cuentasxpagar..cxp_ordencompra WHERE oce_numeroflotilla = @idFlotilla and oce_idsucursal = @idSucursal

	SELECT @max = MAX(id) FROM @folios 

	--Registramos en la bitacora
	INSERT INTO BITACORA_PROCESOS
	VALUES (4,'INS_EXPEDIENTE_FLOTILLA_SP Inserta expedientes flotilla: ' + CONVERT(VARCHAR(7), @idFlotilla) + ', de la sucursal: ' +  CONVERT(VARCHAR(7), @idSucursal),GETDATE())
			    		
		--Inicia transaccion
		BEGIN TRANSACTION TRAN_EXP_FLOTILLA

	BEGIN TRY
				--recorremos todas las ordenes de compra de la flotilla
				WHILE(@aux <= @max)
				BEGIN

					SELECT @folio = folio FROM @folios WHERE id = @aux				
					
					--insertamos el expediente de la orden de compra actual
					INSERT INTO @Resultados
					EXECUTE [INS_NODOS_FOLIO_SP] @folio, 1
					
					INSERT INTO @Resultados
					EXECUTE [Centralizacionv2].[dbo].[INS_CIERRA_NODO_SP] @proc_Id = 1         --Proceso 
                                                      ,@nodo_Id = 1         --Nodo a cerrar
													  ,@folio_Operacion= @folio
					
					SET @aux = @aux + 1
				
				END

		INSERT INTO BITACORA_PROCESOS
		VALUES (4,'INS_EXPEDIENTE_FLOTILLA_SP Termina expedientes flotilla: ' + CONVERT(VARCHAR(7), @idFlotilla),GETDATE())
		
		SELECT 0
		
		--damos commit a la transaccion
		COMMIT TRANSACTION TRAN_EXP_FLOTILLA

	END TRY
	BEGIN CATCH		
		
		INSERT INTO BITACORA_PROCESOS
		VALUES (4,'INS_EXPEDIENTE_FLOTILLA_SP Error expediente flotilla: ' + CONVERT(VARCHAR(7), @idFlotilla),GETDATE())

		--rollback a la transaccion
		ROLLBACK TRANSACTION TRAN_EXP_FLOTILLA
		
		DECLARE @Mensaje  nvarchar(max)		
		SELECT @Mensaje = ERROR_MESSAGE() + ' @idFlotilla : ' + CONVERT(VARCHAR(7), @idFlotilla)
		--insertamos en la bitacora de errores
		EXECUTE INS_ERROR_SP 'INS_EXPEDIENTE_FLOTILLA_SP', @Mensaje
		SELECT  ERROR_NUMBER() 

	END CATCH
go

