-- =============================================
-- Author:		<JJSY>
-- Create date: <24/06/2020>
-- Description:	selecciona a quien se manda correos de  los expedientes incompletos 
--por sucursal  y empresa para gerentes
-- De 6 dias en adeñante
-- TEST [expedienteSeminuevo].[SEL_EXPEDIENTES_CORP_SM_MAIL] 4,6
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_EXPEDIENTES_CORP_SM_MAIL]

 	 @empresa INT , 
	 @sucursal INT 

AS
BEGIN
	DECLARE @sqlCommandCXC VARCHAR(MAX)
	DECLARE @sqlCommandCXP VARCHAR(MAX)
	DECLARE @sqlCommandALLExpedientes VARCHAR(MAX)

	DECLARE @minDay INT, @maxDay INT, @puestoNotificacion INT;
	DECLARE @bd VARCHAR(MAX);

	SELECT @minDay = par_valor FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'MINDIAS'
	SELECT @maxDay = par_valor FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'MAXDIAS'
	SELECT @puestoNotificacion = par_valor FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'SEGUNDA_NOTI'

		SELECT  
				ISNULL(nombre, '') + ' ' + ISNULL(apellidoP, '') + ' ' + ISNULL(apellidoM, '')as nombre,
				correo
		FROM [expedienteSeminuevo].[cat_correos_corporativo] WHERE id NOT IN (1, 7)
		 --ISNULL((SELECT correo FROM [DATOS_PUESTOS](103, ME.empresa, ME.sucursal)),'notiene@notiene.com') mailCoordinador,
	
	SELECT @bd = nombre_base
	FROM DIG_CAT_BASES_BPRO 
		WHERE emp_idEmpresa = @empresa
		AND suc_idSucursal = @sucursal

	DECLARE @mailCXP TABLE ( PROCESO varchar(20), VEH_NUMSERIE varchar(150), nombre_sucursal varchar(150), VEH_SMARCA VARCHAR(100), VEH_TIPOAUTO VARCHAR(500), VEH_ANMODELO VARCHAR(50), UBICACION VARCHAR(100) )
	DECLARE @mailCXC TABLE ( PROCESO varchar(20), VEH_NUMSERIE varchar(150), nombre_sucursal varchar(150), VEH_SMARCA VARCHAR(100), VEH_TIPOAUTO VARCHAR(500), VEH_ANMODELO VARCHAR(50), UBICACION VARCHAR(100) )

SET @sqlCommandCXP = '
		
    SELECT
		 ''CXP'' AS PROCESO,
		 S.VEH_NUMSERIE,
		 B.nombre_sucursal,
		 CASE WHEN S.VEH_SMARCA = '' '' THEN  ''S/M'' 
		 ELSE S.VEH_SMARCA 
		 END AS VEH_SMARCA,
		 S.VEH_TIPOAUTO,
		 S.VEH_ANMODELO,
		 P.PAR_DESCRIP1 AS UBICACION
	from [expedienteSeminuevo].[maillExpediente] ME
	INNER JOIN [expedienteSeminuevo].[expedientes] E ON ME.vin = e.EXP_VIN
	INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = ME.empresa AND B.suc_idsucursal = ME.sucursal
	INNER JOIN ' + @bd + '.DBO.SER_VEHICULO S ON E.exp_vin COLLATE Modern_Spanish_CI_AS = S.VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS
	INNER JOIN ' + @bd + '.[dbo].[PNC_PARAMETR] P ON S.VEH_UBICACION = P.PAR_IDENPARA and  P.par_tipopara = '+'''UBI'''+' AND P.PAR_STATUS='+'''A''
	WHERE ME.empresa = '+ CAST(@empresa AS NVARCHAR(10))+' and ME.sucursal = '+ CAST(@sucursal AS NVARCHAR(10))+'  AND ME.dias > '+ CAST(@maxDay AS NVARCHAR(10))+''

	INSERT INTO @mailCXP
	EXEC (@sqlCommandCXP)
	
	SET @sqlCommandCXC = '
	SELECT 
	    ''CXC'' AS PROCESO,
		 S.VEH_NUMSERIE,
		 B.nombre_sucursal,
		 CASE WHEN S.VEH_SMARCA = '' '' THEN  ''S/M'' 
		 ELSE S.VEH_SMARCA 
		 END AS VEH_SMARCA,
		 S.VEH_TIPOAUTO,
		 S.VEH_ANMODELO,
		 P.PAR_DESCRIP1 AS UBICACION
	from [expedienteSeminuevo].[maillExpedientep2] ME
	INNER JOIN [expedienteSeminuevo].[expedientes] E ON ME.vin = e.EXP_VIN
	INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = ME.empresa AND B.suc_idsucursal = ME.sucursal
	INNER JOIN ' + @bd + '.DBO.SER_VEHICULO S ON E.exp_vin COLLATE Modern_Spanish_CI_AS = S.VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS
	INNER JOIN ' + @bd + '.[dbo].[PNC_PARAMETR] P ON S.VEH_UBICACION = P.PAR_IDENPARA and  P.par_tipopara = '+'''UBI'''+' AND P.PAR_STATUS='+'''A''
	WHERE ME.empresa = '+ CAST(@empresa AS NVARCHAR(10))+' and ME.sucursal = '+ CAST(@sucursal AS NVARCHAR(10))+'  AND ME.dias > '+ CAST(@maxDay AS NVARCHAR(10))+''

	INSERT INTO @mailCXC
	EXEC (@sqlCommandCXC)
	-- TEST [expedienteSeminuevo].[SEL_EXPEDIENTES_CORP_SM_MAIL] 4,6
	--SELECT * FROM @mailCXP
	--SELECT * FROM @mailCXC
	
	
	DECLARE @allExpedientes TABLE ( id INT IDENTITY, nombre_sucursal varchar(150), VEH_NUMSERIE varchar(150), VEH_SMARCA VARCHAR(100), 
									VEH_TIPOAUTO VARCHAR(500), VEH_ANMODELO VARCHAR(50), expedienteCXP VARCHAR(100), expedienteCXC VARCHAR(100), fechaEntrega VARCHAR(100))
	INSERT INTO @allExpedientes
	SELECT 
		nombre_sucursal,
		VEH_NUMSERIE,
		VEH_SMARCA,
		VEH_TIPOAUTO,
		VEH_ANMODELO,
		'Documentacion incompleta',
		'',
		''
	FROM @mailCXP

	DECLARE @tempCXC TABLE ( id INT IDENTITY, PROCESO varchar(20), VEH_NUMSERIE varchar(150), nombre_sucursal varchar(150), VEH_SMARCA VARCHAR(100), VEH_TIPOAUTO VARCHAR(500), VEH_ANMODELO VARCHAR(50), UBICACION VARCHAR(100) )

	INSERT INTO @tempCXC
	SELECT * FROM @mailCXC

	DECLARE @min INT, @max INT;
	SELECT 
		@min = MIN(id),
		@max = MAX(id)
	FROM @tempCXC

	IF( (SELECT COUNT(*) FROM @tempCXC) <> 0)
		BEGIN
			WHILE(@min <= @max)
				BEGIN
					DECLARE @vinBusqueda VARCHAR(150) = '';
					SELECT 
						@vinBusqueda = VEH_NUMSERIE 
					FROM @tempCXC WHERE id = @min

					IF EXISTS(SELECT * FROM @allExpedientes WHERE VEH_NUMSERIE = @vinBusqueda )
						BEGIN
							UPDATE @allExpedientes SET expedienteCXC = 'Documentacion incompleta' WHERE VEH_NUMSERIE = @vinBusqueda;
							UPDATE @allExpedientes SET fechaEntrega = (SELECT  PEN_FECHAENTREGA_REAL FROM VW_FECHA_ENTREGA_UNIDAD WHERE PEN_NUMSERIE = @vinBusqueda) WHERE VEH_NUMSERIE = @vinBusqueda;
						END
					ELSE
						BEGIN
							INSERT INTO @allExpedientes
							SELECT 
								nombre_sucursal,
								VEH_NUMSERIE,
								VEH_SMARCA,
								VEH_TIPOAUTO,
								VEH_ANMODELO,
								'',
								'Documentacion incompleta',
								(SELECT  PEN_FECHAENTREGA_REAL FROM VW_FECHA_ENTREGA_UNIDAD WHERE PEN_NUMSERIE = @vinBusqueda)
							FROM @tempCXC WHERE id = @min
						END

					SET @min = @min + 1;
				END
		END

	SELECT * FROM @allExpedientes
END
go

