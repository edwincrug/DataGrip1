CREATE PROCEDURE [dbo].[PPROV_VALIDA_RECIBE_FACTURA]   -- [dbo].[PPROV_VALIDA_RECIBE_FACTURA] 'AD-AUA-VIG-UN-PE-01'
@folioorden VARCHAR(50) 

AS  
  SET NOCOUNT ON    
       SELECT sod_idsituacionorden 
	   FROM [cuentasxpagar].[dbo].[cxp_ordencompra] 
	   WHERE oce_folioorden=@folioorden
SET NOCOUNT OFF

go

