
CREATE PROCEDURE [dbo].[SEL_CARGOSCONTABLES_NOBANCOS]  (@iAnio int,@iMes int,@snoCuenta varchar(100),@sConciliados varchar(1), @dResultado numeric(18,6) Output)   
As
Declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@iIdBanco int,
@iIdEmpresa int,
@noCtaContable varchar(50),
@stipo_poliza_pago varchar(10),
@snombre_base varchar(20),
@ipServidor    VARCHAR(100),
@ipLocal VARCHAR(50)
begin

set nocount on

--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#CARGOS_COMPLETO]'))
--begin
--	drop table #CARGOS_COMPLETO
--end
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#CARGOS_COBROS]'))
--begin
--	drop table #CARGOS_COBROS
--end
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#CARTERA_COBROS]'))
--begin
--	drop table #CARTERA_COBROS
--end
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#DOCTOSCOBRADOS]'))
--begin
--	drop table #DOCTOSCOBRADOS
--end
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#REGISTROSCONCILIADOS]'))
--begin
--	drop table #REGISTROSCONCILIADOS
--end

--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#COBROSCONCILIADOS_CONTROL]'))
--begin
--	drop table #COBROSCONCILIADOS_CONTROL
--end

--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#COBROSCONCILIADOS_REFERENCIA]'))
--begin
--	drop table #COBROSCONCILIADOS_REFERENCIA
--end

-- Se quitaron las variables de tabla
DECLARE @CARGOS_COMPLETO TABLE
(
		id_local [int] IDENTITY (1, 1),
		MOV_TIPOPOL varchar(10),
		MOV_CONSPOL numeric(18,0),
		MOV_CONSMOV numeric(18,0),
		MOV_MES numeric(18,0),
		MOV_NUMCTA varchar(50),
		MOV_DEBE decimal(18,5),
		MOV_HABER decimal(18,5),
		Tipo varchar(1)
)

DECLARE @CARGOSCOBROS TABLE
(
		id_local [int] IDENTITY (1, 1),
		MOV_TIPOPOL varchar(10),
		MOV_CONSPOL numeric(18,0),
		MOV_CONSMOV numeric(18,0),
		MOV_MES numeric(18,0),
		MOV_NUMCTA varchar(50),
		MOV_DEBE decimal(18,5),
		MOV_HABER decimal(18,5),
		Tipo varchar(1)
)

DECLARE @CARTERA_COBROS TABLE
(
CCP_CONSCARTERA numeric(18,0),
CCP_TIPOPOL varchar(10),
CCP_CONSPOL numeric(18,0),
CCP_CONSMOV numeric(18,0),
CCP_MES numeric(18,0),
CCP_IDDOCTO varchar(20),
CCP_IDPERSONA numeric(18,0)
)

DECLARE @DOCTOSCOBRADOS TABLE
(
rap_referencia varchar(20),
rap_idpersona int,
rap_iddocto varchar(20),
rap_cotped varchar(20)
)



DECLARE @REGISTROSCONCILIADOS TABLE
(--CCP_TIPOPOL,CCP_CONSPOL,CCP_MES
CCP_TIPOPOL varchar(10),
CCP_CONSPOL numeric(18,0),
CCP_MES numeric(18,0)
)

DECLARE @COBROSCONCILIADOS_CONTROL TABLE
(--CCP_TIPOPOL,CCP_CONSPOL,CCP_MES
CCP_TIPOPOL varchar(10),
CCP_CONSPOL numeric(18,0),
CCP_MES numeric(18,0)
)

DECLARE @COBROSCONCILIADOS_REFERENCIA TABLE
(
CCP_TIPOPOL varchar(10),
CCP_CONSPOL numeric(18,0),
CCP_MES numeric(18,0)
)

           select @iIdBanco = idBanco,@iIdEmpresa = idEmpresa, @noCtaContable = cuentaContable from referencias..BancoCuenta where numeroCuenta = @snoCuenta  
		   select @ipServidor=ip_servidor, @stipo_poliza_pago=tipo_poliza_pago, @snombre_base = nombre_base  from Centralizacionv2..DIG_CAT_BASES_BPRO where emp_idempresa = @iIdEmpresa and tipo=2 
		   
		    SELECT @ipLocal=local_net_address
			FROM sys.dm_exec_connections c
			WHERE session_id = @@SPID

			if (@ipLocal = @ipServidor)
			begin
			   select @ipServidor = '';
			end
			else
				begin
				   select @ipServidor = '[' + @ipServidor + '].'
				end
		   select @snombre_base = '[' + @snombre_base + ']'


		   set @sQ = N'INSERT INTO @CARGOS_COMPLETO (MOV_TIPOPOL,MOV_CONSPOL,MOV_CONSMOV,MOV_MES,MOV_NUMCTA,MOV_DEBE,MOV_HABER,Tipo)'
		   set @sQ = @sQ + N' SELECT MOV_TIPOPOL,MOV_CONSPOL,MOV_CONSMOV,MOV_MES,MOV_NUMCTA,MOV_DEBE,MOV_HABER,''0'' as TIPO FROM ' + @ipServidor +ltrim(rtrim(@snombre_base)) + '.DBO.CON_MOVDET01' + Convert(char(4),@iAnio) + ' WHERE MOV_MES = @iMes AND MOV_NUMCTA = @noCtaContable AND MOV_DEBE <> 0 '		   
		   --SELECT *,Tipo='0' INTO #CARGOS_COMPLETO FROM GAAU_Universidad.DBO.CON_MOVDET012018  WHERE MOV_MES = 2 AND MOV_NUMCTA = '1100-0020-0001-0001' AND MOV_DEBE > 0
		   execute sp_executesql @sQ,N'@noCtaContable varchar(50),@iMes int',@noCtaContable=@noCtaContable,@iMes=@iMes

		   set @sQ = N'INSERT INTO	@CARGOSCOBROS (MOV_TIPOPOL,MOV_CONSPOL,MOV_CONSMOV,MOV_MES,MOV_NUMCTA,MOV_DEBE,MOV_HABER,Tipo)'
		   set @sQ = @sQ + N' SELECT MOV_TIPOPOL,MOV_CONSPOL,MOV_CONSMOV,MOV_MES,MOV_NUMCTA,MOV_DEBE,MOV_HABER,Tipo from #CARGOS_COMPLETO WHERE MOV_TIPOPOL  COLLATE Modern_Spanish_CS_AS in '
		   set @sQ = @sQ + N' (SELECT distinct Tipo_Poliza FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO  WHERE emp_idempresa = @iIdEmpresa  AND Tipo = 1) ' 
		   execute sp_executesql @sQ,N'@iIdEmpresa int',@iIdEmpresa=@iIdEmpresa
		   --BUSCO MOV POR TIPO ICCU,ICPE,ICCU ESTE VALOR ESTA PARAMETRIZADO EN LA TABLA 
			--SELECT Tipo_Poliza,* FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO  WHERE emp_idempresa = 1  AND Tipo = 1
			--SELECT * INTO #CARGOSCOBROS FROM  #CARGOS_COMPLETO WHERE MOV_TIPOPOL IN('ICCU','ICPE','ICUN')

		   --BUSCO LA CARTERA DE ESTOS PAGOS
		   set @sQ = N'INSERT INTO @CARTERA_COBROS (CCP_CONSCARTERA,CCP_TIPOPOL,CCP_CONSPOL,CCP_CONSMOV,CCP_MES,CCP_IDDOCTO,CCP_IDPERSONA)'
		   set @sQ = @sQ + N' SELECT CCP_CONSCARTERA,CCP_TIPOPOL,CCP_CONSPOL,CCP_CONSMOV,CCP_MES,CCP_IDDOCTO,CCP_IDPERSONA '			
		   set @sQ = @sQ + N' FROM #CARGOSCOBROS P INNER JOIN ' + @ipServidor + ltrim(rtrim(@snombre_base)) + '.DBO.CON_CAR01' + Convert(char(4),@iAnio) + ' ON MOV_CONSPOL = CCP_CONSPOL AND MOV_MES = CCP_MES'
		   set @sQ = @sQ + N' WHERE CCP_TIPOPOL COLLATE Modern_Spanish_CS_AS in '
		   set @sQ = @sQ + N' (SELECT distinct Tipo_Poliza FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO  WHERE emp_idempresa = @iIdEmpresa  AND Tipo = 1) '
		   set @sQ = @sQ + N' AND CCP_MES = @iMes AND CCP_TIPODOCTO in (''ANT'',''PCA'') '
		   execute sp_executesql @sQ,N'@iMes int,@iIdEmpresa int',@iIdEmpresa=@iIdEmpresa,@iMes=@iMes

		   --BUSCO LA CARTERA DE ESTOS PAGOS
			--SELECT CCP_CONSCARTERA,CCP_TIPOPOL,CCP_CONSPOL,CCP_CONSMOV,CCP_MES,CCP_IDDOCTO,CCP_IDPERSONA
			--INTO #CARTERA_COBROS
			--FROM #CARGOSCOBROS P INNER JOIN GAAU_Universidad.DBO.CON_CAR012018 ON MOV_CONSPOL = CCP_CONSPOL AND MOV_MES = CCP_MES
			--WHERE CCP_TIPOPOL IN('ICCU','ICPE','ICUN') AND CCP_MES = 2 AND CCP_TIPODOCTO IN('ANT','PCA')


		   --BUSCO LOS PAGOS POR TXT POR CUENTA, LA CUENTA ESTA PARAMETRIZADA POR BANCO
			set @sQ = N'INSERT INTO @DOCTOSCOBRADOS (rap_referencia,rap_idpersona, rap_iddocto,rap_cotped)'
			set @sQ = @sQ + N' SELECT rap_referencia,rap_idpersona, rap_iddocto,rap_cotped FROM [GA_Corporativa].[dbo].[cxc_refantypag] '
			set @sQ = @sQ + N' WHERE Year(rap_fecha)=@iAnio AND Month(rap_fecha)=@iMes '
			--set @sQ = @sQ + N' AND rap_numctabanc = @snoCuenta '
			set @sQ = @sQ + N' AND rap_numctabanc = ''00741820000195334667'' '			
			set @sQ = @sQ + N' AND rap_idstatus <> 1'
			set @sQ = @sQ + N' AND rap_idempresa = @iIdEmpresa'
			execute sp_executesql @sQ,N'@iIdEmpresa int,@iMes int, @iAnio int, @snoCuenta varchar(50)',@iIdEmpresa=@iIdEmpresa,@iMes=@iMes,@iAnio=@iAnio,@snoCuenta = @snoCuenta

			--SELECT * FROM #DOCTOSCOBRADOS
			--FROM GA_Corporativa.dbo.cxc_refantypag WHERE rap_fecha BETWEEN '01/02/2018' AND '28/02/2018 23:59:59.999' AND rap_idempresa = 1 
			--AND rap_numctabanc = '00741820000195334667' AND rap_idstatus <> 1

			--REGISTROS CONCILIADOS CONTROL DEPOSITOS
			insert INTO @COBROSCONCILIADOS_CONTROL (CCP_TIPOPOL,CCP_CONSPOL,CCP_MES)
			SELECT CCP_TIPOPOL,CCP_CONSPOL,CCP_MES 
			FROM @CARTERA_COBROS INNER JOIN @DOCTOSCOBRADOS ON CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS = rap_referencia COLLATE Modern_Spanish_CS_AS 
			AND CCP_IDPERSONA = rap_idpersona WHERE rap_cotped <> 'COTIZACION UNIVERSAL' GROUP BY  CCP_TIPOPOL,CCP_CONSPOL,CCP_MES

		--REGISTROS CONCILIADOS REFERENCIADOS
		
		INSERT INTO @COBROSCONCILIADOS_REFERENCIA (CCP_TIPOPOL,CCP_CONSPOL,CCP_MES)
		SELECT CCP_TIPOPOL,CCP_CONSPOL,CCP_MES FROM @CARTERA_COBROS INNER JOIN @DOCTOSCOBRADOS ON CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS = rap_iddocto COLLATE Modern_Spanish_CS_AS 
		AND CCP_IDPERSONA = rap_idpersona WHERE rap_cotped = 'COTIZACION UNIVERSAL' 


		--CAMBIO EL TIPO DE REGISTRO EN ##CARGOS_COMPLETO
		UPDATE A SET Tipo = '1' FROM @CARGOS_COMPLETO A
		INNER JOIN @COBROSCONCILIADOS_CONTROL C ON  MOV_TIPOPOL = CCP_TIPOPOL AND MOV_MES = CCP_MES AND MOV_CONSPOL = CCP_CONSPOL

		UPDATE A SET Tipo = '1' FROM @CARGOS_COMPLETO A
		INNER JOIN @COBROSCONCILIADOS_REFERENCIA C ON  MOV_TIPOPOL = CCP_TIPOPOL AND MOV_MES = CCP_MES AND MOV_CONSPOL = CCP_CONSPOL

		--CARGOS EN CONTABILIDAD NO CONSIDERADOS EN BANCOS Tipo=0
			select @dResultado = sum(MOV_DEBE) from @CARGOS_COMPLETO WHERE Tipo = @sConciliados
		--CARGOS EN CONTABILIDAD SI CONSIDERADOS EN BANCOS Tipo=1
	set nocount off
end --Del Store

/*
Declare
@iAnio int,
@iMes int,
@snoCuenta varchar(100),
@sConciliados varchar(1),
@dResultado numeric(18,6)

select @iAnio = 2018
select @iMes = 2
select @snoCuenta ='000000000195334667'  --'000000000195334667'  --Bancomer Suzuky  --Santander Suzuky 65504258249
select @sConciliados = '0' --0 No CONSIDERADOS en Bancos, 1 Si Considerados
select @dResultado = 0

--*******************************************
execute [SEL_CARGOSCONTABLES_NOBANCOS]  @iAnio, @iMes,@snoCuenta,@sConciliados, @dResultado Output
print 'Resultado: ' + CAST(CONVERT(varchar, CAST(@dResultado AS money), 1) AS varchar)

select * from referencias..BancoCuenta 1100-0020-0001-0001
  000000000195334667
 ******** ---->  00741820000195334667

*/
go

