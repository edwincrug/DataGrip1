-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 10/01/2019
-- Description:	Obtengo los datos del encabezado
-- ==========================================================================================
-- EXECUTE [dbo].[PPROV_SEL_COMPLEMENTO_ESTATUS_SP] '3b9dd10b-3322-4f84-9bbd-768fb8e9380x'
		
CREATE PROCEDURE [dbo].[PPROV_SEL_COMPLEMENTO_ESTATUS_SP]
				 @uuid 			 VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;	
    BEGIN TRY
		SELECT [id_Complemento]
			  ,[serie]
			  ,[folio]
			  ,[uuid]
			  ,[estatus]
		  FROM [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC]
         WHERE [uuid] = @uuid

	END TRY
	BEGIN CATCH
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 DECLARE @Mensaje  nvarchar(max),
		 @Componente nvarchar(50) = '[PPROV_SEL_COMPLEMENTO_ESTATUS_SP]'
		 SELECT @Mensaje = ERROR_MESSAGE()
		 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
		 SELECT 1  --Encontro error
	END CATCH
END
go

