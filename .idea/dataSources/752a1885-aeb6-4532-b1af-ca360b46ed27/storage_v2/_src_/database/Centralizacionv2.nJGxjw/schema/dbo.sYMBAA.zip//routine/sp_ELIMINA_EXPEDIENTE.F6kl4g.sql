
CREATE PROCEDURE [dbo].[sp_ELIMINA_EXPEDIENTE] (@folio VARCHAR(50))  
As
-- ======================================================================================================
--    DIGITALIZACIÓN Queries para eliminar un EXPEDIENTE completo.
--    Cuentas por Pagar CXP		proceso = 1
--	  Cuentas por Cobrar CXC	proceso = 2
-- ======================================================================================================
--DECLARE @folio VARCHAR(20) = 'AU-AU-UNI-SE-PE-488'
DECLARE @proceso INT
DECLARE @iResultado int

begin 
set nocount on

select @iResultado=0
				
-- Verifico si es CXP o CXC
IF (EXISTS(SELECT * FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE [oce_folioorden] = @folio))
	BEGIN
		SET @proceso = 1
		--SELECT 'Cuentas por Pagar'
	END
ELSE IF (EXISTS (SELECT * FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE [ucu_foliocotizacion] = @folio))
	BEGIN
		SET @proceso = 2
		--SELECT 'Cuentas por Cobrar'
	END
	
	
BEGIN TRANSACTION eliminaexp	
	
DELETE
  FROM [Centralizacionv2].[dbo].[DIG_EXPEDIENTE]
 WHERE [Folio_Operacion] = @folio 
   AND [Proc_Id] = @proceso 

DELETE  
 FROM [Centralizacionv2].[dbo].[DIG_EXP_NODO]     
WHERE [Folio_Operacion] = @folio
  AND [Proc_Id] =  @proceso 

DELETE 
 FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
WHERE [Folio_Operacion] = @folio 
  AND [Proc_Id] = @proceso
  
		select @iResultado=1

COMMIT TRANSACTION eliminaexp
	Return @iResultado
	select @iResultado
set nocount off
end
go

