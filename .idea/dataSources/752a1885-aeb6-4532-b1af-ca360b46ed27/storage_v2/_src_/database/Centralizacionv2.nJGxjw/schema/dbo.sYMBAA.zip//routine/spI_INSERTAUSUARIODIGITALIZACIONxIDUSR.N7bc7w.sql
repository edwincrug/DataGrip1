/*

*/

CREATE PROCEDURE [dbo].[spI_INSERTAUSUARIODIGITALIZACIONxIDUSR](@iIdUsr int,@sNomBase nvarchar(20), @sOPCION varchar(50),@sCSVDeptos varchar(200),@iResultado int OUTPUT) --with recompile
 AS
declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
--@iIdUsr int,
@sIp nvarchar(20),
@sNomBaseConcentra nvarchar(20),
@iIdEmpresa int,
@iIdSucursal int,
@ipLocal VARCHAR(50),
@sAuxIP varchar(50)
begin 

set nocount on

Declare @sUsr3letras varchar(10);
--Declare @iUsu_idusuario int;
--select @iUsu_idusuario = 0;

Select @sIP = ip_servidor,@iIdEmpresa = emp_idempresa, @iIdSucursal = suc_idsucursal from Centralizacionv2..DIG_CAT_BASES_BPRO where nombre_base = @sNomBase
--validar si se corre en el servidor local
SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC

if (@ipLocal = @sIP)
begin   
	   select @sAuxIP = ''
end
else
begin	   
	   select @sAuxIP = '[' + @sIP + '].'
end

set @sQ = N'select @iIdUsrOUT = usu_idusuario from ControlAplicaciones..cat_usuarios where usu_nombreusu like ' + char(39) + char(37) + @sUsr3letras  + char(37) + char(39) 
SET @sParmDefinition = N'@iIdUsrOUT int OUTPUT';
print @sQ;

--select @iIdUsr = -1;
--EXECUTE sp_executesql @sQ, @sParmDefinition, @iIdUsrOUT=@iIdUsr OUTPUT;  
Select 'Usuario Id ' + Convert(char(5),@iIdUsr)

--select @iIdUsr = 71;

if (@iIdUsr=-1)
	begin  --No encontró el usario hay que darlo de alta.
			print 'No se encontró al asuario en: ' + @sQ;
			print 'se dará de alta'
		
				Declare @sAux varchar(5);
				select @sAux = ltrim(rtrim(Convert(char(3),@iIdSucursal))) + @sUsr3letras  
				--consultamos el nombre desde la base de BPRo.
				Declare @sUSU_APUSUARI varchar(50) = '';
				Declare @sUSU_AMUSUARI varchar(50) = '';
				Declare @sUSU_NOUSUARI varchar(50) = '';
				Declare @sUSU_CVEACCES varchar(20) = null;
				
				set @sQ = N'select @sUSU_APUSUARIOUT = USU_APUSUARI,@sUSU_AMUSUARIOUT = USU_AMUSUARI,@sUSU_NOUSUARIOUT = USU_NOUSUARI,@sUSU_CVEACCESOUT = USU_CVEACCES from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_USUARIOS] where usu_idusuari = ' + char(39) + @sUsr3letras + char(39) 
				SET @sParmDefinition = N'@sUSU_APUSUARIOUT varchar(50) OUTPUT, @sUSU_AMUSUARIOUT varchar(50) OUTPUT, @sUSU_NOUSUARIOUT varchar(50) OUTPUT, @sUSU_CVEACCESOUT varchar(20) OUTPUT';
				print @sQ
				EXECUTE sp_executesql @sQ, @sParmDefinition, @sUSU_APUSUARIOUT=@sUSU_APUSUARI OUTPUT,@sUSU_AMUSUARIOUT = @sUSU_AMUSUARI OUTPUT,@sUSU_NOUSUARIOUT = @sUSU_NOUSUARI OUTPUT, @sUSU_CVEACCESOUT = @sUSU_CVEACCES OUTPUT; 


			if (@sUSU_APUSUARI<>'' and @sUSU_NOUSUARI<>'')	
			begin

			INSERT INTO [ControlAplicaciones].[dbo].[cat_usuarios]
					   ([gpo_idgrupo]
					   ,[div_iddivision]
					   ,[emp_idempresa]
					   ,[suc_idsucursal]
					   ,[dep_iddepartamento]
					   ,[usu_nombreusu]
					   ,[usu_paterno]
					   ,[usu_materno]
					   ,[usu_nombre]
					   ,[usu_correo]
					   ,[usu_contrasenia]
					   ,[pto_idpuesto]
					   ,[usu_fechaalta]
					   ,[usu_usualta]
					   ,[usu_fechamodifica]
					   ,[usu_usumodifica]
					   ,[usu_estatus]
					   ,[usu_passbpro])
				 VALUES
					   (1,1,
					   @iIdEmpresa, 
					   @iIdSucursal, 
					   0,
					   ltrim(rtrim(@sAux)),
					   ltrim(rtrim(@sUSU_APUSUARI)), --,<usu_paterno, varchar(50),>
					   ltrim(rtrim(@sUSU_AMUSUARI)), --,<usu_materno, varchar(50),>
					   ltrim(rtrim(@sUSU_NOUSUARI)), --,<usu_nombre, varchar(70),>
					   'porconfirmar-sp@hotmail.com',
					   '8cb2237d0679ca88db6464eac60da96345513964', --12345
						0,
						getdate(),--,<usu_fechaalta, datetime,>
						0,		  --,<usu_usualta, int,>
						getdate(),--,<usu_fechamodifica, datetime,>
						0,		  --,<usu_usumodifica, int,>
						1,        --,<usu_estatus, int,>
						@sUSU_CVEACCES)     --,<usu_passbpro, varchar(20),>)
						select @iIdUsr = @@IDENTITY 
						print 'se creo el usuario en  ControlAplicaciones..cat_usuarios ' + ltrim(rtrim(@sAux)) + ' id:' + ltrim(rtrim(Convert(char(5),@iIdUsr)))
			   end --del insert
end --del @iIdUsr=-1
--else
--begin
--   print 'No se encontró al asuario en: ' + @sQ;
--   select @iIdUsr=-1
--end

			-- DadoDeAlta el usuario lo agregamos a Digitalizacion, menus etc.
			--select * from ControlAplicaciones..ope_organigrama where usu_idusuario=617 order by org_idorganigrama
			Declare @isis_idsistema int;
			if (@sOPCION='CXP')
			   begin 
			      select @isis_idsistema = 3;
			   end
			if (@sOPCION = 'CXC')
			   begin
			      select @isis_idsistema = 4
			   end
			if (@sOPCION = 'AMBOS')
			   begin 
			      select @isis_idsistema = 3;
			   end

if (@iIdUsr>-1)
begin
		 if Not Exists(Select 1 from  [ControlAplicaciones].[dbo].[ope_organigrama] where usu_idusuario = @iIdUsr and emp_idempresa = @iIdEmpresa and suc_idsucursal = @iIdSucursal) 
		 begin
		  set @sQ = N'	INSERT INTO [ControlAplicaciones].[dbo].[ope_organigrama]'
	      set @sQ = @sQ + N'([sis_idsistema]'
		  set @sQ = @sQ + N',[gpo_idgrupo]'
		  set @sQ = @sQ + N',[div_iddivision]'
					   set @sQ = @sQ + N',[emp_idempresa]'
					   set @sQ = @sQ + N',[suc_idsucursal]'
					   set @sQ = @sQ + N',[dep_iddepartamento]'
					   set @sQ = @sQ + N',[usu_idusuario]'
					   set @sQ = @sQ + N',[org_fechaalta]'
					   set @sQ = @sQ + N',[org_usualta]'
					   set @sQ = @sQ + N',[org_fechamodifica]'
					   set @sQ = @sQ + N',[org_usumodifica]'
					   set @sQ = @sQ + N',[org_estatus])'
		set @sQ = @sQ + N'select '
		set @sQ = @sQ + N' ' + ltrim(rtrim(convert(char(5),@isis_idsistema))) + ',' --<sis_idsistema, int,>
		set @sQ = @sQ + N' 1,' --<gpo_idgrupo, int,>
		set @sQ = @sQ + N' 1,' --<div_iddivision, int,>
		set @sQ = @sQ + N' ' + ltrim(rtrim(convert(char(5),@iIdEmpresa))) +  ','  --<emp_idempresa, int,>
		set @sQ = @sQ + N' ' + ltrim(rtrim(convert(char(5),@iIdSucursal))) + ',' --<suc_idsucursal, int,>
		set @sQ = @sQ + N' dep_iddepartamento,' --,<dep_iddepartamento, int,>
		set @sQ = @sQ + N' ' + ltrim(rtrim(convert(char(5),@iIdUsr))) + ',' --<usu_idusuario, int,>
		set @sQ = @sQ + N' getdate(),' --<org_fechaalta, datetime,>
		set @sQ = @sQ + N' 1,' --<org_usualta, int,>
		set @sQ = @sQ + N' getdate(),' --<org_fechamodifica, datetime,>
		set @sQ = @sQ + N' 1,' --<org_usumodifica, int,>
		set @sQ = @sQ + N' 1 ' --<org_estatus, int,>)
		set @sQ = @sQ + N' from ControlAplicaciones..cat_departamentos where emp_idempresa = ' + ltrim(rtrim(convert(char(5),@iIdEmpresa))) + ' and suc_idsucursal=' + ltrim(rtrim(convert(char(5),@iIdSucursal))) + ' and dep_nombrecto in (' + @sCSVDeptos + ')'
		print @sQ
		EXECUTE sp_executesql @sQ

					   print 'Se insertó el organigrama [ControlAplicaciones].[dbo].[ope_organigrama]'
				end
				if Not Exists(select 1 from ControlAplicaciones..rel_usuarioperfil where usu_idusuario=@iIdUsr)
				begin
					   --SELECT * FROM ControlAplicaciones..rel_usuarioperfil where usu_idusuario=617
					   insert into ControlAplicaciones..rel_usuarioperfil (per_idperfil,usu_idusuario,sis_idsistema )
					   values (4,@iIdUsr,@isis_idsistema)

					   if  (@sOpcion='AMBOS')
					   begin
					       if (@isis_idsistema=3)
						     begin
							   select @isis_idsistema = 4
							 end
							else
							 begin
						   		if (@isis_idsistema=4)
								begin
									select @isis_idsistema = 3
								end
							 end

						   insert into ControlAplicaciones..rel_usuarioperfil (per_idperfil,usu_idusuario,sis_idsistema )
						   values (5,@iIdUsr,@isis_idsistema)
					   end

					   --este es el que le da acceso a Digitalizacion
					   insert into ControlAplicaciones..rel_usuarioperfil (per_idperfil,usu_idusuario,sis_idsistema )
					   values (6,@iIdUsr,5)
					   print 'Se creo el perfil: ControlAplicaciones..rel_usuarioperfil'
				end

				if Not Exists(select 1 from Seguridad..SEG_USUARIO_PERFIL where sup_idUsuario = @iIdUsr)
				begin
					   --le ponemos el menu más basico de Digitalización
					   Declare @iSiguiente int = 0;
					   select @iSiguiente = Max(sup_idUsuarioPerfil)+1 from Seguridad..SEG_USUARIO_PERFIL
					   insert into Seguridad..SEG_USUARIO_PERFIL (sup_idUsuarioPerfil,sup_idUsuario,sup_idPerfil)
					   values (@iSiguiente,@iIdUsr,1)					   
				end
		select @iResultado = @iIdUsr; 
	end

set nocount off
end
/*
Declare @iUsu_idusuario int = 2155;
Declare @sNomBase nvarchar(20) = 'GAAutoAngarTlahuac';
Declare  @sOPCION varchar(50) = 'AMBOS'; --'CXP'| 'CXC'
Declare @sCSVDeptos varchar(200) = char(39) + 'UN' + char(39) + ',' + char(39) + 'US' + char(39) + ',' + char(39) + 'RE' + char(39) + ',' + char(39) + 'SE' + char(39) + ',' + char(39) + 'OT' + char(39)
--Declare @sCSVDeptos varchar(200) = char(39) + 'UN' + char(39) + ',' + char(39) + 'OT' + char(39) 
--Declare @sCSVDeptos varchar(200) = char(39) + 'UN' + char(39) + ',' + char(39) + 'US' + char(39) + ',' + char(39) + 'OT' + char(39)

DECLARE @iResultado int = -1;

Execute spI_INSERTAUSUARIODIGITALIZACIONxIDUSR @iUsu_idusuario,@sNomBase, @sOPCION,@sCSVDeptos, @iResultado OUTPUT
print 'Usuario dado de alta con el id: ' + ltrim(rtrim(Convert(char(5),@iResultado)))

select * from ControlAplicaciones..cat_usuarios where  usu_nombreusu like '%18VFG%'

--Borro todo su organigrama de un usuario
delete [ControlAplicaciones].[dbo].[ope_organigrama] where usu_idusuario = 2155

select * from Centralizacionv2..DIG_CAT_BASES_BPRO

Declare @sCSVDeptos varchar(200) = char(39) + 'UN' + char(39) + ',' + char(39) + 'US' + char(39) + ',' + char(39) + 'RE' + char(39) + ',' + char(39) + 'SE' + char(39) + ',' + char(39) + 'OT' + char(39)					
print @sCSVDeptos
select * from ControlAplicaciones..cat_departamentos where emp_idempresa = 1 and suc_idsucursal=3 and dep_nombrecto in ('UN','SE','OT')




Select * from  [ControlAplicaciones].[dbo].[ope_organigrama] where usu_idusuario = 71

*/
go

