

CREATE PROCEDURE [dbo].[PROV_SEL_VALIDA_CUENTA_BANCARIA_ACTIVA_SP]
     @rfc VARCHAR(20) 
	
AS
BEGIN

--	DECLARE  @rfc VARCHAR(20)  = 'GOAM761120C8A'
	

	BEGIN TRY
	SET NOCOUNT ON;

    DECLARE @aux               INT = 1
	DECLARE @max               INT = 0
	DECLARE @idEmpresaBusca    INT = 0
	DECLARE @idSucursal        INT = 0
	DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
	DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @nomBaseSucursal  NVARCHAR(50) =NULL
	DECLARE @nomEmpresa        NVARCHAR(100)=NULL
	DECLARE @ipServidor        NVARCHAR(100)=NULL
	DECLARE @cadIpServidor     NVARCHAR(100)=NULL
	DECLARE @consulta          NVARCHAR(MAX)=NULL
	DECLARE @consultaIntercambio          NVARCHAR(MAX)=NULL

	DECLARE @ipServer		   NVARCHAR(20)
	
	DECLARE @existeCuenta TABLE  (  IDB INT IDENTITY(1,1),
								    idEmpresa         int
								   ,nombreEmpresa     nvarchar(100)
								   ,idProveedor       int 
								  )   
								  
	DECLARE @tblPersonas as TABLE
	(
		 id int IDENTITY(1,1)
		,idPersona numeric(18,0)
	)

	
	INSERT INTO @tblPersonas
	SELECT PER_IDPERSONA FROM GA_CORPORATIVA.DBO.PER_PERSONAS WHERE PER_RFC = @rfc

    ------------------------------------------------------------
	-- BUSCAMOS EN TODAS LAS CONCENTRADORAS
	------------------------------------------------------------	
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
	                        idEmpresa         int
							,nombreEmpresa     nvarchar(100)
							,nombreSucursal    nvarchar(100)
							,nomBaseConcentra  nvarchar(50)
							,nomBaseMatriz     nvarchar(50)
							,ipServidor        nvarchar(20)
							,idSucursal        int 
							)    
	
	 DECLARE @BasesSucursal TABLE  ( IDB INT IDENTITY(1,1),
	                        idEmpresa         int
							,nombreEmpresa     nvarchar(100)
							,nombreSucursal    nvarchar(100)
							,nomBaseSucursal  nvarchar(50)
							,nomBaseMatriz     nvarchar(50)
							,ipServidor        nvarchar(20)
							,idSucursal        int 
							)     

	 INSERT INTO @Bases
            SELECT B.[emp_idempresa]
			      ,A.[emp_nombre]
			      ,B.[nombre_sucursal]
				  ,B.[nombre_base]
				  ,B.[nombre_base_matriz]
				  ,B.[ip_servidor]
				  ,B.[sucursal_matriz]
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
			       INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON A.[emp_idempresa]= B.[emp_idempresa]
			WHERE B.tipo = 2
			  --AND B.[emp_idempresa] <> @idEmpresa

     --SELECT * FROM @Bases

	  INSERT INTO @BasesSucursal
            SELECT B.[emp_idempresa]
			      ,A.[emp_nombre]
			      ,B.[nombre_sucursal]
				  ,B.[nombre_base]
				  ,B.[nombre_base_matriz]
				  ,B.[ip_servidor]
				  ,B.[sucursal_matriz]
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
			       INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON A.[emp_idempresa]= B.[emp_idempresa]
			WHERE B.tipo = 1

	
	 ------------------------------------------------------------
	 -- RECORREMOS LAS CONCENTRADORAS PARA BUSCAR EL PROVEEDOR
	 ------------------------------------------------------------
	 DECLARE @cont int = 1
			 ,@idPer numeric(18,0)
	 SET @max = (SELECT count(IDB) FROM @Bases)
	 
	 WHILE(@cont<= (select count(1) FROM @tblPersonas ))
	 BEGIN
		select @idPer = idPersona from @tblPersonas where id = @cont

		 WHILE(@aux <= @max)
			 BEGIN
	 
				 --SELECT @aux
				 SELECT  @idEmpresaBusca   = DB.idEmpresa 
						,@nomEmpresa       = DB.nombreEmpresa
						,@nomBaseConcentra = DB.nomBaseConcentra
						,@nomBaseMatriz    = DB.nomBaseMatriz
						,@idSucursal       = DB.idSucursal
						,@ipServidor       = DB.ipServidor
				
				   FROM @Bases AS DB 
				  WHERE DB.IDB = @aux 

				  SET @cadIpServidor = '['+ @ipServidor  +'].'
		  
				  SELECT @ipServer = local_net_address
				  FROM sys.dm_exec_connections
				  WHERE Session_id = @@SPID
		
		
				IF (@ipServidor = @ipServer)
				BEGIN
				set @cadIpServidor =''
				END
	

				IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @nomBaseConcentra)) 
				BEGIN
		
					SET @consulta = ' SELECT  ' + cast (@idEmpresaBusca as varchar(20)) +' ,' +''''+ @nomEmpresa +'''' + '          
											 ,BCO_IDPERSONA          
										FROM '+ @cadIpServidor + @nomBaseConcentra +'.DBO.CON_BANCOS ' + 
									' WHERE BCO_IDPERSONA = ' + CONVERT(VARCHAR(20), @idPer) +'
									AND BCO_AUTORIZADA = 1 '
									--' WHERE BCO_IDPERSONA = ' + cast (@idProveedor as varchar(20)) 

				  --PRINT @consulta
				  INSERT INTO @existeCuenta
						 EXECUTE (@consulta)
				END
				  --SELECT @cadIpServidor
				 SET @aux = @aux + 1
			 END
	 SET @cont = @cont + 1
	 END

	 ------------------------------------------------------------
	 -- RECORREMOS LAS SUCURSALES PARA BUSCAR EL PROVEEDOR INTERCAMBIO
	 ------------------------------------------------------------
	 SET @cont  = 1
	 SET @aux = 1
			
	 SET @max = (SELECT count(IDB) FROM @BasesSucursal)
	 
	 WHILE(@cont<= (select count(1) FROM @tblPersonas ))
	 BEGIN
		select @idPer = idPersona from @tblPersonas where id = @cont

		 WHILE(@aux <= @max)
			 BEGIN
	 
				 --SELECT @aux
				 SELECT  @idEmpresaBusca   = DB.idEmpresa 
						,@nomEmpresa       = DB.nombreEmpresa
						,@nomBaseSucursal =  DB.nomBaseSucursal
						,@nomBaseMatriz    = DB.nomBaseMatriz
						,@idSucursal       = DB.idSucursal
						,@ipServidor       = DB.ipServidor
				
				   FROM @BasesSucursal AS DB 
				  WHERE DB.IDB = @aux 

				  SET @cadIpServidor = '['+ @ipServidor  +'].'
		  
				  SELECT @ipServer = local_net_address
				  FROM sys.dm_exec_connections
				  WHERE Session_id = @@SPID
		
		
				IF (@ipServidor = @ipServer)
				BEGIN
				set @cadIpServidor =''
				END
	

				IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @nomBaseSucursal)) 
				BEGIN
				
					
					SET @consulta = ' SELECT  ' + cast (@idEmpresaBusca as varchar(20)) +' ,' +''''+ @nomEmpresa +'''' + '          
											 ,ROL_IDPERSONA          
										FROM '+ @cadIpServidor + @nomBaseSucursal +'.dbo.PER_ROLES ' + 
									' WHERE ROL_IDPERSONA = ' + CONVERT(VARCHAR(20), @idPer) +'
									AND ROL_ROL = ''INTER'' '
									--' WHERE BCO_IDPERSONA = ' + cast (@idProveedor as varchar(20)) 
				  --PRINT @consulta
				  INSERT INTO @existeCuenta
						 EXECUTE (@consulta)
				END
				  --SELECT @cadIpServidor
				 SET @aux = @aux + 1
			 END
	 SET @cont = @cont + 1
	 END
	--SELECT * FROM @existeCuenta
	 ------------------------------------------------------------
	 -- RESULTADO FINAL
	 ------------------------------------------------------------

	 IF NOT EXISTS(SELECT 1 FROM @existeCuenta)
			BEGIN
				SELECT 1 AS estatus,'No tiene cuentas activas y tampoco es proveedor de intercambio' AS msj
			END
     ELSE
	        BEGIN
				SELECT top 1	0 AS estatus
						,'Ya tiene cuentas activas o el proveedor es de intercambio' AS msj
						, nombreEmpresa AS empresa
						, idProveedor AS idProveedor
						,RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre  
				FROM	@existeCuenta AS C
						INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS P ON C.idProveedor = P.PER_IDPERSONA
			END
	 
	   
	END TRY

    BEGIN CATCH
	select 'Error'
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'PROV_SEL_VALIDA_CUENTA_BANCARIA_ACTIVA_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END

go

