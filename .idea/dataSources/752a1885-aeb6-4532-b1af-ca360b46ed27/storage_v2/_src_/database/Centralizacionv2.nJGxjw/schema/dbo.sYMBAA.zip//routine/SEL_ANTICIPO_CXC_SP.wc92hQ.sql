/*
 
 [dbo].[SEL_ANTICIPO_CXC_SP] @folio =  'AU-ZM-NZA-UN-29'-- 'AU-AU-UNI-UN-42' 

 */
CREATE PROCEDURE [dbo].[SEL_ANTICIPO_CXC_SP] 
	@folio    NVARCHAR(50) = ''
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY

	DECLARE @idCotizacion   INT = 0;
	DECLARE @idEmpresa      INT = 0;
	DECLARE @idSucursal     INT = 0;
	DECLARE @rfc            VARCHAR(30) = 0;
	DECLARE @nomBaseMatriz  VARCHAR(30) = 0;
	DECLARE @query          NVARCHAR(MAX) = null

	DECLARE @ipServidor        NVARCHAR(100);
	DECLARE @cadIpServidor     NVARCHAR(200);

	---------------------------------------------------------------
	--  Obtenemos la consulta dinamicamente                      --
	---------------------------------------------------------------
	DECLARE @VariableTabla TABLE (PAM_IDDOCTO	nvarchar(30)
									,serie	        nvarchar(10)
									,folio	        nvarchar(20)
									,rfcEmisor	    nvarchar(30)
								  )
	
	DECLARE @Sucursales TABLE(id INT IDENTITY(1,1)
							  , nombre VARCHAR(50)
							  , ipServidor VARCHAR(20)
							  )   	
		
	SELECT @idCotizacion  = ucu_idcotizacion 
		       ,@idEmpresa    = ucu_idempresa
			   ,@idSucursal   = ucu_idsucursal
	FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
	WHERE ucu_foliocotizacion = @folio

	SELECT @rfc = rfc
		        ,@nomBaseMatriz = nombre_base_matriz
				,@ipServidor = ip_servidor
		   FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
	WHERE catsuc_nombrecto = 'CONCENTRA'
          AND emp_idempresa    = @idEmpresa
    
	INSERT INTO @Sucursales
	SELECT nombre_base, ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE tipo = 1 AND emp_idempresa = @idEmpresa


        SET @cadIpServidor = '[' + @ipServidor + '].'
		
        --SELECT  @cadIpServidor, @nombreBase
		--SELECT @rfc,@nomBaseMatriz 

		/*
		SET @query = ' SELECT D.CCP_IDDOCTO         AS idNotaCredito '+
							  ',(SELECT dbo.[fn_BuscaLetras](D.CCP_IDDOCTO ))  AS serie '+
							  ',(SELECT dbo.[fn_BuscaNumeros](D.CCP_IDDOCTO )) AS folio '+
							  ','+''''+ @rfc+''''+' AS rfcEmisor '+
						'FROM [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSAL] AS A '+ 
							   'INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] B ON A.ucu_idcotizacion=B.ucu_idcotizacion '+
							   'INNER JOIN '+ @cadIpServidor + @nomBaseMatriz +'.dbo.ADE_VTAFI C   ON C.VTE_TIPODOCTO= '+''''+'A'+''''+' AND C.VTE_STATUS= '+''''+'I'+''''+' AND B.ucn_noserie=C.VTE_SERIE '+
							   'LEFT JOIN '+ @cadIpServidor + @nomBaseMatriz +'.dbo.VIS_CONCAR01 D ON CCP_TIPODOCTO= '+''''+'NCRBON'+''''+' AND CCP_REFERNCRBONI = C.VTE_DOCTO   '+
					   'WHERE A.ucu_foliocotizacion ='+''''+ @folio +''''+' AND D.CCP_IDDOCTO IS NOT NULL AND D.CCP_IDDOCTO <> '+''''+''''
        */		

		/*
		SELECT PAM_IDDOCTO FROM [192.168.20.31].GAAU_Universidad_P.dbo.CXC_PAGANT P 
		INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal U ON P.PAM_IDCOTIZACIONWEB = U.ucu_idcotizacion 
		WHERE u.ucu_foliocotizacion = 'AU-AU-UNI-UN-44' AND PAM_TIPODOCTO = 'ANT'
		*/
		DECLARE @aux INT = 1, @max INT = 0
		SELECT @max = MAX(id) FROM @Sucursales

		WHILE @aux <= @max 
		 BEGIN

				SELECT @cadIpServidor = ipServidor, @nomBaseMatriz =nombre FROM @Sucursales WHERE id = @aux

				SET @query =  'SELECT PAM_IDDOCTO ' + 
							  ',(SELECT dbo.[fn_BuscaLetras](PAM_IDDOCTO))  AS serie ' +
							  ',(SELECT dbo.[fn_BuscaNumeros](PAM_IDDOCTO)) AS folio ' +
							  ','+''''+ @rfc+''''+' AS rfcEmisor '+
							  'FROM ['+ @cadIpServidor + '].[' + @nomBaseMatriz +'].dbo.CXC_PAGANT P ' +
							  'INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal U ON P.PAM_IDCOTIZACIONWEB = U.ucu_idcotizacion ' +					  
							  'WHERE u.ucu_foliocotizacion = ''' + @folio + ''' AND PAM_TIPODOCTO = ''ANT'''
				
				print @query

				INSERT INTO  @VariableTabla
				EXECUTE (@query);
				--SELECT 'MK000007405','AA','15070','ZMO841221BJ4'
				--UNION
				--SELECT 'MK000007408','AA','15070','ZMO841221BJ4'
				SET @aux =  @aux + 1
		END

        SELECT PAM_IDDOCTO
			  ,serie	        
			  ,folio	        
			  ,rfcEmisor	     
	    FROM @VariableTabla

	END TRY

	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_ANTICIPO_CXC_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END
go

