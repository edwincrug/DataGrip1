
-- [dbo].[SEL_PERMISOS_TRAMITES_SP] 'AU-AA-AAZ-OT-PE-189'
CREATE PROCEDURE [dbo].[SEL_PERMISOS_TRAMITES_SP] 
	@folio VARCHAR(50)
AS
BEGIN
	DECLARE @BaseLocal				VARCHAR(100)
			,@consultaTramites		VARCHAR(max)
			,@ipBase				VARCHAR(20)

	SELECT	@ipBase= local_net_address
	FROM	sys.dm_exec_connections c
	WHERE	c.session_id = @@SPID

	SELECT	@BaseLocal = (CASE	WHEN ip_servidor = @ipBase THEN '[' + nombre_base + '].[dbo].'
								ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END)
	FROM	DIG_CAT_BASES_BPRO AS BPRO
			INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] AS O ON BPRO.suc_idsucursal = O.oce_idsucursal
	WHERE	O.oce_folioorden = @folio
	--SELECT @BaseLocal

	DECLARE  @tblTramites AS TABLE
	(
		STR_IDSUBTRAM INT
	)



	DECLARE @cont INT = 1
	DECLARE @noTramite INT = (SELECT COUNT(1) FROM dbo.DIG_CAT_TRAMITES_COT WHERE estatus = 1)
	DECLARE @tramite VARCHAR(50)

	WHILE(@cont <= @noTramite)
	BEGIN

	SELECT @tramite = tramite FROM (
	SELECT  ROW_NUMBER() OVER(ORDER BY tramite ASC) AS rowId
			,tramite 
	FROM	dbo.DIG_CAT_TRAMITES_COT 
	WHERE estatus = 1) A WHERE rowId = @cont

	SET @consultaTramites = 'SELECT STR_IDSUBTRAM FROM ' + char(13) +
										'( ' + char(13) +
										'SELECT ST.STR_IDSUBTRAM,PAR_DESCRIP1 FROM ' + @BaseLocal + '[CXC_SUBTRAMITE] ST ' + char(13) +
										'INNER JOIN ' + @BaseLocal + 'PNC_PARAMETR P ON P.PAR_IDENPARA = ST.STR_TRAMITE ' + char(13) +
										'WHERE (PAR_TIPOPARA = '+char(39)+'COCOCXC'+char(39)+') ' + char(13) +
										'AND (PAR_STATUS = '+char(39)+'A'+char(39)+') ' + char(13) +
										'AND PAR_IDENPARA IN ( ' + char(13) +
										'					SELECT PAR_IDENPARA ' + char(13) +
										'					FROM ' + @BaseLocal + 'PNC_PARAMETR ' + char(13) +
										'					WHERE PAR_TIPOPARA = '+char(39)+'COCOCXCCAR'+char(39)+' ' + char(13) +
										'					AND PAR_STATUS = '+char(39)+'A'+char(39)+' ' + char(13) +
										'					AND PAR_DESCRIP2 IN (SELECT PAR_IDENPARA ' + char(13) +
										'										FROM ' + @BaseLocal + 'PNC_PARAMETR ' + char(13) +
										'										WHERE PAR_TIPOPARA = '+char(39)+'CARTERA'+char(39)+' ' + char(13) +
										'										AND par_idmodulo = '+char(39)+'CXP'+char(39)+' AND PAR_STATUS = '+char(39)+'A'+char(39)+')' + char(13) +
										'					) ' + char(13) +
										') A WHERE A.PAR_DESCRIP1 LIKE '+char(39)+'%'+@tramite+'%'+char(39)+' COLLATE Traditional_Spanish_ci_ai' 



	PRINT @consultaTramites
	INSERT INTO @tblTramites
	EXEC (@consultaTramites)


	set @cont = @cont + 1


	END

	IF EXISTS(SELECT 1 FROM cuentasporcobrar.dbo.uni_anticiposweb WHERE STR_IDSUBTRAM IN (SELECT STR_IDSUBTRAM FROM  @tblTramites) AND UAW_FOLIOORDENCOMPRAOT = @folio )
	BEGIN
		SELECT 1 AS respuesta, 'Puede confirmar sin factura' AS mensaje
	END
	ELSE
	BEGIN 
		SELECT 0 AS respuesta, 'No Puede confirmar sin factura' AS mensaje
	END
END
go

