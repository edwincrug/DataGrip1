
--SEL_CARGA_ARCHIVO_RECEPCION_SP @idUsuario = 297, @folio = 'AU-AU-UNI-RE-IF-420'

CREATE PROCEDURE [dbo].[SEL_CARGA_ARCHIVO_RECEPCION_SP]
@idUsuario INT = 0,
@folio VARCHAR(50) = ''
AS
BEGIN
	
	DECLARE @activo INT = 1, @mensaje VARCHAR(200) = ''
		
	--validar que el archivo exista fisicamente
		
	DECLARE @Archivo varchar(255) = 'E:\GA_Centralizacion\CuentasXPagar\Cargas\' + @folio + '\15.pdf'
	DECLARE @Existe int
	EXEC Master.dbo.xp_fileexist @Archivo , @Existe OUT
	--IF @Existe = 1
	--PRINT 'Existe el archivo'
	--ELSE PRINT 'No existe el archivo'		

	IF(@Existe = 0)
		BEGIN
		   print ''
		   /*
			UPDATE DIG_EXPNODO_DOC 
			SET Fecha_Creacion = NULL, 
				Doc_Extencion = NULL
			WHERE Folio_Operacion = @folio 
			  AND Doc_Id = 15 
			 */ --AND Nodo_Id = 7
		END
	
	--LQMA comentado 21072017, se omite validacion, todos pueden subir todo en cualquier momento
	--si el documento ha sido subido ya, y el usuario no esta en la tabla SEG_CENTRALIZACION, no podra subirlo
	/*IF EXISTS(SELECT * FROM DIG_EXPNODO_DOC WHERE Folio_Operacion = @folio AND Doc_Id = 15 AND Nodo_Id = 7 AND Fecha_Creacion IS NOT NULL)
		BEGIN
		    SET @mensaje = 'Ya se ha subido el documento. Solo usuarios con permisos pueden reemplazar.'
			SET @activo = 0
		END	
	*/

	--LQMA comentado 21072017, se omite validacion, todos pueden subir todo en cualquier momento
	--si el usuario esta en la tabla SEG_CENTRALIZACION, podra subir documento siempre que 
	--la orden no este en documentacion completa (sod_idsituacionorden < 10) 
	--LQMA 21072017 comentado, se quito la valiacion de que se pueda 
	/*IF NOT EXISTS ( SELECT * FROM Seguridad..SEG_CENTRALIZACION 
				    WHERE seg_idUsuario = @idUsuario 
							AND seg_idAccion = 4  -- Subir Comprobante Recepcion
							AND seg_idModulo = 1  -- Factura
							AND seg_idPortal = 1) -- Digitalizacion
		BEGIN						
			SET @activo = 0
			SET @mensaje = 'Solo usuarios con permiso pueden reemplazar el archivo de Recepción.'
		END
	ELSE
		BEGIN
			SET @activo = 1
			SET @mensaje = 'Usuario con permisos para reemplazar Comprobante de Recepción.'
		END*/
	--si documentacion completa, ya no pueden subir ningun usuario el comprobante
	IF EXISTS( SELECT 1 FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @folio AND sod_idsituacionorden IN (3,4,10,11,12,13,16)) --IN(3,4,10,11,12,13,16,18) 
		BEGIN
			SET @activo = 0
			SET @mensaje = 'Documentación completa, ya no se puede reemplazar el comprobante.'
		END 

	--LQMA add 19072017 si el documento esta en situacion = 4 (cancelado), ya no se debe poder sustituir ni confirmar
	IF (SELECT sod_idsituacionorden FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @folio) = 4 --cancelado
		 BEGIN
			SELECT @activo = 2, @mensaje = 'La Orden ha sido cancelada, no es posible subir ni confirmar documentación.'
		 END

	SELECT @activo activo, @mensaje mensaje
	--SELECT 1 activo
END
go

