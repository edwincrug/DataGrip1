-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- EXECUTE [dbo].[PPROV_ORDCOMPRA_PAGADAS_VIN] 71,null,null,'',2,0,0,-1,'','',''
CREATE PROCEDURE [dbo].[PPROV_ORDCOMPRA_PAGADAS_VIN] 
@idProveedor INT = 0,
@monto DECIMAL = NULL,
@orden VARCHAR(50) = NULL,
@user VARCHAR(15) = '',
@idUserRol INT = 0, 
@idEmpresaP INT = 0,
@idSucursalP INT = 0,
@idDeptoP INT = 0,
@fechaIniP VARCHAR(10) = '',
@fechaFinP VARCHAR(10) = '',
@rfcProveedor VARCHAR(20) = ''
AS  

	--==========================================================================================--
	-- BUSQUEDA DE VIN
	--==========================================================================================--	
		DECLARE @TablaVIN TABLE (folioorden	       VARCHAR(50)
								,vin               VARCHAR(20)
								)
        INSERT INTO @TablaVIN
             SELECT DISTINCT (A.uaw_folioordencompraot),CD.ucn_noserie
               FROM [cuentasporcobrar].[dbo].[uni_anticiposweb] AS A
                    INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON ISNULL(A.[ucn_idcotizadetalle], A.ucn_idcotizadetallepost) = CD.[ucn_idcotizadetalle]
                    INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS C ON C.[ucu_idcotizacion] = CD.[ucu_idcotizacion]
              WHERE [UAW_FOLIOORDENCOMPRAOT] IS NOT NULL AND A.CEA_IdEstatusAdicionales != 4	
        
		--SELECT * FROM @TablaVIN
	  
IF(@idUserRol = 1)
	BEGIN
	-----------------------
	If (@fechaIniP = '') and (@fechaIniP='')
	BEGIN
	PRINT ('ROL 1 SIN FECHA')
					SELECT ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,depto.dep_nombre, suc.suc_nombre,  
						emp.emp_nombre,ordComp.oce_importetotal, emp.emp_nombrecto,  
						ordComp.oce_fechaorden,'1' estatus,per.per_rfc,ordComp.oce_uuid
						,suc.suc_idsucursal --ADD LQMA 02052016
						,emp.emp_idempresa --ADD LQMA 02052016	
						,CASE  
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
						(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
						(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
						ELSE ''
						END AS NumSerie,
					    OC.ser_ordenservicio ordenServicio --LQMA 02102017
						,FAC.serie + FAC.folio factura --LQMA add 23012018
						,REFPAG.pad_polReferencia RefPag --LQMA add 07022018
						,ordComp.oce_idproveedor idProveedor --LQMA add 07022018
						,V.vin  AS vin
						,COM.folio AS folioComplemento  --ADD LMS 11/01/2019
				FROM cuentasxpagar.dbo.cxp_ordencompra ordComp    
				LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
				LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
				LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
				LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
				LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL 
				LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] FAC ON ordComp.oce_folioorden = FAC.folioorden 
				LEFT JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTODET] AS COMD ON COMD.[orden_UUID] = FAC.uuid
				LEFT JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC] COM  ON COMD.[id_Complemento] = COM.[id_Complemento]    --ADD LMS 11/01/2019
				LEFT JOIN PAGOS.dbo.PAG_PROGRA_PAGOS_DETALLE REFPAG ON ordComp.oce_folioorden = REFPAG.pad_documento 
				LEFT JOIN @TablaVIN V ON V.folioorden = ordComp.oce_folioorden COLLATE Modern_Spanish_CI_AS
				WHERE ordComp.oce_folioorden NOT IN (SELECT oce_folioorden FROM dbo.PPRO_ORDENARCHIVOXML)
					  AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
					  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					  AND ordComp.sod_idsituacionorden IN (12)
					  AND ordComp.oce_folioorden IN (SELECT oce_folioorden FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_idproveedor IN(
												 SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @user))

					  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
					  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
					  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
					  --AND CONVERT(DATE,REPLACE(ordComp.oce_fechaorden,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
					  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))		 
					  order by ordComp.oce_fechaorden ASC
 					 
	END
	ELSE 
	BEGIN
	PRINT ('ROL 1 CON FECHA')
	
									SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,depto.dep_nombre, suc.suc_nombre,  
						emp.emp_nombre,ordComp.oce_importetotal, emp.emp_nombrecto,  
						ordComp.oce_fechaorden,'1' estatus,per.per_rfc,ordComp.oce_uuid
						,suc.suc_idsucursal --ADD LQMA 02052016
						,emp.emp_idempresa --ADD LQMA 02052016	
						,CASE  
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
						(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
						(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
						ELSE ''
						END AS NumSerie,
					    OC.ser_ordenservicio ordenServicio --LQMA 02102017
						,FAC.serie + FAC.folio factura --LQMA add 23012018
						,REFPAG.pad_polReferencia RefPag --LQMA add 07022018
						,ordComp.oce_idproveedor idProveedor --LQMA add 07022018
						,V.vin  AS vin
						,COM.folio AS folioComplemento  --ADD LMS 11/01/2019
				FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_movimientosorden] AS MOC ON MOC.oce_folioorden = ordComp.oce_folioorden AND MOC.sod_idsituacionorden = 12 
				LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
				LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
				LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
				LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
				LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL 
				LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] FAC ON ordComp.oce_folioorden = FAC.folioorden 
				LEFT JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTODET] AS COMD ON COMD.[orden_UUID] = FAC.uuid
				LEFT JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC] COM  ON COMD.[id_Complemento] = COM.[id_Complemento]    --ADD LMS 11/01/2019
				LEFT JOIN PAGOS.dbo.PAG_PROGRA_PAGOS_DETALLE REFPAG ON ordComp.oce_folioorden = REFPAG.pad_documento
				LEFT JOIN @TablaVIN V ON V.folioorden = ordComp.oce_folioorden COLLATE Modern_Spanish_CI_AS 
				WHERE ordComp.oce_folioorden NOT IN (SELECT oce_folioorden FROM dbo.PPRO_ORDENARCHIVOXML)
					  AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
					  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					  AND ordComp.sod_idsituacionorden IN (12)
					  AND ordComp.oce_folioorden IN (SELECT oce_folioorden FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_idproveedor IN(
												 SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @user))

					  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
					  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
					  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
					  AND CONVERT(DATE,REPLACE(MOC.[mov_fechamovimiento],'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
					  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))		 
					  order by ordComp.oce_fechaorden ASC

	END

  	END
ELSE
	BEGIN

			DECLARE @EmpresaSucursal TABLE
			(	
				idEmpSuc INT NOT NULL IDENTITY(1,1),
				empresa INT,
				sucursal INT
			)
		
		if (@fechaIniP = '') and (@fechaIniP='')
		BEGIN

			print 'SIN FECHA'
			print 'variable tabla'

			--Insertamos empresas y sucursales por usuario
			INSERT INTO @EmpresaSucursal
			SELECT DISTINCT emp_idempresa,suc_idsucursal FROM [ControlAplicaciones].[dbo].[ope_organigrama]
			WHERE [usu_idusuario] = @idProveedor--(SELECT usu_idusuario FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombreusu = @user)

			SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,depto.dep_nombre, suc.suc_nombre,  
						emp.emp_nombre,ordComp.oce_importetotal, emp.emp_nombrecto,  
						ordComp.oce_fechaorden,'1' estatus,per.per_rfc,ordComp.oce_uuid
						,suc.suc_idsucursal --ADD LQMA 02052016
						,emp.emp_idempresa --ADD LQMA 02052016	
						,CASE  
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
						(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
						(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
						ELSE ''
						END AS NumSerie,
					    OC.ser_ordenservicio ordenServicio --LQMA 02102017
						,FAC.serie + FAC.folio factura --LQMA add 23012018
						,REFPAG.pad_polReferencia RefPag --LQMA add 07022018
						,ordComp.oce_idproveedor idProveedor --LQMA add 07022018
						,V.vin  AS vin
						,COM.folio AS folioComplemento  --ADD LMS 11/01/2019
				FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
				LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
				LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
				LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
				LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
				LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
				JOIN @EmpresaSucursal EmpSuc ON ordComp.oce_idempresa = EmpSuc.empresa AND ordComp.oce_idsucursal = EmpSuc.sucursal
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL --LQMA 02102017
				--LQMA 23012018 add nuevos campos
				LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] FAC ON ordComp.oce_folioorden = FAC.folioorden 
				LEFT JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTODET] AS COMD ON COMD.[orden_UUID] = FAC.uuid
				LEFT JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC] COM  ON COMD.[id_Complemento] = COM.[id_Complemento]    --ADD LMS 11/01/2019
				--LQMA add 07022018
				--LEFT JOIN referencias.dbo.DetalleReferencia REFPAGODET ON ordComp.oce_folioorden = REFPAGODET.documento 
				--LEFT JOIN referencias.dbo.Referencia REFPAGO ON REFPAGODET.idReferencia = REFPAGO.idReferencia
				LEFT JOIN PAGOS.dbo.PAG_PROGRA_PAGOS_DETALLE REFPAG ON ordComp.oce_folioorden = REFPAG.pad_documento 
				LEFT JOIN @TablaVIN V ON V.folioorden = ordComp.oce_folioorden COLLATE Modern_Spanish_CI_AS
				WHERE --ordComp.oce_idproveedor = @idProveedor AND
					   (@monto IS NULL OR ordComp.oce_importetotal = @monto)
					  AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
					  AND ordComp.oce_folioorden NOT IN (SELECT oce_folioorden FROM dbo.PPRO_ORDENARCHIVOXML)
					  AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
					  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					  --AND ordComp.sod_idsituacionorden NOT IN (11,12,16,18)
					  AND ordComp.sod_idsituacionorden IN (12)

					   --LQMA 21092017 add fintros
					  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
					  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
					  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
					  --AND CONVERT(DATE,REPLACE(ordComp.oce_fechaorden,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
					  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))
					  order by ordComp.oce_fechaorden ASC
		END
		ELSE
		BEGIN
			print 'CON FECHA'
			print 'variable tabla'

			--Insertamos empresas y sucursales por usuario
			INSERT INTO @EmpresaSucursal
			SELECT DISTINCT emp_idempresa,suc_idsucursal FROM [ControlAplicaciones].[dbo].[ope_organigrama]
			WHERE [usu_idusuario] = @idProveedor--(SELECT usu_idusuario FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombreusu = @user)

			SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,depto.dep_nombre, suc.suc_nombre,  
						emp.emp_nombre,ordComp.oce_importetotal, emp.emp_nombrecto,  
						ordComp.oce_fechaorden,'1' estatus,per.per_rfc,ordComp.oce_uuid
						,suc.suc_idsucursal --ADD LQMA 02052016
						,emp.emp_idempresa --ADD LQMA 02052016	
						,CASE  
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
						(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
						(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
						ELSE ''
						END AS NumSerie,
					    OC.ser_ordenservicio ordenServicio --LQMA 02102017
						,FAC.serie + FAC.folio factura --LQMA add 23012018
						,REFPAG.pad_polReferencia RefPag --LQMA add 07022018
						,ordComp.oce_idproveedor idProveedor --LQMA add 07022018
						,V.vin  AS vin
						,COM.folio AS folioComplemento  --ADD LMS 11/01/2019
				FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_movimientosorden] AS MOC ON MOC.oce_folioorden = ordComp.oce_folioorden AND MOC.sod_idsituacionorden = 12 
				LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
				LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
				LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
				LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
				LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
				JOIN @EmpresaSucursal EmpSuc ON ordComp.oce_idempresa = EmpSuc.empresa AND ordComp.oce_idsucursal = EmpSuc.sucursal
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL --LQMA 02102017
				--LQMA 23012018 add nuevos campos
				LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] FAC ON ordComp.oce_folioorden = FAC.folioorden
				LEFT JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTODET] AS COMD ON COMD.[orden_UUID] = FAC.uuid
				LEFT JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC] COM  ON COMD.[id_Complemento] = COM.[id_Complemento]    --ADD LMS 11/01/2019
				--LQMA add 07022018
				--LEFT JOIN referencias.dbo.DetalleReferencia REFPAGODET ON ordComp.oce_folioorden = REFPAGODET.documento 
				--LEFT JOIN referencias.dbo.Referencia REFPAGO ON REFPAGODET.idReferencia = REFPAGO.idReferencia
				LEFT JOIN PAGOS.dbo.PAG_PROGRA_PAGOS_DETALLE REFPAG ON ordComp.oce_folioorden = REFPAG.pad_documento 
				LEFT JOIN @TablaVIN V ON V.folioorden = ordComp.oce_folioorden COLLATE Modern_Spanish_CI_AS
				WHERE --ordComp.oce_idproveedor = @idProveedor AND
					   (@monto IS NULL OR ordComp.oce_importetotal = @monto)
					  AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
					  AND ordComp.oce_folioorden NOT IN (SELECT oce_folioorden FROM dbo.PPRO_ORDENARCHIVOXML)
					  AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
					  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					  --AND ordComp.sod_idsituacionorden NOT IN (11,12,16,18)
					  AND ordComp.sod_idsituacionorden IN (12)

					   --LQMA 21092017 add fintros
					  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
					  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
					  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
					  AND CONVERT(DATE,REPLACE(MOC.[mov_fechamovimiento],'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
					  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))
					  order by ordComp.oce_fechaorden ASC
		
		END
			
	END

go

