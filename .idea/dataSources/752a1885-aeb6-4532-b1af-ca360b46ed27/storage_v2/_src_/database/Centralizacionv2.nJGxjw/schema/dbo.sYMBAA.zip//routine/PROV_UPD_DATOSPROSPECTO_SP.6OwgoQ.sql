CREATE  PROCEDURE [dbo].[PROV_UPD_DATOSPROSPECTO_SP] 
 @idProspecto INT
,@email     VARCHAR(70)           = ''
,@nombre    VARCHAR(150)			  = ''
,@paterno	 VARCHAR(40)		  = ''
,@materno 	 VARCHAR(40)		  = ''
,@rfc  		 VARCHAR(13)		  = ''
,@giro 		 VARCHAR(10)		  = ''
,@contacto 	 VARCHAR(50)		  = ''
,@telefono 	 VARCHAR(10)		  = ''
,@calle 	 VARCHAR(70)		  = ''
,@calle2 	 VARCHAR(70)		  = ''
,@exterior   VARCHAR(20)		  = ''
,@interior 	 VARCHAR(20)		  = ''
,@cp  	     VARCHAR(5)			  = ''
,@colonia 	 VARCHAR(150)		  = ''
,@localidad 	 VARCHAR(60)	  = ''
,@ciudad		 VARCHAR(40)	  = ''
,@pagina		 VARCHAR(40)	  = ''
,@comercial		 VARCHAR(150)	  = ''
,@docContacto		 VARCHAR(50)  = ''
,@tipoPersona		VARCHAR(5)	  = ''
,@empresaId			VARCHAR(10)		= ''
,@empresaBD			VARCHAR(50) = ''
,@limiteCredito		DECIMAL(18,2) = 0
,@diasCredito		INT = 0
,@representante		VARCHAR(150) = ''
,@legales			BIT = 0

AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY
		UPDATE Centralizacionv2.dbo.PROV_PROSPECTO SET
			 PER_EMAIL            = @email 
			,PER_NOMRAZON 		  = @nombre    
			,PER_PATERNO		  = @paterno	
			,PER_MATERNO 		  = @materno 	
			,PER_RFC  			  = @rfc  		
			,PER_GIRO 			  = @giro 		
			,PER_CLICON 		  = @contacto 	
			,PER_TELEFONO1 		  = @telefono 	
			,PER_CALLE1 		  = @calle 	
			,PER_NUMEXTER  		  = @exterior  
			,PER_NUMINER  		  = @interior 	
			,PER_CODPOS  		  = @cp  	
			,PER_COLONIA  		  = @colonia 	
			,PER_DELEGAC 		  = @localidad
			,PER_CIUDAD 		  = @ciudad	
			,PER_PAGWEB			  = @pagina
			,PER_RLNOMRAZON		  = @comercial 
			,PER_DEALERID		  = @docContacto
			,PER_TIPO			  = @tipoPersona	
			,empresaId = @empresaId
			,empresaBD = @empresaBD
			,limiteCredito = @limiteCredito
			,diasCredito = @diasCredito
			,representante = @representante
			,legales	 = @legales
			
   	   WHERE   PER_IDPERSONA = @idProspecto

	   SELECT 1 result
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	   
ROLLBACK TRANSACTION

	    	   SELECT -1 result

END CATCH
END

go

