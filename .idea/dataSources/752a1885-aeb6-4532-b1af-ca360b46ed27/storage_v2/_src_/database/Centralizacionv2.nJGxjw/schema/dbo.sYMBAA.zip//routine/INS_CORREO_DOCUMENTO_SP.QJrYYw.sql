
-- ==========================================================================================
-- Author:		Arturo Rodea Victoria
-- Create date: 10/11/2015
-- Description:	Envia por correo un documento a una dirección dada
-- Modified date: 08/06/2016  Lourdes Maldonado Sánchez(LMS)
-- Description:	Cambia la direccion del Remitente dependiendo de la Orden de Compra
-- ==========================================================================================
-- INS_CORREO_DOCUMENTO_SP 11, 'AU-AU-UNI-RE-PE-31', 'lgordillo@bism.com.mx'
CREATE PROCEDURE [dbo].[INS_CORREO_DOCUMENTO_SP]
	 @idDocumento	int
	,@folio			nvarchar(50)
	,@correo		nvarchar(150)=null
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @tableHTML  nvarchar(MAX)
	,@desDocumento		nvarchar(300)
	,@asunto			nvarchar(500)
	,@anexo				nvarchar(500)
	,@rutaDoc			nvarchar(200)
	,@asuntoCorreo   	nvarchar(100)
	,@correoRemitente   nvarchar(100) 

	--Buscamos la direccion de correo de la sucursal a donde se enviara el documento:	
	SELECT @asuntoCorreo      = cs.CorreoNombre
		   ,@correoRemitente   = cs.CorreoDireccion
		   --,@correoRemitente   ='lmaldonado@bism.com.mx'
	  FROM Centralizacionv2..DIG_CORREOS_SUCURSAL cs
			,cuentasxpagar..cxp_ordencompra        oc
			,ControlAplicaciones..cat_divisiones   catdiv
			,ControlAplicaciones..cat_empresas     catemp
			,ControlAplicaciones..cat_sucursales   catsuc
	  WHERE oc.oce_folioorden = @folio
		and oc.oce_iddivision = catdiv.div_iddivision
		and oc.oce_idempresa  = catemp.emp_idempresa
		and oc.oce_idsucursal = catsuc.suc_idsucursal
		and cs.div_nombrecto  = catdiv.div_nombrecto
		and cs.emp_nombrecto  = catemp.emp_nombrecto
		and cs.suc_nombrecto  = catsuc.suc_nombrecto 

	SELECT @desDocumento = Doc_Descripcion FROM DIG_CATDOCUMENTO WHERE Doc_Id = @idDocumento;
	SET @asunto = 'Documento ' + @desDocumento + ' del expediente: ' + @folio;	
	print ('1.Asunto: ' + @asunto)
	print ('2.Correo Remitente: ' + @correoRemitente)

	SELECT @rutaDoc =	CASE CD.Doc_Id
							WHEN 11 THEN CD.[Doc_Ruta_Web] + 'Orden_' + ED.Folio_Operacion + CD.[Doc_Extencion]
							WHEN 12 THEN CD.[Doc_Ruta_Web] + 'Orden_' + ED.Folio_Operacion + CD.[Doc_Extencion]
							WHEN 13 THEN CD.[Doc_Ruta_Web] + 'Pol_PC_' + ED.Folio_Operacion +  CD.[Doc_Extencion]
							WHEN 14 THEN CD.[Doc_Ruta_Web] + 'Pol_PT_' + ED.Folio_Operacion + CD.[Doc_Extencion]
							---
							WHEN 15 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + ED.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
							WHEN 20 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + (SELECT rfc_receptor 
																												+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																												+ '/' + rfc_emisor + '_' + 
																	     										CASE folio 
																	 												WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																													ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																													END
																													+ '.pdf'
																										   FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] 
																										  WHERE [folioorden] = ED.Folio_Operacion)
							ELSE 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + ED.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.' + ED.Doc_Extencion --ISNULL(CD.[Doc_Extencion],'.pdf'
							--ELSE 'C:\GA_Centralizacion\CuentasXPagar\Cargas\' + ED.Folio_Operacion + '\' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.' + ED.Doc_Extencion
						END
	FROM [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] CD
	     LEFT JOIN [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] ED ON CD.Doc_Id = ED.Doc_Id
	WHERE CD.Doc_Id          = @idDocumento 
	  AND ED.Folio_Operacion = @folio 
	  AND ED.Proc_Id         = 1

	print ('3.Ruta Doc: ' + @rutaDoc) 

	SET @anexo = @rutaDoc--'C:\GA_Centralizacion\CuentasXPagar\TempPdf\EnviaCorreo\Depositos\' + @folio + '.pdf';

	SET @tableHTML =
	    N'<H4 style="font-family: Helvetica,Arial,sans-serif;">Estimado Usuario:</H4>' +
		N'<H4 style="font-family: Helvetica,Arial,sans-serif;">Se ha enviado el documento correspondiente al siguiente expediente </H4>' +
		N'<table  style="text-align: left; width: 343px; height: 82px;" border="1" cellpadding="2" cellspacing="0">' +
		N'<tr><td style="font-family: Helvetica,Arial,sans-serif; font-weight: bold;"> No.: </td><td style="font-family: Helvetica,Arial,sans-serif; text-align: center;">' + @folio + '</td></tr>' +
		N'<tr><td style="font-family: Helvetica,Arial,sans-serif; font-weight: bold;"> Id de Documento: </td><td style="font-family: Helvetica,Arial,sans-serif; text-align: center;">' + CONVERT(varchar, @idDocumento) + '</td></tr>' +
		N'<tr><td style="font-family: Helvetica,Arial,sans-serif; font-weight: bold;"> Descripción: </td><td style="font-family: Helvetica,Arial,sans-serif; text-align: center;">' + @desDocumento + '</td></tr>' +
		N'</table>' +
		N'<br><br>'+
	    N'<img style="width: 121px; height: 43px;" alt="Grupo Andrade"' +
		N'src="http://192.168.20.89/GA_centralizacion/Images/Grupo-Andrade.png">' +
		N'<h5 style="font-family: Helvetica,Arial,sans-serif;">' +
		N'<p><a href="'+@anexo+'">Ver Archivo</a></p>' +
		N'<p>Correo enviado automáticamente, no responder</p>' +
		N'</h5>' ;
		--print ('Cuerpo: ' + @tableHTML);
        print ('5.Mando a llamar a   INS_MAIL_SP')
		print ('6.Anexo: ' + @anexo) 
	EXEC INS_MAIL_SP @correo,'','',@asuntoCorreo,@tableHTML, @anexo, @correoRemitente;
	
	print ('7.Termino') 
	--print @asunto;
	--print @tableHTML;
END

go

