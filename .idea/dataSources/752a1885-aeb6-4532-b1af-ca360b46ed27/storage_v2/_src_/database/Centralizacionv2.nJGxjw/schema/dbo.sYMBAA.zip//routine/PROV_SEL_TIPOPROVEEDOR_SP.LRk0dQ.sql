

CREATE PROCEDURE [dbo].[PROV_SEL_TIPOPROVEEDOR_SP] 
@idProspecto INT


AS
BEGIN

BEGIN TRY

	SELECT	 cveProveedor
			,tipoProveedor
			,modulo 
			
	FROM	PROV_CAT_TIPO_PROVEEDOR TP
	WHERE TP.cveProveedor not in (SELECT rol FROM CentralizacionV2.[dbo].[PROV_PROSPECTO_ROL] WHERE   idProspecto = @idProspecto )

	
END TRY
BEGIN CATCH
	SELECT -1 result
END CATCH
	
END
go

