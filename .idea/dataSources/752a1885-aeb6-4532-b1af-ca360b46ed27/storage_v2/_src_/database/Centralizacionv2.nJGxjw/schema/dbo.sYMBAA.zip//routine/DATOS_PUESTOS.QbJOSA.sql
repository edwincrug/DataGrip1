-- =============================================
-- Author:		<>
-- Create date: <>
-- Description:	<>
--SELECT * FROM [DATOS_PUESTOS](116, 11, 25)
--SELECT * FROM [DATOS_PUESTOS](174, 11, 25)
-- =============================================
CREATE FUNCTION [dbo].[DATOS_PUESTOS] (@idpuesto INT = 0, @idEmpresa INT = 0, @sucursal INT = 0)
RETURNS 
@Result TABLE(nombre VARCHAR(50), correo VARCHAR(50))
AS
BEGIN
	IF( @idpuesto = 0 OR @idEmpresa = 0 OR @sucursal = 0 )
		BEGIN
			INSERT INTO @Result VALUES (' ', ' ')
		END
	ELSE
		BEGIN
			INSERT INTO @Result
			SELECT 
				TOP 1 usu_nombre + ' ' + usu_paterno + '  ' + usu_materno AS nombre,
				usu_correo
			FROM [ControlAplicaciones].[DBO].[cat_usuarios] U
			INNER JOIN [ControlAplicaciones].[DBO].[ope_organigrama] O ON O.usu_idusuario = U.usu_idUsuario
			WHERE pto_idpuesto = @idpuesto AND O.emp_idEmpresa = @idEmpresa AND O.suc_idSucursal = @sucursal
		END
	RETURN
END

go

