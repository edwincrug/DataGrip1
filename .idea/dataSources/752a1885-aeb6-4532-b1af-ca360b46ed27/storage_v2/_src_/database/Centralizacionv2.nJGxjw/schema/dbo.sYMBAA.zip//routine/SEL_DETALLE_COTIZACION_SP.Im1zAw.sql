---------------------------------------------
/*
[dbo].[SEL_DETALLE_COTIZACION_SP]
	@FolioCotizacion = 'AU-AU-UNI-UN-4403' 
	,@idCotizacionDetalle = 47778
*/
---------------------------------------------
CREATE PROCEDURE [dbo].[SEL_DETALLE_COTIZACION_SP]
	@FolioCotizacion VARCHAR(100) 
	,@idCotizacionDetalle VARCHAR(10)
AS
BEGIN
	SET NOCOUNT ON;
		DECLARE @Base                 VARCHAR(100)
		DECLARE @BaseConcentra        VARCHAR(100)
		DECLARE @BaseLocal            VARCHAR(100)
		DECLARE @TipoCotizacion       VARCHAR(3)
		DECLARE @IdCotizacion         VARCHAR(100)
		DECLARE @ConsultaUnidad       VARCHAR(max)
		DECLARE @ConsultaRefacciones  VARCHAR(max)
		DECLARE @ConsultaTramites     VARCHAR(max)
		DECLARE @ConsultaOtros        VARCHAR(max)
		DECLARE @ConsultaServicio     VARCHAR(max) 
		-------------------------------------------------------------
		--Se crea variable tabla 
		-------------------------------------------------------------
		DECLARE @cotizacionDetalle TABLE(	MODULO VARCHAR(30),
											ID_COTIZACION NUMERIC,
											CANTIDAD INT,
											CLAVE_CATALOGO VARCHAR(250),
											DESCRIPCION VARCHAR(500),
											MODELO VARCHAR(250),
											SERIE VARCHAR(250),
											COLOR_EXT VARCHAR(100),
											COLOR_INT VARCHAR(100),
											PRECIO DECIMAL(18,2),
											IVA DECIMAL(18,2),
											TOTAL DECIMAL(18,2),
											ESTATUS VARCHAR(100)
										)
		-------------------------------------------------------------
		--Obtengo información sobre la cotización
		------------------------------------------------------------- 
		--Cuando es enviado el @FolioCotizacion y el @idCotizacionDetalle
		IF(@FolioCotizacion <> '' AND @idCotizacionDetalle <> '')
			BEGIN
				--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE DONDE SE BUSCARA LA POLIZA
				SET @Base = [dbo].[base_Cotizacion](@FolioCotizacion)
				--SELECT @Base
				--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE CONCENTRADORA
				SET @BaseConcentra =[dbo].[base_concentradora_cotizacion](@FolioCotizacion)		
				--SELECT @BaseConcentra
				--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE LOCAL
				SELECT	@BaseLocal = '['+ ip_servidor + '].[' + nombre_base + '].[dbo].'
				  FROM	DIG_CAT_BASES_BPRO AS BPRO 
						INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU ON CU.ucu_idsucursal = BPRO.suc_idsucursal
				 WHERE	CU.ucu_foliocotizacion = @FolioCotizacion --AND BPRO.tipo = 2
				--SELECT @BaseLocal
				--Incicio Variable consecutivo de cotizacion
				SET @IdCotizacion = (SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)
				SET @TipoCotizacion = (SELECT ucu_tipocotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)
				-------------------------------------------------------------
				--QUERY CONSULTA UNIDADES
				------------------------------------------------------------- 		        
				IF @TipoCotizacion = 'NU' 
				  BEGIN

					set @ConsultaUnidad =	'SELECT 	'+char(39)+'UNIDADES'+char(39)+'' + char(13) + 
											'		,C.ucn_idcotizadetalle' + char(13) + 
											'		,1' + char(13) + 
											'		,ucn_idcatalogo' + char(13) + 
											'		,V.UNC_DESCRIPCION' + char(13) + 
											'		,ucn_modelo' + char(13) + 
											'		,ucn_noserie' + char(13) + 
											'		,ucn_colorext' + char(13) + 
											'		,ucn_colorint' + char(13) + 
											'		,CONVERT(DECIMAL(18,2),ucn_preciounidad)' + char(13) + 
											'		,CONVERT(DECIMAL(18,2),ucn_iva)' + char(13) + 
											'		,CONVERT(DECIMAL(18,2),ucn_total)' + char(13) + 
											'		,'+char(39)+''+char(39)+'  ' + char(13) + 
											'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
											'		INNER JOIN ' + @BaseConcentra + 'UNI_CATALOGO V ON C.ucn_idcatalogo = V.UNC_IDCATALOGO AND C.ucn_modelo = V.UNC_MODELO ' + char(13) + 
											'WHERE 	C.ucn_estatus = 1 AND ucu_idcotizacion = ' + @IdCotizacion+ '' + char(13) + 
											'		AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + '' + char(13) +
											''   
				  END
				ELSE
				  BEGIN  

					set @ConsultaUnidad =	'SELECT 	'+char(39)+'UNIDADES'+char(39)+'' + char(13) + 
											'		,C.ucn_idcotizadetalle' + char(13) + 
											'		,1' + char(13) + 
											'		,ucn_idcatalogo='+char(39)+''+char(39)+'' + char(13) + 
											'		,UNC_DESCRIPCION= U.VEH_TIPOAUTO' + char(13) + 
											'		,ucn_modelo' + char(13) + 
											'		,ucn_noserie' + char(13) + 
											'		,ucn_colorext' + char(13) + 
											'		,ucn_colorint' + char(13) + 
											'		,CONVERT(DECIMAL(18,2)' + char(13) + 
											'		,ucn_preciounidad)' + char(13) + 
											'		,CONVERT(DECIMAL(18,2),ucn_iva)' + char(13) + 
											'		,CONVERT(DECIMAL(18,2),ucn_total)' + char(13) + 
											'		,'+char(39)+''+char(39)+'  ' + char(13) + 
											'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C INNER JOIN ' + @BaseLocal + 'SER_VEHICULO U ON C.ucn_noserie = U.VEH_NUMSERIE' + char(13) + 
											'WHERE 	C.ucn_estatus = 1 ' + char(13) + 
											'		AND ucu_idcotizacion = ' + @IdCotizacion+ '' + char(13) + 
											'		AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + '' + char(13) +
											''
			
				   END
				--PRINT @ConsultaUnidad
				INSERT INTO @cotizacionDetalle
				EXEC (@ConsultaUnidad)
				-------------------------------------------------------------
				--QUERY CONSULTA REFACCIONES
				------------------------------------------------------------- 
				SET @ConsultaRefacciones =	'SELECT '+char(39)+'ACCESORIOS'+char(39)+'' + char(13) + 
											'		,C.ucn_idcotizadetalle' + char(13) + 
											'		,P.pmd_cantidad' + char(13) + 
											'		,P.pmd_idparte' + char(13) + 
											'		,PP.PTS_DESPARTE' + char(13) + 
											'		,'+char(39)+''+char(39)+'' + char(13) + 
											'		,'+char(39)+''+char(39)+'' + char(13) + 
											'		,'+char(39)+''+char(39)+'' + char(13) + 
											'		,'+char(39)+''+char(39)+'' + char(13) + 
											'		,P.pmd_preciounitario / 1.16' + char(13) + 
											'		,P.pmd_preciounitario - (P.pmd_preciounitario / 1.16)' + char(13) + 
											'		,P.pmd_total' + char(13) + 
											'		,UPPER(CASE WHEN pmd_estatusautorizacion IS NULL AND PE.pmm_nopedmost IS NULL THEN '+char(39)+'Por Autorizar'+char(39)+' ELSE AD.CEA_Nombre END)  ' + char(13) + 
											'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
											'		INNER JOIN cuentasporcobrar.dbo.par_pedmostdet P ON C.ucn_idcotizadetalle = P.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = P.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)' + char(13) + 
											'		INNER JOIN ' + @Base + 'PAR_PARTES PP ON P.pmd_idparte = PP.PTS_IDPARTE ' + char(13) + 
											'		INNER JOIN cuentasporcobrar.dbo.CAT_EstatusAdicionales AS AD ON AD.CEA_IdEstatusAdicionales = P.CEA_IdEstatusAdicionales ' + char(13) + 
											'		INNER JOIN cuentasporcobrar.dbo.par_pedmostenc PE ON PE.pmm_idpedmostenc = P.pmm_idpedmostenc ' + char(13) +
											'WHERE 	P.pmd_estatus = 1 AND C.ucu_idcotizacion = ' + @IdCotizacion+ '' + char(13) +
											'		AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + '' + char(13) +
											'		AND P.[CEA_IdEstatusAdicionales] <> 4' + char(13) + 
											'' 
				PRINT (@ConsultaRefacciones)
				INSERT INTO @cotizacionDetalle
				EXEC (@ConsultaRefacciones)
				-------------------------------------------------------------
				--QUERY CONSULTA TRAMITES 
				-------------------------------------------------------------
				SET @ConsultaTramites =	'SELECT '+char(39)+'TRAMITES'+char(39)+'' + char(13) + 
										'		,C.ucn_idcotizadetalle' + char(13) + 
										'		,1' + char(13) + 
										'		,P.PAR_DESCRIP1' + char(13) + 
										'		,a.uaw_descripcion' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,a.UAW_PRECIO' + char(13) + 
										'		,a.UAW_PRECIO - (a.UAW_PRECIO /1.16)' + char(13) + 
										'		,a.UAW_PRECIO' + char(13) + 
										'		,UPPER(CASE WHEN pmd_estatusautorizacion IS NULL THEN '+char(39)+'Por Autorizar'+char(39)+' ELSE AD.CEA_Nombre END)' + char(13) + 
										'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.uni_anticiposweb A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle  OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)' + char(13) + 
										'		INNER JOIN ' + @Base + 'PNC_PARAMETR P ON A.uaw_idconceptopago = P.PAR_IDENPARA ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.CAT_EstatusAdicionales AS AD ON AD.CEA_IdEstatusAdicionales = A.CEA_IdEstatusAdicionales ' + char(13) + 
										'WHERE 	C.ucu_idcotizacion = ' + @IdCotizacion+ '' + char(13) + 
										'		AND A.uaw_estatus = 1 ' + char(13) + 
										'		AND P.PAR_TIPOPARA = '+char(39)+'COCOCXC'+char(39)+'' + char(13) + 
										'		AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + '' + char(13) +
										'		AND A.[CEA_IdEstatusAdicionales] <> 4' + char(13) + 
										'' 
				--PRINT (@ConsultaTramites)
				INSERT INTO @cotizacionDetalle
				EXEC (@ConsultaTramites)
				-------------------------------------------------------------
				--QUERY CONSULTA OTROS
				-------------------------------------------------------------
				SET @ConsultaOtros =	'SELECT '+char(39)+'OTROS'+char(39)+'' + char(13) + 
										'		,C.ucn_idcotizadetalle' + char(13) + 
										'		,A.ucd_cantidad' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,A.ucd_descripcion' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,A.ucd_preciounitario / 1.16' + char(13) + 
										'		,A.ucd_preciounitario - (A.ucd_preciounitario / 1.16)' + char(13) + 
										'		,A.ucd_preciounitario' + char(13) + 
										'		,UPPER(CASE WHEN pmd_estatusautorizacion IS NULL AND CA.uoc_idpedidobpro IS NULL THEN '+char(39)+'Por Autorizar'+char(39)+' ELSE AD.CEA_Nombre END) ' + char(13) + 
										'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.uni_otroconceptosdet A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost  AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL) ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.CAT_EstatusAdicionales AS AD ON AD.CEA_IdEstatusAdicionales = A.CEA_IdEstatusAdicionales ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.uni_otrosconceptosenc AS CA ON CA.uoc_idotrosconceptosenc = A.uoc_idotrosconceptosenc' + char(13) + 
										'WHERE 	A.ucd_estatus = 1 ' + char(13) + 
										'		AND C.ucu_idcotizacion = ' + @IdCotizacion+ '' + char(13) +  
										'		AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + '' + char(13) +
										'		AND A.[CEA_IdEstatusAdicionales] <> 4' + char(13) + 
										''  
				--PRINT (@ConsultaOtros)
				INSERT INTO @cotizacionDetalle
				EXEC (@ConsultaOtros)
				-------------------------------------------------------------
				--QUERY CONSULTA SERVICIO
				-------------------------------------------------------------
				SET @ConsultaServicio =	'SELECT '+char(39)+'SERVICIO'+char(39)+'' + char(13) + 
										'		,C.ucn_idcotizadetalle' + char(13) + 
										'		,1' + char(13) + 
										'		,PS.PQE_IDPAQUETE' + char(13) + 
										'		,PS.PQE_NOMPAQUETE' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,PS.PQE_DESCRIPCION' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,'+char(39)+''+char(39)+'' + char(13) + 
										'		,A.upo_precio / 1.16 ' + char(13) + 
										'		,A.upo_precio - (A.upo_precio / 1.16)' + char(13) + 
										'		,A.upo_precio' + char(13) + 
										'		,UPPER(CASE WHEN pmd_estatusautorizacion IS NULL AND A.upo_idorden IS NULL THEN '+char(39)+'Por Autorizar'+char(39)+' ELSE AD.CEA_Nombre END) ' + char(13) + 
										'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.uni_preordenser A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost   AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL) ' + char(13) + 
										'		INNER JOIN ' + @Base + 'SER_PAQUESER PS ON A.upo_idpaquete = PS.PQE_IDPAQUETE ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.CAT_EstatusAdicionales AS AD ON AD.CEA_IdEstatusAdicionales = A.CEA_IdEstatusAdicionales ' + char(13) + 
										'WHERE 	A.upo_estatus = 1 AND C.ucu_idcotizacion = ' + @IdCotizacion+ '' + char(13) +  
										'		AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + '' + char(13) +
										'		AND A.[CEA_IdEstatusAdicionales] <> 4' + char(13) +
										''
				--PRINT (@ConsultaServicio)
				INSERT INTO @cotizacionDetalle
				EXEC (@ConsultaServicio)
		 
			END
		ELSE 
			BEGIN 
				INSERT INTO @cotizacionDetalle (MODULO)
				SELECT 'Ocurrio un problema'

			END
		SELECT MODULO,ID_COTIZACION,CANTIDAD,CLAVE_CATALOGO,DESCRIPCION,MODELO,SERIE,COLOR_EXT,COLOR_INT,PRECIO,IVA,TOTAL,ESTATUS FROM @cotizacionDetalle

	SET NOCOUNT OFF;
END;

go

