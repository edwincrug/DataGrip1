CREATE PROCEDURE [dbo].[SEL_CORREOS_USUARIO_SP] -- [SEL_CORREOS_USUARIO_SP] 'HEHJ520304R36'
@ppro_user VARCHAR(15)
AS
BEGIN
	SELECT idUsuarioCorreo, ppro_user,correo,UC.idTipoCorreo,descripcion FROM UsuarioCorreo UC 
	INNER JOIN TipoCorreo TC ON UC.idTipoCorreo = TC.idTipoCorreo
	 --right join  [PPRO_USERSPORTALPROV] us on us.ppro_user =  UC.ppro_user
	WHERE uc.ppro_user = @ppro_user
END
go

