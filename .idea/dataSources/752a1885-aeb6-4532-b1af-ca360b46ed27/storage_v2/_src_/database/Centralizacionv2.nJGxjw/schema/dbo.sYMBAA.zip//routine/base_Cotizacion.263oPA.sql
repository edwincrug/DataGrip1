-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	Obtiene la base a partir de folio de Cotización 
-- =============================================
CREATE FUNCTION [dbo].[base_Cotizacion] 
(
	@folio VARCHAR(50)
)
RETURNS VARCHAR(100)
AS
BEGIN
	DECLARE @base VARCHAR(100)
	DECLARE @ipLocal VARCHAR(50) = ''
	SELECT	@ipLocal = local_net_address
	FROM	sys.dm_exec_connections
	WHERE	Session_id = @@SPID;
	SELECT	@base =(CASE WHEN @ipLocal = ip_servidor THEN '[' + nombre_base + '].[dbo].'
						 ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END)
	  FROM	DIG_CAT_BASES_BPRO AS BPRO 
			INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU ON CU.ucu_idsucursal = BPRO.suc_idsucursal AND CU.ucu_idempresa = BPRO.emp_idempresa
	 WHERE	CU.ucu_foliocotizacion = @folio

	RETURN @base

END
;
go

