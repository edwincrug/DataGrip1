-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [expedienteSeminuevo].[SEL_DOCUMENTO_NOTA_CARGO_SP] 'JM1BM1K31F1244253', 4, 6
-- idDetalle con varias notas de cargo en PROD 17661
-- idDetalle con una nota de cargo en PROD 51596
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_DOCUMENTO_NOTA_CARGO_SP]
	@vin VARCHAR(150),
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN

	SET NOCOUNT ON;

    DECLARE @idDetalle VARCHAR(100) = 0; 

	SELECT 
		 @idDetalle = CUD.ucn_idcotizadetalle
	FROM [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES]  CUD
	INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSAL] CU ON CU.ucu_idcotizacion = CUD.ucu_idcotizacion 
	WHERE ucn_noserie = @vin AND ucu_idempresa = @idEmpresa AND ucu_idsucursal = @idSucursal AND ucu_tipocotizacion = 'SN' AND cec_idestatuscotiza IN (18, 20, 15) --Estatus la cotizacion 18, 20 --- QUITAR EL 15 SOLO ES PARA PRUEBAS

	DECLARE @tempTabla TABLE( docto VARCHAR(100), serie VARCHAR(5), folio VARCHAR(15), descripcion VARCHAR(500) );

	INSERT INTO @tempTabla
	SELECT 
		UAW_IDDOCTO AS docto, 
		SUBSTRING(UAW_IDDOCTO, 0, 3) AS serie,
		SUBSTRING(UAW_IDDOCTO, 3, LEN(UAW_IDDOCTO)) AS folio,
		uaw_descripcion 
	FROM [cuentasporcobrar].DBO.UNI_ANTICIPOSWEB 
	WHERE ucn_idcotizadetalle = @idDetalle AND uaw_estatus = 1

	UNION ALL -- QUITAR EL ID EN DURO Y DEJAR EL @idDetalle

	SELECT 
		UAW_IDDOCTO AS docto,
		SUBSTRING(UAW_IDDOCTO, 0, 3) AS serie,
		SUBSTRING(UAW_IDDOCTO, 3, LEN(UAW_IDDOCTO)) AS folio,
		uaw_descripcion  
	FROM [cuentasporcobrar].DBO.UNI_ANTICIPOSWEB 
	WHERE ucn_idcotizadetallepost = @idDetalle AND uaw_estatus = 1

	IF( (SELECT COUNT(docto) FROM @tempTabla) > 0 )
		BEGIN
			SELECT success = 1
			SELECT * FROM @tempTabla WHERE docto IS NOT NULL AND docto <> ''
		END
	ELSE
		BEGIN
			SELECT success = 0
			SELECT msg = 'No se encontraron datos'
		END
	
END
go

