-- =============================================
-- Author:	Genaro Mora Valencia 
-- Create date: 07/12/2015
-- Description: Recupera el catalogo de tipos de Ordenes de Compras 
-- =============================================
-- [SEL_CATALOGO_ORDEN_COMPRA_SP] 
CREATE PROCEDURE [dbo].[SEL_CATALOGO_ORDEN_COMPRA_SP] 

AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY

	SELECT tip_idtipoorden AS idtipoorden
      ,tip_nombre AS nombre
      ,tip_nombrecorto AS nombrecorto
      ,tip_status AS estatus
      ,tip_fechaalta AS fechaalta
      ,tip_idusuarioalta AS idusuarioalta
      ,tip_fechamodifica AS fechamodifica
      ,tip_idusuariomodifica AS tip_idusuariomodifica
  FROM dbo.Tipos_OCCompra_Cuentasxpagar
  
	END TRY
	BEGIN CATCH 
		DECLARE @Mensaje nvarchar(max),
		@Componente nvarchar(50)  ='[SEL_CATALOGO_ORDEN_COMPRA_SP]' 
		select @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje 

	END CATCH 
END


go

