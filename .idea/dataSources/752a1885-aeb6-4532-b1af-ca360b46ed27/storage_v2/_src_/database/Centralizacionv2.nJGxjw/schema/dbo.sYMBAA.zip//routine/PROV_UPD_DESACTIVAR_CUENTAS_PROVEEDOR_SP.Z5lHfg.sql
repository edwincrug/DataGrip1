




------ EXECUTE [dbo].[PROV_UPD_DESACTIVAR_CUENTAS_PROVEEDOR_SP] 'MOFO9103181A9','61401384750947',''
CREATE PROCEDURE [dbo].[PROV_UPD_DESACTIVAR_CUENTAS_PROVEEDOR_SP] 
@rfc     VARCHAR(50) 
,@ctaBancaria    VARCHAR(25)
,@convenio       VARCHAR(10)


AS
BEGIN
--DECLARE  @rfc     VARCHAR(50) = 'MOFO9103181A9'
--,@ctaBancaria    VARCHAR(25) = '61401384750947'
--,@convenio       VARCHAR(10) = ''

BEGIN TRANSACTION
BEGIN TRY
		SET NOCOUNT ON;

		--DECLARE @rfc VARCHAR(20) = 'NME610911L71'

			DECLARE @aux               INT = 1
		DECLARE @max               INT = 0
		DECLARE @idEmpresaBusca    INT = 0
		DECLARE @idSucursal        INT = 0
		DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
		DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
		DECLARE @nomEmpresa        NVARCHAR(100)=NULL
		DECLARE @ipServidor        NVARCHAR(100)=NULL
		DECLARE @cadIpServidor     NVARCHAR(100)=NULL
		DECLARE @consulta          NVARCHAR(MAX)=NULL
		DECLARE @ipServer   NVARCHAR(20)
		DECLARE @cont               INT = 1


		DECLARE @idPersona NUMERIC(18,0)

		DECLARE @tblUsuarios TABLE
		(
		id INT IDENTITY(1,1)
		,idPersona NUMERIC
		,rfc VARCHAR(20)
		)

		INSERT INTO @tblUsuarios
		SELECT  PER_IDPERSONA, PER_RFC  FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_RFC  = @rfc

		--SELECT * from  @tblUsuarios

		DECLARE @existeCuenta TABLE  (  id INT IDENTITY(1,1),
		   idEmpresa         int
		  ,nombreEmpresa     nvarchar(100)
		  ,idPersona       int 
		  ,cuentaBancaria    VARCHAR(25)
		  ,convenio  VARCHAR(25)
		  ,clabe  VARCHAR(20)
		  ,tipoCuenta  VARCHAR(200) 
		  ,banco  VARCHAR(50)
		  ,autorizado  INT
		  ,banxico  VARCHAR(20) 
		 )     

			------------------------------------------------------------
		-- BUSCAMOS EN TODAS LAS CONCENTRADORAS
		------------------------------------------------------------ 
			DECLARE @Bases TABLE  ( id INT IDENTITY(1,1),
							   idEmpresa         int
		,nombreEmpresa     nvarchar(100)
		,nombreSucursal    nvarchar(100)
		,nomBaseConcentra  nvarchar(50)
		,nomBaseMatriz     nvarchar(50)
		,ipServidor        nvarchar(20)
		,idSucursal        int 
		)     

		INSERT INTO @Bases
				SELECT B.[emp_idempresa]
				,A.[emp_nombre]
				,B.[nombre_sucursal]
				,B.[nombre_base]
				,B.[nombre_base_matriz]
				,B.[ip_servidor]
				,B.[sucursal_matriz]
		 FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
			  INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON A.[emp_idempresa]= B.[emp_idempresa]
		WHERE B.tipo = 2


		------------------------------------------------------------
		-- RECORREMOS LAS CONCENTRADORAS PARA BUSCAR EL PROVEEDOR
		------------------------------------------------------------

		WHILE (@cont <= (SELECT count(1) FROM @tblUsuarios) )
		BEGIN

		SELECT @idPersona =  idPersona from @tblUsuarios WHERE id = @cont

		SET @max = (SELECT count(1) FROM @Bases)

		WHILE(@aux <= @max)
		BEGIN

			--SELECT @aux
			SELECT  @idEmpresaBusca   = DB.idEmpresa 
			,@nomEmpresa       = DB.nombreEmpresa
			,@nomBaseConcentra = DB.nomBaseConcentra
			,@nomBaseMatriz    = DB.nomBaseMatriz
			,@idSucursal       = DB.idSucursal
			,@ipServidor       = DB.ipServidor

			  FROM @Bases AS DB 
			 WHERE DB.id = @aux 

			 SET @cadIpServidor = '['+ @ipServidor  +'].'
 
			 SELECT @ipServer = local_net_address
			 FROM sys.dm_exec_connections
			 WHERE Session_id = @@SPID


			IF (@ipServidor = @ipServer)
			BEGIN
			set @cadIpServidor =''
			END

			IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @nomBaseConcentra)) 
			BEGIN

			SET @consulta = ' UPDATE B SET B.BCO_AUTORIZADA = 0
							 FROM '+ @cadIpServidor + @nomBaseConcentra +'.DBO.CON_BANCOS B INNER JOIN  ' + + @cadIpServidor + @nomBaseConcentra + + '.dbo.PNC_PARAMETR AS PG ON B.BCO_BANCO = PG.PAR_IDENPARA AND PG.PAR_TIPOPARA = ''BA'' AND PG.PAR_STATUS = ''A''' + char(13) +  
							' WHERE BCO_NUMCUENTA = ' + ''''+ @ctaBancaria + '''' + 
							  ' AND BCO_CONVENIOCIE = ' + ''''+ @convenio + '''' + 
							' AND BCO_IDPERSONA = ' + cast (@idPersona as varchar(20)) 
    
			 PRINT @consulta
			EXECUTE (@consulta)
			END

 
			SET @aux = @aux + 1
			END

			INSERT INTO [dbo].[DIG_BITACORA_CUENTAS_PROVEEDOR]
			SELECT @idPersona, @ctaBancaria   ,@convenio, 'Baja de Cuenta Bancaria', GETDATE()


		SET @cont = @cont + 1
		END 

		------------------------------------------------------------
		-- RESULTADO FINAL
		------------------------------------------------------------

		SELECT 1 result

  COMMIT TRANSACTION
END TRY

  BEGIN CATCH
		ROLLBACK TRANSACTION
		--SELECT  ERROR_MESSAGE()
		SELECT  0 result
		
  END CATCH
END



go

