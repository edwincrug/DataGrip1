-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <17/06/2020>
-- Description:	<Regresa el nombre del usuario que subio el correo>
--TESET [expedienteSeminuevo].[SEL_USUARIO_DOCUMENTO] 1
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_USUARIO_DOCUMENTO]
	@idDocumentoGuardado INT
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @idUsuario INT, @idExpediente INT, @vin VARCHAR(100), @observaciones VARCHAR(200), @nombreDocumento VARCHAR(200);

	SELECT 
		@idUsuario = idUsuario,
		@idExpediente = id_expediente,
		@observaciones = observacionesDocumento,
		@nombreDocumento = D.doc_nombre
	FROM [expedienteSeminuevo].[documentosExpediente] DE
	INNER JOIN [expedienteSeminuevo].[cat_documentos] D ON D.id_documento = DE.id_documento
	WHERE id_documentoGuardado = @idDocumentoGuardado;

	SELECT 
		@vin = exp_vin 
	FROM [expedienteSeminuevo].[expedientes] WHERE id_expediente = @idExpediente

	SELECT 
		@vin AS vin,
		(usu_nombre + ' ' +  usu_paterno + ' ' + usu_materno) AS nombreUsuario,
		usu_correo,
		@observaciones AS observaciones,
		@nombreDocumento AS nombreDocumento
	FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @idUsuario
END
go

