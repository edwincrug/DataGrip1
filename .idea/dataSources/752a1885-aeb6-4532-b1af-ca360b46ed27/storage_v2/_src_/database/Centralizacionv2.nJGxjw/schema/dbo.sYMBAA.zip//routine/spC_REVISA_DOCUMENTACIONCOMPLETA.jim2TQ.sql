

/*
select * from DIG_NODO_DOC --Aqui indica si es mandatorio o no.
select * from DIG_EXPNODO_DOC --Aqui es donde actualizan la Fecha_Creacion

Recorre la tabla DIG_NODO_DOC y por cada documento marcado como mandatorio
lo busca en DIG_EXPNODO_DOC, si todos los documentos mandatorios ya estan creados,
entonces coloca la orden de compra en estatus 10 Documentacion completa.

20160606 Revisa que en el caso de la factura del proveedor doc_id=20 esté en estatus 2 (Factura Válida),
en el portal de Proveedores para poder colocar en Documentación Completa.
inserta en cuentasxpagar..cxp_movimientosorden como log para indicar que esa orden de compra esta con documentacion completa.

Regresa 1 si esta completo el expediente 0 si falta algun documento.

*/

CREATE PROCEDURE [dbo].[spC_REVISA_DOCUMENTACIONCOMPLETA](@iProc_Id int,@sFolio_Operacion varchar(50), @iNodo_Hasta int, @iResultado int OUTPUT) --with recompile
 AS
declare
@iTope int,
@iIndice int,
@iNodo_Id int,
@iDoc_Id int,
@dFecha_Creacion smalldatetime,
@ioce_idtipoorden int,
@iEstatusFactura int

begin 

set nocount on

CREATE TABLE #DOC_MANDATORIOS
	(
     POSICION [smallint] IDENTITY (1, 1),
	 Nodo_Id int,
	 Doc_Id int,
	 Esta int
	)

--Seleccionamos los documentos mandatorios y suponemos que no estan Esta = 0
insert into #DOC_MANDATORIOS(Nodo_Id,Doc_Id,Esta)
SELECT Nodo_Id, Doc_Id, 0 from DIG_NODO_DOC 
WHERE Es_Mandatorio = 1 and Proc_Id=@iProc_Id
and Nodo_id <= @iNodo_Hasta --solo considera los documentos mandatorios hasta este nodo.
order by Orden


    Select @iTope = Max(POSICION) from #DOC_MANDATORIOS
    Select @iIndice = 1

			Select @iNodo_Id=0
			Select @iDoc_Id=0
			Select @dFecha_Creacion = '19000101' 
			select @iEstatusFactura=0

    WHILE  (@iIndice <= @iTope)
     begin
	    SET ROWCOUNT 1 
		Select @iNodo_Id=Nodo_Id, @iDoc_Id=Doc_Id FROM #DOC_MANDATORIOS where POSICION = @iIndice
	    SET ROWCOUNT 0                                          		    
	
		If Not EXISTS (Select 1 from [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] WHERE Proc_Id = @iProc_Id and Nodo_Id = @iNodo_Id and Doc_Id=@iDoc_Id and Folio_Operacion = @sFolio_Operacion)	
		 begin                    
			insert into [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] (Proc_Id,Nodo_Id,Folio_Operacion,Doc_Id,Fecha_Creacion,Usuario_BPRO,Doc_Extencion)
			values (@iProc_Id,@iNodo_Id,@sFolio_Operacion,@iDoc_Id,null,null,null)
         end
		
		Select @dFecha_Creacion = Fecha_Creacion From [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC]
		WHERE Proc_Id = @iProc_Id and Nodo_Id = @iNodo_Id and Doc_Id=@iDoc_Id and Folio_Operacion = @sFolio_Operacion

		IF (Isnull(@dFecha_Creacion,'19000101') <> '19000101')		
		begin --se trata de un documento mandatorio que ya tiene fecha de creación por lo que le ponemos que ya esta
		    if (@iDoc_Id=20) --20 es la factura del proveedor
		    begin
		       --20160606 Validamos que la factura en el portal de proveedores esté en estatus = 2 [validada desde digitalizacion]
		      select @iEstatusFactura = estatus from [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]
			  where folioorden=@sFolio_Operacion
		      if (@iEstatusFactura = 2)
		        begin
		          update #DOC_MANDATORIOS set Esta = 1 where POSICION=@iIndice
		        end
		    end --de que es la factura del proveedor
		    else
		     begin 
				update #DOC_MANDATORIOS set Esta = 1 where POSICION=@iIndice  
			 end 	
		end	

			Select @iIndice = @iIndice + 1	
			Select @iNodo_Id=0
			Select @iDoc_Id=0
			Select @dFecha_Creacion = '19000101' 	   
			Select @iEstatusFactura = 0
     end
     
	 --20170420 Dependiendo del tipo de orden de compra debe estar en un estatus determinado para poder pasar a documentacion completa
	  	--obtenemos en que nodo esta la orden
		SELECT @iNodo_Id = Nodo_Id   From [Centralizacionv2].[dbo].[DIG_EXP_NODO] 
		where Nodo_Estatus_Id = 2 --ABIERTO
		and [Folio_Operacion] = @sFolio_Operacion
		AND [Proc_Id] = @iProc_Id
		order by Nodo_Id
		
		--obtenemos el tipo de orden	
		select @ioce_idtipoorden = oce_idtipoorden from [cuentasxpagar].[dbo].[cxp_ordencompra] where oce_folioorden=@sFolio_Operacion			
	  --
    --Ahora comprobamos si estan todos los documentos mandatorios.
    Select @iIndice = Count(*) from #DOC_MANDATORIOS where Esta = 1

    print 'Cantidad de documentos obligatorios existentes: ' + Convert(char(3),@iIndice) + ' de ' + Convert(char(3),@iTope) + ' documentos mandatorios'
    Select * from #DOC_MANDATORIOS --por borrar
	if (@iIndice = @iTope  and  @iNodo_Id = 7) --Solo si está en el nodo 7 Nodo donde se carga la factura
    begin      		
	if Exists(select 1 from [cuentasxpagar].[dbo].[cxp_ordencompra] where oce_folioorden=@sFolio_Operacion and sod_idsituacionorden<>10)
	 begin	
		BEGIN TRANSACTION PasaADocumentacionCompleta
						
				Update [cuentasxpagar].[dbo].[cxp_ordencompra] set sod_idsituacionorden = 10 where oce_folioorden=@sFolio_Operacion       	        
       
				insert into [cuentasxpagar].[dbo].[cxp_movimientosorden] (mov_idusuariomovimiento,mov_fechamovimiento,mov_horamovimiento,oce_folioorden,sod_idsituacionorden)
				values(0,getdate(),getdate(),@sFolio_Operacion,10)
       
       	       insert into [Centralizacionv2].[dbo].[DIG_BITACORA] (fecha,quien,que,aquien) values (GETDATE(),'spC_REVISA_DOCUMENTACIONCOMPLETA','Se pone la orden de compra en Documentacion Completa 10',@sFolio_Operacion)       	       
	           Select @iResultado=1	
	           
	           print 'Se pone en Documentacion completa: ' + @sFolio_Operacion
		COMMIT TRANSACTION PasaADocumentacionCompleta			   
         end
    end 		
    else
    begin	
	Select @iResultado=0	
    end	

--Select * from #DOC_MANDATORIOS

set nocount off
end

/*

declare
@iProc_Id int,
@sFolio_Operacion varchar(50),
@iNodo_Hasta int,
@iResultado int

select @iProc_Id =1
select @sFolio_Operacion='AU-AT-MIR-RE-PE-108'
select @iNodo_Hasta = 7 --Programa de pagos, Autorizacion Programación de Pagos.
select @iResultado = -1

execute spC_REVISA_DOCUMENTACIONCOMPLETA @iProc_Id,@sFolio_Operacion, @iNodo_Hasta,@iResultado OUTPUT 

print 'Resultado afuera ' + Convert(char(20),@iResultado)

select distinct Nodo_Id,Doc_Id from DIG_NODO_DOC
where Es_Mandatorio=1 --Aqui indica si es mandatorio o no.
and Proc_Id=1
and Doc_Id=20


SELECT Nodo_Id, Doc_Id, 0, * from DIG_NODO_DOC 
WHERE Es_Mandatorio = 1 and Proc_Id=1
and Nodo_id <= 7 --solo considera los documentos mandatorios hasta este nodo.
order by Orden

select * from  DIG_CATDOCUMENTO where Doc_Id in (11,20,15)

select * from DIG_CATDOCUMENTO

insert into DIG_EXPNODO_DOC 
values (1,12,'AU-ZM-ZAR-OT-PE-20',20,'20160210',null,null)

select estatus from Centralizacionv2..PPRO_DATOSFACTURAS
			  where folioorden='AU-ZM-ZAR-OT-PE-72'

4
5
7
8
9
10
11
12


SELECT Nodo_Id, Doc_Id, 0 from DIG_NODO_DOC 
WHERE Es_Mandatorio = 1 and Proc_Id=1
and Nodo_id <= 9



select * from DIG_EXPNODO_DOC --Aqui es donde actualizan la Fecha_Creacion
where Folio_Operacion = 'AU-ZM-ZAR-OT-PE-20'
and Doc_Id=20
and  Isnull(Fecha_Creacion,'')=''

Select  Fecha_Creacion From DIG_EXPNODO_DOC
		WHERE Proc_Id = 1 and Nodo_Id = 7 and Doc_Id in (20,15,11) and Folio_Operacion = 'AU-ZM-ZAR-OT-PE-72'

select sod_idsituacionorden,* from cuentasxpagar..cxp_ordencompra where oce_folioorden = 'AU-ZM-ZAR-OT-PE-20'

update cuentasxpagar..cxp_ordencompra set sod_idsituacionorden=9 where oce_folioorden = 'AU-ZM-ZAR-OT-PE-20'


select * from cuentasxpagar..cat_situacionorden



update DIG_EXPNODO_DOC set Fecha_Creacion = '20160210'
where Folio_Operacion='AU-ZM-ZAR-OT-PE-20'
and Nodo_Id in (6)
and Doc_Id = 20
and Isnull(Fecha_Creacion,'')=''

SELECT Nodo_Id, Doc_Id, Es_Mandatorio from DIG_NODO_DOC 
WHERE Es_Mandatorio = 1 and Proc_Id=1
and Nodo_id <= 9


nodo 7 estatus 15 es IF --> documentacion completa
nodo 7 estatus y  es PE --> documentacion completa

-- ======================================================================================================
--    DIGITALIZACIÓN Queries para verificar información del aplicativo de los errores en PRODUCCIÓN
--    Cuentas por Pagar CXP		proceso = 1
--	  Cuentas por Cobrar CXC	proceso = 2
-- ======================================================================================================

DECLARE @folio VARCHAR(20) = 'AU-AU-UNI-UN-PE-22'
		,@proceso INT

-- Verifico si es CXP o CXC
IF (EXISTS(SELECT * FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE [oce_folioorden] = @folio))
	BEGIN
		SET @proceso = 1
	END
ELSE IF (EXISTS (SELECT * FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE [ucu_foliocotizacion] = @folio))
	BEGIN
		SET @proceso = 2
	END

IF(@proceso = 1)
	BEGIN
		SELECT 'ENTRE A CXP'

		-- ======================================================================================================
		--	  Cuentas por Pagar CXP
		-- ======================================================================================================

		-- Verificar la Orden de Compra 

		SELECT 'ORDEN DE COMPRA'
		SELECT *
		  FROM [cuentasxpagar].[dbo].[cxp_ordencompra] 
		 WHERE [oce_folioorden] = @folio	
		
		-- Verifica en que situación se encuentra la Orden de Compra

		SELECT 'SITUACIÓN ORDEN DE COMPRA'
		SELECT OC.[sod_idsituacionorden]
			  ,SOC.[sod_nombresituacion]      
		  FROM [cuentasxpagar].[dbo].[cxp_ordencompra] OC
			   INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SOC ON OC.[sod_idsituacionorden] = SOC.[sod_idsituacionorden]
		 WHERE [oce_folioorden] = @folio

		-- Verifica el EXPEDIENTE de la Orden de Compra

		SELECT 'EXPEDIENTE'
		SELECT * 
		  FROM [Centralizacionv2].[dbo].[DIG_EXPEDIENTE]
		 WHERE [Folio_Operacion] = @folio 
		   AND [Proc_Id] = @proceso 

		--Verifica el estatus de los nodos

		SELECT 'NODOS'

		SELECT *, CASE WHEN Nodo_Estatus_Id = 1 THEN 'PENDIENTE'
						WHEN Nodo_Estatus_Id = 2 THEN 'ABIERTO'
						WHEN Nodo_Estatus_Id = 3 THEN 'CERRADO'
						END     
		 FROM [Centralizacionv2].[dbo].[DIG_EXP_NODO]     
		WHERE [Folio_Operacion] = @folio
		  AND [Proc_Id] = @proceso

		-- Verifica los documentos por nodo

		SELECT 'DOCUMENTOS POR NODO'

		SELECT EXPDOC.[Proc_Id]
			  ,[Nodo_Id]
			  ,[Folio_Operacion]
			  ,EXPDOC.[Doc_Id]
			  ,[Fecha_Creacion]
			  ,[Usuario_BPRO]
			  ,EXPDOC.[Doc_Extencion]
			  ,[Doc_Nombre]
			  ,[Doc_Descripcion]
		 FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] EXPDOC
			  INNER JOIN [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] CATDOC ON EXPDOC.Doc_Id = CATDOC.Doc_Id
		WHERE [Folio_Operacion] = @folio 
		  AND EXPDOC.[Proc_Id] = @proceso 
		ORDER BY Nodo_Id

		--Verifica el tipo de folio 

		SELECT 'TIPO DE FOLIO'
		SELECT CASE WHEN EXISTS (SELECT irr_folioinicial FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac] WHERE [irr_folioinicial] = @folio) THEN
						'TIPO DE FOLIO: ORDEN DE COMPRA' 
					   WHEN EXISTS(SELECT irr_folionuevo FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac] WHERE [irr_folionuevo] =  @folio) THEN
						'TIPO DE FOLIO: REMISIÓN'
					   WHEN EXISTS(SELECT ifr_folionuevo FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac] WHERE [ifr_folionuevo] = @folio) THEN
						'TIPO DE FOLIO: FACTURA DE REFACCIONES'
					   ---
					   WHEN EXISTS(SELECT ifs_folionuevo 
									 FROM [cuentasxpagar].[dbo].[cxp_integracionfacser] 
									WHERE [ifs_folionuevo] = @folio) THEN
						'TIPO DE FOLIO: FACTURA DE SERVICIO'
					   ---
					   ELSE 'TIPO DE FOLIO: ORDEN DE COMPRA'
				   end AS tipofolio
    
		-- Verificar desde la orden de compra que usarios tienen acceso a ella

		SELECT 'USUARIOS ACCESO FOLIO'
		SELECT  emp_idempresa
			   ,suc_idsucursal
			   ,dep_iddepartamento
			   ,usu_idusuario
		  FROM [cuentasxpagar].[dbo].[cxp_ordencompra] OC
			   INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] ORG ON OC.oce_idempresa = ORG.emp_idempresa 
																			   AND OC.oce_idsucursal = ORG.suc_idsucursal
																			   AND OC.oce_iddepartamento = ORG.dep_iddepartamento
		 WHERE [oce_folioorden] = @folio

	END
ELSE IF (@proceso = 2)
	BEGIN
		
		SELECT 'ENTRE A CXC'

		-- ======================================================================================================
		--	  Cuentas por Cobrar CXC
		-- ======================================================================================================

		-- Verificar la Orden de Compra 

		SELECT 'ORDEN DE COMPRA'
		SELECT *
		  FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] 
		 WHERE [ucu_foliocotizacion] = @folio	

		-- Verifica en que estatus esta la cotización 

		SELECT ECU.[cec_idestatuscotiza]
				,ECU.[cec_nombre]
		FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] CU
				INNER JOIN [cuentasporcobrar].[dbo].[cat_estatuscotiza] ECU ON CU.[cec_idestatuscotiza] = ECU.[cec_idestatuscotiza]
		WHERE [ucu_foliocotizacion] = @folio

		-- Verifica si el tipo de venta existe 

		SELECT 'TIPO DE VENTA'
		SELECT Tip_Clave 
		  FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] COTI
			   INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_TIPO_VENTA] VENTA ON COTI.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS = VENTA.Tip_Clave COLLATE Modern_Spanish_CI_AS
		 WHERE [ucu_foliocotizacion] = @folio

		-- Verifica el EXPEDIENTE de la Orden de Compra

		SELECT 'EXPEDIENTE'
		SELECT * 
		  FROM [Centralizacionv2].[dbo].[DIG_EXPEDIENTE]
		 WHERE [Folio_Operacion] = @folio 
		   AND [Proc_Id] = @proceso 

		--Verifica el estatus de los nodos

		SELECT 'NODOS'

		SELECT *, CASE WHEN Nodo_Estatus_Id = 1 THEN 'PENDIENTE'
						WHEN Nodo_Estatus_Id = 2 THEN 'ABIERTO'
						WHEN Nodo_Estatus_Id = 3 THEN 'CERRADO'
						END     
		 FROM [Centralizacionv2].[dbo].[DIG_EXP_NODO]     
		WHERE [Folio_Operacion] = @folio
		  AND [Proc_Id] = @proceso

		-- Verifica los documentos por nodo

		SELECT 'DOCUMENTOS POR NODO'


		SELECT EXPDOC.[Proc_Id]
			  ,[Nodo_Id]
			  ,[Folio_Operacion]
			  ,EXPDOC.[Doc_Id]
			  ,[Fecha_Creacion]
			  ,[Usuario_BPRO]
			  ,EXPDOC.[Doc_Extencion]
			  ,[Doc_Nombre]
			  ,[Doc_Descripcion]
		 FROM [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] EXPDOC
			  INNER JOIN [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] CATDOC ON EXPDOC.Doc_Id = CATDOC.Doc_Id
		WHERE [Folio_Operacion] = @folio 
		  AND EXPDOC.[Proc_Id] = @proceso 
		ORDER BY Nodo_Id
    
		-- Verificar desde la orden de compra que usarios tienen acceso a ella

		SELECT 'USUARIOS ACCESO FOLIO'
		SELECT  emp_idempresa
			   ,suc_idsucursal
			   ,dep_iddepartamento
			   ,usu_idusuario
		  FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] OC
			   INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] ORG ON OC.ucu_idempresa = ORG.emp_idempresa 
																			   AND OC.ucu_idsucursal = ORG.suc_idsucursal
																			   AND OC.ucu_iddepartamento = ORG.dep_iddepartamento
		 WHERE [ucu_foliocotizacion] = @folio

	END


*/
go

