-- =============================================
-- Author:		<JJSY>
-- Create date: <24/06/2020>
-- Description:	Valida los expedientes que estan incompletos
-- TEST [expedienteSeminuevo].[INS_EXPEDIENTES_MAIL] 1
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[INS_EXPEDIENTES_MAIL]
  @idProceso INT 
AS
BEGIN
	BEGIN TRY
		DECLARE @allVines TABLE (id INT IDENTITY, id_expediente INT, exp_vin VARCHAR(150), exp_empresa INT, exp_sucursal INT, base VARCHAR(200));
		DECLARE @tempvinoficial TABLE (id INT IDENTITY,idExpediente INT, vinExpediente VARCHAR(100),empresa INT,sucursal INT ,situacion NVARCHAR(MAX),proceso INT, base VARCHAR(100) );
		DECLARE @tableFinal TABLE (id INT IDENTITY, idExpediente INT, idDocumento INT, idDocumentoInsertado INT, nombreDocumento VARCHAR(200), vinExpediente VARCHAR(100), finalEmpresa INT, finalSucursal INT);
		DECLARE @queryAllVines VARCHAR(MAX);

		INSERT INTO @allVines
		SELECT 
			 id_expediente,
			 exp_vin,
			 exp_empresa,
			 exp_sucursal,
			 nombre_base
		FROM [expedienteSeminuevo].[expedientes] E
		INNER JOIN DIG_CAT_BASES_BPRO BD ON BD.emp_idempresa = E.exp_empresa AND BD.suc_idsucursal = E.exp_sucursal
		WHERE exp_flotilla = 0

		DECLARE @maxAllVin INT, @minAllVin INT

		SELECT 
			@maxAllVin = MAX(id),
			@minAllVin = MIN(id)
		FROM @allVines

		WHILE( @minAllVin <= @maxAllVin )
			BEGIN
				DECLARE @empresaAllVin INT, @sucursalAllVin INT, @vinAllVin VARCHAR(150), @baseAllVin VARCHAR(150);
				SELECT 
					 @empresaAllVin = exp_empresa,
					 @sucursalAllVin = exp_sucursal,
					 @vinAllVin = exp_vin,
					 @baseAllVin = base
				FROM @allVines WHERE id =  @minAllVin

		
				SET @queryAllVines = 'SELECT 
										id_expediente,
										VEH_NUMSERIE,
										exp_empresa,
										exp_sucursal,
										VEH_SITUACION, 
										CASE WHEN VEH_SITUACION LIKE ''%SVEN%'' THEN 2  ELSE  1 
										END AS proceso,
										''' + @baseAllVin + '''
									FROM [' + @baseAllVin + '].[DBO].[SER_VEHICULO] S
									INNER JOIN [expedienteSeminuevo].[expedientes] E ON S.VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS =E.exp_vin COLLATE Modern_Spanish_CI_AS
									WHERE VEH_NUMSERIE = ''' + @vinAllVin + ''' AND E.exp_empresa = ' + CONVERT(VARCHAR(5), @empresaAllVin) + ' AND E.exp_sucursal = ' + CONVERT(VARCHAR(5), @sucursalAllVin) + ' AND VEH_SITUACION NOT IN (''SCANCEL'') '

				INSERT INTO @tempvinoficial
				EXEC (@queryAllVines)

				SET @minAllVin = @minAllVin + 1;
			END

		DECLARE @maxSituacion INT, @minSituacion INT;

		SELECT 
			@maxSituacion = MAX(id),
			@minSituacion = MIN (id)
		FROM @tempvinoficial

		DECLARE @complementoQuery VARCHAR(MAX);

		IF (@idProceso = 1)
		BEGIN
			SET @complementoQuery= ''''
		END
		ELSE IF (@idProceso = 2)
		BEGIN
			SET @complementoQuery = ''' AND VEH_SITUACION LIKE ''%SVEN%'''
		END

		-------- comienza el recorrido por los documentos y tabla de vines 		
		WHILE ( @minSituacion <= @maxSituacion )
			BEGIN
				DECLARE @documentosExistentes TABLE ( id INT IDENTITY, idExpedienteIns INT, idDocumentoIns INT,empresa INT,sucursal INT);
				DECLARE @idExpediente INT = 0, @vinExpediente VARCHAR(100), @baseSeach VARCHAR(100);
				DECLARE @queryFisicaMoral NVARCHAR(MAX) = '', @idCliente INT, @fisicaMoral VARCHAR(5);
				
				SELECT 
					@idExpediente = idExpediente,
					@vinExpediente = vinExpediente,
					@baseSeach = base
				FROM @tempvinoficial WHERE id = @minSituacion


				IF ( @idProceso = 1 )
					BEGIN
						SET @queryFisicaMoral = 'SELECT 
												@clienteId = OC.oce_idproveedor 
											FROM ' + @baseSeach + '.DBO.SER_VEHICULO SV
											INNER JOIN cuentasxpagar.[dbo].[cxp_detalleseminuevos] DS ON DS.asn_numeroserie =  SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
											INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] OC ON OC.oce_folioOrden = DS.oce_folioorden
											WHERE OC.sod_idsituacionorden <> 4 AND VEH_NUMSERIE = ''' + @vinExpediente + @complementoQuery

						EXEC sp_executesql @queryFisicaMoral, N'@clienteId INT OUTPUT', @clienteId = @idCliente OUTPUT
					END
				ELSE
					BEGIN
						SELECT 
							@idCliente = ucu_idcliente
						FROM cuentasporcobrar.[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] CD
						INNER JOIN cuentasporcobrar.[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_idCotizacion = CD.ucu_idCotizacion
						WHERE CD.ucn_noserie = @vinExpediente AND cec_idestatuscotiza <> 14 AND ucu_tipocotizacion = 'SN'
					END

	
				SELECT @fisicaMoral = PER_TIPO FROM GA_corporativa.DBO.PER_PERSONAS WHERE PER_IDPERSONA = @idCliente

					INSERT INTO @documentosExistentes
					SELECT 
						TV.idExpediente,
						DE.id_documento,
						TV.empresa,
						TV.sucursal
					FROM @tempvinoficial TV
					INNER JOIN [expedienteSeminuevo].[documentosExpediente] DE ON DE.id_expediente = TV.idExpediente
					WHERE id = @minSituacion AND DE.id_proceso = @idProceso AND DE.id_expediente = @idExpediente
					GROUP BY DE.id_documento, TV.idExpediente,TV.empresa,TV.sucursal			

				INSERT INTO @tableFinal
				SELECT 
					@idExpediente AS idExpediente,
					A.id_documento,
					B.idDocumentoIns, 
					A.doc_Nombre,
					@vinExpediente AS vinExpediente,
					B.empresa,
					B.sucursal
				FROM (
						SELECT 
							id_documento, 
							doc_nombre, 
							doc_extencion, 
							doc_opcional,
							doc_usuarios, 
							doc_proceso,
							doc_varios
						FROM [expedienteSeminuevo].[cat_documentos] 
						WHERE doc_proceso = @idProceso AND doc_opcional = 0  AND doc_activo = 1 AND ((@fisicaMoral = 'MOR' AND doc_moral = 1) OR (@fisicaMoral = 'FIS' AND doc_fisica = 1) OR (@fisicaMoral = 'FIE' AND doc_fisicaAE = 1))) AS A
						LEFT JOIN (
							SELECT 
								* 
							FROM @documentosExistentes dE
							INNER JOIN  [expedienteSeminuevo].[expedientes] E ON DE.idExpedienteIns = E.id_expediente
							WHERE idExpedienteIns = @idExpediente) AS B ON B.idDocumentoIns = A.id_documento AND A.doc_proceso = @idProceso
				SET @minSituacion = @minSituacion + 1
			END

			--select * from @tableFinal where idExpediente = 4		--SELECT * FROM @tableFinal WHERE idExpediente IN (4, 1)

			DECLARE @tableFinalFinal TABLE (id INT IDENTITY, idExpediente INT, idDocumento INT, idDocumentoInsertado INT, nombreDocumento VARCHAR(200), vinExpediente VARCHAR(100),empresa INT,sucursal INT);

			IF (@idProceso = 1)
				BEGIN	
					INSERT INTO @tableFinalFinal
					SELECT
						TFF.idExpediente,
						TFF.idDocumento,
						TFF.idDocumentoInsertado,
						TFF.nombreDocumento,
						TFF.vinExpediente,
						TVV.empresa,
						TVV.sucursal
					FROM @tableFinal TFF
					INNER JOIN @tempvinoficial TVV ON TFF.idExpediente = TVV.idExpediente 

				END 
			ELSE
				BEGIN	
					INSERT INTO @tableFinalFinal
					SELECT
						TFF.idExpediente,
						TFF.idDocumento,
						TFF.idDocumentoInsertado,
						TFF.nombreDocumento,
						vw.PEN_NUMSERIE,
						TVV.empresa,
						TVV.sucursal
					FROM @tableFinal TFF
					INNER JOIN @tempvinoficial TVV ON TFF.idExpediente = TVV.idExpediente 
					INNER JOIN VW_FECHA_ENTREGA_UNIDAD vw on TVV.vinExpediente  = vw.PEN_NUMSERIE COLLATE DATABASE_DEFAULT-- JOin con la tabla tenmporal en caso de ser necesario
					WHERE TVV.proceso = @idProceso
					AND vw.PEN_FECHAENTREGA_REAL IS NOT NULL
				END
			--SELECT * FROm @tableFinalFinal
			DECLARE @tempRegistros TABLE (id INT IDENTITY, vin NVARCHAR (20),empresa INT,sucursal INT,fechaInsercion datetime );
			DECLARE @maxCount INT, @minCount INT;

			INSERT INTO @tempRegistros
			SELECT  
				vinExpediente,
				TFFF.empresa,
				TFFF.sucursal,
				GETDATE()
			FROM @tableFinalFinal TFFF
			WHERE idDocumentoInsertado IS  NULL
			GROUP BY idExpediente, vinExpediente, TFFF.empresa, TFFF.sucursal HAVING COUNT(*) <> 0

		IF (@idProceso = 1)
			BEGIN
				PRINT 'ENTRO1'
					MERGE  [expedienteSeminuevo].[maillExpediente] AS TARGET
					USING @tempRegistros AS SOURCE ON TARGET.vin = SOURCE.vin AND TARGET.empresa = SOURCE.empresa AND TARGET.sucursal = SOURCE.sucursal
					WHEN MATCHED THEN
						--UPDATE SET TARGET.dias = DATEDIFF(DAY, TARGET.fechaInsercion, GETDATE() )
						UPDATE SET TARGET.dias = (DATEDIFF(DAY, TARGET.fechaInsercion, GETDATE()) -  ((datediff(wk, TARGET.fechaInsercion, GETDATE())) + (SELECT 
																																								COUNT(*) 
																																							FROM GA_WebAndrade.dbo.AppHoliday 
																																							WHERE CONVERT(date, CONVERT(varchar(50),(CASE WHEN [Repeat] = 1 THEN DATEPART(yy, GETDATE()) ELSE [Year] END *10000 + [Month]*100 + [Day])) ,104) BETWEEN TARGET.fechaInsercion AND CONVERT(DATE,GETDATE()))))
					WHEN NOT MATCHED BY TARGET THEN
						INSERT ( vin,empresa,sucursal,fechaInsercion, dias )
						VALUES ( SOURCE.vin,SOURCE.empresa,SOURCE.sucursal,GETDATE(), 0 )
					WHEN NOT MATCHED BY SOURCE THEN
					DELETE;
				END 
			ELSE
			BEGIN
				PRINT 'ENTRO2'
				MERGE  [expedienteSeminuevo].[maillExpedienteP2] AS TARGET
				USING @tempRegistros AS SOURCE ON TARGET.vin = SOURCE.vin AND TARGET.empresa = SOURCE.empresa AND TARGET.sucursal = SOURCE.sucursal
				WHEN MATCHED THEN
					--UPDATE SET TARGET.dias = DATEDIFF(DAY, TARGET.fechaInsercion, GETDATE() )
					UPDATE SET TARGET.dias = (DATEDIFF(DAY, TARGET.fechaInsercion, GETDATE()) -  ((datediff(wk, TARGET.fechaInsercion, GETDATE())) + (SELECT 
																																								COUNT(*) 
																																							FROM GA_WebAndrade.dbo.AppHoliday 
																																							WHERE CONVERT(date, CONVERT(varchar(50),(CASE WHEN [Repeat] = 1 THEN DATEPART(yy, GETDATE()) ELSE [Year] END *10000 + [Month]*100 + [Day])) ,104) BETWEEN TARGET.fechaInsercion AND CONVERT(DATE,GETDATE()))))
				WHEN NOT MATCHED BY TARGET THEN
					INSERT ( vin,empresa,sucursal,fechaInsercion, dias )
					VALUES ( SOURCE.vin,SOURCE.empresa,SOURCE.sucursal,GETDATE(), 0 )
				WHEN NOT MATCHED BY SOURCE THEN
					DELETE;
			END

		SELECT success = 1;
	END TRY
	BEGIN CATCH
		SELECT success = 0;
	END CATCH 
	
END


go

