

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	Validar los expedientes a los que les falta subir algun docuemnto mandatorio 
--				a partir de la fecha 18-05-2020
-- =============================================
CREATE PROCEDURE [dbo].[EXP_SAVE_FOLIOS_MAIL]

AS
BEGIN
	BEGIN TRY
		DECLARE @folios TABLE ( idFolio INT IDENTITY, folio VARCHAR(100), fechaInsercion datetime );
		DECLARE @maxCount INT, @minCount INT;

		INSERT INTO @folios
		SELECT	DISTINCT E.Folio_Operacion
				,GETDATE()
		FROM	[Centralizacionv2].dbo.DIG_EXPEDIENTE AS E 
				INNER JOIN [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] AS ND ON ND.Folio_Operacion = E.Folio_Operacion
				INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] AS C ON C.ucu_foliocotizacion = E.Folio_Operacion COLLATE DATABASE_DEFAULT AND C.ucu_tipocotizacion = 'NU'
				INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON C.ucu_idcotizacion = CD.ucu_idcotizacion
				INNER JOIN Centralizacionv2.dbo.[VW_FECHA_ENTREGA_UNIDAD] VW ON VW.PEN_NUMSERIE = CD.ucn_noserie AND VW.PEN_FECHAENTREGA_REAL IS NOT NULL 
				INNER JOIN Centralizacionv2.dbo.DIG_CANAL_VENTA AS CV ON CV.canalVenta = C.ucu_idtipoventa COLLATE DATABASE_DEFAULT
				INNER JOIN Centralizacionv2.dbo.EXP_DOCUMENTOS_MANDATORIO AS DM ON DM.idTipoVenta = CV.idTipoVenta AND DM.idEmpresa = C.ucu_idempresa AND DM.idSucursal = C.ucu_idsucursal AND DM.Doc_Id = ND.Doc_Id 
		WHERE	E.Proc_Id = 2 AND E.Fecha_Inicio > CONVERT(DATETIME,'18-05-2020',103) AND E.Estatus_Id <> 2 AND ND.Fecha_Creacion IS NULL 
				AND C.cec_idestatuscotiza in (20)
				AND cd.ucn_idFactura <> '' 

				
		SELECT 
			@maxCount = MAX(idFolio),
			@minCount = MIN(idFolio) 
		FROM @folios;
		

		MERGE EXP_FOLIOS_MAIL AS TARGET
		USING @folios AS SOURCE ON TARGET.folio = SOURCE.folio
		WHEN MATCHED THEN
			UPDATE SET TARGET.dias = DATEDIFF(DAY, TARGET.fechaInsercion, GETDATE() )
		WHEN NOT MATCHED BY TARGET THEN
			INSERT ( folio, fechaInsercion, dias )
			VALUES ( SOURCE.folio, GETDATE(), 0 )
		WHEN NOT MATCHED BY SOURCE THEN
			DELETE;

		SELECT success = 1;
	END TRY
	BEGIN CATCH
		SELECT success = 0;
	END CATCH 
	--DECLARE @folios TABLE ( idFolio INT IDENTITY, folio VARCHAR(100), fechaInsercion datetime );
	--DECLARE @maxCount INT, @minCount INT;

	--INSERT INTO @folios
	--SELECT 
	--	DISTINCT N.Folio_Operacion,
	--	GETDATE()
	--FROM [Centralizacionv2].[dbo].[DIG_EXP_NODO] AS N
	--INNER JOIN Centralizacionv2.dbo.DIG_EXPEDIENTE As E ON E.Folio_Operacion = N.Folio_Operacion AND E.Estatus_Id <> 2
	--INNER JOIN [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] AS ND ON N.Folio_Operacion = ND.Folio_Operacion
	--INNER JOIN [Centralizacionv2].[dbo].[DIG_NODO_DOC] AS PD ON PD.Doc_Id = ND.Doc_Id AND ND.Fecha_Creacion IS NULL
	--INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = N.Folio_Operacion COLLATE DATABASE_DEFAULT
	--INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON C.ucu_idcotizacion = CD.ucu_idcotizacion
	--INNER JOIN [VW_FECHA_ENTREGA_UNIDAD] VW ON VW.PEN_NUMSERIE = CD.ucn_noserie
	--WHERE N.Nodo_Id = 5 AND FechaInicio IS NULL AND E.Proc_Id = 2 AND VW.PEN_FECHAENTREGA_REAL IS NOT NULL
	--AND YEAR(C.ucu_fechacotiza) = 2019 AND CD.ucn_idFactura <> ''

	--SELECT 
	--	@maxCount = MAX(idFolio),
	--	@minCount = MIN(idFolio) 
	--FROM @folios

	--MERGE EXP_FOLIOS_MAIL AS TARGET
	--USING @folios AS SOURCE ON TARGET.folio = SOURCE.folio
	--WHEN MATCHED THEN
	--	UPDATE SET TARGET.dias = DATEDIFF(DAY, TARGET.fechaInsercion, GETDATE() )
	--WHEN NOT MATCHED BY TARGET THEN
	--	INSERT ( folio, fechaInsercion, dias )
	--	VALUES ( SOURCE.folio, GETDATE(), 0 )
	--WHEN NOT MATCHED BY SOURCE THEN
	--	DELETE;

	--SELECT success = 1;
END

go

