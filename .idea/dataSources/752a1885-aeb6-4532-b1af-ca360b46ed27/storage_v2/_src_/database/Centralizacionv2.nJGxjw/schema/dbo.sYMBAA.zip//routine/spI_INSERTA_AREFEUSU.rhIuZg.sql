/*
DA DE ALTA LAS AREAS DE AFECTACION [Parametro AREFEUSU]  EN UNA BASE PARA UN USUARIO DETERMINADO
PARAMETROS

-- @sNomBase =  nombre de la base donde se insertará el parámetro AREFEUSU
-- @sAreas = lista, separada por comas, de las  Areas de afectacion a insertar para el usuario.
-- @sUsr3letras = Las 3 letras de BPRO del usuario.
*/

CREATE PROCEDURE [dbo].[spI_INSERTA_AREFEUSU] (@sNomBase varchar(20), @sAreas varchar(250), @sUsr3letras varchar(10)) --with recompile
 AS
declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@sIp nvarchar(20),
@iIdEmpresa int,
@iIdSucursal int,
@ipLocal VARCHAR(50),
@sAuxIP varchar(50),
@iPosicion int

begin 

set nocount on

Declare @idep_iddepartamento int;

Declare @sUsr3letrasAux varchar(7);
select @sUsr3letrasAux  = ''; 

--nos quedamos solo con el usuario de Bpro es decir solo las 3 letras de BPRO, puede o no venir con los dígitos de la sucursal
SELECT @sUsr3letrasAux = substring(@sUsr3letras,PATINDEX('%[^0-9]%',@sUsr3letras),len(@sUsr3letras)) --as usuario3Letras				

--select @sNomBase = ''
select @iIdEmpresa = 0; --emp_idempresa, @iIdSucursal =  suc_idsucursal from Centralizacionv2..DIG_CAT_BASES_BPRO where nombre_base = @sNomBase
if (CHARINDEX('[192.168.20.',@sNomBase COLLATE Latin1_General_BIN)>0)
begin 
		Select @sIP  = SUBSTRING(@sNomBase,1,CHARINDEX(']',@sNomBase))
		Select @sIP = Replace(@sIP,'[','');
		Select @sIP = Replace(@sIP,']','');
		select @sNomBase = SUBSTRING(@sNomBase,CHARINDEX(']',@sNomBase)+2,len(@sNomBase)) 
		Select @sNomBase = Replace(@sNomBase,'[','');
		Select @sNomBase = Replace(@sNomBase,']','');
		print '@sIP: ' +  @sIP
		print '@sNomBase: ' + @sNomBase
end
else
begin
	Select @sIP = ''
	print '@sIP: ' + @sIP
end

  
--validar si se corre en el servidor local
SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC

if (@ipLocal = @sIP or @sIP = '' )
begin   
	   select @sAuxIP = ''
end
else
begin	   
	   select @sAuxIP = '[' + @sIP + '].'
end
------------
--Partiendo las areas de afectacion para que quepan en las 3 variables de 100 caracteres cada variable, en promedio 4 caracteres por cada area.
DECLARE @AREAS_G2 VARCHAR(100) = '';
DECLARE @AREAS_G3 VARCHAR(100) = '';
DECLARE @AREAS_G4 VARCHAR(100) = '';
Declare @iContador int
Declare @iIndice int
Declare @iTope int
Declare @sAreasJoin varchar(1000) = '';
Declare @sAux varchar(20)
Create Table #AreasAuxiliar
(
		posicion_l [int] IDENTITY (1, 1),
		PAR_IDENPARA varchar(20)		
)
insert into #AreasAuxiliar
select * from dbo.Split(@sAreas,',',60) order by 1
select @iContador = 1
select @iIndice = 1
select @iTope = Max(posicion_l) from #AreasAuxiliar
--print 'Tope:' + Convert(char(10),@iTope)
 
while @iIndice <= @iTope   
begin    
    select @sAux = PAR_IDENPARA from #AreasAuxiliar where posicion_l = @iIndice;
    select @sAreasJoin = @sAreasJoin + char(39) + @sAux + char(39) + ',' 	
	--print 'AreasJoin' + @sAreasJoin

    if (@iContador=1)
	begin
	  select @AREAS_G2 = @AREAS_G2 + @sAux + ',' 
	end
	if (@iContador=2) 
	begin
	   select @AREAS_G3 = @AREAS_G3 + @sAux + ',' 
	end
	if (@iContador = 3)
	begin
	  select @AREAS_G4 = @AREAS_G4 + @sAux + ',' 
	end
	
   select @iIndice = @iIndice + 1
   if ((@iIndice % 14) = 0)
   Begin
	Select @iContador = @iContador + 1 
   end
end  -- de cada variable @AREAS_G2

--quitamos la última coma.
--print 'Antes:' +  @sAreasJoin
select @sAreasJoin = SUBSTRING(@sAreasJoin, 1, len(@sAreasJoin)-1) --LEFT(@sAreasJoin, CHARINDEX(',', REVERSE(@sAreasJoin)) - 1);
--print @sAreasJoin
if (len (@AREAS_G2)>0)
begin
  select @AREAS_G2 = SUBSTRING(@AREAS_G2, 1, len(@AREAS_G2)-1)  --LEFT(@AREAS_G2, CHARINDEX(',', REVERSE(@AREAS_G2)) - 1);
  --print @AREAS_G2
end
if (len(@AREAS_G3)>0)
begin
	select @AREAS_G3 = SUBSTRING(@AREAS_G3, 1, len(@AREAS_G3)-1)  --LEFT(@AREAS_G3, CHARINDEX(',', REVERSE(@AREAS_G3)) - 1);
	--print @AREAS_G3
end

if (len(@AREAS_G4)>0)
begin
	select @AREAS_G4 = SUBSTRING(@AREAS_G4, 1, len(@AREAS_G4)-1)  --LEFT(@AREAS_G4, CHARINDEX(',', REVERSE(@AREAS_G4)) - 1);
	--print @AREAS_G4
end 
------------
Create Table #AreasAfectacion
(
		id_local [int] IDENTITY (1, 1),
		PAR_IDENPARA varchar(20),
		PAR_DESCRIP1 VARCHAR(100)
)

set @sQ = N'Insert into #AreasAfectacion (PAR_IDENPARA,PAR_DESCRIP1) '
set @sQ = @sQ + N' SELECT PAR_IDENPARA,PAR_DESCRIP1 '
set @sQ = @sQ + N' from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR]  WHERE PAR_TIPOPARA = ' + char(39) + 'AREPED' + char(39) 
set @sQ = @sQ + N' and PAR_IDENPARA in (' + @sAreasJoin + ')'

print @sQ
execute sp_executesql @sQ
-------------
			
--SELECT PARAMETRO_US=PAR_IDENPARA + PAR_IDMODULO,PAR_IDENPARA,PAR_DESCRIP1 FROM GAAutoAngarTlahuac..PNC_PARAMETR WHERE PAR_TIPOPARA = 'AREPED' AND SUBSTRING(PAR_IDENPARA,1,1) = 'D' 

declare @sArea varchar(10);
select @iPosicion = 1;

--Inicia transaccion
			BEGIN TRANSACTION TRAN_REGISTRA
			BEGIN TRY

		while Exists(select 1 from #AreasAfectacion)
		begin
			select @sArea = PAR_IDENPARA from #AreasAfectacion where id_local = @iPosicion		
			
			if (@iPosicion = 1)
			begin
			    -- buscamos si tiene definido el parámetro AREAFEUSU este usuario
			    DEclare @sPAR_IDENPARA varchar(20) = '';
				set @sQ = N' SELECT @sPAR_IDENPARAOUT = PAR_IDENPARA '
				set @sQ = @sQ + N' from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR]  WHERE PAR_TIPOPARA = ' + char(39) + 'AREAFEUSU' + char(39) 
				set @sQ = @sQ + N' and PAR_IDENPARA = ' + char(39) + @sUsr3letrasAux + char(39) 				
				SET @sParmDefinition = N'@sPAR_IDENPARAOUT varchar(20) OUTPUT';								
				--print @sQ
				EXECUTE sp_executesql @sQ, @sParmDefinition, @sPAR_IDENPARAOUT=@sPAR_IDENPARA OUTPUT; 
				if (@sPAR_IDENPARA='')
				begin -- No lo tiene por lo que se lo ponemos.
				    print 'Insertando AREAFEUSU'
					set @sQ = N' INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] VALUES(' + char(39) + 'AREAFEUSU' + char(39) + ',' + char(39) + @sUsr3letrasAux + char(39) + ',''CON'',''AREAS ASIGNADAS AL USUARIO EN PEDIDOS VARIOS'',' + char(39) + @AREAS_G2 + char(39) + ','
					set @sQ = @sQ + N'' + char(39) + @AREAS_G3 + char(39) + ',' + char(39) + @AREAS_G4 + char(39) + ','''',''A'',0,0,0,0,0,'''','''','''','''','''','''',''GMI'',''24/10/2018'','''')';
					print @sQ
					EXECUTE sp_executesql @sQ
				end
				else
				  begin
				     print 'Ya existe  AREAFEUSU se actualiza con: ' + @sAreasJoin;
					set @sQ = N' Update ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] set PAR_DESCRIP2 = ' + char(39) + @AREAS_G2 + char(39) + ', PAR_DESCRIP3=' + char(39) + @AREAS_G3 + char(39) + ', PAR_DESCRIP4=' + char(39) + @AREAS_G4 + char(39) 
					set @sQ = @sQ + N' where PAR_TIPOPARA=''AREAFEUSU'' and PAR_IDENPARA = ' + char(39) + @sUsr3letrasAux + char(39) + ' and PAR_IDMODULO=''CON'''
					print @sQ
					EXECUTE sp_executesql @sQ					 										  
				  end
			end -- De solo en la primer área. buscando si tiene definido el parámetro AREAFEUSU
			
				Declare @sPAR_IDENPARAAUX varchar(20) = '';
				set @sQ = N' SELECT @sPAR_IDENPARAOUT = PAR_IDENPARA '
				set @sQ = @sQ + N' from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR]  WHERE PAR_TIPOPARA = ' + char(39) + @sArea + 'CON' + char(39) 
				set @sQ = @sQ + N' and PAR_IDENPARA = ' + char(39) + @sUsr3letrasAux + char(39) 				
				SET @sParmDefinition = N'@sPAR_IDENPARAOUT varchar(20) OUTPUT';								
				--print @sQ
				EXECUTE sp_executesql @sQ, @sParmDefinition, @sPAR_IDENPARAOUT=@sPAR_IDENPARAAUX OUTPUT; 

				if (@sPAR_IDENPARAAUX='')
				begin
					print 'Se inserta: ' + char(39) + @sArea + 'CON' + char(39)  + ',' + char(39) + @sUsr3letrasAux + char(39)
					set @sQ = N' INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] VALUES(';
					set @sQ = @sQ + N'' + char(39) + @sArea + 'CON' + char(39)  + ',' + char(39) + @sUsr3letrasAux + char(39) + ',''CON'',''CAPACITACION ANDRADE'','''','''','''','''',''A'',0,0,0,0,0,'''','''','''','''','''','''',''GMI'',CONVERT (VARCHAR(10),GETDATE(),103),'''')';
					--print @sQ
					EXECUTE sp_executesql @sQ
			    end
				else
				  begin
				     print 'Ya existe: '  + char(39) + @sArea + 'CON' + char(39)  + ',' + char(39) + @sUsr3letrasAux + char(39)
				  end

				Declare @sPAR_IDENPARAAUX1 varchar(20) = '';
				set @sQ = N' SELECT @sPAR_IDENPARAOUT = PAR_IDENPARA '
				set @sQ = @sQ + N' from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR]  WHERE PAR_TIPOPARA = ' + char(39) + @sArea + 'CONAUT' + char(39) 
				set @sQ = @sQ + N' and PAR_IDENPARA = ' + char(39) + @sUsr3letrasAux + char(39) 				
				SET @sParmDefinition = N'@sPAR_IDENPARAOUT varchar(20) OUTPUT';								
				--print @sQ
				EXECUTE sp_executesql @sQ, @sParmDefinition, @sPAR_IDENPARAOUT=@sPAR_IDENPARAAUX1 OUTPUT; 

				if (@sPAR_IDENPARAAUX1='')
				begin					
				    print 'Se inserta: ' + char(39) + @sArea + 'CONAUT' + char(39)  + ',' + char(39) + @sUsr3letrasAux + char(39)
					set @sQ = N' INSERT INTO ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_PARAMETR] VALUES('
					set @sQ = @sQ + N'' + char(39) + @sArea + 'CONAUT' + char(39)  + ',' + char(39) + @sUsr3letrasAux + char(39) + ',''CON'',''CAPACITACION ANDRADE'','''','''','''','''',''A'',0,0,0,0,0,'''','''','''','''','''','''',''GMI'',CONVERT (VARCHAR(10),GETDATE(),103),'''')';
					--print @sQ
					EXECUTE sp_executesql @sQ								
				end
				else
				  begin
				     print 'Ya existe: '  + char(39) + @sArea + 'CONAUT' + char(39)  + ',' + char(39) + @sUsr3letrasAux + char(39)
				  end

			Delete #AreasAfectacion where id_local = @iPosicion
			select @iPosicion = @iPosicion + 1
		end  -- Del mientras existan areas afectacion

										--damos commit a la transaccion
								COMMIT TRANSACTION TRAN_REGISTRA
								END TRY
								BEGIN CATCH				
									--rollback a la transaccion
									ROLLBACK TRANSACTION TRAN_REGISTRA		
									DECLARE @Mensaje  nvarchar(max)		
									SELECT @Mensaje = ERROR_MESSAGE() + ' Error al declarar las áreas de afectacion del usuario' +  @sUsr3letrasAux		
									SELECT  ERROR_NUMBER() 
									print @Mensaje
								END CATCH

set nocount off
end



/*
Declare @sAreas varchar(300) = 'AAB,AFA,AFL5,AFL6,AFL7,AFL8,AFL9,AZA,CZA,CZAP,CZAV,F1AB,F1FA,F1ZA,F2AB,F2FA,F2ZA,F3AB,F3FA,F3ZA,F4AB,F4FA,F4ZA,F5FA,F5ZA,F6FA,F6ZA,F7FA,F7ZA,F8FA,F8ZA,F9FA,F9ZA,HAB,HFA,HZA,ICAB,ICFA,ICZA,MAB,MFA,MZA,NGAB,NGFA,NGZA,RAB,RFA,RZA,SAB,SFA,SZA,UAB,UFA,UZA';
								AAB,AFA,AFL5,AFL6,AFL7,AFL8,AFL9,AZA,CZA,CZAP,CZAV,F1AB,F1FA,F1ZA,F2AB,F2FA,F2ZA,F3AB,F3FA,F3ZA,
Declare @sUsr3letras varchar(10) = 'GGJ';

Execute [dbo].[spI_INSERTA_AREFEUSU] 'GAZM_Zaragoza', @sAreas, @sUsr3letras --with recompile

select * from GAZM_Zaragoza..PNC_PARAMETR where PAR_TIPOPARA='AREPED'

select * from GAZM_Zaragoza..PNC_PARAMETR where PAR_TIPOPARA='AREAFEUSU' and PAR_IDENPARA='GGJ'

select PAR_DESCRIP2 + ',' + PAR_DESCRIP3 + ',' + PAR_DESCRIP4 from GAZM_Zaragoza..PNC_PARAMETR where PAR_TIPOPARA='AREAFEUSU' and PAR_IDENPARA='GGJ'
--delete GAZM_Zaragoza..PNC_PARAMETR where PAR_TIPOPARA='AREAFEUSU' and PAR_IDENPARA='GGJ'
select * from GAZM_Zaragoza..PNC_PARAMETR where  PAR_IDENPARA='GGJ' and PAR_DESCRIP1='CAPACITACION ANDRADE'
--delete GAAutoAngarTlahuac..PNC_PARAMETR where  PAR_IDENPARA='LBA'

SELECT  *  from [GAAutoAngarTlahuac].[dbo].[PNC_PARAMETR]  WHERE PAR_TIPOPARA = 'AREAFEUSU' and PAR_IDENPARA = 'LBA'

select len('AAB,AFA,AFL5,AFL6,AFL7,AFL8,AFL9,AZA,CZA,CZAP,CZAV,F1AB,F1FA,F1ZA,F2AB,F2FA,F2ZA,F3AB,F3FA,F3ZA,F4AB,F4FA,F4ZA,F5FA,F5ZA,F6FA,F6ZA,F7FA,F7ZA,F8FA,F8ZA,F9FA,F9ZA,HAB,HFA,HZA,ICAB,ICFA,ICZA,MAB,MFA,MZA,NGAB,NGFA,NGZA,RAB,RFA,RZA,SAB,SFA,SZA,UAB,UFA,UZA')

SELECT PAR_IDENPARA,PAR_DESCRIP1 FROM  from [GAAutoAngarTlahuac].[dbo].[PNC_PARAMETR]  WHERE PAR_TIPOPARA = 'AREPED' and PAR_IDENPARA in ('DADM','DAUT','DCTR','DFL1','DFL2','DFL3','DFL4','DFL5','DFL6','DFL7','DFL8','DFL9','DHYP','DINT','DNEG','DNUE','DPV','DREF','DSEM','DSER')

DECLARE @test NVARCHAR(255)
SET @test = 'DADM,DAUT,DCTR,DFL1,DFL2,DFL3,DFL4,DFL5,DFL6,DFL7,DFL8,DFL9,DHYP,DINT,DNEG,DNUE,DPV,DREF,DSEM,DSER,' --'Esto es una frase'
Select SUBSTRING(@test, 1, len(@test)-1)

DECLARE @test NVARCHAR(255)
SET @test = 'Esto es una frase'



Declare @sNomBase varchar(100)='[192.168.20.31].[GAZM_Zaragoza]'; 
Declare @sAreas varchar(250)='';
Declare @sUsr3letras varchar(10)='';

declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@sIp nvarchar(20),
@iIdEmpresa int,
@iIdSucursal int,
@ipLocal VARCHAR(50),
@sAuxIP varchar(50),
@iPosicion int

Declare @idep_iddepartamento int;

Declare @sUsr3letrasAux varchar(7);
select @sUsr3letrasAux  = 'PBO'; 

--nos quedamos solo con el usuario de Bpro es decir solo las 3 letras de BPRO, puede o no venir con los dígitos de la sucursal
SELECT @sUsr3letrasAux = substring(@sUsr3letras,PATINDEX('%[^0-9]%',@sUsr3letras),len(@sUsr3letras)) --as usuario3Letras				


select @iIdEmpresa = 0; --emp_idempresa, @iIdSucursal =  suc_idsucursal from Centralizacionv2..DIG_CAT_BASES_BPRO where nombre_base = @sNomBase
print @sNomBase

print '2 - ' + Convert(char(10),CHARINDEX('[192.168.20.',@sNomBase COLLATE Latin1_General_BIN) )
if (CHARINDEX('[192.168.20.',@sNomBase COLLATE Latin1_General_BIN)>0)
begin 
		Select @sIP  = SUBSTRING(@sNomBase,1,CHARINDEX(']',@sNomBase))
		Select @sIP = Replace(@sIP,'[','');
		Select @sIP = Replace(@sIP,']','');
		select @sNomBase = SUBSTRING(@sNomBase,CHARINDEX(']',@sNomBase)+2,len(@sNomBase)) 
		Select @sNomBase = Replace(@sNomBase,'[','');
		Select @sNomBase = Replace(@sNomBase,']','');
		print '@sIP: ' +  @sIP
		print '@sNomBase: ' + @sNomBase
end
else
begin
	Select @sIP = ''
	print '@sIP: ' + @sIP
end



*/
go

