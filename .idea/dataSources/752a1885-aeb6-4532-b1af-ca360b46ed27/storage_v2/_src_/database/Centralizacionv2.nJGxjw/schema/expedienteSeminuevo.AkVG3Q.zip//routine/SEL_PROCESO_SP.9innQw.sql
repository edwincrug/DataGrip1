-- =============================================
-- Author:		Luis Garcia
-- Create date: 13/08/2020
-- Description:	Recupero los procesos a los que tiene permiso el usuario
-- =============================================
-- EXECUTE [SEL_PROCESO_SP] 1, 2
CREATE PROCEDURE [expedienteSeminuevo].[SEL_PROCESO_SP]
	@CXP INT,
	@CXC INT
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
          SELECT [Proc_Id]          AS Proc_Id
			    ,[Proc_Nombre]      AS Proc_Nombre
			    ,[Proc_Descripcion] AS Proc_Descripcion
			    ,[Proc_Orden]       AS Proc_Orden
		    FROM [dbo].[DIG_PROCESO] WHERE Proc_id IN (@CXP, @CXC)
	END TRY

BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_PROCESO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

