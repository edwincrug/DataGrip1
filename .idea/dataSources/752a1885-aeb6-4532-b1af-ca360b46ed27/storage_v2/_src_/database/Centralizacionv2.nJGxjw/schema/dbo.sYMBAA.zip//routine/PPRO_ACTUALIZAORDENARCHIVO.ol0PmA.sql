CREATE PROCEDURE [dbo].[PPRO_ACTUALIZAORDENARCHIVO]
@idUser INT = 0,
@orden VARCHAR(30) = '',
@nombreArchivo VARCHAR(50) = '',
@factura VARCHAR(30) = '',
@uuid VARCHAR(50) = '',
@serie VARCHAR(5) = '',
@fecha_factura DATETIME = NULL,
@rfc_emisor VARCHAR(15) = '',
@rfc_receptor VARCHAR(15) = '',
@importe_total MONEY = NULL
AS

BEGIN TRY  
	BEGIN TRAN

			UPDATE cuentasxpagar.dbo.cxp_ordencompra
			SET oce_uuid = @uuid,
				oce_factura = @factura+@serie
			WHERE oce_folioorden = @orden

			INSERT INTO dbo.PPRO_ORDENARCHIVOXML(oce_folioorden,ppro_nombrearchivo,factura,uuid,fechaValidacion,fecha_pago,
												 serie,fecha_factura,rfc_emisor,rfc_receptor,importe_total)
										  VALUES(@orden,@nombreArchivo,@factura,@uuid,GETDATE(),DATEADD(day,30,GETDATE()),
												 @serie,@fecha_factura,@rfc_emisor,@rfc_receptor,@importe_total)
	COMMIT TRAN;  
END TRY  
BEGIN CATCH  

		 PRINT ('Error: ' + ERROR_MESSAGE())  
		 DECLARE @Mensaje  nvarchar(max),  
		 @Componente nvarchar(50) = 'PPRO_ACTUALIZAORDENARCHIVO'  
		 SELECT @Mensaje = ERROR_MESSAGE()  
		 RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje;   
	ROLLBACK TRAN;   
		 
END CATCH

go

