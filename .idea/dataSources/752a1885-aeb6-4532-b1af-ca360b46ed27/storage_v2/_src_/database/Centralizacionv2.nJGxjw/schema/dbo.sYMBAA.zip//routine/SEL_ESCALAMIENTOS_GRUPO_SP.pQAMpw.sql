--EXECUTE [dbo].[SEL_ESCALAMIENTOS_GRUPO_SP] 1,2,1,3,13,1
-- ==========================================================================================
-- Author: Lourdes Maldonado Sánchez
-- Create date: 19/01/2016
-- Description:	Procedimiento para ver escalamientos una de empresa,sucursal,depto y autorizadores.
-- ==========================================================================================
CREATE PROCEDURE [dbo].[SEL_ESCALAMIENTOS_GRUPO_SP] 
	@procId INT = NULL,              --1
	@usuario_idusuario INT = null,   --2
	@emp_idempresa INT = null,       --1
	@suc_idsucursal INT = null,      --3
	@dep_iddepartamento INT = null,  --13
	@tipo_idtipoorden INT = null     --1
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
	 
     select  DISTINCT   DE.Nodo_Id             AS nodoId
	                   ,DE.emp_idempresa       AS empIdempresa
					   ,E.emp_nombre           AS empNombre
					   ,DE.suc_idsucursal      AS sucIdsucursal
					   ,S.suc_nombre           AS sucNombre
					   ,DE.dep_iddepartaamento AS depIddepartamento
					   ,D.dep_nombre           AS depNombre
					   ,DE.tipo_idtipoorden    AS tipoidtipoorden 
					   ,DE.Nivel_Escalamiento  AS nivelEscalamiento
					   ,DE.Usuario_Autoriza1   AS idusuarioAutoriza1
					   ,U1.usu_nombreusu +  '/' + U1.usu_paterno + '/' + U1.usu_materno AS nomusuarioAutoriza1
					   ,DE.Usuario_Autoriza2   AS idusuarioAutoriza2
					   ,U2.usu_nombreusu +  '/' + U2.usu_paterno + '/' + U2.usu_materno AS nomusuarioAutoriza2
					   ,DE.Usuario_Autoriza3   AS idusuarioAutoriza3
					   ,U3.usu_nombreusu +  '/' + U3.usu_paterno + '/' + U3.usu_materno AS nomusuarioAutoriza3
					   ,DE.Minutos_Escalar     AS minutosEscala
				   FROM  [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO] DE
						,[ControlAplicaciones].[dbo].[cat_empresas]   E
						,[ControlAplicaciones].[dbo].[cat_sucursales] S
						,[ControlAplicaciones].[dbo].[cat_departamentos] D
						,[ControlAplicaciones].[dbo].[cat_usuarios] U1
						,[ControlAplicaciones].[dbo].[cat_usuarios] U2
						,[ControlAplicaciones].[dbo].[cat_usuarios] U3  
				  WHERE	 E.emp_idempresa  = S.emp_idempresa  
					AND  S.emp_idempresa  = D.emp_idempresa
					AND  S.suc_idsucursal = D.suc_idsucursal
					--
					AND  E.emp_idempresa        = @emp_idempresa      --1
					AND  S.suc_idsucursal       = @suc_idsucursal     --3
					AND  D.dep_iddepartamento   = @dep_iddepartamento --13
					--
					AND  DE.emp_idempresa       = D.emp_idempresa
					AND  DE.suc_idsucursal      = S.suc_idsucursal 
					AND  DE.dep_iddepartaamento = D.dep_iddepartamento
					--
					AND  U1.usu_idusuario = DE.Usuario_Autoriza1
					AND  U2.usu_idusuario = DE.Usuario_Autoriza2
					AND  U3.usu_idusuario = DE.Usuario_Autoriza3

	END TRY
	BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_ESCALAMIENTOS_GRUPO_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	END CATCH
END

go

