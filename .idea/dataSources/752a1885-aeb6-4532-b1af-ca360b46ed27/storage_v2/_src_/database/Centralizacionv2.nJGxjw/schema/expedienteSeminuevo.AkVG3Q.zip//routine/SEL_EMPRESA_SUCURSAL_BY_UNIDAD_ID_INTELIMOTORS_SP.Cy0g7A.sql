-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description
-- TEST [expedienteSeminuevo].[SEL_EMPRESA_SUCURSAL_BY_UNIDAD_ID_INTELIMOTORS_SP] '5d768f916ebc5a009de22c3f'
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_EMPRESA_SUCURSAL_BY_UNIDAD_ID_INTELIMOTORS_SP]
	@unidadId VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;

	SELECT 
		idEmpresa,
		idSucursal
	FROM [intelimotors].[dbo].[SucursalIntelimotors] WHERE code = @unidadId
END

go

