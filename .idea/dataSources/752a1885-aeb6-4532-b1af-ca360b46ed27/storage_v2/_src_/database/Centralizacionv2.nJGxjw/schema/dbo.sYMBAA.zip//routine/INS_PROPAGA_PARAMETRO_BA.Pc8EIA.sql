
CREATE PROCEDURE [dbo].[INS_PROPAGA_PARAMETRO_BA] (@sNOMBREBANCO varchar(100),@sPAR_DESCRIP5 varchar(3)) --with recompile
 As

BEGIN
SET NOCOUNT ON;

DECLARE  @sQ nvarchar(1500); 
Declare  @sParmDefinition nvarchar(500);
DECLARE  @ipServidor    VARCHAR(100);
DECLARE  @ipLocal VARCHAR(50);
DECLARE  @emp_idempresa int;
DECLARE  @suc_idsucursal int;
DEclare  @sNombre_base varchar(100);
DECLARE  @aux INT = 1, @max INT = 0;
DECLARE  @TBases TABLE(id INT IDENTITY(1,1), ip_servidor VARCHAR(100), nombre_base varchar(100), emp_idempresa int, suc_idsucursal int, tipo int)

	insert into @TBases
	select ip_servidor,nombre_base,emp_idempresa, suc_idsucursal, tipo  from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] where tipo in (1,2) order by tipo
	

SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC


 SELECT @max = MAX(id) FROM @TBases 
 

 --Inicia transaccion
		BEGIN TRANSACTION TRAN_PROPAGA
			BEGIN TRY
				--recorremos todas las bases de datos.
				WHILE(@aux <= @max)
				BEGIN												
							select @sNombre_base = nombre_base, @ipServidor = ip_servidor from @TBases where id = @aux																					

							if (@ipLocal = @ipServidor)
							begin
								select @ipServidor = ''
							end
							else
							begin
								select @ipServidor = '[' + @ipServidor + '].'
							end
							
							--buscamos en la Tabla de parámetros de la base si ya se encuentra el valor.							
							--select  PAR_TIPOPARA,PAR_IDENPARA,PAR_DESCRIP1,PAR_DESCRIP5,PAR_STATUS, * from [192.168.20.31].[GAZM_Zaragoza].[dbo].PNC_PARAMETR where PAR_TIPOPARA='BA' order by Convert(int, PAR_IDENPARA)							
							--select  PAR_TIPOPARA,PAR_IDENPARA,PAR_DESCRIP1,PAR_DESCRIP5,PAR_STATUS, * from [GAZM_Zaragoza].[dbo].PNC_PARAMETR where PAR_TIPOPARA='BA' order by Convert(int, PAR_IDENPARA)							
							        declare @sPAR_DESCRIP1 varchar(150) = '';
									set @sQ = N' select @sPAR_DESCRIP1OUT = PAR_DESCRIP1  from ' + @ipServidor + '[' + @sNombre_base + '].[dbo].[PNC_PARAMETR] where PAR_TIPOPARA = ' + char(39) + 'BA' + char(39) + ' and PAR_DESCRIP5=' + char(39) +  ltrim(rtrim(@sPAR_DESCRIP5))  +  char(39) + ''
									SET @sParmDefinition = N'@sPAR_DESCRIP1OUT varchar(150) OUTPUT';
									--print @sQ
									EXECUTE sp_executesql @sQ, @sParmDefinition, @sPAR_DESCRIP1OUT= @sPAR_DESCRIP1 OUTPUT; 

									if (ltrim(rtrim(@sPAR_DESCRIP1))<>'')
									begin
									   print 'El parámetro BA para el banco: ' + @sPAR_DESCRIP1 + ' PAR_DESCRIP5: ' + @sPAR_DESCRIP5 + ' ya se encuentra declarado en la base: ' + @ipServidor + '[' + @sNombre_base + '].[dbo].[PNC_PARAMETR] ';
									end
									else
									begin
										   print 'No se ecuentra el parametro BA y PAR_DESCRIP5: ' + @sPAR_DESCRIP5 + ' se registrará en: ' +  @ipServidor + '[' + @sNombre_base + '].[dbo].[PNC_PARAMETR]'
											declare @iSiguiente int = 0;
											set @sQ = N'select @sPAR_IDENPARAOUT =  Isnull(Max(PAR_IDENPARA),0) + 1  from ' + @ipServidor + '[' + @sNombre_base + '].[dbo].[PNC_PARAMETR] where PAR_TIPOPARA = ' + char(39) + 'BA' + char(39) 
											SET @sParmDefinition = N'@sPAR_IDENPARAOUT int OUTPUT';
											--print @sQ
											EXECUTE sp_executesql @sQ, @sParmDefinition, @sPAR_IDENPARAOUT= @iSiguiente OUTPUT; 									        
											DEclare @sSiguiente varchar(2) = '00';											
											select @sSiguiente = SUBSTRING(@sSiguiente,1,2-len(Convert(char(2),@iSiguiente))) + Convert(char(2),@iSiguiente)
																										
												--Select * from GAZM_Zaragoza..PNC_PARAMETR where PAR_TIPOPARA = 'BA' 
												set @sQ = N'	INSERT INTO ' + @ipServidor + '[' + @sNombre_base + '].[dbo].[PNC_PARAMETR]'
												set @sQ = @sQ + N'	([PAR_TIPOPARA],[PAR_IDENPARA],[PAR_IDMODULO],[PAR_DESCRIP1],[PAR_DESCRIP2],[PAR_DESCRIP3],[PAR_DESCRIP4],[PAR_DESCRIP5]'
												set @sQ = @sQ + N'	,[PAR_STATUS],[PAR_IMPORTE1],[PAR_IMPORTE2],[PAR_IMPORTE3],[PAR_IMPORTE4],[PAR_IMPORTE5],[PAR_FECHA1],[PAR_FECHA2],[PAR_FECHA3]'
												set @sQ = @sQ + N'	,[PAR_HORA1],[PAR_HORA2],[PAR_HORA3],[PAR_CVEUSU],[PAR_FECHOPE],[PAR_HORAOPE])'
												set @sQ = @sQ + N'	     VALUES ('
												set @sQ = @sQ + N'' + char(39) + 'BA' + char(39) + ',' --(<PAR_TIPOPARA, varchar(10),>
												set @sQ = @sQ + N'' + char(39) + @sSiguiente + char(39) + ',' --,<PAR_IDENPARA, varchar(20),>
												set @sQ = @sQ + N'' + char(39) + 'CXC' + char(39) + ',' --,<PAR_IDMODULO, varchar(3),>
												set @sQ = @sQ + N' ' + char(39) + ltrim(rtrim(@sNOMBREBANCO))  + char(39) + ',' --,<PAR_DESCRIP1, varchar(100),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_DESCRIP2, varchar(100),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_DESCRIP3, varchar(100),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_DESCRIP4, varchar(100),>
												set @sQ = @sQ + N'' + char(39) + ltrim(rtrim(@sPAR_DESCRIP5)) + char(39) + ',' --,<PAR_DESCRIP5, varchar(100),>
												set @sQ = @sQ + N'' + char(39) + 'A' + char(39) + ',' --,<PAR_STATUS, varchar(60),>
												set @sQ = @sQ + N'0,' --,<PAR_IMPORTE1, decimal(18,5),>
												set @sQ = @sQ + N'0,' --,<PAR_IMPORTE2, decimal(18,5),>
												set @sQ = @sQ + N'0,' --,<PAR_IMPORTE3, decimal(18,5),>
												set @sQ = @sQ + N'0,' --,<PAR_IMPORTE4, decimal(18,5),>
												set @sQ = @sQ + N'0,' --,<PAR_IMPORTE5, decimal(18,5),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_FECHA1, char(10),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_FECHA2, char(10),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_FECHA3, char(10),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_HORA1, char(5),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_HORA2, char(5),>
												set @sQ = @sQ + N'' + char(39) + '' + char(39) + ',' --,<PAR_HORA3, char(5),>
												set @sQ = @sQ + N'' + char(39) + 'STOR' + char(39) + ',' --,<PAR_CVEUSU, varchar(10),>
												set @sQ = @sQ + N'' + char(39) +  Convert(char(10),getdate(),103) + char(39) + ',' --,<PAR_FECHOPE, varchar(10),>
												set @sQ = @sQ + N'NULL)' --,<PAR_HORAOPE, varchar(5),>)
												--print @sQ
												EXECUTE sp_executesql @sQ
												print 'Se insertó en el parametro BA: ' + @sPAR_DESCRIP5 + ' ' + @sNOMBREBANCO + ' en ' +  @ipServidor + '[' + @sNombre_base + '].[dbo].[PNC_PARAMETR]'
											end --De que no existe y se inserta el parámetro.

							SET @aux = @aux + 1
				END -- del while que cicla sobre los registros de la tabla.

				--Finalmente lo buscamos en PAGOS.
				if not Exists (Select 1 from [Pagos].[dbo].[PAG_CAT_BANXICO] where pbx_numoficial = @sPAR_DESCRIP5)
				begin
				  print 'No existe en [Pagos].[dbo].[PAG_CAT_BANXICO] se registra ';  
				  insert into [Pagos].[dbo].[PAG_CAT_BANXICO] (pbx_numoficial,pbx_descripcion,pbx_par_idenpara)
				  values (ltrim(rtrim(@sPAR_DESCRIP5)),Upper(ltrim(rtrim(@sNOMBREBANCO))),'00')
				  print 'Registro correcto en [Pagos].[dbo].[PAG_CAT_BANXICO] ';
				end
				--damos commit a la transaccion
				COMMIT TRANSACTION TRAN_PROPAGA
	END TRY
	BEGIN CATCH				
		--rollback a la transaccion
		ROLLBACK TRANSACTION TRAN_PROPAGA		
		DECLARE @Mensaje  nvarchar(max)		
		SELECT @Mensaje = ERROR_MESSAGE() + ' Error al declarar el parámetro BA no se insertó en ningún lado ' 		
		SELECT  ERROR_NUMBER() 
		print @Mensaje
	END CATCH

set nocount off
END

/*
NOTA: Es de suma importancia el identificador del Banco [el valor númerico]
tomar en cuenta que es diferente '002' que '2'

Execute [Centralizacionv2].[dbo].[INS_PROPAGA_PARAMETRO_BA]  'PATITO SA de C.V.', '055' 

select * from [GAAT_Concentra].[dbo].[PNC_PARAMETR] where PAR_TIPOPARA='BA'
SELECT * FROM [Pagos].[dbo].[PAG_CAT_BANXICO]

*/
go

