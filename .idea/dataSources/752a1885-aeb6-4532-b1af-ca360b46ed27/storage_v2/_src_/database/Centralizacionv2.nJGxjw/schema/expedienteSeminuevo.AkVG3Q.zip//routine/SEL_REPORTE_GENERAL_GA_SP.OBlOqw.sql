-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [expedienteSeminuevo].[SEL_REPORTE_GENERAL_GA_SP] '01/08/2020', '31/08/2020'
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_REPORTE_GENERAL_GA_SP] 
	 @F1 VARCHAR(10),
	 @F2 VARCHAR(10)
AS
BEGIN
		BEGIN TRY

		DECLARE @count INT = 0,@aux INT = 1,@cxp_query NVARCHAR(MAX),@cxc_query NVARCHAR(MAX), @base VARCHAR(300),@idEmpresa INT, @idSucursal INT,@exp_vin VARCHAR(100),
				@cxp_totalMOR INT,@cxp_totalFis INT,@cxp_totalFIE INT,
				@cxc_totalMOR INT,@cxc_totalFis INT,@cxc_totalFIE INT;

		DECLARE @basesSucursal TABLE (id INT IDENTITY(1,1), base NVARCHAR(300), idEmpresa INT, idSucursal INT);
		DECLARE @vinesIncompletos TABLE (id INT IDENTITY(1,1),idExpediente INT, vin NVARCHAR(300), idEmpresa INT, idSucursal INT,
										 cxp_totalDocs INT,cxp_docsFaltantes INT,cxp_docsQuetiene INT,
										 cxc_totalDocs INT,cxc_docsFaltantes INT,cxc_docsQuetiene INT,
										 tipoPersona NVARCHAR(10));

			INSERT INTO @basesSucursal
			SELECT DISTINCT a.nombre_base,a.emp_idempresa,a.suc_idsucursal
			FROM [DBO].[DIG_CAT_BASES_BPRO]  a
			--INNER JOIN [ControlAplicaciones].[dbo].[OPE_ORGANIGRAMA]  b on a.suc_idsucursal = b.suc_idsucursal
			WHERE  a.tipo = 1
			--AND b.usu_idusuario = @idempleado
			--AND b.div_iddivision = @iddivision			
			ORDER BY a.emp_idempresa,a.nombre_base,a.suc_idsucursal DESC

			SET @cxp_totalMOR = (SELECT COUNT(id_documento) FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_moral = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0)
			SET @cxp_totalFis = (SELECT COUNT(id_documento) FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisica = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0)
			SET @cxp_totalFIE = (SELECT COUNT(id_documento) FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisicaAE = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0)
			SET @cxc_totalMOR = (SELECT COUNT(id_documento) FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_moral = 1 AND doc_activo = 1 AND doc_proceso = 2 AND doc_opcional = 0)
			SET @cxc_totalFis = (SELECT COUNT(id_documento) FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisica = 1 AND doc_activo = 1 AND doc_proceso = 2 AND doc_opcional = 0)
			SET @cxc_totalFIE = (SELECT COUNT(id_documento) FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisicaAE = 1 AND doc_activo = 1 AND doc_proceso = 2 AND doc_opcional = 0)

		
			SET @count = (SELECT COUNT(id) FROM @basesSucursal)
		
			WHILE (@aux <= @count)
			BEGIN

				DECLARE @countVines INT = 0,@auxVines INT = 1
				DECLARE @vines TABLE (id INT IDENTITY(1,1),idExpediente INT, exp_vin  NVARCHAR(300))

				SELECT @base = base, @idEmpresa = idEmpresa, @idSucursal = idSucursal
				FROM @basesSucursal 
				WHERE id = @aux		
								
				INSERT INTO @vines
				SELECT id_expediente,exp_vin
				FROM [expedienteSeminuevo].[expedientes] 
				WHERE exp_empresa  = @idEmpresa
				AND exp_sucursal = @idSUcursal
				AND CONVERT(DATE,exp_fechaCreacion, 103) BETWEEN CONVERT(DATE,@F1,103) AND CONVERT(DATE,@F2,103)
				
					SET @countVines = (SELECT COUNT(*) FROM @vines)
					
					IF (@countVines > 0)
					BEGIN
										
							WHILE (@auxVines <= @countVines)
							BEGIN
						
								DECLARE @idExpediente INT,@vin NVARCHAR(300) = '',
								@cxp_idCliente INT = 0, @cxp_fisMor VARCHAR(10) = '',
								@cxc_idCliente INT = 0, @cxc_fisMor VARCHAR(10) = '',
								@cxp_debeTenerDocs INT = 0,@cxp_soloTieneDocs INT = 0,
								@cxc_debeTenerDocs INT = 0,@cxc_soloTieneDocs INT = 0,
								@cxp_docsFaltantes INT = 0,@cxc_docsFaltantes INT = 0
						
								SELECT @idExpediente = idExpediente, @vin = exp_vin
								FROM @vines WHERE id = @auxVines			

								SET @cxp_query = 'SELECT 
													@cxp_clienteId = OC.oce_idproveedor 
												FROM ' + @base + '.DBO.SER_VEHICULO SV
												INNER JOIN cuentasxpagar.[dbo].[cxp_detalleseminuevos] DS ON DS.asn_numeroserie =  SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
												INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] OC ON OC.oce_folioOrden = DS.oce_folioorden
												WHERE OC.sod_idsituacionorden <> 4 AND VEH_NUMSERIE = ''' + @vin + ''''
								EXEC sp_executesql @cxp_query, N'@cxp_clienteId INT OUTPUT', @cxp_clienteId = @cxp_idCliente OUTPUT

								SET @cxc_query = 'SELECT 
													@cxc_clienteId = ucu_idcliente 
												FROM ' + @base + '.DBO.SER_VEHICULO SV
												INNER JOIN cuentasporcobrar.[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucn_noserie = SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
												INNER JOIN cuentasporcobrar.[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_idCotizacion = CD.ucu_idCotizacion
												WHERE VEH_NUMSERIE = ''' + @vin + ''' AND VEH_SITUACION LIKE ''%SVEN%'' AND cec_idestatuscotiza <> 14 AND ucu_tipocotizacion = ''SN'' '
								EXEC sp_executesql @cxc_query, N'@cxc_clienteId INT OUTPUT', @cxc_clienteId = @cxc_idCliente OUTPUT

								SELECT @cxp_fisMor = PER_TIPO FROM [GA_Corporativa].[DBO].[PER_PERSONAS] WHERE PER_IDPERSONA = @cxp_idCliente
								SELECT @cxc_fisMor = PER_TIPO FROM [GA_Corporativa].[DBO].[PER_PERSONAS] WHERE PER_IDPERSONA = @cxc_idCliente
															
								--------------------------------
								------------ INICIO ------------
														
									IF (@cxp_fisMor = 'MOR')
									BEGIN
										SET @cxp_debeTenerDocs = @cxp_totalMOR										
									END
									ELSE IF(@cxp_fisMor = 'FIS')
									BEGIN
										SET @cxp_debeTenerDocs = @cxp_totalFis
									END
									ELSE IF(@cxp_fisMor = 'FIE')
									BEGIN
										SET @cxp_debeTenerDocs = @cxp_totalFIE
									END

									SELECT @cxp_soloTieneDocs = COUNT(*)
									FROM [expedienteSeminuevo].[documentosExpediente] e
									INNER JOIN [expedienteSeminuevo].[cat_documentos] d on e.id_documento = d.id_documento
									WHERE e.id_expediente = @idExpediente
									AND d.doc_proceso = 1
									AND d.doc_opcional = 0

									SET @cxp_docsFaltantes = @cxp_debeTenerDocs - @cxp_soloTieneDocs
									
									IF(@cxc_idCliente > 0)
									BEGIN

											IF (@cxc_fisMor = 'MOR')
											BEGIN
												SET @cxc_debeTenerDocs = @cxc_totalMOR
											END
											ELSE IF(@cxc_fisMor = 'FIS')
											BEGIN
												SET @cxc_debeTenerDocs = @cxc_totalFis
											END
											ELSE IF(@cxc_fisMor = 'FIE')
											BEGIN
												SET @cxc_debeTenerDocs = @cxc_totalFIE
											END

											SELECT @cxc_soloTieneDocs = COUNT(*)
											FROM [expedienteSeminuevo].[documentosExpediente] e
											INNER JOIN [expedienteSeminuevo].[cat_documentos] d on e.id_documento = d.id_documento
											WHERE e.id_expediente = @idExpediente
											AND d.doc_proceso = 2
											AND d.doc_opcional = 0

											SET @cxc_docsFaltantes = @cxc_debeTenerDocs - @cxc_soloTieneDocs

									END
									ELSE
									BEGIN						
										SET @cxc_docsFaltantes = -1
									END								
																																								
									INSERT INTO @vinesIncompletos
									SELECT @idExpediente, @vin, @idEmpresa, @idSUcursal,
									@cxp_debeTenerDocs, @cxp_docsFaltantes, @cxp_soloTieneDocs,
									@cxc_debeTenerDocs, @cxc_docsFaltantes, @cxc_soloTieneDocs,
									@cxp_fisMor
									
								------------ F I N -------------
								--------------------------------

								SET @auxVines = @auxVines + 1
							END
					END
			
				DELETE FROM @vines
				SET @aux = @aux + 1
			END

		SELECT 
				e.emp_nombre,
				s.suc_nombre,
				vin,
				CASE WHEN cxp_docsFaltantes > 0 THEN 'Incompleto' 
					 WHEN cxp_docsFaltantes = 0 THEN 'Completo' 
					 END AS cxp_estatus,
				CASE 					
					WHEN cxc_docsFaltantes >  0 THEN 'Incompleto' 
					WHEN cxc_docsFaltantes =  0 THEN 'Completo' 
					WHEN cxc_docsFaltantes = -1 THEN 'Unidad en inventario' 
					END AS cxc_estatus
				
		FROM @vinesIncompletos v
		INNER JOIN ControlAplicaciones.dbo.cat_empresas e ON v.idEmpresa = e.emp_idempresa
		INNER JOIN ControlAplicaciones.dbo.cat_sucursales s ON v.idSucursal = s.suc_idsucursal
		WHERE tipoPersona <> ''
		
		-- [expedienteSeminuevo].[SEL_REPORTE_GENERAL_GA_SP] '01/02/2020', '30/08/2020' 

	END TRY
	BEGIN CATCH
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = '[SEL_REPORTE_EXPEDIENTE_COMPLETO_SP]'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	END CATCH
END
go

