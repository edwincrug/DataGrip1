	CREATE PROCEDURE [dbo].[PROV_CUENTAS_ACTIVAS_SP]
	@rfc VARCHAR(20)
	AS
	BEGIN
	
		
		DECLARE @idPersona NUMERIC(18,0)

		DECLARE @tblUsuarios TABLE
		(
			id INT IDENTITY(1,1)
			,idPersona NUMERIC
			,rfc VARCHAR(20)
		)

		INSERT INTO @tblUsuarios 
		SELECT  PER_IDPERSONA, PER_RFC FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_RFC  = @rfc
	

		DECLARE @BASES TABLE(id int identity(1,1),emp_idempresa INT,base nvarchar(200), nombreEmpresa VARCHAR(200))
		
		DECLARE @contBases INT = 1, @numRegistros INT = 0, @contUsuarios INT = 1, @banxico VARCHAR(20), @numRegistrosCuentas INT = 0, @existe INT,@emp_idempresa INT,  @idRespuestaUni   INT, @cie VARCHAR(50), @noCuenta VARCHAR(50),  @numRegistrosU INT = 0, @nombreEmpresa VARCHAR(200)
		DECLARE @basePrincipal VARCHAR(50) = '', @queryCuentaSel NVARCHAR(MAX) = '', @queryBanco NVARCHAR(MAX) = '', @SQLString NVARCHAR(MAX), @sqlUni VARCHAR(MAX)
		DECLARE @ParmDefinition nvarchar(500) 

	
	
		DECLARE @CON_BANCOS TABLE (
				[ID] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
				[BCO_IDPERSONA] [numeric](18, 0) NULL,
				[BCO_BANCO] [varchar](20) NULL,
				[BCO_PLAZA] [varchar](10) NULL,
				[BCO_SUCURSAL] [varchar](50) NULL,
				[BCO_STATUS] [varchar](20) NULL,
				[BCO_TIPCUENTA] [varchar](20) NULL,
				[BCO_NUMCUENTA] [varchar](25) NOT NULL,
				[BCO_CLABE] [varchar](20) NULL,
				[BCO_CVEUSU] [varchar](10) NULL,
				[BCO_FECHOPE] [varchar](50) NULL, 
				[BCO_HORAOPE] [varchar](8) NULL,
				[BCO_REFERNUM] [varchar](35) NULL,
				[BCO_REFERALF] [varchar](35) NULL,
				[BCO_CONVENIOCIE] [varchar](10) NULL,
				[BCO_AUTORIZADA] [int] NULL,
				Empresa VARCHAR(50) NULL
		) 



		INSERT INTO @BASES
		SELECT A.emp_idempresa ,nombre_base ,emp_nombre FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] A
		INNER JOIN ControlAplicaciones.dbo.cat_empresas B ON A.emp_idempresa = B.emp_idempresa WHERE tipo = 2 
		
		

		SET @numRegistros = (select COUNT(1) from @BASES)
		SET @numRegistrosU = (select COUNT(1) from @tblUsuarios)
		
		WHILE(@contUsuarios <= @numRegistrosU )
		BEGIN
			SELECT @idPersona =  idPersona FROM @tblUsuarios WHERE Id =  @contUsuarios
			--SELECT @idPersona
			SET @contBases = 1
			WHILE(@contBases<= @numRegistros)
			BEGIN
					
				SELECT @basePrincipal = base ,  @nombreEmpresa = nombreEmpresa FROM @BASES WHERE id = @contBases

				--select @basePrincipal
				IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @basePrincipal)) 
				BEGIN
						
					SET @SQLString = ' SELECT 
											[BCO_IDPERSONA]
											,[BCO_BANCO]
											,[BCO_PLAZA]
											,[BCO_SUCURSAL]
											,[BCO_STATUS]
											,[BCO_TIPCUENTA]
											,[BCO_NUMCUENTA]
											,[BCO_CLABE]
											,[BCO_CVEUSU]
											,[BCO_FECHOPE]
											,[BCO_HORAOPE]
											,[BCO_REFERNUM]
											,[BCO_REFERALF]
											,[BCO_CONVENIOCIE]
											,[BCO_AUTORIZADA]
											,''' + @nombreEmpresa
										+''' FROM ' + @basePrincipal+'.[dbo].[CON_BANCOS] WHERE [BCO_AUTORIZADA] = 1 AND  [BCO_IDPERSONA] = '+ CONVERT(VARCHAR(50), @idPersona)
				
				
					print @SQLString

					INSERT INTO @CON_BANCOS
					EXECUTE (@SQLString) --sp_executesql @SQLString, @ParmDefinition, @res= @existe OUTPUT
				
			
				
				END
			

			SET @contBases= @contBases+1 
			
			END
			SET @contUsuarios= @contUsuarios + 1
		END
		
			SELECT DISTINCT [BCO_IDPERSONA] 
					,[BCO_PLAZA] 
					,[BCO_SUCURSAL] 
					,[BCO_STATUS] 
					,[BCO_TIPCUENTA]
					,[BCO_NUMCUENTA]
					,[BCO_CLABE]
					,[BCO_AUTORIZADA] 
			FROM	@CON_BANCOS

		END



    go

