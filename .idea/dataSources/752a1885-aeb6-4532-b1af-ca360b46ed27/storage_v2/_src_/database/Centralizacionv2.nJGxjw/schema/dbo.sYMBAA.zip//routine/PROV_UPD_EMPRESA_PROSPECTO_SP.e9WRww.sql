CREATE PROCEDURE [dbo].[PROV_UPD_EMPRESA_PROSPECTO_SP]
@idProspecto INT
,@nombreBD VARCHAR(50)
,@empresaId INT
AS
BEGIN
BEGIN TRY
		UPDATE PROV_PROSPECTO SET
		empresaId = @empresaId
		,empresaBD =	@nombreBD  
	
		WHERE PER_IDPERSONA = @idProspecto

		SELECT 1 result
END TRY
BEGIN CATCH
		SELECT 0 result
END CATCH

END
go

