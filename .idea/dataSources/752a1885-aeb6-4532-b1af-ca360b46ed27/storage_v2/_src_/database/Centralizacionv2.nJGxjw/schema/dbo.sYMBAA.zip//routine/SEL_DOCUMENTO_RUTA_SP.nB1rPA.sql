-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 29/01/2016
-- Description:	Regresa la ruta del Documento
-- =============================================
--EXECUTE [dbo].[SEL_DOCUMENTO_RUTA_SP] 21  

CREATE PROCEDURE [dbo].[SEL_DOCUMENTO_RUTA_SP]
	 @Doc_id	nvarchar(50) = Null

AS
BEGIN

	SET NOCOUNT ON;
		BEGIN TRY 

		SELECT  [par_valor] ruta
			  --,[par_nombre]      
			  --,[par_descripcion]
			  --,[par_status]
		  FROM [Centralizacionv2].[dbo].[DIG_PARAMETROS] 
		 WHERE [par_id] = @Doc_id
					
	END TRY
	
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_DOCUMENTO_RUTA_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

