	CREATE PROCEDURE [dbo].[PROV_INS_PROSPECTO_PORTAL_SP]
		@rfc VARCHAR(20) 
	AS
	BEGIN
	BEGIN TRANSACTION
	BEGIN TRY
	--DECLARE @rfc VARCHAR(20) = 'MOGJ790628397'

		DECLARE @idProspecto NUMERIC (18,0)
				,@tokenID uniqueidentifier 
				,@correoUsuario VARCHAR(100)
				,@tipoProveedor INT
				,@tipoP VARCHAR(10)
		
		
		IF EXISTS(SELECT 1 FROM Centralizacionv2.dbo.PROV_PROSPECTO WHERE per_rfc = @rfc )
		BEGIN
				SELECT @idProspecto = PER_IDPERSONA, @tipoProveedor =   CASE WHEN PER_TIPO = 'FIS' OR PER_TIPO = 'FIE' THEN 1 
																		WHEN PER_TIPO = 'MOR' THEN 2 END
				 FROM Centralizacionv2.dbo.PROV_PROSPECTO where per_rfc = @rfc
		END
		ELSE
		BEGIN
			SET @tokenID = NEWID()
			SET @correoUsuario = (SELECT correo FROM dbo.PPRO_USERSPORTALPROV WHERE ppro_user = @rfc )

			SELECT TOP 1 @tipoProveedor = CASE WHEN PER_TIPO = 'FIS' OR PER_TIPO = 'FIE' THEN 1 
									WHEN PER_TIPO = 'MOR' THEN 2 END ,
						@tipoP		= CASE WHEN PER_TIPO = 'FIS' OR PER_TIPO = 'FIE' THEN 'FIS' 
									WHEN PER_TIPO = 'MOR' THEN 'MOR' END 		
			FROM GA_Corporativa.dbo.PER_PERSONAS WHERE  PER_RFC = @rfc
			
				
			INSERT INTO  Centralizacionv2.dbo.PROV_PROSPECTO (TOKEN,PER_TIPO,PER_RFC,PER_STATUS, fecha_registro, PER_EMAIL, portal) values (@tokenID,@tipoP,@rfc,1,GETDATE(), @correoUsuario,1)

			SELECT @idProspecto = SCOPE_IDENTITY()

		END
		SELECT @idProspecto idProspecto, @tipoProveedor tipoProveedor
	COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
	ROLLBACK TRANSACTION
		SELECT -1 idProspecto,  @tipoProveedor tipoProspecto
	END CATCH



	END


    go

