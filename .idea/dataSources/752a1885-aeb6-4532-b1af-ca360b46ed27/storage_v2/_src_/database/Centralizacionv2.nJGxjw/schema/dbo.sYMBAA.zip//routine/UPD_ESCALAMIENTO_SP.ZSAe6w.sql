-- =============================================
-- Author: Genaro Mora Valencia
-- Create date: 14/12/2015
-- Description:	Procedimiento para Actualizar los escalamientos.
-- =============================================
-- [UPD_ESCALAMIENTO_SP] 1,1,1,3,13,1,0,7,2,3,3
CREATE PROCEDURE [dbo].[UPD_ESCALAMIENTO_SP]
	 @proc_Id	int
	,@nodo_Id	INT
	,@emp_idempresa INT
	,@suc_idsucursal INT
	,@dep_iddepartaamento INT
	,@tipo_idtipoorden INT
	,@usuario_Autoriza NVARCHAR(MAX)
	
		
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	

      DELETE FROM DIG_ESCALAMIENTO	WHERE suc_idsucursal = @suc_idsucursal 
	  AND	dep_iddepartaamento = @dep_iddepartaamento AND emp_idempresa = @emp_idempresa AND tipo_idtipoorden=@tipo_idtipoorden


		DECLARE @userList TABLE(datosXml XML)
		INSERT  @userList SELECT @usuario_Autoriza
		--INSERT  [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO](Proc_Id,Nodo_Id,emp_idempresa,suc_idsucursal,dep_iddepartaamento,tipo_idtipoorden,Nivel_Escalamiento,Usuario_Autoriza1,Usuario_Autoriza2,Usuario_Autoriza3,Minutos_Escalar)
declare @tblInsert table(Proc_Id int,Nodo_Id int,emp_idempresa int,suc_idsucursal int,dep_iddepartaamento int,tipo_idtipoorden int,Nivel_Escalamiento int IDENTITY(0,1),Usuario_Autoriza1 int,Usuario_Autoriza2 int,Usuario_Autoriza3 int,Minutos_Escalar int)
   insert @tblInsert(Proc_Id,Nodo_Id,emp_idempresa,suc_idsucursal,dep_iddepartaamento,tipo_idtipoorden,Usuario_Autoriza1,Usuario_Autoriza2,Usuario_Autoriza3,Minutos_Escalar)
	SELECT
      N.C.value('proc_Id[1]', 'int') Proc_Id
   ,N.C.value('nodo_Id[1]', 'int') Nodo_Id
   ,N.C.value('emp_idempresa[1]', 'int') emp_idempresa
   ,N.C.value('suc_idsucursal[1]', 'int') suc_idsucursal
   ,N.C.value('dep_iddepartaamento[1]', 'int') dep_iddepartaamento
   ,N.C.value('tipo_idtipoorden[1]', 'int') tipo_idtipoorden
   ,N.C.value('Usuario_Autoriza1[1]', 'int') Usuario_Autoriza1
   ,N.C.value('Usuario_Autoriza2[1]', 'int') Usuario_Autoriza2
   ,N.C.value('Usuario_Autoriza3[1]', 'int') Usuario_Autoriza3
   ,N.C.value('Minutos_Escalar[1]', 'int') Minutos_Escalar
FROM @userList
CROSS APPLY datosXml.nodes('//Root') N(C)


INSERT  [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO](Proc_Id,Nodo_Id,emp_idempresa,suc_idsucursal,dep_iddepartaamento,tipo_idtipoorden,Nivel_Escalamiento,Usuario_Autoriza1,Usuario_Autoriza2,Usuario_Autoriza3,Minutos_Escalar)
SELECT	Proc_Id
		,Nodo_Id
		,emp_idempresa
		,suc_idsucursal
		,dep_iddepartaamento
		,tipo_idtipoorden
		,Nivel_Escalamiento
		,Usuario_Autoriza1
		,Usuario_Autoriza2
		,Usuario_Autoriza3
		,Minutos_Escalar
FROM	@tblInsert
--select * from @tblInsert --Cambio SELECT *
		
		
		
		SELECT '1' AS Result

	
	--	IF (@Usuario_Autoriza1 <>@Usuario_Autoriza2) and (@Usuario_Autoriza2 <> @Usuario_Autoriza3) and (@Usuario_Autoriza1 <> @Usuario_Autoriza3)
		--	BEGIN
			--INSERT INTO [dbo].[DIG_ESCALAMIENTO]
			--		   ([Proc_Id]
			--		   ,[Nodo_Id]
			--		   ,[emp_idempresa]
			--		   ,[suc_idsucursal]
			--		   ,[dep_iddepartaamento]
			--		   ,[tipo_idtipoorden]
			--		   ,[Nivel_Escalamiento]
			--		   ,[Usuario_Autoriza1]
			--		   ,[Usuario_Autoriza2]
			--		   ,[Usuario_Autoriza3]
			--		   ,[Minutos_Escalar])
			--	 VALUES
			--		   (select proc_Id	
			--			,nodo_Id	
			--			,emp_idempresa 
			--			,suc_idsucursal 
			--			,dep_iddepartaamento 
			--			,tipo_idtipoorden 
			--			,Nivel_Escalamiento 
			--			,Usuario_Autoriza1 
			--			,Usuario_Autoriza2 
			--			,Usuario_Autoriza3 
			--			,Minutos_Escalar from userList)	


		
						
			--SELECT '1' AS Result
			--END		
			--ELSE
			--BEGIN
		--	SELECT '0' AS Result
		--	END 

			--IF (@Usuario_Autoriza1 <>@Usuario_Autoriza2) and (@Usuario_Autoriza2 <> @Usuario_Autoriza3) and (@Usuario_Autoriza1 <> @Usuario_Autoriza3)
			--BEGIN
			--UPDATE  [dbo].[DIG_ESCALAMIENTO]
			--		SET		
			--		 [Usuario_Autoriza1] = @Usuario_Autoriza1			    
			--		,[Usuario_Autoriza2] = @Usuario_Autoriza2
			--		,[Usuario_Autoriza3] = @Usuario_Autoriza3
			--		,[Minutos_Escalar] = @Minutos_Escalar
			--WHERE	[escalamientoId] = @escalamientoId			 
				  
		 -- SELECT 0
		 -- END
		 -- ELSE
		 -- SELECT -1
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[UPD_ESCALAMIENTO_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT ERROR_NUMBER()
END CATCH
END


--SELECT * FROM [dbo].[DIG_ESCALAMIENTO]
go

