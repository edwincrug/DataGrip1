-- ===================================================================================================
-- Author:		Arturo Rodea Victoria
-- Create date: 23/10/2015
-- Modified date: 06/05/2016  LMS Existencia del Documento
-- Modified date: 31/05/2016  LMS Agrego Documento de Cancelacion si esta Cancelada la orden de Compra
-- solo en el nodo donde esta parada la orden siempre que el Nodo sea mayor a 4 y menor a 15 
-- Description: Stored que recupera los datos de documentos por nodo, folio y perfil
-- Modified date: 01/06/2016  LMS Agrego docuemntos de BPRO para nodo 15
-- ===================================================================================================
--EXECUTE [SEL_DOCUMENTOS_NODO_SP] 7, 'AU-ZM-ZAR-UN-PE-159', 1
--EXECUTE [SEL_DOCUMENTOS_NODO_SP] 7, 'AU-AU-UNI-RE-PE-1864', 1
--EXECUTE [SEL_DOCUMENTOS_NODO_SP] 9, 'AU-AU-CUA-RE-PE-385', 1
--[dbo].[SEL_DOCUMENTOS_NODO_SP] 1,'AU-AU-UNI-UN-2',1
--[dbo].SEL_DOCUMENTOS_NODO_SP 7,'AU-AU-UNI-RE-PE-4234',1
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_NODO_SP]     
	  @idNodo int
	, @folio nvarchar(50)
	, @idperfil int
	
AS
BEGIN
    ----------------------------------------------------------------------
    -- Busco Base e ipServidor
	----------------------------------------------------------------------
	DECLARE @nombreBase        NVARCHAR(100);
	DECLARE @ipServidor        NVARCHAR(100);
	DECLARE @cadIpServidor     NVARCHAR(200);
	DECLARE @idEmpresa         INT = 0;
	DECLARE @ipServer		   NVARCHAR(100);	

    ----------------------------------------------------------------------
	-- Determino Tipo de Proceso
	----------------------------------------------------------------------
	DECLARE @idProceso      INT=0;
	DECLARE @folioPlanPiso  nvarchar(50)

	SELECT @idProceso = E.Proc_Id        
	  FROM dbo.DIG_EXPEDIENTE AS E 
     WHERE E.Folio_Operacion = @folio

    ----------------------------------------------------------------------
	-- Determino si es una orden Padre, busco la orden Hijo
	----------------------------------------------------------------------
	SELECT @folioPlanPiso = Folio_Alias  
      FROM dbo.DIG_EXP_PLAN_PISO 
     WHERE Folio_Operacion = @folio
    
	---------------------------------------------------------------------------------------------------------------------------
	--   Tipo de Proceso 1.-CXP Cuentas Por Pagar
	---------------------------------------------------------------------------------------------------------------------------
    IF (@idProceso = 1 OR @idProceso = 0)
	BEGIN

	--SELECT @nombreBase = nombre_base
 --         ,@ipServidor = ip_servidor
 --     FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
 --    WHERE suc_idsucursal = (SELECT oce_idsucursal
	--						   FROM cuentasxpagar.dbo.cxp_ordencompra
	--						  WHERE oce_folioorden = @folio)

 --  SELECT @ipServer=local_net_address
 --  FROM sys.dm_exec_connections
 --  WHERE Session_id = @@SPID;

 --  IF(@ipServer = @ipServidor)
 --  BEGIN
	--SET @cadIpServidor = ''	
 --  END
 --  ELSE
 --  BEGIN
	--SET @cadIpServidor = '[' + @ipServidor + '].'
 --  END

    
	--SET @cadIpServidor = '[' + @ipServidor + '].'
    --SELECT  @cadIpServidor, @nombreBase

	DECLARE @NodoCancelacion int = 0
	DECLARE @origen1 nvarchar(100) = (SELECT par_valor COLLATE Modern_Spanish_CI_AS FROM DIG_PARAMETROS WHERE par_id = 3) -- Selecciona la ruta de subida	
    ---------------------------------------------------------------------
	--Obtiene la concentradora 
	---------------------------------------------------------------------
	DECLARE @concentradora VARCHAR(100)
	SET @idEmpresa = (	SELECT	oce_idempresa
						FROM	cuentasxpagar.dbo.cxp_ordencompra
						WHERE	oce_folioorden = @folio)
	SET @concentradora = [dbo].[base_Concentradora](@idEmpresa)

	--SELECT @concentradora = @cadIpServidor + '[' + nombre_base + '].[dbo].'
 --     FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
	--  WHERE emp_idempresa = (SELECT oce_idempresa
	--						   FROM cuentasxpagar.dbo.cxp_ordencompra
	--						  WHERE oce_folioorden = @folio)
	--		AND tipo = 2 AND catsuc_nombrecto = 'CONCENTRA'
	--SELECT @concentradora
	DECLARE @existePolizaCompra    INT = 0;
	DECLARE @polizaCompra          TABLE  ( idPoliza  INT);
	INSERT INTO @polizaCompra 
        EXECUTE (' SELECT CASE WHEN EXISTS ( SELECT 1 FROM ' + @concentradora + 'con_movimientoreferencia '+
													  'WHERE mre_folioorden = ''' + @folio + ''''+
													  ' AND mre_tipoliza IN (SELECT PAR_IDENPARA FROM ' + @concentradora + 'PNC_PARAMETR'+
																							   ' WHERE PAR_TIPOPARA = ''TIPOLI'' AND PAR_DESCRIP2 IN(''COMACC'',''COMACCS'',''CU'',''CR'',''COSE'',''APORDCOM'',''CPV'',''CXPTOT'',''CPVCON'')))'+
                              ' THEN 1 '+  
							  '    ELSE 0 '+
							  ' END	');
		
    
	SELECT @existePolizaCompra = idPoliza 
	  FROM @polizaCompra
	--SELECT 'Existe Poliza', @existePolizaCompra
	---------------------------------------------------------------------
	--SELECT @NodoCancelacion = CASE  --Busco si esta cancelada la Orden
	--								WHEN EXISTS(
	--									select Folio_Operacion
	--									  from [Centralizacionv2].[dbo].[DIG_EXPEDIENTE]
	--									 where Folio_Operacion = @folio
	--									   and estatus_id = 2            --OC Cancelada
	--								)
	--								THEN (
	--								    --Busco el ultimo nodo activo
	--									select Top 1 Nodo_id
	--									  from [Centralizacionv2].[dbo].[DIG_EXP_NODO] 
	--									 where Folio_Operacion = @folio 
	--									   and Nodo_estatus_id = 2 
	--									 order by Nodo_id desc
	--								) 
	--								ELSE '0' 
	--								END		

   
    --PRINT 'NodoCancelacion: ' + cast(@NodoCancelacion as varchar)

	--IF (@idNodo < 5 or @idNodo >= 5 and @idNodo <= 15 and @NodoCancelacion <> @idNodo )  --Orden Activa o Inactiva pero detenida en otro nodos
	--	BEGIN
		      PRINT 'QUERY SENCILLO: ' + cast(@idNodo as varchar)
			  SELECT  DISTINCT E.Proc_Id                                                    as idProceso
										, EN.Nodo_Id												   as idNodo
										, N.Nodo_Nombre COLLATE Modern_Spanish_CI_AS                   as nombreNodo
										, EN.Folio_Operacion COLLATE Modern_Spanish_CI_AS              as folio
										, UPPER(CD.Doc_Nombre) COLLATE Modern_Spanish_CI_AS            as nombreDocumento
										, CD.Doc_Id                                                    as idDocumento
										, CD.Doc_Origen COLLATE Modern_Spanish_CI_AS                   as origen
										, UPPER(CD.Doc_Descripcion) COLLATE Modern_Spanish_CI_AS       as descripcion
										, PD.Perfil_Id                                                 as idPerfil
										,CASE	WHEN (CD.Doc_Id = 15 AND EN.Nodo_Id = 4) THEN 1 
												WHEN (CD.Doc_Id = 67 AND EXISTS(SELECT * FROM cuentasxpagar.DBO.cxp_doctospagados WHERE dpa_iddocumento = @folio)
																	 AND EXISTS(SELECT	* 
																				FROM	PAGOS.DBO.PAG_PROGRA_PAGOS_DETALLE D
																						INNER JOIN referencias.DBO.Bancomer  B ON B.refAmpliada like '%' + D.pad_polReferencia + '%'
																						WHERE pad_documento = @folio)) THEN 1
												WHEN (CD.Doc_Id = 66 AND EXISTS(SELECT * FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pad_documento = @folio)) THEN 1
												ELSE cast(PD.Consultar as int) 
												END  as consultar --WHEN (CD.Doc_Id = 13 AND @existePolizaCompra = 0) THEN 0 
										--, cast(PD.Consultar as int)                                    as consultar
										,CASE	WHEN (CD.Doc_Id = 15 AND EN.Nodo_Id = 4) THEN 0 
												WHEN (CD.Doc_Id = 67 AND EXISTS(SELECT * FROM cuentasxpagar.DBO.cxp_doctospagados WHERE dpa_iddocumento = @folio)
																	 AND EXISTS(SELECT	* 
																				FROM	PAGOS.DBO.PAG_PROGRA_PAGOS_DETALLE D
																						INNER JOIN referencias.DBO.Bancomer  B ON B.refAmpliada like '%' + D.pad_polReferencia + '%'
																						WHERE pad_documento = @folio)) THEN 0
												WHEN (CD.Doc_Id = 66 AND EXISTS(SELECT * FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pad_documento = @folio)) THEN 0
												ELSE cast(PD.Imprimir as int) END  as imprimir
										--, cast(PD.Imprimir as int)                                     as imprimir
										, cast(PD.Enviar_Email  as int)                                as enviarEmail
										,CASE	WHEN (CD.Doc_Id = 15 AND EN.Nodo_Id = 4) THEN 0 
												WHEN (CD.Doc_Id = 67 AND EXISTS(SELECT * FROM cuentasxpagar.DBO.cxp_doctospagados WHERE dpa_iddocumento = @folio)
																	 AND EXISTS(SELECT	* 
																				FROM	PAGOS.DBO.PAG_PROGRA_PAGOS_DETALLE D
																						INNER JOIN referencias.DBO.Bancomer  B ON B.refAmpliada like '%' + D.pad_polReferencia + '%'
																						WHERE pad_documento = @folio)) THEN 0
												WHEN (CD.Doc_Id = 66 AND EXISTS(SELECT * FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pad_documento = @folio)) THEN 0
												ELSE cast(PD.Descargar as int) END  as descargar
										--, cast(PD.Descargar as int)                                    as descargar
										,CASE	WHEN (CD.Doc_Id = 15 AND EN.Nodo_Id = 4) THEN 0 
												WHEN (CD.Doc_Id = 67 AND EXISTS(SELECT * FROM cuentasxpagar.DBO.cxp_doctospagados WHERE dpa_iddocumento = @folio)
																	 AND EXISTS(SELECT	* 
																				FROM	PAGOS.DBO.PAG_PROGRA_PAGOS_DETALLE D
																						INNER JOIN referencias.DBO.Bancomer  B ON B.refAmpliada like '%' + D.pad_polReferencia + '%'
																						WHERE pad_documento = @folio)) THEN 0
												WHEN (CD.Doc_Id = 66 AND EXISTS(SELECT * FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pad_documento = @folio)) THEN 0
												ELSE cast(PD.Cargar as int) END  as cargar
										--, cast(PD.Cargar as int)                                       as cargar
										, EE.Estatus_Nombre COLLATE Modern_Spanish_CI_AS               as estatusNombre
										, EN.Nodo_Estatus_Id                                           as idEstatus
										, CASE WHEN CD.Doc_Origen = 1 THEN  @origen1 --+ dbo.OBTIENE_RUTA_FN(@folio, @idNodo, CD.Doc_Id)
										ELSE '' END AS Ruta
										,CASE WHEN ED.Fecha_Creacion is null THEN  
																					CASE 
																							WHEN (CD.Doc_Id = 65 AND EN.Nodo_Id <= 3 AND EXISTS(SELECT * FROM [Centralizacionv2].[dbo].[DIG_BITACORA_ENVCORREO] WHERE Folio_Operacion = @folio AND id_nodo = 2 AND enviado =1)) THEN EN.Folio_Operacion
																							WHEN (CD.Doc_Id = 65 AND EN.Nodo_Id > 3 AND EXISTS(SELECT * FROM [Centralizacionv2].[dbo].[DIG_BITACORA_ENVCORREO] WHERE Folio_Operacion = @folio AND id_nodo = 4  AND enviado =1)) THEN EN.Folio_Operacion
																							WHEN (CD.Doc_Id = 67 AND EXISTS(SELECT * FROM cuentasxpagar.DBO.cxp_doctospagados WHERE dpa_iddocumento = @folio)
																												 AND EXISTS(SELECT	* 
																															FROM	PAGOS.DBO.PAG_PROGRA_PAGOS_DETALLE D
																																	INNER JOIN referencias.DBO.Bancomer  B ON B.refAmpliada like '%' + D.pad_polReferencia + '%'
																																	WHERE pad_documento = @folio)) THEN EN.Folio_Operacion
																							WHEN (CD.Doc_Id = 66 AND EXISTS(SELECT * FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pad_documento = @folio)) THEN EN.Folio_Operacion
																							--WHEN (CD.Doc_Id = 20 ) THEN ''
																							ELSE '' 
																							END
										--''
											  WHEN ED.Fecha_Creacion is not null THEN --'Si'
																					CASE 
																						WHEN CD.Doc_Id = 11 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN CD.Doc_Id = 12 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN (CD.Doc_Id = 13 AND @existePolizaCompra = 1) THEN CD.[Doc_Ruta_Web] + 'Pol_PC_' + EN.Folio_Operacion +  CD.[Doc_Extencion]
																						WHEN (CD.Doc_Id = 13 AND @existePolizaCompra = 0) THEN ''
																						WHEN CD.Doc_Id = 14 THEN CD.[Doc_Ruta_Web] + 'Pol_PT_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN CD.Doc_Id = 15 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																						WHEN CD.Doc_Id = 20 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + ISNULL((SELECT rfc_receptor 
																																											+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																											+ '/' + ISNULL(rfc_emisor,'xxxxx') + '_' + 
																																											CASE folio 
																																												WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																												--ELSE  LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																												ELSE serie + REPLACE(folio, '+', '') 
																																											END
																																											+ '.pdf'
																																									   FROM PPRO_DATOSFACTURAS 
																																									  WHERE [folioorden] = EN.Folio_Operacion
																																									    AND [tipoDocumento] = 1 --Factura
																																									  ),(SELECT rfc_receptor 
																																											+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																											+ '/' + ISNULL(rfc_emisor,'xxxxx') + '_' + 
																																											CASE folio 
																																												WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																												--ELSE  LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																												ELSE serie + REPLACE(folio, '+', '')
																																											END
																																											+ '.pdf'
																																									   FROM PPRO_DATOSFACTURAS 
																																									  WHERE [folioorden] = @folioPlanPiso    --EN.Folio_Operacion
																																									    AND [tipoDocumento] = 1 --Factura
																																									  ))
                                                    ---------
													WHEN CD.Doc_Id = 10 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + ISNULL((SELECT rfc_receptor 
																																		+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																		+ '/' + rfc_emisor + '_' + 
																																		CASE folio 
																																			WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																			ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																		END
																																		+ '.pdf'
																																	FROM PPRO_DATOSFACTURAS 
																																	WHERE [folioorden] = EN.Folio_Operacion
																																	AND [tipoDocumento] = 2 --Nota de Credito
																																	),(SELECT rfc_receptor 
																																		+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																		+ '/' + rfc_emisor + '_' + 
																																		CASE folio 
																																			WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																			ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																		END
																																		+ '.pdf'
																																	FROM PPRO_DATOSFACTURAS 
																																	WHERE [folioorden] =  @folioPlanPiso  --EN.Folio_Operacion
																																	AND [tipoDocumento] = 2               --Nota de Credito
																																	))
													---------
																	
																						ELSE 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.' + ED.Doc_Extencion --ISNULL(CD.[Doc_Extencion],'.pdf')
																					END
											  END AS existeDoc
										 ,D.Orden 	                                  AS orden
										 ,CD.Doc_NomCto COLLATE Modern_Spanish_CI_AS  AS tipo
										 ,CASE WHEN EXISTS(
																	SELECT [estatus]--[folioorden]--
																	  FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]  
																	 WHERE [folioorden] = @folio
																	   AND [estatus] = 1
																)
																THEN 2
																ELSE 1 
										 END                                          AS estatusDoc
								FROM     dbo.DIG_PERFIL_DOCUMENTO   AS PD LEFT JOIN
										 dbo.DIG_CATDOCUMENTO       AS CD ON PD.Doc_Id = CD.Doc_Id LEFT JOIN
										 dbo.DIG_EXPEDIENTE         AS E LEFT JOIN
										 dbo.DIG_ESTATUS_EXPEDIENTE AS EE ON E.Estatus_Id = EE.Estatus_Id LEFT JOIN
										 dbo.DIG_EXP_NODO           AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion LEFT JOIN
										 dbo.DIG_EXPNODO_DOC        AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id 
										 INNER JOIN dbo.DIG_NODO_DOC AS D ON ED.Doc_Id = D.Doc_Id AND ED.Nodo_Id = D.Nodo_Id
										 LEFT JOIN
										 dbo.DIG_NODO               AS N  ON EN.Proc_Id = N.Proc_Id AND EN.Nodo_Id = N.Nodo_Id LEFT JOIN
										 dbo.DIG_NODOPERFIL         AS NP ON N.Proc_Id = NP.Proc_Id AND N.Nodo_Id = NP.Nodo_Id ON PD.Doc_Id = ED.Doc_Id
								WHERE EN.Nodo_Id = @idNodo 
									AND (EN.Folio_Operacion = @folio OR EN.Folio_Operacion IN ( 
											SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
										  ) )
									AND PD.Perfil_Id = @idperfil
							   ORDER BY D.Orden
		--END
	--ELSE
	--	BEGIN
	--		IF (@idNodo >= 5 and @idNodo <= 15 and @NodoCancelacion = @idNodo )   --Ordenes Canceladas y Paradas en el mismo Nodo
	--		BEGIN
	--		      PRINT 'QUERY SENCILLO + UNION: ' + cast(@idNodo as varchar)
	--			  SELECT * 
	--				FROM ((SELECT  DISTINCT E.Proc_Id							 as idProceso
	--										, EN.Nodo_Id						 as idNodo
	--										, N.Nodo_Nombre						 as nombreNodo
	--										, EN.Folio_Operacion				 as folio
	--										, CD.Doc_Nombre                      as nombreDocumento
	--										, CD.Doc_Id                          as idDocumento
	--										, CD.Doc_Origen                      as origen
	--										, CD.Doc_Descripcion				 as descripcion
	--										, PD.Perfil_Id                       as idPerfil
	--										, cast(PD.Consultar as int)          as consultar
	--										, cast(PD.Imprimir as int)           as imprimir
	--										, cast(PD.Enviar_Email  as int)      as enviarEmail
	--										, cast(PD.Descargar as int)          as descargar
	--										, cast(PD.Cargar as int)             as cargar
	--										, EE.Estatus_Nombre                  as estatusNombre
	--										, EN.Nodo_Estatus_Id                 as idEstatus
	--										, CASE WHEN CD.Doc_Origen = 1 THEN  @origen1 --+ dbo.OBTIENE_RUTA_FN(@folio, @idNodo, CD.Doc_Id)
	--											   ELSE '' END                   as Ruta
	--										,CASE WHEN ED.Fecha_Creacion is null THEN ''
	--												WHEN ED.Fecha_Creacion is not null THEN --'Si'
	--																					CASE CD.Doc_Id
	--																						WHEN 11 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
	--																						WHEN 12 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
	--																						WHEN 13 THEN CD.[Doc_Ruta_Web] + 'Pol_PC_' + EN.Folio_Operacion +  CD.[Doc_Extencion]
	--																						WHEN 14 THEN CD.[Doc_Ruta_Web] + 'Pol_PT_' + EN.Folio_Operacion + CD.[Doc_Extencion]
	--																						WHEN 15 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
	--																						WHEN 20 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + (SELECT rfc_receptor 
	--																																											+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
	--																																											+ '/' + rfc_emisor + '_' + 
	--																																											CASE folio 
	--																																												WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
	--																																												ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
	--																																											END
	--																																											+ '.pdf'
	--																																										FROM PPRO_DATOSFACTURAS 
	--																																										WHERE [folioorden] = EN.Folio_Operacion
	--																																										  AND [tipoDocumento] = 1 --Factura
	--																																										)
	--																						---------
	--																						WHEN 10 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + (SELECT rfc_receptor 
	--																																											+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
	--																																											+ '/' + rfc_emisor + '_' + 
	--																																											CASE folio 
	--																																												WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
	--																																												ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
	--																																											END
	--																																											+ '.pdf'
	--																																										FROM PPRO_DATOSFACTURAS 
	--																																										WHERE [folioorden] = EN.Folio_Operacion
	--																																										AND [tipoDocumento] = 2 --Nota de Credito
	--																																										)
	--																						---------
	--																						ELSE 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.' + ED.Doc_Extencion --ISNULL(CD.[Doc_Extencion],'.pdf')
	--																					END
	--												END                    as existeDoc
	--											,D.Orden	               as orden
	--											,CD.Doc_NomCto             as tipo
	--											,CASE WHEN EXISTS(
	--																SELECT [estatus]--[folioorden]--
	--																  FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]  
	--																 WHERE [folioorden] = @folio
	--																   AND [estatus] = 2
	--															)
	--															THEN 2
	--															ELSE 1 
	--									         END                                          AS estatusDoc
	--								FROM     dbo.DIG_PERFIL_DOCUMENTO   AS PD LEFT JOIN
	--											dbo.DIG_CATDOCUMENTO       AS CD ON PD.Doc_Id = CD.Doc_Id LEFT JOIN
	--											dbo.DIG_EXPEDIENTE         AS E LEFT JOIN
	--											dbo.DIG_ESTATUS_EXPEDIENTE AS EE ON E.Estatus_Id = EE.Estatus_Id LEFT JOIN
	--											dbo.DIG_EXP_NODO           AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion LEFT JOIN
	--											dbo.DIG_EXPNODO_DOC        AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id 
	--											INNER JOIN dbo.DIG_NODO_DOC AS D ON ED.Doc_Id = D.Doc_Id AND ED.Nodo_Id = D.Nodo_Id
	--											LEFT JOIN
	--											dbo.DIG_NODO               AS N  ON EN.Proc_Id = N.Proc_Id AND EN.Nodo_Id = N.Nodo_Id LEFT JOIN
	--											dbo.DIG_NODOPERFIL         AS NP ON N.Proc_Id = NP.Proc_Id AND N.Nodo_Id = NP.Nodo_Id ON PD.Doc_Id = ED.Doc_Id
	--								WHERE EN.Nodo_Id = @idNodo 
	--									AND (EN.Folio_Operacion = @folio OR EN.Folio_Operacion IN ( 
	--											SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
	--											) )
	--									AND PD.Perfil_Id = @idperfil
	--								--ORDER BY D.Orden	
 --                                   )
	--				    UNION
 --                               (SELECT 1                                           as idProceso       --int
	--								   ,@idNodo                                     as idNodo          --int
	--								   ,(select Nodo_Nombre from [DIG_NODO] where Nodo_id = @idNodo) COLLATE Modern_Spanish_CI_AS                                    as nombreNodo      --varchar
	--								   ,@folio  as folio           --varchar
	--								   ,C.[Doc_Nombre]                              as nombreDocumento --varchar
	--								   ,C.[Doc_Id]                                  as idDocumento     --int
	--								   ,C.[Doc_Origen]                              as origen          --varchar --BPRO
	--								   ,C.[Doc_Descripcion]                         as descripcion     --varchar
	--								   ,1                                           as idPerfil        --int
	--								   ,1                                           as consultar       --int
	--								   ,1                                           as imprimir        --bit
	--								   ,1                                           as enviarEmail     --bit
	--								   ,1                                           as descargar       --bit
	--								   ,0                                           as cargar          --bit
	--								   ,(select estatus_nombre COLLATE Modern_Spanish_CI_AS
	--									   from [Centralizacionv2].[dbo].[DIG_ESTATUS_EXPEDIENTE] 
	--									   where estatus_id=(select estatus_id 
	--														   from	[Centralizacionv2].[dbo].[DIG_EXPEDIENTE] 
	--														  where folio_operacion = @folio))  as estatusNombre   --varchar
	--								   ,(select estatus_id 
	--									   from	[Centralizacionv2].[dbo].[DIG_EXPEDIENTE] 
	--									  where folio_operacion = @folio)           as idEstatus  --int
	--								   ,'Ruta'    as Ruta            --varchar
	--								   ,'C:/Users/USUARIO/Documents/Cancelacion.pdf'   as existeDoc       --varchar
	--								   ,1                                           as orden           --decimal(5, 2)
	--								   ,C.[Doc_NomCto] as tipo           --varchar
	--								   ,1                                           AS estatusDoc
	--							 FROM  [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] AS C
	--							 WHERE [Doc_Id] = 23 
	--							 )) AS T 
	--			  ORDER BY T.orden 
				  
	--		END    
			
	--	END
    
	END --FIN CXP
	---------------------------------------------------------------------------------------------------------------------------
	--   Tipo de Proceso 2.-CXC Cuentas Por Cobrar 
	---------------------------------------------------------------------------------------------------------------------------
	ELSE IF(@idProceso = 2)
	BEGIN
	------------------------------------
    DECLARE @existeAnticipo    INT = 0;
	DECLARE @anticipo          TABLE  ( idAnticipo  INT);
	DECLARE @existeRc		   INT = 0;
	DECLARE @reciboCaja	       TABLE  ( idReciboC  INT);

	--SELECT @nombreBase = nombre_base
 --         ,@ipServidor = ip_servidor
 --     FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
 --    WHERE suc_idsucursal = (SELECT ucu_idsucursal
 --                              FROM cuentasporcobrar.dbo.uni_cotizacionuniversal
 --                             WHERE ucu_foliocotizacion = @folio)
    
	SET @cadIpServidor = [dbo].[base_Cotizacion](@folio)
    --SELECT  @cadIpServidor, @nombreBase

	INSERT INTO @anticipo 
	EXECUTE (' SELECT CASE WHEN EXISTS ( SELECT 1 '+
											             '  FROM '+ @cadIpServidor + 'CXC_PAGANT '+
                                                         ' WHERE PAM_REFERENCIA = ' +''''+ @folio +''''+' )'+
                              ' THEN 1 '+  
							  '    ELSE 0 '+
							  ' END	');
        --EXECUTE (' SELECT CASE WHEN EXISTS ( SELECT PAM_IDCOTIZACIONWEB '+
								--			             '  FROM '+ @cadIpServidor + @nombreBase +'.dbo.CXC_PAGANT '+
        --                                                 ' WHERE PAM_REFERENCIA = ' +''''+ @folio +''''+' )'+
        --                      ' THEN 1 '+  
							 -- '    ELSE 0 '+
							 -- ' END	');
    
	SELECT @existeAnticipo = idAnticipo 
	  FROM @anticipo

	   INSERT INTO @reciboCaja
        EXECUTE (' SELECT CASE WHEN EXISTS ( SELECT PAM_IDDOCTO '+
											             '  FROM '+ @cadIpServidor + 'CXC_PAGANT P'+
														 '  INNER JOIN '+ @cadIpServidor + 'uni_cotizacionuniversalunidades  U ON P.PAM_DOCAFECTADO = U.ucn_idFactura'+
														 '  INNER JOIN '+ @cadIpServidor + 'uni_cotizacionuniversal UE ON U.ucu_idcotizacion = UE.ucu_idcotizacion'+
                                                         '  WHERE UE.ucu_foliocotizacion = ' +''''+ @folio +''''+' )'+
                              ' THEN 1 '+  
							  '    ELSE 0 '+
							  ' END	');
	SELECT @existeRc = idReciboC 
	  FROM @reciboCaja
	------------------------------------
	IF (@idNodo <= 6 )  --Orden Activa o Inactiva pero detenida en otro nodos
		BEGIN
		      PRINT 'QUERY SENCILLO CXC: ' + cast(@idNodo as varchar)
			  SELECT  DISTINCT E.Proc_Id                                                    as idProceso
								, EN.Nodo_Id												   as idNodo
								, N.Nodo_Nombre COLLATE Modern_Spanish_CI_AS                   as nombreNodo
								, EN.Folio_Operacion COLLATE Modern_Spanish_CI_AS              as folio
								, UPPER(CD.Doc_Nombre) COLLATE Modern_Spanish_CI_AS            as nombreDocumento
								, CD.Doc_Id                                                    as idDocumento
								, CD.Doc_Origen COLLATE Modern_Spanish_CI_AS                   as origen
								, UPPER(CD.Doc_Descripcion) COLLATE Modern_Spanish_CI_AS       as descripcion
								, PD.Perfil_Id                                                 as idPerfil
								--, cast(PD.Consultar as int)                                    as consultar
								--------------
								-- Anticipo --
								--------------
								--,CASE WHEN CD.Doc_Id = 24 
								--           THEN  @existeAnticipo 
								--      ELSE 
								--	       cast(PD.Consultar as int)
        --                          END  as consultar
								--------------
								,cast(PD.Consultar as int)									   as consultar
								, cast(PD.Imprimir as int)                                     as imprimir
								, cast(PD.Enviar_Email  as int)                                as enviarEmail
								, cast(PD.Descargar as int)                                    as descargar
								, cast(PD.Cargar as int)                                       as cargar
								, EE.Estatus_Nombre COLLATE Modern_Spanish_CI_AS               as estatusNombre
								, EN.Nodo_Estatus_Id                                           as idEstatus
								, CASE WHEN CD.Doc_Origen = 1 THEN  @origen1 --+ dbo.OBTIENE_RUTA_FN(@folio, @idNodo, CD.Doc_Id)
								ELSE '' END AS Ruta
								,CASE WHEN ED.Fecha_Creacion is null THEN ''
										WHEN ED.Fecha_Creacion is not null THEN --'Si'
																			CASE CD.Doc_Id  
																				WHEN 24 THEN (CASE WHEN @existeAnticipo = 0 THEN '' ELSE EN.Folio_Operacion END) 
																				WHEN 26 THEN (CASE WHEN ([ucu_idpedidobpro] IS NULL) THEN '' ELSE EN.Folio_Operacion END)
																				WHEN 28 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXCobrar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																				WHEN 29 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXCobrar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																				WHEN 30 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXCobrar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																				WHEN 20 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + (SELECT rfc_receptor 
																																									+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																									+ '/' + rfc_emisor + '_' + 
																																									CASE folio 
																																										WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																										ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																									END
																																									+ '.pdf'
																																								FROM PPRO_DATOSFACTURAS 
																																								WHERE [folioorden] = EN.Folio_Operacion
																																								  AND [tipoDocumento] = 1 --Factura
																																								)
																				WHEN 40 THEN (CASE WHEN @existeRc = 0 THEN '' ELSE EN.Folio_Operacion END) 
																				ELSE 'http://192.168.20.89/GA_Centralizacion/CuentasXCobrar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf' -- '.' + ED.Doc_Extencion --ISNULL(CD.[Doc_Extencion],'.pdf')
																			END
										END AS existeDoc
									,D.Orden 	                                  AS orden
									,CD.Doc_NomCto COLLATE Modern_Spanish_CI_AS  AS tipo
									,CASE WHEN EXISTS(
															SELECT [estatus]--[folioorden]--
																FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]  
																WHERE [folioorden] = @folio
																AND [estatus] = 2
														)
														THEN 2
														ELSE 1 
									END                                          AS estatusDoc
						----***************************************************************************************************
						--***********LAURA Modificado, este debe ir cuando ya exista la relación entre el tipo de documento y el tipo de venta
						--   FROM     dbo.DIG_PERFIL_DOCUMENTO   AS PD LEFT JOIN
						--			dbo.DIG_CATDOCUMENTO       AS CD ON PD.Doc_Id = CD.Doc_Id LEFT JOIN
						--			dbo.DIG_EXPEDIENTE         AS E LEFT JOIN
						--			dbo.DIG_ESTATUS_EXPEDIENTE AS EE ON E.Estatus_Id = EE.Estatus_Id LEFT JOIN
						--			dbo.DIG_EXP_NODO           AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion LEFT JOIN
						--			dbo.DIG_EXPNODO_DOC        AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id 
						--			----
						--			INNER JOIN  Centralizacionv2.dbo.DIG_DOC_TIPO_VENTA AS DT ON DT.Doc_Id = ED.Doc_Id AND DT.Tip_Id = (SELECT Tip_Id
						--																												  FROM Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA AS T
						--																													   INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O 
						--																													   ON O.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS = @folio AND T.Tip_Clave = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS
						--																											    )
						--			----
						--			INNER JOIN dbo.DIG_NODO_DOC AS D ON DT.Doc_Id = D.Doc_Id AND ED.Nodo_Id = D.Nodo_Id
						--			LEFT JOIN
						--			dbo.DIG_NODO               AS N  ON EN.Proc_Id = N.Proc_Id AND EN.Nodo_Id = N.Nodo_Id LEFT JOIN
						--			dbo.DIG_NODOPERFIL         AS NP ON N.Proc_Id = NP.Proc_Id AND N.Nodo_Id = NP.Nodo_Id ON PD.Doc_Id = ED.Doc_Id
						--WHERE EN.Nodo_Id = @idNodo 
						--	AND (EN.Folio_Operacion = @folio OR EN.Folio_Operacion IN ( 
						--			SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
						--			) )
						--	AND PD.Perfil_Id = @idperfil
						--ORDER BY D.Orden
						--*************************************************************************************************************************************************************
						FROM     dbo.DIG_PERFIL_DOCUMENTO   AS PD 
									LEFT JOIN dbo.DIG_CATDOCUMENTO       AS CD ON PD.Doc_Id = CD.Doc_Id 
									LEFT JOIN dbo.DIG_EXPEDIENTE         AS E 
									LEFT JOIN dbo.DIG_ESTATUS_EXPEDIENTE AS EE ON E.Estatus_Id = EE.Estatus_Id 
									LEFT JOIN dbo.DIG_EXP_NODO           AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion 
									LEFT JOIN dbo.DIG_EXPNODO_DOC        AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id 									
									--LEFT JOIN  Centralizacionv2.dbo.DIG_DOC_TIPO_VENTA AS DT ON DT.Doc_Id = ED.Doc_Id AND DT.Tip_Id = (SELECT Tip_Id
									--																									  FROM Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA AS T
									--																										   INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O 
									--																										   ON O.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS = @folio AND T.Tip_Clave = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS
									--																								    )									
									INNER JOIN dbo.DIG_NODO_DOC AS D ON ED.Doc_Id = D.Doc_Id AND ED.Nodo_Id = D.Nodo_Id
									LEFT JOIN dbo.DIG_NODO               AS N  ON EN.Proc_Id = N.Proc_Id AND EN.Nodo_Id = N.Nodo_Id 
									LEFT JOIN dbo.DIG_NODOPERFIL         AS NP ON N.Proc_Id = NP.Proc_Id AND N.Nodo_Id = NP.Nodo_Id ON PD.Doc_Id = ED.Doc_Id
									INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS C ON E.Folio_Operacion = C.ucu_foliocotizacion COLLATE SQL_Latin1_General_CP1_CI_AS
						WHERE EN.Nodo_Id = @idNodo 
							AND (EN.Folio_Operacion = @folio OR EN.Folio_Operacion IN ( 
									SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
									) )
							AND PD.Perfil_Id = @idperfil
		END
    END --FIN CXC

END
go

