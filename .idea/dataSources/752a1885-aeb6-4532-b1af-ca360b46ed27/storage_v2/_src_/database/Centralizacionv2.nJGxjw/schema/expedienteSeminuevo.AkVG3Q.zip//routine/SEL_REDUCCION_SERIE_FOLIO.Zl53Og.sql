-- =============================================
-- Author:		<Luis Garcia y David Vazquez>
-- Create date: <24/07/2020>
-- Description:	<Descompone la factura y le quita los ceros>
-- SELECT [expedienteSeminuevo].[SEL_REDUCCION_SERIE_FOLIO] ('AA000002806')
-- =============================================
CREATE FUNCTION [expedienteSeminuevo].[SEL_REDUCCION_SERIE_FOLIO] 
(
	@documento VARCHAR(15) = ''
)
RETURNS VARCHAR(15)
AS
BEGIN
	DECLARE @serie VARCHAR(5) = '', @folio VARCHAR(300) = '';
	DECLARE @aux INT = 1

	SET @serie = SUBSTRING(@documento, 0, 3);
	SET @folio = SUBSTRING(@documento, 3, LEN(@documento));

	WHILE (@aux = 1)
		BEGIN
			IF( SUBSTRING(@folio, 0, 2) = 0 )
				BEGIN
					IF(SUBSTRING(@folio, 0, 2) <> '')
						BEGIN
							SET @folio = SUBSTRING(@folio, 2, LEN(@documento));	
						END
					ELSE
						BEGIN
							SET @aux = 0	
						END
				END
			ELSE
				BEGIN
					SET @aux = 0
				END
		END
	RETURN  @serie + @folio 
END

go

