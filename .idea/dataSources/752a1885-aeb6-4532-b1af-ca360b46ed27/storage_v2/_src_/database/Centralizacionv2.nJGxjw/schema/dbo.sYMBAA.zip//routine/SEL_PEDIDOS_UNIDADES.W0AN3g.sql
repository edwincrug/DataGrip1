-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================


 -- execute [dbo].[SEL_PEDIDOS_UNIDADES]'AU-ZM-NZA-UN-4365','3N6AD31A0KK845084'
CREATE PROCEDURE [dbo].[SEL_PEDIDOS_UNIDADES] 
	@folio nvarchar(50)
   ,@numeroSerie nvarchar(70)
   
AS
BEGIN

	 DECLARE @ConsultaPedidosUnidades NVARCHAR(max)  
	 DECLARE @baseLocal NVARCHAR(max)
	 DECLARE @baseConcentra NVARCHAR(max)
	 DECLARE @idCot NVARCHAR(max)  

	  SELECT @idCot = ucu_idcotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @folio

	  SET  @baseLocal=[dbo].[base_Cotizacion](@folio)

	--SET  @baseLocal=(SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
	--				(SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa =
	--				(SELECT ucu_idempresa FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion =''+ @folio +'')) AND suc_idsucursal = 
	--				(SELECT ucu_idsucursal FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = ''+ @folio +''))

	SET @baseConcentra=[dbo].[base_concentradora_cotizacion](@folio)

	--SET @baseConcentra=(SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
	--				   (SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa =
	--				   (SELECT ucu_idempresa FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = ''+ @folio +'')) AND tipo = 2)


	SET @ConsultaPedidosUnidades =  'SELECT C.ucu_foliocotizacion, C.ucu_idcotizacion, E.emp_nombre, S.suc_nombre, D.dep_nombre,'+CHAR(13)+
									 +'B.rfc, C.ucu_fechacotiza,CC.cec_descripcion, C.ucu_idcliente,'+CHAR(13)+
									 +'NombreCliente = LTRIM(RTRIM(P.per_paterno)) + '' ''+ LTRIM(RTRIM(P.per_materno)) + '' ''+ LTRIM(RTRIM(P.per_nomrazon)),P.per_rfc,'+CHAR(13)+
									 +'Direccion = LTRIM(RTRIM(P.[PER_CALLE1])) + '' ''+ LTRIM(RTRIM(P.[PER_NUMEXTER])) + '' Col.''+ LTRIM(RTRIM(P.[PER_COLONIA]))+ ''. ''+ LTRIM(RTRIM(P.PER_DELEGAC)) + ''. ''+  LTRIM(RTRIM(P.[PER_CIUDAD])) + ''. C.p.''+  LTRIM(RTRIM(P.[PER_CODPOS])),'+CHAR(13)+
									 +'P.[PER_TELEFONO1],D.dep_nombre,'+CHAR(13)+
									 +'UsuarioSolicita = LTRIM(RTRIM(U.usu_paterno)) + '' ''+ LTRIM(RTRIM(U.usu_materno)) + '' ''+LTRIM(RTRIM(U.usu_nombre)),'+CHAR(13)+
									 +'C.ucu_idpedidobpro,'+CHAR(13)+
									 +'P1.UPE_FECHPEDI,P1.UPE_IDAGTE,P1.UPE_STATUS,P1.UPE_CVEUSU,P2.PEN_IDCATALOGO,'+CHAR(13)+
									 +'P2.PEN_MODELO,P2.PEN_NUMSERIE,P2.PEN_STATUS,P2.PEN_SUBTOTAL1,P2.PEN_IVA,P2.PEN_TOTAL,'+CHAR(13)+
									 +'P3.UNC_DESCRIPCION,P3.UNC_PTAS,P3.UNC_CILINDROS,P3.UNC_COMBUSTIBLE,P3.UNC_CAPACIDAD,P3.UNC_TRANSMISION,'+CHAR(13)+
									 +'P4.VEH_NOMOTOR,P4.VEH_NOINVENTA,P4.VEH_SITUACION,P4.VEH_FINANCIERA,P4.VEH_NOFACTPLAN,UBICACION=P5.PAR_DESCRIP1,P4.VEH_ORGUNIDAD,'+CHAR(13)+
									 +'COTUN.ucn_colorext,COTUN.ucn_colorint,P8.PAR_DESCRIP1,'+CHAR(13)+
									 +'Vendedor = LTRIM(RTRIM(P9.per_paterno)) + '' ''+ LTRIM(RTRIM(P9.per_materno))+ '' ''+LTRIM(RTRIM(P9.per_nomrazon)), '+CHAR(13)+
									 +'P10.PAR_DESCRIP1,P2.PEN_OBSERVS,P.[PER_EMAIL]'+CHAR(13)+
										+'FROM  cuentasporcobrar.DBO.uni_cotizacionuniversal C '+CHAR(13)+
										+'LEFT JOIN  ControlAplicaciones.DBO.cat_empresas E ON C.ucu_idempresa = E.emp_idempresa '+CHAR(13)+
										+'LEFT JOIN  [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES]  COTUN ON C.ucu_idcotizacion=COTUN.ucu_idcotizacion'+CHAR(13)+ 
										+'LEFT JOIN  ControlAplicaciones.DBO.cat_sucursales S ON C.ucu_idsucursal = S.suc_idsucursal '+CHAR(13)+
										+'LEFT JOIN  ControlAplicaciones.DBO.cat_departamentos D ON C.ucu_iddepartamento = D.dep_iddepartamento '+CHAR(13)+
										+'LEFT JOIN  cuentasporcobrar.DBO.cat_estatuscotiza CC ON C.cec_idestatuscotiza = CC.cec_idestatuscotiza '+CHAR(13)+
										+'LEFT JOIN  [GA_Corporativa].[dbo].[PER_PERSONAS] P ON C.ucu_idcliente = P.per_idpersona '+CHAR(13)+
										+'LEFT JOIN  Centralizacionv2.dbo.DIG_CAT_BASES_BPRO B ON E.emp_idempresa = B.emp_idempresa'+CHAR(13)+
										--+'LEFT JOIN  BDPersonas.DBO.per_direcciones DI ON DI.dir_iddireccion= (SELECT MIN(dir_iddireccion) FROM  BDPersonas.DBO.per_direcciones WHERE per_idpersona=P.per_idpersona)'+CHAR(13)+
										--+'LEFT JOIN  BDPersonas.DBO.per_telefonos TE ON TE.red_idtelefono =(SELECT MIN(red_idtelefono) FROM  BDPersonas.DBO.per_telefonos WHERE per_idpersona=P.per_idpersona)'+CHAR(13)+
										+'LEFT JOIN  ControlAplicaciones.dbo.cat_usuarios U ON C.ucu_idusuarioalta = U.usu_idusuario'+CHAR(13)+
										+'LEFT JOIN '+@baseLocal+'uni_pedido P1 ON C.ucu_idpedidobpro = P1.upe_idpedi'+CHAR(13)+
										+'LEFT JOIN '+@baseLocal+'uni_pediuni P2 ON  COTUN.ucn_noserie = P2.PEN_NUMSERIE   AND P2.PEN_IDPEDI =  C.ucu_idpedidobpro'+CHAR(13)+
										+'LEFT JOIN '+@baseConcentra+'uni_catalogo P3 ON COTUN.ucn_idcatalogo = P3.UNC_IDCATALOGO AND COTUN.ucn_modelo = P3.UNC_MODELO '+CHAR(13)+
										+'LEFT JOIN '+@baseLocal+'ser_vehiculo P4 ON COTUN.ucn_noserie = P4.VEH_NUMSERIE '+CHAR(13)+
										+'LEFT JOIN '+@baseLocal+'PNC_PARAMETR P5 ON P4.VEH_UBICACION = P5.PAR_IDENPARA'+CHAR(13)+
										+'LEFT JOIN '+@baseLocal+'PNC_PARAMETR P8 ON P2.PEN_VENTA = P8.PAR_IDENPARA '+CHAR(13)+
										+'LEFT JOIN   [GA_Corporativa].[dbo].[PER_PERSONAS] P9 ON P1.UPE_IDAGTE = P9.per_idpersona'+CHAR(13)+
										+'LEFT JOIN '+@baseLocal+'PNC_PARAMETR P10 ON P3.UNC_MARCA = P10.PAR_IDENPARA '+CHAR(13)+
										--+'LEFT JOIN  BDPersonas.DBO.per_correos P11 ON P.per_idpersona = P11.per_idpersona  AND P11.cor_idcorreo=(SELECT MIN(cor_idcorreo) FROM  BDPersonas.DBO.per_correos  WHERE per_idpersona= P.per_idpersona)'+CHAR(13)+
										+'WHERE  C.ucu_foliocotizacion= '''+ @folio +'''  AND COTUN.ucu_idcotizacion= '''+ @idCot +''' AND COTUN.ucn_noserie = '''+ @numeroSerie +''' AND B.tipo = 2 AND C.ucu_idpedidobpro IS NOT NULL '+CHAR(13)+
										+'AND P5.PAR_TIPOPARA = ''UBI'' AND P8.PAR_TIPOPARA = ''VNT'' AND P10.PAR_TIPOPARA = ''MCAV'''

		--print(@ConsultaPedidosUnidades)
		EXECUTE (@ConsultaPedidosUnidades)
		
END

go

