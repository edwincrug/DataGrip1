-- =============================================
-- Author:		Mario Arturo Mejía Ramírez
-- Create date: 15/12/2015
-- Description:	Procedimiento para insertar Usuario Mancomunado.
--exec INS_ESCALAMIENTO_PARAM_SP 2,1,2,7,40,4,0

-- =============================================
CREATE PROCEDURE [dbo].[INS_ESCALAMIENTO_PARAM_SP]
	 @proc_Id	int
	,@nodo_Id	int
	,@emp_idempresa int
	,@suc_idsucursal int
	,@dep_iddepartamento int
	,@tipo_idtipoorden int
    ,@usuario_mancomunado int
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
			INSERT INTO [dbo].[DIG_ESCALAMIENTO_PARAMETROS]
					   ([Proc_Id]
					   ,[Nodo_Id]
					   ,[emp_idempresa]
					   ,[suc_idsucursal]
					   ,[dep_iddepartamento]
					   ,[tipo_idtipoorden]
					   ,[usuario_mancomunado])
				 VALUES
					   ( @proc_Id	
						,@nodo_Id	
						,@emp_idempresa 
						,@suc_idsucursal 
						,@dep_iddepartamento 
						,@tipo_idtipoorden 	
						,@usuario_mancomunado)

				SELECT @@IDENTITY
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[INS_ESCALAMIENTO_PARAM_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

