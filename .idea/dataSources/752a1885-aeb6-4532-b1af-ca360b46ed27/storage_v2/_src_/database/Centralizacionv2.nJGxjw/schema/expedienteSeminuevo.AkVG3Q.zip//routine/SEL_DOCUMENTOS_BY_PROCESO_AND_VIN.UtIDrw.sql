-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <SP que regresa los documentos>
-- Description:	<Description,,>
--TEST [expedienteSeminuevo].[SEL_DOCUMENTOS_BY_PROCESO_AND_VIN] '1C4RJEBG4JC153427', 9, 24, 1, 30, 2996
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_DOCUMENTOS_BY_PROCESO_AND_VIN]
	@vin VARCHAR(50),
	@idEmpresa INT,
	@idSucursal INT,
	@idProceso INT,
	@idPerfil INT,
	@idUsuario INT
AS
BEGIN

	DECLARE @idExpediente INT = 0;
	DECLARE @bd VARCHAR(MAX);
	DECLARE @queryDinamicoSeminuevos NVARCHAR(MAX);
	DECLARE @queryDinamicoExiste NVARCHAR(MAX);
	DECLARE @queryDinamicoExisteSNU NVARCHAR(MAX);
	DECLARE @ubi nvarchar (max);
	DECLARE @seminuevos INT
	DECLARE @queryFisicaMoral NVARCHAR(MAX) = '', @idCliente INT, @fisicaMoral VARCHAR(5);
	DECLARE @rfc_empresa VARCHAR(20);

	DECLARE @complementoQuery VARCHAR(MAX)
    IF (@idProceso = 1)
        BEGIN
            SET @complementoQuery= ''''
        END
    ELSE IF (@idProceso = 2)
        BEGIN
            SET @complementoQuery = ''' AND VEH_SITUACION LIKE ''%SVEN%'''
        END

	SELECT @bd = nombre_base
	FROM DIG_CAT_BASES_BPRO 
		WHERE emp_idEmpresa = @idEmpresa
		AND suc_idSucursal = @idSucursal

	SELECT @rfc_empresa = rfc
	FROM DIG_CAT_BASES_BPRO 
	WHERE emp_idEmpresa = @idEmpresa
	AND tipo = 2

    IF NOT EXISTS(SELECT usu_idusuario FROM controlAplicaciones..ope_organigrama 
            WHERE usu_idUsuario = @idUsuario
                AND emp_idempresa = @idEmpresa
                AND suc_idsucursal = @idSucursal)
        BEGIN
			SELECT success = 0
            SELECT msg = 'El usuario no tiene acceso a la empresa y/o sucursal indicada.'
            RETURN
        END

	BEGIN TRY
		IF NOT EXISTS(SELECT id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
				AND exp_empresa = @idEmpresa 
				AND exp_sucursal = @idSucursal)
			BEGIN
				SET @queryDinamicoSeminuevos = 'SELECT @C = COUNT(*) FROM ' + @bd + '.DBO.SER_VEHICULO WHERE VEH_NUMSERIE = ''' + @vin + @complementoQuery
				PRINT(@queryDinamicoSeminuevos)
				
				EXEC sp_executesql @queryDinamicoSeminuevos, N'@C INT OUTPUT', @C=@seminuevos OUTPUT
				PRINT(@seminuevos)

				IF (@seminuevos > 0)
					BEGIN
						IF EXISTS (SELECT bitra_vinTransferido FROM expedienteSeminuevo.bitacoraTransferencias WHERE bitra_vinTransferido = @vin AND bitra_empEnvia = @idEmpresa AND bitra_sucEnvia = @idSucursal)
							BEGIN
								DECLARE @empresaTransferida VARCHAR(100);
								SELECT 
									@empresaTransferida = BD.nombre_sucursal
								FROM expedienteSeminuevo.bitacoraTransferencias  BT
								INNER JOIN DIG_CAT_BASES_BPRO BD ON BD.emp_idEmpresa = bitra_empRecibe AND BD.suc_idSucursal = BT.bitra_sucRecibe
								WHERE bitra_vinTransferido = @vin AND bitra_empEnvia = @idEmpresa AND bitra_sucEnvia = @idSucursal

								SELECT success = 0
								SELECT msg = 'La unidad con el VIN "' + @vin + '" fue transferida, el expediente ahora existe en la empresa ' + @empresaTransferida;
								RETURN
							END
						ELSE
							BEGIN
								INSERT INTO [expedienteSeminuevo].[expedientes] ([exp_vin], [exp_empresa], [exp_sucursal], [exp_fechaCreacion])
								VALUES (@vin, @idEmpresa, @idSucursal, GETDATE())
							END
					END
				ELSE
					BEGIN
						SELECT success = 0
						SELECT msg = 'No se encontró registro del VIN en la empresa y/o sucursal indicada.'
						RETURN
					END
			END
		
		SELECT @idExpediente = id_expediente 
			FROM [expedienteSeminuevo].[expedientes] 
			WHERE exp_vin = @vin 
				AND exp_empresa = @idEmpresa 
				AND exp_sucursal = @idSucursal
		
		
	IF ( @idProceso = 1 )
		BEGIN
			SET @queryFisicaMoral = 'SELECT 
								@clienteId = OC.oce_idproveedor 
							FROM ' + @bd + '.DBO.SER_VEHICULO SV
							INNER JOIN cuentasxpagar.[dbo].[cxp_detalleseminuevos] DS ON DS.asn_numeroserie =  SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
							INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] OC ON OC.oce_folioOrden = DS.oce_folioorden
							WHERE OC.sod_idsituacionorden <> 4 AND VEH_NUMSERIE = ''' + @vin + @complementoQuery

			EXEC sp_executesql @queryFisicaMoral, N'@clienteId INT OUTPUT', @clienteId = @idCliente OUTPUT
		END
	ELSE
		BEGIN
			SELECT 
				@idCliente = ucu_idcliente
			FROM cuentasporcobrar.[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] CD
			INNER JOIN cuentasporcobrar.[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_idCotizacion = CD.ucu_idCotizacion
			WHERE CD.ucn_noserie = @vin AND cec_idestatuscotiza <> 14 AND ucu_tipocotizacion = 'SN' AND ucu_idEmpresa = @idEmpresa AND ucu_idSucursal = @idSucursal
		END

        IF (@idCliente IS NULL)
            BEGIN
                SELECT success = 0
                SELECT msg = 'No se encontró registro del VIN en la empresa y/o sucursal indicada.'
                RETURN
            END
	
		SELECT @fisicaMoral = PER_TIPO FROM GA_corporativa.DBO.PER_PERSONAS WHERE PER_IDPERSONA = @idCliente
		--TEST [expedienteSeminuevo].[SEL_DOCUMENTOS_BY_PROCESO_AND_VIN] 'JM1BM1K31F1244253', 4, 6, 1, 139, 71
		DECLARE @rutaSave VARCHAR(500), @rutaGet VARCHAR(500);

		SELECT @rutaSave = par_valor FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'SAVE_IMG' 
		SELECT @rutaGet = par_valor FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'GET_IMG'
		 
		SELECT success = 1;
		SELECT 
			@idExpediente AS idExpediente,
			@rutaSave AS rutaSave,
			CASE 
				WHEN @idProceso = 1 AND B.id_documento  IN (select doc_idDocumento from [expedienteSeminuevo].[documentosVarios]) /* proceso 1 con documentos multiples */
				THEN  
				@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXP' + '/' + DV.var_carpetaSave

				WHEN @idProceso = 1  
				THEN 
				@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXP' + '/' + B.nombreDocumento 

			ELSE 
			    CASE
					WHEN @idProceso = 2 AND B.id_documento  IN (select doc_idDocumento from [expedienteSeminuevo].[documentosVarios])  /* proceso 2 con documentos multiples */
					THEN 
					@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXC' + '/' + DV.var_carpetaSave
					ELSE 
					@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXC' + '/' + B.nombreDocumento 
				END
			END AS rutaGet,
			CASE WHEN @idProceso = 1 THEN 'CXP' ELSE 'CXC' END AS proceso,
			ISNULL(DV.var_carpetaSave, '') AS carpetaVarios,
			A.doc_varios,
			A.id_documento,
			A.doc_nombre,
			A.doc_extencion,
			CASE WHEN A.doc_opcional = 0 THEN 'Obligatorio' 
			ELSE  'Opcional'  
			END AS doctoOpcional,
			A.doc_opcional,
			A.doc_usuarios,
			CASE WHEN ISNULL(B.id_documentoGuardado, 0) > 0 THEN 1 ELSE 0 END AS existe,
			B.nombreDocumento AS nombreActual,
			B.id_documentoGuardado,
			B.id_expediente,
			B.id_proceso,
			B.id_estatus,
			B.est_descripcion,
			B.observacionesDocumento,
			A.doc_nombreCorto
		FROM ( 
			SELECT 
				id_documento, 
				doc_nombre, 
				doc_extencion, 
				doc_opcional,
				doc_usuarios, 
				doc_proceso,
				doc_varios,
				doc_nombreCorto
			FROM [expedienteSeminuevo].[cat_documentos] 
			WHERE doc_proceso = @idProceso AND ((@fisicaMoral = 'MOR' AND doc_moral = 1) OR (@fisicaMoral = 'FIS' AND doc_fisica = 1) OR (@fisicaMoral = 'FIE' AND doc_fisicaAE = 1))) AS A
		LEFT JOIN ( 
			SELECT
				max(DE.id_documentoGuardado) as id_documentoGuardado, 
				DE.id_expediente, 
				DE.id_proceso, 
				MAX(DE.id_estatus) AS id_estatus,
				MAX(ED.est_descripcion) AS est_descripcion, 
				MAX(DE.observacionesDocumento) observacionesDocumento, 
				--max(id_documento) as idDoc,
				DE.id_documento,
				max (nombreDocumento) as nombreDocumento
			FROM [Centralizacionv2].[expedienteSeminuevo].[documentosExpediente] DE
			INNER JOIN [expedienteSeminuevo].[estatusDocumentos] ED ON DE.id_estatus = ED.id_estatus 
			WHERE id_expediente = @idExpediente 
			group by DE.id_expediente, DE.id_proceso, DE.id_documento ) AS B ON B.id_documento = A.id_documento AND B.id_proceso = A.doc_proceso
		INNER JOIN [expedienteSeminuevo].[documentoPerfil] DP ON DP.id_perfil = @idPerfil AND DP.id_documento = A.id_documento AND DP.id_proceso = A.doc_proceso
		LEFT JOIN [expedienteSeminuevo].[documentosVarios] DV ON DV.doc_idDocumento = A.id_documento

		SET @queryDinamicoExiste ='SELECT @ubii = P.PAR_DESCRIP1  FROM ' + @bd + '.DBO.SER_VEHICULO S 
		INNER JOIN ' + @bd + '.[dbo].[PNC_PARAMETR] P ON S.VEH_UBICACION = P.PAR_IDENPARA
		WHERE  par_tipopara = '+'''UBI'''+' AND P.PAR_STATUS='+'''A'' AND VEH_NUMSERIE = ''' + @vin + @complementoQuery 
		EXEC sp_executesql @queryDinamicoExiste, N'@ubii nvarchar OUTPUT', @ubii=@ubi OUTPUT
	

		--TEST [expedienteSeminuevo].[SEL_DOCUMENTOS_BY_PROCESO_AND_VIN] 'JM1BM1K31F1244253', 4, 6, 2, 139, 71
   --     BEGIN
			--set @queryDinamicoExisteSNU = 'SELECT VEH_SMARCA, VEH_TIPOAUTO, VEH_ANMODELO, VEH_NUMSERIE, ''No Se Encontro la Ubicacion'' as ubicacion FROM ' + @bd + '.DBO.SER_VEHICULO WHERE VEH_NUMSERIE = ''' + @vin + @complementoQuery
			-- EXEC sp_executesql @queryDinamicoExisteSNU
			-- print @queryDinamicoExisteSNU
   --         RETURN
   --     END

		SET @queryDinamicoSeminuevos = 'SELECT VEH_SMARCA, VEH_TIPOAUTO, VEH_ANMODELO, VEH_NUMSERIE'

		IF (@ubi IS NULL)
			BEGIN
				SET @queryDinamicoSeminuevos += ',''No se encontreo la ubicacion''AS ubicacion'
			END
		ELSE
			BEGIN
				SET @queryDinamicoSeminuevos += ',P.PAR_DESCRIP1 AS ubicacion'
			END

		SET @queryDinamicoSeminuevos += ',PER_RFC AS rfc_cliente
		,'''+ @rfc_empresa +''' AS rfc_empresa' 

		if(@idProceso = 1)
		begin
			set @queryDinamicoSeminuevos +=',ISNULL(DT.oce_folioorden,S.veh_folioorden)  AS folioOrden,'''' AS docto '
		end
		else
		begin
			set @queryDinamicoSeminuevos +=',''''  AS folioOrden 
											,(SELECT dbo.[fn_BuscaLetras](VTF.VTE_DOCTO)) AS serie
											,(SELECT dbo.[fn_BuscaNumeros](VTF.VTE_DOCTO)) AS folio
											,(SELECT dbo.[fn_BuscaLetras](VTF.VTE_DOCTO)) +''''+ (SELECT dbo.[fn_BuscaNumeros](VTF.VTE_DOCTO)) AS docto  '
		end
		
		set @queryDinamicoSeminuevos +='
		FROM ' + @bd + '.DBO.SER_VEHICULO S 
		INNER JOIN ' + @bd + '.[dbo].[PNC_PARAMETR] P ON S.VEH_UBICACION = P.PAR_IDENPARA
		LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DT ON VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS = DT.asn_numeroserie
		INNER JOIN GA_Corporativa.DBO.PER_PERSONAS PER ON VEH_IDCLIENT = PER.PER_IDPERSONA
		LEFT  JOIN ' + @bd + '.[dbo].[ADE_VTAFI] VTF ON VEH_NUMSERIE  = VTE_SERIE
		WHERE  par_tipopara = '+'''UBI'''+' AND P.PAR_STATUS='+'''A'' AND VEH_NUMSERIE = ''' + @vin + @complementoQuery 
		set @queryDinamicoSeminuevos +=' group by S.veh_folioorden,VEH_SMARCA, VEH_TIPOAUTO, VEH_ANMODELO, VEH_NUMSERIE,P.PAR_DESCRIP1,DT.oce_folioorden,PER_RFC'

		if(@idProceso = 2)
		begin
			set @queryDinamicoSeminuevos +=',VTF.VTE_DOCTO'
		end
		
		PRINT @queryDinamicoSeminuevos


        EXEC sp_executesql @queryDinamicoSeminuevos

		
    END TRY

	BEGIN CATCH
		PRINT (ERROR_MESSAGE())
		SELECT success = 0
		SELECT msg = 'Error al regresar los datos del expediente.';
	END CATCH
END

go

