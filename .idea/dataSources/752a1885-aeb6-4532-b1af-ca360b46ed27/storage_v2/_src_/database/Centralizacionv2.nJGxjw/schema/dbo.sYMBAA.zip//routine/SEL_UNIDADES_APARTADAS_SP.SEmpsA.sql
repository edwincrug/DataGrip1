-- ================================================
-- Create date: 20/07/2017
-- Description:	Obtiene si la unidad esta en estatus apartado 
-- =============================================
--[dbo].[SEL_UNIDADES_APARTADAS_SP]  'AU-AU-PED-UN-5'
CREATE PROCEDURE [dbo].[SEL_UNIDADES_APARTADAS_SP] 
	@folio NVARCHAR(50)
AS
BEGIN
	DECLARE @existeNotificacion INT 
	
	SET @existeNotificacion=(SELECT COUNT(not_identificador) FROM Notificacion..NOT_NOTIFICACION WHERE not_agrupacion = 11 AND not_estatus = 2 AND not_identificador = @folio)
	IF(@existeNotificacion = 0)
		BEGIN
			DECLARE @ipServidor NVARCHAR(50)
				,@nombreBase NVARCHAR(50)
				,@idEmpresa INT
				,@idSucursal INT
				,@valor NVARCHAR(10)
				,@idGerenteVentas INT
		

			SELECT	@idEmpresa = CU.ucu_idempresa
					,@idSucursal = CU.ucu_idsucursal
			FROM	cuentasporcobrar..uni_cotizacionuniversal CU
					INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] BBPRO ON BBPRO.suc_idsucursal = CU.ucu_idsucursal AND BBPRO.emp_idempresa = CU.ucu_idempresa
			WHERE	ucu_foliocotizacion = @folio 
					AND BBPRO.tipo = 1
					AND BBPRO.estatus = 1
			SET @nombreBase = [dbo].[base_Cotizacion](@folio)
			print @ipServidor
			print @nombreBase

			print CONVERT(NVARCHAR(5),@idEmpresa) + '|' + CONVERT(NVARCHAR(5),@idSucursal)
			SET @valor = CONVERT(NVARCHAR(5),@idEmpresa) + '|' + CONVERT(NVARCHAR(5),@idSucursal)
			SELECT @idGerenteVentas = cat_valor FROM Centralizacionv2..DIG_CATALOGOS WHERE cat_id_padre=150 and cat_nombre = @valor and cat_estatus=1

			declare @queryText varchar(max) =	'SELECT	sv.VEH_NUMSERIE as numeroSerie,    sv.VEH_SITUACION  as situacion' + char(13) + 
												',' + CONVERT(NVARCHAR(10),@idGerenteVentas) + 'as idGerenteVentas' + char(13) + 
												'FROM	[cuentasporcobrar].[dbo].[uni_cotizacionuniversal] cu, [cuentasporcobrar].[dbo].[uni_cotizacionuniversalunidades] cuu,' + char(13) + 
												'		'+@nombreBase+'[SER_VEHICULO] sv' + char(13) + 
												'where cu.ucu_idcotizacion=cuu.ucu_idcotizacion' + char(13) + 
												'and cuu.ucn_noserie=sv.VEH_NUMSERIE' + char(13) + 
												'and cu.ucu_foliocotizacion = '+char(39)+''+@folio+''+char(39)+'' + char(13) + 
												'and cu.cec_idestatuscotiza IN (1,17)' + char(13) +
												'and sv.VEH_SITUACION = ''PED''' 
			print 	@queryText
			 exec(@queryText)
		END
	ELSE
	BEGIN
		SELECT '' as numeroSerie, '' as situacion, -1 as idGerenteVentas
	END
	
	--SELECT '' as numeroSerie, '' as situacion, 0 as idGerenteVentas
END
go

