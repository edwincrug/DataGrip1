CREATE PROCEDURE [dbo].[UPD_CORREOS_ALTERNATIVOS_SP] --3,'prueba2@correo.com', 2
@idUsuarioCorreo INT,
@correo NVARCHAR(50),
@idTipoCorreo INT

AS
BEGIN
	UPDATE UsuarioCorreo
	SET	correo = @correo,
		idTipoCorreo = @idTipoCorreo
	WHERE idUsuarioCorreo=@idUsuarioCorreo

	SELECT @correo  Mensaje
END
go

