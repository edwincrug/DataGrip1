CREATE PROCEDURE [dbo].[PPRO_SELDATOSFACTURAS]
@uuid VARCHAR(50) = ''
,@folio VARCHAR(50) = ''
/*,
@rfc_emisor VARCHAR(15) = '',
@rfc_receptor VARCHAR(15) = '',
@serie VARCHAR(5) = '',
@folio VARCHAR(30) = '',
@importe MONEY = NULL,

@fecha_factura DATETIME = NULL,
@usuario_carga VARCHAR(15) = ''*/
AS

--sp_help PPRO_DATOSFACTURAS

---PPRO_SELDATOSFACTURAS '062DCBC5-0FE5-4A0C-A3F2-71A6385B7F59'

DECLARE @contadorUUID INT 
DECLARE @tUID TABLE (id_facturas int)

SELECT	@contadorUUID = COUNT(id_facturas) 
FROM	dbo.PPRO_DATOSFACTURAS AS F  
		INNER JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC ON OC.oce_folioorden = F.folioorden
WHERE	uuid = @uuid AND OC.sod_idsituacionorden NOT IN (3,4)

IF(@contadorUUID = 1)
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM	dbo.PPRO_DATOSFACTURAS WHERE uuid = @uuid AND folioorden = @folio)
			BEGIN		
				INSERT INTO @tUID
				SELECT id_facturas FROM dbo.PPRO_DATOSFACTURAS WHERE uuid = @uuid
			END
	END
ELSE
	BEGIN
		INSERT INTO @tUID
		SELECT id_facturas FROM dbo.PPRO_DATOSFACTURAS WHERE uuid = @uuid
	END
SELECT id_facturas FROM @tUID
go

