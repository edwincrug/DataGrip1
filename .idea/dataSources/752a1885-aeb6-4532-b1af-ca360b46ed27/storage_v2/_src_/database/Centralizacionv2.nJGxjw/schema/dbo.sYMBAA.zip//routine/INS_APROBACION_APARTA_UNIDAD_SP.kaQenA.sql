-- =============================================
-- Author:		LQMA
-- Create date: 06072017
-- Description:	Inserta notificación para apartar una unidad, desde CXC, en el NODO 1
-- =============================================
--EXECUTE [dbo].[INS_APROBACION_APARTA_UNIDAD_SP] 'AU-ZM-ZAR-UN-29','Aqui va la descripción',2,15
CREATE PROCEDURE[dbo].[INS_APROBACION_APARTA_UNIDAD_SP]
	 --@idtipoproceso int
	  @numeroSerie VARCHAR(50) = ''
	 ,@identificador VARCHAR(50) = ''
	--,@descripcion varchar(500)
	--,@estatus int
	--,@linkBPRO varchar(MAX) = NULL
	--,@adjunto varchar(MAX) = NULL 
	--,@idtipoadjunto	varchar(500)
	,@solicitante NUMERIC(18,0) = 0 
	--,@aprobador	numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;
	-- Inserta una notificación de tipo aprobación
		--LQMA 05070217
		
		DECLARE @estatusResp INT = 0, @msg VARCHAR(100) = 'La Solicitud para desapartar la unidad ' + @numeroSerie + ' se ha realizado con exito!.'
		DECLARE @empresa INT = 0, @sucursal INT = 0

		SELECT @empresa = ucu_idempresa, @sucursal = ucu_idsucursal FROM cuentasporcobrar..uni_cotizacionuniversal WHERE ucu_foliocotizacion = @identificador

		INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	    VALUES (7,'INS_APROBACION_APARTA_UNIDAD_SP inicio --- @@solicitante:' + CONVERT(VARCHAR(5),@solicitante) ,GETDATE())

		BEGIN TRAN TRAN_APROBACION_APARTA_UNIDAD

	BEGIN TRY

		DECLARE @aprobador NUMERIC(18,0) = 0, @descripcion VARCHAR(500) = 'Solicitud de desapartado de unidad ' + @numeroSerie
		
		SELECT @aprobador = cat_valor 
		FROM [Centralizacionv2].[dbo].[DIG_CATALOGOS] 
		WHERE cat_nombre= CONVERT(varchar(5),@empresa)+'|'+CONVERT(varchar(5),@sucursal) AND cat_id_padre=87 and cat_estatus=1
		
		INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	    VALUES (7,'INS_APROBACION_APARTA_UNIDAD_SP @aprobador:' + CONVERT(VARCHAR(5),@aprobador) ,GETDATE())

		INSERT INTO Notificacion..NOT_NOTIFICACION (not_tipo
		, not_tipo_proceso
		, not_identificador
		, not_nodo
		, not_descripcion
		, not_estatus
		, not_fecha
		, not_link_BPRO
		, not_adjunto
		, not_adjunto_tipo
		, not_agrupacion
		, idEmpresa
		, idSucursal)
		VALUES
		( 1
		, 11
		, @identificador
		,''
		, @descripcion 
		, 2--@estatus
		, GETDATE()
		, null--@linkBPRO
		, ''--@adjunto
		, ''--@idtipoadjunto
		, 11
		, @empresa
		, @sucursal)


	DECLARE @nid_not int = @@IDENTITY;

--Solicitante
--LQMA  add 17062016   si aprobador = solicitante, solo se inserta aprobador
----------------------------------
IF(@aprobador != @solicitante) --si aprobador es diferente de solicitante, se inserta solicitante
	BEGIN
		INSERT INTO Notificacion..[NOT_APROBACION]
			   ([not_id]
			   ,[apr_nivel]
			   ,[apr_visto]
			   ,[emp_id]
			   ,[apr_fecha]
			   ,[apr_estatus]
			   ,[apr_escalado])
		 VALUES
			   (@nid_not
			   ,0
			   ,NULL
			   ,@solicitante
			   ,GETDATE()
			   ,2
			   ,-1)
	END
		   
--Aprobador
----------------------------------
	INSERT INTO Notificacion..[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
           ,[apr_escalado])
     VALUES
           (@nid_not
		   ,0
		   ,NULL
           ,@aprobador
           ,GETDATE()
           ,2
           ,0)	

--Actualiza el estatus de la notificación a 2
----------------------------------
	--UPDATE NOT_NOTIFICACION SET not_estatus = 2 WHERE not_id =@nid_not
	
	--LQMA 03072017
	--UPDATE NOT_APROBACION SET apr_estatus = 2 WHERE not_id = @nid_not
	
	--LQMA 05070217
	COMMIT TRAN TRAN_APROBACION_APARTA_UNIDAD		
	SELECT @estatusResp estatus,@msg mensaje
	
END TRY
BEGIN CATCH
	
	ROLLBACK TRAN TRAN_APROBACION_APARTA_UNIDAD

	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_APROBACION_APARTA_UNIDAD_SP'
	SELECT @estatusResp = ERROR_NUMBER()
	SELECT @Mensaje = ERROR_MESSAGE()
	
	DECLARE @tablaRespuesta TABLE(idError INT)
	INSERT INTO @tablaRespuesta
	EXECUTE INS_ERROR_SP @Componente, @Mensaje
					
	SELECT @estatusResp estatus,@Mensaje mensaje

END CATCH
END
go

