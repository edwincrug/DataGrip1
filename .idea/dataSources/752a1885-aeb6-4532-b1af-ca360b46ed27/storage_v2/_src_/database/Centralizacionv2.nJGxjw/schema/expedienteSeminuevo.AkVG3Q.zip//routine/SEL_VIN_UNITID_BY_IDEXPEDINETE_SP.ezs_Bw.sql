-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST [expedienteSeminuevo].[SEL_VIN_UNITID_BY_IDEXPEDINETE_SP] 30
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_VIN_UNITID_BY_IDEXPEDINETE_SP]
	@idExpediente INT
AS
BEGIN
	SET NOCOUNT ON;
	SELECT 
		E.exp_vin AS vin,
		I.code AS unitId
	FROM [expedienteSeminuevo].[expedientes] E
	INNER JOIN [Intelimotors].[dbo].[SucursalIntelimotors] I ON E.exp_empresa = I.idEmpresa AND E.exp_sucursal = I.idSucursal
	WHERE id_expediente = @idExpediente
END
go

