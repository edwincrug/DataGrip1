-- =============================================
-- Author:		LQMA
-- Create date: 10042017
-- Description:	Inserta una solicitud de cancelacion al usuario que aprobo, se manda a llamar desde centralizacion en nodo 4
-- =============================================
CREATE PROCEDURE [dbo].[INS_SOLICITUD_CANCELACION_SP]
	 @solicitante DECIMAL(18,0) = 0,
	 @folio VARCHAR(50) = ''
AS
BEGIN

		DECLARE @estatusResp INT = 0, @msg VARCHAR(100) = 'Solicitud de Cancelación realizada con exito.'

		IF EXISTS (SELECT 1 FROM Notificacion..NOT_NOTIFICACION WHERE not_identificador = @folio AND not_agrupacion = 9)
			BEGIN
				SELECT @msg = 'La Orden de compra ya tiene una solicitud de cancelación.' 
			END
		ELSE
			BEGIN
			
				DECLARE @aprobador DECIMAL(18,0) = 0

				SELECT TOP 1  @aprobador = mov_idusuariomovimiento FROM cuentasxpagar..cxp_movimientosorden 
				WHERE oce_folioorden = @folio AND sod_idsituacionorden = 2		
		
						INSERT INTO Notificacion..NOT_NOTIFICACION (not_tipo
							, not_tipo_proceso
							, not_identificador
							, not_nodo
							, not_descripcion
							, not_estatus
							, not_fecha
							--, not_link_BPRO
							--, not_adjunto
							--, not_adjunto_tipo
							, not_agrupacion)
							VALUES
							( 1
							, 1
							, @folio--@identificador
							, 0--@idnodo
							, 'Solicitud de Cancelación para el folio: ' + @folio
							, 2--@estatus
							, GETDATE()
							--, @linkBPRO
							--, @adjunto
							--, @idtipoadjunto
							, 9 --Solicitud de Cancelación
							)

						DECLARE @nid_not int = @@IDENTITY;

						IF(@aprobador != @solicitante) --si aprobador es diferente de solicitante, se inserta solicitante
						BEGIN
							INSERT INTO Notificacion..NOT_APROBACION
										([not_id]
										,[apr_nivel]
										,[apr_visto]
										,[emp_id]
										,[apr_fecha]
										,[apr_estatus]				
										,[apr_escalado])
							 VALUES
								   (@nid_not
								   ,0
								   ,NULL
								   ,@solicitante
								   ,GETDATE()
								   ,1
								   ,-1)
						END       
           
					--Aprobador
					----------------------------------
						INSERT INTO Notificacion..NOT_APROBACION
							   ([not_id]
							   ,[apr_nivel]
							   ,[apr_visto]
							   ,[emp_id]
							   ,[apr_fecha]
							   ,[apr_estatus]
							   ,[apr_escalado])
						 VALUES
							   (@nid_not
							   ,0
							   ,NULL
							   ,@aprobador
							   ,GETDATE()
							   ,1
							   ,0)	

			END

		SELECT @estatusResp estatus,@msg mensaje

END
go

