-- ==========================================================================================
-- Author:  Aldo Ortiz Palma   
-- Create date: 12/03/2020
-- Description: Seleccionar facturas por VIN.
-- ==========================================================================================
-- EXECUTE [dbo].[SEL_FACTURAS_VIN_SP] 'AU-ZM-NZA-UN-6294'
CREATE PROCEDURE [dbo].[SEL_FACTURAS_VIN_SP] 
    @cotizacion VARCHAR(MAX)
AS
BEGIN
    DECLARE @baseDeDatos VARCHAR(MAX), @idEmpresa INT, @idsucursal INT, @rfcEmisor VARCHAR(50)
    DECLARE @query NVARCHAR(MAX)

	SELECT 
		@idEmpresa = ucu_idempresa,
		@idsucursal = ucu_idSucursal
	FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE ucu_foliocotizacion = @cotizacion

	SELECT 
		@baseDeDatos = [nombre_base]
	FROM [DIG_CAT_BASES_BPRO] 
	WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idsucursal

	SELECT
		@rfcEmisor = rfc
	FROM [DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND tipo = 2
    
    SET @query = 'SELECT' + CHAR(13) +
					CHAR(9) + 'SUBSTRING(V.VTE_DOCTO, 1, 2) AS serie,'  + CHAR(13) +
					CHAR(9) + 'SUBSTRING(V.VTE_DOCTO, 3, LEN(V.VTE_DOCTO) - 1) AS folio,'  + CHAR(13) +
					CHAR(9) + 'P.PER_RFC AS rfcReceptor,'  + CHAR(13) +
					CHAR(9) + '''' +  @rfcEmisor + '''' + ' AS rfcEmisor'  + CHAR(13) +
				 'FROM ' + QUOTENAME(@baseDeDatos) + '.[DBO].[ADE_VTAFI] V' + CHAR(13) +
				 'INNER JOIN cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES CD ON CD.ucn_noserie = V.VTE_SERIE' + CHAR(13) +
				 'INNER JOIN cuentasporcobrar..uni_cotizacionuniversal C ON C.ucu_idcotizacion = CD.ucu_idcotizacion' + CHAR(13) +
				 'INNER JOIN Ga_Corporativa.DBO.PER_PERSONAS P ON P.PER_IDPERSONA = C.ucu_idCliente' + CHAR(13) +
				 'WHERE C.ucu_foliocotizacion = ''' + @cotizacion + '''';



    EXECUTE sp_executesql @query
END
go

