CREATE PROCEDURE [dbo].[PROV_INS_PROSPECTO_SP] --'Hola nundo','AAA01010192','nikkosteel@gmail.com','1234567'    
@razonSocial VARCHAR(max) = '',
@rfc VARCHAR(50),
@correoUsuario VARCHAR(150),
@contrasena VARCHAR(50)

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
	
	

	DECLARE @per_idpersona SMALLINT
	DECLARE @msg VARCHAR(500) = '', @estatus VARCHAR(10) = '', @IdProspecto NUMERIC(18,0)
	DECLARE @passEnc NVARCHAR(500)
	DECLARE @tokenID uniqueidentifier
	DECLARE @cadena VARBINARY(200),  @cadenaEncrypt VARCHAR(200)  

	IF (SELECT LEN (@contrasena))> 10
	BEGIN
	   SET @estatus = 'error'
	   SET @msg ='La contraseña debe ser menor a 10 caracteres'
    END
	ELSE 
	BEGIN
			IF NOT EXISTS(SELECT 1 FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @rfc)
				BEGIN
					IF NOT EXISTS(SELECT 1 FROM PPRO_USERSPORTALPROV WHERE ppro_user = @rfc)
						BEGIN
					 
						SELECT @cadena = EncryptByPassPhrase('4ndr4d3', @contrasena)  

						SET @cadenaEncrypt = (SELECT CONVERT(VARCHAR(MAX), @cadena,1))

								INSERT INTO PPRO_USERSPORTALPROV(
									ppro_idUserRol,
									ppro_user,
									ppro_pass,
									pprov_usersStatus,
									razonSocial,
									correo,
									estatus,
									fechaAlta)
								VALUES (					    											
									1,
									@rfc,
									@cadenaEncrypt,
									2,--pendiente de activar
									@razonSocial,
									@correoUsuario,
									0, 
									GETDATE()
								)

								
								SET @tokenID = NEWID()
					
								INSERT INTO [proveedores].[dbo].[CorreoActivacion]([token],[per_rfc],[fechaCreacion],[fechaActivacion],[idEstatus])
								VALUES (@tokenID,@rfc,GETDATE(),NULL,1)	
								
								INSERT INTO  Centralizacionv2.dbo.PROV_PROSPECTO (TOKEN,PER_RFC,PER_STATUS, fecha_registro, PER_EMAIL) values (@tokenID,@rfc,0,GETDATE(), @correoUsuario)

								SET @IdProspecto = SCOPE_IDENTITY()
								 												

								SELECT @estatus = 'ok', @msg ='Se ha creado el registro con éxito para el usuario con RFC: ' + @rfc 
						END
					ELSE
						BEGIN
								SELECT @estatus = 'error', @msg ='Proveedor con RFC: ' + @rfc + ' ya se ecuentra registrado en el Portal de Proveedores.'
						END
			END
			ELSE
			BEGIN

					IF NOT EXISTS(SELECT 1 FROM PPRO_USERSPORTALPROV WHERE ppro_user = @rfc)
						BEGIN
								SELECT @cadena = EncryptByPassPhrase('4ndr4d3', @contrasena)  

								SET @cadenaEncrypt = (SELECT CONVERT(VARCHAR(MAX), @cadena,1))

								INSERT INTO PPRO_USERSPORTALPROV(
									ppro_idUserRol,
									ppro_user,
									ppro_pass,
									pprov_usersStatus,
									razonSocial,
									correo,
									estatus,
									fechaAlta)
								VALUES (					    											
									1,
									@rfc,
									@cadenaEncrypt,
									2,--pendiente de activar
									@razonSocial,
									@correoUsuario,
									0, 
									GETDATE()
								)

								
								SET @tokenID = NEWID()
					
								INSERT INTO [proveedores].[dbo].[CorreoActivacion]([token],[per_rfc],[fechaCreacion],[fechaActivacion],[idEstatus])
								VALUES (@tokenID,@rfc,GETDATE(),NULL,1)													

								SELECT @estatus = 'okPP', @msg ='Proveedor con RFC: ' + @rfc + ' registrado con exito! Se ha enviado un correo para su activación a la dirección ' + @correoUsuario + '.'
						END
						
						ELSE
						BEGIN
							SELECT @estatus = 'error', @msg ='Proveedor con RFC: ' + @rfc + ' ya se ecuentra registrado en el Portal de Proveedores.'
						END
			--		SELECT @estatus = 'error', @msg ='Proveedor con RFC: ' + @rfc + ' no existe en el catalogo de proveedores. No se registro.'
			END	
   END
   SELECT @estatus estatus,@msg mensaje, @IdProspecto idProspecto,   @correoUsuario correoUsuario
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[PPRO_GUARDADATOS_USER_REGISTRO]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje, 0 idProspecto , '' correoUsuario  --@msg

END CATCH
END
go

