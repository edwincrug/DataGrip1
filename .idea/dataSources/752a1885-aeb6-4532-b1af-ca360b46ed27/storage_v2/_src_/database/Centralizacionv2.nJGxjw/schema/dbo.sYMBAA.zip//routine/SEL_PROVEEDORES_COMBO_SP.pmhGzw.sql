-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 21/10/2015
-- Description:	Procedimiento que selecciona los proveedores a mostrar en combo
--				el parámetro @idsucursal proviene del entorno y limitará las búsquedas
--				por sucursal si el usuario tiene este dato, de lo contrario se buscará
--				el proveedor en la totalidad de la tabla.
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PROVEEDORES_COMBO_SP] 
	@idsucursal int = 0
AS
BEGIN

	SET NOCOUNT ON;
BEGIN TRY
	SELECT PER_IDPERSONA
	, RTRIM(LTRIM(PER_NOMRAZON + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) AS Nombre
	, PER_RFC
	FROM [GA_Corporativa].[dbo].[PER_PERSONAS]
	WHERE (PER_SUCURSAL COLLATE Modern_Spanish_CI_AS  = (SELECT suc_nombre 
						FROM [ControlAplicaciones].[dbo].cat_sucursales
						WHERE suc_idsucursal = @idsucursal) COLLATE Modern_Spanish_CI_AS) 
						 OR (@idsucursal = 0)
	ORDER BY PER_NOMRAZON
END TRY
  BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_PROVEEDORES_COMBO_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

