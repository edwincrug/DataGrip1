-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 10/01/2019
-- Description:	Delete Complemento de Pago
-- ==========================================================================================
-- EXECUTE [dbo].[PPROV_DEL_COMPLEMENTO_PAGO_SP] 11

CREATE PROCEDURE [dbo].[PPROV_DEL_COMPLEMENTO_PAGO_SP]
				 @id_Complemento 		 INT
AS
BEGIN
    SET NOCOUNT ON;	
    BEGIN TRY
	    -----------------------------------------------------------
		-- Borramos el Detalle del Complemento
		-----------------------------------------------------------
	    DELETE
		  FROM [Centralizacionv2].[dbo].[PPRO_COMPLEMENTODET]
		 WHERE [id_Complemento] = @id_Complemento
        PRINT '1)Borro Detalle de Complemento'

		-----------------------------------------------------------
		-- Borramos el Encabezado del Complemento
		-----------------------------------------------------------
	    DELETE
		  FROM [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC]
		 WHERE [id_Complemento] = @id_Complemento
        PRINT '2)Borro Encabezado de Complemento'

		SELECT 'Complemento de Pago Eliminado' as msj

	END TRY
	BEGIN CATCH
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 DECLARE @Mensaje  nvarchar(max),
		 @Componente nvarchar(50) = '[PPROV_DEL_COMPLEMENTO_PAGO_SP]'
		 SELECT @Mensaje = ERROR_MESSAGE()
		 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
		 SELECT 1  --Encontro error
	END CATCH
END
go

