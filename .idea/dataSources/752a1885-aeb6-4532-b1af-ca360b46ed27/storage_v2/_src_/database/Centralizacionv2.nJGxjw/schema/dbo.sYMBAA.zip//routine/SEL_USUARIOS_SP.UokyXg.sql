-- =============================================
-- Author:		Mario Arturo Mejía Ramírez
-- Create date: 21/12/2015
-- Description: Stored que recupera los usuarios
--[SEL_USUARIOS_SP] 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_USUARIOS_SP] 
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
SELECT  usu_idusuario AS idUsuario
		,usu_nombreusu AS nombre
		,usu_paterno AS aPaterno
		,usu_materno AS aMaterno
FROM [dbo].[Usuario_ControlAplicaciones]
	END TRY
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_USUARIOS_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

