-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 06/11/2015
-- Description:	Procedimiento que recupera las sucursales por empresa
-- =============================================
CREATE PROCEDURE [dbo].[SEL_SUCURSALES_CENTRAL_SP]
	@idempresa	int
AS
BEGIN
	SET NOCOUNT ON;
	SELECT    S.suc_idsucursal
		, S.suc_nombre
		, S.suc_nombrecto
	FROM    ControlAplicaciones.dbo.cat_departamentos D INNER JOIN
			ControlAplicaciones.dbo.cat_sucursales S ON D.suc_idsucursal = S.suc_idsucursal
	WHERE	(S.emp_idempresa = @idempresa OR @idempresa = 0)
END


go

