-- ================================================
-- Create date: 04/10/2017
-- Description:	Obtiene permimsos de la tabla de seguridad 
-- =============================================
--EXECUTE [dbo].[SEL_PERMISOS_ACCION_SEGURIDAD_SP] 71,8
CREATE PROCEDURE [dbo].[SEL_PERMISOS_ACCION_SEGURIDAD_SP] 
	@idUsuario int
	,@idAccion int
AS
BEGIN
	--Verifica si el usuario puede cargar el comprobante de pago con el [seg_idAccion] de la tabla de seguridad 8
	IF(@idAccion = 8)
		BEGIN
			IF(EXISTS(SELECT  1 FROM [Seguridad].[dbo].[SEG_CENTRALIZACION] WHERE [seg_idUsuario] = @idUsuario AND [seg_idAccion] = 8 AND [seg_idPortal]=1 AND [seg_idModulo] =2))
				BEGIN
					SELECT  1 AS respuesta
							,'Tiene permisos para subir el archivo' AS  mensaje
				END
			ELSE
				BEGIN
					SELECT  0 AS respuesta
							,'No Tiene permisos para subir el archivo' AS  mensaje
				END
		END
END
go

