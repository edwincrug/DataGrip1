-- =============================================
-- Author:		<Author,,Name>
-- Create date: 07/01/2018
-- Description:	Obtiene el encabezado del resumen de las cotizaciones
-- =============================================
--[dbo].[SEL_ENCABEZADO_RESUMEN_CXC_SP] 'AU-ZM-NZA-UN-1013'
CREATE PROCEDURE [dbo].[SEL_ENCABEZADO_RESUMEN_CXC_SP]
	@folio VARCHAR(100)
AS
BEGIN
	DECLARE	@total INT
	SET @total = (	SELECT COUNT (ucn_noserie) 
					FROM	cuentasporcobrar.dbo.uni_cotizacionuniversal CU
							INNER JOIN cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES CUD ON CU.ucu_idcotizacion = CUD.ucu_idcotizacion 
					WHERE	CU.ucu_foliocotizacion = @folio) 
					PRINT @total
	SELECT	ROW_NUMBER() OVER(ORDER BY CU.ucu_idcotizacion DESC) AS id
			,CU.ucu_idcotizacion
			,ucu_foliocotizacion
			,ucu_idcliente
			,ucu_fechacotiza
			,ucn_noserie AS numeroSerie
			,@total AS numeroUnidades	
			,ucn_idFactura AS factura
			,ucn_modelo AS modelo
			,ucn_idcotizadetalle AS idDetalleCotizacion	
	FROM	cuentasporcobrar.dbo.uni_cotizacionuniversal CU
			inner join cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES CUD ON CU.ucu_idcotizacion = CUD.ucu_idcotizacion 
	WHERE	CU.ucu_foliocotizacion = @folio
END
;

go

