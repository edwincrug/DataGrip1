--[dbo].[SEL_COTIZACIONES_SP] 'AU-AU-UNI-UN-2154'
CREATE PROCEDURE [dbo].[SEL_COTIZACIONES_SP]
	@folio VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT 	C.ucu_foliocotizacion
			, C.ucu_idcotizacion
			, E.emp_nombre
			, S.suc_nombre
			, D.dep_nombre
			, B.rfc
			,CONVERT(VARCHAR(50),C.ucu_fechacotiza,103) AS fecha
			,CC.cec_descripcion
			, C.ucu_idcliente
			, NombreCliente = LTRIM(RTRIM(P.per_paterno)) + ' ' + LTRIM(RTRIM(P.per_materno)) + ' ' + LTRIM(RTRIM(P.per_nomrazon))
			, P.per_rfc
			, Direccion = LTRIM(RTRIM(P.PER_CALLE1)) + ' ' + LTRIM(RTRIM(P.PER_NUMEXTER)) + ', ' + LTRIM(RTRIM(P.PER_COLONIA)) + ', ' + LTRIM(RTRIM(P.PER_DELEGAC)) + ', ' + LTRIM(RTRIM(P.PER_CIUDAD)) + ', C.P:' + LTRIM(RTRIM(P.PER_CODPOS))
			,P.PER_TELEFONO1
			,UsuarioSolicita = LTRIM(RTRIM(U.usu_paterno)) + ' ' + LTRIM(RTRIM(U.usu_materno)) + ' ' + LTRIM(RTRIM(U.usu_nombre)) 
	FROM 	cuentasporcobrar.DBO.uni_cotizacionuniversal C 
			INNER JOIN ControlAplicaciones.DBO.cat_empresas E ON C.ucu_idempresa = E.emp_idempresa 
			INNER JOIN ControlAplicaciones.DBO.cat_sucursales S ON C.ucu_idsucursal = S.suc_idsucursal 
			INNER JOIN ControlAplicaciones.DBO.cat_departamentos D ON C.ucu_iddepartamento = D.dep_iddepartamento 
			INNER JOIN cuentasporcobrar.DBO.cat_estatuscotiza CC ON C.cec_idestatuscotiza = CC.cec_idestatuscotiza 
			INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] P ON C.ucu_idcliente = P.per_idpersona 
			INNER JOIN Centralizacionv2.dbo.DIG_CAT_BASES_BPRO B ON E.emp_idempresa = B.emp_idempresa 
			--LEFT JOIN BDPersonas.DBO.per_direcciones DI ON P.per_idpersona = DI.per_idpersona 
			--LEFT JOIN BDPersonas.DBO.per_telefonos TE ON P.per_idpersona = TE.per_idpersona 
			LEFT JOIN ControlAplicaciones.dbo.cat_usuarios U ON C.ucu_idusuarioalta = U.usu_idusuario 
	WHERE 	ucu_foliocotizacion = @folio and B.tipo = 2


	SELECT	CD.ucn_idcatalogo AS clave
			,CD.ucn_modelo AS modelo
			,CD.ucn_noserie AS numeroSerie
			,CD.ucn_total AS total
			,CD.ucn_iva AS iva
			,CD.ucn_idcotizadetalle AS idDetalleCotizacion
	FROM	[cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU
			INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON CU.ucu_idcotizacion = CD.ucu_idcotizacion
	WHERE	CU.ucu_foliocotizacion = @folio

	select Folio_Operacion, convert(nvarchar(10),MAX(fechaEscaneado),103)+' '+convert(nvarchar(10),MAX(fechaEscaneado),108) FechaEscaneado,convert(nvarchar(10),GETDATE(),103)+' '+convert(nvarchar(10),getdate(),108) fechaactual,DATEDIFF(day,convert(date,MAX(fechaEscaneado)),convert(date,getdate()))  valid   
	from(
			SELECT  C.ucu_foliocotizacion Folio_Operacion, B.fecha fechaEscaneado  
			FROM cuentasporcobrar.dbo.uni_cotizacionuniversal C 
			INNER JOIN cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES U ON U.ucu_idcotizacion = C.ucu_idcotizacion  
			INNER JOIN [192.168.20.59].PortalClientes.dbo.SICOP_BITACORA B ON B.aquien = U.ucn_noserie collate Database_default) A 
			WHERE Folio_Operacion = @folio  group by Folio_Operacion  

SELECT  ucu_foliocotizacion foliocotizacion,
convert(nvarchar(10),ucn_fechaentregauni,103) fechaentrega, 
ucu_hrpromesaent horaentrega,
ucu_impenganche enganche, 
ucu_impmensual mensualidad,
ucu_tasainteres tasainteres,
ucu_plazocredito plazo
			FROM cuentasporcobrar.dbo.uni_cotizacionuniversal C 
			INNER JOIN cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES U ON U.ucu_idcotizacion = C.ucu_idcotizacion  
		
			WHERE ucu_foliocotizacion = @folio
	SET NOCOUNT OFF;
END;

go

