-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <15/06/2020>
-- Description:	<SP que actualiza el nopmbre del documento>
--TEST [expedienteSeminuevo].[UPD_NOMBRE_DOCUMENTO_GUARDADO_SP] 1, 71, 'Prueba1RemplasoconSP.pdf'
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[UPD_NOMBRE_DOCUMENTO_GUARDADO_SP]
	@idDocumentoGuardado INT,
	@idUsuario INT,
	@nombreDocumento VARCHAR(200) 
AS
BEGIN

	SET NOCOUNT ON;

    UPDATE [expedienteSeminuevo].[documentosExpediente] 
	SET nombreDocumento = @nombreDocumento, idUsuario = @idUsuario, id_estatus = 1, observacionesDocumento = ''
	WHERE id_documentoGuardado = @idDocumentoGuardado;

	SELECT success = 1;
END

go

