
CREATE PROCEDURE [dbo].[SEL_EMPRESAS_SP]
	@idempleado int 
	,@iddivision int 
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		SELECT  distinct substring(E.emp_nombre,1,37) +case when len(E.emp_nombre)>37 then '..' else '' end    AS nombre
				,E.emp_idempresa  AS idEmpresa
				, E.emp_cveempresa AS claveEmpresa
				, E.emp_nombrecto  AS nombreCorto
		FROM ControlAplicaciones.dbo.cat_empresas E 
				INNER JOIN  ControlAplicaciones.dbo.OPE_ORGANIGRAMA  Orga ON Orga.emp_idempresa = E.emp_idempresa
		WHERE Orga.div_iddivision = @iddivision 
		AND Orga.usu_idusuario = @idempleado
		order by E.emp_idempresa 
	END TRY
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_EMPRESAS_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END

go

