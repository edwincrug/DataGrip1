--[dbo].[PPROV_RUTA_COMPLEMENTO_SP] 'AU-ZM-NZA-OT-PE-90'
CREATE PROCEDURE [dbo].[PPROV_RUTA_COMPLEMENTO_SP]
	@folio  VARCHAR(50)
AS
BEGIN	
	IF EXISTS(SELECT 1 FROM PPRO_DATOSFACTURAS AS F INNER JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTODET] AS CD ON CD.orden_UUID = F.uuid INNER JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC] AS C ON CD.id_Complemento = C.id_Complemento WHERE folioorden = @folio)
		BEGIN
			SELECT	1 AS respuesta
					,'\' + 
					C.rfc_receptor + 
					'\' + 
					CONVERT(VARCHAR(4),DATEPART(yyyy,C.fecha_factura))+
					'_'+
					RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,C.fecha_factura)))),2) +
					'\' + 
					C.rfc_emisor + 
					'_' + 
					case when C.serie <> '' then C.serie else '' end + 
					C.folio AS ruta
			FROM	PPRO_DATOSFACTURAS AS F
					INNER JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTODET] AS CD ON CD.orden_UUID = F.uuid
					INNER JOIN [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC] AS C ON CD.id_Complemento = C.id_Complemento
			WHERE 	folioorden = @folio
		END
	ELSE
		BEGIN
			SELECT	0 AS respuesta
					,'No existe Archivo' AS mensaje
		END
END
go

