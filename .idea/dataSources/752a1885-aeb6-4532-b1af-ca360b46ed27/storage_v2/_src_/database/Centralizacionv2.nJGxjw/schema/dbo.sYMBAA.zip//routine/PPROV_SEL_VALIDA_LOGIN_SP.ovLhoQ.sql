-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez.
-- Create date: 27/02/2019
-- Description:	Descripcion de error en el Login del Protal Proveedores
-- ==========================================================================================
-- EXECUTE [PPROV_SEL_VALIDA_LOGIN_SP] 'OAOG500921989',''
CREATE PROCEDURE [dbo].[PPROV_SEL_VALIDA_LOGIN_SP] 
	 @rfc   VARCHAR(13) = ''
	,@pass  VARCHAR(20) = ''
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @msg VARCHAR(500) = '', @estatus VARCHAR(10) = ''

BEGIN TRY
   
	IF NOT EXISTS(SELECT PER_RFC FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_RFC = @rfc)
	BEGIN
	   SET @estatus = 'error'
	   SET @msg ='El RFC no se encuentra dado de alta en las Bases de datos de Grupo Andrade, favor de registrarse.'
	END
		ELSE IF NOT EXISTS(SELECT ppro_user FROM [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV] WHERE [ppro_user] = @rfc)
		BEGIN
		   SET @estatus = 'error'
		   SET @msg ='Por favor registrese en el Portal de Proveedores para poder ingresar.'
		END
		ELSE 
			BEGIN
			   SET @estatus = 'error'
			   SET @msg ='Contraseña incorrecta intenta de nuevo por favor.'
			END
	
	SELECT @estatus estatus,@msg mensaje

END TRY
BEGIN CATCH
	PRINT('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'PPROV_SEL_VALIDA_LOGIN_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
END CATCH
END
go

