--EXECUTE [dbo].[PPROV_ORDCOMPRA_VALIDADAS] 75,null,null,'',2,0,0,0,'','','HEHJ520304R36'
CREATE PROCEDURE [dbo].[PPROV_ORDCOMPRA_VALIDADAS]   
@idProveedor INT = 0,
@monto DECIMAL = NULL,
@orden VARCHAR(50) = NULL,
@user VARCHAR(15) = '',
@idUserRol INT = 0, 
@idEmpresaP INT = 0,
@idSucursalP INT = 0,
@idDeptoP INT = 0,
@fechaIniP VARCHAR(10) = '',
@fechaFinP VARCHAR(10) = '',
@rfcProveedor VARCHAR(20) = ''

AS  
BEGIN

IF(@idUserRol = 1)
	BEGIN
	-----------------------
	If (@fechaIniP = '') and (@fechaIniP='')
	BEGIN
	PRINT ('ROL 1 SIN FECHA')
	     SELECT   ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,
						depto.dep_nombre,
						suc.suc_nombre,  
						emp.emp_nombre,
						ordComp.oce_importetotal,
						emp.emp_nombrecto,  
						CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
						sit.sod_nombresituacion estatus,
						per.per_rfc,
						df.folioorden as ppro_nombrearchivo,
						df.serie + ISNULL(df.folio,'') factura,
						df.uuid,
						df.fecha_carga as fechaValidacion,
						CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
						df.serie,
						df.fecha_factura fecha_pago,
						df.rfc_emisor,
						df.rfc_receptor,
						df.importe as importe_total,
						ordComp.oce_uuid,
					    Recepcion =  --ADD LQMA 28042016
							 case when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6
							 then 'Recepción Completa'
							 when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7
							  THEN 'Recepción Incompleta'
							  else 'Pendiente'
							  end,
						 Estado =
						 CASE ordComp.sod_idsituacionorden
						 WHEN 12 THEN 'Pagada'
						 WHEN 13 THEN 'Pagada'
						 WHEN 16 THEN 'Pagada'
						 WHEN 18 THEN 'Pagada'
						 ELSE  'Por Pagar'
					  END					  
					  ,CASE
							WHEN ((SELECT COUNT(1) FROM Seguridad..SEG_CENTRALIZACION 
								  WHERE seg_idUsuario = @idProveedor 
										AND seg_idAccion = 5 
										AND seg_idPortal = 19
										AND seg_idModulo = 1) > 0 AND ISNULL(DF.estatus,0) = 2) --ordComp.sod_idsituacionorden = 2
							THEN 2
							ELSE 1
							END	idEstatus					  
					  ,emp.emp_idempresa 	
					  ,DF.folio
					  ,CASE  
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
						(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
						(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
						ELSE ''
					END AS NumSerie,
					OC.ser_ordenservicio ordenServicio
				FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
				LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
				LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
				LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal   
				LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
				LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
				LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento 
				LEFT JOIN  PPRO_DATOSFACTURAS DF ON DF.folioorden= ordComp.oce_folioorden
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL
				WHERE ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18,20) 
					  --AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
					  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					  AND ordComp.oce_folioorden IN (SELECT oce_folioorden FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_idproveedor IN(
												 SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @user))
					  AND DF.tipoDocumento = 1
					  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
					  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
					  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
					  --AND CONVERT(DATE,REPLACE(df.fecha_carga,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
					  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))
					  order by ordComp.oce_fechaorden ASC
	END
	
	ELSE
	
	BEGIN
	PRINT ('ROL 1 CON FECHA')
	 SELECT   ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,
						depto.dep_nombre,
						suc.suc_nombre,  
						emp.emp_nombre,
						ordComp.oce_importetotal,
						emp.emp_nombrecto,  
						CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
						sit.sod_nombresituacion estatus,
						per.per_rfc,
						df.folioorden as ppro_nombrearchivo,
						df.serie + ISNULL(df.folio,'') factura,
						df.uuid,
						df.fecha_carga as fechaValidacion,
						CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
						df.serie,
						df.fecha_factura fecha_pago,
						df.rfc_emisor,
						df.rfc_receptor,
						df.importe as importe_total,
						ordComp.oce_uuid,
					    Recepcion =  --ADD LQMA 28042016
							 case when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6
							 then 'Recepción Completa'
							 when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7
							  THEN 'Recepción Incompleta'
							  else 'Pendiente'
							  end,
						 Estado =
						 CASE ordComp.sod_idsituacionorden
						 WHEN 12 THEN 'Pagada'
						 WHEN 13 THEN 'Pagada'
						 WHEN 16 THEN 'Pagada'
						 WHEN 18 THEN 'Pagada'
						 ELSE  'Por Pagar'
					  END					  
					  ,CASE
							WHEN ((SELECT COUNT(1) FROM Seguridad..SEG_CENTRALIZACION 
								  WHERE seg_idUsuario = @idProveedor 
										AND seg_idAccion = 5 
										AND seg_idPortal = 19
										AND seg_idModulo = 1) > 0 AND ISNULL(DF.estatus,0) = 2) --ordComp.sod_idsituacionorden = 2
							THEN 2
							ELSE 1
							END	idEstatus					  
					  ,emp.emp_idempresa 	
					  ,DF.folio
					  ,CASE  
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
						(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
						(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
						ELSE ''
					END AS NumSerie,
					OC.ser_ordenservicio ordenServicio
				FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
				LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
				LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
				LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal   
				LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
				LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
				LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento 
				LEFT JOIN  PPRO_DATOSFACTURAS DF ON DF.folioorden= ordComp.oce_folioorden
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL
				WHERE ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18,20) 
					  --AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
					  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)
					  AND ordComp.oce_folioorden IN (SELECT oce_folioorden FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_idproveedor IN(
												 SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @user))
					  AND DF.tipoDocumento = 1
					  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
					  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
					  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
					  AND CONVERT(DATE,REPLACE(df.fecha_carga,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
					  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = ''))
					  order by ordComp.oce_fechaorden ASC

	END
	-----------------------
	END
ELSE
	BEGIN
	if @idProveedor = 67
		begin
			set @idProveedor = 15
		end

		DECLARE @EmpresaSucursal TABLE
			(	
				idEmpSuc INT NOT NULL IDENTITY(1,1),
				empresa INT,
				sucursal INT
			)

	if (@fechaIniP = '') and (@fechaIniP='')
	
		Begin
			PRINT ('SIN FECHA')

			print 'variable tabla'

			--Insertamos empresas y sucursales por usuario
			INSERT INTO @EmpresaSucursal
			SELECT DISTINCT emp_idempresa,suc_idsucursal FROM [ControlAplicaciones].[dbo].[ope_organigrama]
			WHERE [usu_idusuario] = @idProveedor--(SELECT usu_idusuario FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombreusu = @user)
			
			SELECT   ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,
						depto.dep_nombre,
						suc.suc_nombre,  
						emp.emp_nombre,
						ordComp.oce_importetotal,
						emp.emp_nombrecto,  
						CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
						sit.sod_nombresituacion estatus,
						per.per_rfc,
						df.folioorden as ppro_nombrearchivo,
						df.serie + ISNULL(df.folio,'') factura,
						df.uuid,
						df.fecha_carga as fechaValidacion,
						CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
						df.serie,
						df.fecha_factura fecha_pago,
						df.rfc_emisor,
						df.rfc_receptor,
						df.importe as importe_total,
						ordComp.oce_uuid,
						Recepcion =  --ADD LQMA 28042016
							 case when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6
							 then 'Recepción Completa'
							 when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7
							  THEN 'Recepción Incompleta'
							  else 'Pendiente'
							  end,
						 --  Recepcion =  --ADD LQMA 28042016
							--CASE ordComp.sod_idsituacionorden
							--	WHEN  (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 order by [sod_idsituacionorden] desc) 
							--		THEN 'Recepción Completa' 
							--	WHEN  (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 order by [sod_idsituacionorden] desc) 	
							--		THEN 'Recepción Incompleta' 
							--		ELSE 'Pendiente' 
							--END,
						 Estado =
						 CASE ordComp.sod_idsituacionorden
						 WHEN 12 THEN 'Pagada'
						 WHEN 13 THEN 'Pagada'
						 WHEN 16 THEN 'Pagada'
						 WHEN 18 THEN 'Pagada'
						 ELSE  'Por Pagar'
					  END
					  ,ISNULL(DF.estatus,0) idEstatus --ordComp.sod_idsituacionorden idEstatus --ADD LQMA 28042016 
					  ,suc.suc_idsucursal --ADD LQMA 02052016
					  ,emp.emp_idempresa --ADD LQMA 02052016	
					  ,DF.folio
					  ,CASE  
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
						(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
						(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
						ELSE ''
					END AS NumSerie,
					OC.ser_ordenservicio ordenServicio
				FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
				LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
				LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
				LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal   
				LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
				LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
				LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento 
				LEFT JOIN  PPRO_DATOSFACTURAS DF ON DF.folioorden= ordComp.oce_folioorden
				JOIN @EmpresaSucursal EmpSuc ON ordComp.oce_idempresa = EmpSuc.empresa AND ordComp.oce_idsucursal = EmpSuc.sucursal
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL
				WHERE --ordComp.oce_idproveedor = @idProveedor AND
					  --ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18) AND --original comentado LQMA 28042016					  
					  ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18,20) AND
					   (@monto IS NULL OR ordComp.oce_importetotal = @monto)
					   AND DF.tipoDocumento = 1
					  AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
					  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)	
					  
				 --LQMA 21092017 add fintros
					  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
					  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
					  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
					  --AND CONVERT(DATE,REPLACE(df.fecha_carga,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
					  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = '')) 	    	  	  
					  order by ordComp.oce_fechaorden ASC
		END
		ELSE
		BEGIN
			PRINT ('CON FECHA')
					
			print 'variable tabla'

			--Insertamos empresas y sucursales por usuario
			INSERT INTO @EmpresaSucursal
			SELECT DISTINCT emp_idempresa,suc_idsucursal FROM [ControlAplicaciones].[dbo].[ope_organigrama]
			WHERE [usu_idusuario] = @idProveedor--(SELECT usu_idusuario FROM [ControlAplicaciones].[dbo].[cat_usuarios] WHERE usu_nombreusu = @user)
			
			SELECT   ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
						ordComp.oce_folioorden,
						depto.dep_nombre,
						suc.suc_nombre,  
						emp.emp_nombre,
						ordComp.oce_importetotal,
						emp.emp_nombrecto,  
						CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
						sit.sod_nombresituacion estatus,
						per.per_rfc,
						df.folioorden as ppro_nombrearchivo,
						df.serie + ISNULL(df.folio,'') factura,
						df.uuid,
						df.fecha_carga as fechaValidacion,
						CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
						df.serie,
						df.fecha_factura fecha_pago,
						df.rfc_emisor,
						df.rfc_receptor,
						df.importe as importe_total,
						ordComp.oce_uuid,
						Recepcion =  --ADD LQMA 28042016
							 case when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 and oce_folioorden = ordComp.oce_folioorden ) = 6
							 then 'Recepción Completa'
							 when (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 and oce_folioorden = ordComp.oce_folioorden ) = 7
							  THEN 'Recepción Incompleta'
							  else 'Pendiente'
							  end,
						 --  Recepcion =  --ADD LQMA 28042016
							--CASE ordComp.sod_idsituacionorden
							--	WHEN  (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 6 order by [sod_idsituacionorden] desc) 
							--		THEN 'Recepción Completa' 
							--	WHEN  (SELECT top 1 [sod_idsituacionorden] FROM [cuentasxpagar].[dbo].[cxp_movimientosorden] WHERE [sod_idsituacionorden] = 7 order by [sod_idsituacionorden] desc) 	
							--		THEN 'Recepción Incompleta' 
							--		ELSE 'Pendiente' 
							--END,
						 Estado =
						 CASE ordComp.sod_idsituacionorden
						 WHEN 12 THEN 'Pagada'
						 WHEN 13 THEN 'Pagada'
						 WHEN 16 THEN 'Pagada'
						 WHEN 18 THEN 'Pagada'
						 ELSE  'Por Pagar'
					  END
					  ,ISNULL(DF.estatus,0) idEstatus --ordComp.sod_idsituacionorden idEstatus --ADD LQMA 28042016 
					  ,suc.suc_idsucursal --ADD LQMA 02052016
					  ,emp.emp_idempresa --ADD LQMA 02052016	
					  ,DF.folio
					  ,CASE  
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='UN') THEN
						(SELECT anu_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] where oce_folioorden = ordComp.oce_folioorden )
						WHEN oce_iddepartamento  in (select dep_iddepartamento from ControlAplicaciones.dbo.cat_departamentos where dep_nombrecto ='US') THEN
						(SELECT asn_numeroserie FROM [cuentasxpagar].[dbo].[cxp_detalleseminuevos] where oce_folioorden = ordComp.oce_folioorden  )
						ELSE ''
					END AS NumSerie,
					OC.ser_ordenservicio ordenServicio
				FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
				LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
				LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
				LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal   
				LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
				LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
				LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento 
				LEFT JOIN  PPRO_DATOSFACTURAS DF ON DF.folioorden= ordComp.oce_folioorden
				JOIN @EmpresaSucursal EmpSuc ON ordComp.oce_idempresa = EmpSuc.empresa AND ordComp.oce_idsucursal = EmpSuc.sucursal
				LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OC ON ordComp.oce_folioorden = OC.oce_folioorden AND ser_ordenservicio IS NOT NULL
				WHERE --ordComp.oce_idproveedor = @idProveedor AND
					  --ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18) AND --original comentado LQMA 28042016					  
					  ordComp.sod_idsituacionorden NOT IN (3,4,11,12,16,18,20) AND
					   (@monto IS NULL OR ordComp.oce_importetotal = @monto)
					   AND DF.tipoDocumento = 1
					  AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
					  AND  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS)	
					  
				 --LQMA 21092017 add fintros
					  AND ((ordComp.oce_idempresa = @idEmpresaP) OR (@idEmpresaP = 0))
					  AND ((ordComp.oce_idsucursal = @idSucursalP) OR (@idSucursalP = 0))
					  AND ((ordComp.oce_iddepartamento = @idDeptoP) OR (@idDeptoP = -1))
					  AND CONVERT(DATE,REPLACE(df.fecha_carga,'-',''),105) BETWEEN CONVERT(DATE,@fechaIniP) AND CONVERT(DATE,@fechaFinP)
					  AND ((per.per_rfc = @rfcProveedor) OR (@rfcProveedor = '')) 	    	  	  
					  order by ordComp.oce_fechaorden ASC
			END
	END

END

--SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
--		ordComp.oce_folioorden,
--		depto.dep_nombre,
--		suc.suc_nombre,  
--		emp.emp_nombre,
--		ordComp.oce_importetotal,
--		emp.emp_nombrecto,  
--		CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden,
--		sit.sod_nombresituacion estatus,
--		per.per_rfc,
--		df.folioorden as ppro_nombrearchivo,
--		df.serie + ISNULL(df.folio,'') factura,
--		df.uuid,
--		df.fecha_carga as fechaValidacion,
--		CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
--		df.serie,
--		df.fecha_factura fecha_pago,
--		df.rfc_emisor,
--		df.rfc_receptor,
--		df.importe as importe_total,
--		ordComp.oce_uuid,
--		Recepcion =
--      CASE ordComp.sod_idsituacionorden
--	     WHEN 1 THEN 'Pendiente'
--		 WHEN 2 THEN 'Pendiente'
--		 WHEN 3 THEN 'Pendiente'
--		 WHEN 4 THEN 'Pendiente'
--		 WHEN 5 THEN 'Pendiente'
--         WHEN 6 THEN 'Recepción Completa'
--         WHEN 7 THEN 'Recepción Incompleta'
--		 ELSE  'Recepción Incompleta'		 
--      END,
--		 Estado =
--	     CASE ordComp.sod_idsituacionorden
--		 WHEN 12 THEN 'Pagada'
--         WHEN 13 THEN 'Pagada'
--		 WHEN 16 THEN 'Pagada'
--		 WHEN 18 THEN 'Pagada'
--         ELSE  'Por Pagar'
--      END 
--FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] DF
-- JOIN cuentasxpagar.dbo.cxp_ordencompra ordComp on DF.folioorden = ordComp.oce_folioorden
--LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON ordComp.oce_idproveedor = per.per_idpersona
--LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
--LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
--LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
--LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
--WHERE ordComp.oce_idproveedor = @idProveedor  AND
--	   (@monto IS NULL OR ordComp.oce_importetotal = @monto)
--	  AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))	
--	  AND ordComp.sod_idsituacionorden NOT IN (3,4)
--	  AND DF.estatus=2
-- order by ordComp.oce_fechaorden DESC

--END

go

