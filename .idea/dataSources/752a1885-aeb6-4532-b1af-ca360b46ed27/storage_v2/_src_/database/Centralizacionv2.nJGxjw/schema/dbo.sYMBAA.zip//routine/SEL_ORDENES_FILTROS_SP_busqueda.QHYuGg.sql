-- ==========================================================================================
-- Author:		Arturo Rodea Victoria
-- Create date: 15/10/2015
-- Modified date: 29/01/2016  Lourdes Maldonado Sánchez(LMS)
-- Description:	Stored que recupera las órdenes de compra según las opciones de los filtros.
--              Dependiendo de si es una orden CXP o CXC                              --AU-ZM-ZAR-UN-22
-- ==========================================================================================
-- EXECUTE [SEL_ORDENES_FILTROS_SP_busqueda] @idDocumento='UN' --@fechaini='20161129', @fechafin='20161211',@idProceso=2  --@folioorden = 'UN',@idProceso=2   --AU-ZM-ZAR-RE-PE-133
CREATE PROCEDURE [dbo].[SEL_ORDENES_FILTROS_SP_busqueda] 
		@idDocumento     nvarchar(20)
AS
BEGIN
	SET NOCOUNT ON;


		EXECUTE [SEL_MONTO_COTIZACION_SP]  @idDocumento =@idDocumento
END

go

