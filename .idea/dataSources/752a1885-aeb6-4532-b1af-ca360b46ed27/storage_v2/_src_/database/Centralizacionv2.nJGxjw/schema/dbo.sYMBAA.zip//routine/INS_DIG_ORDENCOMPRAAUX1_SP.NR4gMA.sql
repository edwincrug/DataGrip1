/*

*/

CREATE PROCEDURE [dbo].[INS_DIG_ORDENCOMPRAAUX1_SP]  --with recompile
  AS
declare
@iId_local int,
@sFolio_Operacion varchar(50),
@iCuantos int
begin 
set nocount on

select @iId_local = 0
select @sFolio_Operacion=''
select @iCuantos = 0;

select @iCuantos=Count(*) from  Centralizacionv2..DIG_ORDENCOMPRAAUX1

if (@iCuantos>0)
begin
		Insert into Centralizacionv2..DIG_BITACORA (fecha,quien,que,aquien)
		values (GETDATE(),'CXP INS_DIG_ORDENCOMPRAAUX1_SP','Se pasan uno a uno los registros a DIG_ORDENCOMPRAAUX desde DIG_ORDENCOMPRAAUX1','los que estan en DIG_ORDENCOMPRAAUX1')



		while Exists(select 1 from  Centralizacionv2..DIG_ORDENCOMPRAAUX1)
		begin
		   BEGIN TRANSACTION T1
			
					select top 1 @iId_local = id_local, @sFolio_Operacion = Folio_Operacion from Centralizacionv2..DIG_ORDENCOMPRAAUX1  --div_iddivision, emp_idempresa, suc_idsucursal, dep_iddepartamento, tipo_idtipoorden, Folio_Operacion,oce_idsituacionorden, getdate(),aux_observaciones from Centralizacionv2..DIG_ORDENCOMPRAAUX1	
					order by aux_fecha desc

					print 'Procesando: ' + @sFolio_Operacion

					insert into Centralizacionv2..DIG_ORDENCOMPRAAUX (div_iddivision, emp_idempresa, suc_idsucursal, dep_iddepartamento, tipo_idtipoorden, Folio_Operacion,oce_idsituacionorden, aux_fecha,aux_observaciones)
					select div_iddivision, emp_idempresa, suc_idsucursal, dep_iddepartamento, tipo_idtipoorden, Folio_Operacion,oce_idsituacionorden, getdate(),aux_observaciones from Centralizacionv2..DIG_ORDENCOMPRAAUX1
					where id_local = @iId_local	
			
					delete Centralizacionv2..DIG_ORDENCOMPRAAUX1 where id_local=@iId_local
			
				select @iId_local=0
		   COMMIT TRANSACTION T1

			WAITFOR DELAY '00:00:30' --30 seconds
		end 
end

Return @iCuantos
select @iCuantos

set nocount off
end
go

