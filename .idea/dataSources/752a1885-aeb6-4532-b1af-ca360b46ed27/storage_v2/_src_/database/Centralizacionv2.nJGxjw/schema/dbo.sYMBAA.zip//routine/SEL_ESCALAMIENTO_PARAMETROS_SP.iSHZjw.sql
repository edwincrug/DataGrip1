-- =============================================
-- Author: Mario Arturo Mejía Ramírez
-- Create date: 16/12/2015
-- Description: Recupera todos los registros de los usuarios mancomunados
-- =============================================
--[SEL_ESCALAMIENTO_PARAMETROS_SP] 2,1,1,1,1,4
CREATE PROCEDURE [dbo].[SEL_ESCALAMIENTO_PARAMETROS_SP] 
	@proc_Id int,
	@nodo_id int,
	@emp_idempresa int,
	@suc_idsucursal int,
	@dep_iddepartamento int,
	@tipo_idtipoorden int
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
				
		SELECT escalamiento_id AS escalamientoId
			  ,ep.Proc_Id
			  ,dig.Proc_Nombre AS procNombre
			  ,ep.Nodo_Id AS nodoId
			  ,din.Nodo_Nombre AS nodoNombre 
			  ,ep.emp_idempresa AS empIdEmpresa
			  ,emp.emp_nombre AS empNombre
			  ,ep.suc_idsucursal AS sucIdSucursal 
			  ,suc.suc_nombre AS sucNombre
			  ,ep.dep_iddepartamento AS depIdDepartamento 
			  ,dep.dep_nombre AS depNombre
			  ,ep.tipo_idtipoorden AS tipoIdTipoOrden 
			  ,occ.tip_nombre AS tipOrden
			  ,ep.usuario_mancomunado AS usuarioMancomunado 
			  ,uc.usu_nombreusu +  ' ' + uc.usu_paterno + ' ' + uc.usu_materno AS usuarioMancomunadoC
FROM DIG_ESCALAMIENTO_PARAMETROS AS ep
INNER join [dbo].[Usuario_ControlAplicaciones] AS uc ON uc.usu_idusuario = ep.usuario_mancomunado
AND ep.Proc_Id= @proc_id
AND ep.Nodo_Id = @nodo_id
AND ep.suc_idsucursal = @suc_idsucursal
AND ep.dep_iddepartamento = @dep_iddepartamento
AND ep.tipo_idtipoorden = @tipo_idtipoorden
and ep.emp_idempresa = @emp_idempresa
INNER JOIN [dbo].[DIG_PROCESO] AS dig ON dig.Proc_Id = ep.Proc_Id
INNER JOIN [dbo].[DIG_NODO] AS din ON din.Nodo_Id = ep.Nodo_Id
INNER JOIN [dbo].[Empresas_ControlAplicaciones] AS emp ON emp.emp_idempresa = ep.emp_idempresa
INNER JOIN [dbo].[Sucursale_ControlAplicaciones] AS suc ON suc.suc_idsucursal = ep.suc_idsucursal
INNER JOIN [dbo].[departamento_ControlAplicaciones] AS dep ON dep.dep_iddepartamento = ep.dep_iddepartamento
INNER JOIN [dbo].[Tipos_OCCompra_Cuentasxpagar] AS occ ON occ.tip_idtipoorden = ep.tipo_idtipoorden
WHERE ep.suc_idsucursal = @suc_idsucursal
AND ep.dep_iddepartamento = @dep_iddepartamento
AND ep.tipo_idtipoorden = @tipo_idtipoorden
AND ep.Nodo_Id = @nodo_id		
AND ep.Proc_Id = @proc_Id
AND ep.emp_idempresa = @emp_idempresa
		
	END TRY
	BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_ESCALAMIENTO_PARAMETROS_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	END CATCH
END


go

