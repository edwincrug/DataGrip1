-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST [expedienteSeminuevo].[SEL_ID_EXPEDIENTE_BY_VIN ] '3G1TA5AF5FL186987'
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_ID_EXPEDIENTE_BY_VIN ]
	@vin VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;

	SELECT id_expediente FROM [expedienteSeminuevo].[expedientes] WHERE exp_vin = @vin
END

go

