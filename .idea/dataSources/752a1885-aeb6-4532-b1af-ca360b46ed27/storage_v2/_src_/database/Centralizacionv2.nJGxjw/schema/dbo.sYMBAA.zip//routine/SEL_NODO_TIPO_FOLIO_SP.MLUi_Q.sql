-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	Obtengo el ultimo nodo del expediente y el tipo de folio
-- =============================================
--EXECUTE [dbo].[SEL_NODO_TIPO_FOLIO_SP] 'AU-ZM-NZA-UN-PE-23', 1
CREATE PROCEDURE [dbo].[SEL_NODO_TIPO_FOLIO_SP] 
	@folio VARCHAR(50)
	,@idProceso INT 
AS
BEGIN
	---------------------------------------------------
	--Obtiene el ultimo nodo activo 
	---------------------------------------------------
	DECLARE @nodo INT
	SELECT	@nodo = D.Nodo_Id 
	FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
	WHERE	D.Proc_Id = @idProceso 
			AND D.Folio_Operacion = @folio
			AND  D.Nodo_Estatus_Id = 2 
	ORDER BY D.Nodo_Id  DESC
	---------------------------------------------------
	--Obtengo el tipo de orden 
	---------------------------------------------------
	DECLARE @tipofolio INT
	SELECT @tipofolio = ( CASE WHEN EXISTS (SELECT irr_folioinicial FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac] WHERE [irr_folioinicial] = @folio) THEN 1 
							   WHEN EXISTS(SELECT irr_folionuevo FROM [cuentasxpagar].[dbo].[cxp_integracionremrefac] WHERE [irr_folionuevo] =  @folio) THEN 2
							   WHEN EXISTS(SELECT ifr_folionuevo FROM [cuentasxpagar].[dbo].[cxp_integracionfacrefac] WHERE [ifr_folionuevo] = @folio) THEN 3
							   WHEN EXISTS(SELECT ifs_folionuevo FROM [cuentasxpagar].[dbo].[cxp_integracionfacser] WHERE [ifs_folionuevo] = @folio) THEN 5
							   ELSE 1
						   END)
	SELECT @nodo AS nodoactual,@tipofolio AS tipofolio
END
go

