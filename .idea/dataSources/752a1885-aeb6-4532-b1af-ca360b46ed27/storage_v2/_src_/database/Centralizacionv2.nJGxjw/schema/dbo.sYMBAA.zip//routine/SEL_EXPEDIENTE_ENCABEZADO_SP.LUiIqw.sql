-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 19/11/2015
-- Description:	recupera el encabezado del expediente
-- ============================================= ----'AU-ZM-ZAR-UN-22'
-- SEL_EXPEDIENTE_ENCABEZADO_SP 'AU-ZM-NZA-UN-4532', 72
--SEL_EXPEDIENTE_ENCABEZADO_SP 'AU-AS-SAT-OT-PE-3018',1 
CREATE PROCEDURE [dbo].[SEL_EXPEDIENTE_ENCABEZADO_SP]
	 @folio		nvarchar(30)
	,@idusuario	int
AS
BEGIN

	SET NOCOUNT ON;
	IF(@folio = 'AU-AUA-VIG-OT-IF-43') --BORRAR
	BEGIN--BORRAR
	        select  'Automovilistica Andrade SA de CV' as empresa
    				,'Viga' as agencia	
					,'Otros Conceptos' as departamento
					,'AU-AUA-VIG-OT-IF-43' as	folio 
					, 10 as nodoActual
					,'En Proceso' as estatusExpediente
					,'Usuario Sistema 1' as	nombreUsuario
					,getdate() as fechaUltimoMovimiento	
					,'' as folioPadre
					,null as folioHijo	 --DIFERENTE
					,null as alias	
					,0 as esPlanta	
					,0 as idTipoVenta	
					,'' as nombreTipoVenta
	END--BORRAR
	ELSE--BORRAR
	BEGIN--BORRAR
	
	DECLARE @idProceso  INT=0;

	SELECT @idProceso = E.Proc_Id        
	  FROM  dbo.DIG_EXPEDIENTE AS E 
     WHERE E.Folio_Operacion = @folio

	print @idProceso
	print 'aqui estoy '
    IF(@idProceso = 1 OR @idProceso = 0)
	BEGIN
		print 'entre'
		DECLARE @folioPlanPiso VARCHAR(50) = null
		SET @folioPlanPiso = (SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO   WHERE Folio_Alias = @folio)
		DECLARE @planta int=0	
		EXECUTE [Centralizacionv2].[dbo].[ES_REFACCIONES_PLANTA_SP]  @folio, @planta output
		print @planta
		
		DECLARE @fechaUltimoMov DATETIME,  @folioHijo VARCHAR(50), @alias VARCHAR(50), @usuarioMov VARCHAR(200) = ''

		SELECT	@fechaUltimoMov = MAX( CONVERT(DATETIME, CONVERT(CHAR(8),[mov_fechamovimiento], 112) + ' ' + CONVERT(CHAR(8),[mov_horamovimiento], 108)))
				,@usuarioMov = U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno 
		FROM	[cuentasxpagar].[dbo].[cxp_movimientosorden] AS M
				INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] AS U ON M.mov_idusuariomovimiento = U.usu_idusuario
		WHERE	oce_folioorden = @folio
		GROUP BY U.usu_nombre, U.usu_paterno, U.usu_materno

		SET @alias = (SELECT TOP 1 Folio_Alias FROM dbo.DIG_EXP_PLAN_PISO   WHERE Folio_Operacion = @folio)

		--SELECT @folioHijo = ISNULL(oce_folioorden,'') FROM cuentasxpagar.dbo.cxp_ordencompra   WHERE oce_foliopadre = @folio AND NOT EXISTS(SELECT 1 FROM dbo.DIG_EXP_PLAN_PISO   WHERE Folio_Operacion = @folio AND Folio_Alias = oce_folioorden )
		IF (@alias is null ) 
			BEGIN 
				SELECT @folioHijo = ISNULL(oce_folioorden,'') FROM cuentasxpagar.dbo.cxp_ordencompra   WHERE oce_foliopadre = @folio --AND 
			END
		SELECT	EM.emp_nombre AS empresa
				,S.suc_nombre AS agencia
				,D.dep_nombre AS departamento
				,E.Folio_Operacion AS folio
				,EN.Nodo_Id AS nodoActual
				,EE.Estatus_Nombre AS estatusExpediente
				,U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno as nombreUsuario
				,@fechaUltimoMov AS fechaUltimoMovimiento
				,ISNULL(OC.oce_foliopadre , '') folioPadre
				,@folioHijo AS folioHijo
				,@alias AS alias
				,CASE WHEN  oce_idtipoorden IN (4,5) THEN 1 ELSE 0 END as esPlanta
				,0          as idTipoVenta
                ,''         as nombreTipoVenta
				,SITORD.sod_nombresituacion AS nombreSituacion
				,@usuarioMov AS nombreUsuariomodifico
				,'' as ucu_tipoventaunidad
		FROM    dbo.DIG_EXPEDIENTE AS E 
				INNER JOIN cuentasxpagar.dbo.cxp_ordencompra  AS OC   ON OC.oce_folioorden = E.Folio_Operacion 				 
				INNER JOIN ControlAplicaciones.dbo.cat_departamentos AS D   ON OC.oce_iddepartamento = D.dep_iddepartamento 
				INNER JOIN ControlAplicaciones.dbo.cat_sucursales AS S   ON D.suc_idsucursal = S.suc_idsucursal 
				INNER JOIN ControlAplicaciones.dbo.cat_empresas AS EM   ON S.emp_idempresa = EM.emp_idempresa 
				INNER JOIN dbo.DIG_EXP_NODO AS EN ON EN.Folio_Operacion = E.Folio_Operacion AND Nodo_Estatus_Id = 2 AND Fecha_Fin IS NULL AND Fecha_Inicio IS NOT  NULL 
				INNER JOIN [dbo].[DIG_ESTATUS_EXPEDIENTE] AS EE ON E.Estatus_Id = EE.Estatus_Id 
				INNER JOIN ControlAplicaciones.dbo.cat_usuarios AS U   ON OC.oce_idusuario = U.usu_idusuario
				LEFT JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITORD    ON OC.sod_idsituacionorden=SITORD.sod_idsituacionorden						
		WHERE  E.Folio_Operacion IN (@folio,@folioPlanPiso)
		
		/*
		SELECT   EM.emp_nombre as empresa
				, S.suc_nombre as agencia
				, D.dep_nombre as departamento
				, E.Folio_Operacion as folio
				, (select TOP 1 Nodo_Id FROM dbo.DIG_EXP_NODO DENT   WHERE Proc_Id = E.Proc_Id AND Folio_Operacion = OC.oce_folioorden AND Nodo_Estatus_Id = 2 ) as nodoActual
				, CASE E.Estatus_Id WHEN 1 THEN 'En Proceso' WHEN 2 THEN 'Cancelado' WHEN 3 THEN 'Rechazada' END as estatusExpediente
				, U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno as nombreUsuario
				, (SELECT MAX( CONVERT(DATETIME, CONVERT(CHAR(8),[mov_fechamovimiento], 112) + ' ' + CONVERT(CHAR(8),[mov_horamovimiento], 108))
				) FROM [cuentasxpagar].dbo.cxp_movimientosorden   WHERE oce_folioorden = E.Folio_Operacion) as fechaUltimoMovimiento
				,ISNULL(OC.oce_foliopadre , '') folioPadre
				,(SELECT ISNULL(oce_folioorden,'') FROM cuentasxpagar.dbo.cxp_ordencompra   WHERE oce_foliopadre = OC.oce_folioorden AND NOT EXISTS(SELECT 1 FROM dbo.DIG_EXP_PLAN_PISO   WHERE Folio_Operacion = OC.oce_folioorden AND Folio_Alias = oce_folioorden ) ) folioHijo
				--,null as folioHijo	 --DIFERENTE
				,(SELECT TOP 1 Folio_Alias FROM dbo.DIG_EXP_PLAN_PISO   WHERE Folio_Operacion = OC.oce_folioorden) alias--, LQMA 27062017
				--,CASE WHEN @planta = 1 OR oce_idtipoorden IN (5,6) THEN 1 ELSE 0 END as esPlanta  --20.89
				,CASE WHEN @planta = 1 OR oce_idtipoorden IN (4,5) THEN 1 ELSE 0 END as esPlanta  --20.9
				,0          as idTipoVenta
                ,''         as nombreTipoVenta
				,SITORD.sod_nombresituacion AS nombreSituacion
				,(SELECT [usu_nombre] + ' ' + [usu_paterno] + ' ' + [usu_materno] 
				            FROM [ControlAplicaciones].[dbo].[cat_usuarios]   
							WHERE usu_idusuario = MOVORD.mov_idusuariomovimiento)
							AS nombreUsuariomodifico
		FROM      dbo.DIG_EXPEDIENTE AS E INNER JOIN
				  --dbo.DIG_EXP_NODO AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion INNER JOIN
				  cuentasxpagar.dbo.cxp_ordencompra  AS OC   ON OC.oce_folioorden = E.Folio_Operacion INNER JOIN
				  ControlAplicaciones.dbo.cat_usuarios AS U   ON OC.oce_idusuario = U.usu_idusuario INNER JOIN
				  ControlAplicaciones.dbo.cat_departamentos AS D   ON OC.oce_iddepartamento = D.dep_iddepartamento INNER JOIN
				  ControlAplicaciones.dbo.cat_sucursales AS S   ON D.suc_idsucursal = S.suc_idsucursal INNER JOIN
				  ControlAplicaciones.dbo.cat_empresas AS EM   ON S.emp_idempresa = EM.emp_idempresa INNER JOIN
				  ControlAplicaciones.dbo.cat_divisiones AS DIV   ON EM.div_iddivision = DIV.div_iddivision
				  INNER JOIN DIG_ESTATUS_EXPEDIENTE AS EE   ON EE.Estatus_Id = E.Estatus_Id--Se agrego cuando se cambio los estatus de la tabla 
				  --add dvr 
				  LEFT JOIN [cuentasxpagar].[dbo].[cxp_movimientosorden] MOVORD WITH (NOLOCK) ON MOVORD.oce_folioorden = OC.oce_folioorden AND MOVORD.sod_idsituacionorden= OC.sod_idsituacionorden
				  LEFT JOIN [cuentasxpagar].[dbo].[cat_situacionorden] SITORD    ON OC.sod_idsituacionorden=SITORD.sod_idsituacionorden	
		WHERE	  E.Folio_Operacion IN (@folio,@folioPlanPiso)
		*/
    END

	IF(@idProceso = 2)
	BEGIN

       --  SELECT DISTINCT EM.emp_nombre     as empresa
	  --      ,S.suc_nombre      as agencia
			--,D.dep_nombre      as departamento
	  --      ,E.Folio_Operacion as folio 
			--,1                 as nodoActual
			----,CASE E.Estatus_Id 
			----    WHEN 1 
			----        THEN 'En Proceso' 
			----    WHEN 2 
			----        THEN 'Cancelado' 
   ----             WHEN 3
			----		THEN 'Rechazada'
			----  END              as estatusExpediente
			--,EE.Estatus_Nombre as estatusExpediente
			--,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
   --             FROM BDPersonas.dbo.cat_personas AS PER 
   --            WHERE PER.per_idpersona = O.ucu_idcliente)     as nombreUsuario
			--, GETDATE()        as fechaUltimoMovimiento
			--,''                as folioPadre
			--,null              as folioHijo      --null
			--,null              as alias          --null
			--,O.ucu_idcliente   as esPlanta
			--,CONVERT (INT,TV.IdTipoVenta)    as idTipoVenta
   --         ,TV.nombreTipoVenta as nombreTipoVenta
	  --FROM  dbo.DIG_EXPEDIENTE AS E 
			--INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
			--INNER JOIN [Centralizacionv2].[dbo].[DIG_CANAL_VENTA] AS CV ON CV.canalVenta = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS --Cambio con los nuevos catalogos de tipo de venta
			--INNER JOIN [Centralizacionv2].[dbo].[DIG_CATALOGO_TIPO_VENTA] AS TV ON TV.IdTipoVenta = CV.idTipoVenta --Cambio con los nuevos catalogos de tipo de venta
			----INNER JOIN Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA      AS T  ON O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS = T.Tip_Clave --Antes de modificaciones de tipo de venta
			--INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
			--INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
			--INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
			--INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
			--INNER JOIN DIG_ESTATUS_EXPEDIENTE AS EE ON EE.Estatus_Id = E.Estatus_Id -- Se agrego cuando se hizo cambio en el catalogo 
   --  WHERE E.Folio_Operacion = @folio
   SELECT DISTINCT EM.emp_nombre     as empresa
	        ,S.suc_nombre      as agencia
			,D.dep_nombre      as departamento
	        ,E.Folio_Operacion as folio 
			,1                 as nodoActual
			--,CASE E.Estatus_Id 
			--    WHEN 1 
			--        THEN 'En Proceso' 
			--    WHEN 2 
			--        THEN 'Cancelado' 
   --             WHEN 3
			--		THEN 'Rechazada'
			--  END              as estatusExpediente
			,EE.Estatus_Nombre as estatusExpediente
			,PER.Persona as nombreUsuario
			--,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
   --             FROM BDPersonas.dbo.cat_personas AS PER   
   --            WHERE PER.per_idpersona = O.ucu_idcliente)     as nombreUsuario
			, GETDATE()        as fechaUltimoMovimiento
			,''                as folioPadre
			,null              as folioHijo      --null
			,null              as alias          --null
			,O.ucu_idcliente   as esPlanta
			,CONVERT (INT,TV.IdTipoVenta)    as idTipoVenta
            ,TV.nombreTipoVenta as nombreTipoVenta
			,'' nombreSituacion 
			,'' nombreUsuariomodifico
			,O.ucu_tipoventaunidad
	  FROM  dbo.DIG_EXPEDIENTE AS E 
			INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O    ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
			INNER JOIN [Centralizacionv2].[dbo].[DIG_CANAL_VENTA] AS CV   ON CV.canalVenta = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS --Cambio con los nuevos catalogos de tipo de venta
			INNER JOIN [Centralizacionv2].[dbo].[DIG_CATALOGO_TIPO_VENTA] AS TV   ON TV.IdTipoVenta = CV.idTipoVenta --Cambio con los nuevos catalogos de tipo de venta
			--INNER JOIN Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA      AS T  ON O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS = T.Tip_Clave --Antes de modificaciones de tipo de venta
			INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D   ON O.ucu_iddepartamento = D.dep_iddepartamento
			INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S   ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
			INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM   ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
			INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV   ON EM.div_iddivision = DIV.div_iddivision
			INNER JOIN DIG_ESTATUS_EXPEDIENTE AS EE    ON EE.Estatus_Id = E.Estatus_Id -- Se agrego cuando se hizo cambio en el catalogo 
			CROSS APPLY fn_ObtenerProveedor(O.ucu_idcliente,EM.emp_idempresa) PER
     WHERE E.Folio_Operacion = @folio
	
	END


	
	
	END--BORRAR

END
go

