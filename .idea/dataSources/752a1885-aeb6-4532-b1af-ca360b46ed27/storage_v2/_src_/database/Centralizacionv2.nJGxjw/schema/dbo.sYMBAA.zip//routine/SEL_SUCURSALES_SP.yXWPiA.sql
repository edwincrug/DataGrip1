------------------------------------------------------------------------ SP SUCRSALES
CREATE PROCEDURE [dbo].[SEL_SUCURSALES_SP]
		@idempresa	  int = 0
		,@idempleado   int = 0
		
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		SELECT    distinct S.suc_nombre     AS nombre
				, S.suc_idsucursal AS idSucursal
				, S.suc_nombrecto  AS nombreCorto
		FROM   	ControlAplicaciones.dbo.cat_sucursales S
				,ControlAplicaciones.dbo.OPE_ORGANIGRAMA  Orga
		WHERE	S.emp_idempresa = Orga.emp_idempresa
				AND Orga.usu_idusuario = @idempleado
				AND Orga.emp_idempresa = @idempresa
				--AND S.suc_idsucursal = Orga.suc_idsucursal --LGV ADD 26062017 descomentar produccion release


		END TRY
		BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_SUCURSALES_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END

go

