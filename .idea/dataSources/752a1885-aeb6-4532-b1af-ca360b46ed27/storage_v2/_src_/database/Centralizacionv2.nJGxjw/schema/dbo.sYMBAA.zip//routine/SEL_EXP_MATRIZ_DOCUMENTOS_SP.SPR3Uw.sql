-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [SEL_EXP_MATRIZ_DOCUMENTOS_SP] 2, 4, 6, '2019/05/01', '2019/05/02'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_EXP_MATRIZ_DOCUMENTOS_SP]
	@proceso INT,
	@idEmpresa INT,
	@idSucursal INT,
	@fechaInicio VARCHAR(50),
	@fechaFin VARCHAR(50)
AS
BEGIN
	--DECLARE 	@proceso INT = 2,
	--@idEmpresa INT = 4,
	--@idSucursal INT = 6,
	--@fechaInicio VARCHAR(50) = '2020/07/01',
	--@fechaFin VARCHAR(50) = '2020/07/31'



	SET NOCOUNT ON;
			SELECT 
				BD.nombre_sucursal AS sucursal,
				'COTIZACIONES' AS proceso 
			FROM [DIG_CAT_BASES_BPRO] BD 
			WHERE BD.emp_idempresa = @idEmpresa AND BD.suc_idsucursal = @idSucursal

			SELECT 
				folio,
				nombre_sucursal,
				serie,
				vendedor,
				ucu_idcliente,
				NombreCliente,
				isnull(MAX([Factura Unidad]),'NO APLICA') as [FacturaUnidad],
				isnull(MAX([Factura Planta]),'NO APLICA') as [FacturaPlanta],
				isnull(MAX([Pedido Original]),'NO APLICA') as [PedidoOriginal],
				isnull(MAX([Nota de crédito]),'NO APLICA') as [Notadecredito],
				isnull(MAX([Nota de cargo]),'NO APLICA') as [Notadecargo],
				isnull(MAX([Recibo oficial de placas y tenencia]),'NO APLICA') as [Recibooficialdeplacasytenencia],
				isnull(MAX([Póliza de seguro]),'NO APLICA') as [Polizadeseguro],
				isnull(MAX([Factura de accesorios]),'NO APLICA') as [Facturadeaccesorios],
				isnull(MAX([Recibo de pago]),'NO APLICA') as [Recibodepago],
				isnull(MAX([Soporte de recibos de caja]),'NO APLICA') as [Soportederecibosdecaja],
				isnull(MAX([Pagarés o cheques]),'NO APLICA') as [Pagaresocheques],
				isnull(MAX([Copia factura seminuevo]),'NO APLICA') as [Copiafacturaseminuevo],
				isnull(MAX([IFE]),'NO APLICA') as [IFE],
				isnull(MAX([Salida de la unidad]),'NO APLICA') as [Salidadelaunidad],
				isnull(MAX([REPUVE]),'NO APLICA') as [REPUVE],
				isnull(MAX([Contrato de adhesión]),'NO APLICA') as [Contratodeadhesion],
				isnull(MAX([Formatos LFPIORPI]),'NO APLICA') as [FormatosLFPIORPI],
				isnull(MAX([Aviso de privacidad]),'NO APLICA') as [Avisodeprivacidad],
				isnull(MAX([Otros formatos]),'NO APLICA') as [Otrosformatos],
				isnull(MAX([Caratula Contrato]),'NO APLICA') as [CaratulaContrato],
				isnull(MAX([Cotización financiera]),'NO APLICA') as [Cotizacionfinanciera],
				isnull(MAX([Cotización]),'NO APLICA') as [Cotizacion],
				isnull(MAX([Solicitud de desembolso]),'NO APLICA') as [Solicituddedesembolso],
				isnull(MAX([Contrato de adhesión Autofinanciamiento]),'NO APLICA') as [ContratodeadhesionAutofinanciamiento],
				isnull(MAX([Contrato Prenda y pagare de Autofinanciamiento]),'NO APLICA') as [ContratoPrendaypagaredeAutofinanciamiento],
				isnull(MAX([Carta Conformidad del Cliente Autofinanciamiento]),'NO APLICA') as [CartaConformidaddelClienteAutofinanciamiento],
				isnull(MAX([Solicitud de Flotilla]),'NO APLICA') as [SolicituddeFlotilla],
				isnull(MAX([Autorizaciones Precio Planta]),'NO APLICA') as [AutorizacionesPrecioPlanta],
				isnull(MAX([Anticipo]),'NO APLICA') as [Anticipo],
				isnull(MAX([Orden de compra del cliente]),'NO APLICA') as [Ordendecompradelcliente],
				isnull(MAX([Carta agrupación de taxistas]),'NO APLICA') as [Cartaagrupaciondetaxistas],
				isnull(MAX([Permiso taxi]),'NO APLICA') as [Permisotaxi],
				isnull(MAX([Varios Identificación]),'NO APLICA') as [VariosIdentificacion]
				--isnull(MAX([Factura Unidad]),'') as [FacturaUnidad],
				--isnull(MAX([Factura Planta]),'') as [FacturaPlanta],
				--isnull(MAX([Pedido Original]),'') as [PedidoOriginal],
				--isnull(MAX([Nota de crédito]),'') as [Notadecredito],
				--isnull(MAX([Nota de cargo]),'') as [Notadecargo],
				--isnull(MAX([Recibo oficial de placas y tenencia]),'') as [Recibooficialdeplacasytenencia],
				--isnull(MAX([Póliza de seguro]),'') as [Polizadeseguro],
				--isnull(MAX([Factura de accesorios]),'') as [Facturadeaccesorios],
				--isnull(MAX([Recibo de pago]),'') as [Recibodepago],
				--isnull(MAX([Soporte de recibos de caja]),'') as [Soportederecibosdecaja],
				--isnull(MAX([Pagarés o cheques]),'') as [Pagaresocheques],
				--isnull(MAX([Copia factura seminuevo]),'') as [Copiafacturaseminuevo],
				--isnull(MAX([IFE]),'') as [IFE],
				--isnull(MAX([Salida de la unidad]),'') as [Salidadelaunidad],
				--isnull(MAX([REPUVE]),'') as [REPUVE],
				--isnull(MAX([Contrato de adhesión]),'') as [Contratodeadhesion],
				--isnull(MAX([Formatos LFPIORPI]),'') as [FormatosLFPIORPI],
				--isnull(MAX([Aviso de privacidad]),'') as [Avisodeprivacidad],
				--isnull(MAX([Otros formatos]),'') as [Otrosformatos],
				--isnull(MAX([Caratula Contrato]),'') as [CaratulaContrato],
				--isnull(MAX([Cotización financiera]),'') as [Cotizacionfinanciera],
				--isnull(MAX([Cotización]),'') as [Cotizacion],
				--isnull(MAX([Solicitud de desembolso]),'') as [Solicituddedesembolso],
				--isnull(MAX([Contrato de adhesión Autofinanciamiento]),'') as [ContratodeadhesionAutofinanciamiento],
				--isnull(MAX([Contrato Prenda y pagare de Autofinanciamiento]),'') as [ContratoPrendaypagaredeAutofinanciamiento],
				--isnull(MAX([Carta Conformidad del Cliente Autofinanciamiento]),'') as [CartaConformidaddelClienteAutofinanciamiento],
				--isnull(MAX([Solicitud de Flotilla]),'') as [SolicituddeFlotilla],
				--isnull(MAX([Autorizaciones Precio Planta]),'') as [AutorizacionesPrecioPlanta],
				--isnull(MAX([Anticipo]),'') as [Anticipo],
				--isnull(MAX([Orden de compra del cliente]),'') as [Ordendecompradelcliente],
				--isnull(MAX([Carta agrupación de taxistas]),'') as [Cartaagrupaciondetaxistas],
				--isnull(MAX([Permiso taxi]),'') as [Permisotaxi],
				--isnull(MAX([Varios Identificación]),'') as [VariosIdentificacion]

				--isnull(MAX([Comprobante de Domicilio]),'') as [ComprobantedeDomicilio],
				--isnull(MAX([Comprobante de Ingresos]),'') as [ComprobantedeIngresos],
				--isnull(MAX([Pedido de Refacciones]),'') as [PedidodeRefacciones],
				--isnull(MAX([Pedido de Servicio (Orden)]),'') as [PedidodeServicio],
				--isnull(MAX([Pedido de Unidades Seminuevas]),'') as [PedidodeUnidadesSeminuevas],
				--isnull(MAX([Pedido de Unidades]),'') as [PedidodeUnidades],
				--isnull(MAX([Pedido Sistema]),'') as [PedidoSistema],
				--isnull(MAX([Solicitud de Crédito]),'') as [SolicituddeCredito]
			FROM (
				SELECT 
					DISTINCT EXPDOC.[Doc_Id]
					,CD.ucn_noserie AS serie
					,U.usu_nombre + ' ' + U.usu_paterno + '  ' + U.usu_materno AS vendedor
					,EXPDOC.[Folio_Operacion] AS folio
					,CASE WHEN [Fecha_Creacion] IS NOT NULL THEN 'OK'
						  WHEN DM.idMandatorio IS NULL OR RVD.IdTipoVenta IS NULL THEN 'NO APLICA' ELSE '' END existe
					
					
					,CASE WHEN Doc_Origen = 1 THEN 'Carga Usuario' WHEN Doc_Origen = 2 AND EXPDOC.Doc_Id = 67 THEN 'Ambos'  ELSE 'Creado Sistema' END origen
					,[Doc_Nombre] AS nombre,
					CU.ucu_idcliente,
					PER_NOMRAZON + ' ' + PER_PATERNO + ' ' + PER_MATERNO AS NombreCliente,
					VW.PEN_FECHAENTREGA_REAL,
					B.nombre_sucursal
				FROM [DIG_EXPEDIENTE] E
				INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_foliocotizacion = E.Folio_Operacion COLLATE DATABASE_DEFAULT
				INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = CU.ucu_idcotizacion
				INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = CU.ucu_idusuarioalta
				INNER JOIN [DIG_EXPNODO_DOC] EXPDOC ON EXPDOC.Folio_Operacion = E.Folio_Operacion
				INNER JOIN [DIG_CATDOCUMENTO] CATDOC ON EXPDOC.Doc_Id = CATDOC.Doc_Id
				INNER JOIN [DIG_CAT_BASES_BPRO] B ON B.emp_idempresa = CU.ucu_idempresa AND B.suc_idsucursal = CU.ucu_idsucursal
				INNER JOIN GA_Corporativa.DBO.PER_PERSONAS P ON P.PER_IDPERSONA = CU.ucu_idcliente
				INNER JOIN [VW_FECHA_ENTREGA_UNIDAD] VW ON VW.PEN_NUMSERIE = CD.ucn_noserie
				INNER JOIN Centralizacionv2.dbo.DIG_CANAL_VENTA AS CV ON CV.canalVenta = CU.ucu_idtipoventa COLLATE DATABASE_DEFAULT
				LEFT JOIN Centralizacionv2.dbo.EXP_DOCUMENTOS_MANDATORIO AS DM ON DM.idTipoVenta = CV.idTipoVenta AND DM.idEmpresa = CU.ucu_idempresa AND DM.idSucursal = CU.ucu_idsucursal AND DM.Doc_Id = EXPDOC.Doc_Id 
				LEFT JOIN [Centralizacionv2].[dbo].[DIG_RELACION_VENTA_DOCUMENTOS] RVD on RVD.IdTipoVenta = CV.idTipoVenta and RVD.Doc_Id = EXPDOC.Doc_Id 
				WHERE CU.ucu_idempresa = @idEmpresa AND CU.ucu_idsucursal = @idSucursal AND EXPDOC.[Proc_Id] = 2 --AND VW.PEN_FECHAENTREGA_REAL IS NOT NULL 
				AND convert(varchar, ucu_fechacotiza, 111) BETWEEN convert(varchar, @fechaInicio, 111) AND convert(varchar, @fechaFin, 111)
				) x
				PIVOT
				(
					MAX(existe)
					FOR nombre in (
					[Factura Unidad],
					[Factura Planta],
					[Pedido Original],
					[Nota de crédito],
					[Nota de cargo],
					[Recibo oficial de placas y tenencia],
					[Póliza de seguro],
					[Factura de accesorios],
					[Recibo de pago],
					[Soporte de recibos de caja],
					[Pagarés o cheques],
					[Copia factura seminuevo],
					[IFE],
					[Salida de la unidad],
					[REPUVE],
					[Contrato de adhesión],
					[Formatos LFPIORPI],
					[Aviso de privacidad],
					[Otros formatos],
					[Caratula Contrato],
					[Cotización financiera],
					[Cotización],
					[Solicitud de desembolso],
					[Contrato de adhesión Autofinanciamiento],
					[Contrato Prenda y pagare de Autofinanciamiento],
					[Carta Conformidad del Cliente Autofinanciamiento],
					[Solicitud de Flotilla],
					[Autorizaciones Precio Planta],
					[Anticipo],
					[Orden de compra del cliente],
					[Carta agrupación de taxistas],
					[Permiso taxi],
					[Varios Identificación]

					--[Comprobante de Domicilio],
					--[Comprobante de Ingresos],
					--[Pedido de Refacciones],
					--[Pedido de Servicio (Orden)],
					--[Pedido de Unidades Seminuevas],
					--[Pedido de Unidades],
					--[Pedido Sistema],
					--[Solicitud de Crédito]
					) )AS p
					GROUP BY folio, nombre_sucursal, serie, vendedor, ucu_idcliente, NombreCliente
			END


go

