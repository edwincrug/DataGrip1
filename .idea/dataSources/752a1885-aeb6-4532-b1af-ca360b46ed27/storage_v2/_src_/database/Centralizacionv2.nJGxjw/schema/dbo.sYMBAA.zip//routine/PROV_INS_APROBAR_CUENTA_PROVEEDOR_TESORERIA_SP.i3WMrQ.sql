
--exec PROV_INS_APROBAR_CUENTA_PROVEEDOR_TESORERIA_SP @rfc='TOJV8505052GA',@idUsuario=88,@idPerTra=54
-- [PROV_INS_APROBAR_CUENTA_PROVEEDOR_TESORERIA_SP] 'TOJV8505052GA',71,50
CREATE PROCEDURE [dbo].[PROV_INS_APROBAR_CUENTA_PROVEEDOR_TESORERIA_SP] -- 
 @rfc VARCHAR(50) 
,@idUsuario VARCHAR(50) 
,@idPerTra INT
AS
BEGIN
--DECLARE @rfc VARCHAR(50)  = 'TOJV8505052GA'
--,@idUsuario INT  = 88
--,@idPerTra INT = 54
BEGIN TRY
BEGIN TRANSACTION
	
	
	/***************UNIFICAR CUENTAS*******************************/
		DECLARE @BASES TABLE(id int identity(1,1),emp_idempresa INT,base nvarchar(200))
		DECLARE @contBases INT = 1, @numRegistros INT = 0, @contBancos INT = 1, @banxico VARCHAR(20), @numRegistrosCuentas INT = 0, @cveBanco VARCHAR(10)='',@emp_idempresa INT,  @idRespuestaUni   INT, @cie VARCHAR(50), @noCuenta VARCHAR(50)
		DECLARE @basePrincipal VARCHAR(50) = '', @queryCuentaSel NVARCHAR(MAX) = '', @queryBanco NVARCHAR(MAX) = '', @SQLString NVARCHAR(MAX), @sqlUni VARCHAR(MAX)
		DECLARE @ParmDefinition nvarchar(500) , @usuario VARCHAR(20)
		
		--SELECT  @usuario = usu_nombreusu 
		--FROM	ControlAplicaciones.dbo.Cat_usuarios 
		--WHERE	usu_idusuario  = @idUsuario

		select  @usuario = eqv_usubusiness  from controlAplicaciones.dbo.eqv_organigrama where usu_usuario = @idUsuario

		DECLARE  @idPersona NUMERIC(18,0)
		--SELECT  PER_IDPERSONA,* FROM GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfc
		SELECT  @idPersona = PER_IDPERSONA FROM GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfc order by PER_IDPERSONA asc
		--select @idPersona
		--select BCO_IDPERSONA, count(1)  from GAZM_Concentra.dbo.CON_BANCOS group by BCO_IDPERSONA
		--select BCO_IDPERSONA, count(1)  from GAAU_Concentra.dbo.CON_BANCOS group by BCO_IDPERSONA

		DECLARE @provBanco TABLE (
				id int identity(1,1),
				[idProspecto] [int] NULL,
				[titular] [varchar](100) NULL,
				[banco] [varchar](50) NULL,
				[sucursal] [varchar](50) NULL,
				[noCuenta] [varchar](30) NULL,
				[clabe] [varchar](30) NULL,
				[cie] [varchar](10) NULL,
				[referencia] [varchar](50) NULL,
				[cveBanxico] [varchar](10) NULL,
				[cveBanco] [varchar](50) NULL,
				[tipoCtaBancaria] [varchar](20) NULL,
				[nombreTipoCtaBancaria] [varchar](50) NULL,
				[empresaId] [int] NULL
			)

		INSERT INTO @BASES
		SELECT emp_idempresa ,nombre_base  FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 

		SET @numRegistros = (select COUNT(1) from @BASES)

		INSERT INTO @provBanco
		SELECT 
			  [idProspecto]
			  ,[titular]
			  ,[banco]
			  ,[sucursal]
			  ,[noCuenta]
			  ,[clabe]
			  ,[cie]
			  ,[referencia]
			  ,[cveBanxico]
			  ,[cveBanco]
			  ,[tipoCtaBancaria]
			  ,[nombreTipoCtaBancaria]
			  ,[empresaId]
		  FROM [dbo].[PROV_CUENTA_BANCARIA]
		  WHERE rfcProspecto = @rfc AND aprobada is null


		  SET  @numRegistrosCuentas = (select  COUNT(1) from @provBanco)


		  WHILE(@contBancos<= @numRegistrosCuentas)
		  BEGIN
			--SELECT @contBancos '@contBancos'
			SET @contBases  = 1
				select @banxico = cveBanxico, @cie = cie, @noCuenta = noCuenta FROM @provBanco WHERE id = @contBancos
				--select @banxico, @cie, @noCuenta
				
				WHILE(@contBases<= @numRegistros)
				BEGIN
				
					
					SELECT @basePrincipal = base, @emp_idempresa = emp_idempresa FROM @BASES WHERE id = @contBases
					--select @basePrincipal
					IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @basePrincipal)) 
					BEGIN
						--SELECT @basePrincipal
						SET @cveBanco = ''
						SET @SQLString = 'IF EXISTS (SELECT 1 from ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''') BEGIN    SELECT @res= PAR_IDENPARA FROM ' + @basePrincipal+'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A'' AND PAR_DESCRIP5 ='''+ @banxico+''' END '
						SET @ParmDefinition = N' @res VARCHAR(10) OUTPUT'; 
						--select * from GAZM_Concentra.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = 'BA' AND PAR_STATUS = 'A' AND PAR_DESCRIP5 = '072'
						
						
						EXECUTE sp_executesql @SQLString, @ParmDefinition, @res= @cveBanco OUTPUT
						
						
						IF( @cveBanco !='')
						BEGIN
							
							SET @sqlUni = ' IF EXISTS(SELECT 1 FROM '+@basePrincipal+'.[dbo].[CON_BANCOS] WHERE BCO_NUMCUENTA ='''+ @noCuenta+''' AND BCO_IDPERSONA = '+CONVERT(VARCHAR(10),@idPersona)+')
											BEGIN 
												UPDATE  ' +@basePrincipal+'.[dbo].[CON_BANCOS] SET 
													  BCO_AUTORIZADA = 1
													, BCO_CVEUSU = ''' + @usuario+ '''
													, BCO_FECHOPE = CONVERT(VARCHAR(10), GETDATE(),103)
													, BCO_HORAOPE = CONVERT(CHAR(8), GETDATE(), 108)    
												WHERE  BCO_NUMCUENTA ='''+ @noCuenta+''' AND BCO_IDPERSONA = '+CONVERT(VARCHAR(10),@idPersona)+'
											END
											ELSE
											BEGIN
										INSERT INTO ' +@basePrincipal+'.[dbo].[CON_BANCOS]
													 ([BCO_IDPERSONA]
													 ,[BCO_BANCO]
													 ,[BCO_PLAZA]
													 ,[BCO_SUCURSAL]
													 ,[BCO_STATUS]
													 ,[BCO_TIPCUENTA]
													 ,[BCO_NUMCUENTA]
													 ,[BCO_CLABE]
													 ,[BCO_CVEUSU]
													 ,[BCO_FECHOPE]
													 ,[BCO_HORAOPE]
													 ,[BCO_REFERNUM]
													 ,[BCO_REFERALF]
													 ,[BCO_CONVENIOCIE]
													 ,[BCO_AUTORIZADA]) 
									   	SELECT '+ CONVERT(VARCHAR(10),@idPersona)+ '
												,'''+@cveBanco+'''
												,''1''
												,ISNULL(sucursal,''1'')
												,''ACTIVO''
												,tipoCtaBancaria
												,noCuenta
												,clabe
												,''' + @usuario+ '''
												,CONVERT(VARCHAR(10), GETDATE(),103)
												,CONVERT(CHAR(8), GETDATE(), 108) 
												,ISNULL(referencia,'''')
												,''''
												,cie
												,1 
										FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
										INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_RFC  = CB.rfcProspecto
										WHERE CB.cveBanxico = '''+ @banxico +''' AND idPerTra = '+CONVERT(VARCHAR(10),@idPerTra) +' AND rfcProspecto = '''+@rfc+''' END' 

							--SELECT (@sqlUni)
							EXEC (@sqlUni)
						--	SELECT @emp_idempresa
						EXEC Pagos.[dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP] @idProveedor =@idPersona , @cuenta =@noCuenta ,	@convenio = @cie, @idEmpresa =  @emp_idempresa,@idUsuario = @idUsuario, @result = @idRespuestaUni OUTPUT
						--SELECT @idRespuestaUni 'Unifica'
						SET	@contBases = @numRegistros
						END
						ELSE 
						BEGIN
							SET @contBases= @contBases+1  
						END
					END
					

					
						BEGIN
							SET @contBases= @contBases+1 
						END
				END
				SET @contBancos = @contBancos+1
		  END

		 -- SELECT * from  GAAU_Concentra.[dbo].[CON_BANCOS]  WHERE BCO_IDPERSONA =@idPersona
		 
		  UPDATE PROV_CUENTA_BANCARIA 
		  SET	aprobada = 1
				,autorizada = 1
				,PER_IDPERSONA = @idPersona
		  WHERE rfcProspecto= @rfc
		  AND idPerTra = @idPerTra 

		  --UPDATE PROV_CUENTA_BANCARIA 
		  --SET aprobada = 1
		  --WHERE rfcProspecto= @rfc



		  DECLARE @cont INT = 1
				, @idRespuesta   NUMERIC(18,0)
				, @msg VARCHAR(MAX) = ''
				, @cuenta VARCHAR(500)
				, @nombreProveedor VARCHAR(100) = (SELECT TOP 1 'Proveedor: '+ ISNULL(PER_NOMRAZON,'')+' '+ ISNULL(PER_PATERNO,'')+ ' '+ ISNULL(PER_MATERNO,'') + ' RFC : '+ ISNULL(PER_RFC,'') from 	 GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfc)
				,@email VARCHAR(100) = (SELECT correo FROM CENTRALIZACIONv2.DBO.PPRO_USERSPORTALPROV WHERE ppro_user = @rfc)
				
			--SELECT @email

		

		
		
		
		DECLARE  @usuario_Autoriza INT
				,@usuarioCorreoAutoriza VARCHAR(250)

		
		SELECT	 @usuario_Autoriza= usuario_autoriza
				,@usuarioCorreoAutoriza = usu_correo 
		FROM	Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION N 
		INNER JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT F ON N.idTipoNotificacion = F.idTipoNotificacion
		INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = F.usuario_autoriza
		WHERE	N.idTipoNotificacion = 4 
		AND		nivel_escalamiento = 0
				


		  SELECT 1 result, @email email, @usuarioCorreoAutoriza usuarioCorreoAutoriza

		  /***** Cambiar el estatus de la notificacion ****/
	DECLARE  @not_id NUMERIC(18,0)	
			,@idAprobacion NUMERIC(18,0)	
	SELECT @not_id =  N.not_id  from Notificacion.dbo.Not_Notificacion N
	inner join Notificacion.dbo.not_aprobacion A on N.not_id = A.not_id
	where not_adjunto = Convert(varchar(20),@idPerTra) and not_estatus = 2 AND not_identificador = @rfc AND not_agrupacion = 23 and emp_id =@idUsuario


	SELECT @idAprobacion = apr_id from Notificacion.dbo.NOT_APROBACION where not_id = @not_id
	

	--- Cambio estatus de notificacion
	UPDATE Notificacion.dbo.NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = @not_id --(SELECT not_id FROM Notificacion.dbo.NOT_APROBACION WHERE apr_id = @idAprobacion)
	UPDATE Notificacion.dbo.NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion
		
	----------------------------------------------------------------
	-------Inserta una respuesta de aprobación
	----------------------------------------------------------------
	INSERT INTO Notificacion.dbo.[NOT_APROBACION_RESPUESTA]									
		(not_id,[apr_id],[nar_fecha],[nar_comentario])
	VALUES
		(@not_id,@idAprobacion,GETDATE(),'Se aprueba Trámite')	
	----------------------------------
				


COMMIT TRANSACTION
END TRY
BEGIN CATCH
ROLLBACK TRANSACTION



		SELECT -1 result, '' email, '' usuarioCorreoAutoriza


END CATCH
   
END

go

