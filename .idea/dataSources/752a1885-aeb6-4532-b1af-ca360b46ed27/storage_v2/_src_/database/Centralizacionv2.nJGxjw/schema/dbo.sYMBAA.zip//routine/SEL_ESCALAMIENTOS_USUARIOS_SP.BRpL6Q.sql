-- =============================================
-- Author: Genaro Mora Valenca
-- Create date: 11/12/2015
-- Description: Recupera todod los registros de escalamiento
-- =============================================
-- [SEL_ESCALAMIENTOS_USUARIOS_SP] 1,1,1,3,13,1
CREATE PROCEDURE [dbo].[SEL_ESCALAMIENTOS_USUARIOS_SP] 
	@procId INT = NULL,
	@usuarioidusuario INT = null,
	@empidempresa INT = null,
	@sucidsucursal INT = null,
	@depiddepartamento INT = null,
	@tipoidtipoorden INT = null
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY		
		
		SELECT 		
			   die.Nivel_Escalamiento AS nivelEscalamiento			  
			  ,die.Usuario_Autoriza1 AS idusuarioAutoriza1			  
			  ,UC1.usu_nombreusu +  ' ' + UC1.usu_paterno + ' ' + UC1.usu_materno AS nomusuarioAutoriza1			   	  
			  ,die.Usuario_Autoriza2 AS idusuarioAutoriza2	
			  ,UC2.usu_nombreusu +  ' ' + UC2.usu_paterno + ' ' + UC2.usu_materno AS nomusuarioAutoriza2			  			  
			  ,die.Usuario_Autoriza3 AS idusuarioAutoriza3			  			  
			  ,UC3.usu_nombreusu +  ' ' + UC3.usu_paterno + ' ' + UC3.usu_materno AS nomusuarioAutoriza3			  		  
			  ,die.Minutos_Escalar AS inutosEscalar
		 FROM DIG_PERFIL_ESCALAMIENTO AS dge	 
		INNER JOIN [dbo].[DIG_ESCALAMIENTO] AS die ON dge.emp_idempresa=@empidempresa
		AND dge.Proc_Id=@procId
		AND dge.suc_idsucursal = @sucidsucursal
		AND dge.dep_iddepartamento = @depiddepartamento
		AND dge.tipo_idtipoorden = @tipoidtipoorden		
		LEFT JOIN [dbo].[Usuario_ControlAplicaciones] UC1 on UC1.usu_idusuario = die.Usuario_Autoriza1
		LEFT JOIN [dbo].[Usuario_ControlAplicaciones] UC2 on UC2.usu_idusuario = die.Usuario_Autoriza2
		LEFT JOIN [dbo].[Usuario_ControlAplicaciones] UC3 on UC3.usu_idusuario = die.Usuario_Autoriza3					
		WHERE die.suc_idsucursal = COALESCE(@sucidsucursal,die.suc_idsucursal)
		AND die.dep_iddepartaamento = COALESCE(@depiddepartamento,die.dep_iddepartaamento)
		AND die.tipo_idtipoorden = COALESCE(@tipoidtipoorden,die.tipo_idtipoorden)
		AND dge.usuario_idusuario = COALESCE(@usuarioidusuario,dge.usuario_idusuario)
				
	END TRY
	BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_EMPLEADO_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	END CATCH
END


go

