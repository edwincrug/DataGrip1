
CREATE FUNCTION [dbo].[Split]
(
    @String AS VARCHAR(2048), 
    @Separator AS CHAR(1),
    @COUNT AS INT
)
RETURNS TABLE
AS
RETURN
( 
  SELECT TOP (ISNULL(@COUNT, 2147483647))
    SUBSTRING(
        @String,
        NUMBER, 
        CHARINDEX(@Separator, @String + @Separator, NUMBER) - NUMBER
        ) AS [SUBSTRING]
  FROM
    master..spt_values
  WHERE 
    [TYPE]='P'
    AND NUMBER BETWEEN 1 AND LEN(@String) + 1 
    AND SUBSTRING(@Separator + @String, NUMBER, 1) = @Separator
)
go

