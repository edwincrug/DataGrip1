-- =============================================
-- Author: Mario Arturo Mejía Ramírez
-- Create date: 15/12/2015
-- Description:	Procedimiento para eliminar los Usuarios Mancomunados.
---[DEL_ESCALAMIENTO_PARAM_SP] 34
-- =============================================
CREATE PROCEDURE [dbo].[DEL_ESCALAMIENTO_PARAM_SP]
	@Escalamiento_Id int	
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
			DELETE FROM dbo.[DIG_ESCALAMIENTO_PARAMETROS]	
			WHERE Escalamiento_Id = @Escalamiento_Id		   
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[DEL_ESCALAMIENTO_PARAMETROS]'
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT ERROR_NUMBER()
END CATCH
END

go

