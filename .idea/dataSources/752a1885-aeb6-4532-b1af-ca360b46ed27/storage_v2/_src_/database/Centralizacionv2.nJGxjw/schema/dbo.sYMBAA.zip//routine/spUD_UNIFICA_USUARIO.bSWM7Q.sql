
/*
Unifica usuarios repetidos:
Sirve para dejar concentrado en un solo usuario los permisos y accesos a Digitalizacion cuando
se tienen más de un usuario. Uno por cada base de datos.
ejemplo: 
22RSI y 23RSI
*/
CREATE PROCEDURE [dbo].[spUD_UNIFICA_USUARIO](@sUsr3LetrasSeQueda varchar(10), @sUsr3LetrasSeBorra varchar(10)) --with recompile
 AS
declare
@iIdUsuarioSeQueda int,
@iIdUsuarioDesaparece int
begin 
set nocount on

select @iIdUsuarioSeQueda    = isnull(usu_idusuario,0) from ControlAplicaciones..cat_usuarios where usu_nombreusu=@sUsr3LetrasSeQueda 
select @iIdUsuarioDesaparece = isnull(usu_idusuario,0) from ControlAplicaciones..cat_usuarios where usu_nombreusu=@sUsr3LetrasSeBorra 

if (@iIdUsuarioSeQueda > 0 and @iIdUsuarioDesaparece > 0)
begin
--Inicia transaccion
			BEGIN TRANSACTION TRAN_PROPAGA
			BEGIN TRY
			    print 'Unificando equivalencias el usuario que se queda hereda las equivalencias del usuairo que se elimina.'
				update ControlAplicaciones..eqv_organigrama set usu_usuario=@iIdUsuarioSeQueda  where usu_usuario = @iIdUsuarioDesaparece 
				print 'Unificando acceso a los departamentos de las agencias, el usuario que se queda hereda el acceso a los deptos del que se elimina'
				update ControlAplicaciones..ope_organigrama set usu_idusuario = @iIdUsuarioSeQueda where usu_idusuario = @iIdUsuarioDesaparece  
				print 'Transferimos las notificaciones del usuario que se va al usuario que se queda'
				update Notificacion..NOT_APROBACION set emp_id=@iIdUsuarioSeQueda where emp_id=@iIdUsuarioDesaparece
				print 'Transferimos las ordenes de compra del usuario que se va al que se queda'
				update cuentasxpagar..cxp_ordencompra set oce_idusuario=@iIdUsuarioSeQueda where oce_idusuario=@iIdUsuarioDesaparece
				print 'Transferimos los movimientos en el log. del usuario que se va al que se queda'
				update cuentasxpagar..cxp_movimientosorden set mov_idusuariomovimiento = @iIdUsuarioSeQueda where mov_idusuariomovimiento = @iIdUsuarioDesaparece
				-----
				--select top   1000 * from cuentasporcobrar..par_pedmostdet where pmd_idusuarioalta = 71
				--select top   1000 * from GAZM_Zaragoza..par_pedmostdet where pmd_idusuarioalta = 71
				--print 'Transferimos las autorizaciones especiales del usuario que se va al que se queda'
				--update cuentasporcobrar..UNI_AutorizacionEspecial set UAE_IdUsuarioAutoriza = @iIdUsuarioSeQueda   where UAE_IdUsuarioAutoriza = @iIdUsuarioDesaparece 
				--update cuentasporcobrar..UNI_AutorizacionEspecial set UAE_IdUsuarioSolicita  = @iIdUsuarioSeQueda   where UAE_IdUsuarioSolicita  = @iIdUsuarioDesaparece 
				--print 'Transferimos las autorizaciones de CC del usuario que se va al que se queda'
				--update cuentasporcobrar..UNI_CCS set ucc_usuarioalta = @iIdUsuarioSeQueda where ucc_usuarioalta = @iIdUsuarioDesaparece
				--update cuentasporcobrar..UNI_CCS set ucc_usuariomodifica = @iIdUsuarioSeQueda where ucc_usuariomodifica = @iIdUsuarioDesaparece
				--print 'Transferimos las CotizacionesUniversales del usuario que se va al que se queda'
				--update cuentasporcobrar..uni_cotizacionuniversal set ucu_idusuarioalta = @iIdUsuarioSeQueda where ucu_idusuarioalta = @iIdUsuarioDesaparece
				--update cuentasporcobrar..uni_cotizacionuniversal set ucu_idusuariomodifica = @iIdUsuarioSeQueda where ucu_idusuariomodifica = @iIdUsuarioDesaparece
				--update cuentasporcobrar..uni_cotizacionuniversal set ucu_idagente  = @iIdUsuarioSeQueda where ucu_idagente = @iIdUsuarioDesaparece
				--update cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES set ucn_idusuarioalta = @iIdUsuarioSeQueda where ucn_idusuarioalta = @iIdUsuarioDesaparece
				--update cuentasporcobrar..UNI_COTIZACIONUNIVERSALUNIDADES set ucn_idausuariomodifica = @iIdUsuarioSeQueda where ucn_idausuariomodifica = @iIdUsuarioDesaparece
				------
				print 'Transferimos permisos del usuario que se va al usuario que se queda.'
				Execute Centralizacionv2.[dbo].[UP_DIG_SUSTITUYEPERMISOS_SP] @iIdUsuarioDesaparece,@iIdUsuarioSeQueda,'NO' --NO significa que no pondrá al usuario que se va como segundo autorizador.
				print 'Eliminando acceso a menu CXP, CXC , Panel de Aplicaciones del usuario que se elimina'
				delete ControlAplicaciones..rel_usuarioperfil where usu_idusuario=@iIdUsuarioDesaparece 
				print 'Eliminando acceso a Menu de digitalizacion del usuario que se va elimina'
				delete Seguridad..SEG_USUARIO_PERFIL where sup_idUsuario = @iIdUsuarioDesaparece 
				print 'Respaldando al usuario que se eliminará: ' + Convert(char(10),@iIdUsuarioDesaparece)
				insert into Centralizacionv2.[dbo].[DIG_CAT_USUDEPURACION] ([usu_idusuario],[gpo_idgrupo],[div_iddivision],[emp_idempresa],[suc_idsucursal],[dep_iddepartamento],[usu_nombreusu],[usu_paterno],[usu_materno],[usu_nombre],[usu_correo],[usu_contrasenia],[pto_idpuesto],[usu_fechaalta],[usu_usualta],[usu_fechamodifica],[usu_usumodifica],[usu_estatus],[usu_passbpro])
				select [usu_idusuario],[gpo_idgrupo],[div_iddivision],[emp_idempresa],[suc_idsucursal],[dep_iddepartamento],[usu_nombreusu],[usu_paterno],[usu_materno],[usu_nombre],[usu_correo],[usu_contrasenia],[pto_idpuesto],[usu_fechaalta],[usu_usualta],[usu_fechamodifica],[usu_usumodifica],[usu_estatus],[usu_passbpro] from ControlAplicaciones..cat_usuarios where usu_idusuario = @iIdUsuarioDesaparece 
				print 'Eliminando al usuario: ' + Convert(char(10),@iIdUsuarioDesaparece) + ' : ' + @sUsr3LetrasSeBorra
				delete ControlAplicaciones..cat_usuarios where usu_idusuario= @iIdUsuarioDesaparece
				insert into Centralizacionv2..DIG_BITACORA (fecha,que,quien,aquien)
				values (getdate(),'Unificacion de usuario desaparece: ' + rtrim(ltrim(Convert(char(10),@iIdUsuarioDesaparece))) + ' - ' + @sUsr3LetrasSeBorra + ' en el usuario: ' + ltrim(rtrim(Convert(char(10),@iIdUsuarioSeQueda))),'[spUD_UNIFICA_USUARIO]', rtrim(ltrim(Convert(char(10),@iIdUsuarioDesaparece))) + ' - ' + @sUsr3LetrasSeBorra)     				  
			--damos commit a la transaccion
			COMMIT TRANSACTION TRAN_PROPAGA
				print 'EL USUARIO : ' + ltrim(rtrim(Convert(char(10),@iIdUsuarioDesaparece))) + ' : ' + @sUsr3LetrasSeBorra + ' FUE UNIFICADO CORRECTAMENTE EN EL USUARIO: ' + ltrim(rtrim(Convert(char(10),@iIdUsuarioSeQueda))) + ' : ' + @sUsr3LetrasSeQueda
			END TRY
			BEGIN CATCH				
				--rollback a la transaccion
				ROLLBACK TRANSACTION TRAN_PROPAGA		
				DECLARE @Mensaje  nvarchar(max)		
				SELECT @Mensaje = ERROR_MESSAGE() + ' Error al unificar usuario NO se hizo nada' 		
				SELECT  ERROR_NUMBER() 
				print @Mensaje
			END CATCH
end
else
begin
     print 'Alguno de los dos usuarios proporcionados no existe verifique'
end
     	     
set nocount off
end

/*
Declare @sUsr3LetrasSeQueda varchar(10) = '22RSI'
Declare @sUsr3LetrasSeBorra varchar(10) = '23RSI'

Execute Centralizacionv2.[dbo].[spUD_UNIFICA_USUARIO] @sUsr3LetrasSeQueda, @sUsr3LetrasSeBorra

Select * from ControlAplicaciones..cat_usuarios where usu_nombreusu='22RSI' 
Select * from ControlAplicaciones..cat_usuarios where usu_nombreusu='23RSI'

select * from Centralizacionv2..DIG_CATALOGOS where cat_valor = '2275' --'2328'

*/
go

