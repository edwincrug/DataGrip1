
CREATE PROCEDURE [dbo].[PROV_SEL_VALIDARFC_SP] --'AAA091014835'
@rfc VARCHAR(15)
AS
BEGIN

	IF EXISTS(select 1 from [192.168.20.29].[GAAA_Azcapo].[dbo].[per_incumplidassat] WHERE inc_rfc = @rfc)
	BEGIN

		SELECT 1 result  
	
	END
	ELSE
	BEGIN
		SELECT 0 result  
	END

END
go

