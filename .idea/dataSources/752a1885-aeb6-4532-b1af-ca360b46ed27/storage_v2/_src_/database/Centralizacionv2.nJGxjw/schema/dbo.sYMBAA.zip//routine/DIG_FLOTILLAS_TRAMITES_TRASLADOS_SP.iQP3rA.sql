-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <29/06/2020>
-- Description:	<TRae los traslados y trae los tramites>
-- DIG_FLOTILLAS_TRAMITES_TRASLADOS_SP 88844
-- =============================================
CREATE PROCEDURE [dbo].[DIG_FLOTILLAS_TRAMITES_TRASLADOS_SP]
	@idDetalleCotizacion INT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @TempTraslados Table (id INT IDENTITY, idOrdenCompra VARCHAR(100), idEmpresa INT, idSucursal INT);
	DECLARE @tempTraladosOc TABLE (id INT IDENTITY, ordenCompra VARCHAR(100))
	DECLARE @maxId INT, @minId INT, @count INT = 1;

	SELECT 
		UAW_FOLIOORDENCOMPRAOT AS Folio_Operacion,
		uaw_descripcion
	FROM cuentasporcobrar.dbo.uni_anticiposweb 
	WHERE ucn_idcotizadetalle = @idDetalleCotizacion AND UAW_FOLIOORDENCOMPRAOT IS NOT NULL

	INSERT INTO @TempTraslados
	SELECT 
		tra_ordencompra AS Folio_Operacion,
		tra_idempresa,
		tra_idsucursal
	FROM cuentasxpagar.dbo.flo_traslados 
	WHERE tra_idcotizadetalle = @idDetalleCotizacion AND tra_ordencompra IS NOT NULL

	SELECT 
		@maxId = MAX(id),
		@minId = MIN(id) 
	FROM @TempTraslados

	WHILE(@count <= @minId)
		BEGIN
			DECLARE @bd VARCHAR(100) = '', @idEmpresa INT = 0, @idSucursal INT = 0, @idOrdenCompra INT = 0, @query VARCHAR(MAX) = '';

			SELECT 
				@idEmpresa = idEmpresa,
				@idSucursal = idSucursal,
				@idOrdenCompra = idOrdenCompra
			FROM @TempTraslados WHERE id = @count

			SELECT 
				@bd = nombre_base
			FROM DIG_CAT_BASES_BPRO 
			WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal

			SET @query = 'SELECT poc_factura FROM ' + @bd + '.DBO.CON_PEDOTROS WHERE poc_idpedido = ' + CONVERT(varchar(500), @idOrdenCompra); 

			INSERT INTO @tempTraladosOc
			EXEC(@query)

			SET @count = @count + 1;
		END

	SELECT
		ordenCompra AS Folio_Operacion 
	FROM @tempTraladosOc
END
go

