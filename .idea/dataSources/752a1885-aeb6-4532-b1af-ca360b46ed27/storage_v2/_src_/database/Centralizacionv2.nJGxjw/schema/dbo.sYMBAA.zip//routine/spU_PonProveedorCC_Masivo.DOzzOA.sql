/*


Esta pensado en que se ejecute bajo una tarea programada el primer día de cada mes
a las 00:05 a.m.

Declare @iError int = 0 ;
Execute Centralizacionv2.dbo.spU_PonProveedorCC_Masivo @iError OUTPUT
print Convert(char(2),@iError);

--PARA CUANDO NO TIENE DECLARADO EL PARAMETRO
--insert into GAZM_Abasto.dbo.PNC_PARAMETR (PAR_TIPOPARA, PAR_IDENPARA,         PAR_IDMODULO, PAR_DESCRIP1,PAR_DESCRIP2,PAR_DESCRIP3,PAR_DESCRIP4,PAR_DESCRIP5,PAR_STATUS,PAR_IMPORTE1,PAR_IMPORTE2,PAR_IMPORTE3,PAR_IMPORTE4,PAR_IMPORTE5,PAR_FECHA1, PAR_FECHA2, PAR_FECHA3,PAR_HORA1, PAR_HORA2, PAR_HORA3, PAR_CVEUSU, PAR_FECHOPE, PAR_HORAOPE)
Select PAR_TIPOPARA, '2019' + substring(PAR_IDENPARA,5,4), PAR_IDMODULO, PAR_DESCRIP1,PAR_DESCRIP2,PAR_DESCRIP3,PAR_DESCRIP4,PAR_DESCRIP5,PAR_STATUS,PAR_IMPORTE1,PAR_IMPORTE2,PAR_IMPORTE3,PAR_IMPORTE4,PAR_IMPORTE5,PAR_FECHA1, PAR_FECHA2, PAR_FECHA3,PAR_HORA1, PAR_HORA2, PAR_HORA3, PAR_CVEUSU, PAR_FECHOPE, PAR_HORAOPE from GAZM_Abasto.dbo.PNC_PARAMETR where par_tipopara='MCERRCON' AND substring(PAR_IDENPARA,1,4) = '2018' 

--VIENDO COMO QUEDARON LOS REGISTROS
Select PAR_IMPORTE1,* from GAZM_Zaragoza..PNC_PARAMETR where PAR_TIPOPARA = 'Ccsconf'
select * from Centralizacionv2..DIG_PROVCCS where nombre_bd = 'GAZM_Zaragoza'
*/

CREATE PROCEDURE [dbo].[spU_PonProveedorCC_Masivo](@iResultado int OUTPUT) --with recompile
 AS
declare
@sBase varchar(200),
@situa varchar(20),
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500)

begin 
set nocount on


CREATE TABLE #BasesDeDatosEnEsteServidor
(
  POSICION [int] IDENTITY (1, 1), 
  nombreBD varchar(300)
)

insert into #BasesDeDatosEnEsteServidor (nombreBD)
SELECT nombre_bd FROM Centralizacionv2..DIG_PROVCCS  

Declare @iIndice int = 1;
Declare @iTope int = 0;
Declare @sAuxFecha varchar(10);
Declare @sHoy varchar(10);
Declare @sAnio varchar(4);
Declare @sMes varchar(2);
Declare @sPrimerDiaMesActual varchar(10);
Declare @iProveedor int = 0;

declare @mydate datetime
set dateformat dmy;
SELECT @mydate = GETDATE();

select @iTope = Isnull(Max(POSICION),0) from #BasesDeDatosEnEsteServidor

--queda en formato dd/mm/yyyy
SELECT @sAuxFecha = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(@mydate)-1),@mydate),103) --, 'Primer día del mes corriente'
select @sAnio = substring(@sAuxFecha,7,4);
select @sMes = substring(@sAuxFecha,4,2);
select @sPrimerDiaMesActual = @sAuxFecha

--print 'fecha del primer dia del mes actual:' + @sAuxFecha
--print 'Anio: ' + @sAnio
--print 'Mes: ' + @sMes

SELECT @sHoy = CONVERT(VARCHAR(25),@mydate,103) --AS Date_Value, 'Hoy' AS Date_Type
--select @sPrimerDiaMesActual = '01/03/2019'
--SELECT @sHoy = '01/03/2019'

if (ltrim(rtrim(@sPrimerDiaMesActual)) = ltrim(rtrim(@sHoy)) )
begin
			WHILE  (@iIndice <= @iTope)    ---EXISTS (Select * from #Pagas)		
				 begin
						SET ROWCOUNT 1 
			   				Select @sBase=nombreBD FROM #BasesDeDatosEnEsteServidor where POSICION = @iIndice		     						
	  					SET ROWCOUNT 0                               
						Declare @iErrorLocal int = 0;
						select @iProveedor = 0;

						set @sQ = N'Select @iiProveedor  = isnull(mes' + ltrim(rtrim(Convert(char(2),Month(GETDATE())))) + ',0)' 
						--set @sQ = N'Select @iiProveedor  = isnull(mes3,0)' 
						set @sQ = @sQ + N' from Centralizacionv2..DIG_PROVCCS ' 
						set @sQ = @sQ + N' where nombre_bd=' + char(39) + @sBase + char(39) 
						--print @sQ
						set @sParmDefinition = N'@iiProveedor int OUTPUT'
						execute sp_executesql @sQ,@sParmDefinition, @iiProveedor = @iProveedor OUTPUT
						if (@iProveedor<>0)
						begin
							Execute [Centralizacionv2].[dbo].[spU_PonProveedorCCXBase]  @sBase,@iProveedor,@sMes,@iErrorLocal OUTPUT
							if (@iErrorLocal=0)
							  begin
								print 'Se Proceso: ' + @sBase + ' ' + @sMes  + ' ' + ltrim(rtrim(Convert(char(10),@iProveedor)))
							  end
							else
							  begin
								print 'No se establecio : ' + @sBase + ' ' + @sMes + ' ' + ltrim(rtrim(Convert(char(10),@iProveedor)))
							  end
						end -- de que hay establecido un valor para el proveedor
						else
						begin
						   print 'No hay proveedor registrado para este mes: ' + @sBase + ' ' + @sMes + ' ' + ltrim(rtrim(Convert(char(10),@iProveedor)))
						end

						select @iResultado = @iResultado + @iErrorLocal; 
						select @iIndice = @iIndice + 1; 		    
				 end -- Del while principal sobre cada Base de Datos.
end
 else
   begin
     print 'Hoy: ' + @sHoy + ' no es el primer día del mes : ' + @sPrimerDiaMesActual + ' no se hizo nada'
   end
Return @iResultado

set nocount off
end


/*

Declare @mydate datetime
set dateformat dmy;
SELECT @mydate = GETDATE()
SELECT CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(@mydate)),@mydate),103) ,
'Último día del mes anterior'
UNION
SELECT CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(@mydate)-1),@mydate),103) AS Date_Value,
'Primer día del mes corriente' AS Date_Type
UNION
SELECT CONVERT(VARCHAR(25),@mydate,103) AS Date_Value, 'Hoy' AS Date_Type
UNION
SELECT CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@mydate))),DATEADD(mm,1,@mydate)),103) ,
'Último día del mes corriente'
UNION
SELECT CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@mydate))-1),DATEADD(mm,1,@mydate)),103) ,
'Primer día del mes siguiente'
GO


*/
go

