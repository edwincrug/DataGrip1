/*

*/

CREATE PROCEDURE [dbo].[spI_INSERTAEQUIVALENCIA](@sFolioOperacion varchar(20), @iError int OUTPUT) --with recompile
 AS
declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@sUsr3letras varchar(10),
@iIdUsr int,
@sIp nvarchar(20),
@sNomBase nvarchar(20),
@sNomBaseConcentra nvarchar(20),
@iIdEmpresa int,
@iIdSucursal int,
@ipLocal VARCHAR(50),
@sAuxIP varchar(50)
begin 

set nocount on
select @sNomBase = ''
select @sNomBaseConcentra = ''

select @iIdEmpresa = oce_idempresa, @iIdSucursal =  oce_idsucursal from Cuentasxpagar..cxp_ordencompra where oce_folioorden = @sFolioOperacion

print Convert(char(1),@iIdEmpresa)
print Convert(char(2),@iIdSucursal)

Select @sIP = ip_servidor, @sNomBase = nombre_base from Centralizacionv2..DIG_CAT_BASES_BPRO where emp_idempresa = @iIdEmpresa and suc_idsucursal = @iIdSucursal
Select  @sNomBaseConcentra = nombre_base from Centralizacionv2..DIG_CAT_BASES_BPRO where emp_idempresa = @iIdEmpresa and tipo=2 --and catsuc_nombrecto='CONCENTRA'

--select * from Centralizacionv2..DIG_CAT_BASES_BPRO
  
--validar si se corre en el servidor local
SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC

if (@ipLocal = @sIP)
begin   
	   select @sAuxIP = ''
end
else
begin	   
	   select @sAuxIP = '[' + @sIP + '].'
end


if (PATINDEX ( '%-SE-%' , @sFolioOperacion) > 0 )
Begin
   set @sQ = N'select @sUsr3letrasOUT = ORD_CVEUSU from ' + @sAuxIP + '[' + @sNomBase +  '].[dbo].[SER_ORDENDET] where  ORD_FOLIOORDEN=''' + @sFolioOperacion + char(39)
end

if (PATINDEX ( '%-OT-%' , @sFolioOperacion) > 0 )
Begin
	set @sQ = N'Select @sUsr3letrasOUT = poc_cvusuario from ' + @sAuxIP + '[' + @sNomBase +  '].[dbo].[con_pedotros] where poc_folioorden=''' + @sFolioOperacion + char(39)
end

if (PATINDEX ( '%-RE-%' , @sFolioOperacion) > 0 )
Begin
	set @sQ = N'select @sUsr3letrasOUT = PED_CVEUSU from ' + @sAuxIP + '[' + @sNomBase +  '].[dbo].[PAR_PEDIDO] where PED_FOLIOORDEN=''' + @sFolioOperacion + char(39)
end

SET @sParmDefinition = N'@sUsr3letrasOUT varchar(5) OUTPUT';
print @sQ;

EXECUTE sp_executesql @sQ, @sParmDefinition, @sUsr3letrasOUT=@sUsr3letras OUTPUT;  
SELECT 'Usuario 3 letras' + @sUsr3letras; 

set @sQ = N'select @iIdUsrOUT = usu_idusuario from ControlAplicaciones..cat_usuarios where usu_nombreusu like ' + char(39) + char(37) + @sUsr3letras  + char(37) + char(39) + ' and emp_idempresa=' + ltrim(rtrim(Convert(char(4),@iIdEmpresa))) + ' and suc_idsucursal = ' + ltrim(rtrim(Convert(char(4),@iIdSucursal)))
SET @sParmDefinition = N'@iIdUsrOUT int OUTPUT';
print @sQ;

select @iIdUsr = -1;
EXECUTE sp_executesql @sQ, @sParmDefinition, @iIdUsrOUT=@iIdUsr OUTPUT;  
Select 'Usuario Id ' + Convert(char(5),@iIdUsr)
if (@iIdUsr = -1)
begin
   print 'El usuario ' + @sUsr3letras + ' no ha sido dado de alta en Digitalizacion [ControlAplicaciones..cat_usuarios]'
end 

--select ASCII(')
--select char(39)

set @sQ = N'INSERT INTO ControlAplicaciones..eqv_organigrama'
set @sQ = @sQ + N' ([eqv_usubusiness]'
set @sQ = @sQ + N' ,[eqv_ip]'
set @sQ = @sQ + N' ,[eqv_nombrebd]'
set @sQ = @sQ + N' ,[eqv_fechaalta]'
set @sQ = @sQ + N' ,[eqv_usualta]'
set @sQ = @sQ + N' ,[eqv_fechamodifica]'
set @sQ = @sQ + N' ,[eqv_usumodifica]'
set @sQ = @sQ + N' ,[eqv_estatus]'
set @sQ = @sQ + N' ,[gpo_idgrupo]'
set @sQ = @sQ + N' ,[div_iddivision]'
set @sQ = @sQ + N' ,[emp_idempresa]'
set @sQ = @sQ + N' ,[reg_idregion]'
set @sQ = @sQ + N' ,[suc_idsucursal]'
set @sQ = @sQ + N' ,[dep_iddepartamento]'
set @sQ = @sQ + N' ,[usu_usuario])'

if (ltrim(rtrim(@sUsr3letras))<>'' and  rtrim(ltrim(Convert(char(5),@iIdUsr)))<>'-1' and rtrim(ltrim(@sNomBase))<>'')   
BEGIN

			update cuentasxpagar..cxp_ordencompra set oce_idusuario = @iIdUsr where oce_folioorden=@sFolioOperacion

			if Not Exists (select 1 from ControlAplicaciones..eqv_organigrama where usu_usuario = @iIdUsr and eqv_nombrebd=@sNomBase) 
			begin
  
			  --ponerlo en transaccion

			set @sQ = @sQ + N' VALUES ('+ char(39) + @sUsr3letras +  char(39) + ','  --este es el usuario de Businnes debe ser igual al que da de alta TINO
			set @sQ = @sQ + N' ' + char(39) +  @sIP + char(39) + ','
			set @sQ = @sQ + N' ' + char(39) + @sNomBase + char(39) + ','
			set @sQ = @sQ + N' getdate(),'
			set @sQ = @sQ + N' 0,'
			set @sQ = @sQ + N' getdate(),'
			set @sQ = @sQ + N' 1,'
			set @sQ = @sQ + N' 1,' --eqv_estatus
			set @sQ = @sQ + N' 1,' --gpo_idgrupo
			set @sQ = @sQ + N' 1,' --div_iddivision
			set @sQ = @sQ + N' ' + ltrim(rtrim(Convert(char(8),@iIdEmpresa))) + ',' --emp_idempresa     4 para NISSAN
			set @sQ = @sQ + N' 0,'
			set @sQ = @sQ + N' ' +  ltrim(rtrim(Convert(char(8),@iIdSucursal))) + ',' --suc_idsucursal 6 Zaragoza 7 Abasto 8 FAerea
			set @sQ = @sQ + N' 20,' --dep_iddepartamento
			set @sQ = @sQ + N' ' + ltrim(rtrim(Convert(char(5),@iIdUsr))) + ')' --usu_usuario el que tiene en cat_usuarios

			print @sQ

			BEGIN TRANSACTION InsercionYBitacora

			EXECUTE sp_executesql @sQ

			print 'Insercion de Equivalencia'

			insert into Centralizacionv2..DIG_BITACORA (fecha,quien,que,aquien) 
			values (getdate(),'spI_InsertaEquivalencia','Insercion de equivalencia a ' + @sNomBase + ' ' + @sUsr3letras + ' ' + ltrim(rtrim(Convert(char(5),@iIdUsr))),@sFolioOperacion) 

			COMMIT TRANSACTION InsercionYBitacora;

			end
			else
			begin
			  print 'Ya existe la equivalencia'
			end

END
Select @iError=@@Error

set nocount off
end


/*
Declare @sFolioOperacion varchar(20);
Declare @iError int;

select @sFolioOperacion='AU-AU-UNI-OT-PE-2150'
select @iError = 0

execute spI_InsertaEquivalencia @sFolioOperacion, @iError OUTPUT

SELECT * FROM Centralizacionv2..DIG_BITACORA where aquien = 'AU-ZM-NFA-SE-PE-251' order by id_bitacora
select * from ControlAplicaciones..eqv_organigrama where usu_usuario = 604 and eqv_nombrebd='GAZM_FAerea'

Select poc_cvusuario from [192.168.20.31].[GAZM_Zaragoza].[dbo].[con_pedotros] where poc_folioorden='AU-ZM-NZA-OT-PE-227'

if (PATINDEX ( '%-SE-%' , 'AU-ZM-NFA-SE-PE-252' ) >0)
begin
    print 'Servicio'
end

*/
go

