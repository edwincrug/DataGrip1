-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--TEST [expedienteSeminuevo].[SEL_CANDADO_ENTREGA_SP] 'MMBNL45K4JH063727', 4, 6
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_CANDADO_ENTREGA_SP]
	@vin VARCHAR(100),
	@idEmpresa INT,
	@idSucursal INT
AS
BEGIN

	SET NOCOUNT ON;
DECLARE @base VARCHAR(200);
DECLARE @queryCXP NVARCHAR(MAX), @idClienteCXP INT, @idClienteCXC INT, @fisMorFieCXP VARCHAR(20), @fisMorFieCXC VARCHAR(20);
DECLARE @tableAllDocumentos TABLE (id INT IDENTITY, idDocumento INT, nombreDocumento VARCHAR(500));
DECLARE @tableAllDocumentosCXC TABLE (id INT IDENTITY, idDocumento INT, nombreDocumento VARCHAR(500));
DECLARE @countCXP INT, @countCXC INT, @idExpediente INT;

SELECT @idExpediente = id_expediente FROM [expedienteSeminuevo].[expedientes] WHERE exp_vin = @vin AND exp_empresa = @idEmpresa AND exp_sucursal = @idSucursal
	
SELECT @base = nombre_base FROM [DBO].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND suc_idSucursal = @idSucursal

SET @queryCXP = 'SELECT 
					@clienteId = OC.oce_idproveedor 
				FROM ' + @base + '.DBO.SER_VEHICULO SV
				INNER JOIN cuentasxpagar.[dbo].[cxp_detalleseminuevos] DS ON DS.asn_numeroserie =  SV.VEH_NUMSERIE COLLATE DATABASE_DEFAULT
				INNER JOIN cuentasxpagar.[dbo].[cxp_ordencompra] OC ON OC.oce_folioOrden = DS.oce_folioorden
				WHERE VEH_NUMSERIE = ''' + @vin + ''' AND OC.sod_idsituacionorden <> 4'
EXEC sp_executesql @queryCXP, N'@clienteId INT OUTPUT', @clienteId = @idClienteCXP OUTPUT

SELECT @fisMorFieCXP = PER_TIPO FROM [GA_Corporativa].[DBO].[PER_PERSONAS] WHERE PER_IDPERSONA = @idClienteCXP;

SELECT 
	@idClienteCXC = ucu_idcliente
FROM cuentasporcobrar.[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] CD
INNER JOIN cuentasporcobrar.[dbo].[uni_cotizacionuniversal] CU ON CU.ucu_idCotizacion = CD.ucu_idCotizacion
WHERE CD.ucn_noserie = @vin AND cec_idestatuscotiza <> 14 AND ucu_tipocotizacion = 'SN' AND ucu_idEmpresa = 4 AND ucu_idSucursal = 6

SELECT @fisMorFieCXC = PER_TIPO FROM [GA_Corporativa].[DBO].[PER_PERSONAS] WHERE PER_IDPERSONA = @idClienteCXC;

IF(@fisMorFieCXP = 'MOR')
	BEGIN
		INSERT INTO @tableAllDocumentos
		SELECT 
			id_documento,
			doc_nombre 
		FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_moral = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
	END
ELSE IF(@fisMorFieCXP = 'FIS')
	BEGIN
		INSERT INTO @tableAllDocumentos
		SELECT 
			id_documento,
			doc_nombre  
		FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisica = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
	END
ELSE IF(@fisMorFieCXP = 'FIE')
	BEGIN
		INSERT INTO @tableAllDocumentos
		SELECT 
			id_documento,
			doc_nombre  
		FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisicaAE = 1 AND doc_activo = 1 AND doc_proceso = 1 AND doc_opcional = 0
	END
ELSE
	BEGIN
		INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
		VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de entrega', 0, 'No se encontro Idcliente en el proceso CXP.', GETDATE());
		SELECT success = 0, msg = 'No se encontro Idcliente en el proceso CXP.';
		RETURN
	END


IF(@fisMorFieCXC = 'MOR')
	BEGIN
		INSERT INTO @tableAllDocumentosCXC
		SELECT 
			id_documento,
			doc_nombre 
		FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_moral = 1 AND doc_activo = 1 AND doc_proceso = 2 AND doc_opcional = 0
	END
ELSE IF(@fisMorFieCXC = 'FIS')
	BEGIN
		INSERT INTO @tableAllDocumentosCXC
		SELECT 
			id_documento,
			doc_nombre 
		FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisica = 1 AND doc_activo = 1 AND doc_proceso = 2 AND doc_opcional = 0
	END
ELSE IF(@fisMorFieCXC = 'FIE')
	BEGIN
		INSERT INTO @tableAllDocumentosCXC
		SELECT 
			id_documento,
			doc_nombre 
		FROM [expedienteSeminuevo].[cat_documentos] WHERE doc_fisicaAE = 1 AND doc_activo = 1 AND doc_proceso = 2 AND doc_opcional = 0
	END
ELSE
	BEGIN
		INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
		VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de entrega', 0, 'No se encontro Idcliente en el proceso CXC.', GETDATE());
		SELECT success = 0, msg = 'No se encontro Idcliente en el proceso CXC.';
		RETURN
	END
	

SELECT 
	@countCXP = COUNT(A.idDocumento) 
FROM (
		SELECT 
			* 
		FROM @tableAllDocumentos) AS A
		LEFT JOIN ( SELECT 
						DISTINCT id_documento 
					FROM [expedienteSeminuevo].[documentosExpediente] 
					WHERE id_expediente = @idExpediente AND id_proceso = 1) AS B ON A.idDocumento = B.id_documento
		WHERE B.id_documento IS NULL

SELECT 
	@countCXC = COUNT(A.idDocumento) 
FROM (
		SELECT 
			* 
		FROM @tableAllDocumentosCXC) AS A
		LEFT JOIN ( SELECT 
						DISTINCT id_documento 
					FROM [expedienteSeminuevo].[documentosExpediente] 
					WHERE id_expediente = @idExpediente AND id_proceso = 2) AS B ON A.idDocumento = B.id_documento
		WHERE B.id_documento IS NULL
PRINT @countCXP
PRINT @countCXC
IF( @countCXP = 0 AND @countCXC = 0 )
	BEGIN
		INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
		VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de entrega', 1, 'Los expedientes estan completos.', GETDATE());
		SELECT success = 1, msg = 'Los expedientes estan completos'
	END
ELSE IF ( @countCXP > 0 AND @countCXC = 0 )
	BEGIN
		INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
		VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de entrega', 0, 'El expediente de compra esta incompleto.', GETDATE());
		SELECT success = 0, msg = 'El expediente de compra esta incompleto'
	END
ELSE IF ( @countCXP = 0 AND @countCXC > 0 )
	BEGIN
		INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
		VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de entrega', 0, 'El expediente de venta esta incompleto.', GETDATE());
		SELECT success = 0, msg = 'El expediente de venta esta incompleto'
	END
ELSE IF ( @countCXP > 0 AND @countCXC > 0 )
	BEGIN
		INSERT INTO [expedienteSeminuevo].[bitacoraCandados] ([vin], [idEmpresa], [idSucursal], [consumo], [successResponse], [msgResponse], [fechaConsumo])
		VALUES (@vin, @idEmpresa, @idSucursal, 'Candado de entrega', 0, 'Los expediente estan incompletos.', GETDATE());
		SELECT success = 0, msg = 'Los expediente estan incompletos'
	END

END
go

