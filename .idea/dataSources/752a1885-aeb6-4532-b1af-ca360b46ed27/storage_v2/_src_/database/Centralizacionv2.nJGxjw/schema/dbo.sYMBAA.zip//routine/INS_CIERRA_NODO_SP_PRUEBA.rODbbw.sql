
-- ==========================================================================================
-- Author:		  Genaro Mora Valencia
-- Create date:   30/11/2015
-- Description:	  Procedimiento para Cerrar un Nodo. (DIG_EXP_NODO_BITACORA)
-- Modified date: 22/11/2016 Lourdes Maldonado Sánchez  Cierra Nodo CXC
-- ==========================================================================================
-- EXECUTE [INS_CIERRA_NODO_SP_PRUEBA] 1, 15,'AU-AUA-VIG-RE-PE-4'
CREATE PROCEDURE [dbo].[INS_CIERRA_NODO_SP_PRUEBA]
	 @proc_Id	int
	,@nodo_Id	int
	,@folio_Operacion varchar(80)
 
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	

		DECLARE @folioOrigen VARCHAR(80) = @folio_Operacion
		-- =================================================================
	    -- PROCESO 1 CXP
		-- =================================================================
		IF(@proc_Id=1)
		BEGIN
				--LQMA 18012016 se busca el folio recibido en la tabla DIG_EXP_NODO, y si no se encuentra, se busca en DIG_EXP_PLAN_PISO,
				--encontrar su folio original
				--IF EXISTS(SELECT * FROM DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio_Operacion AND Nodo_Id = @nodo_Id)
				IF NOT EXISTS(SELECT * FROM DIG_EXP_NODO WHERE Folio_Operacion = @folio_Operacion)
					BEGIN				
						SELECT @folioOrigen = [Folio_Operacion] FROM DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio_Operacion
					END
		
				--Actualizo la Fecha Fin y le doy estatus 3 terminado, cierro el nodo	
				EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
				   @proc_Id 
				  ,@nodo_Id
				  ,@folioOrigen --LQMA 18012016 comentado @folio_Operacion
				  ,2						
			
				-- Valida si el nodo es menor que 15, inserta la apertura del nuevo nodo
				IF (@nodo_Id<(SELECT max(Nodo_Id) FROM  DIG_NODO WHERE Proc_Id = @proc_Id))
				BEGIN
					 SET @nodo_Id = @nodo_Id +1
					 --Abro el nodo creando Fecha de Inicio y le doy estatus 2
					 EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
							 @proc_Id 
							,@nodo_Id
							,@folioOrigen --LQMA 18012016 comentado @folio_Operacion
							,1				
				END		
        END
		-- =================================================================
		-- PROCESO 2 CXC
		-- =================================================================
		ELSE IF(@proc_Id=2)
		BEGIN
		     PRINT('CXC: cierro Nodo');
		     --1) Actualizo la Fecha Fin y le doy estatus 3 terminado, cierro el nodo	
			 EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
					 @proc_Id 
					,@nodo_Id
					,@folioOrigen 
					,2	
             
			 --2) Valida si el nodo es menor que 6, inserta la apertura del nuevo nodo
			 IF (@nodo_Id<(SELECT max(Nodo_Id) FROM  DIG_NODO WHERE Proc_Id = @proc_Id))
			 BEGIN
			      PRINT('CXC: Abro Nodo');
				  SET @nodo_Id = @nodo_Id +1
				  --Abro el nodo creando Fecha de Inicio y le doy estatus 2
				  EXECUTE [dbo].[UPD_DIG_EXP_NODO_FECHA_SP] 
						  @proc_Id 
						 ,@nodo_Id
						 ,@folioOrigen 
						 ,1				
			 END		
		END
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[INS_CIERRA_NODO_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END

go

