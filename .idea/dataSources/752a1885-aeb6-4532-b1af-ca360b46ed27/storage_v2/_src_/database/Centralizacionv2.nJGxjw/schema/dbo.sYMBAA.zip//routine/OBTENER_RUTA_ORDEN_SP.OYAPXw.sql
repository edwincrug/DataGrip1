
-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 06/11/2015
-- Description:	procedimiento que obtiene la ruta en caso de tener que generar un archivo
-- =============================================
CREATE PROCEDURE [dbo].[OBTENER_RUTA_ORDEN_SP]
	@idfolio nvarchar(50)
	,@result nvarchar(MAX) out
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @origen nvarchar(10);
	DECLARE @iddoc	int;
	DECLARE @R		int;
	--DECLARE @result NVARCHAR(MAX);
	DECLARE @rutaarc NVARCHAR(256);
	DECLARE  @PathName  VARCHAR(256) ,
             @CMD       VARCHAR(512)
    DECLARE @CommandShell TABLE (Line VARCHAR(512));

	SELECT	@origen = CD.Doc_Origen
	FROM    dbo.DIG_CATDOCUMENTO AS CD INNER JOIN
            dbo.DIG_EXPNODO_DOC AS ED ON CD.Doc_Id = ED.Doc_Id	
	WHERE	ED.Folio_Operacion = @idfolio
			AND CD.Doc_Id = @iddoc 
		
	IF @origen = 1
	BEGIN
	SELECT @result = RTRIM(LTRIM(par_valor)) FROM DIG_PARAMETROS WHERE par_id = 3 
	SET @result = @result + '/' + SUBSTRING(@idfolio, 1, 13) + '/' + @idfolio + '.pdf'
	END
	ELSE
	BEGIN
	-- Se ejecuta el ejecutable con parámetros y regresa una ruta en el servidor.
	-- Averiguar si el archivo ya existe
	SELECT @PathName = par_valor FROM DIG_PARAMETROS WHERE par_id = 5
	SET @CMD = 'DIR ' + @PathName + ' /B'
	PRINT @CMD -- test & debug

	INSERT INTO @CommandShell
	EXEC sp_xp_cmdshell_proxy_account 'sa','S0p0rt3'
    EXEC MASTER..xp_cmdshell   @CMD ,NO_OUTPUT

	IF NOT EXISTS (SELECT Line FROM @CommandShell WHERE Line = @idfolio + '.pdf')
	BEGIN
	-- Proceso de creación de archivo
	print ('Inicioa proceso de creacion de archivo')
	SELECT @CMD = par_valor FROM DIG_PARAMETROS WHERE par_id = 5 
	SET @CMD = '"' + @CMD + ' 1 ' + @idfolio + '"'
	print ('Comando @CMD: ' + @CMD)
		EXEC sp_xp_cmdshell_proxy_account 'sa','S0p0rt3'
	EXEC @result = MASTER..xp_cmdshell @CMD, NO_OUTPUT
	END
	-- Esperar cinco segundos
	WAITFOR DELAY '00:00:05'
		SELECT @result = par_valor FROM DIG_PARAMETROS WHERE par_id = 4 
		SET @result = @result + SUBSTRING(@idfolio, 1, 6) + '/' + @idfolio + '.pdf'
		print @result
	END									
	-- Return the result of the function
    PRINT ('de regreso al stored')
	--RETURN @result;
END

go

