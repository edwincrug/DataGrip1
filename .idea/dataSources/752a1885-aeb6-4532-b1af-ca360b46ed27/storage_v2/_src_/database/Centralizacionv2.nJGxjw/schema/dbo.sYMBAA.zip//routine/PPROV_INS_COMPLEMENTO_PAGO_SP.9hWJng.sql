-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 10/01/2019
-- Description:	Insert a la Tabla Encabezado
-- ==========================================================================================
/*
EXECUTE [dbo].[PPROV_INS_COMPLEMENTO_PAGO_SP] 
                 @rfc_emisor     = 'MAGJ660418IM1'
				,@rfc_receptor 	 = 'AUN1402117H9'
				,@serie 		 = 'X'
				,@folio 		 = '123'
				,@importe 		 = 2000.05
				,@uuid 			 = '1b9dd10b-3322-4f84-9bbd-768fb8e9'
				,@fecha_factura  = '2017-04-03 07:57:00'
				,@fecha_carga 	 = '2017-04-06 18:29:00'
				,@usuario_carga  = '1'
				,@iva 			 = 1280.00
				,@estatus 		 = 1
*/				
CREATE PROCEDURE [dbo].[PPROV_INS_COMPLEMENTO_PAGO_SP]
				 @rfc_emisor 	 VARCHAR(20)
				,@rfc_receptor 	 VARCHAR(20)
				,@serie 		 VARCHAR(30)
				,@folio 		 VARCHAR(30)
				,@importe 		 DECIMAL
				,@uuid 			 VARCHAR(50)
				,@fecha_factura  SMALLDATETIME
				,@fecha_carga 	 SMALLDATETIME
				,@usuario_carga  VARCHAR(5)
				,@iva 			 DECIMAL
				,@estatus 		 INT
AS
BEGIN
    SET NOCOUNT ON;	
    BEGIN TRY
	    DECLARE @idPadre     INT = 0;

		SELECT @fecha_carga = GETDATE()

		--Si el XML no tiene folio, se guardan los últimos 12 caracteres del UUID
		--IF(@folio ='' OR @folio IS NULL)
		--BEGIN
		--  SELECT @folio = RIGHT(@uuid,12)
  --      END
	    ----------------------------------------------------------------------
		-- Si No existe encabezado lo inserto
		----------------------------------------------------------------------
		IF NOT EXISTS(SELECT 1 FROM [dbo].[PPRO_COMPLEMENTOENC] WHERE serie = @serie AND folio = @folio)
			BEGIN
				IF NOT EXISTS(SELECT 1 FROM [Centralizacionv2].[dbo].[PPRO_COMPLEMENTOENC] WHERE [uuid] = @uuid)
				   BEGIN
				   		PRINT 'NO EXISTE, INSERTO'
						INSERT INTO [dbo].[PPRO_COMPLEMENTOENC] (	rfc_emisor
											,rfc_receptor
											,serie
											,folio
											,importe
											,uuid
											,fecha_factura
											,fecha_carga
											,usuario_carga
											,iva
											,estatus)
						VALUES(	 @rfc_emisor 	
								,@rfc_receptor 	
								,@serie 			
								,@folio 			
								,@importe 		
								,@uuid 			
								,@fecha_factura 	
								,@fecha_carga 	
								,@usuario_carga 	
								,@iva 			
								,@estatus )

					   SELECT @idPadre = @@IDENTITY 
					   SELECT @idPadre AS idComplemento, 'Ok' AS msj
					END
				ELSE
					BEGIN
					   PRINT 'EXISTE UUID'
					   SELECT 0 AS idComplemento, 'No insertado, UUID ya registrado anteriormente' AS msj        
					END  				   
			END
		ELSE 
		----------------------------------------------------------------------
		-- Existe encabezado se hace Update
		----------------------------------------------------------------------
			BEGIN
			    PRINT 'EXISTE, SERIE Y FOLIO'
				SELECT 0 AS idComplemento, 'No insertado, serie y folio registrados anteriormente' AS msj
				--UPDATE [dbo].[PPRO_COMPLEMENTOENC]
				--   SET [rfc_emisor]    = @rfc_emisor
				--	    ,[rfc_receptor]  = @rfc_receptor
				--	    ,[importe]       = @importe
				--	    ,[uuid]          = @uuid
				--	    ,[fecha_factura] = @fecha_factura
				--	    ,[fecha_carga]   = @fecha_carga
				--	    ,[usuario_carga] = @usuario_carga
				--	    ,[iva]           = @iva
				--	    ,[estatus]       = @estatus 
				-- WHERE serie = @serie 
				--   AND folio = @folio
			END
	
	END TRY
	BEGIN CATCH
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 DECLARE @Mensaje  nvarchar(max),
		 @Componente nvarchar(50) = '[PPROV_INS_COMPLEMENTO_PAGO_SP]'
		 SELECT @Mensaje = ERROR_MESSAGE()
		 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
		 SELECT 1  --Encontro error
	END CATCH
END
go

