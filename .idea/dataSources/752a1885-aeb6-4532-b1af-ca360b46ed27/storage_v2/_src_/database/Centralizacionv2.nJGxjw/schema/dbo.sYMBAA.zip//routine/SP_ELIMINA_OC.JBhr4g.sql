-- =============================================
-- Author:		Javier Hernandez Rodriguez
-- Create date: 04/04/2016
-- Elimina archivo PDF / Orden de compra 
-- =============================================

CREATE PROCEDURE [dbo].[SP_ELIMINA_OC]
	@FolioOrden VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRY	   

DECLARE @folder VARCHAR(500)
DECLARE @nombrearchivo VARCHAR(200)
DECLARE @extension VARCHAR(10)
DECLARE @cmd VARCHAR(800)

set @folder =  '\\192.168.20.89\GA_Centralizacion\CuentasXPagar\TempPdf\OrdenCompra\Orden_'
set @nombrearchivo = @FolioOrden
set @extension = '.PDF'
set @cmd = 'del '+ @folder + @nombrearchivo + @extension
--EJECUTO SCRIPT
EXEC MASTER..xp_cmdshell @cmd, no_output

END TRY

BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SP_ELIMINA_OC]'
	 SELECT @Mensaje = ERROR_MESSAGE()	 
	 SELECT 0 
END CATCH		     
END

go

