--USE [Centralizacionv2]
--GO
--/****** Object:  StoredProcedure [dbo].[SEL_RESUMEN_COTIZACION_SP]    Script Date: 07/05/2018 07:28:16 p. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
----------------------------------------------
/*
[dbo].[SEL_RESUMEN_COTIZACIONUNIDAD_SP] 'AU-ZM-NZA-UN-4334', '32807'
*/
----------------------------------------------
CREATE PROCEDURE [dbo].[SEL_RESUMEN_COTIZACIONUNIDAD_SP]
	@FolioCotizacion VARCHAR(100) 
	,@idCotizacionDetalle VARCHAR(100) 
AS 
BEGIN
	SET NOCOUNT ON;
		DECLARE @Base                 VARCHAR(100)
		DECLARE @BaseConcentra        VARCHAR(100)
		DECLARE @BaseLocal            VARCHAR(100)
		DECLARE @IdCotizacion         VARCHAR(100)
		DECLARE @TipoCotizacion       VARCHAR(3)
		DECLARE @ConsultaUnidad       VARCHAR(max)
		DECLARE @ConsultaRefacciones  VARCHAR(max)
		DECLARE @ConsultaTramites     VARCHAR(max)
		DECLARE @ConsultaOtros        VARCHAR(max)
		DECLARE @ConsultaServicio     VARCHAR(max)
		DECLARE @idBpro	VARCHAR(50) 
		 
		-------------------------------------------------------------
		--Se crea variable tabla 
		-------------------------------------------------------------
		DECLARE @cotizacionDetalle TABLE(	MODULO VARCHAR(30),
											CANTIDAD INT,
											PRECIO DECIMAL(18,2),
											IVA DECIMAL(18,2),
											TOTAL DECIMAL(18,2)
										)
		-------------------------------------------------------------
		--Obtengo información sobre la cotización
		------------------------------------------------------------- 
 
		--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE DONDE SE BUSCARA LA POLIZA  
		SET @Base = [dbo].[base_Cotizacion](@FolioCotizacion)
		PRINT @Base
		--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE CONCENTRADORA
		SET @BaseConcentra = [dbo].[base_concentradora_cotizacion](@FolioCotizacion)
		PRINT @BaseConcentra
		--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE LOCAL
		SET @BaseLocal = [dbo].[base_Cotizacion](@FolioCotizacion)
		PRINT @BaseLocal

		----INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE DONDE SE BUSCARA LA POLIZA  
		--SET @Base = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
		--(SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa = 
		--(SELECT ucu_idempresa FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)) 
		--AND suc_idsucursal = (SELECT ucu_idsucursal FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion))
		--PRINT @Base
		----INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE CONCENTRADORA
		--SET @BaseConcentra = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE tipo = 2 and catemp_nombrecto = 
		--(SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa = 
		--(SELECT ucu_idempresa FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)))
		--PRINT @BaseConcentra
		----INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE LOCAL
		--SET @BaseLocal = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE tipo = 1 and suc_idsucursal = 
		--(SELECT ucu_idsucursal FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion))
		--PRINT @BaseLocal

		--Incicio Variable consecutivo de cotizacion
		SET @IdCotizacion = (SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)
		SET @TipoCotizacion = (SELECT ucu_tipocotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion) 

		-------------------------------------------------------------
		--Obtengo información sobre la cotización
		------------------------------------------------------------- 
		--Cuando es enviado el @FolioCotizacion y el @idCotizacionDetalle
		IF(@FolioCotizacion <> '')
			BEGIN
				--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE DONDE SE BUSCARA LA POLIZA
				SET @Base = [dbo].[base_Cotizacion](@FolioCotizacion)
				--SELECT @Base
				--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE CONCENTRADORA
				SET @BaseConcentra =[dbo].[base_concentradora_cotizacion](@FolioCotizacion)		
				--SELECT @BaseConcentra
				--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE LOCAL
				--SELECT	@BaseLocal = '['+ ip_servidor + '].[' + nombre_base + '].[dbo].'
				--	FROM	DIG_CAT_BASES_BPRO AS BPRO 
				--		INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU ON CU.ucu_idsucursal = BPRO.suc_idsucursal
				--	WHERE	CU.ucu_foliocotizacion = @FolioCotizacion --AND BPRO.tipo = 2
				--SELECT @BaseLocal
				--Incicio Variable consecutivo de cotizacion
				SET @IdCotizacion = (SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)
				SET @TipoCotizacion = (SELECT ucu_tipocotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)
				
				SELECT @TipoCotizacion = ucu_tipocotizacion, @idBpro = ISNULL(ucu_idpedidobpro,0)  FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_idcotizacion = @IdCotizacion 
				-------------------------------------------------------------
				--QUERY CONSULTA UNIDADES
				------------------------------------------------------------- 		        
				IF @TipoCotizacion = 'NU' 
					BEGIN
					  set @ConsultaUnidad = 'SELECT ''UNIDADES'' Unidad
													,C.ucn_idcotizadetalle
													,1
													,ucn_idcatalogo
													,V.UNC_DESCRIPCION
													,ucn_modelo
													,ucn_noserie
													,ucn_colorext
													,ucn_colorint
													,CONVERT(DECIMAL(18,2),ucn_preciounidad) PrecioUnidad
													,CONVERT(DECIMAL(18,2),ucn_iva) Iva
													,CONVERT(DECIMAL(18,2),ucn_total) Total
													, '+ @idBpro +' AS idBpro  
											FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C 
											INNER JOIN ' + @BaseConcentra + 'UNI_CATALOGO V ON 
														C.ucn_idcatalogo = V.UNC_IDCATALOGO 
														AND C.ucn_modelo = V.UNC_MODELO 
											WHERE C.ucn_estatus = 1 AND ucu_idcotizacion = ' + @IdCotizacion
											+ ' AND C.ucn_idcotizadetalle = '+@idCotizacionDetalle+''
					
					END
				ELSE
					BEGIN  

					  set @ConsultaUnidad = 'SELECT ''UNIDADES'' Concepto
													,C.ucn_idcotizadetalle
													,1
													,ucn_idcatalogo=''''
													,UNC_DESCRIPCION= U.VEH_TIPOAUTO
													,ucn_modelo
													,ucn_noserie
													,ucn_colorext
													,ucn_colorint
													,CONVERT(DECIMAL(18,2),ucn_preciounidad) PrecioUnidad
													,CONVERT(DECIMAL(18,2),ucn_iva) Iva
													,CONVERT(DECIMAL(18,2),ucn_total) Total
													, '+ @idBpro +' AS idBpro   
											FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C 
											INNER JOIN ' + ISNULL(@BaseLocal,'') + 'SER_VEHICULO U ON 
														C.ucn_noserie = U.VEH_NUMSERIE
											WHERE C.ucn_estatus = 1 AND ucu_idcotizacion = ' + ISNULL(@IdCotizacion,'')
											+ ' AND C.ucn_idcotizadetalle = '+@idCotizacionDetalle+''

					END
				
				EXEC (@ConsultaUnidad)
				-------------------------------------------------------------
				--QUERY CONSULTA REFACCIONES
				------------------------------------------------------------- 
				
				
					set @ConsultaRefacciones = 'SELECT ''ACCESORIOS'' Concepto
														,C.ucn_idcotizadetalle
														,CONVERT(INT,P.pmd_cantidad) Cantidad
														,P.pmd_idparte,PP.PTS_DESPARTE
														,''Desc'' = '''' 
														,''Desc1'' = '''' 
														,''Desc2'' = '''' 
														,''Desc3'' = '''' 
														,P.pmd_preciounitario / 1.16 Precio
														,P.pmd_preciounitario - (P.pmd_preciounitario / 1.16) Iva
														,CASE WHEN VTE_DOCTO IS NOT NULL THEN V.VTE_IMPORTEMON ELSE P.pmd_total END ImporteTotal
														, PE.pmm_nopedmost AS idBpro '+
														',VTE_DOCTO AS factura   ' + char(13) + 
														',ISNULL(SUM(CCP_ABONO),0) AS importe   ' + char(13) + 
							'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN ISNULL(SUM(CCP_CARGO),0) - ISNULL(SUM(CCP_ABONO),0) ELSE P.pmd_total END  As saldo   ' + char(13) + 
							'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
							'		INNER JOIN ' + @Base + 'par_pedmostdet P ON C.ucn_idcotizadetalle = P.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = P.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
							'		INNER JOIN ' + @Base + 'PAR_PARTES PP ON P.pmd_idparte = PP.PTS_IDPARTE ' + char(13) + 
							'		INNER JOIN ' + @Base + 'par_pedmostenc PE ON PE.pmm_idpedmostenc = P.pmm_idpedmostenc' + char(13) + 
							'		LEFT JOIN ' + @Base + '[PAR_PEDMOST] AS PEM ON PE.pmm_nopedmost = PEM.PMM_NUMERO AND PMM_IDALMA = '+char(39)+'NEG'+char(39)+'' + char(13) + 
							'		LEFT JOIN ' + @Base + '[ADE_VTAFI] AS V ON V.VTE_DOCTO = PMM_REF2' + char(13) + 
							'		LEFT JOIN ' + @Base + '[VIS_CONCAR01] AS VIS ON V.VTE_DOCTO = VIS.CCP_IDDOCTO AND CCP_TIPODOCTO IN(''FAC'',''NCR'',''ANT'',''PCA'')' + char(13) + 
							'WHERE 	P.pmd_estatus = 1 AND C.ucu_idcotizacion = ' + @IdCotizacion + ' AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + ' AND P.[CEA_IdEstatusAdicionales] <> 4 ' + char(13) + 
							'GROUP BY C.ucn_idcotizadetalle, P.pmd_cantidad, P.pmd_idparte,PP.PTS_DESPARTE, P.pmd_preciounitario, P.pmd_total, PE.pmm_nopedmost, VTE_DOCTO, V.VTE_IMPORTEMON' + char(13) +
							'' 





				EXEC (@ConsultaRefacciones)
				-------------------------------------------------------------
				--QUERY CONSULTA TRAMITES 
				-------------------------------------------------------------
				set @ConsultaTramites = ' SELECT	''TRAMITES'' Concepto
													, C.ucn_idcotizadetalle
													,1 cantidad
													,P.PAR_DESCRIP1
													,a.uaw_descripcion
													,''Desc'' = '''' 
													,''Desc1'' = '''' 
													,''Desc2'' = '''' 
													,''Desc3'' = '''' 
													,a.UAW_PRECIO  Precio
													,a.UAW_PRECIO - (a.UAW_PRECIO /1.16) Iva
													,CASE WHEN uaw_IDDOCTO IS NOT NULL THEN SUM(CCP_CARGO) ELSE a.UAW_PRECIO END ImporteTotal
													,ISNULL(A.UAW_IDPEDIDOVAR,'''') AS idBpro '+
										'			,ISNULL(uaw_IDDOCTO,'+char(39)+''+char(39)+') AS factura    ' + char(13) + 
										'			,ISNULL(SUM(CCP_ABONO),0) AS importe   ' + char(13) + 
										'			,CASE WHEN uaw_IDDOCTO IS NOT NULL THEN ISNULL(SUM(CCP_CARGO),0) - ISNULL(SUM(CCP_ABONO),0) ELSE a.UAW_PRECIO END  As saldo   ' + char(13) + 
										' FROM		cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
										'			INNER JOIN cuentasporcobrar.dbo.uni_anticiposweb A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
										'			INNER JOIN ' + @Base + 'PNC_PARAMETR P ON A.uaw_idconceptopago = P.PAR_IDENPARA ' + char(13) + 
										'			LEFT JOIN ' + @Base + '[VIS_CONCAR01] AS VIS ON uaw_IDDOCTO = VIS.CCP_IDDOCTO  AND CCP_TIPODOCTO IN(''FAC'',''NCR'',''ANT'',''PCA'', ''NCA'',''APAN'')' + char(13) + 
										' WHERE		C.ucu_idcotizacion = ' + @IdCotizacion + ' AND A.uaw_estatus = 1 ' + char(13) + 
										'			AND P.PAR_TIPOPARA = '+char(39)+'COCOCXC'+char(39)+' ' + char(13) + 
										'			AND C.ucn_idcotizadetalle = '+@idCotizacionDetalle+' ' + char(13) + 
										'			AND A.[CEA_IdEstatusAdicionales] <> 4' + char(13) + 
										' GROUP BY	C.ucn_idcotizadetalle, P.PAR_DESCRIP1, a.uaw_descripcion,a.UAW_PRECIO, A.UAW_IDPEDIDOVAR, uaw_IDDOCTO ' + char(13) +
										''  

				
				EXEC (@ConsultaTramites)
				-------------------------------------------------------------
				--QUERY CONSULTA OTROS
				-------------------------------------------------------------
				
				set @ConsultaOtros = ' SELECT ''OTROS'' Concepto
												,C.ucn_idcotizadetalle
												,A.ucd_cantidad Cantidad
												,'''' catalogo
												,A.ucd_descripcion
												,''Desc'' = '''' 
												,''Desc1'' = '''' 
												,''Desc2'' = '''' 
												,''Desc3'' = '''' 
												,A.ucd_preciounitario / 1.16 Precio
												,A.ucd_preciounitario - (A.ucd_preciounitario / 1.16) Iva
												,CASE WHEN VTE_DOCTO IS NOT NULL THEN V.VTE_IMPORTEMON ELSE A.ucd_preciounitario END ImporteTotal
												, AD.uoc_idpedidobpro AS idBpro ' +
										'		, VTE_DOCTO AS factura    ' + char(13) +
										'		,ISNULL(SUM(CCP_ABONO),0) AS importe   ' + char(13) + 
										'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN ISNULL(SUM(CCP_CARGO),0) - ISNULL(SUM(CCP_ABONO),0) ELSE A.ucd_preciounitario END  As saldo   ' + char(13) + 
										'FROM	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.uni_otroconceptosdet A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.uni_otrosconceptosenc AS AD ON AD.uoc_idotrosconceptosenc = A.uoc_idotrosconceptosenc ' + char(13) + 
										'		LEFT JOIN ' + @Base + 'ADE_VTAFI AS V ON AD.uoc_idpedidobpro = V.VTE_REFERENCIA1' + char(13) + 
										'		LEFT JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS D ON D.ucu_idcliente = V.VTE_IDCLIENTE AND D.ucu_idcotizacion = C.ucu_idcotizacion ' + char(13) + 
										'		LEFT JOIN ' + @Base + '[VIS_CONCAR01] AS VIS ON V.VTE_DOCTO = VIS.CCP_IDDOCTO AND CCP_TIPODOCTO IN(''FAC'',''NCR'',''ANT'',''PCA'',  ''NCA'')' + char(13) + 
										'WHERE	A.ucd_estatus = 1 AND C.ucu_idcotizacion = ' + @IdCotizacion + ' AND C.ucn_idcotizadetalle = '+@idCotizacionDetalle+' AND A.[CEA_IdEstatusAdicionales] <> 4 ' + char(13) + 
										'GROUP	BY C.ucn_idcotizadetalle, A.ucd_cantidad, A.ucd_descripcion, A.ucd_preciounitario, AD.uoc_idpedidobpro, VTE_DOCTO, V.VTE_IMPORTEMON ' + char(13) + 
										'' 


				
				EXEC (@ConsultaOtros)
				-------------------------------------------------------------
				--QUERY CONSULTA SERVICIO
				-------------------------------------------------------------
				set @ConsultaServicio = 'SELECT ''SERVICIO'' Concepto
												,C.ucn_idcotizadetalle
												,1 cantidad
												,PS.PQE_IDPAQUETE
												,PS.PQE_NOMPAQUETE
												,''Desc''= '''' 
												,''Desc1''= PS.PQE_DESCRIPCION 
												,''Desc2''=''''
												,''Desc3''=''''
												,A.upo_precio / 1.16 Precio
												,A.upo_precio - (A.upo_precio / 1.16) Iva
												,CASE WHEN VTE_DOCTO IS NOT NULL THEN SUM(CCP_CARGO) ELSE A.upo_precio END ImporteTotal
												,A.upo_idorden AS idBpro ' +
										'		,VTE_DOCTO AS factura     ' + char(13) + 
										'		,ISNULL(SUM(CCP_ABONO),0) AS importe   ' + char(13) + 
										'		,CASE WHEN VTE_DOCTO IS NOT NULL THEN ISNULL(SUM(CCP_CARGO),0) - ISNULL(SUM(CCP_ABONO),0) ELSE A.upo_precio END As saldo   ' + char(13) + 
										'FROM 	cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C ' + char(13) + 
										'		INNER JOIN cuentasporcobrar.dbo.uni_preordenser A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost AND (pmd_estatusautorizacion <> 0 OR pmd_estatusautorizacion IS NULL)  ' + char(13) + 
										'		INNER JOIN ' + @Base + 'SER_PAQUESER PS ON A.upo_idpaquete = PS.PQE_IDPAQUETE ' + char(13) + 
										'		LEFT JOIN ' + @Base + 'SER_ORDEN AS OS ON OS.ORE_IDCOTIZACIONUNIVERSAL = C.ucu_idcotizacion' + char(13) +
										'		--LEFT JOIN ' + @Base + 'SER_PRESUP AS PRE ON PRE.ORE_IDCOTIZACIONUNIVERSAL = C.ucu_idcotizacion ' + char(13) +
										'		LEFT JOIN ' + @Base + 'SER_ORDENDET AS ODET ON (OS.ORE_IDORDEN = ODET.ORD_IDORDEN /*OR PRE.PRE_IDORDEN = ODET.ORD_IDORDEN*/) AND ORD_FACSER IS NOT NULL ' + char(13) +
										'		LEFT JOIN ' + @Base + 'ADE_VTAFI AS V ON V.VTE_REFERENCIA1 = OS.ORE_IDORDEN ' + char(13) + 
										'		LEFT JOIN ' + @Base + '[VIS_CONCAR01] AS VIS ON V.VTE_DOCTO = VIS.CCP_IDDOCTO  AND CCP_TIPODOCTO IN(''FAC'',''NCR'',''ANT'',''PCA'')' + char(13) + 
										'WHERE 	A.upo_estatus = 1 ' + char(13) + 
										'		AND C.ucu_idcotizacion = ' + @IdCotizacion + ' ' + char(13) + 
										'		AND C.ucn_idcotizadetalle = ' + @idCotizacionDetalle + ' ' + char(13) + 
										'		AND A.[CEA_IdEstatusAdicionales] <> 4 ' + char(13) + 
										'GROUP BY C.ucn_idcotizadetalle, PS.PQE_IDPAQUETE, PS.PQE_NOMPAQUETE, PS.PQE_DESCRIPCION, A.upo_precio, A.upo_idorden, VTE_DOCTO, V.VTE_IMPORTEMON, ODET.ORD_IDORDEN ' + char(13) + 
										''  
				
				EXEC (@ConsultaServicio)
				EXECUTE [dbo].[SEL_ANTICIPOS_CC_SP] @IdCotizacion;
				EXECUTE [dbo].[SEL_RESUMEN_FACTURAS_SP] @FolioCotizacion,@idCotizacionDetalle;
				PRINT (@ConsultaServicio)
			END
		ELSE 
			BEGIN 
				
				SELECT 'Ocurrio un problema'

			END
		
	SET NOCOUNT OFF;
END;

go

