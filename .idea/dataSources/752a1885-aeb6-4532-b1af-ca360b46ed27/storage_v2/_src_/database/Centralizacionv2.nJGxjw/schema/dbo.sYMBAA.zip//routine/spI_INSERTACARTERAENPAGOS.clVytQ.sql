/*
Borra los registros en PAG_PROGRA_PAGOS_BPRO que serán sustituidos con los nuevos valores.
Inserta en en PAG_PROGRA_PAGOS_BPRO aquellos regsitros que cambio el valor en la cartera.

Se manda llamar bajo los eventos de un trigger en 2 maneras:

Cuando se modifica la cuenta pagadora, para un proveedor, entonces solo se envia el id_proveedor como 
parámetro para que recoloque todos los registros en PAG_PROGRA_PAGOS_BPRO de ese proveedor.

Cuando se modifica la fecha de vencimiento, se manda únicamente el registro de esa cartera.

Regresa 1 si se pudo hacer la INSERCION
Regresa 0 si hubo un error al hacer la insercion

Esta dentro de una transacción.

*/

CREATE PROCEDURE [dbo].[spI_INSERTACARTERAENPAGOS] (@idEmpresa numeric(18,0),@cadId_persona VARCHAR(10),
 @ccp_conscartera varchar(10),@ccp_tipopol varchar(10),@vcc_annio varchar(10),@ccp_conspol varchar(10),
 @ccp_consmov varchar(10),@ccp_iddocto varchar(50),@ccp_mes varchar(10),@ccp_fechope VARCHAR(10),
 @iResultado int OUTPUT ) --with recompile
 As
--DECLARE @idEmpresa numeric(18,0) = null;
--DECLARE @cadId_persona VARCHAR(10) = '345';
--DECLARE @ccp_conscartera varchar(10) = '';
--DECLARE @ccp_tipopol varchar(10) = '';
--DECLARE @vcc_annio varchar(10)='';
--DECLARE @ccp_conspol varchar(10) = '';
--DECLARE @ccp_consmov varchar(10) = '';
--DECLARE @ccp_iddocto varchar(50) = '';
--DECLARE @ccp_mes varchar(10) = '';

--DECLARE @ccp_cartera VARCHAR(10)='';
--DECLARE @ccp_fechope VARCHAR(10)='';

BEGIN



	SET NOCOUNT ON;
	BEGIN TRY	 
	  BEGIN TRANSACTION InsertaEnCarteraHoy
	    ---------------------------------------------------------------
		--  Buscamos la  IP del Servidor y  la Base                  --
		---------------------------------------------------------------
		DECLARE @ipServidor    VARCHAR(100);
		DECLARE @cadIpServidor VARCHAR(100);
		DECLARE @nombreBase    VARCHAR(100);
		DECLARE @campos        VARCHAR(max);
		DECLARE @tabla         VARCHAR(max) = '';
		DECLARE @condicion     VARCHAR(max);
		DECLARE @consultaSaldo VARCHAR(max);
		DECLARE @totalSaldo     decimal(18,5);
		DECLARE @select         VARCHAR(max);
		DECLARE @campos1		VARCHAR(max);

		SELECT @nombreBase = [nombre_base]        
			  ,@ipServidor = [ip_servidor]      
		FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
		WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
									FROM [ControlAplicaciones].[dbo].[cat_empresas]
								WHERE [emp_idempresa] = @idEmpresa)
		  AND tipo = 2

        select @nombreBase, @ipServidor
		select @cadIpServidor = '[' + @ipServidor + '].'
	
	---------------------------------------------------------------
		--  Obtenemos la consulta dinamicamente                      --
		---------------------------------------------------------------
		DECLARE     @VariableTabla TABLE (ID INT IDENTITY(1,1)
										 ,polTipo	        nvarchar(50)
										 ,annio	        int
										 ,polMes	        int
										 ,polConsecutivo	int
										 ,polMovimiento	    int
										 ,polFechaOperacion	datetime
										 ,documento   nvarchar(100)
										 ,cuenta      nvarchar(50)
										 ,idProveedor int
										 ,proveedor   nvarchar(250)
										 ,tipoDocto	  nvarchar(50)
										 ,cartera     nvarchar(150)	
										 ,monto	      decimal(18, 5)
										 ,saldo	      decimal(18, 5)
										 ,saldoPorcentaje	decimal(18, 5)
										 ,moneda			nvarchar(2)	
										 ,fechaVencimiento	datetime
										 ,fechaPromesaPago	datetime
										 ,fechaRecepcion	datetime
										 ,fechaFactura		datetime
										 ,ordenCompra		nvarchar(30)
										 ,estatus			nvarchar(100)
										 ,idEstatus         nvarchar(3)
										 ,anticipo			decimal(18, 0)--int
										 ,anticipoAplicado	decimal(18, 0)--int
										 ,proveedorBloqueado nvarchar(5)
										 ,ordenBloqueada	nvarchar(5)	
										 ,diasCobro			decimal(3, 0)
										 ,aprobado			nvarchar(5)
										 ,contReprog		decimal(3, 0)
										 ,documentoPagable  nvarchar(10)
										 ,aPagar            int          
										 ,nombreAgrupador   nvarchar(50)
										 ,ordenAgrupador    int
										 ,ordenProveedor    int
										 ,cuentaPagadora    nvarchar(50)
										 ,cuentaProveedor   nvarchar(50)   
										 ,empresa          int
										 ,cuentaDestino    nvarchar(50)
										 ,seleccionable    nvarchar(5)
										 ,numeroSerie      varchar(20)
										 ,facturaProveedor varchar(50)
										 ,consCartera      decimal(18, 0)
										 ,esBanco		   nvarchar(5)
										 )
	
	
			/**************/

						
						if(ISNULL(@ccp_conscartera,'')='' and ISNULL(@ccp_consmov,'')='' and ISNULL(@ccp_conspol,'')='' and ISNULL(@ccp_iddocto,'')='' and ISNULL(@ccp_mes,'')='' and ISNULL(@ccp_tipopol,'')=''  )						
						begin
						    Delete [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] where pbp_idProveedor=@cadId_persona;													
						end
						else
						begin
						  --Select * from PAG_PROGRA_PAGOS_BPRO
							Delete [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO]
							 WHERE 
							 pbp_idProveedor = Convert(int,@cadId_persona) and
							 pbp_empresa=Convert(int,@idEmpresa) and
							 pbp_polTipo=@ccp_tipopol and
							 pbp_polAnnio=@vcc_annio and
							 pbp_polMes = @ccp_mes and
							 pbp_polConsecutivo = @ccp_conspol and
							 pbp_polMovimiento = @ccp_consmov and
							 --Convert(char(8),pbp_polFechaOperacion,112) = Convert(char(8),@ccp_fechope,112) and
							 pbp_documento= @ccp_iddocto;
							 --pbp_cuenta= and 
							 --pbp_cartera = '01-1-05 ZAR. - PROVEEDORES DE REFACCIONES'
																								   
						end												

	
	
	
			/**************/	
		SET @campos=' ISNULL(documento.CCP_TIPOPOL,'+''''+''''+')       AS polTipo   ' +
					' ,documento.vcc_anno                     AS annio   ' +
					' ,ISNULL(documento.CCP_MES,0)            AS polMes   ' +
					' ,ISNULL(documento.CCP_CONSPOL, 0)       AS polConsecutivo   ' +
					' ,documento.CCP_CONSMOV                  AS polMovimiento   ' +
					' ,ISNULL(documento.CCP_FECHOPE,CAST('+''''+'1900-01-01 00:00:00'+''''+' AS datetime))  AS polFechaOperacion   ' +
					' , documento.ccp_iddocto AS documento ' +
		            ' , cartera.par_descrip5 AS cuenta  ' +
					' , documento.ccp_idpersona AS idProveedor ' + 
					--
					' , LTRIM(RTRIM(replace(replace(per_paterno,'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+') +'+''''+' '+''''+' + replace(replace(per_materno,'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+') + '+''''+' '+''''+' + per_nomrazon))   AS proveedor  ' +
					' , timo.par_descrip1 AS tipoDocto ' +
					' , cartera.par_descrip1 AS cartera , '+
		            ''''+'monto'+''''+' = case cartera.par_idmodulo when '+''''+ 'cxc' +'''' + ' then ccp_cargo - ccp_abono else ccp_abono - ccp_cargo end  , ' +
					' case cartera.par_idmodulo when '+''''+ 'cxc' +''''+' then ccp_cargo - ccp_abono + (select isnull(sum(ccp_cargo - ccp_abono),0) ' +
		                                                                                            ' FROM ' + @cadIpServidor + '['+  @nombreBase +'].[dbo].[vis_concar01] as movimiento  WHERE movimiento.ccp_iddocto = documento.ccp_iddocto and movimiento.ccp_idpersona = documento.ccp_idpersona and movimiento.ccp_cartera = documento.ccp_cartera and movimiento.ccp_docori<>'+ ''''+'s'+''''+') ' +
		                                       ' else ccp_abono - ccp_cargo +(select isnull(sum(ccp_abono - ccp_cargo),0) from  '+
					                                  @cadIpServidor + '['+  @nombreBase +'].[dbo].[vis_concar01] as movimiento where movimiento.ccp_iddocto = documento.ccp_iddocto and movimiento.ccp_idpersona = documento.ccp_idpersona '+ 
					                                 ' and movimiento.ccp_cartera = documento.ccp_cartera and movimiento.ccp_docori <> '+''''+'s'+''''+')   end  AS saldo,  '+
		             ----
					 '0'+'  AS saldoPorcentaje , '+
					 ----
					 ''''+'moneda'+''''+'= case when cartera.par_descrip4 IN ('+''''+'PE'+''''+','+''''+''''+') or cartera.par_descrip4 not in ('+''''+'DA'+''''+','+''''+'DB'+''''+','+''''+'DL'+''''+','+''''+'PE'+''''+') then '+''''+'PE'+''''+ 
					                          ' else cartera.par_descrip4 end '+
                     ' , documento.ccp_fechven AS fechaVencimiento ' + 
					 ' , ccp_fechprompag AS fechaPromesaPago '+   
					 ' , isnull(documento.ccp_fechrev,CAST('+''''+'1900-01-01 00:00:00'+''''+' AS datetime)) AS fechaRecepcion ' +
					 ' , documento.ccp_fechadocto AS fechaFactura ' +
					 ' , oce_folioorden AS ordenCompra ' + 
					 ' , sod_nombresituacion AS estatus '+ 
					 ' , isnull(O.sod_idsituacionorden,0)  AS idEstatus  ' +
      			     ' , oce_anticipo AS anticipo '+
					 ' , oce_antaplicado AS anticipoAplicado ' + 
					 --Cambio de True a False 22/abril/2016
					 ' , CASE WHEN (ISNULL((SELECT TOP  1 bpv_estatusproveedor FROM '+
					                                                  '[cuentasxpagar].[dbo].[cxp_bloqueoproveedores]  WHERE  PER_IDPERSONA = BPV_IDPROVEEDOR ORDER BY  bpv_idbloqueo DESC ) ,0 ) ) = 1 THEN '+ ''''+'True'+''''+
                                                                      '  ELSE ' +''''+'False' +'''' + '	END  AS  proveedorBloqueado ' +
					 --****
					 ', CASE WHEN (ISNULL((SELECT TOP 1 boc_estatusorden    ' +
					 '	       				 FROM  [cuentasxpagar].[dbo].[cxp_bloqueoordenes] WHERE oce_folioorden = boc_folioorden ORDER BY boc_idbloqueo DESC),0)) = 1 THEN '+''''+'True'+''''+
					 '	ELSE     '+''''+'False'+''''+
					 '  END AS ordenBloqueada     ' +
					 --****
					 ----------
					 ',ISNULL((SELECT CDP_DIASCOBRO FROM '+
					  @cadIpServidor + '['+  @nombreBase +'].[dbo].[CXP_CONDCRED]	WHERE CDP_IdPERSONA = ccp_idpersona),30)  AS diasCobro, '+
			         ''''+'1'+''''+'  AS aprobado ,'+ ''''+'0'+''''+'  AS contReprog '+
					 ------------------------------
					 ' ,CASE WHEN (SELECT TOP  1 bpv_estatusproveedor  ' +
					 '              FROM  [cuentasxpagar].[dbo].[cxp_bloqueoproveedores] WHERE  PER_IDPERSONA = BPV_IDPROVEEDOR  ORDER BY  bpv_idbloqueo DESC ) = 1 THEN '+''''+'False'+''''+
		             '      ELSE   ' +
					 '			CASE WHEN (ISNULL((SELECT TOP 1 boc_estatusorden FROM     ' +
					 '							  [cuentasxpagar].[dbo].[cxp_bloqueoordenes] WHERE oce_folioorden = boc_folioorden ORDER BY boc_idbloqueo DESC),0)) = 1 THEN '+''''+'False'+''''+
					 '					ELSE     ' +
					 '			        CASE  WHEN ((isnull(O.sod_idsituacionorden,0) not in ('+''''+'10'+''''+','+''''+'15'+''''+','+''''+'17'+''''+','+''''+'0'+''''+')) )  THEN '+''''+'False'+''''+
					 '					ELSE'+''''+'True'+''''+
					 '					END    ' +
                     '          END   ' +
					 '  END AS documentoPagable     ' +
					 ------------------------------
					--- Agregados 22/abril/2016  idEmpresa
					',0  AS aPagar  '
					    
	  SET @campos1 =',ISNULL((SELECT A.[pca_nombre]  '+
					'		   FROM [Pagos].[dbo].[PAG_CAT_AGRUPADORES]    A '+
					'			   ,[Pagos].[dbo].[PAG_AGRUPADOR_PROVEEDOR] P '+
					'         WHERE A.[pca_idAgrupador] = P.[pca_idAgrupador] '+
				    '			AND P.[pap_idProveedor] = PER_IDPERSONA '+
					' 		    AND A.[pca_idEmpresa]   = '+ cast (@idEmpresa as varchar(2)) +' ),' +''''+'Sin Agrupar' +''''+') as nombreAgrupador   '+
					',ISNULL((SELECT A.[pca_orden]  '+
				    '           FROM [Pagos].[dbo].[PAG_CAT_AGRUPADORES]    A '+
					'               ,[Pagos].[dbo].[PAG_AGRUPADOR_PROVEEDOR] P '+
				    '          WHERE A.[pca_idAgrupador] = P.[pca_idAgrupador]  '+
				    '            AND P.[pap_idProveedor] = PER_IDPERSONA '+
				    '            AND A.[pca_idEmpresa]   ='+ cast (@idEmpresa as varchar(2)) +' ),0)      as ordenAgrupador  '+
					',ISNULL((SELECT P.[pap_orden]  '+
				    '           FROM [Pagos].[dbo].[PAG_CAT_AGRUPADORES]    A '+
					'               ,[Pagos].[dbo].[PAG_AGRUPADOR_PROVEEDOR] P '+
				    '          WHERE A.[pca_idAgrupador] = P.[pca_idAgrupador]  '+
				    '            AND P.[pap_idProveedor] = PER_IDPERSONA  '+
				    '            AND A.[pca_idEmpresa]   = '+ cast (@idEmpresa as varchar(2)) +' ),0)       as ordenProveedor  '+
					',ISNULL((SELECT PP.PAR_DESCRIP4 FROM '+
					''+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] P INNER JOIN '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] PP ON '+
					'P.PAR_DESCRIP5 = PP.PAR_IDENPARA  WHERE P.PAR_TIPOPARA = ' +''''+'TRANSBCO' +''''+' AND '+
					'PP.PAR_TIPOPARA = ' +''''+'CCHEQ' +''''+' AND PP.PAR_IMPORTE5 = (SELECT pbp_idBanco  '+
					'FROM  [Pagos].[dbo].[PAG_PROVEEDOR_BANCO_PAGADOR] WHERE (pbp_idEmpresa = '+ cast (@idEmpresa as varchar(2)) +') '+
					'AND (pbp_idProveedor = PER_IDPERSONA))),' +''''+'SIN CUENTA PAGADORA' +''''+')  as cuentaPagadora  '+
					',ISNULL((SELECT TOP 1 [pcp_cuentaPagadora]  '+
					'		FROM [Pagos].[dbo].[PAG_CAT_PROVEEDORES] '+
					'		WHERE [pcp_idProveedor] = PER_IDPERSONA),' +''''+'SIN CUENTA PAGADORA' +''''+')  as cuentaProveedor  '+
					','+ cast (@idEmpresa as varchar(2)) +'  as empresa  '+
					',(ISNULL((SELECT TOP 1 ba.par_descrip1     ' + 
             		'			FROM '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[CON_BANCOS]      '+
					'				,'+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] as tu  '+
					'				,'+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[per_personas]        '+
					'				,'+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] as ba  '+
					'		WHERE bco_tipcuenta   = tu.par_idenpara   '+
					'			and bco_idpersona   = per_idpersona   '+
					'			and tu.par_tipopara = ' +''''+'tu' +''''+ 
					'			and bco_banco       = ba.par_idenpara    '+ 
					'			and ba.par_tipopara = ' +''''+'ba' +''''+
					'			and bco_idpersona   = documento.ccp_idpersona ),' +''''+'SIN CUENTA DESTINO' +''''+')) AS  cuentaDestino  '+
					--- Agregados 15/abril/2016
					' ,CASE WHEN (SELECT TOP  1 bpv_estatusproveedor  ' +
					'              FROM  [cuentasxpagar].[dbo].[cxp_bloqueoproveedores] WHERE  PER_IDPERSONA = BPV_IDPROVEEDOR  ORDER BY  bpv_idbloqueo DESC ) = 1 THEN '+''''+'True'+''''+
		            '      ELSE   ' +
					'	    CASE WHEN (ISNULL(('+
					'SELECT ' +''''+'TIENE' +''''+' FROM [Pagos].[dbo].[PAG_PROVEEDOR_BANCO_PAGADOR] WHERE (pbp_idEmpresa = '+ cast (@idEmpresa as varchar(2)) +') AND (pbp_idProveedor = PER_IDPERSONA)'+
					--'SELECT TOP 1 [pcp_cuentaPagadora] FROM [Pagos].[dbo].[PAG_CAT_PROVEEDORES] WHERE [pcp_idProveedor] = PER_IDPERSONA'+
					' ),'+''''+'SIN CUENTA PAGADORA'+''''+')) = '+''''+'SIN CUENTA PAGADORA'+''''+'  THEN  '+''''+'True'+''''+
					'			   ELSE    ' +
					'			   CASE WHEN (ISNULL((SELECT TOP 1 boc_estatusorden FROM     ' +
					'							  [cuentasxpagar].[dbo].[cxp_bloqueoordenes] WHERE oce_folioorden = boc_folioorden ORDER BY boc_idbloqueo DESC),0)) = 1 THEN '+''''+'True'+''''+
					'					ELSE     ' +
					'			        CASE  WHEN ((isnull(O.sod_idsituacionorden,0) not in ('+''''+'10'+''''+','+''''+'15'+''''+','+''''+'17'+''''+','+''''+'0'+''''+')) AND documento.ccp_iddocto LIKE '+''''+'%-%-%-%-%'+''''+' )  THEN '+''''+'True'+''''+
					'	                      ELSE '+
					'						      CASE  WHEN (ISNULL((SELECT TOP 1 ba.par_descrip1 '+                     
					'	 										FROM '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[CON_BANCOS] '+ 
					'													,'+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] as tu '+
					'													,'+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[per_personas]       '+
					'													,'+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] as ba '+
					'											WHERE bco_tipcuenta   = tu.par_idenpara  '+
					'												and bco_idpersona   = per_idpersona  '+
					'												and tu.par_tipopara = '+''''+'tu'+'''' +
					'												and bco_banco       = ba.par_idenpara  '+
					'												and ba.par_tipopara = '+''''+'ba'+''''+
					'												and bco_idpersona   = documento.ccp_idpersona ),'+''''+'SIN CUENTA DESTINO'+''''+')) = '+''''+'SIN CUENTA DESTINO'+''''+'   THEN '+''''+'True'+''''+
					'							  ELSE'+''''+'False'+''''+
					'							  END    ' +
					'						  END   ' +     
                    '               END      ' +
                    '      END   ' +
					'  END AS seleccionable     ' +
					---------
					--NumeroSerie
					-----
					',ISNULL((SELECT TOP 1 au.anu_numeroserie '+
                    '        FROM [cuentasxpagar].[dbo].[cxp_detalleautosnuevos]  as au        '+
                    '       WHERE au.oce_folioorden = documento.ccp_iddocto COLLATE Modern_Spanish_CI_AS  ),'+''''+'SIN NUMERO SERIE'+''''+') as numeroSerie '+
					-----
					--FacturaProveedor 
					',CASE WHEN (SELECT [folio]     '+
					'	    FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]   '+
					'	   WHERE [folioorden] = documento.ccp_iddocto COLLATE Modern_Spanish_CI_AS ) <> null THEN  (SELECT TOP 1 [folio] + '+''''+'-'+''''+' + [serie]  '+
					'																								  FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] '+
					'																								 WHERE [folioorden] = documento.ccp_iddocto COLLATE Modern_Spanish_CI_AS ) '+
					'  ELSE    '+
					'	  ISNULL((SELECT TOP 1 SUBSTRING([uuid], 25,36)  '+
					'		        FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]  '+
					'		       WHERE [folioorden] = documento.ccp_iddocto COLLATE Modern_Spanish_CI_AS ),'+''''+'SIN FACTURA PROVEEDOR'+''''+')  '+
					' END AS  facturaProveedor   ' +
					-----
				    ' ,ccp_conscartera  as consCartera ' + ' ,CASE WHEN EXISTS (SELECT 1 FROM [BDPersonas].[dbo].[per_relacionroles] WHERE rol_idrol =29 and per_idpersona = documento.ccp_idpersona) Then '+''''+'true'+''''+' Else '+''''+'false'+''''+' END AS esBanco '



		SET @tabla= @cadIpServidor + '['+  @nombreBase +'].[dbo].[vis_concar01] As documento INNER JOIN '+
		            @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] as cartera ON ccp_cartera = cartera.par_idenpara INNER JOIN  ' +
					--Por el momento solo vive en el servidor (192.168.20.9)
					'[GA_Corporativa].[dbo].[PER_PERSONAS] ON documento.ccp_idpersona = per_idpersona LEFT OUTER JOIN '+
					@cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] as timo ON documento.ccp_tipodocto = timo.par_idenpara AND timo.par_tipopara = '+''''+ 'timo' +''''+' LEFT OUTER JOIN '+
					--Por el momento solo vive en el servidor (192.168.20.9)
					'['+ @nombreBase +'].[dbo].[con_movimientoreferencia] ON documento.CCP_TIPOPOL = mre_tipoliza AND documento.CCP_CONSPOL = mre_numeropoliza AND documento.CCP_CONSMOV = mre_movimiento AND  documento.CCP_MES = mre_mes AND documento.Vcc_Anno = mre_anio AND documento.CCP_IDDOCTO = mre_referencia1 LEFT OUTER JOIN ' +
					--Por el momento solo vive en el servidor (192.168.20.9)
					'[cuentasxpagar].[dbo].[cxp_ordencompra] O ON mre_folioorden = oce_folioorden COLLATE Modern_Spanish_CI_AS   LEFT OUTER JOIN '+
					--Por el momento solo vive en el servidor (192.168.20.9)
					'[cuentasxpagar].[dbo].[cat_situacionorden] S ON O.sod_idsituacionorden = S.sod_idsituacionorden '

	
		
				SET @condicion= ' ccp_docori = '+ ''''+'s'+''''+' and cartera.par_tipopara = '+''''+'cartera'+''''+' and cartera.par_idmodulo = '+''''+'cxp'+''''+
	                    ' and cartera.par_importe5 = 0 and  documento.ccp_cartera in( select par_idenpara from  '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] '+ '  where par_tipopara = '+ ''''+'cartera'+''''+ 
                        '  and par_idmodulo = '+''''+ 'cxp' +''''+'  and par_status = '+''''+ 'a'+'''' + '  and par_importe4 <> 1 and par_importe5 = 0 )' +
						'and (case cartera.par_idmodulo when '+''''+'cxc'+''''+' then ccp_cargo -  ccp_abono + (select isnull(sum(ccp_cargo - ccp_abono),0) from '+
						@cadIpServidor + '['+  @nombreBase +'].[dbo].[vis_concar01] as movimiento where movimiento.ccp_iddocto = documento.ccp_iddocto and movimiento.ccp_idpersona = documento.ccp_idpersona '+
						'and movimiento.ccp_cartera = documento.ccp_cartera and movimiento.ccp_docori <> '+''''+'s'+''''+') '+ 
						'else ccp_abono - ccp_cargo + (select isnull(sum(ccp_abono - ccp_cargo),0) from '+
						@cadIpServidor + '['+  @nombreBase +'].[dbo].[vis_concar01] as movimiento where movimiento.ccp_iddocto = documento.ccp_iddocto and movimiento.ccp_idpersona = documento.ccp_idpersona '+ 
						'and movimiento.ccp_cartera = documento.ccp_cartera and movimiento.ccp_docori <> '+''''+'s'+''''+') end) > 0 and ccp_tipodocto not like '+''''+'%iva'+'''' 
						--Codigo Agregado para paremtrizar la consulta.
						
						if(ISNULL(@ccp_conscartera,'')='' and ISNULL(@ccp_consmov,'')='' and ISNULL(@ccp_conspol,'')='' and ISNULL(@ccp_iddocto,'')='' and ISNULL(@ccp_mes,'')='' and ISNULL(@ccp_tipopol,'')='' )						
						begin
							set @condicion = @condicion + ' and documento.ccp_idpersona=' + @cadId_persona;
						end
						else
						begin
						   set @condicion = @condicion + ' and documento.ccp_idpersona=' + @cadId_persona;
						   set @condicion = @condicion + ' and documento.ccp_conscartera=' + @ccp_conscartera;
						   set @condicion = @condicion + ' and documento.ccp_tipopol=' + '''' + @ccp_tipopol + '''';
						   set @condicion = @condicion + ' and documento.ccp_conspol=' + @ccp_conspol;
						   set @condicion = @condicion + ' and documento.ccp_consmov=' + @ccp_consmov;
						   set @condicion = @condicion + ' and documento.ccp_mes=' + @ccp_mes;
						   set @condicion = @condicion + ' and documento.ccp_iddocto=' + '''' + @ccp_iddocto + '''';						   
						   --set @condicion = @condicion + ' and documento.ccp_cartera=' + '' + @ccp_cartera + '';
						   
						end												
						set @condicion = @condicion + ' order by convert(datetime,ccp_fechven,103) desc';

		
		--select Isnull(@campos,'@campos es nulo')
		--print @campos
		
		--select ISNULL(@campos1,'@campos1 es nulo')
		--print @campos1
		
		--select Isnull(@tabla,'@tabla es nulo')
		--print @tabla
		--select Isnull(@condicion,'@condicion es nulo')
		--print @condicion
		
		set @select = ' SELECT ' + @campos + @campos1 +'   FROm ' +  @tabla  + '  WHERe ' + @condicion 
		select Isnull(@select,'@select es nulo')
		print @select
		
		INSERT INTO  @VariableTabla  EXEC ( ' SELECT  ' + @campos + @campos1 +
		                                    '   FROM ' +  @tabla  +
					                        '  WHERE ' + @condicion +';');
        
		SET @totalSaldo = ( SELECT SUM (saldo) 
		                     FROM @VariableTabla) 
		UPDATE @VariableTabla 
		   SET saldoPorcentaje = saldo * 100/@totalSaldo
		  
        INSERT INTO [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO]
					([pbp_polTipo]
					,[pbp_polAnnio]
					,[pbp_polMes]
					,[pbp_polConsecutivo]
					,[pbp_polMovimiento]
					,[pbp_polFechaOperacion]
					--
					,[pbp_documento]
					,[pbp_cuenta]
					,[pbp_idProveedor]
					,[pbp_proveedor]
					--
					,[pbp_tipoDocto]
					,[pbp_cartera]
					,[pbp_monto]
					,[pbp_saldo]
					,[pbp_saldoPorcentaje]
					,[pbp_moneda]
					--
					,[pbp_fechaVencimiento]
					,[pbp_fechaPromesaPago]
					,[pbp_fechaRecepcion]
					,[pbp_fechaFactura]
					--
					,[pbp_ordenCompra]
					,[pbp_estatus]
					,[pbp_idEstatus]
					--
					,[pbp_anticipo]
					,[pbp_anticipoAplicado]
					--
					,[pbp_proveedorBloqueado]
					,[pbp_ordenBloqueada]
					,[pbp_diasCobro]
					,[pbp_aprobado]
					,[pbp_contReprog]
					,[pbp_documentoPagable]
					,[pbp_aPagar]
					,[pbp_nombreAgrupador]
					,[pbp_ordenAgrupador]
					,[pbp_ordenProveedor]
					,[pbp_cuentaPagadora]
					,[pbp_cuentaProveedor]
					,[pbp_empresa]
					,[pbp_fechaCreacionRegistro]
					,[pbp_cuentaDestino]
					,[pbp_seleccionable]
					,[pbp_numeroSerie]
                    ,[pbp_facturaProveedor]
					,[pbp_consCartera]
					,[pbp_esBanco]
					) 
		  SELECT V.polTipo         as  polTipo
				,V.annio           as  annio
				,V.polMes          as  polMes
				,V.polConsecutivo  as  polConsecutivo
				,V.polMovimiento   as  polMovimiento
				,V.polFechaOperacion as polFechaOperacion
				--
				,V.documento         as documento
				,V.cuenta            as cuenta
				,V.idProveedor       as idProveedor
				,V.proveedor         as proveedor
				--
				,V.tipoDocto         as tipoDocto
				,V.cartera           as cartera
				,V.monto             as monto
				,V.saldo             as saldo        
				,V.saldoPorcentaje   as saldoPorcentaje
				,V.moneda            as moneda
				--
				,V.fechaVencimiento  as fechaVencimiento
				,V.fechaPromesaPago  as fechaPromesaPago
				,V.fechaRecepcion    as fechaRecepcion
				,V.fechaFactura      as fechaFactura
				--
				,V.ordenCompra       as ordenCompra
				,V.estatus           as estatus
				,V.idEstatus         as idEstatus
				--
				,V.anticipo          as anticipo
				,V.anticipoAplicado  as anticipoAplicado
				,V.proveedorBloqueado  as proveedorBloqueado 
				,V.ordenBloqueada      as ordenBloqueada
				,V.diasCobro           as diasCobro
				,V.aprobado            as aprobado
				,V.contReprog          as contReprog
				,V.documentoPagable    as documentoPagable
				,V.aPagar              as aPagar
				,V.nombreAgrupador     as nombreAgrupador 
				,V.ordenAgrupador      as ordenAgrupador
				,V.ordenProveedor      as ordenProveedor
				,V.cuentaPagadora      as cuentaPagadora
				,V.cuentaProveedor     as cuentaProveedor
				,V.empresa             as empresa
				,GETDATE()             as fechaCreacionRegistro
				,V.cuentaDestino       as cuentaDestino
				,V.seleccionable       as seleccionable
				,V.numeroSerie         as numeroSerie 
                ,V.facturaProveedor    as facturaProveedor 
				,V.consCartera         as consCartera
				,V.esBanco			   as esBanco
		 FROM  @VariableTabla AS  V
				           
              SELECT 'INSERCION CORRECTA DE INFORMACION DE BPRO'
			  SELECT @iResultado = 0		
			  SELECT @select
				
				Insert into [Centralizacionv2].[dbo].DIG_BITACORA (fecha,que,aquien,quien) 
		        values (GETDATE(),'Insercion en Cartera de Programacion de Pagos','Empresa: ' + CONVERT(char(4),@idEmpresa) + ' Proveedor: ' + @cadId_persona + ' Documento: ' +  Isnull(@ccp_iddocto,'sin documento'), 'Store spI_INSERTACARTERAENPAGOS')
		
			COMMIT TRANSACTION InsertaEnCarteraHoy			
        END TRY

	

	BEGIN CATCH
	     RollBack Transaction InsertaEnCarteraHoy
	     SELECT 'ERROR EN LA CONSULTA'
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 SELECT @iResultado = 1 --Encontro error
	END CATCH

	Return @iResultado
	
set nocount off
END
      
      
      
      
      /*
      
      DECLARE @idEmpresa numeric(18,0) = 2;
	  DECLARE @cadId_persona VARCHAR(10) = '345';
	  DECLARE @ccp_conscartera varchar(10) = '223526';
	  DECLARE @ccp_tipopol varchar(10) = 'CPVCON';
	  DECLARE @vcc_annio varchar(10)='2016';
	  DECLARE @ccp_conspol varchar(10) = '6';
	  DECLARE @ccp_consmov varchar(10) = '3';
	  DECLARE @ccp_iddocto varchar(50) = 'CA-CRA-CUA-OT-PE-19';
	  DECLARE @ccp_mes varchar(10) = '8';
	  DECLARE @ccp_fechope VARCHAR(10)='05/08/2016';
--DECLARE @ccp_cartera VARCHAR(10)='';
	  DECLARE @iResultado int = 0;
            
     Execute spI_INSERTACARTERAENPAGOS @idEmpresa,@cadId_persona,
 @ccp_conscartera,@ccp_tipopol,@vcc_annio,@ccp_conspol,
 @ccp_consmov,@ccp_iddocto,@ccp_mes,@ccp_fechope,
 @iResultado OUTPUT 
      
      print 'Resultado fuera: ' + Convert(char(1),@iResultado) 
      
      
      
         
      
      
      
      
      
      
      
       Select * from PAG_PROGRA_PAGOS_BPRO
 WHERE 
 pbp_idProveedor = 345 and
 pbp_empresa=4 and
 pbp_polTipo='CRZ' and
 pbp_polAnnio=2016 and
 pbp_polMes = 8 and
 pbp_polConsecutivo = 1 and
 pbp_polMovimiento = 2 and
 pbp_polFechaOperacion = '01/08/2016' and
 pbp_documento= 'AU-ZM-ZAR-RE-PE-130' and
 pbp_cuenta='2100-0001-0001-0005' and 
 pbp_cartera = '01-1-05 ZAR. - PROVEEDORES DE REFACCIONES'
 --pbp_id=4465
 
 
 
 select top 100 * from VIS_CONCAR01
 
 select * from  [192.168.20.89].[GAZM_Concentra].[dbo].[PNC_PARAMETR]   where par_tipopara = 'cartera'  
				   and par_idmodulo = 'cxp'  and par_status = 'a'  and par_importe4 <> 1 and par_importe5 = 0
				   and PAR_IDENPARA='Z38'
				   --and PAR_DESCRIP5='2100-0001-0001-0005'
				   --and PAR_DESCRIP1='01-1-05 ZAR. - PROVEEDORES DE REFACCIONES'
				   
				   select top 100 * from  [192.168.20.89].[GAZM_Concentra].[dbo].VIS_CONCAR01
				   where Vcc_Empresa='01'
				   and Vcc_Anno='2016'
				   and CCP_CONSPOL=1
				   and CCP_TIPOPOL='CRZ'
				   and CCP_MES=8
				   and CCP_CONSMOV=2
				   and CCP_CARTERA='Z38'
      
      
      
      
      
      
      */
go

