CREATE PROCEDURE dbo.PROV_SEL_BANCOS_PROSPECTO_SP 
@idProspecto INT,
@rfc VARCHAR (50) = ''
AS
BEGIN
			IF(@rfc = '')
			BEGIN
				SELECT   idCuentaBancaria
				,idProspecto
				,titular
				,banco
				,sucursal
				,PCB.noCuenta
				,PCB.clabe
				,cie
				,referencia
				,cveBanxico
				,cveBanco
				,tipoCtaBancaria
				,PCB.empresaId
				,aprobada
				,isnull(PC.id_perTra,0) existe
				,PC.det_estatus
				,PC.idDetPersonaTramite
				FROM PROV_CUENTA_BANCARIA PCB
				INNER JOIN PROV_PROSPECTO PP ON PP.PER_IDPERSONA = PCB.idProspecto
				LEFT JOIN Tramites.dbo.personas P on P.per_rfc = PP.PER_RFC
				LEFT JOIN Tramites.dbo.personaTramite PT ON PT.id_persona = P.id_persona AND PT.petr_estatus not in (2,3) AND PT.id_tramite in (1,2,5)
				LEFT JOIN Tramites.dbo.detallePersonaCuenta PC ON PC.id_perTra = PT.id_perTra AND PCB.noCuenta = PC.noCuenta and PCB.cveBanxico = PC.idBanxico
				--INNER JOIN PROV_PROSPECTO PP ON PCB.empresaId = PP.empresaId
				--AND PCB.idProspecto = PP.PER_IDPERSONA
				WHERE IdProspecto = @idProspecto AND aprobada is null 
			END
			ELSE
			BEGIN 
				SELECT   idCuentaBancaria
				,idProspecto
				,titular
				,banco
				,sucursal
				,PCB.noCuenta
				,PCB.clabe
				,cie
				,referencia
				,cveBanxico
				,cveBanco
				,tipoCtaBancaria
				,PCB.empresaId
				,isnull(PC.id_perTra,0) existe
				,PC.det_estatus
				,PC.idDetPersonaTramite
				FROM PROV_CUENTA_BANCARIA PCB
				LEFT JOIN PROV_PROSPECTO PP ON PP.PER_RFC = PCB.rfcProspecto
				LEFT JOIN Tramites.dbo.personas P on P.per_rfc = PP.PER_RFC
				LEFT JOIN Tramites.dbo.personaTramite PT ON PT.id_persona = P.id_persona AND PT.petr_estatus not in (2,3) AND PT.id_tramite in (1,2,5)
				LEFT JOIN Tramites.dbo.detallePersonaCuenta PC ON PC.id_perTra = PT.id_perTra AND PCB.noCuenta = PC.noCuenta and PCB.cveBanxico = PC.idBanxico
				--INNER JOIN PROV_PROSPECTO PP ON PCB.empresaId = PP.empresaId
				--AND PCB.idProspecto = PP.PER_IDPERSONA
				WHERE rfcProspecto = @rfc AND aprobada is null 
			END
END
go

