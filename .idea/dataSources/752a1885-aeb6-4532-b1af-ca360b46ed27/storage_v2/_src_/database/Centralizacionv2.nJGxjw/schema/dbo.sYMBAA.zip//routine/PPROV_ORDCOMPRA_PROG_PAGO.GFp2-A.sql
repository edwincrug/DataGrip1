CREATE PROCEDURE [dbo].[PPROV_ORDCOMPRA_PROG_PAGO]   --   PPROV_ORDCOMPRA_PROG_PAGO 4,null,null
@idProveedor INT = 0,
@monto DECIMAL = NULL,
@orden VARCHAR(50) = NULL

AS  
BEGIN

SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
		ordComp.oce_folioorden,
		depto.dep_nombre,
		suc.suc_nombre,
		emp.emp_nombre,
		ordComp.oce_importetotal,  
		emp.emp_nombrecto,
		CONVERT (datetime,ordComp.oce_fechaorden, 13) as oce_fechaorden, 
		sit.sod_nombresituacion estatus,
		per.per_rfc, 
		df.folioorden as ppro_nombrearchivo,
		df.serie + ISNULL(df.folio,'') factura,
		df.uuid,
		df.fecha_carga as fechaValidacion,
		CONVERT (datetime,df.fecha_factura, 103) as fecha_factura,
		df.serie,
		df.fecha_factura fecha_pago,
		df.rfc_emisor,
		df.rfc_receptor,
		df.importe as importe_total,
		ordComp.oce_uuid,
		Recepcion =
      CASE ordComp.sod_idsituacionorden
	     WHEN 1 THEN 'Pendiente'
		 WHEN 2 THEN 'Pendiente'
		 WHEN 3 THEN 'Pendiente'
		 WHEN 4 THEN 'Pendiente'
		 WHEN 5 THEN 'Pendiente'
         WHEN 6 THEN 'Recepción Completa'
         WHEN 7 THEN 'Recepción Incompleta'
		 ELSE  'Recepción Incompleta'		 
      END,
		 Estado =
	     CASE ordComp.sod_idsituacionorden
		 WHEN 12 THEN 'Pagada'
         WHEN 13 THEN 'Pagada'
		 WHEN 16 THEN 'Pagada'
		 WHEN 18 THEN 'Pagada'
         ELSE  'Por Pagar'
      END 
		
FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal   
LEFT JOIN BDPersonas.dbo.cat_personas per ON per.per_idpersona = ordComp.oce_idproveedor
LEFT JOIN cuentasxpagar.dbo.cat_situacionorden sit ON ordComp.sod_idsituacionorden = sit.sod_idsituacionorden 
LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento 
LEFT JOIN  PPRO_DATOSFACTURAS DF ON DF.folioorden= ordComp.oce_folioorden
WHERE ordComp.oce_idproveedor = @idProveedor AND
	  ordComp.sod_idsituacionorden NOT IN(3,4) AND
      ordComp.sod_idsituacionorden = 11 AND
	  ordComp.oce_folioorden IN (SELECT folioorden FROM dbo.PPRO_DATOSFACTURAS) AND	
	   (@monto IS NULL OR ordComp.oce_importetotal = @monto)AND
	   (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))	  	  	  
	  order by ordComp.oce_fechaorden DESC



END

go

