-- ================================================
-- Create date: 25/09/2017
-- Description:	Obtiene la informacion para el rpt de lote de pago 
-- =============================================
-- [dbo].[SEL_FORMATO_LOTE_PAGO_SP] 'AU-HY-HCU-RE-PE-534', 78783 
CREATE PROCEDURE [dbo].[SEL_FORMATO_LOTE_PAGO_SP]
	@folio VARCHAR(50)
	,@idProveedor INT
AS
BEGIN
	IF @idProveedor = -1
		SET @idProveedor = null

	DECLARE @idLote INT = (SELECT pal_id_lote_pago FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pad_documento = @folio)

	--Obtengo la factura y folio 
	DECLARE @facturaFolio TABLE(folio VARCHAR(100), factura VARCHAR(100))
	INSERT INTO @facturaFolio
	SELECT	PPD.pad_ordenCompra, ISNULL(FAC.serie, '') + ISNULL(FAC.folio,'') 
	FROM	[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] AS PPD
			LEFT JOIN [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] AS FAC ON PPD.pad_ordenCompra = FAC.folioorden
	WHERE	pal_id_lote_pago = @idLote

	--Obtengo la orden de servicio
	DECLARE @ordenServicio TABLE(folio VARCHAR(100), ordenServicio VARCHAR(100))
	INSERT INTO @ordenServicio
	SELECT	PPD.pad_ordenCompra, ISNULL(OS.ser_ordenservicio,'') 
	FROM	[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] AS PPD
			LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] OS ON PPD.pad_ordenCompra = OS.oce_folioorden
	WHERE	pal_id_lote_pago = @idLote

	--Obtengo la información necesaria para llenar el detalle del rpt 
	DECLARE @tablaAux TABLE(idLote NUMERIC(18,0) 
							,lotePago NVARCHAR(100)
							,usuarioLote NVARCHAR(500)
							,fechaLote NVARCHAR(10)
							,horaLote NVARCHAR(10)
							,estatus NVARCHAR(50)
							,idUsuarioProveedor NUMERIC(18,0) 
							,usuarioProveedor NVARCHAR(500)
							,documento NVARCHAR(50)
							,cuentaOrigen NVARCHAR(100)
							,cuentaBeneficiario  NVARCHAR(100)
							,importe NUMERIC(18,2)
							,fechaAplicacion NVARCHAR(10)
							,logo NVARCHAR(500)
							,empresa NVARCHAR(100))
	INSERT INTO @tablaAux
	SELECT	DISTINCT PD.pal_id_lote_pago AS idLote
			,PL.pal_nombre AS lotePago
			,LTRIM(RTRIM(LTRIM(U.usu_paterno)) + ' ' + RTRIM(LTRIM(U.usu_materno)) + ' ' + RTRIM(LTRIM(U.usu_nombre))) AS usuarioLote
			,CONVERT(varchar, PL.pal_fecha, 103) AS fechaLote
			,CONVERT(varchar, PL.pal_fecha, 108) As horaLote
			,EL.pel_descripcion AS estatus
			,dpa_idpersona AS idUsuarioProveedor
			--,PER.Persona AS usuarioProveedor
			,LTRIM(RTRIM(LTRIM(P.per_paterno)) + ' ' + RTRIM(LTRIM(P.per_materno)) + ' ' + RTRIM(LTRIM(P.per_nomrazon))) AS usuarioProveedor
			,dpa_iddocumento AS documento
			,dpa_cuentapagadora AS cuentaOrigen
			,dpa_cuentabeneficiario AS cuentaBeneficiario
			,CONVERT(numeric(18,2),dpa_importepagado) AS importe
			,CONVERT(varchar, dpa_fechaaplicacion, 103) AS fechaAplicacion
			,B.urlLogo AS logo
			,E.emp_nombre AS empresa
	FROM	[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] AS PD
			INNER JOIN [Pagos].[dbo].[PAG_LOTE_PAGO] AS PL ON PD.pal_id_lote_pago =  PL.pal_id_lote_pago
			INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] AS U ON U.usu_idusuario = PL.pal_id_usuario
			INNER JOIN [Pagos].[dbo].[PAG_ESTATUS_LOTE] AS EL ON EL.pel_id_estatus_pago = PL.pal_estatus
			INNER JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] AS DP ON DP.dpa_lote = PD.pal_id_lote_pago and dpa_idpersona = PD.pad_idProveedor
			--CROSS APPLY fn_ObtenerProveedor(PD.pad_idProveedor,PL.pal_id_empresa) AS PER
			INNER JOIN GA_Corporativa.dbo.PER_PERSONAS P ON P.per_idpersona = PD.pad_idProveedor 
			--INNER JOIN [BDPersonas].[dbo].[cat_personas] AS P ON P.per_idpersona = PD.pad_idProveedor 
			INNER JOIN [referencias].[DBO].[BancoCuenta] AS BC ON DP.dpa_cuentapagadora =  BC.numeroCuenta
			INNER JOIN [referencias].[dbo].[Banco] AS B ON B.idBanco = BC.idBanco
			INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS E ON E.emp_idempresa = PL.pal_id_empresa
	WHERE	PD.pal_id_lote_pago = @idLote
			AND dpa_idpersona = COALESCE(@idProveedor, dpa_idpersona)
	
	SELECT	DISTINCT TA.idLote
			,TA.lotePago
			,TA.usuarioLote
			,TA.fechaLote
			,TA.horaLote
			,TA.estatus
			,TA.idUsuarioProveedor
			,TA.usuarioProveedor
			,TA.documento
			,TA.cuentaOrigen
			,TA.cuentaBeneficiario
			,TA.importe
			,TA.fechaAplicacion
			,TA.logo
			,TA.empresa 
			,LTRIM(RTRIM(LTRIM(USU.usu_paterno)) + ' ' + RTRIM(LTRIM(USU.usu_materno)) + ' ' + RTRIM(LTRIM(USU.usu_nombre))) AS usuarioNotificacion
			,CONVERT(varchar, NAR.nar_fecha, 103) AS fechaAutorizacion
			,factura
			,ordenServicio
	FROM	@tablaAux AS TA
			INNER JOIN [Notificacion].[dbo].[NOT_NOTIFICACION] AS N ON N.not_identificador= CONVERT(VARCHAR(30),TA.idLote)	AND not_agrupacion = 1
			INNER JOIN [Notificacion].[dbo].[NOT_APROBACION] AS NA ON N.not_id = NA.not_id
			INNER JOIN [Notificacion].[dbo].[NOT_APROBACION_RESPUESTA] AS NAR ON NAR.apr_id = NA.apr_id
			INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] AS USU ON USU.usu_idusuario = NA.emp_id
			INNER JOIN @facturaFolio AS FAC ON FAC.folio = TA.documento
			INNER JOIN @ordenServicio AS OS ON OS.folio = TA.documento	
END
go

