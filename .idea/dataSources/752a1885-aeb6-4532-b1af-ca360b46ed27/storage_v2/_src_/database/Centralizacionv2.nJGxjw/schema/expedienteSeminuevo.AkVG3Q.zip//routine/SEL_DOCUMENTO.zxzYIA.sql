-- =============================================
-- Author:		<JJSY>
-- Create date: <23/06/2020>
-- Description:	<Regresa Documento>
--TESET [expedienteSeminuevo].[SEL_DOCUMENTO] 5,4,1
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_DOCUMENTO]
	@idDocumento INT ,
	@idExpediente INT ,
	@idProceso INT 
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @tempEstatus TABLE (id INT IDENTITY, estatusNombre VARCHAR(100), estatus INT);

	INSERT INTO @tempEstatus

	SELECT  
	       ED.est_descripcion  AS estatusNombre,
		  max (DE.id_estatus) AS estatus
		FROM [expedienteSeminuevo].[cat_documentos] CD
		INNER JOIN [expedienteSeminuevo].[documentosExpediente] DE ON CD.id_documento = DE.id_documento
		INNER JOIN [expedienteSeminuevo].[estatusDocumentos] ED ON DE.id_estatus = ED.id_estatus
		WHERE DE.id_expediente =@idExpediente and DE.id_documento = @idDocumento and DE.id_proceso = @idProceso
		group by ED.est_descripcion


	IF EXISTS (SELECT * FROM @tempEstatus WHERE  estatus = 3)
		BEGIN
			SELECT estatusNombre, estatus FROM @tempEstatus WHERE estatus = 3
		END
	ELSE IF EXISTS  (SELECT * FROM @tempEstatus WHERE  estatus = 1)
		BEGIN
			SELECT estatusNombre, estatus FROM @tempEstatus WHERE estatus = 1
		END
	ELSE IF EXISTS  (SELECT * FROM @tempEstatus WHERE  estatus = 2)
		BEGIN
			SELECT estatusNombre, estatus FROM @tempEstatus WHERE estatus = 2
		END


END



go

