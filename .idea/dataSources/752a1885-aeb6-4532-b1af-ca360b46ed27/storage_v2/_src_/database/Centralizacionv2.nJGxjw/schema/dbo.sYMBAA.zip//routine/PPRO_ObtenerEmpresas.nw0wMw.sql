-- =============================================    
-- Author:  Ricardo Montero Escudero 
-- Create date: 16/12/2015   
-- Description: obtener todas las empresas  
-- =============================================    
CREATE PROCEDURE [dbo].[PPRO_ObtenerEmpresas]   -- [dbo].[PPRO_ObtenerEmpresas]  75,'HEHJ520304R36',2
 @idProveedor as INT = 0,
 @user VARCHAR(15) = '',
 @idUserRol INT = 0 
AS    
BEGIN    
 
 IF(@idUserRol = 1)
    BEGIN
		  
		  --SELECT 0 as emp_idempresa,'---Elije una opción--' as emp_nombre,'OP' as emp_nombrecto
		  --UNION	 
		  SELECT DISTINCT([emp_idempresa])
				,[emp_nombre]
				,[emp_nombrecto]
		  FROM cuentasxpagar.dbo.cxp_ordencompra OC		  
		  LEFT JOIN [ControlAplicaciones].[dbo].[cat_empresas] EM on OC.oce_idempresa = EM.emp_idempresa
		  WHERE OC.oce_folioorden IN (SELECT oce_folioorden FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_idproveedor IN(
												 SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @user))
		  
		  --WHERE OC.oce_idproveedor = @idProveedor

		  /*SELECT * FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_idproveedor IN(
			SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = 'ZMO841221BJ4')*/

	END
ELSE
	BEGIN

		  --SELECT 0 as emp_idempresa,'---Elije una opción---' as emp_nombre,'OP' as emp_nombrecto
		  --UNION	 
		  SELECT DISTINCT([emp_idempresa])
				,[emp_nombre]
				,[emp_nombrecto]
		  FROM cuentasxpagar.dbo.cxp_ordencompra OC
		  LEFT JOIN [ControlAplicaciones].[dbo].[cat_empresas] EM on OC.oce_idempresa = EM.emp_idempresa
		  WHERE EM.emp_idempresa IN (SELECT DISTINCT emp_idempresa 
									 FROM [ControlAplicaciones].[dbo].[ope_organigrama]
									 WHERE [usu_idusuario] = @idProveedor)/*(SELECT usu_idusuario 
															  FROM [ControlAplicaciones].[dbo].[cat_usuarios] 
															  WHERE usu_nombreusu = @user))*/
	
	END  
      
END

go

