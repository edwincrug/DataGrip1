CREATE PROCEDURE [dbo].[PROV_SEL_ACCIONISTAS_SP]
@idProspecto INT
AS
BEGIN

	SELECT   idAccionista
			
			,nombreAccionista
			,idProspecto
	FROM	dbo.PROV_ACCIONISTAS
	WHERE	idProspecto = @idProspecto
END

go

