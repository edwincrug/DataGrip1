
CREATE PROCEDURE [dbo].[SEL_ABONOSBANCOS_NOCONTA]  (@iAnio int,@iMes int,@snoCuenta varchar(100),@sConciliados varchar(1), @dResultado numeric(18,6) Output)   
As
Declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@iIdBanco int,
@ipServidor    VARCHAR(100),
@ipLocal VARCHAR(50)
begin

set nocount on

  SELECT @ipLocal=local_net_address 
  FROM sys.dm_exec_connections c
  WHERE Session_id = @@SPID;

 

if (@ipLocal = @ipServidor)
begin
   select @ipServidor = '';
end
else
	begin
	   select @ipServidor = '[' + @ipServidor + '].'
	end


--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#ABONOSBANCOS]'))
--begin
--	drop table #ABONOSBANCOS
--end

Declare @ABONOSBANCOS TABLE 
(
		id_local [int] IDENTITY (1, 1),
		idBmer int,
		importe numeric(18,6),
		idBanco int,
		noCuenta varchar(50),
		Tipo varchar(1)
)

           select @iIdBanco = idBanco from referencias..BancoCuenta where numeroCuenta = @snoCuenta  

			if (@iIdBanco = 1)
			Begin
			    set @sQ = N'Insert INTO @ABONOSBANCOS (idBmer,importe,idBanco,noCuenta,Tipo) '
				set @sQ = @sQ + N' SELECT idBmer,importe,idBanco,noCuenta,''0'' as Tipo'				
				set @sQ = @sQ + N' FROM Referencias.dbo.BANCOMER WHERE '
				set @sQ = @sQ + N' Month(fechaOperacion) = @iMes and Year(fechaOperacion)=@iAnio' 
				set @sQ = @sQ + N' AND noCuenta = @snoCuenta AND esCargo = 0'
			end
			else
			begin				
				set @sQ = N'Insert INTO @ABONOSBANCOS (idBmer,importe,idBanco,noCuenta,Tipo) '
				set @sQ = @sQ + N' SELECT idSantander,Convert(numeric(18,6),importe),idbanco,noCuenta,''0'' as Tipo'
				set @sQ = @sQ + N' FROM Referencias.dbo.Santander WHERE '
				set @sQ = @sQ + N' Month(fechaMovimiento) = @iMes and Year(fechaMovimiento)=@iAnio' 
				set @sQ = @sQ + N' AND noCuenta = @snoCuenta AND signo = ''+'''
			end

			--print @sQ

			execute sp_executesql @sQ,N'@snoCuenta varchar(50),@iMes int,@iAnio int',@snoCuenta=@snoCuenta,@iMes=@iMes,@iAnio=@iAnio
			
			--SELECT * FROM #ABONOSBANCOS
			--select top 10000 * from referencias..Santander 
			--select * from referencias..BancoCuenta 

			--IDENTIFICO LOS REGISTROS CONCILIADOS Y NO CONCILIADOS, 0 = NO CONCILAIDOS, 1 = CONCILIADOS

			UPDATE A SET Tipo = '1' FROM @ABONOSBANCOS A INNER JOIN [referencias].[dbo].[RAPDeposito] D ON idBmer = idDeposito 
			INNER JOIN GA_Corporativa.dbo.cxc_refantypag R ON D.rap_folio = R.rap_folio 
			WHERE noCuenta = @snoCuenta AND A.idbanco = @iIdBanco  AND D.idBanco = @iIdBanco AND rap_idstatus <> 1

			--SELECT * FROM [referencias].[dbo].[RAPDeposito]

			--SELECT * FROM #ABONOSBANCOS WHERE Tipo = '0'  --NO CONCILIADOS
			--SELECT * FROM #ABONOSBANCOS WHERE Tipo = 1  --CONCILIADOS
			select @dResultado = sum(importe) from @ABONOSBANCOS WHERE Tipo = @sConciliados

	set nocount off
end --Del Store

/*
Declare
@iAnio int,
@iMes int,
@snoCuenta varchar(50),
@sConciliados varchar(1),
@dResultado numeric(18,6)

select @iAnio = 2018
select @iMes = 2
select @snoCuenta ='65504258249'  --'000000000195334667'  --Bancomer Suzuky  --Santander Suzuky 65504258249
select @sConciliados = '0'
select @dResultado = 0


execute [SEL_ABONOSBANCOS_NOCONTA]  @iAnio, @iMes,@snoCuenta,@sConciliados, @dResultado Output
print 'Resultado: ' + CAST(CONVERT(varchar, CAST(@dResultado AS money), 1) AS varchar)




*/
go

