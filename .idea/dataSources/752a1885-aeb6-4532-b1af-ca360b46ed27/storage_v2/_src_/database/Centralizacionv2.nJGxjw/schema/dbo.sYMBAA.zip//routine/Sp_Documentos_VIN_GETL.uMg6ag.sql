-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [dbo].[Sp_Documentos_VIN_GETL] 'AU-ZM-NZA-UN-7754'
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Documentos_VIN_GETL]
	@Cotizacion VARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT UNI.ucn_noserie VIN
	FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES UNI
	JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal COTI ON UNI.ucu_idcotizacion = COTI.ucu_idcotizacion
	WHERE COTI.ucu_foliocotizacion = @Cotizacion
END
go

