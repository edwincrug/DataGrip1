
CREATE PROCEDURE [dbo].[SEL_DIVISIONES_SP]
@idempleado int 
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
SELECT  distinct Div.[div_nombre] AS nombre
		,Div.[div_iddivision] AS idDivision
		,Div.[div_nombrecto] AS nombreCorto
FROM [ControlAplicaciones].[dbo].[cat_divisiones] Div
INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA  Orga ON Orga.div_iddivision = Div.div_iddivision
WHERE  Orga.usu_idusuario = @idempleado

	END TRY
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_DIVISIONES_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


--141


----------------------------------------------------------- SP empresas
go

