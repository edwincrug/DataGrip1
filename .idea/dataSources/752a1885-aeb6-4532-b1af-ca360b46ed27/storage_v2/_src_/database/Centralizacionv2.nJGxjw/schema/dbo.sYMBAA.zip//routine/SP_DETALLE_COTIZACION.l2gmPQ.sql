--USE [Centralizacionv2]
--GO
--/****** Object:  StoredProcedure [dbo].[SP_DETALLE_COTIZACION]    Script Date: 30/10/2018 02:26:31 p. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

CREATE PROCEDURE [dbo].[SP_DETALLE_COTIZACION] 
	@FolioCotizacion VARCHAR(100)
AS
BEGIN
 SET NOCOUNT ON;    

 
 DECLARE @Base                 VARCHAR(100)
 DECLARE @BaseConcentra        VARCHAR(100)
 DECLARE @BaseLocal            VARCHAR(100)
 DECLARE @IdCotizacion         VARCHAR(100)
 DECLARE @TipoCotizacion       VARCHAR(3)
 DECLARE @ConsultaUnidad       VARCHAR(max)
 DECLARE @ConsultaRefacciones  VARCHAR(max)
 DECLARE @ConsultaTramites     VARCHAR(max)
 DECLARE @ConsultaOtros        VARCHAR(max)
 DECLARE @ConsultaServicio     VARCHAR(max)  
 
 --INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE DONDE SE BUSCARA LA POLIZA  
SET @Base = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE catemp_nombrecto = 
(SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa = 
(SELECT ucu_idempresa FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)) 
AND suc_idsucursal = (SELECT ucu_idsucursal FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion))

--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE CONCENTRADORA
SET @BaseConcentra = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE tipo = 2 and catemp_nombrecto = 
(SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa = 
(SELECT ucu_idempresa FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)))

--INICIO VARIABLE CON LA IP Y NOMBRE DE LA BASE LOCAL
SET @BaseLocal = (SELECT '['+ ip_servidor + '].[' + nombre_base + '].DBO.' FROM DIG_CAT_BASES_BPRO WHERE tipo = 1 and suc_idsucursal = 
(SELECT ucu_idsucursal FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion))


--Incicio Variable consecutivo de cotizacion
SET @IdCotizacion = (SELECT ucu_idcotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion)
SET @TipoCotizacion = (SELECT ucu_tipocotizacion FROM cuentasporcobrar.DBO.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @FolioCotizacion) 


 --Creo tabla temporal 
CREATE TABLE #COTIZACION_DETALLE(
MODULO VARCHAR(30),
ID_COTIZACION NUMERIC,
CANTIDAD INT,
CLAVE_CATALOGO VARCHAR(250),
DESCRIPCION VARCHAR(500),
MODELO VARCHAR(250),
SERIE VARCHAR(250),
COLOR_EXT VARCHAR(100),
COLOR_INT VARCHAR(100),
PRECIO DECIMAL(18,2),
IVA DECIMAL(18,2),
TOTAL DECIMAL(18,2))

--QUERY CONSULTA UNIDADES        
IF @TipoCotizacion = 'NU' 
  BEGIN

    set @ConsultaUnidad = 'INSERT INTO #COTIZACION_DETALLE SELECT ''UNIDADES'',C.ucn_idcotizadetalle,1,ucn_idcatalogo,V.UNC_DESCRIPCION,ucn_modelo,ucn_noserie,ucn_colorext,
    ucn_colorint,CONVERT(DECIMAL(18,2),ucn_preciounidad),CONVERT(DECIMAL(18,2),ucn_iva),CONVERT(DECIMAL(18,2),ucn_total) 
    FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C INNER JOIN ' + @BaseConcentra + 'UNI_CATALOGO V ON C.ucn_idcatalogo = V.UNC_IDCATALOGO AND C.ucn_modelo = V.UNC_MODELO 
    WHERE ucu_idcotizacion = ' + @IdCotizacion -- C.ucn_estatus = 1 AND
    
  END
ELSE
  BEGIN  

    set @ConsultaUnidad = 'INSERT INTO #COTIZACION_DETALLE SELECT ''UNIDADES'',C.ucn_idcotizadetalle,1,ucn_idcatalogo='''',UNC_DESCRIPCION= U.VEH_TIPOAUTO,ucn_modelo,ucn_noserie,ucn_colorext,
    ucn_colorint,CONVERT(DECIMAL(18,2),ucn_preciounidad),CONVERT(DECIMAL(18,2),ucn_iva),CONVERT(DECIMAL(18,2),ucn_total) 
    FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C INNER JOIN ' + @BaseLocal + 'SER_VEHICULO U ON C.ucn_noserie = U.VEH_NUMSERIE
    WHERE ucu_idcotizacion = ' + @IdCotizacion -- C.ucn_estatus = 1 AND
  
   END
 
EXEC (@ConsultaUnidad)  

--QUERY CONSULTA REFACCIONES         
set @ConsultaRefacciones = 'INSERT INTO #COTIZACION_DETALLE SELECT ''ACCESORIOS'',C.ucn_idcotizadetalle,P.pmd_cantidad,P.pmd_idparte,PP.PTS_DESPARTE,'''','''','''','''',
P.pmd_preciounitario / 1.16,P.pmd_preciounitario - (P.pmd_preciounitario / 1.16),P.pmd_total 
FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C INNER JOIN ' + @Base + 'par_pedmostdet P ON C.ucn_idcotizadetalle = P.ucn_idcotizadetalle OR C.ucn_idcotizadetalle = P.ucn_idcotizadetallepost 
INNER JOIN ' + @Base + 'PAR_PARTES PP ON P.pmd_idparte = PP.PTS_IDPARTE WHERE P.pmd_estatus = 1 AND ucu_idcotizacion = ' + @IdCotizacion
 
EXEC (@ConsultaRefacciones)  

--QUERY CONSULTA TRAMITES         
set @ConsultaTramites = 'INSERT INTO #COTIZACION_DETALLE SELECT ''TRAMITES'', C.ucn_idcotizadetalle,1,P.PAR_DESCRIP1,a.uaw_descripcion,'''','''','''','''',a.uaw_importe / 1.16,
a.uaw_importe - (a.uaw_importe /1.16),a.uaw_importe
FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C INNER JOIN cuentasporcobrar.dbo.uni_anticiposweb A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle  OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost 
INNER JOIN ' + @Base + 'PNC_PARAMETR P ON A.uaw_idconceptopago = P.PAR_IDENPARA WHERE C.ucu_idcotizacion = ' + @IdCotizacion + ' AND A.uaw_estatus = 1 AND P.PAR_TIPOPARA = ''COCOCXC'''
 
EXEC (@ConsultaTramites)  

--QUERY CONSULTA OTROS         
set @ConsultaOtros = 'INSERT INTO #COTIZACION_DETALLE SELECT ''OTROS'',C.ucn_idcotizadetalle,A.ucd_cantidad,'''',A.ucd_descripcion,'''','''','''','''',A.ucd_preciounitario / 1.16,
A.ucd_preciounitario - (A.ucd_preciounitario / 1.16),A.ucd_preciounitario
FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C INNER JOIN cuentasporcobrar.dbo.uni_otroconceptosdet A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle  OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost 
WHERE A.ucd_estatus = 1 AND C.ucu_idcotizacion = ' + @IdCotizacion
 
EXEC (@ConsultaOtros) 

--QUERY CONSULTA SERVICIO         
set @ConsultaServicio = 'INSERT INTO #COTIZACION_DETALLE SELECT ''SERVICIO'',C.ucn_idcotizadetalle,1,PS.PQE_IDPAQUETE,PS.PQE_NOMPAQUETE,'''',PS.PQE_DESCRIPCION,'''','''',
A.upo_precio / 1.16 ,A.upo_precio - (A.upo_precio / 1.16),A.upo_precio
FROM cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES C INNER JOIN cuentasporcobrar.dbo.uni_preordenser A ON C.ucn_idcotizadetalle = A.ucn_idcotizadetalle  OR C.ucn_idcotizadetalle = A.ucn_idcotizadetallepost 
INNER JOIN ' + @Base + 'SER_PAQUESER PS ON A.upo_idpaquete = PS.PQE_IDPAQUETE WHERE A.upo_estatus = 1 AND C.ucu_idcotizacion = ' + @IdCotizacion
 
EXEC (@ConsultaServicio) 


SELECT * FROM #COTIZACION_DETALLE

END
go

