-- ===================================================================================================
-- Author:		  Alejandro Lopez Quiroz
-- Create date:   10/02/2016
-- Modified date: 08/06/2016 Lourdes Maldonado Sánchez 
-- Description:   Inserta la factura de entrega
--                checa si es un OC de Paln Piso o no, y ejecuta los SP segun coincide o no 
-- ===================================================================================================
--EXECUTE [INS_FACTURA_ENTREGA_SP_3] 'AU-ZM-ZAR-UN-PE-166', 1,1,1   --OPC 1:Coincide OPC 2:No coincide
CREATE PROCEDURE [dbo].[INS_FACTURA_ENTREGA_SP_3]
	 @folio VARCHAR(50) = ''
	,@idperfil     INT = 1
	,@opcion       INT = 0
	,@idAprobacion INT = 0
AS
BEGIN
	
	DECLARE @iResultadoOut INT = -1
    DECLARE @resulatdoSP   varchar(5)
	DECLARE @folioPlanPiso nvarchar(50)

    ----------------------------------------------------------------------
	-- Determino si es una orden Padre, busco la orden Hijo
	----------------------------------------------------------------------
	SELECT @folioPlanPiso = Folio_Alias  
      FROM dbo.DIG_EXP_PLAN_PISO 
     WHERE Folio_Operacion = @folio
    PRINT('PLAN PISO:'+ @folioPlanPiso);

    IF EXISTS (SELECT Folio_Alias  
				  FROM dbo.DIG_EXP_PLAN_PISO 
				 WHERE Folio_Operacion = @folio)
	BEGIN
	     SET @folio = @folioPlanPiso
    END
	PRINT('FINAL:'+ @folio);

	----------------------------------------------------------------------
	-- Coincide
	----------------------------------------------------------------------
	IF(@opcion = 1) 
		BEGIN
		   -- Si es 0 hubo error y se deja la pantalla como estaba y se notifica al usuario que la
		   --'El importe de la factura es diferente al de la Orden de Compra' lo dejo en la misma pantalla
		   -- Si es 1 se queda como esta 
		   EXECUTE @iResultadoOut = [SP_INSERTA_UUID_XML] @folio
		   PRINT 'La Factura Coincide' 
		   SELECT @iResultadoOut  		   
		END
	ELSE
	----------------------------------------------------------------------
	-- No Coincide
	---------------------------------------------------------------------- 
		BEGIN
		    -- Al ejecutar este SP pone las Fecha_Creacion en Null por eso aparece como si no existiera la factura
			-- Regresa 1 si se pudo hacer la desvinculacion de la factura.
            -- Regresa 0 si hubo un error al hacer la desvinculacion de la factura.
		    EXECUTE @iResultadoOut = [spU_DESVINCULA_FACTURA] @iProc_Id = 1, @sFolio_Operacion = @folio ,@iResultado = 0
			PRINT 'La Factura No Coincide' 
			SELECT @iResultadoOut 
		END
		
    --LMS  Mando a llamar al sp [UPD_APROBACION_SP] @idAprobacion,@respuesta,@observacion
	--EXECUTE [Notificacion].[dbo].[UPD_APROBACION_SP] @idAprobacion, 1, 'Factura Validada'		
END
go

