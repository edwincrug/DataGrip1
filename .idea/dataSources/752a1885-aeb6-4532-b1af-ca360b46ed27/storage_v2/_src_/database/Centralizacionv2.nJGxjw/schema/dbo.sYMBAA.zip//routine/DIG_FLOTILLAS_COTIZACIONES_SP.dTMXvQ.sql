-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- DIG_FLOTILLAS_COTIZACIONES_SP 'AU-ZM-NZA-UN-7503' 
-- DIG_FLOTILLAS_COTIZACIONES_SP 'AU-HY-HEC-UN-2120'
-- =============================================
CREATE PROCEDURE [dbo].[DIG_FLOTILLAS_COTIZACIONES_SP]
	@cotizacionGlobal VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT  
		E.Folio_Operacion    AS Folio_Operacion
		,'N/A'               AS tipoorden
		,CONVERT(VARCHAR(20), O.ucu_fechacotiza,103)    AS oce_fechaorden
		,ST.cec_nombre AS situacionOrden
		,RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor--PER.Persona as Proveedor
		,EM.emp_nombre     AS empNombre
		,S.suc_nombre      AS sucursal
		,D.dep_nombre      AS depto
		,SUM(CD.ucn_total)  AS oce_importetotal
		,O.ucu_idcliente   AS esPlanta            --idCliente para CXC
		,1                 AS nodoactual          --NodoAcutal
		,1                 AS tipofolio
	FROM dbo.DIG_EXPEDIENTE AS E 
		INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
		INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON CD.ucu_idcotizacion = O.ucu_idcotizacion
		INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
		INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
		INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
		INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
		INNER JOIN cuentasporcobrar.dbo.cat_estatuscotiza AS ST ON  ST.cec_idestatuscotiza = O.cec_idestatuscotiza
		INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS PER ON O.ucu_idcliente =  PER.PER_IDPERSONA
	WHERE  E.Folio_Operacion = @cotizacionGlobal
	GROUP BY Folio_Operacion, O.ucu_fechacotiza, EM.emp_nombre, S.suc_nombre, D.dep_nombre, O.ucu_idcliente,ST.cec_nombre, PER.PER_NOMRAZON, PER.PER_PATERNO, PER.PER_MATERNO--,PER.Persona
END
go

