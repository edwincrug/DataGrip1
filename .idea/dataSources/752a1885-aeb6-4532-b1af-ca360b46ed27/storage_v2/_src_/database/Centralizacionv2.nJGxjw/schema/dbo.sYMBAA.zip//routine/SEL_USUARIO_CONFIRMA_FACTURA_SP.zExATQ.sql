CREATE PROCEDURE [dbo].[SEL_USUARIO_CONFIRMA_FACTURA_SP] 
	@idUsuario NUMERIC(18,0) = 0
AS
BEGIN
	
	SELECT seg_idCentralizacion,seg_idUsuario 
	FROM Seguridad..SEG_CENTRALIZACION 
	WHERE seg_idUsuario = @idUsuario
	--LQMA ADD 21062017, se agregaron filtros a tabla SEG_CENTRALIZACION, para separar por modulo, accion y portal  
		  AND seg_idAccion = 2 --Confirmar 
		  AND seg_idModulo = 1 --Factura
		  AND seg_idPortal = 1 --Digitalizacion
END
go

