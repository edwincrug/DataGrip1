

CREATE PROCEDURE [dbo].[PROV_DEL_PROSPECTO_ROL_SP]
@idProspectoRol INT
		  
          

AS
BEGIN
BEGIN TRY
		
		DELETE FROM [dbo].[PROV_PROSPECTO_ROL] WHERE idProspectoRol = @idProspectoRol
		SELECT 1 result
	

END TRY
BEGIN CATCH

END CATCH 
		SELECT 0 result

END


go

