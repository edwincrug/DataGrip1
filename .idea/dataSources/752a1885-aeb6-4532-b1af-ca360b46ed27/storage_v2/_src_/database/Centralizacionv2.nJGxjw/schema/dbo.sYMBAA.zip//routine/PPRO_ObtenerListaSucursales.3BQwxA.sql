-- =============================================    
-- Author:  Mario Alejandro Santiago de la Cruz 
-- Create date: 11/01/2016   
-- Description: obtener todas las Sucursales  
-- ============================================= 
-- [dbo].[PPRO_ObtenerListaSucursales]   4,'HEHJ520304R36',1
CREATE PROCEDURE [dbo].[PPRO_ObtenerListaSucursales](   
@emp_idempresa AS INT=null,
@user VARCHAR(15) = '',
@idUserRol INT = 0 ,
@idProveedor INT = 0
)
AS    
SET NOCOUNT ON


IF(@idUserRol = 1)
    BEGIN
    
			   --SELECT 0 as suc_idsucursal,'---Elije una opción---' as suc_nombre,'OP' as suc_nombrecto
			   --UNION
			   SELECT [suc_idsucursal] 
			   ,[suc_nombre] 
			   ,[suc_nombrecto] 
				FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
				WHERE [emp_idempresa]= @emp_idempresa 
					AND [suc_idsucursal] IN (SELECT oce_idsucursal 
											 FROM cuentasxpagar.dbo.cxp_ordencompra 
											 WHERE oce_folioorden IN (SELECT oce_folioorden 
																	  FROM cuentasxpagar.dbo.cxp_ordencompra 
																	  WHERE oce_idproveedor IN(SELECT per_idpersona 
																							   FROM GA_Corporativa.dbo.PER_PERSONAS 
																							   WHERE per_rfc = @user))
											 AND oce_idempresa = @emp_idempresa
											 GROUP BY oce_idempresa,oce_idsucursal)			   

			   /*SELECT [suc_idsucursal] 
			   ,[suc_nombre] 
			   ,[suc_nombrecto] 
				FROM [ControlAplicaciones].[dbo].[cat_sucursales] 
				WHERE [emp_idempresa]= @emp_idempresa*/			

	END
ELSE
	BEGIN			

			--SELECT 0 as suc_idsucursal,'---Elije una opción---' as suc_nombre,'OP' as suc_nombrecto
			--UNION
			SELECT [suc_idsucursal] ,[suc_nombre] ,[suc_nombrecto] 
			FROM [ControlAplicaciones].[dbo].[cat_sucursales] 				
			WHERE [emp_idempresa]= @emp_idempresa AND 
				  [suc_idsucursal] IN ( SELECT DISTINCT suc_idsucursal 
										FROM [ControlAplicaciones].[dbo].[ope_organigrama]
										WHERE [usu_idusuario] = @idProveedor
										AND emp_idempresa = @emp_idempresa)
												/*(SELECT usu_idusuario 
																 FROM [ControlAplicaciones].[dbo].[cat_usuarios] 
																 WHERE usu_nombreusu = @user)
										AND emp_idempresa = @emp_idempresa)*/

	END

SET NOCOUNT OFF

go

