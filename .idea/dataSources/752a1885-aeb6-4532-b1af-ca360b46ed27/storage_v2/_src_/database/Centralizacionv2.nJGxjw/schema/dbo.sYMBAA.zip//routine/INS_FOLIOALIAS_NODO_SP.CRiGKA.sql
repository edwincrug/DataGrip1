-- =============================================
-- Author:		ALEJANDRO LOPEZ
-- Create date: 18/01/2016
-- Description:	Inserta un folio alias relacionado a un folio original con un id de nodo
-- =============================================

CREATE PROCEDURE [dbo].[INS_FOLIOALIAS_NODO_SP]	 
	@folio_Operacion varchar(80)
	,@folio_Alias varchar(80)	
 
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	

		INSERT INTO [dbo].[DIG_EXP_PLAN_PISO]
		VALUES(@folio_Operacion,@folio_Alias,GETDATE())

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[INS_FOLIOALIAS_NODO_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END

go

