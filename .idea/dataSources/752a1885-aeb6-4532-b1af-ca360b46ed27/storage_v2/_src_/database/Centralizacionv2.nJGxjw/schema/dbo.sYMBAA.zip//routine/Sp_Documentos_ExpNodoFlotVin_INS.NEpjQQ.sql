-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [dbo].[Sp_Documentos_ExpNodoFlot_INS] 'AU-ZM-NZA-UN-7754', '3N6AD35A3LK854762'
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Documentos_ExpNodoFlotVin_INS]
	@Cotizacion VARCHAR( 50 ) = NULL
	,@Serie VARCHAR(50) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRANSACTION TRAN_DOCS
	BEGIN TRY
		
		DECLARE @Tamanio INT = LEN(@Serie);

		IF( @Tamanio = 17 )
			BEGIN
				INSERT INTO DIG_EXPNODO_DOC_FLOT( [Doc_Id], [Proc_Id], [Folio_Operacion], [No_Serie] )
				SELECT 
						DOCS.[Doc_Id]
						,DOCS.[Proc_Id]
						,DOCS.[Folio_Operacion]
						,DOCS.[No_Serie]
				FROM	(SELECT 
							DISTINCT ND.[Doc_Id]
							,[Proc_Id] = 2
							,[Folio_Operacion] = @Cotizacion
							,[No_Serie] = @Serie
						FROM [DIG_EXPNODO_DOC] DN
						JOIN DIG_NODO_DOC ND ON DN.Nodo_Id = ND.Nodo_Id  AND DN.[Doc_Id] = ND.[Doc_Id]
						JOIN [DIG_CATDOCUMENTO] CD ON ND.Doc_Id = CD.Doc_Id AND CD.Doc_Origen <> 2 
						JOIN [DIG_RELACION_VENTA_DOCUMENTOS] RVD ON RVD.Doc_Id = CD.Doc_Id AND RVD.PorUnidad = 1
						WHERE DN.[Folio_Operacion] = @Cotizacion ) DOCS
						LEFT JOIN DIG_EXPNODO_DOC_FLOT F ON DOCS.Folio_Operacion = F.Folio_Operacion AND DOCS.No_Serie = F.No_Serie AND DOCS.Doc_Id = F.Doc_Id
				WHERE	F.Doc_Id IS NULL;
			END

		COMMIT TRANSACTION TRAN_DOCS
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION TRAN_DOCS
		
		DECLARE @Mensaje  NVARCHAR(MAX)		
		SELECT @Mensaje = ERROR_MESSAGE() + ' @Serie : ' + @Serie
		EXECUTE INS_ERROR_SP '[dbo].[Sp_Documentos_ExpNodoFlotVin_INS]', @Mensaje
	END CATCH
END
go

