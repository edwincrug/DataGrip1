
CREATE PROCEDURE [dbo].[PROV_VALIDA_LOGIN]
@rfc VARCHAR(20)
,@pass VARCHAR(20)
AS
BEGIN
			DECLARE @passEnc VARCHAR(100)
			DECLARE @passDecry  VARCHAR(50)
			DECLARE @SQLString nvarchar(500)
			DECLARE @ParmDefinition nvarchar(500) 
			
			SELECT @passEnc = ppro_pass FROM PPRO_USERSPORTALPROV WHERE ppro_User = @rfc
								
			SET @SQLString =N'SELECT @passD = convert(varchar(MAX),DecryptByPassPhrase(''4ndr4d3'',  '+ @passEnc +' )) '	 
			SET @ParmDefinition = N' @passD varchar(MAX) OUTPUT'; 
			
			
			EXECUTE sp_executesql @SQLString, @ParmDefinition, @passD=@passDecry OUTPUT;
			
			

		IF EXISTS(SELECT 1 FROM Centralizacionv2.dbo.PROV_PROSPECTO WHERE PER_RFC = @rfc AND PER_STATUS = 0 )
		BEGIN

			IF EXISTS(SELECT 1 FROM CentralizacionV2.dbo.PPRO_USERSPORTALPROV WHERE  ppro_user like @rfc AND @passDecry = @pass)
			BEGIN
				SELECT 1 result, PER_IDPERSONA idProspecto
				FROM Centralizacionv2.dbo.PROV_PROSPECTO PP WHERE PER_RFC = @rfc
			END
			ELSE
			BEGIN
				SELECT 0 result, 0 idProspecto 
			END
		END
		ELSE
		BEGIN 
			SELECT -1 result, -1 idProspecto 
		END
END
go

