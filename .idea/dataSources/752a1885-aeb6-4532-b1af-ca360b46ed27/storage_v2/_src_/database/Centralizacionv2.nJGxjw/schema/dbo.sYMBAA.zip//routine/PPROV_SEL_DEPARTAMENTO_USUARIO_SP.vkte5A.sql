/*
PPROV_SEL_DEPARTAMENTO_USUARIO_SP @idUsuario = 29,@idSucursal = 2
*/
CREATE PROCEDURE [dbo].[PPROV_SEL_DEPARTAMENTO_USUARIO_SP]
@idUsuario INT = 0,
@idSucursal INT = 0
AS
BEGIN

  --SELECT '--Seleccione--' dep_nombre,-1 dep_iddepartamento
  --UNION		
  SELECT DISTINCT (Depto.dep_nombre) dep_nombre, 
				   Depto.dep_iddepartamento dep_iddepartamento
  FROM [ControlAplicaciones].[dbo].[ope_organigrama] Orga
  INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] Depto ON Orga.dep_iddepartamento = Depto.dep_iddepartamento
  WHERE Orga.usu_idUsuario = @idUsuario 
	    AND Orga.suc_idsucursal = @idSucursal
  ORDER BY dep_iddepartamento	
 END
go

