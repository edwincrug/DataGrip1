-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Sp_Documentos_GeneralesUnidad_GETL] 'AU-AA-AAZ-UN-8511', 2
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Documentos_GeneralesUnidad_GETL] 
	@folio VARCHAR(50),
	@idProceso INT
AS
BEGIN
	--DECLARE @folio VARCHAR(50) = 'AU-ZM-NZA-UN-7824'
	--,@idProceso INT = 2


	SET NOCOUNT ON;

	DECLARE @imgCXP VARCHAR(100), @imgCXC VARCHAR(100);

	SELECT 
		@imgCXP = par_valor 
	FROM DIG_PARAMETROS WHERE par_descripcion = 'IMGCXP'
	SELECT 
		@imgCXC = par_valor 
	FROM DIG_PARAMETROS WHERE par_descripcion = 'IMGCXC'
	PRINT @imgCXP
	PRINT @imgCXC

	
	
	
	--SET @imgCXC = 'http://localhost:8001/CuentasXCobrar/Cargas/';
	--
	-- Validamos el estatus de la cotización para indicar si aplica o no carga de documentos
	--
	DECLARE @Result INT = 1; -- 1 Puede cargar, 0 No puede cargar
	-- =====================================================================================
	-- Validamos que la cotizacion no este cancelada (14) ni Entregada (20)
	-- =====================================================================================
	IF EXISTS( SELECT ucu_foliocotizacion FROM cuentasporcobrar.dbo.uni_cotizacionuniversal WHERE ucu_foliocotizacion = @Folio AND cec_idestatuscotiza IN (14) )
		BEGIN
			-- Esta cancelada o entregada
			SET @Result = 0;
		END




	IF(@idProceso = 1)
		BEGIN
			SELECT	DISTINCT Doc_Nombre
					,Doc_Descripcion
					,ND.Doc_Id 
					,CASE	WHEN Fecha_Creacion IS NULL THEN ''
							ELSE @imgCXP + DN.[Folio_Operacion] + '/' + CONVERT(VARCHAR(5),DD.Doc_Id) + '.pdf' 
					 END AS existeDoc
					 ,DD.Cargar AS cargar
					 ,active = @Result
			FROM	[dbo].[DIG_PERFIL_DOCUMENTO] DD
					INNER JOIN DIG_CATDOCUMENTO D ON D.Doc_id = DD.Doc_Id
					INNER JOIN DIG_NODO_DOC AS ND ON ND.Doc_Id = D.Doc_Id 
					INNER JOIN [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] AS DN ON DN.Nodo_Id = ND.Nodo_Id  AND DN.[Doc_Id] = ND.[Doc_Id]
			WHERE	DD.Cargar = 1 
					AND D.Proc_Id = @idProceso
					AND DN.[Folio_Operacion] = @folio
			ORDER BY D.Doc_Nombre ASC
		END
	ELSE IF (@idProceso = 2)
		BEGIN 
			SELECT  DISTINCT Doc_Nombre
					,Doc_Descripcion
					,ND.Doc_Id 
					,CASE	WHEN Fecha_Creacion IS NULL THEN ''
							ELSE @imgCXC + CU.ucu_foliocotizacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf' 
					 END AS existeDoc
					 ,CASE	WHEN DN.Fecha_Creacion IS NULL THEN 1
							ELSE 0
					 END AS  cargar
					 ,isNULL(DM.idMandatorio,0) mandatorio
					 ,active = @Result
			FROM	DIG_NODO_DOC  AS ND	 
					INNER JOIN [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] AS CD ON CD.Doc_Id = ND.Doc_Id AND CD.Doc_Origen <> 2
					INNER JOIN [Centralizacionv2].[dbo].[DIG_RELACION_VENTA_DOCUMENTOS] AS RVD ON ND.Doc_Id = RVD.Doc_Id
					INNER JOIN [Centralizacionv2].[dbo].[DIG_CANAL_VENTA] AS CV ON RVD.IdTipoVenta = CV.idTipoVenta
					INNER JOIN [Centralizacionv2].[dbo].[DIG_CATALOGO_TIPO_VENTA] AS TV ON TV.IdTipoVenta = RVD.IdTipoVenta
					INNER JOIN [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] AS CU ON CU.ucu_idtipoventa = CV.canalVenta COLLATE SQL_Latin1_General_CP1_CI_AS  AND CU.ucu_idempresa = CV.idEmpresa AND CU.ucu_idsucursal = CV.idSucursal
					INNER JOIN [Centralizacionv2].[dbo].[DIG_PERFIL_DOCUMENTO] AS PD ON PD.Doc_Id = CD.Doc_Id AND Cargar = 1
					INNER JOIN [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] AS DN ON DN.Nodo_Id = ND.Nodo_Id  AND DN.[Folio_Operacion] = CU.ucu_foliocotizacion COLLATE SQL_Latin1_General_CP1_CI_AS AND DN.[Doc_Id] = ND.[Doc_Id]
					LEFT JOIN Centralizacionv2.dbo.EXP_DOCUMENTOS_MANDATORIO AS DM ON DM.idTipoVenta = CV.idTipoVenta AND DM.idEmpresa = CU.ucu_idempresa AND DM.idSucursal = CU.ucu_idsucursal AND DM.Doc_Id = ND.Doc_Id 
			WHERE	ND.Proc_Id = @idProceso 
					AND CU.ucu_foliocotizacion = @folio
		END
END
go

