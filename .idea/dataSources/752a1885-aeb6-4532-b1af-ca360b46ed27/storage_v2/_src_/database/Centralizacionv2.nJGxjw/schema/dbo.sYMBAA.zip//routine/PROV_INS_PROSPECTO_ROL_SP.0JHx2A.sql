
CREATE PROCEDURE [dbo].[PROV_INS_PROSPECTO_ROL_SP]

		    @idProspecto INT
           ,@rol	 VARCHAR(15)
		   ,@nombreRol VARCHAR(50)
		   ,@empresaId INT
		   ,@empresaBD VARCHAR(50)
          

AS
BEGIN
BEGIN TRY
		
		IF NOT EXISTS (SELECT 1 FROM [dbo].[PROV_PROSPECTO_ROL] WHERE idProspecto = @idProspecto AND rol = @rol and empresaId = @empresaId)
		BEGIN
			INSERT INTO [dbo].[PROV_PROSPECTO_ROL]
			   ([idProspecto]
			   ,[rol]
			   ,[nombreRol]
			   ,empresaId
			   ,empresaBD)
			VALUES(
			   @idProspecto
			   ,@rol
			   ,@nombreRol
			   ,@empresaId
			   ,@empresaBD  )
			 SELECT SCOPE_IDENTITY() result, 'Rol agregado con éxito' msg
		END
		ELSE
		BEGIN
			SELECT 0 result,  'El rol seleccionado ya existe para este prospecto.' msg
		END



END TRY
BEGIN CATCH

END CATCH 
		SELECT -1 result, 'Ocurrio un error al agregar el tipo de proveedor. ' msg 

END
go

