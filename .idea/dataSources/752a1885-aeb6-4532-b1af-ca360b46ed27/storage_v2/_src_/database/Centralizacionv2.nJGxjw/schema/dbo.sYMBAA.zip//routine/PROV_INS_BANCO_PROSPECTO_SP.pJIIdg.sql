CREATE PROCEDURE [dbo].[PROV_INS_BANCO_PROSPECTO_SP]

		    @idProspecto INT
           ,@titular	 VARCHAR(100)
           ,@banco		 VARCHAR(50)
           ,@sucursal	 VARCHAR(50)
           ,@noCuenta	 VARCHAR(30)
           ,@clabe		 VARCHAR(30)
           ,@cie		 VARCHAR(30) = ''
           ,@referencia	 VARCHAR(50) 
		   ,@cveBanxico  VARCHAR(10)
		   ,@cveBanco	 VARCHAR(10)
		   ,@empresaId   INT = 0
		   ,@rfc		VARCHAR(50) = ''

AS
BEGIN
BEGIN TRY

		IF(@rfc = '')
		BEGIN

				IF NOT EXISTS (	SELECT 1 FROM PROV_PROSPECTO PP
								INNER JOIN Tramites.dbo.Personas P on PP.PER_RFC = p.per_rfc
								INNER JOIN Tramites.dbo.PersonaTramite PT on P.id_persona = PT.id_Persona 
								WHERE PER_IDPERSONA = @idProspecto AND PT.petr_estatus  in (0,1,11,12) AND PT.id_tramite in (1,2,5))
				BEGIN	
						IF NOT EXISTS (SELECT 1 from PROV_CUENTA_BANCARIA B where b.noCuenta = @noCuenta AND B.cveBanxico = @cveBanxico )
						
						BEGIN 

							--DELETE FROM PROV_CUENTA_BANCARIA WHERE noCuenta = @noCuenta AND cveBanxico = @cveBanxico

							INSERT INTO [dbo].[PROV_CUENTA_BANCARIA]
							   ([idProspecto]
							   ,[titular]
							   ,[banco]
							   ,[sucursal]
							   ,[noCuenta]
							   ,[clabe]
							   ,[cie]
							   ,[referencia]
							   ,cveBanxico
							   ,cveBanco
							   ,empresaId)
							VALUES(
							   @idProspecto
							   ,@titular	
							   ,@banco		
							   ,@sucursal	
							   ,@noCuenta	
							   ,@clabe		
							   ,isnull(@cie,'')		
							   ,@referencia
							   ,@cveBanxico	
							   ,@cveBanco
							   ,@empresaId)

							-- eliminar y crear
							PRINT 'no existe'
							SELECT SCOPE_IDENTITY() result

						END ELSE IF EXISTS (	SELECT 1 FROM PROV_CUENTA_BANCARIA B
												LEFT JOIN Tramites.dbo.detallePersonaCuenta D ON B.noCuenta = D.noCuenta and B.cveBanxico = D.idBanxico
												WHERE D.id_perTra is null AND B.noCuenta =@noCuenta AND cveBanxico = @cveBanxico )
						
						BEGIN
							 PRINT 'no Existe en trámites'
							 DELETE FROM PROV_CUENTA_BANCARIA WHERE noCuenta = @noCuenta AND cveBanxico = @cveBanxico

							 INSERT INTO [dbo].[PROV_CUENTA_BANCARIA]
								   ([idProspecto]
								   ,[titular]
								   ,[banco]
								   ,[sucursal]
								   ,[noCuenta]
								   ,[clabe]
								   ,[cie]
								   ,[referencia]
								   ,cveBanxico
								   ,cveBanco
								   ,empresaId)
								VALUES(
								   @idProspecto
								   ,@titular	
								   ,@banco		
								   ,@sucursal	
								   ,@noCuenta	
								   ,@clabe		
								   ,isnull(@cie,'')		
								   ,@referencia
								   ,@cveBanxico	
								   ,@cveBanco
								   ,@empresaId)
							
							SELECT SCOPE_IDENTITY() result
						END
				
				
						ELSE  IF EXISTS(SELECT 1 from PROV_CUENTA_BANCARIA B
											INNER JOIN Tramites.dbo.detallePersonaCuenta D ON B.noCuenta = D.noCuenta AND B.cveBanxico = D.idBanxico
											INNER JOIN Tramites.dbo.personaTramite PT on PT.id_perTra = D.id_perTra
											WHERE petr_estatus not in (3) AND B.noCuenta = @noCuenta AND idBanxico = @cveBanxico AND PT.id_tramite in (1,2,5) )
						BEGIN
							print 'Existe en tramites'
							SELECT -1 result

						END
						
						ELSE IF EXISTS(select 1 from PROV_CUENTA_BANCARIA B
											inner join Tramites.dbo.detallePersonaCuenta D ON B.noCuenta = D.noCuenta and B.cveBanxico = D.idBanxico
											inner join Tramites.dbo.personaTramite PT on PT.id_perTra = D.id_perTra
											where petr_estatus  in (3) AND B.noCuenta = @noCuenta AND idBanxico = @cveBanxico AND PT.id_tramite in (1,2,5)) 
						BEGIN
							 PRINT 'tiene tramite cancelado'
							 DELETE FROM PROV_CUENTA_BANCARIA WHERE noCuenta = @noCuenta AND cveBanxico = @cveBanxico

							 INSERT INTO [dbo].[PROV_CUENTA_BANCARIA]
								   ([idProspecto]
								   ,[titular]
								   ,[banco]
								   ,[sucursal]
								   ,[noCuenta]
								   ,[clabe]
								   ,[cie]
								   ,[referencia]
								   ,cveBanxico
								   ,cveBanco
								   ,empresaId)
								VALUES(
								   @idProspecto
								   ,@titular	
								   ,@banco		
								   ,@sucursal	
								   ,@noCuenta	
								   ,@clabe		
								   ,isnull(@cie,'')		
								   ,@referencia
								   ,@cveBanxico	
								   ,@cveBanco
								   ,@empresaId)
						
							SELECT SCOPE_IDENTITY() result
				
						END	
				
				

				END
				ELSE
					BEGIN
						print 'No puede dar de alta cuenta por que tiene un trámite pendiente'
						SELECT -2 result
					END
	
		END
		ELSE
		BEGIN  
				IF NOT EXISTS (SELECT 1 FROM PROV_PROSPECTO PP
								INNER JOIN Tramites.dbo.Personas P on PP.PER_RFC = p.per_rfc
								INNER JOIN Tramites.dbo.PersonaTramite PT on P.id_persona = PT.id_Persona 
								WHERE PP.PER_RFC = @rfc AND PT.petr_estatus  in (0,1,11,12) AND PT.id_tramite in (1,2,5))
				BEGIN
					IF NOT EXISTS (SELECT 1 from PROV_CUENTA_BANCARIA B where b.noCuenta = @noCuenta AND B.cveBanxico = @cveBanxico )
						BEGIN
							INSERT INTO [dbo].[PROV_CUENTA_BANCARIA]
								   (rfcProspecto
								   ,[titular]
								   ,[banco]
								   ,[sucursal]
								   ,[noCuenta]
								   ,[clabe]
								   ,[cie]
								   ,[referencia]
								   ,cveBanxico
								   ,cveBanco
								   ,empresaId)
								VALUES(
									@rfc
								   ,@titular	
								   ,@banco		
								   ,@sucursal	
								   ,@noCuenta	
								   ,@clabe		
								   ,isnull(@cie,'')		
								   ,@referencia
								   ,@cveBanxico	
								   ,@cveBanco
								   ,@empresaId)
							SELECT SCOPE_IDENTITY() result

							PRINT 'No existe cuenta'
						END
						ELSE IF EXISTS ( SELECT 1 FROM PROV_CUENTA_BANCARIA B
						LEFT JOIN Tramites.dbo.detallePersonaCuenta D ON B.noCuenta = D.noCuenta and B.cveBanxico = D.idBanxico
						WHERE D.id_perTra is null AND B.noCuenta =@noCuenta AND cveBanxico = @cveBanxico )
							BEGIN 

										DELETE FROM PROV_CUENTA_BANCARIA WHERE noCuenta = @noCuenta AND cveBanxico = @cveBanxico

										INSERT INTO [dbo].[PROV_CUENTA_BANCARIA]
											   (rfcProspecto
											   ,[titular]
											   ,[banco]
											   ,[sucursal]
											   ,[noCuenta]
											   ,[clabe]
											   ,[cie]
											   ,[referencia]
											   ,cveBanxico
											   ,cveBanco
											   ,empresaId)
											VALUES(
												@rfc
											   ,@titular	
											   ,@banco		
											   ,@sucursal	
											   ,@noCuenta	
											   ,@clabe		
											   ,isnull(@cie,'')		
											   ,@referencia
											   ,@cveBanxico	
											   ,@cveBanco
											   ,@empresaId)
										SELECT SCOPE_IDENTITY() result

									-- eliminar y crear
									PRINT 'No esta en tramites'
							END ELSE IF EXISTS(select 1 from PROV_CUENTA_BANCARIA B
												inner join Tramites.dbo.detallePersonaCuenta D ON B.noCuenta = D.noCuenta and B.cveBanxico = D.idBanxico
												inner join Tramites.dbo.personaTramite PT on PT.id_perTra = D.id_perTra
												where petr_estatus not in (3) AND B.noCuenta = @noCuenta AND idBanxico = @cveBanxico AND PT.id_tramite in (1,2,5) )
								BEGIN
									
									PRINT 'Existe en trámites'
									SELECT -1 result
								
								END ELSE IF EXISTS( select 1 from PROV_CUENTA_BANCARIA B
												INNER JOIN Tramites.dbo.detallePersonaCuenta D ON B.noCuenta = D.noCuenta and B.cveBanxico = D.idBanxico
												INNER JOIN Tramites.dbo.personaTramite PT on PT.id_perTra = D.id_perTra
												where petr_estatus  in (3) AND B.noCuenta = @noCuenta AND idBanxico = @cveBanxico AND PT.id_tramite in (1,2,5)) 
									BEGIN
									-- eliminar y crear
	
									DELETE FROM PROV_CUENTA_BANCARIA WHERE noCuenta = @noCuenta AND cveBanxico = @cveBanxico

				
									INSERT INTO [dbo].[PROV_CUENTA_BANCARIA]
										   (rfcProspecto
										   ,[titular]
										   ,[banco]
										   ,[sucursal]
										   ,[noCuenta]
										   ,[clabe]
										   ,[cie]
										   ,[referencia]
										   ,cveBanxico
										   ,cveBanco
										   ,empresaId)
										VALUES(
											@rfc
										   ,@titular	
										   ,@banco		
										   ,@sucursal	
										   ,@noCuenta	
										   ,@clabe		
										   ,isnull(@cie,'')		
										   ,@referencia
										   ,@cveBanxico	
										   ,@cveBanco
										   ,@empresaId)
								  SELECT SCOPE_IDENTITY() result
				
								PRINT 'tiene tramite cancelado'
				
				
							END
				
				END
				ELSE
				BEGIN
					SELECT -2 result
				END

		END

END TRY
BEGIN CATCH

END CATCH 
		SELECT 0 result

END
go

