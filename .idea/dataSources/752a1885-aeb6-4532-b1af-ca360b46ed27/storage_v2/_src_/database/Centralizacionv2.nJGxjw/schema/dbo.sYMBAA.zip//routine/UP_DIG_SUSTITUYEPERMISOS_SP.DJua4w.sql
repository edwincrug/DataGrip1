--QUITANDO LOS PERMISOS A UN USUARIO Y PONERSELOS A OTRO
/*
select * from ControlAplicaciones..cat_usuarios where usu_nombreusu = '8LMA0' usu_paterno=''
--507 8CRF CANTORAN REBOLLEDO FRANCISCO
--771 8LMA0 LoREDO

select * from ControlAplicaciones..cat_usuarios where usu_idusuario = 765
--765 
select * from DIG_ESCALAMIENTO where suc_idsucursal=8

Declare @usuarioquita int = 507;
Declare @usuariopon int = 771;
Declare @sPonComoSegundo varchar(2) = 'NO';

Execute UP_DIG_SUSTITUYEPERMISOS_SP @usuarioquita,@usuariopon,@sPonComoSegundo

--update DIG_ESCALAMIENTO set Usuario_Autoriza2 = 82 where escalamientoId in (57,58)  suc_idsucursal=8 and dep_iddepartaamento in (38,39)

			 Declare @sBase varchar(50);
			 select @sBase = 'GAZM_Faerea'

			 select de.escalamientoId,  usu_idusuario, usu_nombreusu,usu_paterno + ' ' + usu_materno + ' ' + usu_nombre as Usuario_Autoriza_UNO, '' as Usuario_Autoriza_DOS, '' as Usuario_Autoriza_TRES, dpt.dep_nombre 
			 from Centralizacionv2..DIG_ESCALAMIENTO de, ControlAplicaciones..cat_usuarios cu, ControlAplicaciones..cat_departamentos dpt , Centralizacionv2..DIG_CAT_BASES_BPRO cb 
			 where de.suc_idsucursal = cb.suc_idsucursal 
			 and de.Usuario_Autoriza1 = cu.usu_idusuario 
			 and de.suc_idsucursal = dpt.suc_idsucursal
			 and de.dep_iddepartaamento = dpt.dep_iddepartamento 
			 and cb.nombre_base = @sBase
			 UNION ALL
			 select de.escalamientoId, usu_idusuario, usu_nombreusu, ' ', usu_paterno + ' ' + usu_materno + ' ' + usu_nombre,  ' ' , dpt.dep_nombre 
			 from Centralizacionv2..DIG_ESCALAMIENTO de, ControlAplicaciones..cat_usuarios cu, ControlAplicaciones..cat_departamentos dpt , Centralizacionv2..DIG_CAT_BASES_BPRO cb 
			 where de.suc_idsucursal = cb.suc_idsucursal 
			 and de.Usuario_Autoriza2 = cu.usu_idusuario 
			 and de.suc_idsucursal = dpt.suc_idsucursal
			 and de.dep_iddepartaamento = dpt.dep_iddepartamento 
			 and cb.nombre_base = @sBase
			 UNION ALL
			 select de.escalamientoId, usu_idusuario, usu_nombreusu, ' ', ' ',  usu_paterno + ' ' + usu_materno + ' ' + usu_nombre, dpt.dep_nombre 
			 from Centralizacionv2..DIG_ESCALAMIENTO de, ControlAplicaciones..cat_usuarios cu, ControlAplicaciones..cat_departamentos dpt , Centralizacionv2..DIG_CAT_BASES_BPRO cb 
			 where de.suc_idsucursal = cb.suc_idsucursal 
			 and de.Usuario_Autoriza3 = cu.usu_idusuario 
			 and de.suc_idsucursal = dpt.suc_idsucursal
			 and de.dep_iddepartaamento = dpt.dep_iddepartamento 
			 and cb.nombre_base = @sBase



*/

CREATE PROCEDURE [dbo].[UP_DIG_SUSTITUYEPERMISOS_SP]  --with recompile
@usuarioquita int,
@usuariopon int,
@sPonComoSegundo varchar(2) --para pasar como segundo autorizador al que se le van a quitar los permisos
AS
begin 
set nocount on

--Declare @usuarioquita int = 72;
--Declare @usuariopon int = 765;
--Declare @sPonComoSegundo varchar(2) = 'SI'; --para pasar como segundo autorizador al que se le van a quitar los permisos

BEGIN TRANSACTION T1

				--SE ACTUALIZA EN EL ESCALAMIENTO
				if Exists (select 1 from Centralizacionv2..DIG_ESCALAMIENTO where Usuario_Autoriza1=@usuarioquita)
				begin 
						print 'Actualizando DIG_ESCALAMIENTO'
						--Se pasa como segundo autorizador al usuario que se le quitan los permisos.
						if (@sPonComoSegundo = 'SI')
						begin
							Declare @usuario_segundo_actual int;
							select @usuario_segundo_actual = Usuario_Autoriza2 from Centralizacionv2..DIG_ESCALAMIENTO where Usuario_Autoriza1=@usuarioquita
							update Centralizacionv2..DIG_ESCALAMIENTO set Usuario_Autoriza2=@usuarioquita, Usuario_Autoriza1 = @usuariopon where Usuario_Autoriza1=@usuarioquita  
							print 'Se sustituyó al primer autorizador: ' +  ltrim(rtrim(Convert(char(5),@usuarioquita))) + ' con el usuario: ' + ltrim(rtrim(Convert(char(5),@usuariopon)))						
							print 'Se sustituyó al segundo autorizador: ' +  ltrim(rtrim(Convert(char(5),@usuario_segundo_actual))) + ' con el usuario: ' + ltrim(rtrim(Convert(char(5),@usuarioquita)))
						end
					else
						begin 
							update Centralizacionv2..DIG_ESCALAMIENTO set Usuario_Autoriza1 = @usuariopon where Usuario_Autoriza1=@usuarioquita  
							print 'Se sustituyó al primer autorizador: ' +  ltrim(rtrim(Convert(char(5),@usuarioquita))) + ' con el usuario: ' + ltrim(rtrim(Convert(char(5),@usuariopon)))
						end
				end
				--sustituyendo en el segundo autorizador
				if Exists (select 1 from Centralizacionv2..DIG_ESCALAMIENTO where Usuario_Autoriza2=@usuarioquita and @sPonComoSegundo <> 'SI')
				begin 
						print 'Actualizando DIG_ESCALAMIENTO en segundo autorizador'				
						update Centralizacionv2..DIG_ESCALAMIENTO set Usuario_Autoriza2 = @usuariopon where Usuario_Autoriza2=@usuarioquita  
						print 'Se sustituyó al segundo autorizador: ' +  ltrim(rtrim(Convert(char(5),@usuarioquita))) + ' con el usuario: ' + ltrim(rtrim(Convert(char(5),@usuariopon)))						
				end

				--sustituyendo en el tercer autorizador
				if Exists (select 1 from Centralizacionv2..DIG_ESCALAMIENTO where Usuario_Autoriza3=@usuarioquita)
				begin 
						print 'Actualizando DIG_ESCALAMIENTO en tercer autorizador'				
						update Centralizacionv2..DIG_ESCALAMIENTO set Usuario_Autoriza3 = @usuariopon where Usuario_Autoriza3=@usuarioquita  
						print 'Se sustituyó al tercer autorizador: ' +  ltrim(rtrim(Convert(char(5),@usuarioquita))) + ' con el usuario: ' + ltrim(rtrim(Convert(char(5),@usuariopon)))						
				end

				if Exists (SELECT 1 FROM Centralizacionv2..DIG_ESCALAMIENTO_AREA_AFECT  WHERE usuario_autoriza1=@usuarioquita)
				begin
					update Centralizacionv2..DIG_ESCALAMIENTO_AREA_AFECT set usuario_autoriza1=@usuariopon WHERE usuario_autoriza1=@usuarioquita 
					print 'Se sustituyo en DIG_ESCALAMIENTO_AREA_AFECT'

				end 

				-- select * from DIG_ESCALAMIENTO_AREA_PRESUP where usuario_autoriza2 = 72 
				if Exists (select 1 from Centralizacionv2..DIG_CATALOGOS where cat_valor = ltrim(rtrim(Convert(char(5),@usuarioquita))) and cat_estatus = 1 )
				Begin
					update Centralizacionv2..DIG_CATALOGOS set cat_valor =  ltrim(rtrim(Convert(char(5),@usuariopon))) where cat_valor = ltrim(rtrim(Convert(char(5),@usuarioquita))) and cat_estatus = 1
					print 'Se sustituyo en DIG_CATALOGOS'
				end

COMMIT TRANSACTION T1

set nocount off
end
go

