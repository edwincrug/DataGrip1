CREATE PROCEDURE [dbo].[INS_ESCALAMIENTO_SP]
	 @proc_Id	int
	,@nodo_Id	INT
	,@emp_idempresa INT
	,@suc_idsucursal INT
	,@dep_iddepartaamento INT
	,@tipo_idtipoorden INT
	,@Nivel_Escalamiento INT
	,@Usuario_Autoriza1 INT
	,@Usuario_Autoriza2 INT
	,@Usuario_Autoriza3 INT
	,@Minutos_Escalar INT
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY


	   IF EXISTS  (SELECT 1 FROM DIG_ESCALAMIENTO WHERE emp_idempresa=@emp_idempresa 
		and suc_idsucursal=@suc_idsucursal and dep_iddepartaamento=@dep_iddepartaamento AND tipo_idtipoorden=@tipo_idtipoorden)
		BEGIN
			SELECT '2'AS Result
	    END
		ELSE
		BEGIN
		     IF (@Usuario_Autoriza1 <>@Usuario_Autoriza2) and (@Usuario_Autoriza2 <> @Usuario_Autoriza3) and (@Usuario_Autoriza1 <> @Usuario_Autoriza3)
			BEGIN
			INSERT INTO [dbo].[DIG_ESCALAMIENTO]
					   ([Proc_Id]
					   ,[Nodo_Id]
					   ,[emp_idempresa]
					   ,[suc_idsucursal]
					   ,[dep_iddepartaamento]
					   ,[tipo_idtipoorden]
					   ,[Nivel_Escalamiento]
					   ,[Usuario_Autoriza1]
					   ,[Usuario_Autoriza2]
					   ,[Usuario_Autoriza3]
					   ,[Minutos_Escalar])
				 VALUES
					   ( @proc_Id	
						,@nodo_Id	
						,@emp_idempresa 
						,@suc_idsucursal 
						,@dep_iddepartaamento 
						,@tipo_idtipoorden 
						,@Nivel_Escalamiento 
						,@Usuario_Autoriza1 
						,@Usuario_Autoriza2 
						,@Usuario_Autoriza3 
						,@Minutos_Escalar )	
						
			SELECT '1' AS Result
			END		
			ELSE
			BEGIN
			SELECT '0' AS Result
			END 
		END

	  
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[INS_ESCALAMIENTO_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END


go

