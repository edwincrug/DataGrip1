CREATE PROCEDURE [dbo].[PROV_DEL_BANCO_PROSPECTO_SP] 
@idCuentaBancaria INT
           

AS
BEGIN
BEGIN TRY
		


				
		IF  EXISTS(SELECT PT.petr_estatus from Tramites.dbo.personaTramite PT 
		INNER JOIN Tramites.dbo.personas P ON PT.id_persona = p.id_persona 
		INNER JOIN (SELECT PP.PER_RFC, CB.* FROM PROV_PROSPECTO  PP 
					INNER JOIN [dbo].[PROV_CUENTA_BANCARIA]  CB ON cb.idProspecto = PP.PER_IDPERSONA OR CB.rfcProspecto = PP.PER_RFC
					WHERE  idCuentaBancaria = @idCuentaBancaria) A ON P.per_rfc = A.PER_RFC
		LEFT JOIN  Tramites.dbo.detallePersonaCuenta DC on dc.id_perTra = pt.id_perTra AND A.noCuenta = DC.noCuenta AND A.cveBanxico = DC.idBanxico
		where pt.petr_estatus IN (3,4) AND  PT.id_tramite in (1,2,5))
		BEGIN
				DELETE FROM [dbo].[PROV_CUENTA_BANCARIA]
				WHERE idCuentaBancaria = @idCuentaBancaria

				SELECT 1 result
		END
		ELSE
		BEGIN
				SELECT 0 result
		END



           
	

END TRY
BEGIN CATCH

		SELECT -1 result

END CATCH 
	

END
go

