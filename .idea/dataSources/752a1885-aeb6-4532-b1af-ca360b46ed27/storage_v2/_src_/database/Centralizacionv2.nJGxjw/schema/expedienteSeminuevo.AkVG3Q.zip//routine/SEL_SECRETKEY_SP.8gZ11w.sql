-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_SECRETKEY_SP]

AS
BEGIN

	SET NOCOUNT ON;

	SELECT 
		par_valor AS APIKEY
	FROM [expedienteSeminuevo].[parametros] 
	WHERE par_nombre = 'SECRET_KEY';

END

go

