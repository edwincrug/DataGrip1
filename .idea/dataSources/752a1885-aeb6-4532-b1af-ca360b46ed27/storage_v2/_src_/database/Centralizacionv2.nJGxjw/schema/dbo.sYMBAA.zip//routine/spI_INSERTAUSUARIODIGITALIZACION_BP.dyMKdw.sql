CREATE PROCEDURE [dbo].[spI_INSERTAUSUARIODIGITALIZACION_BP](@iID_BP int,@sUsr3letras varchar(10),@sNomBase nvarchar(21), @sOPCION varchar(50),@sCSVDeptos varchar(200),@sPerfilDigitalizacion varchar(50), @iResultado int OUTPUT) --with recompile
 AS
declare
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500),
@iIdUsr int,
@sIp nvarchar(20),
@sNomBaseConcentra nvarchar(21),
@iIdEmpresa int,
@iIdSucursal int,
@ipLocal VARCHAR(50),
@sAuxIP varchar(50)
begin 

set nocount on


Declare @iUsu_idusuario int;
select @iUsu_idusuario = 0;
Declare @sUsr3letrasAux varchar(7);
select @sUsr3letrasAux  = ''; 

Select @sIP = ip_servidor,@iIdEmpresa = emp_idempresa, @iIdSucursal = suc_idsucursal from Centralizacionv2..DIG_CAT_BASES_BPRO where nombre_base = @sNomBase and tipo=1
--validar si se corre en el servidor local
SELECT TOP 1 @ipLocal=local_net_address --,local_tcp_port, net_transport
  FROM sys.dm_exec_connections c
 ORDER BY local_net_address DESC

if (@ipLocal = @sIP)
begin   
	   select @sAuxIP = ''
end
else
begin	   
	   select @sAuxIP = '[' + @sIP + '].'
end

set @sQ = N'select @iIdUsrOUT = usu_idusuario from ControlAplicaciones..cat_usuarios where usu_nombreusu = ' + char(39) + @sUsr3letras + char(39) 
SET @sParmDefinition = N'@iIdUsrOUT int OUTPUT';
print @sQ;

select @iIdUsr = -1;
EXECUTE sp_executesql @sQ, @sParmDefinition, @iIdUsrOUT=@iIdUsr OUTPUT;  
Select 'Usuario Id ' + Convert(char(5),@iIdUsr)

--select @iIdUsr = 71;

--nos quedamos solo con el usuario de Bpro es decir solo las 3 letras de BPRO, puede o no venir con los dígitos de la sucursal o con el 0 final
SELECT @sUsr3letrasAux = substring(@sUsr3letras,PATINDEX('%[^0-9]%',@sUsr3letras),len(@sUsr3letras)) --as usuario3Letras

if (@iIdUsr=-1)
	begin  --No encontró el usario hay que darlo de alta.
			print 'No se encontró al asuario en: ' + @sQ;
			print 'se dará de alta'
		
				Declare @sAux varchar(7);
				
				select @sAux = ltrim(rtrim(Convert(char(3),@iIdSucursal))) + @sUsr3letrasAux  
				--consultamos el nombre desde la base de BPRo.
				Declare @sUSU_APUSUARI varchar(50) = '';
				Declare @sUSU_AMUSUARI varchar(50) = '';
				Declare @sUSU_NOUSUARI varchar(50) = '';
				Declare @sUSU_CVEACCES varchar(20) = '04060B0203';
				

				--set @sQ = N'select @sUSU_APUSUARIOUT = USU_APUSUARI,@sUSU_AMUSUARIOUT = USU_AMUSUARI,@sUSU_NOUSUARIOUT = USU_NOUSUARI,@sUSU_CVEACCESOUT = USU_CVEACCES from ' + @sAuxIP + '[' + @sNomBase + '].[dbo].[PNC_USUARIOS] where usu_idusuari = ' + char(39) + @sUsr3letrasAux + char(39) 
				--SET @sParmDefinition = N'@sUSU_APUSUARIOUT varchar(50) OUTPUT, @sUSU_AMUSUARIOUT varchar(50) OUTPUT, @sUSU_NOUSUARIOUT varchar(50) OUTPUT, @sUSU_CVEACCESOUT varchar(20) OUTPUT';
				--print @sQ
				--EXECUTE sp_executesql @sQ, @sParmDefinition, @sUSU_APUSUARIOUT=@sUSU_APUSUARI OUTPUT,@sUSU_AMUSUARIOUT = @sUSU_AMUSUARI OUTPUT,@sUSU_NOUSUARIOUT = @sUSU_NOUSUARI OUTPUT, @sUSU_CVEACCESOUT = @sUSU_CVEACCES OUTPUT; 

				select @sUSU_APUSUARI=PER_PATERNO,@sUSU_AMUSUARI=PER_MATERNO,@sUSU_NOUSUARI = PER_NOMRAZON  from GA_Corporativa..PER_PERSONAS where PER_IDPERSONA = @iID_BP


			if (@sUSU_APUSUARI<>'' and @sUSU_NOUSUARI<>'')	
			begin

			INSERT INTO [ControlAplicaciones].[dbo].[cat_usuarios]
					   ([gpo_idgrupo]
					   ,[div_iddivision]
					   ,[emp_idempresa]
					   ,[suc_idsucursal]
					   ,[dep_iddepartamento]
					   ,[usu_nombreusu]
					   ,[usu_paterno]
					   ,[usu_materno]
					   ,[usu_nombre]
					   ,[usu_correo]
					   ,[usu_contrasenia]
					   ,[pto_idpuesto]
					   ,[usu_fechaalta]
					   ,[usu_usualta]
					   ,[usu_fechamodifica]
					   ,[usu_usumodifica]
					   ,[usu_estatus]
					   ,[usu_passbpro])
				 VALUES
					   (1,1,
					   @iIdEmpresa, 
					   @iIdSucursal, 
					   0,
					   ltrim(rtrim(@sAux)),
					   ltrim(rtrim(@sUSU_APUSUARI)), --,<usu_paterno, varchar(50),>
					   ltrim(rtrim(@sUSU_AMUSUARI)), --,<usu_materno, varchar(50),>
					   ltrim(rtrim(@sUSU_NOUSUARI)), --,<usu_nombre, varchar(70),>
					   'porconfirmar-sp@hotmail.com',
					   '8cb2237d0679ca88db6464eac60da96345513964', --12345
						0,
						getdate(),--,<usu_fechaalta, datetime,>
						0,		  --,<usu_usualta, int,>
						getdate(),--,<usu_fechamodifica, datetime,>
						0,		  --,<usu_usumodifica, int,>
						1,        --,<usu_estatus, int,>
						@sUSU_CVEACCES)     --,<usu_passbpro, varchar(20),>)
						select @iIdUsr = @@IDENTITY 
						print 'se creo el usuario en  ControlAplicaciones..cat_usuarios ' + ltrim(rtrim(@sAux)) + ' id:' + ltrim(rtrim(Convert(char(5),@iIdUsr)))
			   end --del insert
end --del @iIdUsr=-1

-- conociendo el usuarioId y el usuario BPro buscamos si tiene la equivalencia en esta base.
--select * from ControlAplicaciones..eqv_organigrama where usu_usuario = 1591 and eqv_nombrebd='GAAA_PERISUR'
if (@iIdUsr<>-1)
begin
	if Not Exists(Select 1 from  [ControlAplicaciones].[dbo].[eqv_organigrama] where usu_usuario = @iIdUsr and emp_idempresa = @iIdEmpresa and suc_idsucursal = @iIdSucursal)
	begin
	  -- se inserta la equivalencia para este usuario 
		 Declare @iErrorLocal int = 0;
		 execute spI_INSERTAEQUIVALENCIAxBASE_Correcto @sNomBase, @sUsr3letras, @iErrorLocal OUTPUT
		 print 'Resultado de meter la equivalencia: ' + Convert(char(5),@iErrorLocal)
	end 
end

			-- DadoDeAlta el usuario lo agregamos a Digitalizacion, menus etc.
			--select * from ControlAplicaciones..ope_organigrama where usu_idusuario=617 order by org_idorganigrama
			Declare @isis_idsistema int;
			if (@sOPCION='CXP')
			   begin 
			      select @isis_idsistema = 3;
			   end
			if (@sOPCION = 'CXC')
			   begin
			      select @isis_idsistema = 4
			   end
			if (@sOPCION = 'AMBOS')
			   begin 
			      select @isis_idsistema = 3;
			   end

if (@iIdUsr>-1)
begin
		 if Not Exists(Select 1 from  [ControlAplicaciones].[dbo].[ope_organigrama] where usu_idusuario = @iIdUsr and emp_idempresa = @iIdEmpresa and suc_idsucursal = @iIdSucursal) 
		 begin
		  set @sQ = N'	INSERT INTO [ControlAplicaciones].[dbo].[ope_organigrama]'
	      set @sQ = @sQ + N'([sis_idsistema]'
		  set @sQ = @sQ + N',[gpo_idgrupo]'
		  set @sQ = @sQ + N',[div_iddivision]'
					   set @sQ = @sQ + N',[emp_idempresa]'
					   set @sQ = @sQ + N',[suc_idsucursal]'
					   set @sQ = @sQ + N',[dep_iddepartamento]'
					   set @sQ = @sQ + N',[usu_idusuario]'
					   set @sQ = @sQ + N',[org_fechaalta]'
					   set @sQ = @sQ + N',[org_usualta]'
					   set @sQ = @sQ + N',[org_fechamodifica]'
					   set @sQ = @sQ + N',[org_usumodifica]'
					   set @sQ = @sQ + N',[org_estatus])'
		set @sQ = @sQ + N'select '
		set @sQ = @sQ + N' ' + ltrim(rtrim(convert(char(5),@isis_idsistema))) + ',' --<sis_idsistema, int,>
		set @sQ = @sQ + N' 1,' --<gpo_idgrupo, int,>
		set @sQ = @sQ + N' 1,' --<div_iddivision, int,>
		set @sQ = @sQ + N' ' + ltrim(rtrim(convert(char(5),@iIdEmpresa))) +  ','  --<emp_idempresa, int,>
		set @sQ = @sQ + N' ' + ltrim(rtrim(convert(char(5),@iIdSucursal))) + ',' --<suc_idsucursal, int,>
		set @sQ = @sQ + N' dep_iddepartamento,' --,<dep_iddepartamento, int,>
		set @sQ = @sQ + N' ' + ltrim(rtrim(convert(char(5),@iIdUsr))) + ',' --<usu_idusuario, int,>
		set @sQ = @sQ + N' getdate(),' --<org_fechaalta, datetime,>
		set @sQ = @sQ + N' 1,' --<org_usualta, int,>
		set @sQ = @sQ + N' getdate(),' --<org_fechamodifica, datetime,>
		set @sQ = @sQ + N' 1,' --<org_usumodifica, int,>
		set @sQ = @sQ + N' 1 ' --<org_estatus, int,>)
		set @sQ = @sQ + N' from ControlAplicaciones..cat_departamentos where emp_idempresa = ' + ltrim(rtrim(convert(char(5),@iIdEmpresa))) + ' and suc_idsucursal=' + ltrim(rtrim(convert(char(5),@iIdSucursal))) + ' and dep_nombrecto in (' + @sCSVDeptos + ')'
		print @sQ
		EXECUTE sp_executesql @sQ

					   print 'Se insertó el organigrama [ControlAplicaciones].[dbo].[ope_organigrama]'
				end --De que no existe el organigrama

				if Not Exists(select 1 from ControlAplicaciones..rel_usuarioperfil where usu_idusuario=@iIdUsr)
				begin  --Los menús de CXP , CXC y el de Control de Aplicaciones
					   --SELECT * FROM ControlAplicaciones..rel_usuarioperfil where usu_idusuario=617
					   if (@sOpcion='CXC')
					   begin
						insert into ControlAplicaciones..rel_usuarioperfil (per_idperfil,usu_idusuario,sis_idsistema )
						values (5,@iIdUsr,4)
					   end

					   if (@sOpcion='CXP')
					   begin
						insert into ControlAplicaciones..rel_usuarioperfil (per_idperfil,usu_idusuario,sis_idsistema )
						values (4,@iIdUsr,3)
					   end

					   if  (@sOpcion='AMBOS')
					   begin
					       if (@isis_idsistema=3)
						     begin
							   select @isis_idsistema = 4
							 end
							else
							 begin
						   		if (@isis_idsistema=4)
								begin
									select @isis_idsistema = 3
								end
							 end

						   insert into ControlAplicaciones..rel_usuarioperfil (per_idperfil,usu_idusuario,sis_idsistema )
						   values (5,@iIdUsr,@isis_idsistema)
					   end

					   --este es el que le da acceso a Digitalizacion
					   insert into ControlAplicaciones..rel_usuarioperfil (per_idperfil,usu_idusuario,sis_idsistema )
					   values (6,@iIdUsr,5)
					   print 'Se creo el perfil: ControlAplicaciones..rel_usuarioperfil'
				end

				if Not Exists(select 1 from Seguridad..SEG_USUARIO_PERFIL where sup_idUsuario = @iIdUsr)
				begin
					   --le ponemos el menu más basico de Digitalización
					   Declare @iSiguiente int = 0;
					   Declare @iPerfil int  = 1;  --el perfil 1 es el más básico 

					   if (@sPerfilDigitalizacion='CORPORATIVO')
					      begin
						     select @iPerfil = 8;
						  end

					   select @iSiguiente = Max(sup_idUsuarioPerfil)+1 from Seguridad..SEG_USUARIO_PERFIL
					   insert into Seguridad..SEG_USUARIO_PERFIL (sup_idUsuarioPerfil,sup_idUsuario,sup_idPerfil)
					   values (@iSiguiente,@iIdUsr,@iPerfil)					   
				end
		select @iResultado = @iIdUsr; 
	end

set nocount off
end
/*
--SI EL USUARIO YA EXISTE en cat_usuarios  REVISA SI LE FALTA ALGO Y SE LO AGREGA--
--SI EL USUAIRO NO EXISTE 
Declare @iID_BP int = 111035;
Declare @sUsr3letras varchar(10) = '6BAL';   --EL USUARIO CON SU IDSUCURSAL [TAL Y COMO DEBE QUEDAR o ESTA EN CAT_USUARIOS] despues del idsucursal esta el usaurio BPRo con todo y el número final si es que lo tiene.
Declare @sNomBase nvarchar(20) = 'GAZM_Zaragoza';
Declare  @sOPCION varchar(50) = 'AMBOS'; --'CXP'| 'CXC'
--Declare @sCSVDeptos varchar(200) = char(39) + 'UN' + char(39) + ',' + char(39) + 'US' + char(39) + ',' + char(39) + 'RE' + char(39) + ',' + char(39) + 'SE' + char(39) + ',' + char(39) + 'OT' + char(39)
--Declare @sCSVDeptos varchar(200) = char(39) + 'UN' + char(39) + ',' + char(39) + 'OT' + char(39)
Declare @sCSVDeptos varchar(200) = char(39) + 'UN' + char(39) + ',' + char(39) + 'US' + char(39) + ',' + char(39) + 'RE' + char(39) + ',' + char(39) + 'SE' + char(39) + ',' + char(39) + 'OT' + char(39) + ',' + char(39) + 'ACS' + char(39) + ',' + char(39) + 'ACN' + char(39)
DECLARE @sPerfilDigitalizacion varchar(50) = 'BASICO'; --    'DIGITALIZACION|NOTIFICACIONES|PORTALPROVEEDORES|REFERENCIAS'; 
--DECLARE @sPerfilDigitalizacion varchar(50) = 'CORPORATIVO';  --TIENE ACCESO A TODOS LOS MENUS EN DIGITALIZACION
DECLARE @iResultado int = -1;


Execute Centralizacionv2..spI_INSERTAUSUARIODIGITALIZACION_BP @iID_BP,@sUsr3letras,@sNomBase, @sOPCION,@sCSVDeptos, @sPerfilDigitalizacion,@iResultado OUTPUT
print 'Usuario dado de alta con el id: ' + ltrim(rtrim(Convert(char(5),@iResultado)))




select * from ControlAplicaciones..cat_usuarios where  usu_nombreusu like '%BFA%'
select * from ControlAplicaciones..cat_sucursales

Select * from  [ControlAplicaciones].[dbo].[ope_organigrama] where usu_idusuario = 1679
Select * from  [ControlAplicaciones].[dbo].[eqv_organigrama] where usu_usuario = 1679

Select * from ControlAplicaciones..cat_usuarios where usu_nombreusu like '%24PML%' --RVV
Select * from ControlAplicaciones..rel_usuarioperfil  where usu_idusuario = 2478
Select * from ControlAplicaciones..ope_organigrama where usu_idusuario=301
Select * from ControlAplicaciones..ope_perfil where 

-- delete ControlAplicaciones..cat_usuarios where usu_idusuario = 1686
-- delete ControlAplicaciones..rel_usuarioperfil  where usu_idusuario = 1692
-- delete  ControlAplicaciones..ope_organigrama where usu_idusuario=301 and suc_idsucursal = 3

insert into ControlAplicaciones..rel_usuarioperfil (per_idperfil,usu_idusuario,sis_idsistema)
values (4,2588,3) --CXP

--delete ControlAplicaciones..rel_usuarioperfil where per_idperfil=7 and usu_idusuario=2478


*/
go

