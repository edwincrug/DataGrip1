-- ================================================
-- Create date: 29/08/2017
-- Description:	Registra la accion en la bitacora 
-- =============================================
CREATE PROCEDURE [dbo].[INS_BITACORA_ACCION_SP]
	@idFolio NVARCHAR(50)
	,@idNodo INT
	,@idUsuario INT
AS
BEGIN
	INSERT INTO [Centralizacionv2].[dbo].[DIG_BITACORA_ACCION]([folio]
															  ,[idNodo]
															  ,[idUsuario]
															  ,[fecha])
	SELECT  @idFolio, @idNodo, @idUsuario, GETDATE()
	SELECT 1 AS respuesta, 'Se inserto correctamente' As mensaje
END
go

