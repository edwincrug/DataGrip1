-- =============================================
-- Author:		<Luis Garcia>
-- Create date: <15/06/2020>
-- Description:	<TRae todos los documentos de un que pueda tener varios>
-- TEST [expedienteSeminuevo].[SEL_DOCUMENTOS_VARIOS_BY_IDS] 5, 4, 1
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_DOCUMENTOS_VARIOS_BY_IDS]
	@idDocumento INT,
	@idExpediente INT,
	@idProceso INT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @rutaGet VARCHAR(500);
	SELECT @rutaGet = par_valor FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'GET_IMG'

	SELECT 
		id_documentoGuardado,
		id_expediente,
		DE.id_documento, 
		id_proceso,
		DE.id_estatus,
		ED.est_descripcion,
		observacionesDocumento,
		nombreDocumento,
		doc_nombreCorto,
		CASE WHEN @idProceso = 1 THEN 'CXP' ELSE 'CXC' END AS proceso,
		CASE
			WHEN @idProceso  = 1
			THEN @rutaGet + cast(@idExpediente as varchar) +'/' + 'CXP' + '/' + DV.var_carpetaSave + '/'+ nombreDocumento
			WHEN @idProceso  = 2
			THEN 
			@rutaGet + cast(@idExpediente as varchar) +'/' + 'CXC' + '/' + DV.var_carpetaSave + '/' + nombreDocumento
		END AS ruta
	FROM [expedienteSeminuevo].[documentosExpediente] DE
	INNER JOIN [expedienteSeminuevo].[cat_documentos] D ON D.id_documento = DE.id_documento
	INNER JOIN [expedienteSeminuevo].[documentosVarios] DV ON DV.doc_idDocumento= DE.id_documento
	INNER JOIN [expedienteSeminuevo].[estatusDocumentos] ED ON ED.id_estatus = DE.id_estatus
	WHERE DE.id_documento = @idDocumento AND DE.id_expediente = @idExpediente AND DE.id_proceso = @idProceso AND D.doc_varios = 1
	ORDER BY 1 ASC
END

go

