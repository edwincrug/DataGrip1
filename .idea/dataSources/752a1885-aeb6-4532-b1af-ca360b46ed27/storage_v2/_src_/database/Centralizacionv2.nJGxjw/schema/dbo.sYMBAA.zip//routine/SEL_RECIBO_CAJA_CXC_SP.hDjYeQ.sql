-- ==========================================================================================
-- Author:		LQMA
-- Create date: 31/03/2017
-- Description: 
--              
-- ==========================================================================================
-- EXECUTE [SEL_RECIBO_CAJA_CXC_SP] @folio = 'AU-ZM-ZAR-UN-22'
CREATE PROCEDURE [dbo].[SEL_RECIBO_CAJA_CXC_SP] 
	@folio    NVARCHAR(50) = ''
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY

	DECLARE @idCotizacion   INT = 0;
	DECLARE @idEmpresa      INT = 0;
	DECLARE @idSucursal     INT = 0;
	DECLARE @rfc            VARCHAR(30) = 0;
	DECLARE @nomBaseMatriz  VARCHAR(30) = 0;
	DECLARE @query          NVARCHAR(MAX) = null

	DECLARE @ipServidor        NVARCHAR(100);
	DECLARE @cadIpServidor     NVARCHAR(200);

	---------------------------------------------------------------
	--  Obtenemos la consulta dinamicamente                      --
	---------------------------------------------------------------
	DECLARE @VariableTabla TABLE (PAM_IDDOCTO	nvarchar(30)
									,serie	        nvarchar(10)
									,folio	        nvarchar(20)
									,rfcEmisor	    nvarchar(30)
								  )

		
		SELECT @idCotizacion  = ucu_idcotizacion 
		       ,@idEmpresa    = ucu_idempresa
			   ,@idSucursal   = ucu_idsucursal
		  FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
		 WHERE ucu_foliocotizacion = @folio

		 --SELECT @rfc = rfc
		 --       ,@nomBaseMatriz = nombre_base_matriz
			--	,@ipServidor = ip_servidor
		 --  FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
		 -- WHERE catsuc_nombrecto = 'CONCENTRA'
   --         AND emp_idempresa    = @idEmpresa
		 SELECT @rfc = rfc
		   FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
		  WHERE catsuc_nombrecto = 'CONCENTRA'
            AND emp_idempresa    = @idEmpresa

        SET @cadIpServidor = [dbo].[base_Concentradora](@idEmpresa)
		
        --SELECT  @cadIpServidor, @nombreBase
		--SELECT @rfc,@nomBaseMatriz 

		/*
		SET @query = ' SELECT D.CCP_IDDOCTO         AS idNotaCredito '+
							  ',(SELECT dbo.[fn_BuscaLetras](D.CCP_IDDOCTO ))  AS serie '+
							  ',(SELECT dbo.[fn_BuscaNumeros](D.CCP_IDDOCTO )) AS folio '+
							  ','+''''+ @rfc+''''+' AS rfcEmisor '+
						'FROM [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSAL] AS A '+ 
							   'INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] B ON A.ucu_idcotizacion=B.ucu_idcotizacion '+
							   'INNER JOIN '+ @cadIpServidor + @nomBaseMatriz +'.dbo.ADE_VTAFI C   ON C.VTE_TIPODOCTO= '+''''+'A'+''''+' AND C.VTE_STATUS= '+''''+'I'+''''+' AND B.ucn_noserie=C.VTE_SERIE '+
							   'LEFT JOIN '+ @cadIpServidor + @nomBaseMatriz +'.dbo.VIS_CONCAR01 D ON CCP_TIPODOCTO= '+''''+'NCRBON'+''''+' AND CCP_REFERNCRBONI = C.VTE_DOCTO   '+
					   'WHERE A.ucu_foliocotizacion ='+''''+ @folio +''''+' AND D.CCP_IDDOCTO IS NOT NULL AND D.CCP_IDDOCTO <> '+''''+''''
        */
		
		SET @query =  'SELECT PAM_IDDOCTO ' + 
	                  ',(SELECT dbo.[fn_BuscaLetras](PAM_IDDOCTO))  AS serie ' +
					  ',(SELECT dbo.[fn_BuscaNumeros](PAM_IDDOCTO)) AS folio ' +
					  ','+''''+ @rfc+''''+' AS rfcEmisor ' +	
		              'FROM '+ @cadIpServidor + 'CXC_PAGANT P ' +
					  'INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversalunidades U ON P.PAM_DOCAFECTADO = U.ucn_idFactura ' +
					  'INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal UE ON U.ucu_idcotizacion = UE.ucu_idcotizacion ' +
					  'WHERE UE.ucu_foliocotizacion = ''' + @folio + ''''	

		/*
		SELECT PAM_IDDOCTO FROM [192.168.20.31].GAAU_Universidad_P.dbo.CXC_PAGANT P 
				INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversalunidades U ON P.PAM_DOCAFECTADO = U.ucn_idFactura 
				INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal UE ON U.ucu_idcotizacion = UE.ucu_idcotizacion
		WHERE UE.ucu_foliocotizacion = 'AU-AU-UNI-UN-89'		
		*/
				
		print @query

		INSERT INTO  @VariableTabla
		SELECT 'MK000007405','MK','000007405','ZMO841221BJ4'
		UNION
		SELECT 'MK000007408',	'MK',	'000007408',	'ZMO841221BJ4'
		UNION
		SELECT 'MK000007409',	'MK',	'000007409',	'ZMO841221BJ4'
		UNION
		SELECT 'MK000007410',	'MK',	'000007410',	'ZMO841221BJ4'
		UNION
		SELECT 'MK000007411',	'MK',	'000007411',	'ZMO841221BJ4'    
			
			--EXECUTE (@query);

        SELECT * FROM @VariableTabla

	END TRY

	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_RECIBO_CAJA_CXC_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END
go

