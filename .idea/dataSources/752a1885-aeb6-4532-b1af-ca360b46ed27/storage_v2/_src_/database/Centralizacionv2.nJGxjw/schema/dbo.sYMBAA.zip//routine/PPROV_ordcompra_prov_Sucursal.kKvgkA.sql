CREATE PROCEDURE [dbo].[PPROV_ordcompra_prov_Sucursal]   -- [dbo].[PPROV_ordcompra_prov_Sucursal]  75,null,null,6
@idProveedor INT = 0,
@monto DECIMAL = NULL,
@orden VARCHAR(50) = NULL,
@Sucursal int

AS  
  
SELECT  ROW_NUMBER() OVER(ORDER BY ordComp.oce_folioorden DESC) AS rowID,
		ordComp.oce_folioorden,depto.dep_nombre, suc.suc_nombre,  
		emp.emp_nombre,ordComp.oce_importetotal, emp.emp_nombrecto,  
		ordComp.oce_fechaorden,'1' estatus,per.per_rfc,ordComp.oce_uuid
FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
WHERE ordComp.oce_idproveedor = @idProveedor  
	  AND (@monto IS NULL OR ordComp.oce_importetotal = @monto)
	  AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
	  AND ordComp.oce_folioorden NOT IN (SELECT oce_folioorden FROM dbo.PPRO_ORDENARCHIVOXML)
	  AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
	  AND ordComp.sod_idsituacionorden NOT IN (3,4,12,13)
	  AND ordComp.oce_idsucursal = @Sucursal
	   order by ordComp.oce_fechaorden DESC
go

