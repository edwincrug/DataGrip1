-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SP_A_PRUEBA
	
@iddepartamento int = 0
	,@iddivision int = 0
	,@idempresa int = 0
	,@idproveedor int = 0
	,@folioorden varchar(20) = ''
	,@idusuariosolicitante int = 0
	,@estatusorden int = 0
	,@fechaini datetime = null
	,@fechafin datetime = null
	,@idSucursal int = 0
	,@idTipoOrden int = -1
	,@idProceso   int = 1
	,@factura NVARCHAR(20) = ''
	,@numeroSerie NVARCHAR(20) = ''
	,@ordenServicio NVARCHAR(20) = ''
			,@tipoBusqueda int =0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY   
           
IF(@fechaini = @fechafin)
		BEGIN
		    SET @fechaini = @fechaini +' 00:00:00.000'
			SET @fechafin = @fechafin +' 23:59:59.000'
			--SELECT  @fechaini,@fechafin
		END
		IF(@fechaini IS NULL)
			SET @fechaini = '20000101'
		IF(@fechafin IS NULL)
			SET @fechafin = GETDATE()

IF(@idProceso = 1)
	BEGIN
	    IF(@tipoBusqueda = 1)--igual folioorden
			BEGIN
				PRINT('1.-Comienza Proceso 1 con tipo de busqueda 5');
				SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion 
						, TIPOR.tip_nombre AS tipoorden
						, OC.oce_fechaorden AS oce_fechaorden
						, SITOR.sod_nombresituacion AS situacionOrden
						, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
						, EMP.emp_nombre AS empNombre
						, SUC.suc_nombre AS sucursal
						, DEP.[dep_nombre] AS depto
						, OC.oce_importetotal AS oce_importetotal
						,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
							  ELSE 0 
							  END AS esPlanta
						,(	SELECT	TOP 1 D.Nodo_Id 
							FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
							WHERE	D.Proc_Id = DG.Proc_Id 
									AND D.Folio_Operacion = OC.oce_folioorden 
									AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual     
						,CASE	WHEN R.irr_folioinicial IS NOT NULL THEN	1 
								WHEN RE.irr_folionuevo  IS NOT NULL THEN	2
								WHEN REF.ifr_folionuevo IS NOT NULL THEN	3
								WHEN F.ifs_folionuevo IS NOT NULL THEN 5
								ELSE 1
								END AS tipofolio  
				
				FROM	[BDPersonas].[dbo].[cat_personas] AS PER
						INNER JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
						INNER JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
						INNER JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
						INNER JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
						INNER JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
						LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
						-------------------------------------
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS R ON R.[irr_folioinicial] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS RE ON RE.[irr_folionuevo] =  OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS REF ON REF.[ifr_folionuevo] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser]  AS F ON F.[ifs_folionuevo] = OC.oce_folioorden
						-------------------------------------
						LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] DF ON DF.folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] DAN ON DAN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DASN ON DASN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] DS ON DS.oce_folioorden = OC.oce_folioorden
						INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
				WHERE																					
						OC.oce_iddivision = (CASE WHEN @iddivision = 0 THEN OC.oce_iddivision ELSE @iddivision END) 
						AND OC.oce_idempresa = (CASE WHEN @idempresa = 0 THEN OC.oce_idempresa ELSE @idempresa END)
						AND OC.oce_idsucursal = (CASE WHEN @idSucursal = 0 THEN OC.oce_idsucursal ELSE @idSucursal END)
						AND OC.oce_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN OC.oce_iddepartamento ELSE @iddepartamento END)
						AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
						AND OC.oce_folioorden = @folioorden 
						AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
						AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
			END
		IF(@tipoBusqueda = 2)--igual factura
			BEGIN
				PRINT('1.-Comienza Proceso 1 con tipo de busqueda 6');
				SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion 
						, TIPOR.tip_nombre AS tipoorden
						, OC.oce_fechaorden AS oce_fechaorden
						, SITOR.sod_nombresituacion AS situacionOrden
						, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
						, EMP.emp_nombre AS empNombre
						, SUC.suc_nombre AS sucursal
						, DEP.[dep_nombre] AS depto
						, OC.oce_importetotal AS oce_importetotal
						,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
							  ELSE 0 
							  END AS esPlanta
						,(	SELECT	TOP 1 D.Nodo_Id 
							FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
							WHERE	D.Proc_Id = DG.Proc_Id 
									AND D.Folio_Operacion = OC.oce_folioorden 
									AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual     
						,CASE	WHEN R.irr_folioinicial IS NOT NULL THEN	1 
								WHEN RE.irr_folionuevo  IS NOT NULL THEN	2
								WHEN REF.ifr_folionuevo IS NOT NULL THEN	3
								WHEN F.ifs_folionuevo IS NOT NULL THEN 5
								ELSE 1
								END AS tipofolio  
				FROM	[BDPersonas].[dbo].[cat_personas] AS PER
						LEFT JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
						LEFT JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
						LEFT JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
						LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
						LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] DF ON DF.folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] DAN ON DAN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DASN ON DASN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] DS ON DS.oce_folioorden = OC.oce_folioorden
						-------------------------------------
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS R ON R.[irr_folioinicial] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS RE ON RE.[irr_folionuevo] =  OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS REF ON REF.[ifr_folionuevo] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser]  AS F ON F.[ifs_folionuevo] = OC.oce_folioorden
						-------------------------------------
						INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
				WHERE	(	oce_iddivision = @iddivision OR (@iddivision = 0 AND (	OC.oce_iddivision IN (	SELECT	DISTINCT div_iddivision 
																											FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																											WHERE	usu_idusuario = @idusuariosolicitante 
																													AND div_iddivision = (CASE WHEN @iddivision = 0 THEN  div_iddivision ELSE  @iddivision END)))))
						AND (	OC.oce_idempresa = @idempresa OR (@idempresa=0 AND (	OC.oce_idempresa IN (	SELECT	DISTINCT emp_idempresa 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND emp_idempresa = (CASE WHEN @idempresa = 0 THEN  emp_idempresa ELSE  @idempresa END)))))
						AND (	OC.oce_idsucursal = @idSucursal OR (@idSucursal=0 AND (OC.oce_idsucursal IN(	SELECT	DISTINCT suc_idsucursal 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND suc_idsucursal = (CASE WHEN @idSucursal = 0 THEN  suc_idsucursal ELSE  @idSucursal END)))))
						AND (	OC.oce_iddepartamento = @iddepartamento OR (@iddepartamento=0 AND (OC.oce_iddepartamento IN (	SELECT	DISTINCT dep_iddepartamento 
																																FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																																WHERE	usu_idusuario = @idusuariosolicitante 
																																	AND dep_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN  dep_iddepartamento ELSE  @iddepartamento END)))))		
						AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
						AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
						AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
						AND ((@factura = '') OR (ISNULL(DF.serie,'') + ISNULL(DF.folio,'') = @factura ))
						
			END
		IF(@tipoBusqueda = 3)--igual numeroSerie
			BEGIN
				PRINT('1.-Comienza Proceso 1 con tipo de busqueda 7');
				SELECT  DISTINCT OC.oce_folioorden AS Folio_Operacion 
						, TIPOR.tip_nombre AS tipoorden
						, OC.oce_fechaorden AS oce_fechaorden
						, SITOR.sod_nombresituacion AS situacionOrden
						, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
						, EMP.emp_nombre AS empNombre
						, SUC.suc_nombre AS sucursal
						, DEP.[dep_nombre] AS depto
						, OC.oce_importetotal AS oce_importetotal
						,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
							  ELSE 0 
							  END AS esPlanta
						,(	SELECT	TOP 1 D.Nodo_Id 
							FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
							WHERE	D.Proc_Id = DG.Proc_Id 
									AND D.Folio_Operacion = OC.oce_folioorden 
									AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual     
						,CASE	WHEN R.irr_folioinicial IS NOT NULL THEN	1 
								WHEN RE.irr_folionuevo  IS NOT NULL THEN	2
								WHEN REF.ifr_folionuevo IS NOT NULL THEN	3
								WHEN F.ifs_folionuevo IS NOT NULL THEN 5
								ELSE 1
								END AS tipofolio  
				FROM	[BDPersonas].[dbo].[cat_personas] AS PER
						LEFT JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
						LEFT JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
						LEFT JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
						LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
						LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] DF ON DF.folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] DAN ON DAN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DASN ON DASN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] DS ON DS.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS R ON R.[irr_folioinicial] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS RE ON RE.[irr_folionuevo] =  OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS REF ON REF.[ifr_folionuevo] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser]  AS F ON F.[ifs_folionuevo] = OC.oce_folioorden
					--	INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
				WHERE OC.oce_iddivision = (CASE WHEN @iddivision = 0 THEN OC.oce_iddivision ELSE @iddivision END) 
						AND (	OC.oce_idempresa = @idempresa OR (@idempresa=0 AND (	OC.oce_idempresa IN (	SELECT	DISTINCT emp_idempresa 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND emp_idempresa = (CASE WHEN @idempresa = 0 THEN  emp_idempresa ELSE  @idempresa END)))))
						AND (	OC.oce_idsucursal = @idSucursal OR (@idSucursal=0 AND (OC.oce_idsucursal IN(	SELECT	DISTINCT suc_idsucursal 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND suc_idsucursal = (CASE WHEN @idSucursal = 0 THEN  suc_idsucursal ELSE  @idSucursal END)))))
						AND (	OC.oce_iddepartamento = @iddepartamento OR (@iddepartamento=0 AND (OC.oce_iddepartamento IN (	SELECT	DISTINCT dep_iddepartamento 
																																FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																																WHERE	usu_idusuario = @idusuariosolicitante 
																																	AND dep_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN  dep_iddepartamento ELSE  @iddepartamento END)))))		
						AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
					    AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
						AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
						AND ((@numeroSerie = '') OR (DAN.anu_numeroserie  = @numeroSerie ) OR (DASN.asn_numeroserie =  @numeroSerie ))	
						
			END
		IF(@tipoBusqueda = 4)--igual ordenServicio
			BEGIN
				PRINT('1.-Comienza Proceso 1 con tipo de busqueda 8');
				SELECT  DISTINCT OC.oce_folioorden AS Folio_Operacion 
						, TIPOR.tip_nombre AS tipoorden
						, OC.oce_fechaorden AS oce_fechaorden
						, SITOR.sod_nombresituacion AS situacionOrden
						, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
						, EMP.emp_nombre AS empNombre
						, SUC.suc_nombre AS sucursal
						, DEP.[dep_nombre] AS depto
						, OC.oce_importetotal AS oce_importetotal
						,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
							  ELSE 0 
							  END AS esPlanta
						,(	SELECT	TOP 1 D.Nodo_Id 
							FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
							WHERE	D.Proc_Id = DG.Proc_Id 
									AND D.Folio_Operacion = OC.oce_folioorden 
									AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual     
						,CASE	WHEN R.irr_folioinicial IS NOT NULL THEN	1 
								WHEN RE.irr_folionuevo  IS NOT NULL THEN	2
								WHEN REF.ifr_folionuevo IS NOT NULL THEN	3
								WHEN F.ifs_folionuevo IS NOT NULL THEN 5
								ELSE 1
								END AS tipofolio  
				FROM	[BDPersonas].[dbo].[cat_personas] AS PER
						LEFT JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
						LEFT JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
						LEFT JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
						LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
						LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] DF ON DF.folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] DAN ON DAN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DASN ON DASN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] DS ON DS.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS R ON R.[irr_folioinicial] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS RE ON RE.[irr_folionuevo] =  OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS REF ON REF.[ifr_folionuevo] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser]  AS F ON F.[ifs_folionuevo] = OC.oce_folioorden
						INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
					
				WHERE OC.oce_iddivision = (CASE WHEN @iddivision = 0 THEN OC.oce_iddivision ELSE @iddivision END) 
						AND (	OC.oce_idempresa = @idempresa OR (@idempresa=0 AND (	OC.oce_idempresa IN (	SELECT	DISTINCT emp_idempresa 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND emp_idempresa = (CASE WHEN @idempresa = 0 THEN  emp_idempresa ELSE  @idempresa END)))))
						AND (	OC.oce_idsucursal = @idSucursal OR (@idSucursal=0 AND (OC.oce_idsucursal IN(	SELECT	DISTINCT suc_idsucursal 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND suc_idsucursal = (CASE WHEN @idSucursal = 0 THEN  suc_idsucursal ELSE  @idSucursal END)))))
						AND (	OC.oce_iddepartamento = @iddepartamento OR (@iddepartamento=0 AND (OC.oce_iddepartamento IN (	SELECT	DISTINCT dep_iddepartamento 
																																FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																																WHERE	usu_idusuario = @idusuariosolicitante 
																																	AND dep_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN  dep_iddepartamento ELSE  @iddepartamento END)))))		
						AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
						AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
						AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
						AND ((DS.ser_ordenservicio =  @ordenServicio ))
			END			
		IF(@tipoBusqueda = 5)--like folioorden
			BEGIN
				PRINT('1.-Comienza Proceso 1 con tipo de busqueda 1');
				SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion 
						, TIPOR.tip_nombre AS tipoorden
						, OC.oce_fechaorden AS oce_fechaorden
						, SITOR.sod_nombresituacion AS situacionOrden
						, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
						, EMP.emp_nombre AS empNombre
						, SUC.suc_nombre AS sucursal
						, DEP.[dep_nombre] AS depto
						, OC.oce_importetotal AS oce_importetotal
						,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
							  ELSE 0 
							  END AS esPlanta
						,(	SELECT	TOP 1 D.Nodo_Id 
							FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
							WHERE	D.Proc_Id = DG.Proc_Id 
									AND D.Folio_Operacion = OC.oce_folioorden 
									AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual     
						,CASE	WHEN R.irr_folioinicial IS NOT NULL THEN	1 
								WHEN RE.irr_folionuevo  IS NOT NULL THEN	2
								WHEN REF.ifr_folionuevo IS NOT NULL THEN	3
								WHEN F.ifs_folionuevo IS NOT NULL THEN 5
								ELSE 1
								END AS tipofolio  
				FROM	[BDPersonas].[dbo].[cat_personas] AS PER
						INNER JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
						INNER JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
						INNER JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
						INNER JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
						INNER JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
						LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
						-------------------------------------
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS R ON R.[irr_folioinicial] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS RE ON RE.[irr_folionuevo] =  OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS REF ON REF.[ifr_folionuevo] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser]  AS F ON F.[ifs_folionuevo] = OC.oce_folioorden
						-------------------------------------
						LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] DF ON DF.folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] DAN ON DAN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DASN ON DASN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] DS ON DS.oce_folioorden = OC.oce_folioorden
						INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
				WHERE																					
						OC.oce_iddivision = (CASE WHEN @iddivision = 0 THEN OC.oce_iddivision ELSE @iddivision END) 
						AND OC.oce_idempresa = (CASE WHEN @idempresa = 0 THEN OC.oce_idempresa ELSE @idempresa END)
						AND OC.oce_idsucursal = (CASE WHEN @idSucursal = 0 THEN OC.oce_idsucursal ELSE @idSucursal END)
						AND OC.oce_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN OC.oce_iddepartamento ELSE @iddepartamento END)
						AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
						AND ((@folioorden = '') OR (OC.oce_folioorden LIKE '%' + @folioorden + '%'))
						AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
						AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
						
					
			END
		IF(@tipoBusqueda = 6)--like factura
			BEGIN
				PRINT('1.-Comienza Proceso 1 con tipo de busqueda 2');
			SELECT	DISTINCT OC.oce_folioorden AS Folio_Operacion 
						, TIPOR.tip_nombre AS tipoorden
						, OC.oce_fechaorden AS oce_fechaorden
						, SITOR.sod_nombresituacion AS situacionOrden
						, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
						, EMP.emp_nombre AS empNombre
						, SUC.suc_nombre AS sucursal
						, DEP.[dep_nombre] AS depto
						, OC.oce_importetotal AS oce_importetotal
						,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
							  ELSE 0 
							  END AS esPlanta
						,(	SELECT	TOP 1 D.Nodo_Id 
							FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
							WHERE	D.Proc_Id = DG.Proc_Id 
									AND D.Folio_Operacion = OC.oce_folioorden 
									AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual     
						,CASE	WHEN R.irr_folioinicial IS NOT NULL THEN	1 
								WHEN RE.irr_folionuevo  IS NOT NULL THEN	2
								WHEN REF.ifr_folionuevo IS NOT NULL THEN	3
								WHEN F.ifs_folionuevo IS NOT NULL THEN 5
								ELSE 1
								END AS tipofolio  
				FROM	[BDPersonas].[dbo].[cat_personas] AS PER
						LEFT JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
						LEFT JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
						LEFT JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
						LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
						LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] DF ON DF.folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] DAN ON DAN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DASN ON DASN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] DS ON DS.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS R ON R.[irr_folioinicial] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS RE ON RE.[irr_folionuevo] =  OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS REF ON REF.[ifr_folionuevo] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser]  AS F ON F.[ifs_folionuevo] = OC.oce_folioorden
						--INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
					
				WHERE	(	oce_iddivision = @iddivision OR (@iddivision = 0 AND (	OC.oce_iddivision IN (	SELECT	DISTINCT div_iddivision 
																											FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																											WHERE	usu_idusuario = @idusuariosolicitante 
																													AND div_iddivision = (CASE WHEN @iddivision = 0 THEN  div_iddivision ELSE  @iddivision END)))))
						AND (	OC.oce_idempresa = @idempresa OR (@idempresa=0 AND (	OC.oce_idempresa IN (	SELECT	DISTINCT emp_idempresa 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND emp_idempresa = (CASE WHEN @idempresa = 0 THEN  emp_idempresa ELSE  @idempresa END)))))
						AND OC.oce_idsucursal = (CASE WHEN @idSucursal = 0 THEN OC.oce_idsucursal ELSE @idSucursal END)
						AND OC.oce_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN OC.oce_iddepartamento ELSE @iddepartamento END)
						AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
						AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
						AND ( (ISNULL(DF.serie,'') + ISNULL(DF.folio,'') like '%'+ @factura +'%' ))
						AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)			
			END
		IF(@tipoBusqueda = 7)--like numeroSerie
			BEGIN
				PRINT('1.-Comienza Proceso 1 con tipo de busqueda 3');
				SELECT  DISTINCT OC.oce_folioorden AS Folio_Operacion 
						, TIPOR.tip_nombre AS tipoorden
						, OC.oce_fechaorden AS oce_fechaorden
						, SITOR.sod_nombresituacion AS situacionOrden
						, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
						, EMP.emp_nombre AS empNombre
						, SUC.suc_nombre AS sucursal
						, DEP.[dep_nombre] AS depto
						, OC.oce_importetotal AS oce_importetotal
						,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
							  ELSE 0 
							  END AS esPlanta
						,(	SELECT	TOP 1 D.Nodo_Id 
							FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
							WHERE	D.Proc_Id = DG.Proc_Id 
									AND D.Folio_Operacion = OC.oce_folioorden 
									AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual     
						,CASE	WHEN R.irr_folioinicial IS NOT NULL THEN	1 
								WHEN RE.irr_folionuevo  IS NOT NULL THEN	2
								WHEN REF.ifr_folionuevo IS NOT NULL THEN	3
								WHEN F.ifs_folionuevo IS NOT NULL THEN 5
								ELSE 1
								END AS tipofolio  
				FROM	[BDPersonas].[dbo].[cat_personas] AS PER
						LEFT JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
						LEFT JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
						LEFT JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
						LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
						LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] DF ON DF.folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] DAN ON DAN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DASN ON DASN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] DS ON DS.oce_folioorden = OC.oce_folioorden
						-------------------------------------
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS R ON R.[irr_folioinicial] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS RE ON RE.[irr_folionuevo] =  OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS REF ON REF.[ifr_folionuevo] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser]  AS F ON F.[ifs_folionuevo] = OC.oce_folioorden
						-------------------------------------
						--INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
				WHERE	OC.oce_iddivision = (CASE WHEN @iddivision = 0 THEN OC.oce_iddivision ELSE @iddivision END) 
						AND (	OC.oce_idempresa = @idempresa OR (@idempresa=0 AND (	OC.oce_idempresa IN (	SELECT	DISTINCT emp_idempresa 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND emp_idempresa = (CASE WHEN @idempresa = 0 THEN  emp_idempresa ELSE  @idempresa END)))))
						AND (	OC.oce_idsucursal = @idSucursal OR (@idSucursal=0 AND (OC.oce_idsucursal IN(	SELECT	DISTINCT suc_idsucursal 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND suc_idsucursal = (CASE WHEN @idSucursal = 0 THEN  suc_idsucursal ELSE  @idSucursal END)))))
						AND (	OC.oce_iddepartamento = @iddepartamento OR (@iddepartamento=0 AND (OC.oce_iddepartamento IN (	SELECT	DISTINCT dep_iddepartamento 
																																FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																																WHERE	usu_idusuario = @idusuariosolicitante 
																																	AND dep_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN  dep_iddepartamento ELSE  @iddepartamento END)))))		
						AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
						AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
						AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
						AND ( (DAN.anu_numeroserie LIKE '%'+ @numeroSerie + '%') OR (DASN.asn_numeroserie LIKE '%'+ @numeroSerie + '%'))	
						
			END
		IF(@tipoBusqueda = 8)--like ordenServicio
			BEGIN
				PRINT('1.-Comienza Proceso 1 con tipo de busqueda 4');
				SELECT  DISTINCT OC.oce_folioorden AS Folio_Operacion 
						, TIPOR.tip_nombre AS tipoorden
						, OC.oce_fechaorden AS oce_fechaorden
						, SITOR.sod_nombresituacion AS situacionOrden
						, RTRIM(LTRIM(PER.PER_NOMRAZON + ' ' + PER.PER_PATERNO + ' ' + PER.PER_MATERNO)) as Proveedor		
						, EMP.emp_nombre AS empNombre
						, SUC.suc_nombre AS sucursal
						, DEP.[dep_nombre] AS depto
						, OC.oce_importetotal AS oce_importetotal
						,CASE WHEN OC.oce_idproveedor IN (6) OR oce_idtipoorden IN (4,5) THEN 1
							  ELSE 0 
							  END AS esPlanta
						,(	SELECT	TOP 1 D.Nodo_Id 
							FROM	[Centralizacionv2].[dbo].[DIG_EXP_NODO]  D
							WHERE	D.Proc_Id = DG.Proc_Id 
									AND D.Folio_Operacion = OC.oce_folioorden 
									AND  D.Nodo_Estatus_Id = 2 ) AS nodoactual     
						,CASE	WHEN R.irr_folioinicial IS NOT NULL THEN	1 
								WHEN RE.irr_folionuevo  IS NOT NULL THEN	2
								WHEN REF.ifr_folionuevo IS NOT NULL THEN	3
								WHEN F.ifs_folionuevo IS NOT NULL THEN 5
								ELSE 1
								END AS tipofolio  
				FROM	[BDPersonas].[dbo].[cat_personas] AS PER
						LEFT JOIN cuentasxpagar.dbo.cxp_ordencompra AS OC  ON OC.oce_idproveedor =PER.PER_IDPERSONA 
						LEFT JOIN dbo.DIG_EXPEDIENTE AS DG ON DG.Folio_Operacion= OC.oce_folioorden
						LEFT JOIN [ControlAplicaciones].dbo.cat_empresas EMP ON OC.oce_idempresa = EMP.[emp_idempresa]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_sucursales] SUC ON OC.oce_idsucursal = SUC.[suc_idsucursal]
						LEFT JOIN [ControlAplicaciones].dbo.[cat_departamentos] DEP ON OC.oce_iddepartamento = DEP.[dep_iddepartamento]
						LEFT JOIN cuentasxpagar.dbo.cat_tiposorden TIPOR ON OC.oce_idtipoorden = TIPOR.[tip_idtipoorden]
						LEFT JOIN cuentasxpagar.dbo.cat_situacionorden SITOR ON OC.sod_idsituacionorden = SITOR.[sod_idsituacionorden]
						LEFT JOIN [dbo].[PPRO_DATOSFACTURAS] DF ON DF.folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] DAN ON DAN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleseminuevos] DASN ON DASN.oce_folioorden = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_detalleservicio] DS ON DS.oce_folioorden = OC.oce_folioorden
						-------------------------------------
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS R ON R.[irr_folioinicial] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionremrefac] AS RE ON RE.[irr_folionuevo] =  OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacrefac] AS REF ON REF.[ifr_folionuevo] = OC.oce_folioorden
						LEFT JOIN [cuentasxpagar].[dbo].[cxp_integracionfacser]  AS F ON F.[ifs_folionuevo] = OC.oce_folioorden
						-------------------------------------
						INNER JOIN ControlAplicaciones.dbo.OPE_ORGANIGRAMA AS OPE ON OPE.usu_idusuario = @idusuariosolicitante AND OPE.div_iddivision = OC.oce_iddivision AND OPE.emp_idempresa = OC.oce_idempresa AND OPE.suc_idsucursal = OC.oce_idsucursal AND OPE.dep_iddepartamento = OC.oce_iddepartamento
				WHERE	(	oce_iddivision = @iddivision OR (@iddivision = 0 AND (	OC.oce_iddivision IN (	SELECT	DISTINCT div_iddivision 
																											FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																											WHERE	usu_idusuario = @idusuariosolicitante 
																													AND div_iddivision = (CASE WHEN @iddivision = 0 THEN  div_iddivision ELSE  @iddivision END)))))
						AND (	OC.oce_idempresa = @idempresa OR (@idempresa=0 AND (	OC.oce_idempresa IN (	SELECT	DISTINCT emp_idempresa 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND emp_idempresa = (CASE WHEN @idempresa = 0 THEN  emp_idempresa ELSE  @idempresa END)))))
						AND (	OC.oce_idsucursal = @idSucursal OR (@idSucursal=0 AND (OC.oce_idsucursal IN(	SELECT	DISTINCT suc_idsucursal 
																												FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																												WHERE	usu_idusuario = @idusuariosolicitante 
																														AND suc_idsucursal = (CASE WHEN @idSucursal = 0 THEN  suc_idsucursal ELSE  @idSucursal END)))))
						AND (	OC.oce_iddepartamento = @iddepartamento OR (@iddepartamento=0 AND (OC.oce_iddepartamento IN (	SELECT	DISTINCT dep_iddepartamento 
																																FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																																WHERE	usu_idusuario = @idusuariosolicitante 
																																	AND dep_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN  dep_iddepartamento ELSE  @iddepartamento END)))))		
						AND ((@idproveedor = 0) OR(OC.oce_idproveedor = @idproveedor))
						AND ((@idTipoOrden = -1) OR(OC.oce_idtipoorden = @idTipoOrden))
						AND (OC.oce_fechaorden BETWEEN @fechaini AND @fechafin)
						AND ((@ordenServicio = '') OR (DS.ser_ordenservicio LIKE  '%'+ @ordenServicio + '%'))
			END			
	
	END 
ELSE

IF(@idProceso = 2)
BEGIN
   PRINT('1.-Comienza Proceso 2');   
	SELECT  E.Folio_Operacion    AS Folio_Operacion
	        ,'N/A'               AS tipoorden
			,O.ucu_fechacotiza   AS oce_fechaorden
			,ST.cec_nombre AS situacionOrden
			,(SELECT TOP 1 RTRIM(LTRIM(PER.[per_nomrazon]  + ' ' + PER.[per_paterno] + ' ' + PER.[per_materno]))
                FROM BDPersonas.dbo.cat_personas AS PER 
               WHERE PER.per_idpersona = O.ucu_idcliente) AS Proveedor   --NombreCliente
	        ,EM.emp_nombre     AS empNombre
	        ,S.suc_nombre      AS sucursal
			,D.dep_nombre      AS depto
			--,350000.00  AS oce_importetotal
			,SUM(CD.ucn_total)  AS oce_importetotal
			,O.ucu_idcliente   AS esPlanta            --idCliente para CXC
			,1                 AS nodoactual          --NodoAcutal
		    ,1                 AS tipofolio
	  FROM  dbo.DIG_EXPEDIENTE AS E 
			INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O  ON O.[ucu_foliocotizacion] COLLATE Modern_Spanish_CI_AS = E.Folio_Operacion COLLATE Modern_Spanish_CI_AS
			INNER JOIN [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES] AS CD ON CD.ucu_idcotizacion = O.ucu_idcotizacion
			INNER JOIN ControlAplicaciones.dbo.cat_departamentos    AS D ON O.ucu_iddepartamento = D.dep_iddepartamento
			INNER JOIN ControlAplicaciones.dbo.cat_sucursales       AS S ON D.suc_idsucursal =  S.suc_idsucursal AND  S.suc_idsucursal = O.ucu_idsucursal
			INNER JOIN ControlAplicaciones.dbo.cat_empresas         AS EM ON S.emp_idempresa = EM.emp_idempresa   AND  S.emp_idempresa = O.ucu_idempresa
			INNER JOIN ControlAplicaciones.dbo.cat_divisiones       AS DIV ON EM.div_iddivision = DIV.div_iddivision
			-----------------------------------------------------------------
			INNER JOIN cuentasporcobrar.dbo.cat_estatuscotiza AS ST ON  ST.cec_idestatuscotiza = O.cec_idestatuscotiza
			-----------------------------------------------------------------
     WHERE  (	ucu_iddivision = @iddivision OR (@iddivision = 0 AND (	O.ucu_iddivision IN (	SELECT	DISTINCT div_iddivision 
																								FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																								WHERE	usu_idusuario = @idusuariosolicitante 
																										AND div_iddivision = (CASE WHEN @iddivision = 0 THEN  div_iddivision ELSE  @iddivision END)))))
				AND (	O.ucu_idempresa = @idempresa OR (@idempresa=0 AND (	O.ucu_idempresa IN (	SELECT	DISTINCT emp_idempresa 
																										FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																										WHERE	usu_idusuario = @idusuariosolicitante 
																												AND emp_idempresa = (CASE WHEN @idempresa = 0 THEN  emp_idempresa ELSE  @idempresa END)))))
				AND (	O.ucu_idsucursal = @idSucursal OR (@idSucursal=0 AND (O.ucu_idsucursal IN(	SELECT	DISTINCT suc_idsucursal 
																										FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																										WHERE	usu_idusuario = @idusuariosolicitante 
																												AND suc_idsucursal = (CASE WHEN @idSucursal = 0 THEN  suc_idsucursal ELSE  @idSucursal END)))))
				AND (	O.ucu_iddepartamento = @iddepartamento OR (@iddepartamento=0 AND (O.ucu_iddepartamento IN (	SELECT	DISTINCT dep_iddepartamento 
																														FROM	ControlAplicaciones.dbo.OPE_ORGANIGRAMA  
																														WHERE	usu_idusuario = @idusuariosolicitante 
																															AND dep_iddepartamento = (CASE WHEN @iddepartamento = 0 THEN  dep_iddepartamento ELSE  @iddepartamento END)))))	
	 	 		AND ((@idproveedor = 0) OR (O.ucu_idcliente = @idproveedor))
			AND E.Folio_Operacion  LIKE '%' + @folioorden + '%' 
			AND (O.ucu_fechacotiza BETWEEN @fechaini AND @fechafin)
			GROUP BY Folio_Operacion, O.ucu_fechacotiza, EM.emp_nombre, S.suc_nombre, D.dep_nombre, O.ucu_idcliente,ST.cec_nombre
	
	PRINT('3.-Fin');	        
END

END TRY
  BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_ORDENES_FILTROS_SP_NODE'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

