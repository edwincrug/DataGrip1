-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--- TEST [expedienteSeminuevo].[SEL_ALL_SUCURSALES_BY_EMPRESA] 4
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_ALL_SUCURSALES_BY_EMPRESA]
	@idEmpresa INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT
		nombre_sucursal,
		suc_idSucursal,
		emp_idempresa 
	FROM DIG_CAT_BASES_BPRO WHERE emp_idEmpresa = @idEmpresa AND tipo != 2
END

go

