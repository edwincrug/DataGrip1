-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST [expedienteSeminuevo].[SEL_SEG_USUARIO_PERFIL_SP] 71,139
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[SEL_SEG_USUARIO_PERFIL_SP] 
	 @idUsuario INT = 0
	,@idPerfil INT = 0
AS
BEGIN

	SELECT 
		CASE WHEN B.id_accion IS NULL THEN 0 ELSE 1 END AS aplica
		,ACC.nombre
	FROM (
		SELECT 
			id_accion 
			,nombre
		FROM [Centralizacionv2].[expedienteSeminuevo].[seg_Accion] ) ACC
		LEFT JOIN   (
		 SELECT 
			A.[id_accion]							
			,A.[nombre]
			FROM (
					SELECT 
						A.[id_accion]							
						,A.[nombre]
					FROM [Centralizacionv2].[expedienteSeminuevo].[seg_PerfilAccion] PA
					INNER JOIN [Centralizacionv2].[expedienteSeminuevo].[seg_Accion] A ON PA.id_accion = A.id_accion
					WHERE id_perfil = @idPerfil
			UNION ALL
					SELECT   
						A.[id_accion]							
						,A.[nombre]
					FROM [Centralizacionv2].[expedienteSeminuevo].[seg_UsuPrivilegio] UP
					INNER JOIN [Centralizacionv2].[expedienteSeminuevo].[seg_Accion] A ON UP.id_accion = A.id_accion
					WHERE id_usuario = @idUsuario) A
			WHERE A.[id_accion] NOT IN (SELECT id_accion FROM [Centralizacionv2].[expedienteSeminuevo].[seg_UsuRestriccion] WHERE id_usuario = @idUsuario)) b  ON ACC.id_accion = B.id_accion
END

go

