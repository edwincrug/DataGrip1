-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--TEST [expedienteSeminuevo].UPD_TRASPASOS_EXPEDIENTES_SP 0
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].UPD_TRASPASOS_EXPEDIENTES_SP 
@numDias   INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @tempTraspasos TABLE (id INT IDENTITY, IDTRASPASO INT, VIN VARCHAR(150), SUCENVIA VARCHAR(100), SUCRECIBE VARCHAR(100), EMPRESA_ENVIA INT, SUCURSAL_ENVIA INT, EMPRESA_RECIBE INT, SUCURSAL_RECIBE INT, ID_INTELIMOTORS_SUCURSAL_RECIBE VARCHAR(100))

	INSERT INTO @tempTraspasos
	EXEC [expedienteSeminuevo].[SEL_UNIDADES_TRASPASOS_EXPEDIENTES_SEMINUEVOS_SP] @numDias

	DECLARE @max INT, @min INT;

	SELECT 
		@max = MAX(id),
		@min = MIN(id)
	FROM @tempTraspasos

	WHILE @min <= @max
		BEGIN
			DECLARE @vin VARCHAR(150), @empEnvia INT, @sucEnvia INT, @empRecibe INT, @sucRecibe INT;

			SELECT 
				 @vin = VIN,
				 @empEnvia = EMPRESA_ENVIA,
				 @sucEnvia = SUCURSAL_ENVIA,
				 @empRecibe = EMPRESA_RECIBE,
				 @sucRecibe = SUCURSAL_RECIBE
			FROM @tempTraspasos WHERE id = @min;

			IF EXISTS ( SELECT exp_vin FROM [expedienteSeminuevo].[expedientes] WHERE exp_vin = @vin AND exp_empresa = @empEnvia AND exp_sucursal = @sucEnvia )
				BEGIN
					UPDATE [expedienteSeminuevo].[expedientes] SET exp_empresa = @empRecibe, exp_sucursal = @sucRecibe 
					WHERE exp_vin = @vin AND exp_empresa = @empEnvia AND exp_sucursal = @sucEnvia

					INSERT INTO [expedienteSeminuevo].[bitacoraTransferencias]
					VALUES (@vin, @empEnvia, @sucEnvia, @empRecibe, @sucRecibe, GETDATE())
				END

			SET @min = @min + 1;
		END
END
go

