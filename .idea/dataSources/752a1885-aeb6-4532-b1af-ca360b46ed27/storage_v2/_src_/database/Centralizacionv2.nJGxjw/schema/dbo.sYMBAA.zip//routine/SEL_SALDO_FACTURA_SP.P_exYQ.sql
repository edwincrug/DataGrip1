-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
/*
DECLARE @saldo NUMERIC(18,2) 
exec [SEL_SALDO_FACTURA_SP] 
'AA000000015','AU-AZ-ZAR-UN-1', @saldo OUTPUT
SELECT @saldo
*/
CREATE PROCEDURE [dbo].[SEL_SALDO_FACTURA_SP] 
	@factura NVARCHAR(50) 
	,@folio NVARCHAR(50) 
	,@saldo NUMERIC(18,2) output
AS
BEGIN
	------------------------------------------------------------
	--Otengo la ip del servidor + el nombre de la base de la sucursal y el id de la cotizacion 
	------------------------------------------------------------
	DECLARE @baseSucursal VARCHAR(100) 
		,@idCotizacion INT
	SELECT @idCotizacion = ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL WHERE ucu_foliocotizacion = @folio
	SET @baseSucursal = [dbo].[base_Cotizacion](@folio)
	--SELECT	@baseSucursal = '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' 
	--	,@idCotizacion = ucu_idcotizacion
	--FROM	cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL CU
	--	INNER JOIN DIG_CAT_BASES_BPRO PRO ON CU.ucu_idempresa = PRO.emp_idEmpresa AND CU.ucu_idsucursal = PRO.suc_idSucursal AND PRO.estatus = 1 AND PRO.tipo = 1
	--WHERE ucu_foliocotizacion = @folio
	--PRINT @baseSucursal
	-----------------------------------------------------------
	--Obtengo anticipo relacionado a la cotizacion 
	-----------------------------------------------------------
	DECLARE @anticipo VARCHAR(MAX)
		,@idAnticipo VARCHAR(50)
	DECLARE @auxiliar TABLE(idAnticipo VARCHAR(50))
	SET @anticipo = 'SELECT PAM_IDDOCTO FROM '+ @baseSucursal +'CXC_PAGANT WHERE PAM_IDCOTIZACIONWEB = '+CONVERT(VARCHAR(50),@idCotizacion)+''
	INSERT INTO @auxiliar
	EXECUTE(@anticipo)
	SELECT @idAnticipo = idAnticipo FROM @auxiliar
	--PRINT @idAnticipo

	------------------------------------------------------------
	----Declaro variable tabla donde guardare los pagos 
	------------------------------------------------------------
	DECLARE @resumenAnticipo TABLE ( cargo NUMERIC(18,2),abono NUMERIC(18,2))

	SET @anticipo = 'SELECT	SUM(CCP_CARGO),SUM(CCP_ABONO) ' + char(13) + 
					'FROM	'+@baseSucursal+'VIS_CONCAR01  AS Car_Externa ' + char(13) + 
					'		INNER JOIN '+@baseSucursal+'pnc_parametr As A ON CCP_CARTERA = A.PAR_IDENPARA ' + char(13) + 
					'		LEFT OUTER JOIN '+@baseSucursal+'pnc_parametr As B ON CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = '+char(39)+'TIMO'+char(39)+' ' + char(13) + 
					'		INNER JOIN GA_Corporativa.dbo.Per_Personas ON CCP_IDPERSONA = PER_IDPERSONA  ' + char(13) + 
					'		LEFT JOIN cuentasxpagar.dbo.cxp_ordencompra Z ON Car_Externa.ccp_iddocto = Z.oce_folioorden COLLATE Modern_Spanish_CI_AS ' + char(13) + 
					'		LEFT JOIN cuentasxpagar.dbo.cxp_detalleautosnuevos ZZ ON Z.oce_folioorden = ZZ.oce_folioorden ' + char(13) + 
					'		LEFT JOIN '+@baseSucursal+'SER_VEHICULO On Car_Externa.CCP_OBSGEN=VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS ' + char(13) + 
					'		LEFT JOIN ppro_datosfacturas on Car_Externa.CCP_IDDOCTO = folioorden COLLATE Modern_Spanish_CI_AS ' + char(13) +
					'		INNER JOIN '+@baseSucursal+'PNC_PARAMETR PARAME ON PARAME.PAR_TIPOPARA = ''TIMO'' AND PARAME.PAR_IDENPARA = Car_Externa.CCP_TIPODOCTO '+ char(13) + 
					'WHERE	A.PAR_TIPOPARA = '+char(39)+'CARTERA'+char(39)+'  AND A.PAR_IDMODULO = '+char(39)+'CXC'+char(39)+'  AND CCP_IDDOCTO='+char(39)+@factura+char(39)+'  and a.par_importe5 <> 1   ' + char(13) +  
					''
	PRINT (@anticipo)
	INSERT INTO @resumenAnticipo 
	EXECUTE (@anticipo)
	SET @saldo = (SELECT  ISNULL(cargo,0) - ISNULL(abono,0) AS saldo FROM @resumenAnticipo)
	RETURN @saldo
END;

go

