

-- EXECUTE [dbo].[SEL_VALIDA_CUENTA_PROV_SP] @ctaBancaria='0186709842 ',@convenio='', @idProveedor = 24401, @idEmpresa=1    
CREATE PROCEDURE [dbo].[PROV_SEL_VALIDA_CUENTA_BANCARIA_SP]
      @ctaBancaria    VARCHAR(25)
	 ,@convenio       VARCHAR(10)
	
AS
BEGIN
	--declare  @ctaBancaria    VARCHAR(25) =  '0186709842'
	-- ,@convenio       VARCHAR(10) = ''

	

	BEGIN TRY
	SET NOCOUNT ON;

    DECLARE @aux               INT = 1
	DECLARE @max               INT = 0
	DECLARE @idEmpresaBusca    INT = 0
	DECLARE @idSucursal        INT = 0
	DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
	DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @nomEmpresa        NVARCHAR(100)=NULL
	DECLARE @ipServidor        NVARCHAR(100)=NULL
	DECLARE @cadIpServidor     NVARCHAR(100)=NULL
	DECLARE @consulta          NVARCHAR(MAX)=NULL
	DECLARE @ipServer		   NVARCHAR(20)
	
	DECLARE @existeCuenta TABLE  (  IDB INT IDENTITY(1,1),
								    idEmpresa         int
								   ,nombreEmpresa     nvarchar(100)
								   ,idProveedor       int 
								  )     

    ------------------------------------------------------------
	-- BUSCAMOS EN TODAS LAS CONCENTRADORAS
	------------------------------------------------------------	
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
	                        idEmpresa         int
							,nombreEmpresa     nvarchar(100)
							,nombreSucursal    nvarchar(100)
							,nomBaseConcentra  nvarchar(50)
							,nomBaseMatriz     nvarchar(50)
							,ipServidor        nvarchar(20)
							,idSucursal        int 
							)     

	 INSERT INTO @Bases
            SELECT B.[emp_idempresa]
			      ,A.[emp_nombre]
			      ,B.[nombre_sucursal]
				  ,B.[nombre_base]
				  ,B.[nombre_base_matriz]
				  ,B.[ip_servidor]
				  ,B.[sucursal_matriz]
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
			       INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON A.[emp_idempresa]= B.[emp_idempresa]
			WHERE B.tipo = 2
			  --AND B.[emp_idempresa] <> @idEmpresa

     --SELECT * FROM @Bases

	
	 ------------------------------------------------------------
	 -- RECORREMOS LAS CONCENTRADORAS PARA BUSCAR EL PROVEEDOR
	 ------------------------------------------------------------
	 SET @max = (SELECT count(IDB) FROM @Bases)
	 
	 WHILE(@aux <= @max)
	 BEGIN
	 
         --SELECT @aux
		 SELECT  @idEmpresaBusca   = DB.idEmpresa 
		        ,@nomEmpresa       = DB.nombreEmpresa
				,@nomBaseConcentra = DB.nomBaseConcentra
				,@nomBaseMatriz    = DB.nomBaseMatriz
				,@idSucursal       = DB.idSucursal
				,@ipServidor       = DB.ipServidor
				
		   FROM @Bases AS DB 
		  WHERE DB.IDB = @aux 

		  SET @cadIpServidor = '['+ @ipServidor  +'].'
		  
		  SELECT @ipServer = local_net_address
		  FROM sys.dm_exec_connections
          WHERE Session_id = @@SPID
		
		
		IF (@ipServidor = @ipServer)
		BEGIN
		set @cadIpServidor =''
		END
	

		IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @nomBaseConcentra)) 
		BEGIN
		
			SET @consulta = ' SELECT  ' + cast (@idEmpresaBusca as varchar(20)) +' ,' +''''+ @nomEmpresa +'''' + '          
									 ,BCO_IDPERSONA          
								FROM '+ @cadIpServidor + @nomBaseConcentra +'.DBO.CON_BANCOS ' + 
                            ' WHERE BCO_NUMCUENTA = ' + ''''+ @ctaBancaria + '''' + 
  							   ' AND BCO_CONVENIOCIE=' + ''''+ @convenio + '''' + 
							   ' AND BCO_AUTORIZADA = 1 '
							--   ' AND BCO_IDPERSONA <> ' + cast (@idProveedor as varchar(20)) 
                            
							--' WHERE BCO_IDPERSONA = ' + cast (@idProveedor as varchar(20)) 


          PRINT @consulta
		  INSERT INTO @existeCuenta
		         EXECUTE (@consulta)
		END
		
		  --SELECT @cadIpServidor

		 
		 SET @aux = @aux + 1
		 
	 END

	 ------------------------------------------------------------
	 -- RESULTADO FINAL
	 ------------------------------------------------------------
	 

	 IF NOT EXISTS(SELECT 1 FROM @existeCuenta)
			BEGIN
				SELECT 1 AS estatus,'Cuenta Valida' AS msj
			END
     ELSE
	        BEGIN
				SELECT	0 AS estatus
						,'Hay diferentes usuario(s) con ese numero de cuenta' AS msj
						, nombreEmpresa AS empresa
						, idProveedor AS idProveedor
						,RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre  
				FROM	@existeCuenta AS C
						INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS P ON C.idProveedor = P.PER_IDPERSONA
			END
	 
	   
	END TRY

    BEGIN CATCH
	select 'Error'
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_VALIDA_CUENTA_PROV_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END

go

