-- =============================================
-- Author:
-- Create date:
-- Description:
-- =============================================
CREATE PROCEDURE dbo.EXP_SEND_FOLIOS_MAIL
AS
BEGIN
		DECLARE @minDays INT;
		
		SELECT @minDays = par_valor FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MINESCALAR'
		
		
		SELECT  DISTINCT CD.ucn_noserie  AS folio,
				CASE WHEN C.ucu_idusuarioalta = 0 THEN -1 ELSE C.ucu_idusuarioalta END AS ucu_idusuarioalta,
				ISNULL(PP.PER_NOMRAZON + ' ' + PP.PER_PATERNO + ' ' + PP.PER_MATERNO,'') nombre, --U.usu_nombre + ' ' + usu_paterno + ' ' + usu_materno, ''
				PP.PER_EMAIL AS usu_correo,
				PP.PER_NOMRAZON + ' ' + PP.PER_PATERNO + ' ' + PP.PER_MATERNO AS vendedor, 
				C.ucu_idempresa,
				C.ucu_idsucursal,
				C.ucu_idagente
		FROM EXP_FOLIOS_MAIL M
				INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = M.folio COLLATE DATABASE_DEFAULT
				INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
				INNER JOIN GA_Corporativa.DBO.PER_PERSONAS AS PP ON PP.PER_IDPERSONA = C.ucu_idagente
				LEFT JOIN [controlAplicaciones].[DBO].[cat_usuarios] U ON U.pto_idpuesto = 170 AND U.emp_idempresa = C.ucu_idempresa AND U.suc_idsucursal = C.ucu_idsucursal
				LEFT JOIN  [controlAplicaciones].[DBO].[ope_organigrama] O ON O.emp_idempresa = C.ucu_idempresa AND O.suc_idsucursal = C.ucu_idsucursal
		WHERE M.dias < @minDays
		--DECLARE @minDays INT;
		--SELECT
		-- @minDays = par_valor
		--FROM [DIG_PARAMETROS] WHERE par_descripcion = 'MINESCALAR'
		--DECLARE @min INT, @max INT, @aux INT = 1;
		--DECLARE @empresa INT, @sucursal INT;
		--DECLARE @allFolios TABLE (consecutivo INT, serie VARCHAR(100), idEmpresa INT, idSucursal INT);
		--DECLARE @folioUsuarios TABLE (idusuario INT, correo VARCHAR(100), nombre VARCHAR(100), serie VARCHAR(100) )
		--INSERT INTO @allFolios
		--SELECT
		-- ROW_NUMBER() OVER (ORDER BY M.folio ASC) consecutivo,
		-- CD.ucn_noserie,
		-- C.ucu_idempresa,
		-- C.ucu_idsucursal
		--FROM EXP_FOLIOS_MAIL M
		--INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = M.folio COLLATE DATABASE_DEFAULT
		--INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
		--WHERE M.dias < @minDays
		--SELECT
		-- @min = MIN(consecutivo),
		-- @max = MAX(consecutivo)
		--FROM @allFolios
		--WHILE(@aux <= @max)
		-- BEGIN
		-- SET @empresa = 0;
		-- SET @sucursal = 0;
		-- SELECT
		-- @empresa = idEmpresa,
		-- @sucursal = idSucursal
		-- FROM @allFolios WHERE consecutivo = @aux
		-- IF EXISTS ( SELECT
		-- DISTINCT U.usu_idusuario,
		-- U.usu_correo
		-- FROM [controlAplicaciones].[DBO].[ope_organigrama] O
		-- INNER JOIN [controlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = O.usu_idusuario AND U.pto_idpuesto = 170
		-- WHERE O.emp_idempresa = @empresa AND O.suc_idsucursal = @sucursal
		-- GROUP BY U.usu_idusuario, U.usu_correo )
		-- BEGIN
		-- INSERT INTO @folioUsuarios
		-- SELECT
		-- DISTINCT U.usu_idusuario,
		-- U.usu_correo,
		-- U.usu_nombre + ' ' + usu_paterno + ' ' + usu_materno nombreGere,
		-- F.serie
		-- FROM [controlAplicaciones].[DBO].[ope_organigrama] O
		-- INNER JOIN [controlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = O.usu_idusuario AND U.pto_idpuesto = 170
		-- INNER JOIN @allFolios F ON F.consecutivo = @aux
		-- WHERE O.emp_idempresa = @empresa AND O.suc_idsucursal = @sucursal
		-- GROUP BY U.usu_idusuario, U.usu_correo, F.serie, U.usu_nombre, U.usu_paterno, U.usu_materno
		-- END
		-- ELSE
		-- BEGIN
		-- INSERT INTO @folioUsuarios
		-- SELECT
		-- '',
		-- '',
		-- '',
		-- serie
		-- FROM @allFolios WHERE consecutivo = @aux
		-- END
		-- SET @aux = @aux + 1
		-- END
		-- SELECT
		-- CD.ucn_noserie AS folio,
		-- C.ucu_idusuarioalta,
		-- F.nombre AS nombre,
		-- F.correo AS usu_correo,
		-- U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS vendedor,
		-- C.ucu_idempresa,
		-- C.ucu_idsucursal
		-- FROM EXP_FOLIOS_MAIL M
		-- INNER JOIN [cuentasporcobrar].[DBO].[uni_cotizacionuniversal] C ON C.ucu_foliocotizacion = M.folio COLLATE DATABASE_DEFAULT
		-- INNER JOIN [cuentasporcobrar].[DBO].[UNI_COTIZACIONUNIVERSALUNIDADES] CD ON CD.ucu_idcotizacion = C.ucu_idcotizacion
		-- INNER JOIN [ControlAplicaciones].[DBO].[cat_usuarios] U ON U.usu_idusuario = C.ucu_idusuarioalta
		-- INNER JOIN @folioUsuarios F ON F.serie = CD.ucn_noserie COLLATE DATABASE_DEFAULT
		-- WHERE M.dias < @minDays
		-- GROUP BY ucu_idusuarioalta , M.folio, U.usu_correo, U.usu_nombre, U.usu_paterno, U.usu_materno, U.usu_correo, CD.ucn_noserie, C.ucu_idempresa, C.ucu_idsucursal, F.correo, F.nombre
END
go

