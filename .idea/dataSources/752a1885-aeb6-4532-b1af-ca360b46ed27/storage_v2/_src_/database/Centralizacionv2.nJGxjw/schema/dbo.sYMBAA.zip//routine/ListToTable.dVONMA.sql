--drop function ListToTable

CREATE FUNCTION ListToTable
(
@list nvarchar(4000)
)
RETURNS @return TABLE
(
n nvarchar(15),
s nvarchar(15)
)
AS
BEGIN
SET @list = NULLIF(ltrim(rtrim(@list)),'')

DECLARE @xml AS XML = CAST('<root><row><n>' + REPLACE(REPLACE(@list, ',', '</s></row><row><n>'), ':', '</n><s>') + '</s></row></root>' AS XML) ;

INSERT INTO @return (n, s)
SELECT root.row.value('n[1]', 'nvarchar(15)')
, root.row.value('s[1]', 'nvarchar(4000)')
FROM @xml.nodes('/root/row') as root(row)

RETURN
END
go

