-- ===================================================================================================
-- Author:		Arturo Rodea Victoria
-- Create date: 23/10/2015
-- Modified date: 06/05/2016  LMS Existencia del Documento
-- Modified date: 31/05/2016  LMS Agrego Documento de Cancelacion si esta Cancelada la orden de Compra
-- solo en el nodo donde esta parada la orden siempre que el Nodo sea mayor a 4 y menor a 15 
-- Description: Stored que recupera los datos de documentos por nodo, folio y perfil
-- Modified date: 01/06/2016  LMS Agrego docuemntos de BPRO para nodo 15
-- ===================================================================================================
--EXECUTE [SEL_DOCUMENTOS_NODO_SP_UN] 7, 'AU-ZM-ZAR-UN-PE-159', 1
CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_NODO_SP_UN]     
	  @idNodo int
	, @folio nvarchar(50)
	, @idperfil int
	
AS
BEGIN
    ----------------------------------------------------------------------
	-- Determino Tipo de Proceso
	----------------------------------------------------------------------
	DECLARE @idProceso      INT=0;
	DECLARE @folioPlanPiso  nvarchar(50)

	SELECT @idProceso = E.Proc_Id        
	  FROM dbo.DIG_EXPEDIENTE AS E 
     WHERE E.Folio_Operacion = @folio

    ----------------------------------------------------------------------
	-- Determino si es una orden Padre, busco la orden Hijo
	----------------------------------------------------------------------
	SELECT @folioPlanPiso = Folio_Alias  
      FROM dbo.DIG_EXP_PLAN_PISO 
     WHERE Folio_Operacion = @folio
    
	---------------------------------------------------------------------------------------------------------------------------
	--   Tipo de Proceso 1.-CXP Cuentas Por Pagar
	---------------------------------------------------------------------------------------------------------------------------
    IF (@idProceso = 1 OR @idProceso = 0)
	BEGIN
	DECLARE @NodoCancelacion int = 0
	DECLARE @origen1 nvarchar(100) = (SELECT par_valor COLLATE Modern_Spanish_CI_AS FROM DIG_PARAMETROS WHERE par_id = 3) -- Selecciona la ruta de subida	
    
	SELECT @NodoCancelacion = CASE  --Busco si esta cancelada la Orden
									WHEN EXISTS(
										select Folio_Operacion
										  from [Centralizacionv2].[dbo].[DIG_EXPEDIENTE]
										 where Folio_Operacion = @folio
										   and estatus_id = 2            --OC Cancelada
									)
									THEN (
									    --Busco el ultimo nodo activo
										select Top 1 Nodo_id
										  from [Centralizacionv2].[dbo].[DIG_EXP_NODO] 
										 where Folio_Operacion = @folio 
										   and Nodo_estatus_id = 2 
										 order by Nodo_id desc
									) 
									ELSE '0' 
									END		

   
    PRINT 'NodoCancelacion: ' + cast(@NodoCancelacion as varchar)

	IF (@idNodo < 5 or @idNodo >= 5 and @idNodo < 15 and @NodoCancelacion <> @idNodo )  --Orden Activa o Inactiva pero detenida en otro nodos
		BEGIN
		      PRINT 'QUERY SENCILLO: ' + cast(@idNodo as varchar)
			  print 'lechon'
			  SELECT  DISTINCT E.Proc_Id                                                    as idProceso
										, EN.Nodo_Id												   as idNodo
										, N.Nodo_Nombre COLLATE Modern_Spanish_CI_AS                   as nombreNodo
										, EN.Folio_Operacion COLLATE Modern_Spanish_CI_AS              as folio
										, UPPER(CD.Doc_Nombre) COLLATE Modern_Spanish_CI_AS            as nombreDocumento
										, CD.Doc_Id                                                    as idDocumento
										, CD.Doc_Origen COLLATE Modern_Spanish_CI_AS                   as origen
										, UPPER(CD.Doc_Descripcion) COLLATE Modern_Spanish_CI_AS       as descripcion
										, PD.Perfil_Id                                                 as idPerfil
										, cast(PD.Consultar as int)                                    as consultar
										, cast(PD.Imprimir as int)                                     as imprimir
										, cast(PD.Enviar_Email  as int)                                as enviarEmail
										, cast(PD.Descargar as int)                                    as descargar
										, cast(PD.Cargar as int)                                       as cargar
										, EE.Estatus_Nombre COLLATE Modern_Spanish_CI_AS               as estatusNombre
										, EN.Nodo_Estatus_Id                                           as idEstatus
										, CASE WHEN CD.Doc_Origen = 1 THEN  @origen1 --+ dbo.OBTIENE_RUTA_FN(@folio, @idNodo, CD.Doc_Id)
										ELSE '' END AS Ruta
										,CASE WHEN ED.Fecha_Creacion is null THEN ''
											  WHEN ED.Fecha_Creacion is not null THEN --'Si'
																					CASE CD.Doc_Id
																						WHEN 11 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN 12 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN 13 THEN CD.[Doc_Ruta_Web] + 'Pol_PC_' + EN.Folio_Operacion +  CD.[Doc_Extencion]
																						WHEN 14 THEN CD.[Doc_Ruta_Web] + 'Pol_PT_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN 15 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																						WHEN 20 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + ISNULL((SELECT rfc_receptor 
																																											+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																											+ '/' + ISNULL(rfc_emisor,'xxxxx') + '_' + 
																																											CASE folio 
																																												WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																												ELSE  LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																											END
																																											+ '.pdf'
																																									   FROM PPRO_DATOSFACTURAS 
																																									  WHERE [folioorden] = EN.Folio_Operacion
																																									    AND [tipoDocumento] = 1 --Factura
																																									  ),(SELECT rfc_receptor 
																																											+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																											+ '/' + ISNULL(rfc_emisor,'xxxxx') + '_' + 
																																											CASE folio 
																																												WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																												ELSE  LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																											END
																																											+ '.pdf'
																																									   FROM PPRO_DATOSFACTURAS 
																																									  WHERE [folioorden] = @folioPlanPiso    --EN.Folio_Operacion
																																									    AND [tipoDocumento] = 1 --Factura
																																									  ))
                                                    ---------
													WHEN 10 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + ISNULL((SELECT rfc_receptor 
																																		+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																		+ '/' + rfc_emisor + '_' + 
																																		CASE folio 
																																			WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																			ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																		END
																																		+ '.pdf'
																																	FROM PPRO_DATOSFACTURAS 
																																	WHERE [folioorden] = EN.Folio_Operacion
																																	AND [tipoDocumento] = 2 --Nota de Credito
																																	),(SELECT rfc_receptor 
																																		+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																		+ '/' + rfc_emisor + '_' + 
																																		CASE folio 
																																			WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																			ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																		END
																																		+ '.pdf'
																																	FROM PPRO_DATOSFACTURAS 
																																	WHERE [folioorden] =  @folioPlanPiso  --EN.Folio_Operacion
																																	AND [tipoDocumento] = 2               --Nota de Credito
																																	))
													---------
																						ELSE 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.' + ED.Doc_Extencion --ISNULL(CD.[Doc_Extencion],'.pdf')
																					END
											  END AS existeDoc
										 ,D.Orden 	                                  AS orden
										 ,CD.Doc_NomCto COLLATE Modern_Spanish_CI_AS  AS tipo
										 ,CASE WHEN EXISTS(
																	SELECT [estatus]--[folioorden]--
																	  FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]  
																	 WHERE [folioorden] = @folio
																	   AND [estatus] = 2
																)
																THEN 2
																ELSE 1 
										 END                                          AS estatusDoc
								FROM     dbo.DIG_PERFIL_DOCUMENTO   AS PD LEFT JOIN
										 dbo.DIG_CATDOCUMENTO       AS CD ON PD.Doc_Id = CD.Doc_Id LEFT JOIN
										 dbo.DIG_EXPEDIENTE         AS E LEFT JOIN
										 dbo.DIG_ESTATUS_EXPEDIENTE AS EE ON E.Estatus_Id = EE.Estatus_Id LEFT JOIN
										 dbo.DIG_EXP_NODO           AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion LEFT JOIN
										 dbo.DIG_EXPNODO_DOC        AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id 
										 INNER JOIN dbo.DIG_NODO_DOC AS D ON ED.Doc_Id = D.Doc_Id AND ED.Nodo_Id = D.Nodo_Id
										 LEFT JOIN
										 dbo.DIG_NODO               AS N  ON EN.Proc_Id = N.Proc_Id AND EN.Nodo_Id = N.Nodo_Id LEFT JOIN
										 dbo.DIG_NODOPERFIL         AS NP ON N.Proc_Id = NP.Proc_Id AND N.Nodo_Id = NP.Nodo_Id ON PD.Doc_Id = ED.Doc_Id
								WHERE EN.Nodo_Id = @idNodo 
									AND (EN.Folio_Operacion = @folio OR EN.Folio_Operacion IN ( 
											SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
										  ) )
									AND PD.Perfil_Id = @idperfil
							   ORDER BY D.Orden
		END
	ELSE
		BEGIN
			IF (@idNodo >= 5 and @idNodo < 15 and @NodoCancelacion = @idNodo )   --Ordenes Canceladas y Paradas en el mismo Nodo
			BEGIN
			      PRINT 'QUERY SENCILLO + UNION: ' + cast(@idNodo as varchar)
				  SELECT * 
					FROM ((SELECT  DISTINCT E.Proc_Id							 as idProceso
											, EN.Nodo_Id						 as idNodo
											, N.Nodo_Nombre						 as nombreNodo
											, EN.Folio_Operacion				 as folio
											, CD.Doc_Nombre                      as nombreDocumento
											, CD.Doc_Id                          as idDocumento
											, CD.Doc_Origen                      as origen
											, CD.Doc_Descripcion				 as descripcion
											, PD.Perfil_Id                       as idPerfil
											, cast(PD.Consultar as int)          as consultar
											, cast(PD.Imprimir as int)           as imprimir
											, cast(PD.Enviar_Email  as int)      as enviarEmail
											, cast(PD.Descargar as int)          as descargar
											, cast(PD.Cargar as int)             as cargar
											, EE.Estatus_Nombre                  as estatusNombre
											, EN.Nodo_Estatus_Id                 as idEstatus
											, CASE WHEN CD.Doc_Origen = 1 THEN  @origen1 --+ dbo.OBTIENE_RUTA_FN(@folio, @idNodo, CD.Doc_Id)
												   ELSE '' END                   as Ruta
											,CASE WHEN ED.Fecha_Creacion is null THEN ''
													WHEN ED.Fecha_Creacion is not null THEN --'Si'
																						CASE CD.Doc_Id
																							WHEN 11 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																							WHEN 12 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																							WHEN 13 THEN CD.[Doc_Ruta_Web] + 'Pol_PC_' + EN.Folio_Operacion +  CD.[Doc_Extencion]
																							WHEN 14 THEN CD.[Doc_Ruta_Web] + 'Pol_PT_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																							WHEN 15 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																							WHEN 20 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + ISNULL((SELECT rfc_receptor 
																																												+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																												+ '/' + ISNULL(rfc_emisor,'xxxxx') + '_' + 
																																												CASE folio 
																																													WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																													ELSE  LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																												END
																																												+ '.pdf'
																																										   FROM PPRO_DATOSFACTURAS 
																																										  WHERE [folioorden] = EN.Folio_Operacion
																																											AND [tipoDocumento] = 1 --Factura
																																										  ),(SELECT rfc_receptor 
																																												+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																												+ '/' + ISNULL(rfc_emisor,'xxxxx') + '_' + 
																																												CASE folio 
																																													WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																													ELSE  LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																												END
																																												+ '.pdf'
																																										   FROM PPRO_DATOSFACTURAS 
																																										  WHERE [folioorden] = @folioPlanPiso    --EN.Folio_Operacion
																																											AND [tipoDocumento] = 1 --Factura
																																										  ))
																							---------
																							WHEN 10 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + ISNULL((SELECT rfc_receptor 
																																													+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																													+ '/' + rfc_emisor + '_' + 
																																													CASE folio 
																																														WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																														ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																													END
																																													+ '.pdf'
																																												FROM PPRO_DATOSFACTURAS 
																																												WHERE [folioorden] = EN.Folio_Operacion
																																												AND [tipoDocumento] = 2 --Nota de Credito
																																												),(SELECT rfc_receptor 
																																													+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																													+ '/' + rfc_emisor + '_' + 
																																													CASE folio 
																																														WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																														ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																													END
																																													+ '.pdf'
																																												FROM PPRO_DATOSFACTURAS 
																																												WHERE [folioorden] =  @folioPlanPiso  --EN.Folio_Operacion
																																												AND [tipoDocumento] = 2               --Nota de Credito
																																												))
																							---------
																							ELSE 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.' + ED.Doc_Extencion --ISNULL(CD.[Doc_Extencion],'.pdf')
																						END
													END                    as existeDoc
												,D.Orden	               as orden
												,CD.Doc_NomCto             as tipo
												,CASE WHEN EXISTS(
																	SELECT [estatus]--[folioorden]--
																	  FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]  
																	 WHERE [folioorden] = @folio
																	   AND [estatus] = 2
																)
																THEN 2
																ELSE 1 
										         END                                          AS estatusDoc
									FROM     dbo.DIG_PERFIL_DOCUMENTO   AS PD LEFT JOIN
												dbo.DIG_CATDOCUMENTO       AS CD ON PD.Doc_Id = CD.Doc_Id LEFT JOIN
												dbo.DIG_EXPEDIENTE         AS E LEFT JOIN
												dbo.DIG_ESTATUS_EXPEDIENTE AS EE ON E.Estatus_Id = EE.Estatus_Id LEFT JOIN
												dbo.DIG_EXP_NODO           AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion LEFT JOIN
												dbo.DIG_EXPNODO_DOC        AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id 
												INNER JOIN dbo.DIG_NODO_DOC AS D ON ED.Doc_Id = D.Doc_Id AND ED.Nodo_Id = D.Nodo_Id
												LEFT JOIN
												dbo.DIG_NODO               AS N  ON EN.Proc_Id = N.Proc_Id AND EN.Nodo_Id = N.Nodo_Id LEFT JOIN
												dbo.DIG_NODOPERFIL         AS NP ON N.Proc_Id = NP.Proc_Id AND N.Nodo_Id = NP.Nodo_Id ON PD.Doc_Id = ED.Doc_Id
									WHERE EN.Nodo_Id = @idNodo 
										AND (EN.Folio_Operacion = @folio OR EN.Folio_Operacion IN ( 
												SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
												) )
										AND PD.Perfil_Id = @idperfil
									--ORDER BY D.Orden	
                                    )
					    UNION
                                (SELECT 1                                           as idProceso       --int
									   ,@idNodo                                     as idNodo          --int
									   ,(select Nodo_Nombre from [DIG_NODO] where Nodo_id = @idNodo) COLLATE Modern_Spanish_CI_AS                                    as nombreNodo      --varchar
									   ,@folio  as folio           --varchar
									   ,C.[Doc_Nombre]                              as nombreDocumento --varchar
									   ,C.[Doc_Id]                                  as idDocumento     --int
									   ,C.[Doc_Origen]                              as origen          --varchar --BPRO
									   ,C.[Doc_Descripcion]                         as descripcion     --varchar
									   ,1                                           as idPerfil        --int
									   ,1                                           as consultar       --int
									   ,1                                           as imprimir        --bit
									   ,1                                           as enviarEmail     --bit
									   ,1                                           as descargar       --bit
									   ,0                                           as cargar          --bit
									   ,(select estatus_nombre COLLATE Modern_Spanish_CI_AS
										   from [Centralizacionv2].[dbo].[DIG_ESTATUS_EXPEDIENTE] 
										   where estatus_id=(select estatus_id 
															   from	[Centralizacionv2].[dbo].[DIG_EXPEDIENTE] 
															  where folio_operacion = @folio))  as estatusNombre   --varchar
									   ,(select estatus_id 
										   from	[Centralizacionv2].[dbo].[DIG_EXPEDIENTE] 
										  where folio_operacion = @folio)           as idEstatus  --int
									   ,'Ruta'    as Ruta            --varchar
									   ,'C:/Users/USUARIO/Documents/Cancelacion.pdf'   as existeDoc       --varchar
									   ,1                                           as orden           --decimal(5, 2)
									   ,C.[Doc_NomCto] as tipo           --varchar
									   ,1                                           AS estatusDoc
								 FROM  [Centralizacionv2].[dbo].[DIG_CATDOCUMENTO] AS C
								 WHERE [Doc_Id] = 23 
								 )) AS T 
				  ORDER BY T.orden 
				  
			END    
			ELSE
			BEGIN
				IF (@idNodo =15 )   --Ordenes Nodo 15
				BEGIN
					PRINT 'QUERY SENCILLO + JAV: ' + cast(@idNodo as varchar)
					SELECT * 
                      FROM ((SELECT 1                                            as idProceso       --int
									   ,@idNodo                                     as idNodo          --int
									   ,(select Nodo_Nombre from [DIG_NODO] where Nodo_id = @idNodo) COLLATE Modern_Spanish_CI_AS                                    as nombreNodo      --varchar
									   ,V.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS  as folio           --varchar
									   ,T.pol_nombre  COLLATE Modern_Spanish_CI_AS  as nombreDocumento --varchar
									   ,99                                          as idDocumento     --int
									   ,'2'                                         as origen          --varchar --BPRO
									   ,P.PAR_DESCRIP1                              as descripcion     --varchar
									   ,1                                           as idPerfil        --int
									   ,1                                           as consultar       --int
									   ,0                                           as imprimir        --bit
									   ,0                                           as enviarEmail     --bit
									   ,1                                           as descargar       --bit
									   ,0                                           as cargar          --bit
									   ,(select estatus_nombre COLLATE Modern_Spanish_CI_AS
										   from [Centralizacionv2].[dbo].[DIG_ESTATUS_EXPEDIENTE] 
										   where estatus_id=(select estatus_id 
															   from	[Centralizacionv2].[dbo].[DIG_EXPEDIENTE] 
															  where folio_operacion = @folio))  as estatusNombre   --varchar
									   ,(select estatus_id 
										   from	[Centralizacionv2].[dbo].[DIG_EXPEDIENTE] 
										  where folio_operacion = @folio)           as idEstatus  --int
									   ,CCP_TIPOPOL COLLATE Modern_Spanish_CI_AS    as Ruta            --varchar
									   ,'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/ZMO841221BJ4/2016_01/CSG051023TZ7_0808.pdf'   as existeDoc       --varchar
									   ,1                                           as orden           --decimal(5, 2)
									   ,CAST(CCP_CONSPOL as varchar(10)) + '-' + CAST(CCP_MES as varchar(2)) + '-' + CAST(Vcc_Anno as varchar(4)) + '-' + CCP_TIPOPOL as tipo 
									   ,1                                           AS estatusDoc          --varchar
								 FROM [GAZM_Concentra].[dbo].[vis_concar01] V 
									  INNER JOIN [GAZM_Concentra].[dbo].[PNC_PARAMETR] P ON V.CCP_TIPOPOL = P.PAR_IDENPARA
									  INNER JOIN [GA_Corporativa].[dbo].[cat_tipopoliza] T ON P.PAR_DESCRIP2 COLLATE Modern_Spanish_CI_AS  =  T.pol_identificador COLLATE Modern_Spanish_CI_AS
								WHERE V.CCP_IDDOCTO =  @folio
								  AND P.PAR_TIPOPARA = 'TIPOLI'
							 GROUP BY V.CCP_IDDOCTO  
									  ,T.pol_nombre  
									  ,P.PAR_DESCRIP1 
									  ,CCP_TIPOPOL
									  ,CCP_CONSPOL
									  ,CCP_MES
									  ,Vcc_Anno
									  )
					UNION
						(SELECT  DISTINCT E.Proc_Id                                                    as idProceso
										, EN.Nodo_Id												   as idNodo
										, N.Nodo_Nombre COLLATE Modern_Spanish_CI_AS                   as nombreNodo
										, EN.Folio_Operacion COLLATE Modern_Spanish_CI_AS              as folio
										, UPPER(CD.Doc_Nombre) COLLATE Modern_Spanish_CI_AS            as nombreDocumento
										, CD.Doc_Id                                                    as idDocumento
										, CD.Doc_Origen COLLATE Modern_Spanish_CI_AS                   as origen
										, UPPER(CD.Doc_Descripcion) COLLATE Modern_Spanish_CI_AS       as descripcion
										, PD.Perfil_Id                                                 as idPerfil
										, cast(PD.Consultar as int)                                    as consultar
										, cast(PD.Imprimir as int)                                     as imprimir
										, cast(PD.Enviar_Email  as int)                                as enviarEmail
										, cast(PD.Descargar as int)                                    as descargar
										, cast(PD.Cargar as int)                                       as cargar
										, EE.Estatus_Nombre COLLATE Modern_Spanish_CI_AS               as estatusNombre
										, EN.Nodo_Estatus_Id                                           as idEstatus
										, CASE WHEN CD.Doc_Origen = 1 THEN  @origen1 --+ dbo.OBTIENE_RUTA_FN(@folio, @idNodo, CD.Doc_Id)
										ELSE '' END AS Ruta
										,CASE WHEN ED.Fecha_Creacion is null THEN ''
											  WHEN ED.Fecha_Creacion is not null THEN --'Si'
																					CASE CD.Doc_Id
																						WHEN 11 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN 12 THEN CD.[Doc_Ruta_Web] + 'Orden_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN 13 THEN CD.[Doc_Ruta_Web] + 'Pol_PC_' + EN.Folio_Operacion +  CD.[Doc_Extencion]
																						WHEN 14 THEN CD.[Doc_Ruta_Web] + 'Pol_PT_' + EN.Folio_Operacion + CD.[Doc_Extencion]
																						WHEN 15 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																						WHEN 20 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + ISNULL((SELECT rfc_receptor 
																																												+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																												+ '/' + ISNULL(rfc_emisor,'xxxxx') + '_' + 
																																												CASE folio 
																																													WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																													ELSE  LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																												END
																																												+ '.pdf'
																																										   FROM PPRO_DATOSFACTURAS 
																																										  WHERE [folioorden] = EN.Folio_Operacion
																																											AND [tipoDocumento] = 1 --Factura
																																										  ),(SELECT rfc_receptor 
																																												+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																												+ '/' + ISNULL(rfc_emisor,'xxxxx') + '_' + 
																																												CASE folio 
																																													WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																													ELSE  LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																												END
																																												+ '.pdf'
																																										   FROM PPRO_DATOSFACTURAS 
																																										  WHERE [folioorden] = @folioPlanPiso    --EN.Folio_Operacion
																																											AND [tipoDocumento] = 1 --Factura
																																										  ))
																						---------
																						WHEN 10 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + ISNULL((SELECT rfc_receptor 
																																													+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																													+ '/' + rfc_emisor + '_' + 
																																													CASE folio 
																																														WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																														ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																													END
																																													+ '.pdf'
																																												FROM PPRO_DATOSFACTURAS 
																																												WHERE [folioorden] = EN.Folio_Operacion
																																												AND [tipoDocumento] = 2 --Nota de Credito
																																												),(SELECT rfc_receptor 
																																													+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																													+ '/' + rfc_emisor + '_' + 
																																													CASE folio 
																																														WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																														ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																													END
																																													+ '.pdf'
																																												FROM PPRO_DATOSFACTURAS 
																																												WHERE [folioorden] =  @folioPlanPiso  --EN.Folio_Operacion
																																												AND [tipoDocumento] = 2               --Nota de Credito
																																												))
																						---------
																						ELSE 'http://192.168.20.89/GA_Centralizacion/CuentasXPagar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.' + ED.Doc_Extencion --ISNULL(CD.[Doc_Extencion],'.pdf')
																					END
											  END AS existeDoc
										 ,D.Orden 	                                  AS orden
										 ,CD.Doc_NomCto COLLATE Modern_Spanish_CI_AS  AS tipo
										 ,1                                           AS estatusDoc
								FROM     dbo.DIG_PERFIL_DOCUMENTO   AS PD LEFT JOIN
										 dbo.DIG_CATDOCUMENTO       AS CD ON PD.Doc_Id = CD.Doc_Id LEFT JOIN
										 dbo.DIG_EXPEDIENTE         AS E LEFT JOIN
										 dbo.DIG_ESTATUS_EXPEDIENTE AS EE ON E.Estatus_Id = EE.Estatus_Id LEFT JOIN
										 dbo.DIG_EXP_NODO           AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion LEFT JOIN
										 dbo.DIG_EXPNODO_DOC        AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id 
										 INNER JOIN dbo.DIG_NODO_DOC AS D ON ED.Doc_Id = D.Doc_Id AND ED.Nodo_Id = D.Nodo_Id
										 LEFT JOIN
										 dbo.DIG_NODO               AS N  ON EN.Proc_Id = N.Proc_Id AND EN.Nodo_Id = N.Nodo_Id LEFT JOIN
										 dbo.DIG_NODOPERFIL         AS NP ON N.Proc_Id = NP.Proc_Id AND N.Nodo_Id = NP.Nodo_Id ON PD.Doc_Id = ED.Doc_Id
								WHERE EN.Nodo_Id = @idNodo 
									AND (EN.Folio_Operacion = @folio OR EN.Folio_Operacion IN ( 
											SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
										  ) )
									AND PD.Perfil_Id = @idperfil
							   --ORDER BY D.Orden	
							   )) AS T 
                     ORDER BY T.orden  
					
			    END
			END
		END
    
	END --FIN CXP
	---------------------------------------------------------------------------------------------------------------------------
	--   Tipo de Proceso 2.-CXC Cuentas Por Cobrar 
	---------------------------------------------------------------------------------------------------------------------------
	ELSE IF(@idProceso = 2)
	BEGIN
	IF (@idNodo <= 6 )  --Orden Activa o Inactiva pero detenida en otro nodos
		BEGIN
		      PRINT 'QUERY SENCILLO CXC: ' + cast(@idNodo as varchar)
			  SELECT  DISTINCT E.Proc_Id                                                    as idProceso
								, EN.Nodo_Id												   as idNodo
								, N.Nodo_Nombre COLLATE Modern_Spanish_CI_AS                   as nombreNodo
								, EN.Folio_Operacion COLLATE Modern_Spanish_CI_AS              as folio
								, UPPER(CD.Doc_Nombre) COLLATE Modern_Spanish_CI_AS            as nombreDocumento
								, CD.Doc_Id                                                    as idDocumento
								, CD.Doc_Origen COLLATE Modern_Spanish_CI_AS                   as origen
								, UPPER(CD.Doc_Descripcion) COLLATE Modern_Spanish_CI_AS       as descripcion
								, PD.Perfil_Id                                                 as idPerfil
								, cast(PD.Consultar as int)                                    as consultar
								, cast(PD.Imprimir as int)                                     as imprimir
								, cast(PD.Enviar_Email  as int)                                as enviarEmail
								, cast(PD.Descargar as int)                                    as descargar
								, cast(PD.Cargar as int)                                       as cargar
								, EE.Estatus_Nombre COLLATE Modern_Spanish_CI_AS               as estatusNombre
								, EN.Nodo_Estatus_Id                                           as idEstatus
								, CASE WHEN CD.Doc_Origen = 1 THEN  @origen1 --+ dbo.OBTIENE_RUTA_FN(@folio, @idNodo, CD.Doc_Id)
								ELSE '' END AS Ruta
								,CASE WHEN ED.Fecha_Creacion is null THEN ''
										WHEN ED.Fecha_Creacion is not null THEN --'Si'
																			CASE CD.Doc_Id   
																				WHEN 28 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXCobrar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																				WHEN 29 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXCobrar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																				WHEN 30 THEN 'http://192.168.20.89/GA_Centralizacion/CuentasXCobrar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf'
																				WHEN 20 THEN 'http://192.168.20.89/GA_Centralizacion/FacturasProveedores/' + (SELECT rfc_receptor 
																																									+ '/' + CONVERT(VARCHAR(4),YEAR(fecha_factura)) + '_' + SUBSTRING(CONVERT(nvarchar(6),fecha_factura, 112),5,2)
																																									+ '/' + rfc_emisor + '_' + 
																																									CASE folio 
																																										WHEN '' THEN  dbo.splitCadena_fn(uuid,'-',0,1)  
																																										ELSE LTRIM(RTRIM(serie)) + LTRIM(RTRIM(folio)) 
																																									END
																																									+ '.pdf'
																																								FROM PPRO_DATOSFACTURAS 
																																								WHERE [folioorden] = EN.Folio_Operacion
																																								  AND [tipoDocumento] = 1 --Factura
																																								)
																				ELSE 'http://192.168.20.89/GA_Centralizacion/CuentasXCobrar/Cargas/' + EN.Folio_Operacion + '/' + CONVERT(VARCHAR(5),CD.Doc_Id) + '.pdf' -- '.' + ED.Doc_Extencion --ISNULL(CD.[Doc_Extencion],'.pdf')
																			END
										END AS existeDoc
									,D.Orden 	                                  AS orden
									,CD.Doc_NomCto COLLATE Modern_Spanish_CI_AS  AS tipo
									,CASE WHEN EXISTS(
															SELECT [estatus]--[folioorden]--
																FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]  
																WHERE [folioorden] = @folio
																AND [estatus] = 2
														)
														THEN 2
														ELSE 1 
									END                                          AS estatusDoc
						   FROM     dbo.DIG_PERFIL_DOCUMENTO   AS PD LEFT JOIN
									dbo.DIG_CATDOCUMENTO       AS CD ON PD.Doc_Id = CD.Doc_Id LEFT JOIN
									dbo.DIG_EXPEDIENTE         AS E LEFT JOIN
									dbo.DIG_ESTATUS_EXPEDIENTE AS EE ON E.Estatus_Id = EE.Estatus_Id LEFT JOIN
									dbo.DIG_EXP_NODO           AS EN ON E.Proc_Id = EN.Proc_Id AND E.Folio_Operacion = EN.Folio_Operacion LEFT JOIN
									dbo.DIG_EXPNODO_DOC        AS ED ON EN.Folio_Operacion = ED.Folio_Operacion AND EN.Proc_Id = ED.Proc_Id AND EN.Nodo_Id = ED.Nodo_Id 
									----
									INNER JOIN  Centralizacionv2.dbo.DIG_DOC_TIPO_VENTA AS DT ON DT.Doc_Id = ED.Doc_Id AND DT.Tip_Id = (SELECT Tip_Id
																																		  FROM Centralizacionv2.dbo.DIG_CAT_TIPO_VENTA AS T
																																			   INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal AS O 
																																			   ON O.ucu_foliocotizacion COLLATE Modern_Spanish_CI_AS = @folio AND T.Tip_Clave = O.ucu_idtipoventa COLLATE Modern_Spanish_CI_AS
																																	    )
									----
									INNER JOIN dbo.DIG_NODO_DOC AS D ON DT.Doc_Id = D.Doc_Id AND ED.Nodo_Id = D.Nodo_Id
									LEFT JOIN
									dbo.DIG_NODO               AS N  ON EN.Proc_Id = N.Proc_Id AND EN.Nodo_Id = N.Nodo_Id LEFT JOIN
									dbo.DIG_NODOPERFIL         AS NP ON N.Proc_Id = NP.Proc_Id AND N.Nodo_Id = NP.Nodo_Id ON PD.Doc_Id = ED.Doc_Id
						WHERE EN.Nodo_Id = @idNodo 
							AND (EN.Folio_Operacion = @folio OR EN.Folio_Operacion IN ( 
									SELECT Folio_Operacion FROM dbo.DIG_EXP_PLAN_PISO WHERE Folio_Alias = @folio
									) )
							AND PD.Perfil_Id = @idperfil
						ORDER BY D.Orden
		END
    END --FIN CXC

END
go

