-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez.
-- Create date: 09/07/2018
-- Description:	Recupera el Token de un proveedor
-- ==========================================================================================
-- EXECUTE [PPROV_SEL_RECUPERA_TOKEN_SP] 'EET140204420'    --'MAGA871227TX9'
CREATE PROCEDURE [dbo].[PPROV_SEL_RECUPERA_TOKEN_SP] 
	@rfc VARCHAR(13) = ''
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	
   SELECT  TOP 1 
			idCorreoActivacion
			,token
			,per_rfc
			,fechaCreacion
			,fechaActivacion
			,idEstatus
   FROM [Proveedores].[dbo].[CorreoActivacion]
	  WHERE [per_rfc] = @rfc
   ORDER BY [fechaCreacion] DESC

END TRY
BEGIN CATCH
	Print('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_RECUPERA_TOKEN_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	--SELECT 1
END CATCH
END
go

