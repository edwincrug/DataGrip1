-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--TEST [expedienteSeminuevo].[DEL_DOCUMENTO_SP] 1, 'JM1BM1K31F1244253'
-- =============================================
CREATE PROCEDURE [expedienteSeminuevo].[DEL_DOCUMENTO_SP]
	@idDocumento INT,
	@vin VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;
	IF( @idDocumento = 2 OR @idDocumento = 1 )
		BEGIN
			DECLARE @idExpediente INT, @doc_varios INT, @nombreDocumento VARCHAR(100), @ruta VARCHAR(500);

			SELECT @idExpediente = id_expediente FROM [expedienteSeminuevo].[expedientes] WHERE exp_vin = @vin

			SELECT @doc_varios = doc_varios FROM [expedienteSeminuevo].[cat_documentos] WHERE id_documento = @idDocumento

			SELECT @nombreDocumento = nombreDocumento FROM [expedienteSeminuevo].[documentosExpediente] WHERE id_expediente = @idExpediente AND id_documento = @idDocumento

			SELECT @ruta = (par_valor + CONVERT(VARCHAR(50), @idExpediente) + '\\CXP\\' + @nombreDocumento) FROM [expedienteSeminuevo].[parametros] WHERE par_nombre = 'SAVE_IMG'

			DELETE FROM [expedienteSeminuevo].[documentosExpediente] WHERE id_expediente = @idExpediente AND id_documento = @idDocumento;

			SELECT @ruta rutaDocumento;
		END
	ELSE
		BEGIN
			SELECT @ruta rutaDocumento;
		END
END

go

