CREATE PROCEDURE [dbo].[SEL_TIPOS_CORREOS__SP]
AS
BEGIN
	SELECT 0 as idtipoCorreo,'Elije una opción' as descripcion
		  UNION	 
	SELECT idtipoCorreo, descripcion FROM TipoCorreo
	--SELECT * FROM TipoCorreo
END
go

