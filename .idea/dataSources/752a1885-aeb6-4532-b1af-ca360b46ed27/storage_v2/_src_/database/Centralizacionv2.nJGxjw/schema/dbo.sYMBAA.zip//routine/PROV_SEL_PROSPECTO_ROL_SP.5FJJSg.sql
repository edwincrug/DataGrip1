

CREATE PROCEDURE [dbo].[PROV_SEL_PROSPECTO_ROL_SP] 

		    @idProspecto INT
  
          

AS
BEGIN
		SELECT  	 idProspectoRol
				,idProspecto
				,rol
				,[nombreRol]
				,E.emp_nombre
		FROM	[dbo].[PROV_PROSPECTO_ROL] PP
		INNER	JOIN ControlAplicaciones.dbo.cat_empresas E ON PP.empresaId = E.emp_idempresa
		WHERE idProspecto =@idProspecto 		

END


go

