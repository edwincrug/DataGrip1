--select * from dbo.PROv_PROSpecto
CREATE procedure [dbo].[PROV_ENVIA_NOTIFICACION_TESORERIA_SP]
 @idProspecto INT  
,@idUsuario INT  
,@idPerTra INT 
AS


BEGIN
--DECLARE  @idProspecto INT  = 48
--		  ,@idUsuario INT  = 71
--		  ,@idPerTra INT = 99



BEGIN TRANSACTION
BEGIN TRY
			DECLARE @cont INT = 1
					,@idRespuesta   NUMERIC(18,0)
					,@msg VARCHAR(MAX) = ''
					,@cuenta VARCHAR(500)
					,@rfc VARCHAR(15) = (SELECT PER_RFC FROM  CentralizacionV2.[dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto)
					,@empresaId INT = (SELECT empresaId FROM  CentralizacionV2.[dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto)
					,@portal INT = 0
					,@sql VARCHAR(max)
					,@bd VARCHAR(100)
					,@idPersona NUMERIC(18,0)
					,@usuario VARCHAR(10)
					,@usuarioCorreoAutoriza VARCHAR(250)
					,@cuentaBancaria VARCHAR (MAX) = ''
			        ,@ip VARCHAR(20) = (SELECT  local_net_address    FROM sys.dm_exec_connections    WHERE Session_id = @@SPID ) 
					,@link VARCHAR(250)
					,@usuario_Autoriza INT
		
			DECLARE @tblCuentas AS TABLE ( id INT IDENTITY(1,1),cuenta VARCHAR(MAX))

			SELECT @portal = portal FROM  CentralizacionV2.[dbo].[PROV_PROSPECTO] WHERE PER_IDPERSONA = @idProspecto
			

		
			INSERT INTO @tblCuentas 
			SELECT  Distinct 'Proveedor: '+ ISNULL(PER_NOMRAZON,'')+' '+ ISNULL(PER_PATERNO,'')+ ' '+ ISNULL(PER_MATERNO,'') + ' RFC : '+ ISNULL(PER_RFC,'')
			FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
			INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_rfc  = CB.rfcProspecto
			WHERE   PP.PER_RFC = @rfc AND CB.idPertra = @idPerTra
			union all
			SELECT  Distinct 'Proveedor: '+ ISNULL(PER_NOMRAZON,'')+' '+ ISNULL(PER_PATERNO,'')+ ' '+ ISNULL(PER_MATERNO,'') + ' RFC : '+ ISNULL(PER_RFC,'')
			FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
			INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_IDPERSONA  = CB.idProspecto
			WHERE   PP.PER_IDPERSONA = @idProspecto AND CB.idPerTra = @idPerTra


			INSERT INTO @tblCuentas 
			SELECT  'Banco: '+ banco +  ' No. cuenta: ' + noCuenta + ' Tipo de cuenta: ' + nombreTipoCtaBancaria + ' Titular Cuenta: ' + titular	+ ' CONVENIO CIE: ' + isnull(cie,'') + ' CLABE: ' + isnull(clabe,'')
			FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
			INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_rfc  = CB.rfcProspecto 
			WHERE   PP.PER_RFC = @rfc AND CB.idPertra = @idPerTra
			union all
			SELECT 'Banco: '+ banco +  ' No. cuenta: ' + noCuenta + ' Tipo de cuenta: ' + nombreTipoCtaBancaria + ' Titular Cuenta: ' + titular	+ ' CONVENIO CIE: ' + isnull(cie,'') + ' CLABE: ' + isnull(clabe,'')
			FROM CentralizacionV2.[dbo].[PROV_CUENTA_BANCARIA] CB 
			INNER JOIN CentralizacionV2.[dbo].[PROV_PROSPECTO] PP ON PP.PER_IDPERSONA  = CB.idProspecto
			WHERE   PP.PER_IDPERSONA = @idProspecto AND CB.idPerTra = @idPerTra

			--select * from @tblCuentas

			WHILE(@cont <= (SELECT count(1) FROM @tblCuentas)  )
			BEGIN
					SELECT @msg= @msg +' '+ cuenta + '<br/>'  FROM @tblCuentas where id =@cont
					SET @cont = @cont + 1 
			END
    
			SELECT  @cuentaBancaria =  cuenta
			FROM @tblCuentas where id = 2


		
			SELECT	 @usuario_Autoriza= usuario_autoriza
						,@usuarioCorreoAutoriza = usu_correo 
			FROM	Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION N 
			INNER JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT F ON N.idTipoNotificacion = F.idTipoNotificacion
			INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON U.usu_idusuario = F.usuario_autoriza
			WHERE	N.idTipoNotificacion = 4 
			AND		nivel_escalamiento = 0



		IF(@usuarioCorreoAutoriza = 'NA' OR @usuarioCorreoAutoriza = '' )
		BEGIN
			SELECT -2 result, '' as rfc,  '' correo, '' token,'' correoAutorizaCuentas
		END
		ELSE
		BEGIN
			IF(@ip != '192.168.20.29')
			BEGIN
				--SET @ip = 'localhost'
				--SET @link = 'http://'+ @ip+':1200/aprobar?employee=88&idTramite='+CONVERT(VARCHAR(10),@idPerTra)
				SET @link = 'http://'+ @ip+':4010/aprobar?employee='+CONVERT(VARCHAR(10),@usuario_Autoriza)+'&idTramite='+CONVERT(VARCHAR(10),@idPerTra)
			END 
			ELSE
			BEGIN
				SET @link = 'http://192.168.20.89:4010/aprobar?employee='+CONVERT(VARCHAR(10),@usuario_Autoriza)+'&idTramite='+CONVERT(VARCHAR(10),@idPerTra)
			END

			EXEC Notificacion.[dbo].[INS_NOTIFICACION_OUTPUT_SP] @rfc,@msg,@usuario_Autoriza,4,@empresaId,null,@link,@idPerTra , @result = @idRespuesta OUTPUT
			IF(@idRespuesta = -1)
			BEGIN
			   --Provocamos el error  para enviar al catch y hacer  rollback si es que el stored de INS_ESCALAMIENTO_SP nos devuelve un error
				SELECT 1/0
			END

			if(@portal = 1)
			BEGIN
				SELECT	1 result
					,ppro_user as rfc
					,PP.correo
					,'' token 
					,@usuarioCorreoAutoriza correoAutorizaCuentas
					,@cuentaBancaria    cuentaBancariaProveedor
					,@idPersona idPersona
					,@portal portal
				FROM CentralizacionV2.dbo.PPRO_USERSPORTALPROV PP 
				INNER JOIN  CentralizacionV2.[dbo].[PROV_PROSPECTO] P ON PP.ppro_user = P.PER_RFC
				WHERE PER_IDPERSONA = @idProspecto 
			END
			ELSE
			BEGIN 
				SELECT	1 result
					,ppro_user as rfc
					,PP.correo
					,CA.token 
					,@usuarioCorreoAutoriza correoAutorizaCuentas
					,@cuentaBancaria    cuentaBancariaProveedor
					,@idPersona idPersona
					,@portal portal
				FROM CentralizacionV2.dbo.PPRO_USERSPORTALPROV PP 
				LEFT JOIN [Proveedores].[dbo].[CorreoActivacion] CA ON CA.per_rfc = ppro_user
				LEFT JOIN  CentralizacionV2.[dbo].[PROV_PROSPECTO] P ON P.token = CA.token
				WHERE PER_IDPERSONA = @idProspecto 

			END
		
		
			

		END

COMMIT TRANSACTION				
END TRY
BEGIN CATCH

ROLLBACK TRANSACTION

--SELECT ERROR_MESSAGE()
SELECT -1 result, '' as rfc,  '' correo, '' token,'' correoAutorizaCuentas, 0 portal

END CATCH

			
END



go

