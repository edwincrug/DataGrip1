CREATE PROCEDURE [dbo].[PPRO_UPDATEDATOS_USER_REGISTRO]     --  [dbo].[PPRO_UPDATEDATOS_USER_REGISTRO]  'CMI950920TR8','CRA130717JE6','C','49055',42212.59,'4f289c8f-9886-4e7f-8d5d-ea07f9a9c17b','30/11/2015','MARJ820822PG3','AU-AUA-ZAR-UN-PF-39'
@razonSocial VARCHAR(max) = '',
@rfc VARCHAR(50),
@correo VARCHAR(150),
@contrasena VARCHAR(50),
@confirmarContrasena VARCHAR(30)

AS

SET NOCOUNT ON	

	--DECLARE @id smallint
	--DECLARE @per_idpersona SMALLINT


	IF(EXISTS (SELECT top 1 rfc FROM PPRO_USERSPORTALPROV_REG WHERE rfc= @rfc))
  BEGIN
      UPDATE PPRO_USERSPORTALPROV_REG SET razonSocial= @razonSocial,correo=@correo,contrasena=@contrasena,confirmarContrasena=@confirmarContrasena
	         WHERE rfc= @rfc

       IF( EXISTS (SELECT TOP 1 ppro_user from PPRO_USERSPORTALPROV where ppro_user= @rfc))
	   BEGIN
			UPDATE PPRO_USERSPORTALPROV SET ppro_pass=@contrasena where ppro_user=@rfc
	   END 
  END

SET NOCOUNT OFF


go

