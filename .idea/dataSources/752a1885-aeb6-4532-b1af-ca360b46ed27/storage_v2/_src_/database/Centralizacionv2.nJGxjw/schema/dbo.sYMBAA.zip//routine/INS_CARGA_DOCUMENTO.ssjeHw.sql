--EXECUTE [INS_CARGA_DOCUMENTO] 'AU-ZM-ZAR-SE-PE-27',15,1,1,2,1,'C:/Desarrollo/Central/centralizacion/app/uploads/Ejemplo.pdf'
--EXECUTE [INS_CARGA_DOCUMENTO] 'AU-AU-UNI-OT-PE-2073',15,1,1,7,1,'E:\Bis\Central\centralizacion-v2\app\uploads\Ejemplo.pdf' 
CREATE PROCEDURE [dbo].[INS_CARGA_DOCUMENTO]
	@folio		nvarchar(50) = '' --se tomara para crear la estructura de carpetas   
	,@idDocumento	int = 0 --se concatenara al final del nombre, despues del _
	,@idPerfil		int = 0
	,@idProceso		int = 0
	,@idNodo		int = 0
	,@idUsuario		int = 0
	,@ruta	nvarchar(500) = '' --Ruta donde se guardo el documento y de donde hay que copiarlo a la ruta final (incluye el nombre de archivo)
AS
BEGIN

	--LQMA 11052017
	INSERT INTO BITACORA_PROCESOS
	VALUES (1,'INS_CARGA_DOCUMENTO O: ' + @folio + ', idDoc: ' + CONVERT(VARCHAR(5),@idDocumento) + ', idProceso: ' + CONVERT(VARCHAR(5),@idProceso),GETDATE())
	
	SET NOCOUNT ON;
	BEGIN TRY
	--BEGIN TRAN
	--Copiar el archivo en el directorio según su folio.
	declare @comando varchar(500), @comando1 varchar(500), @comando2 varchar(500)
	-- Mostrar los archivos en el directorio
	DECLARE @CommandShell TABLE (Line VARCHAR(512));
	DECLARE @CMD       VARCHAR(512);
	DECLARE @cuenta		int;
	DECLARE @DocNombre VARCHAR(50);
	DECLARE @nruta	   VARCHAR(500) = '';
	DECLARE @archivo	VARCHAR(150) = '';
	DECLARE @path1	VARCHAR(256), @path2	VARCHAR(256), @nomarchivo VARCHAR(256)	
	
	--LQMA 11/012016 BEGIN
	DECLARE @extencion VARCHAR(10) = ''	
	DECLARE @rutaFolio VARCHAR(50) = ''
	DECLARE @nombreArchivoFolio VARCHAR(50) = ''
	SELECT @rutaFolio = dbo.splitCadena_fn(@folio,'-',3,0)
	SELECT @nombreArchivoFolio = SUBSTRING(@folio,LEN(@rutaFolio),100)
	print @nombreArchivoFolio
	SELECT @rutaFolio = SUBSTRING(@rutaFolio,1,LEN(@rutaFolio) - 1)	

	--LQMA 11/012016 END
	-- la nueva ruta debe contener \ en ves de / 
	SET @ruta = REPLACE(@ruta,'/','\')	
	SET @archivo = RIGHT(@ruta, CHARINDEX('\', REVERSE(@ruta)) - 1)
	--LQMA
	IF @idProceso=1
	BEGIN
		SET @nruta = 'E:\GA_Centralizacion\CuentasXPagar\Cargas\' + @folio --@rutaFolio
	END
	ELSE IF @idProceso=2
	BEGIN
		SET @nruta = 'E:\GA_Centralizacion\CuentasXCobrar\Cargas\' + @folio --@rutaFolio
	END
	
	
	SELECT @extencion = RIGHT(@archivo, CHARINDEX('.', REVERSE('.' + @archivo)) - 1) --extencion
	SELECT @nombreArchivoFolio = CONVERT(VARCHAR(10),@idDocumento) + '.' + @extencion--SUBSTRING(@nombreArchivoFolio,1,LEN(@nombreArchivoFolio) - 1) + '_' + CONVERT(VARCHAR(10),@idDocumento) + '.' + @extencion
	SET @nombreArchivoFolio = SUBSTRING(@nombreArchivoFolio,2,100)
	
	print ('Ruta parametro: ' + @ruta)
	print ('Nueva Nruta: ' + @nruta)
	print ('Nueva nomArchivo: ' + @nomarchivo)
	print ('Nueva nombreArchivoFolio: ' + @nombreArchivoFolio)
	print @nruta
	print @nomarchivo
	print @nombreArchivoFolio
	

	SET @CMD = 'DIR ' + @nruta
	print @CMD

	--INSERT INTO @CommandShell EXEC MASTER..xp_cmdshell @CMD , no_output
	--SELECT @cuenta = COUNT(Line) FROM @CommandShell WHERE Line IS NOT NULL
	--print @cuenta
	--IF @cuenta > 4
	--BEGIN
	--	-- el directorio ya existe, se hace la copia directa
	--	    print ('A) El directorio existe, se hace la copia directa')
	--		set @comando = 'move /Y "' + @ruta + '" "' + @nruta +  '\' + @nombreArchivoFolio + '"' -- @nomarchivo
	--		print @comando
	--		EXEC MASTER..xp_cmdshell @comando, no_output
	--		print ('copia directa')
	--END
	--ELSE
	--BEGIN
	---- El directorio no existe, primero se crea, después se copia
	--        print ('B) El directorio NOOOO existe, primero se crea, después se copia')
	--		set @comando1 = 'md  ' + @nruta
	--		print @comando1
	--		EXEC MASTER..xp_cmdshell @comando1,no_output
	--		print ('acabo de hacer el directorio')
	--		set @comando2 = 'move /Y "' + @ruta + '" "' + @nruta + '\' + @nombreArchivoFolio +'"' --@nomarchivo
	--		print @comando2
	--		EXEC MASTER..xp_cmdshell @comando2,no_output
	--		print ('acabo de mover el archivo despues de crear el directorio')
	--		print @nruta + '\' + @nomarchivo
	--END
	--05022016 LQMA 

	IF(@idDocumento <> 15)
		BEGIN
			UPDATE DIG_EXPNODO_DOC SET [Fecha_Creacion] = GETDATE(), [Doc_Extencion] = @extencion
					WHERE [Folio_Operacion] = @folio
					AND   [Doc_Id] = @idDocumento
					AND   [Proc_Id] = @idProceso			
		END	
	ELSE
		BEGIN
				UPDATE DIG_EXPNODO_DOC SET [Fecha_Creacion] = GETDATE(), [Doc_Extencion] = @extencion
					WHERE [Folio_Operacion] = @folio
					AND   [Doc_Id] = @idDocumento
					AND   [Proc_Id] = @idProceso			
		END
	--COMMIT TRAN
		SELECT 0 
				
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_CARGA_DOCUMENTO'
	SELECT @Mensaje = ERROR_MESSAGE()
	--ROLLBACK TRAN
	return EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	 SELECT @@IDENTITY
END CATCH  

END
go

