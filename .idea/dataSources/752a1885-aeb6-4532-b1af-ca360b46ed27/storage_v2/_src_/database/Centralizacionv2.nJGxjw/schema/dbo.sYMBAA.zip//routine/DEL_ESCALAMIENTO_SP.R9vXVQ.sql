-- =============================================
-- Author: Genaro Mora Valencia
-- Create date: 14/12/2015
-- Description:	Procedimiento para eliminar los escalamientos.
-- =============================================
-- [DEL_ESCALAMIENTO_SP] 1,1,1,3,13,1,0,7,2,3 
CREATE PROCEDURE [dbo].[DEL_ESCALAMIENTO_SP]
	 @escalamientoId INT
				
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	

			DELETE FROM dbo.[DIG_ESCALAMIENTO]	
			WHERE escalamientoId = @escalamientoId				
			SELECT 0	  
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[DEL_ESCALAMIENTO_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT ERROR_NUMBER()
END CATCH
END

go

