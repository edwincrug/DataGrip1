-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 07/12/2016
-- Description: Regresa Serie, Folio y RFCEmisor
-- ==========================================================================================
-- EXECUTE [SEL_FACTUTA_CXC_SP] @folio = 'AU-ZM-ZAR-UN-53'
CREATE PROCEDURE [dbo].[SEL_FACTUTA_CXC_SP] 
	@folio    NVARCHAR(50) = ''
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY

	DECLARE @idCotizacion   INT = 0;
	DECLARE @idEmpresa      INT = 0;
	DECLARE @idSucursal      INT = 0;
		
		SELECT @idCotizacion  = ucu_idcotizacion 
		       ,@idEmpresa    = ucu_idempresa
			   ,@idSucursal   = ucu_idsucursal
		  FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
		 WHERE ucu_foliocotizacion = @folio
		 
		SELECT ucn_idFactura                                  AS idFactura
		       ,(SELECT dbo.[fn_BuscaLetras](ucn_idFactura))  AS serie
			   ,(SELECT dbo.[fn_BuscaNumeros](ucn_idFactura)) AS folio
			   ,(SELECT rfc 
			       FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO
				  WHERE catsuc_nombrecto = 'CONCENTRA'
                    and emp_idempresa = @idEmpresa)           AS rfcEmisor
		  FROM [cuentasporcobrar].[dbo].[UNI_COTIZACIONUNIVERSALUNIDADES]
         WHERE ucu_idcotizacion  = @idCotizacion 
		   --AND ucn_situacionfact = 18 --Situacion de la Orden

	END TRY

	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_FACTUTA_CXC_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END


go

