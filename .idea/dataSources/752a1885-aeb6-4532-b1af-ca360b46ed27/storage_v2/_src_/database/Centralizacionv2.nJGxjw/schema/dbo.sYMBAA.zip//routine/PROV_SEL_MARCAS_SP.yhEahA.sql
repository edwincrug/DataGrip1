CREATE PROCEDURE [dbo].[PROV_SEL_MARCAS_SP]
AS
BEGIN
	SELECT	 emp_idempresa
			,emp_nombre
			,emp_nombrebd 
	FROM	ControlAplicaciones.dbo.cat_empresas 
	WHERE	emp_idempresa != 0
END


go

