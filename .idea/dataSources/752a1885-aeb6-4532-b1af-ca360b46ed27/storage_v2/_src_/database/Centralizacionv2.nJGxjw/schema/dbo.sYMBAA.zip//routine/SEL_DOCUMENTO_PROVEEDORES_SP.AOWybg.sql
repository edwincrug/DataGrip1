-- =============================================
-- Author:		Alejandro Lopez
-- Create date: 13/05/2016
-- Description:	Obtiene rutas de documentos XML y PDF cargados en portal de Proveedores
-- =============================================
--EXECUTE [dbo].[SEL_DOCUMENTO_PROVEEDORES_SP] 'AU-AUA-VIG-UN-PF-21'

CREATE PROCEDURE [dbo].[SEL_DOCUMENTO_PROVEEDORES_SP]
	 @OC  VARCHAR(50) = ''
AS
BEGIN

	SET NOCOUNT ON;
	BEGIN TRY 
		
		SELECT 
			'\' + 
			rfc_receptor + 
			'\' + 
			CONVERT(VARCHAR(4),DATEPART(yyyy,fecha_factura))+
			'_'+
			RIGHT('00' + Ltrim(Rtrim(CONVERT(VARCHAR(2),DATEPART(mm,fecha_factura)))),2) +
			'\' + 
			rfc_emisor + 
			'_' + 
			case when serie <> '' then REPLACE (REPLACE(serie, '+', ''),'/','') else '' end + 
			REPLACE (REPLACE(folio, '+', ''),'/','')
		FROM 
			PPRO_DATOSFACTURAS 
		WHERE 
			folioorden = @OC
											
	END TRY
	
	BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_DOCUMENTO_PROVEEDORES_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

