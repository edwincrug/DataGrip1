-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SEL_DICCIONARIO_NODO_Y_STATUS_SP
	@tipo INT
   ,@proceso INT
AS
BEGIN
	IF @tipo=1
		SELECT
			 PR.[Proc_Nombre]AS proceso
			,ND.[Nodo_Nombre] AS nombre
			,ND.[Nodo_Id] AS nodo
			,ND.[Nodo_Descripcion] AS descripcion
		FROM [Centralizacionv2].[dbo].[DIG_NODO] ND
		LEFT JOIN [dbo].[DIG_PROCESO] PR ON PR.Proc_Id=ND.Proc_Id
		WHERE ND.Proc_Id=@proceso
	ELSE
		IF @proceso=1
			SELECT 
				 [sod_idsituacionorden] AS id
				,[sod_nombresituacion] AS nombreSit
				,[sod_nombrecto] AS nombreCorto
			FROM  [cuentasxpagar].[dbo].[cat_situacionorden] where [sod_idsituacionorden] <> 0
		ELSE IF @proceso=2
			 SELECT 
			   [cec_idestatuscotiza] AS id
			  ,[cec_nombre] AS nombreSit
			  ,[cec_nombrecorto] AS nombreCorto
			  ,[cec_descripcion] AS descripcion
			 FROM [cuentasporcobrar].[dbo].[cat_estatuscotiza]
END
go

