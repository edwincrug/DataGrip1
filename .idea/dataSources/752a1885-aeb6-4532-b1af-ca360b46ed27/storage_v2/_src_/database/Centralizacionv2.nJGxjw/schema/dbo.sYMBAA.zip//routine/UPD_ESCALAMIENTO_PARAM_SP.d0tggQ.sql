-- =============================================
-- Author: Mario Arturo Mejía Ramírez
-- Create date: 15/12/2015
-- Description:	Procedimiento para Actualizar el Usuario Mancomunado.
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESCALAMIENTO_PARAM_SP]
	 @Escalamiento_Id int
	,@usuario_mancomunado int
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
			UPDATE  [dbo].[DIG_ESCALAMIENTO_PARAMETROS]
					SET		
					[usuario_mancomunado] = @usuario_mancomunado
			WHERE [Escalamiento_Id] = @Escalamiento_Id
			RETURN 1
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[UPD_ESCALAMIENTO_PARAM_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

