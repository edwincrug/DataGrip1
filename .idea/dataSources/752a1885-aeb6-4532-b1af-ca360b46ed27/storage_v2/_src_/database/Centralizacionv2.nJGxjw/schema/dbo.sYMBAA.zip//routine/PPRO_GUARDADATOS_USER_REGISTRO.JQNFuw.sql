CREATE PROCEDURE [dbo].[PPRO_GUARDADATOS_USER_REGISTRO]     --  [dbo].[PPRO_GUARDADATOS_USER_REGISTRO]  'CMI950920TR8','CRA130717JE6','C','49055',42212.59,'4f289c8f-9886-4e7f-8d5d-ea07f9a9c17b','30/11/2015','MARJ820822PG3','AU-AUA-ZAR-UN-PF-39'
@razonSocial VARCHAR(max) = '',
@rfc VARCHAR(50),
@correoUsuario VARCHAR(150),
@contrasena VARCHAR(50)

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
	
	DECLARE @per_idpersona SMALLINT
	DECLARE @msg VARCHAR(500) = '', @estatus VARCHAR(10) = ''

	IF (SELECT LEN (@contrasena))> 10
	BEGIN
	   SET @estatus = 'error'
	   SET @msg ='La contraseña debe ser menor a 10 caracteres'
    END
	ELSE 
	BEGIN
			IF EXISTS(SELECT 1 FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @rfc)
				BEGIN
					IF NOT EXISTS(SELECT 1 FROM PPRO_USERSPORTALPROV WHERE ppro_user = @rfc)
						BEGIN
								INSERT INTO PPRO_USERSPORTALPROV(
									ppro_idUserRol,
									ppro_user,
									ppro_pass,
									pprov_usersStatus,
									razonSocial,
									correo,
									estatus,
									fechaAlta)
								VALUES (					    											
									1,
									@rfc,
									@contrasena,
									2,--pendiente de activar
									@razonSocial,
									@correoUsuario,
									0, 
									GETDATE()
								)

								DECLARE @tokenID uniqueidentifier
								SET @tokenID = NEWID()
					
								INSERT INTO [proveedores].[dbo].[CorreoActivacion]([token],[per_rfc],[fechaCreacion],[fechaActivacion],[idEstatus])
								VALUES (@tokenID,@rfc,GETDATE(),NULL,1)													

								SELECT @estatus = 'ok', @msg ='Proveedor con RFC: ' + @rfc + ' registrado con exito! Se ha enviado un correo para su activación a la dirección ' + @correoUsuario + '.'
						END
					ELSE
						BEGIN
								SELECT @estatus = 'error', @msg ='Proveedor con RFC: ' + @rfc + ' ya existe. No se registro.'
						END
				END
			ELSE
				BEGIN
					SELECT @estatus = 'error', @msg ='Proveedor con RFC: ' + @rfc + ' no existe en el catalogo de proveedores. No se registro.'
				END	
   END
   SELECT @estatus estatus,@msg mensaje
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[PPRO_GUARDADATOS_USER_REGISTRO]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje--@msg

END CATCH
END
go

