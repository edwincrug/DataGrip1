CREATE VIEW VIS_CONCAR01 AS Select '01' as Vcc_Empresa,'2003' as Vcc_Anno,* FROM Con_Car012003
 union all Select '01' as Vcc_Empresa,'2004' as Vcc_Anno,* FROM Con_Car012004
 union all Select '01' as Vcc_Empresa,'2005' as Vcc_Anno,* FROM Con_Car012005
 union all Select '01' as Vcc_Empresa,'2006' as Vcc_Anno,* FROM Con_Car012006
 union all Select '01' as Vcc_Empresa,'2007' as Vcc_Anno,* FROM Con_Car012007
 union all Select '01' as Vcc_Empresa,'2008' as Vcc_Anno,* FROM Con_Car012008
 union all Select '01' as Vcc_Empresa,'2009' as Vcc_Anno,* FROM Con_Car012009
 union all Select '01' as Vcc_Empresa,'2010' as Vcc_Anno,* FROM Con_Car012010
 union all Select '01' as Vcc_Empresa,'2011' as Vcc_Anno,* FROM Con_Car012011
 union all Select '01' as Vcc_Empresa,'2012' as Vcc_Anno,* FROM Con_Car012012
 union all Select '01' as Vcc_Empresa,'2013' as Vcc_Anno,* FROM Con_Car012013
 union all Select '01' as Vcc_Empresa,'2014' as Vcc_Anno,* FROM Con_Car012014
 union all Select '01' as Vcc_Empresa,'2015' as Vcc_Anno,* FROM Con_Car012015
 union all Select '01' as Vcc_Empresa,'2016' as Vcc_Anno,* FROM Con_Car012016
 union all Select '01' as Vcc_Empresa,'2017' as Vcc_Anno,* FROM Con_Car012017
 union all Select '01' as Vcc_Empresa,'2018' as Vcc_Anno,* FROM Con_Car012018
 union all Select '01' as Vcc_Empresa,'2019' as Vcc_Anno,* FROM Con_Car012019
 union all Select '01' as Vcc_Empresa,'2020' as Vcc_Anno,* FROM Con_Car012020
go

