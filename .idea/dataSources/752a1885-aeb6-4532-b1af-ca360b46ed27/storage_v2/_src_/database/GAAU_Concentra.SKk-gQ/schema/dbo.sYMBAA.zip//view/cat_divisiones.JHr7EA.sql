CREATE VIEW [dbo].[cat_divisiones]
AS
SELECT 
div_iddivision, gpo_idgrupo, div_nombre, div_nombrecto, div_fechaalta, div_usualta, div_fechamodifica, div_usumodifica, div_estatus
FROM         [ControlAplicaciones].dbo.cat_divisiones
go

