CREATE VIEW une_estructura
AS 
SELECT * FROM GA_Corporativa.DBO.une_estructura
go

