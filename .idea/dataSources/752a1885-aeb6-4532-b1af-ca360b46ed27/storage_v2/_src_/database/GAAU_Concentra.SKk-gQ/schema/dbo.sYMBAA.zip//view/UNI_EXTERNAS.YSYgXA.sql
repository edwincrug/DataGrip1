CREATE VIEW UNI_EXTERNAS
AS
SELECT * FROM GA_Corporativa.dbo.uni_externas
go

