
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create view [dbo].[VIS_LTPEDIUNI] as 
select 'GAAU_Cuautitlan'  as PEN_BD,[GAAU_Cuautitlan].[dbo].uni_ltpediuni.*  from [GAAU_Cuautitlan].[dbo].uni_ltpedido  inner join [GAAU_Cuautitlan].[dbo].uni_ltpediuni  on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO 
union all
select 'GAAU_Pedregal'     as PEN_BD,[GAAU_Pedregal].[dbo].uni_ltpediuni.*     from [GAAU_Pedregal].[dbo].uni_ltpedido     inner join [GAAU_Pedregal].[dbo].uni_ltpediuni     on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO 
union all
select 'GAAU_Universidad'   as PEN_BD,[GAAU_Universidad].[dbo].uni_ltpediuni.*   from [GAAU_Universidad].[dbo].uni_ltpedido   inner join [GAAU_Universidad].[dbo].uni_ltpediuni   on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO
go

