

-- ==========================================================================================
-- Author:		Fernando Alvarado Luna
-- Create date: 05/01/2018
-- Description:	Selecciona la cartera, 
-- ==========================================================================================
--EXECUTE [SP_BI_CARTERA_PAGOS] 1

CREATE PROCEDURE [dbo].[SP_BI_CARTERA_PAGOS1] 
	     @idEmpresa numeric(18,0) = null

AS
BEGIN

	SET NOCOUNT ON;
	BEGIN TRY	    
	  
	  --busqueda

DECLARE @VariableTablaCARTERA TABLE (ID INT IDENTITY(1,1), pce_id_empresa numeric(18, 0), pce_clave nvarchar(15))
		INSERT INTO @VariableTablaCARTERA (pce_id_empresa,pce_clave)
		SELECT pce_id_empresa,pce_clave FROM [Pagos].[dbo].[PAG_CARTERA_EMPRESA] where pce_id_empresa = @idEmpresa
		DECLARE @totalcartera INT = (SELECT count(*) FROM @VariableTablaCARTERA)	
		DECLARE @auxcartera   INT = 1
		DECLARE @strCartera VARCHAR(max) = '';

				WHILE(@auxcartera <=  @totalcartera)
			BEGIN

			SET @strCartera =  @strCartera + '''' + (SELECT pce_clave FROM @VariableTablaCARTERA WHERE ID = @auxcartera) + '''' + ','

			SET @auxcartera = @auxcartera + 1	

			END

			DECLARE @TamStrCartera int
			SET @TamStrCartera = LEN(@strCartera) - 1

			SET @strCartera =  SUBSTRING(@strCartera, 1, @TamStrCartera)
		
		SELECT 	@strCartera


declare @queryText1 varchar(max) = 
'SELECT Isnull(documento.ccp_tipopol, '+char(39)+''+char(39)+')' + char(13) + 
'       AS' + char(13) + 
'       polTipo,' + char(13) + 
'       documento.vcc_anno' + char(13) + 
'       AS annio,' + char(13) + 
'       Isnull(documento.ccp_mes, 0)' + char(13) + 
'       AS polMes,' + char(13) + 
'       Isnull(documento.ccp_conspol, 0)' + char(13) + 
'       AS polConsecutivo,' + char(13) + 
'       documento.ccp_consmov' + char(13) + 
'       AS polMovimiento,' + char(13) + 
'       Isnull(documento.ccp_fechope, Cast('+char(39)+'1900-01-01 00:00:00'+char(39)+' AS DATETIME))' + char(13) + 
'       AS' + char(13) + 
'       polFechaOperacion,' + char(13) + 
'       documento.ccp_iddocto' + char(13) + 
'       AS documento,' + char(13) + 
'       cartera.par_descrip5' + char(13) + 
'       AS cuenta,' + char(13) + 
'       documento.ccp_idpersona' + char(13) + 
'       AS idProveedor,' + char(13) + 
'       timo.par_descrip1' + char(13) + 
'       AS tipoDocto,' + char(13) + 
'       cartera.par_descrip1' + char(13) + 
'       AS cartera,' + char(13) + 
'       '+char(39)+'monto'+char(39)+' = CASE cartera.par_idmodulo' + char(13) + 
'                   WHEN '+char(39)+'cxc'+char(39)+' THEN ccp_cargo - ccp_abono' + char(13) + 
'                   ELSE ccp_abono - ccp_cargo' + char(13) + 
'                 END,' + char(13) + 
'       CASE cartera.par_idmodulo' + char(13) + 
'         WHEN '+char(39)+'cxc'+char(39)+' THEN ccp_cargo - ccp_abono + (SELECT' + char(13) + 
'                         Isnull(Sum(' + char(13) + 
'                         ccp_cargo - ccp_abono), 0)' + char(13) + 
'                                                  FROM' + char(13) + 
'       vis_concar01 AS movimiento' + char(13) + 
'              WHERE  movimiento.ccp_iddocto = documento.ccp_iddocto' + char(13) + 
'                     AND movimiento.ccp_idpersona =' + char(13) + 
'                         documento.ccp_idpersona' + char(13) + 
'                     AND movimiento.ccp_cartera =' + char(13) + 
'                         documento.ccp_cartera' + char(13) + 
'                     AND movimiento.ccp_docori <> '+char(39)+'s'+char(39)+')' + char(13) + 
'         ELSE ccp_abono - ccp_cargo + (SELECT Isnull(Sum(ccp_abono - ccp_cargo),' + char(13) + 
'                                              0)' + char(13) + 
'                                       FROM' + char(13) + 
'                     vis_concar01 AS' + char(13) + 
'                     movimiento' + char(13) + 
'                                       WHERE  movimiento.ccp_iddocto =' + char(13) + 
'                                              documento.ccp_iddocto' + char(13) + 
'                                              AND movimiento.ccp_idpersona =' + char(13) + 
'                                                  documento.ccp_idpersona' + char(13) + 
'                                              AND movimiento.ccp_cartera =' + char(13) + 
'                                                  documento.ccp_cartera' + char(13) + 
'                                              AND movimiento.ccp_docori <> '+char(39)+'s'+char(39)+')' + char(13) + 
'       END' + char(13) + 
'       AS saldo,' + char(13) + 
'       0' + char(13) + 
'       AS saldoPorcentaje,' + char(13) + 
'       '+char(39)+'moneda'+char(39)+'= CASE' + char(13) + 
'                   WHEN cartera.par_descrip4 IN ( '+char(39)+'PE'+char(39)+', '+char(39)+''+char(39)+' )' + char(13) + 
'                         OR cartera.par_descrip4 NOT IN' + char(13) + 
'                            ( '+char(39)+'DA'+char(39)+', '+char(39)+'DB'+char(39)+', '+char(39)+'DL'+char(39)+', '+char(39)+'PE'+char(39)+' ) THEN' + char(13) + 
'                   '+char(39)+'PE'+char(39)+'' + char(13) + 
'                   ELSE cartera.par_descrip4' + char(13) + 
'                 END,' + char(13) + 
'       documento.ccp_fechven' + char(13) + 
'       AS fechaVencimiento,' + char(13) + 
'       CASE ISDATE(ccp_fechprompag) ' + char(13) +
'			WHEN 1 THEN ccp_fechprompag ' + char(13) +
'			ELSE ' + char(13) +
'				CASE isdate(documento.CCP_FECHVEN) ' + char(13) +
'				WHEN 1 THEN documento.CCP_FECHVEN ' + char(13) +
'				ELSE Cast('+char(39)+'1900-01-01 00:00:00'+char(39)+' AS DATETIME) ' + char(13) +
'			END ' + char(13) +
'       END ' + char(13) +
'       AS fechaPromesaPago,' + char(13) +
'       Isnull(documento.ccp_fechrev, Cast('+char(39)+'1900-01-01 00:00:00'+char(39)+' AS DATETIME))' + char(13) + 
'       AS' + char(13) + 
'       fechaRecepcion,' + char(13) + 
'       documento.ccp_fechadocto' + char(13) + 
'       AS fechaFactura,' + char(13) + 
'     ' + char(13) + 
'       Isnull((SELECT cdp_diascobro' + char(13) + 
'               FROM   cxp_condcred' + char(13) + 
'               WHERE  cdp_idpersona = ccp_idpersona), 30)' + char(13) + 
'       AS diasCobro,' + char(13) + 
'       '+char(39)+'1'+char(39)+'' + char(13) + 
'       AS aprobado,' + char(13) + 
'       '+char(39)+'0'+char(39)+'' + char(13) + 
'       AS contReprog,' + char(13) + 
'       0' + char(13) + 
'       AS aPagar,' + char(13) + 
'       '+char(39)+'BCOEGRESOSEL'+char(39)+'' + char(13) + 
'       AS cuentaPagadora,' + char(13) + 
'       '+char(39)+'BCOEGRESOSEL'+char(39)+'' + char(13) + 
'       AS cuentaProveedor,' + char(13) + 
'       '+ cast (@idEmpresa as varchar(2)) + char(13) + 
'       AS empresa,' + char(13) + 
'	   GETDATE()             as fechaCreacionRegistro,' + char(13) + 
'    (isnull( STUFF((SELECT '+char(39)+', '+ char(39) +'  + REPLACE(ISNULL(ba.par_descrip1, '+char(39)+'CIE'+char(39)+')' +' COLLATE Latin1_General_BIN,' +char(39) + ',' +char(39) + ', ' +char(39)  +char(39) + ' ) +'  +char(39) + '(' + char(39) + ' + BCO_NUMCUENTA +' +char(39)+')'+char(39)+'' + char(13) + 
'    FROM con_bancos     LEFT JOIN pnc_parametr AS ba ON bco_banco = ba.par_idenpara AND ba.par_tipopara = '+char(39)+'ba'+char(39)+'' + char(13) + 
'    WHERE bco_idpersona = documento.ccp_idpersona  ' + char(13) + 
'    AND bco_autorizada = 1 ' + char(13) + 
'    FOR XML PATH('+char(39)+char(39)+')), 1, 2, '+char(39)+char(39)+'), '+ char(39) +'Sin cuenta destino'+ char(39) +')) As cuentaDestino, ' + char(13) + 
'		( Isnull((SELECT TOP 1   BCO_CONVENIOCIE ' + char(13) + 
'                 FROM   con_bancos ' + char(13) + 
'                 WHERE   bco_idpersona = documento.ccp_idpersona AND BCO_CONVENIOCIE <> '+char(39)+''+char(39)+'),' + char(13) + 
'           '+char(39)+''+char(39)+') )' + char(13) + 
'       AS convenioCIE,' + char(13) + 
'	   ccp_conscartera' + char(13) + 
'       AS consCartera,' + char(13) + 
'		CASE WHEN EXISTS(SELECT BCO_AUTORIZADA ' + char(13) + 
'                 FROM   con_bancos ' + char(13) + 
'                 WHERE   bco_idpersona = documento.ccp_idpersona  AND BCO_AUTORIZADA = 1) THEN 1 ' + char(13) + 
'	  ELSE 0 ' + char(13) + 
'	  END  AS pbp_autorizado ' + char(13) + 
' -- tablas' + char(13) + 
'FROM  vis_concar01 AS documento' + char(13) + 
'       INNER JOIN pnc_parametr AS' + char(13) + 
'                  cartera' + char(13) + 
'               ON ccp_cartera = cartera.par_idenpara' + char(13) + 
' ' + char(13) + 
'       LEFT OUTER JOIN pnc_parametr AS' + char(13) + 
'                       timo' + char(13) + 
'                    ON documento.ccp_tipodocto = timo.par_idenpara' + char(13) + 
'                       AND timo.par_tipopara = '+char(39)+'timo'+char(39)+'' + char(13) + 
'		' + char(13) + 
'' + char(13) 
declare @queryText2 varchar(max) =  
'WHERE  ccp_docori = '+char(39)+'s'+char(39)+'' + char(13) + 
'       AND cartera.par_tipopara = '+char(39)+'cartera'+char(39)+'' + char(13) + 
'       AND cartera.par_idmodulo = '+char(39)+'cxp'+char(39)+'' + char(13) + 
'       AND cartera.par_importe5 = 0' + char(13) + 
'       AND documento.ccp_cartera IN(SELECT par_idenpara' + char(13) + 
'                                    FROM' + char(13) + 
'										pnc_parametr' + char(13) + 
'                                    WHERE  par_tipopara = '+char(39)+'cartera'+char(39)+'' + char(13) + 
'                                           AND par_idmodulo = '+char(39)+'cxp'+char(39)+'' + char(13) + 
'                                           AND par_status = '+char(39)+'a'+char(39)+'' + char(13) + 
'                                           AND par_importe4 <> 1' + char(13) + 
'                                           AND par_importe5 = 0)' + char(13) + 
'       AND ( CASE cartera.par_idmodulo' + char(13) + 
'               WHEN '+char(39)+'cxc'+char(39)+' THEN ccp_cargo - ccp_abono + (SELECT' + char(13) + 
'                               Isnull(Sum(' + char(13) + 
'                               ccp_cargo - ccp_abono), 0)' + char(13) + 
'                                                        FROM' + char(13) + 
'												vis_concar01 AS movimiento' + char(13) + 
'                    WHERE  movimiento.ccp_iddocto = documento.ccp_iddocto' + char(13) + 
'                           AND movimiento.ccp_idpersona =' + char(13) + 
'                               documento.ccp_idpersona' + char(13) + 
'                           AND movimiento.ccp_cartera =' + char(13) + 
'                               documento.ccp_cartera' + char(13) + 
'                           AND movimiento.ccp_docori <> '+char(39)+'s'+char(39)+')' + char(13) + 
'               ELSE ccp_abono - ccp_cargo + (SELECT Isnull(Sum(' + char(13) + 
'                                                    ccp_abono - ccp_cargo),' + char(13) + 
'                                                    0)' + char(13) + 
'                                             FROM' + char(13) + 
'                           vis_concar01' + char(13) + 
'                           AS' + char(13) + 
'                           movimiento' + char(13) + 
'                                             WHERE  movimiento.ccp_iddocto =' + char(13) + 
'                                                    documento.ccp_iddocto' + char(13) + 
'                                                    AND movimiento.ccp_idpersona' + char(13) + 
'                                                        =' + char(13) + 
'                                                        documento.ccp_idpersona' + char(13) + 
'                                                    AND movimiento.ccp_cartera =' + char(13) + 
'                                                        documento.ccp_cartera' + char(13) + 
'                                                    AND movimiento.ccp_docori <>' + char(13) + 
'                                                        '+char(39)+'s'+char(39)+')' + char(13) + 
'             END ) <> 0' + char(13) + 
'       AND ccp_tipodocto NOT LIKE '+char(39)+'%iva'+char(39)+'' + char(13) + 
'       AND documento.ccp_cartera IN ( '+ @strCartera +' )' + char(13) + 
'ORDER  BY CONVERT(DATETIME, ccp_fechven, 103) DESC ' + char(13) + 
'' 


	    ---------------------------------------------------------------
		--  Buscamos la  IP del Servidor y  la Base                  --
		---------------------------------------------------------------
		
		select @queryText1 + @queryText2

		DELETE FROM BI_CARTERA_PAGOS
		WHERE pbp_empresa = @idEmpresa

       INSERT INTO BI_CARTERA_PAGOS
					([pbp_polTipo]
					,[pbp_polAnnio]
					,[pbp_polMes]
					,[pbp_polConsecutivo]
					,[pbp_polMovimiento]
					,[pbp_polFechaOperacion]
					--
					,[pbp_documento]
					,[pbp_cuenta]
					,[pbp_idProveedor]
					--
					,[pbp_tipoDocto]
					,[pbp_cartera]
					,[pbp_monto]
					,[pbp_saldo]
					,[pbp_saldoPorcentaje]
					,[pbp_moneda]
					--
					,[pbp_fechaVencimiento]
					,[pbp_fechaPromesaPago]
					,[pbp_fechaRecepcion]
					,[pbp_fechaFactura]
					--
					,[pbp_diasCobro]
					,[pbp_aprobado]
					,[pbp_contReprog]
					,[pbp_aPagar]
					,[pbp_cuentaPagadora]
					,[pbp_cuentaProveedor]
					,[pbp_empresa]
					,[pbp_fechaCreacionRegistro]
					,[pbp_cuentaDestino]
					,[pbp_convenioCIE]
					,[pbp_consCartera]
					,[pbp_autorizado]
					) 
				exec(@queryText1 + @queryText2) 
		
		
			
        SELECT 'INSERCION CORRECTA DE INFORMACION DE BPRO'
   
    END TRY

	BEGIN CATCH
	     SELECT 'ERROR EN LA CONSULTA'
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 DECLARE @Mensaje  nvarchar(max),
		 @Componente nvarchar(50) = '[INS_DE_BPRO_A_PAGOS_SP]'
		 SELECT @Mensaje = ERROR_MESSAGE()
		 
		 SELECT 0 --Encontro error
	END CATCH
END



go

