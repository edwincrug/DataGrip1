CREATE VIEW [dbo].[VIS_movdet01] AS Select '01' as Vmd_Empresa,'2003' as Vmd_Anno,* FROM con_movdet012003

 union all Select '01' as Vmd_Empresa,'2004' as Vmd_Anno,* FROM con_movdet012004

 union all Select '01' as Vmd_Empresa,'2005' as Vmd_Anno,* FROM con_movdet012005

 union all Select '01' as Vmd_Empresa,'2006' as Vmd_Anno,* FROM con_movdet012006

 union all Select '01' as Vmd_Empresa,'2007' as Vmd_Anno,* FROM con_movdet012007
go

