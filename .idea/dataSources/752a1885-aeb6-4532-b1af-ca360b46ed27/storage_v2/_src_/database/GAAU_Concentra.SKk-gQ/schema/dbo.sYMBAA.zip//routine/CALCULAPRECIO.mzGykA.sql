CREATE FUNCTION CALCULAPRECIO(@IDPARTE VARCHAR(40),@TIPOPRECIO VARCHAR(2),@ALMACEN VARCHAR(3),@OPCION AS VARCHAR(1),@PREUNITARIO AS NUMERIC(18,2))
RETURNS NUMERIC(18,2)
AS
-- Returns the stock level for the product.
BEGIN
    DECLARE @PRECIO numeric(18,2)
    DECLARE @TOTAL numeric(18,2)
    DECLARE @CP numeric(18,2)
    DECLARE @CR numeric(18,2)
    DECLARE @PL numeric(18,2)
   declare @Operador as varchar (2)
   Declare @porcentaje as numeric(18)
   DECLARE @TIPOP AS VARCHAR(2)
   SELECT @TIPOP=PAR_DESCRIP2,@Operador=PAR_DESCRIP3,@porcentaje= PAR_IMPORTE1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'RP' AND PAR_IDENPARA = @TIPOPRECIO
    SELECT @CP = ALM_CTOPROM,@CR = PTS_CUNREPO,@PL = PTS_PCOLISTA FROM PAR_PARTES INNER JOIN PAR_ALMACEN ON ALM_IDPARTE=PTS_IDPARTE AND ALM_IDALMA = @ALMACEN AND PTS_IDPARTE = @IDPARTE
   IF @TIPOP = 'PL'
       SET @PRECIO = @PL
   IF @TIPOP = 'CR'
       SET @PRECIO = @CR
   IF @TIPOP = 'CP'
       SET @PRECIO = @CP
       SET @PRECIO = @PREUNITARIO
       If @Operador = '-'
           SET @TOTAL = (((@PRECIO * @porcentaje) / 100) - @PRECIO) * -1
        If @Operador = '+'
           SET @TOTAL = (((@PRECIO * @porcentaje) / 100) + @PRECIO)
        If @Operador = '&'
           SET @TOTAL = @PRECIO + @porcentaje
        If @Operador = '/'
           SET @TOTAL = (@PRECIO / (@porcentaje / 100))
        If @Operador = '*'
           SET @TOTAL = (@PRECIO * (@porcentaje / 100))
        If @Operador = ''
           SET @TOTAL = @PRECIO
   IF @opcion = 'I'
   BEGIN
       SET @TOTAL  = @TOTAL * 0.16
   END
   RETURN @TOTAL
END
go

