CREATE VIEW [dbo].[dep_recepnotascredito]
AS
SELECT rnc_idrecepnotascredito, rnc_iddevolucion, rnc_idalmacen, rnc_idempresa, rnc_idsucursal, rnc_idusuario,
rnc_fechaalta, rnc_estatus, rnc_idfactura, rnc_observaciones,rnc_nombrebd,rnc_ipbd,rnc_tipobase,rnc_numsiniestro,rnc_ordenglobal,rnc_tareferencia
FROM PortalRefacciones.dbo.dep_recepnotascredito

go

