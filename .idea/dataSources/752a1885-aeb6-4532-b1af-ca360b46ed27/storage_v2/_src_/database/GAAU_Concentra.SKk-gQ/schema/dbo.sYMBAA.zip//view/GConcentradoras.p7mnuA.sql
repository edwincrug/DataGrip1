CREATE VIEW GConcentradoras
AS
SELECT * FROM [192.168.20.29].GA_Corporativa.dbo.GConcentradoras
go

