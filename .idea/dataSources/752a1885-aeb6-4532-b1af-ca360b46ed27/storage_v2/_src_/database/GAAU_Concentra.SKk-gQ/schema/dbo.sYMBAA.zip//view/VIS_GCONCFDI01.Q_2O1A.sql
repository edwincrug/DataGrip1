CREATE VIEW VIS_GCONCFDI01 AS Select '01' as Vcc_Empresa,'2003' as Vcc_Anno,* FROM CON_GCFDI012003
 union all Select '01' as Vcc_Empresa,'2004' as Vcc_Anno,* FROM CON_GCFDI012004
 union all Select '01' as Vcc_Empresa,'2005' as Vcc_Anno,* FROM CON_GCFDI012005
 union all Select '01' as Vcc_Empresa,'2006' as Vcc_Anno,* FROM CON_GCFDI012006
 union all Select '01' as Vcc_Empresa,'2007' as Vcc_Anno,* FROM CON_GCFDI012007
 union all Select '01' as Vcc_Empresa,'2008' as Vcc_Anno,* FROM CON_GCFDI012008
 union all Select '01' as Vcc_Empresa,'2009' as Vcc_Anno,* FROM CON_GCFDI012009
 union all Select '01' as Vcc_Empresa,'2010' as Vcc_Anno,* FROM CON_GCFDI012010
 union all Select '01' as Vcc_Empresa,'2011' as Vcc_Anno,* FROM CON_GCFDI012011
 union all Select '01' as Vcc_Empresa,'2012' as Vcc_Anno,* FROM CON_GCFDI012012
 union all Select '01' as Vcc_Empresa,'2013' as Vcc_Anno,* FROM CON_GCFDI012013
 union all Select '01' as Vcc_Empresa,'2014' as Vcc_Anno,* FROM CON_GCFDI012014
 union all Select '01' as Vcc_Empresa,'2015' as Vcc_Anno,* FROM CON_GCFDI012015
 union all Select '01' as Vcc_Empresa,'2016' as Vcc_Anno,* FROM CON_GCFDI012016
 union all Select '01' as Vcc_Empresa,'2017' as Vcc_Anno,* FROM CON_GCFDI012017
 union all Select '01' as Vcc_Empresa,'2018' as Vcc_Anno,* FROM CON_GCFDI012018
 union all Select '01' as Vcc_Empresa,'2019' as Vcc_Anno,* FROM CON_GCFDI012019
 union all Select '01' as Vcc_Empresa,'2020' as Vcc_Anno,* FROM CON_GCFDI012020
go

