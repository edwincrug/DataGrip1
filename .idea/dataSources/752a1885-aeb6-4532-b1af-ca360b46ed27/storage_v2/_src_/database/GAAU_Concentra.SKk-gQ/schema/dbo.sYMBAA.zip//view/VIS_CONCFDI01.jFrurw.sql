CREATE VIEW VIS_CONCFDI01 AS Select '01' as Vcc_Empresa,'2003' as Vcc_Anno,* FROM CON_CFDI012003
 union all Select '01' as Vcc_Empresa,'2004' as Vcc_Anno,* FROM CON_CFDI012004
 union all Select '01' as Vcc_Empresa,'2005' as Vcc_Anno,* FROM CON_CFDI012005
 union all Select '01' as Vcc_Empresa,'2006' as Vcc_Anno,* FROM CON_CFDI012006
 union all Select '01' as Vcc_Empresa,'2007' as Vcc_Anno,* FROM CON_CFDI012007
 union all Select '01' as Vcc_Empresa,'2008' as Vcc_Anno,* FROM CON_CFDI012008
 union all Select '01' as Vcc_Empresa,'2009' as Vcc_Anno,* FROM CON_CFDI012009
 union all Select '01' as Vcc_Empresa,'2010' as Vcc_Anno,* FROM CON_CFDI012010
 union all Select '01' as Vcc_Empresa,'2011' as Vcc_Anno,* FROM CON_CFDI012011
 union all Select '01' as Vcc_Empresa,'2012' as Vcc_Anno,* FROM CON_CFDI012012
 union all Select '01' as Vcc_Empresa,'2013' as Vcc_Anno,* FROM CON_CFDI012013
 union all Select '01' as Vcc_Empresa,'2014' as Vcc_Anno,* FROM CON_CFDI012014
 union all Select '01' as Vcc_Empresa,'2015' as Vcc_Anno,* FROM CON_CFDI012015
 union all Select '01' as Vcc_Empresa,'2016' as Vcc_Anno,* FROM CON_CFDI012016
 union all Select '01' as Vcc_Empresa,'2017' as Vcc_Anno,* FROM CON_CFDI012017
 union all Select '01' as Vcc_Empresa,'2018' as Vcc_Anno,* FROM CON_CFDI012018
 union all Select '01' as Vcc_Empresa,'2019' as Vcc_Anno,* FROM CON_CFDI012019
 union all Select '01' as Vcc_Empresa,'2020' as Vcc_Anno,* FROM CON_CFDI012020
go

