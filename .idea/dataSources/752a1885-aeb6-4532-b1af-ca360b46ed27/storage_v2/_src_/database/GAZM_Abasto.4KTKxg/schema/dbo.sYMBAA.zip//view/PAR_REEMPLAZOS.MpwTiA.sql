create view [dbo].[PAR_REEMPLAZOS] as select * from GAZM_Concentra.dbo.PAR_REEMPLAZOS
go

