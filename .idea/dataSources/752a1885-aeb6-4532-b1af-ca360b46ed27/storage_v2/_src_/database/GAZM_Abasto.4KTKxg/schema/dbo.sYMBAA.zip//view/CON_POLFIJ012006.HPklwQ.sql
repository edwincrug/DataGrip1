create view 	[dbo].[CON_POLFIJ012006]	 as select * from GAZM_Concentra.dbo.CON_POLFIJ012006
go

