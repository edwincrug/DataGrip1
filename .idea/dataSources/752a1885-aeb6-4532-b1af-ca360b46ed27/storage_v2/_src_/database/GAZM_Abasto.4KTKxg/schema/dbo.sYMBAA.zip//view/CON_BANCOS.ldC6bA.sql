create view [dbo].[CON_BANCOS] as select * from GAZM_Concentra.dbo.CON_BANCOS
go

