create view [dbo].[ADE_CANCFDDETMN] as select * from GAZM_Concentra.dbo.ADE_CANCFDDETMN
go

