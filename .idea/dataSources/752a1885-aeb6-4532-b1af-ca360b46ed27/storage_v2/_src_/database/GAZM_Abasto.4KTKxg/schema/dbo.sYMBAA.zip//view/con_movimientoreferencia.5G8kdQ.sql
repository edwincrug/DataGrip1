CREATE VIEW [dbo].[con_movimientoreferencia] AS SELECT * From GAZM_Concentra.dbo.con_movimientoreferencia
go

