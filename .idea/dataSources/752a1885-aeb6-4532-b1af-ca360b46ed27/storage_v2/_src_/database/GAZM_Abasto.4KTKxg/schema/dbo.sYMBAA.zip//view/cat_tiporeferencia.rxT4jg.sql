CREATE VIEW [dbo].[cat_tiporeferencia] AS SELECT * From  GAZM_Concentra.dbo.cat_tiporeferencia
go

