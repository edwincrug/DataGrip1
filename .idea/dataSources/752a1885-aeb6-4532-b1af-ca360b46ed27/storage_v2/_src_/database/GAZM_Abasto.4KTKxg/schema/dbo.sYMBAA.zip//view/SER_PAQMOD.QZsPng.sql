create view [dbo].[SER_PAQMOD] as select * from GAZM_Concentra.dbo.SER_PAQMOD
go

