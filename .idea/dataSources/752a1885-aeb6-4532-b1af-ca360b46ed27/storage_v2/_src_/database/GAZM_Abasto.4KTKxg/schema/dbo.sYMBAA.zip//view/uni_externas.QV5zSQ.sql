CREATE VIEW [dbo].[uni_externas]
AS
SELECT uex_idunificacionext, uex_nombrebd, uex_ipbd, uex_estatus FROM GA_CORPORATIVA.DBO.uni_externas
go

