create view [dbo].[ADE_ADDENDASCONFIG] as select * from GAZM_Concentra.dbo.ADE_ADDENDASCONFIG
go

