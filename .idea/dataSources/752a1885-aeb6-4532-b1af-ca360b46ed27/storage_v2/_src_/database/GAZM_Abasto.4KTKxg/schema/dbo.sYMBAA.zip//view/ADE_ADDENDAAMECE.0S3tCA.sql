create view [dbo].[ADE_ADDENDAAMECE] as select * from GAZM_Concentra.dbo.ADE_ADDENDAAMECE
go

