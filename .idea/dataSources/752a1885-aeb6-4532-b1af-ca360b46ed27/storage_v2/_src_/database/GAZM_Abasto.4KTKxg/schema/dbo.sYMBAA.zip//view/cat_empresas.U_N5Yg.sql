CREATE VIEW [dbo].[cat_empresas]
AS
SELECT 
emp_idempresa, gpo_idgrupo, div_iddivision, reg_idregion, emp_cveempresa, emp_idpersona, emp_nombre, emp_nombrecto, emp_paginaweb, emp_ipbd, emp_nombrebd, emp_alias, emp_observaciones, emp_fechaalta, emp_usualta, emp_fechamodifica, emp_usumodifica, emp_estatus
FROM        [ControlAplicaciones].dbo.cat_empresas
go

