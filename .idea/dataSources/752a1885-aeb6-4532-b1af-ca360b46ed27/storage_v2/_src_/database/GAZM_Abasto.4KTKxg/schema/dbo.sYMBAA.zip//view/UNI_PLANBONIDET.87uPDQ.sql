create view [dbo].[UNI_PLANBONIDET] as select * from GAZM_Concentra.dbo.UNI_PLANBONIDET
go

