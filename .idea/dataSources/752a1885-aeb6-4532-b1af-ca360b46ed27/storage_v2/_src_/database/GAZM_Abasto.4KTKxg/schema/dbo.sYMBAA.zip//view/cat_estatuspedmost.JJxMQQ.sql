---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[cat_estatuspedmost] AS 
SELECT cep_idestatuspedmost, cep_nombrecorto, cep_nombre, cep_descripcion, cep_estatus, cep_idusuarioalta, cep_fechaalta, cep_idusuariomodifica, cep_fechamodifica
FROM       CUENTASPORCOBRAR.dbo.cat_estatuspedmost;
go

