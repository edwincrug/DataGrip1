create view [dbo].[PYM_VARIOS] as select * from GAZM_Concentra.dbo.PYM_VARIOS
go

