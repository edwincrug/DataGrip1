create view [dbo].[CON_GCFDI012006] as select * from [GAZM_Concentra].dbo.[CON_GCFDI012006]
go

