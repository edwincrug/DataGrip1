create view [dbo].[UNI_PLANBONI] as select * from GAZM_Concentra.dbo.UNI_PLANBONI
go

