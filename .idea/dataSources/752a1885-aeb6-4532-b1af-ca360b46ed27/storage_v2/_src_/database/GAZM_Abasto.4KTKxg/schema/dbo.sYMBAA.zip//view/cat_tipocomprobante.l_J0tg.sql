CREATE VIEW [cat_tipocomprobante] AS Select * From GAZM_Concentra.dbo.cat_tipocomprobante
go

