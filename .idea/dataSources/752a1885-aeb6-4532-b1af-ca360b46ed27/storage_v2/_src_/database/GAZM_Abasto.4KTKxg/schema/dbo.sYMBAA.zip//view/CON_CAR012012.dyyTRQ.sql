create view 	[dbo].[CON_CAR012012]	as select * from GAZM_Concentra.dbo.CON_CAR012012
go

