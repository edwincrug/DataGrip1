---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[uni_otroconceptosdet]  
AS  

SELECT        ucd_idotrosconceptosdet, ucd_cantidad, ucd_descripcion, ucd_costounitario, ucd_preciounitario, ucd_idconcepconta, ucd_referencia, ucd_idunidadmedida, uoc_idotrosconceptosenc, ucd_idusuarioalta, ucd_fechaalta, 
                         ucd_idusuariomodifica, ucd_fechamodifica, ucd_estatus, ucn_idcotizadetalle, ctc_idtipoorden, ucn_idcotizadetallepost, CEA_IdEstatusAdicionales, pmd_estatusautorizacion, ucd_agrupado  
FROM       CUENTASPORCOBRAR.dbo.uni_otroconceptosdet

go

