create view 	[dbo].[CON_CAR012007]	as select * from GAZM_Concentra.dbo.CON_CAR012007
go

