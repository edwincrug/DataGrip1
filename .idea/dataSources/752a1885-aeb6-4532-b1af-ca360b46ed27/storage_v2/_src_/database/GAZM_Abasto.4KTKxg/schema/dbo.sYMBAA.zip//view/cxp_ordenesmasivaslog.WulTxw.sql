Create View [dbo].[cxp_ordenesmasivaslog] as select * from [GAZM_CONCENTRA].dbo.cxp_ordenesmasivaslog
go

