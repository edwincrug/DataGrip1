CREATE VIEW [dbo].[cat_acciones]
AS
SELECT  
apc_idaccionporcondicion, apc_nombre, apc_nombrecto, apc_fechaalta, apc_usualta, apc_fechamodifica, apc_usumodifica, apc_estatus
FROM         [GA_Corporativa].dbo.cat_acciones
go

