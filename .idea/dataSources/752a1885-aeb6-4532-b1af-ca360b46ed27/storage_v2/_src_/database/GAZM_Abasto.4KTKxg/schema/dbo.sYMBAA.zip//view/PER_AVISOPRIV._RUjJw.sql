create view [dbo].[PER_AVISOPRIV] as select * from GAZM_Concentra.dbo.PER_AVISOPRIV
go

