create view 	[dbo].[CON_CARDETACON012004]	as select * from GAZM_Concentra.dbo.CON_CARDETACON012004
go

