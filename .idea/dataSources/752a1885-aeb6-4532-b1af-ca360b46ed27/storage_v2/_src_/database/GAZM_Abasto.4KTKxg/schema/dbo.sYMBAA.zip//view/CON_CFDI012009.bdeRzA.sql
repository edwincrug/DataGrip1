create view [dbo].[CON_CFDI012009] as select * from [GAZM_Concentra].dbo.[con_cfdi012009]
go

