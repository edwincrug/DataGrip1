create view 	[dbo].[CON_POLFIJ012010]	 as select * from GAZM_Concentra.dbo.CON_POLFIJ012010
go

