CREATE VIEW [cat_claveprodserv] AS Select * From GAZM_Concentra.dbo.cat_claveprodserv
go

