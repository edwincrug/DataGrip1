create view [dbo].[ADE_VTACFD] as select * from GAZM_Concentra.dbo.ADE_VTACFD
go

