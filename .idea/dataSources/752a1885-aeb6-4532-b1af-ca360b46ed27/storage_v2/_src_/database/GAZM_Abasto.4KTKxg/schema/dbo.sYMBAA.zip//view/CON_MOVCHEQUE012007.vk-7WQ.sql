create view [dbo].[CON_MOVCHEQUE012007] as select * from GAZM_Concentra.dbo.CON_MOVCHEQUE012007
go

