CREATE VIEW [dbo].[def_condicionescredito]
AS
SELECT 
dcc_idcondicionescredito, dcc_idtipoventa, dcc_idtipooperacion, dcc_estatus, apc_idaccionporcondicion, tbq_idtipobloqueo, dcc_nombrectodepto, dcc_fechaalta, dcc_usualta
FROM         [GA_Corporativa].dbo.def_condicionescredito
go

