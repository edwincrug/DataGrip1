create view [dbo].[CON_MOVTRANSFER012003] as select * from GAZM_Concentra.dbo.CON_MOVTRANSFER012003
go

