create view 	[dbo].[CON_POL012011]	 as select * from GAZM_Concentra.dbo.CON_POL012011
go

