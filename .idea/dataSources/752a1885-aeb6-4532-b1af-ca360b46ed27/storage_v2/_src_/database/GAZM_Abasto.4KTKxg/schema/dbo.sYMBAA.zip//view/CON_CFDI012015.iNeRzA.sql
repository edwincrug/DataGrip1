create view [dbo].[CON_CFDI012015] as select * from [GAZM_Concentra].dbo.[con_cfdi012015]
go

