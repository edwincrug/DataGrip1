create view [dbo].[ADE_CFDI] as select * from GAZM_Concentra.dbo.ADE_CFDI
go

