create view [dbo].[ADE_CANCFDMN] as select * from GAZM_Concentra.dbo.ADE_CANCFDMN
go

