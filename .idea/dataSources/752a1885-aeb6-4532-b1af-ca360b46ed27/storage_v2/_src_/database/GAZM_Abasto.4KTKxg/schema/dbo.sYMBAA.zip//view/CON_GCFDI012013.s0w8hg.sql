create view [dbo].[CON_GCFDI012013] as select * from [GAZM_Concentra].dbo.[CON_GCFDI012013]
go

