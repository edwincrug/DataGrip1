create view 	[dbo].[CON_MOVDETFIJ012012]	 as select * from GAZM_Concentra.dbo.CON_MOVDETFIJ012012
go

