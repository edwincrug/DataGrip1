create view [dbo].[ADE_CFDREPMENSUAL] as select * from GAZM_Concentra.dbo.ADE_CFDREPMENSUAL
go

