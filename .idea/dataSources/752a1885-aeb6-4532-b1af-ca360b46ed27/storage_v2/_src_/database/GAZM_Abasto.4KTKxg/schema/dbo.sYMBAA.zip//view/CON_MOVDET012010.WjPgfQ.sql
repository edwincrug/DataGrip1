create view 	[dbo].[CON_MOVDET012010]	 as select * from GAZM_Concentra.dbo.CON_MOVDET012010
go

