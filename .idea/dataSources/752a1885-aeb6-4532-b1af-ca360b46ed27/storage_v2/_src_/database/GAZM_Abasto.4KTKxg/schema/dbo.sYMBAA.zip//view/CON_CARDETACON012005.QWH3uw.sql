create view 	[dbo].[CON_CARDETACON012005]	as select * from GAZM_Concentra.dbo.CON_CARDETACON012005
go

