create view [dbo].[CON_CFDI012008] as select * from [GAZM_Concentra].dbo.[con_cfdi012008]
go

