CREATE VIEW [cat_tiporelacion] AS Select * From GAZM_Concentra.dbo.cat_tiporelacion
go

