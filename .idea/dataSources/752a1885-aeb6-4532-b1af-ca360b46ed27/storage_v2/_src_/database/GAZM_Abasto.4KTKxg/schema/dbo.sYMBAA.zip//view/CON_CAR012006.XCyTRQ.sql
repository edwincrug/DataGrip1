create view 	[dbo].[CON_CAR012006]	as select * from GAZM_Concentra.dbo.CON_CAR012006
go

