create view [dbo].[SER_PAQREF] as select * from GAZM_Concentra.dbo.SER_PAQREF
go

