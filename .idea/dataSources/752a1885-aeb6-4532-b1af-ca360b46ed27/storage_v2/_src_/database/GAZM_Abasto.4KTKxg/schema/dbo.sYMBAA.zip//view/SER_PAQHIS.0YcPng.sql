create view [dbo].[SER_PAQHIS] as select * from GAZM_Concentra.dbo.SER_PAQHIS
go

