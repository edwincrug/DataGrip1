create view 	[dbo].[CON_CARDETACON012009]	as select * from GAZM_Concentra.dbo.CON_CARDETACON012009
go

