create view [dbo].[ADE_CFDREPMENDET] as select * from GAZM_Concentra.dbo.ADE_CFDREPMENDET
go

