CREATE VIEW [dbo].[ade_cfditimbrado] AS SELECT * FROM GAZM_Concentra.dbo.ade_cfditimbrado
go

