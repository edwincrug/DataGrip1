create view 	[dbo].[CON_MOVDETFIJ012011]	 as select * from GAZM_Concentra.dbo.CON_MOVDETFIJ012011
go

