-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_GENERA_LAYOUT_PRUEBA]
@dbName varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @query nvarchar(max), @db nvarchar(50)

	exec(N'USE '+ @db + N'; EXEC(''
									SELECT TOP 100
									/*========================================
									DATOS DEL CLIENTE COMPRADOR
									========================================*/
									per.PER_IDPERSONA AS numero_cliente
									,substring(per.PER_NOMRAZON,1,50) AS primer_nombre
									,substring(per.PER_NOMRAZON,51,len(per.PER_NOMRAZON)) AS segundo_nombre
									,per.PER_PATERNO AS apellido_paterno
									,per.PER_MATERNO AS apellido_materno
									,CASE WHEN per.PER_SEXO = ''HOM'' THEN''1'' ELSE ''2'' END AS genero
									,CASE WHEN per.PER_EDOCIVIL = ''SOL'' THEN ''1''
									      WHEN per.PER_EDOCIVIL = ''CAS'' THEN ''2''
										  WHEN per.PER_EDOCIVIL = ''VIU'' THEN ''3''
										  WHEN per.PER_EDOCIVIL = ''DIV'' THEN ''4''
										  WHEN per.PER_EDOCIVIL = ''UNL'' THEN ''5''
										  ELSE '''' END AS estado_civil
									,CASE WHEN per.PER_FECNAC like ''[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]'' THEN per.PER_FECNAC ELSE '''' END AS fecha_nacimiento
									,per.PER_RFC AS rfc
									,CASE WHEN per.PER_TIPO = ''MOR'' THEN 3
										  WHEN per.PER_TIPO = ''FIE''	THEN 2
									      when per.PER_TIPO = ''FIS'' THEN 1
									END AS tipo_de_regimen_fiscal
									/*========================================
									DATOS DE CONTACTO DEL CLIENTE COMPRADOR
									========================================*/
									,perfac.PER_NOMRAZON AS nombre_de_empresa
									,perfac.PER_CALLE1 AS calle
									,perfac.PER_NUMEXTER AS no_exterior
									,perfac.PER_NUMINER AS no_interior
									,perfac.PER_CIUDAD AS ciudad
									,perfac.PER_COLONIA AS colonia
									,perfac.PER_DELEGAC AS municipio_delegacion
									,para.PAR_DESCRIP1 AS estado
									,perfac.PER_CODPOS AS codigo_postal
									,perfac.PER_TELEFONO1 AS telefono_casa
									,perfac.PER_TELEFONO1 AS telefono_oficina
									,perfac.PER_EXT1 AS ext_telefono_oficina
									,perfac.per_telcelular AS telefono_celular
									,perfac.PER_TELEFONO2 AS telefono_casa_2
									,perfac.PER_TELEFONO2 AS telefono_oficina_2
									,CASE WHEN perfac.PER_EMAIL LIKE ''%@%.%'' THEN perfac.PER_EMAIL ELSE '''' END AS email_personal
									,CASE WHEN perfac.PER_EMAIL2 LIKE ''%@%.%'' THEN perfac.PER_EMAIL2 ELSE '''' END AS email_trabajo
									,'''' AS vehiculo_actual_anterior
									,'''' AS marca_actual_anterior
									,'''' AS aniomodelo_actual_anterior
									,'''' AS color_actual_anterior
									,perfac.PER_ESCOLAR AS escolaridad
									,'''' AS facebook
									,'''' AS twitter
									,'''' AS desea_ser_contacto
									,perfac.PER_MEDIOCONTACTO AS medio_de_contacto_preferido_del_cliente
									--/*========================================
									--DATOS DEL CONTACTO 1 DE VENTAS
									--========================================*/
									,pp.PER_NOMRAZON AS primer_nombre_c1
									,'''' AS segundo_nombre_c1
									,pp.PER_PATERNO AS apellido_paterno_c1
									,pp.PER_MATERNO AS apellido_materno_c1
									,pp.PER_CALLE1 AS calle_c1
									,pp.PER_NUMEXTER AS no_exterior_c1
									,pp.PER_NUMINER AS no_interior_c1
									,pp.PER_CIUDAD AS ciudad_c1
									,pp.PER_COLONIA AS colonia_c1
									,pp.PER_DELEGAC AS municipio_delegacion_c1
									,'''' AS estado_c1
									,pp.PER_CODPOS AS codigo_postal_c1
									,pp.PER_TELEFONO1 AS telefono_casa_c1
									,pp.PER_TELEFONO2 AS telefono_oficina_c1
									,pp.PER_EXT2 AS ext_telefono_oficina_c1
									,pp.per_telcelular AS telefono_celular_c1
									,'''' AS telefono_casa_2_c1
									,'''' AS telefono_oficina_2_c1
									,CASE WHEN pp.PER_EMAIL LIKE ''%@%.%'' THEN pp.PER_EMAIL ELSE '''' END AS email_personal_c1
									,CASE WHEN pp.PER_EMAIL2 LIKE ''%@%.%'' THEN pp.PER_EMAIL2 ELSE '''' END  AS email_trabajo_c1
									,pp.PER_ESCOLAR AS escolaridad_c1
									,'''' AS facebook_c1
									,'''' AS twitter_c1
									,'''' AS desea_ser_contacto_c1
									,'''' AS pasatiempo_1_c1
									,'''' AS pasatiempo_2_c1
									,'''' AS vinculo_c1
									,'''' AS medio_de_contacto_preferido_del_cliente_c1
									/*========================================
									DATOS DEL CONTACTO 2 DE VENTAS
									========================================*/
									,'''' AS primer_nombre_c2
									,'''' AS segundo_nombre_c2
									,'''' AS apellido_paterno_c2
									,'''' AS apellido_materno_c2
									,'''' AS calle_c2
									,'''' AS no_exterior_c2
									,'''' AS no_interior_c2
									,'''' AS ciudad_c2
									,'''' AS colonia_c2
									,'''' AS municipio_delegacion_c2
									,'''' AS estado_c2
									,'''' AS codigo_postal_c2
									,'''' AS telefono_casa_c2
									,'''' AS telefono_oficina_c2
									,'''' AS ext_telefono_oficina_c2
									,'''' AS telefono_celular_c2
									,'''' AS telefono_casa_2_c2
									,'''' AS telefono_oficina_2_c2
									,'''' AS email_personal_c2
									,'''' AS email_trabajo_c2
									,'''' AS escolaridad_c2
									,'''' AS facebook_c2
									,'''' AS twitter_c2
									,'''' AS desea_ser_contacto_c2
									,'''' AS pasatiempo_1_c2
									,'''' AS pasatiempo_2_c2
									,'''' AS vinculo_c2
									,'''' AS medio_de_contacto_preferido_del_cliente_c2
									/*========================================
									DATOS DEL PRODUCTO
									========================================*/
									,SUBSTRING(sv.VEH_TIPOAUTO,1,15) AS modelo
									,vta.VDE_VEHMARCA  AS marca
									,sv.VEH_ANMODELO AS aniomodelo
									,SUBSTRING(sv.VEH_TIPOAUTO,1,15) AS [version]
									,uce.COL_DESCRIPCION AS color_exterior
									,uci.COL_DESCRIPCION AS color_interior
									,sv.VEH_NOSERIEIMP AS vin
									,sv.VEH_NOMOTOR AS motor
									,case when cat.UNC_TRANSMISION <> ''MAN'' THEN ''A'' ELSE ''M'' END  AS transmision
									/*========================================
									DATOS DE FACTURACION
									========================================*/
									,fac.VTE_DOCTO AS factura_cliente
									,substring(cast(fac.VTE_VTABRUT AS varchar(30)),1, charindex(''.'', cast(fac.VTE_VTABRUT AS varchar(30)))-1) AS precio_base_vehiculo
									,substring(cast(vdeta.precioAcc AS varchar(30)),1, charindex(''.'', cast(vdeta.precioAcc AS varchar(30)))-1) AS precio_accesorios	   --substring(cast(fac.VTE_VTABRUT AS varchar(30)),1, charindex(''.'', cast(fac.VTE_VTABRUT AS varchar(30)))-1)
									,substring(cast(fac.VTE_TOTAL AS varchar(30)),1, charindex(''.'', cast(fac.VTE_TOTAL AS varchar(30)))-1) AS precio_vehiculo		 
									,CASE WHEN up2.PEN_FECHAENTREGA_REAL like ''[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]'' THEN up2.PEN_FECHAENTREGA_REAL ELSE '''' END AS fecha_entrega_delvehiculo
									,CASE WHEN fac.VTE_FECHDOCTO like ''[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]'' THEN fac.VTE_FECHDOCTO ELSE '''' END  AS fecha_factura_cliente
									,emi.EMR_IDPERSONA AS clave_distribuidor
									,up3.PBU_PROMOCION AS clave_promocion
									,CASE WHEN par.PAR_DESCRIP1 LIKE ''F[^I]%'' 
									THEN ''2''
									ELSE  CASE WHEN par.PAR_DESCRIP1 LIKE ''TRA%'' OR par.PAR_DESCRIP1 LIKE ''V%''
												THEN ''3''
												ELSE ''1''
											END
									END AS tipo_venta
									,pp.PER_IDPERSONA AS idvendedor
									,pp.PER_NOMRAZON AS vend_vnombre
									,pp.PER_PATERNO AS vend_vapaterno
									,pp.PER_MATERNO AS vend_vamaterno
									--========================================
									FROM dbo.PER_PERSONAS per
									left JOIN ADE_VTAFI fac
									on fac.VTE_STATUS = ''I'' 
									AND fac.VTE_TIPODOCTO = ''A''
									AND fac.VTE_IDCLIENTE = per.PER_IDPERSONA
									JOIN dbo.ADE_VTACFD vta
									ON fac.VTE_DOCTO = vta.VDE_DOCTO
									JOIN dbo.SER_VEHICULO sv
									ON fac.VTE_SERIE = sv.VEH_NOSERIEIMP
									AND sv.VEH_SITUACION = ''VEN''
									JOIN UNI_CATALOGO cat
									ON sv.VEH_CATALOGO = cat.UNC_IDCATALOGO
									AND sv.VEH_ANMODELO = cat.UNC_MODELO
									left JOIN (SELECT distinct sum(VHD_PRECIO) OVER(PARTITION BY v.VHD_NOSERIE) AS precioAcc
											,v.VHD_NOSERIE
											FROM UNI_VEHDETA v
											WHERE v.VHD_FACT=''n'' --AND v.VHD_PRECIO>0 
									) AS vdeta
									ON fac.VTE_SERIE = vdeta.VHD_NOSERIE
									JOIN dbo.UNI_PEDIDO up
									ON fac.VTE_REFERENCIA1 = up.UPE_IDPEDI
									JOIN dbo.UNI_PEDIUNI up2
									ON up.UPE_IDPEDI = up2.PEN_IDPEDI
									AND fac.VTE_SERIE = up2.PEN_NUMSERIE
									AND up2.PEN_FECHAENTREGA_REAL IS NOT NULL
									JOIN dbo.PER_PERSONAS pp
									ON up.UPE_IDAGTE = pp.PER_IDPERSONA
									JOIN dbo.PER_PERSONAS perfac
									ON up.UPE_IDCLIEFAC = perfac.PER_IDPERSONA
									JOIN PNC_PARAMETR para 
									on para.PAR_TIPOPARA = ''EO''
									AND para.PAR_IDENPARA = perfac.PER_ESTADO
									JOIN PNC_PARAMETR par
									ON fac.VTE_FORMAPAGO = par.PAR_IDENPARA
									AND par.PAR_TIPOPARA = ''VNT''
									left JOIN ADE_EMISRECEP emi
									ON vta.VDE_IDEMPRESA = emi.EMR_IDPERSONA --par.PAR_CVEUSU = emi.EMR_CVEUSU
									JOIN dbo.UNI_CATACOLOR uce
									ON sv.VEH_COLOEXTE = uce.COL_CLAVE
									AND sv.VEH_ANMODELO = uce.COL_MODELO
									AND sv.VEH_CATALOGO = uce.COL_CATALOGO
									JOIN dbo.UNI_CATACOLOR uci
									ON sv.VEH_COLOINTE = uci.COL_CLAVE
									AND sv.VEH_ANMODELO = uci.COL_MODELO
									AND sv.VEH_CATALOGO = uci.COL_CATALOGO
									LEFT JOIN dbo.UNI_BONIFICACIONES ub
									ON up2.PEN_IDPEDI = ub.BON_IDPEDI
									LEFT JOIN dbo.UNI_PLANBONI up3
									ON ub.BON_PLAN = up3.PBU_NUMERO
									ORDER BY numero_cliente DESC
									--WHERE convert(varchar,convert(datetime, fac.VTE_FECHDOCTO,103),112) = convert(varchar,getdate()-5,112)
									--ORDER BY fac.VTE_IDCLIENTE desc
									'')')


END
go

