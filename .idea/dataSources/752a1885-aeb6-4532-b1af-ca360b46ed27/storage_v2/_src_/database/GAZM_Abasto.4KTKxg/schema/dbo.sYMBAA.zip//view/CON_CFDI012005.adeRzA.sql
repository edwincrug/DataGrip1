create view [dbo].[CON_CFDI012005] as select * from [GAZM_Concentra].dbo.[con_cfdi012005]
go

