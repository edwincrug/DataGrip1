CREATE VIEW [cat_usoCFDI] AS Select * From GAZM_Concentra.dbo.cat_usoCFDI
go

