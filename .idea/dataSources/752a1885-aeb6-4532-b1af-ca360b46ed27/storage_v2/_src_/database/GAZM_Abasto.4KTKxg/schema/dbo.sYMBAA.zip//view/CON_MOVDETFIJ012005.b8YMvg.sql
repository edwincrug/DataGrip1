create view 	[dbo].[CON_MOVDETFIJ012005]	 as select * from GAZM_Concentra.dbo.CON_MOVDETFIJ012005
go

