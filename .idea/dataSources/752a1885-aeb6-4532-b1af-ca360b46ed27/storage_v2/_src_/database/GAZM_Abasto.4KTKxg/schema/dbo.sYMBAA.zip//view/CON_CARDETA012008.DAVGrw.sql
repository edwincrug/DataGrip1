create view 	[dbo].[CON_CARDETA012008]	as select * from GAZM_Concentra.dbo.CON_CARDETA012008
go

