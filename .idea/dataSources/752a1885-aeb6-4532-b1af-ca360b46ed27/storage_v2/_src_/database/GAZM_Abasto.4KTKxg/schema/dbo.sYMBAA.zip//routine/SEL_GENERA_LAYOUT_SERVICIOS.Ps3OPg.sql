-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_GENERA_LAYOUT_SERVICIOS]
@dbName varchar(50)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		DECLARE @query nvarchar(max), @db nvarchar(50)

		exec(N'USE '+ @db + N'; EXEC(''
									SELECT TOP 100
									/*========================================
									DATOS DEL CLIENTE COMPRADOR
									========================================*/
									cli.PER_IDPERSONA AS numero_cliente
									,substring(cli.PER_NOMRAZON,1,50) AS primer_nombre
									,substring(cli.PER_NOMRAZON,51,len(cli.PER_NOMRAZON)) AS segundo_nombre
									,cli.PER_PATERNO AS apellido_paterno
									,cli.PER_MATERNO AS apellido_materno
									,CASE WHEN cli.PER_SEXO = ''HOM'' THEN''1'' ELSE ''0'' END AS genero
									,CASE WHEN cli.PER_EDOCIVIL = ''SOL'' THEN ''1''
									      WHEN cli.PER_EDOCIVIL = ''CAS'' THEN ''2''
										  WHEN cli.PER_EDOCIVIL = ''VIU'' THEN ''3''
										  WHEN cli.PER_EDOCIVIL = ''DIV'' THEN ''4''
										  WHEN cli.PER_EDOCIVIL = ''UNL'' THEN ''5''
										  ELSE '''' END AS estado_civil
									,CASE WHEN cli.PER_FECNAC like ''[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]'' THEN cli.PER_FECNAC ELSE '''' END AS fecha_nacimiento
									,cli.PER_RFC AS rfc
									,CASE WHEN cli.PER_TIPO = ''MOR'' THEN 3
										  WHEN cli.PER_TIPO = ''FIE''	THEN 2
									      when cli.PER_TIPO = ''FIS'' THEN 1
									END AS tipo_de_regimen_fiscal
									,isnull(cast(cli.PER_CALLE1 AS varchar(100)),'''') AS calle
									,cli.PER_NUMEXTER AS no_exterior
									,cli.PER_NUMINER AS no_interior
									,cli.PER_CIUDAD AS ciudad
									,cli.PER_COLONIA AS colonia
									,cli.PER_DELEGAC AS municipio_delegacion
									,para.PAR_DESCRIP1 AS estado
									,cli.PER_CODPOS AS codigo_postal
									,cli.PER_TELEFONO1 AS telefono_casa
									,cli.PER_TELEFONO1 AS telefono_oficina
									,cli.PER_EXT1 AS ext_telefono_oficina
									,cli.per_telcelular AS telefono_celular
									,cli.PER_TELEFONO2 AS telefono_casa_2
									,cli.PER_TELEFONO2 AS telefono_oficina_2
									,CASE WHEN cli.PER_EMAIL LIKE ''%@%.%'' THEN cli.PER_EMAIL ELSE '''' END AS email_personal
									,CASE WHEN cli.PER_EMAIL2 LIKE ''%@%.%'' THEN cli.PER_EMAIL2 ELSE '''' END AS email_trabajo
									,cli.PER_ESCOLAR AS escolaridad
									,'''' AS facebook
									,'''' AS twitter
									,'''' AS desea_ser_contacto
									,'''' AS pasatiempo_1
									,'''' AS pasatiempo_2
									,'''' AS vinculo
									,cli.PER_MEDIOCONTACTO AS medio_de_contacto_preferido_del_cliente
									/*========================================
									DATOS DEL CONTACTO 1 DE VENTAS
									========================================*/
									,per.PER_NOMRAZON AS nombre_de_empresa
									,per.PER_NOMRAZON AS primer_nombre_c1
									,'''' AS segundo_nombre_c1
									,per.PER_PATERNO AS apellido_paterno_c1
									,per.PER_MATERNO AS apellido_materno_c1
									,per.PER_CALLE1 AS calle_c1
									,per.PER_NUMEXTER AS no_exterior_c1
									,per.PER_NUMINER AS no_interior_c1
									,per.PER_CIUDAD AS ciudad_c1
									,per.PER_COLONIA AS colonia_c1
									,per.PER_DELEGAC AS municipio_delegacion_c1
									,'''' AS estado_c1
									,per.PER_CODPOS AS codigo_postal_c1
									,per.PER_TELEFONO1 AS telefono_casa_c1
									,per.PER_TELEFONO2 AS telefono_oficina_c1
									,per.PER_EXT2 AS ext_telefono_oficina_c1
									,per.per_telcelular AS telefono_celular_c1
									,'''' AS telefono_casa_2_c1
									,'''' AS telefono_oficina_2_c1
									,per.PER_EMAIL AS email_personal_c1
									,per.PER_EMAIL AS email_trabajo_c1
									,per.PER_ESCOLAR AS escolaridad_c1
									,'''' AS facebook_c1
									,'''' AS twitter_c1
									,'''' AS desea_ser_contacto_c1
									,'''' AS pasatiempo_1_c1
									,'''' AS pasatiempo_2_c1
									,'''' AS vinculo_c1
									,'''' AS medio_de_contacto_preferido_del_cliente_c1
									/*========================================
									DATOS DEL CONTACTO 2 DE VENTAS
									========================================*/
									,'''' AS primer_nombre_c2
									,'''' AS segundo_nombre_c2
									,'''' AS apellido_paterno_c2
									,'''' AS apellido_materno_c2
									,'''' AS calle_c2
									,'''' AS no_exterior_c2
									,'''' AS no_interior_c2
									,'''' AS ciudad_c2
									,'''' AS colonia_c2
									,'''' AS municipio_delegacion_c2
									,'''' AS estado_c2
									,'''' AS codigo_postal_c2
									,'''' AS telefono_casa_c2
									,'''' AS telefono_oficina_c2
									,'''' AS ext_telefono_oficina_c2
									,'''' AS telefono_celular_c2
									,'''' AS telefono_casa_2_c2
									,'''' AS telefono_oficina_2_c2
									,'''' AS email_personal_c2
									,'''' AS email_trabajo_c2
									,'''' AS escolaridad_c2
									,'''' AS facebook_c2
									,'''' AS twitter_c2
									,'''' AS desea_ser_contacto_c2
									,'''' AS pasatiempo_1_c2
									,'''' AS pasatiempo_2_c2
									,'''' AS vinculo_c2
									,'''' AS medio_de_contacto_preferido_del_cliente_c2
									--/*========================================
									--DATOS DEL PRODUCTO
									--========================================*/
									,SUBSTRING(sv.VEH_TIPOAUTO,1,15) AS modelo
									,so.ORE_MARCA AS marca
									,sv.VEH_ANMODELO AS aniomodelo
									,SUBSTRING(sv.VEH_TIPOAUTO,1,15) AS [version]
									,sv.VEH_COLOEXTE AS color_exterior
									,sv.VEH_COLOINTE AS color_interior
									,sv.VEH_NUMSERIE AS vin
									,sv.VEH_NOPLACAS AS placas
									,so.ORE_KILOMETRAJE AS km
									,sv.VEH_NOMOTOR AS motor
									,case when cat.UNC_TRANSMISION <> ''MAN'' THEN ''A'' ELSE ''M'' END  AS transmision
									--/*========================================
									--DATOS DE FACTURACION
									--========================================*/
									,fac.VTE_DOCTO AS factura_cliente
									,so.ORE_IDORDEN AS orden_de_reparacion
									,'''' AS tipo_orden_de_reparacion
									,'''' AS monto_de_factura
									,fac.VTE_FECHDOCTO AS fecha_entrega_delvehiculo
									,fac.VTE_FECHDOCTO AS fecha_factura_cliente
									,''153602'' AS clave_distribuidor
									,'''' AS clave_promocion
									,CASE 
									WHEN cast(ts.PAR_IMPORTE2 AS int) = 2 THEN 3--GARANTIAS
									WHEN cast(ts.PAR_IMPORTE2 AS int) = 3 THEN 6--INTERNAS
									WHEN cast(ts.PAR_IMPORTE2 AS int) = 1 AND para.PAR_DESCRIP1 LIKE ''%HYP%'' THEN 4--INTERNAS  
									END AS tipo_de_servicio
									,'''' AS idasesor
									,'''' AS asesor_snombre
									,'''' AS asesor_spaterno
									,'''' AS asesor_smaterno
									,'''' AS fecha_apertura_orden
									--========================================
									FROM dbo.PER_PERSONAS per
									left JOIN ADE_VTAFI fac
									on fac.VTE_STATUS = ''I'' 
									AND fac.VTE_TIPODOCTO like ''S%''
									AND fac.VTE_IDCLIENTE = per.PER_IDPERSONA
									left JOIN PNC_PARAMETR para 
									on para.PAR_TIPOPARA = ''EO''
									AND para.PAR_IDENPARA = per.PER_ESTADO
									JOIN dbo.SER_ORDEN so
									ON fac.VTE_REFERENCIA1 = so.ORE_IDORDEN
									AND fac.VTE_IDCLIENTE = so.ORE_IDCLIFAC
									JOIN dbo.PER_PERSONAS cli
									ON so.ORE_IDCLIENTE = cli.PER_IDPERSONA
									left JOIN dbo.SER_VEHICULO sv
									ON  so.ORE_NUMSERIE = sv.VEH_NUMSERIE
									left JOIN UNI_CATALOGO cat
									ON sv.VEH_CATALOGO = cat.UNC_IDCATALOGO
									AND sv.VEH_ANMODELO = cat.UNC_MODELO
									JOIN dbo.PNC_PARAMETR ass
									ON so.ORE_IDASESOR = ass.PAR_IDENPARA
									AND ass.PAR_TIPOPARA =''as''
									JOIN dbo.ADE_VTACFD vta
									ON fac.VTE_DOCTO = vta.VDE_DOCTO
									JOIN dbo.PNC_PARAMETR ts
									ON LEFT(ORE_IDORDEN,1) = ts.PAR_IDENPARA
									AND ts.PAR_TIPOPARA =''TO''
									AND ts.PAR_IDMODULO =''SER''
									--WHERE convert(varchar,convert(datetime, fac.VTE_FECHDOCTO,103),112) = convert(varchar,getdate()-30,112)
									--ORDER BY fac.VTE_IDCLIENTE desc
'')')

END
go

