
CREATE PROC SP_IPIN_VEN_DET_REFACCIONES_INSERTA
AS

--INSERTA EN IPIN
Select convert(varchar(20),Factura) as Factura,convert(varchar(8),case when isnull(FechaFactura,'') = '' 
then 'ND' else replace(FechaFactura,'/','') end) as FechaFactura,convert(varchar(20),Pedido) as 
Pedido,convert(numeric (5,0),Secuencial) as Secuencial,convert(varchar(50),idrefaccion) as 
idrefaccion,convert(varchar(50),tiporefaccion) as tiporefaccion,convert(varchar(50),marca) as 
marca,convert(varchar(50),Unidad_Medida) as Unidad_Medida,convert(varchar(50),Grupo) as Grupo,convert(varchar(20),
Unidad_Empaque) as Unidad_Empaque,convert(varchar(50),Numero_serie) as Numero_serie,convert(varchar(50),
Codigo_barras) as Codigo_barras,convert(varchar(50),Pedimento) as Pedimento,convert(varchar(50),
case when isnull(Fecha_pedimento,'') = '' then 'ND' else Fecha_pedimento end) as 
Fecha_pedimento,convert(decimal(17,5),Costo) as Costo,convert(decimal(17,5),Precio_unitario) as 
Precio_unitario,convert(decimal(17,5),cantidad) as cantidad,convert(decimal(17,5),Factor_descuento) as 
Factor_descuento,convert(decimal(17,5),Descuento) as Descuento,convert(decimal(17,5),Factor_impuesto) as 
Factor_impuesto,convert(decimal(17,5),impuesto_iva) as impuesto_iva,convert(decimal(17,5),Total) as 
Total,convert(decimal(17, 5), utilidad) As utilidad 
into IPIN_VEN_DET_REFACCIONES 
From (select case when tmc_mpmov in ('dv','dt','dw') then '9' + tmc_ref1 else tmc_ref1 end as Factura,case when 
tmc_mpmov in ('dv','dt','dw') then tmc_fechmovdet else tmc_fechfact end as FechaFactura,tmc_ref2 
as Pedido,row_number() over (order by tmc_ref1) as secuencial,tmc_idparte as idrefaccion,tmc_grupo as tiporefaccion,
(select par_descrip2 from pnc_parametr where par_tipopara = 'DS' and par_idenpara IN('01','04')) as 
marca,isnull((select par_descrip1 from pnc_parametr where par_tipopara = 'um' and par_idenpara = pts_unimed),'') 
as Unidad_Medida,tmc_idgrupo as Grupo,isnull((select par_descrip1 from pnc_parametr where par_tipopara = 'ue' and 
par_idenpara = pts_uniemp),'') as Unidad_Empaque,NULL as Numero_serie,NULL as Codigo_barras,NULL as Pedimento,
NULL as Fecha_pedimento,abs(tmc_costopromuni) as Costo,(abs(tmc_subtotal)/abs(tmc_cantidad)) as 
Precio_unitario,tmc_cantidad as cantidad,0 as Factor_descuento,tmc_descuento as Descuento,0 as 
Factor_impuesto,tmc_iva as impuesto_iva,tmc_total as Total,case when (abs(tmc_subtotal)- abs(abs(tmc_cantidad) * 
tmc_costopromuni)) > 0 then ((abs(tmc_subtotal)- abs(abs(tmc_cantidad) * tmc_costopromuni))/tmc_subtotal) else 0 
end * 100 as utilidad from par_tmptiposmov, par_partes where pts_idparte = tmc_idparte and tmc_cveusu = 'GMI') 
as VEN_DET_REFACCIONES

go

