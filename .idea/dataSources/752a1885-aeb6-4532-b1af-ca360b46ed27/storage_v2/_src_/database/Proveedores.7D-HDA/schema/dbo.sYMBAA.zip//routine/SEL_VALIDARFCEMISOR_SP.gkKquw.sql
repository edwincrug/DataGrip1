--  [SEL_VALIDARFCEMISOR_SP] 'AU-AU-UNI-UN-TPP-19', 'SMM960209M49'
CREATE PROCEDURE [dbo].[SEL_VALIDARFCEMISOR_SP]
@ordenCompra VARCHAR(50) = ''
,@rfcEmisor VARCHAR(15) = ''
AS
BEGIN

	--valida si es plan piso
	DECLARE @empresa INT = 0, @depto INT = 0, @sucursal INT = 0 ,@ipLocal VARCHAR(20) = '', @base VARCHAR(50) = '',@server VARCHAR(50) = ''
	,@query VARCHAR(MAX) = '', @planPisoRefacciones INT = 0
	SELECT @empresa = oce_idempresa, @depto = oce_iddepartamento, @sucursal = oce_idsucursal FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_folioorden = @ordenCompra
		
	IF EXISTS(SELECT 1 FROM Centralizacionv2.dbo.DIG_CATALOGOS WHERE cat_nombre = CONVERT(VARCHAR(5),@empresa) + '|' + CONVERT(VARCHAR(5),@depto) AND cat_valor = '1')
			SET @planPisoRefacciones = 1 

	DECLARE @rfcEmi VARCHAR(15) = ''
	IF (EXISTS(SELECT 1 FROM [Centralizacionv2].[dbo].[DIG_EXP_PLAN_PISO] WHERE Folio_Alias = @ordenCompra) OR (@planPisoRefacciones = 1))
		BEGIN			--- es plan piso
			
			--DECLARE @OC_ORIGINAL VARCHAR(80) = ''

			SELECT @rfcEmisor-- @rfcEmi =
			/*LTRIM(RTRIM(PER.per_rfc)) FROM [Centralizacionv2].[dbo].[DIG_EXP_PLAN_PISO] PPISO 
								 LEFT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] OCS ON PPISO.Folio_Operacion = OCS.oce_folioorden
								 LEFT JOIN [BDPersonas].[dbo].[cat_personas] PER ON OCS.oce_idproveedor = PER.per_idpersona
								 WHERE PPISO.Folio_Alias = @ordenCompra*/			
			 
		END	
	ELSE
		BEGIN
			SELECT --@rfcEmi = 
			per_rfc FROM [GA_Corporativa].[dbo].[PER_PERSONAS]
				WHERE per_idpersona = ( SELECT oce_idproveedor FROM cuentasxpagar.dbo.cxp_ordencompra 
								WHERE oce_folioorden = @ordenCompra)
				AND UPPER(LTRIM(RTRIM(per_rfc))) = UPPER(LTRIM(RTRIM(@rfcEmisor)))
		END
		--SELECT @rfcEmi per_rfc
	END

--ALTER PROCEDURE [dbo].[SEL_VALIDARFCEMISOR_SP]
--@ordenCompra VARCHAR(20) = ''
--,@rfcEmisor VARCHAR(15) = ''
--AS
--BEGIN
--	--DECLARE @rfcEmisor VARCHAR(15) 
--		SELECT per_rfc FROM [BDPersonas].[dbo].[cat_personas]
--		WHERE per_idpersona = ( SELECT oce_idproveedor FROM cuentasxpagar.dbo.cxp_ordencompra 
--								WHERE oce_folioorden = @ordenCompra)
--		AND UPPER(LTRIM(RTRIM(per_rfc))) = UPPER(LTRIM(RTRIM(@rfcEmisor)))
--END
go

