-- =============================================
-- Author: Alejandro Lopez
-- Create date: 10/05/2016
-- Description:	Pone como estatus visto la noticia correspondiente
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ALERTA_SP]
	@rfcProveedor VARCHAR(13) = '', 
	@idTipo NUMERIC(18,0) = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
		
		UPDATE Alerta
		SET idEstatus = 2
		WHERE idTipo = @idTipo --AND CONVERT(VARCHAR(10), fecha, 103) =  CONVERT(VARCHAR(10), GETDATE(), 103)
		AND per_rfc = @rfcProveedor

		SELECT 'ok' estatus, 'Actualización correcta!' mensaje

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[UPD_ALERTA_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT ERROR_NUMBER()
END CATCH
END
go

