CREATE PROCEDURE [dbo].[UPD_ALERTAS_NOTICIASORDENES_SP]
AS

DECLARE @alertas TABLE(ID INT IDENTITY(1,1),RFC VARCHAR(15))

INSERT INTO @alertas(RFC)
SELECT per_rfc FROM Noticia WHERE idEstatus = 1

DECLARE @aux INT = 1,@total INT = 0, @rfc VARCHAR(15) = '', @count INT = 0
SELECT @total = ISNULL(MAX(ID),0) FROM @alertas

WHILE(@aux <= @total) --noticias tipo = 2
	BEGIN
		SELECT @rfc = RFC FROM @alertas WHERE ID = @aux		
		SELECT @count = COUNT(per_rfc) From Noticia WHERE per_rfc = @rfc AND idEstatus = 1 --no vista

		IF EXISTS (SELECT 1 FROM Alerta WHERE per_rfc = @rfc AND idTipo = 2)--noticias, ya existe ROW
			BEGIN
					UPDATE Alerta
					SET textoAlerta = CONVERT(VARCHAR(8),@count),
						idEstatus = 1 --no visto
					WHERE per_rfc = @rfc AND idTipo = 2
			END
		ELSE   --se inserta nuevo ROW con alerta de noticias para este RFC
			BEGIN
				INSERT INTO Alerta(idEstatus,idTipo,fecha,per_rfc,textoAlerta)
					        VALUES(1,2,GETDATE(),@rfc,CONVERT(VARCHAR(8),@count))
			END

		SET @aux = @aux + 1
	END

SELECT @count = 0, @rfc = '', @total = 0, @aux = 1
DELETE FROM @alertas
DECLARE @alertas_o TABLE(ID INT IDENTITY(1,1),RFC VARCHAR(15))

INSERT INTO @alertas_o
SELECT DISTINCT ppro_user FROM [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV]
SELECT @total = ISNULL(MAX(ID),0) FROM @alertas_o

WHILE(@aux <= @total) --alertas ordenes tipo = 1
	BEGIN
		SELECT @rfc = RFC FROM @alertas_o WHERE ID = @aux
		
		SELECT @count = COUNT(ISNULL(ordComp.oce_folioorden,0))
			FROM cuentasxpagar.dbo.cxp_ordencompra ordComp  
			LEFT JOIN cuentasxpagar.dbo.cat_tiposorden tipOrd ON ordComp.oce_idtipoorden = tipOrd.tip_idtipoorden  
			LEFT JOIN ControlAplicaciones.dbo.cat_empresas emp ON ordComp.oce_idempresa = emp.emp_idempresa  
			LEFT JOIN ControlAplicaciones.dbo.cat_sucursales suc ON ordComp.oce_idsucursal = suc.suc_idsucursal  
			LEFT JOIN ControlAplicaciones.dbo.cat_departamentos depto ON ordComp.oce_iddepartamento = depto.dep_iddepartamento  
			LEFT JOIN GA_Corporativa.dbo.PER_PERSONAS per ON per.per_idpersona = ordComp.oce_idproveedor
			LEFT JOIN proveedores.dbo.OrdenEstatusVista oeVista ON ordComp.oce_folioorden = oeVista.Folio_Operacion
			WHERE --(@monto IS NULL OR ordComp.oce_importetotal = @monto)
				  --AND (@orden IS NULL OR UPPER(ordComp.oce_folioorden) LIKE ('%' + UPPER(@orden) + '%'))
				  --AND 
				  ordComp.oce_folioorden NOT IN (SELECT folioorden FROM Centralizacionv2.dbo.PPRO_DATOSFACTURAS)				  
				  AND (ordComp.oce_uuid = '' or ordComp.oce_uuid IS NULL)
				  AND ordComp.sod_idsituacionorden IN (2,5,6,7,8)
				  AND ordComp.oce_folioorden IN (SELECT oce_folioorden FROM cuentasxpagar.dbo.cxp_ordencompra WHERE oce_idproveedor IN(
												 SELECT per_idpersona FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @rfc))
				  AND ordComp.oce_folioorden NOT IN (SELECT Folio_Operacion FROM OrdenEstatusVista)		
		
		IF(@count > 0)
			BEGIN			
					IF EXISTS (SELECT 1 FROM Alerta WHERE per_rfc = @rfc AND idTipo = 1)--ordenes, ya existe ROW
						BEGIN
								UPDATE Alerta
								SET textoAlerta = CONVERT(VARCHAR(8),@count),
									idEstatus = 1 --no visto
								WHERE per_rfc = @rfc AND idTipo = 1 --ordenes sin ver
						END
					ELSE   --se inserta nuevo ROW con alerta de noticias para este RFC
						BEGIN
							INSERT INTO Alerta(idEstatus,idTipo,fecha,per_rfc,textoAlerta)
										VALUES(1,1,GETDATE(),@rfc,CONVERT(VARCHAR(8),@count)) -- alertas de ordenes sin ver
						END
			END

			SET @aux = @aux + 1
	END
go

