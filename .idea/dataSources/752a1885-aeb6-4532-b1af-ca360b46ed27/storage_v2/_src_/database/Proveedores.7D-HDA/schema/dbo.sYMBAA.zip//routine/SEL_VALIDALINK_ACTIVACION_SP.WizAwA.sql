CREATE PROC [dbo].[SEL_VALIDALINK_ACTIVACION_SP]
@toke VARCHAR(300),
@rfcPoveedor VARCHAR(13),
@opcion int = 1 --1 mail de bienvenida, 2 mail de cambio de correo
AS
BEGIN

	DECLARE @msg VARCHAR(100) = 'Link de activación valido', @estatus VARCHAR(10) = 'ok'

	IF NOT EXISTS(SELECT 1 FROM [dbo].[CorreoActivacion] WHERE [token] = @toke AND per_rfc = @rfcPoveedor AND idEstatus = 1)
		BEGIN
			SELECT @estatus = 'error', @msg = 'Link de activación no valido.'
		END

	SELECT @estatus estatus, @msg mensaje

END

go

