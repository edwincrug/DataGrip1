 --  [dbo].5
CREATE PROCEDURE [dbo].[PPRO_GUARDADATOS_USER_REGISTRO_nuevo]    
@razonSocial VARCHAR(max) = '',
@rfc VARCHAR(50),
@correoUsuario VARCHAR(150),
@contrasena VARCHAR(50)

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
	
	DECLARE @per_idpersona SMALLINT
	DECLARE @msg VARCHAR(500) = '', @estatus VARCHAR(10) = '',@Token VARCHAR(MAX) 

	--BDPersonas.dbo.cat_personas que exista el rfc, y que no exista el rfc en PPRO_USERSPORTALPROV
				

	/*IF NOT EXISTS ( SELECT a.per_nomrazon,b.per_idpersona,b.rol_idrol FROM BDPersonas.dbo.cat_personas a 
				inner join BDPersonas.dbo.per_relacionroles b ON b.per_idpersona= a.per_idpersona
				WHERE  per_rfc=@rfc and b.rol_idrol=3)*/

	IF EXISTS(SELECT 1 FROM [GA_Corporativa].[dbo].[PER_PERSONAS] WHERE per_rfc = @rfc)
		BEGIN
			IF NOT EXISTS(SELECT 1 FROM [Centralizacionv2]..PPRO_USERSPORTALPROV WHERE ppro_user = @rfc)
				BEGIN
						INSERT INTO [Centralizacionv2]..PPRO_USERSPORTALPROV(
							ppro_idUserRol,
							ppro_user,
							ppro_pass,
							pprov_usersStatus,
							razonSocial,
							correo,
							estatus,
							fechaAlta)
						VALUES (					    											
							1,
							@rfc,
							@contrasena,
							2,--pendiente de activar
							@razonSocial,
							@correoUsuario,
							0, 
							GETDATE()
						)

						DECLARE @tokenID uniqueidentifier
						set @tokenID = newid()
						DECLARE @tokenNuevo nvarchar(max)
						SET @tokenNuevo = CAST(@tokenID AS nvarchar(max))
					
						INSERT INTO [proveedores].[dbo].[CorreoActivacion]([token],[per_rfc],[fechaCreacion],[fechaActivacion],[idEstatus])
						VALUES (@tokenID,@rfc,GETDATE(),NULL,1)

						--EXEC [proveedores].[dbo].[SEL_ACTIVACION_CORREO_SP] @rfcProveedor = @rfc,@correo = @correoUsuario,@token = @tokenID, @opcion = 1														

						SELECT @estatus = 'ok', @msg ='Proveedor con RFC: ' + @rfc + ' registrado con exito! Se ha enviado un correo para su activación a la dirección ' + @correoUsuario + '.',@Token =   @tokenNuevo
				END
			ELSE
				BEGIN
						SELECT @estatus = 'error', @msg ='Proveedor con RFC: ' + @rfc + ' ya existe. No se registro.',@Token = 'Existe'
				END
		END
	ELSE
		BEGIN
			SELECT @estatus = 'error', @msg ='Proveedor con RFC: ' + @rfc + ' no existe en el catalogo de proveedores. No se registro.',@Token =  'error'
		END	


		SELECT @estatus estatus,@msg mensaje, @Token Token
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[PPRO_GUARDADATOS_USER_REGISTRO]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje--@msg

END CATCH
END
 go

