-- =============================================
-- Author:		ALEJANDRO LOPEZ
-- Create date: 09/05/2016
-- Description:	selecciona notificaciones por provedor,tipo y estatus
-- =============================================
-- [SEL_NOTIFICACION_SP] 1,4,1
CREATE PROCEDURE [dbo].[SEL_ALERTA_SP] 
	@idEstatus numeric(18,0) = 0
	,@rfcProveedor VARCHAR(13) = ''
	,@idTipo numeric(18,0) = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	
	SELECT	idAlerta
			,idEstatus
			,idTipo
			,fecha
			,per_rfc
			,textoAlerta 
	FROM	Alerta
	WHERE  ((@rfcProveedor = '') OR (per_rfc = @rfcProveedor))
	AND ((@idEstatus = 0) OR (idEstatus = @idEstatus))
	AND ((@idTipo = 0) OR (idTipo = @idTipo))

END TRY
BEGIN CATCH
	Print('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_ALERTA_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	--SELECT 1
END CATCH
END
go

