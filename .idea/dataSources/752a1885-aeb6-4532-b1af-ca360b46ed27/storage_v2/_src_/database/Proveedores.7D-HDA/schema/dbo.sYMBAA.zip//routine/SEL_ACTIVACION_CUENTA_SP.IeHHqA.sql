

CREATE PROCEDURE [dbo].[SEL_ACTIVACION_CUENTA_SP]
@toke VARCHAR(300),
@rfcPoveedor VARCHAR(13),
@opcion int = 1 --1 activacion, 2 cambio correo
AS
BEGIN

	DECLARE @msg VARCHAR(100) = '', @estatus VARCHAR(10) = 'ok'

	IF NOT EXISTS(SELECT 1 FROM [dbo].[CorreoActivacion] WHERE [token] = @toke AND per_rfc = @rfcPoveedor AND idEstatus = 1)
		BEGIN
			SELECT @estatus = 'error', @msg = 'Link de activación no valido.'
		END
	ELSE
		BEGIN

				IF(@opcion = 1) --activar usuario
				BEGIN

					UPDATE [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV]
					SET pprov_usersStatus = 1
					WHERE ppro_user = @rfcPoveedor

					SELECT @estatus = 'ok', @msg = 'El usuario ' + @rfcPoveedor + ' ha sido activado.'	

				END

				IF(@opcion = 2)--actualizar correo
				BEGIN					
					
					UPDATE [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV]
					SET correo = correoTemporal,
						correoTemporal = NULL
					WHERE [ppro_user] = @rfcPoveedor

					SELECT @estatus = 'ok', @msg = 'Ha sido actualizado el correo del usuario ' + @rfcPoveedor + '.'	

				END

				UPDATE [dbo].[CorreoActivacion]
				SET fechaActivacion = GETDATE(), idEstatus = 2
				WHERE [token] = @toke AND per_rfc = @rfcPoveedor
		END	

	SELECT @estatus estatus, @msg mensaje

END

go

