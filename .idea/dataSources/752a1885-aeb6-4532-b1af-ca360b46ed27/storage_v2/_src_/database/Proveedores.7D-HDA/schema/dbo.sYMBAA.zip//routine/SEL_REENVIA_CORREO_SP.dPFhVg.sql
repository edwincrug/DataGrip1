
CREATE PROCEDURE [dbo].[SEL_REENVIA_CORREO_SP] --SEL_REENVIA_CORREO_SP 'ACM850712MW2'
@rfcPoveedorP VARCHAR(13) = ''
AS
BEGIN
	
	DECLARE @msg VARCHAR(100) = 'Se reenvio el correo correctamente.' , @estatus VARCHAR(10) = 'ok'

BEGIN TRY	

	DECLARE @correoUser VARCHAR(100) = '', @tokenID uniqueidentifier
	SET @tokenID = NEWID()

	SELECT @correoUser = [correo] FROM [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV] WHERE [ppro_user] = @rfcPoveedorP

	UPDATE [dbo].[CorreoActivacion]
	SET [token] = @tokenID
	WHERE per_rfc = @rfcPoveedorP
	
	EXEC [proveedores].[dbo].[SEL_ACTIVACION_CORREO_SP] @rfcProveedor = @rfcPoveedorP,@correo = @correoUser,@token = @tokenID, @opcion = 1
	
	SELECT @estatus estatus, @msg mensaje

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_REENVIA_CORREO_SP'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje--@msg

END CATCH
END
go

