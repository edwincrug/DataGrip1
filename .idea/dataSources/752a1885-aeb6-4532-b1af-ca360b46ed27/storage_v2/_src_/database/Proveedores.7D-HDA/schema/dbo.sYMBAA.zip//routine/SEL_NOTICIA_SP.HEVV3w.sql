-- =============================================
-- Author:		ALEJANDRO LOPEZ
-- Create date: 09/05/2016
-- Description:	selecciona noticias por provedor y estatus
-- =============================================
-- [SEL_NOTICIA_SP] 1, 4
CREATE PROCEDURE [dbo].[SEL_NOTICIA_SP] 
	@idEstatus numeric(18,0) = 0
	,@rfcProveedor varchar(13) = ''
	,@idTipo numeric(18,0) = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	
	SELECT  idNoticia
			,fecha
			,textoNoticia
			,idEstatus
			,per_rfc
			,idTipo
			,titulo
			,descripcion
			,urlImagen
	FROM Noticia
	WHERE ((@rfcProveedor = '') OR (per_rfc = @rfcProveedor))  
	AND ((@idEstatus = 0) OR (idEstatus = @idEstatus))
	AND ((@idTipo = 0) OR (idTipo = @idTipo))
	ORDER BY idEstatus ASC

END TRY
BEGIN CATCH
	Print('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_NOTICIA_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

