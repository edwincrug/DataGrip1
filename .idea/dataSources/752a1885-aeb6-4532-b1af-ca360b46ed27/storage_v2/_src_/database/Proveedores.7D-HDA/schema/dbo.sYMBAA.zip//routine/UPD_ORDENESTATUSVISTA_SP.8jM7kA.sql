-- =============================================
-- Author: Alejandro Lopez
-- Create date: 09/05/2016
-- Description:	Pone como estatus visto las ordenes de compra
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ORDENESTATUSVISTA_SP]	
	@Folio_Operacion VARCHAR(80) = ''
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	

		IF NOT EXISTS(SELECT 1 FROM OrdenEstatusVista WHERE [Folio_Operacion] = @Folio_Operacion)
		BEGIN
			INSERT INTO OrdenEstatusVista
			VALUES (@Folio_Operacion)
		END

		SELECT 0

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[UPD_ORDENESTATUSVISTA_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT ERROR_NUMBER()
END CATCH
END
go

