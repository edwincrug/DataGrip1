-- =============================================
-- Author: Alejandro Lopez
-- Create date: 10/05/2016
-- Description:	Pone como estatus visto la noticia correspondiente
-- =============================================
CREATE PROCEDURE [dbo].[UPD_NOTICIAESTATUSVISTA_SP]
	@idNoticia NUMERIC(18,0) = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	

		UPDATE [dbo].[Noticia]
		SET idEstatus = 2
		WHERE idNoticia = @idNoticia		

		SELECT 'ok' estatus, 'Noticia vista' mensaje

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[UPD_NOTICIAESTATUSVISTA_SP]'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus, ERROR_MESSAGE() mensaje
END CATCH
END
go

