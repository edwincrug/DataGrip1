-- =============================================
-- Author:		ALEJANDRO LOPEZ
-- Create date: 09/05/2016
-- Description:	selecciona noticias por provedor y estatus
-- =============================================
-- [SEL_ORDENESTATUSVISTA_SP] 1, ''
CREATE PROCEDURE [dbo].[SEL_ORDENESTATUSVISTA_SP] 	
	@Folio_Operacion VARCHAR(80) = ''	
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	
	SELECT idOrdenEstatusVista
			,Folio_Operacion 
	FROM OrdenEstatusVista
	WHERE ((Folio_Operacion = '') OR (Folio_Operacion = @Folio_Operacion))  	

END TRY
BEGIN CATCH
	Print('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_ORDENESTATUSVISTA_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

