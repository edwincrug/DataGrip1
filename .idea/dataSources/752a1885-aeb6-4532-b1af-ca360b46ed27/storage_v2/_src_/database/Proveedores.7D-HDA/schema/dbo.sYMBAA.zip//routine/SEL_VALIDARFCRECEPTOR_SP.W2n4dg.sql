CREATE PROCEDURE [dbo].[SEL_VALIDARFCRECEPTOR_SP]
@ordenCompra VARCHAR(50) = ''
,@rfcReceptor VARCHAR(15) = ''
AS

DECLARE @rcfEmpresa VARCHAR

SELECT rfc FROM Centralizacionv2..DIG_CAT_BASES_BPRO 
		 WHERE catemp_nombrecto = (SELECT emp_nombrecto FROM ControlAplicaciones.dbo.cat_empresas 
								   WHERE emp_idempresa = (SELECT oce_idempresa FROM cuentasxpagar.dbo.cxp_ordencompra 
														  WHERE oce_folioorden = @ordenCompra)) 
		 AND catsuc_nombrecto = 'CONCENTRA'
		  AND rfc LIKE '%' + @rfcReceptor + '%'
		 --AND UPPER(LTRIM(RTRIM(rfc))) = UPPER(LTRIM(RTRIM(@rfcReceptor)))


go

