-- =============================================
-- Author:		Lourdes Maldonado Sanchez
-- Create date: 16/05/2018
-- Description:	Alerta
-- =============================================
-- EXECUTE [SEL_ALERTA_UUID_SP] '93C85074-4100-4101-A7E6-31114CC2DB96'
Create PROCEDURE [dbo].[SEL_ALERTA_UUID_SP] 
	@uuid varchar(50)=''
	
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	 DECLARE @msj varchar(200)= 'disponible'
	 DECLARE @folio   varchar(50) = ''
	 DECLARE @conteo  int = 0
	 	 
	 IF EXISTS ( SELECT [folioorden] FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS] WHERE [uuid] = @uuid )
	 BEGIN
	    SELECT  @folio =  [folioorden]
	      FROM [Centralizacionv2].[dbo].[PPRO_DATOSFACTURAS]
	     WHERE [uuid] = @uuid
		
		SET @msj = 'UUID Registrado con la Orden de compra: '+ @folio +'. Los archivos no fueron registrados.'		
	 END

	 SELECT  @msj as mensaje
	 
     	
END TRY
BEGIN CATCH
	Print('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_ALERTA_UUID_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END
go

