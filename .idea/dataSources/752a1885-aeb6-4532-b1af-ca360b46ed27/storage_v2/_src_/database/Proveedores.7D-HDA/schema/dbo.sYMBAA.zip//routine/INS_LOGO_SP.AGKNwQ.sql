-- =============================================
-- Author:		Alejandro Lopez Quiroz
-- Create date: 23/05/2016
-- Modified date: 
-- Description: Inserta el logo por proveedor(usuario)
-- =============================================
--execute [INS_FACTURA_ENTREGA_SP] 'AU-ZM-ZAR-SE-PE-32', 1,0
CREATE PROCEDURE [dbo].[INS_LOGO_SP]
	 @usuario VARCHAR(15) = ''
	,@tipo VARCHAR(10) = ''
AS
BEGIN
	
	BEGIN TRY
			
			UPDATE [Centralizacionv2].[dbo].[PPRO_USERSPORTALPROV]
			SET urlLogo = @tipo
			WHERE ppro_user = @usuario

			SELECT 'ok' estatus, 'Logo guardado correctamente.' mensaje

	END TRY
	BEGIN CATCH
		/*PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = '[INS_CIERRA_NODO_SP]'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; */
		SELECT 'error' estatus, ERROR_MESSAGE() mensaje
	END CATCH
		
END
go

