create view [dbo].[ADE_CANCFDDET] as select * from GAAAF_Concentra.dbo.ADE_CANCFDDET
go

