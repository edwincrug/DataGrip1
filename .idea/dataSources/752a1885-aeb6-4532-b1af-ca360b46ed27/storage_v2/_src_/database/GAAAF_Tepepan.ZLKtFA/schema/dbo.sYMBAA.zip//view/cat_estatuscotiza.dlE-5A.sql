---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[cat_estatuscotiza] AS 
SELECT
cec_idestatuscotiza, cec_nombrecorto, cec_nombre, cec_descripcion, cec_idusuarioalta, cec_fechaalta, cec_idusuariomodifica, cec_fechamodifica
FROM        cuentasporcobrar.dbo.cat_estatuscotiza;
go

