create view [dbo].[SQC_Servicio_Excepciones] as select * from GAAAF_Concentra.dbo.SQC_Servicio_Excepciones
go

