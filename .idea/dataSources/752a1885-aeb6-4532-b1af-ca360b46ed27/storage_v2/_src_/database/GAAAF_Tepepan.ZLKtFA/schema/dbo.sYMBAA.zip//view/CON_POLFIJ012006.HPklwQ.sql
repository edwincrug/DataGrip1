create view 	[dbo].[CON_POLFIJ012006]	 as select * from GAAAF_Concentra.dbo.CON_POLFIJ012006
go

