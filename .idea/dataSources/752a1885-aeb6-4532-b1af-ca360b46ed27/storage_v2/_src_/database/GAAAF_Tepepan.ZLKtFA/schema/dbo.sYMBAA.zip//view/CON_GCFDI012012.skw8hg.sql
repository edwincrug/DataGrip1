create view [dbo].[CON_GCFDI012012] as select * from [GAAAF_Concentra].dbo.[CON_GCFDI012012]
go

