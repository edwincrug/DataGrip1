CREATE VIEW [dbo].[cat_tiporelacion] AS Select * From GAAAF_CONCENTRA.dbo.cat_tiporelacion
go

