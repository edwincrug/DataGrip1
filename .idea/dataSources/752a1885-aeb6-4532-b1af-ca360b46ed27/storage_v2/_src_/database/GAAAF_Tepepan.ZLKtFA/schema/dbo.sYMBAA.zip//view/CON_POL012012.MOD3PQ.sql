create view 	[dbo].[CON_POL012012]	 as select * from GAAAF_Concentra.dbo.CON_POL012012
go

