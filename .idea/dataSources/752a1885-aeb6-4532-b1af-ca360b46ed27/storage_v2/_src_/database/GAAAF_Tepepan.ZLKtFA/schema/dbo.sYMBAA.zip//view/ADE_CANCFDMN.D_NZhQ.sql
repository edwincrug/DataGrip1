create view [dbo].[ADE_CANCFDMN] as select * from GAAAF_Concentra.dbo.ADE_CANCFDMN
go

