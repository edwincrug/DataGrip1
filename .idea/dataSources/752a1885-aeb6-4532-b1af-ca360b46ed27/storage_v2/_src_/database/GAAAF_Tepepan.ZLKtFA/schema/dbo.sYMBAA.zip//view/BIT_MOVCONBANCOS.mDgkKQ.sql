-- vista en operativa con relacion a concentradora

CREATE VIEW [dbo].[BIT_MOVCONBANCOS]
AS
SELECT * FROM GAAAF_Concentra.DBO.BIT_MOVCONBANCOS
go

