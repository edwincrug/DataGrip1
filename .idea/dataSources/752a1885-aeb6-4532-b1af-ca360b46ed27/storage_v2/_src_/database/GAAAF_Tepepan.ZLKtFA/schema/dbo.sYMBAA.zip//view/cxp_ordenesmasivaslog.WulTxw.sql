Create View [dbo].[cxp_ordenesmasivaslog] as select * from [GAAAF_Concentra].dbo.cxp_ordenesmasivaslog
go

