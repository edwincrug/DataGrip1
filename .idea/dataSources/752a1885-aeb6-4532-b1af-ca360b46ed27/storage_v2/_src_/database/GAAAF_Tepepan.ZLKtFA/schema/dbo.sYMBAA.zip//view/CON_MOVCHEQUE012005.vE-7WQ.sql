create view [dbo].[CON_MOVCHEQUE012005] as select * from GAAAF_Concentra.dbo.CON_MOVCHEQUE012005
go

