CREATE VIEW [dbo].[ade_cfditimbrado] AS SELECT * FROM GAAAF_Concentra.dbo.ade_cfditimbrado
go

