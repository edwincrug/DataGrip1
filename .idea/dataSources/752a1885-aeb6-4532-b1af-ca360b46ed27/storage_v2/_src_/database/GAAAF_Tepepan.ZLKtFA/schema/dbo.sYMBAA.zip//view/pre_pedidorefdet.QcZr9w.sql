CREATE VIEW [dbo].[pre_pedidorefdet]
AS
SELECT prd_idpedidorefdet, prd_codigoparte, prd_cantidad, prd_montodescuento, prd_idusuario, prd_fecha, pre_idpedidoref,
spd_idsituacionpedidodet, prd_cantidadsolicitada, pdr_preciounitario
FROM PortalRefacciones.dbo.pre_pedidorefdet
go

