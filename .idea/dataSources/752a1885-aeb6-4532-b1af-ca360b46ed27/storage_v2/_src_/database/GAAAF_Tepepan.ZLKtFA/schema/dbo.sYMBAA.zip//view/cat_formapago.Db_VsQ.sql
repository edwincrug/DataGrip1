CREATE VIEW [dbo].[cat_formapago] AS Select * From GAAAF_CONCENTRA.dbo.cat_formapago

