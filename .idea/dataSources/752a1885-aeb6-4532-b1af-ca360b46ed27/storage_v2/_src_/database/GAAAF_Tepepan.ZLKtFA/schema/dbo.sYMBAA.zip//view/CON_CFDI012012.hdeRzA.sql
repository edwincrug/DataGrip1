create view [dbo].[CON_CFDI012012] as select * from [GAAAF_Concentra].dbo.[con_cfdi012012]
go

