CREATE VIEW [dbo].[cat_grupos]
AS
SELECT 
gpo_idgrupo, gpo_nombre, gpo_nombrecto, gpo_paginaweb, gpo_ipdb, gpo_nombrebd, gpo_fechaalta, gpo_usualta, gpo_fechamodifica, gpo_usumodifica, gpo_estatus
FROM       [ControlAplicaciones].dbo.cat_grupos
go

