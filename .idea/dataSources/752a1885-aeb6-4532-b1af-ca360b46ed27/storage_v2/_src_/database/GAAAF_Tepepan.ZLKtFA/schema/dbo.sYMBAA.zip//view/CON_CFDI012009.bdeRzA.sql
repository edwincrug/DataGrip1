create view [dbo].[CON_CFDI012009] as select * from [GAAAF_Concentra].dbo.[con_cfdi012009]
go

