create view [dbo].[SER_PAQRPT] as select * from GAAAF_Concentra.dbo.SER_PAQRPT
go

