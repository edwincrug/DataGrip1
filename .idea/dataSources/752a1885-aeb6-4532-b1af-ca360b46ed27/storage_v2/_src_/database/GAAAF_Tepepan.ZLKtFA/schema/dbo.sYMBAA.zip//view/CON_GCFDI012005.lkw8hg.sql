create view [dbo].[CON_GCFDI012005] as select * from [GAAAF_Concentra].dbo.[CON_GCFDI012005]
go

