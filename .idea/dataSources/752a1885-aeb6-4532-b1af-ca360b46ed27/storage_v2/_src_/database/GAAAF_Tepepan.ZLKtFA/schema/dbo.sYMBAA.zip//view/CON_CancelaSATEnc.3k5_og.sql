
CREATE VIEW [dbo].[CON_CancelaSATEnc] AS SELECT * FROM GAAAF_Concentra.dbo.CON_CancelaSATEnc
go

