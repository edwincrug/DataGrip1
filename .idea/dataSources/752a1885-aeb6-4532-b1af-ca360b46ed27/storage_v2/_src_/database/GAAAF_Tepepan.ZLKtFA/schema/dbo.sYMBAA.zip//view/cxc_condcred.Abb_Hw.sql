create view [dbo].[cxc_condcred] as select * from GAAAF_CONCENTRA.dbo.cxc_condcred
go

