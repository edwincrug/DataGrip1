CREATE VIEW [dbo].[cat_claveunidad] AS Select * From GAAAF_CONCENTRA.dbo.cat_claveunidad
go

