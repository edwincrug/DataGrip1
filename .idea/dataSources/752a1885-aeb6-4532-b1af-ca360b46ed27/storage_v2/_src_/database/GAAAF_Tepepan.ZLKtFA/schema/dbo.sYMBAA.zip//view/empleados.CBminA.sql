create view [dbo].[empleados] AS 
SELECT NOM_PERSO2.pe2_cveemp, 
    NOM_PERSO2.pe2_idpersona, NOM_PERSO2.pe2_imss, 
    Par_INTipoNomi.PAR_DESCRIP1 AS pe2_tipnomi, 
    Par_ICTipoCont.PAR_DESCRIP1 AS pe2_tipocontra, 
    NOM_PERSO2.pe2_fecingre, NOM_PERSO2.pe2_saldiario, 
    NOM_PERSO2.pe2_saldiainte, NOM_PERSO2.pe2_fecsalario, 
    NOM_PERSO2.pe2_fechsaldia, 
    Par_TGTipoPago.PAR_DESCRIP1 AS pe2_tipopago, 
    Par_BABanco.PAR_DESCRIP1 AS pe2_banpago, 
    Par_TUTipoCta.PAR_DESCRIP1 AS pe2_tipocta, 
    NOM_PERSO2.pe2_numcta, NOM_PERSO2.pe2_horaentrada, 
    NOM_PERSO2.pe2_horsalcomer, 
    NOM_PERSO2.pe2_horentcomer, 
    NOM_PERSO2.pe2_horsalida, NOM_PERSO2.pe2_checa, 
    Par_TETipoEmple.PAR_DESCRIP1 AS pe2_tipoemple, 
    Par_ISTipoSalario.PAR_DESCRIP1 AS pe2_tiposalario, 
    NOM_PERSO2.pe2_lugnaci, 
    Par_PSNacionali.PAR_DESCRIP1 AS pe2_nacionali, 
    Par_REReligión.PAR_DESCRIP1 AS pe2_religion, 
    NOM_PERSO2.pe2_estatura, NOM_PERSO2.pe2_peso, 
    Par_MUManousa.PAR_DESCRIP1 AS pe2_manousa, 
    Par_CEComplexion.PAR_DESCRIP1 AS pe2_complex, 
    NOM_PERSO2.pe2_señparticu, NOM_PERSO2.pe2_casaprop, 
    NOM_PERSO2.pe2_infonavit, NOM_PERSO2.pe2_nocredinf, 
    NOM_PERSO2.pe2_valinftab, NOM_PERSO2.pe2_valinfpor, 
    NOM_PERSO2.pe2_valinfmon, NOM_PERSO2.pe2_comopag, 
    NOM_PERSO2.pe2_pagRenta, NOM_PERSO2.pe2_rentmont, 
    NOM_PERSO2.pe2_maneja, NOM_PERSO2.pe2_numlicencia, 
    NOM_PERSO2.pe2_numcartilla, 
    NOM_PERSO2.pe2_numcreele, 
    NOM_PERSO2.pe2_numformig, NOM_PERSO2.pe2_tieauto, 
    Par_PVPervive.PAR_DESCRIP1 AS pe2_pervive, 
    Par_CCEdoSalAct.PAR_DESCRIP1 AS pe2_estsalact, 
    NOM_PERSO2.pe2_padenfer, NOM_PERSO2.pe2_enfpadecio, 
    Par_TNTipSangre.PAR_DESCRIP1 AS pe2_tipsangre, 
    NOM_PERSO2.pe2_nivtabaco, 
    Par_NCNumCigarr.PAR_DESCRIP1 AS pe2_numtabac, 
    NOM_PERSO2.pe2_nivalchol, 
    Par_FBFrecBeber.PAR_DESCRIP1 AS pe2_frebebe, 
    NOM_PERSO2.pe2_resfisicas, NOM_PERSO2.pe2_resfisexp, 
    Par_LVNivelVista.PAR_DESCRIP1 AS pe2_nivvista, 
    Par_NANivelAudi.PAR_DESCRIP1 AS pe2_nivadu, 
    NOM_PERSO2.pe2_alergi, NOM_PERSO2.pe2_alecual, 
    NOM_PERSO2.pe2_fobias, NOM_PERSO2.pe2_cuafobias, 
    Par_NPNivelPresSan.PAR_DESCRIP1 AS pe2_presangui, 
    NOM_PERSO2.pe2_comdatper, 
    NOM_PERSO2.pe2_comsalhabper, 
    NOM_PERSO2.pe2_depprac, NOM_PERSO2.pe2_aficiones, 
    Par_CSClubSoc.PAR_DESCRIP1 AS pe2_clubsoc, 
    Par_CRClubDepvo.PAR_DESCRIP1 AS pe2_clubdep, 
    NOM_PERSO2.pe2_pasatiempre, 
    NOM_PERSO2.pe2_escolaridad2, 
    NOM_PERSO2.pe2_especialidad, 
    NOM_PERSO2.pe2_nominstituto, 
    NOM_PERSO2.pe2_ubicacioninst, NOM_PERSO2.pe2_grado, 
    NOM_PERSO2.pe2_gradode, NOM_PERSO2.pe2_gradoa, 
    NOM_PERSO2.pe2_otrestu, NOM_PERSO2.pe2_cualotrestu, 
    Par_AFAfore.PAR_DESCRIP1 AS pe2_afoban, 
    NOM_PERSO2.pe2_afore, NOM_PERSO2.pe2_comexplab, 
    NOM_PERSO2.pe2_ultpuedes1, NOM_PERSO2.pe2_perinitra1, 
    NOM_PERSO2.pe2_perfintra1, 
    NOM_PERSO2.pe2_emplaboro1, 
    NOM_PERSO2.pe2_giroemp1, NOM_PERSO2.pe2_domemp1, 
    NOM_PERSO2.pe2_telemp1, 
    NOM_PERSO2.pe2_labdesempe1, 
    NOM_PERSO2.pe2_logrorecient1, 
    NOM_PERSO2.pe2_ultpuedes2, NOM_PERSO2.pe2_perinitra2, 
    NOM_PERSO2.pe2_perfintra2, 
    NOM_PERSO2.pe2_emplaboro2, 
    NOM_PERSO2.pe2_giroemp2, NOM_PERSO2.pe2_domemp2, 
    NOM_PERSO2.pe2_telemp2, 
    NOM_PERSO2.pe2_labdesempe2, 
    NOM_PERSO2.pe2_logrorecient2, 
    NOM_PERSO2.pe2_ultpuedes3, NOM_PERSO2.pe2_perinitra3, 
    NOM_PERSO2.pe2_perfintra3, 
    NOM_PERSO2.pe2_emplaboro3, 
    NOM_PERSO2.pe2_giroemp3, NOM_PERSO2.pe2_domemp3, 
    NOM_PERSO2.pe2_telemp3, 
    NOM_PERSO2.pe2_labdesempe3, 
    NOM_PERSO2.pe2_logrorecient3, 
    NOM_PERSO2.pe2_comfinales, NOM_PERSO2.pe2_expecono, 
    NOM_PERSO2.pe2_cveusu, NOM_PERSO2.pe2_fechope, 
    NOM_PERSO2.pe2_aptilaboral1, 
    NOM_PERSO2.pe2_actisobre1, NOM_PERSO2.pe2_intprofe1, 
    NOM_PERSO2.pe2_aptilaboral2, 
    NOM_PERSO2.pe2_actisobre2, NOM_PERSO2.pe2_intprofe2, 
    NOM_PERSO2.pe2_aptilaboral3, 
    NOM_PERSO2.pe2_actisobre3, NOM_PERSO2.pe2_intprofe3, 
    Par_ZVVivZona.PAR_DESCRIP1 AS pe2_idvivzona, 
    Par_LCClaseCol.PAR_DESCRIP1 AS pe2_idclasecol, 
    Par_NVTieneVehi.PAR_DESCRIP1 AS pe2_idtieneveh, 
    NOM_PERSO2.pe2_marcaveh, NOM_PERSO2.pe2_submarca, 
    NOM_PERSO2.pe2_modelo, 
    Par_DTMedioTrans.PAR_DESCRIP1 AS pe2_idtranspo, 
    NOM_PERSO2.pe2_tiemtrans
FROM NOM_PERSO2 LEFT OUTER JOIN
    PNC_PARAMETR Par_INTipoNomi ON 
    NOM_PERSO2.pe2_tipnomi = Par_INTipoNomi.PAR_IDENPARA LEFT
     OUTER JOIN
    PNC_PARAMETR Par_ICTipoCont ON 
    NOM_PERSO2.pe2_tipocontra = Par_ICTipoCont.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_TGTipoPago ON 
    NOM_PERSO2.pe2_tipopago = Par_TGTipoPago.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_BABanco ON 
    NOM_PERSO2.pe2_banpago = Par_BABanco.PAR_IDENPARA LEFT
     OUTER JOIN
    PNC_PARAMETR Par_TUTipoCta ON 
    NOM_PERSO2.pe2_tipocta = Par_TUTipoCta.PAR_IDENPARA LEFT
     OUTER JOIN
    PNC_PARAMETR Par_TETipoEmple ON 
    NOM_PERSO2.pe2_tipoemple = Par_TETipoEmple.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_ISTipoSalario ON 
    NOM_PERSO2.pe2_tiposalario = Par_ISTipoSalario.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_PSNacionali ON 
    NOM_PERSO2.pe2_nacionali = Par_PSNacionali.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_REReligión ON 
    NOM_PERSO2.pe2_religion = Par_REReligión.PAR_IDENPARA LEFT
     OUTER JOIN
    PNC_PARAMETR Par_MUManousa ON 
    NOM_PERSO2.pe2_manousa = Par_MUManousa.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_CEComplexion ON 
    NOM_PERSO2.pe2_complex = Par_CEComplexion.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_PVPervive ON 
    NOM_PERSO2.pe2_pervive = Par_PVPervive.PAR_IDENPARA LEFT
     OUTER JOIN
    PNC_PARAMETR Par_CCEdoSalAct ON 
    NOM_PERSO2.pe2_estsalact = Par_CCEdoSalAct.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_TNTipSangre ON 
    NOM_PERSO2.pe2_tipsangre = Par_TNTipSangre.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_NCNumCigarr ON 
    NOM_PERSO2.pe2_numtabac = Par_NCNumCigarr.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_FBFrecBeber ON 
    NOM_PERSO2.pe2_frebebe = Par_FBFrecBeber.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_LVNivelVista ON 
    NOM_PERSO2.pe2_nivvista = Par_LVNivelVista.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_NANivelAudi ON 
    NOM_PERSO2.pe2_nivadu = Par_NANivelAudi.PAR_IDENPARA LEFT
     OUTER JOIN
    PNC_PARAMETR Par_NPNivelPresSan ON 
    NOM_PERSO2.pe2_presangui = Par_NPNivelPresSan.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_CSClubSoc ON 
    NOM_PERSO2.pe2_clubsoc = Par_CSClubSoc.PAR_IDENPARA LEFT
     OUTER JOIN
    PNC_PARAMETR Par_CRClubDepvo ON 
    NOM_PERSO2.pe2_clubdep = Par_CRClubDepvo.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_AFAfore ON 
    NOM_PERSO2.pe2_afoban = Par_AFAfore.PAR_IDENPARA LEFT OUTER
     JOIN
    PNC_PARAMETR Par_ZVVivZona ON 
    NOM_PERSO2.pe2_idvivzona = Par_ZVVivZona.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_LCClaseCol ON 
    NOM_PERSO2.pe2_idclasecol = Par_LCClaseCol.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_NVTieneVehi ON 
    NOM_PERSO2.pe2_idtieneveh = Par_NVTieneVehi.PAR_IDENPARA
     LEFT OUTER JOIN
    PNC_PARAMETR Par_DTMedioTrans ON 
    NOM_PERSO2.pe2_idtranspo = Par_DTMedioTrans.PAR_IDENPARA
WHERE (Par_INTipoNomi.PAR_TIPOPARA = 'IN') AND 
    (Par_ICTipoCont.PAR_TIPOPARA = 'IC') AND 
    (Par_TGTipoPago.PAR_TIPOPARA = 'TG') AND 
    (Par_BABanco.PAR_TIPOPARA = 'BA') AND 
    (Par_TUTipoCta.PAR_TIPOPARA = 'TU') AND 
    (Par_TETipoEmple.PAR_TIPOPARA = 'TE') AND 
    (Par_ISTipoSalario.PAR_TIPOPARA = 'IS') AND 
    (Par_PSNacionali.PAR_TIPOPARA = 'PS') AND 
    (Par_REReligión.PAR_TIPOPARA = 'RE') AND 
    (Par_MUManousa.PAR_TIPOPARA = 'MU') AND 
    (Par_CEComplexion.PAR_TIPOPARA = 'CE') AND 
    (Par_PVPervive.PAR_TIPOPARA = 'PV') AND 
    (Par_CCEdoSalAct.PAR_TIPOPARA = 'CC') AND 
    (Par_TNTipSangre.PAR_TIPOPARA = 'TN') AND 
    (Par_NCNumCigarr.PAR_TIPOPARA = 'NC') AND 
    (Par_FBFrecBeber.PAR_TIPOPARA = 'FB') AND 
    (Par_LVNivelVista.PAR_TIPOPARA = 'LV') AND 
    (Par_NANivelAudi.PAR_TIPOPARA = 'NA') AND 
    (Par_NPNivelPresSan.PAR_TIPOPARA = 'NP') AND 
    (Par_CSClubSoc.PAR_TIPOPARA = 'CS') AND 
    (Par_CRClubDepvo.PAR_TIPOPARA = 'CR') AND 
    (Par_AFAfore.PAR_TIPOPARA = 'AF') AND 
    (Par_ZVVivZona.PAR_TIPOPARA = 'ZV') AND 
    (Par_LCClaseCol.PAR_TIPOPARA = 'LC') AND 
    (Par_NVTieneVehi.PAR_TIPOPARA = 'NV') AND 
    (Par_DTMedioTrans.PAR_TIPOPARA = 'DT')
go

