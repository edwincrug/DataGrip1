CREATE  PROC SICOP_NORMALIZA_DIAS_VENTA_PARA_ROP
AS
BEGIN
DECLARE @FechaContacto datetime
DECLARE @FechaVenta datetime
DECLARE @IdCotizacion Int
DECLARE @C_prospecto nvarchar(15)
DECLARE @Sn nvarchar(1000)
DECLARE @Ejecutado nvarchar(1)
SET @Ejecutado =(SELECT Valor_2 from SICOP_CONF_MODS where Modulo='ENVIO_DATOS' and PARAMETRO='ACT_REG')
IF @Ejecutado is Null or @Ejecutado=0
BEGIN
DECLARE Regs_Venta Cursor
FOR
   SELECT [Número de cotización], [Fecha de entrega] FROM [TESTIMONIO DE VENTA] ORDER BY [FECHA DE ENTREGA] DESC
    OPEN Regs_venta
      FETCH NEXT FROM  Regs_venta INTO @IdCotizacion, @FechaVenta
        WHILE @@FETCH_STATUS = 0
          BEGIN
            Set @C_Prospecto =(Select [Clave Prospecto] from [Cotizaciones y pedidos] where [Número de cotización]=@IdCotizacion )
            Set @FechaContacto = (Select [Fecha de registro] From Prospecto where C_Clave=@C_Prospecto)
          Update
      [TESTIMONIO DE VENTA]
          Set
      DiasVenta=  datediff(d,@FechaContacto,@FechaVenta)
      Where
        [Número de cotización] =@IdCotizacion
             FETCH NEXT FROM  Regs_venta INTO @IdCotizacion, @FechaVenta
          End
   Close Regs_Venta
   DEALLOCATE Regs_Venta
  update Sicop_Conf_mods set Valor_2=1 where Modulo='ENVIO_DATOS' and PARAMETRO='ACT_REG'
  UPDATE [TESTIMONIO DE VENTA] SET DiasVenta=0  WHERE DiasVenta IS NULL
   End
End
go

