create view [dbo].[SQC_Servicio_99] as select * from GAAAF_Concentra.dbo.SQC_Servicio_99
go

