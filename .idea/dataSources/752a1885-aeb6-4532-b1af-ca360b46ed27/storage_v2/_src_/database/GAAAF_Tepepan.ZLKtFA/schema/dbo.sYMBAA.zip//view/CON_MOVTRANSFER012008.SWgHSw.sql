create view [dbo].[CON_MOVTRANSFER012008] as select * from GAAAF_Concentra.dbo.CON_MOVTRANSFER012008
go

