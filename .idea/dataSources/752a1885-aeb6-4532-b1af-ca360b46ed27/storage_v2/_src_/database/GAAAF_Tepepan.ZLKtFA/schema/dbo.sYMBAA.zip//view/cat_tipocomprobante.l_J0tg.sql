CREATE VIEW [dbo].[cat_tipocomprobante] AS Select * From GAAAF_CONCENTRA.dbo.cat_tipocomprobante
go

