CREATE VIEW [dbo].[cat_politicaventas]
AS
SELECT 
pvt_idpoliticaventa, pvt_idgrupo, pvt_iddivision, pvt_idempresa, pvt_tipo, pvt_porcentaje, pvt_monto, pvt_estatus, pvt_tipovehiculo
FROM [GA_Corporativa].dbo.cat_politicaventas
go

