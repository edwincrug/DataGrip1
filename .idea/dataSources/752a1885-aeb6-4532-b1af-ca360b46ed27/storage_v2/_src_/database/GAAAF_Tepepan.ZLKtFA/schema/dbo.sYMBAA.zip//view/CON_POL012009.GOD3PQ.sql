create view 	[dbo].[CON_POL012009]	 as select * from GAAAF_Concentra.dbo.CON_POL012009
go

