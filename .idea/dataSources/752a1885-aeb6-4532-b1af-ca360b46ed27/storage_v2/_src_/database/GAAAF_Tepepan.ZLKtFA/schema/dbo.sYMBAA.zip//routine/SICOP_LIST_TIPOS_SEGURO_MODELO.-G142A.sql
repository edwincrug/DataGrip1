 Create proc SICOP_LIST_TIPOS_SEGURO_MODELO
 @Modelo Nvarchar( 15 ),
 @Ano Nvarchar( 4 )
 As
 SELECT
  Distinct
    B.Clave_paquete AS C_Clave,
    A.Descripcion AS N_Descripcion
 From
    SICOP_Seguros_Planes AS B,
     SICOP_TIPOS_SEGURO As a
 Where
   B.Clave_paquete=[A].[C_Clave]  and
   b.C_Producto=@Modelo and
   Año=@Ano
 Order By
  a.Descripcion
 go

