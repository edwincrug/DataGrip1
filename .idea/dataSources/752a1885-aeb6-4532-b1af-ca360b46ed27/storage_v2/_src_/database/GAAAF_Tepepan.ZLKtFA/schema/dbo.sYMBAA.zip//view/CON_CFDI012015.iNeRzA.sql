create view [dbo].[CON_CFDI012015] as select * from [GAAAF_Concentra].dbo.[con_cfdi012015]
go

