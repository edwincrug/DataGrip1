create view [dbo].[ADE_CFDI] as select * from GAAAF_Concentra.dbo.ADE_CFDI
go

