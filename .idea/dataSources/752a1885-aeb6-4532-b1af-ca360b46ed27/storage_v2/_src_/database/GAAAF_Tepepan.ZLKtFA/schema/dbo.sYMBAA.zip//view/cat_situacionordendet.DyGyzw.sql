CREATE VIEW [dbo].[cat_situacionordendet] AS   SELECT   sde_idsituacionordendet, sde_nombre, sde_nombrecto, sde_fechaalta, sde_usualta, sde_fechamodifica, sde_usumodifica, sde_estatus  FROM   CUENTASXPAGAR.dbo.cat_situacionordendet
go

