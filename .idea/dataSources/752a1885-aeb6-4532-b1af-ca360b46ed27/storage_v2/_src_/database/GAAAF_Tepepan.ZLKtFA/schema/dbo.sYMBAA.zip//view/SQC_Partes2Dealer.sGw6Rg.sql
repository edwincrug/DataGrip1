create view [dbo].[SQC_Partes2Dealer] as select * from GAAAF_Concentra.dbo.SQC_Partes2Dealer
go

