---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[cat_estatuspresuint] AS 
SELECT 
cec_idestatuspresuint, cec_nombrecorto, cec_nombre, cec_descripcion, cec_idusuarioalta, cec_fechaalta, cec_idusuariomodifica, cec_fechamodifica, cec_estatus
FROM         cuentasporcobrar.dbo.cat_estatuspresuint;
go

