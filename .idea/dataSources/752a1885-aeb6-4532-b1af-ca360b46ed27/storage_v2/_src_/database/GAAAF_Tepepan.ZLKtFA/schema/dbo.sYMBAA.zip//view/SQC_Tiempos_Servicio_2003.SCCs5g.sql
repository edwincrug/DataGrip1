create view [dbo].[SQC_Tiempos_Servicio_2003] as select * from GAAAF_Concentra.dbo.SQC_Tiempos_Servicio_2003
go

