create view [dbo].[PAR_LINEAS] as select * from GAAAF_Concentra.dbo.PAR_LINEAS
go

