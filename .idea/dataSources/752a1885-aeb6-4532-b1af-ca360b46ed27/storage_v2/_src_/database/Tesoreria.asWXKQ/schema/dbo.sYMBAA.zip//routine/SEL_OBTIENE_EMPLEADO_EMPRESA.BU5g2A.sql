-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OBTIENE_EMPLEADO_EMPRESA]
	-- Add the parameters for the stored procedure here
	@idUsuario int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select *
	from Seguridad.dbo.SEG_USUARIO_EMPRESA
	where id_empleado = @idUsuario 
END
go

exec sp_addextendedproperty 'MS_Description', 'Obtiene los permisos para el portal de consulta de movimientos',
     'SCHEMA', 'dbo', 'PROCEDURE', 'SEL_OBTIENE_EMPLEADO_EMPRESA'
go

