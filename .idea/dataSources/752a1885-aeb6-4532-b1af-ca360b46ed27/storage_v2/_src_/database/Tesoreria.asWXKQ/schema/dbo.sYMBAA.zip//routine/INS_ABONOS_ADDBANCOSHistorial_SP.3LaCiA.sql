-- =============================================
-- Author:		Irving Solorio Garcia
-- Create date: 08/05/2019
-- Description:	Insercion de un nuevo movimiento 
--				bancario sobre demanda al historial
-- =============================================
CREATE PROCEDURE [dbo].[INS_ABONOS_ADDBANCOSHistorial_SP]
@IDABONOSBANCOS numeric(18, 0)
AS
BEGIN
--drop table #abonoHist
Declare
	
	@mes int,
	@IDBanco int,
	@anio int,
	@idEmpresa int,
		@importe numeric(18, 6),
@noCuenta varchar(50),
@fechaOperacion date



select 
@idEmpresa=idEmpresa,
@IDBanco=idbanco,
@importe=importe,
@fechaOperacion=fechaOperacion,
@noCuenta=noCuenta,
@mes = month(fechaOperacion),
@anio=year(fechaOperacion)

 from ABONOSBANCOS_CB where IDABONOSBANCOS=@IDABONOSBANCOS
 --select * from ABONOSBANCOS_CB where IDABONOSBANCOS=@IDABONOSBANCOS 
 --select * from PeriodoActivo where idEmpresa=@idEmpresa and idBanco=@IDBanco and cuentaBancaria=@noCuenta and mec_numMes=@mes and mec_anio=@anio

select  ROW_NUMBER() OVER(ORDER BY idHistorico ASC) AS rownumber,
	   [idHistorico]
      ,[idUsuario]
      ,[idBanco]
      ,[idEmpresa]
      ,[fecha]
      ,[cuenta]
      ,[tipoHistorico]
      ,[perido]
      ,[anio]
	into #abonoHist
from [dbo].[HISTORICO_CONCILIACION] h
where idEmpresa=@idEmpresa 
and idBanco=@IDBanco 
and cuenta=@noCuenta 
and tipoHistorico=2
and convert(date,'01/'+RIGHT('00'+ISNULL(convert(nvarchar(2),perido),''),2)+'/'+convert(nvarchar(4),anio),103) >=convert(date,'01/'+RIGHT('00'+ISNULL(convert(nvarchar(2),@mes),''),2)+'/'+convert(nvarchar(4),@anio),103)

DECLARE @maxrow int,@minrow int
SET @minrow = 1

select @maxrow=max(rownumber) from #abonoHist

	WHILE (@minrow <=@maxrow)
	BEGIN
		INSERT INTO [dbo].[ABONOSBANCOS_CB_H]
			   ([IDABONOSBANCOS]
			   ,[idBmer]
			   ,[IDBanco]
			   ,[txtOrigen]
			   ,[registro]
			   ,[noMovimiento]
			   ,[referencia]
			   ,[concepto]
			   ,[refAmpliada]
			   ,[esCargo]
			   ,[importe]
			   ,[saldoOperativo]
			   ,[codigoLeyenda]
			   ,[oficinaOperadora]
			   ,[fechaOperacion]
			   ,[horaOperacion]
			   ,[fechaValor]
			   ,[fechaContable]
			   ,[estatus]
			   ,[noCuenta]
			   ,[estatusRevision]
			   ,[Tipo]
			   ,[idUsuario]
			   ,[idEmpresa]
			   ,[anio]
			   ,[fecha]
			   ,[idEstatus]
			   ,[idConciliado]
			   ,[idHistorico])
		select [IDABONOSBANCOS]
			   ,[idBmer]
			   ,a.[IDBanco]
			   ,[txtOrigen]
			   ,[registro]
			   ,[noMovimiento]
			   ,[referencia]
			   ,[concepto]
			   ,[refAmpliada]
			   ,[esCargo]
			   ,[importe]
			   ,[saldoOperativo]
			   ,[codigoLeyenda]
			   ,[oficinaOperadora]
			   ,[fechaOperacion]
			   ,[horaOperacion]
			   ,[fechaValor]
			   ,[fechaContable]
			   ,[estatus]
			   ,[noCuenta]
			   ,[estatusRevision]
			   ,[Tipo]
			   ,a.[idUsuario]
			   ,a.[idEmpresa]
			   ,a.[anio]
			   ,a.[fecha]
			   ,[idEstatus]
			   ,[idConciliado]
			   ,[idHistorico] from (select * from #abonoHist where rownumber=@minrow) ah
		cross join ABONOSBANCOS_CB a
		where IDABONOSBANCOS=@IDABONOSBANCOS

		update h set  saldoBanco=saldoBanco+@importe,tAbonoBancario=tAbonoBancario+@importe 
		from #abonoHist ah
		inner join TOTALES_H h on ah.idHistorico=h.idHistorico
		where ah.rownumber=@minrow

	
		SET @minrow = @minrow + 1
	END

END


--select * from #abonoHist
go

