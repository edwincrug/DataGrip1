-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-05-17
-- Description:	Obtiene los registros punteados aplicados o no aplicados
-- [dbo].[SEL_PUNTEO_DETALLE_SP] 0, 1;
-- [dbo].[SEL_PUNTEO_DETALLE_SP] 1, 1;
-- [dbo].[SEL_PUNTEO_DETALLE_SP] 1, 1, '000000000195334667', '1100-0020-0001-0001', 1;
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PUNTEO_DETALLE_SP]
	@idEmpresa INT = 0,
	@idBanco INT = 0,
	@noCuenta VARCHAR(60) = '',
	@cuentaContable VARCHAR(60) = '',
	@rpun_idAplicado int
AS
BEGIN
	
	DECLARE @idmes INT 
	SELECT @idmes=p.mec_idMes FROM PeriodoActivo p WHERE cuentaBancaria = @noCuenta AND mec_conciliado = 0

	SELECT
		PUN.rpun_idAplicado AS aplicado,
		PUN.rpun_grupoPunteo AS grupo,
		ABO.idBmer AS idBmer,
		BAN.idBanco AS idBanco,
		BAN.nombre AS banco,
		ABO.referencia AS referencia,
		ABO.fechaOperacion AS fechaOperacion,
		ABO.concepto + ' ' + ABO.refAmpliada AS concepto,
		CASE rpun_idCargo WHEN 0 THEN 0 ELSE ABO.importe END AS cargo,
		CASE rpun_idAbono WHEN 0 THEN 0 ELSE ABO.importe END AS abono,
		0 AS cancela
	FROM VW_REGISTROS_PUNTEADOS PUN
	INNER JOIN  [ABONOSBANCOS_CB] ABO ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS
				AND ABO.idEmpresa = @idEmpresa
				AND ABO.IDBanco = @idBanco
				AND ABO.noCuenta = @noCuenta
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = ABO.IDBanco
	INNER JOIN [dbo].[PeriodoActivo] PAC ON PAC.mec_idMes = PUN.idMes
	WHERE PUN.rpun_tipo = 'B'
		  AND ABO.idEmpresa = @idEmpresa
		  AND PUN.rpun_idAplicado = @rpun_idAplicado
		  AND PAC.mec_idMes = @idmes

	UNION ALL
	SELECT
		PUN.rpun_idAplicado AS aplicado,
		PUN.rpun_grupoPunteo AS grupo,
		CAR.idBmer AS idBmer,
		BAN.idBanco AS idBanco,
		BAN.nombre AS banco,
		CAR.referencia AS referencia,
		CAR.fechaOperacion AS fechaOperacion,
		CAR.concepto + ' ' + CAR.refAmpliada AS concepto,
		CASE rpun_idCargo WHEN 0 THEN 0 ELSE CAR.importe END AS cargo,
		CASE rpun_idAbono WHEN 0 THEN 0 ELSE CAR.importe END AS abono,
		0 AS cancela
	FROM VW_REGISTROS_PUNTEADOS PUN
	INNER JOIN  [CARGOSBANCOS_CB] CAR ON PUN.rpun_idCargo = CAR.IDCARGOSBANCOS
				AND CAR.idEmpresa = @idEmpresa
				AND CAR.IDBanco = @idBanco
				AND CAR.noCuenta = @noCuenta
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = CAR.IDBanco
	INNER JOIN [dbo].[PeriodoActivo] PAC ON PAC.mec_idMes = PUN.idMes
	WHERE PUN.rpun_tipo = 'B'
		  AND CAR.idEmpresa = @idEmpresa
		  AND PUN.rpun_idAplicado= @rpun_idAplicado
				  AND PAC.mec_idMes = @idmes
		  

	SELECT 
		PUN.rpun_idAplicado AS aplicado,
		PUN.rpun_grupoPunteo AS grupo,
		CAR.IDCARGOS_COMPLETO AS Identificador,
		BAN.idBanco AS idBanco,
		BAN.nombre AS banco,
		CAR.MOV_FECHOPE AS fecha,
		CAR.MOV_TIPOPOL AS tipoPoliza,
		CAR.MOV_CONSPOL AS poliza,
		CAR.MOV_CONCEPTO AS concepto,
		CAR.MOV_DEBE AS cargo,
		CAR.MOV_HABER AS abono,
		0 AS cancela
	FROM VW_REGISTROS_PUNTEADOS PUN
	INNER JOIN  [CARGOS_COMPLETO_CB] CAR ON PUN.rpun_idCargo = CAR.IDCARGOS_COMPLETO
				AND CAR.idEmpresa = @idEmpresa
				AND CAR.idBanco = @idBanco
				AND CAR.MOV_NUMCTA = @cuentaContable
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = CAR.idBanco
	INNER JOIN [dbo].[PeriodoActivo] PAC ON PAC.mec_idMes = PUN.idMes
	WHERE rpun_tipo = 'C'
		  AND CAR.idEmpresa = @idEmpresa
		  AND PUN.rpun_idAplicado= @rpun_idAplicado
				  AND PAC.mec_idMes = @idmes
	UNION ALL
	SELECT 
		PUN.rpun_idAplicado AS aplicado,
		PUN.rpun_grupoPunteo AS grupo,
		ABO.IDABONOS_COMPLETO AS Identificador,
		BAN.idBanco AS idBanco,
		BAN.nombre AS banco,
		ABO.MOV_FECHOPE AS fecha,
		ABO.MOV_TIPOPOL AS tipoPoliza,
		ABO.MOV_CONSPOL AS poliza,
		ABO.MOV_CONCEPTO AS concepto,
		ABO.MOV_DEBE AS cargo,
		ABO.MOV_HABER AS abono,
		0 AS cancela
	FROM VW_REGISTROS_PUNTEADOS PUN
	INNER JOIN  [ABONOS_COMPLETO_CB] ABO ON PUN.rpun_idAbono = ABO.IDABONOS_COMPLETO
				AND ABO.idEmpresa = @idEmpresa
				AND ABO.idBanco = @idBanco
				AND ABO.MOV_NUMCTA = @cuentaContable
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = ABO.idBanco
	INNER JOIN [dbo].[PeriodoActivo] PAC ON PAC.mec_idMes = PUN.idMes
	WHERE rpun_tipo = 'C'
		  AND ABO.idEmpresa = @idEmpresa
		  AND PUN.rpun_idAplicado= @rpun_idAplicado
		 		  AND PAC.mec_idMes = @idmes
END
go

