-- =============================================
-- Author: Roberto Almaza Nieto
-- Create date: 03-09-2019
-- Description: regresa el listado de las empresas con sus numeros de cuenta y saldo inicial
-- exec [SaldoEmpresaBancoCuenta] 2020,3,71,1,4
-- =============================================
CREATE PROCEDURE dbo.SaldoEmpresaBancoCuenta
-- Add the parameters for the stored procedure here
@anio INT = 2019
, @mes INT = 8
, @idUsuario INT = 71
, @idModulo INT = 1
, @empresaSeleccionada INT = -1
AS
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON;
  DECLARE @idEmpresa INT
         ,@empresa VARCHAR(250)
         ,@nombre_base VARCHAR(250)
         ,@cuentaContable VARCHAR(20)
         ,@numeroCuenta VARCHAR(50)
         ,@cuenta VARCHAR(50)
         ,@saldoinicial DECIMAL(18, 2)
         ,@abonosBanco DECIMAL(18, 2)
         ,@cargosBanco DECIMAL(18, 2)
         ,@saldoBanco DECIMAL(18, 2)
         ,@idBanco INT
         ,@saldoMinimoCuenta DECIMAL(18, 2)
         ,@tipo_poliza_pago NVARCHAR(10)
         ,@idSucursal INT
  DECLARE @empresaBancoCuenta TABLE (
    empresaId INT
   ,empresa VARCHAR(250)
   ,idBanco INT
   ,cuenta VARCHAR(50)
   ,saldo DECIMAL(18, 2)
   ,saldoMinimoCuenta DECIMAL(18, 2)
   ,cuentaContable VARCHAR(50)
   ,idSucursal INT
   ,saldoInicial decimal(18,2)
  )
  DECLARE @resultado TABLE (
    saldoBanco DECIMAL(18, 2)
   ,tAbonoContable DECIMAL(18, 2)
   ,tAbonoBancario DECIMAL(18, 2)
   ,tCargoContable DECIMAL(18, 2)
   ,tCargoBancario DECIMAL(18, 2)
   ,sConciliacion DECIMAL(18, 2)
   ,sContabilidad DECIMAL(18, 2)
   ,diferencia DECIMAL(18, 2)
   ,mesActivo INT
   ,mensaje NVARCHAR(MAX)
  )
  DECLARE @listBancos NVARCHAR(255) = '', @listaEmpresa NVARCHAR(250) = '';
 SELECT
    @listBancos = ISNULL(ue.id_BancoAcceso, '*') 
  FROM Seguridad.dbo.SEG_USUARIO_EMPRESA ue
  WHERE ue.id_modulo = @idModulo
  AND ue.id_empleado = @idUsuario
  AND ue.id_empresa = @empresaSeleccionada
  DECLARE @NombreMes VARCHAR(3)
         ,@RESULT_MESNAME VARCHAR(10)
         ,@ParmDefinition NVARCHAR(100)
         ,@result_SaldoInicial_Contable DECIMAL(18, 2)
         ,@saldoContabilidad DECIMAL(18, 2)
         ,@date VARCHAR(10) = CONVERT(NVARCHAR(4), @anio) + '-' + RIGHT('0000' + CONVERT(VARCHAR(2), CONVERT(NVARCHAR(2), @mes)), 2) + '-' + '01/'
         ,@dateFin VARCHAR(10) = CONVERT(NVARCHAR(4), @anio) + '-' + RIGHT('0000' + CONVERT(VARCHAR(2), CONVERT(NVARCHAR(2), @mes)), 2)  + '-' + (CASE
            WHEN @mes = 1 OR
              @mes = 3 OR
              @mes = 5 OR
              @mes = 7 OR
              @mes = 8 OR
              @mes = 10 OR
              @mes = 12 THEN '31'
            ELSE '30'
          END)
  PRINT ISNULL(@date, 'error')
  PRINT ISNULL(@dateFin, 'error')
  SET LANGUAGE Spanish;
  SET @NombreMes = SUBSTRING(DATENAME(MONTH, CONVERT(DATE, CONVERT(DATE, REPLACE(@date, '-', '')), 103)), 0, 4);--SUBSTRING(DATENAME(MONTH, convert(DATE, convert(date, @fechaCorte), 103)),0,4);
  SET @RESULT_MESNAME = UPPER('SF_' + @NombreMes)
  DECLARE curEmp CURSOR FOR SELECT DISTINCT
    nombre_base
   ,contrApp.emp_idempresa AS emp_idempresa
   ,contrApp.emp_nombre AS emp_nombre
   ,centBases.tipo_poliza_pago
   ,centBases.sucursal_matriz
  FROM [ControlAplicaciones].[dbo].[cat_empresas] contrApp
  INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] centBases
    ON contrApp.emp_idempresa = centBases.emp_idempresa
    AND centBases.sucursal_matriz > 0
    AND (contrApp.emp_idempresa = @empresaSeleccionada OR @empresaSeleccionada = -1)
  JOIN Seguridad.dbo.SEG_USUARIO_EMPRESA ue
    ON (contrApp.emp_idempresa = @empresaSeleccionada OR @empresaSeleccionada = -1)
    AND ue.id_empleado = @idUsuario
  WHERE contrApp.emp_idempresa != 0
  AND centBases.tipo = 2
  AND nombre_base_matriz IS NOT NULL
  ORDER BY contrApp.emp_idempresa
  OPEN curEmp
  FETCH NEXT FROM curEmp INTO @nombre_base, @idEmpresa, @empresa, @tipo_poliza_pago, @idSucursal
  WHILE @@FETCH_STATUS = 0
  BEGIN
  DECLARE curCuentas CURSOR FOR SELECT
    cuentaContable
   ,numeroCuenta
   ,cuenta
   ,SaldoInicial
   ,idBanco
   ,saldoMinimoCuenta
  FROM referencias.dbo.BancoCuenta b
  WHERE idempresa = @idempresa
  AND ((CHARINDEX(',' + CAST(b.idBanco AS VARCHAR(50)) + ',', ',' + @listBancos + ',') > 0)
  OR @listBancos = '*') --and idbanco in (1,2,3) --Filtramos por Bancomer, Banamex y Santander
  AND cuentaContable <> '0000-0000-0000-0000'
  OPEN curCuentas
  FETCH NEXT FROM curCuentas INTO @cuentaContable, @numeroCuenta, @cuenta, @saldoinicial, @idBanco, @saldoMinimoCuenta
  WHILE @@FETCH_STATUS = 0
  BEGIN
  BEGIN TRY
    PRINT '@idEmpresa: ' + CAST(@idEmpresa AS VARCHAR(30))
    PRINT '@idBanco: ' + CAST(@idBanco AS VARCHAR(30))
    PRINT '@numeroCuenta: ' + CAST(@numeroCuenta AS VARCHAR(30))
    PRINT '@cuentaContable: ' + CAST(@cuentaContable AS VARCHAR(30))
    PRINT '@tipo_poliza_pago: ' + CAST(@tipo_poliza_pago AS VARCHAR(30))
    PRINT ''
    --IF (@idBanco = 1
    -- OR @idBanco = 2
    -- OR @idBanco = 3)
    --BEGIN
    -- EXEC SEL_TOTAL_ABONOCARGO_CONSMOV_SP @idEmpresa
    -- ,@idBanco
    -- ,@numeroCuenta
    -- ,@cuentaContable
    -- ,@date
    -- ,@dateFin
    -- ,@tipo_poliza_pago
    -- ,2
    --END
    ----if(@mes<=6)
    IF (2 <= 1)
    BEGIN
      SELECT
        @abonosBanco = SUM(ab.importe)
      FROM referencias.dbo.BancoCuenta bc
      LEFT JOIN ABONOSBANCOS_CB ab
        ON bc.numeroCuenta = ab.noCuenta
          AND BC.idEmpresa = AB.idEmpresa
          AND idEstatus = 0
          AND ab.idbanco IS NOT NULL
      WHERE ab.anio = @anio
      AND MONTH(fechaOperacion) = @mes
      AND bc.idEmpresa = @idEmpresa
      AND esCargo = 0
      AND bc.cuenta = @cuenta
      GROUP BY bc.idbanco
              ,bc.cuenta
              ,numeroCuenta
              ,cuentaContable
      SELECT
        @cargosBanco = SUM(ab.importe)
      FROM referencias.dbo.BancoCuenta bc
      LEFT JOIN cargosBANCOS_CB ab
        ON bc.numeroCuenta = ab.noCuenta
          AND BC.idEmpresa = AB.idEmpresa
          AND idEstatus = 0
          AND ab.idbanco IS NOT NULL
      WHERE ab.anio = @anio
      AND MONTH(fechaOperacion) = @mes
      AND bc.idEmpresa = @idEmpresa
      AND bc.cuenta = @cuenta
      GROUP BY bc.idbanco
              ,bc.cuenta
              ,numeroCuenta
              ,cuentaContable
    END
    ELSE
    BEGIN
      SELECT
        @abonosBanco = SUM(ab.importe)
      FROM referencias.dbo.BancoCuenta bc
      LEFT JOIN ABONOSBANCOS_CB ab
        ON bc.numeroCuenta = ab.noCuenta
          AND BC.idEmpresa = AB.idEmpresa
          AND idEstatus = 0
          AND CONVERT(NVARCHAR(10), fechaOperacion, 112) BETWEEN '20180601' AND @dateFin
          AND ab.idbanco IS NOT NULL
      WHERE bc.idEmpresa = @idEmpresa
      AND bc.cuenta = @cuenta
      GROUP BY bc.idbanco
              ,bc.cuenta
              ,numeroCuenta
              ,cuentaContable
      SELECT
        @cargosBanco = SUM(ab.importe)
      FROM referencias.dbo.BancoCuenta bc
      LEFT JOIN cargosBANCOS_CB ab
        ON bc.numeroCuenta = ab.noCuenta
          AND BC.idEmpresa = AB.idEmpresa
          AND idEstatus = 0
          AND CONVERT(NVARCHAR(10), fechaOperacion, 112) BETWEEN '20180601' AND @dateFin
          AND ab.idbanco IS NOT NULL
      WHERE bc.idEmpresa = @idEmpresa
      AND bc.cuenta = @cuenta
      GROUP BY bc.idbanco
              ,bc.cuenta
              ,numeroCuenta
              ,cuentaContable
    END
    PRINT '@cuenta: ' + CAST(@cuenta AS VARCHAR(50))
    PRINT '@saldoinicial: ' + CAST(@saldoinicial AS VARCHAR(50))
    PRINT '@cargosBanco: ' + CAST(@cargosBanco AS VARCHAR(50))
    PRINT '@abonosBanco: ' + CAST(@abonosBanco AS VARCHAR(50))
    PRINT '=============================================='
    SET @saldoBanco = (@saldoinicial - (ISNULL(@cargosBanco, 0) - ISNULL(@abonosBanco, 0)))
    INSERT INTO @empresaBancoCuenta
      SELECT
        @idEmpresa
       ,@empresa
       ,@idBanco
       ,@numeroCuenta
       ,ISNULL(@saldoBanco, 0)
       ,@saldoMinimoCuenta
       ,@cuentaContable
       ,@idSucursal
,@saldoinicial
  END TRY
  BEGIN CATCH
  --insert into @empresaBancoCuenta
  --select -1,null,0,null, 0,15000,0
  END CATCH
  FETCH NEXT FROM curCuentas INTO @cuentaContable, @numeroCuenta, @cuenta, @saldoinicial, @idBanco, @saldoMinimoCuenta
  END
  CLOSE curCuentas
  DEALLOCATE curCuentas
  FETCH NEXT FROM curEmp INTO @nombre_base, @idEmpresa, @empresa, @tipo_poliza_pago, @idSucursal
  END
  CLOSE curEmp
  DEALLOCATE curEmp
  SELECT
    empresaId
   ,empresa
   ,bn.idBanco
   ,bn.nombre
   ,cuenta AS cuenta
   ,saldo
   ,saldoMinimoCuenta
   ,cuentaContable
   ,idSucursal
   ,saldoInicial
  FROM @empresaBancoCuenta bc
  JOIN referencias.dbo.Banco bn
    ON bc.idBanco = bn.idBanco
  WHERE empresaId <> -1
  ORDER BY empresaId, bn.idBanco
END
go

exec sp_addextendedproperty 'MS_Description',
     'Regresa el listado de las empresas con sus numeros de cuenta y saldo inicial', 'SCHEMA', 'dbo', 'PROCEDURE',
     'SaldoEmpresaBancoCuenta'
go

exec sp_addextendedproperty 'MS_Description', 'id del usuario logeado', 'SCHEMA', 'dbo', 'PROCEDURE',
     'SaldoEmpresaBancoCuenta', 'PARAMETER', '@idUsuario'
go

exec sp_addextendedproperty 'MS_Description', '1 identificacion de movimientos, 2 transferencias', 'SCHEMA', 'dbo',
     'PROCEDURE', 'SaldoEmpresaBancoCuenta', 'PARAMETER', '@idModulo'
go

exec sp_addextendedproperty 'MS_Description', '-1 regersa todas las empresas o id de la empresa que se desea', 'SCHEMA',
     'dbo', 'PROCEDURE', 'SaldoEmpresaBancoCuenta', 'PARAMETER', '@empresaSeleccionada'
go

