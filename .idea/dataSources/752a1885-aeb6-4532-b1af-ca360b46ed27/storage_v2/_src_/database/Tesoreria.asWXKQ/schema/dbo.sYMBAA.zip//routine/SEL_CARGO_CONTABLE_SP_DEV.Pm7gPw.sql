-- [dbo].[SEL_CARGO_CONTABLE_SP_DEV] 1, '2018-07-01', '2018-07-31', 1,  '000000000195334667', '1100-0020-0001-0001', 1
CREATE PROCEDURE [dbo].[SEL_CARGO_CONTABLE_SP_DEV]
	@idEmpresa VARCHAR(50),
	@fechaElaboracion VARCHAR(50),
	@fechaCorte VARCHAR(50),
	@idBanco INT,
	@noCuenta VARCHAR(50),
	@cuentaContable VARCHAR(50),
	@opcion INT -- 1: detalle, 2: resumen
AS
BEGIN
	
	DECLARE @idHistorico INT = 0;
	-- Casos @opcion
	-- 1: Normal 
	-- 2: Empresa
	-- 3: Sistema
	
	IF( @opcion = 1 )
		BEGIN
			SELECT	
				CC.MOV_NUMCTA MOV_NUMCTA,
				CC.MOV_TIPOPOL MOV_TIPOPOL,
				CC.MOV_CONSPOL MOV_CONSPOL,
				CC.MOV_CONSMOV MOV_CONSMOV,
				CC.MOV_MES MOV_MES,
				CC.MOV_DEBE MOV_DEBE,
				CC.MOV_FECHOPE MOV_FECHOPE,
				CC.MOV_HABER MOV_HABER,
				CC.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM CARGOS_COMPLETO_CB CC
			LEFT JOIN REGISTROS_PUNTEADOS PUN ON PUN.rpun_idCargo = CC.IDCARGOS_COMPLETO AND PUN.rpun_tipo = 'C'
			WHERE   CC.idEmpresa = @idEmpresa
					AND CC.idBanco = @idBanco
					AND CC.MOV_NUMCTA = @cuentaContable
					AND PUN.rpun_idCargo IS NULL
					AND idEstatus = 0
					ORDER BY CC.MOV_FECHOPE, CC.MOV_CONSPOL ASC
		END
	ELSE IF( @opcion = 2 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 1
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)

			SELECT	
				CC.MOV_NUMCTA MOV_NUMCTA,
				CC.MOV_TIPOPOL MOV_TIPOPOL,
				CC.MOV_CONSPOL MOV_CONSPOL,
				CC.MOV_CONSMOV MOV_CONSMOV,
				CC.MOV_MES MOV_MES,
				CC.MOV_DEBE MOV_DEBE,
				CC.MOV_FECHOPE MOV_FECHOPE,
				CC.MOV_HABER MOV_HABER,
				CC.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM CARGOS_COMPLETO_CB_H CC
			LEFT JOIN REGISTROS_PUNTEADOS_H PUN ON PUN.rpun_idCargo = CC.IDCARGOS_COMPLETO AND PUN.rpun_tipo = 'C' AND CC.idHistorico = @idHistorico
			WHERE   CC.idEmpresa = @idEmpresa
					AND CC.idBanco = @idBanco
					AND CC.MOV_NUMCTA = @cuentaContable
					AND PUN.rpun_idCargo IS NULL
					AND idEstatus = 0
					AND CC.idHistorico = @idHistorico
					ORDER BY CC.MOV_FECHOPE, CC.MOV_CONSPOL ASC
		END
	ELSE IF( @opcion = 3 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 2
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)

			SELECT	
				AC.MOV_NUMCTA MOV_NUMCTA,
				AC.MOV_TIPOPOL MOV_TIPOPOL,
				AC.MOV_CONSPOL MOV_CONSPOL,
				AC.MOV_CONSMOV MOV_CONSMOV,
				AC.MOV_MES MOV_MES,
				AC.MOV_DEBE MOV_DEBE,
				AC.MOV_FECHOPE MOV_FECHOPE,
				AC.MOV_HABER MOV_HABER,
				AC.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM ABONOS_COMPLETO_CB_H AC
			LEFT JOIN REGISTROS_PUNTEADOS_H PUN ON PUN.rpun_idAbono = AC.IDABONOS_COMPLETO AND PUN.rpun_tipo = 'C' AND AC.idHistorico = PUN.idHistorico
			WHERE   AC.idEmpresa = @idEmpresa
					AND AC.idBanco = @idBanco
					AND AC.MOV_NUMCTA = @cuentaContable
					AND PUN.rpun_idAbono IS NULL
					AND AC.idEstatus = 0
					AND AC.idHistorico = @idHistorico
					ORDER BY AC.MOV_FECHOPE, AC.MOV_HORAOPE ASC;
		END
END
go

