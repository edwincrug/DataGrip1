-- =============================================
-- Author:		Roberto Almanza
-- Create date: 08/04/2020
-- Description:	Muestra los movimientos DPI anteriores a junio 2018, los movimientos posteriores a esta fecha tambien se
-- mostraran con un estatus DPI, se optimizo un poco mas la consulta
-- =============================================
CREATE PROCEDURE [dbo].[ConsultaMovimientosEmpresaBancoCuenta] 
	@anio INT 
	,@mes INT
	,@idEmpresa INT 
	,@cuenta VARCHAR(150)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @idbanco INT

	SET @idbanco = (SELECT idbanco
					  FROM referencias.dbo.BancoCuenta bc
					  WHERE bc.numeroCuenta = @cuenta
					  AND bc.idEmpresa = @idEmpresa);

/*
OBTENEMOS LOS DPIs
*/
  DECLARE @DPIs TABLE (
    rpun_idPunteado INT
   ,rpun_grupoPunteo INT
   ,rpun_idCargo INT
   ,rpun_idAbono INT
   ,rpun_tipo VARCHAR(1)
   ,concepto NVARCHAR(250)
   ,rpun_fechaPunteo DATETIME
   ,rpun_usuario INT
   ,rpun_idAplicado INT
   ,idEmpresa INT
   ,IDBanco INT
   ,noCuenta VARCHAR(50)
   ,cargos DECIMAL(38, 5)
   ,abonos DECIMAL(38, 6)
   ,mes INT
   ,anio INT
   ,idbmer INT
   ,idMes INT
   ,fechaope DATETIME
   ,idEstatus INT
  )

  INSERT INTO @DPIs
    SELECT distinct
      rpun_idPunteado
     ,rpun_grupoPunteo
     ,MAX(rpun_idCargo) AS rpun_idCargo
     ,MAX(rpun_idAbono) AS rpun_idAbono
     ,MAX(rpun_tipo) AS rpun_tipo
     ,MAX(concepto) AS concepto
     ,MAX(rpun_fechaPunteo) AS rpun_fechaPunteo
     ,MAX(rpun_usuario) AS rpun_usuario
     ,MAX(rpun_idAplicado) AS rpun_idAplicado
     ,MAX(idEmpresa) AS idEmpresa
     ,MAX(IDBanco) AS IDBanco
     ,MAX(noCuenta) AS noCuenta
     ,SUM(cargos) AS cargos
     ,SUM(abonos) AS abonos
     ,MAX(mes) AS mes
     ,MAX(anio) AS anio
     ,MAX(idBmer) AS idbmer
     ,MAX(idMes) AS idMes
     ,MAX(fechaope) AS fechaope
     ,MAX(idEstatus) AS idEstatus
    FROM (SELECT
        r.rpun_idPunteado
       ,r.rpun_grupoPunteo
       ,r.rpun_idCargo
       ,r.rpun_idAbono
       ,c.concepto
       ,r.rpun_tipo
       ,r.rpun_fechaPunteo
       ,r.rpun_usuario
       ,r.rpun_idAplicado
       ,c.idEmpresa
       ,c.IDBanco
       ,c.noCuenta
       ,0 AS cargos
       ,c.importe AS abonos
       ,pa.mec_numMes AS mes
       ,pa.mec_anio AS anio
       ,c.idBmer
       ,pa.mec_idMes AS idMes
       ,c.fechaOperacion AS fechaope
       ,c.idEstatus
      FROM dbo.REGISTROS_PUNTEADOS AS r
      LEFT OUTER JOIN dbo.ABONOSBANCOS_CB AS c
        ON r.rpun_idAbono = c.IDABONOSBANCOS
        AND r.rpun_tipo = 'B'
      INNER JOIN dbo.PeriodoActivo AS pa
        ON pa.mec_idMes = r.idMes
      UNION
      SELECT
        r.rpun_idPunteado
       ,r.rpun_grupoPunteo
       ,r.rpun_idCargo
       ,r.rpun_idAbono
       ,c.MOV_CONCEPTO
       ,r.rpun_tipo
       ,r.rpun_fechaPunteo
       ,r.rpun_usuario
       ,r.rpun_idAplicado
       ,c.idEmpresa
       ,c.idBanco
       ,c.MOV_NUMCTA AS noCuenta
       ,c.MOV_DEBE AS cargos
       ,c.MOV_HABER AS abonos
       ,pa.mec_numMes AS mes
       ,pa.mec_anio AS anio
       ,0 AS idbmer
       ,pa.mec_idMes AS idMes
       ,CONVERT(DATETIME, c.MOV_FECHOPE, 103)
        AS fechaope
       ,c.idEstatus
      FROM dbo.REGISTROS_PUNTEADOS AS r
      LEFT OUTER JOIN dbo.ABONOS_COMPLETO_CB AS c
        ON r.rpun_idAbono = c.IDABONOS_COMPLETO
        AND r.rpun_tipo = 'C'
      INNER JOIN dbo.PeriodoActivo AS pa
        ON pa.mec_idMes = r.idMes) AS x
    GROUP BY rpun_idPunteado
            ,rpun_grupoPunteo;

/**/
	WITH bancos
	AS
	(SELECT
		ab.idBmer
	   ,0 AS cargo
	   ,ABS(ab.importe) AS abono
	   ,ab.referencia + ' - ' + ab.concepto + ' - ' + ab.refAmpliada AS descripcion
	   ,CONVERT(VARCHAR(10), fechaOperacion, 103) AS fechaOperacion
	   ,fechaOperacion AS fechaOperacion2
	   ,bc.idBanco
	   ,bc.idEmpresa
	  FROM referencias.dbo.BancoCuenta bc
	  LEFT JOIN ABONOSBANCOS_CB ab
		ON bc.numeroCuenta = ab.noCuenta
		AND BC.idEmpresa = AB.idEmpresa
		AND idEstatus = 0
		--and YEAR(fechaOperacion) = @anio
		--and MONTH(fechaOperacion) = @mes
		AND CONVERT(NVARCHAR(10), fechaOperacion, 112) >= '20180601'-- AND '20200331'
		AND ab.idbanco IS NOT NULL
		AND bc.numeroCuenta = @cuenta
	  WHERE ab.idEmpresa = @idEmpresa
	  AND ab.IDBanco = @idbanco
	  AND ab.idBmer IS NOT NULL
	  AND ab.anio <= @anio
	  AND MONTH(fechaOperacion) <= (CASE
		WHEN AB.anio < @anio THEN 12
		ELSE @mes
	  END)),
	Punteados
	AS
	(SELECT DISTINCT
		rp.rpun_idPunteado
	   ,rp.rpun_grupoPunteo
	   ,rp.rpun_idCargo
	   ,rp.rpun_idAbono
	   ,rp.rpun_tipo
	   ,rp.concepto
	   ,rp.rpun_fechaPunteo
	   ,rp.rpun_usuario
	   ,rp.rpun_idAplicado
	   ,rp.idEmpresa
	   ,rp.IDBanco
	   ,rp.noCuenta
	   ,rp.cargos
	   ,rp.abonos
	   ,rp.mes
	   ,rp.anio
	   ,rp.idbmer
	   ,rp.idMes
	   ,ROW_NUMBER() OVER (PARTITION BY rp.idbmer ORDER BY rp.idbmer) AS NumeroFila
	  FROM (SELECT
		  r.rpun_idPunteado
		 ,r.rpun_grupoPunteo
		 ,r.rpun_idCargo
		 ,r.rpun_idAbono
		 ,c.concepto
		 ,r.rpun_tipo
		 ,r.rpun_fechaPunteo
		 ,r.rpun_usuario
		 ,r.rpun_idAplicado
		 ,c.idEmpresa
		 ,c.IDBanco
		 ,c.noCuenta
		 ,0 AS cargos
		 ,c.importe AS abonos
		 ,pa.mec_numMes AS mes
		 ,pa.mec_anio AS anio
		 ,c.idBmer
		 ,pa.mec_idMes AS idMes
		FROM dbo.REGISTROS_PUNTEADOS AS r
		LEFT OUTER JOIN dbo.ABONOSBANCOS_CB AS c
		  ON r.rpun_idAbono = c.IDABONOSBANCOS
		  AND r.rpun_tipo = 'B'
		INNER JOIN dbo.PeriodoActivo AS pa
		  ON pa.mec_idMes = r.idMes
		UNION
		SELECT
		  r.rpun_idPunteado
		 ,r.rpun_grupoPunteo
		 ,r.rpun_idCargo
		 ,r.rpun_idAbono
		 ,c.MOV_CONCEPTO
		 ,r.rpun_tipo
		 ,r.rpun_fechaPunteo
		 ,r.rpun_usuario
		 ,r.rpun_idAplicado
		 ,c.idEmpresa
		 ,c.idBanco
		 ,c.MOV_NUMCTA AS noCuenta
		 ,c.MOV_DEBE AS cargos
		 ,c.MOV_HABER AS abonos
		 ,pa.mec_numMes AS mes
		 ,pa.mec_anio AS anio
		 ,0 AS idbmer
		 ,pa.mec_idMes AS idMes
		FROM dbo.REGISTROS_PUNTEADOS AS r
		LEFT OUTER JOIN dbo.ABONOS_COMPLETO_CB AS c
		  ON r.rpun_idAbono = c.IDABONOS_COMPLETO
		  AND r.rpun_tipo = 'C'
		INNER JOIN dbo.PeriodoActivo AS pa
		  ON pa.mec_idMes = r.idMes) rp
	  INNER JOIN bancos b
		ON rp.idbmer = b.idBmer
		AND rp.IDBanco = b.IDBanco
		AND rp.idEmpresa = b.idEmpresa
	  WHERE rp.idbmer <> 0
	  AND rp.idEmpresa = @idEmpresa
	  AND rp.IDBanco = @idbanco
	  AND rp.rpun_idAbono <> 0
	  AND rp.rpun_grupoPunteo > 0
	  AND rp.rpun_tipo = 'B'),
	controlAPP
	AS
	(SELECT DISTINCT
		idDeposito
	   ,dp.idEmpresa
	   ,dp.idBanco
	   ,idUsuario
	   ,CONVERT(VARCHAR(10), fecha, 103) AS fecha
	  FROM referencias..RAPDeposito dp
	  INNER JOIN bancos b
		ON dp.idEmpresa = b.idEmpresa
		AND dp.idBanco = b.idBanco
		AND dp.idDeposito = b.idBmer
	  WHERE dp.idEmpresa = @idEmpresa
	  AND dp.idBanco = @idbanco),
	referencia
	AS
	(SELECT
		ref.idReferencia
	   ,ref.idEmpresa
	   ,ref.fecha
	   ,ref.referencia
	   ,ref.tipoReferencia
	   ,ref.numeroConsecutivo
	   ,ref.estatus
	   ,ref.depositoID
	   ,ref.IDBanco
	   ,ref.idUsuario
	  FROM Tesoreria.dbo.Referencia ref
	  JOIN bancos b
		ON b.idBmer = ref.depositoID
		AND b.idBanco = ref.IDBanco
	  WHERE ref.IDBanco = @idbanco),
	bancos2
	AS
	(SELECT
		ab.idBmer
	   ,ABS(ab.importe) AS cargo
	   ,0 AS abono
	   ,ab.referencia + ' - ' + ab.concepto + ' - ' + ab.refAmpliada AS descripcion
	   ,CONVERT(VARCHAR(10), fechaOperacion, 103) AS fechaOperacion
	   ,fechaOperacion AS fechaOperacion2
	   ,bc.idBanco
	   ,bc.idEmpresa
	  FROM referencias.dbo.BancoCuenta bc
	  LEFT JOIN CARGOSBANCOS_CB ab
		ON bc.numeroCuenta = ab.noCuenta
		AND BC.idEmpresa = AB.idEmpresa
		AND idEstatus = 0
		AND CONVERT(NVARCHAR(10), fechaOperacion, 112) >= '20180601'-- AND '20200331'
		--and YEAR(fechaOperacion) = @anio
		--and MONTH(fechaOperacion) = @mes
		AND ab.idbanco IS NOT NULL
		AND bc.numeroCuenta = @cuenta
	  WHERE ab.idEmpresa = @idEmpresa
	  AND ab.IDBanco = @idbanco
	  AND ab.idBmer IS NOT NULL
	  AND ab.anio <= @anio
	  AND MONTH(fechaOperacion) <= (CASE
		WHEN AB.anio < @anio THEN 12
		ELSE @mes
	  END)),
	Punteados2
	AS
	(SELECT DISTINCT
		rp.rpun_idPunteado
	   ,rp.rpun_grupoPunteo
	   ,rp.rpun_idCargo
	   ,rp.rpun_idAbono
	   ,rp.rpun_tipo
	   ,rp.concepto
	   ,rp.rpun_fechaPunteo
	   ,rp.rpun_usuario
	   ,rp.rpun_idAplicado
	   ,rp.idEmpresa
	   ,rp.IDBanco
	   ,rp.noCuenta
	   ,rp.cargos
	   ,rp.abonos
	   ,rp.mes
	   ,rp.anio
	   ,rp.idbmer
	   ,rp.idMes
	   ,ROW_NUMBER() OVER (PARTITION BY rp.idbmer ORDER BY rp.idbmer) AS NumeroFila
	  FROM (SELECT
		  r.rpun_idPunteado
		 ,r.rpun_grupoPunteo
		 ,r.rpun_idCargo
		 ,r.rpun_idAbono
		 ,c.concepto
		 ,r.rpun_tipo
		 ,r.rpun_fechaPunteo
		 ,r.rpun_usuario
		 ,r.rpun_idAplicado
		 ,c.idEmpresa
		 ,c.IDBanco
		 ,c.noCuenta
		 ,c.importe AS cargos
		 ,0 AS abonos
		 ,pa.mec_numMes AS mes
		 ,pa.mec_anio AS anio
		 ,c.idBmer
		 ,pa.mec_idMes AS idMes
		FROM dbo.REGISTROS_PUNTEADOS AS r
		LEFT OUTER JOIN dbo.CARGOSBANCOS_CB AS c
		  ON r.rpun_idCargo = c.IDCARGOSBANCOS
		  AND r.rpun_tipo = 'B'
		INNER JOIN dbo.PeriodoActivo AS pa
		  ON pa.mec_idMes = r.idMes
		UNION
		SELECT
		  r.rpun_idPunteado
		 ,r.rpun_grupoPunteo
		 ,r.rpun_idCargo
		 ,r.rpun_idAbono
		 ,c.MOV_CONCEPTO
		 ,r.rpun_tipo
		 ,r.rpun_fechaPunteo
		 ,r.rpun_usuario
		 ,r.rpun_idAplicado
		 ,c.idEmpresa
		 ,c.idBanco
		 ,c.MOV_NUMCTA AS noCuenta
		 ,c.MOV_DEBE AS cargos
		 ,c.MOV_HABER AS abonos
		 ,pa.mec_numMes AS mes
		 ,pa.mec_anio AS anio
		 ,0 AS idbmer
		 ,pa.mec_idMes AS idMes
		FROM dbo.REGISTROS_PUNTEADOS AS r
		LEFT OUTER JOIN dbo.CARGOS_COMPLETO_CB AS c
		  ON r.rpun_idCargo = c.IDCARGOS_COMPLETO
		  AND r.rpun_tipo = 'C'
		INNER JOIN dbo.PeriodoActivo AS pa
		  ON pa.mec_idMes = r.idMes) rp
	  INNER JOIN bancos2 b
		ON rp.idbmer = b.idBmer
		AND rp.IDBanco = b.IDBanco
		AND rp.idEmpresa = b.idEmpresa
	  WHERE rp.idEmpresa = @idEmpresa
	  AND rp.IDBanco = @idbanco
	  AND rp.idbmer <> 0
	  AND rp.rpun_idAbono = 0
	  AND rp.rpun_grupoPunteo > 0
	  AND rp.rpun_tipo = 'B'),
	controlAPP2
	AS
	(SELECT DISTINCT
		idDeposito
	   ,dp.idEmpresa
	   ,dp.idBanco
	   ,idUsuario
	   ,CONVERT(VARCHAR(10), fecha, 103) AS fecha
	  FROM referencias..RAPDeposito dp
	  INNER JOIN bancos2 b
		ON dp.idEmpresa = b.idEmpresa
		AND dp.idBanco = b.idBanco
		AND dp.idDeposito = b.idBmer
	  WHERE dp.idEmpresa = @idEmpresa
	  AND dp.idBanco = @idbanco),
	referencia2
	AS
	(SELECT
		ref.idReferencia
	   ,ref.idEmpresa
	   ,ref.fecha
	   ,ref.referencia
	   ,ref.tipoReferencia
	   ,ref.numeroConsecutivo
	   ,ref.estatus
	   ,ref.depositoID
	   ,ref.IDBanco
	   ,ref.idUsuario
	  FROM Tesoreria.dbo.Referencia ref
	  INNER JOIN bancos2 b
		ON b.idBmer = ref.depositoID
		AND b.idBanco = ref.IDBanco
	  WHERE ref.IDBanco = @idbanco),
	DPI AS (
	   SELECT
		[aplicado] = PUN.rpun_idAplicado
		,[grupo] = PUN.rpun_grupoPunteo
		,[Identificador] = ABO.IDABONOSBANCOS
		FROM DepositoBancarioDPI DPI
		INNER JOIN ABONOSBANCOS_CB ABO
		ON DPI.idAbonoBanco = ABO.idBmer
		  AND DPI.idEmpresa = ABO.idEmpresa
		  AND DPI.idBanco = ABO.IDBanco
		JOIN @DPIs pun
		  ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS
		  AND PUN.rpun_tipo = 'B'
		JOIN @DPIs cpun
		ON pun.rpun_grupoPunteo = cpun.rpun_grupoPunteo
			AND cpun.rpun_tipo = 'C'
		LEFT JOIN CancelaDPI CAN
		  ON CAN.idDPI = DPI.idDPI
		LEFT JOIN ABONOS_COMPLETO_CB AC
		  ON AC.IDABONOS_COMPLETO = CAN.idAbonos_Completo
		left join Referencia ref
			on abo.idBmer = ref.depositoID
		WHERE CAN.idDPI IS NULL
		AND DPI.idEmpresa = @idEmpresa
		AND DPI.idBanco = @idbanco
		AND ABO.noCuenta = @cuenta
		and ref.depositoID is null
	)
	SELECT DISTINCT
	  b.idBmer AS id
	 ,b.descripcion
	 ,b.cargo
	 ,b.abono
	 ,CASE WHEN ((ISNULL(p.rpun_idPunteado, 0) > 0 AND dpi.grupo IS NULL) OR (ISNULL(cap.idDeposito, 0) > 0 AND dpi.grupo IS NULL)) 
	  THEN 'Identificado'
	  ELSE CASE WHEN ((ISNULL(p.rpun_idPunteado, 0) > 0 AND dpi.grupo IS NOT NULL) OR (ISNULL(cap.idDeposito, 0) > 0 AND dpi.grupo IS NOT NULL)) 
				THEN 'DPI'
				else'No identificado'
			END
	END AS estatus
	 ,ISNULL(pimb.Observacion, '') AS Observacion
	 ,b.fechaOperacion
	 ,b.fechaOperacion2
	 ,CASE
		WHEN ((ISNULL(p.rpun_idPunteado, 0) > 0) OR
		  (ISNULL(cap.idDeposito, 0) > 0)) THEN 'Aplicó: ' + ISNULL((cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno), 'Sin Dato') + ' el día ' + ISNULL(CONVERT(VARCHAR(10), cap.fecha, 103), 'Sin Dato')
		ELSE ''
	  END AS aplico
	 ,ref.idReferencia
	 ,p.rpun_grupoPunteo AS grupoPunteo
	 , 1 AS suma
	 ,DPI.grupo
	FROM bancos b
	LEFT JOIN Punteados p
	  ON b.idBmer = p.idbmer
		AND b.idEmpresa = p.idEmpresa
		AND b.idBanco = p.IDBanco
		AND p.NumeroFila = 1
	LEFT JOIN controlAPP cap
	  ON b.idBmer = cap.idDeposito
	LEFT JOIN referencia ref
	  ON b.idEmpresa = ref.idEmpresa
		AND b.idBanco = ref.IDBanco
		AND b.idBmer = ref.depositoID
	LEFT JOIN PreIdentitificacionMovimientosBancarios pimb
	  ON b.idBmer = pimb.idMovimiento
		AND pimb.activo = 1
		AND pimb.tipoMovimiento = 'A'
	LEFT JOIN ControlAplicaciones..cat_usuarios cu
	  ON cap.idUsuario = cu.usu_idusuario
	LEFT JOIN DPI AS DPI
	  ON DPI.grupo = P.rpun_grupoPunteo
	UNION ALL
	--insert into @cargo
	SELECT DISTINCT
	  b.idBmer
	 ,b.descripcion
	 ,b.cargo
	 ,b.abono
	 ,CASE
		WHEN ((ISNULL(p.rpun_idPunteado, 0) > 0) OR (ISNULL(cap.idDeposito, 0) > 0)) THEN 'Identificado'
		ELSE 'No identificado'
	  END AS estatus
	 ,ISNULL(pimb.Observacion, '') AS Observacion
	 ,b.fechaOperacion
	 ,b.fechaOperacion2
	 ,CASE
		WHEN ((ISNULL(p.rpun_idPunteado, 0) > 0) OR
		  (ISNULL(cap.idDeposito, 0) > 0)) THEN 'Aplicó: ' + ISNULL((cu.usu_nombre + ' ' + cu.usu_paterno + ' ' + cu.usu_materno), 'Sin Dato') + ' el día ' + ISNULL(CONVERT(VARCHAR(10), cap.fecha, 103), 'Sin Dato')
		ELSE ''
	  END AS aplico
	 ,ref.idReferencia
	 ,p.rpun_grupoPunteo AS grupoPunteo
	 ,1 AS suma
	 ,DPI.grupo
	FROM bancos2 b
	LEFT JOIN Punteados2 p
	  ON b.idBmer = p.idbmer
		AND b.idEmpresa = p.idEmpresa
		AND b.idBanco = p.IDBanco
		AND p.NumeroFila = 1
	LEFT JOIN controlAPP2 cap
	  ON b.idBmer = cap.idDeposito
	LEFT JOIN referencia2 ref
	  ON b.idEmpresa = ref.idEmpresa
		AND b.idBanco = ref.IDBanco
		AND b.idBmer = ref.depositoID
	LEFT JOIN PreIdentitificacionMovimientosBancarios pimb
	  ON b.idBmer = pimb.idMovimiento
		AND pimb.activo = 1
		AND pimb.tipoMovimiento = 'C'
	LEFT JOIN ControlAplicaciones..cat_usuarios cu
	  ON cap.idUsuario = cu.usu_idusuario
	LEFT JOIN DPI AS DPI
	  ON DPI.grupo = P.rpun_grupoPunteo
	UNION
	 SELECT
	  a.idDpiAnterior AS id
	  ,a.referencia AS descripcion
	  ,0 AS cargo
	  ,a.importe AS abono
	  , case when cancelado = 1 then 'Identificado' else 'DPI' end AS estatus
	  ,'' AS observacion
	  ,CONVERT(VARCHAR(10), a.fecha,103) AS fechaOperacion
	  ,a.fecha AS fechaOperacion2
	  ,'DPI ANTERIOR' AS aplico
	  ,NULL AS idReferencia
	  ,NULL AS grupoPunteo
	  , 0 AS suma
	  ,NULL AS grupo
	 FROM Tesoreria..dpiAnterior a
	 inner join referencias.dbo.BancoCuenta b 
	 on a.cuenta=b.numeroCuenta
	 LEFT JOIN [Referencia] REF ON a.idDpiAnterior = REF.depositoID and b.IDBanco=REF.IDBanco
	 WHERE a.cuenta = @cuenta
	 and ref.idReferencia is null

END
go

