
CREATE PROCEDURE  [dbo].[SEL_SEGURUDAD_SP]
	@idUsuario int = 0
AS
BEGIN
	-- Esto solo es funcional para Control de Depositos 
	SELECT * 
	FROM [Seguridad].[dbo].SEG_CENTRALIZACION 
	WHERE seg_idAccion = 0 
		  AND seg_idPortal = 4
		  AND seg_idModulo = 3
		  AND seg_idUsuario = @idUsuario;
	         -- [67],      [0],      [4],      [3]
END
go

