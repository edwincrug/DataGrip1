-- =============================================
-- Author:		ROBERTO ALMANZA
-- Create date: 06-01-2020
-- Description:	OBTIENE LA LISTA DE DEPARTAMENTOS DE LAS SUCURSALES SELECCIONADAS
-- exec SEL_DEPARTAMENTO_BY_USUARIO_SUCURSAL_SP 71, '6,8'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTO_BY_USUARIO_SUCURSAL_SP]
@idUsuario INT,
@idSucursal nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	--select distinct (Depto.dep_nombre)+' - '+suc.suc_nombre as dep_nombre
	select distinct (Depto.dep_nombre) as dep_nombre
	, Depto.dep_iddepartamento
	from [ControlAplicaciones].[dbo].[ope_organigrama] Orga
	JOIN [ControlAplicaciones].[dbo].[cat_departamentos] Depto 
	ON Orga.dep_iddepartamento = Depto.dep_iddepartamento
	join ControlAplicaciones.dbo.cat_sucursales suc
	on suc.suc_idsucursal = Orga.suc_idsucursal
	where Orga.usu_idusuario = @idUsuario
	and (CHARINDEX(',' + cast(Orga.suc_idsucursal as varchar(50)) + ',', ',' + @idSucursal + ',') > 0)
	order by 2
END
go

exec sp_addextendedproperty 'MS_Description', 'OBTIENE LA LISTA DE DEPARTAMENTOS DE LAS SUCURSALES SELECCIONADAS',
     'SCHEMA', 'dbo', 'PROCEDURE', 'SEL_DEPARTAMENTO_BY_USUARIO_SUCURSAL_SP'
go

