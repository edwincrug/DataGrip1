-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-05-17
-- Description:	Aplicar los registros punteados
-- =============================================
CREATE PROCEDURE [dbo].[UPD_PUNTEO_APLICAR_SP]
AS
BEGIN
	UPDATE [REGISTROS_PUNTEADOS] SET rpun_idAplicado = 1 WHERE rpun_idAplicado = 0;
	SELECT success = 1, msg = 'Se han aplicado los registros punteados.'
END
go

