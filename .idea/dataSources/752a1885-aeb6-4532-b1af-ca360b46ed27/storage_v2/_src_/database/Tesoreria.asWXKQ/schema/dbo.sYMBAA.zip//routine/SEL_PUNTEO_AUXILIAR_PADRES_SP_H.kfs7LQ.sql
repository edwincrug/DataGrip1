-- [SEL_PUNTEO_AUXILIAR_PADRES_SP_H] 1,'1100-0020-0001-0001',2
--[SEL_PUNTEO_AUXILIAR_PADRES_SP] 1, '1100-0020-0001-0001', '2018-03-01', '2018-03-31'
CREATE PROCEDURE [dbo].[SEL_PUNTEO_AUXILIAR_PADRES_SP_H]
@idEmpresa INT,
@cuentaContable VARCHAR(50) = '',
--@fechaelaboracion VARCHAR(30),
--@fechaCorte VARCHAR(30)
@idHistorico DECIMAL(18,0) = 0,
@idEstatus INT = 2 --2: punteado temporal, 3: punteado final
AS 
BEGIN
    
	SELECT 
				     --DISTINCT(PUNTEO.[idPunteoAuxiliarBanco_H]) AS  idAuxiliarContable
		            DISTINCT
					idAuxiliarContable
					,(SELECT TOP 1 descripcion FROM [PunteoAuxiliarBanco] WHERE MOV_CONSPOL = PUNTEO.idAuxiliarContable) AS  descripcion
 					,@idEmpresa idEmpresa 
					,auxiliar.MOV_MES movMes
					,auxiliar.MOV_CONSMOV movConsMov
					,auxiliar.MOV_NUMCTA numeroCuenta  
					,auxiliar.MOV_TIPOPOL polTipo
					,auxiliar.MOV_CONSPOL polConsecutivo  
					,auxiliar.MOV_CONCEPTO movConcepto 
					,auxiliar.MOV_DEBE cargo 
					,auxiliar.MOV_HABER abono
					,auxiliar.MOV_FECHOPE movFechaOpe
					,auxiliar.MOV_HORAOPE movHoraOpe
					,2 idEstatus --auxiliar.idEstatus --?????
					,PUNTEO.idPAdre
					,PUNTEO.tipoPunteo AS tipoPunteo
					,PUNTEO.idPunteoFinalBancos					
	FROM ABONOS_COMPLETO_CB_H auxiliar 
	INNER JOIN [PunteoAuxiliarBanco_H] PUNTEO ON auxiliar.MOV_CONSPOL = PUNTEO.MOV_CONSPOL
	WHERE auxiliar.idHistorico = @idHistorico
	AND PUNTEO.esCargoContable = 0	
	AND PUNTEO.idHistorico = @idHistorico
	AND auxiliar.MOV_MES = PUNTEO.MOV_MES
	AND auxiliar.MOV_TIPOPOL = PUNTEO.MOV_TIPOPOL
	AND auxiliar.MOV_CONSMOV = PUNTEO.MOV_CONSMOV
	AND auxiliar.MOV_CONSPOL = PUNTEO.MOV_CONSPOL
	--AND idPunteoFinalBancos IN (2,3)

	UNION
	
	SELECT 				     
					  DISTINCT--(PUNTEO.[idPunteoAuxiliarBanco]) idAuxiliarContable		            
					idAuxiliarContable
					,(SELECT TOP 1 descripcion FROM [PunteoAuxiliarBanco] WHERE MOV_CONSPOL = PUNTEO.idAuxiliarContable) AS  descripcion
 					,@idEmpresa idEmpresa 
					,auxiliar.MOV_MES movMes
					,auxiliar.MOV_CONSMOV movConsMov
					,auxiliar.MOV_NUMCTA numeroCuenta  
					,auxiliar.MOV_TIPOPOL polTipo
					,auxiliar.MOV_CONSPOL polConsecutivo  
					,auxiliar.MOV_CONCEPTO movConcepto 
					,auxiliar.MOV_DEBE cargo 
					,auxiliar.MOV_HABER abono
					,auxiliar.MOV_FECHOPE movFechaOpe
					,auxiliar.MOV_HORAOPE movHoraOpe
					,2 idEstatus --auxiliar.idEstatus --?????
					,PUNTEO.idPAdre
					,PUNTEO.tipoPunteo AS tipoPunteo	
					,PUNTEO.idPunteoFinalBancos									
	FROM CARGOS_COMPLETO_CB_H auxiliar 
	INNER JOIN [PunteoAuxiliarBanco_H] PUNTEO ON auxiliar.MOV_CONSPOL = PUNTEO.MOV_CONSPOL
	WHERE auxiliar.idHistorico = @idHistorico	
	AND PUNTEO.esCargoContable = 1	
	AND PUNTEO.idHistorico = @idHistorico
	AND auxiliar.MOV_MES = PUNTEO.MOV_MES
	AND auxiliar.MOV_TIPOPOL = PUNTEO.MOV_TIPOPOL
	AND auxiliar.MOV_CONSMOV = PUNTEO.MOV_CONSMOV
	AND auxiliar.MOV_CONSPOL = PUNTEO.MOV_CONSPOL
	--AND idPunteoFinalBancos IN (2,3)
END


go

