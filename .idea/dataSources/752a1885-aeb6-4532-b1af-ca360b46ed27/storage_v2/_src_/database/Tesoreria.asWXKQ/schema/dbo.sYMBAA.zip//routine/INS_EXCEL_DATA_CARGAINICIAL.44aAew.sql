
-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[INS_EXCEL_DATA_CARGAINICIAL]
	-- Add the parameters for the stored procedure here
@noCuenta VARCHAR(100),
@fecha VARCHAR(100),
@concepto VARCHAR(100),
@sucursal numeric(18,0),
@referencia numeric(18,0),
@refAmpliada VARCHAR(MAX),
@autorizacion numeric(18,0),
@abonos numeric(18,2),
@cargos numeric(18,2),
@clveLayout VARCHAR(30)


AS
BEGIN TRY
DECLARE @nombreBanco varchar(50),
        @idBanco INT
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
SET @idBanco = (SELECT idBanco 
				       FROM referencias.dbo.BancoCuenta 
					   WHERE numeroCuenta = CONVERT(VARCHAR, @noCuenta))
SET @nombreBanco = (SELECT nombre 
						   FROM referencias.dbo.Banco 
						   WHERE idBanco = ISNULL(@idBanco,0))

    -- Insert statements for procedure here
	INSERT INTO [referencias].[dbo].[CargaInicial_Layout] 
								(idBanco,
								 nombre,
								 noCuenta,
								 fecha, 
								 Concepto, 
								 Sucursal, 
								 Referencia, 
								 ReferenciaAmpliada, 
								 Autorizacion, 
								 Abonos, 
								 Cargos)
	                               SELECT
								    ISNULL(@idBanco,0),
								    ISNULL(@nombreBanco, 'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@noCuenta)),'INDEFINIDO'),
                                    ISNULL(CONVERT(DATE,(RTRIM(LTRIM(@fecha))),103), CONVERT(date,GETDATE(),103)),
	                                ISNULL(RTRIM(LTRIM(@concepto)), 'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@sucursal)), 0),
									ISNULL(RTRIM(LTRIM(@referencia)), 0),
									ISNULL(RTRIM(LTRIM(@refAmpliada)),'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@autorizacion)),0),
									ISNULL(CONVERT(numeric(18,2),RTRIM(LTRIM(@abonos))),0),
									ISNULL(CONVERT(numeric(18,2),RTRIM(LTRIM(@cargos))),0)	        
 
              
			   UPDATE [layout_Historial]
					  SET fecha_Carga_Info = CONVERT(date, GETDATE())
					  WHERE clv_Identificador = @clveLayout 


				SELECT 1 AS SUCCESS 

		
END TRY
BEGIN CATCH
          SELECT ERROR_MESSAGE() AS ERROR
END CATCH


go

