-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <10/07/2017>
-- Description:	<Inserta los referenciados DPI a la tabla de punteo >
-- =============================================

--[dbo].[CON_REFERENCIADOS_DPI_SP] 1,1,4,2020,'000000000195334667' ,'1100-0020-0001-0001' 
CREATE PROCEDURE [dbo].[CON_REFERENCIADOS_DPI_SP] 

@idBanco INT	= 0,
	@idEmpresa INT	=0,
	@Mes INT		= 0,
	@Anio INT		= 0,
	@noCuenta VARCHAR(30) = '',
	@cuentaContable VARCHAR(30) = ''
	
--Declare
--@idBanco INT	= 1,
--	@idEmpresa INT	= 1,
--	@Mes INT		= 4,
--	@Anio INT		= 2020,
--	@noCuenta VARCHAR(30) = '000000000195334667',
--	@cuentaContable VARCHAR(30) = '1100-0020-0001-0001'
AS
BEGIN
Declare @MOV_TIPOPOL varchar(30),@max_grupopunteo int=0
         
		DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);

		DECLARE @Base VARCHAR(300) = ''
		IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
			BEGIN
				SET @Base = (SELECT '[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
			END
		ELSE
			BEGIN
				SET @Base = (SELECT '[' + ip_servidor + '].[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
			END

	declare @query varchar(max)  =  
		'update a set a.mov_observa=c.mov_observa
			FROM '+ @Base +' C
			inner join ABONOS_COMPLETO_CB a on a.idEmpresa = ' + CONVERT(VARCHAR(5),@idEmpresa)+' and C.MOV_NUMCTA COLLATE database_default=A.MOV_NUMCTA and c.MOV_CONSPOL		= a.MOV_CONSPOL 
					AND c.MOV_CONSMOV	= a.MOV_CONSMOV
					AND c.MOV_MES		= a.MOV_MES
					AND c.MOV_TIPOPOL COLLATE database_default = a.MOV_TIPOPOL
					and c.mov_haber = a.mov_haber
			WHERE C.MOV_HABER <> 0 AND C.MOV_MES = ' + CONVERT(VARCHAR(4),@Mes)+' and c.mov_observa COLLATE database_default <>a.mov_observa
			AND C.MOV_NUMCTA = '''+ @cuentaContable+'''' ;
print @query
--exec (@query)
DECLARE @idMes INT = ( SELECT mec_idMes FROM PeriodoActivo WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @noCuenta AND mec_conciliado = 0);
select  distinct IDCARGOS_COMPLETO,c.mov_debe,IDABONOS_COMPLETO,a.mov_haber,0 grupo,@idMes idMes
into #relpunteo 
from ABONOS_COMPLETO_CB a 
inner join CARGOS_COMPLETO_CB c on a.mov_observa=c.mov_observa and a.idEmpresa=c.idEmpresa and a.idBanco=c.idBanco and a.MOV_NUMCTA=c.MOV_NUMCTA
left join REGISTROS_PUNTEADOS r1 on a.IDABONOS_COMPLETO=r1.rpun_idAbono and r1.rpun_tipo='C'
left join REGISTROS_PUNTEADOS r2 on c.IDcargos_COMPLETO=r2.rpun_idCargo and r2.rpun_tipo='C'
left join REGISTROS_PUNTEADOS_can r1c on a.IDABONOS_COMPLETO=r1c.rpun_idAbono and r1.rpun_tipo='C'
left join REGISTROS_PUNTEADOS_can r2c on c.IDcargos_COMPLETO=r2c.rpun_idCargo and r2.rpun_tipo='C'
where a.idempresa=@idEmpresa and a.idbanco=@idBanco and a.mov_tipopol='DPI' and len(a.mov_observa)>0 and r1.rpun_grupoPunteo is null and r2.rpun_grupoPunteo is null and r1c.rpun_grupoPunteo is null and r2c.rpun_grupoPunteo is null

update r set r.grupo= x.grupo from ( 
select  ROW_NUMBER() OVER(ORDER BY IDABONOS_COMPLETO ASC) AS grupo, IDABONOS_COMPLETO from #relpunteo group by IDABONOS_COMPLETO) x
inner join #relpunteo r on x.IDABONOS_COMPLETO=r.IDABONOS_COMPLETO
--select * from #relpunteo

select  x.grupo,x.IDCARGOS_COMPLETO,x.IDABONOS_COMPLETO,x.tipo,x.fecha,x.usuario,x.idaplicado,x.idMes ,0 noexiste
into #relpunteo4
from (
select distinct grupo,0 IDCARGOS_COMPLETO,IDABONOS_COMPLETO,'C' tipo,getdate() fecha,2 usuario,2 idaplicado,idMes from #relpunteo 
union all
select distinct grupo,IDCARGOS_COMPLETO,0 IDABONOS_COMPLETO,'C',getdate(),2 ,2,idMes  from #relpunteo) x 
left join (select * from [dbo].[REGISTROS_PUNTEADOS] 
union all select * from [dbo].[REGISTROS_PUNTEADOS_ERR]  ) r on r.rpun_idAbono=x.IDABONOS_COMPLETO and r.rpun_idCargo=x.IDCARGOS_COMPLETO and r.rpun_tipo=x.tipo
where r.rpun_idPunteado is null
order by grupo
select @max_grupopunteo=max(rpun_grupoPunteo) from (select max(rpun_grupoPunteo) rpun_grupoPunteo from [dbo].[REGISTROS_PUNTEADOS] union all select max(rpun_grupoPunteo) rpun_grupoPunteo from[dbo].[REGISTROS_PUNTEADOS_ERR]) x


INSERT INTO [dbo].[REGISTROS_PUNTEADOS]
           ([rpun_grupoPunteo]
           ,[rpun_idCargo]                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
           ,[rpun_idAbono]
           ,[rpun_tipo]
           ,[rpun_fechaPunteo]
           ,[rpun_usuario]
           ,[rpun_idAplicado]
		   ,[idMes])
select @max_grupopunteo+ grupo,IDCARGOS_COMPLETO,IDABONOS_COMPLETO,tipo,fecha,usuario,idaplicado ,idMes
from #relpunteo4 
 order by grupo

 drop table #relpunteo
drop table #relpunteo4
END
go

