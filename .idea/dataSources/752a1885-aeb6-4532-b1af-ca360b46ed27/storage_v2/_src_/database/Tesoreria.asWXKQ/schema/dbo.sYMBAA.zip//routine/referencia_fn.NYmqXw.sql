-- =============================================
-- Author:		
-- Create date: 21092016
-- Description:	genera y regresa referencia bancaria
-- select [dbo].[referencia_fn]('AA','0944',23,1)
-- =============================================
CREATE FUNCTION [dbo].[referencia_fn]
(	
	@serie VARCHAR(3),
	@factura VARCHAR(7),
	--@tipo int = 0,
	--@consecutivo TINYINT = 0,
	@idSucursal int = 0,
	@idTipoReferencia varchar(2)
)
RETURNS VARCHAR(19)
AS
BEGIN	

	DECLARE @referencia VARCHAR(19) = '' 
	SET @serie = REPLICATE('0',3-LEN(@serie)) + @serie
	SET @factura = REPLICATE('0',7-LEN(@factura)) + CONVERT(VARCHAR(7),@factura)    
	       
	SELECT  @referencia = 
		 REPLICATE('0',1-LEN(CONVERT(VARCHAR(1),CONVERT(VARCHAR(1),0)))) + CONVERT(VARCHAR(1),0) +
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(MM,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(MM,GETDATE())),'0123456789AB') + -- conversion a base 12
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(DD,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(DD,GETDATE())),'0123456789ABCDEFGHIJKLMNOPQRSTUV') + -- conversion a base 31
		 [dbo].[intToBase] (REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE())) ,'0123456789ABCDEFGHIJKLMNO') + -- conversion a base 24
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())) + -- conversión base 10
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),CONVERT(VARCHAR(2),[dbo].[intToBase]( @idSucursal ,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'))))) + CONVERT(VARCHAR(2),[dbo].[intToBase]( @idSucursal ,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ')) + --conversión a base 36, investigar que es Suc
		 --REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),CONVERT(VARCHAR(2),@consecutivo)))) + CONVERT(VARCHAR(2),@consecutivo) +  
		 @idTipoReferencia+@serie + @factura
	RETURN @referencia
END


go

