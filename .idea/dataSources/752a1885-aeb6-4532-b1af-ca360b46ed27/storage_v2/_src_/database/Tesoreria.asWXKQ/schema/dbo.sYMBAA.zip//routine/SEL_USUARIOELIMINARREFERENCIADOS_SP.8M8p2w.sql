-- =============================================
-- Author:		Ing. Luis Antonio García Perrusquía
-- Create date: 19/09/2018
-- Description:	SP Que nos devuelven si los usuarios tienen permiso de eliminar referenciados
-- =============================================
CREATE PROCEDURE [dbo].[SEL_USUARIOELIMINARREFERENCIADOS_SP]
	@idUsuario INT
AS
BEGIN
	IF EXISTS(SELECT seg_idPortal FROM [Seguridad].[dbo].[SEG_CENTRALIZACION] WHERE seg_idPortal = 9 AND seg_idModulo = 7 AND seg_idAccion = 18 AND seg_idUsuario = @idUsuario)
		BEGIN
			SELECT elimina = 1;
		END
	ELSE
		BEGIN
			SELECT elimina = 0;
		END
END
go

