-- =============================================
-- Author:		<Author,Rodrigo Olivares>
-- Create date: <Create Date, 2017-11-27>
-- Description:	EXECUTE [DBO].[SEL_AUXILIAR_CONTABLE_SANTANDER] 1, '1100-0020-0001-0018', 1, '2017-11-01', '2017-11-28', 'TREEUN', '65504258249'
-- =============================================
CREATE  PROCEDURE [dbo].[SEL_AUXILIAR_CONTABLE_SANTANDER] 
	-- Add the parameters for the stored procedure here
	@idEmpresa INT,
	@noCuenta VARCHAR(100),
	@idEstatus INT,
	@fechaElaboracion VARCHAR(50),
	@fechaCorte VARCHAR(50),
	@polizaPago VARCHAR(30),
	@cuentaBancaria VARCHAR(30)
AS
BEGIN TRY
DECLARE @MesMov INT = MONTH(convert(DATE, convert(date,@fechaCorte), 103))
DECLARE @añoConsulta INT = YEAR(CONVERT(DATE,(CONVERT(DATE,@fechaCorte)),103))
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	 DECLARE @ipLocal NVARCHAR(50) = ''
			,@ip_catbases NVARCHAR(50) = ''			
			,@Base NVARCHAR(50) = ''

SELECT	@ipLocal = dec.local_net_address
FROM	sys.dm_exec_connections AS dec
WHERE	dec.session_id = @@SPID;
--------------------------------------------------------------------------------------------------
--Obtiene los datos de la CONCENTRADORA
--------------------------------------------------------------------------------------------------
SELECT	@ip_catbases = (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN ''
							ELSE ip_servidor 
						END),
		@idEmpresa	= emp_idempresa,
		@Base		= (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN '[' + nombre_base + '].[DBO].' 
							ELSE '['+ ip_servidor + '].[' + nombre_base + '].[DBO].' 
						END)
FROM	[CentralizacionV2].[dbo].[DIG_CAT_BASES_BPRO]
WHERE	emp_idempresa	= @idEmpresa 
		AND tipo		= 2

--SELECT @Base
  DECLARE @query2 NVARCHAR(MAX) = ''
  DECLARE @query3 NVARCHAR(MAX) = ''
  ---------------------------------------------CARGOS
  DECLARE @query NVARCHAR(MAX) =
      'SELECT '+ char(13) + 
	   +'[idAuxiliarContable] AS idAuxiliarContable '+ char(13) +
       +',[idEmpresa] AS idEmpresa '+ char(13) +
       +',[movMes] AS movMes '+ char(13) +
       +',[movConsMov] AS movConsMov '+ char(13) +
       +',[numeroCuenta] AS numeroCuenta '+ char(13) +
       +',[polTipo] AS polTipo '+ char(13) +
       +',[polConsecutivo] AS polConsecutivo '+ char(13) +
       +',[movConcepto] AS movConcepto '+ char(13) +
       +',[cargo] AS cargo '+ char(13) +
       +',[abono] AS abono '+ char(13) +
       +',convert(VARCHAR(10),[movFechaOpe],120) AS movFechaOpe '+ char(13) +
	   +',[movHoraOpe] AS movHoraOpe '+ char(13) +
       +',[idEstatus] AS idEstatus '+ char(13) +
	  +',CASE '+ char(13) +
						+'WHEN [movMes] < 11 '+ char(13) +
							+'THEN 1 '+ char(13) +
						+'ELSE 0 '+ char(13) +
					+'END fechaAnterior '+ char(13) +
	  +','''' color '+ char(13) +
	  +',ISNULL(CXC_PAGANTDET.PAD_REFERENCIA,'''') referenciaAuxiliar '+ char(13) + --LQMA add parametro pre-punteo
	 +'FROM [AuxiliarContable] ' + char(13) +
	 --LQMA BEGIN add parametro para pre punteo
	 +'LEFT JOIN '+ @Base + 'CON_MOVDET01'+CONVERT(VARCHAR(4),@añoConsulta)+' MOV_2017 ON  MOV_2017.MOV_CONSPOL = polConsecutivo '+ char(13) +
											+'AND MOV_2017.MOV_MES = movMes '+ char(13) +
											+'AND MOV_2017.MOV_NUMCTA = ''' + @noCuenta + ''' '+ char(13) +--'1100-0030-0001-0001' --parametro
											+'AND MOV_2017.MOV_FECHOPE BETWEEN ''' +@fechaCorte+ ''' and ''' +@fechaElaboracion+ ''''
											+'AND MOV_2017.MOV_CONSPOL = polConsecutivo '+ char(13) +
											+'AND MOV_2017.MOV_TIPOPOL  COLLATE Modern_Spanish_CI_AS = polTipo '+ char(13) +

	 +'LEFT JOIN '+ @Base + 'CON_CAR01'+CONVERT(VARCHAR(4),@añoConsulta)+' CAR_2017 ON  CAR_2017.CCP_TIPOPOL = MOV_2017.MOV_TIPOPOL '+ char(13) +
											+'AND CAR_2017.CCP_CONSPOL = MOV_2017.MOV_CONSPOL '+ char(13) +
											+'AND CAR_2017.CCP_MES = MOV_2017.MOV_MES '+ char(13) +
											+'AND CAR_2017.CCP_TIPODOCTO = MOV_2017.MOV_TIPODOCTO '+ char(13) +
											+'AND CAR_2017.CCP_FECHOPE BETWEEN ''' +@fechaCorte+ ''' and ''' +@fechaElaboracion+ ''''
	
	 +'LEFT JOIN '+ @Base + 'CXC_PAGANT ON CXC_PAGANT.PAM_IDDOCTO = CAR_2017.CCP_REFER ' + char(13) +
	 +'LEFT JOIN '+ @Base + 'CXC_PAGANTDET ON CXC_PAGANTDET.PAD_CONSPAGO = CXC_PAGANT.PAM_CONSCARTERA '+ char(13) +
	 +'WHERE idEmpresa = '  + CONVERT(VARCHAR(5), @idEmpresa) +' and numeroCuenta = ''' + @noCuenta + ''' AND '+ char(13) +
	 +'idEstatus = ' + CONVERT(VARCHAR(5), @idEstatus) + ' ' + char(13) +
	 +'AND cargo <> 0 '+ char(13) +
	 +'AND polTipo <> '''+ @polizaPago +''' ' --Agregue esta condición el día 20-07-2017 RO
	 +'AND [movMes] = MONTH(convert(DATE, convert(date, ''' + @fechaCorte + '''), 103)) '+ char(13) +--Numero correspondiente al mes de Octubre
	 +'AND [movFechaOpe] BETWEEN '''+ @fechaElaboracion +''' and '''+ @fechaCorte +''''
	 +'AND YEAR(convert(DATE, convert(date,[movFechaOpe]), 103)) = YEAR(convert(DATE, convert(date,''' + @fechaCorte + '''), 103)) '+ char(13) +
	 +'AND idAuxiliarContable NOT IN ( '+ char(13) +
--Identifico los tipos de poliza dependiendo las sucursales 
     +'SELECT   DISTINCT([idAuxiliarContable]) AS idAuxiliar '+ char(13) +
	 +'			FROM AuxiliarContable aux '+ char(13) +
	 +'			LEFT JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] catB '+ char(13) +
	 +'			ON catB.Tipo_Poliza = aux.polTipo '+ char(13) +
	 +'			LEFT JOIN '+ @Base + 'CON_CAR01'+CONVERT(VARCHAR(4),@añoConsulta)+' conCar '+ char(13) +
	 +'			ON  conCar.CCP_MES = aux.movMes '+ char(13) +
	 +'			AND conCar.CCP_CONSMOV = aux.movConsMov '+ char(13) +
	 +'			AND conCar.CCP_CONSPOL = aux.polConsecutivo '+ char(13) +
	 +'			WHERE aux.numeroCuenta = '''+ @noCuenta +''''+ char(13) +
	 +'			AND aux.movMes = MONTH(convert(DATE, convert(date, ''' + @fechaCorte + '''), 103))'+ char(13) +
	 +'			AND aux.idEmpresa = '+ CONVERT(VARCHAR(5), @idEmpresa) +' '+ char(13) +
	 +'			AND aux.abono = 0 '+ char(13) +
	 +'			AND aux.movFechaOpe  between '''+ @fechaElaboracion +''' and '''+ @fechaCorte +''''+ char(13) +
	 +'			AND catB.emp_idempresa = '+ CONVERT(VARCHAR(5), @idEmpresa) +' '+ char(13) +
	 +'			AND catB.Tipo_Poliza IS NOT NULL)'
	 -----------------------------------------------------ABONOS
SET @query2 = 'UNION '+ char(13) +
	   'SELECT '+ char(13) +
	  +' [idAuxiliarContable] AS idAuxiliarContable '+ char(13) +
      +',[idEmpresa] AS idEmpresa '+ char(13) +
      +',[movMes] AS movMes '+ char(13) +
      +',[movConsMov] AS movConsMov '+ char(13) +
      +',[numeroCuenta] AS numeroCuenta '+ char(13) +
      +',[polTipo] AS polTipo '+ char(13) +
	  +',[polConsecutivo] AS polConsecutivo '+ char(13) +
      +',[movConcepto] AS movConcepto '+ char(13) +
      +',[cargo] AS cargo '+ char(13) +
      +',[abono] AS abono '+ char(13) +
      +',convert(VARCHAR(10),[movFechaOpe],120) AS movFechaOpe '+ char(13) +	  
      +',[movHoraOpe] AS movHoraOpe '+ char(13) +
      +',[idEstatus] AS idEstatus '+ char(13) +
	  +',CASE '+ char(13) +
						+'WHEN [movMes] < 11 '+ char(13) +
							+'THEN 1 '+ char(13) +
						+'ELSE 0 '+ char(13) +
					+'END fechaAnterior '+ char(13) +
	  +','''' color	'+ char(13) +
	  +',ISNULL(CXC_PAGANTDET.PAD_REFERENCIA,'''') referenciaAuxiliar ' + char(13) +--LQMA add parametro pre-punteo
	+'FROM [AuxiliarContable] '+ char(13) +
	--LQMA BEGIN add parametro para pre punteo
	+'LEFT JOIN '+ @Base + 'CON_MOVDET01'+CONVERT(VARCHAR(4),@añoConsulta)+' MOV_2017 ON  MOV_2017.MOV_CONSPOL = polConsecutivo '+ char(13) +
											+'AND MOV_2017.MOV_MES = movMes '+ char(13) +
											+'AND MOV_2017.MOV_NUMCTA = ''' + @noCuenta + ''' '+ char(13) +--'1100-0030-0001-0001' --parametro
											+'AND MOV_2017.MOV_FECHOPE BETWEEN ''' +@fechaCorte+ ''' and ''' +@fechaElaboracion+ ''''+ char(13) +
											+'AND MOV_2017.MOV_CONSPOL = polConsecutivo '+ char(13) +
											+'AND MOV_2017.MOV_TIPOPOL  COLLATE Modern_Spanish_CI_AS = polTipo '+ char(13) +

	+'LEFT JOIN '+ @Base + 'CON_CAR01'+CONVERT(VARCHAR(4),@añoConsulta)+' CAR_2017 ON  CAR_2017.CCP_TIPOPOL = MOV_2017.MOV_TIPOPOL '+ char(13) +
											+'AND CAR_2017.CCP_CONSPOL = MOV_2017.MOV_CONSPOL '+ char(13) +
											+'AND CAR_2017.CCP_MES = MOV_2017.MOV_MES '+ char(13) +
											+'AND CAR_2017.CCP_TIPODOCTO = MOV_2017.MOV_TIPODOCTO '+ char(13) +
											+'AND CAR_2017.CCP_FECHOPE BETWEEN ''' +@fechaCorte+ ''' and ''' +@fechaElaboracion+ ''''+ char(13) +
	
	+'LEFT JOIN '+ @Base + 'CXC_PAGANT ON CXC_PAGANT.PAM_IDDOCTO = CAR_2017.CCP_REFER '+ char(13) + 
	+'LEFT JOIN '+ @Base + 'CXC_PAGANTDET ON CXC_PAGANTDET.PAD_CONSPAGO = CXC_PAGANT.PAM_CONSCARTERA '+ char(13) +
	+'WHERE idEmpresa =' + CONVERT(VARCHAR(5), @idEmpresa) + ' and numeroCuenta =''' + @noCuenta + ''' AND '+ char(13) +
	+'idEstatus =' + CONVERT(VARCHAR(5), @idEstatus) + ' '+ char(13) +
	+'AND abono <> 0'+ char(13) +
	+'AND [movMes] = MONTH(convert(DATE, convert(date,''' + @fechaCorte + '''), 103)) '+ char(13) +--Numero correspondiente al mes de Octubre
	+'AND [movFechaOpe] BETWEEN '''+ @fechaElaboracion +''' and '''+ @fechaCorte +''''
	+'AND YEAR(convert(DATE, convert(date,[movFechaOpe]), 103)) = YEAR(convert(DATE, convert(date,''' + @fechaCorte + '''), 103)) '+ char(13) +
	+'AND CAR_2017.CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS NOT IN(' +char(13)+
    +'                                   SELECT idDocto 
								         FROM Pagos.dbo.PAG_REL_DOCTOS_BANCOS
								         WHERE idBanco = 3
										 AND pal_id_empresa = ' + CONVERT(VARCHAR(5), @idEmpresa) + '
										 AND CONVERT(VARCHAR(10),CONVERT(DATE,(prdb_fechaAplica),103)) BETWEEN '''+ @fechaElaboracion +''' and '''+ @fechaCorte +''''									 
	+')'
SET @query3 = ' ORDER BY convert(VARCHAR(10),[movFechaOpe],120) DESC '

EXECUTE(@query + @query2 + @query3)
END TRY
BEGIN CATCH
            SELECT ERROR_LINE() + '' + ERROR_MESSAGE() AS ERROR 
END CATCH
go

