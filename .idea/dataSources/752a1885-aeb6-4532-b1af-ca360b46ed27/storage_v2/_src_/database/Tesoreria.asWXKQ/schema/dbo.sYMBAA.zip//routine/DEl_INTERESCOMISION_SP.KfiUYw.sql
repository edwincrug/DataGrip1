CREATE PROCEDURE [dbo].[DEl_INTERESCOMISION_SP]
	@interesComisionID AS INT
AS
BEGIN
	DECLARE @idcomisionesinterese INT = (SELECT coi_idcomisionesintereses FROM [cxp_comisionesintereses] WHERE interesComisionID = @interesComisionID);

	DELETE FROM [InteresComision] WHERE interesComisionID = @interesComisionID;
	DELETE FROM [cxp_comisionesintereses] WHERE interesComisionID = @interesComisionID;
	DELETE FROM [cxp_comisionesinteresesdet] WHERE coi_idcomisionesintereses = @idcomisionesinterese;
 
	SELECT '0' result
END


go

