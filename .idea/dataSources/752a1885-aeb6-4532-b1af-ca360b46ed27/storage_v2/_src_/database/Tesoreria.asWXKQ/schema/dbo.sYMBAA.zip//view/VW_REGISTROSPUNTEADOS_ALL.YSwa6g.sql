

CREATE VIEW [dbo].[VW_REGISTROSPUNTEADOS_ALL] AS
			SELECT  [rpun_idPunteado]
				  ,[rpun_grupoPunteo]
				  ,[rpun_idCargo]
				  ,[rpun_idAbono]
				  ,[rpun_tipo]
				  ,[rpun_fechaPunteo]
				  ,[rpun_usuario]
				  ,[rpun_idAplicado]
				  ,[idMes] FROM REGISTROS_PUNTEADOS
			UNION ALL 
			SELECT [rpun_idPunteado]
				  ,[rpun_grupoPunteo]
				  ,[rpun_idCargo]
				  ,[rpun_idAbono]
				  ,[rpun_tipo]
				  ,[rpun_fechaPunteo]
				  ,[rpun_usuario]
				  ,[rpun_idAplicado]
				  ,[idMes] FROM REGISTROS_PUNTEADOS_ERR
			UNION ALL 
			SELECT [rpun_idPunteadoCan]
				  ,[rpun_grupoPunteo]
				  ,[rpun_idCargo]
				  ,[rpun_idAbono]
				  ,[rpun_tipo]
				  ,[rpun_fechaPunteo]
				  ,[rpun_usuario]
				  ,[rpun_idAplicado]
				  ,[idMes]
			  FROM [dbo].[REGISTROS_PUNTEADOS_CAN]


go

