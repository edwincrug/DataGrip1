
-- =============================================
-- Author:		<Irving Solorio>, <Alejandro Grijalva Antonio>
-- Create date: <21/01/2019>
-- Description:	<Forma de pago no definida refantypaq>
-- =============================================
--[dbo].[FormaPago_SEL] 4,3,'65500507299'
CREATE PROCEDURE [dbo].[FormaPago_SEL]
	@idEmpresa INT         = 0,
    @idBanco INT            = 0,
    @numCuenta NVARCHAR(20) = NULL--'000000148333084'
AS
BEGIN
    SELECT c.[rap_folio]
        ,[rap_referenciabancaria]
        ,[rap_referencia]
        ,[rap_iddocto]
        ,[rap_cotped]
        ,[rap_importe]
        ,[rap_idsucursal]
        ,ca.suc_nombre sucursal
        ,[rap_iddepartamento]
        ,de.dep_nombre
        ,[rap_idpersona]
        ,p.PER_NOMRAZON+ ' ' +p.PER_PATERNO + ' '+ p.PER_MATERNO persona
        ,[rap_formapago]
        ,c.rap_numctabanc
        ,SUBSTRING ( c.rap_numctabanc ,( LEN(c.rap_numctabanc) - 3 ) , LEN(c.rap_numctabanc) ) cuenta
        ,c.rap_banco
        ,UPPER(B.nombre) Banco
        ,mov.codigoLeyenda
        ,CI.Descripcion TipoPago
    FROM  GA_Corporativa.dbo.cxc_refantypag c
    INNER JOIN [ControlAplicaciones].dbo.cat_sucursales ca ON c.rap_idsucursal=ca.suc_idsucursal
    INNER JOIN [ControlAplicaciones].dbo.cat_departamentos de ON c.rap_iddepartamento=de.dep_iddepartamento
    INNER JOIN GA_Corporativa.dbo.PER_PERSONAS p ON c.rap_idpersona = p.PER_IDPERSONA
    INNER JOIN ( SELECT DISTINCT(idBanco), idBancoBPRO, idEmpresa  FROM referencias.dbo.BancoCuenta WHERE idEmpresa = @idEmpresa  ) BAN ON BAN.idEmpresa = c.rap_idempresa AND BAN.idBancoBPRO = C.rap_banco
    INNER JOIN referencias.dbo.Banco B ON B.idBanco = BAN.idBanco
    INNER JOIN referencias.dbo.RAPDeposito RD ON RD.rap_folio = c.rap_folio
    INNER JOIN [controlDepositosView] mov ON mov.IDBanco = RD.idBanco AND rd.idDeposito = mov.idBmer
    left JOIN referencias.dbo.CodigoIdentificacion CI ON CI.CodigoBanco = mov.codigoLeyenda and mov.IDBanco = CI.IDBanco
    WHERE   rap_idstatus = 1 
            AND rap_formapago = 0
            AND ( rap_idempresa= @idEmpresa OR @idEmpresa IS  NULL )
            AND ( BAN.idBanco = @idBanco OR @idBanco = 0 )
            AND ( rap_numctabanc like '%'+REPLACE(LTRIM(REPLACE(@numCuenta, '0', ' ')),' ', '0')+'%' OR @numCuenta IS NULL )
END

go

