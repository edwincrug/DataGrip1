-- =============================================
-- Author:		Ing. Luis Antonio Garcia Perrusquia
-- Create date: 09/05/2018
-- Description:	Trae los registros del universo para los no conciliados
--select * from Centralizacionv2.[dbo].[DIG_CAT_BASES_BPRO] where emp_idempresa=5
--select * from referencias.[dbo].[BancoCuenta] where idempresa=5
-- EXECUTE [dbo].[SEL_TODO_CONTABLE_SP] 5, 1, '1100-0020-0001-0001', 1, '2019-01-01', '2019-01-31', 'TREEAZ', '000000000145881986'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TODO_CONTABLE_SP]
@idEmpresa INT,
@idBanco INT,
@noCuenta VARCHAR(100),
@idEstatus INT,
@fechaElaboracion VARCHAR(50),
@fechaCorte VARCHAR(50),
@polizaPago VARCHAR(30),
@cuentaBancaria VARCHAR(30)	
AS
BEGIN TRY


-------------------------------------------------------------------------------------------------------------------
	SET LANGUAGE Español

	SELECT	
		MOV.IDABONOS_COMPLETO idAuxiliarContable,
		@idEmpresa idEmpresa,
		MOV.MOV_CONSMOV movConsMov,
		MOV.MOV_NUMCTA numeroCuenta,
		MOV.MOV_TIPOPOL polTipo,
		MOV.MOV_CONSPOL polConsecutivo,
		MOV.MOV_CONCEPTO movConcepto,
		MOV.MOV_DEBE cargo,
		MOV.MOV_HABER abono,
		MOV.MOV_FECHOPE movFechaOpe,
		MOV.MOV_HORAOPE movHoraOpe,
		1 idEstatus,
		0 fechaAnterior,
		'' color,
		'' referenciaAuxiliar,
		UPPER(DATENAME(YEAR, CONVERT(DATE,MOV_FECHOPE,103))) anio,
		UPPER(DATENAME(month, CONVERT(DATE, '01/' + CONVERT(VARCHAR(2), MOV.MOV_MES) + '/' + CONVERT(VARCHAR(4), MOV.anio),103))) MES,
		0 esCargo,
		punErr = CASE WHEN PUNE.rpun_idPunteado IS NULL THEN 0 ELSE 1 END
	FROM  [ABONOS_COMPLETO_CB] MOV
	LEFT JOIN [REGISTROS_PUNTEADOS]		PUN		ON MOV.IDABONOS_COMPLETO= PUN.rpun_idAbono AND PUN.rpun_tipo = 'C'
	LEFT JOIN VW_REGISTROS_PUNTEADOS_ERR PUNE ON MOV.IDABONOS_COMPLETO = PUNE.rpun_idAbono AND PUNE.rpun_tipo = 'C' AND PUNE.rpun_usuario != 0
	WHERE   MOV.MOV_NUMCTA = @noCuenta 
   			AND MOV.idEmpresa = @idEmpresa 
   			AND MOV.idBanco = @idBanco
			AND MOV.idEstatus IN (0,2)
			AND PUN.rpun_idPunteado IS NULL   			 
	
	UNION ALL

	SELECT	distinct
		MOV.IDCARGOS_COMPLETO idAuxiliarContable,--MOV_CONSPOL idAuxiliarContable,
		@idEmpresa idEmpresa,
		MOV.MOV_CONSMOV movConsMov, --?
		MOV.MOV_NUMCTA numeroCuenta,
		MOV.MOV_TIPOPOL polTipo,
		MOV.MOV_CONSPOL polConsecutivo,
		MOV.MOV_CONCEPTO movConcepto,
		MOV.MOV_DEBE cargo,
		MOV.MOV_HABER abono,
		MOV.MOV_FECHOPE movFechaOpe,
		MOV.MOV_HORAOPE movHoraOpe,
		1 idEstatus,
		0 fechaAnterior,
		'' color,
		'' referenciaAuxiliar,
		UPPER(DATENAME(YEAR, CONVERT(DATE,MOV_FECHOPE,103))) anio,
		UPPER(DATENAME(month, CONVERT(DATE, '01/' + CONVERT(VARCHAR(2), MOV.MOV_MES) + '/' + CONVERT(VARCHAR(4), MOV.anio),103))) MES,
		1 esCargo,
		punErr = CASE WHEN PUNE.rpun_idPunteado IS NULL THEN 0 ELSE 1 END
	FROM  [CARGOS_COMPLETO_CB] MOV
	LEFT JOIN REGISTROS_PUNTEADOS		PUN		ON MOV.IDCARGOS_COMPLETO = PUN.rpun_idCargo AND PUN.rpun_tipo = 'C'
	LEFT JOIN VW_REGISTROS_PUNTEADOS_ERR PUNE ON MOV.IDCARGOS_COMPLETO = PUNE.rpun_idCargo AND PUNE.rpun_tipo = 'C' AND PUNE.rpun_usuario != 0
	WHERE   MOV.MOV_NUMCTA = @noCuenta 
   			AND MOV.idEmpresa = @idEmpresa 
   			AND MOV.idBanco = @idBanco
			AND MOV.idEstatus IN (0,2)
			AND PUN.rpun_idPunteado IS NULL
		
END TRY
BEGIN CATCH
			SELECT ERROR_MESSAGE() +'' + ERROR_LINE() AS ERROR
END CATCH


go

