-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-06-27
-- Description:	Elimina los registros eliminados 
-- desde BPRO y si esta punteado elimina el punteo
-- =============================================
CREATE PROCEDURE [dbo].[CON_ELIMINADESDEBPRO_SP]
	@NumCTA VARCHAR(50) = '',
	@idEmpresa INT		= 0,
	@mes INT			= 0,
	@anio INT			= 0
AS
BEGIN
	DECLARE @TempCONTABLE TABLE(
		IDCOMPLETO NUMERIC(18,0)
	);


	DECLARE @ipLocal VARCHAR(15) = (
		SELECT	dec.local_net_address
		FROM	sys.dm_exec_connections AS dec
		WHERE	dec.session_id = @@SPID
	);

	DECLARE @Base VARCHAR(300) = ''
	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			SET @Base = (SELECT '[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
		END
	ELSE
		BEGIN
			SET @Base = (SELECT '[' + ip_servidor + '].[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
		END

	DECLARE @QueryDelPUN VARCHAR(MAX) = 
	'SELECT 
		TESO.IDCARGOS_COMPLETO
	FROM CARGOS_COMPLETO_CB TESO
	LEFT JOIN ' + @Base + ' BPRO ON TESO.MOV_CONSPOL		= BPRO.MOV_CONSPOL
									AND TESO.MOV_TIPOPOL	= BPRO.MOV_TIPOPOL COLLATE SQL_Latin1_General_CP1_CI_AS
									AND TESO.MOV_CONSMOV	= BPRO.MOV_CONSMOV
									AND TESO.MOV_MES		= BPRO.MOV_MES
									AND BPRO.MOV_DEBE		<> 0
									AND TESO.MOV_MES		= ' + CONVERT(VARCHAR(2), @mes) + '
									AND TESO.MOV_NUMCTA		= BPRO.MOV_NUMCTA COLLATE SQL_Latin1_General_CP1_CI_AS
	WHERE	TESO.MOV_NUMCTA = ''' + @NumCTA + ''' 
			AND TESO.MOV_MES = ' + CONVERT(VARCHAR(2), @mes) + ' 
			AND TESO.idEmpresa = ' + CONVERT(VARCHAR(2), @idEmpresa) + ' 
			AND BPRO.MOV_CONSPOL IS NULL and TESO.anio='+convert(nvarchar(4),@anio)

	INSERT INTO @TempCONTABLE
	EXEC (@QueryDelPUN);

	DELETE FROM REGISTROS_PUNTEADOS WHERE rpun_grupoPunteo IN (
		SELECT 
			rpun_grupoPunteo 
		FROM @TempCONTABLE T
		INNER JOIN REGISTROS_PUNTEADOS P ON T.IDCOMPLETO = rpun_idCargo AND rpun_tipo = 'C'
		WHERE rpun_tipo = 'C' AND rpun_idAplicado != 3
	);

	DELETE FROM CARGOS_COMPLETO_CB WHERE IDCARGOS_COMPLETO IN ( SELECT IDCOMPLETO FROM @TempCONTABLE );

	DELETE FROM @TempCONTABLE;

	SET @QueryDelPUN = 
	'SELECT 
		TESO.IDABONOS_COMPLETO
	FROM ABONOS_COMPLETO_CB TESO
	LEFT JOIN ' + @Base + ' BPRO ON TESO.MOV_CONSPOL		= BPRO.MOV_CONSPOL
																				AND TESO.MOV_TIPOPOL	= BPRO.MOV_TIPOPOL COLLATE SQL_Latin1_General_CP1_CI_AS
																				AND TESO.MOV_CONSMOV	= BPRO.MOV_CONSMOV
																				AND TESO.MOV_MES		= BPRO.MOV_MES
																				AND BPRO.MOV_HABER		<> 0
																				AND TESO.MOV_MES		= ' + CONVERT(VARCHAR(2), @mes) + '
																				AND TESO.MOV_NUMCTA		= BPRO.MOV_NUMCTA COLLATE SQL_Latin1_General_CP1_CI_AS
	WHERE TESO.MOV_NUMCTA = ''' + @NumCTA + ''' AND TESO.MOV_MES = ' + CONVERT(VARCHAR(2), @mes) + ' AND TESO.idEmpresa = ' + CONVERT(VARCHAR(2), @idEmpresa) + ' AND BPRO.MOV_CONSPOL IS NULL and TESO.anio='+convert(nvarchar(4),@anio)

	INSERT INTO @TempCONTABLE
	EXEC (@QueryDelPUN);

	DELETE FROM REGISTROS_PUNTEADOS WHERE rpun_grupoPunteo IN (
		SELECT 
			rpun_grupoPunteo 
		FROM @TempCONTABLE T
		INNER JOIN REGISTROS_PUNTEADOS P ON T.IDCOMPLETO = rpun_idAbono AND rpun_tipo = 'C'
		WHERE rpun_tipo = 'C'  AND rpun_idAplicado != 3
	);

	DELETE FROM ABONOS_COMPLETO_CB WHERE IDABONOS_COMPLETO IN ( SELECT IDCOMPLETO FROM @TempCONTABLE );
END
go

