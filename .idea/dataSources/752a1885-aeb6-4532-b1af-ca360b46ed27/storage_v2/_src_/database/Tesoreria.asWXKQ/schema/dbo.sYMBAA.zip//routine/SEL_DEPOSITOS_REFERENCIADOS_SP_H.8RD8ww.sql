/*

[SEL_DEPOSITOS_REFERENCIADOS_SP_H] 1,1,'000000000195334667',1,6

*/

CREATE PROCEDURE [dbo].[SEL_DEPOSITOS_REFERENCIADOS_SP_H] -- [SEL_DEPOSITOS_REFERENCIADOS_SP] 1,1,'000000000195334667'
@idBanco INT = 0,
@idEstatus INT = 0,
@noCuenta VARCHAR(50) = '',
@fechaElaboracion VARCHAR(30),
--@fechaCorte	VARCHAR(30),
@idEmpresa INT = 0,
@idHistorico NUMERIC(18,0) = 0

AS	
BEGIN

IF @idBanco = 1
BEGIN
		DECLARE @mesActual INT;
		SELECT @mesActual = DATEPART(MONTH,REPLACE(@fechaElaboracion,'-',''))
      --EXECUTE [SEL_DEPOSITOS_REFERENCIADOS_BANCOMER] @idBanco, @idEstatus, @noCuenta, @fechaElaboracion, @fechaCorte, @idEmpresa
	SELECT 
		*,
		'' abono, 
		'' cargo, 
		0 fechaAnterior,
		'' color, 
		IDBanco idBanco, 
		UPPER(DATENAME(month, CONVERT(DATE,fechaOperacion,103))) MES,
		UPPER(DATENAME(YEAR, CONVERT(DATE,fechaOperacion,103))) anio
	FROM ABONOSBANCOS_CB_H WHERE idBmer NOT IN (SELECT idDepositoBanco FROM PunteoAuxiliarBanco_H)
	AND idBmer NOT IN (SELECT idAbonoBanco FROM DepositoBancarioDPI_H)
	AND idHistorico = @idHistorico  AND DATEPART(MONTH,fechaOperacion) = @mesActual --AND DATEPART(MONTH,fechaOperacion) < @mesActual --Luis Antonio
			
END
IF @idBanco = 2
BEGIN
      SELECT 'BANCO NO DISPONIBLE' AS ERROR
END
IF @idBanco = 3
BEGIN
	  print 'sss'	
      --EXECUTE [SEL_DEPOSITOS_REFERENCIADOS_SANTANDER] @idBanco, @idEstatus, @noCuenta, @fechaElaboracion, @fechaCorte, @idEmpresa
END


	 --Selecciono el  último idPunteoAuxiliar para tener un identificador que relacione las conciliaciones Bancarias (CARGO - ABONO)
 SELECT 
		ISNULL(idAuxiliarContable,0)
		AS idRelationOfBancoRows 
        FROM [PunteoAuxiliarBanco_H]
		WHERE idPAdre = 4
		AND idDepositoBanco = (Select ISNULL(MAX(idDepositoBanco),0)
									 FROM [PunteoAuxiliarBanco_H]
									 WHERE idPAdre = 4
									       AND idBanco = @idBanco
										   and idEmpresa = @idEmpresa )
		AND idBanco = @idBanco
		AND idEmpresa = @idEmpresa


END
go

