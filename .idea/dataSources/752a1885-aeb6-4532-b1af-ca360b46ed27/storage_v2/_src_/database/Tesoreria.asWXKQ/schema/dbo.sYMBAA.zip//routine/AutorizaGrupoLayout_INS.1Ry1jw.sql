-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <30/10/2018>
-- Description:	<guarda la autorizacion del  grupo en el layout>
-- =============================================
--[dbo].[ValidaGrupoLayout_SEL] 228
CREATE PROCEDURE [dbo].[AutorizaGrupoLayout_INS]
			 @grupo int,
			 @idUsuario int
AS
BEGIN

update referencias.dbo.MovimientoBancarioLayout set status=1
where idGrupoIns = @grupo 

INSERT INTO tesoreria.[dbo].[AutorizaDuplicado]
           ([idGrupoIns]
           ,[idUsuario]
           ,[fecha])
     VALUES
           (@grupo
           ,@idUsuario
           ,getdate())

select 1 success,'Se autorizó correctamente su layout' msg
END
go

