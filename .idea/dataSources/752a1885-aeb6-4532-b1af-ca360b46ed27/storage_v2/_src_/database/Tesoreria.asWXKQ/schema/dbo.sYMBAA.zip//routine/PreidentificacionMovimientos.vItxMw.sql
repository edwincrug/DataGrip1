-- =============================================
-- Author:
-- Create date:
-- Description:
-- exec PreidentificacionMovimientos 0,49024,'A','prueba'
-- =============================================
CREATE PROCEDURE dbo.PreidentificacionMovimientos
-- Add the parameters for the stored procedure here
@opcion varchar(1)
,@movi varchar(10)
,@tipoMovimiento varchar(1)
,@observacion NVARCHAR(255)
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
    -- Insert statements for procedure here
IF(@opcion=1)
BEGIN 
IF EXISTS(SELECT * FROM PreIdentitificacionMovimientosBancarios WHERE idMovimiento = @movi AND activo = 1)
BEGIN
SELECT 'Error' as estatus, 'El movimeinto ya esta pre- identificado' as mensaje
END
ELSE
BEGIN
insert into PreIdentitificacionMovimientosBancarios(idMovimiento, tipoMovimiento,Observacion, activo, fechaCreacion, fechaModificacion)
values(@movi, @tipoMovimiento, @observacion, 1, GETDATE(), NULL)
SELECT 'Ok' as estatus, 'El movimeinto se pre-identifico correctamente' as mensaje
END

END
ELSE
BEGIN
IF EXISTS(SELECT * FROM PreIdentitificacionMovimientosBancarios WHERE idMovimiento = @movi AND activo = 1)
BEGIN
update mov
SET activo = 0, fechaModificacion = GETDATE(), Observacion = @observacion
FROM PreIdentitificacionMovimientosBancarios mov
WHERE idMovimiento = @movi 
AND activo = 1
SELECT 'Ok' as estatus, 'La pre-calificación ha sido borrada' as mensaje
END
ELSE
BEGIN
SELECT 'Error' as estatus, 'El movimiento no ha sido pre-identificado' as mensaje
END
END
END
go

exec sp_addextendedproperty 'MS_Description', '1 agregar 0 boraado logico', 'SCHEMA', 'dbo', 'PROCEDURE',
     'PreidentificacionMovimientos', 'PARAMETER', '@opcion'
go

exec sp_addextendedproperty 'MS_Description', 'id del movimiento', 'SCHEMA', 'dbo', 'PROCEDURE',
     'PreidentificacionMovimientos', 'PARAMETER', '@movi'
go

exec sp_addextendedproperty 'MS_Description', 'tipo de movimiento A: abono, C: cargo', 'SCHEMA', 'dbo', 'PROCEDURE',
     'PreidentificacionMovimientos', 'PARAMETER', '@tipoMovimiento'
go

exec sp_addextendedproperty 'MS_Description', 'Mensaje que se mostrara en la observacion del movimiento', 'SCHEMA',
     'dbo', 'PROCEDURE', 'PreidentificacionMovimientos', 'PARAMETER', '@observacion'
go

