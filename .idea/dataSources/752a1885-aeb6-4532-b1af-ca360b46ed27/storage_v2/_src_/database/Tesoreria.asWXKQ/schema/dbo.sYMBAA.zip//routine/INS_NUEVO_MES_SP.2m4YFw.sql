-- =============================================
-- Author:		Ing. Luis Antonio García Perrusquía
-- Create date: 06/06/2018
-- Description:	SP que inserta el nuevo mes y pone como conciliado el anterior
-- TEST EXECUTE [dbo].[INS_NUEVO_MES_SP]
-- =============================================
CREATE PROCEDURE [dbo].[INS_NUEVO_MES_SP] 

AS
BEGIN
	BEGIN TRY
	DECLARE @Mes VARCHAR(2), @Anio VARCHAR(4), @LastDay VARCHAR(2), @FechaIni DATE, @FechaFin DATE = GETDATE();

	SELECT @Mes = mec_numMes, @Anio = mec_anio FROM Meses_Conciliados WHERE mec_conciliado = 0;
	SELECT @FechaIni = CONVERT(DATE,DATEADD(MONTH, ((YEAR(CONVERT(DATE, @Anio + '-' + @Mes + '-01')) - 1900) * 12) + MONTH(CONVERT(DATE, @Anio + '-' + @Mes + '-01')), -1));

	IF( @FechaFin >= @FechaIni )
		BEGIN
			UPDATE Meses_Conciliados SET mec_conciliado = 1 WHERE mec_conciliado = 0;

			INSERT INTO Meses_Conciliados
			SELECT 
				[mec_numMes]	 = MONTH(DATEADD(month, 1, @FechaIni)),
				[mec_anio]		 = YEAR(DATEADD(month, 1, @FechaIni)),
				[mec_conciliado] = 0;
			SELECT success = 1, msg = 'Mes cerrado con éxito';
		END
	ELSE
		BEGIN
			SELECT success = 0, msg = 'Aún no es posible cerrar el mes que solicita';
		END
	END TRY
	BEGIN CATCH
		SELECT success = 0, msg = ERROR_MESSAGE() + ' ' + ERROR_LINE();
	END CATCH
END
go

