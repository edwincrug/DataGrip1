-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-05-17
-- Description:	Obtiene los registros punteados aplicados o no aplicados
-- [dbo].[SEL_PUNTEO_DETALLE_SP] 0, 1;
-- [dbo].[SEL_PUNTEO_DETALLE_SP] 1, 1;
-- [dbo].[SEL_PUNTEO_DETALLE_SP] 1;
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PUNTEO_DETALLE_SP_Luis]
	@idEmpresa INT = 0,
	@idBanco INT = 0,
	@noCuenta VARCHAR(60) = '',
	@cuentaContable VARCHAR(60) = ''
AS
BEGIN
	SELECT
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[idBmer]		= ABO.idBmer,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[referencia]	= ABO.referencia,
		[concepto]		= ABO.concepto + ' ' + ABO.refAmpliada,
		[cargo]			= CASE rpun_idCargo WHEN 0 THEN 0 ELSE ABO.importe END,
		[abono]			= CASE rpun_idAbono WHEN 0 THEN 0 ELSE ABO.importe END
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN  [ABONOSBANCOS_CB] ABO ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS
				AND ABO.idEmpresa = @idEmpresa
				AND ABO.IDBanco = @idBanco
				AND ABO.noCuenta = @noCuenta
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = ABO.IDBanco
	WHERE rpun_tipo = 'B'
		  AND idEmpresa = @idEmpresa
	UNION ALL
	SELECT
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[idBmer]		= CAR.idBmer,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[referencia]	= CAR.referencia,
		[concepto]		= CAR.concepto + ' ' + CAR.refAmpliada,
		[cargo]			= CASE rpun_idCargo WHEN 0 THEN 0 ELSE CAR.importe END,
		[abono]			= CASE rpun_idAbono WHEN 0 THEN 0 ELSE CAR.importe END
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN  [CARGOSBANCOS_CB] CAR ON PUN.rpun_idCargo = CAR.IDCARGOSBANCOS
				AND CAR.idEmpresa = @idEmpresa
				AND CAR.IDBanco = @idBanco
				AND CAR.noCuenta = @noCuenta
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = CAR.IDBanco
	WHERE rpun_tipo = 'B'
		  AND idEmpresa = @idEmpresa;

	SELECT 
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[Identificador] = CAR.IDCARGOS_COMPLETO,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[fecha]			= CAR.MOV_FECHOPE,
		[tipoPoliza]	= CAR.MOV_TIPOPOL,
		[poliza]		= CAR.MOV_CONSPOL,
		[concepto]		= CAR.MOV_CONCEPTO,
		[cargo]			= CAR.MOV_DEBE,
		[abono]			= CAR.MOV_HABER
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN  [CARGOS_COMPLETO_CB] CAR ON PUN.rpun_idCargo = CAR.IDCARGOS_COMPLETO
				AND CAR.idEmpresa = @idEmpresa
				AND CAR.idBanco = @idBanco
				AND CAR.MOV_NUMCTA = @cuentaContable
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = CAR.idBanco
	WHERE rpun_tipo = 'C'
		  AND idEmpresa = @idEmpresa
	UNION ALL
	SELECT 
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[Identificador] = ABO.IDABONOS_COMPLETO,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[fecha]			= ABO.MOV_FECHOPE,
		[tipoPoliza]	= ABO.MOV_TIPOPOL,
		[poliza]		= ABO.MOV_CONSPOL,
		[concepto]		= ABO.MOV_CONCEPTO,
		[cargo]			= ABO.MOV_DEBE,
		[abono]			= ABO.MOV_HABER
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN  [ABONOS_COMPLETO_CB] ABO ON PUN.rpun_idAbono = ABO.IDABONOS_COMPLETO
				AND ABO.idEmpresa = @idEmpresa
				AND ABO.idBanco = @idBanco
				AND ABO.MOV_NUMCTA = @cuentaContable
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = ABO.idBanco
	WHERE rpun_tipo = 'C'
		  AND idEmpresa = @idEmpresa;
END
go

