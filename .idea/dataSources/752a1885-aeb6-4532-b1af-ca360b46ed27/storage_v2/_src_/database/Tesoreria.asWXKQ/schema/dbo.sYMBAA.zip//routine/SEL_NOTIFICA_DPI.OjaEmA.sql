-- =============================================
-- Author:		Roberto Almanza Nieto
-- Create date: 08-04-2019
-- Description:	envia notificacion de DPI
-- =============================================
CREATE PROCEDURE [dbo].[SEL_NOTIFICA_DPI]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
DECLARE @tablaDatos TABLE(
idAbonoBanco int
,idEmpresa int
,idBanco int
,conspol int
,fecha datetime
,noPaso int
,rpun_idAbono int
,rpun_grupoPunteo int
,rpun_idAplicado int
,idmes int
,noCuenta varchar(50)
,cuentacontable varchar(50)
,idEstatus int
,mes int
,anio int
,existeRegistrosPunteados varchar(10)
,terminoProcesoDPI varchar(50)
,existeTablaDPI varchar(50)
,polizas varchar(20)
,movdet varchar(20)
,concar varchar(20)
,cfdi varchar(30)
,seatendio varchar(30)
)

DECLARE @tableHTML nvarchar(max) =''
DECLARE @destinatarios nvarchar(max) =''

SELECT @destinatarios = dm.destinatarios FROM dbo.DestinatariosMonitores dm WHERE dm.id = 4

INSERT INTO @tablaDatos
(
    idAbonoBanco,
    idEmpresa,
    idBanco,
    conspol,
    fecha,
    noPaso,
    rpun_idAbono,
    rpun_grupoPunteo,
    rpun_idAplicado,
    idmes,
    noCuenta,
    cuentacontable,
    idEstatus,
    mes,
    anio,
    existeRegistrosPunteados,
    terminoProcesoDPI,
    existeTablaDPI,
    polizas,
    movdet,
    concar,
    cfdi,
    seatendio
)
SELECT [idAbonoBanco]
      ,[idEmpresa]
      ,[idBanco]
      ,[conspol]
      ,[fecha]
      ,[noPaso]
      ,[rpun_idAbono]
      ,[rpun_grupoPunteo]
      ,[rpun_idAplicado]
      ,[idmes]
      ,[noCuenta]
      ,[cuentacontable]
      ,[idEstatus]
      ,[mes]
      ,[anio]
      ,[existeRegistrosPunteados]
      ,[terminoProcesoDPI]
      ,[existeTablaDPI]
      ,[polizas]
      ,[movdet]
      ,[concar]
      ,[cfdi]
      ,[seatendio]
  FROM [Tesoreria].[dbo].[VW_VALIDAMONITORDPI]
  where (existeRegistrosPunteados = 'No' or terminoProcesoDPI = 'No' or existeTablaDPI= 'No')
  --and mes=month(getdate()) and anio = year(getdate())
  and mes=2 and anio = year(getdate())

if(@@ROWCOUNT > 0)
BEGIN

SET @tableHTML =
		N'<html>'+
		N'<head>'+
		N'<style>'+
		N'table {'+
		N'border-collapse: collapse;'+
		N'width: 100%;'+
		N'}'+
		N'th, td {'+
		N'text-align: left;'+
		N'padding: 8px;'+
		N'font-size: x-small;'+
		N'}'+
		N'th {'+
		N'text-align: center;'+
		N'}'+
		N'tr:nth-child(even) {background-color: #E6F2FF;}'+
		N'</style>'+
		N'</head>' +
		N'<body>' +
		N'<div style="overflow-x:auto;">'+
        N'<H1>DPIs</H1>' +
        N'<table>' +
        N'<tr>'+
			N'<th>idAbonoBanco</th>' +
			N'<th>idEmpresa</th>' +
			N'<th>idBanco</th>' +
			N'<th>conspol</th>' +
			N'<th>fecha</th>' +
			N'<th>noPaso</th>' +
			N'<th>rpun_idAbono</th>' +
			N'<th>rpun_grupoPunteo</th>' +
			N'<th>rpun_idAplicado</th>' +
			N'<th>idmes</th>' +
			N'<th>noCuenta</th>' +
			N'<th>cuentacontable</th>' +
			N'<th>idEstatus</th>' +
			N'<th>mes</th>' +
			N'<th>anio</th>' +
			N'<th>existeRegistrosPunteados</th>' +
			N'<th>terminoProcesoDPI</th>' +
			N'<th>existeTablaDPI</th>' +
			N'<th>polizas</th>' +
			N'<th>movdet</th>' +
			N'<th>concar</th>' +
			N'<th>cfdi</th>' +
			N'<th>seatendio</th>' +
		N'</tr>' +
		CAST ( ( SELECT      
					td = idAbonoBanco, ''
					,td =idEmpresa, ''
					,td =idBanco, ''
					,td =conspol, ''
					,td =fecha, ''
					,td =noPaso, ''
					,td =rpun_idAbono, ''
					,td =rpun_grupoPunteo, ''
					,td =rpun_idAplicado, ''
					,td =idmes, ''
					,td =noCuenta, ''
					,td =cuentacontable, ''
					,td =idEstatus, ''
					,td =mes, ''
					,td =anio, ''
					,td =existeRegistrosPunteados, ''
					,td =terminoProcesoDPI, ''
					,td =existeTablaDPI, ''
					,td =polizas, ''
					,td =movdet, ''
					,td =concar, ''
					,td =cfdi, ''
					,td =seatendio, ''
                  FROM @tabladatos
                  FOR XML PATH('tr'), TYPE 
        ) AS NVARCHAR(MAX) ) +      
        N'</table>'+
		N'</div>'+
		N'</body>'+
		N'</html>'

		EXEC msdb.dbo.sp_send_dbmail  
		@profile_name = null,  
		@recipients = @destinatarios,   
		@subject = 'Reporte de incidencias DPIs',  
		@body = @tableHTML,
		@body_format = 'HTML'

END

END
go

