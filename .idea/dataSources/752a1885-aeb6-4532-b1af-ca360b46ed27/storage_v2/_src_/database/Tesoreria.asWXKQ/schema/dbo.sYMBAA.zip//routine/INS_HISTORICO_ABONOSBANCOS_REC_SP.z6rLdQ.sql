-- =============================================
-- Author:	Ing. Luis Antonio García Perrusquía
-- Create date: 01/10/2018
-- Description:	Inserta en todos los registros en ABONOSBANCOS_CB
-- =============================================
create PROCEDURE [dbo].[INS_HISTORICO_ABONOSBANCOS_REC_SP]
	@idEmpresa INT = 0,
	@idBanco INT = 0,
	@cuentaBancaria VARCHAR(60) = '',
	@cuentaContable VARCHAR(60) = '',
	@idHistorico INT = 0,
	@opcion INT = 0,
	@idUsuario INT = 0,
	@nummes int=6
AS
BEGIN
	
--	select * from PeriodoActivo PA where PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria 
--	Tabla ABONOSBANCOS
	--====PUNTEADOS DEL PERIODO ACTIVO 
	INSERT INTO ABONOSBANCOS_CB_H 
		(IDABONOSBANCOS, 
			idBmer, 
			IDBanco, 
			txtOrigen, 
			registro, 
			noMovimiento, 
			referencia, 
			concepto, 
			refAmpliada, 
			esCargo, 
			importe, 
			saldoOperativo, 
			codigoLeyenda, 
			oficinaOperadora, 
			fechaOperacion, 
			horaOperacion, 
			fechaValor, 
			fechaContable, 
			estatus, 
			noCuenta, 
			estatusRevision, 
			Tipo, 
			idUsuario, 
			idEmpresa, 
			anio, 
			fecha, 
			idEstatus, 
			idConciliado, 
			idHistorico) 
	SELECT 
		IDABONOSBANCOS, 
		idBmer, 
		ABO.IDBanco, 
		txtOrigen, 
		registro, 
		noMovimiento, 
		referencia, 
		concepto, 
		refAmpliada, 
		esCargo, 
		importe, 
		saldoOperativo, 
		codigoLeyenda, 
		oficinaOperadora, 
		fechaOperacion, 
		horaOperacion, 
		fechaValor, 
		fechaContable, 
		estatus, 
		noCuenta, 
		estatusRevision, 
		Tipo, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		ABO.idEmpresa, 
		anio, 
		fecha, 
		idEstatus, 
		idConciliado, 
		@idHistorico 
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN ABONOSBANCOS_CB ABO ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono AND PUN.rpun_tipo = 'B'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE ABO.idEmpresa = @idEmpresa 
			AND ABO.IDBanco = @idBanco
			AND ABO.noCuenta = @cuentaBancaria
			AND pa.mec_numMes= @nummes 

	----=====NO PUNTEADOS
	INSERT INTO ABONOSBANCOS_CB_H 
		(IDABONOSBANCOS, 
			idBmer, 
			IDBanco, 
			txtOrigen, 
			registro, 
			noMovimiento, 
			referencia, 
			concepto, 
			refAmpliada, 
			esCargo, 
			importe, 
			saldoOperativo, 
			codigoLeyenda, 
			oficinaOperadora, 
			fechaOperacion, 
			horaOperacion, 
			fechaValor, 
			fechaContable, 
			estatus, 
			noCuenta, 
			estatusRevision, 
			Tipo, 
			idUsuario, 
			idEmpresa, 
			anio, 
			fecha, 
			idEstatus, 
			idConciliado, 
			idHistorico) 
	SELECT 
		IDABONOSBANCOS, 
		idBmer, 
		ABO.IDBanco, 
		txtOrigen, 
		registro, 
		noMovimiento, 
		referencia, 
		concepto, 
		refAmpliada, 
		esCargo, 
		importe, 
		saldoOperativo, 
		codigoLeyenda, 
		oficinaOperadora, 
		fechaOperacion, 
		horaOperacion, 
		fechaValor, 
		fechaContable, 
		estatus, 
		noCuenta, 
		estatusRevision, 
		Tipo, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		ABO.idEmpresa, 
		anio, 
		fecha, 
		idEstatus, 
		idConciliado, 
		@idHistorico 
	FROM ABONOSBANCOS_CB ABO 
	WHERE ABO.idEmpresa = @idEmpresa 
			AND ABO.IDBanco = @idBanco
			AND ABO.noCuenta = @cuentaBancaria
			and month(fechaOperacion) = @nummes
			and IDABONOSBANCOS not in (select IDABONOSBANCOS FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN ABONOSBANCOS_CB ABO ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono AND PUN.rpun_tipo = 'B'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE ABO.idEmpresa = @idEmpresa 
			AND ABO.IDBanco = @idBanco
			AND ABO.noCuenta = @cuentaBancaria
			AND pa.mec_numMes= @nummes )

	----==== DPI DE MESES ANTERIORES NO CANCELADOS "AbonosBancos"
	INSERT INTO ABONOSBANCOS_CB_H 
		(IDABONOSBANCOS, 
			idBmer, 
			IDBanco, 
			txtOrigen, 
			registro, 
			noMovimiento, 
			referencia, 
			concepto, 
			refAmpliada, 
			esCargo, 
			importe, 
			saldoOperativo, 
			codigoLeyenda, 
			oficinaOperadora, 
			fechaOperacion, 
			horaOperacion, 
			fechaValor, 
			fechaContable, 
			estatus, 
			noCuenta, 
			estatusRevision, 
			Tipo, 
			idUsuario, 
			idEmpresa, 
			anio, 
			fecha, 
			idEstatus, 
			idConciliado, 
			idHistorico) 
	SELECT 
		IDABONOSBANCOS, 
		idBmer, 
		ABO.IDBanco, 
		txtOrigen, 
		registro, 
		noMovimiento, 
		referencia, 
		concepto, 
		refAmpliada, 
		esCargo, 
		importe, 
		saldoOperativo, 
		codigoLeyenda, 
		oficinaOperadora, 
		fechaOperacion, 
		horaOperacion, 
		fechaValor, 
		fechaContable, 
		estatus, 
		noCuenta, 
		estatusRevision, 
		Tipo, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		ABO.idEmpresa, 
		anio, 
		ABO.fecha, 
		ABO.idEstatus, 
		idConciliado, 
		@idHistorico 
	FROM DepositoBancarioDPI DPI
	LEFT JOIN CancelaDPI CAN ON CAN.idDPI = DPI.idDPI 
	INNER JOIN ABONOSBANCOS_CB ABO ON ABO.idBmer = DPI.idAbonoBanco
	INNER JOIN REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS AND PUN.rpun_tipo = 'B'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria  and pun.idMes=pa.mec_idMes
	WHERE idCancelaDPI IS NULL
			AND ABO.idEmpresa = @idEmpresa
			AND ABO.IDBanco = @idBanco
			AND ABO.noCuenta = @cuentaBancaria
			AND pa.mec_numMes= @nummes 

	--=====TABLA REGISTROS PUNTEADOS
	--====PUNTEADOS DEL PERIODO ACTIVO 
	INSERT INTO REGISTROS_PUNTEADOS_H 
		(rpun_idPunteado, 
			rpun_grupoPunteo, 
			rpun_idCargo, 
			rpun_idAbono, 
			rpun_tipo, 
			rpun_fechaPunteo, 
			rpun_usuario, 
			rpun_idAplicado, 
			idHistorico) 
	SELECT 
		rpun_idPunteado, 
		rpun_grupoPunteo, 
		rpun_idCargo, 
		rpun_idAbono, 
		rpun_tipo, 
		rpun_fechaPunteo, 
		rpun_usuario, 
		rpun_idAplicado, 
		@idHistorico 
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN ABONOSBANCOS_CB ABO ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono AND PUN.rpun_tipo = 'B'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE ABO.idEmpresa = @idEmpresa 
			AND ABO.IDBanco = @idBanco
			AND ABO.noCuenta = @cuentaBancaria
			AND pa.mec_numMes= @nummes 

	----==== DPI DE MESES ANTERIORES NO CANCELADOS "RegistrosPunteados"
	INSERT INTO REGISTROS_PUNTEADOS_H 
		(rpun_idPunteado, 
			rpun_grupoPunteo, 
			rpun_idCargo, 
			rpun_idAbono, 
			rpun_tipo, 
			rpun_fechaPunteo, 
			rpun_usuario, 
			rpun_idAplicado, 
			idHistorico) 
	SELECT 
		rpun_idPunteado, 
		rpun_grupoPunteo, 
		rpun_idCargo, 
		rpun_idAbono, 
		rpun_tipo, 
		rpun_fechaPunteo, 
		rpun_usuario, 
		rpun_idAplicado, 
		@idHistorico 
	FROM DepositoBancarioDPI DPI
	LEFT JOIN CancelaDPI CAN ON CAN.idDPI = DPI.idDPI 
	INNER JOIN ABONOSBANCOS_CB ABO ON ABO.idBmer = DPI.idAbonoBanco
	INNER JOIN REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS AND PUN.rpun_tipo = 'B'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE idCancelaDPI IS NULL
			AND ABO.idEmpresa = @idEmpresa
			AND ABO.IDBanco = @idBanco
			AND ABO.noCuenta = @cuentaBancaria
			AND pa.mec_numMes= @nummes 

	--====Tabla DPI
	INSERT INTO DepositoBancarioDPI_H 
		(idDPI, 
			idAbonoBanco, 
			idBanco, 
			idEmpresa, 
			idEstatus, 
			fechaRegistro, 
			idUsuario, 
			idHistorico) 
	SELECT 
		DPI.idDPI, 
		DPI.idAbonoBanco, 
		DPI.idBanco, 
		DPI.idEmpresa, 
		DPI.idEstatus, 
		DPI.fechaRegistro, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		@idHistorico 
	FROM DepositoBancarioDPI DPI
	LEFT JOIN CancelaDPI CAN ON CAN.idDPI = DPI.idDPI 
	INNER JOIN ABONOSBANCOS_CB ABO ON ABO.idBmer = DPI.idAbonoBanco
	INNER JOIN REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS AND PUN.rpun_tipo = 'B'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE idCancelaDPI IS NULL
			AND ABO.idEmpresa = @idEmpresa
			AND ABO.IDBanco = @idBanco
			AND ABO.noCuenta = @cuentaBancaria
			AND pa.mec_numMes= @nummes 
END
go

