CREATE PROCEDURE [dbo].[SEL_SUCURSAL_BY_USUARIO_SP]
@idUsuario INT,
@idEmpresa INT
AS
BEGIN

	-- DECLARE @Usuario NUMERIC(18) = ( SELECT Usuario FROM [Tesoreria].[dbo].[Usuarios] WHERE IdUsuario = @idUsuario );
	-- PRINT( @Usuario );
	SELECT DISTINCT (Sucur.suc_nombre), Sucur.suc_idsucursal,suc_nombrebd,suc_ipbd 
	FROM  [ControlAplicaciones].[dbo].[ope_organigrama] Orga
	INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] Sucur ON Orga.suc_idsucursal = Sucur.suc_idsucursal
	WHERE Orga.emp_idempresa = @idEmpresa    
		--AND Orga.usu_idusuario = @idUsuario
		
  /*
  select distinct (Sucur.suc_nombre), Sucur.suc_idsucursal,suc_nombrebd,suc_ipbd 
  from 
  --[ControlAplicaciones].[dbo].[eqv_organigrama] Orga
  [ControlAplicaciones].[dbo].[ope_organigrama] Orga
  INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] Sucur 
  ON Orga.suc_idsucursal = Sucur.suc_idsucursal
  where Orga.emp_idempresa = @idEmpresa    
  and Orga.usu_idusuario = @idUsuario 
  --SELECT distinct(suc_idsucursal) FROM [ControlAplicaciones].[dbo].[ope_organigrama] where usu_idusuario = 71
  */

   

 END

go

