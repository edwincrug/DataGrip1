-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GeneraNotificacionTransferencia]
	 @cuentaOrigen varchar(150)
	,@cuentaDestino varchar(150)
	,@concepto varchar(255)
	,@monto decimal(18,2)
	,@usuario int
	,@solicitaAuto int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   	
	begin try
		insert into TransferenciasBancarias (cuentaOrigen, cuentaDestino, concepto, importe, usuario, fechaTransferencia)
		values( @cuentaOrigen, @cuentaDestino, @Concepto, @monto, @usuario, GETDATE())

		select @@IDENTITY AS Folio --max(id) as Folio
		,'Ok' as estatus
		,'Se genero la transferencia temporal' as mensaje
		from TransferenciasBancarias


    end try
	begin catch
		select 'error' as Estatus, 'Ocurrio un error durante la transferencia' as mensaje
	end catch

END
go

