
CREATE procedure  [dbo].[INS_CXPCOMISIONESINTERESESDET_SP]
	@cuentacontable as varchar(50),
	@concepto as varchar(50),
	@cargo as varchar(50),
	@abono as varchar(50),
	@documento as varchar(50),
	@idpersona as varchar(50),
	@idcomisionesintereses as varchar(50),
	@tipodocumento as varchar(50),
	@fechavencimiento as varchar(50),
	@poriva as varchar(50),
	@referencia as varchar(50),
	@banco as varchar(50),
	@referenciabancaria as varchar(50),
	@conpoliza as varchar(50),
	@consecutivo as varchar(50),
	@idSucursalAplica as varchar(50)
AS
BEGIN
	
	INSERT INTO cxp_comisionesinteresesdet 
	(
		cid_cuentacontable,
		cid_concepto,
		cid_cargo,
		cid_abono,
		cid_documento,
		cid_idpersona,
		coi_idcomisionesintereses,
		cid_tipodocumento,
		cid_fechavencimiento,
		cid_poriva,
		cid_referencia,
		cid_banco,
		cid_referenciabancaria,
		cid_conpoliza,
		cid_consecutivo,
		idSucursalAplica
	)
	VALUES
	(
		@cuentacontable,
		@concepto,
		@cargo,
		@abono,
		@documento,
		CASE @tipodocumento
		  WHEN 'FAC' THEN @idpersona 
		  WHEN 'FACIVA' THEN @idpersona 
		  WHEN '' THEN 0 
		  ELSE 0 
	    END,
		-- @idpersona,
		@idcomisionesintereses,
		@tipodocumento,
		@fechavencimiento,
		@poriva,
		@referencia,
		@banco,
		@referenciabancaria,
		@conpoliza,
		@consecutivo,
		@idSucursalAplica
	)
	SELECT @@IDENTITY AS result
END
go

