/****** Script for SelectTopNRows command from SSMS  ******/
--select top 100 * from [controlDepositosview] order by fechaoperacion desc
CREATE PROCEDURE [dbo].[SEL_DEPOSITOS_NO_REFERENCIADOS_SP] 
--SEL_DEPOSITOS_NO_REFERENCIADOS_SP 1,'000000000190701289','01/04/2020','18/04/2020',0
@idBanco INT=0,
@noCuenta varchar(50)='',
@fechaIni varchar(20) = '',
@fechaFin varchar(20) = '',
@conciliado int =0
AS
BEGIN
DECLARE @idEmpresa varchar(50)
DECLARE @cuentaContable varchar(50)
DECLARE @polizaPago varchar(20)
DECLARE @opcion int
DECLARE @idUsuario int
DECLARE @idHistorico numeric(18,0)
declare @fechainicial date,@fechacorte date, @mes int,@anio int
if @idbanco=2
	begin
		select @mes=mec_numMes,@anio=mec_anio from tesoreria.dbo.PeriodoActivo where idEmpresa=1 and idbanco=1 and cuentaBancaria=@noCuenta and mec_conciliado=0
		Set @fechainicial = convert(nvarchar(4),@anio)+'-'+right('0'+convert(varchar(2), convert(nvarchar(2),@mes)), 2)+'-01'
		Select @fechacorte=dateadd(day, -1, convert(date,case when @mes = 12 then convert(nvarchar(4),@anio+1) else convert(nvarchar(4),@anio) end+'-'+case when @mes = 12 then '01' else convert(nvarchar(2),@mes+1) end +'-01'))
		select @idEmpresa=idEmpresa from PeriodoActivo where cuentaBancaria=@noCuenta and mec_conciliado=0
		select top 1 d.emp_idempresa,b.idBanco,b.numeroCuenta,b.cuentaContable,d.tipo_poliza_pago,2 opcion,71 idusuario into #temp  from Centralizacionv2.dbo.dig_cat_bases_bpro d
		inner join referencias.dbo.BancoCuenta b on d.emp_idempresa=b.idEmpresa
		where d.tipo=2  and emp_idempresa =@idEmpresa
		  select 
		
		 
		  @cuentaContable=CuentaContable,
		  @polizaPago= tipo_poliza_pago,
		  @opcion= opcion,
		  @idUsuario=idusuario
		   from  #temp 

	--   select  @idEmpresa idEmpresa, @idBanco idBanco  ,@noCuenta noCuenta  ,@cuentaContable cuentaContable  ,@fechainicial fechainicial  ,@fechacorte fechacorte  ,@polizaPago polizaPago  ,@opcion  opcion ,@idUsuario idUsuario ,0 idhistorico

	  EXECUTE [dbo].[SEL_TOTAL_ABONOCARGO2_SP] 
	   @idEmpresa
	  ,@idBanco
	  ,@noCuenta
	  ,@cuentaContable
	  ,@fechainicial
	  ,@fechacorte
	  ,@polizaPago
	  ,@opcion
	  ,@idUsuario
	  ,0
  end
	DECLARE @NombreBanco VARCHAR(15) = (SELECT nombre FROM [referencias].[dbo].[Banco] WHERE idBanco = @idBanco);
	if(@conciliado =1)
	begin
	IF( @fechaIni = '' AND @fechaFin = '' )
		BEGIN
			SELECT 
			   cd.idbmer idDepositoBanco
			  ,CD.idBanco
			  ,cd.[idBmer]
			  ,@NombreBanco banco
			  ,[txtOrigen]
			  ,cd.[noCuenta]
			  ,cd.[concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,[saldoOperativo]
			  ,CD.[referencia]
			  ,convert (varchar(20), [fechaOperacion],111) [fechaOperacion]
			  ,[horaOperacion]
			  ,[oficinaOperadora]
			  ,refAmpliada
			  ,case when rpun_grupoPunteo IS Not null then rpun_grupoPunteo else 0 end grupopunteo
			 FROM [controlDepositosview] CD 
			 LEFT JOIN [Referencia] REF ON CD.idBmer = REF.depositoID and cd.IDBanco=REF.IDBanco
			 LEFT JOIN referencias.dbo.rapdeposito r ON cd.idbmer=r.iddeposito and CD.IDBanco=r.idBanco
			 LEFT JOIN VW_REGISTROS_PUNTEADOS vw on cd.idBmer = vw.idbmer and vw.IDBanco=@idBanco
			 WHERE CD.idBanco = @idBanco
				 AND cd.noCuenta = @noCuenta 
				 AND esCargo = 0 
				 AND cd.concepto NOT LIKE 'CE%' 
				 AND cd.concepto NOT LIKE 'CC%'
				 AND cd.concepto NOT like 'interes%'	 
				 AND cd.concepto NOT like 'COMISI%'
				 AND cd.concepto NOT like 'IVA COM%'
				 AND cd.concepto NOT like 'IVA INTERES%'
				  and cd.[estatusRevision]=1
				 AND REF.idReferencia IS NULL
				 and r.idRAPDeposito is null
				
			ORDER BY convert (varchar(20), [fechaOperacion],111) asc
		END
	ELSE
	print 'no es aqui 1'
		BEGIN
			--SET @fechaIni   = substring(@fechaIni,7,4) +   substring(@fechaIni,4,2) + substring(@fechaIni,1,2) 
			--SET @fechaFin   = substring(@fechaFin,7,4) +  substring(@fechaFin,4,2) + substring(@fechaFin,1,2)
			
			SELECT 
			   cd.idbmer idDepositoBanco
			  ,CD.idBanco
			  ,cd.[idBmer]
			  ,@NombreBanco banco
			  ,[txtOrigen]
			  ,cd.[noCuenta]
			  ,cd.[concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,[saldoOperativo]
			  ,CD.[referencia]
			  ,convert (varchar(20), [fechaOperacion],111) [fechaOperacion]
			  ,[horaOperacion]
			  ,[oficinaOperadora]
			  ,refAmpliada
			  ,case when rpun_grupoPunteo IS Not null then rpun_grupoPunteo else 0 end grupopunteo
			 FROM [controlDepositosview] CD
			 LEFT JOIN [Referencia] REF ON CD.idBmer = REF.depositoID and cd.IDBanco=REF.IDBanco
			 LEFT JOIN referencias.dbo.rapdeposito r ON cd.idbmer=r.iddeposito and CD.IDBanco=r.idBanco
			 LEFT JOIN VW_REGISTROS_PUNTEADOS vw on cd.idBmer = vw.idbmer and vw.IDBanco=@idBanco
			 WHERE CD.idBanco = @idBanco  	 
				 AND fechaOperacion between  convert(date,@fechaIni,103) and convert(date,@fechaFin,103)
				 AND cd.noCuenta = @noCuenta 
				 AND esCargo = 0 
				 AND cd.concepto NOT LIKE 'CE%' 
				 AND cd.concepto NOT LIKE 'CC%'
				 AND cd.concepto NOT like 'interes%'	 
				 AND cd.concepto NOT like 'COMISI%'
				 AND cd.concepto NOT like 'IVA COM%'
				 AND cd.concepto NOT like 'IVA INTERES%'
				 and cd.[estatusRevision]=1
				 AND REF.idReferencia IS NULL
				 AND r.idRAPDeposito IS NULL
			
			ORDER BY convert (varchar(20), [fechaOperacion],111) asc
		END
	 end
	 else
	 begin
	IF( @fechaIni = '' AND @fechaFin = '' )
		BEGIN
			SELECT 
			   cd.idbmer idDepositoBanco
			  ,CD.idBanco
			  ,cd.[idBmer]
			  ,@NombreBanco banco
			  ,[txtOrigen]
			  ,cd.[noCuenta]
			  ,cd.[concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,[saldoOperativo]
			  ,CD.[referencia]
			  ,convert (varchar(20), [fechaOperacion],111) [fechaOperacion]
			  ,[horaOperacion]
			  ,[oficinaOperadora]
			  ,refAmpliada
			  ,case when rpun_grupoPunteo IS Not null then rpun_grupoPunteo else 0 end grupopunteo
			 FROM [controlDepositosview] CD 
			 LEFT JOIN [Referencia] REF ON CD.idBmer = REF.depositoID and cd.IDBanco=REF.IDBanco
			 LEFT JOIN referencias.dbo.rapdeposito r ON cd.idbmer=r.iddeposito and CD.IDBanco=r.idBanco
			 LEFT JOIN VW_REGISTROS_PUNTEADOS vw on cd.idBmer = vw.idbmer and vw.IDBanco=@idBanco
			 WHERE CD.idBanco = @idBanco
				 AND cd.noCuenta = @noCuenta 
				 AND esCargo = 0 
				 AND cd.concepto NOT LIKE 'CE%' 
				 AND cd.concepto NOT LIKE 'CC%'
				 AND cd.concepto NOT like 'interes%'	 
				 AND cd.concepto NOT like 'COMISI%'
				 AND cd.concepto NOT like 'IVA COM%'
				 AND cd.concepto NOT like 'IVA INTERES%'
				  and cd.[estatusRevision]=1
				 AND REF.idReferencia IS NULL
				 and r.idRAPDeposito is null
				 and vw.rpun_idPunteado is null
			ORDER BY convert (varchar(20), [fechaOperacion],111) asc
		END
	ELSE
	print 'no es aqui'
		BEGIN
			--SET @fechaIni   = substring(@fechaIni,7,4) +   substring(@fechaIni,4,2) + substring(@fechaIni,1,2) 
			--SET @fechaFin   = substring(@fechaFin,7,4) +  substring(@fechaFin,4,2) + substring(@fechaFin,1,2)
			
			SELECT 
			   cd.idbmer idDepositoBanco
			  ,CD.idBanco
			  ,cd.[idBmer]
			  ,@NombreBanco banco
			  ,[txtOrigen]
			  ,cd.[noCuenta]
			  ,cd.[concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,[saldoOperativo]
			  ,CD.[referencia]
			  ,convert (varchar(20), [fechaOperacion],111) [fechaOperacion]
			  ,[horaOperacion]
			  ,[oficinaOperadora]
			  ,refAmpliada
			  ,case when rpun_grupoPunteo IS Not null then rpun_grupoPunteo else 0 end grupopunteo
			 FROM [controlDepositosview] CD
			 LEFT JOIN [Referencia] REF ON CD.idBmer = REF.depositoID and cd.IDBanco=REF.IDBanco
			 LEFT JOIN referencias.dbo.rapdeposito r ON cd.idbmer=r.iddeposito and CD.IDBanco=r.idBanco
			 LEFT JOIN VW_REGISTROS_PUNTEADOS vw on cd.idBmer = vw.idbmer and vw.IDBanco=@idBanco
			 WHERE CD.idBanco = @idBanco  	 
				 AND fechaOperacion between  convert(date,@fechaIni,103) and convert(date,@fechaFin,103)
				 AND cd.noCuenta = @noCuenta 
				 AND esCargo = 0 
				 AND cd.concepto NOT LIKE 'CE%' 
				 AND cd.concepto NOT LIKE 'CC%'
				 AND cd.concepto NOT like 'interes%'	 
				 AND cd.concepto NOT like 'COMISI%'
				 AND cd.concepto NOT like 'IVA COM%'
				 AND cd.concepto NOT like 'IVA INTERES%'
				 and cd.[estatusRevision]=1
				 AND REF.idReferencia IS NULL
				 AND r.idRAPDeposito IS NULL
				 and vw.rpun_idPunteado is null
				 union all
				 select  idDpiAnterior idDepositoBanco
			  ,b.idBanco idBanco
			  ,idDpiAnterior [idBmer]
			  ,b.cuenta banco
			  ,'' [txtOrigen]
			  ,d.cuenta [noCuenta]
			  ,d.referencia [concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,0 [saldoOperativo]
			  ,d.documento [referencia]
			  ,convert (varchar(20), d.fecha,111) [fechaOperacion]
			  ,null [horaOperacion]
			  ,0 [oficinaOperadora]
			  ,d.referencia refAmpliada
			  ,-1 grupopunteo
			  from dpiAnterior d
			  inner join referencias.dbo.BancoCuenta b on d.cuenta=b.numeroCuenta
			  LEFT JOIN [Referencia] REF ON d.idDpiAnterior = REF.depositoID and b.IDBanco=REF.IDBanco
			  where isnull(cancelado,0)=0 and b.numeroCuenta=@noCuenta
			  union all
	SELECT
	 abo.idbmer idDepositoBanco
			  ,abo.idBanco idBanco
			  ,abo.idbmer [idBmer]
			  ,@NombreBanco banco
			  ,abo.txtOrigen [txtOrigen]
			  ,abo.noCuenta [noCuenta]
			  ,abo.concepto [concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,0 [saldoOperativo]
			  ,abo.referencia [referencia]
			  ,convert (varchar(20), abo.fechaOperacion,111) [fechaOperacion]
			  ,abo.horaOperacion [horaOperacion]
			  ,0 [oficinaOperadora]
			  ,abo.refAmpliada refAmpliada
			  ,-1 grupopunteo
			--  select *
	FROM DepositoBancarioDPI DPI 
	INNER JOIN ABONOSBANCOS_CB ABO ON DPI.idAbonoBanco = ABO.idBmer AND DPI.idEmpresa = ABO.idEmpresa AND DPI.idBanco = ABO.IDBanco
	INNER JOIN VW_REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS AND PUN.rpun_tipo = 'B'
	 LEFT JOIN [Referencia] REF ON ABO.idBmer = REF.depositoID and ABO.IDBanco=REF.IDBanco
	LEFT JOIN CancelaDPI CAN ON CAN.idDPI = DPI.idDPI
	LEFT JOIN ABONOS_COMPLETO_CB AC ON AC.IDABONOS_COMPLETO = CAN.idAbonos_Completo
	WHERE  DPI.idBanco =@idBanco
	AND ABO.noCuenta = @noCuenta
	and can.idCancelaDPI is null and ref.idReferencia is null
			ORDER BY convert (varchar(20), [fechaOperacion],111) asc
		END
	 end
END
go

