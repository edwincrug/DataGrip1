-- =============================================
-- Author:	Ing. Luis Antonio García Perrusquía
-- Create date: 01/10/2018
-- Description:	Inserta en todos los registros en CARGOS_COMPLETOS_CB
-- =============================================
create PROCEDURE [dbo].[INS_HISTORICO_CARGOSCOMPLETOS_REC_SP] 
	@idEmpresa INT = 0,
	@idBanco INT = 0,
	@cuentaBancaria VARCHAR(60) = '',
	@cuentaContable VARCHAR(60) = '',
	@idHistorico INT = 0,
	@opcion INT = 0,
	@idUsuario INT = 0,
	@nummes int=6
AS
BEGIN

	----==== Obtiene los Grupos de los DPI´s punteados
	SELECT 
		PUN.rpun_grupoPunteo
	INTO #grupos
	FROM DepositoBancarioDPI DPI
	LEFT JOIN CancelaDPI CAN ON CAN.idDPI = DPI.idDPI
	INNER JOIN ABONOSBANCOS_CB ABO ON ABO.idBmer = DPI.idAbonoBanco
	INNER JOIN REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE idCancelaDPI IS NULL
			AND ABO.idEmpresa = @idEmpresa
			AND ABO.IDBanco = @idBanco
			AND ABO.noCuenta = @cuentaBancaria
			AND pa.mec_numMes= @nummes 

	--====PUNTEADOS DEL PERIODO ACTIVO 
	INSERT INTO CARGOS_COMPLETO_CB_H
		(IDCARGOS_COMPLETO, 
			MOV_TIPOPOL, 
			MOV_CONSPOL, 
			MOV_CONSMOV, 
			MOV_MES, 
			MOV_NUMCTA, 
			MOV_CONCEPTO, 
			MOV_DEBE, 
			MOV_HABER, 
			MOV_ORIGEN, 
			MOV_IDCLIENTE, 
			MOV_DEPTO, 
			MOV_CARTERA, 
			MOV_TIPODOCTO, 
			MOV_IDDOCTO, 
			MOV_FECHVEN, 
			MOV_FECHPAG, 
			MOV_AGENTE, 
			MOV_CVEUSU, 
			MOV_FECHOPE, 
			MOV_CONCILIADO, 
			MOV_FOLIO, 
			MOV_FOLIODET, 
			MOV_MONEDA, 
			MOV_TIPOCAMBIO, 
			MOV_HORAOPE, 
			MOV_OBSERVA, 
			TIPO, 
			idUsuario, 
			idEmpresa, 
			idBanco, 
			anio, 
			fecha, 
			idEstatus, 
			idConciliado, 
			idHistorico) 
	SELECT 
		IDCARGOS_COMPLETO, 
		MOV_TIPOPOL, 
		MOV_CONSPOL, 
		MOV_CONSMOV, 
		MOV_MES, 
		MOV_NUMCTA, 
		MOV_CONCEPTO, 
		MOV_DEBE, 
		MOV_HABER, 
		MOV_ORIGEN, 
		MOV_IDCLIENTE, 
		MOV_DEPTO, 
		MOV_CARTERA, 
		MOV_TIPODOCTO, 
		MOV_IDDOCTO, 
		MOV_FECHVEN, 
		MOV_FECHPAG, 
		MOV_AGENTE, 
		MOV_CVEUSU, 
		MOV_FECHOPE, 
		MOV_CONCILIADO, 
		MOV_FOLIO, 
		MOV_FOLIODET, 
		MOV_MONEDA, 
		MOV_TIPOCAMBIO, 
		MOV_HORAOPE, 
		MOV_OBSERVA, 
		TIPO, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		CAR.idEmpresa, 
		CAR.idBanco, 
		anio, 
		fecha, 
		idEstatus, 
		idConciliado, 
		@idHistorico 
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN CARGOS_COMPLETO_CB CAR ON CAR.IDCARGOS_COMPLETO = PUN.rpun_idCargo AND PUN.rpun_tipo = 'C'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE CAR.idEmpresa = @idEmpresa
			AND CAR.idBanco = @idBanco
			AND CAR.MOV_NUMCTA = @cuentaContable
			AND pa.mec_numMes= @nummes 

	--====NO PUNTEADOS
	INSERT INTO CARGOS_COMPLETO_CB_H
		(IDCARGOS_COMPLETO, 
			MOV_TIPOPOL, 
			MOV_CONSPOL, 
			MOV_CONSMOV, 
			MOV_MES, 
			MOV_NUMCTA, 
			MOV_CONCEPTO, 
			MOV_DEBE, 
			MOV_HABER, 
			MOV_ORIGEN, 
			MOV_IDCLIENTE, 
			MOV_DEPTO, 
			MOV_CARTERA, 
			MOV_TIPODOCTO, 
			MOV_IDDOCTO, 
			MOV_FECHVEN, 
			MOV_FECHPAG, 
			MOV_AGENTE, 
			MOV_CVEUSU, 
			MOV_FECHOPE, 
			MOV_CONCILIADO, 
			MOV_FOLIO, 
			MOV_FOLIODET, 
			MOV_MONEDA, 
			MOV_TIPOCAMBIO, 
			MOV_HORAOPE, 
			MOV_OBSERVA, 
			TIPO, 
			idUsuario, 
			idEmpresa, 
			idBanco, 
			anio, 
			fecha, 
			idEstatus, 
			idConciliado, 
			idHistorico) 
	SELECT 
		IDCARGOS_COMPLETO, 
		MOV_TIPOPOL, 
		MOV_CONSPOL, 
		MOV_CONSMOV, 
		MOV_MES, 
		MOV_NUMCTA, 
		MOV_CONCEPTO, 
		MOV_DEBE, 
		MOV_HABER, 
		MOV_ORIGEN, 
		MOV_IDCLIENTE, 
		MOV_DEPTO, 
		MOV_CARTERA, 
		MOV_TIPODOCTO, 
		MOV_IDDOCTO, 
		MOV_FECHVEN, 
		MOV_FECHPAG, 
		MOV_AGENTE, 
		MOV_CVEUSU, 
		MOV_FECHOPE, 
		MOV_CONCILIADO, 
		MOV_FOLIO, 
		MOV_FOLIODET, 
		MOV_MONEDA, 
		MOV_TIPOCAMBIO, 
		MOV_HORAOPE, 
		MOV_OBSERVA, 
		TIPO, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		CAR.idEmpresa, 
		CAR.idBanco, 
		anio, 
		fecha, 
		idEstatus, 
		idConciliado, 
		@idHistorico 
	FROM REGISTROS_PUNTEADOS PUN
	RIGHT JOIN CARGOS_COMPLETO_CB CAR ON CAR.IDCARGOS_COMPLETO = PUN.rpun_idCargo AND PUN.rpun_tipo = 'C'
	WHERE CAR.idEmpresa = @idEmpresa
			AND CAR.idBanco = @idBanco
			AND CAR.MOV_NUMCTA = @cuentaContable
			and month(MOV_FECHOPE) = @nummes
			AND car.IDCARGOS_COMPLETO not in (select IDCARGOS_COMPLETO 	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN CARGOS_COMPLETO_CB CAR ON CAR.IDCARGOS_COMPLETO = PUN.rpun_idCargo AND PUN.rpun_tipo = 'C'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE CAR.idEmpresa = @idEmpresa
			AND CAR.idBanco = @idBanco
			AND CAR.MOV_NUMCTA = @cuentaContable
			AND pa.mec_numMes= @nummes )

	--==== DPI No cancelados CargosContables
	INSERT INTO CARGOS_COMPLETO_CB_H
		(IDCARGOS_COMPLETO, 
			MOV_TIPOPOL, 
			MOV_CONSPOL, 
			MOV_CONSMOV, 
			MOV_MES, 
			MOV_NUMCTA, 
			MOV_CONCEPTO, 
			MOV_DEBE, 
			MOV_HABER, 
			MOV_ORIGEN, 
			MOV_IDCLIENTE, 
			MOV_DEPTO, 
			MOV_CARTERA, 
			MOV_TIPODOCTO, 
			MOV_IDDOCTO, 
			MOV_FECHVEN, 
			MOV_FECHPAG, 
			MOV_AGENTE, 
			MOV_CVEUSU, 
			MOV_FECHOPE, 
			MOV_CONCILIADO, 
			MOV_FOLIO, 
			MOV_FOLIODET, 
			MOV_MONEDA, 
			MOV_TIPOCAMBIO, 
			MOV_HORAOPE, 
			MOV_OBSERVA, 
			TIPO, 
			idUsuario, 
			idEmpresa, 
			idBanco, 
			anio, 
			fecha, 
			idEstatus, 
			idConciliado, 
			idHistorico) 
	SELECT 
		IDCARGOS_COMPLETO, 
		MOV_TIPOPOL, 
		MOV_CONSPOL, 
		MOV_CONSMOV, 
		MOV_MES, 
		MOV_NUMCTA, 
		MOV_CONCEPTO, 
		MOV_DEBE, 
		MOV_HABER, 
		MOV_ORIGEN, 
		MOV_IDCLIENTE, 
		MOV_DEPTO, 
		MOV_CARTERA, 
		MOV_TIPODOCTO, 
		MOV_IDDOCTO, 
		MOV_FECHVEN, 
		MOV_FECHPAG, 
		MOV_AGENTE, 
		MOV_CVEUSU, 
		MOV_FECHOPE, 
		MOV_CONCILIADO, 
		MOV_FOLIO, 
		MOV_FOLIODET, 
		MOV_MONEDA, 
		MOV_TIPOCAMBIO, 
		MOV_HORAOPE, 
		MOV_OBSERVA, 
		TIPO, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		CAR.idEmpresa, 
		CAR.idBanco, 
		anio, 
		fecha, 
		idEstatus, 
		idConciliado, 
		@idHistorico  
	FROM REGISTROS_PUNTEADOS PUN 
	INNER JOIN #grupos GPO ON GPO.rpun_grupoPunteo  = PUN.rpun_grupoPunteo AND PUN.rpun_tipo = 'C'
	INNER JOIN CARGOS_COMPLETO_CB CAR ON CAR.IDCARGOS_COMPLETO = PUN.rpun_idCargo

	--====REGISTROS PUNTEADOS
	--====PUNTEADOS DEL PERIODO ACTIVO 
	INSERT INTO REGISTROS_PUNTEADOS_H 
		(rpun_idPunteado, 
			rpun_grupoPunteo, 
			rpun_idCargo, 
			rpun_idAbono, 
			rpun_tipo, 
			rpun_fechaPunteo, 
			rpun_usuario, 
			rpun_idAplicado, 
			idHistorico) 
	SELECT 
		rpun_idPunteado, 
		rpun_grupoPunteo, 
		rpun_idCargo, 
		rpun_idAbono, 
		rpun_tipo, 
		rpun_fechaPunteo, 
		rpun_usuario, 
		rpun_idAplicado, 
		@idHistorico 
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN CARGOS_COMPLETO_CB CAR ON CAR.IDCARGOS_COMPLETO = PUN.rpun_idCargo AND PUN.rpun_tipo = 'C'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria and pun.idMes=pa.mec_idMes
	WHERE CAR.idEmpresa = @idEmpresa
			AND CAR.idBanco = @idBanco
			AND CAR.MOV_NUMCTA = @cuentaContable
			AND pa.mec_numMes= @nummes

	--==== DPI No cancelados RegistrosPunteaos
	INSERT INTO REGISTROS_PUNTEADOS_H 
		(rpun_idPunteado, 
			rpun_grupoPunteo, 
			rpun_idCargo, 
			rpun_idAbono, 
			rpun_tipo, 
			rpun_fechaPunteo, 
			rpun_usuario, 
			rpun_idAplicado, 
			idHistorico) 
	SELECT 
		rpun_idPunteado, 
		PUN.rpun_grupoPunteo, 
		rpun_idCargo, 
		rpun_idAbono, 
		rpun_tipo, 
		rpun_fechaPunteo, 
		rpun_usuario, 
		rpun_idAplicado, 
		@idHistorico
	FROM REGISTROS_PUNTEADOS PUN 
	INNER JOIN #grupos GPO ON GPO.rpun_grupoPunteo  = PUN.rpun_grupoPunteo AND PUN.rpun_tipo = 'C'
	INNER JOIN CARGOS_COMPLETO_CB CAR ON CAR.IDCARGOS_COMPLETO = PUN.rpun_idCargo

	--==Se elimina la tabla temporal que se creo
	DROP TABLE #grupos
END
go

