-- [SEL_LOCAL_ABONOCARGO_SP] 1,3,'65504258249','1100-0020-0001-0018,'2018-08-01','2018-06-30',0,0,71,0
-- [SEL_LOCAL_ABONOCARGO_SP] 3,1,'000000000110861464','1100-0020-0001-0001','2019-02-01','2019-02-28'
create PROCEDURE [dbo].[SEL_LOCAL_ABONOCARGO2_SP]
	@idEmpresa VARCHAR(50)			= 0,
	@idBanco INT						= 0,
	@noCuenta VARCHAR(50)				= '',
	@cuentaContable VARCHAR(50)		= '',
	@fechaElaboracion VARCHAR(50)	= '',
	@fechaCorte VARCHAR(50)			= '',
	@polizaPago VARCHAR(20)			= '',
	@opcion INT						= 0,
	@idUsuario INT						= 0,
	@idHistorico NUMERIC(18,0)		= 0
AS
BEGIN
	-- Variables bases dinamicas
	DECLARE @ipLocal NVARCHAR(50)		= '',
			 @ip_catbases NVARCHAR(50)	= '',
			 @Base NVARCHAR(50)			= '';

	-- Obtención de Bases de Datos Dinamicos
	SELECT	@ipLocal = dec.local_net_address
	FROM	sys.dm_exec_connections AS dec
	WHERE	dec.session_id = @@SPID;

	SELECT	@ip_catbases = (CASE 
						WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
							THEN ''
						ELSE ip_servidor 
					END),
			@idEmpresa	= emp_idempresa,
			@Base		= (CASE 
								WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
									THEN '[' + nombre_base + '].[DBO].' 
								ELSE '['+ ip_servidor + '].[' + nombre_base + '].[DBO].' 
							END)
	FROM	[CentralizacionV2].[dbo].[DIG_CAT_BASES_BPRO]
	WHERE	emp_idempresa	= @idEmpresa 
			AND tipo		= 2

	DECLARE @añoConsulta INT = YEAR( CONVERT( DATE, @fechaElaboracion) );
	DECLARE @mes INT = MONTH( CONVERT( DATE, @fechaElaboracion) );
	print(@mes)

	DECLARE @primerDiaMesConsulta DATE	= DATEADD(MM, DATEDIFF(MM,0,CONVERT(DATE,REPLACE(@fechaCorte,'-',''))), 0);


	DECLARE @saldoBanco NUMERIC(18,6)		   = 0,
			@totalAbonoContable NUMERIC(18,6)  = 0,
			@totalCargoContable NUMERIC(18,6)  = 0,
			@totalAbonoBancario NUMERIC(18,6)  = 0,
			@totalCargoBancario NUMERIC(18,6)  = 0,
			@SaldoInicial NUMERIC(18,6)		   = 0,
			@saldoConciliacion NUMERIC(18,6)	   = 0,
			@saldoContabilidad NUMERIC(18,6)	   = 0,
			@diferencia NUMERIC(18,6)			   = 0,
			@mesActivo INT						   = 0;
	-- Consulta de Saldo Inicial
	-- Obtención de Bases de Datos Dinamicos

	--
	SELECT 
		@SaldoInicial = SaldoInicial
	FROM referencias.dbo.BancoCuenta
	WHERE 	idBanco = @idBanco
			AND idEmpresa = @idEmpresa
			AND cuentaContable = @cuentaContable;


	-- SALDO BANCO DESPUES DE LA NETRADA AL SISTEMA
	DECLARE @SUMCargos2 NUMERIC(18,2) =  ( 	
											SELECT SUM(importe) 
											FROM [CARGOSBANCOS_CB] 
											WHERE IDBanco = @idBanco
												AND idEmpresa = @idEmpresa 
												AND noCuenta = @noCuenta 
												AND idEstatus = 0 
												AND CONVERT(NVARCHAR(10), fechaOperacion, 111) >= '2018/06/01'
											);

	DECLARE @SUMAbonos2 NUMERIC(18,2) =  (
											SELECT SUM(importe) 
											FROM  [ABONOSBANCOS_CB] 
											WHERE IDBanco = @idBanco
												AND idEmpresa = @idEmpresa
												AND noCuenta  = @noCuenta
												AND idEstatus = 0
												AND CONVERT(NVARCHAR(10), fechaOperacion, 111) >= '2018/06/01'
											);
	
	
	SELECT @saldoBanco = ISNULL(@SaldoInicial,0) - ISNULL( @SUMCargos2, 0 ) + ISNULL( @SUMAbonos2, 0 )
	


	SELECT @totalAbonoContable = SUM( MOV_HABER )
	FROM  [ABONOS_COMPLETO_CB] MOV
	LEFT JOIN REGISTROS_PUNTEADOS PUN ON MOV.IDABONOS_COMPLETO = PUN.rpun_idAbono AND rpun_tipo = 'C' AND rpun_idAplicado != 0
	WHERE idEmpresa  = @idEmpresa
			AND idBanco    = @idBanco
			AND MOV_NUMCTA = @cuentaContable
			AND idEstatus  IN (0)
			AND rpun_idAplicado IS NULL


	SELECT @totalCargoContable = SUM(MOV_DEBE) 
	FROM  [CARGOS_COMPLETO_CB] MOV
	LEFT JOIN REGISTROS_PUNTEADOS PUN ON MOV.IDCARGOS_COMPLETO = PUN.rpun_idCargo AND rpun_tipo = 'C' AND rpun_idAplicado != 0
   	WHERE idEmpresa  = @idEmpresa
			AND idBanco    = @idBanco
			AND MOV_NUMCTA = @cuentaContable
			AND idEstatus  IN (0)
			AND rpun_idAplicado IS NULL

	-- Set Totales de Cargos y Abonos Bancarios
	SELECT 
		@totalCargoBancario = SUM(importe)
	FROM  CARGOSBANCOS_CB CAR  --CARGOS
	LEFT JOIN  [REGISTROS_PUNTEADOS] PUN ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo
												AND PUN.rpun_tipo = 'B'
												AND PUN.rpun_idAplicado IN (1,2,3)
	WHERE CAR.noCuenta = @noCuenta
			AND CAR.idEmpresa = @idEmpresa
			AND CAR.IDBanco = @idBanco
			AND CAR.idEstatus  IN (0)
			AND PUN.rpun_idPunteado IS NULL



	SELECT
		@totalAbonoBancario = SUM(importe)
	FROM  ABONOSBANCOS_CB ABO  --CARGOS
	LEFT JOIN  [REGISTROS_PUNTEADOS] PUN ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono
											AND PUN.rpun_tipo = 'B'
											AND PUN.rpun_idAplicado IN (1,2,3)
	WHERE ABO.noCuenta = @noCuenta
			AND ABO.idEmpresa = @idEmpresa
			AND ABO.IDBanco = @idBanco
			AND ABO.idEstatus  IN (0)
			AND PUN.rpun_idPunteado IS NULL 

    -- DISCRIMINA LOS REGISTROS PUNTEADOS CON MOVIMIENTOS EN ESTATUD 2
    DECLARE @Discriminate NUMERIC(18,2), @AuxAbonoBancario NUMERIC(18,2), @AuxAbonoContable NUMERIC(18,2);
   SET @Discriminate = (
			SELECT SUM(MOV_DEBE) FROM REGISTROS_PUNTEADOS P
			INNER JOIN CARGOS_COMPLETO_CB CC ON P.rpun_idCargo = CC.IDCARGOS_COMPLETO
			WHERE rpun_grupoPunteo IN (
				SELECT rpun_grupoPunteo FROM VW_REGISTROS_PUNTEADOS WHERE rpun_grupoPunteo IN (
					SELECT rpun_grupoPunteo
					FROM REGISTROS_PUNTEADOS PUN
					INNER JOIN CARGOS_COMPLETO_CB MOV ON PUN.rpun_idCargo = MOV.IDCARGOS_COMPLETO AND rpun_tipo = 'C'
					WHERE   MOV.MOV_MES   <= @mes
							AND idEmpresa  = @idEmpresa
							AND anio       = @añoConsulta
							AND idBanco    = @idBanco
							AND MOV_NUMCTA = @cuentaContable
							AND idEstatus  = (2)
				) AND rpun_idAbono <> 0 AND rpun_tipo = 'B'
			) AND idEstatus = 2
		)
		
	   SET @AuxAbonoBancario = isnull(@totalAbonoBancario,0) + ISNULL(@Discriminate, 0);
	      
    SET @Discriminate = (
            SELECT SUM(MOV_DEBE) FROM REGISTROS_PUNTEADOS P
            INNER JOIN CARGOS_COMPLETO_CB CC ON P.rpun_idCargo = CC.IDCARGOS_COMPLETO
            WHERE rpun_grupoPunteo IN (
                SELECT rpun_grupoPunteo FROM VW_REGISTROS_PUNTEADOS WHERE rpun_grupoPunteo IN (
                    SELECT rpun_grupoPunteo
                    FROM REGISTROS_PUNTEADOS PUN
                    INNER JOIN CARGOS_COMPLETO_CB MOV ON PUN.rpun_idCargo = MOV.IDCARGOS_COMPLETO AND rpun_tipo = 'C'
                    WHERE   MOV.MOV_MES   <= @mes
                            AND idEmpresa  = @idEmpresa
                            AND anio       = @añoConsulta
                            AND idBanco    = @idBanco
                            AND MOV_NUMCTA = @cuentaContable
                            AND idEstatus  = (2)
                ) AND rpun_idAbono <> 0 AND rpun_tipo = 'C'
            ) AND idEstatus = 2
        )
		
	   SET @AuxAbonoContable = isnull(@totalAbonoContable,0) + ISNULL(@Discriminate, 0);
	-----------------------------------------------------------Cálculo de saldo según Conciliacion---------------------------------------------------------------------
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------
	SET @saldoConciliacion = ((ISNULL(@saldoBanco,0) - ISNULL(@AuxAbonoContable,0) - ISNULL(@AuxAbonoBancario,0))+ (ISNULL(@totalCargoContable,0) + ISNULL(@totalCargoBancario,0)))









	DECLARE @NombreMes varchar(3),
				@RESULT_MESNAME varchar(10),
				@ParmDefinition nvarchar(100),
				@result_SaldoInicial_Contable decimal(18,2);
	
		SET LANGUAGE Spanish;
		SET @NombreMes = SUBSTRING(DATENAME(MONTH, CONVERT(DATE, CONVERT(DATE, REPLACE(@fechaCorte,'-','')), 103)),0,4);--SUBSTRING(DATENAME(MONTH, convert(DATE, convert(date, @fechaCorte), 103)),0,4);
		SET @RESULT_MESNAME = UPPER('SF_'+ @NombreMes) 
	

		DECLARE @RESULTADO NVARCHAR(MAX) =   'SELECT @saldoInicialContable = CONVERT(DECIMAL(18,2),'+ @RESULT_MESNAME +')' +char(13)+ 
											+'FROM '+ @Base +'BI_VIEW_SALDOS_FINALES_'+CONVERT(VARCHAR(4),@añoConsulta)+'' +char(13) 
											+'WHERE  CTA_NUMCTA = '''+ @cuentaContable +''''
		SET @ParmDefinition = N'@saldoInicialContable decimal(18,2) OUTPUT';
        PRINT(@RESULTADO);

		EXECUTE sp_executesql @RESULTADO, @ParmDefinition, @saldoInicialContable = @result_SaldoInicial_Contable OUTPUT;

		SELECT @saldoContabilidad = @result_SaldoInicial_Contable
		 ----Saldo inicial + (@totalCargoContable - @totalAbonoContable)
		 ---------------------------------------------------Calculo Saldo Inicial--------------------------------------------
		print 'saldo conciliacion: ' + CONVERT(VARCHAR(20),@saldoConciliacion)














		DECLARE @saldoSegunContabilidad NUMERIC(18,5) = ( SELECT saldo FROM [SaldoContabilidad] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND noCuenta = @noCuenta );
		SET @saldoSegunContabilidad = ISNULL( @saldoSegunContabilidad,0);
		
		IF( @saldoSegunContabilidad <> 0 )
			BEGIN
				SET @saldoContabilidad = @saldoSegunContabilidad;
			END
		------------------------------------------------------------------Cálculo Diferencia-------------------------------------------------------------------------------
		-------------------------------------------------------------------------------------------------------------------------------------------------------------------
		SET @diferencia = @saldoConciliacion - @saldoContabilidad


		----------------------------------------------------------Consulto la viabilidad del mes de búsqueda---------------------------------------------------------------
		-------------------------------------------------------------------------------------------------------------------------------------------------------------------

		DECLARE @Meses TABLE(ID INT IDENTITY(1,1), PAR_IDENPARA VARCHAR(10), PAR_DESCRIP2 VARCHAR(20))
		DECLARE @mensaje VARCHAR(100) = 'Mes actual activo.'

		--INSERT INTO @Meses

        /*
		SELECT  PAR_IDENPARA,PAR_DESCRIP2
		FROM GAAU_Concentra.dbo.PNC_PARAMETR
		WHERE PAR_TIPOPARA = 'mcerrcon' 	
		AND PAR_IDENPARA LIKE '' + CONVERT(VARCHAR(10),DATEPART(year,REPLACE(@primerDiaMesConsulta,'-',''))) + '%'
		AND PAR_DESCRIP1 = '01'
        */
	
        /*
		SELECT @mesActivo = CASE PAR_DESCRIP2
								WHEN 'ABIERTO' THEN 1
								WHEN 'CERRADO' THEN 0
							END 
		FROM @Meses WHERE PAR_IDENPARA = REPLACE(@primerDiaMesConsulta,'-','')
        */

        /*
		IF(SELECT PAR_DESCRIP2 FROM @Meses WHERE ID = (SELECT ID - 1 FROM @Meses WHERE PAR_IDENPARA = REPLACE(@primerDiaMesConsulta,'-',''))) = 'ABIERTO'
			BEGIN
				SELECT @mesActivo = 0, @mensaje = ' Los movimientos del mes actual no se podran ver. El mes anterior aun se encuentra activo.'
			END 
        */
			
		IF(@idHistorico <> 0)
		BEGIN
			INSERT INTO TOTALES_H([idHistorico]
								,[saldoBanco]
								,[tAbonoContable]
								,[tAbonoBancario]
								,[tCargoContable]
								,[tCargoBancario]
								,[sConciliacion]
								,[sContabilidad]
								,[diferencia]
								,[mesActivo])
			VALUES(@idHistorico,
					ISNULL(@saldoBanco,0),
					ISNULL(@totalAbonoContable,0),
					ISNULL(@totalAbonoBancario,0),
					ISNULL(@totalCargoContable,0),		
					ISNULL(@totalCargoBancario,0),
					ISNULL(@saldoConciliacion,0),
					ISNULL(@saldoContabilidad,0),
					ISNULL(@diferencia,0),
					ISNULL(@mesActivo,0))
		END

	SELECT ISNULL(@saldoBanco,0) saldoBanco,
			ISNULL(@totalAbonoContable,0) tAbonoContable,
			ISNULL(@totalAbonoBancario,0) tAbonoBancario,
			ISNULL(@totalCargoContable,0) tCargoContable,		
			ISNULL(@totalCargoBancario,0) tCargoBancario,
			ISNULL(@saldoConciliacion,0) sConciliacion,
			ISNULL(@saldoContabilidad,0) sContabilidad,
			ISNULL(@diferencia,0) diferencia,
			ISNULL(@mes,0) mesActivo,
			@mensaje mensaje
END



go

