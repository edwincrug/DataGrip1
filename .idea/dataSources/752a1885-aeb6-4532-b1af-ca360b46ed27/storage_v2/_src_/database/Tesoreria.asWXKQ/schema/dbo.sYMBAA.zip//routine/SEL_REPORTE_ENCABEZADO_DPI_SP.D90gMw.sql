--[dbo].[SEL_REPORTE_ENCABEZADO_DPI_SP] 1
CREATE PROCEDURE [dbo].[SEL_REPORTE_ENCABEZADO_DPI_SP] 
	@idEmpresa INT
AS
BEGIN
	SET NOCOUNT ON;
	SELECT numeroCuenta,cuenta, idPersona FROM referencias.dbo.BancoCuenta WHERE idEmpresa=@idEmpresa and activo=1
END
go

