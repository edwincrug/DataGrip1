-- [dbo].[SEL_CARGO_CONTABLE_SP] 1, '2018-06-01', '2018-06-30', 1,  '000000000195334667', '1100-0020-0001-0001', 3
CREATE PROCEDURE [dbo].[SEL_CARGO_CONTABLE_SP]
	@idEmpresa VARCHAR(50),
	@fechaElaboracion VARCHAR(50),
	@fechaCorte VARCHAR(50),
	@idBanco INT,
	@noCuenta VARCHAR(50),
	@cuentaContable VARCHAR(50),
	@opcion INT -- 1: detalle, 2: resumen
AS
BEGIN
	
	DECLARE @idHistorico INT = 0;
	-- Casos @opcion
	-- 1: Normal 
	-- 2: Empresa
	-- 3: Sistema
	
	IF( @opcion = 1 )
		BEGIN
			SELECT	
				CC.MOV_NUMCTA MOV_NUMCTA,
				CC.MOV_TIPOPOL MOV_TIPOPOL,
				CC.MOV_CONSPOL MOV_CONSPOL,
				CC.MOV_CONSMOV MOV_CONSMOV,
				CC.MOV_MES MOV_MES,
				CC.MOV_DEBE MOV_DEBE,
				CC.MOV_FECHOPE MOV_FECHOPE,
				CC.MOV_HABER MOV_HABER,
				CC.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM CARGOS_COMPLETO_CB CC
			LEFT JOIN REGISTROS_PUNTEADOS PUN ON PUN.rpun_idCargo = CC.IDCARGOS_COMPLETO AND PUN.rpun_tipo = 'C'
			WHERE   CC.idEmpresa = @idEmpresa
					AND CC.idBanco = @idBanco
					AND CC.MOV_NUMCTA = @cuentaContable
					AND PUN.rpun_idCargo IS NULL
					AND idEstatus = 0
					ORDER BY CC.MOV_FECHOPE, CC.MOV_CONSPOL ASC
		END
	ELSE IF( @opcion = 2 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 1
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)

			SELECT	
				MOV.MOV_NUMCTA MOV_NUMCTA,
				MOV.MOV_TIPOPOL MOV_TIPOPOL,
				MOV.MOV_CONSPOL MOV_CONSPOL,
				MOV.MOV_CONSMOV MOV_CONSMOV,
				MOV.MOV_MES MOV_MES,
				MOV.MOV_DEBE MOV_DEBE,
				MOV.MOV_FECHOPE MOV_FECHOPE,
				MOV.MOV_HABER MOV_HABER,
				MOV.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM  [CARGOS_COMPLETO_CB_H] MOV
			WHERE   MOV.MOV_MES <= MONTH(@fechaElaboracion) 
					AND MOV.MOV_NUMCTA = @cuentaContable
					AND MOV.idEmpresa = @idEmpresa
					AND MOV.idBanco = @idBanco
					AND MOV.idEstatus = 0
					AND IDCARGOS_COMPLETO NOT IN (SELECT rpun_idCargo FROM REGISTROS_PUNTEADOS_H WHERE rpun_tipo = 'C' AND idHistorico = @idHistorico)
					AND MOV.anio = YEAR(@fechaElaboracion)
					AND MOV.idHistorico = @idHistorico
		END
	ELSE IF( @opcion = 3 )
		BEGIN
			
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 2
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)

			SELECT	
				MOV.MOV_NUMCTA MOV_NUMCTA,
				MOV.MOV_TIPOPOL MOV_TIPOPOL,
				MOV.MOV_CONSPOL MOV_CONSPOL,
				MOV.MOV_CONSMOV MOV_CONSMOV,
				MOV.MOV_MES MOV_MES,
				MOV.MOV_DEBE MOV_DEBE,
				MOV.MOV_FECHOPE MOV_FECHOPE,
				MOV.MOV_HABER MOV_HABER,
				MOV.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM  [CARGOS_COMPLETO_CB_H] MOV
			WHERE   MOV.MOV_MES <= MONTH(@fechaElaboracion) 
					AND MOV.MOV_NUMCTA = @cuentaContable
					AND MOV.idEmpresa = @idEmpresa
					AND MOV.idBanco = @idBanco
					AND MOV.idEstatus = 0
					AND IDCARGOS_COMPLETO NOT IN (SELECT rpun_idCargo FROM REGISTROS_PUNTEADOS_H WHERE rpun_tipo = 'C' AND idHistorico = @idHistorico)
					AND MOV.anio = YEAR(@fechaElaboracion)
					AND MOV.idHistorico = @idHistorico
		END
END
go

