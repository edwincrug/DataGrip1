CREATE PROCEDURE [dbo].[SEL_EMPRESA_SP] 
 @idEmpresa as int 
 as 
 begin 

	select 
		emp_idempresa as idEmpresa,
		emp_nombrecto as nombreCorto,
		emp_nombre as nombre 
	from [ControlAplicaciones].[dbo].[cat_empresas]
	WHERE emp_idempresa != 0
 
 end
go

