---EXECUTE [dbo].[INS_PUNTEO_DEPOSITO_AUXILIAR_SP] 9999,1,'PRUEBA',0,4,2,1,1,2
--[INS_PUNTEO_DEPOSITO_AUXILIAR_SP] @idDepositoBanco = 4 ,@idAuxiliarContable = 5
CREATE PROCEDURE [dbo].[INS_PUNTEO_DEPOSITO_AUXILIAR_SP]
 @idDepositoBanco int 
,@idAuxiliarContable int 
,@descripcion nvarchar(50) = ''
,@idEstatus int
,@idPadre int
,@idOpcion int
,@idEmpresa int
,@idBanco int
,@tipoPunteo int
,@idBmerPadre INT = 0
,@idUsuario INT = 0
,@esCargoBanco INT= 0
,@esCargoContable INT= 0
AS
BEGIN TRY

IF @idOpcion = 1
	BEGIN	
		
		DECLARE @MOV_CONSPOL INT, @MOV_CONSMOV INT, @MOV_MES INT,@MOV_TIPOPOL VARCHAR(50), @idPunteoAuxiliarBanco NUMERIC(18,0)

	
			
			IF(@esCargoContable = 0)
			BEGIN
				SELECT @MOV_CONSPOL = MOV_CONSPOL, @MOV_CONSMOV = MOV_CONSMOV, @MOV_MES = MOV_MES, @MOV_TIPOPOL = MOV_TIPOPOL FROM
					  ABONOS_COMPLETO_CB  WHERE IDABONOS_COMPLETO = @idAuxiliarContable
			END
		ELSE
			BEGIN
				SELECT @MOV_CONSPOL = MOV_CONSPOL, @MOV_CONSMOV = MOV_CONSMOV, @MOV_MES = MOV_MES, @MOV_TIPOPOL = MOV_TIPOPOL FROM
						CARGOS_COMPLETO_CB WHERE IDCARGOS_COMPLETO = @idAuxiliarContable 
			END

		
				INSERT INTO [dbo].[PunteoAuxiliarBanco](
								[idDepositoBanco]
							,[idAuxiliarContable]
							,[descripcion]
							,[idPAdre]
							,[fechaAplicacion]
							,[idEmpresa]
							,[idBanco]
							,[idPunteoFinalBancos]
							,[tipoPunteo]
							,idUsuario
							,esCargoBanco
							,esCargoContable) 
				VALUES (@idDepositoBanco
							,@idAuxiliarContable
							,@descripcion
							,@idPadre
							,GETDATE()
							,@idEmpresa
							,@idBanco
							,2
							,@tipoPunteo
							,@idUsuario
							,@esCargoBanco
							,@esCargoContable)
			
				SET @idPunteoAuxiliarBanco = @@IDENTITY

				UPDATE PunteoAuxiliarBanco 
				SET MOV_CONSPOL = @MOV_CONSPOL,
					MOV_CONSMOV = @MOV_CONSMOV, MOV_MES = @MOV_MES, MOV_TIPOPOL = @MOV_TIPOPOL

				WHERE idPunteoAuxiliarBanco = @idPunteoAuxiliarBanco
				


	END
IF @idOpcion = 2
	BEGIN
	INSERT INTO [dbo].[PunteoAuxiliarBanco](
						[idDepositoBanco]
						,[idAuxiliarContable]
						,[descripcion]
						,[idPAdre]
						,[fechaAplicacion]
						,[idEmpresa]
						,[idBanco]
						,[idPunteoFinalBancos]
						,[tipoPunteo]
						,[idBmerPadre]
						,esCargoBanco
						,esCargoContable) --varchar(111111)) 
			VALUES (@idDepositoBanco
						,@idAuxiliarContable
						,@descripcion
						,@idPadre
						,GETDATE()
						,@idEmpresa
						,@idBanco
						,2
						,@tipoPunteo
						,@idBmerPadre
						,@esCargoBanco
						,@esCargoContable)
	END

	
	   SELECT SCOPE_IDENTITY() AS idPunteoAuxiliarBanco

END TRY
BEGIN CATCH
          SELECT ERROR_MESSAGE() AS ERROR_OPERACION
END CATCH


go

