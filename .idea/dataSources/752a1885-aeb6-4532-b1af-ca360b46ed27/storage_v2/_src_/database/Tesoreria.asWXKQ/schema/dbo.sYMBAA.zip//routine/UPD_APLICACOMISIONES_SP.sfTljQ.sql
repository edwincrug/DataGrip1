CREATE PROCEDURE [dbo].[UPD_APLICACOMISIONES_SP]
	@interesComisionID AS INT
AS
BEGIN
	DECLARE @LastId INT;
	
	INSERT INTO cuentasxpagar .dbo.[cxp_comisionesintereses]
	SELECT 
		coi_idempresa,
		coi_idsucursal,
		coi_tipopoliza,
		coi_fechapoliza,
		coi_descripcion,
		coi_fechageneracion,
		coi_estatus,
		coi_cuentabeneficiario,
		coi_cuentapagadora,
		coi_cobrador,
		coi_moneda,
		coi_tipocambio,
		coi_formapago,
		coi_tipo
	FROM  [cxp_comisionesintereses] CXP
	INNER JOIN  [InteresComision] COM ON CXP.interesComisionID = COM.interesComisionID
	WHERE COM.interesComisionID = @interesComisionID;
	
	UPDATE InteresComision SET statusID = 2 WHERE interesComisionID = @interesComisionID;
	
	SET @LastId = @@IDENTITY;
	
	UPDATE  [cxp_comisionesintereses] SET coi_idcomisionesinteresesBPRO = @LastId WHERE interesComisionID = @interesComisionID;

	INSERT INTO cuentasxpagar.[dbo].[cxp_comisionesinteresesdet] 
	SELECT 
		cid_cuentacontable,
		cid_concepto,
		cid_cargo,
		cid_abono,
		cid_documento,
		cid_idpersona,
		@LastId,
		cid_tipodocumento,
		cid_fechavencimiento,
		cid_poriva,
		cid_referencia,
		cid_banco,
		cid_referenciabancaria,
		cid_conpoliza 
	FROM  [cxp_comisionesinteresesdet] DET
	INNER JOIN  [cxp_comisionesintereses] CXP ON DET.coi_idcomisionesintereses = CXP.coi_idcomisionesintereses
	INNER JOIN  [InteresComision] COM ON CXP.interesComisionID = COM.interesComisionID
	WHERE COM.interesComisionID = @interesComisionID;

	SELECT 1 AS respuesta, 'Insert Éxitoso' mensaje
END
go

