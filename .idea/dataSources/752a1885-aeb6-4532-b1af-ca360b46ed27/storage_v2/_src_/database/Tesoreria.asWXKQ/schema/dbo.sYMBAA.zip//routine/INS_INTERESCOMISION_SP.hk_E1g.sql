
CREATE PROCEDURE [dbo].[INS_INTERESCOMISION_SP]
	@interesID as INT,
	@comisionID as INT,
	@bancoID as INT,
	@userID as INT,
	@idEmpresa as INT,
	@Agrupador as INT,
	@statusID as INT
AS
BEGIN
	INSERT INTO interesComision ( interesID, comisionID, bancoID, userID, fecha, statusID, idEmpresa, agrupador ) 
						 VALUES ( @interesID, @comisionID, @bancoID, @userID, getdate(),	@statusID, @idEmpresa, @Agrupador );
	SELECT @@identity AS headerID
END
go

