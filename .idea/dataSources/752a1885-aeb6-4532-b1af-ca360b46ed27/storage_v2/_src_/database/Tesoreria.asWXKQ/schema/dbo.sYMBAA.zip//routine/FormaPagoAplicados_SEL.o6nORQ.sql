-- =============================================
-- Author:		<Irving Solorio>, <Alejandro Grijalva Antonio>
-- Create date: <21/01/2019>
-- Description:	<Forma de pago no definida refantypaq>
-- =============================================
--[dbo].[FormaPagoAplicados_SEL] 71
CREATE PROCEDURE [dbo].[FormaPagoAplicados_SEL]
	@idUsuario INT          = 71,
	@idEmpresa INT          = 1,
    @idBanco INT            = 0,
    @numCuenta NVARCHAR(20) = NULL
AS
BEGIN
    SELECT c.[rap_folio]
        ,[rap_referenciabancaria]
        ,[rap_referencia]
        ,[rap_iddocto]
        ,[rap_cotped]
        ,[rap_importe]
        ,[rap_idsucursal]
        ,ca.suc_nombre sucursal
        ,[rap_iddepartamento]
        ,de.dep_nombre
        ,[rap_idpersona]
        ,p.PER_NOMRAZON+ ' ' +p.PER_PATERNO + ' '+ p.PER_MATERNO persona
        ,[rap_formapago]
        ,b.fecha
        ,x.FormaPago
        ,c.rap_numctabanc
        ,SUBSTRING ( c.rap_numctabanc ,( LEN(c.rap_numctabanc) - 3 ) , LEN(c.rap_numctabanc) ) cuenta
        ,c.rap_banco
        ,UPPER(Ba.nombre) Banco
        ,mov.codigoLeyenda
        ,CI.Descripcion TipoPago
    FROM  GA_Corporativa.dbo.cxc_refantypag c
    INNER JOIN [ControlAplicaciones].dbo.cat_sucursales ca ON c.rap_idsucursal=ca.suc_idsucursal
    INNER JOIN [ControlAplicaciones].dbo.cat_departamentos de ON c.rap_iddepartamento=de.dep_iddepartamento
    INNER JOIN GA_Corporativa.dbo.PER_PERSONAS p ON c.rap_idpersona=p.PER_IDPERSONA
    
    INNER JOIN ( SELECT DISTINCT(idBanco), idBancoBPRO, idEmpresa  FROM referencias.dbo.BancoCuenta WHERE idEmpresa = @idEmpresa  ) BAN ON BAN.idEmpresa = c.rap_idempresa AND BAN.idBancoBPRO = C.rap_banco
    INNER JOIN referencias.dbo.Banco Ba ON Ba.idBanco = BAN.idBanco
    INNER JOIN referencias.dbo.RAPDeposito RD ON RD.rap_folio = c.rap_folio
    INNER JOIN [controlDepositosView] mov ON mov.IDBanco = RD.idBanco AND rd.idDeposito = mov.idBmer
    left JOIN referencias.dbo.CodigoIdentificacion CI ON CI.CodigoBanco = mov.codigoLeyenda and mov.IDBanco = CI.IDBanco

    INNER JOIN BitacoraFormaPago b ON c.rap_folio=b.rap_folio
    INNER JOIN (VALUES ('38','CHEQUE')
                , ('02','TRANSFERENCIA')
        ) x (id, FormaPago) ON x.id=c.rap_formapago
    WHERE   b.idusuario=@idUsuario
            AND rap_idempresa = @idEmpresa 
            AND ( BAN.idBanco = @idBanco OR @idBanco = 0 )
            AND ( rap_numctabanc like '%'+REPLACE(LTRIM(REPLACE(@numCuenta, '0', ' ')),' ', '0')+'%' OR @numCuenta IS NULL )
END



go

