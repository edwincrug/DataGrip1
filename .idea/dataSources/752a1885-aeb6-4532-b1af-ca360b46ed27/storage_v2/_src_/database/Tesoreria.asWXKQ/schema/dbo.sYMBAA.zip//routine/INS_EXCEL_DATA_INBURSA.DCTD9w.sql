-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[INS_EXCEL_DATA_INBURSA]
	-- Add the parameters for the stored procedure here

@idBanco INT,
@noCuenta VARCHAR(100),
@fecha VARCHAR(100),
@referencia numeric(18,0),
@refLeyenda VARCHAR(100),
@refNumerica numeric(18,0),
@cargo numeric(18,2),
@abono numeric(18,2),
@ordenante VARCHAR(100),
@clveLayout VARCHAR(30)


AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [referencias].[dbo].[Inbursa_Layout]
	                                (
								    idBanco,
									noCuenta,
									fecha,
									Referencia,
									ReferenciaLeyenda,
									ReferenciaNumerica,
									Cargo,
									Abono,
									Ordenante
									) 
	                               SELECT
								    @idBanco,
									ISNULL(RTRIM(LTRIM(@noCuenta)),'INDEFINIDO'),
                                    ISNULL(CONVERT(DATE,(RTRIM(LTRIM(@fecha))),103), CONVERT(date,GETDATE(),103)),
	                                ISNULL(RTRIM(LTRIM(@referencia)), 0),
									ISNULL(RTRIM(LTRIM(@refLeyenda)),'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@refNumerica)),0),
									ISNULL(CONVERT(numeric(18,2),RTRIM(LTRIM(@cargo))),0),
									ISNULL(CONVERT(numeric(18,2),RTRIM(LTRIM(@abono))),0),
									ISNULL(RTRIM(LTRIM(@ordenante)),'INDEFINIDO')
							        
 
              
			   UPDATE [layout_Historial]
					  SET fecha_Carga_Info = CONVERT(date, GETDATE())
					  WHERE clv_Identificador = @clveLayout 


				SELECT 1 AS SUCCESS 

		
END TRY
BEGIN CATCH
          SELECT ERROR_MESSAGE() AS ERROR
END CATCH
go

