-- =============================================
-- Author:		Roberto Almanza	Nieto
-- Create date: 27-03-2019
-- Description:	Envia correo de notificacion de registros punteados con error
-- =============================================
CREATE PROCEDURE [dbo].[SEL_NOTIFICA_PUNTEADOS_ERR_SP] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

/*================================================================
						MONITOR ROJITOS
================================================================*/


    DECLARE @tablaDatos TABLE(
rpun_idPunteado int
,rpun_grupoPunteo int
,rpun_idCargo int
,rpun_idAbono int
,rpun_tipo varchar(1)
,concepto nvarchar(250)
,rpun_fechaPunteo datetime
,rpun_usuario int
,rpun_idAplicado int
,idEmpresa int
,IDBanco int
,noCuenta varchar(50)
,cargos numeric(38,6)
,abonos numeric(38,6)
,mes int
,anio int
,idbmer int
,idMes int
,totalcargos numeric(38,6)
,totalabonos numeric(38,6)
,motivo varchar(250)
,tipo varchar(30)
)

DECLARE @tablaDatosRapFolios TABLE(rap_folio int
, rap_idempresa int
, rap_idsucursal int
, rap_iddepartamento int
, rap_idpersona int
, rap_cobrador varchar(5)
, rap_moneda varchar(2)
, rap_tipocambio int
, rap_referencia nvarchar(150)
, rap_iddocto nvarchar(150)
, rap_cotped nvarchar(150)
, rap_consecutivo int
, rap_importe decimal(18,2)
, rap_formapago int
, rap_numctabanc varchar(60)
, rap_fecha datetime
, rap_idusuari int 
, rap_idstatus int
, rap_banco varchar(60)
, rap_referenciabancaria varchar(150)
, rap_anno int
, RAP_AplicaPago decimal(18,2)
, RAP_NumDeposito int )


DECLARE @tableHTML  nvarchar(MAX) ='';
DECLARE @tableHTML2  nvarchar(MAX) = '';
DECLARE @htmlFinal nvarchar(max) ='';
DECLARE @destinatarios nvarchar(max) ='';
DECLARE @enviaCobros bit = 0
DECLARE @enviaRojitos bit = 0

SELECT @destinatarios = dm.destinatarios FROM dbo.DestinatariosMonitores dm WHERE dm.id = 1

SET @tableHTML =N'<html>'+
		N'<head>'+
		N'<style>'+
		N'table {'+
		N'border-collapse: collapse;'+
		N'width: 100%;'+
		N'}'+
		N'th, td {'+
		N'text-align: left;'+
		N'padding: 8px;'+
		N'font-size: x-small;'+
		N'}'+
		N'th {'+
		N'text-align: center;'+
		N'}'+
		N'tr:nth-child(even) {background-color: #E6F2FF;}'+
		N'</style>'+
		N'</head>' +
		N'<body>' +
		N'<div style="overflow-x:auto;">'




DECLARE cRevisa CURSOR
READ_ONLY
FOR select idEmpresa,idBanco, numeroCuenta, cuenta, ce.emp_nombre+' - '+ce.emp_cveempresa 
from referencias.dbo.bancocuenta ban
JOIN ControlAplicaciones.dbo.cat_empresas ce
ON ban.idEmpresa = ce.emp_idempresa

DECLARE @empresa int, @banco int, @numeroCuenta varchar(50), @cuenta varchar(50), @nomEmpresa nvarchar(150) 
OPEN cRevisa

FETCH NEXT FROM cRevisa INTO @empresa, @banco, @numeroCuenta, @cuenta, @nomEmpresa
WHILE (@@FETCH_STATUS = 0)
BEGIN

	INSERT INTO @tablaDatos
	EXEC [SEL_REGISTROS_PUNTEADOS_ERR] @empresa,@banco,@numeroCuenta

	if(@@ROWCOUNT >0)
	BEGIN
	 SET @enviaRojitos=1

	SET @tableHTML = @tableHTML +
		N'<H2>'+@nomEmpresa+'</H2>' +
        N'<H3>'+@cuenta+' cuenta '+ @numeroCuenta+'</H3>' +
        N'<table>' +
        N'<tr>'+
		N'<th>rpun_idPunteado</th>' +
        N'<th>rpun_grupoPunteo</th>'+
		N'<th>rpun_idCargo</th>' +
        N'<th>rpun_idAbono</th>'+
		N'<th>rpun_tipo</th>' +
        N'<th>concepto </th>'+
		N'<th>rpun_fechaPunteo</th>' +
        N'<th>rpun_usuario</th>'+
		N'<th>rpun_idAplicado</th>' +
        N'<th>idEmpresa</th>'+
		N'<th>IDBanco</th>' +
        N'<th>noCuenta</th>'+
		N'<th>cargos</th>' +
        N'<th>abonos</th>'+
		N'<th>mes</th>' +
		N'<th>anio</th>' +
        N'<th>idbmer</th>'+
		N'<th>idMes</th>' +
        N'<th>totalcargos</th>'+
		N'<th>totalabonos</th>' +
        N'<th>motivo</th>'+
		N'<th>tipo</th>' +
		N'</tr>' +
        CAST ( ( SELECT  td = rpun_idPunteado , ''
						,td = rpun_grupoPunteo , ''
						,td = rpun_idCargo , ''
						,td = rpun_idAbono , ''
						,td = rpun_tipo , ''
						,td = concepto , ''
						,td = rpun_fechaPunteo , ''
						,td = rpun_usuario , ''
						,td = rpun_idAplicado , ''
						,td = idEmpresa , ''
						,td = IDBanco , ''
						,td = noCuenta , ''
						,td = cargos , ''
						,td = abonos , ''
						,td = mes , ''
						,td = anio , ''
						,td = idbmer , ''
						,td = idMes , ''
						,td = totalcargos , ''
						,td = totalabonos , ''
						,td = motivo , ''
						,td = tipo , ''
                  FROM @tablaDatos
                  FOR XML PATH('tr'), TYPE 
        ) AS NVARCHAR(MAX) ) +      
        N'</table>'

		DELETE FROM @tablaDatos
	END


	FETCH NEXT FROM cRevisa INTO @empresa, @banco, @numeroCuenta,@cuenta, @nomEmpresa
END

CLOSE cRevisa
DEALLOCATE cRevisa

SET @tableHTML = @tableHTML+ 
        N'</div>'+
		N'</body>'+
		N'</html>'


/*================================================================
				Cobros no aplicados por BPRO
================================================================*/

INSERT INTO @tablaDatosRapFolios
SELECT rap_folio
,rap_idempresa
,rap_idsucursal
,rap_iddepartamento
,rap_idpersona
,rap_cobrador
,rap_moneda
,rap_tipocambio
,rap_referencia
,rap_iddocto
,rap_cotped
,rap_consecutivo
,rap_importe
,rap_formapago
,rap_numctabanc
,rap_fecha
,rap_idusuari
,rap_idstatus
,rap_banco
,rap_referenciabancaria
,rap_anno
,RAP_AplicaPago
,RAP_NumDeposito
FROM GA_Corporativa.dbo.cxc_refantypag 
WHERE rap_idstatus=0

if(@@ROWCOUNT >0)
BEGIN
	SET @enviaCobros=1
	SET @tableHTML2 =
		N'<html>'+
		N'<head>'+
		N'<style>'+
		N'table {'+
		N'border-collapse: collapse;'+
		N'width: 5%;'+
		N'}'+
		N'th, td {'+
		N'text-align: left;'+
		N'padding: 8px;'+
		N'font-size: x-small;'+
		N'}'+
		N'th {'+
		N'text-align: center;'+
		N'}'+
		N'tr:nth-child(even) {background-color: #E6F2FF;}'+
		N'</style>'+
		N'</head>' +
		N'<body>' +
		N'<div style="overflow-x:auto;">'+
        N'<H2>Cobros no aplicados por BPRO</H2>' +
		--N'<hr>'+
        N'<table>' +
        N'<tr>'+
		N'<th>rap_folio</th>' +
		N'<th>rap_idempresa</th>' +
		N'<th>rap_idsucursal</th>' +
		N'<th>rap_iddepartamento</th>' +
		N'<th>rap_idpersona</th>' +
		N'<th>rap_cobrador</th>' +
		N'<th>rap_moneda</th>' +
		N'<th>rap_tipocambio</th>' +
		N'<th>rap_referencia</th>' +
		N'<th>rap_iddocto</th>' +
		N'<th>rap_cotped</th>' +
		N'<th>rap_consecutivo</th>' +
		N'<th>rap_importe</th>' +
		N'<th>rap_formapago</th>' +
		N'<th>rap_numctabanc</th>' +
		N'<th>rap_fecha</th>' +
		N'<th>rap_idusuari</th>' +
		N'<th>rap_idstatus</th>' +
		N'<th>rap_banco</th>' +
		N'<th>rap_referenciabancaria</th>' +
		N'<th>rap_anno</th>' +
		N'<th>RAP_AplicaPago</th>' +
		N'<th>RAP_NumDeposito</th>' +
		N'</tr>' +
        CAST ( ( SELECT td = rap_folio , ''
						,td =rap_idempresa , ''
						,td =rap_idsucursal , ''
						,td =rap_iddepartamento , ''
						,td =rap_idpersona , ''
						,td =rap_cobrador , ''
						,td =rap_moneda , ''
						,td =rap_tipocambio , ''
						,td =rap_referencia , ''
						,td =rap_iddocto , ''
						,td =rap_cotped , ''
						,td =rap_consecutivo , ''
						,td =rap_importe , ''
						,td =rap_formapago , ''
						,td =rap_numctabanc , ''
						,td =rap_fecha , ''
						,td =rap_idusuari , ''
						,td =rap_idstatus , ''
						,td =rap_banco , ''
						,td =rap_referenciabancaria , ''
						,td =rap_anno , ''
						,td =RAP_AplicaPago , ''
						,td =RAP_NumDeposito , ''
				 FROM @tablaDatosRapFolios
                  FOR XML PATH('tr'), TYPE 
        ) AS NVARCHAR(MAX) ) +      
        N'</table>'+
		N'</div>'+
		N'</body>'+
		N'</html>'

END




 IF(@enviaRojitos = 1)
 BEGIN
 PRINT @tableHTML
	set @htmlFinal = @tableHTML
 END

 if(@enviaCobros =1)
 BEGIN
 PRINT @tableHTML2
 SET @htmlFinal = @htmlFinal+' '+ @tableHTML2
 END


 if(@enviaRojitos = 1 OR @enviaCobros=1)
 begin

 		EXEC msdb.dbo.sp_send_dbmail  
		@profile_name = null,  
		@recipients = @destinatarios,   
		@subject = 'Reporte de incidencias punteos y cobros no aplicados por BPRO',  
		@body = @htmlFinal,
		@body_format = 'HTML'
END

END
go

