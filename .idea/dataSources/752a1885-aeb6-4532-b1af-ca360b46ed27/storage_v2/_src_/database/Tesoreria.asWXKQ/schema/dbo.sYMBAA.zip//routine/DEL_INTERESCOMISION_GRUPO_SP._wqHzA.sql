
CREATE PROCEDURE [dbo].[DEL_INTERESCOMISION_GRUPO_SP]
	@agrupador AS INT,
	@idEmpresa AS INT
AS
BEGIN
	DELETE FROM [cxp_comisionesinteresesdet] WHERE cid_idcomisionesinteresesdet IN ( SELECT cid_idcomisionesinteresesdet 
	FROM [cxp_comisionesinteresesdet] DET
	INNER JOIN [cxp_comisionesintereses] ENC ON DET.coi_idcomisionesintereses = ENC.coi_idcomisionesintereses
	INNER JOIN [InteresComision] COM ON ENC.interesComisionID = COM.interesComisionID
	WHERE agrupador = @agrupador AND COM.idEmpresa = @idEmpresa AND COM.statusID = 1 );

	DELETE FROM [cxp_comisionesintereses] WHERE coi_idcomisionesintereses IN ( SELECT coi_idcomisionesintereses FROM [cxp_comisionesintereses] ENC
	INNER JOIN [InteresComision] COM ON ENC.interesComisionID = COM.interesComisionID
	WHERE agrupador = @agrupador AND COM.idEmpresa = @idEmpresa AND COM.statusID = 1 );

	DELETE FROM [InteresComision] WHERE agrupador = @agrupador AND idEmpresa = @idEmpresa AND statusID = 1;
 
	SELECT '0' result
END


go

