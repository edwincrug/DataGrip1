-- =============================================
-- Author:		Ing. Luis Antonio García Perrusquía
-- Create date: 27/04/2018
-- Description:	Trae todos los datos del historico de universo movimiento contable
-- TEST EXECUTE [dbo].[SEL_CONTABLE_TODO_SP_H] 1, 71, 1, '000000000195334667', '1100-0020-0001-0001', '2018-06-01', 'TREEUN', 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CONTABLE_TODO_SP_H]
	@idEmpresa INT,
	@idUsuario INT,
	@idHistorico INT,
	@noCuenta VARCHAR (250),
	@cuentaContable VARCHAR (250),
	@fechaElaboracion DATE,
	@polizaPago VARCHAR (250),
	@idBanco INT
AS
BEGIN
	BEGIN TRY
		BEGIN
			DECLARE @mes INT = MONTH(REPLACE(@fechaElaboracion,'-','')) 
			SELECT
				 CONTABLES.[IDABONOS_COMPLETO_H]
				,CONTABLES.[IDABONOS_COMPLETO]
				,CONTABLES.[MOV_TIPOPOL]
				,CONTABLES.[MOV_CONSPOL]
				,CONTABLES.[MOV_CONSMOV]
				,CONTABLES.[MOV_MES]
				,CONTABLES.[MOV_NUMCTA]
				,CONTABLES.[MOV_CONCEPTO]
				,CONTABLES.[MOV_DEBE]
				,CONTABLES.[MOV_HABER]
				,CONTABLES.[MOV_ORIGEN]
				,CONTABLES.[MOV_IDCLIENTE]
				,CONTABLES.[MOV_DEPTO]
				,CONTABLES.[MOV_CARTERA]
				,CONTABLES.[MOV_TIPODOCTO]
				,CONTABLES.[MOV_IDDOCTO]
				,CONTABLES.[MOV_FECHVEN]
				,CONTABLES.[MOV_FECHPAG]
				,CONTABLES.[MOV_AGENTE]
				,CONTABLES.[MOV_CVEUSU]
				,CONTABLES.[MOV_FECHOPE]
				,CONTABLES.[MOV_CONCILIADO]
				,CONTABLES.[MOV_FOLIO]
				,CONTABLES.[MOV_FOLIODET]
				,CONTABLES.[MOV_MONEDA]
				,CONTABLES.[MOV_TIPOCAMBIO]
				,CONTABLES.[MOV_HORAOPE]
				,CONTABLES.[MOV_OBSERVA]
				,CONTABLES.[TIPO]
				,CONTABLES.[idUsuario]
				,CONTABLES.[idEmpresa]
				,CONTABLES.[idBanco]
				,CONTABLES.[anio]
				,CONTABLES.[fecha]
				,CONTABLES.[idEstatus]
				,CONTABLES.[idConciliado]
				,CONTABLES.[idHistorico],
				CASE WHEN MOV_DEBE = 0 THEN 1 ELSE 0 END tipoMovimiento,
				[cargo] = MOV_DEBE,
				[abono] = MOV_HABER
			FROM 
			(
				SELECT 
					 MOV.[IDABONOS_COMPLETO_H]
					,MOV.[IDABONOS_COMPLETO]
					,MOV.[MOV_TIPOPOL]
					,MOV.[MOV_CONSPOL]
					,MOV.[MOV_CONSMOV]
					,MOV.[MOV_MES]
					,MOV.[MOV_NUMCTA]
					,MOV.[MOV_CONCEPTO]
					,MOV.[MOV_DEBE]
					,MOV.[MOV_HABER]
					,MOV.[MOV_ORIGEN]
					,MOV.[MOV_IDCLIENTE]
					,MOV.[MOV_DEPTO]
					,MOV.[MOV_CARTERA]
					,MOV.[MOV_TIPODOCTO]
					,MOV.[MOV_IDDOCTO]
					,MOV.[MOV_FECHVEN]
					,MOV.[MOV_FECHPAG]
					,MOV.[MOV_AGENTE]
					,MOV.[MOV_CVEUSU]
					,MOV.[MOV_FECHOPE]
					,MOV.[MOV_CONCILIADO]
					,MOV.[MOV_FOLIO]
					,MOV.[MOV_FOLIODET]
					,MOV.[MOV_MONEDA]
					,MOV.[MOV_TIPOCAMBIO]
					,MOV.[MOV_HORAOPE]
					,MOV.[MOV_OBSERVA]
					,MOV.[TIPO]
					,MOV.[idUsuario]
					,MOV.[idEmpresa]
					,MOV.[idBanco]
					,MOV.[anio]
					,MOV.[fecha]
					,MOV.[idEstatus]
					,MOV.[idConciliado]
					,MOV.[idHistorico]
				FROM [ABONOS_COMPLETO_CB_H] MOV
				WHERE MOV.MOV_NUMCTA = @cuentaContable 
					  AND MOV.idEmpresa = @idEmpresa 
					  AND MOV.idBanco = @idBanco 
					  AND MOV.idHistorico = @idHistorico
					  AND MOV.MOV_MES = @mes
					  AND MOV.anio = YEAR(@fechaElaboracion)

				UNION ALL

				SELECT 
					 MOV.[IDCARGOS_COMPLETO_H]
					,MOV.[IDCARGOS_COMPLETO]
					,MOV.[MOV_TIPOPOL]
					,MOV.[MOV_CONSPOL]
					,MOV.[MOV_CONSMOV]
					,MOV.[MOV_MES]
					,MOV.[MOV_NUMCTA]
					,MOV.[MOV_CONCEPTO]
					,MOV.[MOV_DEBE]
					,MOV.[MOV_HABER]
					,MOV.[MOV_ORIGEN]
					,MOV.[MOV_IDCLIENTE]
					,MOV.[MOV_DEPTO]
					,MOV.[MOV_CARTERA]
					,MOV.[MOV_TIPODOCTO]
					,MOV.[MOV_IDDOCTO]
					,MOV.[MOV_FECHVEN]
					,MOV.[MOV_FECHPAG]
					,MOV.[MOV_AGENTE]
					,MOV.[MOV_CVEUSU]
					,MOV.[MOV_FECHOPE]
					,MOV.[MOV_CONCILIADO]
					,MOV.[MOV_FOLIO]
					,MOV.[MOV_FOLIODET]
					,MOV.[MOV_MONEDA]
					,MOV.[MOV_TIPOCAMBIO]
					,MOV.[MOV_HORAOPE]
					,MOV.[MOV_OBSERVA]
					,MOV.[Tipo]
					,MOV.[idUsuario]
					,MOV.[idEmpresa]
					,MOV.[idBanco]
					,MOV.[anio]
					,MOV.[fecha]
					,MOV.[idEstatus]
					,MOV.[idConciliado]
					,MOV.[idHistorico]
				FROM [CARGOS_COMPLETO_CB_H] MOV
				WHERE MOV.MOV_NUMCTA = @cuentaContable 
					  AND MOV.idEmpresa = @idEmpresa 
					  AND MOV.idBanco = @idBanco 
					  AND MOV.idHistorico = @idHistorico
					  AND MOV.MOV_MES = @mes
					  AND MOV.anio = YEAR(@fechaElaboracion)

			) CONTABLES;

		END
	END TRY

	BEGIN CATCH
		SELECT MSG = ERROR_MESSAGE();
	END CATCH
END
go

