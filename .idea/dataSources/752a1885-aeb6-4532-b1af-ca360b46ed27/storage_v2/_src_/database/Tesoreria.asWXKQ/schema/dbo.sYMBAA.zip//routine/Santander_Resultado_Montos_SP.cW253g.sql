
-- =============================================
-- Author:		<Author,,Rodrigo olivares>
-- Create date: <Create Date, 2017-11-27>
-- Description:	EXECUTE [dbo].[Santander_Resultado_Montos_SP] '2017-12-01','2017-12-07','1100-0020-0002-0004','65504569012','TREEMI',2,3,1
-- =============================================
CREATE PROCEDURE [dbo].[Santander_Resultado_Montos_SP] 
	-- Add the parameters for the stored procedure here
	-- Add the parameters for the function here
		@fechaElaboracion varchar(30),
		@fechaCorte varchar(30),
		@cuentaContable varchar(50), 
		@noCuenta varchar(50),
		@polizaPago varchar(20),
		@idEmpresa int = 0,
		@idBanco int = 0,
		@tipoconsulta int = 0
AS
BEGIN TRY

DECLARE       @totalAbonoContable decimal(18,2),
			  @totalAbonoContableQuery NVARCHAR(MAX),
			  @totalCargoContableQuery NVARCHAR(MAX),
			  @totalAbonoBancario decimal(18,2),
			  @totalCargoBancario decimal(18,2),
			  @totalCargoContable decimal(18,2),
			  @ParmDefinition nvarchar(500),
              @result_CargoContable varchar(30)

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
--------------------------------------------------------------Obtiene datos de las bases correspondientes según el numero de empresa----------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @ipLocal NVARCHAR(50) = ''
	   ,@ip_catbases NVARCHAR(50) = ''			
	   ,@Base NVARCHAR(50) = ''

SELECT	@ipLocal = dec.local_net_address
FROM	sys.dm_exec_connections AS dec
WHERE	dec.session_id = @@SPID;
------------------------------------------------------------------------------------------------
--Obtiene los datos de la CONCENTRADORA
-- Obtención de Bases de Datos Dinamicos
		SELECT	@ipLocal = dec.local_net_address
		FROM	sys.dm_exec_connections AS dec
		WHERE	dec.session_id = @@SPID;

		SELECT	@ip_catbases = (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN ''
							ELSE ip_servidor 
						END),
				@idEmpresa	= emp_idempresa,
				@Base		= (CASE 
									WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
										THEN '[' + nombre_base + '].[DBO].' 
									ELSE '['+ ip_servidor + '].[' + nombre_base + '].[DBO].' 
								END)
		FROM	[CentralizacionV2].[dbo].[DIG_CAT_BASES_BPRO]
		WHERE	emp_idempresa	= @idEmpresa 
				AND tipo		= 2

------------------------------------------------------------------------Inserta los datos de las referencias bancarias--------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @MesMov INT = MONTH(convert(DATE, convert(date,@fechaCorte), 103))
DECLARE @añoConsulta INT = YEAR(CONVERT(DATE,(CONVERT(DATE,@fechaCorte)),103))
 -----------------------------------------------------------------------Cálculos Cargos Contabilidad Santander------------------------------------------------------------------------
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		
SET @totalCargoContableQuery =          'SELECT @totalCargoContable = ISNULL(SUM(cargo),0)'+ char(13) +
									  + 'FROM AuxiliarContable ' + char(13) +
									  + 'WHERE numeroCuenta = '''+ @cuentaContable +'''' + char(13) + 
									  + 'AND movMes = '+CONVERT(VARCHAR(5), @MesMov )+'' + char(13) +
									  + 'AND abono = 0' + char(13) +
									  + 'AND idEmpresa = '+CONVERT(VARCHAR(5), @idEmpresa )+'' + char(13) +
									  + 'AND movFechaOpe BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''' + char(13)
									  + 'AND idAuxiliarContable not in (' + char(13)
									  + '   SELECT   DISTINCT([idAuxiliarContable]) AS idAuxiliar' + char(13)
									  + '			FROM Tesoreria.dbo.AuxiliarContable aux' + char(13)
									  + '			LEFT JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] catB' + char(13)
									  + '			ON catB.Tipo_Poliza = aux.polTipo' + char(13)
									  + '			LEFT JOIN '+ @Base +'CON_CAR01'+CONVERT(VARCHAR(4),@añoConsulta)+' conCar' + char(13)
									  + '			ON  conCar.CCP_MES = aux.movMes' + char(13)
									  + '			AND conCar.CCP_CONSMOV = aux.movConsMov' + char(13)
									  + '			AND conCar.CCP_CONSPOL = aux.polConsecutivo' + char(13)
									  + '			WHERE aux.numeroCuenta = '''+ @cuentaContable +'''' + char(13)
									  + '			AND aux.movMes = '+CONVERT(VARCHAR(5), @MesMov )+'' + char(13)
									  + '			AND aux.idEmpresa = '+CONVERT(VARCHAR(5), @idEmpresa )+'' + char(13)
									  + '			AND aux.abono = 0' + char(13)
									  + '			AND aux.movFechaOpe  between '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''' + char(13)
									  + '			AND catB.emp_idempresa = '+CONVERT(VARCHAR(5), @idEmpresa )+'' + char(13)
									  + '			AND catB.Tipo_Poliza IS NOT NULL' + char(13)
									  + '			) '
--print(@totalCargoContableQuery)
SET @ParmDefinition = N'@totalCargoContable varchar(50) OUTPUT';

EXECUTE sp_executesql @totalCargoContableQuery, @ParmDefinition, @totalCargoContable = @result_CargoContable OUTPUT;



---------------------------------------------------------------------------Cálculos de Abonos Banco Santander------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SELECT @totalAbonoBancario = 
       (SELECT ISNULL(SUM(importe),0)
	   FROM [dbo].[DepositoBancoView] 
	   WHERE noCuenta = @noCuenta AND esCargo = 0 AND fechaOperacion 
	   BETWEEN @fechaElaboracion AND @fechaCorte
	   AND idBanco = @idBanco
	   AND idBmer NOT IN (SELECT idDepositoBanco
								 FROM [Tesoreria].[dbo].[PunteoAuxiliarBanco]
								 where idBanco = @idBanco
								 AND idempresa = @idEmpresa
						 --UNION
						 --SELECT depositoID 
						 --       FROM Tesoreria.DBO.Referencia ref
							--	INNER JOIN Referencias.dbo.Santander banc
							--	ON ref.depositoID = banc.idSantander 
							--	WHERE banc.noCuenta = @noCuenta
							--	AND banc.fechaMovimiento BETWEEN @fechaElaboracion AND @fechaCorte
							--	AND banc.signo = '-'
							--	AND ref.IDBanco = @idBanco
							--	AND ref.idEmpresa = @idEmpresa  
							--------------------------------------Comentado y pendiente 
						 UNION
						 SELECT idSantander 
						        FROM Referencias.dbo.Santander banc
								INNER JOIN [referencias].[dbo].[RAPDeposito] rapDep 
								ON banc.idSantander = rapDep.idDeposito
								WHERE banc.noCuenta = @noCuenta
								AND banc.fechaMovimiento BETWEEN @fechaElaboracion AND @fechaCorte
								AND banc.signo = '-'
								AND rapDep.idBanco = @idBanco
								AND rapDep.idEmpresa = @idEmpresa 
						 )
		) 
-------------------------------------------------------------------------Consultado con Alejandro Grijalva
-------------------------------------------------------------------------Cálculos de Cargos Banco Santander--------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		SELECT @totalCargoBancario = 
			   (SELECT ISNULL(SUM(importe),0)
			   FROM [dbo].[DepositoBancoView] 
			   WHERE noCuenta = @noCuenta 
			   AND esCargo = 1 
			   AND fechaOperacion BETWEEN @fechaElaboracion AND @fechaCorte
			   AND idBanco = @idBanco
			   AND idBmer NOT IN (SELECT idDepositoBanco
								  FROM [Tesoreria].[dbo].[PunteoAuxiliarBanco]
								  WHERE idBanco = @idBanco
								  AND idEmpresa = @idEmpresa
								  UNION
								  SELECT idBmer 
								         FROM Pagos.dbo.PAG_REL_DOCTOS_BANCOS
								         WHERE idBanco = @idBanco
										 --AND pal_id_empresa = @idEmpresa
										
										 -------------Consultado con FERNANDO LUNA
								  )
			   )
-------------------------------------------------------------Se consulta la información en la tabla de retorno--------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------



-------------------------------------------------------------Cálculo Abonos en Contabilidad Santander (Se consulta la información en la tabla de retorno)-------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
print @totalCargoBancario

SET @totalAbonoContableQuery =         '(SELECT   ISNULL(SUM(abono),0) AS tAbonoContable, '+ CONVERT(varchar(30),@result_CargoContable) +' AS tCargoContable' + char(13) +
									 + ', '+CONVERT(varchar(30), @totalAbonoBancario)+' AS tAbonoBancario, '+ CONVERT(varchar(30), @totalCargoBancario)+' AS tCargoBancario' + char(13) + 
									 + 'FROM AuxiliarContable' + char(13) +  
									 + 'WHERE numeroCuenta = '''+ @cuentaContable +'''' + char(13) + 
									 + 'AND movMes = MONTH(convert(DATE, convert(date,'''+ @fechaCorte +'''), 103))' + char(13) +  
									 + 'AND cargo = 0' + char(13) + 
									 + 'AND idEmpresa = '+CONVERT(VARCHAR(5), @idEmpresa )+'' + char(13) + 
									 + 'AND movFechaOpe BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''' + char(13) + 
									 + 'AND idAuxiliarContable' + char(13) +   
									 + 'NOT IN(' + char(13) + 
									 + 'SELECT idAuxiliarContable ' + char(13) + 
									 + 'FROM AuxiliarContable aux' + char(13) + 
									 + 'INNER JOIN '+ @Base +'CON_CAR01'+CONVERT(VARCHAR(4),@añoConsulta)+' conCar' + char(13) + 
									 + 'ON conCar.CCP_TIPOPOL COLLATE Modern_Spanish_CS_AS = aux.polTipo' + char(13) + 
									 + 'AND conCar.CCP_CONSPOL = aux.polConsecutivo' + char(13) + 
									 + 'AND conCar.CCP_MES = aux.movMes' + char(13) + 
									 + 'INNER JOIN cuentasxpagar.DBO.cxp_doctospagados docP' + char(13) + 
									 + 'ON conCar.CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS = docP.dpa_iddocumento' + char(13) + 
									 + 'WHERE numeroCuenta = '''+ @cuentaContable +''' AND movMes = MONTH(convert(DATE, convert(date,'''+ @fechaCorte +'''), 103))' + char(13) +  
									 + 'AND cargo = 0' + char(13) +    
									 + 'AND movFechaOpe  BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''' + char(13) + 
									 + 'AND conCar.CCP_TIPOPOL = '''+ @polizaPago +'''' + char(13) +  
									 + 'AND conCar.CCP_TIPODOCTO = ''PAGO''' + char(13) + 
									 + 'AND docP.dpa_lote NOT IN (' + char(13) + 
									 + 'SELECT dpa_iddoctopagado 
											 FROM Pagos.dbo.PAG_REL_DOCTOS_BANCOS
											 WHERE idBanco = '+CONVERT(VARCHAR(4),@idBanco)+'
											 AND pal_id_empresa = '+CONVERT(VARCHAR(4),@idEmpresa)+')' +char(13) +
									 
									 +'))'
 
 print(@totalAbonoContableQuery)
EXEC(@totalAbonoContableQuery)
									
END TRY
BEGIN CATCH
     SELECT ERROR_MESSAGE() + ' ' + ERROR_LINE() AS ERROR
END CATCH
go

