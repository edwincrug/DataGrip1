CREATE PROCEDURE [dbo].[SEL_DEPOSITOS_REFERENCIADOS_SP] -- 
/*
	[SEL_DEPOSITOS_REFERENCIADOS_SP] 1,1,'000000000195334667','2018-04-01','2018-04-30',1

*/
@idBanco INT,
@idEstatus INT,
@noCuenta VARCHAR(50),
@fechaElaboracion VARCHAR(30),
@fechaCorte	VARCHAR(30),
@idEmpresa INT

AS	
BEGIN

	DECLARE @Meses TABLE(ID INT IDENTITY(1,1), PAR_IDENPARA VARCHAR(10), PAR_DESCRIP2 VARCHAR(20))
	DECLARE @mesActual INT, @mesActivo INT

	SELECT @mesActual = DATEPART(MONTH,REPLACE(@fechaElaboracion,'-',''))
	INSERT INTO @Meses

	SELECT  PAR_IDENPARA,PAR_DESCRIP2
	FROM GAAU_Concentra.dbo.PNC_PARAMETR
	WHERE PAR_TIPOPARA = 'mcerrcon' 	
	AND PAR_IDENPARA LIKE '' + CONVERT(VARCHAR(10),DATEPART(year,REPLACE(@fechaElaboracion,'-',''))) + '%'
	AND PAR_DESCRIP1 = '01'
	
	
	SELECT @mesActivo = CASE PAR_DESCRIP2
						   WHEN 'ABIERTO' THEN 1
						   WHEN 'CERRADO' THEN 0
						END 
	FROM @Meses WHERE PAR_IDENPARA = CONVERT(VARCHAR(10),DATEPART(year,REPLACE(@fechaElaboracion,'-','')))

	IF(SELECT PAR_DESCRIP2 FROM @Meses WHERE ID = (SELECT ID - 1 FROM @Meses WHERE PAR_IDENPARA = REPLACE(@fechaElaboracion,'-',''))) = 'ABIERTO'
		BEGIN
			SELECT @mesActivo = 0
		END

	IF(@mesActivo = 1)
		BEGIN
			SET @mesActual = 14
		END

IF @idBanco = 1
BEGIN
      --EXECUTE [SEL_DEPOSITOS_REFERENCIADOS_BANCOMER] @idBanco, @idEstatus, @noCuenta, @fechaElaboracion, @fechaCorte, @idEmpresa
	  SET LANGUAGE Español
	  SELECT *, importe abono, 0 cargo, 0 fechaAnterior,'' color, IDBanco idBanco, UPPER(DATENAME(month, CONVERT(DATE,fechaOperacion,103))) MES, anio 
			FROM ABONOSBANCOS_CB WHERE Tipo = 0  --ABONOS
			AND idBmer NOT IN (SELECT idDepositoBanco FROM PunteoAuxiliarBanco)
			AND idBmer NOT IN (SELECT idAbonoBanco FROM DepositoBancarioDPI)
			--AND DATEPART(MONTH,fechaOperacion) > @mesActual
			AND DATEPART(MONTH,fechaOperacion) = @mesActual
	  UNION
	  SELECT *,0 abono, importe cargo, 0 fechaAnterior,'' color, IDBanco idBanco, UPPER(DATENAME(month, CONVERT(DATE,fechaOperacion,103))) MES, anio
			FROM CARGOSBANCOS_CB WHERE Tipo = 0  --CARGOS
			AND idBmer NOT IN (SELECT idDepositoBanco FROM PunteoAuxiliarBanco)
			AND idBmer NOT IN (SELECT idAbonoBanco FROM DepositoBancarioDPI)
			--AND DATEPART(MONTH,fechaOperacion) > @mesActual
			AND DATEPART(MONTH,fechaOperacion) = @mesActual
END
IF @idBanco = 2
BEGIN
      SELECT 'BANCO NO DISPONIBLE' AS ERROR
END
IF @idBanco = 3
BEGIN
      EXECUTE [SEL_DEPOSITOS_REFERENCIADOS_SANTANDER] @idBanco, @idEstatus, @noCuenta, @fechaElaboracion, @fechaCorte, @idEmpresa
END


	 --Selecciono el  último idPunteoAuxiliar para tener un identificador que relacione las conciliaciones Bancarias (CARGO - ABONO)
 SELECT 
		ISNULL(idAuxiliarContable,0)
		AS idRelationOfBancoRows 
        FROM [PunteoAuxiliarBanco]
		WHERE idPAdre = 4
		AND idDepositoBanco = (Select ISNULL(MAX(idDepositoBanco),0)
									 FROM [PunteoAuxiliarBanco]
									 WHERE idPAdre = 4
									       AND idBanco = @idBanco
										   and idEmpresa = @idEmpresa )
		AND idBanco = @idBanco
		AND idEmpresa = @idEmpresa


END
go

