
--EXECUTE [SEL_CARTERA_VENCIDA_SP]    @idCliente = 113 , @idEmpresas = 9,@idSucursales =24, @idDepartamentos = 120, @fechaInicio=NULL,@fechaFin=NULL
CREATE Procedure [dbo].[SEL_CARTERA_VENCIDA_SP]
       @idCliente         int
	  ,@idEmpresas        int
	  ,@idSucursales      int = NULL
	  ,@idDepartamentos   int = NULL
	  ,@fechaInicio       VARCHAR(10)=NULL
	  ,@fechaFin          VARCHAR(10)=NULL
AS
BEGIN
	IF( @idSucursales = 0 )
		BEGIN
			SET @idSucursales = NULL;
		END
	
	EXECUTE [INS_CARTERA_VENCIDA_SP]  @idCliente, @idEmpresas
		
	IF( @fechaInicio IS NULL AND @fechaFin IS NULL )
		BEGIN
			print('Sin fecha');			
			
			SELECT
			  IDB
			 ,folio
			 ,serie
			 ,idDocumento
			 ,CV.idEmpresa
			 ,nombreEmpresa
			 ,CV.idSucursal
			 ,nombreSucursal
			 ,CV.idDepartamento
			 ,nombreDepartamento
			 ,origenMovimiento
			 ,importe
			 ,CASE WHEN importeDocumento IS NULL THEN CONVERT(NUMERIC(18,2),saldo) ELSE (saldo - importeDocumento) END saldo
			 ,nombreCliente
			 ,CONVERT(VARCHAR(20), fecha, 111) fecha
			 ,CV.idCliente
			 ,referencia
			 ,tipoDocumento
			 ,idStatus
			FROM CarteraVencida CV
			LEFT JOIN (SELECT
				SUM(importeDocumento) importeDocumento
			   ,documento
			   ,estatus
			   ,idEmpresa
			  FROM [DetalleReferencia] DET
			  INNER JOIN [Referencia] REF
				ON DET.idReferencia = REF.idReferencia
				where isnull(estatus,0)=0
			  GROUP BY documento
					  ,estatus
					  ,idEmpresa) DRE
			  ON CV.folio = DRE.documento
				AND CV.idEmpresa = DRE.idEmpresa
			WHERE idstatus = 1
			AND CV.idCliente = @idCliente
			AND CV.idEmpresa = @idEmpresas
			AND (@idSucursales IS NULL OR CV.idSucursal = @idSucursales)
			AND (@idDepartamentos IS NULL
			OR CV.idDepartamento = @idDepartamentos)
			--AND (estatus IS NULL) -- 24042020
			AND CONVERT(DECIMAL(18, 5), CV.importe) > 0.0
			and CASE WHEN importeDocumento IS NULL THEN CONVERT(NUMERIC(18,2),saldo) ELSE (saldo - importeDocumento)end >0.0
			ORDER BY CONVERT(VARCHAR(20), fecha, 111)
				-- AND( estatus IS NULL OR estatus = 2 ) -- DEBERIA SER DE ESTA MANERA
		END
	ELSE
		BEGIN
			SET @fechaInicio   = substring(@fechaInicio,7,4) +   substring(@fechaInicio,4,2) + substring(@fechaInicio,1,2) 
			SET @fechaFin   = substring(@fechaFin,7,4) +  substring(@fechaFin,4,2) + substring(@fechaFin,1,2)
			
			SELECT 
				IDB,
				folio,
				serie,
				idDocumento,
				CV.idEmpresa,
				nombreEmpresa,
				CV.idSucursal,
				nombreSucursal,
				CV.idDepartamento,
				nombreDepartamento,
				origenMovimiento,
				importe,
				CASE WHEN importeDocumento IS NULL THEN CONVERT(NUMERIC(18,2),saldo) ELSE (saldo - importeDocumento) END saldo,
				nombreCliente,
				convert (varchar(20), fecha,111)  fecha,
				CV.idCliente,
				referencia,
				tipoDocumento,
				idStatus	
			FROM CarteraVencida CV
			LEFT JOIN (
					SELECT SUM(importeDocumento) importeDocumento, documento, estatus, idEmpresa
					FROM [DetalleReferencia] DET 
					INNER JOIN [Referencia] REF ON DET.idReferencia = REF.idReferencia
					where isnull(estatus,0)=0
					GROUP BY documento, estatus, idEmpresa
			)DRE ON CV.folio = DRE.documento AND CV.idEmpresa = DRE.idEmpresa
			WHERE  	
				idstatus = 1
				AND CV.idCliente = @idCliente
				AND CV.idEmpresa = @idEmpresas
				AND (@idSucursales IS NULL OR CV.idSucursal = @idSucursales)
				AND (@idDepartamentos  IS NULL OR CV.idDepartamento=@idDepartamentos)
				--AND( estatus IS NULL )
				-- AND( estatus IS NULL OR estatus = 2 ) -- DEBERIA SER DE ESTA MANERA
				--AND fecha between @fechaInicio AND @fechaFin
				AND CONVERT(DECIMAL(18,5), CV.importe ) > 0.0
				and CASE WHEN importeDocumento IS NULL THEN CONVERT(NUMERIC(18,2),saldo) ELSE (saldo - importeDocumento)end >0.0
			ORDER BY convert (varchar(20), fecha,111)
		END
END


go

