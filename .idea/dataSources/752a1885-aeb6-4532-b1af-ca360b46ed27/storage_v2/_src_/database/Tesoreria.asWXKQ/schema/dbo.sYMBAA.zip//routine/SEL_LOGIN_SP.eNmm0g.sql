

-- ==========================================================================================
-- Author:	     Lourdes Maldonado Sánchez
-- Create date:  19/01/2017
-- Description:	 Usuario, Perfil
-- ==========================================================================================
--  [SEL_LOGIN_SP] @User='119'
CREATE PROCEDURE [dbo].[SEL_LOGIN_SP] 
 @User  varchar(50)
--,@pass varchar(50)
AS
BEGIN
		
		 SELECT
				 USUARIOS.IdUsuario AS idUsuario
				,PERFILES.IdPerfil AS idPerfil
				,(usu_nombre + ' '+ usu_paterno + ' ' + usu_materno) AS nombreUsuario
				,PERFILES.NombrePerfil AS nombrePerfil
		   FROM [USUARIOS] AS USUARIOS 
				INNER JOIN [REL_USUARIO_PERFIL] ON USUARIOS.IdUsuario = REL_USUARIO_PERFIL.IdUsuario 
				INNER JOIN [PERFILES] ON REL_USUARIO_PERFIL.IdPerfil = PERFILES.IdPerfil
				INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] ON usu_idusuario = USUARIOS.Usuario
		  WHERE (USUARIOS.Usuario = @User)
END


go

