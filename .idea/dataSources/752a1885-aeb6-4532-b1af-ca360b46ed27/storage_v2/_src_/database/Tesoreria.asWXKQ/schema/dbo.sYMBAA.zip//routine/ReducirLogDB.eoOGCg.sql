-- =============================================
-- Description:	Reducir el LOG de la Base de Datos Tesoreria
-- Test:  EXEC [ReducirLogDB]
-- =============================================
CREATE PROCEDURE [dbo].[ReducirLogDB] AS
	BEGIN
		DBCC SQLPERF('LOGSPACE');

		DBCC SHRINKFILE (Tesoreria_log, 1)
		
		ALTER DATABASE Tesoreria
		SET RECOVERY SIMPLE;
		
		DBCC SHRINKFILE (Tesoreria_log, 1)
		
		ALTER DATABASE Tesoreria
		SET RECOVERY FULL
		
		DBCC SQLPERF('LOGSPACE');
	END
go

