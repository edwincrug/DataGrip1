
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 02/08/2017
-- Description:	Se obtienen los depositos referenciados como DPI (Deposito por Identificar)
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_DEPOSITOS_POR_IDENTIFICAR_SP]
    @idBanco INT = 0,
	@noCuenta varchar(50)='',
	@fechaIni varchar(20) = '',
	@fechaFin varchar(20) = ''
AS   
BEGIN
	DECLARE @i int
	DECLARE @PractitionerId int
	DECLARE @numrows int
	DECLARE @idEstatus varchar(18)
	DECLARE @idDPI varchar(18)
	DECLARE @Practitioner TABLE (
		idx smallint Primary Key IDENTITY(1,1),
		idCargoBanco int
	)

	DECLARE @DPI TABLE (
		idx smallint Primary Key IDENTITY(1,1),
		idCargoBanco int
	)


	INSERT @Practitioner SELECT DISTINCT(idCargoBanco) FROM CargoBancarioDPI 

	SET @i = 1
	SET @numrows = (SELECT COUNT(*) FROM @Practitioner)
	IF @numrows > 0
		WHILE (@i <= (SELECT MAX(idx) FROM @Practitioner))
		BEGIN
			SET @PractitionerId = (SELECT idCargoBanco FROM @Practitioner WHERE idx = @i)
			--Do something with Id here
			PRINT @PractitionerId
	        
	        
			SET @idEstatus = (SELECT TOP 1 idEstatus FROM CargoBancarioDPI WHERE idCargoBanco = @PractitionerId ORDER BY fechaRegistro DESC);
			-- SET @idDPI = (SELECT TOP 1 idDPI FROM CargoBancarioDPI WHERE idCargoBanco = @PractitionerId ORDER BY fechaRegistro DESC);
	        
			IF( @idEstatus = 1 )
				BEGIN
					INSERT @DPI SELECT TOP 1 idCargoBanco FROM CargoBancarioDPI WHERE idCargoBanco = @PractitionerId ORDER BY fechaRegistro DESC;
					
					-- SELECT TOP 1 * FROM CargoBancarioDPI WHERE idCargoBanco = @PractitionerId ORDER BY fechaRegistro DESC;
				END

			SET @i = @i + 1
		END	
	
	IF( @fechaIni = '' AND @fechaFin = '')
		BEGIN
			SELECT 
			   idbmer idDepositoBanco
			  ,[idBanco]
			  ,[idBmer]
			  ,'bancomer' banco
			  ,[txtOrigen]
			  ,[noCuenta]
			  ,[concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,[saldoOperativo]
			  ,[referencia]
			  ,convert (varchar(20), [fechaOperacion],103) [fechaOperacion]
			  ,[horaOperacion]
			  ,[oficinaOperadora]
			  ,refAmpliada
			              	
			 FROM [controlDepositosview]
			 WHERE idBmer IN ( SELECT idCargoBanco FROM @DPI )
				   AND idBanco = @idBanco
				   AND noCuenta = @noCuenta 
				   AND esCargo = 4 -- 0 DEFAULT 
			 ORDER BY fechaOperacion,horaOperacion asc
		END
	ELSE
		BEGIN
			SET @fechaIni   = substring(@fechaIni,7,4) +   substring(@fechaIni,4,2) + substring(@fechaIni,1,2) 
			SET @fechaFin   = substring(@fechaFin,7,4) +  substring(@fechaFin,4,2) + substring(@fechaFin,1,2)
			
			SELECT 
			   idbmer idDepositoBanco
			  ,[idBanco]
			  ,[idBmer]
			  ,'bancomer' banco
			  ,[txtOrigen]
			  ,[noCuenta]
			  ,[concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,[saldoOperativo]
			  ,[referencia]
			  ,convert (varchar(20), [fechaOperacion],103) [fechaOperacion]
			  ,[horaOperacion]
			  ,[oficinaOperadora]
			  ,refAmpliada
			              	
			 FROM [controlDepositosview]
			 WHERE idBmer IN ( SELECT idCargoBanco FROM @DPI )
				   AND idBanco = @idBanco  	 
				   AND  fechaOperacion between  @fechaIni and @fechaFin 
				   AND noCuenta = @noCuenta 
				   AND esCargo = 4 -- 0 DEFAULT
			 ORDER BY fechaOperacion,horaOperacion asc
		END
	
END
go

