-- [SEL_PUNTEO_DEPOSITOS_PADRES_SP] 1, '000000000195334667', 1, '2018-04-01', '2018-04-11'
CREATE PROCEDURE [dbo].[SEL_PUNTEO_DEPOSITOS_PADRES_SP]
@idEmpresa INT,
@cuentaBancaria VARCHAR(50) = '',
@idBanco INT,  
@fechaelaboracion VARCHAR(30),
@fechaCorte VARCHAR(30)
AS 
BEGIN
	PRINT '1'	
	SELECT 
			   DISTINCT(PUNTEO.[idDepositoBanco]) AS  idDepositoBanco
 			  ,UPPER(Banco.[nombre]) AS banco --??
			  ,DEPOSITO.[txtOrigen] AS txtOrigen
			  ,DEPOSITO.[noCuenta] AS noCuenta
			  ,DEPOSITO.[concepto] AS concepto
			  ,DEPOSITO.[importe] AS abono
			  ,0 as cargo
			  ,DEPOSITO.[saldoOperativo] AS saldoOperativo
			  ,DEPOSITO.[referencia] AS referencia
			  ,DEPOSITO.[fechaOperacion] AS fechaOperacion
			  ,DEPOSITO.[horaOperacion] AS horaOperacion
			  ,DEPOSITO.[oficinaOperadora] AS oficinaOperadora
			  ,PUNTEO.idPAdre idPAdre--PUNTEO.idPunteoFinalBancos AS idPAdre
			  ,PUNTEO.tipoPunteo AS tipoPunteo
			  ,PUNTEO.idPunteoFinalBancos			  
		FROM ABONOSBANCOS_CB DEPOSITO 
				INNER JOIN [PunteoAuxiliarBanco] PUNTEO ON DEPOSITO.idBmer  = PUNTEO.idDepositoBanco
				INNER JOIN [AuxiliarContable] aux ON PUNTEO.idAuxiliarContable = aux.idAuxiliarContable
				INNER JOIN referencias.dbo.Banco Banco ON DEPOSITO.IDBanco = Banco.idBanco
		WHERE DEPOSITO.idBanco = @idBanco  
			  AND  DEPOSITO.[esCargo] = 0 
		      AND DEPOSITO.noCuenta = @cuentaBancaria
		      AND CONVERT(CHAR(8), PUNTEO.fechaAplicacion, 112) BETWEEN REPLACE(@fechaelaboracion,'-','') --CONVERT(VARCHAR(10),CONVERT(DATETIME,REPLACE(@fechaelaboracion,'-','')),103) 
											AND REPLACE(@fechaCorte,'-','') --CONVERT(VARCHAR(10),CONVERT(DATETIME,REPLACE(@fechaCorte,'-','')),103)
	UNION
	SELECT	
	          DISTINCT(PUNTEO.[idDepositoBanco]) AS  idDepositoBanco
 			  ,UPPER(Banco.[nombre]) AS banco --??
			  ,DEPOSITO.[txtOrigen] AS txtOrigen
			  ,DEPOSITO.[noCuenta] AS noCuenta
			  ,DEPOSITO.[concepto] AS concepto
			  ,0 AS abono
			  ,DEPOSITO.[importe] AS cargo
			  ,DEPOSITO.[saldoOperativo] AS saldoOperativo
			  ,DEPOSITO.[referencia] AS referencia
			  ,DEPOSITO.[fechaOperacion] AS fechaOperacion
			  ,DEPOSITO.[horaOperacion] AS horaOperacion
			  ,DEPOSITO.[oficinaOperadora] AS oficinaOperadora
			  ,PUNTEO.idPAdre idPAdre--PUNTEO.idPunteoFinalBancos AS idPAdre
			  ,PUNTEO.tipoPunteo AS tipoPunteo
			  ,PUNTEO.idPunteoFinalBancos			  
	  FROM CARGOSBANCOS_CB DEPOSITO 
			INNER JOIN [PunteoAuxiliarBanco] PUNTEO ON DEPOSITO.idBmer  = PUNTEO.idDepositoBanco
			INNER JOIN [AuxiliarContable] aux ON PUNTEO.idAuxiliarContable = aux.idAuxiliarContable 
			INNER JOIN referencias.dbo.Banco Banco ON DEPOSITO.IDBanco = Banco.idBanco
	  WHERE DEPOSITO.idBanco = @idBanco  
			--AND  DEPOSITO.[esCargo] = 1 
			AND DEPOSITO.noCuenta = @cuentaBancaria
			AND CONVERT(CHAR(8),PUNTEO.fechaAplicacion, 112)  BETWEEN REPLACE(@fechaelaboracion,'-','')--CONVERT(VARCHAR(10),CONVERT(DATETIME,REPLACE(@fechaelaboracion,'-','')),103) 
											AND REPLACE(@fechaCorte,'-','')--CONVERT(VARCHAR(10),CONVERT(DATETIME,REPLACE(@fechaCorte,'-','')),103)
											PRINT '2'
	/*
	SELECT 
			   DISTINCT(PUNTEO.[idDepositoBanco]) AS  idDepositoBanco
 			  ,DEPOSITO.[banco] AS banco
			  ,DEPOSITO.[txtOrigen] AS txtOrigen
			  ,DEPOSITO.[noCuenta] AS noCuenta
			  ,DEPOSITO.[concepto] AS concepto
			  ,DEPOSITO.[importe] AS abono
			  ,0 as cargo
			  ,DEPOSITO.[saldoOperativo] AS saldoOperativo
			  ,DEPOSITO.[referencia] AS referencia
			  ,DEPOSITO.[fechaOperacion] AS fechaOperacion
			  ,DEPOSITO.[horaOperacion] AS horaOperacion
			  ,DEPOSITO.[oficinaOperadora] AS oficinaOperadora
			  ,PUNTEO.idPunteoFinalBancos AS idPAdre
			  ,PUNTEO.tipoPunteo AS tipoPunteo			  
		FROM [DepositoBancoView] DEPOSITO 
				INNER JOIN [PunteoAuxiliarBanco] PUNTEO ON DEPOSITO.idBmer  = PUNTEO.idDepositoBanco
				INNER JOIN [AuxiliarContable] aux ON PUNTEO.idAuxiliarContable = aux.idAuxiliarContable
		WHERE DEPOSITO.idBanco = @idBanco  
			  AND  DEPOSITO.[esCargo] = 0 
		      AND DEPOSITO.noCuenta = @cuentaBancaria
		      AND DEPOSITO.fechaOperacion BETWEEN @fechaelaboracion AND @fechaCorte
	UNION
	SELECT	
	          DISTINCT(PUNTEO.[idDepositoBanco]) AS  idDepositoBanco
 			  ,DEPOSITO.[banco] AS banco
			  ,DEPOSITO.[txtOrigen] AS txtOrigen
			  ,DEPOSITO.[noCuenta] AS noCuenta
			  ,DEPOSITO.[concepto] AS concepto
			  ,0 AS abono
			  ,DEPOSITO.[importe] AS cargo
			  ,DEPOSITO.[saldoOperativo] AS saldoOperativo
			  ,DEPOSITO.[referencia] AS referencia
			  ,DEPOSITO.[fechaOperacion] AS fechaOperacion
			  ,DEPOSITO.[horaOperacion] AS horaOperacion
			  ,DEPOSITO.[oficinaOperadora] AS oficinaOperadora
			  ,PUNTEO.idPunteoFinalBancos AS idPAdre
			  ,PUNTEO.tipoPunteo AS tipoPunteo			  
	  FROM [DepositoBancoView] DEPOSITO 
			INNER JOIN [PunteoAuxiliarBanco] PUNTEO ON DEPOSITO.idBmer  = PUNTEO.idDepositoBanco
			INNER JOIN [AuxiliarContable] aux ON PUNTEO.idAuxiliarContable = aux.idAuxiliarContable 
	  WHERE DEPOSITO.idBanco = @idBanco  
			AND  DEPOSITO.[esCargo] = 1 
			AND DEPOSITO.noCuenta = @cuentaBancaria
			AND DEPOSITO.fechaOperacion BETWEEN @fechaelaboracion and @fechaCorte
	  */

END



go

