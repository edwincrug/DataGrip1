-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <25/03/2019>
-- Description:	<Elimina el abono bancos>
-- =============================================
CREATE PROCEDURE [dbo].[DEL_AbonosBancos_SP]
	@IDABONOSBANCOS [numeric](18, 0),
	@idUsuario [int] 

AS
BEGIN

UPDATE [dbo].[ABONOSBANCOS_CB]
   SET [idEstatus] = 1
      
 WHERE IDABONOSBANCOS=@IDABONOSBANCOS


INSERT INTO [dbo].[CancelaBANCOS]
           ([IDABONOSBANCOS]
           ,[idUsuario]
           ,[fecha]
		   ,[tipo])
     VALUES
           (@IDABONOSBANCOS
           ,@idUsuario
           ,getdate()
		   ,'A')

	SELECT '1' success
END
go

