-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio 
-- Create date: 2018-07-17
-- Description:	Elimina los registros que fueron cancelados por BPRO y si existe un punteo, lo elimina.
-- =============================================
CREATE PROCEDURE [dbo].[CON_REGISTROSCANCELADOSBPRO_SP]
	@añoConsulta INT			= 0,
	@MesMov INT					= 0,
	@cuentaContable VARCHAR(50) = '',
	@idEmpresa INT				= 0
AS
BEGIN
	DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
		DECLARE @Base VARCHAR(300) = ''
		IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
			BEGIN
				SET @Base = (	SELECT '[' + nombre_base + '].[dbo].[CON_MOVDET01' + CONVERT(VARCHAR(4), YEAR( GETDATE())) + ']' 
									FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
			END
		ELSE
			BEGIN
				SET @Base = (	SELECT '[' + ip_servidor + '].[' + nombre_base + '].[dbo].[CON_MOVDET01' + CONVERT(VARCHAR(4), YEAR( GETDATE())) + ']' 
									FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
			END
	

	DECLARE @TempCONTABLE TABLE(
			IDCOMPLETO NUMERIC(18,0)
		);

	DECLARE @QueryDelPunteo VARCHAR(MAX) = 
	'SELECT 
		ABO.IDABONOS_COMPLETO
	FROM ABONOS_COMPLETO_CB ABO
	INNER JOIN CARGOS_COMPLETO_CB CAR ON	ABO.MOV_CONSPOL = CAR.MOV_CONSPOL 
											AND ABO.MOV_NUMCTA = CAR.MOV_NUMCTA 
											AND ABO.MOV_TIPOPOL = CAR.MOV_TIPOPOL
											AND ABO.MOV_CONSMOV = CAR.MOV_CONSMOV
	LEFT JOIN '+ @Base +' MOV ON ABO.MOV_CONSPOL = MOV.MOV_CONSPOL 
																				AND ABO.MOV_NUMCTA COLLATE SQL_Latin1_General_CP1_CI_AS  = MOV.MOV_NUMCTA 
																				AND ABO.MOV_TIPOPOL COLLATE SQL_Latin1_General_CP1_CI_AS = MOV.MOV_TIPOPOL
																				AND ABO.MOV_CONSMOV = MOV.MOV_CONSMOV
																				AND ABO.MOV_MES = MOV.MOV_MES
	WHERE ABO.MOV_MES = ' + CONVERT(VARCHAR(4),@MesMov)+' AND ABO.MOV_NUMCTA = '''+ @cuentaContable +''' AND ABO.MOV_HABER <> MOV.MOV_HABER AND ABO.idEmpresa = ' + CONVERT(VARCHAR(5),@idEmpresa);

	INSERT INTO @TempCONTABLE
	EXEC (@QueryDelPunteo);

	DELETE FROM REGISTROS_PUNTEADOS WHERE rpun_grupoPunteo IN (
		SELECT rpun_grupoPunteo FROM REGISTROS_PUNTEADOS WHERE rpun_tipo = 'C' AND rpun_idAbono IN (SELECT IDCOMPLETO FROM @TempCONTABLE) AND rpun_idAplicado != 3
	);

	DELETE FROM ABONOS_COMPLETO_CB WHERE IDABONOS_COMPLETO IN ( SELECT IDCOMPLETO FROM @TempCONTABLE );

	DELETE FROM @TempCONTABLE;

	SET @QueryDelPunteo = 
	'SELECT 
		CAR.IDCARGOS_COMPLETO
	FROM ABONOS_COMPLETO_CB ABO
	RIGHT JOIN CARGOS_COMPLETO_CB CAR ON	ABO.MOV_CONSPOL = CAR.MOV_CONSPOL 
											AND ABO.MOV_NUMCTA = CAR.MOV_NUMCTA 
											AND ABO.MOV_TIPOPOL = CAR.MOV_TIPOPOL
											AND ABO.MOV_CONSMOV = CAR.MOV_CONSMOV
	LEFT JOIN '+ @Base +' MOV ON CAR.MOV_CONSPOL = MOV.MOV_CONSPOL 
																				AND CAR.MOV_NUMCTA COLLATE SQL_Latin1_General_CP1_CI_AS  = MOV.MOV_NUMCTA 
																				AND CAR.MOV_TIPOPOL COLLATE SQL_Latin1_General_CP1_CI_AS = MOV.MOV_TIPOPOL
																				AND CAR.MOV_CONSMOV = MOV.MOV_CONSMOV
																				AND CAR.MOV_MES = MOV.MOV_MES
	WHERE ABO.MOV_MES = ' + CONVERT(VARCHAR(4),@MesMov)+' AND ABO.MOV_NUMCTA = '''+ @cuentaContable +''' AND CAR.MOV_HABER <> MOV.MOV_HABER AND ABO.idEmpresa = ' + CONVERT(VARCHAR(5),@idEmpresa);

	INSERT INTO @TempCONTABLE
	EXEC (@QueryDelPunteo);

	DELETE FROM REGISTROS_PUNTEADOS WHERE rpun_grupoPunteo IN (
		SELECT rpun_grupoPunteo FROM REGISTROS_PUNTEADOS WHERE rpun_tipo = 'C' AND rpun_idCargo IN (SELECT IDCOMPLETO FROM @TempCONTABLE) AND rpun_idAplicado != 3
	);

	DELETE FROM CARGOS_COMPLETO_CB WHERE IDCARGOS_COMPLETO IN ( SELECT IDCOMPLETO FROM @TempCONTABLE );
END
go

