-- =============================================
-- Author:		<Author, Rodrigo Olivares>
-- Create date: <Create Date, 2017-12-07>
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[Retorna_Comision_Interes] 
(
	-- Add the parameters for the function here
	@idBanco INT,
	@idEmpresa INT, 
	@noCuenta varchar(50),
	@fechaInicio varchar(30),
	@fechaCorte varchar(30)
)
RETURNS 
@idInteresComision TABLE 
(
	-- Add the column definitions for the TABLE variable here
	idbmer Int 
	
)
AS
BEGIN
	INSERT INTO @idInteresComision (idbmer)
								(
								SELECT idBmer 
									   FROM Tesoreria.dbo.DepositoBancoView banc
									   LEFT JOIN referencias.dbo.CodigoIdentificacion cod
									   ON banc.codigoLeyenda = cod.CodigoBanco
									   WHERE cod.Tipo = 1
									   AND banc.esCargo = 1
									   AND banc.idBanco = @idBanco
									   AND banc.noCuenta = @noCuenta
									   AND fechaOperacion BETWEEN @fechaInicio AND @fechaCorte 
									   )

INSERT INTO @idInteresComision (idbmer)
								(SELECT   idBmer
										 FROM Tesoreria.dbo.DepositoBancoView banc
										 LEFT JOIN [Tesoreria].[dbo].[InteresComision] intC
										 ON banc.idBmer = intC.interesID
										 OR banc.idBmer = intC.comisionID
										 WHERE intC.statusID = 2
										 AND banc.esCargo = 1
										 AND banc.idBanco = @idBanco
										 AND banc.noCuenta = @noCuenta
										 AND fechaOperacion BETWEEN @fechaInicio AND @fechaCorte)
	
	RETURN 
END
go

