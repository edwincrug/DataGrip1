-- [SEL_REFERENCIA_SP] @idEmpresa=2, @idSucursal=1, @idDepartamento=11, @idTipoDocumento=1, @folio='00283',@idCliente = 135,@idTipoReferencia = 4, @importeDocumento = 4382.22 ,@serie='YA'
CREATE PROCEDURE [dbo].[INS_REFERENCIADPI_SP]
	@idEmpresa INT = 0,
	@idSucursal int = 0,
	@idDepartamento	 int = 0,
	@idTipoDocumento INT = 0,
	@serie VARCHAR(20) = '',
	@folio VARCHAR(30) = '',
	@idCliente INT = 0,
	@idAlma NVARCHAR(10) = 0,
	@importeDocumento NUMERIC(18,2) = 0,
	@idTipoReferencia NUMERIC(18,0) = 0,
	@depositoID NUMERIC(18,0) = 0,
	@idBanco NUMERIC(18,0) = 0,
	@importeAplica NUMERIC(18,2) = 0,
	@importeBPRO NUMERIC(18,2) = 0,
	@idusuario int = 0
AS
BEGIN				

	-- SE DECLARAN LAS VARIABLES PARA GUARDAR LOS VALORES ORIGINALES DE SERIE Y FOLIO
	DECLARE @referencia VARCHAR(20) = ''
	DECLARE @serieOriginal VARCHAR(20) = @serie
	DECLARE @folioOriginal VARCHAR(20) = @folio
	DECLARE @idTipoDocOriginal  int = @idTipoDocumento
	DECLARE @idReferencia NUMERIC(18,0)
		-- SE DECLARA LA VARIABLE NUMERO CONSECUTIVO Y SE BUSCA SI YA EXISTE O NO
	DECLARE @numeroConsecutivo VARCHAR(10)
		-- SI EXISTE ALGUN NUMERO CONSECUTIVO DE ALGUNA EMPRESA BUSCA EL NUMERO MAS ALTO Y LE AGREGA UN MAS 1
	IF EXISTS (SELECT numeroConsecutivo FROM [Referencia] WHERE idEmpresa = @idEmpresa) 
		BEGIN
			SET @numeroConsecutivo = (SELECT TOP 1(numeroConsecutivo) FROM [Referencia] WHERE idEmpresa = @idEmpresa ORDER BY numeroConsecutivo DESC) +1
			--SELECT @numeroConsecutivo 
		END
	ELSE
		BEGIN
			SET @numeroConsecutivo = 1
			--SELECT @numeroConsecutivo
		END 

	-- PRIMERO SE COMPRUEBA QUE TIPO DE REFERENCIA ES, SI ES DE TIPO UNO ES IGUAL REFERENCIA INDIVIDUAL
	
		

				
		SELECT @numeroConsecutivo = SUBSTRING(@numeroConsecutivo,LEN(@numeroConsecutivo)-9,10)
		SET @numeroConsecutivo = REPLICATE('0',9-LEN(@numeroConsecutivo)) + CONVERT(VARCHAR(9),@numeroConsecutivo)

		SET @referencia =  [dbo].[referencia_lote_pos](@numeroConsecutivo,@idEmpresa,@idTipoDocumento,@idTipoReferencia) + 
							[dbo].[digito_verificador_fn]( [dbo].[referencia_lote_pos](@numeroConsecutivo,@idEmpresa,@idTipoDocumento,@idTipoReferencia)) 
		INSERT INTO  [dbo].[Referencia] ([idEmpresa],[fecha],[referencia],[tipoReferencia],[numeroConsecutivo],[estatus],[depositoID],[IDBanco],[idusuario])
		VALUES(@idEmpresa, GETDATE(), @referencia,@idTipoReferencia,@numeroConsecutivo,0,@depositoID, @idBanco,@idusuario)
		SET @idReferencia = SCOPE_IDENTITY()
		-- SE INSERTAN LOS DETALLES DE LA REFERENCIA
		INSERT INTO  [dbo].[DetalleReferencia] (idSucursal, idDepartamento, idTipoDocumento, importeDocumento,importeAplicar,importeBPRO, documento, idCliente, idAlmacen, idReferencia) VALUES(@idSucursal,@idDepartamento, @idTipoDocOriginal, @importeDocumento,@importeAplica,@importeBPRO, @serieOriginal+@folioOriginal, @idCliente,@idAlma,@idReferencia)
		SELECT @referencia AS REFERENCIA , 'Nueva Referencia por Lote Pre'	AS ESTATUS, @idReferencia AS idReferencia
			
END



go

