-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[INS_EXCEL_DATA_BANAMEX]
	-- Add the parameters for the stored procedure here
@idBanco INT,
@noCuenta VARCHAR(100),
@fecha VARCHAR(100),
@descipcion VARCHAR(100),
@sucursal numeric(18,0),
@tipoTransaccion varchar(30),
@refNumerica numeric(18,0),
@refAlfanumerica VARCHAR(MAX),
@autorizacion numeric(18,0),
@depositos numeric(18,2),
@retiros numeric(18,2),
@clveLayout VARCHAR(30)


AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [referencias].[dbo].[Banamex_Layout] 
								(idBanco,
								 noCuenta,
								 fecha, 
								 Descripcion, 
								 Sucursal,
								 Tipo_Transaccion, 
								 ReferenciaNumerica, 
								 ReferenciaAlfaNumerica, 
								 Autorizacion, 
								 Depositos, 
								 Retiros)
	                               SELECT
								   @idBanco,
									ISNULL(RTRIM(LTRIM(@noCuenta)),'INDEFINIDO'),
                                    ISNULL(CONVERT(DATE,(RTRIM(LTRIM(@fecha))),103), CONVERT(date,GETDATE(),103)),
	                                ISNULL(RTRIM(LTRIM(@descipcion)), 'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@sucursal)), 0),
									ISNULL(RTRIM(LTRIM(@tipoTransaccion)),'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@refNumerica)), 0),
									ISNULL(RTRIM(LTRIM(@refAlfanumerica)),'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@autorizacion)),0),
									ISNULL(CONVERT(numeric(18,2),RTRIM(LTRIM(@depositos))),0),
									ISNULL(CONVERT(numeric(18,2),RTRIM(LTRIM(@retiros))),0)	        
 
              
			   UPDATE [layout_Historial]
					  SET fecha_Carga_Info = CONVERT(date, GETDATE())
					  WHERE clv_Identificador = @clveLayout 


				SELECT 1 AS SUCCESS 

		
END TRY
BEGIN CATCH
          SELECT ERROR_MESSAGE() AS ERROR
END CATCH



go

