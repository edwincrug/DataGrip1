-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<Inserta el regpunteados cancelados>
-- =============================================
CREATE PROCEDURE [dbo].[RegPunteadosCancelados_INS]
			@rpun_grupoPunteo INT,
			@rpun_usuarioCancela INT,
			@rpun_observacion nvarchar(250)
		   

AS
BEGIN
INSERT INTO [dbo].[REGISTROS_PUNTEADOS_CAN]
           ([rpun_grupoPunteo]
           ,[rpun_idCargo]
           ,[rpun_idAbono]
           ,[rpun_tipo]
           ,[rpun_fechaPunteo]
           ,[rpun_usuario]
           ,[rpun_idAplicado]
           ,[idMes]
           ,[rpun_usuarioCancela]
           ,[rpun_observacion]
           ,[rpun_fechaCancela])
SELECT [rpun_grupoPunteo]
      ,[rpun_idCargo]
      ,[rpun_idAbono]
      ,[rpun_tipo]
      ,[rpun_fechaPunteo]
      ,[rpun_usuario]
      ,[rpun_idAplicado]
      ,[idMes]
	  ,@rpun_usuarioCancela
	  ,@rpun_observacion
	  ,getdate()
  FROM [dbo].[REGISTROS_PUNTEADOS]
  where [rpun_grupoPunteo]=@rpun_grupoPunteo
  
  delete
  FROM [dbo].[REGISTROS_PUNTEADOS]
  where [rpun_grupoPunteo]=@rpun_grupoPunteo

  SELECT 'Se borro el registro con éxito.' AS msg,1 success
END
go

