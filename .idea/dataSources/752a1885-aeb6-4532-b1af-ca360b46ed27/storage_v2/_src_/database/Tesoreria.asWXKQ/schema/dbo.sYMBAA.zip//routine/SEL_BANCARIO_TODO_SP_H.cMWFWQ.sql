-- =============================================
-- Author:		Ing. Luis Antonio García Perrusquía
-- Create date: 27/04/2018
-- Description:	Trae todos los datos del historico de universo movimiento bancario
-- TEST EXECUTE [dbo].[SEL_BANCARIO_TODO_SP_H] 1, 71, 19225, '000000000195334667', '1100-0020-0001-0001', '2019-10-01', 'TREEUN', 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_BANCARIO_TODO_SP_H]
	@idEmpresa INT,
	@idUsuario INT,
	@idHistorico INT,
	@noCuenta VARCHAR (250),
	@cuentaContable VARCHAR (250),
	@fechaElaboracion VARCHAR(50),
	@polizaPago VARCHAR (250),
	@idBanco INT
AS
BEGIN
	BEGIN TRY
		SELECT
			uniBan.[IDCARGOSBANCOS]
			,uniBan.[idBmer]
			,uniBan.[IDBanco]
			,uniBan.[txtOrigen]
			,uniBan.[registro]
			,uniBan.[noMovimiento]
			,uniBan.[referencia]
			,uniBan.[concepto]
			,uniBan.[refAmpliada]
			,uniBan.[esCargo]
			,uniBan.[importe]
			,uniBan.[saldoOperativo]
			,uniBan.[codigoLeyenda]
			,uniBan.[oficinaOperadora]
			,uniBan.[fechaOperacion]
			,uniBan.[horaOperacion]
			,uniBan.[fechaValor]
			,uniBan.[fechaContable]
			,uniBan.[estatus]
			,uniBan.[noCuenta]
			,uniBan.[estatusRevision]
			,uniBan.[Tipo]
			,uniBan.[idUsuario]
			,uniBan.[idEmpresa]
			,uniBan.[anio]
			,uniBan.[fecha]
			,uniBan.[idEstatus]
			,uniBan.[idConciliado],
			CASE WHEN uniBan.esCargo = 1 THEN 1 ELSE 0 END tipoMovimiento,
			CASE WHEN uniBan.esCargo = 1 THEN uniBan.importe ELSE 0 END cargo,
			CASE WHEN uniBan.esCargo = 0 THEN uniBan.importe ELSE 0 END abono
		FROM(
			SELECT 
				   CAR.[IDCARGOSBANCOS]
				  ,CAR.[idBmer]
				  ,CAR.[IDBanco]
				  ,CAR.[txtOrigen]
				  ,CAR.[registro]
				  ,CAR.[noMovimiento]
				  ,CAR.[referencia]
				  ,CAR.[concepto]
				  ,CAR.[refAmpliada]
				  ,CAR.[esCargo]
				  ,CAR.[importe]
				  ,CAR.[saldoOperativo]
				  ,CAR.[codigoLeyenda]
				  ,CAR.[oficinaOperadora]
				  ,CAR.[fechaOperacion]
				  ,CAR.[horaOperacion]
				  ,CAR.[fechaValor]
				  ,CAR.[fechaContable]
				  ,CAR.[estatus]
				  ,CAR.[noCuenta]
				  ,CAR.[estatusRevision]
				  ,CAR.[Tipo]
				  ,CAR.[idUsuario]
				  ,CAR.[idEmpresa]
				  ,CAR.[anio]
				  ,CAR.[fecha]
				  ,CAR.[idEstatus]
				  ,CAR.[idConciliado]
			FROM CARGOSBANCOS_CB_H CAR
			WHERE noCuenta = @noCuenta 
				  AND idEmpresa = @idEmpresa 
				  AND IDBanco = @idBanco 
				  AND idHistorico = @idHistorico
				  AND CAR.idEstatus=0
				  and MONTH(fechaoperacion) = month(convert(date,@fechaElaboracion,23))
				 and  car.anio=year(convert(date,@fechaElaboracion,23))

	UNION ALL

			SELECT 
				   ABO.[IDABONOSBANCOS]
				  ,ABO.[idBmer]
				  ,ABO.[IDBanco]
				  ,ABO.[txtOrigen]
				  ,ABO.[registro]
				  ,ABO.[noMovimiento]
				  ,ABO.[referencia]
				  ,ABO.[concepto]
				  ,ABO.[refAmpliada]
				  ,ABO.[esCargo]
				  ,ABO.[importe]
				  ,ABO.[saldoOperativo]
				  ,ABO.[codigoLeyenda]
				  ,ABO.[oficinaOperadora]
				  ,ABO.[fechaOperacion]
				  ,ABO.[horaOperacion]
				  ,ABO.[fechaValor]
				  ,ABO.[fechaContable]
				  ,ABO.[estatus]
				  ,ABO.[noCuenta]
				  ,ABO.[estatusRevision]
				  ,ABO.[Tipo]
				  ,ABO.[idUsuario]
				  ,ABO.[idEmpresa]
				  ,ABO.[anio]
				  ,ABO.[fecha]
				  ,ABO.[idEstatus]
				  ,ABO.[idConciliado]
			FROM ABONOSBANCOS_CB_H ABO
			WHERE noCuenta = @noCuenta 
				  AND idEmpresa = @idEmpresa 
				  AND IDBanco = @idBanco 
				  AND idHistorico = @idHistorico
				  AND ABO.idEstatus=0
				  and MONTH(fechaoperacion) = month(convert(date,@fechaElaboracion,23))
				  and  ABO.anio=year(convert(date,@fechaElaboracion,23))
				 ) AS uniBan	
	END TRY

	BEGIN CATCH
		SELECT MSG = ERROR_MESSAGE();
	END CATCH
END
go

