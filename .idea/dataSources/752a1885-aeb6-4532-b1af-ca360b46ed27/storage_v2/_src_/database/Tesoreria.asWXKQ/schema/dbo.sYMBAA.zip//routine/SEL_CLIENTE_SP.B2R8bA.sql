
-- =============================================
-- Author:      
-- Create date: 21/07/2016
-- Description: Busqueda de clientes dada una cadena
-- =============================================
-- [SEL_CLIENTE_ID_SP] busqueda por IdCliente
-- [SEL_CLIENTE_SP] busqueda por nombre 
--EXECUTE [SEL_CLIENTE_SP] 'roca'     'HEHJ520304R36'  --'javier.hernandezr@grupoandrade.com.mx' --'JAVIER HERNANDEZ'
CREATE PROCEDURE [dbo].[SEL_CLIENTE_SP] 
    @varBusqueda  varchar(150) = null
AS
BEGIN
    SET NOCOUNT ON;
        SELECT distinct C.[per_idpersona]    AS idCliente
              ,C.[per_rfc]          AS rfc 
              ,C.[per_paterno]      AS paterno
              ,C.[per_materno]      AS materno
              ,RTRIM(LTRIM(C.[per_nomrazon]  + ' ' + C.[per_paterno] + ' ' + C.[per_materno])) AS nombre
              ,RTRIM(LTRIM(C.[per_nomrazon]  + ' ' + C.[per_paterno] + ' ' + C.[per_materno])) AS nombreCliente  --Contrato
              ,C.[per_curp]         AS curp
              ,c.PER_CALLE1        AS calle
              ,c.PER_NUMEXTER    AS numero
              ,c.PER_COLONIA     AS colonia
              ,c.PER_DELEGAC     AS delegacion
              ,c.PER_CODPOS AS codigoPostal
              ,c.per_email    AS email
              , 55555555  AS telefono
              ,C.PER_STATUS      AS estatus
              , 55555555  AS telefonoCelular
          FROM GA_Corporativa.[dbo].PER_PERSONAS AS C
              
         WHERE --C.[per_idpersona] = CAST(@varBusqueda AS INT) OR
               RTRIM(LTRIM(C.[per_nomrazon]  + ' ' + C.[per_paterno] + ' ' + C.[per_Materno])) LIKE '%'+ @varBusqueda +'%'
            OR C.[per_idpersona] like '%' + @varBusqueda + '%'
            OR C.[per_rfc] like '%' + @varBusqueda + '%'
            OR c.per_email like '%' + @varBusqueda + '%'
             
END



go

