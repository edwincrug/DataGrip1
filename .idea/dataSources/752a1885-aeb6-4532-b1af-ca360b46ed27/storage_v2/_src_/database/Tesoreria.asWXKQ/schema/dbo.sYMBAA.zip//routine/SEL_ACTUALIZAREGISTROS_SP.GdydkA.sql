-- ==========================================================================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 27/Septiembre/2018
-- Description:	B
-- EXECUTE dbo.[SEL_ACTUALIZAREGISTROS_SP] 1,1,'000000000195334667','1100-0020-0001-0001','2018-09-01','2018-09-30','',2,71,0
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_ACTUALIZAREGISTROS_SP]
	@idEmpresa VARCHAR(50)			= 0,
	@idBanco INT					= 0,
	@noCuenta VARCHAR(50)			= '',
	@cuentaContable VARCHAR(50)		= '',	
	@fechaElaboracion VARCHAR(50)	= '',
	@fechaCorte VARCHAR(50)			= '',
	@polizaPago VARCHAR(20)			= '',
	@opcion INT						= 0,
	@idUsuario INT					= 0,
	@idHistorico NUMERIC(18,0)		= 0
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;

		-- // 0 -> Disabled, 1 -> Modo Debug
		DECLARE @DEBUG INT = 0;

		-- Variables bases dinamicas
		DECLARE @ipLocal NVARCHAR(50)		= '',
				@ip_catbases NVARCHAR(50)	= '',
				@Base NVARCHAR(50)			= '';
		
		-- Variables generales
		DECLARE @saldoBanco NUMERIC(18,6)			= 0,
				@totalAbonoContable NUMERIC(18,6)	= 0,
				@totalCargoContable NUMERIC(18,6)	= 0,
				@totalAbonoBancario NUMERIC(18,6)	= 0,
				@totalCargoBancario NUMERIC(18,6)	= 1,
				@SaldoInicial NUMERIC(18,6)			= 0,
				@saldoConciliacion NUMERIC(18,6)	= 0,
				@saldoContabilidad NUMERIC(18,6)	= 0,
				@diferencia NUMERIC(18,6)			= 0,
				@mesActivo INT						= 0;

		-- Obtención de Bases de Datos Dinamicos
		SELECT	@ipLocal = dec.local_net_address
		FROM	sys.dm_exec_connections AS dec
		WHERE	dec.session_id = @@SPID;

		SELECT	@ip_catbases = (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN ''
							ELSE ip_servidor 
						END),
				@idEmpresa	= emp_idempresa,
				@Base		= (CASE 
									WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
										THEN '[' + nombre_base + '].[DBO].' 
									ELSE '['+ ip_servidor + '].[' + nombre_base + '].[DBO].' 
								END)
		FROM	[CentralizacionV2].[dbo].[DIG_CAT_BASES_BPRO]
		WHERE	emp_idempresa	= @idEmpresa 
				AND tipo		= 2


		DECLARE @añoConsulta INT			= YEAR(CONVERT(DATE,(CONVERT(DATE,REPLACE(@fechaCorte,'-',''))),103));
		DECLARE @primerDiaMesConsulta DATE	= DATEADD(MM, DATEDIFF(MM,0,CONVERT(DATE,REPLACE(@fechaCorte,'-',''))), 0);
		
		-- Variables que se ocupan en los 3 IF's
		DECLARE @mes INT				= MONTH(REPLACE(@fechaElaboracion,'-',''));
		DECLARE @MesMov INT				= MONTH(convert(DATE, convert(date,REPLACE(@fechaCorte,'-','')), 103));
		DECLARE @query VARCHAR(MAX)		= '';
		DECLARE @numCuenta2 VARCHAR(50) = '';
		DECLARE @query2 VARCHAR(MAX)	= '';


			
		SET @query =  
		'SELECT  
		   NUEVOS.[MOV_TIPOPOL]
		  ,NUEVOS.[MOV_CONSPOL]
		  ,NUEVOS.[MOV_CONSMOV]
		  ,NUEVOS.[MOV_MES]
		  ,NUEVOS.[MOV_NUMCTA]
		  ,NUEVOS.[MOV_CONCEPTO]
		  ,NUEVOS.[MOV_DEBE]
		  ,NUEVOS.[MOV_HABER]
		  ,NUEVOS.[MOV_ORIGEN]
		  ,NUEVOS.[MOV_IDCLIENTE]
		  ,NUEVOS.[MOV_DEPTO]
		  ,NUEVOS.[MOV_CARTERA]
		  ,NUEVOS.[MOV_TIPODOCTO]
		  ,NUEVOS.[MOV_IDDOCTO]
		  ,NUEVOS.[MOV_FECHVEN]
		  ,NUEVOS.[MOV_FECHPAG]
		  ,NUEVOS.[MOV_AGENTE]
		  ,NUEVOS.[MOV_CVEUSU]
		  ,NUEVOS.[MOV_FECHOPE]
		  ,NUEVOS.[MOV_CONCILIADO]
		  ,NUEVOS.[MOV_FOLIO]
		  ,NUEVOS.[MOV_FOLIODET]
		  ,NUEVOS.[MOV_MONEDA]
		  ,NUEVOS.[MOV_TIPOCAMBIO]
		  ,NUEVOS.[MOV_HORAOPE]
		  ,NUEVOS.[MOV_OBSERVA]
		  ,NUEVOS.TIPO		 
		  ,NUEVOS.idUsuario	 
		  ,NUEVOS.idEmpresa	 
		  ,NUEVOS.idBanco		 
		  ,NUEVOS.anio		 
		  ,NUEVOS.fecha		 
		  ,NUEVOS.idEstatus	 
		  ,NUEVOS.idConciliado
		FROM 
			(SELECT CON.[MOV_TIPOPOL],
				CON.[MOV_CONSPOL],
				CON.[MOV_CONSMOV],
				CON.[MOV_MES],
				CON.[MOV_NUMCTA],
				CON.[MOV_CONCEPTO],
				CON.[MOV_DEBE],
				CON.[MOV_HABER],
				CON.[MOV_ORIGEN],
				CON.[MOV_IDCLIENTE],
				CON.[MOV_DEPTO],
				CON.[MOV_CARTERA],
				CON.[MOV_TIPODOCTO],
				CON.[MOV_IDDOCTO],
				CON.[MOV_FECHVEN],
				CON.[MOV_FECHPAG],
				CON.[MOV_AGENTE],
				CON.[MOV_CVEUSU],
				CON.[MOV_FECHOPE],
				CON.[MOV_CONCILIADO],
				CON.[MOV_FOLIO],
				CON.[MOV_FOLIODET],
				CON.[MOV_MONEDA],
				CON.[MOV_TIPOCAMBIO],
				CON.[MOV_HORAOPE],
				CON.[MOV_OBSERVA],
				TIPO		 = 0, 
				idUsuario	 = ' + CONVERT(VARCHAR(4),@idUsuario)+ ',
				idEmpresa	 = ' + CONVERT(VARCHAR(5),@idEmpresa) + ',
				idBanco		 = ' + CONVERT(VARCHAR(4),@idBanco) + ',
				anio		 = ' + CONVERT(VARCHAR(4),@añoConsulta) + ',
				fecha		 = GETDATE(),
				idEstatus	 = 0,
				idConciliado = 0 
			FROM '+ @Base +'CON_MOVDET01' + CONVERT(VARCHAR(4),@añoConsulta)+' CON
			WHERE CON.MOV_HABER <> 0 AND CON.MOV_MES = ' + CONVERT(VARCHAR(4),@MesMov)+'
			AND CON.MOV_NUMCTA = '''+ @cuentaContable +'''
		) NUEVOS
		LEFT JOIN (
			SELECT
				   [IDABONOS_COMPLETO]
				  ,[MOV_TIPOPOL]
				  ,[MOV_CONSPOL]
				  ,[MOV_CONSMOV]
				  ,[MOV_MES]
				  ,[MOV_NUMCTA]
				  ,[MOV_CONCEPTO]
				  ,[MOV_DEBE]
				  ,[MOV_HABER]
				  ,[MOV_ORIGEN]
				  ,[MOV_IDCLIENTE]
				  ,[MOV_DEPTO]
				  ,[MOV_CARTERA]
				  ,[MOV_TIPODOCTO]
				  ,[MOV_IDDOCTO]
				  ,[MOV_FECHVEN]
				  ,[MOV_FECHPAG]
				  ,[MOV_AGENTE]
				  ,[MOV_CVEUSU]
				  ,[MOV_FECHOPE]
				  ,[MOV_CONCILIADO]
				  ,[MOV_FOLIO]
				  ,[MOV_FOLIODET]
				  ,[MOV_MONEDA]
				  ,[MOV_TIPOCAMBIO]
				  ,[MOV_HORAOPE]
				  ,[MOV_OBSERVA]
				  ,[TIPO]
				  ,[idUsuario]
				  ,[idEmpresa]
				  ,[idBanco]
				  ,[anio]
				  ,[fecha]
				  ,[idEstatus]
				  ,[idConciliado]
			FROM ABONOS_COMPLETO_CB CON
			WHERE CON.MOV_HABER <> 0 AND CON.MOV_MES = ' + CONVERT(VARCHAR(4),@MesMov)+'
					AND CON.MOV_NUMCTA = '''+ @cuentaContable +'''
					AND CON.idEmpresa = ' + CONVERT(VARCHAR(5),@idEmpresa) + '
		) OPE ON	NUEVOS.MOV_CONSPOL		= OPE.MOV_CONSPOL 
					AND NUEVOS.MOV_CONSMOV	= OPE.MOV_CONSMOV 
					AND NUEVOS.MOV_MES		= OPE.MOV_MES 
					AND NUEVOS.MOV_TIPOPOL COLLATE SQL_Latin1_General_CP1_CI_AS = OPE.MOV_TIPOPOL
		WHERE OPE.IDABONOS_COMPLETO IS NULL';
		
				
		INSERT INTO ABONOS_COMPLETO_CB
		EXEC (@query);
				
		-- MODO DEBUG
		-- MODO DEBUG
		-- MODO DEBUG
		IF( @DEBUG = 1 )
			BEGIN
				PRINT('=> ABONOS_COMPLETO_CB')
				PRINT (@query);
			END
		--//
		
		-- CARGOS_COMPLETO_CB
		-- CARGOS_COMPLETO_CB
		-- CARGOS_COMPLETO_CB
		
		SET @query = 
		'SELECT  NUEVOS.[MOV_TIPOPOL]
		  ,NUEVOS.[MOV_CONSPOL]
		  ,NUEVOS.[MOV_CONSMOV]
		  ,NUEVOS.[MOV_MES]
		  ,NUEVOS.[MOV_NUMCTA]
		  ,NUEVOS.[MOV_CONCEPTO]
		  ,NUEVOS.[MOV_DEBE]
		  ,NUEVOS.[MOV_HABER]
		  ,NUEVOS.[MOV_ORIGEN]
		  ,NUEVOS.[MOV_IDCLIENTE]
		  ,NUEVOS.[MOV_DEPTO]
		  ,NUEVOS.[MOV_CARTERA]
		  ,NUEVOS.[MOV_TIPODOCTO]
		  ,NUEVOS.[MOV_IDDOCTO]
		  ,NUEVOS.[MOV_FECHVEN]
		  ,NUEVOS.[MOV_FECHPAG]
		  ,NUEVOS.[MOV_AGENTE]
		  ,NUEVOS.[MOV_CVEUSU]
		  ,NUEVOS.[MOV_FECHOPE]
		  ,NUEVOS.[MOV_CONCILIADO]
		  ,NUEVOS.[MOV_FOLIO]
		  ,NUEVOS.[MOV_FOLIODET]
		  ,NUEVOS.[MOV_MONEDA]
		  ,NUEVOS.[MOV_TIPOCAMBIO]
		  ,NUEVOS.[MOV_HORAOPE]
		  ,NUEVOS.[MOV_OBSERVA]
		  ,NUEVOS.TIPO		 
		  ,NUEVOS.idUsuario	 
		  ,NUEVOS.idEmpresa	 
		  ,NUEVOS.idBanco		 
		  ,NUEVOS.anio		 
		  ,NUEVOS.fecha		 
		  ,NUEVOS.idEstatus	 
		  ,NUEVOS.idConciliado 
		   FROM 
			(SELECT CON.[MOV_TIPOPOL],
				CON.[MOV_CONSPOL],
				CON.[MOV_CONSMOV],
				CON.[MOV_MES],
				CON.[MOV_NUMCTA],
				CON.[MOV_CONCEPTO],
				CON.[MOV_DEBE],
				CON.[MOV_HABER],
				CON.[MOV_ORIGEN],
				CON.[MOV_IDCLIENTE],
				CON.[MOV_DEPTO],
				CON.[MOV_CARTERA],
				CON.[MOV_TIPODOCTO],
				CON.[MOV_IDDOCTO],
				CON.[MOV_FECHVEN],
				CON.[MOV_FECHPAG],
				CON.[MOV_AGENTE],
				CON.[MOV_CVEUSU],
				CON.[MOV_FECHOPE],
				CON.[MOV_CONCILIADO],
				CON.[MOV_FOLIO],
				CON.[MOV_FOLIODET],
				CON.[MOV_MONEDA],
				CON.[MOV_TIPOCAMBIO],
				CON.[MOV_HORAOPE],
				CON.[MOV_OBSERVA],
				TIPO		 = 0, 
				idUsuario	 = ' + CONVERT(VARCHAR(4),@idUsuario)+ ',
				idEmpresa	 = ' + CONVERT(VARCHAR(5),@idEmpresa) + ',
				idBanco		 = ' + CONVERT(VARCHAR(4),@idBanco) + ',
				anio		 = ' + CONVERT(VARCHAR(4),@añoConsulta) + ',
				fecha		 = GETDATE(),
				idEstatus	 = 0,
				idConciliado = 0 
			FROM '+ @Base +'CON_MOVDET01' + CONVERT(VARCHAR(4),@añoConsulta)+' CON 
			WHERE CON.MOV_DEBE <> 0 AND CON.MOV_MES = ' + CONVERT(VARCHAR(4),@MesMov)+'
			AND CON.MOV_NUMCTA = '''+ @cuentaContable +'''
		) NUEVOS
		LEFT JOIN (
			SELECT
				[IDCARGOS_COMPLETO]
				  ,[MOV_TIPOPOL]
				  ,[MOV_CONSPOL]
				  ,[MOV_CONSMOV]
				  ,[MOV_MES]
				  ,[MOV_NUMCTA]
				  ,[MOV_CONCEPTO]
				  ,[MOV_DEBE]
				  ,[MOV_HABER]
				  ,[MOV_ORIGEN]
				  ,[MOV_IDCLIENTE]
				  ,[MOV_DEPTO]
				  ,[MOV_CARTERA]
				  ,[MOV_TIPODOCTO]
				  ,[MOV_IDDOCTO]
				  ,[MOV_FECHVEN]
				  ,[MOV_FECHPAG]
				  ,[MOV_AGENTE]
				  ,[MOV_CVEUSU]
				  ,[MOV_FECHOPE]
				  ,[MOV_CONCILIADO]
				  ,[MOV_FOLIO]
				  ,[MOV_FOLIODET]
				  ,[MOV_MONEDA]
				  ,[MOV_TIPOCAMBIO]
				  ,[MOV_HORAOPE]
				  ,[MOV_OBSERVA]
				  ,[Tipo]
				  ,[idUsuario]
				  ,[idEmpresa]
				  ,[idBanco]
				  ,[anio]
				  ,[fecha]
				  ,[idEstatus]
				  ,[idConciliado] 
			FROM CARGOS_COMPLETO_CB CON
			WHERE CON.MOV_DEBE <> 0 AND CON.MOV_MES = ' + CONVERT(VARCHAR(4),@MesMov)+'
					AND CON.MOV_NUMCTA = '''+ @cuentaContable +'''
					AND CON.idEmpresa = ' + CONVERT(VARCHAR(5),@idEmpresa) + '
		) OPE ON NUEVOS.MOV_CONSPOL = OPE.MOV_CONSPOL AND NUEVOS.MOV_CONSMOV = OPE.MOV_CONSMOV AND NUEVOS.MOV_MES = OPE.MOV_MES AND NUEVOS.MOV_TIPOPOL COLLATE SQL_Latin1_General_CP1_CI_AS = OPE.MOV_TIPOPOL
		WHERE OPE.IDCARGOS_COMPLETO IS NULL'			
				
		INSERT INTO CARGOS_COMPLETO_CB 
		EXEC (@query);
		
		-- MODO DEBUG
		-- MODO DEBUG
		-- MODO DEBUG
		IF( @DEBUG = 1 )
			BEGIN
				PRINT('=> CARGOS_COMPLETO_CB')
				PRINT (@query);
			END
		--//

		-- Elima los regitros cancelados en BPRO junto con el punteo que se haya generado
			--EXEC [dbo].[CON_REGISTROSCANCELADOSBPRO_SP] @añoConsulta, @MesMov, @cuentaContable, @idEmpresa

		-- CARGOS Y ABONOS BANCARIOS
		-- CARGOS Y ABONOS BANCARIOS
		-- CARGOS Y ABONOS BANCARIOS
		IF (@idBanco = 1)
			BEGIN 
				PRINT 'Bancomer'
				-- ABONOS BANCOS
				SELECT BAN.[idbmer], 
				   BAN.[idbanco], 
				   BAN.[txtorigen], 
				   BAN.[registro], 
				   BAN.[nomovimiento], 
				   BAN.[referencia], 
				   BAN.[concepto], 
				   BAN.[refampliada], 
				   BAN.[escargo], 
				   BAN.[importe], 
				   BAN.[saldooperativo], 
				   BAN.[codigoleyenda], 
				   BAN.[oficinaoperadora], 
				   BAN.[fechaoperacion], 
				   BAN.[horaoperacion], 
				   BAN.[fechavalor], 
				   BAN.[fechacontable], 
				   BAN.[estatus], 
				   BAN.[nocuenta], 
				   BAN.[estatusrevision], 
				   [Tipo]				= 0,
				   [idUsuario]			= @idUsuario,
				   [idEmpresa]			= @idEmpresa,
				   [anio]				= @añoConsulta,
				   [fecha]				= GETDATE(),
				   [idEstatus]			= 0,
				   [idConciliado]		= 0
				INTO #ABONOSBANCOSBAN_TMP
				FROM
					   referencias.dbo.bancomer BAN 
				INNER JOIN 
					Referencias.dbo.BancoCuenta CTA ON BAN.noCuenta= CTA.numeroCuenta
				WHERE
					BAN.escargo = 0 
					AND CTA.numeroCuenta = @noCuenta
					AND CTA.idEmpresa	 = @idEmpresa
					AND CTA.idBanco		 = 1
					AND fechaoperacion BETWEEN @fechaElaboracion AND @fechaCorte;
	

				INSERT INTO ABONOSBANCOS_CB
				SELECT TMP.* 
				FROM #ABONOSBANCOSBAN_TMP TMP
				LEFT JOIN  [ABONOSBANCOS_CB] OPE ON TMP.idBmer = OPE.idBmer AND TMP.idbanco = OPE.IDBanco
				WHERE OPE.idBmer IS NULL;

				-- CARGOS BANCOS
				SELECT BAN.[idbmer], 
				   BAN.[idbanco], 
				   BAN.[txtorigen], 
				   BAN.[registro], 
				   BAN.[nomovimiento], 
				   BAN.[referencia], 
				   BAN.[concepto], 
				   BAN.[refampliada], 
				   BAN.[escargo], 
				   BAN.[importe], 
				   BAN.[saldooperativo], 
				   BAN.[codigoleyenda], 
				   BAN.[oficinaoperadora], 
				   BAN.[fechaoperacion], 
				   BAN.[horaoperacion], 
				   BAN.[fechavalor], 
				   BAN.[fechacontable], 
				   BAN.[estatus], 
				   BAN.[nocuenta], 
				   BAN.[estatusrevision], 
				   [Tipo]				= 0,
				   [idUsuario]			= @idUsuario,
				   [idEmpresa]			= @idEmpresa,
				   [anio]				= @añoConsulta,
				   [fecha]				= GETDATE(),
				   [idEstatus]			= 0,
				   [idConciliado]		= 0
				INTO #CARGOSBANCOSBAN_TMP
				FROM
					   referencias.dbo.bancomer BAN 
				INNER JOIN 
					Referencias.dbo.BancoCuenta CTA ON BAN.noCuenta= CTA.numeroCuenta
				WHERE
					BAN.escargo = 1 
					AND CTA.numeroCuenta = @noCuenta
					AND CTA.idEmpresa	 = @idEmpresa
					AND CTA.idBanco		 = 1
					AND fechaoperacion BETWEEN @fechaElaboracion AND @fechaCorte
	
				
				INSERT INTO CARGOSBANCOS_CB
				SELECT TMP.* FROM #CARGOSBANCOSBAN_TMP TMP
				LEFT JOIN  [CARGOSBANCOS_CB] OPE ON TMP.idBmer = OPE.idBmer AND TMP.idbanco = OPE.IDBanco
				WHERE OPE.idBmer IS NULL;

				DROP TABLE #CARGOSBANCOSBAN_TMP;
				DROP TABLE #ABONOSBANCOSBAN_TMP;

			PRINT 'END Bancomer'
		END
  
	ELSE IF( @idBanco = 2 ) -- Corresponde a BANAMEX
		BEGIN
			PRINT 'Banamex'
			-- ABONOS BANCOS
				SELECT BAN.[idbmer], 
				   BAN.[idbanco], 
				   BAN.[txtorigen], 
				   BAN.[registro], 
				   BAN.[nomovimiento], 
				   BAN.[referencia], 
				   BAN.[concepto], 
				   BAN.[refampliada], 
				   BAN.[escargo], 
				   BAN.[importe], 
				   BAN.[saldooperativo], 
				   BAN.[codigoleyenda], 
				   BAN.[oficinaoperadora], 
				   BAN.[fechaoperacion], 
				   BAN.[horaoperacion], 
				   BAN.[fechavalor], 
				   BAN.[fechacontable], 
				   BAN.[estatus], 
				   BAN.[nocuenta], 
				   BAN.[estatusrevision], 
				   [Tipo]				= 0,
				   [idUsuario]			= @idUsuario,
				   [idEmpresa]			= @idEmpresa,
				   [anio]				= @añoConsulta,
				   [fecha]				= GETDATE(),
				   [idEstatus]			= 0,
				   [idConciliado]		= 0
				INTO #ABONOSBANCOSMEX_TMP
				FROM
					   referencias.dbo.bancomer BAN 
				INNER JOIN 
					Referencias.dbo.BancoCuenta CTA ON BAN.noCuenta= CTA.numeroCuenta
				WHERE
					BAN.escargo = 0 
					AND CTA.numeroCuenta = @noCuenta
					AND CTA.idEmpresa	 = @idEmpresa
					AND CTA.idBanco		 = 1
					AND fechaoperacion BETWEEN @fechaElaboracion AND @fechaCorte;
	

				INSERT INTO ABONOSBANCOS_CB
				SELECT TMP.[idbmer], 
				   TMP.[idbanco], 
				   TMP.[txtorigen], 
				   TMP.[registro], 
				   TMP.[nomovimiento], 
				   TMP.[referencia], 
				   TMP.[concepto], 
				   TMP.[refampliada], 
				   TMP.[escargo], 
				   TMP.[importe], 
				   TMP.[saldooperativo], 
				   TMP.[codigoleyenda], 
				   TMP.[oficinaoperadora], 
				   TMP.[fechaoperacion], 
				   TMP.[horaoperacion], 
				   TMP.[fechavalor], 
				   TMP.[fechacontable], 
				   TMP.[estatus], 
				   TMP.[nocuenta], 
				   TMP.[estatusrevision], 
				   TMP.[Tipo],
				   TMP.[idUsuario],
				   TMP.[idEmpresa],
				   TMP.[anio],
				   TMP.[fecha],
				   TMP.[idEstatus],
				   TMP.[idConciliado]
				FROM #ABONOSBANCOSMEX_TMP TMP
				LEFT JOIN  [ABONOSBANCOS_CB] OPE ON TMP.idBmer = OPE.idBmer AND TMP.idbanco = OPE.IDBanco
				WHERE OPE.idBmer IS NULL;

				-- CARGOS BANCOS
				SELECT BAN.[idbmer], 
				   BAN.[idbanco], 
				   BAN.[txtorigen], 
				   BAN.[registro], 
				   BAN.[nomovimiento], 
				   BAN.[referencia], 
				   BAN.[concepto], 
				   BAN.[refampliada], 
				   BAN.[escargo], 
				   BAN.[importe], 
				   BAN.[saldooperativo], 
				   BAN.[codigoleyenda], 
				   BAN.[oficinaoperadora], 
				   BAN.[fechaoperacion], 
				   BAN.[horaoperacion], 
				   BAN.[fechavalor], 
				   BAN.[fechacontable], 
				   BAN.[estatus], 
				   BAN.[nocuenta], 
				   BAN.[estatusrevision], 
				   [Tipo]				= 0,
				   [idUsuario]			= @idUsuario,
				   [idEmpresa]			= @idEmpresa,
				   [anio]				= @añoConsulta,
				   [fecha]				= GETDATE(),
				   [idEstatus]			= 0,
				   [idConciliado]		= 0
				INTO #CARGOSBANCOSMEX_TMP				
				FROM
					   referencias.dbo.bancomer BAN 
				INNER JOIN 
					Referencias.dbo.BancoCuenta CTA ON BAN.noCuenta= CTA.numeroCuenta
				WHERE
					BAN.escargo = 1 
					AND CTA.numeroCuenta = @noCuenta
					AND CTA.idEmpresa	 = @idEmpresa
					AND CTA.idBanco		 = 1
					AND fechaoperacion BETWEEN @fechaElaboracion AND @fechaCorte
	
				
				INSERT INTO CARGOSBANCOS_CB
				SELECT 
						TMP.[idbmer], 
						TMP.[idbanco], 
						TMP.[txtorigen], 
						TMP.[registro], 
						TMP.[nomovimiento], 
						TMP.[referencia], 
						TMP.[concepto], 
						TMP.[refampliada], 
						TMP.[escargo], 
						TMP.[importe], 
						TMP.[saldooperativo], 
						TMP.[codigoleyenda], 
						TMP.[oficinaoperadora], 
						TMP.[fechaoperacion], 
						TMP.[horaoperacion], 
						TMP.[fechavalor], 
						TMP.[fechacontable], 
						TMP.[estatus], 
						TMP.[nocuenta], 
						TMP.[estatusrevision], 
						TMP.[Tipo],
						TMP.[idUsuario],
						TMP.[idEmpresa],
						TMP.[anio],
						TMP.[fecha],
						TMP.[idEstatus],
						TMP.[idConciliado]
				    FROM #CARGOSBANCOSMEX_TMP TMP
				LEFT JOIN  [CARGOSBANCOS_CB] OPE ON TMP.idBmer = OPE.idBmer AND TMP.idbanco = OPE.IDBanco
				WHERE OPE.idBmer IS NULL;

				DROP TABLE #CARGOSBANCOSBAN_TMP;
				DROP TABLE #ABONOSBANCOSBAN_TMP;
			
			DROP TABLE #CARGOSBANCOSMEX_TMP;
			DROP TABLE #ABONOSBANCOSMEX_TMP;
			PRINT 'End Banamex'
		END
  
	ELSE IF (@idBanco = 3) --CORRESPONDE A SANTANDER
		BEGIN
			PRINT 'Santander'
			-- ABONOS BANCOS
			SELECT
				[idBmer]			= SAN.[idSantander],
				[IDBanco]			= SAN.[IDBanco],
				[txtOrigen]			= SAN.[txtOrigen],
				[referencia]		= SAN.[referencia],
				[concepto]			= SAN.[concepto],
				[esCargo]			= CASE SAN.[signo] WHEN '-' THEN 1 ELSE 0 END,
				[importe]			= SAN.[importe],
				[saldoOperativo]	= SAN.[saldo],
				[oficinaOperadora]	= SAN.[sucursal],
				[fechaOperacion]	= SAN.[fechaMovimiento],
				[horaOperacion]		= SAN.[horaMovimiento],
				[codigoLeyenda]		= SAN.[clacon],
				[refAmpliada]		= SAN.[concepto],
				[estatus]			= SAN.[estatus],
				[noCuenta]			= SAN.[noCuenta],
				[estatusRevision]	= SAN.[estatusRevision],
				[Tipo]				= 0,
				[idUsuario]			= @idUsuario,
				[idEmpresa]			= @idEmpresa,
				[anio]				= @añoConsulta,
				[fecha]				= GETDATE(),
				[idEstatus]			= 0,
				[idConciliado]		= 0
			INTO #ABONOSBANCOS_TMP
			FROM
				Referencias.dbo.Santander SAN 
			INNER JOIN 
				Referencias.dbo.BancoCuenta CTA ON SAN.noCuenta = CTA.numeroCuenta
			WHERE
				SAN.signo = '+' 
				AND CTA.numeroCuenta = @noCuenta 
				AND CTA.idEmpresa	 = @idEmpresa
				AND CTA.idBanco		 = 3
				AND SAN.fechaMovimiento BETWEEN @fechaElaboracion AND @fechaCorte;
	
			INSERT INTO ABONOSBANCOS_CB(
				idBmer,
				IDBanco,
				txtOrigen,
				referencia,
				concepto,
				esCargo,
				importe,
				saldoOperativo,
				oficinaOperadora,
				fechaOperacion,
				horaOperacion,
				codigoLeyenda,
				refAmpliada,
				estatus,
				noCuenta,
				estatusRevision,
				Tipo,
				idUsuario,
				idEmpresa,
				anio,
				fecha,
				idEstatus,
				idConciliado
			)
			SELECT 
			TMP.idBmer,
			TMP.IDBanco,
			TMP.txtOrigen,
			TMP.referencia,
			TMP.concepto,
			TMP.esCargo,
			TMP.importe,
			TMP.saldoOperativo,
			TMP.oficinaOperadora,
			TMP.fechaOperacion,
			TMP.horaOperacion,
			TMP.codigoLeyenda,
			TMP.refAmpliada,
			TMP.estatus,
			TMP.noCuenta,
			TMP.estatusRevision,
			TMP.Tipo,
			TMP.idUsuario,
			TMP.idEmpresa,
			TMP.anio,
			TMP.fecha,
			TMP.idEstatus,
			TMP.idConciliado 
			FROM #ABONOSBANCOS_TMP TMP
			LEFT JOIN  [ABONOSBANCOS_CB] OPE ON TMP.idBmer = OPE.idBmer AND TMP.idbanco = OPE.IDBanco
			WHERE OPE.idBmer IS NULL;

			-- CARGOS BANCOS
			SELECT
				[idBmer]			= SAN.[idSantander],
				[IDBanco]			= SAN.[IDBanco],
				[txtOrigen]			= SAN.[txtOrigen],
				[referencia]		= SAN.[referencia],
				[concepto]			= SAN.[concepto],
				[esCargo]			= CASE SAN.[signo] WHEN '-' THEN 1 ELSE 0 END,
				[importe]			= SAN.[importe],
				[saldoOperativo]	= SAN.[saldo],
				[oficinaOperadora]	= SAN.[sucursal],
				[fechaOperacion]	= SAN.[fechaMovimiento],
				[horaOperacion]		= SAN.[horaMovimiento],
				[codigoLeyenda]		= SAN.[clacon],
				[refAmpliada]		= SAN.[concepto],
				[estatus]			= SAN.[estatus],
				[noCuenta]			= SAN.[noCuenta],
				[estatusRevision]	= SAN.[estatusRevision],
				[Tipo]				= 0,
				[idUsuario]			= @idUsuario,
				[idEmpresa]			= @idEmpresa,
				[anio]				= @añoConsulta,
				[fecha]				= GETDATE(),
				[idEstatus]			= 0,
				[idConciliado]		= 0
			INTO #CARGOSBANCOS_TMP
			FROM
				Referencias.dbo.Santander SAN 
			INNER JOIN 
				Referencias.dbo.BancoCuenta CTA ON SAN.noCuenta = CTA.numeroCuenta
			WHERE
				SAN.signo = '-' 
				AND CTA.numeroCuenta = @noCuenta
				AND CTA.idEmpresa	 = @idEmpresa
				AND CTA.idBanco		 = 3
				AND SAN.fechaMovimiento BETWEEN @fechaElaboracion AND @fechaCorte;

			INSERT INTO CARGOSBANCOS_CB(
				idBmer,
				IDBanco,
				txtOrigen,
				referencia,
				concepto,
				esCargo,
				importe,
				saldoOperativo,
				oficinaOperadora,
				fechaOperacion,
				horaOperacion,
				codigoLeyenda,
				refAmpliada,
				estatus,
				noCuenta,
				estatusRevision,
				Tipo,
				idUsuario,
				idEmpresa,
				anio,
				fecha,
				idEstatus,
				idConciliado
			)
			SELECT TMP.idBmer,
				TMP.IDBanco,
				TMP.txtOrigen,
				TMP.referencia,
				TMP.concepto,
				TMP.esCargo,
				TMP.importe,
				TMP.saldoOperativo,
				TMP.oficinaOperadora,
				TMP.fechaOperacion,
				TMP.horaOperacion,
				TMP.codigoLeyenda,
				TMP.refAmpliada,
				TMP.estatus,
				TMP.noCuenta,
				TMP.estatusRevision,
				TMP.Tipo,
				TMP.idUsuario,
				TMP.idEmpresa,
				TMP.anio,
				TMP.fecha,
				TMP.idEstatus,
				TMP.idConciliado 
			FROM #CARGOSBANCOS_TMP TMP
			LEFT JOIN  [CARGOSBANCOS_CB] OPE ON TMP.idBmer = OPE.idBmer AND TMP.idbanco = OPE.IDBanco
			WHERE OPE.idBmer IS NULL;
			
			DROP TABLE #CARGOSBANCOS_TMP;
			DROP TABLE #ABONOSBANCOS_TMP;
		PRINT 'END Santander'
	END
ELSE
	BEGIN
		-- ABONOS BANCARIO
		SELECT
			[idBmer]			= BAN.idMovimiento,
			[IDBanco]			= BAN.idBanco,
			[txtOrigen]			= '',
			[referencia]		= SUBSTRING(BAN.referencia,0,50),
			[concepto]			= SUBSTRING(BAN.descripcion,0,50),
			[esCargo]			= 0,
			[importe]			= BAN.abono,
			[saldoOperativo]	= 0,
			[oficinaOperadora]	= '',
			[fechaOperacion]	= BAN.fecha,
			[horaOperacion]		= GETDATE(),
			[codigoLeyenda]		= '',
			[refAmpliada]		= SUBSTRING(BAN.descripcionAmpliada,0,50),
			[estatus]			= 0,
			[noCuenta]			= BAN.noCuenta,
			[estatusRevision]	= 0,
			[Tipo]				= 0,
			[idUsuario]			= @idUsuario,
			[idEmpresa]			= @idEmpresa,
			[anio]				= @añoConsulta,
			[fecha]				= GETDATE(),
			[idEstatus]			= 0,
			[idConciliado]		= 0
		INTO #ABONOSLAYOUT_TMP
		FROM
			Referencias.dbo.MovimientoBancarioLayout BAN
		INNER JOIN 
			Referencias.dbo.BancoCuenta CTA ON BAN.noCuenta = CTA.numeroCuenta
		WHERE
			BAN.abono <> 0 
			AND CTA.numeroCuenta = @noCuenta 
			AND CTA.idEmpresa	 = @idEmpresa
			AND BAN.fecha BETWEEN @fechaElaboracion AND @fechaCorte;

		INSERT INTO ABONOSBANCOS_CB(
			idBmer,
			IDBanco,
			txtOrigen,
			referencia,
			concepto,
			esCargo,
			importe,
			saldoOperativo,
			oficinaOperadora,
			fechaOperacion,
			horaOperacion,
			codigoLeyenda,
			refAmpliada,
			estatus,
			noCuenta,
			estatusRevision,
			Tipo,
			idUsuario,
			idEmpresa,
			anio,
			fecha,
			idEstatus,
			idConciliado
		)
		SELECT TMP.idBmer,
				TMP.IDBanco,
				TMP.txtOrigen,
				TMP.referencia,
				TMP.concepto,
				TMP.esCargo,
				TMP.importe,
				TMP.saldoOperativo,
				TMP.oficinaOperadora,
				TMP.fechaOperacion,
				TMP.horaOperacion,
				TMP.codigoLeyenda,
				TMP.refAmpliada,
				TMP.estatus,
				TMP.noCuenta,
				TMP.estatusRevision,
				TMP.Tipo,
				TMP.idUsuario,
				TMP.idEmpresa,
				TMP.anio,
				TMP.fecha,
				TMP.idEstatus,
				TMP.idConciliado  
		FROM #ABONOSLAYOUT_TMP TMP
		LEFT JOIN  [ABONOSBANCOS_CB] OPE ON TMP.idBmer = OPE.idBmer AND TMP.idbanco = OPE.IDBanco
		WHERE OPE.idBmer IS NULL;

		-- CARGO BANCARIO
		SELECT
			[idBmer]			= BAN.idMovimiento,
			[IDBanco]			= BAN.idBanco,
			[txtOrigen]			= '',
			[referencia]		= SUBSTRING(BAN.referencia,0,50),
			[concepto]			= SUBSTRING(BAN.descripcion,0,50),
			[esCargo]			= 1,
			[importe]			= BAN.cargo,
			[saldoOperativo]	= 0,
			[oficinaOperadora]	= '',
			[fechaOperacion]	= BAN.fecha,
			[horaOperacion]		= GETDATE(),
			[codigoLeyenda]		= '',
			[refAmpliada]		= SUBSTRING(BAN.descripcionAmpliada,0,50),
			[estatus]			= 0,
			[noCuenta]			= BAN.noCuenta,
			[estatusRevision]	= 0,
			[Tipo]				= 0,
			[idUsuario]			= @idUsuario,
			[idEmpresa]			= @idEmpresa,
			[anio]				= @añoConsulta,
			[fecha]				= GETDATE(),
			[idEstatus]			= 0,
			[idConciliado]		= 0
		INTO #CARGOSOSLAYOUT_TMP
		FROM
			Referencias.dbo.MovimientoBancarioLayout BAN
		INNER JOIN 
			Referencias.dbo.BancoCuenta CTA ON BAN.noCuenta = CTA.numeroCuenta
		WHERE
			BAN.cargo <> 0 
			AND CTA.numeroCuenta = @noCuenta 
			AND CTA.idEmpresa	 = @idEmpresa
			AND BAN.fecha BETWEEN @fechaElaboracion AND @fechaCorte;
	
		INSERT INTO CARGOSBANCOS_CB(
			idBmer,
			IDBanco,
			txtOrigen,
			referencia,
			concepto,
			esCargo,
			importe,
			saldoOperativo,
			oficinaOperadora,
			fechaOperacion,
			horaOperacion,
			codigoLeyenda,
			refAmpliada,
			estatus,
			noCuenta,
			estatusRevision,
			Tipo,
			idUsuario,
			idEmpresa,
			anio,
			fecha,
			idEstatus,
			idConciliado
		)
		SELECT TMP.idBmer,
				TMP.IDBanco,
				TMP.txtOrigen,
				TMP.referencia,
				TMP.concepto,
				TMP.esCargo,
				TMP.importe,
				TMP.saldoOperativo,
				TMP.oficinaOperadora,
				TMP.fechaOperacion,
				TMP.horaOperacion,
				TMP.codigoLeyenda,
				TMP.refAmpliada,
				TMP.estatus,
				TMP.noCuenta,
				TMP.estatusRevision,
				TMP.Tipo,
				TMP.idUsuario,
				TMP.idEmpresa,
				TMP.anio,
				TMP.fecha,
				TMP.idEstatus,
				TMP.idConciliado  
		FROM #CARGOSOSLAYOUT_TMP TMP
		LEFT JOIN  [CARGOSBANCOS_CB] OPE ON TMP.idBmer = OPE.idBmer AND TMP.idbanco = OPE.IDBanco
		WHERE OPE.idBmer IS NULL;
	END
	-- // END CARGOS Y ABONOS CONTABLES

	-- REGISTROS PAGOS
		-- REGISTROS PAGOS
		-- REGISTROS PAGOS
		SET @query = 'SELECT [IDABONOS_COMPLETO] ' +
					  ',[MOV_TIPOPOL] ' +
					  ',[MOV_CONSPOL] ' +
					  ',[MOV_CONSMOV] ' +
					  ',[MOV_MES] ' +
					  ',[MOV_NUMCTA] ' +
					  ',[MOV_CONCEPTO] ' +
					  ',[MOV_DEBE] ' +
					  ',[MOV_HABER] ' +
					  ',[MOV_ORIGEN] ' +
					  ',[MOV_IDCLIENTE] ' +
					  ',[MOV_DEPTO] ' +
					  ',[MOV_CARTERA] ' +
					  ',[MOV_TIPODOCTO] ' +
					  ',[MOV_IDDOCTO] ' +
					  ',[MOV_FECHVEN] ' +
					  ',[MOV_FECHPAG] ' +
					  ',[MOV_AGENTE] ' +
					  ',[MOV_CVEUSU] ' +
					  ',[MOV_FECHOPE] ' +
					  ',[MOV_CONCILIADO] ' +
					  ',[MOV_FOLIO] ' +
					  ',[MOV_FOLIODET] ' +
					  ',[MOV_MONEDA] ' +
					  ',[MOV_TIPOCAMBIO] ' +
					  ',[MOV_HORAOPE] ' +
					  ',[MOV_OBSERVA] ' +
					  ',[TIPO] ' +
					  ',[IDUSUARIO] ' +
					  ',[IDEMPRESA] ' +
					  ',[IDBANCO] ' +
					  ',[anio] ' +
					  ',[fecha] ' +
					  ',[idEstatus] ' + 			
					  ' FROM  ABONOS_COMPLETO_CB WHERE MOV_TIPOPOL COLLATE Modern_Spanish_CS_AS = (SELECT TOP(1) tipo_poliza_pago COLLATE Modern_Spanish_CS_AS FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 AND emp_idempresa = ' + CONVERT(VARCHAR(4),@idEmpresa) + ') '  --''TREEUN'''
			
		INSERT INTO ABONOS_PAGO_CB 
		EXEC (@query)

		--BUSCO LA CARTERA DE ESTOS PAGOS
		

		SET @query = 'SELECT [IDCARGOS_COMPLETO] ' +
			',[MOV_TIPOPOL] ' +
			',[MOV_CONSPOL] ' +
			',[MOV_CONSMOV] ' +
			',[MOV_MES] ' +
			',[MOV_NUMCTA] ' +
			',[MOV_CONCEPTO] ' +
			',[MOV_DEBE] ' +
			',[MOV_HABER] ' +
			',[MOV_ORIGEN] ' +
			',[MOV_IDCLIENTE] ' +
			',[MOV_DEPTO] ' +
			',[MOV_CARTERA] ' +
			',[MOV_TIPODOCTO] ' +
			',[MOV_IDDOCTO] ' +
			',[MOV_FECHVEN] ' +
			',[MOV_FECHPAG] ' +
			',[MOV_AGENTE] ' +
			',[MOV_CVEUSU] ' +
			',[MOV_FECHOPE] ' +
			',[MOV_CONCILIADO] ' +
			',[MOV_FOLIO] ' +
			',[MOV_FOLIODET] ' +
			',[MOV_MONEDA] ' +
			',[MOV_TIPOCAMBIO] ' +
			',[MOV_HORAOPE] ' +
			',[MOV_OBSERVA] ' +
			',[Tipo] ' +
			',[idUsuario] ' +
			',[idEmpresa] ' +
			',[idBanco] ' +
			',[anio] ' +
			',[fecha] ' +
			',[idEstatus] ' + 
		' FROM CARGOS_COMPLETO_CB ' +
						'WHERE MOV_TIPOPOL COLLATE Modern_Spanish_CS_AS IN(SELECT Tipo_Poliza COLLATE Modern_Spanish_CS_AS FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO  WHERE emp_idempresa = ' + CONVERT(VARCHAR(4),@idEmpresa) + ' AND Tipo = 1)'
			
		

		SELECT TOP(1) @numCuenta2 = numeroCuenta2 
		FROM referencias.dbo.BancoCuenta
			WHERE idBanco = @idBanco 
				AND idEmpresa = @idEmpresa
																																										--4)LQMA 19042018 se agregaron columna idBanco y idEmpresa BODOKITO
		

	-- Elimina registros en Tesoreria si fueron eliminados en BPRO y su punteo si existe
		EXEC [dbo].[CON_ELIMINADESDEBPRO_SP] @cuentaContable, @idEmpresa, @mes, @añoConsulta;

	-- Conciliados por referencia
		EXEC [dbo].[CON_REFERENCIADOS_CARGOS_SP] @idBanco, @idEmpresa, @mes, @añoConsulta, @noCuenta, @cuentaContable;
		EXEC [dbo].[CON_REFERENCIADOS_ABONOS_SP] @idBanco, @idEmpresa, @mes, @añoConsulta, @fechaElaboracion, @fechaCorte, @noCuenta, @cuentaContable;

	-- Depuración de datos modificados por BPRO
		EXEC [dbo].[CON_DATOSMODIFICADOS_SP] @idEmpresa, @idBanco, @cuentaContable, @añoConsulta;


	-- Consulta de Saldo Inicial
		SELECT @SaldoInicial = SaldoInicial
			   FROM referencias.dbo.BancoCuenta
			   WHERE idBanco = @idBanco
			   AND idEmpresa = @idEmpresa
			   AND cuentaContable = @cuentaContable;

		DECLARE @SUMCargos NUMERIC(18,2) =  (
												SELECT	SUM(importe) 
												FROM	[CARGOSBANCOS_CB] 
												WHERE	IDBanco			= @idBanco
														AND idEmpresa	= @idEmpresa
														AND anio		= @añoConsulta
														AND noCuenta	= @noCuenta
														AND idEstatus = 0
														AND MONTH(fechaOperacion) = @mes
											);

		DECLARE @SUMAbonos NUMERIC(18,2) =  (
												SELECT SUM(importe) 
												FROM  [ABONOSBANCOS_CB] 
												WHERE IDBanco		= @idBanco
													  AND idEmpresa = @idEmpresa
													  AND anio		= @añoConsulta
													  AND noCuenta  = @noCuenta
													  AND idEstatus = 0
													  AND MONTH(fechaOperacion) = @mes
											);

		-- Calculo de Saldo Banco
		SELECT @saldoBanco = ISNULL(@SaldoInicial,0) - ISNULL( @SUMCargos, 0 ) + ISNULL( @SUMAbonos, 0 )

		-- SALDO BANCO DESPUES DE LA NETRADA AL SISTEMA
		DECLARE @SUMCargos2 NUMERIC(18,2) =  (
												SELECT	SUM(importe) 
												FROM	[CARGOSBANCOS_CB] 
												WHERE	IDBanco			= @idBanco
														AND idEmpresa	= @idEmpresa
														AND anio		= @añoConsulta
														AND noCuenta	= @noCuenta
														AND idEstatus = 0
														AND MONTH(fechaOperacion) >= 6
											);

		DECLARE @SUMAbonos2 NUMERIC(18,2) =  (
												SELECT SUM(importe) 
												FROM  [ABONOSBANCOS_CB] 
												WHERE IDBanco		= @idBanco
														AND idEmpresa = @idEmpresa
														AND anio		= @añoConsulta
														AND noCuenta  = @noCuenta
														AND idEstatus = 0
														AND MONTH(fechaOperacion) >= 6
												);
	
		IF( @mes > 6)
			BEGIN
				SELECT @saldoBanco = ISNULL(@SaldoInicial,0) - ISNULL( @SUMCargos2, 0 ) + ISNULL( @SUMAbonos2, 0 )
			END
		
		-- MODO DEBUG
		-- MODO DEBUG
		-- MODO DEBUG
			IF( @DEBUG = 1 )
				BEGIN
					SELECT @saldoBanco SALDOBANCO, @SaldoInicial SALDOINICIAL, @SUMCargos CARGOS, @SUMAbonos ABONOS;
				END
		--//


		SELECT @totalAbonoContable = SUM( MOV_HABER )
		FROM  [ABONOS_COMPLETO_CB] MOV
		LEFT JOIN REGISTROS_PUNTEADOS PUN ON MOV.IDABONOS_COMPLETO = PUN.rpun_idAbono AND rpun_tipo = 'C' AND rpun_idAplicado != 0
		WHERE MOV.MOV_MES <= @mes
				AND idEmpresa  = @idEmpresa
				AND anio       = @añoConsulta
				AND idBanco    = @idBanco
				AND MOV_NUMCTA = @cuentaContable
				AND idEstatus  = 0
				AND rpun_idAplicado IS NULL

		SELECT @totalCargoContable = SUM(MOV_DEBE) 
		FROM  [CARGOS_COMPLETO_CB] MOV
		LEFT JOIN REGISTROS_PUNTEADOS PUN ON MOV.IDCARGOS_COMPLETO = PUN.rpun_idCargo AND rpun_tipo = 'C' AND rpun_idAplicado != 0
   		WHERE MOV.MOV_MES <= @mes
				AND idEmpresa  = @idEmpresa
				AND anio       = @añoConsulta
				AND idBanco    = @idBanco
				AND MOV_NUMCTA = @cuentaContable
				AND idEstatus  = 0
				AND rpun_idAplicado IS NULL


	-- Set Totales de Cargos y Abonos Bancarios

	SELECT 
		@totalCargoBancario = SUM(importe)
	FROM  CARGOSBANCOS_CB CAR  --CARGOS
	LEFT JOIN  [REGISTROS_PUNTEADOS] PUN ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo
											AND PUN.rpun_tipo = 'B'
											AND PUN.rpun_idAplicado IN (1,2,3)
	WHERE CAR.noCuenta = @noCuenta
			AND CAR.idEmpresa = @idEmpresa
			AND CAR.IDBanco = @idBanco
			AND CAR.anio = @añoConsulta
			AND idEstatus  = 0
			AND PUN.rpun_idPunteado IS NULL
	
	SELECT
		@totalAbonoBancario = SUM(importe) 
	FROM  ABONOSBANCOS_CB ABO  --CARGOS
	LEFT JOIN  [REGISTROS_PUNTEADOS] PUN ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono
											AND PUN.rpun_tipo = 'B'
											AND PUN.rpun_idAplicado IN (1,2,3)
	WHERE ABO.noCuenta = @noCuenta
			AND ABO.idEmpresa = @idEmpresa
			AND ABO.IDBanco = @idBanco
			AND ABO.anio = @añoConsulta
			AND idEstatus  = 0
			AND PUN.rpun_idPunteado IS NULL

	
	-----------------------------------------------------------Cálculo de saldo según Conciliacion---------------------------------------------------------------------
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------
	SET @saldoConciliacion = ((ISNULL(@saldoBanco,0) - ISNULL(@totalAbonoContable,0) - ISNULL(@totalAbonoBancario,0))+ (ISNULL(@totalCargoContable,0) + ISNULL(@totalCargoBancario,0)))

	-- MODO DEBUG
	-- MODO DEBUG
	-- MODO DEBUG
		IF( @DEBUG = 1 )
			BEGIN
				SELECT @totalAbonoContable;
			END
	--//
							 ---Suma de cargos y abonos no punteados Registros Bancarios 

	-----------------------------------------------------------Cálculo de saldo según contabilidad---------------------------------------------------------------------
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------
	DECLARE @NombreMes varchar(3),
			@RESULT_MESNAME varchar(10),
			@ParmDefinition nvarchar(100),
			@result_SaldoInicial_Contable decimal(18,2);
	
	SET LANGUAGE Spanish;
	SET @NombreMes = SUBSTRING(DATENAME(MONTH, CONVERT(DATE, CONVERT(DATE, REPLACE(@fechaCorte,'-','')), 103)),0,4);--SUBSTRING(DATENAME(MONTH, convert(DATE, convert(date, @fechaCorte), 103)),0,4);
	SET @RESULT_MESNAME = UPPER('SF_'+ @NombreMes) 
	

	DECLARE @RESULTADO NVARCHAR(MAX) =   'SELECT @saldoInicialContable = CONVERT(DECIMAL(18,2),'+ @RESULT_MESNAME +')' +char(13)+ 
										+'FROM '+ @Base +'BI_VIEW_SALDOS_FINALES_'+CONVERT(VARCHAR(4),@añoConsulta)+'' +char(13) 
										+'WHERE  CTA_NUMCTA = '''+ @cuentaContable +''''
	SET @ParmDefinition = N'@saldoInicialContable decimal(18,2) OUTPUT';

	print('BI_VIEW_SALDOS_FINALES')
	print(@RESULTADO)

	EXECUTE sp_executesql @RESULTADO, @ParmDefinition, @saldoInicialContable = @result_SaldoInicial_Contable OUTPUT;

	SELECT @saldoContabilidad = @result_SaldoInicial_Contable
	 ----Saldo inicial + (@totalCargoContable - @totalAbonoContable)
	 ---------------------------------------------------Calculo Saldo Inicial--------------------------------------------
	print 'saldo conciliacion: ' + CONVERT(VARCHAR(20),@saldoConciliacion)

	------------------------------------------------------------------Cálculo Diferencia-------------------------------------------------------------------------------
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------
	SET @diferencia = @saldoConciliacion - @saldoContabilidad


	----------------------------------------------------------Consulto la viabilidad del mes de búsqueda---------------------------------------------------------------
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------

	DECLARE @Meses TABLE(ID INT IDENTITY(1,1), PAR_IDENPARA VARCHAR(10), PAR_DESCRIP2 VARCHAR(20))
	DECLARE @mensaje VARCHAR(100) = 'Mes actual activo.'

	INSERT INTO @Meses

	SELECT  PAR_IDENPARA,PAR_DESCRIP2
	FROM GAAU_Concentra.dbo.PNC_PARAMETR
	WHERE PAR_TIPOPARA = 'mcerrcon' 	
	AND PAR_IDENPARA LIKE '' + CONVERT(VARCHAR(10),DATEPART(year,REPLACE(@primerDiaMesConsulta,'-',''))) + '%'
	AND PAR_DESCRIP1 = '01'
	
	
	SELECT @mesActivo = CASE PAR_DESCRIP2
							WHEN 'ABIERTO' THEN 1
							WHEN 'CERRADO' THEN 0
						END 
	FROM @Meses WHERE PAR_IDENPARA = REPLACE(@primerDiaMesConsulta,'-','')

	
	IF(SELECT PAR_DESCRIP2 FROM @Meses WHERE ID = (SELECT ID - 1 FROM @Meses WHERE PAR_IDENPARA = REPLACE(@primerDiaMesConsulta,'-',''))) = 'ABIERTO'
		BEGIN
			SELECT @mesActivo = 0, @mensaje = ' Los movimientos del mes actual no se podran ver. El mes anterior aun se encuentra activo.'
		END 
	
	-- SE GUARDA EL SALDO SEGUN CONTABILIDAD PARA CONSULTAS POSTERIORES
	IF EXISTS( SELECT * FROM [SaldoContabilidad] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND noCuenta = @noCuenta)
		BEGIN
			UPDATE 
				SC
			SET 
				saldo = @saldoContabilidad
			FROM [SaldoContabilidad] SC
			WHERE	idEmpresa	 = @idEmpresa 
					AND idBanco  = @idBanco 
					AND noCuenta = @noCuenta
		END
	ELSE
		BEGIN
			INSERT INTO [SaldoContabilidad] VALUES( @idEmpresa, @idBanco, @noCuenta, @saldoContabilidad )
		END

	----------------------------------------------------------Regreso el resultado de los cálculos---------------------------------------------------------------------
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
		SELECT ISNULL(@saldoBanco,0) saldoBanco,
			ISNULL(@totalAbonoContable,0) tAbonoContable,
			ISNULL(@totalAbonoBancario,0) tAbonoBancario,
			ISNULL(@totalCargoContable,0) tCargoContable,		
			ISNULL(@totalCargoBancario,0) tCargoBancario,
			ISNULL(@saldoConciliacion,0) sConciliacion,
			ISNULL(@saldoContabilidad,0) sContabilidad,
			ISNULL(@diferencia,0) diferencia,
			ISNULL(@mesActivo,0) mesActivo,
			@mensaje mensaje
	END TRY
	BEGIN CATCH

		   print 'error'	
		   SELECT ERROR_MESSAGE() + '' + ERROR_LINE() AS ERROR

	END CATCH
END
go

