
--  [INS_AUXILIAR_CONTABLE_SP]@idEmpresas = 1, @cuentaContable='1100-0020-0001-0001'
---EXECUTE [dbo].[INS_AUXILIAR_CONTABLE_SP] 4,'1100-0020-0001-0010','2017-11-01','2017-11-30'
CREATE PROCEDURE [dbo].[INS_AUXILIAR_CONTABLE_SP]
	  @idEmpresas varchar(3),
	  @cuentaContable varchar(20),
	  @fechaElaboracion varchar(50),
	  @fechaCorte varchar(50)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @aux               INT = 1
    DECLARE @max               INT = 0
    DECLARE @idEmpresaBusca    INT = 0
    DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
    DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @select            NVARCHAR(MAX);
	DECLARE @selectPreCot      VARCHAR(max);
	DECLARE @selectCotNu       VARCHAR(max);
	DECLARE @selectCotSE       VARCHAR(max);
	DECLARE @selectPeOr        VARCHAR(max);
	DECLARE	@idSucursal		   NVARCHAR(50) =NULL
	DECLARE	@nombreSucursal    NVARCHAR(50) =NULL
	DECLARE @nombreEmpresa     NVARCHAR(50) =NULL
	DECLARE	@idEmpresa	       NVARCHAR(50) =NULL
	DECLARE @ipServidor NVARCHAR(50)
	DECLARE @cadIpServidor VARCHAR(100)
    
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
							
                            idEmpresa         nvarchar(30)
                            ,nombreEmpresa     nvarchar(100)
                            ,nomCtoEmpresa     nvarchar(5)
                            ,nomBaseConcentra  nvarchar(50)
							,nomBaseSucursal  nvarchar(50)
                            ,nomBaseMatriz     nvarchar(50)
                            ,ipServidor        nvarchar(20)
                            )

-- SE HACE LA BUSQUEDA DE LAS EMPRESAS Y SUCURSALES DISPONIBLES CON EL NOMBRE Y DIRECCIÓN IP DONDE SE ENCUENTRAN

DECLARE  @fechaFin date , @mes VARCHAR(2),@anio VARCHAR(4)

SET @fechaFin = GETDATE()
SET @anio = YEAR(@fechaFin)
SET @mes  = MONTH(@fechaFin)

--
     INSERT INTO @Bases
	   	SELECT
				EMP.emp_idempresa
                ,EMP.emp_nombre
                ,EMP.emp_nombrecto
                ,BASEMP.nombre_base
				,BASEMP.nombre_sucursal
                ,ISNULL(BASEMP.nombre_base_matriz,BASEMP.nombre_base)
                ,BASEMP.ip_servidor 
           FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
                INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
          WHERE  BASEMP.estatus = 1 AND BASEMP.tipo = 2 and EMP.emp_idempresa= @idEmpresas --EMP.emp_idempresa AND BASEMP.nombre_sucursal != 'CRA Guadalajara' AND BASEMP.nombre_sucursal !='CRA Cuautitlan'
    
     SET @max = (SELECT MAX(IDB) FROM @Bases)
     WHILE(@aux <= @max)
     BEGIN
        
         SELECT  @idEmpresaBusca   = DB.idEmpresa 
				,@idEmpresa = DB.idEmpresa
                ,@nomBaseConcentra = DB.nomBaseConcentra
                ,@nomBaseMatriz    = DB.nomBaseMatriz
				,@nombreSucursal = DB.nomBaseSucursal
				,@nombreEmpresa = DB.nombreEmpresa
				,@ipServidor = DB.ipServidor
           FROM @Bases AS DB 
          WHERE DB.IDB = @aux --DB.idEmpresa = @aux 
        

		    
		IF (@ipServidor ='192.168.20.29')
		BEGIN
		set @cadIpServidor =''
		END
		ELSE
		BEGIN
		set @cadIpServidor =' [' + @ipServidor + '].'
		END

		DECLARE @todo TABLE  ( --IDB INT IDENTITY(1,1),										
								 idEmpresa  VARCHAR(50)
								,movMes VARCHAR(MAX)
								,movConsMov INT
								,numeroCuenta VARCHAR(MAX)
								,polTipo VARCHAR(MAX)
								,polConsecutivo VARCHAR(MAX)
								,movConcepto VARCHAR(MAX)
								,cargo DECIMAL(18,2)
								,abono DECIMAL(18,2)
								,movFechaOpe DATE
								,movHoraOpe TIME
								,idDocto VARCHAR(MAX)
                            )
		  
		  SET @select =
				'SELECT  '+ char(13) +
					'		'+@idEmpresas+' as idEmpresa'+ char(13) + 
					'	   ,MOV_MES as movMes' + char(13) + 
					'	   ,MOV_CONSMOV as movConsMov' + char(13) + 
					'	   ,MOV_NUMCTA as numeroCuenta' + char(13) +  
					'      ,MOV_TIPOPOL as tipoPoliza' + char(13)+
					'	   ,MOV_CONSPOL as movConsPol' + char(13) + 
					'	   ,MOV_CONCEPTO as movConcepto' + char(13) + 
					'	   ,MOV_DEBE as cargo' + char(13) + -- Cargo
					'	   ,MOV_HABER as abono' + char(13) + -- Abono	
					'      ,CONVERT(DATE,SUBSTRING(mov_fechope,7,4) + SUBSTRING(mov_fechope,4,2) + SUBSTRING(mov_fechope,1,2)) movFechaOpe' + char(13) + 
					'	   ,mov_horaope as movHoraOpe' + char(13) +
					'	   ,MOV_IDDOCTO as idDocto' + char(13) + 
					'FROM    '+@cadIpServidor +'['+@nomBaseConcentra+'].[dbo].[CON_MOVDET01'+@anio+']' + char(13) + 					
					'WHERE MOV_NUMCTA = '+char(39)+@cuentaContable+char(39)+' ' + char(13) +   					
					'      AND MOV_MES = MONTH(convert(DATE, convert(date,'+ char(39) + @fechaCorte + char(39) +'), 103)) '+ char(13) +
					'' 
				
				--print @select 

				INSERT INTO @todo EXECUTE (@select)  
				      
         SET @aux = @aux + 1
    END
	
	 --modifcar parametros para que puedan ser opcionales
	INSERT INTO AuxiliarContable
			  SELECT auxiliar.idEmpresa 
					,auxiliar.movMes
					,auxiliar.movConsMov
					,auxiliar.numeroCuenta  
					,auxiliar.polTipo 
					,auxiliar.polConsecutivo 
					,auxiliar.movConcepto 
					,auxiliar.cargo 
					,auxiliar.abono
					,auxiliar.movFechaOpe
					,auxiliar.movHoraOpe
					,1 as idEstatus
					,auxiliar.idDocto
				from @todo auxiliar 
					left outer join [AuxiliarContable]  on 
					[AuxiliarContable].[movConsMov] = auxiliar.movConsMov 
					AND [AuxiliarContable].[polConsecutivo] = auxiliar.[polConsecutivo]
				    AND [AuxiliarContable].[movMes] = auxiliar.movMes
					AND [AuxiliarContable].[polTipo] = auxiliar.polTipo
					AND [AuxiliarContable].[numeroCuenta] = auxiliar.numeroCuenta
 					where [AuxiliarContable].[polConsecutivo] IS NULL 

END
go

