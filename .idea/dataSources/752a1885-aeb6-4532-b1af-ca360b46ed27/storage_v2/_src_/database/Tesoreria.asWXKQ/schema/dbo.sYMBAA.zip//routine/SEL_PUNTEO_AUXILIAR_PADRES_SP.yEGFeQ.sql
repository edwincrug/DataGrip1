-- [SEL_PUNTEO_AUXILIAR_PADRES_SP] 1
--[SEL_PUNTEO_AUXILIAR_PADRES_SP] 1, '1100-0020-0001-0001', '2018-05-01', '2018-05-30'
CREATE PROCEDURE [dbo].[SEL_PUNTEO_AUXILIAR_PADRES_SP]
@idEmpresa INT,
@cuentaContable VARCHAR(50) = '',
@fechaelaboracion VARCHAR(30),
@fechaCorte VARCHAR(30)
AS 
BEGIN
    
	SELECT 					 
				     --DISTINCT(PUNTEO.[idPunteoAuxiliarBanco]) AS  idAuxiliarContable
					DISTINCT
					idAuxiliarContable
					,(SELECT TOP 1 descripcion FROM [PunteoAuxiliarBanco] WHERE MOV_CONSPOL = PUNTEO.idAuxiliarContable) AS  descripcion
 					,@idEmpresa idEmpresa 
					,auxiliar.MOV_MES movMes
					,auxiliar.MOV_CONSMOV movConsMov
					,auxiliar.MOV_NUMCTA numeroCuenta  
					,auxiliar.MOV_TIPOPOL polTipo
					,auxiliar.MOV_CONSPOL polConsecutivo  
					,auxiliar.MOV_CONCEPTO movConcepto 
					,auxiliar.MOV_DEBE cargo 
					,auxiliar.MOV_HABER abono
					,auxiliar.MOV_FECHOPE movFechaOpe
					,auxiliar.MOV_HORAOPE movHoraOpe
					,2 idEstatus --auxiliar.idEstatus --?????
					,PUNTEO.idPAdre
					,PUNTEO.tipoPunteo AS tipoPunteo
					,PUNTEO.idPunteoFinalBancos					
	FROM ABONOS_COMPLETO_CB auxiliar 
	INNER JOIN [PunteoAuxiliarBanco] PUNTEO ON PUNTEO.idAuxiliarContable = auxiliar.IDABONOS_COMPLETO--auxiliar.MOV_CONSPOL  
	WHERE --auxiliar.idEmpresa = @idEmpresa
	--AND
	PUNTEO.esCargoContable = 0 
	AND auxiliar.MOV_NUMCTA = @cuentaContable
	--AND auxiliar.MOV_FECHOPE BETWEEN CONVERT(VARCHAR(10),CONVERT(DATETIME,REPLACE(@fechaelaboracion,'-','')),103) 
	--							 AND CONVERT(VARCHAR(10),CONVERT(DATETIME,REPLACE(@fechaCorte,'-','')),103)
	AND PUNTEO.fechaAplicacion BETWEEN REPLACE(@fechaelaboracion,'-','')
											AND REPLACE(@fechaCorte,'-','')
	--AND PUNTEO.idPAdre != 4  
	--AND	auxiliar.MOV_CONSPOL = PUNTEO.idAuxiliarContable 
	--AND auxiliar.MOV_MES = PUNTEO.MOV_MES
	--AND auxiliar.MOV_TIPOPOL = PUNTEO.MOV_TIPOPOL
	--AND auxiliar.MOV_CONSMOV = PUNTEO.MOV_CONSMOV
	--AND auxiliar.MOV_CONSPOL = PUNTEO.MOV_CONSPOL
	UNION
	
	SELECT 
					 DISTINCT--(PUNTEO.[idPunteoAuxiliarBanco]) idAuxiliarContable		            
					idAuxiliarContable
					,(SELECT TOP 1 descripcion FROM [PunteoAuxiliarBanco] WHERE MOV_CONSPOL = PUNTEO.idAuxiliarContable) AS  descripcion
 					,@idEmpresa idEmpresa 
					,auxiliar.MOV_MES movMes
					,auxiliar.MOV_CONSMOV movConsMov
					,auxiliar.MOV_NUMCTA numeroCuenta  
					,auxiliar.MOV_TIPOPOL polTipo
					,auxiliar.MOV_CONSPOL polConsecutivo  
					,auxiliar.MOV_CONCEPTO movConcepto 
					,auxiliar.MOV_DEBE cargo 
					,auxiliar.MOV_HABER abono
					,auxiliar.MOV_FECHOPE movFechaOpe
					,auxiliar.MOV_HORAOPE movHoraOpe
					,2 idEstatus --auxiliar.idEstatus --?????
					,PUNTEO.idPAdre
					,PUNTEO.tipoPunteo AS tipoPunteo	
					,PUNTEO.idPunteoFinalBancos									
	FROM CARGOS_COMPLETO_CB auxiliar 
	INNER JOIN [PunteoAuxiliarBanco] PUNTEO ON PUNTEO.idAuxiliarContable = auxiliar.IDCARGOS_COMPLETO --MOV_CONSPOL  
	WHERE --auxiliar.idEmpresa = @idEmpresa
	--AND 
	auxiliar.MOV_NUMCTA = @cuentaContable
	AND PUNTEO.esCargoContable = 1 
	--AND auxiliar.MOV_FECHOPE BETWEEN CONVERT(VARCHAR(10),CONVERT(DATETIME,REPLACE(@fechaelaboracion,'-','')),103) 
	--							 AND CONVERT(VARCHAR(10),CONVERT(DATETIME,REPLACE(@fechaCorte,'-','')),103)
	AND PUNTEO.fechaAplicacion BETWEEN REPLACE(@fechaelaboracion,'-','')
											AND REPLACE(@fechaCorte,'-','')
	AND PUNTEO.idPAdre != 4  
	--AND	auxiliar.MOV_CONSPOL = PUNTEO.idAuxiliarContable 
	AND auxiliar.MOV_MES = PUNTEO.MOV_MES
	--AND auxiliar.MOV_TIPOPOL = PUNTEO.MOV_TIPOPOL
	--AND auxiliar.MOV_CONSMOV = PUNTEO.MOV_CONSMOV

	/*
	 SELECT 
				     DISTINCT(PUNTEO.[idAuxiliarContable]) AS  idAuxiliarContable
		            ,(SELECT TOP 1 descripcion FROM [PunteoAuxiliarBanco] WHERE idAuxiliarContable = PUNTEO.idAuxiliarContable) AS  descripcion
 					,auxiliar.idEmpresa 
					,auxiliar.movMes
					,auxiliar.movConsMov
					,auxiliar.numeroCuenta  
					,auxiliar.polTipo
					,auxiliar.polConsecutivo  
					,auxiliar.movConcepto 
					,auxiliar.cargo 
					,auxiliar.abono
					,auxiliar.movFechaOpe
					,auxiliar.movHoraOpe
					,auxiliar.idEstatus
					,PUNTEO.idPAdre
					,PUNTEO.tipoPunteo AS tipoPunteo
					
	 FROM [AuxiliarContable] auxiliar 
	INNER JOIN [PunteoAuxiliarBanco] PUNTEO ON PUNTEO.idAuxiliarContable = auxiliar.idAuxiliarContable  
	WHERE auxiliar.idEmpresa = @idEmpresa
	AND auxiliar.numeroCuenta = @cuentaContable
	AND auxiliar.movFechaOpe BETWEEN @fechaelaboracion and @fechaCorte
	AND PUNTEO.idPAdre != 4  
	*/
END


go

