CREATE PROCEDURE [dbo].[SEL_CUENTA_CLAVE_BANCO_SP]
--[SEL_CUENTA_CLAVE_BANCO_SP] 1,1  
@idEmpresa as int ,
@idBanco as int 

as 
begin 
select [idCuenta]
      ,[idEmpresa]
      ,[idBanco]
      ,[cuenta]
      ,[convenio]
      ,[tipoCuenta]
      ,[cuentaContable]
      ,[MontoMinimoPagos]
      ,[SaldoInicial]
      ,[numeroCuenta]
      ,[IdPersona]
      ,[Carga_Layout]
      ,[numeroCuenta2]
      ,[idBancoBPRO] from referencias.dbo.bancocuenta where  idBanco =@idBanco  and  idEmpresa = @idEmpresa and ((SELECT ISNUMERIC(cuenta)) = 1) 
end


go

