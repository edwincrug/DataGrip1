
-- [dbo].[SEL_ABONO_CONTABLE_SP_DEV] 1, 1, '000000000195334667', '1100-0020-0001-0001', '2018-06-01', '2018-06-30', 'TREUN', 2
CREATE PROCEDURE [dbo].[SEL_ABONO_CONTABLE_SP_DEV]
	@idEmpresa VARCHAR(50),
	@idBanco INT,
	@noCuenta VARCHAR(50),
	@cuentaContable VARCHAR(50),
	@fechaElaboracion CHAR(11),
	@fechaCorte CHAR(11),
	@polizaPago VARCHAR(30),
	@opcion INT
AS
BEGIN

	DECLARE @idHistorico INT = 0;
	-- Casos @opcion
	-- 1: Normal 
	-- 2: Empresa
	-- 3: Sistema
	
	IF( @opcion = 1 )
		BEGIN
			SELECT	
				AC.MOV_NUMCTA MOV_NUMCTA,
				AC.MOV_TIPOPOL MOV_TIPOPOL,
				AC.MOV_CONSPOL MOV_CONSPOL,
				AC.MOV_CONSMOV MOV_CONSMOV,
				AC.MOV_MES MOV_MES,
				AC.MOV_DEBE MOV_DEBE,
				AC.MOV_FECHOPE MOV_FECHOPE,
				AC.MOV_HABER MOV_HABER,
				AC.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM ABONOS_COMPLETO_CB AC
			LEFT JOIN REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = AC.IDABONOS_COMPLETO AND PUN.rpun_tipo = 'C'
			WHERE   AC.idEmpresa = @idEmpresa
					AND AC.idBanco = @idBanco
					AND AC.MOV_NUMCTA = @cuentaContable
					AND PUN.rpun_idAbono IS NULL
					AND AC.idEstatus = 0
			ORDER BY AC.MOV_FECHOPE, AC.MOV_HORAOPE ASC;
		END
	ELSE IF( @opcion = 2 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 1
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)

			SELECT	
				AC.MOV_NUMCTA MOV_NUMCTA,
				AC.MOV_TIPOPOL MOV_TIPOPOL,
				AC.MOV_CONSPOL MOV_CONSPOL,
				AC.MOV_CONSMOV MOV_CONSMOV,
				AC.MOV_MES MOV_MES,
				AC.MOV_DEBE MOV_DEBE,
				AC.MOV_FECHOPE MOV_FECHOPE,
				AC.MOV_HABER MOV_HABER,
				AC.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM ABONOS_COMPLETO_CB_H AC
			LEFT JOIN REGISTROS_PUNTEADOS_H PUN ON PUN.rpun_idAbono = AC.IDABONOS_COMPLETO AND PUN.rpun_tipo = 'C' AND AC.idHistorico = @idHistorico
			WHERE   AC.idEmpresa = @idEmpresa
					AND AC.idBanco = @idBanco
					AND AC.MOV_NUMCTA = @cuentaContable
					AND PUN.rpun_idAbono IS NULL
					AND AC.idEstatus = 0
					AND AC.idHistorico = @idHistorico
					ORDER BY AC.MOV_FECHOPE, AC.MOV_HORAOPE ASC;
		END
	ELSE IF( @opcion = 3 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 2
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)

			SELECT	
				AC.MOV_NUMCTA MOV_NUMCTA,
				AC.MOV_TIPOPOL MOV_TIPOPOL,
				AC.MOV_CONSPOL MOV_CONSPOL,
				AC.MOV_CONSMOV MOV_CONSMOV,
				AC.MOV_MES MOV_MES,
				AC.MOV_DEBE MOV_DEBE,
				AC.MOV_FECHOPE MOV_FECHOPE,
				AC.MOV_HABER MOV_HABER,
				AC.MOV_CONCEPTO MOV_CONCEPTO,
				'' MOV_REFERENCIA
			FROM ABONOS_COMPLETO_CB_H AC
			LEFT JOIN REGISTROS_PUNTEADOS_H PUN ON PUN.rpun_idAbono = AC.IDABONOS_COMPLETO AND PUN.rpun_tipo = 'C' AND AC.idHistorico = PUN.idHistorico
			WHERE   AC.idEmpresa = @idEmpresa
					AND AC.idBanco = @idBanco
					AND AC.MOV_NUMCTA = @cuentaContable
					AND PUN.rpun_idAbono IS NULL
					AND AC.idEstatus = 0
					AND AC.idHistorico = @idHistorico
					ORDER BY AC.MOV_FECHOPE, AC.MOV_HORAOPE ASC;
		END
END
go

