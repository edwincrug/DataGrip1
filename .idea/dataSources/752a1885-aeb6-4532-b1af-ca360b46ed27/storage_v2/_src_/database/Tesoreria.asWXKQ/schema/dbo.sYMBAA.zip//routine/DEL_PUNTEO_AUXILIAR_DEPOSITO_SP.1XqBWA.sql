
CREATE PROCEDURE [dbo].[DEL_PUNTEO_AUXILIAR_DEPOSITO_SP]
@idDatoBusqueda INT,
@opcion INT,
@idEmpresa INT,
@idBanco INT
AS
BEGIN
		
	IF(@opcion = 1)--Banco Punteado
		BEGIN
			
			--SELECT A.idPunteoAuxiliarBanco,A.idDepositoBanco, A.idAuxiliarContable 
			IF(SELECT TOP(1) idBmerPadre FROM [PunteoAuxiliarBanco] WHERE idDepositoBanco = @idDatoBusqueda) IS NOT NULL 
				BEGIN
					
					DELETE FROM [PunteoAuxiliarBanco] 
					WHERE idBmerPadre = (SELECT TOP(1) idBmerPadre FROM [PunteoAuxiliarBanco] WHERE idDepositoBanco = @idDatoBusqueda)

				END
			ELSE
				BEGIN

					DELETE A FROM [PunteoAuxiliarBanco] A  
					JOIN [PunteoAuxiliarBanco] B ON A.idAuxiliarContable = B.idAuxiliarContable
													AND	A.MOV_CONSMOV = B.MOV_CONSMOV
													AND	A.MOV_MES = B.MOV_MES
													AND	A.MOV_TIPOPOL = B.MOV_TIPOPOL
					WHERE B.idDepositoBanco =  @idDatoBusqueda
					
				END
			
		END 
	ELSE
	IF(@opcion = 2) --Auxiliar Contable Punteado
		BEGIN				

			--SELECT A.idPunteoAuxiliarBanco,A.idDepositoBanco, A.idAuxiliarContable 
			DELETE A 
			FROM [PunteoAuxiliarBanco] A  
			JOIN [PunteoAuxiliarBanco] B ON A.idAuxiliarContable = B.idAuxiliarContable
											AND	A.MOV_CONSMOV = B.MOV_CONSMOV
											AND	A.MOV_MES = B.MOV_MES
											AND	A.MOV_TIPOPOL = B.MOV_TIPOPOL
			WHERE B.idAuxiliarContable = @idDatoBusqueda			
			
		END		


	SELECT 0 AS Estatus, 'RELACIONES BORRADAS CORRECTAMENTE' AS Descripcion
END
go

