-- =============================================
-- Author:
-- Create date:
-- Description:
-- =============================================
CREATE PROCEDURE dbo.validaTransferencia_SP
-- Add the parameters for the stored procedure here
@cuenta varchar(50)
,@saldoCuenta decimal(18,2)
,@transitoEntrada decimal(18,2)
,@transitoSalida decimal(18,2)
,@montoTransferencia DECIMAL(18,2)
,@saldoMinimo decimal(18,2)
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
DECLARE @saldo decimal(18,2)
    -- Insert statements for procedure here
--SELECT @saldo = isnull(SUM(tb.importe),0)
--FROM Tesoreria..TransferenciasBancarias tb
--WHERE tb.cuentaOrigen = @cuenta
--AND tb.autorizado = 0
--SELECT @saldo = @saldo+ISNULL(SUM(tsb.tsb_importe),0)
--FROM GA_Corporativa.dbo.tsb_traspasosaldobancos tsb
--WHERE tsb.tsb_cuentaorigen = @cuenta
--and tsb.tsb_estatus in (-1,0)
set @saldo = @saldoCuenta+@transitoEntrada-@transitoSalida
--select @saldo - @montoTransferencia as valor
if ((@saldo - @montoTransferencia) >= 0 AND (@saldo - @montoTransferencia) <= @saldoMinimo)
BEGIN
SELECT 1 AS estatus, 'La cuenta no cumplira la regla del saldo minimo de '+CAST(@saldoMinimo as varchar(30))+ ', o no cuenta con fondos para solicitar una transferencias ' as mensaje, @saldo as disponible
END
ELSE if ((@saldo - @montoTransferencia) > 0 AND (@saldo - @montoTransferencia) > @saldoMinimo)
BEGIN 
SELECT 2 AS estatus,'Cuenta lista para transferencias' as mensaje
END
ELSE if ((@saldo - @montoTransferencia)< 0)
BEGIN 
SELECT 3 AS estatus,'Saldo insuficiente en la cuenta' as mensaje, ABS((@saldo - @montoTransferencia)) as excede
END
END
go

exec sp_addextendedproperty 'MS_Description', 'Valida los datos de la transferencia', 'SCHEMA', 'dbo', 'PROCEDURE',
     'validaTransferencia_SP'
go

