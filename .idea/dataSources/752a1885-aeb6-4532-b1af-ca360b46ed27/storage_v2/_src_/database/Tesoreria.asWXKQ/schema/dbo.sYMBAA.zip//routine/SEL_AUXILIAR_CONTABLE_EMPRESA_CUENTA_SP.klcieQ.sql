CREATE PROCEDURE [dbo].[SEL_AUXILIAR_CONTABLE_EMPRESA_CUENTA_SP]
@idEmpresa INT,
@idBanco INT,
@noCuenta VARCHAR(100),
@idEstatus INT,
@fechaElaboracion VARCHAR(50),
@fechaCorte VARCHAR(50),
@polizaPago VARCHAR(30),
@cuentaBancaria VARCHAR(30)	
AS
BEGIN TRY

	DECLARE @Meses TABLE(ID INT IDENTITY(1,1), PAR_IDENPARA VARCHAR(10), PAR_DESCRIP2 VARCHAR(20))
	DECLARE @mesActual INT, @mesActivo INT

	SELECT @mesActual = DATEPART(MONTH,REPLACE(@fechaElaboracion,'-',''))	

	INSERT INTO @Meses

	SELECT  PAR_IDENPARA,PAR_DESCRIP2
	FROM GAAU_Concentra.dbo.PNC_PARAMETR
	WHERE PAR_TIPOPARA = 'mcerrcon' 	
	AND PAR_IDENPARA LIKE '' + CONVERT(VARCHAR(10),DATEPART(year,REPLACE(@fechaElaboracion,'-',''))) + '%'
	AND PAR_DESCRIP1 = '01'
	
	
	SELECT @mesActivo = CASE PAR_DESCRIP2
						   WHEN 'ABIERTO' THEN 1
						   WHEN 'CERRADO' THEN 0
						END 
	FROM @Meses WHERE PAR_IDENPARA = CONVERT(VARCHAR(10),DATEPART(year,REPLACE(@fechaElaboracion,'-','')))

	IF(SELECT PAR_DESCRIP2 FROM @Meses WHERE ID = (SELECT ID - 1 FROM @Meses WHERE PAR_IDENPARA = REPLACE(@fechaElaboracion,'-',''))) = 'ABIERTO'
		BEGIN
			SELECT @mesActivo = 0
		END

	IF(@mesActivo = 1)
		BEGIN
			SET @mesActual = 0
		END


IF @idBanco = 1
BEGIN
      --EXECUTE [DBO].[SEL_AUXILIAR_CONTABLE_BANCOMER] @idEmpresa, @noCuenta, @idEstatus, @fechaElaboracion, @fechaCorte, @polizaPago, @cuentaBancaria
		SET LANGUAGE Español
		SELECT	CB.IDABONOS_COMPLETO idAuxiliarContable,--MOV_CONSPOL idAuxiliarContable,
				@idEmpresa idEmpresa,
				CB.MOV_MES movMes,
				CB.MOV_CONSMOV movConsMov, --?
				CB.MOV_NUMCTA numeroCuenta,
				CB.MOV_TIPOPOL polTipo,
				CB.MOV_CONSPOL polConsecutivo,
				CB.MOV_CONCEPTO movConcepto,
				CB.MOV_DEBE cargo,
				CB.MOV_HABER abono,
				CB.MOV_FECHOPE movFechaOpe,
				CB.MOV_HORAOPE movHoraOpe,
				1 idEstatus,
				0 fechaAnterior,
				'' color,
				'' referenciaAuxiliar,
				CB.anio,
				UPPER(DATENAME(month, CONVERT(DATE,CB.MOV_FECHOPE,103))) MES,
			 	0 esCargo
		--SELECT --@totalAbonoContable = SUM(MOV_HABER) --Abonos_Contables_noBancarios 
			 FROM ABONOS_COMPLETO_CB CB  
			 LEFT JOIN PunteoAuxiliarBanco PUNTEO ON CB.MOV_CONSPOL = PUNTEO.MOV_CONSPOL --CB.IDABONOS_COMPLETO = PUNTEO.idAuxiliarContable 
								AND CB.MOV_MES = PUNTEO.MOV_MES
								AND CB.MOV_TIPOPOL = PUNTEO.MOV_TIPOPOL
								AND CB.MOV_CONSMOV = PUNTEO.MOV_CONSMOV
   			 WHERE TIPO = 0
				AND PUNTEO.idAuxiliarContable IS NULL
				--AND CB.MOV_MES NOT IN (@mesActual)
				AND CB.MOV_MES = @mesActual --LAGP
			 --AND MOV_CONSPOL NOT IN (SELECT idAuxiliarContable FROM PunteoAuxiliarBanco)
		UNION
		SELECT  CB.IDCARGOS_COMPLETO idAuxiliarContable,--MOV_CONSPOL idAuxiliarContable,
				@idEmpresa idEmpresa,
				CB.MOV_MES movMes,
				CB.MOV_CONSMOV movConsMov, --?
				CB.MOV_NUMCTA numeroCuenta,
				CB.MOV_TIPOPOL polTipo,
				CB.MOV_CONSPOL polConsecutivo,
				CB.MOV_CONCEPTO movConcepto,
				CB.MOV_DEBE cargo,
				CB.MOV_HABER abono,
				CB.MOV_FECHOPE movFechaOpe,
				CB.MOV_HORAOPE movHoraOpe,
				1 idEstatus,
				0 fechaAnterior,
				'' color,
				'' referenciaAuxiliar,
				CB.anio,
				UPPER(DATENAME(month, CONVERT(DATE,CB.MOV_FECHOPE,103))) MES,
				1 esCargo
				--@totalCargoContable = SUM(MOV_DEBE) --Cargos_Contabilidad_noBancos 
			 FROM CARGOS_COMPLETO_CB CB 
			 LEFT JOIN PunteoAuxiliarBanco PUNTEO ON CB.MOV_CONSPOL = PUNTEO.MOV_CONSPOL--CB.IDCARGOS_COMPLETO = PUNTEO.idAuxiliarContable 
								AND CB.MOV_MES = PUNTEO.MOV_MES
								AND CB.MOV_TIPOPOL = PUNTEO.MOV_TIPOPOL
								AND CB.MOV_CONSMOV = PUNTEO.MOV_CONSMOV
			 WHERE TIPO = 0
				AND PUNTEO.idAuxiliarContable IS NULL
				--AND CB.MOV_MES NOT IN (@mesActual)
				AND CB.MOV_MES = @mesActual --LAGP
			 --AND MOV_CONSPOL NOT IN (SELECT idAuxiliarContable FROM PunteoAuxiliarBanco)

END
IF @idBanco = 2
BEGIN
   SELECT 'BANCO NO DISPONIBLE' AS ERROR 
END
IF @idBanco = 3
BEGIN 
   EXECUTE [DBO].[SEL_AUXILIAR_CONTABLE_SANTANDER] @idEmpresa, @noCuenta, @idEstatus, @fechaElaboracion, @fechaCorte, @polizaPago, @cuentaBancaria
END

 --Selecciono el  último idPunteoAuxiliar para tener un identificador que relacione las conciliaciones Contables
 SELECT 
		ISNULL(idDepositoBanco,0) 
		AS idRelationOfContableRows 
        FROM [PunteoAuxiliarBanco]
		WHERE idPAdre = 3
		AND idPunteoAuxiliarBanco = (Select ISNULL(MAX(idPunteoAuxiliarBanco),0)
									 FROM [PunteoAuxiliarBanco]
									 WHERE idPAdre =3
									 AND idBanco = @idBanco
									 AND idEmpresa = @idEmpresa)
	    AND idEmpresa = @idEmpresa
		AND idBanco = @idBanco

END TRY
BEGIN CATCH
			SELECT ERROR_MESSAGE() +'' + ERROR_LINE() AS ERROR
END CATCH
go

