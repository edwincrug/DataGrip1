CREATE procedure [dbo].[INS_CXPCOMISIONESINTERESES_SP]
	@interesComisionID as int,
	@idSucursal as int,
	@idEmpresa as INT,
	@esGrupo as INT
AS
BEGIN
	DECLARE @idBanco INT = (SELECT bancoID FROM [InteresComision] WHERE interesComisionID = @interesComisionID);
	DECLARE @NoCuenta VARCHAR(50);
	DECLARE @Beneficiario VARCHAR(30)

	IF (@idBanco = 1)
		BEGIN
			SET @NoCuenta = (SELECT B.noCuenta FROM referencias.dbo.Bancomer B	INNER JOIN InteresComision I ON B.idBmer = I.comisionID	AND statusID = 1 AND interesComisionID  = @interesComisionID)
			SET @Beneficiario = (SELECT numeroCuenta FROM [referencias].[dbo].[BancoCuenta] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND numeroCuenta = @NoCuenta);		
		END	
	ELSE
		BEGIN
			SET @NoCuenta = (SELECT TOP 1 numeroCuenta FROM [referencias].[dbo].[BancoCuenta] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco)
			SET @Beneficiario = (SELECT TOP 1 numeroCuenta FROM [referencias].[dbo].[BancoCuenta] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco);		
		END
						
	IF( @idBanco = 1 ) -- Bancomer
		BEGIN
			INSERT INTO cxp_comisionesintereses
			SELECT 	Empresa = @idEmpresa,
					Sucursal = @idSucursal,
					poliza = 'CXPCOMUN',
					fechaPoliza = getdate(),
					descripcion = concepto,
					fechaGen = getdate(),
					estatus = 0,
					ctaBeneficiario = @Beneficiario,
					coi_cuentapagadora = b.noCuenta,
					cobrador = 'MMK',
					moneda = 'PE',
					tipocambio = 1,
					formaPago = '39',
					tipo = 'C',
					interesComisionID = @interesComisionID,
					null
			FROM referencias.dbo.Bancomer B
			INNER JOIN InteresComision I ON B.idBmer = I.comisionID	AND statusID =1 AND interesComisionID  = @interesComisionID
		END
	ELSE IF( @idBanco = 2 ) -- Banamex
		BEGIN
			INSERT INTO cxp_comisionesintereses
			SELECT  Empresa = @idEmpresa,
					Sucursal = @idSucursal,
					poliza = 'CXPCOMUN',
					fechaPoliza = getdate(),
					descripcion = BMEX.concepto,
					fechaGen = getdate(),
					estatus = 0,
					ctaBeneficiario = @Beneficiario,
					coi_cuentapagadora = BMEX.noCuenta,
					cobrador = 'MMK',
					moneda = 'PE',
					tipocambio = 1,
					formaPago = '39',
					tipo = 'C',
					interesComisionID = @interesComisionID,
					null
			FROM (select * from ABONOSBANCOS_CB where idbanco=2 union all select * from CARGOSBANCOS_CB where IDBanco=2) BMEX
			INNER JOIN InteresComision I ON BMEX.idBmer = I.comisionID AND interesComisionID =  @interesComisionID
		END
	ELSE IF( @idBanco = 3 ) -- Santander
		BEGIN
			INSERT INTO cxp_comisionesintereses
			SELECT  Empresa = @idEmpresa,
					Sucursal = @idSucursal,
					poliza = 'CXPCOMUN',
					fechaPoliza = getdate(),
					descripcion = concepto,
					fechaGen = getdate(),
					estatus = 0,
					ctaBeneficiario = @Beneficiario,
					coi_cuentapagadora = S.noCuenta,
					cobrador = 'MMK',
					moneda = 'PE',
					tipocambio = 1,
					formaPago = '39',
					tipo = 'C',
					interesComisionID = @interesComisionID,
					null
			FROM referencias.dbo.Santander S
			INNER JOIN InteresComision I ON S.idSantander = I.comisionID AND statusID = 1 AND interesComisionID = @interesComisionID
		END
	
	-- Obtenemos la referencia
	DECLARE @nextRef NUMERIC(18) = (SELECT MAX(DISTINCT(CONVERT(INT, cid_referenciabancaria))) + 1 nextRef
	FROM [cxp_comisionesinteresesdet] DET
	INNER JOIN [cxp_comisionesintereses] COM ON DET.coi_idcomisionesintereses = COM.coi_idcomisionesintereses
	WHERE coi_idempresa = @idEmpresa);

	IF( @nextRef IS NULL )
	BEGIN
		SET @nextRef = 1;
	END
	
	--	Obtenemos el idPersona
	--DECLARE @idPersona NUMERIC = (SELECT idPersona FROM [referencias].[dbo].[BancoCuenta] WHERE idBanco = @idBanco AND idEmpresa = @idEmpresa AND IdPersona IS NOT NULL);
	DECLARE @idPersona NUMERIC = (SELECT idPersona FROM [referencias].[dbo].[BancoCuenta] WHERE idBanco = @idBanco AND idEmpresa = @idEmpresa AND IdPersona IS NOT NULL AND numeroCuenta = @NoCuenta);
	
	-- Base para la referencia
	DECLARE @NombreEmpresa VARCHAR(5)   = (SELECT emp_nombrecto FROM [ControlAplicaciones].[dbo].[cat_empresas] WHERE emp_idempresa = @idEmpresa);
	DECLARE @NombreSucursal VARCHAR(5)  = 0;
	IF( @esGrupo = 1 )
		BEGIN
			DECLARE @sucMatriz NUMERIC(2,0)  = ( SELECT sucursal_matriz FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND tipo = 2 );
			SET @NombreSucursal = (SELECT suc_nombrecto FROM [ControlAplicaciones].[dbo].[cat_sucursales] WHERE suc_idsucursal = @sucMatriz);	
		END
	ELSE
		BEGIN			
			SET @NombreSucursal = (SELECT suc_nombrecto FROM [ControlAplicaciones].[dbo].[cat_sucursales] WHERE suc_idsucursal = @idSucursal);			
		END
		
	DECLARE @BaseReferencia VARCHAR(50) = @NombreEmpresa + '-' + @NombreSucursal + '-Com-';	
	
	
	
	DECLARE @headerID NUMERIC(18,0) = @@IDENTITY;
	-- Obtenemos el ultimo compuetso de referencia
	DECLARE @LastReferencia VARCHAR(50) = ( SELECT TOP 1 cid_documento 
											FROM [cxp_comisionesinteresesdet] 
											WHERE cid_documento LIKE @BaseReferencia + '%'
											ORDER BY cid_idcomisionesinteresesdet DESC );
	
	-- Result
	SELECT @headerID AS headerID, 
			RIGHT('00000000000000000000' + Ltrim(Rtrim(@nextRef)),20) as nextRef, 
			@idPersona AS idPersona, 
			@LastReferencia AS lastReferencia,
			@BaseReferencia AS baseReferencia;








	--DECLARE @idBanco INT = (SELECT bancoID FROM [InteresComision] WHERE interesComisionID = @interesComisionID);
	--DECLARE @Beneficiario VARCHAR(30) = (SELECT numeroCuenta FROM [referencias].[dbo].[BancoCuenta] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco);

	--DECLARE @idBanco INT = (SELECT bancoID FROM [InteresComision] WHERE interesComisionID = @interesComisionID);
	--DECLARE @NoCuenta VARCHAR(50) = (SELECT B.noCuenta FROM referencias.dbo.Bancomer B	INNER JOIN InteresComision I ON B.idBmer = I.comisionID	AND statusID = 1 AND interesComisionID  = @interesComisionID)
	--DECLARE @Beneficiario VARCHAR(30) = (SELECT numeroCuenta FROM [referencias].[dbo].[BancoCuenta] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND numeroCuenta = @NoCuenta);
								
	--IF( @idBanco = 1 ) -- Bancomer
	--	BEGIN
	--		INSERT INTO cxp_comisionesintereses
	--		SELECT 	Empresa = @idEmpresa,
	--				Sucursal = @idSucursal,
	--				poliza = 'CXPCOMUN',
	--				fechaPoliza = getdate(),
	--				descripcion = concepto,
	--				fechaGen = getdate(),
	--				estatus = 0,
	--				ctaBeneficiario = @Beneficiario,
	--				coi_cuentapagadora = b.noCuenta,
	--				cobrador = 'MMK',
	--				moneda = 'PE',
	--				tipocambio = 1,
	--				formaPago = '39',
	--				tipo = 'C',
	--				interesComisionID = @interesComisionID,
	--				null
	--		FROM referencias.dbo.Bancomer B
	--		INNER JOIN InteresComision I ON B.idBmer = I.comisionID	AND statusID =1 AND interesComisionID  = @interesComisionID
	--	END
	--ELSE IF( @idBanco = 2 ) -- Banamex
	--	BEGIN
	--		INSERT INTO cxp_comisionesintereses
	--		SELECT  Empresa = @idEmpresa,
	--				Sucursal = @idSucursal,
	--				poliza = 'CXPCOMUN',
	--				fechaPoliza = getdate(),
	--				descripcion = BMEX.Descripcion,
	--				fechaGen = getdate(),
	--				estatus = 0,
	--				ctaBeneficiario = @Beneficiario,
	--				coi_cuentapagadora = BMEX.noCuenta,
	--				cobrador = 'MMK',
	--				moneda = 'PE',
	--				tipocambio = 1,
	--				formaPago = '39',
	--				tipo = 'C',
	--				interesComisionID = @interesComisionID,
	--				null
	--		FROM referencias.dbo.Banamex_Layout BMEX
	--		INNER JOIN InteresComision I ON BMEX.idBmer = I.comisionID AND interesComisionID =  @interesComisionID
	--	END
	--ELSE IF( @idBanco = 3 ) -- Santander
	--	BEGIN
	--		INSERT INTO cxp_comisionesintereses
	--		SELECT  Empresa = @idEmpresa,
	--				Sucursal = @idSucursal,
	--				poliza = 'CXPCOMUN',
	--				fechaPoliza = getdate(),
	--				descripcion = concepto,
	--				fechaGen = getdate(),
	--				estatus = 0,
	--				ctaBeneficiario = @Beneficiario,
	--				coi_cuentapagadora = S.noCuenta,
	--				cobrador = 'MMK',
	--				moneda = 'PE',
	--				tipocambio = 1,
	--				formaPago = '39',
	--				tipo = 'C',
	--				interesComisionID = @interesComisionID,
	--				null
	--		FROM referencias.dbo.Santander S
	--		INNER JOIN InteresComision I ON S.idSantander = I.comisionID AND statusID = 1 AND interesComisionID = @interesComisionID
	--	END
	
	---- Obtenemos la referencia
	--DECLARE @nextRef NUMERIC(18) = (SELECT MAX(DISTINCT(CONVERT(INT, cid_referenciabancaria))) + 1 nextRef
	--FROM [cxp_comisionesinteresesdet] DET
	--INNER JOIN [cxp_comisionesintereses] COM ON DET.coi_idcomisionesintereses = COM.coi_idcomisionesintereses
	--WHERE coi_idempresa = @idEmpresa);

	--IF( @nextRef IS NULL )
	--BEGIN
	--	SET @nextRef = 1;
	--END
	
	----	Obtenemos el idPersona
	----DECLARE @idPersona NUMERIC = (SELECT idPersona FROM [referencias].[dbo].[BancoCuenta] WHERE idBanco = @idBanco AND idEmpresa = @idEmpresa AND IdPersona IS NOT NULL);
	--DECLARE @idPersona NUMERIC = (SELECT idPersona FROM [referencias].[dbo].[BancoCuenta] WHERE idBanco = @idBanco AND idEmpresa = @idEmpresa AND IdPersona IS NOT NULL AND numeroCuenta = @NoCuenta);
	
	---- Base para la referencia
	--DECLARE @NombreEmpresa VARCHAR(5)   = (SELECT emp_nombrecto FROM [ControlAplicaciones].[dbo].[cat_empresas] WHERE emp_idempresa = @idEmpresa);
	--DECLARE @NombreSucursal VARCHAR(5)  = 0;
	--IF( @esGrupo = 1 )
	--	BEGIN
	--		DECLARE @sucMatriz NUMERIC(2,0)  = ( SELECT sucursal_matriz FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND tipo = 2 );
	--		SET @NombreSucursal = (SELECT suc_nombrecto FROM [ControlAplicaciones].[dbo].[cat_sucursales] WHERE suc_idsucursal = @sucMatriz);	
	--	END
	--ELSE
	--	BEGIN			
	--		SET @NombreSucursal = (SELECT suc_nombrecto FROM [ControlAplicaciones].[dbo].[cat_sucursales] WHERE suc_idsucursal = @idSucursal);			
	--	END
		
	--DECLARE @BaseReferencia VARCHAR(50) = @NombreEmpresa + '-' + @NombreSucursal + '-Com-';	
	
	
	
	--DECLARE @headerID NUMERIC(18,0) = @@IDENTITY;
	---- Obtenemos el ultimo compuetso de referencia
	--DECLARE @LastReferencia VARCHAR(50) = ( SELECT TOP 1 cid_documento 
	--										FROM [cxp_comisionesinteresesdet] 
	--										WHERE cid_documento LIKE @BaseReferencia + '%'
	--										ORDER BY cid_idcomisionesinteresesdet DESC );
	
	---- Result
	--SELECT @headerID AS headerID, 
	--	   RIGHT('00000000000000000000' + Ltrim(Rtrim(@nextRef)),20) as nextRef, 
	--	   @idPersona AS idPersona, 
	--	   @LastReferencia AS lastReferencia,
	--	   @BaseReferencia AS baseReferencia;
END
go

