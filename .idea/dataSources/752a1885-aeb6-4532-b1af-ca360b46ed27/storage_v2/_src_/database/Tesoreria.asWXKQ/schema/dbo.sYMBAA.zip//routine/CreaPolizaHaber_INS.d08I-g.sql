-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<Inserta el dpi en bpro>
-- =============================================
--[dbo].[CreaPolizaHaber_INS] 5,4,1,'GMI',71,'HHHH123456GME','1100-0020-001-0018','cafr',23,2,2,2020,1857425,0,'TRANSFERIR INGRESOS DE CAJA/DB000022437/03- Tarjeta de Crédito/BANAMEX6439','asdsdyuyiasdufyiads','12/02/2020','12/02/2020',0
CREATE PROCEDURE [dbo].[CreaPolizaHaber_INS]
			@idRegistro int,
			@idEmpresa INT,
			@idBanco INT,
			@idUsuario nvarchar(4)='GMI',
			@Usuario int,
			@rfc nvarchar(20),
			@MOV_NUMCTA nvarchar(20)='',
			@MOV_TIPOPOL nvarchar(10)='',
			@MOV_CONSPOL int,
			@MOV_CONSMOV int,
			@MOV_MES INT,
			@anio int,
			@MOV_DEBE decimal(18,5) =0,
			@MOV_HABER decimal(18,5) =0,
			@MOV_CONCEPTO nvarchar(250)='',
			@referencia nvarchar(22)='',
			@fechaoper datetime ,
			@mov_fecha datetime,
			@MOV_IDCLIENTE int=0
		   

AS
BEGIN
----1.-Declarar las variables--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('tempdb..##TempDPI') IS NOT NULL
    DROP TABLE ##TempDPI

	SET NOCOUNT ON;
	Declare @serverDB varchar(200) 
	,@ipDB varchar(200) 

	,@queryText1 AS VARCHAR(max) =''
	,@queryText2 AS VARCHAR(max) =''
	,@queryText3 AS VARCHAR(max) =''
	,@queryText4 AS VARCHAR(max) =''
	,@queryText5 AS VARCHAR(max) =''
	,@queryText6 AS VARCHAR(max) =''
	,@queryText7 AS VARCHAR(max) =''
	,@cuentacargo int =1

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--select @mov_fecha
         DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	set @serverDB= ''
	set @ipDB= ''

	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			select top 1	@serverDB=
			'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							--from  [192.168.20.92].[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal is null
		END
	ELSE
		BEGIN
			select top 1	@serverDB=
			'['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							--from  [192.168.20.92].[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal is null
		END
	
         if @serverDB is null or len(@serverDB) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 return 0;
		 end
		 
----3.-Insertar en CON_MOVDET01--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	select @serverDB serverDB,@MOV_MES MOV_MES,@idEmpresa idEmpresa,@idBanco idBanco,@mOV_NUMCTA NUMCTA
	,@MOV_DEBE MOV_DEBE,@MOV_HABER MOV_HABER,@MOV_IDCLIENTE MOV_IDCLIENTE,@idUsuario idUsuario
 
		   Set @queryText1=' Declare @rfc nvarchar(20)='''+@rfc+''',@mov_numcta nvarchar(20)='''+@mov_numcta+''',@MOV_CONSMOV int='+convert(nvarchar(3),@mov_consmov)+',@MOV_CONSPOL int='+convert(nvarchar(3),@mov_conspol)+',@namedpi nvarchar(250)='''+@MOV_CONCEPTO+''',@fechaoper datetime = convert(datetime,'''+convert(nvarchar(10),@fechaoper,103)+''',103),@mov_fecha datetime = convert(datetime,'''+convert(nvarchar(10),@mov_fecha,103)+''',103)
insert into '+@serverDB+'.CON_MOVDET01'+convert(nvarchar(8),@anio)+' (MOV_NUMCTA,	MOV_CONCEPTO,MOV_CONSMOV,MOV_DEBE,MOV_HABER,MOV_ORIGEN,MOV_IDCLIENTE,MOV_DEPTO,MOV_CARTERA,MOV_TIPODOCTO,MOV_IDDOCTO,MOV_FECHVEN,MOV_FECHPAG,MOV_AGENTE,MOV_TIPOPOL,MOV_CONSPOL,MOV_MES,MOV_CVEUSU,MOV_FECHOPE,MOV_CONCILIADO,MOV_FOLIO,MOV_FOLIODET,MOV_MONEDA,MOV_TIPOCAMBIO, MOV_OBSERVA) 
VALUES (@MOV_NUMCTA,--MOV_NUMCTA,
@namedpi,--MOV_CONCEPTO,
@MOV_CONSMOV,--MOV_CONSMOV,
'+convert(nvarchar(23),@MOV_DEBE)+',--MOV_DEBE,
'+convert(nvarchar(23),@MOV_HABER)+',--MOV_HABER,
'''',--MOV_ORIGEN,
'''+convert(nvarchar(5),@MOV_IDCLIENTE)+''',--MOV_IDCLIENTE,
'''', --MOV_DEPTO,
'''',--MOV_CARTERA,
'''',--MOV_TIPODOCTO,
'''',--MOV_IDDOCTO,
'''',--MOV_FECHVEN,
'''',--MOV_FECHPAG,
'''', --MOV_AGENTE,
'''+@mov_tipopol+''',--MOV_TIPOPOL,
convert(nvarchar(5),@MOV_CONSPOL),--MOV_CONSPOL,
'+convert(nvarchar(5),@MOV_MES)+',--MOV_MES,
'''+@idUsuario+''',--MOV_CVEUSU,
 '''+convert(nvarchar(10),@mov_fecha,103)+''',--MOV_FECHOPE,
'''',--MOV_CONCILIADO,
0,--MOV_FOLIO,
0,--MOV_FOLIODET,
''PE'',--MOV_MONEDA,
''1'',--MOV_TIPOCAMBIO,
'''++@referencia+'''--MOV_OBSERVA
)'  +  CHAR(13) + CHAR(10)  +'EXEC [dbo].[BitacoraFLAP_INS]  '+convert(nvarchar(9),@idRegistro)+','+convert(nvarchar(9),@idEmpresa)+','+convert(nvarchar(9),@idBanco)+',@mov_numcta,@MOV_CONSPOL,2,'''','+convert(nvarchar(9),@Usuario)+  CHAR(13) + CHAR(10)  

		   Set @queryText2= 

'update '+@serverDB+'.CON_CTAS01'+convert(nvarchar(8),@anio)+ ' set cta_abono'+convert(nvarchar(2),@MOV_MES)+' = cta_abono'+convert(nvarchar(2),@MOV_MES)+' + '+convert(nvarchar(23),@MOV_HABER)+' , cta_cargo'+convert(nvarchar(2),@MOV_MES)+' = cta_cargo'+convert(nvarchar(2),@MOV_MES)+' + '+convert(nvarchar(23),@MOV_DEBE)+' 
where  cta_numcta = substring(@MOV_NUMCTA,1,4)+''-0000-0000-0000'' or cta_numcta = substring(@MOV_NUMCTA,1,9)+''-0000-0000'' or cta_numcta = substring(@MOV_NUMCTA,1,14)+''-0000'' or cta_numcta = @MOV_NUMCTA'  +  CHAR(13) + CHAR(10) +
 CHAR(13) + CHAR(10)  +'EXEC [dbo].[BitacoraFLAP_INS]  '+convert(nvarchar(9),@idRegistro)+','+convert(nvarchar(9),@idEmpresa)+','+convert(nvarchar(9),@idBanco)+',@mov_numcta,@MOV_CONSPOL,3,'''','+convert(nvarchar(9),@Usuario)+  CHAR(13) + CHAR(10)   

--print 'Paso 01'
--print @queryText1
--print 'Paso 02'
--print @queryText2 
--print 'Paso 03'
--print @queryText3 
--print 'Paso 04'
--print @queryText4 
--print 'Paso 05'
--print @queryText5
--print 'Paso 06'
--print @queryText6 
--print 'Paso 07'
--print @queryText7
	--	print @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7
	--select len( @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7)
begin try
--Begin TRAN DPI
	EXEC( @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7) 
	print @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7
	--select len( @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7)
	--COMMIT TRAN DPI
END TRY
BEGIN CATCH
    PRINT 'In CATCH Block'
	Declare @mensaje nvarchar(max)
	 select @mensaje=ERROR_MESSAGE() 
	 --IF(@@TRANCOUNT > 0)
  --     ROLLBACK TRAN DPI;
 EXEC [dbo].[BitacoraFLAP_INS]  @idRegistro,@idEmpresa,@idBanco,@mOV_NUMCTA,0,0,@mensaje,@Usuario

  
   select 0 as id,ERROR_MESSAGE() msg into ##TempDPI
  
END CATCH		
   
END
go

