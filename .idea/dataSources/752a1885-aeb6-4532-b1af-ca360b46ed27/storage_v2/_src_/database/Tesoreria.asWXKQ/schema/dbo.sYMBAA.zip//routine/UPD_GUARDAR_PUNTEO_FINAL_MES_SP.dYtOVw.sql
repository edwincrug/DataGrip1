--    [UPD_GUARDAR_PUNTEO_FINAL_MES_SP] @idEmpresa = 1, @idBanco = 1, @cuentaContable = '1100-0020-0001-0001', @cuentaBancaria='000000000195334667'
CREATE PROCEDURE [dbo].[UPD_GUARDAR_PUNTEO_FINAL_MES_SP]
@idEmpresa INT,
@idBanco INT,
@cuentaContable VARCHAR(20) = '',
@cuentaBancaria VARCHAR(20)= ''

AS
BEGIN TRY
		DECLARE @ultimoDiaMes VARCHAR(20), @primerDiaMes VARCHAR(30),@diaActual VARCHAR(30)
		SET @ultimoDiaMes = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,GETDATE()))),DATEADD(mm,1,GETDATE())),103)
		SET @primerDiaMes = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(GETDATE())),GETDATE()),103) 
		SET @diaActual = CONVERT(VARCHAR(25),GETDATE(),103)
		select @ultimoDiaMes as ultimodiames,@primerDiaMes as primerdiaMes,@diaActual as diaActual
		--Quitar vaidación de fin de mes
		
				

				UPDATE [AuxiliarContable] SET idEstatus = 3 
				FROM [AuxiliarContable] Aux 
				INNER JOIN [PunteoAuxiliarBanco] PunteoAu ON Aux.idAuxiliarContable = PunteoAu.idAuxiliarContable
				WHERE 
				Aux.idEmpresa = @idEmpresa 
				AND Aux.idEstatus = 2
				AND Aux.numeroCuenta = @cuentaContable


				UPDATE PunteoAuxiliarBanco SET [idPunteoFinalBancos] = 3
				FROM DepositoBancoView banco
				INNER JOIN PunteoAuxiliarBanco punteo ON banco.idBmer = punteo.idDepositoBanco
				WHERE 
				banco.idBanco = @idBanco
				AND banco.noCuenta = @cuentaBancaria
				AND punteo.idBanco = @idBanco
				AND punteo.idEmpresa = @idEmpresa 
				

				
				SELECT 1 idEstatus,'Éxito se guardaron los punteos' Descripcion
			
END TRY
BEGIN CATCH
           SELECT ERROR_LINE() +' '+ ERROR_MESSAGE() AS ERROR
END CATCH


go

