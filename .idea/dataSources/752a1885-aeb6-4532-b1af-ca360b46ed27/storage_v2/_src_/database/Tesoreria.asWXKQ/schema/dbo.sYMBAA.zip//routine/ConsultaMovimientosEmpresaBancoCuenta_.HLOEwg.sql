-- =============================================
-- Author:
-- Create date:
-- Description:
-- exec ConsultaMovimientosEmpresaBancoCuenta 2020, 3, 4, '000000000445990351'
-- =============================================
CREATE PROCEDURE [dbo].[ConsultaMovimientosEmpresaBancoCuenta]
@anio int 
,@mes int 
,@idEmpresa int 
,@cuenta varchar(150)
WITH RECOMPILE
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
DECLARE @idbanco INT
--declare @abono table(
--id int
--,descripcion varchar(255)
--,cargo decimal(18,2)
--,abono decimal(18,2)
--,estatus varchar(25)
--,Observacion varchar(max)
--,fechaOperacion varchar(10)
--,fechaOperacion2 datetime
--,aplico varchar(255)
--,idReferencia int
--,grupoPunteo int
--)
--declare @cargo table(
--id int
--,descripcion varchar(255)
--,cargo decimal(18,2)
--,abono decimal(18,2)
--,estatus varchar(25)
--,Observacion varchar(max)
--,fechaOperacion varchar(10)
--,fechaOperacion2 datetime
--,aplico varchar(255)
--,idReferencia int
--,grupoPunteo int
--)
SET @idbanco = (SELECT idbanco from referencias.dbo.BancoCuenta bc WHERE bc.numeroCuenta = @cuenta AND bc.idEmpresa = @idEmpresa  )
;WITH bancos AS (
  SELECT ab.idBmer
  ,0  as cargo
  ,abs(ab.importe) as abono
  , ab.referencia+' - '+ab.concepto+ ' - '+ab.refAmpliada as descripcion
  ,convert(varchar(10),fechaOperacion, 103) as fechaOperacion
  ,fechaOperacion AS fechaOperacion2
  , bc.idBanco
  , bc.idEmpresa
  from referencias.dbo.BancoCuenta bc
left join  ABONOSBANCOS_CB ab
ON bc.numeroCuenta = ab.noCuenta
          AND BC.idEmpresa = AB.idEmpresa
          AND idEstatus = 0
          AND CONVERT(NVARCHAR(10), fechaOperacion, 112) >= '20180601'-- AND '20200331'
          AND ab.idbanco IS NOT NULL
and bc.numeroCuenta = @cuenta
  WHERE ab.idEmpresa = @idEmpresa
    AND ab.IDBanco = @idbanco
    AND ab.idBmer IS NOT NULL
  and  ab.anio <= @anio
and MONTH(fechaOperacion) <= (CASE WHEN AB.anio < @anio then 12 else @mes end)
)
, Punteados AS (
  SELECT DISTINCT
    rp.rpun_idPunteado
    ,rp.rpun_grupoPunteo
        ,rp.rpun_idCargo
        ,rp.rpun_idAbono
        ,rp.rpun_tipo
        ,rp.concepto
        ,rp.rpun_fechaPunteo
        ,rp.rpun_usuario
        ,rp.rpun_idAplicado
        ,rp.idEmpresa
        ,rp.IDBanco
        ,rp.noCuenta
        ,rp.cargos
        ,rp.abonos
        ,rp.mes
        ,rp.anio
        ,rp.idbmer
        ,rp.idMes
    ,ROW_NUMBER() OVER(PARTITION BY rp.idbmer ORDER BY rp.idbmer) AS NumeroFila
  FROM VW_REGISTROS_PUNTEADOS rp
  inner JOIN bancos b
   on rp.idbmer = b.idBmer
and rp.IDBanco = b.IDBanco
and rp.idEmpresa = b.idEmpresa
  WHERE rp.idbmer <> 0
  AND rp.idEmpresa = @idEmpresa 
  AND rp.IDBanco = @idbanco
  AND rp.rpun_idAbono <> 0
  AND rp.rpun_grupoPunteo > 0
  AND rp.rpun_tipo = 'B'
)

,controlAPP AS(
  SELECT distinct 
    idDeposito
    ,dp.idEmpresa
    ,dp.idBanco
    ,idUsuario 
   ,CONVERT(VARCHAR(10), fecha, 103) AS fecha
  FROM referencias..RAPDeposito dp
  inner JOIN bancos b
  ON dp.idEmpresa = b.idEmpresa
  AND dp.idBanco = b.idBanco
  AND dp.idDeposito = b.idBmer
  WHERE dp.idEmpresa = @idEmpresa
  AND dp.idBanco =@idbanco
)

,referencia AS (
  SELECT ref.idReferencia
        ,ref.idEmpresa
        ,ref.fecha
        ,ref.referencia
        ,ref.tipoReferencia
        ,ref.numeroConsecutivo
        ,ref.estatus
        ,ref.depositoID
        ,ref.IDBanco
        ,ref.idUsuario 
  FROM Tesoreria.dbo.Referencia ref
  JOIN bancos b
on b.idBmer = ref.depositoID
  AND b.idBanco = ref.IDBanco
  WHERE ref.IDBanco = @idbanco
)
, bancos2 AS (
  SELECT ab.idBmer
  ,abs(ab.importe)  as cargo
  , 0 as abono
  , ab.referencia+' - '+ab.concepto+ ' - '+ab.refAmpliada as descripcion
  ,convert(varchar(10),fechaOperacion, 103) as fechaOperacion
  ,fechaOperacion AS fechaOperacion2
  , bc.idBanco
  , bc.idEmpresa
  from referencias.dbo.BancoCuenta bc
left join  CARGOSBANCOS_CB ab
ON bc.numeroCuenta = ab.noCuenta
          AND BC.idEmpresa = AB.idEmpresa
          AND idEstatus = 0
          AND CONVERT(NVARCHAR(10), fechaOperacion, 112) >= '20180601'-- AND '20200331'
          AND ab.idbanco IS NOT NULL
and bc.numeroCuenta = @cuenta
  WHERE ab.idEmpresa = @idEmpresa 
  AND ab.IDBanco = @idbanco
  AND ab.idBmer IS NOT NULL
  and  ab.anio <= @anio
and MONTH(fechaOperacion) <= (CASE WHEN AB.anio < @anio then 12 else @mes end) 
)
, Punteados2 AS (
  SELECT DISTINCT
    rp.rpun_idPunteado
    ,rp.rpun_grupoPunteo
        ,rp.rpun_idCargo
        ,rp.rpun_idAbono
        ,rp.rpun_tipo
        ,rp.concepto
        ,rp.rpun_fechaPunteo
        ,rp.rpun_usuario
        ,rp.rpun_idAplicado
        ,rp.idEmpresa
        ,rp.IDBanco
        ,rp.noCuenta
        ,rp.cargos
        ,rp.abonos
        ,rp.mes
        ,rp.anio
        ,rp.idbmer
        ,rp.idMes
    ,ROW_NUMBER() OVER(PARTITION BY rp.idbmer ORDER BY rp.idbmer) AS NumeroFila
  FROM VW_REGISTROS_PUNTEADOS rp
  inner JOIN bancos2 b
   on rp.idbmer = b.idBmer
and rp.IDBanco = b.IDBanco
and rp.idEmpresa = b.idEmpresa
  WHERE rp.idEmpresa = @idEmpresa
    AND rp.IDBanco = @idbanco
    AND rp.idbmer <> 0
  AND rp.rpun_idAbono = 0
  AND rp.rpun_grupoPunteo > 0
  AND rp.rpun_tipo = 'B'
)
,controlAPP2 AS(
  SELECT distinct 
    idDeposito
    ,dp.idEmpresa
    ,dp.idBanco
    ,idUsuario 
   ,CONVERT(VARCHAR(10), fecha, 103) AS fecha
  FROM referencias..RAPDeposito dp
  inner JOIN bancos2 b
  ON dp.idEmpresa = b.idEmpresa
  AND dp.idBanco = b.idBanco
  AND dp.idDeposito = b.idBmer
  WHERE dp.idEmpresa = @idEmpresa
  AND dp.idBanco = @idbanco
)
,referencia2 AS (
  SELECT ref.idReferencia
        ,ref.idEmpresa
        ,ref.fecha
        ,ref.referencia
        ,ref.tipoReferencia
        ,ref.numeroConsecutivo
        ,ref.estatus
        ,ref.depositoID
        ,ref.IDBanco
        ,ref.idUsuario 
  FROM Tesoreria.dbo.Referencia ref
  inner JOIN bancos2 b
on b.idBmer = ref.depositoID
  AND b.idBanco = ref.IDBanco
  WHERE ref.IDBanco = @idbanco
)

SELECT DISTINCT 
  b.idBmer as id
 ,b.descripcion
 ,b.cargo
 ,b.abono
 ,case when ((isnull(p.rpun_idPunteado,0)>0) OR (isnull(cap.idDeposito,0)>0)) then 'Identificado' else 'No identificado' end as estatus
 ,isnull(pimb.Observacion,'') as Observacion
 ,b.fechaOperacion
 ,b.fechaOperacion2
 , case when ((isnull(p.rpun_idPunteado,0)>0) OR (isnull(cap.idDeposito,0)>0)) 
 then 'Aplicó: '+isnull((cu.usu_nombre+' '+ cu.usu_paterno+' '+ cu.usu_materno),'Sin Dato')+ ' el día '+ isnull(CONVERT(VARCHAR(10),cap.fecha,103),'Sin Dato')
 else '' end   as aplico
 ,ref.idReferencia
 ,p.rpun_grupoPunteo AS grupoPunteo
  FROM bancos b
  LEFT JOIN Punteados p
    ON b.idBmer = p.idbmer
    AND b.idEmpresa = p.idEmpresa
    AND b.idBanco = p.IDBanco
  AND p.NumeroFila = 1
  LEFT JOIN controlAPP cap
  ON b.idBmer = cap.idDeposito
  LEFT JOIN referencia ref
  ON b.idEmpresa = ref.idEmpresa
  AND b.idBanco = ref.IDBanco
  AND b.idBmer = ref.depositoID
left join PreIdentitificacionMovimientosBancarios pimb
  on b.idBmer = pimb.idMovimiento
  and pimb.activo = 1
  and pimb.tipoMovimiento = 'A'
LEFT JOIN ControlAplicaciones..cat_usuarios cu
ON cap.idUsuario = cu.usu_idusuario
union all
--insert into @cargo
SELECT DISTINCT 
  b.idBmer
 ,b.descripcion
 ,b.cargo
 ,b.abono
 ,case when ((isnull(p.rpun_idPunteado,0)>0) OR (isnull(cap.idDeposito,0)>0)) then 'Identificado' else 'No identificado' end as estatus
 ,isnull(pimb.Observacion,'') as Observacion
 ,b.fechaOperacion
 ,b.fechaOperacion2
, case when ((isnull(p.rpun_idPunteado,0)>0) OR (isnull(cap.idDeposito,0)>0)) 
then 'Aplicó: '+isnull((cu.usu_nombre+' '+ cu.usu_paterno+' '+ cu.usu_materno),'Sin Dato')+ ' el día '+ isnull(CONVERT(VARCHAR(10),cap.fecha,103),'Sin Dato')
else '' end   as aplico
  ,ref.idReferencia
 ,p.rpun_grupoPunteo AS grupoPunteo
  FROM bancos2 b
  LEFT JOIN Punteados2 p
    ON b.idBmer = p.idbmer
    AND b.idEmpresa = p.idEmpresa
    AND b.idBanco = p.IDBanco
  AND p.NumeroFila = 1
  LEFT JOIN controlAPP2 cap
  ON b.idBmer = cap.idDeposito
  LEFT JOIN referencia2 ref
  ON b.idEmpresa = ref.idEmpresa
  AND b.idBanco = ref.IDBanco
  AND b.idBmer = ref.depositoID
left join PreIdentitificacionMovimientosBancarios pimb
  on b.idBmer = pimb.idMovimiento
  and pimb.activo = 1
  and pimb.tipoMovimiento = 'C'
  LEFT JOIN ControlAplicaciones..cat_usuarios cu
ON cap.idUsuario = cu.usu_idusuario
--select id 
--,descripcion 
--,cargo 
--,abono 
--,estatus 
--,Observacion 
--,fechaOperacion 
--,fechaOperacion2 
--,aplico 
--,idReferencia 
--,grupoPunteo
--from @abono
--union all
--select id 
--,descripcion 
--,cargo 
--,abono 
--,estatus 
--,Observacion 
--,fechaOperacion 
--,fechaOperacion2 
--,aplico 
--,idReferencia 
--,grupoPunteo 
--from @cargo
--order by 8 desc
END
go

