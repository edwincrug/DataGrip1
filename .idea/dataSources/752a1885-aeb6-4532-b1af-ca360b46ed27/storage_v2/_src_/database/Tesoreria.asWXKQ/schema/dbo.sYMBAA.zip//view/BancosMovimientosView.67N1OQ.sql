CREATE VIEW [dbo].[BancosMovimientosView]
AS
select b.idEmpresa,idBmer, x.IDBanco, txtOrigen, registro, noMovimiento, referencia, concepto, refAmpliada, esCargo, importe, saldoOperativo, codigoLeyenda, oficinaOperadora, 
                      fechaOperacion, horaOperacion, fechaValor, fechaContable, estatus, noCuenta 
from [dbo].[controlDepositosView] x
left JOIN [referencias].[dbo].[BancoCuenta] B on x.idbanco=b.idBanco and x.noCuenta=b.numeroCuenta
go

