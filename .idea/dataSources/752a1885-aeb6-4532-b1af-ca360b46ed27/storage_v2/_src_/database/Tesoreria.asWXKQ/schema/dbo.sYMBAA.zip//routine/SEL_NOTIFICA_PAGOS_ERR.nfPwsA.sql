-- =============================================
-- Author:		Roberto Almanza Nieto	
-- Create date: 02-04-2019
-- Description: Monitor de Pagos no relacionados
-- =============================================
CREATE PROCEDURE [dbo].[SEL_NOTIFICA_PAGOS_ERR]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
/*================================================================
				Pagos no relacionados
================================================================*/
 DECLARE @tabladatos3 TABLE(
 idDoctoPagado int
 ,consCartera int
 ,idDocumento varchar(150)
 ,idPersona int
 ,cuentaPagadora varchar(150)
 ,cuentaBeneficiario varchar(150)
 ,importePagado decimal(18,2)
 ,folioOrden varchar(150)
 ,pagoAplicado int
 ,lote int
 ,idEmpresa int
 ,fechaAplicacion datetime --varchar(100)
 ,consCaraPl varchar(10)
 ,mes varchar(2)
 ,convenioCie varchar(150)
 )

 DECLARE @tableHtml3 nvarchar(max)
 ,@destinatarios varchar(250)

 SELECT @destinatarios = destinatarios FROM DestinatariosMonitores WHERE id=3

 INSERT INTO @tabladatos3
 (
     idDoctoPagado,
     consCartera,
     idDocumento,
     idPersona,
     cuentaPagadora,
     cuentaBeneficiario,
     importePagado,
     folioOrden,
     pagoAplicado,
     lote,
     idEmpresa,
     fechaAplicacion,
     consCaraPl,
     mes,
     convenioCie
 )
select p.dpa_iddoctopagado
, p.dpa_conscartera
, p.dpa_iddocumento
, p.dpa_idpersona
, p.dpa_cuentapagadora
, p.dpa_cuentabeneficiario
, p.dpa_importepagado
, p.dpa_folioorden
, p.dpa_pagoaplicado
, p.dpa_lote
, p.dpa_idempresa
, p.dpa_fechaaplicacion
, p.dpa_conscarapl
, p.dpa_mes
, p.dpa_conveniocie--case when len(p.dpa_conveniocie) < 1 then 'Sin Dato' else p.dpa_conveniocie end as dpa_conveniocie
from [cuentasxpagar].[dbo].[cxp_doctospagados] p
left join PAGOS.DBO.PAG_REL_DOCTOS_BANCOS r 
on p.dpa_iddoctopagado=r.dpa_iddoctopagado
left  join dbo.CARGOSBANCOS_CB c   
on c.idBmer=r.idBanco_Registro and r.idBanco=c.IDBanco
where  month(dpa_fechaaplicacion )= month(getdate())
and r.dpa_iddoctopagado is null 
and year(dpa_fechaaplicacion )=year(getdate())
AND p.dpa_importepagado > 0.02
AND dpa_mes = month(getdate())
ORDER BY p.dpa_idempresa ASC

 if( @@ROWCOUNT > 0 )
 BEGIN

 	SET @tableHTML3 =
		N'<html>'+
		N'<head>'+
		N'<style>'+
		N'table {'+
		N'border-collapse: collapse;'+
		N'width: 100%;'+
		N'}'+
		N'th, td {'+
		N'text-align: left;'+
		N'padding: 8px;'+
		N'font-size: x-small;'+
		N'}'+
		N'th {'+
		N'text-align: center;'+
		N'}'+
		N'tr:nth-child(even) {background-color: #E6F2FF;}'+
		N'</style>'+
		N'</head>' +
		N'<body>' +
		N'<div style="overflow-x:auto;">'+
        N'<H1>Pagos no relacionados</H1>' +
        N'<table>' +
        N'<tr>'+
			N'<th>idDoctoPagado</th>' +
			N'<th>consCartera</th>'+
			N'<th>idDocumento</th>' +
			N'<th>idPersona</th>'+
			N'<th>cuentaPagadora</th>' +
			N'<th>cuentaBeneficiario </th>'+
			N'<th>importePagado</th>' +
			N'<th>folioOrden</th>'+
			N'<th>pagoAplicado</th>' +
			N'<th>lote</th>'+
			N'<th>idEmpresa</th>' +
			N'<th>fechaAplicacion</th>'+
			N'<th>consCaraPl</th>' +
			N'<th>mes</th>'+
			N'<th>convenioCie</th>' +
		N'</tr>' +
        CAST ( ( SELECT  td = idDoctoPagado , ''
						,td = consCartera , ''
						,td = idDocumento , ''
						,td = idPersona , ''
						,td = cuentaPagadora , ''
						,td = cuentaBeneficiario , ''
						,td = importePagado , ''
						,td = folioOrden , ''
						,td = pagoAplicado , ''
						,td = lote , ''
						,td = idEmpresa , ''
						,td = fechaAplicacion , ''
						,td = consCaraPl , ''
						,td = mes , ''
						,td = convenioCie , ''
                  FROM @tabladatos3
                  FOR XML PATH('tr'), TYPE 
        ) AS NVARCHAR(MAX) ) +      
        N'</table>'+
		N'</div>'+
		N'</body>'+
		N'</html>'

		EXEC msdb.dbo.sp_send_dbmail  
		@profile_name = null,  
		@recipients = @destinatarios,   
		@subject = 'Reporte de incidencias de pagos no relacionados',  
		@body = @tableHTML3,
		@body_format = 'HTML'
 END

END
go

