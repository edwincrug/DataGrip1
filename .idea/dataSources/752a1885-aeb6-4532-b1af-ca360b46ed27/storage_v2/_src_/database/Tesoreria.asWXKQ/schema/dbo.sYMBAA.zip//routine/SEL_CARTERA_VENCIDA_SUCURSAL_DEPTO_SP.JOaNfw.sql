
--EXECUTE SEL_CARTERA_VENCIDA_SUCURSAL_DEPTO_SP    @idCliente = 480152 , @idEmpresas = 14, @idSucursales ='39', @idDepartamentos = '333', @fechaInicio='06-01-2018',@fechaFin='06-04-2020'
CREATE PROCEDURE [dbo].[SEL_CARTERA_VENCIDA_SUCURSAL_DEPTO_SP] @idCliente INT
, @idEmpresas INT
, @idSucursales NVARCHAR(MAX) = ''
, @idDepartamentos NVARCHAR(MAX) = ''
, @fechaInicio VARCHAR(10) = NULL
, @fechaFin VARCHAR(10) = NULL
AS
BEGIN
  IF( @idSucursales = 0 )
  	BEGIN
  		SET @idSucursales = NULL;
  	END

  	EXECUTE [INS_CARTERA_VENCIDA_SP] @idCliente, @idEmpresas

  IF (@fechaInicio IS NULL
    AND @fechaFin IS NULL)
  BEGIN
    PRINT ('Sin fecha');

    SELECT
	 0 as checked
     , IDB
     ,folio
     ,serie
     ,idDocumento
     ,CV.idEmpresa
     ,nombreEmpresa
     ,CV.idSucursal
     ,nombreSucursal
     ,CV.idDepartamento
     ,nombreDepartamento
     ,origenMovimiento
     ,importe
     ,CASE WHEN importeDocumento IS NULL THEN CONVERT(NUMERIC(18,2),saldo) ELSE (saldo - importeDocumento) END saldo
     ,nombreCliente
     ,CONVERT(VARCHAR(20), fecha, 111) fecha
     ,CV.idCliente
     ,referencia
     ,tipoDocumento
     ,idStatus
    FROM CarteraVencida CV
    LEFT JOIN (SELECT
        SUM(importeDocumento) importeDocumento
       ,documento
       ,estatus
       ,idEmpresa
      FROM [DetalleReferencia] DET
      INNER JOIN [Referencia] REF
        ON DET.idReferencia = REF.idReferencia
		where isnull(estatus,0)=0
      GROUP BY documento
              ,estatus
              ,idEmpresa) DRE
      ON CV.folio = DRE.documento
        AND CV.idEmpresa = DRE.idEmpresa
    WHERE idstatus = 1
    AND CV.idCliente = @idCliente
    AND CV.idEmpresa = @idEmpresas
    AND (CAST(@idSucursales AS VARCHAR(5)) = ''
    OR (CHARINDEX(',' + CAST(CV.idSucursal AS VARCHAR(5)) + ',', ',' + @idSucursales + ',') > 0))
    AND (CAST(@idDepartamentos AS VARCHAR(5)) = ''
    OR (CHARINDEX(',' + CAST(CV.idDepartamento AS VARCHAR(5)) + ',', ',' + @idDepartamentos + ',') > 0))
    --AND (estatus IS NULL)
    AND CONVERT(DECIMAL(18, 5), CV.importe) > 0.0
	 and CASE WHEN importeDocumento IS NULL THEN CONVERT(NUMERIC(18,2),saldo) ELSE (saldo - importeDocumento)end >0.0
    ORDER BY CONVERT(VARCHAR(20), fecha, 111), CV.idSucursal
  -- AND( estatus IS NULL OR estatus = 2 ) -- DEBERIA SER DE ESTA MANERA
  END
  ELSE
  BEGIN
    SET @fechaInicio = SUBSTRING(@fechaInicio, 7, 4) + SUBSTRING(@fechaInicio, 4, 2) + SUBSTRING(@fechaInicio, 1, 2)
    SET @fechaFin = SUBSTRING(@fechaFin, 7, 4) + SUBSTRING(@fechaFin, 4, 2) + SUBSTRING(@fechaFin, 1, 2)

    SELECT
	 0 as checked
     , IDB
     ,folio
     ,serie
     ,idDocumento
     ,CV.idEmpresa
     ,nombreEmpresa
     ,CV.idSucursal
     ,nombreSucursal
     ,CV.idDepartamento
     ,nombreDepartamento
     ,origenMovimiento
     ,importe
     ,CASE WHEN importeDocumento IS NULL THEN CONVERT(NUMERIC(18,2),saldo) ELSE (saldo - importeDocumento) END saldo
     ,nombreCliente
     ,CONVERT(VARCHAR(20), fecha, 111) fecha
     ,CV.idCliente
     ,referencia
     ,tipoDocumento
     ,idStatus
    FROM CarteraVencida CV
    LEFT JOIN (SELECT
        SUM(importeDocumento) importeDocumento
       ,documento
       ,estatus
       ,idEmpresa
      FROM [DetalleReferencia] DET
      INNER JOIN [Referencia] REF
        ON DET.idReferencia = REF.idReferencia
		where isnull(estatus,0)=0
      GROUP BY documento
              ,estatus
              ,idEmpresa) DRE
      ON CV.folio = DRE.documento
        AND CV.idEmpresa = DRE.idEmpresa
    WHERE idstatus = 1
    AND CV.idCliente = @idCliente
    AND CV.idEmpresa = @idEmpresas
    AND (CAST(@idSucursales AS VARCHAR(5)) = ''
    OR (CHARINDEX(',' + CAST(CV.idSucursal AS VARCHAR(5)) + ',', ',' + @idSucursales + ',') > 0))
    AND (CAST(@idDepartamentos AS VARCHAR(5)) = ''
    OR (CHARINDEX(',' + CAST(CV.idDepartamento AS VARCHAR(5)) + ',', ',' + @idDepartamentos + ',') > 0))
    --AND (estatus IS NULL)
    --AND( estatus IS NULL OR estatus = 2 ) -- DEBERIA SER DE ESTA MANERA
    AND fecha BETWEEN @fechaInicio AND @fechaFin
    AND CONVERT(DECIMAL(18, 5), CV.importe) > 0.0
	 and CASE WHEN importeDocumento IS NULL THEN CONVERT(NUMERIC(18,2),saldo) ELSE (saldo - importeDocumento)end >0.0
    ORDER BY CONVERT(VARCHAR(20), fecha, 111), CV.idSucursal
  END
END
go

