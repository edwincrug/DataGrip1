

CREATE procedure [dbo].[SEL_LAYOUT_TXT_BANCO_PAGO_SP] 
@idEmpresa as integer = 0,
@idBanco as integer = 0,
@fechaInicial as varchar(25) = '',
@fechaFinal as varchar(25) = ''

as
begin

	select 
		1 AS idBanco,
		idBmer,
		'Bancomer' banco,
		txtOrigen ,
		noCuenta cuenta,
		concepto,
		esCargo,
		importe,
		saldoOperativo,
		referencia,
		fechaOperacion,
		horaOperacion,
		oficinaOperadora 
	from 
		referencias.dbo.Bancomer 
union
	select 
	2 AS idBanco,
		idSantander,
		'Santander' banco ,
		txtOrigen,
		noCuenta,
		concepto,
		case signo  when '-' then '0' else '1' end signo,
		importe,
		saldo,
		referencia,
		fechaMovimiento,
		horaMovimiento,
		sucursal  
	from 
		referencias.dbo.Santander
		end
go

