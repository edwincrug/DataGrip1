-- =============================================
-- Author:		Ing. Luis Antonio Gacia Perrusquia
-- Create date: 22/06/2018
-- Description:	Insertamos los datos del exel
-- TEST EXEC [DBO].[INS_LAYOUT_SP] '105429576', '6/22/18', 'Prueba1', '1234345', 'Luis1', 'Cargo', 100, 0 
/*
	EXEC [DBO].[INS_LAYOUT_SP] '106442297', '31/07/2018', 'Pago Servicio Honda Amarillo', '2174615176', 'SEL TRASPASO ENTRE CUENTAS ', '2', '1800', '0', 0
	
	EXEC [DBO].[INS_LAYOUT_SP] '105967819', '08/08/2018', '', '216246843', 'ABONO DISPOSICION PLAN PISO', '1', '0', '6367800.01', 0
	EXEC [DBO].[INS_LAYOUT_SP] '105967819',	'08/08/2018',	'',	'216246843',	'ABONO DISPOSICION PLAN PISO'	,'',	'0',	'6367800.01', 0
*/
-- =============================================
--[dbo].[INS_LAYOUT_SP] '190701289','01/03/2019','movmarzo2','movmarzo2','movmarzo2','2','1000',0,0,779
CREATE PROCEDURE [dbo].[INS_LAYOUT_SP]
	@noCuenta VARCHAR(50) = '',
	@fecha VARCHAR(10) = '',
	@descripcion VARCHAR(500) = '',
	@referencia VARCHAR(50) = '',
	@desAmpliada VARCHAR(500) = '',
	@tipoMovimiento VARCHAR(50) = '',
	@cargo VARCHAR(25) = '0',
	@abono VARCHAR(25) = '0',
	@grupoIns INT = 0,
	@idUsuario int=0
AS
BEGIN

	DECLARE @idEmpresa INT = 0, @idBanco INT = 0, @cuenta VARCHAR (50) = '', @periodo INT = 0, @anio INT = 0, @idCargaLayout INT = 0, @id int;
	
	IF( @grupoIns = 0)
		BEGIN
			SELECT 
				@grupoIns = (ISNULL(MAX(idGrupoIns), 0)) + 1 
			FROM [referencias].[dbo].[MovimientoBancarioLayout]
		END

	SELECT 
		@idEmpresa = idEmpresa, 
		@idBanco = idBanco,
		@cuenta = numeroCuenta,
		@idCargaLayout = Carga_Layout
	--	select *
	FROM [referencias].[dbo].[BancoCuenta] 
	WHERE numeroCuenta like '%'+ @noCuenta;
	SELECT 
		@periodo = mec_numMes,
		@anio = mec_anio
	FROM PeriodoActivo 
	WHERE   idEmpresa = @idEmpresa 
			AND idBanco = @idBanco 
			AND cuentaBancaria = @cuenta;
	BEGIN TRY
	IF(EXISTS(select * from usuarioPermisos where idusuario = @idusuario) or convert(date,@fecha,103)>=convert(date,'01/'+RIGHT('0' + Ltrim(Rtrim(convert(nvarchar(2),@periodo))),2)+'/'+convert(nvarchar(4),@anio),103))
			BEGIN 
				IF(@idCargaLayout != 0)
					BEGIN 
						IF( @fecha != NULL OR @fecha != '' )
							BEGIN
								IF( @idEmpresa != 0 )
									BEGIN
										INSERT INTO [referencias].[dbo].[MovimientoBancarioLayout]
											([noCuenta]
											,[fecha]
											,[descripcion]
											,[referencia]
											,[descripcionAmpliada]
											,[tipoMovimiento]
											,[cargo]
											,[abono]
											,[idEmpresa]
											,[idBanco]
											,[fechaRegistro]
											,[idGrupoIns])
										VALUES
										( 
											@cuenta, 
											CONVERT(DATE,@fecha, 103), 
											ISNULL(@descripcion, ''), 
											ISNULL (@referencia, ''), 
											ISNULL (@desAmpliada, ''), 
											@tipoMovimiento, 
											ISNULL(REPLACE( CONVERT(NUMERIC (18,5), @cargo), ',', ''), 0), 
											ISNULL(REPLACE( CONVERT(NUMERIC (18,5), @abono), ',', ''), 0), 
											@idEmpresa, 
											@idBanco, 
											GETDATE(),
											@grupoIns
										)

										set @id = SCOPE_IDENTITY()

							
									DECLARE @concepto varchar(50)=ISNULL(@descripcion, '')
									DECLARE @refAmpliada varchar(50)=ISNULL (@desAmpliada, '')
									Set @referencia=ISNULL (@referencia, '')
									DECLARE @esCargo int = case when convert(numeric(18,2),@cargo)>0 then 1 when convert(numeric(18,2),@abono)>0 then 0 end
									DECLARE @importe numeric(18,2) = case when convert(numeric(18,2),@cargo)>0.00 then  convert(numeric(18,2),@cargo) when  convert(numeric(18,2),@abono)>0.00 then  convert(numeric(18,2),@abono) else 0.00 end
									DECLARE @fechaOperacion date=CONVERT(DATE,@fecha, 103)
								

									-- TODO: Set parameter values here.

									EXECUTE  [Tesoreria].[dbo].[INT_CONCILIACION_ADDBANCOS_SP] 
									   @referencia
									  ,@concepto
									  ,@refAmpliada
									  ,@Cuenta
									  ,@esCargo
									  ,@importe
									  ,@fechaOperacion
									  ,@idUsuario
									  ,@idEmpresa
									  ,@idBanco
									  ,@anio
									  ,@id

										SELECT success = 1, msg = '';
									END
								ELSE
									BEGIN
										SELECT success = 0, msg = 'Registro con numero de cuenta incorrecta';
									END
							END
					ELSE
						BEGIN
							SELECT success = 0, msg = 'Registro sin Fecha';
						END	
			END
		ELSE
			BEGIN
				SELECT success = 0, msg = 'El numero de cuenta no permite la carga por layout.';
			END
	END
	ELSE
	BEGIN
		SELECT success = 0, msg = 'No tiene permitido cargar registros fuera del periodo.';
	END
	END TRY

	BEGIN CATCH
		SELECT success = 0,msg = 'El registro con referencia '+ ' ' + @referencia + ' fecha ' + @fecha  + ' no se inserto ' + ERROR_LINE() + ' ' + ERROR_MESSAGE();
	END CATCH
END
go

