/*
	[SEL_AUXILIAR_CONTABLE_EMPRESA_CUENTA_SP_H] @idEmpresa = 1, @idBanco = 1,@idHistorico = 26
*/
CREATE PROCEDURE [dbo].[SEL_AUXILIAR_CONTABLE_EMPRESA_CUENTA_SP_H]
@idEmpresa INT,
@idBanco INT,
--@noCuenta VARCHAR(100),
--@idEstatus INT,
@fechaElaboracion VARCHAR(50),
--@fechaCorte VARCHAR(50),
--@polizaPago VARCHAR(30),
--@cuentaBancaria VARCHAR(30),
@idHistorico NUMERIC(18,0) = 0	
AS
BEGIN TRY

IF @idBanco = 1
BEGIN
      --EXECUTE [DBO].[SEL_AUXILIAR_CONTABLE_BANCOMER] @idEmpresa, @noCuenta, @idEstatus, @fechaElaboracion, @fechaCorte, @polizaPago, @cuentaBancaria
		DECLARE @mesActual INT;
		SELECT @mesActual = DATEPART(MONTH,REPLACE(@fechaElaboracion,'-',''))
		SELECT	MOV.IDABONOS_COMPLETO idAuxiliarContable,--MOV_CONSPOL idAuxiliarContable,
				@idEmpresa idEmpresa,
				MOV.MOV_CONSMOV movConsMov, --?
				MOV.MOV_NUMCTA numeroCuenta,
				MOV.MOV_TIPOPOL polTipo,
				MOV.MOV_CONSPOL polConsecutivo,
				MOV.MOV_CONCEPTO movConcepto,
				MOV.MOV_DEBE cargo,
				MOV.MOV_HABER abono,
				MOV.MOV_FECHOPE movFechaOpe,
				MOV.MOV_HORAOPE movHoraOpe,
				1 idEstatus,
				0 fechaAnterior,
				'' color,
				'' referenciaAuxiliar,
				UPPER(DATENAME(YEAR, CONVERT(DATE,MOV_FECHOPE,103))) anio,
				UPPER(DATENAME(month, CONVERT(DATE,MOV_FECHOPE,103))) MES,
			 	0 esCargo
		--SELECT --@totalAbonoContable = SUM(MOV_HABER) --Abonos_Contables_noBancarios 
			 FROM [ABONOS_COMPLETO_CB_H] MOV
			 LEFT JOIN PunteoAuxiliarBanco PUNTEO ON MOV.MOV_CONSPOL = PUNTEO.MOV_CONSPOL --CB.IDABONOS_COMPLETO = PUNTEO.idAuxiliarContable 
								AND MOV.MOV_MES = PUNTEO.MOV_MES
								AND MOV.MOV_TIPOPOL COLLATE SQL_Latin1_General_CP1_CI_AS = PUNTEO.MOV_TIPOPOL
								AND MOV.MOV_CONSMOV = PUNTEO.MOV_CONSMOV
   			 WHERE MOV.MOV_MES = @mesActual --AND MOV_NUMCTA = @noCuenta 
   			 AND PUNTEO.idAuxiliarContable IS NULL
				--AND CB.MOV_MES NOT IN (@mesActual)
				AND MOV.MOV_MES = @mesActual --LAGP
			 --AND MOV_CONSPOL NOT IN (SELECT idAuxiliarContable FROM PunteoAuxiliarBanco)
END
IF @idBanco = 2
BEGIN
   SELECT 'BANCO NO DISPONIBLE' AS ERROR 
END
IF @idBanco = 3
BEGIN
	print '2222' 
   --EXECUTE [DBO].[SEL_AUXILIAR_CONTABLE_SANTANDER] @idEmpresa, @noCuenta, @idEstatus, @fechaElaboracion, @fechaCorte, @polizaPago, @cuentaBancaria
END

 --Selecciono el  último idPunteoAuxiliar para tener un identificador que relacione las conciliaciones Contables
 SELECT 
		ISNULL(idDepositoBanco,0) 
		AS idRelationOfContableRows 
        FROM [PunteoAuxiliarBanco]
		WHERE idPAdre = 3
		AND idPunteoAuxiliarBanco = (Select ISNULL(MAX(idPunteoAuxiliarBanco),0)
									 FROM [PunteoAuxiliarBanco]
									 WHERE idPAdre =3
									 AND idBanco = @idBanco
									 AND idEmpresa = @idEmpresa)
	    AND idEmpresa = @idEmpresa
		AND idBanco = @idBanco

END TRY
BEGIN CATCH
			SELECT ERROR_MESSAGE() +'' + ERROR_LINE() AS ERROR
END CATCH
go

