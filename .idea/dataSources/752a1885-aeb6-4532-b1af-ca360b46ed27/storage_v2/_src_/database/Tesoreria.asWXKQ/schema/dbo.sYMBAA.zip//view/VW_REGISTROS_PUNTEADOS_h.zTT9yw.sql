







--select * from [dbo].[VW_REGISTROS_PUNTEADOS]

/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW [dbo].[VW_REGISTROS_PUNTEADOS_h] AS
select  [rpun_idPunteado]
      ,[rpun_grupoPunteo]
      ,Max([rpun_idCargo]) [rpun_idCargo]
      ,MAx([rpun_idAbono]) [rpun_idAbono]
      ,MAx([rpun_tipo]) [rpun_tipo]
	  ,MAx([concepto]) [concepto]
      ,MAx([rpun_fechaPunteo]) [rpun_fechaPunteo]
      ,MAx([rpun_usuario]) [rpun_usuario]
      ,MAx([rpun_idAplicado])  [rpun_idAplicado]
	  ,MAx(idEmpresa) idEmpresa
	  ,MAx(IDBanco) IDBanco
	  ,MAx(noCuenta) noCuenta
	  ,sum(cargos) cargos
	  ,sum(abonos) abonos
	  ,MAx(mes) mes
	  ,MAx(anio) anio
	  ,MAx(idbmer) idbmer 
	  ,Max(idHistorico) idHistorico from (
 select  [rpun_idPunteado]
      ,[rpun_grupoPunteo]
      ,[rpun_idCargo]
      ,[rpun_idAbono]
	  ,c.concepto
      ,[rpun_tipo]
      ,[rpun_fechaPunteo]
      ,[rpun_usuario]
      ,[rpun_idAplicado] 
	  ,c.idEmpresa
	  ,c.IDBanco
	  ,c.noCuenta
	  ,c.importe cargos
	  ,0 abonos
	  ,pa.perido mes
	  ,pa.anio anio
	  ,c.idBmer
	  ,r.idHistorico idHistorico
	  from [dbo].[REGISTROS_PUNTEADOS_h] r 
 left join [dbo].CARGOSBANCOS_CB_h c on r.rpun_idCargo=c.IDCARGOSBANCOS and rpun_tipo='B'
 inner join dbo.HISTORICO_CONCILIACION pa on pa.idHistorico=r.idHistorico
union all
 select  [rpun_idPunteado]
      ,[rpun_grupoPunteo]
      ,[rpun_idCargo]
      ,[rpun_idAbono]
	  ,c.concepto
      ,[rpun_tipo]
      ,[rpun_fechaPunteo]
      ,[rpun_usuario]
      ,[rpun_idAplicado] 
	  ,c.idEmpresa
	  ,c.IDBanco
	  ,c.noCuenta
	  ,0 cargos
	  ,c.importe abonos
	  ,pa.perido mes
	  ,pa.anio anio
	  ,c.idBmer
	  ,r.idHistorico idHistorico
	  from [dbo].[REGISTROS_PUNTEADOS_h] r 
 left join [dbo].ABONOSBANCOS_CB_h c on r.rpun_idAbono=c.IDABONOSBANCOS and rpun_tipo='B'
 inner join dbo.HISTORICO_CONCILIACION pa on pa.idHistorico=r.idHistorico

union all
 select  [rpun_idPunteado]
      ,[rpun_grupoPunteo]
      ,[rpun_idCargo]
      ,[rpun_idAbono]
	  ,c.MOV_CONCEPTO
      ,[rpun_tipo]
      ,[rpun_fechaPunteo]
      ,[rpun_usuario]
      ,[rpun_idAplicado] 
	  ,c.idEmpresa
	  ,c.IDBanco
	  ,c.MOV_NUMCTA noCuenta
	  ,c.MOV_DEBE cargos
	  ,c.MOV_HABER abonos
	  ,pa.perido mes
	  ,pa.anio anio
	  ,0 idBmer
	  ,r.idHistorico idHistorico
	  from [dbo].[REGISTROS_PUNTEADOS_h] r 
 left join [dbo].CARGOS_COMPLETO_CB_h c on r.rpun_idCargo=c.IDCARGOS_COMPLETO and rpun_tipo='C'
 inner join dbo.HISTORICO_CONCILIACION pa on pa.idHistorico=r.idHistorico

union all
select  [rpun_idPunteado]
      ,[rpun_grupoPunteo]
      ,[rpun_idCargo]
      ,[rpun_idAbono]
	  ,c.MOV_CONCEPTO
      ,[rpun_tipo]
      ,[rpun_fechaPunteo]
      ,[rpun_usuario]
      ,[rpun_idAplicado] 
	  ,c.idEmpresa
	  ,c.IDBanco
	  ,c.MOV_NUMCTA noCuenta
	  ,c.MOV_DEBE cargos
	  ,c.MOV_HABER abonos
	  ,pa.perido mes
	  ,pa.anio anio
	  ,0 idBmer
	  ,r.idHistorico idHistorico
	  from [dbo].[REGISTROS_PUNTEADOS_h] r 
 left join [dbo].ABONOS_COMPLETO_CB_h c on r.rpun_idAbono=c.IDABONOS_COMPLETO and rpun_tipo='C'
 inner join dbo.HISTORICO_CONCILIACION pa on pa.idHistorico=r.idHistorico

 ) x group by [rpun_idPunteado]
      ,[rpun_grupoPunteo]


go

