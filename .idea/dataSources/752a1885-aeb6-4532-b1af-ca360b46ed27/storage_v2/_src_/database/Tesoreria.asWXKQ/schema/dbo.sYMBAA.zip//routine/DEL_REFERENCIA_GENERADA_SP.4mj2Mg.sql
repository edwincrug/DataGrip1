CREATE procedure [dbo].[DEL_REFERENCIA_GENERADA_SP]

@idReferencia as int

as
begin
	delete from detallereferencia where idreferencia = @idReferencia
	delete  from referencia where idreferencia = @idReferencia
	update depositoBanco set  idReferencia=0 ,idEstatus =1  where idreferencia = @idReferencia
	update carteravencida set referencia=0 ,idstatus =1 where referencia = @idReferencia
end
go

