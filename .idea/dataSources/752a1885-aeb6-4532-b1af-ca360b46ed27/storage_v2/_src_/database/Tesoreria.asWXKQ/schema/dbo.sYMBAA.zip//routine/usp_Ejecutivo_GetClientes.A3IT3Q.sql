CREATE PROCEDURE [dbo].[usp_Ejecutivo_GetClientes](
	@id_clientes NVARCHAR(100),
	@clientes NVARCHAR(1000) OUTPUT
)AS

DECLARE @sql NVARCHAR(1000)

IF @id_clientes = '**Todos**'
BEGIN
	SET @clientes = @id_clientes
END
ELSE
BEGIN
	SET @sql = N'SET @clientesOUT = ''''
		SELECT @clientesOUT = @clientesOUT + ''; '' + cliente
		FROM dbo.tblClientes
		WHERE id_cliente IN (' + @id_clientes + ')'
	
	EXEC sp_executesql @sql,
		N'@clientesOUT NVARCHAR(2000) OUTPUT',
		@clientesOUT = @clientes OUTPUT
	
	SET @clientes = Right(@clientes, LEN(@clientes)-2)

	select @clientes
END
go

