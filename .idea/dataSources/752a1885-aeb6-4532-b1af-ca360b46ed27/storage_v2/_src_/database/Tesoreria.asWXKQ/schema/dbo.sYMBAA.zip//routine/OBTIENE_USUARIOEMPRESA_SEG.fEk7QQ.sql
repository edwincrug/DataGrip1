-- =============================================
-- Author: Roberto Almanza
-- Create date: 27-12-2019
-- Description: Obtiene el catalogo de empresas a las que tiene acceso el usuario en
-- el portal de consulta de movimientos
-- =============================================
CREATE PROCEDURE dbo.OBTIENE_USUARIOEMPRESA_SEG
-- Add the parameters for the stored procedure here
@idUsuario int
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
SELECT -1 AS id,
'SELECCIONA TODAS' as nombre
union
    SELECT DISTINCT ce.emp_idempresa AS id
, emp_nombre AS nombre
FROM Seguridad.dbo.SEG_USUARIO_EMPRESA ue
JOIN  [ControlAplicaciones].[dbo].[cat_empresas] ce
ON ue.id_empresa = ce.emp_idempresa
WHERE id_empleado = @idUsuario
ORDER BY  1
END
go

exec sp_addextendedproperty 'MS_Description',
     'Obtiene los permisos del usuario para el portal de consulta de movimientos', 'SCHEMA', 'dbo', 'PROCEDURE',
     'OBTIENE_USUARIOEMPRESA_SEG'
go

exec sp_addextendedproperty 'MS_Description', 'id del usuario logeado', 'SCHEMA', 'dbo', 'PROCEDURE',
     'OBTIENE_USUARIOEMPRESA_SEG', 'PARAMETER', '@idUsuario'
go

