-- =============================================
-- Author:
-- Create date:
-- Description:
-- =============================================
CREATE PROCEDURE dbo.TransferenciasBancarias_SP
@idempresa int
,@idSucursal int = 6
,@cuentaOrigen varchar(150)
,@cuentaDestino varchar(150)
,@monto decimal(18,2)
,@idUsuario int
,@solicitaAuto int
,@fueraHorario int
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
declare @folio int =0
begin try
if(@solicitaAuto = 0)
begin
insert into GA_Corporativa.dbo.tsb_traspasosaldobancos (
tsb_idempresa
      ,tsb_idsucursal
      ,tsb_cuentaorigen
      ,tsb_cuentadestino
      ,tsb_importe
      ,tsb_moneda
      ,tsb_concepto
      ,tsb_estatus
      ,tsb_fechasolicita
      ,tsb_usuariosolicita)
values( 
@idempresa
,@idSucursal
,@cuentaOrigen
,@cuentaDestino
,@monto
,'PE'
,'DTRASSALDOINGTS'
,-1 -- SE COLOCA -1 PARA QUE NO LO PROCESE EL SERVICIO DE BPRO HASTA QUE SE HAYA REALIZADO EL TRAMITE EN EL PORTAL DE TRAMITES
,case when @fueraHorario = 0 then  GETDATE() else convert(varchar,GETDATE()+1,111) end 
,@idUsuario
)
set @folio = @@IDENTITY
insert into transferenciasLog(idtransferencia)
values(@folio)
select 'Ok' as estatus, 'La transferencia se realizó con exito' as mensaje, @folio  as folio, @folio as Folio
END
ELSE
BEGIN
INSERT INTO TransferenciasBancarias (idEmpresa, idSucursal, cuentaOrigen, cuentaDestino, importe, moneda, concepto, usuario, fechaTransferencia)
VALUES (@idempresa, @idSucursal, @cuentaOrigen, @cuentaDestino, @monto, 'PE', 'Transferencia', @idUsuario, GETDATE());
set @folio = @@IDENTITY
select @folio as folio
,'Ok' as estatus
,'Se genero la transferencia temporal' as mensaje
,@folio as Folio
--from TransferenciasBancarias
END
    end try
begin catch
select 'error' as Estatus, 'Ocurrio un error durante la transferencia' as mensaje,   ERROR_NUMBER() AS ErrorNumber,
    ERROR_STATE() AS ErrorState,
    ERROR_SEVERITY() AS ErrorSeverity,
    ERROR_PROCEDURE() AS ErrorProcedure,
    ERROR_LINE() AS ErrorLine,
    ERROR_MESSAGE() AS ErrorMessage;
end catch
END
go

exec sp_addextendedproperty 'MS_Description',
     'Inserta la informacion para la generación de transferencias con el bat de bpro', 'SCHEMA', 'dbo', 'PROCEDURE',
     'TransferenciasBancarias_SP'
go

