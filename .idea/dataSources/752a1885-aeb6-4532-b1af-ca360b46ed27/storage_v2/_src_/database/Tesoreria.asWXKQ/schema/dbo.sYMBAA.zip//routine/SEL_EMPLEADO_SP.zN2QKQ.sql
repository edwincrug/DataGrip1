CREATE PROCEDURE [dbo].[SEL_EMPLEADO_SP]
	@idEmpleado  int = 0
AS
BEGIN
	SET NOCOUNT ON;
		
		DECLARE @Historico INT = 0
		IF EXISTS ( SELECT seg_idPortal FROM [Seguridad].[dbo].[SEG_CENTRALIZACION] WHERE seg_idPortal = 9 AND seg_idModulo = 7 AND seg_idAccion = 17 AND seg_idUsuario = @idEmpleado )
			BEGIN 
				SET @Historico = 1
			END

      SELECT  U.usu_idusuario AS idUsuario
			, U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS nombre
			, U.usu_correo AS correo
			, U.dep_iddepartamento AS iddepartamento
			, D.suc_idsucursal AS idsucursal
			, S.emp_idempresa 
			--, historico = @Historico
		FROM  ControlAplicaciones.dbo.cat_usuarios U INNER JOIN
			  ControlAplicaciones.dbo.cat_departamentos D ON U.dep_iddepartamento = D.dep_iddepartamento INNER JOIN
			  ControlAplicaciones.dbo.cat_sucursales S ON D.suc_idsucursal = S.suc_idsucursal
		WHERE U.usu_idusuario = @idEmpleado --OR @idEmpleado = 0
END
go

