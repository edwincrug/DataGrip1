-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- OBTIENE_CATCONCEPTOS_SP_Nuevo 4, 6, 27
-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_CATCONCEPTOS_SP_Nuevo]
	 @idEmpresa INT 
	,@idSucursal INT
	,@idDepartamento INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	    DECLARE 
   @query NVARCHAR(MAX) = ''
  ,@queryOtros NVARCHAR(MAX) = ''
  ,@bd VARCHAR(20)=''
  ,@depto VARCHAR(20)
  ,@idDeptoUnidadesNuevas INT

    DECLARE @catalogo TABLE(valor VARCHAR(22), descripcion VARCHAR(100))

    -- Insert statements for procedure here
	SET @bd =(SELECT DISTINCT nombre_base
            	FROM [ControlAplicaciones].[dbo].[cat_empresas] contrApp
            	INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] centBases
            	ON contrApp.emp_idempresa = centBases.emp_idempresa
            	WHERE contrApp.emp_idempresa != 0
                AND contrApp.emp_idempresa = @idEmpresa
            	and  suc_idsucursal = @idSucursal
    )

		SELECT @depto = cd.dep_nombre
    FROM ControlAplicaciones..cat_departamentos cd
    WHERE cd.emp_idempresa = @idEmpresa
    AND cd.suc_idsucursal = @idSucursal
    AND cd.dep_iddepartamento = @idDepartamento

  IF( @depto = 'UNIDADES SEMINUEVAS')
  BEGIN
  	SELECT @idDeptoUnidadesNuevas = cd.dep_iddepartamento
    FROM ControlAplicaciones..cat_departamentos cd
    WHERE cd.emp_idempresa = @idEmpresa
    AND cd.suc_idsucursal = @idSucursal
    AND cd.dep_nombre like '%UNIDADES NUEVAS%'

    SET @idDepartamento = @idDeptoUnidadesNuevas
  END

	SET @query = (
	    'select par_idenpara + CASE WHEN PAR_DESCRIP1 LIKE ''%UNIDADES'' THEN ''|UNI'' ELSE  ''|F'' END AS valor
		,par_descrip1 as descripcion
		from '+@bd+'.dbo.pnc_parametr 
		where par_tipopara = ''COCOCXC'' and par_status <> ''I'' 
		and (PAR_IMPORTE1=0 or PAR_IMPORTE1=1) 
		--and PAR_IMPORTE5 ='+ CAST(@idDepartamento AS VARCHAR(5))+'
		and par_idenpara NOT IN (select par_idenpara 
								from '+@bd+'.dbo.pnc_parametr
								where par_tipopara = ''COCOCXCUM'' and par_status = ''A'')  Order by par_descrip1
		'
	)

	print @query


	--INSERT INTO @catalogo
	EXECUTE sp_executesql @QUERY

	--IF EXISTS(
	--	SELECT 1
	--	FROM  @catalogo
	--) BEGIN

	--		EXECUTE sp_executesql @QUERY

	--END
	--ELSE
	--BEGIN
	--	EXECUTE sp_executesql @queryOtros
	--END
END
go

