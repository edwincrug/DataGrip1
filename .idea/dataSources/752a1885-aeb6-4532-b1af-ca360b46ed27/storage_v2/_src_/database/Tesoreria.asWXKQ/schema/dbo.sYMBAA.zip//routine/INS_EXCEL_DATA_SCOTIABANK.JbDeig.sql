-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[INS_EXCEL_DATA_SCOTIABANK]
	-- Add the parameters for the stored procedure here
@idBanco INT,
@noCuenta VARCHAR(100),
@fecha VARCHAR(100),
@ref_numerica VARCHAR(100),
@cargo numeric(18,2),
@abono numeric(18,2),
@tipo VARCHAR(100),
@transaccion VARCHAR(MAX),
@leyenda1 VARCHAR(MAX),
@leyenda2 VARCHAR(MAX),
@clveLayout VARCHAR(30)


AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [referencias].[dbo].[Scotiabank_Layout]
								   (
								   idBanco,
								   noCuenta,
								   fecha,
								   referencia_numerica,
								   cargo,
								   abono,
								   tipo,
								   transaccion,
								   leyenda1,
								   leyenda2
								   ) 
	                               SELECT
								    @idBanco,
									ISNULL(RTRIM(LTRIM(@noCuenta)),'INDEFINIDO'),
                                    ISNULL(CONVERT(DATE,(RTRIM(LTRIM(@fecha))),103), CONVERT(date,GETDATE(),103)),
									ISNULL(CONVERT(numeric(18,0),(RTRIM(LTRIM(@ref_numerica)))),0),
	                                ISNULL(CONVERT(numeric(18,2),(RTRIM(LTRIM(@cargo)))),0),
									ISNULL(CONVERT(numeric(18,2),(RTRIM(LTRIM(@abono)))),0),
									ISNULL(@tipo, 'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@transaccion)),'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@leyenda1)),'INDEFINIDO'),
									ISNULL(RTRIM(LTRIM(@leyenda2)),'INDEFINIDO')
							        
 
              
			   UPDATE [layout_Historial]
					  SET fecha_Carga_Info = CONVERT(date, GETDATE())
					  WHERE clv_Identificador = @clveLayout 


				SELECT 1 AS SUCCESS 

		
END TRY
BEGIN CATCH
          SELECT ERROR_MESSAGE() AS ERROR
END CATCH
go

