-- =============================================
-- Author:		Gibran A. Quintero
-- Create date: 27052016
-- Description:	convierte numeros en base decimal a  base X
-- =============================================
CREATE Function [dbo].[intToBase]
(
	@n bigint,	
	@base varchar(1000) 
)
Returns varchar(1000) As
Begin
	--Set @base = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'

	Declare @baseNum int
	Set @baseNum = len(@base)

	Declare @code varchar(1000)

	while (@n>0)
		Select @code=substring(@base,@n%@baseNum+1,1)+isnull(@code,''), @n=@n/@baseNum

	Return @code
End

go

