/*

EXECUTE dbo.[SEL_CONTABLE_TODO_SP] 3,1,'000000000110861464','1100-0020-0001-0001','2019-02-01','2019-02-28'

*/

CREATE PROCEDURE [dbo].[SEL_CONTABLE_TODO_SP]
@idEmpresa VARCHAR(50) = '',
@idBanco INT = 0,
@noCuenta VARCHAR(50) = '',
@cuentaContable VARCHAR(50) = '',	
@fechaElaboracion VARCHAR(50) = '',
@fechaCorte VARCHAR(50) = '',
@polizaPago VARCHAR(20) = '',
@opcion INT = 0, --1: detalle, 2: resumen
@idUsuario INT = 0
AS
BEGIN	
	SELECT distinct
		[IDABONOS_COMPLETO]
      ,[MOV_TIPOPOL]
      ,[MOV_CONSPOL]
      ,[MOV_CONSMOV]
      ,[MOV_MES]
      ,[MOV_NUMCTA]
      ,[MOV_CONCEPTO]
      ,[MOV_DEBE]
      ,[MOV_HABER]
      ,[MOV_ORIGEN]
      ,[MOV_IDCLIENTE]
      ,[MOV_DEPTO]
      ,[MOV_CARTERA]
      ,[MOV_TIPODOCTO]
      ,[MOV_IDDOCTO]
      ,[MOV_FECHVEN]
      ,[MOV_FECHPAG]
      ,[MOV_AGENTE]
      ,[MOV_CVEUSU]
      ,[MOV_FECHOPE]
      ,[MOV_CONCILIADO]
      ,[MOV_FOLIO]
      ,[MOV_FOLIODET]
      ,[MOV_MONEDA]
      ,[MOV_TIPOCAMBIO]
      ,[MOV_HORAOPE]
      ,[MOV_OBSERVA]
      ,[TIPO]
      ,[idUsuario]
      ,[idEmpresa]
      ,[idBanco]
      ,[anio]
      ,[fecha]
      ,[idEstatus]
      ,[idConciliado]
	  ,CASE WHEN MOV_DEBE = 0 THEN 1 ELSE 0 END tipoMovimiento
	  ,[cargo] = MOV_DEBE
	  ,[abono] = MOV_HABER
	FROM 
	(
		SELECT  [IDABONOS_COMPLETO]
      ,[MOV_TIPOPOL]
      ,[MOV_CONSPOL]
      ,[MOV_CONSMOV]
      ,[MOV_MES]
      ,[MOV_NUMCTA]
      ,[MOV_CONCEPTO]
      ,[MOV_DEBE]
      ,[MOV_HABER]
      ,[MOV_ORIGEN]
      ,[MOV_IDCLIENTE]
      ,[MOV_DEPTO]
      ,[MOV_CARTERA]
      ,[MOV_TIPODOCTO]
      ,[MOV_IDDOCTO]
      ,[MOV_FECHVEN]
      ,[MOV_FECHPAG]
      ,[MOV_AGENTE]
      ,[MOV_CVEUSU]
      ,[MOV_FECHOPE]
      ,[MOV_CONCILIADO]
      ,[MOV_FOLIO]
      ,[MOV_FOLIODET]
      ,[MOV_MONEDA]
      ,[MOV_TIPOCAMBIO]
      ,[MOV_HORAOPE]
      ,[MOV_OBSERVA]
      ,[TIPO]
      ,[idUsuario]
      ,[idEmpresa]
      ,[idBanco]
      ,[anio]
      ,[fecha]
      ,[idEstatus]
      ,[idConciliado]
		FROM [ABONOS_COMPLETO_CB] MOV
		WHERE MOV_NUMCTA = @cuentaContable AND idEmpresa = @idEmpresa AND idBanco = @idBanco AND idEstatus = 0 AND MOV_MES = MONTH(@fechaElaboracion) AND anio = YEAR(@fechaElaboracion)
		UNION ALL

		SELECT [IDCARGOS_COMPLETO]
      ,[MOV_TIPOPOL]
      ,[MOV_CONSPOL]
      ,[MOV_CONSMOV]
      ,[MOV_MES]
      ,[MOV_NUMCTA]
      ,[MOV_CONCEPTO]
      ,[MOV_DEBE]
      ,[MOV_HABER]
      ,[MOV_ORIGEN]
      ,[MOV_IDCLIENTE]
      ,[MOV_DEPTO]
      ,[MOV_CARTERA]
      ,[MOV_TIPODOCTO]
      ,[MOV_IDDOCTO]
      ,[MOV_FECHVEN]
      ,[MOV_FECHPAG]
      ,[MOV_AGENTE]
      ,[MOV_CVEUSU]
      ,[MOV_FECHOPE]
      ,[MOV_CONCILIADO]
      ,[MOV_FOLIO]
      ,[MOV_FOLIODET]
      ,[MOV_MONEDA]
      ,[MOV_TIPOCAMBIO]
      ,[MOV_HORAOPE]
      ,[MOV_OBSERVA]
      ,[Tipo]
      ,[idUsuario]
      ,[idEmpresa]
      ,[idBanco]
      ,[anio]
      ,[fecha]
      ,[idEstatus]
      ,[idConciliado]
		FROM [CARGOS_COMPLETO_CB] MOV
		WHERE MOV_NUMCTA = @cuentaContable AND idEmpresa = @idEmpresa AND idBanco = @idBanco AND idEstatus = 0 AND MOV_MES = MONTH(@fechaElaboracion) AND anio = YEAR(@fechaElaboracion)

	) CONTABLES ORDER BY MOV_CONSPOL;
	

END
go

