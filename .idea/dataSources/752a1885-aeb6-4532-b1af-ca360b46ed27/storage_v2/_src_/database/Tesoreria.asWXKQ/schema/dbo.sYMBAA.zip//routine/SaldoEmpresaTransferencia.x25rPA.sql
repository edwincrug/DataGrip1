-- =============================================
-- Author: Roberto Almanza
-- Create date:
-- Description:
-- exec SaldoEmpresaTransferencia 2020, 8, 71, 2, 3
-- =============================================
CREATE PROCEDURE [dbo].[SaldoEmpresaTransferencia] 
@anio INT = 2019
, @mes INT = 8
, @idUsuario INT = 71
, @idModulo INT = 2
, @empresaSeleccionada INT = -1
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
    DECLARE  @datos TABLE(idEmpresa INT, empresa VARCHAR(150), idBanco INT, Nombre VARCHAR(150), Cuenta VARCHAR(150), Saldo DECIMAL(18,2),saldoMinimoCuenta DECIMAL(18,2), cuentaContable VARCHAR(150), idSucursal INT, saldoInicial decimal(18,2))
INSERT INTO @datos (idEmpresa, empresa, idBanco, Nombre, Cuenta, Saldo, saldoMinimoCuenta, cuentaContable, idSucursal, saldoInicial)
exec [SaldoEmpresaBancoCuenta] @anio,@mes,@idUsuario,@idModulo,-1
;WITH general AS (
SELECT d.idEmpresa
,d.empresa
,d.idBanco
,d.Nombre
,d.Cuenta
,bc.cuentaClabe
,d.Saldo
,d.saldoMinimoCuenta
,d.cuentaContable
,d.idSucursal
FROM @datos d
join referencias.dbo.bancoCuenta bc
on d.cuentaContable = bc.cuentaContable
and d.idEmpresa = bc.idEmpresa
),
Salida AS (
SELECT tsb.tsb_idempresa
, tsb.tsb_cuentaorigen
, sum(ISNULL(tsb.tsb_importe, 0)) AS importe
FROM GA_Corporativa.dbo.tsb_traspasosaldobancos tsb
WHERE tsb.tsb_estatus in (-1,0)
GROUP BY tsb.tsb_idempresa, tsb.tsb_cuentaorigen
UNION
SELECT tb.idEmpresa
,tb.cuentaOrigen
,SUM(tb.importe) AS importe
FROM Tesoreria.dbo.TransferenciasBancarias tb
WHERE tb.autorizado = 0
GROUP BY tb.idEmpresa, tb.cuentaOrigen
),
Entrada AS (
SELECT tsb.tsb_idempresa
, tsb.tsb_cuentadestino
, sum(ISNULL(tsb.tsb_importe, 0)) AS importe
FROM GA_Corporativa.dbo.tsb_traspasosaldobancos tsb
WHERE tsb.tsb_estatus in (-1,0)
GROUP BY tsb.tsb_idempresa, tsb.tsb_cuentadestino
UNION
SELECT tb.idEmpresa
,tb.cuentaDestino
,SUM(tb.importe) AS importe
FROM Tesoreria.dbo.TransferenciasBancarias tb
WHERE tb.autorizado = 0
GROUP BY tb.idEmpresa, tb.cuentaDestino
)
SELECT g.idEmpresa as empresaId
,g.empresa
,g.idBanco
,g.nombre
,g.cuenta
,isnull(g.cuentaClabe,'') as clabe
,g.saldo
,g.saldoMinimoCuenta
,g.cuentaContable
,g.idSucursal
,sum(ISNULL(s.importe,0)) AS importeSalida
,sum(ISNULL(e.importe,0)) AS importeEntrada
,g.Saldo+sum(ISNULL(e.importe,0)) - sum(ISNULL(s.importe,0)) AS saldoDisponible
FROM general g
LEFT JOIN Salida s
ON g.idEmpresa = s.tsb_idempresa
AND g.cuentaContable = s.tsb_cuentaorigen
LEFT JOIN Entrada e
ON g.idEmpresa = e.tsb_idempresa
AND g.cuentaContable = e.tsb_cuentadestino
where cuentaClabe is not null
group by g.idEmpresa ,g.empresa ,g.idBanco ,g.nombre ,g.cuenta  ,isnull(g.cuentaClabe,'') ,g.saldo ,g.saldoMinimoCuenta ,g.cuentaContable  ,g.idSucursal
END
go

