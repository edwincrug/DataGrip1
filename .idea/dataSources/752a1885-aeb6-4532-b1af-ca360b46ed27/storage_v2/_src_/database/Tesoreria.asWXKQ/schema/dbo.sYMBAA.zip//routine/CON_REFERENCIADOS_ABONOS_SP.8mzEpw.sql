-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <10/07/2017>
-- Description:	<Inserta los referenciados a la tabla de punteo >
-- =============================================
--[dbo].[CON_REFERENCIADOS_ABONOS_SP] 1,1,7,2018,'','','000000000195334667' ,'1100-0020-0001-0001' 
--[dbo].[CON_REFERENCIADOS_ABONOS_SP] 3,1,7,2018,'','','65504258249' ,'1100-0020-0001-0018' 
--[dbo].[CON_REFERENCIADOS_ABONOS_SP] 1,2,7,2018,'','','000000000195368154' ,'1100-0020-0002-0001' 
--[dbo].[CON_REFERENCIADOS_ABONOS_SP] 1,3,7,2018,'','','000000000110861464' ,'1100-0020-0001-0001' 
--[dbo].[CON_REFERENCIADOS_ABONOS_SP] 1,1,7,2018,'','','000000000195334667' ,'1100-0020-0001-0001' 
--[dbo].[CON_REFERENCIADOS_ABONOS_SP] 1,4,7,2018,'','','000000000445990351' ,'1100-0020-0001-0001' 
--[dbo].[CON_REFERENCIADOS_ABONOS_SP] 1,9,11,2018,'','','000000000145298911' ,'1100-0020-0001-0001' 
CREATE PROCEDURE [dbo].[CON_REFERENCIADOS_ABONOS_SP] 
--Declare
@idBanco INT	= 0,
	@idEmpresa INT	= 0,
	@Mes INT		= 0,
	@Anio INT		= 0,
	@fechaOperacion VARCHAR(30) = '',
	@fechaCorte VARCHAR(30) = '',
	@noCuenta VARCHAR(30) = '',
	@cuentaContable VARCHAR(30) = ''
	--@idBanco INT	= 1,
	--@idEmpresa INT	= 10,
	--@Mes INT		= 3,
	--@Anio INT		= 2019,
	--@fechaOperacion VARCHAR(30) = '',
	--@fechaCorte VARCHAR(30) = '',
	--@noCuenta VARCHAR(30) = '000000000195368316',
	--@cuentaContable VARCHAR(30) = '1100-0020-0001-0001'

AS
BEGIN
------1.-Declarar las variables--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	SET NOCOUNT ON;
	Declare @MOV_TIPOPOL varchar(30),@max_grupopunteo int=0
         
	set @MOV_TIPOPOL= ''
	select top 1	@MOV_TIPOPOL=tipo_poliza_pago
					--from  [192.168.20.92].[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
					from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
					where   emp_idempresa = @idEmpresa and suc_idsucursal is null
         if @MOV_TIPOPOL is null or len(@MOV_TIPOPOL) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 --return 0;
		 end
--		 select @MOV_TIPOPOL
--IF OBJECT_ID('#relpunteo') IS NOT NULL
--BEGIN
--	DROP TABLE #relpunteo
--END
--IF OBJECT_ID('#relpunteo2') IS NOT NULL
--BEGIN
--	DROP TABLE #relpunteo2
--END
--IF OBJECT_ID('#relpunteo3') IS NOT NULL
--BEGIN
--	DROP TABLE #relpunteo3
--END
----2.-Obtener cte--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @idMes INT = ( SELECT mec_idMes FROM PeriodoActivo WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @noCuenta AND mec_conciliado = 0);
select  distinct IDCARGOSBANCOS,importe,IDABONOS_COMPLETO,mov_haber,0 grupo,@idMes idMes
into #relpunteo from PAGOS.DBO.PAG_REL_DOCTOS_BANCOS MR
left join (

SELECT p.dpa_iddoctopagado,ac.IDABONOS_COMPLETO,ac.MOV_HABER,ac.MOV_TIPOPOL  FROM [cuentasxpagar].[dbo].[cxp_doctospagados] p
	inner join PAGOS.DBO.PAG_REL_DOCTOS_BANCOS r on p.dpa_iddoctopagado=r.dpa_iddoctopagado and r.idBanco=@idBanco
	inner join PAGOS.DBO.PAG_LOTE_PAGO lp on p.dpa_lote=lp.pal_id_lote_pago and lp.pal_id_tipoLotePago=@idBanco
	inner join dbo.ABONOS_COMPLETO_CB ac on p.dpa_conscarapl=ac.MOV_CONSPOL AND ac.MOV_TIPOPOL = @MOV_TIPOPOL and p.dpa_mes=ac.MOV_MES and ac.anio=@Anio
	where MONTH(dpa_fechaaplicacion) = @Mes 
	and YEAR(dpa_fechaaplicacion) = @Anio AND dpa_pagoaplicado = 1 AND dpa_cuentapagadora =@noCuenta AND p.dpa_iddocumento NOT LIKE 'AU-UNI-Com%'
	and ac.idEmpresa=@idEmpresa and ac.idBanco=@idBanco
) MA on MR.dpa_iddoctopagado=MA.dpa_iddoctopagado
Left join (
select r.dpa_iddoctopagado,c.idBmer,c.IDCARGOSBANCOS,c.importe from PAGOS.DBO.PAG_REL_DOCTOS_BANCOS r
	inner join dbo.CARGOSBANCOS_CB c   on c.idBmer=r.idBanco_Registro and r.idBanco=c.IDBanco
	inner join [cuentasxpagar].[dbo].[cxp_doctospagados] p on p.dpa_iddoctopagado=r.dpa_iddoctopagado and r.idBanco=c.IDBanco
	inner join PAGOS.DBO.PAG_LOTE_PAGO lp on p.dpa_lote=lp.pal_id_lote_pago and lp.pal_id_tipoLotePago=1 
	where c.idEmpresa=@idEmpresa and c.IDBanco=@idBanco and month(c.fechaOperacion)=@Mes and anio=@Anio and noCuenta=@noCuenta AND p.dpa_iddocumento NOT LIKE 'AU-UNI-Com%'
) MC on MR.dpa_iddoctopagado=MC.dpa_iddoctopagado
where IDABONOS_COMPLETO is not null and IDCARGOSBANCOS is not null
		
update r set r.grupo= x.grupo from ( 
select  ROW_NUMBER() OVER(ORDER BY IDABONOS_COMPLETO ASC) AS grupo, IDABONOS_COMPLETO from #relpunteo group by IDABONOS_COMPLETO) x
inner join #relpunteo r on x.IDABONOS_COMPLETO=r.IDABONOS_COMPLETO
----2.-Obtener pa borrar--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
select x.grupo,x.IDCARGOSBANCOS,x.IDABONOS_COMPLETO,x.tipo,x.fecha,x.usuario,x.idaplicado,x.idMes ,0 noexiste
into #relpunteo2 
from (
select distinct grupo,0 IDCARGOSBANCOS,IDABONOS_COMPLETO,'C' tipo,getdate() fecha,2 usuario,2 idaplicado,idMes from #relpunteo 
union all
select distinct grupo,IDCARGOSBANCOS,0 IDABONOS_COMPLETO,'B',getdate(),2 ,2,idMes  from #relpunteo) x 
left join (select * from VW_REGISTROSPUNTEADOS_ALL ) r on r.rpun_idAbono=x.IDABONOS_COMPLETO and r.rpun_idCargo=x.IDCARGOSBANCOS and r.rpun_tipo=x.tipo
where r.rpun_idPunteado is null
order by grupo


update #relpunteo2 set noexiste=1 where grupo in (select grupo from #relpunteo2 r where tipo='C')
update #relpunteo2 set noexiste=1 where grupo in (select grupo from #relpunteo2 r where tipo='B')


----2.-Borrar--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SELECT [rpun_idPunteado]
      ,[rpun_grupoPunteo]
      ,[rpun_idCargo]
      ,[rpun_idAbono]
      ,[rpun_tipo]
      ,[rpun_fechaPunteo]
      ,[rpun_usuario]
      ,[rpun_idAplicado]
      ,[idMes] into #regborrar FROM REGISTROS_PUNTEADOS WHERE  rpun_idAplicado IN (0,1) AND rpun_tipo = 'B' AND rpun_idCargo in (select 
	
	t.IDCARGOSBANCOS

	FROM #relpunteo2 TEM
	inner join #relpunteo t on tem.idabonos_completo=t.idabonos_completo and tem.tipo='C'
	LEFT JOIN REGISTROS_PUNTEADOS PUN ON	T.IDCARGOSBANCOS = PUN.rpun_idCargo 
											AND PUN.rpun_tipo = 'B'
	WHERE noexiste= 1 and pun.rpun_idAplicado in(0,1) )
--delete from REGISTROS_PUNTEADOS where rpun_grupoPunteo in (
--select rpun_grupoPunteo from #regborrar
--)
--SELECT [rpun_idPunteado]
--      ,[rpun_grupoPunteo]
--      ,[rpun_idCargo]
--      ,[rpun_idAbono]
--      ,[rpun_tipo]
--      ,[rpun_fechaPunteo]
--      ,[rpun_usuario]
--      ,[rpun_idAplicado]
--      ,[idMes] into #regborrarContable FROM REGISTROS_PUNTEADOS WHERE  rpun_idAplicado IN (0,1) AND rpun_tipo = 'C' AND rpun_idAbono in (
--	select 
	
--	t.IDABONOS_COMPLETO

--	FROM #relpunteo2 TEM
--	inner join #relpunteo t on tem.IDCARGOSBANCOS=t.IDCARGOSBANCOS and tem.tipo='B'
--	LEFT JOIN REGISTROS_PUNTEADOS PUN ON	T.idabonos_completo = PUN.rpun_idAbono 
											
--											AND PUN.rpun_tipo = 'C'
--	WHERE noexiste= 1 and pun.rpun_idAplicado in(0,1) )
----Borrar registros
--delete from REGISTROS_PUNTEADOS where rpun_grupoPunteo in (
--select rpun_grupoPunteo from #regborrarContable
--)
--select * from #relpunteo

select  x.grupo,x.IDCARGOSBANCOS,x.IDABONOS_COMPLETO,x.tipo,x.fecha,x.usuario,x.idaplicado,x.idMes ,0 noexiste
into #relpunteo4
from (
select distinct grupo,0 IDCARGOSBANCOS,IDABONOS_COMPLETO,'C' tipo,getdate() fecha,2 usuario,2 idaplicado,idMes from #relpunteo 
union all
select distinct grupo,IDCARGOSBANCOS,0 IDABONOS_COMPLETO,'B',getdate(),2 ,2,idMes  from #relpunteo) x 
left join (select * from [dbo].[REGISTROS_PUNTEADOS] 
union all select * from [dbo].[REGISTROS_PUNTEADOS_ERR]  ) r on r.rpun_idAbono=x.IDABONOS_COMPLETO and r.rpun_idCargo=x.IDCARGOSBANCOS and r.rpun_tipo=x.tipo
where r.rpun_idPunteado is null
order by grupo


update #relpunteo4 set noexiste=1 where grupo in (select grupo from #relpunteo4 r where tipo='C')
update #relpunteo4 set noexiste=1 where grupo in (select grupo from #relpunteo4 r where tipo='B')

----3.-Checar montos--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Declare @dif_monetaria int=0
SELECT @dif_monetaria=emp_dif_monetaria FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 and emp_idempresa=@idEmpresa
select grupo,sum(importe) importe,sum(mov_haber) mov_haber,abs(sum(importe)-sum(mov_haber)) dif,@dif_monetaria dif_monetaria,case when @dif_monetaria > abs(sum(importe)-sum(mov_haber)) then 1 else 0 end success 
into #relpunteo3 from (
select distinct r2.grupo,r2.IDCARGOSBANCOS,r.importe,r2.IDABONOS_COMPLETO,r1.MOV_HABER from #relpunteo4 r2 left join #relpunteo r on r2.IDCARGOSBANCOS=r.IDCARGOSBANCOS
left join #relpunteo r1 on r2.IDABONOS_COMPLETO=r1.IDABONOS_COMPLETO)x group by grupo 

update r2 set noexiste=0 from #relpunteo4 r2 
inner join #relpunteo3  rx on r2.grupo=rx.grupo
where dif<> 0
--select * from #relpunteo where IDABONOS_COMPLETO in(35725
--,36479)
--order by IDCARGOSBANCOS
--select * from #relpunteo2
--select * from #relpunteo3
--select * from #relpunteo4
update r1 set noexiste = 0 from #relpunteo4 r1
inner join (
select grupo, count(*) cuantos from #relpunteo4 group by grupo) r2 on r1.grupo=r2.grupo
where cuantos=1
select @max_grupopunteo=max(rpun_grupoPunteo) from (select max(rpun_grupoPunteo) rpun_grupoPunteo from [dbo].[REGISTROS_PUNTEADOS] union all select max(rpun_grupoPunteo) rpun_grupoPunteo from[dbo].[REGISTROS_PUNTEADOS_ERR]) x
--@max_grupopunteo  
INSERT INTO [dbo].[REGISTROS_PUNTEADOS]
           ([rpun_grupoPunteo]
           ,[rpun_idCargo]                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
           ,[rpun_idAbono]
           ,[rpun_tipo]
           ,[rpun_fechaPunteo]
           ,[rpun_usuario]
           ,[rpun_idAplicado]
		   ,[idMes])
select @max_grupopunteo+ grupo,IDCARGOSBANCOS,IDABONOS_COMPLETO,tipo,fecha,usuario,idaplicado ,idMes
from #relpunteo4 
where noexiste= 1 order by grupo

INSERT INTO [dbo].[REGISTROS_PUNTEADOS_ERR]
           ([rpun_grupoPunteo]
           ,[rpun_idCargo]
           ,[rpun_idAbono]
           ,[rpun_tipo]
           ,[rpun_fechaPunteo]
           ,[rpun_usuario]
           ,[rpun_idAplicado]
		   ,[idMes])
select  @max_grupopunteo+grupo,IDCARGOSBANCOS,IDABONOS_COMPLETO,tipo,fecha,usuario,idaplicado ,idMes
from #relpunteo4 
where noexiste= 0 order by grupo
--select * from #relpunteo2
--select * from #relpunteo order by IDABONOS_COMPLETO
--select * from #relpunteo2
--select distinct r.IDABONOS_COMPLETO,ac.MOV_HABER from #relpunteo2 r
--inner join [dbo].ABONOS_COMPLETO_CB ac on r.IDABONOS_COMPLETO=ac.IDABONOS_COMPLETO 
--select distinct r.IDCARGOSBANCOS, ac.importe from #relpunteo2 r
--inner join [dbo].CARGOSBANCOS_CB ac on r.IDCARGOSBANCOS=ac.IDCARGOSBANCOS 
--select sum(ac.MOV_HABER) from (select distinct IDABONOS_COMPLETO from #relpunteo2 )r
--inner join [dbo].ABONOS_COMPLETO_CB ac on r.IDABONOS_COMPLETO=ac.IDABONOS_COMPLETO 
--select sum( ac.importe) from (select distinct IDCARGOSBANCOS from #relpunteo2 ) r
--inner join [dbo].CARGOSBANCOS_CB ac on r.IDCARGOSBANCOS=ac.IDCARGOSBANCOS 
-- where noexiste= 1
--order by grupo,IDABONOS_COMPLETO,IDCARGOSBANCOS
--	select * from #regborrar	

----3.-Borrar temporales por si acaso, no se necesita pero por si acaso--------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	IF OBJECT_ID('#relpunteo') IS NOT NULL
BEGIN
	DROP TABLE #relpunteo
END
IF OBJECT_ID('#relpunteo2') IS NOT NULL
BEGIN
	DROP TABLE #relpunteo2
END
IF OBJECT_ID('#relpunteo3') IS NOT NULL
BEGIN
	DROP TABLE #relpunteo3
END
END
----select * from VW_REGISTROS_PUNTEADOS where rpun_idAbono=4080
----select * from VW_REGISTROS_PUNTEADOS where rpun_grupoPunteo=28052
--DROP TABLE #relpunteo
--DROP TABLE #relpunteo2
--DROP TABLE #relpunteo3
--DROP TABLE #relpunteo4
--DROP TABLE #regborrar
--DROP TABLE #regborrarContable
--select * from ABONOS_COMPLETO_CB where IDABONOS_COMPLETO=17495
--select * from CARGOSBANCOS_CB where IDCARGOSBANCOS=37195 
--select * from VW_REGISTROS_PUNTEADOS where rpun_idAbono=17495 and rpun_tipo='C'
go

