-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- ALTER date: 2018-01-22
-- Description:	Actualización de la cartera por empresa
-- [PlanPiso].[dbo].[SEL_ACTIVE_DATABASES_SP]
-- [CARTERAACTUALIZA_SP] 12
-- =============================================
CREATE PROCEDURE [dbo].[CARTERAACTUALIZA_SP] 
	@idEmpresa INT = 0
AS
BEGIN
	DECLARE @FECHA VARCHAR(10) = (SELECT CONVERT(VARCHAR(10),GETDATE(),103));
	
	IF(@idEmpresa = 1)
		BEGIN
			EXEC GAAU_Cuautitlan.dbo.SP_BI_CARTERA @FECHA, '3' 
			EXEC GAAU_Pedregal.dbo.SP_BI_CARTERA @FECHA, '2' 
			EXEC GAAU_Universidad.dbo.SP_BI_CARTERA @FECHA, '1' 

			SELECT success = 1, idEmpresa = 1, msg = 'Cartera actualizada correctamente'
		END
	ELSE IF(@idEmpresa = 2)
		BEGIN
			EXEC [192.168.20.31].GAAT_Peugeot.dbo.SP_BI_CARTERA @FECHA, '2' 
			
			SELECT success = 1, idEmpresa = 2, msg = 'Cartera actualizada correctamente'
		END
	ELSE IF(@idEmpresa = 3)
		BEGIN
			EXEC GAHondaZaragoza.dbo.SP_BI_CARTERA @FECHA, '1' 
			
			SELECT success = 1, idEmpresa = 3, msg = 'Cartera actualizada correctamente'
		END
	ELSE IF(@idEmpresa = 4)
		BEGIN
			--EXEC [192.168.20.31].GAZM_Abasto.dbo.SP_BI_CARTERA @FECHA, '3' 
			--EXEC [192.168.20.31].GAZM_Cuauhtemoc.dbo.SP_BI_CARTERA @FECHA, '5' 
			--EXEC [192.168.20.31].GAZM_FAerea.dbo.SP_BI_CARTERA @FECHA, '4' 
			--EXEC [192.168.20.31].GAZM_Zaragoza.dbo.SP_BI_CARTERA @FECHA, '1' 
			
			EXEC GAZM_Zaragoza.dbo.SP_BI_CARTERA @FECHA, '1' 
			EXEC GAZM_Abasto.dbo.SP_BI_CARTERA @FECHA, '3' 
			EXEC GAZM_FAerea.dbo.SP_BI_CARTERA @FECHA, '4' 

			SELECT success = 1, idEmpresa = 4, msg = 'Cartera actualizada correctamente'
		END
	ELSE IF(@idEmpresa = 5)
		BEGIN

			
			EXEC GAAA_Azcapo.dbo.SP_BI_CARTERA @FECHA, '1' 
			EXEC GAAA_PERISUR.dbo.SP_BI_CARTERA @FECHA, '2' 


			SELECT success = 1, idEmpresa = 5, msg = 'Cartera actualizada correctamente'
		END
	ELSE IF(@idEmpresa = 6)
	BEGIN

			
		EXEC GAAS_Satelite.dbo.SP_BI_CARTERA @FECHA, '1' 
		EXEC GAAS_Esmeralda.dbo.SP_BI_CARTERA @FECHA, '2' 
		EXEC GAAS_Pedregal.dbo.SP_BI_CARTERA @FECHA, '3' 


		SELECT success = 1, idEmpresa = 6, msg = 'Cartera actualizada correctamente'
	END
	ELSE IF(@idEmpresa = 7)
	BEGIN

			
		EXEC GAAutoExpress.dbo.SP_BI_CARTERA @FECHA, '1' 
		EXEC GAAutoExpressBanorte.dbo.SP_BI_CARTERA @FECHA, '2' 
		EXEC GAAutoExpressIII.dbo.SP_BI_CARTERA @FECHA, '3' 


		SELECT success = 1, idEmpresa = 7, msg = 'Cartera actualizada correctamente'
	END
	ELSE IF(@idEmpresa = 9)
	BEGIN

			
		EXEC GAAutoAngar.dbo.SP_BI_CARTERA @FECHA, '1' 
		EXEC GAAutoAngarMitsu.dbo.SP_BI_CARTERA @FECHA, '3' 
		EXEC GAAutoAngarFiat.dbo.SP_BI_CARTERA @FECHA, '4'
		EXEC GAAutoAngarTlahuac.dbo.SP_BI_CARTERA @FECHA, '5' 
		EXEC GAAutoAngarTepepan.dbo.SP_BI_CARTERA @FECHA, '6' 


		SELECT success = 1, idEmpresa = 9, msg = 'Cartera actualizada correctamente'
	END
	ELSE IF(@idEmpresa = 10)
	BEGIN

			
		EXEC GAHyundai.dbo.SP_BI_CARTERA @FECHA, '1' 
		EXEC GAHyundaiEcatepec.dbo.SP_BI_CARTERA @FECHA, '2' 
 


		SELECT success = 1, idEmpresa = 10, msg = 'Cartera actualizada correctamente'
	END
	ELSE IF(@idEmpresa = 11)
	BEGIN

			
		EXEC GADVAP_Pedregal.dbo.SP_BI_CARTERA @FECHA, '1' 
		
		SELECT success = 1, idEmpresa = 11, msg = 'Cartera actualizada correctamente'
	END
	ELSE IF(@idEmpresa = 14)
	BEGIN

			
		EXEC GAAAF_Viga.dbo.SP_BI_CARTERA @FECHA, '1' 
		EXEC GAAAF_Zaragoza.dbo.SP_BI_CARTERA @FECHA, '2'
		EXEC GAAAF_Tepepan.dbo.SP_BI_CARTERA @FECHA, '3' 
	
		
		SELECT success = 1, idEmpresa = 14, msg = 'Cartera actualizada correctamente'
	END
	ELSE IF(@idEmpresa = 12)
	BEGIN

			
		EXEC GARadiocomunicaciones.dbo.SP_BI_CARTERA @FECHA, '1' 
		
		SELECT success = 1, idEmpresa = 12, msg = 'Cartera actualizada correctamente'
	END
	ELSE IF(@idEmpresa = 17)
	BEGIN

			
		EXEC GAOperadora.dbo.SP_BI_CARTERA @FECHA, '1' 
		
		SELECT success = 1, idEmpresa = 17, msg = 'Cartera actualizada correctamente'
	END
	ELSE IF(@idEmpresa = 18)
	BEGIN

			
		EXEC GARRTelevision.dbo.SP_BI_CARTERA @FECHA, '1' 
		
		SELECT success = 1, idEmpresa = 18, msg = 'Cartera actualizada correctamente'
	END
	ELSE
		BEGIN
			SELECT success = 1, idEmpresa = 0, msg = 'No hay empresa proporcionada'
		END
END
go

