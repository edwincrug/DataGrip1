-- =============================================
-- Author:    	Ing. Luis Antonio Garcia Perrusquia
-- Create date: 09/05/2018
-- Description:	Trae todos los registros para colocarlos en los no conciliados
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TODO_BANCARIO_SP]
/*
	[SEL_TODO_BANCARIO_SP] 1,1,'000000000195334667','2018-09-01','2018-09-31',1

*/
	@idBanco int,
	@idEstatus int,
	@noCuenta varchar(50),
	@fechaElaboracion varchar(30),
	@fechaCorte varchar(30),
	@idEmpresa int

AS
BEGIN

  ---------------------------------------------------------------
  SET LANGUAGE Español
   SELECT
      [IDABONOSBANCOS]
      ,ABO.[idBmer]
      ,ABO.[IDBanco]
      ,ABO.[txtOrigen]
      ,ABO.[registro]
      ,ABO.[noMovimiento]
      ,ABO.[referencia]
	  ,CASE  WHEN ABO.[IDBanco]=3 THEN ABO.[concepto] + ' ' + ABO.[referencia] ELSE ABO.[concepto] END [concepto]
	-- ,ABO.[concepto] + ' ' + ABO.[referencia] [concepto]      
	  ,ABO.[refAmpliada]
      ,ABO.[esCargo]
      ,ABO.[importe]
      ,ABO.[saldoOperativo]
      ,ABO.[codigoLeyenda]
      ,ABO.[oficinaOperadora]
      ,ABO.[fechaOperacion]
      ,ABO.[horaOperacion]
      ,ABO.[fechaValor]
      ,ABO.[fechaContable]
      ,ABO.[estatus]
      ,ABO.[noCuenta]
      ,ABO.[estatusRevision]
      ,ABO.[Tipo]
      ,ABO.[idUsuario]
      ,ABO.[idEmpresa]
      ,ABO.[anio]
      ,ABO.[fecha]
      ,ABO.[idEstatus]
      ,ABO.[idConciliado]
	  ,PUN.[rpun_idPunteado]
      ,PUN.[rpun_grupoPunteo]
      ,PUN.[rpun_idCargo]
      ,PUN.[rpun_idAbono]
      ,PUN.[rpun_tipo]
      ,PUN.[rpun_fechaPunteo]
      ,PUN.[rpun_usuario]
      ,PUN.[rpun_idAplicado]
      ,PUN.[idMes],
      '' abono,
      '' cargo,
      0 fechaAnterior,
      '' color,
      ABO.IDBanco idBanco,
      UPPER(DATENAME(MONTH, CONVERT(date, fechaOperacion, 103))) MES,
      UPPER(DATENAME(YEAR, CONVERT(date, fechaOperacion, 103))) anio,
	  --punErr = 0
	  punErr = CASE WHEN PUNE.rpun_idPunteado IS NULL THEN 0 ELSE 1 END
    FROM ABONOSBANCOS_CB ABO
    LEFT JOIN [REGISTROS_PUNTEADOS]		PUN		ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono AND PUN.rpun_tipo = 'B'
    LEFT JOIN REGISTROS_PUNTEADOS_ERR	PUNE	ON ABO.IDABONOSBANCOS = PUNE.rpun_idAbono AND PUNE.rpun_tipo = 'B' AND PUNE.rpun_usuario != 0
	--LEFT JOIN [DepositoBancarioDPI] DPI ON ABO.idBmer = DPI.idAbonoBanco
    WHERE   ABO.noCuenta = @noCuenta 
			AND ABO.idEmpresa = @idEmpresa 
			AND ABO.IDBanco = @idBanco
			AND ABO.idEstatus = 0
			AND PUN.rpun_idPunteado IS NULL 
			--AND DPI.idDPI IS NULL
    
    UNION ALL
    
	SELECT 
	   CAR.[IDCARGOSBANCOS]
      ,CAR.[idBmer]
      ,CAR.[IDBanco]
      ,CAR.[txtOrigen]
      ,CAR.[registro]
      ,CAR.[noMovimiento]
      ,CAR.[referencia]
      ,CASE  WHEN CAR.[IDBanco]=3 THEN CAR.[concepto] + ' ' + CAR.[referencia] ELSE CAR.[concepto] END [concepto]
	  --,CAR.[concepto] + ' ' + CAR.[referencia] [concepto]
      ,CAR.[refAmpliada]
      ,CAR.[esCargo]
      ,CAR.[importe]
      ,CAR.[saldoOperativo]
      ,CAR.[codigoLeyenda]
      ,CAR.[oficinaOperadora]
      ,CAR.[fechaOperacion]
      ,CAR.[horaOperacion]
      ,CAR.[fechaValor]
      ,CAR.[fechaContable]
      ,CAR.[estatus]
      ,CAR.[noCuenta]
      ,CAR.[estatusRevision]
      ,CAR.[Tipo]
      ,CAR.[idUsuario]
      ,CAR.[idEmpresa]
      ,CAR.[anio]
      ,CAR.[fecha]
      ,CAR.[idEstatus]
      ,CAR.[idConciliado]
	  ,PUN.[rpun_idPunteado]
      ,PUN.[rpun_grupoPunteo]
      ,PUN.[rpun_idCargo]
      ,PUN.[rpun_idAbono]
      ,PUN.[rpun_tipo]
      ,PUN.[rpun_fechaPunteo]
      ,PUN.[rpun_usuario]
      ,PUN.[rpun_idAplicado]
      ,PUN.[idMes]
	  ,'' abono
	  ,'' cargo
	  ,0 fechaAnterior
	  ,'' color
	  ,CAR.IDBanco idBanco
	  ,UPPER(DATENAME(MONTH, CONVERT(date, fechaOperacion, 103))) MES
	  ,UPPER(DATENAME(YEAR, CONVERT(date, fechaOperacion, 103))) anio
	  ,punErr = CASE WHEN PUNE.rpun_idPunteado IS NULL THEN 0 ELSE 1 END
	FROM CARGOSBANCOS_CB CAR 
	LEFT JOIN REGISTROS_PUNTEADOS		PUN		ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo AND PUN.rpun_tipo = 'B'
	LEFT JOIN REGISTROS_PUNTEADOS_ERR	PUNE	ON CAR.IDCARGOSBANCOS = PUNE.rpun_idCargo AND PUNE.rpun_tipo = 'B' AND PUNE.rpun_usuario != 0
	WHERE   CAR.noCuenta = @noCuenta
			AND CAR.idEmpresa = @idEmpresa
			AND CAR.IDBanco = @idBanco
			AND CAR.idEstatus = 0
			AND PUN.rpun_idPunteado IS NULL



END
go

