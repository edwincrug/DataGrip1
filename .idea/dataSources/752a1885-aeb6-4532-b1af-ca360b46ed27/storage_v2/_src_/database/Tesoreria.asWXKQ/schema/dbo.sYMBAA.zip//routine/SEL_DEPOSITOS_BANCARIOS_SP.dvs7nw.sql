
CREATE PROCEDURE [dbo].[SEL_DEPOSITOS_BANCARIOS_SP]
--[SEL_DEPOSITOS_BANCARIOS_SP] 1

@idBanco varchar(10)

AS
BEGIN
select [idBanco]
      ,[idBmer]
      ,[banco]
      ,[txtOrigen]
      ,[noCuenta]
      ,[concepto]
      ,[esCargo]
      ,[importe]
      ,[saldoOperativo]
      ,[referencia]
      ,[fechaOperacion]
      ,[horaOperacion]
      ,[oficinaOperadora]
      ,[refAmpliada]
      ,[estatusRevision]
      ,[codigoLeyenda] from [dbo].[DepositoBancoView] where idbanco = @idBanco
END
go

