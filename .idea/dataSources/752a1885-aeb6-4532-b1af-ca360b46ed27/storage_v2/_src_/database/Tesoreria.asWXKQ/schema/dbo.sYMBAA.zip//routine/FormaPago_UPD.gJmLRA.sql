-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<Forma de pago no definida refantypaq>
-- =============================================

CREATE PROCEDURE [dbo].[FormaPago_UPD]
			@rap_folio int,
			@rap_formapago nvarchar(2),
			@idUsuario int
		   

AS
BEGIN

UPDATE  GA_Corporativa.dbo.cxc_refantypag Set rap_formapago=@rap_formapago
  
  where rap_folio=@rap_folio


INSERT INTO [dbo].[BitacoraFormaPago]
           ([rap_folio]
           ,[idUsuario]
           ,[fecha])
     VALUES
           (@rap_folio
           ,@idUsuario
           ,getdate())

select 1 success,'Guardado Satisfactoriamente' msg

END
go

