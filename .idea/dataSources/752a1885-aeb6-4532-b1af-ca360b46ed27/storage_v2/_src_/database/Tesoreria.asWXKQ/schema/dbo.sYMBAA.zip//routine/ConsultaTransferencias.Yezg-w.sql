-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- EXEC ConsultaTransferencias 2020, 3, 71
-- =============================================
CREATE PROCEDURE [dbo].[ConsultaTransferencias] 
	@anio int
	,@mes int
	,@idUsuario int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
WITH origen AS (
  
  SELECT tt.tsb_idtraspasosaldobancos
    ,tt.tsb_idempresa
    ,ce.emp_nombre
    , b.idBanco
    , b.nombre
    , bc.numeroCuenta
    , tt.tsb_importe
    , tt.tsb_usuariosolicita
    , convert(varchar(10),tt.tsb_fechasolicita,103) as fechaSolicita
    , l.idPerTra
    , tt.tsb_fechaaplicacion
    , cu.usu_nombre+' '+cu.usu_paterno+' '+cu.usu_materno AS usuario
	, tt.tsb_estatus
  FROM GA_Corporativa..tsb_traspasosaldobancos tt
  JOIN referencias..BancoCuenta bc
    ON tt.tsb_idempresa = bc.idEmpresa
    AND tt.tsb_cuentaorigen = bc.cuentaContable
  JOIN referencias..Banco b
    ON bc.idBanco = b.idBanco
  JOIN ControlAplicaciones..cat_empresas ce
    ON tt.tsb_idempresa = ce.emp_idempresa
  LEFT JOIN Tesoreria..transferenciasLog l
    ON tt.tsb_idtraspasosaldobancos = l.idtransferencia
  LEFT JOIN ControlAplicaciones..cat_usuarios cu
    ON tt.tsb_usuariosolicita = cu.usu_idusuario 
  )
, destino AS (
  
  SELECT tt.tsb_idtraspasosaldobancos
    ,tt.tsb_idempresa
    ,ce.emp_nombre
    , b.idBanco
    , b.nombre
    , bc.numeroCuenta
  FROM GA_Corporativa..tsb_traspasosaldobancos tt
  JOIN referencias..BancoCuenta bc
    ON tt.tsb_idempresa = bc.idEmpresa
    AND tt.tsb_cuentadestino = bc.cuentaContable
  JOIN referencias..Banco b
    ON bc.idBanco = b.idBanco
  JOIN ControlAplicaciones..cat_empresas ce
  ON tt.tsb_idempresa = ce.emp_idempresa
  )
SELECT 
   o.tsb_idtraspasosaldobancos AS id
   ,o.idPerTra
   ,o.tsb_idempresa AS idEmpresa
   ,o.emp_nombre AS empresa
   ,o.idBanco AS idBancoOrigen
   ,o.nombre AS bancoOrigen
   ,o.numeroCuenta AS cuentaOrigen
   ,o.tsb_importe AS importe
   ,o.tsb_usuariosolicita AS usuariosolicita
   ,o.fechaSolicita AS fechaSolicita
   ,convert(varchar(10), o.tsb_fechaaplicacion,103) AS fechaAplicacion
   ,d.nombre AS bancoDestino
   ,d.numeroCuenta AS cuentaDestino
  ,o.usuario 
  , case when o.tsb_fechaaplicacion is NULL and  o.tsb_estatus = -1
	then 'Comprobante Pendiente' 
	else case when o.tsb_estatus = 0 
				then 'Procesando'
				else case when o.tsb_estatus = -2
						  then 'Cancelada'
						  else 'Realizada' 
					  end
		       end 
	end AS estatus
FROM origen o
JOIN destino d
  ON o.tsb_idtraspasosaldobancos = d.tsb_idtraspasosaldobancos
  AND o.tsb_idempresa = d.tsb_idempresa
END
go

