
-- =============================================
-- Modifico:		Ing. Luis Antonio García Perrusquía
-- Modificado fecha: 26/09/2018
-- Description:	SP que guarda los historicos
-- TEST EXECUTE	INS_GUARDAHISTORICO_SP_RECON 1, 3 ,2 , '65504569012', '1100-0020-0002-0004','2018-09-01', '2018-09-30', 'TREEUN', 2
-- =============================================
CREATE PROCEDURE [dbo].[INS_GUARDAHISTORICO_SP_RECON]
	 @idUsuario INT = 0
	,@idBanco INT = 0
	,@idEmpresa INT = 0
	,@cuentaBancaria VARCHAR(50) = ''
	,@cuentaContable VARCHAR(50) = ''
	,@fechaElaboracion VARCHAR(50) = ''
	,@fechaCorte VARCHAR(50) = ''
	,@polizaPago VARCHAR(20) = ''
	,@opcion INT = 0 --1:reporte por empresa, 2: reporte por sistema (mensual,) 
AS
--BEGIN TRANSACTION TRAN_GUARDA_HISTORICO 
BEGIN TRY 

	DECLARE @fechaIni DATE = CONVERT(DATE, @fechaCorte);
	DECLARE @fechaFin DATE = GETDATE();

	IF( @opcion = 2 AND ( @FechaFin <= @FechaIni ) )
		BEGIN
			Select '' Hola;
			SELECT 1 estatus, 'No es posible cerrar el mes que solicita.' mensaje ;
			--COMMIT TRAN TRAN_GUARDA_HISTORICO;
		END
	ELSE
		BEGIN
		   DECLARE @mesActual INT = MONTH(@fechaElaboracion),
				   @anioActual INT = YEAR(@fechaElaboracion)


			DECLARE @considHistorico  INT = 0, 
					@periodoHistorico INT = 0; 

			SELECT 
				@considHistorico = Max(idHistorico) 
			FROM   HISTORICO_CONCILIACION HC 
				   INNER JOIN PeriodoActivo PA 
							ON HC.perido = PA.mec_numMes 
							--AND PA.mec_anio = 2018 
							AND HC.anio = PA.mec_anio
							AND HC.idEmpresa = PA.idEmpresa 
							AND HC.idBanco = PA.idBanco 
							AND HC.cuenta  = PA.cuentaBancaria
			WHERE  HC.idEmpresa = @idEmpresa 
				   AND HC.idBanco = @idBanco 
				   AND HC.cuenta = @cuentaBancaria 
				   AND PA.mec_conciliado = 0; 

			--IF( @considHistorico IS NOT NULL ) 
			--  BEGIN 
			--	  IF( @opcion = 1 ) 
			--		BEGIN 
			--			--DELETE FROM HISTORICO_CONCILIACION WHERE idEmpresa = @idEmpresa AND idusuario != 0
			--			--DELETE FROM DepositoBancarioDPI_H  WHERE idHistorico = @considHistorico 
			--			--DELETE FROM ABONOS_COMPLETO_CB_H   WHERE idHistorico = @considHistorico
			--			--DELETE FROM CARGOS_COMPLETO_CB_H   WHERE idHistorico = @considHistorico
			--			--DELETE FROM ABONOSBANCOS_CB_H	   WHERE idHistorico = @considHistorico
			--			--DELETE FROM CARGOSBANCOS_CB_H	   WHERE idHistorico = @considHistorico
			--			--DELETE FROM REGISTROS_PUNTEADOS_H  WHERE idHistorico = @considHistorico
			--		END 
			--  END 

			DECLARE @idHistorico NUMERIC(18, 0) = 0;
			--INSERTA ENCABEZADO DEL HISTORICO 
			--INSERT INTO HISTORICO_CONCILIACION 
			--	(idUsuario, 
			--	 idBanco, 
			--	 idEmpresa, 
			--	 fecha, 
			--	 cuenta, 
			--	 tipoHistorico, 
			--	 perido,
			--	 anio) 
			--VALUES      
			--	(@idUsuario, 
			--	@idBanco, 
			--	@idEmpresa, 
			--	Getdate(), 
			--	@cuentaBancaria, 
			--	@opcion, 
			--	@mesActual,
			--	@anioActual) 
			----SE RECUPERA ID DEL HISTORICO 
			--SET @idHistorico = @@IDENTITY 
			SET @idHistorico = 0

			-- Se guardadon los totales
			-- EXECUTE [DBO].[SEL_LOCAL_ABONOCARGO_SP_RECON] @idEmpresa, @idBanco, @cuentaBancaria, @cuentaContable, @fechaElaboracion, @fechaCorte, @polizaPago, 2, @idUsuario, @idHistorico
			-- Se llama al SP que guardara todos los registros de ABONOSBANCOS_CB
			EXEC [INS_HISTORICO_ABONOSBANCOS_SP_RECON] @idEmpresa, @idBanco, @cuentaBancaria, @cuentaContable, @idHistorico, @opcion, @idUsuario
			--EXEC [INS_HISTORICO_CARGOSBANCOS_SP_RECON] @idEmpresa, @idBanco, @cuentaBancaria, @cuentaContable, @idHistorico, @opcion, @idUsuario
			--EXEC [INS_HISTORICO_ABONOSCOMPLETO_SP_RECON] @idEmpresa, @idBanco, @cuentaBancaria, @cuentaContable, @idHistorico, @opcion, @idUsuario
			--EXEC [INS_HISTORICO_CARGOSCOMPLETOS_SP_RECON] @idEmpresa, @idBanco, @cuentaBancaria, @cuentaContable, @idHistorico, @opcion, @idUsuario
			--COMMIT TRAN TRAN_GUARDA_HISTORICO
			SELECT 0 estatus, 'Historico guardado correctamente.' mensaje 
		END
END TRY 

BEGIN CATCH 

    DECLARE @Mensaje    NVARCHAR(max), @Componente NVARCHAR(50) = '[INS_GUARDAHISTORICO_SP]' 

    SELECT @Mensaje = Error_message();

    SELECT Error_number() estatus, 'Ocurrio un error al guardar Historico. ' + @Mensaje     mensaje 
    --ROLLBACK TRAN TRAN_GUARDA_HISTORICO 
END CATCH
go

