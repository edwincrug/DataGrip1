-- [dbo].[SEL_ABONO_BANCARIO_SP_H] 25346
CREATE PROCEDURE [dbo].[SEL_ABONO_BANCARIO_SP_H]
	@idHistorico INT
AS
	BEGIN
		SELECT	
			'BANCO'  BANCO,
			CB.noCuenta CUENTA, 
			LTRIM(RTRIM(CB.fechaOperacion)) [FECHAOP],
			CONVERT(CHAR(15), CB.horaOperacion, 108) [HORAOP],
			LTRIM(RTRIM(CB.concepto)) [CONSEPTO],
			LTRIM(RTRIM(CB.referencia)) [REFERENCIA],
			LTRIM(RTRIM(CB.refAmpliada)) [REFAMPLIADA],
			CB.importe [IMPORTE]
		FROM ABONOSBANCOS_CB_H CB
		LEFT JOIN REGISTROS_PUNTEADOS_H PUN ON CB.IDABONOSBANCOS = PUN.rpun_idAbono AND PUN.rpun_tipo = 'B' and cb.idHistorico=PUN.idHistorico
		LEFT JOIN DepositoBancarioDPI_H DPI ON DPI.idAbonoBanco = CB.idBmer  and cb.idHistorico=dpi.idHistorico
		WHERE	CB.idHistorico = @idHistorico
				AND PUN.rpun_idPunteado IS NULL
				AND DPI.idDPI IS NULL
				AND CB.idEstatus = 0
				ORDER BY CB.fechaOperacion, CB.horaOperacion ASC;
END
go

