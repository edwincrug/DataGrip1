

-- ==========================================================================================
-- Author:	     Alejandro Grijalva Antonio
-- Create date:  27/11/2017
-- Description:	 Valida Usuario proveniente de BPRO
-- ==========================================================================================
CREATE PROCEDURE [dbo].[SEL_VALIDAUSUARIO_SP] 
	@idUsuario  varchar(50)
AS
BEGIN
	SELECT
		usu_idusuario AS idUsuario,
		5 AS idPerfil,
		(usu_nombre + ' '+ usu_paterno + ' ' + usu_materno) AS nombreUsuario,
		'Administrador Total' AS nombrePerfil
	FROM [ControlAplicaciones].[dbo].[cat_usuarios]
	WHERE usu_idusuario = @idUsuario;
END

go

