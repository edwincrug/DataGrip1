-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <20/06/2018>
-- Description:	<cancela el dpi en tesoreria>
-- =============================================
CREATE PROCEDURE [dbo].[CancelaCargoDPI_INS]
			@grupoPunteo int,
			@idAbonoBanco INT,
			@idBanco INT,
			@idEmpresa INT,
			@MOV_NUMCTA varchar(50),
			@MOV_CONSPOL INT ,
			@MOV_CONSMOV INT,
			@MOV_DEBE decimal(18,5) =0,
			@MOV_HABER decimal(18,5) =0,
			@MOV_IDCLIENTE numeric (18,0),
			@MOV_TIPOPOL nvarchar(10),
			@MOV_MES int,
			@MOV_ANIO int,
			@idusuario int,
			@MOV_IDDOCTO nvarchar(20)
		   

AS
BEGIN
----1.-Insertar en [CARGOS_COMPLETO_CB]--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	SET NOCOUNT ON;
declare @IDABONOS_COMPLETO numeric,@rpun_grupoPunteo int
INSERT INTO [dbo].[ABONOS_COMPLETO_CB]
           ([MOV_TIPOPOL],[MOV_CONSPOL],[MOV_CONSMOV],[MOV_MES],[MOV_NUMCTA],[MOV_CONCEPTO],[MOV_DEBE],[MOV_HABER],[MOV_ORIGEN],[MOV_IDCLIENTE],[MOV_DEPTO],[MOV_CARTERA],[MOV_TIPODOCTO],[MOV_IDDOCTO],[MOV_FECHVEN]
           ,[MOV_FECHPAG],[MOV_AGENTE],[MOV_CVEUSU] ,[MOV_FECHOPE] ,[MOV_CONCILIADO],[MOV_FOLIO],[MOV_FOLIODET],[MOV_MONEDA],[MOV_TIPOCAMBIO],[MOV_HORAOPE],[MOV_OBSERVA],[Tipo],[idUsuario],[idEmpresa],[idBanco],[anio],[fecha],[idEstatus],[idConciliado])
		        VALUES
           (@MOV_TIPOPOL			--<MOV_TIPOPOL, varchar(10),>
           ,@MOV_CONSPOL			--<MOV_CONSPOL, numeric(18,0),>
           ,@MOV_CONSMOV			--<MOV_CONSMOV, numeric(18,0),>
           ,@MOV_MES			--<MOV_MES, numeric(18,0),>
           ,@MOV_NUMCTA			--<MOV_NUMCTA, varchar(50),>
           ,'DEPOSITO IDENTIFICADO'+' '+@MOV_IDDOCTO			--<MOV_CONCEPTO, varchar(250),>
           ,@MOV_HABER		--<MOV_DEBE, decimal(18,5),>
           ,@MOV_DEBE			--<MOV_HABER, decimal(18,5),>
           ,''			--<MOV_ORIGEN, varchar(50),>
           ,@MOV_IDCLIENTE			--<MOV_IDCLIENTE, numeric(18,0),>
           ,''			--<MOV_DEPTO, varchar(50),>
           ,''			--<MOV_CARTERA, varchar(50),>
           ,''			--<MOV_TIPODOCTO, varchar(50),>
           ,''			--<MOV_IDDOCTO, varchar(20),>
           ,''			--<MOV_FECHVEN, varchar(10),>
           ,''			--<MOV_FECHPAG, varchar(10),>
           ,''			--<MOV_AGENTE, varchar(50),>
           ,3			--<MOV_CVEUSU, varchar(10),>
           ,convert(varchar(10),getdate(),103)			--<MOV_FECHOPE, varchar(10),>
           ,''			--<MOV_CONCILIADO, varchar(1),>
           ,0			--<MOV_FOLIO, numeric(18,0),>
           ,0			--<MOV_FOLIODET, numeric(18,0),>
           ,'PE'			--<MOV_MONEDA, varchar(10),>
           ,'1'			--<MOV_TIPOCAMBIO, decimal(18,5),>
           ,''			--<MOV_HORAOPE, varchar(8),>
           ,''			--<MOV_OBSERVA, varchar(250),>
           ,0			--<Tipo, int,>
           ,3			--<idUsuario, int,>
           ,@idEmpresa			--<idEmpresa, int,>
           ,@idBanco			--<idBanco, int,>
           ,@MOV_ANIO			--<anio, int,>
           ,getdate()			--<fecha, datetime,>
           ,0			--<idEstatus, int,>
           ,1			--<idConciliado, int,>
		   )
set @IDABONOS_COMPLETO=SCOPE_IDENTITY()
select @IDABONOS_COMPLETO id into ##TempCancelaDPI2
----2.-Actualizar en [REGISTROS_PUNTEADOS]--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--update [dbo].[REGISTROS_PUNTEADOS] set rpun_idAbono=@IDABONOS_COMPLETO,rpun_tipo='C'
--where rpun_grupoPunteo=@grupoPunteo and rpun_tipo = 'B'
--update [dbo].[REGISTROS_PUNTEADOS] set rpun_fechaPunteo = getdate(), rpun_idAplicado=1
--where rpun_grupoPunteo=@grupoPunteo
declare @idDPI numeric(18,0)
select top 1 @idDPI=idDPI from DepositoBancarioDPI where idAbonoBanco in (select top 1 idBmer from abonosbancos_cb where IDABONOSBANCOS=@idAbonoBanco)

INSERT INTO [dbo].[CancelaDPI]
           ([idDPI]
           ,[idOrigen]
           ,[idUsuario]
           ,[fecha]
           ,[idAbonos_Completo])
     VALUES
           (@idDPI
           ,1
           ,@idusuario
           ,getdate()
           ,@IDABONOS_COMPLETO)

END
go

