-- [dbo].[SEL_CARGO_BANCARIO_SP_H] 25346
CREATE PROCEDURE [dbo].[SEL_CARGO_BANCARIO_SP_H]
	@idHistorico INT = 0
AS
BEGIN

			SELECT
			    'BANCO'  BANCO,
				CAR.noCuenta CUENTA, 
				LTRIM(RTRIM(CAR.fechaOperacion)) [FECHAOP],
				CONVERT(CHAR(15), CAR.horaOperacion, 108) [HORAOP],
				LTRIM(RTRIM(CAR.concepto)) [CONSEPTO],
				LTRIM(RTRIM(CAR.referencia)) [REFERENCIA],
				LTRIM(RTRIM(CAR.refAmpliada)) [REFAMPLIADA],
				CAR.importe [IMPORTE]
			FROM CARGOSBANCOS_CB_H CAR  --CARGOS
			LEFT JOIN [REGISTROS_PUNTEADOS_H] PUN
			  ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo
				 AND PUN.idHistorico = @idHistorico
				 AND PUN.rpun_tipo = 'B'
			WHERE   
					 CAR.idEstatus = 0
				AND PUN.rpun_idPunteado IS NULL 
				
					AND CAR.idHistorico = @idHistorico
	
END
go

