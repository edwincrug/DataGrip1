
CREATE procedure [dbo].[SEL_CONTROLD_DEPOSITOS_PENDIENTES_SP]

@idUsuario int

AS
BEGIN
Declare @mes int,@anio int,@fechainicial nvarchar(10),@fechafinal nvarchar(10)
select @mes=month(getdate()),@anio=year(getdate())
Set @fechainicial = convert(nvarchar(4),@anio)+'-'+right('0'+convert(varchar(2), convert(nvarchar(2),@mes)), 2)+'-01'
Select @fechafinal=dateadd(day, -1, convert(date,convert(nvarchar(4),case when @mes=12 then @anio+1 else @anio end)+convert(nvarchar(2),case when @mes=12 then '01'  else right('0'+convert(varchar(2), convert(nvarchar(2),@mes+1)), 2) end)+'01',112))
select distinct * from (
SELECT  dep.idBmer idDepositoBanco,                                                                                                                                                                                                                                
        dep.importe,                                                                                                                                                                                                                                
        dep.nocuenta,                                                                                                                                                                                                                                
        ref.fecha,                                                                                                                                                                                                                                
        ref.idReferencia,                                                                                                                                                                                                                                
        ref.referencia ,                                                                                                                                                                                                                                
        (select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where ref.idEmpresa =  emp_idempresa  ) nomEmpresa,
        (select descripcion from TipoReferencia  where ref.tipoReferencia =  idTipoReferencia  ) tipoRefNombre,
        (select nombre from [referencias].[dbo].[banco]  where dep.idbanco = idbanco  )  nombreBanco
		
        from Referencia ref 
		inner join DetalleReferencia d on ref.idReferencia=d.idReferencia
		inner join  controlDepositosView dep
        on  ref.depositoID  = dep.idbmer and ref.estatus =0 and ref.IDBanco=dep.IDBanco
		INNER JOIN ControlAplicaciones.dbo.ope_organigrama o on ref.idempresa=o.emp_idempresa and o.usu_idusuario=@idUsuario
		where dep.IDBanco IN (1,2,3) and ref.fecha >= convert(date,@fechainicial,23) and ref.fecha < dateadd(day,1,convert(date,@fechafinal,23)) and esCargo=0
		union all
SELECT dep.idBmer idDepositoBanco,                                                                                                                                                                                                                                
        dep.importe,                                                                                                                                                                                                                                
        dep.nocuenta,                                                                                                                                                                                                                                
        ref.fecha,                                                                                                                                                                                                                                
        ref.idReferencia,                                                                                                                                                                                                                                
        ref.referencia ,                                                                                                                                                                                                                                
        (select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where ref.idEmpresa =  emp_idempresa  ) nomEmpresa,
        (select descripcion from TipoReferencia  where ref.tipoReferencia =  idTipoReferencia  ) tipoRefNombre,
        (select nombre from [referencias].[dbo].[banco]  where dep.idbanco = idbanco  )  nombreBanco
        from Referencia ref inner join  (SELECT     d.idDpiAnterior idBmer, IDBanco,'' txtOrigen,'' registro,0 noMovimiento, referencia,referencia concepto,referencia refAmpliada,0 esCargo, importe,0 saldoOperativo,'' codigoLeyenda,0 oficinaOperadora, 
                      fecha fechaOperacion,null  horaOperacion,fecha fechaValor,fecha fechaContable,0 estatus,0 [estatusRevision],d.cuenta noCuenta
FROM         tesoreria.dbo.dpiAnterior d 
inner join referencias.dbo.BancoCuenta b on d.cuenta=b.numeroCuenta) dep
        on  ref.depositoID  = dep.idbmer and ref.estatus =0 and ref.IDBanco=dep.IDBanco
		INNER JOIN ControlAplicaciones.dbo.ope_organigrama o on ref.idempresa=o.emp_idempresa and o.usu_idusuario=@idUsuario
		where dep.IDBanco IN (1,2,3) and ref.fecha >= convert(date,@fechainicial,23) and ref.fecha < dateadd(day,1,convert(date,@fechafinal,23))

union all
SELECT distinct dep.idBmer idDepositoBanco,                                                                                                                                                                                                                                
        dep.importe,                                                                                                                                                                                                                                
        dep.nocuenta,                                                                                                                                                                                                                                
        ref.fecha,                                                                                                                                                                                                                                
        ref.idReferencia,                                                                                                                                                                                                                                
        ref.referencia ,                                                                                                                                                                                                                                
        (select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where ref.idEmpresa =  emp_idempresa  ) nomEmpresa,
        (select descripcion from TipoReferencia  where ref.tipoReferencia =  idTipoReferencia  ) tipoRefNombre,
        (select nombre from [referencias].[dbo].[banco]  where dep.idbanco = idbanco  )  nombreBanco
		
        from Referencia ref 
		inner join DetalleReferencia d on ref.idReferencia=d.idReferencia
		INNER JOIN ControlAplicaciones.dbo.ope_organigrama o on ref.idempresa=o.emp_idempresa and o.usu_idusuario=@idUsuario
		inner join  (select a.idbmer,a.importe,a.noCuenta, a.idbanco from DepositoBancarioDPI d inner join ABONOSBANCOS_CB a on d.idAbonoBanco=a.idBmer and d.idBanco=a.IDBanco
		LEFT JOIN CancelaDPI CAN ON CAN.idDPI = D.idDPI where idCancelaDPI is null) dep
        on  ref.depositoID  = dep.idbmer and ref.estatus =0 and ref.IDBanco=dep.IDBanco
		where dep.IDBanco IN (1,2,3) and ref.fecha >= convert(date,@fechainicial,23) and ref.fecha < dateadd(day,1,convert(date,@fechafinal,23))
		) x
--		select @fechainicial
--select @fechafinal
--select @fechainicial,@fechafinal, convert(date,@fechainicial,23) , convert(date,@fechafinal,23)
 --select                                                                                                                                                                                                                                
 --       dep.idBmer idDepositoBanco,                                                                                                                                                                                                                                
 --       dep.importe,                                                                                                                                                                                                                                
 --       dep.nocuenta,                                                                                                                                                                                                                                
 --       ref.fecha,                                                                                                                                                                                                                                
 --       ref.idReferencia,                                                                                                                                                                                                                                
 --       ref.referencia ,                                                                                                                                                                                                                                
 --       (select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where ref.idEmpresa =  emp_idempresa  ) nomEmpresa,
 --       (select descripcion from TipoReferencia  where ref.tipoReferencia =  idTipoReferencia  ) tipoRefNombre,
 --       (select nombre from [referencias].[dbo].[banco]  where dep.idbanco = idbanco  )  nombreBanco
 --       from Referencia ref inner join  controlDepositosView dep
 --       on  ref.depositoID  = dep.idbmer and ref.estatus =0
	--	where IDBanco =1

--	select * from controlDepositosview 

END
go

