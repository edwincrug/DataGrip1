-- =============================================
-- Author:		Ing. Luis Antonio Garcia Perrusquia
-- Create date: 09/05/2018
-- Description:	Trae los registros del universo para los no conciliados Historico
-- EXECUTE [dbo].[SEL_TODO_CONTABLE_SP_H] 5, 1, '1100-0020-0001-0001', '2020-01-01', 7
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TODO_CONTABLE_SP_H]
@idEmpresa INT,
@idBanco INT,
@noCuenta VARCHAR(100),
@fechaElaboracion VARCHAR(50),
@idHistorico INT
AS
BEGIN TRY
	SET LANGUAGE Español
	SELECT	
		MOV.IDABONOS_COMPLETO idAuxiliarContable,
		@idEmpresa idEmpresa,
		MOV.MOV_CONSMOV movConsMov, --?
		MOV.MOV_NUMCTA numeroCuenta,
		MOV.MOV_TIPOPOL polTipo,
		MOV.MOV_CONSPOL polConsecutivo,
		MOV.MOV_CONCEPTO movConcepto,
		MOV.MOV_DEBE cargo,
		MOV.MOV_HABER abono,
		MOV.MOV_FECHOPE movFechaOpe,
		MOV.MOV_HORAOPE movHoraOpe,
		1 idEstatus,
		0 fechaAnterior,
		'' color,
		'' referenciaAuxiliar,
		UPPER(DATENAME(YEAR, CONVERT(DATE,MOV_FECHOPE,103))) anio,
		UPPER(DATENAME(month, CONVERT(DATE,MOV_FECHOPE,103))) MES,
		0 esCargo
	FROM  [ABONOS_COMPLETO_CB_H] MOV
	WHERE    MOV.MOV_NUMCTA = @noCuenta 
			AND MOV.idEmpresa = @idEmpresa 
			AND MOV.idBanco = @idBanco
			AND MOV.idEstatus = 0
			AND IDABONOS_COMPLETO NOT IN (SELECT rpun_idAbono FROM REGISTROS_PUNTEADOS_H WHERE  rpun_tipo = 'C' AND idHistorico = @idHistorico)
		--	AND MOV.anio = YEAR(@fechaElaboracion)
			AND MOV.idHistorico = @idHistorico
 
	UNION ALL
		
	SELECT	
		MOV.IDCARGOS_COMPLETO idAuxiliarContable,
		@idEmpresa idEmpresa,
		MOV.MOV_CONSMOV movConsMov, 
		MOV.MOV_NUMCTA numeroCuenta,
		MOV.MOV_TIPOPOL polTipo,
		MOV.MOV_CONSPOL polConsecutivo,
		MOV.MOV_CONCEPTO movConcepto,
		MOV.MOV_DEBE cargo,
		MOV.MOV_HABER abono,
		MOV.MOV_FECHOPE movFechaOpe,
		MOV.MOV_HORAOPE movHoraOpe,
		1 idEstatus,
		0 fechaAnterior,
		'' color,
		'' referenciaAuxiliar,
		UPPER(DATENAME(YEAR, CONVERT(DATE,MOV_FECHOPE,103))) anio,
		UPPER(DATENAME(month, CONVERT(DATE,MOV_FECHOPE,103))) MES,
		1 esCargo
	FROM  [CARGOS_COMPLETO_CB_H] MOV
	
	WHERE 
	MOV.MOV_NUMCTA = @noCuenta 
			AND MOV.idEmpresa = @idEmpresa 
			AND MOV.idBanco = @idBanco
			AND MOV.idEstatus = 0
			AND IDCARGOS_COMPLETO NOT IN (SELECT rpun_idCargo FROM REGISTROS_PUNTEADOS_H WHERE rpun_tipo = 'C' AND idHistorico = @idHistorico)
		--	AND MOV.anio = YEAR(@fechaElaboracion)
			AND MOV.idHistorico = @idHistorico
-------------------------------------------------------------------------------------------------------------------
END TRY
BEGIN CATCH
			SELECT ERROR_MESSAGE() +'' + ERROR_LINE() AS ERROR
END CATCH
go

