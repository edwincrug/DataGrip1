-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-05-17
-- Description:	Obtiene los registros punteados aplicados o no aplicados
-- [dbo].[SEL_PUNTEO_DETALLE_SP_H] 0, 1;
-- [dbo].[SEL_PUNTEO_DETALLE_SP_H]_ 1, 1;
-- [dbo].[SEL_PUNTEO_DETALLE_SP_H] 1;
-- [dbo].[SEL_PUNTEO_DETALLE_SP_H] 4, 44, '2018-07-01';
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PUNTEO_DETALLE_SP_H]
	@idEmpresa INT = 0,
	@idHistorico INT = 0,
	@fechaElaboracion VARCHAR(12)= ''
AS
BEGIN
	DECLARE @cuentaContable VARCHAR(30) = (SELECT 
												cuentaContable 
											FROM referencias.dbo.BancoCuenta WHERE numeroCuenta = (SELECT 
																										cuenta 
																									FROM HISTORICO_CONCILIACION WHERE idHistorico = @idHistorico))
	--===== Bancos
	SELECT
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[idBmer]		= ABO.idBmer,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[referencia]	= ABO.referencia,
		[fechaOperacion]= ABO.fechaOperacion,
		[concepto]		= ABO.concepto + ' ' + ABO.refAmpliada,
		[cargo]			= CASE rpun_idCargo WHEN 0 THEN 0 ELSE ABO.importe END,
		[abono]			= CASE rpun_idAbono WHEN 0 THEN 0 ELSE ABO.importe END
	FROM REGISTROS_PUNTEADOS_H PUN
	INNER JOIN [ABONOSBANCOS_CB_H] ABO  ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS 
										AND ABO.idHistorico = @idHistorico
										AND ABO.idEstatus = 0
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = ABO.IDBanco
	WHERE rpun_tipo = 'B'
		  AND idEmpresa = @idEmpresa
		  AND PUN.idHistorico = @idHistorico
		  AND ABO.idHistorico = @idHistorico
		  --AND MONTH(ABO.fechaOperacion) = MONTH(@fechaElaboracion)
		  --AND YEAR(ABO.fechaOperacion) = YEAR(@fechaElaboracion)
		  AND ABO.idEstatus = 0
	UNION ALL
	SELECT
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[idBmer]		= CAR.idBmer,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[referencia]	= CAR.referencia,
		[fechaOperacion]= CAR.fechaOperacion,
		[concepto]		= CAR.concepto + ' ' + CAR.refAmpliada,
		[cargo]			= CASE rpun_idCargo WHEN 0 THEN 0 ELSE CAR.importe END,
		[abono]			= CASE rpun_idAbono WHEN 0 THEN 0 ELSE CAR.importe END
	FROM REGISTROS_PUNTEADOS_H PUN
	INNER JOIN [CARGOSBANCOS_CB_H] CAR  ON PUN.rpun_idCargo = CAR.IDCARGOSBANCOS 
										AND CAR.idHistorico = @idHistorico
										AND CAR.idEstatus = 0
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = CAR.IDBanco
	WHERE rpun_tipo = 'B'
		  AND idEmpresa = @idEmpresa
		  AND PUN.idHistorico = @idHistorico
		  AND CAR.idHistorico = @idHistorico
		  --AND MONTH(CAR.fechaOperacion) = MONTH(@fechaElaboracion)
		  --AND YEAR(CAR.fechaOperacion) = YEAR(@fechaElaboracion)

	--===== Contable
	SELECT 
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[Identificador] = CAR.IDCARGOS_COMPLETO,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[fecha]			= CAR.MOV_FECHOPE,
		[tipoPoliza]	= CAR.MOV_TIPOPOL,
		[poliza]		= CAR.MOV_CONSPOL,
		[concepto]		= CAR.MOV_CONCEPTO,
		[cargo]			= CAR.MOV_DEBE,
		[abono]			= CAR.MOV_HABER
	FROM REGISTROS_PUNTEADOS_H PUN
	INNER JOIN [CARGOS_COMPLETO_CB_H] CAR   ON PUN.rpun_idCargo = CAR.IDCARGOS_COMPLETO
											AND CAR.idHistorico = @idHistorico
											AND CAR.idEstatus = 0
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = CAR.idBanco
	WHERE rpun_tipo = 'C'
		  AND idEmpresa = @idEmpresa
		  AND PUN.idHistorico = @idHistorico
		  AND CAR.idHistorico = @idHistorico
		  AND CAR.MOV_NUMCTA = @cuentaContable
		  --AND CAR.MOV_MES = MONTH(@fechaElaboracion)
		  --AND CAR.anio = YEAR(@fechaElaboracion)
		  AND CAR.idEstatus = 0
		  
	UNION ALL
	SELECT 
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[Identificador] = ABO.IDABONOS_COMPLETO,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[fecha]			= ABO.MOV_FECHOPE,
		[tipoPoliza]	= ABO.MOV_TIPOPOL,
		[poliza]		= ABO.MOV_CONSPOL,
		[concepto]		= ABO.MOV_CONCEPTO,
		[cargo]			= ABO.MOV_DEBE,
		[abono]			= ABO.MOV_HABER
	FROM REGISTROS_PUNTEADOS_H PUN
	INNER JOIN [ABONOS_COMPLETO_CB_H] ABO   ON PUN.rpun_idAbono = ABO.IDABONOS_COMPLETO
											AND ABO.idHistorico = @idHistorico
											AND ABO.idEstatus = 0	
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = ABO.idBanco
	WHERE rpun_tipo = 'C'
		  AND idEmpresa = @idEmpresa
		  AND PUN.idHistorico = @idHistorico
		  AND ABO.idHistorico = @idHistorico
		  AND ABO.MOV_NUMCTA = @cuentaContable
		  --AND ABO.MOV_MES = MONTH(@fechaElaboracion)
		  --AND ABO.anio = YEAR(@fechaElaboracion)
		  AND ABO.idEstatus = 0
END
go

