-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <30/10/2018>
-- Description:	<valida el grupo en el layout>
-- =============================================
--[dbo].[ValidaGrupoLayout_SEL] 122
CREATE PROCEDURE [dbo].[ValidaGrupoLayout_SEL]
--declare
			 @grupo int
AS
BEGIN
declare  @suma decimal(18,2),@idempresa int
			,@idbanco int ,@repetido int
		
SELECT @suma=sum(cargo)+sum(abono) FROM referencias.dbo.MovimientoBancarioLayout
where idGrupoIns = @grupo and status =1
group by idGrupoIns
SELECT idGrupoIns into #temp FROM referencias.dbo.MovimientoBancarioLayout 
WHERE  month(fecharegistro)=10 
and idGrupoIns != @grupo  and status =1
group by idGrupoIns
having sum(cargo)+sum(abono)-@suma =0
select @repetido=case when count(*) >0 then 1 else 0 end  from #temp x
SELECT 
 o.[idMovimiento]
,o.[noCuenta]
,o.[fecha]
,o.[descripcion]
,o.[referencia]
,o.[descripcionAmpliada]
,o.[tipoMovimiento]
,o.[cargo]
,o.[abono]
,o.[idEmpresa]
,o.[idBanco]
,o.[fechaRegistro]
,o.[idGrupoIns]
,o.[status]
,c.idMovimiento idmovimientocopia,c.idgrupoIns grupoduplicado,case when c.idMovimiento is null then 'No' else 'Si' end seEncontro into #temp2 
FROM referencias.dbo.MovimientoBancarioLayout o
left join (SELECT [idMovimiento]
      ,[noCuenta]
      ,[fecha]
      ,[descripcion]
      ,[referencia]
      ,[descripcionAmpliada]
      ,[tipoMovimiento]
      ,[cargo]
      ,[abono]
      ,[idEmpresa]
      ,[idBanco]
      ,[fechaRegistro]
      ,[idGrupoIns]
      ,[status] FROM referencias.dbo.MovimientoBancarioLayout
where idGrupoIns in (SELECT idGrupoIns from #temp)) c on o.noCuenta=c.noCuenta and o.fecha=c.fecha and o.descripcion=c.descripcion and o.referencia=c.referencia and o.cargo=c.cargo and o.abono=c.abono
where o.idGrupoIns = @grupo  
if (@repetido=1 and not exists(select seencontro from #temp2 where seencontro = 'No'))
begin


select @repetido gruposRepetidos
select [idMovimiento]
      ,[noCuenta]
      ,[fecha]
      ,[descripcion]
      ,[referencia]
      ,[descripcionAmpliada]
      ,[tipoMovimiento]
      ,[cargo]
      ,[abono]
      ,[idEmpresa]
      ,[idBanco]
      ,[fechaRegistro]
      ,[idGrupoIns]
      ,[status]
 ,idmovimientocopia, grupoduplicado, seEncontro
 from #temp2
update referencias.dbo.MovimientoBancarioLayout set status=0
where idGrupoIns = @grupo
End
else
begin

select 0 gruposRepetidos
end
drop table #temp
drop table #temp2

END
go

