-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <27/07/2018>
-- Description:	<Saca resumen de todos los bancos con periodos activos>
-- =============================================
CREATE PROCEDURE [dbo].[CreaResumenBancos_INS]

AS
BEGIN


truncate table [dbo].[ResumenBancos]
-- Declaracion de variables para el cursor

DECLARE @IdEmpresa int,
		@IdBanco int,
		@cuentaBancaria nvarchar(50),
		@cuentaContable nvarchar(50),
		@fechaInicial datetime,
		@fechaFinal datetime

DECLARE @intFlag INT, @endFlag INT=0
SET @intFlag = 1
select ROW_NUMBER() OVER(ORDER BY b.idEmpresa,b.idBanco) AS rowLine,b.idEmpresa,b.idBanco,b.numeroCuenta,b.cuentaContable,  DATEADD(MONTH, DATEDIFF(MONTH, 0, convert(nvarchar(4),p.mec_anio)+'-'+RIGHT('0' + convert(nvarchar(2),p.mec_numMes),2)+'-'+RIGHT('0' + convert(nvarchar(2),p.mec_numMes),2)), 0) fechainicial,DATEADD(month, ((p.mec_anio - 1900) * 12) + p.mec_numMes, -1) fechafinal
into #temp
 from referencias.dbo.bancocuenta b
inner join Tesoreria.dbo.PeriodoActivo p on b.idEmpresa=p.idEmpresa and b.idBanco=p.idBanco and p.mec_conciliado=0 and b.numeroCuenta=p.cuentaBancaria
where b.idEmpresa !=7 
select @endFlag=max(rowLine) from #temp

WHILE (@intFlag <=@endFlag)
BEGIN
select @IdEmpresa=IdEmpresa,@IdBanco=IdBanco,@cuentaBancaria=numeroCuenta,@cuentaContable=cuentaContable,@fechaInicial=fechaInicial,@fechaFinal=fechaFinal from #temp where rowLine=@intFlag

    exec [SEL_RESUMEN_ABONOCARGO_SP] @IdEmpresa,@IdBanco,@cuentaBancaria,@cuentaContable,@fechaInicial,@fechaFinal,0,0,71,0

    SET @intFlag = @intFlag + 1
END


SELECT [idResumenBancos]
      ,[idEmpresa]
      ,[idBanco]
      ,[cuentaBancaria]
      ,[cuentaContable]
      ,[saldoBanco]
      ,[totalAbonoContable]
      ,[totalCargoContable]
      ,[totalAbonoBancario]
      ,[totalCargoBancario]
      ,[saldoConciliacion]
      ,[saldoContabilidad]
      ,[diferencia]
      ,[mesActivo]
      ,[fecha]
  FROM [dbo].[ResumenBancos]
  where  idEmpresa not in (7,8,11,13) and (diferencia>100 or diferencia<-100)
  order by idEmpresa,idBanco
END
go

