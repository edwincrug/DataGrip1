-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <25/03/2019>
-- Description:	<Elimina el abono bancos>
-- =============================================
CREATE PROCEDURE [dbo].[DEL_CargosBancos_SP]
	@IDCargosBANCOS [numeric](18, 0),
	@idUsuario [int] 

AS
BEGIN

UPDATE [dbo].[CargosBANCOS_CB]
   SET [idEstatus] = 1
      
 WHERE [IDCARGOSBANCOS]=@IDCargosBANCOS


INSERT INTO [dbo].[CancelaBANCOS]
           ([IDABONOSBANCOS]
           ,[idUsuario]
           ,[fecha]
		   ,[tipo])
     VALUES
           (@IDCargosBANCOS
           ,@idUsuario
           ,getdate()
		   ,'C')

	SELECT '1' success
END
go

