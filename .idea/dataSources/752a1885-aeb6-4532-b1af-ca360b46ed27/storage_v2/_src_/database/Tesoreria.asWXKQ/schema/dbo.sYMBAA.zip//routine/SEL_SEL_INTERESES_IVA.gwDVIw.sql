
CREATE PROCEDURE  [dbo].[SEL_[SEL_INTERESES_IVA]

@idDepositoBanco int =0
AS
BEGIN



SELECT
		idbmer idDepositoBanco
      ,[idBanco]
      ,[idBmer]
      ,'bancomer' banco
      ,[txtOrigen]
      ,[noCuenta]
      ,[concepto]
      ,[importe] as abono
	  ,0 as cargo
      ,[saldoOperativo]
      ,[referencia]
      ,[fechaOperacion]
      ,[horaOperacion]
      ,[oficinaOperadora]

FROM referencias.DBO.BANCOMER WHERE codigoLeyenda IN
(
	SELECT        CodigoBanco--, TipoMovimiento, Descripcion, CodigoBPRO, IDBanco
	FROM           referencias.DBO. CodigoIdentificacion
	where descripcion like 'iva interes%' and CodigoBanco 
		like 'C%'
	)
 and idbmer  between @idDepositoBanco-1 and @idDepositoBanco+1


END
go

