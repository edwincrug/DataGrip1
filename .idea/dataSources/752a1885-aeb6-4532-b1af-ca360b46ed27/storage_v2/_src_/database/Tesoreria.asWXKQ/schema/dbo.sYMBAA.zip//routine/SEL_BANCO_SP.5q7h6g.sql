CREATE PROCEDURE [dbo].[SEL_BANCO_SP]  @idBanco as int as 
begin 

           SELECT DISTINCT(bc.idBanco) AS IdBanco, 
		   UPPER(banco.nombre) AS Nombre,
		   bc.Carga_Layout AS Layout  
		   FROM referencias.dbo.Banco banco
		   INNER JOIN referencias.dbo.BancoCuenta bc
		   ON banco.idBanco = bc.idBanco
		   WHERE bc.idEmpresa = @idBanco
		   ORDER BY bc.idBanco asc

 end



go

