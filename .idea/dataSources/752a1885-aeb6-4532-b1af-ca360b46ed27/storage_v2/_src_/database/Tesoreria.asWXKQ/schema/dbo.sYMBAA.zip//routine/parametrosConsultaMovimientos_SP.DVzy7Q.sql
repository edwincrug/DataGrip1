-- =============================================
-- Author: Roberto Almanza
-- Create date:
-- Description: Obtiene los parametros configurados para el portal de consulta de moviimentos
-- =============================================
CREATE PROCEDURE dbo.parametrosConsultaMovimientos_SP
@idModulo int
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
SELECT
id
,modulo
,tipo
,Destinatario
,asunto
FROM dbo.parametrosConsultaMovimientos
where modulo = @idModulo
END
go

