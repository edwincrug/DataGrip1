-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date, 2017-11-10>
-- Description:	EXECUTE dbo.[SEL_TOTAL_ABONOCARGO_SP_H] 4,1,'65504258249','1100-0020-0001-0018','2017-12-01','2017-12-05','TREEUN',2
                   --'2017-11-01','2017-11-30','1100-0020-0001-0010','000000000190701289','TREEZ',4,1,1
	/*	
		
		SEL_TOTAL_ABONOCARGO_SP_H @idEmpresa = 1, @idBanco = 1, @noCuenta = '1100-0020-0001-0010', @cuentaContable = '000000000190701289', @fechaElaboracion = '20180301',  @fechaCorte = '20180316',
								  @polizaPago = '', @opcion = 1, @idUsuario = 0

	*/
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TOTAL_ABONOCARGO_SP_H]
@idEmpresa VARCHAR(50),
@idBanco INT,
@noCuenta VARCHAR(50),
@cuentaContable VARCHAR(50),	
@fechaElaboracion VARCHAR(50),
@fechaCorte VARCHAR(50),
@polizaPago VARCHAR(20),
@opcion INT, --1: detalle, 2: resumen
@idUsuario INT = 0,
@tipoReporte INT = 0 --1: empresa, 2: sistema (fin de mes) 

AS
BEGIN TRY

		DECLARE @mesActual INT;
		SELECT @mesActual = DATEPART(MONTH,REPLACE(@fechaElaboracion,'-',''))

		DECLARE @anioActual INT;
		SELECT @anioActual = YEAR(@fechaElaboracion);

		DECLARE @saldoBanco NUMERIC(18,6) = 0,
				@totalAbonoContable NUMERIC(18,6) = 0,
				@totalCargoContable NUMERIC(18,6) = 0,
				@totalAbonoBancario NUMERIC(18,6) = 0,
				@totalCargoBancario NUMERIC(18,6) = 0,
				@SaldoInicial NUMERIC(18,6) = 0,
				@saldoConciliacion NUMERIC(18,6) = 0,
				@saldoContabilidad NUMERIC(18,6) = 0,
				@diferencia NUMERIC(18,6) = 0,
				@mesActivo INT = 0,
				@idHistorico DECIMAL(18,0) = 0,
				@fechaGuardado VARCHAR(50) = '',
				@mensaje VARCHAR(50) = 'No se han encontrado registros',
				@resultado INT = 0
						
				SELECT TOP(1) @idHistorico = idHistorico,
							  @fechaGuardado = CONVERT(VARCHAR(50),fecha,113)	 
				FROM HISTORICO_CONCILIACION 
				WHERE   idBanco = @idBanco 
						AND idEmpresa = @idEmpresa 
						AND cuenta = @noCuenta
						AND perido = @mesActual
						AND anio = @anioActual
						AND tipoHistorico = @tipoReporte
						AND idUsuario != 0
				ORDER BY idHistorico DESC
					

----------------------------------------------------------Regreso el resultado de los cálculos---------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF EXISTS (SELECT *	FROM TOTALES_H WHERE idHistorico = @idHistorico)
				BEGIN
						 SELECT @saldoBanco = saldoBanco,
								@totalAbonoContable = tAbonoContable,
								@totalCargoContable = tAbonoBancario,
								@totalAbonoBancario = tCargoContable,	
								@totalCargoBancario = tCargoBancario,
								@saldoConciliacion = sConciliacion,
								@saldoContabilidad = sContabilidad,
								@diferencia = diferencia,
								@mesActivo = mesActivo,
								@idHistorico = idHistorico,
								@resultado = 1,
								@mensaje = 'Registros encontrados.'
						 FROM TOTALES_H WHERE idHistorico = @idHistorico
				END

				SELECT  @saldoBanco saldoBanco,
						@totalAbonoContable tAbonoContable,
						@totalCargoContable tAbonoBancario,
						@totalAbonoBancario tCargoContable,
						@totalCargoBancario tCargoBancario,
						@saldoConciliacion sConciliacion,
						@saldoContabilidad sContabilidad,
						@diferencia diferencia,
						@mesActivo mesActivo,
						@idHistorico idHistorico,
						@fechaGuardado fecha,
						@mensaje mensaje,
						@resultado resultado 
			
END TRY
BEGIN CATCH

       SELECT ERROR_MESSAGE() + '' + ERROR_LINE() AS ERROR

END CATCH

go

