CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTO_BY_USUARIO_SP]
@idUsuario INT,
@idSucursal INT
AS
BEGIN
  select distinct (Depto.dep_nombre), Depto.dep_iddepartamento from [ControlAplicaciones].[dbo].[ope_organigrama] Orga
  INNER JOIN [ControlAplicaciones].[dbo].[cat_departamentos] Depto ON Orga.dep_iddepartamento = Depto.dep_iddepartamento
  where Orga.usu_idusuario = @idUsuario and Orga.suc_idsucursal = @idSucursal
 END
go

