-- =============================================
-- Author:		<Author Rodrigo Olivares>
-- Create date: <2017-09-14>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_RELACION_REG_BANCOS_REF_SP] 
	-- Add the parameters for the stored procedure here
@referenciaAmpliada VARCHAR(50),
@tipoDato INT,
@idEmpresa INT,
@cuentaContable VARCHAR(50),
@fecha VARCHAR(30),
@polizaPago VARCHAR(30),
@noCuenta VARCHAR(50),
@idRegistroBanco INT

AS
BEGIN TRY
DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), item nvarchar(50))
DECLARE @idLote nvarchar(50)
DECLARE @idPersona nvarchar(50)
DECLARE @consecutivo nvarchar(50)
DECLARE @CountIdLote nvarchar(50)
DECLARE @añoConsulta INT
DECLARE @mesConsulta INT
DECLARE @tipoPoliza VARCHAR(10)
DECLARE @query NVARCHAR(MAX)
	-- SET NOCOUNT ON added to prevent extra result sets from
---Variables para la parametrización de las conexiones a bases de datos (según empresas)
DECLARE @ipLocal varchar(50)
DECLARE @nombreBase varchar(50)
DECLARE @ip_catBases varchar(50) 


--Obtengo la ip local
SELECT	@ipLocal = dec.local_net_address
FROM	sys.dm_exec_connections AS dec
WHERE	dec.session_id = @@SPID;

--Seleciono la información dependiendo del identificador de la empresa
SELECT	@ip_catbases = (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN ''
							ELSE ip_servidor 
						END),
		@idEmpresa	= emp_idempresa,
		@nombreBase		= (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN '[' + nombre_base + '].[DBO].' 
							ELSE '['+ ip_servidor + '].[' + nombre_base + '].[DBO].' 
						END)
FROM	[CentralizacionV2].[dbo].[DIG_CAT_BASES_BPRO]
WHERE	emp_idempresa	= @idEmpresa 
		AND tipo		= 2

--Selecciono el año de la inforamción consultada para parametrizar la consulta dinámica y el nombre de las bases de datos correspondientes
SET @añoConsulta = YEAR(CONVERT(DATE,(CONVERT(DATE,@fecha)),103))
SET @mesConsulta = MONTH(CONVERT(DATE,(CONVERT(DATE,@fecha)),103))
	-- interfering with SELECT statements.
			  --      print @ip_catbases
					--print @nombreBase
					--print @idEmpresa

	SET NOCOUNT ON;

	--COBROS REFERENCIADOS DIRECTOS (Abonos)
    --  Números identificadores para el tipo de referencia de cada registro Bancario "ABONOS"
	--1 Corresponde al detalle depositos Bancarios (Abonos) referenciados (Directos)
	--2 Corresponde al detalle depositos BANCARIOS (Abonos) referenciados (Control de depositos)
	--3 Corresponde al detalle depositos Bancarios (Cargos) referenciados 

IF @tipoDato = 3 --opción para ver el detalle de Registros Bancarios "Cargos" mediante la consulta de referenciaApliada
		BEGIN
						INSERT INTO @VariableTabla (item) 
						SELECT item FROM  dbo.SplitString(RTRIM(LTRIM(@referenciaAmpliada)),'-')
						
						SELECT  @CountIdLote = LEN(item)
								FROM @VariableTabla WHERE ID = 1
							IF(@CountIdLote > 7)
							BEGIN
								SELECT  @idLote = SUBSTRING(item, 8, LEN(item)-7)
										FROM @VariableTabla WHERE ID = 1
							END
						ELSE
							BEGIN
						SELECT  @idLote = item
								FROM @VariableTabla WHERE ID = 1
						END

						SELECT  @idPersona = item
								FROM @VariableTabla WHERE ID = 2

						SELECT  @consecutivo = LEFT(item,3)
								FROM @VariableTabla WHERE ID = 3
					

                  SET @query =    
								   'SELECT' + char(13) +
								   +'DISTINCT(MOV_CONSMOV),' + char(13) +
								   +'RTRIM(LTRIM([MOV_TIPOPOL])) AS tipoPoliza,' + char(13) +
								   +'RTRIM(LTRIM([MOV_NUMCTA])) AS numeroCuenta,' + char(13) +
								   +'RTRIM(LTRIM([MOV_CONCEPTO])) AS concepto,' + char(13) +
								   +'[MOV_HABER] AS abono,' + char(13) +
								   +'[MOV_CONSMOV] AS consecutivoNumero,' + char(13) +
								   +'RTRIM(LTRIM([per_paterno])) +'' ''+ RTRIM(LTRIM([per_materno])) +'' ''+ RTRIM(LTRIM([per_nomrazon])) as nombreUsuario,' + char(13) +
								   +'RTRIM(LTRIM([MOV_CARTERA])) AS cartera,' + char(13) +
								   +'RTRIM(LTRIM([MOV_FECHOPE])) AS fechaOperacion' + char(13) +
								   +'FROM '+ @nombreBase +'CON_MOVDET01'+CONVERT(VARCHAR(4),@añoConsulta)+' movdet' + char(13) +
							+'INNER JOIN '+ @nombreBase +'CON_CAR01'+CONVERT(VARCHAR(4),@añoConsulta)+' conCar' + char(13) +
							+'ON movdet.MOV_CONSPOL = conCar.CCP_CONSPOL' + char(13) +
							+'AND movdet.MOV_MES = conCar.CCP_MES' + char(13) +
							+'INNER JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] docpag' + char(13) +
							+'ON  conCar.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS = docpag.dpa_iddocumento' + char(13) +
							+'AND conCar.CCP_IDPERSONA = docpag.dpa_idpersona' + char(13) +
							+'INNER JOIN [BDPersonas].[dbo].[cat_personas] personas' + char(13) +
							+'ON conCar.CCP_IDPERSONA = personas.per_idpersona' + char(13) +
							+'WHERE CONVERT(nvarchar,docpag.dpa_lote) ='+ CONVERT(VARCHAR(10),@idLote) +'' + char(13) +
							+'AND docpag.dpa_idpersona =  '+ CONVERT(VARCHAR(10),@idPersona) +'' + char(13) +
							+'AND conCar.CCP_TIPOPOL = '''+ @polizaPago +''' ' + char(13) +
							+'AND conCar.CCP_TIPODOCTO = ''PAGO'' ' + char(13) +
							+'AND movdet.MOV_TIPOPOL = '''+ @polizaPago +''' ' + char(13) +
							+'AND conCar.CCP_IDPERSONA = '+ CONVERT(VARCHAR(10),@idPersona) +'' + char(13) +
							+'AND movdet.MOV_NUMCTA = '''+ @cuentaContable +'''' + char(13) +
							+'AND movdet.MOV_DEBE = 0'

							PRINT(@query)
							EXECUTE(@query)
							

END
	ELSE 
	IF @tipoDato = 1 --1 Corresponde al detalle depositos Bancarios (Abonos) referenciados (Directos)
	BEGIN
	--Obtengo el tipo de Poliza de acuerdo a la empresa y sucursal
SET @tipoPoliza = (SELECT  
						   [Tipo_Poliza]
						   FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
						   WHERE emp_idempresa = @idEmpresa
						   AND suc_idsucursal = (SELECT rap_idsucursal 
														FROM [GA_Corporativa].[dbo].[cxc_refantypag] 
														WHERE rap_idempresa = @idEmpresa AND rap_referenciabancaria IN(
														SELECT referencia FROM REFERENCIAS.DBO.Referencia WHERE referencia IN(
														SELECT SUBSTRING(concepto,3,20) FROM REFERENCIAS.DBO.Bancomer WHERE
														idBmer = @idRegistroBanco))))

---Ejecuto la consulta para traer el registro vinculado con el idBanco 
DECLARE  @query2 NVARCHAR(MAX) =     'SELECT' + char(13)+
									 +'DISTINCT(MOV_CONSMOV),' + char(13) +
								     +'RTRIM(LTRIM([MOV_TIPOPOL])) AS tipoPoliza,' + char(13) +
								     +'RTRIM(LTRIM([MOV_NUMCTA])) AS numeroCuenta,' + char(13) +
								     +'RTRIM(LTRIM([MOV_CONCEPTO])) AS concepto,' + char(13) +
								     +'[MOV_DEBE] AS cargo,' + char(13) +
								     +'[MOV_CONSMOV] AS consecutivoNumero,' + char(13) +
								     +'RTRIM(LTRIM([per_paterno])) +'' ''+ RTRIM(LTRIM([per_materno])) +'' ''+ RTRIM(LTRIM([per_nomrazon])) as nombreUsuario,' + char(13) +
								     +'RTRIM(LTRIM([MOV_CARTERA])) AS cartera,' + char(13) +
								     +'RTRIM(LTRIM([MOV_FECHOPE])) AS fechaOperacion' + char(13) +
									+'FROM '+ @nombreBase +'CON_MOVDET01'+ CONVERT(VARCHAR(4),@añoConsulta) +' movDet' + char(13)+ 
									+'INNER JOIN'+ @nombreBase +'VIS_CONCAR01 conCar' + char(13)+ 
									+'ON movDet.MOV_TIPOPOL = conCar.CCP_TIPOPOL' + char(13)+ 
									+'AND movDet.MOV_CONSPOL = conCar.CCP_CONSPOL' + char(13)+ 
									+'INNER JOIN [GA_Corporativa].[dbo].[cxc_refantypag] refPag' + char(13)+ 
									+'ON conCar.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS = refPag.rap_iddocto' + char(13)+ 
									+'AND conCar.CCP_IDPERSONA = refPag.rap_idpersona ' + char(13)+
									+'INNER JOIN [BDPersonas].[dbo].[cat_personas] personas' + char(13) +
									+'ON conCar.CCP_IDPERSONA = personas.per_idpersona' + char(13) + 
									+'WHERE ' + char(13)+ 
									+'movDet.MOV_TIPOPOL = '''+ @tipoPoliza +'''' + char(13)+  
									+'AND movDet.MOV_MES = '+ CONVERT(VARCHAR(10), @mesConsulta) +'' + char(13)+ 
									+'AND movDet.MOV_NUMCTA= '''+ @cuentaContable +'''' + char(13)+ 
									+'AND conCar.CCP_TIPODOCTO =''ANT''' + char(13)+  
									+'AND refPag.rap_iddocto IN (' + char(13)+ 
									+'SELECT rap_iddocto ' + char(13)+ 
									+'FROM [GA_Corporativa].[dbo].[cxc_refantypag]' + char(13)+  
									+'WHERE rap_idempresa = '+ CONVERT(VARCHAR(10), @idEmpresa) +'' + char(13)+ 
									+'AND rap_referenciabancaria IN(' + char(13)+ 
								+'SELECT ' + char(13)+ 
								+'referencia ' + char(13)+ 
								+'FROM REFERENCIAS.DBO.Referencia ' + char(13)+ 
								+'WHERE referencia IN(' + char(13)+ 
								+'SELECT SUBSTRING(concepto,3,20) ' + char(13)+ 
								+'FROM REFERENCIAS.DBO.Bancomer ' + char(13)+ 
								+'WHERE fechaOperacion >= '''+ @fecha +'''' + char(13)+  
								+'AND noCuenta = '''+ @noCuenta +'''' + char(13)+  
								+'AND esCargo = 0 ' + char(13)+ 
								+'AND idBmer = '+ CONVERT(VARCHAR(10), @idRegistroBanco) +'' + char(13)+  
								+'AND (concepto LIKE ''CE%'' OR concepto LIKE ''CB%'')' + char(13)+  
								+'AND estatusRevision = 2)))'
						PRINT @query2
						EXECUTE(@query2)

	END
	ELSE IF(@tipoDato = 2) --2 Corresponde al detalle depositos BANCARIOS (Abonos) referenciados (Control de depositos)
	BEGIN


SET @tipoPoliza = (SELECT TOP(1) 
					     CCP_TIPOPOL FROM GAAU_CONCENTRA.DBO.VIS_CONCAR01 concar 
                   INNER JOIN DetalleReferencia detalle
				   ON concar.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS = detalle.documento
				   INNER JOIN Referencia ref
				   ON detalle.idReferencia = ref.idReferencia
                   WHERE CCP_TIPODOCTO = 'PCA'
				   AND ref.depositoID = @idRegistroBanco)

DECLARE  @query3 NVARCHAR(MAX) =					       'SELECT' + char(13)+
														   +'DISTINCT(MOV_CONSMOV),' + char(13) +
														   +'RTRIM(LTRIM([MOV_TIPOPOL])) AS tipoPoliza,' + char(13) +
														   +'RTRIM(LTRIM([MOV_NUMCTA])) AS numeroCuenta,' + char(13) +
														   +'RTRIM(LTRIM([MOV_CONCEPTO])) AS concepto,' + char(13) +
														   +'[MOV_DEBE] AS cargo,' + char(13) +
														   +'[MOV_CONSMOV] AS consecutivoNumero,' + char(13) +
														   +'RTRIM(LTRIM([per_paterno])) +'' ''+ RTRIM(LTRIM([per_materno])) +'' ''+ RTRIM(LTRIM([per_nomrazon])) as nombreUsuario,' + char(13) +
														   +'RTRIM(LTRIM([MOV_CARTERA])) AS cartera,' + char(13) +
														   +'RTRIM(LTRIM([MOV_FECHOPE])) AS fechaOperacion' + char(13) +
														   +'FROM'+ @nombreBase +'CON_MOVDET01'+ CONVERT(VARCHAR(4),@añoConsulta) +' movDet' + char(13)+
														   +'INNER JOIN'+ @nombreBase +'VIS_CONCAR01 conCar' + char(13)+
														   +'ON movDet.MOV_CONSPOL = conCar.CCP_CONSPOL' + char(13)+
														   +'AND movDet.MOV_MES = conCar.CCP_MES' + char(13)+
														   +'INNER JOIN DetalleReferencia detRef' + char(13)+
														   +'ON conCar.CCP_IDPERSONA = detRef.idCliente' + char(13)+
														   +'AND conCar.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS = detRef.documento' + char(13)+
														   +'INNER JOIN  Referencia ref' + char(13)+
														   +'ON detRef.idReferencia = ref.idReferencia' + char(13)+
														   +'INNER JOIN [GA_Corporativa].[dbo].[cxc_refantypag] refPag' + char(13)+
														   +'ON ref.referencia = refPag.rap_referenciabancaria' + char(13)+
														   +'INNER JOIN REFERENCIAS.DBO.Bancomer banco' + char(13)+
														   +'ON banco.idBmer = ref.depositoID' + char(13)+
														   +'INNER JOIN [BDPersonas].[dbo].[cat_personas] personas' + char(13)+
														   +'ON conCar.CCP_IDPERSONA = personas.per_idpersona' + char(13)+
														   +'WHERE movDet.MOV_TIPOPOL = '''+ @tipoPoliza +'''' + char(13)+ 
														   +'AND movDet.MOV_MES = '+ CONVERT(VARCHAR(10), @mesConsulta) +'' + char(13)+
														   +'AND movDet.MOV_NUMCTA = '''+ @cuentaContable +'''' + char(13)+
														   +'AND ref.depositoID = '+ CONVERT(VARCHAR(10), @idRegistroBanco) +'' + char(13)+ --idBmer
														   +'AND refPag.rap_idempresa = '+ CONVERT(VARCHAR(10), @idEmpresa) +''
														   PRINT @query3
												           EXECUTE(@query3)
	END
	ELSE IF (@tipoDato = 4)
	BEGIN
	     SELECT 'FUNCION NO DISPONIBLE' AS ERROR
	END
END TRY
BEGIN CATCH
			SELECT ERROR_MESSAGE() AS ERROR 
END CATCH
go

