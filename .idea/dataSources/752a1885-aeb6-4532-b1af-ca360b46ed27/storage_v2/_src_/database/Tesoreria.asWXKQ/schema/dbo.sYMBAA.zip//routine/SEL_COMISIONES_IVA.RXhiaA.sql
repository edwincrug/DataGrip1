-- [SEL_COMISIONES_IVA] 23958, 2
CREATE PROCEDURE  [dbo].[SEL_COMISIONES_IVA]
	@idDepositoBanco int = 0,
	@idBanco int
AS
BEGIN
	IF( @idBanco = 1 ) -- Bancomer
		BEGIN
			SELECT idbmer idDepositoBanco
				  ,[idBanco]
				  ,[idBmer]
				  ,'Bancomer' banco
				  ,[txtOrigen]
				  ,[noCuenta]
				  ,[concepto]
				  ,[importe] as abono
				  ,0 as cargo
				  ,[saldoOperativo]
				  ,[referencia]
				  ,[fechaOperacion]
				  ,[horaOperacion]
				  ,[oficinaOperadora]
			FROM referencias.DBO.BANCOMER 
			WHERE codigoLeyenda IN ( SELECT        CodigoBanco FROM referencias.DBO. CodigoIdentificacion WHERE IDBanco = 1 AND Tipo = 1 AND Descripcion LIKE 'IVA%' )
				  AND idbmer  BETWEEN @idDepositoBanco - 1 AND @idDepositoBanco + 1;
		END
	ELSE IF( @idBanco = 2 ) -- Banamex
		BEGIN
			
			SELECT idbmer as idDepositoBanco,
				   idbanco as idBanco,
				   idbmer as idBmer,
				   'Banamex' banco,
				   '' as txtOrigen,
				   noCuenta,
				   BMEX.concepto as concepto,
				   BMEX.importe as abono,
				   0 as cargo,
				   0 as saldoOperativo,
				   referencia AS referencia,
				   BMEX.fechaOperacion as fechaOperacion,
				   CONVERT(time, getdate(), 108) as horaOperacion,
				   0 as oficinaOperadora
			FROM (select * from ABONOSBANCOS_CB where idbanco=2 union all select * from CARGOSBANCOS_CB where IDBanco=2) BMEX
		WHERE  BMEX.concepto like '%imp%' 
				 AND idBmer between @idDepositoBanco - 1 AND @idDepositoBanco + 1;
		END
	ELSE IF( @idBanco = 3 ) -- Santander
		BEGIN
			SELECT idSantander as idDepositoBanco,
				   idbanco as idBanco,
				   idSantander as idBmer,
				   'Santander' banco,
				   txtOrigen,
				   noCuenta,
				   concepto,
				   importe as abono,
				   0 as cargo,
				   saldo as saldoOperativo,
				   referencia,
				   fechaMovimiento as fechaOperacion,
				   horaMovimiento as horaOperacion,
				   sucursal as oficinaOperadora
			FROM referencias.dbo.Santander 
			WHERE clacon IN ( SELECT CodigoBanco FROM referencias.DBO. CodigoIdentificacion WHERE IDBanco = 3 AND Tipo = 1 AND Descripcion LIKE '%IVA%' )
				  AND idSantander = @idDepositoBanco + 1;
		END
	ELSE -- Por Layout
		BEGIN
			SELECT
				[idDepositoBanco] = [idMovimiento],
				[idBanco] = MOV.[idBanco],
				[idBmer] = [idMovimiento],
				BAN.nombre banco,
				[txtOrigen] = '',
				[noCuenta] = [noCuenta],
				[concepto] = [descripcion],
				[abono],
				[cargo],
				[saldoOperativo] = 0,
				[referencia] = [referencia],
				[fechaMovimiento] = [fechaRegistro],
				[horaMovimiento] = GETDATE(),
				[oficinaOperadora] = 0	,
				[tipoMovimiento]			
			FROM referencias.dbo.MovimientoBancarioLayout MOV
			INNER JOIN referencias.dbo.Banco BAN ON MOV.idBanco = BAN.idBanco
			WHERE [tipoMovimiento] IN ( SELECT CodigoBanco FROM referencias.DBO. CodigoIdentificacion WHERE IDBanco = MOV.[idBanco] AND Tipo = 1 AND Descripcion LIKE '%IVA%' )
				  AND idMovimiento BETWEEN ( @idDepositoBanco - 1 ) AND ( @idDepositoBanco + 1 );
		END
END


go

