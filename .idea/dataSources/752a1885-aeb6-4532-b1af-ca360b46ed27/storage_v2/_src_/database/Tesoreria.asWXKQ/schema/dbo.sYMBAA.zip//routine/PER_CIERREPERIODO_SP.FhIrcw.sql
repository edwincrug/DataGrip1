-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-07-05
-- Description:	Cierre del mes contable 
-- =============================================
CREATE PROCEDURE [dbo].[PER_CIERREPERIODO_SP]

	@idEmpresa INT			 = 0,
	@idBanco INT			 = 0,
	@cuentaBanco VARCHAR(30) = '',
	@fechaInicio VARCHAR(30) = ''
AS
BEGIN
	DECLARE @mes INT	= MONTH(CONVERT( DATE, @fechaInicio, 103 ));
	DECLARE @anio INT	= YEAR(CONVERT( DATE, @fechaInicio, 103 ));
	DECLARE @fechaIni DATE;
	DECLARE @fechaFin DATE = GETDATE();


	SELECT @fechaIni = CONVERT(DATE,DATEADD(MONTH, ((YEAR(CONVERT(DATE, CONVERT(VARCHAR(4), @anio) + '-' + CONVERT(VARCHAR(2), @mes) + '-01')) - 1900) * 12) + MONTH(CONVERT(DATE, CONVERT(VARCHAR(4), @anio) + '-' + CONVERT(VARCHAR(2), @mes) + '-01')), -1));
	--SELECT idEmpresa FROM [dbo].[PeriodoActivo] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @cuentaBanco AND mec_numMes = @mes AND mec_anio = @anio AND mec_conciliado = 0
	--select @fechaIni,@fechaFin,@mes,@anio
	IF EXISTS( SELECT idEmpresa FROM [dbo].[PeriodoActivo] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @cuentaBanco AND mec_numMes = @mes AND mec_anio = @anio AND mec_conciliado = 0)
		BEGIN
			IF( @FechaFin >= @FechaIni )
				BEGIN
					UPDATE 
						PA
					SET 
						mec_conciliado = 1
					--select *
					FROM [dbo].[PeriodoActivo] PA
					WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @cuentaBanco AND mec_conciliado = 0;

					INSERT INTO [dbo].[PeriodoActivo]
					SELECT
						[mec_numMes]		= MONTH(DATEADD(MONTH, 1, CONVERT( DATE, @fechaInicio, 103 ))),
						--[mec_anio]			= 2019,
                        [mec_anio]			= YEAR(GETDATE()),
						[mec_conciliado]	= 0,
						[idEmpresa]			= @idEmpresa,
						[idBanco]			= @idBanco,
						[cuentaBancaria]	= @cuentaBanco;

					SELECT
						success = 1,
						msg		= 'Mes cerrado con éxito',
						periodo = MONTH(DATEADD(MONTH, 1, CONVERT( DATE, @fechaInicio, 103 ))),
						--anio	= 2019
                        anio	= @anio		
				END
			ELSE
				BEGIN
					SELECT success = 0, msg		= 'No es posible cerrar el mes que solicita. '
				END
		END
	ELSE
		BEGIN
			SELECT success = 0, msg		= 'No es posible cerrar el mes que solicita. '
		END
END

go

