-- [DEL_COMISIONAPLICADA_SP] 1, 13
CREATE PROCEDURE [dbo].[DEL_COMISIONAPLICADA_SP]
	@idEmpresa AS INT,
	@Agrupador AS INT
AS
BEGIN
	-- DECLARE @idEmpresa INT = 1
	-- DECLARE @Agrupador INT = 10;
	DECLARE @LastId INT;
	
	DECLARE @idComisionesIntereses NUMERIC(18,0) = (SELECT TOP 1 coi_idcomisionesinteresesBPRO FROM InteresComision COM
	INNER JOIN cxp_comisionesintereses CXP ON COM.interesComisionID = CXP.interesComisionID
	WHERE agrupador = @Agrupador AND idEmpresa = @idEmpresa);

	INSERT INTO cuentasxpagar .dbo.[cxp_comisionesintereses]
	SELECT coi_idempresa
		   , coi_idsucursal
		   , 'C' + coi_tipopoliza as coi_tipopoliza
		   , coi_fechapoliza         
		   , coi_descripcion                                                                                                                                                                                          
		   , coi_fechageneracion     
		   , coi_estatus 
		   , coi_cuentabeneficiario                                                                                                                                                                                   
		   , coi_cuentapagadora                                                                                                                                                                                       
		   , coi_cobrador 
		   , coi_moneda 
		   , coi_tipocambio                          
		   , coi_formapago 
		   , 'C' + coi_tipo as coi_tipo
	FROM cuentasxpagar.dbo.cxp_comisionesintereses 
	WHERE coi_idcomisionesintereses = @idComisionesIntereses;
	
	SET @LastId = @@IDENTITY;

	INSERT INTO cuentasxpagar.[dbo].[cxp_comisionesinteresesdet] 
	SELECT cid_cuentacontable                                 
		   , cid_concepto                                                                                                                                                                                             
		   , cid_abono as cid_cargo
		   , cid_cargo as cid_abono	   
		   , cid_documento                                      
		   , cid_idpersona                           
		   , @LastId AS coi_idcomisionesintereses               
		   , cid_tipodocumento    
		   , cid_fechavencimiento    
		   , cid_poriva                              
		   , cid_referencia                                                                                       
		   , cid_banco  
		   , cid_referenciabancaria                                                                               
		   , cid_conpoliza
	FROM cuentasxpagar.dbo.cxp_comisionesinteresesdet
	WHERE coi_idcomisionesintereses = @idComisionesIntereses;
	
	-- Eliminamos registros
	
	DELETE FROM [cxp_comisionesinteresesdet] WHERE cid_idcomisionesinteresesdet IN ( SELECT cid_idcomisionesinteresesdet 
	FROM [cxp_comisionesinteresesdet] DET
	INNER JOIN [cxp_comisionesintereses] ENC ON DET.coi_idcomisionesintereses = ENC.coi_idcomisionesintereses
	INNER JOIN [InteresComision] COM ON ENC.interesComisionID = COM.interesComisionID
	WHERE agrupador = @agrupador AND COM.idEmpresa = @idEmpresa );

	DELETE FROM [cxp_comisionesintereses] WHERE coi_idcomisionesintereses IN ( SELECT coi_idcomisionesintereses FROM [cxp_comisionesintereses] ENC
	INNER JOIN [InteresComision] COM ON ENC.interesComisionID = COM.interesComisionID
	WHERE agrupador = @agrupador AND COM.idEmpresa = @idEmpresa );

	DELETE FROM [InteresComision] WHERE agrupador = @agrupador AND idEmpresa = @idEmpresa;
	
	SELECT '0' result
END
go

