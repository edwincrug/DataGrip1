CREATE procedure [dbo].[UPD_DEPOSITO_REFERENCIA]
@idDepositoBanco as int,
@idReferencia as int
as
begin
	update depositobanco 
	set idReferencia= @idReferencia, idEstatus = 6
	where idDepositoBanco =@idDepositoBanco 
end
go

