
-- =============================================
-- Author:
-- Create date:
-- Description:
-- =============================================
--[dbo].[TransferenciasBancarias_SP] 4,6,'1100-0020-0001-0001','1100-0020-0001-0010',14500,1,1,0,1,5,'00408062020001001501'
CREATE PROCEDURE [dbo].[TransferenciasBancariasCCS_SP] @idempresa INT = 0
, @idSucursal INT = 0
, @cuentaOrigen VARCHAR(150) = 0
, @cuentaDestino VARCHAR(150) = 0
, @monto DECIMAL(18, 2) = 0
, @idUsuario INT = 0
, @solicitaAuto INT = 0
, @fueraHorario INT = 0
, @automatico BIT = 0
, @idOrigenSistema int=0
, @referencia VARCHAR(50) = ''

AS
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON;
  DECLARE @folio INT = 0
        
  --DECLARE @respuestaReferencia TABLE (
  --  estatus INT
  -- ,mensaje VARCHAR(150)
  -- ,referencia VARCHAR(30)
  --)
  BEGIN TRY
    /*
  	Cuando se rompe la regla de saldo minimo en la cuenta se requiere autorizacion, este funciona actualmente 
  	en las solicitudes de trasnferencias del portal movimientos bancarios
  	*/
    IF (@solicitaAuto = 1)
    BEGIN
      /*
    	@automatico en este momento significa que la solicitud fue generada desde el portal de movimientos bancarios
    	por carmen sepulveda o alguien de su equipo
    	*/
      IF (@automatico = 0)
      BEGIN
        /*
  			Insertamos en la tabla que nos proporciono BPRO
  			*/
        INSERT INTO GA_Corporativa.dbo.tsb_traspasosaldobancos (tsb_idempresa
        , tsb_idsucursal
        , tsb_cuentaorigen
        , tsb_cuentadestino
        , tsb_importe
        , tsb_moneda
        , tsb_concepto
        , tsb_estatus
        , tsb_fechasolicita
        , tsb_usuariosolicita)
          VALUES (@idempresa, @idSucursal, @cuentaOrigen, @cuentaDestino, @monto, 'PE', 'DTRASSALDOINGTS', -1 -- SE COLOCA -1 PARA QUE NO LO PROCESE EL SERVICIO DE BPRO HASTA QUE SE HAYA REALIZADO EL TRAMITE EN EL PORTAL DE TRAMITES
          , CASE WHEN @fueraHorario = 0 THEN GETDATE() ELSE CONVERT(VARCHAR, GETDATE() + 1, 111) END, @idUsuario)
        SET @folio = @@IDENTITY

        /*
  			Insertamos en esta tabla el folio generado en el paso anterior, esta tabla se actualiza con el folio del tramite generado porteriormente 
  			para saber la relacion
  			*/
        INSERT INTO transferenciasLog (idtransferencia)
          VALUES (@folio)
        SELECT
          'Ok' AS estatus
         ,'La transferencia se realizó con exito' AS mensaje
         ,@folio AS folio
         ,@folio AS Folio
      END
      ELSE
      BEGIN

        /*
  			Entramos en esta parte del codigo cuando la solicitd es automatica es decir los CC
  			*/

        /*
  			Obtenemos y/o generamos la referencia
  			*/
        --INSERT INTO @respuestaReferencia
        --EXEC INS_REFERENCIAS_TRAMITES_SP @idempresa
        --                                ,@idSucursal
        --                                ,@idDepartamento
        --                                ,@idOrigenSistema
        --                                ,@idBancoOrigen
        --                                ,@idBancoDestino
        --                                ,@documento
        --                                ,@monto
        --                                ,@idUsuario

        /*
  			leemos la referencia
  			*/
        --SELECT
        --  @referencia = referencia
        --FROM @respuestaReferencia

        /*
  			insertamos la informacion en la tabla de bpro, es necesario para mostrar la informacion en el portal de victor tesoreria
  			*/
        INSERT INTO GA_Corporativa.dbo.tsb_traspasosaldobancos (tsb_idempresa
        , tsb_idsucursal
        , tsb_cuentaorigen
        , tsb_cuentadestino
        , tsb_importe
        , tsb_moneda
        , tsb_concepto
        , tsb_estatus
        , tsb_fechasolicita
        , tsb_usuariosolicita)
          VALUES (@idempresa, @idSucursal, @cuentaOrigen, @cuentaDestino, @monto, 'PE', 'DTRASSALDOINGTS', -3 -- SE COLOCA -3 PARA IDENTIFICAR QUE ESTA SOLICITUD ES AUTOMATICA
          , CASE WHEN @fueraHorario = 0 THEN GETDATE() ELSE CONVERT(VARCHAR, GETDATE() + 1, 111) END, @idUsuario)
        SET @folio = @@IDENTITY

        /*
  			Insertamos en esta tabla el folio generado en el paso anterior, esta tabla se actualiza con el folio del tramite generado porteriormente 
  			para saber la relacion
  			*/
        INSERT INTO transferenciasLog (idtransferencia, referencia, automatico, idOrigenReferencia,esCC)
          VALUES (@folio, @referencia, 1, @idOrigenSistema,1)

        SELECT
          'Ok' AS estatus
         ,'La transferencia se realizó con exito' AS mensaje
         ,@folio AS folio
         

      END

    END
    ELSE
    BEGIN
      INSERT INTO TransferenciasBancarias (idEmpresa, idSucursal, cuentaOrigen, cuentaDestino, importe, moneda, concepto, usuario, fechaTransferencia)
        VALUES (@idempresa, @idSucursal, @cuentaOrigen, @cuentaDestino, @monto, 'PE', 'Transferencia', @idUsuario, GETDATE());
      SET @folio = @@IDENTITY
      SELECT
        @folio AS folio
       ,'Ok' AS estatus
       ,'Se genero la transferencia temporal' AS mensaje
       ,@folio AS Folio
    --from TransferenciasBancarias
    END
  END TRY
  BEGIN CATCH
    SELECT
      'error' AS Estatus
     ,'Ocurrio un error durante la transferencia' AS mensaje
     ,ERROR_NUMBER() AS ErrorNumber
     ,ERROR_STATE() AS ErrorState
     ,ERROR_SEVERITY() AS ErrorSeverity
     ,ERROR_PROCEDURE() AS ErrorProcedure
     ,ERROR_LINE() AS ErrorLine
     ,ERROR_MESSAGE() AS ErrorMessage;
  END CATCH
END
go

