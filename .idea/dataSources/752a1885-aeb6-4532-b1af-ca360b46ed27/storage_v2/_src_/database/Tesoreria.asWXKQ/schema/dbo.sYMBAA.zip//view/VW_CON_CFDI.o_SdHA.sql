--select emp_idempresa,nombre_base from [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] where tipo = 2

create VIEW [dbo].[VW_CON_CFDI] AS
select 1 idempresa,* from GAAU_Concentra.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 1 idempresa,* from GAAU_Concentra.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 2 idempresa,* from GAAT_Concentra.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 2 idempresa,* from GAAT_Concentra.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 3 idempresa,* from GAHondaConcen.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 3 idempresa,* from GAHondaConcen.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 4 idempresa,* from GAZM_Concentra.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 4 idempresa,* from GAZM_Concentra.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 5 idempresa,* from GAAA_Concentra.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 5 idempresa,* from GAAA_Concentra.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 6 idempresa,* from GAAS_Concentra.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 6 idempresa,* from GAAS_Concentra.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 7 idempresa,* from GAAutoExpressConcentra.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 7 idempresa,* from GAAutoExpressConcentra.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 8 idempresa,* from GAConsArriagaTap.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 8 idempresa,* from GAConsArriagaTap.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 9 idempresa,* from GAAutoAngarConcen.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 9 idempresa,* from GAAutoAngarConcen.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
union all
select 10 idempresa,* from GAHyundaiConcentra.[dbo].[CON_CFDI012018] where CFI_tipopol='dpi'
union all
select 10 idempresa,* from GAHyundaiConcentra.[dbo].[CON_CFDI012019] where CFI_tipopol='dpi'
go

