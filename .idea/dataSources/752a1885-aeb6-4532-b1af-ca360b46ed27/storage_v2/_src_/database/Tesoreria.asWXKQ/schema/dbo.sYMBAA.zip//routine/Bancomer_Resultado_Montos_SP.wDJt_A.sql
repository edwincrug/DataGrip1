
-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date, 2017-11-10>
-- Description:	EXECUTE dbo.[Bancomer_Resultado_Montos_SP] '2017-01-01','2017-01-15','1100-0020-0001-0001','000000000195334667','TREEUN',1,1,1
-- =============================================
CREATE PROCEDURE [dbo].[Bancomer_Resultado_Montos_SP] 
	-- Add the parameters for the stored procedure here
	-- Add the parameters for the function here
		@fechaElaboracion varchar(30),
		@fechaCorte varchar(30),
		@cuentaContable varchar(50), 
		@noCuenta varchar(50),
		@polizaPago varchar(20),
		@idEmpresa int = 0,
		@idBanco int = 0,
		@tipoconsulta int = 0
AS
BEGIN TRY

DECLARE       @totalAbonoContable decimal(18,2),
			  @totalAbonoContableQuery NVARCHAR(MAX),
			  @totalCargoContableQuery NVARCHAR(MAX),
			  @totalAbonoBancario decimal(18,2),
			  @totalCargoBancario decimal(18,2),
			  @totalCargoContable decimal(18,2),
			  @ParmDefinition nvarchar(500),
              @result_CargoContable varchar(30),
			  @result_AbonoContable varchar(30)

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
--------------------------------------------------------------Obtiene datos de las bases correspondientes según el numero de empresa----------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @ipLocal NVARCHAR(50) = ''
	   ,@ip_catbases NVARCHAR(50) = ''			
	   ,@Base NVARCHAR(50) = ''

SELECT	@ipLocal = dec.local_net_address
FROM	sys.dm_exec_connections AS dec
WHERE	dec.session_id = @@SPID;
------------------------------------------------------------------------------------------------
--Obtiene los datos de la CONCENTRADORA
------------------------------------------------------------------------------------------------
SELECT	@ip_catbases = (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN ''
							ELSE ip_servidor 
						END),
		@idEmpresa	= emp_idempresa,
		@Base		= (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN '[' + nombre_base + '].[DBO].' 
							ELSE '['+ ip_servidor + '].[' + nombre_base + '].[DBO].' 
						END)
FROM	[CentralizacionV2].[dbo].[DIG_CAT_BASES_BPRO]
WHERE	emp_idempresa	= @idEmpresa 
		AND tipo		= 2

------------------------------------------------------------------------Inserta los datos de las referencias bancarias--------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @MesMov INT = MONTH(convert(DATE, convert(date,@fechaCorte), 103))
DECLARE @añoConsulta INT = YEAR(CONVERT(DATE,(CONVERT(DATE,@fechaCorte)),103))


-----------------------------------------------------------------------Cálculo Abonos en Contabilidad Bancomer------------------------------------------------------------------------
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SET @totalAbonoContableQuery =         'SELECT @totalAbonoContable =  ISNULL(SUM(abono),0) '
									 + 'FROM AuxiliarContable' + char(13) +  
									 + 'WHERE numeroCuenta = '''+ @cuentaContable +'''' + char(13) + 
									 + 'AND movMes = MONTH(convert(DATE, convert(date,'''+ @fechaCorte +'''), 103))' + char(13) +  
									 + 'AND cargo = 0' + char(13) + 
									 + 'AND idEmpresa = '+CONVERT(VARCHAR(5), @idEmpresa )+'' + char(13) + 
									 + 'AND movFechaOpe BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''' + char(13) + 
									 + 'AND idAuxiliarContable' + char(13) +   
									 + 'NOT IN(' + char(13) + 
									 + 'SELECT idAuxiliarContable ' + char(13) + 
									 + 'FROM AuxiliarContable aux' + char(13) + 
									 + 'INNER JOIN '+ @Base +'CON_CAR01'+CONVERT(VARCHAR(4),@añoConsulta)+' conCar' + char(13) + 
									 + 'ON conCar.CCP_TIPOPOL COLLATE Modern_Spanish_CS_AS = aux.polTipo' + char(13) + 
									 + 'AND conCar.CCP_CONSPOL = aux.polConsecutivo' + char(13) + 
									 + 'AND conCar.CCP_MES = aux.movMes' + char(13) + 
									 + 'INNER JOIN cuentasxpagar.DBO.cxp_doctospagados docP' + char(13) + 
									 + 'ON conCar.CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS = docP.dpa_iddocumento' + char(13) +
									 + 'AND conCar.CCP_IDPERSONA =  docP.dpa_idpersona ' --LQMA add 27022018 relaciona por cliente  
									 + 'INNER JOIN [Pagos].[dbo].[PAG_REL_DOCTOS_BANCOS] relPag' + char(13) +
                                     + 'ON docP.dpa_iddoctopagado = relPag.dpa_iddoctopagado' + char(13) +
									 + 'WHERE numeroCuenta = '''+ @cuentaContable +''' AND movMes = MONTH(convert(DATE, convert(date,'''+ @fechaCorte +'''), 103))' + char(13) +  
									 + 'AND cargo = 0' + char(13) +   
									 + 'AND movFechaOpe  BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''' + char(13) + 
									 + 'AND conCar.CCP_TIPOPOL = '''+ @polizaPago +'''' + char(13) +  
									 + 'AND conCar.CCP_TIPODOCTO = ''PAGO''' + char(13) + 
									 + 'AND relPag.idBanco = '+CONVERT(VARCHAR(5), @idBanco )+''+ char(13) +
									 --+ 'AND docP.dpa_lote NOT IN (' + char(13) + LQMA 
									 + 'AND docP.dpa_iddoctopagado NOT IN (' + char(13) +
									 
									 + ' SELECT PAG.dpa_iddoctopagado FROM Pagos.dbo.PAG_REL_DOCTOS_BANCOS PAG '
									 + ' JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] docpag ON PAG.dpa_iddoctopagado = docpag.dpa_iddoctopagado '
									 +	'WHERE docpag.dpa_pagoaplicado IN (1) '
									 +	'AND docpag.dpa_idempresa = ' + CONVERT(VARCHAR(5), @idEmpresa ) + ' ' 
									 + ' AND PAG.idBanco = ' + CONVERT(VARCHAR(5), @idBanco) + ' ))'

print(@totalAbonoContableQuery)
SET @ParmDefinition = N'@totalAbonoContable varchar(50) OUTPUT';

EXECUTE sp_executesql @totalAbonoContableQuery, @ParmDefinition, @totalAbonoContable = @result_AbonoContable OUTPUT;

---------------------------------------------------------------------------Cálculos de Abonos Banco Bancomer------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SELECT @totalAbonoBancario = 
       (SELECT ISNULL(SUM(importe),0)
	    FROM [DepositoBancoView] banco
		
		LEFT JOIN [referencias].[dbo].[RAPDeposito] rapDep ON banco.idBanco = rapDep.idDeposito
																AND rapDep.idBanco = @idBanco
																AND rapDep.idEmpresa = @idEmpresa
		LEFT JOIN GA_Corporativa.DBO.cxc_refantypag refPag ON rapDep.rap_folio = refPag.rap_folio --refPag.rap_referenciabancaria = SUBSTRING(banco.concepto,3,20)
								AND refPag.rap_idempresa = @idEmpresa
		WHERE banco.idBanco = @idBanco and [esCargo] = 0 
		   AND banco.noCuenta = @noCuenta 
		   AND banco.fechaOperacion BETWEEN @fechaElaboracion and @fechaCorte 
		   --AND puntAux.idBanco IS NULL
		   --AND depDpi.idAbonoBanco IS NULL
		   --AND rapDep.idDeposito IS NULL
		   --AND ref.depositoID IS NULL
		   AND refPag.rap_referenciabancaria IS NULL
		   AND refPag.rap_idstatus <> 1
		) 



 -----------------------------------------------------------------------Cálculos Cargos Contabilidad Bancomer------------------------------------------------------------------------
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		
SET @totalCargoContableQuery =          'SELECT @totalCargoContable = ISNULL(SUM(cargo),0)'+ char(13) +
									  + 'FROM AuxiliarContable ' + char(13) +
									  + 'WHERE numeroCuenta = '''+ @cuentaContable +'''' + char(13) + 
									  + 'AND movMes = '+CONVERT(VARCHAR(5), @MesMov )+'' + char(13) +
									  + 'AND abono = 0' + char(13) +
									  + 'AND idEstatus = 1' + char(13)
									  + 'AND idEmpresa = '+CONVERT(VARCHAR(5), @idEmpresa )+'' + char(13) +
									  + 'AND movFechaOpe BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''' + char(13)
									  + 'AND idAuxiliarContable not in (' + char(13)
									  + '   SELECT   DISTINCT([idAuxiliarContable]) AS idAuxiliar' + char(13)
									  + '			FROM AuxiliarContable aux' + char(13)
									  + '			LEFT JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] catB' + char(13)
									  + '			ON catB.Tipo_Poliza = aux.polTipo' + char(13)
									  + '			LEFT JOIN '+ @Base +'CON_CAR01'+CONVERT(VARCHAR(4),@añoConsulta)+' conCar' + char(13)
									  + '			ON  conCar.CCP_MES = aux.movMes' + char(13)
									  + '			AND conCar.CCP_CONSMOV = aux.movConsMov' + char(13)
									  + '			AND conCar.CCP_CONSPOL = aux.polConsecutivo' + char(13)
									  + '			WHERE aux.numeroCuenta = '''+ @cuentaContable +'''' + char(13)
									  + '			AND aux.movMes = '+CONVERT(VARCHAR(5), @MesMov )+'' + char(13)
									  + '			AND aux.idEmpresa = '+CONVERT(VARCHAR(5), @idEmpresa )+'' + char(13)
									  + '			AND aux.abono = 0' + char(13)
									  + '			AND aux.movFechaOpe  between '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''' + char(13)
									  + '			AND catB.emp_idempresa = '+CONVERT(VARCHAR(5), @idEmpresa )+'' + char(13)
									  + '			AND catB.Tipo_Poliza IS NOT NULL' + char(13)
									  + '			) '
print(@totalCargoContableQuery)
SET @ParmDefinition = N'@totalCargoContable varchar(50) OUTPUT';

EXECUTE sp_executesql @totalCargoContableQuery, @ParmDefinition, @totalCargoContable = @result_CargoContable OUTPUT;

-------------------------------------------------------------------------Cálculos de Cargos Banco Bancomer--------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		SELECT @totalCargoBancario = 
			   (SELECT ISNULL(SUM(importe),0)
			   FROM [dbo].[DepositoBancoView] 
			   WHERE noCuenta = @noCuenta AND esCargo = 1 AND fechaOperacion 
			   BETWEEN @fechaElaboracion AND @fechaCorte
			   AND idBanco = @idBanco
			   AND idBmer NOT IN (
								  SELECT PAG.idBanco_Registro FROM Pagos.dbo.PAG_REL_DOCTOS_BANCOS PAG
									JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] docpag ON PAG.dpa_iddoctopagado = docpag.dpa_iddoctopagado
								  WHERE docpag.dpa_pagoaplicado IN (1)
									AND docpag.dpa_idempresa = @idEmpresa	
									AND PAG.idBanco = @idBanco	
								  )
			   )
-------------------------------------------------------------Se consulta la información en la tabla de retorno--------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---@result_CargoContable

SELECT @result_AbonoContable tAbonoContable, 	   
	   @totalAbonoBancario tAbonoBancario, 
	   @result_CargoContable tCargoContable, 
	   @totalCargoBancario tCargoBancario
 
--print(@totalAbonoContableQuery)
--EXEC(@totalAbonoContableQuery)
									
END TRY
BEGIN CATCH
     SELECT ERROR_MESSAGE() + ' ' + ERROR_LINE() AS ERROR
END CATCH

go

