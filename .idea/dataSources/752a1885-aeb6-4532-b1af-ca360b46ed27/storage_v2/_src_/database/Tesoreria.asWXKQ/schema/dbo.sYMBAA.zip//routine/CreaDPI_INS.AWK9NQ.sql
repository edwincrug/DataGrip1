-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<Inserta el dpi en bpro>
-- =============================================
--[dbo].[CreaDPI_INS] 23782,1,2,'GMI',2
CREATE PROCEDURE [dbo].[CreaDPI_INS]
			@idAbonoBanco INT,
			@idBanco INT,
			@idEmpresa INT,
			@idUsuario nvarchar(4)='GMI',
			@Usuario int
		   

AS
BEGIN
----1.-Declarar las variables--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('tempdb..##TempDPI') IS NOT NULL
    DROP TABLE ##TempDPI

	SET NOCOUNT ON;
	Declare @serverDB varchar(200) ,@ipDB varchar(200) 
	,@MOV_CONSPOL INT 
	,@MOV_CONSMOV INT
	,@MOV_MES INT
	,@anio int
	,@MOV_DEBE decimal(18,5) =0
	,@MOV_HABER decimal(18,5) =0
	,@NUMCTA varchar(50)
	,@MOV_IDCLIENTE int=0
	,@mov_fecha datetime
	,@queryText1 AS VARCHAR(max) =''
	,@queryText2 AS VARCHAR(max) =''
	,@queryText3 AS VARCHAR(max) =''
	,@queryText4 AS VARCHAR(max) =''
	,@queryText5 AS VARCHAR(max) =''
	,@queryText6 AS VARCHAR(max) =''
	,@queryText7 AS VARCHAR(max) =''
	,@fechaoper datetime
	,@cuentacargo int =1
--	declare @mydate date= getdate()
--	SELECT CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@mydate))),DATEADD(mm,1,@mydate)),103) ,
--'Último día del mes corriente'
     select @cuentacargo = case when @idEmpresa = 2 then 2 else 1 end
	select @MOV_DEBE=0,
	 @MOV_HABER=isnull(importe,0),
	 @NUMCTA=noCuenta,
	 @MOV_MES=p.mec_numMes,
	 @anio=p.mec_anio,
	 @mov_fecha=case when month(getdate())=p.mec_numMes then getdate() else DATEADD(month, ((p.mec_anio - 1900) * 12) + p.mec_numMes, -1) end,
	 @fechaoper=fechaoperacion

	from ABONOSBANCOS_CB ab
	inner join PeriodoActivo p on ab.idEmpresa=p.idEmpresa and ab.IDBanco=p.idBanco and ab.noCuenta= p.cuentaBancaria and p.mec_conciliado=0
	where IDABONOSBANCOS=	@idAbonoBanco
----2.-Obtener nombre de bd de la empresa--------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--select @mov_fecha
         DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	set @serverDB= ''
	set @ipDB= ''

	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			select top 1	@serverDB=
			'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							--from  [192.168.20.92].[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal is null
		END
	ELSE
		BEGIN
			select top 1	@serverDB=
			'['+ ip_servidor +'].' +'['+ nombre_base+'].'+'[dbo]',@ipDB='['+ ip_servidor +'].'
							--from  [192.168.20.92].[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
							from  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
							where   emp_idempresa = @idEmpresa and suc_idsucursal is null
		END
	
         if @serverDB is null or len(@serverDB) =0
		 begin
		 RAISERROR('No encuentra la empresa',16,1);
		 return 0;
		 end
		 
----3.-Insertar en CON_MOVDET01--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	--select @serverDB serverDB,@MOV_MES MOV_MES,@idEmpresa idEmpresa,@idBanco idBanco,@NUMCTA NUMCTA
	--,@MOV_DEBE MOV_DEBE,@MOV_HABER MOV_HABER,@MOV_IDCLIENTE MOV_IDCLIENTE,@idUsuario idUsuario
 
		   Set @queryText1=' Declare @rfc nvarchar(20),@IDPERSONA int,@mov_numcta nvarchar(20),@MOV_CONSMOV int,@MOV_CONSPOL int,@PAR_IDENPARA nvarchar(20),@namedpi nvarchar(20),@fechaoper datetime = convert(datetime,'''+convert(nvarchar(10),@fechaoper,103)+''',103),@mov_fecha datetime = convert(datetime,'''+convert(nvarchar(10),@mov_fecha,103)+''',103)
select @MOV_CONSPOL=ISNULL(max(pol_consecutivo),0)+1  from '+@serverDB+'.con_pol01'+convert(nvarchar(8),@anio)+' where pol_tipo =''DPI'' and pol_mes ='+convert(nvarchar(2),@MOV_MES)+'
SELECT @IDPERSONA=IdPersona,@mov_numcta=cuentaContable  FROM [referencias].[dbo].[BancoCuenta] where  numeroCuenta = '''+@NUMCTA+''' -- idEmpresa = '+convert(nvarchar(6),@idEmpresa)+' and idBanco ='+convert(nvarchar(6),@idBanco)+' and
SELECT @rfc=per_rfc FROM '+@ipDB+'GA_Corporativa.dbo.PER_PERSONAS
WHERE PER_IDPERSONA =@IDPERSONA
 if @mov_numcta is null or len(@mov_numcta) =0
		 RAISERROR(''No se encuentra la cuenta contable en esa empresa'',16,1);
select @MOV_CONSMOV=ISNULL(max(mov_consmov),0)+1  from '+@serverDB+'.CON_MOVDET01'+convert(nvarchar(8),@anio)+' where MOV_CONSPOL =@MOV_CONSPOL and mov_mes ='+convert(nvarchar(2),@MOV_MES)+'  and MOV_TIPOPOL=''DPI''
select @namedpi =''DPI_''+RIGHT(''00000'' +convert(nvarchar(2),day(@fechaoper)),2)+RIGHT(''00000'' +convert(nvarchar(2),month(@fechaoper)),2)+convert(nvarchar(4),year(@fechaoper))+''_''+convert(nvarchar(5),@MOV_CONSPOL)
SELECT @PAR_IDENPARA=PAR_IDENPARA FROM '+@serverDB+'.PNC_PARAMETR WHERE PAR_TIPOPARA = ''CARTERA'' AND PAR_DESCRIP5 = ''2100-0002-000'+convert(nvarchar(1),@cuentacargo)+'-0004''
insert into '+@serverDB+'.CON_MOVDET01'+convert(nvarchar(8),@anio)+' (MOV_NUMCTA,	MOV_CONCEPTO,MOV_CONSMOV,MOV_DEBE,MOV_HABER,MOV_ORIGEN,MOV_IDCLIENTE,MOV_DEPTO,MOV_CARTERA,MOV_TIPODOCTO,MOV_IDDOCTO,MOV_FECHVEN,MOV_FECHPAG,MOV_AGENTE,MOV_TIPOPOL,MOV_CONSPOL,MOV_MES,MOV_CVEUSU,MOV_FECHOPE,MOV_CONCILIADO,MOV_FOLIO,MOV_FOLIODET,MOV_MONEDA,MOV_TIPOCAMBIO, MOV_OBSERVA) 
VALUES (@MOV_NUMCTA,--MOV_NUMCTA,
''DEPOSITO NO IDENTIFICADO''+'' ''+@namedpi,--MOV_CONCEPTO,
''1'',--MOV_CONSMOV,
'+convert(nvarchar(23),@MOV_HABER)+',--MOV_DEBE,
'+convert(nvarchar(23),@MOV_DEBE)+',--MOV_HABER,
'''',--MOV_ORIGEN,
'''+convert(nvarchar(5),@MOV_IDCLIENTE)+''',--MOV_IDCLIENTE,
'''', --MOV_DEPTO,
'''',--MOV_CARTERA,
'''',--MOV_TIPODOCTO,
'''',--MOV_IDDOCTO,
'''',--MOV_FECHVEN,
'''',--MOV_FECHPAG,
'''', --MOV_AGENTE,
''DPI'',--MOV_TIPOPOL,
convert(nvarchar(5),@MOV_CONSPOL),--MOV_CONSPOL,
'+convert(nvarchar(5),@MOV_MES)+',--MOV_MES,
'''+@idUsuario+''',--MOV_CVEUSU,
 '''+convert(nvarchar(10),@mov_fecha,103)+''',--MOV_FECHOPE,
'''',--MOV_CONCILIADO,
0,--MOV_FOLIO,
0,--MOV_FOLIODET,
''PE'',--MOV_MONEDA,
''1'',--MOV_TIPOCAMBIO,
@namedpi--MOV_OBSERVA
)'  +  CHAR(13) + CHAR(10)  +'EXEC [dbo].[BitacoraDPI_INS]  '+convert(nvarchar(9),@idAbonoBanco)+','+convert(nvarchar(9),@idEmpresa)+','+convert(nvarchar(9),@idBanco)+',@mov_numcta,@MOV_CONSPOL,2,'''','+convert(nvarchar(9),@Usuario)+  CHAR(13) + CHAR(10)  
		
----4.-Actualiza en CON_CTAS01--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 --[dbo].[CreaCargoDPI_INS]
	--		@idAbonoBanco INT,
	--		@idBanco INT,
	--		@idEmpresa INT,
	--		@MOV_NUMCTA varchar(50),
	--		@MOV_CONCEPTO varchar(250),
	--		@MOV_CONSPOL INT ,
	--		@MOV_CONSMOV INT,
	--		@MOV_DEBE decimal(18,5) =0,
	--		@MOV_HABER decimal(18,5) =0,
	--		@MOV_IDCLIENTE numeric (18,0),
	--		@MOV_TIPOPOL nvarchar(10),
	--		@MOV_MES int,
	--		@MOV_ANIO int
		   Set @queryText2= 

'EXECUTE [dbo].[CreaCargoDPI_INS] '+convert(nvarchar(9),@idAbonoBanco)+','+convert(nvarchar(9),@idBanco)+','+convert(nvarchar(9),@idEmpresa)+',@MOV_NUMCTA,@MOV_CONSPOL,@MOV_CONSMOV,'+convert(nvarchar(23),@MOV_DEBE)+','+convert(nvarchar(23),@MOV_HABER)+','''+convert(nvarchar(18),@MOV_IDCLIENTE)+''',''DPI'','+convert(nvarchar(5),@MOV_MES)+','+convert(nvarchar(5),@anio)+',@mov_fecha,@namedpi
update '+@serverDB+'.CON_CTAS01'+convert(nvarchar(8),@anio)+ ' set cta_abono'+convert(nvarchar(2),@MOV_MES)+' = cta_abono'+convert(nvarchar(2),@MOV_MES)+' + '+convert(nvarchar(23),@MOV_DEBE)+' , cta_cargo'+convert(nvarchar(2),@MOV_MES)+' = cta_cargo'+convert(nvarchar(2),@MOV_MES)+' + '+convert(nvarchar(23),@MOV_HABER)+' 
where  cta_numcta = substring(@MOV_NUMCTA,1,4)+''-0000-0000-0000'' or cta_numcta = substring(@MOV_NUMCTA,1,9)+''-0000-0000'' or cta_numcta = substring(@MOV_NUMCTA,1,14)+''-0000'' or cta_numcta = @MOV_NUMCTA'  +  CHAR(13) + CHAR(10) +
 CHAR(13) + CHAR(10)  +'EXEC [dbo].[BitacoraDPI_INS]  '+convert(nvarchar(9),@idAbonoBanco)+','+convert(nvarchar(9),@idEmpresa)+','+convert(nvarchar(9),@idBanco)+',@mov_numcta,@MOV_CONSPOL,3,'''','+convert(nvarchar(9),@Usuario)+  CHAR(13) + CHAR(10)   

----5.-Inserta en CON_CAR01--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		   Set @queryText3= 

'INSERT INTO '+@serverDB+'.CON_CAR01'+convert(nvarchar(8),@anio)+ ' (CCP_TIPOPOL,CCP_CONSPOL,CCP_CONSMOV,CCP_MES,CCP_CARTERA,CCP_TIPODOCTO,CCP_IDDOCTO,CCP_NODOCTO,CCP_COBRADOR,CCP_IDPERSONA,CCP_FECHVEN,CCP_FECHPAG,CCP_FECHPROMPAG,CCP_CARGO,CCP_ABONO,CCP_MONEDA,CCP_TIPOCAMBIO,CCP_IMPORTEMON,CCP_FECHOPE,CCP_CVEUSU,CCP_HORAOPE,CCP_FECHREV,CCP_DOCAFECTADO,CCP_CONCEPTO,CCP_REFERENCIA,CCP_OBSPAR,CCP_OBSGEN,CCP_CONPAGO,CCP_FECHADOCTO,CCP_ORIGENCON,CCP_DOCORI,CCP_REFER,CCP_GRUPO1,CCP_PORIVA,CCP_FECHAORACAR,CCP_IETU) 
 VALUES ( ''DPI'',--CCP_TIPOPOL,
 convert(nvarchar(5),@MOV_CONSPOL),--CCP_CONSPOL,
''2'',--MOV_CONSMOV,
 '+convert(nvarchar(5),@MOV_MES)+',--CCP_MES,
 @PAR_IDENPARA,--CCP_CARTERA,
 ''FAC'',--CCP_TIPODOCTO,
 @namedpi,--CCP_IDDOCTO,
 ''0000'',--CCP_NODOCTO,
 ''DIRECTO'',--CCP_COBRADOR,
 @IDPERSONA,--CCP_IDPERSONA,
 '''',--CCP_FECHVEN,
 '''',--CCP_FECHPAG,
 '''',--CCP_FECHPROMPAG,
 '+convert(nvarchar(23),@MOV_DEBE)+',--MOV_DEBE CCP_CARGO,
 '+convert(nvarchar(23),@MOV_HABER)+',--MOV_HABER CCP_ABONO,
 ''PE'',--CCP_MONEDA,
 ''1'',--CCP_TIPOCAMBIO,
 '+convert(nvarchar(23),@MOV_HABER)+',--CCP_IMPORTEMON,
  '''+convert(nvarchar(10),@mov_fecha,103)+''',	--CCP_FECHOPE,
'''+@idUsuario+''', --CCP_CVEUSU,
 convert(VarChar(5),getdate(),108),--CCP_HORAOPE,
 '''+convert(nvarchar(10),@mov_fecha,103)+''',--CCP_FECHREV,
 '''',--CCP_DOCAFECTADO,
 '''',--CCP_CONCEPTO,
 '''',--CCP_REFERENCIA,
 '''',--CCP_OBSPAR,
 '''',--CCP_OBSGEN,
 '''',--CCP_CONPAGO,
 '''+convert(nvarchar(10),@mov_fecha,103)+''',--CCP_FECHADOCTO,
 ''CON'',--CCP_ORIGENCON,
 ''S'',--CCP_DOCORI,
 '''',--CCP_REFER,
 '''',--CCP_GRUPO1,
 ''16'',--CCP_PORIVA,
'''+convert(nvarchar(19),@mov_fecha,126)+''',--CCP_FECHAORACAR,
 0	--CCP_IETU 
 )'  +  CHAR(13) + CHAR(10)   +'EXEC [dbo].[BitacoraDPI_INS]  '+convert(nvarchar(9),@idAbonoBanco)+','+convert(nvarchar(9),@idEmpresa)+','+convert(nvarchar(9),@idBanco)+',@mov_numcta,@MOV_CONSPOL,4,'''','+convert(nvarchar(9),@Usuario)+  CHAR(13) + CHAR(10)  
 ----6.-Inserta en CON_CFDI01--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
 
		   Set @queryText4= 

'INSERT INTO  '+@serverDB+'.CON_CFDI01'+convert(nvarchar(8),@anio)+ ' (CFI_TIPOPOL,CFI_CONSPOL,CFI_CONSMOV,CFI_MES,CFI_IDDOCTO,CFI_UUID,CFI_MONTO,CFI_IDPERSONA,CFI_RFC,CFI_RUTAXML,CFI_RUTAPDF,CFI_NOMBREXML,CFI_NOMBREPDF, CFI_ESTATUS,CFI_CVEUSU,CFI_FECHOPE,CFI_HORAOPE,CFI_DESCARTAR)
VALUES(''DPI'',--CFI_TIPOPOL,
convert(nvarchar(5),@MOV_CONSPOL),--CFI_CONSPOL,
''2'',--CFI_CONSMOV,
'+convert(nvarchar(5),@MOV_MES)+',--CFI_MES,
@namedpi,--CFI_IDDOCTO,
'''',--CFI_UUID,
0,--CFI_MONTO,
@IDPERSONA,	--CFI_IDPERSONA,
@rfc,--CFI_RFC,
'''',--CFI_RUTAXML,
'''',--CFI_RUTAPDF,
'''',--CFI_NOMBREXML,
'''',--CFI_NOMBREPDF, 
''A'',--CFI_ESTATUS,
'''+@idUsuario+''',--CFI_CVEUSU,
 '''+convert(nvarchar(10),@mov_fecha,103)+''',--CFI_FECHOPE,
CONVERT(VARCHAR(5),GETDATE(),108),--CFI_HORAOPE
null--CFI_DESCARTAR
)
'  +  CHAR(13) + CHAR(10)  +'EXEC [dbo].[BitacoraDPI_INS]  '+convert(nvarchar(9),@idAbonoBanco)+','+convert(nvarchar(9),@idEmpresa)+','+convert(nvarchar(9),@idBanco)+',@mov_numcta,@MOV_CONSPOL,5,'''','+convert(nvarchar(9),@Usuario)+  CHAR(13) + CHAR(10)  
 ----7.-Inserta en CON_MOVDET01--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
 
		   Set @queryText5= 

'INSERT INTO  '+@serverDB+'.CON_MOVDET01'+convert(nvarchar(8),@anio)+ ' ( MOV_NUMCTA,MOV_CONCEPTO,MOV_CONSMOV,MOV_DEBE,MOV_HABER,MOV_ORIGEN,MOV_IDCLIENTE,MOV_DEPTO,MOV_CARTERA,MOV_TIPODOCTO,MOV_IDDOCTO,MOV_FECHVEN,MOV_FECHPAG,MOV_AGENTE,MOV_TIPOPOL,MOV_CONSPOL,MOV_MES,MOV_CVEUSU,MOV_FECHOPE,MOV_CONCILIADO,MOV_FOLIO,MOV_FOLIODET,MOV_MONEDA,MOV_TIPOCAMBIO,MOV_OBSERVA)
 VALUES (''2100-0002-000'+convert(nvarchar(1),@cuentacargo)+'-0004'',	--MOV_NUMCTA,
''DEPOSITO NO IDENTIFICADO''+'' ''+@namedpi,--MOV_CONCEPTO,
''2'',--MOV_CONSMOV,
'+convert(nvarchar(23),@MOV_DEBE)+',--MOV_DEBE,
'+convert(nvarchar(23),@MOV_HABER)+',--MOV_HABER,
'''',--MOV_ORIGEN,
@IDPERSONA,--MOV_IDCLIENTE,
'''',--MOV_DEPTO,
@PAR_IDENPARA,--MOV_CARTERA,
''FAC'',--MOV_TIPODOCTO,
 @namedpi,--CCP_IDDOCTO,
'''',--MOV_FECHVEN,
'''',--MOV_FECHPAG,
'''',--MOV_AGENTE,
''DPI'',--MOV_TIPOPOL,
convert(nvarchar(5),@MOV_CONSPOL),--MOV_CONSPOL,
'+convert(nvarchar(5),@MOV_MES)+',--MOV_MES,
'''+@idUsuario+''',--MOV_CVEUSU,
 '''+convert(nvarchar(10),@mov_fecha,103)+''',--MOV_FECHOPE,
'''',--MOV_CONCILIADO,
0,--MOV_FOLIO,
0,--MOV_FOLIODET,
''PE'',--MOV_MONEDA,
''1'',--MOV_TIPOCAMBIO,
''''--MOV_OBSERVA
)
'  +    CHAR(13) + CHAR(10)  +'EXEC [dbo].[BitacoraDPI_INS]  '+convert(nvarchar(9),@idAbonoBanco)+','+convert(nvarchar(9),@idEmpresa)+','+convert(nvarchar(9),@idBanco)+',@mov_numcta,@MOV_CONSPOL,6,'''','+convert(nvarchar(9),@Usuario)+  CHAR(13) + CHAR(10)  
 ----8.-Inserta en CON_MOVDET01--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
 
		   Set @queryText6=

'update '+@serverDB+'.CON_CTAS01'+convert(nvarchar(8),@anio)+ ' set cta_abono'+convert(nvarchar(8),@MOV_MES)+ ' = cta_abono'+convert(nvarchar(8),@MOV_MES)+ ' + '+convert(nvarchar(23),@MOV_HABER)+' , cta_cargo'+convert(nvarchar(8),@MOV_MES)+ ' = cta_cargo'+convert(nvarchar(8),@MOV_MES)+ ' + '+convert(nvarchar(23),@MOV_DEBE)+'
where  cta_numcta = ''2100-0000-0000-0000'' or cta_numcta = ''2100-0002-0000-0000'' or cta_numcta = ''2100-0002-000'+convert(nvarchar(1),@cuentacargo)+'-0000'' or cta_numcta = ''2100-0002-000'+convert(nvarchar(1),@cuentacargo)+'-0004'''  +  CHAR(13) + CHAR(10)   
 
  ----9.-Inserta en CON_POL01--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
 
		   Set @queryText7= 

'INSERT INTO  '+@serverDB+'.CON_POL01'+convert(nvarchar(8),@anio)+ ' ( POL_TIPO, POL_CONSECUTIVO, POL_FECHA, POL_AJUSTE,POL_CONCEPTO, POL_REFERENCIA1,  POL_REFERENCIA2, POL_REFERENCIA3, POL_CARGO,POL_ABONO, POL_LEYENDA, POL_HONORARIOS,POL_AFAVOR, POL_MES, POL_CVEUSU, POL_FECHOPE, POL_CHEQUERA,pol_fija, pol_numbco,pol_nocheque)  
VALUES (
''DPI'',--POL_TIPO, 
convert(nvarchar(5),@MOV_CONSPOL) ,--POL_CONSECUTIVO,
 '''+convert(nvarchar(10),@mov_fecha,103)+''',--POL_FECHA, 
''0'',--POL_AJUSTE,
''DEPOSITO EN EFECTIVO DPI''+'' ''+@namedpi,--POL_CONCEPTO, 
'''',--POL_REFERENCIA1,
'''',--POL_REFERENCIA2,
'''',--POL_REFERENCIA3,
'+convert(nvarchar(23),@MOV_HABER)+',--MOV_DEBE POL_CARGO,
'+convert(nvarchar(23),@MOV_HABER)+',--MOV_HABER POL_ABONO,
''0'',--POL_LEYENDA, 
''0'',--POL_HONORARIOS,
'''',--POL_AFAVOR, 
'+convert(nvarchar(5),@MOV_MES)+',--POL_MES, 
'''+@idUsuario+''',--POL_CVEUSU, 
 '''+convert(nvarchar(10),@mov_fecha,103)+''',--POL_FECHOPE, 
'''',--POL_CHEQUERA,
''N'',--pol_fija, 
'''',--pol_numbco,
''''--pol_nocheque
)
'  +  CHAR(13) + CHAR(10)  +'EXEC [dbo].[BitacoraDPI_INS]  '+convert(nvarchar(9),@idAbonoBanco)+','+convert(nvarchar(9),@idEmpresa)+','+convert(nvarchar(9),@idBanco)+',@mov_numcta,@MOV_CONSPOL,7,'''','+convert(nvarchar(9),@Usuario)+  CHAR(13) + CHAR(10) +
'select @MOV_CONSPOL as id into ##TempDPI' 
--print 'Paso 01'
--print @queryText1
--print 'Paso 02'
--print @queryText2 
--print 'Paso 03'
--print @queryText3 
--print 'Paso 04'
--print @queryText4 
--print 'Paso 05'
--print @queryText5
--print 'Paso 06'
--print @queryText6 
--print 'Paso 07'
--print @queryText7
	--	print @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7
	--select len( @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7)
begin try
--Begin TRAN DPI
	EXEC( @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7) 
	--print @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7
	--select len( @queryText1+@queryText2+@queryText3+@queryText4+@queryText5+@queryText6+@queryText7)
	--COMMIT TRAN DPI
END TRY
BEGIN CATCH
    PRINT 'In CATCH Block'
	Declare @mensaje nvarchar(max)
	 select @mensaje=ERROR_MESSAGE() 
	 --IF(@@TRANCOUNT > 0)
  --     ROLLBACK TRAN DPI;
 EXEC [dbo].[BitacoraDPI_INS]  @idAbonoBanco,@idEmpresa,@idBanco,@NUMCTA,0,0,@mensaje,@Usuario

  
   select 0 as id,ERROR_MESSAGE() msg into ##TempDPI
  
END CATCH		
   
END
go

