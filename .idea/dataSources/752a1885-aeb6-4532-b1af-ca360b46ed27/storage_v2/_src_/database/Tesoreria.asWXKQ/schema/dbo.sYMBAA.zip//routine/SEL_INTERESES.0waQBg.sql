
CREATE PROCEDURE  [dbo].[SEL_INTERESES]
@idBanco INT=0,
@noCuenta varchar(50),
@fechaIni varchar(20) ,
@fechaFin varchar(20) 
	
AS
BEGIN
	
	set @fechaIni   = substring(@fechaIni,7,4) +   substring(@fechaIni,4,2) + substring(@fechaIni,1,2) 
	set @fechaFin   = substring(@fechaFin,7,4) +  substring(@fechaFin,4,2) + substring(@fechaFin,1,2)

	IF (@idBanco = 1) --bancomer
	
	Begin
	SELECT 
		  idbmer idDepositoBanco
		  ,[idBanco]
		  ,[idBmer]
		  ,'bancomer' banco
		  ,[txtOrigen]
		  ,[noCuenta]
		  ,[concepto]
		  ,[importe] as abono
		  ,0 as cargo
		  ,[saldoOperativo]
		  ,[referencia]
		  ,[fechaOperacion]
		  ,[horaOperacion]
		  ,[oficinaOperadora]

	 FROM referencias.DBO.BANCOMER WHERE codigoLeyenda IN
	(
		SELECT        CodigoBanco--, TipoMovimiento, Descripcion, CodigoBPRO, IDBanco
		FROM           referencias.DBO. CodigoIdentificacion
		where descripcion like 'interes%' and CodigoBanco 
		like 'C%'
		)

	AND  idbmer not in (select comisionID from InteresComision where BancoID = 1)

	END
	ELSE IF(@idBanco = 2) --Banamex
		
	BEGIN
		SELECT 
		  idBanamex idDepositoBanco
		  ,[idBanco]
		  ,[idBanamex]
		  ,'banamex' banco
		  ,[archivo]
		  ,[noCuenta]
		  ,[AODescripcion]
		  ,[SLMonto] as abono
		  ,0 as cargo
		  ,[OBmontoApertura]
		  ,[SLTipoReferencia]
		  ,[SLFechaTransaccion]
		  ,'12:00:00' as horaOperacion
		  ,'0' as [oficinaOperadora]

	 FROM referencias.DBO.Banamex WHERE SLCodigoTransaccion IN
	(
		SELECT        CodigoBanco--, TipoMovimiento, Descripcion, CodigoBPRO, IDBanco
		FROM           referencias.DBO. CodigoIdentificacion
		where descripcion like '%interes%' 
		and IdBanco = 2
		)

	AND  idbanamex not in (select comisionID from InteresComision where BancoID = 2)
	END
END
go

