-- =============================================
-- Author:		Ing. Luis Antonio García Perrusquía
-- Create date: 26/06/2018
-- Description:	SP que trae todos los usuarios que pueden ocupar el boton de cerrar el mes
-- TEST: EXEC [DBO].[SEL_USUARIOS_BOTON_CERRAR_MES_SP]
-- =============================================
CREATE PROCEDURE [DBO].[SEL_USUARIOS_BOTON_CERRAR_MES_SP]

AS
BEGIN
	BEGIN TRY
		SELECT 
			seg_idUsuario 
		FROM [Seguridad].[dbo].[SEG_CENTRALIZACION] 
		WHERE seg_idAccion = 16
	END TRY
	BEGIN CATCH
		SELECT msg = ERROR_LINE () + ' ' + ERROR_MESSAGE();
	END CATCH
END
go

