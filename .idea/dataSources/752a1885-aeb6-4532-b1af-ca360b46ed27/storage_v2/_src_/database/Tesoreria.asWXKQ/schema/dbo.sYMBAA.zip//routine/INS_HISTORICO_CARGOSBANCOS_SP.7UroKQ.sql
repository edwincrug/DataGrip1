-- =============================================
-- Author:	Ing. Luis Antonio García Perrusquía
-- Create date: 01/10/2018
-- Description:	Inserta en todos los registros en CARGOSBANCOS_CB_H
-- =============================================
CREATE PROCEDURE [dbo].[INS_HISTORICO_CARGOSBANCOS_SP] 
	@idEmpresa INT = 0,
	@idBanco INT = 0,
	@cuentaBancaria VARCHAR(60) = '',
	@cuentaContable VARCHAR(60) = '',
	@idHistorico INT = 0,
	@opcion INT = 0,
	@idUsuario INT = 0
AS
BEGIN
	--====CARGOSBANCOS PUNTEADOS DEL PERIODO ACTIVO 
	INSERT INTO CARGOSBANCOS_CB_H
		(IDCARGOSBANCOS, 
			idBmer, 
			IDBanco, 
			txtOrigen, 
			registro, 
			noMovimiento, 
			referencia, 
			concepto, 
			refAmpliada, 
			esCargo, 
			importe, 
			saldoOperativo, 
			codigoLeyenda, 
			oficinaOperadora, 
			fechaOperacion, 
			horaOperacion, 
			fechaValor, 
			fechaContable, 
			estatus, 
			noCuenta, 
			estatusRevision, 
			Tipo, 
			idUsuario, 
			idEmpresa, 
			anio, 
			fecha, 
			idEstatus, 
			idConciliado, 
			idHistorico) 
	SELECT 
		IDCARGOSBANCOS, 
		idBmer, 
		CAR.IDBanco, 
		txtOrigen, 
		registro, 
		noMovimiento, 
		referencia, 
		concepto, 
		refAmpliada, 
		esCargo, 
		importe, 
		saldoOperativo, 
		codigoLeyenda, 
		oficinaOperadora, 
		fechaOperacion, 
		horaOperacion, 
		fechaValor, 
		fechaContable, 
		estatus, 
		noCuenta, 
		estatusRevision, 
		Tipo, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		CAR.idEmpresa, 
		anio, 
		fecha, 
		idEstatus, 
		idConciliado, 
		@idHistorico 
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN CARGOSBANCOS_CB CAR ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo AND PUN.rpun_tipo = 'B'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria AND PA.mec_conciliado = 0
	WHERE CAR.idEmpresa = @idEmpresa
			AND CAR.IDBanco = @idBanco
			AND CAR.noCuenta = @cuentaBancaria
			AND PUN.idMes = PA.mec_idMes

	--====CARGOSBANCOS NO PUNTEADOS
	INSERT INTO CARGOSBANCOS_CB_H
		(IDCARGOSBANCOS, 
			idBmer, 
			IDBanco, 
			txtOrigen, 
			registro, 
			noMovimiento, 
			referencia, 
			concepto, 
			refAmpliada, 
			esCargo, 
			importe, 
			saldoOperativo, 
			codigoLeyenda, 
			oficinaOperadora, 
			fechaOperacion, 
			horaOperacion, 
			fechaValor, 
			fechaContable, 
			estatus, 
			noCuenta, 
			estatusRevision, 
			Tipo, 
			idUsuario, 
			idEmpresa, 
			anio, 
			fecha, 
			idEstatus, 
			idConciliado, 
			idHistorico) 
	SELECT 
		IDCARGOSBANCOS, 
		idBmer, 
		CAR.IDBanco, 
		txtOrigen, 
		registro, 
		noMovimiento, 
		referencia, 
		concepto, 
		refAmpliada, 
		esCargo, 
		importe, 
		saldoOperativo, 
		codigoLeyenda, 
		oficinaOperadora, 
		fechaOperacion, 
		horaOperacion, 
		fechaValor, 
		fechaContable, 
		estatus, 
		noCuenta, 
		estatusRevision, 
		Tipo, 
		CASE 
			WHEN @opcion = 1 -- por empresa 
		THEN @idUsuario 
			ELSE 0 -- por sistema 
		END, 
		CAR.idEmpresa, 
		anio, 
		fecha, 
		idEstatus, 
		idConciliado, 
		@idHistorico 
	FROM REGISTROS_PUNTEADOS PUN
	RIGHT JOIN CARGOSBANCOS_CB CAR ON PUN.rpun_idCargo = CAR.IDCARGOSBANCOS AND PUN.rpun_tipo = 'B'
	WHERE CAR.idEmpresa = @idEmpresa
			AND CAR.IDBanco = @idBanco
			AND CAR.noCuenta = @cuentaBancaria
			AND PUN.rpun_idPunteado IS NULL

	--====Tabla REGISTROS PUNTEADOS
	--====CARGOSBANCOS PUNTEADOS DEL PERIODO ACTIVO 
	INSERT INTO REGISTROS_PUNTEADOS_H 
		(rpun_idPunteado, 
			rpun_grupoPunteo, 
			rpun_idCargo, 
			rpun_idAbono, 
			rpun_tipo, 
			rpun_fechaPunteo, 
			rpun_usuario, 
			rpun_idAplicado, 
			idHistorico) 
	SELECT 
		rpun_idPunteado, 
		rpun_grupoPunteo, 
		rpun_idCargo, 
		rpun_idAbono, 
		rpun_tipo, 
		rpun_fechaPunteo, 
		rpun_usuario, 
		rpun_idAplicado, 
		@idHistorico 
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN CARGOSBANCOS_CB CAR ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo AND PUN.rpun_tipo = 'B'
	INNER JOIN PeriodoActivo PA ON PA.idEmpresa = @idEmpresa AND PA.idBanco = @idBanco AND PA.cuentaBancaria = @cuentaBancaria AND PA.mec_conciliado = 0
	WHERE CAR.idEmpresa = @idEmpresa
			AND CAR.IDBanco = @idBanco
			AND CAR.noCuenta = @cuentaBancaria
			AND PUN.idMes = PA.mec_idMes
END
go

