

/****** Script for SelectTopNRows command from SSMS  ******/
--select * from [dbo].[VW_VALIDAMONITORDPI] where  mes = 2 and anio=2019 and (existeRegistrosPunteados = 'No' or terminoProcesoDPI = 'No' or existeTablaDPI='No' or polizas <>1 or movdet <>2 or concar <>1 or cfdi <>1)
--select * from [dbo].[VW_VALIDAMONITORDPI] where  mes = 2 and anio=2019 and isnull(seatendio,0)=0 order by idempresa,idbanco,conspol
CREATE VIEW [dbo].[VW_VALIDAMONITORDPI] AS
select prin.[idAbonoBanco]
      ,prin.[idEmpresa]
      ,prin.[idBanco]
     
      ,prin.[conspol]
     , fecha
      , [noPaso]
	  ,rpun_idAbono,rpun_grupoPunteo,rpun_idAplicado,idmes
	  ,isnull(b.numeroCuenta,noCuenta) noCuenta
	  ,isnull(c.cuentaContable,noCuenta) cuentacontable
	  ,d.idEstatus
	  ,p.mec_numMes mes
	  ,p.mec_anio anio
	  ,case when rpun_idabono is null then 'No' else 'Si' end existeRegistrosPunteados
	  ,case when noPaso >=7 then 'Si' else 'No' end terminoProcesoDPI
	 ,case when idEstatus is null then 'No' else 'Si' end existeTablaDPI
	 ,isnull(pol.cuantos,0) polizas
	 ,isnull(mov.cuantos,0) movdet
	 ,isnull(car.cuantos,0) concar
	 ,isnull(cfd.cuantos,0) cfdi
	 ,isnull(seatendio,0) seatendio
	 from (
		SELECT [idAbonoBanco]
			  ,[idEmpresa]
			  ,[idBanco]
			  ,max([noCuenta]) noCuenta
			  ,[conspol]
			 ,max(fecha) fecha
			  ,max([noPaso]) [noPaso]
      ,seatendio
		  FROM [Tesoreria].[dbo].[BitacoraDPI]
 
		  group by [idAbonoBanco]
			  ,[idEmpresa]
			  ,[idBanco]
     
			  ,[conspol]
			  ,seatendio
	  ) prin
	  left join 
	  (
		 select rpun_idAbono,rpun_grupoPunteo,rpun_idAplicado,idmes from REGISTROS_PUNTEADOS r where rpun_idAbono <>0 and rpun_tipo='B'
	  ) r on prin.idAbonoBanco=r.rpun_idAbono
	  left join referencias.dbo.BancoCuenta b on prin.idEmpresa=b.idEmpresa and prin.idBanco=b.idBanco and prin.noCuenta=b.cuentaContable
	  left join referencias.dbo.BancoCuenta c on prin.idEmpresa=c.idEmpresa and prin.idBanco=c.idBanco and prin.noCuenta=c.numeroCuenta
	  left join (select d.idEmpresa,d.idBanco,ab.IDABONOSBANCOS idAbonoBanco,d.idEstatus from DepositoBancarioDPI d inner join ABONOSBANCOS_CB ab on d.idAbonoBanco=ab.idBmer  and d.idEmpresa=ab.idEmpresa and d.idBanco=ab.idBanco ) d 
			on prin.idAbonoBanco=d.idAbonoBanco and prin.idEmpresa=d.idEmpresa and prin.idBanco=d.idBanco
	  inner join PeriodoActivo p on r.idmes=p.mec_idMes
	  left join (select idempresa,pol_consecutivo conspol,pol_mes,count(pol_consecutivo) cuantos from  [Tesoreria].[dbo].[VW_CON_POL] group by idempresa,pol_consecutivo,pol_mes) pol
	  on prin.conspol=pol.conspol and p.mec_numMes=pol.pol_mes and prin.idEmpresa= pol.idempresa
	  left join (select idempresa,mov_conspol conspol,mov_mes,count(mov_conspol) cuantos from  [Tesoreria].[dbo].[VW_CON_MOVDET] group by idempresa, mov_conspol,mov_mes) mov
	  on prin.conspol=mov.conspol and p.mec_numMes=mov.MOV_MES and prin.idEmpresa= mov.idempresa
	  left join (select idempresa,CCP_CONSPOL conspol,ccp_mes,count(CCP_CONSPOL) cuantos from [Tesoreria].[dbo].[VW_CON_CAR] group by idempresa,CCP_CONSPOL,ccp_mes) car
	  on prin.conspol=car.conspol and p.mec_numMes=car.ccp_mes and prin.idEmpresa= car.idempresa
	  left join (select idempresa,cfi_conspol conspol,cfi_mes,count(cfi_conspol) cuantos from  [Tesoreria].[dbo].[VW_CON_CFDI] group by idempresa,cfi_conspol,cfi_mes) cfd
	  on prin.conspol=cfd.conspol and p.mec_numMes=cfd.CFI_MES and prin.idEmpresa= cfd.idempresa



go

