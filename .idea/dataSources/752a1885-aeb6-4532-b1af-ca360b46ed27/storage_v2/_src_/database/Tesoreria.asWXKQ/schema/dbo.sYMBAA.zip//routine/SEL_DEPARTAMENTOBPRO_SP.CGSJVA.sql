



CREATE procedure [dbo].[SEL_DEPARTAMENTOBPRO_SP]
@sucursalID as int
as
begin

SELECT [unicoID]
      ,[sucursalID]
      ,[cuentaContable]
      ,[descripcion]
      ,[subCuenta]
      ,[porcentaje]
      ,[esVisible]
  FROM [dbo].[DepartamentosBPRO]
 where sucursalID=@sucursalID  and esvisible=1
end
go

