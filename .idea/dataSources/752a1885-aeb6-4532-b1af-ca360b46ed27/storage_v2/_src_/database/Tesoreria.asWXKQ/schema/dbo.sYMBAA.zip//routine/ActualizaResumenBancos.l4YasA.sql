-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <05/08/2019>
-- Description:	<Saca resumen y actualiza todo>
-- =============================================
CREATE PROCEDURE [dbo].[ActualizaResumenBancos]

AS
BEGIN
DECLARE @RC int
DECLARE @idEmpresa varchar(50)
DECLARE @idBanco int
DECLARE @noCuenta varchar(50)
DECLARE @cuentaContable varchar(50)
DECLARE @polizaPago varchar(20)
DECLARE @opcion int
DECLARE @idUsuario int
DECLARE @idHistorico numeric(18,0)

Declare @min int=0,@max int=0,@const int,@mes int ,@anio int,@fechainicial nvarchar(10),@fechacorte nvarchar(10)
select ROW_NUMBER() OVER(ORDER BY b.idempresa,b.idbanco ASC) AS RowId, d.emp_idempresa,b.idBanco,b.numeroCuenta,b.cuentaContable,d.tipo_poliza_pago,2 opcion,71 idusuario,p.mec_numMes,p.mec_anio into #temp 
from Centralizacionv2.dbo.dig_cat_bases_bpro d
inner join referencias.dbo.BancoCuenta b on d.emp_idempresa=b.idEmpresa 
inner join PeriodoActivo p on b.idEmpresa=p.idEmpresa and b.idBanco=p.idBanco and b.numeroCuenta=p.cuentaBancaria and p.mec_conciliado=0
where d.tipo=2  and d.emp_idempresa not in (7,8,12,13,15,16,17,18) and b.idBanco = 1
select * from #temp
--drop table #temp
select @min=min(RowId) from #temp
--dbo.[SEL_TOTAL_ABONOCARGO_SP] 10,1,'000000000195368316','1100-0020-0001-0001','2019-01-01','2019-01-31','TREEHY',2,71

select @max=max(RowId) from  #temp

Set @const=@min

--WHILE (@const <=@max ) 
--BEGIN  
----select @mes=mec_numMes,@anio=mec_anio from tesoreria.dbo.PeriodoActivo where idEmpresa=1 and idbanco=1 and cuentaBancaria='000000000195334667' and mec_conciliado=0
----Set @fechainicial = convert(nvarchar(4),@anio)+'-'+right('0'+convert(varchar(2), convert(nvarchar(2),@mes)), 2)+'-01'
----Select @fechacorte=dateadd(day, -1, convert(date,convert(nvarchar(4),@anio)+'-'+convert(nvarchar(2),@mes+1)+'-01',120))

--select @mes=4,@anio=2020 
--Set @fechainicial = '2020-03-01'
--Select @fechacorte= '2020-03-30'
--  select 
--  @idEmpresa=emp_idempresa,
--  @idBanco=idBanco,
--  @noCuenta= numeroCuenta,
--  @cuentaContable=CuentaContable,
--  @polizaPago= tipo_poliza_pago,
--  @opcion= opcion,
--  @idUsuario=idusuario,
--  @mes=mec_numMes

--   from  #temp where rowId=@const

-- --  select  @idEmpresa idEmpresa, @idBanco idBanco  ,@noCuenta noCuenta  ,@cuentaContable cuentaContable  ,@fechainicial fechainicial  ,@fechacorte fechacorte  ,@polizaPago polizaPago  ,@opcion  opcion ,@idUsuario idUsuario ,0 idhistorico

--  EXECUTE @RC = [dbo].[SEL_TOTAL_ABONOCARGO_SP] 
--   @idEmpresa
--  ,@idBanco
--  ,@noCuenta
--  ,@cuentaContable
--  ,@fechainicial
--  ,@fechacorte
--  ,@polizaPago
--  ,@opcion
--  ,@idUsuario
--  ,0

--  set @const=@const+1
--END  
END
go

