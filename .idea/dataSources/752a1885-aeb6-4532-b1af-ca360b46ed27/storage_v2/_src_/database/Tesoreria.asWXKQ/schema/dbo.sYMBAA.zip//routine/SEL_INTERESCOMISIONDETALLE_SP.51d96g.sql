
CREATE procedure [dbo].[SEL_INTERESCOMISIONDETALLE_SP] 
	@idcomisionInteres as NUMERIC(12)
AS
BEGIN
	SELECT cid_cuentacontable, cid_concepto,cid_cargo,cid_abono
	FROM cxp_comisionesinteresesdet DET
	INNER JOIN cxp_comisionesintereses ENC ON ENC.coi_idcomisionesintereses = DET.coi_idcomisionesintereses
	WHERE interesComisionID = @idcomisionInteres;
END
go

