-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 03/08/2017
-- Description:	Se obtienen los depositos referenciados aplicados correctamente
-- ==========================================================================================

-- [SEL_DEPOSITOS_APLICADOS_SP] 2,'02691814702','01/09/2020','28/09/2020'
CREATE PROCEDURE [dbo].[SEL_DEPOSITOS_APLICADOS_SP]
    @idBanco INT = 0,
	@noCuenta varchar(50)='',
	@fechaIni varchar(20) = '',
	@fechaFin varchar(20) = ''
AS   
BEGIN
	DECLARE @NombreBanco VARCHAR(15) = (SELECT nombre FROM [referencias].[dbo].[Banco] WHERE idBanco = @idBanco);
	
	IF( @fechaIni = '' AND @fechaFin = '')
		BEGIN
			SELECT distinct idbmer idDepositoBanco,
				   CD.idBanco,
				   [idBmer],
				   @NombreBanco banco,
				   [txtOrigen],
				   [noCuenta],
				   [concepto],
				   [importe] as abono,
				   0 as cargo,
				   [saldoOperativo],
				   CD.[referencia],
				   convert (varchar(20), [fechaOperacion],103) [fechaOperacion],
				   [horaOperacion],
				   [oficinaOperadora],
				   refAmpliada,
				   TES.idReferencia
			FROM [controlDepositosview] CD
			LEFT JOIN [Referencia] TES ON CD.idBmer = TES.depositoID and cd.IDBanco=tes.IDBanco
			LEFT JOIN [referencias].[dbo].[Referencia] REF ON TES.referencia =	REF.referencia 
			WHERE CD.idBanco = @idBanco
				AND noCuenta = @noCuenta
				AND esCargo = 0
				AND REF.estatus = 0
				--AND concepto NOT LIKE 'CE%' 
				--AND concepto NOT LIKE 'CC%'
				--AND concepto NOT like 'interes%'	 
				--AND concepto NOT like 'COMISI%'
				--AND concepto NOT like 'IVA COM%'
				--AND concepto NOT like 'IVA INTERES%'
				AND REF.idReferencia IS NOT NULL
			ORDER BY fechaOperacion,horaOperacion asc;
		END
	ELSE
		BEGIN
			SET @fechaIni   = substring(@fechaIni,7,4) +   substring(@fechaIni,4,2) + substring(@fechaIni,1,2) 
			SET @fechaFin   = substring(@fechaFin,7,4) +  substring(@fechaFin,4,2) + substring(@fechaFin,1,2)
			
			SELECT distinct idbmer idDepositoBanco,
				   CD.idBanco,
				   [idBmer],
				   @NombreBanco banco,
				   [txtOrigen],
				   [noCuenta],
				   [concepto],
				   [importe] as abono,
				   0 as cargo,
				   [saldoOperativo],
				   CD.[referencia],
				   convert (varchar(20), [fechaOperacion],103) [fechaOperacion],
				   [horaOperacion],
				   [oficinaOperadora],
				   refAmpliada,
				   TES.idReferencia
			FROM [controlDepositosview] CD
			LEFT JOIN [Referencia] TES ON CD.idBmer = TES.depositoID and cd.IDBanco=tes.IDBanco
			LEFT JOIN [referencias].[dbo].[Referencia] REF ON TES.referencia =	REF.referencia
			WHERE CD.idBanco = @idBanco	
				AND fechaOperacion BETWEEN @fechaIni AND @fechaFin
				AND noCuenta = @noCuenta
				AND esCargo = 0
				AND REF.estatus = 0
				--AND concepto NOT LIKE 'CE%' 
				--AND concepto NOT LIKE 'CC%'
				--AND concepto NOT like 'interes%'	 
				--AND concepto NOT like 'COMISI%'
				--AND concepto NOT like 'IVA COM%'
				--AND concepto NOT like 'IVA INTERES%'
				AND REF.idReferencia IS NOT NULL
			ORDER BY fechaOperacion,horaOperacion asc;
		END
END
go

