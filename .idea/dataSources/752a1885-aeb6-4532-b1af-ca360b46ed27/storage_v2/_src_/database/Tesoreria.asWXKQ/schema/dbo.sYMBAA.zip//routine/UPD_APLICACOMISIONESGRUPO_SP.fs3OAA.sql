-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- =============================================
--[dbo].[UPD_APLICACOMISIONESGRUPO_SP] 9,1
CREATE PROCEDURE [dbo].[UPD_APLICACOMISIONESGRUPO_SP]
	@idEmpresa INT = 0,
	@idBanco INT = 0
AS
BEGIN
	DECLARE @Grupo NUMERIC(18,0);
	DECLARE @LastId INT;

	SELECT 
		DISTINCT( agrupador ), 
		ROW_NUMBER() OVER(ORDER BY agrupador ASC) AS Row 
	INTO #Comisiones
	FROM  [InteresComision] 
	WHERE statusID = 1 AND idEmpresa = @idEmpresa AND bancoID = @idBanco
	GROUP BY agrupador

	DECLARE @Max INT = ( SELECT MAX(Row) FROM #Comisiones ),
			@Current INT = 1;

	WHILE ( @Current <= @Max )
		BEGIN
			SET @Grupo = (SELECT agrupador FROM #Comisiones WHERE Row = @Current);
			-- Obtenermo la Sucursal Matriz
			DECLARE @numGrupos NUMERIC(18,0) = ( SELECT COUNT(interesComisionID) FROM  [InteresComision] WHERE agrupador = @Grupo AND idEmpresa = @idEmpresa);
			DECLARE @sucMatriz NUMERIC(2,0)  = ( SELECT sucursal_matriz FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND tipo = 2 );
	
			-- Aqui se hace la migracion por grupo
			INSERT INTO cuentasxpagar .dbo.[cxp_comisionesintereses]
			SELECT TOP 1
				coi_idempresa,
				'coi_idsucursal' = CASE   
										WHEN @numGrupos = 1 THEN coi_idsucursal
										ELSE @sucMatriz
									END,
				'coi_tipopoliza' = CASE   
										WHEN @numGrupos = 1 THEN (SELECT tipoPoliza FROM  [TipoPoliza] WHERE idEmpresa = @idEmpresa AND idSucursal = coi_idsucursal AND idTipo = 1)
										ELSE (SELECT tipoPoliza FROM  [TipoPoliza] WHERE idEmpresa = @idEmpresa AND idSucursal = @sucMatriz AND idTipo = 1)
									END,
				coi_fechapoliza,
				'coi_descripcion' = 'Comisiones Bancomer ' + CONVERT( VARCHAR, CONVERT(date, getdate()) ),
				coi_fechageneracion,
				coi_estatus,
				coi_cuentabeneficiario,
				coi_cuentapagadora,
				coi_cobrador,
				coi_moneda,
				coi_tipocambio,
				coi_formapago,
				coi_tipo
			FROM  [cxp_comisionesintereses] CXP
			INNER JOIN  [InteresComision] COM ON CXP.interesComisionID = COM.interesComisionID
			WHERE COM.agrupador = @Grupo AND idEmpresa = @idEmpresa;
		
			-- Obtenemos el Id con que se guardo en BPRO
			SET @LastId = SCOPE_IDENTITY();
		
			-- Actualizamos a estatus 2 para indicar que ya se procesaron
			UPDATE InteresComision SET statusID = 2 WHERE agrupador = @Grupo AND idEmpresa = @idEmpresa;
		
			-- Se guarda el id de BPRO en las tablas de Tesoreria
			UPDATE  [cxp_comisionesintereses] 
				SET coi_idcomisionesinteresesBPRO = @LastId 
			WHERE interesComisionID IN ( SELECT interesComisionID FROM  [InteresComision] WHERE agrupador = @Grupo AND idEmpresa = @idEmpresa);
		
			-- Detalles de cada grupo
			INSERT INTO cuentasxpagar.[dbo].[cxp_comisionesinteresesdet] 
			SELECT 
				cid_cuentacontable,
				cid_concepto,
				cid_cargo,
				cid_abono,
				cid_documento,
				cid_idpersona,
				@LastId,
				cid_tipodocumento,
				cid_fechavencimiento,
				cid_poriva,
				cid_referencia,
				cid_banco,
				cid_referenciabancaria,
				cid_conpoliza 
			FROM  [cxp_comisionesinteresesdet] DET
			INNER JOIN  [cxp_comisionesintereses] CXP ON DET.coi_idcomisionesintereses = CXP.coi_idcomisionesintereses
			INNER JOIN  [InteresComision] COM ON CXP.interesComisionID = COM.interesComisionID
			WHERE COM.agrupador = @Grupo AND idEmpresa = @idEmpresa
			ORDER BY cid_conpoliza ASC;

			SET @Current = @Current + 1;
		END

	SELECT 1 AS respuesta, 'Insert Éxitoso' mensaje
	DROP TABLE #Comisiones
END
go

