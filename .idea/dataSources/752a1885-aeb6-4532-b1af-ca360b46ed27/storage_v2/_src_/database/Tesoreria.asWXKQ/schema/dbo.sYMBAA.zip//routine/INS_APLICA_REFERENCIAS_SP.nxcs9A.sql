--[dbo].[INS_APLICA_REFERENCIAS_SP] 14802,71
CREATE PROCEDURE [dbo].[INS_APLICA_REFERENCIAS_SP] 
	@idReferencia INT = 0,
	@idUsuario INT = 0
AS
BEGIN
	--DECLARE @idReferencia INT = 10769;
	--DECLARE @idUsuario INT = 71;

	DECLARE @temp_refantypag TABLE(
		ID int,
		rap_idempresa int,
		rap_idsucursal int,
		rap_iddepartamento int ,
		rap_idpersona numeric(18, 0),
		rap_cobrador varchar(10),
		rap_moneda varchar(10),
		rap_tipocambio decimal(18, 5),
		rap_referencia varchar(20),
		rap_iddocto varchar(20),
		rap_cotped varchar(20),
		rap_consecutivo varchar(20),
		rap_importe decimal(18, 5),
		rap_formapago varchar(10),
		rap_numctabanc varchar(50),
		rap_fecha datetime,
		rap_idusuari int,
		rap_idstatus int,
		rap_banco varchar(50),
		rap_referenciabancaria varchar(20),
		rap_anno varchar(4),
		RAP_AplicaPago decimal(18, 5),
		RAP_NumDeposito numeric(18, 0),
		dep_detalle INT
	);

	DECLARE @idReferencianNueva INT,  @idBanco INT, @idBancoFinal INT, @Referencia VARCHAR(20),@importe decimal(18,2)

	SET @idBanco		= ( SELECT top 1 IDBanco FROM Referencia WHERE idReferencia = @idReferencia );
	SET @idBancoFinal	= ( SELECT top 1 depositoID FROM Referencia WHERE idReferencia = @idReferencia );
	SET @Referencia		= ( SELECT top 1 [referencia] FROM [Referencia] WHERE [idReferencia] = @idReferencia );
	SET @importe		= ( SELECT top 1 importeDocumento FROM Referencia r inner join DetalleReferencia d on r.idreferencia=d.idReferencia WHERE r.idReferencia = @idReferencia );

	if exists(select idDpiAnterior from dpiAnterior d inner join referencias.dbo.BancoCuenta b on d.cuenta=b.numeroCuenta where idBanco=@idbanco  and idDpiAnterior=@idBancoFinal
	union all
	select idBmer from  DepositoBancarioDPI DPI 
	INNER JOIN ABONOSBANCOS_CB ABO ON DPI.idAbonoBanco = ABO.idBmer AND DPI.idEmpresa = ABO.idEmpresa AND DPI.idBanco = ABO.IDBanco
	where abo.idBanco=@idbanco  and abo.idBmer=@idBancoFinal
	)
	begin
	execute [dbo].[INS_APLICA_REFERENCIASDPI_SP] 
	@idReferencia ,
	@idUsuario 
	end
	else
	begin

		DECLARE @Cosecutivo INT = ( SELECT
									CASE WHEN MAX(RAP_NumDeposito) IS NULL
										THEN 1
									ELSE (MAX(RAP_NumDeposito) + 1 ) END AS Consecutivo
								FROM GA_Corporativa.DBO.cxc_refantypag
								WHERE rap_referenciabancaria = (
																	SELECT referencia 
																	FROM Referencia 
																	WHERE idReferencia = @idReferencia
																) );

	-- Obtenemos si hay mas de una sucursal en el detalle
	DECLARE @SucVarios INT = (SELECT COUNT(DISTINCT(idSucursal)) Sucursal FROM [Referencia] REF
							  INNER JOIN [DetalleReferencia] DET ON REF.idReferencia = DET.idReferencia
							  WHERE REF.idReferencia = @idReferencia);

	DECLARE @idEmpresa INT = (SELECT idEmpresa FROM [Referencia] WHERE [idReferencia] = @idReferencia);
	DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);
	DECLARE @Cartera VARCHAR(255);
	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			SET @Cartera = (SELECT '[' + nombre_base_matriz + '].dbo.VIS_CONCAR01' FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND tipo = 2);
		END
	ELSE
		BEGIN
			SET @Cartera = (SELECT '[' + ip_servidor + '].[' + nombre_base_matriz + '].dbo.VIS_CONCAR01' FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND tipo = 2);
		END
	

	DECLARE @sucMatriz INT = (SELECT sucursal_matriz FROM Centralizacionv2..DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);

	-- Se guarda el registro en refantipag
	DECLARE @DepartamentosNissan VARCHAR(MAX) = 
	'CASE REF.idEmpresa 
							WHEN 2 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		WHEN 4 THEN 16
																	END
																)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							WHEN 3 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		WHEN 5 THEN 21
																	END
																)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							WHEN 4 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		WHEN 6 THEN 26
																		WHEN 7 THEN 31
																		WHEN 8 THEN 36
																	END
																)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							WHEN 5 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		WHEN 9 THEN 41
																		WHEN 10 THEN 46
																		WHEN 11 THEN 51
																	END
																)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							WHEN 6 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		WHEN 12 THEN 56
																		WHEN 13 THEN 61
																		WHEN 14 THEN 66
																	END
																)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							WHEN 8 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		WHEN 17 THEN 81
																	END
																)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							WHEN 9 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		WHEN 18 THEN 86
																		WHEN 19 THEN 91
																		WHEN 20 THEN 96
																		WHEN 21 THEN 105
                                                                        WHEN 24 THEN 120
																	END
																)
												WHEN ''US'' THEN (
													CASE DET.idSucursal
														WHEN 18 THEN 86
														WHEN 19 THEN 91
														WHEN 20 THEN 96
														WHEN 21 THEN 105
                                                        WHEN 24 THEN 120
													END
												)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							WHEN 10 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		WHEN 22 THEN 110
																		WHEN 23 THEN 115
                                                                        
																	END
																)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							WHEN 11 THEN (
											CASE (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento)
												WHEN ''OT'' THEN (
																	CASE DET.idSucursal
																		
																		WHEN 25 THEN 125
                                                                        
																	END
																)
												ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
											END
										)
							ELSE CONVERT(VARCHAR(18),DET.idDepartamento)
						END';

	DECLARE @RAPreferencia VARCHAR(MAX) = 
	'CASE  -- Unidades Nuevas y Seminuevas
						WHEN (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT TOP 1 CONVERT(VARCHAR(18),ucu_idcotizacion) FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DET.documento ) IS NOT NULL
										 THEN (SELECT TOP 1 ucu_foliocotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL WHERE ucu_idcotizacion = (SELECT TOP 1 ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DET.documento)) COLLATE Modern_Spanish_CS_AS
										ELSE DET.documento
									END
								)
						ELSE DET.documento
				   END';

	DECLARE @RAPiddocto VARCHAR(MAX) = 
	'CASE  -- Unidades Nuevas y Seminuevas
						WHEN (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT TOP 1 ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DET.documento ) IS NOT NULL
										 THEN DET.documento
										ELSE ''''
									END
								)
						ELSE ''''
				   END';

	DECLARE @RAPcotped VARCHAR(MAX) = 
	'CASE  --Unidades Nuevas y Seminuevas
						WHEN (SELECT TOP 1 dep_nombrecto from [ControlAplicaciones].[dbo].[cat_departamentos] where  dep_iddepartamento = DET.idDepartamento) IN (''UN'',''US'')
						 THEN  (
									CASE WHEN ( SELECT TOP 1 ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DET.documento ) IS NOT NULL
										 THEN ''COTIZACION UNIVERSAL''
										ELSE ''''
									END
								)
						ELSE ''''
				   END';
						
	DECLARE @Query VARCHAR(MAX)='',@Query2 VARCHAR(MAX)='',@Query3 VARCHAR(MAX)='';
	SET @Query = 'SELECT
					ID						= ROW_NUMBER() OVER(ORDER BY DET.idDetallereferencia ASC),
					rap_idempresa			= REF.idEmpresa,
					/*rap_idsucursal		= (CASE WHEN ' + CONVERT( VARCHAR(20),@SucVarios ) + ' = 1 THEN DET.idSucursal ELSE '+ CONVERT( VARCHAR(20), @sucMatriz ) +' END ),*/
                    rap_idsucursal			= DET.idSucursal,
					rap_iddepartamento		= ' + @DepartamentosNissan + ','
	SET @Query2 ='rap_idpersona			= DET.idCliente,
					rap_cobrador			= ''MMK'',
					rap_moneda				= ''PE'',
					rap_tipocambio			= 1,
                    rap_referencia				=  substring( CASE (DET.idTipoDocumento)
                                                    WHEN 1 THEN DET.documento
                                                    WHEN 2 
                                                        THEN
                                                            CASE CHARINDEX(''-'',DET.documento)
                                                                WHEN 0 THEN
                                                                    CASE WHEN SUBSTRING(DET.documento,1,2) IN ( ''AA'', ''AB'', ''AC'', ''AD'', ''AE'' )
                                                                        THEN (
                                                                            CASE WHEN (SELECT TOP 1 ucu_foliocotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL WHERE ucu_idcotizacion IN (SELECT TOP 1 ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DET.documento) AND ucu_idempresa = '+CONVERT(nvarchar(2), @idEmpresa)+' AND ucu_idsucursal = (CASE WHEN ' + CONVERT( VARCHAR(20),@SucVarios ) + ' = 1 THEN DET.idSucursal ELSE '+ CONVERT( VARCHAR(20), @sucMatriz ) +' END )) IS NULL
                                                                                THEN DET.documento
                                                                                ELSE (SELECT TOP 1 ucu_foliocotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSAL WHERE ucu_idcotizacion IN (SELECT TOP 1 ucu_idcotizacion FROM cuentasporcobrar.DBO.UNI_COTIZACIONUNIVERSALUNIDADES WHERE ucn_idFactura COLLATE Modern_Spanish_CS_AS = DET.documento) AND ucu_idempresa = '+CONVERT(nvarchar(2), @idEmpresa)+' AND ucu_idsucursal = (CASE WHEN ' + CONVERT( VARCHAR(20),@SucVarios ) + ' = 1 THEN DET.idSucursal ELSE '+ CONVERT( VARCHAR(20), @sucMatriz ) +' END )) COLLATE Modern_Spanish_CS_AS
                                                                            END
                                                                        )	
                                                                        ELSE '+ @RAPreferencia +'
                                                                    END
                                                                ELSE ''''
                                                            END
                                                    ELSE ''''
                                                END,1,20),
                    rap_iddocto				= '''','
        Set @Query3='rap_cotped				=   CASE (DET.idTipoDocumento)
                                                    WHEN 1 THEN ''''
                                                    WHEN 2 THEN ''COTIZACION UNIVERSAL''
                                                    ELSE ''''
                                                END,
                    rap_consecutivo				=   CASE (DET.idTipoDocumento)
                                                    WHEN 1 THEN ( SELECT top 1 CCP_CONSCARTERA FROM '+ @Cartera +' WHERE CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DET.documento AND CCP_IDPERSONA = DET.IdCliente AND CCP_TIPODOCTO IN (''FAC'', ''NCA'', ''RD'',''NCSS'')) 
                                                    WHEN 2 THEN ''''
                                                    ELSE ''''
                                                END,
					rap_importe				= convert(decimal(32,2),DET.importeAplicar),
					rap_formapago			= (select top 1 co.CodigoBPRO  from [referencias].[dbo].Bancomer b inner join  [referencias].[dbo].CodigoIdentificacion co  on co.CodigoBanco = b.codigoLeyenda),
					rap_numctabanc			= b.[noCuenta],
					rap_fecha				= GETDATE(),
					rap_idusuari			= (SELECT top 1 usu_idusuario FROM ControlAplicaciones..cat_usuarios WHERE usu_nombreusu = ''GMI''),
					rap_idstatus			= ''1'',
					rap_banco				= (SELECT TOP 1 idBancoBPRO FROM referencias.dbo.BancoCuenta WHERE idEmpresa = REF.idEmpresa AND idBanco = B.idBanco AND numeroCuenta = B.noCuenta),
					rap_referenciabancaria	= REF.referencia,
					rap_anno				= (SELECT top 1 Vcc_Anno FROM '+ @Cartera +' WHERE CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS= DET.documento AND CCP_IDPERSONA = DET.IdCliente),
					RAP_AplicaPago			= convert(decimal(32,2),DET.importeBPRO),
					RAP_NumDeposito			= '+ CONVERT( VARCHAR(10), @Cosecutivo ) +',
					dep_detalle				= DET.idDetalleReferencia
				FROM [DetalleReferencia] DET
				INNER JOIN [Referencia] REF		ON DET.idReferencia = REF.idReferencia
				INNER JOIN Centralizacionv2..DIG_CAT_BASES_BPRO BP	ON REF.idEmpresa = BP.emp_idempresa AND DET.idSucursal = BP.suc_idsucursal
				INNER JOIN [DepositoBancoView] B	ON REF.depositoID = B.idBmer and ref.IDBanco=b.idBanco
				WHERE REF.idReferencia = ' + CONVERT(VARCHAR(18), @idReferencia);

	INSERT INTO @temp_refantypag
	EXECUTE( @Query+@Query2+@Query3 );
	print @Query
	print @Query2
	print @Query3
--	select * from @temp_refantypag
	-- Clasificacion de Tipos de Documentos
	SELECT 
		ROW_NUMBER() OVER(ORDER BY ID ASC) ROW,
		ID
	INTO #tmpCotiUniversal
	FROM @temp_refantypag WHERE rap_cotped = 'COTIZACION UNIVERSAL';

	SELECT 
		ROW_NUMBER() OVER(ORDER BY ID ASC) ROW,
		ID
	INTO #tmpOtrosDocs
	FROM @temp_refantypag WHERE rap_cotped <> 'COTIZACION UNIVERSAL';

	DECLARE @totCoti INT = (SELECT COUNT(ROW) TOTAL FROM #tmpCotiUniversal);
	DECLARE @totOtro INT = (SELECT COUNT(ROW) TOTAL FROM #tmpOtrosDocs);
	DECLARE @refCoti VARCHAR(MAX) = '', @refOtro VARCHAR(MAX) = '';

			
	IF( @totCoti = 0 AND @totOtro = 0 )
		BEGIN
			SET @refCoti = '';
			SET @refOtro = '';
		END
	ELSE IF( @totCoti = 0 AND @totOtro != 0 ) -- Puros de otros documentos
		BEGIN
			SET @refCoti = '';
			SET @refOtro = ( SELECT TOP 1 rap_referenciabancaria FROM @temp_refantypag VARI INNER JOIN #tmpOtrosDocs TMP ON VARI.ID = TMP.ID );
		END
	ELSE IF( @totCoti != 0 AND @totOtro = 0 ) -- Puras de Cotizaciones
		BEGIN
			SET @refCoti = ( SELECT TOP 1 rap_referenciabancaria FROM @temp_refantypag VARI INNER JOIN #tmpCotiUniversal TMP ON VARI.ID = TMP.ID );
			SET @refOtro = '';
		END
	ELSE
		BEGIN
			SET @refCoti = ( SELECT TOP 1 rap_referenciabancaria FROM @temp_refantypag VARI INNER JOIN #tmpCotiUniversal TMP ON VARI.ID = TMP.ID );
			DECLARE @tmp_empresa INT, @tmp_sucursal INT, @tmp_serie VARCHAR(2), @tmp_folio VARCHAR(30)
			SELECT TOP 1 @tmp_empresa = rap_idempresa, @tmp_sucursal = rap_idsucursal, @tmp_serie = SUBSTRING( rap_referencia,1,2 ), @tmp_folio = SUBSTRING( rap_referencia,3,LEN(rap_referencia) ) FROM @temp_refantypag VARI INNER JOIN #tmpOtrosDocs TMP ON VARI.ID = TMP.ID
			SET @refOtro = [dbo].[referencia_fn](@tmp_serie, @tmp_folio, @tmp_sucursal, @tmp_empresa) + [dbo].[digito_verificador_fn]([dbo].[referencia_fn](@tmp_serie, @tmp_folio, @tmp_sucursal, @tmp_empresa)) ;
		END

	DECLARE @Current INT	= 0;
	DECLARE @Max INT		= 0;
	DECLARE @rap_folio INT	= 0;
	DECLARE @idDeposito INT = 0;
	DECLARE @idDetalle INT	= 0;

	SET @idDeposito = (SELECT depositoID FROM Referencia WHERE idReferencia = @idReferencia);

	DECLARE @Revision INT = ( SELECT COUNT(idRAPDeposito) FROM referencias..RAPDeposito WHERE idDeposito = @idDeposito and IDBanco=@idBanco );
	--IF not EXISTS (select rpun_idPunteado from VW_REGISTROS_PUNTEADOS where idbmer=@idDeposito and IDBanco=@idBanco)
	--begin
		IF(@Revision = 0)
			BEGIN
				-- COTIZACIONES
				-- COTIZACIONES
				-- COTIZACIONES
				SELECT @Current = MIN( ROW ), @Max = MAX(ROW) FROM #tmpCotiUniversal;
				WHILE( @Current <= @Max )
					BEGIN
					print 'Cotizaciones'
						SET @idDetalle = ( 
							SELECT dep_detalle 
							FROM @temp_refantypag VARI
							INNER JOIN #tmpCotiUniversal TMP ON VARI.ID = TMP.ID
							WHERE ROW = @Current
						)
					
					
						BEGIN TRY
							INSERT INTO GA_Corporativa.dbo.cxc_refantypag
							SELECT 
								rap_idempresa,
								rap_idsucursal,
								rap_iddepartamento,
								rap_idpersona,
								rap_cobrador,
								rap_moneda,
								rap_tipocambio,
								rap_referencia,
								rap_iddocto,
								rap_cotped,
								rap_consecutivo,
								rap_importe,
								rap_formapago,
								rap_numctabanc,
								rap_fecha,
								rap_idusuari,
								rap_idstatus,
								rap_banco,
								rap_referenciabancaria = @refCoti,
								rap_anno,
								RAP_AplicaPago,
								RAP_NumDeposito
							FROM @temp_refantypag VARI
							INNER JOIN #tmpCotiUniversal TMP ON VARI.ID = TMP.ID
							WHERE ROW = @Current;

							SET @rap_folio = SCOPE_IDENTITY();
						
							INSERT INTO [referencias].[dbo].[RAPDeposito](idEmpresa, idSucursal, rap_folio, idBanco, idDeposito, idOrigenReferencia, fecha, idDetalleReferencia, idUsuario)
							SELECT 
								idEmpresa			= idEmpresa, 
								idSucursal			= idSucursal,
								rap_folio			= @rap_folio,
								idBanco				= IDBanco,
								idDeposito			= depositoID,
								idOrigenReferencia	= 'Control de Depósitos',
								fecha				= GETDATE(),
								idDetalleReferencia = idDetalleReferencia,
								idUsuario			= @idUsuario
							FROM [Referencia] REF
							INNER JOIN [DetalleReferencia] DET ON REF.idReferencia = DET.idReferencia
							WHERE idDetalleReferencia = @idDetalle;

							INSERT INTO  [referencias].dbo.[cxc_refantypag]
									   ([rap_folio]
									   ,[rap_idempresa]
									   ,[rap_idsucursal]
									   ,[rap_iddepartamento]
									   ,[rap_idpersona]
									   ,[rap_cobrador]
									   ,[rap_moneda]
									   ,[rap_tipocambio]
									   ,[rap_referencia]
									   ,[rap_iddocto]
									   ,[rap_cotped]
									   ,[rap_consecutivo]
									   ,[rap_importe]
									   ,[rap_formapago]
									   ,[rap_numctabanc]
									   ,[rap_fecha]
									   ,[rap_idusuari]
									   ,[rap_idstatus]
									   ,[rap_banco]
									   ,[rap_referenciabancaria]
									   ,[rap_anno]
									   ,[RAP_AplicaPago]
									   ,[RAP_NumDeposito])
							SELECT [rap_folio]
									   ,[rap_idempresa]
									   ,[rap_idsucursal]
									   ,[rap_iddepartamento]
									   ,[rap_idpersona]
									   ,[rap_cobrador]
									   ,[rap_moneda]
									   ,[rap_tipocambio]
									   ,[rap_referencia]
									   ,[rap_iddocto]
									   ,[rap_cotped]
									   ,[rap_consecutivo]
									   ,[rap_importe]
									   ,[rap_formapago]
									   ,[rap_numctabanc]
									   ,[rap_fecha]
									   ,[rap_idusuari]
									   ,[rap_idstatus]
									   ,[rap_banco]
									   ,[rap_referenciabancaria]
									   ,[rap_anno]
									   ,[RAP_AplicaPago]
									   ,[RAP_NumDeposito]
							FROM GA_Corporativa.dbo.cxc_refantypag
							WHERE rap_folio= @rap_folio;

							PRINT( 'SUCCESS: idDetalleReferencia ['+ CONVERT(VARCHAR(10), @idDetalle) +']: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
						END TRY
						BEGIN CATCH
					
							INSERT INTO referencias.dbo.LogRAP(log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal, idDetalleReferencia) 
							SELECT 
								log_error			= ERROR_MESSAGE(),
								idOrigenReferencia	= 'Control de Depósitos',
								fecha				= GETDATE(),
								idBanco				= IDBanco,
								idDeposito			= depositoID,
								idEmpresa			= idEmpresa, 
								idSucursal			= idSucursal,
								idDetalleReferencia = idDetalleReferencia
							FROM [Referencia] REF
							INNER JOIN [DetalleReferencia] DET ON REF.idReferencia = DET.idReferencia
							WHERE idDetalleReferencia = @idDetalle;
						
							PRINT( 'ERROR: idDetalleReferencia ['+ CONVERT(VARCHAR(10), @idDetalle) +']: ' + ERROR_MESSAGE() );
						END CATCH
					
						SET @Current = @Current + 1;
					END
				
				-- OTROS
				-- OTROS
				-- OTROS
				SELECT @Current = MIN( ROW ), @Max = MAX(ROW) FROM #tmpOtrosDocs;
				WHILE( @Current <= @Max )
					BEGIN
					print 'otrosdocs'
						SET @idDetalle = ( 
							SELECT dep_detalle 
							FROM @temp_refantypag VARI
							INNER JOIN #tmpOtrosDocs TMP ON VARI.ID = TMP.ID
							WHERE ROW = @Current
						)
					
					
						BEGIN TRY
							INSERT INTO GA_Corporativa.dbo.cxc_refantypag
							SELECT 
								rap_idempresa,
								rap_idsucursal,
								rap_iddepartamento,
								rap_idpersona,
								rap_cobrador,
								rap_moneda,
								rap_tipocambio,
								rap_referencia,
								rap_iddocto,
								rap_cotped,
								rap_consecutivo,
								rap_importe,
								rap_formapago,
								rap_numctabanc,
								rap_fecha,
								rap_idusuari,
								rap_idstatus,
								rap_banco,
								rap_referenciabancaria = @refOtro,
								rap_anno,
								RAP_AplicaPago,
								RAP_NumDeposito
							FROM @temp_refantypag VARI
							INNER JOIN #tmpOtrosDocs TMP ON VARI.ID = TMP.ID
							WHERE ROW = @Current;
						
							SET @rap_folio = SCOPE_IDENTITY();
						
							INSERT INTO [referencias].[dbo].[RAPDeposito](idEmpresa, idSucursal, rap_folio, idBanco, idDeposito, idOrigenReferencia, fecha, idDetalleReferencia, idUsuario)
							SELECT 
								idEmpresa			= idEmpresa, 
								idSucursal			= idSucursal,
								rap_folio			= @rap_folio,
								idBanco				= IDBanco,
								idDeposito			= depositoID,
								idOrigenReferencia	= 'Control de Depósitos',
								fecha				= GETDATE(),
								idDetalleReferencia = idDetalleReferencia,
								idUsuario			= @idUsuario
							FROM [Referencia] REF
							INNER JOIN [DetalleReferencia] DET ON REF.idReferencia = DET.idReferencia
							WHERE idDetalleReferencia = @idDetalle;
						
							INSERT INTO [referencias].dbo.[cxc_refantypag]
									   ([rap_folio]
									   ,[rap_idempresa]
									   ,[rap_idsucursal]
									   ,[rap_iddepartamento]
									   ,[rap_idpersona]
									   ,[rap_cobrador]
									   ,[rap_moneda]
									   ,[rap_tipocambio]
									   ,[rap_referencia]
									   ,[rap_iddocto]
									   ,[rap_cotped]
									   ,[rap_consecutivo]
									   ,[rap_importe]
									   ,[rap_formapago]
									   ,[rap_numctabanc]
									   ,[rap_fecha]
									   ,[rap_idusuari]
									   ,[rap_idstatus]
									   ,[rap_banco]
									   ,[rap_referenciabancaria]
									   ,[rap_anno]
									   ,[RAP_AplicaPago]
									   ,[RAP_NumDeposito])
							SELECT [rap_folio]
									   ,[rap_idempresa]
									   ,[rap_idsucursal]
									   ,[rap_iddepartamento]
									   ,[rap_idpersona]
									   ,[rap_cobrador]
									   ,[rap_moneda]
									   ,[rap_tipocambio]
									   ,[rap_referencia]
									   ,[rap_iddocto]
									   ,[rap_cotped]
									   ,[rap_consecutivo]
									   ,[rap_importe]
									   ,[rap_formapago]
									   ,[rap_numctabanc]
									   ,[rap_fecha]
									   ,[rap_idusuari]
									   ,[rap_idstatus]
									   ,[rap_banco]
									   ,[rap_referenciabancaria]
									   ,[rap_anno]
									   ,[RAP_AplicaPago]
									   ,[RAP_NumDeposito]
							FROM GA_Corporativa.dbo.cxc_refantypag
							WHERE rap_folio= @rap_folio;
							PRINT( 'SUCCESS: idDetalleReferencia ['+ CONVERT(VARCHAR(10), @idDetalle) +']: Inserción exitosa con rap_folio ' + CONVERT(VARCHAR(10), @rap_folio) );
						END TRY
						BEGIN CATCH
					
							INSERT INTO referencias.dbo.LogRAP(log_error, log_origen, log_fecha, idBanco, idDeposito, idEmpresa, idSucursal, idDetalleReferencia) 
							SELECT 
								log_error			= ERROR_MESSAGE(),
								idOrigenReferencia	= 'Control de Depósitos',
								fecha				= GETDATE(),
								idBanco				= IDBanco,
								idDeposito			= depositoID,
								idEmpresa			= idEmpresa, 
								idSucursal			= idSucursal,
								idDetalleReferencia = idDetalleReferencia
							FROM [Referencia] REF
							INNER JOIN [DetalleReferencia] DET ON REF.idReferencia = DET.idReferencia
							WHERE idDetalleReferencia = @idDetalle;
						
							PRINT( 'ERROR: idDetalleReferencia ['+ CONVERT(VARCHAR(10), @idDetalle) +']: ' + ERROR_MESSAGE() );
						END CATCH
					
						SET @Current = @Current + 1;
					END
				--
				--
				--
				
				DECLARE @hechos INT = ( SELECT COUNT(idRAPDeposito) FROM referencias..RAPDeposito WHERE idDeposito = @idDeposito and IDBanco=@idBanco);
				DECLARE @esperados INT = ( SELECT COUNT(dep_detalle) FROM @temp_refantypag );

				PRINT(@idDetalle);
				PRINT(@esperados);

				IF( @hechos = @esperados )
					BEGIN
					
						IF(@idBanco = 1)
							BEGIN
								UPDATE [referencias].[dbo].[Bancomer] SET [referencia] = @Referencia, estatus = 1 WHERE [idBmer] = @idBancoFinal;
							END
						ELSE IF(@idBanco = 2)
							BEGIN
								 UPDATE [referencias].[dbo].[Banamex] SET SLTipoReferencia = @Referencia, estatus = 1 WHERE idBanamex = @idBancoFinal;
							END
						ELSE IF(@idBanco = 3)
							BEGIN
								 UPDATE [referencias].[dbo].[Santander] SET concepto = @Referencia, estatus = 1 WHERE [idSantander] = @idBancoFinal;
							END

						INSERT INTO [referencias].[dbo].Referencia
						SELECT 
							   [idEmpresa]
							  ,[fecha]
							  ,[referencia]
							  ,[tipoReferencia]
							  ,[numeroConsecutivo]
							  ,[estatus]
						FROM [Referencia]
						WHERE [idReferencia] = @idReferencia

						SET @idReferencianNueva = SCOPE_IDENTITY()

						INSERT INTO [referencias].[dbo].[DetalleReferencia]
						SELECT 
							   [idSucursal]
							  ,[idDepartamento]
							  ,[idTipoDocumento]
							  ,[importeDocumento]
							  ,[documento]
							  ,[idCliente]
							  ,[idAlmacen]
							  ,@idReferencianNueva
						FROM [DetalleReferencia]
						WHERE [idReferencia] = @idReferencia

						UPDATE [Referencia] SET [estatus] = 2 WHERE [idReferencia] = @idReferencia;
					
						SELECT idEstatus = 1, descripcion = 'Se ha procesado correctamente su petición';
					END
				ELSE
					BEGIN
						DELETE FROM GA_Corporativa..cxc_refantypag WHERE rap_folio IN ( SELECT rap_folio FROM referencias..RAPDeposito WHERE idDeposito = @idDeposito and IDBanco=@idBanco);
						DELETE FROM referencias..RAPDeposito WHERE idDeposito = @idDeposito and IDBanco=@idBanco;
						SELECT idEstatus = 0, descripcion = 'Ocurrio un problema favor de ponerse en contacto con su administrador de la aplicación';
					END
			END --/ END IF EXISTS
		ELSE
			BEGIN
				SELECT idEstatus = 0, descripcion = 'El deposito en cuestión ya ha sido procesado con anterioridad';	
			END
	--End
	--ELSE'El deposito en cuestión ya ha sido procesado en Tesoreria con anterioridad';	
	--		END
	DROP TABLE #tmpCotiUniversal;
	DROP TABLE #tmpOtrosDocs;
	--		BEGIN
	--			SELECT idEstatus = 0, descripcion = 
	Declare @idbmer bigint,@idabonobanco  int,@rpun_grupoPunteo int, @RC int

	select @idbmer=depositoID,@idBanco=isnull(idbanco,0) from   Referencia where idReferencia=@idReferencia
	select @idabonobanco=IDABONOSBANCOS from ABONOSBANCOS_CB where idbmer=@idbmer and idbanco= @idBanco
	select @rpun_grupoPunteo=rpun_grupoPunteo from REGISTROS_PUNTEADOS where rpun_idAbono=@idabonobanco and rpun_tipo='B' and rpun_idAplicado=3
	end
	
	/*
    if @rpun_grupoPunteo is not null
	begin
	EXECUTE @RC = [dbo].[CancelarDPI_INS] @rpun_grupoPunteo

	end
    */
END
go

