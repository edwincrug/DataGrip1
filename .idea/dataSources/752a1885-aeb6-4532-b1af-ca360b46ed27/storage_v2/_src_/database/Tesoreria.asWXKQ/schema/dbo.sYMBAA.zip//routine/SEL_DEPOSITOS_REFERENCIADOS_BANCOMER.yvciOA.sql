-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date, 2017-11-27>
-- Description:	
-- =============================================
--EXECUTE [dbo].[SEL_DEPOSITOS_REFERENCIADOS_BANCOMER] 1, 1, '000000000195334667', '2018-01-01', '2018-01-15', 1
CREATE PROCEDURE [dbo].[SEL_DEPOSITOS_REFERENCIADOS_BANCOMER] 
	@idBanco INT,
	@idEstatus INT,
	@noCuenta VARCHAR(50),
	@fechaElaboracion VARCHAR(30),
	@fechaCorte	VARCHAR(30),
	@idEmpresa INT
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--LQMA add parametro que indica que campo tomar para comparar contra auxiliar
	DECLARE @campoReferenciaAuxiliar INT = 1 --1:concepto, 2: referencia, 3: refAmpliada

   SELECT 
	   banco.[idBanco], 
	   banco.[idBmer], 
	   UPPER(RTRIM(banco.[banco])) as banco, 
	   banco.[txtOrigen], 
	   banco.[noCuenta], 
	   banco.[concepto], 
	   banco.[esCargo], 
	   banco.[importe] as abono,
	   0 as cargo, 
	   banco.[saldoOperativo], 
	   banco.[referencia], 
	   CONVERT(VARCHAR(24),banco.[fechaOperacion],120) as fechaOperacion,
	   banco.[horaOperacion], 
	   banco.[oficinaOperadora],  
	   banco.[refAmpliada]
	   ,CASE 
					WHEN banco.[fechaOperacion] < @fechaElaboracion --BETWEEN '20170503' AND '20170508'
					THEN 1
					ELSE 0
					END fechaAnterior
	   ,'' color
	   , CASE @campoReferenciaAuxiliar 
				WHEN 1 THEN banco.[concepto]
				WHEN 2 THEN banco.[referencia]
				WHEN 3 THEN banco.[refAmpliada]
		END referenciaAuxiliar --LQMA add parametro que indica que campo tomar para comparar contra auxiliar			
	 FROM [DepositoBancoView] banco
	 LEFT JOIN [PunteoAuxiliarBanco] puntAux
	 ON banco.idBmer = puntAux.idDepositoBanco
	 AND puntAux.idBanco = @idBanco
	 AND puntAux.idEmpresa = @idEmpresa
	 LEFT JOIN [DepositoBancarioDPI] depDpi
	 ON banco.idBmer = depDpi.idAbonoBanco
	 AND depDpi.idBanco = @idBanco
	 AND depDpi.idEmpresa = @idEmpresa
	 LEFT JOIN [referencias].[dbo].[RAPDeposito] rapDep
	 ON banco.idBanco = rapDep.idDeposito
	 AND rapDep.idBanco = @idBanco
	 AND rapDep.idEmpresa = @idEmpresa
	 LEFT JOIN Referencia ref
	 ON banco.idBmer = ref.depositoID
	 AND ref.IDBanco = @idBanco
	 AND ref.idEmpresa = @idEmpresa
	 LEFT JOIN GA_Corporativa.DBO.cxc_refantypag refPag
	 ON refPag.rap_referenciabancaria = SUBSTRING(banco.concepto,3,20)
	 AND refPag.rap_idempresa = @idEmpresa
	 WHERE banco.idBanco = @idBanco and [esCargo] = 0 
		   AND banco.noCuenta = @noCuenta 
		   AND banco.fechaOperacion BETWEEN @fechaElaboracion and @fechaCorte 
		   AND puntAux.idBanco IS NULL
		   AND depDpi.idAbonoBanco IS NULL
		   AND rapDep.idDeposito IS NULL
		   AND ref.depositoID IS NULL
		   AND refPag.rap_referenciabancaria IS NULL

	 UNION

	  SELECT 
	   banco.[idBanco], 
	   banco.[idBmer], 
	   UPPER(RTRIM(banco.[banco])) as banco, 
	   banco.[txtOrigen], 
	   banco.[noCuenta], 
	   banco.[concepto], 
	   banco.[esCargo], 
	   0 as abono,
	   banco.[importe] as cargo, 
	   banco.[saldoOperativo], 
	   banco.[referencia],  
	   CONVERT(VARCHAR(24),banco.[fechaOperacion],120) as fechaOperacion,
	   banco.[horaOperacion], 
	   banco.[oficinaOperadora],  
	   banco.[refAmpliada]
	   ,CASE 
					WHEN banco.[fechaOperacion] < @fechaElaboracion --BETWEEN '20170503' AND '20170508'
					THEN 1
					ELSE 0
					END fechaAnterior
	   ,'' color	
	   , CASE @campoReferenciaAuxiliar 
				WHEN 1 THEN banco.[concepto]
				WHEN 2 THEN banco.[referencia]
				WHEN 3 THEN banco.[refAmpliada]
		END referenciaAuxiliar --LQMA add parametro que indica que campo tomar para comparar contra auxiliar
	 FROM [DepositoBancoView] banco
	 LEFT JOIN [PunteoAuxiliarBanco] punteoAux
	 ON banco.idBmer = punteoAux.idDepositoBanco
	 LEFT JOIN [dbo].[Retorna_Comision_Interes] (
																					@idBanco
																					,@idEmpresa
																					,@noCuenta
																					,@fechaElaboracion
																					,@fechaCorte) intComision
     ON banco.idBmer = intComision.idbmer
	 WHERE banco.idBanco = @idBanco 
	       AND banco.[esCargo] = 1
		   AND banco.idBanco = @idBanco  
		   AND banco.noCuenta = @noCuenta 
		   AND banco.fechaOperacion >= '2017-11-01'
		   AND banco.fechaOperacion BETWEEN @fechaElaboracion and @fechaCorte 
		   AND punteoAux.idDepositoBanco IS NULL
		   AND intComision.idbmer IS NULL

	 ORDER BY CONVERT(VARCHAR(24),banco.[fechaOperacion],120) DESC
END TRY
BEGIN CATCH
       SELECT ERROR_LINE() + '' + ERROR_MESSAGE() as ERROR
END CATCH
go

