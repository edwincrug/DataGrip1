-- =============================================
-- Author: Roberto Almanza
-- Create date:
-- Description:
-- exec [OBTIENE_CATMETODO_PAGO_SP] 4,6
-- =============================================
CREATE PROCEDURE [dbo].[OBTIENE_CATMETODO_PAGO_SP]
-- Add the parameters for the stored procedure here
@idEmpresa int,
@idSucursal int
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
DECLARE @query NVARCHAR(MAX) = ''
,@bd VARCHAR(20)=''
SET @bd =(SELECT DISTINCT nombre_base
FROM [ControlAplicaciones].[dbo].[cat_empresas] contrApp
INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] centBases
ON contrApp.emp_idempresa = centBases.emp_idempresa
--and centBases.sucursal_matriz >0
WHERE contrApp.emp_idempresa !=0
--AND centBases.tipo = 2
--and nombre_base_matriz is not NULL
    AND contrApp.emp_idempresa = @idEmpresa
and  suc_idsucursal = @idSucursal)
SET @query = (

' Select par_idenpara + ''|'' + case when par_descrip2 <> ''BANCO'' then ''N'' else ''B'' end AS valor , UPPER(par_descrip1) AS descripcion from '+@bd+
'.dbo.PNC_PARAMETR WHERE PAR_TIPOPARA = ''FP'' AND PAR_STATUS = ''A'' AND par_idenpara IN (''01'',''39'',''38'') order by par_descrip1 '
)
PRINT @query
EXECUTE sp_executesql @QUERY
END
go

exec sp_addextendedproperty 'MS_Description', 'Catálogos de los metodos de pago para la generacion de anticipos',
     'SCHEMA', 'dbo', 'PROCEDURE', 'OBTIENE_CATMETODO_PAGO_SP'
go

exec sp_addextendedproperty 'MS_Description', 'id de la empresa', 'SCHEMA', 'dbo', 'PROCEDURE',
     'OBTIENE_CATMETODO_PAGO_SP', 'PARAMETER', '@idEmpresa'
go

exec sp_addextendedproperty 'MS_Description', 'id de la sucursal', 'SCHEMA', 'dbo', 'PROCEDURE',
     'OBTIENE_CATMETODO_PAGO_SP', 'PARAMETER', '@idSucursal'
go

