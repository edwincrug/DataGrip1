
--EXECUTE [dbo].[SEL_GERENTE_CONTADOR_SP] 71, 1
CREATE PROCEDURE [dbo].[SEL_GERENTE_CONTADOR_SP]
@idUsuario INT,
@idEmpresa INT
AS
BEGIN
    SELECT  
	 (USU.usu_nombre + ' '+ USU.usu_paterno + ' ' + USU.usu_materno) AS Usuario
	,ISNULL((SELECT USU.usu_nombre + ' '+ USU.usu_paterno + ' ' + USU.usu_materno 
			 FROM ControlAplicaciones.dbo.cat_usuarios USU
			 WHERE 
			 USU.usu_idusuario = 82
			 ),'INDEFINIDO') as NombreGerente
	,ISNULL((SELECT USU.usu_nombre + ' '+ USU.usu_paterno + ' ' + USU.usu_materno 
			 FROM ControlAplicaciones.dbo.cat_usuarios USU
			 WHERE 
			 USU.usu_idusuario = 437
			 ),'INDEFINIDO') as NombreContador
  FROM ControlAplicaciones.dbo.cat_usuarios USU 
  WHERE USU.usu_idusuario = @idUsuario --(SELECT Usuario FROM Usuarios
							 --WHERE IdUsuario = @idUsuario)


END



go

