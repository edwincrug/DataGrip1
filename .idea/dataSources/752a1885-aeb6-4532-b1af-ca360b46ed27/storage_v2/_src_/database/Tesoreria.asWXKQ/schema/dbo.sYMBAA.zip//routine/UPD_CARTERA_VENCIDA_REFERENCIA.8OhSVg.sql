CREATE procedure [dbo].[UPD_CARTERA_VENCIDA_REFERENCIA]
@idReferencia as int
as
begin


		update carteravencida 
		set idstatus=2 , 
		referencia =@idReferencia 

		where folio  in
		(
			select documento 
			from detalleReferencia 
			where idreferencia = @idReferencia
		)

end
go

