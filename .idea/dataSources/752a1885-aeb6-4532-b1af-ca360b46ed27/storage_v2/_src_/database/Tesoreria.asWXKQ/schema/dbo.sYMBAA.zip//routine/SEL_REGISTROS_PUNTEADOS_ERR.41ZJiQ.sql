-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <02/08/2018>
-- Description:	<Sel registros punteados con error>
-- =============================================
-- [dbo].[SEL_REGISTROS_PUNTEADOS_ERR] 4,1,'000000000190701289'
CREATE PROCEDURE [dbo].[SEL_REGISTROS_PUNTEADOS_ERR]
    @idEmpresa INT = '',
    @idBanco INT = 0,
    @noCuenta VARCHAR(50) = ''
AS
BEGIN	

	DECLARE @cuentaContable VARCHAR(20);
	SELECT @cuentaContable = cuentaContable FROM referencias.dbo.BancoCuenta WHERE numeroCuenta = @noCuenta;

	DECLARE @mec_idMes INT;
	SELECT @mec_idMes = mec_idMes FROM PeriodoActivo WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @noCuenta AND mec_conciliado = 0
	PRINT @mec_idMes
    SELECT [rpun_idPunteado]
        ,vw.[rpun_grupoPunteo]
        ,[rpun_idCargo]
        ,[rpun_idAbono]
        ,[rpun_tipo]
        ,[concepto]
        ,[rpun_fechaPunteo]
        ,[rpun_usuario]
        ,[rpun_idAplicado]
        ,vw.[idEmpresa]
        ,vw.[IDBanco]
        ,[noCuenta]
        ,vw.[cargos]
        ,vw.[abonos]
        ,[mes]
        ,[anio]
        ,[idbmer]
        ,[idMes]
		,sm.cargos totalcargos
		,sm.abonos totalabonos
		,case when sm.cargos>sm.abonos then 'Se ha cobrado de mas' else 'Se ha pagado de mas' end  motivo
		,sm.tipo
    FROM [dbo].[VW_REGISTROS_PUNTEADOS_ERR] vw
	inner join (select rpun_grupoPunteo,idempresa,idbanco,sum(cargos) cargos,sum(abonos) abonos,Max(case when idbmer>0 and cargos>0  then 'Pagos' when idbmer>0 and abonos>0 then 'Cobros' end) tipo from [dbo].[VW_REGISTROS_PUNTEADOS_ERR] group by rpun_grupoPunteo,idempresa,idbanco) sm on vw.rpun_grupoPunteo=sm.rpun_grupoPunteo and vw.idEmpresa=sm.idempresa and vw.idbanco=sm.idbanco
    WHERE vw.rpun_grupoPunteo IN ( SELECT rpun_grupoPunteo 
                                FROM [dbo].[VW_REGISTROS_PUNTEADOS_ERR] 
                                WHERE   idEmpresa = @idEmpresa 
                                        AND idBanco = @idBanco 
                                        AND noCuenta IN (@noCuenta, @cuentaContable)
		  AND idMes = @mec_idMes)
    ORDER BY vw.rpun_grupoPunteo
END
go

