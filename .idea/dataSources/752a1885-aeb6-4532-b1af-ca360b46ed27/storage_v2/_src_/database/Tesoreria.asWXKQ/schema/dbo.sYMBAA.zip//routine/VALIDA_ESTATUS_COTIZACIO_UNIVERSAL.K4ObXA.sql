-- =============================================
-- Author: Roberto Almanza
-- Create date: 26-02-2020
-- Description: valida la existencia de la cotizacion universal y su estatus
-- =============================================
CREATE PROCEDURE dbo.VALIDA_ESTATUS_COTIZACIO_UNIVERSAL
-- Add the parameters for the stored procedure here
@cotizacion varchar(20)
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
    -- Insert statements for procedure here
IF EXISTS(
    SELECT 1
    FROM cuentasporcobrar..uni_cotizacionuniversal uc
    WHERE uc.ucu_foliocotizacion = @cotizacion
    AND uc.cec_idestatuscotiza NOT IN (14,20)
) BEGIN
   
    SELECT estatus = 1, cliente = pp.PER_NOMRAZON+' '+isnull(pp.PER_PATERNO,'')+' '+isnull(pp.PER_MATERNO,'')
    FROM cuentasporcobrar..uni_cotizacionuniversal uc
JOIN GA_Corporativa..PER_PERSONAS pp
ON uc.ucu_idcliente = pp.PER_IDPERSONA
WHERE uc.ucu_foliocotizacion = @cotizacion
AND uc.cec_idestatuscotiza NOT IN (14,20)
   
END
ELSE
BEGIN
IF NOT EXISTS(
    SELECT 1
    FROM cuentasporcobrar..uni_cotizacionuniversal uc
WHERE uc.ucu_foliocotizacion = @cotizacion
) BEGIN
SELECT estatus = 0, 'La cotización no es valida' as mensaje
end
else
begin
SELECT estatus = 0, 'la cotización se encuentra en estatus: '+ ce.cec_descripcion as mensaje
    FROM cuentasporcobrar..uni_cotizacionuniversal uc
join cuentasporcobrar..cat_estatuscotiza ce
on uc.cec_idestatuscotiza = ce.cec_idestatuscotiza
WHERE uc.ucu_foliocotizacion = @cotizacion
end
END
END
go

exec sp_addextendedproperty 'MS_Description', 'alida la existencia de la cotizacion universal y su estatus', 'SCHEMA',
     'dbo', 'PROCEDURE', 'VALIDA_ESTATUS_COTIZACIO_UNIVERSAL'
go

