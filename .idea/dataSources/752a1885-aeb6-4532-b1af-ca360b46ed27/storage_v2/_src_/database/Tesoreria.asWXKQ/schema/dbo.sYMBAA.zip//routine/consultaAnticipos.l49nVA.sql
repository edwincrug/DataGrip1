-- =============================================
-- Author:		Roberto Almanza Nieto
-- Create date: 23-03-2020
-- Description:	Consulta de anticipos generados automaticamente por BPRO
-- =============================================
create PROCEDURE [dbo].[consultaAnticipos]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT ca.caa_idanticiposautomaticos AS id
  ,ca.caa_idpersona AS idCliente
  ,pp.PER_NOMRAZON+' '+pp.PER_PATERNO+' '+pp.PER_MATERNO AS nombre
  ,ca.caa_idempresa AS idEmpresa
  ,ce.emp_nombre AS nombreEmpresa
  ,CONVERT(VARCHAR(10),ca.caa_fechasolicita,103) AS fechaSolicita
  ,CONVERT(VARCHAR(10),ca.caa_fechaproceso,103) AS fechaProceso
  ,CASE ca.caa_estatus
   	WHEN 0 THEN 'En proceso'
   	WHEN 1 THEN 'Realizado'
   	-- ELSE
   END AS estatus
  , ISNULL(ca.caa_cotizacionuniversal,'') AS cotizacionUniversal
  , ca.caa_anticipogenerado AS mkGenerado
  FROM GA_Corporativa..cxc_anticiposautomaticos ca
  JOIN GA_Corporativa..PER_PERSONAS pp
  ON CA.caa_idpersona = PP.PER_IDPERSONA
  JOIN ControlAplicaciones..cat_empresas ce
  ON ca.caa_idempresa = ce.emp_idempresa

END
go

