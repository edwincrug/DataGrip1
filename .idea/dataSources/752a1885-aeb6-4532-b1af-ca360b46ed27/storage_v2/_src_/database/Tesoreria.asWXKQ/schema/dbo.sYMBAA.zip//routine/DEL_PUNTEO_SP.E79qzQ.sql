-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-05-17
-- Description:	Eliminar los registros punteados
-- =============================================
CREATE PROCEDURE [dbo].[DEL_PUNTEO_SP]
	@grupo INT = 0
	,@idusuario int
AS
BEGIN

INSERT INTO [dbo].[REGISTROS_PUNTEADOS_CAN]
           ([rpun_grupoPunteo]
           ,[rpun_idCargo]
           ,[rpun_idAbono]
           ,[rpun_tipo]
           ,[rpun_fechaPunteo]
           ,[rpun_usuario]
           ,[rpun_idAplicado]
           ,[idMes]
           ,[rpun_usuarioCancela]
           ,[rpun_observacion]
           ,[rpun_fechaCancela])
SELECT [rpun_grupoPunteo]
      ,[rpun_idCargo]
      ,[rpun_idAbono]
      ,[rpun_tipo]
      ,[rpun_fechaPunteo]
      ,[rpun_usuario]
      ,[rpun_idAplicado]
      ,[idMes]
	  ,@idusuario
	  ,''
	  ,getdate()
  FROM [dbo].[REGISTROS_PUNTEADOS]
where [rpun_grupoPunteo]=@grupo



	DELETE FROM [REGISTROS_PUNTEADOS]  WHERE rpun_grupoPunteo = @grupo;
	SELECT success = 1, msg = 'Se han eliminado los registros punteados del grupo '+ CONVERT(VARCHAR(10),@grupo) +'.'
END
go

