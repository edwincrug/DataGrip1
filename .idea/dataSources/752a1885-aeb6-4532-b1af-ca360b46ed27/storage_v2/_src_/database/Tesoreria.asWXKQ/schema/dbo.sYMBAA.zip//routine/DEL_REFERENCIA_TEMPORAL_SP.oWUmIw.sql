-- [DEL_REFERENCIA_TEMPORAL_SP] 48
CREATE PROCEDURE [dbo].[DEL_REFERENCIA_TEMPORAL_SP]
	@idReferencia INT
AS
BEGIN
	DELETE FROM DetalleReferencia WHERE idReferencia = @idReferencia;
	DELETE FROM Referencia WHERE idReferencia = @idReferencia;
	SELECT 1 AS success;
END
go

