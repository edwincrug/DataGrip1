-- =============================================
-- Author: Roberto Almanza
-- Create date:
-- Description:
-- EXEC [OBTIENE_CATCONCEPTOS_SP] 4, 6
-- =============================================
CREATE PROCEDURE dbo.OBTIENE_CATCONCEPTOS_SP
-- Add the parameters for the stored procedure here
@idEmpresa int,
@idSucursal int
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
DECLARE @query NVARCHAR(MAX) = ''
  ,@bd VARCHAR(20)=''
    -- Insert statements for procedure here
SET @bd =(SELECT DISTINCT nombre_base
FROM [ControlAplicaciones].[dbo].[cat_empresas] contrApp
INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] centBases
ON contrApp.emp_idempresa = centBases.emp_idempresa
--and centBases.sucursal_matriz >0
WHERE contrApp.emp_idempresa !=0
--AND centBases.tipo = 2
--and nombre_base_matriz is not NULL
    AND contrApp.emp_idempresa = @idEmpresa
and  suc_idsucursal = @idSucursal)
SET @query = (
' Select par_idenpara +''|''+ CASE WHEN LEN(PAR_FECHA1) = 0 THEN ''F'' ELSE ''N'' END AS valor , par_descrip1 AS descripcion from '+@bd+
'.dbo.PNC_PARAMETR where PAR_IDMODULO = ''CON'' AND PAR_TIPOPARA = ''COCOCXC'' AND PAR_IMPORTE1 = 1 AND PAR_IMPORTE4 = 0 AND PAR_IMPORTE5 > 0 UNION ALL Select par_idenpara +''|''+ CASE WHEN LEN(PAR_FECHA1) = 0 THEN ''F'' ELSE ''N'' END AS valor , par_descrip1 AS descripcion from '+@bd+
'.dbo.PNC_PARAMETR where PAR_IDMODULO = ''CON'' AND PAR_TIPOPARA = ''COCOCXC'' AND PAR_IMPORTE1 = 1 AND PAR_IMPORTE4 = 1.1 AND PAR_IMPORTE5 = 1.1 '
)
PRINT @query
EXECUTE sp_executesql @QUERY
END
go

exec sp_addextendedproperty 'MS_Description', 'Catálogo de conceptos para la generación de anticipos', 'SCHEMA', 'dbo',
     'PROCEDURE', 'OBTIENE_CATCONCEPTOS_SP'
go

exec sp_addextendedproperty 'MS_Description', 'id de la empresa', 'SCHEMA', 'dbo', 'PROCEDURE',
     'OBTIENE_CATCONCEPTOS_SP', 'PARAMETER', '@idEmpresa'
go

exec sp_addextendedproperty 'MS_Description', 'id de la sucursal', 'SCHEMA', 'dbo', 'PROCEDURE',
     'OBTIENE_CATCONCEPTOS_SP', 'PARAMETER', '@idSucursal'
go

