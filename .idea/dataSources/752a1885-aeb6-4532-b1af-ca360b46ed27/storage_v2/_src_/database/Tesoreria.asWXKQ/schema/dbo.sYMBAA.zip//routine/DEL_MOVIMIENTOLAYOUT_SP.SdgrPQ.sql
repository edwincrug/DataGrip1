-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-07-06
-- Description:	Se borraran los registros cuando al menos uno de todo el layout tenga un error
-- =============================================
CREATE PROCEDURE [dbo].[DEL_MOVIMIENTOLAYOUT_SP]
	@idGrupoIns INT = 0
AS
BEGIN
	DELETE FROM referencias.dbo.MovimientoBancarioLayout WHERE idGrupoIns = @idGrupoIns;
	SELECT success = 1, msg = 'Se han eliminado correctamente.'
END
go

