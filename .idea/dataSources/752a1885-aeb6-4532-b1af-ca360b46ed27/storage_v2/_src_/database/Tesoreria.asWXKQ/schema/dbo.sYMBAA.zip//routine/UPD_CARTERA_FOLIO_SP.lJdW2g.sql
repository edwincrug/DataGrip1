-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-09-20
-- Description:	Actualiza la serie y fondo de los que no son documentos fiscales
-- =============================================
CREATE PROCEDURE [dbo].[UPD_CARTERA_FOLIO_SP]
	@idCliente INT = 0,
	@idEmpresaActual INT = 0
AS
BEGIN
	SELECT
		ROW_NUMBER() OVER(ORDER BY suc_idsucursal ASC) AS Row,
		'UPDATE
			CV
		SET 
			serie = '''',
			idDocumento = ''''
		FROM CarteraVencida CV 
		LEFT JOIN [' + ip_servidor + '].['+ nombre_base +'].[dbo].[BI_CARTERA_CLIENTES] CAR ON CV.folio = CAR.CCP_IDDOCTO COLLATE SQL_Latin1_General_CP1_CI_AS
		WHERE idCliente = '+ CONVERT(NVARCHAR(10), @idCliente) +' AND idSucursal = '+ CONVERT( NVARCHAR(5), suc_idsucursal) +' AND CCP_ORIGENCON = ''CON''' Query
	INTO #QUERY
	FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresaActual AND tipo = 1

	DECLARE @Current INT = 1,
			@Max INT = (SELECT MAX(Row) FROM #QUERY),
			@Query NVARCHAR(MAX) = '';

	WHILE( @Current <= @Max )
		BEGIN
			SET @Query = (SELECT Query FROM #QUERY WHERE Row = @Current);
			EXECUTE(@Query);

			SET @Current = @Current + 1;
		END

	DROP TABLE #QUERY;
END

go

