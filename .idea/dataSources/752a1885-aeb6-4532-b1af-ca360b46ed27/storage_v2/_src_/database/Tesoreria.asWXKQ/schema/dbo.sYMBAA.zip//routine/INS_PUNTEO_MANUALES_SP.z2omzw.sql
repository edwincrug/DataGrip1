-- =============================================
-- Author:		
-- Create date: 2018-05-17
-- Description:	SP que se dedica a insertar los registros que fueron punteados manualmente
-- =============================================
CREATE PROCEDURE [dbo].[INS_PUNTEO_MANUALES_SP](
	@grupoPunteo INT	= NULL,
	@idCargo INT		= NULL,
	@idAbono INT		= NULL,
	@tipo VARCHAR(10)	= NULL,
	@idUsuario INT		= NULL,
	@idMes INT			= 0
)
AS
BEGIN
	BEGIN TRY
		IF(@grupoPunteo IS NULL OR @idCargo IS NULL OR @idAbono IS NULL OR @tipo IS NULL OR @idUsuario IS NULL)
			BEGIN
				SELECT succes = 0, msg = 'Favor de introducir todos los datos necesarios.';
			END
		ELSE
			BEGIN
				IF( @grupoPunteo = 0 )
					BEGIN
					
						SELECT 
							@grupoPunteo = CASE WHEN MAX(rpun_grupoPunteo) IS NULL THEN 1 
								 ELSE ( MAX(rpun_grupoPunteo) + 1 ) 
							END 
						FROM [REGISTROS_PUNTEADOS]
					END

				INSERT INTO [REGISTROS_PUNTEADOS] (
					rpun_grupoPunteo,
					rpun_idCargo,
					rpun_idAbono,
					rpun_tipo,
					rpun_fechaPunteo,
					rpun_usuario,
					rpun_idAplicado,
					idMes
				)
				SELECT [rpun_grupoPunteo]	= @grupoPunteo,
						[rpun_idCargo]		= @idCargo,
						[rpun_idAbono]		= @idAbono,
						[rpun_tipo]			= @tipo,
						[rpun_fechaPunteo]	= GETDATE(),
						[rpun_usuario]		= @idUsuario,
						[rpun_idAplicado]	= 0,
						[idMes]				= @idMes

				SELECT success = 1, LastId = @@IDENTITY, grupoPunteo = @grupoPunteo;
			END
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE() + ' in line ' + ERROR_LINE();
	END CATCH
END
go

