CREATE PROCEDURE [dbo].[SEL_CUENTA_CONTABLE_SP]  @idCuentacontable as int as begin select  * from Cuentacontable end
go

