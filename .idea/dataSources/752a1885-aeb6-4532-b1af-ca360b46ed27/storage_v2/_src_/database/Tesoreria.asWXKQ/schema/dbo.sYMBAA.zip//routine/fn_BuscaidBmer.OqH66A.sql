CREATE FUNCTION [dbo].[fn_BuscaidBmer] (@idBanco int) 
RETURNS int 
AS 
BEGIN 


DECLARE @idBmer AS INT
--SELECT top 10  * FROM referencias.dbo.bancomer;
-- de hecho, no usaremos cursores.
DECLARE @n1 INT;
DECLARE @nn INT;
DECLARE @i INT;
Declare @temp TABLE(
		id INT
		);
if(@idBanco=1)
Begin
		-- conseguir el primer y el ultimo numero de la secuencia
		SET @n1 = (SELECT top 1 idbmer FROM referencias.dbo.bancomer ORDER BY idbmer ASC);
		SET @nn = (SELECT top 1 idbmer FROM referencias.dbo.bancomer ORDER BY idbmer DESC);
		-- crear una tabla temporal para la lista de identificadores generados interpolando el n1 y nn.
		
--		print 'iniciar tabla id '+CONVERT(nvarchar(50), getdate(), 121);
	
		SET @i = @n1;
		while @i <= @nn
		BEGIN
		INSERT INTO @temp VALUES (@i);
		SET @i = @i + 1;
		END
--		print 'fin tabla id '+CONVERT(nvarchar(50), getdate(), 121);
		-- conseguir los ids huecos
		SELECT top 1 @idBmer=  id FROM @temp
		WHERE NOT EXISTS(SELECT idbmer FROM referencias.dbo.bancomer WHERE idbmer = id)   
		and not exists(select idbmer from ABONOSBANCOS_CB WHERE idbmer = id union all select idbmer from cargosBANCOS_CB WHERE idbmer = id) 
		and id > 4530
		order by id ---- not in (select id from #_series);
End
else if(@idBanco= 3)
BEGIN
	SET @n1 = (SELECT top 1 idSantander FROM referencias.dbo.santander ORDER BY idSantander ASC);
	SET @nn = (SELECT top 1 idSantander FROM referencias.dbo.santander ORDER BY idSantander DESC);
	-- crear una tabla temporal para la lista de identificadores generados interpolando el n1 y nn.
--	
--	print 'iniciar tabla id '+CONVERT(nvarchar(50), getdate(), 121);

	SET @i = @n1;
	while @i <= @nn
	BEGIN
	INSERT INTO @temp VALUES (@i);
	SET @i = @i + 1;
	END
--	print 'fin tabla id '+CONVERT(nvarchar(50), getdate(), 121);
	-- conseguir los ids huecos
	SELECT top 1 @idBmer=  id FROM @temp
	WHERE NOT EXISTS(SELECT idSantander  FROM referencias.dbo.santander WHERE idSantander = id)   
	and not exists(select idbmer from ABONOSBANCOS_CB WHERE idbmer = id union all select idbmer from cargosBANCOS_CB WHERE idbmer = id) 
	
	order by id ---- not in (select id from #_series);
END
else if(@idBanco= 3)
BEGIN
	SET @n1 = (SELECT top 1 idSantander FROM referencias.dbo.santander ORDER BY idSantander ASC);
	SET @nn = (SELECT top 1 idSantander FROM referencias.dbo.santander ORDER BY idSantander DESC);
	-- crear una tabla temporal para la lista de identificadores generados interpolando el n1 y nn.
--	
--	print 'iniciar tabla id '+CONVERT(nvarchar(50), getdate(), 121);

	SET @i = @n1;
	while @i <= @nn
	BEGIN
	INSERT INTO @temp VALUES (@i);
	SET @i = @i + 1;
	END
--	print 'fin tabla id '+CONVERT(nvarchar(50), getdate(), 121);
	-- conseguir los ids huecos
	SELECT top 1 @idBmer=  id FROM @temp
	WHERE NOT EXISTS(SELECT idSantander  FROM referencias.dbo.santander WHERE idSantander = id)   
	and not exists(select idbmer from ABONOSBANCOS_CB WHERE idbmer = id union all select idbmer from cargosBANCOS_CB WHERE idbmer = id) 
	
	order by id ---- not in (select id from #_series);
END
else if(@idBanco= 5)
BEGIN
	SET @n1 = (SELECT top 1 idbmer FROM ABONOSBANCOS_CB where idbanco=5 ORDER BY idbmer ASC);
	SET @nn = (SELECT top 1 idbmer FROM ABONOSBANCOS_CB where idbanco=5 ORDER BY idbmer DESC);
	-- crear una tabla temporal para la lista de identificadores generados interpolando el n1 y nn.
--	
--	print 'iniciar tabla id '+CONVERT(nvarchar(50), getdate(), 121);

	SET @i = @n1;
	while @i <= @nn
	BEGIN
	INSERT INTO @temp VALUES (@i);
	SET @i = @i + 1;
	END
--	print 'fin tabla id '+CONVERT(nvarchar(50), getdate(), 121);
	-- conseguir los ids huecos
	SELECT top 1 @idBmer=  id FROM @temp
	WHERE NOT EXISTS(SELECT idbmer FROM ABONOSBANCOS_CB where idbanco=5 and idbmer = id)   
	and not exists(select idbmer from ABONOSBANCOS_CB WHERE idbmer = id union all select idbmer from cargosBANCOS_CB WHERE idbmer = id) 
	
	order by id ---- not in (select id from #_series);
END
else if(@idBanco= 8)
BEGIN
	SET @n1 = (SELECT top 1 idbmer FROM ABONOSBANCOS_CB where idbanco=8 ORDER BY idbmer ASC);
	SET @nn = (SELECT top 1 idbmer FROM ABONOSBANCOS_CB where idbanco=8 ORDER BY idbmer DESC);
	-- crear una tabla temporal para la lista de identificadores generados interpolando el n1 y nn.
--	
--	print 'iniciar tabla id '+CONVERT(nvarchar(50), getdate(), 121);

	SET @i = @n1;
	while @i <= @nn
	BEGIN
	INSERT INTO @temp VALUES (@i);
	SET @i = @i + 1;
	END
--	print 'fin tabla id '+CONVERT(nvarchar(50), getdate(), 121);
	-- conseguir los ids huecos
	SELECT top 1 @idBmer=  id FROM @temp
	WHERE NOT EXISTS(SELECT idbmer FROM ABONOSBANCOS_CB where idbanco=8 and idbmer = id)   
	and not exists(select idbmer from ABONOSBANCOS_CB WHERE idbmer = id union all select idbmer from cargosBANCOS_CB WHERE idbmer = id) 
	
	order by id ---- not in (select id from #_series);
END
else if(@idBanco=9)
BEGIN
	SET @n1 = (SELECT top 1 idbmer FROM ABONOSBANCOS_CB where idbanco=9 ORDER BY idbmer ASC);
	SET @nn = (SELECT top 1 idbmer FROM ABONOSBANCOS_CB where idbanco=9 ORDER BY idbmer DESC);
	-- crear una tabla temporal para la lista de identificadores generados interpolando el n1 y nn.
--	
--	print 'iniciar tabla id '+CONVERT(nvarchar(50), getdate(), 121);

	SET @i = @n1;
	while @i <= @nn
	BEGIN
	INSERT INTO @temp VALUES (@i);
	SET @i = @i + 1;
	END
--	print 'fin tabla id '+CONVERT(nvarchar(50), getdate(), 121);
	-- conseguir los ids huecos
	SELECT top 1 @idBmer=  id FROM @temp
	WHERE NOT EXISTS(SELECT idbmer FROM ABONOSBANCOS_CB where idbanco=9 and idbmer = id)   
	and not exists(select idbmer from ABONOSBANCOS_CB WHERE idbmer = id union all select idbmer from cargosBANCOS_CB WHERE idbmer = id) 
	
	order by id ---- not in (select id from #_series);
END

RETURN @idBmer

END
go

