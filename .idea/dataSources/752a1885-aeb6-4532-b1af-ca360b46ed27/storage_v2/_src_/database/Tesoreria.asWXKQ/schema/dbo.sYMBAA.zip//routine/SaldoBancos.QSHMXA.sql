-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec saldoBancos 2019, 10 ,71
-- =============================================
CREATE PROCEDURE [dbo].[SaldoBancos]
	 @anio int =2019
	 ,@mes int =8
	 ,@idUsuario int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	declare
	@idEmpresa int
	,@empresa varchar(250)
	,@nombre_base varchar(250)
	,@cuentaContable varchar(20)
	,@numeroCuenta varchar(50)
	,@cuenta varchar(50)
	,@saldoinicial decimal(18,2)
	,@abonosBanco decimal(18,2)
	,@cargosBanco decimal(18,2)
	,@saldoBanco decimal(18,2)
	,@idBanco int

	Declare @empresaBancoCuenta Table(empresaId int, empresa varchar(250), idBanco int, cuenta varchar(50), saldo decimal(18,2))

		DECLARE @NombreMes varchar(3),
					@RESULT_MESNAME varchar(10),
					@ParmDefinition nvarchar(100),
					@result_SaldoInicial_Contable decimal(18,2),
					@saldoContabilidad decimal(18,2),
					@date varchar(10)='01/'+right('0000'+convert(varchar(2), convert(nvarchar(2),@mes)), 2)+'/'+convert(nvarchar(4),@anio);

	SET LANGUAGE Spanish;
	SET @NombreMes = SUBSTRING(DATENAME(MONTH, CONVERT(DATE, CONVERT(DATE, REPLACE(@date,'-','')), 103)),0,4);

	SET @RESULT_MESNAME = UPPER('SF_'+ @NombreMes) 

	declare curEmp cursor for
	select nombre_base
	, contrApp.emp_idempresa AS emp_idempresa
	, contrApp.emp_nombre AS emp_nombre
	FROM [ControlAplicaciones].[dbo].[cat_empresas] contrApp
	INNER JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] centBases
	ON contrApp.emp_idempresa = centBases.emp_idempresa
	join Seguridad.dbo.SEG_USUARIO_EMPRESA ue
	on contrApp.emp_idempresa = ue.id_empresa
	and ue.id_empleado = @idUsuario
	WHERE contrApp.emp_idempresa !=0
	AND centBases.tipo = 2 
	and nombre_base_matriz is not null
	order by contrApp.emp_idempresa 

	OPEN curEmp
	FETCH NEXT FROM curEmp into @nombre_base, @idEmpresa, @empresa
	while @@FETCH_STATUS = 0
	begin


		declare curCuentas cursor for
		select cuentaContable, numeroCuenta, cuenta, SaldoInicial, idBanco
		from referencias.dbo.BancoCuenta
		where idempresa = @idempresa
		and idbanco in (1,2,3)

		open curCuentas
		fetch next from curCuentas into @cuentaContable, @numeroCuenta,@cuenta,@saldoinicial, @idBanco
		while @@FETCH_STATUS = 0
		begin

			begin try

			select @abonosBanco =sum(ab.importe)  
			from referencias.dbo.BancoCuenta bc
			left join  ABONOSBANCOS_CB ab
				on bc.numeroCuenta = ab.noCuenta
				AND BC.idEmpresa = AB.idEmpresa
				and idEstatus =0
			where  ab.anio =@anio
			and MONTH(fechaOperacion)= @mes
			and bc.idEmpresa = @idEmpresa
			and esCargo = 0
			and bc.cuenta = @cuenta
			group by bc.idbanco, bc.cuenta, numeroCuenta, cuentaContable

			select @cargosBanco =sum(ab.importe)  
			from referencias.dbo.BancoCuenta bc
			left join cargosBANCOS_CB ab
				on bc.numeroCuenta = ab.noCuenta
				AND BC.idEmpresa = AB.idEmpresa
				and idEstatus =0
			where  ab.anio =@anio
			and MONTH(fechaOperacion)= @mes
			and bc.idEmpresa = @idEmpresa
			and bc.cuenta = @cuenta
			group by bc.idbanco, bc.cuenta, numeroCuenta, cuentaContable

			set @saldoBanco = (@saldoinicial - (isnull(@cargosBanco,0)-isnull(@abonosBanco,0)))
			
			insert into @empresaBancoCuenta
			select @idEmpresa,@empresa, @idBanco,@cuenta, isnull(@saldoBanco,0)
			end try
			begin catch
			insert into @empresaBancoCuenta
			select -1,null,0,null, 0
			end catch
			

		fetch next from curCuentas into @cuentaContable, @numeroCuenta, @cuenta, @saldoinicial,@idBanco
		end
		close curCuentas
		deallocate curCuentas




	FETCH NEXT FROM curEmp into @nombre_base, @idEmpresa,@empresa
	end
	close curEmp
	deallocate curEmp

	select 
	bc.idBanco
	,bn.nombre
	,empresaId
	,empresa
	,cuenta
	,sum(saldo) as saldo
	from @empresaBancoCuenta bc
	join referencias.dbo.Banco bn
		on bc.idBanco = bn.idBanco
	where empresaId <> -1
	group by  bc.idBanco,bn.nombre,empresaId, empresa, cuenta
	order by idBanco, empresa

END
go

exec sp_addextendedproperty 'MS_Description', 'Obtiene el saldo por banco y empresa', 'SCHEMA', 'dbo', 'PROCEDURE',
     'SaldoBancos'
go

exec sp_addextendedproperty 'MS_Description', 'id del usuario logeado', 'SCHEMA', 'dbo', 'PROCEDURE', 'SaldoBancos',
     'PARAMETER', '@idUsuario'
go

