-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-05-18
-- Description:	Insercion de un nuevo movimiento 
--				bancario sobre demanda para poder 
--				ajustar y cuadrar la conciliacion bancaria
-- =============================================
CREATE PROCEDURE [dbo].[INT_CONCILIACION_ADDBANCOS_SP]
	@referencia VARCHAR(50)  = '',
	@concepto VARCHAR(50)	 = '',
	@refAmpliada VARCHAR(50) = '',
	@noCuenta VARCHAR(50)	 = '',
	@esCargo INT			 = 0,
	@importe NUMERIC(18,2)	 = 0,
	@fechaOperacion DATE	 = NULL,
	@idUsuario INT			 = 0,
	@idEmpresa INT			 = 0,
	@idBanco INT			 = 0,
	@anio INT				 = 0,
	@idBmer int				 = 0
AS
BEGIN
Declare @id int = 0

--Select @idBmer=case when @idBmer=0 then [dbo].[fn_BuscaidBmer](@idBanco) else @idBmer end

	SELECT 
		[idBmer]		 = @idBmer,
		[referencia]	 = @referencia,
		[noCuenta]		 = @noCuenta,
		[concepto]		 = @concepto,
		[refAmpliada]	 = @refAmpliada,
		[esCargo]		 = @esCargo,
		[importe]		 = @importe,
		[fechaOperacion] = @fechaOperacion,
		[fechaValor]	 = @fechaOperacion,
		[fechaContable]  = @fechaOperacion,
		[estatus]		 = 0,
		[Tipo]			 = 0,
		[idUsuario]		 = @idUsuario,
		[idEmpresa]		 = @idEmpresa,
		[anio]			 = @anio,
		[idBanco]		 = @idBanco,
		[fecha]			 = GETDATE(),
		[idEstatus]		 = 0,
		[idConciliado]	 = 0
	INTO #NUEVOREGISTRO_TMP

	IF( @esCargo = 1 )
		BEGIN
			INSERT INTO [CARGOSBANCOS_CB](
				[idBmer],
				[referencia],
				[noCuenta],
				[concepto],
				[refAmpliada],
				[esCargo],
				[importe],
				[fechaOperacion],
				[fechaValor],
				[fechaContable],
				[estatus],
				[Tipo],
				[idUsuario],
				[idEmpresa],
				[anio],
				[idBanco],
				[fecha],
				[idEstatus],
				[idConciliado]
			)
			SELECT 
			[idBmer]	,
		[referencia]	,
		[noCuenta]		,
		[concepto]		,
		[refAmpliada]	,
		[esCargo]		,
		[importe]		,
		[fechaOperacion],
		[fechaValor]	,
		[fechaContable] ,
		[estatus]		,
		[Tipo]			,
		[idUsuario]		,
		[idEmpresa]		,
		[anio]			,
		[idBanco]		,
		[fecha]			,
		[idEstatus]		,
		[idConciliado]	  FROM #NUEVOREGISTRO_TMP;

		set @id = SCOPE_IDENTITY()
		update [CARGOSBANCOS_CB] set idbmer=@id where IDCARGOSBANCOS=@id
		exec [dbo].[INS_CARGOS_ADDBANCOSHistorial_SP] @id
		END
	ELSE
		BEGIN
			INSERT INTO [ABONOSBANCOS_CB](
				[idBmer],
				[referencia],
				[noCuenta],
				[concepto],
				[refAmpliada],
				[esCargo],
				[importe],
				[fechaOperacion],
				[fechaValor],
				[fechaContable],
				[estatus],
				[Tipo],
				[idUsuario],
				[idEmpresa],
				[anio],
				[idBanco],
				[fecha],
				[idEstatus],
				[idConciliado]
			)
			SELECT 
			[idBmer]	,
		[referencia]	,
		[noCuenta]		,
		[concepto]		,
		[refAmpliada]	,
		[esCargo]		,
		[importe]		,
		[fechaOperacion],
		[fechaValor]	,
		[fechaContable] ,
		[estatus]		,
		[Tipo]			,
		[idUsuario]		,
		[idEmpresa]		,
		[anio]			,
		[idBanco]		,
		[fecha]			,
		[idEstatus]		,
		[idConciliado]	  FROM #NUEVOREGISTRO_TMP;

		set @id = SCOPE_IDENTITY()
		update [ABONOSBANCOS_CB] set idbmer=@id where IDABONOSBANCOS=@id
		exec [dbo].[INS_ABONOS_ADDBANCOSHistorial_SP] @id
		END

	DROP TABLE #NUEVOREGISTRO_TMP;
	SELECT success = 1;
END
go

