-- EXECUTE [dbo].[INS_CARTERA_VENCIDA_SP] 113, 5
CREATE PROCEDURE [dbo].[INS_CARTERA_VENCIDA_SP] 
       @idCliente int = 0,
       @idEmpresaActual int
AS
BEGIN
    SET NOCOUNT ON;
    --==========================================================================================--
    -- Clasificacion de Totales: 
    -- SALDO Negativo(anticipo que me dio)  Positivo(Lo el cliente me debe)
    -- Para este caso no debo discriminar si es factura o no.
    --==========================================================================================-- 
    
    
    DECLARE @aux               INT = 1
    DECLARE @max               INT = 0
    DECLARE @idEmpresaBusca    INT = 0
    DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
    DECLARE @IPBaseMatriz      NVARCHAR(50) =NULL
    DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @select            VARCHAR(max);
	DECLARE @selectPreCot      VARCHAR(max);
	DECLARE @selectCotNu       VARCHAR(max);
	DECLARE @selectCotSE       VARCHAR(max);
	DECLARE @selectPeOr        VARCHAR(max);
	DECLARE	@idSucursal		   NVARCHAR(50) =NULL
	DECLARE	@nombreSucursal    NVARCHAR(50) =NULL
	DECLARE @nombreEmpresa     NVARCHAR(50) =NULL
	DECLARE	@idEmpresa	       NVARCHAR(50) =NULL
    
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
							idSucursal nvarchar(30),
                            idEmpresa         nvarchar(30)
                            ,nombreEmpresa     nvarchar(100)
                            ,nomCtoEmpresa     nvarchar(5)
                            ,nomBaseConcentra  nvarchar(50)
							,nomBaseSucursal  nvarchar(50)
                            ,nomBaseMatriz     nvarchar(50)
                            ,ipServidor        nvarchar(20)
                            )
	
	

-- SE HACE LA BUSQUEDA DE LAS EMPRESAS Y SUCURSALES DISPONIBLES CON EL NOMBRE Y DIRECCIÓN IP DONDE SE ENCUENTRAN
     INSERT INTO @Bases
	   	SELECT 
				sucursales.suc_idsucursal
				,EMP.emp_idempresa
                ,EMP.emp_nombre
                ,EMP.emp_nombrecto
                ,BASEMP.nombre_base
				,BASEMP.nombre_sucursal
				--,BASEMP.
                ,ISNULL(BASEMP.nombre_base_matriz,BASEMP.nombre_base)
                ,BASEMP.ip_servidor 
           FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
                INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				inner join [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
          WHERE  BASEMP.estatus = 1 AND BASEMP.tipo = 1 and sucursales.emp_idempresa= EMP.emp_idempresa AND BASEMP.nombre_sucursal != 'CRA Guadalajara' AND BASEMP.nombre_sucursal !='CRA Cuautitlan' AND BASEMP.nombre_sucursal !='FORD BODY'
          AND BASEMP.emp_idempresa = @idEmpresaActual
       ORDER BY sucursales.suc_idsucursal
     SET @max = (SELECT MAX(IDB) FROM @Bases)
     WHILE(@aux <= @max)
     BEGIN
         
         SELECT  @idEmpresaBusca   = DB.idEmpresa 
				,@idEmpresa = DB.idEmpresa
                ,@nomBaseConcentra = DB.nomBaseConcentra
                --,@nomBaseMatriz    = DB.nomBaseMatriz
				--,@nomBaseMatriz    = (SELECT nombre_base_matriz FROM Centralizacionv2..DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresaActual AND sucursal_matriz IS NOT NULL)
				,@nomBaseMatriz    = nomBaseConcentra
				,@idSucursal = DB.idSucursal
				,@nombreSucursal = DB.nomBaseSucursal
				,@nombreEmpresa = DB.nombreEmpresa
				,@IPBaseMatriz = DB.ipServidor
           FROM @Bases AS DB 
          WHERE DB.IDB = @aux --DB.idEmpresa = @aux 
          --EXECUTE [SEL_PRESUPUESTO_DETALLE_SP] @idEmpresaBusca

		DECLARE @BaseLocal VARCHAR(18) = '';

		DECLARE @ipLocal VARCHAR(50) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);

		IF( @IPBaseMatriz != @ipLocal )
			BEGIN
				SET @BaseLocal = '[' + @IPBaseMatriz + '].';
				PRINT('===============================================')
				PRINT(@BaseLocal)
				PRINT('===============================================')
			END

		DECLARE @todo TABLE  ( --IDB INT IDENTITY(1,1),
                            folio         nvarchar(30)
							,serie nvarchar(20)
							,idDocumento nvarchar(30)
							,idEmpresa nvarchar(30)
							,nombreEmpresa nvarchar(100)
							,idSucursal nvarchar(30)
							,nombreSucursal nvarchar(30)
							,idDepartamento  nvarchar(30)
							,nombreDepartamento nvarchar(30)
							,origenMovimiento nvarchar(100)
							,importe nvarchar(30)
							,saldo nvarchar(30)
                            ,nombreCliente     nvarchar(100)
                            ,fecha  nvarchar(30)
							,idCliente  nvarchar(30)
							,referencia nvarchar(20)
							,tipoDocumento int
                            )
		  -- Refacciones|Cotizaciones dep_nombre
		  SET @select =
					'SELECT ' + char(13) + 
					'substring(CCP_IDDOCTO,1,30) CCP_IDDOCTO ' + char(13) + 
					',(select dbo.[fn_BuscaLetras](CCP_IDDOCTO)) as serie'+
					',(select dbo.[fn_BuscaNumeros](CCP_IDDOCTO)) as folio'+
					',(select emp_idempresa from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as idEmpresa' + char(13) + 
					',(select emp_nombre from [ControlAplicaciones].[dbo].[cat_empresas] where emp_idempresa = '+@idEmpresa +'  )as nombreEmpresa' + char(13) + 
					',(select suc_idsucursal from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as idSucursal' + char(13) + 
					',(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +')as nombreSucursal' + char(13) +
					',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +' ' + char(13) + 
					'and  dep_nombrecto = ' + char(13) + 
					'(select case when OrigenMovimiento = '+char(39)+'NUEVOS'+char(39)+' THEN '+char(39)+'UN'+char(39)+' ' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'SEMINUEVOS'+char(39)+' THEN '+char(39)+'US'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'REFACCIONES'+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'SERVICIO '+char(39)+' THEN '+char(39)+'SE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'NEGOCIOS '+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) +
					'when OrigenMovimiento = '+char(39)+'AUDITORIA '+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) +
					'when OrigenMovimiento = '+char(39)+'ND '+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) +
					'when OrigenMovimiento = '+char(39)+'AUDITORIA '+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'HOJALATERIA Y PINTURA '+char(39)+' THEN '+char(39)+'SE'+char(39)+'ELSE '+char(39)+'OT'+char(39)+' end)) AS idDepartamento' + char(13) + 
					',(select dep_nombre from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa +' and suc_idsucursal = '+@idSucursal +' ' + char(13) + 
					'and  dep_nombrecto = ' + char(13) + 
					'(select case when OrigenMovimiento = '+char(39)+'NUEVOS'+char(39)+' THEN '+char(39)+'UN'+char(39)+' ' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'SEMINUEVOS'+char(39)+' THEN '+char(39)+'US'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'REFACCIONES'+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'SERVICIO '+char(39)+' THEN '+char(39)+'SE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'NEGOCIOS '+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'AUDITORIA '+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) +
					'when OrigenMovimiento = '+char(39)+'ND '+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) +
					'when OrigenMovimiento = '+char(39)+'AUDITORIA '+char(39)+' THEN '+char(39)+'OT'+char(39)+'' + char(13) + 
					'when OrigenMovimiento = '+char(39)+'HOJALATERIA Y PINTURA '+char(39)+' THEN '+char(39)+'SE'+char(39)+'ELSE '+char(39)+'OT'+char(39)+' end)) AS nombreDepa' + char(13) +
					',OrigenMovimiento' + char(13) + 
					',IMPORTE' + char(13) + 
					',SALDO' + char(13) + 
					',(personas.per_nomrazon +'+char(39)+' '+char(39)+'+ personas.per_paterno +'+char(39)+' '+char(39)+'+ personas.per_materno) AS nombreCliente' + char(13) + 
					---',CCP_FECHADOCTO' + char(13) + 
					',substring(CCP_FECHADOCTO,7,4) +   substring(CCP_FECHADOCTO,4,2) + substring(CCP_FECHADOCTO,1,2) ' + char(13) + 
					',CCP_IDPERSONA' + char(13) + 
					',(SELECT referencia FROM [referencias].[dbo].[Referencia] REF INNER JOIN [referencias].[dbo].[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia 
					WHERE DEREF.documento = CCP_IDDOCTO  COLLATE Modern_Spanish_CI_AS 
					AND REF.idEmpresa ='+@idEmpresa +' AND  DEREF.idSucursal = '+@idSucursal +' AND REF.tipoReferencia = 1) AS referencia'+
					',1 AS idTipoDocumento' + char(13) + 
					'FROM '+@BaseLocal+'['+ @nomBaseMatriz +'].dbo.BI_CARTERA_CLIENTES facturas ' + char(13) + 
					'INNER JOIN  GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = facturas.CCP_IDPERSONA ' + char(13) + 
					'WHERE MODULO = '+char(39)+'CXC'+char(39)+
					' and CCP_TIPODOCTO IN (''FAC'', ''NCA'', ''RD'',''NCSS'')' + char(13) + 
					--' AND SUBSTRING(CCP_IDDOCTO,1,2) 	IN(SELECT SUBSTRING(FCF_SERIE,1,2) FROM '+@BaseLocal+'['+ @nomBaseMatriz +'].dbo.ADE_CFDFOLIOS)' + char(13) + 
					+' AND CCP_IDPERSONA='+ cast (@idCliente as varchar(10)) +' order by CCP_IDDOCTO'
					
					print( @IPBaseMatriz + '.' + @nomBaseMatriz);
					print(@select )
					---print('--------------------------------------------------')
				INSERT INTO @todo EXECUTE (@select)        
         SET @aux = @aux + 1
     END
--	 select * from @todo

     DELETE FROM CarteraVencida WHERE idCliente = @idCliente
          
	 insert into CarteraVencida 
	 select 
        folio
        ,serie
        ,idDocumento
        ,idEmpresa
        ,nombreEmpresa
        ,idSucursal
        ,nombreSucursal
        ,idDepartamento
        ,nombreDepartamento
        ,origenMovimiento
        ,importe
        ,saldo
        ,nombreCliente
        ,fecha
        ,idCliente
        ,referencia
        ,tipoDocumento
        , 1 
    from @todo -- where folio not in (select folio from CarteraVencida )

	print('Cliente: ' + convert(varchar(10),@idCliente))
	print('Empresa: ' + convert(varchar(2),@idEmpresaActual))
	--EXECUTE [dbo].[UPD_CARTERA_FOLIO_SP] @idCliente, @idEmpresa;
--	select * from @todo
END



go

