-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-06-11
-- Description:	Conciliacion de los referenciados al nacer
--delete from REGISTROS_PUNTEADOS_ERR where rpun_grupoPunteo in (select rpun_grupoPunteo from VW_REGISTROS_PUNTEADOS_ERR where idEmpresa=5 and mes=12)
-- [CON_REFERENCIADOS_CARGOS_V2_SP] 1, 4,8, 2019, '000000000190701289', '1100-0020-0001-0010'
-- =============================================
CREATE PROCEDURE [dbo].[CON_REFERENCIADOS_CARGOS_V2_SP]
	@idBanco INT	= 0,
	@idEmpresa INT	= 0,
	@Mes INT		= 0,
	@Anio INT		= 0,
	@cuentaBanco VARCHAR(30) = '',
	@cuentaContable VARCHAR(30) = ''
AS
BEGIN
	--DECLARE	@idBanco INT	= 1,
	--	@idEmpresa INT	= 4,
	--	@Mes INT		= 12,
	--	@Anio INT		= 2018,
	--	@cuentaBanco VARCHAR(30) = '000000000190701289',
	--	@cuentaContable VARCHAR(30) = '1100-0020-0001-0010'
		SET NOCOUNT ON;

		DECLARE @ipLocal VARCHAR(15) = (
			SELECT	dec.local_net_address
			FROM	sys.dm_exec_connections AS dec
			WHERE	dec.session_id = @@SPID
		);

		DECLARE @Base VARCHAR(300) = ''
		IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
			BEGIN
				SET @Base = (SELECT '[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
			END
		ELSE
			BEGIN
				SET @Base = (SELECT '[' + ip_servidor + '].[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
			END

		DECLARE @idMes INT = ( SELECT mec_idMes FROM PeriodoActivo WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @cuentaBanco AND mec_conciliado = 0 );
        PRINT ('Base');
        PRINT (@Base);
		DECLARE @Temporal TABLE(
			Id INT IDENTITY,
			MOV_TIPOPOL VARCHAR(50),
			MOV_CONSPOL INT,
			MOV_CONSMOV INT,
			MOV_NUMCTA VARCHAR(20),
			MOV_DEBE NUMERIC(18,5),
			MOV_MES INT,
			MOV_OBSERVA VARCHAR(50),
			MOV_OBSERVA2 VARCHAR(50)
		);
----1.-Se actualiza cb de cargos completos por que es la base
		DECLARE @Query VARCHAR(MAX) =
		'update CB set CB.MOV_OBSERVA = MOV.MOV_OBSERVA
		FROM '+ @Base +' MOV 
		INNER JOIN CARGOS_COMPLETO_CB CB ON MOV.MOV_TIPOPOL COLLATE Modern_Spanish_CI_AS = CB.MOV_TIPOPOL 
											AND MOV.MOV_CONSPOL = CB.MOV_CONSPOL 
											AND MOV.MOV_CONSMOV = CB.MOV_CONSMOV 
											AND MOV.MOV_MES = CB.MOV_MES
											AND MOV.MOV_NUMCTA COLLATE Modern_Spanish_CI_AS = CB.MOV_NUMCTA
											AND MOV.MOV_DEBE <> 0
		WHERE	CB.idEstatus = 0 
				AND cb.anio = ' + CONVERT( VARCHAR(4), @anio) + ' 
				AND idEmpresa = ' + CONVERT( VARCHAR(2), @idEmpresa) + ' 
				AND MOV.MOV_MES = ' + CONVERT(VARCHAR(2), @Mes) + ' 
				AND idBanco = ' + CONVERT(VARCHAR(2), @idBanco) + '
				AND MOV.MOV_NUMCTA = ''' + @cuentaContable + '''';

		--INSERT INTO @Temporal
		EXEC( @Query );

		
------2.-Se llama al universo
		select *
INTO #CASIPUNTEADOS
from(
		SELECT 
			CB.IDABONOSBANCOS,
			MOV.IDCARGOS_COMPLETO,
			CB.fechaOperacion,
			RD.fecha,
			CB.importe,
			MOV.MOV_DEBE,
			RAP.RAP_AplicaPago,
			RAP.rap_folio,
			RAP.rap_referenciabancaria,
			SUBSTRING(MOV.MOV_OBSERVA, 1, 20) Referencia,
			RAP.RAP_NumDeposito,
			SUBSTRING(MOV.MOV_OBSERVA, 22, 1) consecutivo,
			MOV_NUMCTA ,
			0 AS grupo
		
		FROM (select * from CARGOS_COMPLETO_CB MOV where len(mov_observa)=22) MOV
		INNER JOIN GA_Corporativa.dbo.cxc_refantypag RAP ON	SUBSTRING(MOV.MOV_OBSERVA, 1, 20) COLLATE database_default = RAP.rap_referenciabancaria 
											AND SUBSTRING(MOV.MOV_OBSERVA, 22, 1) = SUBSTRING( CONVERT(VARCHAR(6),RAP.RAP_NumDeposito),1,1)
		INNER JOIN  referencias.dbo.RAPDeposito RD ON RD.rap_folio = RAP.rap_folio
		INNER JOIN ABONOSBANCOS_CB CB ON CB.IDBanco = RD.idBanco AND CB.idBmer = RD.idDeposito
		WHERE   MONTH(fechaOperacion) = @Mes 
				AND YEAR(fechaOperacion) = @Anio 
				AND CB.noCuenta = @cuentaBanco 
				AND CB.idEstatus = 0 
				AND MOV.idEstatus = 0
				and MOV.MOV_NUMCTA = @cuentaContable
				and mov.anio= @Anio
union all
	SELECT 
			CB.IDABONOSBANCOS,
			MOV.IDCARGOS_COMPLETO,
			CB.fechaOperacion,
			CB.fechaOperacion fecha,
			CB.importe,
			MOV.MOV_DEBE,
			0 RAP_AplicaPago,
			0 rap_folio,
			substring(MOV.MOV_OBSERVA,1,20) rap_referenciabancaria,
			SUBSTRING(MOV.MOV_OBSERVA, 1, 20) Referencia,
			cb.idbmer RAP_NumDeposito,
			SUBSTRING(MOV.MOV_OBSERVA, 22, 1) consecutivo,
			MOV_NUMCTA ,
			0 AS grupo
		
		FROM (select * from CARGOS_COMPLETO_CB MOV where len(mov_observa)>20 and idEmpresa=@idEmpresa and idBanco=@idBanco and MOV_NUMCTA=@cuentaContable ) MOV
		INNER JOIN ABONOSBANCOS_CB CB ON  replace(substring(MOV.MOV_OBSERVA,1,20),'-','')=CB.referencia and MOV.idEmpresa=CB.idEmpresa and MOV.idBanco=CB.IDBanco
		left join VW_REGISTROS_PUNTEADOS w on MOV.IDCARGOS_COMPLETO=rpun_idCargo and rpun_tipo='C' 
		WHERE    YEAR(fechaOperacion) = @Anio 
				AND CB.noCuenta = @cuentaBanco 
				AND CB.idEstatus = 0 
				AND MOV.idEstatus = 0
				and MOV.MOV_NUMCTA = @cuentaContable
				and mov.anio= @Anio
				and w.rpun_grupoPunteo is null
				) x
		ORDER BY rap_referenciabancaria;
----3.-Se crean los grupos del universo

		 update c  set grupo=b.grupo from #CASIPUNTEADOS c 
		 inner join (select referencia,ROW_NUMBER() OVER(ORDER BY referencia ASC)+ ( SELECT ISNULL(MAX(rpun_grupoPunteo),0) FROM REGISTROS_PUNTEADOS ) AS grupo from(select distinct referencia from #CASIPUNTEADOS) x) b on c.Referencia=b.Referencia

----4.-Se crean los registros para insertar
		SELECT 
			IDABONOSBANCOS,
			referencia, 
			importe,
			grupo
		INTO #GRUPOS
		FROM #CASIPUNTEADOS
		GROUP BY IDABONOSBANCOS,referencia, importe,grupo

		SELECT 
			IDCARGOS_COMPLETO,
			IDABONOSBANCOS,
			SUM(RAP_AplicaPago) APLICA
		INTO #PUNTEO
		FROM #CASIPUNTEADOS
		GROUP BY IDCARGOS_COMPLETO, IDABONOSBANCOS;

	
			SELECT * ,0 noencontrado
		INTO #PUNTEADOS
		FROM 
		( select distinct * from (
			SELECT 
				[rpun_grupoPunteo]	= grupo,
				[rpun_idCargo]		= 0,
				[rpun_idAbono]		= P.IDABONOSBANCOS,
				[rpun_tipo]			= 'B',
				[rpun_fechaPunteo]	= GETDATE(),
				[rpun_usuario]		= 1,
				[rpun_idAplicado]	= 2,
				[idMes]				= @idMes
			FROM #PUNTEO P
			INNER JOIN #GRUPOS G ON P.IDABONOSBANCOS = G.IDABONOSBANCOS
		
			UNION ALL
		
			SELECT 
				[rpun_grupoPunteo]	= grupo,
				[rpun_idCargo]		= P.IDCARGOS_COMPLETO,
				[rpun_idAbono]		= 0,
				[rpun_tipo]			= 'C',
				[rpun_fechaPunteo]	= GETDATE(),
				[rpun_usuario]		= 1,
				[rpun_idAplicado]	= 2,
				[idMes]				= @idMes
			FROM #PUNTEO P
			INNER JOIN #GRUPOS G ON P.IDABONOSBANCOS = G.IDABONOSBANCOS
			) x
		) CONCILIADOS
		ORDER BY rpun_grupoPunteo, rpun_tipo  ASC


		
----5.-Se quitan los registros que ya existan en registrospunteados	
	
	

		update p set noencontrado = 1 from #PUNTEADOS  p where rpun_grupoPunteo in (
		select  tem.rpun_grupoPunteo
		
		FROM #PUNTEADOS TEM
		inner JOIN dbo.VW_REGISTROSPUNTEADOS_ALL PUN ON	TEM.rpun_idCargo = PUN.rpun_idCargo
												AND TEM.rpun_idAbono = PUN.rpun_idAbono
												AND TEM.rpun_tipo = PUN.rpun_tipo
		where pun.rpun_usuario=1
		)
	

----6.-Obtener registros para borrar
	SELECT * into #regborrar FROM REGISTROS_PUNTEADOS WHERE  rpun_idAplicado IN (0,1) AND rpun_tipo = 'B' AND rpun_idAbono in (select 
	
		TEM.rpun_idAbono
	
		FROM #PUNTEADOS TEM
		LEFT JOIN dbo.VW_REGISTROSPUNTEADOS_ALL PUN ON	TEM.rpun_idCargo = PUN.rpun_idCargo
												AND TEM.rpun_idAbono = PUN.rpun_idAbono
												AND TEM.rpun_tipo = PUN.rpun_tipo
		WHERE pun.rpun_idPunteado IS not NULL and noencontrado = 0 and pun.rpun_idAplicado in(0,1) and tem.rpun_tipo = 'B')
		insert into #regborrar
			select 
			PUN.rpun_grupoPunteo,
			TEM.rpun_idCargo,
			TEM.rpun_idAbono,
			TEM.rpun_tipo,
			TEM.rpun_fechaPunteo,
			TEM.rpun_usuario,
			TEM.rpun_idAplicado,
			TEM.idMes 
		
		FROM #PUNTEADOS TEM
		LEFT JOIN dbo.VW_REGISTROSPUNTEADOS_ALL PUN ON	TEM.rpun_idCargo = PUN.rpun_idCargo
												AND TEM.rpun_idAbono = PUN.rpun_idAbono
												AND TEM.rpun_tipo = PUN.rpun_tipo
		WHERE pun.rpun_idPunteado IS NULL 

													
------7.-Borrar registros
--	delete from REGISTROS_PUNTEADOS where rpun_grupoPunteo in (select rpun_grupoPunteo from #regborrar)
	


----8.-Actualizar temporal con los que tengan diferencia

		DECLARE @difMonetaria INT = (SELECT emp_dif_monetaria FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 AND emp_idempresa = @idEmpresa)
		DECLARE @difMonetariaNeg INT = @difMonetaria * -1;

		SELECT
			*
		INTO #CONIMPORTE
		FROM
		(
			SELECT 
				P.*,
				0 cargo,
				importe abono			
			FROM #PUNTEADOS P
			INNER JOIN ABONOSBANCOS_CB BAN ON P.rpun_idAbono = BAN.IDABONOSBANCOS AND rpun_tipo = 'B'
			UNION ALL
			SELECT 
				P.*,
				MOV_DEBE cargo,
				0 abono
			FROM #PUNTEADOS P
			INNER JOIN CARGOS_COMPLETO_CB BAN ON P.rpun_idCargo = BAN.IDCARGOS_COMPLETO AND rpun_tipo = 'C'
		) MONT
	
		SELECT 
			rpun_grupoPunteo,
			SUM(cargo) - SUM(abono) diferencia,
			guardarPorDiferencia =	CASE 
										WHEN (SUM(cargo) - SUM(abono) > @difMonetaria) THEN 1 
										ELSE
											CASE 
												WHEN (SUM(cargo) - SUM(abono) < @difMonetariaNeg) THEN 1 
												ELSE 0
											END
									END
		INTO #CONDIFERENCIAS
		FROM #CONIMPORTE 
		GROUP BY rpun_grupoPunteo 
		



		INSERT INTO [REGISTROS_PUNTEADOS] (
			rpun_grupoPunteo,
			rpun_idCargo,
			rpun_idAbono,
			rpun_tipo,
			rpun_fechaPunteo,
			rpun_usuario,
			rpun_idAplicado,
			idMes
		)
		select 
			TEM.rpun_grupoPunteo,
			TEM.rpun_idCargo,
			TEM.rpun_idAbono,
			TEM.rpun_tipo,
			TEM.rpun_fechaPunteo,
			TEM.rpun_usuario,
			TEM.rpun_idAplicado,
			TEM.idMes   
		from #PUNTEADOS TEM
		WHERE (SELECT guardarPorDiferencia FROM #CONDIFERENCIAS A WHERE A.rpun_grupoPunteo = TEM.rpun_grupoPunteo) = 0 and tem.noencontrado=0


		INSERT INTO [REGISTROS_PUNTEADOS_ERR] (
			rpun_grupoPunteo,
			rpun_idCargo,
			rpun_idAbono,
			rpun_tipo,
			rpun_fechaPunteo,
			rpun_usuario,
			rpun_idAplicado,
			idMes
		)
		select 
			TEM.rpun_grupoPunteo,
			TEM.rpun_idCargo,
			TEM.rpun_idAbono,
			TEM.rpun_tipo,
			TEM.rpun_fechaPunteo,
			TEM.rpun_usuario,
			TEM.rpun_idAplicado,
			TEM.idMes   
		from #PUNTEADOS TEM 
		WHERE (SELECT guardarPorDiferencia FROM #CONDIFERENCIAS A WHERE A.rpun_grupoPunteo = TEM.rpun_grupoPunteo) = 1 and tem.noencontrado=0

--		select * from #CASIPUNTEADOS;
--		select * from #GRUPOS;
--		select * from #PUNTEO;
--		select * from #PUNTEADOS;
--		select * from #regborrar;
		
--		select * from #CONIMPORTE
--		select * from #CONDIFERENCIAS

--		DROP TABLE #CASIPUNTEADOS;
--		DROP TABLE #GRUPOS;
--		DROP TABLE #PUNTEO;
--		DROP TABLE #PUNTEADOS;
--		DROP TABLE #regborrar;
		
--		DROP TABLE #CONIMPORTE
--		DROP TABLE #CONDIFERENCIAS
END
go

