-- =============================================
-- Author:		Roberto Almanza	Nieto
-- Create date: 27-03-2019
-- Description:	Envia correo de notificacion de registros punteados con error
-- =============================================
CREATE PROCEDURE [dbo].[SEL_GENERA_LAYOUT_PRUEBA] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


DECLARE @tableHTML  nvarchar(MAX) ='';
DECLARE @tableHTML2  nvarchar(MAX) = '';
DECLARE @htmlFinal nvarchar(max) ='';
DECLARE @destinatarios nvarchar(max) ='';
DECLARE @enviaCobros bit = 0
DECLARE @enviaRojitos bit = 0

DECLARE @tablaDatos TABLE(
rpun_idPunteado int
,rpun_grupoPunteo int
,rpun_idCargo int
,rpun_idAbono int
,rpun_tipo varchar(1)
,concepto nvarchar(250)
,rpun_fechaPunteo datetime
,rpun_usuario int
,rpun_idAplicado int
,idEmpresa int
,IDBanco int
,noCuenta varchar(50)
,cargos numeric(38,6)
,abonos numeric(38,6)
,mes int
,anio int
,idbmer int
,idMes int
,totalcargos numeric(38,6)
,totalabonos numeric(38,6)
,motivo varchar(250)
,tipo varchar(30)
)

SELECT @destinatarios = dm.destinatarios FROM dbo.DestinatariosMonitores dm WHERE dm.id = 1

DECLARE cRevisa CURSOR
READ_ONLY
FOR select idEmpresa,idBanco, numeroCuenta, cuenta, ce.emp_nombre+' - '+ce.emp_cveempresa 
from referencias.dbo.bancocuenta ban
JOIN ControlAplicaciones.dbo.cat_empresas ce
ON ban.idEmpresa = ce.emp_idempresa

DECLARE @empresa int, @banco int, @numeroCuenta varchar(50), @cuenta varchar(50), @nomEmpresa nvarchar(150) 
OPEN cRevisa

FETCH NEXT FROM cRevisa INTO @empresa, @banco, @numeroCuenta, @cuenta, @nomEmpresa
WHILE (@@FETCH_STATUS = 0)
BEGIN

	INSERT INTO @tablaDatos
	EXEC [SEL_REGISTROS_PUNTEADOS_ERR] @empresa,@banco,@numeroCuenta
	if(@@ROWCOUNT >0)
	BEGIN
		SELECT * FROM @tablaDatos td
		
	END
	
	DELETE FROM @tablaDatos

	FETCH NEXT FROM cRevisa INTO @empresa, @banco, @numeroCuenta,@cuenta, @nomEmpresa
END

CLOSE cRevisa
DEALLOCATE cRevisa

end
go

