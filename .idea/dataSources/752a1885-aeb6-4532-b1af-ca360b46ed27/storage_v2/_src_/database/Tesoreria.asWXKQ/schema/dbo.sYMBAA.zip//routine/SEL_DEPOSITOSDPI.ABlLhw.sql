-- =============================================
-- Author:		<Author,,Alejandro Grijalva Antonio>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [dbo].[SEL_DEPOSITOSDPI] 1225,2
CREATE PROCEDURE [dbo].[SEL_DEPOSITOSDPI] 
	@idMes INT = 0,
	@tipo int =0
AS
BEGIN
	DECLARE @idEmpresa INT, @idBanco INT, @cuenta VARCHAR(50), @mesActivo INT, @anioActivo INT;

	SELECT 
		@idEmpresa	= idEmpresa, 
		@idBanco	= idBanco, 
		@cuenta		= cuentaBancaria, 
		@mesActivo	= mec_numMes, 
		@anioActivo = mec_anio
	FROM PeriodoActivo 
	WHERE mec_idMes = @idMes;
	if @tipo=1
	begin
	SELECT
		DPI.idDPI,
		ABO.IDABONOSBANCOS,
		PUN.rpun_idPunteado,
		idCancelaDPI = ISNULL(CAN.idCancelaDPI, 0),
		fechaRegistro = CONVERT(VARCHAR(10), fechaRegistro, 103),
		replace(cpun.concepto,'DEPOSITO NO IDENTIFICADO ','') referencia,
		concepto = ABO.concepto + ' ' + refAmpliada,
		abono = importe,
		fechaOperacion,
		grupo = pun.rpun_grupoPunteo,
		pun.mes, 
		PUN.anio,
		origen = CASE idOrigen WHEN 1 THEN 'Conciliación' WHEN 2 THEN 'Control de Depósitos' END,
		fechaCancelacion = CAN.fecha,
		CAN.IDABONOS_COMPLETO,
		AC.MOV_TIPOPOL,
		AC.MOV_CONSPOL,
		AC.idEmpresa,
		mesLetra =  CASE PUN.mes
						WHEN 1 THEN 'Enero'
						WHEN 2 THEN 'Febrero'
						WHEN 3 THEN 'Marzo'
						WHEN 4 THEN 'Abril'
						WHEN 5 THEN 'Mayo'
						WHEN 6 THEN 'Junio'
						WHEN 7 THEN 'Julio'
						WHEN 8 THEN 'Agosto'
						WHEN 9 THEN 'Septiembre'
						WHEN 10 THEN 'Octubre'
						WHEN 11 THEN 'Noviembre'
						WHEN 12 THEN 'Diciembre'
					END,
					replace(ac.mov_concepto,'DEPOSITO IDENTIFICADO ','') mov_concepto
	,cpun.fechaope fechasinidentificar

	INTO #DPI
 
	FROM DepositoBancarioDPI DPI 
	INNER JOIN ABONOSBANCOS_CB ABO ON DPI.idAbonoBanco = ABO.idBmer AND DPI.idEmpresa = ABO.idEmpresa AND DPI.idBanco = ABO.IDBanco
	INNER JOIN VW_REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS AND PUN.rpun_tipo = 'B'
	inner join VW_REGISTROS_PUNTEADOS cpun on pun.rpun_grupoPunteo=cpun.rpun_grupoPunteo and cpun.rpun_tipo='C'
	LEFT JOIN CancelaDPI CAN ON CAN.idDPI = DPI.idDPI
	LEFT JOIN ABONOS_COMPLETO_CB AC ON AC.IDABONOS_COMPLETO = CAN.idAbonos_Completo
	WHERE DPI.idEmpresa = @idEmpresa AND DPI.idBanco = @idBanco AND ABO.noCuenta = @cuenta
	union all
	select idDPIAnterior idDPI,
		0 IDABONOSBANCOS,
		0  rpun_idPunteado,
		0  idCancelaDPI, 
		CONVERT(VARCHAR(10), fecha, 103) fechaRegistro, 
		documento referencia,
		referencia concepto ,
		importe abono ,
		fecha fechaOperacion,
		0	grupo ,
		month(fecha) mes, 
		year(fecha) anio,
		'DPI Histórico' origen ,
		null fechaCancelacion ,
		null IDABONOS_COMPLETO,
		'DPI' MOV_TIPOPOL,
		null MOV_CONSPOL,
		@idEmpresa idEmpresa,
		mesLetra =  CASE month(fecha)
						WHEN 1 THEN 'Enero'
						WHEN 2 THEN 'Febrero'
						WHEN 3 THEN 'Marzo'
						WHEN 4 THEN 'Abril'
						WHEN 5 THEN 'Mayo'
						WHEN 6 THEN 'Junio'
						WHEN 7 THEN 'Julio'
						WHEN 8 THEN 'Agosto'
						WHEN 9 THEN 'Septiembre'
						WHEN 10 THEN 'Octubre'
						WHEN 11 THEN 'Noviembre'
						WHEN 12 THEN 'Diciembre'
					END ,
	referencia mov_concepto
	,fechaIdentificado
	from [dbo].[dpiAnterior] where cuenta=@cuenta and isnull(cancelado,0)=0


	SELECT *, status = 1, label = 'Generado', class = 'primary'  FROM #DPI WHERE  mes = @mesActivo AND idCancelaDPI = 0
	UNION ALL
	SELECT *, status = 2, label = 'Por Identificar', class = 'warning' FROM #DPI WHERE mes != @mesActivo AND idCancelaDPI = 0
	
	DROP TABLE #DPI;
	end
	else
	begin
			SELECT
		DPI.idDPI,
		ABO.IDABONOSBANCOS,
		PUN.rpun_idPunteado,
		idCancelaDPI = ISNULL(CAN.idCancelaDPI, 0),
		fechaRegistro = CONVERT(VARCHAR(10), fechaRegistro, 103),
		replace(ac.mov_concepto,'DEPOSITO IDENTIFICADO ','') referencia,
		concepto = ABO.concepto + ' ' + refAmpliada,
		abono = importe,
		fechaOperacion,
		grupo = rpun_grupoPunteo,
		ac.mov_mes mes, 
		PUN.anio,
		origen = CASE idOrigen WHEN 1 THEN 'Conciliación' WHEN 2 THEN 'Control de Depósitos' END,
		fechaCancelacion = CAN.fecha,
		CAN.IDABONOS_COMPLETO,
		AC.MOV_TIPOPOL,
		AC.MOV_CONSPOL,
		AC.idEmpresa,
		mesLetra =  CASE PUN.mes
						WHEN 1 THEN 'Enero'
						WHEN 2 THEN 'Febrero'
						WHEN 3 THEN 'Marzo'
						WHEN 4 THEN 'Abril'
						WHEN 5 THEN 'Mayo'
						WHEN 6 THEN 'Junio'
						WHEN 7 THEN 'Julio'
						WHEN 8 THEN 'Agosto'
						WHEN 9 THEN 'Septiembre'
						WHEN 10 THEN 'Octubre'
						WHEN 11 THEN 'Noviembre'
						WHEN 12 THEN 'Diciembre'
					END,
					replace(ac.mov_concepto,'DEPOSITO IDENTIFICADO ','') mov_concepto
	,convert(datetime,ac.MOV_FECHOPE,103) fechasinidentificar
	INTO #DPI2
	FROM DepositoBancarioDPI DPI 
	INNER JOIN ABONOSBANCOS_CB ABO ON DPI.idAbonoBanco = ABO.idBmer AND DPI.idEmpresa = ABO.idEmpresa AND DPI.idBanco = ABO.IDBanco
	INNER JOIN VW_REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS AND PUN.rpun_tipo = 'B'
	LEFT JOIN CancelaDPI CAN ON CAN.idDPI = DPI.idDPI
	LEFT JOIN ABONOS_COMPLETO_CB AC ON AC.IDABONOS_COMPLETO = CAN.idAbonos_Completo
	WHERE DPI.idEmpresa = @idEmpresa AND DPI.idBanco = @idBanco AND ABO.noCuenta = @cuenta 
		union all
	select idDPIAnterior idDPI,
		0 IDABONOSBANCOS,
		0  rpun_idPunteado,
		9999  idCancelaDPI, 
		CONVERT(VARCHAR(10), d.fecha, 103) fechaRegistro, 
		documento referencia,
		referencia concepto ,
		importe abono ,
		d.fecha fechaOperacion,
		0	grupo ,
		a.mov_mes mes, 
		a.anio anio,
		'DPI Histórico' origen ,
		a.fecha fechaCancelacion ,
		a.IDABONOS_COMPLETO,
		a.MOV_TIPOPOL,
		a.MOV_CONSPOL,
		@idEmpresa idEmpresa,
		mesLetra =  CASE month(d.fecha)
						WHEN 1 THEN 'Enero'
						WHEN 2 THEN 'Febrero'
						WHEN 3 THEN 'Marzo'
						WHEN 4 THEN 'Abril'
						WHEN 5 THEN 'Mayo'
						WHEN 6 THEN 'Junio'
						WHEN 7 THEN 'Julio'
						WHEN 8 THEN 'Agosto'
						WHEN 9 THEN 'Septiembre'
						WHEN 10 THEN 'Octubre'
						WHEN 11 THEN 'Noviembre'
						WHEN 12 THEN 'Diciembre'
					END  ,
referencia mov_concepto
,d.fechaIdentificado fechasinidentificar
	from [dbo].[dpiAnterior] d
	inner join referencias.dbo.bancocuenta bc on d.cuenta=bc.numerocuenta
	inner join abonos_completo_cb a on d.importe=a.mov_haber and bc.idempresa=a.idempresa and bc.idbanco=a.idbanco and bc.cuentacontable=a.mov_numcta and MOV_TIPOPOL='DPI'
	where d.cuenta=@cuenta and isnull(cancelado,0)=1


	SELECT *, status = 3, label = 'Identificado', class = 'success' FROM #DPI2 WHERE  idCancelaDPI != 0
	DROP TABLE #DPI2;
	end
END
go

