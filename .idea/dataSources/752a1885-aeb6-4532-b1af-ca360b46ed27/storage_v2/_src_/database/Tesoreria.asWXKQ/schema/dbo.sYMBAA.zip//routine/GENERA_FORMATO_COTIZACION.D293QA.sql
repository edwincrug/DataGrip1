-- =============================================
-- Author: Roberto Almanza
-- Create date: 26-02-2020
-- Description: Genera el formato para la captura de la cotizacion universal en
--el portal de consulta movimientos
-- =============================================
CREATE PROCEDURE dbo.GENERA_FORMATO_COTIZACION
@idEmpresa INT
,@idSucursal INT
,@idDepartamento INT
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
    BEGIN TRY
Declare
@divicion varchar(3)
,@empresa varchar(5)
,@sucursal varchar(5)
,@depto varchar(5)
SELECT @divicion = div_nombrecto FROM ControlAplicaciones..cat_divisiones cd where div_nombrecto = 'AU'
SELECT @empresa = emp_nombrecto FROM ControlAplicaciones..cat_empresas ce WHERE emp_idempresa =  @idEmpresa
SELECT @sucursal = suc_nombrecto FROM ControlAplicaciones..cat_sucursales cs WHERE suc_idsucursal = @idSucursal
SELECT @depto = dep_nombrecto FROM ControlAplicaciones..cat_departamentos cd where emp_idempresa = @idEmpresa and suc_idsucursal = @idSucursal and dep_nombrecto = 'UN'
select estatus = 1, @divicion+'-'+@empresa+'-'+@sucursal+'-'+@depto+'-' as cotizacion
END TRY
BEGIN CATCH
select estatus = 0,'' as cotizacion
END CATCH
END
go

exec sp_addextendedproperty 'MS_Description',
     'Genera el formato para la captura de la cotizacion universal en el portal de consulta movimientos', 'SCHEMA',
     'dbo', 'PROCEDURE', 'GENERA_FORMATO_COTIZACION'
go

