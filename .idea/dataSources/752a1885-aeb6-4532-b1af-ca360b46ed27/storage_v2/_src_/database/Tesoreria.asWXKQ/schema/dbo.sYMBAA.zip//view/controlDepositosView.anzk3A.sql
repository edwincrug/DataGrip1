


--select top 100 * from [dbo].[controlDepositosView]
CREATE VIEW [dbo].[controlDepositosView]
AS

SELECT     idBmer, IDBanco, txtOrigen, registro, noMovimiento, referencia, concepto, refAmpliada, esCargo, importe, saldoOperativo, codigoLeyenda, oficinaOperadora, 
                      fechaOperacion, horaOperacion, fechaValor, fechaContable, estatus,[estatusRevision], noCuenta
FROM         [referencias].[dbo].[Bancomer]
UNION
SELECT     idSantander AS idBmer, idbanco AS IDBanco, txtOrigen AS txtOrigen, 0 AS registro, clacon AS noMovimiento, referencia AS referencia, concepto AS concepto, 
                      descripcion AS refAmpliada, CASE signo WHEN '+' THEN 0 ELSE 1 END AS esCargo, importe AS importe, saldo AS saldoOperativo, clacon AS codigoLeyenda, 
                      sucursal AS oficinaOperadora, fechaMovimiento AS fechaOperacion, horaMovimiento AS horaOperacion, getdate() AS fechaValor, getdate() AS fechaContable, 
                      estatus AS estatus,[estatusRevision], noCuenta AS noCuenta
FROM         [referencias].[dbo].[Santander]
UNION
--select * from (
--select idBmer, IDBanco, txtOrigen, registro, noMovimiento, referencia, concepto, refAmpliada, esCargo, importe, saldoOperativo, codigoLeyenda, oficinaOperadora, 
--                      fechaOperacion, horaOperacion, fechaValor, fechaContable, estatus,[estatusRevision], noCuenta from ABONOSBANCOS_CB where IDBanco=2 and idEstatus=0
--union all
--select idBmer, IDBanco, txtOrigen, registro, noMovimiento, referencia, concepto, refAmpliada, esCargo, importe, saldoOperativo, codigoLeyenda, oficinaOperadora, 
--                      fechaOperacion, horaOperacion, fechaValor, fechaContable, estatus,[estatusRevision], noCuenta from cargosBANCOS_CB where IDBanco=2 and idEstatus=0) x
SELECT    idbanamex idBmer, BMEX.idBanco,archivo AS txtOrigen,case when isnumeric(SLCodigoTransaccion)=1 then convert(smallint,SLCodigoTransaccion) else 0 end AS registro,Consecutivo  AS noMovimiento, 
					  CONVERT(VARCHAR(30), SLTipoReferencia) AS referencia, 
                      BMEX.AODescripcion AS concepto, '' AS refAmpliada, CASE BMEX.SLCredito WHEN 'C' THEN 0 ELSE 1 END AS esCargo, 
                      BMEX.SLMonto  AS importe, CBMonto AS saldoOperativo, BMEX.SLRazon AS codigoLeyenda, 
                      0 AS oficinaOperadora, BMEX.SLFechaTransaccion AS fechaOperacion, CONVERT(time, getdate(), 108) AS horaOperacion, getdate() AS fechaValor, getdate() 
                      AS fechaContable, 1 AS estatus,[estatusRevision], noCuenta
FROM         [referencias].[dbo].[Banamex] BMEX
--union  


go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[15] 4[47] 2[21] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4[30] 2[40] 3) )"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2[66] 3) )"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 5
   End
   Begin DiagramPane = 
      PaneHidden = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 28
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      PaneHidden = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'controlDepositosView'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'controlDepositosView'
go

