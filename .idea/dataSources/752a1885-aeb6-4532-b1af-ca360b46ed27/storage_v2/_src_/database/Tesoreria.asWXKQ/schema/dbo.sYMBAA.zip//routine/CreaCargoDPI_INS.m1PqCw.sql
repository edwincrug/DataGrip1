-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <20/06/2018>
-- Description:	<Inserta el dpi en tesoreria>
-- =============================================
CREATE PROCEDURE [dbo].[CreaCargoDPI_INS]
			@idAbonoBanco INT,
			@idBanco INT,
			@idEmpresa INT,
			@MOV_NUMCTA varchar(50),
			@MOV_CONSPOL INT ,
			@MOV_CONSMOV INT,
			@MOV_DEBE decimal(18,5) =0,
			@MOV_HABER decimal(18,5) =0,
			@MOV_IDCLIENTE numeric (18,0),
			@MOV_TIPOPOL nvarchar(10),
			@MOV_MES int,
			@MOV_ANIO int,
			@mov_fecha datetime,
			@MOV_IDDOCTO nvarchar(20)
		   

AS
BEGIN
DECLARE @idMes INT = ( SELECT mec_idMes FROM PeriodoActivo p
left join Referencias.dbo.BancoCuenta bc on p.idEmpresa=bc.idEmpresa and p.IDBanco=bc.idBanco and p.cuentaBancaria=bc.numeroCuenta
WHERE p.idEmpresa = @idEmpresa AND p.idBanco = @idBanco AND bc.cuentaContable = @MOV_NUMCTA AND mec_conciliado = 0 );

----1.-Insertar en [CARGOS_COMPLETO_CB]--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	SET NOCOUNT ON;
declare @IDCARGOS_COMPLETO numeric,@rpun_grupoPunteo int
INSERT INTO [dbo].[CARGOS_COMPLETO_CB]
           ([MOV_TIPOPOL],[MOV_CONSPOL],[MOV_CONSMOV],[MOV_MES],[MOV_NUMCTA],[MOV_CONCEPTO],[MOV_DEBE],[MOV_HABER],[MOV_ORIGEN],[MOV_IDCLIENTE],[MOV_DEPTO],[MOV_CARTERA],[MOV_TIPODOCTO],[MOV_IDDOCTO],[MOV_FECHVEN]
           ,[MOV_FECHPAG],[MOV_AGENTE],[MOV_CVEUSU] ,[MOV_FECHOPE] ,[MOV_CONCILIADO],[MOV_FOLIO],[MOV_FOLIODET],[MOV_MONEDA],[MOV_TIPOCAMBIO],[MOV_HORAOPE],[MOV_OBSERVA],[Tipo],[idUsuario],[idEmpresa],[idBanco],[anio],[fecha],[idEstatus],[idConciliado])
		        VALUES
           (@MOV_TIPOPOL			--<MOV_TIPOPOL, varchar(10),>
           ,@MOV_CONSPOL			--<MOV_CONSPOL, numeric(18,0),>
           ,@MOV_CONSMOV			--<MOV_CONSMOV, numeric(18,0),>
           ,@MOV_MES			--<MOV_MES, numeric(18,0),>
           ,@MOV_NUMCTA			--<MOV_NUMCTA, varchar(50),>
           ,'DEPOSITO NO IDENTIFICADO '+@MOV_IDDOCTO		--<MOV_CONCEPTO, varchar(250),>
           ,@MOV_HABER		--<MOV_DEBE, decimal(18,5),>
           ,@MOV_DEBE			--<MOV_HABER, decimal(18,5),>
           ,''			--<MOV_ORIGEN, varchar(50),>
           ,@MOV_IDCLIENTE			--<MOV_IDCLIENTE, numeric(18,0),>
           ,''			--<MOV_DEPTO, varchar(50),>
           ,''			--<MOV_CARTERA, varchar(50),>
           ,''			--<MOV_TIPODOCTO, varchar(50),>
           ,@MOV_IDDOCTO--<MOV_IDDOCTO, varchar(20),>
           ,''			--<MOV_FECHVEN, varchar(10),>
           ,''			--<MOV_FECHPAG, varchar(10),>
           ,''			--<MOV_AGENTE, varchar(50),>
           ,3			--<MOV_CVEUSU, varchar(10),>
           ,convert(varchar(10),@mov_fecha,103)			--<MOV_FECHOPE, varchar(10),>
           ,''			--<MOV_CONCILIADO, varchar(1),>
           ,0			--<MOV_FOLIO, numeric(18,0),>
           ,0			--<MOV_FOLIODET, numeric(18,0),>
           ,'PE'			--<MOV_MONEDA, varchar(10),>
           ,'1'			--<MOV_TIPOCAMBIO, decimal(18,5),>
           ,''			--<MOV_HORAOPE, varchar(8),>
           ,''			--<MOV_OBSERVA, varchar(250),>
           ,0			--<Tipo, int,>
           ,3			--<idUsuario, int,>
           ,@idEmpresa			--<idEmpresa, int,>
           ,@idBanco			--<idBanco, int,>
           ,@MOV_ANIO			--<anio, int,>
           ,getdate()			--<fecha, datetime,>
           ,0			--<idEstatus, int,>
           ,1			--<idConciliado, int,>
		   )
set @IDCARGOS_COMPLETO=SCOPE_IDENTITY()
----2.-Insertar en [REGISTROS_PUNTEADOS]--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
select @rpun_grupoPunteo= max(rpun_grupoPunteo)+1 from [REGISTROS_PUNTEADOS]
INSERT INTO [dbo].[REGISTROS_PUNTEADOS]
           ([rpun_grupoPunteo]
           ,[rpun_idCargo]
           ,[rpun_idAbono]
           ,[rpun_tipo]
           ,[rpun_fechaPunteo]
           ,[rpun_usuario]
           ,[rpun_idAplicado]
		   ,idMes)
     VALUES
           (@rpun_grupoPunteo				--<rpun_grupoPunteo, int,>
           ,0		--<rpun_idCargo, int,>
           ,@idAbonoBanco				--<rpun_idAbono, int,>
           ,'B'			--<rpun_tipo, varchar(1),>
           ,getdate()				--<rpun_fechaPunteo, datetime,>
           ,3				--<rpun_usuario, int,>
           ,3
		   ,@idMes				--<rpun_idAplicado, int,>
		   )
----3.-Insertar en [REGISTROS_PUNTEADOS]--------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO [dbo].[REGISTROS_PUNTEADOS]
           ([rpun_grupoPunteo]
           ,[rpun_idCargo]
           ,[rpun_idAbono]
           ,[rpun_tipo]
           ,[rpun_fechaPunteo]
           ,[rpun_usuario]
           ,[rpun_idAplicado]
		   ,idMes)
     VALUES
           (@rpun_grupoPunteo				--<rpun_grupoPunteo, int,>
           ,@IDCARGOS_COMPLETO		--<rpun_idCargo, int,>
           ,0				--<rpun_idAbono, int,>
           ,'C'			--<rpun_tipo, varchar(1),>
           ,getdate()				--<rpun_fechaPunteo, datetime,>
           ,3				--<rpun_usuario, int,>
           ,3	
		   ,@idMes			--<rpun_idAplicado, int,>
		   )
EXEC [dbo].[BitacoraDPI_INS]  @idAbonoBanco,@idEmpresa,@idBanco,@MOV_NUMCTA,@MOV_CONSPOL,8,'',3
END
go

