
-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date, 2017-11-10>
-- Description:	EXECUTE dbo.[Bancomer_Resultado_Montos_SP_BC] '2018-03-01','2018-03-06','1100-0020-0001-0001','000000000195334667','TREEUN',1,1,1,9
-- =============================================
CREATE PROCEDURE [dbo].[Bancomer_Resultado_Montos_SP_BC] 
	-- Add the parameters for the stored procedure here
	-- Add the parameters for the function here
		@fechaElaboracion varchar(30),
		@fechaCorte varchar(30),
		@cuentaContable varchar(50), 
		@noCuenta varchar(50),
		@polizaPago varchar(20),
		@idEmpresa int = 0,
		@idBanco int = 0,
		@tipoconsulta int = 0,
		@idUsuario INT = 0
AS
BEGIN TRY

DECLARE       @totalAbonoContable decimal(18,2),
			  @totalAbonoContableQuery NVARCHAR(MAX),
			  @totalCargoContableQuery NVARCHAR(MAX),
			  @totalAbonoBancario decimal(18,2),
			  @totalCargoBancario decimal(18,2),
			  @totalCargoContable decimal(18,2),
			  @ParmDefinition nvarchar(500),
              @result_CargoContable varchar(30),
			  @result_AbonoContable varchar(30),
			  @query VARCHAR(MAX) = ''

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
--------------------------------------------------------------Obtiene datos de las bases correspondientes según el numero de empresa----------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @ipLocal NVARCHAR(50) = ''
	   ,@ip_catbases NVARCHAR(50) = ''			
	   ,@Base NVARCHAR(50) = ''

SELECT	@ipLocal = dec.local_net_address
FROM	sys.dm_exec_connections AS dec
WHERE	dec.session_id = @@SPID;
------------------------------------------------------------------------------------------------
--Obtiene los datos de la CONCENTRADORA
------------------------------------------------------------------------------------------------
SELECT	@ip_catbases = (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN ''
							ELSE ip_servidor 
						END),
		@idEmpresa	= emp_idempresa,
		@Base		= (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN '[' + nombre_base + '].[DBO].' 
							ELSE '['+ ip_servidor + '].[' + nombre_base + '].[DBO].' 
						END)
FROM	[CentralizacionV2].[dbo].[DIG_CAT_BASES_BPRO]
WHERE	emp_idempresa	= @idEmpresa 
		AND tipo		= 2

------------------------------------------------------------------------Inserta los datos de las referencias bancarias--------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @MesMov INT = MONTH(convert(DATE, convert(date,@fechaCorte), 103))
DECLARE @añoConsulta INT = YEAR(CONVERT(DATE,(CONVERT(DATE,@fechaCorte)),103))

-----------------------------------------------------------------------Cálculo Abonos en Contabilidad Bancomer------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DELETE FROM ABONOS_COMPLETO_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM ABONOS_PAGO_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM CARTERA_PAGOS_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM DOCTOSPAGADOS_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM REGISTROSCONCILIADOS_CB WHERE IDUSUARIO = @idUsuario

SET @totalAbonoContableQuery =  ---'INSERT INTO ABONOS_COMPLETO_CB ' +
								'SELECT *,0, ' + CONVERT(VARCHAR(4),@idUsuario)+ ' FROM '+ @Base +'CON_MOVDET01' + CONVERT(VARCHAR(4),@añoConsulta)+' ' +
								'WHERE MOV_MES = ' + CONVERT(VARCHAR(4),@MesMov)+' ' +
								'AND MOV_NUMCTA = '''+ @cuentaContable +''' ' +
								'AND MOV_HABER > 0 '
							
--print @totalAbonoContableQuery
INSERT INTO ABONOS_COMPLETO_CB
EXEC (@totalAbonoContableQuery)


SET @totalAbonoContableQuery = 'SELECT * FROM  ABONOS_COMPLETO_CB WHERE MOV_TIPOPOL = ''TREEUN'''
INSERT INTO ABONOS_PAGO_CB 
EXEC (@totalAbonoContableQuery)


SET @totalAbonoContableQuery ='SELECT 1,CCP_CONSCARTERA,CCP_TIPOPOL,CCP_CONSPOL,CCP_CONSMOV,CCP_MES,CCP_IDDOCTO,CCP_IDPERSONA, ' + CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
							  'FROM ABONOS_PAGO_CB P INNER JOIN '+ @Base +'CON_CAR01' + CONVERT(VARCHAR(4),@añoConsulta)+' ON MOV_CONSPOL = CCP_CONSPOL AND MOV_MES = CCP_MES ' +
							  'WHERE CCP_TIPOPOL = ''TREEUN'' AND CCP_MES = ' + CONVERT(VARCHAR(4),@MesMov)+ ' AND CCP_TIPODOCTO = ''PAGO'''

INSERT INTO CARTERA_PAGOS_CB
EXEC (@totalAbonoContableQuery)

SET @totalAbonoContableQuery = 'SELECT 1,*, ' + CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
								'FROM [cuentasxpagar].[dbo].[cxp_doctospagados] D INNER JOIN Pagos.DBO.PAG_LOTE_PAGO ON dpa_lote = pal_id_lote_pago ' +
								'WHERE dpa_fechaaplicacion BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''  '+
								'AND dpa_cuentapagadora = '''+ @noCuenta +''' ' +
								'AND pal_id_tipoLotePago = 1 ' + 
								'AND dpa_pagoaplicado = 1'

INSERT INTO DOCTOSPAGADOS_CB
EXEC (@totalAbonoContableQuery)


SET @totalAbonoContableQuery = 'SELECT 1,CCP_TIPOPOL,CCP_CONSPOL,CCP_MES, ' + CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
								'FROM CARTERA_PAGOS_CB INNER JOIN DOCTOSPAGADOS_CB ON CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS = dpa_iddocumento COLLATE Modern_Spanish_CS_AS ' +
								'AND CCP_IDPERSONA = dpa_idpersona GROUP BY  CCP_TIPOPOL,CCP_CONSPOL,CCP_MES '

INSERT INTO REGISTROSCONCILIADOS_CB
EXEC (@totalAbonoContableQuery)


UPDATE ABONOS_COMPLETO_CB SET Tipo = 1 FROM  ABONOS_COMPLETO_CB A 
INNER JOIN REGISTROSCONCILIADOS_CB C ON  MOV_TIPOPOL = CCP_TIPOPOL AND MOV_MES = CCP_MES AND MOV_CONSPOL = CCP_CONSPOL

SELECT @result_AbonoContable = SUM(MOV_HABER) --Abonos_Contables_noBancarios 
FROM ABONOS_COMPLETO_CB

/********************************************************************************************************************
*********************************************************************************************************************/
---------------------------------------------------------------------------Cálculos de Abonos Banco Bancomer------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DELETE FROM ABONOSBANCOS_CB WHERE IDUSUARIO = @idUsuario
/*
DELETE FROM ABONOS_COMPLETO_CB WHERE IDUSUARIO = @idUsuario
*/		
SET @query = 'SELECT *,0, ' + CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
			 'FROM Referencias.dbo.BANCOMER WHERE fechaOperacion BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''  '+
			 'AND noCuenta = '''+ @noCuenta +''' AND esCargo = 0 '
--print @query
INSERT INTO ABONOSBANCOS_CB
EXEC (@query)

UPDATE ABONOSBANCOS_CB SET Tipo = 1 FROM ABONOSBANCOS_CB A 
INNER JOIN [referencias].[dbo].[RAPDeposito] D ON idBmer = idDeposito 
INNER JOIN GA_Corporativa.dbo.cxc_refantypag R ON D.rap_folio = R.rap_folio 
WHERE noCuenta = @noCuenta AND A.IDBanco = 1 AND D.idBanco = 1 AND rap_idstatus <> 1

SELECT @totalAbonoBancario = SUM(importe) --Abonos_Bancos_noContabilidad 
FROM ABONOSBANCOS_CB WHERE Tipo = 0  --NO CONCILIADOS

 -----------------------------------------------------------------------Cálculos Cargos Contabilidad Bancomer------------------------------------------------------------------------
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DELETE FROM CARGOS_COMPLETO_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM CARGOSCOBROS_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM CARTERA_COBROS_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM DOCTOSCOBRADOS_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM COBROSCONCILIADOS_CONTROL_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM COBROSCONCILIADOS_REFERENCIA_CB WHERE IDUSUARIO = @idUsuario

SET @query = 'SELECT *,0, '+ CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
				'FROM '+ @Base +'CON_MOVDET01' + CONVERT(VARCHAR(4),@añoConsulta)+' ' +
				'WHERE MOV_MES = ' + CONVERT(VARCHAR(4),@MesMov)+ ' ' +
				'AND MOV_NUMCTA = '''+ @cuentaContable +''' ' +
				'AND MOV_DEBE > 0'
				
INSERT INTO CARGOS_COMPLETO_CB 
EXEC (@query)

SET @query = 'SELECT * FROM CARGOS_COMPLETO_CB ' +
			 'WHERE MOV_TIPOPOL IN(''ICCU'',''ICPE'',''ICUN'')'
INSERT INTO CARGOSCOBROS_CB
EXEC (@query)


SET @query = 'SELECT CCP_CONSCARTERA,CCP_TIPOPOL,CCP_CONSPOL,CCP_CONSMOV,CCP_MES,CCP_IDDOCTO,CCP_IDPERSONA, '+ CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
			 'FROM CARGOSCOBROS_CB P INNER JOIN '+ @Base +'CON_CAR01' + CONVERT(VARCHAR(4),@añoConsulta)+' ON MOV_CONSPOL = CCP_CONSPOL AND MOV_MES = CCP_MES ' +
			 'WHERE CCP_TIPOPOL IN(''ICCU'',''ICPE'',''ICUN'') ' +
			 'AND CCP_MES = ' + CONVERT(VARCHAR(4),@MesMov)+ ' ' +
			 'AND CCP_TIPODOCTO IN(''ANT'',''PCA'')'
			 
INSERT INTO CARTERA_COBROS_CB
EXEC (@query)

SET @query = 'SELECT 1,*, '+ CONVERT(VARCHAR(4),@idUsuario)+ ' FROM GA_Corporativa.dbo.cxc_refantypag ' +
				'WHERE rap_fecha BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''  '+
				'AND rap_idempresa = '''+ CONVERT(VARCHAR(4),@idEmpresa)+ ''' ' +
				'AND rap_numctabanc = '''+ @noCuenta +''' ' +  --@noCuenta --'00741820000195334667' --????
				'AND rap_idstatus <> 1'

INSERT INTO DOCTOSCOBRADOS_CB
EXEC (@query)

SET @query = 'SELECT CCP_TIPOPOL,CCP_CONSPOL,CCP_MES, '+ CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
			 'FROM CARTERA_COBROS_CB INNER JOIN DOCTOSCOBRADOS_CB ON CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS = rap_referencia COLLATE Modern_Spanish_CS_AS ' +
			 'AND CCP_IDPERSONA = rap_idpersona WHERE rap_cotped <> ''COTIZACION UNIVERSAL'' GROUP BY  CCP_TIPOPOL,CCP_CONSPOL,CCP_MES'

INSERT INTO COBROSCONCILIADOS_CONTROL_CB
EXEC (@query)

SET @query =  'SELECT CCP_TIPOPOL,CCP_CONSPOL,CCP_MES, '+ CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
				'FROM CARTERA_COBROS_CB INNER JOIN DOCTOSCOBRADOS_CB ON CCP_IDDOCTO COLLATE Modern_Spanish_CS_AS = rap_iddocto COLLATE Modern_Spanish_CS_AS ' +
				'AND CCP_IDPERSONA = rap_idpersona WHERE rap_cotped = ''COTIZACION UNIVERSAL'''

INSERT INTO COBROSCONCILIADOS_REFERENCIA_CB
EXEC (@query)
 

UPDATE CARGOS_COMPLETO_CB SET Tipo = 1 FROM CARGOS_COMPLETO_CB A
INNER JOIN COBROSCONCILIADOS_CONTROL_CB C ON  MOV_TIPOPOL = CCP_TIPOPOL AND MOV_MES = CCP_MES AND MOV_CONSPOL = CCP_CONSPOL

UPDATE CARGOS_COMPLETO_CB SET Tipo = 1 FROM CARGOS_COMPLETO_CB A
INNER JOIN COBROSCONCILIADOS_REFERENCIA_CB C ON MOV_TIPOPOL = CCP_TIPOPOL AND MOV_MES = CCP_MES AND MOV_CONSPOL = CCP_CONSPOL

--CARGOS EN CONTABILIDAD NO CONSIDERADOS EN BANCOS
SELECT @result_CargoContable = SUM(MOV_DEBE) --Cargos_Contabilidad_noBancos 
FROM CARGOS_COMPLETO_CB WHERE TIPO = 0
-------------------------------------------------------------------------Cálculos de Cargos Banco Bancomer--------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DELETE FROM CARGOSBANCOS_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM PAGOSRELACION_CB WHERE IDUSUARIO = @idUsuario
DELETE FROM PAGOSRELACIONFINAL_CB WHERE IDUSUARIO = @idUsuario

SET @query = 'SELECT *,0, ' + CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
			 'FROM Referencias.dbo.BANCOMER WHERE fechaOperacion BETWEEN '''+ @fechaElaboracion +''' AND '''+ @fechaCorte +'''  '+
			 'AND noCuenta = '''+ @noCuenta +''' AND esCargo = 1 '

INSERT INTO CARGOSBANCOS_CB
EXEC (@query)

SET @query = 'SELECT D.*, ' + CONVERT(VARCHAR(4),@idUsuario)+ ' ' +
				'FROM CARGOSBANCOS_CB C INNER JOIN [Pagos].[dbo].[PAG_REL_DOCTOS_BANCOS] D ON idBmer = idBanco_Registro ' +
				'WHERE D.idBanco = 1'  -----??????? BANCOMER = 1

INSERT INTO PAGOSRELACION_CB 
EXEC (@query)

SET @query = 'SELECT R.* '+
			 'FROM PAGOSRELACION_CB R INNER JOIN [cuentasxpagar].[dbo].[cxp_doctospagados] P ON R.dpa_iddoctopagado = P.dpa_iddoctopagado ' +
			 'WHERE dpa_pagoaplicado = 1 '

INSERT INTO PAGOSRELACIONFINAL_CB
EXEC (@query)

UPDATE CARGOSBANCOS_CB SET Tipo = 1 FROM CARGOSBANCOS_CB C INNER JOIN PAGOSRELACIONFINAL_CB P ON idBmer = idBanco_Registro

SELECT @totalCargoBancario = SUM(importe) --Cargos_Bancos_noContabilidad 
FROM CARGOSBANCOS_CB WHERE Tipo = 0  --NO CONCILIADOS

-------------------------------------------------------------Se consulta la información en la tabla de retorno--------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SELECT @result_AbonoContable tAbonoContable, 	   
	   @totalAbonoBancario tAbonoBancario, 
	   @result_CargoContable tCargoContable, 
	   @totalCargoBancario tCargoBancario
 									
END TRY
BEGIN CATCH
     SELECT ERROR_MESSAGE() + ' ' + ERROR_LINE() AS ERROR
END CATCH
go

