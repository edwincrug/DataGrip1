-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-05-17
-- Description:	Obtiene los registros punteados por grupo
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PUNTEO_DETALLE_GRUPO_SP]
	@grupo INT = 0
AS
BEGIN
	SELECT
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[idBmer]		= ABO.idBmer,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[referencia]	= ABO.referencia,
		[concepto]		= ABO.concepto + ' ' + ABO.refAmpliada,
		[cargo]			= CASE rpun_idCargo WHEN 0 THEN 0 ELSE ABO.importe END,
		[abono]			= CASE rpun_idAbono WHEN 0 THEN 0 ELSE ABO.importe END
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN [ABONOSBANCOS_CB] ABO ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = ABO.IDBanco
	WHERE rpun_tipo = 'B'
		  AND PUN.rpun_grupoPunteo = @grupo
	UNION ALL
	SELECT
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[idBmer]		= CAR.idBmer,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[referencia]	= CAR.referencia,
		[concepto]		= CAR.concepto + ' ' + CAR.refAmpliada,
		[cargo]			= CASE rpun_idCargo WHEN 0 THEN 0 ELSE CAR.importe END,
		[abono]			= CASE rpun_idAbono WHEN 0 THEN 0 ELSE CAR.importe END
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN [CARGOSBANCOS_CB] CAR ON PUN.rpun_idCargo = CAR.IDCARGOSBANCOS
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = CAR.IDBanco
	WHERE rpun_tipo = 'B'
		  AND PUN.rpun_grupoPunteo = @grupo;

	SELECT 
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[Identificador] = CAR.IDCARGOS_COMPLETO,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[fecha]			= CAR.MOV_FECHOPE,
		[tipoPoliza]	= CAR.MOV_TIPOPOL,
		[poliza]		= CAR.MOV_CONSPOL,
		[concepto]		= CAR.MOV_CONCEPTO,
		[cargo]			= CAR.MOV_DEBE,
		[abono]			= CAR.MOV_HABER,
		[idEmpresa]		= car.idEmpresa,
		[mes]			= car.MOV_MES,
		[anio]			= car.anio
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN [CARGOS_COMPLETO_CB] CAR ON PUN.rpun_idCargo = CAR.IDCARGOS_COMPLETO
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = CAR.idBanco
	WHERE rpun_tipo = 'C'
		  AND PUN.rpun_grupoPunteo = @grupo
	UNION ALL
	SELECT 
		[aplicado]      = PUN.rpun_idAplicado,
		[grupo]			= PUN.rpun_grupoPunteo,
		[Identificador] = ABO.IDABONOS_COMPLETO,
		[idBanco]		= BAN.idBanco,
		[banco]			= BAN.nombre,
		[fecha]			= ABO.MOV_FECHOPE,
		[tipoPoliza]	= ABO.MOV_TIPOPOL,
		[poliza]		= ABO.MOV_CONSPOL,
		[concepto]		= ABO.MOV_CONCEPTO,
		[cargo]			= ABO.MOV_DEBE,
		[abono]			= ABO.MOV_HABER,
		[idEmpresa]		= abo.idEmpresa,
		[mes]			= abo.MOV_MES,
		[anio]			= abo.anio
	FROM REGISTROS_PUNTEADOS PUN
	INNER JOIN [ABONOS_COMPLETO_CB] ABO ON PUN.rpun_idAbono = ABO.IDABONOS_COMPLETO
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = ABO.idBanco
	WHERE rpun_tipo = 'C'
		  AND PUN.rpun_grupoPunteo = @grupo;
END
go

