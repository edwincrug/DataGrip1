-- =============================================
-- Author:		Ing. Luis Antonio García Perrusquía 
-- Create date: 27/03/2018
-- Description:	Trae todos los cargos
--TEST EXECUTE [dbo].[SEL_ALL_CARGOS_BANCARIO]
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ALL_CARGOS_BANCARIO]

AS
BEGIN
	BEGIN TRY
		SELECT 
			[IDCARGOSBANCOS]
			,[idBmer]
			,[IDBanco]
			,[txtOrigen]
			,[registro]
			,[noMovimiento]
			,[referencia]
			,[concepto]
			,[refAmpliada]
			,[esCargo]
			,[importe]
			,[saldoOperativo]
			,[codigoLeyenda]
			,[oficinaOperadora]
			,[fechaOperacion]
			,[horaOperacion]
			,[fechaValor]
			,[fechaContable]
			,[estatus]
			,[noCuenta]
			,[estatusRevision]
			,[Tipo]
			,[idUsuario]
			,[idEmpresa]
			,[anio]
			,[fecha]
			,[idEstatus]
			,[idConciliado] 
	  FROM CARGOSBANCOS_CB WHERE Tipo = 1
	END TRY

	BEGIN CATCH
		SELECT msg = ERROR_MESSAGE();
	END CATCH
END
go

