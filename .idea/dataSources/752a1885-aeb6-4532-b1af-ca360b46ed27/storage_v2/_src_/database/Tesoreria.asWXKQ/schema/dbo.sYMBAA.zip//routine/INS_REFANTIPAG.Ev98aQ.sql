
CREATE PROCEDURE [dbo].[INS_REFANTIPAG]
@bankTableName varchar(100),
@currentBase varchar(50)
	
AS
BEGIN
/*Estse sp se ejecuta en la base de tesoreia*/
-- EXEC REFERENCIAS.DBO.[INS_REFANTIPAG_FROM_TESORERIA] @bankTableName ,@currentBase 
SELECT 1 AS success;
	
END
go

