-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create Date: 2018-07-05
-- Description:	Apertura de mes donde si no esta abierto por default se abrera el mes 6 
--[dbo].[PER_APERTURAPERIODO_SP] 11,1,'000000000112847361','20190715'
-- =============================================
CREATE PROCEDURE [dbo].[PER_APERTURAPERIODO_SP]
	@idEmpresa INT			 = 0,
	@idBanco INT			 = 0,
	@cuentaBanco VARCHAR(30) = '',
	@fechaActual VARCHAR(30) = ''
AS
BEGIN
	DECLARE @Default INT = MONTH(CONVERT( DATE, @fechaActual, 103 ));

	IF( @Default = 7 )
		BEGIN
			SET @Default = 6
		END
	
	IF NOT EXISTS( SELECT idEmpresa FROM [dbo].[PeriodoActivo] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @cuentaBanco )
		BEGIN
			INSERT INTO [dbo].[PeriodoActivo]
			SELECT
				[mec_numMes]		= @Default,
                [mec_anio]			= 2019,
				--[mec_anio]			= YEAR(CONVERT( DATE, @fechaActual, 103 )),
				[mec_conciliado]	= 0,
				[idEmpresa]			= @idEmpresa,
				[idBanco]			= @idBanco,
				[cuentaBancaria]	= @cuentaBanco;

			SELECT
				mec_numMes = @Default,
				mec_anio   = 2019,
                --mec_anio   = YEAR(CONVERT( DATE, @fechaActual, 103 )),
				mec_idMes  = @@IDENTITY
	
		END
	ELSE
		BEGIN
			SELECT mec_numMes, mec_anio, mec_idMes  FROM [dbo].[PeriodoActivo] WHERE idEmpresa = @idEmpresa AND idBanco = @idBanco AND cuentaBancaria = @cuentaBanco AND mec_conciliado = 0
		
		END
END



go

