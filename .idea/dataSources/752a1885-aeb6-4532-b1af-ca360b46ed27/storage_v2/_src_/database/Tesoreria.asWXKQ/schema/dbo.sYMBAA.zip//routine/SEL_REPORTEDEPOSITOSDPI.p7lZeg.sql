-- =============================================
-- Author:		Irving Solorio Garcia
-- Create date: 08/04/2020
-- Description:	Reporte DPIs
-- =============================================
-- [dbo].[SEL_REPORTEDEPOSITOSDPI] 4
CREATE PROCEDURE [dbo].[SEL_REPORTEDEPOSITOSDPI] 
 @idEmpresa INT

 AS
BEGIN



DECLARE @columns NVARCHAR(MAX), @columns2 NVARCHAR(MAX),@columns3 NVARCHAR(MAX), @sql VARCHAR(MAX);
SET @columns = N'';
SELECT @columns+=N', '+QUOTENAME([Name])
FROM
(
    select idBanco,numeroCuenta Name,cuenta from referencias.dbo.BancoCuenta where idEmpresa=@idEmpresa and activo=1
) AS x;
SET @columns2 = N'';
SELECT @columns2+=N', isnull('+QUOTENAME([Name])+',0.00) '+QUOTENAME(cuentaContable)
FROM
(
    select idBanco,numeroCuenta Name,cuenta, cuentaContable from referencias.dbo.BancoCuenta where idEmpresa=@idEmpresa and activo=1
) AS x;
SET @columns3 = N'';
SELECT @columns3+=N'+ isnull('+QUOTENAME([Name])+',0.00) '
FROM
(
    select idBanco,numeroCuenta Name,cuenta from referencias.dbo.BancoCuenta where idEmpresa=@idEmpresa and activo=1
) AS x;
--SELECT convert(nvarchar(10),fechaoperacion,103) AS [FECHA DE DEPOSITO],convert(nvarchar(10),fechasinidentificar,103) AS [FECHA SIN IDENTIFICAR],conceptocontable AS [DOCTO.], '+STUFF(@columns2, 1, 2, '')+','+STUFF(@columns3, 1, 2, '')+' SUMA,concepto AS [CONCEPTO] FROM (
SET @sql = N'
SELECT convert(nvarchar(10),fechaoperacion,103) AS [FECHA DE DEPOSITO],convert(nvarchar(10),fechasinidentificar,103) AS [FECHA SIN IDENTIFICAR],conceptocontable AS [DOCTO.], '+STUFF(@columns2, 1, 2, '')+','+STUFF(@columns3, 1, 2, '')+' SUMA,concepto AS [CONCEPTO],refAmpliada as [REFAMPLIADA] FROM (

SELECT 
    dpi.iddpi,abo.idbanco,abo.noCuenta,replace(cpun.concepto,''DEPOSITO NO IDENTIFICADO '','''') conceptocontable,abo.concepto,abo.importe,abo.fechaOperacion fechaOperacion,cpun.fechaope fechasinidentificar,abo.refAmpliada
	FROM DepositoBancarioDPI DPI 
	INNER JOIN ABONOSBANCOS_CB ABO ON DPI.idAbonoBanco = ABO.idBmer AND DPI.idEmpresa = ABO.idEmpresa AND DPI.idBanco = ABO.IDBanco
	INNER JOIN VW_REGISTROS_PUNTEADOS PUN ON PUN.rpun_idAbono = ABO.IDABONOSBANCOS AND PUN.rpun_tipo = ''B''
	inner join VW_REGISTROS_PUNTEADOS cpun on pun.rpun_grupoPunteo=cpun.rpun_grupoPunteo and cpun.rpun_tipo=''C''
	LEFT JOIN CancelaDPI CAN ON CAN.idDPI = DPI.idDPI
	WHERE DPI.idEmpresa ='+ convert(nvarchar(5),@idEmpresa)+'  and can.idCancelaDPI is null
	union all
	select d.idDpiAnterior iddpi,b.idbanco,b.numeroCuenta noCuenta,d.documento conceptocontable,d.referencia concepto,d.importe,d.fecha fechaOperacion,d.fechaIdentificado fechasinidentificar,'''' refAmpliada
	from [dbo].[dpiAnterior] d
	inner join referencias.dbo.BancoCuenta b on d.cuenta=b.numeroCuenta
	where b.idEmpresa='+convert(nvarchar(5),@idEmpresa)+' and isnull(cancelado,0)=0
	) AS j PIVOT (AVG(importe) FOR [noCuenta] in 
	   ('+STUFF(REPLACE(@columns, ', [', ',['), 1, 1, '')+')) AS p;';
print @sql
exec(@sql)

END
go

