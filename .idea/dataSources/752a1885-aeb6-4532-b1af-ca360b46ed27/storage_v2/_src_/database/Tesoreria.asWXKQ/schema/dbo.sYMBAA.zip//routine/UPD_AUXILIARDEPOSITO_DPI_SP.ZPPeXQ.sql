-- [UPD_AUXILIARDEPOSITO_DPI_SP] 73915,1,1,2
CREATE PROCEDURE [dbo].[UPD_AUXILIARDEPOSITO_DPI_SP]
	@idAbonoBanco INT,
	@idBanco INT,
	@idEmpresa INT,
	@idUsuario INT
AS
BEGIN
	--set transaction isolation level read uncommitted
	--BEGIN TRY
	--    BEGIN TRAN DPI
		
	--Se ejecuta la inserción de los datos recabados de la tabla correspondiente al banco seleccionado (Replica) 
	Declare @idAbono int, @NUMCTA varchar(50), @idDPI int
	
	SELECT 
		@idAbono = IDABONOSBANCOS, 
		@NUMCTA = noCuenta 
	FROM ABONOSBANCOS_CB 
	WHERE 	idBmer = @idAbonoBanco 
			AND idBanco = @idBanco

	
	IF EXISTS( SELECT idDPI FROM DepositoBancarioDPI WHERE idAbonoBanco = @idAbonoBanco AND idBanco = @idBanco )
		BEGIN
			SELECT 'Ya existe el dpi que quiere insertar' AS msg,0 success
		END
	ELSE
		BEGIN
			DECLARE @id INT=0
			exec  [dbo].[CreaDPI_INS]
						@idAbono ,
						@idBanco ,
						@idEmpresa ,
						'GMI',
						@idUsuario
			
	
			SELECT @id=id FROM ##TempDPI
		
			IF( @id > 0 )
				BEGIN
					INSERT INTO [dbo].[DepositoBancarioDPI]
												([idAbonoBanco]
												,[idBanco]
												,[idEmpresa]
												,[idEstatus]
												,[fechaRegistro]
												,[idUsuario])
								VALUES 
									   (@idAbonoBanco
									   ,@idBanco
									   ,@idEmpresa
									   ,1
									   ,GETDATE()
									   ,@idUsuario)
		
					EXEC [dbo].[BitacoraDPI_INS]  @idAbono,@idEmpresa,@idBanco,@NUMCTA,@id,1,'',@idUsuario
				
				 	SELECT 'SE INSERTARON LOS DATOS DPI DE BANCOS' AS msg, 1 success
		 		END
			ELSE
				BEGIN
					SELECT 'Ocurrió un problema al enviar el depósito a DPI' AS msg,0 success
					EXEC [dbo].[BitacoraDPI_INS]  @idAbono,@idEmpresa,@idBanco,@NUMCTA,@id,0,'',@idUsuario
				END
			-- COMMIT TRAN
			
			--END TRY
			--BEGIN CATCH
			--    PRINT 'In CATCH Block'
			--    IF(@@TRANCOUNT > 0)
			--        ROLLBACK TRAN DPI;
			
			--   select ERROR_MESSAGE() mensaje
			--END CATCH			
		END			
		IF OBJECT_ID('tempdb..##TempDPI') IS NOT NULL
		    DROP TABLE ##TempDPI
		END
go

