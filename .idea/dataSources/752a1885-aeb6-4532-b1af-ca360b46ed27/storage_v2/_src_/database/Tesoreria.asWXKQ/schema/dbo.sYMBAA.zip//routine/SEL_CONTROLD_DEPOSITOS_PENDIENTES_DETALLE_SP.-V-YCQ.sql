
CREATE procedure [dbo].[SEL_CONTROLD_DEPOSITOS_PENDIENTES_DETALLE_SP]
@idReferencia as int 

AS
BEGIN
select 
* ,
(select dep_nombre from  [ControlAplicaciones].[dbo].[cat_departamentos] where dRef.idSucursal =  suc_idsucursal  and dRef.idDepartamento = dep_iddepartamento) depto,
(select suc_nombre from [ControlAplicaciones].[dbo].[cat_sucursales]  where dRef.idSucursal =  suc_idsucursal    ) sucursal
from DetalleReferencia  dRef
where idreferencia=@idReferencia  

END
go

