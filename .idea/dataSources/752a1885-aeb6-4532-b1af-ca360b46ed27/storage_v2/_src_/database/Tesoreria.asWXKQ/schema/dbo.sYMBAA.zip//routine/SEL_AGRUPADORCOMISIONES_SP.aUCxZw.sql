
CREATE PROCEDURE [dbo].[SEL_AGRUPADORCOMISIONES_SP]
	@idEmpresa as INT,
	@esGrupo as INT,
	@idSucursal as INT
AS
BEGIN
	DECLARE @Consecutivo INT = 0;

	-- Get Last 'Agrupador'
	DECLARE @UltimoAgrupador NUMERIC(18,0) = (SELECT TOP 1 agrupador FROM [InteresComision] WHERE idEmpresa = @idEmpresa)
	DECLARE @Agrupador NUMERIC(18,0) = 0;
	IF( @UltimoAgrupador IS NULL )
		BEGIN SET @Agrupador = 1; END
	ELSE
		BEGIN SET @Agrupador = (SELECT MAX(agrupador) FROM [InteresComision] WHERE idEmpresa = @idEmpresa) + 1; END
	PRINT( 'Agrupador ' + CONVERT(VARCHAR(5),@Agrupador) );
	-- /End Get Last 'Agrupador'


	-- Get Last 'idSucursalMatriz'
	IF (@esGrupo = 1)
		BEGIN
			SET @idSucursal = ( SELECT sucursal_matriz FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE emp_idempresa = @idEmpresa AND tipo = 2 );
		END
	PRINT( 'idSucursal Aplica ' + CONVERT(VARCHAR(5),@idSucursal) );

	-- Get Last 'Consecutivo'
	SET @Consecutivo = ( SELECT MAX(cid_consecutivo) FROM [cxp_comisionesinteresesdet] WHERE idSucursalAplica = @idSucursal);
	IF( @Consecutivo IS NULL )
		BEGIN
			SET @Consecutivo = 0;
		END
	PRINT( 'Consecutivo ' + CONVERT(VARCHAR(5),@Consecutivo) );

	SELECT 'Agrupador' = @Agrupador, 'Consecutivo' = @Consecutivo, 'idSucursalAplica' = @idSucursal;
END
go

