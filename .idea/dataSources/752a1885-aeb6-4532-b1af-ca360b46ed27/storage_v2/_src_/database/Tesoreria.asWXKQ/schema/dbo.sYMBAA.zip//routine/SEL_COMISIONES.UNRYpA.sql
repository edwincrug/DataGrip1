/*
MODIFICACION: Se agregaron 2 comillas simples en las lineas 41 y 42 para pasar como texto el valor del numero de cuenta
FECHA: 10-04-2019
AUTOR: Roberto Almanza
*/
-- [SEL_COMISIONES] 2, '70037137187', 10, '2019'
CREATE PROCEDURE  [dbo].[SEL_COMISIONES]
	@idBanco INT=0,
	@noCuenta varchar(50),
	@mes varchar(20) ,
	@anio varchar(20) 
AS
BEGIN
	DECLARE @NombreBanco VARCHAR(15) = (SELECT nombre FROM [referencias].[dbo].[Banco] WHERE idBanco = @idBanco);
	DECLARE @Query NVARCHAR(MAX);

	SET @Query = 'SELECT idbmer idDepositoBanco
						 ,CD.idBanco
						 ,idBmer
						 ,'''+ @NombreBanco +''' banco
						 ,[txtOrigen]
						 ,[noCuenta]
						 ,[concepto]
						 ,[importe] as abono
						 ,0 as cargo
						 ,[saldoOperativo]
						 ,[referencia]
						 ,[refAmpliada]
						 ,convert(varchar(20),[fechaOperacion],103) [fechaOperacion]
						 ,[horaOperacion]
						 ,[oficinaOperadora]
					FROM [controlDepositosView] CD
					INNER JOIN [referencias].[dbo].[CodigoIdentificacion] CI ON CD.codigoLeyenda = CI.CodigoBanco AND CD.IDBanco = CI.IDBanco
					LEFT JOIN [InteresComision] COM ON CD.idBmer = COM.comisionID
					WHERE CD.idBanco = ' + CONVERT(VARCHAR(2),@idBanco) 
						+ ' AND noCuenta = ''' + @noCuenta 
						+ ''' AND CI.Tipo = 1 
							AND COM.interesComisionID IS NULL '
							if @idBanco=2
							SET @Query= @Query + 'AND CD.concepto LIKE ''%COBRO COMI%'' 
							'
							else
							SET @Query= @Query + 'AND CD.refAmpliada NOT LIKE ''COBRO IMP%'' 
							AND CI.Descripcion NOT LIKE ''%IVA%''
							AND CD.refAmpliada NOT LIKE ''%IVA%''
							AND CD.refAmpliada NOT LIKE ''INTERE%''';

	SET @Query = @Query + ' AND  month(fechaOperacion) = ''' + @mes + ''' and year(fechaOperacion) =''' + @anio + '''';
	SET @Query = @Query + ' ORDER BY idDepositoBanco';

	PRINT( @Query );
	EXECUTE (@Query);		
END
-- SELECT * FROM referencias.DBO.Banamex WHERE SLFechaTransaccion > '01/10/2019' and SLCodigoTransaccion in(
--select CodigoBanco from referencias.DBO.CodigoIdentificacion WHERE IDBanco = 2 and Tipo = 1)
--and noCuenta = '02457776589'
go

