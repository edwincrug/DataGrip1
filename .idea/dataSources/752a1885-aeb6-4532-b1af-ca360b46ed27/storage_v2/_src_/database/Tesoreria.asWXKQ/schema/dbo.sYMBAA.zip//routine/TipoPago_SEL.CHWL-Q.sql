
-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <21/01/2019>
-- Description:	<Tipo Forma de pago no definida refantypaq>
-- =============================================
--[dbo].[TipoPago_SEL]
CREATE PROCEDURE [dbo].[TipoPago_SEL]
				   

AS
BEGIN

SELECT id, FormaPago
  FROM (VALUES ('38','CHEQUE')
             , ('02','TRANSFERENCIA')
       ) x (id, FormaPago)
END
go

