-- =============================================
-- Author:		<Author,,Rodrigo Olivares>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--MODIFICADO
-- Author:		<Ing. Luis Antonio Garcia Perrusquia>
-- Create date: <SP modificado el dia 12/07/2018>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPOSITOSDPI_H] 
/*
	SEL_DEPOSITOSDPI_H 1, '000000000195334667','2018-09-01', 1
*/
	-- Add the parameters for the stored procedure here
@idEmpresa INT = 0,
@cuentaBancaria VARCHAR(50) = 0,
@fechaElaboracion VARCHAR(12) = '',
@idHistorico NUMERIC(18,0) = 0
AS
BEGIN
	SELECT 
		DPI.idAbonoBanco AS  idDepositoBanco
		,DEPOSITO.IDBanco AS banco
		,DEPOSITO.txtOrigen AS txtOrigen
		,DEPOSITO.noCuenta AS noCuenta
		,DEPOSITO.concepto AS concepto
		,DEPOSITO.importe AS abono
		,0 as cargo
		,DEPOSITO.saldoOperativo AS saldoOperativo
		,DEPOSITO.referencia AS referencia
		,DEPOSITO.fechaOperacion AS fechaOperacion
		,DEPOSITO.horaOperacion AS horaOperacion
		,DEPOSITO.oficinaOperadora AS oficinaOperadora
		,BAN.nombre AS bancoNombre
	FROM DepositoBancarioDPI_H DPI
	INNER JOIN ABONOSBANCOS_CB_H DEPOSITO ON DPI.idAbonoBanco = DEPOSITO.idBmer 
											 AND DPI.idBanco = DEPOSITO.IDBanco
											 AND DEPOSITO.idHistorico = @idHistorico
	INNER JOIN [referencias].[dbo].[Banco] BAN ON BAN.idBanco = DPI.idBanco
	WHERE DPI.idHistorico = @idHistorico
END

go

