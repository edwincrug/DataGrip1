-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-07-03
-- Description:	Verifica si desde BPRO se han modificado registros
-- =============================================
CREATE PROCEDURE [dbo].[CHECK_DATOSMODIFICADOS_SP]
	@idEmpresa INT		  = 2,
	@idBanco INT		  = 1,
	@numCenta VARCHAR(20) = '1100-0020-0002-0001',
	@anio INT			  = 2018
AS
BEGIN
	DECLARE @ipLocal VARCHAR(15) = (
		SELECT	dec.local_net_address
		FROM	sys.dm_exec_connections AS dec
		WHERE	dec.session_id = @@SPID
	);

	DECLARE @Base VARCHAR(300) = ''
	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			SET @Base = (SELECT '[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
		END
	ELSE
		BEGIN
			SET @Base = (SELECT '[' + ip_servidor + '].[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
		END


	DECLARE @UPD_Abono VARCHAR(1000) = 
	'SELECT
		AC.MOV_HABER, MOV.MOV_HABER,
		AC.MOV_CONCEPTO, MOV.MOV_CONCEPTO,
		AC.MOV_CVEUSU, MOV.MOV_CVEUSU,
		AC.MOV_FECHOPE, MOV.MOV_FECHOPE
	FROM ABONOS_COMPLETO_CB AC 
	INNER JOIN '+ @Base +' MOV ON MOV.MOV_CONSPOL = AC.MOV_CONSPOL 
																					AND MOV.MOV_MES = AC.MOV_MES
																					AND MOV.MOV_TIPOPOL COLLATE Modern_Spanish_CI_AS = AC.MOV_TIPOPOL
																					AND MOV.MOV_CONSMOV = AC.MOV_CONSMOV
																					AND MOV.MOV_HABER <> 0
																					AND MOV.MOV_HABER != AC.MOV_HABER 
	WHERE AC.idEmpresa = ' + CONVERT( VARCHAR(3), @idEmpresa ) + ' AND AC.idBanco = ' + CONVERT( VARCHAR(3), @idBanco ) + ' AND AC.MOV_NUMCTA = ''' + @numCenta + ''''
	PRINT('@UPD_Abono =>');
	PRINT(@UPD_Abono);
	EXEC(@UPD_Abono);

	DECLARE @UPD_Cargo VARCHAR(1000) = 
	'SELECT
		CC.MOV_DEBE, MOV.MOV_DEBE,
		CC.MOV_CONCEPTO, MOV.MOV_CONCEPTO,
		CC.MOV_CVEUSU, MOV.MOV_CVEUSU,
		CC.MOV_FECHOPE, MOV.MOV_FECHOPE
	FROM CARGOS_COMPLETO_CB CC 
	INNER JOIN '+ @Base +' MOV ON MOV.MOV_CONSPOL = CC.MOV_CONSPOL 
																					AND MOV.MOV_MES = CC.MOV_MES
																					AND MOV.MOV_TIPOPOL COLLATE Modern_Spanish_CI_AS = CC.MOV_TIPOPOL
																					AND MOV.MOV_CONSMOV = CC.MOV_CONSMOV
																					AND MOV.MOV_DEBE <> 0
																					AND MOV.MOV_DEBE != CC.MOV_DEBE 
	WHERE CC.idEmpresa = ' + CONVERT( VARCHAR(3), @idEmpresa ) + ' AND CC.idBanco = ' + CONVERT( VARCHAR(3), @idBanco ) + ' AND CC.MOV_NUMCTA = ''' + @numCenta + ''''
	PRINT('@UPD_Cargo =>');
	PRINT(@UPD_Cargo);
	EXEC(@UPD_Cargo);
END
go

