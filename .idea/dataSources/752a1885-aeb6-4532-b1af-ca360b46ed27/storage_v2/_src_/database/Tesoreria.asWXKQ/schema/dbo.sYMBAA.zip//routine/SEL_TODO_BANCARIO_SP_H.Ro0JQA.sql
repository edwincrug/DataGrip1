-- =============================================
-- Author:    	Ing. Luis Antonio Garcia Perrusquia
-- Create date: 21/05/2018
-- Description:	Trae todos los registros para colocarlos en los no conciliados Historico
-- =============================================
--[dbo].[SEL_TODO_BANCARIO_SP_H] 7,1,'109100990201','2019-01-01',1,5607
CREATE PROCEDURE [dbo].[SEL_TODO_BANCARIO_SP_H]
/*
	[SEL_TODO_BANCARIO_SP_H] 1,1,'z','2018-06-01', 1, 48

*/
@idBanco int,
@idEstatus int,
@noCuenta varchar(50),
@fechaElaboracion varchar(30),
@idEmpresa int,
@idHistorico int

AS
BEGIN

  DECLARE @Meses TABLE (
    ID int IDENTITY (1, 1),
    PAR_IDENPARA varchar(10),
    PAR_DESCRIP2 varchar(20)
  )
  DECLARE @mesActual int,
          @mesActivo int;

 -- SELECT
 --   @mesActual = DATEPART(MONTH, REPLACE(@fechaElaboracion, '-', ''))
	--PRINT @mesActual
 -- INSERT INTO @Meses
 --   SELECT
 --     PAR_IDENPARA,
 --     PAR_DESCRIP2
 --   FROM GAAU_Concentra.dbo.PNC_PARAMETR
 --   WHERE PAR_TIPOPARA = 'mcerrcon'
 --   AND PAR_IDENPARA LIKE '' + CONVERT(varchar(10), DATEPART(YEAR, REPLACE(@fechaElaboracion, '-', ''))) + '%'
 --   AND PAR_DESCRIP1 = '01'


  SELECT
    @mesActivo =
                CASE PAR_DESCRIP2
                  WHEN 'ABIERTO' THEN 1
                  WHEN 'CERRADO' THEN 0
                END
  FROM @Meses
  WHERE PAR_IDENPARA = CONVERT(varchar(10), DATEPART(YEAR, REPLACE(@fechaElaboracion, '-', '')))

  IF (SELECT
      PAR_DESCRIP2
    FROM @Meses
    WHERE ID = (SELECT
      ID - 1
    FROM @Meses
    WHERE PAR_IDENPARA = REPLACE(@fechaElaboracion, '-', '')))
    = 'ABIERTO'
  BEGIN
    SELECT
      @mesActivo = 0
  END

  IF (@mesActivo = 1)
  BEGIN
    SET @mesActual = 14
  END

---------------------------------------------------------------
  SET LANGUAGE Español
   SELECT
       ABO.[IDABONOSBANCOS_H]
      ,ABO.[IDABONOSBANCOS]
      ,ABO.[idBmer]
      ,ABO.[IDBanco]
      ,ABO.[txtOrigen]
      ,ABO.[registro]
      ,ABO.[noMovimiento]
      ,ABO.[referencia]
      ,ABO.[concepto]
      ,ABO.[refAmpliada]
      ,ABO.[esCargo]
      ,ABO.[importe]
      ,ABO.[saldoOperativo]
      ,ABO.[codigoLeyenda]
      ,ABO.[oficinaOperadora]
      ,ABO.[fechaOperacion]
      ,ABO.[horaOperacion]
      ,ABO.[fechaValor]
      ,ABO.[fechaContable]
      ,ABO.[estatus]
      ,ABO.[noCuenta]
      ,ABO.[estatusRevision]
      ,ABO.[Tipo]
      ,ABO.[idUsuario]
      ,ABO.[idEmpresa]
      ,ABO.[anio]
      ,ABO.[fecha]
      ,ABO.[idEstatus]
      ,ABO.[idConciliado]
      ,ABO.[idHistorico],
      '' abono,
      '' cargo,
      0 fechaAnterior,
      '' color,
      ABO.IDBanco idBanco,
      UPPER(DATENAME(MONTH, CONVERT(date, fechaOperacion, 103))) MES,
      UPPER(DATENAME(YEAR, CONVERT(date, fechaOperacion, 103))) anio
    FROM ABONOSBANCOS_CB_H ABO  --CARGOS
    LEFT JOIN [REGISTROS_PUNTEADOS_H] PUN
      ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono 
		 AND PUN.idHistorico = @idHistorico
		 AND PUN.rpun_tipo = 'B'
    LEFT JOIN [DepositoBancarioDPI_H] DPI
		ON  ABO.idBmer = DPI.idAbonoBanco
			AND DPI.idHistorico = @idHistorico
    WHERE   ABO.noCuenta = @noCuenta 
			AND ABO.idEmpresa = @idEmpresa 
			AND ABO.IDBanco = @idBanco
			AND ABO.idEstatus = 0
		--	AND month(ABO.fechaOperacion)= month(CONVERT(DATE, @fechaElaboracion, 23))
			AND PUN.rpun_idPunteado IS NULL 
			AND DPI.idDPI IS NULL
			AND ABO.idHistorico = @idHistorico
    
    UNION ALL
    
    SELECT
       CAR.[IDCARGOSBANCOS_H]
      ,CAR.[IDCARGOSBANCOS]
      ,CAR.[idBmer]
      ,CAR.[IDBanco]
      ,CAR.[txtOrigen]
      ,CAR.[registro]
      ,CAR.[noMovimiento]
      ,CAR.[referencia]
      ,CAR.[concepto]
      ,CAR.[refAmpliada]
      ,CAR.[esCargo]
      ,CAR.[importe]
      ,CAR.[saldoOperativo]
      ,CAR.[codigoLeyenda]
      ,CAR.[oficinaOperadora]
      ,CAR.[fechaOperacion]
      ,CAR.[horaOperacion]
      ,CAR.[fechaValor]
      ,CAR.[fechaContable]
      ,CAR.[estatus]
      ,CAR.[noCuenta]
      ,CAR.[estatusRevision]
      ,CAR.[Tipo]
      ,CAR.[idUsuario]
      ,CAR.[idEmpresa]
      ,CAR.[anio]
      ,CAR.[fecha]
      ,CAR.[idEstatus]
      ,CAR.[idConciliado]
      ,CAR.[idHistorico],
      '' abono,
      '' cargo,
      0 fechaAnterior,
      '' color,
      CAR.IDBanco idBanco,
      UPPER(DATENAME(MONTH, CONVERT(date, fechaOperacion, 103))) MES,
      UPPER(DATENAME(YEAR, CONVERT(date, fechaOperacion, 103))) anio
    FROM CARGOSBANCOS_CB_H CAR  --CARGOS
    LEFT JOIN [REGISTROS_PUNTEADOS_H] PUN
      ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo
		 AND PUN.idHistorico = @idHistorico
		 AND PUN.rpun_tipo = 'B'
    LEFT JOIN [DepositoBancarioDPI_H] DPI
		ON  CAR.IDCARGOSBANCOS = DPI.idAbonoBanco
			AND DPI.idHistorico = @idHistorico
    WHERE   CAR.noCuenta = @noCuenta 
			AND CAR.idEmpresa = @idEmpresa 
			AND CAR.IDBanco = @idBanco
			AND CAR.idEstatus = 0
			AND month(CAR.fechaOperacion) = month(CONVERT(DATE, @fechaElaboracion, 23))
			AND PUN.rpun_idPunteado IS NULL 
			AND DPI.idDPI IS NULL
			AND CAR.idHistorico = @idHistorico
END
go

