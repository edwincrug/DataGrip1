
-- [SEL_INTERESCOMISION_SP] 2, 9, 2,11,2019
CREATE PROCEDURE [dbo].[SEL_INTERESCOMISION_SP]
	@Estatus INT = 1,
	@idEmpresa INT = 1,
	@idBanco INT = 1,
	@mes varchar(20) ,
	@anio varchar(20) 
AS
BEGIN
	IF(@Estatus = 1)
		BEGIN
			IF (@idBanco = 1) -- Bancomer
				BEGIN 
					SELECT 
						comision.agrupador,
						comisionID,
						comSaldoOperativo,
						comBanco,
						comNoCuenta,
						comAbono,
						comConcepto,
						comReferencia,
						comision.interesComisionID,
						intSaldoOperativo,
						intBanco,
						intNoCuenta,
						intAbono,
						intConcepto,
						intReferencia,
						convert(nvarchar(10),comision.fechaoperacion,103) fechaoperacion,
						convert(nvarchar(10),comision.fecha,103) fechaaplicado
					 FROM 
					(
						SELECT 
							I.interesComisionID, 
							I.comisionID, 
							SaldoOperativo as comSaldoOperativo, 
							'Bancomer'  as comBanco,	
							NoCuenta as comNoCuenta, 
							importe  as comAbono, 
							Concepto as comConcepto,	
							Referencia as comReferencia, 
							I.agrupador,
							b.fechaOperacion,
							i.fecha
						FROM referencias.dbo.Bancomer B
						INNER JOIN InteresComision I ON B.idBmer = I.comisionID AND statusID = @Estatus AND idEmpresa = @idEmpresa)AS comision
						INNER JOIN (SELECT 
										I.interesComisionID, 
										SaldoOperativo as intSaldoOperativo, 
										'Bancomer' as intBanco, 
										NoCuenta as intNoCuenta, 
										importe  as intAbono, 
										Concepto as intConcepto, 
										Referencia as intReferencia, 
										I.agrupador
									FROM referencias.dbo.Bancomer B
									INNER JOIN InteresComision I ON B.idBmer = I.interesID AND statusID = @Estatus AND idEmpresa = @idEmpresa AND bancoID = @idBanco
									where month(b.fechaOperacion)=convert(int,@mes) and year(b.fechaOperacion)=convert(int,@anio)
									) AS interes
					ON comision.interesComisionID= interes.interesComisionID
					
					ORDER BY comision.interesComisionID DESC;
				END
			ELSE IF (@idBanco = 2) -- Banamex
				BEGIN
					SELECT 
						comision.agrupador,
						comisionID,
						comSaldoOperativo,
						comBanco,
						comNoCuenta,
						comAbono,
						comConcepto,
						comReferencia,
						comision.interesComisionID,
						intSaldoOperativo,
						intBanco,
						intNoCuenta,
						intAbono,
						intConcepto,
						intReferencia,
						convert(nvarchar(10),comision.fechaoperacion,103) fechaoperacion,
						convert(nvarchar(10),comision.fecha,103) fechaaplicado
					 FROM 
					(
						SELECT  I.interesComisionID
							, I.comisionID
							, 0 as comSaldoOperativo
							, 'Banamex' as comBanco
							, noCuenta as comNoCuenta
							, importe as comAbono
							, bmex.concepto as comConcepto
							, bmex.referencia as comReferencia
							, I.agrupador,
							Bmex.fechaOperacion fechaOperacion,
							i.fecha
						FROM (select * from ABONOSBANCOS_CB where idbanco=2 union all select * from CARGOSBANCOS_CB where IDBanco=2)  BMEX 
						INNER JOIN InteresComision I ON BMEX.idBmer = I.comisionID AND bmex.idEmpresa = I.idEmpresa and bmex.idEmpresa = @idEmpresa)AS comision
						INNER JOIN (SELECT  I.interesComisionID
							, 0 as intSaldoOperativo
							, 'Banamex' as intBanco
							, noCuenta as intNoCuenta
							, importe  as intAbono
							, bmex.concepto as intConcepto
							,  bmex.referencia as intReferencia
							, I.agrupador
					FROM (select * from ABONOSBANCOS_CB where idbanco=2 union all select * from CARGOSBANCOS_CB where IDBanco=2) BMEX 
					INNER JOIN InteresComision I ON BMEX.idBmer = I.interesID AND statusID = @Estatus AND bmex.idEmpresa = @idEmpresa AND bancoID = @idBanco
					where month(Bmex.fechaOperacion)=convert(int,@mes) and year(Bmex.fechaOperacion)=convert(int,@anio)
					) AS interes
					ON comision.interesComisionID= interes.interesComisionID
					
					ORDER BY comision.interesComisionID DESC;
				END
			ELSE IF (@idBanco = 3) -- Santander
				BEGIN
					SELECT 
						comision.agrupador,
						comisionID,
						comSaldoOperativo,
						comBanco,
						comNoCuenta,
						comAbono,
						comConcepto,
						comReferencia,
						comision.interesComisionID,
						intSaldoOperativo,
						intBanco,
						intNoCuenta,
						intAbono,
						intConcepto,
						intReferencia,
						convert(nvarchar(10),comision.fechaoperacion,103) fechaoperacion,
						convert(nvarchar(10),comision.fecha,103) fechaaplicado
					 FROM 
					(
						SELECT 
							I.interesComisionID, 
							I.comisionID, 
							S.saldo as comSaldoOperativo, 
							'Santander' as comBanco, 
							noCuenta as comNoCuenta, 
							importe as comAbono, 
							concepto as comConcepto,	
							referencia as comReferencia, 
							I.agrupador,
							s.fechaMovimiento fechaOperacion,
							i.fecha
						FROM referencias.dbo.Santander S
						INNER JOIN InteresComision I ON S.idSantander = I.comisionID AND statusID = @Estatus AND idEmpresa = @idEmpresa
						where month(s.fechaMovimiento)=convert(int,@mes) and year(s.fechaMovimiento)=convert(int,@anio))AS comision
						INNER JOIN (SELECT  
										I.interesComisionID, 
										S.saldo as intSaldoOperativo, 
										'Santander' as intBanco, 
										noCuenta as intNoCuenta, 
										importe  as intAbono, 
										concepto as intConcepto, 
										referencia as intReferencia, 
										I.agrupador 
									FROM referencias.dbo.Santander S
									INNER JOIN InteresComision I ON S.idSantander = I.interesID AND statusID = @Estatus AND idEmpresa = @idEmpresa AND bancoID = @idBanco
									where month(s.fechaMovimiento)=convert(int,@mes) and year(s.fechaMovimiento)=convert(int,@anio)) AS interes
					ON comision.interesComisionID= interes.interesComisionID
					ORDER BY comision.interesComisionID DESC;
				END
		END
	ELSE
		BEGIN
			IF (@idBanco = 1) -- Bancomer
				BEGIN 
					SELECT 
						comision.agrupador,
						comisionID,
						comSaldoOperativo,
						comBanco,
						comNoCuenta,
						comAbono,
						comConcepto,
						comReferencia,
						comision.interesComisionID,
						intSaldoOperativo,
						intBanco,
						intNoCuenta,
						intAbono,
						intConcepto,
						intReferencia,
						comision.coi_estatus estatusBPRO,
						convert(nvarchar(10),comision.fechaoperacion,103) fechaoperacion,
						convert(nvarchar(10),comision.fecha,103) fechaaplicado
					 FROM 
					(
						SELECT 
							I.interesComisionID, 
							I.comisionID, 
							SaldoOperativo as comSaldoOperativo, 
							'Bancomer'  as comBanco,	
							NoCuenta as comNoCuenta, 
							importe  as comAbono, 
							Concepto as comConcepto,	
							Referencia as comReferencia, 
							I.agrupador,
							CXP.coi_estatus,
							b.fechaOperacion fechaOperacion,
							i.fecha
						FROM referencias.dbo.Bancomer B
						INNER JOIN InteresComision I ON B.idBmer = I.comisionID AND statusID = @Estatus AND idEmpresa = @idEmpresa 
						INNER JOIN cxp_comisionesintereses CI ON CI.interesComisionID = I.interesComisionID
						INNER JOIN [cuentasxpagar].[dbo].[cxp_comisionesintereses] CXP ON CXP.coi_idcomisionesintereses = CI.coi_idcomisionesinteresesBPRO
						where month(b.fechaOperacion)=convert(int,@mes) and year(b.fechaOperacion)=convert(int,@anio)
						)AS comision
						INNER JOIN (SELECT 
										I.interesComisionID, 
										SaldoOperativo as intSaldoOperativo, 
										'Bancomer' as intBanco, 
										NoCuenta as intNoCuenta, 
										importe  as intAbono, 
										Concepto as intConcepto, 
										Referencia as intReferencia, 
										I.agrupador,
										CXP.coi_estatus,
										b.fechaOperacion
									FROM referencias.dbo.Bancomer B
									INNER JOIN InteresComision I ON B.idBmer = I.interesID AND statusID = @Estatus AND idEmpresa = @idEmpresa AND bancoID = @idBanco 
									INNER JOIN cxp_comisionesintereses CI ON CI.interesComisionID = I.interesComisionID
									INNER JOIN [cuentasxpagar].[dbo].[cxp_comisionesintereses] CXP ON CXP.coi_idcomisionesintereses = CI.coi_idcomisionesinteresesBPRO
									where month(b.fechaOperacion)=convert(int,@mes) and year(b.fechaOperacion)=convert(int,@anio)
									) AS interes
					ON comision.interesComisionID= interes.interesComisionID
					ORDER BY comision.interesComisionID DESC;
				END
			ELSE IF (@idBanco = 2) -- Banamex
				BEGIN
							SELECT 
						comision.agrupador,
						comisionID,
						comSaldoOperativo,
						comBanco,
						comNoCuenta,
						comAbono,
						comConcepto,
						comReferencia,
						comision.interesComisionID,
						intSaldoOperativo,
						intBanco,
						intNoCuenta,
						intAbono,
						intConcepto,
						intReferencia,
						convert(nvarchar(10),comision.fechaoperacion,103) fechaoperacion,
						convert(nvarchar(10),comision.fecha,103) fechaaplicado
					 FROM 
					(
						SELECT  I.interesComisionID
							, I.comisionID
							, 0 as comSaldoOperativo
							, 'Banamex' as comBanco
							, noCuenta as comNoCuenta
							, importe as comAbono
							, bmex.concepto as comConcepto
							, bmex.referencia as comReferencia
							, I.agrupador,
							Bmex.fechaOperacion fechaOperacion,
							i.fecha
						FROM (select * from ABONOSBANCOS_CB where idbanco=2 union all select * from CARGOSBANCOS_CB where IDBanco=2)  BMEX 
						INNER JOIN InteresComision I ON BMEX.idBmer = I.comisionID AND bmex.idEmpresa = I.idEmpresa and bmex.idEmpresa = @idEmpresa)AS comision
						INNER JOIN (SELECT  I.interesComisionID
							, 0 as intSaldoOperativo
							, 'Banamex' as intBanco
							, noCuenta as intNoCuenta
							, importe  as intAbono
							, bmex.concepto as intConcepto
							,  bmex.referencia as intReferencia
							, I.agrupador
					FROM (select * from ABONOSBANCOS_CB where idbanco=2 union all select * from CARGOSBANCOS_CB where IDBanco=2) BMEX 
					INNER JOIN InteresComision I ON BMEX.idBmer = I.interesID AND statusID = @Estatus AND bmex.idEmpresa = @idEmpresa AND bancoID = @idBanco
					where month(Bmex.fechaOperacion)=convert(int,@mes) and year(Bmex.fechaOperacion)=convert(int,@anio)
					) AS interes
					ON comision.interesComisionID= interes.interesComisionID
					
					ORDER BY comision.interesComisionID DESC;
				END
			ELSE IF (@idBanco = 3) -- Santander
				BEGIN
					SELECT 
						comision.agrupador,
						comisionID,
						comSaldoOperativo,
						comBanco,
						comNoCuenta,
						comAbono,
						comConcepto,
						comReferencia,
						comision.interesComisionID,
						intSaldoOperativo,
						intBanco,
						intNoCuenta,
						intAbono,
						intConcepto,
						intReferencia,
						comision.coi_estatus estatusBPRO,
						convert(nvarchar(10),comision.fechaoperacion,103) fechaoperacion,
						convert(nvarchar(10),comision.fecha,103) fechaaplicado
					 FROM 
					(
						SELECT 
							I.interesComisionID, 
							I.comisionID, 
							S.saldo as comSaldoOperativo, 
							'Santander' as comBanco, 
							noCuenta as comNoCuenta, 
							importe as comAbono, 
							concepto as comConcepto,	
							referencia as comReferencia, 
							I.agrupador,
							CXP.coi_estatus,
							s.fechaMovimiento fechaOperacion,
							i.fecha
						FROM referencias.dbo.Santander S
						INNER JOIN InteresComision I ON S.idSantander = I.comisionID AND statusID = @Estatus AND idEmpresa = @idEmpresa 
						INNER JOIN cxp_comisionesintereses CI ON CI.interesComisionID = I.interesComisionID
						INNER JOIN [cuentasxpagar].[dbo].[cxp_comisionesintereses] CXP ON CXP.coi_idcomisionesintereses = CI.coi_idcomisionesinteresesBPRO
						where month(s.fechaMovimiento)=convert(int,@mes) and year(s.fechaMovimiento)=convert(int,@anio))AS comision
						INNER JOIN (SELECT  
										I.interesComisionID, 
										S.saldo as intSaldoOperativo, 
										'Santander' as intBanco, 
										noCuenta as intNoCuenta, 
										importe  as intAbono, 
										concepto as intConcepto, 
										referencia as intReferencia, 
										I.agrupador 
									FROM referencias.dbo.Santander S
									INNER JOIN InteresComision I ON S.idSantander = I.interesID AND statusID = @Estatus AND idEmpresa = @idEmpresa AND bancoID = @idBanco 
									INNER JOIN cxp_comisionesintereses CI ON CI.interesComisionID = I.interesComisionID
									INNER JOIN [cuentasxpagar].[dbo].[cxp_comisionesintereses] CXP ON CXP.coi_idcomisionesintereses = CI.coi_idcomisionesinteresesBPRO
									where month(s.fechaMovimiento)=convert(int,@mes) and year(s.fechaMovimiento)=convert(int,@anio)) AS interes
					ON comision.interesComisionID= interes.interesComisionID

					ORDER BY comision.interesComisionID DESC;
				END
		END
END
go

