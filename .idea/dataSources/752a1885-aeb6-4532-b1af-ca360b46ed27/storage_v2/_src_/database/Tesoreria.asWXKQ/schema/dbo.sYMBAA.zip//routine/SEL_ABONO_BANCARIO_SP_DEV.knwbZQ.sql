
-- [dbo].[SEL_ABONO_BANCARIO_SP_DEV] 1, '2018-07-01', '2018-07-31', 1, '000000000195334667', '1100-0020-0001-0001', 2
CREATE PROCEDURE [dbo].[SEL_ABONO_BANCARIO_SP_DEV]
	@idEmpresa VARCHAR(50),
	@fechaElaboracion VARCHAR(50),
	@fechaCorte VARCHAR(50),
	@idBanco INT,
	@noCuenta varchar(50),
	@cuentaContable varchar(50),
	@opcion INT --1: detalle, 2: resumen
AS
BEGIN
	DECLARE @idHistorico INT = 0;
	-- Casos @opcion
	-- 1: Normal 
	-- 2: Empresa
	-- 3: Sistema

	IF( @opcion = 1 )
		BEGIN
			SELECT	
				'BANCO'  BANCO,
				CB.noCuenta CUENTA, 
				LTRIM(RTRIM(CB.fechaOperacion)) [FECHAOP],
				CONVERT(CHAR(15), CB.horaOperacion, 108) [HORAOP],
				LTRIM(RTRIM(CB.concepto)) [CONSEPTO],
				LTRIM(RTRIM(CB.referencia)) [REFERENCIA],
				LTRIM(RTRIM(CB.refAmpliada)) [REFAMPLIADA],
				CB.importe [IMPORTE]
			FROM ABONOSBANCOS_CB CB
			LEFT JOIN REGISTROS_PUNTEADOS PUN ON CB.IDABONOSBANCOS = PUN.rpun_idAbono AND PUN.rpun_tipo = 'B'
			WHERE	CB.idEmpresa		= @idEmpresa
					AND CB.noCuenta		= @noCuenta
					AND CB.IDBanco		= @idBanco
					AND rpun_idPunteado IS NULL
					AND CB.idEstatus	= 0
					AND PUN.rpun_idAplicado != 0
			ORDER BY CB.fechaOperacion, CB.horaOperacion ASC;
		END
	ELSE IF( @opcion = 2 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 1
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)
			
			SELECT
				'BANCO'  BANCO,
				ABO.noCuenta CUENTA, 
				LTRIM(RTRIM(ABO.fechaOperacion)) [FECHAOP],
				CONVERT(CHAR(15), ABO.horaOperacion, 108) [HORAOP],
				LTRIM(RTRIM(ABO.concepto)) [CONSEPTO],
				LTRIM(RTRIM(ABO.referencia)) [REFERENCIA],
				LTRIM(RTRIM(ABO.refAmpliada)) [REFAMPLIADA],
				ABO.importe [IMPORTE]
			FROM ABONOSBANCOS_CB_H ABO LEFT JOIN [REGISTROS_PUNTEADOS_H] PUN ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono 
																				AND PUN.idHistorico = @idHistorico
																				AND PUN.rpun_tipo = 'B'
			WHERE   ABO.noCuenta = @noCuenta
					AND ABO.idEmpresa = @idEmpresa
					AND ABO.IDBanco = @idBanco
					AND ABO.idEstatus = 0
					AND MONTH (ABO.fechaOperacion) <= MONTH(CONVERT(DATE, @fechaElaboracion))
					AND PUN.rpun_idPunteado IS NULL
					AND ABO.idHistorico = @idHistorico
		END
	ELSE IF( @opcion = 3 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 2
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)
			
			SELECT
				'BANCO'  BANCO,
				ABO.noCuenta CUENTA, 
				LTRIM(RTRIM(ABO.fechaOperacion)) [FECHAOP],
				CONVERT(CHAR(15), ABO.horaOperacion, 108) [HORAOP],
				LTRIM(RTRIM(ABO.concepto)) [CONSEPTO],
				LTRIM(RTRIM(ABO.referencia)) [REFERENCIA],
				LTRIM(RTRIM(ABO.refAmpliada)) [REFAMPLIADA],
				ABO.importe [IMPORTE]
			FROM ABONOSBANCOS_CB_H ABO  --CARGOS
			LEFT JOIN [REGISTROS_PUNTEADOS_H] PUN
				ON ABO.IDABONOSBANCOS = PUN.rpun_idAbono 
					AND PUN.idHistorico = @idHistorico
					AND PUN.rpun_tipo = 'B'
			WHERE   ABO.noCuenta = @noCuenta
					AND ABO.idEmpresa = @idEmpresa
					AND ABO.IDBanco = @idBanco
					AND ABO.idEstatus = 0
					AND MONTH (ABO.fechaOperacion) <= MONTH(CONVERT(DATE, @fechaElaboracion))
					AND PUN.rpun_idPunteado IS NULL
					AND ABO.idHistorico = @idHistorico
		END
END
go

