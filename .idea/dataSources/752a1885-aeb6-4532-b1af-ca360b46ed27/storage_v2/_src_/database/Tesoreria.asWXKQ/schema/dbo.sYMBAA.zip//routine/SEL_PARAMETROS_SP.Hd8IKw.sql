-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PARAMETROS_SP] 
	@tipoParametro  INT = 0
AS
BEGIN
	SELECT	 [valor]
	FROM	[Parametros]
END

go

