
-- =============================================
-- Author:		<Author Rodrigo Olivares>
-- Create date: <Create Date 25/08/2017>
-- =============================================
CREATE PROCEDURE [dbo].[UPDT_HISTORY_LAYOUT] 
@nombreBanco VARCHAR(50),
@idBanco INT,
@clave VARCHAR(50),
@accion int
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
IF(@accion = 2)
   BEGIN
    -- Insert statements for procedure here
	INSERT INTO  [layout_Historial]
		   (
			[idBanco],
			[Nombre_Banco],
			[clv_Identificador],
			[fecha_Descarga]
		   )
		   VALUES (
		            CONVERT(INT,@idBanco), --Id del Banco
					@nombreBanco, -- Nombre del Banco
					@clave, -- clave identificadora del archivo
					CONVERT(date, GETDATE())
				  )

		 --Elimino los registros que no tienen fecha de carga de información, mayor a 2 días
		     DELETE FROM  [layout_Historial]
			 WHERE [id_histLayout] IN
			   (SELECT [id_histLayout]
					  FROM  [layout_Historial]
					  WHERE [fecha_Carga_Info] IS NULL
					  AND DATEDIFF(day,[fecha_Descarga], GETDATE()) > 2)


				  SELECT 1 AS SUCCESS
	END
	ELSE IF(@accion = 1)
	DECLARE @result INT
	BEGIN

	  SET @result = (SELECT COUNT(*) 
						   FROM  [layout_Historial]
						   WHERE idBanco = @idBanco AND clv_Identificador =  @clave
						   AND fecha_Carga_Info IS NULL)
	  IF(@result != '')
	  BEGIN
	  SELECT @result AS Resultado
	  END
	  
	  ELSE
	  BEGIN
	    SELECT 'No existe registro del documento en la BD' AS Resultado
	  END
	END
END TRY
BEGIN CATCH
			SELECT ERROR_MESSAGE() AS ERROR
END CATCH
go

