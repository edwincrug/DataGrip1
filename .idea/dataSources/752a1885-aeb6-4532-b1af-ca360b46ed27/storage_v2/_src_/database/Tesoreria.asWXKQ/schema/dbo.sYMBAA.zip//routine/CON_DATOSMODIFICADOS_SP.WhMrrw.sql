-- =============================================
-- Author:		Ing. Alejandro Grijalva Antonio
-- Create date: 2018-07-03
-- Description:	Verifica si desde BPRO se han modificado registros
-- [CON_DATOSMODIFICADOS_SP] 4, 2, '1100-0020-0001-0011', 2019
-- =============================================
CREATE PROCEDURE [dbo].[CON_DATOSMODIFICADOS_SP]
	@idEmpresa INT		  = 0,
	@idBanco INT		  = 0,
	@numCenta VARCHAR(20) = '',
	@anio INT			  = 0
AS
BEGIN
	DECLARE @TempMOV TABLE(
		MOV_DEBE NUMERIC(18,5),
		MOV_HABER NUMERIC(18,5),
		MOV_CONCEPTO VARCHAR(250),
		MOV_CVEUSU VARCHAR(10),
		MOV_FECHOPE VARCHAR(10),
		MOV_MES NUMERIC(18,0),
		MOV_TIPOPOL VARCHAR(10),
		MOV_CONSMOV NUMERIC(18,0),
		MOV_NUMCTA VARCHAR(50),
		MOV_CONSPOL NUMERIC(18,0)
	);

	DECLARE @ipLocal VARCHAR(15) = (
		SELECT	dec.local_net_address
		FROM	sys.dm_exec_connections AS dec
		WHERE	dec.session_id = @@SPID
	);

	DECLARE @Base VARCHAR(300) = ''
	IF(  @ipLocal = (SELECT ip_servidor FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2)  )
		BEGIN
			SET @Base = (SELECT '[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
		END
	ELSE
		BEGIN
			SET @Base = (SELECT '[' + ip_servidor + '].[' + nombre_base + '].[dbo].[CON_MOVDET01'+ CONVERT(VARCHAR(4), @anio) +']' FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND tipo = 2);
		END
	
	

	DECLARE @UPD_Abono VARCHAR(1000) = 
	'SELECT 
		MOV.MOV_DEBE,
		MOV.MOV_HABER,
		MOV.MOV_CONCEPTO,
		MOV.MOV_CVEUSU,
		MOV.MOV_FECHOPE,
		MOV.MOV_MES,
		MOV.MOV_TIPOPOL,
		MOV.MOV_CONSMOV,
		MOV.MOV_NUMCTA,
		MOV.MOV_CONSPOL
	FROM ABONOS_COMPLETO_CB AC 
	INNER JOIN '+ @Base +' MOV ON MOV.MOV_CONSPOL = AC.MOV_CONSPOL 
				AND MOV.MOV_MES = AC.MOV_MES
				AND MOV.MOV_TIPOPOL COLLATE Modern_Spanish_CI_AS = AC.MOV_TIPOPOL
				AND MOV.MOV_CONSMOV = AC.MOV_CONSMOV
				AND MOV.MOV_HABER <> 0
				AND MOV.MOV_HABER != AC.MOV_HABER 
	WHERE AC.idEmpresa = ' + CONVERT( VARCHAR(3), @idEmpresa ) 
	+ ' AND AC.idBanco = ' + CONVERT( VARCHAR(3), @idBanco ) 
	+ ' AND AC.MOV_NUMCTA = ''' + @numCenta + ''''
	+ ' AND AC.anio='+convert(nvarchar(4),@anio)

	INSERT INTO @TempMOV
	EXEC(@UPD_Abono);

	UPDATE
		AC
	SET 
		AC.MOV_HABER	= MOV.MOV_HABER,
		AC.MOV_CONCEPTO = MOV.MOV_CONCEPTO,
		AC.MOV_CVEUSU   = MOV.MOV_CVEUSU,
		AC.MOV_FECHOPE  = MOV.MOV_FECHOPE	
	FROM ABONOS_COMPLETO_CB AC 
	INNER JOIN @TempMOV MOV ON  MOV.MOV_CONSPOL = AC.MOV_CONSPOL 
								AND MOV.MOV_MES = AC.MOV_MES
								AND MOV.MOV_TIPOPOL COLLATE Modern_Spanish_CI_AS = AC.MOV_TIPOPOL
								AND MOV.MOV_CONSMOV = AC.MOV_CONSMOV
								AND MOV.MOV_HABER <> 0
								AND MOV.MOV_HABER != AC.MOV_HABER 
	WHERE AC.idEmpresa = @idEmpresa AND AC.idBanco = @idBanco AND AC.MOV_NUMCTA = @numCenta and ac.anio=@anio


	DELETE FROM @TempMOV;

	DECLARE @UPD_Cargo VARCHAR(1000) = 
	'SELECT 
		MOV.MOV_DEBE,
		MOV.MOV_HABER,
		MOV.MOV_CONCEPTO,
		MOV.MOV_CVEUSU,
		MOV.MOV_FECHOPE,
		MOV.MOV_MES,
		MOV.MOV_TIPOPOL,
		MOV.MOV_CONSMOV,
		MOV.MOV_NUMCTA,
		MOV.MOV_CONSPOL
	FROM CARGOS_COMPLETO_CB CC 
	INNER JOIN '+ @Base +' MOV ON MOV.MOV_CONSPOL = CC.MOV_CONSPOL 
				AND MOV.MOV_MES = CC.MOV_MES
				AND MOV.MOV_TIPOPOL COLLATE Modern_Spanish_CI_AS = CC.MOV_TIPOPOL
				AND MOV.MOV_CONSMOV = CC.MOV_CONSMOV
				AND MOV.MOV_DEBE <> 0
				AND MOV.MOV_DEBE != CC.MOV_DEBE 
	WHERE CC.idEmpresa = ' + CONVERT( VARCHAR(3), @idEmpresa )
	 + ' AND CC.idBanco = ' + CONVERT( VARCHAR(3), @idBanco ) 
	 + ' AND CC.MOV_NUMCTA = ''' + @numCenta + ''''
	 + ' AND CC.anio='+convert(nvarchar(4),@anio)
	INSERT INTO @TempMOV
	EXEC(@UPD_Cargo);

	UPDATE
		CC
	SET 
		CC.MOV_DEBE		= MOV.MOV_DEBE,
		CC.MOV_CONCEPTO = MOV.MOV_CONCEPTO,
		CC.MOV_CVEUSU   = MOV.MOV_CVEUSU,
		CC.MOV_FECHOPE  = MOV.MOV_FECHOPE
	FROM CARGOS_COMPLETO_CB CC 
	INNER JOIN @TempMOV MOV ON  MOV.MOV_CONSPOL = CC.MOV_CONSPOL
								AND MOV.MOV_MES = CC.MOV_MES
								AND MOV.MOV_TIPOPOL COLLATE Modern_Spanish_CI_AS = CC.MOV_TIPOPOL
								AND MOV.MOV_CONSMOV = CC.MOV_CONSMOV
								AND MOV.MOV_DEBE <> 0
								AND MOV.MOV_DEBE != CC.MOV_DEBE
	WHERE CC.idEmpresa = @idEmpresa AND CC.idBanco = @idBanco AND CC.MOV_NUMCTA = @numCenta and cc.anio=@anio
END
go

