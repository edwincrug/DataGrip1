

CREATE procedure [dbo].[INS_CUENTAS_REFERENCIADAS_SP]  
@idEmpresa as integer = 0,
@idBanco as integer = 0,
@cuentaBancaria varchar(20) = '',
@fechaInicial as varchar(25) = '',
@fechaFinal as varchar(25) = ''

as
begin
	insert into [DepositoBanco]
	select 
		1 AS idBanco,
		banco.idBmer,		
		1 as idEstatus,
		0,
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null
	from 
		referencias.dbo.Bancomer banco  left outer join [DepositoBanco]  on [DepositoBanco].idBanco = 1 and [DepositoBanco].idBmer = banco.idBmer AND banco.estatus != 4
		where [DepositoBanco].idBmer IS NULL --and banco.referencia != ''
union
	select 
	2 AS idBanco,
		idSantander,
		1 as idEstatus,
		0,
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null
	from 
		referencias.dbo.Santander banco left outer join [DepositoBanco]  on [DepositoBanco].idBanco = 2 and [DepositoBanco].idBmer = banco.idSantander AND banco.estatus != 4
		where [DepositoBanco].idBmer IS NULL --and banco.referencia != ''
		end

go

