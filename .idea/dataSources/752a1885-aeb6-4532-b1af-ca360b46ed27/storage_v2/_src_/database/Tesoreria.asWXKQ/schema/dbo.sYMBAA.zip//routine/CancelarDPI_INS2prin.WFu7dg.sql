-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <01/12/2017>
-- Description:	<Inserta el dpi en bpro>
-- =============================================
--[dbo].[CancelarDPI_INS2prin] 430133,71
CREATE PROCEDURE [dbo].[CancelarDPI_INS2prin]
			@rpun_grupoPunteo INT,
			@usuario int	   

AS
begin
declare @id int,@id2 int,@idAbono numeric(18,0),@idEmpresa int,@idBanco int,@NUMCTA varchar(50)
select @idAbono=rpun_idabono ,@idEmpresa=a.idEmpresa,@idBanco=idBanco,@NUMCTA=noCuenta
 from registros_punteados r 
inner join [dbo].[ABONOSBANCOS_CB] a on r.rpun_idabono=a.[IDABONOSBANCOS] where r.rpun_grupoPunteo=@rpun_grupoPunteo and rpun_tipo='B'

BEgin TRY
Begin TRAN DPI
 exec  [dbo].[CancelaDPI_INS2]
			@rpun_grupoPunteo ,
			@usuario 


select @id=id from ##TempCancelaDPI
--select @id2=id from ##TempCancelaDPI2

select  @id=isnull(@id,0)
 if(@id>0)
 begin
 	
 EXEC [dbo].[BitacoraDPI_INS]  @idAbono,@idEmpresa,@idBanco,@NUMCTA,@id,1,'',@usuario

  SELECT 'SE CANCELARON LOS DPI DE BANCOS' AS msg, 1 success
 end
 else
 begin
  
 --delete from  [dbo].[ABONOS_COMPLETO_CB] where [IDABONOS_COMPLETO] =@id2
 SELECT 'Ocurrió un problema al enviar el depósito a DPI' AS msg,0 success
 end
COMMIT TRAN DPI

END TRY
BEGIN CATCH
    PRINT 'In CATCH Block'
    IF(@@TRANCOUNT > 0)
        ROLLBACK TRAN DPI;
		Declare @msg varchar(max)=ERROR_MESSAGE()
 EXEC [dbo].[BitacoraDPI_INS]  @idAbono,@idEmpresa,@idBanco,@NUMCTA,@id,1,@msg,@usuario
   select @msg mensaje
END CATCH			
		
	IF OBJECT_ID('tempdb..##TempCancelaDPI') IS NOT NULL
	Begin
		DROP TABLE ##TempCancelaDPI
	END
	IF OBJECT_ID('tempdb..##TempCancelaDPI2') IS NOT NULL
	Begin
		DROP TABLE ##TempCancelaDPI2
	END
END
go

