
CREATE PROCEDURE [dbo].[INS_DEPOSITOS_PENDIENTES_SP]
	  @idUsuario        INT = 0
	  ,@idEstatus       INT=1 -- 1: registrado, 2: procesado
	  ,@idTipoAuxiliar          INT=0 --1 :  abono contable, 2 : abono bancario
	  ,@idDepositoBanco INT = 0
AS
BEGIN
    
	/*IF(@idTipoAuxiliar = 1)  --abono contable
		BEGIN
				
				INSERT INTO DEPOSITOSPENDIENTES
				SELECT idAuxiliarContable,@idTipoAuxiliar,GETDATE(),1, idEmpresa,TIPO, POLIZA,FECHA 
				FROM AuxiliarContable 
				WHERE ABONO > 0 AND CARGO = 0 AND idEstatus = 4
			
		END
	ELSE    -- cargo contable
		BEGIN
				
				INSERT INTO DEPOSITOSPENDIENTES				
				SELECT idAuxiliarContable,@idTipoAuxiliar,GETDATE(),1, idEmpresa,TIPO, POLIZA,FECHA 
				FROM AuxiliarContable 
				WHERE CARGO > 0 AND ABONO = 0 AND idEstatus = 4				

		END*/

	--llamar a SP BPRO 

	DECLARE @idEmpresa INT = 0, @noCuenta VARCHAR(18) = '', @CuentaContable INT = 0, @Importe NUMERIC(18,6) = 0, @fecha DATETIME = NULL

	SELECT	@idEmpresa = [idEmpresa], 
			@noCuenta = [noCuenta], 
			@CuentaContable = [CuentaContable], 
			@Importe = [importe], 
			@fecha = [fechaOperacion]
	FROM DepositoBancoView 
	WHERE idDepositoBanco = @idDepositoBanco
	--SP_INSERTA_DPI (IdEmpresa,CuentaBancaria,CuentaContable,Importe,Fecha)

	UPDATE [dbo].[DepositoBanco]
	SET poliza = '99999', fechaDPI = GETDATE(), idEstatus = 5
	WHERE idDepositoBanco = @idDepositoBanco

	SELECT 'ok' estatus, 'Registros insertados.' mensaje

END
go

