





CREATE VIEW [dbo].[DepositoBancoView]
AS
SELECT banco.idBanco, 
       banco.idBmer, 
	   'Bancomer' banco, 
	   banco.txtOrigen, 
	   banco.noCuenta, 
	   banco.concepto, 
	   banco.esCargo, 
	   banco.importe, 
	   banco.saldoOperativo, 
       banco.referencia, 
	   banco.fechaOperacion, 
	   banco.horaOperacion, 
	   banco.oficinaOperadora, 
	   banco.refAmpliada, 
	   banco.estatusRevision,
	   banco.codigoLeyenda
FROM   referencias.dbo.Bancomer banco
UNION
SELECT banco.idbanco AS idBanco, 
       banco.idSantander AS idBmer, 
	   'Santander' banco, 
	   banco.txtOrigen, 
	   banco.noCuenta, 
	   banco.descripcion AS concepto, 
       CASE banco.signo 
	   WHEN '+' THEN 1 
	   ELSE 0 
	   END 
	   AS esCargo, 
	   banco.importe, 
	   banco.saldo AS saldoOperativo, 
	   banco.referencia, 
       banco.fechaMovimiento AS fechaOperacion, 
	   banco.horaMovimiento AS horaOperacion, 
	   banco.sucursal AS oficinaOperadora, 
	   banco.concepto AS refAmpliada,
       banco.estatusRevision,
	   banco.clacon AS codigoLeyenda
FROM [referencias].[dbo].[Santander] banco
UNION
SELECT banco.idBanco, 
	   banco.idBanamex AS idBmer, 
	   'Banamex' banco, 
	    banco.AODescripcion, 
	   banco.noCuenta, 
	    banco.AODescripcion AS concepto, 
       CASE banco.SLCredito 
	   WHEN 'C' THEN 0 
	   ELSE 1
	   END AS esCargo, 
	   slmonto
	   AS importe, 
	   0 AS saldoOperativo, 
	   CONVERT(VARCHAR(30), SLTipoReferencia) AS referencia, 
       banco.SLFechaTransaccion AS fechaOperacion, 
	   convert(time, getdate(), 108) AS horaOperacion, 
	   0 AS oficinaOperadora, 
	   '' AS refAmpliada,
	   1 as estatusRevision, 
	   banco.SLRazon AS codigoLeyenda
FROM   [referencias].[dbo].[Banamex] banco
UNION
SELECT banco.idBanco, 
	   banco.idBmer AS idBmer, 
	   'Scotiabank' banco, 
	   banco.transaccion AS Descripcion, 
	   banco.noCuenta, 
	   banco.leyenda2 AS concepto, 
       CASE banco.tipo 
	   WHEN 'ABONO' THEN 1 
	   ELSE 0 
	   END AS esCargo, 
	   CASE banco.abono
	   WHEN 0 THEN banco.cargo
	   else banco.abono
	   END
	   AS importe, 
	   0 AS saldoOperativo, 
	   banco.leyenda1 AS referencia, 
       banco.fecha AS fechaOperacion, 
	   convert(time, getdate(), 108) AS horaOperacion, 
	   0 AS oficinaOperadora, 
	   '' AS refAmpliada,
	   1 as estatusRevision,
	   'PRUEBA' as codigoLeyenda
FROM   [referencias].[dbo].[Scotiabank_Layout] banco
UNION
SELECT banco.idBanco, 
	   banco.idBmer AS idBmer, 
	   'Inbursa' banco, 
	   banco.Ordenante AS Descripcion, 
	   banco.noCuenta, 
	   banco.ReferenciaLeyenda AS concepto, 
       CASE banco.Abono 
	   WHEN 0 THEN 1 
	   ELSE 0 
	   END AS esCargo, 
	   CASE banco.Abono
	   WHEN 0 THEN banco.Cargo
	   else banco.Abono
	   END
	   AS importe, 
	   0 AS saldoOperativo, 
	   convert(nvarchar,banco.Referencia) AS referencia, 
       banco.fecha AS fechaOperacion, 
	   convert(time, getdate(), 108) AS horaOperacion, 
	   0 AS oficinaOperadora, 
	   convert(varchar,banco.ReferenciaNumerica) AS refAmpliada,
	   1 as estatusRevision,
	   'PRUEBA' AS codigoLeyenda
FROM   [referencias].[dbo].[Inbursa_Layout] banco
UNION

SELECT banco.idBanco, 
	   banco.idBmer AS idBmer, 
	   banco.nombre banco, 
	   banco.Concepto as Descipcion, 
	   banco.noCuenta, 
	   banco.Concepto AS concepto, 
       CASE banco.Abonos 
	   WHEN 0 THEN 1 
	   ELSE 0 
	   END AS esCargo, 
	   CASE banco.Abonos
	   WHEN 0 THEN banco.Cargos
	   else banco.Abonos
	   END
	   AS importe, 
	   0 AS saldoOperativo, 
	   convert(varchar,banco.Referencia) AS referencia, 
       banco.fecha AS fechaOperacion, 
	   convert(time, getdate(), 108) AS horaOperacion, 
	   banco.Sucursal AS oficinaOperadora, 
	   banco.ReferenciaAmpliada AS refAmpliada,
	   1 as estatusRevision,
	   'PRUEBA' AS codigoLeyenda
FROM   [referencias].[dbo].[CargaInicial_Layout] banco
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[15] 4[16] 2[52] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'DepositoBancoView'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'DepositoBancoView'
go

