/*

EXECUTE dbo.[SEL_BANCARIO_TODO_SP] 1,1,'000000000195334667','1100-0020-0001-0001','2018-03-01','2018-03-31','TREEUN',2

EXECUTE dbo.[SEL_BANCARIO_TODO_SP] 1,1,'000000000195334667','1100-0020-0001-0001','2018-07-01','2018-07-31','TREEUN',2

EXECUTE dbo.[SEL_BANCARIO_TODO_SP] 1,3,'65504258249','1100-0020-0001-0001','2018-05-01','2018-05-31','TREEUN',2

*/

CREATE PROCEDURE [dbo].[SEL_BANCARIO_TODO_SP]
@idEmpresa VARCHAR(50) = '',
@idBanco INT = 0,
@noCuenta VARCHAR(50) = '',
@cuentaContable VARCHAR(50) = '',	
@fechaElaboracion VARCHAR(50) = '',
@fechaCorte VARCHAR(50) = '',
@polizaPago VARCHAR(20) = '',
@opcion INT = 0, --1: detalle, 2: resumen
@idUsuario INT = 0
AS
BEGIN	
		DECLARE @añoConsulta INT = YEAR(CONVERT(DATE,(CONVERT(DATE,REPLACE(@fechaCorte,'-',''))),103))
		DECLARE @mes INT = MONTH(REPLACE(@fechaElaboracion,'-','')) 
		DECLARE @anio INT = YEAR(REPLACE(@fechaElaboracion,'-','')) 

		DECLARE @ipLocal NVARCHAR(50) = ''
					,@ip_catbases NVARCHAR(50) = ''			
					,@Base NVARCHAR(50) = ''

		SELECT	@ipLocal = dec.local_net_address
		FROM	sys.dm_exec_connections AS dec
		WHERE	dec.session_id = @@SPID;

		SELECT	@ip_catbases = (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN ''
							ELSE ip_servidor 
						END),
		@idEmpresa	= emp_idempresa,
		@Base		= (CASE 
							WHEN ltrim( rtrim( @ipLocal ) ) = rtrim( ltrim( ip_servidor ) ) 
								THEN '[' + nombre_base + '].[DBO].' 
							ELSE '['+ ip_servidor + '].[' + nombre_base + '].[DBO].' 
						END)
FROM	[CentralizacionV2].[dbo].[DIG_CAT_BASES_BPRO]
WHERE	emp_idempresa	= @idEmpresa 
		AND tipo		= 2


		DECLARE @query VARCHAR(MAX) = ''
		
		--------------------------------------------------------------------------------
		SELECT
			 uniBan. [IDCARGOSBANCOS]
			,uniBan.[idBmer]
			,uniBan.[IDBanco]
			,uniBan.[txtOrigen]
			,uniBan.[registro]
			,uniBan.[noMovimiento]
			,uniBan.[referencia]
			,uniBan.[concepto]
			,uniBan.[refAmpliada]
			,uniBan.[esCargo]
			,uniBan.[importe]
			,uniBan.[saldoOperativo]
			,uniBan.[codigoLeyenda]
			,uniBan.[oficinaOperadora]
			,uniBan.[fechaOperacion]
			,uniBan.[horaOperacion]
			,uniBan.[fechaValor]
			,uniBan.[fechaContable]
			,uniBan.[estatus]
			,uniBan.[noCuenta]
			,uniBan.[estatusRevision]
			,uniBan.[Tipo]
			,uniBan.[idUsuario]
			,uniBan.[idEmpresa]
			,uniBan.[anio]
			,uniBan.[fecha]
			,uniBan.[idEstatus]
			,uniBan.[idConciliado]
			,CASE WHEN uniBan.esCargo = 1 THEN 1 ELSE 0 END tipoMovimiento
			,CASE WHEN uniBan.esCargo = 1 THEN uniBan.importe ELSE 0 END cargo
			,CASE WHEN uniBan.esCargo = 0 THEN uniBan.importe ELSE 0 END abono
		FROM(
			SELECT 
				 [IDCARGOSBANCOS]
				  ,[idBmer]
				  ,[IDBanco]
				  ,[txtOrigen]
				  ,[registro]
				  ,[noMovimiento]
				  ,[referencia]
				  ,[concepto]
				  ,[refAmpliada]
				  ,[esCargo]
				  ,[importe]
				  ,[saldoOperativo]
				  ,[codigoLeyenda]
				  ,[oficinaOperadora]
				  ,[fechaOperacion]
				  ,[horaOperacion]
				  ,[fechaValor]
				  ,[fechaContable]
				  ,[estatus]
				  ,[noCuenta]
				  ,[estatusRevision]
				  ,[Tipo]
				  ,[idUsuario]
				  ,[idEmpresa]
				  ,[anio]
				  ,[fecha]
				  ,[idEstatus]
				  ,[idConciliado]
			FROM CARGOSBANCOS_CB ABO
			WHERE noCuenta = @noCuenta AND idEstatus = 0 AND MONTH(fechaOperacion) = @mes AND YEAR(fechaOperacion) = @anio
					
			UNION ALL
					
			SELECT 
				 [IDABONOSBANCOS]
				  ,[idBmer]
				  ,[IDBanco]
				  ,[txtOrigen]
				  ,[registro]
				  ,[noMovimiento]
				  ,[referencia]
				  ,[concepto]
				  ,[refAmpliada]
				  ,[esCargo]
				  ,[importe]
				  ,[saldoOperativo]
				  ,[codigoLeyenda]
				  ,[oficinaOperadora]
				  ,[fechaOperacion]
				  ,[horaOperacion]
				  ,[fechaValor]
				  ,[fechaContable]
				  ,[estatus]
				  ,[noCuenta]
				  ,[estatusRevision]
				  ,[Tipo]
				  ,[idUsuario]
				  ,[idEmpresa]
				  ,[anio]
				  ,[fecha]
				  ,[idEstatus]
				  ,[idConciliado]
			FROM ABONOSBANCOS_CB CAR
			WHERE noCuenta = @noCuenta AND idEstatus = 0 AND MONTH(fechaOperacion) = @mes AND YEAR(fechaOperacion) = @anio)	uniBan	

END
go

