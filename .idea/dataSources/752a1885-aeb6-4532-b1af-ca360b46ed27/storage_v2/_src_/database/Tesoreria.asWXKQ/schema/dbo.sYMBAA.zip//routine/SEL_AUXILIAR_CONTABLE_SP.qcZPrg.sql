
--  [SEL_AUXILIAR_CONTABLE_SP]'192.168.20.9','GAZM_ZARAGOZA','01/12/2016','31/12/2016'
CREATE procedure [dbo].[SEL_AUXILIAR_CONTABLE_SP]

@server varchar(150), 
@database varchar(150), 
@fechaIni  varchar(20),
@fechaFin  varchar(20)

as
begin

declare @schema varchar(50)='dbo'
declare @conexion varchar(350)='['+ @server +'].' +'['+ @dataBase +'].' +'['+  @schema +'].' 

declare @queryText varchar(max) = 
'SELECT ' + char(13) + 
'		isnull((SELECT cli.PER_RFC as PER_RFC FROM  '+@conexion+'per_personas as cli WHERE aux_idcliente = cli.PER_IDPERSONA), '+char(39)+''+char(39)+') as RFC,' + char(13) + 
'	    isnull((SELECT cli.PER_NOMRAZON FROM   '+@conexion+'per_personas as cli WHERE aux_idcliente = cli.PER_IDPERSONA), '+char(39)+''+char(39)+') as NOMBRE_RAZON,' + char(13) + 
'	    isnull(AUX_IDCLIENTE, '+char(39)+'0'+char(39)+') as IDCLIENTE, AUX_REFFAC, AUX_CUENTA AS NUMERO_CUENTA,' + char(13) + 
'	    AUX_FECHA AS FECHA, ISNULL(A.PAR_DESCRIP1, '+char(39)+''+char(39)+') AS TIPO, AUX_CONPOLIZA AS POLIZA,' + char(13) + 
'	    AUX_REFERENCIA AS REFERENCIA, AUX_DESCRIPCION AS DESCRIPCION, AUX_CONCEPTO AS CONCEPTO,' + char(13) + 
'	    AUX_SI AS SALDO_INICIAL, AUX_CARGO AS CARGO, AUX_ABONO AS ABONO, AUX_SF AS SALDO_ACTUAL,' + char(13) + 
'	    AUX_GRUPO AS GRUPO, AUX_NOCHEQUE AS CHEQUE, AUX_AFAVOR 		' + char(13) + 
'		FROM            ' + char(13) + 
'		 '+@conexion+'CON_TEMPAUXILIARES LEFT OUTER JOIN' + char(13) + 
'		 '+@conexion+'PNC_PARAMETR AS A ON CON_TEMPAUXILIARES.AUX_TIPO = A.PAR_IDENPARA' + char(13) + 
'WHERE       ' + char(13) + 
'		(A.PAR_TIPOPARA = '+char(39)+'TIPOLI'+char(39)+') AND ' + char(13) + 
'		(CON_TEMPAUXILIARES.AUX_CVEUSU = '+char(39)+'GMI'+char(39)+')' + char(13) + 
'ORDER BY CON_TEMPAUXILIARES.AUX_NO, SUBSTRING(CON_TEMPAUXILIARES.AUX_CUENTA, 1, 4) + ' + char(13) + 
'		SUBSTRING(CON_TEMPAUXILIARES.AUX_CUENTA, 6, 4) + ' + char(13) + 
'		SUBSTRING(CON_TEMPAUXILIARES.AUX_CUENTA, 11, 4) + ' + char(13) + 
'		SUBSTRING(CON_TEMPAUXILIARES.AUX_CUENTA, 16, 4)' + char(13) + 
'' 

 exec(@queryText) 

 end
go

