-- =============================================
-- Author: Roberto Almanza Nieto
-- Create date:
-- Description:
-- =============================================
CREATE PROCEDURE [dbo].[INS_ANTICIPO_SP]
-- Add the parameters for the stored procedure here
  @header NVARCHAR(MAX)
  ,@detalle NVARCHAR(MAX)
  ,@metodoPago NVARCHAR(MAX)
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
DECLARE @identity INT
    BEGIN TRY
BEGIN TRANSACTION [Tran1]
INSERT INTO GA_Corporativa.dbo.cxc_anticiposautomaticos (caa_cobrador, caa_estatus, caa_fechasolicita, caa_idempresa, caa_idmoneda, caa_idpersona, caa_idsucursal, caa_tasaiva, caa_tipocambio, caa_usuariosolicita, caa_cotizacionuniversal)
SELECT
max(case when name='cobrador' then convert(VARCHAR(50),StringValue) else '' end) as [cobrador],
max(case when name='estatus' then convert(Varchar(50),StringValue) else '' end) as [estatus],
max(case when name='fechaSolicita' then convert(VARCHAR(50),StringValue) else '' end) as [fechaSolicita],
max(case when name='idEmpresa' then convert(Varchar(50),StringValue) else '' end) as [idEmpresa],
max(case when name='idMoneda' then convert(Varchar(50),StringValue) else '' end) as [idMoneda],
max(case when name='idPersona' then convert(VARCHAR(50),StringValue) else '' end) as [idPersona],
max(case when name='idSucursal' then convert(Varchar(50),StringValue) else '' end) as [idSucursal],
max(case when name='tasaIva' then convert(Varchar(50),StringValue) else '' end) as [tasaIva],
max(case when name='tipoCambio' then convert(VARCHAR(50),StringValue) else '' end) as [tipoCambio],
max(case when name='usuarioSolicita' then convert(VARCHAR(50),StringValue) else '' end) as [usuarioSolicita],
ISNULL(max(case when name='cotizacionU' then convert(VARCHAR(50),StringValue) else '' end),'') as [cotizacionU]
From parseJSON(@header)
where ValueType = 'string' OR ValueType = 'int' OR ValueType ='boolean' or ValueType = 'decimal' or ValueType = 'float' or ValueType = 'money' or ValueType = 'real'
group BY parent_ID
SET @identity = @@identity
INSERT INTO GA_Corporativa.dbo.cxc_anticiposautomaticosdet( cad_concepto, cad_referencia, cad_importe, cad_observaciones, cad_idpersona, caa_idanticiposautomaticos)
SELECT
       
max(case when name='concepto' then convert(VARCHAR(50),StringValue) else '' end) as [concepto],
max(case when name='referencia' then convert(Varchar(50),StringValue) else '' end) as [referencia],
max(case when name='importe' then convert(VARCHAR(50),StringValue) else '' end) as [importe],
max(case when name='observaciones' then convert(Varchar(50),StringValue) else '' end) as [observaciones],
case when max(case when name='idPersona' then convert(VARCHAR(50),StringValue) else '' end) = '' then NULL ELSE max(case when name='idPersona' then convert(VARCHAR(50),StringValue) else '' end) END as [idPersona],
@identity AS idanticiposautomaticos
From parseJSON(@detalle)
where ValueType = 'string' OR ValueType = 'int' OR ValueType ='boolean' or ValueType = 'decimal' or ValueType = 'float' or ValueType = 'money' or ValueType = 'real'
group BY parent_ID
INSERT INTO GA_Corporativa.dbo.cxc_anticiposautomaticosmp(cam_metodopago, cam_banco, cam_referencia, cam_importe, cam_numerocuenta, cam_nochequevoucher, cam_fechaingreso, caa_idanticiposautomaticos)
SELECT
    
max(case when name='metodoPago' then convert(VARCHAR(50),StringValue) else '' end) as [metodoPago],
CASE WHEN max(case when name='banco' then convert(Varchar(50),StringValue) else '' end) = '' THEN NULL ELSE max(case when name='banco' then convert(Varchar(50),StringValue) else '' end) END as [banco],
max(case when name='referencia' then convert(VARCHAR(50),StringValue) else '' end) as [referencia],
max(case when name='importe' then convert(Varchar(50),StringValue) else '' end) as [importe],
CASE WHEN max(case when name='numeroCuenta' then convert(Varchar(50),StringValue) else '' end) ='' THEN NULL ELSE max(case when name='numeroCuenta' then convert(Varchar(50),StringValue) else '' end) END as [numeroCuenta],
CASE WHEN max(case when name='noChequeVoucher' then convert(VARCHAR(50),StringValue) else '' end) = '' THEN NULL ELSE max(case when name='noChequeVoucher' then convert(VARCHAR(50),StringValue) else '' end) END as [noChequeVoucher],
max(case when name='fechaingreso' then convert(Varchar(50),StringValue) else '' end) as [fechaingreso],
@identity AS idanticiposautomaticos
From parseJSON(@metodoPago)
where ValueType = 'string' OR ValueType = 'int' OR ValueType ='boolean' or ValueType = 'decimal' or ValueType = 'float' or ValueType = 'money' or ValueType = 'real'
group BY parent_ID
COMMIT TRANSACTION [Tran1]
select 1 as estatus, 'Información almacenda correctamente' as mensaje, @identity as folio
END TRY
BEGIN CATCH
ROLLBACK TRANSACTION [Tran1]
select 0 as estatus, 'Ocurrio un error al guardar los datos '+ERROR_MESSAGE() as mensaje
END CATCH
END
go

