-- [dbo].[SEL_CARGO_BANCARIO_SP] 4, '2018-06-01', '2018-06-30', 1,  '000000000195334667', '1100-0020-0001-0001', 3
CREATE PROCEDURE [dbo].[SEL_CARGO_BANCARIO_SP]
	@idEmpresa VARCHAR(50),
	@fechaElaboracion VARCHAR(50),
	@fechaCorte VARCHAR(50),
	@idBanco INT,
	@noCuenta VARCHAR(50),
	@cuentaContable VARCHAR(50),
	@opcion INT --1: detalle, 2: resumen
AS
BEGIN
	DECLARE @idHistorico INT = 0;
	-- Casos @opcion
	-- 1: Normal 
	-- 2: Empresa
	-- 3: Sistema

	IF( @opcion = 1 )
		BEGIN
			SELECT
				'BANCO'  BANCO,
				CB.noCuenta CUENTA, 
				CONVERT(NVARCHAR(10),CB.fechaOperacion,103)[FECHAOP],
				CONVERT(CHAR(15), CB.horaOperacion, 108) [HORAOP],
				LTRIM(RTRIM(CB.concepto)) [CONSEPTO],
				LTRIM(RTRIM(CB.referencia)) [REFERENCIA],
				LTRIM(RTRIM(CB.refAmpliada)) [REFAMPLIADA],
				CB.importe [IMPORTE]
			FROM CARGOSBANCOS_CB CB
			LEFT JOIN REGISTROS_PUNTEADOS PUN ON CB.IDCARGOSBANCOS = PUN.rpun_idCargo AND PUN.rpun_tipo = 'B'
			WHERE	CB.idEmpresa = @idEmpresa
					AND CB.noCuenta = @noCuenta
					AND CB.IDBanco = @idBanco
					AND rpun_idPunteado IS NULL
					AND CB.idEstatus = 0
					ORDER BY CB.fechaOperacion, CB.horaOperacion ASC;
		END
	ELSE IF( @opcion = 2 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 1
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)
			
			SELECT
			    'BANCO'  BANCO,
				CAR.noCuenta CUENTA, 
				LTRIM(RTRIM(CAR.fechaOperacion)) [FECHAOP],
				CONVERT(CHAR(15), CAR.horaOperacion, 108) [HORAOP],
				LTRIM(RTRIM(CAR.concepto)) [CONSEPTO],
				LTRIM(RTRIM(CAR.referencia)) [REFERENCIA],
				LTRIM(RTRIM(CAR.refAmpliada)) [REFAMPLIADA],
				CAR.importe [IMPORTE]
			FROM CARGOSBANCOS_CB_H CAR  --CARGOS
			LEFT JOIN [REGISTROS_PUNTEADOS_H] PUN
			  ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo
				 AND PUN.idHistorico = @idHistorico
				 AND PUN.rpun_tipo = 'B'
			LEFT JOIN [DepositoBancarioDPI_H] DPI
				ON  CAR.IDCARGOSBANCOS = DPI.idAbonoBanco
					AND DPI.idHistorico = @idHistorico
			WHERE   CAR.noCuenta = @noCuenta 
					AND CAR.idEmpresa = @idEmpresa 
					AND CAR.IDBanco = @idBanco
					AND CAR.idEstatus = 0
					AND MONTH(CAR.fechaOperacion) <= MONTH(CONVERT(DATE, @fechaElaboracion))
					AND PUN.rpun_idPunteado IS NULL 
					AND DPI.idDPI IS NULL
					AND CAR.idHistorico = @idHistorico
		END
	ELSE IF( @opcion = 3 )
		BEGIN
			SET @idHistorico = (
				SELECT MAX(idHistorico) 
				FROM HISTORICO_CONCILIACION 
				WHERE	idEmpresa			= @idEmpresa 
						AND idBanco			= @idBanco 
						AND cuenta			= @noCuenta
						AND tipoHistorico	= 2
						AND perido			= MONTH(CONVERT(DATE, @fechaElaboracion))
			)
			
			SELECT
			    'BANCO'  BANCO,
				CAR.noCuenta CUENTA, 
				LTRIM(RTRIM(CAR.fechaOperacion)) [FECHAOP],
				CONVERT(CHAR(15), CAR.horaOperacion, 108) [HORAOP],
				LTRIM(RTRIM(CAR.concepto)) [CONSEPTO],
				LTRIM(RTRIM(CAR.referencia)) [REFERENCIA],
				LTRIM(RTRIM(CAR.refAmpliada)) [REFAMPLIADA],
				CAR.importe [IMPORTE]
			FROM CARGOSBANCOS_CB_H CAR  --CARGOS
			LEFT JOIN [REGISTROS_PUNTEADOS_H] PUN
			  ON CAR.IDCARGOSBANCOS = PUN.rpun_idCargo
				 AND PUN.idHistorico = @idHistorico
				 AND PUN.rpun_tipo = 'B'
			LEFT JOIN [DepositoBancarioDPI_H] DPI
				ON  CAR.IDCARGOSBANCOS = DPI.idAbonoBanco
					AND DPI.idHistorico = @idHistorico
			WHERE   CAR.noCuenta = @noCuenta 
					AND CAR.idEmpresa = @idEmpresa 
					AND CAR.IDBanco = @idBanco
					AND CAR.idEstatus = 0
					AND MONTH(CAR.fechaOperacion) <= MONTH(CONVERT(DATE, @fechaElaboracion))
					AND PUN.rpun_idPunteado IS NULL 
					AND DPI.idDPI IS NULL
					AND CAR.idHistorico = @idHistorico
		END
END
go

