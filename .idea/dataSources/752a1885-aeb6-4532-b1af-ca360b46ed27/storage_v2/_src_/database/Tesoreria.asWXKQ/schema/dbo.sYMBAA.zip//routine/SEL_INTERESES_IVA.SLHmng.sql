
CREATE PROCEDURE  [dbo].[SEL_INTERESES_IVA]

@idDepositoBanco int =0,
@idBanco INT=0
AS
BEGIN

	IF (@idBanco = 1) --bancomer
	
	Begin

		SELECT
				idbmer idDepositoBanco
			  ,[idBanco]
			  ,[idBmer]
			  ,'bancomer' banco
			  ,[txtOrigen]
			  ,[noCuenta]
			  ,[concepto]
			  ,[importe] as abono
			  ,0 as cargo
			  ,[saldoOperativo]
			  ,[referencia]
			  ,[fechaOperacion]
			  ,[horaOperacion]
			  ,[oficinaOperadora]

		FROM referencias.DBO.BANCOMER WHERE codigoLeyenda IN
		(
			SELECT        CodigoBanco--, TipoMovimiento, Descripcion, CodigoBPRO, IDBanco
			FROM           referencias.DBO. CodigoIdentificacion
			where descripcion like 'IVA INTERES%' and CodigoBanco 
			like 'C%'
			)
		 and idbmer  between @idDepositoBanco-10 and @idDepositoBanco+10
	END
	ELSE IF(@idBanco = 2) --Banamex
		
	BEGIN
		SELECT 
		  idBanamex idDepositoBanco
		  ,[idBanco]
		  ,[idBanamex]
		  ,'banamex' banco
		  ,[archivo]
		  ,[noCuenta]
		  ,[AODescripcion]
		  ,[SLMonto] as abono
		  ,0 as cargo
		  ,[OBmontoApertura]
		  ,[SLTipoReferencia]
		  ,[SLFechaTransaccion]
		  ,'12:00:00' as horaOperacion
		  ,'0' as [oficinaOperadora]

	 FROM referencias.DBO.Banamex WHERE SLCodigoTransaccion IN
	(
		SELECT        CodigoBanco--, TipoMovimiento, Descripcion, CodigoBPRO, IDBanco
		FROM           referencias.DBO. CodigoIdentificacion
		where descripcion like '%IVA INT%' 
		and IdBanco = 2
		)

	AND  idbanamex not in (select comisionID from InteresComision where BancoID = 2)
	END


END
go

