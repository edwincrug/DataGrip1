
CREATE PROCEDURE [dbo].[SEL_TEST_API]
--SEL_TEST_API 1, 'ho9la'
	@valorUno as int,
	@valorDos as varchar(50)
as
BEGIN

select  @valorUno as res1 , @valorDos as res2
	
END

go

