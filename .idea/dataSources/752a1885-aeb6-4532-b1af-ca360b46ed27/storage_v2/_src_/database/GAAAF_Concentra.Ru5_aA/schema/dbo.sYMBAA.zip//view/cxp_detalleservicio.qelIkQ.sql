CREATE VIEW [dbo].[cxp_detalleservicio]
AS
SELECT  
ser_iddetalle, ser_numeroserie, ser_aniomodelo, ser_modelo, ser_idmarca, ser_idcolorext, ser_idcolorint, ser_kilometraje, ser_fechapromentrega, ser_horapromentrega, ser_idcliente, ser_clasificacion, ser_descripcion, ser_precio, ser_costo, ser_idasesor, ser_comentarios, oce_folioorden, ser_ordenservicio
FROM        CUENTASXPAGAR.dbo.cxp_detalleservicio
go

