CREATE VIEW VIS_CONPOLDIRERR AS Select '01' as VCOE_Empresa,'2003' as VCOE_Anno,* FROM CON_POLDIRERR012003
 union all Select '01' as VCOE_Empresa,'2004' as VCOE_Anno,* FROM CON_POLDIRERR012004
 union all Select '01' as VCOE_Empresa,'2005' as VCOE_Anno,* FROM CON_POLDIRERR012005
 union all Select '01' as VCOE_Empresa,'2006' as VCOE_Anno,* FROM CON_POLDIRERR012006
 union all Select '01' as VCOE_Empresa,'2007' as VCOE_Anno,* FROM CON_POLDIRERR012007
 union all Select '01' as VCOE_Empresa,'2008' as VCOE_Anno,* FROM CON_POLDIRERR012008
 union all Select '01' as VCOE_Empresa,'2009' as VCOE_Anno,* FROM CON_POLDIRERR012009
 union all Select '01' as VCOE_Empresa,'2010' as VCOE_Anno,* FROM CON_POLDIRERR012010
 union all Select '01' as VCOE_Empresa,'2011' as VCOE_Anno,* FROM CON_POLDIRERR012011
 union all Select '01' as VCOE_Empresa,'2012' as VCOE_Anno,* FROM CON_POLDIRERR012012
 union all Select '01' as VCOE_Empresa,'2013' as VCOE_Anno,* FROM CON_POLDIRERR012013
 union all Select '01' as VCOE_Empresa,'2014' as VCOE_Anno,* FROM CON_POLDIRERR012014
 union all Select '01' as VCOE_Empresa,'2015' as VCOE_Anno,* FROM CON_POLDIRERR012015
 union all Select '01' as VCOE_Empresa,'2016' as VCOE_Anno,* FROM CON_POLDIRERR012016
 union all Select '01' as VCOE_Empresa,'2017' as VCOE_Anno,* FROM CON_POLDIRERR012017
 union all Select '01' as VCOE_Empresa,'2018' as VCOE_Anno,* FROM CON_POLDIRERR012018
 union all Select '01' as VCOE_Empresa,'2019' as VCOE_Anno,* FROM CON_POLDIRERR012019
 union all Select '01' as VCOE_Empresa,'2020' as VCOE_Anno,* FROM CON_POLDIRERR012020
go

