CREATE VIEW [dbo].[cxp_loganticipos]
AS
SELECT 
lan_idloganticipos, lan_idempresa, lan_idsucursal, lan_error, lan_fecha, lan_folioorden
FROM cuentasxpagar.dbo.cxp_loganticipos
go

