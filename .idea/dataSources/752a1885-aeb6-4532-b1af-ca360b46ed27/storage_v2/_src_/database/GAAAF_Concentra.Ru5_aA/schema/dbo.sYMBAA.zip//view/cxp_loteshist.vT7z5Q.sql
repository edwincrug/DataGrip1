CREATE VIEW [dbo].[cxp_loteshist]
AS
SELECT 
lts_idlotehist, lts_idempresahist, lts_numlotehist, lts_cuentapagadorahist, lts_importetotalhist, lts_usualtahist, lts_fechaalta, lts_numdocautorizahist, lts_idflujoefectivohist, lts_saldoflujohist, lts_usuautorizahist, lts_fechaautorizahist, lts_txtgeneradohist, lts_idsituacionhist
FROM    cuentasxpagar.dbo.cxp_loteshist
go

