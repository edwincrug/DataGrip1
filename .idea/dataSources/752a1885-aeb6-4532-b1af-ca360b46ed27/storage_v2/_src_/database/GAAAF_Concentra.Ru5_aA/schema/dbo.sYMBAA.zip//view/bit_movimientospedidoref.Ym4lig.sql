CREATE VIEW [dbo].[bit_movimientospedidoref]
AS
SELECT mpr_idmovimiento, mpr_idcotizacion, mpr_estatus, mpr_usuario, mpr_fecha, 
pre_idpedidoref, mpr_error, spe_idsituacionpedido
FROM PortalRefacciones.dbo.bit_movimientospedidoref
go

