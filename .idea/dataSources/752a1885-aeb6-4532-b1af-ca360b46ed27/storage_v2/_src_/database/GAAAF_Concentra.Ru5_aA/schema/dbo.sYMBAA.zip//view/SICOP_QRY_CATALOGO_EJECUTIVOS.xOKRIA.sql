create view [dbo].[SICOP_QRY_CATALOGO_EJECUTIVOS] AS
select convert(varchar,PER_IDPERSONA) + substring('               ',1,15-len(PER_IDPERSONA)) as Clave_Ejecutivo,
PER_PATERNO + substring('                                                  ',1,50-len(PER_PATERNO)) as Apellido_Paterno,
PER_MATERNO + substring('                                                  ',1,50-len(PER_MATERNO)) as Apellido_Materno,
PER_NOMRAZON + substring('                                                  ',1,50-len(PER_NOMRAZON)) as Nombre 
FROM Per_Personas, PER_ROLES where per_idpersona = rol_idpersona and rol_rol = 'VENU'
go

