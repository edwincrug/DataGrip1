CREATE VIEW [dbo].[UNI_CCS]
AS
SELECT
ucc_idcc, ucu_idcotizacion, ucc_monto, ucc_cartera, ucc_usuarioalta, ucc_fechaalta, ucc_fechamodifica, ucc_usuariomodifica, ucc_estatus, ucc_idpoliticadescuentos, UCC_FOLIOORDENPROVISION
FROM        cuentasporcobrar.dbo.UNI_CCS
go

