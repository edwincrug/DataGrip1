------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create view [dbo].[VIS_LTPEDIUNI] as 
select 'GAAAF_Viga'  as PEN_BD,GAAAF_Viga.[dbo].uni_ltpediuni.*  from GAAAF_Viga.[dbo].uni_ltpedido  inner join GAAAF_Viga.[dbo].uni_ltpediuni  on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO 
union all
select 'GAAAF_Zaragoza'     as PEN_BD,[GAAAF_Zaragoza].[dbo].uni_ltpediuni.*     from [GAAAF_Zaragoza].[dbo].uni_ltpedido     inner join [GAAAF_Zaragoza].[dbo].uni_ltpediuni     on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO 
union all
select 'GAAAF_Tepepan'     as PEN_BD,[GAAAF_Tepepan].[dbo].uni_ltpediuni.*     from [GAAAF_Tepepan].[dbo].uni_ltpedido     inner join [GAAAF_Tepepan].[dbo].uni_ltpediuni     on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO
go

