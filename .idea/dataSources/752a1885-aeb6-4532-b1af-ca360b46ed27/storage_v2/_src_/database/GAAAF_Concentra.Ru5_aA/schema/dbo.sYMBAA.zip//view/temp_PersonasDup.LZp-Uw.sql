create view [dbo].[temp_PersonasDup] as
select PER_PATERNO+ ' '+ PER_MATERNO+' '+PER_NOMRAZON  as nombre,per_paterno, per_materno,per_nomrazon,COUNT(1) as veces 
from PER_PERSONAS 
GROUP BY PER_PATERNO+ ' '+ PER_MATERNO+' '+PER_NOMRAZON, per_paterno, per_materno,per_nomrazon
having COUNT(1) > 1
go

