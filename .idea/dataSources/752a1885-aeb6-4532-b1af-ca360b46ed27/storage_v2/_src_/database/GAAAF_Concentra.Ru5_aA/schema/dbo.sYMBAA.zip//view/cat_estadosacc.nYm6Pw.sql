CREATE VIEW [dbo].[cat_estadosacc]
AS
SELECT 
cea_idestadoacc, cea_descripcion, cea_nombrecorto, cea_estatus, cea_fechaalta, cea_usuarioalta, cea_usuariomodifica, cea_fechamodifica
FROM cuentasporcobrar.dbo.cat_estadosacc
go

