CREATE VIEW [dbo].[cxp_doctospagados]
AS
SELECT
dpa_iddoctopagado, dpa_conscartera, dpa_iddocumento, dpa_idpersona, dpa_cuentapagadora, dpa_cuentabeneficiario, dpa_importepagado, dpa_folioorden, dpa_pagoaplicado, dpa_lote, dpa_idempresa, dpa_fechaaplicacion, dpa_conscarapl, dpa_mes, dpa_conveniocie
FROM      CUENTASXPAGAR.dbo.cxp_doctospagados
go

