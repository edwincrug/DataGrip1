CREATE VIEW [dbo].[cxp_detallerefacciones]
AS
SELECT  
ref_iddetalle, ref_codigoparte, ref_descripcion, ref_disponibilidad, ref_costopromedio, ref_costounitario, ref_requerido, ref_costototal, ref_almacen, ref_idvendedor, ref_clasificacion, ref_fechapromentrega, ref_horapromentrega, ref_comentarios, oce_folioorden, ref_recibido, ref_costorecibido, ref_idsituaciondetalle, ref_tipocompra, ref_cantrec, ref_autoriza
FROM     CUENTASXPAGAR.dbo.cxp_detallerefacciones
go

