CREATE VIEW [dbo].[cxp_detalleaccesorios]
AS
SELECT 
acr_iddetalle, acr_numeroserie, acr_idtipocompra, acr_idsituacion, acr_fechapromentrega, acr_horapromentrega, acr_descripcioncompra, acr_idtipo, acr_monedacompra, acr_costo, acr_iva, acr_costototal, acr_monedaventa, acr_precioventa, acr_comentarios, oce_folioorden
FROM       CUENTASXPAGAR.dbo.cxp_detalleaccesorios
go

