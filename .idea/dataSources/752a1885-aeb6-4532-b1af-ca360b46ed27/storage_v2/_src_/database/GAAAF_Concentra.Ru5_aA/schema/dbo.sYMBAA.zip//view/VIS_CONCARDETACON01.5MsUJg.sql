CREATE VIEW VIS_CONCARDETACON01 AS Select '01' as Vcd_Empresa,'2003' as Vcd_Anno,* FROM Con_CarDetaCON012003
 union all Select '01' as Vcd_Empresa,'2004' as Vcd_Anno,* FROM Con_CarDetaCON012004
 union all Select '01' as Vcd_Empresa,'2005' as Vcd_Anno,* FROM Con_CarDetaCON012005
 union all Select '01' as Vcd_Empresa,'2006' as Vcd_Anno,* FROM Con_CarDetaCON012006
 union all Select '01' as Vcd_Empresa,'2007' as Vcd_Anno,* FROM Con_CarDetaCON012007
 union all Select '01' as Vcd_Empresa,'2008' as Vcd_Anno,* FROM Con_CarDetaCON012008
 union all Select '01' as Vcd_Empresa,'2009' as Vcd_Anno,* FROM Con_CarDetaCON012009
 union all Select '01' as Vcd_Empresa,'2010' as Vcd_Anno,* FROM Con_CarDetaCON012010
 union all Select '01' as Vcd_Empresa,'2011' as Vcd_Anno,* FROM Con_CarDetaCON012011
 union all Select '01' as Vcd_Empresa,'2012' as Vcd_Anno,* FROM Con_CarDetaCON012012
 union all Select '01' as Vcd_Empresa,'2013' as Vcd_Anno,* FROM Con_CarDetaCON012013
 union all Select '01' as Vcd_Empresa,'2014' as Vcd_Anno,* FROM Con_CarDetaCON012014
 union all Select '01' as Vcd_Empresa,'2015' as Vcd_Anno,* FROM Con_CarDetaCON012015
 union all Select '01' as Vcd_Empresa,'2016' as Vcd_Anno,* FROM Con_CarDetaCON012016
 union all Select '01' as Vcd_Empresa,'2017' as Vcd_Anno,* FROM Con_CarDetaCON012017
 union all Select '01' as Vcd_Empresa,'2018' as Vcd_Anno,* FROM Con_CarDetaCON012018
 union all Select '01' as Vcd_Empresa,'2019' as Vcd_Anno,* FROM Con_CarDetaCON012019
 union all Select '01' as Vcd_Empresa,'2020' as Vcd_Anno,* FROM Con_CarDetaCON012020
go

