create view [dbo].[CXP_FLOTILLAS] as 
select 
flo_idflotilla, flo_idempresa, flo_idsucursal, flo_proveedor, flo_flotillapara, flo_fechaflotilla, flo_usuarioflotilla, flo_cantidad, flo_catalogo, flo_aniomodelo, flo_modelo, flo_numeroflotilla, flo_importeflotilla, flo_nombreflotilla, flo_numautorizaplanta 
from cuentasxpagar.dbo.CXP_FLOTILLAS
go

