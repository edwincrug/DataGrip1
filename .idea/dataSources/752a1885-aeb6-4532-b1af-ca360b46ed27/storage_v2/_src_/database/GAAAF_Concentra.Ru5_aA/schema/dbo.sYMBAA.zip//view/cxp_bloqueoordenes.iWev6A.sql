CREATE VIEW [dbo].[cxp_bloqueoordenes]
AS
SELECT 
boc_idbloqueo, boc_folioorden, boc_fechamov, boc_horamov, boc_idusuariomov, boc_motivobloqueo, boc_motivodesbloqueo, boc_estatusorden
FROM    cuentasxpagar.dbo.cxp_bloqueoordenes
go

