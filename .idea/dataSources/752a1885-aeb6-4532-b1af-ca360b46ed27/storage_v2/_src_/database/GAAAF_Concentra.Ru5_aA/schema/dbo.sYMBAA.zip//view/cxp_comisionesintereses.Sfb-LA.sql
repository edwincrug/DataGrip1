CREATE VIEW [dbo].[cxp_comisionesintereses]
AS
SELECT 
coi_idcomisionesintereses, coi_idempresa, coi_idsucursal, coi_tipopoliza, coi_fechapoliza, coi_descripcion, coi_fechageneracion, coi_estatus, coi_cuentabeneficiario, coi_cuentapagadora, coi_cobrador, coi_moneda, coi_tipocambio, coi_formapago, coi_tipo
FROM cuentasxpagar.dbo.cxp_comisionesintereses
go

