CREATE VIEW [dbo].[cxp_planpisolog]
AS
SELECT
plp_folio, plo_descripcion, plo_fecha
FROM  GA_Corporativa.dbo.cxp_planpisolog
go

