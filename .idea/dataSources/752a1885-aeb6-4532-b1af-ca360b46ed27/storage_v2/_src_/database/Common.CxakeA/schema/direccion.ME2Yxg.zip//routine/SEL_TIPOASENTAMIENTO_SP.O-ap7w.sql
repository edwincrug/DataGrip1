
-- =============================================
-- Author:		Uriel Hernandez
-- Create date: <06/11/2020>
-- Description:	Obtiene el tipo de Asentamiento
-- =============================================
/*
	Fecha:25/02/2019		Autor	Descripción 
	--2019

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [direccion].[SEL_TIPOASENTAMIENTO_SP]
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [direccion].[SEL_TIPOASENTAMIENTO_SP]
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS

BEGIN	
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET NOCOUNT ON;
	SET @err = '';
	
	SELECT * FROM [direccion].[TipoAsentamiento] ORDER BY [nombre]
	
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

