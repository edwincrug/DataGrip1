
-- =============================================
-- Author:		<Uriel hernandez>
-- Create date: <06/11/2020>
-- Description:	<Obtiene por cp el estado y el municipio>
-- =============================================
/*
	Fecha:12/02/2019		Autor	Descripción 
	--2019

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [direccion].[SEL_CPAUTOCIMPLETE_SP]
		@cp = '57000',
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [direccion].[SEL_CPAUTOCIMPLETE_SP]
	@idUsuario				int,
	@cp						varchar(5),
	@err					varchar(max) OUTPUT
AS

BEGIN	
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET NOCOUNT ON;
	SET @err = '';

	SELECT TOP (100)
       Cp.[idPais]
      ,Pais.nombre as nombrePais
     ,Cp.[idEstado]
      ,Edo.nombre	AS nombreEstado
     ,Cp.[idMunicipio]
      ,Mun.nombre AS nombreMunicipio
     ,[CP]
     ,Cp.[idTipoAsentamiento]
      ,tAs.nombre as nombreTipoAsentamiento
     ,Cp.[idAsentamiento]
      ,Ase.nombre AS nombreAsentamiento
     ,Cp.[idUsuario]
 FROM [Common].[direccion].[CP] AS CP
    inner join [direccion].[Pais] AS Pais ON Pais.idPais = CP.idPais
    inner join [direccion].[Estado] AS Edo ON edo.idPais = CP.idPais AND edo.idEstado = CP.idEstado
    inner join [direccion].Municipio AS Mun ON Mun.idPais = CP.idPais AND Mun.idEstado = CP.idEstado AND Mun.idMunicipio = CP.idMunicipio
    inner join [direccion].Asentamiento AS Ase ON Ase.idPais = CP.idPais AND Ase.idEstado = CP.idEstado AND Ase.idMunicipio = CP.idMunicipio AND Ase.idAsentamiento = CP.idAsentamiento
    inner join [direccion].TipoAsentamiento AS tAs ON tAs.idTipoAsentamiento = CP.idTipoAsentamiento
	where Cp.Cp = @cp

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

