
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <01/11/2020>
-- Description:	<Obtiene sucursales>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [bpro].[SEL_EMPRESAS_SP]
		@idUsuario = 45,
		@produccion  = 0,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [bpro].[SEL_EMPRESAS_SP]
	@idUsuario				int,
	@produccion				BIT,
	@err					varchar(max) OUTPUT
AS

BEGIN
	SET @err = '';

	DECLARE @BD VARCHAR(100),
			@Sql NVARCHAR(MAX);


	IF(@produccion = 1)
		BEGIN
			SELECT
			@BD = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 1
		AND nombre = 'bpro'
		END

	ELSE
		BEGIN

			SELECT
				@BD = servidor
			FROM [common].[bpro].[servidorBPRO]
			WHERE idambiente = 2
			AND nombre = 'bpro'
		END

		

	SET @Sql = 'select DISTINCT
					E.emp_idempresa,
					E.emp_nombre,
					E.emp_observaciones,
					E.emp_estatus			
				from seguridad.catalogo.usuario U
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_usuarios] UB ON LTRIM(RTRIM(UB.usu_nombreusu)) = LEFT(username,( CHARINDEX(''@'', USERNAME) -1)) COLLATE Modern_Spanish_CI_AS
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[ope_organigrama] O ON O.usu_idusuario  = ub.usu_idusuario
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_empresas] E ON E.emp_idempresa = O.emp_idempresa
				WHERE id = ' +  CAST(@idusuario AS VARCHAR(50)) 
	print @sql
	EXEC sp_executesql @Sql


END



go

