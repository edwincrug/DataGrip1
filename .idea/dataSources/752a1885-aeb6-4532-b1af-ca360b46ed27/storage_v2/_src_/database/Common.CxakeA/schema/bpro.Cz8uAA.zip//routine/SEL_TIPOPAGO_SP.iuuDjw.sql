
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <24/10/2020>
-- Description:	<Obtiene sucursales>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [bpro].[SEL_TIPOPAGO_SP]
	@produccion = 0,
	@idEmpresa = 9,
	@idSucursal = 18,
		@idUsuario = 69,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;

*/

-- =============================================
CREATE PROCEDURE [bpro].[SEL_TIPOPAGO_SP]
	@produccion				BIT,
	@idEmpresa				INT,
	@idSucursal				INT,
	@idUsuario				int,
	@err					varchar(max) OUTPUT

AS

BEGIN


	DECLARE @Sql NVARCHAR(MAX),
			@server VARCHAR(100),
			@BDSucursal VARCHAR(100)

	IF(@produccion = 1)
		BEGIN
			SELECT
			@server = servidor
		FROM [common].[bpro].[servidorBPRO] 
		WHERE idambiente = 1
		AND nombre = 'bpro'
		END

	ELSE
		BEGIN

			SELECT
				@server = servidor
			FROM [common].[bpro].[servidorBPRO]
			WHERE idambiente = 2
			AND nombre = 'bpro'
		END

	DECLARE @sqlCommand NVARCHAR(4000)

	SET @sqlCommand = 'SELECT  @BDSucursal = nombre_base
	FROM ' +  @server + '.Centralizacionv2.DBO.DIG_CAT_BASES_BPRO 
	WHERE emp_idempresa = @idEmpresa
	AND suc_idsucursal = @idSucursal'
	EXEC sp_executesql @sqlCommand, N'@idEmpresa INT, @idSucursal INT,  @BDSucursal VARCHAR(100) OUTPUT',
	@idEmpresa = @idEmpresa,@idSucursal = @idSucursal, @BDSucursal = @BDSucursal OUTPUT

	SET @Sql = 'SELECT  
				PAR_IDENPARA,
				PAR_DESCRIP1
				FROM '  + @server + '.' + @BDSucursal + '.[dbo].PNC_PARAMETR WHERE PAR_TIPOPARA = ''FP'' '

	print @sql
	EXEC sp_executesql @Sql


END

go

