-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <20/10/2020>
-- Description:	<Agregar Excepciones>
-- =============================================
/*
	Fecha			Autor		Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [Excepcion].[INS_EXCEPCION_SP] @idTipoExcepcion= 1, @idUsuario= 1, @idAplicacion=1, @mensajeExcepcion = 'mi msj', @stacktraceExcepcion ='stack....', @err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [excepcion].[INS_EXCEPCION_SP]
	@idTipoExcepcion		int,
	@idUsuario				int,
	@idOperacion			int = null,
	@idAplicacion			int,
	@moduloExcepcion		nvarchar(max) = '',
	@mensajeExcepcion		nvarchar(max),
	@stacktraceExcepcion	nvarchar(max),
	@err					varchar(max) OUTPUT
AS
BEGIN
	SET @err = '';
	
	INSERT INTO [Excepcion].[Excepcion] 
		(
			idTipoExcepcion,
			idUsuario,
			idOperacion,
			idAplicacion,
			idEstatus,
			fechaExcepcion,
			moduloExcepcion,
			mensajeExcepcion,
			stacktraceExcepcion
		) 
	VALUES 
		(
			@idTipoExcepcion, 
			@idUsuario, 
			@idOperacion,
			@idAplicacion,
			1, 
			getdate(), 
			@moduloExcepcion, 
			@mensajeExcepcion, 
			@stacktraceExcepcion
		)

--	SELECT 'Insertado' as result
	
	SELECT	'Insertado' as result,
			ISNULL(PrimerNombre,'') + 
			CASE WHEN SegundoNombre IS NULL THEN '' ELSE ' '+segundoNombre END +
			CASE WHEN PrimerApellido IS NULL THEN '' ELSE ' '+PrimerApellido END +
			CASE WHEN SegundoApellido IS NULL THEN '' ELSE ' '+SegundoApellido END 'requesterName',
			Email 'requesterMail'
	FROM	Seguridad.catalogo.Usuario
	WHERE	id=@idUsuario --6282
END
go

