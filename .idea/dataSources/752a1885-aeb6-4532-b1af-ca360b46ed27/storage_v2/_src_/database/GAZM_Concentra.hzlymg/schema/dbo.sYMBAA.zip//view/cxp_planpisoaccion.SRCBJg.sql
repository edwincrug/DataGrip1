CREATE VIEW [dbo].[cxp_planpisoaccion]
AS
SELECT 
acc_idaccion, acc_idempresa, acc_idsucursal, acc_descripcion, acc_carterafinan, acc_tipoli, acc_areped, acc_conven, acc_fechaalta, acc_idusuarioalta, acc_fechamodifica, acc_idusuariomodifica
FROM  GA_Corporativa.dbo.cxp_planpisoaccion
go

