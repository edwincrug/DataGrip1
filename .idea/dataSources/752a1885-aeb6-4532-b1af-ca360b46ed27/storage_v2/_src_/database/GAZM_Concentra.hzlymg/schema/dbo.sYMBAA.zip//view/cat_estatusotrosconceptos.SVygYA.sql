CREATE VIEW [dbo].[cat_estatusotrosconceptos]
AS
SELECT 
ceo_idestatusotrosconceptos, ceo_nombrecorto, ceo_nombre, ceo_descripcion, ceo_idusuarioalta, ceo_fechaalta, ceo_idusuariomodifica, ceo_fechamodifica, ceo_estatus
FROM       CUENTASPORCOBRAR.dbo.cat_estatusotrosconceptos
go

