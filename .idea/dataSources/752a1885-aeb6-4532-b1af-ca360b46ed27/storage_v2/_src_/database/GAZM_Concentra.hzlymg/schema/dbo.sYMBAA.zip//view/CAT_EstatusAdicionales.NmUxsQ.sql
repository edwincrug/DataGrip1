CREATE VIEW [dbo].[CAT_EstatusAdicionales]
AS
SELECT 
CEA_IdEstatusAdicionales, CEA_NombreCorto, CEA_Nombre, CEA_IdUsuarioAlta, CEA_FechaAlta, CEA_IdUsuarioModifica, CEA_FechaModifica, CEA_Estatus
FROM  [cuentasporcobrar].DBO.CAT_EstatusAdicionales
go

