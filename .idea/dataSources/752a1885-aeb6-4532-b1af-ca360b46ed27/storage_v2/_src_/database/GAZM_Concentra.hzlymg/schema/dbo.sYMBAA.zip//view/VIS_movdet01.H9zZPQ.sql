
CREATE VIEW [dbo].[VIS_movdet01] AS Select '01' as Vmd_Empresa,'2003' as Vmd_Anno,* FROM con_movdet012003

 union all Select '01' as Vmd_Empresa,'2004' as Vmd_Anno,* FROM con_movdet012004

 union all Select '01' as Vmd_Empresa,'2005' as Vmd_Anno,* FROM con_movdet012005

 union all Select '01' as Vmd_Empresa,'2006' as Vmd_Anno,* FROM con_movdet012006

 union all Select '01' as Vmd_Empresa,'2007' as Vmd_Anno,* FROM con_movdet012007
 union all Select '01' as Vmd_Empresa,'2008' as Vmd_Anno,* FROM con_movdet012008
 union all Select '01' as Vmd_Empresa,'2009' as Vmd_Anno,* FROM con_movdet012009
 union all Select '01' as Vmd_Empresa,'2010' as Vmd_Anno,* FROM con_movdet012010
 union all Select '01' as Vmd_Empresa,'2011' as Vmd_Anno,* FROM con_movdet012011
 union all Select '01' as Vmd_Empresa,'2012' as Vmd_Anno,* FROM con_movdet012012
 union all Select '01' as Vmd_Empresa,'2013' as Vmd_Anno,* FROM con_movdet012013
 union all Select '01' as Vmd_Empresa,'2014' as Vmd_Anno,* FROM con_movdet012014
 union all Select '01' as Vmd_Empresa,'2015' as Vmd_Anno,* FROM con_movdet012015
 union all Select '01' as Vmd_Empresa,'2016' as Vmd_Anno,* FROM con_movdet012016
 union all Select '01' as Vmd_Empresa,'2017' as Vmd_Anno,* FROM con_movdet012017
 union all Select '01' as Vmd_Empresa,'2018' as Vmd_Anno,* FROM con_movdet012018
 union all Select '01' as Vmd_Empresa,'2019' as Vmd_Anno,* FROM con_movdet012019

go

