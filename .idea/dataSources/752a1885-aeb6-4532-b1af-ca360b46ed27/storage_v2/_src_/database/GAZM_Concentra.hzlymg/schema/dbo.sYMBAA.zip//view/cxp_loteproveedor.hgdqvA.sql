CREATE VIEW [dbo].[cxp_loteproveedor]
AS
SELECT 
plt_idloteproveedor, plt_idempresa, plt_idsucursal, plt_idproveedor, plt_numerolote, plt_fechalote, plt_idusulote, plt_iddocto, plt_folioordencompra, plt_montodocto, plt_idususalida, plt_fechasalida, plt_motivo
FROM        cuentasxpagar.dbo.cxp_loteproveedor
go

