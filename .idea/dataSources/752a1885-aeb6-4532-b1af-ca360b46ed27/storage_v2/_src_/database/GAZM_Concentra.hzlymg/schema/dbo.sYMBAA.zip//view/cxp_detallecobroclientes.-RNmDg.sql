CREATE VIEW [dbo].[cxp_detallecobroclientes]
AS
SELECT 
dcc_iddetallecobroclientes, dcc_montosiniva, dcc_montoconiva, dcc_idpersona, dcc_fecha, dcc_referenciabancaria, oce_folioorden 
FROM cuentasxpagar.dbo.cxp_detallecobroclientes
go

