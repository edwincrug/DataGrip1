CREATE VIEW cxp_planpiso
AS
SELECT  
plp_folio, plp_idaccion, oce_folioorden, oce_idempresa, oce_idsucursal, plp_numeroserie, plp_concepto, plp_monto, plp_numerolote, plp_idfinanorigen, plp_idfinandestino, plp_tipopol, plp_conspol, plp_mes, plp_idstatus, plp_año
FROM  GA_Corporativa.dbo.cxp_planpiso
go

