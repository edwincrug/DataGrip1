CREATE VIEW cxp_logaplicacion
AS
SELECT 
lap_idlogaplicacion, lap_lote, lap_idempresa, lap_idproveedor, lap_descripcion, lap_fechaalta, lap_hora
FROM cuentasxpagar.dbo.cxp_logaplicacion
go

