

CREATE VIEW [dbo].[BI_VIEW_SALDOS_FINALES_2019] AS

SELECT CTA_NUMCTA,CTA_SDOINICIAL,
SI_ENE = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1) - (cta_abono1) - cta_cargo1 + cta_abono1 
ELSE 
CTA_SDOINICIAL - (cta_cargo1) + (cta_abono1) + cta_cargo1 - cta_abono1 
END,
SI_FEB = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2) - (cta_abono1+cta_abono2) - cta_cargo2 + cta_abono2 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2) + (cta_abono1+cta_abono2) + cta_cargo2 - cta_abono2 
END,
SI_MAR = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3) - (cta_abono1+cta_abono2+cta_abono3) - cta_cargo3 + cta_abono3 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3) + (cta_abono1+cta_abono2+cta_abono3) + cta_cargo3 - cta_abono3 
END,
SI_ABR = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4) - cta_cargo4 + cta_abono4 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4) + cta_cargo4 - cta_abono4 
END,
SI_MAY = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5) - cta_cargo5 + cta_abono5 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5) + cta_cargo5 - cta_abono5 
END,
SI_JUN = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6) - cta_cargo6 + cta_abono6 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6) + cta_cargo6 - cta_abono6 
END,
SI_JUL = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7) - cta_cargo7 + cta_abono7 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7) + cta_cargo7 - cta_abono7 
END,
SI_AGO = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8) - cta_cargo8 + cta_abono8 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8) + cta_cargo8 - cta_abono8 
END,
SI_SEP = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9) - cta_cargo9 + cta_abono9 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9) + cta_cargo9 - cta_abono9 
END,
SI_OCT = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10) - cta_cargo10 + cta_abono10 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10) + cta_cargo10 - cta_abono10 
END,
SI_NOV = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10+cta_cargo11) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10+cta_abono11) - cta_cargo11 + cta_abono11 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10+cta_cargo11) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10+cta_abono11) + cta_cargo11 - cta_abono11 
END,
SI_DIC = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10+cta_cargo11+cta_cargo12) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10+cta_abono11+cta_abono12) - cta_cargo12 + cta_abono12 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10+cta_cargo11+cta_cargo12) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10+cta_abono11+cta_abono12) + cta_cargo12 - cta_abono12 
END,
--SALDO FINAL
SF_ENE = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1) - (cta_abono1) - cta_cargo1 + cta_abono1 + cta_cargo1 - cta_abono1
ELSE 
CTA_SDOINICIAL - (cta_cargo1) + (cta_abono1) + cta_cargo1 - cta_abono1 - cta_cargo1 + cta_abono1
END,
SF_FEB = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2) - (cta_abono1+cta_abono2) - cta_cargo2 + cta_abono2 + cta_cargo2 - cta_abono2
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2) + (cta_abono1+cta_abono2) + cta_cargo2 - cta_abono2 - cta_cargo2 + cta_abono2
END,
SF_MAR = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3) - (cta_abono1+cta_abono2+cta_abono3) - cta_cargo3 + cta_abono3 + cta_cargo3 - cta_abono3   
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3) + (cta_abono1+cta_abono2+cta_abono3) + cta_cargo3 - cta_abono3 - cta_cargo3 + cta_abono3
END,
SF_ABR = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4) - cta_cargo4 + cta_abono4 + cta_cargo4 - cta_abono4 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4) + cta_cargo4 - cta_abono4 - cta_cargo4 + cta_abono4
END,
SF_MAY = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5) - cta_cargo5 + cta_abono5 + cta_cargo5 - cta_abono5
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5) + cta_cargo5 - cta_abono5 - cta_cargo5 + cta_abono5 
END,
SF_JUN = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6) - cta_cargo6 + cta_abono6 + cta_cargo6 - cta_abono6
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6) + cta_cargo6 - cta_abono6 - cta_cargo6 + cta_abono6
END,
SF_JUL = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7) - cta_cargo7 + cta_abono7 + cta_cargo7 - cta_abono7
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7) + cta_cargo7 - cta_abono7 - cta_cargo7 + cta_abono7
END,
SF_AGO = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8) - cta_cargo8 + cta_abono8 + cta_cargo8 - cta_abono8
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8) + cta_cargo8 - cta_abono8 - cta_cargo8 + cta_abono8
END,
SF_SEP = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9) - cta_cargo9 + cta_abono9 + cta_cargo9 - cta_abono9
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9) + cta_cargo9 - cta_abono9 - cta_cargo9 + cta_abono9
END,
SF_OCT = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10) - cta_cargo10 + cta_abono10 + cta_cargo10 - cta_abono10
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10) + cta_cargo10 - cta_abono10 - cta_cargo10 + cta_abono10
END,
SF_NOV = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10+cta_cargo11) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10+cta_abono11) - cta_cargo11 + cta_abono11 + cta_cargo11 - cta_abono11
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10+cta_cargo11) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10+cta_abono11) + cta_cargo11 - cta_abono11 - cta_cargo11 + cta_abono11
END,
SF_DIC = CASE WHEN CTA_NATURALEZA = 'DEUD' THEN 
CTA_SDOINICIAL + (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10+cta_cargo11+cta_cargo12) - (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10+cta_abono11+cta_abono12) - cta_cargo12 + cta_abono12 + cta_cargo12 - cta_abono12 
ELSE 
CTA_SDOINICIAL - (cta_cargo1+cta_cargo2+cta_cargo3+cta_cargo4+cta_cargo5+cta_cargo6+cta_cargo7+cta_cargo8+cta_cargo9+cta_cargo10+cta_cargo11+cta_cargo12) + (cta_abono1+cta_abono2+cta_abono3+cta_abono4+cta_abono5+cta_abono6+cta_abono7+cta_abono8+cta_abono9+cta_abono10+cta_abono11+cta_abono12) + cta_cargo12 - cta_abono12 - cta_cargo12 + cta_abono12
END
FROM CON_CTAS012019
go

