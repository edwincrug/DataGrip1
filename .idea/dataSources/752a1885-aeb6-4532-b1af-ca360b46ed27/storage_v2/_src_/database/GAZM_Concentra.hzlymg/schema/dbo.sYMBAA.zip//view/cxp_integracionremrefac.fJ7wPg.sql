CREATE VIEW [dbo].[cxp_integracionremrefac]
AS
SELECT 
irr_idintegracionremrefac, irr_folionuevo, irr_folioinicial, irr_numeroparte, irr_cantidad
FROM        cuentasxpagar.dbo.cxp_integracionremrefac
go

