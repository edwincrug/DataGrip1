CREATE VIEW [dbo].[cxp_integracionfacrefac]
AS
SELECT 
ifr_idintegracionfacrefac, ifr_folionuevo, ifr_folioinicial, ifr_numeroparte, ifr_cantidad
FROM         cuentasxpagar.dbo.cxp_integracionfacrefac
go

