CREATE VIEW cxp_comisionesinteresesdet
AS
SELECT 
cid_idcomisionesinteresesdet, cid_cuentacontable, cid_concepto, cid_cargo, cid_abono, cid_documento, cid_idpersona, coi_idcomisionesintereses, cid_tipodocumento, cid_fechavencimiento, cid_poriva, cid_referencia, cid_banco, cid_referenciabancaria, cid_conpoliza
FROM cuentasxpagar.dbo.cxp_comisionesinteresesdet
go

