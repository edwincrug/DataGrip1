CREATE VIEW VIS_CONCARDETA01 AS Select '01' as Vcd_Empresa,'2003' as Vcd_Anno,* FROM Con_CarDeta012003
 union all Select '01' as Vcd_Empresa,'2004' as Vcd_Anno,* FROM Con_CarDeta012004
 union all Select '01' as Vcd_Empresa,'2005' as Vcd_Anno,* FROM Con_CarDeta012005
 union all Select '01' as Vcd_Empresa,'2006' as Vcd_Anno,* FROM Con_CarDeta012006
 union all Select '01' as Vcd_Empresa,'2007' as Vcd_Anno,* FROM Con_CarDeta012007
 union all Select '01' as Vcd_Empresa,'2008' as Vcd_Anno,* FROM Con_CarDeta012008
 union all Select '01' as Vcd_Empresa,'2009' as Vcd_Anno,* FROM Con_CarDeta012009
 union all Select '01' as Vcd_Empresa,'2010' as Vcd_Anno,* FROM Con_CarDeta012010
 union all Select '01' as Vcd_Empresa,'2011' as Vcd_Anno,* FROM Con_CarDeta012011
 union all Select '01' as Vcd_Empresa,'2012' as Vcd_Anno,* FROM Con_CarDeta012012
 union all Select '01' as Vcd_Empresa,'2013' as Vcd_Anno,* FROM Con_CarDeta012013
 union all Select '01' as Vcd_Empresa,'2014' as Vcd_Anno,* FROM Con_CarDeta012014
 union all Select '01' as Vcd_Empresa,'2015' as Vcd_Anno,* FROM Con_CarDeta012015
 union all Select '01' as Vcd_Empresa,'2016' as Vcd_Anno,* FROM Con_CarDeta012016
 union all Select '01' as Vcd_Empresa,'2017' as Vcd_Anno,* FROM Con_CarDeta012017
 union all Select '01' as Vcd_Empresa,'2018' as Vcd_Anno,* FROM Con_CarDeta012018
 union all Select '01' as Vcd_Empresa,'2019' as Vcd_Anno,* FROM Con_CarDeta012019
 union all Select '01' as Vcd_Empresa,'2020' as Vcd_Anno,* FROM Con_CarDeta012020
go

