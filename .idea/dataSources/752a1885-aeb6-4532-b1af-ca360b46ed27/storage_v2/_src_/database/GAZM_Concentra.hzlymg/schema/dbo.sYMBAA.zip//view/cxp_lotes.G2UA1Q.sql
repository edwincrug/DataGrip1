CREATE VIEW [dbo].[cxp_lotes]
AS
SELECT 
lts_idlote, lts_idempresa, lts_numlote, lts_cuentapagadora, lts_importetotal, lts_usualta, lts_fechaalta, lts_docautorizado, lts_idflujoefectivo, lts_saldoflujo, lts_usuautoriza, lts_fechaautoriza, slt_idsituacion, lts_txtgenerado, lts_fechatxt, lts_usuariotxt
FROM      cuentasxpagar.dbo.cxp_lotes
go

