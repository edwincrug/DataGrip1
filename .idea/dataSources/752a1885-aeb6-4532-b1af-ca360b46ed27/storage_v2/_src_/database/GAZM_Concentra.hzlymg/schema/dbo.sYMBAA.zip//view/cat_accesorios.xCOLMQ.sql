CREATE VIEW [dbo].[cat_accesorios]
AS
SELECT 
caa_idacce, caa_descripacce, caa_estatus, caa_usuarioalta, caa_fechaalta, caa_usuariomodifica, caa_fechamodifica, caa_iddivision, caa_idempresa, caa_idsucursal, caa_iddepartamento, caa_SKU
FROM cuentasporcobrar.dbo.cat_accesorios
go

