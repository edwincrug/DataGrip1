CREATE VIEW [dbo].[cxp_bloqueoproveedores]
AS
SELECT 
bpv_idbloqueo, bpv_idproveedor, bpv_fechamov, bpv_horamov, bpv_idusuariomov, bpv_motivobloqueo, bpv_motivodesbloqueo, bpv_estatusproveedor
FROM    cuentasxpagar.dbo.cxp_bloqueoproveedores
go

