CREATE VIEW [dbo].[cxp_detalleseminuevos]
AS
SELECT 
asn_iddetalle, asn_numeroserie, asn_aniomodelo, asn_idmarca, asn_modelo, asn_idcolorext, asn_idcolorint, asn_kilometraje, asn_clavevehicular, asn_cantidad, asn_numerofactura, asn_fechafactura, asn_preciobasecompra, asn_preciobaseventa, asn_idorigenunidad, asn_idorigenmotor, asn_fechapromentrega, asn_horapromentrega, asn_comentarios, oce_folioorden, asn_idcombustible, asn_idtransmision, asn_idtipoadquisicion, asn_idsituacionautos, asn_idubicacion, asn_idacuentade, asn_preciocompraiva, asn_precioventaiva, asn_utilidad, asn_retencion, asn_tipounidad, asn_ivacompra, asn_noplacas
FROM       CUENTASXPAGAR.dbo.cxp_detalleseminuevos
go

