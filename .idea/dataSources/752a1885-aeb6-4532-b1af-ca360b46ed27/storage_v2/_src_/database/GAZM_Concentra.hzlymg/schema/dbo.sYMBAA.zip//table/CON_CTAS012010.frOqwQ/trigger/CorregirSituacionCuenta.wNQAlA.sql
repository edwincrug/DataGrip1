CREATE TRIGGER CorregirSituacionCuenta
ON con_ctas012010
AFTER INSERT
AS
BEGIN
UPDATE con_ctas012010
SET cta_situacion = 'A'
WHERE cta_situacion is null
END
go

