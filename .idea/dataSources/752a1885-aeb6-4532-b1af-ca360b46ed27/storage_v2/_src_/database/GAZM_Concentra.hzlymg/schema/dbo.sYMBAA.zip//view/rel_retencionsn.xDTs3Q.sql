CREATE VIEW rel_retencionsn
AS
SELECT
risr_mes, risr_anio, risr_impfaccompra, risr_incpmesadq, risr_incpmesactual, risr_excedente, oce_folioorden, risr_numserie, risr_idisr
FROM        [cuentasxpagar].dbo.rel_retencionsn
go

