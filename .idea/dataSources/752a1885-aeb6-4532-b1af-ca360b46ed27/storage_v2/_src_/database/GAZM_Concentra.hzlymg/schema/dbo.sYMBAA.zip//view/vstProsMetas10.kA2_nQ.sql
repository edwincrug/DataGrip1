CREATE View [dbo].[vstProsMetas10] AS SELECT Ppc_Age, Ppc_ObjPros, Ppc_ObjVta, Ppc_Csvo FROM PYM_Prospeccion WHERE Ppc_Año = 2008 AND Ppc_Mes = 10 AND Ppc_Age = 'CBM'
go

