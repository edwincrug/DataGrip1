CREATE VIEW [dbo].[vstRsmAnlAtv] AS SELECT ci.Seg_Actividad, ag.SumVnd, isNull((Select Sum(SumVnd) From vstAnlArvXAge),0) As TotAge, ci.SumGral, isNull((Select Sum(SumGral) From vstAnlArvXCia),0) As TotGral FROM vstAnlArvXCia ci LEFT OUTER JOIN vstAnlArvXAge ag ON ci.Seg_Actividad = ag.Seg_Actividad
go

