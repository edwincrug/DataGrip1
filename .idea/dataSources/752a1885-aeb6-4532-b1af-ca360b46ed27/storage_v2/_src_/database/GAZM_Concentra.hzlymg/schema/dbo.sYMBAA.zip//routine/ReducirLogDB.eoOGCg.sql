

-- =============================================
-- Author:		Fernando Alvarado Luna
-- Create date: 2018 09 September 04
-- Description:	Reducir el LOG de la Base de Datos Pagos
-- Test:  EXEC [ReducirLogDB]
-- =============================================
CREATE PROCEDURE [dbo].[ReducirLogDB]
	-- Add the parameters for the stored procedure here
	--<@Param1, sysname, @p1> <Datatype_For_Param1, , int> = <Default_Value_For_Param1, , 0>, 
	--<@Param2, sysname, @p2> <Datatype_For_Param2, , int> = <Default_Value_For_Param2, , 0>
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Paso 01 Despliega el tamaño de los logs de las diferentes bases
	DBCC SQLPERF('LOGSPACE')


    DBCC SHRINKFILE (GAZM_Concentra_1, 1)

	-- Paso 02 Se modifica el tipo de Recovery de la base respecto al log de transaccion
	--         y su reduccion
   ALTER DATABASE GAZM_Concentra
        SET RECOVERY SIMPLE;
        
        DBCC SHRINKFILE (GAZM_Concentra_1, 1)
        
        ALTER DATABASE GAZM_Concentra
        SET RECOVERY FULL


		-- Paso 03 Despliega el tamaño de los logs de las diferentes bases despues de la reduccion
		DBCC SQLPERF('LOGSPACE')
	
	

END


--SELECT *
--	,RIGHT('00' + CAST([periodoMes] AS VARCHAR(2)), 2 )
--  FROM [ProcesoSSIS].[MesesProcesar]

go

