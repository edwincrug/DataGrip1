
CREATE VIEW [dbo].[vsCRMPEDPRE]  as    
select pED_oRIGEN, PED_STATUS,PED_NUMERO, PED_FECHA, PER_IDPERSONA , PER_NOMRAZON + ' ' + PER_PATERNO   + ' ' + PER_MATERNO 
as nombre , PER_TELEFONO1, PER_TELEFONO2 , per_telcelular ,PED_CVEUSU,  '' cita, ''feccita,'' horacit,''stacita,isnull(UNC_DESCRIPCION,'')
 UNC_DESCRIPCION , VEH_QCMODELO, PAR_DESCRIP1  
 from PAR_PEDIDO 
 inner join SER_ORDEN on ORE_IDORDEN = ped_origen   
 inner join GA_Corporativa.DBO.per_personas on PER_IDPERSONA = ORE_IDCLIENTE    
 left join SER_VEHICULO on VEH_NUMSERIE = ORE_NUMSERIE   
 left join UNI_CATALOGO on ORE_IDCATALOGO = UNC_IDCATALOGO and UNC_MODELO = VEH_ANMODELO  
 left join PNC_PARAMETR on PAR_IDENPARA=ORE_IDASESOR and PAR_TIPOPARA='AS'  where ped_origen <> ''   AND convert (varchar,PED_NUMERO)
  not in (select COF_IDCITA from CRM_CONFCITA where cof_modulo='PREPICKING')   and convert (varchar,PED_NUMERO) 
  not in (select rel_idcita from CRM_PREPICK where rel_stataccion <> 'CITA PROGRAMADA' and rel_stataccion <>'AVISO A BPRO') 
 union all  select pED_oRIGEN, PED_STATUS,PED_NUMERO, PED_FECHA, PER_IDPERSONA , PER_NOMRAZON + ' ' + PER_PATERNO   + ' ' + PER_MATERNO
 as nombre , PER_TELEFONO1, PER_TELEFONO2 , per_telcelular,PED_CVEUSU,   convert(varchar,CIT_IDCITA) cita, CIT_FECCITA feccita,
 CIT_HORCITA horacit, CIT_IDSTATUSCIT stacita,isnull(UNC_DESCRIPCION,'') , CIT_ANMODELO as VEH_QCMODELO, PAR_DESCRIP1  from PAR_PEDIDO 
 inner join SER_CITAS on CIT_IDCITA = substring(ped_origen,7,len(ped_origen))   
 inner join GA_Corporativa.DBO.per_personas on PER_IDPERSONA = CIT_IDPERSON    left join UNI_CATALOGO on cit_idcatalogo = UNC_IDCATALOGO 
 and UNC_MODELO = CIT_ANMODELO   left join PNC_PARAMETR on PAR_IDENPARA = CIT_IDASESOR and PAR_TIPOPARA ='AS'  where ped_origen like 'CIT%'  
  AND convert (varchar,PED_NUMERO) not in (select COF_IDCITA from CRM_CONFCITA where cof_modulo='PREPICKING')   
  and convert (varchar,PED_NUMERO) not in (select rel_idcita from CRM_PREPICK where rel_stataccion <> 'CITA PROGRAMADA' 
 and rel_stataccion <>'AVISO A BPRO')  union all   select pED_oRIGEN, PED_STATUS,PED_NUMERO, PED_FECHA, p1.PER_IDPERSONA , 
 p1.PER_NOMRAZON + ' ' + p1.PER_PATERNO   + ' ' + p1.PER_MATERNO as nombre , p1.PER_TELEFONO1, p1.PER_TELEFONO2 , p1.per_telcelular, PED_CVEUSU,
   '' cita, ''feccita,'' horacit,''stacita, '' UNC_DESCRIPCION , '' VEH_QCMODELO, p2.PER_NOMRAZON + ' ' + p2.PER_PATERNO   + ' ' + p2.PER_MATERNO
    as PAR_DESCRIP1  from PAR_PEDIDO inner join PAR_PEDMOST on PMM_NUMERO = substring(ped_origen,5,len(ped_origen)) and PMM_STATUS='C'   
    inner join GA_Corporativa.DBO.per_personas as p1 on p1.PER_IDPERSONA = PMM_IDCLIENTE    inner join GA_Corporativa.DBO.per_personas as p2 
    on p2.PER_IDPERSONA = ped_persona   where ped_origen like 'cot%'   AND convert (varchar,PED_NUMERO) 
    not in (select COF_IDCITA from CRM_CONFCITA where cof_modulo='PREPICKING')   and convert (varchar,PED_NUMERO) 
    not in (select rel_idcita from CRM_PREPICK where rel_stataccion <> 'CITA PROGRAMADA' and rel_stataccion <>'AVISO A BPRO')   
    union all  select pED_oRIGEN, PED_STATUS,PED_NUMERO, PED_FECHA, PER_IDPERSONA , 
    p1.PER_NOMRAZON + ' ' + p1.PER_PATERNO   + ' ' + p1.PER_MATERNO as nombre , p1.PER_TELEFONO1, p1.PER_TELEFONO2 , p1.per_telcelular 
    ,PED_CVEUSU,  '' cita, ''feccita,'' horacit,''stacita,'' UNC_DESCRIPCION , '' VEH_QCMODELO, 
    p2.USU_NOUSUARI + ' ' + p2.USU_APUSUARI + ' ' + p2.USU_AMUSUARI as PAR_DESCRIP1  from PAR_PEDIDO 
    inner join GA_Corporativa.DBO.per_personas p1 on p1.PER_IDPERSONA = ped_persona  left join pnc_usuarios p2 on p2.USU_CVEUSU = PED_CVEUSU 
     where ped_origen like 'pkg%'   AND convert (varchar,PED_NUMERO) not in (select COF_IDCITA from CRM_CONFCITA where cof_modulo='PREPICKING')
       and convert (varchar,PED_NUMERO) not in (select rel_idcita from CRM_PREPICK where rel_stataccion <> 'CITA PROGRAMADA'
        and rel_stataccion <>'AVISO A BPRO')

go

