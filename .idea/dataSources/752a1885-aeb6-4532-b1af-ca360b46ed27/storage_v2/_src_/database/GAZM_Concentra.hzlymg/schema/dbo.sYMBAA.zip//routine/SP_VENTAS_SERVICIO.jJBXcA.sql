
CREATE PROC SP_VENTAS_SERVICIO @AGENCIA VARCHAR(2), @ANIO VARCHAR(4), @MES VARCHAR(2), @FECHA_INI VARCHAR(10), @FECHA_FIN VARCHAR(10),
@PAR1 VARCHAR(2),@PAR2 VARCHAR(2),@PAR3 VARCHAR(2),@PAR4 VARCHAR(2),@PAR5 VARCHAR(2),@PAR6 VARCHAR(2),
@PAR7 VARCHAR(2),@PAR8 VARCHAR(2),@H1 VARCHAR(2),@H2 VARCHAR(2),@H3 VARCHAR(2),@H4 VARCHAR(2)
AS

--SERVICIO-----------------------------------------------------------------
---------------------------------------------------------------------------
--VENTAS SERVICIO
select LLAVE_1=LTRIM(vte_tipodocto)+'-'+LTRIM(vte_docto)+'-'+LTRIM(vte_referencia1),
a.par_descrip1, ltrim(ltrim(per_paterno) + ' ' + ltrim(per_materno) + ' ' + ltrim(per_nomrazon)) 
as nombre, vte_fechdocto, vte_docto, per_rfc, vte_total, vte_status, vte_referencia2, vte_referencia1, vte_iva, 
vte_tipodocto, veh_tipoauto, ore_fechaord, 'v' as venta, b.par_descrip3 as piva, b.par_descrip1 as tiporden, 
vte_ivaplicado, veh_qctipoauto, per_idpersona, per_calle1, per_calle2, per_calle3, per_numexter, per_numiner, per_codpos, 
per_colonia, per_delegac, per_ciudad, descestado.par_descrip1 as descripcionestado, per_telefono1, per_ext1, per_telefono2,
per_ext2, per_email,veh_qcmodelo,ore_numserie,ore_marca,isnull(per_tpocteref,'') as per_tpocteref, 
ISNULL(ORE_NOTA8,'') AS ORE_NOTA8,ore_idorden,per_personas.PER_TIPO
INTO #SERVICIO_VENTAS
from ade_vtafi INNER JOIN ser_orden ON ore_idorden = vte_referencia1 INNER JOIN 
ser_vehiculo ON ore_numserie = veh_numserie LEFT OUTER JOIN pnc_parametr as a ON vte_formapago = a.par_idenpara AND 
a.par_tipopara = 'fp' LEFT OUTER JOIN pnc_parametr as b ON substring(ore_idorden,1,1) = b.par_idenpara AND 
b.par_tipopara = 'to' INNER JOIN per_personas ON vte_idcliente = per_idpersona LEFT OUTER JOIN pnc_parametr as 
descestado ON per_estado = descestado.par_idenpara AND descestado.par_tipopara = 'eo' WHERE vte_tipodocto like 's%' 
and convert(datetime,vte_fechdocto,103) between convert(datetime,@FECHA_INI,103) and convert(datetime,@FECHA_FIN,
103)  and substring(ore_idorden, 1, 1) in (@PAR1,@PAR2,@PAR3,@PAR4,@PAR5,@PAR6,@PAR7,@PAR8) 

--AGREGA TABLA DE IMPORTE VENTAS SERVICIO
select LLAVE=(LTRIM(VTD_TIPODOCTO)+'-'+LTRIM(VTD_IDDOCTO)+'-'+LTRIM(vtd_referencia1)),
vtd_codigo,vtd_cantidad, vtd_costo, vtd_clasific, vtd_preciounitario as preciounitario, vtd_referencia1,
vtd_descue,vtd_desgen,vtd_desgpocla,
par_descrip1=ISNULL(par_descrip1,''), (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1 as Descuento, vtd_descrip,
vtd_tiempotab,TIPO_MOV=PAR_IDENPARA
INTO #VENTAS_IMPORTE_SER
from
ade_vtafidet LEFT OUTER JOIN pnc_parametr ON vtd_clasific = par_idenpara and par_tipopara = 'CL' WHERE
LTRIM(VTD_TIPODOCTO)+'-'+LTRIM(VTD_IDDOCTO)+'-'+LTRIM(vtd_referencia1)IN(
SELECT LLAVE_1 FROM #SERVICIO_VENTAS) 
and (vtd_preciounitario > 0 or vtd_costo >= 0 
and vtd_clasific not like '%d')  AND (VTD_CLASIFIC NOT LIKE 'RE%' OR VTD_CLASIFIC  LIKE 'MO%' OR VTD_CLASIFIC  
LIKE 'TT%')

--CANCELACIONES SERVICIO
select LLAVE_1=LTRIM(vec_tipodocto)+'-'+LTRIM(vec_docto)+'-'+LTRIM(vec_referencia1),
 a.par_descrip1, ltrim(ltrim(per_paterno) + ' ' + ltrim(per_materno) + ' ' + ltrim(per_nomrazon)) as nombre, vec_fechdocto, vec_docto, 
per_rfc, vec_total, vec_status, vec_referencia2, vec_referencia1, vec_iva, vec_tipodocto, veh_tipoauto, ore_fechaord, 
'c' as venta, b.par_descrip3 as piva, b.par_descrip1 as tiporden, vec_ivaplicado, veh_qctipoauto, per_idpersona, 
per_calle1, per_calle2, per_calle3, per_numexter, per_numiner, per_codpos, per_colonia, per_delegac, per_ciudad, 
descestado.par_descrip1 as descripcionestado, per_telefono1, per_ext1, per_telefono2, per_ext2, per_email,
veh_qcmodelo,ore_numserie,ore_marca,isnull(per_tpocteref,'') as per_tpocteref, ISNULL(ORE_NOTA8,'') AS ORE_NOTA8
,ore_idorden,per_personas.PER_TIPO
INTO #SERVICIO_CANCELA  
FROM ade_canfi INNER JOIN ser_orden ON ore_idorden = vec_referencia1 INNER JOIN ser_vehiculo ON ore_numserie = 
veh_numserie LEFT OUTER JOIN pnc_parametr as a ON vec_formapago = a.par_idenpara AND a.par_tipopara = 'fp' 
LEFT OUTER JOIN pnc_parametr as b ON substring(ore_idorden,1,1) = b.par_idenpara AND b.par_tipopara = 'to' INNER JOIN 
per_personas ON vec_idcliente = per_idpersona LEFT OUTER JOIN pnc_parametr as descestado ON per_estado = 
descestado.par_idenpara AND descestado.par_tipopara = 'eo' WHERE vec_tipodocto like 's%' and 
convert(datetime,vec_fechdocto,103) between convert(datetime,@FECHA_INI,103) and 
convert(datetime,@FECHA_FIN,103)  and substring(ore_idorden, 1, 1) in (@PAR1,@PAR2,@PAR3,@PAR4,@PAR5,@PAR6,@PAR7,@PAR8)

--AGREGA TABLA DE IMPORTE CACELACIONES SERVICIO
select LLAVE=(LTRIM(VTD_TIPODOCTO)+'-'+LTRIM(VTD_IDDOCTO)+'-'+LTRIM(vtd_referencia1)),
vtd_codigo,vtd_cantidad, vtd_costo, vtd_clasific, vtd_preciounitario as preciounitario, vtd_referencia1,
vtd_descue,vtd_desgen,vtd_desgpocla, 
par_descrip1=ISNULL(par_descrip1,''), (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1 as Descuento, vtd_descrip,
vtd_tiempotab,TIPO_MOV=PAR_IDENPARA
INTO #CANCELA_IMPORTE_SER
from 
ade_vtafidet LEFT OUTER JOIN pnc_parametr ON vtd_clasific = par_idenpara and par_tipopara = 'CL' WHERE
LTRIM(VTD_TIPODOCTO)+'-'+LTRIM(VTD_IDDOCTO)+'-'+LTRIM(vtd_referencia1)IN(
SELECT LTRIM(vec_tipodocto)+'-'+LTRIM(vec_docto)+'-'+LTRIM(vec_referencia1) FROM #SERVICIO_CANCELA) 
and (vtd_preciounitario > 0 or vtd_costo >= 0 
and vtd_clasific not like '%d')  AND (VTD_CLASIFIC NOT LIKE 'RE%' OR VTD_CLASIFIC  LIKE 'MO%' OR VTD_CLASIFIC  
LIKE 'TT%')

--CAMBIA EL SIGNO DE LAS CANCELACIONES
UPDATE #CANCELA_IMPORTE_SER SET preciounitario = preciounitario *-1, vtd_costo = vtd_costo * -1


-----------------------------------------------------------------------------------------------------------
--HYP------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------
--VENTAS HYP
select LLAVE_1=LTRIM(vte_tipodocto)+'-'+LTRIM(vte_docto)+'-'+LTRIM(vte_referencia1),
a.par_descrip1, ltrim(ltrim(per_paterno) + ' ' + ltrim(per_materno) + ' ' + ltrim(per_nomrazon)) 
as nombre, vte_fechdocto, vte_docto, per_rfc, vte_total, vte_status, vte_referencia2, vte_referencia1, vte_iva, 
vte_tipodocto, veh_tipoauto, ore_fechaord, 'v' as venta, b.par_descrip3 as piva, b.par_descrip1 as tiporden, 
vte_ivaplicado, veh_qctipoauto, per_idpersona, per_calle1, per_calle2, per_calle3, per_numexter, per_numiner, per_codpos, 
per_colonia, per_delegac, per_ciudad, descestado.par_descrip1 as descripcionestado, per_telefono1, per_ext1, per_telefono2,
per_ext2, per_email,veh_qcmodelo,ore_numserie,ore_marca,isnull(per_tpocteref,'') as per_tpocteref, 
ISNULL(ORE_NOTA8,'') AS ORE_NOTA8,ore_idorden,per_personas.PER_TIPO
INTO #HYP_VENTAS
from ade_vtafi INNER JOIN ser_orden ON ore_idorden = vte_referencia1 INNER JOIN 
ser_vehiculo ON ore_numserie = veh_numserie LEFT OUTER JOIN pnc_parametr as a ON vte_formapago = a.par_idenpara AND 
a.par_tipopara = 'fp' LEFT OUTER JOIN pnc_parametr as b ON substring(ore_idorden,1,1) = b.par_idenpara AND 
b.par_tipopara = 'to' INNER JOIN per_personas ON vte_idcliente = per_idpersona LEFT OUTER JOIN pnc_parametr as 
descestado ON per_estado = descestado.par_idenpara AND descestado.par_tipopara = 'eo' WHERE vte_tipodocto like 's%' 
and convert(datetime,vte_fechdocto,103) between convert(datetime,@FECHA_INI,103) and convert(datetime,@FECHA_FIN,
103)  and substring(ore_idorden, 1, 1) in (@H1,@H2,@H3,@H4) 

--AGREGA TABLA DE IMPORTE VENTAS HYP
select LLAVE=(LTRIM(VTD_TIPODOCTO)+'-'+LTRIM(VTD_IDDOCTO)+'-'+LTRIM(vtd_referencia1)),
vtd_codigo,vtd_cantidad, vtd_costo, vtd_clasific, vtd_preciounitario as preciounitario, vtd_referencia1,
vtd_descue,vtd_desgen,vtd_desgpocla,
par_descrip1=ISNULL(par_descrip1,''), (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1 as Descuento, vtd_descrip,
vtd_tiempotab,TIPO_MOV=PAR_IDENPARA
INTO #VENTAS_IMPORTE_HYP
from
ade_vtafidet LEFT OUTER JOIN pnc_parametr ON vtd_clasific = par_idenpara and par_tipopara = 'CL' WHERE
LTRIM(VTD_TIPODOCTO)+'-'+LTRIM(VTD_IDDOCTO)+'-'+LTRIM(vtd_referencia1)IN(
SELECT LLAVE_1 FROM #HYP_VENTAS) 
and (vtd_preciounitario > 0 or vtd_costo >= 0 
and vtd_clasific not like '%d')  AND (VTD_CLASIFIC NOT LIKE 'RE%' OR VTD_CLASIFIC  LIKE 'MO%' OR VTD_CLASIFIC  
LIKE 'TT%')


--CANCELACIONES HYP
select LLAVE_1=LTRIM(vec_tipodocto)+'-'+LTRIM(vec_docto)+'-'+LTRIM(vec_referencia1),
 a.par_descrip1, ltrim(ltrim(per_paterno) + ' ' + ltrim(per_materno) + ' ' + ltrim(per_nomrazon)) as nombre, vec_fechdocto, vec_docto, 
per_rfc, vec_total, vec_status, vec_referencia2, vec_referencia1, vec_iva, vec_tipodocto, veh_tipoauto, ore_fechaord, 
'c' as venta, b.par_descrip3 as piva, b.par_descrip1 as tiporden, vec_ivaplicado, veh_qctipoauto, per_idpersona, 
per_calle1, per_calle2, per_calle3, per_numexter, per_numiner, per_codpos, per_colonia, per_delegac, per_ciudad, 
descestado.par_descrip1 as descripcionestado, per_telefono1, per_ext1, per_telefono2, per_ext2, per_email,
veh_qcmodelo,ore_numserie,ore_marca,isnull(per_tpocteref,'') as per_tpocteref, ISNULL(ORE_NOTA8,'') AS ORE_NOTA8
,ore_idorden,per_personas.PER_TIPO
INTO #HYP_CANCELA  
FROM ade_canfi INNER JOIN ser_orden ON ore_idorden = vec_referencia1 INNER JOIN ser_vehiculo ON ore_numserie = 
veh_numserie LEFT OUTER JOIN pnc_parametr as a ON vec_formapago = a.par_idenpara AND a.par_tipopara = 'fp' 
LEFT OUTER JOIN pnc_parametr as b ON substring(ore_idorden,1,1) = b.par_idenpara AND b.par_tipopara = 'to' INNER JOIN 
per_personas ON vec_idcliente = per_idpersona LEFT OUTER JOIN pnc_parametr as descestado ON per_estado = 
descestado.par_idenpara AND descestado.par_tipopara = 'eo' WHERE vec_tipodocto like 's%' and 
convert(datetime,vec_fechdocto,103) between convert(datetime,@FECHA_INI,103) and 
convert(datetime,@FECHA_FIN,103)  and substring(ore_idorden, 1, 1) in (@H1,@H2,@H3,@H4)



--AGREGA TABLA DE IMPORTE CACELACIONES SERVICIO
select LLAVE=(LTRIM(VTD_TIPODOCTO)+'-'+LTRIM(VTD_IDDOCTO)+'-'+LTRIM(vtd_referencia1)),
vtd_codigo,vtd_cantidad, vtd_costo, vtd_clasific, vtd_preciounitario as preciounitario, vtd_referencia1,
vtd_descue,vtd_desgen,vtd_desgpocla, 
par_descrip1=ISNULL(par_descrip1,''), (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1 as Descuento, vtd_descrip,
vtd_tiempotab,TIPO_MOV=PAR_IDENPARA
INTO #CANCELA_IMPORTE_HYP
from 
ade_vtafidet LEFT OUTER JOIN pnc_parametr ON vtd_clasific = par_idenpara and par_tipopara = 'CL' WHERE
LTRIM(VTD_TIPODOCTO)+'-'+LTRIM(VTD_IDDOCTO)+'-'+LTRIM(vtd_referencia1)IN(
SELECT LTRIM(vec_tipodocto)+'-'+LTRIM(vec_docto)+'-'+LTRIM(vec_referencia1) FROM #HYP_CANCELA) 
and (vtd_preciounitario > 0 or vtd_costo >= 0 
and vtd_clasific not like '%d')  AND (VTD_CLASIFIC NOT LIKE 'RE%' OR VTD_CLASIFIC  LIKE 'MO%' OR VTD_CLASIFIC  
LIKE 'TT%')

--CAMBIA EL SIGNO DE LAS CANCELACIONES
UPDATE #CANCELA_IMPORTE_HYP SET preciounitario = preciounitario *-1 , vtd_costo = vtd_costo * -1




----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--INSERTA  SERVICIO Y HOJALATRERIA EN TABLA DEFINTIVA

--INSERTA VENTAS SERVICIO
INSERT INTO BI_VENTAS_SERVICIO
SELECT agencia = @AGENCIA,anio=@ANIO,mes=@MES,cubo=2,linea_tiempo='ACTUAL',escenario='REAL',tipo_venta='SERVICIO',
tipo_cargo=tiporden,tipo_taller=substring(ore_idorden, 1, 1),tipo_servicio=I.par_descrip1,detalle_servicio=vtd_descrip,
tipo_cliente=CASE WHEN PER_TIPO= 'FIS' THEN 'PERSONA FISICA' WHEN PER_TIPO= 'MOR' THEN 'PERSONA MORAL' ELSE 
'PERSONA FISICA CON ACTIVIDAD EMPRESARIAL' END,rfc_cliente=per_rfc,nombre_cliente = nombre,rfc_asesor='',nombre_asesor='',
anio_unidad=ISNULL(veh_qcmodelo,''),marca_unidad=ore_marca,modelo_unidad = ISNULL(veh_qctipoauto,''),
utilidad_bruta=((preciounitario + (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) +
((preciounitario + (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) * 
(convert(numeric,vte_ivaplicado) / 100)) - vtd_costo - ((isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) - (preciounitario + 
(isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) * (convert(numeric,vte_ivaplicado) / 100)),
ventas=preciounitario,CANTIDAD=case when substring(vtd_clasific,1,2) = 'mo' then vtd_tiempotab else '1' end,
precio_venta= preciounitario / (case when substring(vtd_clasific,1,2) = 'mo' then (CASE WHEN vtd_tiempotab = 0 THEN 1 ELSE vtd_tiempotab END) else '1' end),
precio_compra=0,costo_venta=vtd_costo,dias_estancia=10,cantidad_ordenes=0,calificacion_precio=0,calificacion_tiempo=0,
calificacion_amabilidad=0,calificacion_atencion=0,reparado_bien_primera_vez=0,ore_idorden,ore_fechaord,
vte_docto,vte_fechdocto
FROM #VENTAS_IMPORTE_SER I , #SERVICIO_VENTAS V WHERE LLAVE = LLAVE_1


--INSERTA CANCELACIONES SERVICIO
INSERT INTO BI_VENTAS_SERVICIO
SELECT agencia = @AGENCIA,anio=@ANIO,mes=@MES,cubo=2,linea_tiempo='ACTUAL',escenario='REAL',tipo_venta='SERVICIO',
tipo_cargo=tiporden,tipo_taller=substring(ore_idorden, 1, 1),tipo_servicio=I.par_descrip1,detalle_servicio=vtd_descrip,
tipo_cliente=CASE WHEN PER_TIPO= 'FIS' THEN 'PERSONA FISICA' WHEN PER_TIPO= 'MOR' THEN 'PERSONA MORAL' ELSE 
'PERSONA FISICA CON ACTIVIDAD EMPRESARIAL' END,rfc_cliente=per_rfc,nombre_cliente = nombre,rfc_asesor='',nombre_asesor='',
anio_unidad=ISNULL(veh_qcmodelo,''),marca_unidad=ore_marca,modelo_unidad = ISNULL(veh_qctipoauto,''),
utilidad_bruta=((preciounitario + (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) +
((preciounitario + (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) * 
(convert(numeric,vec_ivaplicado) / 100)) - vtd_costo - ((isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) - (preciounitario + 
(isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) * (convert(numeric,vec_ivaplicado) / 100)),
ventas=preciounitario,CANTIDAD=case when substring(vtd_clasific,1,2) = 'mo' then vtd_tiempotab else '1' end,
precio_venta= preciounitario / (case when substring(vtd_clasific,1,2) = 'mo' then (CASE WHEN vtd_tiempotab = 0 THEN 1 ELSE vtd_tiempotab END) else '1' end),
precio_compra=0,costo_venta=vtd_costo,dias_estancia=10,cantidad_ordenes=0,calificacion_precio=0,calificacion_tiempo=0,
calificacion_amabilidad=0,calificacion_atencion=0,reparado_bien_primera_vez=0,ore_idorden,ore_fechaord,
vec_docto,vec_fechdocto
FROM #CANCELA_IMPORTE_SER I , #SERVICIO_CANCELA V WHERE LLAVE = LLAVE_1 


----------------------------------------------------------------------------------
----------------------------------------------------------------------------------

--INSERTA VENTAS HYP
INSERT INTO BI_VENTAS_SERVICIO
SELECT agencia = @AGENCIA,anio=@ANIO,mes=@MES,cubo=2,linea_tiempo='ACTUAL',escenario='REAL',tipo_venta='HOJALATERIA Y PINTURA',
tipo_cargo=tiporden,tipo_taller=substring(ore_idorden, 1, 1),tipo_servicio=I.par_descrip1,detalle_servicio=vtd_descrip,
tipo_cliente=CASE WHEN PER_TIPO= 'FIS' THEN 'PERSONA FISICA' WHEN PER_TIPO= 'MOR' THEN 'PERSONA MORAL' ELSE 
'PERSONA FISICA CON ACTIVIDAD EMPRESARIAL' END,rfc_cliente=per_rfc,nombre_cliente = nombre,rfc_asesor='',nombre_asesor='',
anio_unidad=ISNULL(veh_qcmodelo,''),marca_unidad=ore_marca,modelo_unidad = ISNULL(veh_qctipoauto,''),
utilidad_bruta=((preciounitario + (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) +
((preciounitario + (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) * 
(convert(numeric,vte_ivaplicado) / 100)) - vtd_costo - ((isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) - (preciounitario + 
(isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) * (convert(numeric,vte_ivaplicado) / 100)),
ventas=preciounitario,CANTIDAD=case when substring(vtd_clasific,1,2) = 'mo' then vtd_tiempotab else '1' end,
precio_venta= preciounitario / (case when substring(vtd_clasific,1,2) = 'mo' then (CASE WHEN vtd_tiempotab = 0 THEN 1 ELSE vtd_tiempotab END) else '1' end),
precio_compra=0,costo_venta=vtd_costo,dias_estancia=10,cantidad_ordenes=0,calificacion_precio=0,calificacion_tiempo=0,
calificacion_amabilidad=0,calificacion_atencion=0,reparado_bien_primera_vez=0,ore_idorden,ore_fechaord,
vte_docto,vte_fechdocto
FROM #VENTAS_IMPORTE_HYP I , #HYP_VENTAS V WHERE LLAVE = LLAVE_1


--INSERTA CANCELACIONES HYP
INSERT INTO BI_VENTAS_SERVICIO
SELECT agencia = @AGENCIA,anio=@ANIO,mes=@MES,cubo=2,linea_tiempo='ACTUAL',escenario='REAL',tipo_venta='HOJALATERIA Y PINTURA',
tipo_cargo=tiporden,tipo_taller=substring(ore_idorden, 1, 1),tipo_servicio=I.par_descrip1,detalle_servicio=vtd_descrip,
tipo_cliente=CASE WHEN PER_TIPO= 'FIS' THEN 'PERSONA FISICA' WHEN PER_TIPO= 'MOR' THEN 'PERSONA MORAL' ELSE 
'PERSONA FISICA CON ACTIVIDAD EMPRESARIAL' END,rfc_cliente=per_rfc,nombre_cliente = nombre,rfc_asesor='',nombre_asesor='',
anio_unidad=ISNULL(veh_qcmodelo,''),marca_unidad=ore_marca,modelo_unidad = ISNULL(veh_qctipoauto,''),
utilidad_bruta=((preciounitario + (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) +
((preciounitario + (isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) * 
(convert(numeric,vec_ivaplicado) / 100)) - vtd_costo - ((isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) - (preciounitario + 
(isnull(vtd_descue,0) + isnull(vtd_desgen,0) + isnull(vtd_desgpocla,0)) * -1) * (convert(numeric,vec_ivaplicado) / 100)),
ventas=preciounitario,CANTIDAD=case when substring(vtd_clasific,1,2) = 'mo' then vtd_tiempotab else '1' end,
precio_venta= preciounitario / (case when substring(vtd_clasific,1,2) = 'mo' then (CASE WHEN vtd_tiempotab = 0 THEN 1 ELSE vtd_tiempotab END) else '1' end),
precio_compra=0,costo_venta=vtd_costo,dias_estancia=10,cantidad_ordenes=0,calificacion_precio=0,calificacion_tiempo=0,
calificacion_amabilidad=0,calificacion_atencion=0,reparado_bien_primera_vez=0,ore_idorden,ore_fechaord,
vec_docto,vec_fechdocto
FROM #CANCELA_IMPORTE_HYP I , #HYP_CANCELA V WHERE LLAVE = LLAVE_1


go

