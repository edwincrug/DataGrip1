CREATE VIEW [dbo].[vstAnlRhzXCia] AS SELECT Prs_CveAGE, COUNT(Prs_Estatus) AS SumGral FROM dbo.PYM_ProspecHis GROUP BY Prs_CveAGE, SUBSTRING(Prs_FecOpe, 4, 2), RIGHT(Prs_FecOpe, 4), Prs_Estatus HAVING RIGHT(Prs_FecOpe, 4) =  2007 AND SUBSTRING(Prs_FecOpe, 4, 2) = 10 AND Prs_Estatus = 3
go

