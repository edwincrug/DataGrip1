CREATE PROC SP_VENTAS_UNIDADES @AGENCIA VARCHAR(2), @FECHA_INI VARCHAR(10), @FECHA_FIN VARCHAR(10),
@COSTO_A1 VARCHAR(10),@COSTO_A2 VARCHAR(10),@COSTO_A3 VARCHAR(10),@COSTO_A4 VARCHAR(10),@COSTO_A5 VARCHAR(10),
@COSTO_A6 VARCHAR(10),@COSTO_A7 VARCHAR(10),@COSTO_A8 VARCHAR(10),@COSTO_A9 VARCHAR(10),@COSTO_A10 VARCHAR(10),
@COSTO_B1 VARCHAR(10),@COSTO_B2 VARCHAR(10),@COSTO_B3 VARCHAR(10),@COSTO_B4 VARCHAR(10),@COSTO_B5 VARCHAR(10),
@COSTO_B6 VARCHAR(10),@COSTO_B7 VARCHAR(10),@COSTO_B8 VARCHAR(10),@COSTO_B9 VARCHAR(10),@COSTO_B10 VARCHAR(10),
@COSTO_C1 VARCHAR(10),@COSTO_C2 VARCHAR(10),@COSTO_C3 VARCHAR(10),@COSTO_C4 VARCHAR(10),@COSTO_C5 VARCHAR(10),
@COSTO_C6 VARCHAR(10),@COSTO_C7 VARCHAR(10),@COSTO_C8 VARCHAR(10),@COSTO_C9 VARCHAR(10),@COSTO_C10 VARCHAR(10),
@COSTO_D1 VARCHAR(10),@COSTO_D2 VARCHAR(10),@COSTO_D3 VARCHAR(10),@COSTO_D4 VARCHAR(10),@COSTO_D5 VARCHAR(10),
@COSTO_D6 VARCHAR(10),@COSTO_D7 VARCHAR(10),@COSTO_D8 VARCHAR(10),@COSTO_D9 VARCHAR(10),@COSTO_D10 VARCHAR(10)
AS

DELETE FROM BI_VENTAS_UNIDADES
DELETE FROM BI_VENTAS_UNIDADES_PREVIO

--VENTAS

Select TipoUnidad = 'NUEVOS',IdCte = ade_vtafi.VTE_IDCLIENTE,RfcCte = PER_PERSONAS.PER_RFC,NombreCte =
rtrim(ltrim(rtrim(ltrim(PER_PERSONAS.per_nomrazon)) + ' ' + rtrim(ltrim(PER_PERSONAS.PER_PATERNO)) + ' ' + 
rtrim(ltrim(PER_PERSONAS.per_materno)))),TipoCte = PER_PERSONAS.PER_TIPO,CTE_DELEGACION = 
PER_PERSONAS.PER_DELEGAC,CTE_CIUDAD = PER_PERSONAS.PER_CIUDAD,
CTE_COLONIA = PER_COLONIA,PER_CALLE1,PER_CALLE2,PER_CALLE3,PER_NUMEXTER,PER_CODPOS,per_email,per_telefono1,
ESTADO_DESC=descestado.par_descrip1,veh_numserie as NumSerie,veh_noinventa as Inventario,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_colointe = col_clave and col_tipo = 'interior') as ColorInterior,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_coloexte = col_clave and col_tipo = 'exterior') as ColorExterior,
veh_anmodelo as Modelo,veh_tipoauto as DescModelo,
(select par_descrip1 from pnc_parametr where par_tipopara = 'MCAV' and par_idenpara = unc_marca) as Marca,
(select par_descrip1 from pnc_parametr where par_tipopara = 'LNA' and par_idenpara = unc_linea) as Segmento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA='CVE' AND PAR_IDENPARA = uni_catalogo.UNC_CLASE) as subtipo_unidad,
UNC_IDCATALOGO,
CarLine = (select PAR_DESCRIP1 from PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'CLI' AND PAR_IDENPARA = uni_catalogo.UNC_FAMILIA),
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'PTA' AND PAR_IDENPARA = unc_ptas) as Puertas,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'CIL' AND PAR_IDENPARA = unc_cilindros) as cilindros,UNC_POTENCIA,
(select par_descrip1 from pnc_parametr where par_tipopara = 'CMB'and par_idenpara = unc_combustible) as Combustible,
unc_capacidad as Capacidad,
(select par_descrip1 from pnc_parametr where par_tipopara = 'TRS' and par_idenpara = unc_transmision) as Transmision,
unc_tipomotor as Tipomotor,veh_orgunidad as Procedencia,
(select par_descrip1 from pnc_parametr where par_tipopara = 'vnt' and par_idenpara = pen_venta) as DescripcionVenta,
vte_docto as Factura,vte_fechdocto as FechaFactura,VEH_NOFACTPLAN,VEH_FECREMISION,veh_nopedimtoext as NumPedimento,
veh_fecpedimtoext as FechaPedimento,vte_referencia1 as Pedido,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'TIPOCOMPRA' AND PAR_IDENPARA = veh_tipocompra) AS TipoCompra,
VEH_FECRETIRO as fecha_asignacion,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
(SELECT PER_RFC FROM PER_PERSONAS WHERE PER_IDPERSONA = VEH_VENDEDOR) AS Rfc_Asesor,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'EV' AND PAR_IDENPARA = VEH_VENDEDOR) AS Asesor,
UNC_PRECLISTA AS PrecioLista,vte_descuento as Descuento,PEN_SUBTOTAL1 as importe,PEN_ISAN as ISAN,
PEN_SUBTOTAL2 AS venta,PEN_IVA as Iva,PEN_TOTAL as Total,
Costo=(SELECT SUM(VHD_COSTO) FROM uni_ltvehdeta WHERE VHD_NOSERIE = veh_numserie AND vhd_docto = vte_docto AND vhd_tipodocto =  vte_tipodocto),
PEN_COSTO1=0,PEN_COSTO2=0,PEN_COSTO3=0,PEN_COSTO4=0,PARTICIPACION=0,
Bonificacion=pen_bonificacion,Costo_Total=0,Utilidad_bruta=0,PorUtil=0,Unidades=1,LIB_FACTOR=0
INTO #VENTA_NUEVOS
from ade_vtafi, ser_vehiculo, vis_concar01,uni_catalogo,uni_ltpedido, GA_CORPORATIVA.DBO.per_personas AS PER_PERSONAS,uni_ltpediuni,pnc_parametr AS descestado
where veh_numserie = vte_serie and vte_tipodocto = 'a' and vte_status in ('i','c') and ccp_iddocto = vte_docto 
and ccp_tipodocto = 'fac' AND ade_vtafi.VTE_IDCLIENTE = PER_PERSONAS.PER_IDPERSONA
and substring(ccp_tipopol,1,2) = 'vu' 
and vte_referencia1 = upe_idpedi and per_idpersona = vte_idcliente and convert(datetime,vte_fechdocto, 103)between 
convert(datetime,@FECHA_INI,103) and convert(datetime,@FECHA_FIN,103) and upe_idpedi = pen_idpedi and 
upe_tipodocto = vte_tipodocto and upe_docto = vte_docto and upe_tipodocto = pen_tipodocto and upe_docto = pen_docto 
and unc_idcatalogo = veh_catalogo and unc_modelo = veh_anmodelo AND per_estado = descestado.par_idenpara 
AND descestado.par_tipopara = 'eo'

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

--CANCELACIONES
Select TipoUnidad = 'NUEVOS',IdCte = ade_vtafi.VTE_IDCLIENTE,RfcCte = PER_PERSONAS.PER_RFC,NombreCte =
rtrim(ltrim(rtrim(ltrim(PER_PERSONAS.per_nomrazon)) + ' ' + rtrim(ltrim(PER_PERSONAS.PER_PATERNO)) + ' ' + 
rtrim(ltrim(PER_PERSONAS.per_materno)))),TipoCte = PER_PERSONAS.PER_TIPO,CTE_DELEGACION = 
PER_PERSONAS.PER_DELEGAC,CTE_CIUDAD = PER_PERSONAS.PER_CIUDAD,CTE_COLONIA = PER_COLONIA,PER_CALLE1,PER_CALLE2,
PER_CALLE3,PER_NUMEXTER,PER_CODPOS,per_email,per_telefono1,ESTADO_DESC=descestado.par_descrip1,
veh_numserie as NumSerie,veh_noinventa as Inventario,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_colointe = col_clave and col_tipo = 'interior') as ColorInterior,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_coloexte = col_clave and col_tipo = 'exterior') as ColorExterior,
veh_anmodelo as Modelo,veh_tipoauto as DescModelo,
(select par_descrip1 from pnc_parametr where par_tipopara = 'MCAV' and par_idenpara = unc_marca) as Marca,
(select par_descrip1 from pnc_parametr where par_tipopara = 'LNA' and par_idenpara = unc_linea) as Segmento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA='CVE' AND PAR_IDENPARA = uni_catalogo.UNC_CLASE) as subtipo_unidad,
UNC_IDCATALOGO,
CarLine = (select PAR_DESCRIP1 from PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'CLI' AND PAR_IDENPARA = uni_catalogo.UNC_FAMILIA),
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'PTA' AND PAR_IDENPARA = unc_ptas) as Puertas,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'CIL' AND PAR_IDENPARA = unc_cilindros) as cilindros,UNC_POTENCIA,
(select par_descrip1 from pnc_parametr where par_tipopara = 'CMB'and par_idenpara = unc_combustible) as Combustible,
unc_capacidad as Capacidad,
(select par_descrip1 from pnc_parametr where par_tipopara = 'TRS' and par_idenpara = unc_transmision) as Transmision,
unc_tipomotor as Tipomotor,veh_orgunidad as Procedencia,
(select par_descrip1 from pnc_parametr where par_tipopara = 'vnt' and par_idenpara = pen_venta) as DescripcionVenta,
'9' + vte_docto as Factura,vte_fechdocto as FechaFactura,VEH_NOFACTPLAN,VEH_FECREMISION,veh_nopedimtoext as NumPedimento,
veh_fecpedimtoext as FechaPedimento,vte_referencia1 as Pedido,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'TIPOCOMPRA' AND PAR_IDENPARA = veh_tipocompra) AS TipoCompra,
VEH_FECRETIRO as fecha_asignacion,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
(SELECT PER_RFC FROM PER_PERSONAS WHERE PER_IDPERSONA = VEH_VENDEDOR) AS Rfc_Asesor,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'EV' AND PAR_IDENPARA = VEH_VENDEDOR) AS Asesor,
UNC_PRECLISTA AS PrecioLista,vte_descuento as Descuento,PEN_SUBTOTAL1 as importe,PEN_ISAN as ISAN,
PEN_SUBTOTAL2 AS venta,PEN_IVA as Iva,PEN_TOTAL as Total,
Costo=(SELECT SUM(VHD_COSTO) FROM uni_ltvehdeta WHERE VHD_NOSERIE = veh_numserie AND vhd_docto = vte_docto AND vhd_tipodocto =  vte_tipodocto),
PEN_COSTO1=0,PEN_COSTO2=0,PEN_COSTO3=0,PEN_COSTO4=0,PARTICIPACION=0,
Bonificacion=pen_bonificacion,Costo_Total=0,Utilidad_bruta=0,PorUtil=0,Unidades=-1,LIB_FACTOR=1
INTO #CANCELA_NUEVOS
from ade_vtafi, ser_vehiculo, vis_concar01,uni_catalogo,uni_ltpedido, GA_CORPORATIVA.DBO.per_personas AS PER_PERSONAS,uni_ltpediuni,pnc_parametr AS descestado
where veh_numserie = vte_serie and vte_tipodocto = 'a' and vte_status = 'c' and ccp_iddocto = vte_docto 
and ccp_tipodocto = 'fac' AND ade_vtafi.VTE_IDCLIENTE = PER_PERSONAS.PER_IDPERSONA
and substring(ccp_tipopol,1,2) = 'vu' and vte_referencia1 = upe_idpedi and per_idpersona = vte_idcliente and 
convert(datetime,vte_fechope, 103)between convert(datetime,@FECHA_INI,103) and convert(datetime,@FECHA_FIN,103) 
and upe_idpedi = pen_idpedi and upe_idpedi = pen_idpedi and upe_tipodocto = vte_tipodocto and upe_docto = 
vte_docto and upe_tipodocto = pen_tipodocto and upe_docto = pen_docto and unc_idcatalogo = veh_catalogo and 
unc_modelo = veh_anmodelo AND per_estado = descestado.par_idenpara 
AND descestado.par_tipopara = 'eo'

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------


INSERT INTO BI_VENTAS_UNIDADES_PREVIO
SELECT TipoUnidad,IdCte,RfcCte,NombreCte,TipoCte,CTE_DELEGACION,CTE_CIUDAD,CTE_COLONIA,PER_CALLE1,PER_CALLE2,PER_CALLE3,
PER_NUMEXTER,PER_CODPOS,per_email,per_telefono1,ESTADO_DESC,NumSerie,Inventario,ColorInterior,ColorExterior,
Modelo,DescModelo,Marca,Segmento,subtipo_unidad,UNC_IDCATALOGO,CarLine,Puertas,cilindros,UNC_POTENCIA,Combustible,
Capacidad,Transmision,Tipomotor,Procedencia,DescripcionVenta,Factura,FechaFactura,VEH_NOFACTPLAN,VEH_FECREMISION,
NumPedimento,FechaPedimento,Pedido,TipoCompra,fecha_asignacion,financiera,Rfc_Asesor,Asesor,PrecioLista,Descuento,
importe,ISAN,venta,Iva,Total,Costo,PEN_COSTO1,PEN_COSTO2,PEN_COSTO3,PEN_COSTO4,PARTICIPACION,
Bonificacion,Costo_Total,Utilidad_bruta,PorUtil,Unidades,LIB_FACTOR FROM #VENTA_NUEVOS

INSERT INTO BI_VENTAS_UNIDADES_PREVIO
SELECT TipoUnidad,IdCte,RfcCte,NombreCte,TipoCte,CTE_DELEGACION,CTE_CIUDAD,CTE_COLONIA,PER_CALLE1,PER_CALLE2,PER_CALLE3,
PER_NUMEXTER,PER_CODPOS,per_email,per_telefono1,ESTADO_DESC,NumSerie,Inventario,ColorInterior,ColorExterior,
Modelo,DescModelo,Marca,Segmento,subtipo_unidad,UNC_IDCATALOGO,CarLine,Puertas,cilindros,UNC_POTENCIA,Combustible,
Capacidad,Transmision,Tipomotor,Procedencia,DescripcionVenta,Factura,FechaFactura,VEH_NOFACTPLAN,VEH_FECREMISION,
NumPedimento,FechaPedimento,Pedido,TipoCompra,fecha_asignacion,financiera,Rfc_Asesor,Asesor,PrecioLista,Descuento,
importe,ISAN,venta,Iva,Total,Costo,PEN_COSTO1,PEN_COSTO2,PEN_COSTO3,PEN_COSTO4,PARTICIPACION,
Bonificacion,Costo_Total,Utilidad_bruta,PorUtil,Unidades,LIB_FACTOR FROM #CANCELA_NUEVOS

UPDATE BI_VENTAS_UNIDADES_PREVIO set COSTO = COSTO*-1 WHERE LIB_FACTOR = 1

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

update BI_VENTAS_UNIDADES_PREVIO set PEN_COSTO1 = interno.costo_interno from (select sum(vhd_costo) as costo_interno, 
vhd_noserie as noserie_interno, factura as docto_interno, LIB_FACTOR as factor_interno from uni_ltvehdeta, 
BI_VENTAS_UNIDADES_PREVIO where Factura = vhd_docto and vhd_noserie = num_serie and vhd_tipo in 
(@COSTO_A1,@COSTO_A2,@COSTO_A3,@COSTO_A4,@COSTO_A5,@COSTO_A6,@COSTO_A7,@COSTO_A8,@COSTO_A9,@COSTO_A10) 
group by vhd_noserie, Factura, LIB_FACTOR)interno where Factura = interno.docto_interno and 
num_serie = interno.noserie_interno and LIB_FACTOR = interno.factor_interno 

update BI_VENTAS_UNIDADES_PREVIO set PEN_COSTO1 = interno.costo_interno from (select sum(vhd_costo) as costo_interno, 
vhd_noserie as noserie_interno, factura as docto_interno, LIB_FACTOR as factor_interno from uni_ltvehdeta, 
BI_VENTAS_UNIDADES_PREVIO where substring(Factura,2,len(factura)) = vhd_docto and vhd_noserie = num_serie and 
vhd_tipo in (@COSTO_A1,@COSTO_A2,@COSTO_A3,@COSTO_A4,@COSTO_A5,@COSTO_A6,@COSTO_A7,@COSTO_A8,@COSTO_A9,@COSTO_A10) 
group by vhd_noserie, Factura, LIB_FACTOR) interno where Factura = interno.docto_interno and 
num_serie = interno.noserie_interno and LIB_FACTOR = interno.factor_interno 

---------------------------------------------------------------------------------------

update BI_VENTAS_UNIDADES_PREVIO set PEN_COSTO2 = interno.costo_interno from (select sum(vhd_costo) as costo_interno, 
vhd_noserie as noserie_interno, factura as docto_interno, LIB_FACTOR as factor_interno from uni_ltvehdeta, 
BI_VENTAS_UNIDADES_PREVIO where Factura = vhd_docto and vhd_noserie = num_serie and vhd_tipo in 
(@COSTO_B1,@COSTO_B2,@COSTO_B3,@COSTO_B4,@COSTO_B5,@COSTO_B6,@COSTO_B7,@COSTO_B8,@COSTO_B9,@COSTO_B10) 
group by vhd_noserie, Factura, LIB_FACTOR) interno where Factura = interno.docto_interno and 
num_serie = interno.noserie_interno and LIB_FACTOR = interno.factor_interno 

update BI_VENTAS_UNIDADES_PREVIO set PEN_COSTO2 = interno.costo_interno from (select sum(vhd_costo) as costo_interno, 
vhd_noserie as noserie_interno, factura as docto_interno, LIB_FACTOR as factor_interno from uni_ltvehdeta, 
BI_VENTAS_UNIDADES_PREVIO where substring(Factura,2,len(factura)) = vhd_docto and vhd_noserie = num_serie and 
vhd_tipo in (@COSTO_B1,@COSTO_B2,@COSTO_B3,@COSTO_B4,@COSTO_B5,@COSTO_B6,@COSTO_B7,@COSTO_B8,@COSTO_B9,@COSTO_B10) 
group by vhd_noserie, Factura, LIB_FACTOR) interno where Factura = interno.docto_interno and 
num_serie = interno.noserie_interno and LIB_FACTOR = interno.factor_interno 

---------------------------------------------------------------------------------------

update BI_VENTAS_UNIDADES_PREVIO set PEN_COSTO3 = interno.costo_interno from (select sum(vhd_costo) as costo_interno, 
vhd_noserie as noserie_interno, factura as docto_interno, LIB_FACTOR as factor_interno from uni_ltvehdeta, 
BI_VENTAS_UNIDADES_PREVIO where Factura = vhd_docto and vhd_noserie = num_serie and vhd_tipo in 
(@COSTO_C1,@COSTO_C2,@COSTO_C3,@COSTO_C4,@COSTO_C5,@COSTO_C6,@COSTO_C7,@COSTO_C8,@COSTO_C9,@COSTO_C10) 
group by vhd_noserie, Factura, LIB_FACTOR) interno where Factura = interno.docto_interno and 
num_serie = interno.noserie_interno and LIB_FACTOR = interno.factor_interno 

update BI_VENTAS_UNIDADES_PREVIO set PEN_COSTO3 = interno.costo_interno from (select sum(vhd_costo) as costo_interno, 
vhd_noserie as noserie_interno, factura as docto_interno, LIB_FACTOR as factor_interno from uni_ltvehdeta, 
BI_VENTAS_UNIDADES_PREVIO where substring(Factura,2,len(factura)) = vhd_docto and vhd_noserie = num_serie and 
vhd_tipo in (@COSTO_C1,@COSTO_C2,@COSTO_C3,@COSTO_C4,@COSTO_C5,@COSTO_C6,@COSTO_C7,@COSTO_C8,@COSTO_C9,@COSTO_C10) 
group by vhd_noserie, Factura, LIB_FACTOR) interno where Factura = interno.docto_interno and 
num_serie = interno.noserie_interno and LIB_FACTOR = interno.factor_interno 

---------------------------------------------------------------------------------------

update BI_VENTAS_UNIDADES_PREVIO set PARTICIPACION = interno.costo_interno from (select sum(vhd_costo) as costo_interno, 
vhd_noserie as noserie_interno, factura as docto_interno, LIB_FACTOR as factor_interno from uni_ltvehdeta, 
BI_VENTAS_UNIDADES_PREVIO where Factura = vhd_docto and vhd_noserie = num_serie and vhd_tipo in 
(@COSTO_D1,@COSTO_D2,@COSTO_D3,@COSTO_D4,@COSTO_D5,@COSTO_D6,@COSTO_D7,@COSTO_D8,@COSTO_D9,@COSTO_D10) 
group by vhd_noserie, Factura, LIB_FACTOR) interno where Factura = interno.docto_interno and 
num_serie = interno.noserie_interno and LIB_FACTOR = interno.factor_interno 

update BI_VENTAS_UNIDADES_PREVIO set PARTICIPACION = interno.costo_interno from (select sum(vhd_costo) as costo_interno, 
vhd_noserie as noserie_interno, factura as docto_interno, LIB_FACTOR as factor_interno from uni_ltvehdeta, 
BI_VENTAS_UNIDADES_PREVIO where substring(Factura,2,len(factura)) = vhd_docto and vhd_noserie = num_serie and 
vhd_tipo in (@COSTO_D1,@COSTO_D2,@COSTO_D3,@COSTO_D4,@COSTO_D5,@COSTO_D6,@COSTO_D7,@COSTO_D8,@COSTO_D9,@COSTO_D10)
group by vhd_noserie, Factura, LIB_FACTOR) interno where Factura = interno.docto_interno and 
num_serie = interno.noserie_interno and LIB_FACTOR = interno.factor_interno 

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
--VENTAS SEMINUEVOS

Select TipoUnidad = 'SEMINUEVOS',IdCte = ade_vtafi.VTE_IDCLIENTE,RfcCte = PER_PERSONAS.PER_RFC,NombreCte =
rtrim(ltrim(rtrim(ltrim(PER_PERSONAS.per_nomrazon)) + ' ' + rtrim(ltrim(PER_PERSONAS.PER_PATERNO)) + ' ' + 
rtrim(ltrim(PER_PERSONAS.per_materno)))),TipoCte = PER_PERSONAS.PER_TIPO,CTE_DELEGACION = 
PER_PERSONAS.PER_DELEGAC,CTE_CIUDAD = PER_PERSONAS.PER_CIUDAD,CTE_COLONIA = PER_COLONIA,PER_CALLE1,PER_CALLE2,
PER_CALLE3,PER_NUMEXTER,PER_CODPOS,per_email,per_telefono1,ESTADO_DESC=descestado.par_descrip1,
veh_numserie as NumSerie,veh_noinventa as Inventario,
veh_colointe as ColorInterior,veh_coloexte as ColorExterior,
veh_anmodelo as Modelo,veh_tipoauto as DescModelo,
(select par_descrip1 from pnc_parametr where par_tipopara = 'MCAV' and par_idenpara = VEH_SMARCA) as Marca,
'AUTOS' as Segmento,'AUTOS' as subtipo_unidad,UNC_IDCATALOGO = '',CarLine = '',
case when veh_puertas = 'ISNULL' or ltrim(rtrim(veh_puertas)) = '' or isnumeric (veh_puertas)<> 1 then '0' else veh_puertas end as Puertas,
case when veh_cilindros = 'ISNULL' or ltrim(rtrim(veh_cilindros)) = '' then '0' else veh_cilindros end as cilindros,
UNC_POTENCIA = '',veh_combustible as Combustible,
case when veh_capacidad = 'ISNULL' or ltrim(rtrim(veh_capacidad)) = '' then '0' else '0' end  as Capacidad,
'' as Transmision,'' as Tipomotor,veh_orgunidad as Procedencia,
(select par_descrip1 from pnc_parametr where par_tipopara = 'tipvenusa' and par_idenpara = vte_formapago) as DescripcionVenta,
vte_docto as Factura,vte_fechdocto as FechaFactura,VEH_NOFACTPLAN as factura_planta,veh_fecoriagen as VEH_FECREMISION,
veh_nopedimtoext as NumPedimento,veh_fecpedimtoext as FechaPedimento,vte_referencia1 as Pedido,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'TADQ' AND PAR_IDMODULO = 'UNI' AND PAR_IDENPARA = VEH_STIPADQUI) AS TipoCompra,
vte_fechdocto as fecha_asignacion,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
CASE WHEN VEH_VENDEDOR <> '' THEN (SELECT PER_RFC FROM PER_PERSONAS WHERE PER_IDPERSONA = VEH_VENDEDOR) ELSE '' END AS Rfc_Asesor,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'EV' AND PAR_IDENPARA = VEH_VENDEDOR) AS Asesor,
VTE_VTABRUT AS PrecioLista,vte_descuento as Descuento,VTE_VTABRUT as importe,0 as ISAN,
VTE_VTABRUT AS venta,VTE_IVA as Iva,VTE_TOTAL as Total,
Costo=veh_ssubtotal,PEN_COSTO1=0,PEN_COSTO2=0,PEN_COSTO3=0,PEN_COSTO4=0,PARTICIPACION=0,Bonificacion=VEH_SCTOACOND,
Costo_Total=veh_ssubtotal*1.16,Utilidad_bruta=0,PorUtil=0,Unidades=1,LIB_FACTOR=0
INTO #VENTA_SEMINUEVOS
from ade_vtafi inner join usn_pedido on pms_numpedido = vte_referencia1 inner join ser_vehiculo 
on veh_numserie = vte_serie inner join GA_CORPORATIVA.DBO.per_personas AS PER_PERSONAS on per_idpersona = vte_idcliente
inner join pnc_parametr AS descestado on per_estado = descestado.par_idenpara where vte_tipodocto = 'u' 
AND ade_vtafi.VTE_IDCLIENTE = PER_PERSONAS.PER_IDPERSONA AND descestado.par_tipopara = 'eo' AND
convert(datetime,vte_fechdocto, 103) between convert(datetime,@FECHA_INI,103) and convert(datetime,@FECHA_FIN,103) 

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
--CANCELACIONES SEMINUEVOS

Select TipoUnidad = 'SEMINUEVOS',IdCte = ade_canfi.VEC_IDCLIENTE,RfcCte = PER_PERSONAS.PER_RFC,NombreCte =
rtrim(ltrim(rtrim(ltrim(PER_PERSONAS.per_nomrazon)) + ' ' + rtrim(ltrim(PER_PERSONAS.PER_PATERNO)) + ' ' + 
rtrim(ltrim(PER_PERSONAS.per_materno)))),TipoCte = PER_PERSONAS.PER_TIPO,CTE_DELEGACION = 
PER_PERSONAS.PER_DELEGAC,CTE_CIUDAD = PER_PERSONAS.PER_CIUDAD,CTE_COLONIA = PER_COLONIA,PER_CALLE1,PER_CALLE2,
PER_CALLE3,PER_NUMEXTER,PER_CODPOS,per_email,per_telefono1,ESTADO_DESC=descestado.par_descrip1,
veh_numserie as NumSerie,veh_noinventa as Inventario,veh_colointe as ColorInterior,veh_coloexte as ColorExterior,
veh_anmodelo as Modelo,veh_tipoauto as DescModelo,
(select par_descrip1 from pnc_parametr where par_tipopara = 'MCAV' and par_idenpara = VEH_SMARCA) as Marca,
'AUTOS' as Segmento,'AUTOS' as subtipo_unidad,UNC_IDCATALOGO = '',CarLine = '',
case when veh_puertas = 'ISNULL' or ltrim(rtrim(veh_puertas)) = '' or isnumeric (veh_puertas)<> 1 then '0' else veh_puertas end as Puertas,
case when veh_cilindros = 'ISNULL' or ltrim(rtrim(veh_cilindros)) = '' then '0' else veh_cilindros end as cilindros,
UNC_POTENCIA = '',veh_combustible as Combustible,
case when veh_capacidad = 'ISNULL' or ltrim(rtrim(veh_capacidad)) = '' then '0' else '0' end  as Capacidad,
'' as Transmision,'' as Tipomotor,veh_orgunidad as Procedencia,
(select par_descrip1 from pnc_parametr where par_tipopara = 'tipvenusa' and par_idenpara = VEC_FORMAPAGO) as DescripcionVenta,
'9' + VEC_DOCTO as Factura,VEC_FECHDOCTO as FechaFactura,VEH_NOFACTPLAN as factura_planta,veh_fecoriagen as VEH_FECREMISION,
veh_nopedimtoext as NumPedimento,veh_fecpedimtoext as FechaPedimento,VEC_REFERENCIA1 as Pedido,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'TADQ' AND PAR_IDMODULO = 'UNI' AND PAR_IDENPARA = VEH_STIPADQUI) AS TipoCompra,
VEC_FECHDOCTO as fecha_asignacion,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
CASE WHEN VEH_VENDEDOR <> '' THEN (SELECT PER_RFC FROM PER_PERSONAS WHERE PER_IDPERSONA = VEH_VENDEDOR) ELSE '' END AS Rfc_Asesor,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'EV' AND PAR_IDENPARA = VEH_VENDEDOR) AS Asesor,
VEC_VTABRUT AS PrecioLista,VEC_DESCUENTO as Descuento,VEC_VTABRUT as importe,0 as ISAN,
VEC_VTABRUT AS venta,VEC_IVA as Iva,VEC_TOTAL as Total,
Costo=veh_ssubtotal,PEN_COSTO1=0,PEN_COSTO2=0,PEN_COSTO3=0,PEN_COSTO4=0,PARTICIPACION=0,Bonificacion=VEH_SCTOACOND,
Costo_Total=veh_ssubtotal*1.16,Utilidad_bruta=0,PorUtil=0,Unidades=-1,LIB_FACTOR=1
INTO #CANCELA_SEMINUEVOS
from ade_canfi inner join usn_pedido on pms_numpedido = vec_referencia1 inner join ser_vehiculo on veh_numserie = vec_serie inner join GA_CORPORATIVA.DBO.per_personas AS PER_PERSONAS 
on per_idpersona = vec_idcliente inner join pnc_parametr AS descestado on per_estado = descestado.par_idenpara
where vec_tipodocto = 'u' and descestado.par_tipopara = 'eo' AND 
convert(datetime,vec_fechdocto, 103) between convert(datetime,@FECHA_INI,103) and convert(datetime,@FECHA_FIN,103)

------------------------------------------------------------
------------------------------------------------------------
INSERT INTO BI_VENTAS_UNIDADES_PREVIO
SELECT * FROM #VENTA_SEMINUEVOS

INSERT INTO BI_VENTAS_UNIDADES_PREVIO
SELECT * FROM #CANCELA_SEMINUEVOS

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
--CAMBIA SIGNOS EN CANCELACIONES
UPDATE BI_VENTAS_UNIDADES_PREVIO set 
importe = ISNULL(importe,0) * -1 , ISAN = ISNULL(ISAN,0) * -1 , venta = ISNULL(venta,0) * -1,
Iva = ISNULL(Iva,0) * -1,Total = ISNULL(Total,0) * -1,
PEN_COSTO1 = ISNULL(PEN_COSTO1,0)*-1, PEN_COSTO2 = ISNULL(PEN_COSTO2,0)*-1, PEN_COSTO3 = ISNULL(PEN_COSTO3,0)*-1, PARTICIPACION = ISNULL(PARTICIPACION,0)*-1 
WHERE LIB_FACTOR = 1 AND tipo_unidad = 'NUEVOS'

UPDATE BI_VENTAS_UNIDADES_PREVIO set Costo = ISNULL(Costo,0) * -1, Costo_Total = ISNULL(Costo_Total,0) * -1,
Bonificacion = ISNULL(Bonificacion,0) * -1
WHERE LIB_FACTOR = 1 AND tipo_unidad = 'SEMINUEVOS'

----------------------------------------------------
--MODIFICA COSTOS

IF @AGENCIA NOT IN ('08','20','19','23','22','09') BEGIN
   UPDATE BI_VENTAS_UNIDADES_PREVIO SET Bonificacion = ISNULL(Bonificacion,0) * -1 WHERE tipo_unidad = 'NUEVOS' AND LIB_FACTOR = 1

   UPDATE BI_VENTAS_UNIDADES_PREVIO SET Costo = ISNULL(Costo,0) - ISNULL(Bonificacion,0)-ISNULL(PEN_COSTO1,0)-
   ISNULL(PEN_COSTO2,0)-ISNULL(PEN_COSTO3,0)-ISNULL(PARTICIPACION,0) WHERE tipo_unidad = 'NUEVOS' 

   UPDATE BI_VENTAS_UNIDADES_PREVIO SET Costo_Total = ISNULL(Costo,0) + ISNULL(Bonificacion,0)
END

ELSE IF @AGENCIA IN('08','20') BEGIN
UPDATE BI_VENTAS_UNIDADES_PREVIO SET Bonificacion = ISNULL(Bonificacion,0) * -1 WHERE tipo_unidad = 'NUEVOS' AND LIB_FACTOR = 1

   UPDATE BI_VENTAS_UNIDADES_PREVIO SET Costo = ISNULL(PEN_COSTO1,0) WHERE tipo_unidad = 'NUEVOS' 

   UPDATE BI_VENTAS_UNIDADES_PREVIO SET Costo_Total = ISNULL(Costo,0) + ISNULL(Bonificacion,0)
END

ELSE IF @AGENCIA IN('19','23','22','09') BEGIN
UPDATE BI_VENTAS_UNIDADES_PREVIO SET Bonificacion = ISNULL(Bonificacion,0) * -1 WHERE tipo_unidad = 'NUEVOS' AND LIB_FACTOR = 1

   UPDATE BI_VENTAS_UNIDADES_PREVIO SET Costo = ISNULL(Costo,0) - ISNULL(PEN_COSTO1,0) WHERE tipo_unidad = 'NUEVOS' 

   UPDATE BI_VENTAS_UNIDADES_PREVIO SET Costo_Total = ISNULL(Costo,0) + ISNULL(Bonificacion,0)
END

INSERT INTO BI_VENTAS_UNIDADES
SELECT tipo_unidad,id_cliente,rfc_cliente,nombre_cliente,TipoCliente,Delegacion,Ciudad,CTE_COLONIA,PER_CALLE1,PER_CALLE2,
PER_CALLE3,PER_NUMEXTER,PER_CODPOS,per_email,per_telefono1,ESTADO_DESC,num_serie,inventario,color_exterior,color_interior,
Modelo,Descripcion,marca,segmento,subtipo_unidad,catalogo,carline,puertas,cilindros,potencia,combustible,capacidad,transmision,
tipo_motor,procedencia,tipo_venta,factura,fecha_factura,factura_planta,fecha_remision,pedimento,fecha_pedimento,pedido,
tipo_compra,fecha_asignacion,financiera,rfc_asesor,nombre_asesor,precio_lista,descuento,Importe,ISAN,Importe,iva,total,
Costo,Bonificacion,Costo_Total,utilidad_bruta,PorUtil,unidades FROM BI_VENTAS_UNIDADES_PREVIO

UPDATE BI_VENTAS_UNIDADES SET Utilidad_bruta = venta - Costo
UPDATE BI_VENTAS_UNIDADES SET PorUtil = round((venta - Costo) * 100 / venta,2)



go

