CREATE View [dbo].[vstCntVtaMes3] AS SELECT 0 AS Prs_CveAge, isNull(Sum(Prs_CantVta),0) AS SumVtasMes FROM PYM_ProspecHis GROUP BY RIGHT(Prs_FecVenta, 4), SUBSTRING(Prs_FecVenta, 4, 2), Prs_Estatus HAVING Right(Prs_FecVenta, 4) =  2008 AND SUBSTRING(Prs_FecVenta, 4, 2) = 3 AND Prs_Estatus = 2
go

