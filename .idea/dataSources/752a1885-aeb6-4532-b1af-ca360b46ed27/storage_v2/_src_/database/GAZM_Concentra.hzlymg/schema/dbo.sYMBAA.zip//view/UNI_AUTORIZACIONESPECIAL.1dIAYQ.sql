CREATE VIEW UNI_AUTORIZACIONESPECIAL
AS  
SELECT
UAE_IdAutorizacionEspecial, UCU_IdCotizacion, UAE_EstatusAutEsp, UAE_IdUsuarioSolicita, UAE_FechaSolicitud, UAE_IdUsuarioAutoriza, UAE_FechaAutorizacion, UAE_Monto  
FROM       CUENTASPORCOBRAR.dbo.UNI_AUTORIZACIONESPECIAL
go

