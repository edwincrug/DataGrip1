CREATE VIEW [dbo].[cxp_detalleautosnuevos]
AS
SELECT  
anu_iddetalle, anu_idcatalogo, anu_numeroserie, anu_aniomodelo, anu_idmarca, anu_idcolorext, anu_idcolorint, anu_clavevehicular, anu_costosiniva, anu_costoconiva, anu_idtipocompra, anu_cantidad, anu_idfinanciera, anu_diastranscfinanciamiento, anu_fechapromentrega, anu_horapromentrega, anu_comentarios, anu_modelo, oce_folioorden, anu_idcombustible, anu_idtransmision, anu_iddiasfinanciamiento, anu_idorigenmot, anu_idorigenunidad, anu_cvetipocompra, anu_preciocatalogo
FROM       CUENTASXPAGAR.dbo.cxp_detalleautosnuevos
go

