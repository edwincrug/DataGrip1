
CREATE VIEW [dbo].[uni_preordenser] 
AS     
SELECT upo_idpreordenser,upo_costo,upo_precio,upo_idusuarioalta,upo_fechaalta,upo_idusuariomodifica,upo_fechamodifica,upo_idpaquete,ucn_idcotizadetalle,upo_estatus,ces_idestatusordenser,ctc_idtipoorden,upo_idorden,upo_foliocompra,ucn_idcotizadetallepost,CEA_IdEstatusAdicionales,pmd_estatusautorizacion,upo_idtipoventa

FROM cuentasporcobrar.dbo.uni_preordenser
go

