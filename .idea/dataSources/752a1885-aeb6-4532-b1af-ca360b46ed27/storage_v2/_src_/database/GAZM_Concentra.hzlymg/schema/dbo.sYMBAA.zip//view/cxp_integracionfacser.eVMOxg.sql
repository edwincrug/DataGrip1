CREATE VIEW [dbo].[cxp_integracionfacser]
AS
SELECT ifs_idintegracion, ifs_folionuevo, ifs_folioanterior, ifs_ordenservicio
FROM cuentasxpagar.dbo.cxp_integracionfacser
go

