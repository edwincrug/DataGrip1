CREATE VIEW VIS_CONMOVPOL01 AS Select '01' as Vcmp_Empresa,'2003' as Vcmp_Anno,* FROM con_movdet012003
 union all Select '01' as Vcmp_Empresa,'2004' as Vcmp_Anno,* FROM con_movdet012004
 union all Select '01' as Vcmp_Empresa,'2005' as Vcmp_Anno,* FROM con_movdet012005
 union all Select '01' as Vcmp_Empresa,'2006' as Vcmp_Anno,* FROM con_movdet012006
 union all Select '01' as Vcmp_Empresa,'2007' as Vcmp_Anno,* FROM con_movdet012007
 union all Select '01' as Vcmp_Empresa,'2008' as Vcmp_Anno,* FROM con_movdet012008
 union all Select '01' as Vcmp_Empresa,'2009' as Vcmp_Anno,* FROM con_movdet012009
 union all Select '01' as Vcmp_Empresa,'2010' as Vcmp_Anno,* FROM con_movdet012010
 union all Select '01' as Vcmp_Empresa,'2011' as Vcmp_Anno,* FROM con_movdet012011
 union all Select '01' as Vcmp_Empresa,'2012' as Vcmp_Anno,* FROM con_movdet012012
 union all Select '01' as Vcmp_Empresa,'2013' as Vcmp_Anno,* FROM con_movdet012013
 union all Select '01' as Vcmp_Empresa,'2014' as Vcmp_Anno,* FROM con_movdet012014
 union all Select '01' as Vcmp_Empresa,'2015' as Vcmp_Anno,* FROM con_movdet012015
 union all Select '01' as Vcmp_Empresa,'2016' as Vcmp_Anno,* FROM con_movdet012016
 union all Select '01' as Vcmp_Empresa,'2017' as Vcmp_Anno,* FROM con_movdet012017
 union all Select '01' as Vcmp_Empresa,'2018' as Vcmp_Anno,* FROM con_movdet012018
 union all Select '01' as Vcmp_Empresa,'2019' as Vcmp_Anno,* FROM con_movdet012019
 union all Select '01' as Vcmp_Empresa,'2020' as Vcmp_Anno,* FROM con_movdet012020
go

