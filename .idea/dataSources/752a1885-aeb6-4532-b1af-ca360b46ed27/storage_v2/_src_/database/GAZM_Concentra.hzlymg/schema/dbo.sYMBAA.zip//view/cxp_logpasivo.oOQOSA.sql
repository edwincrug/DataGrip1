CREATE VIEW cxp_logpasivo
AS 
SELECT 
lps_idlogpasivo, lps_idempresa, lps_iddocumento, lps_tipopoliza, lps_error, coi_idcomisionesintereses
FROM cuentasxpagar.dbo.cxp_logpasivo
go

