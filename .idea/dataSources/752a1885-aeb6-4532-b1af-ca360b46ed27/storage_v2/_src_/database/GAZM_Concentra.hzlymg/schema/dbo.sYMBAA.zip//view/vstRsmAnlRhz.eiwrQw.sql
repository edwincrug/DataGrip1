CREATE VIEW [dbo].[vstRsmAnlRhz] AS SELECT ci.Prs_CveAGE, ag.SumVnd, isNull((Select Sum(SumVnd) From vstAnlRhzXAge),0) As TotAge, ci.SumGral, isNull((Select Sum(SumGral) From vstAnlRhzXCia),0) As TotGral FROM vstAnlRhzXCia ci LEFT OUTER JOIN vstAnlRhzXAge ag ON ci.Prs_CveAGE = ag.Prs_CveAGE
go

