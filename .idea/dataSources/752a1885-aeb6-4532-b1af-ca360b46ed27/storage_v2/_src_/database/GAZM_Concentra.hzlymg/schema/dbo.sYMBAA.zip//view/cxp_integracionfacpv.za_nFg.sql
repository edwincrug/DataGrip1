CREATE VIEW [dbo].[cxp_integracionfacpv]
AS
SELECT 
ifp_idintegracion, ifp_folioanterior, ifp_folionuevo, ifp_nopedido
FROM cuentasxpagar.dbo.cxp_integracionfacpv
go

