CREATE VIEW ser_presupwebdet
AS
SELECT     
pwd_idordendet, prw_idpresuorden, pwd_conse, pwd_descripprod, pwd_codigorefac, pwd_clasificacion, pwd_fechasolicitud, pwd_fechainicial, pwd_fechafinal, pwd_mecanico, pwd_tiempotab, pwd_cantidad, pwd_preciounitario, pwd_iva, pwd_costo, pwd_subtotal, pwd_referencia1, pwd_referencia2, pwd_referencia3, cec_idestatuspresuint, pwd_tiporden, pwd_idpaquete, pwd_avance, pwd_idfactura, pwd_idcausa, pwd_idfalla, pwd_idsolucion, pwd_idusuario, pwd_fechaoperacion, pwd_nivel, pwd_familia, pwd_clave, pwd_descripaquete, pwd_ereact, pwd_catetrabajo, pwd_iddivision, pwd_idempresa, pwd_iddepartamento, pwd_idsucursal, pwd_idproveedor, pwd_foliocompra
FROM        CUENTASPORCOBRAR.dbo.ser_presupwebdet
go

