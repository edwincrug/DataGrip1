CREATE VIEW [dbo].[cxp_flujoefectivo]
AS
SELECT 
fef_idflujoefectivo, fef_cuenta, fef_saldocuenta, fef_fechaflujo, fef_idusuario, fef_idempresa, fef_banco, fef_saldoinicial, fef_importecuenta, fef_saldofinal, tmf_idtipo, fef_saldocaja, fef_cobranzaesperada, fef_flujopendiente
FROM     cuentasxpagar.dbo.cxp_flujoefectivo
go

