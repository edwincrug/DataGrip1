
CREATE VIEW [dbo].[par_pedmostdet]      
AS      
SELECT		pmd_idparte
			,pmd_cantidad
			,pmd_tipoprecio
			,pmd_preciounitario
			,pmd_iva
			,pmd_total
			,pmd_estatus
			,pmd_idusuarioalta
			,pmd_fechaalta
			,pmm_idpedmostenc
			,pmd_idpedmostdet
			,pmd_idusuariomodifica
			,pmd_fechamodifica
			,ucn_idcotizadetalle
			,ctc_idtipoorden
			,ucn_idcotizadetallepost
			,CEA_IdEstatusAdicionales
			,pmd_idtipoventa
			,pmd_estatusautorizacion
			,pmd_agrupado      
FROM       CUENTASPORCOBRAR.dbo.par_pedmostdet
go

