CREATE VIEW [dbo].[vstAnlRhzXAge] AS SELECT Prs_CveAGE, COUNT(Prs_Estatus) AS SumVnd FROM dbo.PYM_ProspecHis GROUP BY Prs_CveAGE, SUBSTRING(Prs_FecOpe, 4, 2), RIGHT(Prs_FecOpe, 4), Prs_Estatus, Prs_CveAge HAVING RIGHT(Prs_FecOpe, 4) =  2007 AND SUBSTRING(Prs_FecOpe, 4, 2) = 10 AND Prs_Estatus = 3 AND Prs_CveAge = 'MNA'
go

