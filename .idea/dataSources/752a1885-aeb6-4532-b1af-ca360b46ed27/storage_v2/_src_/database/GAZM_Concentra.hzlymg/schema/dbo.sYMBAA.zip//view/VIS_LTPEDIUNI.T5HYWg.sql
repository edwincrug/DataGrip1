create view [dbo].[VIS_LTPEDIUNI] as 
select 'GAZM_Zaragoza'  as PEN_BD,[GAZM_Zaragoza].[dbo].uni_ltpediuni.*  from [GAZM_Zaragoza].[dbo].uni_ltpedido  inner join [GAZM_Zaragoza].[dbo].uni_ltpediuni  on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO 
union all
select 'GAZM_FAerea'     as PEN_BD,[GAZM_FAerea].[dbo].uni_ltpediuni.*     from [GAZM_FAerea].[dbo].uni_ltpedido     inner join [GAZM_FAerea].[dbo].uni_ltpediuni     on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO 
union all
select 'GAZM_Abasto'   as PEN_BD,[GAZM_Abasto].[dbo].uni_ltpediuni.*   from [GAZM_Abasto].[dbo].uni_ltpedido   inner join [GAZM_Abasto].[dbo].uni_ltpediuni   on pen_idpedi = upe_idpedi and UPE_TIPODOCTO = PEN_TIPODOCTO and UPE_DOCTO = PEN_DOCTO
go

