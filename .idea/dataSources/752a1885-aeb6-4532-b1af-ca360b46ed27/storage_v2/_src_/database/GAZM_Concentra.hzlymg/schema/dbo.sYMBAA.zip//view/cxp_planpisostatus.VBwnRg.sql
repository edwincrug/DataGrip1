CREATE VIEW [dbo].[cxp_planpisostatus]
AS
SELECT 
sta_idstatus, sta_descripcion, sta_fechaalta, sta_idusuarioalta, sta_fechamodifica, sta_idusuariomodifica
FROM  GA_Corporativa.dbo.cxp_planpisostatus
go

