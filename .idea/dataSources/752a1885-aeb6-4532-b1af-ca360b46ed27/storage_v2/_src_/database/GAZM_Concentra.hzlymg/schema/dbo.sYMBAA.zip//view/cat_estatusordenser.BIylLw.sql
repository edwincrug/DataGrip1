CREATE VIEW [dbo].[cat_estatusordenser] AS (
SELECT
ces_idestatusordenser, ces_nombrecorto, ces_nombre, ces_descripcion, ces_idusuarioalta, ces_fechaalta, ces_idusuariomodifica, ces_fechamodifica, ces_estatus
FROM cuentasporcobrar.dbo.cat_estatusordenser)
go

