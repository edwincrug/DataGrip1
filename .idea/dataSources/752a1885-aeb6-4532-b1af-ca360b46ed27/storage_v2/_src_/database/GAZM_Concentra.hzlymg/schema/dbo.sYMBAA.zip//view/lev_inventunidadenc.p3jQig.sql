CREATE VIEW lev_inventunidadenc
AS
SELECT 
liu_idinventuni, liu_noinventuni, liu_noserieuni, liu_previa, liu_ordenservicio, liu_usuariooper, liu_fechaoper, liu_reclama, iae_idinventacce, liu_iddivision, liu_idempresa, liu_idsucursal, liu_iddepartamento, liu_observaciongral, liu_usuariomodifica, liu_fechamodifica, cei_idestatusinventario
FROM CUENTASPORCOBRAR.dbo.lev_inventunidadenc
go

