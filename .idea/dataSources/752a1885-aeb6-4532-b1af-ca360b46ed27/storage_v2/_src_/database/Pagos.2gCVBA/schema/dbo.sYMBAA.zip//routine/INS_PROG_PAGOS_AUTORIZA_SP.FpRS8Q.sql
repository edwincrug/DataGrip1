

-- ==========================================================================================
-- Author:		FERNANDO ALVARADO LUNA
-- Create date: 15/03/2016
-- Description:	Insert a la Tabla Maestro y Detalle de Pagos Programados (Dinamico) empresa
--  
-- ==========================================================================================
--Execute [dbo].[INS_PROG_PAGOS_SP] 
CREATE PROCEDURE [dbo].[INS_PROG_PAGOS_AUTORIZA_SP]
       @idUsuario               numeric(18, 0) = 0
	  ,@idPadre                 numeric(18, 0) = 0
	  
AS
BEGIN
    SET NOCOUNT ON;	
BEGIN TRY	
      
		
			DELETE 
			  FROM [dbo].[PAG_PROGRA_PAGOS_DETALLE]
             WHERE [pal_id_lote_pago] = @idPadre

            
    
    DECLARE @total INT = (SELECT count(pal_id_lote_pago) FROM [dbo].[PAG_TABLA_PASO_POLIZAS]  T
	                                      WHERE T.[pal_id_lote_pago] = @idPadre)
	--select  @total as totalTablaPasoPolizas
	   
	BEGIN TRAN
	   INSERT INTO [dbo].[PAG_PROGRA_PAGOS_DETALLE]
				   ([pal_id_lote_pago]
					,[pad_fechaPromesaPago]
					,[pad_saldo]
					,[pad_aPagar]
					,[pad_polReferencia]
					,[pad_polTipo]
					,[pad_polAnnio]
					,[pad_polMes]
					,[pad_polConsecutivo]
					,[pad_polMovimiento]
					,[pad_polFechaOperacion]
					,[pad_documento]
					,[pad_cuenta]
					,[pad_idProveedor]
					,[pad_proveedor]
					--
					,[pad_tipoDocto]
					,[pad_cartera]
					,[pad_monto]
					,[pad_saldoPorcentaje]
					,[pad_moneda]
					,[pad_fechaVencimiento]
					,[pad_fechaRecepcion]
					,[pad_fechaFactura]
					---
					,[pad_ordenCompra]
					,[pad_estatus]
					,[pad_idEstatus]
					,[pad_anticipo]
					,[pad_anticipoAplicado]
					--
					,[pad_proveedorBloqueado]
					,[pad_ordenBloqueada]
					,[pad_diasCobro]
					,[pad_aprobado]
					,[pad_contReprog]
					,[pad_documentoPagable]
					--
					,[pad_nombreAgrupador]
					,[pad_ordenAgrupador]
					,[pad_ordenProveedor]
					,[pad_cuentaProveedor]
					,[pad_cuentaDestino]
                    ,[pad_seleccionable]
					--
					,[pad_numeroSerie]
                    ,[pad_facturaProveedor]
					,[pbp_consCartera]
					,[pad_bancoPagador]
					,[pad_agrupamiento]
					)
									         SELECT  tab.[pal_id_lote_pago]
													,tab.[pad_fechaPromesaPago]
													,tab.[pad_saldo]
													,tab.[tab_revision]
													,tab.[pad_polReferencia]
													,BPRO.[pbp_polTipo]           as polTipo
													,BPRO.[pbp_polAnnio]          as annio
													,BPRO.[pbp_polMes]            as polMes
													,BPRO.[pbp_polConsecutivo]    as polConsecutivo
													,BPRO.[pbp_polMovimiento]     as polMovimiento
													,BPRO.[pbp_polFechaOperacion] as polFechaOperacion
													--
													,BPRO.[pbp_documento]         as documento 
													,BPRO.[pbp_cuenta]            as cuenta
													,BPRO.[pbp_idProveedor]       as idProveedor
													,BPRO.[pbp_proveedor]         as proveedor
													,BPRO.[pbp_tipoDocto]         as tipoDocto
													,BPRO.[pbp_cartera]           as cartera
													,BPRO.[pbp_monto]             as monto
													--
													,BPRO.[pbp_saldoPorcentaje]   as saldoPorcentaje
													,BPRO.[pbp_moneda]            as moneda
													,BPRO.[pbp_fechaVencimiento]  as fechaVencimiento
													--
													,BPRO.[pbp_fechaRecepcion]    as fechaRecepcion
													,BPRO.[pbp_fechaFactura]      as fechaFactura
													,BPRO.[pbp_ordenCompra]       as ordenCompra
													,BPRO.[pbp_estatus]           as estatus
													,BPRO.[pbp_idEstatus]         as idEstatus
													,BPRO.[pbp_anticipo]          as anticipo
													,BPRO.[pbp_anticipoAplicado]  as anticipoAplicado
													,BPRO.[pbp_proveedorBloqueado] as proveedorBloqueado
													,BPRO.[pbp_ordenBloqueada]     as ordenBloqueada
													,BPRO.[pbp_diasCobro]          as diasCobro
													,BPRO.[pbp_aprobado]           as aprobado
													,BPRO.[pbp_contReprog]         as contReprog
													,BPRO.[pbp_documentoPagable]   as documentoPagable
													--
													,BPRO.[pbp_nombreAgrupador]    as nombreAgrupador
													,BPRO.[pbp_ordenAgrupador]     as ordenAgrupador
													,BPRO.[pbp_ordenProveedor]     as ordenProveedor
													--
													,tab.[pad_bancoPagador]    as cuentaPagadora
													--
													,tab.[pad_bancoDestino]      as cuentaDestino
													--
                                                    ,BPRO.[pbp_seleccionable]      as seleccionable
													--
													,BPRO.[pbp_numeroSerie]        as numeroSerie
                                                    ,BPRO.[pbp_facturaProveedor]   as facturaProveedor
													,BPRO.[pbp_consCartera]        as consCartera
													,tab.[pad_bancoPagador]
													,tab.[pad_agrupamiento]
												FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] AS BPRO
													 INNER JOIN [Pagos].[dbo].[PAG_TABLA_PASO_POLIZAS] Tab ON tab.[pal_id_lote_pago]    = @idPadre
																AND BPRO.[pbp_polTipo]        = tab.[pad_polTipo] 
																AND BPRO.[pbp_polTipo]        = tab.[pad_polTipo] COLLATE Modern_Spanish_CI_AS
																AND BPRO.[pbp_polAnnio]       = tab.[pad_polAnnio] 
																AND BPRO.[pbp_polMes]         = tab.[pad_polMes]
																AND BPRO.[pbp_polConsecutivo] = tab.[pad_polConsecutivo]  
																AND BPRO.[pbp_polMovimiento]  = tab.[pad_polMovimiento]
																AND BPRO.[pbp_documento]  = tab.[pad_documento]
																--WHERE  tab.[pal_id_lote_pago]    = @idPadre
    
	--select @@ROWCOUNT as totalInsertados
	IF @@ROWCOUNT = @total 
		        SELECT 0  --Se insertaron todos los Registros
    ELSE 
	    BEGIN
	            SELECT 2  --Insercion incompleta
				--ROLLBACK TRAN
	    END    
													  			
	---------------  Ingresos  ----------------------------------------------------------------------
	
	-------------------------------------------------------------------------------------------------
	
	COMMIT TRAN    
	        
	--Se borran los datos de la tabla de Paso
	DELETE [dbo].[PAG_TABLA_PASO_POLIZAS] WHERE [pal_id_lote_pago] = @idPadre	

END TRY

BEGIN CATCH
     ROLLBACK TRAN
	 --Se borran los datos de la tabla de Paso
	 DELETE [dbo].[PAG_TABLA_PASO_POLIZAS] WHERE [pal_id_lote_pago] = @idPadre

	 PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[INS_PROG_PAGOS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 1  --Encontro error

END CATCH

END



go

