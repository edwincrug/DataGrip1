

-- =============================================
-- Author:		FAL
-- Create date: 01062016
-- Description:	AGREGA LAS REFERENCIAS A LOS LOTES APROVADOS.
-- =============================================

--EXECUTE [INS_REF_AUTOMATICA_LOTE_SP] 326
CREATE PROCEDURE [dbo].[INS_REF_AUTOMATICA_LOTE_SP18092020]

	 @idLote DECIMAL(18,0) = 0


AS
BEGIN

	
				DECLARE @total INT = (SELECT COUNT(*) FROM (SELECT pad_idProveedor FROM   PAG_PROGRA_PAGOS_DETALLE WHERE (pal_id_lote_pago = @idLote) group by pad_idProveedor, pad_agrupamiento) as Num)
				DECLARE @aux   INT = 1	
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), lote numeric(18, 0), proveedor numeric(18, 0), agrupamiento int )
				declare @Referencia int = 0
				DECLARE @STRREFERENCIA nvarchar(30)						
				INSERT INTO @VariableTabla  (lote, proveedor, agrupamiento)
				SELECT pal_id_lote_pago, pad_idProveedor, pad_agrupamiento AS LOTE FROM   PAG_PROGRA_PAGOS_DETALLE WHERE (pal_id_lote_pago = @idLote) group by pad_idProveedor, pal_id_lote_pago, pad_agrupamiento


				WHILE(@aux <=  @total)
						BEGIN
									
									SET @Referencia = @Referencia + 1
									SET @STRREFERENCIA = ''
									declare @loteactual as numeric(18, 0)
									declare @proveedoractual as numeric(18,0)
									DECLARE @numagrupamiento as int
									set @loteactual = (SELECT lote FROM @VariableTabla WHERE ID = @aux)
									set @proveedoractual = (SELECT proveedor FROM @VariableTabla WHERE ID = @aux)
									set @numagrupamiento = (SELECT agrupamiento FROM @VariableTabla WHERE ID = @aux)
									SET @STRREFERENCIA = cast (@Referencia AS varchar(30))
									SET @STRREFERENCIA = right(replicate ('0',3) + cast (@Referencia AS varchar(3)) ,3)
									SET @STRREFERENCIA = cast (@loteactual AS varchar(30)) + '-' + cast (@proveedoractual AS varchar(30)) + '-' + @STRREFERENCIA
									INSERT INTO  PAG_REFERENCIA (pre_referencia, pre_tipo, pal_id_lote_pago, pre_estatus, pad_idProveedor, pad_agrupamiento)
									VALUES(@STRREFERENCIA,1,@loteactual,1,@proveedoractual, @numagrupamiento)

									DECLARE @id_refesrch as numeric(18,0)
									
									SELECT @id_refesrch = pre_id_referencia  FROM PAG_REFERENCIA WHERE pal_id_lote_pago = @idLote AND pad_idProveedor =  @proveedoractual

									EXECUTE [INS_REF_AUTOMATICA_LOTE_DETALLE_SP] @idLote,@proveedoractual,@id_refesrch,@numagrupamiento
									SET @aux = @aux + 1
						END
	
	
	SELECT @total

END

go

