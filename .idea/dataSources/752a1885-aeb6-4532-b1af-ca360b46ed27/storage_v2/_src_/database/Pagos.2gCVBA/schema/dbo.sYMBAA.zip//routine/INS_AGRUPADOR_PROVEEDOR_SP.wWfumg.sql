-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 07/03/2016
-- Description:	Inserta Agrupador Proveedor
-- =============================================
--EXECUTE [INS_AGRUPADOR_PROVEEDOR_SP]                      
CREATE PROCEDURE [dbo].[INS_AGRUPADOR_PROVEEDOR_SP]
	 @idAgrupador          numeric(18,0) =0
	,@idProveedor          int =0
    ,@ordenAgruProveedor   int =0
	--,@idEmpresa         numeric(18,0) =0
	
    
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
	--IF( @idEmpresa = 4)  --Falta definir si filtrara los Proveedores por empresa
			   INSERT INTO [dbo].[PAG_AGRUPADOR_PROVEEDOR]
					   ([pca_idAgrupador]
					   ,[pap_idProveedor]
					   ,[pap_orden])               
				  VALUES
					   (@idAgrupador
					   ,@idProveedor
					   ,@ordenAgruProveedor
					   )
           SELECT 1
     --ELSE
	    --SELECT 'No hay información sobre esta empresa'

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[INS_AGRUPADOR_PROVEEDOR_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 0
END CATCH		     
END

go

