-- =============================================
-- Author:		
-- Create date: 09/02/2016
-- Description: Recupera los datos de operación del usuario.
-- =============================================
--EXECUTE [SEL_EMPLEADO_SP] 71
CREATE PROCEDURE [dbo].[SEL_EMPLEADO_SP] 
	@idEmpleado  int = 0
AS
BEGIN
	SET NOCOUNT ON;


      SELECT  U.usu_idusuario AS idusuario
			, U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS nombre
			, U.usu_correo AS correo
			, U.dep_iddepartamento AS iddepartamento
			, 0 AS idsucursal
			, 0 as emp_idempresa
			, isnull(r.prup_id_perfil,0) as idPerfil
		FROM  ControlAplicaciones.dbo.cat_usuarios U left JOIN
			  PAGOS.dbo.PAG_USUARIOS D ON U.usu_idusuario = d.pus_usuario
			  LEFT JOIN PAGOS.dbo.PAG_REL_USUARIO_PERFIL R ON d.pus_usuario = r.prup_id_usuario
			  
		WHERE U.usu_idusuario = @idEmpleado 

	
END



go

