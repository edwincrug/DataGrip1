-- =============================================
-- Author:		Francisco Javier Suárez Priego
-- Create date: 05/07/2019
-- Description:	<Description,,>
-- =============================================
--EXEC  SEL_DETALLES_PAGOS_BITACORA 10428, '1', 2
CREATE PROCEDURE SEL_DETALLES_PAGOS_BITACORA 
	-- Add the parameters for the stored procedure here
	@idLote int,
	@Referencia nvarchar(15),
	@tipo int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @tipo = 3
			BEGIN
			select  

			L.pal_id_lote_pago as Lote,
			L.pal_nombre  as NombreLote,
			E.pel_descripcion as EstatusLote,
			DB.pad_proveedor as NombreProvedor, 
			DB.pad_documento as NombreDocumento, 
			DB.pad_tipoDocto as tipoDocumento,
			DB.pad_monto as Monto,
			L.pal_fecha as Fecha,
			DB.pad_bancoPagador as cuenta


			from dbo.PAG_PROGRA_PAGOS_DETALLE_BITACORA DB
			inner join dbo.PAG_LOTE_PAGO L on db.pal_id_lote_pago = L.pal_id_lote_pago
			inner join dbo.PAG_ESTATUS_LOTE E on l.pal_estatus=e.pel_id_estatus_pago
			WHERE L.pal_id_lote_pago = @idLote and db.pad_polReferencia=@Referencia
			END
		ELSE IF  @tipo = 2
		BEGIN
			select  

			L.pal_id_lote_pago as Lote,
			L.pal_nombre  as NombreLote,
			E.pel_descripcion as EstatusLote,
			DB.pad_proveedor as NombreProvedor, 
			DB.pad_documento as NombreDocumento, 
			DB.pad_tipoDocto as tipoDocumento,
			DB.pad_monto as Monto,
			L.pal_fecha as Fecha,
			DB.pad_bancoPagador as cuenta


			from dbo.PAG_PROGRA_PAGOS_DETALLE_BITACORA DB
			inner join dbo.PAG_LOTE_PAGO L on db.pal_id_lote_pago = L.pal_id_lote_pago
			inner join dbo.PAG_ESTATUS_LOTE E on l.pal_estatus=e.pel_id_estatus_pago
			WHERE L.pal_id_lote_pago = @idLote and db.pad_procesoBanco=@Referencia
			END
END
go

