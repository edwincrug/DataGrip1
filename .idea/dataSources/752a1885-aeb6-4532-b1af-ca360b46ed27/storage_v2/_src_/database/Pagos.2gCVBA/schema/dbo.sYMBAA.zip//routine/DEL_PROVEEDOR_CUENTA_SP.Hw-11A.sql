-- ====================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 08/03/2016
-- Description:	
-- ====================================================
--EXECUTE [DEL_PROVEEDOR_CUENTA_SP] 4,139,'BANCOMER 1289'               
CREATE PROCEDURE [dbo].[DEL_PROVEEDOR_CUENTA_SP]
	 @idEmpresa numeric(18,0)=0,
	 @IdProveedor numeric(18,0)=0,
	 @CuentaPagadora nvarchar(50) = null
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
	   --Me regresa todos los usuarios asociados a ese Lote
	   IF(@idEmpresa =0)
	   BEGIN
	           SELECT  'Se debe seleccionar una empresa'

	   END
	   ELSE
	   --Me regresa todos los proveedores asociados a esa empresa
	     BEGIN

		 UPDATE [dbo].[PAG_CAT_PROVEEDORES]
		 SET pcp_cuentaPagadora = @CuentaPagadora
		 WHERE pcp_idEmpresa = @idEmpresa AND pcp_idProveedor = @IdProveedor

			   -- DELETE
				 -- FROM [dbo].[PAG_CAT_PROVEEDORES]
                 --WHERE [pcp_idEmpresa] = @idEmpresa
				 --  AND [pcp_idProveedor] =555
         END  
		 
		 SELECT '1'  

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[DEL_PROVEEDOR_CUENTA_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT  0 --'Error en la consulta' 
END CATCH		     
END

go

