		create view PagosEXCEPT as 
		
					  SELECT   B.[pbp_polTipo]           as polTipo
					          ,B.[pbp_polAnnio]          as annio
					          ,B.[pbp_polMes]            as polMes
					          ,B.[pbp_polConsecutivo]    as polConsecutivo
					          ,B.[pbp_polMovimiento]     as polMovimiento
							  ,B.[pbp_saldo]	as saldo
						FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] B
                      EXCEPT
					      	 SELECT   D.[pad_polTipo]                                  as polTipo                    
									  ,CAST((ROUND(D.[pad_polAnnio],0)) AS INT)        as annio
									  ,CAST((ROUND(D.[pad_polMes],0)) AS INT)          as polMes
									  ,CAST((ROUND(D.[pad_polConsecutivo],0)) AS INT)  as polConsecutivo
									  ,CAST((ROUND(D.[pad_polMovimiento],0)) AS INT)   as polMovimiento
									  --INCLUYE EL SALDO SI VIENE UN SEGUNDO PAGO TIENE QUE INCLUIR EL MOVIMEINTO
									  ,D.[pad_saldo] as saldo
								FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
									,[Pagos].[dbo].[PAG_LOTE_PAGO]            L
							   WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago]
								 --AND datediff (day,L.[pal_fecha],getdate()) = 0
								 AND D.[pad_aPagar] = 1
        go

