
-- =============================================
-- Author:		LQMA
-- Create date: 09042016
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [INS_APLICA_LOTE_SP] 1,8,77
CREATE PROCEDURE [dbo].[INS_APLICA_LOTE_SP]
	
	 @emp_idempresa INT = 0,
	 @idLote DECIMAL(18,0) = 0,
	 @idUsuario numeric(18,0)=0

	
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @ipServidor    VARCHAR(100);
				DECLARE @cadIpServidor VARCHAR(100);
				DECLARE @nombreBase    VARCHAR(100);
				DECLARE @campos        VARCHAR(max);
				DECLARE @tabla         VARCHAR(max);
				DECLARE @condicion     VARCHAR(max);
				DECLARE @consultaSaldo VARCHAR(max);
				DECLARE @totalSaldo     decimal(18,5);
				DECLARE @select         VARCHAR(max);

				SELECT @nombreBase = [nombre_base]        
					  ,@ipServidor = [ip_servidor]      
				FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
				WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
											FROM [ControlAplicaciones].[dbo].[cat_empresas]
										WHERE [emp_idempresa] = @emp_idempresa)
				  AND tipo = 2


				
	
		
				DECLARE @total INT = (SELECT count(pal_id_lote_pago) FROM [dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pal_id_lote_pago = @idLote)	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), conscartera numeric(18, 0), iddocumento nvarchar(25), idpersona numeric(18, 0), cuentapagadora nvarchar(50), cuentabeneficiario nvarchar(50), importepagado decimal(18, 5), folioorden nvarchar(50) NULL, pagoaplicado int, ordenCompra nvarchar(80), lote int, idempresa int)
										
				INSERT INTO @VariableTabla (conscartera,iddocumento,idpersona,cuentapagadora,cuentabeneficiario,importepagado,folioorden,pagoaplicado, ordenCompra, idempresa, lote) 

				SELECT   PAG_PROGRA_PAGOS_BPRO.pbp_consCartera, PAG_PROGRA_PAGOS_DETALLE.pad_documento, PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor, PAG_PROGRA_PAGOS_BPRO.pbp_cuentaPagadora, 
                         PAG_PROGRA_PAGOS_DETALLE.pad_cuentaDestino, PAG_PROGRA_PAGOS_DETALLE.pad_saldo, PAG_PROGRA_PAGOS_DETALLE.pad_documento AS Doc2, 0 AS Expr1, 
                         PAG_PROGRA_PAGOS_BPRO.pbp_ordenCompra, PAG_LOTE_PAGO.pal_id_empresa, PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago
				FROM            PAG_PROGRA_PAGOS_DETALLE INNER JOIN
										 PAG_PROGRA_PAGOS_BPRO ON PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor = PAG_PROGRA_PAGOS_BPRO.pbp_idProveedor AND 
										 PAG_PROGRA_PAGOS_DETALLE.pad_documento = PAG_PROGRA_PAGOS_BPRO.pbp_documento INNER JOIN
										 PAG_LOTE_PAGO ON PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = PAG_LOTE_PAGO.pal_id_lote_pago
				WHERE        (PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = @idLote)

				
		
				WHILE(@aux <=  @total)
						BEGIN
						
						declare @folioactual as nvarchar(80)
						declare @cuentaPagadora as nvarchar(50)
						declare @cuentaPagadoraParametro as nvarchar(50)
						declare @cuentaPagadoratabla as nvarchar(50)
						declare @cuentaBeneficiario as nvarchar(50)
						declare @varidpersona as nvarchar(50)
						declare @idempresa as int

						SET @cuentaPagadora = (SELECT cuentapagadora FROM @VariableTabla WHERE ID = @aux)
						SET @varidpersona = (SELECT idpersona FROM @VariableTabla WHERE ID = @aux)
						SET @idempresa = (SELECT idempresa FROM @VariableTabla WHERE ID = @aux)

						--FAL02082017
						--UPDATE PARA QUE NO HAYA EL ERROR DE DIFERENCIA 0.

						
						UPDATE GAAU_CONCENTRA.DBO.CON_CAR012017 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = @varidpersona AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = 'FAC'

						--2016
			
						UPDATE GAAU_CONCENTRA.DBO.CON_CAR012016 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = @varidpersona AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = 'FAC'


						--FIN FAL02082017

						DECLARE @strSql NVARCHAR(500)=null;
						DECLARE @strSql2 NVARCHAR(500)=null;
						
						
						SET @cuentaPagadoraParametro = (SELECT  pbp_idBanco FROM   PAG_PROVEEDOR_BANCO_PAGADOR WHERE  (pbp_idEmpresa = cast (@emp_idempresa as varchar(2))) AND (pbp_idProveedor = cast (@varidpersona as varchar(2))))
						
						DECLARE @retval nvarchar(50);   
						DECLARE @sSQL nvarchar(500);
						DECLARE @ParmDefinition nvarchar(500);

						SET @sSQL = 'SELECT @retvalOUT = P.PAR_DESCRIP3 FROM ' + @cadIpServidor + '[' + @nombreBase + '].[dbo].[PNC_PARAMETR] P INNER JOIN [' + @nombreBase + '].[dbo].[PNC_PARAMETR] PP ON P.PAR_DESCRIP5 = PP.PAR_IDENPARA  WHERE P.PAR_TIPOPARA = ''TRANSBCO'' AND PP.PAR_IMPORTE5 = ' + @cuentaPagadoraParametro + ' AND PP.PAR_TIPOPARA = ''CCHEQ'''
						SET @ParmDefinition = N'@retvalOUT nvarchar(50) OUTPUT';
						EXEC sp_executesql @sSQL, @ParmDefinition, @retvalOUT=@retval OUTPUT;
						SET @cuentaPagadoratabla = @retval;

						SET @sSQL = 'SELECT @retvalOUT = BCO_NUMCUENTA FROM ' + @cadIpServidor + '[' + @nombreBase + '].[dbo].[CON_BANCOS] WHERE BCO_IDPERSONA = ''' + cast (@varidpersona as varchar(2)) +''''
						SET @ParmDefinition = N'@retvalOUT nvarchar(50) OUTPUT';
						EXEC sp_executesql @sSQL, @ParmDefinition, @retvalOUT=@retval OUTPUT;
						SET @cuentaBeneficiario = @retval;

						--INSERT INTO [cuentasxpagar].[dbo].[cxp_doctospagados](dpa_conscartera,dpa_iddocumento,dpa_idpersona,dpa_cuentapagadora,dpa_cuentabeneficiario,dpa_importepagado,dpa_folioorden,dpa_pagoaplicado, dpa_lote, dpa_idempresa)
					    SELECT conscartera, iddocumento, idpersona, @cuentaPagadoratabla, @cuentaBeneficiario, importepagado, folioorden, 0,@idLote,@idempresa FROM @VariableTabla WHERE ID = @aux

						SET @folioactual = (SELECT ordenCompra FROM @VariableTabla WHERE ID = @aux)

						EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
														   @proc_Id = 1  
														  ,@nodo_Id = 7 
														  ,@folio_Operacion = @folioactual
							
						EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
														   @proc_Id = 1 
														  ,@nodo_Id = 8
														  ,@folio_Operacion = @folioactual

						EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
														   @proc_Id = 1 
														  ,@nodo_Id = 9
														  ,@folio_Operacion = @folioactual

						EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
														   @proc_Id = 1 
														  ,@nodo_Id = 10
														  ,@folio_Operacion = @folioactual
						
						update PAG_LOTE_PAGO  SET pal_estatus = 3	WHERE pal_id_lote_pago = @idLote

						SET @aux = @aux + 1	
						
						--SELECT @aux
								
						END

	

END



go

