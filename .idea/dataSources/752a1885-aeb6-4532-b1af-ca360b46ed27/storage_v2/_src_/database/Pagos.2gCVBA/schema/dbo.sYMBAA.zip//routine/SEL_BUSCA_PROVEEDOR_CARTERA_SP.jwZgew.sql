

-- ==========================================================================================
-- ==========================================================================================
-- EXECUTE [dbo].[SEL_BUSCA_PROVEEDOR_CARTERA_SP] @idProveedor= '', @nombreProveedor= '', @rfc= 'XAXX01010' , 1   
CREATE PROCEDURE [dbo].[SEL_BUSCA_PROVEEDOR_CARTERA_SP]
     @idProveedor     VARCHAR(30)
	,@nombreProveedor VARCHAR(150)
	,@rfc             VARCHAR(30)
	,@IdEmpresa		  VARCHAR (20)            
AS
BEGIN
	BEGIN TRY
	SET NOCOUNT ON;

	DECLARE @baseDatos NVARCHAR(1000)
			,@sql NVARCHAR(1000)

	
	
	DECLARE @Server VARCHAR(100) =(
	SELECT local_net_address
    FROM sys.dm_exec_connections
    WHERE Session_id = @@SPID)
	

	SELECT @baseDatos =  '['+ ip_servidor + '].[GA_Corporativa].[dbo].PER_PERSONAS' 
	FROM	[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
	WHERE	tipo  = 2 
	AND		emp_idempresa = @IdEmpresa

	IF (@idProveedor <> '')
	BEGIN
	     PRINT '1)Busco por ID'
		
		SET @sql = 'SELECT TOP 5 PER_IDPERSONA as idProveedor
						 , RTRIM(LTRIM(PER_NOMRAZON  + '' '' + PER_PATERNO + '' '' + PER_MATERNO)) as Nombre
						 , PER_RFC as RFC
					FROM ' + @baseDatos +
					' WHERE PER_IDPERSONA LIKE ''' + @idProveedor + '%'''

		
		PRINT @SQL
		EXEC  sp_executesql @sql


	 
	END
		ELSE IF (@nombreProveedor <> '')
		BEGIN
			PRINT '2)Busco por nombre'
			
		SET @sql = 'SELECT TOP 5 PER_IDPERSONA as idProveedor
						 , RTRIM(LTRIM(PER_NOMRAZON  + '' '' + PER_PATERNO + '' '' + PER_MATERNO)) as Nombre
						 , PER_RFC as RFC
					FROM ' + @baseDatos +
					' WHERE RTRIM(LTRIM(PER_NOMRAZON  + '' '' + PER_PATERNO + '' '' + PER_MATERNO)) Like ''%'+ @nombreProveedor +'%'''

		PRINT @SQL
		EXEC  sp_executesql @sql

		
		END
			ELSE IF (@rfc <> '')
			BEGIN
				PRINT '3)Busco por RFC'

				SET @sql = 'SELECT TOP 5 PER_IDPERSONA as idProveedor
							, RTRIM(LTRIM(PER_NOMRAZON  + '' '' + PER_PATERNO + '' '' + PER_MATERNO)) as Nombre
						 , PER_RFC as RFC
						  FROM ' + @baseDatos +
					' WHERE RTRIM(LTRIM(PER_RFC)) Like ''%'+ @rfc +'%'''


			PRINT @SQL
			EXEC  sp_executesql @sql
				
			END
	END TRY

    BEGIN CATCH
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_BUSCA_PROVEEDOR_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END

go

