

-- ====================================================
-- Author:		Fernando Alvarado Luna	
-- Create date: 03/08/2017
-- Description:	job que actualiza los estatus para los aplicados
-- ====================================================
--EXECUTE [JOB_UPDATE_LOTES_ESTATUS_SP]
CREATE PROCEDURE [dbo].[JOB_UPDATE_LOTES_ESTATUS_SP]

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
			DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), idLotePago numeric(18, 0), idEmpresa numeric(18, 0),estatus numeric(18, 0),numdetalle numeric(18, 0),numpendiente numeric(18, 0),numaplicado numeric(18, 0))
										
			INSERT INTO @VariableTabla (idLotePago,idEmpresa,estatus, numdetalle, numpendiente, numaplicado) 

	        SELECT   L.[pal_id_lote_pago]    as idLotePago
					,L.[pal_id_empresa]      as idEmpresa
					,L.[pal_estatus]         as estatus
					,COUNT(D.[pal_id_lote_pago]) AS numdetalle
					,(SELECT COUNT(DP.[dpa_lote]) FROM [cuentasxpagar].[dbo].[cxp_doctospagados] DP WHERE DP.[dpa_lote] = L.[pal_id_lote_pago] and ((DP.[dpa_pagoaplicado] = 2) OR (DP.[dpa_pagoaplicado] = 0))) AS numpendiente
					,(SELECT COUNT(DP.[dpa_lote]) FROM [cuentasxpagar].[dbo].[cxp_doctospagados] DP WHERE DP.[dpa_lote] = L.[pal_id_lote_pago] and  DP.[dpa_pagoaplicado] = 1) AS numaplicado
			  FROM  [Pagos].[dbo].[PAG_LOTE_PAGO] L
					LEFT JOIN [cuentasxpagar].[dbo].[cxp_logaplicacion] LO ON LO.[lap_lote]= L.[pal_id_lote_pago]
				   ,[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
			 WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
			   
			   AND D.[pad_aPagar] = 1
			   AND L.[pal_estatus] >= 4 AND L.[pal_estatus] < 7
			   --
             GROUP BY L.[pal_id_lote_pago],L.[pal_id_empresa],L.[pal_estatus],L.[pal_esAplicacionDirecta]

			 DECLARE @total INT = (SELECT count(*) FROM @VariableTabla )	
			 DECLARE @aux   INT = 1

			 WHILE(@aux <=  @total)
						BEGIN
						declare @empresa as int
						declare @diferencia as int
						declare @varidLOTE as numeric(18,0)
						declare @varnumpendiente as int
						declare @varnumaplicado as int

						SET @diferencia = (SELECT (numdetalle - numaplicado ) AS DIFERENCIA FROM @VariableTabla WHERE ID = @aux)
						SET @varidLOTE = (SELECT idLotePago FROM @VariableTabla WHERE ID = @aux)
						SET @empresa = (SELECT idempresa FROM @VariableTabla WHERE ID = @aux)
						SET @varnumpendiente = (SELECT numpendiente FROM @VariableTabla WHERE ID = @aux)
						SET @varnumaplicado = (SELECT numaplicado FROM @VariableTabla WHERE ID = @aux)

						IF ((@varnumpendiente + @varnumaplicado) > 0)
						BEGIN
								IF (@diferencia = 0)
								BEGIN
									UPDATE Pagos.dbo.[PAG_LOTE_PAGO] SET pal_estatus = 7 WHERE (pal_id_empresa = @empresa AND pal_id_lote_pago = @varidLOTE)
								END 
								ELSE
								BEGIN
									UPDATE Pagos.dbo.[PAG_LOTE_PAGO] SET pal_estatus = 6 WHERE (pal_id_empresa = @empresa AND pal_id_lote_pago = @varidLOTE)
								END
						END 

			  SET @aux = @aux + 1	

			  END 

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END



go

