-- ==========================================================================================
-- Author:	Lourdes Maldonado Sánchez	
-- Create date: 24/02/2016
-- Description:	Procedimiento que me regresara la consulta a la información guardada en las 
--              tablas PROG_PAGOS y PROG_PAGOS_DETALLE
-- ==========================================================================================
--EXECUTE [SEL_PROG_PAGOS_GUARDADA_SP] 292
CREATE PROCEDURE [dbo].[SEL_PROG_PAGOS_GUARDADA_SP] 
	      @idPadre      numeric(18,0) = 0
AS
BEGIN
	SET NOCOUNT ON;
  BEGIN TRY
	   SELECT  D.[pal_id_lote_pago]         AS idPadre
	          ,M.[pal_id_usuario]           AS idUsuario
	          ,M.[pal_fecha]                AS fechaRegistro
			  ,D.[pad_idProveedor]          AS idProveedor
			  ,D.[pad_polTipo]              AS polTipo
			  ,D.[pad_polAnnio]             AS annio
			  ,D.[pad_polMes]			    AS polMes
			  ,D.[pad_polConsecutivo]	    AS polConsecutivo
			  ,D.[pad_polMovimiento]	    AS polMovimiento
			  ,D.[pad_polFechaOperacion]    AS polFechaOperacion
			  ,D.[pad_cuenta]			    AS cuenta
			  ,D.[pad_proveedor]			AS proveedor
			  ,D.[pad_documento]			AS documento
			  ,D.[pad_tipo]					AS tipo
			  ,D.[pad_tipoDocto]			AS tipoDocto
			  ,D.[pad_cartera]				AS cartera
			  ,D.[pad_monto]				AS monto
			  ,D.[pad_saldo]				AS saldo
			  ,D.[pad_saldoPorcentaje]		AS saldoPorcentaje
			  ,D.[pad_moneda]				AS moneda
			  ,D.[pad_fechaVencimiento]		AS fechaVencimiento
			  ,D.[pad_fechaPromesaPago]		AS fechaPromesaPago
			  ,D.[pad_fechaRecepcion]		AS fechaRecepcion
			  ,D.[pad_fechaFactura]			AS fechaFactura
			  ,D.[pad_ordenCompra]			AS ordenCompra
			  ,D.[pad_idEstatus]			AS idEstatus
			  ,D.[pad_estatus]				AS estatus
			  ,D.[pad_anticipo]				AS anticipo
			  ,D.[pad_anticipoAplicado]		AS anticipoAplicado
			  ,D.[pad_proveedorBloqueado]	AS proveedorBloqueado
			  ,D.[pad_ordenBloqueada]		AS ordenBloqueada 
			  ,D.[pad_diasCobro]			AS diasCobro 
			  ,D.[pad_aprobado]				AS aprobado 
			  ,D.[pad_contReprog]			AS contReprog
			  ,D.[pad_documentoPagable]		AS documentoPagable 
			  ,D.[pad_aPagar]				AS aPagar
			  ,D.[pad_nombreAgrupador]      AS nombreAgrupador
			  ,D.[pad_ordenAgrupador]       AS ordenAgrupador
			  ,D.[pad_ordenProveedor]       AS ordenProveedor
			  ,D.[pad_cuentaProveedor]      AS cuentaProveedor
			  ,D.[pad_cuentaProveedor]      AS cuentaPagadora
			  ,D.[pad_cuentaDestino]        AS cuentaDestino
              ,D.[pad_seleccionable]        AS seleccionable
			  ,D.[pad_numeroSerie]          AS numeroSerie 
              ,D.[pad_facturaProveedor]     AS facturaProveedor
			  ,D.[pad_polReferencia]     AS referencia
			  ,D.[pad_bancoPagador]		AS bancoPagador
			  ,D.[pad_agrupamiento]		AS agrupamiento
		FROM  [Pagos].[dbo].[PAG_LOTE_PAGO] M
		     ,[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
	   WHERE M.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
		 AND D.[pal_id_lote_pago] = @idPadre
		 --AND DATEDIFF (DAY,M.[pal_fecha],GETDATE()) = 0  
  
  END TRY
  
  BEGIN CATCH
	 PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_PROG_PAGOS_GUARDADA_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 --SELECT 0 --Encontro error
	 SELECT 'ERROR EN LA CONSULTA'
  END CATCH
END

go

