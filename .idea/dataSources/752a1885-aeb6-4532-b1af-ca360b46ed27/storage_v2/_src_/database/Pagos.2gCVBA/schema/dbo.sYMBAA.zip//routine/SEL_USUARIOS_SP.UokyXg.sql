-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 29/02/2016
-- Description:	Empresas 
-- =============================================
--EXECUTE [SEL_USUARIOS_SP] 1 
CREATE PROCEDURE [dbo].[SEL_USUARIOS_SP]
      @idEmpresa  int = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		SELECT U.[usu_idusuario]
			  ,U.[suc_idsucursal]
			  ,U.[dep_iddepartamento]
			  ,U.[usu_nombreusu]
			  ,U.[usu_paterno]
			  ,U.[usu_materno]
			  ,U.[usu_nombre]
			  --,U.[usu_correo]
			  --,U.[usu_contrasenia]
			  ,U.[pto_idpuesto]
			  --,U.[usu_fechaalta]
			  --,U.[usu_usualta]
			  --,U.[usu_fechamodifica]
			  --,U.[usu_usumodifica]
			  ,U.[usu_estatus]
			  ,E.[emp_idempresa]
		  FROM [ControlAplicaciones].[dbo].[cat_empresas]  E 
			   ,[ControlAplicaciones].[dbo].[cat_usuarios] U
		WHERE E.[emp_idempresa] = U.[emp_idempresa]
		  AND U.[emp_idempresa] = @idEmpresa
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_USUARIOS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 0 --Encontro error
END CATCH		     
END

go

