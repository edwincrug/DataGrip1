

-- =============================================
-- Author:		LQMA
-- Create date: 09042016
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [JOB_INSBPRO_DEPOSITOS_FIN_SP] 4,55,15
-- =============================================
-- Author:		DCG
-- Update date: 12042018
-- Description:	Se agrega (NOLOCK) a las consultas de tablas ordinarias,
-- para que no se bloquen los procesos
-- =============================================
CREATE PROCEDURE [dbo].[JOB_INSBPRO_DEPOSITOS_FIN_SP]
	
	 @emp_idempresa INT = 0,
	 @idLote nvarchar(50)= '',
	 @consCar nvarchar(50)= '',
	 @consLote nvarchar(50)= '',
	 @idBanco int = 0
	 
	
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @ipServidor    VARCHAR(100) = '';
				DECLARE @cadIpServidor VARCHAR(100)= '';
				DECLARE @nombreBase    VARCHAR(100)= '';
				DECLARE @refAutomatica VARCHAR(100)= '';
				DECLARE @nCuentaCargo  varchar(200)='';
				DECLARE @campos        VARCHAR(max)= '';
				DECLARE @tabla         VARCHAR(max)= '';
				DECLARE @condicion     VARCHAR(max)= '';
				DECLARE @consultaSaldo VARCHAR(max)= '';
				DECLARE @totalSaldo     decimal(18,5)= 0.00;
				DECLARE @select         VARCHAR(max)= '';

				SELECT @nombreBase = [nombre_base]        
					  ,@ipServidor = [ip_servidor]      
				FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] with (NOLOCK)
				WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
											FROM [ControlAplicaciones].[dbo].[cat_empresas] with (NOLOCK)
										WHERE [emp_idempresa] = @emp_idempresa)
				  AND tipo = 2
				
				set @cadIpServidor =' [' + @ipServidor + '].'
		
					IF (@ipServidor ='192.168.20.29')
					BEGIN
					set @cadIpServidor =''
					END
				
				PRINT @idLote + '-' + @consCar + '-' + @consLote
				SET @refAutomatica = @idLote + '-' + @consCar + '-' + @consLote
				
				

				SELECT     @nCuentaCargo= noCuenta FROM   referencias.dbo.Bancomer with (NOLOCK)   WHERE        (idBmer = @idBanco)
				
				--PRINT  SELECT     @nCuentaCargo= noCuenta FROM   referencias.dbo.Bancomer with (NOLOCK)   WHERE        (idBmer = @idBanco)

				DECLARE @total INT = (SELECT count(pal_id_lote_pago) FROM [dbo].[PAG_PROGRA_PAGOS_DETALLE] with (NOLOCK) WHERE pal_id_lote_pago = @idLote)	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), conscartera numeric(18, 0), iddocumento nvarchar(25), idpersona numeric(18, 0), cuentapagadora nvarchar(50), cuentabeneficiario nvarchar(50), importepagado decimal(18, 5), folioorden nvarchar(50) NULL, pagoaplicado int, ordenCompra nvarchar(80), lote int, idempresa int, saldoDocumento decimal(18, 5))
										
				INSERT INTO @VariableTabla (conscartera,iddocumento,idpersona,cuentapagadora,cuentabeneficiario,importepagado,folioorden,pagoaplicado, ordenCompra, idempresa, lote, saldoDocumento) 

				SELECT   PAG_PROGRA_PAGOS_BPRO.pbp_consCartera, PAG_PROGRA_PAGOS_DETALLE.pad_documento, PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor, PAG_PROGRA_PAGOS_DETALLE.pad_cuentaProveedor, 
                         PAG_PROGRA_PAGOS_DETALLE.pad_cuentaDestino, PAG_PROGRA_PAGOS_DETALLE.pad_saldo, PAG_PROGRA_PAGOS_DETALLE.pad_documento AS Doc2, 0 AS Expr1, 
                         PAG_PROGRA_PAGOS_BPRO.pbp_ordenCompra, PAG_LOTE_PAGO.pal_id_empresa, PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago, PAG_PROGRA_PAGOS_BPRO.pbp_saldo 
				FROM            PAG_PROGRA_PAGOS_DETALLE with (NOLOCK) INNER JOIN
										 PAG_PROGRA_PAGOS_BPRO with (NOLOCK) ON PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor = PAG_PROGRA_PAGOS_BPRO.pbp_idProveedor AND 
										 PAG_PROGRA_PAGOS_DETALLE.pad_documento = PAG_PROGRA_PAGOS_BPRO.pbp_documento INNER JOIN
										 PAG_LOTE_PAGO with (NOLOCK) ON PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = PAG_LOTE_PAGO.pal_id_lote_pago
				WHERE        (PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = @idLote) AND (PAG_PROGRA_PAGOS_DETALLE.pad_polReferencia = @refAutomatica)

				
		
				WHILE(@aux <=  @total)
						BEGIN
						
						declare @folioactual as nvarchar(80)
						declare @cuentaPagadora as nvarchar(50)
						declare @cuentaPagadoraParametro as nvarchar(50)
						declare @cuentaPagadoratabla as nvarchar(50)
						declare @cuentaBeneficiario as nvarchar(50)
						declare @varidpersona as nvarchar(50)
						declare @idempresa as int
						DECLARE @sSQL2016 nvarchar(500) = '';
						DECLARE @sSQL2017 nvarchar(500) = '';
						DECLARE @sSQL2018 nvarchar(500) = '';
						DECLARE @sSQL2018Docs nvarchar(500) = '';
						DECLARE @sSQL2017Docs nvarchar(500) = '';
						DECLARE @sSQL2016Docs nvarchar(500) = '';
						DECLARE @idDoctoPagado int = 0;
						DECLARE @idBancoPagador int = 0;
						DECLARE @saldoDocumento decimal (18,5) = 0;
						DECLARE @importePagado decimal (18,5) = 0;

						SET @cuentaPagadora = (SELECT cuentapagadora FROM @VariableTabla WHERE ID = @aux)
						SET @varidpersona = (SELECT idpersona FROM @VariableTabla WHERE ID = @aux)
						SET @idempresa = (SELECT idempresa FROM @VariableTabla WHERE ID = @aux)
						SET @cuentaBeneficiario = (SELECT cuentabeneficiario FROM @VariableTabla WHERE ID = @aux)

						--FAL02082017
						--UPDATE PARA QUE NO HAYA EL ERROR DE DIFERENCIA 0.

									
						SET @sSQL2018 = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012018 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''FAC'''

						BEGIN TRY
							exec(@sSQL2018)
						END TRY
						BEGIN CATCH
							PRINT 'ERROR EN UPDATE: @sSQL2018 '
						END CATCH

						SET @sSQL2017 = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012017 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''FAC'''
						
						BEGIN TRY
							exec(@sSQL2017)
						END TRY
						BEGIN CATCH
							PRINT 'ERROR EN UPDATE: @sSQL2017 '
						END CATCH


						SET @sSQL2016 = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012016 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''FAC'''

						BEGIN TRY
							exec(@sSQL2016)
						END TRY
						BEGIN CATCH
							PRINT 'ERROR EN UPDATE: @sSQL2016 '
						END CATCH


						SET @sSQL2016Docs = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012016 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''DOCDOC'''

						BEGIN TRY
							exec(@sSQL2016Docs)
						END TRY
						BEGIN CATCH
							PRINT 'ERROR EN UPDATE: @sSQL2016Docs '
						END CATCH

						SET @sSQL2017Docs = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012017 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''DOCDOC'''

						BEGIN TRY
							exec(@sSQL2017Docs)
						END TRY
						BEGIN CATCH
							PRINT 'ERROR EN UPDATE: @sSQL2017Docs '
						END CATCH

						SET @sSQL2018Docs = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012018 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''DOCDOC'''

						BEGIN TRY
							exec(@sSQL2018Docs)
						END TRY
						BEGIN CATCH
							PRINT 'ERROR EN UPDATE: @@sSQL2018Docs '
						END CATCH
						


						SET @idempresa = (SELECT idempresa FROM @VariableTabla WHERE ID = @aux)

						DECLARE @strSql NVARCHAR(500)=  '';
						DECLARE @strSql2 NVARCHAR(500) = '';
						
						
						SET @cuentaPagadoraParametro = @cuentaPagadora
						
						DECLARE @retval nvarchar(50) = '';   
						DECLARE @sSQL nvarchar(500)  = '';
						DECLARE @ParmDefinition nvarchar(500) = '';
						DECLARE @sSQL2 nvarchar(500) = '';
						DECLARE @conscartera numeric(18, 0);
						DECLARE @iddocumento nvarchar(25);

						SELECT @cuentaPagadoratabla = numeroCuenta, @idBancoPagador = idBanco FROM referencias.dbo.BancoCuenta with (NOLOCK) WHERE ((cuenta =  @cuentaPagadoraParametro ) AND  (idEmpresa = @emp_idempresa) AND (tipoCuenta = '1'));
						--PRINT(@cuentaPagadoraParametro)

						DECLARE @tipCuentaDestino nvarchar(50) = '';   
						DECLARE @numCuentaDestino nvarchar(50) = '';

						SET @sSQL2 = 'SELECT TOP 1 @retvalOUT = BCO_TIPCUENTA FROM ' + @cadIpServidor + '[' + @nombreBase + '].[dbo].[CON_BANCOS] with (NOLOCK) WHERE BCO_IDPERSONA = ''' + @varidpersona +'''  AND (BCO_STATUS = ''ACTIVO'')  order by BCO_CONSE'
						SET @ParmDefinition = N'@retvalOUT nvarchar(50) OUTPUT';
						EXEC sp_executesql @sSQL2, @ParmDefinition, @retvalOUT=@retval OUTPUT;

						--PRINT(@nombreBase)
						--PRINT(@ipServidor)
						--PRINT(@sSQL2)

						SET @tipCuentaDestino = @retval;

						IF @tipCuentaDestino = 'CC'
							
						BEGIN
							SET @sSQL2 = 'SELECT TOP 1 @retvalOUT = BCO_NUMCUENTA FROM ' + @cadIpServidor + '[' + @nombreBase + '].[dbo].[CON_BANCOS] WHERE BCO_IDPERSONA = ''' + @varidpersona +'''  AND (BCO_NUMCUENTA LIKE ''%' + @cuentaBeneficiario +'%'') '
							SET @ParmDefinition = N'@retvalOUT nvarchar(50) OUTPUT';
							EXEC sp_executesql @sSQL2, @ParmDefinition, @retvalOUT=@retval OUTPUT;
							PRINT (@sSQL2)
							SET @numCuentaDestino = @retval;
						END
						ELSE
						BEGIN 
							SET @sSQL2 = 'SELECT TOP 1 @retvalOUT = BCO_CLABE FROM ' + @cadIpServidor + '[' + @nombreBase + '].[dbo].[CON_BANCOS] WHERE BCO_IDPERSONA = ''' + @varidpersona +'''  AND (BCO_NUMCUENTA LIKE ''%' + @cuentaBeneficiario +'%'') '
							SET @ParmDefinition = N'@retvalOUT nvarchar(50) OUTPUT';
							EXEC sp_executesql @sSQL2, @ParmDefinition, @retvalOUT=@retval OUTPUT;
							SET @numCuentaDestino = @retval;
							PRINT (@sSQL2)
						END

						

						--SELECT @conscartera, @iddocumento FROM @VariableTabla WHERE ID = @aux
						
						SELECT @conscartera = conscartera, @iddocumento = iddocumento FROM @VariableTabla WHERE ID = @aux

						IF NOT EXISTS
							(
							SELECT 1
							FROM [cuentasxpagar].[dbo].[cxp_doctospagados] with (NOLOCK)
							WHERE dpa_lote = @idLote AND dpa_iddocumento = @iddocumento	AND dpa_conscartera = @conscartera
							)
						BEGIN
								
						INSERT INTO [cuentasxpagar].[dbo].[cxp_doctospagados](dpa_conscartera,dpa_iddocumento,dpa_idpersona,dpa_cuentapagadora,dpa_cuentabeneficiario,dpa_importepagado,dpa_folioorden,dpa_pagoaplicado, dpa_lote, dpa_idempresa)
					    
						SELECT conscartera, iddocumento, idpersona, @cuentaPagadoratabla, @numCuentaDestino, importepagado, folioorden, 0,@idLote,@idempresa FROM @VariableTabla WHERE ID = @aux

						
						--PRINT(@cuentaPagadoratabla)

						END


						SET @saldoDocumento = (SELECT saldoDocumento FROM @VariableTabla WHERE ID = @aux)
						SET @importePagado = (SELECT importepagado FROM @VariableTabla WHERE ID = @aux)

						-- Actualizo el estatus si el saldo es mayor al importe pagado

						IF (@importePagado < @saldoDocumento)

						BEGIN

							UPDATE cuentasxpagar.DBO.cxp_ordencompra SET sod_idsituacionorden = 10 WHERE oce_folioorden = @iddocumento

						END 


						IF @idBancoPagador > 0
						BEGIN 
							IF (NOT EXISTS(SELECT dpa_iddoctopagado FROM PAG_REL_DOCTOS_BANCOS with (NOLOCK) WHERE dpa_iddoctopagado = @idDoctoPagado and idBanco_Registro = @idBanco and idBanco = @idBancoPagador)) 
							BEGIN 
									SELECT @idDoctoPagado = dpa_iddoctopagado FROM [cuentasxpagar].[dbo].[cxp_doctospagados] with (NOLOCK) WHERE dpa_lote = @idLote AND dpa_iddocumento = @iddocumento	AND dpa_conscartera = @conscartera
									INSERT INTO PAG_REL_DOCTOS_BANCOS (dpa_iddoctopagado, idBanco_Registro, idBanco)
									VALUES(@idDoctoPagado, @idBanco, @idBancoPagador)

									UPDATE pagos.dbo.PAG_LOTE_PAGO SET pal_id_tipoLotePago = 1 WHERE pal_id_lote_pago = @idlote
							END 
						END 

						BEGIN TRY  -- para tener el control de los bloqueos
							--Actualizo en centralización la fecha del documento al entrar a doctos pagados
							UPDATE [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] 
							SET Fecha_Creacion = GetDate()
							WHERE Doc_Id = 67  AND Folio_Operacion = @iddocumento

							SET @aux = @aux + 1	
							--PRINT 'UPDATE CORRECTO'
						END TRY

						BEGIN CATCH
							PRINT 'ERROR EN EL UPDATE [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] '
						END CATCH
						--PRINT 'DESPUES DEL UPDATE'
				END

				--  Valido si esta en doctos pagados actualizo su estatus en bancomer
						IF EXISTS
							(
							SELECT 1
							FROM [cuentasxpagar].[dbo].[cxp_doctospagados] with (NOLOCK)
							WHERE dpa_lote = @idLote AND dpa_iddocumento = @iddocumento	AND dpa_conscartera = @conscartera
							)
						BEGIN
							--PRINT @idBanco	
							DELETE FROM [cuentasxpagar].[dbo].[cxp_doctospagados] WHERE dpa_lote = @idLote AND dpa_pagoaplicado = 3 
							update   referencias.dbo.Bancomer  SET estatus = 3	WHERE idBmer = @idBanco
							
							UPDATE [Centralizacionv2].[dbo].[DIG_EXPNODO_DOC] 
							SET Fecha_Creacion = GetDate()
							WHERE Doc_Id = 67  AND Folio_Operacion = @iddocumento

							
							
							PRINT ('Se proceso con éxito')
						END
		

END



go

