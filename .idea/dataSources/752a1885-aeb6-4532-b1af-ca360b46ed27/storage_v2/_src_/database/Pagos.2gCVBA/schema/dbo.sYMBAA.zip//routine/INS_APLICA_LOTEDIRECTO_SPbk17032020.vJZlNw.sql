



-- =============================================
-- Author:		LQMA
-- Create date: 09042016
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [INS_APLICA_LOTEDIRECTO_SPbk17032020] 5,5490,77
CREATE PROCEDURE [dbo].[INS_APLICA_LOTEDIRECTO_SPbk17032020]
	
	 @emp_idempresa INT = 0,
	 @idLote DECIMAL(18,0) = 0,
	 @idUsuario numeric(18,0)=0

	
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @ipServidor    VARCHAR(100) = '';
				DECLARE @cadIpServidor VARCHAR(100) = '';
				
				DECLARE @nombreBase    VARCHAR(100) = '';
				DECLARE @campos        VARCHAR(max) = '';
				DECLARE @tabla         VARCHAR(max) = '';
				DECLARE @condicion     VARCHAR(max) = '';
				DECLARE @consultaSaldo VARCHAR(max) = '';
				DECLARE @totalSaldo     decimal(18,5) = 0.00;
				DECLARE @select         VARCHAR(max) = '';

				SELECT @nombreBase = [nombre_base]        
					  ,@ipServidor = [ip_servidor]      
				FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
				WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
											FROM [ControlAplicaciones].[dbo].[cat_empresas]
										WHERE [emp_idempresa] = @emp_idempresa) AND tipo = 2

				set @cadIpServidor =' [' + @ipServidor + '].'
        
					IF (@ipServidor ='192.168.20.29')
					BEGIN
					set @cadIpServidor =''
					END

				PRINT @ipServidor
				PRINT @nombreBase
		
				DECLARE @total INT = (SELECT count(*) FROM [dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pal_id_lote_pago = @idLote)	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), conscartera numeric(18, 0), iddocumento nvarchar(25), idpersona numeric(18, 0), cuentapagadora nvarchar(50), cuentabeneficiario nvarchar(50), importepagado decimal(18, 5), folioorden nvarchar(50) NULL, pagoaplicado int, ordenCompra nvarchar(80) null, lote int, idempresa int, saldoDocumento decimal(18, 5), fechaaplicacion nvarchar (50))
										
				INSERT INTO @VariableTabla (conscartera,iddocumento,idpersona,cuentapagadora,cuentabeneficiario,importepagado,folioorden,pagoaplicado, ordenCompra, idempresa, lote, saldoDocumento, fechaaplicacion) 

				SELECT   PAG_PROGRA_PAGOS_BPRO.pbp_consCartera, PAG_PROGRA_PAGOS_DETALLE.pad_documento, PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor, PAG_PROGRA_PAGOS_DETALLE.pad_cuentaProveedor, 
                         PAG_PROGRA_PAGOS_DETALLE.pad_cuentaDestino, PAG_PROGRA_PAGOS_DETALLE.pad_saldo, PAG_PROGRA_PAGOS_DETALLE.pad_documento AS Doc2, 0 AS Expr1, 
                         PAG_PROGRA_PAGOS_BPRO.pbp_ordenCompra, PAG_LOTE_PAGO.pal_id_empresa, PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago, PAG_PROGRA_PAGOS_BPRO.pbp_saldo, PAG_LOTE_PAGO.pal_fechaAplicacion
				FROM            PAG_PROGRA_PAGOS_DETALLE INNER JOIN
										 PAG_PROGRA_PAGOS_BPRO ON PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor = PAG_PROGRA_PAGOS_BPRO.pbp_idProveedor AND 
										 PAG_PROGRA_PAGOS_DETALLE.pad_documento = PAG_PROGRA_PAGOS_BPRO.pbp_documento AND PAG_PROGRA_PAGOS_DETALLE.pbp_consCartera = PAG_PROGRA_PAGOS_BPRO.pbp_consCartera INNER JOIN
										 PAG_LOTE_PAGO ON PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = PAG_LOTE_PAGO.pal_id_lote_pago
				WHERE        (PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = @idLote)

				--SELECT * FROM @VariableTabla
		
				WHILE(@aux <=  @total)
						BEGIN
						
						declare @folioactual as nvarchar(80) = '';
						declare @cuentaPagadora as nvarchar(50) = '';
						declare @cuentaPagadoraParametro as nvarchar(50)= '';
						declare @cuentaPagadoratabla as nvarchar(50)= '';
						declare @cuentaBeneficiario as nvarchar(50)= '';
						declare @varidpersona as nvarchar(50)= '';
						declare @idempresa as int = 0;
						DECLARE @sSQL2016 nvarchar(500) = '';
						DECLARE @sSQL2017 nvarchar(500) = '';
						DECLARE @sSQL2018 nvarchar(500) = '';
						DECLARE @sSQL2016Docs nvarchar(500) = '';
						DECLARE @sSQL2017Docs nvarchar(500) = '';
						DECLARE @sSQL2018Docs nvarchar(500) = '';
						DECLARE @saldoDocumento decimal (18,5) = 0;
						DECLARE @importePagado decimal (18,5) = 0;
						DECLARE @FechaAplicacion VARCHAR(50) = ''

						SET @cuentaPagadora = (SELECT cuentapagadora FROM @VariableTabla WHERE ID = @aux)
						SET @varidpersona = (SELECT idpersona FROM @VariableTabla WHERE ID = @aux)
						SET @idempresa = (SELECT idempresa FROM @VariableTabla WHERE ID = @aux)
						SET @cuentaBeneficiario = (SELECT cuentabeneficiario FROM @VariableTabla WHERE ID = @aux)
						SET @FechaAplicacion = (SELECT fechaaplicacion FROM @VariableTabla WHERE ID = @aux)
						
						--FAL02082017
						--UPDATE PARA QUE NO HAYA EL ERROR DE DIFERENCIA 0.

						SET @sSQL2018 = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012018 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''FAC'''

						exec(@sSQL2018)


						SET @sSQL2017 = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012017 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''FAC'''

						exec(@sSQL2017)


						SET @sSQL2016 = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012016 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''FAC'''

						exec(@sSQL2016)

						SET @sSQL2016Docs = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012016 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''DOCDOC'''

						exec(@sSQL2016Docs)
						
						SET @sSQL2017Docs = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012017 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''DOCDOC'''

						exec(@sSQL2017Docs)

						SET @sSQL2018Docs = 'UPDATE ' + @cadIpServidor + '[' + @nombreBase + '].DBO.CON_CAR012018 SET CCP_IMPORTEMON = CCP_ABONO WHERE CCP_IDPERSONA = ''' + @varidpersona + ''' AND CCP_IMPORTEMON = 0 AND CCP_CARGO = 0 AND CCP_TIPODOCTO = ''DOCDOC'''

						exec(@sSQL2018Docs)
						
						


						SET @idempresa = (SELECT idempresa FROM @VariableTabla WHERE ID = @aux)

						DECLARE @strSql NVARCHAR(500)=  '';
						DECLARE @strSql2 NVARCHAR(500) = '';
						
						
						SET @cuentaPagadoraParametro = @cuentaPagadora
						PRINT(@cuentaPagadoraParametro)
						
						DECLARE @retval nvarchar(50) = '';   
						DECLARE @sSQL nvarchar(500)  = '';
						DECLARE @ParmDefinition nvarchar(500) = '';
						DECLARE @sSQL2 nvarchar(500) = '';
						DECLARE @conscartera numeric(18, 0);
						DECLARE @iddocumento nvarchar(25);
					
						--SET @cuentaPagadoratabla = '000000000195334667';

						SET @cuentaPagadoratabla = (SELECT numeroCuenta FROM referencias.dbo.BancoCuenta WHERE ((cuenta = @cuentaPagadoraParametro ) AND  (idEmpresa = @emp_idempresa) AND (tipoCuenta = '1')));
						PRINT(@cuentaPagadoraParametro)

						DECLARE @tipCuentaDestino nvarchar(50) = '';   
						DECLARE @numCuentaDestino nvarchar(50) = '';

						SET @sSQL2 = 'SELECT TOP 1 @retvalOUT = BCO_TIPCUENTA FROM ' + @cadIpServidor + '[' + @nombreBase + '].[dbo].[CON_BANCOS] WHERE BCO_IDPERSONA = ''' + @varidpersona +'''  AND (BCO_STATUS = ''ACTIVO'')  order by BCO_CONSE'
						SET @ParmDefinition = N'@retvalOUT nvarchar(50) OUTPUT';
						EXEC sp_executesql @sSQL2, @ParmDefinition, @retvalOUT=@retval OUTPUT;

						PRINT(@sSQL2)

						SET @tipCuentaDestino = @retval;

						IF @tipCuentaDestino = 'CC'
							
						BEGIN
							SET @sSQL2 = 'SELECT TOP 1 @retvalOUT = BCO_NUMCUENTA FROM ' + @cadIpServidor + '[' + @nombreBase + '].[dbo].[CON_BANCOS] WHERE BCO_IDPERSONA = ''' + @varidpersona +'''  AND (BCO_NUMCUENTA = ''' + @cuentaBeneficiario +''') '
							
							SET @ParmDefinition = N'@retvalOUT nvarchar(50) OUTPUT';
							EXEC sp_executesql @sSQL2, @ParmDefinition, @retvalOUT=@retval OUTPUT;
							SET @numCuentaDestino = @retval;
						END
						ELSE
						BEGIN 
							
							SET @sSQL2 = 'SELECT TOP 1 @retvalOUT = BCO_CLABE FROM ' + @cadIpServidor + '[' + @nombreBase + '].[dbo].[CON_BANCOS] WHERE BCO_IDPERSONA = ''' + @varidpersona +'''  AND (BCO_NUMCUENTA = ''' + @cuentaBeneficiario +''') '
							SET @ParmDefinition = N'@retvalOUT nvarchar(50) OUTPUT';
							EXEC sp_executesql @sSQL2, @ParmDefinition, @retvalOUT=@retval OUTPUT;
							SET @numCuentaDestino = @retval;
						END

						SELECT @conscartera, @iddocumento FROM @VariableTabla WHERE ID = @aux

						
						SELECT @conscartera = conscartera, @iddocumento = iddocumento FROM @VariableTabla WHERE ID = @aux

						IF NOT EXISTS
							(
							SELECT 1
							FROM [cuentasxpagar].[dbo].[cxp_doctospagados]
							WHERE dpa_lote = @idLote AND dpa_iddocumento = @iddocumento	AND dpa_conscartera = @conscartera
							)
						BEGIN
								
							INSERT INTO [cuentasxpagar].[dbo].[cxp_doctospagados](dpa_conscartera,dpa_iddocumento,dpa_idpersona,dpa_cuentapagadora,dpa_cuentabeneficiario,dpa_importepagado,dpa_folioorden,dpa_pagoaplicado, dpa_lote, dpa_idempresa,[dpa_fechaaplicacion])
					    
							SELECT conscartera, iddocumento, idpersona, @cuentaPagadoratabla, @numCuentaDestino, importepagado, folioorden, 0,@idLote,@idempresa,convert(date,@FechaAplicacion) FROM @VariableTabla WHERE ID = @aux

							UPDATE pagos.dbo.PAG_LOTE_PAGO SET pal_id_tipoLotePago = 2 WHERE pal_id_lote_pago = @idlote
						
						END

						SET @saldoDocumento = (SELECT saldoDocumento FROM @VariableTabla WHERE ID = @aux)
						SET @importePagado = (SELECT importepagado FROM @VariableTabla WHERE ID = @aux)

						-- Actualizo el estatus si el saldo es mayor al importe pagado

						IF (@importePagado < @saldoDocumento)

						BEGIN

							UPDATE cuentasxpagar.DBO.cxp_ordencompra SET sod_idsituacionorden = 10 WHERE oce_folioorden = @iddocumento

						END 


						SET @aux = @aux + 1	
						
						SELECT @aux
								
			END

			--  Valido si esta en doctos pagados actualizo su estatus en bancomer
						IF EXISTS
							(
							SELECT 1
							FROM [cuentasxpagar].[dbo].[cxp_doctospagados]
							WHERE dpa_lote = @idLote AND dpa_iddocumento = @iddocumento	AND dpa_conscartera = @conscartera
							)
						BEGIN
								
							DELETE FROM [cuentasxpagar].[dbo].[cxp_doctospagados] WHERE dpa_lote = @idLote AND dpa_pagoaplicado = 3

							update PAG_LOTE_PAGO  SET pal_estatus = 5	WHERE pal_id_lote_pago = @idLote
							
						
							PRINT ('Se proceso con éxito')

						END

		

END



go

