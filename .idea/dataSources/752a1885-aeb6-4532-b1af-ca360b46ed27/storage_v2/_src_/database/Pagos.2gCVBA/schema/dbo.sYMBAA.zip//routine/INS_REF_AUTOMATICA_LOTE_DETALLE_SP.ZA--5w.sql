

-- =============================================
-- Author:		FAL
-- Create date: 01062016
-- Description:	AGREGA EL DETALLE DE CADA REFERENCIA AUTOMATICA DE LOS LOTES APROVADOS.
-- =============================================

--EXECUTE [INS_REF_AUTOMATICA_LOTE_DETALLE_SP] 325,1226,3
CREATE PROCEDURE [dbo].[INS_REF_AUTOMATICA_LOTE_DETALLE_SP]

	 @idLote numeric(18,0) = 0,
	 @idProveedorPRM numeric(18,0) = 0,
	 @idReferencia numeric(18,0) = 0,
	 @numagrupamiento int 
AS
BEGIN

	
				DECLARE @total INT = (SELECT COUNT(*) FROM (SELECT pad_id
															FROM PAG_PROGRA_PAGOS_DETALLE WHERE pal_id_lote_pago = @idLote and pad_idProveedor = @idProveedorPRM and  pad_agrupamiento = @numagrupamiento) as Num)
				DECLARE @aux   INT = 1	
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), id_documento numeric(18, 0))
				INSERT INTO @VariableTabla  (id_documento)
				SELECT pad_id FROM PAG_PROGRA_PAGOS_DETALLE WHERE pal_id_lote_pago = @idLote and pad_idProveedor = @idProveedorPRM and  pad_agrupamiento = @numagrupamiento

				SELECT ID, id_documento FROM @VariableTabla

				WHILE(@aux <=  @total)
						BEGIN
									
									DECLARE @documentoActual NUMERIC (18,0)
									set @documentoActual = (SELECT TOP 1 id_documento FROM @VariableTabla WHERE ID = @aux)
									
									INSERT INTO  PAG_REFERENCIA_DOCUMENTO (pre_id_referencia, pad_id, prd_estatus)
									VALUES(@idReferencia,@documentoActual,1)

									DECLARE @referencia nvarchar(30)
									set @referencia = (SELECT TOP 1 pre_referencia FROM PAG_REFERENCIA WHERE pal_id_lote_pago = @idLote AND pad_idProveedor =  @idProveedorPRM and  pad_agrupamiento = @numagrupamiento)

									UPDATE PAG_PROGRA_PAGOS_DETALLE SET pad_polReferencia = @referencia WHERE pad_id = @documentoActual and pad_polReferencia = 'AUT'

									SET @aux = @aux + 1
						END
	
	
	SELECT @total


END


go

