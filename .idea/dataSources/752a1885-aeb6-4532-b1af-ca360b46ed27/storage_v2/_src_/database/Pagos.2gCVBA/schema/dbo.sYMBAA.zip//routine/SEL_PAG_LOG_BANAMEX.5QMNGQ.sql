-- =============================================
-- Author:		Francisco Javier Suárez Priego
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PAG_LOG_BANAMEX] 

@idLote int=0
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT lb.Id
		   ,ProfileName
		   ,ProfileDescripcion
		   ,RunID
		   ,RunDate
		   ,reverse(substring (REVERSE( sourceFileName), 0, (select case CHARINDEX('\',reverse(SourceFileName )) 
		      when 0 then LEN(SourceFileName) +1
			  else  CHARINDEX('\',reverse(SourceFileName ))
			  end))) as SourceFileName
           ,SUBSTRING (reverse(substring (REVERSE( sourceFileName), 0, (select case CHARINDEX('\',reverse(SourceFileName )) 
		      when 0 then LEN(SourceFileName) +1
			  else  CHARINDEX('\',reverse(SourceFileName ))
			  end))), 18, (select len(@idLote)))
		   ,DestinationFileName
		   ,eb.EstatusdeTransaccionBanamex
		   ,EstatusDeTransaccion
		   ,NumeroReferenciadeTransaccion
		   ,Beneficiario
		   ,MontoPago
		   ,ValueDate
		   ,RazonRechazo
		   FROM 
		   referencias.dbo.LogBanamex lb inner join 
		   referencias.dbo.CAT_EstatusTransaccionBanamex eb on lb.EstatusDeTransaccion = eb.id

		   where SUBSTRING (reverse(substring (REVERSE( sourceFileName), 0, (select case CHARINDEX('\',reverse(SourceFileName )) 
		      when 0 then LEN(SourceFileName) +1
			  else  CHARINDEX('\',reverse(SourceFileName ))
			  end))), 18, (select len(@idLote))) =@idLote
END

go

