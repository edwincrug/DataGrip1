


-- ==========================================================================================
-- Author:		
-- Create date: 08052019
-- Description:	Select a la Programacion de Pagos   
-- ==========================================================================================
--EXECUTE [SEL_PROGRAMACION_PAGOS_SPsintem] 4  
CREATE PROCEDURE [dbo].[SEL_PROGRAMACION_PAGOS_SPsintem] 
	    	      @idEmpresa numeric = 0
AS
BEGIN

	SET NOCOUNT ON;
	BEGIN TRY
	
DECLARE @pagos_origen TABLE   ( IDB INT IDENTITY(1,1)
									,pbp_documento nvarchar(100)
	                                ,pbp_idProveedor        numeric(18,0)
									,pbp_monto          decimal(18, 5)
									,pbp_saldo          decimal(18, 5)
									,ESTATUS			INT
									 primary key (IDB, pbp_documento, pbp_idProveedor)
								   )
--inserto los pagos de la cartera
INSERT INTO @pagos_origen
SELECT   B.pbp_documento,b.pbp_idProveedor,B.pbp_monto,B.pbp_saldo, 0 AS ESTATUS
FROM [dbo].[PAG_PROGRA_PAGOS_BPRO] B (NOLOCK) WHERE    [pbp_empresa] = @idEmpresa	

DECLARE @pagos_detalle TABLE   ( IDdet INT IDENTITY(1,1)
									,pad_documento nvarchar(100)
	                                ,pad_idProveedor        numeric(18,0)
									,saldo          decimal(18, 5)
								 primary key (IDdet, pad_documento, pad_idProveedor)
								   )
--inserto los pagos del detalle.

INSERT INTO @pagos_detalle	
SELECT D.pad_documento,D.pad_idProveedor,SUM (D.[pad_saldo]) as saldo 
FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D (NOLOCK)
,[Pagos].[dbo].[PAG_LOTE_PAGO]            L (NOLOCK)
WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago] AND L.pal_id_empresa = @idEmpresa
GROUP BY D.pad_documento,D.pad_idProveedor 				


UPDATE @pagos_origen SET ESTATUS = 1 FROM 
@pagos_origen L INNER JOIN 
@pagos_detalle B ON  L.pbp_documento = B.pad_documento 
and L.pbp_idProveedor = B.pad_idProveedor AND (L.pbp_saldo + B.saldo) > L.pbp_monto

DELETE FROM @pagos_origen WHERE ESTATUS = 1						

 
	
	DECLARE @diaBd int = 0
	DECLARE @diaActual int = 0
	DECLARE @diapago int = 0
	
	set @diaActual = DATEPART(dw,GETDATE())
	SELECT  @diaBd = pag_idDias  FROM PAG_REL_Dias (nolock) WHERE (idEmpresa = @idEmpresa)
	SET @diapago = @diaBd-@diaActual
	--select @diaActual, @diaBd
	
	IF (@diaActual = @diaBd)	
	BEGIN 
		UPDATE [PAG_PROGRA_PAGOS_BPRO] SET EstatusDiasPago = 1 WHERE pbp_empresa = @idEmpresa 
		--select @diaActual, @diaBd
	END
	ELSE
	BEGIN
	UPDATE [PAG_PROGRA_PAGOS_BPRO] SET EstatusDiasPago = 0 WHERE pbp_empresa = @idEmpresa 
	UPDATE [PAG_PROGRA_PAGOS_BPRO] SET EstatusDiasPago = 1 WHERE pbp_empresa = @idEmpresa AND (pbp_documento like '%-US-PE-%' or pbp_documento like '%ANT%-1%' or pbp_documento like '%ANT%')
	END 
	  
		    SELECT DISTINCT   BPRO.[pbp_polTipo]           as polTipo
					,BPRO.[pbp_polAnnio]          as annio
					,BPRO.[pbp_polMes]            as polMes
					,BPRO.[pbp_polConsecutivo]    as polConsecutivo
					,BPRO.[pbp_polMovimiento]     as polMovimiento
					,BPRO.[pbp_polFechaOperacion] as polFechaOperacion
					,BPRO.[pbp_documento]         as documento 
					,BPRO.[pbp_cuenta]            as cuenta
					,BPRO.[pbp_idProveedor]       as idProveedor
					,BPRO.[pbp_proveedor]         as proveedor
					,BPRO.[pbp_tipoDocto]         as tipoDocto
					,BPRO.[pbp_cartera]           as cartera
					,BPRO.[pbp_monto]             as monto
					,BPRO.[pbp_saldo]             as saldo
					,BPRO.[pbp_saldoPorcentaje]   as saldoPorcentaje
					,BPRO.[pbp_moneda]            as moneda
					,BPRO.[pbp_fechaVencimiento]  as fechaVencimiento
					,BPRO.[pbp_fechaPromesaPago]  as fechaPromesaPago
					--,CON_CAR012016.CCP_FECHPROMPAG AS fechaPromesaPago
					,BPRO.[pbp_fechaRecepcion]    as fechaRecepcion
					,BPRO.[pbp_fechaFactura]      as fechaFactura
					,BPRO.[pbp_ordenCompra]       as ordenCompra
					,BPRO.[pbp_estatus]           as estatus
					,BPRO.[pbp_idEstatus]         as idEstatus
					,BPRO.[pbp_anticipo]          as anticipo
					,BPRO.[pbp_anticipoAplicado]  as anticipoAplicado
					,BPRO.[pbp_proveedorBloqueado] as proveedorBloqueado
					,BPRO.[pbp_ordenBloqueada]     as ordenBloqueada
					,BPRO.[pbp_diasCobro]          as diasCobro
					,BPRO.[pbp_aprobado]           as aprobado
					,BPRO.[pbp_contReprog]         as contReprog
					,BPRO.[pbp_documentoPagable]   as documentoPagable
					,BPRO.[pbp_aPagar]             as aPagar
					,BPRO.pbp_nombreAgrupador   as nombreAgrupador
					,bpro.pbp_ordenAgrupador    as ordenAgrupador
					,BPRO.[pbp_ordenProveedor]     as ordenProveedor
					,UPPER(BPRO.[pbp_cuentaPagadora])     as cuentaPagadora
					,BPRO.[pbp_cuentaProveedor]    as cuentaProveedor
					,BPRO.[pbp_empresa]            as empresa
					,BPRO.[pbp_cuentaDestino]      as cuentaDestino
					,'seleccionable' =
						   CASE [EstatusDiasPago]
							 WHEN 1 THEN BPRO.pbp_seleccionable
							 ELSE CASE DIAS.pag_idDias
									WHEN 5 THEN BPRO.pbp_seleccionable
									ELSE CASE relTipoProv.pag_idTipoProveedor
										 WHEN 2 THEN 'True'
										 ELSE BPRO.pbp_seleccionable
										 END
									END 
						   END
					
					,BPRO.[pbp_numeroSerie]        as numeroSerie
                    ,BPRO.[pbp_facturaProveedor]   as facturaProveedor
					,BPRO.[pbp_esBanco]			   as esBanco
					,BPRO.[pbp_consCartera]		   as consCartera
					,BPRO.[pbp_convenioCIE]        as convenioCIE
					,BPRO.[pbp_autorizado]        as autorizado
					,BPRO.[pbp_cuentaDestinoArr]  as cuentaDestinoArr
					,BPRO.[EstatusDiasPago]
					,relTipoProv.pag_idTipoProveedor as tipo
					,DIAS.pag_idDias as diadePago
					
		       FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] AS BPRO (NOLOCK)
		       INNER JOIN dbo.PAG_REL_Dias DIAS (NOLOCK) ON  BPRO.pbp_empresa = DIAS.idEmpresa
			   INNER JOIN PAG_REL_tipoProveedor as relTipoProv(NOLOCK) ON BPRO.pbp_idProveedor = relTipoProv.idPersona
			   INNER JOIN @pagos_origen  AS E 
			          ON BPRO.[pbp_idProveedor]    = E.pbp_idProveedor       
                     AND BPRO.[pbp_documento]  = E.pbp_documento
				     AND BPRO.[pbp_empresa] = @idEmpresa
			   
									  
               WHERE BPRO.[pbp_idProveedor]    = E.pbp_idProveedor      
				  AND BPRO.[pbp_documento]  = E.pbp_documento
				  AND BPRO.[pbp_empresa] = @idEmpresa
				  AND BPRO.[pbp_saldo] > 0
				  AND (datediff (day,BPRO.[pbp_fechaPromesaPago],getdate()) >= 0)
				  AND ((BPRO.[pbp_fechaPromesaPago] <> '') or (BPRO.[pbp_fechaVencimiento] <> ''))

			ORDER by BPRO.[pbp_fechaPromesaPago] desc

        END TRY

	BEGIN CATCH
	     --SELECT 'ERROR EN LA CONSULTA'
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 DECLARE @Mensaje  nvarchar(max),
		 @Componente nvarchar(50) = '[SEL_PROGRAMACION_PAGOS_SP]'
		 SELECT @Mensaje = ERROR_MESSAGE()
		 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
		 SELECT 0 --Encontro error
	END CATCH
END



go

