
-- =============================================
-- Author:		LQMA
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_APROBACION_SPbak]
	 @proc_id INT = 0,  
	 @nodo INT = 0,  
	 @emp_idempresa INT = 0,
	 @idLote DECIMAL(18,0) = 0
AS
BEGIN
	
	DECLARE @idAprobador INT = 0
	DECLARE @nombreLote VARCHAR(100) = ''
	DECLARE @url VARCHAR(100) = ''
	DECLARE @solicitante NUMERIC(18,0) = 0.0
		
	SELECT @nombreLote = pal_nombre, @solicitante = pal_id_usuario FROM [dbo].[PAG_LOTE_PAGO] WHERE [pal_id_lote_pago] = @idLote

	SELECT @url = ppa_valor FROM PAG_PARAMETROS WHERE ppa_nombre = 'URL_PAGOS'
	
	SELECT TOP(1) @idAprobador = [Usuario_Autoriza1] 
	FROM [Centralizacionv2].[dbo].[DIG_PARAMETROS_PAGO]  
	WHERE [emp_idempresa] =@emp_idempresa 
	--AND [Nodo_Id] = @nodo
	--AND [Proc_Id] = @proc_id
	
	SET @url = @url + '?idLote=' + CONVERT(VARCHAR(10),@idLote) + '&idOperacion=2'
	DECLARE @descripcion VARCHAR(100) = 'Solicitud de Aprobación del lote: ' + @nombreLote
		
	EXEC [Notificacion].[dbo].[INS_APROBACION_LOTE_SP]    @idtipoproceso = @proc_id
														 ,@identificador = @idLote
														 ,@idnodo = @nodo
														 ,@descripcion = @descripcion
														 ,@estatus = 1
														 ,@linkBPRO = @url
														 ,@adjunto = NULL
														 ,@idtipoadjunto	= NULL
														 ,@solicitante = @solicitante
														 ,@aprobador	= @idAprobador

	UPDATE [dbo].[PAG_LOTE_PAGO] SET [pal_estatus] = 2 --Pendiente de aprobar
			WHERE [pal_id_lote_pago] = @idLote
	
	SELECT 0
	
	EXECUTE [INS_REF_AUTOMATICA_LOTE_SP] @idLote

END


go

