-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 01/03/2016
-- Description:	Ingreso Otros por empresa 
-- =============================================
--EXECUTE [SEL_INGRESO_OTROS_SP] 4                        --4: GAZM_Concentra
CREATE PROCEDURE [dbo].[SEL_INGRESO_OTROS_SP]
	@idLotePago numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
		SELECT [pio_caja]
			  ,[pio_cobranzaEsperada]
		  FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_OTROS] 
         WHERE [pal_id_lote_pago] = @idLotePago
        
		--SELECT 1
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_INGRESO_OTROS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 0 --Encontro error
END CATCH		     
END

go

