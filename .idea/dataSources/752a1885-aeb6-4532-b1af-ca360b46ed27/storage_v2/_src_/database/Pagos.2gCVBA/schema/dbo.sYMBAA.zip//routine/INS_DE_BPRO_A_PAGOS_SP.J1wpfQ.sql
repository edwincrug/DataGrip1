


-- ==========================================================================================
-- Author:		Fernando Alvarado Luna
-- Create date: 22042019
-- Description:	Select a la Programacion de Pagos   
-- ==========================================================================================
----EXECUTE [INS_DE_BPRO_A_PAGOS_SP] 4   
CREATE PROCEDURE [dbo].[INS_DE_BPRO_A_PAGOS_SP] 

	     @idEmpresa numeric(18,0) = null
AS
BEGIN

	--SET NOCOUNT ON;
	--BEGIN TRY	    
	  
	    ---------------------------------------------------------------
		--  Buscamos la  IP del Servidor y  la Base                  --
		---------------------------------------------------------------
		DECLARE @ipServidor    VARCHAR(100);
		DECLARE @cadIpServidor VARCHAR(100);
		DECLARE @nombreBase    VARCHAR(100);
		DECLARE @campos        VARCHAR(max);
		DECLARE @tabla         VARCHAR(max);
		DECLARE @condicion     VARCHAR(max);
		DECLARE @consultaSaldo VARCHAR(max);
		DECLARE @totalSaldo     decimal(18,5);
		DECLARE @select         VARCHAR(max);
		DECLARE @campos1		VARCHAR(max);
		DECLARE @campos2		VARCHAR(max);
		DECLARE @strCartera VARCHAR(max) = '';
		DECLARE @TOTALREGITROS INT;

		SELECT @nombreBase = [nombre_base]        
			  ,@ipServidor = [ip_servidor]      
		FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
		WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
									FROM [ControlAplicaciones].[dbo].[cat_empresas]
								WHERE [emp_idempresa] = @idEmpresa)
		  AND tipo = 2

        set @cadIpServidor =' [' + @ipServidor + '].'
        
        IF (@ipServidor ='192.168.20.29')
		BEGIN
		set @cadIpServidor =''
		END

		DECLARE @ipPagos VARCHAR(100) = (SELECT ppa_valor  FROM [dbo].[PAG_PARAMETROS] WHERE ppa_nombre = 'BASE PAGOS')

		

		
		--------------------FAL 21032017---------------------------------
       
		
		DELETE FROM PAG_PROGRA_PAGOS_BPRO WHERE (pbp_empresa = @idEmpresa)

		
		
		declare @queryBpro varchar(300) =  @cadIpServidor + '['+  @nombreBase +'].[dbo].[SP_BI_CARTERA_PAGOS] ' + cast(@idEmpresa as varchar(2))
		
		SELECT @queryBpro

		EXECUTE(@queryBpro)
		--comienza la busqueda tomando en cuenta lo de brpro ya previamente guardado

		DECLARE     @VariableTabla TABLE (ID INT IDENTITY(1,1)
										 ,polTipo	        nvarchar(50)
										 ,annio	        numeric
										 ,polMes	        numeric
										 ,polConsecutivo	numeric
										 ,polMovimiento	    numeric
										 ,polFechaOperacion	datetime
										 ,documento   nvarchar(100)
										 ,cuenta      nvarchar(50)
										 ,idProveedor numeric
										 ,proveedor   nvarchar(250)
										 ,tipoDocto	  nvarchar(50)
										 ,cartera     nvarchar(150)	
										 ,monto	      decimal(18, 5)
										 ,saldo	      decimal(18, 5)
										 ,saldoPorcentaje	decimal(18, 5)
										 ,moneda			nvarchar(2)	
										 ,fechaVencimiento	datetime
										 ,fechaPromesaPago	datetime
										 ,fechaRecepcion	datetime
										 ,fechaFactura		datetime
										 ,ordenCompra		nvarchar(30)
										 ,estatus			nvarchar(100)
										 ,idEstatus         nvarchar(3)
										 ,anticipo			decimal(18, 0)--int
										 ,anticipoAplicado	decimal(18, 0)--int
										 ,proveedorBloqueado nvarchar(5)
										 ,ordenBloqueada	nvarchar(5)	
										 ,diasCobro			decimal(3, 0)
										 ,aprobado			nvarchar(5)
										 ,contReprog		decimal(3, 0)
										 ,documentoPagable  nvarchar(10)
										 ,aPagar            int          
										 ,nombreAgrupador   nvarchar(50)
										 ,ordenAgrupador    int
										 ,ordenProveedor    int
										 ,cuentaPagadora    nvarchar(50)
										 ,cuentaProveedor   nvarchar(50)   
										 ,empresa          int
										 ,cuentaDestino    nvarchar(300)
										 ,seleccionable    nvarchar(5)
										 ,numeroSerie      varchar(20)
										 ,facturaProveedor varchar(50)
										 ,convenioCie varchar(10)
										 ,consCartera      decimal(18, 0)
										 ,esBanco		   nvarchar(5)
										 ,autorizado int
										 ,cuentaDestinoArr    nvarchar(300)
										 ,EstatusDiasPago int
										 )

		declare @queryText varchar(max) = 
'SELECT  [polTipo],[annio],[polMes],max([polConsecutivo]) [polConsecutivo],max([polMovimiento]) [polMovimiento] ' + char(13) +
'      ,max([polFechaOperacion]) [polFechaOperacion],[documento],[cuenta],[idProveedor],[proveedor],[tipoDocto]	' + char(13) +
'      ,[cartera],max([monto]) [monto],max([saldo]) [saldo],[saldoPorcentaje],[moneda],max([fechaVencimiento])	' + char(13) +						
'      ,max([fechaPromesaPago]),max([fechaRecepcion]),max([fechaFactura]),[ordenCompra],[estatus],[idEstatus]	' + char(13) +									
'      ,[anticipo],[anticipoAplicado],[proveedorBloqueado],[ordenBloqueada],[diasCobro],[aprobado],[contReprog]	' + char(13) +								
'      ,[documentoPagable],[aPagar],[nombreAgrupador],[ordenAgrupador],[ordenProveedor],[cuentaPagadora]		' + char(13) +						
'      ,[cuentaProveedor],[empresa],[cuentaDestino],[seleccionable],[numeroSerie],[facturaProveedor],[pbp_convenioCIE]' + char(13) +								
'      ,max([pbp_consCartera]) [pbp_consCartera],[esBanco],[autorizado],[cuentaDestinoArr],[EstatusDiasPago]' + char(13) +
' from ( ' + char(13) +
'SELECT Isnull(bpro.pbp_polTipo, '+char(39)+''+char(39)+')' + char(13) + 
'       AS polTipo,' + char(13) + 
'       bpro.pbp_polAnnio' + char(13) + 
'       AS annio,' + char(13) + 
'       Isnull(bpro.pbp_polMes, 0)' + char(13) + 
'       AS polMes,' + char(13) + 
'       Isnull(bpro.pbp_polConsecutivo, 0)' + char(13) + 
'       AS polConsecutivo,' + char(13) + 
'       bpro.pbp_polMovimiento' + char(13) + 
'       AS polMovimiento,' + char(13) + 
'       Isnull(bpro.pbp_polFechaOperacion,'+char(39)+'1900-01-01 00:00:00'+char(39)+')' + char(13) + 
'       AS' + char(13) + 
'       polFechaOperacion,' + char(13) + 
'       bpro.pbp_documento' + char(13) + 
'       AS documento,' + char(13) + 
'       bpro.pbp_cuenta' + char(13) + 
'       AS cuenta,' + char(13) + 
'       bpro.pbp_idProveedor' + char(13) + 
'       AS idProveedor,' + char(13) + 
'       Ltrim(Rtrim(Replace(Replace(personas.per_paterno, '+char(39)+'Ñ'+char(39)+', '+char(39)+''+char(39)+'), '+char(39)+'.'+char(39)+', '+char(39)+''+char(39)+')' + char(13) + 
'                   + '+char(39)+' '+char(39)+'' + char(13) + 
'                   + Replace(Replace(personas.per_materno, '+char(39)+'Ñ'+char(39)+', '+char(39)+''+char(39)+'), '+char(39)+'.'+char(39)+', '+char(39)+''+char(39)+')' + char(13) + 
'                   + '+char(39)+' '+char(39)+' + personas.per_nomrazon))' + char(13) + 
'       AS proveedor,' + char(13) + 
'       bpro.pbp_tipoDocto' + char(13) + 
'       AS tipoDocto,' + char(13) + 
'       bpro.pbp_cartera' + char(13) + 
'       AS cartera,' + char(13) + 
'       bpro.pbp_monto as monto,' + char(13) + 
'	    bpro.pbp_saldo as saldo,' + char(13) + 
'       0' + char(13) + 
'       AS saldoPorcentaje,' + char(13) + 
'       bpro.pbp_moneda as moneda,' + char(13) + 
'       bpro.pbp_fechaVencimiento AS fechaVencimiento,' + char(13) + 
'       ISNULL(bpro.pbp_fechaPromesaPago, bpro.pbp_fechaVencimiento)  AS fechaPromesaPago,' + char(13) + 
'       bpro.pbp_fechaRecepcion AS fechaRecepcion,' + char(13) + 
'       bpro.pbp_fechaFactura    AS fechaFactura,' + char(13) + 
'       Orden.oce_folioorden' + char(13) + 
'       AS ordenCompra,' + char(13) + 
'       Situacion.sod_nombresituacion' + char(13) + 
'       AS estatus,' + char(13) + 
'       Isnull(Orden.sod_idsituacionorden, 0)' + char(13) + 
'       AS idEstatus,' + char(13) + 
'       Orden.oce_anticipo' + char(13) + 
'       AS anticipo,' + char(13) + 
'       Orden.oce_antaplicado' + char(13) + 
'       AS anticipoAplicado,' + char(13) + 
'       CASE' + char(13) + 
'         WHEN ( Isnull((SELECT TOP 1 bpv_estatusproveedor' + char(13) + 
'                        FROM   [cuentasxpagar].[dbo].[cxp_bloqueoproveedores]' + char(13) + 
'                        WHERE  bpro.pbp_idProveedor = bpv_idproveedor' + char(13) + 
'                        ORDER  BY bpv_idbloqueo DESC), 0) ) = 1 THEN '+char(39)+'True'+char(39)+'' + char(13) + 
'         ELSE '+char(39)+'False'+char(39)+'' + char(13) + 
'       END' + char(13) + 
'       AS proveedorBloqueado,' + char(13) + 
'       CASE' + char(13) + 
'         WHEN ( Isnull((SELECT TOP 1 boc_estatusorden' + char(13) + 
'                        FROM   [cuentasxpagar].[dbo].[cxp_bloqueoordenes]' + char(13) + 
'                        WHERE  oce_folioorden = boc_folioorden' + char(13) + 
'                        ORDER  BY boc_idbloqueo DESC), 0) ) = 1 THEN '+char(39)+'True'+char(39)+'' + char(13) + 
'         ELSE '+char(39)+'False'+char(39)+'' + char(13) + 
'       END' + char(13) + 
'       AS ordenBloqueada,' + char(13) + 
'       bpro.pbp_diasCobro' + char(13) + 
'       AS diasCobro,' + char(13) + 
'       '+char(39)+'1'+char(39)+'' + char(13) + 
'       AS aprobado,' + char(13) + 
'       '+char(39)+'0'+char(39)+'' + char(13) + 
'       AS contReprog,' + char(13) + 
'       CASE' + char(13) + 
'         WHEN (SELECT TOP 1 bpv_estatusproveedor' + char(13) + 
'               FROM   [cuentasxpagar].[dbo].[cxp_bloqueoproveedores]' + char(13) + 
'               WHERE  bpro.pbp_idProveedor = bpv_idproveedor' + char(13) + 
'               ORDER  BY bpv_idbloqueo DESC) = 1 THEN '+char(39)+'False'+char(39)+'' + char(13) + 
'         ELSE' + char(13) + 
'           CASE' + char(13) + 
'             WHEN ( Isnull((SELECT TOP 1 boc_estatusorden' + char(13) + 
'                            FROM   [cuentasxpagar].[dbo].[cxp_bloqueoordenes]' + char(13) + 
'                            WHERE Orden.oce_folioorden = boc_folioorden' + char(13) + 
'                            ORDER  BY boc_idbloqueo DESC), 0) ) = 1 THEN '+char(39)+'False'+char(39)+'' + char(13) + 
'             ELSE' + char(13) + 
'               CASE' + char(13) + 
'                 WHEN (( Isnull(Orden.sod_idsituacionorden, 0) NOT IN (' + char(13) + 
'                         '+char(39)+'10'+char(39)+', '+char(39)+'15'+char(39)+', '+char(39)+'17'+char(39)+', '+char(39)+'0'+char(39)+' )' + char(13) + 
'                       ))' + char(13) + 
'               THEN '+char(39)+'False'+char(39)+'' + char(13) + 
'                 ELSE'+char(39)+'True'+char(39)+'' + char(13) + 
'               END' + char(13) + 
'           END' + char(13) + 
'       END' + char(13) + 
'       AS documentoPagable,' + char(13) + 
'       0' + char(13) + 
'       AS aPagar,' + char(13) + 
'       '+char(39)+'Z Sin Agrupar'+char(39)+'' + char(13) + 
'       AS nombreAgrupador,' + char(13) + 
'       0' + char(13) + 
'       AS ordenAgrupador,' + char(13) + 
'       0' + char(13) + 
'       AS ordenProveedor,' + char(13) + 
'       '+char(39)+'BCOEGRESOSEL'+char(39)+'' + char(13) + 
'       AS cuentaPagadora,' + char(13) + 
'       '+char(39)+'BCOEGRESOSEL'+char(39)+'' + char(13) + 
'       AS cuentaProveedor,' + char(13) + 
'       ' + cast (@idEmpresa as varchar(2)) + char(13) + 
'       AS empresa,' + char(13) + 
'       bpro.pbp_cuentaDestino as cuentaDestino,' + char(13) + 
'       CASE' + char(13) + 
'         WHEN (SELECT TOP 1 bpv_estatusproveedor' + char(13) + 
'               FROM   [cuentasxpagar].[dbo].[cxp_bloqueoproveedores]' + char(13) + 
'               WHERE  bpro.pbp_idProveedor = bpv_idproveedor' + char(13) + 
'               ORDER  BY bpv_idbloqueo DESC) = 1 THEN '+char(39)+'True'+char(39)+'' + char(13) + 
'         ELSE' + char(13) + 
'           CASE' + char(13) + 
'             WHEN ( Isnull((SELECT TOP 1 boc_estatusorden' + char(13) + 
'                            FROM   [cuentasxpagar].[dbo].[cxp_bloqueoordenes]' + char(13) + 
'                            WHERE  oce_folioorden = boc_folioorden' + char(13) + 
'                            ORDER  BY boc_idbloqueo DESC), 0) ) = 1 THEN '+char(39)+'True'+char(39)+'' + char(13) + 
'             ELSE' + char(13) + 
'               CASE' + char(13) + 
'                 WHEN ( ( Isnull(Orden.sod_idsituacionorden, 0) NOT IN' + char(13) + 
'                          ( '+char(39)+'10'+char(39)+', '+char(39)+'15'+char(39)+', '+char(39)+'17'+char(39)+', '+char(39)+'0'+char(39)+' ) )' + char(13) + 
'                        AND bpro.pbp_documento LIKE '+char(39)+'%-%-%-%-%'+char(39)+' ) THEN '+char(39)+'True'+char(39)+'' + char(13) + 
'                 ELSE' + char(13) + 
'                  '+char(39)+'False'+char(39)+'' + char(13) + 
'               END' + char(13) + 
'           END' + char(13) + 
'       END' + char(13) + 
'       AS seleccionable,' + char(13) + 
'       Isnull((SELECT TOP 1 au.anu_numeroserie' + char(13) + 
'               FROM   [cuentasxpagar].[dbo].[cxp_detalleautosnuevos] AS au' + char(13) + 
'               WHERE  au.oce_folioorden = bpro.pbp_documento COLLATE' + char(13) + 
'                                          modern_spanish_ci_as),' + char(13) + 
'       '+char(39)+'SIN NUMERO SERIE'+char(39)+') AS' + char(13) + 
'       numeroSerie,' + char(13) + 
'       CASE' + char(13) + 
'         WHEN (SELECT [folio]' + char(13) + 
'               FROM   [Centralizacionv2].[dbo].[ppro_datosfacturas]' + char(13) + 
'               WHERE  [folioorden] = bpro.pbp_documento COLLATE' + char(13) + 
'                                     modern_spanish_ci_as' + char(13) + 
'              ) <> NULL THEN (SELECT TOP 1 [folio] + '+char(39)+'-'+char(39)+' + [serie]' + char(13) + 
'                              FROM' + char(13) + 
'         [Centralizacionv2].[dbo].[ppro_datosfacturas]' + char(13) + 
'                              WHERE  [folioorden] = bpro.pbp_documento' + char(13) + 
'    COLLATE modern_spanish_ci_as)' + char(13) + 
'         ELSE Isnull((SELECT TOP 1 Substring([uuid], 25, 36)' + char(13) + 
'                      FROM   [Centralizacionv2].[dbo].[ppro_datosfacturas]' + char(13) + 
'                      WHERE  [folioorden] = bpro.pbp_documento COLLATE' + char(13) + 
'                                            modern_spanish_ci_as' + char(13) + 
'                            ), '+char(39)+'SIN FACTURA PROVEEDOR'+char(39)+')' + char(13) + 
'       END' + char(13) + 
'       AS facturaProveedor,' + char(13) + 
'      bpro.pbp_convenioCIE,' + char(13) + 
'	   bpro.pbp_consCartera AS pbp_consCartera,' + char(13) + 
'       '+char(39)+'false'+char(39)+'' + char(13) + 
'       AS esBanco,' + char(13) + 
'	   bpro.pbp_autorizado AS autorizado, '  + char(13) + 
'	   bpro.pbp_cuentaDestino AS cuentaDestinoArr, 0 as EstatusDiasPago'  + char(13) + 
'  FROM   ' + @cadIpServidor + '['+  @nombreBase +'].[dbo].[BI_CARTERA_PAGOS] as bpro' + char(13) + 
'	   INNER JOIN [GA_Corporativa].[dbo].[per_personas] as personas' + char(13) + 
'               ON bpro.pbp_idProveedor = personas.per_idpersona	' + char(13) + 
'       LEFT OUTER JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] as Orden' + char(13) + 
'                    ON bpro.pbp_documento = Orden.oce_folioorden COLLATE' + char(13) + 
' modern_spanish_ci_as' + char(13) + 
'       LEFT OUTER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] as Situacion' + char(13) + 
'                    ON Orden.sod_idsituacionorden = Situacion.sod_idsituacionorden' + char(13) + 
'  WHERE  pbp_empresa =' + cast (@idEmpresa as varchar(2)) +' AND bpro.pbp_monto>=0 ' + char(13) +
 ' ) x group by				' + char(13) +
' [polTipo],[annio],[polMes],[documento],[cuenta],[idProveedor],[proveedor],[tipoDocto],[cartera],[saldoPorcentaje],[moneda],[ordenCompra],[estatus],[idEstatus],[anticipo],[anticipoAplicado],[proveedorBloqueado],[ordenBloqueada],[diasCobro],[aprobado],[contReprog],[documentoPagable],[aPagar],[nombreAgrupador],[ordenAgrupador],[ordenProveedor],[cuentaPagadora],[cuentaProveedor],[empresa],[cuentaDestino],[seleccionable],[numeroSerie],[facturaProveedor],[pbp_convenioCIE],[esBanco],[autorizado],[cuentaDestinoArr],[EstatusDiasPago] 	' + char(13) +
'  ORDER BY Max(fechaVencimiento) DESC '
print @queryText
INSERT INTO  @VariableTabla  EXEC (@queryText);
        
		SET @totalSaldo = ( SELECT SUM (saldo) 
		                     FROM @VariableTabla) 
		UPDATE @VariableTabla 
		   SET saldoPorcentaje = saldo * 100/@totalSaldo

		UPDATE @VariableTabla 
		   SET seleccionable = 'True'
		where cuentaDestino = 'SIN CUENTA DESTINO'

		--UPDATE @VariableTabla 
		 --  SET cuentaDestino = '[' + cuentaDestino + ']'
SET @TOTALREGITROS = (SELECT   COUNT(pbp_consCartera) FROM PAG_PROGRA_PAGOS_BPRO WHERE pbp_empresa = @idEmpresa)
		 
	IF 	( @TOTALREGITROS = 0)

		BEGIN	
		  
        INSERT INTO [dbo].[PAG_PROGRA_PAGOS_BPRO]
					([pbp_polTipo]
					,[pbp_polAnnio]
					,[pbp_polMes]
					,[pbp_polConsecutivo]
					,[pbp_polMovimiento]
					,[pbp_polFechaOperacion]
					--
					,[pbp_documento]
					,[pbp_cuenta]
					,[pbp_idProveedor]
					,[pbp_proveedor]
					--
					,[pbp_tipoDocto]
					,[pbp_cartera]
					,[pbp_monto]
					,[pbp_saldo]
					,[pbp_saldoPorcentaje]
					,[pbp_moneda]
					--
					,[pbp_fechaVencimiento]
					,[pbp_fechaPromesaPago]
					,[pbp_fechaRecepcion]
					,[pbp_fechaFactura]
					--
					,[pbp_ordenCompra]
					,[pbp_estatus]
					,[pbp_idEstatus]
					--
					,[pbp_anticipo]
					,[pbp_anticipoAplicado]
					--
					,[pbp_proveedorBloqueado]
					,[pbp_ordenBloqueada]
					,[pbp_diasCobro]
					,[pbp_aprobado]
					,[pbp_contReprog]
					,[pbp_documentoPagable]
					,[pbp_aPagar]
					,[pbp_nombreAgrupador]
					,[pbp_ordenAgrupador]
					,[pbp_ordenProveedor]
					,[pbp_cuentaPagadora]
					,[pbp_cuentaProveedor]
					,[pbp_empresa]
					,[pbp_fechaCreacionRegistro]
					,[pbp_cuentaDestino]
					,[pbp_seleccionable]
					,[pbp_numeroSerie]
                    ,[pbp_facturaProveedor]
					,[pbp_convenioCIE]
					,[pbp_consCartera]
					,[pbp_esBanco]
					,[pbp_autorizado]
					,[pbp_cuentaDestinoArr]
					,[EstatusDiasPago]
					) 
		  SELECT V.polTipo         as  polTipo
				,V.annio           as  annio
				,V.polMes          as  polMes
				,V.polConsecutivo  as  polConsecutivo
				,V.polMovimiento   as  polMovimiento
				,V.polFechaOperacion as polFechaOperacion
				--
				,V.documento         as documento
				,V.cuenta            as cuenta
				,V.idProveedor       as idProveedor
				,V.proveedor         as proveedor
				--
				,V.tipoDocto         as tipoDocto
				,V.cartera           as cartera
				,V.monto             as monto
				,V.saldo             as saldo        
				,V.saldoPorcentaje   as saldoPorcentaje
				,V.moneda            as moneda
				--
				,V.fechaVencimiento  as fechaVencimiento
				,V.fechaPromesaPago  as fechaPromesaPago
				,V.fechaRecepcion    as fechaRecepcion
				,V.fechaFactura      as fechaFactura
				--
				,V.ordenCompra       as ordenCompra
				,V.estatus           as estatus
				,V.idEstatus         as idEstatus
				--
				,V.anticipo          as anticipo
				,V.anticipoAplicado  as anticipoAplicado
				,V.proveedorBloqueado  as proveedorBloqueado 
				,V.ordenBloqueada      as ordenBloqueada
				,V.diasCobro           as diasCobro
				,V.aprobado            as aprobado
				,V.contReprog          as contReprog
				,V.documentoPagable    as documentoPagable
				,V.aPagar              as aPagar
				,V.nombreAgrupador     as nombreAgrupador 
				,V.ordenAgrupador      as ordenAgrupador
				,V.ordenProveedor      as ordenProveedor
				,V.cuentaPagadora      as cuentaPagadora
				,V.cuentaProveedor     as cuentaProveedor
				,V.empresa             as empresa
				,GETDATE()             as fechaCreacionRegistro
				,V.cuentaDestino       as cuentaDestino
				,V.seleccionable       as seleccionable
				,V.numeroSerie         as numeroSerie 
                ,V.facturaProveedor    as facturaProveedor
				,V.convenioCie		   as convenioCie 
				,V.consCartera         as consCartera
				,V.esBanco			   as esBanco
				,V.autorizado		   AS autorizado
				,V.cuentaDestinoArr	   as cuentaDestinoArr
				,V.EstatusDiasPago     AS EstatusDiasPago
		 FROM  @VariableTabla AS  V

         UPDATE [PAG_PROGRA_PAGOS_BPRO] SET pbp_fechaPromesaPago = pbp_fechaVencimiento WHERE pbp_empresa = @idEmpresa AND pbp_fechaPromesaPago IS NULL
         UPDATE [PAG_PROGRA_PAGOS_BPRO] SET pbp_fechaVencimiento = '' WHERE pbp_empresa = @idEmpresa AND pbp_fechaVencimiento IS NULL 
		 UPDATE [PAG_PROGRA_PAGOS_BPRO] SET pbp_nombreAgrupador = CAT.pca_ordenVarchar + ' ' + CAT.pca_nombre, pbp_ordenAgrupador = prov.pap_orden
		 FROM PAG_PROGRA_PAGOS_BPRO AS BPRO
		 INNER JOIN PAG_AGRUPADOR_PROVEEDOR AS PROV ON BPRO.pbp_idProveedor = PROV.pap_idProveedor
		 INNER JOIN PAG_CAT_AGRUPADORES AS CAT ON PROV.pca_idAgrupador = CAT.pca_idAgrupador
		 --UPDATE [PAG_PROGRA_PAGOS_BPRO] SET EstatusDiasPago = 1 WHERE pbp_empresa = @idEmpresa AND (pbp_documento like '%-US-PE-%' or pbp_documento like '%ANT%-1%' or pbp_documento like '%ANT%')
		 
		UPDATE          PAG_PROGRA_PAGOS_BPRO
		SET pbp_idEstatus = 10, pbp_estatus = 'Documentación Completa', pbp_seleccionable = 'False'
		WHERE     (pbp_documento IN ('AU-TP-TMY-SE-PE-3','AU-TP-TMY-SE-PE-6','AU-TP-TMY-SE-PE-12'))
				 
	 
       END
       
 --       END TRY

	--BEGIN CATCH
	--     SELECT 'ERROR EN LA CONSULTA pagos'
	--	 PRINT ('Error: ' + ERROR_MESSAGE())
	--	 DECLARE @Mensaje  nvarchar(max),
	--	 @Componente nvarchar(50) = '[INS_DE_BPRO_A_PAGOS_SP]'
	--	 SELECT @Mensaje = ERROR_MESSAGE()
	--	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	--	 SELECT 0 --Encontro error
	--END CATCH


END
go

