
-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 14/03/2016
-- Description:	Select a la Programacion de Pagos   
-- ==========================================================================================
--EXECUTE [SEL_PROGRAMACION_PAGOSXVENCER_SP] 1   
CREATE PROCEDURE [dbo].[SEL_PROGRAMACION_PAGOSXVENCER_SP] 
	     @idEmpresa numeric(18,0) = null
AS
BEGIN

	SET NOCOUNT ON;
	BEGIN TRY	    
	 
		    SELECT   BPRO.[pbp_polTipo]           as polTipo
					,BPRO.[pbp_polAnnio]          as annio
					,BPRO.[pbp_polMes]            as polMes
					,BPRO.[pbp_polConsecutivo]    as polConsecutivo
					,BPRO.[pbp_polMovimiento]     as polMovimiento
					,BPRO.[pbp_polFechaOperacion] as polFechaOperacion
					,BPRO.[pbp_documento]         as documento 
					,BPRO.[pbp_cuenta]            as cuenta
					,BPRO.[pbp_idProveedor]       as idProveedor
					,BPRO.[pbp_proveedor]         as proveedor
					,BPRO.[pbp_tipoDocto]         as tipoDocto
					,BPRO.[pbp_cartera]           as cartera
					,BPRO.[pbp_monto]             as monto
					,BPRO.[pbp_saldo]             as saldo
					,BPRO.[pbp_saldoPorcentaje]   as saldoPorcentaje
					,BPRO.[pbp_moneda]            as moneda
					,BPRO.[pbp_fechaVencimiento]  as fechaVencimiento
					,BPRO.[pbp_fechaPromesaPago]  as fechaPromesaPago
					,BPRO.[pbp_fechaRecepcion]    as fechaRecepcion
					,BPRO.[pbp_fechaFactura]      as fechaFactura
					,BPRO.[pbp_ordenCompra]       as ordenCompra
					,BPRO.[pbp_estatus]           as estatus
					,BPRO.[pbp_idEstatus]         as idEstatus
					,BPRO.[pbp_anticipo]          as anticipo
					,BPRO.[pbp_anticipoAplicado]  as anticipoAplicado
					,BPRO.[pbp_proveedorBloqueado] as proveedorBloqueado
					,BPRO.[pbp_ordenBloqueada]     as ordenBloqueada
					,BPRO.[pbp_diasCobro]          as diasCobro
					,BPRO.[pbp_aprobado]           as aprobado
					,BPRO.[pbp_contReprog]         as contReprog
					,BPRO.[pbp_documentoPagable]   as documentoPagable
					,BPRO.[pbp_aPagar]             as aPagar
					,BPRO.[pbp_nombreAgrupador]    as nombreAgrupador
					,BPRO.[pbp_ordenAgrupador]     as ordenAgrupador
					,BPRO.[pbp_ordenProveedor]     as ordenProveedor
					,BPRO.[pbp_cuentaPagadora]     as cuentaPagadora
					,BPRO.[pbp_cuentaProveedor]    as cuentaProveedor
					,BPRO.[pbp_empresa]            as empresa
					,BPRO.[pbp_cuentaDestino]      as cuentaDestino
                    ,BPRO.[pbp_seleccionable]      as seleccionable
					,BPRO.[pbp_numeroSerie]        as numeroSerie
                    ,BPRO.[pbp_facturaProveedor]   as facturaProveedor
					,BPRO.[pbp_esBanco]			   as esBanco
					,BPRO.[pbp_consCartera]		as consCartera
		       FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] AS BPRO
			        ,(SELECT   B.[pbp_polTipo]           as polTipo
					          ,B.[pbp_polAnnio]          as annio
					          ,B.[pbp_polMes]            as polMes
					          ,B.[pbp_polConsecutivo]    as polConsecutivo
					          ,B.[pbp_polMovimiento]     as polMovimiento
						FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] B
                      EXCEPT
					      	 SELECT   D.[pad_polTipo]                                  as polTipo                    
									  ,CAST((ROUND(D.[pad_polAnnio],0)) AS INT)        as annio
									  ,CAST((ROUND(D.[pad_polMes],0)) AS INT)          as polMes
									  ,CAST((ROUND(D.[pad_polConsecutivo],0)) AS numeric)  as polConsecutivo
									  ,CAST((ROUND(D.[pad_polMovimiento],0)) AS numeric)   as polMovimiento 
								FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
									,[Pagos].[dbo].[PAG_LOTE_PAGO]            L
							   WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago]
								 --AND datediff (day,L.[pal_fecha],getdate()) = 0  
								 AND D.[pad_aPagar] = 1 --AND D.pad_estatus =  @idEmpresa    
						) AS E
		        WHERE BPRO.[pbp_polTipo]        = E.polTipo       
                  AND BPRO.[pbp_polAnnio]       = E.annio
			      AND BPRO.[pbp_polMes]         = E.polMes
			      AND BPRO.[pbp_polConsecutivo] = E.polConsecutivo
			      AND BPRO.[pbp_polMovimiento]  = E.polMovimiento
				  AND BPRO.[pbp_empresa] = @idEmpresa
				  AND BPRO.[pbp_saldo] > 0
				  AND ((datediff (day,BPRO.[pbp_fechaPromesaPago],getdate()) < 0) OR (BPRO.[pbp_fechaPromesaPago] = '1900-01-01 00:00:00.000'))
				order by BPRO.[pbp_fechaPromesaPago] desc

        END TRY

	BEGIN CATCH
	     --SELECT 'ERROR EN LA CONSULTA'
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 DECLARE @Mensaje  nvarchar(max),
		 @Componente nvarchar(50) = '[SEL_PROGRAMACION_PAGOS_SP]'
		 SELECT @Mensaje = ERROR_MESSAGE()
		 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
		 SELECT 0 --Encontro error
	END CATCH
END


go

