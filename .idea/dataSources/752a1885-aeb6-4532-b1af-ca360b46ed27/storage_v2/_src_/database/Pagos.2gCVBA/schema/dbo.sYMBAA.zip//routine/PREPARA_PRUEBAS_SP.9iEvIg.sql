-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 10/04/2016
-- Description:	Prepara base para pruebas
-- =============================================
--EXECUTE [PREPARA_PRUEBAS_SP] 1                      
CREATE PROCEDURE [dbo].[PREPARA_PRUEBAS_SP]
	 @idEmpresa         numeric(18,0)=0

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
        
		PRINT '--------------        INICIO                                  ------------'    
		--BORRA TODOS LOS LOTES POR EMPRESA
		PRINT '1.------------ Borra Lotes excepto Aprobados y Pagados        ------------'
		EXECUTE [Pagos].[dbo].[DEL_LOTE_DETALLE_COMPLETO_SP]  @idEmpresa,0           --Borra Todo
		--EXECUTE [DEL_LOTE_NO_APROBADO_SP]  0                              --Borra solo No Aprobados
		--EXECUTE [PROC_BORRA_LOTES_NO_APROBADOS_SP]  4                     --Borra solo los No Aprobados Ni Pagados

		--ACTRUALIZA LA CARTERA DE BPRO
		PRINT '2.------------ Actualiza la cartera de Programacion de Pagos  ------------'
		EXECUTE [PROC_ACTUALIZA_CARTERA_SP]  @idEmpresa                          

		PRINT '--------------         FIN                                    ------------'
      

END TRY

BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[PREPARA_PRUEBAS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 0 
END CATCH		     
END
go

