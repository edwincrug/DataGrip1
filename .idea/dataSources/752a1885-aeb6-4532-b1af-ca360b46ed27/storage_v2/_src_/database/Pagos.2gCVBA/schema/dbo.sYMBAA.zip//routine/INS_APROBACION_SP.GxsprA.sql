
-- =============================================
-- Author:		LQMA
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============EXECUTE [INS_APROBACION_SP] 1,8,4,16865
CREATE PROCEDURE [dbo].[INS_APROBACION_SP]
	 @proc_id INT = 0,  
	 @nodo INT = 0,  
	 @emp_idempresa INT = 0,
	 @idLote DECIMAL(18,0) = 0
AS
BEGIN
	
	DECLARE @idAprobador INT = 0
	DECLARE @nombreLote VARCHAR(100) = ''
	DECLARE @url VARCHAR(100) = ''
	DECLARE @solicitante NUMERIC(18,0) = 0.0
	DECLARE @observacion nvarchar(50) = 'SIN'
	DECLARE @cuentaoperacion nvarchar(50)
	DECLARE @idUsuarioSimultaneo int = 0
	DECLARE @descripcion VARCHAR(100) = ''
	DECLARE @totalSimultaneos int = (select count(Usuario_Autoriza1)FROM [Centralizacionv2].[dbo].[DIG_PARAMETROS_PAGO]  
	WHERE [emp_idempresa] = @emp_idempresa and Usuario_tipo = 2)

	IF @totalSimultaneos >=  1

	BEGIN

	DECLARE @traeSimultaneos TABLE (ID INT IDENTITY(1,1), idUsuario int)
				INSERT @traeSimultaneos (idUsuario)
				select Usuario_Autoriza1 FROM [Centralizacionv2].[dbo].[DIG_PARAMETROS_PAGO]  
				WHERE [emp_idempresa] = @emp_idempresa and Usuario_tipo = 2 

				DECLARE @totalRegSim INT = (SELECT COUNT(*) FROM @traeSimultaneos )
				DECLARE @auxRegSim   INT = 1
			--		SELECT * FROM @traeSimultaneos
				WHILE(@auxRegSim <=  @totalRegSim)
					BEGIN 
						set @idUsuarioSimultaneo = (select idUsuario from @traeSimultaneos where ID = @auxRegSim)
						SELECT DISTINCT TOP 1 @cuentaoperacion =  pad_bancoPagador FROM PAG_PROGRA_PAGOS_DETALLE WHERE pal_id_lote_pago = @idLote
						SELECT  @observacion = reo_descOperacion FROM PAG_RELCUENTAOPERACION where  reo_id_empresa = @emp_idempresa AND  reo_cuentaPagadora = @cuentaoperacion
 						SELECT @nombreLote = pal_nombre, @solicitante = pal_id_usuario FROM [dbo].[PAG_LOTE_PAGO] WHERE [pal_id_lote_pago] = @idLote

						SELECT @url = ppa_valor FROM PAG_PARAMETROS WHERE ppa_nombre = 'URL_PAGOS'
	
						
	
						SET @url = @url + '?idLote=' + CONVERT(VARCHAR(10),@idLote) + '&idOperacion=2'
						SET @descripcion  = 'Solicitud de Aprobación del lote: ' + @nombreLote
		
						EXEC [Notificacion].[dbo].[INS_APROBACION_LOTE_SP]    @idtipoproceso = @proc_id
																			 ,@identificador = @idLote
																			 ,@idnodo = @nodo
																			 ,@descripcion = @descripcion
																			 ,@estatus = 1
																			 ,@linkBPRO = @url
																			 ,@adjunto = NULL
																			 ,@idtipoadjunto	= NULL
																			 ,@solicitante = @solicitante
																			 ,@aprobador	= @idUsuarioSimultaneo

						UPDATE [dbo].[PAG_LOTE_PAGO] SET [pal_estatus] = 2 , pal_observacion = @observacion--Pendiente de aprobar
								WHERE [pal_id_lote_pago] = @idLote
	
						SELECT 0
	
						EXECUTE [INS_REF_AUTOMATICA_LOTE_SP] @idLote

		SET @auxRegSim = @auxRegSim + 1
	END
END

IF @totalSimultaneos =  0

	BEGIN
	SELECT DISTINCT TOP 1 @cuentaoperacion =  pad_bancoPagador FROM PAG_PROGRA_PAGOS_DETALLE WHERE pal_id_lote_pago = @idLote
	
						SELECT  @observacion = reo_descOperacion FROM PAG_RELCUENTAOPERACION where  reo_id_empresa = @emp_idempresa AND  reo_cuentaPagadora = @cuentaoperacion
 
		
						SELECT @nombreLote = pal_nombre, @solicitante = pal_id_usuario FROM [dbo].[PAG_LOTE_PAGO] WHERE [pal_id_lote_pago] = @idLote

						SELECT @url = ppa_valor FROM PAG_PARAMETROS WHERE ppa_nombre = 'URL_PAGOS'
	
						SELECT TOP(1) @idAprobador = [Usuario_Autoriza1] 
						FROM [Centralizacionv2].[dbo].[DIG_PARAMETROS_PAGO]  
						WHERE [emp_idempresa] =@emp_idempresa 
						ORDER BY Usuario_Orden_Autoriza
						--AND [Nodo_Id] = @nodo
						--AND [Proc_Id] = @proc_id
	
						SET @url = @url + '?idLote=' + CONVERT(VARCHAR(10),@idLote) + '&idOperacion=2'
						 SET @descripcion = 'Solicitud de Aprobación del lote: ' + @nombreLote
		
						EXEC [Notificacion].[dbo].[INS_APROBACION_LOTE_SP]    @idtipoproceso = @proc_id
																			 ,@identificador = @idLote
																			 ,@idnodo = @nodo
																			 ,@descripcion = @descripcion
																			 ,@estatus = 1
																			 ,@linkBPRO = @url
																			 ,@adjunto = NULL
																			 ,@idtipoadjunto	= NULL
																			 ,@solicitante = @solicitante
																			 ,@aprobador	= @idAprobador

						UPDATE [dbo].[PAG_LOTE_PAGO] SET [pal_estatus] = 2 , pal_observacion = @observacion--Pendiente de aprobar
								WHERE [pal_id_lote_pago] = @idLote
	
						SELECT 0
	
						EXECUTE [INS_REF_AUTOMATICA_LOTE_SP] @idLote
END 


END


go

