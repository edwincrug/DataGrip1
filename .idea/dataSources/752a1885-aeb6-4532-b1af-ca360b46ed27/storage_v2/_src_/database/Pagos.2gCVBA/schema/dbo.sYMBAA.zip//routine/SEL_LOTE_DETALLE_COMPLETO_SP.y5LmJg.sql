-- ====================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 15/03/2016
-- Description:	Informacion completa del lote
-- ====================================================
--EXECUTE [SEL_LOTE_DETALLE_COMPLETO_SP]  4,262                  
CREATE PROCEDURE [dbo].[SEL_LOTE_DETALLE_COMPLETO_SP]
	 @idEmpresa  numeric(18,0)=0
	 ,@idLote     numeric(18,0)=0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
 BEGIN TRAN   
        ---------------------------------------------------------------
		--  Obtenemos Los lotes inconclusos                          --
		---------------------------------------------------------------
		
             
				SELECT *
				  FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE]	
				 WHERE [pal_id_lote_pago] = @idLote
				 order by pad_saldo asc
				 PRINT '1.Detalle'

				 SELECT *
				   FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS]
				  WHERE [pal_id_lote_pago] =  @idLote
				  PRINT '2.Ingresos'

				  SELECT *
					FROM [Pagos].[dbo].[PAG_FLUJO_EGRESO_BANCOS]
				   WHERE [pal_id_lote_pago] =  @idLote
				  PRINT '3.Egresos'

				  SELECT *
					FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_OTROS]
					WHERE [pal_id_lote_pago] =  @idLote
				  PRINT '4.Otros'

				  SELECT *
					FROM [Pagos].[dbo].[PAG_TRANSFERENCIAS_BANCARIAS]
					WHERE [pal_id_lote_pago] =  @idLote
				  PRINT '5.Transferencias'

				  SELECT *
					FROM [Pagos].[dbo].[PAG_LOTE_PAGO] 
					WHERE [pal_id_lote_pago] =  @idLote
				  PRINT '6.Padre'
	  
		 
COMMIT TRAN
 	   
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_DETALLE_COMPLETO_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Error en la consulta' 
END CATCH		     
END

go

