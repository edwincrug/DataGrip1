-- ====================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 08/03/2016
-- Description:	Lotes Maestro por empresa y Usuario
-- Este SP debe ser solo por empresa
-- ====================================================
--EXECUTE [INS_PROV_BPRO_SP] 1
CREATE PROCEDURE [dbo].[INS_PROV_BPRO_SP]
	 @idEmpresa int=0
	
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
	   BEGIN 

	 


		   DECLARE     @VariableTabla TABLE (ID INT IDENTITY(1,1)
										 ,pbp_idEmpresa numeric(18,0)
										 ,pbp_idProveedor	numeric (18,0)
										 ,pbp_idBanco	    numeric (18,0)
										 --,cuentaProveedor	int
										 --,cuentaPagadora	nvarchar(50)
								 )

--------------1) CAT_PERSONAS  UN PROVEEDOR EN ESPECIFICO
			--INSERT INTO  @VariableTabla	
			--SELECT P.[per_idpersona]                                  as idpersona
			--	  ,P.[per_nomrazon]                                   as per_nomrazon  
			-- FROM [BDPersonas].[dbo].[cat_personas] P  where P.[per_idpersona] IN (2158,22)--(249083,250537,248602,8)

--------------2) INSERTO TODO 
            INSERT INTO  @VariableTabla	
			SELECT 1,P.[per_idpersona] as idpersona, 6 as idBanco
			FROM [BDPersonas].[dbo].[cat_personas] P 
			DECLARE @aux   INT = 1
			DECLARE @total INT = (SELECT count(*) FROM @VariableTabla WHERE pbp_idEmpresa = 1)

			WHILE(@aux <=  @total)

			BEGIN
			INSERT INTO [dbo].[PAG_PROVEEDOR_BANCO_PAGADOR]
					   ([pbp_idEmpresa]
					   ,[pbp_idProveedor]
					   ,[pbp_idBanco]
					   )
			  SELECT pbp_idEmpresa
			      ,pbp_idProveedor
			  --	  ,((SELECT ROUND(((3 - 1) * RAND() + 1), 0))) as idBanco
			  ,1 as idBanco
			  FROM @VariableTabla
			  WHERE ID = @aux


			  SET @aux = @aux + 1	
			END

            --INSERTO TODO MENOS LO QUE ESTA EN CAT_PROVEEDORES          
			--SELECT P.[per_idpersona]                                  as idpersona
			--      ,LTRIM(RTRIM(replace(replace(P.[per_paterno],'Ñ',''),'.','')  +' '+ replace(replace(P.[per_materno],'Ñ',''),'.','') +' '+ P.[per_nomrazon]))  as per_nomrazon 
			-- FROM [BDPersonas].[dbo].[cat_personas] P 
			--		LEFT OUTER JOIN  [Pagos].[dbo].[PAG_CAT_PROVEEDORES] C ON  C.[pcp_idProveedor] = P.[per_idpersona]  --and C.[pcp_idEmpresa] = 4 @idEmpresa  
			--		INNER JOIN  [BDPersonas].[dbo].[per_relacionroles] R ON P.[per_idpersona] = R.[per_idpersona] --AND R.[rol_idrol] NOT IN (0,18,19,20,21) 
			--		INNER JOIN  [BDPersonas].[dbo].[cat_roles] O ON R.[rol_idrol] = O.[rol_idrol]
			--EXCEPT 
			--	SELECT C.[pcp_idProveedor]      as idpersona
			--		  ,C.[pcp_nombreProveedor]  as per_nomrazon
			--	  FROM [Pagos].[dbo].[PAG_CAT_PROVEEDORES] C
			--	 WHERE C.pcp_idEmpresa = @idEmpresa

--------------   CAT_PROVEEDORES MENOS CAT_PERSONAS
    --        INSERT INTO  @VariableTabla
    --            SELECT C.[pcp_idProveedor]      as idpersona
				--	  ,C.[pcp_nombreProveedor]  as per_nomrazon
				--  FROM [Pagos].[dbo].[PAG_CAT_PROVEEDORES] C
				-- WHERE C.pcp_idEmpresa = @idEmpresa
				--EXCEPT 
				--SELECT P.[per_idpersona]                                    as idpersona
				--	  ,P.[per_nomrazon]                                     as per_nomrazon  
				-- FROM [BDPersonas].[dbo].[cat_personas] P
				--		LEFT OUTER JOIN  [Pagos].[dbo].[PAG_CAT_PROVEEDORES] C ON  C.[pcp_idProveedor] = P.[per_idpersona] AND C.[pcp_idEmpresa] = 4--@idEmpresa  
				--		INNER JOIN  [BDPersonas].[dbo].[per_relacionroles] R ON P.[per_idpersona] = R.[per_idpersona] AND R.[rol_idrol] IN (0,18,19,20,21) 
				--		INNER JOIN  [BDPersonas].[dbo].[cat_roles] O ON R.[rol_idrol] = O.[rol_idrol]
		    

		
			

-------------- UPDATE  CAT_PROVEEDORES 
    --       SELECT  [pcp_id]
				--  ,[pcp_idEmpresa]
				--  ,[pcp_idProveedor]
				--  ,[pcp_nombreProveedor]
				--  ,[pcp_cuentaPagadora]
				--  ,[pcp_claveCuentaPagadora]
				--  ,[pcp_cuentaProveedor]
			 -- FROM [Pagos].[dbo].[PAG_CAT_PROVEEDORES]
			 --WHERE [pcp_idProveedor] IN (2158,22) 
			   --AND [pcp_cuentaPagadora] IS NULL
			       --(247602,7,6)
			        --                       (249083,
											--250537,
											--248602,
											--8,
											--345,
											--4,
											--528
											--)

            --BANAMEX 3658    --1100-0020-0001-0011  --03
			--BANCOMER 1289   --1100-0020-0001-0010  --10
			
			--BANAMEX 7187    --1100-0020-0001-0011  --Z11
			--BANCOMER 1289   --1100-0020-0001-0010  --10
--NUEVA CUENTA PAGADORA
			--BANAMEX 7187    --1100-0020-0001-0011  --Z11  
    --        UPDATE [dbo].[PAG_CAT_PROVEEDORES]
			 --  SET [pcp_cuentaPagadora] = 'BANAMEX 7187'
				--  ,[pcp_claveCuentaPagadora] = '1100-0020-0001-0011'
				--  ,[pcp_cuentaProveedor] = '03'
			 --WHERE [pcp_id] <= 21810
			   --AND [pcp_cuentaPagadora] IS NULL
			   --AND [pcp_idProveedor] = 345


-------ANTERIOR
			----BANAMEX 3658    --1100-0020-0001-0011  --03  
            --UPDATE [dbo].[PAG_CAT_PROVEEDORES]
			 --  SET [pcp_cuentaPagadora] = 'BANAMEX 3658'
				--  ,[pcp_claveCuentaPagadora] = '1100-0020-0001-0011'
				--  ,[pcp_cuentaProveedor] = '03'
			 --WHERE [pcp_id] <= 21810
			   --AND [pcp_cuentaPagadora] IS NULL
			   --AND [pcp_idProveedor] = 345

            
			--BANCOMER 1289   --1100-0020-0001-0010  --10  
            --UPDATE [dbo].[PAG_CAT_PROVEEDORES]
			 --  SET [pcp_cuentaPagadora] = 'BANCOMER 1289'
				--  ,[pcp_claveCuentaPagadora] = '1100-0020-0001-0010'
				--  ,[pcp_cuentaProveedor] = '10'
			 --WHERE [pcp_id] > 21810
			     --AND [pcp_cuentaPagadora] IS NULL
			 --  AND [pcp_idProveedor] IN (2158,22)
            
			select ID ,pbp_idEmpresa,pbp_idProveedor,pbp_idBanco from  @VariableTabla --where idpersona =  183
            
			--UPDATE [dbo].[PAG_CAT_PROVEEDORES]
			--   SET [pcp_nombreProveedor] = (select top 1 per_nomrazon 
			--                                  from @VariableTabla
			--                                 where idpersona = [pcp_idProveedor])
			--where  [pcp_idProveedor] >  183

		 
	   END

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[INS_PROV_BPRO_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Error en la consulta' 
END CATCH		     
END

go

