-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 29/02/2016
-- Description:	Lotes por empresa  --Inconcluso
-- =============================================
--EXECUTE [INS_LOTE_SP] 4, 2,'Lote Nuevo'                       
CREATE PROCEDURE [dbo].[INS_LOTE_SP]
	 @idEmpresa         numeric(18,0)
	,@idUsuario         numeric(18,0)
	,@nombreLote        nvarchar(50)
    ,@estatus           smallint =1   --1: Pendiente - 2:Aprobacion Pendiente - 3: Aprobado - 4: Rechazado - 5: Pagado
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
       INSERT INTO [Pagos].[dbo].[PAG_LOTE_PAGO]
				   ([pal_id_empresa]
				   ,[pal_id_usuario]
				   ,[pal_fecha]
				   ,[pal_nombre]
				   ,[pal_estatus])
			 VALUES
				   (@idEmpresa       
				   ,@idUsuario       
				   ,getdate()        
				   ,@nombreLote           
				   ,@estatus          
				   )



END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[INS_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 0 
END CATCH		     
END

go

