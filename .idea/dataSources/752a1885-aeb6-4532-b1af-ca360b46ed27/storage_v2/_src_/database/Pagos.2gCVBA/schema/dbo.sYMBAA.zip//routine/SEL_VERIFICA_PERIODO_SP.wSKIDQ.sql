-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [dbo].[SEL_VERIFICA_PERIODO_SP] 4 , '20191001'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VERIFICA_PERIODO_SP]
	@IdEmpresa INT = 0,
	@periodoAnterior NVARCHAR(10) = ''
AS
BEGIN
	--DECLARE @IdEmpresa INT = 4,
	--		@periodoAnterior NVARCHAR(10) = '20190901'

	DECLARE @Base NVARCHAR(250),
			@SQL NVARCHAR(700);

	SELECT @Base = ppe_base_aplicacion + '.dbo.PNC_PARAMETR' FROM PAG_PARAMETROS_EMPRESAS WHERE ppe_id_empresa = @IdEmpresa


	SET @SQL = 'SELECT     CASE PAR_DESCRIP2 WHEN ''CERRADO'' THEN 0 WHEN ''ABIERTO'' THEN 1 END Status
				FROM       '+ @Base +'
				WHERE     (PAR_TIPOPARA = ''mcerrcon'') AND (PAR_IDENPARA = ''' + @periodoAnterior + ''')';

	EXEC( @SQL );

	--SELECT 0 Status;
END
go

