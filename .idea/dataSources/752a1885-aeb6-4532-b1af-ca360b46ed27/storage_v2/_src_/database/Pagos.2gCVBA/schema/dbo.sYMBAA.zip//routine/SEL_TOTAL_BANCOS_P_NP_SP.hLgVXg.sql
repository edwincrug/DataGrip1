-- ==========================================================================================
-- Author:		Fernando Alvarado Luna
-- Create date: 21082018
-- Description:	Total de SALDOS: TOTAL, PAGABLE Y NO PAGABLE
-- ==========================================================================================
--EXECUTE [SEL_TOTAL_BANCOS_P_NP_SP] 1                      
CREATE PROCEDURE [dbo].[SEL_TOTAL_BANCOS_P_NP_SP]
	@idEmpresa    decimal(18,0)
	--@idEmpresa    int
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    

DECLARE @totalapagar decimal(18,2)
DECLARE @totalpagable decimal(18,2)

SELECT   B.[pbp_polTipo] as polTipo,B.[pbp_polAnnio] as annio ,B.[pbp_polMes] as polMes, B.[pbp_polConsecutivo] as polConsecutivo, 
 B.[pbp_polMovimiento]     as polMovimiento  ,B.[pbp_saldo]	as saldo, 0 AS ESTATUS
 INTO #PAG_PROGRA_PAGOS_BPRO_TEMP
 FROM [dbo].[PAG_PROGRA_PAGOS_BPRO] B (NOLOCK) WHERE    [pbp_empresa] = @idEmpresa

SELECT   D.[pad_polTipo],CAST((ROUND(D.[pad_polAnnio],0)) AS numeric) AS pad_polAnnio ,CAST((ROUND(D.[pad_polMes],0)) AS numeric) AS pad_polMes
,CAST((ROUND(D.[pad_polConsecutivo],0)) AS numeric) AS  pad_polConsecutivo ,CAST((ROUND(D.[pad_polMovimiento],0)) AS numeric) AS pad_polMovimiento,
SUM (D.[pad_saldo]) as saldo 
INTO #PAG_PROGRA_PAGOS_DETALLE_TEMP
FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D (NOLOCK)
,[Pagos].[dbo].[PAG_LOTE_PAGO]            L (NOLOCK)
WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago] AND D.[pad_aPagar] = 1 AND L.pal_id_empresa =  @idEmpresa
GROUP BY D.[pad_polTipo], D.[pad_polAnnio],D.[pad_polMes],D.[pad_polConsecutivo],D.[pad_polMovimiento],D.[pad_saldo], D.pad_monto 							 	
HAVING SUM(D.[pad_saldo]) >= D.pad_monto

UPDATE #PAG_PROGRA_PAGOS_BPRO_TEMP SET ESTATUS = 1 FROM 
#PAG_PROGRA_PAGOS_BPRO_TEMP L INNER JOIN #PAG_PROGRA_PAGOS_DETALLE_TEMP B ON polTipo = pad_polTipo AND annio = pad_polAnnio AND polMes = pad_polMes
AND polConsecutivo = pad_polConsecutivo AND polMovimiento = pad_polMovimiento AND L.saldo = B.saldo

DELETE FROM #PAG_PROGRA_PAGOS_BPRO_TEMP WHERE ESTATUS = 1

DECLARE @pagosDetalle TABLE   ( IDB INT IDENTITY(1,1)
	                                ,polTipo        nvarchar(50)
									,annio          decimal(4, 0)
									,polMes         decimal(2, 0)
									,polConsecutivo decimal(10, 0)
									,polMovimiento  decimal(10, 0)
									,saldo          decimal(18, 5)
									 primary key (IDB, polTipo, annio, polMes,polConsecutivo, polMovimiento)
								   )	 
	INSERT INTO @pagosDetalle
	SELECT polTipo,annio,polMes,polConsecutivo,polMovimiento,saldo FROM #PAG_PROGRA_PAGOS_BPRO_TEMP		
	     --             SELECT   B.[pbp_polTipo]           as polTipo
					 --         ,B.[pbp_polAnnio]          as annio
					 --         ,B.[pbp_polMes]            as polMes
					 --         ,B.[pbp_polConsecutivo]    as polConsecutivo
					 --         ,B.[pbp_polMovimiento]     as polMovimiento
						--	  ,B.[pbp_saldo]	as saldo
						--FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] B (NOLOCK) 
						--WHERE    [pbp_empresa] = @idEmpresa
      --                EXCEPT	
						--SELECT   D.[pad_polTipo]                                    
						--		,CAST((ROUND(D.[pad_polAnnio],0)) AS numeric)       
						--		,CAST((ROUND(D.[pad_polMes],0)) AS numeric)         
						--		,CAST((ROUND(D.[pad_polConsecutivo],0)) AS numeric)  
						--		,CAST((ROUND(D.[pad_polMovimiento],0)) AS numeric)   
						--		,D.[pad_saldo] as saldo
						--FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D (NOLOCK)
						--	,[Pagos].[dbo].[PAG_LOTE_PAGO]            L (NOLOCK)
						--WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago]
						--	AND D.[pad_aPagar] = 1 
						--	AND L.pal_id_empresa =  @idEmpresa 	
						

						
	
	--SELECT count(*) FROM @pagosDetalle	
		
		
		
		DECLARE @Detalle TABLE   ( IDDet INT IDENTITY(1,1)
	                                ,documento      nvarchar(100)
									,monto          decimal(18, 5)
									,saldo         decimal(18, 5)
									,seleccionable nvarchar(10)
									
								   )	 
		INSERT INTO @Detalle					   
 
		    SELECT DISTINCT   					
					BPRO.[pbp_documento]         as documento 
					,BPRO.[pbp_monto]             as monto
					,BPRO.[pbp_saldo]             as saldo
                    ,BPRO.[pbp_seleccionable]      as seleccionable
					
		       FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] AS BPRO (NOLOCK)
					LEFT join PAG_AGRUPADOR_PROVEEDOR AS GRP on 
					BPRO.[pbp_idProveedor]        = GRP.pap_idProveedor
					LEFT JOIN PAG_CAT_AGRUPADORES AS CAGRP ON
					GRP.pca_idAgrupador = CAGRP.pca_idAgrupador
			        left join @pagosDetalle AS E on 
					BPRO.[pbp_polTipo]        = E.polTipo       
                  AND BPRO.[pbp_polAnnio]       = E.annio
			      AND BPRO.[pbp_polMes]         = E.polMes
			      AND BPRO.[pbp_polConsecutivo] = E.polConsecutivo
			      AND BPRO.[pbp_polMovimiento]  = E.polMovimiento
				 -- AND BPRO.[pbp_empresa] = @idEmpresa
									  
               WHERE BPRO.[pbp_polTipo]        = E.polTipo       
                  AND BPRO.[pbp_polAnnio]       = E.annio
			      AND BPRO.[pbp_polMes]         = E.polMes
			      AND BPRO.[pbp_polConsecutivo] = E.polConsecutivo
			      AND BPRO.[pbp_polMovimiento]  = E.polMovimiento
				  AND BPRO.[pbp_empresa] = @idEmpresa
				  AND BPRO.[pbp_saldo] > 0
				  AND (datediff (day,BPRO.[pbp_fechaPromesaPago],getdate()) >= 0)
				  AND ((BPRO.[pbp_fechaPromesaPago] <> '') or (BPRO.[pbp_fechaVencimiento] <> ''))
				
				
			SELECT @totalapagar = (SUM (saldo)) FROM @Detalle  
			SELECT @totalpagable = SUM (saldo) FROM @Detalle WHERE  seleccionable ='False'
				
			
			SELECT 'Cuenta' as cuentaPagadora, @totalapagar as sumaSaldo, @totalpagable as sumaSaldoPagable, (@totalapagar - @totalpagable) sumaSaldoNoPagable, 0.00 as sumaSaldoMenosLotes

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_TOTAL_BANCOS_P_NP_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 0 --Encontro error
END CATCH		     
END

go

