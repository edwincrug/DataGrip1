


-- ====================================================
-- Author:		Fernando Alvarado Luna
-- Create date: 22/11/2016
-- Description:	Lotes Maestro por empresa y Usuario
-- Este SP debe ser solo por empresa
-- ====================================================
--EXECUTE [SEL_TRANSFERENCIASXLOTE] 78
CREATE PROCEDURE [dbo].[SEL_TRANSFERENCIASXLOTE]
	 @idLote int =0

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
	   --LQMA 31032016 se cambio para que traiga siempre por empresa
	  
	       SELECT        PAG_TRANSFERENCIAS_BANCARIAS.ptb_id, PAG_TRANSFERENCIAS_BANCARIAS.pal_id_lote_pago, PAG_TRANSFERENCIAS_BANCARIAS.ptb_id_cuenta_origen, 
                         PAG_TRANSFERENCIAS_BANCARIAS.ptb_id_cuenta_destino, PAG_TRANSFERENCIAS_BANCARIAS.ptb_importe, PAG_TRANSFERENCIAS_BANCARIAS.ptb_estatus, PAG_LOTE_PAGO.pal_id_empresa, 
                         PAG_LOTE_PAGO.pal_id_usuario
			FROM            PAG_TRANSFERENCIAS_BANCARIAS INNER JOIN
                         PAG_LOTE_PAGO ON PAG_TRANSFERENCIAS_BANCARIAS.pal_id_lote_pago = PAG_LOTE_PAGO.pal_id_lote_pago
WHERE PAG_TRANSFERENCIAS_BANCARIAS.ptb_id = @idLote


END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END



go

