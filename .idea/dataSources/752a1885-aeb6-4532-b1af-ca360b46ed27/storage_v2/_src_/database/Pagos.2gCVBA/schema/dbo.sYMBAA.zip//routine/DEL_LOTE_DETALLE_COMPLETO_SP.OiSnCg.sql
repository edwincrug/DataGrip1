-- ====================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 31/03/2016
-- Description:	Borra informacion completa del lote
-- ====================================================
--EXECUTE [DEL_LOTE_DETALLE_COMPLETO_SP]  5,0          --0:Borra todo            
CREATE PROCEDURE [dbo].[DEL_LOTE_DETALLE_COMPLETO_SP]
	 @idEmpresa  numeric(18,0)=0
	 ,@idLote     numeric(18,0)=0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
 BEGIN TRAN   
        ---------------------------------------------------------------
		--  Obtenemos Los lotes inconclusos                          --
		---------------------------------------------------------------
		--IF(@idLote <> 0)
  --       BEGIN  
  --              PRINT '**********BORRA SOLO EL LOTE**********'  
		--		--SELECT *
		--		DELETE
		--		  FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE]	
		--		 WHERE [pal_id_lote_pago] = @idLote
		--		 PRINT '1.Borra Lote en Detalle'

		--		 --SELECT *
		--		 DELETE
		--		   FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS]
		--		  WHERE [pal_id_lote_pago] =  @idLote
		--		  PRINT '2.Borra Lote en Ingresos'

		--		  --SELECT *
		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_FLUJO_EGRESO_BANCOS]
		--		   WHERE [pal_id_lote_pago] =  @idLote
		--		  PRINT '3.Borra Lote en Egresos'

		--		  --SELECT *
		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_OTROS]
		--			WHERE [pal_id_lote_pago] =  @idLote
		--		  PRINT '4.Borra Lote en Otros'

		--		  --SELECT *
		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_TRANSFERENCIAS_BANCARIAS]
		--			WHERE [pal_id_lote_pago] =  @idLote
		--		  PRINT '5.Borra Lote en Transferencias'

		--		  --SELECT *
		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_LOTE_PAGO] 
		--			WHERE [pal_id_lote_pago] =  @idLote
		--		  PRINT '6.Borra Lote en Lote Padre'

		--		  --SELECT *
		--		  DELETE
		--			  FROM [Pagos].[dbo].[PAG_TABLA_PASO_POLIZAS]
		--			  WHERE [pal_id_lote_pago] =  @idLote
		--		  PRINT '7.Borra Tabla de Paso en Lote Padre'

  --          END
	 --   ELSE
		--	BEGIN
		--	    PRINT '**********BORRA TODO**********'
		--	    --SELECT *
		--		DELETE
		--		  FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE]	
		--		 WHERE [pal_id_lote_pago] > 0
		--		 PRINT '1.Borra Todo en Detalle'

		--		 --SELECT *
		--		 DELETE
		--		   FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS]
		--		  WHERE [pal_id_lote_pago] > 0
		--		  PRINT '2.Borra Todo en Ingresos'

		--		  --SELECT *
		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_FLUJO_EGRESO_BANCOS]
		--		   WHERE [pal_id_lote_pago] > 0
		--		  PRINT '3.Borra Todo en Egresos'

		--		  --SELECT *
		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_OTROS]
		--			WHERE [pal_id_lote_pago] > 0
		--		  PRINT '4.Borra Todo en Otros'

		--		  --SELECT *
		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_TRANSFERENCIAS_BANCARIAS]
		--			WHERE [pal_id_lote_pago] > 0
		--		  PRINT '5.Borra Todo en Transferencias'

		--		  --SELECT *
		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_LOTE_PAGO] 
		--			WHERE [pal_id_lote_pago] > 0
		--		  PRINT '6.Borra Todo en Lote Padre'

		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_REFERENCIA] 
		--		  PRINT 'Referencias'

		--		  DELETE
		--			FROM [Pagos].[dbo].[PAG_REFERENCIA_DOCUMENTO] 
		--		  PRINT 'Detalle Referencias'

		--		  --SELECT *
		--		  DELETE
		--			  FROM [Pagos].[dbo].[PAG_TABLA_PASO_POLIZAS]
		--			  WHERE [pal_id_lote_pago] =  @idLote
				  select '7.Borra Todo en Tabla de Paso'
	    --END
		 
COMMIT TRAN
 	   
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[DEL_LOTE_DETALLE_COMPLETO_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END

go

