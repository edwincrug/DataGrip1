

-- =============================================
-- Author:		Fernando Alvarado Luna
-- Create date: 04/03/2019
-- Description:	Lotes por empresa  --
-- =============================================
--  --EXECUTE [BUSCA_PAGOS_MAL_APLICADOS]                  
CREATE PROCEDURE [dbo].[BUSCA_PAGOS_MAL_APLICADOS]
	
AS
BEGIN
--Esta comentado por si se desea hacer transaccional
--SET NOCOUNT ON;
--BEGIN TRY	

DECLARE  @lote INT 
DECLARE @documento VARCHAR(100)
DECLARE @saldo NUMERIC (18,6)
DECLARE @saldoAplicado NUMERIC (18,6)
DECLARE @consecutivoCartera numeric (18,0)
DECLARE @consecutivoPoliza numeric (18,0)
DECLARE @mesPoliza int
DECLARE @empresa numeric (18,0)
DECLARE @fecha datetime
DECLARE @VariableTablaResultado TABLE (ID INT IDENTITY(1,1), loteResultado int, empresa int, fecha datetime, consecutivoCartera numeric(18,0), 
										documentoResultado varchar(100), saldoDetalle numeric (18,6),
										saldoDoctos numeric (18,6), diferencia numeric (18,6), consecutivoPoliza numeric (18,0), mesPoliza int)

DECLARE @totalBusqueda INT = (SELECT count(pad_documento) 
				FROM (select detalle.pal_id_lote_pago,detalle.pad_documento, detalle.pad_saldo
					FROM Pagos.DBO.PAG_PROGRA_PAGOS_DETALLE detalle
					INNER JOIN Pagos.dbo.PAG_LOTE_PAGO pago on detalle.pal_id_lote_pago = pago.pal_id_lote_pago
					where pago.pal_estatus >= 4  and  pago.pal_fecha BETWEEN '01/03/2019 00:00:000' AND '31/03/2019 23:59:59'
				) AS NUM)

				--SELECT @totalBusqueda
			
				DECLARE @auxBusqueda   INT = 1
				DECLARE @VariableBusquedaTabla TABLE (ID INT IDENTITY(1,1), pal_id_lote_pago int,  pal_id_empresa numeric(18,0), pal_fecha datetime, pad_documento varchar(100), pad_saldo numeric (18,6), pbp_consCartera numeric (18,0))
				
				INSERT INTO @VariableBusquedaTabla (pal_id_lote_pago, pal_id_empresa, pal_fecha, pad_documento,pad_saldo, pbp_consCartera) 
				
					select detalle.pal_id_lote_pago, pago.pal_id_empresa, pago.pal_fecha, detalle.pad_documento, detalle.pad_saldo, detalle.pbp_consCartera
					FROM Pagos.DBO.PAG_PROGRA_PAGOS_DETALLE detalle
					INNER JOIN Pagos.dbo.PAG_LOTE_PAGO pago on detalle.pal_id_lote_pago = pago.pal_id_lote_pago
					where pago.pal_estatus >= 4  and  pago.pal_fecha BETWEEN '01/03/2019 00:00:000' AND '31/03/2019 23:59:59'
			
			WHILE(@auxBusqueda <=  @totalBusqueda)
				BEGIN
				
				--separo la referncia.
				
					SELECT @lote= pal_id_lote_pago, @empresa = pal_id_empresa ,@fecha = pal_fecha, @consecutivoCartera = pbp_consCartera,  @documento = pad_documento, @saldo = pad_saldo, @consecutivoCartera = pbp_consCartera  FROM @VariableBusquedaTabla WHERE ID = @auxBusqueda
					
					
				
				IF ( EXISTS(SELECT  [dpa_iddoctopagado]
							  ,[dpa_conscartera]
							  ,[dpa_iddocumento]
							  ,[dpa_idpersona]
							  ,[dpa_cuentapagadora]
							  ,[dpa_cuentabeneficiario]
							  ,[dpa_importepagado]
							  ,[dpa_folioorden]
							  ,[dpa_pagoaplicado]
							  ,[dpa_lote]
							  ,[dpa_idempresa]
							  ,[dpa_fechaaplicacion]
							  ,[dpa_conscarapl]
							  ,[dpa_mes]
							  ,[dpa_conveniocie]
						  FROM [cuentasxpagar].[dbo].[cxp_doctospagados]
						  WHERE [dpa_lote] = @lote AND [dpa_iddocumento] = @documento AND [dpa_conscartera] = @consecutivoCartera))
				
				begin
						--select @referencia,@cuenta,@importe
						SELECT @saldoAplicado = [dpa_importepagado], @consecutivoPoliza = [dpa_conscarapl],  @mesPoliza = [dpa_mes]
  					    FROM [cuentasxpagar].[dbo].[cxp_doctospagados]
						WHERE [dpa_lote] = @lote AND [dpa_iddocumento] = @documento AND [dpa_conscartera] = @consecutivoCartera
						
						INSERT INTO @VariableTablaResultado (loteResultado,	empresa, fecha, consecutivoCartera, documentoResultado, saldoDetalle,saldoDoctos,diferencia,consecutivoPoliza , mesPoliza)
						SELECT @lote,@empresa,@fecha, @consecutivoCartera, @documento,@saldo,@saldoAplicado,@saldoAplicado-@saldo, @consecutivoPoliza, @mesPoliza
						
						IF (@saldoAplicado-@saldo <> 0)
							BEGIN
							
							--IF (@consecutivoPoliza IS NULL)
							--BEGIN
							
							SELECT @lote, @documento, @consecutivoCartera, @saldo, @saldoAplicado
							--UPDATE cxp_doctospagados
							--SET dpa_importepagado = @saldo
							--FROM [cuentasxpagar].[dbo].[cxp_doctospagados]
							--WHERE [dpa_lote] = @lote AND [dpa_iddocumento] = @documento AND [dpa_conscartera] = @consecutivoCartera
							
							--END
							
							
						END
						
				END 
	
				SET @auxBusqueda = @auxBusqueda + 1	
			END
			
			
			SELECT * FROM @VariableTablaResultado WHERE diferencia <> 0	
			
			SELECT DISTINCT loteResultado FROM @VariableTablaResultado WHERE diferencia <> 0 	
				
--Esta comentado por si se desea hacer transaccional	
	
--END TRY
--BEGIN CATCH
--     PRINT ('Error: ' + ERROR_MESSAGE())
--	 DECLARE @Mensaje  nvarchar(max),
--	 @Componente nvarchar(50) = '[INS_DOCTOS_BANCOMER_SP]'
--	 SELECT @Mensaje = ERROR_MESSAGE()
--	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
--	 SELECT 0 
--END CATCH	
	     
END



go

