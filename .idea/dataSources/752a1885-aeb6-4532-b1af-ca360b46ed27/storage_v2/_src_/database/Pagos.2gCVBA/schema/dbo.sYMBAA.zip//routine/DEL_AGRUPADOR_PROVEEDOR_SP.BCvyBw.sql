-- =================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 01/02/2016
-- Description:	Borra informacion de PAG_AGRUPADOR_PROVEEDOR
-- =================================================================
--EXECUTE [DEL_AGRUPADOR_PROVEEDOR_SP]  4        
CREATE PROCEDURE [dbo].[DEL_AGRUPADOR_PROVEEDOR_SP]
     @idEmpresa   NUMERIC(18,0) = 0

AS
BEGIN
	
	SET NOCOUNT ON;
	
	BEGIN TRY	
			 BEGIN TRAN
				DELETE
				  FROM [Pagos].[dbo].[PAG_AGRUPADOR_PROVEEDOR] 
				 WHERE [pca_idAgrupador] IN ( SELECT C.[pca_idAgrupador]
												 FROM [Pagos].[dbo].[PAG_CAT_AGRUPADORES]  C
												WHERE C.[pca_idEmpresa] = @idEmpresa)
				SELECT 1								 
	         COMMIT TRAN;
    END TRY

	BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = '[DEL_AGRUPADOR_PROVEEDOR_SP]'
		SELECT @Mensaje = ERROR_MESSAGE()
		EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
		SELECT 0
	END CATCH
   
END
go

