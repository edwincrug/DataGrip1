-- ====================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 08/03/2016
-- Description:	Lotes Maestro por empresa y Usuario
-- Este SP debe ser solo por empresa
-- ====================================================
--EXECUTE [SEL_LOTE_SP] 4,0,0,0
CREATE PROCEDURE [dbo].[SEL_LOTE_SP]
	 @idEmpresa numeric(18,0)=0
	,@idUsuario numeric(18,0)=0
	,@borraLotes int=1  --Cuando venga en 0 borrara lotes que no tengan detalle
	,@idLote    numeric(18,0)=0 
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
	   --UPDATE PAG_PROGRA_PAGOS_DETALLE SET pad_saldo = pad_monto
	   --WHERE        (pal_id_lote_pago = @idLote)		
	   --LQMA 31032016 se cambio para que traiga siempre por empresa
	   IF(@idLote <> 0)
	   BEGIN 
		    SELECT   L.[pal_id_lote_pago]    as idLotePago
					,L.[pal_id_empresa]      as idEmpresa
					,L.[pal_id_usuario]      as idUsuario
					,L.[pal_fecha]           as fecha
					,L.[pal_nombre]          as nombre
					,L.[pal_estatus]         as estatus
					,SUM(D.[pad_saldo])      as totalPagar
					,L.[pal_esAplicacionDirecta]         as pal_esAplicacionDirecta
			  FROM  [Pagos].[dbo].[PAG_LOTE_PAGO] L
				    ,[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
			 WHERE L.[pal_id_lote_pago] = @idLote		
         GROUP BY L.[pal_id_lote_pago],L.[pal_id_empresa],L.[pal_id_usuario],L.[pal_fecha],L.[pal_nombre],L.[pal_estatus],L.[pal_esAplicacionDirecta]
       END
	   ELSE
	   BEGIN
	        SELECT   L.[pal_id_lote_pago]    as idLotePago
					,L.[pal_id_empresa]      as idEmpresa
					,L.[pal_id_usuario]      as idUsuario
					,L.[pal_fecha]           as fecha
					,L.[pal_nombre]          as nombre
					,L.[pal_estatus]         as estatus
					,SUM(D.[pad_saldo])      as totalPagar
					,L.[pal_esAplicacionDirecta]         as pal_esAplicacionDirecta
			  FROM  [Pagos].[dbo].[PAG_LOTE_PAGO] L
				   ,[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
			 WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
			   AND L.[pal_id_empresa] = @idEmpresa
			   --AND L.[pal_id_lote_pago] =@idLote
			   AND DATEDIFF (DAY,L.[pal_fecha],GETDATE()) = 0  
			   AND D.[pad_aPagar]	= 1
             GROUP BY L.[pal_id_lote_pago],L.[pal_id_empresa],L.[pal_id_usuario],L.[pal_fecha],L.[pal_nombre],L.[pal_estatus],L.[pal_esAplicacionDirecta]
	   END

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END

go

