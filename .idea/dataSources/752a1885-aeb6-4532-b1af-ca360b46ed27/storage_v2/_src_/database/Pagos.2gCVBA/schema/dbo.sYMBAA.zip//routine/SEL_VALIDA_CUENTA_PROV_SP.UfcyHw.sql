
-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez
-- Create date: 03/08/2018
-- Description:	validacion de si existe una cuenta con otro usuario
--              --474 --24401
-- ==========================================================================================
-- EXECUTE [dbo].[SEL_VALIDA_CUENTA_PROV_SP] @ctaBancaria='0147724659',@convenio='', @idProveedor = 352601, @idEmpresa=14   
CREATE PROCEDURE [dbo].[SEL_VALIDA_CUENTA_PROV_SP]
      @ctaBancaria    VARCHAR(25)
	 ,@convenio       VARCHAR(10)
	 ,@idProveedor    INT
	 ,@idEmpresa      INT
AS
BEGIN
	BEGIN TRY
	SET NOCOUNT ON;

    DECLARE @aux               INT = 1
	DECLARE @max               INT = 0
	DECLARE @idEmpresaBusca    INT = 0
	DECLARE @idSucursal        INT = 0
	DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
	DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @nomEmpresa        NVARCHAR(100)=NULL
	DECLARE @ipServidor        NVARCHAR(100)=NULL
	DECLARE @cadIpServidor     NVARCHAR(100)=NULL
	DECLARE @consulta          NVARCHAR(MAX)=''
	DECLARE @ipServer		   NVARCHAR(10)
	
	DECLARE @existeCuenta TABLE  (  IDB INT IDENTITY(1,1),
								    idEmpresa         int
								   ,nombreEmpresa     nvarchar(100)
								   ,idProveedor       int 
								   ,BancoInicio     nvarchar(100)
								   ,BancoPersona     nvarchar(100)
								  )     

   
    ------------------------------------------------------------
	-- BUSCAMOS EN TODAS LAS CONCENTRADORAS
	------------------------------------------------------------	
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
	                        idEmpresa         int
							,nombreEmpresa     nvarchar(100)
							,nombreSucursal    nvarchar(100)
							,nomBaseConcentra  nvarchar(50)
							,nomBaseMatriz     nvarchar(50)
							,ipServidor        nvarchar(20)
							,idSucursal        int 
							)     
							
	 INSERT INTO @Bases
            SELECT B.[emp_idempresa]
			      ,A.[emp_nombre]
			      ,B.[nombre_sucursal]
				  ,B.[nombre_base]
				  ,B.[nombre_base_matriz]
				  ,B.[ip_servidor]
				  ,B.[sucursal_matriz]
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
			       INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON A.[emp_idempresa]= B.[emp_idempresa]
			WHERE B.[catsuc_nombrecto] = 'CONCENTRA'
			  --AND B.[emp_idempresa] <> @idEmpresa
			   SELECT @nomBaseConcentra=B.[nombre_base]
				  
				  ,@cadIpServidor=B.[ip_servidor]
				  
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
			       INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON A.[emp_idempresa]= B.[emp_idempresa]
			WHERE B.[catsuc_nombrecto] = 'CONCENTRA'
			AND B.[emp_idempresa] =@idEmpresa
     --SELECT * FROM @Bases

		SET @consulta = ' SELECT  @NombreBanco=PAR_DESCRIP1         
								FROM ['+ @cadIpServidor +'].'+ @nomBaseConcentra +'.DBO.CON_BANCOS b ' + 
								'inner join ['+ @cadIpServidor +'].'+ @nomBaseConcentra +'.DBO.PNC_PARAMETR p on p.PAR_TIPOPARA=''BA'' and b.BCO_BANCO=p.PAR_IDENPARA' + 
                            ' WHERE BCO_NUMCUENTA = ' + ''''+ @ctaBancaria + '''' + 
  							   ' AND BCO_CONVENIOCIE=' + ''''+ @convenio + '''' + 
							   ' AND BCO_IDPERSONA = ' + cast (@idProveedor as varchar(20)) 
DECLARE @NombreBanco nvarchar(250);
--*select  @nomBaseConcentra,@ctaBancaria,@convenio, cast (@idProveedor as varchar(20)) 

print @consulta
EXEC sp_executesql @consulta, N'@NombreBanco nvarchar(250) OUTPUT', @NombreBanco OUTPUT;
print @NombreBanco
	 ------------------------------------------------------------
	 -- RECORREMOS LAS CONCENTRADORAS PARA BUSCAR EL PROVEEDOR
	 ------------------------------------------------------------
	 SET @max = (SELECT MAX(IDB) FROM @Bases)
	 WHILE(@aux <= @max)
	 BEGIN
         --SELECT @aux
		 SELECT  @idEmpresaBusca   = DB.idEmpresa 
		        ,@nomEmpresa       = DB.nombreEmpresa
				,@nomBaseConcentra = DB.nomBaseConcentra
				,@nomBaseMatriz    = DB.nomBaseMatriz
				,@idSucursal       = DB.idSucursal
				,@ipServidor       = DB.ipServidor
		   FROM @Bases AS DB 
		  WHERE DB.IDB = @aux 

		  SET @cadIpServidor = '['+ @ipServidor  +'].'
		  
		  SELECT @ipServer = local_net_address
		  FROM sys.dm_exec_connections
          WHERE Session_id = @@SPID


		IF (@ipServidor = @ipServer)
		BEGIN
		set @cadIpServidor =''
		END

		  --SELECT @cadIpServidor
		  --select idempresa,empresa from (
		  --select 1 idempresa,'2mpresatal' empresa,COUNT(*) cuenta from GAZM_Aeropuerto.DBO.PNC_PARAMETR p 
		  --inner join GAZM_Aeropuerto.DBO.CON_BANCOS b on  b.BCO_BANCO=p.PAR_IDENPARA where p.PAR_TIPOPARA='BA'  
    --                         and BCO_NUMCUENTA = '0147724659') x
				--			 where cuenta=0
			--	if(@idEmpresaBusca=@idEmpresa)
			--	begin
			--SET @consulta = '   select idempresa,empresa,0,'''+ @ctaBancaria + ''','''' from (
			--					select ' + cast (@idEmpresaBusca as varchar(20)) +' idempresa ,' +''''+ @nomEmpresa +'''' + ' empresa,COUNT(*) cuenta
			--					FROM '+ @cadIpServidor + @nomBaseConcentra +'.DBO.PNC_PARAMETR p 
			--					 inner join '+ @cadIpServidor + @nomBaseConcentra +'.DBO.CON_BANCOS b on b.BCO_BANCO=p.PAR_IDENPARA where p.PAR_TIPOPARA=''BA''  ' + 
   --                         ' and BCO_NUMCUENTA = ' + ''''+ @ctaBancaria + ''') x
			--				 where cuenta=0'  
  							  
                            
			--				--' WHERE BCO_IDPERSONA = ' + cast (@idProveedor as varchar(20)) 
						
							
   --       PRINT @consulta
		 -- INSERT INTO @existeCuenta
		 --        EXECUTE (@consulta);				 
  	--				End		    

			SET @consulta = ' SELECT  ' + cast (@idEmpresaBusca as varchar(20)) +' ,' +''''+ @nomEmpresa +'''' + '          
									 ,BCO_IDPERSONA
									 ,'''+@NombreBanco+'''
									 ,p.PAR_DESCRIP1
								FROM '+ @cadIpServidor + @nomBaseConcentra +'.DBO.CON_BANCOS 
								 b left join '+ @cadIpServidor + @nomBaseConcentra +'.DBO.PNC_PARAMETR p on p.PAR_TIPOPARA=''BA'' and b.BCO_BANCO=p.PAR_IDENPARA ' + 
                            ' WHERE BCO_NUMCUENTA = ' + ''''+ @ctaBancaria + '''' + 
  							   ' AND BCO_CONVENIOCIE=' + ''''+ @convenio + '''' + 
							   ' AND BCO_IDPERSONA <> ' + cast (@idProveedor as varchar(20)) 
                            
							--' WHERE BCO_IDPERSONA = ' + cast (@idProveedor as varchar(20)) 
						
							
          PRINT @consulta
		  INSERT INTO @existeCuenta
		         EXECUTE (@consulta);
		 
		 SET @aux = @aux + 1
	 END

	 ------------------------------------------------------------
	 -- RESULTADO FINAL
	 ------------------------------------------------------------
	-- SELECT * FROM @existeCuenta
	 IF NOT EXISTS(SELECT 1 FROM @existeCuenta)
			BEGIN
				SELECT 1 AS estatus,'Cuenta Valida' AS msj
			END
     ELSE
	        BEGIN
			SELECT	0 AS estatus
						,'Esta empresa: '+nombreEmpresa+ ' no tiene el parametro BA con la cuenta:'+BancoInicio + ', favor de contactar al Administrador de Sistemas'  AS msj
						, nombreEmpresa AS empresa
						, idProveedor AS idProveedor
						,'' as Nombre  
				FROM	@existeCuenta AS C
						where idProveedor=0
				union all
				SELECT	0 AS estatus
						,'Hay diferentes usuario(s) con ese numero de cuenta' AS msj
						, nombreEmpresa AS empresa
						, idProveedor AS idProveedor
						,RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre  
				FROM	@existeCuenta AS C
						INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS P ON C.idProveedor = P.PER_IDPERSONA
						where C.idProveedor <>0
						union all
				SELECT	0 AS estatus
						,'El banco a unificar '+BancoPersona+' del idProveedor: '+convert(nvarchar(50),idproveedor)+' de la empresa: '+nombreEmpresa + ' es diferente al usuario original que es:'+BancoInicio AS msj
						, nombreEmpresa AS empresa
						, idProveedor AS idProveedor
						,RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre  
				FROM	@existeCuenta AS C
						INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] AS P ON C.idProveedor = P.PER_IDPERSONA
						where C.idProveedor <>0 and BancoInicio <>BancoPersona 
			END
	 
	   
	END TRY

    BEGIN CATCH
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_VALIDA_CUENTA_PROV_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END
go

