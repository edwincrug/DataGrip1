
-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez
-- Create date: 02/08/2018
-- Description:	Stored que busca el nombre de un proveedor en las tablas de BPRO.
-- 111035, 'BONNET','XAXX010101000'  
-- ==========================================================================================
-- EXECUTE [dbo].[SEL_BUSCA_PROVEEDOR_SP] @idProveedor= '26164', @nombreProveedor= '', @rfc= ''    
CREATE PROCEDURE [dbo].[SEL_BUSCA_PROVEEDOR_SP]
     @idProveedor     VARCHAR(30)
	,@nombreProveedor VARCHAR(150)
	,@rfc             VARCHAR(30)            
AS
BEGIN
	BEGIN TRY
	SET NOCOUNT ON;

	IF (@idProveedor <> '')
	BEGIN
	     PRINT '1)Busco por ID'
		 SELECT TOP 5 PER_IDPERSONA as idProveedor
			 , RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre
			 , PER_RFC as RFC
		FROM [GA_Corporativa].[dbo].PER_PERSONAS
        WHERE PER_IDPERSONA LIKE @idProveedor + '%'
		ORDER BY PER_IDPERSONA
		--AND PER_IDPERSONA < 312478 
	    --WHERE PER_IDPERSONA LIKE CONVERT(VARCHAR(10),@idProveedor) + '%'
	END
		ELSE IF (@nombreProveedor <> '')
		BEGIN
			PRINT '2)Busco por nombre'
			SELECT TOP 5 PER_IDPERSONA as idProveedor
				 , RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre
				 , PER_RFC as RFC
			 FROM [GA_Corporativa].[dbo].PER_PERSONAS
			WHERE RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) Like '%'+ @nombreProveedor +'%'
			ORDER BY PER_IDPERSONA
			--AND PER_IDPERSONA < 312478 
		END
			ELSE IF (@rfc <> '')
			BEGIN
				PRINT '3)Busco por RFC'
				SELECT TOP 5  PER_IDPERSONA as idProveedor
					 , RTRIM(LTRIM(PER_NOMRAZON  + ' ' + PER_PATERNO + ' ' + PER_MATERNO)) as Nombre
					 , PER_RFC as RFC
				 FROM [GA_Corporativa].[dbo].PER_PERSONAS
				WHERE RTRIM(LTRIM(PER_RFC)) Like '%'+ @rfc +'%'
				ORDER BY PER_IDPERSONA
				--AND PER_IDPERSONA < 312478 
			END
	END TRY

    BEGIN CATCH
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_BUSCA_PROVEEDOR_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END

go

