-- =============================================
-- Author:		Francisco Javier Suárez Priego
-- Create date: 26/07/2019
-- Description:	Se crea el sp que obtiene la información del servicio SFTP
-- =============================================

--EXEC	[dbo].[SEL_FORMATO_SFTP] @IDBanco = 2
CREATE PROCEDURE SEL_FORMATO_SFTP
	@IDBanco int 
AS
BEGIN
	SET NOCOUNT ON;

    
	SELECT [IDFormato]
	  ,[IDBanco] 
      ,[FTPServer]
      ,convert(varchar(100),DecryptByPassPhrase('BanamexUser',FTPUser )) as [FTPUser]
      ,convert(varchar(100),DecryptByPassPhrase('BanamexPassword',FTPPassword )) as [FTPPassword]
      ,[FTPWorkFolder]
      ,[FTPPort]
  FROM [Pagos].[dbo].[PAG_Formato] where idbanco = @IDBanco


END
go

