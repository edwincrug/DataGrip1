



-- =============================================
-- Author:		LQMA
-- Create date: 09042016
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [INS_APLICA_REFERENCIAS_AUT_SP] 
CREATE PROCEDURE [dbo].[INS_APLICA_REFERENCIAS_AUT_SP]
	
	
	
AS
BEGIN
				--VARIABLE PROCESO DE BUSQUEDA
				DECLARE @totalBusqueda INT = (SELECT count(*) FROM (
					SELECT idBmer, RTRIM(SUBSTRING(refAmpliada, 7, 20)) AS REF, refAmpliada, importe, fechaValor
					FROM           referencias.DBO.Bancomer
					where ((refAmpliada LIKE 'REF:%CIE:%') AND ((estatus = 1) AND (esCargo = 1))  AND (datediff (day,fechaValor,getdate()) <= 15))
					UNION 
					select idBmer, 'REF' =
							CASE   
								 WHEN concepto LIKE 'SPEI%' THEN RTRIM(SUBSTRING(refAmpliada, 8, 20))  
								 WHEN concepto LIKE 'TRASPASO%' THEN RTRIM(SUBSTRING(refAmpliada, 1, 30))  
							END, refAmpliada, importe, fechaValor
					FROM           referencias.DBO.Bancomer
					where (((concepto LIKE 'SPEI%' AND refAmpliada LIKE '1234567%') OR (concepto LIKE 'TRASPASO%' AND refAmpliada LIKE '%')) AND ((estatus = 1) AND (esCargo = 1)) AND (datediff (day,fechaValor,getdate()) <= 15) AND (refAmpliada not like('%-%-%')))
					
				) AS NUM)

				SELECT @totalBusqueda
			
				DECLARE @auxBusqueda   INT = 1
				DECLARE @VariableBusquedaTabla TABLE (ID INT IDENTITY(1,1), idBmerTemp int, REFTemp nvarchar(50), refAmpliadaTemp nvarchar(50), importeTemp numeric (18,6), fechaValorTemp datetime)
				
				INSERT INTO @VariableBusquedaTabla (idBmerTemp,REFTemp,refAmpliadaTemp,importeTemp,fechaValorTemp) 
				
					SELECT idBmer, RTRIM(SUBSTRING(refAmpliada, 7, 19)) AS REF, refAmpliada, importe, fechaValor
					FROM           referencias.DBO.Bancomer
					where ((refAmpliada LIKE 'REF:%CIE:%') AND ((estatus = 1) AND (esCargo = 1))  AND (datediff (day,fechaValor,getdate()) <= 15))
					UNION 
					select idBmer, 'REF' =
							CASE   
								 WHEN concepto LIKE 'SPEI%' THEN RTRIM(SUBSTRING(refAmpliada, 8, 19))  
								 WHEN concepto LIKE 'TRASPASO%' THEN RTRIM(SUBSTRING(refAmpliada, 1, 28))  
							END, refAmpliada, importe, fechaValor
					FROM           referencias.DBO.Bancomer
					where (((concepto LIKE 'SPEI%' AND refAmpliada LIKE '1234567%') OR (concepto LIKE 'TRASPASO%' AND refAmpliada LIKE '%')) AND ((estatus = 1) AND (esCargo = 1)) AND (datediff (day,fechaValor,getdate()) <= 15) AND (refAmpliada not like('%-%-%')))

				WHILE(@auxBusqueda <=  @totalBusqueda)

				BEGIN
						declare @refTemporal as nvarchar(50)
						declare @idBanco as int
						declare @importeTemporal as numeric (18,6)
						
						SELECT @idBanco = idBmerTemp,  @refTemporal = replace(ltrim(replace(REFTemp,'0',' ')),' ','0'), @importeTemporal = importeTemp  FROM @VariableBusquedaTabla WHERE ID = @auxBusqueda

						--

					IF EXISTS
							(
							 SELECT   PAG_PROGRA_PAGOS_BPRO.pbp_consCartera, PAG_PROGRA_PAGOS_DETALLE.pad_documento, PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor, PAG_PROGRA_PAGOS_DETALLE.pad_cuentaProveedor, 
                         PAG_PROGRA_PAGOS_DETALLE.pad_cuentaDestino, PAG_PROGRA_PAGOS_DETALLE.pad_saldo, PAG_PROGRA_PAGOS_DETALLE.pad_documento AS Doc2, 0 AS Expr1, 
                         PAG_PROGRA_PAGOS_BPRO.pbp_ordenCompra, PAG_LOTE_PAGO.pal_id_empresa, PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago, PAG_PROGRA_PAGOS_BPRO.pbp_saldo
				FROM            PAG_PROGRA_PAGOS_DETALLE INNER JOIN
										 PAG_PROGRA_PAGOS_BPRO ON PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor = PAG_PROGRA_PAGOS_BPRO.pbp_idProveedor AND 
										 PAG_PROGRA_PAGOS_DETALLE.pad_documento = PAG_PROGRA_PAGOS_BPRO.pbp_documento AND PAG_PROGRA_PAGOS_DETALLE.pbp_consCartera = PAG_PROGRA_PAGOS_BPRO.pbp_consCartera INNER JOIN
										 PAG_LOTE_PAGO ON PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = PAG_LOTE_PAGO.pal_id_lote_pago
				WHERE        (PAG_PROGRA_PAGOS_DETALLE.pad_polReferencia LIKE '%'+ @refTemporal +'%' AND PAG_PROGRA_PAGOS_DETALLE.pad_saldo = @importeTemporal)

							)
						BEGIN
								
						
						PRINT (@refTemporal + '-' + cast(@idBanco as varchar(50)) + '-' + cast(@importeTemporal as varchar(50)))
						EXECUTE [INS_APLICA_REFERENCIAS_FIN_SP] @refTemporal, @idBanco, @importeTemporal

						END

					SET @auxBusqueda = @auxBusqueda + 1		

				END 
				
				
END

go

