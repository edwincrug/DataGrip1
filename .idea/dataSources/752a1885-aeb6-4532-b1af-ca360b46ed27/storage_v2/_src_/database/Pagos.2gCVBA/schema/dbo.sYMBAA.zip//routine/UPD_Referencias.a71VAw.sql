


-- =============================================
-- Author:		FAL
-- Create date: 28092020
-- Description:	actualiza las referencias Automaticas.
-- EXECUTE UPD_Referencias
-- =============================================

CREATE PROCEDURE [dbo].[UPD_Referencias]
	

		
AS
BEGIN
				--Encontramos los parametros de la base de datos 

      DECLARE @total INT = (SELECT  COUNT (*) from (SELECT  DISTINCT det.pal_id_lote_pago, det.pad_idProveedor, det.pad_agrupamiento, pad_polReferencia, lote.pal_id_empresa, det.pad_documento, det.pbp_consCartera
													from Pagos.dbo.PAG_PROGRA_PAGOS_DETALLE det 
													inner join pagos.dbo.PAG_LOTE_PAGO lote on lote.pal_id_lote_pago = det.pal_id_lote_pago 
													WHERE lote.pal_id_tipoLotePago  = 1 AND (datediff (day,lote.pal_fecha,getdate()) <= 1) and det.pad_polReferencia = 'AUT' and lote.pal_estatus <= 3 and lote.pal_estatus > 1
													) as cuantos)	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), pal_id_lote_pago int, pad_idProveedor int, pad_agrupamiento int, pad_polReferencia varchar(35), pal_id_empresa int, pad_documento varchar(35), pbp_consCartera int)
														
				INSERT INTO @VariableTabla (pal_id_lote_pago, pad_idProveedor, pad_agrupamiento , pad_polReferencia , pal_id_empresa , pad_documento , pbp_consCartera) 

				SELECT  DISTINCT det.pal_id_lote_pago, det.pad_idProveedor, det.pad_agrupamiento, pad_polReferencia, lote.pal_id_empresa, det.pad_documento, det.pbp_consCartera
				from Pagos.dbo.PAG_PROGRA_PAGOS_DETALLE det 
				inner join pagos.dbo.PAG_LOTE_PAGO lote on lote.pal_id_lote_pago = det.pal_id_lote_pago 
				WHERE lote.pal_id_tipoLotePago  = 1 AND (datediff (day,lote.pal_fecha,getdate()) <= 1) and det.pad_polReferencia = 'AUT' and lote.pal_estatus <= 3 and lote.pal_estatus > 1
				order by det.pal_id_lote_pago, det.pad_idProveedor
				

				WHILE(@aux <=  @total)
						BEGIN
						
						DECLARE @id_lote_pago int
						DECLARE @IdProveedor int
						DECLARE @agrupamiento int
						DECLARE @polReferencia varchar(35)
						DECLARE @id_empresa int
						DECLARE @pad_documento varchar(35)
						DECLARE @consCartera int
						
						SELECT @id_lote_pago = pal_id_lote_pago , @IdProveedor = pad_idProveedor,  @agrupamiento = pad_agrupamiento, @polReferencia= pad_polReferencia,@id_empresa = pal_id_empresa, @pad_documento = pad_documento, @consCartera = pbp_consCartera FROM @VariableTabla WHERE ID = @aux

						UPDATE PAG_PROGRA_PAGOS_DETALLE SET pad_polReferencia = CONVERT(varchar,@id_lote_pago) + '-' + CONVERT(varchar,@IdProveedor) + '-' + CONVERT(varchar,@agrupamiento) WHERE pal_id_lote_pago = @id_lote_pago and pad_documento = @pad_documento and pbp_consCartera = @consCartera

						--select @id_lote_pago, @pad_documento, @pad_documento
						 
					SET @aux = @aux + 1				
				END

				--select * from @VariableTabla

END



go

