-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 08/03/2016
-- Description:	Inserta Proveedor Cuenta
-- =============================================
--EXECUTE [INS_PROVEEDOR_CUENTA_SP] 4, 555,'autos', 'Azteca 243'                        
CREATE PROCEDURE [dbo].[INS_PROVEEDOR_CUENTA_SP]
	 @idEmpresa            numeric(18,0) =0
	,@idProveedor          numeric(18,0) =0
    ,@nombreProveedor      nvarchar(50)=NULL
	,@cuentaPagadora       nvarchar(50)=NULL
    
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
			   
			   INSERT INTO [dbo].[PAG_CAT_PROVEEDORES]
								   ([pcp_idEmpresa]
								   ,[pcp_idProveedor]
								   ,[pcp_nombreProveedor]
								   ,[pcp_cuentaPagadora]    
								   )
							  VALUES
								   (@idEmpresa
								   ,@idProveedor
								   ,@nombreProveedor
								   ,@cuentaPagadora
								   )  
								  			              
				 
           SELECT 1

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[INS_PROVEEDOR_CUENTA_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 0
END CATCH		     
END

go

