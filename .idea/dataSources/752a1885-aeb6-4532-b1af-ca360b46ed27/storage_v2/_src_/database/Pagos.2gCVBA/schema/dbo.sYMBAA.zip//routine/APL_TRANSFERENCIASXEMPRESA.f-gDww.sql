



-- ====================================================
-- Author:		Fernando Alvarado Luna
-- Create date: 22/11/2016
-- Description:	Lotes Maestro por empresa y Usuario
-- Este SP debe ser solo por empresa
-- ====================================================
--EXECUTE [UPD_TRANSFERENCIASXEMPRESA] 75,50000
CREATE PROCEDURE [dbo].[APL_TRANSFERENCIASXEMPRESA]
	 @idLote int =0,
	 @importe numeric (18,0) = 0

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
UPDATE PAG_TRANSFERENCIAS_BANCARIAS SET ptb_importe = @importe, ptb_estatus = 2  WHERE ptb_id = @idLote
SELECT 'Exito'
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END



go

