-- ====================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 11/03/2016
-- Description:	Para eliminar Lotes inconclusos en cascada
-- ====================================================
--EXECUTE [DEL_LOTE_INCONCLUSO_SP]  0                   
CREATE PROCEDURE [dbo].[DEL_LOTE_INCONCLUSO_SP]
	 @idLote numeric(18,0)=0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
 BEGIN TRAN   
        ---------------------------------------------------------------
		--  Obtenemos Los lotes inconclusos                          --
		---------------------------------------------------------------
		DECLARE     @total        INT = 0
		DECLARE     @aux          INT = 1
		DECLARE     @VariableTabla TABLE (id            INT IDENTITY(1,1)
										 ,idLote        decimal(18,0)
										 )
									
        INSERT INTO  @VariableTabla  SELECT L.[pal_id_lote_pago]
									   FROM [Pagos].[dbo].[PAG_LOTE_PAGO] L
									  WHERE L.[pal_id_lote_pago] NOT IN (SELECT D.[pal_id_lote_pago] 
																		  FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE]	  D
																		 WHERE D.[pal_id_lote_pago] = L.[pal_id_lote_pago]) 
										OR  L.[pal_id_lote_pago] NOT IN (SELECT I.[pal_id_lote_pago]
																		   FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS]   I
																		  WHERE I.[pal_id_lote_pago] = L.[pal_id_lote_pago])
										OR  L.[pal_id_lote_pago] NOT IN (SELECT E.[pal_id_lote_pago]
																		   FROM [Pagos].[dbo].[PAG_FLUJO_EGRESO_BANCOS]   E
																		  WHERE E.[pal_id_lote_pago] = L.[pal_id_lote_pago])
										OR  L.[pal_id_lote_pago] NOT IN (SELECT O.[pal_id_lote_pago]
																		   FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_OTROS]   O
																		  WHERE O.[pal_id_lote_pago] = L.[pal_id_lote_pago])
										OR  L.[pal_id_lote_pago] NOT IN (SELECT T.[pal_id_lote_pago]
																		   FROM [Pagos].[dbo].[PAG_TRANSFERENCIAS_BANCARIAS] T
																		  WHERE T.[pal_id_lote_pago] = L.[pal_id_lote_pago])
									    --AND  L.[pal_id_lote_pago] < 100									  
										;
      
	SET @total = (SELECT count(id) FROM  @VariableTabla)
	SELECT id, idLote FROM  @VariableTabla

    WHILE(@aux <=  @total)
	     BEGIN
              DECLARE @loteActual  decimal(18,0)=0
	              SET  @loteActual = (SELECT idLote FROM @VariableTabla WHERE ID = @aux)
	            PRINT @loteActual
				
				DELETE
				  FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE]	
				 WHERE [pal_id_lote_pago] = @loteActual
				 PRINT '1.Elimina Detalle'

				
				DELETE
				   FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS]
				  WHERE [pal_id_lote_pago] =  @loteActual
				  PRINT '2.Elimina Ingresos'

				
				DELETE
					FROM [Pagos].[dbo].[PAG_FLUJO_EGRESO_BANCOS]
				   WHERE [pal_id_lote_pago] =  @loteActual
				  PRINT '3.Elimina Egresos'

				
				DELETE
					FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_OTROS]
					WHERE [pal_id_lote_pago] =  @loteActual
				  PRINT '4.Elimina Otros'

				
				DELETE
					FROM [Pagos].[dbo].[PAG_TRANSFERENCIAS_BANCARIAS]
					WHERE [pal_id_lote_pago] =  @loteActual
				  PRINT '5.Elimina Transferencias'

				
				DELETE
					FROM [Pagos].[dbo].[PAG_LOTE_PAGO] 
					WHERE [pal_id_lote_pago] =  @loteActual
				  PRINT '6.Elimina Padre'
	  
		  ----SELECT @aux
		  SET @aux = @aux + 1
		  END
COMMIT TRAN
 	   
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[DEL_LOTE_INCONCLUSO_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END

go

