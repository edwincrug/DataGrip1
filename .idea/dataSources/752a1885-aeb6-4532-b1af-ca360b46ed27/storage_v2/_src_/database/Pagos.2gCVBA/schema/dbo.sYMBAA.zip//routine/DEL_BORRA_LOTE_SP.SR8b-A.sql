




-- =============================================
-- Author:		FAL
-- Create date: 09042016
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [DEL_BORRA_LOTE_SP] 190
CREATE PROCEDURE [dbo].[DEL_BORRA_LOTE_SP]
	
	
	 @idLote INT = 0

	
AS
BEGIN
				--Encontramos los parametros de la base de datos 
delete PAG_FLUJO_EGRESO_BANCOS where pal_id_lote_pago = @idLote
delete PAG_FLUJO_INGRESO_BANCOS where pal_id_lote_pago = @idLote
delete PAG_FLUJO_INGRESO_OTROS where pal_id_lote_pago = @idLote
delete PAG_PROGRA_PAGOS_DETALLE where pal_id_lote_pago = @idLote
delete PAG_LOTE_PAGO where pal_id_lote_pago = @idLote

	SELECT 'TERMINO CON EXITO'			

END



go

