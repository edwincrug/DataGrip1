-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 29/02/2016
-- Description:	Lotes por empresa 
-- =============================================
--EXECUTE [INS_PAG_PROG_PAGOS_SP] 1, 77,'08222017-AUN1402117H9-02', 0, 3899.94                       
CREATE PROCEDURE [dbo].[INS_PAG_PROG_PAGOS_SP]
	 @idEmpresa INT = 0
	,@idUsuario INT = 0
	,@nombreLote nvarchar(50) = 0
    ,@estatus  smallint = 1    --1: Pendiente - 2: Aprobado - 3: Rechazado - 4: Pagado
	,@esApliacionDirecta smallint = 0
	,@cifraControl	decimal	(18,5) = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY

	   DECLARE @idLoteDctos int = 0
	   DECLARE @idLotePagos int = 0
	   DECLARE @idLote int = 0
	   

	   SET @idLoteDctos = (SELECT MAX(dpa_lote) FROM [cuentasxpagar].[dbo].[cxp_doctospagados])
	   	
	   SET @idLotePagos = (SELECT MAX(pal_id_lote_pago) FROM [Pagos].[dbo].[PAG_LOTE_PAGO])

	   IF (@idLotePagos > = @idLoteDctos)
	   BEGIN
			SET @idLote = @idLotePagos + 1
	   END
	   ELSE
	   BEGIN
			SET @idLote = @idLoteDctos + 1
	   END 


	   
	   INSERT INTO [cuentasxpagar].[dbo].[cxp_doctospagados](dpa_conscartera,dpa_iddocumento,dpa_idpersona,dpa_cuentapagadora,dpa_cuentabeneficiario,dpa_importepagado,dpa_folioorden,dpa_pagoaplicado, dpa_lote, dpa_idempresa,dpa_fechaaplicacion)
	   VALUES(0, '', 0, '', '', 0.01, '', 3,@idLote,@idempresa,getdate())

       INSERT INTO [Pagos].[dbo].[PAG_LOTE_PAGO]
				   ([pal_id_lote_pago]
				   ,[pal_id_empresa]
				   ,[pal_id_usuario]
				   ,[pal_fecha]
				   ,[pal_nombre]
				   ,[pal_estatus]
				   ,[pal_esAplicacionDirecta]
				   ,[pal_cifraControl])
			 VALUES
				   (@idLote
				   ,@idEmpresa       
				   ,@idUsuario       
				   ,getdate()        
				   ,@nombreLote           
				   ,@estatus
				   ,@esApliacionDirecta
				   ,@cifraControl          
				   )
        DECLARE @idPadre numeric(18,0) = @idLote   
        SELECT @idPadre 

     
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[INS_PAG_PROG_PAGOS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 0 
END CATCH		     
END



go

