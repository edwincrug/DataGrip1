


-- =============================================
-- Author:		FAL
-- Create date: 19042017
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [SP_PROCESO_BIS] 
CREATE PROCEDURE [dbo].[SP_PROCESO_BIS]
	

		
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @total INT = (SELECT  COUNT(*)  FROM  PAG_LOTE_PAGO)	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), idLote INT)
				DECLARE @IDLOTE INT
										
				INSERT INTO @VariableTabla (idLote) 

				SELECT        pal_id_lote_pago
				FROM          PAG_LOTE_PAGO
				

				WHILE(@aux <=  @total)
						BEGIN
						
						
						SELECT @IDLOTE = idLote FROM @VariableTabla WHERE ID = @aux
						--SELECT @refPropia, @varconcepto, @idBanco , @emp_idempresa

						EXECUTE [INS_REF_AUTOMATICA_LOTE_SP] @IDLOTE
					SET @aux = @aux + 1				
				END

	--SELECT * from  @VariableTabla

END



go

