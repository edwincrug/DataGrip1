-- ====================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 04/03/2016
-- Description:	Lotes Maestro por empresa y Usuario
-- ====================================================
--EXECUTE [SEL_LOTE_DETALLE_SP] 4,53,118                       
CREATE PROCEDURE [dbo].[SEL_LOTE_DETALLE_SP]
	 @idEmpresa numeric(18,0)=0
	,@idUsuario numeric(18,0)=0
	,@idLotePago  numeric(18,0)=0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
	    SELECT D.[pal_id_lote_pago]       as idLotePago
			  ,D.[pad_id]                 as id
			  ,D.[pad_idProveedor]        as idProveedor 
			  ,D.[pad_polTipo]            as polTipo
			  ,D.[pad_polAnnio]           as annio
			  ,D.[pad_polMes]             as polMes 
			  ,D.[pad_polConsecutivo]     as polConsecutivo
			  ,D.[pad_polMovimiento]      as polMovimiento
			  ,D.[pad_polFechaOperacion]  as polFechaOperacion
			  ,D.[pad_cuenta]             as cuenta
			  ,D.[pad_proveedor]          as proveedor
			  ,D.[pad_documento]          as documento
			  ,D.[pad_tipoDocto]          as tipoDocto
			  ,D.[pad_cartera]            as cartera
			  ,D.[pad_monto]              as monto
			  ,D.[pad_saldo]              as saldo 
			  ,D.[pad_saldoPorcentaje]    as saldoPorcentaje
			  ,D.[pad_moneda]             as moneda
			  ,D.[pad_fechaVencimiento]   as fechaVencimiento
			  ,D.[pad_fechaPromesaPago]   as fechaPromesaPago
			  ,D.[pad_fechaRecepcion]     as fechaRecepcion
			  ,D.[pad_fechaFactura]       as fechaFactura
			  ,D.[pad_ordenCompra]        as ordenCompra
			  ,D.[pad_idEstatus]          as idEstatus
			  ,D.[pad_estatus]            as estatus
			  ,D.[pad_anticipo]           as anticipo
			  ,D.[pad_anticipoAplicado]   as anticipoAplicado
			  ,D.[pad_proveedorBloqueado] as proveedorBloqueado
			  ,D.[pad_ordenBloqueada]     as ordenBloqueada
			  ,D.[pad_diasCobro]          as diasCobro
			  ,D.[pad_aprobado]           as aprobado
			  ,D.[pad_contReprog]         as contReprog
			  ,D.[pad_documentoPagable]   as documentoPagable
			  ,D.[pad_aPagar]             as aPagar
			  ,ISNULL (D.[pad_nombreAgrupador],'Sin Agrupar')    as nombreAgrupador
			  ,ISNULL (D.[pad_ordenAgrupador],0)     as ordenAgrupador
			  ,ISNULL (D.[pad_ordenProveedor],0)     as ordenProveedor
			  ,ISNULL (D.[pad_cuentaProveedor],'SIN CUENTA PAGADORA')    as cuentaProveedor   --Cuenta Pagadora
		  FROM   [Pagos].[dbo].[PAG_LOTE_PAGO] L
		        ,[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
         WHERE L.[pal_id_empresa]   = @idEmpresa
	       --AND datediff (day,L.[pal_fecha],getdate()) = 0       --Para seleccionar solamente lo del día de Hoy
	       AND L.[pal_id_usuario]   = @idUsuario
		   AND L.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
		   AND L.[pal_id_lote_pago] = @idLotePago

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_DETALLE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Error en la consulta' 
END CATCH		     
END

go

