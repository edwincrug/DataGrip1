-- =============================================
-- Author:		Sahirely Yam
-- Create date: 04/07/2017
-- =============================================
CREATE PROCEDURE [dbo].[JOB_INSBPRO_DEPOSITOS_SANTANDER_SP]
	
			@refPropia as nvarchar(100),
			@idBanco as int,
			@varconcepto as nvarchar(50),
			@emp_idempresa INT = 0
		
AS
BEGIN
				DECLARE @total INT = (SELECT  COUNT(*)  FROM  dbo.SplitString(@refPropia,'-'))	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), item nvarchar(50))
				DECLARE @idLote nvarchar(50)
				DECLARE @consCar nvarchar(50)
				DECLARE @consLote nvarchar(50)
				IF @total = 3
					BEGIN										
						INSERT INTO @VariableTabla (item) 
						SELECT item FROM  dbo.SplitString(@refPropia,'-')
						
						SELECT  @idLote = item
						FROM @VariableTabla WHERE ID = 1
						SELECT  @consCar = item
						FROM @VariableTabla WHERE ID = 2
						SELECT  @consLote = LEFT(item,3)
						FROM @VariableTabla WHERE ID = 3

						print @idLote
						print @consCar
						print @consLote
						
						EXECUTE [JOB_INSBPRO_DEPOSITOS_FIN_SANTANDER_SP] @emp_idempresa,@idLote, @consCar, @consLote, @idBanco
				END
END



go

