
-- ==========================================================================================
-- Author:	Lourdes Maldonado Sánchez	
-- Create date: 24/02/2016
-- Description:	Procedimiento que me regresara la consulta a la información guardada en las 
--              tablas PROG_PAGOS y PROG_PAGOS_DETALLE
-- ==========================================================================================
--EXECUTE [SEL_PROG_PAGOS_GUARDADA_SP3erPiso] 5267
CREATE PROCEDURE [dbo].[SEL_PROG_PAGOS_GUARDADA_SP3erPiso] 
	      @idPadre      numeric(18,0) = 0
AS
BEGIN
	SET NOCOUNT ON;
  BEGIN TRY
	   SELECT  D.[pal_id_lote_pago]         AS idPadre
	          ,M.[pal_id_usuario]           AS idUsuario
	          ,M.[pal_fecha]                AS fechaRegistro
			  ,D.[pad_idProveedor]          AS idProveedor
			  ,D.[pad_polTipo]              AS polTipo
			  ,D.[pad_polAnnio]             AS annio
			  ,D.[pad_polMes]			    AS polMes
			  ,D.[pad_polConsecutivo]	    AS polConsecutivo
			  ,D.[pad_polMovimiento]	    AS polMovimiento
			  ,D.[pad_polFechaOperacion]    AS polFechaOperacion
			  ,D.[pad_cuenta]			    AS cuenta
			  ,D.[pad_proveedor]			AS proveedor
			  ,D.[pad_documento]			AS documento
			  ,D.[pad_tipo]					AS tipo
			  ,D.[pad_tipoDocto]			AS tipoDocto
			  ,D.[pad_cartera]				AS cartera
			  ,D.[pad_monto]				AS monto
			  ,D.[pad_saldo]				AS saldo
			  ,D.[pad_saldoPorcentaje]		AS saldoPorcentaje
			  ,D.[pad_moneda]				AS moneda
			  ,D.[pad_fechaVencimiento]		AS fechaVencimiento
			  ,D.[pad_fechaPromesaPago]		AS fechaPromesaPago
			  ,D.[pad_fechaRecepcion]		AS fechaRecepcion
			  ,D.[pad_fechaFactura]			AS fechaFactura
			  ,D.[pad_ordenCompra]			AS ordenCompra
			  ,D.[pad_idEstatus]			AS idEstatus
			  ,D.[pad_estatus]				AS estatus
			  ,D.[pad_anticipo]				AS anticipo
			  ,D.[pad_anticipoAplicado]		AS anticipoAplicado
			  ,D.[pad_proveedorBloqueado]	AS proveedorBloqueado
			  ,D.[pad_ordenBloqueada]		AS ordenBloqueada 
			  ,D.[pad_diasCobro]			AS diasCobro 
			  ,D.[pad_aprobado]				AS aprobado 
			  ,D.[pad_contReprog]			AS contReprog
			  ,D.[pad_documentoPagable]		AS documentoPagable 
			  ,D.[pad_aPagar]				AS aPagar
			  ,D.[pad_nombreAgrupador]      AS nombreAgrupador
			  ,D.[pad_ordenAgrupador]       AS ordenAgrupador
			  ,D.[pad_ordenProveedor]       AS ordenProveedor
			  ,D.[pad_cuentaProveedor]      AS cuentaProveedor
			  ,D.[pad_cuentaProveedor]      AS cuentaPagadora
			  ,D.[pad_cuentaDestino]        AS cuentaDestino
              ,D.[pad_seleccionable]        AS seleccionable
			  ,D.[pad_numeroSerie]          AS numeroSerie 
              ,D.[pad_facturaProveedor]     AS facturaProveedor
			  ,D.[pad_polReferencia]     AS referencia
			  ,D.[pad_bancoPagador]		AS bancoPagador
			  ,D.[pad_agrupamiento]		AS agrupamiento
			  ,BPRO.[pbp_cuentaDestinoArr]  as cuentaDestinoArr
			  ,isnull(MAX(BPRO.[No_CotizacionSISCO]),'Sin Cotizacion SISCO')   as No_CotizacionSISCO
			  ,isnull(MAX(BPRO.[No_OrdenServicioSISCO]), 'Sin Orden de Servicio') as No_OrdenServicioSISCO
			  ,isNull(MAX(BPRO.[Id_EstatusSISCO]),0)  as Id_EstatusSISCO
			  ,isNull(MAX(BPRO.[EstatusSISCO]),'Sin Estatus')  as EstatusSISCO
			  ,isNull(MAX(BPRO.[FechaFacturaSISCO]), '1900-01-01 00:00:00') as FechaFacturaSISCO
			  ,isNull(MAX(BPRO.[OperacionSISCO]),'Sin Operacion')  as OperacionSISCO
			  ,isNull(MAX(BPRO.[FechaCargaCopade]),'1900-01-01 00:00:00') as FechaCargaCopade
			  ,isNull(MAX(BPRO.[FechaRecepcionCopade]),'1900-01-01 00:00:00') as FechaRecepcionCopade
		FROM  [Pagos].[dbo].[PAG_LOTE_PAGO] M,
		[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
		 INNER JOIN PAG_PROGRA_PAGOS_BPRO AS BPRO 
			          ON BPRO.[pbp_polTipo]        = D.pad_polTipo       
                     AND BPRO.[pbp_polAnnio]       = D.pad_polAnnio
			         AND BPRO.[pbp_polMes]         = D.pad_polMes
			         AND BPRO.[pbp_polConsecutivo] = D.pad_polConsecutivo
			         AND BPRO.[pbp_polMovimiento]  = D.pad_polMovimiento
			         AND BPRO.[pbp_consCartera] = D.pbp_consCartera
		 where  M.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
		 AND D.[pal_id_lote_pago] = @idPadre
		 AND M.[pal_id_empresa] = BPRO.[pbp_empresa]
		GROUP BY 
			D.[pal_id_lote_pago],M.[pal_id_usuario],M.[pal_fecha],D.[pad_idProveedor],D.[pad_polTipo],D.[pad_polAnnio],D.[pad_polMes],
			D.[pad_polConsecutivo],D.[pad_polMovimiento],D.[pad_polFechaOperacion],D.[pad_cuenta],D.[pad_proveedor],D.[pad_documento],
			D.[pad_tipo],D.[pad_tipoDocto],D.[pad_cartera],D.[pad_monto],D.[pad_saldo],D.[pad_saldoPorcentaje],D.[pad_moneda],
			D.[pad_fechaVencimiento] ,D.[pad_fechaPromesaPago],D.[pad_fechaRecepcion] ,D.[pad_fechaFactura],D.[pad_ordenCompra],D.[pad_idEstatus],
			D.[pad_estatus],D.[pad_anticipo],D.[pad_anticipoAplicado],D.[pad_proveedorBloqueado],D.[pad_ordenBloqueada],D.[pad_diasCobro],
			D.[pad_aprobado],D.[pad_contReprog],D.[pad_documentoPagable],D.[pad_aPagar],D.[pad_nombreAgrupador],D.[pad_ordenAgrupador],D.[pad_ordenProveedor],
			D.[pad_cuentaProveedor],D.[pad_cuentaProveedor],D.[pad_cuentaDestino],D.[pad_seleccionable],D.[pad_numeroSerie],D.[pad_facturaProveedor],
			D.[pad_polReferencia],D.[pad_bancoPagador],D.[pad_agrupamiento],BPRO.[pbp_cuentaDestinoArr]
		ORDER BY D.[pad_idProveedor] , D.[pad_documento] 	
   END TRY
  
  BEGIN CATCH
	 PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_PROG_PAGOS_GUARDADA_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 --SELECT 0 --Encontro error
	 SELECT 'ERROR EN LA CONSULTA'
  END CATCH
END


go

