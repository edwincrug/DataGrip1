
-- =============================================
-- Author:		Fernando Alvarado Luna
-- Create date: 04/03/2019
-- Description:	Lotes por empresa  --
-- =============================================
--  --EXECUTE [REGENERA_DOCTOS_BANCOS] 3
                 
CREATE PROCEDURE [dbo].[REGENERA_DOCTOS_BANCOS]
@idEmpresa      int = 0	
AS
BEGIN
--Esta comentado por si se desea hacer transaccional
--SET NOCOUNT ON;
--BEGIN TRY	

DECLARE  @lote INT 
DECLARE @documento VARCHAR(100)
DECLARE @referencia VARCHAR(100)
DECLARE @saldo NUMERIC (18,6)
DECLARE @saldoAplicado NUMERIC (18,6)
DECLARE @consecutivoCartera numeric (18,0)
DECLARE @consecutivoPoliza numeric (18,0)
DECLARE @idBmer numeric (18,0)
DECLARE @idDocto numeric (18,0)	
DECLARE @mesPoliza int
DECLARE @empresa numeric (18,0)
DECLARE @fecha datetime
DECLARE @id_persona numeric (18,0)
DECLARE @VariableREFERENCIASTabla TABLE (ID INT IDENTITY(1,1), idBmer numeric(18,0), referencia varchar(100), idDocto numeric(18,0) )


DECLARE @totalBusqueda INT = (SELECT count(dpa_iddoctopagado) 
				FROM (select p.dpa_iddoctopagado  from [cuentasxpagar].[dbo].[cxp_doctospagados] p
				  left join PAGOS.DBO.PAG_REL_DOCTOS_BANCOS r on p.dpa_iddoctopagado=r.dpa_iddoctopagado
				  left  join Tesoreria.dbo.CARGOSBANCOS_CB c   on c.idBmer=r.idBanco_Registro and r.idBanco=c.IDBanco
				  where dpa_idempresa=@idEmpresa and month(dpa_fechaaplicacion )=9 and r.dpa_iddoctopagado is null
				) AS NUM)

				SELECT @totalBusqueda
			
				DECLARE @auxBusqueda   INT = 1
				SET @referencia = 'Sin'
				SET @idBmer = 0
				DECLARE @VariableBusquedaTabla TABLE (ID INT IDENTITY(1,1), dpa_iddoctopagado int,  pal_id_empresa numeric(18,0), pad_documento varchar(100), pal_lote numeric(18,0), pad_saldo numeric (18,6), pbp_consCartera numeric (18,0), pal_id_persona numeric(18,0))
				
				INSERT INTO @VariableBusquedaTabla (dpa_iddoctopagado, pal_id_empresa, pad_documento, pal_lote, pad_saldo, pbp_consCartera, pal_id_persona) 
				
				select p.dpa_iddoctopagado,p.dpa_idempresa, p.dpa_iddocumento, p.dpa_lote, p.dpa_importepagado, p.dpa_conscartera, p.dpa_idpersona  from [cuentasxpagar].[dbo].[cxp_doctospagados] p
						  left join PAGOS.DBO.PAG_REL_DOCTOS_BANCOS r on p.dpa_iddoctopagado=r.dpa_iddoctopagado
						  left  join Tesoreria.dbo.CARGOSBANCOS_CB c   on c.idBmer=r.idBanco_Registro and r.idBanco=c.IDBanco
						  where dpa_idempresa=@idEmpresa and month(dpa_fechaaplicacion )=9 and r.dpa_iddoctopagado is null
						  order by p.dpa_iddoctopagado desc
			
			WHILE(@auxBusqueda <=  @totalBusqueda)
					BEGIN
				
				--separo la referncia.
				
						SELECT @idDocto = dpa_iddoctopagado, @lote= pal_lote, @empresa = pal_id_empresa ,@consecutivoCartera = pbp_consCartera,  @documento = pad_documento, @consecutivoCartera = pbp_consCartera, @id_persona = pal_id_persona FROM @VariableBusquedaTabla WHERE ID = @auxBusqueda
						
						--SELECT @documento, @id_persona, @consecutivoCartera
						
						SELECT  @referencia = pad_polReferencia
						FROM         PAG_PROGRA_PAGOS_DETALLE
						WHERE pad_documento = @documento AND pad_idProveedor = @id_persona 
						
						SELECT    @idBmer = idBmer
						FROM       REFERENCIAS.DBO.Bancomer
						WHERE     (refAmpliada LIKE ('%' + @referencia + '%'))
						
						INSERT @VariableREFERENCIASTabla(idBmer,referencia, idDocto)
						SELECT @idBmer, @referencia, @idDocto
						
						INSERT INTO PAG_REL_DOCTOS_BANCOS (dpa_iddoctopagado, idBanco_Registro, idBanco)
						VALUES(@idDocto, @idBmer, 1)
						
						SET @idBmer = 0
						SET @referencia = 'Sin'
						SET @auxBusqueda = @auxBusqueda + 1	
			END
			
			
			--SELECT * FROM @VariableREFERENCIASTabla where referencia <> 'Sin'
			
			--SELECT DISTINCT loteResultado FROM @VariableTablaResultado WHERE diferencia <> 0 	
				

	     
END



go

