



-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 05/05/2016
-- Description:	Empresas relacionadas solo con ese usuario
-- ==========================================================================================
--EXECUTE [SEL_LIBERAR_CXP_SP] 1226
CREATE PROCEDURE [dbo].[SEL_LIBERAR_CXP_SP]
          @idlote  int = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
--Debe mostrar solo las empresas relacionadas solo con ese usuario

Select  D.pad_proveedor as proveedor, D.pad_documento as documento, D.pad_saldo as saldo
From [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
Left Outer Join
      [cuentasxpagar].[dbo].cxp_doctospagados LO
ON   D.pad_documento = LO.dpa_iddocumento
where D.pal_id_lote_pago = @idlote AND  LO.dpa_iddocumento is null order by D.pad_proveedor

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_EMPRESAS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 0 --Encontro error
END CATCH		     
END



go

