-- ==================================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 13/04/2016
-- Description:	Borra informacion completa de los lotes No Aprobados ni Pagados
-- ==================================================================================================
--EXECUTE [PROC_BORRA_LOTES_NO_APROBADOS_SP]  4                     
CREATE PROCEDURE [dbo].[PROC_BORRA_LOTES_NO_APROBADOS_SP]
	 @idEmpresa  numeric(18,0)=0
	 
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
 --BEGIN TRAN   
        ---------------------------------------------------------------------------------------------
		--  Obtenemos Los Lotes que no fueron Aprobados ni Pagados (Status 3 y 5)                  --
		---------------------------------------------------------------------------------------------
		PRINT '--------------                INICIO                                     ------------'    
		PRINT '1.------------         Borra Lotes que no esten en Estatus 3 y 5         ------------'

		DECLARE   @total INT = (SELECT count(*) 
		                          FROM [Pagos].[dbo].[PAG_LOTE_PAGO] 
								 WHERE [pal_id_empresa] = @idEmpresa 
								   AND [pal_estatus] NOT IN (3,5))	
		DECLARE   @aux   INT = 1	
        DECLARE   @VariableTabla TABLE (ID        INT IDENTITY(1,1)
										,idLote    INT
										--,idUsuario INT
										--,fecha     DATETIME 
										,estatus   INT
										)

       INSERT INTO  @VariableTabla 
			  SELECT [pal_id_lote_pago]
					--,[pal_id_usuario]
					--,[pal_fecha]
					,[pal_estatus]
				FROM [Pagos].[dbo].[PAG_LOTE_PAGO]
			   WHERE [pal_id_empresa] = @idEmpresa
				 AND [pal_estatus] NOT IN (3,5)  --3: Aprobado - 5: Pagado

        --SET @total= (SELECT count(*) 
		      --        FROM  @VariableTabla)


		WHILE(@aux <=  @total)
		BEGIN
					DECLARE @idLote  AS NUMERIC(18,0)
					DECLARE @estatus AS NUMERIC(18,0)

					SELECT  @idLote  = idLote
						   ,@estatus = estatus 
					  FROM  @VariableTabla 
					 WHERE  ID = @aux
                    
					--PRINT '**********BORRA SOLO EL LOTE**********'  
					--SELECT *
					DELETE
					  FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE]	
					 WHERE [pal_id_lote_pago] = @idLote
					 PRINT '1.Borra Lote en Detalle'

					 --SELECT *
					DELETE
					   FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS]
					  WHERE [pal_id_lote_pago] =  @idLote
					  PRINT '2.Borra Lote en Ingresos'

					  --SELECT *
					DELETE
						FROM [Pagos].[dbo].[PAG_FLUJO_EGRESO_BANCOS]
					   WHERE [pal_id_lote_pago] =  @idLote
					  PRINT '3.Borra Lote en Egresos'

					  --SELECT *
					DELETE
						FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_OTROS]
						WHERE [pal_id_lote_pago] =  @idLote
					  PRINT '4.Borra Lote en Otros'

					  --SELECT *
					DELETE
						FROM [Pagos].[dbo].[PAG_TRANSFERENCIAS_BANCARIAS]
						WHERE [pal_id_lote_pago] =  @idLote
					  PRINT '5.Borra Lote en Transferencias'

					  --SELECT *
					DELETE
						FROM [Pagos].[dbo].[PAG_LOTE_PAGO] 
						WHERE [pal_id_lote_pago] =  @idLote
					  PRINT '6.Borra Lote en Lote Padre' 

					  --SELECT *
					DELETE
						  FROM [Pagos].[dbo].[PAG_TABLA_PASO_POLIZAS]
						  WHERE [pal_id_lote_pago] =  @idLote
					  PRINT '7.Borra Tabla de Paso en Lote Padre'

                      SET @aux = @aux + 1
          END
        --COMMIT TRAN

		PRINT '--------------                FIN                                  ------------'

    

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[PROC_BORRA_LOTES_NO_APROBADOS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END

go

