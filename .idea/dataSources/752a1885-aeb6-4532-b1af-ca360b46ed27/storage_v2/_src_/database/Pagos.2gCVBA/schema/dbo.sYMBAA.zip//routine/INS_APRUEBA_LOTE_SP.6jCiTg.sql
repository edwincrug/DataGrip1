-- =============================================
-- Author:		FAL
-- Create date: 21082018
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [INS_APRUEBA_LOTE_SP] 1,3,1,90016,71,72,'',118129,60590
CREATE PROCEDURE [dbo].[INS_APRUEBA_LOTE_SP]
	 @proc_id INT = 0,  
	 @nodo INT = 0,  --ID de aprobado o rechazado: 3 aprobado, 4 rechazado
	 @emp_idempresa INT = 0,
	 @idLote DECIMAL(18,0) = 0,
	 @idUsuario numeric(18,0)=0,

	 @idAprobador numeric(18,0)=0,
	 @observacion VARCHAR(500),
	 @idAprobacion numeric(18,0)=0,
	 @not_identificador numeric(18,0)=0
AS
BEGIN

				   	
	IF(@nodo = 3)
		BEGIN	
		
				
				print ('entro')
				DECLARE @varIDLote varchar = (SELECT CONVERT(varchar(10), @idLote))
				DECLARE @total INT = (SELECT count(pal_id_lote_pago) FROM [dbo].[PAG_PROGRA_PAGOS_DETALLE] WHERE pal_id_lote_pago = @idLote)	
				DECLARE @aux   INT = 1	
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), folio VARCHAR(50), importepagado decimal(18, 5),saldoDocumento decimal(18, 5))
				DECLARE @OrdenValidador int = 1
				DECLARE @AprovadorSiguiente numeric(18,0) = 0
				DECLARE @empresaLote int

				SELECT @idAprobacion = NOT_APROBACION.apr_id, @not_identificador = NOT_NOTIFICACION.not_id
				FROM [Notificacion].DBO.NOT_NOTIFICACION 
				INNER JOIN [Notificacion].DBO.NOT_APROBACION  ON NOT_APROBACION.not_id = NOT_NOTIFICACION.not_id
				where NOT_APROBACION.emp_id = @idAprobador and not_estatus = 2 AND NOT_NOTIFICACION.not_identificador = @varIDLote
		
				
				SELECT @empresaLote = pal_id_empresa  FROM   PAG_LOTE_PAGO  where pal_id_lote_pago = @idLote
				
		
				SELECT TOP(1)  @OrdenValidador = Usuario_Orden_Autoriza
				FROM [Centralizacionv2].[dbo].[DIG_PARAMETROS_PAGO]  
				WHERE [emp_idempresa] = @empresaLote AND Usuario_Autoriza1 = @idAprobador
					
				SELECT TOP(1) @AprovadorSiguiente = Usuario_Autoriza1 
				FROM [Centralizacionv2].[dbo].[DIG_PARAMETROS_PAGO]  
				WHERE [emp_idempresa] = @empresaLote AND Usuario_Orden_Autoriza > @OrdenValidador
				ORDER BY Usuario_Orden_Autoriza	
				
				print (cast(@AprovadorSiguiente as  varchar(20)))
				
				IF @AprovadorSiguiente = 0 
				
				BEGIN
								print ('entro' + cast(@AprovadorSiguiente as  varchar(20)))
								UPDATE [dbo].[PAG_LOTE_PAGO] SET [pal_estatus] = @nodo -- 3 Aprobado, 4 rechazado
								WHERE [pal_id_lote_pago] = @idLote	

								--IF(@nodo = 3)
								--	BEGIN
								UPDATE [Notificacion].[dbo].[NOT_NOTIFICACION] SET not_estatus = @nodo WHERE not_id = (SELECT not_id FROM [Notificacion].[dbo].[NOT_APROBACION] WHERE apr_id = @idAprobacion)
								UPDATE [Notificacion].[dbo].[NOT_APROBACION] SET apr_estatus = @nodo WHERE apr_id = @idAprobador;	

								INSERT INTO [Notificacion].[dbo].[NOT_APROBACION_RESPUESTA](not_id,[apr_id],[nar_fecha],[nar_comentario])
								VALUES(@not_identificador,@idAprobacion,GETDATE(),@observacion)
								
								update Notificacion.dbo.NOT_NOTIFICACION
								set  not_estatus = 3       
								WHERE  (not_identificador LIKE '%' + CONVERT(VARCHAR(10),@idLote) + '%')
										
								INSERT INTO @VariableTabla  

								SELECT   PAG_PROGRA_PAGOS_BPRO.pbp_ordenCompra, PAG_PROGRA_PAGOS_DETALLE.pad_saldo, PAG_PROGRA_PAGOS_BPRO.pbp_saldo
								FROM            PAG_PROGRA_PAGOS_DETALLE INNER JOIN
														 PAG_PROGRA_PAGOS_BPRO ON PAG_PROGRA_PAGOS_DETALLE.pad_idProveedor = PAG_PROGRA_PAGOS_BPRO.pbp_idProveedor AND 
														 PAG_PROGRA_PAGOS_DETALLE.pad_documento = PAG_PROGRA_PAGOS_BPRO.pbp_documento AND PAG_PROGRA_PAGOS_DETALLE.pbp_consCartera = PAG_PROGRA_PAGOS_BPRO.pbp_consCartera INNER JOIN
														 PAG_LOTE_PAGO ON PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = PAG_LOTE_PAGO.pal_id_lote_pago
								WHERE        (PAG_PROGRA_PAGOS_DETALLE.pal_id_lote_pago = @idLote)

									
								WHILE(@aux <=  @total)

								DECLARE @saldoDocumento decimal (18,5) = 0;
								DECLARE @importePagado decimal (18,5) = 0;
										BEGIN
													declare @folioactual as nvarchar(80)
													SELECT @folioactual = folio FROM @VariableTabla WHERE ID = @aux
													--INS_CIERRA_NODO_SP 7 									
													EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
																		   @proc_Id = 1  
																		  ,@nodo_Id = 7 
																		  ,@folio_Operacion = @folioactual
													--INS_CIERRA_NODO_SP 8									
													EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
																		   @proc_Id = 1 
																		  ,@nodo_Id = 8
																		  ,@folio_Operacion = @folioactual
													
													SET @aux = @aux + 1		
													
												SET @saldoDocumento = (SELECT saldoDocumento FROM @VariableTabla WHERE ID = @aux)
												SET @importePagado = (SELECT importepagado FROM @VariableTabla WHERE ID = @aux)

												-- Actualizo el estatus si el saldo es = al importe pagado

												IF (@importePagado = @saldoDocumento)

												BEGIN

													UPDATE [cuentasxpagar].[dbo].[cxp_ordencompra] SET sod_idsituacionorden = 11 WHERE oce_folioorden = @folioactual

												END 
										END
										
						EXECUTE [INS_APROBACION_REGRESO_SP] 
							   @proc_id = 1 
							  ,@nodo = 0
							  ,@emp_idempresa = @emp_idempresa
							  ,@idLote = @idLote
							  
						EXECUTE [INS_REF_AUTOMATICA_LOTE_SP] @idLote		  

	--EXECUTE [INS_APLICA_LOTE_SP] @emp_idempresa,@idLote,@idUsuario		
				END
										
				IF @AprovadorSiguiente > 0 
				BEGIN
				
				
					print ('entro' + cast(@AprovadorSiguiente as  varchar(20)))
					DECLARE @nombreLote VARCHAR(100) = ''
					DECLARE @url VARCHAR(100) = ''
					DECLARE @solicitante NUMERIC(18,0) = 0.0
						
					SELECT @nombreLote = pal_nombre, @solicitante = pal_id_usuario FROM [dbo].[PAG_LOTE_PAGO] WHERE [pal_id_lote_pago] = @idLote

					SELECT @url = ppa_valor FROM PAG_PARAMETROS WHERE ppa_nombre = 'URL_PAGOS'
					
					
					SET @url = @url + '?idLote=' + CONVERT(VARCHAR(10),@idLote) + '&idOperacion=2'
					DECLARE @descripcion VARCHAR(100) = 'Solicitud de Aprobación del lote: ' + @nombreLote
						
					EXEC [Notificacion].[dbo].[INS_APROBACION_LOTE_SP]    @idtipoproceso = 1
																		 ,@identificador = @idLote
																		 ,@idnodo = 3
																		 ,@descripcion = @descripcion
																		 ,@estatus = 1
																		 ,@linkBPRO = @url
																		 ,@adjunto = NULL
																		 ,@idtipoadjunto	= NULL
																		 ,@solicitante = @solicitante
																		 ,@aprobador	= @AprovadorSiguiente

					UPDATE [dbo].[PAG_LOTE_PAGO] SET [pal_estatus] = 2 --Pendiente de aprobar
							WHERE [pal_id_lote_pago] = @idLote
					
					update PAG_LOTE_PAGO
					set pal_observacion = pal_observacion + ' A DIRECCIÓN'
					where  pal_id_lote_pago = @idLote
					
					SELECT 0
								
								
					END				
		END

	SELECT 0	

END
go

