-- =============================================
-- Author:		Sahirely Yam
-- Create date: 04/07/2017
-- execute [JOB_BUSCA_DEPOSITOS_SANTANDER_SP]
-- =============================================
CREATE PROCEDURE [dbo].[JOB_BUSCA_DEPOSITOS_SANTANDER_SP]		
AS
BEGIN				
				DECLARE @total INT = (SELECT  COUNT(*)  FROM  referencias.dbo.Santander WHERE ((concepto like '%-%-%') and (estatus = 1) AND (signo = '-')) and (clacon = '0681' or clacon = '0790') )
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), idSantander int null, concepto varchar(max) null,  importe varchar(14), idEmpresa int)
										
				INSERT INTO @VariableTabla (idSantander, concepto, importe, idEmpresa) 

				SELECT        idSantander, concepto, importe, idEmpresa
				FROM          referencias.dbo.Santander
				INNER JOIN    referencias.dbo.BancoCuenta on Santander.noCuenta = BancoCuenta.cuenta
				where ((concepto like '%-%-%') and (estatus = 1) AND (signo = '-')) and (clacon = '0681' or clacon = '0790') 
				
				WHILE(@aux <=  @total)
				BEGIN
						declare @idBanco int  = (select idSantander from @VariableTabla where ID = @aux)
						declare @varconcepto varchar(max) = (select concepto from @VariableTabla where ID = @aux) 
						declare @emp_idempresa int =  (select idEmpresa from @VariableTabla where ID = @aux)
						
						DECLARE @splitTabla TABLE (ID INT IDENTITY(1,1), item nvarchar(50))

						DELETE FROM @splitTabla

						INSERT INTO @splitTabla(item) 
						SELECT item FROM  dbo.SplitString(@varconcepto,' ')

						declare @refPropia varchar(max) = (select top 1 item from @splitTabla order by ID desc)		
												
						EXECUTE [JOB_INSBPRO_DEPOSITOS_SANTANDER_SP] @refPropia, @idBanco, @varconcepto, @emp_idempresa 
					SET @aux = @aux + 1				
				END

END



go

