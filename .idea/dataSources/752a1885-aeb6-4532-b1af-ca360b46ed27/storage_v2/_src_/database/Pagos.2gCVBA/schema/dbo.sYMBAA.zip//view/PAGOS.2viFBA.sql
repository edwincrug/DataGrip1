CREATE view dbo.PAGOS as
SELECT   [pbp_polTipo] AS polTipo
		,[pbp_polAnnio]          as annio
		,[pbp_polMes]            as polMes
		,[pbp_polConsecutivo]    as polConsecutivo
		,[pbp_polMovimiento]     as polMovimiento
		,[pbp_saldo]	as saldo
   FROM  [dbo].[PAG_PROGRA_PAGOS_BPRO]
go

