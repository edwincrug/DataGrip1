

-- =============================================
-- Create date: 22/06/2017
-- Description:	Obtengo el idUsuarioPanel
-- =============================================
-- [dbo].[SEL_LOGIN_SP] @usuario = 'ADMIN', @contrasena = '1234'
CREATE PROCEDURE [dbo].[SEL_LOGIN_SP]
	@usuario NVARCHAR(50),
	@contrasena NVARCHAR(50)	
AS
BEGIN
	SELECT	[idUsuarioPanel]
    FROM	[Pagos].[dbo].[Usuarios]
	WHERE	[usuario] = @usuario AND [contrasena] = @contrasena	
END


go

