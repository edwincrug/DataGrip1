
-- =============================================
-- Author:		FAL
-- Create date: 19042017
-- Description:	Aprueba el Lote
-- =============================================

CREATE PROCEDURE [dbo].[actualiza_fin]
	
				@docto as int,
				@refAmpliada as nvarchar (50),
				@Fecha as datetime
		
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @idBmer int

				SELECT TOP 1 @idBmer = idBmer
				FROM   referencias.dbo.Bancomer
				WHERE  refAmpliada like '%' +@refAmpliada  + '%'  and (datediff (day,fechaOperacion, @Fecha) = 0)

				INSERT INTO PAG_REL_DOCTOS_BANCOS (dpa_iddoctopagado, idBanco_Registro, idBanco)
				VALUES(@docto, @idBmer, 1)

				
				

			--  Valido si esta en doctos pagados actualizo su estatus en bancomer
						

END



go

