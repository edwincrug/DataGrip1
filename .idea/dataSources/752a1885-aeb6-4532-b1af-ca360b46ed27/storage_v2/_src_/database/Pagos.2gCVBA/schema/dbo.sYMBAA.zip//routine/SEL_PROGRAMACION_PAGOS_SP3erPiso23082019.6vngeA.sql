



-- ==========================================================================================
-- Author:		
-- Create date: 21082018
-- Description:	Select a la Programacion de Pagos   
-- ==========================================================================================
--EXECUTE [SEL_PROGRAMACION_PAGOS_SP3erPiso23082019] 7  
CREATE PROCEDURE [dbo].[SEL_PROGRAMACION_PAGOS_SP3erPiso23082019] 
 @idEmpresa numeric = 0
AS
BEGIN

	SET NOCOUNT ON;
	BEGIN TRY
	DECLARE @pagos TABLE   ( IDB INT IDENTITY(1,1)
	                                ,polTipo        nvarchar(50)
									,annio          decimal(4, 0)
									,polMes         decimal(2, 0)
									,polConsecutivo decimal(10, 0)
									,polMovimiento  decimal(10, 0)
									,saldo          decimal(18, 5)
									,Estatus        int
									 primary key (IDB, polTipo, annio, polMes,polConsecutivo, polMovimiento)
								   )	
INSERT INTO @pagos
SELECT distinct  B.[pbp_polTipo] as polTipo,B.[pbp_polAnnio] as annio ,B.[pbp_polMes] as polMes, B.[pbp_polConsecutivo] as polConsecutivo, 
 B.[pbp_polMovimiento]     as polMovimiento  ,B.[pbp_saldo]	as saldo, 0 AS ESTATUS
 FROM [dbo].[PAG_PROGRA_PAGOS_BPRO] B (NOLOCK) WHERE    [pbp_empresa] = @idEmpresa

 DECLARE @pagosDetalle TABLE ( IDBD INT IDENTITY(1,1),
	[pad_polTipo] [nvarchar](50) NOT NULL,
	[pad_polAnnio] [numeric](18, 0) NULL,
	[pad_polMes] [numeric](18, 0) NULL,
	[pad_polConsecutivo] [numeric](18, 0) NULL,
	[pad_polMovimiento] [numeric](18, 0) NULL,
	[saldo] [decimal](38, 5) NULL
	 primary key (IDBD)
) 



INSERT INTO @pagosDetalle
SELECT   D.[pad_polTipo],CAST((ROUND(D.[pad_polAnnio],0)) AS numeric) AS pad_polAnnio ,CAST((ROUND(D.[pad_polMes],0)) AS numeric) AS pad_polMes
,CAST((ROUND(D.[pad_polConsecutivo],0)) AS numeric) AS  pad_polConsecutivo ,CAST((ROUND(D.[pad_polMovimiento],0)) AS numeric) AS pad_polMovimiento,
SUM (D.[pad_saldo]) as saldo 
FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D (NOLOCK)
inner join [Pagos].[dbo].[PAG_LOTE_PAGO]            L (NOLOCK) 
	on L.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
	AND D.[pad_aPagar] = 1 AND L.pal_id_empresa =  @idEmpresa
GROUP BY D.[pad_polTipo], D.[pad_polAnnio],D.[pad_polMes],D.[pad_polConsecutivo],D.[pad_polMovimiento],D.[pad_saldo], D.pad_monto 							 	
HAVING SUM(D.[pad_saldo]) >= D.pad_monto


UPDATE @pagos SET ESTATUS = 1 
FROM @pagos L INNER JOIN @pagosDetalle B ON polTipo = pad_polTipo AND annio = pad_polAnnio AND polMes = pad_polMes
AND polConsecutivo = pad_polConsecutivo AND polMovimiento = pad_polMovimiento AND L.saldo = B.saldo

DELETE FROM @pagos WHERE ESTATUS = 1
	
							   
 
		    SELECT   BPRO.[pbp_polTipo]           as polTipo
					,BPRO.[pbp_polAnnio]          as annio
					,BPRO.[pbp_polMes]            as polMes
					,BPRO.[pbp_polConsecutivo]    as polConsecutivo
					,BPRO.[pbp_polMovimiento]     as polMovimiento
					,BPRO.[pbp_polFechaOperacion] as polFechaOperacion
					,BPRO.[pbp_documento]         as documento 
					,BPRO.[pbp_cuenta]            as cuenta
					,BPRO.[pbp_idProveedor]       as idProveedor
					,BPRO.[pbp_proveedor]         as proveedor
					,BPRO.[pbp_tipoDocto]         as tipoDocto
					,BPRO.[pbp_cartera]           as cartera
					,BPRO.[pbp_monto]             as monto
					,BPRO.[pbp_saldo]             as saldo
					,BPRO.[pbp_saldoPorcentaje]   as saldoPorcentaje
					,BPRO.[pbp_moneda]            as moneda
					,BPRO.[pbp_fechaVencimiento]  as fechaVencimiento
					,BPRO.[pbp_fechaPromesaPago]  as fechaPromesaPago
					--,CON_CAR012016.CCP_FECHPROMPAG AS fechaPromesaPago
					,BPRO.[pbp_fechaRecepcion]    as fechaRecepcion
					,BPRO.[pbp_fechaFactura]      as fechaFactura
					,BPRO.[pbp_ordenCompra]       as ordenCompra
					,BPRO.[pbp_estatus]           as estatus
					,BPRO.[pbp_idEstatus]         as idEstatus
					,BPRO.[pbp_anticipo]          as anticipo
					,BPRO.[pbp_anticipoAplicado]  as anticipoAplicado
					,BPRO.[pbp_proveedorBloqueado] as proveedorBloqueado
					,BPRO.[pbp_ordenBloqueada]     as ordenBloqueada
					,BPRO.[pbp_diasCobro]          as diasCobro
					,BPRO.[pbp_aprobado]           as aprobado
					,BPRO.[pbp_contReprog]         as contReprog
					,BPRO.[pbp_documentoPagable]   as documentoPagable
					,BPRO.[pbp_aPagar]             as aPagar
					,ISNULL (CAGRP.pca_ordenVarchar,'Z') + ' ' + ISNULL (CAGRP.pca_descripcion,'Sin Agrupar')    as nombreAgrupador
					,ISNULL (CAGRP.pca_orden, 0)     as ordenAgrupador
					,BPRO.[pbp_ordenProveedor]     as ordenProveedor
					,UPPER(BPRO.[pbp_cuentaPagadora])     as cuentaPagadora
					,BPRO.[pbp_cuentaProveedor]    as cuentaProveedor
					,BPRO.[pbp_empresa]            as empresa
					,BPRO.[pbp_cuentaDestino]      as cuentaDestino
                    ,CASE WHEN BPRO.[pbp_fechaPromesaPago] <> '' THEN 
						CASE WHEN(datediff (day,BPRO.[pbp_fechaPromesaPago],getdate()) >= 0) THEN
						BPRO.[pbp_seleccionable] ELSE 
						'True' END
					 ELSE
					 CASE WHEN 	BPRO.[pbp_fechaVencimiento] <> '' THEN
						CASE WHEN(datediff (day,BPRO.[pbp_fechaVencimiento],getdate()) >= 0) THEN
						BPRO.[pbp_seleccionable] ELSE 
						'True' END
					 END 
					 END  AS seleccionable
					,BPRO.[pbp_numeroSerie]        as numeroSerie
                    ,BPRO.[pbp_facturaProveedor]   as facturaProveedor
					,BPRO.[pbp_esBanco]			   as esBanco
					,BPRO.[pbp_consCartera]		   as consCartera
					,BPRO.[pbp_convenioCIE]        as convenioCIE
					,BPRO.[pbp_autorizado]        as autorizado
					,BPRO.[pbp_cuentaDestinoArr]  as cuentaDestinoArr
					,isnull(MAX(BPRO.[No_CotizacionSISCO]),'Sin Cotizacion SISCO')   as No_CotizacionSISCO
					,isnull(MAX(BPRO.[No_OrdenServicioSISCO]), 'Sin Orden de Servicio') as No_OrdenServicioSISCO
					,isNull(MAX(BPRO.[Id_EstatusSISCO]),0)  as Id_EstatusSISCO
					,isNull(MAX(BPRO.[EstatusSISCO]),'Sin Estatus')  as EstatusSISCO
					,isNull(MAX(BPRO.[FechaFacturaSISCO]), '1900-01-01 00:00:00') as FechaFacturaSISCO
					,isNull(MAX(BPRO.[OperacionSISCO]),'Sin Operacion')  as OperacionSISCO
					,isNull(MAX(BPRO.[FechaCargaCopade]), '1900-01-01 00:00:00') as FechaCargaCopade
					,isNull(MAX(BPRO.[FechaRecepcionCopade]), '1900-01-01 00:00:00') as FechaRecepcionCopade
					,BPRO.[pbp_obsGenerales] as pbp_obsGenerales		
					
		       FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] AS BPRO (NOLOCK)
			   INNER JOIN @pagos AS E 
			          ON BPRO.[pbp_empresa] = @idEmpresa
					 AND BPRO.[pbp_polTipo]        = E.polTipo       
                     AND BPRO.[pbp_polAnnio]       = E.annio
			         AND BPRO.[pbp_polMes]         = E.polMes
			         AND BPRO.[pbp_polConsecutivo] = E.polConsecutivo
			         AND BPRO.[pbp_polMovimiento]  = E.polMovimiento
				     AND BPRO.[pbp_saldo] > 0 
			   LEFT JOIN PAG_AGRUPADOR_PROVEEDOR AS GRP 
			          ON GRP.pap_idProveedor = 	BPRO.[pbp_idProveedor]     

			   LEFT JOIN PAG_CAT_AGRUPADORES AS CAGRP 
			          ON CAGRP.pca_idAgrupador = GRP.pca_idAgrupador 
--               WHERE   (datediff (day,BPRO.[pbp_fechaPromesaPago],getdate()) >= 0)
--				  AND ((BPRO.[pbp_fechaPromesaPago] <> '') or (BPRO.[pbp_fechaVencimiento] <> ''))
			
			GROUP BY 
			
			BPRO.[pbp_polTipo]   
					,BPRO.[pbp_polAnnio]   
					,BPRO.[pbp_polMes]  
					,BPRO.[pbp_polConsecutivo] 
					,BPRO.[pbp_polMovimiento] 
					,BPRO.[pbp_polFechaOperacion]
					,BPRO.[pbp_documento] 
					,BPRO.[pbp_cuenta]     
					,BPRO.[pbp_idProveedor]  
					,BPRO.[pbp_proveedor]     
					,BPRO.[pbp_tipoDocto]    
					,BPRO.[pbp_cartera]    
					,BPRO.[pbp_monto]      
					,BPRO.[pbp_saldo]      
					,BPRO.[pbp_saldoPorcentaje]  
					,BPRO.[pbp_moneda]          
					,BPRO.[pbp_fechaVencimiento] 
					,BPRO.[pbp_fechaPromesaPago]					
					,BPRO.[pbp_fechaRecepcion] 
					,BPRO.[pbp_fechaFactura]  
					,BPRO.[pbp_ordenCompra] 
					,BPRO.[pbp_estatus]     
					,BPRO.[pbp_idEstatus]   
					,BPRO.[pbp_anticipo]   
					,BPRO.[pbp_anticipoAplicado] 
					,BPRO.[pbp_proveedorBloqueado] 
					,BPRO.[pbp_ordenBloqueada]  
					,BPRO.[pbp_diasCobro]      
					,BPRO.[pbp_aprobado]      
					,BPRO.[pbp_contReprog]     
					,BPRO.[pbp_documentoPagable] 
					,BPRO.[pbp_aPagar]          
					,CAGRP.pca_ordenVarchar,CAGRP.pca_descripcion
					,CAGRP.pca_orden
					,BPRO.[pbp_ordenProveedor] 
					,BPRO.[pbp_cuentaPagadora]
					,BPRO.[pbp_cuentaProveedor]  
					,BPRO.[pbp_empresa]         
					,BPRO.[pbp_cuentaDestino]   
                    ,BPRO.[pbp_seleccionable]   
					,BPRO.[pbp_numeroSerie]      
                    ,BPRO.[pbp_facturaProveedor]  
					,BPRO.[pbp_esBanco]			  
					,BPRO.[pbp_consCartera]		
					,BPRO.[pbp_convenioCIE]    
					,BPRO.[pbp_autorizado]     
					,BPRO.[pbp_cuentaDestinoArr] 
					,BPRO.[pbp_obsGenerales]
					
			
			ORDER by BPRO.[pbp_idProveedor],BPRO.[pbp_documento]  desc
--4060
--1619
        END TRY

	BEGIN CATCH
	     --SELECT 'ERROR EN LA CONSULTA'
		 PRINT ('Error: ' + ERROR_MESSAGE())
		 DECLARE @Mensaje  nvarchar(max),
		 @Componente nvarchar(50) = '[SEL_PROGRAMACION_PAGOS_SP]'
		 SELECT @Mensaje = ERROR_MESSAGE()
		 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
		 SELECT 0 --Encontro error
	END CATCH
END
--drop table #PAG_PROGRA_PAGOS_detalle_TEMP
go

