


-- ==========================================================================================
-- Author:	Fernando Alvarado Luna	
-- Create date: 18/05/2016
-- Description:	Procedimeinto que trae la información agrupada por proveedor y referencia
-- Modified date: 28/06/2016  Lourdes Maldonado Sánchez(LMS)
-- Description:	Consulta para que obtenga el nombre de la base dinamicamente
-- ==========================================================================================
--EXECUTE [SEL_PROG_PAGOS_TXT_SP2] 19713  
CREATE PROCEDURE [dbo].[SEL_PROG_PAGOS_TXT_SP2] 
	      @idPadre      numeric(18,0) = 0
AS
BEGIN
	SET NOCOUNT ON;
  BEGIN TRY

        DECLARE @idEmpresa numeric(18,0) = 0
	      
	    SELECT @idEmpresa = [pal_id_empresa]  
		 FROM [Pagos].[dbo].[PAG_LOTE_PAGO]
		 WHERE [pal_id_lote_pago] = @idPadre
	    --SELECT @idEmpresa
	    ---------------------------------------------------------------
		--  Buscamos la  IP del Servidor y  la Base                  --
		---------------------------------------------------------------
		DECLARE @ipServidor    VARCHAR(100);
		DECLARE @cadIpServidor VARCHAR(100);
		DECLARE @nombreBase    VARCHAR(100);
		DECLARE @campos        VARCHAR(max);
		DECLARE @campos1        VARCHAR(max);
		DECLARE @campos2        VARCHAR(max);
		DECLARE @tabla         VARCHAR(max);
		DECLARE @condicion     VARCHAR(max);
		DECLARE @consultaSaldo VARCHAR(max);
		DECLARE @totalSaldo     decimal(18,5);
		DECLARE @select         VARCHAR(max);

		SELECT @nombreBase = [nombre_base]        
			  ,@ipServidor = [ip_servidor]      
		FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
		WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
									FROM [ControlAplicaciones].[dbo].[cat_empresas]
								WHERE [emp_idempresa] = @idEmpresa)
		  AND tipo = 2

       -- select @nombreBase, @ipServidor
		---------------------------------------------------------------
		--  Para cambiar la consulta si es local o no                --
		---------------------------------------------------------------
		set @cadIpServidor =' [' + @ipServidor + '].'
		
		IF (@ipServidor ='192.168.20.29')
		BEGIN
		set @cadIpServidor =''
		END



		DECLARE @empresa numeric(18,0) = (SELECT pal_id_empresa FROM [dbo].[PAG_LOTE_PAGO] WHERE pal_id_lote_pago = @idPadre)
		DECLARE @usuario numeric(18,0) = (SELECT pal_id_usuario FROM [dbo].[PAG_LOTE_PAGO] WHERE pal_id_lote_pago = @idPadre)

		--UPDATE Pagos.dbo.[PAG_LOTE_PAGO] SET pal_estatus = 4 WHERE (pal_id_empresa = @empresa AND pal_id_lote_pago = @idPadre)
		--EXECUTE [INS_APLICA_LOTE_SP] @empresa,@idPadre,@usuario	
      ---------------------------------------------------------------
		--  Obtenemos la consulta                      --
		---------------------------------------------------------------
		DECLARE     @VariableTabla TABLE (ID INT IDENTITY(1,1)
		                                 ,idPadre           int
										 ,nombreLote   	    nvarchar(150)
										 ,idUsuario	        nvarchar(50)
										 ,fechaRegistro	    datetime
										 ,idProveedor       int  
										 ,proveedor         nvarchar(250)
										 ,rfc   	        nvarchar(50)
										 ,polTipo	        nvarchar(50)
										 ,annio	            numeric
										 ,polMes	        numeric
										 ,polConsecutivo	numeric
										 ,polMovimiento	    numeric
										 ,documento         nvarchar(100)
										 ,ordenCompra		nvarchar(30)
										 ,idEstatus         nvarchar(3)
										 ,cuentaPagadora    nvarchar(55)
										 --
										 ,cuentaOrigen       nvarchar(55)
										 ,numBancoOrigen     nvarchar(4)
										 ,nombreBancoOrigen  nvarchar(55)
										 ,sucursalOrigen     nvarchar(4)
										 ,tipoCtaOrigen      nvarchar(10)
										 ,numCtaOrigen       nvarchar(55)
										 --
										 ,cuentaDestino       nvarchar(55)
										 ,numeroBancoBCO      nvarchar(4)
										 ,numBancoDestino     nvarchar(4)
										 ,convenioCie		  nvarchar(10)
										 ,nombreBancoDestino  nvarchar(55)
										 ,sucursalDestino     nvarchar(4)
										 ,tipoCtaDestino      nvarchar(10)
										 ,numCtaDestino       nvarchar(18)
										 ,numCtaClabeDestino  nvarchar(18)
										 ,numRefDestino       nvarchar(30)
										 --
										 ,importe	          decimal(13,2)
										 ,importeSP	          nvarchar(16)
										 ,ivaImporteSP	      nvarchar(16)
										 --
										 ,moneda			 nvarchar(5)
										 ,monedaCte          nvarchar(3)
										 ,razonSocial        nvarchar(30)
										 ,motivoPago         nvarchar(30)
										 ,fecha              nvarchar(10)
										 ,hora               nvarchar(4)
										 ,disponibilidad     nvarchar(2)
										 ,plazo              nvarchar(2)
										 ,referencia	     nvarchar(30)
										 ,agrupar			 int
										 ,autorizacion		 int
										 )

------------------
  SET @campos='D.[pal_id_lote_pago]         AS idPadre
	          ,M.[pal_nombre]               AS nombreLote
	          ,M.[pal_id_usuario]           AS idUsuario
	          ,M.[pal_fecha]                AS fechaRegistro
			  ,D.[pad_idProveedor]          AS idProveedor
			  ,D.[pad_proveedor]			AS proveedor
			  ,(select p.per_rfc  ' +
			  '    from '+@cadIpServidor+'GA_Corporativa.[dbo].[per_personas] p 
				 where p.per_idpersona = D.[pad_idProveedor]) as rfc   
			  ,D.[pad_polTipo]              AS polTipo
			  ,D.[pad_polAnnio]             AS annio
			  ,D.[pad_polMes]			    AS polMes
			  ,D.[pad_polConsecutivo]	    AS polConsecutivo
			  ,D.[pad_polMovimiento]	    AS polMovimiento
			  ,D.[pad_documento]			AS documento
			  ,D.[pad_ordenCompra]			AS ordenCompra
			  ,D.[pad_idEstatus]			AS idEstatus
			     		  ,ISNULL(D.[pad_cuentaProveedor],' +''''+'SIN CUENTA PAGADORA' +''''+')  as cuentaPagadora
	          ,ba.par_descrip1     as cuentaOrigen    
			  ,ba.par_descrip5     as numBancoOrigen
			  ,case when ba.par_descrip5= ' +''''+'002' +''''+'  then ' +''''+'BANAMEX' +''''+'
			        when ba.par_descrip5= ' +''''+'012' +''''+'  then ' +''''+'BANCOMER' +''''+'
					when ba.par_descrip5=' +''''+'014' +''''+'  then ' +''''+'SANTANDER' +''''+'
					when ba.par_descrip5=' +''''+'021' +''''+'  then ' +''''+'HSBC' +''''+'
					when ba.par_descrip5=' +''''+'072' +''''+'  then ' +''''+'BANORTE' +''''+'
					else ' +''''+'Otro Banco' +''''+'
				end    as nombreBancoOrigen        
			   ,right(replicate (' +''''+'0' +''''+',4) + cast ( ISNULL(transbco.PAR_DESCRIP2,' +''''+'0000' +''''+') AS varchar(4)) ,4) as sucursalOrigen    
			   ,case when transbco.PAR_DESCRIP1=' +''''+'CHEQUES' +''''+'  then ' +''''+'03' +''''+'                   
			         else ' +''''+'00' +''''+'
				end as tipoCtaOrigen               
               ,right(replicate (' +''''+'0' +''''+',18) + cast((SELECT numeroCuenta FROM referencias.dbo.BancoCuenta WHERE ((cuenta like ' +''''+'%' +''''+' + D.[pad_cuentaProveedor] +' +''''+'%' +''''+') AND  (idEmpresa = M.[pal_id_empresa]))) AS varchar(25)) ,18) as numCtaOrigen         
	           ,(select top 1 ba.PAR_DESCRIP1
			       from '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] ba
				  where PAR_IDENPARA= b.BCO_BANCO
				    and ba.par_tipopara = ' +''''+'ba' +''''+'
					
					)             as cuentaDestino
			   ,b.BCO_BANCO          as numeroBancoBCO,' 
			   SET @campos1= '(SELECT   TOP 1   PAG_CAT_BANXICO.pbx_numoficial
				FROM     '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] AS ba INNER JOIN
                PAG_CAT_BANXICO ON ba.PAR_DESCRIP5 = PAG_CAT_BANXICO.pbx_numoficial COLLATE SQL_Latin1_General_CP1_CI_AS
				WHERE        (ba.PAR_IDENPARA = b.BCO_BANCO) AND (ba.PAR_TIPOPARA = ' +''''+'ba' +''''+') and (ba.par_status   = ' +''''+'A' +''''+') ORDER BY PAG_CAT_BANXICO.pbx_numoficial)
		       as numBancoDestino, isnull(b.BCO_CONVENIOCIE,' +''''''+') as convenioCie,
			   (SELECT   TOP 1   ba.PAR_DESCRIP1
				FROM      '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] AS ba INNER JOIN
                PAG_CAT_BANXICO ON ba.PAR_DESCRIP5 = PAG_CAT_BANXICO.pbx_numoficial COLLATE SQL_Latin1_General_CP1_CI_AS
				WHERE        (ba.PAR_IDENPARA = b.BCO_BANCO) AND (ba.PAR_TIPOPARA = ' +''''+'ba' +''''+') and (ba.par_status   = ' +''''+'A' +''''+')  ORDER BY PAG_CAT_BANXICO.pbx_numoficial)
		       as nombreBancoDestino,
				right(replicate (' +''''+'0' +''''+',4) + cast ( ISNULL(b.BCO_SUCURSAL,' +''''+'0000' +''''+') AS varchar(4)) ,4) as sucursalDestino     											   
                 ,CASE WHEN b.bco_clabe is null  THEN ' +''''+'03' +''''+' 
					  ELSE  ' +''''+'40' +''''+'                           
				  END  as tipoCtaDestino       
				,right(replicate (' +''''+'0' +''''+',18) + cast ( b.bco_numcuenta AS varchar(25)) ,18) as numCtaDestino
				,right(replicate (' +''''+'0' +''''+',18) + cast ( b.bco_clabe     AS varchar(20)) ,18) as numCtaClabeDestino
				,b.bco_refernum as numRefDestino                                                          
				,replicate (' +''''+'0' +''''+',13)+  cast(ROUND(d.[pad_saldo], 2) as decimal(13,2)) as importe 
				,REPLACE(CAST(CAST(ROUND(d.[pad_saldo], 2)  as decimal(13,2)) as varchar(16)),' +''''+'.' +''''+',' +''''+'' +''''+')                 as importeSP     
				,REPLACE(CAST(CAST(ROUND((d.[pad_saldo])*0.16, 2) as decimal(13,2)) as varchar(16)),' +''''+'.' +''''+',' +''''+'' +''''+')           as ivaImporteSP 
				,case when d.[pad_moneda]=' +''''+'PE' +''''+' then ' +''''+'MXP' +''''+' 
						else ' +''''+'Otro' +''''+'
						end as moneda    
				,' +''''+'000' +''''+'  as monedaCte          
				,left(cast ( D.[pad_proveedor] AS varchar(30)) + replicate (' +''''+' ' +''''+',30) ,30)                               as razonSocial
				,left(cast ( ISNULL(D.[pad_ordenCompra],replicate (' +''''+' ' +''''+',24)) AS varchar(24)) + replicate (' +''''+' ' +''''+',24) ,24)  as motivoPago 
				,REPLACE(CONVERT(VARCHAR(10),GETDATE(),5),' +''''+'-' +''''+',' +''''+'' +''''+')                      as fecha     
				,REPLACE(CONVERT(VARCHAR(5), GETDATE(), 108),' +''''+':' +''''+',' +''''+'' +''''+')                   as hora      
				,' +''''+'H' +''''+'       as disponibilidad                               
				,' +''''+'00' +''''+'      as plazo
				,D.pad_polReferencia     as referencia, D.pad_agrupamiento as agrupar,
				b.BCO_AUTORIZADA as autorizacion'

		SET @tabla= ' [dbo].[PAG_LOTE_PAGO] M  
		        INNER JOIN [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] as D ON D.[pal_id_lote_pago] = M.[pal_id_lote_pago] AND D.[pal_id_lote_pago] = '+ cast (@idPadre as varchar(18)) +'
				LEFT OUTER JOIN '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] ba ON ba.par_tipopara = ' +''''+'ba' +''''+' and ba.par_status=' +''''+'A' +''''+' and ba.par_descrip1 = D.[pad_cuentaProveedor] COLLATE Modern_Spanish_CI_AS
		        LEFT OUTER JOIN '+ @cadIpServidor + ' GA_Corporativa.[dbo].[per_personas] p ON p.per_idpersona = D.[pad_idProveedor]
				LEFT OUTER JOIN '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[CON_BANCOS]   b ON b.bco_idpersona = D.[pad_idProveedor] AND B.BCO_NUMCUENTA = D.pad_cuentaDestino   COLLATE Modern_Spanish_CI_AS 
			    LEFT OUTER  JOIN '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] tu ON tu.par_idenpara = b.bco_tipcuenta and tu.par_tipopara     = ' +''''+'tu' +''''+'
				LEFT OUTER JOIN '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] transbco ON transbco.par_tipopara = ' +''''+'TRANSBCO' +''''+' and  transbco.PAR_DESCRIP5 =(SELECT TOP 1 ccheq.PAR_IDENPARA 
																																					FROM '+ @cadIpServidor + '['+  @nombreBase +'].[dbo].[PNC_PARAMETR] ccheq
																																					WHERE ccheq.par_tipopara = ' +''''+'ccheq' +''''+' 
																																					AND ccheq.PAR_DESCRIP2 = (SELECT TOP 1 [pcp_claveCuentaPagadora]
																																													FROM [Pagos].[dbo].[PAG_CAT_PROVEEDORES]
			        																																								WHERE [pcp_idProveedor]  = D.[pad_idProveedor]) COLLATE Modern_Spanish_CI_AS) order by D.[pad_idProveedor]'
		
		
		
		SET @condicion= ' b.BCO_AUTORIZADA = 1 '
        --select @campos
		--select @tabla
		--select @condicion
		set @select = ' SELECT ' + @campos + @campos1 +'   FROM ' +  @tabla  
        
		select @select
															         
		INSERT INTO  @VariableTabla  EXEC ( ' SELECT  ' + @campos + @campos1 +
		                                   '   FROM ' +  @tabla  +';');

		--	IF EXISTS
		--			(
		--		SELECT 1
		--		FROM @VariableTabla 
		--		WHERE autorizacion <> 1 
		--		)
		--	BEGIN
								
		----	SELECT 'HAY UNA CUENTA SIN AUTORIZAR'

		--	END
		
    
        SELECT DISTINCT idPadre,nombreLote,idUsuario,fechaRegistro,idProveedor,proveedor,rfc,
				'0' as idEstatus,cuentaPagadora,cuentaOrigen,numBancoOrigen,nombreBancoOrigen,
				sucursalOrigen,tipoCtaOrigen,numCtaOrigen,cuentaDestino,numeroBancoBCO,
				numBancoDestino,convenioCie, nombreBancoDestino,sucursalDestino,tipoCtaDestino,
				numCtaDestino,numCtaClabeDestino,numRefDestino,
				SUM(importe) AS "importeTotal", '0' as motivoPago,
				moneda,monedaCte,razonSocial,fecha,hora,disponibilidad,plazo,referencia,agrupar
		FROM  @VariableTabla AS  V
		GROUP BY idPadre,nombreLote,idUsuario,fechaRegistro,idProveedor,proveedor,rfc,
				cuentaPagadora,cuentaOrigen,numBancoOrigen,nombreBancoOrigen,
				sucursalOrigen,tipoCtaOrigen,numCtaOrigen,cuentaDestino,numeroBancoBCO,
				numBancoDestino,convenioCie, nombreBancoDestino,sucursalDestino,tipoCtaDestino,
				numCtaDestino,numCtaClabeDestino,numRefDestino,
				moneda,monedaCte,razonSocial,fecha,hora,disponibilidad,plazo,referencia,agrupar

  END TRY
  
  BEGIN CATCH
	 PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_PROG_PAGOS_TXT_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 --SELECT 0 --Encontro error
	 SELECT 'ERROR EN LA CONSULTA'
  END CATCH
END


go

