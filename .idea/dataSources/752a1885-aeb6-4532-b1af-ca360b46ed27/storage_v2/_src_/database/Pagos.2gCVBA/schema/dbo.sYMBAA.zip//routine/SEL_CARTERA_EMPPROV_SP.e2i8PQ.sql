--exec [dbo].[SEL_CARTERA_EMPPROV_SP] '1','167',0
--exec [dbo].[SEL_CARTERA_EMPPROV_SP] '1','167',1

CREATE PROCEDURE [dbo].[SEL_CARTERA_EMPPROV_SP]
	 @IdEmpresa VARCHAR (20) 
	,@IdProveedor VARCHAR (20) 
	,@Vencida INT = 0

AS
BEGIN
SET NOCOUNT ON;

DECLARE @Concentradora VARCHAR(1000)
		,@sql NVARCHAR(1000)
		,@Empresa VARCHAR(50)



	DECLARE @Server VARCHAR(100) =(
	SELECT local_net_address
    FROM sys.dm_exec_connections
    WHERE Session_id = @@SPID)

	SELECT	@Concentradora = CASE WHEN @Server =  ip_servidor THEN  '[' + nombre_base + '].[dbo].' 
							 ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END
	FROM	[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
	WHERE	tipo  = 2 
	AND		emp_idempresa = @IdEmpresa

	SELECT	@Empresa = emp_nombre 
	FROM	ControlAplicaciones.dbo.cat_empresas 
	WHERE	emp_idempresa = @IdEmpresa


IF (@Vencida = 1)
BEGIN

SET @sql = 'SELECT  pbp_consCartera, '  + char(13) + 
			''+char(39)+@Empresa		+char(39)+' Empresa, '		+ char(13) + 
			'		pbp_documento,'		+ char(13) + 
			'		pbp_tipoDocto,'		+ char(13) + 
			'		pbp_cartera,'		+ char(13) + 
			'		pbp_monto, '		+ char(13) + 
			'		pbp_saldo,'			+ char(13) + 
			'		ISNULL(CONVERT(varchar(10),pbp_fechaVencimiento,103),'+char(39)+char(39)+') pbp_fechaVencimiento, ' + char(13) + 
			'		ISNULL(CONVERT(varchar(10),pbp_fechaPromesaPago,103),'+char(39)+char(39)+') pbp_fechaPromesaPago,' + char(13) + 
			'		ISNULL(CONVERT(varchar(10),pbp_fechaFactura,103),'+char(39)+char(39)+') pbp_fechaFactura,'     + char(13) + 
			'       pbp_polAnnio ' + char(13) + 
			--' '+char(39)+'false'+char(39)+' seleccionada,  ' + char(13) + 
			--' '+char(39)+'false'+char(39)+' unSelect  ' + char(13) + 
			' FROM	'+ @Concentradora +'[BI_CARTERA_PAGOS]'  + char(13) +
			' WHERE  pbp_empresa = ' + @IdEmpresa +' and pbp_idProveedor = ' + @IdProveedor  + char(13) +
			' AND   CASE  ' + char(13) +
			' WHEN pbp_fechaPromesaPago = CONVERT(DATETIME,'+char(39)+'1900-01-01 00:00:00.000'+char(39)+') THEN pbp_fechaVencimiento ' + char(13) +
			' WHEN pbp_fechaPromesaPago <> CONVERT(DATETIME,'+char(39)+'1900-01-01 00:00:00.000'+char(39)+')  THEN pbp_fechaPromesaPago ' + char(13) +
			' END <= GETDATE() ' + char(13)
END
ELSE
BEGIN

SET @sql = 'SELECT  pbp_consCartera, '  + char(13) + 
			''+char(39)+@Empresa		+char(39)+' Empresa, '		+ char(13) + 
			'		pbp_documento,'		+ char(13) + 
			'		pbp_tipoDocto,'		+ char(13) + 
			'		pbp_cartera,'		+ char(13) + 
			'		pbp_monto, '		+ char(13) + 
			'		pbp_saldo,'			+ char(13) + 
			'		ISNULL(CONVERT(varchar(10),pbp_fechaVencimiento,103),'+char(39)+char(39)+') pbp_fechaVencimiento, ' + char(13) + 
			'		ISNULL(CONVERT(varchar(10),pbp_fechaPromesaPago,103),'+char(39)+char(39)+') pbp_fechaPromesaPago,' + char(13) + 
			'		ISNULL(CONVERT(varchar(10),pbp_fechaFactura,103),'+char(39)+char(39)+') pbp_fechaFactura,'     + char(13) + 
			'       pbp_polAnnio ' + char(13) + 
			--' '+char(39)+'false'+char(39)+' seleccionada,  ' + char(13) + 
			--' '+char(39)+'false'+char(39)+' unSelect  ' + char(13) + 
			' FROM	'+ @Concentradora +'[BI_CARTERA_PAGOS]'  + char(13) +
			' WHERE  pbp_empresa = ' + @IdEmpresa +' and pbp_idProveedor = ' + @IdProveedor  + char(13) 
END





PRINT @SQL
EXEC  sp_executesql @sql
END
go

