-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 04/03/2016
-- Description:	Proveedores
--              Me regresa todos los Proveedores del grupo con su cuentaPagadora
--              [Pagos].[dbo].[PAG_CAT_PROVEEDORES] 
-- ==========================================================================================
--EXECUTE [SEL_PROVEEDORES_CTA_PAGADORA_SP] 4
CREATE PROCEDURE [dbo].[SEL_PROVEEDORES_CTA_PAGADORA_SP]
	@idEmpresa numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		DECLARE @ipServidor    VARCHAR(100);
		DECLARE @nombreBase    VARCHAR(100);
		DECLARE @cadIpServidor VARCHAR(100);
		DECLARE @select        VARCHAR(max);
		DECLARE @campos        VARCHAR(max);
		DECLARE @tabla         VARCHAR(max);
		DECLARE @condicion     VARCHAR(max);

		SELECT @nombreBase = [nombre_base]        
			  ,@ipServidor = [ip_servidor]      
		  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
		 WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
		   							 FROM [ControlAplicaciones].[dbo].[cat_empresas]
								    WHERE [emp_idempresa] = @idEmpresa)
		  AND tipo = 2
        
		--SELECT @nombreBase,@ipServidor
		---------------------------------------------------------------
		--  Para cambiar la consulta si es local o no                --
		---------------------------------------------------------------
		DECLARE @ipPagos VARCHAR(100) = (SELECT ppa_valor  FROM [dbo].[PAG_PARAMETROS] WHERE ppa_nombre = 'BASE PAGOS')

		DECLARE @ipBPRO VARCHAR(100) = (SELECT ppa_valor  FROM [dbo].[PAG_PARAMETROS] WHERE ppa_nombre = 'BASE BPRO')


		set @cadIpServidor =' [' + @ipPagos + '].'
		
		IF (@ipServidor ='192.168.20.29')
		BEGIN
		set @cadIpServidor =''
		END


		--SELECT  @cadIpServidor
		---------------------------------------------------------------
		--            CONSULTA DINAMICA                              --
		---------------------------------------------------------------
		DECLARE     @VariableTabla TABLE (ID INT IDENTITY(1,1)
										 ,idProveedor	 INT
										 ,nomProveedor   NVARCHAR(250)
										 )

		SET @campos=' P.[per_idpersona] as idProveedor ' +
		            ', LTRIM(RTRIM(replace(replace(P.[per_paterno],'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+') +'+''''+' '+''''+' + replace(replace(P.[per_materno],'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+') + '+''''+' '+''''+' + P.[per_nomrazon]))   as nomProveedor  ' 

		SET @tabla= @cadIpServidor + '[BDPersonas].[dbo].[cat_personas] P, ' +
		            @cadIpServidor + '[BDPersonas].[dbo].[per_relacionroles] R, ' +
					@cadIpServidor + '[BDPersonas].[dbo].[cat_roles] O   '
		SET @condicion= 'P.[per_idpersona] = R.[per_idpersona] ' +
		                'AND R.[rol_idrol] in (0,18,19,20,21)  ' +            
		                'AND R.[rol_idrol] = O.[rol_idrol]  ' 

		SET  @select = ' SELECT ' + @campos  + '   FROM  ' + @tabla +'    WHERE ' + @condicion +';' 
		--SELECT  @select
		
		INSERT INTO  @VariableTabla EXEC( @select );
        
		
		SELECT ISNULL(C.[pcp_id],0)                                 AS  id
		      ,ISNULL(C.[pcp_idEmpresa],0)                          AS  idEmpresa
			  ,V.idProveedor                                        AS  idProveedor       
			  ,V.nomProveedor                                       AS  nombreProveedor
			  ,ISNULL(C.[pcp_cuentaProveedor],0)                    AS  idCuentaPagadora
			  ,ISNULL(C.[pcp_cuentaPagadora],'SIN CUENTA PAGADORA') AS  cuentaPagadora 
		  FROM @VariableTabla  V
			   LEFT OUTER JOIN  [Pagos].[dbo].[PAG_CAT_PROVEEDORES] C ON  C.[pcp_idProveedor] = V.idProveedor  --AND C.[pcp_idEmpresa] = @idEmpresa  


	
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_PROVEEDORES_CTA_PAGADORA_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
     SELECT 'ERROR SEL_PROVEEDORES_CTA_PAGADORA_SP'
END CATCH		     
END

go

