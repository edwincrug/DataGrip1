-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 11/03/2016
-- Description:	Cuentas de Ingreso por empresa 
-- =============================================
--EXECUTE [SEL_CUENTAS_INGRESOS_SP] 1,0                         
CREATE PROCEDURE [dbo].[SEL_CUENTAS_INGRESOS_SP]
	@idEmpresa numeric(18,0)=0
	,@numLote   numeric(18,0)=0   

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
--Total de la empresa sino tiene lote y si lo tiene se tiene que traer el total de la empresa menos lo contenido en los lotes
		DECLARE @ipServidor    VARCHAR(100);
		DECLARE @nombreBase    VARCHAR(100);
		DECLARE @cadIpServidor VARCHAR(100);
		DECLARE @select        VARCHAR(max);
		DECLARE @campos        VARCHAR(max);
		DECLARE @tabla         VARCHAR(100);
		DECLARE @condicion     VARCHAR(100);

		SELECT @nombreBase = [nombre_base]        
			  ,@ipServidor = [ip_servidor]      
		FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
		WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
									FROM [ControlAplicaciones].[dbo].[cat_empresas]
								WHERE [emp_idempresa] = @idEmpresa)
		  AND tipo = 2
        --select @nombreBase, @ipServidor
		---------------------------------------------------------------
		--  Para cambiar la consulta si es local o no                --
		---------------------------------------------------------------
		set @cadIpServidor =' [' + @ipServidor + '].'
		
		IF (@ipServidor ='192.168.20.29')
		BEGIN
		set @cadIpServidor =''
		END

		---------------------------------------------------------------
		--  CUENTAS DE INGRESO                                       --
		---------------------------------------------------------------
		IF (@numLote = 0)
		BEGIN

		SET @campos= ' CONVERT(nvarchar(50), P.PAR_IDENPARA)   AS id ' +  
		             ' ,CASE WHEN P.PAR_DESCRIP4 like  '+ ''''+'%BANCOMER%'+''''+' THEN '+''''+'BANCOMER' + '''' +
					 '       WHEN P.PAR_DESCRIP4 like ' + ''''+'%BANAMEX%' +'''' + '  THEN ' + '''' +'BANAMEX' +'''' +
					 '       WHEN P.PAR_DESCRIP4 like ' + ''''+'%BANORTE%' +'''' + '  THEN ' + '''' +'BANORTE' +'''' +
					 '       WHEN P.PAR_DESCRIP4 like ' + ''''+'%HSBC%' +'''' + '  THEN ' + '''' +'HSBC' +'''' +
					 '       WHEN P.PAR_DESCRIP4 like ' + ''''+'%SANTANDER%' +'''' + '  THEN ' + '''' +'SANTANDER' +'''' +
					 '       WHEN P.PAR_DESCRIP4 like ' + ''''+'%MIFEL%' +'''' + '  THEN ' + '''' +'MIFEL' +'''' +
					 '       WHEN P.PAR_DESCRIP4 like ' + ''''+'%BANSI%' +'''' + '  THEN ' + '''' +'BANSI' +'''' +
					 '       WHEN P.PAR_DESCRIP4 like ' + ''''+'%AZTECA%' +'''' + '  THEN ' + '''' +'AZTECA' +'''' +
					 '       ELSE '+'''' +'Otro' +'''' +
					 '  END  banco ' +
					 --NUMERO CUENTA
	                 --'  ,SUBSTRING(PAR_DESCRIP1,CHARINDEX('+''''+' '+''''+' ,PAR_DESCRIP1)+1, LEN(PAR_DESCRIP1))  AS cuenta ' +  
					 '  ,UPPER(P.PAR_DESCRIP4)  AS cuenta ' +
					 
					 ' ,CASE WHEN (ISNULL((SELECT TOP 1 I.[pib_disponible] AS id
								             FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS] I
									             ,[Pagos].[dbo].[PAG_LOTE_PAGO]           L
								            WHERE I.[pal_id_lote_pago] = L.[pal_id_lote_pago]
											  AND I.[pib_id_cuenta]   = P.PAR_DESCRIP4  COLLATE Modern_Spanish_CI_AS
											  AND datediff (day,L.[pal_fecha],getdate()) = 0 --0 para que sea hoy
										  ORDER BY I.[pib_id] DESC),0.00000)) = 0 THEN  0
						ELSE 
							(SELECT TOP 1 I.[pib_disponible] AS id
													 FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS] I
														 ,[Pagos].[dbo].[PAG_LOTE_PAGO]           L
													WHERE I.[pal_id_lote_pago] = L.[pal_id_lote_pago]
													  AND I.[pib_id_cuenta]   = P.PAR_DESCRIP4  COLLATE Modern_Spanish_CI_AS
													  AND datediff (day,L.[pal_fecha],getdate()) = 0 --0 para que sea hoy
												  ORDER BY I.[pib_id] DESC)										  													
						END AS saldo ' +
					 '  ,0.00000  AS disponible ' 
					 +'  ,PAR_DESCRIP2 AS cuentaContable  '
		SET @tabla='.[dbo].[PNC_PARAMETR]  P'
		SET @condicion= 'P.PAR_TIPOPARA = '+ ''''+ 'CCHEQ' + '''' + '   AND P.PAR_STATUS = ' + '''' +'A' + ''''
		               -- + 'AND P.PAR_IDENPARA IN ('+''''+'Z01'+''''+','+''''+'Z11'+''''+','+''''+'Z10'+''''+') '
		SET  @select = ' SELECT ' + @campos  + '   FROM  ' + @cadIpServidor + '['+  @nombreBase +']'+ @tabla +'    WHERE  ' + @condicion +';' 
		--select @select


		---------------------------------------------------------------
		--  Obtenemos la consulta dinamicamente                      --
		---------------------------------------------------------------
		DECLARE     @VariableTabla TABLE (id            nvarchar(50)       --Alexxxxxx
										 ,banco	        nvarchar(50)
										 ,cuenta	    nvarchar(50)
										 ,saldo	        decimal(18,5)
										 ,disponible	decimal(18,5)
										 ,cuentaContable      nvarchar(50)
										 )
									
        INSERT INTO  @VariableTabla  EXEC(@select);
      
		SELECT * FROM  @VariableTabla
		END
		ELSE
		BEGIN
		        SELECT CONVERT(nvarchar(50), pib_id)  as id
				      ,[pib_id_cuenta]                as banco
					  ,UPPER([pib_id_cuenta])         as cuenta
					  ,[pib_saldo]                    as saldo      
					  ,[pib_disponible]               as disponible
					  ,ISNULL([pib_cuentaContable],'Actualizar valor')  as cuentaContable             --Checar 
				  FROM [Pagos].[dbo].[PAG_FLUJO_INGRESO_BANCOS] 
                 WHERE [pal_id_lote_pago] = @numLote
		END


END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_CUENTAS_INGRESOS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Encontro error'
END CATCH		     
END


go

