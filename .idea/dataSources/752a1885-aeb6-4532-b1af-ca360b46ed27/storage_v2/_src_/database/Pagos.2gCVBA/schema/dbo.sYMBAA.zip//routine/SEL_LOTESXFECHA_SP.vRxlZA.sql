
-- ====================================================
-- Author:		Fernando Alvarado Luna	
-- Create date: 03/08/2017
-- Description:	Busqueda de los lotes x un rango de Fecha
-- Este SP debe ser solo por empresa
-- ====================================================
--EXECUTE [SEL_LOTESXFECHA_SP] 1,77,'2016-11-15','2018-11-17',1
CREATE PROCEDURE [dbo].[SEL_LOTESXFECHA_SP]
	 @idEmpresa numeric(18,0)=0,
	 @idUsuario numeric(18,0)=0,
	 @fecha_ini varchar(15)= '',
	 @fecha_fin varchar(15)= '',
	 @estatus int = 0

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		

	        SELECT   L.[pal_id_lote_pago]    as idLotePago
					,L.[pal_id_empresa]      as idEmpresa
					,L.[pal_id_usuario]      as idUsuario
					,L.[pal_fecha]           as fecha
					,L.[pal_nombre]          as nombre
					,L.[pal_estatus]         as estatus
					,SUM(D.[pad_saldo])      as totalPagar
					,L.[pal_esAplicacionDirecta]         as pal_esAplicacionDirecta
					,D.[pad_bancoPagador] as bancoPagador
					,E.[pel_descripcion] AS descLote
					,'ERRORES' AS descerror
					,T.[ptl_nombreTipoPago] AS nombretipo
					,COUNT(D.[pal_id_lote_pago]) AS numdetalle
					,(SELECT COUNT(DP.[dpa_lote]) FROM [cuentasxpagar].[dbo].[cxp_doctospagados] DP WHERE DP.[dpa_lote] = L.[pal_id_lote_pago] and ((DP.[dpa_pagoaplicado] = 2) OR (DP.[dpa_pagoaplicado] = 0))) AS numpendiente
					,(SELECT COUNT(DP.[dpa_lote]) FROM [cuentasxpagar].[dbo].[cxp_doctospagados] DP WHERE DP.[dpa_lote] = L.[pal_id_lote_pago] and  DP.[dpa_pagoaplicado] = 1) AS numaplicado
					,D.[pad_bancoPagador] AS cuentaPago
			  FROM  [Pagos].[dbo].[PAG_LOTE_PAGO] L
					--LEFT JOIN [cuentasxpagar].[dbo].[cxp_logaplicacion] LO ON LO.[lap_lote]= L.[pal_id_lote_pago]
				   ,[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
				   ,[Pagos].[dbo].[PAG_ESTATUS_LOTE] E
				   ,[Pagos].[dbo].[PAG_TIPO_LOTE] T
				   --,
			 WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
			   AND L.[pal_id_empresa] = @idEmpresa
			   --AND L.[pal_id_lote_pago] =@idLote
			   AND L.[pal_estatus] = E.[pel_id_estatus_pago]
			   AND L.[pal_fecha] >= CONVERT(datetime, @fecha_ini, 120)
			   AND L.[pal_fecha] < DATEADD(day,1,(CONVERT(datetime, @fecha_fin, 120)))
			   AND D.[pad_aPagar] = 1
			   AND T.[ptl_id_tipoLotePago] = L.[pal_id_tipoLotePago]
			   AND L.[pal_estatus] >= @estatus
			   AND D.[pal_id_lote_pago] not in (select distinct pal_id_lote_pago from [Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE_BITACORA])
			   --

             GROUP BY L.[pal_id_lote_pago],L.[pal_id_empresa],L.[pal_id_usuario],L.[pal_fecha],L.[pal_nombre],L.[pal_estatus],L.[pal_esAplicacionDirecta],D.[pad_bancoPagador],E.[pel_descripcion],T.[ptl_nombreTipoPago],D.[pal_id_lote_pago],D.[pad_bancoPagador]
			  UNION 
			 SELECT   L.[pal_id_lote_pago]    as idLotePago
					,L.[pal_id_empresa]      as idEmpresa
					,L.[pal_id_usuario]      as idUsuario
					,L.[pal_fecha]           as fecha
					,L.[pal_nombre]          as nombre
					,L.[pal_estatus]         as estatus
					,SUM(D.[pad_saldo])      as totalPagar
					,L.[pal_esAplicacionDirecta]         as pal_esAplicacionDirecta
					,D.[pad_bancoPagador] as bancoPagador
					,E.[pel_descripcion] AS descLote
					,'ERRORES' AS descerror
					,T.[ptl_nombreTipoPago] AS nombretipo
					,COUNT(D.[pal_id_lote_pago]) AS numdetalle
					,(SELECT COUNT(DP.[dpa_lote]) FROM [cuentasxpagar].[dbo].[cxp_doctospagados] DP WHERE DP.[dpa_lote] = L.[pal_id_lote_pago] and ((DP.[dpa_pagoaplicado] = 2) OR (DP.[dpa_pagoaplicado] = 0))) AS numpendiente
					,(SELECT COUNT(DP.[dpa_lote]) FROM [cuentasxpagar].[dbo].[cxp_doctospagados] DP WHERE DP.[dpa_lote] = L.[pal_id_lote_pago] and  DP.[dpa_pagoaplicado] = 1) AS numaplicado
					,D.[pad_bancoPagador] AS cuentaPago
			  FROM  [Pagos].[dbo].[PAG_LOTE_PAGO] L
					--LEFT JOIN [cuentasxpagar].[dbo].[cxp_logaplicacion] LO ON LO.[lap_lote]= L.[pal_id_lote_pago]
				   ,[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE_BITACORA] D
				   ,[Pagos].[dbo].[PAG_ESTATUS_LOTE] E
				   ,[Pagos].[dbo].[PAG_TIPO_LOTE] T
				   --,
			 WHERE L.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
			   AND L.[pal_id_empresa] = @idEmpresa
			   --AND L.[pal_id_lote_pago] =@idLote
			   AND L.[pal_estatus] = E.[pel_id_estatus_pago]
			   AND L.[pal_fecha] >= CONVERT(datetime, @fecha_ini, 120)
			   AND L.[pal_fecha] < DATEADD(day,1,(CONVERT(datetime, @fecha_fin, 120)))
			   AND D.[pad_aPagar] = 1
			   AND T.[ptl_id_tipoLotePago] = L.[pal_id_tipoLotePago]
			   AND L.[pal_estatus] >= @estatus
			   --

             GROUP BY L.[pal_id_lote_pago],L.[pal_id_empresa],L.[pal_id_usuario],L.[pal_fecha],L.[pal_nombre],L.[pal_estatus],L.[pal_esAplicacionDirecta],D.[pad_bancoPagador],E.[pel_descripcion],T.[ptl_nombreTipoPago],D.[pal_id_lote_pago],D.[pad_bancoPagador]



END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END


go

