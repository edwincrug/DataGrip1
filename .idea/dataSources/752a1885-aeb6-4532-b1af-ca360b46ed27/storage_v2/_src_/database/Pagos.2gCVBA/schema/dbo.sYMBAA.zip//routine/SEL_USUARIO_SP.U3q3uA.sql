

-- =============================================
-- Create date: 23/06/2017
-- Description:	Obtengo los datos del usuario logueado por el panel de aplicaciones 
-- =============================================
-- [dbo].[SEL_USUARIO_SP] 71
CREATE PROCEDURE [dbo].[SEL_USUARIO_SP] 
	@idUsuario NUMERIC(18,0)
AS
BEGIN
	SELECT	[usu_idusuario] AS idUsuario
			,[usu_nombreusu] AS nombreUsuario
			,[usu_paterno] AS apaterno
			,[usu_materno] AS amaterno
			,[usu_nombre] AS nombre
			,[usu_correo] AS correo
			,[pto_idpuesto] AS idPuesto
	FROM	[ControlAplicaciones].[dbo].[cat_usuarios]
	WHERE usu_idusuario = @idUsuario 
END


go

