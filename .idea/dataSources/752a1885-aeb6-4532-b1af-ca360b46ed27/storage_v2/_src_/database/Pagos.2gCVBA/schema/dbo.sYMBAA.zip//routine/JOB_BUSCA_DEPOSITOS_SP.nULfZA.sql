

-- =============================================
-- Author:		FAL
-- Create date: 19042017
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [JOB_BUSCA_DEPOSITOS_SP] 3
-- =============================================
-- Author:		DCG
-- Update date: 12042018
-- Description:	Se agrega (NOLOCK) a las consultas de tablas ordinarias,
-- para que no se bloquen los procesos
-- =============================================

CREATE PROCEDURE [dbo].[JOB_BUSCA_DEPOSITOS_SP]
	
	 @emp_idempresa INT = 0
		
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @total INT = (SELECT  COUNT(concepto)  FROM  referencias.dbo.Bancomer with (NOLOCK) where (((concepto LIKE 'SPEI%' AND refAmpliada LIKE '%-%-%') OR (concepto LIKE 'TRASPASO%' AND refAmpliada LIKE '%-%-%')) AND ((estatus = 1) AND (esCargo = 1))))	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), idBmer INT, concepto nvarchar(50) NULL, refAmpliada nvarchar(50) null, importe numeric(18,6))
										
				INSERT INTO @VariableTabla (idBmer,concepto,refAmpliada,importe) 

				SELECT        idBmer,concepto, refAmpliada, importe
				FROM            referencias.dbo.Bancomer with (NOLOCK)
				where (((concepto LIKE 'SPEI%' AND refAmpliada LIKE '%-%-%') OR (concepto LIKE 'TRASPASO%' AND refAmpliada LIKE '%-%-%')) AND ((estatus = 1) AND (esCargo = 1)))

				WHILE(@aux <=  @total)
						BEGIN
						declare @refPropia as nvarchar(100)
						declare @idBanco as int
						declare @varconcepto as nvarchar (50)
						
						SELECT @varconcepto = concepto, @idBanco = idBmer,  @refPropia = refAmpliada FROM @VariableTabla WHERE ID = @aux
						--SELECT @refPropia, @varconcepto, @idBanco , @emp_idempresa

						EXECUTE [JOB_INSBPRO_DEPOSITOS_SP] @refPropia, @idBanco, @varconcepto, @emp_idempresa 
					SET @aux = @aux + 1				
				END

	--SELECT * from  @VariableTabla

END



go

