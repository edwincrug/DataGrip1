--USE [Pagos]
--GO
--/****** Object:  StoredProcedure [dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP]    Script Date: 14/02/2020 01:23:19 p. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

---- =============================================
---- Author:		<Author,,Name>
---- Create date: <Create Date,,>
---- Description:	<Description,,>
---- =============================================
--/*
--[dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP]
--	@idProveedor = 210273
--	,@cuenta = '1509916849'
--	,@convenio = ''
--	,@idEmpresa = 7
--	,@idUsuario = 71
--*/
CREATE PROCEDURE [dbo].[INS_BITACORA_CUENTAS_PROVEEDOR_SP]
	@idProveedor NUMERIC(18,0) 
	,@cuenta varchar(25) 
	,@convenio varchar(10) 
	,@idEmpresa NUMERIC(18,0) 
	,@idUsuario VARCHAR(10)
	,@result INT OUTPUT 

AS
BEGIN
--DECLARE @idProveedor NUMERIC(18,0) = 464119
--	,@cuenta varchar(25)  = '1019380723'
--	,@convenio varchar(10) = ''
--	,@idEmpresa NUMERIC(18,0) = 1
--	,@idUsuario VARCHAR(10) = 'DRM' 
	--,@result INT OUTPUT 

	


	BEGIN TRY
		DECLARE @ipServer VARCHAR(100) =(SELECT  local_net_address FROM sys.dm_exec_connections WHERE Session_id = @@SPID)
		DECLARE @BASES TABLE(id int identity(1,1),emp_idempresa INT,bases nvarchar(200), BD nvarchar(200))
		DECLARE @basePricipal VARCHAR(50) = '', @queryCuentaSel NVARCHAR(MAX) = '', @queryBanco NVARCHAR(MAX) = '', @bd VARCHAR(50) = ''
		SELECT @basePricipal = CASE WHEN @ipServer = ip_servidor  THEN  '[' + nombre_base + '].[dbo].' ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 AND emp_idempresa IN (@idEmpresa) 
		--SELECT @basePricipal
		
		INSERT INTO @BASES
		SELECT emp_idempresa ,CASE WHEN @ipServer = ip_servidor  THEN  '[' + nombre_base + '].[dbo].' ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END, nombre_base  FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 AND emp_idempresa  NOT IN (@idEmpresa)  
		
		--SELECT * FROM @BASES
		DECLARE @max INT = 0, @aux INT = 1
		DECLARE @queryCuenta NVARCHAR(MAX), @base NVARCHAR(500) = '', @empresa_id VARCHAR(10), @queryInsert NVARCHAR(MAX)
		DECLARE @PARA_INSERTAR TABLE(	IDUSUARIO VARCHAR(10) ,
										IDEMPRESA numeric (18, 0) ,
										FECHA datetime,
										BCO_CONSE numeric (18, 0) ,
										BCO_IDPERSONA numeric(18, 0) ,
										BCO_BANCO varchar(200) ,
										BCO_PLAZA varchar(10) ,
										BCO_SUCURSAL varchar(50) ,
										BCO_STATUS varchar(20) ,
										BCO_TIPCUENTA varchar(20) ,
										BCO_NUMCUENTA varchar(25) ,
										BCO_CLABE varchar(20) ,
										BCO_CVEUSU varchar(10),
										BCO_FECHOPE varchar(50),
										BCO_HORAOPE varchar(8) ,
										BCO_REFERNUM varchar(35),
										BCO_REFERALF varchar(35),
										BCO_CONVENIOCIE varchar(10),
										BCO_AUTORIZADA int
									)

		SELECT @max = COUNT(id) FROM @BASES

		WHILE(@aux <= @max)
			BEGIN 				
				SELECT @base = bases, @empresa_id = emp_idempresa, @bd = BD  FROM @BASES WHERE id = @aux

				IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @bd)) 
					BEGIN

				--SELECT @base, @empresa_id
				--IF(@convenio = '')
				--	BEGIN
				
						SET @queryCuentaSel =	'SELECT	TOP 1 [BCO_IDPERSONA]' + char(13) + 
												'		,P.[PAR_IDENPARA]' + char(13) + 
												'		,[BCO_PLAZA]' + char(13) + 
												'		,[BCO_SUCURSAL]' + char(13) + 
												'		,[BCO_STATUS]' + char(13) + 
												'		,[BCO_TIPCUENTA]' + char(13) + 
												'		,[BCO_NUMCUENTA]' + char(13) + 
												'		,[BCO_CLABE]' + char(13) + 
												'		,[BCO_CVEUSU]' + char(13) + 
												'		,[BCO_FECHOPE]' + char(13) + 
												'		,[BCO_HORAOPE]' + char(13) + 
												'		,[BCO_REFERNUM]' + char(13) + 
												'		,[BCO_REFERALF]' + char(13) + 
												'		,[BCO_CONVENIOCIE]' + char(13) + 
												'		,[BCO_AUTORIZADA] ' + char(13) + 
												'FROM	' + @basePricipal + 'CON_BANCOS AS B' + char(13) + 
												'		INNER JOIN ' + @basePricipal + 'PNC_PARAMETR AS PG ON B.BCO_BANCO = PG.PAR_IDENPARA AND PG.PAR_TIPOPARA = ''BA'' AND PG.PAR_STATUS = ''A''' + char(13) + 
												'		INNER JOIN ' + @base + 'PNC_PARAMETR AS P ON PG.PAR_DESCRIP5 = P.PAR_DESCRIP5 AND P.PAR_TIPOPARA = ''BA'' AND P.PAR_STATUS = ''A''' + char(13) + -- AND P.PAR_DESCRIP1 LIKE ''%'' + PG.PAR_DESCRIP1 + ''%''
												'WHERE	[BCO_IDPERSONA] = ' + CONVERT(VARCHAR(20), @idProveedor) + ' ' + char(13) + 
												'		AND [BCO_CONVENIOCIE] = '+char(39)+ @convenio +char(39)+' ' + char(13) + 
												'		AND [BCO_NUMCUENTA] = '+char(39)+ @cuenta +char(39)+'' + char(13) + 
												'' 
				--	END
				--ELSE
				--	BEGIN
				--		SET @queryCuentaSel =	'SELECT	TOP 1 [BCO_IDPERSONA]' + char(13) + 
				--								'		,[BCO_BANCO]' + char(13) + 
				--								'		,[BCO_PLAZA]' + char(13) + 
				--								'		,[BCO_SUCURSAL]' + char(13) + 
				--								'		,[BCO_STATUS]' + char(13) + 
				--								'		,[BCO_TIPCUENTA]' + char(13) + 
				--								'		,[BCO_NUMCUENTA]' + char(13) + 
				--								'		,[BCO_CLABE]' + char(13) + 
				--								'		,[BCO_CVEUSU]' + char(13) + 
				--								'		,[BCO_FECHOPE]' + char(13) + 
				--								'		,[BCO_HORAOPE]' + char(13) + 
				--								'		,[BCO_REFERNUM]' + char(13) + 
				--								'		,[BCO_REFERALF]' + char(13) + 
				--								'		,[BCO_CONVENIOCIE]' + char(13) + 
				--								'		,[BCO_AUTORIZADA] ' + char(13) + 
				--								'FROM	' + @basePricipal + 'CON_BANCOS AS B' + char(13) +
				--								'WHERE	[BCO_IDPERSONA] = ' + CONVERT(VARCHAR(20), @idProveedor) + ' ' + char(13) + 
				--								'		AND [BCO_CONVENIOCIE] = '+char(39)+ @convenio +char(39)+' ' + char(13) + 
				--								'		AND [BCO_NUMCUENTA] = '+char(39)+ @cuenta +char(39)+'' + char(13) + 
				--								'' 
				--	END	
				--EXECUTE (@queryCuentaSel)
				PRINT (@queryCuentaSel)
			
				SET @queryCuenta =	'SELECT	''' + @idUsuario + '''' + char(13) + 
									'		,' + @empresa_id + '' + char(13) + 
									'		,GETDATE()' + char(13) + 
									'		,[BCO_CONSE]' + char(13) + 
									'		,[BCO_IDPERSONA]' + char(13) + 
									'		,[BCO_BANCO]' + char(13) + 
									'		,[BCO_PLAZA]' + char(13) + 
									'		,[BCO_SUCURSAL]' + char(13) + 
									'		,[BCO_STATUS]' + char(13) + 
									'		,[BCO_TIPCUENTA]' + char(13) + 
									'		,[BCO_NUMCUENTA]' + char(13) + 
									'		,[BCO_CLABE]' + char(13) + 
									'		,[BCO_CVEUSU]' + char(13) + 
									'		,[BCO_FECHOPE]' + char(13) + 
									'		,[BCO_HORAOPE]' + char(13) + 
									'		,[BCO_REFERNUM]' + char(13) + 
									'		,[BCO_REFERALF]' + char(13) + 
									'		,[BCO_CONVENIOCIE]' + char(13) + 
									'		,[BCO_AUTORIZADA] ' + char(13) + 
									'FROM	' + @base + 'CON_BANCOS AS B' + char(13) + 
									'WHERE	[BCO_IDPERSONA] = ' + CONVERT(VARCHAR(20), @idProveedor) + ' ' + char(13) + 
									'		AND [BCO_CONVENIOCIE] = '+char(39)+ @convenio +char(39)+' ' + char(13) + 
									'		AND [BCO_NUMCUENTA] = '+char(39)+ @cuenta +char(39)+'' + char(13) + 
									'' 
				

				INSERT INTO @PARA_INSERTAR
				EXECUTE(@queryCuenta)
				--EXECUTE(@queryCuenta)
				IF EXISTS(SELECT BCO_NUMCUENTA FROM @PARA_INSERTAR)
					BEGIN
				
						PRINT 'EXISTE'
						INSERT INTO [Pagos].[dbo].[PAG_BITACORA_CUENTAS]
						SELECT  342	
							   ,IDEMPRESA	
							   ,FECHA		
							   ,BCO_CONSE	
							   ,BCO_IDPERSONA
							   ,BCO_BANCO 
							   ,BCO_PLAZA 
							   ,BCO_SUCURSAL
							   ,BCO_STATUS
							   ,BCO_TIPCUENTA
							   ,BCO_NUMCUENTA
							   ,BCO_CLABE 
							   ,BCO_CVEUSU 
							   ,BCO_FECHOPE
							   ,BCO_HORAOPE 
							   ,BCO_REFERNUM 
							   ,BCO_REFERALF 
							   ,BCO_CONVENIOCIE 
						 	   ,BCO_AUTORIZADA 
						FROM @PARA_INSERTAR
						SET @queryCuenta =	'DELETE ' + char(13) +
											'FROM	' + @base + 'CON_BANCOS ' + char(13) + 
											'WHERE	[BCO_IDPERSONA] = ' + CONVERT(VARCHAR(20), @idProveedor) + ' ' + char(13) + 
											'		AND [BCO_CONVENIOCIE] = '+char(39)+ @convenio +char(39)+' ' + char(13) + 
											'		AND [BCO_NUMCUENTA] = '+char(39)+ @cuenta +char(39)+'' + char(13) + 
											'' 
						EXECUTE (@queryCuenta)
						--PRINT (@queryCuenta)
						SET @queryInsert = 'INSERT INTO ' + @base + 'CON_BANCOS ' + char(13) +
											'	(	[BCO_IDPERSONA]' + char(13) +
											'	,[BCO_BANCO]' + char(13) +
											'	,[BCO_PLAZA]' + char(13) +
											'	,[BCO_SUCURSAL]' + char(13) +
											'	,[BCO_STATUS]' + char(13) +
											'	,[BCO_TIPCUENTA]' + char(13) +
											'	,[BCO_NUMCUENTA]' + char(13) +
											'	,[BCO_CLABE]' + char(13) +
											'	,[BCO_CVEUSU]' + char(13) +
											'	,[BCO_FECHOPE]' + char(13) +
											'	,[BCO_HORAOPE]' + char(13) +
											'	,[BCO_REFERNUM]' + char(13) +
											'	,[BCO_REFERALF]' + char(13) +
											'	,[BCO_CONVENIOCIE]' + char(13) +
											'	,[BCO_AUTORIZADA] )' + char(13) +  ''
											 + @queryCuentaSel
						 --PRINT (@queryInsert)
						 EXECUTE (@queryInsert)
					END
				ELSE 
					BEGIN
					
						 PRINT 'NO EXISTE'						 						 		 
						 SET @queryInsert = 'INSERT INTO ' + @base + 'CON_BANCOS ' + char(13) +
											'	(	[BCO_IDPERSONA]' + char(13) +
											'	,[BCO_BANCO]' + char(13) +
											'	,[BCO_PLAZA]' + char(13) +
											'	,[BCO_SUCURSAL]' + char(13) +
											'	,[BCO_STATUS]' + char(13) +
											'	,[BCO_TIPCUENTA]' + char(13) +
											'	,[BCO_NUMCUENTA]' + char(13) +
											'	,[BCO_CLABE]' + char(13) +
											'	,[BCO_CVEUSU]' + char(13) +
											'	,[BCO_FECHOPE]' + char(13) +
											'	,[BCO_HORAOPE]' + char(13) +
											'	,[BCO_REFERNUM]' + char(13) +
											'	,[BCO_REFERALF]' + char(13) +
											'	,[BCO_CONVENIOCIE]' + char(13) +
											'	,[BCO_AUTORIZADA] )' + char(13) +  ''
											 + @queryCuentaSel
						 --PRINT (@queryInsert)
						 EXECUTE (@queryInsert)
						 --EXECUTE (@queryCuentaSel)
					END
				END
				SET @aux = @aux +1 
				DELETE FROM @PARA_INSERTAR
			END
		SET @result = 1
		print 'Éxito'
		RETURN @result
		

	END TRY
		BEGIN CATCH
			
			PRINT ('Error: ' + ERROR_MESSAGE())
			DECLARE @Mensaje  nvarchar(max),
			@Componente nvarchar(50) = '[INS_BITACORA_CUENTAS_SP]'
			SET @result = 0
			print 'Error'

			--SELECT 0 estatus,ERROR_MESSAGE() mensaje
			RETURN @result

		END CATCH
	END

go

