
-- =============================================
-- Author:		FAL
-- Create date: 11122017
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [JOB_BUSCA_DEPOSITOS_SP] 1
CREATE PROCEDURE [dbo].[JOB_REL_DOCTOS_BANCOS_SP]
	
	 @emp_idempresa INT = 0
		
AS
BEGIN
--Encontramos los parametros de la base de datos 
--DECLARE @ID_DOCTO_INICIO INT = (SELECT TOP 1 ISNULL(dpa_iddoctopagado, 0) as id_docto FROM PAG_REL_DOCTOS_BANCOS ORDER BY dpa_iddoctopagado DESC)
				
				DECLARE @ID_DOCTO_INICIO INT = 0

				DECLARE @total INT = (SELECT  COUNT(dpa_iddoctopagado)  FROM  cuentasxpagar.dbo.cxp_doctospagados where dpa_iddoctopagado > @ID_DOCTO_INICIO)
				
				--referencias.dbo.Bancomer where (((concepto LIKE 'SPEI%' AND refAmpliada LIKE '%-%-%') OR (concepto LIKE 'TRASPASO%' AND refAmpliada LIKE '%-%-%')) AND ((estatus = 1) AND (esCargo = 1))))	
				DECLARE @aux   INT = 1

				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), dpa_iddoctopagado INT, idBanco_Registro INT, idBanco INT, pal_id_empresa INT, ptl_id_tipoLotePago INT, prdb_fechaAplica smalldatetime, pal_id_lote_pago numeric(18, 0))
										
				--INSERT INTO @VariableTabla (dpa_iddoctopagado,idBanco_Registro,idBanco,pal_id_empresa, ptl_id_tipoLotePago) 

				SELECT        DOCTOS.dpa_iddoctopagado, DOCTOS.dpa_idempresa, DOCTOS.dpa_fechaaplicacion, DOCTOS.dpa_lote 
				FROM            cuentasxpagar.dbo.cxp_doctospagados AS DOCTOS 

				--WHILE(@aux <=  @total)
				--		BEGIN
				--		declare @refPropia as nvarchar(100)
				--		declare @idBanco as int
				--		declare @varconcepto as nvarchar (50)
						
				--		SELECT @varconcepto = concepto, @idBanco = idBmer,  @refPropia = refAmpliada FROM @VariableTabla WHERE ID = @aux
				--		--SELECT @refPropia, @varconcepto, @idBanco , @emp_idempresa

				--		EXECUTE [JOB_INSBPRO_DEPOSITOS_SP] @refPropia, @idBanco, @varconcepto, @emp_idempresa 
				--	SET @aux = @aux + 1				
				--END

	

END



go

