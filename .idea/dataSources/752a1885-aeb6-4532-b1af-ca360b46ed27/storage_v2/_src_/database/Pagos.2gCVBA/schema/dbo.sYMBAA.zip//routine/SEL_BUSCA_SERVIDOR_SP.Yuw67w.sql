-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 09/02/2016
-- Description:	Busca el servidor al dar el nombre de la empresa
-- =============================================
--EXECUTE [SEL_BUSCA_SERVIDOR_SP] 'Zaragoza Motriz SA de CV'
CREATE PROCEDURE [dbo].[SEL_BUSCA_SERVIDOR_SP]
	@emp_nombre NVARCHAR(100)=NULL
AS
BEGIN
	SET NOCOUNT ON;
	--DECLARE  @emp_nombre NVARCHAR(100)
	--DECLARE  @nombreBase NVARCHAR(100)
	--DECLARE  @ipServidor NVARCHAR(100)
	BEGIN
	  SELECT [nombre_base]        
			 ,[ip_servidor]      
		FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
		WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
									FROM [ControlAplicaciones].[dbo].[cat_empresas]
								  WHERE [emp_nombre] = @emp_nombre) 
		AND tipo = 2

	--  SELECT @nombreBase = [nombre_base]        
	--		,@ipServidor = [ip_servidor]      
	--	FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
	--	WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
	--								FROM [ControlAplicaciones].[dbo].[cat_empresas]
	--							WHERE [emp_nombre] = 'Zaragoza Motriz SA de CV') --@emp_nombre
	--	AND tipo = 2

	--SELECT @nombreBase, @ipServidor
END
	       		     
END

go

