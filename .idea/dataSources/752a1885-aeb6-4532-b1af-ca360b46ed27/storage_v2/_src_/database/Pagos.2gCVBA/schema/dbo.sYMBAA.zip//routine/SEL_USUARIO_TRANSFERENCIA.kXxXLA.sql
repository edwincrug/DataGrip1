


-- ====================================================
-- Author:		Fernando Alvarado Luna
-- Create date: 22/11/2016
-- Description:	Lotes Maestro por empresa y Usuario
-- Este SP debe ser solo por empresa
-- ====================================================
--EXECUTE [SEL_TRANSFERENCIASXEMPRESA] 1
CREATE PROCEDURE [dbo].[SEL_USUARIO_TRANSFERENCIA]
	 @idUsuario int =0

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
	   --LQMA 31032016 se cambio para que traiga siempre por empresa
	  
SELECT sup_idUsuario, sup_idPerfil FROM Seguridad.dbo.SEG_USUARIO_PERFIL
WHERE sup_idUsuario = @idUsuario AND sup_idPerfil = 4


END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END



go

