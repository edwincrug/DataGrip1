


-- =============================================
-- Author:		FAL
-- Create date: 19042017
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [JOB_INSBPRO_DEPOSITOS_SP] 1
-- =============================================
-- Author:		DCG
-- Update date: 12042018
-- Description:	Se agrega (NOLOCK) a las consultas de tablas ordinarias,
-- para que no se bloquen los procesos
-- =============================================

CREATE PROCEDURE [dbo].[JOB_INSBPRO_DEPOSITOS_SP]
	
			@refPropia as nvarchar(100),
			@idBanco as int,
			@varconcepto as nvarchar(50),
			@emp_idempresa INT = 0
		
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @total INT = (SELECT  COUNT(*)  FROM  dbo.SplitString(@refPropia,'-'))	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), item nvarchar(50))
				DECLARE @idLote nvarchar(50)
				DECLARE @idempresalote int = 0
				DECLARE @consCar nvarchar(50)
				DECLARE @consLote nvarchar(50)
				DECLARE @VARTIPOCARGO nvarchar(4)
				IF @total = 3
					BEGIN										
						INSERT INTO @VariableTabla (item) 
						SELECT item FROM  dbo.SplitString(@refPropia,'-')
						
						SELECT @VARTIPOCARGO= LEFT(@varconcepto,4)
						
						if @VARTIPOCARGO = 'SPEI'
							BEGIN
								
								SELECT  @idLote = SUBSTRING(item, 8, LEN(item)-7)
								FROM @VariableTabla WHERE ID = 1
								SELECT  @consCar = item
								FROM @VariableTabla WHERE ID = 2
								SELECT  @consLote = LEFT(item,3)
								FROM @VariableTabla WHERE ID = 3
							END
						ELSE
							BEGIN
								SELECT  @idLote = item
								FROM @VariableTabla WHERE ID = 1
								SELECT  @consCar = item
								FROM @VariableTabla WHERE ID = 2
								SELECT  @consLote = LEFT(item,3)
								FROM @VariableTabla WHERE ID = 3
						END

						SELECT @idempresalote = pal_id_empresa FROM PAG_LOTE_PAGO with (NOLOCK) WHERE pal_id_lote_pago = @idLote

						IF @idempresalote = @emp_idempresa
						BEGIN
						EXECUTE [JOB_INSBPRO_DEPOSITOS_FIN_SP] @emp_idempresa,@idLote, @consCar, @consLote, @idBanco
						END

				END
END



go

