-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 25/02/2016
-- Description:	Agrupadores por empresa 
-- =============================================
--EXECUTE [SEL_AGRUPADORES_PROVEEDOR_SP] 1
CREATE PROCEDURE [dbo].[SEL_AGRUPADORES_PROVEEDOR_SP]
	@idEmpresa numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		DECLARE @ipServidor    VARCHAR(100);
		DECLARE @nombreBase    VARCHAR(100);
		DECLARE @cadIpServidor VARCHAR(100);
		DECLARE @select        VARCHAR(max);
		DECLARE @campos        VARCHAR(max);
		DECLARE @tabla         VARCHAR(max);
		DECLARE @condicion     VARCHAR(max);

		SELECT @nombreBase = [nombre_base]        
			  ,@ipServidor = [ip_servidor]      
		 FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
		 WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
		   							 FROM [ControlAplicaciones].[dbo].[cat_empresas]
								    WHERE [emp_idempresa] = @idEmpresa)
		  AND tipo = 2
        
		--SELECT @nombreBase,@ipServidor
		---------------------------------------------------------------
		--  Para cambiar la consulta si es local o no                --
		---------------------------------------------------------------
		DECLARE @ipPagos VARCHAR(100) = (SELECT ppa_valor  FROM [dbo].[PAG_PARAMETROS] WHERE ppa_nombre = 'BASE PAGOS')

		DECLARE @ipBPRO VARCHAR(100) = (SELECT ppa_valor  FROM [dbo].[PAG_PARAMETROS] WHERE ppa_nombre = 'BASE BPRO')

		IF (@ipServidor = @ipPagos)
		BEGIN
		set @cadIpServidor =' [' + @ipPagos + '].'
		END
		ELSE
		BEGIN
		set @cadIpServidor =' [' + @ipPagos + '].'
		END

		--SELECT  @cadIpServidor
		---------------------------------------------------------------
		--            CONSULTA DINAMICA                              --
		---------------------------------------------------------------
		DECLARE     @VariableTabla TABLE (ID INT IDENTITY(1,1)
										 ,idProveedor	 INT
										 ,nomProveedor   NVARCHAR(250)
										 )

		SET @campos='  P.[per_idpersona]  idProveedor  '+ 
		            ' ,LTRIM(RTRIM(replace(replace(P.[per_paterno],'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+') +'+''''+' '+''''+' + replace(replace(P.[per_paterno],'+''''+'Ñ'+''''+','+''''+''+''''+'),'+''''+'.'+''''+','+''''+''+''''+') + '+''''+' '+''''+' + per_nomrazon))   AS nomProveedor   '
		
		SET @tabla= @cadIpServidor + '[BDPersonas].[dbo].[cat_personas] P, ' +
		            @cadIpServidor + '[BDPersonas].[dbo].[per_relacionroles] R, ' +
					@cadIpServidor + '[BDPersonas].[dbo].[cat_roles] O   '
		SET @condicion= 'P.[per_idpersona] = R.[per_idpersona]  ' +    --AND P.[per_idpersona] = 25188
		                'AND R.[rol_idrol] in (0,18,19,20,21)  ' +            
		                'AND R.[rol_idrol] = O.[rol_idrol]  ' 

		SET  @select = ' SELECT ' + @campos  + '   FROM  ' + @tabla +'    WHERE ' + @condicion +';' 
		--SELECT  @select
		
		INSERT INTO  @VariableTabla EXEC( @select );
        
		--SELECT idProveedor, nomProveedor FROM  @VariableTabla

		SELECT ISNULL(P.[pca_idAgrupador], 0)       AS  idAgrupador
		      ,ISNULL(A.[pca_nombre],'Sin Agrupar') AS  nombreAgrupador
			  ,C.idProveedor                        AS  idProveedor       
			  ,C.nomProveedor                       AS  nombreProveedor
			  ,ISNULL(P.[pap_orden], 0)             AS  ordenAgruProveedor
			  ,ISNULL(A.[pca_orden], 0)             AS  ordenCatAgrupador
		  FROM @VariableTabla  C
			   LEFT OUTER JOIN [Pagos].[dbo].[PAG_AGRUPADOR_PROVEEDOR] P ON P.[pap_idProveedor] = C.idProveedor 
			   LEFT OUTER JOIN [Pagos].[dbo].[PAG_CAT_AGRUPADORES]     A ON P.[pca_idAgrupador] = A.[pca_idAgrupador] AND A.[pca_idEmpresa]   = @idEmpresa

      

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_AGRUPADORES_PROVEEDOR_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Error en la consulta' 
END CATCH		     
END


go

