

-- =============================================
-- Author:		Irving Solorio Garcia
-- Create date: 29/04/2019
-- Description:	Obtener los tipos de provvedor
-- =============================================
CREATE PROCEDURE [dbo].[INS_Rel_dias]

@pag_idDias  int,
@idEmpresa int
	
AS
BEGIN
if exists (select pag_idDias from PAG_REL_Dias where idEmpresa=@idEmpresa) 
begin

	UPDATE [dbo].[PAG_REL_Dias]
	   SET [pag_idDias] = @pag_idDias
      
	 WHERE idEmpresa=@idEmpresa

	select SCOPE_IDENTITY() id, 1 success
 end
else
 begin
	INSERT INTO [dbo].[PAG_REL_Dias]
			   ([pag_idDias]
			   ,[idEmpresa])
		 VALUES
			   (@pag_idDias
			   ,@idEmpresa)

	select SCOPE_IDENTITY() id, 1 success
 end
END



go

