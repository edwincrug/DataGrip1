-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 24/02/2016
-- Description:	Agrupadores              --Eliminar de la tabla el ID_Agrupador 0
-- ==========================================================================================
--EXECUTE [SEL_AGRUPADORES_SP] 4
CREATE PROCEDURE [dbo].[SEL_AGRUPADORES_SP]
	@idEmpresa numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
		SELECT [pca_idAgrupador]
			  ,[pca_idEmpresa]
			  ,[pca_nombre]
			  ,[pca_descripcion]
			  ,[pca_orden]
			  ,[pca_estatus]
		  FROM [Pagos].[dbo].[PAG_CAT_AGRUPADORES]
         WHERE [pca_idEmpresa] = @idEmpresa

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_AGRUPADORES_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Error en la consulta'
END CATCH		     
END

go

