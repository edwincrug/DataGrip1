-- =============================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 11/03/2016
-- Description:	Cuentas de Egresos por empresa 
-- =============================================
--EXECUTE [SEL_CUENTAS_EGRESOS_SPBK] 10,0                        
CREATE PROCEDURE [dbo].[SEL_CUENTAS_EGRESOS_SPBK]
	@idEmpresa numeric(18,0)=0
	,@numLote   numeric(18,0)=0   
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		DECLARE @ipServidor    VARCHAR(100);
		DECLARE @nombreBase    VARCHAR(100);
		DECLARE @cadIpServidor VARCHAR(100);
		DECLARE @select        VARCHAR(max);
		DECLARE @campos        VARCHAR(max);
		DECLARE @tabla         VARCHAR(200);
		DECLARE @condicion     VARCHAR(100);

		SELECT @nombreBase = [nombre_base]        
			  ,@ipServidor = [ip_servidor]      
		FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
		WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
									FROM [ControlAplicaciones].[dbo].[cat_empresas]
								WHERE [emp_idempresa] = @idEmpresa)
		  AND tipo = 2
        set @cadIpServidor =' [' + @ipServidor + '].'
        
        IF (@ipServidor ='192.168.20.29')
		BEGIN
		set @cadIpServidor =''
		END
		---------------------------------------------------------------
		--  CUENTAS               --
		---------------------------------------------------------------
		IF (@numLote = 0)
		BEGIN 

		SET @campos='  P.PAR_IDENPARA   AS id ' +
		             ' ,CASE WHEN PP.PAR_DESCRIP4 like  '+ ''''+'%BANCOMER%'+''''+' THEN '+''''+'BANCOMER' + '''' +
					 '       WHEN PP.PAR_DESCRIP4 like ' + ''''+'%BANAMEX%' +'''' + '  THEN ' + '''' +'BANAMEX' +'''' +
					 '       WHEN PP.PAR_DESCRIP4 like ' + ''''+'%SANTANDER%' +'''' + '  THEN ' + '''' +'SANTANDER' +'''' +
					 '       WHEN PP.PAR_DESCRIP4 like ' + ''''+'%SCOTIABANK%' +'''' + '  THEN ' + '''' +'SCOTIABANK' +'''' +
					 
					 '       ELSE '+'''' +'Otro' +'''' +
					 '  END  banco ' +
					 ' ,CASE WHEN PP.PAR_DESCRIP4 like  '+'''' +'%BANCOMER%'+''''+' THEN (SELECT TOP (1) MontoMinimoPagos FROM  referencias.dbo.BancoCuenta WHERE (cuenta LIKE '+'''' +'%BANCOMER%'+''''+'))' +
					 ' WHEN PP.PAR_DESCRIP4 like '+'''' +'%BANAMEX%'+''''+'  THEN (SELECT TOP (1) MontoMinimoPagos FROM  referencias.dbo.BancoCuenta WHERE (cuenta LIKE '+'''' +'%BANAMEX%'+''''+'))' +      
					 ' WHEN PP.PAR_DESCRIP4 like '+'''' +'%SANTANDER%'+''''+'  THEN (SELECT TOP (1) MontoMinimoPagos FROM  referencias.dbo.BancoCuenta WHERE (cuenta LIKE '+'''' +'%SANTANDER%'+''''+'))' +    
					  ' WHEN PP.PAR_DESCRIP4 like '+'''' +'%SCOTIABANK%'+''''+'  THEN (SELECT TOP (1) MontoMinimoPagos FROM  referencias.dbo.BancoCuenta WHERE (cuenta LIKE '+'''' +'%SCOTIABANK%'+''''+'))' +    
					 ' ELSE 0  END  MontoMinimo ' +
					 --NUMERO CUENTA
	                 --'  ,SUBSTRING(P.PAR_DESCRIP1,CHARINDEX('+''''+' '+''''+' ,P.PAR_DESCRIP1)+1, LEN(P.PAR_DESCRIP1))  AS cuenta ' +  
					 '  ,UPPER(PP.PAR_DESCRIP4)  AS cuenta ' +
					 ---
					 '  ,0.00000  AS saldo ' +
					 '  ,0.00000  AS aTransferir ' +
					 '  ,0.00000  AS total ' +
					 '  ,0.00000  AS excedente ' +
					 '  ,0.00000  AS totalPagar  ' +
					 '  ,0.00000  AS saldoIngreso ' +
					 --FAL traigo parametrizado de referencias
					 --' ,CASE WHEN referencias.dbo. like  '+ ''''+'%BANCOMER%'+''''+' THEN '+''''+'BANCOMER' + '''' +
					 --'       WHEN PP.PAR_DESCRIP4 like ' + ''''+'%BANAMEX%' +'''' + '  THEN ' + '''' +'BANAMEX' +'''' +
					 --'       WHEN PP.PAR_DESCRIP4 like ' + ''''+'%SANTANDER%' +'''' + '  THEN ' + '''' +'SANTANDER' +'''' +
					 --'       ELSE '+'''' +'Otro' +'''' +
					 --'  END  MontoMinimoPagos ' +
					 --- Si la cuenta existe en ingreso
					 ' ,1  as ingreso ' + 
					 '  ,1   AS egreso  ' 
					 +'  ,PP.PAR_DESCRIP4 AS cuentaContable '
		SET @tabla='.[dbo].[PNC_PARAMETR] P INNER JOIN '  + @cadIpServidor + '['+  @nombreBase +']'+ '.[dbo].[PNC_PARAMETR] PP ON PP.PAR_IDENPARA = P.PAR_DESCRIP5'
		SET @condicion= 'P.PAR_TIPOPARA ='+ ''''+ 'TRANSBCO' + '''' + '  AND PP.PAR_TIPOPARA ='+ ''''+ 'CCHEQ' + '''' + '   AND  PP.PAR_IMPORTE5 > 0' 

		SET  @select = ' SELECT ' + @campos  + '   FROM  ' + @cadIpServidor + '['+  @nombreBase +']'+ @tabla +'    WHERE  ' + @condicion +';' 
		
		select @select
		---------------------------------------------------------------
		--  Obtenemos la consulta dinamicamente                      --
		---------------------------------------------------------------
		DECLARE     @VariableTabla TABLE (id            numeric(18,0)
										 ,banco	        nvarchar(50)
										 ,MontoMinimo   decimal(18,0)
										 ,cuenta	    nvarchar(50)
										 ,saldo	        decimal(18,5)
										 ,aTransferir	decimal(18,5)
										 ,total	        decimal(18,5)
										 ,excedente	    decimal(18,5)
										 ,totalPagar	decimal(18,5)
										 ,saldoIngreso	decimal(18,5)
										 ,ingreso	    int
										 ,egreso	    int
										 ,cuentaContable      nvarchar(50)
										 )
									
        INSERT INTO  @VariableTabla  EXEC(@select);

		SELECT * FROM  @VariableTabla
		
		END
		ELSE
		BEGIN
		    SELECT [peb_id]          as id
			      ,UPPER([peb_id_cuenta])   as banco
				  ,0.0000 as MontoMinimo
				  ,UPPER([peb_id_cuenta])   as cuenta
				  ,[peb_saldo]       as saldo
				  ,[peb_aTransferir] as aTransferir
				  ,[peb_total]       as total
				  ,[peb_excedente]   as excedente
				  ,0.00000           as totalPagar
				  ,0.00000           as saldoIngreso
				  ,0                 as ingreso
				  ,1                 as egreso
				  ,ISNULL([peb_cuentaContable],'Actualizar valor')  as cuentaContable             --Checar
			  FROM [Pagos].[dbo].[PAG_FLUJO_EGRESO_BANCOS]
             WHERE [pal_id_lote_pago] =  @numLote



		END

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_CUENTAS_EGRESOS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Encontro error'
END CATCH		     
END


go

