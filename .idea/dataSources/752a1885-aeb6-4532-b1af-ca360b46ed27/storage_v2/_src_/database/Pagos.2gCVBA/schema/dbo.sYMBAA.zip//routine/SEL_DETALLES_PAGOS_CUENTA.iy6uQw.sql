-- =============================================
-- Author:		Francisco Javier Suárez Priego
-- Create date: 07/08/2019
-- Description:	SP para obtener la información de la cuenta de bpro de los detalles de pago
-- =============================================
--exec SEL_DETALLES_PAGOS_CUENTA 10442
CREATE PROCEDURE SEL_DETALLES_PAGOS_CUENTA
	-- Add the parameters for the stored procedure here
	@idLotePago int 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  DECLARE @idEmpresa numeric(18,0) = 0;
  DECLARE @ipServidor    VARCHAR(100);  
  DECLARE @cadIpServidor VARCHAR(100);  
  DECLARE @nombreBase    VARCHAR(100);
  DECLARE @campos        VARCHAR(max);  

   SELECT @idEmpresa = [pal_id_empresa]    
   FROM [Pagos].[dbo].[PAG_LOTE_PAGO]  
   WHERE [pal_id_lote_pago] = @idLotePago;  


  SELECT @nombreBase = [nombre_base]          
     ,@ipServidor = [ip_servidor]        
  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]  
  WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto   
         FROM [ControlAplicaciones].[dbo].[cat_empresas]  
        WHERE [emp_idempresa] = @idEmpresa)  
    AND tipo = 2;  
  
--select @nombreBase, @ipServidor  
  ---------------------------------------------------------------  
  --  Para cambiar la consulta si es local o no                --  
  ---------------------------------------------------------------  
  set @cadIpServidor =' [' + @ipServidor + '].'  
    
  IF (@ipServidor ='192.168.20.29')  
  BEGIN  
  set @cadIpServidor =''  
  END  
	
set @campos ='select d.pad_idProveedor, d.pad_proveedor, 											 
(SELECT TOP 1 ba.par_descrip1 
 FROM ['+  @ipServidor +'].['+@nombreBase+'].[dbo].[pnc_parametr] AS ba 
        INNER JOIN pag_cat_banxico 
                ON ba.par_descrip5 = pag_cat_banxico.pbx_numoficial COLLATE 
                                     sql_latin1_general_cp1_ci_as 
 WHERE  ( ba.par_idenpara = b.bco_banco ) 
        AND ( ba.par_tipopara = '+''''+'ba'+''''+' ) 
        AND ( ba.par_status = '+ ''''+'A'+''''+' ) 
 ORDER  BY pag_cat_banxico.pbx_numoficial) 
       AS nombreBancoDestino,  b.bco_numcuenta, b.BCO_CLABE, d.[pad_saldo]
FROM   [Pagos].[dbo].[pag_lote_pago] M 
       INNER JOIN [Pagos].[dbo].[pag_progra_pagos_detalle] AS D 
               ON D.[pal_id_lote_pago] = M.[pal_id_lote_pago] 
                  AND D.[pal_id_lote_pago] = '+cast (@idLotePago as varchar(18))+' 
       INNER JOIN [CentralizacionV2].[dbo].[dig_cat_empresa_razon] AS ER 
               ON ER.idempresa = M.[pal_id_empresa] 
	   LEFT OUTER JOIN ['+  @ipServidor +'].['+@nombreBase+'].[dbo].[con_bancos] b 
                    ON b.bco_idpersona = D.[pad_idproveedor] 
                       AND B.bco_numcuenta = D.pad_cuentadestino COLLATE 
                                             modern_spanish_ci_as '
EXEC (@campos);
											 
END
go

