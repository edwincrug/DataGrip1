

-- =============================================
-- Author:		Irving Solorio Garcia
-- Create date: 29/04/2019
-- Description:	Actualiza el tipo de proveedor
-- =============================================
CREATE PROCEDURE [dbo].[UPD_Rel_TipoProveedor]

@pag_idtipoProveedor  int,
@proveedores XML = ''
--@idPersona numeric(18,0)
	
AS
BEGIN

	DECLARE @tablaIds TABLE  (idProveedor VARCHAR(100))

		INSERT INTO  @tablaIds
		SELECT 
		I.N.value('(id)[1]', 'VARCHAR(100)')
		FROM @proveedores.nodes('/proveedores/proveedor') I(N);


		UPDATE [dbo].[PAG_REL_tipoProveedor]
		   SET [pag_idtipoProveedor] = @pag_idtipoProveedor
     
		 WHERE idPersona in (SELECT idProveedor FROM @tablaIds)

		 select SCOPE_IDENTITY() id, 1 success

END



go

