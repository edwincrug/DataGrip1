
-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 05/05/2016
-- Description:	Empresas relacionadas solo con ese usuario
-- ==========================================================================================
--EXECUTE [SEL_EMPRESAS_SP] 71
CREATE PROCEDURE [dbo].[SEL_EMPRESAS_SP]
          @idUsuario  int = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
--Debe mostrar solo las empresas relacionadas solo con ese usuario

	   SELECT DISTINCT O.[emp_idempresa]
					  ,E.[emp_nombre]
					  ,E.[emp_nombrecto]
					  ,E.[emp_estatus]
					  ,(SELECT ISNULL([rfc],'XXXXXXXXXXXX') 
						  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
						 WHERE [catsuc_nombrecto] = 'CONCENTRA' 
						   AND [catemp_nombrecto] = E.[emp_nombrecto] ) as rfc
					  ,(SELECT ISNULL([catemp_id_tipo_finaciera],9) 
						  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
						 WHERE [catsuc_nombrecto] = 'CONCENTRA' 
						   AND [catemp_nombrecto] = E.[emp_nombrecto] ) as tipo
					  ,(SELECT ISNULL([catemp_pago_directo],'NO') 
						  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
						 WHERE [catsuc_nombrecto] = 'CONCENTRA' 
						   AND [catemp_nombrecto] = E.[emp_nombrecto] ) as pagoDirecto,
						P.ppe_monto_minimo AS monto_minimo
		   FROM [ControlAplicaciones].[dbo].[ope_organigrama] O
			   ,[ControlAplicaciones].[dbo].[cat_empresas]  E
			   ,[Pagos].[dbo].[PAG_PARAMETROS_EMPRESAS] P
		 WHERE O.[emp_idempresa] = E.[emp_idempresa]
		   AND O.[usu_idusuario] =@idUsuario
		   AND P.ppe_id_empresa =  E.[emp_idempresa]

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_EMPRESAS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 0 --Encontro error
END CATCH		     
END


go

