-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 19/04/2016
-- Description:	Total saldo del Lote
-- ==========================================================================================
--EXECUTE [SEL_TOTAL_BANCOS_LOTE_SP] 233                    
CREATE PROCEDURE [dbo].[SEL_TOTAL_BANCOS_LOTE_SP]
	  @idPadre      numeric(18,0) = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	    
	  SELECT  D.[pad_cuentaProveedor]                      AS cuentaProveedor
	          ,ISNULL(SUM(D.[pad_saldo]),0.00000)          AS sumaSaldo
		FROM  [Pagos].[dbo].[PAG_LOTE_PAGO] M
		     ,[Pagos].[dbo].[PAG_PROGRA_PAGOS_DETALLE] D
	   WHERE M.[pal_id_lote_pago] = D.[pal_id_lote_pago] 
		 AND D.[pal_id_lote_pago] = @idPadre
		 --AND DATEDIFF (DAY,M.[pal_fecha],GETDATE()) = 0   
       GROUP BY  D.[pad_cuentaProveedor]
	   ORDER BY  D.[pad_cuentaProveedor]
			  			    
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_TOTAL_BANCOS_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 0 --Encontro error
END CATCH		     
END

go

