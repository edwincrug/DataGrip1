
-- ====================================================
-- Author:		Fernando Alvarado Luna
-- Create date: 22/11/2016
-- Description:	Lotes Maestro por empresa y Usuario
-- Este SP debe ser solo por empresa
-- ====================================================
--EXECUTE [SEL_TRANSFERENCIASXEMPRESAXFECHA] 1,'2016-11-15','2016-11-28'
CREATE PROCEDURE [dbo].[SEL_TRANSFERENCIASXEMPRESAXFECHA]
	 @idEmpresa int =0,
	 @fecha_ini varchar(15)= '',
	 @fecha_fin varchar(15)= ''
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
	   --LQMA 31032016 se cambio para que traiga siempre por empresa
	  
SELECT        PAG_TRANSFERENCIAS_BANCARIAS.ptb_id, PAG_TRANSFERENCIAS_BANCARIAS.pal_id_lote_pago, PAG_TRANSFERENCIAS_BANCARIAS.ptb_id_cuenta_origen, 
                         PAG_TRANSFERENCIAS_BANCARIAS.ptb_id_cuenta_destino, PAG_TRANSFERENCIAS_BANCARIAS.ptb_importe, PAG_TRANSFERENCIAS_BANCARIAS.ptb_estatus, PAG_LOTE_PAGO.pal_id_empresa, 
                         PAG_LOTE_PAGO.pal_id_usuario, PAG_ESTATUS_TRANSFERENCIAS.pet_descripcion
FROM            PAG_TRANSFERENCIAS_BANCARIAS INNER JOIN
                         PAG_LOTE_PAGO ON PAG_TRANSFERENCIAS_BANCARIAS.pal_id_lote_pago = PAG_LOTE_PAGO.pal_id_lote_pago INNER JOIN
                         PAG_ESTATUS_TRANSFERENCIAS ON PAG_TRANSFERENCIAS_BANCARIAS.ptb_estatus = PAG_ESTATUS_TRANSFERENCIAS.pet_id_estatus_transferencias

WHERE PAG_LOTE_PAGO.pal_id_empresa = @idEmpresa AND PAG_LOTE_PAGO.pal_fecha >= CONVERT(datetime, @fecha_ini, 120)
			   AND PAG_LOTE_PAGO.pal_fecha < DATEADD(day,1,(CONVERT(datetime, @fecha_fin, 120)))


END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END



go

