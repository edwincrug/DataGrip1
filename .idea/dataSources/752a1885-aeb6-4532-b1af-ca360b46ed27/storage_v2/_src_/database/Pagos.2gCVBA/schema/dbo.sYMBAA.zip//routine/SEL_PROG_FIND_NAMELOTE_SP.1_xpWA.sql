-- ==========================================================================================  
-- Author: 
-- Create date: 18/05/2016  
-- Description: Procedimeinto que trae la información agrupada por proveedor y referencia  
-- Modified date: 
-- Description: Formar el archivo de pago para banamex
-- ==========================================================================================  
--EXECUTE [SEL_PROG_FIND_BANK_TXT_SP] 8369  
CREATE PROCEDURE [dbo].[SEL_PROG_FIND_NAMELOTE_SP]   
       @idPadre      numeric(18,0) = 0  
AS  
BEGIN  
 SET NOCOUNT ON;  
  BEGIN TRY  
	SELECT  DISTINCT TOP 1 pal_nombre FROM [dbo].[PAG_LOTE_PAGO] M  where [pal_id_lote_pago] = @idPadre
  END TRY      
  BEGIN CATCH  
  PRINT ('Error: ' + ERROR_MESSAGE())  
  DECLARE @Mensaje  nvarchar(max),  
  @Componente nvarchar(50) = '[SEL_PROG_FIND_NAMELOTE_SP]'  
  SELECT @Mensaje = ERROR_MESSAGE()  
  EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;   
  --SELECT 0 --Encontro error  
  SELECT 'ERROR EN LA CONSULTA'  
  END CATCH  
END
go

