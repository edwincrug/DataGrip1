
-- =============================================
-- Author:FAL		
-- Create date: 23/05/2016
-- Description: Recupera los parametros del escenario.
-- =============================================
--EXECUTE [SEL_ESCENARIO_SP] 1
CREATE PROCEDURE [dbo].[SEL_ESCENARIO_SP] 
	@idEscenario  int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT        PAG_ESCENARIOS_PAGOS.pep_pagoDirectoPlanta AS Pdplanta, PAG_ESCENARIOS_PAGOS.pep_pagoDirectoBanco AS Pdbanco, PAG_ESCENARIOS_PAGOS.ptrp_idtipoReferenciaPlanta TipoRefPlanta, 
                         PAG_ESCENARIOS_PAGOS.ptrb_idtipoReferenciaBancos as tipoRefBanco, PAG_TIPO_REFERENCIA_BANCOS.ptrb_nombre AS nomnomTipoRefBanco, PAG_TIPO_REFERENCIA_PLANTA.ptrp_nombre AS nomTipoRefPlanta
FROM            PAG_ESCENARIOS_PAGOS INNER JOIN
                         PAG_TIPO_REFERENCIA_BANCOS ON PAG_ESCENARIOS_PAGOS.ptrb_idtipoReferenciaBancos = PAG_TIPO_REFERENCIA_BANCOS.ptrb_idtipoReferenciaBancos INNER JOIN
                         PAG_TIPO_REFERENCIA_PLANTA ON PAG_ESCENARIOS_PAGOS.ptrp_idtipoReferenciaPlanta = PAG_TIPO_REFERENCIA_PLANTA.ptrp_idtipoReferenciaPlanta
WHERE        (PAG_ESCENARIOS_PAGOS.pep_idEscenarios = @idEscenario)

END


go

