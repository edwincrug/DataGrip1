-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 03/03/2016
-- Description:	Transferencias de Bancos por Lote 
-- ==========================================================================================
--EXECUTE [SEL_CUENTAS_TRANSFERENCIAS_SP] 3                       
CREATE PROCEDURE [dbo].[SEL_CUENTAS_TRANSFERENCIAS_SP]
	@idLotePago numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		SELECT [ptb_id_cuenta_origen]                        bancoOrigen
			  ,[ptb_id_cuenta_destino]                       bancoDestino
			  ,[ptb_importe]                                 importe
			  ,(ROW_NUMBER() OVER(ORDER BY [ptb_id] ASC))-1  [index] 
		  FROM [Pagos].[dbo].[PAG_TRANSFERENCIAS_BANCARIAS] 
         WHERE [pal_id_lote_pago] = @idLotePago
			  
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_CUENTAS_TRANSFERENCIAS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 0 --Encontro error
END CATCH		     
END

go

