


-- =============================================
-- Author:		FAL
-- Create date: 19042017
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [SP_BUSCA_ERROR_PAGOVSCARTERA]
CREATE PROCEDURE [dbo].[SP_BUSCA_ERROR_PAGOVSCARTERA]
	

		
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @total INT = (SELECT  COUNT (*)
										FROM         PAG_PROGRA_PAGOS_DETALLE DET
										INNER JOIN PAG_LOTE_PAGO LOTE ON DET.pal_id_lote_pago = LOTE.pal_id_lote_pago
										WHERE     LOTE.pal_id_empresa = 7)	
										
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), pal_id_lote_pago INT, pad_idProveedor INT, pad_proveedor varchar(200) null, pad_documento varchar(50) null, pad_saldo decimal (16,6) null)
				DECLARE @ErrorTable Table (IDErrorTable int identity(1,1), idLote int, documento varchar(50), idpersona int)						
				
				INSERT INTO @VariableTabla (pal_id_lote_pago,pad_idProveedor ,pad_proveedor, pad_documento, pad_saldo) 

				SELECT     DET.pal_id_lote_pago,  DET.pad_idProveedor,  DET.pad_proveedor, DET.pad_documento,  DET.pad_saldo
				FROM         PAG_PROGRA_PAGOS_DETALLE DET
				INNER JOIN PAG_LOTE_PAGO LOTE ON DET.pal_id_lote_pago = LOTE.pal_id_lote_pago
				WHERE     LOTE.pal_id_empresa = 7

				WHILE(@aux <=  @total)
						BEGIN
						declare @idlote as int
						declare @docto as varchar (50)
						declare @idpersona as int
						
			SELECT @docto = pad_documento, @idpersona = pad_idProveedor, @idlote = pal_id_lote_pago FROM @VariableTabla WHERE ID = @aux
						
					  
			
			IF (NOT EXISTS(SELECT    Vcc_Empresa, Vcc_Anno, CCP_CONSCARTERA, CCP_TIPOPOL, CCP_CONSPOL, CCP_CONSMOV, CCP_MES, CCP_CARTERA, CCP_TIPODOCTO, CCP_IDDOCTO, CCP_NODOCTO, 
							  CCP_DOCAFECTADO, CCP_COBRADOR, CCP_IDPERSONA, CCP_FECHVEN, CCP_FECHPAG, CCP_FECHPROMPAG, CCP_CARGO, CCP_ABONO, CCP_MONEDA, CCP_TIPOCAMBIO, 
							  CCP_IMPORTEMON, CCP_FECHOPE, CCP_CVEUSU, CCP_HORAOPE, CCP_FECHREV, CCP_CONCEPTO, CCP_REFERENCIA, CCP_OBSPAR, CCP_OBSGEN, CCP_IMPRESO, CCP_FECHIMPRESION, 
							  CCP_USUIMPRESION, CCP_FOLIONCR, CCP_FECHADOCTO, CCP_CONPAGO, CCP_ORIGENCON, CCP_TIPOFAC, CCP_DOCORI, CCP_REFER, CCP_FACTURANT, CCP_CONTRARECIBO, 
							  CCP_MOTREPCON, CCP_DESGLOSE, CCP_REFERNCRBONI, CCP_TIPDEV, CCP_TIPMOV, CCP_FOLMOV, CCP_GRUPO1, CCP_GRUPO2, CCP_PORIVA, CCP_COSTO, CCP_SUBTOTAL, 
							  CCP_VFTIPODOCTO, CCP_VFDOCTO, CCP_TRANSFERIR, CCP_ISAN, CCP_IMPEFECOBPAG, CCP_IVAEFECOBPAG, CCP_FECHAEFE, CCP_CONCEIETU, CCP_FECAPLIETU, CCP_HORAPLIETU, 
							  CCP_FECHAORACAR, CCP_SUBTOTALPV, CCP_DESCUENTOPV, CCP_IEPSPV, CCP_IVAPV, CCP_RETIVAPV, CCP_RETISRPV, CCP_TIPOCOMTEPV, CCP_IETU, CCP_TERPERSONA, CCP_TERCARTERA,
							  CCP_ENTREGAFAC, CCP_FECHENTREGA, CCP_RECIBIDAFAC, CCP_FECHRECIBIDA, CCP_TIPODOCVTA, CCP_OBSENTREGA, CCP_TIPCAMBIOREVAL, CCP_FECHAREVAL, CCP_IDPEDIDO, 
							  CCP_STATUSCARTERA, CCP_FACTANTICIPO, ccp_ESTATUS, ccp_FPROREV, ccp_FPROCOB, ccp_FECRECH, ccp_DESRECH, ccp_RESPON, ccp_FECDEV, ccp_DIFDEV, ccp_FREPCOB, 
							  CCP_REFGPOANDRADE
			FROM     GAAutoexpressConcentra.dbo.VIS_CONCAR01
			WHERE     (CCP_IDDOCTO like '%' + @docto + '%' AND CCP_IDPERSONA = @idpersona)
			)			) 
			
					BEGIN 
					INSERT INTO @ErrorTable(idLote, documento, idpersona) 
					VALUES(@idlote, @docto, @idpersona) 
			END 
		--ELSE 
		--		BEGIN 
		--		UPDATE Clock 
		--		SET breakOut = GetDate()
		--		WHERE clockDate = '08/10/2012' AND userName = 'test'
		
		-- END 
			
					
						 
					SET @aux = @aux + 1				
				END

	SELECT * from  @ErrorTable

END



go

