-- =============================================
-- Author:		Francisco Javier suarez priego
-- Create date: 04/07/2019
-- Description:	Obtenemos las rutas de las carpetas para el back de pagos 
-- =============================================
CREATE PROCEDURE SEL_RUTA_CONFIGURACION
	-- Add the parameters for the stored procedure here
	@Id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT nombreIdentificador, descripcion FROM pag_configuracion
	WHERE Id = @Id and estatus = 1
END
go

