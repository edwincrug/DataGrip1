

-- =============================================
-- Author:		Irving Solorio Garcia
-- Create date: 29/04/2019
-- Description:	Obtener las personas por quien sabe
-- =============================================
-- [dbo].[SEL_Rel_TipoProveedor] 4
CREATE PROCEDURE [dbo].[SEL_Rel_TipoProveedor] 

@idEmpresa int 
	
AS
BEGIN

INSERT INTO [dbo].[PAG_REL_tipoProveedor]
           ([pag_idtipoProveedor]
           ,[idPersona])
select 3,p.PER_IDPERSONA from  [GA_Corporativa].[dbo].[PER_PERSONAS] p 
left join  PAG_REL_tipoProveedor r on p.PER_IDPERSONA=r.idPersona
where r.pag_rel_idtipoProveedor is null

		--SELECT  distinct  per_idpersona idpersona,PER_NOMRAZON,isnull(r.pag_idtipoProveedor,3) pag_idtipoProveedor,isNull(p.pag_TipoProveedor,'Operación') pag_TipoProveedor
		--FROM [GA_Corporativa].[dbo].[PER_PERSONAS] d 
		--inner join [dbo].[PAG_PROGRA_PAGOS_BPRO] v on v.pbp_idProveedor=d.PER_IDPERSONA
		--left join PAG_REL_tipoProveedor r on d.PER_IDPERSONA=r.idPersona
		--inner join PAG_TipoProveedor p on p.pag_idTipoProveedor=r.pag_idtipoProveedor
		--where v.pbp_empresa = @idEmpresa
		--group by per_idpersona,PER_NOMRAZON,r.pag_idtipoProveedor,p.pag_TipoProveedor
		--order by PER_NOMRAZON
		SELECT  distinct  per_idpersona idpersona,PER_NOMRAZON + ' ' +PER_PATERNO+ ' ' +PER_MATERNO AS persona,r.pag_idtipoProveedor,p.pag_TipoProveedor
		  FROM [GA_Corporativa].[dbo].[PER_PERSONAS] d 
		  inner join PAG_REL_tipoProveedor r on d.PER_IDPERSONA=r.idPersona
		  inner join PAG_TipoProveedor p on p.pag_idTipoProveedor=r.pag_idtipoProveedor
		  inner join [dbo].[PAG_PROGRA_PAGOS_BPRO] v on v.pbp_idProveedor=d.PER_IDPERSONA
		where v.pbp_empresa =@idEmpresa
		group by per_idpersona,PER_NOMRAZON,PER_PATERNO,PER_MATERNO,r.pag_idtipoProveedor,p.pag_TipoProveedor
		order by per_idpersona
END



go

