-- ==================================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 13/04/2016
-- Description:	Borra informacion completa de los lotes No Aprobados ni Pagados
-- ==================================================================================================
--EXECUTE [PROC_ACTUALIZA_CARTERA_SP] 7                    
CREATE PROCEDURE [dbo].[PROC_ACTUALIZA_CARTERA_SP]
	 @idEmpresa  int =0
	
AS
BEGIN
	SET NOCOUNT ON;

BEGIN TRY	
     	    
		DELETE [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] WHERE pbp_empresa = @idEmpresa	
		
		IF (@idEmpresa = 7)
			BEGIN
				EXECUTE [Pagos].[dbo].[INS_DE_BPRO_A_PAGOS_SP3erPiso] @idEmpresa
		END
		
		IF (@idEmpresa <> 7)
			BEGIN
		EXECUTE [Pagos].[dbo].[INS_DE_BPRO_A_PAGOS_SP] @idEmpresa 
		END 
		
		
		select 'OK'    		
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[PROC_ACTUALIZA_CARTERA_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Error en la consulta' 
END CATCH	
	 
END

go

