-- ==========================================================================================
-- Author:	Lourdes Maldonado Sánchez	
-- Create date: 09/02/2016
-- Description:	Procedimiento que me regresara el encabezado
-- ==========================================================================================
--EXECUTE [SEL_ENCABEZADO_SP] 4
CREATE PROCEDURE [dbo].[SEL_ENCABEZADO_SP]
	@idEmpresa numeric(18,0)=4
AS
BEGIN
	SET NOCOUNT ON;

    SELECT 0.0           as saldoBanco
          ,0.0           as saldoCaja
          ,0.0           as cobranzaEsperada
          ,0.0           as flujoEfectivo
          ,0.0           as disponible
		  ,emp_nombre  as empNombre
      FROM [ControlAplicaciones].[dbo].[cat_empresas] 
	 WHERE emp_idempresa = @idEmpresa

END
go

