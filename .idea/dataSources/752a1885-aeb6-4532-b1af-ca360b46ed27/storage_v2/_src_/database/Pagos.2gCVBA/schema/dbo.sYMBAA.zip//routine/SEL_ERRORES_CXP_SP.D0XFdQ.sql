

-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 05/05/2016
-- Description:	Empresas relacionadas solo con ese usuario
-- ==========================================================================================
--EXECUTE [SEL_ERRORES_CXP_SP] 119
CREATE PROCEDURE [dbo].[SEL_ERRORES_CXP_SP]
          @idlote  int = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
--Debe mostrar solo las empresas relacionadas solo con ese usuario

	   SELECT        lap_descripcion, lap_fechaalta, lap_hora
FROM         [cuentasxpagar].[dbo].cxp_logaplicacion
WHERE        (lap_lote = @idLote)

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_EMPRESAS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 0 --Encontro error
END CATCH		     
END



go

