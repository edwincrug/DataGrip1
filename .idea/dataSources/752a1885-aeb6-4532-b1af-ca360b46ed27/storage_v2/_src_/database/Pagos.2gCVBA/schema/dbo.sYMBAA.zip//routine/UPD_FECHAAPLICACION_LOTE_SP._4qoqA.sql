
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_FECHAAPLICACION_LOTE_SP]
	@IdLote INT = 0,
	@FechaAplicacion VARCHAR(10) = ''
AS
BEGIN
	--DECLARE @IdLote INT = 12859,
	--	@FechaAplicacion VARCHAR(10) = '2019/09/21'

	UPDATE [PAG_LOTE_PAGO]
	SET pal_fechaAplicacion = convert(date,@FechaAplicacion)
	WHERE pal_id_lote_pago = @IdLote;

	SELECT 1 success
END
go

