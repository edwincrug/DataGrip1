


-- ====================================================
-- Author:		Fernando Alvarado Luna	
-- Create date: 31/01/2020
-- Description:	job que actualiza los estatus para los aplicados
-- ====================================================
--EXECUTE [UPD_LOTES_ESTATUS_SP]
CREATE PROCEDURE [dbo].[UPD_LOTES_ESTATUS_SP]

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		
			DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), idLotePago numeric(18, 0), idEmpresa numeric(18, 0),estatus numeric(18, 0))
			INSERT INTO @VariableTabla (idLotePago,idEmpresa,estatus) 

	        SELECT   pal_id_lote_pago, pal_id_empresa, pal_estatus
			FROM         PAG_LOTE_PAGO
			WHERE   (pal_fecha BETWEEN '01/01/2020 00:00:000' AND '31/01/2020 23:59:59') and (pal_estatus = 6)
			ORDER BY pal_id_lote_pago


			 DECLARE @total INT = (SELECT count(*) FROM @VariableTabla )	
			 DECLARE @aux   INT = 1

			 WHILE(@aux <=  @total)
						BEGIN
						declare @empresa as int
						declare @varidLOTE as numeric(18,0)
						declare @totaldetalle as decimal(18,5)
						declare @totaldoctos as decimal(18,5)
						SET @varidLOTE = (SELECT idLotePago FROM @VariableTabla WHERE ID = @aux)
						SET @totaldetalle = (SELECT SUM(pad_saldo) AS SUMADETALLE FROM PAG_PROGRA_PAGOS_DETALLE WHERE pal_id_lote_pago IN (@varidLOTE))
						SET @totaldoctos = (SELECT ISNULL(SUM(dpa_importepagado),0) AS SUMADOCTOS FROM cuentasxpagar.DBO.cxp_doctospagados WHERE dpa_lote IN (@varidLOTE) AND (dpa_pagoaplicado = 1))
						

						IF (@totaldetalle = @totaldoctos) 
						BEGIN
								UPDATE   PAG_LOTE_PAGO
								SET pal_estatus = 7
								WHERE pal_id_lote_pago = @varidLOTE
						END 

			  SET @aux = @aux + 1	

			  END 

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_LOTE_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 'Error en la consulta' 
END CATCH		     
END



go

