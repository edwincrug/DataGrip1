-- =============================================
-- Author:		
-- Create date: 07/04/20
-- Description:	<Description,,>
-- SEL_CORREOS_LOTE_SP 4
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CORREOS_LOTE_SP]
	@IdEmpresa INT = 0
AS

BEGIN


		SELECT PARAMETRO.USUARIO_AUTORIZA1, USUARIOS.USU_CORREO, empresa.RazonSocial 
		FROM [CENTRALIZACIONV2].[DBO].[DIG_PARAMETROS_PAGO] AS PARAMETRO
		INNER JOIN [CONTROLAPLICACIONES].DBO.CAT_USUARIOS AS USUARIOS ON PARAMETRO.USUARIO_AUTORIZA1 = USUARIOS.USU_IDUSUARIO
		INNER JOIN [Centralizacionv2].dbo.DIG_CAT_EMPRESA_RAZON as empresa on empresa.IdEmpresa = PARAMETRO.emp_idempresa
		WHERE PARAMETRO.EMP_IDEMPRESA = @IdEmpresa 
		AND PARAMETRO.USUARIO_TIPO = 2



END

go

