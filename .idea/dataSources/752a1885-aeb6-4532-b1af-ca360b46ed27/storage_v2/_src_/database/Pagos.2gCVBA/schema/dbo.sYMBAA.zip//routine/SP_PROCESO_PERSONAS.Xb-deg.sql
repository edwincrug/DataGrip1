-- =============================================
-- Author:		FAL
-- Create date: 19042018
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [SP_PROCESO_PERSONAS]
CREATE PROCEDURE [dbo].[SP_PROCESO_PERSONAS]
AS
BEGIN
				--Encontramos los parametros de la base de datos 
				DECLARE @total INT = (SELECT count(*) FROM [GA_Corporativa].[dbo].[unp_unificaciondet] WHERE upe_idunificacion in (
				SELECT upe_idunificacion FROM [GA_Corporativa].[dbo].[unp_unificacionenc] WHERE upe_fechaunificacion > '16/01/2019' and upe_estatus = 1))	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), perUNIFICA numeric(18,0), perUNIFICADA numeric(18,0) )
				DECLARE @IDPERSONAUNIFICA NUMERIC(18,0) = 0
				DECLARE @IDPERSONAUNIFICADA NUMERIC(18,0)= 0 
				INSERT INTO @VariableTabla (perUNIFICA,perUNIFICADA) 
				SELECT upd_idpersonaunifica, upd_idpersonaunificada FROM [GA_Corporativa].[dbo].[unp_unificaciondet] WHERE upe_idunificacion in (
				SELECT upe_idunificacion FROM [GA_Corporativa].[dbo].[unp_unificacionenc] WHERE upe_fechaunificacion > '16/01/2019' and upe_estatus = 1)
				WHILE(@aux <=  @total)
						BEGIN						
						SELECT @IDPERSONAUNIFICA = perUNIFICA, @IDPERSONAUNIFICADA = perUNIFICADA FROM @VariableTabla WHERE ID = @aux						
						IF EXISTS (SELECT pad_idProveedor FROM PAG_PROGRA_PAGOS_DETALLE WHERE pad_idProveedor = @IDPERSONAUNIFICADA) 
						BEGIN
						  SELECT @IDPERSONAUNIFICADA, 'SI ESTA' , @IDPERSONAUNIFICA
						  UPDATE PAG_PROGRA_PAGOS_DETALLE SET pad_idProveedor = @IDPERSONAUNIFICA WHERE pad_idProveedor = @IDPERSONAUNIFICADA
						END
						
					SET @aux = @aux + 1				
				END
END



go

