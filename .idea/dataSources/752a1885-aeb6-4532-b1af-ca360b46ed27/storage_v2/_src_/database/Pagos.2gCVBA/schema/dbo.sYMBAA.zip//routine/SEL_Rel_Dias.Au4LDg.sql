

-- =============================================
-- Author:		Irving Solorio Garcia
-- Create date: 29/04/2019
-- Description:	Obtener el dia por empresa
-- =============================================

create PROCEDURE [dbo].[SEL_Rel_Dias]

@idEmpresa int 
	
AS
BEGIN
SELECT d.[pag_idDias]
      ,d.[pag_Dias]
  FROM [dbo].[PAG_Dias] d 
  inner join PAG_REL_Dias r on d.pag_idDias=r.pag_idDias
where r.idEmpresa=@idEmpresa
END



go

