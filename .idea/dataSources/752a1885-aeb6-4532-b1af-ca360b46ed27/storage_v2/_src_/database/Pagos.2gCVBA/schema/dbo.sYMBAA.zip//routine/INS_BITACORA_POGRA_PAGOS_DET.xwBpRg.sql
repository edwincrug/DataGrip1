-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[INS_BITACORA_POGRA_PAGOS_DET] 
	-- Add the parameters for the stored procedure here
	@NumeroTransaccion varchar(16) = '',
	@idLotePago int 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	 BEGIN TRY 

	 DECLARE @TipoError int


	 select  @TipoError = (
	 select case charindex('-', NumeroReferenciadeTransaccion) 
	 when 0 then 2
	 else 1
	 end 
	 )
	 from referencias.dbo.LogBanamex
	 where NumeroReferenciadeTransaccion=@NumeroTransaccion


	 if @TipoError = 1

	 BEGIN

	insert into dbo.PAG_PROGRA_PAGOS_DETALLE_BITACORA (
	   [pal_id_lote_pago]
      ,[pad_id]
      ,[pad_idProveedor]
      ,[pad_polTipo]
      ,[pad_polAnnio]
      ,[pad_polMes]
      ,[pad_polConsecutivo]
      ,[pad_polMovimiento]
      ,[pad_polFechaOperacion]
      ,[pad_cuenta]
      ,[pad_proveedor]
      ,[pad_documento]
      ,[pad_tipo]
      ,[pad_tipoDocto]
      ,[pad_cartera]
      ,[pad_monto]
      ,[pad_saldo]
      ,[pad_saldoPorcentaje]
      ,[pad_moneda]
      ,[pad_fechaVencimiento]
      ,[pad_fechaPromesaPago]
      ,[pad_fechaRecepcion]
      ,[pad_fechaFactura]
      ,[pad_ordenCompra]
      ,[pad_idEstatus]
      ,[pad_estatus]
      ,[pad_anticipo]
      ,[pad_anticipoAplicado]
      ,[pad_annio]
      ,[pad_proveedorBloqueado]
      ,[pad_ordenBloqueada]
      ,[pad_diasCobro]
      ,[pad_aprobado]
      ,[pad_contReprog]
      ,[pad_documentoPagable]
      ,[pad_aPagar]
      ,[pad_nombreAgrupador]
      ,[pad_ordenAgrupador]
      ,[pad_ordenProveedor]
      ,[pad_cuentaProveedor]
      ,[pad_cuentaDestino]
      ,[pad_seleccionable]
      ,[pad_numeroSerie]
      ,[pad_facturaProveedor]
      ,[pad_polReferencia]
      ,[pbp_consCartera]
      ,[pad_bancoPagador]
      ,[pad_agrupamiento]
      ,[pad_convenioCIE]
      ,[pad_procesoBanco]
      ,[pad_idProveedorold]
      ,[pad_estatus_proceso]
	
	)
	select 
	 [pal_id_lote_pago]
      ,[pad_id]
      ,[pad_idProveedor]
      ,[pad_polTipo]
      ,[pad_polAnnio]
      ,[pad_polMes]
      ,[pad_polConsecutivo]
      ,[pad_polMovimiento]
      ,[pad_polFechaOperacion]
      ,[pad_cuenta]
      ,[pad_proveedor]
      ,[pad_documento]
      ,[pad_tipo]
      ,[pad_tipoDocto]
      ,[pad_cartera]
      ,[pad_monto]
      ,[pad_saldo]
      ,[pad_saldoPorcentaje]
      ,[pad_moneda]
      ,[pad_fechaVencimiento]
      ,[pad_fechaPromesaPago]
      ,[pad_fechaRecepcion]
      ,[pad_fechaFactura]
      ,[pad_ordenCompra]
      ,[pad_idEstatus]
      ,[pad_estatus]
      ,[pad_anticipo]
      ,[pad_anticipoAplicado]
      ,[pad_annio]
      ,[pad_proveedorBloqueado]
      ,[pad_ordenBloqueada]
      ,[pad_diasCobro]
      ,[pad_aprobado]
      ,[pad_contReprog]
      ,[pad_documentoPagable]
      ,[pad_aPagar]
      ,[pad_nombreAgrupador]
      ,[pad_ordenAgrupador]
      ,[pad_ordenProveedor]
      ,[pad_cuentaProveedor]
      ,[pad_cuentaDestino]
      ,[pad_seleccionable]
      ,[pad_numeroSerie]
      ,[pad_facturaProveedor]
      ,[pad_polReferencia]
      ,[pbp_consCartera]
      ,[pad_bancoPagador]
      ,[pad_agrupamiento]
      ,[pad_convenioCIE]
      ,[pad_procesoBanco]
      ,[pad_idProveedorold]
      ,[pad_estatus_proceso]
	  from  dbo.PAG_PROGRA_PAGOS_DETALLE where pad_polReferencia =@NumeroTransaccion

DELETE FROM dbo.PAG_PROGRA_PAGOS_DETALLE where pad_polReferencia =@NumeroTransaccion


Select 'Se movieron los datos de ' + @NumeroTransaccion as respuesta;
END
ELSE 
	 BEGIN

	insert into dbo.PAG_PROGRA_PAGOS_DETALLE_BITACORA (
	   [pal_id_lote_pago]
      ,[pad_id]
      ,[pad_idProveedor]
      ,[pad_polTipo]
      ,[pad_polAnnio]
      ,[pad_polMes]
      ,[pad_polConsecutivo]
      ,[pad_polMovimiento]
      ,[pad_polFechaOperacion]
      ,[pad_cuenta]
      ,[pad_proveedor]
      ,[pad_documento]
      ,[pad_tipo]
      ,[pad_tipoDocto]
      ,[pad_cartera]
      ,[pad_monto]
      ,[pad_saldo]
      ,[pad_saldoPorcentaje]
      ,[pad_moneda]
      ,[pad_fechaVencimiento]
      ,[pad_fechaPromesaPago]
      ,[pad_fechaRecepcion]
      ,[pad_fechaFactura]
      ,[pad_ordenCompra]
      ,[pad_idEstatus]
      ,[pad_estatus]
      ,[pad_anticipo]
      ,[pad_anticipoAplicado]
      ,[pad_annio]
      ,[pad_proveedorBloqueado]
      ,[pad_ordenBloqueada]
      ,[pad_diasCobro]
      ,[pad_aprobado]
      ,[pad_contReprog]
      ,[pad_documentoPagable]
      ,[pad_aPagar]
      ,[pad_nombreAgrupador]
      ,[pad_ordenAgrupador]
      ,[pad_ordenProveedor]
      ,[pad_cuentaProveedor]
      ,[pad_cuentaDestino]
      ,[pad_seleccionable]
      ,[pad_numeroSerie]
      ,[pad_facturaProveedor]
      ,[pad_polReferencia]
      ,[pbp_consCartera]
      ,[pad_bancoPagador]
      ,[pad_agrupamiento]
      ,[pad_convenioCIE]
      ,[pad_procesoBanco]
      ,[pad_idProveedorold]
      ,[pad_estatus_proceso]
	
	)
	select 
	 [pal_id_lote_pago]
      ,[pad_id]
      ,[pad_idProveedor]
      ,[pad_polTipo]
      ,[pad_polAnnio]
      ,[pad_polMes]
      ,[pad_polConsecutivo]
      ,[pad_polMovimiento]
      ,[pad_polFechaOperacion]
      ,[pad_cuenta]
      ,[pad_proveedor]
      ,[pad_documento]
      ,[pad_tipo]
      ,[pad_tipoDocto]
      ,[pad_cartera]
      ,[pad_monto]
      ,[pad_saldo]
      ,[pad_saldoPorcentaje]
      ,[pad_moneda]
      ,[pad_fechaVencimiento]
      ,[pad_fechaPromesaPago]
      ,[pad_fechaRecepcion]
      ,[pad_fechaFactura]
      ,[pad_ordenCompra]
      ,[pad_idEstatus]
      ,[pad_estatus]
      ,[pad_anticipo]
      ,[pad_anticipoAplicado]
      ,[pad_annio]
      ,[pad_proveedorBloqueado]
      ,[pad_ordenBloqueada]
      ,[pad_diasCobro]
      ,[pad_aprobado]
      ,[pad_contReprog]
      ,[pad_documentoPagable]
      ,[pad_aPagar]
      ,[pad_nombreAgrupador]
      ,[pad_ordenAgrupador]
      ,[pad_ordenProveedor]
      ,[pad_cuentaProveedor]
      ,[pad_cuentaDestino]
      ,[pad_seleccionable]
      ,[pad_numeroSerie]
      ,[pad_facturaProveedor]
      ,[pad_polReferencia]
      ,[pbp_consCartera]
      ,[pad_bancoPagador]
      ,[pad_agrupamiento]
      ,[pad_convenioCIE]
      ,[pad_procesoBanco]
      ,[pad_idProveedorold]
      ,[pad_estatus_proceso]
	  from  dbo.PAG_PROGRA_PAGOS_DETALLE where pad_procesoBanco =@NumeroTransaccion and
 pal_id_lote_pago = @idLotePago

DELETE FROM dbo.PAG_PROGRA_PAGOS_DETALLE where pad_procesoBanco = @NumeroTransaccion and
 pal_id_lote_pago = @idLotePago


Select 'Se movieron los datos de ' + @NumeroTransaccion as respuesta;
END

 END TRY  
    
  BEGIN CATCH  
  PRINT ('Error: ' + ERROR_MESSAGE())  
  DECLARE @Mensaje  nvarchar(max),  
  @Componente nvarchar(50) = '[INS_BITACORA_POGRA_PAGOS_DET]'  
  SELECT @Mensaje = ERROR_MESSAGE()  
  EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;   
  --SELECT 0 --Encontro error  
  SELECT 'ERROR EN LA CONSULTA' 
  END CATCH  
END

go

