


--EXECUTE [PROC_LIBERA_DOCUMENTO_SP] 2320, 'AU-AU-PED-UN-PE-727'                     
CREATE PROCEDURE [dbo].[PROC_LIBERA_DOCUMENTO_SP]
	 @idLote  int =0,
	 @documento varchar(100) = ''
	
AS
BEGIN
	SET NOCOUNT ON;

BEGIN TRY	
     	    
		DELETE FROM PAG_PROGRA_PAGOS_DETALLE WHERE pal_id_lote_pago = @idLote AND pad_documento = @documento
		SELECT 'BORRO BIEN--' + @documento
		
		UPDATE cuentasxpagar.DBO.cxp_ordencompra SET sod_idsituacionorden = 10 WHERE oce_folioorden = @documento

		SELECT * FROM cuentasxpagar.DBO.cxp_ordencompra WHERE oce_folioorden = @documento


		select 'OK'    		
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[PROC_ACTUALIZA_CARTERA_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 'Error en la consulta' 
END CATCH	
	 
END



go

