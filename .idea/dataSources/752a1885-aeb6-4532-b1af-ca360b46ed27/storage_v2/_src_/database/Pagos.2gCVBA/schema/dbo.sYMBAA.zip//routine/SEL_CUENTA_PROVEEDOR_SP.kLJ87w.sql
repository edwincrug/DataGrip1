
-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez
-- Create date: 02/08/2018
-- Description:	Stored que busca el idProveedor en cada concentradora de cada agencia 
--              para traerme la informacion de la cuenta.   --474 --24401
-- ==========================================================================================
-- EXECUTE [dbo].[SEL_CUENTA_PROVEEDOR_SP] @idProveedor = 263287    
CREATE PROCEDURE [dbo].[SEL_CUENTA_PROVEEDOR_SP]
     @idProveedor     INT
AS
BEGIN
	--DECLARE  @idProveedor     INT = 263287

	BEGIN TRY
	SET NOCOUNT ON;

    DECLARE @aux               INT = 1
	DECLARE @max               INT = 0
	DECLARE @idEmpresaBusca    INT = 0
	DECLARE @idSucursal        INT = 0
	DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
	DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL
	DECLARE @nomEmpresa        NVARCHAR(100)=NULL
	DECLARE @ipServidor        NVARCHAR(100)=NULL
	DECLARE @cadIpServidor     NVARCHAR(100)=NULL
	DECLARE @consulta          NVARCHAR(MAX)=NULL
	DECLARE @ipServer		   NVARCHAR(10)
	
	DECLARE @Cuentas TABLE    (  ID INT IDENTITY(1,1)
	                            ,idEmpresa           varchar(10)
								,nombreEmpresa       varchar(100)
								,BCO_CONSE           numeric(18, 0)
								,BCO_IDPERSONA       numeric(18, 0)
								,BCO_BANCO           varchar(200)
								,BCO_PLAZA           varchar(10)
								,BCO_SUCURSAL        varchar(50)
								,BCO_STATUS          varchar(20)
								,BCO_TIPCUENTA       varchar(20)
								,BCO_NUMCUENTA       varchar(25)
								,BCO_CLABE           varchar(20)
								,BCO_CVEUSU          varchar(10)
								,BCO_FECHOPE         varchar(50)
								,BCO_HORAOPE         varchar(8)
								,BCO_REFERNUM        varchar(35)
								,BCO_REFERALF        varchar(35)
								,BCO_CONVENIOCIE     varchar(10) 
								,BCO_AUTORIZADA		 int
								)
	
    ------------------------------------------------------------
	-- BUSCAMOS EN TODAS LAS CONCENTRADORAS
	------------------------------------------------------------	
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
	                        idEmpresa         int
							,nombreEmpresa     nvarchar(100)
							,nombreSucursal    nvarchar(100)
							,nomBaseConcentra  nvarchar(50)
							,nomBaseMatriz     nvarchar(50)
							,ipServidor        nvarchar(20)
							,idSucursal        int 
							)     

	 INSERT INTO @Bases
            SELECT B.[emp_idempresa]
			      ,A.[emp_nombre]
			      ,B.[nombre_sucursal]
				  ,B.[nombre_base]
				  ,B.[nombre_base_matriz]
				  ,B.[ip_servidor]
				  ,B.[sucursal_matriz]
			  FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B
			       INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] AS A ON A.[emp_idempresa]= B.[emp_idempresa]
			WHERE B.[catsuc_nombrecto] = 'CONCENTRA'

     --SELECT * FROM @Bases

	
	 ------------------------------------------------------------
	 -- RECORREMOS LAS CONCENTRADORAS PARA BUSCAR EL PROVEEDOR
	 ------------------------------------------------------------
	 SET @max = (SELECT MAX(IDB) FROM @Bases)
	 WHILE(@aux <= @max)
	 BEGIN
       --  SELECT @aux
		 SELECT  @idEmpresaBusca   = DB.idEmpresa 
		        ,@nomEmpresa       = DB.nombreEmpresa
				,@nomBaseConcentra = DB.nomBaseConcentra
				,@nomBaseMatriz    = DB.nomBaseMatriz
				,@idSucursal       = DB.idSucursal
				,@ipServidor       = DB.ipServidor
		   FROM @Bases AS DB 
		  WHERE DB.IDB = @aux 

		 IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @nomBaseConcentra)) 
					BEGIN

		  SET @cadIpServidor = '['+ @ipServidor  +'].'
		  
		  SELECT @ipServer = local_net_address
		  FROM sys.dm_exec_connections
          WHERE Session_id = @@SPID


		IF (@ipServidor = @ipServer)
		BEGIN
			SET @cadIpServidor =''
		END

		 -- SELECT @cadIpServidor

		 SET @consulta = ' SELECT  ' + cast (@idEmpresaBusca as varchar(20)) +' ,' +''''+ @nomEmpresa +'''' + '
		                            ,BCO_CONSE           
									,BCO_IDPERSONA       
									,ISNULL(P.PAR_DESCRIP1,BCO_BANCO)           
									,BCO_PLAZA          
									,BCO_SUCURSAL       
									,BCO_STATUS          
									,BCO_TIPCUENTA       
									,BCO_NUMCUENTA       
									,BCO_CLABE           
									,BCO_CVEUSU          
									,BCO_FECHOPE         
									,BCO_HORAOPE         
									,BCO_REFERNUM        
									,BCO_REFERALF       
									,BCO_CONVENIOCIE 
									,ISNULL(BCO_AUTORIZADA,0)         
		                     FROM '+ @cadIpServidor + @nomBaseConcentra +'.DBO.CON_BANCOS AS B  
									LEFT JOIN '+ @cadIpServidor + @nomBaseConcentra +'.DBO.PNC_PARAMETR AS P ON B.BCO_BANCO = P.PAR_IDENPARA AND PAR_TIPOPARA = ''BA'' AND PAR_STATUS = ''A''
							 WHERE BCO_IDPERSONA = ' + cast (@idProveedor as varchar(20)) 
		  
         -- SELECT @consulta
		  PRINT @consulta
		  INSERT INTO @Cuentas
		  EXECUTE (@consulta);
		  END
		-- select * from @Cuentas
		 SET @aux = @aux + 1
	 END
	
	 ------------------------------------------------------------
	 -- RESULTADO FINAL
	 ------------------------------------------------------------
	 SELECT  ID					
	        ,idEmpresa          
			,nombreEmpresa      
			,BCO_CONSE          
			,BCO_IDPERSONA      
			,BCO_BANCO          
			,BCO_PLAZA          
			,BCO_SUCURSAL       
			,BCO_STATUS         
			,BCO_TIPCUENTA      
			,BCO_NUMCUENTA      
			,BCO_CLABE          
			,BCO_CVEUSU         
			,BCO_FECHOPE        
			,BCO_HORAOPE        
			,BCO_REFERNUM       
			,BCO_REFERALF       
			,BCO_CONVENIOCIE    
			,BCO_AUTORIZADA		
     FROM	@Cuentas
	   
	END TRY

    BEGIN CATCH
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'SEL_CUENTA_PROVEEDOR_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
    END CATCH
END
go

