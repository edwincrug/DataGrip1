--exec [dbo].[UPD_CARTERA_FECHAPROMPAGO_SP] '62971',1, '03/09/2018','2017'
CREATE PROCEDURE [dbo].[UPD_CARTERA_FECHAPROMPAGO_SP]
	 @IdCartera VARCHAR (20) 
	,@IdEmpresa VARCHAR (20) 
	,@FechaPromPago VARCHAR (20)
	,@AnioCartera VARCHAR(4) 
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRY

	DECLARE @Concentradora VARCHAR(1000)
			,@sql NVARCHAR(1000)

	
	DECLARE @Server VARCHAR(100) =(
	SELECT local_net_address
    FROM sys.dm_exec_connections
    WHERE Session_id = @@SPID)

	
	SELECT	@Concentradora = CASE WHEN @Server =  ip_servidor THEN  '[' + nombre_base + '].[dbo].' 
								ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END
	FROM	[Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] 
	WHERE	tipo  = 2 
	AND		emp_idempresa = @IdEmpresa

	

	SET @sql = ' UPDATE '+ @Concentradora +'[BI_CARTERA_PAGOS]'  + char(13) + 
			    ' SET pbp_fechaPromesaPago = CONVERT(DATETIME,'+char(39)+ @FechaPromPago +char(39)+',103)'+ char(13) + 
			   ' WHERE  pbp_consCartera = ' + @IdCartera + char(13) 
	--PRINT @SQL
	EXEC  sp_executesql @sql

	SET @sql = ' UPDATE '+ @Concentradora +'[CON_CAR01'+ @AnioCartera+']'  + char(13) + 
			   ' SET CCP_FECHPROMPAG =  '+char(39)+ @FechaPromPago +char(39)+ char(13) + 
			   ' WHERE  CCP_CONSCARTERA = ' + @IdCartera + char(13) 


	
	--PRINT @SQL
	EXEC  sp_executesql @sql
	SELECT @@ROWCOUNT Result, 'Se actualizó con éxito el registro.' Mensaje

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max) = ERROR_MESSAGE()
	SELECT 0 Result, 'Ocurrio un error al actualizar el registro.' 
END CATCH
END



go

