-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 08/04/2016
-- Description:	SALDO TOTAL por cuenta de cada empresa (Todos los documentos)
-- ==========================================================================================
--EXECUTE [SEL_TOTAL_BANCOS_SP] 1                        --4: GAZM_Concentra
CREATE PROCEDURE [dbo].[SEL_TOTAL_BANCOS_SP]
	 @idEmpresa     decimal(18,0)
	--,@banco    VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
		       
				    SELECT BPRO.[pbp_cuentaPagadora] as cuentaPagadora 
					       ,SUM(BPRO.[pbp_saldo])    as sumaSaldo
						   ,CONVERT(INT,0)           as saldoLote
                    FROM [Pagos].[dbo].[PAG_PROGRA_PAGOS_BPRO] as BPRO
					WHERE BPRO.pbp_empresa = @idEmpresa
					AND datediff (day,BPRO.[pbp_fechaPromesaPago],getdate()) > 0
				  AND BPRO.[pbp_fechaPromesaPago] != '1900-01-01 00:00:00.000'
				  AND pbp_saldo > 0
                    GROUP BY BPRO.[pbp_cuentaPagadora]
					ORDER BY BPRO.[pbp_cuentaPagadora]
	   
END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_TOTAL_BANCOS_SP]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje; 
	 SELECT 0 --Encontro error
END CATCH		     
END

go

