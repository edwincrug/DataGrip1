

-- ==========================================================================================
-- Author:		Fernando Alvarado Luna
-- Create date: 17/05/2016
-- Description:	Trae datos si la sucursal es tipo financiera
-- ==========================================================================================
--EXECUTE [SEL_TIPO_CON_CONFCONTA] 
CREATE PROCEDURE [dbo].[SEL_TIPO_CON_CONFCONTA]
          @idUsuario  int = 0
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	    
--Debe mostrar solo las empresas relacionadas solo con ese usuario
SELECT ISNULL(CNC_IDPERSONA,0) as ID_PERSONA FROM [GAZM_Zaragoza].[dbo].CON_CONFCONTA WHERE CNC_CONFIGURA = 'COMPRA UNIDAD NUEVA' AND CNC_CONCEPTO ='CXP0' AND CNC_CONCEPTO3 ='PTA'

END TRY
BEGIN CATCH
     PRINT ('Error: ' + ERROR_MESSAGE())
	 DECLARE @Mensaje  nvarchar(max),
	 @Componente nvarchar(50) = '[SEL_TIPO_CON_CONFCONTA]'
	 SELECT @Mensaje = ERROR_MESSAGE()
	 EXECUTE [INS_ERROR_SP] @Componente, @Mensaje;  
	 SELECT 0 --Encontro error
END CATCH		     
END



go

