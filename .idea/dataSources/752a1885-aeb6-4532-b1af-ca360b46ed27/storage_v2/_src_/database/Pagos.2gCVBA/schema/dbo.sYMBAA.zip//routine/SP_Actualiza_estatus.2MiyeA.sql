

-- =============================================
-- Author:		FAL
-- Create date: 19042017
-- Description:	Aprueba el Lote
-- =============================================
--EXECUTE [SP_Actualiza_estatus]
CREATE PROCEDURE [dbo].[SP_Actualiza_estatus]
	

		
AS
BEGIN
				--Encontramos los parametros de la base de datos 

				DECLARE @total INT = (SELECT  COUNT (*) from (select DISTINCT  doctos.dpa_iddoctopagado, doctos.dpa_conscartera, doctos.dpa_iddocumento, doctos.dpa_lote, doctos.dpa_importepagado, det.pad_polReferencia, lote.pal_fecha
										from cuentasxpagar.dbo.cxp_doctospagados doctos 
										inner Join  Pagos.dbo.PAG_PROGRA_PAGOS_DETALLE det on doctos.dpa_lote = det.pal_id_lote_pago and doctos.dpa_conscartera = det.pbp_consCartera and doctos.dpa_iddocumento = det.pad_documento
										inner join pagos.dbo.PAG_LOTE_PAGO lote on lote.pal_id_lote_pago = det.pal_id_lote_pago 
										WHERE lote.pal_id_tipoLotePago = 1 AND dpa_iddoctopagado >= 40388)as cuantos)	
				DECLARE @aux   INT = 1
				DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), dpa_iddoctopagado int,  refAmpliada nvarchar(50) null, fecha datetime)
										
				INSERT INTO @VariableTabla (dpa_iddoctopagado,refAmpliada,fecha) 

				SELECT  DISTINCT doctos.dpa_iddoctopagado, det.pad_polReferencia, lote.pal_fecha
										from cuentasxpagar.dbo.cxp_doctospagados doctos 
										inner Join  Pagos.dbo.PAG_PROGRA_PAGOS_DETALLE det on doctos.dpa_lote = det.pal_id_lote_pago and doctos.dpa_conscartera = det.pbp_consCartera and doctos.dpa_iddocumento = det.pad_documento
										inner join pagos.dbo.PAG_LOTE_PAGO lote on lote.pal_id_lote_pago = det.pal_id_lote_pago 
										WHERE lote.pal_id_tipoLotePago = 1 AND dpa_iddoctopagado >= 40388 order by doctos.dpa_iddoctopagado

				WHILE(@aux <=  @total)
						BEGIN
						declare @docto as int
						declare @refAmpliada as nvarchar (50)
						declare @Fecha as datetime
						
						SELECT @docto = dpa_iddoctopagado , @refAmpliada = refAmpliada,  @Fecha = fecha FROM @VariableTabla WHERE ID = @aux
						--SELECT @refPropia, @varconcepto, @idBanco , @emp_idempresa

						EXECUTE [actualiza_fin] @docto, @refAmpliada, @Fecha
						 
					SET @aux = @aux + 1				
				END

	--SELECT * from  @VariableTabla

END



go

