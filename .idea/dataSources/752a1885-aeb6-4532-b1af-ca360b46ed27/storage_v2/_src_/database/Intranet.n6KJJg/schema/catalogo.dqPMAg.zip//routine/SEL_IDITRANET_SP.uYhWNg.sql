
-- =============================================
-- Author:		<Jose Dionicio Santamaria Barrera>
-- Create date: <4/11/2020>
-- Description:	<Obtener idDrive de la carpeta contenedora de intranet>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [catalogo].[SEL_PERMISOS_SP] @idusuario = 3,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [catalogo].[SEL_IDITRANET_SP]
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS

BEGIN
	SET @err = '';

	SELECT [valor]
	FROM [configuracion].[Parametro]
    WHERE [parametro] = 'idDrive'

END

go

