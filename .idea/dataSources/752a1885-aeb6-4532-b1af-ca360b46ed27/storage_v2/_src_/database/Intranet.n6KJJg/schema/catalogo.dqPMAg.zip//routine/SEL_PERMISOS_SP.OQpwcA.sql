
-- =============================================
-- Author:		<Luis Antonio Sanchez>
-- Create date: <23/10/2020>
-- Description:	<Obtiene el catalogo de permisos>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [catalogo].[SEL_PERMISOS_SP] @idusuario = 3,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [catalogo].[SEL_PERMISOS_SP]
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS

BEGIN
	SET @err = '';

	SELECT *
	FROM [catalogo].[TipoPermiso]

END
go

