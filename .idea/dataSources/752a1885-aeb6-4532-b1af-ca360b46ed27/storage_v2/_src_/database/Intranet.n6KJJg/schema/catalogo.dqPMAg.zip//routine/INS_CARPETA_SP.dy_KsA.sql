
-- =============================================
-- Author:		<Jose Dionicio Santamaria Barrera>
-- Create date: <4/11/2020>
-- Description:	<Insertar el arbol de carpetas de intranet>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [dato].[INS_CARPETA_SP] 
        @idusuario = 3
        @idDrive = ''
        @nombre = 'carpeta 1'
        @herencia = 0,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [catalogo].[INS_CARPETA_SP]
	@idUsuario				int,
    @idDrive                nvarchar(200),
    @parent                 nvarchar(200),
    @nombre                 nvarchar(150),
    @herencia               bigint,
	@err					varchar(max) OUTPUT
AS

BEGIN
    SET NOCOUNT ON;
	SET LANGUAGE Español;
    DECLARE @padre bigint;

	BEGIN TRY
    -- ================

        IF(@herencia != 0)
            BEGIN
            -- =================================
            -- Select rows from a Table or View '[Carpeta]' in schema '[dato]'
            SET @padre = (SELECT [idCarpeta] FROM [dato].[Carpeta]
                        WHERE idDrive = @parent);
            -- ==================================
            END
        ELSE
            BEGIN
            -- ==================================
            SET @padre =  0
            -- ==================================
            END
        
       -- Insert rows into table 'Carpeta' in schema '[dato]'
       INSERT INTO [dato].[Carpeta]
       ( -- Columns to insert data into
        [idDrive], [nombre], [herencia], [estatus], [fecha]
       )
       VALUES
       ( -- First row: values for the columns in the list above
        @idDrive, @nombre, @padre, 1, GetDate()
       );

       Select SCOPE_IDENTITY() AS 'ID_CARPETA';

    -- ================
    END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;

END

go

