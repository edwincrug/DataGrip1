CREATE procedure traslado.SEL_VEHICULO_GPS_SP 
@produccion	INT
,@vin varchar(50)
,@idUsuario	INT
, 	@err	VARCHAR(MAX) OUTPUT

AS
BEGIN
    SELECT top 1
                  pos.fixtime as date
                  ,pos.latitude
                  ,pos.longitude
                  ,pos.altitude
                  ,pos.speed
                  ,pos.course
                  ,pos.attributes
              FROM [192.168.20.110].[Tracker_Socket1].[dbo].[tc_devices] dev
              INNER JOIN [192.168.20.110].[Tracker_Socket1].[dbo].[tc_positions] pos on pos.id = dev.positionid
              INNER JOIN traslado.Vehiculo vei on vei.gps = dev.uniqueid
              WHERE dev.uniqueid = '2394082'-- vei.vin = @vin
END
go

