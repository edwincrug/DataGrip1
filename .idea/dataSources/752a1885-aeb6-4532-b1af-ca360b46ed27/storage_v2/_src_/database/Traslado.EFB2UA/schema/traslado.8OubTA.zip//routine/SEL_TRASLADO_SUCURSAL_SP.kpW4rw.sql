
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <13/12/2020>
-- Description:	<Obtiene los trasladoS POR SUCURSAL>
-- =============================================
/*
	Fecha		Autor	Descripción 
	EXEC [traslado].[SEL_TRASLADO_SUCURSAL_SP] 'ALL', NULL, 1, ''
	*- Testing...
	
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_TRASLADO_SUCURSAL_SP]
	@idSucursal			INT = NULL,
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	DECLARE @trasladoEstatus TABLE (
		titulo	VARCHAR(50),
		noAutos	INT,
		color VARCHAR(50),
		filtro	VARCHAR(50)
	)
	IF(@idSucursal IS NOT NULL)
	BEGIN
		---------------------------------------TODOS---------------------------------------
		INSERT INTO @trasladoEstatus
		SELECT 
			'Todos los traslados' AS titulo
			,COUNT(*) AS noAutos
			,'#000' AS color
			,'all' AS filtro
		FROM traslado.Traslado T
		WHERE T.idSucursal = @idSucursal
			  AND T.activo = 1
			  AND T.idEstatusTraslado NOT IN ('FIN')
		
		---------------------------------------EN RUTA---------------------------------------
		INSERT INTO @trasladoEstatus
		SELECT 
			'En ruta' AS titulo
			,COUNT(*) AS noAutos
			,'#000' AS color
			,'ruta' AS filtro
		FROM traslado.Traslado T
		WHERE GETDATE() BETWEEN T.fechaRealInicio AND T.fechaTermino
			  AND GETDATE() BETWEEN T.fechaRealInicio AND DATEADD(SECOND, T.tiempoTraslado, T.fechaRealInicio)
			  AND T.idEstatusTraslado = 'RUT'
			  AND T.idSucursal = @idSucursal
			  AND T.activo = 1
		---------------------------------------SALIDAS PENDIENTES---------------------------------------
		INSERT INTO @trasladoEstatus
		SELECT 
			'Salidas pendientes' AS titulo
			,COUNT(*) as noAutos
			,'#000' AS color
			,'pendiente' as filtro
		FROM traslado.Traslado T
		WHERE T.idEstatusTraslado = 'PEN'
			  AND T.idSucursal = @idSucursal
			  AND T.activo = 1

		---------------------------------------CON RETRASO---------------------------------------
		INSERT INTO @trasladoEstatus
		SELECT 
			'Con retraso' AS titulo
			,COUNT(*) as noAutos
			,'red' AS color
			,'retraso' as filtro
		FROM traslado.Traslado T
		WHERE GETDATE() > DATEADD(SECOND, T.tiempoTraslado, T.fechaRealInicio)
			  AND T.idEstatusTraslado = 'RUT'
			  AND T.idSucursal = @idSucursal
			  AND T.activo = 1
	END

	ELSE
	BEGIN
		---------------------------------------TODOS---------------------------------------
		INSERT INTO @trasladoEstatus
		SELECT 
			'Todos los traslados' AS titulo
			,COUNT(*) AS noAutos
			,'#000' AS color
			,'all' AS filtro
		FROM traslado.Traslado T
		WHERE T.activo = 1
		AND T.idEstatusTraslado NOT IN ('FIN')
		
		---------------------------------------EN RUTA---------------------------------------
		INSERT INTO @trasladoEstatus
		SELECT 
			'En ruta' AS titulo
			,COUNT(*) AS noAutos
			,'#000' AS color
			,'ruta' AS filtro
		FROM traslado.Traslado T
		WHERE GETDATE() BETWEEN T.fechaRealInicio AND T.fechaTermino
			  AND GETDATE() BETWEEN T.fechaRealInicio AND DATEADD(SECOND, T.tiempoTraslado, T.fechaRealInicio)
			  AND T.idEstatusTraslado = 'RUT'
			  AND T.activo = 1
		---------------------------------------SALIDAS PENDIENTES---------------------------------------
		INSERT INTO @trasladoEstatus
		SELECT 
			'Salidas pendientes' AS titulo
			,COUNT(*) as noAutos
			,'#000' AS color
			,'pendiente' as filtro
		FROM traslado.Traslado T
		WHERE T.idEstatusTraslado = 'PEN'
			  AND T.activo = 1

		---------------------------------------CON RETRASO---------------------------------------
		INSERT INTO @trasladoEstatus
		SELECT 
			'Con retraso' AS titulo
			,COUNT(*) as noAutos
			,'red' AS color
			,'retraso' as filtro
		FROM traslado.Traslado T
		WHERE GETDATE() > DATEADD(SECOND, T.tiempoTraslado, T.fechaRealInicio)
			  AND T.idEstatusTraslado = 'RUT'
			  AND T.activo = 1
	END

	SELECT * FROM @trasladoEstatus

END

go

