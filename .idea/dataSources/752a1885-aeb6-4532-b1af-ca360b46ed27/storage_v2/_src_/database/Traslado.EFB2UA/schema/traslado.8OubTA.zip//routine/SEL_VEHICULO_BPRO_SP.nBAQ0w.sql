
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <11/12/2020>
-- Description:	<Obtiene los vehiculos temporalmente>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	EXEC [traslado].[SEL_VEHICULO_BPRO_SP]
	2,0,18,''
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_VEHICULO_BPRO_SP]
	@idSucursal			INT = NULL,
	@produccion			INT,
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	
	DECLARE @BD VARCHAR(100),
			@consecutivoCOntable VARCHAR(100),
			@Sql NVARCHAR(MAX),
			@BDSucursal VARCHAR(100)


	IF(@produccion = 1)
	BEGIN
		SELECT
			@BD = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 1
		AND nombre = 'bpro'
	END

	ELSE
	BEGIN

		SELECT
			@BD = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 2
		AND nombre = 'bpro'
	END

	SET @Sql = 'select DISTINCT
					@BDSucursal = E.suc_nombrebd
				from seguridad.catalogo.usuario U
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_usuarios] UB ON LTRIM(RTRIM(UB.usu_nombreusu)) = LEFT(username,( CHARINDEX(''@'', USERNAME) -1)) COLLATE Modern_Spanish_CI_AS
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[ope_organigrama] O ON O.usu_idusuario  = ub.usu_idusuario
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_sucursales] E ON E.suc_idsucursal = O.suc_idSUCURSAL
				WHERE id = ' +  CAST(@idusuario AS VARCHAR(50)) + '
					  AND E.suc_nombrebd NOT IN (''NA'')
					  AND E.suc_idsucursal = ' + CAST(@idSucursal AS VARCHAR(50))
	print @sql
	EXEC sp_executesql @Sql, N'@BDSucursal VARCHAR(100) OUTPUT',
	@BDSucursal = @BDSucursal OUTPUT
	SET @Sql = ''

	SET @Sql = '
		SELECT DISTINCT
			SV.VEH_NUMSERIE vin
			,IU.colorExterior
			,IU.colorInterior
			,IU.modelo
			,IU.descModelo submarca
			,IU.marca
			,U.direccion
			,U.longitud
			,U.latitud
		FROM '+ @BD + '.' + @BDSucursal +'.dbo.SER_VEHICULO SV
		INNER JOIN '+ @BD + '.' + @BDSucursal +'.[dbo].[BI_INVENTARIO_UNIDADES] IU ON IU.veh_numserie = SV.veh_numserie
		LEFT JOIN traslado.Vehiculo V ON V.VIN = SV.VEH_NUMSERIE COLLATE Modern_Spanish_CI_AS
		LEFT JOIN catalogo.Ubicacion U ON U.idUbicacion = V.idUbicacion 
		WHERE SV.VEH_SITUACION IN (
			''FIS''
			,''ING''
			,''SFIS''
		)
		AND SV.VEH_NUMSERIE NOT IN (
			SELECT 
				vin COLLATE Modern_Spanish_CI_AS
			FROM traslado.Traslado 
			WHERE idSucursal = '+CAST(@idSucursal AS VARCHAR(50))+'
			AND idEstatusTraslado IN (
				''PEN''
				,''RUT''
			) 
		)
		ORDER BY IU.modelo DESC
	'
	PRINT @Sql
	EXEC sp_executesql @Sql
	SET @Sql = ''
	   	  
END
go

