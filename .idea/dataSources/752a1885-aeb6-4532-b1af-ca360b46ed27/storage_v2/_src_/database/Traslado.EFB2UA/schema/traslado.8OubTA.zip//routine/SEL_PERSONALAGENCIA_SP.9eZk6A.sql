
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <11/12/2020>
-- Description:	<Obtiene EL PERSONAL DE LA AGENCIA>
-- =============================================
/*
	Fecha		Autor	Descripción 
	
	
	*- Testing...
	
	EXEC [traslado].[SEL_PROVEEDOR_SP] 2, 0, 'PPT190502181', 18, ''
	
*/

-- =============================================
create PROCEDURE [traslado].[SEL_PERSONALAGENCIA_SP]
	@idSucursal			INT,
	@produccion			INT,
	@busqueda			VARCHAR(250),
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	--SELECT 
	--	*,
	--	rfcProveedor + ' / ' + nombreComercial + ' / ' + personaContacto as [label]
	--FROM traslado.Proveedor
	--WHERE rfcProveedor LIKE '%'+@busqueda+'%'
	--	OR nombreComercial LIKE '%'+@busqueda+'%'
	--	OR personaContacto LIKE '%'+@busqueda+'%'
	--	OR correo LIKE '%'+@busqueda+'%'

	DECLARE @BD VARCHAR(100),
			@consecutivoCOntable VARCHAR(100),
			@Sql NVARCHAR(MAX),
			@BDSucursal VARCHAR(100)


	IF(@produccion = 1)
	BEGIN
		SELECT
			@BD = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 1
		AND nombre = 'bpro'
	END

	ELSE
	BEGIN

		SELECT
			@BD = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 2
		AND nombre = 'bpro'
	END

	SET @Sql = 'select DISTINCT
					@BDSucursal = E.suc_nombrebd
				from seguridad.catalogo.usuario U
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_usuarios] UB ON LTRIM(RTRIM(UB.usu_nombreusu)) = LEFT(username,( CHARINDEX(''@'', USERNAME) -1)) COLLATE Modern_Spanish_CI_AS
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[ope_organigrama] O ON O.usu_idusuario  = ub.usu_idusuario
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_sucursales] E ON E.suc_idsucursal = O.suc_idSUCURSAL
				WHERE id = ' +  CAST(@idusuario AS VARCHAR(50)) + '
					AND E.suc_idsucursal = ' + CAST(@idSucursal AS VARCHAR(50))
	print @sql
	EXEC sp_executesql @Sql, N'@BDSucursal VARCHAR(100) OUTPUT',
	@BDSucursal = @BDSucursal OUTPUT
	SET @Sql = ''

	SET @Sql = '
		SELECT DISTINCT
			P.PER_IDPERSONA AS idBpro
			,P.PER_RFC AS rfc
			,P.PER_NOMRAZON AS nombre
			,P.PER_TELEFONO1 AS telefono
			,P.PER_EMAIL AS correo
			,CAST(P.PER_IDPERSONA AS VARCHAR(15)) + '' / '' + P.PER_RFC + '' / '' + P.PER_NOMRAZON as [label]
		FROM '+ @BD + '.' + @BDSucursal +'.dbo.PER_ROLES R
		LEFT JOIN '+ @BD + '.' + @BDSucursal +'.DBO.PER_PERSONAS P ON P.PER_IDPERSONA = R.ROL_IDPERSONA
		LEFT JOIN Common.direccion.Estado ES on ES.idEstado = P.PER_ESTADO COLLATE Modern_Spanish_CI_AS
		WHERE R.ROL_ROL NOT IN  (''TRASLA'')
		AND R.ROL_ESTATUS = 1
		AND P.PER_IDPERSONA LIKE '+'''%'+ @busqueda + '%''
		OR P.PER_RFC LIKE '+'''%'+ @busqueda + '%''
		OR P.PER_NOMRAZON LIKE '+'''%'+ @busqueda + '%''
		OR P.PER_EMAIL LIKE '+'''%'+ @busqueda + '%''
	'
	print @sql
	EXEC sp_executesql @Sql
	SELECT 'Personal de la agencia' AS grupo

END

go

