
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <11/12/2020>
-- Description:	<Obtiene tipos de gasto>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_TIPOGASTO_SP]
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		idTipoGasto
		,descripcion
		,url
	FROM catalogo.TipoGasto
	WHERE activo = 1
END
go

