
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <24/11/2020>
-- Description:	<Obtiene el catalogo de los tipos de viaje>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[SEL_TIPOVIAJE_SP]
		@idUbicacion
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[SEL_TIPOVIAJE_SP]
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		idTipoViaje,
		descripcion
	FROM catalogo.TipoViaje
	WHERE activo = 1
END
go

