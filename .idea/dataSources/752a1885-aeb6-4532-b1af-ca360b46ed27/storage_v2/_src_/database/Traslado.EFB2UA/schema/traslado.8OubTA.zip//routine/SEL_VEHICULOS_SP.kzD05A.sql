
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <20/12/2020>
-- Description:	<Obtiene los vehiculos de nuestra base de datos (busca por vin)>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	EXEC [traslado].[SEL_VEHICULOS_SP]
	1,0,18,''
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_VEHICULOS_SP]
	@produccion			INT,
	@busqueda			VARCHAR(50),
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	
	DECLARE @empresas TABLE (
		emp_idempresa VARCHAR(250),
		emp_nombre VARCHAR(250),
		emp_observaciones VARCHAR(250),
		emp_estatus VARCHAR(250)
	  )

	  DECLARE @sucursales TABLE (
		suc_idsucursal VARCHAR(250),
		suc_nombre VARCHAR(250),
		suc_ipbd VARCHAR(250),
		suc_nombrebd VARCHAR(250),
		suc_observaciones VARCHAR(250),
		emp_idempresa VARCHAR(250),
		suc_estatus	VARCHAR(250)	
	  )

	  --OBTENEMOS LAS EMPRESAS
	  INSERT INTO @empresas
	  EXEC Common.[bpro].[SEL_EMPRESAS_SP]	@idUsuario, @produccion, ''

	  --OBTENEMOS LAS SUCURSALES
	  INSERT INTO @sucursales
	  EXEC Common.[bpro].[SEL_SUCURSALES_SP] @idUsuario, @produccion, ''

	
		SELECT DISTINCT
			V.vin,
			V.VIN + ' / ' + V.marca + ' / ' + V.submarca + ' / ' + CAST(V.modelo AS VARCHAR(10)) as [label]
		FROM traslado.Traslado T
		INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
		INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
		INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
		WHERE V.vin LIKE '%'+@busqueda+'%'

		SELECT 'Unidades' AS grupo
	
END
go

