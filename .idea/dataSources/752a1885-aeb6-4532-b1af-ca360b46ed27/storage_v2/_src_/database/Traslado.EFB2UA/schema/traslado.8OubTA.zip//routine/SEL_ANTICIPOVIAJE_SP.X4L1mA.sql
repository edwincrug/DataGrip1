
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <20/12/2020>
-- Description:	<Obtiene anticipo de viake>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [traslado].[SEL_ANTICIPOVIAJE_SP]
		@idEmpresa = 1
		,@idSucursal = 1
		,@idUsuario = 20
		,@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_ANTICIPOVIAJE_SP]
	@idUsuario			INT,
	@idEmpresa			INT,
	@idSucursal			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		D.id_perTra folio
		,trade_devTotal total
		,trade_observaciones observaciones
		,petr_fechaTramite fechaTramite
		,concepto
	FROM Tramites.dbo.tramiteDevoluciones D 
	INNER JOIN Tramites.dbo.personaTramite T ON D.id_perTra = T.id_perTra
	where D.esde_idestatus = 2
	AND id_Empresa = @idEmpresa
	AND id_sucursal = @idSucursal
	and D.id_perTra NOT IN (SELECT FOLIO FROM [Traslado].[traslado].[CostoAnticipo])


--SELECT * FROM Tramites.Tramite.ConceptoContable cc
END
go

