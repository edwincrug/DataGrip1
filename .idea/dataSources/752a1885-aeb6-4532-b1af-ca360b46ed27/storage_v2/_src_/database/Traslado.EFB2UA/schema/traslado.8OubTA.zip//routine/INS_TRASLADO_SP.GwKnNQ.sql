
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <13/12/2020>
-- Description:	<Inserta UN TRASLADO>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[INS_UBICACION_SP]
		@asentamiento =  null,
		@ciudad =  null,
		@colonia =  null,
		@colorExterior =  "CONSTELACION",
		@colorInterior =  "TELA NEGRA",
		@correoPersonal =  "URIEL.TRINIDAD@GRUPOANDRADE.COM.MX",
		@correoProveedor =  null,
		@cp =  null,
		@delegacion =  null,
		@fechaInicio =  "2021-1-5 0:10:0",
		@fechaTermino =  "2021-1-5 0:49:53",
		@folioServicioAnticipo =  null,
		@folioServicioFondo =  "FF-AG-TLA-OT-1-19",
		@idBproPersonal =  374,
		@idBproProveedor =  null,
		@idEmpresa =  1,
		@idEstado =  null,
		@idPais =  null,
		@idPersonalAgencia =  null,
		@idSucursal =  1,
		@idTipoGasto =  null,
		@idTipoViaje =  1,
		@idUbicacionDestino =  6,
		@idUbicacionOrigen =  5,
		@marca =  "SUZUKI",
		@modelo =  "2021",
		@nombreComercial =  null,
		@nombrePersonal =  "URIEL ",
		@numeroExterior =  null,
		@numeroInterior =  null,
		@rfcPersonal =  "TIPU7409032A8",
		@rfcProveedor =  "",
		@submarca =  "IGNIS GLX CVT 1.2LT 4CIL",
		@telefonoPersonal =  "5518459678",
		@telefonoProveedor =  null,
		@tiempoTraslado =  2393,
		@vin =  "JS2FH81S1M6303010",
		@xmlFondos =  "<fondos><fondo><folio>FF-AG-TLA-OT-1-19</folio><subtotal>1242</subtotal></fondo></fondos>",
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [traslado].[INS_TRASLADO_SP]
	@idEmpresa              INT
	,@idSucursal            INT
	,@fechaInicio			DATETIME
	,@fechaTermino			DATETIME
	,@folioServicioFondo	VARCHAR(50)
	,@folioServicioAnticipo	VARCHAR(50)
	,@idPersonalAgencia		INT = NULL
	,@idTipoGasto			INT = 1
	,@idTipoViaje			INT
	,@idUbicacionDestino	INT
	,@idUbicacionOrigen		INT
	--,@iva					FLOAT
	--,@subTotal				FLOAT
	--,@total					FLOAT
	,@tiempoTraslado		INT
	
	--DATOS DEL PERSONAL DE LA AGENCIA
	,@correoPersonal				VARCHAR(500)
	,@nombrePersonal		VARCHAR(250)
	,@telefonoPersonal		VARCHAR(20) = null
	,@idBproPersonal		INT
	,@rfcPersonal			VARCHAR(50)
	
	--DATOS DEL PROVEEDOR
	,@rfcproveedor			VARCHAR(13) = NULL
	,@nombreComercial		VARCHAR(250)
	,@telefonoProveedor		VARCHAR(20)
	,@correoProveedor		VARCHAR(500)
	,@idPais				VARCHAR(4)
	,@idEstado				VARCHAR(2)
	,@ciudad				VARCHAR(450)
	,@delegacion			VARCHAR(450)
	,@colonia				VARCHAR(500)
	,@asentamiento			VARCHAR(250)
	,@numeroExterior		VARCHAR(100)
	,@numeroInterior		VARCHAR(100)
	,@cp					INT
	,@idBproProveedor		INT

	--DATOS VEHICULO
	,@vin					VARCHAR(20)
	,@marca					VARCHAR(50)
	,@submarca				VARCHAR(100)
	,@modelo				INT
	,@colorExterior			VARCHAR(250)
	,@colorInterior			VARCHAR(250)

	,@xmlFondos				XML = NULL
	,@xmlAnticipos			XML = NULL

	,@idUsuario				INT
	,@err					VARCHAR(MAX) OUTPUT

AS
BEGIN
	BEGIN TRY  
	BEGIN TRANSACTION  
		DECLARE @idTraslado INT
		IF (@idPersonalAgencia IS NULL OR @idPersonalAgencia = '' AND @correoPersonal IS NOT NULL)
		BEGIN
			
			INSERT INTO traslado.PersonalAgencia VALUES(
														@nombrePersonal
														,@correoPersonal
														,@telefonoPersonal
														,@idBproPersonal
														,@rfcPersonal)
			SET @idPersonalAgencia = @@IDENTITY
			
		END

		IF(@idPersonalAgencia = '')
		BEGIN
			SET @idPersonalAgencia = NULL;
		END

		IF(@rfcproveedor IS NOT NULL)
		BEGIN
			IF NOT EXISTS(SELECT * FROM traslado.Proveedor WHERE rfcProveedor = @rfcproveedor)
			BEGIN
				INSERT INTO traslado.Proveedor VALUES (
														@rfcproveedor
														,@nombreComercial
														,@telefonoProveedor
														,@correoProveedor
														,@idPais
														,@idEstado
														,@ciudad
														,@delegacion
														,@colonia
														,@asentamiento
														,@numeroExterior
														,@numeroInterior
														,@cp
														,@idBproProveedor
													   );
			END
		END

		IF NOT EXISTS(SELECT * FROM traslado.Vehiculo WHERE vin = @vin)
		BEGIN
			INSERT INTO traslado.Vehiculo (vin
										   ,marca
										   ,submarca
										   ,modelo
										   ,colorExterior
										   ,colorInterior
										   ,idUbicacion
											) VALUES (
													@vin
													,@marca
													,@submarca
													,@modelo
													,@colorExterior
													,@colorInterior
													,@idUbicacionOrigen
												 )
		END


		INSERT INTO traslado.Traslado (idEmpresa
									   ,idSucursal
									   ,rfcProveedor
									   ,idPersonalAgencia
									   ,idUbicacionOrigen
									   ,idUbicacionDestino
									   ,fechaInicio
									   ,fechaTermino
									   ,idTipoViaje
									   ,vin
									   ,idTipoGasto
									   ,folioServicioFondo
									   ,folioServicioAnticipo
									   --,subTotal
									   --,total
									   --,iva
									   ,idUsuario
									   ,activo
									   ,idEstatusTraslado
									   ,tiempoTraslado
									   ,fechaCreacion
									   ) VALUES(
											 @idEmpresa
											 ,@idSucursal
											 ,@rfcproveedor
											 ,@idPersonalAgencia
											 ,@idUbicacionOrigen
											 ,@idUbicacionDestino
											 ,@fechaInicio
											 ,@fechaTermino
											 ,@idTipoViaje
											 ,@vin
											 ,1
											 ,@folioServicioFondo
											 ,@folioServicioAnticipo
											 --,@subTotal
											 --,@total
											 --,@iva
											 ,@idUsuario
											 ,1
											 ,'PEN'
											 ,@tiempoTraslado
											 ,GETDATE())
		SET @idTraslado = @@IDENTITY

		DECLARE @folioTraslado VARCHAR(50) = CAST(@idEmpresa AS VARCHAR(15))+'-'+CAST(@idSucursal AS VARCHAR(15))+'-'+CAST(@idTraslado AS VARCHAR(15))

		UPDATE traslado.Traslado 
			SET folioTraslado = @folioTraslado
		WHERE idTraslado = @idTraslado

		SELECT @idTraslado AS idTraslado, @folioTraslado as folioTraslado

		DECLARE @tbl_fondos AS TABLE(
			folio		VARCHAR(100)
			,subTotal	FLOAT
			)

		DECLARE @tbl_anticipos AS TABLE(
			folio		VARCHAR(100)
			,subTotal	FLOAT
			)
			print 1111
			INSERT INTO @tbl_fondos(folio, subTotal)
			SELECT
				ParamValues.col.value('folio[1]','varchar(100)'),
				ParamValues.col.value('subtotal[1]','float')
				FROM @xmlFondos.nodes('fondos/fondo') AS ParamValues(col)
			print 22222
			INSERT INTO @tbl_anticipos(folio, subTotal)
			SELECT
				ParamValues.col.value('folio[1]','varchar(100)'),
				ParamValues.col.value('subtotal[1]','float')
				FROM @xmlAnticipos.nodes('anticipos/anticipo') AS ParamValues(col)

			INSERT INTO traslado.CostoFondo
			SELECT
				@idTraslado
				,folio
				,subTotal
			FROM @tbl_fondos

			INSERT INTO traslado.CostoAnticipo
			SELECT
				@idTraslado
				,folio
				,subTotal
			FROM @tbl_anticipos

	COMMIT  
	END TRY 

	BEGIN CATCH  
		SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
		SELECT @err  AS err
	ROLLBACK  
	END CATCH 
END

go

