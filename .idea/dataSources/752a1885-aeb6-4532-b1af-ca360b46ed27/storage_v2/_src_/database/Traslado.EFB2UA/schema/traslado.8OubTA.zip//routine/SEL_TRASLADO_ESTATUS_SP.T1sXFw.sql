
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <13/12/2020>
-- Description:	<Obtiene los estatus de un traslado>
-- =============================================
/*
	Fecha		Autor	Descripción 
	EXEC [traslado].[SEL_TRASLADO_ESTATUS_SP] 'all', 0, 18, 1, ''
	*- Testing...
	
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_TRASLADO_ESTATUS_SP]
	@filtro				VARCHAR(50),
	@idSucursal			INT = NULL,
	@idUsuario			INT,
	@produccion			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN

	DECLARE @empresas TABLE (
		emp_idempresa VARCHAR(250),
		emp_nombre VARCHAR(250),
		emp_observaciones VARCHAR(250),
		emp_estatus VARCHAR(250)
	)

	DECLARE @sucursales TABLE (
		suc_idsucursal VARCHAR(250),
		suc_nombre VARCHAR(250),
		suc_ipbd VARCHAR(250),
		suc_nombrebd VARCHAR(250),
		suc_observaciones VARCHAR(250),
		emp_idempresa VARCHAR(250),
		suc_estatus	VARCHAR(250)	
	)

	--OBTENEMOS LAS EMPRESAS
	INSERT INTO @empresas
	EXEC Common.[bpro].[SEL_EMPRESAS_SP]	@idUsuario, @produccion, ''

	--OBTENEMOS LAS SUCURSALES
	INSERT INTO @sucursales
	EXEC Common.[bpro].[SEL_SUCURSALES_SP] @idUsuario, @produccion, ''

	------------------------------------------------------------------------CON IDSUCURSAL--------------------------------------------------------------------------
	IF(@idSucursal IS NOT NULL AND @idSucursal > 0)
	BEGIN
		---------------------------------------TODOS---------------------------------------
		IF(@filtro = 'all')
		BEGIN
			SELECT 
				T.folioTraslado,
				ES.descripcion AS descripcionEstatus,
				E.emp_nombre AS nombreEmpresa,
				S.suc_nombre AS nombreSucursal,
				T.idTraslado,
				CASE
					WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
					WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
				END AS trasladista,
				t.vin,
				V.marca,
				V.submarca,
				V.modelo,
				T.fechaInicio,
				T.fechaTermino,
				(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
				(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
				CASE
					WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
					ELSE 0 
				END AS proveedor,
				CASE
					WHEN T.idPersonalAgencia IS NOT NULL THEN 1
					ELSE 0 
				END AS personalAgencia
			FROM traslado.Traslado T
			INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
			INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
			INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
			INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
			INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
			INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
			INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
			INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
			INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
			WHERE T.idSucursal = @idSucursal
				  AND T.activo = 1
				  AND T.idEstatusTraslado NOT IN ('FIN')
			SELECT 'Todos' AS titulo
		END
		---------------------------------------EN RUTA---------------------------------------
		IF(@filtro = 'ruta')
		BEGIN
			SELECT 
				T.folioTraslado,
				ES.descripcion AS descripcionEstatus,
				E.emp_nombre AS nombreEmpresa,
				S.suc_nombre AS nombreSucursal,
				T.idTraslado,
				CASE
						WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
						WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
					END AS trasladista,
					t.vin,
					V.marca,
					V.submarca,
					V.modelo,
					T.fechaInicio,
					T.fechaTermino,
					(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
					(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
					CASE
						WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
						ELSE 0 
					END AS proveedor,
					CASE
						WHEN T.idPersonalAgencia IS NOT NULL THEN 1
						ELSE 0 
					END AS personalAgencia
			FROM traslado.Traslado T
			INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
			INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
			INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
			INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
			INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
			INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
			INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
			INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
			INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
			WHERE GETDATE() BETWEEN T.fechaRealInicio AND T.fechaTermino
				  AND GETDATE() BETWEEN T.fechaRealInicio AND DATEADD(SECOND, T.tiempoTraslado, T.fechaRealInicio)
				  AND T.idEstatusTraslado = 'RUT'
				  AND T.idSucursal = @idSucursal
				  AND T.activo = 1
			SELECT 'En ruta' AS titulo
		END
		---------------------------------------SALIDAS PENDIENTES---------------------------------------
		IF (@filtro = 'pendiente')
		BEGIN
			SELECT 
				T.folioTraslado,
				ES.descripcion AS descripcionEstatus,
				E.emp_nombre AS nombreEmpresa,
				S.suc_nombre AS nombreSucursal,
				T.idTraslado,
				CASE
					WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
					WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
				END AS trasladista,
				t.vin,
				V.marca,
				V.submarca,
				V.modelo,
				T.fechaInicio,
				T.fechaTermino,
				(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
				(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
				CASE
					WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
					ELSE 0 
				END AS proveedor,
				CASE
					WHEN T.idPersonalAgencia IS NOT NULL THEN 1
					ELSE 0 
				END AS personalAgencia
			FROM traslado.Traslado T
			INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
			INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
			INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
			INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
			INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
			INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
			INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
			INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
			INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
			WHERE T.idEstatusTraslado = 'PEN'
				  AND T.idSucursal = @idSucursal
				  AND T.activo = 1
			SELECT 'Salidas pendientes' AS titulo
		END

		---------------------------------------CON RETRASO---------------------------------------
		IF(@filtro = 'retraso')
		BEGIN
			SELECT 
				T.folioTraslado,
				ES.descripcion AS descripcionEstatus,
				E.emp_nombre AS nombreEmpresa,
				S.suc_nombre AS nombreSucursal,
				T.idTraslado,
				CASE
					WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
					WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
				END AS trasladista,
				t.vin,
				V.marca,
				V.submarca,
				V.modelo,
				T.fechaInicio,
				T.fechaTermino,
				(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
				(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
				CASE
					WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
					ELSE 0 
				END AS proveedor,
				CASE
					WHEN T.idPersonalAgencia IS NOT NULL THEN 1
					ELSE 0 
				END AS personalAgencia
			FROM traslado.Traslado T
			INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
			INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
			INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
			INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
			INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
			INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
			INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
			INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
			INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
			WHERE GETDATE() > DATEADD(SECOND, T.tiempoTraslado, T.fechaRealInicio)
				  AND T.idSucursal = @idSucursal
				  AND T.idEstatusTraslado = 'RUT'
				  AND T.activo = 1
			SELECT 'Con retraso' AS titulo
		END
	END
	
	
	------------------------------------------------------------------------SIN IDSUCURSAL--------------------------------------------------------------------------
	
	
	ELSE
	BEGIN
		---------------------------------------TODOS---------------------------------------
		IF(@filtro = 'all')
		BEGIN
			SELECT 
				T.folioTraslado,
				ES.descripcion AS descripcionEstatus,
				E.emp_nombre AS nombreEmpresa,
				S.suc_nombre AS nombreSucursal,
				T.idTraslado,
				CASE
					WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
					WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
				END AS trasladista,
				t.vin,
				V.marca,
				V.submarca,
				V.modelo,
				T.fechaInicio,
				T.fechaTermino,
				(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
				(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
				CASE
					WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
					ELSE 0 
				END AS proveedor,
				CASE
					WHEN T.idPersonalAgencia IS NOT NULL THEN 1
					ELSE 0 
				END AS personalAgencia
			FROM traslado.Traslado T
			INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
			INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
			INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
			INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
			INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
			INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
			INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
			INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
			INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
			WHERE T.activo = 1
			AND T.idEstatusTraslado NOT IN ('FIN')

			SELECT 'Todos' AS titulo
		END
		---------------------------------------EN RUTA---------------------------------------
		IF(@filtro = 'ruta')
		BEGIN
			SELECT 
				T.folioTraslado,
				ES.descripcion AS descripcionEstatus,
				E.emp_nombre AS nombreEmpresa,
				S.suc_nombre AS nombreSucursal,
				T.idTraslado,
				CASE
						WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
						WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
					END AS trasladista,
					t.vin,
					V.marca,
					V.submarca,
					V.modelo,
					T.fechaInicio,
					T.fechaTermino,
					(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
					(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
					CASE
						WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
						ELSE 0 
					END AS proveedor,
					CASE
						WHEN T.idPersonalAgencia IS NOT NULL THEN 1
						ELSE 0 
					END AS personalAgencia
			FROM traslado.Traslado T
			INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
			INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
			INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
			INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
			INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
			INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
			INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
			INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
			INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
			WHERE GETDATE() BETWEEN T.fechaRealInicio AND T.fechaTermino
				  AND GETDATE() BETWEEN T.fechaRealInicio AND DATEADD(SECOND, T.tiempoTraslado, T.fechaRealInicio)
				  AND T.idEstatusTraslado = 'RUT'
				  AND T.activo = 1
			SELECT 'En ruta' AS titulo
		END
		---------------------------------------SALIDAS PENDIENTES---------------------------------------
		IF (@filtro = 'pendiente')
		BEGIN
			SELECT 
				T.folioTraslado,
				ES.descripcion AS descripcionEstatus,
				E.emp_nombre AS nombreEmpresa,
				S.suc_nombre AS nombreSucursal,
				T.idTraslado,
				CASE
					WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
					WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
				END AS trasladista,
				t.vin,
				V.marca,
				V.submarca,
				V.modelo,
				T.fechaInicio,
				T.fechaTermino,
				(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
				(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
				CASE
					WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
					ELSE 0 
				END AS proveedor,
				CASE
					WHEN T.idPersonalAgencia IS NOT NULL THEN 1
					ELSE 0 
				END AS personalAgencia
			FROM traslado.Traslado T
			INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
			INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
			INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
			INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
			INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
			INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
			INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
			INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
			INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
			WHERE T.idEstatusTraslado = 'PEN'
				  AND T.activo = 1
			SELECT 'Salidas pendientes' AS titulo
		END

		---------------------------------------CON RETRASO---------------------------------------
		IF(@filtro = 'retraso')
		BEGIN
			SELECT 
				T.folioTraslado,
				ES.descripcion AS descripcionEstatus,
				E.emp_nombre AS nombreEmpresa,
				S.suc_nombre AS nombreSucursal,
				T.idTraslado,
				CASE
					WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
					WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
				END AS trasladista,
				t.vin,
				V.marca,
				V.submarca,
				V.modelo,
				T.fechaInicio,
				T.fechaTermino,
				(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
				(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
				CASE
					WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
					ELSE 0 
				END AS proveedor,
				CASE
					WHEN T.idPersonalAgencia IS NOT NULL THEN 1
					ELSE 0 
				END AS personalAgencia
			FROM traslado.Traslado T
			INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
			INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
			INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
			INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
			INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
			INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
			INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
			INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
			INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
			WHERE GETDATE() > DATEADD(SECOND, T.tiempoTraslado, T.fechaRealInicio)
				  AND T.idEstatusTraslado = 'RUT'
				  AND T.activo = 1
			SELECT 'Con retraso' AS titulo
		END
	END

	

END

go

