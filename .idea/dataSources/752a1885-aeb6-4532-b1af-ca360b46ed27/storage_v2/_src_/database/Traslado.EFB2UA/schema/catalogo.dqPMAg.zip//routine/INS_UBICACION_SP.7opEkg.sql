
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <24/11/2020>
-- Description:	<Inserta una ubicacion>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[INS_UBICACION_SP]
		@idUbicacion
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[INS_UBICACION_SP]
	@idEmpresa              INT
	,@idSucursal            INT
	,@nombreUbicacion       VARCHAR(300)
	,@telefono              VARCHAR(20)
	,@cp                    VARCHAR(5)
	,@idEstado              INT
	,@idMunicipio           INT
	,@idTipoAsentamiento    INT
	,@asentamiento          VARCHAR(200)
	,@idTipoVialidad        INT
	,@vialidad              VARCHAR(200)
	,@numeroExterior        VARCHAR(20)
	,@numeroInterior        VARCHAR(20)
	,@latitud               FLOAT
	,@longitud              FLOAT
	,@direccion				VARCHAR(500) = NULL
	,@idUsuario				INT
	,@err					VARCHAR(MAX) OUTPUT

AS
BEGIN
	BEGIN TRY  
	BEGIN TRANSACTION  

		INSERT INTO catalogo.Ubicacion VALUES (
			 @idEmpresa
			,@idSucursal
			,@nombreUbicacion
			,@telefono
			,@cp
			,@idEstado
			,@idMunicipio
			,@idTipoAsentamiento
			,@asentamiento
			,@idTipoVialidad
			,@vialidad
			,@numeroExterior
			,@numeroInterior
			,@latitud
			,@longitud
			,@idUsuario
			,1
			,@direccion
		)

	COMMIT  
	END TRY 

	BEGIN CATCH  
		SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
		SELECT @err  
	ROLLBACK  
	END CATCH 
END
go

