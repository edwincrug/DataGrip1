
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <24/11/2020>
-- Description:	<Actualiza una ubicacion>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[UPD_UBICACION_SP]
		@idUbicacion
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[UPD_UBICACION_SP]
	@idUbicacion			INT
	,@nombreUbicacion       VARCHAR(300)
	,@telefono              VARCHAR(20)
	,@cp                    VARCHAR(5)
	,@idEstado              INT
	,@idMunicipio           INT
	,@idTipoAsentamiento    INT
	,@asentamiento          VARCHAR(200)
	,@idTipoVialidad        INT
	,@vialidad              VARCHAR(200)
	,@numeroExterior        VARCHAR(20)
	,@numeroInterior        VARCHAR(20)
	,@latitud               FLOAT
	,@longitud              FLOAT
	,@idUsuario				INT
	,@err					VARCHAR(MAX) OUTPUT

AS
BEGIN
	BEGIN TRY  
	BEGIN TRANSACTION  

		UPDATE catalogo.Ubicacion 
		SET 
			nombreUbicacion =          @nombreUbicacion
			,telefono =                 @telefono
			,cp =                       @cp
			,idEstado =                 @idEstado
			,idMunicipio =              @idMunicipio
			,idTipoAsentamiento =       @idTipoAsentamiento
			,asentamiento =             @asentamiento
			,idTipoVialidad =           @idTipoVialidad
			,vialidad =                 @vialidad
			,numeroExterior =           @numeroExterior
			,numeroInterior =           @numeroInterior
			,latitud =                  @latitud
			,longitud =                 @longitud
			,idUsuario =                @idUsuario
		WHERE idUbicacion = @idUbicacion

	COMMIT  
	END TRY 

	BEGIN CATCH  
		SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
		SELECT @err  
	ROLLBACK  
	END CATCH 
END
go

