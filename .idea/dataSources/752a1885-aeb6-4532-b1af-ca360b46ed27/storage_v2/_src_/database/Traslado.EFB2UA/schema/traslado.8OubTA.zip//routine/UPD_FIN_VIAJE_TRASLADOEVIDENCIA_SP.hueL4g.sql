
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <19/12/2020>
-- Description:	<Inserta la evidencia de un traslado y finaliza el traslado>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [traslado].[INS_VIAJE_TRASLADOEVIDENCIA_SP]
		@idTraslado = 6,
		@idEstatusTraslado = 'RUT',
		@xmlDocumentos = '<documentos><documento><idDocumento>539</idDocumento></documento><documento><idDocumento>540</idDocumento></documento></documentos>',
		,@idUsuario = 18,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [traslado].[UPD_FIN_VIAJE_TRASLADOEVIDENCIA_SP]
	@idTraslado			INT,
	@comentarios		VARCHAR(MAX),
	@idEstatusTraslado	VARCHAR(3),
	@xmlDocumentos		XML,
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	
	BEGIN TRY  
	BEGIN TRANSACTION  

		DECLARE @documentosTabla TABLE(
			idDocumento INT
		)

		INSERT INTO @documentosTabla
		SELECT
			ParamValues.col.value('idDocumento[1]','INT')
		FROM @xmlDocumentos.nodes('documentos/documento') AS ParamValues(col)

		DELETE [traslado].[TrasladoEvidencia] WHERE idTraslado = @idTraslado

		INSERT INTO [traslado].[TrasladoEvidencia] (idTraslado, idFileServer)
		SELECT
			@idTraslado
			,idDocumento
		FROM @documentosTabla

		UPDATE traslado.Traslado
			SET idEstatusTraslado = @idEstatusTraslado,
				fechaRealTermino = GETDATE(),
				comentarios = @comentarios
		WHERE idTraslado = @idTraslado

		DECLARE @vin VARCHAR (20),
		@idUbicacionDestino INT
		
		SELECT 
			@vin = vin,
			@idUbicacionDestino = idUbicacionDestino
		FROM traslado.Traslado 
		WHERE idTraslado = @idTraslado
		
		UPDATE traslado.Vehiculo
			SET idUbicacion = @idUbicacionDestino
		WHERE vin = @vin

	COMMIT  
	END TRY 

	BEGIN CATCH  
		SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
		SELECT @err  
	ROLLBACK  
	END CATCH 
END

go

