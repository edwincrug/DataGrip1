
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <20/12/2020>
-- Description:	<Obtiene los vehiculos de nuestra base de datos (busca por vin)>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	EXEC [traslado].[SEL_VEHICULOS_SP]
	1,0,18,''
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_VEHICULO_BY_VIN_SP]
	@produccion			INT,
	@vin				VARCHAR(20),
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	
	DECLARE @empresas TABLE (
		emp_idempresa VARCHAR(250),
		emp_nombre VARCHAR(250),
		emp_observaciones VARCHAR(250),
		emp_estatus VARCHAR(250)
	  )

	  DECLARE @sucursales TABLE (
		suc_idsucursal VARCHAR(250),
		suc_nombre VARCHAR(250),
		suc_ipbd VARCHAR(250),
		suc_nombrebd VARCHAR(250),
		suc_observaciones VARCHAR(250),
		emp_idempresa VARCHAR(250),
		suc_estatus	VARCHAR(250)	
	  )

	  --OBTENEMOS LAS EMPRESAS
	  INSERT INTO @empresas
	  EXEC Common.[bpro].[SEL_EMPRESAS_SP]	@idUsuario, @produccion, ''

	  --OBTENEMOS LAS SUCURSALES
	  INSERT INTO @sucursales
	  EXEC Common.[bpro].[SEL_SUCURSALES_SP] @idUsuario, @produccion, ''


	  ----------------------------------DATOS DEL VEHICULO----------------------------------
		SELECT DISTINCT
			V.*,
			U.direccion,
			U.latitud,
			U.longitud
		FROM traslado.Vehiculo V 
		INNER JOIN catalogo.Ubicacion U ON V.idUbicacion = U.idUbicacion
		WHERE V.vin = @vin


		----------------------------------HISTORIAL DEL VEHICULO----------------------------------
		SELECT 
			T.idTraslado,
			CASE
				WHEN rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN (SELECT nombreComercial FROM traslado.Proveedor WHERE rfcProveedor = T.rfcProveedor)
				WHEN idPersonalAgencia IS NOT NULL THEN (SELECT nombre FROM traslado.PersonalAgencia WHERE idPersonalAgencia = T.idPersonalAgencia)
			END AS trasladista,
			t.vin,
			V.marca,
			V.submarca,
			V.modelo,
			T.fechaInicio,
			T.fechaTermino,
			(EO.emp_nombre + '/' + SO.suc_nombre + '/' + UO.nombreUbicacion ) origen,
			(ED.emp_nombre + '/' + SD.suc_nombre + '/' + UD.nombreUbicacion ) destino,
			CASE
				WHEN T.rfcProveedor IS NOT NULL AND rfcProveedor != '' THEN 1
				ELSE 0 
			END AS proveedor,
			CASE
				WHEN T.idPersonalAgencia IS NOT NULL THEN 1
				ELSE 0 
			END AS personalAgencia,
			UO.latitud AS latitudOrigen,
			UO.longitud AS longitudOrigen,
			UD.latitud AS latitudDestino,
			UD.longitud AS longitudDestino,
			UO.direccion AS direccionOrigen,
			UD.direccion AS direccionDestino,
			T.idUbicacionOrigen,
			T.idUbicacionDestino,
			T.total,
			T.subTotal,
			T.iva,
			T.idEstatusTraslado,
			ES.descripcion,
			T.idTipoViaje,
			TV.descripcion AS descripcionTipoViaje,
			T.comentarios,
			T.folioTraslado
		FROM traslado.Traslado T
		INNER JOIN traslado.Vehiculo V ON V.vin = T.vin
		INNER JOIN catalogo.Ubicacion UO ON UO.idUbicacion = idUbicacionOrigen
		INNER JOIN catalogo.Ubicacion UD ON UD.idUbicacion = idUbicacionDestino
		INNER JOIN @empresas E ON E.emp_idempresa = T.idEmpresa
		INNER JOIN @sucursales S ON S.suc_idsucursal = T.idSucursal
		INNER JOIN @empresas EO ON EO.emp_idempresa = UO.idEmpresa
		INNER JOIN @sucursales SO ON SO.suc_idsucursal = UO.idSucursal
		INNER JOIN @empresas ED ON ED.emp_idempresa = UD.idEmpresa
		INNER JOIN @sucursales SD ON SD.suc_idsucursal = UD.idSucursal
		INNER JOIN catalogo.EstatusTraslado ES ON ES.idEstatusTraslado = T.idEstatusTraslado
		INNER JOIN catalogo.TipoViaje TV ON TV.idTipoViaje = T.idTipoViaje
		WHERE T.activo = 1
			AND T.vin = @vin
		ORDER BY T.fechaInicio DESC
	
END
go

