-- =============================================
CREATE PROCEDURE [catalogo].[SEL_UBICACION_SP]
	@idUbicacion		INT,
	@idUsuario			INT,
	@produccion			INT, 
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	
	DECLARE @empresas TABLE (
		emp_idempresa VARCHAR(250),
		emp_nombre VARCHAR(250),
		emp_observaciones VARCHAR(250),
		emp_estatus VARCHAR(250)
	  )

	  DECLARE @sucursales TABLE (
		suc_idsucursal VARCHAR(250),
		suc_nombre VARCHAR(250),
		suc_ipbd VARCHAR(250),
		suc_nombrebd VARCHAR(250),
		suc_observaciones VARCHAR(250),
		emp_idempresa VARCHAR(250),
		suc_estatus	VARCHAR(250)	
	  )

	  DECLARE @unidadesBPRO TABLE (
	  VIN		VARCHAR(100)
	  ,colorExterior		VARCHAR(250)
	  ,colorInterior		VARCHAR(250)
	  ,modelo				INT
	  ,submarca				VARCHAR(250)
	  ,marca				VARCHAR(250)
	  ,direccion			VARCHAR(500)
	  ,longitud				VARCHAR(250)
	  ,latitud				VARCHAR(250)
	  )

	  --OBTENEMOS LAS EMPRESAS
	  INSERT INTO @empresas
	  EXEC Common.[bpro].[SEL_EMPRESAS_SP]	@idUsuario, @produccion, ''

	  --OBTENEMOS LAS SUCURSALES
	  INSERT INTO @sucursales
	  EXEC Common.[bpro].[SEL_SUCURSALES_SP] @idUsuario, @produccion, ''

	SELECT DISTINCT
		 U.[idUbicacion]
		,U.[idEmpresa]
		,U.[idSucursal]
		,U.[nombreUbicacion]
		,U.[telefono]
		,U.[cp]
		,U.[idEstado]
		,U.[idMunicipio]
		,U.[idTipoAsentamiento]
		,U.[asentamiento]
		,U.[idTipoVialidad]
		,U.[vialidad]
		,U.[numeroExterior]
		,U.[numeroInterior]
		,U.[latitud]
		,U.[longitud]
		,ES.nombre AS estado
		,M.nombre AS municipio
		,U.direccion
		,(E.emp_nombre + '/' + S.suc_nombre + '/' + U.nombreUbicacion ) nombreCompleto
	FROM catalogo.Ubicacion U
	INNER JOIN Common.direccion.Estado ES ON ES.idEstado = U.idEstado
	INNER JOIN Common.direccion.Municipio M ON M.idMunicipio = U.idMunicipio AND M.idEstado = U.idEstado
	INNER JOIN @empresas E ON E.emp_idempresa = U.idEmpresa
	INNER JOIN @sucursales S ON S.suc_idsucursal = U.idSucursal
	WHERE activo = 1
	AND idUbicacion = @idUbicacion

	DECLARE @idSucursal INT = (SELECT idSucursal FROM catalogo.Ubicacion WHERE idUbicacion = @idUbicacion)

	INSERT INTO @unidadesBPRO
	EXEC [traslado].[SEL_VEHICULO_BPRO_SP] @idSucursal,0,18,''

	SELECT 
	vin
	,marca
	,submarca
	,modelo
	,colorExterior
	,colorInterior
	,@idUbicacion AS idUbicacion
	, '' as GPS
	FROM @unidadesBPRO

	UNION

	SELECT 
		*
	FROM traslado.Vehiculo
	WHERE idUbicacion = @idUbicacion
END
go

