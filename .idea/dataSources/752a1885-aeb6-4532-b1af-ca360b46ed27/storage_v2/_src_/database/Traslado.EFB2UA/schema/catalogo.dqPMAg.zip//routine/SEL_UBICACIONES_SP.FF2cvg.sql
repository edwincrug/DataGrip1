
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <24/11/2020>
-- Description:	<Obtiene las ubicaciones>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[SEL_UBICACIONES_SP]
		@produccion = 0,
		@idUsuario = 18,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[SEL_UBICACIONES_SP]
	@produccion			BIT,
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN

	DECLARE @empresas TABLE (
		emp_idempresa VARCHAR(250),
		emp_nombre VARCHAR(250),
		emp_observaciones VARCHAR(250),
		emp_estatus VARCHAR(250)
	  )

	  DECLARE @sucursales TABLE (
		suc_idsucursal VARCHAR(250),
		suc_nombre VARCHAR(250),
		suc_ipbd VARCHAR(250),
		suc_nombrebd VARCHAR(250),
		suc_observaciones VARCHAR(250),
		emp_idempresa VARCHAR(250),
		suc_estatus	VARCHAR(250)	
	  )

	  --OBTENEMOS LAS EMPRESAS
	  INSERT INTO @empresas
	  EXEC Common.[bpro].[SEL_EMPRESAS_SP]	@idUsuario, @produccion, ''

	  --OBTENEMOS LAS SUCURSALES
	  INSERT INTO @sucursales
	  EXEC Common.[bpro].[SEL_SUCURSALES_SP] @idUsuario, @produccion, ''

		SELECT 
			U.[idUbicacion]
			,E.emp_nombre
			,S.suc_nombre
			,U.[nombreUbicacion]
			,U.[telefono]
			,U.[cp]
			,U.[idEstado]
			,U.[idMunicipio]
			,U.[idTipoAsentamiento]
			,U.[asentamiento]
			,U.[idTipoVialidad]
			,U.[vialidad]
			,U.[numeroExterior]
			,U.[numeroInterior]
			,U.[latitud]
			,U.[longitud]
			,(E.emp_nombre + '/' + S.suc_nombre + '/' + U.nombreUbicacion ) nombreCompleto
			,ES.nombre AS estado
			,M.nombre AS municipio
			,U.direccion
		FROM catalogo.Ubicacion U
		INNER JOIN Common.direccion.Estado ES ON ES.idEstado = U.idEstado
		INNER JOIN Common.direccion.Municipio M ON M.idMunicipio = U.idMunicipio AND M.idEstado = ES.idEstado
		INNER JOIN @empresas E ON E.emp_idempresa = U.idEmpresa
		INNER JOIN @sucursales S ON S.suc_idsucursal = U.idSucursal
		WHERE activo = 1
END
go

