
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <20/12/2020>
-- Description:	<Obtiene anticipo de viake>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [traslado].[SEL_FONDOFIJO_SP]
		@idEmpresa = 1
		,@idSucursal = 1
		,@produccion = 2
		,@idUsuario = 20
		,@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_FONDOFIJO_SP]
	@idUsuario			INT,
	@idEmpresa			INT,
	@idSucursal			INT,
	@produccion			INT = 2,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN

	DECLARE --@BD VARCHAR(500),
			@sqlCommand NVARCHAR(MAX),
			@PAR_IDENPARA  VARCHAR(500)


	DECLARE @BD VARCHAR(100),
			@consecutivoCOntable VARCHAR(100),
			@Sql NVARCHAR(MAX),
			@BDSucursal VARCHAR(100)


	IF(@produccion = 1)
	BEGIN
		SELECT
			@BD = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 1
		AND nombre = 'bpro'
	END

	ELSE
	BEGIN

		SELECT
			@BD = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 2
		AND nombre = 'bpro'
	END

	SET @Sql = 'select DISTINCT
					@BDSucursal = E.suc_nombrebd
				from seguridad.catalogo.usuario U
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_usuarios] UB ON LTRIM(RTRIM(UB.usu_nombreusu)) = LEFT(username,( CHARINDEX(''@'', USERNAME) -1)) COLLATE Modern_Spanish_CI_AS
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[ope_organigrama] O ON O.usu_idusuario  = ub.usu_idusuario
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_sucursales] E ON E.suc_idsucursal = O.suc_idSUCURSAL
				WHERE id = ' +  CAST(@idusuario AS VARCHAR(50)) + '
					AND E.suc_idsucursal = ' + CAST(@idSucursal AS VARCHAR(50))
	print @sql
	EXEC sp_executesql @Sql, N'@BDSucursal VARCHAR(100) OUTPUT',
	@BDSucursal = @BDSucursal OUTPUT

	--SELECT @BD = suc_nombrebd FROM [ControlAplicaciones].[dbo].[cat_sucursales]
	--WHERE suc_idsucursal = @idSucursal
	--AND emp_idempresa = @idEmpresa


	SET @sqlCommand = 'SELECT @PAR_IDENPARA = PAR_IDENPARA
						FROM '+ @BD + '.' + @BDSucursal +'.[DBO].[PNC_PARAMETR]
						WHERE PAR_TIPOPARA = ''CONVEN'' 
						AND PAR_STATUS = ''A'' 
						AND PAR_IDMODULO = ''CON'' 
						AND PAR_DESCRIP1 like ''%traslado%unidades%'''
	print @sqlCommand
	EXEC sp_executesql @sqlCommand , N'@PAR_IDENPARA VARCHAR(500) OUTPUT',
	@PAR_IDENPARA = @PAR_IDENPARA OUTPUT

	
	select distinct
	v.idvale folio --FolioVale
	,v.fechaCreacionVale fechaTramite
	,v.descripcion concepto
	,'' observaciones
	,v.montoSolicitado total -- monto del vale
		from Tramites.Tramite.vales v
	inner join Tramites.Tramite.valesEvidencia e on v.id = e.idVales
	inner join tramites.[Tramite].[valesFondoFijo] vff on v.id = vff.idvales
	--inner join tramites.tramite.fondofijo ff on ff.idFondoFijo = v.idVale
	where v.estatusVale = 4 --Estatus del vale comprobado
	and e.conceptoafectacion in ( '' + @PAR_IDENPARA + '') 
	AND v.idvale NOT IN (select FOLIO from [Traslado].[traslado].[CostoFondo])

END

go

