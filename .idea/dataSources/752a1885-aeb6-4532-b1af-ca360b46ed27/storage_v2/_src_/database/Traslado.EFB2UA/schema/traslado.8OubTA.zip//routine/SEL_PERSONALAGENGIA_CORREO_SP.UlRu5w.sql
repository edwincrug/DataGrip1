
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <11/12/2020>
-- Description:	<Valida si el personal existe en la base de datos por el correo>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	
*/

-- =============================================
CREATE PROCEDURE [traslado].[SEL_PERSONALAGENGIA_CORREO_SP]
	@correo				varchar(500),
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	IF EXISTS(SELECT * FROM traslado.PersonalAgencia WHERE correo = @correo)
	BEGIN
		SELECT
			idPersonalAgencia,
			nombre,
			correo,
			telefono
		FROM traslado.PersonalAgencia
		WHERE correo = @correo
	END
	ELSE
	BEGIN
		SELECT 'no' AS validacion
	END
END
go

