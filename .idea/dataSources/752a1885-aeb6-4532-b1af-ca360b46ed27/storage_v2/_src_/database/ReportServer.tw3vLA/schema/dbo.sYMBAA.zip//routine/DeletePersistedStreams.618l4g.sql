
CREATE PROCEDURE [dbo].[DeletePersistedStreams]
@SessionID varchar(32)
AS
SET NOCOUNT OFF
delete 
    [ReportServerTempDB].dbo.PersistedStream
from 
    (select top 1 * from [ReportServerTempDB].dbo.PersistedStream PS2 where PS2.SessionID = @SessionID) as e1
where 
    e1.SessionID = [ReportServerTempDB].dbo.PersistedStream.[SessionID] and
    e1.[Index] = [ReportServerTempDB].dbo.PersistedStream.[Index]
go

