create view [dbo].[CON_GCFDI012004] as select * from [GAAAF_Concentra].dbo.[CON_GCFDI012004]
go

