create view [dbo].[vpfOrdendet] as 
select d.ORD_IDORDEN
, TipoOrden = isnull(pT.par_descrip1,d.ORD_TIPORDEN)
, QTYSolicitada = sum(d.ORD_CANTIDAD)
, QTYSurtida = sum(d.ord_surtido)
, Horas = sum(d.Ord_tiempotab)
, CostoMOB = sum(case when substring(d.ORD_Clasific,1,2) = 'MO' then d.Ord_Costo else 0 end)  --modulo = 'SER', tipopara = 'CL' idempara=ord_clasif
, CostoREF = sum(case when substring(d.ORD_Clasific,1,2) = 'RE' then d.Ord_Costo*d.ord_surtido else 0 end)
, CostoTOT = sum(case when substring(d.ORD_Clasific,1,2) = 'TT' then d.Ord_Costo else 0 end)
, CostoXVA = sum(case when substring(d.ORD_Clasific,1,2) = 'VA' then d.Ord_Costo else 0 end)
, CostoOTR = sum(case when substring(d.ORD_Clasific,1,2) not  in ('MO','RE','TT','VA','DG') then d.Ord_Costo else 0 end)
, VtaMOB = sum(case when substring(d.ORD_Clasific,1,2) = 'MO' then d.Ord_Subtotal else 0 end)  --modulo = 'SER', tipopara = 'CL' idempara=ord_clasif
, VtaREF = sum(case when substring(d.ORD_Clasific,1,2) = 'RE' then d.Ord_Subtotal else 0 end)
, VtaTOT = sum(case when substring(d.ORD_Clasific,1,2) = 'TT' then d.Ord_Subtotal else 0 end)
, VtaXVA = sum(case when substring(d.ORD_Clasific,1,2) = 'VA' then d.Ord_Subtotal else 0 end)
, VtaOTR = sum(case when substring(d.ORD_Clasific,1,2) not  in ('MO','RE','TT','VA','DG') then d.Ord_Subtotal else 0 end)
--, DSC = sum(case when substring(d.ORD_Clasific,1,2) = 'DG' then d.Ord_Subtotal else 0 end)
--, iva = sum(d.ORD_IVA)
from SER_ORDENDET d
Left Outer Join PNC_PARAMETR pT on
    pT.PAR_IDMODULO = 'SER'
and pT.PAR_DESCRIP2 = 'FACTURA SER'
and pT.PAR_IDENPARA = d.ORD_TIPORDEN
where d.ORD_STATUS <> 'X'
group by d.ORD_IDORDEN, isnull(pT.par_descrip1,d.ORD_TIPORDEN)
go

