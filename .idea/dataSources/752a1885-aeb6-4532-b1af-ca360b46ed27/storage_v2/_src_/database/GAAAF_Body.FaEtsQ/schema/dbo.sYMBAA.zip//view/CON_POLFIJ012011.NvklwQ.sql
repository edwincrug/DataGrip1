create view 	[dbo].[CON_POLFIJ012011]	 as select * from GAAAF_Concentra.dbo.CON_POLFIJ012011
go

