CREATE VIEW [dbo].[gen_indicadores]
AS
SELECT 
ind_idindicador, ind_proceso, ind_nombre, ind_valor, ind_definicion, ind_fechaalta, ind_usualta, ind_fechamodifica, ind_usumodifica, ind_estatus, pro_idproducto
FROM [cuentasxpagar].dbo.gen_indicadores
go

