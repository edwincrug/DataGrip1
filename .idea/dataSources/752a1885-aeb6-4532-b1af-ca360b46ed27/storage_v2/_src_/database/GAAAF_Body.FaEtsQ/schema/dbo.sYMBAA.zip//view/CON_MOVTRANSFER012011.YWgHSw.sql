create view [dbo].[CON_MOVTRANSFER012011] as select * from GAAAF_Concentra.dbo.CON_MOVTRANSFER012011
go

