CREATE  PROC  p_inserta_ceros
  @strNumero nvarchar(25),
  @Formato nvarchar(13) Output
As
Declare @Ceros nvarchar(13)
Declare @Lng Integer
Declare @LngCad Integer
Declare @a Integer
Declare @Caracter nvarchar(25)
set @a=1
set @LngCad= len(@strNumero)
set @Caracter=''
while @a<=@LngCad
BEGIN
if isnumeric(Substring(@strNumero,@a, 1))=1
  BEGIN
     set  @Caracter =  @Caracter+Substring(@strNumero,@a, 1)
   End
 set @a=@a+1
End
set @lng=13-len(@Caracter)
set @Ceros='0000000000000'
set @Ceros=left (@Ceros, @lng) +@Caracter
if @Ceros='0000000000000'
  BEGIN
   set @Formato=''
  End
Else
 BEGIN
  set @Formato=@Ceros
End
go

