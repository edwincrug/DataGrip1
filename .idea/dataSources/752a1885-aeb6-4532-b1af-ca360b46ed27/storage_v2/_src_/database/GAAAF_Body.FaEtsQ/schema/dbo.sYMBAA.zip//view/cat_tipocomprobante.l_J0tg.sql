CREATE VIEW [dbo].[cat_tipocomprobante] AS Select * From GAAAF_Concentra.dbo.cat_tipocomprobante
go

