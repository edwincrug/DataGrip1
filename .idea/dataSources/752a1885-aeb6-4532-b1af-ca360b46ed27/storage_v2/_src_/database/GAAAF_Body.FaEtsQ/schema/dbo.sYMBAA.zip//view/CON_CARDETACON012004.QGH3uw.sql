create view 	[dbo].[CON_CARDETACON012004]	as select * from GAAAF_Concentra.dbo.CON_CARDETACON012004
go

