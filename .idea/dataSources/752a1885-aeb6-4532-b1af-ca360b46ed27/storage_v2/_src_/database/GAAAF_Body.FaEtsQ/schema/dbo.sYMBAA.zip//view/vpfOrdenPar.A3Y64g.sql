create view [dbo].[vpfOrdenPar] as
select v.VTE_DOCTO
--, d.vtd_codigo, D.VTD_DESCRIP, PrecioUnitario = d.vtd_preciounitario
, cantidad = sum(d.vtd_cantidad), tiempo = sum(d.VTD_TIEMPOTAB)
, CostoMO = sum(case when substring(d.vtd_clasific,1,2) = 'MO' then d.vtd_costo else 0 end)
, CostoRE = sum(case when substring(d.vtd_clasific,1,2) = 'RE' then d.vtd_cantidad * d.vtd_costo else 0 end)
, CostoTT = sum(case when substring(d.vtd_clasific,1,2) = 'TT' then d.vtd_costo else 0 end)
, CostoOT = sum(case when substring(d.vtd_clasific,1,2) not in ('MO','RE','TT') then d.vtd_costo else 0 end)
, VentaMO = sum(case when substring(d.vtd_clasific,1,2) = 'MO' then d.vtd_preciounitario else  0 end)
, VentaRE = sum(case when substring(d.vtd_clasific,1,2) = 'RE' then d.vtd_preciounitario else  0 end)
, VentaTT = sum(case when substring(d.vtd_clasific,1,2) = 'TT' then d.vtd_preciounitario else  0 end)
, VentaOT = sum(case when substring(d.vtd_clasific,1,2) not in ('MO','RE','TT') then  d.vtd_preciounitario else 0 end)
from ade_vtafi  v 
Inner Join  ade_vtafidet d on
  v.VTE_DOCTO = d.VTD_IDDOCTO
--LEFT OUTER JOIN pnc_parametr ON d.vtd_clasific = par_idenpara and par_tipopara = 'CL' 
where substring(v.vte_tipodocto,1,1) = 'S'
and v.VTE_STATUS in ('I','C') 
and d.vtd_clasific <> 'DGD'
group by v.VTE_DOCTO, v.VTE_REFERENCIA1
go

