create view [dbo].[SQC_Familias] as select * from GAAAF_Concentra.dbo.SQC_Familias
go

