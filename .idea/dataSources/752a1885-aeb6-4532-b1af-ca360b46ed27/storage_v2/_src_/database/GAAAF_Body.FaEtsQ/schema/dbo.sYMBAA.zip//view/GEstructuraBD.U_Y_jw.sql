CREATE VIEW [dbo].[GEstructuraBD]
AS 
SELECT 
nProceso, cTabla cIdPersona, cIdPersonaMod, cWhere, cTipo, cComentarios
FROM GA_Corporativa.dbo.GEstructuraBD
go

