create view [dbo].[ADE_CFDREPMENDET] as select * from GAAAF_Concentra.dbo.ADE_CFDREPMENDET
go

