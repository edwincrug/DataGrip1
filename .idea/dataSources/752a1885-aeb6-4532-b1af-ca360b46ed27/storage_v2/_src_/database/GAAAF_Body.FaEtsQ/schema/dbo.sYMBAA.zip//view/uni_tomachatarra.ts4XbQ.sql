CREATE VIEW [dbo].[uni_tomachatarra] AS 
SELECT     utc_idtomachatarra, utc_tipotomachatarra, utc_nombrecorto, utc_importe, utc_porcentaje, utc_idusuarioalta,
utc_fechaalta, utc_estatus, ucu_idcotizacion, utc_idusuariomodifica, utc_fechamodifica
FROM       CUENTASPORCOBRAR.dbo.uni_tomachatarra;
go

