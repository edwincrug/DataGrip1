create view [dbo].[SQC_Liquidos] as select * from GAAAF_Concentra.dbo.SQC_Liquidos
go

