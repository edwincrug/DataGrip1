Create Function SICOP_HA_HECHO_MANEJO_DEMO (@Clave_Prospecto as nvarchar(15), @Fecha nvarchar(12))
  Returns Bit
AS
BEGIN
 Declare @TotalDemos int
Declare @SiNo Bit
set @TotalDemos= (Select
    Count(*)
    From
    SICOP_BITACORA_DEMOS
  Where
  C_ProspecTo=@Clave_Prospecto    and   Fecha Between DateAdd(dd, -90,@Fecha) And @Fecha )
 if @TotalDemos>0
  BEGIN
    set @SiNo= 1
  End
Else
  BEGIN
    set @SiNo=0
  End
Return @SiNo
End
go

