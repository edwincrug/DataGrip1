create view 	[dbo].[CON_POL012005]	 as select * from GAAAF_Concentra.dbo.CON_POL012005
go

