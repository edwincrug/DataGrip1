create view [dbo].[CON_MOVCHEQUE012008] as select * from GAAAF_Concentra.dbo.CON_MOVCHEQUE012008
go

