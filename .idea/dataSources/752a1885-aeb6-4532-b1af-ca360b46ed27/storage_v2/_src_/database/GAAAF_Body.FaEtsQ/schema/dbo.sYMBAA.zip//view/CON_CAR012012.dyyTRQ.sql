create view 	[dbo].[CON_CAR012012]	as select * from GAAAF_Concentra.dbo.CON_CAR012012
go

