create view [dbo].[SQC_Tipo_Vehiculos] as select * from GAAAF_Concentra.dbo.SQC_Tipo_Vehiculos
go

