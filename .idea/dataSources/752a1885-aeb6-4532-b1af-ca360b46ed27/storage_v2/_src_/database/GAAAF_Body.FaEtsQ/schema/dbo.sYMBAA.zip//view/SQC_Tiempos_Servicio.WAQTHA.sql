create view [dbo].[SQC_Tiempos_Servicio] as select * from GAAAF_Concentra.dbo.SQC_Tiempos_Servicio
go

