create view [dbo].[SQC_Operacion_FamiliaA] as select * from GAAAF_Concentra.dbo.SQC_Operacion_FamiliaA
go

