create view [dbo].[SQC_Partes2] as select * from GAAAF_Concentra.dbo.SQC_Partes2
go

