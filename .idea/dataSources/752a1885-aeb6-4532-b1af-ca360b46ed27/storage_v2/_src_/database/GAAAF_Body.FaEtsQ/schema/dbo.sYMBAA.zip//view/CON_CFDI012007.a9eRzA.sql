create view [dbo].[CON_CFDI012007] as select * from [GAAAF_Concentra].dbo.[con_cfdi012007]
go

