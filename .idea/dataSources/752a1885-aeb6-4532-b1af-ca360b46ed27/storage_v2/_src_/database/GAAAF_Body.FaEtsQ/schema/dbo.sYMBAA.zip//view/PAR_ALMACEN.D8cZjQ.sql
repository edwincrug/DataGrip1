create view [dbo].[PAR_ALMACEN] as select * from GAAAF_Viga.dbo.PAR_ALMACEN
go

