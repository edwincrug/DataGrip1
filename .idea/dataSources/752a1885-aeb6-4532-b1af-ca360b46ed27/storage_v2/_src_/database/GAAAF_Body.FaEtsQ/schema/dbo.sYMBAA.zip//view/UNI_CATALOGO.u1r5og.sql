create view [dbo].[UNI_CATALOGO ] AS SELECT * FROM GAAAF_Concentra..UNI_CATALOGO

