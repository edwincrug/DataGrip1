create view 	[dbo].[CON_CARDETACON012005]	as select * from GAAAF_Concentra.dbo.CON_CARDETACON012005
go

