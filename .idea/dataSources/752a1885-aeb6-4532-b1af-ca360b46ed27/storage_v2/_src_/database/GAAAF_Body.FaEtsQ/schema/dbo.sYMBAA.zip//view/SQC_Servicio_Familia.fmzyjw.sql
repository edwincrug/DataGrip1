create view [dbo].[SQC_Servicio_Familia] as select * from GAAAF_Concentra.dbo.SQC_Servicio_Familia
go

