create view [dbo].[CON_GCFDI012007] as select * from [GAAAF_Concentra].dbo.[CON_GCFDI012007]
go

