create view [dbo].[SQC_Operacion_VehiculoA] as select * from GAAAF_Concentra.dbo.SQC_Operacion_VehiculoA
go

