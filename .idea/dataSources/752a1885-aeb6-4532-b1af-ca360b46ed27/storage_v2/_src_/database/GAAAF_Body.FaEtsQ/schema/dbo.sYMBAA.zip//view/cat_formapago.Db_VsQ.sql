CREATE VIEW [dbo].[cat_formapago] AS Select * From GAAAF_Concentra.dbo.cat_formapago

