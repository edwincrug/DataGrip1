create view [dbo].[AseRef] as 
select vte_idcliente,VTE_DOCTO,VTE_FECHDOCTO, VTE_VTABRUT, VTE_IVA, VTE_TOTAL, pmm_tipoauto, pmm_idPOLIZA, pmm_idsiniestro 
from ade_vtafi, PAR_PEDMOST, PER_ROLES   
where 
VTE_IDCLIENTE = ROL_IDPERSONA
AND ROL_ROL = 'ASEG'
and VTE_DOCTO=pmm_ref2
and VTE_STATUS='i'
go

