create view [dbo].[PAR_PARTES] as select * from GAAAF_Viga.dbo.PAR_PARTES
go

