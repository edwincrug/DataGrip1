CREATE VIEW [dbo].[cat_sucursales]
AS
SELECT 
suc_idsucursal, gpo_idgrupo, div_iddivision, emp_idempresa, reg_idregion, suc_idpersona, suc_nombre, suc_nombrecto, suc_ipbd, suc_nombrebd, suc_alias, suc_observaciones, tps_idtiposuc, suc_subordinado, suc_fechaalta, suc_usualta, suc_fechamodifica, suc_usumodifica, suc_estatus
FROM        [ControlAplicaciones].dbo.cat_sucursales
go

