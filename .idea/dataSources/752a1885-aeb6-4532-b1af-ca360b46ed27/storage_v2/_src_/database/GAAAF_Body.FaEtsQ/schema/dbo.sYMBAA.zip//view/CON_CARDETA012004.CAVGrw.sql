create view 	[dbo].[CON_CARDETA012004]	as select * from GAAAF_Concentra.dbo.CON_CARDETA012004
go

