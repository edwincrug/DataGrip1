Create VIEW [dbo].[CXP_ORDENESMASIVAS] as select * from GAAAF_Concentra.[dbo].CXP_ORDENESMASIVAS
go

