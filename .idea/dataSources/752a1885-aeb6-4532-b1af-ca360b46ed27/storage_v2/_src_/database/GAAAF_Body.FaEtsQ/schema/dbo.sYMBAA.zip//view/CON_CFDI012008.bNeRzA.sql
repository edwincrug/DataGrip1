create view [dbo].[CON_CFDI012008] as select * from [GAAAF_Concentra].dbo.[con_cfdi012008]
go

