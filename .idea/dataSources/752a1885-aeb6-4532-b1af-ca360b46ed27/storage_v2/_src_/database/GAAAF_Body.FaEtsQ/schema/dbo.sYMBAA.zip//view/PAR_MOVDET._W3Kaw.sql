create view [dbo].[PAR_MOVDET] as select * from GAAAF_Viga.dbo.PAR_MOVDET
go

