-- CREATE VIEW	
create view 	[dbo].[CON_CTAS012003]	 as select * from GAAAF_Concentra.dbo.CON_CTAS012003
go

