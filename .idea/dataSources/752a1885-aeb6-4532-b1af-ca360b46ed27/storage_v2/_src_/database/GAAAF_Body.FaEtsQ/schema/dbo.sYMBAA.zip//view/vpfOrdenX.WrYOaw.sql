create view [dbo].[vpfOrdenX] as
select distinct d.ORD_IDORDEN, TipoOrden = isnull(pT.par_descrip1,d.ORD_TIPORDEN)
from SER_ORDENDET d
Left Outer Join PNC_PARAMETR pT on
    pT.PAR_IDMODULO = 'SER'
and pT.PAR_DESCRIP2 = 'FACTURA SER'
and pT.PAR_IDENPARA = d.ORD_TIPORDEN
where d.ORD_STATUS = 'X'
go

