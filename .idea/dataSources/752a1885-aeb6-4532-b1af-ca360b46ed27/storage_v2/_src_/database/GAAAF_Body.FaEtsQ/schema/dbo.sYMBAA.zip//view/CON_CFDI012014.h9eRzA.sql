create view [dbo].[CON_CFDI012014] as select * from [GAAAF_Concentra].dbo.[con_cfdi012014]
go

