create view [dbo].[PAR_MOVTOS] as select * from GAAAF_Viga.dbo.PAR_MOVTOS
go

