



CREATE procedure [dbo].[excepciones_partes]
as
begin
      set nocount on;

      --BATERIAS
      update par_partes set pts_preciopromo = pts_costpromo / .84 where pts_subgpo = '20'

      --ACEITE Y LIQUIDO
      update par_partes set pts_preciopromo = pts_cunrepo / .82
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('mxt5qmc','xo10w30qsd','mxo5w205qsp','mxo5w20qsp','mpm14aaa') 


      ------------------------------------------------------------------------------------
      --BALATAS
      update par_partes set pts_pcolista = 1465.67
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('m62uz2v200bcera') 

      
      ------------------------------------------------------------------------------------
      --SUSPENSION
      update par_partes set pts_pcomayoreo = 887.89, pts_pcolista = 1138.73
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('8l8z3a130a') 

      update par_partes set pts_pcomayoreo = 830, pts_pcolista = 1124.63
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('2l3z3a131ba') 

      update par_partes set pts_pcomayoreo = 676.74, pts_pcolista = 865.42
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('4c3z3049db') 
    
      ------------------------------------------------------------------------------------
      --PLUMAS
      update par_partes set pts_pcomayoreo = 52.06, pts_pcolista = 53.10
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('m2u2z17528ba') 

      update par_partes set pts_pcomayoreo = 194.25, pts_pcolista = 233.10
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('1s7z17528ba') 

      update par_partes set pts_pcomayoreo = 299.85, pts_pcolista = 299.85
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('7t4z17528bc') 

      update par_partes set pts_pcomayoreo = 285.95, pts_pcolista = 285.95
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('7t4z17528c') 

      update par_partes set pts_pcomayoreo = 170.63, pts_pcolista = 204.75
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('8l8z17528c') 
      
      update par_partes set pts_pcomayoreo = 107.25, pts_pcolista = 128.70
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('mww1921') 

      update par_partes set pts_pcomayoreo = 73.34, pts_pcolista = 79.56
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('mww10318') 

      update par_partes set pts_pcomayoreo = 40.12, pts_pcolista = 50.70
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('mww1508') 

      update par_partes set pts_pcomayoreo = 37.50, pts_pcolista = 50.00
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('mww1611')
      
      ---NUEVAS
      
      update par_partes set pts_pcomayoreo = 260.66, pts_pcolista = 260.66, pts_preciopromo = 260.66
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('MBG3AK2420AA')
      
      -- 8 aGO update par_partes set pts_pcomayoreo = 112.85, pts_pcolista = 112.85, pts_preciopromo = 112.85
      --where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      --in ('1135010')
      
      update par_partes set pts_pcomayoreo = 789.44 , pts_pcolista = 789.44 , pts_preciopromo = 789.44 
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('MXL3Z2C018AB')     
                
      update par_partes set pts_pcomayoreo = 3264.57  , pts_pcolista = 3264.57  , pts_preciopromo = 3264.57 
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('M2S652140BA')  
       
      update par_partes set pts_pcomayoreo =381.91, pts_pcolista = 381.91,  pts_preciopromo = 381.91 
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('M2S652078AC')   
        
      update par_partes set pts_pcomayoreo =387.34 , pts_pcolista = 387.34 ,  pts_preciopromo = 387.34
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('MF75Z2001AALS')     




-------------------------------------------------------------------------------------------------------------------------------------------------------
--ROCIO 
--PLUMAS
      update par_partes set pts_pcomayoreo = 52.30, pts_pcolista = 52.30
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('1014368')

      update par_partes set pts_pcomayoreo = 127.71, pts_pcolista = 127.71
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('1326535')

      
      update par_partes set pts_pcomayoreo = 184.61, pts_pcolista = 184.61
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('1105327')

      
      update par_partes set pts_pcomayoreo = 630.53, pts_pcolista = 630.53
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('1125933')

      update par_partes set pts_pcomayoreo = 180.73, pts_pcolista = 180.73
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('1132443')


      update par_partes set pts_pcomayoreo = 275, pts_pcolista = 275
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('2S4Z17528AB')

      update par_partes set pts_pcomayoreo = 138.68, pts_pcolista = 138.68
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('4U2Z17528CA')


      update par_partes set pts_pcomayoreo = 245.61, pts_pcolista = 245.61
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('4U2Z17528KA')


      update par_partes set pts_pcomayoreo = 155.48, pts_pcolista = 155.48
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('6L2Z17528AA')

      update par_partes set pts_pcomayoreo = 251.61, pts_pcolista = 251.61
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('7T4Z17528AC')

      update par_partes set pts_pcomayoreo = 92.61, pts_pcolista = 92.61
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('MWW10316')

      update par_partes set pts_pcomayoreo = 62.00, pts_pcolista = 62.00
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('MWW2222')

      update par_partes set pts_pcomayoreo = 151.89, pts_pcolista = 151.89
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('XF2Z17528AD')

      update par_partes set pts_pcomayoreo = 80.75, pts_pcolista = 80.75
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('XL2Z17528CE')

      update par_partes set pts_pcomayoreo = 155.48, pts_pcolista = 155.48
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('YC3Z17528BA')

      update par_partes set pts_pcomayoreo = 208.42, pts_pcolista = 208.42
      where rtrim(ltrim(substring(pts_idparte,1,8)))+ rtrim(ltrim(substring(pts_idparte,10,8))) + rtrim(ltrim(substring(pts_idparte,19,6)))
      in ('YL8Z17528AB')
      
      
      --Por alta en precios de ford precio lista = cto ford/ .80 y precio mayoreo = cto ford / .85  25 Octubre 2012
update par_partes set pts_pcomayoreo =2930.6, pts_pcolista =2930.6,  PTS_COSTPROMO=2491.01, pts_preciopromo =2646.698125   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='M2N1516006AH'
update par_partes set pts_pcomayoreo =106.517647058824, pts_pcolista =106.517647058824,  PTS_COSTPROMO=90.54, pts_preciopromo =96.19875   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='MXS6E6571AB'
update par_partes set pts_pcomayoreo =686.882352941176, pts_pcolista =686.882352941176,  PTS_COSTPROMO=583.85, pts_preciopromo =620.340625   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='6E5Z8200C'
update par_partes set pts_pcomayoreo =79.5176470588235, pts_pcolista =79.5176470588235,  PTS_COSTPROMO=67.59, pts_preciopromo =71.814375   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='F6TZ99404A42AA'
--update par_partes set pts_pcomayoreo =263.835294117647, pts_pcolista =263.835294117647,  PTS_COSTPROMO=224.26, pts_preciopromo =238.27625   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='M6E5Z17A385AA'
update par_partes set pts_pcomayoreo =460.482352941176, pts_pcolista =460.482352941176,  PTS_COSTPROMO=391.41, pts_preciopromo =415.873125   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='1L2Z8678AB'
update par_partes set pts_pcomayoreo =32, pts_pcolista =32,  PTS_COSTPROMO=27.2, pts_preciopromo =28.9   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='W702527S437'
update par_partes set pts_pcomayoreo =1833.11764705882, pts_pcolista =1833.11764705882,  PTS_COSTPROMO=1558.15, pts_preciopromo =1655.534375   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='MAC3Z3A131CB'
update par_partes set pts_pcomayoreo =1309.6, pts_pcolista =1309.6,  PTS_COSTPROMO=1113.16, pts_preciopromo =1182.7325   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='XL3Z3590AA'
update par_partes set pts_pcomayoreo =1228.8, pts_pcolista =1228.8,  PTS_COSTPROMO=1044.48, pts_preciopromo =1109.76   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='MXL3Z17K833AAA'
update par_partes set pts_pcomayoreo =3490.4, pts_pcolista =3490.4,  PTS_COSTPROMO=2966.84, pts_preciopromo =3152.2675   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='9L1Z16138A'
update par_partes set pts_pcomayoreo =2272.48235294118, pts_pcolista =2272.48235294118,  PTS_COSTPROMO=1931.61, pts_preciopromo =2052.335625   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='2U3Z6D256DA'
update par_partes set pts_pcomayoreo =37.7882352941176, pts_pcolista =37.7882352941176,  PTS_COSTPROMO=32.12, pts_preciopromo =34.1275   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='2L1Z1012AA'
update par_partes set pts_pcomayoreo =143, pts_pcolista =143,  PTS_COSTPROMO=121.55, pts_preciopromo =129.146875   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='MBE8Z17K707C'
update par_partes set pts_pcomayoreo =175.835294117647, pts_pcolista =175.835294117647,  PTS_COSTPROMO=149.46, pts_preciopromo =158.80125   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='1L3Z9461AA'
update par_partes set pts_pcomayoreo =638.235294117647, pts_pcolista =638.235294117647,  PTS_COSTPROMO=542.5, pts_preciopromo =576.40625   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='1S7Z6051AA'
update par_partes set pts_pcomayoreo =2900.95294117647, pts_pcolista =2900.95294117647,  PTS_COSTPROMO=2465.81, pts_preciopromo =2619.923125   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='MXL3Z17626ABC'
update par_partes set pts_pcomayoreo =917.917647058824, pts_pcolista =917.917647058824,  PTS_COSTPROMO=780.23, pts_preciopromo =828.994375   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='BC3Z3D746A'
update par_partes set pts_pcomayoreo =194.588235294118, pts_pcolista =194.588235294118,  PTS_COSTPROMO=165.4, pts_preciopromo =175.7375   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='MF4TZ8100B'
update par_partes set pts_pcomayoreo =219.835294117647, pts_pcolista =219.835294117647,  PTS_COSTPROMO=186.86, pts_preciopromo =198.53875   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='7L1Z17E857A'
update par_partes set pts_pcomayoreo =3505.76470588235, pts_pcolista =3505.76470588235,  PTS_COSTPROMO=2979.9, pts_preciopromo =3166.14375   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='9L3Z3A674C'
update par_partes set pts_pcomayoreo =412.635294117647, pts_pcolista =412.635294117647,  PTS_COSTPROMO=350.74, pts_preciopromo =372.66125   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='MD2TZ4813A'
update par_partes set pts_pcomayoreo =3201.6, pts_pcolista =3201.6,  PTS_COSTPROMO=2721.36, pts_preciopromo =2891.445   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='9C3Z9E926C'
update par_partes set pts_pcomayoreo =311.764705882353, pts_pcolista =311.764705882353,  PTS_COSTPROMO=265, pts_preciopromo =281.5625   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='MAL5JJ17D720AA'
update par_partes set pts_pcomayoreo =93.2823529411765, pts_pcolista =93.2823529411765,  PTS_COSTPROMO=79.29, pts_preciopromo =84.245625   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='M5L5Z17A861AA'
update par_partes set pts_pcomayoreo =1222.71764705882, pts_pcolista =1222.71764705882,  PTS_COSTPROMO=1039.31, pts_preciopromo =1104.266875   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='9L1Z5A972A'
update par_partes set pts_pcomayoreo =41.4235294117647, pts_pcolista =41.4235294117647,  PTS_COSTPROMO=35.21, pts_preciopromo =37.410625   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='D7UZ3B244C'
update par_partes set pts_pcomayoreo =651.682352941176, pts_pcolista =651.682352941176,  PTS_COSTPROMO=553.93, pts_preciopromo =588.550625   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='BC3Z17B985A'
update par_partes set pts_pcomayoreo =368.8, pts_pcolista =368.8,  PTS_COSTPROMO=313.48, pts_preciopromo =333.0725   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='BC3Z17K833CA'
update par_partes set pts_pcomayoreo =685.764705882353, pts_pcolista =685.764705882353,  PTS_COSTPROMO=582.9, pts_preciopromo =619.33125   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='1127721'
update par_partes set pts_pcomayoreo =496.847058823529, pts_pcolista =496.847058823529,  PTS_COSTPROMO=422.32, pts_preciopromo =448.715   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='7L1Z16039BPTM'
update par_partes set pts_pcomayoreo =303.835294117647, pts_pcolista =303.835294117647,  PTS_COSTPROMO=258.26, pts_preciopromo =274.40125   where replace(REPLACE(pts_idparte, '-', ' '), ' ', '') ='XF2Z9461AA'
                      
end



go

