create view [dbo].[CON_CFDI012005] as select * from [GAAAF_Concentra].dbo.[con_cfdi012005]
go

