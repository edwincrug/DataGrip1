create view [dbo].[ADE_CANCFD] as select * from GAAAF_Concentra.dbo.ADE_CANCFD
go

