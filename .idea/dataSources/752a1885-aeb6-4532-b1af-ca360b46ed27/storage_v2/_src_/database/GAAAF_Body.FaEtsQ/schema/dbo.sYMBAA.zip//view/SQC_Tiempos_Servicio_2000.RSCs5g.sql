create view [dbo].[SQC_Tiempos_Servicio_2000] as select * from GAAAF_Concentra.dbo.SQC_Tiempos_Servicio_2000
go

