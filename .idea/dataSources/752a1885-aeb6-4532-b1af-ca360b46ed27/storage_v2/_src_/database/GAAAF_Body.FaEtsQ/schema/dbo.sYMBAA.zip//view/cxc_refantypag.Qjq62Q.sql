CREATE VIEW [dbo].[cxc_refantypag]
AS
SELECT 
rap_folio, rap_idempresa, rap_idsucursal, rap_iddepartamento, rap_idpersona, rap_cobrador, rap_moneda, rap_tipocambio, rap_referencia, rap_iddocto, rap_cotped, rap_consecutivo, rap_importe, rap_formapago, rap_numctabanc, rap_fecha, rap_idusuari, rap_idstatus, rap_banco, rap_referenciabancaria, rap_anno, RAP_AplicaPago, RAP_NumDeposito
FROM         [GA_Corporativa].dbo.cxc_refantypag
go

