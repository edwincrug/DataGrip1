create view 	[dbo].[CON_CARCON012007]	as select * from GAAAF_Concentra.dbo.CON_CARCON012007
go

