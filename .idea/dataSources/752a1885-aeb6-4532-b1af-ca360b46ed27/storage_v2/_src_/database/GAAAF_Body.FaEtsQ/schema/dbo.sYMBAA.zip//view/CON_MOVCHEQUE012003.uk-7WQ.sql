create view [dbo].[CON_MOVCHEQUE012003] as select * from GAAAF_Concentra.dbo.CON_MOVCHEQUE012003
go

