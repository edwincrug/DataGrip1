CREATE  Procedure VerificarVelocidadDeConversion
     @Inicio Datetime,
     @Fin Datetime
 As
     If Exists (Select * From dbo.SysObjects Where id = Object_Id('ProspectosConVelocidadMayorA180Dias') And ObjectProperty(id, N'IsUserTable') = 1) Begin
         Drop Table ProspectosConVelocidadMayorA180Dias
     End
     If Exists (Select * From dbo.SysObjects Where id = Object_Id('ProspectosConVelocidadMayorA180DiasSeguimientos') And ObjectProperty(id, N'IsUserTable') = 1) Begin
         Drop Table ProspectosConVelocidadMayorA180DiasSeguimientos
     End
     Select Distinct
         a.C_Clave As IdProspecto, a.[Fecha Primer contacto] As PrimerContacto, c.[Fecha de entrega] As Entrega, c.Id_registro As IdVenta,
         DateDiff(dd, a.[Fecha Primer contacto], c.[Fecha de entrega]) As Velocidad, c.[Fecha de entrega] As Fecha 
     Into
         ProspectosConVelocidadMayorA180Dias
     From
         Prospecto a, [Cotizaciones y pedidos] b, [Testimonio de Venta]  C 
     Where
         a.C_Clave = b.[Clave Prospecto] And  
         b.[Número de cotización] = c.[Número de cotización] And 
         c.[Fecha de entrega] Between @Inicio And @Fin And ( 
         DateDiff(dd, a.[Fecha Primer contacto], c.[Fecha de entrega]) > 180 Or 
         DateDiff(dd, a.[Fecha Primer contacto], c.[Fecha de entrega]) < 0) 
     Select
         b.IdProspecto, Min(FechaA) As FechaSeguimiento
     Into
         ProspectosConVelocidadMayorA180DiasSeguimientos
     From
         Seguimiento a, ProspectosConVelocidadMayorA180Dias b
     Where
         a.C_Prospecto = b.IdProspecto And
         a.FechaA Between DateAdd(dd, -180, Convert(datetime, b.Entrega, 101)) And Convert(datetime, b.Entrega, 101)
     Group By
         B.IdProspecto
     Print 'Actualizando fecha de seguimiento'
     Update
         ProspectosConVelocidadMayorA180Dias
     Set
         Fecha = B.FechaSeguimiento
     From
         ProspectosConVelocidadMayorA180Dias a, ProspectosConVelocidadMayorA180DiasSeguimientos b
     Where
         a.IdProspecto = B.IdProspecto
     Print 'Actualizando negativos'
     Update
         ProspectosConVelocidadMayorA180Dias
     Set
         Fecha = Entrega
     From
         ProspectosConVelocidadMayorA180Dias a
     Where
         DateDiff(dd, Fecha, Entrega) < 0
         Update
  [Testimonio de Venta] 
     Set
         DiasVenta = DateDiff(dd, a.[Fecha Primer contacto], c.[Fecha de entrega])
     From
         Prospecto a, [Cotizaciones y pedidos] b, [Testimonio de Venta] C
     Where
         a.C_Clave = b.[Clave Prospecto] And 
         b.[Número de cotización] = c.[Número de cotización] And  
  c.[Fecha de entrega] Between @Inicio And @Fin 
     Update
         [Testimonio de Venta] 
     Set
         DiasVenta = DateDiff(dd, Fecha, Entrega)
     From
         ProspectosConVelocidadMayorA180Dias a, [Testimonio de Venta]  b 
     Where
         a.IdVenta = B.Id_Registro
go

