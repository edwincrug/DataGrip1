create view [dbo].[PAR_UBICACION] as select * from GAAAF_Viga.dbo.PAR_UBICACION
go

