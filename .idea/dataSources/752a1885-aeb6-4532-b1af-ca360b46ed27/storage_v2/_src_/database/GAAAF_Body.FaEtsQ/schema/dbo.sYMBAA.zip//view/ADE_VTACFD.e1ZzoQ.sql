create view [dbo].[ADE_VTACFD] as select * from GAAAF_Concentra.dbo.ADE_VTACFD
go

