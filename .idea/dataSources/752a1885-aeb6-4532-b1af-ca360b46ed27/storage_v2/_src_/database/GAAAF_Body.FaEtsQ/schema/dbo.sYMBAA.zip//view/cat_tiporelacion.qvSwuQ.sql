CREATE VIEW [dbo].[cat_tiporelacion] AS Select * From GAAAF_Concentra.dbo.cat_tiporelacion
go

