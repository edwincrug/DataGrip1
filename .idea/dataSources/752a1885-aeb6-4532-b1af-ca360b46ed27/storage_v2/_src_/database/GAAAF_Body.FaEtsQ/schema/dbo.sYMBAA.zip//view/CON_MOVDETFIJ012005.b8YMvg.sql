create view 	[dbo].[CON_MOVDETFIJ012005]	 as select * from GAAAF_Concentra.dbo.CON_MOVDETFIJ012005
go

