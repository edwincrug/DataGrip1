CREATE VIEW [dbo].[dep_recepnotascreditodet]
AS
SELECT ncd_idrecepnotascreditodet, ncd_codigoparte, ncd_detalleparte, rnc_idrecepnotascredito, ncd_cantidad 
FROM PortalRefacciones.dbo.dep_recepnotascreditodet
go

