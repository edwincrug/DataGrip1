CREATE FUNCTION [dbo].[fnCantidadPartes]  ( @PEDIDO VARCHAR(30) ) RETURNS VarChar(300) AS BEGIN declare @nombre int SET @nombre = '' SELECT  TOP 1 @nombre =  sum(pmd_cantidad)   FROM  PAR_PEDMODE, PAR_partes WHERE PTS_IDPARTE=PMD_CODIGO and  PMD_NUMERO IN (@PEDIDO) and pmd_cantidad > 0 Return @nombre End
go

