create view 	[dbo].[CON_CARCON012005]	as select * from GAAAF_Concentra.dbo.CON_CARCON012005
go

