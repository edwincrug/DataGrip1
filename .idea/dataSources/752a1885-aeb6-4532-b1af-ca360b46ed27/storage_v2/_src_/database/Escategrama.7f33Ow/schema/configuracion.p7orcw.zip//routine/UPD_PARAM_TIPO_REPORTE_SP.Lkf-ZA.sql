-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 30-10-2020
-- Description: Actualiza el valor de parametros de la tabla [configuracion].[Parametrizacion]
-- EXEC [configuracion].[UPD_PARAM_TIPO_REPORTE_SP] 6,12,7,31,30, ''
-- =============================================

CREATE PROCEDURE [configuracion].[UPD_PARAM_TIPO_REPORTE_SP]
	@idParamTipoReporte int,
	@idTipoReporte		int,
	@descrpcion         varchar(200),
	@anioAnterior       int,
	@mesInicial         int,
	@idCompania			int,	
	@idUsuario			int,
	@err				varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY

		IF ( @idParamTipoReporte > 0)
		BEGIN
			UPDATE [Escategrama].[configuracion].[ParamTipoReporte]
			SET descripcion = @descrpcion,
				anioAnterior = @anioAnterior,
				mesInicial = @mesInicial
			WHERE idParamTipoReporte = @idParamTipoReporte

			IF(@idTipoReporte IN (2,3,4))
			BEGIN 
				UPDATE [Escategrama].[configuracion].[Parametrizacion]
				SET titulo = @descrpcion
				WHERE idCompania = @idCompania
				AND idTipoParametro = CASE WHEN @idTipoReporte = 2 THEN 15
										   WHEN @idTipoReporte = 3 THEN 16
										   WHEN @idTipoReporte = 4 THEN 17
										END
				END
			END

		ELSE
		BEGIN
		
			IF(@idTipoReporte IN (2,3,4))
			BEGIN 
				INSERT INTO [Escategrama].[configuracion].[Parametrizacion]
				SELECT CASE WHEN @idTipoReporte = 2 THEN 15
				WHEN @idTipoReporte = 3 THEN 16
				WHEN @idTipoReporte = 4 THEN 17
				END,0,@idCompania,@idUsuario,GETDATE(),NULL,@descrpcion	
			END
					
			INSERT INTO [Escategrama].[configuracion].[ParamTipoReporte]
			SELECT @idTipoReporte ,@anioAnterior, @mesInicial, @idCompania, @descrpcion,GETDATE(),NULL,@idUsuario 

		END

	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

