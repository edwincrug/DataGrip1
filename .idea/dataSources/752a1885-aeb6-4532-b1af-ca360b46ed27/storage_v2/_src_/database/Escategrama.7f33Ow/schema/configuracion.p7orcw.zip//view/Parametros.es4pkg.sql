

CREATE view [configuracion].[Parametros] as
(select TP.idTipoParametro, TP.idOrden, TP.parametro, TP.esActivo, TP.[origen], PR.idParametrizacion,
 PR.valor, PR.idCompania, PR.idUsuario  from [catalogo].[TipoParametro] TP
  left join [configuracion].[Parametrizacion] PR
ON TP.idTipoParametro = PR.idTipoParametro where TP.esActivo = 1 and TP.origen = 2)
go

