-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 30-10-2020
-- Description: Actualiza el valor de parametros de la tabla [configuracion].[Parametrizacion]
-- EXEC [configuracion].[UPD_PARAMETROS_SP] 6,12,7,31,30, ''
-- =============================================

CREATE PROCEDURE [configuracion].[UPD_PARAMETROS_SP]
	@idParametizacion int,
	@idTipoParametro int,
	@valor          float,
	@idCompania     int,
	@titulo          varchar(200),
	@idUsuario		int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		IF ( @idParametizacion > 0)
		begin
			UPDATE [configuracion].[Parametrizacion]
			SET valor = @valor, [fechaModificacion] = GETDATE(),titulo = @titulo
			WHERE [idParametrizacion] = @idParametizacion AND [idCompania] = @idCompania;
			SELECT @idParametizacion
			end
		ELSE
		begin
			INSERT INTO [configuracion].[Parametrizacion]
			(idTipoParametro,
			 valor,
			 idCompania,
			 idUsuario,
			 fecha,
			 [fechaModificacion],
			 titulo)
			values(@idTipoParametro,
				   @valor,
				   @idCompania,
				   @idUsuario,
				   GETDATE(),
				   GETDATE(),
				   @titulo)
			SELECT SCOPE_IDENTITY() idParametrizacion
			end
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

