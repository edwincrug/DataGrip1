-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 26-10-2020
-- Description: Recupera el nombre de las columnas para el grid de historicos
-- EXEC [catalogo].[SEL_COLUMNA_GRID_SP] 11, 2,2, 0,1, ''
-- =============================================

CREATE PROCEDURE [catalogo].[SEL_COLUMNA_GRID_SP]
	@mes		int,
	@idTipoReporte int,
	@idCompania		int,
	@idFoto		int,
	@idUsuario				int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY	
		Set Language spanish
		DECLARE @meses INT, @aplicaAnterior INT = 0
		DECLARE @mesTable AS TABLE ([titulo] VARCHAR(200),[mes] VARCHAR(50),[tipoCampo] VARCHAR(50),[fixed] bit,[allowupdate] bit,[clase] VARCHAR(50),summaryType VARCHAR(50),valueFormat VARCHAR(50))
		DECLARE @periodos AS TABLE ([inicio] VARCHAR(50), [fin] VARCHAR(50))

		IF(@idTipoReporte < 5)
		BEGIN

		IF(@idFoto > 0)
		BEGIN
			SELECT @meses = A.[mesInicial] + 1, @aplicaAnterior = A.[anioAnterior]
			--FROM [catalogo].[TipoReporte] 
			--WHERE idTipoReporte = @idTipoReporte
			FROM [Escategrama].[reporte].[FotoParamTipoReporte] A
			--LEFT JOIN [Escategrama].[configuracion].[ParamTipoReporte] B
			--ON A.idTipoReporte = B.idTipoReporte AND B.idCompania = @idCompania
			WHERE idFoto = @idFoto
			AND A.idTipoReporte = @idTipoReporte

		END
		ELSE
		BEGIN

			SELECT @meses = coalesce(B.[mesInicial],A.[mesInicial]) + 1, @aplicaAnterior = coalesce(B.[anioAnterior],A.[anioAnterior]) 
			--FROM [catalogo].[TipoReporte] 
			--WHERE idTipoReporte = @idTipoReporte
			FROM [catalogo].[TipoReporte] A
			LEFT JOIN [Escategrama].[configuracion].[ParamTipoReporte] B
			ON A.idTipoReporte = B.idTipoReporte AND B.idCompania = @idCompania
			WHERE [esActivo] = 1
			AND A.idTipoReporte = @idTipoReporte
		END
			IF(@aplicaAnterior = 1)
			BEGIN
				SET @meses = 12 + @mes
			END
			DECLARE @totalMeses int = @meses -1
			WHILE (@meses > 1)
			BEGIN
				SET @meses = @meses-1
				INSERT INTO @mesTable (titulo,mes,tipoCampo,fixed,allowupdate,clase)
				SELECT SUBSTRING(DATENAME(MONTH,DATEADD(MM,-@meses,GETDATE())),1,3) + '/' + SUBSTRING(CAST(DATEPART(YEAR,DATEADD(MM,-@meses,GETDATE())) AS CHAR(4)),3,2),SUBSTRING(DATENAME(MONTH,DATEADD(MM,-@meses,GETDATE())),1,3) + '/' + SUBSTRING(CAST(DATEPART(YEAR,DATEADD(MM,-@meses,GETDATE())) AS CHAR(4)),3,2),'number',0,0,''
				IF @meses = @totalMeses
					begin
						INSERT INTO @periodos (inicio) 
						select DATENAME(MONTH,DATEADD(MM,-@meses,GETDATE())) + ' ' +  CAST(DATEPART(YEAR,DATEADD(MM,-@meses,GETDATE())) AS CHAR(4))
					end
				IF @meses = 1 
					begin
						Update @periodos set fin = 
						DATENAME(MONTH,DATEADD(MM,-@meses,GETDATE())) + ' ' +  CAST(DATEPART(YEAR,DATEADD(MM,-@meses,GETDATE())) AS CHAR(4))
					end
			END
		END
		IF(@idFoto > 0)
		BEGIN
			INSERT INTO @mesTable
			SELECT  
					[titulo]
					,[parametro]
					,[tipoCampo]
					,[fixed]
					,[allowupdate]
					,[clase]
					,'' AS summaryType,'' AS valueFormat
			FROM [Escategrama].[reporte].[FotoColumna]
			WHERE [idFoto] = @idFoto AND idTipoReporte = @idTipoReporte
			order by idOrden
		END
		ELSE
		BEGIN
			
			------------------------------------------------------
			------------------------------------------------------
			-- SE AGREGO COMO PROPUESTA DVR VALIDAR
			INSERT INTO @mesTable
			SELECT	coalesce(n.titulo,A.titulo) AS titulo,
			A.[parametro],A.tipoCampo,A.fixed,A.allowupdate,A.clase,A.summaryType,A.valueFormat
			FROM [catalogo].[TipoParametro] A
			INNER JOIN [Escategrama].[relacion].[TipoReporteParametro] B ON A.idTipoParametro = B.idTipoParametro
			left join [configuracion].[Parametrizacion] n on B.idTipoParametro = n.idTipoParametro and n.idCompania = @idCompania
			WHERE B.idTipoReporte = @idTipoReporte AND b.esActivo = 1		
			AND A.idOrden > 0 AND A.idTipoParametro NOT IN (30,31)
			order by A.idOrden
			------------------------------------------------------
			------------------------------------------------------

		END
		
		-- EXEC [catalogo].[SEL_COLUMNA_GRID_SP] 11, 2,2, 0,1, ''
		SELECT	 A.titulo,A.[parametro],A.tipoCampo,A.fixed,A.allowupdate,A.clase,A.summaryType,A.valueFormat  
		FROM [catalogo].[TipoParametro] A
		INNER JOIN [Escategrama].[relacion].[TipoReporteParametro] B ON A.idTipoParametro = B.idTipoParametro
		WHERE B.idTipoReporte = @idTipoReporte AND b.esActivo = 1
		AND A.idOrden = 0
		UNION ALL
		SELECT	 A.titulo,A.[parametro],A.tipoCampo,A.fixed,A.allowupdate,A.clase,A.summaryType,A.valueFormat  
		FROM [catalogo].[TipoParametro] A
		INNER JOIN [Escategrama].[relacion].[TipoReporteParametro] B ON A.idTipoParametro = B.idTipoParametro
		WHERE B.idTipoReporte = @idTipoReporte AND b.esActivo = 1
		AND A.idTipoParametro IN (30,31)
		UNION ALL
		SELECT titulo,[mes] AS parametro,tipoCampo,fixed,
		(CASE WHEN @idTipoReporte = 6 THEN allowupdate ELSE 0 END) AS allowupdate,	
		clase
		, summaryType,valueFormat
		FROM @mesTable
		IF(@idTipoReporte < 5)
		BEGIN
			SELECT [inicio] + ' al mes de ' + [fin] AS periodos FROM @periodos 
		END
		ELSE
		BEGIN
			SELECT DATENAME(MONTH,GETDATE()) +' ' + DATENAME(YEAR,GETDATE()) AS periodos
		END
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

