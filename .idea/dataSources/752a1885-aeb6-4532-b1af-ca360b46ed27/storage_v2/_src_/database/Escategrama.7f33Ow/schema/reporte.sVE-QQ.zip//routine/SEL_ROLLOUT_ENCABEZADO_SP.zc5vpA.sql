-- =============================================
-- Author:		DVT
-- Create date: 18/11/2020
-- Description:	Obtiene el listado de rollout por compañia y sucursal
-- TEST: reporte.SEL_ROLLOUT_ENCABEZADO_SP 2,4,30,''
-- =============================================
CREATE PROCEDURE reporte.SEL_ROLLOUT_ENCABEZADO_SP
	@idCompania				int,
	@idSucursal				int,
	@idUsuario				int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY	
	
	SELECT 
			idFoto,
			idCompania,
			idSucursal,
			CONVERT(varchar,FechaCreacion,100) AS FechaCreacion
	FROM [Escategrama].[reporte].[Foto]
	WHERE idCompania = @idCompania 
	AND idSucursal = @idSucursal
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

