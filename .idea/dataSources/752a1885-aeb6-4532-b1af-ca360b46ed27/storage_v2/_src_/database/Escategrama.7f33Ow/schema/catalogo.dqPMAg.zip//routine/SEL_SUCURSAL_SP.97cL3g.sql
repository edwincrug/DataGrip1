-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 26-10-2020
-- Description: Recupera el catalogo de compania de la vista catalogo.Sucursal de acuerdo al usuario proporcionado
-- EXEC [catalogo].[SEL_SUCURSAL_SP] 31,30,''
-- =============================================

CREATE PROCEDURE [catalogo].[SEL_SUCURSAL_SP]
	@idCompania int,
	@idUsuario		int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		SELECT	 [idUsuario]
			,[idCompania]
			,[idSucursal]
			,[razonCompania]
			,[nombreComercialCompania]
			,[sucursal]
			,[nombreComercialSucursal]
		FROM catalogo.Sucursal 
		WHERE idCompania = @idCompania
		AND [idUsuario] = @idUsuario and [esActivo] = 1

		
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

