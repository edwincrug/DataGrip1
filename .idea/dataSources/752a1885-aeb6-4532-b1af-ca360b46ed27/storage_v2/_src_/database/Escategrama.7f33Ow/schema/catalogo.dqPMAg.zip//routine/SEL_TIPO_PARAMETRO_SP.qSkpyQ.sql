-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 26-10-2020
-- Description: Recupera los parametros para cabecero de reporte de la tabla catalogo.TipoParametro
-- EXEC [catalogo].[SEL_TIPO_PARAMETRO_SP]
-- =============================================

CREATE PROCEDURE [catalogo].[SEL_TIPO_PARAMETRO_SP]
	@idUsuario		int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		SELECT	 [idOrden]
			,[parametro] 
		FROM [catalogo].[TipoParametro] 
		--WHERE [periodoMes] < @mes
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

