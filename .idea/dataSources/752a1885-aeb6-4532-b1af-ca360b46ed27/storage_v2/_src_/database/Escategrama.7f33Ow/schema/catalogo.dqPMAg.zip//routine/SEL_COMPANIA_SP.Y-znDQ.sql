-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 26-10-2020
-- Description: Recupera el catalogo de COMPANIA de la vista catalogo.Compania de acuerdo al usuario proporcionado
-- EXEC [catalogo].[SEL_COMPANIA_SP] 30
-- =============================================

CREATE PROCEDURE [catalogo].[SEL_COMPANIA_SP]
	@idUsuario		int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		SELECT	 [idUsuario]
			,[idCompania]
			,[razonSocial]
			,[nombreComercial]
		FROM catalogo.Compania 
		WHERE [idUsuario] = @idUsuario and [esActivo] = 1
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

