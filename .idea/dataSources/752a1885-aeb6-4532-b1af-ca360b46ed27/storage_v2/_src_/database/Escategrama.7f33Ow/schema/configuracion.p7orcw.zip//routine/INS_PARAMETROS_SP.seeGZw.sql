-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 30-10-2020
-- Description: Inserta la configuracion de Parametros en la tabla [catalogo].[TipoParametro]
-- EXEC [configuracion].[INS_PARAMETROS_SP] 6,3.5,31,30, ''
-- =============================================

CREATE PROCEDURE [configuracion].[INS_PARAMETROS_SP]
	@idParametro    tinyint,
	@valor          decimal(18,2),
	@idCompania     int,
	@idUsuario		int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		INSERT INTO [configuracion].[Parametrizacion]
		(idParametrizacion,
		 valor,
		 idCompania,
		 idUsuario,
		 fecha)
		values(@idParametro,
			   @valor,
			   @idCompania,
			   @idUsuario,
			   GETDATE())
		SELECT SCOPE_IDENTITY() idParametrizacion
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

