-- =============================================
-- Author: DVR	
-- Create date: 17-11-2020
-- Description: Inserta el ROLL-OUT configurado en base al historico del mes y año deseado

/*
TRUNCATE TABLE [Escategrama].[reporte].[Foto]
TRUNCATE TABLE [Escategrama].[reporte].[FotoDetalle]
TRUNCATE TABLE [Escategrama].[reporte].[RollOut]
TRUNCATE TABLE [Escategrama].[reporte].[FotoParametro]
TRUNCATE TABLE [Escategrama].[reporte].[FotoParamTipoReporte]

EXEC [reporte].[INS_ROLL_OUT_SP_DVR] 
	2,
	4,
	11,
	2020,
	'<propiedades>
		<propiedad>
			<unidadDescripcion>VW</unidadDescripcion>
			<inventario>1</inventario>
			<pedidoMes>2</pedidoMes>
			<ventasPronostico>3</ventasPronostico>
			<inventarioTeorico>5</inventarioTeorico>
		</propiedad>
		<propiedad>
			<unidadDescripcion>NISSAN</unidadDescripcion>
			<inventario>4</inventario>
			<pedidoMes>1</pedidoMes>
			<ventasPronostico>22</ventasPronostico>
			<inventarioTeorico>8</inventarioTeorico>
		</propiedad>
		<propiedad>
			<unidadDescripcion>CHEVROLET</unidadDescripcion>
			<inventario>7</inventario>
			<pedidoMes>80</pedidoMes>
			<ventasPronostico>4</ventasPronostico>
			<inventarioTeorico>6</inventarioTeorico>
		</propiedad>
	 </propiedades>',
	 '0',
	31,
	''
*/
-- =============================================
CREATE PROCEDURE [reporte].[INS_ROLL_OUT_SP]
	@idCompania     INT,
	@idSucursal     INT,
	@mes     INT,
	@periodoYear    INT,
	@rollOut		XML,
	@idFoto			INT,
	@idUsuario		INT,
	@err			VARCHAR(MAX) = '' OUTPUT
AS
BEGIN
BEGIN TRY


	Set Language spanish

	IF NOT EXISTS (SELECT idFoto FROM [Escategrama].[reporte].[Foto] WHERE idFoto = @idFoto)
	BEGIN
	DECLARE @foto INT = 0
	SELECT @foto = idFoto FROM [Escategrama].[reporte].[Foto] 
				WHERE idCompania = @idCompania
				AND idSucursal = @idSucursal
				AND periodoMes = @mes
				AND periodoYear = @periodoYear

	IF (@foto > 0)
	BEGIN
		DELETE FROM [Escategrama].[reporte].[Foto] WHERE idFoto = @foto
		DELETE FROM [Escategrama].[reporte].[FotoDetalle] WHERE idFoto = @foto
		DELETE FROM [Escategrama].[reporte].[RollOut] WHERE idFoto = @foto
		DELETE FROM [Escategrama].[reporte].[FotoParametro] WHERE idFoto = @foto
		DELETE FROM [Escategrama].[reporte].[FotoParamTipoReporte] WHERE idFoto = @foto
		
	END
		DECLARE @unidadDescripcionTable AS TABLE ([idCompania] INT, [descripcion] VARCHAR(200))
		DECLARE @queryDynamic VARCHAR(MAX),
		@meses INT,
		@aplicaAnterior INT = 0,
		@redondeo_probabilidad BIT,
		@redondeo_porcentaje BIT
		DECLARE @periodoMes INT = 0
		DECLARE @columnaPivot2 VARCHAR(500) = ''

 
		SELECT @periodoMes = mesInicial,  @meses = mesInicial + 1, @aplicaAnterior = anioAnterior
		FROM [catalogo].[TipoReporte] WHERE idTipoReporte = 1 -- REPORTE HISTORICO

		IF(@aplicaAnterior = 1)
		BEGIN
			SET @meses = 12 + @mes
			SET @periodoMes = @meses
		END

		INSERT INTO @unidadDescripcionTable (idCompania,descripcion)
		SELECT DISTINCT idCompania, unidadDescripcion
		FROM [192.168.20.31].FinanzasSite.Unidad.Venta
		WHERE idCompania = @idCompania AND idSucursal = @idSucursal AND idOrigenPlanta IN (1,5) AND idautolinea != 2
		AND facturaFecha BETWEEN DATEADD(MONTH, -@periodoMes, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)) AND  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), -1)


		

		INSERT INTO [Escategrama].[reporte].[FotoDetalle]		
		SELECT COALESCE(V.unidadDescripcion, UD.descripcion),
		MP.periodoMes, MP.periodoYear
		--, 'AZUL' AS color
		--	,SUBSTRING(DATENAME(MONTH,'01/' + RIGHT('00' + CAST(MP.[periodoMes] AS VARCHAR(2)), 2 ) + '/' + CAST(MP.periodoYear AS VARCHAR(4))),1,3) + '/' + SUBSTRING(CAST(MP.periodoYear AS VARCHAR(4)),3,2) mes
			, SUM(COALESCE(Cantidad, 0)) AS total
			,1,GETDATE()
		FROM [catalogo].[MesesProcesar] MP
		INNER JOIN @unidadDescripcionTable UD ON UD.idCompania = @idCompania
		LEFT JOIN [192.168.20.31].FinanzasSite.Unidad.Venta V ON MP.periodomes = V.[periodoMes] 
			AND V.idCompania = @idCompania
			and idSucursal = @idSucursal
			AND V.periodoYear = MP.periodoYear AND V.periodoMes = MP.periodoMes
			AND UD.descripcion = V.unidadDescripcion		
			AND idOrigenPlanta IN (1,5) 
		where UD.descripcion != ''
		AND CAST(('01/' + CAST(RIGHT('00' + CAST(MP.[periodoMes] AS VARCHAR(2)), 2 ) AS CHAR(2)) + '/' + CAST(mp.periodoYear AS CHAR(4))) AS DATE) between DATEADD(MONTH, -@periodoMes, DATEADD(MONTH, DATEDIFF(MONTH, 0, '30/11/2020'), 0)) and  DATEADD(MONTH, DATEDIFF(MONTH, 0, '30/11/2020'), -1)
		group by unidadDescripcion,MP.periodoMes, MP.periodoYear,UD.descripcion


	END
	ELSE
	BEGIN
	PRINT(2)

			DELETE FROM [Escategrama].[reporte].[RollOut] WHERE idFoto = @idFoto

			INSERT INTO [Escategrama].[reporte].[RollOut]
			SELECT
			ParamValues.col.value('unidadDescripcion[1]','nvarchar(250)'),
			ParamValues.col.value('inventario[1]','int'),
			ParamValues.col.value('existenciasPorLlegar[1]','int'),
			ParamValues.col.value('pedidoMes[1]','int'),
			ParamValues.col.value('ventasPronostico[1]','decimal(18,2)'),
			ParamValues.col.value('inventarioTeorico[1]','decimal(18,2)'),
			@idFoto
			FROM @rollOut.nodes('propiedades/propiedad') AS ParamValues(col)


			SELECT 1 AS exito,'Se actualizo el roll out con éxito' AS mensaje;

	END

		

	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err,0 AS exito;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

