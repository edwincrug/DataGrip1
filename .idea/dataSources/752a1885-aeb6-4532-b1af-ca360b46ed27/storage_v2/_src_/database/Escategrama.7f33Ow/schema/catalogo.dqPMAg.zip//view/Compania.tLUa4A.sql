
CREATE view [catalogo].[Compania] as
( select UC.idUsuario, UC.idCompania, UC.esActivo, US.userName, US.primerNombre, US.primerApellido,
US.email, CM.razonSocial, CM.nombreComercial
from [Escategrama].[relacion].[UsuarioCompania] UC 
inner join [Seguridad].[catalogo].[Usuario] US on UC.idUsuario = US.id
inner join [192.168.20.31].[FinanzasSite].Catalogo.Compania CM on UC.idCompania = CM.id)
go

