
CREATE view [catalogo].[Sucursal] as
(select USUC.idUsuario, USUC.idCompania, USUC.idSucursal, USUC.esActivo, US.userName, US.primerNombre, US.primerApellido,
US.email, CM.razonSocial as razonCompania, CM.nombreComercial as nombreComercialCompania, SUC.razonSocial as sucursal, SUC.nombreComercial as nombreComercialSucursal
from [Escategrama].[relacion].[UsuarioSucursal] USUC 
inner join [Seguridad].[catalogo].[Usuario] US on USUC.idUsuario = US.id
inner join [192.168.20.31].[FinanzasSite].Catalogo.Compania CM on USUC.idCompania = CM.id
inner join [192.168.20.31].FinanzasSite.Catalogo.Sucursal SUC on USUC.idSucursal = SUC.id)
go

