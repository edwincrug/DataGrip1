
CREATE FUNCTION [configuracion].[SEL_PARAMETRO_ROLLOUT_FN](
    @idFoto INT,
	@idTipoParametro INT
   
)
RETURNS DECIMAL(18,2)
AS 
BEGIN
	
    RETURN (SELECT [valor] FROM [Escategrama].[reporte].[FotoParametro]
			WHERE [idFoto] = @idFoto AND [idTipoParametro] = @idTipoParametro)
END;
go

