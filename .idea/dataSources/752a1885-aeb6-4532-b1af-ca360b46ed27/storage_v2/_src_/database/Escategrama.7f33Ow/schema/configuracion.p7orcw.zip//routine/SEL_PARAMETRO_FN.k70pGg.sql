CREATE FUNCTION configuracion.SEL_PARAMETRO_FN(
    @idCompania INT,
	@idTipoParametro INT
   
)
RETURNS DECIMAL(18,2)
AS 
BEGIN
	
    RETURN (SELECT [valor] FROM [Escategrama].[configuracion].[Parametrizacion]
			WHERE [idCompania] = @idCompania AND [idTipoParametro] = @idTipoParametro)
END;
go

