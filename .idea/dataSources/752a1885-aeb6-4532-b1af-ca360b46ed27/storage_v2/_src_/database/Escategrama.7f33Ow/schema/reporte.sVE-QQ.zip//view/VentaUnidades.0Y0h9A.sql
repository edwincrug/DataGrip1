



CREATE view [reporte].[VentaUnidades] as
( select idCompania, idSucursal, unidadDescripcion,M.abreviatura+'/' + CONVERT(NVARCHAR(20),YEAR(facturaFecha)) as fecha,VA.periodoMes, Cantidad
 from [192.168.20.31].[FinanzasSite].[Unidad].[Venta] VA
 inner join catalogo.Mes M on MONTH(VA.facturaFecha) = M.periodoMes where idOrigen = 1)
go

