-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 27-10-2020
-- Description: Recupera las unidades de la tabla [192.168.20.31].[FinanzasSite].[Unidad].[Venta]
-- EXEC [reporte].[SEL_UNIDADES_SP_DSV_DVR] 11,2,2,4, 0,30, ''
-- =============================================

CREATE PROCEDURE [reporte].[SEL_UNIDADES_SP_DSV_DVR]
	@mes		    int,
	@idTipoReporte  int,
	@idCompania       int,
	@idSucursal       int,
	@idFoto       int,
	@idUsuario	    int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		Set Language spanish		
	--Remover if
	IF(@idTipoReporte <> 5 AND @idTipoReporte <> 6)
	BEGIN

		DECLARE @queryDynamic VARCHAR(MAX),
		@meses INT,
		@aplicaAnterior INT = 0,
		@redondeo_probabilidad BIT,
		@redondeo_porcentaje BIT
		DECLARE @periodoMes INT = 0
		DECLARE @columnaPivot2 VARCHAR(500) = ''

		SELECT @periodoMes = coalesce(B.[mesInicial],A.[mesInicial]),  @meses = coalesce(B.[mesInicial],A.[mesInicial]) + 1, @aplicaAnterior = coalesce(B.[anioAnterior],A.[anioAnterior]),@redondeo_probabilidad = redondeo_probabilidad,@redondeo_porcentaje= redondeo_porcentaje
		FROM [catalogo].[TipoReporte] A
		LEFT JOIN [Escategrama].[configuracion].[ParamTipoReporte] B
		ON A.idTipoReporte = B.idTipoReporte AND B.idCompania = @idCompania
		WHERE [esActivo] = 1
		AND A.idTipoReporte = @idTipoReporte

		 
		 SELECT @meses,@periodoMes,@mes
		IF(@aplicaAnterior = 1)
		BEGIN
			SET @meses = 12 + @mes
			SET @periodoMes = @meses
		END
		
		 --	EXEC [reporte].[SEL_UNIDADES_SP_DSV_DVR] 11,1,2,4, 0,30, ''
		SELECT @meses,@periodoMes,@mes

		WHILE (@meses > 1)
		BEGIN
			SET @meses = @meses-1
			IF(LEN(@columnaPivot2) > 0)
			BEGIN
				SET @columnaPivot2 = @columnaPivot2 + ','
			END
			SET @columnaPivot2 = @columnaPivot2 + (SELECT '[' + SUBSTRING(DATENAME(MONTH,DATEADD(MM,-@meses,GETDATE())),1,3) + '/' + SUBSTRING(CAST(DATEPART(YEAR,DATEADD(MM,-@meses,GETDATE())) AS CHAR(4)),3,2) + ']')
		END
		--SET @columnaPivot2 = @columnaPivot2 + ',[TotalMeses]'
		--SELECT	@columnaPivot2 = @columnaPivot2 + ',[' + [parametro] + ']' FROM [catalogo].[TipoParametro] WHERE esActivo = 1
		SELECT	 @columnaPivot2 = @columnaPivot2 + ',[' + A.[parametro] + ']' FROM [catalogo].[TipoParametro] A
		INNER JOIN [Escategrama].[relacion].[TipoReporteParametro] B ON A.idTipoParametro = B.idTipoParametro
		WHERE B.idTipoReporte = @idTipoReporte AND b.esActivo = 1
		AND A.idOrden > 0
		--PRINT @columnaPivot2

		

		TRUNCATE TABLE [reporte].[PeriodoMensual]
		INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		select COALESCE(V.unidadDescripcion, UD.descripcion), 'AZUL' AS color
			,SUBSTRING(DATENAME(MONTH,'01/' + RIGHT('00' + CAST(MP.[periodoMes] AS VARCHAR(2)), 2 ) + '/' + CAST(MP.periodoYear AS VARCHAR(4))),1,3) + '/' + SUBSTRING(CAST(MP.periodoYear AS VARCHAR(4)),3,2) mes
			, SUM(COALESCE(Cantidad, 0)) AS total
		FROM [catalogo].[MesesProcesar] MP
		INNER JOIN [reporte].[UnidadDescripcion] UD ON UD.idCompania = @idCompania
		LEFT JOIN [192.168.20.31].FinanzasSite.Unidad.Venta V ON MP.periodomes = V.[periodoMes] 
			AND V.idCompania = @idCompania
			and idSucursal = @idSucursal
			AND V.periodoYear = MP.periodoYear AND V.periodoMes = MP.periodoMes
			AND UD.descripcion = V.unidadDescripcion		
			AND idOrigenPlanta IN (1,5) 
		where UD.descripcion != ''
		AND MP.periodoYear = 2020 AND MP.periodoMes IN (10,9,8,7,6,5)
		--AND CAST(('01/' + CAST(RIGHT('00' + CAST(MP.[periodoMes] AS VARCHAR(2)), 2 ) AS CHAR(2)) + '/' + CAST(mp.periodoYear AS CHAR(4))) AS DATE) between DATEADD(MONTH, -@periodoMes, DATEADD(MONTH, DATEDIFF(MONTH, 0, '30/11/2020'), 0)) and  DATEADD(MONTH, DATEDIFF(MONTH, 0, '30/11/2020'), -1)
		group by unidadDescripcion,MP.periodoMes, MP.periodoYear,UD.descripcion




		INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		SELECT unidadDescripcion, color, 'TotalMes' AS [TotalMeses], SUM(total) AS total FROM [reporte].[PeriodoMensual]
		GROUP BY unidadDescripcion, color
	
		INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		SELECT unidadDescripcion, color, 'Promedio' AS [Promedio], 
		CASE WHEN @redondeo_probabilidad = 1 THEN ROUND(total/@periodoMes,0) ELSE total/@periodoMes END AS total
		FROM [reporte].[PeriodoMensual] WHERE mes = 'TotalMes'


		INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		SELECT unidadDescripcion, color, 'DesvStd' AS [DesvStd], 
		--CASE WHEN @redondeo_probabilidad = 1 THEN ROUND(STDEVP([total]),0) ELSE STDEVP([total]) END AS total
		STDEV(coalesce([total],0)) AS total
		FROM [reporte].[PeriodoMensual] where mes not in ('TotalMes' , 'Promedio')
		GROUP BY unidadDescripcion, color
		


		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT unidadDescripcion, color, 'D(dda)' AS [D(dda)],
		--CASE WHEN @redondeo_probabilidad = 1 THEN ROUND(total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,4)),0) ELSE total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,4)) END AS total
		----total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,4)) AS total
		--FROM [reporte].[PeriodoMensual] WHERE mes = 'DesvStd'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, 'I/Viariabilidad' AS [I/Viariabilidad], 
		
		--CASE WHEN P1.total > 0 THEN 
		--CASE WHEN @redondeo_probabilidad = 1 THEN ROUND(P2.total/P1.total,0) ELSE P2.total/P1.total END -- AS total
		----P2.total/P1.total 
		--ELSE 0 END AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, '100%' AS [100%],
		--CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total* (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,6))),0) ELSE P1.total + (P2.total* (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,6))) END AS total
		----P1.total + (P2.total* (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,6))) AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, '99%' AS [99%], 
		--CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,7))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,7))) END AS total
		----P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,7))) AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, '98%' AS [98%], 
		--CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,8))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,8))) END AS total
		----P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,8))) AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, '97%' AS [97%],
		--CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,9))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,9))) END AS total
		----P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,9))) AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, '90%' AS [90%],
		--CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,10))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,10))) END AS total
		----P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,10))) AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, '84%' AS [84%],
		--CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + P2.total,0) ELSE P1.total + P2.total END AS total
		----P1.total + P2.total AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, '67%' AS [67%],
		--CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,12))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,12))) END  AS total
		----P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,12))) AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT unidadDescripcion, color, '50%' AS [50%],
		--CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(total,0) ELSE total END AS total 
		----total AS total 
		--FROM [reporte].[PeriodoMensual] WHERE mes = 'Promedio'
		
		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion
		--, 'AZUL' AS color
		--,'Inventario' AS [Inventario] 
		--, COUNT(P1.unidadDescripcion) AS total
		--FROM [192.168.20.31].[FinanzasSite].Unidad.InventarioUnidad P1
		--WHERE P1.idCompania = @idCompania AND P1.periodoYear = CAST(DATEPART(YEAR,DATEADD(MM,-1,GETDATE())) AS CHAR(4)) AND P1.periodoMes = CAST(DATEPART(MONTH,DATEADD(MM,-1,GETDATE())) AS CHAR(4)) AND P1.idSucursal = @idSucursal AND P1.idOrigen = 1	
		--AND idOrigen = 1
		--GROUP BY P1.unidadDescripcion

		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT unidadDescripcion, color, 'ExistenciasPorLlegar' AS [ExistenciasPorLlegar], 0 AS total FROM [reporte].[PeriodoMensual]
		--GROUP BY unidadDescripcion, color

		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, 'TotalExistencias' AS [TotalExistencias], P1.total + P2.total AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
		--WHERE P1.mes = 'Inventario' AND P2.mes = 'ExistenciasPorLlegar'


		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, 'Pronostico' AS [Pronostico],
		--CASE 
		--	WHEN P1.total <= 1.2 THEN ROUND( P2.TOTAL,0)
		--	WHEN P1.total <= 1.5 THEN ROUND( P3.TOTAL,0)
		--	WHEN P1.total <= 1.9 THEN ROUND( P4.TOTAL,0)
		--	WHEN P1.total <= 2.3 THEN ROUND( P5.TOTAL,0)
		--	WHEN P1.total <= 2.6 THEN ROUND( P6.TOTAL,0)
		--	WHEN P1.total <= 2.9 THEN ROUND( P7.TOTAL,0)
		--	WHEN P1.total <= 3.5 THEN ROUND( P8.TOTAL,0)
		--	ELSE 0
		--END
		--AS total
		--FROM [reporte].[PeriodoMensual] P1
		--INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color	AND P2.mes = '99%'
		--INNER JOIN [reporte].[PeriodoMensual] P3 ON P1.unidadDescripcion = P3.unidadDescripcion AND P1.color = P3.color	AND P3.mes = '98%'
		--INNER JOIN [reporte].[PeriodoMensual] P4 ON P1.unidadDescripcion = P4.unidadDescripcion AND P1.color = P4.color	AND P4.mes = '97%'
		--INNER JOIN [reporte].[PeriodoMensual] P5 ON P1.unidadDescripcion = P5.unidadDescripcion AND P1.color = P5.color	AND P5.mes = '90%'
		--INNER JOIN [reporte].[PeriodoMensual] P6 ON P1.unidadDescripcion = P6.unidadDescripcion AND P1.color = P6.color	AND P6.mes = '84%'
		--INNER JOIN [reporte].[PeriodoMensual] P7 ON P1.unidadDescripcion = P7.unidadDescripcion AND P1.color = P7.color	AND P7.mes = '67%'
		--INNER JOIN [reporte].[PeriodoMensual] P8 ON P1.unidadDescripcion = P8.unidadDescripcion AND P1.color = P8.color	AND P8.mes = '50%'
		--WHERE P1.mes = 'I/Viariabilidad'
		

		--INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
		--SELECT P1.unidadDescripcion, P1.color, 'PronosticoReporte' AS [PronosticoReporte],
		--ROUND(P1.total * (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,27)),0) AS total
		----P1.total * (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,27)) AS total
		--FROM [reporte].[PeriodoMensual] P1
		--WHERE P1.mes = 'Pronostico' 
		
		SET @queryDynamic = 'SELECT unidadDescripcion, color, ' + @columnaPivot2 + ' FROM (
		SELECT unidadDescripcion, color, mes, total
		FROM [reporte].[PeriodoMensual]) A
		pivot (avg(total) for mes in(' + @columnaPivot2 + ' )) AS Y'
		EXEC (@queryDynamic)

	END
	ELSE IF(@idTipoReporte = 5 OR @idTipoReporte = 6)
	BEGIN
		DECLARE @ventasIntercambio TABLE(
		id int identity(1,1),UnidadDescripcion nvarchar(200),color nvarchar(20), 
		TotalExistencias decimal (18,2),Meses2 decimal (18,2),Meses3 decimal (18,2),Meses4 decimal (18,2) )
		DECLARE @tabla_tipoReporte TABLE(id int identity(1,1),idTipoReporte int,descripcion nvarchar(50))
		DECLARE @aux INT = 1, @total INT = 0

		INSERT INTO @tabla_tipoReporte
		SELECT 
				  coalesce(B.[idTipoReporte],A.[idTipoReporte]) 
				, coalesce(B.[descripcion],A.[descripcion]) 			
		FROM [catalogo].[TipoReporte] A
		LEFT JOIN [Escategrama].[configuracion].[ParamTipoReporte] B
		ON A.idTipoReporte = B.idTipoReporte AND B.idCompania = @idCompania
		WHERE [esActivo] = 1 AND coalesce(B.[mesInicial],A.[mesInicial]) > 0
		
		
		--WHERE [esActivo] = 1 AND mesInicial > 0

		SET @total = (SELECT COUNT(id) FROM @tabla_tipoReporte)
		
		WHILE (@aux <= @total)
		BEGIN
		TRUNCATE TABLE [reporte].[PeriodoMensual]
			SET @queryDynamic = ''
			SET @meses = 0
			SET @aplicaAnterior = 0
			SET @periodoMes = 0
			SET @columnaPivot2  = ''

			DECLARE @id_TipoReporte INT = 0
			SELECT @id_TipoReporte = idTipoReporte FROM @tabla_tipoReporte WHERE id = @aux
	
				--SELECT @periodoMes = mesInicial,  @meses = mesInicial + 1, @aplicaAnterior = anioAnterior
				--FROM [catalogo].[TipoReporte] WHERE idTipoReporte = @id_TipoReporte
				
				SELECT @periodoMes = coalesce(B.[mesInicial],A.[mesInicial]),  @meses = coalesce(B.[mesInicial],A.[mesInicial]) + 1, @aplicaAnterior = coalesce(B.[anioAnterior],A.[anioAnterior]),@redondeo_probabilidad = redondeo_probabilidad,@redondeo_porcentaje= redondeo_porcentaje
				FROM [catalogo].[TipoReporte] A
				LEFT JOIN [Escategrama].[configuracion].[ParamTipoReporte] B
				ON A.idTipoReporte = B.idTipoReporte AND B.idCompania = @idCompania
				WHERE [esActivo] = 1
				AND A.idTipoReporte = @id_TipoReporte

				IF(@aplicaAnterior = 1)
				BEGIN
					SET @meses = 12 + @mes
					SET @periodoMes = @meses
				END
		
				WHILE (@meses > 1)
				BEGIN
					SET @meses = @meses-1
					IF(LEN(@columnaPivot2) > 0)
					BEGIN
						SET @columnaPivot2 = @columnaPivot2 + ','
					END
					SET @columnaPivot2 = @columnaPivot2 + (SELECT '[' + SUBSTRING(DATENAME(MONTH,DATEADD(MM,-@meses,GETDATE())),1,3) + '/' + SUBSTRING(CAST(DATEPART(YEAR,DATEADD(MM,-@meses,GETDATE())) AS CHAR(4)),3,2) + ']')
				END

				INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
				select unidadDescripcion, 'AZUL' AS color
				,SUBSTRING(DATENAME(MONTH,'01/' + RIGHT('00' + CAST([periodoMes] AS VARCHAR(2)), 2 ) + '/' + CAST(periodoYear AS VARCHAR(4))),1,3) + '/' + SUBSTRING(CAST(periodoYear AS VARCHAR(4)),3,2) mes
				, SUM(Cantidad) AS total
				FROM [192.168.20.31].FinanzasSite.Unidad.Venta
				where idCompania = @idCompania
				and idSucursal = @idSucursal
				and facturaFecha between DATEADD(MONTH, -@periodoMes, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)) and  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), -1)
				AND idOrigenPlanta IN (1,5)
				group by unidadDescripcion,periodoMes, periodoYear

				
				
				IF(@id_TipoReporte = 1)
				BEGIN
					SET @columnaPivot2 = '[Inventario],[ExistenciasPorLlegar],[TotalExistencias]'

					INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
					SELECT P1.unidadDescripcion
					, 'AZUL' AS color
					,'Inventario' AS [Inventario] 
					, COUNT(P1.unidadDescripcion) AS total
					FROM [192.168.20.31].[FinanzasSite].Unidad.InventarioUnidad P1
					WHERE P1.idCompania = @idCompania AND P1.periodoYear = CAST(DATEPART(YEAR,DATEADD(MM,-1,GETDATE())) AS CHAR(4)) AND P1.periodoMes = CAST(DATEPART(MONTH,DATEADD(MM,-1,GETDATE())) AS CHAR(4)) AND P1.idSucursal = @idSucursal AND P1.idOrigen = 1	
					AND idOrigen = 1
					GROUP BY P1.unidadDescripcion

					INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
					SELECT unidadDescripcion, color, 'ExistenciasPorLlegar' AS [ExistenciasPorLlegar], 0 AS total FROM [reporte].[PeriodoMensual]
					GROUP BY unidadDescripcion, color

					INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
					SELECT P1.unidadDescripcion, P1.color, 'TotalExistencias' AS [TotalExistencias], P1.total + P2.total AS total
					FROM [reporte].[PeriodoMensual] P1
					INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
					WHERE P1.mes = 'Inventario' AND P2.mes = 'ExistenciasPorLlegar'

					INSERT INTO @ventasIntercambio(UnidadDescripcion, color,TotalExistencias)
					SELECT unidadDescripcion, color, [TotalExistencias] FROM (
					SELECT unidadDescripcion, color, mes, total
					FROM [reporte].[PeriodoMensual]) A
					pivot (avg(total) for mes in([TotalExistencias] )) AS Y


						--select * from @ventasIntercambio
				END
				ELSE
				BEGIN
					--SET @columnaPivot2 = '[PronosticoReporte]'
				
						DECLARE @paso TABLE(UnidadDescripcion nvarchar(200),color nvarchar(20), PronosticoReporte decimal (18,2)) 
				
						SELECT	 @columnaPivot2 = @columnaPivot2 + ',[' + A.[parametro] + ']' FROM [catalogo].[TipoParametro] A
						INNER JOIN [Escategrama].[relacion].[TipoReporteParametro] B ON A.idTipoParametro = B.idTipoParametro
						WHERE B.idTipoReporte = @id_TipoReporte AND b.esActivo = 1
						AND A.idOrden > 0
						--PRINT @columnaPivot2
		
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT unidadDescripcion, color, 'TotalMes' AS [TotalMeses], SUM(total) AS total FROM [reporte].[PeriodoMensual]
						GROUP BY unidadDescripcion, color
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT unidadDescripcion, color, 'Promedio' AS [Promedio],
						CASE WHEN @redondeo_probabilidad = 1 THEN ROUND(total/@periodoMes,0) ELSE total/@periodoMes END AS total
						--total/@periodoMes AS total
						FROM [reporte].[PeriodoMensual] WHERE mes = 'TotalMes'


						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT unidadDescripcion, color, 'DesvStd' AS [DesvStd], 
						CASE WHEN @redondeo_probabilidad = 1 THEN ROUND(STDEVP([total]),0) ELSE STDEVP([total]) END AS total
						--STDEVP([total]) AS total 
						FROM [reporte].[PeriodoMensual] where mes not in ('TotalMes' , 'Promedio')
						GROUP BY unidadDescripcion, color
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT unidadDescripcion, color, 'D(dda)' AS [D(dda)],
						CASE WHEN @redondeo_probabilidad = 1 THEN ROUND(total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,4)),0) ELSE total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,4)) END AS total
						--total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,4)) AS total 
						FROM [reporte].[PeriodoMensual] WHERE mes = 'DesvStd'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, 'I/Viariabilidad' AS [I/Viariabilidad],
						CASE WHEN P1.total > 0 THEN 
						CASE WHEN @redondeo_probabilidad = 1 THEN ROUND(P2.total/P1.total,0) ELSE P2.total/P1.total END -- AS total
						--P2.total/P1.total 
						ELSE 0 END AS total
						--CASE WHEN P1.total > 0 THEN P2.total/P1.total ELSE 0 END AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, '100%' AS [100%],
						CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total* (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,6))),0) ELSE P1.total + (P2.total* (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,6))) END AS total
						--P1.total + (P2.total* (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,6))) AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, '99%' AS [99%],
						CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,7))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,7))) END AS total
						--P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,7))) AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, '98%' AS [98%], 
						CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,8))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,8))) END AS total
						--P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,8))) AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, '97%' AS [97%],
						CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,9))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,9))) END AS total
						--P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,9))) AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, '90%' AS [90%],
						CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,10))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,10))) END AS total
						--P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,10))) AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, '84%' AS [84%],
						CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + P2.total,0) ELSE P1.total + P2.total END AS total
						--P1.total + P2.total AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, '67%' AS [67%],
						CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,12))),0) ELSE P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,12))) END  AS total
						--P1.total + (P2.total*(SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,12))) AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Promedio' AND P2.mes = 'D(dda)'
	
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT unidadDescripcion, color, '50%' AS [50%],
						CASE WHEN @redondeo_porcentaje = 1 THEN ROUND(total,0) ELSE total END AS total
						--ROUND(total,0) AS total
						FROM [reporte].[PeriodoMensual] WHERE mes = 'Promedio'
		
						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion
						, 'AZUL' AS color
						,'Inventario' AS [Inventario] 
						, COUNT(P1.unidadDescripcion) AS total
						FROM [192.168.20.31].[FinanzasSite].Unidad.InventarioUnidad P1
						WHERE P1.idCompania = @idCompania AND P1.periodoYear = CAST(DATEPART(YEAR,DATEADD(MM,-1,GETDATE())) AS CHAR(4)) AND P1.periodoMes = CAST(DATEPART(MONTH,DATEADD(MM,-1,GETDATE())) AS CHAR(4)) AND P1.idSucursal = @idSucursal AND P1.idOrigen = 1	
						AND idOrigen = 1
						GROUP BY P1.unidadDescripcion

						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT unidadDescripcion, color, 'ExistenciasPorLlegar' AS [ExistenciasPorLlegar], 0 AS total FROM [reporte].[PeriodoMensual]
						GROUP BY unidadDescripcion, color

						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, 'TotalExistencias' AS [TotalExistencias], P1.total + P2.total AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color
						WHERE P1.mes = 'Inventario' AND P2.mes = 'ExistenciasPorLlegar'


						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, 'Pronostico' AS [Pronostico],
						CASE 
									WHEN P1.total <= 1.2 THEN ROUND( P2.TOTAL,0)
									WHEN P1.total <= 1.5 THEN ROUND( P3.TOTAL,0)
									WHEN P1.total <= 1.9 THEN ROUND( P4.TOTAL,0)
									WHEN P1.total <= 2.3 THEN ROUND( P5.TOTAL,0)
									WHEN P1.total <= 2.6 THEN ROUND( P6.TOTAL,0)
									WHEN P1.total <= 2.9 THEN ROUND( P7.TOTAL,0)
									WHEN P1.total <= 3.5 THEN ROUND( P8.TOTAL,0)
							ELSE 0
						END
						AS total
						FROM [reporte].[PeriodoMensual] P1
						INNER JOIN [reporte].[PeriodoMensual] P2 ON P1.unidadDescripcion = P2.unidadDescripcion AND P1.color = P2.color	AND P2.mes = '99%'
						INNER JOIN [reporte].[PeriodoMensual] P3 ON P1.unidadDescripcion = P3.unidadDescripcion AND P1.color = P3.color	AND P3.mes = '98%'
						INNER JOIN [reporte].[PeriodoMensual] P4 ON P1.unidadDescripcion = P4.unidadDescripcion AND P1.color = P4.color	AND P4.mes = '97%'
						INNER JOIN [reporte].[PeriodoMensual] P5 ON P1.unidadDescripcion = P5.unidadDescripcion AND P1.color = P5.color	AND P5.mes = '90%'
						INNER JOIN [reporte].[PeriodoMensual] P6 ON P1.unidadDescripcion = P6.unidadDescripcion AND P1.color = P6.color	AND P6.mes = '84%'
						INNER JOIN [reporte].[PeriodoMensual] P7 ON P1.unidadDescripcion = P7.unidadDescripcion AND P1.color = P7.color	AND P7.mes = '67%'
						INNER JOIN [reporte].[PeriodoMensual] P8 ON P1.unidadDescripcion = P8.unidadDescripcion AND P1.color = P8.color	AND P8.mes = '50%'
						WHERE P1.mes = 'I/Viariabilidad'
		

						INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
						SELECT P1.unidadDescripcion, P1.color, 'PronosticoReporte' AS [PronosticoReporte],
						ROUND( P1.total * (SELECT configuracion.SEL_PARAMETRO_FN(@idCompania,27)),0) AS total
						FROM [reporte].[PeriodoMensual] P1
						WHERE P1.mes = 'Pronostico' 
								

						INSERT INTO @paso
						SELECT unidadDescripcion, color, [PronosticoReporte] FROM (
						SELECT unidadDescripcion, color, mes, total
						FROM [reporte].[PeriodoMensual]) A
						pivot (avg(total) for mes in([PronosticoReporte] )) AS Y

							
						IF(@id_TipoReporte = 2)
						BEGIN
							UPDATE vnt
							SET 
							vnt.Meses2  = ROUND(pas.PronosticoReporte,0)
							FROM @ventasIntercambio vnt
							INNER JOIN @paso pas
							ON vnt.unidadDescripcion = pas.unidadDescripcion

						END
						IF(@id_TipoReporte = 3)
						BEGIN
							UPDATE vnt
							SET 
							vnt.Meses3  = ROUND(pas.PronosticoReporte,0) 
							FROM @ventasIntercambio vnt
							INNER JOIN @paso pas
							ON vnt.unidadDescripcion = pas.unidadDescripcion
						END
						IF(@id_TipoReporte = 4)
						BEGIN
							UPDATE vnt
							SET 
							vnt.Meses4  = ROUND(pas.PronosticoReporte,0) 
							FROM @ventasIntercambio vnt
							INNER JOIN @paso pas
							ON vnt.unidadDescripcion = pas.unidadDescripcion
						END

					DELETE FROM @paso
					
				END
				

				-- EXEC [reporte].[SEL_UNIDADES_SP] 11,5,31,89, 30, ''		

				SET @aux = @aux + 1

				END

				IF(@idTipoReporte = 5)
				BEGIN
					SELECT unidadDescripcion,color,TotalExistencias,
					Meses2 as '6Meses',
					Meses3 as '9Meses',
					Meses4 as '12Meses',
					ROUND((Meses2 + Meses3 + Meses4)/3,0) AS PronosticoReal
					FROM @ventasIntercambio
				END
				ELSE IF(@idTipoReporte = 6)
				BEGIN
					
					
					INSERT INTO [reporte].[PeriodoMensual] (unidadDescripcion, color, mes, total)
					SELECT P1.unidadDescripcion
					, 'AZUL' AS color
					,'Inventario' AS [Inventario] 
					, COUNT(P1.unidadDescripcion) AS total
					FROM [192.168.20.31].[FinanzasSite].Unidad.InventarioUnidad P1
					WHERE P1.idCompania = @idCompania AND P1.periodoYear = CAST(DATEPART(YEAR,DATEADD(MM,-1,GETDATE())) AS CHAR(4)) AND P1.periodoMes = CAST(DATEPART(MONTH,DATEADD(MM,-1,GETDATE())) AS CHAR(4)) AND P1.idSucursal = @idSucursal AND P1.idOrigen = 1	
					AND idOrigen = 1
					GROUP BY P1.unidadDescripcion

					DECLARE @p1 TABLE(unidadDescripcion NVARCHAR(300),Inventario INT) 


					INSERT INTO @p1
					SELECT unidadDescripcion, [Inventario]
					FROM (
					SELECT unidadDescripcion, color, mes, total
					FROM [reporte].[PeriodoMensual]) A
					pivot (avg(total) for mes in([Inventario],[PedidoMes],[VentasPronostico],[InventarioTeorico])) AS Y

					SELECT A.unidadDescripcion,coalesce( A.Inventario,0) AS Inventario,0 AS ExistenciasPorLlegar,0 AS [PedidoMes], 
					ROUND((Meses2 + Meses3 + Meses4)/3,0) AS [VentasPronostico],
					0 AS [InventarioTeorico]
					FROM @p1 AS A
					INNER JOIN @ventasIntercambio b on A.unidadDescripcion = b.UnidadDescripcion

				
				END

	END
	
	
	
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

