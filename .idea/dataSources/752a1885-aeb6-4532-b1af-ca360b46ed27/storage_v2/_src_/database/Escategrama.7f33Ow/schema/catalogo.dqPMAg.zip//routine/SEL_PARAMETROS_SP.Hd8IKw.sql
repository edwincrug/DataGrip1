-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 30-10-2020
-- Description: Recupera el catalogo de Parametros de la tabla [catalogo].[TipoParametro]
-- EXEC [catalogo].[SEL_PARAMETROS_SP] 1,2,30, ''
-- =============================================

CREATE PROCEDURE [catalogo].[SEL_PARAMETROS_SP]
	@tipo			int,
	@idCompania     int,
	@idUsuario		int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY
		--IF EXISTS(SELECT idCompania from [configuracion].[Parametros] where idCompania = @idCompania)
			--SELECT idParametrizacion, [idTipoParametro], [idOrden], [parametro], [valor] 
			--from [configuracion].[Parametros] where idCompania = @idCompania
			--and [esActivo] = 1 and [origen] = 2
		--ELSE
			IF(@tipo = 1)
			BEGIN
				SELECT coalesce(idParametrizacion,0) as idParametrizacion, a.[idTipoParametro], [idOrden], [parametro], coalesce([valor],0) as valor,coalesce(n.titulo,a.titulo) AS titulo  FROM [catalogo].[TipoParametro]  a
				LEFT JOIN [configuracion].[Parametrizacion] n on a.idTipoParametro = n.idTipoParametro and n.idCompania = @idCompania
				WHERE [esActivo] = 1 and [origen] in (2)
			END
			ELSE
				BEGIN
					SELECT 
					coalesce([idParamTipoReporte],0) AS [idParamTipoReporte]
					,coalesce(B.[idTipoReporte],A.[idTipoReporte]) AS [idTipoReporte]
					,coalesce(B.[descripcion],A.[descripcion]) AS [descripcion]
					,[esActivo]
					,coalesce(B.[anioAnterior],A.[anioAnterior]) AS [anioAnterior]
					,coalesce(B.[mesInicial],A.[mesInicial]) AS [mesInicial]

				FROM [Escategrama].[catalogo].[TipoReporte] A
				LEFT JOIN [Escategrama].[configuracion].[ParamTipoReporte] B ON A.idTipoReporte = B.idTipoReporte AND B.idCompania = @idCompania
				WHERE [esActivo] = 1 AND A.idTipoReporte NOT IN (5,6)
			END
			
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

