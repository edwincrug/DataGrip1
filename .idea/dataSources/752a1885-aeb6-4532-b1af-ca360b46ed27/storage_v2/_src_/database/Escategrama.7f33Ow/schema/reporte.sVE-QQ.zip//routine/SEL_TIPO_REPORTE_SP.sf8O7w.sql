-- =============================================
-- Author:		<DVR>
-- Create date: <26/10/2020>
-- Description:	<Obtiene el listado de tipos de reportes a consultar>
-- Test [reporte].[SEL_TIPO_REPORTE_SP]  2,30,''
-- =============================================
CREATE PROCEDURE [reporte].[SEL_TIPO_REPORTE_SP] 
	@idCompania				int,
	@idFoto					int,
	@idUsuario				int,
	@err					varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY

	IF(@idFoto > 0)
		BEGIN
			SELECT 
			 [idTipoReporte],
			 [anioAnterior],
			 [mesInicial],
			 [descripcion]
			FROM [Escategrama].[reporte].[FotoParamTipoReporte] A
			
			WHERE idFoto = @idFoto
			

		END
		ELSE
		BEGIN

					SELECT 
						 coalesce(B.[idTipoReporte],A.[idTipoReporte]) AS [idTipoReporte]
						,coalesce(B.[descripcion],A.[descripcion]) AS [descripcion]
						,[esActivo]
						,coalesce(B.[anioAnterior],A.[anioAnterior]) AS [anioAnterior]
						,coalesce(B.[mesInicial],A.[mesInicial]) AS [mesInicial]

				FROM [Escategrama].[catalogo].[TipoReporte] A
				LEFT JOIN [Escategrama].[configuracion].[ParamTipoReporte] B ON A.idTipoReporte = B.idTipoReporte AND B.idCompania = @idCompania
				WHERE [esActivo] = 1
		END



		
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

