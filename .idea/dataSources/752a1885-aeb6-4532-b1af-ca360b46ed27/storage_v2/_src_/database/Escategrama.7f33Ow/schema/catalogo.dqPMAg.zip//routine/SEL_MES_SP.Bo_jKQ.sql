-- =============================================
-- Author: Jose Alberto Polo Lara	
-- Create date: 26-10-2020
-- Description: Recupera los meses para cabecero de reporte de la tabla catalogo.Mes
-- EXEC [catalogo].[SEL_MES_SP] 10, 2, 30, ''
-- =============================================

CREATE PROCEDURE [catalogo].[SEL_MES_SP]
	@mes		int,
	@idTipoReporte int,
	@idUsuario				int,
	@err			varchar(max) = '' OUTPUT
AS
BEGIN
	BEGIN TRY	
		Set Language spanish
		DECLARE @meses INT, @aplicaAnterior INT = 0
		DECLARE @mesTable AS TABLE ([mes] VARCHAR(50), id INT IDENTITY(1,1))

		SELECT @meses = mesInicial + 1, @aplicaAnterior = anioAnterior 
		FROM [catalogo].[TipoReporte] 
		WHERE idTipoReporte = @idTipoReporte
		
		IF(@aplicaAnterior = 1)
		BEGIN
			SET @meses = 12 + @mes
		END
		
		WHILE (@meses > 1)
		BEGIN
			SET @meses = @meses-1
			INSERT INTO @mesTable (mes)
			SELECT SUBSTRING(DATENAME(MONTH,DATEADD(MM,-@meses,GETDATE())),1,3) + '/' + SUBSTRING(CAST(DATEPART(YEAR,DATEADD(MM,-@meses,GETDATE())) AS CHAR(4)),3,2)
		END

		------------------------------------------------------
		------------------------------------------------------
		-- SE AGREGO COMO PROPUESTA DVR VALIDAR
		INSERT INTO @mesTable
		SELECT	 A.[parametro] FROM [catalogo].[TipoParametro] A
		INNER JOIN [Escategrama].[relacion].[TipoReporteParametro] B ON A.idTipoParametro = B.idTipoParametro
		WHERE B.idTipoReporte = @idTipoReporte AND b.esActivo = 1
		------------------------------------------------------
		------------------------------------------------------

		SELECT id,mes as parametro FROM @mesTable
		ORDER BY id
			
	END TRY
	BEGIN CATCH
		SET  @err = 'Line: ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		SELECT @err AS err;
	END CATCh
	PRINT 'OUT = ' +  @err
	RETURN 0;
END
go

