-- =============================================
-- Author:
-- Create date: <09/06/2020>
-- Description:
-- [dbo].[INS_NOTIFICACION_CORREOCONTRALORIA_SP] 10, 251794, 11
-- INS_NOTIFICACION_CORREOCONTRALORIA_GV_SP 488306
-- =============================================
CREATE PROCEDURE [dbo].[INS_NOTIFICACION_CORREOCONTRALORIA_GV_SP] 
@not_id NUMERIC(18,0)
AS
BEGIN
DECLARE @not_Agrupacion INT = 51, @idNot INT, @idAprobacion INT

DECLARE @idComprobacion INT, @link_BPRO varchar(max), @not_descripcion varchar(max), @not_Adjunto varchar(max), @not_AdjuntoTipo varchar(max), 
@emp_id INT, @tipoNotificacion INT, @nombreUsuario varchar(max), @correo varchar(max), @subjet varchar(max), @idComprobacionVale varchar(50)
,@idEmpresa int, @idSucursal int, @selEmpresa varchar(150), @selSucursal varchar(150)
select top 1 
@idComprobacion = not_identificador,
@link_BPRO = not_link_BPRO,
@not_descripcion = not_descripcion,
@not_Adjunto = not_adjunto,
@not_AdjuntoTipo = not_adjunto_tipo
from [dbo].[NOT_NOTIFICACION] where not_id = @not_id
--select top 1 @emp_id = emp_id from [dbo].[NOT_APROBACION] where not_id = @not_id
--select
--@tipoNotificacion = fv.tipoNotificacion,
--@idComprobacionVale = ve.idComprobacionVale from tramites.tramite.valesEvidencia ve
--left join tramites.tramite.FacturaVale fv on fv.id = ve.idfactura
--where ve.id = @idComprobacion
select @tipoNotificacion = tipoNotificacion, @idComprobacionVale  =idconceptoarchivo  from tramites.tramite.conceptoarchivo where idconceptoarchivo = @idComprobacion
IF(@tipoNotificacion = 2)
BEGIN
	select
	@nombreUsuario = u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno,
	@correo = u.usu_correo,
	@emp_id =  ef.usuario_autoriza
	from Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT ef
	inner join controlaplicaciones.dbo.cat_usuarios u on u.usu_idusuario = ef.usuario_autoriza
	where ef.not_agrupador = @not_Agrupacion

	SELECT
	@idEmpresa = td.id_empresa,
	@idSucursal = td.id_sucursal
	FROM [dbo].[NOT_NOTIFICACION] n
	JOIN Tramites.Tramite.ConceptoArchivo ca
		ON n.not_identificador = ca.idConceptoArchivo
	JOIN tramites.tramite.TramiteConcepto tc
		ON ca.idReferencia = tc.idTramiteConcepto
	JOIN Tramites.dbo.tramiteDevoluciones td
		ON tc.idTramitePersona = td.id_perTra
	WHERE not_id = @not_id

	select @selEmpresa = emp_nombre from ControlAplicaciones..cat_empresas where emp_idempresa = @idEmpresa
	SELECT @selSucursal = cs.suc_nombre FROM ControlAplicaciones..cat_sucursales cs where cs.suc_idsucursal = @idSucursal

	INSERT INTO NOT_NOTIFICACION (
	not_tipo
	, not_tipo_proceso
	, not_identificador
	, not_nodo
	, not_descripcion
	, not_estatus
	, not_fecha
	, not_link_BPRO
	, not_adjunto
	, not_adjunto_tipo
	, not_agrupacion
	, idEmpresa
	, idSucursal
	, idDepartamento
	)
	VALUES ( 
	1
	, 1
	, @idComprobacion
	, ''
	, @not_descripcion
	, 2
	, GETDATE()
	, @link_BPRO
	, @not_Adjunto
	, @not_AdjuntoTipo
	, @not_Agrupacion
	, NULL
	, NULL
	, 0
	)
	SET @idNot  = @@IDENTITY
	INSERT INTO [dbo].[NOT_APROBACION]
	([not_id]
	,[apr_nivel]
	,[apr_visto]
	,[emp_id]
	,[apr_fecha]
	,[apr_estatus]
	,[apr_escalado])
	VALUES
	(@idNot
	,0
	,NULL
	,@emp_id
	,GETDATE()
	,1
	,0)
	SET @idAprobacion = SCOPE_IDENTITY()
	SELECT  @idNot not_id, 1 success, 1 result , 'message' = 'La operación se realizó con exito.' , @idAprobacion apr_id, @tipoNotificacion enviaNoti,
	@correo correo, @link_BPRO linkBPRO, @idComprobacionVale idComprobacionVale, 'Solicitud de Aprobación de Factura' as [subject], @selEmpresa as selEmpresa,
	@selSucursal as selSucursal
END
ELSE
BEGIN
	select 1 result, @tipoNotificacion enviaNoti
END
END
go

