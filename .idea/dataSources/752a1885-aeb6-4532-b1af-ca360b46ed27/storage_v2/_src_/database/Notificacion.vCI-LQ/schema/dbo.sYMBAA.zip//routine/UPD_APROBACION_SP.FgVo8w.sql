
-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 28/10/2015
-- Description:	Procedimiento que realiza la aprobación tomando en cuenta
-- el nivel de escalamiento y al usuario mancomunado.
-- El parámetro de respuesta solo puede tener los valores: 1- Aprobado,  0- Rechazado
-- =============================================

-- [UPD_APROBACION_SP] 432, 2, 'Probando'
CREATE PROCEDURE [dbo].[UPD_APROBACION_SP]
	@idAprobacion int
	,@respuesta   int
	,@observacion nvarchar(max)
AS
	
		DECLARE @idnotificacion int
		DECLARE @proceso int
		DECLARE @nodo int
		DECLARE @folio nvarchar(100)
		--DECLARE @respuestaest int;
		DECLARE @usuariomancomunado int =0, @usuario int =0
		DECLARE @not_identificador VARCHAR
		DECLARE @not_agrupacion int

		-- Obtener el idNotificacion
		SELECT @idnotificacion = not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion
		-- Obtener el idNotifiacion
			     
		SELECT @not_agrupacion = not_agrupacion 
		,@proceso = not_tipo_proceso
		,@nodo = not_nodo + 1
		,@folio = not_identificador
		from dbo.NOT_NOTIFICACION 
		where not_id = @idnotificacion
				--Valida si ya fue aprobada la orden
		--LQMA 17032017, se agregaron los tipos 2 y 4 para que se valide en todos los casos		 
 		IF EXISTS(SELECT not_id FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion AND not_tipo IN (1,2,3,4) AND not_nodo = 1 AND not_estatus in(3,4,5))
		BEGIN
			-- Si ya fue aprobada no hace la actualizacion y la pone como retrasada adicionalmente sale con 5
			PRINT 'Ya existe'
			UPDATE NOT_APROBACION SET apr_estatus = 5 WHERE apr_id = @idAprobacion
			SELECT -1
		END
		ELSE	
		BEGIN
			IF(@not_agrupacion = 0)
			BEGIN	
				PRINT 'Agrupación 0'
				IF @respuesta = 1
				BEGIN		
					SELECT   @usuariomancomunado = dep.usuario_mancomunado
							, @usuario = apr.emp_id
							, @not_identificador = ntf.not_identificador					
						FROM    
						
							dbo.NOT_APROBACION apr 
							LEFT JOIN dbo.NOT_NOTIFICACION ntf ON ntf.not_id = apr.not_id
						    LEFT JOIN [dbo].[OrdenesdeCompra] orc ON orc.oce_folioorden = ntf.not_identificador
						    LEFT JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_PARAMETROS dep ON dep.Proc_Id = ntf.not_tipo_proceso
						    AND dep.Nodo_Id = ntf.not_nodo 
						    AND dep.emp_idempresa = orc.[oce_idempresa]
						    AND dep.suc_idsucursal = orc.[oce_idsucursal]
						    AND dep.dep_iddepartamento = orc.[oce_iddepartamento]
						    AND dep.tipo_idtipoorden = orc.[oce_idtipoorden]
						    
					WHERE apr.apr_id =  @idAprobacion		
						  
	
					
					IF ((@usuariomancomunado IS NULL) OR (@usuariomancomunado = @usuario) )						
					BEGIN	
						PRINT 'Entra acciones aprobación 0'
						EXECUTE [INS_ACCIONES_APROBACION_0_SP] 
								@idAprobacion 
								,@respuesta   
								,@observacion 
								,@idnotificacion 
								,@usuario
								,@folio
					END
					ELSE
					BEGIN
						EXEC INS_MANCOMUNADO_SP @idAprobacion
						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
						VALUES
							(@not_identificador,@idAprobacion,GETDATE(),@observacion)
						UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion
						print 'freshness'
					END
				END
				ELSE
				BEGIN
					EXECUTE [INS_ACCIONES_APROBACION_0_SP] 
								@idAprobacion 
								,@respuesta   
								,@observacion 
								,@idnotificacion 
								,@usuario
								,@folio
								print 'freshness'
				END
			END	     										     																						
			IF(@not_agrupacion = 1)
			BEGIN	
			    PRINT 'Lotes'
				--Acciones de aprobación para lotes
				EXECUTE [INS_ACCIONES_APROBACION_1_SP] 
								@idAprobacion 
								,@respuesta   
								,@observacion 
								,@idnotificacion 
								,@usuario
			END	     										     																						
			IF(@not_agrupacion = 2)
			BEGIN	
				PRINT 'Flotillas'
				--ACCIONES DE APROBACIÓN para flotillas
				EXECUTE [INS_ACCIONES_APROBACION_2_SP] 
								@idAprobacion 
								,@respuesta   
								,@observacion 
								,@idnotificacion 
								,@usuario
			END	
			--/////////////add Laura 
			--***Lo de adentro de este(entre --%%) if se encontraba sin condición, se coloca la condición por que 
			--***para el @not_agrupacion = 5 no contiene nodo
			--***y se tiene que realizar un upd en la tabla [ser_presupweb]
			--***para el @not_agrupacion = 6 no contiene nodo
			--***y se tiene que realizar un upd en la tabla [ser_presupwebdet]
			DECLARE @idEmpresa INT =0, @idSucursal INT=0
			SELECT  @idEmpresa= NN.idEmpresa,
					@idSucursal= NN.idSucursal
					FROM [Notificacion].[dbo].[NOT_APROBACION] NA
					INNER JOIN [Notificacion].[dbo].[NOT_NOTIFICACION] NN ON NA.not_id=NN.not_id 
					WHERE [apr_id]=@idAprobacion
			DECLARE @identificador varchar(20)=(select [referencias].[dbo].[fn_BuscaNumeros](@folio));
			print 'identificador'
			print @identificador
			DECLARE @orden INT =(SELECT prw_idpresuorden FROM [cuentasporcobrar].[dbo].[ser_presupweb] WHERE prw_nopresupuesto=@identificador and prw_idempresa=@idEmpresa and prw_idsucursal=@idSucursal)
			print 'orden'
			print @orden
			IF (@not_agrupacion = 5) --5 = encabezado de presupuesto normal/adicional LQMA			
				BEGIN 					
					print @identificador
					
					--@folio
					IF(@respuesta=1)
						BEGIN
							--SELECT * FROM [cuentasporcobrar].[dbo].[ser_presupweb] WHERE prw_idpresuorden=@idnotificacion	
							UPDATE [cuentasporcobrar].[dbo].[ser_presupweb]
							SET cec_idestatuspresuint=5
							WHERE prw_idpresuorden=@orden
						END
					ELSE
						BEGIN
							UPDATE [cuentasporcobrar].[dbo].[ser_presupweb]
							SET cec_idestatuspresuint=4
							WHERE prw_idpresuorden=@orden
						END	
						print		@idAprobacion 
						print		@respuesta   
						print		@observacion 
						print		@idnotificacion 
						print		@usuario
						print		@folio
						--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
						--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
						--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
						EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
								@idAprobacion 
								,@respuesta   
								,@observacion 
								,@idnotificacion 
								,@usuario
								,@folio
						--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{						
				END
			IF (@not_agrupacion = 6) --6 = detalle de presupuesto normal/adicional LQMA				
				BEGIN
				print'Entre al 6'	
					print @not_agrupacion				
					print @identificador                                          --ADD LQMA @folioOrden, @clasificacion 08032017
					DECLARE @max int, @condicion int, @aux int=1, @idDetalle INT, @folioOrden VARCHAR(50) = '', @clasificacion VARCHAR(10) = '', @idUsuario INT = 0  
					DECLARE @tabInfoDetalle TABLE (ID INT IDENTITY(1,1), idDetalle INT, idDetEncabezado INT)--, folioOrden VARCHAR(50) NULL,clasificacion VARCHAR(10) NULL) --ADD LQMA @folioOrden, @clasificacion 08032017
					--@folio
					IF(@respuesta=1)
						BEGIN
							--#############################################################################################
							--Recorre el detalle del presupuesto para cheacar donde cec_idestatuspresuint=2 y modificar por 5.-Autorizado, 6.-Rechazado
							print 'Entre a la respuesta 1'
							INSERT INTO @tabInfoDetalle
								SELECT pwd_idordendet, prw_idpresuorden--, pwd_foliocompra, pwd_clasificacion
										FROM [cuentasporcobrar].[dbo].[ser_presupwebdet] WHERE prw_idpresuorden=@orden 
							SELECT @max =  MAX(ID) FROM @tabInfoDetalle
							print @max
							WHILE (@aux<=@max)
								BEGIN				
									SELECT	@condicion=cec_idestatuspresuint,
											@idDetalle=pwd_idordendet 
											FROM [cuentasporcobrar].[dbo].[ser_presupwebdet] 
											WHERE pwd_idordendet=(SELECT idDetalle FROM @tabInfoDetalle WHERE ID=@aux)
									--
									IF(@condicion=2 OR @condicion=3)
										BEGIN
											PRINT 'ENTRE a la condicion 2'
											UPDATE [cuentasporcobrar].[dbo].[ser_presupwebdet]
											SET cec_idestatuspresuint=5
											WHERE pwd_idordendet=@idDetalle
										END	
									SET @aux += 1			
								END
							--#############################################################################################						
							
						END
					ELSE
						BEGIN
							--#############################################################################################
							--Recorre el detalle del presupuesto para cheacar donde cec_idestatuspresuint=2 y modificar por 5.-Autorizado, 7.-Rechazado
							print'Entre a la 2'
							print @orden
							print 'Orden'
							INSERT INTO @tabInfoDetalle
								SELECT pwd_idordendet, prw_idpresuorden--, pwd_foliocompra, pwd_clasificacion
										FROM [cuentasporcobrar].[dbo].[ser_presupwebdet] WHERE prw_idpresuorden=@orden
							SELECT @max =  MAX(ID) FROM @tabInfoDetalle
							print @max
							WHILE (@aux<=@max)
								BEGIN				
									SELECT	@condicion=cec_idestatuspresuint,
											@idDetalle=pwd_idordendet,
											@folioOrden = pwd_foliocompra, -- ADD LQMA 08032017
											@clasificacion = pwd_clasificacion, -- ADD LQMA 08032017
											@idUsuario = pwd_idusuario
											FROM [cuentasporcobrar].[dbo].[ser_presupwebdet] 
											WHERE pwd_idordendet=(SELECT idDetalle FROM @tabInfoDetalle WHERE ID=@aux)
									--
									IF(@condicion=2 OR @condicion=3)
										BEGIN
											PRINT 'ENTRE '
											UPDATE [cuentasporcobrar].[dbo].[ser_presupwebdet]
											SET cec_idestatuspresuint=4
											WHERE pwd_idordendet=@idDetalle
											--LQMA 08032017	se agrego para cancelar la orden de compray agregarlo en la bitacora
											--IF(UPPER(@clasificacion) = 'TT' AND @folioOrden != '')
											--	BEGIN										
											--				UPDATE [cuentasxpagar].[dbo].[cxp_ordencompra]
											--				SET [sod_idsituacionorden] = 4
											--				WHERE oce_folioorden = @folioOrden
													
											--				INSERT INTO [cuentasxpagar].[dbo].[cxp_movimientosorden]
											--				VALUES (@idUsuario,CONVERT(date, getdate()),CONVERT(time, getdate()),@folioOrden,4)
											--	END
										END								

									
									SET @aux += 1									
									
								END
							--#############################################################################################
							
						END	
						--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
						--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
						--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
						EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
								@idAprobacion 
								,@respuesta   
								,@observacion 
								,@idnotificacion 
								,@usuario
								,@folio
						--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{				
				END
			--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
			--????????????????????????????????????????????????????????????????????
			--Para realizar el cambio de estatus de cec_idestatuscotiza 13.-Autorizada 14.-Cancelada 
			IF (@not_agrupacion = 7)
				BEGIN 

					/* COMMENT, LQMA  17042018, se cambio la regla de negocio, Luis Bonnete, Jose Manuel, se autorizara por detalle de cotización
					IF(@respuesta=1)
						BEGIN
							--SELECT * FROM [cuentasporcobrar].[dbo].[ser_presupweb] WHERE prw_idpresuorden=@idnotificacion	
							UPDATE [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
							SET cec_idestatuscotiza=17
							WHERE ucu_foliocotizacion =@folio
						END
					ELSE
						BEGIN
							UPDATE [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
							SET cec_idestatuscotiza=14
							WHERE ucu_foliocotizacion =@folio
						END
					*/
										
					DECLARE @idDetalleCotizacion INT = 0

					SELECT @idDetalleCotizacion = not_adjunto_tipo FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion

					UPDATE [cuentasporcobrar].[dbo].CC SET CC.ucc_estatus = CASE @respuesta 
																				WHEN 1 THEN 1  --aprobado
																				WHEN 0 THEN 3  --rechazado
																			END  
					FROM [cuentasporcobrar].[dbo].UNI_CCS CC 
					INNER JOIN [cuentasporcobrar].[dbo].uni_cotizacionuniversal ctz
					ON cc.ucu_idcotizacion=ctz.ucu_idcotizacion
					WHERE ctz.ucu_foliocotizacion = @folio
						  AND ucc_idcc = @idDetalleCotizacion
				
					--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
					--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
					--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
					EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
							@idAprobacion 
							,@respuesta   
							,@observacion 
							,@idnotificacion 
							,@usuario
							,@folio
					--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{	

				END
			--????????????????????????????????????????????????????????????????????
			--....................................................................
			--............Para aceptar o rechazar Cotización sin Anticipo
			IF (@not_agrupacion = 8)
				BEGIN 
					DECLARE @idCotizacion INT = 0;
					DECLARE @emp_id INT =0;
					SELECT @idCotizacion = [ucu_idcotizacion]      
					FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE ucu_foliocotizacion = @folio 
					PRINT @idCotizacion
					SELECT @emp_id = [emp_id] FROM NOT_APROBACION WHERE apr_id = @idAprobacion
					PRINT @emp_id
					IF(@respuesta=1)
						BEGIN
							print 1
							UPDATE [cuentasporcobrar].[dbo].[UNI_AutorizacionEspecial]
							SET	   UAE_EstatusAutEsp=2, UAE_IdUsuarioAutoriza=@emp_id, UAE_FechaAutorizacion=GETDATE() 
							WHERE  UCU_IdCotizacion=@idCotizacion AND [UAE_EstatusAutEsp]=1
						END
					ELSE
						BEGIN
						print 2
							UPDATE [cuentasporcobrar].[dbo].[UNI_AutorizacionEspecial]
							SET	   UAE_EstatusAutEsp=3, UAE_IdUsuarioAutoriza=@emp_id, UAE_FechaAutorizacion=GETDATE() 
							WHERE  UCU_IdCotizacion=@idCotizacion AND [UAE_EstatusAutEsp]=1
						END
					--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
					--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
					--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
					EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
							@idAprobacion 
							,@respuesta   
							,@observacion 
							,@idnotificacion 
							,@usuario
							,@folio
					--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{	

				END
			--....................................................................
			IF (@not_agrupacion= 0 OR @not_agrupacion = 1 OR @not_agrupacion = 2)
				BEGIN
				DECLARE @proc_Id int
				DECLARE @nodo_Id int
				DECLARE @folio_Operacion varchar(80)

				EXECUTE [Centralizacionv2].[dbo].[INS_CIERRA_NODO_SP] 
				@proceso  --proceso
				,@nodo --nodo
				,@folio --folio
				
				END	
			--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55


     	SELECT 0
		
		END									     																						
		

;
go

