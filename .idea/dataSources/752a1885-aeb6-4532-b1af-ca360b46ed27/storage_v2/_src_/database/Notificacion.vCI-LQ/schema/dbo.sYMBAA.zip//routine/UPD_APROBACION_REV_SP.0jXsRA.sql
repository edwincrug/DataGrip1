-- Author:	    Lourdes Maldonado Sánchez
-- Create date: 13/01/2016
-- Description:	Procedimiento que realiza 
-- El parámetro de respuesta solo puede tener los valores: Revision
-- =========================================================================
-- [UPD_APROBACION_REV_SP] 144, 2 ,'345'
CREATE PROCEDURE [dbo].[UPD_APROBACION_REV_SP]
	 @idAprobacion INT = 0 
	,@respuesta   INT = 0         
	,@observacion VARCHAR(500) = '' 
	,@idUsuario INT = 0
AS

  DECLARE @res INT = 0
  DECLARE @idnotificacion int

  SELECT @idnotificacion = not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion

  IF EXISTS(SELECT not_id FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion AND not_tipo IN (1,2,3,4) AND not_nodo = 1 AND not_estatus in(3,4,5))
	 BEGIN
			-- Si ya fue aprobada no hace la actualizacion y la pone como retrasada adicionalmente sale con 5
			PRINT 'Ya existe'
			--UPDATE NOT_APROBACION SET apr_estatus = 5 WHERE apr_id = @idAprobacion
			--SELECT @res = -1
			SELECT -1 estatus, 'La solicitud fue aprobada previamente por otro autorizador.' mensaje 
	 END
  ELSE
     BEGIN	 

		BEGIN TRY
			BEGIN TRAN TRAN_APROBACION_REVISION
			
			DECLARE @not_identificador NUMERIC(18,0)
			DECLARE @folio nvarchar(100)
    
			SELECT @not_identificador = NOT_ID FROM NOT_APROBACION WHERE apr_id = @idAprobacion
			SELECT @folio = not_identificador FROM NOT_NOTIFICACION WHERE not_id = @not_identificador

			 --Update para el estatus a 6 en NOT_APROBACION
			 UPDATE NOT_APROBACION 
				SET APR_ESTATUS = 6 
			  WHERE apr_id = @idAprobacion

			 --Update para el estatus a 6 en NOT_NOTIFICACION 
			 UPDATE NOT_NOTIFICACION  
				SET not_estatus = 6 
			  WHERE NOT_ID = @not_identificador

			 --Insertamos en Aprobacion Respuesta 
			 INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
						  (not_id,[apr_id],[nar_fecha],[nar_comentario])
     				VALUES(@not_identificador,@idAprobacion,GETDATE(),@observacion)
			--UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion
	
			--Update para el estatus a 20(Revision) en CXP_ORDENCOMPRA
				UPDATE [cuentasxpagar].[dbo].[cxp_ordencompra]
					SET sod_idsituacionorden = 20
				WHERE oce_folioorden = @folio
					  AND sod_idsituacionorden <> 20
	 
 			COMMIT TRAN TRAN_APROBACION_REVISION

			SELECT 0 estatus, 'La solicitud fue enviada a revisión.' mensaje 

		END TRY
		BEGIN CATCH
			
			ROLLBACK TRAN TRAN_APROBACION_REVISION
			PRINT ('Error: ' + ERROR_MESSAGE())
			DECLARE @Mensaje  nvarchar(max),
			@Componente nvarchar(50) = 'UPD_APROBACION_REV_SP'
			SELECT @Mensaje = ERROR_MESSAGE()
						
			DECLARE @tablaRespuesta TABLE(idError INT)

			INSERT INTO @tablaRespuesta
			EXECUTE INS_ERROR_SP @Componente, @Mensaje
					
			SELECT ERROR_NUMBER() estatus, @Mensaje mensaje

		END CATCH

	END --ELSE			


go

