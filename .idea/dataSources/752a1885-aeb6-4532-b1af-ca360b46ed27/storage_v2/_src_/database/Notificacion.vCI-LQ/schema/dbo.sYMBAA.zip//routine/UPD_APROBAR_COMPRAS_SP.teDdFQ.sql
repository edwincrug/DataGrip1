


CREATE Procedure UPD_APROBAR_COMPRAS_SP  
@idAprobacion INT = 0
,@respuesta   INT = 0
,@observacion VARCHAR(max) = ''
,@idUsuario INT = 0
AS 
BEGIN
--DECLARE @idAprobacion INT = 758454
--,@respuesta   INT = 1
--,@observacion VARCHAR(max) = ''
--,@idUsuario INT = 454



	BEGIN TRY
		DECLARE @idEstatus INT = 0, @mensaje VARCHAR(500) = ''
		IF @respuesta = 1
			SET @mensaje = 'Autorización Realizada'
		ELSE
			SET @mensaje = 'Rechazo Realizado'

		DECLARE @idnotificacion int
		DECLARE @proceso int
		DECLARE @nodo int
		DECLARE @folio varchar(100) = ''
		--DECLARE @respuestaest int;
		DECLARE @usuariomancomunado int =0, @usuario int =0
		DECLARE @not_identificador VARCHAR(100) = ''
		DECLARE @not_agrupacion int
		DECLARE @resp VARCHAR(50)
		DECLARE @errorC VARCHAR (100)

		-- Obtener el idNotificacion
		SELECT @idnotificacion = not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion
		-- Obtener el idNotifiacion
			     
		SELECT @not_agrupacion = not_agrupacion 
		,@proceso = not_tipo_proceso
		,@nodo = not_nodo + 1
		,@folio = not_identificador
		from dbo.NOT_NOTIFICACION 
		where not_id = @idnotificacion

		IF EXISTS(SELECT not_id FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion AND not_tipo IN (1,2,3,4) AND not_nodo = 1 AND not_estatus in(3,4,5))
			BEGIN
				-- Si ya fue aprobada no hace la actualizacion y la pone como retrasada adicionalmente sale con 5
			PRINT 'Ya existe'
				UPDATE NOT_APROBACION SET apr_estatus = 5 WHERE apr_id = @idAprobacion
				SELECT -1 estatus, 'La solicitud fue aprobada previamente por otro autorizador.' mensaje 
			END
			ELSE
			BEGIN
				--select * from Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION
						IF  (@not_agrupacion = 47 OR @not_agrupacion = 48 )  -- TIPO A y TIPO B
						BEGIN
								DECLARE @notificacionEstatus INT
								DECLARE @res47 VARCHAR (10)
												
								EXEC [192.168.20.3].Solicitud.[compraBPRO].[UPD_APRUEBA_COMPRA_SP] @folio,@idUsuario,@respuesta, @err = @errorC
								--select @errorC
								set @idEstatus = 0
									
								IF(@respuesta=1 and (@errorC IS NULL OR @errorC  = '') )
									BEGIN
										SELECT  @notificacionEstatus = 3,@mensaje = 'Se autorizó la compra con Folio: ' + @folio, @resp = 'Aprobado: '
										UPDATE NOT_NOTIFICACION SET not_estatus = @notificacionEstatus WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
										UPDATE NOT_APROBACION SET apr_estatus = @notificacionEstatus WHERE apr_id = @idAprobacion;							
										----------------------------------------------------------------
										-------Inserta una respuesta de aprobación
										----------------------------------------------------------------						
							
										INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
											(not_id,[apr_id],[nar_fecha],[nar_comentario])
										VALUES
											(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
			
			
			
										INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
										VALUES (7,'APR_INS_AGRUP7_SP termina @folio: ' + @folio  + ' - ' + @mensaje ,GETDATE())
									END
								ELSE IF(@respuesta=0 and  (@errorC IS NULL OR @errorC  = ''))
									BEGIN
										SELECT @notificacionEstatus =  4,@mensaje = 'Se rechazó la compra con Folio: ' + @folio, @resp = 'Rechazado: '

										UPDATE NOT_NOTIFICACION SET not_estatus = @notificacionEstatus WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
										UPDATE NOT_APROBACION SET apr_estatus = @notificacionEstatus WHERE apr_id = @idAprobacion;							
										----------------------------------------------------------------
										-------Inserta una respuesta de aprobación
										----------------------------------------------------------------						
							
										INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
											(not_id,[apr_id],[nar_fecha],[nar_comentario])
										VALUES
											(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
			
			
			
										INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
										VALUES (7,'APR_INS_AGRUP7_SP termina @folio: ' + @folio  + ' - ' + @mensaje ,GETDATE())

									END
									ELSE 
									BEGIN
										set @idEstatus = -1
										SET @mensaje = 'Ocurrio un problema al realizar la operación.' 
										
									END

								

						END
						IF  (@not_agrupacion = 49  )  -- TIPO C
						BEGIN
								DECLARE @notificacionEstatusC INT

								DECLARE @respComp as TABLE ( respuesta VARCHAR(10))
							
							

								Declare @res49 varchar(10)

								
							
								EXEC   [192.168.20.3].Solicitud.[compraBPRO].[UPD_APRUEBA_ESTUDIO_MERCADO_SP] @folio,@idUsuario,@respuesta,@err = @errorC

								--select @errorC

								set @idEstatus = 0

								IF(@respuesta=1 and  (@errorC IS NULL OR @errorC  = ''))
									BEGIN
										SELECT  @notificacionEstatusC = 3,@mensaje = 'Se autorizó la compra con Folio: ' + @folio, @resp = 'Aprobado: '		
										UPDATE NOT_NOTIFICACION SET not_estatus = @notificacionEstatusC WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
										UPDATE NOT_APROBACION SET apr_estatus = @notificacionEstatusC WHERE apr_id = @idAprobacion;							
										----------------------------------------------------------------
										-------Inserta una respuesta de aprobación
										----------------------------------------------------------------						
							
										INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
											(not_id,[apr_id],[nar_fecha],[nar_comentario])
										VALUES
											(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
			
			
			
										INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
										VALUES (7,'APR_INS_AGRUP7_SP termina @folio: ' + @folio  + ' - ' + @mensaje ,GETDATE())

									END
								ELSE IF(@respuesta=0 and  (@errorC IS NULL OR @errorC  = ''))
									BEGIN
										SELECT @notificacionEstatusC =  4,@mensaje = 'Se rechazó la compra con Folio: ' + @folio, @resp = 'Rechazado: '

										UPDATE NOT_NOTIFICACION SET not_estatus = @notificacionEstatusC WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
										UPDATE NOT_APROBACION SET apr_estatus = @notificacionEstatusC WHERE apr_id = @idAprobacion;							
										----------------------------------------------------------------
										-------Inserta una respuesta de aprobación
										----------------------------------------------------------------						
							
										INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
											(not_id,[apr_id],[nar_fecha],[nar_comentario])
										VALUES
											(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
			
			
			
										INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
										VALUES (7,'APR_INS_AGRUP7_SP termina @folio: ' + @folio  + ' - ' + @mensaje ,GETDATE())

									END
									ELSE 
									BEGIN
										set @idEstatus = -1
										SET @mensaje = 'Ocurrio un problema al realizar la operación.' 
										
									END

								
						END

     				SELECT @idEstatus estatus, @mensaje mensaje 
			END

	
	END TRY
	BEGIN CATCH
	END CATCH



END
go

