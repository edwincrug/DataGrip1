-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <09/06/2020>
-- Description:	<SP que trae inserta la notificacion si va para contraloria>
-- [dbo].[INS_NOTIFICACION_CORREOCONTRALORIA_SP] 10, 251794, 11
-- =============================================
CREATE PROCEDURE [dbo].[INS_NOTIFICACION_CORREOCONTRALORIA_SP] 
	@not_id NUMERIC(18,0)
AS
BEGIN
DECLARE @not_Agrupacion INT = 44, @idNot INT, @idAprobacion INT
DECLARE @idComprobacion INT, @link_BPRO varchar(max), @not_descripcion varchar(max), @not_Adjunto varchar(max), @not_AdjuntoTipo varchar(max), 
		@emp_id INT, @tipoNotificacion INT, @nombreUsuario varchar(max), @correo varchar(max), @subjet varchar(max), @idComprobacionVale varchar(50)

select top 1 
@idComprobacion = not_identificador,
@link_BPRO = not_link_BPRO,
@not_descripcion = not_descripcion,
@not_Adjunto = not_adjunto,
@not_AdjuntoTipo = not_adjunto_tipo
from [dbo].[NOT_NOTIFICACION] where not_id = @not_id
--select top 1 @emp_id = emp_id from [dbo].[NOT_APROBACION] where not_id = @not_id


select 
@tipoNotificacion = fv.tipoNotificacion, 
@idComprobacionVale = ve.idComprobacionVale from tramites.tramite.valesEvidencia ve
left join tramites.tramite.FacturaVale fv on fv.id = ve.idfactura
where ve.id = @idComprobacion

IF(@tipoNotificacion = 2)
BEGIN
select
@nombreUsuario = u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno,
@correo = u.usu_correo,
@emp_id =  ef.usuario_autoriza
from Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT ef
inner join controlaplicaciones.dbo.cat_usuarios u on u.usu_idusuario = ef.usuario_autoriza
where ef.not_agrupador = @not_Agrupacion

						INSERT INTO NOT_NOTIFICACION (
											  not_tipo
											, not_tipo_proceso
											, not_identificador
											, not_nodo
											, not_descripcion
											, not_estatus
											, not_fecha
											, not_link_BPRO
											, not_adjunto
											, not_adjunto_tipo
											, not_agrupacion
											, idEmpresa
											, idSucursal
											, idDepartamento
											)
							VALUES			( 
											  1
											, 1
											, @idComprobacion
											, ''
											, @not_descripcion
											, 2
											, GETDATE()
											, @link_BPRO
											, @not_Adjunto
											, @not_AdjuntoTipo
											, @not_Agrupacion
											, NULL
											, NULL
											, 0
											)

						SET @idNot  = @@IDENTITY
						INSERT INTO [dbo].[NOT_APROBACION]
								   ([not_id]
								   ,[apr_nivel]
								   ,[apr_visto]
								   ,[emp_id]
								   ,[apr_fecha]
								   ,[apr_estatus]
								   ,[apr_escalado])
							 VALUES
								   (@idNot
								   ,0
								   ,NULL
								   ,@emp_id
								   ,GETDATE()
								   ,1
								   ,0)
						SET @idAprobacion = SCOPE_IDENTITY()

SELECT  @idNot not_id, 1 success, 1 result , 'message' = 'La operación se realizó con exito.' , @idAprobacion apr_id, @tipoNotificacion enviaNoti,
@correo correo, @link_BPRO linkBPRO, @idComprobacionVale idComprobacionVale, 'Solicitud de Aprobación de Factura' as [subject]
END
ELSE
BEGIN
select 1 result, @tipoNotificacion enviaNoti
END

END
go

