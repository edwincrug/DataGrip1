-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 16/10/2015
-- Description: Stored que recupera las sucursales en base al usuario y la empresa
-- =============================================
-- [SEL_SUCURSALES_SP] 
CREATE PROCEDURE [dbo].[SEL_SUCURSALES_SP] 
		@idempleado   int = 0,
		@idempresa	  int = 0

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	SELECT    DISTINCT S.suc_idsucursal
			, S.suc_nombre
			, S.suc_nombrecto
	FROM     ControlAplicaciones.dbo.cat_departamentos D INNER JOIN
			 ControlAplicaciones.dbo.cat_usuarios U ON D.dep_iddepartamento = U.dep_iddepartamento RIGHT OUTER JOIN
			 ControlAplicaciones.dbo.cat_sucursales S ON D.suc_idsucursal = S.suc_idsucursal
	WHERE	(S.emp_idempresa = @idempresa OR @idempresa = 0 OR @idempresa=NULL)
			--AND (U.usu_idusuario = @idempleado OR @idempleado = 0)

END TRY

BEGIN CATCH
	DECLARE @Mensaje nvarchar(max),
	@Componente nvarchar(50)='SEL_SUCURSALES_SP'
	SELECT @Mensaje= ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente,@Mensaje
END CATCH
END


go

