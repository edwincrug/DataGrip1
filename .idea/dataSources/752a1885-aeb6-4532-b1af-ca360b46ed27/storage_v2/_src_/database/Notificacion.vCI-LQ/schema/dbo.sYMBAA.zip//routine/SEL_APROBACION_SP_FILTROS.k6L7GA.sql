-- =============================================
-- Author: Alejandro Lopez Quiroz
-- Create date: 28/10/2015
-- Description:	Stored que consulta las información de las aprobaciones
--				de un empleado.
-- =============================================
-- EXECUTE [dbo].[SEL_APROBACION_SP_FILTROS] 71 , 4, 7, -1, '', ''
CREATE PROCEDURE [dbo].[SEL_APROBACION_SP_FILTROS]
	@idUsuario INT = 0,
	@idEmpresa INT = 0,
	@idSucursal INT = 0,
	@idDepartamento INT = -1,
	@fechaIni VARCHAR(10) = '',
	@fechaFin VARCHAR(10) = ''
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY

		--LQMA add 13092017
		IF(@fechaIni = '')
		   SET @fechaIni = '20000101'
		IF(@fechaFin = '') 
		   SET @fechaFin = CONVERT(VARCHAR(8),GETDATE(),112)

		SELECT    N.not_id AS id
				 ,A.apr_id as idAprobacion
				 ,@idUsuario as idEmpleado
				--, ISNULL(eve.emp_id, 0) as idEmpleado 				
				--,eve.emp_id AS idEmpleado					 	
				, CASE N.not_agrupacion  
					WHEN 0 THEN U.usu_idusuario 
					ELSE sap.usu_idusuario
					END AS idSolicitante
				, CASE N.not_agrupacion  
					WHEN 0 THEN ISNULL(U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno, '')
					ELSE ISNULL(sap.usu_nombre + ' ' + sap.usu_paterno + ' ' + sap.usu_materno, '')
					END AS solicitante
				, ISNULL(UAP.usu_nombre + ' ' + UAP.usu_paterno + '  ' + UAP.usu_materno, '') AS aprobador
				, N.not_tipo_proceso AS tipoProceso
				, N.not_nodo AS etapaProceso
				--, ISNULL(S.suc_nombre, 'N/A') as agencia 
				, CASE WHEN S.suc_nombre IS NOT NULL THEN S.suc_nombre ELSE  ISNULL(SC.suc_nombre, 'N/A') END  AS agencia
				, ISNULL(D.dep_nombre, 'N/A')  as departamento								
					
				--Valida las decripciones de la Agrupacion 
					,CASE  N.not_agrupacion 
						WHEN 0 THEN (CASE WHEN N.not_identificador != '' THEN N.not_identificador ELSE 'Alerta' END) 
						WHEN 1 THEN 'L-' + N.not_identificador 
						WHEN 2 THEN (select 'Flotilla: ' + flo_nombreflotilla + ' ['+ CONVERT(varchar(max),flo_cantidad) + '] ' as flt_nombre FROM dbo.Flotilla_Cuentasxpagar WHERE flo_idempresa = [dbo].[splitCadena_fn](N.not_identificador,'|',1) AND flo_idsucursal =  [dbo].[splitCadena_fn](N.not_identificador,'|',2) AND flo_numeroflotilla= [dbo].[splitCadena_fn](N.not_identificador,'|',3))
						--WHEN 2 THEN (select 'Flotilla: ' + flo_nombreflotilla + ' ['+ CONVERT(varchar(max),flo_cantidad) + '] ' as flt_nombre FROM dbo.Flotilla_Cuentasxpagar WHERE flo_numeroflotilla=N.not_identificador )END AS identificador --LQMA COMENTADO 13072016					
	
						WHEN 5 THEN 'Aprobación de presupuesto: '+N.not_identificador -- Para notificaciones de presupuesto encabezado
						WHEN 6 THEN 'Aprobación adicional presupuesto: '+N.not_identificador --Para notificaciones del detalle del presupuesto
						WHEN 7 THEN 'Cotización: '+N.not_identificador --Para notificaciones de cotización
						WHEN 8 THEN 'Sin anticipo: '+N.not_identificador --Para notificaciones de anticipo
						WHEN 9 THEN 'Solicitud de Cancelación: '+N.not_identificador --Para notificaciones de anticipo
						WHEN 10 THEN 'Solicitud de cambio de inventario VIN : ' + N.not_identificador --LQMA add 06072017 inventario
						WHEN 11 THEN 'Solicitud de desapartado de unidad, Orden: ' + N.not_identificador --LQMA add 06072017 inventario
						WHEN 12 THEN 'Solicitud de desapartado de unidad, Número de Serie: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'
						WHEN 13 THEN 'Solicitud de Conceptos Adicionales de la Cotizacion: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'
						WHEN 14 THEN 'Solicitud de PLAN PISO - Valida Conciliación: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'	
						WHEN 15 THEN 'Solicitud de PLAN PISO - Cancela Conciliación: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'	
						WHEN 16 THEN 'Traspasos entre financiera, cambio de fecha promesa de pago: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'	
						WHEN 17 THEN 'Solicitud de Cotización de Unidad: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'	
						WHEN 18 THEN 'Solicitud de Revisión de Lote: ' + N.not_identificador --Para revisiones de lotes de pago	
						WHEN 19 THEN 'Solicitud de Cancelacion CC: ' + N.not_identificador --Cancelacion CC
						WHEN 20 THEN 'Solicitud de Notificación de Prueba: ' + N.not_identificador --Nuevas notificaciones
						WHEN 21 THEN 'Autorización de porcentaje de utilidad: ' + N.not_identificador --Nuevas notificaciones
						WHEN 22 THEN 'Autorización de crédito: ' + N.not_identificador --Nuevas notificaciones
						WHEN 23 THEN 'Autorización de Cuentas Bancarias: ' + N.not_identificador --Nuevas notificaciones
						WHEN 24 THEN 'Autorización de Crédito MPI: ' + N.not_identificador --Nuevas notificaciones
						WHEN 25 THEN 'Autorización de Crédito Comite: ' + N.not_identificador --Nuevas notificaciones
						WHEN 26 THEN 'Autorización de Devolución: ' + N.not_identificador --Notificaciones para las devoluciones
						WHEN 27 THEN 'Autorización de Devolución Comite: ' + N.not_identificador --Notificaciones para las devoluciones del comite
						WHEN 28 THEN 'Autorización de Apartado de Unidad: ' + N.not_identificador --Notificacion de Flotillas para el apartado de unidades
						WHEN 34 THEN 'Solicitud de autorización de plantilla : ' + N.not_identificador --Gastos recurrentes
						WHEN 35 THEN 'Solicitud de finalización de plantilla : ' + N.not_identificador --Finalización Gastos recurrentes
						WHEN 38 THEN 'Aprobar Cotización de Flotillas: '+ N.not_identificador
						WHEN 39 THEN 'Aprobación de Cargo Interno a Cotización de Flotillas: ' + N.not_identificador 
						WHEN 30 THEN 'Autorización Anticipo de Gastos: ' + N.not_identificador --Gastos de Viaje Nuevas notificaciones
						WHEN 31 THEN 'Autorización de venta de traslados por debajo del margen' + N.not_identificador --Flotillas: Notificacion para aprobar venta de traslados por debajo del costo
						WHEN 32 THEN 'Autorización de Fondo Fijo: ' + N.not_identificador --Nuevas notificaciones
						WHEN 37 THEN 'Autorización de Vale: ' + N.not_identificador --Notificaciones para vales 
						WHEN 40 THEN 'Autorización Vale Evidencia de Fondo Fijo: ' + N.not_identificador 
						WHEN 41 THEN 'Autorización de Mas Vale Evidencia de Fondo Fijo: ' + N.not_identificador 
						WHEN 42 THEN 'Cierre de Fondo Fijo: ' + N.not_identificador 
						WHEN 45 THEN 'Autorización CC sin Presupuesto: ' + N.not_identificador 
						WHEN 46 THEN 'Solicitud CC sin Presupuesto: ' + N.not_identificador 
						WHEN 47 THEN 'Solicitud de aprobación de compra: ' + N.not_identificador 
						WHEN 48 THEN 'Solicitud de aprobación de compra: ' + N.not_identificador 
						WHEN 49 THEN 'Solicitud de aprobación de estudio de mercado: ' + N.not_identificador 
						WHEN 60 THEN 'Reembolso de Fondo Fijo Finanzas 2: ' + N.not_identificador 
						WHEN 61 THEN 'Reembolso de Fondo Fijo Finanzas 3: ' + N.not_identificador  
						END AS identificador  --LQMA ADD 13072016
				, N.not_fecha AS fecha
				, N.not_identificador 
				, SUBSTRING(N.not_descripcion, 1, 43) + '...' AS descripcionCorta
				, N.not_descripcion AS descripcionLarga
				,CASE WHEN N.not_agrupacion IN (5,6,7,8) THEN N.not_adjunto ELSE N.not_link_BPRO END AS link 
				-- N.not_link_BPRO AS link --Antes de realizar la modificacionpara poner el link de los agrupacion 5,6,7
				, N.not_adjunto AS adjunto
				, N.not_adjunto_tipo AS tipoAdjunto
				, CASE WHEN not_link_BPRO IS NULL 
					THEN 2 
					ELSE 1 END AS modalidadAdjunto
				, CASE A.apr_escalado	
					WHEN -1 THEN 3 
					ELSE N.not_tipo END AS tipoNotificacion
				, (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id) AS chat
				, N.not_agrupacion AS agrupacion
				, 0 as correoEnviado
				, A.apr_escalado as escalado
				, N.not_estatus AS estatus
				, CASE ISNULL(A.apr_visto,0) WHEN 0 THEN 0 ELSE 1 END as estado
				, N.not_estatus as aprobacion
				, AR.nar_comentario as comentario 
				,CONVERT(VARCHAR(16), nar_fecha,120) as fechaAprobacion
				--, AR.nar_fecha as fechaAprobacion
				--, S.emp_idempresa AS idEmpresa
				--, S.suc_idsucursal AS idSucursal
				, CASE WHEN S.emp_idempresa IS NOT NULL THEN S.emp_idempresa ELSE  SC.emp_idempresa END  AS idEmpresa
				, CASE WHEN S.suc_idsucursal IS NOT NULL THEN S.suc_idsucursal ELSE  SC.suc_idsucursal END  AS idSucursal	
				, D.dep_iddepartamento as idDepartamento				
		FROM	
				dbo.NOT_APROBACION AS A 				
				LEFT JOIN dbo.NOT_APROBACION_RESPUESTA AS AR ON A.apr_id = AR.apr_id 
				LEFT JOIN dbo.NOT_NOTIFICACION AS N ON N.not_id= AR.not_id
				LEFT JOIN dbo.NOT_APROBACION AS ema ON ema.not_id = N.not_id AND ema.apr_escalado = -1
				LEFT JOIN dbo.NOT_APROBACION AS eve ON eve.not_id = N.not_id AND eve.emp_id = @idUsuario 
				LEFT JOIN dbo.OrdenesdeCompra AS OC ON OC.oce_folioorden = N.not_identificador
				LEFT JOIN dbo.BPRO_Sucursales AS S ON S.suc_idsucursal= OC.oce_idsucursal
				LEFT JOIN dbo.BPRO_Departamentos AS D ON  D.dep_iddepartamento =  OC.[oce_iddepartamento]	
				LEFT JOIN dbo.BPRO_Usuarios AS U ON U.usu_idusuario = OC.oce_idusuario 
				LEFT JOIN dbo.BPRO_Usuarios AS UAP ON UAP.usu_idusuario = A.emp_id 
				LEFT JOIN dbo.BPRO_Usuarios AS sap ON sap.usu_idusuario = ema.emp_id
				LEFT JOIN dbo.BPRO_Sucursales AS SC ON  SC.suc_idsucursal= N.idSucursal

		WHERE   N.not_estatus in(3,4,5,6) AND A.emp_id = CAST(@idUsuario AS INT) --14/08/2018 Se agrega el estatus 6 debido a que las que estan en revision deberian de verse en completadas no en nuevas 
				--AND ((N.not_agrupacion = 3 AND A.apr_estatus > 1) OR (N.not_agrupacion != 3))  --ADD LQMA muestra notificaciones alertas
				--FAL original WHERE   N.not_estatus in(3,4,5)
				--AND	((OC.oce_idempresa = @idEmpresa) OR (@idEmpresa = 0))
				AND	((OC.oce_idempresa = @idEmpresa) OR ((N.idEmpresa = @idEmpresa) OR (@idEmpresa = 0)))
				--AND ((OC.oce_idsucursal = @idSucursal) OR (@idSucursal = 0))
				AND	((OC.oce_idsucursal = @idSucursal) OR ((N.idSucursal = @idSucursal) OR (@idSucursal = 0)))
				AND((OC.oce_iddepartamento = @idDepartamento) OR (@idDepartamento = -1)) 
			    AND CONVERT(DATE,REPLACE(N.not_fecha,'-',''),105) BETWEEN CONVERT(DATE,@fechaIni) AND CONVERT(DATE,@fechaFin)
				--AND N.not_fecha > DATEADD(DD,-15,GETDATE()) --LQMA ADD para reducir el numero de aprobadas.
		ORDER BY N.not_fecha DESC

	END TRY
	  BEGIN CATCH
		  DECLARE @Mensaje  nvarchar(max),
		  @Componente nvarchar(50) = 'SEL_APROBACION_SP'
		  SELECT @Mensaje = ERROR_MESSAGE()
		  EXECUTE INS_ERROR_SP @Componente, @Mensaje; 

	  END CATCH
END
go

