-- =============================================
-- Author: Genaro Mora Valencia
-- Create date: 12/03/2015
-- Modified date: 05/11/2015
-- Description:	INS_APROBACION_FLOTILLA_SP Inserta las notificacione de aprobación de flotillas
-- =============================================
-- execute [INS_APROBACION_FLOTILLA_SP] 1, '2|4|9', 1, 'Solicitud de Autorizacion de la Flotilla: 9 prueba notificacion2', 1, '', '9_Flotilla.pdf', 'pdf', 15, 2

CREATE PROCEDURE [dbo].[INS_APROBACION_FLOTILLA_SP]
	@idtipoproceso int
	,@identificador varchar(50)
	,@idnodo int
	,@descripcion varchar(500)
	,@estatus int
	,@linkBPRO varchar(MAX) = NULL
	,@adjunto varchar(MAX) = NULL
	,@idtipoadjunto	varchar(500)
	,@solicitante numeric(18,0) 
	,@aprobador	numeric(18,0)  
AS
BEGIN

	SET NOCOUNT ON;
-- inserta una notificación de tipo aprobación

		INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	    VALUES (10,'INS_APROBACION_FLOTILLA_SP @folio: ' + @identificador ,GETDATE())
		--LQMA 05070217
		BEGIN TRANSACTION TRAN_APROBACION_FLOTILLAS

BEGIN TRY

		IF EXISTS(SELECT NOT_ID FROM NOT_NOTIFICACION WHERE NOT_IDENTIFICADOR = @identificador)
			BEGIN
					DECLARE @idEstatus INT = 0
					SELECT @idEstatus = NOT_ESTATUS FROM NOT_NOTIFICACION WHERE NOT_IDENTIFICADOR = @identificador 

					INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
					VALUES (10,'INS_APROBACION_FLOTILLA_SP @folio: ' + @identificador + ' .Se volvio a enviar solicitud de autorizacion flotilla, no se inserto, la flotilla ya existe con estatus: ' + CONVERT(VARCHAR(10),@idEstatus) ,GETDATE())	
				
			END
		ELSE
			BEGIN
						-- Obtiene la descripción de la tabla cxp_flotilla.	

							--LQMA 13072016 ADD buscar por empresa, sucursal y consecutivo de flotilla
							---------------***************************************************************************
							DECLARE @cadena VARCHAR(100) = @identificador, @idEmpresa VARCHAR(10) = '', @idSucursal VARCHAR(10) = '', @idConsecutivo VARCHAR(10) = ''
		
							SELECT @idEmpresa = SUBSTRING(@cadena,1,CHARINDEX('|',@cadena)-1)
							SELECT @cadena = SUBSTRING(@cadena,CHARINDEX('|',@cadena)+1,100)

							SELECT @idSucursal = SUBSTRING(@cadena,1,CHARINDEX('|',@cadena)-1)
							SELECT @cadena = SUBSTRING(@cadena,CHARINDEX('|',@cadena)+1,100)	
		
							SELECT @idConsecutivo = SUBSTRING(@cadena,1,100)
							---------------***************************************************************************
							--LQMA 13072016 original
							--select @descripcion = FL.flo_modelo  from  [dbo].[Flotilla_Cuentasxpagar] FL WHERE FL.flo_idflotilla=@identificador
							--LQMA 13072016 ADD buscar por empresa, sucursal, consecutivo
							--LJBA 20160815 se quita el alías.
		
							--SELECT @descripcion = FL.flo_modelo  from  [dbo].[Flotilla_Cuentasxpagar] FL WHERE FL.flo_numeroflotilla = @idConsecutivo
																										 --AND FL.flo_idempresa = @idEmpresa
																										 --AND FL.flo_idsucursal = @idSucursal
							/*03032017 LQMA--  se comento ya que el campo esta vacio
							SELECT @descripcion = Isnull(FL.flo_modelo,' ')  from [cuentasxpagar].[dbo].[cxp_flotillas] FL WHERE FL.flo_numeroflotilla = @idConsecutivo
																										 AND FL.flo_idempresa = @idEmpresa			
																										 AND FL.flo_idsucursal = @idSucursal		
							*/

							INSERT INTO NOT_NOTIFICACION (not_tipo
							, not_tipo_proceso
							, not_identificador
							, not_nodo
							, not_descripcion
							, not_estatus
							, not_fecha
							, not_link_BPRO
							, not_adjunto
							, not_adjunto_tipo
							, not_agrupacion
							,idEmpresa
							,idSucursal)
							VALUES
							( 1
							, @idtipoproceso
							, @identificador
							, @idnodo
							, @descripcion
							, @estatus
							, GETDATE()
							, @linkBPRO
							, @adjunto
							, @idtipoadjunto
							, 2
							, @idEmpresa
							, @idSucursal
							)


						DECLARE @nid_not int = @@IDENTITY;

					--Solicitante
					--LQMA  add 17062016   si aprobador = solicitante, solo se inserta aprobador
					----------------------------------
					IF(@aprobador != @solicitante) --si aprobador es diferente de solicitante, se inserta solicitante
						BEGIN
							INSERT INTO [dbo].[NOT_APROBACION]
								   ([not_id]
								   ,[apr_nivel]
								   ,[apr_visto]
								   ,[emp_id]
								   ,[apr_fecha]
								   ,[apr_estatus]
								   ,[apr_escalado])
							 VALUES
								   (@nid_not
								   ,0
								   ,NULL
								   ,@solicitante
								   ,GETDATE()
								   ,1
								   ,-1)
						END
		   
					--Aprobador
					----------------------------------
						INSERT INTO [dbo].[NOT_APROBACION]
							   ([not_id]
							   ,[apr_nivel]
							   ,[apr_visto]
							   ,[emp_id]
							   ,[apr_fecha]
							   ,[apr_estatus]
							   ,[apr_escalado])
						 VALUES
							   (@nid_not
							   ,0
							   ,NULL
							   ,@aprobador
							   ,GETDATE()
							   ,1
							   ,0)
	

					--Actualiza el estatus de la notificación a 2
					----------------------------------
						UPDATE NOT_NOTIFICACION SET not_estatus = 2 
							WHERE not_id =@nid_not
		
						--LQMA 03072017
						UPDATE NOT_APROBACION SET apr_estatus = 2 WHERE not_id = @nid_not
			END
	--LQMA 05070217
	COMMIT TRANSACTION TRAN_APROBACION_FLOTILLAS
	
	Select 0 error
	
END TRY
BEGIN CATCH

	--LQMA 05070217
	ROLLBACK TRANSACTION TRAN_APROBACION_FLOTILLAS

	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_APROBACION_FLOTILLA_SP'
	SELECT ERROR_NUMBER() error
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	
END CATCH

END
go

