-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 29/10/2015
-- Description: Recupera los datos de operación del usuario.
-- =============================================
--SEL_EMPLEADO_SP 1
CREATE PROCEDURE [dbo].[SEL_EMPLEADO_SP] 
	@idEmpleado  int = 0
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY

    SELECT  U.usu_idusuario AS idusuario
	, U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS nombre
	, U.usu_correo AS correo
	, U.dep_iddepartamento AS iddepartamento
	, D.suc_idsucursal AS idsucursal
	, S.emp_idempresa
FROM  ControlAplicaciones.dbo.cat_usuarios U INNER JOIN
      ControlAplicaciones.dbo.cat_departamentos D ON U.dep_iddepartamento = D.dep_iddepartamento INNER JOIN
      ControlAplicaciones.dbo.cat_sucursales S ON D.suc_idsucursal = S.suc_idsucursal
WHERE U.usu_idusuario = @idEmpleado OR @idEmpleado = 0

	END TRY
	BEGIN CATCH 
		DECLARE @Mensaje nvarchar(max),
		@Componente nvarchar(50)  ='SEL_EMPLEADO_SP' 
		select @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje 

	END CATCH 
END


go

