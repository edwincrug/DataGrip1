CREATE FUNCTION [dbo].[splitCadena_fn]
(
	@cadena VARCHAR(100),
	@separador VARCHAR(5),
	@posicion INT = 1
)
RETURNS VARCHAR(100)
AS
BEGIN
	
	DECLARE @aux INT = 0
	DECLARE @cadenaAux VARCHAR(50) = ''	
	
	SET @cadenaAux = @cadena

	DECLARE @idEmpresa VARCHAR(10) = '', @idSucursal VARCHAR(10) = '', @idConsecutivo VARCHAR(10) = ''
		
	IF (CHARINDEX(@separador,@cadena) > 0)
		BEGIN	
			SELECT @idEmpresa = SUBSTRING(@cadena,1,CHARINDEX(@separador,@cadena)-1)
			SELECT @cadena = SUBSTRING(@cadena,CHARINDEX(@separador,@cadena)+1,100)

			--SET @cadenaAux = @idEmpresa
	
			--IF (CHARINDEX(@separador,@cadena) > 0)
				--BEGIN
					SELECT @idSucursal = SUBSTRING(@cadena,1,CHARINDEX(@separador,@cadena)-1)
					SELECT @cadena = SUBSTRING(@cadena,CHARINDEX(@separador,@cadena)+1,100)	

					--SET @cadenaAux = @idSucursal
				--END
			--ELSE
				--BEGIN
					--SELECT @cadena = SUBSTRING(@cadena,CHARINDEX(@separador,@cadena)+1,100)	
					--SET @cadenaAux = @idSucursal
				--END
		
			--IF (CHARINDEX(@separador,@cadena) > 0)
				--BEGIN
					SELECT @idConsecutivo = SUBSTRING(@cadena,1,100)

					--SET @cadenaAux = @idConsecutivo
				--END
		
		
			IF @posicion = 1
				SET @cadenaAux = @idEmpresa

			IF @posicion = 2
				SET @cadenaAux = @idSucursal

			IF @posicion = 3
				SET @cadenaAux = @idConsecutivo
				
		END

	RETURN @cadenaAux

END
go

