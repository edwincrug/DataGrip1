--EXECUTE [dbo].[ENVIA_CORREO_NOTIFICACION_SP] 2,'lou_mald@hotmail.com','AU-AUA-VIG-UN-PF-19'
-- ======================================================================================================
-- Author: Lourdes Maldonado Sánchez
-- Create date: 02/02/2016
-- Description:	Procedimiento para enviar un correo de Notificación al Usuario sobre su autorización
-- actual y las pendientes. 
-- ======================================================================================================
CREATE PROCEDURE [dbo].[ENVIA_CORREO_NOTIFICACION_SP] 
	@apr_usu       INT = NULL,             
	@correo        NVARCHAR(100)=NULL,
	@identificador NVARCHAR(50)=NULL
	
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
			--DECLARE @correoP  NVARCHAR(100)=NULL
			--SET @correoP = '''' + @correo + ''''
			--SET @correoP = @correo
			--select @correo

			DECLARE @tableHTML  NVARCHAR(MAX)= null;

			SET @tableHTML =
				N'<H2><b>Estimado Usuari@:</b></H2>' +
				N'<H3><br> </br></H3>' +
				N'<H3><blockquote>Un gusto saludarle, el motivo de este correo es para informarle que usted esta en el flujo de Aprobacion :</blockquote></H3>' +
				CAST ( (SELECT @identificador FOR XML PATH('tr'),TYPE ) AS NVARCHAR ) +
				N'<H3>Tambien se requiere su atencion en los siguientes Folios: </H3>' +
				N'<table border="1">' +
				N'<tr><th>NOT_ID</th><th>FOLIO</th><th>FECHA_CREACION</th>' +
				CAST ( (SELECT td =N.not_id,        '',
							   td = CASE  N.not_agrupacion 	WHEN 0 THEN N.not_identificador 
					    								WHEN 1 THEN  'Lote: ' + N.not_identificador 
														WHEN 2 THEN (select 'Flotilla: ' + flo_nombreflotilla + ' ['+ CONVERT(varchar(max),flo_cantidad) + '] ' as flt_nombre FROM dbo.Flotilla_Cuentasxpagar WHERE flo_numeroflotilla=N.not_identificador)END,        '', 
							   td =N.not_fecha 											
							FROM    [Notificacion].[dbo].[NOT_APROBACION] AS A 
									LEFT JOIN dbo.NOT_NOTIFICACION AS N ON  N.not_id = A.not_id
									LEFT JOIN dbo.NOT_APROBACION   AS ema ON ema.not_id = N.not_id AND ema.apr_escalado = -1
									LEFT JOIN dbo.OrdenesdeCompra  AS OC ON OC.oce_folioorden = N.not_identificador
									LEFT JOIN ControlAplicaciones.dbo.cat_sucursales AS S ON  S.suc_idsucursal = OC.oce_idsucursal
									LEFT JOIN dbo.BPRO_Departamentos AS D ON  D.dep_iddepartamento = OC.[oce_iddepartamento] 
									LEFT JOIN dbo.BPRO_Usuarios AS U ON U.usu_idusuario = OC.oce_idusuario 
									LEFT JOIN dbo.BPRO_Usuarios AS sap ON sap.usu_idusuario = ema.emp_id
									LEFT JOIN dbo.NOT_PARAMETROS AS parametros ON parametros.par_id = 1
							WHERE   N.not_estatus in(1,2,6) 
								AND   A.emp_id = @apr_usu
								AND   (A.apr_escalado = 0 OR A.apr_escalado = -1)
							ORDER BY N.not_fecha DESC
						  FOR XML PATH('tr'), TYPE 
				) AS NVARCHAR(MAX) ) +
				N'</table>' +
				N'<H3><br> </br></H3>' +
				N'<H3>Buen dia y quedo atento a sus comentarios.</H3>' +
				N'<H3><big><em><p align="center"><font color = "002366">Aprobador_GA</font></p></em></big></H3>';

			EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'SMTPFlotilla',
				@recipients = @correo,
				@body =  @tableHTML,
				@body_format = 'HTML' ;

	END TRY

	BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'ENVIA_CORREO_NOTIFICACION_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	END CATCH
END

go

