-- ==========================================================================================
-- Author:		Arturo Rodea Victoria
-- Create date: 26/10/2015
-- Modified date: 13/01/2016  Lourdes Maldonado Sánchez(LMS)
-- Description:	INS_APROBACION_SP Inserta las notificacione de aprobación.
-- 05/11/2015: Se agrega la tabla DIG_PARAMETROS_PAGO para el pago de los lotes de órdenes.
-- ==========================================================================================
-- [INS_APROBACION_FOLIO_SP] 1, 'AU-ZM-ZAR-OT-PE-143', 1, 'Prueba de OC unitaria', 1, 'http://Prueba1', '', ''
   
CREATE PROCEDURE [dbo].[INS_APROBACION_FOLIO_SP]
	@idtipoproceso int
	,@identificador varchar(50)
	,@idnodo	int
	,@descripcion varchar(500)
	,@estatus int
	,@linkBPRO varchar(MAX) = NULL
	,@adjunto varchar(MAX) = NULL
	,@idtipoadjunto	varchar(500)	
AS
BEGIN


		DECLARE @Resultados TABLE(ID INT IDENTITY(1,1), RES INT)

		BEGIN TRANSACTION TRAN_APROBACION_FOLIOS
BEGIN TRY

    ------------------------------------------------------------------------------------------------------------------
    --LMS 15/01/2016 Agregado para que actualice el Estatus si este es 6, sino que siga el proceso normal
    ------------------------------------------------------------------------------------------------------------------
	DECLARE @cmd           varchar(512)=NULL
	DECLARE @folder        varchar(512)=NULL
	DECLARE @nombrearchivo varchar(100)=NULL --'AU-AUA-VIG-OT-PE-21'--'AU-AUA-VIG-US-PE-1' --@identificador --Folio de la Orden: 
	DECLARE @extension     varchar(5)=NULL


	IF EXISTS(SELECT NOT_ID FROM NOT_NOTIFICACION WHERE NOT_IDENTIFICADOR = @identificador AND NOT_ESTATUS NOT IN (6))
			BEGIN
					DECLARE @idEstatus INT = 0

					SELECT @idEstatus = NOT_ESTATUS FROM NOT_NOTIFICACION WHERE NOT_IDENTIFICADOR = @identificador 

					INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
					VALUES (8,'INS_APROBACION_FOLIO_SP @folio: ' + @identificador + ' .Se volvio a enviar solicitud de autorizacin, no se inserto, la orden ya existe con estatus: ' + CONVERT(VARCHAR(10),@idEstatus) ,GETDATE())
					
					SELECT 0

			END
		ELSE
			BEGIN
					IF EXISTS(SELECT NOT_ID FROM NOT_NOTIFICACION WHERE NOT_IDENTIFICADOR = @identificador AND NOT_ESTATUS = 6)
						  BEGIN
								--Update para el estatus de 6(Revision) a 2(En aprobacion) en NOT_NOTIFICACION 
								UPDATE NOT_NOTIFICACION 
								   SET not_estatus = 2 
								 WHERE not_estatus = 6  
								   AND not_identificador = @identificador 

								--Update para el estatus de 6(Revision) a 1(Pendiente) EN NOT_APROBACION
								UPDATE NOT_APROBACION
								   SET APR_ESTATUS = 1 
								 WHERE APR_ESTATUS = 6
								   AND NOT_ID = (SELECT NOT_ID 
												   FROM NOT_NOTIFICACION  
												  WHERE NOT_IDENTIFICADOR = @identificador) 

								--Elimino todos los registros de NOT_APROBACION_RESPUESTA
								DELETE
								  FROM [Notificacion].[dbo].[NOT_APROBACION_RESPUESTA] 
								 WHERE   NOT_ID = (SELECT NOT_ID 
													 FROM NOT_NOTIFICACION  
													WHERE NOT_IDENTIFICADOR = @identificador) 

								--Elimino el archivo de la ruta c:\GA_Centralizacion\CuentasXPagar\TempPdf\OrdenCompra\Orden_FOLIO.PDF
								--'c:\Archivos\GA_Centralizacion\CuentasXPagar\TempPdf\OrdenCompra\Orden_'
								begin					
								set @folder = 'C:\GA_Centralizacion\CuentasXPagar\TempPdf\OrdenCompra\Orden_'
								set @nombrearchivo = @identificador
								set @extension = '.PDF'
								set @cmd = 'del '+ @folder + @nombrearchivo + @extension	  
								--select @cmd
								EXEC MASTER..xp_cmdshell @cmd, no_output
								--select 'Termino'
								end
							SELECT 0 
					END
				------------------------------------------------------------------------------------------------------------------
				--Termina LMS 15/01/2016 
				------------------------------------------------------------------------------------------------------------------
					ELSE
						  --Procedure Original
						  BEGIN
							 INSERT INTO NOT_NOTIFICACION (not_tipo
									, not_tipo_proceso
									, not_identificador
									, not_nodo
									, not_descripcion
									, not_estatus
									, not_fecha
									, not_link_BPRO
									, not_adjunto
									, not_adjunto_tipo
									, not_agrupacion)
									VALUES
									( 1
									, @idtipoproceso
									, @identificador
									, @idnodo
									, @descripcion
									, @estatus
									, GETDATE()
									, @linkBPRO
									, @adjunto
									, @idtipoadjunto
									, 0
									)
							--Busca cuantas personas recibirán la notificación y hace el insert en la tabla de aprobaciones.
							-- 05/11/2015  Si el campo de agrupación es 1 solamente agrega 1 aprobación al usuario configurado en DIG_PARAMETROS_PAGO

								DECLARE @apr_usu1	int=0;
								DECLARE @apr_usu2	int=0;
								DECLARE @apr_usu3	int=0;
								DECLARE @nid_not	int = @@IDENTITY;
								DECLARE @departamento int;
								DECLARE @empresa	int;
								DECLARE @sucursal	int;
								DECLARE @solicitante int;
								DECLARE @tipoorden int;
								DECLARE @naprobacion numeric(18,0);				    

								SELECT @departamento = OC.oce_iddepartamento, @empresa= OC.oce_idempresa, @sucursal=OC.oce_idsucursal, @solicitante = OC.oce_idusuario, @tipoorden = [oce_idtipoorden] FROM dbo.OrdenesdeCompra OC WHERE OC.oce_folioorden = @identificador


								SELECT top 1   @apr_usu1 = Usuario_Autoriza1
											, @apr_usu2 = Usuario_Autoriza2
											, @apr_usu3 = Usuario_Autoriza3 
								FROM  [Centralizacionv2].dbo.DIG_ESCALAMIENTO
								WHERE Nodo_Id = @idnodo
								AND Proc_Id = @idtipoproceso	
								AND emp_idempresa= @empresa	
								AND suc_idsucursal= @sucursal
								AND dep_iddepartaamento = @departamento
								AND tipo_idtipoorden = @tipoorden
								AND Nivel_Escalamiento = 0
								print 'empieza'
								print @idnodo 
								print @idtipoproceso
								print @empresa
								print @sucursal
								print @departamento
								print @tipoorden
								print 'termina'

								--Validar si al menos existe un usuario aprobador o sea si alguna de las variables <> 0
								--En caso afirmativo Actualizar NOT_NOTIFICACION = 2 antes de insertar aprobaciones
								/*
								LQMA ADD 26092016 obtiene responsable cuando compras = otros
								*/

								IF (SELECT TOrden.[dep_nombrecto]
									FROM [cuentasxpagar].[dbo].[cxp_ordencompra] OC 
									JOIN [ControlAplicaciones].[dbo].[cat_departamentos] TOrden ON  OC.oce_iddepartamento = TOrden.[dep_iddepartamento]
									WHERE OC.oce_folioorden = @identificador) = 'OT'
								BEGIN							
										DECLARE @base VARCHAR(50) = ''
	
										SELECT @empresa = oce_idempresa, @sucursal = oce_idsucursal 
										FROM [cuentasxpagar].[dbo].[cxp_ordencompra] 
										WHERE oce_folioorden = @identificador --oce_idempresa, oce_idsucursal

										DECLARE @IntVariable int;  
										DECLARE @SQLString nvarchar(500);  
										DECLARE @ParmDefinition nvarchar(500);  
										DECLARE @poc_area varchar(30); 

										/*
										SELECT @base = nombre_base FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
										INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
										INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON BASEMP.catsuc_nombrecto = SUC.suc_nombrecto
										WHERE BASEMP.tipo = 1
										AND EMP.emp_idempresa = @empresa
										AND SUC.emp_idempresa = @empresa 
										AND SUC.suc_idsucursal = @sucursal*/
										--LQMA 03082017
										/*******/
										DECLARE @ipServer VARCHAR(20) = '', @ipLocal VARCHAR(20) = ''

										SELECT TOP 1 @ipLocal=local_net_address 
										FROM sys.dm_exec_connections c
										ORDER BY local_net_address DESC
										/*******/
										--LQMA 03082017

										SELECT @base = nombre_base , @ipServer = ip_servidor
										FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
										WHERE BASEMP.tipo = 1   	  
												AND BASEMP.emp_idempresa = @empresa
												AND BASEMP.suc_idsucursal = @sucursal
												AND BASEMP.estatus = 1
							
										/*******/
										--LQMA 03082017
										IF(ltrim(rtrim(@ipLocal))=rtrim(ltrim(@ipServer)))
											SET @ipServer = ''
										ELSE
											SET @ipServer = '[' + @ipServer + '].' 								

										SET @SQLString = N'select @poc_areaOUT = poc_area from '+ @ipServer +'[' + @base + '].[dbo].[con_pedotros] where poc_folioorden= ''' + @identificador + '''';
										SET @ParmDefinition = N'@poc_areaOUT varchar(30) OUTPUT';

										print @SQLString

										EXECUTE sp_executesql @SQLString, @ParmDefinition, @poc_areaOUT=@poc_area OUTPUT;  
										--SELECT @poc_area;

										print 'paso 2'

										SELECT @apr_usu1 = usuario_autoriza1 
										FROM Centralizacionv2..DIG_ESCALAMIENTO_AREA_AFECT 
										WHERE emp_idempresa=@empresa
											  AND suc_idsucursal=@sucursal 
											  AND par_idenpara=@poc_area
											  print 'poc_area'
											  print @poc_area
								END								
					
								--LQMA 18042017 ADD cuando es REFACCIONES, obtenemos el primer autorizador de la tabla cuentasxpagar..cxp_detallerefacciones,
								-- del campo ref_autoriza, si es nulo, dejamos de dig_escalamiento, solicitado por LUIS BONNET
								IF (SELECT TOrden.[dep_nombrecto]
									FROM [cuentasxpagar].[dbo].[cxp_ordencompra] OC 
									JOIN [ControlAplicaciones].[dbo].[cat_departamentos] TOrden ON  OC.oce_iddepartamento = TOrden.[dep_iddepartamento]
									WHERE OC.oce_folioorden = @identificador) = 'RE'
								BEGIN												     
										IF EXISTS(SELECT TOP(1) ref_autoriza FROM cuentasxpagar..cxp_detallerefacciones WHERE oce_folioorden = @identificador)
											BEGIN
													IF (SELECT TOP(1) ref_autoriza FROM cuentasxpagar..cxp_detallerefacciones WHERE oce_folioorden = @identificador)  IS NOT NULL
													BEGIN
														SELECT TOP(1) @apr_usu1 = ref_autoriza FROM cuentasxpagar..cxp_detallerefacciones WHERE oce_folioorden = @identificador
													END
											END
								END					
							
								DECLARE @aprobadorInsertado INT = 0 --LQMA 20042017 ADD bandera para solo insertar al primer aprobador
				
								IF(@apr_usu1 <>0 OR @apr_usu2 <>0 OR @apr_usu3<>0)		
									BEGIN
											PRINT ('CENTO A VALIDAR  ' + convert(varchar, @apr_usu1)+convert(varchar, @apr_usu2)+convert(varchar, @apr_usu3))
							
													print('Usuarios a notificar ' + convert(varchar, @apr_usu1)+ ', ' +  convert(varchar, @apr_usu2) + ', ' + convert(varchar, @apr_usu3))
													print('Notificación ' + convert(varchar, @nid_not))								
								
													--Actualiza el estatus de la notificación a 2
													UPDATE NOT_NOTIFICACION SET not_estatus = 2 WHERE not_id =@nid_not								
													
													------- INSERTAR NOTIFICACION DEL SOLICITANTE

													--LQMA  add 17062016   si aprobador = solicitante, solo se inserta aprobador
													----------------------------------
													IF((@solicitante != @apr_usu1) AND (@solicitante != @apr_usu2) AND (@solicitante != @apr_usu3)) --si aprobador es diferente de solicitante, se inserta solicitante
													BEGIN
													----DECLARE @naprobacion numeric(18,0);
															INSERT INTO [dbo].[NOT_APROBACION]
																([not_id]
																,[apr_nivel]
																,[apr_visto]
																,[emp_id]
																,[apr_fecha]
																,[apr_estatus]
																--,[apr_comentario]
																,[apr_escalado])
															VALUES
																(@nid_not
																,0
																,0
																,@solicitante
																,GETDATE()
																,1
																--,''
																,-1)

																print 'Inserte @solicitante: ' + convert(varchar, @solicitante)
													END	
												----------------------------------
												IF @apr_usu1 > 0 --AND @apr_usu1 NOT IN (@apr_usu2,@apr_usu3)  --LQMA add 17032017 para que no repita los usuarios de aprobadores (@apr_usu2,@apr_usu3)
													BEGIN
															INSERT INTO [dbo].[NOT_APROBACION]
																	([not_id]
																	,[apr_nivel]
																	,[apr_visto]
																	,[emp_id]
																	,[apr_fecha]
																	,[apr_estatus]
																	--,[apr_comentario]
																	,[apr_escalado])
																VALUES
																	(@nid_not
																	,0
																	,0
																	,@apr_usu1
																	,GETDATE()
																	,1
																	--,''
																	,0)
																	print 'Inserte @apr_usu1: ' + convert(varchar, @apr_usu1) 

																	SET @aprobadorInsertado = 1 --LQMA 20042017 ADD bandera para solo insertar al primer aprobador
													END

												IF @apr_usu2 > 0 AND @apr_usu2 NOT IN (@apr_usu1) AND @aprobadorInsertado = 0 --LQMA 20042017 ADD bandera para solo insertar al primer aprobador
													BEGIN
															INSERT INTO [dbo].[NOT_APROBACION]
																	([not_id]
																	,[apr_nivel]
																	,[apr_visto]
																	,[emp_id]
																	,[apr_fecha]
																	,[apr_estatus]
																	--,[apr_comentario]
																	,[apr_escalado])
																VALUES
																	(@nid_not
																	,0
																	,0
																	,@apr_usu2
																	,GETDATE()
																	,1
																	--,''
																	,0)

																	SET @aprobadorInsertado = 1 --LQMA 20042017 ADD bandera para solo insertar al primer aprobador
																	print 'Inserte @apr_usu2: ' + convert(varchar, @apr_usu2)
													END

												IF @apr_usu3 > 0 AND @apr_usu3 NOT IN (@apr_usu1,@apr_usu2) AND @aprobadorInsertado = 0 --LQMA 20042017 ADD bandera para solo insertar al primer aprobador
													BEGIN
															INSERT INTO [dbo].[NOT_APROBACION]
																	([not_id]
																	,[apr_nivel]
																	,[apr_visto]
																	,[emp_id]
																	,[apr_fecha]
																	,[apr_estatus]
																	--,[apr_comentario]
																	,[apr_escalado])
																VALUES
																	(@nid_not
																	,0
																	,0
																	,@apr_usu3
																	,GETDATE()
																	,1
																	--,''
																	,0)

																	SET @aprobadorInsertado = 1 --LQMA 20042017 ADD bandera para solo insertar al primer aprobador
																	print 'Inserte @apr_usu3: ' + convert(varchar, @apr_usu3)
													END

													--Actualizamos el estatus del nodo
													--UPDATE dbo.DIG_EXP_NODO SET Nodo_Estatus_Id = 3 where folio_operacion = @identificador AND nodo_id = 1 and proc_id = @idtipoproceso 
													--UPDATE dbo.DIG_EXP_NODO SET Nodo_Estatus_Id = 2 where folio_operacion = @identificador AND nodo_id = 2 and proc_id = @idtipoproceso 

													print 'INS_CIERRA_NODO_SP'

													INSERT INTO @Resultados --LQMA 31052017 guarda resultado en tabla temporal
													EXECUTE  Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
													   @proc_Id = @idtipoproceso
													  ,@nodo_Id = 1
													  ,@folio_Operacion = @identificador

													UPDATE NOT_NOTIFICACION SET not_estatus = 2 WHERE not_id = @nid_not   --Comentar 13/01/2016
				
							SELECT 0  --En Estatus <> 6 y cambia
							END											
					END
		END
			--Termina Procedure Original
		COMMIT TRAN TRAN_APROBACION_FOLIOS
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())

		ROLLBACK TRAN TRAN_APROBACION_FOLIOS
	DECLARE @Mensaje  NVARCHAR(max),
	@Componente NVARCHAR(50) = '[INS_APROBACION_FOLIO_SP]'
	--SELECT ERROR_NUMBER() error
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje
END CATCH
END

go

