
CREATE  PROCEDURE [dbo].[SEL_USUARIOS_NOTIFICACION_SP] 
 @idTipoNotificacion INT 
,@idEmpresa INT = NULL
,@idSucursal INT = NULL
,@idDepartamento INT = NULL

AS
BEGIN


--DECLARE  @identificador NVARChAR(50)
--		,@idTipoNotificacion INT = 1
--		,@idEmpresa INT = 4
--		,@idSucursal INT = 6
--		,@idDepartamento INT = NULL

	DECLARE @autorizadorMultiEmpresa INT 
			 


	SELECT @autorizadorMultiEmpresa = ISNULL(autorizadorMultiEmpresa,0) FROM [Centralizacionv2].[dbo].[DIG_TIPO_NOTIFICACION]  WHERE idTipoNotificacion = @idTipoNotificacion

	SELECT descripcion   FROM [Centralizacionv2].[dbo].[DIG_TIPO_NOTIFICACION]  WHERE idTipoNotificacion = @idTipoNotificacion




	IF(@autorizadorMultiEmpresa = 0)
	BEGIN
		IF((@idEmpresa IS NULL OR @idEmpresa = 0) AND (@idSucursal IS NULL OR @idSucursal = 0) )
		BEGIN
			SELECT -1 success ,'Favor de Agregar la Empresa y Sucursal' as msg
		END
		ELSE
		BEGIN
				SELECT usu_idusuario idUsuario, usu_nombre+' '+usu_paterno+' '+usu_materno nombre, 'Autorizador' tipo, nivel_escalamiento, usu_telefono telefono , usu_correo correo
				FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT F 
				INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON
				F.usuario_autoriza  = U.usu_idusuario
				WHERE  idTipoNotificacion = @idTipoNotificacion
				AND F.idEmpresa = @idEmpresa AND F.idSucursal = @idSucursal
				UNION ALL
				SELECT usu_idusuario idUsuario, usu_nombre+' '+usu_paterno+' '+usu_materno nombre, 'Mancomunado' tipo,0 nivel_escalamiento, usu_telefono telefono, usu_correo correo
				FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO F 
				INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON
				F.usuario_mancomunado  = U.usu_idusuario
				WHERE  idTipoNotificacion = @idTipoNotificacion
				
		END
	END
	ELSE
	BEGIN
				SELECT usu_idusuario idUsuario, usu_nombre+' '+usu_paterno+' '+usu_materno nombre, 'Autorizador' tipo, nivel_escalamiento, usu_telefono telefono , usu_correo correo
				FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT F 
				INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON
				F.usuario_autoriza  = U.usu_idusuario
				WHERE  idTipoNotificacion = @idTipoNotificacion
				UNION ALL
				SELECT usu_idusuario idUsuario, usu_nombre+' '+usu_paterno+' '+usu_materno nombre, 'Mancomunado' tipo,0 nivel_escalamiento, usu_telefono telefono , usu_correo correo
				FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO F 
				INNER JOIN ControlAplicaciones.dbo.cat_usuarios U ON
				F.usuario_mancomunado  = U.usu_idusuario
				WHERE  idTipoNotificacion = @idTipoNotificacion
	
	END

END

go

