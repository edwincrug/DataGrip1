-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_APROBACION_PEDIDOS_SIN_ANTICIPO_SP]
	@idtipoproceso int
	,@identificador varchar(50) 
	,@descripcion varchar(500)
	,@estatus int
	--,@linkBPRO varchar(MAX) = NULL
	--,@adjunto varchar(MAX) = NULL 
	--,@idtipoadjunto	varchar(500)
	--,@solicitante numeric(18,0) 
	,@aprobador	numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;
	-- Inserta una notificación de tipo aprobación
		BEGIN TRY

		IF EXISTS(SELECT not_id FROM NOT_NOTIFICACION WHERE NOT_IDENTIFICADOR = @identificador AND NOT_ESTATUS NOT IN (6) AND not_tipo_proceso = 8)
			BEGIN
					DECLARE @idEstatus INT = 0

					SELECT @idEstatus = NOT_ESTATUS FROM NOT_NOTIFICACION WHERE NOT_IDENTIFICADOR = @identificador 

					INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
					VALUES (8,'INS_APROBACION_PEDIDOS_SIN_ANTICIPO_SP @folio: ' + @identificador + ' .Se volvio a enviar solicitud de autorizacion sin anticipo, no se inserto, la orden ya existe con estatus: ' + CONVERT(VARCHAR(10),@idEstatus) ,GETDATE())
					
					SELECT 0 error

			END
		ELSE
			BEGIN

						DECLARE @idsolicitante numeric(18,0)
						SELECT @idsolicitante=ucu_idusuarioalta FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE ucu_foliocotizacion =@identificador
		
						INSERT INTO NOT_NOTIFICACION (not_tipo
						, not_tipo_proceso
						, not_identificador
						, not_nodo
						, not_descripcion
						, not_estatus
						, not_fecha
						, not_link_BPRO
						, not_adjunto
						, not_adjunto_tipo
						, not_agrupacion)
						VALUES
						( 1
						, @idtipoproceso
						, @identificador
						,''
						, @descripcion
						, @estatus
						, GETDATE()
						, null--@linkBPRO
						, ''--@adjunto
						, ''--@idtipoadjunto
						, 8
						)


					DECLARE @nid_not int = @@IDENTITY;

				--Solicitante
				--LQMA  add 17062016   si aprobador = solicitante, solo se inserta aprobador
				----------------------------------
				IF(@aprobador != @idsolicitante) --si aprobador es diferente de solicitante, se inserta solicitante
					BEGIN
						INSERT INTO [dbo].[NOT_APROBACION]
							   ([not_id]
							   ,[apr_nivel]
							   ,[apr_visto]
							   ,[emp_id]
							   ,[apr_fecha]
							   ,[apr_estatus]
							   ,[apr_escalado])
						 VALUES
							   (@nid_not
							   ,0
							   ,NULL
							   ,@idsolicitante
							   ,GETDATE()
							   ,1
							   ,-1)
					END
		   
				--Aprobador
				----------------------------------
					INSERT INTO [dbo].[NOT_APROBACION]
						   ([not_id]
						   ,[apr_nivel]
						   ,[apr_visto]
						   ,[emp_id]
						   ,[apr_fecha]
						   ,[apr_estatus]
						   ,[apr_escalado])
					 VALUES
						   (@nid_not
						   ,0
						   ,NULL
						   ,@aprobador
						   ,GETDATE()
						   ,1
						   ,0)
	

				--Actualiza el estatus de la notificación a 2
				----------------------------------
					UPDATE NOT_NOTIFICACION SET not_estatus = 2 
						WHERE not_id =@nid_not
		
					--EXECUTE [dbo].[INS_APROBACION_PRESUPUESTO_DETALLE_SP] @idtipoproceso,@identificador,@descripcion,@estatus,@linkBPRO,@adjunto,@idtipoadjunto,@solicitante,@aprobador
					Select 0 error
			END
	
	END TRY
	BEGIN CATCH
		PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'INS_APROBACION_PEDIDOS_SIN_ANTICIPO_SP'
		SELECT ERROR_NUMBER() error
		SELECT @Mensaje = ERROR_MESSAGE()
		EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	
	END CATCH
END
go

