CREATE PROCEDURE [dbo].[APR_INS_AGRUP7_SP] 
	 @idAprobacion INT = 0
	,@folio VARCHAR(100) = ''
	,@respuesta   INT = 0 
	,@idnotificacion INT = 0
	,@observacion VARCHAR(MAX) = ''	
	,@idUsuario INT = 0
AS
BEGIN

		INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	    VALUES (7,'APR_INS_AGRUP7_SP inicia @folio: ' + @folio ,GETDATE())

		DECLARE @valor DECIMAL(18,4) = 0, @mensajeRollback VARCHAR(100) = ''

	SET NOCOUNT ON;	
		BEGIN TRAN TRAN_APR_INS_AGRUP7

	BEGIN TRY

			DECLARE @idEstatus INT = 0, @mensaje VARCHAR(500) = '', @cec_idestatuscotiza INT = 0, @estatusNotificacion INT = 0, @resp VARCHAR(30) = ''

			IF(@respuesta=1)
				BEGIN
					SELECT @cec_idestatuscotiza = 17, @estatusNotificacion = 3,@mensaje = 'Se autorizo CC de la orden : ' + @folio, @resp = 'Aprobado: '					
				END
			ELSE
				BEGIN
					SELECT @cec_idestatuscotiza = 14, @estatusNotificacion = 4,@mensaje = 'Se rechazo CC la orden : ' + @folio, @resp = 'Rechazado: '
				END

			UPDATE [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
			SET cec_idestatuscotiza=@cec_idestatuscotiza
			WHERE ucu_foliocotizacion =@folio
			
			UPDATE NOT_NOTIFICACION SET not_estatus = @estatusNotificacion WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
			UPDATE NOT_APROBACION SET apr_estatus = @estatusNotificacion WHERE apr_id = @idAprobacion;							
			----------------------------------------------------------------
			-------Inserta una respuesta de aprobación
			----------------------------------------------------------------						
							
			INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
				(not_id,[apr_id],[nar_fecha],[nar_comentario])
			VALUES
				(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
			
			DECLARE @estatusFinal INT = 0
			SELECT TOP(1) @estatusFinal = cec_idestatuscotiza FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
			    WHERE ucu_foliocotizacion = @folio
			
			INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
			VALUES (7,'APR_INS_AGRUP7_SP termina @folio: ' + @folio + ' ESTATUS FINAL: ' + CONVERT(VARCHAR(10), @estatusFinal) + ' - ' + @mensaje ,GETDATE())
			
			--LQMA add 25102017 valida que se haga el cambio de estatus, si no es el mismo, se prova un error para que entre al rollback
			IF((SELECT TOP(1) cec_idestatuscotiza FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
			    WHERE ucu_foliocotizacion =@folio) != @cec_idestatuscotiza)
			BEGIN				
				SELECT @valor = 1/0
			END 
			
			SELECT 0 estatus, @mensaje mensaje
		
		COMMIT TRAN TRAN_APR_INS_AGRUP7	
					
	END TRY
    BEGIN CATCH

		ROLLBACK TRAN TRAN_APR_INS_AGRUP7		
			
			DECLARE @MensajeEr VARCHAR(MAX) = '',
			@Componente VARCHAR(50) = 'APR_INS_AGRUP7_SP'
			SELECT @MensajeEr = ERROR_MESSAGE()
			DECLARE @parametros  nvarchar(500) = 'Componente externo a BD'
			
			INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
			VALUES (7,'APR_INS_AGRUP7_SP error @folio: ' + @folio + ' - Error: ' +  @MensajeEr,GETDATE())

			IF EXISTS (SELECT 1 FROM sysobjects WHERE name=@componente) 
			BEGIN
				SELECT @parametros = COALESCE(@parametros + ', ', '') + PARAMETER_NAME  from INFORMATION_SCHEMA.PARAMETERS Where SPECIFIC_NAME = @componente
			END

			INSERT INTO Error(componente, parametros, mensaje,fecha) VALUES (@componente, @parametros, @MensajeEr + @folio,GETDATE())
					
			SELECT ERROR_NUMBER() estatus, 'No se ha podido realizar la operación, intente de nuevo.' mensaje

	END CATCH

END
go

