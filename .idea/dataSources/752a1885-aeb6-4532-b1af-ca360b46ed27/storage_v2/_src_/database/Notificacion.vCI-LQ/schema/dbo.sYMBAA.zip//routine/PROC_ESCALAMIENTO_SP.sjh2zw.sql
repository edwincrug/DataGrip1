CREATE PROCEDURE [dbo].[PROC_ESCALAMIENTO_SP]
AS
BEGIN
BEGIN TRY
	SET NOCOUNT ON
		--SELECT * FROM NOT_NOTIFICACION WHERE not_identificador = 'AU-ZM-NZA-OT-PE-9338'
		--SELECT * FROM NOT_APROBACION WHERE not_id IN (SELECT not_id FROM NOT_NOTIFICACION WHERE not_identificador = 'AU-ZM-NZA-OT-PE-9338')
		DECLARE @notificaciones TABLE(	id INT IDENTITY
										,not_id	numeric(18,	0) 
										,not_identificador	nvarchar(100)  
										,not_tipo	int
										,not_tipo_proceso	int
										,not_nodo	int
										,not_estatus	int
										,apr_fecha DATETIME
										,apr_nivel INT
										,apr_escalado INT
										,not_agrupacion INT
										,not_adjunto_tipo VARCHAR(100)
										,idEmpresa INT
										,idSucursal INT
										)	
		-------------------------------------------------------------------------------------------------------
		--Obtenemos las Notificaciones que son escalables 
		-------------------------------------------------------------------------------------------------------
		INSERT INTO @notificaciones
		SELECT	DISTINCT N.not_id
				,N.not_identificador
				,N.not_tipo
				,N.not_tipo_proceso
				,N.not_nodo
				,N.not_estatus
				,A.apr_fecha
				,A.apr_nivel
				,A.apr_escalado
				,N.not_agrupacion
				,N.not_adjunto_tipo
				,N.idEmpresa
				,N.idSucursal
		FROM	dbo.NOT_NOTIFICACION N  
				INNER JOIN dbo.NOT_APROBACION A ON A.not_id = N.not_id 
				LEFT JOIN dbo.BPRO_Usuarios U ON A.emp_id = U.usu_idusuario
		WHERE	N.not_estatus in (2) AND N.not_tipo = 1 AND apr_escalado <> -1 AND apr_escalado = 0 AND N.not_nodo = 1 and not_agrupacion not in (48,49)

		

		--SELECT * FROM @notificaciones
		DECLARE @max				INT 
				,@aux				INT = 1
				,@idnot				INT
				,@tiponot			INT
				,@tipoproceso		INT
				,@idnodo			INT
				,@notestatus		INT				
				,@nivel				INT
				,@escalado			INT
				,@fecha				DATETIME
				,@idfolio			VARCHAR(50)
				,@empresa			INT
				,@sucursal			INT
				,@departamento		INT
				,@depNombreCto		VARCHAR(10)
				,@minutos1			INT
				,@minutos2			INT
				,@areaOT			VARCHAR (250)
				,@solicitante		INT
				,@tipoorden			INT
				,@apr_usu1			INT = 0
				,@apr_usu2			INT = 0
				,@apr_usu3			INT = 0
				,@idEmpleado		INT = 0
				,@nivelC			INT = 0
				,@auxEscalar		BIT = 0
				,@descripcion		VARCHAR(500) = ''
				,@not_linkBPRO		VARCHAR(MAX) = ''
				,@not_adjunto		VARCHAR(MAX) = ''
				,@not_adjunto_tipo	VARCHAR(500) = ''
				,@usuarioEscalado	VARCHAR(100) = '<Usuario Escalado>'
				,@nombreBase		VARCHAR(100) = ''
				,@queryArea			VARCHAR(MAX) = ''
				,@not_agrupacion	INT
				,@idNotificacion NUMERIC(18,0)
				
		
		
		DECLARE	@tablaArea			TABLE(area VARCHAR(250))
		SELECT @max = COUNT(1) FROM @notificaciones
	
		WHILE(@aux <= @max)
			BEGIN
				SET @empresa = null
				SET @sucursal = null
				SET @departamento = null
				SET @solicitante = null
				SET @tipoorden = null
				SET @depNombreCto = ''
				SET @nombreBase = ''
				SET @minutos1 = null
				SET @apr_usu1 = null
				SET @apr_usu2 = null
				SET @apr_usu3 = null 
				SET @not_agrupacion = null
				SELECT	@idnot = not_id
						,@idfolio = not_identificador
						,@tiponot = not_tipo
						,@tipoproceso = not_tipo_proceso
						,@idnodo = not_nodo
						,@notestatus = not_estatus
						,@fecha = apr_fecha
						,@nivel = apr_nivel
						,@escalado = apr_escalado 
						,@not_agrupacion = not_agrupacion
						
				FROM	@notificaciones 
				WHERE	id = @aux 

				--select @idnot
				SELECT @departamento = OC.oce_iddepartamento, @empresa= OC.oce_idempresa, @sucursal=OC.oce_idsucursal, @solicitante = OC.oce_idusuario, @tipoorden = OC.[oce_idtipoorden]  FROM dbo.OrdenesdeCompra OC WHERE OC.oce_folioorden = @idfolio --AND OC.oce_idempresa = 4 --Comentar en Producción
				--PRINT @departamento
				SELECT @depNombreCto = dep_nombrecto FROM [ControlAplicaciones].[dbo].[cat_departamentos] WHERE dep_iddepartamento = @departamento
				--PRINT @depNombreCto
				--select * from Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION

				
				IF(@not_agrupacion = 47 )
				BEGIN
					print 'Agrupador 47'
					DECLARE @areaC VARCHAR(10) = ''
					SELECT @areaC = not_adjunto_tipo, @empresa = idEmpresa, @sucursal = idSucursal from @notificaciones where not_id = @idnot 

					SELECT		 @minutos1 = E.Minutos_Escalar
								,@apr_usu1 = E.Usuario_Autoriza1
								,@apr_usu2 = E.Usuario_Autoriza2
								,@apr_usu3 = E.Usuario_Autoriza3 
						FROM	[Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] AS E
						WHERE	E.emp_idempresa = @empresa 
								AND E.suc_idsucursal = @sucursal 
								AND par_idenpara = @areaC

					--select * from  [Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] where par_idenpara = 'AZA'
					
				END
				ELSE IF( @depNombreCto = 'OT')
					BEGIN
						--select 'Entre OT'
						SELECT @nombreBase = [nombre_base] FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE [emp_idempresa] = @empresa AND [suc_idsucursal] = @sucursal AND [tipo] = 1
						--PRINT @nombreBase
						SET @queryArea =	' SELECT	PNC.PAR_DESCRIP1 ' +
											' FROM		' + @nombreBase + '.DBO.CON_PEDOTROS AS P' +
											' 			INNER JOIN ' + @nombreBase + '.DBO.PNC_PARAMETR AS PNC ON PAR_TIPOPARA = ''AREPED'' AND PNC.PAR_IDENPARA = P.poc_area' +
											' WHERE		P.poc_folioorden = ''' + @idfolio + ''' '
						INSERT INTO @tablaArea
						EXECUTE (@queryArea)
						SELECT @areaOT = area FROM @tablaArea 
						DELETE FROM @tablaArea
						--PRINT @areaOT
						--SELECT @areaOT = otc_area FROM [cuentasxpagar].[dbo].[cxp_detalleotrosconceptos] WHERE oce_folioorden = @idfolio
						SELECT	@minutos1 = E.Minutos_Escalar
								,@apr_usu1 = E.Usuario_Autoriza1
								,@apr_usu2 = E.Usuario_Autoriza2
								,@apr_usu3 = E.Usuario_Autoriza3 
						FROM	[Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] AS E
						WHERE	E.emp_idempresa = @empresa 
								AND E.suc_idsucursal = @sucursal 
								AND E.otc_area = @areaOT
						

					END
				ELSE 
					BEGIN
						--select 'Entre otro escalamiento'
						SELECT	@minutos1 = E.Minutos_Escalar
								,@apr_usu1 = E.Usuario_Autoriza1
								,@apr_usu2 = E.Usuario_Autoriza2
								,@apr_usu3 = E.Usuario_Autoriza3 
						FROM	dbo.ESCALACION E
						WHERE	E.nodo_id = @idnodo
								AND E.emp_idempresa = @empresa 
								AND E.suc_idsucursal = @sucursal 
								AND E.dep_iddepartaamento =@departamento
					END
				--------------------------------------------------------------------------
				--corregir para obtener los minutos adiconales y sumarlos a la variable @fecha
				--print ('minutos 1: ' + convert(varchar, ISNULL(@minutos1,9999999)));			
				SELECT @minutos2 = DATEDIFF(MINUTE, @fecha, GETDATE());
				SET @nivel = @nivel + 1;
				DECLARE @fechaIni DATETIME = @fecha/*'2018-02-01 15:29:59'*/
						,@minutos INT = @minutos1
						,@horaI INT = 9, @horaF INT = 18
						,@fechaActual DATETIME = GETDATE()
						,@escalamiento BIT = 0

				DECLARE @iDia DATETIME = CONVERT(VARCHAR(10),@fechaActual,112) 
						,@fDia DATETIME = CONVERT(VARCHAR(10),@fechaActual,112)
				SELECT @iDia = DATEADD(HOUR,@horaI, @iDia), @fDia = DATEADD(HOUR,@horaF, @fDia)
		
				IF (SELECT UPPER(DATENAME(DW, GETDATE()))) != 'DOMINGO'
					BEGIN						
						IF (SELECT UPPER(DATENAME(DW, @fechaIni))) = 'DOMINGO'
							BEGIN
								SELECT @fechaIni = DATEADD(DAY,1,@fechaIni)
							END
							
						IF(SELECT DATEDIFF(DAY, @fechaIni, @fechaActual)) = 0
							BEGIN
								IF(@fechaIni < @iDia)
									SET @fechaIni = @iDia
								IF(@fechaActual > @fDia)
									BEGIN
										--PRINT 'Mayor a hora final'
										SET @fechaActual = @fDia
									END
								IF(SELECT DATEDIFF(MINUTE, @fechaIni, @fechaActual)) > @minutos
									SET @escalamiento = 1	--SELECT 'MIN: ' + CONVERT(VARCHAR(10),DATEDIFF(MINUTE, @fechaIni, @fechaActual)) + ' ESCALA! 1'
								--ELSE
									--PRINT 'MIN: ' + CONVERT(VARCHAR(10),DATEDIFF(MINUTE, @fechaIni, @fechaActual)) + ' EN TIEMPO!'

							END
						ELSE
							BEGIN						
								--PRINT 'diferente dia'
								SELECT @iDia  = CONVERT(VARCHAR(10),@fechaIni,112),@fDia = CONVERT(VARCHAR(10),@fechaIni,112) 
								SELECT @iDia = DATEADD(HOUR,@horaI, @iDia), @fDia = DATEADD(HOUR,@horaF, @fDia)
								DECLARE @minDia INT = 0
								IF(@fechaIni < @iDia)
									SET @fechaIni = @iDia
								--PRINT '@fechaIni: ' + CONVERT(VARCHAR(20),@fechaIni) + ', @fDia: ' + CONVERT(VARCHAR(20),@fDia)
								SELECT @minDia = DATEDIFF(MINUTE, @fechaIni, @fDia)
								--SELECT @fechaIni fechaIni,@iDia iDia, @fDia fDia, @minDia minAcumulados
								IF(@minDia > @minutos)
									SET @escalamiento = 1 --SELECT 'MIN: ' + CONVERT(VARCHAR(10),@minDia) + ' ESCALA! 2'
								ELSE
									BEGIN
										IF(SELECT (DATEPART(HOUR,GETDATE()) * 60 + DATEPART(MINUTE,GETDATE())) - (9 * 60) + @minDia) > @minutos
											SET @escalamiento = 1--SELECT 'MIN: ' + CONVERT(VARCHAR(10),@minDia) + ' ESCALAR! 3'
										--ELSE
										--	PRINT 'EN TIEMPO!'
									END						
							END
						END
					IF(@escalamiento = 1)
						IF(@not_agrupacion in(47))--- OC diferentes
						BEGIN
						print 'Entre a OC diferentes escalar'
							--PRINT 'Se escalaria ' + @idfolio + ' ' + CONVERT(VARCHAR(10), @minutos1)	
								SELECT	TOP(1) @nivelC = apr_nivel
										,@idEmpleado = emp_id 
								FROM	NOT_APROBACION 
								WHERE	not_id = @idnot 
										AND apr_estatus IN (1,2) 
										AND apr_escalado <> -1 ORDER BY apr_id DESC 
								IF (@nivelC < 2) AND ((SELECT COUNT(1) FROM NOT_APROBACION WHERE not_id = @idnot AND apr_escalado <> -1) < 3)
									BEGIN
										SET @auxEscalar = 0
										IF(@nivelC = 0) --escalacion nivel 1
											BEGIN
												IF(@idEmpleado <> @apr_usu2 AND @apr_usu2 > 0)												
													SELECT @apr_usu1 = @apr_usu2, @auxEscalar = 1, @nivelC = 1
											END
										ELSE	--escalacion nivel 2
											BEGIN
												IF(@idEmpleado <> @apr_usu3 AND @apr_usu3 > 0)
													SELECT @apr_usu1 = @apr_usu3, @auxEscalar = 1, @nivelC = 2
											END
										IF(@auxEscalar = 1) --se escalara a alguien
											BEGIN
												UPDATE NOT_APROBACION 
												SET apr_escalado = 1 , apr_estatus = 3 --LQMA 26072017
												WHERE not_id = @idnot AND apr_escalado <> -1 --escala solo las aprobaciones a 1
												SET @descripcion = ''
												SET @not_linkBPRO = ''
												SET @not_adjunto = ''
												SET @not_adjunto_tipo = ''
												SELECT  @descripcion = not_descripcion, 
														@not_linkBPRO = not_link_BPRO, 
														@not_adjunto = not_adjunto, 
														@not_adjunto_tipo = not_adjunto_tipo
												FROM	NOT_NOTIFICACION 
												WHERE	not_id = @idnot
												INSERT INTO NOT_NOTIFICACION (not_tipo, not_tipo_proceso, not_identificador, not_nodo, not_descripcion, not_estatus, not_fecha, not_link_BPRO, not_adjunto	, not_adjunto_tipo, not_agrupacion)
												VALUES(7, 1	, @idfolio, 0	, 'Solicitud escalada. El tiempo para dar respuesta a esta solicitud ha transcurrido. Se ha escalado al siguiente nivel.  <br/><b>Escalado: </b> ' +   CONVERT(VARCHAR(10),GETDATE(),103) + ' ' + CONVERT(VARCHAR(10),GETDATE(),108)  + ' <b>  a: </b> ' + @usuarioEscalado, 2	, GETDATE()	, @not_linkBPRO, @not_adjunto, @not_adjunto_tipo, 0)
												
												SET @idNotificacion = @@IDENTITY
												INSERT INTO NOT_APROBACION(not_id,apr_nivel,apr_visto,emp_id,apr_fecha,apr_estatus,apr_escalado)
												VALUES(@idNotificacion,0,0,@idEmpleado,GETDATE(), 2, -1)
												SELECT @usuarioEscalado = usu_nombre + ' ' + usu_paterno + ' ' + usu_materno FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @apr_usu1
												INSERT INTO [dbo].[NOT_APROBACION](	[not_id]
																					,[apr_nivel]
																					,[apr_visto]
																					,[emp_id]
																					,[apr_fecha]
																					,[apr_estatus]
																					,[apr_escalado])
												VALUES(		@idnot
															,@nivelC
															,0
															,@apr_usu1
															,GETDATE()
															,2
															,0)

												UPDATE	NOT_NOTIFICACION 
												SET		not_descripcion = REPLACE(not_descripcion,'<Usuario Escalado>',@usuarioEscalado)
												WHERE	not_id = @idNotificacion
												--PRINT 'Se escalaria ' + @idfolio + ' Minutos_Escalar ' + CONVERT(VARCHAR(10), @minutos1) + ' Al usuario ' + CONVERT(VARCHAR(10), @apr_usu1)
											END
									END
						END

						ELSE IF EXISTS(SELECT 1 FROM dbo.OrdenesdeCompra OC WHERE OC.oce_folioorden = @idfolio)
							BEGIN
								--select 'Escalo OT'
								--PRINT 'Se escalaria ' + @idfolio + ' ' + CONVERT(VARCHAR(10), @minutos1)	
								SELECT	TOP(1) @nivelC = apr_nivel
										,@idEmpleado = emp_id 
								FROM	NOT_APROBACION 
								WHERE	not_id = @idnot 
										AND apr_estatus IN (1,2) 
										AND apr_escalado <> -1 ORDER BY apr_id DESC 
								IF (@nivelC < 2) AND ((SELECT COUNT(1) FROM NOT_APROBACION WHERE not_id = @idnot AND apr_escalado <> -1) < 3)
									BEGIN
										SET @auxEscalar = 0
										IF(@nivelC = 0) --escalacion nivel 1
											BEGIN
												IF(@idEmpleado <> @apr_usu2 AND @apr_usu2 > 0)												
													SELECT @apr_usu1 = @apr_usu2, @auxEscalar = 1, @nivelC = 1
											END
										ELSE	--escalacion nivel 2
											BEGIN
												IF(@idEmpleado <> @apr_usu3 AND @apr_usu3 > 0)
													SELECT @apr_usu1 = @apr_usu3, @auxEscalar = 1, @nivelC = 2
											END
										IF(@auxEscalar = 1) --se escalara a alguien
											BEGIN
												UPDATE NOT_APROBACION 
												SET apr_escalado = 1 , apr_estatus = 3 --LQMA 26072017
												WHERE not_id = @idnot AND apr_escalado <> -1 --escala solo las aprobaciones a 1
												SET @descripcion = ''
												SET @not_linkBPRO = ''
												SET @not_adjunto = ''
												SET @not_adjunto_tipo = ''
												SELECT  @descripcion = not_descripcion, 
														@not_linkBPRO = not_link_BPRO, 
														@not_adjunto = not_adjunto, 
														@not_adjunto_tipo = not_adjunto_tipo
												FROM	NOT_NOTIFICACION 
												WHERE	not_id = @idnot
												INSERT INTO NOT_NOTIFICACION (not_tipo, not_tipo_proceso, not_identificador, not_nodo, not_descripcion, not_estatus, not_fecha, not_link_BPRO, not_adjunto	, not_adjunto_tipo, not_agrupacion)
												VALUES(7, 1	, @idfolio, 0	, 'Solicitud escalada. El tiempo para dar respuesta a esta solicitud ha transcurrido. Se ha escalado al siguiente nivel.  <br/><b>Escalado: </b> ' +   CONVERT(VARCHAR(10),GETDATE(),103) + ' ' + CONVERT(VARCHAR(10),GETDATE(),108)  + ' <b>  a: </b> ' + @usuarioEscalado, 2	, GETDATE()	, @not_linkBPRO, @not_adjunto, @not_adjunto_tipo, 0)
												
												SET @idNotificacion = @@IDENTITY
												INSERT INTO NOT_APROBACION(not_id,apr_nivel,apr_visto,emp_id,apr_fecha,apr_estatus,apr_escalado)
												VALUES(@idNotificacion,0,0,@idEmpleado,GETDATE(), 2, -1)
												SELECT @usuarioEscalado = usu_nombre + ' ' + usu_paterno + ' ' + usu_materno FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @apr_usu1
												INSERT INTO [dbo].[NOT_APROBACION](	[not_id]
																					,[apr_nivel]
																					,[apr_visto]
																					,[emp_id]
																					,[apr_fecha]
																					,[apr_estatus]
																					,[apr_escalado])
												VALUES(		@idnot
															,@nivelC
															,0
															,@apr_usu1
															,GETDATE()
															,2
															,0)

												UPDATE	NOT_NOTIFICACION 
												SET		not_descripcion = REPLACE(not_descripcion,'<Usuario Escalado>',@usuarioEscalado)
												WHERE	not_id = @idNotificacion
												--PRINT 'Se escalaria ' + @idfolio + ' Minutos_Escalar ' + CONVERT(VARCHAR(10), @minutos1) + ' Al usuario ' + CONVERT(VARCHAR(10), @apr_usu1)
											END
									END
							END						
				--------------------------------------------------------------------------
				SET @aux = @aux + 1
			END
			--SELECT * FROM NOT_NOTIFICACION WHERE not_identificador = 'AU-ZM-NZA-OT-PE-9338'
			--SELECT * FROM NOT_APROBACION WHERE not_id IN (SELECT not_id FROM NOT_NOTIFICACION WHERE not_identificador = 'AU-ZM-NZA-OT-PE-9338')
	SET NOCOUNT OFF

END TRY
BEGIN CATCH

		--PRINT ('Error: ' + ERROR_MESSAGE())
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'PROC_ESCALAMIENTO_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		
		EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	--	ROLLBACK TRAN;
		print 0;
END CATCH
END
go

