
CREATE PROCEDURE [dbo].[INS_APROBACION_CC_SINPRESUPUESTO_SP]
	@idtipoproceso int
	,@identificador varchar(50) 
	,@descripcion varchar(500)
	,@estatus int
	,@aprobador	numeric(18,0)
	,@idCC INT = 0 
	
AS
BEGIN
	SET NOCOUNT ON;
	
	--	BEGIN TRAN TRAN_APROBACION_COTIZACION

	BEGIN TRY

		INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	    VALUES (5,'INS_APROBACION_CC_SINPRESUPUESTO_SP @aprobador:' + CONVERT(VARCHAR(5),@aprobador) ,GETDATE())

		DECLARE @idsolicitante numeric(18,0)
		SELECT @idsolicitante=ucu_idusuarioalta FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE ucu_foliocotizacion =@identificador
		
		INSERT INTO NOT_NOTIFICACION (not_tipo
		, not_tipo_proceso
		, not_identificador
		, not_nodo
		, not_descripcion
		, not_estatus
		, not_fecha
		, not_link_BPRO
		, not_adjunto
		, not_adjunto_tipo
		, not_agrupacion)
		VALUES
		( 1
		, @idtipoproceso
		, @identificador
		,''
		, @descripcion
		, @estatus
		, GETDATE()
		, null
		, ''
		, @idCC
		, 45
		)

DECLARE @nid_not int = @@IDENTITY;

--Solicitante
-- si aprobador = solicitante, solo se inserta aprobador
----------------------------------
IF(@aprobador != @idsolicitante) --si aprobador es diferente de solicitante, se inserta solicitante
	BEGIN
		INSERT INTO [dbo].[NOT_APROBACION]
			   ([not_id]
			   ,[apr_nivel]
			   ,[apr_visto]
			   ,[emp_id]
			   ,[apr_fecha]
			   ,[apr_estatus]
			   ,[apr_escalado])
		 VALUES
			   (@nid_not
			   ,0
			   ,NULL
			   ,@idsolicitante
			   ,GETDATE()
			   ,1
			   ,-1)
	END
		   
--Aprobador
----------------------------------
	INSERT INTO [dbo].[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
           ,[apr_escalado])
     VALUES
           (@nid_not
		   ,0
		   ,NULL
           ,@aprobador
           ,GETDATE()
           ,1
           ,0)
	

--Actualiza el estatus de la notificación a 2
----------------------------------
	UPDATE NOT_NOTIFICACION SET not_estatus = 2 
		WHERE not_id =@nid_not

	
	UPDATE NOT_APROBACION SET apr_estatus = 2 WHERE not_id = @nid_not





	
--	COMMIT TRAN TRAN_APROBACION_COTIZACION	
	
	
	
END TRY
BEGIN CATCH

	
	--ROLLBACK TRAN TRAN_APROBACION_COTIZACION

	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_APROBACION_COTIZACION_SP'
	SELECT ERROR_NUMBER() error
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	
END CATCH
END;
go

