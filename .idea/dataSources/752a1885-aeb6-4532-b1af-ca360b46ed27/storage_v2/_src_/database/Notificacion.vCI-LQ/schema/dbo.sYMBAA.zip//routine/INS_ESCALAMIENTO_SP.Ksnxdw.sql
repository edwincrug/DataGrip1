
CREATE PROCEDURE dbo.INS_ESCALAMIENTO_SP
@nid_not INT 
,@idnivel INT 
,@not_agrupador INT 
,@idEmpresa INT = NULL
,@idSucursal INT = NULL
,@idDepartamento INT = NULL
,@result NUMERIC(18,0) = 0 OUTPUT 
AS
BEGIN
SET NOCOUNT ON;

BEGIN TRY

--DECLARE @nid_not INT = 255022
-- ,@idnivel INT = 0
-- ,@not_agrupador INT = 53
-- ,@idEmpresa INT = 4
-- ,@idSucursal INT = 6
-- ,@idDepartamento INT = 26
--,@result NUMERIC(18,0) = 0 OUTPUT


		DECLARE @tblAprobadores TABLE
		(
		id INT IDENTITY(1,1) 
		,nivel_escalamiento INT
		,usuarioAprobador INT
		,idTipoNotificacion INT
		)
		--SELECT not_identificador from Notificacion.dbo.NOT_NOTIFICACION where not_id = @nid_not


		--INSERT INTO Centralizacionv2.dbo.BITACORA_PROCESOS
		--VALUES(999,'INS_ESCALACION_SYS_SP ' + CONVERT(varchar(10),@nid_not) ,GETDATE())


			DECLARE  @apr_usu1 INT=0
					,@nivelC INT = 0
					,@idEmpleado INT = 0
					,@usuarioEscalado VARCHAR(100) =  '<Usuario Escalado>'
					,@NoAprobadores INT
					,@folio VARCHAR(50) = ''
					,@idTipoNotificacion INT


			INSERT INTO @tblAprobadores
			SELECT nivel_escalamiento, usuario_autoriza, idTipoNotificacion
			FROM CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
			WHERE not_agrupador = @not_agrupador
			AND ISNULL(idEmpresa,0) = ISNULL(@idEmpresa,0) AND ISNULL(idSucursal,0) = ISNULL(@IdSucursal,0) AND ISNULL(idDepartamento,0) = ISNULL(@idDepartamento,0)
	
	
			DECLARE @idPadre int = NULL
			,@idSolicitante INT
			,@cont INT = 0

			DECLARE @tblAprobJera as TABLE (id int, idUsuario INT, idtipoNotificacionJeraquizada INT )

			IF EXISTS (SELECT 1 FROM Centralizacionv2.dbo.DIG_CAT_NOTIFICACION_JERARQUIZADA WHERE not_agrupador IN ( @not_agrupador))
			BEGIN
				-- 255022
				SELECT @idSolicitante = not_adjunto from notificacion.dbo.not_notificacion where not_id = @nid_not
				--select @idSolicitante
				INSERT INTO @tblAprobJera 
				SELECT 0,idUsuario,idtipoNotificacionJeraquizada from Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE id in (SELECT idPadre FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE idUsuario = @idSolicitante and idDepartamento = @idDepartamento)

				SELECT @idPadre = idPadre FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE idUsuario = @idSolicitante

				WHILE(@idPadre is not null)
				BEGIN
				SELECT @idPadre = idPadre  from Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE id in (SELECT idPadre FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE idUsuario in (SELECT idUsuario from @tblAprobJera where id = @cont))

				INSERT INTO @tblAprobJera
				SELECT (SELECT MAX(id)+1 FROM @tblAprobJera), idUsuario , idtipoNotificacionJeraquizada from Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE id in (SELECT idPadre FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE idUsuario in (SELECT idUsuario from @tblAprobJera where id = @cont))
				SET @cont = @cont + 1

				END
				--select * from @tblAprobJera
				INSERT INTO @tblAprobadores
				SELECT  id , idUsuario , idtipoNotificacionJeraquizada from @tblAprobJera
				--SELECT * FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO-- WHERE idUsuario = 517
				--select * from Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE id in (SELECT idPAdre FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO WHERE idUsuario = 517)
			END

			SET @NoAprobadores = (SELECT COUNT(1) FROM  @tblAprobadores)

			SELECT @folio = not_identificador FROM NOT_NOTIFICACION WHERE not_id = @nid_not


			SELECT @idEmpleado =  emp_id 
			FROM Notificacion.dbo.NOT_APROBACION 
			WHERE not_id = @nid_not 
			AND apr_estatus IN (1,2) 
			AND apr_escalado <> -1 
			ORDER BY apr_id DESC 



			IF ((SELECT COUNT(1) FROM NOT_APROBACION WHERE not_id = @nid_not AND apr_escalado <> -1) < @NoAprobadores)
			BEGIN


					DECLARE @aux BIT = 0

					SELECT @nivelC = @idnivel + 1
					SELECT @apr_usu1 = usuarioAprobador, @idTipoNotificacion = idTipoNotificacion  FROM @tblAprobadores WHERE nivel_escalamiento = @nivelC


					--BEGIN TRAN
					UPDATE NOT_APROBACION SET apr_escalado = 1 , apr_estatus = 5--3
					WHERE not_id = @nid_not AND apr_escalado <> -1 

					---LQMA 26072017
					DECLARE @descripcion VARCHAR(500) = '',  @not_linkBPRO VARCHAR(MAX) = '', @not_adjunto VARCHAR(MAX) = '', 
					@not_adjunto_tipo VARCHAR(500) = '', @agrupador INT

					SELECT  @descripcion = not_descripcion, 
							@not_linkBPRO = not_link_BPRO, 
							@not_adjunto = not_adjunto, 
							@not_adjunto_tipo = not_adjunto_tipo,
							@agrupador = not_agrupacion
					FROM NOT_NOTIFICACION WHERE not_id = @nid_not


					INSERT INTO NOT_NOTIFICACION (not_tipo, not_tipo_proceso, not_identificador, not_nodo, not_descripcion, not_estatus, not_fecha, not_link_BPRO
												, not_adjunto , not_adjunto_tipo, not_agrupacion, idEmpresa, idSucursal, idDepartamento)
					VALUES(7, 1 , @folio, 0 , 'Solicitud escalada. El tiempo para dar respuesta a esta solicitud ha transcurrido. Se ha escalado al siguiente nivel.
					Escalado: ' +   CONVERT(VARCHAR(10),GETDATE(),103) + ' ' + CONVERT(VARCHAR(10),GETDATE(),108)  + ' a: ' + @usuarioEscalado, 2 , GETDATE() , @not_linkBPRO, @not_adjunto, @not_adjunto_tipo, @agrupador, @idEmpresa, @idSucursal,@idDepartamento)

					DECLARE @idNot NUMERIC(18,0) = SCOPE_IDENTITY()

					INSERT INTO NOT_APROBACION(not_id,apr_nivel,apr_visto,emp_id,apr_fecha,apr_estatus,apr_escalado)
					VALUES(@idNot,0,0,@idEmpleado,GETDATE() ,2,-1)

					SELECT @usuarioEscalado = usu_nombre + ' ' + usu_paterno + ' ' + usu_materno FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @apr_usu1

					INSERT INTO [dbo].[NOT_APROBACION] ([not_id],[apr_nivel],[apr_visto],[emp_id],[apr_fecha],[apr_estatus],[apr_escalado])
					VALUES  (@nid_not,@nivelC,0,@apr_usu1,GETDATE(),2,0)


					UPDATE NOT_NOTIFICACION SET not_descripcion = REPLACE(not_descripcion,'',@usuarioEscalado) WHERE not_id = @idNot
					IF(@agrupador = 23)
					BEGIN
						DECLARE @nuevoUsuario  VARCHAR(250) = '?employee='+ convert(varchar(5),@apr_usu1)+'&'

						UPDATE NOT_NOTIFICACION SET not_link_BPRO = REPLACE(not_link_BPRO,'?employee=341&',@nuevoUsuario)
						WHERE  not_identificador in  (SELECT not_identificador from NOT_NOTIFICACION where not_id = @nid_not)
						--select REPLACE('http://192.168.20.89:4010/aprobar?employee=341&idTramite=329','?employee=341&','?employee=342&')
						end



						INSERT INTO Centralizacionv2.dbo.DIG_BITACORA_ESCALAMIENTO
						SELECT @nid_not,@idTipoNotificacion,@idEmpleado,@apr_usu1,'Se escaló la notificación al usuario: ' + CONVERT(VARCHAR(50),@apr_usu1), GETDATE()
						--SELECT * from Notificacion.dbo.NOT_NOTIFICACION where not_id = @nid_not
						--select * from Notificacion.dbo.NOT_APROBACION where not_id = @nid_not order by apr_id asc

						--SELECT * from Notificacion.dbo.NOT_NOTIFICACION where not_id = @idNot
						--select * from Notificacion.dbo.NOT_APROBACION where not_id = @idNot order by apr_id asc
			END
			ELSE 
			BEGIN
				print 'ya no escalo'
			END
			--END--IF(@aux = 1)
			SET @result = 1
			RETURN @result
END TRY
BEGIN CATCH
-- PRINT ('Error: ' + ERROR_MESSAGE())
-- DECLARE @Mensaje nvarchar(max),
-- @Componente nvarchar(50) = 'INS_ESCALACION_SYS_SP'
-- SELECT @Mensaje = ERROR_MESSAGE()
-- RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje;
	SET @result = -1
	RETURN @result
END CATCH
END
go

