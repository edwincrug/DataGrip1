-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- SEL_TOKEN_RESPUESTA_SP 248072,483218 ,'75A85715-1C0E-4997-A8F4-4961A8E248C0'
CREATE PROCEDURE [dbo].[SEL_TOKEN_RESPUESTA_SP]
	 @not_id INT
	,@apr_id INT
	,@token NVARCHAR(300)
AS
BEGIN


		IF EXISTS(SELECT not_id FROM [Notificacion].[dbo].[NOT_APROB_MANCOMUNADO] WHERE not_id = @not_id AND apr_id = @apr_id AND token_correo = @token)
		BEGIN 
			SELECT success = 1, msg = 'Notificación sin revisar.'
		END
		ELSE
		BEGIN
			SELECT success = 0, msg = 'La notificación ha sido previamente revisada.'
		END

END
go

