CREATE PROCEDURE  [dbo].[SEL_TIPO_NOTIFICACION_SP]
AS
BEGIN

SELECT [idTipoNotificacion]
      ,[descripcion]
	  ,[autorizadorMultiEmpresa]
FROM [Centralizacionv2].[dbo].[DIG_TIPO_NOTIFICACION]

END


go

