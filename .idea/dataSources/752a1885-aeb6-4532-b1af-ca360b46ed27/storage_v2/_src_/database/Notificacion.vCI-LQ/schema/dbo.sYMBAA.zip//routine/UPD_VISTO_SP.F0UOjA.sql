-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 28/10/2015
-- Description:	Procedimiento que actualiza a visto
-- =============================================

--UPD_VISTO_SP 1,1
CREATE PROCEDURE [dbo].[UPD_VISTO_SP] 
	 @idempleado	int
	,@idaprobacion  int
AS
BEGIN

	--SET NOCOUNT ON;
	BEGIN TRY
	BEGIN TRAN
	--FAL BUSCO EL ID DE LA NOTIFICACION PARA NO HACERLE NADA AUNQUE SEA VISTO SE AFECTARA ESTO AL APROBARSE.

	declare @idNot as int
	SET @idNot = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idaprobacion)

	IF EXISTS (SELECT not_id FROM NOT_NOTIFICACION
	WHERE not_estatus = 2 and not_descripcion Like '%Solicitud de Aprobación%' and not_id = @idNot) 
	BEGIN
	print 0;
	END
	ELSE
	BEGIN
	   UPDATE NOT_APROBACION SET apr_visto = GETDATE(), apr_estatus = 2 WHERE emp_id = @idempleado AND apr_id = @idaprobacion
	END
	print 0;
	COMMIT TRAN
	END TRY
	BEGIN CATCH
	ROLLBACK TRAN
	print @@IDENTITY ;
	END CATCH

END


go

