
---- =============================================

---- Description: Stored que recupera las notificaciones de un empleado
---- =============================================
---- EXECUTE [SEL_NOTIFICACIONES_ESCALADAS_PAGINADO_SP] 71,10
CREATE PROCEDURE [dbo].[SEL_NOTIFICACIONES_ESCALADAS_PAGINADO_SP]
  @idEmpleado   nvarchar(50)
 ,@top INT
AS
BEGIN
--DECLARE @idEmpleado   nvarchar(50) = 71
--		,@top INT = 300

SET NOCOUNT ON;
	BEGIN TRY
			
			DECLARE @ipLocal VARCHAR(50) = ''
			SELECT	@ipLocal = local_net_address
			FROM	sys.dm_exec_connections
			WHERE	Session_id = @@SPID;

			UPDATE N  SET not_estatus = 5
			FROM NOT_notificacion N 
			inner join Not_aprobacion A    ON  N.not_id = A.not_id
			WHERE  A.emp_id = @idEmpleado
			AND ((N.not_estatus IN (1,2,6)) AND (A.apr_estatus IN (1,2))) 
			AND A.apr_escalado IN (-1,0)
			AND ((N.not_agrupacion = 3 AND A.apr_estatus = 1) OR (N.not_agrupacion != 3) OR (A.apr_estatus = 2))
			AND  not_tipo = 7
			AND  N.not_fecha <=  DATeadd(day,-2,getdate())

	
		
			SELECT TOP (@top) N.not_id AS id
					, A.apr_id as idAprobacion
					, A.emp_id AS idEmpleado
					, U.usu_idusuario  AS idSolicitante
					,  ISNULL(U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno, '') AS solicitante
					, N.not_tipo_proceso AS tipoProceso
					, N.not_nodo AS etapaProceso 
					, S.suc_nombre   AS agencia
					, ISNULL(D.dep_nombre, 'N/A')  as departamento					
					,CASE  WHEN N.not_identificador != '' THEN N.not_identificador ELSE 'Alerta' END AS identificador 	
					,not_identificador
					, N.not_fecha AS fecha
					, SUBSTRING(N.not_descripcion, 1, 43) + '...' AS descripcionCorta
					, N.not_descripcion AS descripcionLarga
					, N.not_link_BPRO  link
					, N.not_adjunto AS adjunto
					, N.not_adjunto_tipo AS tipoAdjunto
					, 1  AS modalidadAdjunto
					,  N.not_tipo  AS tipoNotificacion
					, (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id) AS chat
					, (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id AND chat_visto=0 AND chat_idEmpleado <> A.emp_id) AS chatPendiente
					, N.not_agrupacion AS agrupacion
					, 0 AS correoEnviado
					, CASE WHEN A.apr_escalado = -1 THEN A.apr_escalado ELSE  A.apr_nivel END  AS escalado
					, A.apr_nivel AS nivel
					, N.not_estatus AS estatus
					, CASE 
						WHEN ISNULL(A.apr_visto, 0) = 0 AND (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id AND chat_visto=0 AND chat_idEmpleado <> A.emp_id)>0 THEN 0
						WHEN ISNULL(A.apr_visto, 0) > 0 AND (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id AND chat_visto=0 AND chat_idEmpleado <> A.emp_id)>0 THEN 0
						WHEN ISNULL(A.apr_visto, 0) = 0 AND (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id AND chat_visto=0 AND chat_idEmpleado <> A.emp_id)=0 THEN 0						
						ELSE 1
					  END AS estado	
					--,S.emp_idempresa AS idEmpresa
					--,S.suc_idsucursal AS idSucursal
					, CASE WHEN S.emp_idempresa IS NOT NULL THEN S.emp_idempresa ELSE  SC.emp_idempresa END  AS idEmpresa
					, CASE WHEN S.suc_idsucursal IS NOT NULL THEN S.suc_idsucursal ELSE  SC.suc_idsucursal END  AS idSucursal					
				    ,D.dep_iddepartamento AS idDepartamento
					,0 MinutosFaltan
					,'' AS comentarioRevision

                    , parametros.par_valor	ruta_archivos  --agrupado 3 flotilla case AU-ZM-[SUC] LQMA 13072016 original comentado parametros.par_valor
					,Deptos.dep_nombrecto Depto  --LQMA 07072016
					,0  esPlanta 
					--LQMA add 02032018
					 ,NULL estatusLote
					,0			diasNot
					,CASE  WHEN  N.not_agrupacion  IN (SELECT	not_agrupador FROM	Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION) THEN 1 ELSE 0 END  existeNotNueva
					
			FROM    
					dbo.NOT_NOTIFICACION AS N 
					LEFT JOIN dbo.NOT_APROBACION AS A ON  N.not_id = A.not_id
					LEFT JOIN dbo.NOT_APROBACION AS ema ON ema.not_id = N.not_id AND ema.apr_escalado = -1
					LEFT JOIN dbo.OrdenesdeCompra AS OC ON OC.oce_folioorden = N.not_identificador
					LEFT JOIN ControlAplicaciones.dbo.cat_sucursales AS S ON  S.suc_idsucursal = OC.oce_idsucursal
					LEFT JOIN dbo.BPRO_Departamentos AS D ON  D.dep_iddepartamento = OC.[oce_iddepartamento] 
					LEFT JOIN dbo.BPRO_Usuarios AS U ON U.usu_idusuario = OC.oce_idusuario 
				 	LEFT JOIN dbo.BPRO_Usuarios AS sap ON sap.usu_idusuario = ema.emp_id
					LEFT JOIN dbo.NOT_PARAMETROS AS parametros ON parametros.par_id = 1
					LEFT JOIN [ControlAplicaciones].[dbo].[cat_departamentos] Deptos ON OC.oce_iddepartamento = Deptos.dep_iddepartamento
					LEFT JOIN ControlAplicaciones.dbo.cat_sucursales AS SC ON  SC.suc_idsucursal= N.idSucursal
			WHERE  A.emp_id = CAST(@idEmpleado AS INT) --and n.not_id=327376
			AND ((N.not_estatus IN (1,2,6)) AND (A.apr_estatus IN (1,2))) --LQMA add se agrego estatus 6 = revision 
			AND A.apr_escalado IN (-1,0)
			AND ((N.not_agrupacion = 3 AND A.apr_estatus = 1) OR (N.not_agrupacion != 3) OR (A.apr_estatus = 2))
			AND  not_tipo = 7
			ORDER BY estado ASC,N.not_fecha DESC
  
	  END TRY
	  BEGIN CATCH
		  DECLARE @Mensaje  nvarchar(max),
		  @Componente nvarchar(50) = 'SEL_NOTIFICACION_SP'
		  SELECT @Mensaje = ERROR_MESSAGE() + '--- @empleado: ' + @idEmpleado
		  EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	  END CATCH
END
go

