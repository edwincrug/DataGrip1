CREATE PROCEDURE [dbo].[INS_ESCALACION_SYS_SP]
	 @nid_not int    -- Id de la notificación a la que se va a insertar la escalacion
	,@idnivel int
	,@idnodo int
	,@idtipoproceso int

AS
BEGIN
	SET NOCOUNT ON;

		--BEGIN TRANSACTION;
	BEGIN TRY
			
			--INSERT INTO Centralizacionv2.dbo.BITACORA_PROCESOS
			--VALUES(999,'INS_ESCALACION_SYS_SP ' + CONVERT(varchar(10),@nid_not) ,GETDATE())

			--Busca cuantas personas recibirán la notificación y hace el insert en la tabla de aprobaciones.
			DECLARE @apr_usu1	int=0;
			DECLARE @apr_usu2	int=0;
			DECLARE @apr_usu3	int=0;
			DECLARE @nivel_chk  int;
			DECLARE @nivelC		int = 0;

			--LQMA add 20042017 agregado, se cambio regla de negocio, se escala por usuarios del nivel 0 BEGIN
			DECLARE @departamento int;
			DECLARE @empresa	int;
			DECLARE @sucursal	int;
			DECLARE @solicitante int;
			DECLARE @tipoorden int;
			DECLARE @folio VARCHAR(50) = ''
			DECLARE @usuarioEscalado VARCHAR(100) = '<Usuario Escalado>'

			SELECT @folio = not_identificador FROM NOT_NOTIFICACION WHERE not_id = @nid_not

			IF EXISTS(SELECT 1 FROM dbo.OrdenesdeCompra OC WHERE OC.oce_folioorden = @folio)
				BEGIN
						SELECT @departamento = OC.oce_iddepartamento, 
							   @empresa= OC.oce_idempresa, 
							   @sucursal=OC.oce_idsucursal, 
							   @solicitante = OC.oce_idusuario, 
							   @tipoorden = [oce_idtipoorden] 
						FROM dbo.OrdenesdeCompra OC WHERE OC.oce_folioorden = @folio			

						SELECT top 1   @apr_usu1 = Usuario_Autoriza1
											, @apr_usu2 = Usuario_Autoriza2
											, @apr_usu3 = Usuario_Autoriza3 
								FROM  [Centralizacionv2].dbo.DIG_ESCALAMIENTO
								WHERE Nodo_Id = @idnodo
								AND Proc_Id = @idtipoproceso	
								AND emp_idempresa= @empresa	
								AND suc_idsucursal= @sucursal
								AND dep_iddepartaamento = @departamento
								--AND tipo_idtipoorden = @tipoorden
								AND Nivel_Escalamiento = 0
						
						--LQMA 10112017 add validar numero de escalamientos, maximo nivel 2
						DECLARE @idEmpleado INT = 0
						SELECT TOP(1) @nivelC = apr_nivel, @idEmpleado = emp_id FROM NOT_APROBACION WHERE not_id = @nid_not 
																									  AND apr_estatus IN (1,2) 
																									  AND apr_escalado <> -1 ORDER BY apr_id DESC 
						
						--LQMA 10112017 comment 	
						--IF(SELECT COUNT(*) FROM NOT_APROBACION WHERE not_id = @nid_not AND apr_escalado <> -1) < 3 --mientras no esten los 3 usuarios escalados, escala
						  IF (@nivelC < 2) AND ((SELECT COUNT(1) FROM NOT_APROBACION WHERE not_id = @nid_not AND apr_escalado <> -1) < 3)
							BEGIN

								DECLARE @aux BIT = 0

								IF(@nivelC = 0) --escalacion nivel 1
									BEGIN
											IF(@idEmpleado <> @apr_usu2 AND @apr_usu2 > 0)												
													SELECT @apr_usu1 = @apr_usu2, @aux = 1, @nivelC = 1
									END
								ELSE	--escalacion nivel 2
									BEGIN
											IF(@idEmpleado <> @apr_usu3 AND @apr_usu3 > 0)
													SELECT @apr_usu1 = @apr_usu3, @aux = 1, @nivelC = 2
									END
								
								IF(@aux = 1) --se escalara a alguien
									BEGIN
											UPDATE NOT_APROBACION SET apr_escalado = 1 , apr_estatus = 3 --LQMA 26072017
											WHERE not_id = @nid_not AND apr_escalado <> -1 --escala solo las aprobaciones a 1
								
											---LQMA 26072017
											DECLARE @descripcion VARCHAR(500) = '',  @not_linkBPRO VARCHAR(MAX) = '', @not_adjunto VARCHAR(MAX) = '', 
													@not_adjunto_tipo VARCHAR(500) = ''

											SELECT  @descripcion = not_descripcion, 
													@not_linkBPRO = not_link_BPRO, 
													@not_adjunto = not_adjunto, 
													@not_adjunto_tipo = not_adjunto_tipo
											FROM NOT_NOTIFICACION WHERE not_id = @nid_not

											INSERT INTO NOT_NOTIFICACION (not_tipo, not_tipo_proceso, not_identificador, not_nodo, not_descripcion, not_estatus, not_fecha, not_link_BPRO
																		, not_adjunto	, not_adjunto_tipo, not_agrupacion)
																	VALUES(7, 1	, @folio, 0	, 'Solicitud escalada. El tiempo para dar respuesta a esta solicitud ha transcurrido. Se ha escalado al siguiente nivel.  <br/><b>Escalado: </b> ' +   CONVERT(VARCHAR(10),GETDATE(),103) + ' ' + CONVERT(VARCHAR(10),GETDATE(),108)  + ' <b>  a: </b> ' + @usuarioEscalado, 2	, GETDATE()	, @not_linkBPRO, @not_adjunto, @not_adjunto_tipo, 0)

											DECLARE @idNot NUMERIC(18,0) = @@IDENTITY

											INSERT INTO NOT_APROBACION(not_id,apr_nivel,apr_visto,emp_id,apr_fecha,apr_estatus,apr_escalado)
											VALUES(@idNot,0,0,@idEmpleado,GETDATE()	,2,-1)

											SELECT @usuarioEscalado = usu_nombre + ' ' + usu_paterno + ' ' + usu_materno FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @apr_usu1

											INSERT INTO [dbo].[NOT_APROBACION]
															([not_id]
															,[apr_nivel]
															,[apr_visto]
															,[emp_id]
															,[apr_fecha]
															,[apr_estatus]
															--,[apr_comentario]
															,[apr_escalado])
													VALUES
															(@nid_not
															,@nivelC--1--0
															,0
															,@apr_usu1
															,GETDATE()
															,2--1
															--,''
															,0)

												UPDATE NOT_NOTIFICACION SET not_descripcion = REPLACE(not_descripcion,'<Usuario Escalado>',@usuarioEscalado)
												WHERE not_id = @idNot

									END--IF(@aux = 1)
								----------------------------------------------------------------------
								
								/*
								--solo se inserto al primer aprobador
								IF(SELECT COUNT(*) FROM NOT_APROBACION WHERE not_id = @nid_not AND apr_escalado <> -1) = 1
									BEGIN	--se inserta al aprobador 2

										IF @apr_usu2 > 0
											BEGIN												
													SELECT @apr_usu1 = @apr_usu2, @aux = 1
													/*
													INSERT INTO [dbo].[NOT_APROBACION]
																			([not_id]
																			,[apr_nivel]
																			,[apr_visto]
																			,[emp_id]
																			,[apr_fecha]
																			,[apr_estatus]
																			--,[apr_comentario]
																			,[apr_escalado])
																		VALUES
																			(@nid_not
																			,1--0
																			,0
																			,@apr_usu2
																			,GETDATE()
																			,2--1
																			--,''
																			,0)
													*/
											END					
										END
									ELSE
										BEGIN
											IF(SELECT COUNT(*) FROM NOT_APROBACION WHERE not_id = @nid_not AND apr_escalado <> -1) = 2 --si existen 2 aprobadores, se inserta al 3
												BEGIN
														IF @apr_usu3 > 0
														BEGIN
																SELECT @apr_usu1 = @apr_usu3, @aux = 1
																/*
																INSERT INTO [dbo].[NOT_APROBACION]
																			([not_id]
																			,[apr_nivel]
																			,[apr_visto]
																			,[emp_id]
																			,[apr_fecha]
																			,[apr_estatus]
																			--,[apr_comentario]
																			,[apr_escalado])
																		VALUES
																			(@nid_not
																			,1--0
																			,0
																			,@apr_usu3
																			,GETDATE()
																			,2--1
																			--,''
																			,0)
																*/
														END
												END
									END
							
									IF(@aux = 1)
										BEGIN									
													SELECT @usuarioEscalado = usu_nombre + ' ' + usu_paterno + ' ' + usu_materno FROM ControlAplicaciones.dbo.cat_usuarios WHERE usu_idusuario = @apr_usu1

													INSERT INTO [dbo].[NOT_APROBACION]
																			([not_id]
																			,[apr_nivel]
																			,[apr_visto]
																			,[emp_id]
																			,[apr_fecha]
																			,[apr_estatus]
																			--,[apr_comentario]
																			,[apr_escalado])
													VALUES
																			(@nid_not
																			,1--0
																			,0
																			,@apr_usu1
																			,GETDATE()
																			,2--1
																			--,''
																			,0)

												UPDATE NOT_NOTIFICACION SET not_descripcion = REPLACE(not_descripcion,'<Usuario Escalado>',@usuarioEscalado)
												WHERE not_id = @idNot
																		
										END
										*/

							END --END  @nivelC < 2

				END --IF SI EXISTE EN ORDENES DE COMPRAS


			--LQMA add 20042017 agregado, se cambio regla de negocio, se escala por usuarios del nivel 0 END

			--LQMA COMMENT 20042017 codigo original para escalar por niveles 
			/*
			--DECLARE @nid_not	int = @@IDENTITY;
			-- Si el nivel existe procede a insertar, de lo contrario cancela la orden.
			print ('Entré al proceso de inserción  Nodo: ' + convert(varchar, @idnodo) + ' proceso: ' + convert(varchar, @idtipoproceso) + ' nivel: ' + convert(varchar, @idnivel) )
			SELECT   @apr_usu1 = Usuario_Autoriza1
					, @apr_usu2 = Usuario_Autoriza2
					, @apr_usu3 = Usuario_Autoriza3 
					, @nivel_chk = Nivel_Escalamiento
			FROM  [Centralizacionv2].dbo.DIG_ESCALAMIENTO
			WHERE Nodo_Id = @idnodo and Proc_Id = @idtipoproceso and Nivel_Escalamiento = @idnivel
			print('usuario 1: ' + convert(varchar,@apr_usu1));
			print('usuario 2: ' + convert(varchar, @apr_usu2));
			print('usuario 3: ' + convert(varchar, @apr_usu3));
			-- Si el nivel que se alcanzó es mayor al configurado, cancela la orden
			SELECT @nivelC = MAX(Nivel_Escalamiento) FROM [Centralizacionv2].dbo.DIG_ESCALAMIENTO WHERE Nodo_Id = @idnodo and Proc_Id = @idtipoproceso
	
			print ('nivel maximo ' + convert(varchar,@nivelC) + ' nivel enviaron ' + convert(varchar, @idnivel))
			IF @nivelC < @idnivel
			BEGIN
				print ('Entro a cancelar 0')
				UPDATE [dbo].[NOT_NOTIFICACION] SET not_estatus = 5 WHERE not_id = @nid_not
				--UPDATE [dbo].[NOT_APROBACION] SET apr_estatus = 6 WHERE not_id = @nid_not
				UPDATE [cuentasxpagar].dbo.[cxp_ordencompra] SET sod_idsituacionorden = 4 WHERE oce_folioorden = (SELECT not_identificador FROM NOT_NOTIFICACION WHERE not_id = @nid_not)
				print ('orden cancelada 0')
			END
			IF LEN(@nivel_chk) > 0
			BEGIN
				UPDATE NOT_APROBACION SET apr_escalado = 1 WHERE not_id = @nid_not AND apr_escalado <> -1
				UPDATE NOT_APROBACION SET apr_nivel = @idnivel WHERE not_id = @nid_not AND apr_escalado = -1
			IF LEN(@apr_usu1) > 0 AND @apr_usu1 <> 0
			BEGIN
			INSERT INTO [dbo].[NOT_APROBACION]
					  ([not_id]
						,[apr_nivel]
						,[apr_visto]
						,[emp_id]
						,[apr_fecha]
						,[apr_estatus]
						--,[apr_comentario]
						,[apr_escalado])
			 VALUES
				   (@nid_not
				   ,@idnivel
				   ,0
				   ,@apr_usu1
				   ,GETDATE()
				   ,1
				   --,''
				   ,0)
				---- Agregar a NOT_APROBACION_RESPUESTA
				--INSERT INTO NOT_APROBACION_RESPUESTA
				--		(apr_id
				--		,not_id
				--		--,nar_estatus
				--		,nar_fecha
				--		,nar_comentario)
				--VALUES  
				--		(@@IDENTITY
				--		,@nid_not
				--		--,0
				--		,GETDATE()
				--		,'')
			END

			IF LEN(@apr_usu2) > 0 AND @apr_usu2 <> 0
			BEGIN
				INSERT INTO [dbo].[NOT_APROBACION]
						([not_id]
						,[apr_nivel]
						,[apr_visto]
						,[emp_id]
						,[apr_fecha]
						,[apr_estatus]
						--,[apr_comentario]
						,[apr_escalado])
				VALUES
						(@nid_not
						,@idnivel
						,0
						,@apr_usu2
						,GETDATE()
						,1
						--,''
						,0)
				---- Actualizar la aprobación - Respuesta para el nuevo apr_id
				--INSERT INTO NOT_APROBACION_RESPUESTA
				--		(apr_id
				--		,not_id
				--		--,nar_estatus
				--		,nar_fecha
				--		,nar_comentario)
				--VALUES  
				--		(@@IDENTITY
				--		,@nid_not
				--		--,0
				--		,GETDATE()
				--		,'')
				--UPDATE NOT_APROBACION_RESPUESTA SET apr_id = @@IDENTITY  WHERE not_id = @nid_not AND apr_id = 
			END

			IF LEN(@apr_usu3) > 0 AND @apr_usu3 <> 0
			BEGIN
				INSERT INTO [dbo].[NOT_APROBACION]
						([not_id]
						,[apr_nivel]
						,[apr_visto]
						,[emp_id]
						,[apr_fecha]
						,[apr_estatus]
						--,[apr_comentario]
						,[apr_escalado])
				VALUES
						(@nid_not
						,@idnivel
						,0
						,@apr_usu3
						,GETDATE()
						,1
						--,''
						,0)
						-- Agregar a NOT_APROBACION_RESPUESTA
				--INSERT INTO NOT_APROBACION_RESPUESTA
				--		(apr_id
				--		,not_id
				--		--,nar_estatus
				--		,nar_fecha
				--		,nar_comentario)
				--VALUES  
				--		(@@IDENTITY
				--		,@nid_not
				--		--,0
				--		,GETDATE()
				--		,'')
			END
			--ELSE
			--BEGIN
			-- Cancelar la orden
			--print ('Entro a cancelar 1')
			--	UPDATE [dbo].[NOT_NOTIFICACION] SET not_estatus = 5 WHERE not_id = @nid_not
			--	UPDATE [dbo].[NOT_APROBACION] SET apr_estatus = 6 WHERE not_id = @nid_not
			--	UPDATE [cuentasxpagar].dbo.[cxp_ordencompra] SET sod_idsituacionorden = 5 WHERE oce_folioorden = (SELECT not_identificador FROM NOT_NOTIFICACION WHERE not_id = @nid_not)
			--print ('orden cancelada 1')
			--END
			-- Si el nivel que se alcanzó es mayor al configurado, cancela la orden
			SELECT @nivelC = MAX(Nivel_Escalamiento) FROM [Centralizacionv2].dbo.DIG_ESCALAMIENTO WHERE Nodo_Id = @idnodo and Proc_Id = @idtipoproceso
			IF @idnivel > @nivelC
			BEGIN
			print ('Entro a cancelar 2')
				UPDATE [dbo].[NOT_NOTIFICACION] SET not_estatus = 5 WHERE not_id = @nid_not
				UPDATE [dbo].[NOT_APROBACION] SET apr_estatus = 6 WHERE not_id = @nid_not
				UPDATE [cuentasxpagar].dbo.[cxp_ordencompra] SET sod_idsituacionorden = 5 WHERE oce_folioorden = (SELECT not_identificador FROM NOT_NOTIFICACION WHERE not_id = @nid_not)
			print ('orden cancelada 2')
			END

			
		END
		*/
		 --COMMIT TRAN
		 print 0;
		END TRY
		BEGIN CATCH
			PRINT ('Error: ' + ERROR_MESSAGE())
			DECLARE @Mensaje  nvarchar(max),
			@Componente nvarchar(50) = 'INS_ESCALACION_SYS_SP'
			SELECT @Mensaje = ERROR_MESSAGE()
			RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
		END CATCH
END
go

