-- =============================================
-- Author:		<Irving Solorio>
-- Create date: <11/11/2019>
-- Description:	<Aprobacion 1era y 2da>
-- =============================================
--select * from NOT_NOTIFICACION where not_id=327376
--SELECT * FROM NOT_APROBACION where not_id=327376
--select top 100 * from [Centralizacionv2].[DBO].[BITACORA_PROCESOS]
--[UPD_APROBACION_PLANTILLA_SP] 638198,1,''
CREATE PROCEDURE [dbo].[UPD_APROBACION_PLANTILLA_SP]
	 @idAprobacion INT = 0
	,@respuesta   INT = 0
	,@observacion VARCHAR(max) = ''
AS
	

	DECLARE @idEstatus INT = 0, @mensaje VARCHAR(500) = '',@numNot int=0
	DECLARE @idnotificacion int
	DECLARE @proceso int
	DECLARE @folio int,@grupo int
	DECLARE @not_identificador VARCHAR(100) = ''
	DECLARE @idplantillasenc int
	DECLARE @idEmpresa int
	DECLARE @idSucursal int,@usuario int

		
	SELECT @idnotificacion = not_id,@usuario=emp_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion
	--		     select @idnotificacion,@usuario
	SELECT @folio = not_identificador ,@grupo=not_agrupacion,@idEmpresa=idEmpresa,@idSucursal=idSucursal FROM dbo.NOT_NOTIFICACION  WHERE not_id = @idnotificacion
	--select @idnotificacion,@usuario,@folio,@grupo,@idEmpresa,@idSucursal

	IF EXISTS(SELECT a.not_id FROM NOT_NOTIFICACION n inner join not_aprobacion a on n.not_id=a.not_id WHERE a.not_id = @idnotificacion and a.apr_id = @idAprobacion AND not_tipo IN (1) AND not_nodo = 1 AND not_estatus in(3,4,5) and a.apr_estatus in(3,4,5))
		BEGIN
			-- Si ya fue aprobada no hace la actualizacion y la pone como retrasada adicionalmente sale con 5
			PRINT 'Ya existe'
			UPDATE NOT_APROBACION SET apr_estatus = 5 WHERE apr_id = @idAprobacion
			SET @idEstatus = -1
			SET @mensaje = 'La solicitud fue aprobada previamente por otro autorizador.' 
		END
		ELSE	
		BEGIN
		BEGIN TRAN TRAN_UPD_APROBACION
		BEGIN TRY
			SELECT @idEstatus = 0, @mensaje = 'La solicitud ha sido procesada.'

			INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
			VALUES (@grupo,'UPD_APROBACION_PLANTILLA_SP @folio: ' + CONVERT(VARCHAR(30),@folio) ,GETDATE())		
			if @grupo=34				
			Begin
			print'caso 34 1'
							select @numNot=count(*) from not_aprobacion a 
							inner join NOT_NOTIFICACION n on a.not_id=n.not_id
							where n.not_identificador =convert(nvarchar(6),@folio) and not_agrupacion=@grupo and idempresa=@idEmpresa and idsucursal= @idSucursal
					print @numNot
							if @numNot=1
							begin
							print @folio
								if @respuesta=1
								begin
									EXECUTE  Notificacion.[dbo].[INS_APROBACION_PLANTILLA2da_SP] 
									@folio
									,@idEmpresa
									,@idSucursal
								end
								else
								begin
								update c set c.ple_estatusgen= case when @respuesta= 1 then 1 else 2 end from ga_corporativa.dbo.cxp_plantillasenc c where ple_idplantillasenc=@folio
								end
								UPDATE NOT_NOTIFICACION SET not_estatus = case when @respuesta= 1 then 3 else 4 end  WHERE not_id = @idnotificacion
								UPDATE NOT_APROBACION SET apr_estatus = case when @respuesta= 1 then 3 else 4 end WHERE apr_id = @idAprobacion;
								INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
															(not_id,[apr_id],[nar_fecha],[nar_comentario])
														VALUES
															(@idnotificacion,@idAprobacion,GETDATE(),@observacion)	

															
							End
							else if @numNot=2
							begin
							print'caso 34 2'
								update c set c.ple_estatusgen= case when @respuesta= 1 then 1 else 2 end from ga_corporativa.dbo.cxp_plantillasenc c where ple_idplantillasenc=@folio

								INSERT INTO ga_corporativa.[dbo].[cxp_plantillaslogacciones]
										   ([pll_accion]
										   ,[pll_fecha]
										   ,[ple_idplantillasenc]
										   ,[pll_usuario])
									 VALUES
										   (case when @respuesta= 1 then 1 else 2 end
										   ,convert(nvarchar(10),getdate(),103)
										   ,@folio
										   ,@usuario)

								UPDATE NOT_NOTIFICACION SET not_estatus = case when @respuesta= 1 then 3 else 4 end WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
								UPDATE NOT_APROBACION SET apr_estatus = case when @respuesta= 1 then 3 else 4 end WHERE apr_id = @idAprobacion;
								INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
															(not_id,[apr_id],[nar_fecha],[nar_comentario])
														VALUES
															(@idnotificacion,@idAprobacion,GETDATE(),@observacion)	
															
												
							end
			End
			else if @grupo=35
			begin
			print'caso 35 1'
				update c set c.ple_estatusgen= case when @respuesta= 1 then 4 else 1 end from ga_corporativa.dbo.cxp_plantillasenc c where ple_idplantillasenc=@folio

				INSERT INTO ga_corporativa.[dbo].[cxp_plantillaslogacciones]
							([pll_accion]
							,[pll_fecha]
							,[ple_idplantillasenc]
							,[pll_usuario])
						VALUES
							(case when @respuesta= 1 then 4 else 1 end
							,convert(nvarchar(10),getdate(),103)
							,@folio
							,@usuario)

				UPDATE NOT_NOTIFICACION SET not_estatus = case when @respuesta= 1 then 3 else 4 end WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
				UPDATE NOT_APROBACION SET apr_estatus = case when @respuesta= 1 then 3 else 4 end WHERE apr_id = @idAprobacion;
				INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
											(not_id,[apr_id],[nar_fecha],[nar_comentario])
										VALUES
											(@idnotificacion,@idAprobacion,GETDATE(),@observacion)	
			End
					
			SELECT @idEstatus estatus, @mensaje mensaje 

			COMMIT TRAN TRAN_UPD_APROBACION
	
		END TRY
		BEGIN CATCH

			ROLLBACK TRAN TRAN_UPD_APROBACION
	
			DECLARE @Componente VARCHAR(50) = 'UPD_APROBACION_PLANTILLA_SP', @errorMensaje VARCHAR(MAX) = ERROR_MESSAGE() + ' - Folio: ' + CONVERT(VARCHAR(30),@folio) 
			DECLARE @tablaRespuesta TABLE(idError INT)
			INSERT INTO @tablaRespuesta
			EXECUTE INS_ERROR_SP @Componente, @errorMensaje
					
			SELECT ERROR_NUMBER() estatus, 'No se pudo ejecutar el proceso. Intente de nuevo.' mensaje

		END CATCH;
END


go

