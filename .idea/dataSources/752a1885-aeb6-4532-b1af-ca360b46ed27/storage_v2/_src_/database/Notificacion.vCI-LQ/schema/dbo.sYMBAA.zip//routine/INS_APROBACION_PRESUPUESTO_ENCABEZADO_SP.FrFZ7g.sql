-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	Inserta notificación de presupuesto encabezado con not_agrupacion=5
-- =============================================
--[dbo].[INS_APROBACION_PRESUPUESTO_ENCABEZADO_SP] 7,'4|12|67|33','Aqui va la descripción',2,'','13_Presupuesto','pdf',2,15
--[INS_APROBACION_PRESUPUESTO_ENCABEZADO_SP] 7, '1|3|11|28', 'Solicitud de Autorización del Presupuesto con cargo Interno : 28', 2, '', '28_Presupuesto.pdf', 'pdf', 0, 119
CREATE PROCEDURE  [dbo].[INS_APROBACION_PRESUPUESTO_ENCABEZADO_SP] 
	@idtipoproceso int
	,@identificador varchar(50) --id_empresa|id_sucursal|id_depto|no_presupuesto
	,@descripcion varchar(500)
	,@estatus int
	,@linkBPRO varchar(MAX) = NULL
	,@adjunto varchar(MAX) = NULL --Solo me llegara el nombre tengo que buscarlo en la ruta xej. C:\GA_Centralizacion\CuentasXCobrar\OtrosDoc\DocVarios\AU-ZM\ZAR
	,@idtipoadjunto	varchar(500)
	,@solicitante numeric(18,0) 
	,@aprobador	numeric(18,0) 
AS
BEGIN
	SET NOCOUNT ON;
	-- Inserta una notificación de tipo aprobación

	--LQMA 05070217
	BEGIN TRAN TRAN_APROBACION_ENCABEZADO

	BEGIN TRY
	-- Obtiene la descripción de [cuentasporcobrar].[dbo].[ser_presupweb]

		--Busca descripción con lo obtenido de @identificador xej. '4|12|67|30'
		---------------***************************************************************************
		
		DECLARE @cadena VARCHAR(50) = @identificador, @idEmpresa VARCHAR(10) = '', @idSucursal VARCHAR(10) = '', @idDepartamento VARCHAR(10) = '', @noPresupuesto VARCHAR(10)
		DECLARE @idDivision INT, @division VARCHAR(10), @departamento VARCHAR(10), @ruta VARCHAR(MAX)
		
		--DECLARE @cadena VARCHAR(50) = '4|12|67|30', @idEmpresa VARCHAR(10) = '', @idSucursal VARCHAR(10) = '', @idDepartamento VARCHAR(10) = '', @noPresupuesto VARCHAR(10)
		
		SELECT @idEmpresa = SUBSTRING(@cadena,1,CHARINDEX('|',@cadena)-1) 
		SELECT @cadena = SUBSTRING(@cadena,CHARINDEX('|',@cadena)+1,100)	

		SELECT @idSucursal = SUBSTRING(@cadena,1,CHARINDEX('|',@cadena)-1)
		SELECT @cadena = SUBSTRING(@cadena,CHARINDEX('|',@cadena)+1,100)	
		
		SELECT @idDepartamento = SUBSTRING(@cadena,1,CHARINDEX('|',@cadena)-1)
		SELECT @cadena = SUBSTRING(@cadena,CHARINDEX('|',@cadena)+1,100)	

		SELECT @noPresupuesto = SUBSTRING(@cadena,1,100)		

	   SELECT	@idDivision = prw_iddivision
				FROM [cuentasporcobrar].[dbo].[ser_presupweb] 
				WHERE prw_idempresa = @idEmpresa AND prw_idsucursal=@idSucursal AND prw_iddepartamento=@idDepartamento AND prw_nopresupuesto=@noPresupuesto
	   SET @division=(SELECT div_nombrecto FROM [ControlAplicaciones].[dbo].[cat_divisiones] WHERE div_iddivision=@idDivision)	
	   SET @departamento=(SELECT dep_nombrecto FROM [ControlAplicaciones].[dbo].[cat_departamentos] WHERE dep_iddepartamento=@idDepartamento)	
	   --set @descripcion='Hola Notificaciones';
	   --print @descripcion
	   --print @noPresupuesto	   
		---------------***************************************************************************
		--Para conseguir el indentificador con el que despues le dare la ruta para buscar el archivo 
		--$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		DECLARE @empresa VARCHAR(10), @sucursal VARCHAR(10), @empSuc VARCHAR(20), @idEncabezado VARCHAR(10)
		DECLARE @TabBases TABLE (ID INT IDENTITY(1,1),NombreBase VARCHAR(50), ip_server VARCHAR(30), emp_nombrecto VARCHAR(10), idEmpresa INT, suc_nombrecto VARCHAR(10), suc_idsucursal INT)

			INSERT INTO @TabBases
			SELECT DISTINCT [nombre_base],[ip_servidor],catEmp.[emp_nombrecto], catEmp.[emp_idempresa], catSuc.[suc_nombrecto],catSuc.suc_idsucursal
			FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] BASES
			INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] catEmp ON BASES.[catemp_nombrecto] = catEmp.[emp_nombrecto]
			INNER JOIN [ControlAplicaciones].[dbo].[CAT_SUCURSALES] catSuc ON BASES.[catsuc_nombrecto] = catSuc.[suc_nombrecto]
			 
		SELECT @empresa=emp_nombrecto, @sucursal=suc_nombrecto FROM @TabBases WHERE idEmpresa=@idEmpresa AND suc_idsucursal=@idSucursal
		SELECT @idEncabezado = prw_idpresuorden FROM [cuentasporcobrar].[dbo].[ser_presupweb] WHERE prw_idempresa = @idEmpresa AND prw_idsucursal=@idSucursal 
																									AND prw_iddepartamento=@idDepartamento AND prw_nopresupuesto=@noPresupuesto
		SET @empSuc=  @empresa +'/'+ @sucursal +' '+@noPresupuesto
		print @empSuc +'Soy la empresa'
		--$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	   --Aqui se genera la ruta para buscar el archivo 
	   --LQMA 15022017
		DECLARE @ip_server VARCHAR(50) = ''
		SELECT @ip_server = par_valor FROM NOT_PARAMETROS WHERE par_id = 2
	   --Aqui se genera la ruta para buscar el archivo 
	   SET @ruta= @ip_server + 'GA_Centralizacion/CuentasXCobrar/OtrosDoc/DocVarios/'+@division+'-'+@empresa+'/'+@sucursal+'/'+@adjunto+'.'+@idtipoadjunto
	   print @ruta
	   --++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++				
		
		INSERT INTO NOT_NOTIFICACION (not_tipo
		, not_tipo_proceso
		, not_identificador
		, not_nodo
		, not_descripcion
		, not_estatus
		, not_fecha
		, not_link_BPRO
		, not_adjunto
		, not_adjunto_tipo
		, not_agrupacion
		,idEmpresa
		,idSucursal)
		VALUES
		( 1
		, @idtipoproceso
		, @empSuc
		,''
		, @descripcion
		, @estatus
		, GETDATE()
		, @linkBPRO
		, @ruta
		, @idtipoadjunto
		, 5
		, @idEmpresa
		, @idSucursal
		)


	DECLARE @nid_not int = @@IDENTITY;

--Solicitante
--LQMA  add 17062016   si aprobador = solicitante, solo se inserta aprobador
----------------------------------
IF(@aprobador != @solicitante) --si aprobador es diferente de solicitante, se inserta solicitante
	BEGIN
		INSERT INTO [dbo].[NOT_APROBACION]
			   ([not_id]
			   ,[apr_nivel]
			   ,[apr_visto]
			   ,[emp_id]
			   ,[apr_fecha]
			   ,[apr_estatus]
			   ,[apr_escalado])
		 VALUES
			   (@nid_not
			   ,0
			   ,NULL
			   ,@solicitante
			   ,GETDATE()
			   ,1
			   ,-1)
	END
		   
--Aprobador
----------------------------------
	INSERT INTO [dbo].[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
           ,[apr_escalado])
     VALUES
           (@nid_not
		   ,0
		   ,NULL
           ,@aprobador
           ,GETDATE()
           ,1
           ,0)
	

--Actualiza el estatus de la notificación a 2
----------------------------------
	UPDATE NOT_NOTIFICACION SET not_estatus = 2 
		WHERE not_id =@nid_not

	--LQMA 05070217
	COMMIT TRAN TRAN_APROBACION_ENCABEZADO
		
	--EXECUTE [dbo].[INS_APROBACION_PRESUPUESTO_DETALLE_SP] @idtipoproceso,@identificador,@descripcion,@estatus,@linkBPRO,@adjunto,@idtipoadjunto,@solicitante,@aprobador
	Select 0 error
	
END TRY
BEGIN CATCH

	--LQMA 05070217
	ROLLBACK TRAN TRAN_APROBACION_ENCABEZADO

	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_APROBACION_PRESUPUESTO_ENCABEZADO_SP'
	SELECT ERROR_NUMBER() error
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	
END CATCH
END



go

