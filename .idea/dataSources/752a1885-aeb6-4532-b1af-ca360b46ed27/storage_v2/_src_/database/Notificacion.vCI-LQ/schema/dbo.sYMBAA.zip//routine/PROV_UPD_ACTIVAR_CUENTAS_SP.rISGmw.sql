CREATE PROCEDURE [dbo].[PROV_UPD_ACTIVAR_CUENTAS_SP]
 @rfc VARCHAR(50)
,@idPerTra INT 
,@result INT OUTPUT
AS

BEGIN
BEGIN TRY


--DECLARE @rfc VARCHAR(50) =  'AAA010101106'
--DECLARE @idPerTra INT  = 119

--SELECT TOP 1 @idPersona =  PER_IDPERSONA FROM GA_CORPORATIVA.dbo.PER_PERSONAS WHERE PER_RFC = @rfc order by PER_IDPERSONA asc
--SELECT @idPersona

DECLARE @idPersona NUMERIC(18,0)
/***************UNIFICAR CUENTAS*******************************/
		DECLARE @BASES TABLE(id int identity(1,1),emp_idempresa INT,base nvarchar(200))
		
		DECLARE @contBases INT = 1, @numRegistros INT = 0, @contBancos INT = 1, @banxico VARCHAR(20), @numRegistrosCuentas INT = 0, @existe INT,@emp_idempresa INT,  @idRespuestaUni   INT, @cie VARCHAR(50), @noCuenta VARCHAR(50)
		DECLARE @basePrincipal VARCHAR(50) = '', @queryCuentaSel NVARCHAR(MAX) = '', @queryBanco NVARCHAR(MAX) = '', @SQLString NVARCHAR(MAX), @sqlUni VARCHAR(MAX)
		DECLARE @ParmDefinition nvarchar(500) 

	

		DECLARE @provBanco TABLE (
				id int identity(1,1),
				[idProspecto] [int] NULL,
				[titular] [varchar](100) NULL,
				[banco] [varchar](50) NULL,
				[sucursal] [varchar](50) NULL,
				[noCuenta] [varchar](30) NULL,
				[clabe] [varchar](30) NULL,
				[cie] [varchar](10) NULL,
				[referencia] [varchar](50) NULL,
				[cveBanxico] [varchar](10) NULL,
				[cveBanco] [varchar](50) NULL,
				[tipoCtaBancaria] [varchar](20) NULL,
				[nombreTipoCtaBancaria] [varchar](50) NULL,
				[empresaId] [int] NULL,
				PER_IDPERSONA NUMERIC(18,0) NULL
			)

		INSERT INTO @BASES
		SELECT emp_idempresa ,nombre_base  FROM  [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] WHERE tipo = 2 

		SET @numRegistros = (select COUNT(1) from @BASES)

		INSERT INTO @provBanco
		SELECT 
			  [idProspecto]
			  ,[titular]
			  ,[banco]
			  ,[sucursal]
			  ,[noCuenta]
			  ,[clabe]
			  ,[cie]
			  ,[referencia]
			  ,[cveBanxico]
			  ,[cveBanco]
			  ,[tipoCtaBancaria]
			  ,[nombreTipoCtaBancaria]
			  ,[empresaId]
			  ,PER_IDPERSONA
		  FROM [Centralizacionv2].dbo.[PROV_CUENTA_BANCARIA]
		  WHERE IdPerTra = @idPerTra


		  SET  @numRegistrosCuentas = (select  COUNT(1) from @provBanco)


		  WHILE(@contBancos<= @numRegistrosCuentas)
		  BEGIN
			--SELECT @contBancos '@contBancos'
			SET @contBases  = 1
				select @banxico = cveBanxico, @cie = cie, @noCuenta = noCuenta, @idPersona = PER_IDPERSONA FROM @provBanco WHERE id = @contBancos
				--select @banxico, @cie, @noCuenta
				
				WHILE(@contBases<= @numRegistros)
				BEGIN
					
					SELECT @basePrincipal = base, @emp_idempresa = emp_idempresa FROM @BASES WHERE id = @contBases
					IF  EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE (name = @basePrincipal)) 
					BEGIN
						
							SET @sqlUni =	'UPDATE  ' +@basePrincipal+'.[dbo].[CON_BANCOS]
														SET [BCO_AUTORIZADA] = 1 
											 WHERE BCO_IDPERSONA = '+ CONVERT(VARCHAR(10),@idPersona)+ '
											 AND [BCO_NUMCUENTA] =  '''+ @noCuenta + ''''
						
							exec (@sqlUni)
							--print (@sql)
					END
					SET @contBases= @contBases+1 
				END
				SET @contBancos = @contBancos+1
		  END


		  UPDATE [Centralizacionv2].dbo.PROV_CUENTA_BANCARIA 
		  SET autorizada = 1
		  WHERE idPerTra = @idPerTra

		  SET  @result = 1

		  return @result

END TRY
BEGIN CATCH

		SET  @result = 0

		RETURN @result


		


END CATCH
END

go

