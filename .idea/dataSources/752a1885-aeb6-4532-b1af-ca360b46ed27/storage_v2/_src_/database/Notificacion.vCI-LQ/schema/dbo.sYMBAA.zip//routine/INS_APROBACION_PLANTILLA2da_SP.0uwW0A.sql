-- =============================================
-- Author: Genaro Mora Valencia
-- Create date: 03/12/2015
-- Description:	Inserta notificacion de gastos recurrentes
-- =============================================
--[dbo].[INS_APROBACION_PLANTILLA2da_SP] 23,4,6
--select cat_valor from Centralizacionv2.dbo.DIG_CATALOGOS where cat_id_padre=2200 and cat_nombre= convert(nvarchar(6),4)+'|'+ convert(nvarchar(6),6) 
--select * from [Notificacion].[dbo].[NOT_NOTIFICACION] where not_identificador=convert(nvarchar(6),23) and idEmpresa=4 and idsucursal=6 and not_agrupacion=34 and not_estatus=2
create PROCEDURE [dbo].[INS_APROBACION_PLANTILLA2da_SP]
@idplantillasenc int,
@idEmpresa int,
@idSucursal int
AS
BEGIN
	SET NOCOUNT ON;
Declare @idNot int,@aprobador int
select @aprobador=cat_valor from Centralizacionv2.dbo.DIG_CATALOGOS where cat_id_padre=2300 and cat_nombre= convert(nvarchar(6),@idEmpresa)+'|'+ convert(nvarchar(6),@idSucursal)
if exists(select not_id from [Notificacion].[dbo].[NOT_NOTIFICACION] where not_identificador=convert(nvarchar(6),@idplantillasenc) and idEmpresa=@idempresa and idsucursal=@idsucursal and not_agrupacion=34 and not_estatus=2) and @aprobador is not null
begin
INSERT INTO [Notificacion].[dbo].[NOT_NOTIFICACION]
           ([not_tipo]
           ,[not_tipo_proceso]
           ,[not_identificador]
           ,[not_nodo]
           ,[not_descripcion]
           ,[not_estatus]
           ,[not_fecha]
           ,[not_link_BPRO]
           ,[not_adjunto]
           ,[not_adjunto_tipo]
           ,[not_agrupacion]
           ,[idEmpresa]
           ,[idSucursal])
SELECT 1,																--<not_tipo, int,>
        1,																--,<not_tipo_proceso, int,>
        convert(nvarchar(6),@idplantillasenc),							--,<not_identificador, nvarchar(50),>
		1,																--,<not_nodo, int,>
		'Solicitud de autorizacion de la plantilla num:'+convert(nvarchar(6),ple_idplantillasenc)+' '+ple_observaciones,	--,<not_descripcion, nvarchar(max),>
		2,																--,<not_estatus, int,>
		getdate(),														--,<not_fecha, datetime,>
		'direcccion',													--,<not_link_BPRO, nvarchar(max),>
		'',																--,<not_adjunto, nvarchar(max),>
		'',																--,<not_adjunto_tipo, nvarchar(500),>
		34,																--,<not_agrupacion, int,>
		ple_idempresa,													--,<idEmpresa, int,>
		ple_idsucursal													--,<idSucursal, int,>)
 FROM   [GA_Corporativa].[dbo].[cxp_plantillasenc]   WHERE ple_idplantillasenc=@idplantillasenc
 SET @idNot  = SCOPE_IDENTITY()
select @aprobador=cat_valor from Centralizacionv2.dbo.DIG_CATALOGOS where cat_id_padre=2300 and cat_nombre= convert(nvarchar(6),@idEmpresa)+'|'+ convert(nvarchar(6),@idSucursal)						
		INSERT INTO  [Notificacion].[dbo].[NOT_APROBACION]
		([not_id]
		,[apr_nivel]
		,[apr_visto]
		,[emp_id]
		,[apr_fecha]
		,[apr_estatus]
		,[apr_escalado])
		VALUES
		(@idNot
		,0
		,NULL
		,@aprobador
		,GETDATE()
		,2
		,0)
-- select 1 success, '' msg
 end
-- else
-- begin
---- select 0, 'Ya existe la notificación o no existe el aprobador' msg,@aprobador aprobador
-- End
END

--delete from [Notificacion].[dbo].[NOT_NOTIFICACION] where not_identificador=convert(nvarchar(6),23) and idEmpresa=4 and idsucursal=6 and not_agrupacion=34
go

