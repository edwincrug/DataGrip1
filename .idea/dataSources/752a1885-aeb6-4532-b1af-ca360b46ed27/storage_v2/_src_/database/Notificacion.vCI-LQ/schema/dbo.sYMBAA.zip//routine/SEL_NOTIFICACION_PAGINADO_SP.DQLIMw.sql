--/****** Object:  StoredProcedure [dbo].[SEL_NOTIFICACION_SP]    Script Date: 21/04/2020 10:58:09 a. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--select * from NOT_NOTIFICACION where not_agrupacion = 4
-- =============================================
-- Description: Stored que recupera las notificaciones de un empleado
-- =============================================
-- EXECUTE [SEL_NOTIFICACION_PAGINADO_SP] 71,10
CREATE PROCEDURE [dbo].[SEL_NOTIFICACION_PAGINADO_SP] 
	@idEmpleado   nvarchar(50)
	,@top INT
	,@filtro INT  = 0
	,@fechaIni VARCHAR(10) = ''
	,@fechaFin VARCHAR(10) = ''
AS
BEGIN


--DECLARE @idEmpleado   nvarchar(50) = 71
--		,@top INT = 10
--		,@filtro INT  = 0
--		,@fechaIni VARCHAR(10) = '20190801'
--		,@fechaFin VARCHAR(10) = '20191001'

	  
		

SET NOCOUNT ON;
	BEGIN TRY
			
			DECLARE @ipLocal VARCHAR(50) = ''
			
			SELECT	@ipLocal = local_net_address
			FROM	sys.dm_exec_connections
			WHERE	Session_id = @@SPID;

		
	
			DECLARE @TabBases TABLE (ID INT IDENTITY(1,1),NombreBase VARCHAR(50), ip_server VARCHAR(30), emp_nombrecto VARCHAR(10), idEmpresa INT, suc_nombrecto VARCHAR(10), suc_idsucursal INT)

			INSERT INTO @TabBases
			SELECT DISTINCT (CASE WHEN @ipLocal = ip_servidor THEN '[' + nombre_base + '].[dbo].'
									   ELSE '['+ ip_servidor + '].[' + nombre_base + '].[dbo].' END),[ip_servidor],catEmp.[emp_nombrecto], catEmp.[emp_idempresa], catSuc.[suc_nombrecto],catSuc.suc_idsucursal
			FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] BASES
			INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] catEmp ON BASES.[catemp_nombrecto] = catEmp.[emp_nombrecto]
			INNER JOIN [ControlAplicaciones].[dbo].[CAT_SUCURSALES] catSuc ON BASES.[catsuc_nombrecto] = catSuc.[suc_nombrecto]
			--//////////////
			--SELECT * FROM @TabBases
			--/////////////
			DECLARE @VarPlantas TABLE (ID INT IDENTITY(1,1),IDPROVEEDOR int, idEmpresa INT, idSucursal INT)

			DECLARE @aux INT = 1, @max INT = 0, @nombreBase VARCHAR(50) = '', @idEmpresa INT = 0, @idSucursal INT = 0 
			SELECT @max = MAX(ID) FROM @TabBases
   
			   WHILE(@aux <= @max)
					BEGIN 
							SELECT @nombreBase = NombreBase,@idEmpresa = idEmpresa, @idSucursal = suc_idsucursal FROM @TabBases WHERE ID = @aux

							--IF  OBJECT_ID (N'[ControlAplicaciones].[dbo].[' +@nombreBase +']', N'U') IS NOT NULL  
							IF exists (select 1 from sys.databases where [name] = @nombreBase)
								INSERT INTO @VarPlantas EXECUTE('SELECT PAR_DESCRIP2, CONVERT(VARCHAR(10),' + @idEmpresa +') idEmpresa, CONVERT(VARCHAR(10),' + @idSucursal +') idSucursal FROM  ' + @nombreBase + '..PNC_PARAMETR WHERE PAR_TIPOPARA = ' + '''' + 'PLANTA' + '''')
							ELSE 
								PRINT @nombreBase

							SET @aux = @aux + 1
					END
			--//////////
			--SELECT * FROM @VarPlantas
			--//////////

			IF(@filtro = 0) SET @filtro = NULL
			IF(@fechaIni = '') SET @fechaIni = NULL
			IF(@fechaFin = '') SET @fechaFin = NULL

			
			SELECT TOP (@top) N.not_id AS id
					, A.apr_id as idAprobacion
					, A.emp_id AS idEmpleado
					, CASE N.not_agrupacion  
						WHEN 0 THEN U.usu_idusuario 
						ELSE sap.usu_idusuario
						END AS idSolicitante
					, CASE N.not_agrupacion  
						WHEN 0 THEN ISNULL(U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno, '')
						ELSE ISNULL(sap.usu_nombre + ' ' + sap.usu_paterno + ' ' + sap.usu_materno, '')
						END AS solicitante
					, N.not_tipo_proceso AS tipoProceso
					, N.not_nodo AS etapaProceso 
					--, ISNULL(S.suc_nombre, 'N/A') as agencia 
					--, CASE WHEN S.suc_nombre IS NOT NULL THEN S.suc_nombre ELSE  ISNULL(SC.suc_nombre, 'N/A') END  AS agencia
					--CAMBIO FERNANDO ALVARADO 23092019 PARA IDENTIFICAR OPERACIONES DE PAGOS 
					, CASE WHEN S.suc_nombre IS NOT NULL THEN S.suc_nombre ELSE 
					  CASE  N.not_agrupacion
					  WHEN 1 THEN PAG.pal_observacion 
					  ELSE  ISNULL(SC.suc_nombre, 'N/A')
					  END
					 END  AS agencia
					, ISNULL(D.dep_nombre, 'N/A')  as departamento					
					--Valida las decripciones de la Agrupacion 
					,CASE  N.not_agrupacion 
						WHEN 0 THEN (CASE WHEN N.not_identificador != '' THEN N.not_identificador ELSE 'Alerta' END) 
						WHEN 1 THEN  'Aprobacion de pago Lote: ' + N.not_identificador 
						--WHEN 2 THEN (select TOP(1) 'Flotilla: ' + flo_nombreflotilla + ' ['+ CONVERT(varchar(max),flo_cantidad) + '] ' as flt_nombre FROM dbo.Flotilla_Cuentasxpagar WHERE flo_numeroflotilla=N.not_identificador) --LQMA COMMENT 13072016 original
						  WHEN 2 THEN (select TOP(1) 'Flotilla: ' + flo_nombreflotilla + ' ['+ CONVERT(varchar(max),flo_cantidad) + '] ' as flt_nombre FROM dbo.Flotilla_Cuentasxpagar WHERE flo_idempresa = [dbo].[splitCadena_fn](N.not_identificador,'|',1) AND flo_idsucursal = [dbo].[splitCadena_fn](N.not_identificador,'|',2) AND flo_numeroflotilla=[dbo].[splitCadena_fn](N.not_identificador,'|',3)) 
						  WHEN 3 THEN 'Recepción - ' + N.not_identificador
						  --WHEN 4 THEN 'Validación de dirección - ' + (SELECT ISNULL(Us.name,'') FROM refacciones..Direcciones DIR JOIN refacciones..Users Us ON DIR.RTD_IDPERSONA = Us.per_idpersona WHERE idDireccion = CASE WHEN N.not_identificador = '' THEN 0 WHEN N.not_identificador IS NULL THEN 0 ELSE N.not_identificador END)
						  WHEN 5 THEN 'Aprobación de presupuesto: '+N.not_identificador -- Para notificaciones de presupuesto encabezado
						  WHEN 6 THEN 'Aprobación adicional presupuesto: '+N.not_identificador --Para notificaciones del detalle del presupuesto
						  WHEN 7 THEN 'Cotización: '+N.not_identificador --Para notificaciones de cotización 
						  WHEN 8 THEN 'Sin anticipo: '+ N.not_identificador --Para notificaciones de anticipos
						  WHEN 9 THEN 'Solicitud de Cancelación - ' + N.not_identificador --LQMA add 12042017 tipo cancelacion
						  WHEN 10 THEN 'Solicitud de cambio de inventario VIN : ' + N.not_identificador --LQMA add 28062017 inventario
						  WHEN 11 THEN 'Solicitud de desapartado de Unidad - Orden : ' + N.not_identificador --LQMA add 28062017 inventario
						  WHEN 12 THEN 'Solicitud de desapartado de unidad, Número de Serie: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'
						  WHEN 13 THEN 'Solicitud de Conceptos Adicionales de la Cotizacion: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'
						  WHEN 14 THEN 'Solicitud de PLAN PISO - Valida Conciliación: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'	
						  WHEN 15 THEN 'Solicitud de PLAN PISO - Cancela Conciliación: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'	
						  WHEN 16 THEN 'Traspasos entre financiera, cambio de fecha promesa de pago: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'	
						  WHEN 17 THEN 'Solicitud de Cotización de Unidad: ' + N.not_identificador --Para notificaciones de unidades con estatus ingresada 'ING'	
						  WHEN 18 THEN 'Solicitud de Revisión de Lote: ' + N.not_identificador --Para revisiones de lotes de pago	
						  WHEN 19 THEN 'Solicitud de Cancelación CC: ' + N.not_identificador --Para revisiones de lotes de pago	
						  WHEN 20 THEN 'Solicitud de Notificación de Prueba: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 21 THEN 'Autorización de porcentaje de utilidad: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 22 THEN 'Autorización de crédito flotilla: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 23 THEN 'Autorización de Cuentas Bancarias: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 24 THEN 'Autorización de Crédito Finanzas: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 25 THEN 'Autorización de Crédito Comite: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 26 THEN 'Autorización de Devolución: ' + N.not_identificador --Notificaciones para las devoluciones
						  WHEN 27 THEN 'Autorización de Devolución Comite: ' + N.not_identificador --Notificaciones para las devoluciones del comite
						  WHEN 28 THEN 'Autorización de apartado de unidades: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 29 THEN 'Autorización de crédito Clientes - Gerente: ' + N.not_identificador --Nuevas notificaciones
  						  WHEN 31 THEN 'Autorización de venta de traslados por debajo del margen: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 32 THEN 'Autorización de Fondo Fijo: ' + N.not_identificador --Nuevas notificaciones
						  WHEN 33 THEN 'Autorización de CC: ' + N.not_identificador --Autorizacion para los CC
						  WHEN 34 THEN 'Solicitud de autorización de plantilla : ' + N.not_identificador --Gastos recurrentes
						  WHEN 35 THEN 'Solicitud de finalización de plantilla : ' + N.not_identificador --Finalización Gastos recurrentes
						  WHEN 36 THEN 'Transferencias Cuentas Bancarias '+ N.not_identificador
						  WHEN 38 THEN 'Aprobar Cotización de Flotillas: '+ N.not_identificador
						  WHEN 39 THEN 'Aprobación de Cargo Interno a Cotización de Flotillas: ' + N.not_identificador 
						  WHEN 37 THEN 'Aprobar Vale: ' + N.not_identificador --Nuevas notificaciones para aprobar vale
						  WHEN 40 THEN 'Autorización Vale Evidencia de Fondo Fijo: ' + N.not_identificador 
						  WHEN 41 THEN 'Autorización de Mas Vale Evidencia de Fondo Fijo: ' + N.not_identificador 
						  WHEN 42 THEN 'Cierre de Fondo Fijo: ' + N.not_identificador 
						  WHEN 43 THEN 'Autorizacion Factura: ' + N.not_identificador 
						  WHEN 44 THEN 'Autorizacion Factura Contraloria: ' + N.not_identificador 
						  WHEN 45 THEN 'Autorización CC sin Presupuesto: ' + N.not_identificador 
						  WHEN 46 THEN 'Solicitud CC sin Presupuesto: ' + N.not_identificador 
						  WHEN 47 THEN 'Solicitud de aprobación de compra: ' + N.not_identificador 
						  WHEN 48 THEN 'Solicitud de aprobación de compra: ' + N.not_identificador 
						  WHEN 49 THEN 'Solicitud de aprobación de estudio de mercado: ' + N.not_identificador
						  WHEN 52 THEN 'Autorización Salida de Unidad: ' + N.not_identificador 
						  WHEN 53 THEN 'Autorización Anticipo de Gastos de Viaje: ' + N.not_identificador 
						  WHEN 54 THEN 'Autorización de gastos de más para Gastos de Viaje: ' + N.not_identificador
						  WHEN 60 THEN 'Reembolso de Fondo Fijo Finanzas 2: ' + N.not_identificador 
						  WHEN 61 THEN 'Reembolso de Fondo Fijo Finanzas 3: ' + N.not_identificador  
						  
						END AS identificador 	
						,not_identificador
					, N.not_fecha AS fecha
					, SUBSTRING(N.not_descripcion, 1, 43) + '...' AS descripcionCorta
					, N.not_descripcion AS descripcionLarga
					, CASE WHEN N.not_agrupacion = 1 --LQMA se agrega parametro de aprobador
								THEN N.not_link_BPRO + '&idAprobador=' + CONVERT(VARCHAR(10),A.emp_id) + '&idAprobacion='+ CONVERT(VARCHAR(10),A.apr_id)+ '&idNotify='+ CONVERT(VARCHAR(10),N.not_id)						   						   
						   WHEN N.not_agrupacion = 18 THEN N.not_link_BPRO + '&idAprobador=' + CONVERT(VARCHAR(10),A.emp_id) + '&idAprobacion='+ CONVERT(VARCHAR(10),A.apr_id)+ '&idNotify='+ CONVERT(VARCHAR(10),N.not_id)
						   WHEN N.not_agrupacion IN (14,16)
								THEN N.not_link_BPRO + '|' + CONVERT(VARCHAR(10),A.apr_id)
						   ELSE N.not_link_BPRO 						
					  END		
					  AS link
					, N.not_adjunto AS adjunto
					, N.not_adjunto_tipo AS tipoAdjunto
					, CASE WHEN not_link_BPRO = '' THEN 2 
					       WHEN not_link_BPRO IS NULL THEN 0  --LQMA 23112016
						   WHEN A.apr_escalado = -1 AND N.not_agrupacion = 1 THEN 0
						   ELSE 1 END AS modalidadAdjunto
					, CASE  
						WHEN N.not_tipo = 7 THEN 7 --LQMA  26072017
						WHEN A.apr_escalado = -1 AND N.not_agrupacion != 1  THEN 3 					
						WHEN A.apr_escalado = -1 AND N.not_agrupacion = 1  THEN 1 					
						ELSE N.not_tipo END AS tipoNotificacion
					, (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id) AS chat
					, (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id AND chat_visto=0 AND chat_idEmpleado <> A.emp_id) AS chatPendiente
					, N.not_agrupacion AS agrupacion
					, 0 AS correoEnviado
					, CASE WHEN A.apr_escalado = -1 THEN A.apr_escalado ELSE  A.apr_nivel END  AS escalado
					, A.apr_nivel AS nivel
					, N.not_estatus AS estatus
					--, CASE ISNULL(A.apr_visto, 0) WHEN 0 THEN 0 ELSE 1 END AS estado
					, CASE 
						WHEN ISNULL(A.apr_visto, 0) = 0 AND (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id AND chat_visto=0 AND chat_idEmpleado <> A.emp_id)>0 THEN 0
						WHEN ISNULL(A.apr_visto, 0) > 0 AND (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id AND chat_visto=0 AND chat_idEmpleado <> A.emp_id)>0 THEN 0
						WHEN ISNULL(A.apr_visto, 0) = 0 AND (SELECT COUNT(chat_id) FROM NOT_CHAT WHERE chat_idNotificacion= N.not_id AND chat_visto=0 AND chat_idEmpleado <> A.emp_id)=0 THEN 0						
						ELSE 1
					  END AS estado	
					--,S.emp_idempresa AS idEmpresa
					--,S.suc_idsucursal AS idSucursal
					, CASE WHEN S.emp_idempresa IS NOT NULL THEN S.emp_idempresa ELSE  SC.emp_idempresa END  AS idEmpresa
					, CASE WHEN S.suc_idsucursal IS NOT NULL THEN S.suc_idsucursal ELSE  SC.suc_idsucursal END  AS idSucursal					
				    ,D.dep_iddepartamento AS idDepartamento
					,ISNULL((SELECT ISNULL(E.Minutos_Escalar - CONVERT(int, DATEDIFF(MINUTE, A.apr_fecha, GETDATE())),-1) 
						FROM dbo.ESCALACION AS E 
							WHERE 
							N.[not_tipo_proceso] = E.[Proc_Id] 
							AND N.[not_nodo] = E.[Nodo_Id] 
							AND OC.[oce_idempresa] = E.[emp_idempresa] 
							AND OC.[oce_idsucursal] = E.[suc_idsucursal] 
							AND OC.[oce_iddepartamento] = E.[dep_iddepartaamento] 
							AND OC.[oce_idtipoorden] = E.[tipo_idtipoorden]
					    	AND A.[apr_nivel] = E.[Nivel_Escalamiento]),0)
					 as MinutosFaltan
					,(SELECT nar_comentario FROM [dbo].[NOT_APROBACION_RESPUESTA] 
								 WHERE nar_id = (SELECT MAX(nar_id) FROM NOT_APROBACION_RESPUESTA WHERE not_id = N.not_id)) AS comentarioRevision,

                    CASE N.not_agrupacion
						WHEN 2 THEN SUBSTRING(parametros.par_valor,1,LEN(parametros.par_valor) - 3) + (SELECT emp_nombrecto FROM [ControlAplicaciones].[dbo].[cat_empresas] WHERE [emp_idempresa] = [dbo].[splitCadena_fn](N.not_identificador,'|',1)) + '/' + (SELECT [suc_nombrecto] FROM [ControlAplicaciones].[dbo].[cat_sucursales] WHERE [emp_idempresa] = [dbo].[splitCadena_fn](N.not_identificador,'|',1) AND [suc_idsucursal] = [dbo].[splitCadena_fn](N.not_identificador,'|',2)) + '/'
						--WHEN 5 THEN 'C:/GA_Centralizacion/CuentasXCobrar/OtrosDoc/DocVarios/'+N.not_identificador+'/'+N.not_adjunto+'.'+N.not_adjunto_tipo
						WHEN 5 THEN ''
						WHEN 6 THEN ''
						WHEN 7 THEN ''
						WHEN 8 THEN ''
						ELSE parametros.par_valor 
					END	ruta_archivos  --agrupado 3 flotilla case AU-ZM-[SUC] LQMA 13072016 original comentado parametros.par_valor
					,Deptos.dep_nombrecto Depto  --LQMA 07072016
					,CASE 
						WHEN EXISTS(SELECT 1 FROM @VarPlantas WHERE IDPROVEEDOR = OC.oce_idproveedor AND idEmpresa = OC.oce_idempresa AND idSucursal = OC.oce_idsucursal)  THEN 1
						ELSE 0
					 END  esPlanta --LQMA 07072016
					--LQMA add 02032018
					 , ESTLOTE.pel_descripcion estatusLote
					--, CASE 
					--		WHEN DATEDIFF(D,not_fecha, GETDATE()) > 5  THEN 
					--				CASE WHEN (SELECT COUNT(1) FROM Pagos.[dbo].PAG_PROGRA_PAGOS_DETALLE WHERE CONVERT(VARCHAR(30),pal_id_lote_pago) = N.not_identificador) = 0 THEN 1 
					--					  ELSE 0 
					--				END 
					--		ELSE 0
					--  END diasNot
					  --, CASE 
							--WHEN DATEDIFF(D,not_fecha, GETDATE()) > 5 AND N.not_agrupacion = 1 THEN 
							--		CASE WHEN (SELECT COUNT(1) FROM Pagos.[dbo].PAG_PROGRA_PAGOS_DETALLE WHERE CONVERT(VARCHAR(30),pal_id_lote_pago) = N.not_identificador) = 0 THEN 1 
							--			  ELSE 0 
							--		END 
							--ELSE 0
					  --END diasNot
				    ,1 diasNot
					,CASE  WHEN  N.not_agrupacion  IN (SELECT	not_agrupador FROM	Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION WHERE not_agrupador NOT IN(45,46,47,48,49,52,53,54)) THEN 1  ELSE 0 END  existeNotNueva
					
			FROM    
					NOT_NOTIFICACION AS N 
					LEFT JOIN dbo.NOT_APROBACION AS A ON  N.not_id = A.not_id
					LEFT JOIN dbo.NOT_APROBACION AS ema ON ema.not_id = N.not_id AND ema.apr_escalado = -1
					LEFT JOIN dbo.OrdenesdeCompra AS OC ON OC.oce_folioorden = N.not_identificador
					LEFT JOIN ControlAplicaciones.dbo.cat_sucursales AS S ON  S.suc_idsucursal = OC.oce_idsucursal
					LEFT JOIN dbo.BPRO_Departamentos AS D ON  D.dep_iddepartamento = OC.[oce_iddepartamento] 
					LEFT JOIN dbo.BPRO_Usuarios AS U ON U.usu_idusuario = OC.oce_idusuario 
				 	LEFT JOIN dbo.BPRO_Usuarios AS sap ON sap.usu_idusuario = ema.emp_id
					LEFT JOIN dbo.NOT_PARAMETROS AS parametros ON parametros.par_id = 1
					LEFT JOIN [ControlAplicaciones].[dbo].[cat_departamentos] Deptos ON OC.oce_iddepartamento = Deptos.dep_iddepartamento
					--LQMA add 02032018 boton completar notificaciones pagos
					LEFT JOIN Pagos.dbo.PAG_LOTE_PAGO PAG ON N.not_identificador = CONVERT(VARCHAR(30),PAG.pal_id_lote_pago)
					LEFT JOIN Pagos.[dbo].[PAG_ESTATUS_LOTE] ESTLOTE ON PAG.pal_estatus = ESTLOTE.pel_id_estatus_pago
					LEFT JOIN ControlAplicaciones.dbo.cat_sucursales AS SC ON  SC.suc_idsucursal= N.idSucursal
					INNER JOIN NOT_FILTRO_AGRUPACION F ON F.not_agrupacion = N.not_agrupacion    
			WHERE  A.emp_id = CAST(@idEmpleado AS INT) --and n.not_id=327376
			AND ((N.not_estatus IN (1,2,6)) AND (A.apr_estatus IN (1,2))) --LQMA add se agrego estatus 6 = revision 
			AND A.apr_escalado IN (-1,0)
			AND ((N.not_agrupacion = 3 AND A.apr_estatus = 1) OR (N.not_agrupacion != 3) OR (A.apr_estatus = 2))
			AND  N.not_tipo in( 1,2,4) --AND not_agrupacion = 1
			AND F.idTipoFiltro = coalesce(@filtro,  F.idTipoFiltro)
			--AND  N.not_agrupacion  in (SELECT not_agrupacion from NOT_FILTRO_AGRUPACION WHERE not_agrupacion = coalesce(@agrupador, not_agrupacion))
			--AND ( N.not_fecha >= CONVERT(DATETIME,'01-08-2019',103)  and N.not_fecha <= CONVERT(DATETIME,'05-10-2019',103) )
			--AND ( N.not_fecha between CONVERT(DATE,coalesce(@fechaIni,N.not_fecha),111) and CONVERT(DATE,coalesce(@fechaFin,N.not_fecha),111) ) 
			 AND CONVERT(DATE,REPLACE(N.not_fecha,'-',''),105) BETWEEN CONVERT(DATE,coalesce(@fechaIni,CONVERT(DATE,REPLACE(N.not_fecha,'-',''),105))) AND CONVERT(DATE,coalesce(@fechaFin,CONVERT(DATE,REPLACE(N.not_fecha,'-',''),105)))
		

			ORDER BY estado ASC,N.not_fecha DESC
  
	  END TRY
	  BEGIN CATCH
		  DECLARE @Mensaje  nvarchar(max),
		  @Componente nvarchar(50) = 'SEL_NOTIFICACION_SP'
		  SELECT @Mensaje = ERROR_MESSAGE() + '--- @empleado: ' + @idEmpleado
		  EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	  END CATCH
END
go

