------------------------------------------------
-- EXEC [dbo].[INS_NOTIFICACION_COMPRAS_SP] 'C-XXXX-C',1,28,'Compra tipo C',4,6, null,'AZA','',NULL,NULL
------------------------------------------------
CREATE PROCEDURE [dbo].[INS_NOTIFICACION_COMPRAS_SP]
		 
	 @identificador		 VARCHAR(50) 
	,@idSolicitante		 NUMERIC(18,0) 
	,@idTipoNotificacion INT 
	,@descripcion		 VARCHAR(MAX) = ''
	,@idEmpresa			 INT = NULL
	,@idSucursal		 INT = NULL
	,@idDepartamento	 INT = NULL
	,@area				 VARCHAR(20)  = ''
	,@linkBPRO			 VARCHAR(MAX) = NULL
	
	,@notAdjunto		 VARCHAR(MAX) = NULL 
	,@notAdjuntoTipo	 VARCHAR(500) = NULL

	
	
	
AS
BEGIN
	SET NOCOUNT ON;
	
	

BEGIN TRAN TRAN_INS_NOTIFICACION

BEGIN TRY
		--DECLARE  @identificador		 VARCHAR(50)  = 'C-XXXX-A'
		--	,@idSolicitante		 NUMERIC(18,0) = 1
		--	,@idTipoNotificacion INT  = 26
		--	,@descripcion		 VARCHAR(MAX) = 'Compra tipo A'
		--	,@idEmpresa			 INT = 4
		--	,@idSucursal		 INT = 6
		--	,@idDepartamento	 INT = NULL
		--	,@linkBPRO			 VARCHAR(MAX) = NULL
		--	,@area				 VARCHAR(20)  = 'AZA'
		--	,@notAdjunto		 VARCHAR(MAX) = NULL 
		--	,@notAdjuntoTipo	 VARCHAR(500) = NULL

	DECLARE  @idNot INT
			,@aprobador			NUMERIC(18,0)
			,@notAgrupacion		NUMERIC(18,0)
			,@apr_usu1			INT=0
			,@apr_usu2			INT=0
			,@apr_usu3			INT=0
			,@empresaSucursal   VARCHAR(10)
			,@success           BIT
	
	
				
	IF((@idEmpresa IS NULL OR @idEmpresa = 0) AND (@idSucursal IS NULL OR @idSucursal = 0) AND (@area IS NULL OR @area = '')  )
	BEGIN
			SELECT  0 not_id, 0 success, -1 result , 'message' = 'Favor de Agregar la Empresa, Sucursal y Área' 
			
	END	
	ELSE
	BEGIN
			IF(@idTipoNotificacion = 26) --TIPO A, SI TIENE ESCALAMIENTO  <= 5000
			BEGIN
				SET @notAgrupacion = 47
						
				
				SELECT @apr_usu1 = usuario_autoriza1 
				FROM Centralizacionv2..DIG_ESCALAMIENTO_AREA_AFECT 
				WHERE emp_idempresa	=	@idEmpresa
					AND suc_idsucursal	=	@idSucursal 
					AND par_idenpara	=	@area
			


			END
			ELSE IF (@idTipoNotificacion = 27) -- TIPO B NO TIENE ESCALAMIENTO   > 5000
			BEGIN
				SET @notAgrupacion = 48

				SET @empresaSucursal = LTRIM(RTRIM(CONVERT(CHAR(3),@idEmpresa))) + '|' + LTRIM(RTRIM(CONVERT(CHAR(3),@idSucursal))) 
				--SELECT @apr_usu1 = cat_valor FROM [Centralizacionv2].[dbo].DIG_CATALOGOS WHERE CAT_ID_PADRE = 74 AND cat_nombre in (@empresaSucursal)
				select @apr_usu1 = cat_valor FROM [Centralizacionv2].[dbo].DIG_CATALOGOS WHERE CAT_ID_PADRE = 120 AND cat_nombre  = @idEmpresa
 
			END
			ELSE IF  (@idTipoNotificacion = 28) --TIPO C:   solicitud o estudio de mercado LOS AUTORIZADORES DE --GERENTE GRAL >5000
			BEGIN
				SET @notAgrupacion = 49
				SET @empresaSucursal = LTRIM(RTRIM(CONVERT(CHAR(3),@idEmpresa))) + '|' + LTRIM(RTRIM(CONVERT(CHAR(3),@idSucursal))) 
				--SELECT @apr_usu1 = cat_valor FROM [Centralizacionv2].[dbo].DIG_CATALOGOS WHERE CAT_ID_PADRE = 74 AND cat_nombre in (@empresaSucursal)
				select @apr_usu1 = cat_valor FROM [Centralizacionv2].[dbo].DIG_CATALOGOS WHERE CAT_ID_PADRE = 120 AND cat_nombre  = @idEmpresa
				
			
			END

				/*Insertar Notificacion*/

					INSERT INTO NOT_NOTIFICACION (
										  not_tipo
										, not_tipo_proceso
										, not_identificador
										, not_nodo
										, not_descripcion
										, not_estatus
										, not_fecha
										, not_link_BPRO
										, not_adjunto
										, not_adjunto_tipo
										, not_agrupacion
										, idEmpresa
										, idSucursal
										)
						VALUES			( 
										  1
										, 1
										, @identificador
										, 1
										, @descripcion
										, 2
										, GETDATE()
										, @linkBPRO
										, @notAdjunto
										, @area
										, @notAgrupacion
										, @idEmpresa
										, @idSucursal
										)

					SET @idNot  = @@IDENTITY
					SET @success = 1

					--Solicitante (si aprobador = solicitante, solo se inserta aprobador)
					IF(@apr_usu1 != @idsolicitante) 
					BEGIN
						INSERT INTO [dbo].[NOT_APROBACION]
							   ([not_id]
							   ,[apr_nivel]
							   ,[apr_visto]
							   ,[emp_id]
							   ,[apr_fecha]
							   ,[apr_estatus]
							   ,[apr_escalado])
						 VALUES
							   (@idNot
							   ,0
							   ,NULL
							   ,@idsolicitante
							   ,GETDATE()
							   ,1
							   ,-1)
					END
		   
					--Aprobador

					INSERT INTO [dbo].[NOT_APROBACION]
						   ([not_id]
						   ,[apr_nivel]
						   ,[apr_visto]
						   ,[emp_id]
						   ,[apr_fecha]
						   ,[apr_estatus]
						   ,[apr_escalado])
					 VALUES
						   (@idNot
						   ,0
						   ,NULL
						   ,@apr_usu1
						   ,GETDATE()
						   ,2
						   ,0)
	
	

					INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
					VALUES (5,'INS_NOTIFICACION_COMPRAS_SP @aprobador:' + CONVERT(VARCHAR(5),@aprobador) ,GETDATE())

					SELECT  @idNot not_id, @success success, 1 result , 'message' = 'La operación se realizó con exito.' 


	END

	

	COMMIT TRAN TRAN_INS_NOTIFICACION	
	
	
END TRY
BEGIN CATCH

	ROLLBACK TRAN TRAN_INS_NOTIFICACION
	DECLARE @Mensaje  nvarchar(max)
	SELECT @Mensaje = ERROR_MESSAGE()	
	SET @success = 0	
	SELECT   0 not_id, @success success, -1 result, @Mensaje 'message'
 	
	EXECUTE INS_ERROR_SP 'INS_NOTIFICACION_SP', @Mensaje 
	
END CATCH
END
go

