-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 16/10/2015
-- Description: Stored que recupera las sucursales en base al usuario y la empresa
-- =============================================
-- [SEL_SUCURSAL_FILTRO_SP] 29,1
CREATE PROCEDURE [dbo].[SEL_SUCURSAL_FILTRO_SP] 
		@idUsuario   INT = 0,
		@idEmpresa   INT = 0

AS
BEGIN

	SELECT 0 suc_idsucursal
			, '---Todas---' suc_nombre
			, '' suc_nombrecto
	UNION
	SELECT    DISTINCT S.suc_idsucursal
			, S.suc_nombre
			, S.suc_nombrecto
	FROM   ControlAplicaciones.dbo.cat_sucursales S
	INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] org ON S.suc_idsucursal = org.suc_idsucursal
	WHERE org.usu_idusuario = @idUsuario
	AND org.emp_idempresa = @idEmpresa		

	--SELECT * FROM [ControlAplicaciones].[dbo].[ope_organigrama] WHERE usu_idusuario = 29

END


go

