-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 28/09/2015
-- Description:	Stored de control de excepciones
-- Regresa el número del último registro insertado.
-- =============================================
CREATE PROCEDURE [dbo].[INS_ERROR_SP] 
	@componente		nvarchar(500)
	,@mensaje		nvarchar(max)
AS
BEGIN
DECLARE @parametros  nvarchar(500) = ''
	SET NOCOUNT ON;
IF EXISTS (SELECT 1 FROM sysobjects WHERE name=@componente) 
BEGIN
	SELECT @parametros = COALESCE(@parametros + ', ', '') + PARAMETER_NAME  from INFORMATION_SCHEMA.PARAMETERS Where SPECIFIC_NAME = @componente
END	

ELSE
BEGIN
SET @parametros = 'Componente externo a BD'
END
INSERT INTO Error (componente, parametros, mensaje,fecha) VALUES (@componente, @parametros, @mensaje,getdate())
RETURN @@IDENTITY

END


go

