
-- Author:	    ALEJANDRO LOPEZ
-- Create date: 05/04/2018
-- Description:	Procedimiento que realiza 
-- El parámetro de respuesta solo puede tener los valores: Revision
-- =========================================================================
/*
--validaConciliacion
EXECUTE [dbo].[INS_APROBACION_PLANPISO_SP] @idtipoproceso = 1,@identificador = '<identificador>',@idnodo = '0'
											,@descripcion = '<descripcion>',@estatus = 2,@link = '<www.google.com>'
											,@adjunto = NULL, @idtipoadjunto	= '',@solicitante = 311 
											,@aprobador	= 71
--cancelaConciliacion
EXECUTE [dbo].[INS_APROBACION_PLANPISO_SP] @idtipoproceso = 2,@identificador = '1',@idnodo = '0'
											,@descripcion = 'PLAN PISO cancela conciliacion',@estatus = 2,@link = null
											,@adjunto = NULL, @idtipoadjunto = '',@solicitante = 311 
											,@aprobador	= 71

--validaTraspasoFinanciera
EXECUTE [dbo].[INS_APROBACION_PLANPISO_SP] @idtipoproceso = 3,@identificador = '1',@idnodo = '0'
											,@descripcion = 'PLAN PISO valida traspaso financiera',@estatus = 2,@link = null
											,@adjunto = NULL, @idtipoadjunto = '',@solicitante = 311 
											,@aprobador	= 71

*/


CREATE PROCEDURE [dbo].[INS_APROBACION_PLANPISO_SP]
	 @idtipoproceso INT = 0
	,@identificador VARCHAR(50) = ''
	,@idnodo INT = ''
	,@descripcion VARCHAR(500) = ''
	,@estatus INT = 0
	,@link VARCHAR(MAX) = NULL
	,@adjunto VARCHAR(MAX) = NULL
	,@idtipoadjunto	VARCHAR(500) = ''
	,@solicitante NUMERIC(18,0) = 0 
	,@aprobador	NUMERIC(18,0) = 0 
AS
  
	DECLARE @idAgrupado INT

	SELECT @idAgrupado = CASE @idtipoproceso WHEN 1 THEN 14 --validaConciliacion
											 WHEN 2 THEN 15 --cancelaConciliacion
											 WHEN 3 THEN 16 --validaTraspasoFinanciera	
						 END 

  	BEGIN TRY
			BEGIN TRAN TRAN_APROBACION_PLANPISO
			
					INSERT INTO NOT_NOTIFICACION (not_tipo
						, not_tipo_proceso
						, not_identificador
						, not_nodo
						, not_descripcion
						, not_estatus
						, not_fecha
						, not_link_BPRO
						, not_adjunto
						, not_adjunto_tipo
						, not_agrupacion)
						VALUES
						( 1
						, @idtipoproceso
						, @identificador
						, @idnodo
						, @descripcion
						, @estatus
						, GETDATE()
						, @link
						, @adjunto
						, @idtipoadjunto
						, @idAgrupado
						)

					DECLARE @nid_not int = @@IDENTITY;

					--Solicitante
					--LQMA  add 17062016   si aprobador = solicitante, solo se inserta aprobador
					----------------------------------
					IF(@aprobador != @solicitante) --si aprobador es diferente de solicitante, se inserta solicitante
						BEGIN
							INSERT INTO [dbo].[NOT_APROBACION]
										([not_id]
										,[apr_nivel]
										,[apr_visto]
										,[emp_id]
										,[apr_fecha]
										,[apr_estatus]				
										,[apr_escalado])
							 VALUES
								   (@nid_not
								   ,0
								   ,NULL
								   ,@solicitante
								   ,GETDATE()
								   ,2
								   ,-1)
						END       
           
					--Aprobador
					----------------------------------
						INSERT INTO [dbo].[NOT_APROBACION]
							   ([not_id]
							   ,[apr_nivel]
							   ,[apr_visto]
							   ,[emp_id]
							   ,[apr_fecha]
							   ,[apr_estatus]
							   ,[apr_escalado])
						 VALUES
							   (@nid_not
							   ,0
							   ,NULL
							   ,@aprobador
							   ,GETDATE()
							   ,2
							   ,0)
					  
			
 			COMMIT TRAN TRAN_APROBACION_PLANPISO

			SELECT 0 estatus, 'Solicitud de aprobación registrada.' mensaje 

		END TRY
		BEGIN CATCH
			
			ROLLBACK TRAN TRAN_APROBACION_PLANPISO
			PRINT ('Error: ' + ERROR_MESSAGE())
			DECLARE @Mensaje  nvarchar(max),
			@Componente nvarchar(50) = 'INS_APROBACION_PLANPISO_SP'
			SELECT @Mensaje = ERROR_MESSAGE()
						
			DECLARE @tablaRespuesta TABLE(idError INT)

			INSERT INTO @tablaRespuesta
			EXECUTE INS_ERROR_SP @Componente, @Mensaje
					
			SELECT ERROR_NUMBER() estatus, @Mensaje mensaje

		END CATCH
go

