-- =============================================
-- Author:		<Jorge Conelly>
-- Create date: <06/03/2020>
-- Description:	<SP que trae los correos de los usuarios x idRol>
-- [dbo].[SEL_CORREOS_NOTIFICACION_SP] 10, 466582, 13
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CORREOS_NOTIFICACION_SP] 
	@idRol         INT,
	@notId NUMERIC(18,0),
	@idTipoNotificacion INT
AS
BEGIN

	DECLARE @not_identificador NVARCHAR(50)
	DECLARE @idUsuario INT
	DECLARE @usu_correo VARCHAR(130)
	DECLARE @nombreUsuario VARCHAR(170)
	DECLARE @idFondoFijo VARCHAR(50) 
	DECLARE @enviaCorreo INT = 1
	DECLARE @idempresa INT = 0

	DECLARE @idFinanzas varchar (100) = '2189'
	DECLARE @idFinanzasHeraldo varchar(100) = '3096'

	--Obtener el not_identificador de la tabla Notificacion..NOT_NOTIFICACION 
	SELECT @not_identificador = not_identificador FROM Notificacion..NOT_NOTIFICACION WHERE not_id = @notId

	SELECT @idempresa = idempresa from [Tramites].[Tramite].[fondoFijo] WHERE id_perTra = @not_identificador

	--Obtener los datos del usuario al que se le va a notificar
	IF(@idRol = 10)
	BEGIN
	IF(@idempresa = 17 or @idempresa =18 or @idempresa = 16 or @idempresa = 12)
	BEGIN
	SELECT  @idUsuario =  cu.usu_idusuario,
			@usu_correo =  cu.usu_correo + ', juan.peralta@coalmx.com', 
		    @nombreUsuario = cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno
	FROM ControlAplicaciones.dbo.cat_usuarios cu WHERE cu.usu_idusuario in (@idFinanzasHeraldo)
	END
	ELSE
	BEGIN
	SELECT  @idUsuario =  cu.usu_idusuario,
			@usu_correo =  cu.usu_correo + ', juan.peralta@coalmx.com', 
		    @nombreUsuario = cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno
	FROM ControlAplicaciones.dbo.cat_usuarios cu WHERE cu.usu_idusuario in (@idFinanzas)
	END
	END
	ELSE
	BEGIN
	SELECT  @idUsuario =  cu.usu_idusuario,
			@usu_correo =  cu.usu_correo, 
		    @nombreUsuario = cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno
	FROM ControlAplicaciones.dbo.cat_usuarios cu
	INNER JOIN Tramites.dbo.usuarioRol ur on cu.usu_idusuario  = ur.idUsuario 
	WHERE ur.idRol = @idRol
	END

	--DECLARE @idFinanzas varchar (100) = '2189'
	----Obtener los datos del usuario al que se le va a notificar
	--IF(@idRol = 10)
	--BEGIN
	--SELECT  @idUsuario =  cu.usu_idusuario,
	--		@usu_correo =  cu.usu_correo + ', juan.peralta@coalmx.com', 
	--	    @nombreUsuario = cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno
	--FROM ControlAplicaciones.dbo.cat_usuarios cu WHERE cu.usu_idusuario in (@idFinanzas)
	--END
	--ELSE
	--BEGIN
	--SELECT  @idUsuario =  cu.usu_idusuario,
	--		@usu_correo =  cu.usu_correo, 
	--	    @nombreUsuario = cu.usu_nombre + ' ' + cu.usu_paterno  + ' ' + cu.usu_materno
	--FROM ControlAplicaciones.dbo.cat_usuarios cu
	--INNER JOIN Tramites.dbo.usuarioRol ur on cu.usu_idusuario  = ur.idUsuario 
	--WHERE ur.idRol = @idRol
	--END
	--Obtener el not_identificador de la tabla Notificacion..NOT_NOTIFICACION 
	SELECT @not_identificador = not_identificador FROM Notificacion..NOT_NOTIFICACION WHERE not_id = @notId


	IF( @idTipoNotificacion = 13) --Fondo Fijo
	BEGIN
		SELECT @idFondoFijo = idFondoFijo from [Tramites].[Tramite].[fondoFijo] WHERE id_perTra = @not_identificador
		DECLARE @esAumentoDecremento INT, @esDecremento INT = 0
		select @esAumentoDecremento = AumentoDisminucion from Tramites.Tramite.fondoFijo where id_perTra = @not_identificador
		SET @esAumentoDecremento = ISNULL(@esAumentoDecremento,0)
		IF(@esAumentoDecremento > 0)
		BEGIN
			select @esDecremento = case when ffc.aumentoDecrementoFF = 2 then 1 else 0 end  
			from Tramites.Tramite.fondofijo  ff
			inner join Tramites.Tramite.fondoFijoCambios ffc on ffc.id = ff.AumentoDisminucion
			where ff.id_perTra = @not_identificador

		END
		IF(@esDecremento = 1)
		BEGIN 
		SET @enviaCorreo = 0
		END

	END
	
	-- Crear una tabla temporal para regresar los datos
	CREATE TABLE #datosCorreoTmp(idUsuario INT,
								 idRol INT,
								 usu_correo VARCHAR(130),
								 nombreUsuario VARCHAR(170),
								 not_identificador NVARCHAR(50),
								 idFondoFijo VARCHAR(50),
								 enviaCorreo INT)


	IF(@idFondoFijo IS NULL)
	BEGIN
		SET @idFondoFijo = ''
	END

	INSERT INTO #datosCorreoTmp (idUsuario, idRol, usu_correo, nombreUsuario, not_identificador, idFondoFijo, enviaCorreo)
	VALUES (@idUsuario, @idRol, @usu_correo, @nombreUsuario, @not_identificador, @idFondoFijo, @enviaCorreo)

	SELECT idUsuario, 
		   idRol, 
		   usu_correo, 
		   nombreUsuario, 
		   not_identificador, 
		   idFondoFijo,
		   enviaCorreo
	FROM #datosCorreoTmp
END

go

