-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 26/10/2015
-- Modified date: 05/11/2015
-- Description:	INS_ALERTA_SP Inserta las notificacione de aprobación.
-- =============================================
-- [INS_ALERTA_SP] 1, '', 0, 'Probando la alerta', 0, '', 'http://direccion/cercana/archivo.pdf', 'pdf', 0, 1
CREATE PROCEDURE [dbo].[INS_ALERTA_SP]
	 @idtipoproceso int
	,@identificador varchar(50)
	,@idnodo	int
	,@descripcion varchar(500)
	,@estatus int
	,@linkBPRO varchar(MAX) = NULL
	,@adjunto varchar(MAX) = NULL
	,@idtipoadjunto	varchar(500)
	,@agrupacion	int = 0
	,@idusuario     int

AS
BEGIN

	SET NOCOUNT ON;
-- inserta una notificación de tipo aprobación
BEGIN TRY
	BEGIN TRAN
		INSERT INTO NOT_NOTIFICACION (not_tipo
		, not_tipo_proceso
		, not_identificador
		, not_nodo
		, not_descripcion
		, not_estatus
		, not_fecha
		, not_link_BPRO
		, not_adjunto
		, not_adjunto_tipo
		, not_agrupacion)
		VALUES
		( 2
		, @idtipoproceso
		, @identificador
		, @idnodo
		, @descripcion
		, @estatus
		, GETDATE()
		, @linkBPRO
		, @adjunto
		, @idtipoadjunto
		, @agrupacion
		)
	--Busca cuantas personas recibirán la notificación y hace el insert en la tabla de aprobaciones.
	-- 05/11/2015  Si el campo de agrupación es 1 solamente agrega 1 aprobación al usuario configurado en DIG_PARAMETROS_PAGO
		DECLARE @nid_not	int = @@IDENTITY;
		DECLARE @departamento int;
		--DECLARE @empresa	int;
		--DECLARE @solicitante int;
		DECLARE @naprobacion numeric(18,0);

	----------------------------------
		INSERT INTO [dbo].[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
		   --,[apr_comentario]
           ,[apr_escalado])
		 VALUES
           (@nid_not
		   ,0
		   ,0
           ,@idusuario
           ,GETDATE()
           ,1
		   --,''
           ,0)
		--SET @naprobacion = @@IDENTITY
		--		INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]
  --         ([not_id]
		--   ,[apr_id]
		--   ,[nar_fecha]
		--   --,[nar_estatus]
  --         ,[nar_comentario])
  --   VALUES
  --         (@nid_not
		--   ,@naprobacion
  --         ,GETDATE()
  --         --,0
		--   ,'')
		   
		--	   SELECT * FROM NOT_APROBACION_RESPUESTA AS nar
		COMMIT TRAN;
	--RETURN 1;
	print 0;

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_ALERTA_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	ROLLBACK TRAN;
	print @@IDENTITY;
END CATCH

END


go

