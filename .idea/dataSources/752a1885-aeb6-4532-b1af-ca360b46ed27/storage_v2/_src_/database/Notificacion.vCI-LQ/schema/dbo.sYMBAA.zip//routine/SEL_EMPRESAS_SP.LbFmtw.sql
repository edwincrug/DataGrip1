-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 16/10/2015
-- Description: Stored que recupera las empresas
-- =============================================
--SEL_EMPRESAS_SP 1,1 
CREATE PROCEDURE [dbo].[SEL_EMPRESAS_SP] 
	@idempleado int = 0
	,@iddivision int = 0
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY 
SELECT    DISTINCT E.emp_idempresa
		, E.emp_cveempresa
		, E.emp_nombre
		, E.emp_nombrecto
		--, ControlAplicaciones.dbo.cat_usuarios.usu_idusuario
FROM  ControlAplicaciones.dbo.cat_departamentos D INNER JOIN
      ControlAplicaciones.dbo.cat_usuarios U ON D.dep_iddepartamento = U.dep_iddepartamento INNER JOIN
      ControlAplicaciones.dbo.cat_sucursales S ON D.suc_idsucursal = S.suc_idsucursal RIGHT OUTER JOIN
      ControlAplicaciones.dbo.cat_empresas E ON S.emp_idempresa = E.emp_idempresa
WHERE (E.div_iddivision = @iddivision OR @iddivision = 0)
	--AND (U.usu_idusuario = @idempleado OR @idempleado = 0)
	AND E.emp_idempresa <> 0

	END TRY
	BEGIN CATCH 
		DECLARE @Mensaje nvarchar(max),
		@Componente nvarchar(50) = 'SEL_EMPRESAS_SP'
		SELECT @Mensaje= ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje
	END CATCH 
END


go

