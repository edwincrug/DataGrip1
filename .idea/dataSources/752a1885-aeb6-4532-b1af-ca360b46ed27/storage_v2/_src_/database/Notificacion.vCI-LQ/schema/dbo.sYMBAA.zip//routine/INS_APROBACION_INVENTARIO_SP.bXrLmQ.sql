-- =============================================
-- Author: LQMA
-- Create date: 27062017
-- 
-- Description:	INS_APROBACION_LOTE_SP Inserta las notificacione de aprobación de inventarios
-- =============================================
-- [INS_APROBACION_INVENTARIO_SP] 1, 87, 1, 'Autorización de LOTE', 1, '', '', 'pdf', 1, 2

CREATE PROCEDURE [dbo].[INS_APROBACION_INVENTARIO_SP]
	-- @idtipoproceso INT = 10 --10: Aprobacion inventario
	@identificador VARCHAR(50) = '' --VIN
	--,@idnodo	INT = 0 --en 0
	,@descripcion VARCHAR(500) = ''--comentario por parte del solicitante
	--,@estatus INT = 1 --siempre en 1
	--,@linkBPRO VARCHAR(MAX) = NULL --va nulo
	--,@adjunto VARCHAR(MAX) = NULL --va nulo
	--,@idtipoadjunto	VARCHAR(500) = NULL --va nulo
	,@solicitante NUMERIC(18,0) --usuario que solicita
	,@aprobador	NUMERIC(18,0)  --aprobador
	,@idEmpresa INT = 0 --id de la agencia/empresa
	,@idSucursal INT = 0
AS
BEGIN

	SET NOCOUNT ON;
-- inserta una notificación de tipo aprobación

		--LQMA 05070217
		BEGIN TRANSACTION TRAN_APROBACION_INVENTARIO

BEGIN TRY

		INSERT INTO NOT_NOTIFICACION (not_tipo
		, not_tipo_proceso
		, not_identificador
		, not_nodo
		, not_descripcion
		, not_estatus
		, not_fecha
		, not_link_BPRO
		, not_adjunto
		, not_adjunto_tipo
		, not_agrupacion
		, idEmpresa
		, idSucursal
		)
		VALUES
		( 1 
		 ,10
		, @identificador
		, 0
		, @descripcion
		, 1
		, GETDATE()
		, NULL
		, NULL
		, NULL
		, 10 --not_agrupacion
		, @idEmpresa
		, @idSucursal
		)

	DECLARE @nid_not int = @@IDENTITY;

	IF(@aprobador != @solicitante) --si aprobador es diferente de solicitante, se inserta solicitante
		BEGIN
			INSERT INTO [dbo].[NOT_APROBACION]
						([not_id]
						,[apr_nivel]
						,[apr_visto]
						,[emp_id]
						,[apr_fecha]
						,[apr_estatus]				
						,[apr_escalado])
			 VALUES
				   (@nid_not
				   ,0
				   ,NULL
				   ,@solicitante
				   ,GETDATE()
				   ,2
				   ,-1)
		END       
           
	--Aprobador
	----------------------------------
	INSERT INTO [dbo].[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
           ,[apr_escalado])
     VALUES
           (@nid_not
		   ,0
		   ,NULL
           ,@aprobador
           ,GETDATE()
           ,2
           ,0)
	
	
--Actualiza el estatus de la notificación a "En proceso"
----------------------------------
	UPDATE NOT_NOTIFICACION SET not_estatus = 2 
		WHERE not_id =@nid_not		
	
	--LQMA 03072017
	UPDATE NOT_APROBACION SET apr_estatus = 2 WHERE not_id = @nid_not
	
	--LQMA 05070217
	COMMIT TRANSACTION TRAN_APROBACION_INVENTARIO
		
	  select 0 error 
	
END TRY
BEGIN CATCH

	--LQMA 05070217
	ROLLBACK TRANSACTION TRAN_APROBACION_INVENTARIO

	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_APROBACION_INVENTARIO_SP'
	SELECT ERROR_NUMBER() error
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
		
END CATCH

END
go

