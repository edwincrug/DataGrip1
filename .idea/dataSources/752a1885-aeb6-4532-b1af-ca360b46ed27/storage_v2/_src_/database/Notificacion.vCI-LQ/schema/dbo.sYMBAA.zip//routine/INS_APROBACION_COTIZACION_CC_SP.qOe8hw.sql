-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
/*
	Guia INS_APROBACION_COTIZACION_SP
*/
CREATE PROCEDURE [dbo].[INS_APROBACION_COTIZACION_CC_SP]
	 @idtipoproceso int
	,@identificador varchar(50) 
	,@descripcion varchar(500)
	,@estatus int
	,@aprobador	numeric(18,0)
	,@idsolicitante  numeric(18,0)
AS
BEGIN

	SET NOCOUNT ON;

	BEGIN TRAN TRAN_APROBACION_COTIZACION

	BEGIN TRY

		INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	    VALUES (19,'INS_NOTIFICAION_CC_SP @aprobador:' + CONVERT(VARCHAR(5),@aprobador) ,GETDATE())

		DECLARE @idEmpresa INT, @idSucursal INT, @idCot INT

		SELECT @idEmpresa = C.ucu_idempresa, @idSucursal = C.ucu_idsucursal, @idCot =  CC.ucu_idcotizacion
		FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] C
		INNER JOIN [cuentasporcobrar].[dbo].[uni_ccs] CC ON C.ucu_idcotizacion = CC.ucu_idcotizacion
		WHERE CC.ucc_idcc = @identificador
		


		-- que es not_tipo
		INSERT INTO NOT_NOTIFICACION (not_tipo, not_tipo_proceso, not_identificador, not_nodo, not_descripcion, not_estatus, not_fecha, not_link_BPRO, not_adjunto, not_adjunto_tipo, not_agrupacion,idEmpresa , idSucursal)
									VALUES( 1, @idtipoproceso, @identificador,' ', @descripcion, 2, GETDATE(), null, ' ', @idCot , 19 , @idEmpresa, @idSucursal)

		DECLARE @nid_not int = @@IDENTITY;

		--	Solicitante
		--	Si aprobador = solicitante, solo se inserta aprobador
			IF(@aprobador != @idsolicitante) --si aprobador es diferente de solicitante, se inserta solicitante
				BEGIN
					INSERT INTO [dbo].[NOT_APROBACION]([not_id],[apr_nivel],[apr_visto],[emp_id],[apr_fecha],[apr_estatus] ,[apr_escalado])
												VALUES	( @nid_not, 0 , NULL , @idsolicitante , GETDATE() , 1  , -1 )
				END
		   
		--	Aprobador
			INSERT INTO [dbo].[NOT_APROBACION] ([not_id],[apr_nivel],[apr_visto],[emp_id],[apr_fecha],[apr_estatus],[apr_escalado])
												VALUES ( @nid_not ,0 ,NULL ,@aprobador ,GETDATE() ,2 , 0 )
		
	COMMIT TRAN TRAN_APROBACION_COTIZACION	
	
	SELECT 0 error
	
END TRY
BEGIN CATCH

	ROLLBACK TRAN TRAN_APROBACION_COTIZACION
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_NOTIFICAION_CC_SP'
	SELECT ERROR_NUMBER() error
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	
END CATCH
END;
go

