-- ==============================================================================================
-- Author:		Lourdes Maldonado Sanchez
-- Create date: 18/06/2018
-- Description: Dependiendo del Usuario cambio de estatus las notificaciones a 3:Aprobadas
--              Las aprobaciones cambian tambien a estatus 3:Aprobadas
--              Y se crea una respuesta de Aprobado sino hay,si existe respuesta hace un update.
-- ==============================================================================================
-- EXECUTE [UPD_NOTIFICACIONES_ESTATUS_SP] 71
CREATE PROCEDURE [dbo].[UPD_NOTIFICACIONES_ESTATUS_SP] 
	@idEmpleado  int = 0
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
	
	DECLARE @Notificaciones_usu TABLE  ( IDB INT IDENTITY(1,1)
										 ,apr_id INT
										 ,not_id INT
										)


   --------------------------------------------------------------------------
   -- 1) Buscamos notificaciones del usuario
   --------------------------------------------------------------------------
   
   INSERT INTO @Notificaciones_usu
    SELECT [apr_id]
	      ,[not_id]
	  FROM [Notificacion].[dbo].[NOT_APROBACION]
     WHERE [emp_id] = @idEmpleado
	   AND [apr_estatus] IN (1,2,6)  --Pendiente,Visto y En Revison.
	   --AND [not_id] = 15507
       --AND [apr_id] = 30187
	
	SELECT	IDB 
			,apr_id 
			,not_id 
	FROM	@Notificaciones_usu
   --SELECT * FROM @Notificaciones_usu


    --------------------------------------------------------------------------
    -- 2) Realizamos el update a la NOTIFICACION a estatus 3:Aprobadas
    --------------------------------------------------------------------------
	UPDATE [Notificacion].[dbo].[NOT_NOTIFICACION]
	   SET [not_estatus] = 3
	 WHERE not_id IN (SELECT N.not_id FROM @Notificaciones_usu AS N)

	--SELECT [not_estatus],[not_id]
	--  FROM [Notificacion].[dbo].[NOT_NOTIFICACION]
	-- WHERE [not_id] IN (SELECT N.not_id FROM @Notificaciones_usu AS N)


    --------------------------------------------------------------------------
    -- 3) Realizamos el update a la APROBACION a estatus 3:Aprobadas
    --------------------------------------------------------------------------
	UPDATE [Notificacion].[dbo].[NOT_APROBACION]
	   SET [apr_estatus] = 3
	 WHERE [apr_id] IN (SELECT N.apr_id FROM @Notificaciones_usu AS N)

	--SELECT [apr_estatus],[apr_id]
	--   FROM [Notificacion].[dbo].[NOT_APROBACION]
	--  WHERE [apr_id] IN (SELECT N.apr_id FROM @Notificaciones_usu AS N)


    --------------------------------------------------------------------------
    -- 4) Insertamos la Respuesta en APROBACION_RESPUESTA
    --------------------------------------------------------------------------
	DECLARE @total INT = (SELECT COUNT(IDB) FROM @Notificaciones_usu)
	DECLARE @aux   INT = 1
	DECLARE @not_id NUMERIC(18,0)
	DECLARE @apr_id NUMERIC(18,0)

	WHILE(@aux <=  @total)
	BEGIN
	      	  SELECT  @not_id = not_id
					 ,@apr_id = apr_id
				FROM @Notificaciones_usu
			   WHERE IDB = @aux

              DECLARE @existe INT = 0
    
	          SELECT @existe = CASE WHEN EXISTS(	SELECT [nar_id]
													  FROM [Notificacion].[dbo].[NOT_APROBACION_RESPUESTA]
													 WHERE [not_id] = @not_id
													   AND [apr_id] = @apr_id)
									  THEN ( 1 )
							          ELSE   0
							     END



			  IF (@existe = 0)
			  BEGIN
				  --SELECT 'No existe Respuesta '
				  --SELECT @not_id,@apr_id
				  INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
									(not_id,apr_id,nar_fecha,nar_comentario)
							  VALUES
									(@not_id,@apr_id,GETDATE(),'Aprobado: OK')
			  END
			  ELSE
			  BEGIN
				  --SELECT 'Existe Respuesta hago update'
				  --SELECT @not_id,@apr_id
				  UPDATE [dbo].[NOT_APROBACION_RESPUESTA]	
					 SET [nar_fecha] = GETDATE()
						,[nar_comentario] = 'Aprobado: OK'
				   WHERE [not_id] = @not_id 
					 AND [apr_id] = @apr_id		  
			  END

			  -------------------------------------------------------
			  -- SE DEBE CAMBIAR EL ESTATUS DE LA ORDEN ?????
			  -------------------------------------------------------
			  /*
			  UPDATE [cuentasxpagar].dbo.cxp_ordencompra 
				 SET sod_idsituacionorden = 2 
			   WHERE oce_folioorden = (SELECT N.not_identificador 
										 FROM NOT_NOTIFICACION N 
									  		  INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
										WHERE A.apr_id = @apr_id)
			  */
	      
			  SET @aux = @aux + 1
	END

	END TRY
	BEGIN CATCH 
		DECLARE @Mensaje nvarchar(max),
		@Componente nvarchar(50)  ='UPD_NOTIFICACIONES_ESTATUS_SP' 
		select @Mensaje = ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje 

	END CATCH 
END


go

