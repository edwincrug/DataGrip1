-- =============================================
-- Author: 
-- Create date: 
-- Description:	Stored de control de las acciones de Aprobación
-- Regresa el número del último registro insertado.
-- =============================================

CREATE PROCEDURE [dbo].[INS_ACCIONES_APROBACION_5_SP] 
	@idAprobacion int
	,@respuesta   int
	,@observacion nvarchar(max)
	,@not_identificador int
	,@usuario1 int
	,@folio nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	
	BEGIN
		IF(@respuesta=1)
				BEGIN
					--Aprobado
					
						UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;
							
						----------------------------------------------------------------
						-------Inserta una respuesta de aprobación
						----------------------------------------------------------------
							
							
						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
						VALUES
							(@not_identificador,@idAprobacion,GETDATE(),'Aprobado: ' +  @observacion)									
						
				END
		
		ELSE  
				BEGIN
						--Entrando a cancelar la orden
						UPDATE NOT_NOTIFICACION SET not_estatus = 4 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						UPDATE NOT_APROBACION SET apr_estatus = 4 WHERE apr_id = @idAprobacion;
							
						----------------------------------------------------------------
						-------Inserta una respuesta de aprobación
						----------------------------------------------------------------
						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
						VALUES
							(@not_identificador,@idAprobacion,GETDATE(),'Cancelado: ' + @observacion)					
											
						
				END			


	END

END


go

