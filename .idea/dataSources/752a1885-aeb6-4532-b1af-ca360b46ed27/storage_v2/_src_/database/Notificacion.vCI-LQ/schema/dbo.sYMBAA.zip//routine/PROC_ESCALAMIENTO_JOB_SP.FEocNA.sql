CREATE PROCEDURE [dbo].[PROC_ESCALAMIENTO_JOB_SP]
AS
BEGIN
	DECLARE @idnot int
			,@tiponot int
			,@tipoproceso int
			,@idnodo int
			,@notestatus int
			,@departamento int
			,@nivel int
			,@escalado int
			,@minutos1 int
			,@minutos2 int
			,@fecha datetime
			,@usuarioAprobador INT
			,@idfolio varchar(50)
			,@idEmpresa INT
			,@idSucursal INT
			,@idDepartamento INT

	SET NOCOUNT ON;
	
	--BEGIN TRAN
BEGIN TRY
	-- Declaración del cursor

	DECLARE @NotPendientes  TABLE
	(
		id INT IDENTITY(1,1),
		[not_id] numeric(18, 0) NULL,
		[not_identificador] nvarchar(50) NULL,
		[not_tipo] int NULL,
		[not_tipo_proceso] int NULL,
		[not_nodo] int NULL,
		[not_estatus] int NULL,
		[apr_fecha] datetime NULL,
		apr_nivel INT NULL, 
		apr_escalado INT NULL,
		[not_agrupacion] [int] NOT NULL,
		[idEmpresa] [int] NULL,
		[idSucursal] [int] NULL,
		[idDepartamento][int] NULL,
		usuarioAprobador INT NULL
		
	)
			INSERT INTO @NotPendientes
			SELECT DISTINCT	     N.not_id
				, N.not_identificador
				, N.not_tipo
				, N.not_tipo_proceso
				, N.not_nodo
				, N.not_estatus
				, A.apr_fecha
				, A.apr_nivel
				, A.apr_escalado
				, N.not_agrupacion
				,N.idEmpresa
				,N.idSucursal
				,N.idDepartamento
				,A.emp_id
			FROM Notificacion.dbo.NOT_NOTIFICACION N 
					INNER JOIN Notificacion.dbo.NOT_APROBACION A ON A.not_id = N.not_id 
					LEFT JOIN Notificacion.dbo.BPRO_Usuarios U ON A.emp_id = U.usu_idusuario
					INNER JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT DE ON DE.not_agrupador = N.not_agrupacion
			WHERE	N.not_estatus in (2) 
				AND		N.not_tipo = 1 
				AND		apr_escalado <> -1 
				AND		apr_escalado = 0  
			--AND		not_agrupacion in (SELECT not_agrupador FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT) 
			AND		A.emp_id not in (SELECT M.usuario_mancomunado from Centralizacionv2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO M WHERE M.idTipoNotificacion = DE.idTipoNotificacion  )
			UNION ALL
			SELECT DISTINCT   N.not_id
							, N.not_identificador
							, N.not_tipo
							, N.not_tipo_proceso
							, N.not_nodo
							, N.not_estatus
							, A.apr_fecha
							, A.apr_nivel
							, A.apr_escalado
							, N.not_agrupacion
							,N.idEmpresa
							,N.idSucursal
							,N.idDepartamento
							,A.emp_id
			FROM Notificacion.dbo.NOT_NOTIFICACION N 
					INNER JOIN Notificacion.dbo.NOT_APROBACION A ON A.not_id = N.not_id 
					LEFT JOIN Notificacion.dbo.BPRO_Usuarios U ON A.emp_id = U.usu_idusuario
					INNER JOIN Centralizacionv2.dbo.[DIG_CAT_NOTIFICACION_JERARQUIZADA] DE ON DE.not_agrupador = N.not_agrupacion
			WHERE N.not_estatus in (2) 
				AND N.not_tipo = 1 
				AND apr_escalado <> -1 
				AND apr_escalado = 0  


			--select * from @NotPendientes

		DECLARE  @cont			int = 1
				,@not_agrupador INT
				,@idRespuesta   NUMERIC(18,0) 
		
		WHILE(@cont <= (SELECT COUNT(1) FROM @NotPendientes) )
		BEGIN
			

			SELECT	@not_agrupador = not_agrupacion
					,@idnot = not_id
					,@fecha = apr_fecha 
					,@usuarioAprobador = usuarioAprobador
					,@nivel = apr_nivel
					,@idEmpresa = idEmpresa
					,@idSucursal = idSucursal
					,@idDepartamento = idDepartamento
			FROM	@NotPendientes 
			WHERE	Id = @cont

			IF EXISTS (SELECT 1 FROM Centralizacionv2.dbo.DIG_CAT_NOTIFICACION_JERARQUIZADA WHERE not_agrupador IN ( @not_agrupador) )
			BEGIN 
				SELECT @minutos1= tiempoEscalacion 
				FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO  E
				INNER JOIN Centralizacionv2.dbo.DIG_CAT_NOTIFICACION_JERARQUIZADA J on E.idtipoNotificacionJeraquizada = J.idtipoNotificacionJeraquizada
				WHERE idUsuario = @usuarioAprobador
				AND J.not_agrupador = @not_agrupador

			END
			ELSE 
			BEGIN
				SELECT @minutos1= minutos_escalar 
				FROM CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
				WHERE usuario_autoriza = @usuarioAprobador
				AND not_agrupador = @not_agrupador
			END

			print ('minutos 1: ' + convert(varchar, ISNULL(@minutos1,9999999)));			
				SELECT @minutos2 = DATEDIFF(MINUTE, @fecha, GETDATE());
		
					

					DECLARE	 @fechaIni DATETIME = @fecha/*'2018-02-01 15:29:59'*/
							, @minutos INT = @minutos1
							, @horaI INT = 9
							, @horaF INT = 18
							, @fechaActual DATETIME = GETDATE()
							, @escalamiento BIT = 0
					
					

					DECLARE @iDia DATETIME = CONVERT(VARCHAR(10),@fechaActual,112) 
							,@fDia DATETIME = CONVERT(VARCHAR(10),@fechaActual,112) 

					
					SELECT @iDia = DATEADD(HOUR,@horaI, @iDia), @fDia = DATEADD(HOUR,@horaF, @fDia)
					--SELECT @fechaIni fechaIni,@iDia iDia, @fDia fDia

					
					IF (SELECT UPPER(DATENAME(DW, GETDATE()))) != 'DOMINGO'
						BEGIN						
								IF (SELECT UPPER(DATENAME(DW, @fechaIni))) = 'DOMINGO'
									BEGIN
										SELECT @fechaIni = DATEADD(DAY,1,@fechaIni)
									END
							
								IF(SELECT DATEDIFF(DAY, @fechaIni, @fechaActual)) = 0
									BEGIN
											IF(@fechaIni < @iDia)
												SET @fechaIni = @iDia
						
											IF(@fechaActual > @fDia)
												BEGIN
													PRINT 'Mayor a hora final'
													SET @fechaActual = @fDia
												END

											IF(SELECT DATEDIFF(MINUTE, @fechaIni, @fechaActual)) > @minutos
												BEGIN
													SET @escalamiento = 1	--SELECT 'MIN: ' + CONVERT(VARCHAR(10),DATEDIFF(MINUTE, @fechaIni, @fechaActual)) + ' ESCALA! 1'
													Print 'ENTRE ESCALAMINIENTO'
												END
											ELSE
												BEGIN
													PRINT 'MIN: ' + CONVERT(VARCHAR(10),DATEDIFF(MINUTE, @fechaIni, @fechaActual)) + ' EN TIEMPO!'
												END
									END
								ELSE
									BEGIN						
											PRINT 'diferente dia'
											SELECT	@iDia  = CONVERT(VARCHAR(10),@fechaIni,112)
													,@fDia = CONVERT(VARCHAR(10),@fechaIni,112)
													 
											SELECT  @iDia = DATEADD(HOUR,@horaI, @iDia)
											       ,@fDia = DATEADD(HOUR,@horaF, @fDia)
											
																			
											
											
											DECLARE @minDia INT = 0

											IF(@fechaIni < @iDia)
												SET @fechaIni = @iDia
						
											PRINT '@fechaIni: ' + CONVERT(VARCHAR(20),@fechaIni) + ', @fDia: ' + CONVERT(VARCHAR(20),@fDia)
												
											SELECT @minDia = DATEDIFF(MINUTE, @fechaIni, @fDia)
											SELECT @fechaIni fechaIni,@iDia iDia, @fDia fDia, @minDia minAcumulados
						
											IF(@minDia > @minutos)
												BEGIN
													SET @escalamiento = 1 --SELECT 'MIN: ' + CONVERT(VARCHAR(10),@minDia) + ' ESCALA! 2'
													Print 'ENTRE ESCALAMINIENTO'
												END
											ELSE
												BEGIN

													IF(SELECT (DATEPART(HOUR,GETDATE()) * 60 + DATEPART(MINUTE,GETDATE())) - (9 * 60) + @minDia) > @minutos
													BEGIN
																SET @escalamiento = 1--SELECT 'MIN: ' + CONVERT(VARCHAR(10),@minDia) + ' ESCALAR! 3'
																Print 'ENTRE ESCALAMINIENTO'
													END
													ELSE
													BEGIN
																PRINT 'EN TIEMPO!'
													END
													/*IF(SELECT UPPER(DATENAME(DW, @fechaIni))) = 'SABADO'
														BEGIN
															SELECT 'dsds'
														END
													ELSE
														BEGIN
										
														   IF(SELECT (DATEPART(HOUR,GETDATE()) * 60 + DATEPART(MINUTE,GETDATE())) - (9 * 60) + @minDia) > @minutos
																SELECT 'ESCALAR!'																			
										
														END*/
												END						
									END

						END
				IF(@escalamiento = 1)
				BEGIN
					SELECT 'SI' Escalar, @idnot, @nivel , @not_agrupador, @idEmpresa, @idSucursal,@idDepartamento
					EXEC Notificacion.[dbo].[INS_ESCALAMIENTO_SP] @idnot, @nivel , @not_agrupador,@idEmpresa, @idSucursal,@idDepartamento, @result = @idRespuesta OUTPUT
				
					IF(@idRespuesta = -1)
					BEGIN
						--Provocamos el error  para enviar al catch y hacer  rollback si es que el stored de INS_ESCALAMIENTO_SP nos devuelve un error
						SELECT 1/0
					END
				END
			print @cont
			SET @cont = @cont + 1
		END
END TRY
BEGIN CATCH
		
		DECLARE @Mensaje  nvarchar(max),
		@Componente nvarchar(50) = 'PROC_ESCALAMIENTO_JOB_SP'
		SELECT @Mensaje = ERROR_MESSAGE()
		EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	
END CATCH
END
go

