--SELECT * FROM NOT_NOTIFICACION WHERE not_identificador = 'XX-XX-XXX-XX-XX-XXXX'
--SELECT * FROM NOT_APROBACION WHERE NOT_ID = 233259
------------------------------------------------
-- EXEC [dbo].[INS_NOTIFICACION_SP] 'XX-XX-XXX-XX-XX-2223','Aprobación de credito',1,2
------------------------------------------------
CREATE PROCEDURE [dbo].[INS_NOTIFICACION_OUTPUT_SP]  
	
	 
	 @identificador		 VARCHAR(50) 
	,@descripcion		 VARCHAR(MAX)    
	,@idSolicitante		 NUMERIC(18,0) 
	,@idTipoNotificacion INT 
	,@idEmpresa			 INT = NULL
	,@idSucursal		 INT = NULL
	,@linkBPRO			 VARCHAR(MAX) = NULL
	,@notAdjunto		 VARCHAR(MAX) = NULL 
	,@notAdjuntoTipo	 VARCHAR(500) = NULL
	,@result			 NUMERIC(18,0) = 0 OUTPUT 			
	
	
AS
BEGIN
	SET NOCOUNT ON;
	
	BEGIN TRAN TRAN_INS_NOTIFICACION

BEGIN TRY
		DECLARE  @idNot INT
				,@aprobador			 NUMERIC(18,0)
				,@notAgrupacion		 NUMERIC(18,0)
				,@success            BIT

		SELECT   @aprobador = usuario_autoriza
				,@notAgrupacion = not_agrupador
		FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
		WHERE	nivel_escalamiento = 0 AND idTipoNotificacion = @idTipoNotificacion

		--SELECT   @aprobador 
		--		,@notAgrupacion
		
		--select top 1000 * from Notificacion.dbo.NOT_NOTIFICACION order by not_id desc
		
		INSERT INTO NOT_NOTIFICACION (
						  not_tipo
						, not_tipo_proceso
						, not_identificador
						, not_nodo
						, not_descripcion
						, not_estatus
						, not_fecha
						, not_link_BPRO
						, not_adjunto
						, not_adjunto_tipo
						, not_agrupacion
					    , idEmpresa
						, idSucursal
						)
		VALUES			( 
						  1
						, 1
						, @identificador
						, ''
						, @descripcion
						, 2
						, GETDATE()
						, @linkBPRO
						, @notAdjunto
						, @notAdjuntoTipo
						, @notAgrupacion
						, @idEmpresa
						, @idSucursal
						)

	SET @idNot  = @@IDENTITY
	SET @success = 1

	--Solicitante (si aprobador = solicitante, solo se inserta aprobador)
	IF(@aprobador != @idsolicitante) 
	BEGIN
		INSERT INTO [dbo].[NOT_APROBACION]
			   ([not_id]
			   ,[apr_nivel]
			   ,[apr_visto]
			   ,[emp_id]
			   ,[apr_fecha]
			   ,[apr_estatus]
			   ,[apr_escalado])
		 VALUES
			   (@idNot
			   ,0
			   ,NULL
			   ,@idsolicitante
			   ,GETDATE()
			   ,1
			   ,-1)
	END
		   
	--Aprobador

	INSERT INTO [dbo].[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
           ,[apr_escalado])
     VALUES
           (@idNot
		   ,0
		   ,NULL
           ,@aprobador
           ,GETDATE()
           ,2
           ,0)
	
	

	INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	VALUES (5,'INS_NOTIFICACION_SP @aprobador:' + CONVERT(VARCHAR(5),@aprobador) ,GETDATE())

	COMMIT TRAN TRAN_INS_NOTIFICACION	


	SET @result = 1
	RETURN @result		

	---SELECT  @idNot not_id, @success success, 1 result , 'message' = 'La operación se realizó con exito.' 
	
END TRY
BEGIN CATCH

	ROLLBACK TRAN TRAN_INS_NOTIFICACION
	DECLARE @Mensaje  nvarchar(max)
	SELECT @Mensaje = ERROR_MESSAGE()	
	SET @success = 0
	EXECUTE INS_ERROR_SP 'INS_NOTIFICACION_SP', @Mensaje 

	SET @result = -1
	RETURN @result		
		
	---SELECT   0 not_id, @success success, -1 result, @Mensaje 'message'
 	
	
	
END CATCH
END
go

