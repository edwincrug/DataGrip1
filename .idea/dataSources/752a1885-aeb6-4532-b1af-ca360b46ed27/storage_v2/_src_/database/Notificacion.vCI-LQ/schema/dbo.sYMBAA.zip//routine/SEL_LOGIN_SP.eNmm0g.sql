-- =============================================
-- Author:		Alejandro Lopez Quiroz
-- Create date: 05/04/2017
-- Description: Obtiene login de usuarios de notificacinoes
-- =============================================
-- [SEL_LOGIN_SP] @user = 'MPI' , @pass = '12345'
CREATE PROCEDURE [dbo].[SEL_LOGIN_SP] 
		@user   varchar(50) = '',
		@pass	varchar(50) = ''

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
		
	
	SELECT CONVERT(DECIMAL(18,0),usu_idusuario) not_idUser,  
		   @user not_user,
		   @pass not_pass,
		   CONVERT(DECIMAL(18,0),usu_idusuario) id_usuario	
	FROM ControlAplicaciones.dbo.cat_usuarios 
	WHERE UPPER(usu_contrasenia) = SUBSTRING(master.dbo.fn_varbintohexstr(HashBytes('SHA1', @pass)), 3, 1000) --HASHBYTES('SHA1','12345')
	AND UPPER(usu_nombreusu) = UPPER(@user) --'MLJ'
	
	/*	
	SELECT not_idUser,not_user, not_pass, id_usuario
	FROM NOT_USUARIOS 
	WHERE not_user = @user AND not_pass = @pass
	*/
	
END TRY

BEGIN CATCH
	DECLARE @Mensaje nvarchar(max),
	@Componente nvarchar(50)='SEL_LOGIN_SP'
	SELECT @Mensaje= ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente,@Mensaje
END CATCH
END


go

