

CREATE PROCEDURE [dbo].[DEL_FILTRO_USUARIO_SP] 
 @idUsuario INT 
AS
BEGIN
	BEGIN TRY

		
			DELETE FROM Notificacion.dbo.NOT_FILTRO_USUARIO WHERE  idUsuario = @idUsuario 
			
	

		SELECT 1 result
	END TRY
	BEGIN CATCH
	    
		SELECT 0 result
	END CATCH
END

go

