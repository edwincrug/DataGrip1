-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 28/10/2015
-- Description:	Procedimiento que realiza la aprobación tomando en cuenta
-- el nivel de escalamiento y al usuario mancomunado.
-- El parámetro de respuesta solo puede tener los valores: 1- Aprobado,  0- Rechazado
-- =============================================
-- [UPD_APROBACION_SP] 610, 1, 'Ok'
CREATE PROCEDURE [dbo].[UPD_APROBACION_FUNCIONA_SP]
	@idAprobacion int
	,@respuesta   int
	,@observacion nvarchar(500)
AS
	--BEGIN TRY
	
		DECLARE @idnotificacion int
		DECLARE @respuestaest int;
		DECLARE @usuario1 int, @usuario2 INT
		DECLARE @not_identificador VARCHAR
		

		-- Obtener el idNotifiacion
		SELECT @idnotificacion = not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion
		     
		     
		     
		  --Valida si ya fue aprobada la orden
		IF EXISTS(SELECT not_id FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion AND not_estatus in(3,4,5))
			BEGIN
				-- Si ya fue aprobada no hace la actualizacion y la pone como retrasada adicionalmente sale con 5
				UPDATE NOT_APROBACION SET apr_estatus = 5 WHERE apr_id = @idAprobacion
				SELECT -1
			END
		ELSE	
		BEGIN
		-- Actualizamos la notificacion, la aprobación, la repuesta y BPRO
			IF @respuesta = 1
					BEGIN
											
						--Entrando a autorizar
						SELECT   @usuario1 = EP.usuario_mancomunado, @usuario2 = A.emp_id, @not_identificador= N.not_identificador
									FROM     dbo.NOT_APROBACION A INNER JOIN
											 dbo.NOT_NOTIFICACION N ON A.not_id = N.not_id LEFT JOIN
											 Centralizacionv2.dbo.DIG_ESCALAMIENTO_PARAMETROS EP ON N.not_tipo_proceso = EP.Proc_Id AND 
											 N.not_nodo = EP.Nodo_Id INNER JOIN
											 dbo.BPRO_Usuarios U ON A.emp_id = U.usu_idusuario AND 
											 EP.dep_iddepartamento = U.dep_iddepartamento
											 WHERE A.apr_id =  @idAprobacion
											 print @usuario1
											 print @usuario2

						--VAlidar si el proceso no tiene mancomunado/ si usuario1 IS NULL
						--En caso afirmativo autorizar todo						
						IF (@usuario1 IS NULL)						
								BEGIN								
										UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
								
										--INSERTAR EN LA BITACORA DE BP 
									  -- 	EXECUTE INS_BITACORA_SP @usuario2, @not_identificador, @idAprobacion																											
										UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;				
													
										--MODIFICAR POR INSERT EN RESPUESTA									
										INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
													(not_id,[apr_id],[nar_fecha],[nar_comentario])
												VALUES
													(@idnotificacion,@idAprobacion,GETDATE(),@observacion)
										UPDATE [cuentasxpagar].dbo.cxp_ordencompra SET sod_idsituacionorden = 2 Where oce_folioorden = (SELECT N.not_identificador FROM 
											NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id  WHERE A.apr_id = @idAprobacion)
								END 
																							
						
						 IF @usuario1 = @usuario2
								BEGIN								
										-- El usuario es el mancomunado
										print('El usuario era el mancomunado, se termina todo')
												UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
								
										--INSERTAR EN LA BITACORA DE BP 
										--EXECUTE INS_BITACORA_SP @usuario1, @not_identificador, @idAprobacion																											
										UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;				
									
				
										--MODIFICAR POR INSERT EN RESPUESTA									
										INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
													(not_id,[apr_id],[nar_fecha],[nar_comentario])
												VALUES
													(@idnotificacion,@idAprobacion,GETDATE(),@observacion)												
										UPDATE [cuentasxpagar].dbo.cxp_ordencompra SET sod_idsituacionorden = 2 Where oce_folioorden = (SELECT N.not_identificador FROM 
											NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id  WHERE A.apr_id = @idAprobacion)
								 END
						  ELSE
								  BEGIN									
						
										-- Inserta un mancomunado
										print ('Entra a insertar mancomunado')
										--EXEC @respuestaest = INS_MANCOMUNADO_SP @idAprobacion											
												
										-- Si se encuentra un usuario mancomunado le manda una notificación y no se modifica el estatus de la notificación							
											UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;
		
											
										----------------------------------------------------------------
										-------Inserta una respuesta de aprobación
										----------------------------------------------------------------
										INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]
											([not_id], apr_id, [nar_fecha],[nar_comentario])
										VALUES
											(@idnotificacion,@idAprobacion,GETDATE(),@observacion)					   
									
								   END 
				END					
				ELSE
					BEGIN
					--Entrando a cancelar la orden
						UPDATE NOT_NOTIFICACION SET not_estatus = 4 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						UPDATE NOT_APROBACION SET apr_estatus = 4 WHERE apr_id = @idAprobacion;
							
						----------------------------------------------------------------
						-------Inserta una respuesta de aprobación
						----------------------------------------------------------------
						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]
							([not_id], apr_id, [nar_fecha],[nar_comentario])
						VALUES
							(@idnotificacion,@idAprobacion,GETDATE(),@observacion)										
											
						UPDATE [cuentasxpagar].dbo.cxp_ordencompra SET sod_idsituacionorden = 3 Where oce_folioorden = (SELECT N.not_identificador FROM 
																														NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	WHERE A.apr_id = @idAprobacion)

						--EXECUTE INS_BITACORA_SP @usuario1, @not_identificador, @idAprobacion	
							 
					END	
					SELECT 0;
		END
	--END TRY
	--BEGIN CATCH
	--	DECLARE @Mensaje  nvarchar(max),
	--	@Componente nvarchar(50) = 'UPD_APROBACION_SP'
	--	SELECT @Mensaje = ERROR_MESSAGE()
	--	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	--END CATCH


go

