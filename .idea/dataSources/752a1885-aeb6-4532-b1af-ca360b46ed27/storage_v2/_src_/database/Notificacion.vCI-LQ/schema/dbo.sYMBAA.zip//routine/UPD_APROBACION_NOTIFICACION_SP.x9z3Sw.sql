CREATE PROCEDURE [dbo].[UPD_APROBACION_NOTIFICACION_SP] --1052954, 1,'Acepto',248065
	 @idAprobacion		INT
	,@respuesta			INT
	,@observacion		NVARCHAR(MAX)
	,@identificador		INT
	
	
AS
BEGIN
	SET NOCOUNT ON;
	--@idAprobacion=483323,@respuesta=1,@observacion='',@identificador='248147'
	--declare
	-- @idAprobacion		INT = 1052954
	--,@respuesta			INT = 1
	--,@observacion		NVARCHAR(MAX) = 'Acepto'
	--,@identificador		INT = 542823


	BEGIN TRY
	BEGIN TRANSACTION
		DECLARE  @usuarioAutoriza INT
				,@not_agrupador	  INT
				,@idTipoNotificacion INT
				,@aprobar BIT = 0
				,@rechazar BIT = 0
				,@not_identificador VARCHAR(250)
				,@not_estatus INT
				,@cont INT = 1
				,@idNotNew INT
				,@usuarioMancomunado INT
				,@mensaje_respuesta  VARCHAR(250)
				,@contCancela INT  = 1
				,@idAprob INT
				,@idNot INT
				,@idTraDe INT
				,@disparador INT
		
		DECLARE @aumentoDecremento INT, @esAumentoDecremento INT, @montoCambio DECIMAL(18,2)
		DECLARE @tblUsuMancomunado TABLE (id INT IDENTITY(1,1),usuario_mancomunado INT)
		DECLARE @tblUsuarios TABLE (id	INT IDENTITY(1,1),usuario INT)
		DECLARE @tblUsuCancela TABLE (id INT IDENTITY(1,1),usuario INT,not_id  INT,emp_id  INT,apr_id  INT)
		
		SELECT	@usuarioAutoriza = emp_id
		FROM	Notificacion.dbo.NOT_APROBACION 
		WHERE	apr_id = @idAprobacion 
		AND		apr_estatus IN (1,2) 
		AND		apr_escalado <> -1 
		ORDER BY apr_id DESC

		if( @usuarioAutoriza is null)
		BEGIN
			select 2 estatus, 'Esta notificación ya fue aprobada anteriormente.' mensaje
		END
		
		SELECT  @not_agrupador = not_agrupacion 
				,@not_identificador = not_identificador
		FROM	Notificacion.DBO.NOT_NOTIFICACION 
		WHERE	not_id = @identificador 
		
		print '@not_agrupador: '+cast(@not_agrupador as varchar(20))
		SELECT	@idTipoNotificacion = idTipoNotificacion  
		FROM	CentralizacionV2.dbo.DIG_TIPO_NOTIFICACION 
		WHERE	not_agrupador = @not_agrupador
			
		print '@idTipoNotificacion: '+cast(@idTipoNotificacion as varchar(20))

		IF(@respuesta = 1)
		BEGIN
			SET @not_estatus = 3 SET @mensaje_respuesta = 'Aprobado: '
		END
		ELSE
		BEGIN
			SET @not_estatus = 5 SET @mensaje_respuesta = 'Cancelado: '
		END
		
		IF(@idTipoNotificacion = 6)
		BEGIN
			SELECT @disparador = usuario_autoriza 
			FROM CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
			WHERE idTipoNotificacion = @idTipoNotificacion 
		END
		IF(@idTipoNotificacion = 7 OR @idTipoNotificacion = 8)
		BEGIN
			SELECT @disparador = usuario_autoriza 
			FROM CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
			WHERE idTipoNotificacion =  @idTipoNotificacion
		END
		
		
		--- Reviso si el aprobador es normal
		IF EXISTS(select 1  from CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT WHERE usuario_autoriza = @usuarioAutoriza AND not_agrupador = @not_agrupador  )
		BEGIN
		
		
					--- Cambio estatus de notificacion
					UPDATE NOT_NOTIFICACION SET not_estatus = @not_estatus WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
					UPDATE NOT_APROBACION SET apr_estatus = @not_estatus WHERE apr_id = @idAprobacion;
						
					----------------------------------------------------------------
					-------Inserta una respuesta de aprobación
					----------------------------------------------------------------
					INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
						(not_id,[apr_id],[nar_fecha],[nar_comentario])
					VALUES
						(@identificador,@idAprobacion,GETDATE(),@mensaje_respuesta +  @observacion)	
					----------------------------------
				
				IF(@respuesta = 1)
				BEGIN 
					IF EXISTS( SELECT 1 FROM CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO WHERE idTipoNotificacion = @idTipoNotificacion  )
					BEGIN
									
						INSERT INTO @tblUsuMancomunado
						SELECT	usuario_mancomunado 
						FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO	
						WHERE	idTipoNotificacion = @idTipoNotificacion 
		
						--SELECT * FROM @tblUsuMancomunado

		
						WHILE (@cont<= (SELECT COUNT(1) FROM @tblUsuMancomunado))
						BEGIN
								SELECT @usuarioMancomunado = usuario_mancomunado FROM @tblUsuMancomunado WHERE id = @cont
		
		
								INSERT INTO NOT_NOTIFICACION (not_tipo, not_tipo_proceso, not_identificador, not_nodo, not_descripcion, not_estatus, not_fecha, not_link_BPRO, not_adjunto	, not_adjunto_tipo, not_agrupacion)
								SELECT not_tipo,not_tipo_proceso, not_identificador, not_nodo, not_descripcion, 2, GETDATE(), not_link_BPRO, not_adjunto	, not_adjunto_tipo, not_agrupacion FROM Notificacion.dbo.NOT_NOTIFICACION WHERE not_id = @identificador 
		
								SET @idNotNew = SCOPE_IDENTITY()
		
								INSERT INTO [dbo].[NOT_APROBACION] ([not_id],[apr_nivel],[apr_visto],[emp_id],[apr_fecha],[apr_estatus],[apr_escalado])
								VALUES(@idNotNew,0,0,@usuarioMancomunado,GETDATE(),2,0)
													
								print 'enviar notificaciones'
								SET @cont = @cont + 1
						END
					
						IF (@idTipoNotificacion = 7)
						BEGIN
						print 7
							UPDATE Tramites.dbo.tramiteDevoluciones set esDe_IdEstatus = 7 where id_perTra = @not_identificador
							insert into Tramites.dbo.BitacoraTramite values (@usuarioAutoriza,@not_identificador,'Se envia a autorizacion de direccion de Finanzas', GETDATE(),7)
						END
						IF (@idTipoNotificacion = 8)
						BEGIN
						print 8
							UPDATE Tramites.dbo.tramiteDevoluciones set esDe_IdEstatus = 8 where id_perTra = @not_identificador
							insert into Tramites.dbo.BitacoraTramite values (@usuarioAutoriza,@not_identificador,'Se envia a autorizacion de direccion de Finanzas', GETDATE(),8)
						END
						
					END
					ELSE
					BEGIN
						SET @aprobar = 1
					
						Print 'SET @aprobar = 1'
					END
					INSERT INTO Notificacion.[dbo].[NOT_BITACORA]  VALUES (@idTipoNotificacion,@usuarioAutoriza,@not_identificador,'[dbo].[UPD_APROBACION_NOTIFICACION_SP]', 'Aprobó Notificacion con Id: ' + CONVERT(VARCHAR(100), @identificador), GETDATE() )
					SELECT 	1 estatus, 'Se realizó la aprobación correctamente' mensaje , idTipoNotificacion = @idTipoNotificacion 
				END
				ELSE
				BEGIN
					SET @rechazar = 1
					INSERT INTO Notificacion.[dbo].[NOT_BITACORA]  VALUES (@idTipoNotificacion,@usuarioAutoriza,@not_identificador,'[dbo].[UPD_APROBACION_NOTIFICACION_SP]', 'Rechazó Notificacion con Id: ' + CONVERT(VARCHAR(100), @identificador), GETDATE() )
					SELECT 	1 estatus, 'Se realizó el rechazo correctamente' mensaje 
					Print 'SET @rechazar = 1'
				END
				
		END
		ELSE IF EXISTS (SELECT 1 FROM CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO WHERE usuario_mancomunado = @usuarioAutoriza AND idTipoNotificacion = @idTipoNotificacion) -- reviso si es aprobador mancomunado
		BEGIN
		
			
				-- Cambio estatus de notificacion
				UPDATE NOT_NOTIFICACION SET not_estatus = @not_estatus WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
				UPDATE NOT_APROBACION SET apr_estatus = @not_estatus WHERE apr_id = @idAprobacion;
					
				----------------------------------------------------------------
				-------Inserta una respuesta de aprobación
				----------------------------------------------------------------
				INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
					(not_id,[apr_id],[nar_fecha],[nar_comentario])
				VALUES
					(@identificador,@idAprobacion,GETDATE(),@mensaje_respuesta +  @observacion)	
		
		
					
				INSERT INTO @tblUsuarios
				SELECt emp_id FROM NOT_NOTIFICACION NN 
				INNER JOIN NOT_APROBACION  NA on NN.not_id = NA.not_id
				INNER JOIN NOT_APROBACION_RESPUESTA NR on NA.apr_id = NR.apr_id
				INNER JOIN CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO M on M.usuario_mancomunado = NA.emp_id 
				WHERE not_identificador = @not_identificador 
				AND idTipoNotificacion = @idTipoNotificacion --and obligatorio = 1
		
		
					--SElect * from @tblUsuarios
		
				IF(@respuesta = 1)
				BEGIN
				IF(	(SELECT COUNT(1) from CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO MM
					LEFT JOIN @tblUsuarios USU ON USU.usuario = MM.usuario_mancomunado 
					WHERE idTipoNotificacion =  @idTipoNotificacion AND obligatorio = 1 
					AND usuario IS NULL) = 0)
					BEGIN
		
							IF((SELECT COUNT(1) from CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO MM
							LEFT JOIN @tblUsuarios USU ON USU.usuario = MM.usuario_mancomunado 
							WHERE idTipoNotificacion = @idTipoNotificacion AND obligatorio = 0  
							AND usuario IS NULL) > 0)
							BEGIN
										
		
								INSERT INTO @tblUsuCancela
								SELECT	usuario_mancomunado
										,not_id
										,emp_id
										,apr_id 
								FROM (
										SELECT	MM.usuario_mancomunado 
										FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO MM
										LEFT JOIN @tblUsuarios USU ON USU.usuario = MM.usuario_mancomunado 
										WHERE idTipoNotificacion = @idTipoNotificacion AND obligatorio = 0 
										AND usuario IS NULL) A 
								LEFT JOIN (
										SELECT	NN.not_id
												,NA.emp_id
												,NA.apr_id 
										FROM NOT_NOTIFICACION NN 
										INNER JOIN NOT_APROBACION  NA on NN.not_id = NA.not_id
										WHERE not_identificador = @not_identificador ) B ON A.usuario_mancomunado = B.emp_id
		
		
								WHILE (@contCancela <= (SELECT COUNT(1) FROM @tblUsuCancela) )
								BEGIN
									SELECT @idAprob =apr_id, @idNot = not_id FROM @tblUsuCancela WHERE id = @contCancela
		
									UPDATE NOT_NOTIFICACION SET not_estatus = 5 WHERE not_id = @idNot
									UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprob;
									IF ((@idTipoNotificacion = 6 OR @idTipoNotificacion = 7 OR @idTipoNotificacion = 8) AND @usuarioAutoriza <> @disparador)
									BEGIN
										DELETE FROM [Notificacion].[dbo].[NOT_APROB_MANCOMUNADO] WHERE not_id = @idNot 
									END

									 SET @contCancela = @contCancela+1
								END
								
		
							Print 'hacer update a la notificacion'
		
							END
					
						SET @aprobar = 1
						Print 'SET @aprobar manco = 1'
						
					END
					INSERT INTO Notificacion.[dbo].[NOT_BITACORA]  VALUES (@idTipoNotificacion,@usuarioAutoriza,@not_identificador,'[dbo].[UPD_APROBACION_NOTIFICACION_SP]', 'Aprobó Notificacion con Id: ' + CONVERT(VARCHAR(100), @identificador), GETDATE() )
					SELECT 	1 estatus, 'Se realizó la aprobación correctamente' mensaje, idTipoNotificacion = @idTipoNotificacion 
				END
				ELSE
				BEGIN
							
					INSERT INTO @tblUsuCancela
					SELECT	usuario_mancomunado
							,not_id
							,emp_id
							,apr_id 
					FROM (
							SELECT MM.usuario_mancomunado 
							FROM CentralizacionV2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO MM
							LEFT JOIN @tblUsuarios USU ON USU.usuario = MM.usuario_mancomunado 
							WHERE idTipoNotificacion = @idTipoNotificacion
							AND usuario IS NULL) A 
					LEFT JOIN (
						    SELECT	 NN.not_id
									,NA.emp_id,NA.apr_id 
							FROM	NOT_NOTIFICACION NN 
						    INNER JOIN NOT_APROBACION  NA on NN.not_id = NA.not_id
							WHERE not_identificador =  @not_identificador) B ON A.usuario_mancomunado = B.emp_id
		
					--SELECT * from @tblUsuCancela
		
					
					WHILE (@contCancela <= (SELECT COUNT(1) FROM @tblUsuCancela) )
					BEGIN
						SELECT @idAprob =apr_id, @idNot = not_id FROM @tblUsuCancela WHERE id = @contCancela
		
						UPDATE NOT_NOTIFICACION SET not_estatus = 5 WHERE not_id = @idNot
						--UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;

						IF ((@idTipoNotificacion = 6 OR @idTipoNotificacion = 7 OR @idTipoNotificacion = 8) AND @usuarioAutoriza <> @disparador)
						BEGIN
							DELETE FROM [Notificacion].[dbo].[NOT_APROB_MANCOMUNADO] WHERE not_id = @idNot 
						END

					 SET @contCancela = @contCancela+1
					END
					Print 'Rechazo'
					SET @rechazar = 1
					INSERT INTO Notificacion.[dbo].[NOT_BITACORA]  VALUES (@idTipoNotificacion,@usuarioAutoriza,@not_identificador,'[dbo].[UPD_APROBACION_NOTIFICACION_SP]', 'Rechazó Notificacion con Id: ' + CONVERT(VARCHAR(100), @identificador), GETDATE() )
					SELECT 	1 estatus, 'Se realizó el rechazo correctamente' mensaje 
				END
		END

		
		
		
		-----------------------------------
		IF (@aprobar = 1)
		BEGIN
		
		--SELECT 	1 estatus, 'Se realizó la aprobación correctamente' mensaje 
		INSERT INTO Notificacion.[dbo].[NOT_BITACORA]  VALUES (@idTipoNotificacion,@usuarioAutoriza,@not_identificador,'[dbo].[UPD_APROBACION_NOTIFICACION_SP]', 'Aqui se ejecutó proceso de BPro para aprobar', GETDATE() )

		-- Inicio Clientes 
		--IF (@idTipoNotificacion = 10 )
		--BEGIN
						
		--		UPDATE clientes.dbo.TramiteCliente 
		--		SET observacion = 'En revision de Cyc', estatus = 3, fecha = GETDATE()
		--		WHERE tramites_Id = @not_identificador
				
		--END
		IF (@idTipoNotificacion = 5 OR @idTipoNotificacion = 6)
		BEGIN
				DECLARE @RespuestaCredito INT
				EXECUTE [Clientes].[dbo].[INS_CREDITO_SP]  @idPertra  = @not_identificador, @result = @RespuestaCredito OUTPUT
				IF(@RespuestaCredito = 0)
				BEGIN
					SELECT 1/0
				END	
																			 
																			 
				UPDATE [Tramites].[dbo].[personaTramite]
				SET petr_estatus = 2 
				WHERE id_perTra = @not_identificador	
				
				IF (@idTipoNotificacion = 6 AND @usuarioAutoriza <> @disparador)
			    BEGIN
					DELETE FROM [Notificacion].[dbo].[NOT_APROB_MANCOMUNADO] WHERE not_id = @identificador AND apr_id = @idAprobacion 
				END
													
		END
		-- Fin Clientes		
		
		--Inicio Devoluciones
		IF(@idTipoNotificacion = 7 OR @idTipoNotificacion = 8)
			BEGIN

				IF NOT EXISTS(SELECT * FROM [Tramites].[DBO].[cuentasTesoreria] WHERE id_perTra = @not_identificador)
					BEGIN	
						EXEC [Tramites].[DBO].[INS_TESORERIA_CUENTAS_SP] @not_identificador
					END

				--DECLARE @RespuestaInsert INT
				--EXEC [Tramites].[DBO].[INS_DATOS_CXC_DEVOLUCIONES] @not_identificador, @result = @RespuestaInsert OUTPUT
				--IF(@RespuestaInsert = 0)
				--	BEGIN
				--		SELECT 1/0
				--	END

				SELECT 
					@idTraDe = id_traDe
				FROM [Tramites].[dbo].tramiteDevoluciones WHERE id_perTra = @not_identificador;

				UPDATE [Tramites].[dbo].[tramiteDevoluciones]
				SET esDe_IdEstatus = 4,
				traDe_fechaAutoriza = GETDATE()
				WHERE id_traDe = @idTraDe;

				insert into  Tramites.dbo.BitacoraTramite values (@usuarioAutoriza,@not_identificador,'Se envia a autorizacion Tesoreria' , GETDATE(),4)
			

				

				IF (@usuarioAutoriza <> @disparador)
			    BEGIN
					DELETE FROM [Notificacion].[dbo].[NOT_APROB_MANCOMUNADO] WHERE not_id = @identificador AND apr_id = @idAprobacion 
				END

			END
		
		IF(@idTipoNotificacion = 14)
			BEGIN
				UPDATE [Tramites].[DBO].[tramiteDevoluciones] 
				SET traDe_banderaCC = 2 
				WHERE id_perTra = @not_identificador
			END
		--Fin Devoluciones

		--- Aprobacion Cuentas Bancarias
		IF(@idTipoNotificacion = 4)
			BEGIN
			
				DECLARE @idPersona NUMERIC(18,2)
				DECLARE @idPerTra INT, @idRespuestaUni INT
					

				SELECT @idPerTra = not_adjunto FROM NOT_NOTIFICACION WHERE Not_id = @identificador
				

				SELECT @idPersona = PER_IDPERSONA_GA
				FROM Centralizacionv2.[dbo].PROV_PROSPECTO WHERE PER_RFC = @not_identificador

				

				EXEC [dbo].[PROV_UPD_ACTIVAR_CUENTAS_SP] @not_identificador, @idPerTra, @result = @idRespuestaUni OUTPUT
				

				IF(@idRespuestaUni=0)
				BEGIN

				
				SELECT 1/0
				END

				

			END
		--------------------------------

	--Inicio Fondo Fijo
		IF(@idTipoNotificacion = 13)
			BEGIN

		select @esAumentoDecremento = AumentoDisminucion from Tramites.Tramite.fondoFijo where id_perTra = @not_identificador
		SET @esAumentoDecremento = ISNULL(@esAumentoDecremento,0)

		IF(@esAumentoDecremento = 0)
			BEGIN
			--Normal
				SELECT @idTraDe = id_traDe
				FROM [Tramites].[dbo].tramiteDevoluciones 
				WHERE id_perTra = @not_identificador;

				UPDATE [Tramites].[dbo].[personaTramite]
				SET petr_estatus = 2 
				WHERE id_perTra = @not_identificador

				UPDATE [Tramites].[dbo].[tramiteDevoluciones]
				SET esDe_IdEstatus = 2,
				traDe_fechaAutoriza = GETDATE()
				WHERE id_traDe = @idTraDe;
			END
		ELSE
			BEGIN

				--SELECT @idTraDe = id_traDe
				--FROM [Tramites].[dbo].tramiteDevoluciones 
				--WHERE id_perTra = @not_identificador;

				--UPDATE [Tramites].[dbo].[personaTramite]
				--SET petr_estatus = 2 
				--WHERE id_perTra = @not_identificador

				--UPDATE [Tramites].[dbo].[tramiteDevoluciones]
				--SET esDe_IdEstatus = 2,
				--traDe_fechaAutoriza = GETDATE()
				--WHERE id_traDe = @idTraDe;
			--AumentoDecremento
			select @montoCambio =ffc.montoCambiado, @aumentoDecremento = ffc.aumentoDecrementoFF  
			from Tramites.Tramite.fondofijo  ff
			inner join Tramites.Tramite.fondoFijoCambios ffc on ffc.id = ff.AumentoDisminucion
			where ff.id_perTra = @not_identificador

				IF(@aumentoDecremento = 1)
					BEGIN

					SELECT @idTraDe = id_traDe
					FROM [Tramites].[dbo].tramiteDevoluciones 
					WHERE id_perTra = @not_identificador;

					UPDATE [Tramites].[dbo].[personaTramite]
					SET petr_estatus = 2 
					WHERE id_perTra = @not_identificador

					UPDATE [Tramites].[dbo].[tramiteDevoluciones]
					SET esDe_IdEstatus = 2,
					traDe_fechaAutoriza = GETDATE()
					WHERE id_traDe = @idTraDe;

					--Aumento
					UPDATE  [Tramites].[dbo].tramiteDevoluciones 
					SET traDe_devTotal = traDe_devTotal + @montoCambio
					WHERE id_perTra = @not_identificador

					UPDATE Tramites.Tramite.fondofijo  
					SET montoDisponible = montoDisponible + @montoCambio
					WHERE id_perTra = @not_identificador

					UPDATE ffc
					SET ffc.estatus = 1
					from Tramites.Tramite.fondofijo  ff
					inner join Tramites.Tramite.fondoFijoCambios ffc on ffc.id = ff.AumentoDisminucion
					where ff.id_perTra = @not_identificador
					END
				ELSE
					BEGIN
					
					SELECT @idTraDe = id_traDe
					FROM [Tramites].[dbo].tramiteDevoluciones 
					WHERE id_perTra = @not_identificador;

					UPDATE [Tramites].[dbo].[personaTramite]
					SET petr_estatus = 2 
					WHERE id_perTra = @not_identificador

					UPDATE [Tramites].[dbo].[tramiteDevoluciones]
					SET esDe_IdEstatus = 3,
					traDe_fechaAutoriza = GETDATE()
					WHERE id_traDe = @idTraDe;
					--Decremento

					UPDATE  [Tramites].[dbo].tramiteDevoluciones 
					SET traDe_devTotal = traDe_devTotal - @montoCambio
					WHERE id_perTra = @not_identificador

					UPDATE Tramites.Tramite.fondofijo  
					SET montoDisponible = montoDisponible - @montoCambio
					WHERE id_perTra = @not_identificador

					UPDATE ffc
					SET ffc.estatus = 1
					from Tramites.Tramite.fondofijo  ff
					inner join Tramites.Tramite.fondoFijoCambios ffc on ffc.id = ff.AumentoDisminucion
					where ff.id_perTra = @not_identificador
					END

				END
				
				--INSERT INTO [Tramites].dbo.BitacoraTramite ([idUsuario], [id_perTra], [accion],[fechaMovimiento])
				--VALUES (@usuarioAutoriza, @not_identificador, 'Se aprobo por Corporativo', GETDATE())
				--INSERT INTO [Tramites].dbo.ProcesoTramite ([id_perTra], [idUsuario], [idEstatus], [hrInicio], [hrFin])
				--VALUES (@not_identificador, @usuarioAutoriza, 2, GETDATE(), NULL)
			END
		--Fin Fondo Fijo
		
		--Inicio Autorización Vale Evidencia de Fondo Fijo
			IF(@idTipoNotificacion = 19)
			BEGIN
				UPDATE  tramites.tramite.valesEvidencia 
				SET estatusReembolso = null, envioReembolso = null, id_perTraReembolso = null
				WHERE id =  @not_identificador;
			END
		--Fin Autorización Vale Evidencia de Fondo Fijo
		
		--Inicio Autorización de mas Vale Evidencia de Fondo Fijo
			IF(@idTipoNotificacion = 20)
			BEGIN
				UPDATE  tramites.tramite.valesEvidencia 
				SET envioNotificacion = 2, comprobacionMas = 1
				WHERE id =  @not_identificador;
				--EXEC [Tramites].[dbo].[INS_FONDOFIJO_ORDENMASIVA_NOTI_SP] @not_identificador, 1;
			END
		--Fin Autorización de mas Vale Evidencia de Fondo Fijo
		
		 --Inicio Autorización de cierre de Fondo Fijo
			IF(@idTipoNotificacion = 21)
			BEGIN	
			UPDATE [Tramites].[dbo].tramitedevoluciones 
			SET esDe_IdEstatus = 7 
			WHERE id_pertra = @not_identificador
			END
		--Fin Autorización de cierre de Fondo Fijo
		
		--Inicio Autorización Factura de Vale 
			IF(@idTipoNotificacion = 22)
			BEGIN
				EXEC [Tramites].[dbo].[UPD_FACTURA_NOTI_SP]  @not_identificador;
			END
		--Fin Autorización Factura de Vale
		
				
		--Inicio Autorización Factura de Vale Contraloria
			IF(@idTipoNotificacion = 23)
			BEGIN
			UPDATE Tramites.Tramite.facturaVale
			SET estatusNotificacion = 6
			where idValeEvidencia = @not_identificador
			END
		--Fin Autorización Factura de Vale Contraloria

		--Inicio Autorización Factura de GV
			IF(@idTipoNotificacion = 35)
			BEGIN
			EXEC [Tramites].[dbo].[UPD_FACTURA_NOTI_GV_SP]  @not_identificador;
			END
			--Fin Autorización Factura de GV

		--Inicio Autorización Factura de GV Contraloria
			IF(@idTipoNotificacion = 36)
			BEGIN
			UPDATE Tramites.Tramite.conceptoArchivo
			SET estatusNotificacion = 6
			where idConceptoArchivo = @not_identificador
			END
			--Fin Autorización Factura de Vale Contraloria

			--Inicio Vales Fondo Fijo
		IF(@idTipoNotificacion = 16)
		BEGIN

			DECLARE @idFondoFijo INT, @valido INT, @montoSolicitado DECIMAL (18,2)

			SELECT @idFondoFijo = VFF.idTablaFondoFijo, @montoSolicitado= V.montoSolicitado from [Tramites].[Tramite].[vales] V
			inner join [Tramites].[Tramite].[valesFondoFijo] VFF on VFF.idVales = V.id
			WHERE V.id = @not_identificador

			--SE AGREGA PARA VALIDAR EL SALDO DEL FONDO
			DECLARE @nombreBD VARCHAR(30) ,@idEmpresa INT ,@query NVARCHAR(MAX) ,@idResponsable int ,@cuentaContable VARCHAR(60) ,@fondoFijo varchar(30)
			,@nombreResponsableFF varchar(150),@clienteBPRO varchar(15),@montoDisponible DECIMAL(18,4)
	
			SELECT @idEmpresa = f.idEmpresa ,@idResponsable = f.idResponsable ,@fondoFijo = idFondoFijo
			FROM Tramites.Tramite.fondoFijo f WHERE f.id = @idFondoFijo
			
			SELECT @nombreBD = ce.emp_nombrebd FROM ControlAplicaciones.dbo.cat_empresas ce WHERE ce.emp_idempresa = @idEmpresa

			SELECT  @clienteBPRO = idpersona FROM Tramites.[Tramite].[cat_CuentasContableFFGV] WHERE idUsuario = @idResponsable

			SET @query = 'SELECT  @montoDisponible = isnull(SUM(CCP_CARGO),0) - isnull(SUM(CCP_ABONO),0) 
						  FROM '+ @nombreBD +'.DBO.VIS_CONCAR01 WHERE CCP_IDDOCTO = '''+@fondoFijo+''' and CCP_IDPERSONA = '''+@clienteBPRO+''''
			EXECUTE sp_executeSQL @query, N' @montoDisponible DECIMAL(18,4) OUTPUT',@montoDisponible OUTPUT
			--SE AGREGA PARA VALIDAR EL SALDO DEL FONDO

			--SELECT @valido=  CASE WHEN  @montoSolicitado + ISNULL(sum(V.montoSolicitado),0) <= TD.traDe_devTotal  THEN 1  ELSE 0 END 
			SELECT @valido=  CASE WHEN  @montoSolicitado + ISNULL(sum(V.montoSolicitado),0) <= @montoDisponible  THEN 1  ELSE 0 END 
			FROM [Tramites].[Tramite].[valesFondoFijo] VFF
			inner join [Tramites].[Tramite].[fondoFijo] FF on FF.id = VFF.idTablaFondoFijo
			inner join  [Tramites].[dbo].[tramiteDevoluciones] TD on TD.id_perTra = FF.id_perTra
			left join [Tramites].[Tramite].[vales] V on VFF.idVales = V.id  and V.estatusVale in (2) 
			WHERE idTablaFondoFijo = @idFondoFijo
			GROUP BY TD.traDe_devTotal


			IF(@valido = 1)
			BEGIN
				UPDATE [Tramites].[Tramite].[vales] set estatusVale = 2
					WHERE id = @not_identificador;
				INSERT INTO Notificacion.[dbo].[NOT_BITACORA]  VALUES (@idTipoNotificacion,@usuarioAutoriza,@not_identificador,'[dbo].[UPD_APROBACION_NOTIFICACION_SP]', 'Aprobó Notificacion con Id: ' + CONVERT(VARCHAR(100), @identificador), GETDATE() )
				SELECT 	1 estatus, 'Se realizó la aprobación correctamente' mensaje, idTipoNotificacion = @idTipoNotificacion 
			END
			ELSE
			BEGIN
			
				-- Actualiza el estatus a 2 ya que no tiene efectivo el fondo fijo, para que se pueda rechazar posteriormente.
				UPDATE Notificacion.[dbo].NOT_NOTIFICACION SET not_estatus = 2 WHERE not_id = @identificador
				UPDATE Notificacion.[dbo].NOT_APROBACION SET apr_estatus = 2 WHERE apr_id = @idAprobacion

				-- Inserta en la bitácora
			    INSERT INTO Notificacion.[dbo].[NOT_BITACORA]  VALUES (@idTipoNotificacion,@usuarioAutoriza,@not_identificador,'[dbo].[UPD_APROBACION_NOTIFICACION_SP]', 'El fondo fijo no cuenta con suficiente efectivo', GETDATE() )
				-- Borra de registro de la tabla NOT_APROBACION_RESPUESTA 
				DELETE FROM Notificacion.[dbo].[NOT_APROBACION_RESPUESTA] WHERE not_id = @identificador AND apr_id = @idAprobacion
			
				select 2 estatus, 'El fondo fijo no cuenta con suficiente efectivo, favor de rechazar el vale' mensaje
			END
		END	
		-- Fin Vales Fondo Fijo

		
		
		/*
		INICIA TRANSFERENCIAS
		*/
		IF(@idTipoNotificacion = 15)
		begin
		 print '@not_identificador. '+ cast(@not_identificador as varchar(20))
			update tb
			set tb.fechaAutorizacion = getdate()
			, autorizado = 1
			from Tesoreria.dbo.TransferenciasBancarias tb
			where tb.id = @not_identificador

			declare @idFolioTran int = 0, 
			@idPerTramite int = 0,
			@usuarioSolicita int = 0

			INSERT INTO GA_Corporativa.dbo.tsb_traspasosaldobancos (tsb_idempresa, tsb_idsucursal, tsb_cuentaorigen, tsb_cuentadestino, tsb_importe, tsb_moneda, tsb_concepto, tsb_estatus, tsb_fechasolicita, tsb_usuariosolicita)
			SELECT tb.idEmpresa
				  ,tb.idSucursal
				  ,tb.cuentaOrigen
				  ,tb.cuentaDestino
				  ,tb.importe
				  ,tb.moneda
				  ,'DTRASSALDOINGTS'
				  , -1
				  ,GETDATE()
				  ,tb.usuario 
			FROM Tesoreria.dbo.TransferenciasBancarias tb
			WHERE tb.id = @not_identificador

			set @idFolioTran = @@identity

			set @usuarioSolicita = (
										select	tb.usuario 
										FROM Tesoreria.dbo.TransferenciasBancarias tb
										WHERE tb.id = @not_identificador
									)

			INSERT INTO Tesoreria.dbo.transferenciasLog (idtransferencia)
			VALUES (@idFolioTran);

			INSERT INTO tramites.[dbo].[personaTramite]
           ([id_persona]
           ,[id_tramite]
           ,[petr_fechaTramite]
           ,[petr_estatus]
		   ,esDe_IdEstatus)
			 VALUES(
				   @usuarioSolicita,
				   11,
				   GETDATE(),
				   0,
				   1)

			set @idPerTramite = @@IDENTITY

			INSERT INTO tramites.[dbo].cuentasTesoreria(
				id_perTra
				,fechaInsercion
				,estatus
				,fechaAtencion
				,id_tipoTramite
			)
			values(
			 @idPerTramite
			 ,GETDATE()
			 ,1
			 ,NULL
			 ,11
			)

			update tl
			set tl.idPerTra = @idPerTramite
			from Tesoreria.dbo.transferenciasLog tl
			where tl.idtransferencia = @idFolioTran



		end
		/*
		FINALIZA TRANSFERENCIAS
		*/
		
		--- IF con los procesos a realizar dependiendo del tipo notificacion
		print 'Apruebo proceso por tipo de notificacion'
		END
		IF (@rechazar = 1)
		BEGIN
		
		INSERT INTO Notificacion.[dbo].[NOT_BITACORA]  VALUES (@idTipoNotificacion,@usuarioAutoriza,@not_identificador,'[dbo].[UPD_APROBACION_NOTIFICACION_SP]', 'Aqui se ejecutó proceso de BPro para rechazar', GETDATE() )
		--- IF con los procesos a realizar dependiendo del tipo notificacion

			-- Clientes 
			IF (@idTipoNotificacion = 10 OR @idTipoNotificacion = 5 OR @idTipoNotificacion = 6)
			BEGIN
				UPDATE clientes.dbo.TramiteCliente 
				SET observacion = 'Rechazado', estatus = 6, fecha = GETDATE()
				WHERE tramites_Id = @not_identificador

				DECLARE @estatusAct INT = 0
				SELECT @estatusAct = estatus FROM  clientes.dbo.TramiteCliente WHERE tramites_Id = @not_identificador 
				
				UPDATE [clientes].[dbo].[ProcesoTramite] SET hrFin = GETDATE() WHERE id_perTra = @not_identificador AND estatus = @estatusAct 
				INSERT INTO [clientes].[dbo].[ProcesoTramite] VALUES (@not_identificador , 6, GETDATE(), GETDATE() )

				UPDATE [Tramites].[dbo].[personaTramite]
				SET petr_estatus = 3 
				WHERE id_perTra = @not_identificador

				IF (@idTipoNotificacion = 6 AND @usuarioAutoriza <> @disparador)
			    BEGIN
					DELETE FROM [Notificacion].[dbo].[NOT_APROB_MANCOMUNADO] WHERE not_id = @identificador AND apr_id = @idAprobacion 
				END
			END
			-- Fin Clientes	

			--Inicio Devluciones
			IF(@idTipoNotificacion = 7 OR @idTipoNotificacion = 8 OR @idTipoNotificacion = 14)
				BEGIN

					SELECT 
						@idTraDe = id_traDe 
					FROM [Tramites].[dbo].[tramiteDevoluciones] WHERE id_perTra = @not_identificador;

					UPDATE [Tramites].[dbo].[documentosDevueltos] 
					SET docDe_valorDev = 0.00
					WHERE id_traDe = @idTraDe;

					UPDATE [Tramites].[dbo].[tramiteDevoluciones]
					SET traDe_fechaAutoriza = GETDATE(), traDe_banderaCC = 4
					WHERE id_traDe = @idTraDe;

					UPDATE [Tramites].[dbo].[personaTramite]
					SET petr_estatus = 3 
					WHERE id_perTra = @not_identificador;

					IF (@usuarioAutoriza <> @disparador)
					BEGIN
						DELETE FROM [Notificacion].[dbo].[NOT_APROB_MANCOMUNADO] WHERE not_id = @identificador AND apr_id = @idAprobacion 
					END

				END
			--Fin Devoluciones

				--Inicio Fondo Fijo
		IF(@idTipoNotificacion = 13)
			BEGIN

		select @esAumentoDecremento = AumentoDisminucion from Tramites.Tramite.fondoFijo where id_perTra = @not_identificador
		SET @esAumentoDecremento = ISNULL(@esAumentoDecremento,0)

		IF(@esAumentoDecremento = 0)
			BEGIN
				--Normal
					
				SELECT @idTraDe = id_traDe 
				FROM [Tramites].[dbo].[tramiteDevoluciones] 
				WHERE id_perTra = @not_identificador;

				UPDATE [Tramites].[dbo].[documentosDevueltos] 
				SET docDe_valorDev = 0.00 
				WHERE id_traDe = @idTraDe;

				UPDATE [Tramites].[dbo].[tramiteDevoluciones]
				SET traDe_fechaAutoriza = GETDATE(),  esDe_IdEstatus = 4
				WHERE id_traDe = @idTraDe;

				UPDATE [Tramites].[dbo].[personaTramite]
				SET petr_estatus = 3 
				WHERE id_perTra = @not_identificador;
			END
		ELSE
			BEGIN

					SELECT @idTraDe = id_traDe
					FROM [Tramites].[dbo].tramiteDevoluciones 
					WHERE id_perTra = @not_identificador;

					UPDATE [Tramites].[dbo].[personaTramite]
					SET petr_estatus = 2 
					WHERE id_perTra = @not_identificador

					UPDATE [Tramites].[dbo].[tramiteDevoluciones]
					SET esDe_IdEstatus = 3,
					traDe_fechaAutoriza = GETDATE()
					WHERE id_traDe = @idTraDe;
					--AumentoDecremento
					UPDATE ffc
					SET ffc.estatus = 2
					from Tramites.Tramite.fondofijo  ff
					inner join Tramites.Tramite.fondoFijoCambios ffc on ffc.id = ff.AumentoDisminucion
					where ff.id_perTra = @not_identificador

				END

			END
		--Fin Fondo Fijo
		
			--Inicio Fondo Fijo
		IF(@idTipoNotificacion = 19)
			BEGIN
				--UPDATE  tramites.tramite.valesEvidencia 
				--SET estatusReembolso = 0, idestatus = 3
				--WHERE id =  @not_identificador;		
				--ACA TENGO QUE PONER UN SP PARA LA DESAPLICACION
				EXEC [Tramites].[dbo].[INS_FONDOFIJO_CANCELAORDENMASIVA_NOTI_SP] @not_identificador;
			END
		--Fin Fondo Fijo
		
		--Inicio Autorización de mas Vale Evidencia de Fondo Fijo
			IF(@idTipoNotificacion = 20)
			BEGIN
				--UPDATE  tramites.tramite.valesEvidencia 
				--SET  idestatus= 3
				--WHERE id =  @not_identificador;

				UPDATE  tramites.tramite.valesEvidencia 
				SET envioNotificacion = 2, compNoAutorizado = 1, comprobacionMas = 1
				WHERE id =  @not_identificador;
				--EXEC [Tramites].[dbo].[INS_FONDOFIJO_ORDENMASIVA_NOTI_SP] @not_identificador, 2;
			END
		--Fin Autorización de mas Vale Evidencia de Fondo Fijo
		
		--Inicio Autorización de cierre de Fondo Fijo
			IF(@idTipoNotificacion = 21)
			BEGIN	
			UPDATE tramites.tramite.fondofijo 
			SET estatusfondofijo = 1 
			WHERE id_pertra = @not_identificador
			END
		--Fin Autorización de cierre de Fondo Fijo
		
		--Inicio Autorización Factura de Vale
			IF(@idTipoNotificacion = 22)
			BEGIN
				UPDATE tramites.Tramite.facturaVale
				SET estatusNotificacion = 4
				where idValeEvidencia = @not_identificador

				UPDATE tramites.tramite.valesEvidencia
				SET idEstatus = 3
				WHERE id =  @not_identificador
			END
		--Fin Autorización Factura de Vale

		--Inicio Autorización Factura de Vale Contraloria
			IF(@idTipoNotificacion = 23)
			BEGIN
				UPDATE Tramites.Tramite.facturaVale
				SET estatusNotificacion = 7
				where idValeEvidencia = @not_identificador

				UPDATE tramites.tramite.valesEvidencia
				SET idEstatus = 3
				WHERE id =  @not_identificador
			END
		--Fin Autorización Factura de Vale Contraloria

				--Inicio Autorización Factura de GV
		IF(@idTipoNotificacion = 35)
		BEGIN
		UPDATE tramites.tramite.conceptoarchivo
		SET estatusNotificacion = 4
		where idconceptoarchivo = @not_identificador
		END
		--Fin Autorización Factura de GV

		--Inicio Autorización Factura de GV Contraloria
			IF(@idTipoNotificacion = 36)
			BEGIN
			UPDATE Tramites.Tramite.ConceptoArchivo
			SET estatusNotificacion = 7, idestatus =10
			where idconceptoArchivo = @not_identificador
			END
			--Fin Autorización Factura de GV Contraloria
		
		--Inicio Vales Fondo Fijo
		IF(@idTipoNotificacion = 16)
		BEGIN
			UPDATE [Tramites].[Tramite].[vales] set estatusVale = 5
			WHERE id = @not_identificador;
		END	
		-- Fin Vales Fondo Fijo
		
		/*
		INICIA TRANSFERENCIAS
		*/
		IF(@idTipoNotificacion = 15)
		begin
		 print '@not_identificador. '+ cast(@not_identificador as varchar(20))
			update tb
			set tb.fechaAutorizacion = getdate()
			, autorizado = 2
			from Tesoreria.dbo.TransferenciasBancarias tb
			where tb.id = @not_identificador

		end
		/*
		FINALIZA TRANSFERENCIAS
		*/


		print 'Rechazo proceso por tipo de notificacion'
		END
			
	COMMIT TRANSACTION	
	END TRY
	
	BEGIN CATCH
	ROLLBACK TRANSACTION	
	DECLARE @Mensaje  nvarchar(max)
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP 'UPD_APROBACION_NOTIFICACION_SP', @Mensaje 
	
	SELECT ERROR_NUMBER() estatus, 'No se pudo ejecutar el proceso. Intente de nuevo.' mensaje
	
	
	END CATCH

END


go

