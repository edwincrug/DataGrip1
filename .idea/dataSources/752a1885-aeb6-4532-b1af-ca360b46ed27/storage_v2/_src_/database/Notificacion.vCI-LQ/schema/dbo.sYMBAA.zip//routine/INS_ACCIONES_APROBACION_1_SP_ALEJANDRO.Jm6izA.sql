-- =============================================
-- Author: Genaro Mora Valencia
-- Create date: 03/12/2015
-- Modified date: 13/01/2016  Lourdes Maldonado Sánchez(LMS)
-- Description:	Stored de control de las acciones de Aprobación para LOTE
-- Regresa el número del último registro insertado.
-- =============================================
-- [INS_ACCIONES_APROBACION_1_SP] 322,1,'ok',234,2
CREATE PROCEDURE [dbo].[INS_ACCIONES_APROBACION_1_SP_ALEJANDRO] 
	@idAprobacion int            
	,@respuesta   int
	,@observacion nvarchar(max)
	,@not_identificador int      
	,@usuario1 int
AS
BEGIN

	SET NOCOUNT ON;
	BEGIN
		IF(@respuesta=1)
		BEGIN
					--Apruebas en Notificaciones, apr_id enviarlo desde not a pagos
					
						UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;
						----------------------------------------------------------------
						-------Inserta una respuesta de aprobación
						----------------------------------------------------------------
						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
						VALUES
							(@not_identificador,@idAprobacion,GETDATE(),@observacion)	
					
						
						----------------------------------------------------------------------	
						--      Agregado por LMS 13/01/2016  para cerrar el nodo 7 y 8      --
						----------------------------------------------------------------------
						DECLARE @total INT = (SELECT count(1) FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_numerolote in ( 
													        SELECT N.not_identificador 
																FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
															WHERE A.apr_id = @idAprobacion)  )
						DECLARE @aux   INT = 1
						DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), folio VARCHAR(50))
						
						INSERT INTO @VariableTabla  SELECT oce_folioorden
													         FROM [cuentasxpagar].[dbo].[cxp_ordencompra]
													        WHERE oce_numerolote in ( 
													        SELECT N.not_identificador 
																FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
															WHERE A.apr_id = @idAprobacion)
						
						WHILE(@aux <=  @total)
							BEGIN
								declare @folioactual as nvarchar(80)
								SELECT @folioactual = folio FROM @VariableTabla WHERE ID = @aux
								--INS_CIERRA_NODO_SP 7 
								EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
													   @proc_Id = 1  
													  ,@nodo_Id = 7 
													  ,@folio_Operacion = @folioactual
								--INS_CIERRA_NODO_SP 8
								EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
													   @proc_Id = 1 
													  ,@nodo_Id = 8
													  ,@folio_Operacion = @folioactual
								--SELECT @aux
								SET @aux = @aux + 1
								
								
								--LUEGO!!!
								--Ir a [cuentasxpagar].[dbo].[cxp_ordencompra] y actualixar el campo sod_idsituacionorden = 11
								--
							END
						----------------------------------------------------------------------
						----------------------------------------------------------------------		
									
		END
		ELSE  
		BEGIN
						--Entrando a cancelar la orden
						UPDATE NOT_NOTIFICACION SET not_estatus = 4 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						UPDATE NOT_APROBACION SET apr_estatus = 4 WHERE apr_id = @idAprobacion;
						----------------------------------------------------------------
						-------Inserta una respuesta de aprobación
						----------------------------------------------------------------
						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
						VALUES
							(@not_identificador,@idAprobacion,GETDATE(),@observacion)	
						--Rechaza Lote
						UPDATE dbo.Lote_Cuentasxpagar set  slt_idsituacion = 3
						WHERE lts_numlote = (SELECT N.not_identificador 
							FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
							WHERE A.apr_id = @idAprobacion)											

		END	
	END

END


go

