CREATE PROCEDURE [dbo].[APR_INS_AGRUP11_SP] 
	@idAprobacion INT = 0
	,@idnotificacion INT = 0
	,@respuesta INT = 0
	,@observacion VARCHAR(MAX) = ''
	,@folio VARCHAR(100) = ''
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
AS
BEGIN
	SET NOCOUNT ON;	
		BEGIN TRAN TRAN_APR_INS_AGRUP11

	BEGIN TRY
		DECLARE @numeroSerie VARCHAR(50) = '', @base VARCHAR(50) = '',@server VARCHAR(50) = '', @query VARCHAR(MAX) = '' 
		DECLARE @idEstatus INT = 0, @mensaje VARCHAR(500) = '',@estatusNotificacion INT = 0, @resp VARCHAR(30) = '',@ipLocal VARCHAR(20) = ''
			IF(@respuesta = 1) --Aprobado
				BEGIN
							
					SELECT @base ='['+ nombre_base + ']', @server = ip_servidor 
					FROM CentralizacionV2..DIG_CAT_BASES_BPRO 
					WHERE emp_idempresa = @idEmpresa 
							AND suc_idSucursal = @idSucursal
							AND tipo = 1
					
					SELECT @ipLocal=local_net_address 
					FROM sys.dm_exec_connections c
					WHERE session_id = @@SPID
  
  
					IF(LTRIM(RTRIM(@ipLocal))!=RTRIM(LTRIM(@server)))
						SET @base = '['+ @server +'].'+@base
										
					SELECT @query = 'SELECT sv.VEH_NUMSERIE, sv.VEH_SITUACION 
					FROM cuentasporcobrar..uni_cotizacionuniversal cu, cuentasporcobrar.dbo.uni_cotizacionuniversalunidades cuu,
					' + @base + '.[dbo].[SER_VEHICULO] sv
					WHERE cu.ucu_idcotizacion=cuu.ucu_idcotizacion
					AND cuu.ucn_noserie=sv.VEH_NUMSERIE
					AND cu.ucu_foliocotizacion = ''' + @folio + ''''

					DECLARE @resultadoVEH TABLE(Id INT IDENTITY(1,1),VEH_NUMSERIE VARCHAR(30), VEH_SITUACION VARCHAR(20))										
					print @query

					INSERT INTO @resultadoVEH
					EXECUTE(@query)

					SELECT TOP(1) @numeroSerie = VEH_NUMSERIE FROM @resultadoVEH

					DECLARE @depto VARCHAR(10) = ''

					SELECT @depto = DE.dep_nombrecto /*ucu_idempresa,ucu_idsucursal,*/ 
					FROM cuentasporcobrar..uni_cotizacionuniversal CU 
					LEFT JOIN cuentasporcobrar..cat_departamentos DE ON CU.ucu_iddepartamento = DE.dep_iddepartamento 
					WHERE CU.ucu_foliocotizacion = @folio--
										
					SELECT @query = 'UPDATE [' + @server +'].[' + @base + '].[dbo].[SER_VEHICULO] 
												SET VEH_SITUACION =  ''FIS''  
												WHERE VEH_NUMSERIE = ''' + @numeroSerie + ''''
					print @query		
					EXECUTE(@query)

					--SELECT @query = 'UPDATE cuentasporcobrar..uni_cotizacionuniversalunidades SET ucn_noserie = ''''
								--			WHERE ucn_noserie = ''' + @numeroSerie + ''' AND ucu_idcotizacion IN (SELECT ucu_idcotizacion FROM cuentasporcobrar..uni_cotizacionuniversal 
								--			 WHERE ucu_foliocotizacion = ''' + @folio + ''')'

					--SELECT @query = 'UPDATE [' + @server +'].[' + @base + '].[dbo].[SER_VEHICULO] SET VEH_SITUACION = ''FIS'' WHERE VEH_NUMSERIE = ''' + @folio + ''' AND '
					--EXECUTE(@query)

					SELECT @idEstatus = 0, @estatusNotificacion = 3, @mensaje = 'La unidad con VIN: '  + @numeroSerie + ' ha sido cambiada ha DISPONIBLE.', @resp = 'Aprobado: '
									
					--SELECT * FROM @resultado
					--PRINT @query
				END --@respuesta = 1 aprobado
			ELSE
				SELECT @idEstatus = 0, @estatusNotificacion = 4, @mensaje = 'La solicitud para el desapartado de unidad ' + @numeroSerie + ' ha sido rechazada.',@resp = 'Rechazado: '
				

			UPDATE NOT_NOTIFICACION SET not_estatus = @estatusNotificacion WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
			UPDATE NOT_APROBACION SET apr_estatus = @estatusNotificacion WHERE apr_id = @idAprobacion;							
			----------------------------------------------------------------
			-------Inserta una respuesta de aprobación
			----------------------------------------------------------------							
			INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]
				(not_id,[apr_id],[nar_fecha],[nar_comentario])
			VALUES
				(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)

			SELECT @idEstatus estatus, @mensaje mensaje
		
		COMMIT TRAN TRAN_APR_INS_AGRUP11	
					
	END TRY
    BEGIN CATCH

		ROLLBACK TRAN TRAN_APR_INS_AGRUP11
			
			DECLARE @MensajeEr VARCHAR(MAX) = '',
			@Componente VARCHAR(50) = 'APR_INS_AGRUP11'
			SELECT @MensajeEr = ERROR_MESSAGE()
			DECLARE @parametros  nvarchar(500) = 'Componente externo a BD'
			
			IF EXISTS (SELECT * FROM sysobjects WHERE name=@componente) 
			BEGIN
				SELECT @parametros = COALESCE(@parametros + ', ', '') + PARAMETER_NAME  from INFORMATION_SCHEMA.PARAMETERS Where SPECIFIC_NAME = @componente
			END

			INSERT INTO Error(componente, parametros, mensaje,fecha) VALUES (@componente, @parametros, @MensajeEr + @folio,GETDATE())
					
			SELECT ERROR_NUMBER() estatus, @MensajeEr mensaje
					
	END CATCH

END
go

