CREATE PROCEDURE [dbo].[SEL_FILTRO_USUARIO_SP]   
 @idUsuario INT   
AS  
BEGIN  
  
  
		DECLARE @tblFiltro AS TABLE  
		(  
		 idTipoFiltro INT  
		 ,notificaciones INT  
		)  
		
		INSERT INTO @tblFiltro  
		SELECT  F.idTipoFiltro, COUNT (N.not_id) notificaciones  
		FROM Notificacion.DBO.NOT_FILTRO_AGRUPACION F  
		INNER JOIN  NOT_NOTIFICACION AS N  ON  F.not_agrupacion = N.not_agrupacion      
		LEFT JOIN dbo.NOT_APROBACION AS A ON  N.not_id = A.not_id  
		WHERE  A.emp_id = @idUsuario    
		   AND ((N.not_estatus IN (1,2,6)) AND (A.apr_estatus IN (1,2)))   
		   AND A.apr_escalado IN (-1,0)  
		   AND ((N.not_agrupacion = 3 AND A.apr_estatus = 1) OR (N.not_agrupacion != 3) OR (A.apr_estatus = 2))  
		   AND  N.not_tipo in( 1,2,4)   
		GROUP BY F.idTipoFiltro  
  		UNION ALL  
  		SELECT  0 idTipoFiltro, COUNT (N.not_id) notificaciones  
		FROM Notificacion.DBO.NOT_FILTRO_AGRUPACION F  
		INNER JOIN  NOT_NOTIFICACION AS N  ON  F.not_agrupacion = N.not_agrupacion      
		LEFT JOIN dbo.NOT_APROBACION AS A ON  N.not_id = A.not_id  
		WHERE  A.emp_id = @idUsuario  
		   AND ((N.not_estatus IN (1,2,6)) AND (A.apr_estatus IN (1,2)))   
		   AND A.apr_escalado IN (-1,0)  
		   AND ((N.not_agrupacion = 3 AND A.apr_estatus = 1) OR (N.not_agrupacion != 3) OR (A.apr_estatus = 2))  
		   AND  N.not_tipo in( 1,2,4)   
  
  
   
     
		SELECT  FU.idTipoFiltro   
		  ,TF.nombre + ' ('+ convert(varchar(10),ISNULL(T.notificaciones,0))+')' as nombre  
		FROM Notificacion.dbo.NOT_FILTRO_USUARIO  FU  
		INNER JOIN Notificacion.dbo.NOT_TIPO_FILTRO TF ON FU.idTipoFiltro = TF.idTipoFiltro  
		INNER JOIN @tblFiltro T on T.idTipoFiltro = FU.idTipoFiltro  
		WHERE  idUsuario = @idUsuario   
   
END
go

