--
--  EXEC INS_NOTIFICACION_JERARQUIZADA 'J0012',517,1, 'Prueba notificacion jerarquizada',4,6,26, NULL,NULL,NULL
--
create PROCEDURE [dbo].[INS_NOTIFICACION_JERARQUIZADA]
@identificador		 VARCHAR(50) 
,@idSolicitante		 NUMERIC(18,0) 
,@idTipoNotJerarquizada INT 
,@descripcion		 VARCHAR(MAX) 
,@idEmpresa			 INT 
,@idSucursal		 INT 
,@idDepartamento	 INT 
,@linkBPRO			 VARCHAR(MAX) = NULL
,@notAdjunto		 VARCHAR(MAX) = NULL 
,@notAdjuntoTipo	 VARCHAR(500) = NULL
AS
BEGIN
BEGIN TRANSACTION
BEGIN TRY


--DECLARE  @identificador		 VARCHAR(50)  = 'J0001'
--			,@idSolicitante		 NUMERIC(18,0) = 517
--			,@idTipoNotJerarquizada INT  = 1
--			,@descripcion		 VARCHAR(MAX) = 'Prueba notificacion jerarquizada'
--			,@idEmpresa			 INT = 4
--			,@idSucursal		 INT = 6
--			,@idDepartamento	 INT = 26
--			,@linkBPRO			 VARCHAR(MAX) = NULL
--			,@notAdjunto		 VARCHAR(MAX) = NULL 
--			,@notAdjuntoTipo	 VARCHAR(500) = NULL

declare @idPadre int 
		,@idNot INT
		,@aprobador			NUMERIC(18,0) = NULL
		,@notAgrupacion		NUMERIC(18,0)
		,@apr_usu1			INT=0
		,@apr_usu2			INT=0
		,@apr_usu3			INT=0
		,@empresaSucursal   VARCHAR(10)
		,@success           BIT
		,@idApr	            NUMERIC(18,0) = NULL
	



SELECT @idPadre = idPadre FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO  where idUsuario = @idSolicitante and idtipoNotificacionJeraquizada = @idTipoNotJerarquizada

select @aprobador = idUsuario FROM Centralizacionv2.dbo.DIG_ESCALAMIENTO_JERARQUIZADO  where id = @idPadre

select @notAgrupacion = not_agrupador  from Centralizacionv2.dbo.[DIG_CAT_NOTIFICACION_JERARQUIZADA] where idtipoNotificacionJeraquizada = @idTipoNotJerarquizada

--select @aprobador,@notAgrupacion



			/*Insertar Notificacion*/

					INSERT INTO NOT_NOTIFICACION (
										  not_tipo
										, not_tipo_proceso
										, not_identificador
										, not_nodo
										, not_descripcion
										, not_estatus
										, not_fecha
										, not_link_BPRO
										, not_adjunto
										, not_adjunto_tipo
										, not_agrupacion
										, idEmpresa
										, idSucursal
										,idDepartamento
										)
						VALUES			( 
										  1
										, 1
										, @identificador
										, 0
										, @descripcion
										, 2
										, GETDATE()
										, @linkBPRO
										, @idSolicitante -- @notAdjunto
										,NULL
										, @notAgrupacion
										, @idEmpresa
										, @idSucursal
										, @idDepartamento
										)

					SET @idNot  = @@IDENTITY
					SET @success = 1

					--Solicitante (si aprobador = solicitante, solo se inserta aprobador)
					IF(@aprobador != @idsolicitante OR @aprobador IS NULL) 
					BEGIN
						INSERT INTO [dbo].[NOT_APROBACION]
							   ([not_id]
							   ,[apr_nivel]
							   ,[apr_visto]
							   ,[emp_id]
							   ,[apr_fecha]
							   ,[apr_estatus]
							   ,[apr_escalado])
						 VALUES
							   (@idNot
							   ,0
							   ,NULL
							   ,@idsolicitante
							   ,GETDATE()
							   ,1
							   ,-1)
					END
		   
					--Aprobador

					INSERT INTO [dbo].[NOT_APROBACION]
						   ([not_id]
						   ,[apr_nivel]
						   ,[apr_visto]
						   ,[emp_id]
						   ,[apr_fecha]
						   ,[apr_estatus]
						   ,[apr_escalado])
					 VALUES
						   (@idNot
						   ,0
						   ,NULL
						   ,@aprobador
						   ,GETDATE()
						   ,2
						   ,0)
	
					set @idApr = @@identity

					INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
					VALUES (5,'INS_NOTIFICACION_JERARQUIZADA @aprobador:' + CONVERT(VARCHAR(5),@aprobador) ,GETDATE())

					SELECT  @idNot not_id, @success success, 1 result , 'message' = 'La operación se realizó con exito.' ,@idApr as apr_id, @aprobador idUsuario

--select * from Notificacion.dbo.NOT_NOTIFICACION where not_id = @idNot
--select * from Notificacion.dbo.NOT_APROBACION where not_id = @idNot
COMMIT TRANSACTION
END TRY
BEGIN CATCH
	SELECT  0 not_id, 0 success, -1 result , 'message' = 'Ocurrio un error al realizar la operación.' , 0 as apr_id, 0 idUsuario
	ROLLBACK TRANSACTION

END CATCH
END
go

