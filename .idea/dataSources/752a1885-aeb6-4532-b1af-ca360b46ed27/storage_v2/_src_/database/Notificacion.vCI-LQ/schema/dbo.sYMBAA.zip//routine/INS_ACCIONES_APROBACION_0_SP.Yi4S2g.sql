-- =============================================
-- Author: Genaro Mora Valencia
-- Create date: 03/12/2015
-- Description:	Stored de control de las acciones de Aprobación
-- Regresa el número del último registro insertado.
-- =============================================

CREATE PROCEDURE [dbo].[INS_ACCIONES_APROBACION_0_SP] 
	@idAprobacion int
	,@respuesta   int
	,@observacion nvarchar(max)
	,@not_identificador int
	,@usuario1 int
	,@folio nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	
		BEGIN TRAN TRAN_ACCION_APROB_0

	BEGIN TRY
		DECLARE @oc VARCHAR(50) 
		SET @oc  = (SELECT N.not_identificador FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	WHERE A.apr_id = @idAprobacion)
		IF(@respuesta=1)
				BEGIN
					IF EXISTS(SELECT 1 FROM [cuentasxpagar].dbo.cxp_ordencompra WHERE oce_folioorden = @oc AND sod_idsituacionorden = 1)
						BEGIN
							PRINT 'Inserta respuesta de aprobación'
							--Entrando a cancelar la orden
								UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
								UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;
							
								----------------------------------------------------------------
								-------Inserta una respuesta de aprobación
								----------------------------------------------------------------
								INSERT INTO CentralizacionV2..BITACORA_PROCESOS (idProceso,descripcion,fecha)
								VALUES (6, 'INS_ACCIONES_APROBACION_0_SP:  @idAprobacion: ' + CONVERT(VARCHAR(10),@idAprobacion) + '- @resp: ' + CONVERT(VARCHAR(10),@respuesta) + '- @observacion: ' + @observacion + 
										   '- @not_identificador: ' + CONVERT(VARCHAR(10),@not_identificador) + '- @usuario1: ' + CONVERT(VARCHAR(10),@usuario1) + 
										   '- @folio: ' + @folio, GETDATE()) 							
							
								INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
									(not_id,[apr_id],[nar_fecha],[nar_comentario])
								VALUES
									(@not_identificador,@idAprobacion,GETDATE(),@observacion)									
											
								UPDATE [cuentasxpagar].dbo.cxp_ordencompra SET sod_idsituacionorden = 2 Where oce_folioorden = (SELECT N.not_identificador FROM 
																																NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	WHERE A.apr_id = @idAprobacion)
								--LQMA 11032017 ADD se actualiza el detalle de la orden
								UPDATE [cuentasxpagar]..cxp_detallerefacciones 
								SET ref_idsituaciondetalle = 2
								WHERE oce_folioorden = (SELECT N.not_identificador FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	WHERE A.apr_id = @idAprobacion)

								PRINT 'Inserta bitácora'
								EXECUTE INS_BITACORA_SP @usuario1, @folio, 2
						END
					ELSE 
						BEGIN
							INSERT INTO CentralizacionV2..BITACORA_PROCESOS (idProceso,descripcion,fecha)
								VALUES (6, 'INS_ACCIONES_APROBACION_0_SP:  @idAprobacion: ' + CONVERT(VARCHAR(10),@idAprobacion) + '- @resp: ' + CONVERT(VARCHAR(10),@respuesta) + '- @observacion: ' + @observacion + 
										   '- @not_identificador: ' + CONVERT(VARCHAR(10),@not_identificador) + '- @usuario1: ' + CONVERT(VARCHAR(10),@usuario1) + 
										   '- @folio: ' + @folio + 'OC con estatus diferente a 1', GETDATE()) 
							SELECT	-1 estatus, 'La orden de compra ' + @oc + ' ya se encuentra en estatus ' + [sod_nombresituacion] + '.' mensaje
							FROM	[cuentasxpagar].dbo.cxp_ordencompra AS O
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] AS S ON S.sod_idsituacionorden = O.sod_idsituacionorden
							WHERE	oce_folioorden = @oc
							UPDATE NOT_NOTIFICACION SET not_estatus = 5 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						END
				    
				END
		
		ELSE  
				BEGIN
					IF EXISTS(SELECT 1 FROM [cuentasxpagar].dbo.cxp_ordencompra WHERE oce_folioorden = @oc AND sod_idsituacionorden = 1)
						BEGIN
							--Entrando a cancelar la orden
							UPDATE NOT_NOTIFICACION SET not_estatus = 4 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
							UPDATE NOT_APROBACION SET apr_estatus = 4 WHERE apr_id = @idAprobacion;
						
						
							--LQMA 11032017 ADD se actualiza el detalle de la orden
							UPDATE [cuentasxpagar]..cxp_detallerefacciones 
							SET ref_idsituaciondetalle = 3
							WHERE oce_folioorden = (SELECT N.not_identificador FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	WHERE A.apr_id = @idAprobacion)
							
							----------------------------------------------------------------
							-------Inserta una respuesta de aprobación
							----------------------------------------------------------------
							INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
								(not_id,[apr_id],[nar_fecha],[nar_comentario])
							VALUES
								(@not_identificador,@idAprobacion,GETDATE(),@observacion)										
											
							UPDATE [cuentasxpagar].dbo.cxp_ordencompra SET sod_idsituacionorden = 3 Where oce_folioorden = (SELECT N.not_identificador FROM 
																															NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	WHERE A.apr_id = @idAprobacion)
						
							--ADD LQMA 04042017 actualiza estatus de expediente a rechazado
							UPDATE Centralizacionv2..DIG_EXPEDIENTE SET Estatus_Id = 3 WHERE Proc_Id = 1 AND Folio_Operacion = @folio

							EXECUTE INS_BITACORA_SP @usuario1, @folio, 3
						END
					ELSE 
						BEGIN
							INSERT INTO CentralizacionV2..BITACORA_PROCESOS (idProceso,descripcion,fecha)
								VALUES (6, 'INS_ACCIONES_APROBACION_0_SP:  @idAprobacion: ' + CONVERT(VARCHAR(10),@idAprobacion) + '- @resp: ' + CONVERT(VARCHAR(10),@respuesta) + '- @observacion: ' + @observacion + 
										   '- @not_identificador: ' + CONVERT(VARCHAR(10),@not_identificador) + '- @usuario1: ' + CONVERT(VARCHAR(10),@usuario1) + 
										   '- @folio: ' + @folio + 'OC con estatus diferente a 1', GETDATE()) 
							SELECT	-1 estatus, 'La orden de compra ' + @oc + ' ya se encuentra en estatus ' + [sod_nombresituacion] + '.' mensaje
							FROM	[cuentasxpagar].dbo.cxp_ordencompra AS O
									INNER JOIN [cuentasxpagar].[dbo].[cat_situacionorden] AS S ON S.sod_idsituacionorden = O.sod_idsituacionorden
							WHERE	oce_folioorden = @oc
							UPDATE NOT_NOTIFICACION SET not_estatus = 5 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						END
						
				END	
		
		COMMIT TRAN TRAN_ACCION_APROB_0	
					
	END TRY
    BEGIN CATCH

		ROLLBACK TRAN TRAN_ACCION_APROB_0

			--PRINT ('Error: ' + ERROR_MESSAGE())
			DECLARE @Mensaje NVARCHAR(MAX) = '',
			@Componente nvarchar(50) = 'INS_ACCIONES_APROBACION_0_SP - ' + @folio
			--SELECT ERROR_NUMBER() error
			SELECT @Mensaje = ERROR_MESSAGE()
			EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
					
	END CATCH

END


go

