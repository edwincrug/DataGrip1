-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 30/0/2015
-- Description:	Inserta la aprobación de mancomunado cuando una solicitud es autorizada.
-- Regrea 1 cuando realiza mancomunado y 2 cuando no hay nada
-- =============================================

--INS_MANCOMUNADO_SP 183

CREATE PROCEDURE [dbo].[INS_MANCOMUNADO_SP]
	@idAprobacion		int
AS
BEGIN
	SET NOCOUNT ON

	--	BEGIN TRANSACTION;
	--BEGIN TRY

		-- Identifica si existe un mancomunado 	
	IF Exists (SELECT   EP.usuario_mancomunado
				FROM     dbo.NOT_APROBACION A INNER JOIN
                         dbo.NOT_NOTIFICACION N ON A.not_id = N.not_id INNER JOIN
                         Centralizacionv2.dbo.DIG_ESCALAMIENTO_PARAMETROS EP ON N.not_tipo_proceso = EP.Proc_Id AND 
                         N.not_nodo = EP.Nodo_Id INNER JOIN
                         dbo.BPRO_Usuarios U ON A.emp_id = U.usu_idusuario --AND 
                         --EP.dep_iddepartamento = U.dep_iddepartamento
						 WHERE A.apr_id = @idAprobacion)
	BEGIN
	DECLARE @idNotificacion Int,
			@idMancomunado Int
			print('Si hay usuario mancomunado')
	SELECT @idNotificacion = not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion
	SELECT @idMancomunado =  EP.usuario_mancomunado
	FROM     dbo.NOT_APROBACION A INNER JOIN
             dbo.NOT_NOTIFICACION N ON A.not_id = N.not_id INNER JOIN
             Centralizacionv2.dbo.DIG_ESCALAMIENTO_PARAMETROS EP ON N.not_tipo_proceso = EP.Proc_Id AND 
             N.not_nodo = EP.Nodo_Id INNER JOIN
             dbo.BPRO_Usuarios U ON A.emp_id = U.usu_idusuario --AND 
             --EP.dep_iddepartamento = U.dep_iddepartamento
			 WHERE A.apr_id = @idAprobacion
			 print ('insertando su notificacion')
			 
			DECLARE @apr_nivel_anterior INT =0				 
			 SELECT   @apr_nivel_anterior=MAX(apr_nivel) FROM [dbo].[NOT_APROBACION] WHERE not_id=@idNotificacion
			 
			 
	INSERT INTO [dbo].[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
           ,[apr_escalado])
     VALUES
           (@idNotificacion
		   ,@apr_nivel_anterior
		   ,0
           ,@idMancomunado
           ,GETDATE()
           ,1
           ,2)
		   print('Se insertó el usuario mancomunado ' + convert(nvarchar, @idMancomunado));
		--INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]
		  --         ([not_id]
				--   ,[apr_id]
		  --         ,[nar_fecha]
           
		  --         ,[nar_comentario])
		  --   VALUES
		  --         (@idNotificacion
				--   ,@@IDENTITY
				--   ,GETDATE()
          
		  --         ,'')
		--   print ('insertado, sale con 1')
	print 1;
		   END
	ELSE
	BEGIN
	print ('no hay usuario mancomunado, sale con 2')
	print 2;
	END

--	print 0;
--		COMMIT TRAN
--END TRY
--BEGIN CATCH
--		DECLARE @Mensaje  nvarchar(max),
--		@Componente nvarchar(50) = 'INS_MANCOMUNADO_SP'
--		SELECT @Mensaje = ERROR_MESSAGE()
--		IF @@TRANCOUNT > 0
--		ROLLBACK TRANSACTION;
--		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
--END CATCH
--IF @@TRANCOUNT > 0
--COMMIT TRANSACTION;	
END


go

