-- =============================================
-- Author:		LQMA
-- Create date: 11042017
-- Description:	Cancela u omite orden de compra, se llama desde back de notificaciones
-- =============================================
/*
EXECUTE [dbo].[INS_CANCELACION_SP]
		@idAprobacion = 478266
		,@respuesta   = 1 --1: Cancelar, 0: Omitir
		,@observacion = ''
		,@not_identificador = 245488
		,@usuario = 82
*/
CREATE PROCEDURE [dbo].[INS_CANCELACION_SP]
	 @idAprobacion INT = 0
	,@respuesta   INT = 0 --1: Cancelar, 0: Omitir
	,@observacion NVARCHAR(MAX) = ''
	,@not_identificador INT = 0
	,@usuario INT = 0
	--,@folio NVARCHAR(100) = ''
AS
BEGIN	

		DECLARE @estatusResp INT = 0, @msg VARCHAR(100) = 'Se omitio la cancelación de esta orden con éxito.', @folio VARCHAR(50) = ''

		BEGIN TRANSACTION TRAN_CANCELACION

		BEGIN TRY		
				 
				SELECT @folio = N.not_identificador 
				FROM NOT_NOTIFICACION N 
				LEFT JOIN NOT_APROBACION A ON N.not_id = A.not_id
				WHERE A.apr_id = @idAprobacion

				--LQMA 17052017 inserta log registro en tabla
				INSERT INTO CentralizacionV2..BITACORA_PROCESOS
				VALUES (2,'Inicia Cancelación folio: ' + @folio,GETDATE())

				IF(@respuesta = 1) --CANCELAR LA ORDEN
				BEGIN
						UPDATE cuentasxpagar..cxp_ordencompra SET sod_idsituacionorden = 4 WHERE oce_folioorden = @folio
				
						INSERT INTO cuentasxpagar..cxp_movimientosorden ([mov_idusuariomovimiento], [mov_fechamovimiento], [mov_horamovimiento], [oce_folioorden], [sod_idsituacionorden])
						VALUES (@usuario,GETDATE(),CONVERT(TIME, GETDATE(),108), @folio, 4)
						-------------------------------------------------------------------------------------------------
						--Cambio para cuando se cancela la orden de compra se cierren los nodos hasta el nodo 14 
						-------------------------------------------------------------------------------------------------
						DECLARE @nodoE INT = 4

						UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
						SET		FechaFin = GETDATE(), Nodo_Estatus_Id = 3
						WHERE	Folio_Operacion IN (@folio) AND Nodo_Id = @nodoE

						UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
						SET		FechaInicio =  GETDATE(), FechaFin = GETDATE(), Nodo_Estatus_Id = 3
						WHERE	Folio_Operacion IN (@folio) AND Nodo_Id BETWEEN @nodoE + 1 AND 14 -1

						UPDATE	Centralizacionv2.dbo.DIG_EXP_NODO
						SET		FechaInicio =  GETDATE(), Nodo_Estatus_Id = 2
						WHERE	Folio_Operacion IN (@folio) AND Nodo_Id = 14
						-------------------------------------------------------------------------------------------------

						SELECT @msg = 'Se ha cancelado la orden ' + @folio + ' orden con éxito.'
				END

				----------------------------------------------------------------
				-------Inserta una respuesta de aprobación
				----------------------------------------------------------------
						
				INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
				VALUES
							(@not_identificador,@idAprobacion,GETDATE(),@observacion)			
		
				--actualizamos estatus de notificacion
				UPDATE NOT_NOTIFICACION 
				SET not_estatus = CASE WHEN @respuesta = 1 THEN 3 ELSE 4 END --1: se aprueba la cancelacion = 3; 0: se rechaza la cancelacion = 4  
				WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
				--actualizamos estatus de aprobacion
				UPDATE NOT_APROBACION 
				SET apr_estatus = CASE WHEN @respuesta = 1 THEN 3 ELSE 4 END --1: se aprueba la cancelacion = 3; 0: se rechaza la cancelacion = 4 
				WHERE apr_id = @idAprobacion;		
		
				--LQMA 17052017 inserta log registro en tabla
				INSERT INTO CentralizacionV2..BITACORA_PROCESOS
				VALUES (2,'Fin Cancelación folio: ' + @folio,GETDATE())
		
				COMMIT TRANSACTION TRAN_CANCELACION
				
				SELECT @estatusResp estatus,@msg mensaje

		END TRY
		BEGIN CATCH
				
				ROLLBACK TRANSACTION TRAN_CANCELACION

				DECLARE @Mensaje  nvarchar(max),
				@Componente nvarchar(50) = 'INS_CANCELACION_SP'
				SELECT @Mensaje = ERROR_MESSAGE() + '- @idAprobacion: ' + CONVERT(VARCHAR(10),@idAprobacion)
				
				INSERT INTO Error (componente, parametros, mensaje,fecha) 
				VALUES (@componente,'- @idAprobacion: ' + CONVERT(VARCHAR(10),@idAprobacion), @Mensaje,getdate())

				SELECT 1 estatus,@Mensaje mensaje
		END CATCH		

END
go

