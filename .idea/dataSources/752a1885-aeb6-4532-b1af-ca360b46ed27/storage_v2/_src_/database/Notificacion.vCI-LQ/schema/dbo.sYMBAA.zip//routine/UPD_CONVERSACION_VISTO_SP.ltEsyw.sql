-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 29/10/2015
-- Description:	Stored que actualiza a visto una conversacion de chat
-- =============================================
--UPD_CONVERSACION_VISTO_SP 1,183
CREATE PROCEDURE [dbo].[UPD_CONVERSACION_VISTO_SP]

	@emp_id numeric(18,0)
	,@apr_id numeric(18,0)
AS
BEGIN

	
	UPDATE NOT_CHAT 
		SET chat_visto = 1 
			,chat_emp_visto = @emp_id
	WHERE 
	chat_visto = 0
	AND chat_id IN(
		SELECT chat_id
		FROM NOT_CHAT cha
		INNER JOIN NOT_NOTIFICACION nno ON nno.not_id = cha.chat_idNotificacion 
		INNER JOIN NOT_APROBACION apo ON apo.not_id = nno.not_id
		WHERE apo.apr_id = @apr_id
	)
	AND [chat_idEmpleado] <> @emp_id 
	
	
END


go

