-- =============================================
-- Author:		Arturo Rodea Victoia
-- Create date: 18/11/2015
-- Description:	Procedimiento para guardar un movimiento en bitácora. (cxp_movimientosorden)
-- =============================================

CREATE PROCEDURE [dbo].[INS_BITACORA_SP]
	 @idusuario	int
	,@folio		nvarchar(50)
	,@estatus	int
AS
BEGIN
--	SET NOCOUNT ON;
--	BEGIN TRY
--BEGIN TRAN
INSERT INTO dbo.BitacoraBPRO
           ([mov_idusuariomovimiento]
           ,[mov_fechamovimiento]
           ,[mov_horamovimiento]
           ,[oce_folioorden]
           ,[sod_idsituacionorden])
     VALUES
           (@idusuario
           ,GETDATE()
           ,GETDATE()
           ,@folio
           ,@estatus)
--COMMIT TRAN
RETURN 0;
--END TRY
--BEGIN CATCH
--	PRINT ('Error: ' + ERROR_MESSAGE())
--	DECLARE @Mensaje  nvarchar(max),
--	@Componente nvarchar(50) = 'INS_BITACORA_SP'
--	SELECT @Mensaje = ERROR_MESSAGE()
--	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
--END CATCH
END


go

