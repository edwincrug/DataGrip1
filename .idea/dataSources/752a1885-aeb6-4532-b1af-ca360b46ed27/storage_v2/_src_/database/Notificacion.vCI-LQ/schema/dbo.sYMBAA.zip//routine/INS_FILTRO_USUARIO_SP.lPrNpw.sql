
CREATE PROCEDURE [dbo].[INS_FILTRO_USUARIO_SP] 
 @idUsuario INT 
,@idTipoFiltro INT
AS
BEGIN
	BEGIN TRY

		IF EXISTS (SELECT 1 FROM Notificacion.dbo.NOT_FILTRO_USUARIO WHERE idUsuario = @idUsuario)
		BEGIN
			UPDATE Notificacion.dbo.NOT_FILTRO_USUARIO 
			SET	   idTipoFiltro = @idTipoFiltro
			WHERE  idUsuario = @idUsuario
		END
		ELSE
		BEGIN
			INSERT INTO Notificacion.dbo.NOT_FILTRO_USUARIO
			SELECT @idUsuario, @idTipoFiltro
		END

		SELECT 1 result
	END TRY
	BEGIN CATCH
	    
		SELECT 0 result
	END CATCH
END
go

