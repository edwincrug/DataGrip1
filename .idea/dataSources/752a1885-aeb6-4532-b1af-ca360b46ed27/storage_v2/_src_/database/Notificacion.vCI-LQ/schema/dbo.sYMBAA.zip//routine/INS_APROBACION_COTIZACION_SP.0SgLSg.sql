CREATE PROCEDURE [dbo].[INS_APROBACION_COTIZACION_SP]
	@idtipoproceso int
	,@identificador varchar(50) 
	,@descripcion varchar(500)
	,@estatus int
	--,@linkBPRO varchar(MAX) = NULL
	--,@adjunto varchar(MAX) = NULL 
	--,@idtipoadjunto	varchar(500)
	--,@solicitante numeric(18,0) 
	,@aprobador	numeric(18,0)
	,@idDetalleCotizacion INT = 0 --LQMA 17042018, id del detalle de la cotizacion, agregado por Jose Manuel y Luis Bonnete
AS
BEGIN
	SET NOCOUNT ON;
	-- Inserta una notificación de tipo aprobación
		--LQMA 05070217
		BEGIN TRAN TRAN_APROBACION_COTIZACION

	BEGIN TRY

		INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	    VALUES (5,'INS_APROBACION_COTIZACION_SP @aprobador:' + CONVERT(VARCHAR(5),@aprobador) ,GETDATE())

		DECLARE @idsolicitante numeric(18,0)
		SELECT @idsolicitante=ucu_idusuarioalta FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE ucu_foliocotizacion =@identificador
		
		INSERT INTO NOT_NOTIFICACION (not_tipo
		, not_tipo_proceso
		, not_identificador
		, not_nodo
		, not_descripcion
		, not_estatus
		, not_fecha
		, not_link_BPRO
		, not_adjunto
		, not_adjunto_tipo
		, not_agrupacion)
		VALUES
		( 1
		, @idtipoproceso
		, @identificador
		,''
		, @descripcion
		, @estatus
		, GETDATE()
		, null--@linkBPRO
		, ''--@adjunto
		, @idDetalleCotizacion --@idtipoadjunto --LQMA 17042018, se guarda consecutivo del detalle de la cotización
		, 7
		)

DECLARE @nid_not int = @@IDENTITY;

--Solicitante
--LQMA  add 17062016   si aprobador = solicitante, solo se inserta aprobador
----------------------------------
IF(@aprobador != @idsolicitante) --si aprobador es diferente de solicitante, se inserta solicitante
	BEGIN
		INSERT INTO [dbo].[NOT_APROBACION]
			   ([not_id]
			   ,[apr_nivel]
			   ,[apr_visto]
			   ,[emp_id]
			   ,[apr_fecha]
			   ,[apr_estatus]
			   ,[apr_escalado])
		 VALUES
			   (@nid_not
			   ,0
			   ,NULL
			   ,@idsolicitante
			   ,GETDATE()
			   ,1
			   ,-1)
	END
		   
--Aprobador
----------------------------------
	INSERT INTO [dbo].[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
           ,[apr_escalado])
     VALUES
           (@nid_not
		   ,0
		   ,NULL
           ,@aprobador
           ,GETDATE()
           ,1
           ,0)
	

--Actualiza el estatus de la notificación a 2
----------------------------------
	UPDATE NOT_NOTIFICACION SET not_estatus = 2 
		WHERE not_id =@nid_not

	--LQMA 03072017
	UPDATE NOT_APROBACION SET apr_estatus = 2 WHERE not_id = @nid_not

	--LQMA 05070217
	COMMIT TRAN TRAN_APROBACION_COTIZACION	
	--EXECUTE [dbo].[INS_APROBACION_PRESUPUESTO_DETALLE_SP] @idtipoproceso,@identificador,@descripcion,@estatus,@linkBPRO,@adjunto,@idtipoadjunto,@solicitante,@aprobador
	Select 0 error
	
END TRY
BEGIN CATCH

	--LQMA 05070217
	ROLLBACK TRAN TRAN_APROBACION_COTIZACION

	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_APROBACION_COTIZACION_SP'
	SELECT ERROR_NUMBER() error
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	
END CATCH
END;
go

