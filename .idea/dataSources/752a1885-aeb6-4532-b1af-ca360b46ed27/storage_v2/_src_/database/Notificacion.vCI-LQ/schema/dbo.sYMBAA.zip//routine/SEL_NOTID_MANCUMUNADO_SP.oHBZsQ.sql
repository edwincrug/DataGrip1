-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	SEL_NOTID_MANCUMUNADO_SP 248067
CREATE PROCEDURE [dbo].[SEL_NOTID_MANCUMUNADO_SP]
	@not_id INT = 0
AS
BEGIN
	--declare @not_id INT = 445716


	DECLARE @not_identificador NVARCHAR(50),@not_agrupacion INT = 0, @idTipoNotificacion INT

	SELECT @not_identificador = not_identificador, @not_agrupacion = not_agrupacion FROM [Notificacion].[dbo].[NOT_NOTIFICACION] WHERE not_id = @not_id
	SELECT @idTipoNotificacion = idTipoNotificacion FROM CentralizacionV2.dbo.DIG_TIPO_NOTIFICACION WHERE Not_agrupador = @not_agrupacion

	--select @not_identificador,@idTipoNotificacion

	DECLARE @tokenID uniqueidentifier
	SET @tokenID = NEWID()

	DECLARE @tab TABLE(apr_id INT,not_id INT, emp_id INT, usu_correo NVARCHAR(50) ,not_descripcion NVARCHAR(MAX), link NVARCHAR(MAX))

	INSERT INTO @tab
	SELECT NA.apr_id,
		   NA.not_id,
		   NA.emp_id,
		   U.usu_correo,
		   N.not_descripcion,
		   --CASE WHEN not_agrupacion = '25' THEN N.not_link_BPRO ELSE '1' END AS link
		  -- CASE WHEN not_agrupacion IN ('25', '26', '27') THEN  'http://189.204.141.196:8085/Aplicaciones/index.html' ELSE '1' END AS link
		   CASE
			   WHEN not_agrupacion IN ('25') THEN 'http://189.204.141.196:4010/aprobar?employee=88&idTramite=' + @not_identificador
			   WHEN not_agrupacion IN ( '26', '27') THEN 'http://189.204.141.196:4010/aprobarDev?employee=70&idTramite=' + @not_identificador
		   ELSE '1' END AS link
	FROM [Notificacion].[dbo].[NOT_NOTIFICACION] N
	INNER JOIN [Notificacion].[dbo].[NOT_APROBACION] NA ON NA.not_id = N.not_id
	INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = NA.emp_id
	WHERE  N.not_agrupacion = @not_agrupacion 
	AND N.not_identificador = @not_identificador
	AND N.not_id > @not_id
	AND NA.emp_id in (SELECT usuario_mancomunado from Centralizacionv2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO where  idTipoNotificacion = @idTipoNotificacion)

	INSERT INTO [Notificacion].[dbo].[NOT_APROB_MANCOMUNADO]
	SELECT not_id, apr_id ,@tokenID FROM @tab


	SELECT apr_id, not_id, emp_id, usu_correo, not_descripcion,@tokenID AS token , link FROM  @tab


END


go

