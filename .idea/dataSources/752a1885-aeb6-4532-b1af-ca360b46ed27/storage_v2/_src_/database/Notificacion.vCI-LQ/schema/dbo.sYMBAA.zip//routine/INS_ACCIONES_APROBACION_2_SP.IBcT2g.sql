-- =============================================
-- Author: Genaro Mora Valencia
-- Create date: 03/12/2015
-- Description:	Stored de control de las acciones de Aprobación para FLOTILLA
-- Regresa el número del último registro insertado.
-- =============================================
CREATE PROCEDURE [dbo].[INS_ACCIONES_APROBACION_2_SP] 
	@idAprobacion int
	,@respuesta   int
	,@observacion nvarchar(max)
	,@not_identificador int
	,@usuario1 int
AS
BEGIN


	SET NOCOUNT ON;
	BEGIN
		DECLARE @idEmpresa INT =0, @idSucursal INT=0
			SELECT  @idEmpresa= NN.idEmpresa,
					@idSucursal= NN.idSucursal
					FROM [Notificacion].[dbo].[NOT_APROBACION] NA
					INNER JOIN [Notificacion].[dbo].[NOT_NOTIFICACION] NN ON NA.not_id=NN.not_id 
					WHERE [apr_id]=@idAprobacion
		IF(@respuesta=1)
		BEGIN
					--Entrando a cancelar la orden
						UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;
						----------------------------------------------------------------
						-------Inserta una respuesta de aprobación
						----------------------------------------------------------------
						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
						VALUES
							(@not_identificador,@idAprobacion,GETDATE(),@observacion)	
							
						----Aprueba Flotilla
						--UPDATE dbo.OrdenesdeCompra
						--set  sod_idsituacionorden = 2
						--where oce_numeroflotilla = (SELECT N.not_identificador 
						--FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
						--WHERE A.apr_id = @idAprobacion)	
						
						----------------------------------------------------------------------	
						--      Agregado por LMS 13/01/2016  para cerrar el nodo 7 y 8      --
						----------------------------------------------------------------------
						DECLARE @total INT = (SELECT count(1) FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_numeroflotilla = (SELECT CONVERT(INT,[dbo].[splitCadena_fn](N.not_identificador,'|',3)) --LQMA 06092016
												FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
												WHERE A.apr_id = @idAprobacion))
						DECLARE @aux   INT = 1
						DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), folio VARCHAR(50))
						
						INSERT INTO @VariableTabla  SELECT oce_folioorden
													         FROM [cuentasxpagar].[dbo].[cxp_ordencompra]
															WHERE oce_numeroflotilla = (SELECT CONVERT(INT,[dbo].[splitCadena_fn](N.not_identificador,'|',3)) 
																FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
																WHERE A.apr_id = @idAprobacion)
						
						WHILE(@aux <=  @total)
							BEGIN
								
								declare @folioactual as nvarchar(80)
								SELECT @folioactual = folio FROM @VariableTabla WHERE ID = @aux
								--Actualizo la orden
								UPDATE dbo.OrdenesdeCompra
									set  sod_idsituacionorden = 2
								WHERE oce_folioorden = @folioactual AND oce_idempresa=@idEmpresa AND oce_idsucursal=@idSucursal
								
								--INS_CIERRA_NODO_SP 2
								EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
													   @proc_Id = 1 --oce_idtipoorden --@idtipoproceso 
													  ,@nodo_Id = 2 
													  ,@folio_Operacion = @folioactual
								SET @aux = @aux + 1
							END
						----------------------------------------------------------------------
						----------------------------------------------------------------------		
															
		END
		ELSE  
		BEGIN
						--Entrando a cancelar la orden
						UPDATE NOT_NOTIFICACION SET not_estatus = 4 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						UPDATE NOT_APROBACION SET apr_estatus = 4 WHERE apr_id = @idAprobacion;
						----------------------------------------------------------------
						-------Inserta una respuesta de aprobación
						----------------------------------------------------------------
						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
						VALUES
							(@not_identificador,@idAprobacion,GETDATE(),@observacion)	
						--Rechaza Flotilla
						
						UPDATE dbo.OrdenesdeCompra
						set  sod_idsituacionorden = 3
						where oce_numeroflotilla = (SELECT CONVERT(INT,[dbo].[splitCadena_fn](N.not_identificador,'|',3)) 
						FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
						WHERE A.apr_id = @idAprobacion)	AND oce_idempresa=@idEmpresa AND oce_idsucursal=@idSucursal	

		END	
	END

END

go

