-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 23/09/2015
-- Description:	Stored que recupera una conversacion
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CONVERSACION_SP] 
	@idnotificacion numeric
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
SELECT    C.chat_idEmpleado AS idEmpleado
		, U.usu_nombre + ' ' + U.usu_paterno + ' ' + U.usu_materno AS nombre
		, ISNULL(C.chat_texto, N'') AS texto
		, ISNULL(C.chat_idNotificacion, N'') AS idNotificacion
		, ISNULL(C.chat_fecha, N'') AS fecha
		, C.chat_visto
		, C.chat_emp_visto
FROM    dbo.NOT_CHAT AS C INNER JOIN dbo.BPRO_Usuarios AS U ON C.chat_idEmpleado = U.usu_idusuario
WHERE   chat_idNotificacion = @idnotificacion
  ORDER BY chat_fecha 
  END TRY
  BEGIN CATCH
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_CONVERSACION_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
	RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
END CATCH
END



go

