CREATE PROCEDURE [dbo].[SEL_NOTIFICACION_ESTATUS_SP] --'XX-XX-XXX-XX-XX-XXX1', 1
 @identificador NVARChAR(50)
,@idTipoNotificacion INT 
AS
BEGIN 
--------------------------------------------------------------------------------------------------------
--DECLARE  @identificador NVARChAR(50) = 'AU-AU-UNI-UN-4557'--'XX-XX-XXX-XX-XX-XXX1'
--		,@idTipoNotificacion INT = 3


--------------------------------------------------------------------------------------------------------
DECLARE @estatusNotificacion TABLE (id INT, estatus NVARCHAR(50))
INSERT INTO @estatusNotificacion
VALUES    (1,'Pendiente')
        ,(2,'En Aprobación')
        ,(3,'Aprobado')
        ,(4,'Rechazado')
        ,(5,'Cancelado')
        ,(6,'En Revisión')

DECLARE @estatusAprobacion TABLE (id INT, estatus NVARCHAR(50))
INSERT INTO @estatusAprobacion
VALUES    (1,'Pendiente')
        ,(2,'Visto')
        ,(3,'Aprobado')
        ,(4,'Rechazado')
        ,(5,'Retrasado')
        ,(6,'Revisión')
-------------------------------------------------------------------------



----Detalle de la Notificación
--SELECT 'NOTIFICACION'
SELECT   distinct N.not_id
		 ,N.not_identificador
		 ,N.not_descripcion
		 --,N.not_estatus
		 ,N.not_fecha
		 ,N.not_agrupacion
		 ,N.idEmpresa
		 ,N.idSucursal
        ,E.estatus
FROM    Notificacion.dbo.NOT_NOTIFICACION AS N
        INNER JOIN @estatusNotificacion AS E ON N.not_estatus =  E.id
		INNER JOIN CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT AS DEF ON DEF.not_agrupador = N.not_agrupacion
WHERE    not_identificador = @identificador
AND		DEF.idTipoNotificacion = @idTipoNotificacion
-------------------------------------------------------------------------
--Detalle de Aprobación
--SELECT 'APROBACIÓN'
SELECT   distinct 
		 
		 A.emp_id
		 ,E.estatus
        --,(CASE    WHEN apr_escalado = -1 THEN 'Solicita'
        --        WHEN apr_escalado = 0 THEN 'Aprobador sin escalar'
        --  END) AS tipoPersona
        ,U.usu_nombreusu + ' ' + U.usu_paterno + ' ' + U.usu_materno Aprobador
		, NAR.nar_fecha
		, NAR.nar_comentario

FROM    Notificacion.dbo.NOT_APROBACION AS A
        INNER JOIN @estatusAprobacion AS E ON A.apr_estatus = E.id
		INNER JOIN Notificacion.dbo.NOT_NOTIFICACION AS N ON N.not_id = A.not_id
		LEFT JOIN Notificacion.dbo.NOT_APROBACION_RESPUESTA NAR ON NAR.not_id = A.not_id
        INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] AS U ON U.[usu_idusuario] = A.emp_id
		INNER JOIN CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT AS DEF ON DEF.not_agrupador = N.not_agrupacion
WHERE   not_identificador = @identificador
AND		DEF.idTipoNotificacion = @idTipoNotificacion
AND     A.apr_escalado = 0

END



go

