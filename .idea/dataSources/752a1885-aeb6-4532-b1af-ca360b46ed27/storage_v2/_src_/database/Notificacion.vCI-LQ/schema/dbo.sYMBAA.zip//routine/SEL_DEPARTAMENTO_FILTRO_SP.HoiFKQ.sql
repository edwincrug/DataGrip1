-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 16/10/2015
-- Description: Stored que recupera los departamentos
-- =============================================
-- [SEL_DEPARTAMENTO_FILTRO_SP] 29,1
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTO_FILTRO_SP] 
	@idUsuario INT = 0
	,@idSucursal INT = 0
AS
BEGIN	
	
	SELECT  -1 dep_iddepartamento
			, '---Todos---' dep_nombre
			, '' dep_nombrecto
	UNION
	SELECT    DISTINCT D.dep_iddepartamento
			, D.dep_nombre
			, D.dep_nombrecto
	FROM  ControlAplicaciones.dbo.cat_departamentos D 
	INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] org ON D.dep_iddepartamento = org.dep_iddepartamento
	WHERE org.usu_idusuario = @idUsuario
	AND org.suc_idsucursal = @idSucursal

	--SELECT * FROM [ControlAplicaciones].[dbo].[ope_organigrama] WHERE usu_idusuario = 29

END


go

