-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
/*
Tabla de CC
0 Solicitado
1 Autorizado o Activo
2 Procesado
3 Cancelado


select * from NOT_NOTIFICACION where not_identificador ='10974' --not_agrupacion = 19
SELECT * FROM NOT_APROBACION WHERE	not_id = 182333
SELECT * FROM [cuentasporcobrar].[dbo].[uni_ccs] where ucc_idcc = 10974
select top 100* from dbo.OrdenesdeCompra where oce_folioorden = 'AU-ZM-NAB-UN-3972'
select * FROM [cuentasxpagar].[dbo].[cxp_ordencompra] where oce_folioorden = 'AU-ZM-NAB-UN-3972'

*/
CREATE PROCEDURE [dbo].[UPD_APROBACION_UP_CC_SP]
	 @idAprobacion INT = 0
	,@respuesta   INT = 0
	,@observacion VARCHAR(max) = ''
AS
	

	DECLARE @idEstatus INT = 0, @mensaje VARCHAR(500) = ''
	DECLARE @idnotificacion int
	DECLARE @proceso int
	DECLARE @folio int
	DECLARE @not_identificador VARCHAR(100) = ''


		
	SELECT @idnotificacion = not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion
			     
	SELECT @folio = not_identificador FROM dbo.NOT_NOTIFICACION  WHERE not_id = @idnotificacion

	BEGIN TRAN TRAN_UPD_APROBACION_UP_CC
	BEGIN TRY
				
					INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
					VALUES (19,'UPD_APROBACION_UP_CC_SP @folio: ' + CONVERT(VARCHAR(30),@folio) ,GETDATE())		

					-- Valida si ya fue aprobada la orden
 					IF EXISTS(SELECT not_id FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion AND not_tipo IN (1,2,3,4) AND not_nodo = 1 AND not_estatus in(3,4,5))
					BEGIN
						-- Si ya fue aprobada no hace la actualizacion y la pone como retrasada adicionalmente sale con 5
						PRINT 'Ya existe'
						UPDATE NOT_APROBACION SET apr_estatus = 5 WHERE apr_id = @idAprobacion
						SET @idEstatus = -1
						SET @mensaje = 'La solicitud fue aprobada previamente por otro autorizador.' 
					END
					ELSE	
					BEGIN
														     																						
								IF(@respuesta = 1)
								BEGIN
							
											--  Consultamos el estatus del cc
											DECLARE @status_cc INT

											SELECT @status_cc = ucc_estatus
											FROM [cuentasporcobrar].[dbo].[uni_ccs] WHERE ucc_idcc =  @folio
								
											-- si el estatus del cc es diferente de Procesado se aprueba la cancelacion
											IF(@status_cc <> 2)
											BEGIN 
												SELECT @idEstatus = 0, @mensaje = 'La solicitud ha sido procesada.'

												-- Aprobada la cancelacion
												UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
												UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;
												UPDATE [cuentasporcobrar].[dbo].[uni_ccs] SET  ucc_estatus = 3 WHERE ucc_idcc = @folio

																							
												INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA] (not_id , [apr_id] , [nar_fecha] , [nar_comentario])
												VALUES ( @idnotificacion , @idAprobacion , GETDATE(), 'Aprobacion de Cancelacion ' + @observacion)	
									
											END
											ELSE
											BEGIN
												-- De lo contrario si ya esta procesada no se cancela 
												SET @idEstatus = -1
												SET @mensaje = 'El CC ya se aplicó como Anticipo, por lo que se debe cancelar desde BPro.'
											END	
													
																					
						
										END
								ELSE  
										BEGIN
												--Entrando a cancelar la orden
										
												UPDATE NOT_NOTIFICACION SET not_estatus = 4 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
												UPDATE NOT_APROBACION SET apr_estatus = 4 WHERE apr_id = @idAprobacion;
							
												----------------------------------------------------------------
												-------Inserta una respuesta de aprobación
												----------------------------------------------------------------
											
												INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
													(not_id,[apr_id],[nar_fecha],[nar_comentario])
												VALUES
													(@idnotificacion,@idAprobacion,GETDATE(),'Rechazo de Cancelación CC '+ @observacion)	
															
												SET @idEstatus = -1
												SET @mensaje = 'Rechazo Realizado'
								END
									
					
     				SELECT @idEstatus estatus, @mensaje mensaje 

	COMMIT TRAN TRAN_UPD_APROBACION_UP_CC
END
END TRY
BEGIN CATCH

	ROLLBACK TRAN TRAN_UPD_APROBACION_UP_CC
	
	DECLARE @Componente VARCHAR(50) = 'UPD_APROBACION_UP_CC_SP', @errorMensaje VARCHAR(MAX) = ERROR_MESSAGE() + ' - Folio: ' + CONVERT(VARCHAR(30),@folio) 
	DECLARE @tablaRespuesta TABLE(idError INT)
	INSERT INTO @tablaRespuesta
	EXECUTE INS_ERROR_SP @Componente, @errorMensaje
					
	SELECT ERROR_NUMBER() estatus, 'No se pudo ejecutar el proceso. Intente de nuevo.' mensaje

END CATCH;


go

