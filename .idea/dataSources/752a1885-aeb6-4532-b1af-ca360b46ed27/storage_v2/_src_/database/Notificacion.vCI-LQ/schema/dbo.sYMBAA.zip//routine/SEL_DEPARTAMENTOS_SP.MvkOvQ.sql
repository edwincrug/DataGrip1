-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 16/10/2015
-- Description: Stored que recupera los departamentos
-- =============================================
-- [SEL_DEPARTAMENTOS_SP] 7, 7, 1
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOS_SP] 
	@idempleado int = 0
	,@idempresa  int = 0
	,@idsucursal int = 0
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
SELECT    DISTINCT D.dep_iddepartamento
		, D.dep_nombre
		, D.dep_nombrecto
FROM            ControlAplicaciones.dbo.cat_departamentos AS D LEFT OUTER JOIN
                         ControlAplicaciones.dbo.cat_sucursales AS S ON D.suc_idsucursal = S.suc_idsucursal LEFT OUTER JOIN
                         ControlAplicaciones.dbo.cat_usuarios AS U ON D.dep_iddepartamento = U.dep_iddepartamento
WHERE	(S.emp_idempresa = @idempresa OR @idempresa = 0)
		AND (D.suc_idsucursal = @idsucursal OR @idsucursal = 0)
		AND LEN(D.dep_nombre)>0

		END TRY
		BEGIN CATCH
		DECLARE @Mensaje nvarchar(max),
		@Componente nvarchar(50)='SEL_DEPARTAMENTOS_SP'
		SELECT @Mensaje=ERROR_MESSAGE()
		RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje

		END CATCH 

END


go

