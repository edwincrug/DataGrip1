--/****** Object:  StoredProcedure [dbo].[UPD_APROBACION_SP_UP]    Script Date: 29/05/2020 11:04:36 a. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
-- [dbo].[UPD_APROBACION_SP_UP] 758422,1,'',454


CREATE PROCEDURE [dbo].[UPD_APROBACION_SP_UP] 
	@idAprobacion INT = 0
	,@respuesta   INT = 0
	,@observacion VARCHAR(max) = ''
	,@idUsuario INT = 0
AS
	--	DECLARE
	--	@idAprobacion INT = 758418
	--,@respuesta   INT = 1
	--,@observacion VARCHAR(max) = ''
	--,@idUsuario INT = 71

		--LQMA ADD 28062017 inventarios

		DECLARE @idEstatus INT = 0, @mensaje VARCHAR(500) = ''
		IF @respuesta = 1
			SET @mensaje = 'Autorización Realizada'
		ELSE
			SET @mensaje = 'Rechazo Realizado'

		DECLARE @idnotificacion int
		DECLARE @proceso int
		DECLARE @nodo int
		DECLARE @folio varchar(100) = ''
		--DECLARE @respuestaest int;
		DECLARE @usuariomancomunado int =0, @usuario int =0
		DECLARE @not_identificador VARCHAR(100) = ''
		DECLARE @not_agrupacion int

		-- Obtener el idNotificacion
		SELECT @idnotificacion = not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion
		-- Obtener el idNotifiacion
			     
		SELECT @not_agrupacion = not_agrupacion 
		,@proceso = not_tipo_proceso
		,@nodo = not_nodo + 1
		,@folio = not_identificador
		from dbo.NOT_NOTIFICACION 
		where not_id = @idnotificacion

		print @not_agrupacion 
		print @folio

		DECLARE @base VARCHAR(50) = '',@server VARCHAR(50) = '', @query VARCHAR(500) = '' 
		DECLARE @ipLocal VARCHAR(50) = ''

		DECLARE @idEmpresa INT =0, @idSucursal INT=0

		

		--LQMA 23102017 add
		DECLARE @tablaRespuestaSPACs TABLE(id INT IDENTITY(1,1),estatus INT, mensaje VARCHAR(MAX))
		DECLARE @aux   INT = 1

		INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
	    VALUES (9,'UPD_APROBACION_SP_UP @folio: ' + @folio ,GETDATE())

			BEGIN TRAN TRAN_UPD_APROBACION_UP

		BEGIN TRY

					--Valida si ya fue aprobada la orden
					--LQMA 17032017, se agregaron los tipos 2 y 4 para que se valide en todos los casos		 
 					IF EXISTS(SELECT not_id FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion AND not_tipo IN (1,2,3,4) AND not_nodo = 1 AND not_estatus in(3,4,5))
					BEGIN
						-- Si ya fue aprobada no hace la actualizacion y la pone como retrasada adicionalmente sale con 5
						PRINT 'Ya existe'
						UPDATE NOT_APROBACION SET apr_estatus = 5 WHERE apr_id = @idAprobacion
						
														

						SELECT -1 estatus, 'La solicitud fue aprobada previamente por otro autorizador.' mensaje 
					END
					ELSE	
					BEGIN
						IF(@not_agrupacion = 0)
						BEGIN	
							PRINT 'Agrupación 0'
							IF @respuesta = 1
							BEGIN		
								SELECT   @usuariomancomunado = dep.usuario_mancomunado
										, @usuario = apr.emp_id
										, @not_identificador = ntf.not_identificador					
									FROM dbo.NOT_APROBACION apr 
										LEFT JOIN dbo.NOT_NOTIFICACION ntf ON ntf.not_id = apr.not_id
										LEFT JOIN [dbo].[OrdenesdeCompra] orc ON orc.oce_folioorden = ntf.not_identificador
										LEFT JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_PARAMETROS dep ON dep.Proc_Id = ntf.not_tipo_proceso
										AND dep.Nodo_Id = ntf.not_nodo 
										AND dep.emp_idempresa = orc.[oce_idempresa]
										AND dep.suc_idsucursal = orc.[oce_idsucursal]
										AND dep.dep_iddepartamento = orc.[oce_iddepartamento]
										AND dep.tipo_idtipoorden = orc.[oce_idtipoorden]
						    
								WHERE apr.apr_id =  @idAprobacion		
					
								IF ((@usuariomancomunado IS NULL) OR (@usuariomancomunado = @usuario) )						
								BEGIN	
									PRINT 'Entra acciones aprobación 0'
									EXECUTE [INS_ACCIONES_APROBACION_0_SP] 
											@idAprobacion 
											,@respuesta   
											,@observacion 
											,@idnotificacion 
											,@usuario
											,@folio
								END
								ELSE
								BEGIN
									EXEC INS_MANCOMUNADO_SP @idAprobacion
									INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
										(not_id,[apr_id],[nar_fecha],[nar_comentario])
									VALUES
										(@idnotificacion,@idAprobacion,GETDATE(),@observacion)
									UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion
									print 'freshness'
								END
							END
							ELSE
							BEGIN
								EXECUTE [INS_ACCIONES_APROBACION_0_SP] 
											@idAprobacion 
											,@respuesta   
											,@observacion 
											,@idnotificacion 
											,@usuario
											,@folio
											print 'freshness'
							END
						END	     										     																						
						IF(@not_agrupacion = 1)
						BEGIN	
							PRINT 'Lotes'
							--Acciones de aprobación para lotes
							EXECUTE [INS_ACCIONES_APROBACION_1_SP] 
											@idAprobacion 
											,@respuesta   
											,@observacion 
											,@idnotificacion 
											,@usuario
						END	     										     																						
						IF(@not_agrupacion = 2)
						BEGIN	
							PRINT 'Flotillas'
							--ACCIONES DE APROBACIÓN para flotillas
							/*EXECUTE [INS_ACCIONES_APROBACION_2_SP] 
											@idAprobacion 
											,@respuesta   
											,@observacion 
											,@idnotificacion 
											,@usuario*/	
														
							SELECT  @idEmpresa= NN.idEmpresa,
									@idSucursal= NN.idSucursal,
									@not_identificador = NN.not_id
									FROM [Notificacion].[dbo].[NOT_APROBACION] NA
									INNER JOIN [Notificacion].[dbo].[NOT_NOTIFICACION] NN ON NA.not_id=NN.not_id 
									WHERE [apr_id]=@idAprobacion
							
							DECLARE @total INT = (SELECT count(oce_numeroflotilla) FROM [cuentasxpagar].[dbo].[cxp_ordencompra] WHERE oce_numeroflotilla = (SELECT CONVERT(INT,[dbo].[splitCadena_fn](N.not_identificador,'|',3)) --LQMA 06092016
																	FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
																	WHERE A.apr_id = @idAprobacion))
							
							DECLARE @VariableTabla TABLE (ID INT IDENTITY(1,1), folio VARCHAR(50))
						
							INSERT INTO @VariableTabla  SELECT oce_folioorden
																	FROM [cuentasxpagar].[dbo].[cxp_ordencompra]
																WHERE oce_numeroflotilla = (SELECT CONVERT(INT,[dbo].[splitCadena_fn](N.not_identificador,'|',3)) 
																	FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
																	WHERE A.apr_id = @idAprobacion) AND oce_idempresa=@idEmpresa AND oce_idsucursal=@idSucursal
							
							IF(@respuesta=1)
								BEGIN
										--Entrando a cancelar la orden
											UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
											UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion;

											 
											----------------------------------------------------------------
											-------Inserta una respuesta de aprobación
											----------------------------------------------------------------
											INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
												(not_id,[apr_id],[nar_fecha],[nar_comentario])
											VALUES
												(@not_identificador,@idAprobacion,GETDATE(),@observacion)	
											
											----Aprueba Flotilla
											--UPDATE dbo.OrdenesdeCompra
											--set  sod_idsituacionorden = 2
											--where oce_numeroflotilla = (SELECT N.not_identificador 
											--FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
											--WHERE A.apr_id = @idAprobacion)	
						
											----------------------------------------------------------------------	
											--      Agregado por LMS 13/01/2016  para cerrar el nodo 7 y 8      --
											----------------------------------------------------------------------											
						
											WHILE(@aux <=  @total)
												BEGIN
								
													declare @folioactual as varchar(80) = ''
													SELECT @folioactual = folio FROM @VariableTabla WHERE ID = @aux
													--Actualizo la orden
													UPDATE dbo.OrdenesdeCompra
														SET sod_idsituacionorden = 2
													WHERE oce_folioorden = @folioactual AND oce_idempresa=@idEmpresa AND oce_idsucursal=@idSucursal
								
													--INS_CIERRA_NODO_SP 2
													EXECUTE Centralizacionv2.[dbo].[INS_CIERRA_NODO_SP] 
																		   @proc_Id = 1 --oce_idtipoorden --@idtipoproceso 
																		  ,@nodo_Id = 2 
																		  ,@folio_Operacion = @folioactual
													SET @aux = @aux + 1
												END
											----------------------------------------------------------------------
											----------------------------------------------------------------------		
															
								END
							ELSE  
								BEGIN
											--Entrando a cancelar la orden
											UPDATE NOT_NOTIFICACION SET not_estatus = 4 WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
											UPDATE NOT_APROBACION SET apr_estatus = 4 WHERE apr_id = @idAprobacion;
											----------------------------------------------------------------
											-------Inserta una respuesta de aprobación
											----------------------------------------------------------------
											INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
												(not_id,[apr_id],[nar_fecha],[nar_comentario])
											VALUES
												(@not_identificador,@idAprobacion,GETDATE(),@observacion)	
											--Rechaza Flotilla
						
											WHILE(@aux <=  @total)
												BEGIN
								
													declare @folioactualR as varchar(80) = ''
													SELECT @folioactualR = folio FROM @VariableTabla WHERE ID = @aux
													--Actualizo la orden
													UPDATE dbo.OrdenesdeCompra
														set  sod_idsituacionorden = 3
													WHERE oce_folioorden = @folioactualR AND oce_idempresa=@idEmpresa AND oce_idsucursal=@idSucursal
													
													SET @aux = @aux + 1
												END
											
											/*
											UPDATE dbo.OrdenesdeCompra
											set  sod_idsituacionorden = 3
											where oce_numeroflotilla = (SELECT CONVERT(INT,[dbo].[splitCadena_fn](N.not_identificador,'|',3)) 
											FROM NOT_NOTIFICACION N INNER JOIN NOT_APROBACION A ON N.not_id = A.not_id	
											WHERE A.apr_id = @idAprobacion)	AND oce_idempresa=@idEmpresa AND oce_idsucursal=@idSucursal	
											*/
								END	

						END  --@not_agrupacion = 2

						--/////////////add Laura 
						--***Lo de adentro de este(entre --%%) if se encontraba sin condición, se coloca la condición por que 
						--***para el @not_agrupacion = 5 no contiene nodo
						--***y se tiene que realizar un upd en la tabla [ser_presupweb]
						--***para el @not_agrupacion = 6 no contiene nodo
						--***y se tiene que realizar un upd en la tabla [ser_presupwebdet]
						--DECLARE @idEmpresa INT =0, @idSucursal INT=0
						SELECT  @idEmpresa= NN.idEmpresa,
								@idSucursal= NN.idSucursal
						FROM [Notificacion].[dbo].[NOT_APROBACION] NA
						INNER JOIN [Notificacion].[dbo].[NOT_NOTIFICACION] NN ON NA.not_id=NN.not_id 
						WHERE [apr_id]=@idAprobacion
			
						--LQMA ADD 29062017 reajuste de variables, se declaran y en casos argupado 5 y 6 se setean 
						DECLARE @identificador VARCHAR(20)= '', @orden INT = 0  						
						--LQMA ADD 29062017 reajuste de variables, se declaran y en casos argupado 5 y 6 se setean 
						IF(@not_agrupacion IN (5,6))
							BEGIN						
								SELECT @identificador =	(SELECT [referencias].[dbo].[fn_BuscaNumeros](@folio));
								print 'identificador'
								print @identificador
								SELECT @orden =(SELECT prw_idpresuorden FROM [cuentasporcobrar].[dbo].[ser_presupweb] WHERE prw_nopresupuesto=@identificador and prw_idempresa=@idEmpresa and prw_idsucursal=@idSucursal)
								print 'orden'
								print @orden
							END					
						
						IF (@not_agrupacion = 5) --5 = encabezado de presupuesto normal/adicional LQMA			
							BEGIN 					
								print @identificador
					
								--@folio
								IF(@respuesta=1)
									BEGIN
										--SELECT * FROM [cuentasporcobrar].[dbo].[ser_presupweb] WHERE prw_idpresuorden=@idnotificacion	
										UPDATE [cuentasporcobrar].[dbo].[ser_presupweb]
										SET cec_idestatuspresuint=5
										WHERE prw_idpresuorden=@orden
									END
								ELSE
									BEGIN
										UPDATE [cuentasporcobrar].[dbo].[ser_presupweb]
										SET cec_idestatuspresuint=4
										WHERE prw_idpresuorden=@orden
									END	
									print		@idAprobacion 
									print		@respuesta   
									print		@observacion 
									print		@idnotificacion 
									print		@usuario
									print		@folio
									--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
									--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
									--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
									EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
											@idAprobacion 
											,@respuesta   
											,@observacion 
											,@idnotificacion 
											,@usuario
											,@folio
									--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{						
							END
						IF (@not_agrupacion = 6) --6 = detalle de presupuesto normal/adicional LQMA				
							BEGIN
							print'Entre al 6'	
								print @not_agrupacion				
								print @identificador                                          --ADD LQMA @folioOrden, @clasificacion 08032017
								DECLARE @max int, @condicion int, @idDetalle INT, @folioOrden VARCHAR(50) = '', @clasificacion VARCHAR(10) = '' --, @idUsuario INT = 0 LQMA 29062017 comentado, se declara arriba  
								DECLARE @tabInfoDetalle TABLE (ID INT IDENTITY(1,1), idDetalle INT, idDetEncabezado INT)--, folioOrden VARCHAR(50) NULL,clasificacion VARCHAR(10) NULL) --ADD LQMA @folioOrden, @clasificacion 08032017
								--@folio
								IF(@respuesta=1)
									BEGIN
										--#############################################################################################
										--Recorre el detalle del presupuesto para cheacar donde cec_idestatuspresuint=2 y modificar por 5.-Autorizado, 6.-Rechazado
										print 'Entre a la respuesta 1'
										INSERT INTO @tabInfoDetalle
											SELECT pwd_idordendet, prw_idpresuorden--, pwd_foliocompra, pwd_clasificacion
													FROM [cuentasporcobrar].[dbo].[ser_presupwebdet] WHERE prw_idpresuorden=@orden 
										SELECT @max =  MAX(ID) FROM @tabInfoDetalle
										print @max
										WHILE (@aux<=@max)
											BEGIN				
												SELECT	@condicion=cec_idestatuspresuint,
														@idDetalle=pwd_idordendet 
														FROM [cuentasporcobrar].[dbo].[ser_presupwebdet] 
														WHERE pwd_idordendet=(SELECT idDetalle FROM @tabInfoDetalle WHERE ID=@aux)
												--
												IF(@condicion=2 OR @condicion=3)
													BEGIN
														PRINT 'ENTRE a la condicion 2'
														UPDATE [cuentasporcobrar].[dbo].[ser_presupwebdet]
														SET cec_idestatuspresuint=5
														WHERE pwd_idordendet=@idDetalle
													END	
												SET @aux += 1			
											END
										--#############################################################################################						
							
									END
								ELSE
									BEGIN
										--#############################################################################################
										--Recorre el detalle del presupuesto para cheacar donde cec_idestatuspresuint=2 y modificar por 5.-Autorizado, 7.-Rechazado
										print'Entre a la 2'
										print @orden
										print 'Orden'
										INSERT INTO @tabInfoDetalle
											SELECT pwd_idordendet, prw_idpresuorden--, pwd_foliocompra, pwd_clasificacion
													FROM [cuentasporcobrar].[dbo].[ser_presupwebdet] WHERE prw_idpresuorden=@orden
										SELECT @max =  MAX(ID) FROM @tabInfoDetalle
										print @max
										WHILE (@aux<=@max)
											BEGIN				
												SELECT	@condicion=cec_idestatuspresuint,
														@idDetalle=pwd_idordendet,
														@folioOrden = pwd_foliocompra, -- ADD LQMA 08032017
														@clasificacion = pwd_clasificacion, -- ADD LQMA 08032017
														@idUsuario = pwd_idusuario
														FROM [cuentasporcobrar].[dbo].[ser_presupwebdet] 
														WHERE pwd_idordendet=(SELECT idDetalle FROM @tabInfoDetalle WHERE ID=@aux)
												--
												IF(@condicion=2 OR @condicion=3)
													BEGIN
														PRINT 'ENTRE '
														UPDATE [cuentasporcobrar].[dbo].[ser_presupwebdet]
														SET cec_idestatuspresuint=4
														WHERE pwd_idordendet=@idDetalle
														--LQMA 08032017	se agrego para cancelar la orden de compray agregarlo en la bitacora
														--IF(UPPER(@clasificacion) = 'TT' AND @folioOrden != '')
														--	BEGIN										
														--				UPDATE [cuentasxpagar].[dbo].[cxp_ordencompra]
														--				SET [sod_idsituacionorden] = 4
														--				WHERE oce_folioorden = @folioOrden
													
														--				INSERT INTO [cuentasxpagar].[dbo].[cxp_movimientosorden]
														--				VALUES (@idUsuario,CONVERT(date, getdate()),CONVERT(time, getdate()),@folioOrden,4)
														--	END
													END								

									
												SET @aux += 1									
									
											END
										--#############################################################################################
							
									END	
									--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
									--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
									--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
									EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
											@idAprobacion 
											,@respuesta   
											,@observacion 
											,@idnotificacion 
											,@usuario
											,@folio
									--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{				
							END
						--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
			--????????????????????????????????????????????????????????????????????
			--Para realizar el cambio de estatus de cec_idestatuscotiza 17.-Autorizada 14.-Cancelada 
						IF (@not_agrupacion = 7)
							BEGIN 
								/*
								INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
								VALUES (7,'Ejecutara APR_INS_AGRUP7_SP inicia @folio: ' + @folio ,GETDATE())

								INSERT INTO @tablaRespuestaSPACs
								EXEC [dbo].[APR_INS_AGRUP7_SP] 
											@idAprobacion -- = 0
											,@folio-- = ''
											,@respuesta-- = 0 
											,@idnotificacion-- = 0
											,@observacion-- = ''
											,@idUsuario-- = 0
								
								SELECT TOP(1) @idEstatus = estatus, @mensaje = mensaje FROM @tablaRespuestaSPACs
								--SELECT @idEstatus = 0, @mensaje = 'Proceso realizado.' --FROM @tablaRespuestaSPACs
								*/
								
								INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
								VALUES (7,'APR_INS_AGRUP7_SP inicia @folio: ' + @folio ,GETDATE())

								DECLARE @cec_idestatuscotiza INT = 0, @estatusNotificacion INT = 0, @resp VARCHAR(30) = ''

								
								DECLARE @idDetalleCotizacion INT = 0

								SELECT @idDetalleCotizacion = not_adjunto_tipo FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion

								IF(@respuesta = 0) -- RECHAZADO
								BEGIN

									UPDATE CC SET CC.ucc_estatus = 3
									FROM [cuentasporcobrar].[dbo].UNI_CCS CC 
									INNER JOIN [cuentasporcobrar].[dbo].uni_cotizacionuniversal ctz
									ON cc.ucu_idcotizacion=ctz.ucu_idcotizacion
									WHERE ctz.ucu_foliocotizacion = @folio
									AND ucc_idcc = @idDetalleCotizacion
									
								END
								ELSE
								BEGIN
									DECLARE  @montoCC DECIMAL(18,5)

									SELECT   @idEmpresa = ucu_idempresa 
											,@idSucursal = ucu_idsucursal  
											,@montoCC = ucc_monto
									FROM [cuentasporcobrar].[dbo].UNI_CCS CC 
									INNER JOIN [cuentasporcobrar].[dbo].uni_cotizacionuniversal ctz
									ON cc.ucu_idcotizacion=ctz.ucu_idcotizacion
									WHERE ctz.ucu_foliocotizacion = @folio
									AND ucc_idcc = @idDetalleCotizacion

									--select @idEmpresa,@idSucursal,@idnotificacion,@idUsuario, @montoCC

									DECLARE @ReturnValue INT
									EXEC @ReturnValue = Notificacion.dbo.UPD_APROBAR_CC_PRESUPUESTO_SP @idEmpresa,@idSucursal,@idnotificacion,@idUsuario, @montoCC
									IF(@ReturnValue=1)    
									BEGIN
										SELECT 1/0

									END


								END
													
								
								
								IF(@respuesta=1)
									BEGIN
										SELECT @cec_idestatuscotiza = 17, @estatusNotificacion = 3,@mensaje = 'Se autorizo CC de la orden : ' + @folio, @resp = 'Aprobado: '					
									END
								ELSE
									BEGIN
										SELECT @cec_idestatuscotiza = 14, @estatusNotificacion = 4,@mensaje = 'Se rechazo CC la orden : ' + @folio, @resp = 'Rechazado: '
									END
								/*
								UPDATE [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
								SET cec_idestatuscotiza=@cec_idestatuscotiza
								WHERE ucu_foliocotizacion =@folio
								*/

								UPDATE NOT_NOTIFICACION SET not_estatus = @estatusNotificacion WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
								UPDATE NOT_APROBACION SET apr_estatus = @estatusNotificacion WHERE apr_id = @idAprobacion;							
								----------------------------------------------------------------
								-------Inserta una respuesta de aprobación
								----------------------------------------------------------------						
							
								INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
									(not_id,[apr_id],[nar_fecha],[nar_comentario])
								VALUES
									(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
			
								DECLARE @estatusFinal INT = 0
								SELECT TOP(1) @estatusFinal = cec_idestatuscotiza FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
									WHERE ucu_foliocotizacion = @folio
			
								INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
								VALUES (7,'APR_INS_AGRUP7_SP termina @folio: ' + @folio + ' ESTATUS FINAL: ' + CONVERT(VARCHAR(10), @estatusFinal) + ' - ' + @mensaje ,GETDATE())

								/*
								IF(@respuesta=1)
									BEGIN
										--SELECT * FROM [cuentasporcobrar].[dbo].[ser_presupweb] WHERE prw_idpresuorden=@idnotificacion	
										UPDATE [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
										SET cec_idestatuscotiza=17
										WHERE ucu_foliocotizacion =@folio

									    SELECT @mensaje = 'Se autorizo CC de la orden : ' + @folio
									END
								ELSE
									BEGIN
										UPDATE [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
										SET cec_idestatuscotiza=14
										WHERE ucu_foliocotizacion =@folio

										SELECT @mensaje = 'Se rechazo CC la orden : ' + @folio
									END
								--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
								--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
								--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
								EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
										@idAprobacion 
										,@respuesta   
										,@observacion 
										,@idnotificacion 
										,@usuario
										,@folio
								--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{*/

							END
						--????????????????????????????????????????????????????????????????????
			--....................................................................
			--............Para aceptar o rechazar Cotización sin Anticipo
						IF (@not_agrupacion = 8)
							BEGIN 
								DECLARE @idCotizacion INT = 0;
								DECLARE @emp_id INT =0;
								SELECT @idCotizacion = [ucu_idcotizacion]      
								FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal] WHERE ucu_foliocotizacion = @folio 
								PRINT @idCotizacion
								SELECT @emp_id = [emp_id] FROM NOT_APROBACION WHERE apr_id = @idAprobacion
								PRINT @emp_id
								IF(@respuesta=1)
									BEGIN
										print 1
										UPDATE [cuentasporcobrar].[dbo].[UNI_AutorizacionEspecial]
										SET	   UAE_EstatusAutEsp=2, UAE_IdUsuarioAutoriza=@emp_id, UAE_FechaAutorizacion=GETDATE() 
										WHERE  UCU_IdCotizacion=@idCotizacion AND [UAE_EstatusAutEsp]=1

										SELECT @mensaje = 'Se autorizo la cotización sin anticipo de la orden : ' + @folio
									END
								ELSE
									BEGIN
									print 2
										UPDATE [cuentasporcobrar].[dbo].[UNI_AutorizacionEspecial]
										SET	   UAE_EstatusAutEsp=3, UAE_IdUsuarioAutoriza=@emp_id, UAE_FechaAutorizacion=GETDATE() 
										WHERE  UCU_IdCotizacion=@idCotizacion AND [UAE_EstatusAutEsp]=1

										SELECT @mensaje = 'Se rechazo la cotización sin anticipo de la orden : ' + @folio
									END
								--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
								--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
								--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
								EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
										@idAprobacion 
										,@respuesta   
										,@observacion 
										,@idnotificacion 
										,@usuario
										,@folio
								--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{	

							END
						--....................................................................
						IF (@not_agrupacion= 0 OR @not_agrupacion = 1 OR @not_agrupacion = 2)
							BEGIN
										DECLARE @proc_Id int
										DECLARE @nodo_Id int
										DECLARE @folio_Operacion varchar(80)

										EXECUTE [Centralizacionv2].[dbo].[INS_CIERRA_NODO_SP] 
										@proceso  --proceso
										,@nodo --nodo
										,@folio --folio
				
							END	
						--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55

						IF  (@not_agrupacion = 10)  --LQMA ADD 28062017 autoriza solicitud de inventario, encapsularlo en SP
						BEGIN
								IF(@respuesta = 1) --Aprobado
									BEGIN										
										SELECT	@ipLocal = '['+ local_net_address + '].'
										FROM	sys.dm_exec_connections
										WHERE	Session_id = @@SPID;

										SELECT @base = nombre_base, @server = '['+ ip_servidor + '].' 
										FROM CentralizacionV2..DIG_CAT_BASES_BPRO 
										WHERE emp_idempresa = @idEmpresa 
											  AND suc_idSucursal = @idSucursal
											  AND tipo = 1
										IF(@ipLocal = @server)
											BEGIN
												SET @server =''											
											END
										SELECT @query = 'SELECT VEH_SITUACION FROM ' + @server +'[' + @base + '].[dbo].[SER_VEHICULO] WHERE VEH_NUMSERIE = ''' + @folio + ''''
										
										--DECLARE @query VARCHAR(200) = 'SELECT VEH_SITUACION FROM [192.168.20.9].[GAAU_Universidad].[dbo].[SER_VEHICULO] WHERE VEH_NUMSERIE = ''JS3TE04V5E4101993''' 
										DECLARE @resultado TABLE(Id INT IDENTITY(1,1),VEH_SITUACION VARCHAR(10))
										
										print @query

										INSERT INTO @resultado
										EXECUTE(@query)			

										IF(SELECT COUNT(Id) FROM @resultado) = 0
											BEGIN
												SELECT @idEstatus = 0, @mensaje = 'La unidad con VIN: '  + @folio + ' no existe en ' + @base
											END
										ELSE
										IF(SELECT VEH_SITUACION FROM @resultado) = 'ING'
											BEGIN				
													
												 SELECT @query = 'UPDATE ' + @server + '[' + @base + '].[dbo].[SER_VEHICULO] SET VEH_SITUACION = ''FIS'' WHERE VEH_NUMSERIE = ''' + @folio + ''''
												 EXECUTE(@query)

												 SELECT @idEstatus = 0, @mensaje = 'La unidad con VIN: '  + @folio + ' ha sido cambiada ha FISICA.'
											END
										ELSE
											SELECT @idEstatus = 0, @mensaje = 'La unidad con VIN: '  + @folio + ' se encuentra en un estatus diferente a INGRESADA.'							
							
										--SELECT * FROM @resultado
										--PRINT @query
									END --@respuesta = 1 aprobado
								ELSE
									SELECT @idEstatus = 0, @mensaje = 'La solicitud para la unidad con VIN: '  + @folio + ' ha sido rechazada'						
							
								UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = @idnotificacion
								UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion
						END		--agrupacion 10

						IF  (@not_agrupacion = 11)  --LQMA ADD 28062017 autoriza desapartado de unidad
						BEGIN

								DECLARE @numeroSerie VARCHAR(50) = ''

								IF(@respuesta = 1) --Aprobado
									BEGIN
							
										--SELECT @base = nombre_base, @server = ip_servidor 
										--FROM CentralizacionV2..DIG_CAT_BASES_BPRO 
										--WHERE emp_idempresa = @idEmpresa 
										--	  AND suc_idSucursal = @idSucursal
										--	  AND tipo = 1
										SELECT	@ipLocal = '['+ local_net_address + '].'
										FROM	sys.dm_exec_connections
										WHERE	Session_id = @@SPID;

										SELECT @base = nombre_base, @server = '['+ ip_servidor + '].' 
										FROM CentralizacionV2..DIG_CAT_BASES_BPRO 
										WHERE emp_idempresa = @idEmpresa 
											  AND suc_idSucursal = @idSucursal
											  AND tipo = 1
										IF(@ipLocal = @server)
											BEGIN
												SET @server =''											
											END
										
										--SELECT @query = 'SELECT VEH_SITUACION FROM [' + @server +'].[' + @base + '].[dbo].[SER_VEHICULO] WHERE VEH_NUMSERIE = ''' + @folio + ''''
										
										SELECT @query = 'SELECT sv.VEH_NUMSERIE, sv.VEH_SITUACION 
										FROM cuentasporcobrar..uni_cotizacionuniversal cu, cuentasporcobrar..uni_cotizacionuniversalunidades cuu,
										' + @server +'[' + @base + '].[dbo].[SER_VEHICULO] sv
										WHERE cu.ucu_idcotizacion=cuu.ucu_idcotizacion
										AND cuu.ucn_noserie=sv.VEH_NUMSERIE
										AND cu.ucu_foliocotizacion = ''' + @folio + ''''

										DECLARE @resultadoVEH TABLE(Id INT IDENTITY(1,1),VEH_NUMSERIE VARCHAR(30), VEH_SITUACION VARCHAR(20))										
										print @query

										INSERT INTO @resultadoVEH
										EXECUTE(@query)

										SELECT TOP(1) @numeroSerie = VEH_NUMSERIE FROM @resultadoVEH

										DECLARE @depto VARCHAR(10) = ''

										SELECT @depto = DE.dep_nombrecto /*ucu_idempresa,ucu_idsucursal,*/ 
										FROM cuentasporcobrar.dbo.uni_cotizacionuniversal CU 
										LEFT JOIN cuentasporcobrar..cat_departamentos DE ON CU.ucu_iddepartamento = DE.dep_iddepartamento 
										WHERE CU.ucu_foliocotizacion = @folio--
										
										SELECT @query = 'UPDATE ' + @server +'[' + @base + '].[dbo].[SER_VEHICULO] 
																	SET VEH_SITUACION =  ''FIS''  
																	WHERE VEH_NUMSERIE = ''' + @numeroSerie + ''''
										print @query		
										EXECUTE(@query)

									    --SELECT @query = 'UPDATE cuentasporcobrar..uni_cotizacionuniversalunidades SET ucn_noserie = ''''
													--			WHERE ucn_noserie = ''' + @numeroSerie + ''' AND ucu_idcotizacion IN (SELECT ucu_idcotizacion FROM cuentasporcobrar..uni_cotizacionuniversal 
													--			 WHERE ucu_foliocotizacion = ''' + @folio + ''')'

										--SELECT @query = 'UPDATE [' + @server +'].[' + @base + '].[dbo].[SER_VEHICULO] SET VEH_SITUACION = ''FIS'' WHERE VEH_NUMSERIE = ''' + @folio + ''' AND '
										--EXECUTE(@query)

										SELECT @idEstatus = 0, @mensaje = 'La unidad con VIN: '  + @numeroSerie + ' ha sido cambiada ha DISPONIBLE.'
									
										--SELECT * FROM @resultado
										--PRINT @query
									END --@respuesta = 1 aprobado
								ELSE
									SELECT @idEstatus = 0, @mensaje = 'La solicitud para el desapartado de unidad ' + @numeroSerie + ' ha sido rechazada.'						
							
								--UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = @idnotificacion
								--UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion
								--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
								--Para cambiar estatus a aprobada o rechazada en la tabla de NOT_NOTIFICACION y NOT_APROBACION
								--y realizar un insert en la tabla [NOT_APROBACION_RESPUESTA]
								EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
										@idAprobacion 
										,@respuesta   
										,@observacion 
										,@idnotificacion 
										,@usuario
										,@folio
								--{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
						END		--agrupacion 11
						
						IF  (@not_agrupacion = 13)  --LQMA ADD 17042018 autorizacion Tramites
						BEGIN
								DECLARE @tabRespTram TABLE(id INT,mensaje VARCHAR (1000))
								
								INSERT INTO @tabRespTram								
								EXEC cuentasporcobrar.dbo.UPD_DetallePedido_SP @folio, @respuesta
							
								SELECT TOP(1) @idEstatus = id, @mensaje = mensaje FROM @tabRespTram
								
								EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
										@idAprobacion 
										,@respuesta   
										,@observacion 
										,@idnotificacion 
										,@usuario
										,@folio			
								
						END		--agrupacion 13


						IF  (@not_agrupacion = 15)  --LQMA ADD 17042018 autorizacion Cancela Conciliación
						BEGIN
							
							Print 'Plan Piso descomentar cuando se libere este modulo'
								--EXEC PlanPiso.dbo.[NOT_CON_CONFIRMACANCELACION_SP] @not_identificador, @respuesta
							
								--SELECT @idEstatus = 0, @mensaje = 'La solicitud ha sido procesada.'			
								
								--EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
								--		@idAprobacion 
								--		,@respuesta   
								--		,@observacion 
								--		,@idnotificacion 
								--		,@usuario
								--		,@folio			
								
						END		--agrupacion 15
						
						IF  (@not_agrupacion = 16)  --LQMA ADD 17042018 autorizacion Valida Transpaso Financiera
						BEGIN
							
							Print 'Plan Piso descomentar cuando se libere este modulo'
								--EXEC PlanPiso.dbo.[NOT_TRASPASO_PAGO_SP] @not_identificador, @respuesta

								--SELECT @idEstatus = 0, @mensaje = 'La solicitud ha sido procesada.'

								--EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
								--		@idAprobacion 
								--		,@respuesta   
								--		,@observacion 
								--		,@idnotificacion 
								--		,@usuario
								--		,@folio
								
						END		--agrupacion 16						

						IF  (@not_agrupacion = 17)  --LQMA ADD 17042018 autorizacion unidad de cotizacion
						BEGIN
								DECLARE @tabRespCotUni TABLE(id INT,mensaje VARCHAR (1000))
								
								INSERT INTO @tabRespCotUni
								EXEC cuentasporcobrar.dbo.UPD_AUTORIZACIONUNIDAD_SP  @folio, @respuesta

								SELECT TOP(1) @idEstatus = 0, @mensaje = mensaje FROM @tabRespCotUni --'La solicitud ha sido procesada.'

								EXECUTE [INS_ACCIONES_APROBACION_5_SP] 
										@idAprobacion 
										,@respuesta   
										,@observacion 
										,@idnotificacion 
										,@usuario
										,@folio
								
						END		
						IF  (@not_agrupacion = 45)  
						BEGIN
						print 'aprobar cc sin presupuesto'
																
								INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
								VALUES (7,'APR_INS_AGRUP7_SP inicia @folio: ' + @folio ,GETDATE())

								DECLARE @idestatuscotiza INT = 0, @estatusNot INT = 0, @respu VARCHAR(30) = ''

								
								DECLARE @idDetalleCC INT = 0

								SELECT @idDetalleCC = not_adjunto_tipo FROM NOT_NOTIFICACION WHERE not_id = @idnotificacion

								UPDATE CC SET CC.ucc_estatus = CASE @respuesta 
																							WHEN 1 THEN 1  --aprobado
																							WHEN 0 THEN 3  --rechazado
																						END  
								FROM [cuentasporcobrar].[dbo].UNI_CCS CC 
								INNER JOIN [cuentasporcobrar].[dbo].uni_cotizacionuniversal ctz
								ON cc.ucu_idcotizacion=ctz.ucu_idcotizacion
								WHERE ctz.ucu_foliocotizacion = @folio
									  AND ucc_idcc = @idDetalleCC
								
								
								IF(@respuesta=1)
									BEGIN
										SELECT @idestatuscotiza = 17, @estatusNot = 3,@mensaje = 'Se autorizó CC del Folio: ' + @folio, @resp = 'Aprobado: '					
									END
								ELSE
									BEGIN
										SELECT @idestatuscotiza = 14, @estatusNot = 4,@mensaje = 'Se rechazó CC del Folio: ' + @folio, @resp = 'Rechazado: '
									END
								

								UPDATE NOT_NOTIFICACION SET not_estatus = @estatusNot WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
								UPDATE NOT_APROBACION SET apr_estatus = @estatusNot WHERE apr_id = @idAprobacion;							
								----------------------------------------------------------------
								-------Inserta una respuesta de aprobación
								----------------------------------------------------------------						
							
								INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
									(not_id,[apr_id],[nar_fecha],[nar_comentario])
								VALUES
									(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
			
								DECLARE @estatusFinalF INT = 0
								SELECT TOP(1) @estatusFinal = cec_idestatuscotiza FROM [cuentasporcobrar].[dbo].[uni_cotizacionuniversal]
									WHERE ucu_foliocotizacion = @folio
			
								INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
								VALUES (7,'APR_INS_AGRUP7_SP termina @folio: ' + @folio + ' ESTATUS FINAL: ' + CONVERT(VARCHAR(10), @estatusFinalF) + ' - ' + @mensaje ,GETDATE())


								
						END		--agrupacion 45	

						IF  (@not_agrupacion = 53)  
						BEGIN
						print' entro en agrupacion 53'
						INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
						VALUES (7,'APR_INS_AGRUP7_SP inicia @folio: ' + @folio ,GETDATE())
						DECLARE  @estNot INT = 0, @res VARCHAR(30) = ''
						/* aqui va tu codigo Robert*/
						SELECT   @not_identificador = ntf.not_identificador
							FROM dbo.NOT_APROBACION apr 
							LEFT JOIN dbo.NOT_NOTIFICACION ntf ON ntf.not_id = apr.not_id
							LEFT JOIN [dbo].[OrdenesdeCompra] orc ON orc.oce_folioorden = ntf.not_identificador
							LEFT JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_PARAMETROS dep ON dep.Proc_Id = ntf.not_tipo_proceso
							AND dep.Nodo_Id = ntf.not_nodo 
							AND dep.emp_idempresa = orc.[oce_idempresa]
							AND dep.suc_idsucursal = orc.[oce_idsucursal]
							AND dep.dep_iddepartamento = orc.[oce_iddepartamento]
							AND dep.tipo_idtipoorden = orc.[oce_idtipoorden]
							WHERE apr.apr_id = @idAprobacion

						IF(@respuesta=1)
						BEGIN
							
							--@idUsuario

							SELECT @estNot = 3,@mensaje = 'Se autorizó correctamente el tramite: ' + @folio, @res = 'Aprobado: '
							EXEC [Tramites].[Tramite].[Sp_Tramite_AprobarRechazar_UPD] @not_identificador, 2, @idUsuario
						END
						ELSE
						BEGIN

						SELECT  @estNot = 4,@mensaje = 'Se rechazó correctamente el tramite: ' + @folio, @res = 'Rechazado: '
						EXEC [Tramites].[Tramite].[Sp_Tramite_AprobarRechazar_UPD] @not_identificador, 3, @idUsuario
						END

						UPDATE NOT_NOTIFICACION SET not_estatus = @estNot WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
						UPDATE NOT_APROBACION SET apr_estatus = @estNot WHERE apr_id = @idAprobacion;
						----------------------------------------------------------------
						-------Inserta una respuesta de aprobación
						----------------------------------------------------------------

						INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]
						(not_id,[apr_id],[nar_fecha],[nar_comentario])
						VALUES
						(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)





						END --agrupacion 53


						IF  (@not_agrupacion = 54)  
						BEGIN
							PRINT('Cierra notificacion')
							INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
							VALUES (7,'APR_INS_AGRUP7_SP inicia @folio: ' + @folio ,GETDATE())
							DECLARE  @estNoti INT = 0, @response VARCHAR(30) = ''
							/* aqui va tu codigo Robert*/

							SELECT   @not_identificador = ntf.not_identificador
							FROM dbo.NOT_APROBACION apr 
							LEFT JOIN dbo.NOT_NOTIFICACION ntf ON ntf.not_id = apr.not_id
							LEFT JOIN [dbo].[OrdenesdeCompra] orc ON orc.oce_folioorden = ntf.not_identificador
							LEFT JOIN Centralizacionv2.dbo.DIG_ESCALAMIENTO_PARAMETROS dep ON dep.Proc_Id = ntf.not_tipo_proceso
							AND dep.Nodo_Id = ntf.not_nodo 
							AND dep.emp_idempresa = orc.[oce_idempresa]
							AND dep.suc_idsucursal = orc.[oce_idsucursal]
							AND dep.dep_iddepartamento = orc.[oce_iddepartamento]
							AND dep.tipo_idtipoorden = orc.[oce_idtipoorden]
							WHERE apr.apr_id = @idAprobacion

							DECLARE @EstatusComprbacion INT = (SELECT estatusNotificacionDeMas FROM tramites.tramite.conceptoarchivo where idconceptoarchivo = @not_identificador AND estatusNotificacionDeMas IN (3,4));
							
							--IF ( @EstatusComprbacion = 3 OR @EstatusComprbacion = 4 )
							--	BEGIN
							--		SELECT @estNot = 3, @idEstatus = -1, @mensaje = 'El tramite ya ha sido procesado con anterioridad. 1'
							--	END
							--ELSE
							--	BEGIN
									IF(@respuesta=1)
										BEGIN
											UPDATE 
												tramites.tramite.conceptoarchivo 
											SET 
												estatusNotificacionDeMas = 3										
											WHERE idconceptoarchivo = @not_identificador

											SELECT @estNot = 3, @idEstatus = 3, @mensaje = 'Se autorizó correctamente el trámite: ' + @folio, @res = 'Aprobado: '
										END
									ELSE
										BEGIN
											UPDATE tramites.tramite.conceptoarchivo SET estatusNotificacionDeMas = 4, compNoAutorizado = 1 WHERE idconceptoarchivo = @not_identificador
											SELECT  @estNot = 4, @idEstatus = 4,@mensaje = 'Se rechazó correctamente el trámite: ' + @folio , @res = 'Rechazado: '
										END	
								--END

							

							
							UPDATE NOT_NOTIFICACION SET not_estatus = @estNot WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
							UPDATE NOT_APROBACION SET apr_estatus = @estNot WHERE apr_id = @idAprobacion;
							----------------------------------------------------------------
							-------Inserta una respuesta de aprobación
							----------------------------------------------------------------

							INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]
							(not_id,[apr_id],[nar_fecha],[nar_comentario])
							VALUES
							(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
						END --agrupacion 54
						IF  (@not_agrupacion = 52)  
						BEGIN
						print 'Autorizar salida unidad'
																
								DECLARE @estatusAuto int
								
								
								IF(@respuesta=1)
									BEGIN
										SELECT @estatusAuto =  3,@mensaje = 'Se autorizó salida de unidad Folio: ' + @folio, @resp = 'Aprobado: '					
									END
								ELSE
									BEGIN
										SELECT  @estatusAuto = 4,@mensaje = 'Se rechazo salida de unidad Folio: ' + @folio, @resp = 'Rechazado: '
									END
								

								UPDATE NOT_NOTIFICACION SET not_estatus = @estatusAuto WHERE not_id = (SELECT not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion)
								UPDATE NOT_APROBACION SET apr_estatus = @estatusAuto WHERE apr_id = @idAprobacion;							
								----------------------------------------------------------------
								-------Inserta una respuesta de aprobación
								----------------------------------------------------------------						
							
								INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
									(not_id,[apr_id],[nar_fecha],[nar_comentario])
								VALUES
									(@idnotificacion,@idAprobacion,GETDATE(),@resp +  @observacion)
			
								
			
								


								
						END		--agrupacion 52	
						

     				SELECT @idEstatus estatus, @mensaje mensaje 

			COMMIT TRAN TRAN_UPD_APROBACION_UP
				END
		END TRY
	    BEGIN CATCH

		            ROLLBACK TRAN TRAN_UPD_APROBACION_UP
	
					DECLARE @Componente VARCHAR(50) = 'UPD_APROBACION_SP_UP', @errorMensaje VARCHAR(MAX) = ERROR_MESSAGE() + ' - Folio: ' + @folio
					DECLARE @tablaRespuesta TABLE(idError INT)

					INSERT INTO @tablaRespuesta
					EXECUTE INS_ERROR_SP @Componente, @errorMensaje
					
					SELECT ERROR_NUMBER() estatus, 'No se pudo ejecutar el proceso. Intente de nuevo.' mensaje
					

		END CATCH

go

