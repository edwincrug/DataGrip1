CREATE PROCEDURE [dbo].[SEL_NOTIFICACION_ESTATUS_FLOTILLAS_SP]
 @identificador NVARChAR(50)
,@idTipoNotificacion INT 
AS
BEGIN 
--------------------------------------------------------------------------------------------------------
--DECLARE  @identificador NVARChAR(50) = 'AU-AU-UNI-UN-4557'--'XX-XX-XXX-XX-XX-XXX1'
--		,@idTipoNotificacion INT = 3
--------------------------------------------------------------------------------------------------------
----Detalle de la Notificación
--SELECT 'NOTIFICACION'
SELECT TOP(1) N.not_id
		 ,N.not_identificador
		 ,N.not_descripcion
		 ,N.not_estatus
		 ,N.not_fecha
		 ,N.not_agrupacion
		 ,N.idEmpresa
		 ,N.idSucursal
FROM    Notificacion.dbo.NOT_NOTIFICACION AS N
		INNER JOIN CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT AS DEF ON DEF.not_agrupador = N.not_agrupacion
WHERE    not_identificador = @identificador
AND		DEF.idTipoNotificacion = @idTipoNotificacion
ORDER BY not_fecha desc
-------------------------------------------------------------------------
END
go

