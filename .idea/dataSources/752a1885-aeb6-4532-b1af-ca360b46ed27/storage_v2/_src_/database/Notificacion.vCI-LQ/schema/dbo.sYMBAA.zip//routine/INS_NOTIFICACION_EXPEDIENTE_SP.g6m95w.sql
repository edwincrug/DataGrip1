------------------------------------------------
-- EXEC [dbo].[INS_NOTIFICACION_EXPEDIENTE_SP] 'C-XXXX-C',1,28,'Compra tipo C',4,6, null,'','',NULL,NULL
------------------------------------------------
CREATE PROCEDURE [dbo].[INS_NOTIFICACION_EXPEDIENTE_SP]
		 
	 @identificador		 VARCHAR(50) 
	,@idSolicitante		 NUMERIC(18,0) 
	,@idTipoNotificacion INT 
	,@descripcion		 VARCHAR(MAX) = ''
	,@idEmpresa			 INT = NULL
	,@idSucursal		 INT = NULL
	,@idDepartamento	 INT = NULL
	,@linkBPRO			 VARCHAR(MAX) = NULL
	,@notAdjunto		 VARCHAR(MAX) = NULL 
	,@notAdjuntoTipo	 VARCHAR(500) = NULL
	,@respuesta         VARCHAR(500) Output
    ,@resultado         INT = 0 Output


	
	
	
AS
BEGIN
	SET NOCOUNT ON;
	
	

BEGIN TRAN TRAN_INS_NOTIFICACION

BEGIN TRY
		--DECLARE  @identificador		 VARCHAR(50)  = 'Prueba-XXXX-A'
		--	,@idSolicitante		 NUMERIC(18,0) = 71
		--	,@idTipoNotificacion INT  = 29
		--	,@descripcion		 VARCHAR(MAX) = 'Autorizacion de salida unidad '
		--	,@idEmpresa			 INT = 4
		--	,@idSucursal		 INT = 6
		--	,@idDepartamento	 INT = NULL
		--	,@linkBPRO			 VARCHAR(MAX) = NULL
		--	,@notAdjunto		 VARCHAR(MAX) = NULL 
		--	,@notAdjuntoTipo	 VARCHAR(500) = NULL


	DECLARE  @idNot INT
			,@aprobador			NUMERIC(18,0)
			,@notAgrupacion		NUMERIC(18,0)
			,@emp_id INT 
			,@empresaSucursal   VARCHAR(10)
			,@success           BIT
			,@notIdInsertados  VARCHAR(20)
	
	declare @tblAutorizadores as table(id int identity, idUsuario int, idEmpresa int, idSucursal int)
	 			
	IF((@idEmpresa IS NULL OR @idEmpresa = 0) AND (@idSucursal IS NULL OR @idSucursal = 0)  )
	BEGIN
			SELECT  0 not_id, 0 success, -1 result , 'message' = 'Favor de Agregar la Empresa, Sucursal ' 
			
	END	
	ELSE
	BEGIN
			DECLARE @cont INT = 1
				
			INSERT INTO @tblAutorizadores 
			SELECT    cat_valor idUsuario
					,@idEmpresa
					,@idSucursal
			FROM Centralizacionv2.dbo.DIG_CATALOGOS C
			WHERE cat_id_padre = 2900
			AND cat_nombre in ( LTRIM(RTRIM(CONVERT(CHAR(3),@idEmpresa))) + '|' + LTRIM(RTRIM(CONVERT(CHAR(3),@idSucursal))) )
			
			SET @notAgrupacion = 52


			WHILE(@cont <= (select count(1) FROM @tblAutorizadores ))
			BEGIN
				SELECT @emp_id = idUsuario FROM  @tblAutorizadores WHERE id = @cont

				INSERT INTO NOT_NOTIFICACION (
										  not_tipo
										, not_tipo_proceso
										, not_identificador
										, not_nodo
										, not_descripcion
										, not_estatus
										, not_fecha
										, not_link_BPRO
										, not_adjunto
										, not_adjunto_tipo
										, not_agrupacion
										, idEmpresa
										, idSucursal
										)
						VALUES			( 
										  1
										, 1
										, @identificador
										, 1
										, @descripcion
										, 2
										, GETDATE()
										, @linkBPRO
										, @notAdjunto
										, null
										, @notAgrupacion
										, @idEmpresa
										, @idSucursal
										)

					SET @idNot  = @@IDENTITY
					SET @success = 1

					--Solicitante (si aprobador = solicitante, solo se inserta aprobador)
					IF(@emp_id != @idsolicitante) 
					BEGIN
						INSERT INTO [dbo].[NOT_APROBACION]
							   ([not_id]
							   ,[apr_nivel]
							   ,[apr_visto]
							   ,[emp_id]
							   ,[apr_fecha]
							   ,[apr_estatus]
							   ,[apr_escalado])
						 VALUES
							   (@idNot
							   ,0
							   ,NULL
							   ,@idsolicitante
							   ,GETDATE()
							   ,1
							   ,-1)
					END
		   
					--Aprobador

					INSERT INTO [dbo].[NOT_APROBACION]
						   ([not_id]
						   ,[apr_nivel]
						   ,[apr_visto]
						   ,[emp_id]
						   ,[apr_fecha]
						   ,[apr_estatus]
						   ,[apr_escalado])
					 VALUES
						   (@idNot
						   ,0
						   ,NULL
						   ,@emp_id
						   ,GETDATE()
						   ,2
						   ,0)

					
	
	

					INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
					VALUES (5,'INS_NOTIFICACION_EXPEDIENTE_SP @aprobador:' + CONVERT(VARCHAR(5),@emp_id) ,GETDATE())

					
				
				SET @cont = @cont + 1

			END
					declare  @valores VARCHAR(50) = ''
					
					SELECT @valores = COALESCE(@valores + '|','' ) + CONVERT(VARCHAR(20),apr_id)  FROM NOT_APROBACION A
					INNER JOIN NOT_NOTIFICACION N on A.not_id = N.not_id 
					WHERE emp_id in (select idUsuario FROM @tblAutorizadores ) AND apr_escalado = 0 AND not_identificador = @identificador and not_agrupacion = @notAgrupacion


					
		
		
	--	SELECT substring(@valores,2,len(@valores)) idAprobacion, @success success, 1 result , 'message' = 'La operación se realizó con exito.' 
		set @respuesta = substring(@valores,2,len(@valores))
		set @resultado = 1

		--SELECT * FROM NOT_APROBACION A
		--			INNER JOIN NOT_NOTIFICACION N on A.not_id = N.not_id 
		--			WHERE  not_identificador = @identificador

	

				


	END

	

	COMMIT TRAN TRAN_INS_NOTIFICACION	
	
	
END TRY
BEGIN CATCH

	ROLLBACK TRAN TRAN_INS_NOTIFICACION
	DECLARE @Mensaje  nvarchar(max)
	SELECT @Mensaje = ERROR_MESSAGE()	
	SET @respuesta = ''
	SET @resultado = 0	
	--SELECT   0 idAprobacion, @success success, -1 result, @Mensaje 'message'
 	
	--EXECUTE INS_ERROR_SP 'INS_NOTIFICACION_SP', @Mensaje 
	
END CATCH
END
go

