-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 16/10/2015
-- Description: Stored que recupera las empresas
-- =============================================
--SEL_EMPRESA_FILTRO_SP 71 
CREATE PROCEDURE [dbo].[SEL_EMPRESA_FILTRO_SP] 
	@idUsuario INT = 0
AS
BEGIN	
		
		/*
		SELECT DISTINCT emp_idempresa,suc_idsucursal FROM [ControlAplicaciones].[dbo].[ope_organigrama]
			WHERE [usu_idusuario] = @idProveedor
		*/
		SELECT 0 emp_idempresa
				, '' emp_cveempresa
				, '---Todas---' emp_nombre
				, '' emp_nombrecto
		UNION
		SELECT   DISTINCT E.emp_idempresa
				, E.emp_cveempresa
				, E.emp_nombre
				, E.emp_nombrecto
		FROM  ControlAplicaciones.dbo.cat_empresas E
		INNER JOIN [ControlAplicaciones].[dbo].[ope_organigrama] org ON E.emp_idempresa = org.emp_idempresa
		WHERE org.usu_idusuario = @idUsuario		
		
END
go

