-- =============================================
-- Author:		Arturo Rodea Victoria
-- Create date: 23/09/2015
-- Description:	Stored que guarda una conversacion
-- =============================================

--INS_CONVERSACION_SP 1,10,'Prueba de Chat'
CREATE PROCEDURE [dbo].[INS_CONVERSACION_SP]
	-- Add the parameters for the stored procedure here
	@idempleado nvarchar(50),
	@idnotificacion nvarchar(50),
	@texto nvarchar(250)
AS
BEGIN
	
	INSERT INTO [Notificacion].[dbo].NOT_CHAT
           ([chat_idEmpleado]
           ,[chat_texto]
           ,[chat_idNotificacion]
           ,[chat_fecha]
		   ,[chat_visto])
     VALUES
           (@IdEmpleado
           ,@texto
           ,@IdNotificacion
           ,GetDate()
		   ,0)

	
END



go

