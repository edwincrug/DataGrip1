-- =============================================
-- Author:		Genaro Mora Valencia 
-- Create date: 02/12/2015
-- Description:	Procedimiento que realiza la aprobación de la alerta
-- =============================================

-- [UPD_ALERTA_SP] 20544
CREATE PROCEDURE [dbo].[UPD_ALERTA_SP]
	@idAprobacion numeric(18,0)
AS
	SET NOCOUNT ON;
	
	BEGIN TRY
	
		DECLARE @idnotificacion numeric(18,0)
		--Checar que no esté ya aprobada
		-- Obtener el idNotifiacion
		SELECT @idnotificacion = not_id FROM NOT_APROBACION WHERE apr_id = @idAprobacion		
				--Actualiza el estatus apr_estatus a 3 de la tabla NOT_APROBACION
		UPDATE NOT_APROBACION SET apr_estatus = 3 WHERE apr_id = @idAprobacion					
				--MODIFICAR POR INSERT EN RESPUESTA									
		INSERT INTO [dbo].[NOT_APROBACION_RESPUESTA]									
				([not_id],apr_id, [nar_fecha],[nar_comentario])
					VALUES
					(@idnotificacion,@idAprobacion,GETDATE(),'')							
					--Actualiza el estatus apr_estatus a 3 de la tabla NOT_NOTIFICACION	
		
		--LQMA add 01112017 solo cambia el estatus de los avisos de escalamiento
		IF(SELECT not_tipo FROM Notificacion.dbo.NOT_NOTIFICACION WHERE not_id = @idnotificacion) = 7	
		UPDATE NOT_NOTIFICACION SET not_estatus = 3 WHERE not_id = @idnotificacion
		
		SELECT 1 error	

				
	END TRY
	BEGIN CATCH
	
		--DECLARE @Mensaje INT,
		--@Componente nvarchar(50) = 'UPD_ALERTA_SP'
		--SELECT @Mensaje = ERROR_NUMBER() 	
		--RETURN EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
		SELECT ERROR_NUMBER() AS error
	END CATCH


go

