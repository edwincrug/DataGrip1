CREATE PROCEDURE [dbo].[UPD_APROBAR_CC_PRESUPUESTO_SP]
@idEmpresa INT 
,@idSucursal INT 
,@notId INT 
,@idUsuario INT 
,@montoCC DECIMAL(18,5) 
AS
BEGIN

BEGIN TRY 
--DECLARE @idEmpresa INT = 4
--		,@idSucursal INT = 6
--		,@notId INT = 236685
--		,@idUsuario INT = 71
--		,@montoCC DECIMAL(18,5) = 6000

DECLARE @bdConcentra VARCHAR(100)
		,@cuenta VARCHAR(MAX)
		,@sql NVARCHAR(MAX)
		,@mes VARCHAR(10) = CONVERT(VARCHAR(10),DATEPART(mm,GETDATE()))
		,@presupuesto DECIMAL(18,5)
		,@montoCCS DECIMAL(18,5)
		,@ParmDefinition NVARCHAR(100)
		,@idtipoproceso int
		,@folioCotizacion varchar(50) 
		,@descripcion varchar(500) = ''
		,@aprobador	numeric(18,0)
		,@idCC	numeric(18,0)
		,@consecutivoContable varchar(10) =  (SELECT consecutivo_contable from Centralizacionv2.dbo.DIG_CAT_BASES_BPRO where emp_idEmpresa = @idEmpresa and suc_idSucursal = @idSucursal and tipo = 1)
		,@cuentaContable varchar(20)  

		--SET @cuentaContable =  '905'+ @consecutivoContable+'-0030-0001-0001'
		SET @cuentaContable =   '9052-0001-'+RIGHT('0000' + LTRIM(RTRIM(CONVERT(VARCHAR(4), @consecutivoContable))),4)+ '-0001'


	


SELECT @bdConcentra = nombre_base from Centralizacionv2.[dbo].[DIG_CAT_BASES_BPRO] where emp_idempresa = @idEmpresa AND tipo = 2 
SET @cuenta = @bdConcentra+'.dbo.CON_CTAS01'+ CONVERT(VARCHAR(10),DATEPART(yy,GETDATE()))


SET @sql =' SELECT  @res =   CASE WHEN '+ convert(VARCHAR(5),@mes) + ' = 1 THEN CTA_PRESUP1
							WHEN '+ convert(VARCHAR(5),@mes) +' = 2 THEN CTA_PRESUP2
							WHEN '+ convert(VARCHAR(5),@mes) +' = 3 THEN CTA_PRESUP3
							WHEN '+ convert(VARCHAR(5),@mes) +' = 4 THEN CTA_PRESUP4
							WHEN '+ convert(VARCHAR(5),@mes) +' = 5 THEN CTA_PRESUP5
							WHEN '+ convert(VARCHAR(5),@mes) +' = 6 THEN CTA_PRESUP6
							WHEN '+ convert(VARCHAR(5),@mes) +' = 7 THEN CTA_PRESUP7
							WHEN '+ convert(VARCHAR(5),@mes) +' = 8 THEN CTA_PRESUP8
							WHEN '+ convert(VARCHAR(5),@mes) +' = 9 THEN CTA_PRESUP9
							WHEN '+ convert(VARCHAR(5),@mes) +' = 10 THEN CTA_PRESUP10
							WHEN '+ convert(VARCHAR(5),@mes) +' = 11 THEN CTA_PRESUP11
							WHEN '+ convert(VARCHAR(5),@mes) +' = 12 THEN CTA_PRESUP12 END
			FROM  ' + @cuenta+ '
			WHERE CTA_NUMCTA = '''+@cuentaContable+''''

print @sql


SET @ParmDefinition = N' @res  VARCHAR(100) OUTPUT'; 
EXECUTE sp_executesql @sql, @ParmDefinition, @res= @presupuesto OUTPUT

--SELECT @presupuesto



	select @montoCCS = ISNULL(SUM(ucc_monto),0) from cuentasporcobrar.dbo.uni_ccs C
	INNER JOIN cuentasporcobrar.dbo.uni_cotizacionuniversal U on U.ucu_idcotizacion = C.ucu_idcotizacion
	WHERE U.ucu_idempresa = @idEmpresa
	AND U.ucu_idsucursal = @idSucursal
	AND	 C.ucc_fechaalta >= CONVERT(DATETIME,'23-06-2020',103) 
	AND  DATEPART(mm,C.ucc_fechaalta) = DATEPART(mm,GETDATE())
	AND  ucc_estatus IN (1)

--select * from cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSALUNIDADES where ucu_idcotizacion = 37592
-- select * from cuentasporcobrar.dbo.UNI_COTIZACIONUNIVERSAL where ucu_idcotizacion = 37592
--select * from Notificacion.dbo.NOT_NOTIFICACION where not_identificador = 'AU-ZM-NZA-UN-5745'

	SET @montoCCS = @montoCCS + @montoCC

	--select @montoCCS
	SELECT @folioCotizacion = not_identificador, @idCC = not_adjunto_tipo  FROM Notificacion.dbo.NOT_NOTIFICACION WHERE not_id = @notId

	IF(@montoCCS <= @presupuesto)
	BEGIN

	print 'tiene'
		UPDATE CC SET CC.ucc_estatus = 1
		FROM [cuentasporcobrar].[dbo].UNI_CCS CC 
		INNER JOIN [cuentasporcobrar].[dbo].uni_cotizacionuniversal ctz
		ON cc.ucu_idcotizacion=ctz.ucu_idcotizacion
		WHERE ctz.ucu_foliocotizacion = @folioCotizacion
		AND ucc_idcc = @idCC
	END
	ELSE
	BEGIN
	print 'no tiene'
				UPDATE CC SET CC.ucc_estatus = 4
				FROM [cuentasporcobrar].[dbo].UNI_CCS CC 
				INNER JOIN [cuentasporcobrar].[dbo].uni_cotizacionuniversal ctz
				ON cc.ucu_idcotizacion=ctz.ucu_idcotizacion
				WHERE ctz.ucu_foliocotizacion = @folioCotizacion
				AND ucc_idcc = @idCC


				SET @descripcion = 'Solicitud de Aprobacion de la cotizacion con folio: ' + @folioCotizacion + ' tiene un CC con monto de: $'+Convert(varchar(20),@montoCC)+' que excede del presupuesto; Favor de validar a la brevedad'; 
				SELECT  @aprobador = cat_valor from CentralizacionV2.dbo.DIG_CATALOGOS where cat_id_padre = 120 AND cat_nombre = @idEmpresa
				
				DECLARE @ReturnValue INT
				EXEC  Notificacion.[dbo].[INS_APROBACION_CC_SINPRESUPUESTO_SP] 7,@folioCotizacion,@descripcion,2,@aprobador,@idCC
				--IF(@ReturnValue=0)       
				--BEGIN
                 

					INSERT INTO Notificacion.dbo.NOT_NOTIFICACION (not_tipo, not_tipo_proceso, not_identificador, not_nodo, not_descripcion, not_estatus, not_fecha, not_link_BPRO
												, not_adjunto	, not_adjunto_tipo, not_agrupacion, idEmpresa, idSucursal)
											VALUES(1, 7	, @folioCotizacion, 0	, 'Se envió al Director de Marca una autorización de CC sin presupuesto por un monto de: $' + CONVERT(VARCHAR(50),@montoCC) + '.' , 2	, GETDATE()	, '','', @idCC, 46, @idEmpresa, @idSucursal)
	
					DECLARE @idNot NUMERIC(18,0) = SCOPE_IDENTITY()
	
					INSERT INTO Notificacion.dbo.NOT_APROBACION(not_id,apr_nivel,apr_visto,emp_id,apr_fecha,apr_estatus,apr_escalado)
					VALUES(@idNot,0,0,@idUsuario,GETDATE()	,2,-1)
				--END 
	END
	

END TRY 
BEGIN CATCH

	

END CATCH
--select * from Notificacion.dbo.NOT_NOTIFICACION  where  not_identificador = 'AU-ZM-NZA-UN-5745'
--UPDATE Notificacion.dbo.NOT_NOTIFICACION  SET not_tipo_proceso = 7, not_agrupacion = 41 where not_id = 236715
--select * from Notificacion.dbo.NOT_APROBACION where not_id in (select not_id from Notificacion.dbo.NOT_NOTIFICACION where not_identificador = 'AU-ZM-NZA-UN-5745')
END
go

