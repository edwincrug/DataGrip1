-- =============================================
-- Author: Genaro Mora Valencia
-- Create date: 12/03/2015
-- Modified date: 05/11/2015
-- Description:	INS_APROBACION_LOTE_SP Inserta las notificacione de aprobación del un Lote
-- =============================================
-- [INS_APROBACION_LOTE_SP] 1, 87, 1, 'Autorización de LOTE', 1, '', 'http://direccion/cercana/archivo.pdf', 'pdf', 1, 2

CREATE PROCEDURE [dbo].[INS_APROBACION_LOTE_SP]
	@idtipoproceso int
	,@identificador varchar(50)
	,@idnodo	int
	,@descripcion varchar(500)
	,@estatus int
	,@linkBPRO varchar(MAX) = NULL
	,@adjunto varchar(MAX) = NULL
	,@idtipoadjunto	varchar(500)
	,@solicitante numeric(18,0) 
	,@aprobador	numeric(18,0)  
AS
BEGIN

	SET NOCOUNT ON;
-- inserta una notificación de tipo aprobación
BEGIN TRY



		INSERT INTO NOT_NOTIFICACION (not_tipo
		, not_tipo_proceso
		, not_identificador
		, not_nodo
		, not_descripcion
		, not_estatus
		, not_fecha
		, not_link_BPRO
		, not_adjunto
		, not_adjunto_tipo
		, not_agrupacion)
		VALUES
		( 1
		, @idtipoproceso
		, @identificador
		, @idnodo
		, @descripcion
		, @estatus
		, GETDATE()
		, @linkBPRO
		, @adjunto
		, @idtipoadjunto
		, 1
		)

	DECLARE @nid_not int = @@IDENTITY;


	-- Obtiene la empresa y el solicitante de la tabla cxp_lotes.
	SELECT @descripcion = OL.lts_idempresa, @solicitante = OL.lts_usualta FROM [cuentasxpagar].dbo.cxp_lotes OL WHERE OL.lts_numlote = @identificador
				
			
--Solicitante
--LQMA  add 17062016   si aprobador = solicitante, solo se inserta aprobador
----------------------------------
IF(@aprobador != @solicitante) --si aprobador es diferente de solicitante, se inserta solicitante
	BEGIN
		INSERT INTO [dbo].[NOT_APROBACION]
					([not_id]
					,[apr_nivel]
					,[apr_visto]
					,[emp_id]
					,[apr_fecha]
					,[apr_estatus]				
					,[apr_escalado])
		 VALUES
			   (@nid_not
			   ,0
			   ,NULL
			   ,@solicitante
			   ,GETDATE()
			   ,1
			   ,-1)
    END       
           
--Aprobador
----------------------------------
	INSERT INTO [dbo].[NOT_APROBACION]
           ([not_id]
		   ,[apr_nivel]
		   ,[apr_visto]
           ,[emp_id]
           ,[apr_fecha]
           ,[apr_estatus]
           ,[apr_escalado])
     VALUES
           (@nid_not
		   ,0
		   ,NULL
           ,@aprobador
           ,GETDATE()
           ,1
           ,0)
	
	
--Actualiza el estatus de la notificación a "En proceso"
----------------------------------
	UPDATE NOT_NOTIFICACION SET not_estatus = 2 
		WHERE not_id =@nid_not
		
		
	  select 0 error 
	
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'INS_APROBACION_LOTE_SP'
	SELECT ERROR_NUMBER() error
	SELECT @Mensaje = ERROR_MESSAGE()
	EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
		
END CATCH

END


go

