

--select * from Centralizacionv2.dbo.DIG_TIPO_NOTIFICACION
--select * from Centralizacionv2.dbo.DIG_ESCALAMIENTO_FLOT where idTipoNotificacion = 16
--select * from Centralizacionv2.dbo.DIG_ESCALAMIENTO_MANCOMUNADO where idTipoNotificacion = 16
--SELECT * FROM NOT_NOTIFICACION WHERE not_id = '253029'
--SELECT * FROM NOT_APROBACION WHERE NOT_ID = 233259
------------------------------------------------
-- EXEC [dbo].[INS_NOTIFICACION_SP] '11XX',1993, 11, 'Pruebas', 4, 6, 26, 'link','', ''
------------------------------------------------
CREATE PROCEDURE [dbo].[INS_NOTIFICACION_SP]
	
	 
	 @identificador		 VARCHAR(50) 
	,@idSolicitante		 NUMERIC(18,0) 
	,@idTipoNotificacion INT 
	,@descripcion		 VARCHAR(MAX) = ''
	,@idEmpresa			 INT = NULL
	,@idSucursal		 INT = NULL
	,@idDepartamento	 INT = NULL
	,@linkBPRO			 VARCHAR(MAX) = NULL
	,@notAdjunto		 VARCHAR(MAX) = NULL 
	,@notAdjuntoTipo	 VARCHAR(500) = NULL
	
	
	
AS
BEGIN
	SET NOCOUNT ON;
	
	BEGIN TRAN TRAN_INS_NOTIFICACION

BEGIN TRY
		DECLARE  @idNot INT
				,@aprobador			 NUMERIC(18,0)
				,@notAgrupacion		 NUMERIC(18,0)
				,@success            BIT
				,@autorizadorMultiEmpresa		 INT 
				,@idAprobacion INT
				

		IF EXISTS(SELECT 1 FROM [Centralizacionv2].[dbo].[DIG_TIPO_NOTIFICACION] WHERE idTipoNotificacion =  @idTipoNotificacion  )
		BEGIN
				SELECT @autorizadorMultiEmpresa = ISNULL(autorizadorMultiEmpresa,0) FROM [Centralizacionv2].[dbo].[DIG_TIPO_NOTIFICACION]  WHERE idTipoNotificacion = @idTipoNotificacion
				--SELECT descripcion FROM [Centralizacionv2].[dbo].[DIG_TIPO_NOTIFICACION]  WHERE idTipoNotificacion = @idTipoNotificacion
				IF(@autorizadorMultiEmpresa = 0)
				BEGIN
					IF((@idEmpresa IS NULL OR @idEmpresa = 0) AND (@idSucursal IS NULL OR @idSucursal = 0) )
					BEGIN
							SELECT  0 not_id, 0 success, -1 result , 'message' = 'Favor de Agregar la Empresa y Sucursal' 
			
					END
					ELSE
					BEGIN
							IF(@idTipoNotificacion = 11 OR @idTipoNotificacion = 16 OR @idTipoNotificacion = 20)
							BEGIN
								IF EXISTS(SELECT 1  FROM 	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
								WHERE	nivel_escalamiento = 0 AND idTipoNotificacion = @idTipoNotificacion
								AND		idEmpresa = @idEmpresa)
								BEGIN
									IF(@idTipoNotificacion = 11)
									BEGIN
									SELECT   @aprobador = usuario_autoriza
											,@notAgrupacion = not_agrupador
									FROM 	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
									WHERE	nivel_escalamiento = 0 AND idTipoNotificacion = @idTipoNotificacion
									AND		idEmpresa = @idEmpresa	
									END
									IF( @idTipoNotificacion = 16 OR @idTipoNotificacion = 20)
									BEGIN
									SELECT   @aprobador = usuario_autoriza
											,@notAgrupacion = not_agrupador
									FROM 	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
									WHERE   idTipoNotificacion = @idTipoNotificacion
									AND		nivel_escalamiento = 0
									AND		idEmpresa = @idEmpresa AND idSucursal = @idSucursal AND idDepartamento = @idDepartamento
									END	
								END
								ELSE
								BEGIN
									SELECT  0 not_id, 0 success, -1 result , 'message' = 'No existe configuración para la Empresa seleccionada. Favor de contactar a sistemas...', 0 apr_id
								END	
							END

							ELSE
							BEGIN
								IF EXISTS(SELECT 1  FROM 	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
								WHERE	nivel_escalamiento = 0 AND idTipoNotificacion = @idTipoNotificacion
								AND		idEmpresa = @idEmpresa AND idSucursal = @idSucursal		)
								BEGIN

									SELECT   @aprobador = usuario_autoriza
											,@notAgrupacion = not_agrupador
									FROM 	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
									WHERE	nivel_escalamiento = 0 AND idTipoNotificacion = @idTipoNotificacion
									AND		idEmpresa = @idEmpresa AND idSucursal = @idSucursal		
								END
								ELSE
								BEGIN
									SELECT  0 not_id, 0 success, -1 result , 'message' = 'No existe configuración para la Empresa y Sucursal seleccionada. Favor de contactar a sistemas...', 0 apr_id
								END	
							END
							
					END
				END
				
				ELSE 
				BEGIN
					--IF(@idTipoNotificacion = 11 OR @idTipoNotificacion = 16 OR @idTipoNotificacion = 20)
					--BEGIN
					
					--			IF(@idTipoNotificacion = 11)
					--			BEGIN
					--			SELECT   @aprobador = usuario_autoriza
					--					,@notAgrupacion = not_agrupador
					--					FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
					--					WHERE	nivel_escalamiento = 0 
					--					AND idTipoNotificacion = @idTipoNotificacion
					--					AND idEmpresa = @idEmpresa
					--			END
					
					--			IF(@idTipoNotificacion = 16 OR @idTipoNotificacion = 20)
					--			BEGIN
					--			SELECT   @aprobador = usuario_autoriza
					--									,@notAgrupacion = not_agrupador
					--							FROM 	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
					--							WHERE   idTipoNotificacion = @idTipoNotificacion
					--							AND		idEmpresa = @idEmpresa AND idSucursal = @idSucursal AND idDepartamento = @idDepartamento
					--			END
							
					--END
					--ELSE
					--BEGIN
					SELECT   @aprobador = usuario_autoriza
									,@notAgrupacion = not_agrupador
							FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
							WHERE	nivel_escalamiento = 0 AND idTipoNotificacion = @idTipoNotificacion

							SET @idEmpresa			  = NULL
							SET @idSucursal		  = NULL

					--END
				END
				
				/*ELSE 
				BEGIN
							SELECT   @aprobador = usuario_autoriza
									,@notAgrupacion = not_agrupador
							FROM	CentralizacionV2.dbo.DIG_ESCALAMIENTO_FLOT 
							WHERE	nivel_escalamiento = 0 AND idTipoNotificacion = @idTipoNotificacion

							SET @idEmpresa			  = NULL
							SET @idSucursal		  = NULL

				
				END*/
						/*Insertar Notificacion*/

						INSERT INTO NOT_NOTIFICACION (
											  not_tipo
											, not_tipo_proceso
											, not_identificador
											, not_nodo
											, not_descripcion
											, not_estatus
											, not_fecha
											, not_link_BPRO
											, not_adjunto
											, not_adjunto_tipo
											, not_agrupacion
											, idEmpresa
											, idSucursal
											, idDepartamento
											)
							VALUES			( 
											  1
											, 1
											, @identificador
											, ''
											, @descripcion
											, 2
											, GETDATE()
											, @linkBPRO
											, @notAdjunto
											, @notAdjuntoTipo
											, @notAgrupacion
											, @idEmpresa
											, @idSucursal
											, @idDepartamento
											)

						SET @idNot  = @@IDENTITY
						SET @success = 1

						--Solicitante (si aprobador = solicitante, solo se inserta aprobador)
						IF(@aprobador != @idsolicitante) 
						BEGIN
							INSERT INTO [dbo].[NOT_APROBACION]
								   ([not_id]
								   ,[apr_nivel]
								   ,[apr_visto]
								   ,[emp_id]
								   ,[apr_fecha]
								   ,[apr_estatus]
								   ,[apr_escalado])
							 VALUES
								   (@idNot
								   ,0
								   ,NULL
								   ,@idsolicitante
								   ,GETDATE()
								   ,1
								   ,-1)
						SET @idAprobacion = SCOPE_IDENTITY()
						END
		   
						--Aprobador

						INSERT INTO [dbo].[NOT_APROBACION]
							   ([not_id]
							   ,[apr_nivel]
							   ,[apr_visto]
							   ,[emp_id]
							   ,[apr_fecha]
							   ,[apr_estatus]
							   ,[apr_escalado])
						 VALUES
							   (@idNot
							   ,0
							   ,NULL
							   ,@aprobador
							   ,GETDATE()
							   ,2
							   ,0)
					
						SET @idAprobacion = SCOPE_IDENTITY()
	
	

						INSERT INTO [Centralizacionv2].[DBO].[BITACORA_PROCESOS](idProceso,descripcion,fecha) 
						VALUES (5,'INS_NOTIFICACION_SP @aprobador:' + CONVERT(VARCHAR(5),@aprobador) ,GETDATE())

						SELECT  @idNot not_id, @success success, 1 result , 'message' = 'La operación se realizó con exito.' , @idAprobacion apr_id

		END
		ELSE
		BEGIN
				SELECT  0 not_id, 0 success, -1 result , 'message' = 'El tipo de notificación enviado no existe...' , 0 apr_id
		END

	COMMIT TRAN TRAN_INS_NOTIFICACION	

	
	
END TRY
BEGIN CATCH

	ROLLBACK TRAN TRAN_INS_NOTIFICACION
	DECLARE @Mensaje  nvarchar(max)
	SELECT @Mensaje = ERROR_MESSAGE()	
	SET @success = 0	
	SELECT   0 not_id, @success success, -1 result, @Mensaje 'message'
 	
	EXECUTE INS_ERROR_SP 'INS_NOTIFICACION_SP', @Mensaje 
	
END CATCH
END
go

