-- =============================================
-- Author:		<Juan Carlos Peralta Sotelo>
-- Create date: <09/06/2020>
-- Description:	<SP que trae inserta la notificacion si va para contraloria>
-- [dbo].[SEL_NOTIFICACION_CORREO_VALE_SP] 10, 251794, 11
-- =============================================
CREATE PROCEDURE [dbo].[SEL_NOTIFICACION_CORREO_VALE_SP] 
	@not_id NUMERIC(18,0)
AS
BEGIN


DECLARE @idNot INT, @idAprobacion INT
DECLARE @idComprobacion INT, @tipoNotificacion INT, @nombreUsuario varchar(max), @correo varchar(max), @subjet varchar(max), @idComprobacionVale varchar(50)

select top 1 @idComprobacion = n.not_identificador, @tipoNotificacion = tn.idTipoNotificacion from [dbo].[NOT_NOTIFICACION] n
inner join [Centralizacionv2].[dbo].[DIG_TIPO_NOTIFICACION] tn on tn.not_agrupador = n.not_agrupacion
where n.not_id = @not_id

IF(@tipoNotificacion = 16)
BEGIN
select 
1 result, 
1 enviaNoti, 
u.usu_nombre + ' ' + u.usu_paterno + ' ' + u.usu_materno as nombreUsuario,
u.usu_correo as correo,
v.idVale,
'Solicitud de Vale Rechazada' as [subject]
from Tramites.Tramite.vales v 
inner join controlaplicaciones.dbo.cat_usuarios u on u.usu_idusuario = v.idEmpleado
where v.id = @idComprobacion
END
ELSE
BEGIN
select 1 result, 0 enviaNoti
END


END
go

