create view [dbo].[CON_MOVDETfij012005] as select * from GAZM_Concentra.dbo.CON_MOVDETfij012005
go

