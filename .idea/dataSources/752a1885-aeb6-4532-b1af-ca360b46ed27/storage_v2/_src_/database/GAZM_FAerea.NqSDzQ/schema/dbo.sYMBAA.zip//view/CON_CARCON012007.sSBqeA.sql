create view [dbo].[CON_CARCON012007] as select * from GAZM_Concentra.dbo.CON_CARCON012007
go

