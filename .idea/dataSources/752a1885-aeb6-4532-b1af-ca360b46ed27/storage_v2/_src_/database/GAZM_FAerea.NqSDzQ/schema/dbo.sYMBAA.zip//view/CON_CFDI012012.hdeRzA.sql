create view [CON_CFDI012012] as select * from [GAZM_Concentra].dbo.[con_cfdi012012]
go

