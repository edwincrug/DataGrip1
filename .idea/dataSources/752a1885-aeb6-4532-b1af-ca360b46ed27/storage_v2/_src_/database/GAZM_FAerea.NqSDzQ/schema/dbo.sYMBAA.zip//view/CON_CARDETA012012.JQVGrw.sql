create view [dbo].[CON_CARDETA012012] as select * from GAZM_Concentra.dbo.CON_CARDETA012012
go

