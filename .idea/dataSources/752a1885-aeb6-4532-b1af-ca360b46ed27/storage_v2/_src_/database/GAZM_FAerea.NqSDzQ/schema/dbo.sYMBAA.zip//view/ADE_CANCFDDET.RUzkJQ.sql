---(4)
create view [dbo].[ADE_CANCFDDET] as select * from GAZM_Concentra.dbo.ADE_CANCFDDET
go

