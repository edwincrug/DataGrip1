
create view [dbo].[PYM_PMA] as select * from GAZM_Concentra.dbo.[PYM_PMA]

go

