create view [dbo].[CON_MOVDETfij012011] as select * from GAZM_Concentra.dbo.CON_MOVDETfij012011
go

