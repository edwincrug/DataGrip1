create view [dbo].[PYM_SEPOMEX] as select * from GAZM_Concentra.dbo.PYM_SEPOMEX
go

