---(12)
create view [dbo].[ADE_ADDENDAS] as select * from GAZM_Concentra.dbo.ADE_ADDENDAS
go

