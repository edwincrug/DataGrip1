create view [dbo].[CON_POL012006] as select * from GAZM_Concentra.dbo.CON_POL012006
go

