Create View [dbo].[cxp_ordenesmasivaslog] as select * from [GAZM_Concentra].dbo.cxp_ordenesmasivaslog
go

