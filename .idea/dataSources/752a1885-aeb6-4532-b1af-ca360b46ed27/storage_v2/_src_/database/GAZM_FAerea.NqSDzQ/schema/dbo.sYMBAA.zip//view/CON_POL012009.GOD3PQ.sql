create view [dbo].[CON_POL012009] as select * from GAZM_Concentra.dbo.CON_POL012009
go

