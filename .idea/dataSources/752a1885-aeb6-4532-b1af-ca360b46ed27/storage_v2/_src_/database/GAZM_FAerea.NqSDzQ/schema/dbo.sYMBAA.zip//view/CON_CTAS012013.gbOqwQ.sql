create view [dbo].[CON_CTAS012013] as select * from GAZM_Concentra.dbo.CON_CTAS012013
go

