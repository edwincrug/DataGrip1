create view [dbo].[PER_AVISOPRIVDEF] as select * from GAZM_Concentra.dbo.PER_AVISOPRIVDEF
go

