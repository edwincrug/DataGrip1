create view [dbo].[SER_PAQhis] as select * from GAZM_Concentra.dbo.SER_PAQhis
go

