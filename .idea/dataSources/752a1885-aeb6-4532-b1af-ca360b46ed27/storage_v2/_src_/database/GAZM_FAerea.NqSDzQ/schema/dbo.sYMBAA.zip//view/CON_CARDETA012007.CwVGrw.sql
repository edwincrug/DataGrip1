create view [dbo].[CON_CARDETA012007] as select * from GAZM_Concentra.dbo.CON_CARDETA012007
go

