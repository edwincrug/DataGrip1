create view [dbo].[CON_CARCON012004] as select * from GAZM_Concentra.dbo.CON_CARCON012004
go

