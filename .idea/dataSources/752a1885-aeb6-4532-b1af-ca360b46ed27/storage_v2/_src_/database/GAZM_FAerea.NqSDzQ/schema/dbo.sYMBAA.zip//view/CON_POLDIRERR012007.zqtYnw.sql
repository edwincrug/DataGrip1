create view [dbo].[CON_POLDIRERR012007] as select * from GAZM_Concentra.dbo.CON_POLDIRERR012007
go

