create view [dbo].[SER_RECALLS] as select * from GAZM_Concentra.dbo.SER_RECALLS
go

