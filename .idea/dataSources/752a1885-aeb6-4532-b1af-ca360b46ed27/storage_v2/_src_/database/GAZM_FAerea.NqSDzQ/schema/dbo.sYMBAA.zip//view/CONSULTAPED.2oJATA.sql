CREATE VIEW [dbo].[CONSULTAPED]  AS  
SELECT     pediuni.[No Pedido] AS PEDIDO, pediuni.Cliente, pediuni.[Fecha Pedido], pediuni.[Tipo Unidad],
PER_PERSONAS.PER_NOMRAZON + ' ' + LTRIM(PER_PERSONAS.PER_PATERNO) + ' ' + LTRIM(PER_PERSONAS.PER_MATERNO)
AS VENDEDOR  
FROM  pediuni 
INNER JOIN   GA_Corporativa.DBO.per_personas  AS PER_PERSONAS ON pediuni.UPE_IDAGTE = PER_PERSONAS.PER_IDPERSONA
go

