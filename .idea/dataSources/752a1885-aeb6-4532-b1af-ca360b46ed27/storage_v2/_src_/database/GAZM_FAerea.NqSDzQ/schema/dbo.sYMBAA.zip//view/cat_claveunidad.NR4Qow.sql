CREATE VIEW [cat_claveunidad] AS Select * From GAZM_Concentra.dbo.cat_claveunidad
go

