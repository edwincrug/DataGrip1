CREATE VIEW [dbo].[cxc_refantypagstatus]
AS
SELECT 
ref_idstatus, ref_nombrecto, ref_descripcion, ref_fechaalta, ref_idusuarioalta, ref_fechamodifica, ref_idusuariomodifica, ref_status
FROM         [GA_Corporativa].dbo.cxc_refantypagstatus
go

