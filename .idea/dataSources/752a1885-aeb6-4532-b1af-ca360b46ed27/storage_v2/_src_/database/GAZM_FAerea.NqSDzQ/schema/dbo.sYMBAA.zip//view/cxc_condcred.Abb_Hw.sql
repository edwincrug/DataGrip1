create view [dbo].[cxc_condcred] as select * from GAZM_Concentra.dbo.cxc_condcred
go

