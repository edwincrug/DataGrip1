create view [dbo].[PAR_LINEASDET] as select * from GAZM_Concentra.dbo.PAR_LINEASDET
go

