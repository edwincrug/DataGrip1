CREATE VIEW [dbo].[ade_CfdiFolioRelacionado] AS SELECT * FROM GAZM_Concentra.dbo.ade_CfdiFolioRelacionado
go

