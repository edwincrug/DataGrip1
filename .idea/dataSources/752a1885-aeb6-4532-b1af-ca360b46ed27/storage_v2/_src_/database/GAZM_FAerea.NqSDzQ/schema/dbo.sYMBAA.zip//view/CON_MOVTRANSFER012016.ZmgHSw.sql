
create view [dbo].[CON_MOVTRANSFER012016] as select * from GAZM_Concentra.dbo.CON_MOVTRANSFER012016

go

