
Create VIEW [dbo].[CXP_ORDENESMASIVAS] as select * from GAZM_Concentra.[dbo].CXP_ORDENESMASIVAS
go

