create view [dbo].[cxp_condcartera] as select * from GAZM_Concentra.dbo.cxp_condcartera
go

