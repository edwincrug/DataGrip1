CREATE VIEW [dbo].[cat_situacionpedidodet]
AS
SELECT spd_idsituacionpedidodet, spd_nombre, spd_nombrecto,spd_fechaalta, spd_usualta,spd_fechamodifica, 
spd_usumodifica, spd_estatus 
FROM [192.168.20.29].PortalRefacciones.dbo.cat_situacionpedidodet

go

