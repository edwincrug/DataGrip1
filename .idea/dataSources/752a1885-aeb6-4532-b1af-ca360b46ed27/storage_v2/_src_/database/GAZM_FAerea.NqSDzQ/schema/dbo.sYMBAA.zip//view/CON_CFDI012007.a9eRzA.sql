create view [CON_CFDI012007] as select * from [GAZM_Concentra].dbo.[con_cfdi012007]
go

