create view [dbo].[CON_POLDIRERR012004] as select * from GAZM_Concentra.dbo.CON_POLDIRERR012004
go

