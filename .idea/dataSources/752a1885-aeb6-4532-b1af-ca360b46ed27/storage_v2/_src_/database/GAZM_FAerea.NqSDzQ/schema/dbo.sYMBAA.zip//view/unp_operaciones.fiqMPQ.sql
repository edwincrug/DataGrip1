CREATE VIEW [dbo].[unp_operaciones]
AS 
SELECT upp_idoperacion, upp_consulta, upp_estatus, upe_idunificacion 
FROM GA_Corporativa.dbo.unp_operaciones
go

