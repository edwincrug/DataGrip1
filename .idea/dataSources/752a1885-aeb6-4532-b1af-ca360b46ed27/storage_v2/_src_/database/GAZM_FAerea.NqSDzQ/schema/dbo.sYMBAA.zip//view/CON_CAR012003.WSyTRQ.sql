create view [dbo].[CON_CAR012003] as select * from GAZM_Concentra.dbo.CON_CAR012003
go

