
create view [dbo].[CON_MOVTRANSFER012005] as select * from GAZM_Concentra.dbo.CON_MOVTRANSFER012005

go

