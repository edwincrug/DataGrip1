CREATE VIEW [dbo].[cat_INPC]
AS
SELECT 
inpc_idinpc, inpc_mes, inpc_anio, inpc_importe, inpc_fechaalta, inpc_usualta, inpc_fechamodifica, inpc_usumodifica, inpc_estatus
FROM         [GA_Corporativa].dbo.CAT_INPC
go

