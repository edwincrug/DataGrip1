create view [dbo].[CON_CARDETACON012007] as select * from GAZM_Concentra.dbo.CON_CARDETACON012007
go

