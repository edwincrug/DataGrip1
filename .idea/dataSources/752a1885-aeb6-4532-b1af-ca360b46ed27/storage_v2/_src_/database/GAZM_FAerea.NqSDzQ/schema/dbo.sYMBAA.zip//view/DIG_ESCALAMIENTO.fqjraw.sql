CREATE VIEW [dbo].[DIG_ESCALAMIENTO]
AS
SELECT 
escalamientoId, Proc_Id, Nodo_Id, emp_idempresa, suc_idsucursal, dep_iddepartaamento, tipo_idtipoorden, Nivel_Escalamiento, Usuario_Autoriza2, Usuario_Autoriza1, Usuario_Autoriza3, Minutos_Escalar
FROM       [Centralizacionv2].dbo.DIG_ESCALAMIENTO
go

