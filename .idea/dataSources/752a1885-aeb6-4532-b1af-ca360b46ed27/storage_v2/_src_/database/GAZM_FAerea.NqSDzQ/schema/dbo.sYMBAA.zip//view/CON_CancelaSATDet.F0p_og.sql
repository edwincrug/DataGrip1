CREATE VIEW [dbo].[CON_CancelaSATDet] AS SELECT * FROM GAZM_Concentra.dbo.CON_CancelaSATDet
go

