CREATE VIEW [dbo].[pre_pedidobackorder]
AS
SELECT pbo_idpedidobackorder, pbo_codigoparte, pbo_cantidad, pbo_estatus, pbo_fecha, pbo_pedidoreferencia
FROM [192.168.20.29].PortalRefacciones.dbo.pre_pedidobackorder

go

