create view [dbo].[CON_POLDIRERR012010] as select * from GAZM_Concentra.dbo.CON_POLDIRERR012010
go

