---(8)
create view [dbo].[ADE_AUXTXTCFD] as select * from GAZM_Concentra.dbo.ADE_AUXTXTCFD
go

