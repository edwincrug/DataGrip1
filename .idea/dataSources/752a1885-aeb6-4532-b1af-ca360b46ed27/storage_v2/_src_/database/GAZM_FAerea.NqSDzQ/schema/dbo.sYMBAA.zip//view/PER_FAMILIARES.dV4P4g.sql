create view [dbo].[PER_FAMILIARES] as select * from GAZM_Concentra.dbo.PER_FAMILIARES
go

