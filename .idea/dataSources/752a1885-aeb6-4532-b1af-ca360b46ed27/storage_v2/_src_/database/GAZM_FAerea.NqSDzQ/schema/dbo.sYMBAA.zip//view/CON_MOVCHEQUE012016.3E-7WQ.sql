
create view [dbo].[CON_MOVCHEQUE012016] as select * from GAZM_Concentra.dbo.CON_MOVCHEQUE012016

go

