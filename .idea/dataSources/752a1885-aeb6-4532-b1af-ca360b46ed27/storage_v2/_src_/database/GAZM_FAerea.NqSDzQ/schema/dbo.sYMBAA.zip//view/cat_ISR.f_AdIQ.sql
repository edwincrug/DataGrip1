CREATE VIEW [dbo].[cat_ISR]
AS
SELECT 
isr_idisr, isr_nombretabla, isr_tipotabla, isr_limiteinferior, isr_limitesuperior, isr_cuotafija, isr_porcentaje, isr_usualta, isr_fechaalta, isr_usumodifica, isr_fechamodifica, isr_estatus
FROM       [GA_Corporativa].dbo.CAT_ISR
go

