-- =============================================
-- Author:		Josué Soto
-- Create date: 29/10/20
-- Description:	Inserta un nuevo registro de amarre de caja
-- =============================================
/*
	Fecha			Autor				Descripción 
	13/11/2020		Uriel Hernandez		Se agrega las altas de evidencia

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [caja].[INS_AMARRECAJA_SP]
		@xmlAnticipos = '',
		@xmlAnticiposAnteriores = '',
		@xmlAnticiposPendientes = '<anticiposPendientes><anticipoPendiente><recibo></recibo><fecha>08/11/2020</fecha><factura></factura><totales>0</totales><hoy>0</hoy><pendiente>0</pendiente><formaPago>0</formaPago></anticipoPendiente></anticiposPendientes>',
		@comentarios = '',
		@idUsuario = 20, 
		@idSucursal = 3,
		@idEmpresa = '',
		@evidencia
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [caja].[INS_AMARRECAJA_SP]
	-- Add the parameters for the stored procedure here
	@xmlAnticipos					XML
	,@xmlAnticiposAnteriores			XML
	,@xmlAnticiposPendientes		XML
	,@comentarios					VARCHAR(MAX)
	,@idUsuario						INT
	,@idSucursal					INT
	,@idEmpresa						INT
	,@evidencia						XML = NULL
	,@err varchar(max) OUTPUT
AS
BEGIN TRY
BEGIN TRAN INS_AMARRECAJA
	SET @err = '';

	IF NOT EXISTS(SELECT 1 FROM [bpro].[Sucursal] WHERE idSucursal = @idSucursal)
		BEGIN
			INSERT INTO [bpro].[Sucursal] VALUES (@idSucursal)
		END

	IF NOT EXISTS(SELECT 1 FROM [seguridad].[Usuario] WHERE idUsuario = @idUsuario)
		BEGIN
			INSERT INTO [seguridad].[Usuario] VALUES (@idUsuario)
		END

	DECLARE @anticipos TABLE (id_row INT IDENTITY(1,1),
								recibo VARCHAR(20),
								fecha VARCHAR(20),
								factura VARCHAR(20),
								ingresosTotales DECIMAL (18,2),
								ingresadosHoy DECIMAL (18,2),
								pendientesIngresar DECIMAL (18,2),
								formaPago VARCHAR(20),
								idBloque VARCHAR(20))
	DECLARE @tablaEvidencia TABLE(
		idEvidencia INT,
		idTipo		INT
	);

		INSERT INTO @anticipos
		SELECT
			ParamValues.col.value('recibo[1]','VARCHAR(20)'),
			ParamValues.col.value('fecha[1]','VARCHAR(20)'),
			ParamValues.col.value('factura[1]','VARCHAR(20)'),
			ParamValues.col.value('totales[1]','DECIMAL (18,2)'),
			ParamValues.col.value('hoy[1]','DECIMAL (18,2)'),
			ParamValues.col.value('pendiente[1]','DECIMAL (18,2)'),
			ParamValues.col.value('formaPago[1]','VARCHAR(20)'),
			'HOY'
			FROM @xmlAnticipos.nodes('anticipos/anticipo') AS ParamValues(col)

		INSERT INTO @anticipos
		SELECT
			ParamValues.col.value('recibo[1]','VARCHAR(20)'),
			ParamValues.col.value('fecha[1]','VARCHAR(20)'),
			ParamValues.col.value('factura[1]','VARCHAR(20)'),
			ParamValues.col.value('totales[1]','DECIMAL (18,2)'),
			ParamValues.col.value('hoy[1]','DECIMAL (18,2)'),
			ParamValues.col.value('pendiente[1]','DECIMAL (18,2)'),
			ParamValues.col.value('formaPago[1]','VARCHAR(20)'),
			'PENDIENTE'
			FROM @xmlAnticiposAnteriores.nodes('anticiposAnteriores/anticipoAnterior') AS ParamValues(col)


	INSERT INTO @anticipos
		SELECT
			ParamValues.col.value('recibo[1]','VARCHAR(20)'),
			ParamValues.col.value('fecha[1]','VARCHAR(20)'),
			ParamValues.col.value('factura[1]','VARCHAR(20)'),
			ParamValues.col.value('totales[1]','DECIMAL (18,2)'),
			ParamValues.col.value('hoy[1]','DECIMAL (18,2)'),
			ParamValues.col.value('pendiente[1]','DECIMAL (18,2)'),
			ParamValues.col.value('formaPago[1]','VARCHAR(20)'),
			'CONTABILIZAR'
			FROM @xmlAnticiposPendientes.nodes('anticiposPendientes/anticipoPendiente') AS ParamValues(col)


	--Generamos el folio
	DECLARE @folio VARCHAR(10)
	SELECT @folio = RIGHT('0000'+ YEAR(GetDate()),4) +  RIGHT('00'+ MONTH(GetDate()),2) + RIGHT('00'+ Day(GetDate()),2) + RIGHT('000'+ CONVERT(VARCHAR(2),Count(1) + 1),2)
		FROM caja.Amarre
		WHERE
			CONVERT (date, fecha) = CONVERT (date, GETDATE())


	--Generamos el token
	DECLARE @token VARCHAR(6)
	SET @token = RIGHT(NEWID(),6)
	WHILE EXISTS (select 1 from caja.Amarre ama WHERE token = @token AND idSucursal = @idSucursal)
		BEGIN
			SET @token = RIGHT(NEWID(),6)
		END


	 
	--Inserta primera parte del encabezado
	INSERT INTO [caja].[Amarre]
           ([idUsuario]
           ,[folio]
           ,[fecha]
           ,[token]
           ,[idSucursal]
		   ,[comentarios])
     VALUES
           (@idUsuario
           ,@folio
           ,GETDATE()
           ,@token
           ,@idSucursal
		   ,@comentarios)


	INSERT INTO [caja].[AmarreDetalle]
           ([folio]
           ,[idBloque]
           ,[recibo]
           ,[fecha]
           ,[factura]
           ,[ingresosTotales]
           ,[ingresadosHoy]
           ,[pendientesIngresar]
           ,[formaPago])
	SELECT
		@folio
		,idBloque
		,recibo
		,CAST(fecha AS DATE)
		,factura
		,ingresosTotales
		,ingresadosHoy
		,pendientesIngresar
		,formaPago
	FROM @anticipos 




	-- Actualiza los totales en el maestro

	UPDATE [caja].[Amarre]
	SET 
      [tihabpc] = (SELECT ISNULL(SUM(ingresadosHoy),0) FROM @anticipos WHERE idBloque = 'PENDIENTE') + (SELECT ISNULL(SUM(ingresadosHoy),0) FROM @anticipos WHERE idBloque = 'HOY') 
      ,[stipd] = (SELECT ISNULL(SUM(pendientesIngresar),0) FROM @anticipos WHERE idBloque = 'PENDIENTE') + (SELECT ISNULL(SUM(pendientesIngresar),0) FROM @anticipos WHERE idBloque = 'HOY') 
      ,[scfdcTotal] = (SELECT SUM(ingresosTotales) FROM @anticipos WHERE idBloque = 'CONTABILIZAR')
      ,[scfdcHoy] = (SELECT ISNULL(SUM(ingresadosHoy),0) FROM @anticipos WHERE idBloque = 'PENDIENTE') + (SELECT ISNULL(SUM(ingresadosHoy),0) FROM @anticipos WHERE idBloque = 'HOY') 
      ,[scfdcPendiente] = (SELECT ISNULL(SUM(pendientesIngresar),0) FROM @anticipos WHERE idBloque = 'PENDIENTE') + (SELECT ISNULL(SUM(pendientesIngresar),0) FROM @anticipos WHERE idBloque = 'HOY')
      ,[dcdcTotal] = 0
      ,[dcdcHoy] = 0
      ,[dcdcPendiente] = 0
      ,[efectivocc] = (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'PENDIENTE' AND formaPago = 'C. EFECTIVO C.') + (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'HOY' AND formaPago = 'C. EFECTIVO C.')
      ,[efectivo] = (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'PENDIENTE' AND formaPago = '02-Efectivo') + (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'HOY' AND formaPago = '02-Efectivo')
      ,[pinpad] = (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'PENDIENTE' AND formaPago in('03- Tarjeta de Crédito - PINPAD', '03- Tarjeta de Débito - PINPAD')) + (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'HOY' AND formaPago in('03- Tarjeta de Crédito - PINPAD', '03- Tarjeta de Débito - PINPAD'))
      ,[tarjeta] = (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'PENDIENTE' AND formaPago in('03- Tarjeta de Crédito', '03- Tarjeta de Débito')) + (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'HOY' AND formaPago in('03- Tarjeta de Crédito', '03- Tarjeta de Débito'))
      ,[chqNominativo] = (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'PENDIENTE' AND formaPago = '04- Cheque nominativo.') + (SELECT ISNULL(SUM(ISNULL(pendientesIngresar,0)),0) FROM @anticipos WHERE idBloque = 'HOY' AND formaPago = '04- Cheque nominativo.')
	WHERE [folio] = @folio

	IF(@evidencia IS NOT NULL)
	BEGIN
		INSERT INTO @tablaEvidencia
		SELECT
			
			ParamValues.col.value('idDocumento[1]','int'),
			ParamValues.col.value('idTipo[1]','int')
		FROM @evidencia.nodes('evidencias/evidencia') AS ParamValues(col)

		INSERT INTO [caja].[AmarreEvidencia]
		SELECT
			@folio
			,idEvidencia
			,idTipo
			,1
		FROM @tablaEvidencia

	END

	SELECT @FOLIO AS folio

	COMMIT TRAN INS_AMARRECAJA

	END TRY

	BEGIN CATCH  
		SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
		 SELECT @err  
		ROLLBACK TRAN INS_AMARRECAJA
	END CATCH



go

