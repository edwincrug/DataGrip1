-- =============================================
-- Author:		AntonioGuerra
-- Create date: 04/11/20
-- Description:	Valida si ya se creo amarre de caja
-- =============================================
/*
	-- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [caja].[SEL_AMARRECAJA_VALIDA_SP] 
	@idUsuario = 20,
	@produccion = 0,
	@fecha='2020/11/18',
	@idSucursal = 2,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [caja].[SEL_AMARRECAJA_VALIDA_SP]
	-- Add the parameters for the stored procedure here
	@idUsuario				INT
	,@produccion			BIT
	,@fecha					DATE
	,@idSucursal			INT
	,@err					varchar(max) OUTPUT
AS
BEGIN
	
	SET @err = ''

	DECLARE  @sucursales TABLE (idSucursal INT, nombre VARCHAR(100), IP VARCHAR(100), BD VARCHAR(100), observaciones VARCHAR(100),idEmpresa INT, estatus INT)
	DECLARE @folio VARCHAR(10) = ''
	DECLARE @hoy DATE,
			@ultimoDiaMes DATE

	SET @hoy = GETDATE()
	SELECT @ultimoDiaMes = CONVERT(DATE,DATEADD(dd,-(DAY(DATEADD(mm,1,@hoy))),DATEADD(mm,1,@hoy)),103) 

	--SELECT @ultimoDiaMes
	
	INSERT INTO @sucursales 
	EXEC [bpro].[SEL_SUCURSALES_SP] 
		@idUsuario = @idUsuario,
		@produccion  = @produccion,
		@err = ''



	IF(@ultimoDiaMes = @fecha)
		BEGIN
			IF((SELECT COUNT(*) FROM caja.Amarre WHERE idSucursal = @idSucursal AND CAST(fecha AS DATE) = @fecha) < 2)
				BEGIN
					SELECT 0 AS existe
				END
			ELSE
				BEGIN
					SELECT 1 AS existe
				END
		END
	ELSE
		BEGIN

			SET @folio = (SELECT folio FROM caja.Amarre WHERE idSucursal = @idSucursal AND CAST(fecha AS DATE) = @fecha)

	
			IF ( @folio != '')

				BEGIN
					SELECT 1 AS existe
				END

			ELSE
				BEGIN
					SELECT 0 AS existe
				END
		END

END

go

