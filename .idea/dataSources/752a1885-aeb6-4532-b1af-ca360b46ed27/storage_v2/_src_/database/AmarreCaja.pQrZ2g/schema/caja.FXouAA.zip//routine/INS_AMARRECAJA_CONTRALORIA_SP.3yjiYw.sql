-- =============================================
-- Author:		Antonio Guerra
-- Create date: 19/11/2020	
-- Description:	Se agrega revision de contraloria
-- =============================================
/*
	Fecha			Autor				Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [caja].[INS_AMARRECAJA_CONTRALORIA_SP]
		@idUsuario = 20,
		@folio = '2020111802',
		@produccion = 0,
		@comentarios = '',
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [caja].[INS_AMARRECAJA_CONTRALORIA_SP]
	-- Add the parameters for the stored procedure here
	@idUsuario			INT,
	@folio				VARCHAR(250),
	@comentarios		VARCHAR(MAX),
	@err varchar(max) OUTPUT
AS
BEGIN TRY
BEGIN TRAN INS_AMARRECAJA_CONTRALORIA
	SET @err = '';

	--Generamos el token
	DECLARE @token VARCHAR(6)
	SET @token = RIGHT(NEWID(),6)
	WHILE EXISTS (select 1 from [caja].[AmarreAprobador] ama WHERE token = @token )
		BEGIN
			SET @token = RIGHT(NEWID(),6)
		END

	INSERT INTO [caja].[AmarreAprobador]
	VALUES(
	@folio
	,@comentarios
	,@idUsuario
	,GETDATE()
	,@token
	)



	COMMIT TRAN INS_AMARRECAJA_CONTRALORIA

	END TRY

	BEGIN CATCH  
		SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
		 SELECT @err  
		ROLLBACK TRAN INS_AMARRECAJA_CONTRALORIA
	END CATCH



go

