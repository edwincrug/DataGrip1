-- =============================================
-- Author:		AntonioGuerra
-- Create date: 04/11/20
-- Description:	Obtiene el desglose completo de un folio por fecha
-- =============================================
/*
	-- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [caja].[SEL_AMARRECAJA_FECHA_SP] @produccion = 0,
	@fecha='2020/11/04/,
	@idSucursal = 3,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [caja].[SEL_AMARRECAJA_FECHA_SP]
	-- Add the parameters for the stored procedure here
	@idUsuario				INT
	,@produccion			BIT
	,@fecha					DATE
	,@idSucursal			INT
	,@err					varchar(max) OUTPUT
AS
BEGIN
	
	SET @err = ''

	DECLARE  @sucursales TABLE (idSucursal INT, nombre VARCHAR(100), IP VARCHAR(100), BD VARCHAR(100), observaciones VARCHAR(100),idEmpresa INT, estatus INT)
	DECLARE  @empresas TABLE (idEmpresa INT, nombre VARCHAR(100),observaciones VARCHAR(100),  estatus INT)
	DECLARE @folio VARCHAR(10)
	
	INSERT INTO @sucursales 
	EXEC [bpro].[SEL_SUCURSALES_SP] 
		@idUsuario = @idUsuario,
		@produccion  = @produccion,
		@err = ''

	INSERT INTO @empresas 
	EXEC [bpro].[SEL_EMPRESAS_SP]
		@idUsuario = @idUsuario,
		@produccion  = @produccion,
		@err = ''

	--SELECT * FROM @sucursales
	--select * from @empresas

    -- Encabezado y datos generales

	SET @folio = (SELECT folio FROM caja.Amarre WHERE idSucursal = @idSucursal AND CAST(fecha AS DATE) = @fecha)


	SELECT A.[idUsuario] --Datos del usuario
		  ,primerNombre + ISNULL(U.segundoNombre,'') + ' ' + U.primerApellido + ISNULL(U.segundoNombre,'') nombreUsuario
		  ,A.[folio]
		  ,A.[fecha]
		  ,A.[token]
		  ,(SELECT idEmpresa FROM @sucursales WHERE idSucursal = A.idSucursal) AS idEmpresa
		  ,(SELECT observaciones FROM @empresas WHERE idEmpresa = (SELECT idEmpresa FROM @sucursales WHERE idSucursal = A.idSucursal)) empresa
		  ,[idSucursal] -- Datos de la sucursal
		  ,(SELECT observaciones FROM @sucursales WHERE idSucursal = A.idSucursal) sucursal
		  ,[tihabpc]
		  ,[stipd]
		  ,[scfdcTotal]
		  ,[scfdcHoy]
		  ,[scfdcPendiente]
		  ,[dcdcTotal]
		  ,[dcdcHoy]
		  ,[dcdcPendiente]
		  ,[efectivocc]
		  ,[efectivo]
		  ,[pinpad]
		  ,[tarjeta]
		  ,[chqNominativo]
		  ,A.comentarios
		  ,AA.comentarios as comentariosContraloria
		  ,(SELECT primerNombre + ISNULL(segundoNombre,'') + ' ' + primerApellido + ISNULL(segundoNombre,'') FROM Seguridad.catalogo.usuario WHERE id = AA.idUsuario)  nombreUsuarioContraloria
		  ,AA.fecha fechaContraloria
		  ,AA.token tokenContraloria
	  FROM [caja].[Amarre] A
	  INNER JOIN Seguridad.catalogo.usuario U ON U.id = A.idUsuario
	  LEFT JOIN [caja].[AmarreAprobador] AA ON AA.folio = A.folio
	  WHERE A.folio = @folio

	  SELECT 
		folio
		,idBloque
		,recibo AS CCP_IDDOCTO
		,FECHA AS MOV_FECHOPE
		,factura AS factura
		,ingresosTotales AS MOV_DEBE
		,ingresadosHoy AS ABONO
		,pendientesIngresar AS PENDIENTE
		,LTRIM(RTRIM(formaPago)) AS CONCEPTO
	FROM [caja].[AmarreDetalle]
	WHERE folio = @folio
	ORDER BY fecha DESC

	SELECT 
		idFileServer,
		idTipo
	FROM caja.AmarreEvidencia
	WHERE folio = @folio
	and activo = 1


	
END

go

