-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION documento.urlFileServer
(
	@idFileServer int
)
RETURNS varchar(max)
AS
BEGIN
	 DECLARE @urlFile VARCHAR(MAX), @host VARCHAR(MAX);

	 SELECT  @urlFile = [path] FROM documento.documento WHERE idDocumento = @idFileServer;
	 SELECT @host = [valor] FROM [Common].[configuracion].[Configuracion] WHERE [nombre] = 'fileServer' AND [activo] = 1

	 RETURN @host + @urlFile;
END
go

