
-- =============================================  
-- Author:  Uriel Hernandez
-- Create date: 09/11/2020 
-- Description: Busca documentos de acuerdo al xml.
-- Test:
/*
    [documento].[SEL_DOCUMENTOS_BYID_SP] @documentos = '<documentos><documento><idDocumento>280</idDocumento></documento><documento><idDocumento>281</idDocumento></documento></documentos>' 
*/
-- ============== Versionamiento ================  
/*  
 Fecha                       Autor                  Descripción  
   
 
*/
CREATE PROCEDURE [documento].[SEL_DOCUMENTOS_BYID_SP]
    @documentos xml,
    @err		varchar(500) = NULL	OUTPUT
AS

    SELECT 
		idDocumento, 
		[path], 
		nombreOriginal, 
		nombre, 
		idUsuario, 
		fechaCreacion, 
		ultimaActualizacion, 
		idAplicacion, 
		titulo, 
		size, 
		tipo, 
		idModulo, 
		activo, 
		descripcion
		,(U.PrimerNombre + ' ' + ISNULL(U.SegundoNombre,'') + ' ' + ISNULL(U.primerApellido,'') + ' ' + ISNULL(U.segundoApellido,'')) as nombreUsuario
      FROM documento.Documento D
	LEFT JOIN Seguridad.catalogo.Usuario U ON U.Id = D.idUsuario
	  WHERE idDocumento IN (SELECT ParamValues.col.value('idDocumento[1]','int')
								FROM @documentos.nodes('documentos/documento') AS ParamValues(col))
go

