  
-- =============================================    
-- Author:  Uriel Hernandez
-- Create date: 09/11/2020   
-- Description: Busca los datos de un modulo    
-- Test:  
-- [documento].[SEL_MODULO_SP] 11, 6  
-- ============== Versionamiento ================    
/*    
 Fecha                       Autor                  Descripción    
     
   
*/  
  
CREATE PROCEDURE [documento].[SEL_MODULO_SP]  
    @idAplicacionSeguridad int,  
    @idModuloSeguridad int,  
    @err  varchar(500) = NULL OUTPUT  
  
AS  
    SELECT M.idModulo, M.estructuraPath, M.nombre FROM documento.moduloDocumentoSeguridad MS  
    INNER JOIN documento.Modulo M ON M.idModulo = MS.idModuloDocumento  
    WHERE MS.idAplicacionSeguridad = @idAplicacionSeguridad AND MS.idModuloSeguridad = @idModuloSeguridad
go

