
-- =============================================  
-- Author:  Uriel Hernandez
-- Create date: 09/11/2020 
-- Description: Inserta los metadatos de un documento  
-- Test:
/*
    [documento].[INS_DOCUMENTO_SP] @documentos = '<documentos><documento><path>\1\2\fee84eab2488e425bdfe0fe6fc2e94a0.png</path><nombreOriginal>0ac94a489b6a6f0c5409c275911c9350.png</nombreOriginal><nombre>fee84eab2488e425bdfe0fe6fc2e94a0.png</nombre><idUsuario>1</idUsuario><idAplicacion>1</idAplicacion><idModulo>1</idModulo><titulo>0ac94a489b6a6f0c5409c275911c9350.png</titulo><size>708026</size><tipo>image/png</tipo><descripcion>Mi descripcion</descripcion></documento></documentos>' 
*/
-- ============== Versionamiento ================  
/*  
 Fecha                       Autor                  Descripción  
   
 
*/

CREATE PROCEDURE [documento].[INS_DOCUMENTO_SP]
    @documentos XML,
    @err		varchar(500) = NULL	OUTPUT
-- add more stored procedure parameters here
AS


    INSERT INTO documento.documento
    ([path],
    nombreOriginal,
    nombre,
    idUsuario,
    fechaCreacion,
    ultimaActualizacion,
    idAplicacion,
    idModulo,
    titulo,
    size,
    tipo,
    activo,
    descripcion
    )
    SELECT ParamValues.col.value('path[1]','varchar(max)'), 
            ParamValues.col.value('nombreOriginal[1]','varchar(max)'),
            ParamValues.col.value('nombre[1]','varchar(max)'), 
            ParamValues.col.value('idUsuario[1]','int'), 
            GETDATE(),
            GETDATE(), 
            ParamValues.col.value('idAplicacion[1]','int'), 
            ParamValues.col.value('idModulo[1]','int'),
            ParamValues.col.value('titulo[1]','varchar(max)'),
            ParamValues.col.value('size[1]','int'), 
            ParamValues.col.value('tipo[1]','varchar(max)'),
            1, 
            ParamValues.col.value('descripcion[1]','varchar(max)')

			FROM @documentos.nodes('documentos/documento') AS ParamValues(col)

    SELECT idDocumento, [path], nombreOriginal, nombre, idUsuario, fechaCreacion, ultimaActualizacion, idAplicacion, titulo, size, tipo, idModulo, activo, descripcion
      FROM documento.Documento WHERE nombre  IN (SELECT ParamValues.col.value('nombre[1]','varchar(max)')
			FROM @documentos.nodes('documentos/documento') AS ParamValues(col))
go

