-- =============================================  
-- Author:  Uriel Hernandez
-- Create date: 09/11/2020 
-- Description: Busca los datos de un documento por medio de un idDocumento.  
-- Test:
-- [documento].[SEL_DOCUMENTO_BYID_SP] 111
-- ============== Versionamiento ================  
/*  
 Fecha                       Autor                  Descripción  
   
 
*/
CREATE PROCEDURE [documento].[SEL_DOCUMENTO_BYID_SP]
@idDocumento int,
@err		varchar(500) = NULL	OUTPUT
   
AS

   SELECT  idDocumento, [path], nombreOriginal, nombre, idUsuario, fechaCreacion, ultimaActualizacion, idAplicacion, titulo, size, tipo, idModulo, activo, descripcion
    FROM documento.documento WHERE idDocumento = @idDocumento
go

