----------REFACCIONES

--create view PAR_PARTES as select * from GAAU_Concentra.dbo.PAR_PARTES
--go
--create view PAR_PLANTA as select * from GAAU_Concentra.dbo.PAR_PLANTA
--go

----------PROSPECCION Y MARKETING

create view [dbo].[PER_FAMILIARES] as select * from GAAU_Concentra.dbo.PER_FAMILIARES
go

