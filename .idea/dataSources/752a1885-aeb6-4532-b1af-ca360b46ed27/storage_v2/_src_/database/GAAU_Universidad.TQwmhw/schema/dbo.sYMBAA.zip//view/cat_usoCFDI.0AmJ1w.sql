CREATE VIEW [dbo].[cat_usoCFDI] AS Select * From GAAU_Concentra.dbo.cat_usoCFDI
go

