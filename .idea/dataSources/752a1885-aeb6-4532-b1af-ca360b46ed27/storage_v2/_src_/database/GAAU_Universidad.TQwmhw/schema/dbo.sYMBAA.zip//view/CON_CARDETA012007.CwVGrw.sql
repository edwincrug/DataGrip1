create view 	[dbo].[CON_CARDETA012007]	as select * from GAAU_Concentra.dbo.CON_CARDETA012007
go

