create view [dbo].[PAR_ALTERNOS] as select * from GAAU_Concentra.dbo.PAR_ALTERNOS
go

