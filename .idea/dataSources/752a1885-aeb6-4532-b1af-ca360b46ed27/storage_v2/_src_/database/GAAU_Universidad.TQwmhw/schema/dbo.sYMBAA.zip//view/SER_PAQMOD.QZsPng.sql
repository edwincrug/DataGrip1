create view [dbo].[SER_PAQMOD] as select * from GAAU_Concentra.dbo.SER_PAQMOD
go

