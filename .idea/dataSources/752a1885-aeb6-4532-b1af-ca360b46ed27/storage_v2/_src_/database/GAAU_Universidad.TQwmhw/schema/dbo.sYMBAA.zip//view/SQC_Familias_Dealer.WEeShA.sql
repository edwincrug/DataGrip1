create view [dbo].[SQC_Familias_Dealer] as select * from GAAU_Concentra.dbo.SQC_Familias_Dealer
go

