create view 	[dbo].[CON_POL012010]	 as select * from GAAU_Concentra.dbo.CON_POL012010
go

