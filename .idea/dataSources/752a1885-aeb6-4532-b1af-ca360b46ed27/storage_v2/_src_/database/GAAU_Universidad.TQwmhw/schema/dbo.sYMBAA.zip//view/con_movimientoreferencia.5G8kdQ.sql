CREATE VIEW [dbo].[con_movimientoreferencia] AS SELECT * From GAAU_Concentra.dbo.con_movimientoreferencia
go

