create view 	[dbo].[CON_CARCON012012]	as select * from GAAU_Concentra.dbo.CON_CARCON012012
go

