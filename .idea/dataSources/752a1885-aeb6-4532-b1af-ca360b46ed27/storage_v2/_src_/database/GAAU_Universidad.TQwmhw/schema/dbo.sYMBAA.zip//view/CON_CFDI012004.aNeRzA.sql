create view [dbo].[CON_CFDI012004] as select * from [GAAU_Concentra].dbo.[con_cfdi012004]
go

