create view [dbo].[CON_CFDI012012] as select * from [GAAU_Concentra].dbo.[con_cfdi012012]
go

