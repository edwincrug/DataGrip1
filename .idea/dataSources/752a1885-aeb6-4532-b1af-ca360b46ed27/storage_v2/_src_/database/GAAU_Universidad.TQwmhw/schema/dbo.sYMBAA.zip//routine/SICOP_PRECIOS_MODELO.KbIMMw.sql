CREATE  Proc SICOP_PRECIOS_MODELO
@Modelo NvarChar(15),
@Año nvarchar(4)
As
SELECT
B.Precio_Contado AS Precio,
B.Precio_Financiado,
A.Seguro,
A.Seguro_Vida,
A.Seguro_Desempleo,
a.Tasa_Tenencia,
a.Cotiza_Dolar
From
Producto AS A,
SICOP_PRECIOS_PRODUCTO As B
Where
A.C_Clave=b.C_Producto And
B.[Año]=@Año And
A.C_Clave=@Modelo
go

