create view [CON_GCFDI012005] as select * from [GAAU_Concentra].dbo.[CON_GCFDI012005]
go

