create view [CON_GCFDI012009] as select * from [GAAU_Concentra].dbo.[CON_GCFDI012009]
go

