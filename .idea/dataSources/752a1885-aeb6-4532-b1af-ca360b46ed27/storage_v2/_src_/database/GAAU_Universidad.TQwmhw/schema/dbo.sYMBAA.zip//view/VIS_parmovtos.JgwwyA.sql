CREATE VIEW VIS_parmovtos AS Select 'GAAU_Cuautitlan' as Base,* FROM GAAU_Cuautitlan.dbo.par_movtos UNION ALL Select 'GAAU_Pedregal' as Base,* FROM GAAU_Pedregal.dbo.par_movtos UNION ALL Select 'GAAU_Universidad' as Base,* FROM GAAU_Universidad.dbo.par_movtos UNION ALL select 'GAAU_Universidad' as Base,* FROM per_parmovtos
go

