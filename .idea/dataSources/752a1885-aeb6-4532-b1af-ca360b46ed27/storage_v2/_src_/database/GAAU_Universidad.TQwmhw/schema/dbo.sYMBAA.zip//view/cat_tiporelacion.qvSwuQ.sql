CREATE VIEW [dbo].[cat_tiporelacion] AS Select * From GAAU_Concentra.dbo.cat_tiporelacion
go

