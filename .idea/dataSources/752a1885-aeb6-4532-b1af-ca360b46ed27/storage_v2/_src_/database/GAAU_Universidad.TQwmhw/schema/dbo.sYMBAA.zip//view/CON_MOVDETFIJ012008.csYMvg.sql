create view 	[dbo].[CON_MOVDETFIJ012008]	 as select * from GAAU_Concentra.dbo.CON_MOVDETFIJ012008
go

