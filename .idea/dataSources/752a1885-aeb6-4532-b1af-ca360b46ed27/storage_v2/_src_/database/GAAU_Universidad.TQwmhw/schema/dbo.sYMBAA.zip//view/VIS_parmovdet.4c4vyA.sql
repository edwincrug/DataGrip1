CREATE VIEW VIS_parmovdet AS Select 'GAAU_Cuautitlan' as BaseD,* FROM GAAU_Cuautitlan.dbo.Par_movdet UNION ALL Select 'GAAU_Pedregal' as BaseD,* FROM GAAU_Pedregal.dbo.Par_movdet UNION ALL Select 'GAAU_Universidad' as BaseD,* FROM GAAU_Universidad.dbo.Par_movdet UNION ALL select 'GAAU_Universidad' as BaseD,* FROM per_parmovdet
go

