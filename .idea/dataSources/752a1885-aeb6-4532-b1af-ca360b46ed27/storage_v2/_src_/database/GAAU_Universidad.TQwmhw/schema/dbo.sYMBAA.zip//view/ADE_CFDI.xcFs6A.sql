create view [dbo].[ADE_CFDI] as select * from GAAU_Concentra.dbo.ADE_CFDI
go

