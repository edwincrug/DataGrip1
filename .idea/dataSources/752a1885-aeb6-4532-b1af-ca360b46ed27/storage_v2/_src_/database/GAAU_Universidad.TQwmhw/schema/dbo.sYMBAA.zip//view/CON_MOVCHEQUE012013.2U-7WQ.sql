
create view [dbo].[CON_MOVCHEQUE012013] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012013

go

