
CREATE VIEW [dbo].[par_pedmostenc]
AS
SELECT pmm_idpedmostenc, pmm_nopedmost, pmm_tipomov, pmm_idvendedor, pmm_fechaalta, pmm_idalmacen, pmm_tipoiva, pmm_total, ucu_idcotizacion, pmm_estatus, pmm_idusuarioalta, pmm_fechamodifica, pmm_tipoprecio, pmm_iva, pmm_idusuariomodifica, cep_idestatuspedmost, ucu_idcotizacionpost, pmm_afprecio, pmm_fact, pmm_cveusocfdi,pmm_idcliente,pmm_remision FROM CUENTASPORCOBRAR.dbo.par_pedmostenc
 
------
go

