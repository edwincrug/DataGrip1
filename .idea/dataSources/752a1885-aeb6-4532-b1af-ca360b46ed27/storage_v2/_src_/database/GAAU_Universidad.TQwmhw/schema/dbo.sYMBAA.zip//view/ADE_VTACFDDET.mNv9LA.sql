create view [dbo].[ADE_VTACFDDET] as select * from GAAU_Concentra.dbo.ADE_VTACFDDET
go

