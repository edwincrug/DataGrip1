create view 	[dbo].[CON_CAR012007]	as select * from GAAU_Concentra.dbo.CON_CAR012007
go

