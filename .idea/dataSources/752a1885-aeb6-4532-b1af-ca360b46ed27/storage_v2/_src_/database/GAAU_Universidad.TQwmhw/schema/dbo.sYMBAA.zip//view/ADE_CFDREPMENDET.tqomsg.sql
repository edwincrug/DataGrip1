create view [dbo].[ADE_CFDREPMENDET] as select * from GAAU_Concentra.dbo.ADE_CFDREPMENDET
go

