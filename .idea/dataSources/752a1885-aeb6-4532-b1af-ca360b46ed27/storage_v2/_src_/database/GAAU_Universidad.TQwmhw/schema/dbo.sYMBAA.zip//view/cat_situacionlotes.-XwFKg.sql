CREATE VIEW [dbo].[cat_situacionlotes] AS 
SELECT
slt_idsituacion, slt_nombre, slt_nombrecto, slt_fechaalta, slt_usualta, slt_fechamodifica, slt_usumodifica, slt_estatus
FROM         cuentasxpagar.dbo.cat_situacionlotes
go

