CREATE  PROCEDURE SICOP_UP_PROS_CAMBIA_EJECUTIVO_GRUPO
  @p_str_ejecutivo_nuevo  NVARCHAR(15),
 @p_str_clave_ejecutivo_actual NVARCHAR(15),
 @p_str_clave_prospecto NVARCHAR(15),
 @p_str_clave_grupo NVARCHAR(15)
 as
 Update
 Prospecto
 SET
 C_Promotor = @p_str_ejecutivo_nuevo,
 ClaveGrupoTrabajo=@p_str_clave_grupo,
 [Registro nuevo] = 1,
 Pre_pozo=0,
 Dias_para_pozo=Null,
 Fecha_pre_pozo = Null
 Where
 C_Promotor= @p_str_clave_ejecutivo_actual  And
 C_clave= @p_str_clave_prospecto
go

