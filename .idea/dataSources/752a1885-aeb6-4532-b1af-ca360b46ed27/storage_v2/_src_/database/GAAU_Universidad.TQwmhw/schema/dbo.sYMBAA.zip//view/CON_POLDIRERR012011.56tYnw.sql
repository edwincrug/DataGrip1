create view 	[dbo].[CON_POLDIRERR012011]	 as select * from GAAU_Concentra.dbo.CON_POLDIRERR012011
go

