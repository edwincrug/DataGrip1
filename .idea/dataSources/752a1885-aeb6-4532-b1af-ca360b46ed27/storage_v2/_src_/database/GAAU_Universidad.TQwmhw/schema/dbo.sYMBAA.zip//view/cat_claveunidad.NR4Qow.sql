CREATE VIEW [dbo].[cat_claveunidad] AS Select * From GAAU_Concentra.dbo.cat_claveunidad
go

