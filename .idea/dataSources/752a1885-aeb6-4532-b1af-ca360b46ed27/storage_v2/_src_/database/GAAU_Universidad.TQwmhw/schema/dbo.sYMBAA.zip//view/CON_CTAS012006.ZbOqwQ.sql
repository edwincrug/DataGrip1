create view 	[dbo].[CON_CTAS012006]	 as select * from GAAU_Concentra.dbo.CON_CTAS012006
go

