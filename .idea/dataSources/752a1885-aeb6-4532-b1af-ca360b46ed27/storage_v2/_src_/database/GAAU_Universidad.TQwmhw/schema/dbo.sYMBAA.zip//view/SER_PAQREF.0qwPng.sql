create view [dbo].[SER_PAQREF] as select * from GAAU_Concentra.dbo.SER_PAQREF
go

