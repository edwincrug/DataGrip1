CREATE VIEW [dbo].[cat_formapago] AS Select * From GAAU_Concentra.dbo.cat_formapago

