
create view [dbo].[CON_MOVTRANSFER012008] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012008

go

