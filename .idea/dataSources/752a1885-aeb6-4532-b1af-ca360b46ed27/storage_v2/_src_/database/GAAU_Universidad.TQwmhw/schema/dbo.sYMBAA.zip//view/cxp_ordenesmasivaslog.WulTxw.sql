Create View [dbo].[cxp_ordenesmasivaslog] as select * from [GAAU_Concentra].dbo.cxp_ordenesmasivaslog
go

