create view [dbo].[SQC_Servicio_Todos] as select * from GAAU_Concentra.dbo.SQC_Servicio_Todos
go

