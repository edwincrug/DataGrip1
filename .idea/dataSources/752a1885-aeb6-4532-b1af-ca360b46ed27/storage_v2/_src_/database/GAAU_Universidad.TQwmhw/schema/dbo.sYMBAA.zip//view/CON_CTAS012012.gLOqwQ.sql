create view 	[dbo].[CON_CTAS012012]	 as select * from GAAU_Concentra.dbo.CON_CTAS012012
go

