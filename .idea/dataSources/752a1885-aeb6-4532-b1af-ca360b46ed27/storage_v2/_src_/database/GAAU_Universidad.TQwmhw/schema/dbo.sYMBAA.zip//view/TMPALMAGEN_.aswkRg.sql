create view [dbo].[TMPALMAGEN$] as 
(select Numparte, COUNT(1) veces from tmpAlmacen$ where ALM_IDALMA = 'gen' group by numparte having COUNT(1) > 1)
go

