create view [CON_GCFDI012004] as select * from [GAAU_Concentra].dbo.[CON_GCFDI012004]
go

