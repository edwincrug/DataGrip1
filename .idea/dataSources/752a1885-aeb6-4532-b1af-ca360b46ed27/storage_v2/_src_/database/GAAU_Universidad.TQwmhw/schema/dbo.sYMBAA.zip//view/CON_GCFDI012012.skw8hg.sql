create view [CON_GCFDI012012] as select * from [GAAU_Concentra].dbo.[CON_GCFDI012012]
go

