
create view [dbo].[CON_MOVTRANSFER012004] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012004

go

