create view [dbo].[SQC_Pro_Maestra_Nov] as select * from GAAU_Concentra.dbo.SQC_Pro_Maestra_Nov
go

