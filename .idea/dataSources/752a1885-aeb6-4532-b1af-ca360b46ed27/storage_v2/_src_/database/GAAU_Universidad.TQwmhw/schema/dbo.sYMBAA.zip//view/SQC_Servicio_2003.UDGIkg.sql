create view [dbo].[SQC_Servicio_2003] as select * from GAAU_Concentra.dbo.SQC_Servicio_2003
go

