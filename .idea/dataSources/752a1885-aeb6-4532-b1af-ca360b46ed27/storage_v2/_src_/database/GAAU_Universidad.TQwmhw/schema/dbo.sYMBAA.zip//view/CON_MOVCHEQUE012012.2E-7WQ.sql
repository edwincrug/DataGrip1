
create view [dbo].[CON_MOVCHEQUE012012] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012012

go

