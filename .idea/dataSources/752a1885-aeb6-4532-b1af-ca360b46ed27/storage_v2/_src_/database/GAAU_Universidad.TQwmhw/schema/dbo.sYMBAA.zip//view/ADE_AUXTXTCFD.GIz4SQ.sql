create view [dbo].[ADE_AUXTXTCFD] as select * from GAAU_Concentra.dbo.ADE_AUXTXTCFD
go

