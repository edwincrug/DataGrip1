create view 	[dbo].[CON_MOVDETFIJ012007]	 as select * from GAAU_Concentra.dbo.CON_MOVDETFIJ012007
go

