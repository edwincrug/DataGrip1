CREATE VIEW VSComunicacionCliente AS SELECT PER_IDPERSONA as IdCliente , ISNULL(PER_TELEFONO1, '') as TelefonoCasa , ISNULL(PER_EXT1, '') as ExtensionCasa , ISNULL(PER_TELEFONO2, '') as TelefonoTrabajo , ISNULL(PER_EXT2, '') as ExtensionTrabajo , ISNULL(PER_TELCELULAR, '') as Celular , ISNULL(PER_EMAIL, '') as EmailCasa , ISNULL(PER_EMAIL2, '') as EmailTrabajo , ISNULL(PER_FAX, '') as Fax FROM GA_Corporativa.dbo.PER_PERSONAS
go

