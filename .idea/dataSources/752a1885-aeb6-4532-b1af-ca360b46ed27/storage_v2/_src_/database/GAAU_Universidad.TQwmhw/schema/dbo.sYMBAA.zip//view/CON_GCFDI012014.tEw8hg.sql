create view [CON_GCFDI012014] as select * from [GAAU_Concentra].dbo.[CON_GCFDI012014]
go

