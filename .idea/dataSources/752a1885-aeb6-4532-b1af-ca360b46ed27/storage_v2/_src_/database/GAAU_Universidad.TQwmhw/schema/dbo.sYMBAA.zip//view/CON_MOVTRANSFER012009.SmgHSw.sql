
create view [dbo].[CON_MOVTRANSFER012009] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012009

go

