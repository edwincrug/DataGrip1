
create view [dbo].[CON_MOVCHEQUE012006] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012006

go

