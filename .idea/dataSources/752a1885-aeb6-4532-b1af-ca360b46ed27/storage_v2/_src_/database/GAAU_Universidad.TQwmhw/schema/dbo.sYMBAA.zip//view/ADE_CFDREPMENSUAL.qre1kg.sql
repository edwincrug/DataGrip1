create view [dbo].[ADE_CFDREPMENSUAL] as select * from GAAU_Concentra.dbo.ADE_CFDREPMENSUAL
go

