create view [dbo].[CDFPP] as 
(select coz_idpersona,coz_iddocto,max(convert(datetime,coz_fechprompag,103)) AS COZ_FECHPROMPAG, COZ_IMPCOBRADO,COUNT(1) AS VECES
from CXC_RUTACOBRANZA 
where coz_fechprompag <> '' and coz_saldo <> coz_impcobrado
group by coz_idpersona,coz_iddocto,coz_fechprompag,COZ_IMPCOBRADO)
go

