create view [dbo].[SQC_Familias] as select * from GAAU_Concentra.dbo.SQC_Familias
go

