create view [dbo].[PAR_LINEASDET] as select * from GAAU_Concentra.dbo.PAR_LINEASDET
go

