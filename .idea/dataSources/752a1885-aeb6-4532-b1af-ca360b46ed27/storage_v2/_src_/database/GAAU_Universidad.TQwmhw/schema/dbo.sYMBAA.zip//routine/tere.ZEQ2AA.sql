
CREATE PROCEDURE tere @IdCia varchar(20), @sServer varchar(100), @sBD varchar(100) AS
DECLARE @Tabla varchar(255), @NvoVtas varchar(100), @NvoCan varchar(100), @SvoVtas varchar(100), @SvoCan varchar(100)
, @Param varchar(100), @Veh varchar(100)
, @Origen varchar(20), @Status varchar(20), @Fecha varchar(10), @pardescr varchar(100), @Catalogo varchar(100), @Qty int
, @SQL varchar(100)

if @sServer = '[192.168.20.29]'  
   begin
   SET @Tabla =  @sBD + '.dbo.' + 'xgaIRVQ'
   set @NvoVtas = @sBD + '.dbo.' + 'ade_vtafi f'
   set @Param = @sBD + '.dbo.' + 'PNC_PARAMETR p'
   set @Veh = @sBD + '.dbo.' + 'SER_VEHICULO v'
   end
else
   Begin
   SET @Tabla = @sServer + '.' + @sBD + '.dbo.' + 'xgaIRVQ'
   set @NvoVtas = @sServer + '.' + @sBD + '.dbo.' + 'ade_vtafi f'
   set @Param = @sServer + '.' + @sBD + '.dbo.' + 'PNC_PARAMETR p'
   set @Veh = @sServer + '.' + @sBD + '.dbo.' + 'SER_VEHICULO v'
   end

set @SQL = 'NUEVOS' + ',' + 'FACTURADA' + ', f.VTE_FECHDOCTO, p.par_descrip1, isnull(VEH_TIPOAUTO,''), 1 from ' + @NvoVtas

--exec ('Select * from ' + @Tabla)

/*
-- exec tere '90','[192.168.20.29]', 'GAAA_Azcapo'
drop proc tere
go
*/
go

