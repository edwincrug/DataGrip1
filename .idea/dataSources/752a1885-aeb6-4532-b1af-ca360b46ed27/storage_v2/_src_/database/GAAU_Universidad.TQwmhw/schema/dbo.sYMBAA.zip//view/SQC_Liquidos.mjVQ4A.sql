create view [dbo].[SQC_Liquidos] as select * from GAAU_Concentra.dbo.SQC_Liquidos
go

