-----------------------------------------
CREATE VIEW [dbo].[uni_anticiposweb] 
AS   
SELECT   
uaw_idanticipoweb, uaw_idconceptopago, uaw_importe, uaw_descripcion, uaw_noserie, uaw_idpersonatercero, uaw_estatus, ucn_idcotizadetalle, cea_idestatusanticiposweb, uaw_fechaalta, uaw_idusuarioalta, ctc_idtipoorden, uaw_saldo, UAW_PRECIO, FACTURA, UAW_FOLIOORDENCOMPRAOT, ucn_idcotizadetallepost, CEA_IdEstatusAdicionales, UAW_TIPOOPERACIONOTR, UAW_IDPEDIDOOTR, UAW_IDDOCTO, UAW_IDPEDIDOVAR, UAW_TipoTramite, uaw_antaplicado, STR_IDSUBTRAM, pmd_estatusautorizacion,cfr_IdDocto,uaw_cveusocfdi,uaw_idcliente,uaw_oc
FROM cuentasporcobrar.dbo.uni_anticiposweb

go

