create view 	[dbo].[CON_POLDIRERR012005]	 as select * from GAAU_Concentra.dbo.CON_POLDIRERR012005
go

