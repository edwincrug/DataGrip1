CREATE VIEW [dbo].[ade_cfditimbrado] AS SELECT * FROM GAAU_Concentra.dbo.ade_cfditimbrado
go

