create view [dbo].[PER_AVISOPRIVDEF] as select * from GAAU_Concentra.dbo.PER_AVISOPRIVDEF
go

