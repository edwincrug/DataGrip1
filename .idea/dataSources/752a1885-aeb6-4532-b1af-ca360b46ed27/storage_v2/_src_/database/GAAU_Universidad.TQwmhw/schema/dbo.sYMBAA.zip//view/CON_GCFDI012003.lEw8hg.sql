create view [CON_GCFDI012003] as select * from [GAAU_Concentra].dbo.[CON_GCFDI012003]
go

