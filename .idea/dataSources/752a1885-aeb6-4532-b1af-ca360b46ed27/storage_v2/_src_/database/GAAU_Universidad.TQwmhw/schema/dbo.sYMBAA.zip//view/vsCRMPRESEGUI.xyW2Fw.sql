
CREATE view [dbo].[vsCRMPRESEGUI]  as   
select rel_fechallamada, rel_horallamada, rel_stataccion, rel_fechope, PER_IDPERSONA, PER_NOMRAZON + ' ' + PER_PATERNO + ' ' + PER_MATERNO 
as nombre ,PER_TELEFONO1,   PER_TELEFONO2 , per_telcelular, UNC_DESCRIPCION, UNC_MODELO,PAR_DESCRIP1, PED_NUMERO  
from PAR_PEDIDO 
inner join SER_ORDEN on ORE_IDORDEN = ped_origen  
inner join GA_Corporativa.DBO.per_personas on PER_IDPERSONA = ORE_IDCLIENTE  
left join SER_VEHICULO on VEH_NUMSERIE = ORE_NUMSERIE   
left join UNI_CATALOGO on ORE_IDCATALOGO = UNC_IDCATALOGO and UNC_MODELO = VEH_ANMODELO   
left join PNC_PARAMETR on PAR_IDENPARA = ORE_IDASESOR and PAR_TIPOPARA = 'AS'   
inner join CRM_PREPICK on rel_idcita = convert (varchar,PED_NUMERO)  where ped_origen<>'' and rel_stataccion <> 'CITA PROGRAMADA' 
and rel_stataccion <> 'AVISO A BPRO'   union all  select rel_fechallamada, rel_horallamada, rel_stataccion, rel_fechope,PER_IDPERSONA , 
PER_NOMRAZON + ' ' + PER_PATERNO + ' ' + PER_MATERNO as nombre ,PER_TELEFONO1,   PER_TELEFONO2 , per_telcelular, UNC_DESCRIPCION, UNC_MODELO,
PAR_DESCRIP1, PED_NUMERO   from PAR_PEDIDO inner join SER_CITAS on convert(varchar,CIT_IDCITA) = substring(ped_origen,7,len(ped_origen))   
inner join GA_Corporativa.DBO.per_personas on PER_IDPERSONA = CIT_IDPERSON   
left join UNI_CATALOGO on cit_idcatalogo = UNC_IDCATALOGO and UNC_MODELO = CIT_ANMODELO   
left join PNC_PARAMETR on PAR_IDENPARA = CIT_IDASESOR and PAR_TIPOPARA='AS'  
 inner join CRM_PREPICK on rel_idcita = convert (varchar,PED_NUMERO)   where ped_origen like 'CIT%'and rel_stataccion <> 'CITA PROGRAMADA' 
 and rel_stataccion <> 'AVISO A BPRO'  union all   select rel_fechallamada, rel_horallamada, rel_stataccion, rel_fechope,p1.PER_IDPERSONA ,
  p1.PER_NOMRAZON + ' ' + p1.PER_PATERNO + ' ' + p1.PER_MATERNO as nombre ,p1.PER_TELEFONO1,   p1.PER_TELEFONO2 , p1.per_telcelular,
   ''UNC_DESCRIPCION, ''UNC_MODELO,p2.PER_NOMRAZON + ' ' + p2.PER_PATERNO   + ' ' + p2.PER_MATERNO as PAR_DESCRIP1, PED_NUMERO   
   from PAR_PEDIDO inner join PAR_PEDMOST on convert(varchar,PMM_NUMERO) = substring(ped_origen,5,len (ped_origen)) and PMM_STATUS='C'   
   inner join GA_Corporativa.DBO.per_personas as p1 on p1.PER_IDPERSONA = PMM_IDCLIENTE    inner join GA_Corporativa.DBO.per_personas as p2 
   on convert(varchar,p2.PER_IDPERSONA) = ped_persona    inner join CRM_PREPICK on rel_idcita = convert (varchar,PED_NUMERO) 
    where ped_origen like 'cot%' and rel_stataccion <> 'CITA PROGRAMADA' and rel_stataccion <> 'AVISO A BPRO'   union all  
    select rel_fechallamada, rel_horallamada, rel_stataccion, rel_fechope,p1.PER_IDPERSONA ,
     p1.PER_NOMRAZON + ' ' + p1.PER_PATERNO + ' ' + p1.PER_MATERNO as nombre ,p1.PER_TELEFONO1,   p1.PER_TELEFONO2 , p1.per_telcelular,
      ''UNC_DESCRIPCION, ''UNC_MODELO, p2.USU_NOUSUARI + ' ' + p2.USU_APUSUARI + ' ' + p2.USU_AMUSUARI as PAR_DESCRIP1, PED_NUMERO   
      from PAR_PEDIDO inner join GA_Corporativa.DBO.per_personas p1 on convert(varchar,p1.PER_IDPERSONA) = ped_persona  
      left join pnc_usuarios p2 on p2.USU_CVEUSU = PED_CVEUSU  inner join CRM_PREPICK on rel_idcita = convert (varchar,PED_NUMERO) 
       where ped_origen like 'pkg%' and rel_stataccion <> 'CITA PROGRAMADA' and rel_stataccion <> 'AVISO A BPRO'
go

