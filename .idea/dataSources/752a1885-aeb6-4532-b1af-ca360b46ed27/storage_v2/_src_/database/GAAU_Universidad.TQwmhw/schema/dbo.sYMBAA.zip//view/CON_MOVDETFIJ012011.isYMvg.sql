create view 	[dbo].[CON_MOVDETFIJ012011]	 as select * from GAAU_Concentra.dbo.CON_MOVDETFIJ012011
go

