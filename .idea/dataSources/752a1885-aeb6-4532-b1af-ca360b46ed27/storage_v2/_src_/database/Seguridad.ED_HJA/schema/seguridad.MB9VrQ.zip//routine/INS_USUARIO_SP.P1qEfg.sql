-- =============================================
-- Author:		Antonio Guerra
-- Create date: 05/10/2020
-- Description:	Inserta un usuario.
-- =============================================
/*
		------ Versionamiento
	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [seguridad].[INS_USUARIO_SP]
	@password = 'usuario.pruebaGAndr4d3!' ,
	@primernombre = 'usuario',
	@segundonombre = '',
	@primerapellido = 'primerApa',
	@segundoapellido = 'prueba',
	@email = 'usuario.prueba@bpro.com',
	@usuarioBPRO = 'usuario.prueba@ga.com',
	@passexpire	= 0,
	@dataApp = '<Apps><idAplicacion>3</idAplicacion><idRol>9</idRol></Apps>',
	@avatar	= 27,
	@dobleFactor = 0,
	@UID = 'vtuz0BAZPlU4XNNfSenE6FqtcKi2'
	SELECT @salida AS salida;


*/
CREATE PROCEDURE [seguridad].[INS_USUARIO_SP]
	@password			VARCHAR(250),
	@primernombre		VARCHAR(100) = null,
	@segundonombre		VARCHAR(100) = null,
	@primerapellido		VARCHAR(100) = null,
	@segundoapellido	VARCHAR(100) = null,
	@email				VARCHAR(150) = null,
	@usuarioBPRO		VARCHAR(100) = null,
	@passexpire			BIT = 0,
	@dataApp			XML,
	@avatar				INT = 0,
	@dobleFactor		BIT = 0,
	@UID				VARCHAR(30) = ''
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    DECLARE
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en [INS_USUARIO_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VC_ResultMessage	VARCHAR(100) = '',
		@VI_Status			BIT = 0,
		@VI_UsuarioId			INT = 0
-- declaro  una tabla temporal para guardar el conjunto de aplicaciones y roles
		DECLARE @Apps TABLE (
		_row			INT IDENTITY(1,1),
		idAplicacion	varchar (10),
		idRol			INT
		);
		INSERT INTO @Apps (idAplicacion,
							idRol)
		SELECT
			ParamValues.col.value('idAplicacion[1]','nvarchar(10)'),
			ParamValues.col.value('idRol[1]','int')
			FROM @dataApp.nodes('Apps') AS ParamValues(col);

		DECLARE @cont		INT = 1;

	
		IF EXISTS(SELECT TOP 1 [Id] FROM [catalogo].[Usuario] 
				WHERE [UserName] = @usuarioBPRO)
			BEGIN
				SET @VC_ResultMessage = 'El usuario proporcionado ya esta registrado.';
				SET @VI_UsuarioId = (SELECT TOP 1[Id] FROM [catalogo].[Usuario] WHERE 
									[UserName] = @usuarioBPRO )
			END
		ELSE
			BEGIN TRY 
				BEGIN TRANSACTION INS_USUARIO_SP
				INSERT INTO [Catalogo].[Usuario](
						[UID]
					   ,[UserName]
					   ,[Password]
					   ,[PrimerNombre]
					   ,[SegundoNombre]
					   ,[PrimerApellido]
					   ,[SegundoApellido]
					   ,[Email]
					   ,[Celular]
					   ,[EstatusId]
					   ,[FechaRegistro]
					   ,[PassExpire]
					   ,[Avatar]
					   ,TwoFactorAuth
				) VALUES (
						@UID
					  , @usuarioBPRO
					  , ENCRYPTBYPASSPHRASE(N'Password Secret!', N'' + CAST(@password AS VARCHAR(250)))
					  , @primernombre
					  , @segundonombre
					  , @primerapellido
					  , @segundoapellido
					  , @email
					  , ''
					  , 1
					  , GETDATE()
					  , @passexpire
					  , @avatar
					  ,@dobleFactor
					  
				)
				print 2
				SET @VI_UsuarioId = SCOPE_IDENTITY();
				SET @VI_Status = 1;
				SET @VC_ResultMessage = 'Usuario registrado.'


				WHILE((SELECT COUNT(*) FROM @Apps)>= @cont)
				-- inicio de while
				BEGIN
					DECLARE @idAplicacion		INT;
					DECLARE @idRol				INT;
							
					SELECT @idAplicacion = idAplicacion,
							@idRol = idRol
					FROM @Apps
					WHERE _row = @cont

					INSERT INTO [relacion].[UsuarioRol](
						 [UsuarioId]
					   , [AplicacionId]
					   , [RolId]
					)
					VALUES(
						@VI_UsuarioId, 
						@idAplicacion, 
						@idRol
					);
					
					SET @cont = @cont + 1
				END
				-- termino while
			COMMIT TRANSACTION INS_USUARIO_SP
		END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION INS_USUARIO_SP
				SET @VC_ResultMessage = 'Error al registar el usuario';
				SET @VC_ErrorMessage = {
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage
					) 
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
			END
		END CATCH
	SELECT 
		@VC_ResultMessage	AS [Message], 
		@VI_Status			AS [Status], 
		@VI_UsuarioId			AS [UserId];

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

