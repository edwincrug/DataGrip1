-- =============================================
-- Author:		Uriel Hernandez
-- Create date: 03/10/2020
-- Description:	obtener los datos del usuario
-- Test:		
/*
	[seguridad].[SEL_USUARIO_CORREO_SP] '', 1

*/

-- =============================================
/*
		------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición

*/
CREATE PROCEDURE [seguridad].[SEL_USUARIO_CORREO_SP] 
	@correo			VARCHAR(500) = '',
	@aplicacionId	INT = 0
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET NOCOUNT ON;

	DECLARE @VI_Zero		        INT = 0,
			--@VD_PasswordExpiration	DATE,
            @VB_PasswordExpiration  BIT = 0,
			@VI_Date				INT,
			@VI_DateValidation		INT,
			@VI_ExpDays				INT,
			@VC_Expiration			VARCHAR(20) = 'PasswordExpiration',
			@passExpire				BIT = 0

	--SET @VD_PasswordExpiration = 
	--	(SELECT [LastPasswordUpdate] 
	--		FROM [catalogo].[Usuario] AS [US] 
	--		WHERE PATINDEX(@Email,[US].UserName) > @vi_Zero
	--		AND EstatusID = 1
	--	 )
	--SET @VI_ExpDays = CONVERT(INT,(SELECT [Valor] FROM [Operacion].[Configuracion] WHERE [Campo] = @VC_Expiration))
	--IF @VD_PasswordExpiration IS NOT NULL
	--BEGIN
        --SET @VI_Date = DATEDIFF(day,
        --    DATEADD(
        --        DAY,
        --        @VI_ExpDays,
        --        @VD_PasswordExpiration
        --    ), GETDATE())

        SET @VI_DateValidation = (SELECT [id] 
			FROM [catalogo].[Usuario] AS [US] 
			WHERE [US].UserName = @correo)
		print @VI_DateValidation;

		SELECT
			@passExpire = passExpire
		from [catalogo].[Usuario] 
		where UserName = @correo

	
	IF @passExpire = 1
		BEGIN
			IF @VI_Date <= @VI_ExpDays
				BEGIN
					SELECT
						  [US].[id]
						, [US].[UID]
						, [US].[userName]
						, [US].[password]
						, [US].[primerNombre]
						, [US].[segundoNombre]
						, [US].[primerApellido]
						, [US].[segundoApellido]
						, [US].[email]
						, [US].[celular]
						, [US].[estatusId]
						, [US].[fechaRegistro]
						--, [US].[PromocionActivo]
						, [US].[passExpire]
						, [US].[avatar]
					FROM 
						[Seguridad].[catalogo].[Usuario] AS [US]
					WHERE 
						[US].UserName = @correo
				END
			ELSE
				BEGIN
					SET @VB_PasswordExpiration = 1
					SELECT @VI_Zero
				END
		END

	ELSE
		BEGIN
			SELECT
				[US].[id]
				, [US].[UID]
				, [US].[userName]
				, [US].[password]
				, [US].[primerNombre]
				, [US].[segundoNombre]
				, [US].[primerApellido]
				, [US].[segundoApellido]
				, [US].[email]
				, [US].[celular]
				, [US].[estatusId]
				, [US].[fechaRegistro]
				--, [US].[PromocionActivo]
				, [US].[passExpire]
				, [US].[avatar]
			FROM 
				[Seguridad].[catalogo].[Usuario] AS [US]
			WHERE 
				[US].UserName = @correo
		END

	-- END
    SELECT @VB_PasswordExpiration AS [PasswordExpiration]

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

