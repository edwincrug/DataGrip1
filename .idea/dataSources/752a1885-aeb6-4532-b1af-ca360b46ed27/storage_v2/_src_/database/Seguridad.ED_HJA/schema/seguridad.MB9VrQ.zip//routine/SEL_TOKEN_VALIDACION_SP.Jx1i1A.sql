-- =============================================
-- Author:		Uriel Hernandez
-- Create date: 10/08/2020
-- Description:	Valida que el token del usuario sea valido
-- =============================================
/*
		------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición

	Test:
	exec [seguridad].[SEL_TOKEN_VALIDACION_SP] 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjU0ODZkYTNlMWJmMjA5YzZmNzU2MjlkMWQ4MzRmNzEwY2EzMDlkNTAiLCJ0eXAiOiJKV1QifQ.eyJuYW1lIjoiSnVhbiIsImlzcyI6Imh0dHBzOi8vc2VjdXJldG9rZW4uZ29vZ2xlLmNvbS9nYS1zZWN1cml0eS1hcGkiLCJhdWQiOiJnYS1zZWN1cml0eS1hcGkiLCJhdXRoX3RpbWUiOjE1NjgxNTkzNzgsInVzZXJfaWQiOiJsNDVVTnJrNUFpY2FJdXdUSE5pUDcyWXlpc3cxIiwic3ViIjoibDQ1VU5yazVBaWNhSXV3VEhOaVA3Mll5aXN3MSIsImlhdCI6MTU2ODE1OTM3OCwiZXhwIjoxNTY4MTYyOTc4LCJlbWFpbCI6Imp1YW5qb3NlQGFuZHJhZGUuY29tIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJwaG9uZV9udW1iZXIiOiIrNTUwMDAwMDAxMTEiLCJmaXJlYmFzZSI6eyJpZGVudGl0aWVzIjp7InBob25lIjpbIis1NTAwMDAwMDExMSJdLCJlbWFpbCI6WyJqdWFuam9zZUBhbmRyYWRlLmNvbSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.LkgW_Kmjgl66TakQQ2SQuQXW_k4axDuTLAxPgJcDL8dhdNUrVZ1Ss4lAotSzPFoETDXCdNbxrHo5UzW3tMooXCwaqTyYVO-EpZomKLk43sDGeXXro3LcuEzoZMWZreyp4EOwVwxUjATgKYcuVKSetHcyPr32vZWn6W6dlZSFGDck32QqaKFCa26M6wzjHamDHFN2RB_-QZ2lG1TUXwhd68fQyZuHML5sW_MmASZFGt83LVEZD-D71hr3PJy77N6pwjeEFp-4pchLvj3oACtJev8auUE6Ud6tJkgrdCBpek4u6Mf4GwtGidiNulTqbDHu_K97N2t3mK3Fw2u-_X9J6w', 11


*/
CREATE PROCEDURE [seguridad].[SEL_TOKEN_VALIDACION_SP]
	@token			VARCHAR(1300) = '',
	@aplicacionId	INT = 0	
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET NOCOUNT ON;

    DECLARE @UserCTE TABLE( [rolId] INT
							,[rol] VARCHAR(MAX)
							,[aplicacionId] VARCHAR(MAX)
							,[usuarioId] INT
						)
	INSERT INTO @UserCTE
		SELECT 
				[UR].[rolId]
				,[R].[nombre] AS [Rol]
				,[A].[nombre] AS [Aplication]
				,[UR].[usuarioId] AS [UsersId]
		FROM [operacion].[AccessToken] AS [AT] 
		INNER JOIN [catalogo].[Usuario] AS [US] ON US.id = [AT].usuarioId
		INNER JOIN [relacion].[UsuarioRol] AS [UR] ON [AT].[usuarioId] = [UR].[usuarioId]
		INNER JOIN [catalogo].[Rol] AS [R] ON [R].[id] = [UR].[rolId]
		INNER JOIN [catalogo].[Aplicacion] AS [A] ON [A].[id] = [UR].[aplicacionId]
		WHERE
			[AT].[accessToken] = @token
			AND [UR].[aplicacionId] = @aplicacionId
			AND estatusId = 1

	IF EXISTS (SELECT [rolId] FROM @UserCTE)
	BEGIN
		DECLARE @RevokedForInactivity INT = 60, @time INT = 0

		BEGIN TRY
			SELECT @RevokedForInactivity  = CAST(Valor AS INT) FROM [Seguridad].[operacion].[Configuracion]
			WHERE [campo] = 'RevokedForInactivity' 
			AND aplicacionId IN (1,@aplicacionId)
			ORDER BY aplicacionId DESC
		END TRY
		BEGIN CATCH
			SET @RevokedForInactivity = 60 -- Solo si hay error
			SET @time = 0
		END	CATCH

		SELECT @time = DATEDIFF(MINUTE,lastAccess,GETDATE()) 
			FROM [Operacion].[AccessToken] 
			WHERE AccessToken = @token

		IF(@RevokedForInactivity > @time)
		BEGIN
			UPDATE [Operacion].[AccessToken] 
				SET lastAccess = GETDATE()
			WHERE  accessToken = @token
		END
		ELSE
		BEGIN
			DELETE FROM [operacion].[AccessToken] 
			WHERE AccessToken = @token
			DELETE FROM @UserCTE
		END
	END

	SELECT 
		 [C].[rolId]
		,[C].[rol]
		,[C].[aplicacionId]
		,[C].[usuarioId]
	FROM @UserCTE AS [C]

	SELECT 
		 [C].[RolId]
		,[C].[Rol]
	FROM @UserCTE AS [C]

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

