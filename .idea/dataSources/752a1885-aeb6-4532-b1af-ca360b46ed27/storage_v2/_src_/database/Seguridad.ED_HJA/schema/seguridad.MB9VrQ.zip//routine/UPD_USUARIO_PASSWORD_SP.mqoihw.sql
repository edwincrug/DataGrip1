-- =============================================
-- Author:		Antonio Guerra
-- Create date: 05/10/2020
-- Description:	actualiza contraseña por email.
-- Test:		exec [Security].[UPD_PasswordRestore_SP] 6119,'alan.rosales@grupoandrade.com.mx','Alan111!'
-- =============================================
/*
		------ Versionamiento

	
*/
create PROCEDURE [Seguridad].[UPD_USUARIO_PASSWORD_SP]
	@UserId			INT = null,
	@Email			VARCHAR(100) = '',
	@NewPassword	VARCHAR(100) = ''
AS
BEGIN
	SET NOCOUNT OFF;

	DECLARE	
		@VC_ErrorMessage	NVARCHAR(4000)	= '',
		@VC_ThrowMessage	NVARCHAR(100)	= 'Ha ocurrido un error en [UPD_PasswordRestore_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VC_EncrypetPass	NVARCHAR(MAX) = '',
		@VI_ResultCount		INT = 0,
		@VC_ResultMessage	VARCHAR(100) = ''

	BEGIN TRY
		BEGIN TRANSACTION UPD_USUARIO_PASSWORD_SP

		SET @VC_EncrypetPass = CONVERT(NVARCHAR(MAX), @NewPassword);

		UPDATE [Catalogo].[Usuario]
		SET [Password] = ENCRYPTBYPASSPHRASE(N'Password Secret!', @VC_EncrypetPass),
			[fechaActualizaPassword] = GETDATE()
		WHERE [Id] = @UserId AND EstatusId = 1 
		SET @VI_ResultCount = @@ROWCOUNT
		
		SELECT 
			[Id],
			CONVERT(NVARCHAR(MAX), DECRYPTBYPASSPHRASE(N'Password Secret!', [Password])) AS [tok],
			[Email] 
		FROM [Catalogo].[Usuario]
		WHERE [Id] = @UserId  AND EstatusId = 1




		COMMIT TRANSACTION UPD_USUARIO_PASSWORD_SP
	END TRY
	BEGIN CATCH
		SELECT  
			@VC_ErrorMessage	= ERROR_MESSAGE(),
			@VC_ErrorSeverity	= ERROR_SEVERITY(),
			@VC_ErrorState		= ERROR_STATE();
		BEGIN
			ROLLBACK TRANSACTION UPD_PasswordRestore_SP
			SET @VC_ErrorMessage = { 
				fn CONCAT(
					@VC_ThrowMessage,
					@VC_ErrorMessage
				) 
			}
			RAISERROR (
				@VC_ErrorMessage, 
				@VC_ErrorSeverity, 
				@VC_ErrorState
			);
		END
	END CATCH 
	 IF @VI_ResultCount > 0
	 	BEGIN
			SET @VC_ResultMessage = 'La contraseña se ha actualizado correctamente.'
		END
	ELSE 
		BEGIN
			SET @VC_ResultMessage = 'Contraseña no actualizada, esta ha sido utilizada anteriormente.'
		END

	SELECT 
		@VC_ResultMessage	AS [Message],
		 @VI_ResultCount AS [result];
END
go

