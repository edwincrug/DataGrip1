-- =============================================
-- Author:		Uriel Hernandez
-- Create date: 05/10/2020
-- Description:	Obtiene todos los susuarios de la plataforma
-- Test:		
/*
	[seguridad].[SEL_USUARIO_ALL_SP] 17, ''

*/

-- =============================================
/*
		------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición

*/
CREATE PROCEDURE [seguridad].[SEL_USUARIO_ALL_SP] 
AS
BEGIN
	select * from (
	SELECT 
		[id]
      ,[UID]
	  ,ISNULL(u.PrimerNombre,'') + ' ' + ISNULL(U.SegundoNombre,'')+' '+ ISNULL(u.PrimerApellido,'') + ' ' +ISNULL(u.SegundoApellido,'') 'nombreCompleto'
      ,REPLACE((SUBSTRING(username,1,(CHARINDEX('@',[userName])))),'@','') usuarioBPRO
      ,[primerNombre]
      ,[segundoNombre]
      ,[primerApellido]
      ,[segundoApellido]
      ,[email]
      ,[celular]
      ,[fechaRegistro]
      ,[passExpire]
      ,[fechaActualizaPassword]
      ,[fechaUltimoAcceso]
      ,[avatar]
      ,[twoFactorAuth]
	  ,(STUFF(
		(SELECT '', ', ' + Nombre
			FROM seguridad.Catalogo.Rol R
			INNER JOIN Seguridad.relacion.UsuarioRol UR ON UR.rolId = R.id AND UR.usuarioId = U.id
			FOR XML PATH ('')),
			1,1, '')) as rol,
	  CASE u.EstatusId WHEN 1 THEN 'Activo' WHEN 2 THEN 'Inactivo' ELSE 'Eliminado' END 'estatusId'
  FROM [Seguridad].[catalogo].[Usuario] U
  WHERE U.UID IS NOT NULL
  AND estatusId != 3) t
  
END
go

