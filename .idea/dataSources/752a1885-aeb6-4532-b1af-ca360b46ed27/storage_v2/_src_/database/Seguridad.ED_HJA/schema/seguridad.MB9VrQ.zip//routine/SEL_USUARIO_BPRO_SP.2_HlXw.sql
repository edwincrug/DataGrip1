/*
	Objetivo: Obtener la Información de un usuario con sus roles y aplicaciones
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	05/10/2020		Antonio Guerra		Obtener password de BPRO

  *** TEST
  EXEC [seguridad].[SEL_USUARIO_BPRO_SP]
	@usuarioBPRO = 'prueba.usuario,
	@err = NULL
*/
CREATE PROCEDURE [seguridad].[SEL_USUARIO_BPRO_SP]
	@usuarioBPRO		VARCHAR(100) , 
	@err			varchar(500) = null output   
AS
BEGIN
		SELECT @usuarioBPRO + 'GAndr4d3!' AS passwordBPRO
END
go

