
/*    
 Objetivo: Guarda los toquens de acceso activos    
     
 ------ Versionamiento    
 DD/MM/AA     Autor Descrición    

    
 [Operacion].[Ins_AccessToken] '',3  
    
*/    
    
CREATE PROCEDURE [operacion].[INS_ACCESSTOKEN_SP]
 @accessToken     VARCHAR(max),  --VALOR OBTENIDO DESPUES DE UN LOGIN SUCCESS EN FIREBASE  
 @usuarioId          INT    
AS    
BEGIN    
 SET NOCOUNT OFF;    
    
 DECLARE     
  @VC_ErrorMessage NVARCHAR(4000) = '',    
  @VC_ThrowMessage NVARCHAR(100) = 'An error has occured on [Ins_AccessToken]:',    
  @VC_ErrorSeverity INT = 0,    
  @VC_ErrorState  INT = 0 ,  
  @RevokedForInactivity INT = 60, @time INT = 0    
    
    BEGIN TRY    
        BEGIN TRANSACTION Ins_AccessToken    
            IF EXISTS (SELECT [usuarioId] FROM [operacion].[AccessToken] WHERE usuarioId = @usuarioId)    
                BEGIN    
     --1. SI YA EXISTE UN TOKEN EN LA TABLA VALIDAMOS QUE AUN ESTÉ ACTIVO  
     -----------------------------------------------------------------------------------------------  
     SELECT @RevokedForInactivity  = CAST(valor AS INT) FROM [Seguridad].[operacion].[Configuracion]    
     WHERE   
      [Campo] = 'RevokedForInactivity'     
      AND aplicacionId IN (1)    
     ORDER BY aplicacionId DESC    
     SET @time = 0    
     SELECT @time = DATEDIFF(MINUTE,LastAccess,GETDATE())     
        FROM [Operacion].[AccessToken]     
        WHERE usuarioId = @usuarioId  
     print 'revoked: ' + convert(varchar,@RevokedForInactivity)  
     print 'time: ' + convert(varchar,@time)  
     -----------------------------------------------------------------------------------------------  
     IF(@RevokedForInactivity > @time)    
     BEGIN    
      --SI EL TOKEN ACTUAL AUN ESTÁ ACTIVO, ACTUALIZAMOS LA FECHA DE ULTIMO ACCESO  
      UPDATE [operacion].[AccessToken]     
      SET lastAccess = GETDATE()
      WHERE  usuarioId = @usuarioId  
     END    
     ELSE  
     BEGIN        
      UPDATE [operacion].[AccessToken]
      SET accessToken = @accessToken,  
       lastAccess = GETDATE()    
      WHERE  usuarioId = @usuarioId
     END  
        
    END    
    ELSE    
     BEGIN    
      INSERT INTO [operacion].[AccessToken](    
       [usuarioId],    
       [accessToken],    
       [lastAccess]    
      ) VALUES (    
       @usuarioId,    
       @accessToken,    
       GETDATE()    
      );    
     END    
   COMMIT TRANSACTION Ins_AccessToken    
     -- EXEC [Security].[UPD_UserLastLoginRegistry_SP] @userID    
  
   select
	usuarioId,
	accessToken,
	lastAccess
   from [operacion].[AccessToken] where usuarioId = @usuarioId  
            
 END TRY    
 BEGIN CATCH    
  SELECT      
   @VC_ErrorMessage = ERROR_MESSAGE(),    
   @VC_ErrorSeverity = ERROR_SEVERITY(),    
   @VC_ErrorState  = ERROR_STATE();    
    
  print @VC_ErrorMessage    
  BEGIN    
   ROLLBACK TRANSACTION Ins_AccessToken    
   SET @VC_ErrorMessage = {     
    fn CONCAT(    
     @VC_ThrowMessage,    
     @VC_ErrorMessage    
    )     
   }    
   RAISERROR (    
    @VC_ErrorMessage,     
    @VC_ErrorSeverity,     
    @VC_ErrorState    
   );    
  END    
 END CATCH    
END
go

