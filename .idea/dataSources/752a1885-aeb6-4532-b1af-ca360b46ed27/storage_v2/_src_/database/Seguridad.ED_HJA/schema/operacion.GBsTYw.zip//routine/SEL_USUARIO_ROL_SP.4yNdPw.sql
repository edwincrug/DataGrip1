/*
	Objetivo:	Devuelve los roles del usuario
				DataSet[0] = Las pantallas a las que tiene acces
				DataSet[1] = Los campos a los que tiene acceso 
				DataSet[2] = Las columnas (en caso de que aplque) a las que tiene acceso
				
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición

	[operacion].[SEL_USUARIO_ROL_SP] 
		1,
	'eyJhbGciOiJSUzI1NiIsImtpZCI6IjBlM2FlZWUyYjVjMDhjMGMyODFhNGZmN2RjMmRmOGIyMzgyOGQ1YzYiLCJ0eXAiOiJKV1QifQ.eyJuYW1lIjoiQW50b25pbyIsImlzcyI6Imh0dHBzOi8vc2VjdXJldG9rZW4uZ29vZ2xlLmNvbS9jb2FsLWRjMjZmIiwiYXVkIjoiY29hbC1kYzI2ZiIsImF1dGhfdGltZSI6MTYwMzEzODgxNCwidXNlcl9pZCI6IkFRZFFtWk0wSE9TQzY3RzBndEU2cGZRemJ5TDIiLCJzdWIiOiJBUWRRbVpNMEhPU0M2N0cwZ3RFNnBmUXpieUwyIiwiaWF0IjoxNjAzMTM4ODE0LCJleHAiOjE2MDMxNDI0MTQsImVtYWlsIjoiYW50b25pby5ndWVycmEyMDg5QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwicGhvbmVfbnVtYmVyIjoiKzUyNTUxMTIyMjExMyIsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnsicGhvbmUiOlsiKzUyNTUxMTIyMjExMyJdLCJlbWFpbCI6WyJhbnRvbmlvLmd1ZXJyYTIwODlAZ21haWwuY29tIl19LCJzaWduX2luX3Byb3ZpZGVyIjoicGFzc3dvcmQifX0.jVeYxm-csgr1njRNVWUajUtmAK8wmdPx1JxyzmeJ9j5Qw_WiQct0s0-UjJNLJioT73PwCYaGAvlVi17BebKd5veUy2dlDvnPgCyY6E1AaMZPM3jGw52roQNvyyajkcKAUAawDzW5jncdherqByMGrAalBp45HqPPPZfPRnBrbmw_Kp-DYhRZ4wZ08U3OH-n36_yCgmNDj44xlYY-otiGKOeYkCgm8cAL2-feEPgCoQse04LarnRSWMY8oeBEkVgMWyv6tW4n4uRVu6ec4k2TWd4EPeLeCzaAteB42tdqn134UaqZgxdJhWV3bbWcr6w691gRPf0YYUlljZn4im868A'

	 
*/
 CREATE PROCEDURE [operacion].[SEL_USUARIO_ROL_SP]
	@aplicacionId int,		-- Los permisos son por aplicación 
	@bearerToken varchar(max)	-- Se el puede mandar el token activo 
AS
BEGIN
	DECLARE @usuarioId INT = 0;
	DECLARE @User_Promo bit = 0;

	IF LEN(@bearerToken)>1
	BEGIN
		IF exists (select usuarioId as user_id from [operacion].[AccessToken] where [AccessToken] =  @bearerToken)
		BEGIN 
			select @usuarioId= usuarioId
			from [operacion].[AccessToken] AO 
			INNER JOIN [catalogo].[Usuario] U ON AO.usuarioId = U.Id
			where [accessToken] =  @bearerToken
		END	
	END
	IF @usuarioId>0
	BEGIN 
		-- DataSet[0] Modulos
		SELECT DISTINCT
				c_Mo.id,
				r_ro.aplicacionId,
				tipoObjetoId,
				c_Mo.moduloId,
			campoId,
				usuarioId,
				--r_RO.aplicacionId,
				c_Mo.nombre,
				c_TO.nombre as tipo,
				c_Mo.caption,
				r_RO.orden, 
				clave
			FROM [Seguridad].[relacion].[RolObjeto] AS r_RO
			INNER JOIN [Seguridad].[relacion].[UsuarioRol] AS r_UR ON r_RO.rolId = r_UR.rolId
			INNER JOIN [catalogo].[Modulo] AS c_Mo ON r_RO.aplicacionId=c_Mo.aplicacionId and r_RO.moduloId = c_Mo.id 
			INNER JOIN [Catalogo].[TipoObjeto] AS c_TO ON c_TO.Id = r_RO.tipoObjetoId
			WHERE	r_RO.aplicacionId = @aplicacionId	
				AND r_UR.usuarioId = @usuarioId
				AND r_RO.tipoObjetoId >= 2 AND r_RO.tipoObjetoId <= 3 -- Tipo Modulo o pantalla
			order by c_Mo.moduloId asc, r_RO.orden , c_Mo.id
		-- DataSet[1] Campos
		SELECT DISTINCT
				c_Ca.id,
				r_ro.aplicacionId,
				tipoObjetoId,
				c_Ca.moduloId,
				c_Ca.campoId,
				usuarioId,
				--r_ro.aplicacionId,
				c_Ca.nombre,
				c_TC.nombre as tipo,
				c_Ca.caption
			FROM [Seguridad].[relacion].[RolObjeto] AS r_RO
			INNER JOIN [Seguridad].[relacion].[UsuarioRol] AS r_UR ON r_RO.rolId = r_UR.rolId
			INNER JOIN [catalogo].[Campo] AS c_Ca ON r_RO.aplicacionId=c_Ca.aplicacionId and r_RO.moduloId = c_Ca.moduloId and r_RO.campoId = c_Ca.id
			INNER JOIN [catalogo].[TipoCampo] AS c_TC ON c_TC.Id = c_Ca.tipoCampoId
			WHERE r_RO.aplicacionId = @aplicacionId
				AND r_UR.usuarioId = @usuarioId
				AND r_RO.tipoObjetoId > 3  -- Tipo Campos


		-- DataSet[2]
		SELECT DISTINCT
				c_Ca.id,
				r_ro.aplicacionId,
				tipoObjetoId,
				c_Ca.moduloId,
				c_Ca.campoId,
				usuarioId,
				--r_ro.aplicacionId,
				c_Ca.nombre,
				c_TC.nombre as tipo,
				c_Ca.caption,
				c_Ca.campoId -- La tabla padre
			FROM [Seguridad].[relacion].[RolObjeto] AS r_RO
			INNER JOIN [Seguridad].[relacion].[UsuarioRol] AS r_UR ON r_RO.rolId = r_UR.rolId
			INNER JOIN [Catalogo].[Campo] AS c_Ca ON r_RO.aplicacionId=c_Ca.aplicacionId and r_RO.moduloId = c_Ca.moduloId and r_RO.campoId = c_Ca.id
			INNER JOIN [Catalogo].[TipoCampo] AS c_TC ON c_TC.id = c_Ca.tipoCampoId
			WHERE r_RO.aplicacionId = @aplicacionId
				AND r_UR.usuarioId = @usuarioId
				AND r_RO.tipoObjetoId = 6  -- Solo si son columnas
				AND isnull(c_Ca.campoId,'') != ''
	END
	ELSE
	BEGIN
		-- DataSet[0]
		SELECT 0 as usuarioId, 'No se encontro al usuario' as Msj, @bearerToken as bearerToken;
		
		-- DataSet[1]
		SELECT 0 as usuarioId, 'No se encontro al usuario';
		
		-- DataSet[2]
		SELECT 0 as usuarioId, 'No se encontro al usuario';
	END
END
go

