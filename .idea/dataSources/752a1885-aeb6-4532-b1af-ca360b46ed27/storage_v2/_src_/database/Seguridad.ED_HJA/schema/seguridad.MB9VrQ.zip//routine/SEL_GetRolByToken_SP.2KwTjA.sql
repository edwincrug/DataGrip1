-- =============================================
-- Author:		Antonio Guerra
-- Create date: 
-- Description:
-- Test:		exec [Seguridad].[SEL_GetRolByToken_SP] 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjkwYmVmMzI2MmVkMzI0MzZkNzhlMjdjYWJhYzg3YmIwZWUxZGYwYzIiLCJ0eXAiOiJKV1QifQ.eyJuYW1lIjoiSm9zw6kiLCJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZ2Etc2VjdXJpdHktYXBpIiwiYXVkIjoiZ2Etc2VjdXJpdHktYXBpIiwiYXV0aF90aW1lIjoxNTUxOTE3NTA5LCJ1c2VyX2lkIjoiT2tZYVpsODN2a1Z1TWpMUVFkbGVwdWh5ZDdNMiIsInN1YiI6Ik9rWWFabDgzdmtWdU1qTFFRZGxlcHVoeWQ3TTIiLCJpYXQiOjE1NTE5MTc1MDksImV4cCI6MTU1MTkyMTEwOSwiZW1haWwiOiJldEBwcnVlYmEuY29tIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJwaG9uZV9udW1iZXIiOiIrMTE0MzQ1Njc4MzUiLCJmaXJlYmFzZSI6eyJpZGVudGl0aWVzIjp7InBob25lIjpbIisxMTQzNDU2NzgzNSJdLCJlbWFpbCI6WyJldEBwcnVlYmEuY29tIl19LCJzaWduX2luX3Byb3ZpZGVyIjoicGFzc3dvcmQifX0.Rrmikm9Nk60Ijh5ZQ8510YRT8fjZGmoQ3RY0CcO8ZegSyLE6VTBQ19DlvnAQMVYzpGVAizruJiRUMW-pzsuTSuzmm8X7Dg3NIQIQpsOBrfATVNNUIfSPNoD6fjwrcx1LMX-kw2-c-QcvVQKdFBlWlK7CdpALWPDgM-X4HSUsbsjr2EYSPjw-ljv4j6QNtXjVPh2crvY-pgnKpcGLGvFJ-YSskrTL8u-CoVp-LNJUbn5zxWc8b_vQw6bv9ExyCRZXCbd3qf11E99wbzlPn-hbYTza_xDfL7KiQNZfTGrcWCze_SyEkrjMZadBiXJqZpm712Ml2LF-pm6OHRTC82jP8A'
-- =============================================
/*
		------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición

*/
CREATE PROCEDURE [Seguridad].[SEL_GetRolByToken_SP]
	@token			VARCHAR(1300) = ''
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET NOCOUNT ON;

    ;WITH UserCTE AS (
        SELECT 
			 [R].[Nombre] AS [Rol]
			,[AU].[AplicacionId] AS [Application]
        FROM [Operacion].[AccessToken] AS [AT] 
        INNER JOIN [Operacion].[AccessUsuario] AS [AU]
			ON [AT].[AccessToken] = [AU].[AccessToken]
		INNER JOIN [Catalogo].[Usuario] AS [U]
			ON [AU].[usuarioId] = [U].[Id]
		INNER JOIN [Relacion].[UsuarioRol] AS [UR]
			ON [UR].[usuarioId] = [U].[Id] AND [UR].[AplicacionId] = [AU].[AplicacionId]
		INNER JOIN [Catalogo].[Rol] AS [R]
			ON [R].[Id] = [UR].[RolId]
		WHERE
			[AT].[AccessToken] = @token
			AND [EstatusId] = 1
    )

	SELECT 
		  [C].[Application]
		, [c].[Rol]
	FROM [UserCTE] AS [C]

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

