-- =============================================
-- Author:		Antonio Guerra
-- Create date: 05/10/2020
-- Description:	Actualizar datos de un usuario por su ID.
-- =============================================
/*
		------ Versionamiento
		*- Testing...
	exec [seguridad].[UPD_USUARIO_ID_SP] 2,'antonio.guerra@gmail.com','Antonio','', 'Guerra', '','', 2,'<Apps><idApp>1</idApp><idRol>1</idRol></Apps><Apps>,false,1
		
*/
CREATE PROCEDURE [seguridad].[UPD_USUARIO_ID_SP]
	@userId				INT,
	@email				VARCHAR(150) = null,
	@primerNombre		VARCHAR(100) = null,
	@segundoNombre		VARCHAR(100) = null,
	@primerApellido		VARCHAR(100) = null,
	@segundoApellido	VARCHAR(100) = null,
	@avatar				INT = null,
	@dataApp			XML = null,
	@dobleFactor		BIT = 0,
	@idEstatus			INT = 0
AS
BEGIN
	SET NOCOUNT OFF;

	DECLARE
		@VC_ErrorMessage	NVARCHAR(4000)	= '',
		@VC_ThrowMessage	NVARCHAR(100)	= 'Ha ocurrido un error en [UPD_UserById_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0
		;

	BEGIN TRY
		BEGIN TRANSACTION UPD_USUARIO_ID_SP
	
		IF @primernombre IS NOT NULL 
		BEGIN
			UPDATE [Catalogo].[Usuario]
			SET [PrimerNombre] = @primerNombre
			WHERE [Id] = @userId 
		END

		IF @segundonombre IS NOT NULL 
		BEGIN
			UPDATE [Catalogo].[Usuario]
			SET [SegundoNombre] = @segundoNombre
			WHERE [Id] = @userId 
		END

		IF @primerapellido IS NOT NULL 
		BEGIN
			UPDATE [Catalogo].[Usuario]
			SET [PrimerApellido] = @primerApellido
			WHERE [Id] = @userId 
		END


		IF @segundoapellido IS NOT NULL 
		BEGIN
			UPDATE [Catalogo].[Usuario]
			SET [SegundoApellido] = @segundoApellido
			WHERE [Id] = @userId 
		END

		IF @avatar IS NOT NULL 
		BEGIN
			UPDATE [Catalogo].[Usuario]
			SET Avatar = @avatar
			WHERE [Id] = @userId 
		END

-- Actualiza doble factor

		UPDATE [Catalogo].[Usuario]
			SET TwoFactorAuth = @dobleFactor
			WHERE [Id] = @userId

		UPDATE [Catalogo].[Usuario]
			SET EstatusId = @idEstatus
			WHERE [Id] = @userId


-- Modificar  tabla usuarios rol 
		IF @dataApp IS NOT NULL 
		BEGIN
		-- declaro  una tabla temporal para guardar el conjunto de aplicaciones y roles
			DECLARE @Apps TABLE (
			_row			INT IDENTITY(1,1),
			idApp			INT,
			idRol			INT
			);
			INSERT INTO @Apps (idApp, idRol)
			SELECT
				ParamValues.col.value('idApp[1]','int'),
				ParamValues.col.value('idRol[1]','int')
				FROM @dataApp.nodes('Apps') AS ParamValues(col);
			DECLARE @cont		INT = 1;

			DELETE [relacion].[UsuarioRol]
				WHERE UsuarioId  = @userId


		--while para insertar los roles de el usuario
			WHILE((SELECT COUNT(*) FROM @Apps)>= @cont)
			-- inicio de while
			BEGIN
				DECLARE @idAplicacion		INT;
				DECLARE @idRol				INT;
							
				SELECT @idRol = idRol,
						@idAplicacion = idApp
				FROM @Apps
				WHERE _row = @cont

			
				-- buscamos l aplicacion de ese rol 

				INSERT INTO [Relacion].[UsuarioRol](
						[UsuarioId]
					, [AplicacionId]
					, [RolId]
				)
				VALUES(
					@userId	, 
					@idAplicacion,
					@idRol
				);	
				SET @cont = @cont + 1
			END
			-- termino while
		END

		COMMIT TRANSACTION UPD_USUARIO_ID_SP

		SELECT [Id]
			  ,[UID]
			  ,[UserName]
			  ,[PrimerNombre]
			  ,[SegundoNombre]
			  ,[PrimerApellido]
			  ,[SegundoApellido]
			  ,[Email]
			  ,[Celular]
			  ,[EstatusId]
			  ,[Avatar]
			  ,1 as Status
		 FROM [Catalogo].[Usuario]
		 WHERE [Id] = @userId 

	END TRY
	BEGIN CATCH
		SELECT  
			@VC_ErrorMessage	= ERROR_MESSAGE(),
			@VC_ErrorSeverity	= ERROR_SEVERITY(),
			@VC_ErrorState		= ERROR_STATE();
		BEGIN
			ROLLBACK TRANSACTION UPD_USUARIO_ID_SP
			SET @VC_ErrorMessage = { 
				fn CONCAT(
					@VC_ThrowMessage,
					@VC_ErrorMessage
				) 
			}
			RAISERROR (
				@VC_ErrorMessage, 
				@VC_ErrorSeverity, 
				@VC_ErrorState
			);
		END
	END CATCH
	
	

END
go

