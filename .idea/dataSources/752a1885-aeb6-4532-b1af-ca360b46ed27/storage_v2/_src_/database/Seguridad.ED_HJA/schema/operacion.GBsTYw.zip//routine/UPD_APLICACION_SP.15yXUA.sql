/*
	Objetivo: Actualiza aplicacion
	
	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición
	21/10/20			Antonio GUerra		Creación del SP
	26/10/20			Uriel Hernandez		Se quita el campo de gerencia
*/
CREATE PROCEDURE [operacion].[UPD_APLICACION_SP]
	@idAplicacion				INT,
	@nombre				VARCHAR(50),
	@URL				VARCHAR(500),
	@descripcion		VARCHAR(500),
	@idTipoAplicacion	INT
AS
BEGIN

	DECLARE @msj		varchar(50) = '', 
			@status		int = 0

	UPDATE Catalogo.Aplicacion SET
		Nombre = @nombre,
		tipoAplicacionId = @IdTipoAplicacion,
		URLProduccion = @URL,
		Descripcion = @descripcion
	WHERE id = @idAplicacion
	
	set @status = 1;
	SET @msj = 'Aplicación actualizada correctamente';

	SELECT @status AS Estado, @msj AS msj;
END
go

