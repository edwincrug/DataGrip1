/*
	Objetivo: Devuelve las gerencias
	
	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición
	21/10/20			Antonio Guerra		Creación del SP
*/
CREATE PROCEDURE [Operacion].[SEL_GERENCIA_SP]
AS
BEGIN
	Select 
		idGerencia
		,Nombre
		,PrimerApellido
		,SegundoApellido
		,activo
	from [Catalogo].[Gerencia] 
	WHERE activo = 1
END
go

