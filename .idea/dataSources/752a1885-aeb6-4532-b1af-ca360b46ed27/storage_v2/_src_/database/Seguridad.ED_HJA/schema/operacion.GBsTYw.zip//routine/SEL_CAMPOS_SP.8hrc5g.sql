/*
	Objetivo: Devuelve los campos

	------TEST

	[Operacion].[SEL_CAMPOS_SP] 3
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor			Descrición
	22/10/20		Antonio Guerra	Creación del SP
*/
CREATE PROCEDURE [Operacion].[SEL_CAMPOS_SP]
	@idAplicacion		INT
AS
BEGIN


		SELECT 
			C.AplicacionId
			,C.ModuloId
			,C.Id
			,C.Nombre
			,C.TipoCampoId
			,C.CampoId
			,C.Caption
			,TC.Nombre AS tipoCampo
		FROM [Catalogo].[Campo] C
		LEFT JOIN [Catalogo].[TipoCampo] TC ON TC.Id = C.TipoCampoID
		WHERE aplicacionId= @idAplicacion
		AND C.activo = 1
	


END
go

