/*
	Objetivo: Obtener la Información de un usuario con sus roles y aplicaciones
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	05/10/2020		Antonio Guerra		Obtener datos de usuario

  *** TEST
  EXEC [seguridad].[SEL_USUARIO_ID_SP]
	@idUsuario = 20,
	@err = NULL
*/
CREATE PROCEDURE [seguridad].[SEL_USUARIO_ID_SP]
	@idUsuario		int ,
	@err			varchar(500) = null output   
AS
BEGIN
			SELECT distinct 
			U.Id, 
			REPLACE((SUBSTRING(username,1,(CHARINDEX('@',[userName])))),'@','') usuarioBPRO, 
			U.[PrimerNombre], 
			U.[SegundoNombre], 
			U.[PrimerApellido], 
			U.[SegundoApellido], 
			U.[Email], 
			U.Celular,
			U.Avatar as Avatar ,
			U.TwoFactorAuth as dobleFactor,
			idDocumento, [path], 
			nombreOriginal, 
			nombre, 
			idUsuario, 
			fechaCreacion, 
			ultimaActualizacion, 
			idAplicacion, 
			titulo, 
			size, 
			tipo, 
			idModulo, 
			activo, 
			descripcion
			,EstatusId
			FROM [Catalogo].[Usuario] AS U
			LEFT JOIN [Relacion].[UsuarioRol] AS UR ON U.[Id] = UR.[usuarioId]
			LEFT JOIN [FileServer].[documento].[Documento] FS ON U.Avatar = FS.idDocumento
			WHERE U.Id = @idUsuario

			SELECT UR.usuarioId, UR.AplicacionId, UR.RolId, 
			SCA.Nombre AS NombreAplicacion, 
			SCR.Nombre AS NombreRol,
			SCR.Nombre AS DescripcionRol
			from [Relacion].[UsuarioRol] UR
			LEFT JOIN [Seguridad].[Catalogo].[Aplicacion] SCA ON UR.AplicacionId = SCA.Id
			LEFT JOIN  [Seguridad].[Catalogo].[Rol] SCR ON UR.RolId = SCR.Id
			WHERE [usuarioId]  = @idUsuario

END
go

