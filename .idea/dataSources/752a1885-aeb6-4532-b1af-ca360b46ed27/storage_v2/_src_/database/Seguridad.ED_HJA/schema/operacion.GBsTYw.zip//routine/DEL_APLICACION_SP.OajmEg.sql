/*
	Objetivo: Elimina aplicaciones

	----TEST

	[Operacion].[DEL_APLICACION_SP] '<Ids><aplicacionId>7</aplicacionId></Ids>'
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor				Descrición
	21/10/20		Antonio GUerra		Creación del SP
*/
CREATE PROCEDURE [Operacion].[DEL_APLICACION_SP]
	@xmlAplicacion			XML
AS
BEGIN

	DECLARE @msj		varchar(50) = '', 
			@status		int = 0

    DECLARE @tbl_propiedades AS TABLE(
        idAplicacion			INT
    )

	INSERT INTO @tbl_propiedades
    SELECT
        I.N.value('.','int')
        FROM @xmlAplicacion.nodes('/Ids/aplicacionId') AS I(N)


	--select * from @tbl_propiedades

	UPDATE Catalogo.Aplicacion SET activo = 0
	WHERE id in (SELECT idAplicacion from @tbl_propiedades)

	set @status = 1;
	SET @msj = 'Aplicación eliminada correctamente';

	SELECT @status AS Estado, @msj AS msj;
	
END
go

