/*
	Objetivo: Obtener la Información de un usuario con sus roles y aplicaciones
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	20/10/2020		Antonio Guerra		Obtener roles y aplicaciones por usuario

  *** TEST
  EXEC  [seguridad].[SEL_ROL_USUARIO_SP]
	@idUsuario = 19,
	@err = NULL
*/
CREATE PROCEDURE [seguridad].[SEL_ROL_USUARIO_SP]
	@idUsuario		INT , 
	@err			varchar(500) = null output   
AS
BEGIN

		SELECT *
		FROM catalogo.Aplicacion A
		INNER JOIN relacion.UsuarioRol U ON U.aplicacionId = A.id
		where usuarioId = @idUsuario
		AND activo = 1

		SELECT *
		FROM relacion.UsuarioRol UR
		INNER JOIN catalogo.Rol R ON R.id = UR.rolId
		where usuarioId = @idUsuario
		and activo = 1
END
go

