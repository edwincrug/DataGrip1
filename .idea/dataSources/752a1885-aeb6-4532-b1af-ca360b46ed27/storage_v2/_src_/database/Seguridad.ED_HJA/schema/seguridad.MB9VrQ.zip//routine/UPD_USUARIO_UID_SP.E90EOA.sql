-- =============================================
-- Author:		Antonio Guerra
-- Create date: 05/10/2020
-- Description:	Actualiza UID de usuario
-- =============================================
create PROCEDURE [seguridad].[UPD_USUARIO_UID_SP]
	@UserId		INT = NULL,
	@UID		VARCHAR(30) = ''
AS
BEGIN
	SET NOCOUNT OFF;

	DECLARE	
		@VC_ErrorMessage	NVARCHAR(4000)	= '',
		@VC_ThrowMessage	NVARCHAR(100)	= 'Ha ocurrido un error en [UPD_USUARIO_UID_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_ResultCount		INT = 0

	BEGIN TRY
		BEGIN TRANSACTION UPD_USUARIO_UID_SP
		
		UPDATE [catalogo].[Usuario]
		SET [UID] = @UID
		WHERE id = @UserId

		SET @VI_ResultCount = @@ROWCOUNT
		COMMIT TRANSACTION UPD_USUARIO_UID_SP
	END TRY
	BEGIN CATCH
		SELECT  
			@VC_ErrorMessage	= ERROR_MESSAGE(),
			@VC_ErrorSeverity	= ERROR_SEVERITY(),
			@VC_ErrorState		= ERROR_STATE();
		BEGIN
			ROLLBACK TRANSACTION UPD_USUARIO_UID_SP
			SET @VC_ErrorMessage = { 
				fn CONCAT(
					@VC_ThrowMessage,
					@VC_ErrorMessage
				) 
			}
			RAISERROR (
				@VC_ErrorMessage, 
				@VC_ErrorSeverity, 
				@VC_ErrorState
			);
		END
	END CATCH
	RETURN @VI_ResultCount
END
go

