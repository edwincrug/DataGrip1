/*
	Objetivo: Devuelve las aplicaciones o apliación seleccionada
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
*/
CREATE PROCEDURE [operacion].[SEL_APLICACION_ALL_SP]
AS
BEGIN

	SELECT 
		A.id AS IdApp, 
		A.nombre AS NombreApp, 
		A.tipoAplicacionId AS IdTApp, 
		TA.nombre AS NombreTApp,
		A.descripcion,
		(SELECT  count([usuarioId]) FROM [Seguridad].[relacion].[UsuarioRol] where [AplicacionId] = A.Id) as totalUsuario,
		A.URLProduccion
		FROM catalogo.Aplicacion AS A
		LEFT JOIN Catalogo.tipoAplicacion AS TA ON A.tipoAplicacionId = TA.id 
		WHERE a.activo = 1
		ORDER BY A.id

END
go

