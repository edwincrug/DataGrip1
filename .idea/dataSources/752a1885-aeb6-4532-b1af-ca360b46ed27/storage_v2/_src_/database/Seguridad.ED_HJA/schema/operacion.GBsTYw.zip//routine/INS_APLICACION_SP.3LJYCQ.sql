/*
	Objetivo: Inserta una aplicación
	
	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición
	21/10/20			Antonio Guerra		Creación del SP
*/
CREATE PROCEDURE [operacion].[INS_APLICACION_SP]
	@nombre				VARCHAR(50),
	@URL				VARCHAR(500),
	@descripcion		VARCHAR(500),
	@idTipoAplicacion	INT
		
AS
BEGIN

	DECLARE @msj		varchar(50) = '', 
			@status		int = 0

	INSERT INTO [Catalogo].[Aplicacion] (nombre, tipoAplicacionId, uRLProduccion, descripcion, activo)
	SELECT
		@nombre	
		,@idTipoAplicacion		
		,@URL			
		,@descripcion		
		,1	

	set @status = 1;
	SET @msj = 'Aplicación agregada correctamente';

	SELECT @status AS Estado, @msj AS msj;
END
go

