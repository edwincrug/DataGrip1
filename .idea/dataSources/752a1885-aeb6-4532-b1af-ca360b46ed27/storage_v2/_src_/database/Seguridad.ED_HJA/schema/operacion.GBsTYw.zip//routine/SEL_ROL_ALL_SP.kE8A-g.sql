/*
	Objetivo: Obtiene los roles o rol especificado
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
*/
CREATE PROCEDURE [operacion].[SEL_ROL_ALL_SP]

AS
BEGIN
	
		SELECT 
			R.id as rolId
			,R.nombre AS Rol
			,R.aplicacionId
			,A.nombre AS Aplicacion
			,TA.nombre AS TApp 
			,r.descripcion
		FROM Catalogo.Rol AS R 
			LEFT JOIN Catalogo.Aplicacion AS A ON R.aplicacionId = A.id AND A.activo = 1
			LEFT JOIN Catalogo.TipoAplicacion AS TA ON A.tipoAplicacionId = TA.id
			WHERE R.activo = 1
			ORDER BY R.id 

END
go

