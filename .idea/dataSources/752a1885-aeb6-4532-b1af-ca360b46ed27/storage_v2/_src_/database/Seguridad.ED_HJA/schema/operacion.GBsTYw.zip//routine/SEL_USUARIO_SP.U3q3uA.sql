/*
	Objetivo:	Devuelvelos datos del usuario
				DataSet[0] = Datos de usuario
				DataSet[1] = Operaciones a las que el usuario tiene derecho
				DataSet[2] = Direcciónes del usuario
				DataSet[3] = Permiso de la opción 
				DataSet[4] = Roles a los que tien acceso 
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición


	Testing
	[Operacion].[SEL_USUARIO_SP] 
	1
	,'eyJhbGciOiJSUzI1NiIsImtpZCI6IjBlM2FlZWUyYjVjMDhjMGMyODFhNGZmN2RjMmRmOGIyMzgyOGQ1YzYiLCJ0eXAiOiJKV1QifQ.eyJuYW1lIjoiQW50b25pbyIsImlzcyI6Imh0dHBzOi8vc2VjdXJldG9rZW4uZ29vZ2xlLmNvbS9jb2FsLWRjMjZmIiwiYXVkIjoiY29hbC1kYzI2ZiIsImF1dGhfdGltZSI6MTYwMzEzMjMzOCwidXNlcl9pZCI6IkFRZFFtWk0wSE9TQzY3RzBndEU2cGZRemJ5TDIiLCJzdWIiOiJBUWRRbVpNMEhPU0M2N0cwZ3RFNnBmUXpieUwyIiwiaWF0IjoxNjAzMTMyMzM4LCJleHAiOjE2MDMxMzU5MzgsImVtYWlsIjoiYW50b25pby5ndWVycmEyMDg5QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwicGhvbmVfbnVtYmVyIjoiKzUyNTUxMTIyMjExMyIsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnsicGhvbmUiOlsiKzUyNTUxMTIyMjExMyJdLCJlbWFpbCI6WyJhbnRvbmlvLmd1ZXJyYTIwODlAZ21haWwuY29tIl19LCJzaWduX2luX3Byb3ZpZGVyIjoicGFzc3dvcmQifX0.pF3SGuykE7xUzUn3WtM4gOqFQPmBIcFuM12ZJ5bQQAMJBBZtpD8YiYKBXg9v_3cbm31eO-z_Hu5je_thts4FMp5zHcDrfTYRevkiw8eBp2a2aNQ6v8eC6TfLXa3DAto2h0pmVHo9TpU66Ok1xOgeSeVE3PLklO4lCWTWLHciXGF9L-07Ziv_bY3YiMXhWgMExw2EcIrku1V5DJwv4yI9kyJzEIVs83ZTQ_KT1LU_pcivJY73wWwHvKoXdL7KB7O8nzgdPYS6H0iPSMoO7zAT-9yTpW24btSDmRIlG2czPOn9YHRTr-vB_cJW05pvMJM88DWf9dsX1bQaNlRJi1nvBw'
	,'login'

*/
CREATE PROCEDURE [operacion].[SEL_USUARIO_SP]
	@aplicacionId int,		-- Los permisos son por aplicación 
	@bearerToken varchar(max),	-- Se el puede mandar el token activo 
	@opcion varchar(max)
AS
BEGIN
	DECLARE @usuarioId INT = 0,
			@Option varchar(max) = @opcion,
			@B_Log INT = 0;

	IF @opcion = 'login'
	BEGIN
		SELECT @Option=[Nombre] FROM [catalogo].[Aplicacion] WHERE [Id] = @aplicacionId;
		SET @B_Log = 1;
	END
	print @Option;

	IF LEN(@bearerToken)>1
	BEGIN
		IF exists ( SELECT usuarioId AS user_id FROM [operacion].[AccessToken]
					INNER JOIN catalogo.Usuario AS us ON us.id = usuarioId
					WHERE [accessToken] =  @bearerToken
						AND	estatusId = 1
		)
		BEGIN 
			SELECT @usuarioId = usuarioId FROM [operacion].[AccessToken]
			INNER JOIN catalogo.Usuario AS us ON us.Id = usuarioId
			WHERE [accessToken] =  @bearerToken
				AND	estatusId = 1
		END	
	END
	print @usuarioId
	print @bearerToken
	IF @usuarioId>0
	BEGIN 
		-- Guardo la bitácora
		INSERT INTO [Operacion].[AccessUsuario](
			  [usuarioId]
			, [aplicacionId]
			, [accessToken]
			, [fecha]
			, [b_Log]
			, [accion]
		) VALUES(
			  @usuarioId
			, @aplicacionId
			, @bearerToken
			, GETDATE()
			, @B_Log
			, @opcion); 

		-- DataSet[0]
		SELECT
			[id] 
		  , [userName]
		  , [password]
		  , [primerNombre]
		  , [segundoNombre]
		  , [primerApellido]
		  , [segundoApellido]
		  , [email]
		  , [celular]
		  , [estatusId]
		  , [fechaRegistro]
		  --, [PromocionActivo]
		  , [passExpire]
		  , @bearerToken AS [bearerToken] 
		  , ((SELECT valor FROM Common.configuracion.Configuracion WHERE nombre = 'fileServer')+(SELECT path FROM FileServer.documento.Documento WHERE idDocumento = [US].[avatar])) avatar
		  --, [lastLogin]
		  , [twoFactorAuth]
	  FROM [catalogo].[Usuario] US
	  WHERE [id] = @usuarioId
	    AND [EstatusId] = 1
	;
		-- DataSet[1]
		SELECT null--[OperacionesId] FROM [Relacion].[Operaciones_User] WHERE [AplicacionesId]= @aplicacionesId and [UsersId] = @User_ID;
		
		-- DataSet[2]
		SELECT 0

		-- DataSet[3]
		
		-- Buscamos si es Aplicacion, Modulo o Campo.
		-- Si es aplicaciín 
		-- Se debe cambiar el SELECT * ya que ocupa mas memoria al ejecuarse.
		IF EXISTS (SELECT * FROM [catalogo].[Aplicacion]  )
		BEGIN
			SELECT distinct 
				c_Ap.Id,
				r_RO.aplicacionId,
			--	r_RO.RolId,
				TipoObjetoId,
				moduloId,
				campoId,
				--r_RO.Authorized,
				usuarioId,
				c_AP.id,
				TipoAplicacionId,
				c_Ap.Nombre,
				c_TA.Nombre as Tipo
			FROM [Seguridad].[relacion].[RolObjeto] AS r_RO
			INNER JOIN [Seguridad].[relacion].[UsuarioRol] AS r_UR ON r_RO.rolId = r_UR.rolId
			INNER JOIN [catalogo].[Aplicacion] AS c_Ap ON r_RO.aplicacionId = c_Ap.Id
			INNER JOIN [Catalogo].[TipoAplicacion] AS c_TA ON c_TA.id = c_Ap.tipoAplicacionId
			WHERE	 r_RO.aplicacionId = @aplicacionId
				AND R_UR.aplicacionId = @aplicacionId		
				AND r_RO.tipoObjetoId = 1 -- Tipo Aplicaccion
		END
		-- Si es módulo
		ELSE IF EXISTS (SELECT * FROM [catalogo].[Modulo] WHERE [nombre] = @Option)
		BEGIN
			SELECT 
				c_Mo.Id,
				r_RO.aplicacionId,
		--		r_RO.RolId,
				TipoObjetoId,
				c_Mo.moduloId,
				campoId,
				--r_RO.Authorized,
				usuarioId,
				r_RO.aplicacionId,
				c_Mo.Nombre,
				c_TO.Nombre as Tipo,
				c_Mo.Caption
			FROM [Seguridad].[relacion].[RolObjeto] AS r_RO
			INNER JOIN [Seguridad].[relacion].[UsuarioRol] AS r_UR ON r_RO.RolId = r_UR.RolId
			INNER JOIN [catalogo].[Modulo] AS c_Mo ON r_RO.aplicacionId=c_Mo.aplicacionId and r_RO.moduloId = c_Mo.Id
			INNER JOIN [catalogo].[TipoObjeto] AS c_TO ON c_TO.Id = r_RO.TipoObjetoId
			WHERE r_RO.aplicacionId = @aplicacionId	
				AND	 r_UR.usuarioId = @usuarioId
				AND r_RO.tipoObjetoId >= 2 AND r_RO.tipoObjetoId <= 3 -- Tipo Modulo o antalla
				AND c_Mo.Nombre = @Option
		END
		-- Si es un campo
		ELSE IF EXISTS (SELECT * FROM [catalogo].[Campo] WHERE [nombre] = @Option)
		BEGIN
			SELECT distinct
				c_Ca.id,
				r_RO.aplicacionId,
				r_RO.rolId,
				tipoObjetoId,
				c_Ca.moduloId,
				c_Ca.campoId,
				--r_RO.Authorized,
				usuarioId,
				r_RO.aplicacionId,
				c_Ca.nombre,
				c_TC.nombre as Tipo,
				c_Ca.caption
			FROM [Seguridad].[relacion].[RolObjeto] AS r_RO
			INNER JOIN [Seguridad].[relacion].[UsuarioRol] AS r_UR ON r_RO.RolId = r_UR.RolId
			INNER JOIN [catalogo].[Campo] AS c_Ca ON r_RO.aplicacionId=c_Ca.aplicacionId and r_RO.moduloId = c_Ca.moduloId and r_RO.campoId = c_Ca.Id
			INNER JOIN [catalogo].[TipoCampo] AS c_TC ON c_TC.Id = c_Ca.tipoCampoId
			WHERE	r_RO.aplicacionId = @aplicacionId		
				AND r_UR.usuarioId = @usuarioId
				AND r_RO.tipoObjetoId > 3  -- Tipo Campos
				AND c_Ca.nombre = @Option
		END
		
		-- DataSet[4]

		SELECT 
			[RolId] as RolId,  -- para conservar retrocompatibilidad con seguridad v1
			[RolId] as id,
			CR.Nombre as nombre
		FROM [Relacion].[UsuarioRol] UR
		INNER JOIN [Catalogo].[Rol] AS CR ON CR.aplicacionId = UR.aplicacionId AND CR.Id = UR.RolId
		WHERE  UR.aplicacionId = @aplicacionId AND [usuarioId] = @usuarioId;
	END
	ELSE
	BEGIN
	-- DataSet[0]
		SELECT 0 as UsersId, 'No se encontro al usuario' as Msj, @bearerToken as bearerToken;
		
		-- DataSet[1]
		SELECT 0 as UsersId, 'No se encontro al usuario';
		
		-- DataSet[2]
		SELECT 0 as UsersId, 'No se encontro al usuario';

		-- DataSet[3]
		SELECT 0 as UsersId, 'No se encontro al usuario';

		-- DataSet[4]
		SELECT 0 as UsersId, 'No se encontro al usuario';
	END
END
go

