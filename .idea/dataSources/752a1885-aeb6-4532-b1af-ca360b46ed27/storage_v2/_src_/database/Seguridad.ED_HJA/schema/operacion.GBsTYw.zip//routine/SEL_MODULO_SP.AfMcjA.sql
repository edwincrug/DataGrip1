/*
	Objetivo: Devuelve los modulos 
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor			Descrición
	22/10/20		Antonio Guerra	Creación del SP
*/
CREATE PROCEDURE [Operacion].[SEL_MODULO_SP] 
	@idAplicacion int
AS
BEGIN
	SELECT  
		AplicacionId
		,Id
		,Nombre
		,ModuloId 
		,Caption
		,Clave
	FROM [Catalogo].[Modulo] 
	WHERE aplicacionId= @idAplicacion
	AND activo = 1

	

END
go

