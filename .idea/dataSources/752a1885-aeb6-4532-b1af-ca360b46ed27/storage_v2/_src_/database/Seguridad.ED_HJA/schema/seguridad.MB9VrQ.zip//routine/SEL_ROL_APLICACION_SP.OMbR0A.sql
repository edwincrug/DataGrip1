-- =============================================
-- Author:		Antonio GUerra
-- Create date: 21/10/2010
-- Description:	Obtiene roles de aplicacion
-- Test:		exec [SEGURIDAD].[SEL_ROL_APLICACION_SP] 1
-- =============================================

CREATE PROCEDURE [SEGURIDAD].[SEL_ROL_APLICACION_SP]
	@idAplicacion	INT
AS
BEGIN


		SELECT  
			[RO].[ID] AS RolId
			, [RO].[Nombre]	 AS Rol
			, [RO].[Descripcion] AS Descripcion
			, aplicacionId AS AplicacionId
		FROM  [Seguridad].[Catalogo].[Rol] AS [RO] 
		WHERE [RO].aplicacionId = @idAplicacion 
		AND [RO] .activo = 1
	
 

END
go

