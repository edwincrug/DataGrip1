/*
	Objetivo: Devuelve los tipo de aplicacion
	
	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición
	21/10/20			Antonio Guerra		Creación del SP
*/
CREATE PROCEDURE [Operacion].[SEL_TIPOAPLICACION_SP]
AS
BEGIN
	Select 
		* 
	from [Seguridad].[Catalogo].[TipoAplicacion] 
END
go

