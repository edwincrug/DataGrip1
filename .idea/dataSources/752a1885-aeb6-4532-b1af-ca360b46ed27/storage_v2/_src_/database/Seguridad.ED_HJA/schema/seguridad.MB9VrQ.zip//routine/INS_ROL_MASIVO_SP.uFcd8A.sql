-- ================================== ===========  
-- Author:  Uriel Hernandez
-- Create date: 11/10/2020
-- sd  
-- Description: Inserta roles de forma masiva
/*  
 *- Testing...  
   
 EXEC [SEGURIDAD].[INS_ROL_MASIVO_SP]  
	'<propiedades><propiedad><index>0</index><valor>0</valor><propiedadDesc>index</propiedadDesc><id>0</id></propiedad><propiedad><index>0</index><valor>Cliente</valor><propiedadDesc>Nombre rol</propiedadDesc><id>0</id></propiedad><propiedad><index>0</index><valor>Es un cliente</valor><propiedadDesc>Descripción</propiedadDesc><id>0</id></propiedad><propiedad><index>1</index><valor>1</valor><propiedadDesc>index</propiedadDesc><id>0</id></propiedad><propiedad><index>1</index><valor>Call center</valor><propiedadDesc>Nombre rol</propiedadDesc><id>0</id></propiedad><propiedad><index>1</index><valor>Es un call center</valor><propiedadDesc>Descripción</propiedadDesc><id>0</id></propiedad></propiedades>',
	'Concatenar',
	3,
	''
  
  */  
-- =============================================  
CREATE PROCEDURE [seguridad].[INS_ROL_MASIVO_SP]   
 @propiedades   XML,  
 @idTipoAccion   nvarchar(50),  
 @idUsuario     int,  
 @err     varchar(max) OUTPUT  
  
AS 
	BEGIN TRY
		BEGIN TRANSACTION
			create TABLE #tbl_propiedades(  
				_row				INT IDENTITY(1,1),  
				i					INT,
				valor               VARCHAR(max),  
				propiedadDesc		varchar(max),
				id					INT
			 )

			INSERT INTO #tbl_propiedades(
			 i,   
			 valor,  
			 propiedadDesc,  
			 id)
			 
			 SELECT  
			   ParamValues.col.value('index[1]','int'), 
			   ParamValues.col.value('valor[1]','varchar(max)'),  
			   ParamValues.col.value('propiedadDesc[1]','varchar(max)'),  
			   CASE WHEN @idTipoAccion = 'Actualizar' THEN ParamValues.col.value('idIns[1]','int')  
			   ELSE 0 END  
			 FROM @propiedades.nodes('propiedades/propiedad') AS ParamValues(col)  

			DECLARE @columns nvarchar(MAX);
			DECLARE @sql nvarchar(MAX)
 
			SET @columns = STUFF(
			(
			SELECT
			',' + QUOTENAME(LTRIM(propiedadDesc))
			FROM
			(SELECT DISTINCT propiedadDesc
			FROM #tbl_propiedades
			where propiedadDesc not in ('index')
			) AS T
			ORDER BY
			propiedadDesc
			FOR XML PATH('')
			), 1, 1, '');

 
			-- En la variable @sql tenemos la consulta completa 
			-- Llamamos a Exec sp_executeSql con la consulta.

			 DECLARE @contador INT = 0,
			 @index INT = (SELECT MAX(valor) FROM #tbl_propiedades WHERE propiedadDesc = 'index')
			 ,@nombre varchar(max)
			 ,@descripcion varchar(max)
			 select @index

			 IF(@idTipoAccion = 'Concatenar')
			 BEGIN
				SET @sql = N'
					insert into catalogo.Rol (aplicacionId, '+@columns+')
					 SELECT 
					   1, '+ @columns +'
					  FROM
					  (  
						SELECT  i, valor, propiedadDesc, id
					 FROM #tbl_propiedades
			 
					  ) AS T
					  PIVOT   
					  (
					  max(valor)
					  FOR propiedadDesc IN (' + @columns + N')
					  ) AS P';
				  EXEC sp_executesql @sql;
			 END
			 IF(@idTipoAccion = 'Actualizar')
			 BEGIN
				SET @sql = N'
					UPDATE catalogo.Rol
					SET 
						nombre = p.nombre,
						descripcion = p.descripcion
					  FROM
					  (  
						SELECT  i, valor, propiedadDesc
					 FROM #tbl_propiedades
					  ) AS T
					  PIVOT   
					  (
					  max(valor)
					  FOR propiedadDesc IN (' + @columns + N')
					  ) AS P
					  where catalogo.Rol.id = p.id';
				  EXEC sp_executesql @sql;
			 END
			 DROP TABLE #tbl_propiedades
		COMMIT
	END TRY

	BEGIN CATCH  
		SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
		SELECT @err  
	ROLLBACK  
END CATCH
go

