-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <08/10/2020>
-- Description:	<Alta de Integridades>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 

	--Test

*/

CREATE TRIGGER [catalogo].[INS_USUARIO_TG] 
   ON  [catalogo].[Usuario]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;

	
	DECLARE @id INT,
			@UID varchar(50),
			@userName varchar(50), 
			@email varchar(max),
			@VC_ThrowTable		VARCHAR(300) = ''
	;

	SELECT @id = id, @UID = [UID], @userName = userName,  @Email=email FROM inserted;

	--Cliente
	BEGIN TRANSACTION;
	BEGIN TRY

		--SET @VC_ThrowTable = '[Excepcion].[Excepcion].[Usuario]';
		--INSERT INTO [Excepcion].[Excepcion].[Usuario] (idUsuario)
		--VALUES (@id);

	COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		PRINT 'ERROR EN TRIGGER INS_USUARIO_TG'
	END CATCH
	
END
go

