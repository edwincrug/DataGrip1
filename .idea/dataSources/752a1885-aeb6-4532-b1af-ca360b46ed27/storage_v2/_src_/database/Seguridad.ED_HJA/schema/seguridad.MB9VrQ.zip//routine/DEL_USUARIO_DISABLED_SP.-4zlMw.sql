-- =============================================
-- Author:		Antonio Guerra
-- Create date: 05/10/2020
-- Description:	Desactiva usuario
-- Test:	
/*	

	exec [seguridad].[DEL_USUARIO_ID_SP]
@dataUser =  '<Ids><userId>1</userId></Ids><Ids><userId>2</userId></Ids>'


*/

-- =============================================
CREATE PROCEDURE [seguridad].[DEL_USUARIO_DISABLED_SP]
	@dataUser			XML
AS
BEGIN
	--SET NOCOUNT OFF;

	DECLARE	
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ha ocurrido un error en [DEL_USUARIO_DISABLED_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_ResultCount		INT = 0
-- declaro  una tabla temporal para guardar el conjunto de aplicaciones y roles

		DECLARE @Users TABLE (
		_row			INT IDENTITY(1,1),
		idUser			INT,
		uid				varchar(50)
		);


		INSERT INTO @Users (idUser)
		SELECT
			ParamValues.col.value('userId[1]','int')
			FROM @dataUser.nodes('Ids') AS ParamValues(col);

		update @Users set uid = (select UID from [seguridad].[Catalogo].[Usuario] where idUser = Id)

		DECLARE @cont		INT = 1;

		WHILE((SELECT COUNT(*) FROM @Users)>= @cont)
		-- inicio de while
		BEGIN
			DECLARE @UserId		INT;	
			SELECT @UserId = idUser
			FROM @Users
			WHERE _row = @cont

			UPDATE [Catalogo].[Usuario]
			SET [EstatusId] = 3
			WHERE [Catalogo].[Usuario].[Id] = @UserId

			SET @cont = @cont + 1
		END

	select * from @Users
END
go

