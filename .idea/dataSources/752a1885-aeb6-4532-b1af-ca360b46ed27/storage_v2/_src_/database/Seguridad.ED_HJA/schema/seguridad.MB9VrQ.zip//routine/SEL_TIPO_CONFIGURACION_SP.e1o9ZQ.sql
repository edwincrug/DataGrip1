-- =============================================
-- Author:		Uriel Hernanez
-- Create date: 06/10/20	20
-- Description:	.
-- =============================================
CREATE PROCEDURE [seguridad].[SEL_TIPO_CONFIGURACION_SP]
	@Type		VARCHAR(50) = ''
AS
BEGIN
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET NOCOUNT ON;

	SELECT 
	   [aplicacionId]
      ,[campo]
      ,[tipo]
      ,[valor]
	FROM [operacion].[Configuracion]
	WHERE [tipo] = @Type

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

