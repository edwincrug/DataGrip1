-- =============================================
-- Author:		Antonio Guerra
-- Create date: 05/10/2020
-- Description:	Borra usuario por id.
-- Test:		exec [seguridad].[DEL_USUARIO_ID_SP] 1
-- =============================================
CREATE PROCEDURE [seguridad].[DEL_USUARIO_ID_SP]
	@UserId		INT = NULL
AS
BEGIN
	SET NOCOUNT OFF;

	DECLARE	
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ha ocurrido un error en  [DEL_USUARIO_ID_SP',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_ResultCount		INT = 0

	BEGIN TRY
		BEGIN TRANSACTION DEL_USUARIO_ID_SP
		
		DELETE FROM [operacion].[AccessToken]
		WHERE [usuarioId] = @UserId

		--DELETE FROM [Operacion].[Access_User]
		--WHERE [UsersId] = @UserId

		DELETE FROM [relacion].[UsuarioRol]
		WHERE [usuarioId] = @UserId

		DELETE FROM [Catalogo].[Usuario]
		WHERE [Id] = @UserId

		SET @VI_ResultCount = @@ROWCOUNT
		COMMIT TRANSACTION DEL_USUARIO_ID_SP
	END TRY
	BEGIN CATCH
		SELECT  
			@VC_ErrorMessage	= ERROR_MESSAGE(),
			@VC_ErrorSeverity	= ERROR_SEVERITY(),
			@VC_ErrorState		= ERROR_STATE();
		BEGIN
			ROLLBACK TRANSACTION DEL_USUARIO_ID_SP
			SET @VC_ErrorMessage = { 
				fn CONCAT(
					@VC_ThrowMessage,
					@VC_ErrorMessage
				) 
			}
			RAISERROR (
				@VC_ErrorMessage, 
				@VC_ErrorSeverity, 
				@VC_ErrorState
			);
		END
	END CATCH
	RETURN @VI_ResultCount
END
go

