/*
	Objetivo: Devuelve la aplicacion por id
	
	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición
	21/10/20			Antonio Guerra		Creación del SP
*/
CREATE PROCEDURE [Operacion].[SEL_APLICACION_ID_SP]
	@idAplicacion int
AS
BEGIN

	SELECT 
	*
	FROM Catalogo.Aplicacion
	WHERE id = @idAplicacion
	AND activo = 1
	
END
go

