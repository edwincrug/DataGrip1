/*
	Objetivo: inserta un rol

	-----TEST
	[Operacion].[INS_ROL_SP]
	@idAplicacion= 3,
	@nombre= 'prueba',
	@descripcion = null,
	@xmlModulo='<Modulos><modulo><idModulo>3</idModulo></modulo></Modulos>',
	@xmlCampo='<Campos><campo><idModulo>4</idModulo><idCampo>6</idCampo></campo><campo><idModulo>4</idModulo><idCampo>7</idCampo></campo></Campos>'
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	22/10/20		Antonio Guerra	Creación del SP
*/
CREATE PROCEDURE [Operacion].[INS_ROL_SP]
	@idAplicacion int,
	@nombre varchar(50),
	@descripcion		VARCHAR(500),
    @xmlModulo			XML,
	@xmlCampo			XML
AS
BEGIN

	DECLARE @tbl_modulos AS TABLE(
        _row                    INT IDENTITY(1,1),
		idModulo				INT
    )

	DECLARE @tbl_campos AS TABLE(
        _row                    INT IDENTITY(1,1),
		idModulo				INT,
		idCampo					INT
    )

    
	DECLARE @msj		varchar(50) = '', 
			@status		int = 0,
			@idRol		INT

	IF EXISTS(SELECT * FROM [Catalogo].[Rol] WHERE LOWER(Nombre) = LOWER(@nombre) AND AplicacionId = @idAplicacion )
		BEGIN
			SET @status = 0;
			SET @msj = 'El rol ya está registrado';
		END
	ELSE
		BEGIN 

		/***********************************SE INSERTA ROL*********************************************************/
			INSERT INTO [Catalogo].[Rol] 
			SELECT 
				@idAplicacion, 
				@nombre, 
				@Descripcion,
				1

			set @status = 1;
			SET @msj = 'Rol agregado correctamente';

			SET @idRol = @@IDENTITY

			/***********************************SE INSERTAN MODULOS*********************************************************/
			IF NOT EXISTS( SELECT id FROM [relacion].[RolObjeto]  WHERE aplicacionId = @idAplicacion AND rolId = @idRol AND TipoObjetoId = 1)
				BEGIN
					INSERT INTO [Relacion].[RolObjeto] 
					VALUES (@idAplicacion, @idRol, 1, NULL, NULL, 1, 1)
				END

			INSERT INTO @tbl_modulos
			SELECT
				ParamValues.col.value('idModulo[1]','INT')
				FROM @xmlModulo.nodes('Modulos/modulo') AS ParamValues(col)

			DECLARE @contModulos INT = 1

			WHILE((SELECT COUNT(*) FROM @tbl_modulos)>= @contModulos)

				BEGIN
					INSERT INTO [Relacion].[RolObjeto]
					SELECT 
						@idAplicacion,
						@idRol,
						(SELECT  ID FROM [catalogo].[TipoObjeto] WHERE NOMBRE = 'Modulo'),
						idModulo,
						NULL,
						2,
						1
					FROM @tbl_modulos
					WHERE _row = @contModulos

					SET @contMOdulos = @contMOdulos + 1
				END
					

	/***********************************SE INSERTAN CAMPOS*********************************************************/

			INSERT INTO @tbl_campos
			SELECT
				ParamValues.col.value('idModulo[1]','INT'),
				ParamValues.col.value('idCampo[1]','INT')
				FROM @xmlCampo.nodes('Campos/campo') AS ParamValues(col)

			DECLARE @contCampos INT = 1

			WHILE((SELECT COUNT(*) FROM @tbl_campos)>= @contCampos)

				BEGIN
					IF NOT EXISTS(SELECT 1 
									FROM [Relacion].[RolObjeto] 
									WHERE aplicacionId = @idAplicacion
									AND campoId IS NULL
									AND rolId = @idRol
									AND moduloId = (SELECT idModulo 
														FROM @tbl_campos
														WHERE _row = @contCampos))

						BEGIN
						select 'entra'
							INSERT INTO [Relacion].[RolObjeto]
							SELECT
								@idAplicacion
								,@idRol
								,(SELECT  ID FROM [catalogo].[TipoObjeto] WHERE NOMBRE = 'Modulo')
								,idModulo
								,NULL
								,1
								,1
							FROM @tbl_campos
							WHERE _row = @contCampos
						END
					INSERT INTO [Relacion].[RolObjeto]
					SELECT 
						@idAplicacion,
						@idRol,
						4,
						idModulo,
						idCampo,
						11,
						1	
					FROM @tbl_campos
					WHERE _row = @contCampos

					SET @contCampos = @contCampos + 1
				END


			--SELECT * FROM @tbl_modulos
			--SELECT * FROM @tbl_campos
		END

	SELECT @status AS Estado, @msj AS msj;
END
go

