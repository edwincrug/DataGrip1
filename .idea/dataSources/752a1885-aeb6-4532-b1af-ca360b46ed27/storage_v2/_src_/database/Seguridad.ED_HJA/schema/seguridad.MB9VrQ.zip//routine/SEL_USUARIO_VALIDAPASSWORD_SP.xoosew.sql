-- =============================================
-- Author:		Antonio Guerra
-- Create date: 05/10/2020
-- Description:	Valida un password de acuerdo a un token 
-- Test:		exec [seguridad].[SEL_USUARIO_VALIDAPASSWORD_SP] '',
-- =============================================
CREATE PROCEDURE [seguridad].[SEL_USUARIO_VALIDAPASSWORD_SP]
	@token		varchar(max),
	@password	varchar(max)
AS
BEGIN
	SET NOCOUNT OFF;

	DECLARE	
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ha ocurrido un error en [SEL_USUARIO_VALIDAPASSWORD_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_ResultCount		INT = 0

	BEGIN TRY
		BEGIN TRANSACTION 
		
		DECLARE @UserId INT;
		SELECT @UserId = [usuarioId] FROM [Operacion].[AccessToken] WHERE [AccessToken] = @token;

		IF EXISTS (
			SELECT TOP 1 [Id]
			FROM [Seguridad].[Catalogo].[Usuario]
			WHERE CONVERT(nvarchar(max), DECRYPTBYPASSPHRASE(N'Password Secret!', [Password])) = @password AND [Id] = @UserId
		)
		BEGIN
			SELECT 'ok' ok;
		END
		ELSE
		BEGIN
			SELECT 'fail' ok;
		END


		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		SELECT  
			@VC_ErrorMessage	= ERROR_MESSAGE(),
			@VC_ErrorSeverity	= ERROR_SEVERITY(),
			@VC_ErrorState		= ERROR_STATE();
		BEGIN
			ROLLBACK TRANSACTION 
			SET @VC_ErrorMessage = { 
				fn CONCAT(
					@VC_ThrowMessage,
					@VC_ErrorMessage
				) 
			}
			RAISERROR (
				@VC_ErrorMessage, 
				@VC_ErrorSeverity, 
				@VC_ErrorState
			);
		END
	END CATCH
	RETURN @VI_ResultCount
END
go

