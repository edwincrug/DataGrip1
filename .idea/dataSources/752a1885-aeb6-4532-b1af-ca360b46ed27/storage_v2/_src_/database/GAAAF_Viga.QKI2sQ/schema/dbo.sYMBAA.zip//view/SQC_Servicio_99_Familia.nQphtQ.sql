create view [dbo].[SQC_Servicio_99_Familia] as select * from GAAAF_Concentra.dbo.SQC_Servicio_99_Familia
go

