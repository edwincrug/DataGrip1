---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[ser_presupweb] AS 
SELECT 
prw_idpresuorden, prw_idordenbpro, prw_idcliente, prw_idclientefac, prw_noserie, prw_noinventario, prw_kilometraje, prw_fechaorden, prw_torre, prw_idasesor, prw_estatus, prw_fechapromesa, prw_idpoliza, prw_idaseguradora, prw_idsiniestro, prw_formapago, prw_observaciones, prw_nivel, prw_ivaorden, prw_foliogarantia, prw_iddivision, prw_idempresa, prw_idsucursal, prw_iddepartamento, prw_idusuario, prw_fechaoperacion, prw_noplacas, prw_colorext, prw_colorint, prw_idcatalogo, prw_catec, prw_nopresupuesto, cec_idestatuspresuint, prw_tiporden, prw_idcontacto, prw_horaautorizacion
FROM        CUENTASPORCOBRAR.dbo.ser_presupweb;
go

