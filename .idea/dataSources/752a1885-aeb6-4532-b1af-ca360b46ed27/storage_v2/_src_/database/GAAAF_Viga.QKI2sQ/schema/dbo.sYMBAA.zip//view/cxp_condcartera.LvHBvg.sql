create view [dbo].[cxp_condcartera] as select * from GAAAF_Concentra.dbo.cxp_condcartera
go

