create view 	[dbo].[CON_CARDETACON012007]	as select * from GAAAF_Concentra.dbo.CON_CARDETACON012007
go

