create view [dbo].[PER_AVISOPRIV] as select * from GAAAF_Concentra.dbo.PER_AVISOPRIV
go

