
create proc spOrdenesAbiertasd  as
Select e.ORE_FECHAORD, e.ORE_HORAORD
, TipoOrden =  isnull(d.TipoOrden, isnull(x.TipoOrden,'CLIENTES')) 
, e.ORE_IDORDEN,  e.ORE_IDCLIENTE
, e.ORE_IDCLIFAC, Nombre = case when p.per_tipo = 'MOR' then p.per_nomrazon else rtrim(p.per_nomrazon) + ' ' + rtrim(p.PER_PATERNO) + ' ' + rtrim(p.per_materno) end
, RFC = p.PER_RFC, Calle = p.PER_CALLE1, NUMEXT = p.PER_NUMEXTER, NUMINT = p.PER_NUMINER, Colonia = p.PER_COLONIA
, Deleg = p.PER_DELEGAC, CODPOST = p.PER_CODPOS, Ciudad = p.PER_CIUDAD
, Tel1 = p.PER_TELEFONO1, Tel2 = p.PER_TELEFONO2, Celular = p.PER_TELCELULAR, EMAIL = p.PER_EMAIL
, Status = isnull(pS.par_descrip1, e.ORE_STATUS)
, QTYSolicitada = isnull(d.QTYSolicitada,0), QTYSurtida = isnull(d.QTYSurtida,0), Hrs = isnull(d.Horas,0)
, CostoManoObra = isnull(d.CostoMOB,0), VCostoTOTs = isnull(d.CostoTOT,0), CostoVarios = isnull(d.CostoXVA,0), CostoOtros = isnull(d.CostoOTR,0) , CostoRefacciones = isnull(d.CostoREF,0) 
, VtaManoObra = isnull(d.VtaMOB,0) , VtaTOTs = isnull(d.VtaTOT,0), VtaVarios = isnull(d.VtaXVA,0), VtaOtros = isnull(d.VtaOTR,0) , VtaRefacciones = isnull(d.VtaREF,0) 
, Asesor = isnull(pA.par_descrip1, ORE_IDASESOR)
, Fechaprom = e.ORE_FECHAPROM, HoraProm = e.ORE_HORAPROM
, Catalogo = e.ore_idcatalogo, Año = veh.VEH_QCMODELO, Modelo = veh.VEH_QCTIPOAUTO, Serie = e.ORE_NUMSERIE
, Kms = e.ORE_KILOMETRAJE, Marca = e.ORE_MARCA, placas = e.ORE_NOPLACAS
, ColorExt = isnull(pCE.par_descrip1, e.ORE_QCCOLOEXTE), ColorInt = isnull(pCI.par_descrip1,e.ORE_QCCOLOINTE)
, IVAP = e.ORE_IVAORDEN
, Dias = DATEDIFF(day, e.ORE_FECHAORD, GETDATE())
, a01a30 = case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) < 31 then 1 else 0 end 
, a31a60 = case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) > 30 and  DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) < 61 then 1 else 0 end 
, a61a90 = case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) > 60 and  DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) < 91 then 1 else 0 end 
, a91a120 = case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) > 90 and  DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) < 121 then 1 else 0 end 
, amas120 = case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) > 120 then 1 else 0 end 
from SER_ORDEN e
Left Outer Join vpfOrdendet d on
    e.ORE_IDORDEN = d.ORD_IDORDEN  
LEFT Outer Join SER_VEHICULO veh on
    e.ORE_NUMSERIE = veh.VEH_NUMSERIE 
Left Outer Join PNC_PARAMETR pS on
    pS.PAR_TIPOPARA = 'SO'
and pS.PAR_IDENPARA = e.ORE_STATUS
Left Outer Join PNC_PARAMETR pA on
    pA.PAR_TIPOPARA = 'AS'
and pA. PAR_IDMODULO = 'SER'
and pA.PAR_IDENPARA =  e.ORE_IDASESOR
Left Outer Join PNC_PARAMETR  pCE on
    pCE.PAR_IDMODULO = 'SER'
and pCE.PAR_tipopara = 'COE'
and pCE.PAR_IDENPARA = e.ORE_qccoloexte 
Left Outer Join PNC_PARAMETR  pCI on
    pCI.PAR_IDMODULO = 'SER'
and pCI.PAR_tipopara = 'COI'
and pCI.PAR_IDENPARA = e.ORE_qccolointe 
Left Outer Join PER_PERSONAS p on
   p.Per_IDPersona = e.ORE_IDCLIFAC
Left Outer Join ade_vtafi  v On
   e.ORE_IDORDEN = v.VTE_REFERENCIA1
and v.VTE_STATUS = 'i'
Left Outer Join vpfOrdenX  x on
  e.ORE_IDORDEN = x.ORD_IDORDEN
where e.ORE_STATUS not in ('I','C')  --I Facturada, C Cancelada
order by e.ORE_IDORDEN


go

