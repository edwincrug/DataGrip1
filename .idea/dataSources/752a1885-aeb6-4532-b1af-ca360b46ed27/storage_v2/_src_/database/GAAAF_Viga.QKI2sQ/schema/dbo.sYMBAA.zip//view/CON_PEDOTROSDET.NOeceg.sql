create view [dbo].[CON_PEDOTROSDET] as select * from GAAAF_Concentra.dbo.CON_PEDOTROSDET
go

