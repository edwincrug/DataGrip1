create view [dbo].[cxp_condcred] as select * from GAAAF_Concentra.dbo.cxp_condcred
go

