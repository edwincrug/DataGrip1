create view [dbo].[SER_PAQHIS] as select * from GAAAF_Concentra.dbo.SER_PAQHIS
go

