
CREATE VIEW [dbo].[FAE_ASOCCATSAT] AS Select * From GAAAF_Concentra.dbo.FAE_ASOCCATSAT

go

