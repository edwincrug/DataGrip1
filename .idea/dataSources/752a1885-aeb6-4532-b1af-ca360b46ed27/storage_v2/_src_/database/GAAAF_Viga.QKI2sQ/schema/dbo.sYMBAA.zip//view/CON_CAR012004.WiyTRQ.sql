create view 	[dbo].[CON_CAR012004]	as select * from GAAAF_Concentra.dbo.CON_CAR012004
go

