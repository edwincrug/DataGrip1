CREATE VIEW [dbo].[ade_CfdiFolioRelacionado] AS SELECT * FROM GAAAF_Concentra.dbo.ade_CfdiFolioRelacionado
go

