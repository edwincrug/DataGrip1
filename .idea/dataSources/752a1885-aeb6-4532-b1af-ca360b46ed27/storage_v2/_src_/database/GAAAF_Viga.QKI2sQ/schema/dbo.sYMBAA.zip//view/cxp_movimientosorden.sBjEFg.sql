CREATE VIEW [dbo].[cxp_movimientosorden]
AS
SELECT 
mov_idmovimiento, mov_idusuariomovimiento, mov_fechamovimiento, mov_horamovimiento, oce_folioorden, sod_idsituacionorden
FROM       CUENTASXPAGAR.dbo.cxp_movimientosorden
go

