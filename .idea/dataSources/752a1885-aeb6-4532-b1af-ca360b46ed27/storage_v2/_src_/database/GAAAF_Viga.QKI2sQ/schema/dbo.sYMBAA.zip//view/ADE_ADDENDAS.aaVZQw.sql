create view [dbo].[ADE_ADDENDAS] as select * from GAAAF_Concentra.dbo.ADE_ADDENDAS
go

