CREATE   PROCEDURE SICOP_DEL_PROSPECTO
@p_str_id_prospecto NVARCHAR(15)
AS
BEGIN
DECLARE @SeBorra int
SET @SeBorra= (Select Count(*)  from [Cotizaciones y pedidos] where [Clave Prospecto]=@p_str_id_prospecto and [Pedido entregado]<>0)
IF @SeBorra=0
BEGIN
  Delete
  From Prospecto
  WHERE C_Clave= @p_str_id_prospecto
 End
Else
 BEGIN
  RAISERROR ('El registro no puede ser borrado ya que tiene ventas registradas!!!',16,1)
 End
End
go

