/* =============================================
 Author:		Tajín Salarich
 Create date:	22/11/2013
 Description:	Antigüedad de Inventario al Día.xls
 Versión:		1.0
 =============================================*/

CREATE PROCEDURE [dbo].[SPGET_AntiguedadInventario]
	@DB varchar(15) = db_name
AS

	select
		VEH_ANMODELO,VEH_NUMSERIE,VEH_NOMOTOR,'',p.PAR_DESCRIP1,VEH_FECRETIRO,Tbl_Costo.Vhd_Costo
	from
		ser_vehiculo
	left outer join
		uni_catalogo on Unc_IdCatalogo = VEH_CATALOGO and UNC_MODELO = Veh_Anmodelo 
	inner join
		PNC_PARAMETR p on unc_familia = p.PAR_IDENPARA and p.PAR_TIPOPARA='cli'
	outer apply
		(
			select sum(VHD_COSTO) Vhd_Costo
			from uni_vehdeta vhd
			where vhd_tipo in('TIPO2','TIPO3') and vhd_noserie=VEH_NUMSERIE
			group by vhd_noserie
		) Tbl_Costo
	Where
		veh_situacion in('FIS','TRAS','TRAN','SEP','PED','SINI') 
	order by p.PAR_DESCRIP1

go

