CREATE VIEW [dbo].[cat_prospecotiza]
AS
SELECT 
cpc_idprospcotiza, cpc_apepaterno, cpc_apematerno, cpc_nombrerazonsoc, cpc_rfc, cpc_tipopersona, cpc_calle, cpc_nointerno, cpc_noexterno, cpc_colonia, cpc_delegacion, cpc_ciudad, cpc_estado, cpc_cp, cpc_telefono, cpc_extension, cpc_celular, cpc_telefonoalt, cpc_email1, cpc_idclientebpro, cpc_usuarioalta, cpc_fechaalta, cpc_usuariomodifica, cpc_fechamodifica
FROM         GA_CORPORATIVA.dbo.cat_prospecotiza
go

