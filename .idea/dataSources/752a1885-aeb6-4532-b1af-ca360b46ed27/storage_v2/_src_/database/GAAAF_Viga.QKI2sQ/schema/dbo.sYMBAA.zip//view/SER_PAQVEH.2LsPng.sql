create view [dbo].[SER_PAQVEH] as select * from GAAAF_Concentra.dbo.SER_PAQVEH
go

