create view [dbo].[GAAAF_ConcentraPER_PERSONAS] as select * from GAAAF_Concentra.dbo.PER_PERSONAS
go

