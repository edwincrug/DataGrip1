create view [dbo].[PER_AVISOPRIVDEF] as select * from GAAAF_Concentra.dbo.PER_AVISOPRIVDEF
go

