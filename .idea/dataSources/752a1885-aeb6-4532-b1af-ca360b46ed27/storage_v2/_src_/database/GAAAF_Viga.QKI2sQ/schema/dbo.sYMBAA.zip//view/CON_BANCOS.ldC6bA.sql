create view [dbo].[CON_BANCOS] as select * from GAAAF_Concentra.dbo.CON_BANCOS
go

