CREATE VIEW [dbo].[cat_claveunidad] AS Select * From GAAAF_Concentra.dbo.cat_claveunidad
go

