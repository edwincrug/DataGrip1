create view [dbo].[PNC_CONCRED] as select * from GAAAF_Concentra.dbo.PNC_CONCRED
go

