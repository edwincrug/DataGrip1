CREATE VIEW [dbo].[cxp_detalleotrosconceptos]
AS
SELECT 
otc_iddetalle, otc_area, otc_cantidad, otc_cantidadrecibida, otc_cveusurecep, otc_producto, otc_preuni, otc_preuniinicial, otc_descuento, otc_iva, otc_total, otc_totalinicial, otc_concepto, oce_folioorden, otc_cveusu, otc_fechope, otc_poriva, otc_retiva, otc_retisr, otc_iddocto, otc_idsituacionordendet, otc_fechapromentrega, otc_horapromentrega, otc_cantidaddiferencia, otc_consecutivo, otc_saldocuentames, otc_presupuestomes, otc_excedentemes, otc_saldocuentaanio, otc_presupuestoanio, otc_excedenteanio, otc_comentarios, otc_nopedido
FROM        CUENTASXPAGAR.dbo.cxp_detalleotrosconceptos
go

