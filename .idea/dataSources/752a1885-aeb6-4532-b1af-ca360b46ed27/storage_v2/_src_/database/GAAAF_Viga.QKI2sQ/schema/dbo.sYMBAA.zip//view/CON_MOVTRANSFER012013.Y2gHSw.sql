create view [dbo].[CON_MOVTRANSFER012013] as select * from GAAAF_Concentra.dbo.CON_MOVTRANSFER012013
go

