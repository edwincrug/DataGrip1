create view [dbo].[CON_GCFDI012014] as select * from [GAAAF_Concentra].dbo.[CON_GCFDI012014]
go

