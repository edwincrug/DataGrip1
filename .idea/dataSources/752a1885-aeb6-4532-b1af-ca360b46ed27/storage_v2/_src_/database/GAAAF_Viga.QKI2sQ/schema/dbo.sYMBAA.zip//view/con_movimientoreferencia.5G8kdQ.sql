CREATE VIEW [dbo].[con_movimientoreferencia]
AS
SELECT   *
FROM         GAAAF_Concentra.dbo.con_movimientoreferencia
go

