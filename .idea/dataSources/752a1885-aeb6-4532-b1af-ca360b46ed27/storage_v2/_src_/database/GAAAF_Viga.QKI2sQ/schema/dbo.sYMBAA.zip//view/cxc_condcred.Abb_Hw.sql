create view [dbo].[cxc_condcred] as select * from GAAAF_Concentra.dbo.cxc_condcred
go

