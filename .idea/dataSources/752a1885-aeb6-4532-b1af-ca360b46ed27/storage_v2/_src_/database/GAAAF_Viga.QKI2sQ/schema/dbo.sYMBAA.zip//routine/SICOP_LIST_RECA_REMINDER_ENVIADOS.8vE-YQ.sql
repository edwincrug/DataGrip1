CREATE   PROCEDURE SICOP_LIST_RECA_REMINDER_ENVIADOS
  @p_str_clave_ejecutivo nvarchar(15)
As
SELECT ID_Registro,
Fecha,
Hora,
Observaciones
From
SICOP_Recados
Where
C_Promotor_Registro=@p_str_clave_ejecutivo and Reg_Borrado=0
Order By
Fecha Desc
go

