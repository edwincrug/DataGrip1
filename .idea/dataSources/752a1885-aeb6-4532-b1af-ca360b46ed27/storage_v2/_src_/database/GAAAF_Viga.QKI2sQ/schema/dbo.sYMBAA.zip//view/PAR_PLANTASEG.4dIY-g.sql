create view [dbo].[PAR_PLANTASEG] as select * from GAAAF_Concentra.dbo.PAR_PLANTASEG
go

