create view [dbo].[ADE_VTACFDMN] as select * from GAAAF_Concentra.dbo.ADE_VTACFDMN
go

