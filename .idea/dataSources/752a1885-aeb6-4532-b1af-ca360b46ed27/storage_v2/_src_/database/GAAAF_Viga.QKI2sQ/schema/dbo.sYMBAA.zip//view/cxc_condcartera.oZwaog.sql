create view [dbo].[cxc_condcartera] as select * from GAAAF_Concentra.dbo.cxc_condcartera
go

