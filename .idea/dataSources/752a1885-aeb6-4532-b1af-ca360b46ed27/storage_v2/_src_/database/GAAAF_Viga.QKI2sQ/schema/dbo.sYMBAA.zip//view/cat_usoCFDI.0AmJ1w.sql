
CREATE VIEW [dbo].[cat_usoCFDI] AS Select * From GAAAF_Concentra.dbo.cat_usoCFDI

go

