create view [dbo].[SQC_Servicio_2001_Familia] as select * from GAAAF_Concentra.dbo.SQC_Servicio_2001_Familia
go

