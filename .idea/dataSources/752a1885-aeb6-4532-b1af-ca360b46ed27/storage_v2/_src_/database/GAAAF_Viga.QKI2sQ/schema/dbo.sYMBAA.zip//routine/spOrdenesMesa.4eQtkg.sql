
create proc spOrdenesMesa (@Periodo varchar(6)) as
Select Tipoorden = isnull(d.TipoOrden, x.TipoOrden) 
, Status = isnull(pS.par_descrip1, e.ORE_STATUS)
, Total = COUNT(*)
from SER_ORDEN e
Left Outer Join vpfOrdendet d on
    e.ORE_IDORDEN = d.ORD_IDORDEN  
Left Outer Join PNC_PARAMETR pS on
    pS.PAR_TIPOPARA = 'SO'
and pS.PAR_IDENPARA = e.ORE_STATUS
Left Outer Join vpfOrdenX  x on
  e.ORE_IDORDEN = x.ORD_IDORDEN
where year(e.ORE_FECHAORD) = substring(@periodo,1,4) and MONTH(e.ORE_FECHAORD) = CAST(SUBSTRING(@periodo,5,2) AS int)
group by isnull(d.TipoOrden, x.TipoOrden)
, isnull(pS.par_descrip1, e.ORE_STATUS)
order by isnull(d.TipoOrden, x.TipoOrden)
, isnull(pS.par_descrip1, e.ORE_STATUS)
go

