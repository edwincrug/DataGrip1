create view [dbo].[ADE_CANCFDDETMN] as select * from GAAAF_Concentra.dbo.ADE_CANCFDDETMN
go

