create view [dbo].[PER_PRIVCONPLANTA] as select * from GAAAF_Concentra.dbo.PER_PRIVCONPLANTA
go

