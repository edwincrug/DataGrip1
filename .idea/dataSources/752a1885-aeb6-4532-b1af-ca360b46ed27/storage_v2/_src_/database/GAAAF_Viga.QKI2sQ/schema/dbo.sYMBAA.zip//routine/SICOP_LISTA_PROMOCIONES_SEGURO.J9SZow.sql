 Create proc SICOP_LISTA_PROMOCIONES_SEGURO
  @Producto nvarchar ( 15 ),
  @Año nvarchar  ( 4 ),
  @Paquete nvarchar  ( 5 ),
  @Finaciado nvarchar  ( 1 )
 As
 SELECT
   Distinct
   Promocion AS C_Clave,
   Promocion As N_Descripcion
 From
   SICOP_Seguros_Planes As a
 Where
  A.C_Producto = @Producto and
  A.año=@Año and
  A.Clave_Paquete=@Paquete and
  Tipo=@Finaciado
 go

