Create View [dbo].[cxp_ordenesmasivasdet] as select * from [GAAAF_Concentra].dbo.cxp_ordenesmasivasdet
go

