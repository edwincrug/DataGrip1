CREATE VIEW [dbo].[cat_claveprodserv] AS Select * From GAAAF_Concentra.dbo.cat_claveprodserv
go

