create view [dbo].[CON_GCFDI012015] as select * from [GAAAF_Concentra].dbo.[CON_GCFDI012015]
go

