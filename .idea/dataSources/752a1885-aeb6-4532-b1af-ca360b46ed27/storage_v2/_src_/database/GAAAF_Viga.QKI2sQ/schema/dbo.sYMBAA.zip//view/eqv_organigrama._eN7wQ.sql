CREATE VIEW [dbo].[eqv_organigrama]
AS
SELECT 
eqv_idorganigrama, eqv_usubusiness, eqv_ip, eqv_nombrebd, eqv_fechaalta, eqv_usualta, eqv_fechamodifica, eqv_usumodifica, eqv_estatus, gpo_idgrupo, div_iddivision, emp_idempresa, reg_idregion, suc_idsucursal, dep_iddepartamento, usu_usuario
FROM       [ControlAplicaciones].dbo.eqv_organigrama
go

