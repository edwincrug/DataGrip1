CREATE    PROC SICOP_UP_CONTADORES_POZO
AS
Update
Prospecto
set
Pre_pozo=0,
Dias_para_pozo=Null,
Fecha_pre_pozo = Null
go

