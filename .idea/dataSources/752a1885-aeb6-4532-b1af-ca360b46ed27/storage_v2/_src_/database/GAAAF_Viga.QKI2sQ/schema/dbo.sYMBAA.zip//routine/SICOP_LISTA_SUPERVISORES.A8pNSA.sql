CREATE PROC SICOP_LISTA_SUPERVISORES
@IdConce  nvarchar(3)=Null
As
SELECT
C_Clave
From
Promotor
Where
Supervisor<>0  and
IdConcesionario= isnull(@IdConce,  IdConcesionario)
go

