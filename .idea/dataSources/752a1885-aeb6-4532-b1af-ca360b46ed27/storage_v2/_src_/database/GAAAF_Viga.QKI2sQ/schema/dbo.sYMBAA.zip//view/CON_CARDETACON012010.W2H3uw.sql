create view 	[dbo].[CON_CARDETACON012010]	as select * from GAAAF_Concentra.dbo.CON_CARDETACON012010
go

