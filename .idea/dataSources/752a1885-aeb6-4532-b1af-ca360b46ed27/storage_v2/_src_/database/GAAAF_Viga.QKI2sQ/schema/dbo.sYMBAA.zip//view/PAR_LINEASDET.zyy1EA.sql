create view [dbo].[PAR_LINEASDET] as select * from GAAAF_Concentra.dbo.PAR_LINEASDET
go

