create view 	[dbo].[CON_POLDIRERR012010]	 as select * from GAAAF_Concentra.dbo.CON_POLDIRERR012010
go

