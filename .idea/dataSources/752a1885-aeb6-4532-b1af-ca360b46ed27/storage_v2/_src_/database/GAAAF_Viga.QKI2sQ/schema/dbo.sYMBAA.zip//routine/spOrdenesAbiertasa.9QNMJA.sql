
create proc spOrdenesAbiertasa  as
Select TipoOrden =  isnull(d.TipoOrden, isnull(x.TipoOrden,'CLIENTES')) 
, Status = isnull(pS.par_descrip1, e.ORE_STATUS)
, QTYSolicitada = sum(isnull(d.QTYSolicitada,0)), QTYSurtida = sum(isnull(d.QTYSurtida,0)), Hrs = sum(isnull(d.Horas,0))
, CostoManoObra = sum(isnull(d.CostoMOB,0)), VCostoTOTs = sum(isnull(d.CostoTOT,0)), CostoVarios = sum(isnull(d.CostoXVA,0)), CostoOtros = sum(isnull(d.CostoOTR,0)) , CostoRefacciones = sum(isnull(d.CostoREF,0) )
, VtaManoObra = sum(isnull(d.VtaMOB,0)) , VtaTOTs = sum(isnull(d.VtaTOT,0)), VtaVarios = sum(isnull(d.VtaXVA,0)), VtaOtros = sum(isnull(d.VtaOTR,0)) , VtaRefacciones = sum(isnull(d.VtaREF,0) )
, a01a30 = sum(case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) < 31 then 1 else 0 end )
, a31a60 = sum(case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) > 30 and  DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) < 61 then 1 else 0 end )
, a61a90 = sum(case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) > 60 and  DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) < 91 then 1 else 0 end )
, a91a120 = sum(case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) > 90 and  DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) < 121 then 1 else 0 end )
, amas120 = sum(case when DATEDIFF(day, e.ORE_FECHAORD, GETDATE()) > 120 then 1 else 0 end )
from SER_ORDEN e
Left Outer Join vpfOrdendet d on
    e.ORE_IDORDEN = d.ORD_IDORDEN  
Left Outer Join PNC_PARAMETR pS on
    pS.PAR_TIPOPARA = 'SO'
and pS.PAR_IDENPARA = e.ORE_STATUS
Left Outer Join vpfOrdenX  x on
  e.ORE_IDORDEN = x.ORD_IDORDEN
where e.ORE_STATUS not in ('I','C')  --I Facturada, C Cancelada
group by isnull(d.TipoOrden, isnull(x.TipoOrden,'CLIENTES')) , isnull(pS.par_descrip1, e.ORE_STATUS)
order by isnull(d.TipoOrden, isnull(x.TipoOrden,'CLIENTES')) , isnull(pS.par_descrip1, e.ORE_STATUS)
go

