CREATE VIEW [dbo].[GBitacoraUnifPersona]
AS 
SELECT 
IdPersonaNew, IdPersonaOld, NombreBase, Tabla, Campo, Cwhere
FROM GA_Corporativa.dbo.GBitacoraUnifPersona
go

