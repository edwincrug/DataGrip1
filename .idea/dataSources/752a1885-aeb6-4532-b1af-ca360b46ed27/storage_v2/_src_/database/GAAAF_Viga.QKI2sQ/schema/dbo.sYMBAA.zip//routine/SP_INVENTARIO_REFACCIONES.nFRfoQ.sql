
CREATE PROC SP_INVENTARIO_REFACCIONES
AS

DELETE FROM BI_INVENTARIO_REFACCIONES


INSERT INTO BI_INVENTARIO_REFACCIONES
select alm_existen as alm_existen,pts_modeloini as modeloini,pts_modelofin as modelofin, pts_idparte, pts_desparte, 
pts_pcolista, pts_cunrepo, pts_pcogarantia,alm_clasifica, pts_pcoflotillero, alm_ctoprom, a.par_descrip1 as grupo,
ISNULL(sgpo.PAR_DESCRIP1,'') as subgpo , isnull(b.par_descrip1,'no clasif.') as clasifica, alm_min, alm_max, 
c.par_descrip1 as almacen, vut_ubicacion as ubicacion, 0 as existencia,alm_fechulcom,alm_fechultven,alm_fechingre ,
(SELECT TOP 1 CNC_CUENTA from CON_CONFCONTA WHERE CNC_CONCEPTO2 = pts_grupo AND CNC_CONFIGURA LIKE '%COMPRA REFACCION%' 
AND CNC_CONFIGURA LIKE '%' +alm_idalma) AS CNC_CUENTA ,MN.PAR_DESCRIP1 AS MONEDAMN  ,
(CASE WHEN PTS_IDMONEDA = 'PE' THEN 1 ELSE (SELECT TOP 1 PTC_TIPOCAMBIO FROM PNC_TIPOCAMBIO WHERE PTC_MONEDA = 
PTS_IDMONEDA ORDER BY CONVERT(DATETIME, PTC_FECHOPE + ' ' + PTC_HORAOPE) DESC) END) as TIPOCAMBIOMN  ,
((CASE WHEN PTS_IDMONEDA = 'PE' THEN 1 ELSE (SELECT TOP 1 PTC_TIPOCAMBIO FROM PNC_TIPOCAMBIO WHERE PTC_MONEDA = 
PTS_IDMONEDA ORDER BY CONVERT(DATETIME, PTC_FECHOPE + ' ' + PTC_HORAOPE) DESC) END) * alm_ctoprom) as TOTALMN,
Anti_Refacciones = case when ltrim(alm_fechultven) <> '' AND ISDATE(alm_fechultven) = 1 then datediff(d,convert(datetime,alm_fechultven,103),convert(datetime,GETDATE(),103)) else 
case when ltrim(alm_fechulcom) <> '' AND ISDATE(alm_fechulcom) = 1 then datediff(d,convert(datetime,alm_fechulcom,103),convert(datetime,GETDATE(),103)) else 0 end end,
PTS_UNIMED = CASE WHEN PTS_UNIMED <> '' THEN (select PAR_DESCRIP1 from PNC_PARAMETR where PAR_TIPOPARA = 'UM' AND PAR_IDENPARA = PTS_UNIMED) ELSE '' END,alm_idalma
FROM PAR_ALMACEN INNER JOIN par_partes ON pts_idparte = alm_idparte  LEFT OUTER JOIN PNC_PARAMETR AS sgpo on 
sgpo.PAR_IDENPARA=PTS_SUBGPO and sgpo.PAR_TIPOPARA = 'GS' LEFT OUTER JOIN par_tmpvalubipar ON pts_idparte = 
vut_idaparte and alm_idalma = vut_almacen AND vut_cveusu = 'GMI' LEFT OUTER JOIN pnc_parametr a ON a.par_idenpara = 
pts_grupo AND a.par_tipopara = 'gp' INNER JOIN pnc_parametr as c ON c.par_idenpara = alm_idalma LEFT OUTER JOIN 
pnc_parametr b ON b.par_idenpara = alm_clasifica AND b.par_tipopara = 'ca' LEFT OUTER JOIN PNC_PARAMETR AS MN ON 
MN.PAR_TIPOPARA = 'MN' AND MN.PAR_IDENPARA = PTS_IDMONEDA where c.par_tipopara = 'sa' and alm_existen <> 0

go

