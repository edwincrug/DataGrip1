
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <18/11/2020>
-- Description:	<Obtiene los tramites vehiculares>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[SEL_TRAMITEVEHICULAR_SP]
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[SEL_TRAMITEVEHICULAR_SP]
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		idTramiteVehicular,
		tramiteVehicular,
		activo
	FROM catalogo.TramiteVehicular
	WHERE activo = 1
END
go

