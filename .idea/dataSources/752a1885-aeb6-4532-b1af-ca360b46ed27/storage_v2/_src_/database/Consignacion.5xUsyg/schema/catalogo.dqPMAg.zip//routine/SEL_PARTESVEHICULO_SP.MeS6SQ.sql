
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <11/11/2020>
-- Description:	<Obtiene las partes del vehiculo con sus imagenes>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[SEL_DOCUMENTOCONTRATO_SP]
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
create PROCEDURE [catalogo].[SEL_PARTESVEHICULO_SP]
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		idParteVehiculo
		,descripcion
		,rutaImagen
	FROM catalogo.ParteVehiculo
	WHERE activo = 1
END
go

