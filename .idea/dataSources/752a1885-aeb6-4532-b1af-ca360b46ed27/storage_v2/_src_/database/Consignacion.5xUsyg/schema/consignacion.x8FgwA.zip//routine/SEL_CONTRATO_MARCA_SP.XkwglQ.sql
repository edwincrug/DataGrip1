
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <19/11/2020>
-- Description:	<Obtiene los contratos>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [consignacion].[SEL_CONTRATO_MARCA_SP]
		@idSucursal = 9,
		@idMarca = '5cdc488ba6ca044a76082150',
		@idUsuario = 69,
		@produccion = 0,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [consignacion].[SEL_CONTRATO_MARCA_SP]
	@idSucursal			INT,
	@idMarca			VARCHAR(50),
	@idUsuario			INT,
	@produccion			BIT = 0,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN

  DECLARE @empresas TABLE (
	emp_idempresa VARCHAR(250),
	emp_nombre VARCHAR(250),
	emp_observaciones VARCHAR(250),
	emp_estatus VARCHAR(250)
  )

  DECLARE @sucursales TABLE (
	suc_idsucursal VARCHAR(250),
	suc_nombre VARCHAR(250),
	suc_ipbd VARCHAR(250),
	suc_nombrebd VARCHAR(250),
	suc_observaciones VARCHAR(250),
	emp_idempresa VARCHAR(250),
	suc_estatus	VARCHAR(250)	
  )

  DECLARE @estatusAutos TABLE (
		titulo		VARCHAR(250)
		,noAutos	INT
		,icono		VARCHAR(MAX)
		,color		VARCHAR(15)
		,filtro		VARCHAR(15)
	  )

	--OBTENEMOS LAS EMPRESAS
	INSERT INTO @empresas
	EXEC Common.[bpro].[SEL_EMPRESAS_SP]	@idUsuario, @produccion, ''

	--OBTENEMOS LAS SUCURSALES
	INSERT INTO @sucursales
	EXEC Common.[bpro].[SEL_SUCURSALES_SP] @idUsuario, @produccion, ''
	

  ---------------------------------------------------SIN FILTROS---------------------------------------------------
  IF(@idSucursal = 0 AND @idMarca = '0')
  BEGIN

  ---------------AUTOS CONSIGNADOS---------------
	INSERT INTO @estatusAutos
	SELECT
		'Autos consignados'
		,COUNT(*)
		,'./assets/images/iconos-coal/consignacion/consignacion.png'
		,'#000'
		,'all'
	FROM [Consignacion].[consignacion].[Contrato] C
		INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
		INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
		INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
		INNER JOIN [catalogo].[SubMarca] SUB ON SUB.idSubMarca = M.idSubMarca
		INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = SUB.idMarca
		INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
		INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
		INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
	WHERE C.activo = 1

	---------------POR VENCER (30 DIAS)---------------
	INSERT INTO @estatusAutos
	SELECT
		'Por vencer(30 días)'
		,COUNT(*)
		,'./assets/images/iconos-coal/consignacion/por_vencer.png'
		,'#000'
		,'ultimosDias'
	FROM [Consignacion].[consignacion].[Contrato] C
		INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
		INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
		INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
		INNER JOIN [catalogo].[SubMarca] SUB ON SUB.idSubMarca = M.idSubMarca
		INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = SUB.idMarca
		INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
		INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
		INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
	WHERE C.activo = 1
		  AND GETDATE() <= C.fechaTermino
		  AND C.fechaTermino BETWEEN DATEADD(DAY, -30, GETDATE()) AND GETDATE()

	---------------VENCIDOS---------------
	INSERT INTO @estatusAutos
	SELECT
		'Vencidos'
		,COUNT(*)
		, './assets/images/iconos-coal/consignacion/vencidos.png'
		,'red'
		,'vencidos'
	FROM [Consignacion].[consignacion].[Contrato] C
		INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
		INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
		INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
		INNER JOIN [catalogo].[SubMarca] SUB ON SUB.idSubMarca = M.idSubMarca
		INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = SUB.idMarca
		INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
		INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
		INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
	WHERE C.activo = 1
		  AND C.fechaTermino < GETDATE()


	---------------VENDIDOS---------------
	INSERT INTO @estatusAutos
	SELECT
		'Vendidos'
		,COUNT(*)
		,'./assets/images/iconos-coal/consignacion/vendidos.png'
		,'green'
		,'vendidos'
	FROM [Consignacion].[consignacion].[Contrato] C
		INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
		INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
		INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
		INNER JOIN [catalogo].[SubMarca] SUB ON SUB.idSubMarca = M.idSubMarca
		INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = SUB.idMarca
		INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
		INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
		INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
	WHERE C.activo = 1
		  AND C.idEstatus = 'COM'

	SELECT * FROM @estatusAutos

  END
  ---------------------------------------------------CON FILTROS---------------------------------------------------
  ELSE
  BEGIN
	  ---------------AUTOS CONSIGNADOS---------------
		INSERT INTO @estatusAutos
		SELECT
			'Autos consignados'
			,COUNT(*)
			,'./assets/images/iconos-coal/consignacion/consignacion.png'
			,'#000'
			,'all'
		FROM [Consignacion].[consignacion].[Contrato] C
			INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
			INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
			INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
			INNER JOIN [catalogo].[SubMarca] SUB ON SUB.idSubMarca = M.idSubMarca
			INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = SUB.idMarca
			INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
			INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
		WHERE S.suc_idsucursal = @idSucursal
			  AND MAR.idMarca = @idMarca
			  AND C.activo = 1

		---------------POR VENCER (30 DIAS)---------------
		INSERT INTO @estatusAutos
		SELECT
			'Por vencer(30 días)'
			,COUNT(*)
			,'./assets/images/iconos-coal/consignacion/por_vencer.png'
			,'#000'
			,'ultimosDias'
		FROM [Consignacion].[consignacion].[Contrato] C
			INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
			INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
			INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
			INNER JOIN [catalogo].[SubMarca] SUB ON SUB.idSubMarca = M.idSubMarca
			INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = SUB.idMarca
			INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
			INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
		WHERE S.suc_idsucursal = @idSucursal
			  AND MAR.idMarca = @idMarca
			  AND C.activo = 1
			  AND GETDATE() <= C.fechaTermino
			  AND C.fechaTermino BETWEEN DATEADD(DAY, -30, GETDATE()) AND GETDATE()

		---------------VENCIDOS---------------
		INSERT INTO @estatusAutos
		SELECT
			'Vencidos'
			,COUNT(*)
			, './assets/images/iconos-coal/consignacion/vencidos.png'
			,'red'
			,'vencidos'
		FROM [Consignacion].[consignacion].[Contrato] C
			INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
			INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
			INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
			INNER JOIN [catalogo].[SubMarca] SUB ON SUB.idSubMarca = M.idSubMarca
			INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = SUB.idMarca
			INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
			INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
		WHERE S.suc_idsucursal = @idSucursal
			  AND MAR.idMarca = @idMarca
			  AND C.activo = 1
			  AND C.fechaTermino < GETDATE()


		---------------VENDIDOS---------------
		INSERT INTO @estatusAutos
		SELECT
			'Vendidos'
			,COUNT(*)
			,'./assets/images/iconos-coal/consignacion/vendidos.png'
			,'green'
			,'vendidos'
		FROM [Consignacion].[consignacion].[Contrato] C
			INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
			INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
			INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
			INNER JOIN [catalogo].[SubMarca] SUB ON SUB.idSubMarca = M.idSubMarca
			INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = SUB.idMarca
			INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
			INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
			INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
		WHERE S.suc_idsucursal = @idSucursal
			  AND MAR.idMarca = @idMarca
			  AND C.activo = 1
			  AND C.idEstatus = 'COM'

  END
		SELECT * FROM @estatusAutos



END

go

