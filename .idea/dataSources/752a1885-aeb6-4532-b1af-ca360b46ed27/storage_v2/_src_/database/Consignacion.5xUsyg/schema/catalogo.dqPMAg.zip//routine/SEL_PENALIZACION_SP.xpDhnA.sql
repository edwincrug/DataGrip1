
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <18/11/2020>
-- Description:	<Obtiene los tramites vehiculares>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[SEL_PENALIZACION_SP]
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[SEL_PENALIZACION_SP]
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		idPenalizacion,
		penalizacion,
		activo
	FROM catalogo.Penalizacion
	WHERE activo = 1
END
go

