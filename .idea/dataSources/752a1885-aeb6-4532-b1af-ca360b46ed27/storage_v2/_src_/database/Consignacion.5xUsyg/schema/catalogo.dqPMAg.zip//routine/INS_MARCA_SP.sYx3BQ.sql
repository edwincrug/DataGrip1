
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <10/11/2020>
-- Description:	<Agrega marcas de intellimotor>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [bpro].[SEL_SUCURSALES_SP]
		@idUsuario = 20,
		@produccion  = 0,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[INS_MARCA_SP]
	@xmlMarca				XML,
	@idUsuario				INT,
	@err					varchar(max) OUTPUT
AS

BEGIN
	SET @err = '';

	DECLARE @marcas TABLE (idBPRO VARCHAR(250),
							nombre VARCHAR(250))

	INSERT INTO @marcas
	SELECT
		ParamValues.col.value('idBPRO[1]','VARCHAR(250)'),
		ParamValues.col.value('nombre[1]','VARCHAR(250)')
		FROM @xmlMarca.nodes('marcas/marca') AS ParamValues(col)


	INSERT INTO catalogo.Marca
	SELECT  
	idBPRO,
	nombre,
	1
	FROM @marcas
	WHERE idBPRO not in (SELECT idBPRO FROM catalogo.Marca)



END

go

