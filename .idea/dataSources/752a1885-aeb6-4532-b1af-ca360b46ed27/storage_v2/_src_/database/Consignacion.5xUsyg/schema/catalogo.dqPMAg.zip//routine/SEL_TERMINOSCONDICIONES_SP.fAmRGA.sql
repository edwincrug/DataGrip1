
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <11/11/2020>
-- Description:	<Obtiene los terminos y condiciones del contrato>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[SEL_TERMINOSCONDICIONES_SP]
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[SEL_TERMINOSCONDICIONES_SP]
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		idTerminosCondiciones
		,descripcion
		,activo
		,color
		,completado
	FROM catalogo.TerminosCondiciones
	WHERE activo = 1
END
go

