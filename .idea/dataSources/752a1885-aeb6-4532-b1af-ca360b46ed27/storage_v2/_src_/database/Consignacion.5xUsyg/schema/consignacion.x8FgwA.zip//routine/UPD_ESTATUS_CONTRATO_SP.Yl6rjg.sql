
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <1/12/2020>
-- Description:	<Actualiza el estatus del contrato a compra>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [consignacion].[UPD_ESTATUS_CONTRATO_SP]
		@idContrato = 4,
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [consignacion].[UPD_ESTATUS_CONTRATO_SP]
	@idContrato			INT,
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	UPDATE consignacion.Contrato
		SET idEstatus = 'COM'
	WHERE idContrato = @idContrato
END

go

