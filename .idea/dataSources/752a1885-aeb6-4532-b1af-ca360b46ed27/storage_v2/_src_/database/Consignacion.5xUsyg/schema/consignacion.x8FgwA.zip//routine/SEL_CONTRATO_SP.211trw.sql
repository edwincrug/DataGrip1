
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <19/11/2020>
-- Description:	<Obtiene los contratos>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [consignacion].[SEL_CONTRATO_SP]
		@idContrato = 4,
		@idUsuario = 20,
		@@produccion = 0,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [consignacion].[SEL_CONTRATO_SP]
	@idContrato			INT,
	@idUsuario			INT,
	@produccion			BIT = 0,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN

  DECLARE @empresas TABLE (
	emp_idempresa VARCHAR(250),
	emp_nombre VARCHAR(250),
	emp_observaciones VARCHAR(250),
	emp_estatus VARCHAR(250)
  )

  DECLARE @sucursales TABLE (
	suc_idsucursal VARCHAR(250),
	suc_nombre VARCHAR(250),
	suc_ipbd VARCHAR(250),
	suc_nombrebd VARCHAR(250),
	suc_observaciones VARCHAR(250),
	emp_idempresa VARCHAR(250),
	suc_estatus	VARCHAR(250)	
  )
	
  /*************CONTRATO**************/
  SELECT 
	*
  FROM [Consignacion].[consignacion].[Contrato] C
  WHERE C.activo = 1
  AND C.idContrato = @idContrato

  /*************VEHICULO**************/
  SELECT 
	C.idContrato,
	C.odometro,
	V.*,
	VER.version AS nombreVersion,
	M.idModelo,
	M.nombre AS nombreModelo,
	S.idSubMarca,
	S.nombre AS nombreSubMarca,
	MAR.idMarca,
	MAR.nombre AS nombreMarca,
	C.idEstatus
  FROM [Consignacion].[consignacion].[Contrato] C
  INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
	INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
	INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
	INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
	INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
  WHERE C.activo = 1
  AND C.idContrato = @idContrato

  /*************CLIENTE**************/
  SELECT 
	C.idContrato,
	CL.*
  FROM [Consignacion].[consignacion].[Contrato] C
  INNER JOIN consignacion.Cliente CL ON CL.idCliente = C.idCliente
  WHERE C.activo = 1
  AND C.idContrato = @idContrato


  /*************DOCUMENTACION**************/

  SELECT * FROM [consignacion].[ContratoDocumento] 
  WHERE idContrato = @idContrato
  and activo = 1

  /*************PARTE VEHICULO**************/

  SELECT 
	CV.idContrato,
	CV.comentario,
	PV.descripcion,
	PV.rutaImagen
  FROM [consignacion].[ContratoParteVehiculo] CV
  INNER JOIN catalogo.ParteVehiculo PV ON PV.idParteVehiculo = CV.idParteVehiculo
  WHERE idContrato = @idContrato

  /*************TERMINOS Y CONDICIONES**************/

  SELECT * FROM [consignacion].[ContratoTerminosCondiciones]
  WHERE idContrato = @idContrato

  
  /*************TRAMITE VEHICULAR**************/

  SELECT * FROM [consignacion].[ContratoTramiteVehicular]
  WHERE idContrato = @idContrato

  /*************PENALIZACIONES**************/

  SELECT * FROM [consignacion].ContratoPenalizacion
  WHERE idContrato = @idContrato

  /*************CONTRATO SUCURSAL**************/

  --OBTENEMOS LAS EMPRESAS
  INSERT INTO @empresas
  EXEC Common.[bpro].[SEL_EMPRESAS_SP]	@idUsuario, @produccion, ''

  --OBTENEMOS LAS SUCURSALES
  INSERT INTO @sucursales
  EXEC Common.[bpro].[SEL_SUCURSALES_SP] @idUsuario, @produccion, ''

  SELECT
	CS.fecha,
	E.emp_nombre,
	S.suc_nombre
  FROM [consignacion].[ContratoSucursal] CS
  INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
  INNER JOIN @sucursales S ON S.suc_idsucursal = CS.idSucursal
  WHERE idContrato = @idContrato
  ORDER BY CS.fecha DESC
END

go

