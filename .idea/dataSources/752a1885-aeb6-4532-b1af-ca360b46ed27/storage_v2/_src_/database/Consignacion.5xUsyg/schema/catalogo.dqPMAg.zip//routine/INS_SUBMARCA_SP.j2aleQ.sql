
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <10/11/2020>
-- Description:	<Agrega submarcas de intellimotor>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[INS_SUBMARCA_SP]
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[INS_SUBMARCA_SP]
	@xmlSubMarca			XML,
	@idUsuario				INT,
	@err					varchar(max) OUTPUT
AS

BEGIN
	SET @err = '';

	DECLARE @submarcas TABLE (idBPROMarca VARCHAR(250),
							idBPRO VARCHAR(250),
							nombre VARCHAR(250))

	INSERT INTO @submarcas
	SELECT
		ParamValues.col.value('idBPROMarca[1]','VARCHAR(250)'),
		ParamValues.col.value('idBPRO[1]','VARCHAR(250)'),
		ParamValues.col.value('nombre[1]','VARCHAR(250)')
		FROM @xmlSubMarca.nodes('submarcas/submarca') AS ParamValues(col)


	INSERT INTO catalogo.SubMarca
	SELECT  
	idBPROMarca,
	idBPRO,
	nombre,
	1
	FROM @submarcas
	WHERE idBPRO not in (SELECT idBPRO FROM catalogo.SubMarca)



END

go

