
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <10/11/2020>
-- Description:	<Busca marca y submarca>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[SEL_BUSCADOR_MARCASUBMARCA_SP]
		@idUsuario = 20,
		@palabraBuscar  = 'FORD',
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[SEL_BUSCADOR_MARCASUBMARCA_SP]
	@idUsuario			INT,
	@palabraBuscar		VARCHAR(50),
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		M.idBPRO AS idBPROMarca,
		M.nombre AS nombreMarca,
		S.idBPRO AS idBPROSubmarca,
		S.nombre AS nombreSubmarca,
		(M.nombre + '/' + S.nombre) AS resultadoBusqueda
	FROM catalogo.Marca M
	INNER JOIN catalogo.SubMarca S ON M.idBPRO = S.idBPROMarca
	WHERE (
			M.nombre LIKE '%'+ @palabraBuscar +'%'
			OR M.idBPRO LIKE '%'+ @palabraBuscar +'%'
			OR S.nombre LIKE '%'+ @palabraBuscar +'%'
			OR S.idBPRO LIKE '%'+ @palabraBuscar +'%'
		)
		AND M.activo = 1
		AND S.activo = 1

END
go

