
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <11/11/2020>
-- Description:	<Obtiene la documentacion del contrato>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[SEL_DOCUMENTOCONTRATO_SP]
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[SEL_DOCUMENTOCONTRATO_SP]
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN
	SELECT 
		idDocumento
		,descripcion
		,activo
	FROM catalogo.Documento
	WHERE activo = 1
END
go

