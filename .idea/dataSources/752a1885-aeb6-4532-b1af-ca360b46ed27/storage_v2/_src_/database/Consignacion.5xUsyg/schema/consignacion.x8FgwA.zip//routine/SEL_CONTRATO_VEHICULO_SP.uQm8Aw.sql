-- =============================================
CREATE PROCEDURE [consignacion].[SEL_CONTRATO_VEHICULO_SP]
	@filtro				VARCHAR(30),
	@idSucursal			INT,
	@idMarca			VARCHAR(50),
	@produccion			INT,
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT

AS
BEGIN


	DECLARE @empresas TABLE (
		emp_idempresa VARCHAR(250),
		emp_nombre VARCHAR(250),
		emp_observaciones VARCHAR(250),
		emp_estatus VARCHAR(250)
	)

	DECLARE @sucursales TABLE (
		suc_idsucursal VARCHAR(250),
		suc_nombre VARCHAR(250),
		suc_ipbd VARCHAR(250),
		suc_nombrebd VARCHAR(250),
		suc_observaciones VARCHAR(250),
		emp_idempresa VARCHAR(250),
		suc_estatus	VARCHAR(250)	
	)

	--OBTENEMOS LAS EMPRESAS
	INSERT INTO @empresas
	EXEC Common.[bpro].[SEL_EMPRESAS_SP]	@idUsuario, @produccion, ''

	--OBTENEMOS LAS SUCURSALES
	INSERT INTO @sucursales
	EXEC Common.[bpro].[SEL_SUCURSALES_SP] @idUsuario, @produccion, ''

  
	DECLARE @estatusAutos TABLE (
	titulo		VARCHAR(250)
	,noAutos	INT
	,icono		VARCHAR(MAX)
	,color		VARCHAR(15)
	,filtro		VARCHAR(15)
	)

	---------------------------------------------------SIN FILTROS---------------------------------------------------
	IF(@idSucursal = 0 AND @idMarca = '0')
	BEGIN
		---------------TODOS---------------
		IF(@filtro = 'ALL')
		BEGIN
			SELECT DISTINCT
				C.idContrato,
				C.odometro,
				C.fechaContrato,
				C.fechaTermino,
				V.idVehiculo,
				V.vin,
				V.placas,
				VER.[version] AS nombreVersion,
				M.nombre AS nombreModelo,
				S.nombre AS nombreSubMarca,
				MAR.nombre AS nombreMarca
			FROM [Consignacion].[consignacion].[Contrato] C
				INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
				INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
				INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
				INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
				INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
				INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
				INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
				INNER JOIN @sucursales SUC ON SUC.suc_idsucursal = CS.idSucursal
			WHERE C.activo = 1
			SELECT 'all' AS estatus
		END


		---------------ULTIMOS DIAS---------------
		IF(@filtro = 'ULTIMOSDIAS')
		BEGIN
			SELECT DISTINCT
				C.idContrato,
				C.odometro,
				C.fechaContrato,
				C.fechaTermino,
				V.idVehiculo,
				V.vin,
				V.placas,
				VER.[version] AS nombreVersion,
				M.nombre AS nombreModelo,
				S.nombre AS nombreSubMarca,
				MAR.nombre AS nombreMarca
			FROM [Consignacion].[consignacion].[Contrato] C
				INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
				INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
				INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
				INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
				INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
				INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
				INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
				INNER JOIN @sucursales SUC ON SUC.suc_idsucursal = CS.idSucursal
			WHERE C.activo = 1
				  AND GETDATE() <= C.fechaTermino
				  AND C.fechaTermino BETWEEN DATEADD(DAY, -30, GETDATE()) AND GETDATE()

			SELECT 'Ultimos 30 días' AS estatus

		END


		---------------VENCIDOS---------------
		IF(@filtro = 'VENCIDOS')
		BEGIN
			SELECT DISTINCT
				C.idContrato,
				C.odometro,
				C.fechaContrato,
				C.fechaTermino,
				V.idVehiculo,
				V.vin,
				V.placas,
				VER.[version] AS nombreVersion,
				M.nombre AS nombreModelo,
				S.nombre AS nombreSubMarca,
				MAR.nombre AS nombreMarca
			FROM [Consignacion].[consignacion].[Contrato] C
				INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
				INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
				INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
				INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
				INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
				INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
				INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
				INNER JOIN @sucursales SUC ON SUC.suc_idsucursal = CS.idSucursal
			WHERE C.activo = 1
				  AND C.fechaTermino < GETDATE()

			SELECT 'Vencidos' AS estatus

		END


		---------------VENDIDOS---------------
		IF(@filtro = 'VENDIDOS')
		BEGIN
			SELECT DISTINCT
				C.idContrato,
				C.odometro,
				C.fechaContrato,
				C.fechaTermino,
				V.idVehiculo,
				V.vin,
				V.placas,
				VER.[version] AS nombreVersion,
				M.nombre AS nombreModelo,
				S.nombre AS nombreSubMarca,
				MAR.nombre AS nombreMarca
			FROM [Consignacion].[consignacion].[Contrato] C
				INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
				INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
				INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
				INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
				INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
				INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
				INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
				INNER JOIN @sucursales SUC ON SUC.suc_idsucursal = CS.idSucursal
			WHERE C.activo = 1
				  AND C.idEstatus = 'COM'
			SELECT 'Vendidos' AS estatus
		END
	END


	---------------------------------------------------CON FILTROS---------------------------------------------------
	ELSE
	BEGIN
		---------------TODOS---------------
		IF(@filtro = 'ALL')
		BEGIN
			SELECT DISTINCT
				C.idContrato,
				C.odometro,
				C.fechaContrato,
				C.fechaTermino,
				V.idVehiculo,
				V.vin,
				V.placas,
				VER.[version] AS nombreVersion,
				M.nombre AS nombreModelo,
				S.nombre AS nombreSubMarca,
				MAR.nombre AS nombreMarca
			FROM [Consignacion].[consignacion].[Contrato] C
				INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
				INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
				INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
				INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
				INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
				INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
				INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
				INNER JOIN @sucursales SUC ON SUC.suc_idsucursal = CS.idSucursal
			WHERE SUC.suc_idsucursal = @idSucursal
				  AND MAR.idMarca = @idMarca
				  AND C.activo = 1
			SELECT 'all' AS estatus
		END


		---------------ULTIMOS DIAS---------------
		IF(@filtro = 'ULTIMOSDIAS')
		BEGIN
			SELECT DISTINCT
				C.idContrato,
				C.odometro,
				C.fechaContrato,
				C.fechaTermino,
				V.idVehiculo,
				V.vin,
				V.placas,
				VER.[version] AS nombreVersion,
				M.nombre AS nombreModelo,
				S.nombre AS nombreSubMarca,
				MAR.nombre AS nombreMarca
			FROM [Consignacion].[consignacion].[Contrato] C
				INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
				INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
				INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
				INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
				INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
				INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
				INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
				INNER JOIN @sucursales SUC ON SUC.suc_idsucursal = CS.idSucursal
			WHERE SUC.suc_idsucursal = @idSucursal
				  AND MAR.idMarca = @idMarca
				  AND C.activo = 1
				  AND GETDATE() <= C.fechaTermino
				  AND C.fechaTermino BETWEEN DATEADD(DAY, -30, GETDATE()) AND GETDATE()

			SELECT 'Ultimos 30 días' AS estatus

		END


		---------------VENCIDOS---------------
		IF(@filtro = 'VENCIDOS')
		BEGIN
			SELECT DISTINCT
				C.idContrato,
				C.odometro,
				C.fechaContrato,
				C.fechaTermino,
				V.idVehiculo,
				V.vin,
				V.placas,
				VER.[version] AS nombreVersion,
				M.nombre AS nombreModelo,
				S.nombre AS nombreSubMarca,
				MAR.nombre AS nombreMarca
			FROM [Consignacion].[consignacion].[Contrato] C
				INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
				INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
				INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
				INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
				INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
				INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
				INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
				INNER JOIN @sucursales SUC ON SUC.suc_idsucursal = CS.idSucursal
			WHERE SUC.suc_idsucursal = @idSucursal
				  AND MAR.idMarca = @idMarca
				  AND C.activo = 1
				  AND C.fechaTermino < GETDATE()

			SELECT 'Vencidos' AS estatus

		END


		---------------VENDIDOS---------------
		IF(@filtro = 'VENDIDOS')
		BEGIN
			SELECT DISTINCT
				C.idContrato,
				C.odometro,
				C.fechaContrato,
				C.fechaTermino,
				V.idVehiculo,
				V.vin,
				V.placas,
				VER.[version] AS nombreVersion,
				M.nombre AS nombreModelo,
				S.nombre AS nombreSubMarca,
				MAR.nombre AS nombreMarca
			FROM [Consignacion].[consignacion].[Contrato] C
				INNER JOIN [consignacion].[Vehiculo] V ON V.idVehiculo = C.idVehiculo
				INNER JOIN [catalogo].[Version] VER ON VER.idVersion = V.idVersion
				INNER JOIN [catalogo].[Modelo] M ON M.idModelo = VER.idModelo
				INNER JOIN [catalogo].[SubMarca] S ON S.idSubMarca = M.idSubMarca
				INNER JOIN [catalogo].[Marca] MAR ON MAR.idMarca = S.idMarca
				INNER JOIN [consignacion].[ContratoSucursal] CS ON CS.idContrato = C.idContrato
				INNER JOIN @empresas E ON E.emp_idempresa = CS.idEmpresa
				INNER JOIN @sucursales SUC ON SUC.suc_idsucursal = CS.idSucursal
			WHERE SUC.suc_idsucursal = @idSucursal
				  AND MAR.idMarca = @idMarca
				  AND C.activo = 1
				  AND C.idEstatus = 'COM'
			SELECT 'Vendidos' AS estatus
		END
	END

	
END
go

