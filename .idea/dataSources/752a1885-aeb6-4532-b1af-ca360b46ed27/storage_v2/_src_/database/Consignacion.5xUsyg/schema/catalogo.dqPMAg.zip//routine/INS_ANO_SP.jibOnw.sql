
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <10/11/2020>
-- Description:	<Agrega submarcas de intellimotor>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[INS_AÑO_SP]
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [catalogo].[INS_AÑO_SP]
	@xmlAño					XML,
	@idUsuario				INT,
	@err					varchar(max) OUTPUT
AS

BEGIN
	SET @err = '';

	DECLARE @años TABLE (idBPROSubMarca VARCHAR(250),
							idBPRO VARCHAR(250),
							nombre VARCHAR(250))

	INSERT INTO @años
	SELECT
		ParamValues.col.value('idBPROSubMarca[1]','VARCHAR(250)'),
		ParamValues.col.value('idBPRO[1]','VARCHAR(250)'),
		ParamValues.col.value('nombre[1]','VARCHAR(250)')
		FROM @xmlAño.nodes('años/año') AS ParamValues(col)


	INSERT INTO catalogo.Año
	SELECT  
	idBPROSubMarca,
	idBPRO,
	nombre,
	1
	FROM @años
	WHERE idBPRO not in (SELECT idBPRO FROM catalogo.Año)



END

go

