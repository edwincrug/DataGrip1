
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <19/11/2020>
-- Description:	<Crea contrato de consignacion>
-- =============================================
/*
	Fecha				Autor				Descripción 
	28/11/2020			Uriel hernandez		Se agrega nombre de penalizacion y tramites

	*- Testing...
	DECLARE @salida varchar(max) 
	EXEC [catalogo].[INS_CONTRATO_SP]
		@apellidoMaterno = 'Perez',
		@apellidoPaterno = 'Hernandez',
		@asentamiento = 'Centro Histórico',
		@celular = '5544778899',
		@color = '5ce850dd045e5d03040c6a5c',
		@comision = '1250',
		@correoElectronico = 'urie@ss.com',
		@cp = '58000',
		@empresa = 1,
		@fechaEntrega = '2020-11-18',
		@fechaNacimiento = '2020-06-13',
		@idEstado = '16',
		@idMunicipio = '053',
		@importe = '302',
		@marca = '5cdc488ba6ca044a76082150',
		@modelo = '5d5ba8d09f10a4006a416ea9',
		@nombre = 'Uriel',
		@nombreMarca = 'Acura',
		@nombreModelo = '2020',
		@nombreSubMarca = 'ILX',
		@nombreVersion = '2.4 A-spec At',
		@numeroExterior = '52',
		@numeroInterior = '24',
		@odometro = '123456',
		@placas = '12-235',
		@precioVenta = '15000',
		@rfc = '5411364578',
		@subMarca = '5cdc488ca6ca044a76082151',
		@sucursal = 1,
		@telefonoCasa = '5544112233',
		@tipoAsentamiento = '01',
		@tipoVialidad = 4,
		@version = '5e726acba8e84900133e5136',
		@vialidad = 'viela',
		@vigenciaContrato = '2021-07-27',
		@vin = 'Vin',
		@xmlDocumentacion = '<documentacion><documento><idDocumento>1</idDocumento><idFileServer>281</idFileServer></documento><documento><idDocumento>2</idDocumento><idFileServer>282</idFileServer></documento><documento><idDocumento>3</idDocumento><idFileServer>0</idFileServer></documento><documento><idDocumento>4</idDocumento><idFileServer>0</idFileServer></documento><documento><idDocumento>5</idDocumento><idFileServer>283</idFileServer></documento><documento><idDocumento>6</idDocumento><idFileServer>0</idFileServer></documento><documento><idDocumento>7</idDocumento><idFileServer>0</idFileServer></documento><documento><idDocumento>8</idDocumento><idFileServer>0</idFileServer></documento><documento><idDocumento>9</idDocumento><idFileServer>0</idFileServer></documento></documentacion>',
		@xmlPartesVehiculo = '<partes><vehiculo><idParteVehiculo>1</idParteVehiculo><valor></valor></vehiculo><vehiculo><idParteVehiculo>2</idParteVehiculo><valor>Dañado</valor></vehiculo><vehiculo><idParteVehiculo>3</idParteVehiculo><valor></valor></vehiculo><vehiculo><idParteVehiculo>4</idParteVehiculo><valor></valor></vehiculo></partes>',
		@xmlPenalizaciones = '<penalizaciones><penalizacion><idPenalizacion>1</idPenalizacion><porcentaje>56</porcentaje><idPenalizacion>1</idPenalizacion><monto>1300</monto></penalizacion></penalizaciones>',
		@xmlTerminosCondiciones = '<terminos><termino><idTerminosCondiciones>1</idTerminosCondiciones></termino><termino><idTerminosCondiciones>2</idTerminosCondiciones></termino><termino><idTerminosCondiciones>4</idTerminosCondiciones></termino><termino><idTerminosCondiciones>6</idTerminosCondiciones></termino><termino><idTerminosCondiciones>8</idTerminosCondiciones></termino><termino><idTerminosCondiciones>10</idTerminosCondiciones></termino><termino><idTerminosCondiciones>12</idTerminosCondiciones></termino><termino><idTerminosCondiciones>13</idTerminosCondiciones></termino></terminos>',
		@xmlTramites = '<tramites><tramite><idTramiteVehicular>1</idTramiteVehicular><fechaPago>2020-11-09</fechaPago><idTramiteVehicular>1</idTramiteVehicular><monto>1322</monto><idTramiteVehicular>1</idTramiteVehicular><vigencia>2021-08-05</vigencia></tramite><tramite><idTramiteVehicular>2</idTramiteVehicular><fechaPago>2021-02-04</fechaPago><idTramiteVehicular>2</idTramiteVehicular><monto>1500</monto><idTramiteVehicular>2</idTramiteVehicular><vigencia>2021-02-11</vigencia></tramite></tramites>',
		@idUsuario = 20,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE PROCEDURE [consignacion].[INS_CONTRATO_SP]

	--sucursal
	@empresa								INT,
	@sucursal								INT,

	--cliente
	@nombre									VARCHAR(100),
	@apellidoPaterno						VARCHAR(100),
	@apellidoMaterno						VARCHAR(100),
	@rfc									VARCHAR(15),
	@fechaNacimiento						DATE,
	@celular								VARCHAR(20),
	@telefonoCasa							VARCHAR(20),
	@correoElectronico						VARCHAR(100),
	@cp										VARCHAR(5),
	@idEstado								INT,
	@idMunicipio							INT,
	@tipoAsentamiento						INT,
	@asentamiento							VARCHAR(200),
	@tipoVialidad							INT,
	@vialidad								VARCHAR(200),
	@numeroExterior							VARCHAR(20),
	@numeroInterior							VARCHAR(20),


	--vehiculo
	@color									VARCHAR(50),
	@fechaEntrega							DATE,
	@marca									VARCHAR(250),
	@nombreMarca							VARCHAR(250),
	@modelo									VARCHAR(250),
	@nombreModelo							VARCHAR(250),
	@odometro								FLOAT,
	@placas									VARCHAR(10),
	@subMarca								VARCHAR(250),
	@nombreSubMarca							VARCHAR(250),
	@version								VARCHAR(250),
	@nombreVersion							VARCHAR(250),
	@vin									VARCHAR(20),

	--precios
	@comision								DECIMAL(18,2),
	@importe								DECIMAL(18,2),
	@precioVenta							DECIMAL(18,2),
	@vigenciaContrato						DATE,

	@xmlDocumentacion						XML,
	@xmlPartesVehiculo						XML,
	@xmlTramites							XML,
	@xmlPenalizaciones						XML,
	@xmlTerminosCondiciones					XML,

	@idUsuario								INT,
	@err									varchar(max) OUTPUT
AS

BEGIN
	BEGIN TRY  
	BEGIN TRANSACTION  
	
		DECLARE @documentacionTable TABLE(
			idDocumeto	INT,
			idFileServer INT
		)

		DECLARE @partesVehiculoTable TABLE(
			idParteVehiculo	INT,
			valor VARCHAR(MAX)
		)

		DECLARE @tramitesTable TABLE(
			idTramiteVehicular	INT,
			fechaPago			DATE,
			monto				FLOAT,
			vigencia			DATE,
			nombreTramite		VARCHAR(250)
		)

		DECLARE @penalizacionTable TABLE(
			idPenalizacion	INT,
			porcentaje		FLOAT,
			monto			FLOAT,
			nombrePenalizacion	VARCHAR(250)
		)

		INSERT INTO @documentacionTable
		SELECT
			ParamValues.col.value('idDocumento[1]','INT'),
			ParamValues.col.value('idFileServer[1]','INT')
		FROM @xmlDocumentacion.nodes('documentacion/documento') AS ParamValues(col)

		INSERT INTO @partesVehiculoTable
		SELECT
			ParamValues.col.value('idParteVehiculo[1]','INT'),
			ParamValues.col.value('valor[1]','VARCHAR(MAX)')
		FROM @xmlPartesVehiculo.nodes('partes/vehiculo') AS ParamValues(col)

		INSERT INTO @tramitesTable
		SELECT
			ParamValues.col.value('idTramiteVehicular[1]','INT'),
			ParamValues.col.value('fechaPago[1]','DATE'),
			ParamValues.col.value('monto[1]','FLOAT'),
			ParamValues.col.value('vigencia[1]','DATE'),
			ParamValues.col.value('nombreTramite[1]','VARCHAR(250)')
		FROM @xmlTramites.nodes('tramites/tramite') AS ParamValues(col)

		INSERT INTO @penalizacionTable
		SELECT
			ParamValues.col.value('idPenalizacion[1]','INT'),
			ParamValues.col.value('porcentaje[1]','FLOAT'),
			ParamValues.col.value('monto[1]','FLOAT'),
			ParamValues.col.value('nombrePenalizacion[1]','VARCHAR(250)')
		FROM @xmlPenalizaciones.nodes('penalizaciones/penalizacion') AS ParamValues(col)

		--INSERTAMOS LOS CATALOGOS DEL VEHICULO
		IF NOT EXISTS(SELECT * FROM catalogo.Marca WHERE idMarca = @marca)
		BEGIN
			INSERT INTO catalogo.Marca VALUES(@marca, @nombreMarca, 1)
		END

		IF NOT EXISTS(SELECT * FROM catalogo.SubMarca WHERE idSubMarca = @subMarca)
		BEGIN
			INSERT INTO catalogo.SubMarca VALUES(@subMarca, @marca, @nombreSubMarca, 1)
		END

		IF NOT EXISTS(SELECT * FROM catalogo.Modelo WHERE idModelo = @modelo)
		BEGIN
			INSERT INTO catalogo.Modelo VALUES(@modelo, @nombreModelo, 1, @subMarca)
		END

		IF((@version IS NOT NULL) AND (@version != ''))
		BEGIN
			IF NOT EXISTS(SELECT * FROM catalogo.Version WHERE idVersion = @version)
			BEGIN
				INSERT INTO catalogo.Version VALUES(@version, @modelo, @nombreVersion, 1)
			END
		END
		ELSE
		BEGIN
			IF NOT EXISTS(SELECT * FROM [catalogo].[Version] WHERE idVersion = (@modelo+'GENERAL'))
			BEGIN
				INSERT INTO [catalogo].[Version] VALUES((@modelo+'GENERAL'), @modelo, 'GENERAL', 1)
				SET @version = @modelo+'GENERAL'
			END
		END

		--INSERTAMOS EL VEHICULO
		DECLARE @idVehiculo INT;
		INSERT INTO consignacion.Vehiculo VALUES(@version, @vin, @placas, @color)
		SET @idVehiculo = @@IDENTITY

		
		--INSERTAMOS EL CLIENTE
		DECLARE @idCliente int;
		INSERT INTO consignacion.Cliente VALUES (
			@nombre,
			@apellidoPaterno,
			@apellidoMaterno,
			@rfc,
			@fechaNacimiento,
			@celular,
			@telefonoCasa,
			@correoElectronico,
			@cp,
			@idEstado,
			@idMunicipio,
			@tipoAsentamiento,
			@asentamiento,
			@tipoVialidad,
			@vialidad,
			@numeroExterior,
			@numeroInterior
		)
		SET @idCliente = @@IDENTITY

		
		--INSERTAMOS EL CONTRATO
		DECLARE @idContrato INT
		INSERT INTO consignacion.Contrato VALUES(
			@idVehiculo,
			@idCliente,
			@fechaEntrega,
			@idUsuario,
			'ACT',
			GETDATE(),
			@odometro,
			@precioVenta,
			@comision,
			@vigenciaContrato,
			@importe,
			1
		)
		SET @idContrato = @@IDENTITY

		
		--INSERTAMOS DOCUMENTACION DEL CONTRATO
		INSERT INTO consignacion.ContratoDocumento
		SELECT
			idDocumeto,
			idFileServer,
			GETDATE(),
			@idUsuario,
			1,
			@idContrato
		FROM @documentacionTable

		
		--INSERTAMOS TERMINOS Y CONDICIONES DEL CONTRATO
		INSERT INTO consignacion.ContratoTerminosCondiciones
		SELECT
			@idContrato,
			idTerminosCondiciones
		FROM catalogo.TerminosCondiciones
		WHERE activo = 1

		
		--INSERTAMOS TRAMITES DEL CONTRATO
		INSERT INTO consignacion.ContratoTramiteVehicular
		SELECT
			@idContrato,
			fechaPago,
			monto,
			vigencia,
			idTramiteVehicular,
			nombreTramite
		FROM @tramitesTable


		--INSERTAMOS PENALIZACION DEL CONTRATO
		INSERT INTO consignacion.ContratoPenalizacion
		SELECT
			@idContrato,
			idPenalizacion,
			porcentaje,
			monto,
			nombrePenalizacion
		FROM @penalizacionTable

		--INSERTAMOS LAS PARTES DEL VEHICULO OBSERVADAS
		INSERT INTO consignacion.ContratoParteVehiculo
		SELECT
			@idContrato,
			idParteVehiculo,
			valor
		FROM @partesVehiculoTable

		--INSERTAMOS EN QUE SUCURSAL ESTA EL CONTRATO
		INSERT INTO consignacion.ContratoSucursal VALUES (@idContrato, @sucursal, 1, GETDATE(), @empresa)

		SELECT @idContrato idContrato

	COMMIT  
	END TRY 

	BEGIN CATCH  
		SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
		SELECT @err  
	ROLLBACK  
	END CATCH  
END

go

