CREATE TRIGGER [dbo].[UpdPersonas] ON [dbo].[PER_PERSONAS]  

   AFTER UPDATE
AS 
BEGIN
	--DECLARE @RC int
	DECLARE @IdPersona numeric(18,0)
	DECLARE @StT nvarchar(20)
	declare @numfil int
	
	
	select @IdPersona = (select per_idpersona from inserted)
	--select @StT = 'Update'		
	
------------------------------------- datos personales

		IF EXISTS (SELECT per_idpersona FROM BDPersonas.dbo.CAT_PERSONAS WHERE per_idpersona=@IdPersona) 
		BEGIN
			select @numfil=(SELECT per_idpersona  FROM BDPersonas.dbo.cat_personas a WHERE 
			PER_IDPERSONA = (select per_idpersona from ga_corporativa.dbo.per_PERSONAS b 
			WHERE b.per_idpersona=@idpersona
			and a.per_nomrazon COLLATE DATABASE_DEFAULT=b.PER_NOMRAZON   
			and a.per_paterno COLLATE DATABASE_DEFAULT=b.PER_PATERNO   
			and a.per_materno COLLATE DATABASE_DEFAULT = b.per_materno
			and a.tpo_idtipo = (select tpo_idtipo from bdpersonas..cat_tipoper where tpo_nombrecto = b.PER_TIPO COLLATE DATABASE_DEFAULT)
			and a.tit_idtitulo = (select tit_idtitulo from bdpersonas..cat_titulo where tit_nombrecto = b.per_titulo COLLATE DATABASE_DEFAULT)
			and a.per_curp COLLATE DATABASE_DEFAULT=b.PER_CURP  
			and a.edc_idedocivil=(CASE WHEN a.edc_idedocivil='' then 1 else (select edc_idedocivil from BDPersonas.dbo.cat_edocivil where edc_nombrecto = b.PER_EDOCIVIL COLLATE database_default)end) 
			 and a.per_rfc COLLATE DATABASE_DEFAULT=b.PER_RFC  
			and a.per_sexo COLLATE DATABASE_DEFAULT=(SELECT CASE WHEN per_sexo='HOM' THEN 'H' ELSE CASE WHEN per_sexo='MUJ' THEN 'M' ELSE '' END  end )
			--and a.per_fechanac=(SELECT convert(datetime,REPLACE(b.PER_FECNAC,'__/__/____','01/01/1900'),103))
			))
		
			IF (@numfil='' or @numfil IS NULL)
			begin
			
			--select * from BDPersonas..cat_titulo
				UPDATE  BDPersonas.DBO.cat_personas 
				SET 
				 bdpersonas.dbo.cat_personas.per_nomrazon=b.PER_NOMRAZON
				, bdpersonas.dbo.cat_personas.per_paterno=b.PER_PATERNO
				, bdpersonas.dbo.cat_personas.per_materno=b.per_materno
				, bdpersonas.dbo.cat_personas.tit_idtitulo=1
				, bdpersonas.dbo.cat_personas.per_curp=b.PER_CURP
				, bdpersonas.dbo.cat_personas.tpo_idtipo =(CASE WHEN bdpersonas.dbo.cat_personas.tpo_idtipo='' then 1 else (select tpo_idtipo from BDPersonas.dbo.cat_tipoper where tpo_nombrecto = b.PER_TIPO COLLATE database_default)end) 
				, bdpersonas.dbo.cat_personas.edc_idedocivil=(CASE WHEN bdpersonas.dbo.cat_personas.edc_idedocivil='' then 1 else (select edc_idedocivil from BDPersonas.dbo.cat_edocivil where edc_nombrecto = b.PER_EDOCIVIL COLLATE database_default)end) 
				, bdpersonas.dbo.cat_personas.per_rfc=b.PER_RFC 
				, bdpersonas.dbo.cat_personas.per_sexo=(SELECT CASE WHEN b.per_sexo='HOM' THEN 'H' ELSE CASE WHEN b.per_sexo='MUJ' THEN 'M' ELSE '' END  end )
				--, per_fechanac=(SELECT convert(datetime,REPLACE(PER_FECNAC,'__/__/____',''),103) 
				,per_fechamodifica = GETDATE()
				,per_usumodifica =1
				from ga_corporativa.dbo.per_PERSONAS b WHERE  bdpersonas.dbo.cat_personas.per_idpersona=@IdPersona and b.PER_IDPERSONA=@IdPersona

			ENd 
		END 
		
------------------------------ direcciones 
			IF EXISTS (SELECT per_idpersona FROM BDPersonas.dbo.PER_DIRECCIONES WHERE per_idpersona = @IdPersona)
			BEGIN  
				update BDPersonas.dbo.per_direcciones set dir_calle=b.per_calle1, 
				dir_entrecalle=b.per_calle2,
				dir_ycalle=b.per_calle2,
				dir_numeroext=b.per_numexter,
				dir_numeroint=b.per_numiner,
				dir_colonia=b.per_colonia,
				dir_municipio=b.per_delegac,
				dir_codigopostal=convert(int,B.PER_CODPOS),  
				dir_consecutivo=1,
				dir_predeterminada=1,
				dir_estatus=1,
				per_idpersona=@IdPersona,
				dir_descripcion='',
				cdd_idciudad= isnull((select top 1 cdd_idciudad from BDPersonas.dbo.cat_ciudades where cdd_nombre 
				COLLATE DATABASE_DEFAULT=B.PER_CIUDAD COLLATE DATABASE_DEFAULT),0),
				tpd_iddireccion=0
				from  GA_Corporativa..PER_PERSONAS b
				where  bdpersonas.dbo.per_direcciones.per_idpersona=@IdPersona and b.PER_IDPERSONA=@IdPersona
			 END 
		 ELSE 
			BEGIN
				insert into BDPersonas.dbo.per_direcciones( dir_calle,dir_entrecalle,dir_ycalle,dir_numeroext,dir_numeroint,dir_colonia,dir_municipio,dir_codigopostal,  
				dir_consecutivo,dir_predeterminada,dir_estatus,per_idpersona,dir_descripcion,cdd_idciudad,tpd_iddireccion,dir_fechaalta,dir_usualta,  
				der_fechamodifica,dir_usumodifica,dir_idrol)  
				SELECT BPER.PER_CALLE1,bper.PER_CALLE2,bper.PER_CALLE3,BPER.PER_NUMEXTER, BPER.PER_NUMINER,BPER.PER_COLONIA,bper.PER_DELEGAC,convert(int,BPER.PER_CODPOS),  
				1,1,1,CONVERT(INT,BPER.PER_IDPERSONA),'', isnull((select top 1 cdd_idciudad from BDPersonas.dbo.cat_ciudades where cdd_nombre COLLATE DATABASE_DEFAULT=BPER.PER_CIUDAD COLLATE DATABASE_DEFAULT),0)  
				,0,GETDATE(),1,GETDATE(),1,isnull((select top 1 rol_idrol from BDPersonas.dbo.per_relacionroles rrl where rrl.per_idpersona= BPER.PER_IDPERSONA),0)  
				 FROM GA_Corporativa..PER_PERSONAS BPER LEFT OUTER JOIN BDPersonas..cat_personas FPER ON BPER.PER_IDPERSONA=FPER.per_idpersona   
				LEFT OUTER JOIN BDPersonas..per_relacionroles RPERROL ON FPER.per_idpersona=RPERROL.per_idpersona   
				LEFT OUTER JOIN BDPersonas..cat_roles ROL ON RPERROL.rol_idrol=ROL.rol_idrol    
				 where bper.PER_IDPERSONA=@IdPersona  
			END 
------------------------------ correos 
		if exists (select  per_idpersona from BDPersonas.dbo.per_correos  where per_idpersona=@IdPersona)
			begin
				--select @numfil=( select PER_IDPERSONA from ga_corporativa.dbo.per_PERSONAS where per_idpersona=@IdPersona)
				--if @numfil<>''
				--begin
				--select * from bdpersonas.dbo.per_correos 
					UPDATE bdpersonas.dbo.per_correos  SET cor_dircorreo = b.per_email, 
					cor_fechamodifica = GETDATE() ,cor_usumodifica =1 ,
					cor_nombrecontacto= (b.PER_NOMRAZON+' ' +b.PER_PATERNO+' '+b.PER_MATERNO)
					from ga_corporativa.dbo.per_PERSONAS b 
					WHERE  bdpersonas.dbo.per_correos.per_idpersona = @IdPersona and b.PER_IDPERSONA=@IdPersona
				--end
			end 
		ELSE
			begin 
				--select @numfil=( select PER_IDPERSONA from ga_corporativa.dbo.per_PERSONAS where per_idpersona=@IdPersona)
				--if @numfil<>''
				--begin
					INSERT INTO BDPersonas..per_correos  
					SELECT CONVERT(INT,BPER.PER_IDPERSONA),CASE WHEN ROL.rol_idrol <> '' THEN ROL.rol_idrol WHEN ROL.rol_idrol IS NULL 
					THEN (SELECT rol_idrol FROM BDPersonas.DBO.CAT_ROLES WHERE rol_nombrecto = 'NA')end,1,BPER.PER_EMAIL,  
					(BPER.PER_NOMRAZON+' '+BPER.PER_PATERNO+' '+BPER.PER_MATERNO),  
					 1,1,GETDATE(),15,getdate(),15  
					 FROM GA_Corporativa.dbo.PER_PERSONAS BPER LEFT OUTER JOIN BDPersonas..cat_personas FPER ON BPER.PER_IDPERSONA=FPER.per_idpersona   
					LEFT OUTER JOIN BDPersonas..per_relacionroles RPERROL ON FPER.per_idpersona=RPERROL.per_idpersona   
					LEFT OUTER JOIN BDPersonas..cat_roles ROL ON RPERROL.rol_idrol=ROL.rol_idrol  
					where BPER.PER_IDPERSONA=@IdPersona  
				--end 
			end


	----------------------------telefonos

		if exists (select  per_idpersona from BDPersonas.dbo.per_telefonos  where per_idpersona=@IdPersona)
			begin 
				
					UPDATE bdpersonas.dbo.per_telefonos SET tel_lada = b.per_lada,
					tel_numero =b.per_telefono1,
					tel_extencion =b.per_ext1,
					tel_nombrecontacto=(B.PER_NOMRAZON+' '+B.PER_PATERNO+' '+B.PER_MATERNO),
					ttl_idtipo = 1,
					tel_fechamodifica = GETDATE(),
					tel_usumodifica =1 
					from ga_corporativa.dbo.per_PERSONAS b 
					WHERE  bdpersonas.dbo.per_telefonos.per_idpersona = @IdPersona and b.PER_IDPERSONA=@IdPersona
				
			end 
		ELSE 
			begin
				
					insert into BDPersonas.dbo.per_telefonos  
					SELECT CONVERT(INT,BPER.PER_IDPERSONA),CASE WHEN ROL.rol_idrol IS NULL 
			THEN (SELECT rol_idrol FROM BDPersonas.DBO.CAT_ROLES WHERE rol_nombrecto = 'NA') WHEN 
			ROL.rol_idrol <> '' THEN ROL.rol_idrol END ,1,
			CASE WHEN PER_LADA = '01 5' THEN 55 WHEN PER_LADA = 
			'01 55|' THEN 55 WHEN PER_LADA = '01 52' THEN 52 WHEN PER_LADA = '01 77' THEN 77 WHEN 
			PER_LADA not in ('01 5','01 55|','01 52','01 77','01 55', '0155|') THEN CONVERT(INT,dbo.removechars( PER_LADA)) END,  
			BPER.PER_TELEFONO1, 
			CASE WHEN BPER.PER_EXT1 = '5530439623' THEN 55 WHEN BPER.PER_EXT1 NOT IN ('5530439623') 
			THEN CONVERT(INT,BPER.PER_EXT1) END,  
			(BPER.PER_NOMRAZON+' '+BPER.PER_PATERNO+' '+BPER.PER_MATERNO),  
			 convert(datetime,'09:00'), convert(datetime,'18:00'),1,1,1,GETDATE(),15,15,getdate()  
			 FROM GA_Corporativa..PER_PERSONAS BPER LEFT OUTER JOIN BDPersonas..cat_personas FPER ON BPER.PER_IDPERSONA=FPER.per_idpersona   
			LEFT OUTER JOIN BDPersonas..per_relacionroles RPERROL ON FPER.per_idpersona=RPERROL.per_idpersona   
			LEFT OUTER JOIN BDPersonas..cat_roles ROL ON RPERROL.rol_idrol=ROL.rol_idrol   
					where BPER.PER_IDPERSONA=@IdPersona  
				
			end

	
END
go

disable trigger UpdPersonas on PER_PERSONAS
go

