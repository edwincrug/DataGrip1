CREATE PROCEDURE [dbo].[SP_RolPersona] 
AS
BEGIN


			delete BDPersonas.dbo.per_relacionroles --where per_idpersona--= @IdPersona
			
			
			INSERT INTO BDPersonas.dbo.per_relacionroles (per_idpersona, rol_idrol)  
				SELECT PER_IDPERSONA, rol_idrol FROM (SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.3].GAAU_PEDREGAL.dbo.PER_ROLES PR, 
				GA_Corporativa.dbo.PER_PERSONAS a , BDPersonas.dbo.cat_roles 
				WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA = a.PER_IDPERSONA and pr.rol_estatus=1
			UNION  
				SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.3].GAAU_CUAUTITLAN.dbo.PER_ROLES PR, GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
				WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA = PER_IDPERSONA and pr.rol_estatus=1
			UNION  
				SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.3].GAAU_UNIVERSIDAD.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
				WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA and pr.rol_estatus=1
			UNION
				SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.31].GAAT_PEUGEOT.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
				WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA and pr.rol_estatus=1
			UNION  
				SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM GAHondaZaragoza.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
				WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA  and pr.rol_estatus=1
							UNION  
				SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.31].GAZM_ABASTO.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
				WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA  and pr.rol_estatus=1
							UNION  
				SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.31].GAZM_FAEREA.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
				WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA  and pr.rol_estatus=1
							UNION  
				SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.31].GAZM_ZARAGOZA.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
				WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA  and pr.rol_estatus=1
	
		     )A  
				--WHERE PER_IDPERSONA = @IdPersona
--				select * from BDPersonas.dbo.per_relacionroles where per_idpersona= @IdPersona
END
go

