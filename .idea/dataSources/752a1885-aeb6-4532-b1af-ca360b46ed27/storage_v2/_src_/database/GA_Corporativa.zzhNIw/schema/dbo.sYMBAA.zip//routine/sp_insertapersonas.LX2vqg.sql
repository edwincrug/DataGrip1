
-- =============================================  
-- Author:  <Jocelyn Hernández>  
-- Create date: <2017-02-28,>  
-- Description: <Stored para replicar personas>  
-- =============================================  
CREATE PROCEDURE [dbo].[sp_insertapersonas]  
  
AS  
BEGIN  
DECLARE @IdPersona Numeric (18,0)  
SET NOCOUNT ON;  
DECLARE  inserta_personas CURSOR  
   
  
FOR  
  
select top 1000  per.per1 from (  
select c.PER_IDPERSONA per1, p.per_idpersona per2  
from GA_Corporativa.DBO.PER_PERSONAS C  
left join BDPersonas.dbo.cat_personas P on c.PER_IDPERSONA = p.per_idpersona) per  
where per.per2 is null 
and per.per1 between 211239 and 240569
--order by 1 desc
  
OPEN inserta_personas                          
FETCH inserta_personas INTO  @IdPersona                 
WHILE (@@FETCH_STATUS = 0)                          
BEGIN   
  
SET IDENTITY_INSERT  BDPersonas.dbo.cat_personas ON  
INSERT INTO BDPersonas.dbo.cat_personas ([per_idpersona],[per_rfc],[per_paterno],[per_materno],[per_nomrazon],[per_sistemaant],[per_avisopriv],  
[per_actaconst],[per_fechaconst],[per_fechainsc],[per_estatus],[per_curp],[per_sexo],[per_paisnac],[per_nacionalidad],[per_enviopubli],[tpo_idtipo],[tps_idtiposoc],[per_fechaalta],[per_usualta],  
[per_fechamodifica],[per_usumodifica],[tit_idtitulo],[edc_idedocivil])  
select per_idpersona,per_rfc,per_paterno,per_materno,per_nomrazon,per_idpersona,case when per_avpriv = 'SI' THEN 'S' when PER_AVPRIV IS NULL THEN 'N' WHEN PER_AVPRIV = 'NO' THEN 'N' END,  
per_actaconst,GETDATE(),GETDATE(),1,per_curp  
,CASE WHEN per_sexo = 'HOM' THEN 'M' WHEN  per_sexo = 'MUJ' THEN 'F' WHEN  per_sexo = '' THEN '' END  
,PER_PAIS,PER_NACIONALIDAD,PER_ENVIO  
,case when  per_tipo= '' then 1 WHEN PER_TIPO IS NULL THEN 1 WHEN PER_TIPO = NULL THEN 1 when  per_tipo <> '' then(select tpo_idtipo from BDPersonas..cat_tipoper where tpo_nombrecto COLLATE DATABASE_DEFAULT = per_tipo COLLATE DATABASE_DEFAULT) end  
,case when  per_tipmoral is null then 0 when PER_TIPMORAL = NULL then 0 when  per_tipmoral = '' then 0 when  per_tipmoral <> ''  then (select tps_idtiposoc from BDPersonas.DBO.cat_tiposoc where tps_nombrecto COLLATE DATABASE_DEFAULT = per_tipmoral COLLATE 
DATABASE_DEFAULT)  end  
,getdate(),1,getdate(),1  
,case when  per_titulo is null then 1 when  per_titulo = '' then 1 when per_titulo = NULL THEN 1 when  per_titulo <> '' then (select tit_idtitulo from BDPersonas..cat_titulo where tit_nombrecto COLLATE DATABASE_DEFAULT = per_titulo COLLATE DATABASE_DEFAULT)  WHEN per_titulo = 1 then 1 when PER_TITULO = 3 then 1 when PER_TITULO = 9 then 1 when PER_TITULO = 2 then 1 WHEN PER_TITULO = 8 THEN 1 WHEN PER_TITULO = 7 THEN 1 WHEN PER_TITULO = 6 THEN 1 WHEN PER_TITULO = 5 THEN 1 WHEN PER_TITULO = 4 THEN 1 WHEN PER_TITULO = 0 THEN 1  end  
,case when  per_edocivil is NULL then 1 when  per_edocivil = '' then 1 when per_edocivil = 'NULL' then 1 when  per_edocivil IS not null then (select edc_idedocivil from BDPersonas..cat_edocivil where edc_nombrecto COLLATE DATABASE_DEFAULT = per_edocivil COLLATE DATABASE_DEFAULT) when  per_edocivil <> '' then (select edc_idedocivil from BDPersonas..cat_edocivil where edc_nombrecto COLLATE DATABASE_DEFAULT = per_edocivil COLLATE DATABASE_DEFAULT) end  
from GA_Corporativa..per_personas where PER_IDPERSONA=@IdPersona  
SET IDENTITY_INSERT  BDPersonas.dbo.cat_personas off  
  
  
  
INSERT INTO BDPersonas.dbo.per_relacionroles (per_idpersona, rol_idrol)  
SELECT top 1 PER_IDPERSONA, rol_idrol FROM (
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM GAAU_PEDREGAL.dbo.PER_ROLES PR, GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA = PER_IDPERSONA  
UNION  
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM GAAU_CUAUTITLAN.dbo.PER_ROLES PR, GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA = PER_IDPERSONA 
UNION  
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM GAAU_UNIVERSIDAD.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA 
UNION
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.31].GAAT_PEUGEOT.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA     
UNION  
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM GAHondaZaragoza.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA 
UNION
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.31].GAZM_ZARAGOZA.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA     
UNION
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.31].GAZM_ABASTO.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA     
UNION
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM [192.168.20.31].GAZM_FAEREA.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA
UNION
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM GAAA_Azcapo.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA 
UNION
SELECT PER_IDPERSONA, cat_roles.rol_idrol FROM GAAA_PERISUR.dbo.PER_ROLES  PR , GA_Corporativa.dbo.PER_PERSONAS, BDPersonas.dbo.cat_roles  
WHERE PR.rol_rol COLLATE DATABASE_DEFAULT = cat_roles.rol_nombrecto AND PR.ROL_IDPERSONA  = PER_IDPERSONA 
   )A  
WHERE PER_IDPERSONA = @IdPersona 
  
  
insert into BDPersonas.dbo.per_direcciones( dir_calle,dir_entrecalle,dir_ycalle,dir_numeroext,dir_numeroint,dir_colonia,dir_municipio,dir_codigopostal,  
dir_consecutivo,dir_predeterminada,dir_estatus,per_idpersona,dir_descripcion,cdd_idciudad,tpd_iddireccion,dir_fechaalta,dir_usualta,  
der_fechamodifica,dir_usumodifica,dir_idrol)  
  
SELECT BPER.PER_CALLE1,bper.PER_CALLE2,bper.PER_CALLE3,DBO.RemoveChars (BPER.PER_NUMEXTER), DBO.RemoveChars(BPER.PER_NUMINER),BPER.PER_COLONIA,bper.PER_DELEGAC,DBO.RemoveChars(BPER.PER_CODPOS),  
1,1,1,CONVERT(INT,BPER.PER_IDPERSONA),'', isnull((select top 1 cdd_idciudad from BDPersonas.dbo.cat_ciudades where cdd_nombre COLLATE DATABASE_DEFAULT=BPER.PER_CIUDAD COLLATE DATABASE_DEFAULT),0)  
,0,GETDATE(),1,GETDATE(),1,isnull((select top 1 rol_idrol from BDPersonas.dbo.per_relacionroles rrl where rrl.per_idpersona= BPER.PER_IDPERSONA),0)  
 FROM GA_Corporativa..PER_PERSONAS BPER LEFT OUTER JOIN BDPersonas..cat_personas FPER ON BPER.PER_IDPERSONA=FPER.per_idpersona   
LEFT OUTER JOIN BDPersonas..per_relacionroles RPERROL ON FPER.per_idpersona=RPERROL.per_idpersona   
LEFT OUTER JOIN BDPersonas..cat_roles ROL ON RPERROL.rol_idrol=ROL.rol_idrol    
 where bper.PER_IDPERSONA=@IdPersona  

  
INSERT INTO BDPersonas..per_correos  
SELECT CONVERT(INT,BPER.PER_IDPERSONA),CASE WHEN ROL.rol_idrol <> '' THEN ROL.rol_idrol WHEN ROL.rol_idrol IS NULL THEN (SELECT rol_idrol FROM BDPersonas.DBO.CAT_ROLES WHERE rol_nombrecto = 'NA')end,1,BPER.PER_EMAIL,  
(BPER.PER_NOMRAZON+' '+BPER.PER_PATERNO+' '+BPER.PER_MATERNO),  
 1,1,GETDATE(),15,getdate(),15  
 FROM GA_Corporativa.dbo.PER_PERSONAS BPER LEFT OUTER JOIN BDPersonas..cat_personas FPER ON BPER.PER_IDPERSONA=FPER.per_idpersona   
LEFT OUTER JOIN BDPersonas..per_relacionroles RPERROL ON FPER.per_idpersona=RPERROL.per_idpersona   
LEFT OUTER JOIN BDPersonas..cat_roles ROL ON RPERROL.rol_idrol=ROL.rol_idrol  
where BPER.PER_IDPERSONA=@IdPersona  
  
  
  
insert into BDPersonas.dbo.per_telefonos  
SELECT CONVERT(Int,BPER.PER_IDPERSONA),CASE WHEN ROL.rol_idrol IS NULL THEN (SELECT rol_idrol FROM BDPersonas.DBO.CAT_ROLES 
WHERE rol_nombrecto = 'NA') WHEN ROL.rol_idrol <> '' THEN ROL.rol_idrol END ,1,CASE WHEN PER_LADA = '01 5' THEN 55 WHEN PER_LADA = '01 55|' THEN 55 WHEN PER_LADA = '01 52' THEN 52 WHEN PER_LADA = '01 77' THEN 77 WHEN PER_LADA = '01 271' THEN 271 WHEN PER_LADA = '.' THEN 0 WHEN PER_LADA = '01 272' THEN 272 WHEN PER_LADA = '52 55' THEN 55 WHEN PER_LADA = '55-' THEN 55 WHEN PER_LADA = '01-777' THEN 777 WHEN PER_LADA = '52-33' THEN 33 WHEN PER_LADA = '52-55' THEN 55 WHEN PER_LADA not in ('01 5','01 55|','01 52','01 77','01 55', '0155|','|') THEN CONVERT(INT, PER_LADA) END,  
(BPER.PER_TELEFONO1), CASE WHEN BPER.PER_EXT1 = '5530439623' THEN 55 WHEN BPER.PER_EXT1 = '5528440166' THEN 55 WHEN BPER.PER_EXT1 = '5585504125' THEN 55 WHEN BPER.PER_EXT1 = '5528959213' THEN 55 WHEN BPER.PER_EXT1 = '5510081818' THEN 55 WHEN BPER.PER_EXT1 = 'OS NATERA' THEN 55 WHEN BPER.PER_EXT1 = '5555555555' THEN 55 WHEN BPER.PER_EXT1 = '5525116971' THEN 55 END,  
(BPER.PER_NOMRAZON+' '+BPER.PER_PATERNO+' '+BPER.PER_MATERNO),  
 convert(datetime,'09:00'), convert(datetime,'18:00'),1,1,1,GETDATE(),15,15,getdate()  
FROM GA_Corporativa.DBO.PER_PERSONAS BPER LEFT OUTER JOIN BDPersonas.DBO.cat_personas FPER ON BPER.PER_IDPERSONA=FPER.per_idpersona   
LEFT OUTER JOIN BDPersonas.DBO.per_relacionroles RPERROL ON FPER.per_idpersona=RPERROL.per_idpersona   
LEFT OUTER JOIN BDPersonas.dbo.cat_roles ROL ON RPERROL.rol_idrol=ROL.rol_idrol  
where BPER.PER_IDPERSONA=@IdPersona  
  
FETCH inserta_personas INTO @IdPersona                        
END      
                          
CLOSE inserta_personas                          
DEALLOCATE inserta_personas       
  
END

go

