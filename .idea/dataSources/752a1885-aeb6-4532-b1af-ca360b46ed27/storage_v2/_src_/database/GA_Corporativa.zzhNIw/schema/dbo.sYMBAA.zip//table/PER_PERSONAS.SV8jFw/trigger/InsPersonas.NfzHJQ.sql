-- =============================================
-- Author:		Jesús Alberto Hernández Plata
-- Create date: 04/11/2017
-- Description:	Trigger invoca Insert de SP "SP_INSUPTPersonas"
-- =============================================
CREATE TRIGGER [dbo].[InsPersonas] ON [dbo].[PER_PERSONAS]  

   AFTER  INSERT
AS 
BEGIN
	DECLARE @RC int
	DECLARE @IdPer numeric(18,0)
	DECLARE @StT nvarchar(20)
	
	
	select @IdPer = (select per_idpersona from inserted)
	select @StT = 'Insert'		

	EXECUTE @RC = [GA_Corporativa].[dbo].[SP_INSUPTPersonas] 
	   @IdPer
	  ,@StT
	
END
go

disable trigger InsPersonas on PER_PERSONAS
go

