
CREATE TRIGGER [dbo].[unificacion_ecommerce] ON [dbo].[unp_unificacionenc]
AFTER UPDATE
AS
BEGIN
DECLARE @IdBueno Numeric (18) 
DECLARE @IdRepetidos VARCHAR(MAX)
DECLARE @Lote Numeric (18)

SELECT @Lote = (select upe_idunificacion from inserted)

SELECT @IdBueno = (select top 1 upd_idpersonaunifica from unp_unificacionenc enc
inner join unp_unificaciondet det on enc.upe_idunificacion = det.upe_idunificacion
where enc.upe_idunificacion = @Lote and enc.upe_estatus = 1)

SELECT @IdRepetidos = (SELECT STUFF(
    (SELECT ','+ convert(varchar(200),det.upd_idpersonaunificada)
    FROM unp_unificaciondet det
    INNER JOIN unp_unificacionenc enc ON det.upe_idunificacion = enc.upe_idunificacion
    WHERE enc.upe_estatus = 1 and enc.upe_idunificacion = @Lote
    FOR XML PATH ('')),1,1, ''))


  EXEC mmxMergePersonasIds @IdBueno, @IdRepetidos

  end
go

disable trigger unificacion_ecommerce on unp_unificacionenc
go

