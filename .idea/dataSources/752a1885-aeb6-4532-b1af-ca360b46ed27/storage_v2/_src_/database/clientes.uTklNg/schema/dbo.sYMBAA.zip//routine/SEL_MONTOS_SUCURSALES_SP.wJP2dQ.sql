-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SEL_MONTOS_SUCURSALES_SP 
	@idTramite INT = 0
AS
BEGIN
		DECLARE @id INT = (SELECT id FROM [clientes].[dbo].[SolicitudMonto] WHERE tramites_Id = @idTramite)
		
		SELECT s.suc_observaciones AS nombreSuc, d.monto AS monto
		FROM [clientes].[dbo].[DestinoMontoSucursal] d
		INNER JOIN  [ControlAplicaciones].[dbo].[cat_sucursales]  s on s.suc_idsucursal = d.idSucursal
		WHERE d.id_SolicitudMonto = @id

END
go

