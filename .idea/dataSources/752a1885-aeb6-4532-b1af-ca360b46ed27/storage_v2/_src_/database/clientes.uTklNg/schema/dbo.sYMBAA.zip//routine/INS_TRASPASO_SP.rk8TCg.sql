-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- INS_TRASPASO_SP 251
CREATE PROCEDURE [dbo].[INS_TRASPASO_SP] 
	 @idPertra INT = 0
	,@result INT = NULL  OUTPUT  
AS
BEGIN
BEGIN TRY

	DECLARE @consulta NVARCHAR(MAX), @nomBaseSuc  NVARCHAR(200) = '',@nomBaseConcentra  NVARCHAR(200) = '', @exite INT = 0, @PER_NOMRAZON  NVARCHAR(200) = '', @PER_PATERNO  NVARCHAR(200) = '', @PER_MATERNO NVARCHAR(200) = '', @PER_RFC NVARCHAR(200) = ''
	,@idEmpresa INT = 0, @monto NUMERIC(18,2), @cartera  NVARCHAR(20) = '', @idCliente INT, @per_idpersona INT,@idSuc INT = 0


	DECLARE @carteras TABLE(id  INT IDENTITY(1,1),cartera NVARCHAR(20),monto DECIMAL(18,0))

	INSERT INTO @carteras
	SELECT cartera, monto FROM [clientes].[dbo].[OrigenMontoSucursal] 
	WHERE id_SolicitudMonto IN (SELECT ID FROM [clientes].[dbo].[SolicitudMonto] WHERE tramites_Id = @idPertra)

	DECLARE @tot  INT = 0, @aux INT = 1
	SET @tot = (SELECT COUNT(id) FROM @carteras)


	SELECT @idCliente =  [idCliente], @idEmpresa = [idEmpresa],@idSuc = idSucursal FROM [clientes].[dbo].[TramiteCliente] WHERE [tramites_Id] = @idPertra
	SELECT @per_idpersona = [per_idpersona] FROM [clientes].[dbo].[Cliente] WHERE [idCliente] =  @idCliente
	SELECT @nomBaseConcentra = nombre_base FROM Centralizacionv2..DIG_CAT_BASES_BPRO   WHERE emp_idempresa = @idEmpresa AND tipo = 2
	SELECT @PER_NOMRAZON = PER_NOMRAZON, @PER_PATERNO =  PER_PATERNO , @PER_MATERNO = PER_MATERNO , @PER_RFC =  PER_RFC FROM  GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @per_idpersona



				WHILE(@aux <= @tot )
				BEGIN

					SELECT @cartera  = cartera , @monto = monto FROM @carteras WHERE id = @aux

					SET @consulta = ' UPDATE '+ @nomBaseConcentra +'.DBO.CXC_CONDCARTERA SET  Con_LimCredito =  (SELECT Con_LimCredito FROM '+ @nomBaseConcentra +'.DBO.CXC_CONDCARTERA WHERE Con_IdPersona ='+ CONVERT(NVARCHAR(20),@per_idpersona) +' AND Con_ClaveCartera = '''+ @cartera +''') - '+CONVERT(NVARCHAR(20), @monto ) + '  WHERE Con_IdPersona ='+CONVERT(NVARCHAR(20), @per_idpersona )+' AND Con_ClaveCartera = '''+ @cartera +''' '
	
					PRINT(@consulta)
					EXECUTE (@consulta)

	
				SET @aux = @aux + 1
				END




				DECLARE @RespuestaCredito INT
				EXECUTE [Clientes].[dbo].[INS_CREDITO_SP]   @idPertra = @idPertra, @result = @RespuestaCredito OUTPUT
				IF(@RespuestaCredito = 0)
				BEGIN
					SELECT 1/0
				END	




			UPDATE [Tramites].[dbo].[personaTramite]
			SET petr_estatus = 2 
			WHERE id_perTra = @idPertra

			SELECT success = 1, msg = 'Se traspaso  el credito con exito';


	--SET  @result = 1
	--RETURN @result

END TRY
BEGIN CATCH
	SET  @result = 0
	SELECT success = 0, msg = 'Servicio no disponible por el momento';
END CATCH
END
go

