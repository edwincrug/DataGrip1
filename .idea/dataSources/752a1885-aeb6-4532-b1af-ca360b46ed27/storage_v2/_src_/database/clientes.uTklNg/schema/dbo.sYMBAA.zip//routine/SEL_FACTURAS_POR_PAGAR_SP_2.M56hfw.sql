-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--	SEL_FACTURAS_POR_PAGAR_SP_2 144, 4
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FACTURAS_POR_PAGAR_SP_2]
	 @idCliente NUMERIC(18,0) = 0
	,@idEmpresa INT = 0
AS
BEGIN
		SET LANGUAGE español
		DECLARE @nombreBaseConcentra VARCHAR(300) = '',@nombreBase VARCHAR(300) = '', @cadena NVARCHAR(MAX) = '', 
		@rfcEmisor VARCHAR(50)='', @ipServidor VARCHAR(20)='', @rfcCliente VARCHAR(15) = '',@nombreCliente VARCHAR(300) = '',@per_idpersona INT = 0,
		@aux INT= 1, @max INT = 0
	   

		DECLARE @BDs TABLE(
		IDBD INT IDENTITY(1,1) PRIMARY KEY,
		emp_idempresa INT, 
		emp_nombre VARCHAR(200), 
		NombreBase VARCHAR(50),
		suc_idsucursal INT,
		suc_nombre VARCHAR(50)
		)
	  
		
		DECLARE @folios TABLE(
		idDocto NVARCHAR(200),
		cartera NVARCHAR(20),
		descripcionCartera NVARCHAR(200),
		tipoDocto  NVARCHAR(20),
		fechaDocumento NVARCHAR(20),
		fechaVencimiento NVARCHAR(20),
		diasVencidos NVARCHAR(5),
		estatus NVARCHAR(20),
		cargo DECIMAL(18,2),
		saldo DECIMAL(18,2),
		pedidos VARCHAR(50),
		cotizacion VARCHAR(50)
		)


		SELECT @rfcEmisor = rfc, @nombreBaseConcentra = nombre_base 
		FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
		WHERE emp_idempresa = @idEmpresa AND tipo = 2 
	  
	   INSERT INTO @BDs
	   SELECT EMP.emp_idempresa ,ME.marca ,BASEMP.nombre_base ,BASEMP.suc_idsucursal ,sucursales.suc_nombre
	   FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
	   INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
       INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.suc_idsucursal = sucursales.suc_idsucursal
	   INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  EMP.emp_idempresa
	   WHERE  BASEMP.emp_idempresa  = @idEmpresa
	  -- AND BASEMP.suc_idsucursal NOT IN (1,2,7,8,10,11)
	   AND BASEMP.tipo = 1

		SELECT @max = MAX(IDBD) FROM @BDs

		SELECT @rfcCliente = rfcCliente ,@nombreCliente = nombreCliente, @per_idpersona = per_idpersona
		FROM Cliente WHERE idCliente = @idCliente

	
		WHILE(@aux <= @max)
			BEGIN		
			
						
				SELECT  @nombreBase = NombreBase
				FROM @BDs WHERE IDBD = @aux
								
				SET @cadena = 'SELECT 
								CCP_IDDOCTO, 
								ccp_cartera,
								A.PAR_DESCRIP1,
								B.PAR_DESCRIP1,
								CCP_FECHADOCTO,
								CCP_FECHVEN,								
								CASE WHEN ISDATE(CCP_FECHVEN) = 1 
								THEN DATEDIFF(DAY,CONVERT(DATETIME,CCP_FECHVEN,103),GETDATE()) 
								ELSE 0  END,
								CASE WHEN DATEDIFF(DAY,CONVERT(DATETIME,CCP_FECHVEN,103),GETDATE()) <= 0 THEN ''Por Vencer'' ELSE ''Vencido'' END,
								CCP_CARGO AS cargo,  
								CCP_CARGO - (select isnull(sum(ccp_abono),0)  
								FROM ['+@nombreBaseConcentra+'].[dbo].[vis_concar01] as movimiento  			  
								WHERE movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  				
								AND movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  				
								AND movimiento.ccp_cartera   = Car_Externa.ccp_cartera  				
								AND movimiento.ccp_docori <> ''s''    				
								AND movimiento.CCP_TIPODOCTO <> ''FACTURA''), 
								CASE WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) IN (''A'',''B'',''D'') THEN (SELECT VTE_REFERENCIA1 FROM ['+@nombreBase+'].[DBO].[ADE_VTAFI] WHERE VTE_DOCTO = CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS)
								WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''F'' THEN (SELECT PMM_REF2 FROM ['+@nombreBase+'].[DBO].[PAR_PEDMOST] WHERE PMM_REF2 = CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS AND PMM_COTPED = ''PEDIDO'' ) 
								ELSE ''No identificado'' END, 
								CASE WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''A'' THEN (SELECT PMM_REF2 FROM ['+@nombreBase+'].[DBO].[PAR_PEDMOST] WHERE PMM_REF2 = CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS AND PMM_COTPED = ''PEDIDO'' ) 
								WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''D'' THEN ''SIN COTIZACIÓN'' 
								WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''B'' THEN ''PENDIENTE''
								ELSE ''No identificado'' END

								FROM ['+@nombreBase+'].[dbo].[VIS_CONCAR01]  AS Car_Externa 
								INNER JOIN ['+@nombreBaseConcentra+'].[dbo].[PNC_PARAMETR] As A ON CCP_CARTERA = A.PAR_IDENPARA 
								LEFT  JOIN ['+@nombreBaseConcentra+'].[dbo].[PNC_PARAMETR] As B ON CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = ''TIMO''
								INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] ON CCP_IDPERSONA = PER_IDPERSONA AND  PER_RFC =  ''' + @rfcCliente + '''

								WHERE   
								A.PAR_TIPOPARA = ''CARTERA''  
								AND A.PAR_IDMODULO = ''CXC''   	 
								AND B.PAR_DESCRIP1 = ''FACTURA'' 
								AND CONVERT(DATETIME,[CAR_EXTERNA].CCP_FECHADOCTO,103) >= CONVERT(DATETIME,''01/01/2014'',103) 
								AND CONVERT(DATETIME,[CAR_EXTERNA].CCP_FECHADOCTO,103) <= CONVERT(DATETIME,GETDATE(),103)  
								AND (CCP_CARGO - (select isnull(sum(ccp_abono),0)  
													FROM ['+@nombreBase+'].[dbo].[vis_concar01] as movimiento  			  
													WHERE movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  				
													AND movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  				
													AND movimiento.ccp_cartera   = Car_Externa.ccp_cartera  				
													AND movimiento.ccp_docori <> ''s''  				
													AND movimiento.CCP_TIPODOCTO <> ''FACTURA'') ) > 0  '
					
				PRINT(@cadena)
				INSERT INTO @folios
				EXECUTE (@cadena)

				SET @aux = @aux + 1	
	END

		SELECT 
		@idCliente AS idCliente,
		(select [referencias].[dbo].[fn_BuscaLetras](f.idDocto)) AS serie,
		(select [referencias].[dbo].[fn_BuscaNumeros](f.idDocto)) AS folio,
		f.descripcionCartera AS descripcion,
		f.fechaDocumento AS fechadoc,
		f.fechaVencimiento AS fechaVencimiento,
		f.diasVencidos AS diasCartera,
		f.estatus,
		f.cargo AS importe,
		f.saldo,
		EMP.emp_idempresa AS idEmpresa,
		sucursales.suc_idsucursal AS idSucursal,
		d.nombreDepartamento AS departamento,
		@rfcEmisor AS rfcEmisor,
		@rfcCliente AS rfcReceptor,
		ME.marca AS emp_nombre,
		--EMP.emp_nombre,
		sucursales.suc_nombre,
		d.idDepartamento,
		f.pedidos,
		f.cotizacion,		
		@per_idpersona AS emp_idPersona, 
		@nombreCliente AS nombreCliente,								
		(SELECT CASE WHEN d.nombreDepartamento = 'UNIDADES NUEVAS' THEN 'UN' 
		 WHEN d.nombreDepartamento = 'UNIDADES SEMINUEVAS' THEN 'US' 
		 WHEN d.nombreDepartamento = 'REFACCIONES' THEN 'RE' 
		 WHEN d.nombreDepartamento = 'SERVICIO' THEN 'SE' 
		 WHEN d.nombreDepartamento = 'NEGOCIOS' THEN 'RE' 
		 WHEN d.nombreDepartamento = 'HYP' THEN 'HYP' END) AS nomCortoDep,

		DD.mp_node,
		CON.mp_concept,                                                                                
		'david.vazquezr@outlook.com' AS correo,                                                                      
		ISNULL(COMI.visa,0) AS visa,
		ISNULL(COMI.masterCard,0) AS masterCard,
		ISNULL(COMI.amex,0) AS amex,
		RTRIM(COMI.mp_paymentmethod)  AS mp_paymentmethod

		FROM @folios f
		INNER JOIN [clientes].[dbo].[CatalogoDepartamento] d on f.cartera = d.claveCartera
		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON d.idEmpresa = EMP.emp_idempresa
		INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON d.idSucursal = sucursales.suc_idsucursal
		INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  EMP.emp_idempresa 
		LEFT JOIN [referencias].[dbo].[Cat_DivisionOrg_BBVA] DD ON DD.idEmpresa = d.idEmpresa AND DD.idSucursal = d.idSucursal
		INNER JOIN  [GA_Corporativa].[dbo].[PER_PERSONAS] P ON P.PER_IDPERSONA = @per_idpersona                          
		INNER JOIN  [clientes].[dbo].[Cat_Concepto_BBVA] CON ON CON.nomCortoDep =  CASE WHEN d.nombreDepartamento = 'UNIDADES NUEVAS' THEN 'UN' 
																						WHEN d.nombreDepartamento = 'UNIDADES SEMINUEVAS' THEN 'US' 
																						WHEN d.nombreDepartamento = 'REFACCIONES' THEN 'RE' 
																						WHEN d.nombreDepartamento = 'SERVICIO' THEN 'SE' 
																						WHEN d.nombreDepartamento = 'NEGOCIOS' THEN 'RE' 
																						WHEN d.nombreDepartamento = 'HYP' THEN 'HYP' END
		LEFT JOIN  [clientes].[dbo].[Cat_ComisionPago] COMI ON COMI.idEmpresa = d.idEmpresa AND COMI.idDepartamento = d.idDepartamento
		WHERE DD.estatus = 1
		ORDER BY cast(f.diasVencidos as int) DESC
	-- SEL_FACTURAS_POR_PAGAR_SP_2 145, 5
END
go

