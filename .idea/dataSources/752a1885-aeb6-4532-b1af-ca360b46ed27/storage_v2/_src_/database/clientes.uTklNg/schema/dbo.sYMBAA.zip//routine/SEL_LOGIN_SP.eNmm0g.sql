-- =============================================
-- Author:		ALEJANDRO LOPEZ QUIROZ
-- Create date: 24052016
-- Description:	obtiene las facturas por pagar por cliente
-- =============================================
--  [dbo].[SEL_LOGIN_SP] 'BRM840921P9A','123456'
CREATE PROCEDURE [dbo].[SEL_LOGIN_SP] 
	@user VARCHAR(15) = ''
   ,@pass VARCHAR(15) = ''
AS
BEGIN

	DECLARE  @passEnc varchar(300) =''
		
	SELECT   @passEnc = Usu.passwordU 	
	FROM Cliente Cli
	JOIN Usuario Usu ON Cli.idCliente = Usu.idCliente
	WHERE Cli.rfcCliente = @user 

	DECLARE @passs table (passDes NVARCHAR(50))

	DECLARE @cadena varchar(max)
	SET  @cadena ='SELECT convert(varchar(100),DecryptByPassPhrase(''4ndr4d3'',  '+ @passEnc +' )) '
	INSERT INTO @passs
	EXECUTE (@cadena)

	SELECT Cli.idCliente, Cli.idTipoCliente, Cli.nombreCliente + ' ' + Cli.apellidoPaterno + ' ' + Cli.apellidoMaterno nombreCliente,
		   Cli.idEstatus, Cli.rfcCliente, Usu.idTipoUsuario, Usu.idUsuario, Cli.imagen,Cli.per_tipo	
	FROM Cliente Cli
	JOIN Usuario Usu ON Cli.idCliente = Usu.idCliente
	WHERE Cli.rfcCliente = @user AND  @pass = (SELECT passDes FROM @passs)

END


go

