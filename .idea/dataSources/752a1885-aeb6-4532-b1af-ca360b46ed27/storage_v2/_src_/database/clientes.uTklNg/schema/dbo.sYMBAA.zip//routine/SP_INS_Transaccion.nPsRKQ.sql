-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_Transaccion]
	 @idEmpresa numeric(18,0)=0
    ,@idSucursal numeric(18,0)=0
    ,@idDepartamento numeric(18,0)=0
    ,@idTipoDocumento numeric(18,0)=0
    ,@importeDocumento decimal(18,2)=0
    ,@serie varchar(100)=NULL
    ,@folio varchar(100)=NULL
    ,@idCliente numeric(18,0)=0
    ,@idAlmacen int=0
    ,@idTipoReferencia int=0
    ,@idEstatus int=0
	,@idOrigen int=0
	,@Id numeric(18,0) OUTPUT
AS
BEGIN
	EXEC [referencias].[dbo].[SP_INS_Transaccion] 
															@idEmpresa = @idEmpresa
														   ,@idSucursal = @idSucursal
														   ,@idDepartamento = @idDepartamento
														   ,@idTipoDocumento = @idTipoDocumento
														   ,@importeDocumento = @importeDocumento
														   ,@serie = @serie
														   ,@folio = @folio
														   ,@idCliente = @idCliente
														   ,@idAlmacen = @idAlmacen
														   ,@idTipoReferencia = @idTipoReferencia
														   ,@idEstatus = @idEstatus
														   ,@idOrigen = @idOrigen
														   ,@Id = @Id OUTPUT

			--	SELECT @Id AS idTransRefe


END
go

