-- =============================================
-- Author:		ALEJANDRO LOPEZ QUIROZ
-- Create date: 27052016
-- Description:	obtiene catalogo de bancos
-- =============================================
CREATE PROCEDURE [dbo].[SEL_BANCOS_SP]	
AS
BEGIN
	
		SELECT 
				 [idBanco]
				,[nombre]
				,[convenio]
				,[urlMicroSitio]
				,[urlRespuesta]
				,[disponible]

		FROM [clientes].[dbo].[Banco]
		WHERE [disponible] = 2

END

go

