-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE UPD_NOTIFIACIONES_CLIENTES_SP
	@idsNots NVARCHAR(400) = ''
AS
BEGIN

		UPDATE [clientes].[dbo].[NotificacionCliente]
		SET visto = 1 , fechaRevision = GETDATE() 
		WHERE idNotificacion IN (SELECT idNotificacion FROM dbo.[SplitDocumentos](@idsNots))
	
END
go

