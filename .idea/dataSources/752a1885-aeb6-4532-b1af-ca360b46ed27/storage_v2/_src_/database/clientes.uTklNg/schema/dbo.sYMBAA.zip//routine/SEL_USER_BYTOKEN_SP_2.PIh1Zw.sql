CREATE PROCEDURE [dbo].[SEL_USER_BYTOKEN_SP_2]  --SEL_USER_BYTOKEN_SP @token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZENsaWVudGUiOjUsImlkVGlwb0NsaWVudGUiOjEsIm5vbWJyZUNsaWVudGUiOiJPc2NhciAgIiwiaWRFc3RhdHVzIjoxLCJyZmNDbGllbnRlIjoiWEFYWDAxMDEwMTAwMCIsImlkVGlwb1VzdWFyaW8iOjEsImlkVXN1YXJpbyI6MywiaW1hZ2VuIjoiWEFYWDAxMDEwMTAwMC5qcGVnIiwiaWF0IjoxNDY0ODg5OTQ0fQ.g1ostfeIpvajJBh5nKDmd_5VdBKRY7k09PWnrnzFjgw'
@token VARCHAR(300) = ''
AS
BEGIN

BEGIN TRY	
	
	SELECT Cli.idCliente, Cli.idTipoCliente, Cli.nombreCliente + ' ' + Cli.apellidoPaterno + ' ' + Cli.apellidoMaterno nombreCliente,
		   Cli.idEstatus, Cli.rfcCliente, Usu.idTipoUsuario, Usu.idUsuario, Cli.imagen
		  ,C.correo+';david.vazquezr@outlook.com' AS correo
		  -- ,'laura.gordillo@grupoandrade.com.mx' AS correo
		   ,Cli.per_idpersona AS idbpro,(SELECT CASE WHEN Cli.per_tipo = 'MOR' THEN 0 WHEN Cli.per_tipo = 'FIS' THEN 1 ELSE 3 END)  AS per_tipoMorFis
		   ,C.recibeNot
	FROM Cliente Cli
	JOIN Usuario Usu ON Cli.idCliente = Usu.idCliente
	INNER JOIN  UsuarioCorreo C ON C.idCliente = Cli.idCliente
	WHERE Usu.token COLLATE Latin1_General_CS_AS = @token 
	AND C.idTipoCorreo = 1 AND c.estatus = 1

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[UPD_USER_SETTOKEN_SP]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje--@msg

END CATCH
END
go

