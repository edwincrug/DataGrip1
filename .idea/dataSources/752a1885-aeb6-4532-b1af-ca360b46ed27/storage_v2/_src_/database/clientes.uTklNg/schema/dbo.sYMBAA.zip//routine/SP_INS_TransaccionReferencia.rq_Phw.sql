-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_TransaccionReferencia]
	  @idTrans numeric(18,0)
     ,@referencia varchar(100)
     ,@idReferencia numeric(18,0)
     ,@estatus varchar(100)
AS
BEGIN
		
	--IF NOT EXISTS (SELECT idReferencia FROM [PagosPinPadWeb].dbo.TransaccionReferencia WHERE idReferencia = @idReferencia)
	--BEGIN
	EXEC [referencias].[dbo].[SP_INS_TransaccionReferencia]   
											     @idTrans  = @idTrans
												,@referencia = @referencia
												,@idReferencia = @idReferencia
												,@estatus = @estatus
		SELECT 1 AS transReferen, @idTrans AS idTrans
	--END
	--ELSE
	--BEGIN
	--	DECLARE @idtransExite INT = 0

	--	SELECT @idtransExite = idTrans FROM [PagosPinPadWeb].dbo.TransaccionReferencia WHERE idReferencia = @idReferencia

	--	SELECT 2 AS transReferen, @idtransExite AS idTrans

	--END

END
go

