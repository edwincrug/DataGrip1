
-- =============================================
-- Author:		Irving Solorio	
-- Create date: 06/06/2019
-- Description:	Descompone string de pipes y comas
-- =============================================
--select * from dbo.[SplitDocumentos]('10,3|10,5|10,4|10,2|10,1')
 

CREATE FUNCTION [dbo].[SplitDocumentos](@input AS Varchar(8000) )

RETURNS

     @Result TABLE(idCliente VARCHAR(20),idNotificacion VARCHAR(20))

AS

BEGIN

      DECLARE @str VARCHAR(20),@str1 VARCHAR(20), @str2 VARCHAR(20),@pos int

      DECLARE @ind Int

      IF(@input is not null)

      BEGIN

            SET @ind = CharIndex('|',@input)

            WHILE @ind > 0

            BEGIN

                  SET @str = SUBSTRING(@input,1,@ind-1)

                  SET @input = SUBSTRING(@input,@ind+1,LEN(@input)-@ind)
				 Set @pos= charindex(',',@str)
					 Set @str1=substring(@str,1,@pos-1)
					 set @str2=substring(@str,@pos+1,len(@str)-@pos)
                  INSERT INTO @Result values (@str1,@str2)

                  SET @ind = CharIndex('|',@input)

            END

            SET @str = @input
			Set @str1=substring(@str,1,@pos-1)
			set @str2=substring(@str,@pos+1,len(@str)-@pos)
			INSERT INTO @Result values (@str1,@str2)
          

      END

      RETURN

END



go

