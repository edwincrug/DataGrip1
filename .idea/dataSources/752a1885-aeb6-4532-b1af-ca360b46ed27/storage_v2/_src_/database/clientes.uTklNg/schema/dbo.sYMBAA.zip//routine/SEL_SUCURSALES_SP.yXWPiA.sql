-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_SUCURSALES_SP] 
	@idEmpresa INT = 0
AS
BEGIN
		SELECT S.suc_idsucursal AS idSucursal
			  ,S.suc_nombre	  AS nombre
			  --,D.claveCartera AS cartera
			  --,D.tipoAgrupacion AS agrupacion
		FROM [ControlAplicaciones].[dbo].[cat_sucursales] S
		--INNER JOIN [clientes].[dbo].[CatalogoDepartamento] D ON D.idSucursal = S.suc_idsucursal
		WHERE S.emp_idempresa = @idEmpresa
	
END
go

