CREATE PROCEDURE [dbo].[UPD_USER_SETTOKEN_SP] 
@idCliente NUMERIC(18,0) = 0, 
@token VARCHAR(300) = '',
@accion INT = 0 --1 update token, 2 set = null
AS
BEGIN

BEGIN TRY	
	
	DECLARE @msg VARCHAR(500) = '', @estatus VARCHAR(10) = ''

	UPDATE Usuario
	SET token = @token
	WHERE idCliente = @idCliente

	SELECT @estatus = 'ok', @msg ='Token actualizado.'

	INSERT INTO Log_Clientes VALUES (99 ,@idCliente ,GETDATE(),'LOGIN TOKEN' )

	IF @accion = 1
	BEGIN 
	INSERT INTO Log_Clientes VALUES (1 ,@idCliente ,GETDATE(),'LOGIN' )
	END

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	INSERT INTO Log_Clientes VALUES (2 ,@idCliente ,GETDATE(),'ERROR'  )
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[UPD_USER_SETTOKEN_SP]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje--@msg

END CATCH
END




--CREATE SEL_USER_BYTOKEN_SP(token)
--{"idCliente","idTipoCliente","nombreCliente","idEstatus","rfcCliente" ,... }
go

