-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_RECUPERA_PASSWORD_SP]
@rfc VARCHAR(13) = ''
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY

   DECLARE @correo         VARCHAR(255)=''
   DECLARE @correoMascara  VARCHAR(255)=''
   DECLARE @pass           VARCHAR(255)=''
   DECLARE @msg            VARCHAR(500) = ''
   DECLARE @estatus        VARCHAR(10) = ''
   DECLARE @idCliente      INT = 0
   DECLARE @tokenID uniqueidentifier

   IF EXISTS (SELECT 1 FROM [Cliente] WHERE rfcCliente = @rfc)
   BEGIN
   	   SET @estatus = 'ok'
	   SET @msg ='RFC encontrado con exito'

	   SELECT  @correo = UC.correo
			  ,@pass   = u.passwordU 
			  ,@correoMascara = SUBSTRING(@correo, 1, 2) +    REPLICATE('*', CHARINDEX('@',@correo)-3) +    RIGHT(@correo, LEN(@correo) - CHARINDEX('@',@correo) + 1 )
			  ,@idCliente = c.idCliente
		 FROM Cliente c
		INNER JOIN Usuario u on c.idCliente = u.idCliente
		INNER JOIN  UsuarioCorreo UC ON UC.idCliente = C.idCliente
		WHERE rfcCliente = @rfc
		AND UC.idTipoCorreo = 1 AND UC.estatus = 1

		INSERT INTO Log_Clientes  VALUES(6,@idCliente , GETDATE(), 'Intento' )

		
		SET @tokenID = NEWID()

		IF NOT EXISTS(SELECT rfc FROM tokenRecuperaPass WHERE rfc = @rfc )
		BEGIN
			INSERT INTO tokenRecuperaPass
			SELECT @rfc, @tokenID
		END
		ELSE 
		BEGIN 
			UPDATE tokenRecuperaPass
			SET tokenRecupera =  @tokenID
			WHERE rfc = @rfc
		END
		
   END
   ELSE
   BEGIN
   	   SET @estatus = 'error'
	   SET @msg ='RFC no registrado en el Portal. Favor de crear una cuenta nueva.'
   END

	--DECLARE @passs table (passDes NVARCHAR(50))

	--DECLARE @cadena varchar(max)
	--SET  @cadena ='SELECT convert(varchar(100),DecryptByPassPhrase(''4ndr4d3'',  '+ @pass +' )) '
	--INSERT INTO @passs
	--EXECUTE (@cadena)

      SELECT  
		   @rfc            AS rfc
	      ,@idCliente	   AS idCliente
		  ,@correoMascara  AS correoMascara
	      ,@correo         AS correo
		  ,@msg            AS mensaje
		  ,@estatus        AS estatus
		  ,@tokenID		   AS token			


END TRY
BEGIN CATCH
	Print('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'PPROV_RECUPERA_PASSWORD_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
END CATCH
end
go

