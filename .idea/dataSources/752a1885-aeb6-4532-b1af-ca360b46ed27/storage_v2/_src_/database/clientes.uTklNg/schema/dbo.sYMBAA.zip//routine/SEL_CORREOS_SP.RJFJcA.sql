-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CORREOS_SP] 
		@idCliente INT = 0
AS
BEGIN

	SELECT idTipoCorreo AS id, descripcion AS nombre FROM TipoCorreo 
	WHERE idTipoCorreo NOT IN(SELECT idTipoCorreo FROM  UsuarioCorreo WHERE idCliente = @idCliente AND estatus = 1 )
	ORDER BY idTipoCorreo

	SELECT t.descripcion, u.correo,u.idUsuarioCorreo,u.idTipoCorreo FROM UsuarioCorreo u
	INNER JOIN TipoCorreo t ON t.idTipoCorreo = u.idTipoCorreo 
	WHERE u.idCliente = @idCliente AND estatus = 1 ORDER BY u.idTipoCorreo

END
go

