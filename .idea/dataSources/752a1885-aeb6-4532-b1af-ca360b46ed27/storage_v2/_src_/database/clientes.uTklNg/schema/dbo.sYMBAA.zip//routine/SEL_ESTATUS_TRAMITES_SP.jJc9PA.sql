-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ESTATUS_TRAMITES_SP]
	
AS
BEGIN
	  SELECT 
		   [id]
		  ,[descripcion]
		  ,[icono]
	  FROM [clientes].[dbo].[Cat_EstatusTramiteCliente]
END
go

