-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_LEYENDAS_PDF_SP] 
@idEmpresa INT = 0,
@tipoReferencia int = 0

AS
BEGIN
	if @tipoReferencia = 1
		BEGIN
			SELECT  
				idEmpresa
				,[descripcion]
				,orden
			FROM [referencias].[dbo].[Leyenda] 
				WHERE idEmpresa = 1 AND tipoReferencia = 1  order by orden asc
		END
	ELSE
		BEGIN
			SELECT  
				idEmpresa
				,[descripcion]
				,orden
			FROM [referencias].[dbo].[Leyenda] 
				WHERE idEmpresa = 1 AND tipoReferencia = 2 order by orden asc
		END
END

go

