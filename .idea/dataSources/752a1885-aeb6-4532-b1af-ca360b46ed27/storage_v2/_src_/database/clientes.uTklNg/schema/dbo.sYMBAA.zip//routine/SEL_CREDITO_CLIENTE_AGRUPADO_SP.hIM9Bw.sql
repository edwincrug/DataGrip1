-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- SEL_CREDITO_CLIENTE_AGRUPADO_SP 329480, 1 ,0
CREATE PROCEDURE [dbo].[SEL_CREDITO_CLIENTE_AGRUPADO_SP]
	 @idCliente INT = 0
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
AS
BEGIN

	DECLARE @consulta NVARCHAR(MAX), @nomBaseConcentra  NVARCHAR(200) = ''	
	DECLARE @cretidos TABLE (id INT IDENTITY(1,1),departamento NVARCHAR(50),tipoAgrupacion INT,limiteCredito NUMERIC(18,2))
		
	SELECT @nomBaseConcentra = nombre_base
	FROM Centralizacionv2..DIG_CAT_BASES_BPRO  
	WHERE emp_idempresa = @idEmpresa
	AND tipo = 2
						
	

	SET @consulta = 'SELECT  
						 C.nombreDepartamento
						,C.tipoAgrupacion
						,SUM(CART.Con_LimCredito)
						FROM ' + @nomBaseConcentra + '.dbo.cxc_condcartera  CART
						INNER JOIN [clientes].[dbo].[CatalogoDepartamento] AS C ON C.claveCartera COLLATE Modern_Spanish_CI_AS  = CART.Con_ClaveCartera
						WHERE Con_IdPersona  =  ' + CONVERT(NVARCHAR(20), @idCliente) +
						'AND CART.Con_ClaveCartera NOT IN(SELECT cartera_descripcion  COLLATE Modern_Spanish_CI_AS FROM [clientes].[dbo].[Cat_CarteraDiscriminar] WHERE  idEmpresa= '+ CONVERT(NVARCHAR(10),@idEmpresa) +') 
						GROUP BY C.nombreDepartamento,C.tipoAgrupacion'

	print(@consulta)
	INSERT INTO @cretidos
	EXECUTE(@Consulta)
	
	SELECT  departamento,tipoAgrupacion,limiteCredito FROM @cretidos

END
go

