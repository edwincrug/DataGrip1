-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	SEL_EXISTE_CLIENTE_SP 79672,0
CREATE PROCEDURE [dbo].[SEL_EXISTE_CLIENTE_SP] 
	 @per_idpersona INT = 0
	,@result INT OUTPUT
AS
BEGIN
	
	   DECLARE @nombreBase VARCHAR(50) = '', @nom_emp NVARCHAR(100) = '',@idEmpresa INT = 0, @ipServidor VARCHAR(20)=''
	   
	   DECLARE @aux INT= 1, @max INT = 0

	 
	   DECLARE @BDs TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(200), NombreBase VARCHAR(50))
	   INSERT INTO @BDs
	   SELECT EMP.emp_idempresa ,EMP.emp_nombre ,BASEMP.nombre_base 
	   FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
	   INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
	   WHERE BASEMP.tipo = 1
	   --AND BASEMP.emp_idempresa  IN (1,4)
	   --AND BASEMP.suc_idsucursal NOT IN (7,8,11)

	    SELECT @max = MAX(IDBD) FROM @BDs

		WHILE(@aux <= @max)
			BEGIN			
				SET @result = 0
				DECLARE @passEnc VARCHAR(100)
				DECLARE @passDecry  VARCHAR(50)
				DECLARE @SQLString NVARCHAR(500)
				DECLARE @ParmDefinition NVARCHAR(500)
				
				SELECT	@nombreBase = NombreBase, @idEmpresa = emp_idempresa  ,@nom_emp = emp_nombre FROM @BDs WHERE IDBD = @aux

			
				SET @SQLString =N'SELECT   @passD = ROL_IDPERSONA FROM ['+ @nombreBase +'].[dbo].[PER_ROLES] WHERE ROL_ROL=''CLI'' AND  ROL_IDPERSONA = ' + CONVERT(NVARCHAR(10),@per_idpersona)    
				SET @ParmDefinition = N' @passD varchar(MAX) OUTPUT';        
				EXECUTE sp_executesql @SQLString, @ParmDefinition, @passD = @passDecry OUTPUT;
				--print(@SQLString)
				IF(@passDecry > 0)
				BEGIN 
				SET @result = 1
					BREAK;
				END

				SET @aux = @aux + 1	
		END

		--SELECT @result 
		RETURN @result
	
END
go

