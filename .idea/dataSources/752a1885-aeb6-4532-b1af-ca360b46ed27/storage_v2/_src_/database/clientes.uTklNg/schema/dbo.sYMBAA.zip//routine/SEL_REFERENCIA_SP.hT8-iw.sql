CREATE PROCEDURE [dbo].[SEL_REFERENCIA_SP]
@serie VARCHAR(20) = '',
@folio VARCHAR(30) = '',
@tipo INT = 0,
@idCliente INT = 0
AS
BEGIN	

	DECLARE @consecutivo TINYINT = 0
	SELECT @consecutivo = consecutivoP FROM [dbo].[Consecutivo] WHERE [idConsecutivo] = 1


	SELECT @folio = SUBSTRING(@folio,LEN(@folio)-5,6)
	SELECT @serie = SUBSTRING(@serie,LEN(@serie)-2,3)
	
	SET @serie = REPLICATE('0',3-LEN(@serie)) + CONVERT(VARCHAR(3),@serie)
	SET @folio = REPLICATE('0',6-LEN(@folio)) + CONVERT(VARCHAR(6),@folio)

	SELECT [dbo].[referencia_fn](@serie,@folio,@consecutivo) + 
		   [dbo].[digito_verificador_fn]([dbo].[referencia_fn](@serie,@folio,@consecutivo)) AS REFERENCIA	

END
go

