CREATE PROCEDURE [dbo].[INS_RESPUESTA_BANCO_SP]
@respuesta XML = ''
--@idCliente NUMERIC(18,0) = 0,
--@referencia VARCHAR(20) = '',
--@folioFactura VARCHAR(30) = '',
--@importe DECIMAL(18,2) = 0,
--@mensajeRes VARCHAR(100) = '',
--@folio_oper VARCHAR(50) = '',
--@referenciaRes VARCHAR(50) = '',
--@estatusResp INT = 0,

/*@mensaje VARCHAR(500) = '',
@folio_oper VARCHAR(500) = '',
@estatusRes INT = 0,
@numContrato VARCHAR(20) = '',
@numUsuario VARCHAR(20) = '',
@nomUsuario VARCHAR(200) = '',
@convenio VARCHAR(50) = '',
@empresa VARCHAR(200) = '',
--@hora VARCHAR(15) = '',
--@folioOper VARCHAR(20) = '',
@referenciaRes VARCHAR(20) = '',
@cuentaCargo VARCHAR(20) = '',
@cuentaAbono VARCHAR(20) = '',
@titularCuentaCargo VARCHAR(200) = '',
@importe DECIMAL(18,2) = 0,
--@estatusOper VARCHAR(50) = '',
@concepto VARCHAR(100) = '',
@servicio_id VARCHAR(50) = '',
@banco VARCHAR(20) = '',
--@fin_datos VARCHAR(50) = '',
@ConvenioSD VARCHAR(50) = '',
@idconvenio VARCHAR(50) = '',
--@botonSalir VARCHAR(50) = ''
*/

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
	
	DECLARE @per_idpersona SMALLINT
	DECLARE @msg VARCHAR(500) = '', @estatus VARCHAR(10) = ''

	INSERT INTO PagoFactura(fecha,idEstatus,respuesta)
					 VALUES(GETDATE(),1,@respuesta)

	/*INSERT INTO PagoFactura(fecha,mensaje,folio_oper,estatus,numContrato,numUsuario,nomUsuario,convenio,empresa,
							hora,folioOper,referencia,cuentaCargo,cuentaAbono,titularCuentaCargo,importe,
							estatusOper,concepto,servicio_id,banco,fin_datos,ConvenioSD,idconvenio,botonSalir)
					 VALUES(GETDATE(),@mensaje,@folio_oper,@estatusRes,@numContrato,@numUsuario,@nomUsuario,@convenio,@empresa,
							@hora,@folioOper,@referenciaRes,@cuentaCargo,@cuentaAbono,@titularCuentaCargo,@importe,
							@estatusOper,@concepto,@servicio_id,@banco,@fin_datos,@ConvenioSD,@idconvenio,@botonSalir)*/
		
	SELECT @estatus estatus,@msg mensaje

END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @MensajeError  nvarchar(max),
	@Componente nvarchar(50) = '[INS_RESPUESTA_BANCO_SP]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje--@msg

END CATCH
END
go

