-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--TEST INS_DATOS_USUARIO_OTHER_PORTAL_SP 105891, '123456', 'lgarciaperrusqui@gmail.com'
-- =============================================
CREATE PROCEDURE [dbo].[INS_DATOS_USUARIO_OTHER_PORTAL_SP]
	@idPerPersona INT,
	@password VARCHAR(50),
	@correo VARCHAR(300)
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @respuesta INT;
	DECLARE @rfc VARCHAR(200), @nomRazon VARCHAR(200), @apellidoPaterno VARCHAR(200), @apellidoMaterno VARCHAR(200), @tipo VARCHAR(5);
	DECLARE @idClienteCount INT;

	SELECT  
		@rfc = PER_RFC,
		@nomRazon = PER_NOMRAZON, 
		@apellidoPaterno = PER_PATERNO, 
		@apellidoMaterno = PER_MATERNO, 
		@tipo = PER_TIPO 
	FROM GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @idPerPersona

	EXECUTE [dbo].[SEL_EXISTE_CLIENTE_SP] @idPerPersona, @result = @respuesta OUTPUT

	SELECT 
		@idClienteCount = COUNT(idCliente)
	FROM Cliente WHERE per_idpersona = @idPerPersona

	IF(@idClienteCount = 0)
		BEGIN
			IF( @respuesta <> 0 )
				BEGIN
					INSERT INTO Cliente (idTipoCliente, nombreCliente, apellidoPaterno, apellidoMaterno, fechaAlta, idEstatus, rfcCliente, correo, imagen,per_idpersona, per_tipo)
					VALUES(1, @nomRazon, @apellidoPaterno, @apellidoMaterno, GETDATE(), 1, @rfc, @correo, 'avatar.png', @idPerPersona, @tipo )
					DECLARE @idCliente NUMERIC(18,0) = @@IDENTITY

					DECLARE @cadena VARBINARY(200),  @cadenaEncrypt VARCHAR(200)   
					SELECT @cadena = EncryptByPassPhrase('4ndr4d3', @password)  

					SET @cadenaEncrypt = (SELECT CONVERT(VARCHAR(300), @cadena, 1));

					INSERT INTO Usuario (passwordU ,idTipoUsuario ,idCliente )
					VALUES (@cadenaEncrypt ,1 ,@idCliente )

					DECLARE @tokenID uniqueidentifier
					SET @tokenID = NEWID()

					INSERT INTO CorreoActivacion ([token] ,[per_rfc] ,[fechaCreacion] ,[fechaActivacion] ,[idEstatus] )
					VALUES (@tokenID, @rfc, GETDATE(), GETDATE(), 1 )

					INSERT INTO UsuarioCorreo 
					VALUES (@idCliente, @correo, 1, 1, 1 )

					INSERT INTO [clientes].[dbo].[NotificacionCliente] 
					VALUES ('Bienvenido al portal Clientes','Le damos la bienvenida al portal donde podra dar seguimineto a sus facturas y créditos en Grupo Andrade', 0, GETDATE(), '', @idCliente)

					SELECT success = 1, msg = 'Usuario registrado con èxito'

					SELECT rfc = @rfc, nombre = @nomRazon, apellidoP = @apellidoPaterno, apellidoM = @apellidoMaterno, moralFisica = @tipo, idCliente = @idCliente
				END
			ELSE
				BEGIN
					SELECT success = 0, msg ='Usuario no es Cliente de Grupo Andrade'
				END
		END
	ELSE
		BEGIN
			SELECT success = 0, msg ='Usuario ya registrado'
		END
END
go

