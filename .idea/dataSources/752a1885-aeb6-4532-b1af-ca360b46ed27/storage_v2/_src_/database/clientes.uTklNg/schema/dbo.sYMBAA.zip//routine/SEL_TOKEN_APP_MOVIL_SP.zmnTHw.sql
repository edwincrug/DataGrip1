-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST SEL_TOKEN_APP_MOVIL_SP '123456789'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TOKEN_APP_MOVIL_SP] 
	@token VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @tokenParam VARCHAR(100) = '';
	SELECT 
		@tokenParam = valor
	FROM [dbo].[Parametros] WHERE nombre = 'TOKEN_APPMOVIL'

	IF( @token = @tokenParam )
		BEGIN
			SELECT success = 1
		END
	ELSE
		BEGIN
			SELECT success = 0
		END
END
go

