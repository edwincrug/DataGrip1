-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE INS_MONTO_SUC_ORIGEN_SP
	 @id_SolicitudMonto INT = 0
	,@idSucursal  INT = 0
	,@monto NUMERIC(18,2)
	,@claveCartera NVARCHAR(10)
AS
BEGIN
		INSERT INTO [clientes].[dbo].[OrigenMontoSucursal] (id_SolicitudMonto,idSucursal,monto,cartera)
		VALUES (@id_SolicitudMonto,@idSucursal,@monto,@claveCartera)

		SELECT 1 AS exito
END
go

