-- =============================================
--		Emiliano Damazo
-- =============================================
--	[dbo].[SP_SEL_CarterasTotalCreditos] 1,3,329965
CREATE PROCEDURE [dbo].[SP_SEL_CarterasTotalCreditos] 
(
	@idEmpresa int=0,
	@tipoAgrupacion int=0,
	@idPersona int=0
)
AS
BEGIN

BEGIN TRY 
				
			DECLARE @carteras TABLE(Clave  VARCHAR(200), Total DECIMAL(18,2))
			

			
			DECLARE @baseConcentra VARCHAR(200)
			SELECT @baseConcentra = BASEMP.nombre_base 
			FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
			INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
			WHERE BASEMP.tipo = 2
			AND BASEMP.emp_idempresa = @idEmpresa

		

			--Varibales				
			--DECLARE @TablaCarteras TABLE (claveCartera VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,idSuc int,nombreDepartamento VARCHAR(200));


				DECLARE @consulta VARCHAR(MAX)

				--- .suc_observaciones + ' - ' +B.nombreDepartamento AS 'Clave', Con_LimCredito AS 'Total'
					SET @consulta = 'SELECT C.suc_observaciones + '' - '' +B.nombreDepartamento, Con_LimCredito 
					FROM ['+@baseConcentra+'].[dbo].[CXC_CONDCARTERA]  AS A
					INNER JOIN [clientes].[dbo].[CatalogoDepartamento] AS B on  A.Con_ClaveCartera= B.claveCartera COLLATE SQL_Latin1_General_CP1_CI_AS
					INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] AS C on  C.suc_idsucursal=B.idSucursal
					WHERE A.Con_IdPersona='+CONVERT(NVARCHAR(20), @idPersona);

					PRINT(@consulta)
				
					INSERT INTO @carteras
					EXECUTE (@consulta)

					SELECT Clave,Total FROM @carteras
			
END TRY  
BEGIN CATCH  
    SELECT 0 As 'error'; 
END CATCH;

END
go

