-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TRAMITES_CLINETE_ACTIVOS_SP]
	 @idCliente INT = 0
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
AS
BEGIN
		SELECT   [idCliente]
				,[observacion]
				,[fecha]
				,[estatus] AS idEstatus
				,[tramites_Id] AS tramites_Id
				,[idEmpresa]
				,[idSucursal]
				,[idDepartamento]
				,[monto]
				,[cartera]
				,TC.[descripcion] AS descripcion
				,ET.descripcion AS estatus
				,CAT.[nombre] AS catalogo
				,TC.id_tramiteAsolicitar AS id_tramiteAsolicitar
		FROM [clientes].[dbo].[TramiteCliente] TC
			INNER JOIN [clientes].[dbo].[Cat_EstatusTramiteCliente] ET ON ET.id = TC.estatus
			INNER JOIN [clientes].[dbo].[Cat_Tramites_clientes] CAT ON CAT.idtramite = TC.id_tramiteAsolicitar
		WHERE TC.idCliente = @idCliente 
		ORDER BY TC.[tramites_Id] DESC
			 --AND TC.idEmpresa = @idEmpresa
			 --AND TC.idSucursal = @idSucursal

END
go

