-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 27/09/2016       14hrs
-- Description:	Detalle de Documentos Pagados
-- 1.-Pago Puntual
-- 2.-Pago Inpuntual
-- ==========================================================================================
--EXECUTE [dbo].[SEL_DOC_PAGADOS_DETALLE_SP] @rfc='GNP9211244P0', @idEmpresa=4               --40078 --11 --46440  
CREATE PROCEDURE [dbo].[SEL_DOC_PAGADOS_DETALLE_SP] 
     @rfc     NVARCHAR(50)=''
	,@idEmpresa     int = 0 
AS
BEGIN
	SET NOCOUNT ON;
	--=======================================================================================-- 
    --  Documentos Pagados 
	--  1.Fecha Pagado antes o en la FechaVencimiento 
	--  2.Fecha Pagado despues FechaVencimiento  
	--  3.No tiene Fecha de Vencimiento
	--=======================================================================================-- 
		---------------------------------------------------------------
		--  Buscamos la  IP del Servidor y  la Base                  --
		---------------------------------------------------------------
		DECLARE @ipServidor    VARCHAR(100);
		DECLARE @cadIpServidor VARCHAR(100);
		DECLARE @nombreBase    VARCHAR(100);
		DECLARE @campos        VARCHAR(max);
		DECLARE @tabla         VARCHAR(max);
		DECLARE @condicion     VARCHAR(max);
		DECLARE @select        VARCHAR(max);
		DECLARE @rfcEmisor	   VARCHAR(50);

		DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
		DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL

		DECLARE @consulta   VARCHAR(max)=NULL;
		DECLARE @consultaDos   VARCHAR(max)=NULL;
		DECLARE @where      VARCHAR(max)=NULL;

		SELECT @nomBaseConcentra = [nombre_base] 
				,@nomBaseMatriz    =[nombre_base_matriz]       
				,@ipServidor       = [ip_servidor]      
			FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO]
			WHERE catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto 
		  							FROM [ControlAplicaciones].[dbo].[cat_empresas]
								WHERE [emp_idempresa] = @idEmpresa)
			AND tipo = 2
			--AND estatus = 1  --Activo para pruebas
		DECLARE @ipServidorTabla VARCHAR(20);
		SELECT @ipServidorTabla = [valor] FROM [clientes].[dbo].[Parametros] WHERE idParametro = 4
		--print  @ipServidorTabla

		--select @nomBaseConcentra,@nomBaseMatriz, @ipServidor
		---------------------------------------------------------------
		--  Para cambiar la consulta si es local o no                --
		---------------------------------------------------------------
		IF (@ipServidor = @ipServidorTabla)
		BEGIN
		set @cadIpServidor =''
		END
		ELSE
		BEGIN
		set @cadIpServidor =' [' + @ipServidor + '].'
		END
		--select @cadIpServidor

		DECLARE @documentosPagados TABLE  (ID INT IDENTITY(1,1)
											,idCliente		 int
											,rfc			 varchar(20)
											,rfcEmisor		 varchar(50)
											,serie			 varchar(150)
											,folio			 varchar(150)
											,idEmpresa       int 
											,empresa	     nvarchar(150)
											,idSucursal	     int  --Cadena
											,sucursal        nvarchar(150)
											,idDepartamento  int
											,departamento    nvarchar(100)
											,cartera         nvarchar(10)
											,idDocto         nvarchar(20)
											,tipoDocto       nvarchar(20)
											,fechaVencimiento DATE
											,fechaUltimoPago  DATE
											,cargo           numeric(18,5)
											,abono           numeric(18,5)
											,saldo           numeric(18,5) 
											,tipoPagoFecha   int
											,diasVencidos    int
											)

	-----------BEGIN Se busca el rfc del Emisor es decir de la empresa-----------------------
				SELECT	 @rfcEmisor= rfc	
					 FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP where tipo=2 
					 AND ISNULL(rfc,'') != '' AND emp_idempresa=@idEmpresa

					 print @rfcEmisor
				-----------END Se busca el rfc del Emisor es decir de la empresa-------------------------

    
	SET @consulta = 'SELECT [CCP_IDPERSONA],'+
							+char(39)+@rfc+char(39)+
							','+char(39)+@rfcEmisor+char(39)+
							', (select [referencias].[dbo].[fn_BuscaLetras](CCP_IDDOCTO)), (select [referencias].[dbo].[fn_BuscaNumeros](CCP_IDDOCTO)),'
							+ cast (@idEmpresa as varchar(2)) +' AS idEmpresa '
							
						   
	SET @consultaDos=',(SELECT [emp_nombre]   '+
					'    FROM [ControlAplicaciones].[dbo].[cat_empresas]' +
					'   WHERE [emp_idempresa] = '+ cast (@idEmpresa as varchar(2)) +')      AS empresa ' +
					',A.PAR_DESCRIP2                              AS idSucursal' +
					',(SELECT B.nombre_sucursal  ' +
					'   FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B ' +
					'  WHERE B.catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto ' + 
     				'								FROM [ControlAplicaciones].[dbo].[cat_empresas] ' +
					'							   WHERE [emp_idempresa] = '+ cast (@idEmpresa as varchar(2)) +')
						AND B.num_base_BI = A.PAR_DESCRIP2 COLLATE Modern_Spanish_CI_AS
						AND B.num_base_BI IS NOT NULL
						)                                       AS sucursal  ' +
					',SUBSTRING(A.PAR_HORA1,4,2)                  AS idDepartamento  ' +
					',(SELECT [dep_nombre]    ' +
					'   FROM [ControlAplicaciones].[dbo].[cat_departamentos]    ' +
						' WHERE [dep_iddepartamento] = SUBSTRING(A.PAR_HORA1,4,2))  AS departamento   ' +
					--',(SELECT [dep_nombre]    ' +
					--'   FROM [ControlAplicaciones].[dbo].[cat_departamentos]    ' +
					-- ' WHERE [dep_iddepartamento] = SUBSTRING(A.PAR_HORA1,4,2))  AS departamento   ' +
					',ccp_cartera                                 AS cartera   ' +
					',CCP_IDDOCTO                                 AS idDocto    ' +
					',B.PAR_DESCRIP1                              AS tipoDocto    ' +
					',CONVERT(DATE, CCP_FECHVEN, 103)                                 AS fechaVencimiento  ' +
					',(select top 1 CONVERT(DATE, movimiento.CCP_FECHADOCTO, 103)  ' +
					'   from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' + 
						' where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto   ' +
						'and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona   ' +
						'and movimiento.ccp_cartera   = Car_Externa.ccp_cartera   ' +
						'and movimiento.ccp_docori <> '+''''+'s'+''''+'  ' +
						'and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+'  ' +
						'and movimiento.CCP_ABONO > 0  ' +
						'order by CCP_FECHADOCTO asc  ' +
						')    AS fechaUltimoPago   ' +
					',CCP_CARGO          AS cargo   ' +
					',(select isnull(sum(ccp_abono),0)  ' +
								'   from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' +
								'  where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  ' +
								'	and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  ' +
								'	and movimiento.ccp_cartera   = Car_Externa.ccp_cartera  ' +
								'	and movimiento.ccp_docori <> '+''''+'s'+''''+'     ' +
								'	and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+')      AS abono ' +
					',CCP_CARGO - (select isnull(sum(ccp_abono),0)    ' +
					'			   from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' + 
					'			  where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  ' +
					'				and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  ' +
					'				and movimiento.ccp_cartera   = Car_Externa.ccp_cartera  ' +
					'				and movimiento.ccp_docori <> '+''''+'s'+''''+'    ' +
					'				and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+')      AS saldo  ' +
					',CASE WHEN (SELECT DATEDIFF(day,(select top 1 CONVERT(DATE,movimiento.CCP_FECHADOCTO, 103)    ' +
													'	  from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento   ' + 
													'	 where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto   ' +
												'	   and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona   ' +
												'	   and movimiento.ccp_cartera   = Car_Externa.ccp_cartera   ' +
												'	   and movimiento.ccp_docori <> '+''''+'s'+''''+
												'	   and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+
												'	   and movimiento.CCP_ABONO > 0   ' +
												'	 order by CCP_FECHADOCTO asc   ' +
												'		),CONVERT(DATE,Car_Externa.CCP_FECHVEN, 103))) >= 0  THEN  1   ' +   
						'  WHEN  (SELECT DATEDIFF(day,(select top 1 CONVERT(DATE,movimiento.CCP_FECHADOCTO, 103) 
														from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento 
														where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto 
														and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona 
														and movimiento.ccp_cartera   = Car_Externa.ccp_cartera 
														and movimiento.ccp_docori <> '+''''+'s'+''''+' 
														and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+'
														and movimiento.CCP_ABONO > 0
														order by CCP_FECHADOCTO asc
														),CONVERT(DATE,Car_Externa.CCP_FECHVEN, 103) )) < 0  THEN  2 
							ELSE 3											
						END                                                           AS tipoPagoFecha  
						,'+''''+'diasVencidos'+''''+' = CASE WHEN isdate(CCP_FECHVEN) = 1 
															then DATEDIFF(DAY,CONVERT(DATETIME,CCP_FECHVEN,103),GETDATE()) 
														else 0 
														end'
		PRINT @consulta
		print 'jojojojojojojoj'
	   SET @where='	FROM ['+ @nomBaseConcentra +'].[dbo].[VIS_CONCAR01]  AS Car_Externa 
						 INNER JOIN ['+ @nomBaseConcentra +'].[dbo].[PNC_PARAMETR] As A ON CCP_CARTERA = A.PAR_IDENPARA 
						 LEFT OUTER JOIN ['+ @nomBaseConcentra +'].[dbo].[PNC_PARAMETR] As B ON CCP_TIPODOCTO = B.PAR_IDENPARA 
			                       												  AND B.PAR_TIPOPARA = '+''''+'TIMO'+''''+' 
						 INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] ON CCP_IDPERSONA = PER_IDPERSONA AND  PER_RFC = '+char(39)+ @rfc+char(39) +' 
						 LEFT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] Z ON Car_Externa.ccp_iddocto = Z.oce_folioorden COLLATE Modern_Spanish_CI_AS  
				   WHERE A.PAR_TIPOPARA = '+''''+'CARTERA'+''''+'  
					 AND A.PAR_IDMODULO = '+''''+'CXC'+''''+'   
					 AND a.par_importe5 <> 1   
					 AND B.PAR_DESCRIP1 = '+''''+'FACTURA'+''''+' 
					 AND DATEDIFF (DAY,CONVERT(DATE, CCP_FECHVEN, 103),GETDATE()) >= 0  
			   ORDER BY CCP_CONSCARTERA'  
		print @where
		--SELECT @consulta + @where

		INSERT INTO  @documentosPagados
		    EXECUTE (@consulta+@consultaDos + @where);

		--select * FROM @documentosPagados 
		

	   SELECT  d.serie				   AS serie
			  ,d.folio				   AS folio
			  ,d.idCliente			   AS idCliente
			  ,d.rfc				   AS	rfcReceptor
			  ,d.rfcEmisor			   AS rfcEmisor
	          ,d.idEmpresa             AS idEmpresa
	          ,UPPER(ISNULL (d.empresa,'SIN EMPRESA EN APLICACIONES'))      AS empresa
	          ,d.idSucursal            AS idSucursal
			  ,UPPER(ISNULL (d.sucursal,'SIN SUCURSAL EN APLICACIONES'))    AS sucursal
			  ,d.idDepartamento        AS idDepartamento
			  ,UPPER(ISNULL (d.departamento,'SIN DEPTO EN APLICACIONES'))   AS departamento
			  ,d.idDocto          AS idDocumento
			  ,d.cartera          AS cartera               --Preguntar
			  ,CONVERT(nvarchar(10),d.fechaVencimiento, 103) AS fechaVencimiento
			  ,CONVERT(nvarchar(10),d.fechaUltimoPago, 103)  AS fechaPago
			  ,DATEDIFF(DAY,CONVERT(DATE, d.fechaVencimiento, 103),CONVERT(DATE,d.fechaUltimoPago, 103))  AS diasAtraso
			  ,d.cargo                                       AS cargo
			  ,d.saldo                                       AS saldo
	     FROM @documentosPagados AS d
        WHERE d.idEmpresa = @idEmpresa                   --d.diasVencidos <= 365
		  --AND d.fechaVencimiento >= (SELECT  CONVERT(DATE,DATEADD(YY,-1,Getdate()),103) )
	 ORDER BY d.tipoPagoFecha,d.idSucursal,d.idDepartamento

END

go

