-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	SEL_DETALLE_CREDITO_DONAS_SP 79672,4,6,'Z3'
CREATE PROCEDURE [dbo].[SEL_DETALLE_CREDITO_DONAS_SP] 
	 @idCliente INT = 0
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
	,@cartera NVARCHAR(20)
AS
BEGIN
	 DECLARE @BDs TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(200), NombreBase VARCHAR(50),suc_idsucursal INT,suc_nombre VARCHAR(50))
	  
	   DECLARE @nombreBase VARCHAR(50) = '', @cadena NVARCHAR(MAX) = '', @nom_suc NVARCHAR(200) = '', @nom_emp NVARCHAR(100) = '',--  @idSucursal NVARCHAR(10) = '',
	   @rfcEmisor VARCHAR(50)='', @ipServidor VARCHAR(20)='', @rfcCliente VARCHAR(15) = ''
	   
	   DECLARE @aux INT= 1, @max INT = 0

	   DECLARE @Facturas TABLE( ID INT IDENTITY(1,1),idCliente NUMERIC(18,0),serie VARCHAR(50),folio VARCHAR(50)
	   ,descripcion VARCHAR(MAX),fechadoc VARCHAR(50),fechaVencimiento VARCHAR(50),diasCartera NUMERIC(18,0),estatus VARCHAR(50),importe decimal(18, 5),
				saldo decimal(18, 5),idEmpresa NUMERIC(18,0),idSucursal NUMERIC(18,0),departamento VARCHAR(50),rfcEmisor VARCHAR(50),rfcReceptor VARCHAR(50),suc_nombre VARCHAR(50),emp_nombre VARCHAR(50),idDepartamento NUMERIC(18,0),pedidos VARCHAR(50),cotizacion VARCHAR(50),emp_idPersona NUMERIC(18,0))

		


	   INSERT INTO @BDs
	   SELECT EMP.emp_idempresa ,ME.marca ,BASEMP.nombre_base ,BASEMP.suc_idsucursal ,sucursales.suc_nombre
	   FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
	   INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
       INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.suc_idsucursal = sucursales.suc_idsucursal
	   INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  EMP.emp_idempresa
	   WHERE  BASEMP.emp_idempresa = @idEmpresa
	   AND BASEMP.suc_idsucursal = @idSucursal
	   AND BASEMP.tipo = 1

		
		
		SELECT @max = MAX(IDBD) FROM @BDs

		SELECT @rfcCliente = rfcCliente FROM Cliente WHERE per_idpersona = @idCliente

	
		WHILE(@aux <= @max)
			BEGIN		
			
				
			
				SELECT	@nombreBase = NombreBase, @idEmpresa = emp_idempresa ,@nom_suc = suc_nombre ,@nom_emp = emp_nombre FROM @BDs WHERE IDBD = @aux
					SELECT @rfcEmisor = rfc FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP WHERE emp_idempresa = @idEmpresa AND  tipo = 2 

					
				SET @cadena = 'SELECT '+ CAST(@idCliente AS VARCHAR(10))+
										',(select [referencias].[dbo].[fn_BuscaLetras](CCP_IDDOCTO))' +
										',(select [referencias].[dbo].[fn_BuscaNumeros](CCP_IDDOCTO))' +
										',DES_CARTERA' +
										',CCP_FECHADOCTO' +
										',FECHAVENCIDO' +
										',DIASVENCIDOS' +
										',CASE'+
											' WHEN DIASVENCIDOS <= 0 THEN ''Por Vencer'' ' +
											'ELSE ''Vencido'' ' +
										'END AS ''estatus'' ' +
										',IMPORTE' +
										',SALDO' +
							            ','+CONVERT(NVARCHAR(10),@idEmpresa ) +
										','+CONVERT(NVARCHAR(10),@idSucursal) +
										',OrigenMovimiento'+ char(13) +
										','+char(39)+ @rfcEmisor + char(39) +
										', PER_RFC '+ char(13) +
										','+char(39)+ @nom_suc +char(39)+
										','+char(39)+ @nom_emp +char(39)+
										',(SELECT dep_iddepartamento FROM [ControlAplicaciones].[dbo].[cat_departamentos] WHERE emp_idempresa = ' +CONVERT(NVARCHAR(10),@idEmpresa )+' AND suc_idsucursal = '+CONVERT(NVARCHAR(10),@idSucursal)+' AND  dep_nombrecto = ' + char(13) + 
										' (SELECT CASE WHEN OrigenMovimiento = ''NUEVOS'' THEN ''UN'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''SEMINUEVOS'' THEN ''US'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''REFACCIONES'' THEN ''RE'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''SERVICIO '' THEN ''SE'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''NEGOCIOS '' THEN ''RE'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''HOJALATERIA Y PINTURA '' THEN ''SE'' END))'+
										',CASE WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) IN (''A'',''B'',''D'') THEN (SELECT VTE_REFERENCIA1 FROM ['+@nombreBase+'].[DBO].[ADE_VTAFI] WHERE VTE_DOCTO = CCP_IDDOCTO)'+
										' WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''F'' THEN (SELECT PMM_REF2 FROM ['+@nombreBase+'].[DBO].[PAR_PEDMOST] WHERE PMM_REF2 = CCP_IDDOCTO AND PMM_COTPED = ''PEDIDO'' ) ELSE ''No identificado'' END ' +
										',CASE WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''A'' THEN (SELECT PMM_REF2 FROM  ['+@nombreBase+'].[DBO].[PAR_PEDMOST] WHERE PMM_REF2 = CCP_IDDOCTO AND PMM_COTPED = ''PEDIDO'' )'+
										' WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''D'' THEN ''SIN COTIZACIÓN'' ' + CHAR(13)+
										' WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''B'' THEN ''PENDIENTE'' ' + CHAR(13)+
										' ELSE ''No identificado'' END ' +
										',CCP_IDPERSONA' + CHAR(13)+
								' FROM ['+@nombreBase+'].[DBO].[BI_CARTERA_CLIENTES] '  + 
								' WHERE DES_TIPODOCTO = ''FACTURA'' AND SUBSTRING(CCP_IDDOCTO,1,2) ' + char(13) + 
								' IN(SELECT SUBSTRING(FCF_SERIE,1,2)' + char(13) + 
								' FROM  ['+@nombreBase+'].[DBO].[ADE_CFDFOLIOS]) AND OrigenMovimiento IN (''NUEVOS'',''SEMINUEVOS'',''REFACCIONES'',''SERVICIO'',''HOJALATERIA Y PINTURA'') ' + char(13) + 
								' AND PER_RFC = ''' + @rfcCliente + '''
								  AND CCP_CARTERA = ''' + @cartera + ''' order by FECHAVENCIDO asc
								' 
								PRINT (@cadena)
								
								INSERT INTO @Facturas
								execute (@cadena)

				SET @aux = @aux + 1	
	END

	SELECT idCliente ,serie ,folio AS documento,descripcion AS dep,fechadoc AS fecha ,fechaVencimiento AS fechaV ,diasCartera AS diasV,estatus ,importe ,saldo AS cargo,idEmpresa ,idSucursal ,departamento ,rfcEmisor ,rfcReceptor,suc_nombre ,emp_nombre AS nombre ,idDepartamento ,pedidos AS pedido,cotizacion ,emp_idPersona FROM  @Facturas ORDER BY fechaVencimiento asc



	---- antes
	--DECLARE @consulta NVARCHAR(MAX), @nomBaseConcentra  NVARCHAR(200) = ''
	--DECLARE @montos TABLE (id INT IDENTITY(1,1),serie NVARCHAR(20),documento NVARCHAR(20),cargo NUMERIC(18,2),abono NUMERIC(18,2),saldo NUMERIC(18,2),fecha NVARCHAR(20),fechaV NVARCHAR(20),estatus NVARCHAR(20),pedido NVARCHAR(20), diasV NVARCHAR(20) )

	--SELECT @nomBaseConcentra = nombre_base
	--FROM Centralizacionv2..DIG_CAT_BASES_BPRO  
	--WHERE emp_idempresa = @idEmpresa
	--AND tipo = 2

	--SET @consulta = 'SELECT  
	--						(select [referencias].[dbo].[fn_BuscaLetras](CCP_IDDOCTO))
	--						,(select [referencias].[dbo].[fn_BuscaNumeros](CCP_IDDOCTO))
	--						,CCP_CARGO          AS cargo  
	--						,(select isnull(sum(ccp_abono),0) from ['+@nomBaseConcentra+'].[dbo].[vis_concar01] as movimiento    
	--							where 
	--							movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto 
	--							and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  
	--							and movimiento.ccp_cartera  = '''+@cartera+''' 
	--							and movimiento.ccp_docori <> ''s''  
	--							and movimiento.CCP_TIPODOCTO <> ''FACTURA'')      AS abono 


	--						,CCP_CARGO - 
	--							(select isnull(sum(ccp_abono),0)  from ['+@nomBaseConcentra+'].[dbo].[vis_concar01] as movimiento  
	--							where movimiento.ccp_iddocto = Car_Externa.ccp_iddocto  
	--							and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona 
	--							and movimiento.ccp_cartera   = '''+@cartera+'''
	--							and movimiento.ccp_docori <> ''s'' 
	--							and movimiento.CCP_TIPODOCTO <> ''FACTURA'')      AS saldo  
	--						,CCP_FECHOPE
	--						,CCP_FECHVEN
	--						,CASE'+
	--							' WHEN 1 <= 0 THEN ''Por Vencer'' ' +
	--							'ELSE ''Vencido'' ' +
	--						'END AS ''estatus''
	--						,12212 AS pedido 
	--						,56 AS diasV
	--					FROM ['+@nomBaseConcentra+'].[dbo].[VIS_CONCAR01]  AS Car_Externa 
	--					INNER JOIN ['+@nomBaseConcentra+'].[dbo].[PNC_PARAMETR] As A ON CCP_CARTERA = A.PAR_IDENPARA 
	--					LEFT OUTER JOIN ['+@nomBaseConcentra+'].[dbo].[PNC_PARAMETR] As B ON CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = ''TIMO'' 
	--					INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] ON CCP_IDPERSONA = PER_IDPERSONA  
 
	--						WHERE PER_IDPERSONA =  ' + CONVERT(NVARCHAR(20),@idCliente ) + '
	--						AND A.PAR_TIPOPARA = ''CARTERA''  
	--						AND A.PAR_IDMODULO = ''CXC''   
	--						AND A.par_importe5 <> 1   
	--						AND B.PAR_DESCRIP1 = ''FACTURA''  
	--						AND Car_Externa.ccp_cartera = '''+@cartera+'''  '
	--						--AND Car_Externa.ccp_cartera = '''+ @cartera +''' '


	--		PRINT(@consulta)
	--        INSERT INTO @montos
	--		EXECUTE(@consulta)

			

	
	--		SELECT id,serie,documento,cargo,abono,saldo,fecha,fechaV,estatus,pedido,diasV FROM @montos ORDER BY fecha ASC


END
go

