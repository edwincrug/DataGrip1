-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TOKEN_RECUPERA_PASS_SP]
	 @rfc NVARCHAR(30) = ''
	,@token NVARCHAR(300) = ''
AS
BEGIN

	DECLARE @encontro NVARCHAR(30) = ''
	SELECT @encontro = RFC FROM tokenRecuperaPass WHERE tokenRecupera = @token

	IF (@encontro <> '')
	BEGIN
		 SELECT success = 1
	END
	ELSE
	BEGIN
		 SELECT success = 0
	END
	 
END
go

