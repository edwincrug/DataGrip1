
-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 23-10-2019
-- Description:	Guarda un log de las partes pagas de una Factura.
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_Pago_Porcentaje] 
	  (  @factura nvarchar(50)
		,@saldoInicial numeric(18,2)
		,@porcentaje numeric(3,0)
		,@saldoFinal numeric(18,2)
		,@estatus bit =0
		)
AS
BEGIN

	BEGIN TRY  --Estar TryCatch
				INSERT INTO [dbo].[Pago_Porcentaje]
				           ([factura]
				           ,[saldoInicial]
				           ,[porcentaje]
				           ,[saldoFinal]
						   ,[estatus]
				           ,[fecharRegistro])
				     VALUES
				           (@factura
				           ,@saldoInicial
				           ,@porcentaje
				           ,@saldoFinal
						   ,@estatus
				           ,GETDATE())


	SELECT 1 AS resultado

	END TRY  
BEGIN CATCH  

		SELECT 0 AS resultado;  

END CATCH; --End TryCatch


END
go

