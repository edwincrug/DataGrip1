CREATE PROCEDURE [dbo].[UPD_USER_SP] --UPD_USER_SP @idCliente = 29, @valor = 'david.vazquez@coalmx.com', @tipo = 2
	@idCliente NUMERIC(18,0) = 0,
	@valor VARCHAR(50) = '',
	@tipo INT = 0, --1 : contaseña, 2 : correo, 3 : imagen
	@tipoCorreo INT = 0,
	@idCorreo INT = 0,
	@estatusCorreo INT = 0

AS

SET NOCOUNT ON	

BEGIN TRY

	DECLARE @estatus VARCHAR(10) = 'ok', @mensaje VARCHAR(100) = '', @rfc VARCHAR(13) = '', @msj VARCHAR(100) = ''

	IF(@tipo = 1) --contraseña
		BEGIN			

			DECLARE @cadena VARBINARY(200),  @cadenaEncrypt VARCHAR(200)   
			SELECT @cadena = EncryptByPassPhrase('4ndr4d3', @valor)  

			SET @cadenaEncrypt = (SELECT CONVERT(VARCHAR(300), @cadena, 1))

			UPDATE Usuario
			SET passwordU = @cadenaEncrypt
			WHERE idCliente = @idCliente

			SET @mensaje = 'Cambio de contraseña correcto.'
				
			INSERT INTO Log_Clientes  VALUES(5,@idCliente , GETDATE(), @mensaje )

			SELECT @rfc = rfcCliente FROM [dbo].[Cliente] WHERE idCliente = @idCliente
			UPDATE tokenRecuperaPass SET tokenRecupera = '' WHERE rfc = @rfc 

		END

	IF(@tipo = 2)  --correo
		BEGIN

			--UPDATE Cliente
			--SET correoTemporal = @valor
			--WHERE idCliente = @idCliente

			SELECT @rfc = rfcCliente FROM [dbo].[Cliente] WHERE idCliente = @idCliente

			DECLARE @tokenID uniqueidentifier
			SET @tokenID = NEWID()
					
			INSERT INTO [CorreoActivacion]([token],[per_rfc],[fechaCreacion],[fechaActivacion],[idEstatus])
			VALUES (@tokenID,@rfc,GETDATE(),NULL,1)

			--EXEC [SEL_ACTIVACION_CORREO_SP] @rfcCliente = @rfc,@correo = @valor,@token = @tokenID, @opcion = 2

			--SET @mensaje = 'Cambio de correo correcto. Se ha enviado un mail para activar el nuevo correo'


			IF (@idCorreo = 0)
			BEGIN
				INSERT INTO UsuarioCorreo VALUES (@idCliente, @valor, @tipoCorreo, 1,1 )
				SET @msj = 'Nuevo correo ' + @valor + ' de tipo ' + CONVERT(NVARCHAR(100), @tipoCorreo)
			END
			ELSE
			BEGIN
				UPDATE UsuarioCorreo set  correo = @valor , estatus = @estatusCorreo   where idUsuarioCorreo = @idCorreo
				SET @msj = 'Se modifico ' + @valor + ' , estatus ' + CONVERT(NVARCHAR(100),@estatus)
			END

			INSERT INTO Log_Clientes  VALUES(7,@idCliente , GETDATE(), @msj )
			SET @mensaje = 'Se guardo con exito.'

		END

	IF(@tipo = 3)  --imagen
		BEGIN
			
			UPDATE Cliente
			SET imagen = @valor
			WHERE idCliente = @idCliente

			SET @mensaje = 'Cambio de imagen correcto.......'
		
		END	

		IF(@tipo = 4)  --imagen
		BEGIN
			
			UPDATE UsuarioCorreo
			SET recibeNot = @valor
			WHERE idCliente = @idCliente
			AND idTipoCorreo = 1

			SET @mensaje = 'Cambio Guardado'
		
		END	

	SELECT @estatus estatus, @mensaje mensaje
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Componente nvarchar(50) = '[UPD_USER_SP]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,'Error al Editar usuario, intente de nuevo.' mensaje--@msg

END CATCH



go

