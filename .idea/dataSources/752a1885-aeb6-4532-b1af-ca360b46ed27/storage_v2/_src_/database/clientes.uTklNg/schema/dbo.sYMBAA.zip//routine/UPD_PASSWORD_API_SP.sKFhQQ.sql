-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST UPD_PASSWORD_API_SP 105891, '1234567'
-- =============================================
CREATE PROCEDURE [dbo].[UPD_PASSWORD_API_SP]
	@idPerPersona INT,
	@password VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;

    BEGIN TRY
		DECLARE @cadena VARBINARY(200),  @cadenaEncrypt VARCHAR(200), @idCliente INT, @rfc VARCHAR(100);  
		SELECT @cadena = EncryptByPassPhrase('4ndr4d3', @password)  

		SET @cadenaEncrypt = (SELECT CONVERT(VARCHAR(300), @cadena, 1))

		SELECT 
			@idCliente = idCliente 
		FROM Cliente 
		WHERE per_idpersona = @idPerPersona

		IF( @idCliente > 0 )
			BEGIN
				UPDATE Usuario SET passwordU = @cadenaEncrypt WHERE idCliente = @idCliente;
				
				INSERT INTO Log_Clientes  VALUES(5,@idCliente , GETDATE(), 'Cambio de contrseña por API' )

				SELECT @rfc = rfcCliente FROM [dbo].[Cliente] WHERE idCliente = @idCliente;

				UPDATE tokenRecuperaPass SET tokenRecupera = '' WHERE rfc = @rfc 

				SELECT success = 1, msg = 'Se cambio la contraseña con éxito'
			END
		ELSE
			BEGIN
				SELECT success = 0, msg = 'No existe cliente con ese ID'
			END
	END TRY

	BEGIN CATCH
		SELECT success = 0, msg = ERROR_MESSAGE();
	END CATCH
END
go

