CREATE PROCEDURE [dbo].[INS_USER_SP]
@nombre VARCHAR(50) = '',
@aPaterno VARCHAR(30) = '',
@aMaterno VARCHAR(30) = '',
@rfc VARCHAR(50),
@correoUsuario VARCHAR(150),
@contrasena VARCHAR(50)

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
	
	DECLARE @per_idpersona SMALLINT
	DECLARE @msg VARCHAR(500) = '', @estatus VARCHAR(10) = ''

	IF EXISTS(SELECT per_rfc FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @rfc)
		BEGIN
			IF NOT EXISTS(SELECT * FROM Cliente WHERE rfcCliente = @rfc)
				BEGIN
						
						INSERT INTO Cliente (idTipoCliente,nombreCliente,apellidoPaterno,
											 apellidoMaterno,fechaAlta,idEstatus,
											 rfcCliente,correo)
									  VALUES(1,@nombre,@aPaterno,
										     @aMaterno,GETDATE(),2,
											 @rfc,@correoUsuario)

						DECLARE @idCliente NUMERIC(18,0) = @@IDENTITY

						INSERT INTO Usuario (passwordU,idTipoUsuario,idCliente)
									  VALUES(@contrasena,1,@idCliente)

						DECLARE @tokenID uniqueidentifier
						SET @tokenID = NEWID()
					
						INSERT INTO [clientes].[dbo].[CorreoActivacion]([token],[per_rfc],[fechaCreacion],[fechaActivacion],[idEstatus])
						VALUES (@tokenID,@rfc,GETDATE(),NULL,1)

						EXEC [clientes].[dbo].[SEL_ACTIVACION_CORREO_SP] @rfcCliente = @rfc,@correo = @correoUsuario,@token = @tokenID, @opcion = 1														

						SELECT @estatus = 'ok', @msg ='Cliente con RFC: ' + @rfc + ' registrado con exito! Se ha enviado un correo para su activación a la dirección ' + @correoUsuario + '.'
				END
			ELSE
				BEGIN
						SELECT @estatus = 'error', @msg ='Cliente con RFC: ' + @rfc + ' ya existe. No se registro.'
				END
		END
	ELSE
		BEGIN
			SELECT @estatus = 'error', @msg ='Cliente con RFC: ' + @rfc + ' no existe en el catalogo de proveedores. No se registro.'
		END	

		SELECT @estatus estatus,@msg mensaje
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[INS_USER_SP]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje--@msg

END CATCH
END
go

