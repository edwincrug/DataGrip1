



-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 21-09-2020
-- Description:	Obtiene toda la informacion de la Transaccion
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_TransaccionPagosEmailFlap]
(
	@idTrans numeric(18,0)
)
AS
BEGIN

BEGIN TRY  --Star TryCatch
		  

SELECT TOP (1) [idTrans] AS 'IdTrans'
      ,[idEmpresa] AS 'IdEmpresa'
      ,[idSucursal] AS 'IdSucursal'
      ,[idDepartamento] AS 'IdDepartamento'
      ,[idTipoDocumento] AS 'IdTipoDocumento'
      ,[importeDocumento] AS 'ImporteDocumento'
      ,[serie] AS 'Serie'
      ,[folio] AS 'Folio'
      ,[idCliente] AS 'IdCliente'
      ,[idAlmacen] AS 'IdAlmacen'
      ,[idTipoReferencia] AS 'IdTipoReferencia'
      ,[idEstatus] AS 'IdEstatus'
      ,[idOrigen] AS 'IdOrigen'
      ,[idEmisor] AS 'IdEmisor'
      ,[fechaRegistro] AS 'Fecha'
  FROM [referencias].[dbo].[Transaccion]

  WHERE idTrans=@idTrans;
		  
			  --  SELECT 
				 --  P.idPago AS 'IdPago'
				 -- ,P.idTrans AS 'IdTransaccion'
			  --    ,P.referencia As 'Referencia'
			  --    ,C.mp_node AS 'Sucursal'
			  --    ,P.idConcepto AS 'IdConcepto'
			  --    ,P.moneda AS 'Moneda'
			  --    ,P.importe AS 'Importe'
			  --    ,P.idComercio AS 'IdComercio'
			  --    ,P.accion AS 'Accion'
				 -- ,@autorizacion AS 'Autorizacion'
			  --FROM [referencias].[dbo].[Pago] AS P
			  --INNER JOIN [referencias].[dbo].[Cat_DivisionOrg_BBVA] AS C ON C.idSucursal=P.nodo		
			  --WHERE P.idOrigen=1 and P.idTrans=@idTrans;

END TRY  
BEGIN CATCH  
	--Log Error
				INSERT INTO [referencias].[dbo].[LogError]
				SELECT  ERROR_PROCEDURE() AS Servicio
				   ,'[dbo].[Pago]' AS Metodo
				   ,'Error al ejecutar linea:'+ CAST(ERROR_LINE() AS VARCHAR(10)) AS Error_Descripcion
				   ,ERROR_MESSAGE() AS Error_Pila
				   ,GETDATE() AS FechaRegistro  

END CATCH; --End TryCatch



	

END
go

