-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [dbo].[INS_TRAMITE_SP]   0 ,'Gewrente',2,188,4,6,'Z7',' CLIENTES HOJ Y PINT (RECONST)',45000,3
CREATE PROCEDURE [dbo].[INS_TRAMITE_SP]  
	 @idCliente INT = 0
	,@observacion NVARCHAR(300)
	,@estatus INT = 0
	,@tramites_Id INT = 0
	,@idEmpresa  INT = 0
	,@idSucursal INT = 0
	--,@idDepartamento INT = 0
	,@cartera  NVARCHAR(10)
	,@depDescripcion  NVARCHAR(200)
	,@monto NUMERIC(18,2)
	,@id_tramiteAsolicitar INT = 0
	,@id_SolicitudMonto INT = NULL
AS
BEGIN
		DECLARE @idDep INT = 0
		
		IF NOT EXISTS(SELECT id FROM TramiteCliente	WHERE tramites_Id = @tramites_Id)
		BEGIN
			IF(@id_tramiteAsolicitar = 8)
			BEGIN
				SET @estatus = 3
				INSERT INTO docCycTramite
				SELECT id,'', @tramites_Id FROM cat_documentaCyC
			END

			SELECT @idDep = idDepartamento
			FROM [clientes].[dbo].[CatalogoDepartamento] WHERE claveCartera = @cartera
			AND idEmpresa = @idEmpresa
			AND idSucursal = @idSucursal

			INSERT INTO TramiteCliente VALUES (@idCliente ,@observacion ,GETDATE() ,@estatus ,@tramites_Id ,@idEmpresa , @idSucursal ,@idDep , @monto,@cartera,@depDescripcion,@id_tramiteAsolicitar)

			UPDATE [clientes].[dbo].[SolicitudMonto] SET tramites_Id = @tramites_Id
			WHERE id = @id_SolicitudMonto



			IF (@estatus > 0)
			BEGIN 
				INSERT INTO [clientes].[dbo].[ProcesoTramite] VALUES (@tramites_Id ,0,GETDATE(),GETDATE())
			END
		
			INSERT INTO [clientes].[dbo].[ProcesoTramite] VALUES (@tramites_Id ,@estatus,GETDATE(),NULL)


		END
		ELSE
		BEGIN

			DECLARE @estatusActual INT = 0
			SELECT @estatusActual = estatus FROM TramiteCliente	WHERE tramites_Id = @tramites_Id
			IF (@estatusActual <> 8)
			BEGIN
				IF(@estatus = 3)
				BEGIN
					INSERT INTO docCycTramite
					SELECT id,'', @tramites_Id FROM cat_documentaCyC
				END
			END

			

			SELECT @id_tramiteAsolicitar = id_tramiteAsolicitar FROM TramiteCliente	WHERE tramites_Id = @tramites_Id

			IF (@id_tramiteAsolicitar <> 8)
			BEGIN


					IF (@estatusActual <> 8)
					BEGIN


						IF(@estatus = 4 OR @estatus = 5)
						BEGIN
							UPDATE [clientes].[dbo].[ProcesoTramite] 
							SET hrFin = GETDATE() 
							WHERE id_perTra = @tramites_Id AND estatus = 3 
							AND id IN ( SELECT id FROM [clientes].[dbo].[ProcesoTramite] WHERE id_perTra = @tramites_Id AND estatus = 3 AND hrFin IS NULL )


						END
						ELSE
						BEGIN
							UPDATE [clientes].[dbo].[ProcesoTramite] SET hrFin = GETDATE() WHERE id_perTra = @tramites_Id AND estatus = @estatus - 1
							--INSERT INTO [clientes].[dbo].[ProcesoTramite] VALUES (@tramites_Id ,@estatus,GETDATE(),NULL)
						END

						INSERT INTO [clientes].[dbo].[ProcesoTramite] VALUES (@tramites_Id ,@estatus,GETDATE(),NULL)
				
					END
					ELSE
					BEGIN

						-- APAGO CYC ANTERIOR
						UPDATE [clientes].[dbo].[ProcesoTramite] 
						SET hrFin = GETDATE() 
						WHERE id_perTra = @tramites_Id AND estatus = 3 
						AND id IN ( SELECT id FROM [clientes].[dbo].[ProcesoTramite] WHERE id_perTra = @tramites_Id AND estatus = 3 AND hrFin IS NULL )

						IF (@estatus = 3)
						BEGIN		
						
							-- APAGO DOC SUBIDOS
							UPDATE [clientes].[dbo].[ProcesoTramite] 
							SET hrFin = GETDATE() 
							WHERE id_perTra = @tramites_Id AND estatus = 8 
							AND id IN ( SELECT id FROM [clientes].[dbo].[ProcesoTramite] WHERE id_perTra = @tramites_Id AND estatus = 8 AND hrFin IS NULL )
							
							-- INSERTO CYC NUEVO			
							INSERT INTO [clientes].[dbo].[ProcesoTramite] VALUES (@tramites_Id ,@estatus,GETDATE(),NULL)
						END
					END
					
			END
			ELSE
			BEGIN 

					IF(@estatus = 3)
					BEGIN
						UPDATE [clientes].[dbo].[ProcesoTramite] SET hrFin = GETDATE() WHERE id_perTra = @tramites_Id AND estatus = 3
						INSERT INTO [clientes].[dbo].[ProcesoTramite] VALUES (@tramites_Id ,7,GETDATE(),GETDATE())
					END

			END

			

			UPDATE TramiteCliente 
			SET observacion = @observacion, estatus = @estatus, fecha = GETDATE()
			WHERE tramites_Id = @tramites_Id
			

		END

				 
		DECLARE @link NVARCHAR(300) ,@imgGA NVARCHAR(MAX)


		SELECT @link = valor FROM [clientes].[dbo].[Parametros] WHERE nombre = 'url_panel'
		SELECT @imgGA = valor FROM [clientes].[dbo].[Parametros] WHERE nombre = 'img_GA'

		SELECT
				 Us.[usu_correo] + ';samuel.valdes@grupoandrade.com;david.vazquezr@outlook.com' as correoGa
				,U.[usu_correo] + ';samuel.valdes@grupoandrade.com;david.vazquezr@outlook.com' as correoCyc
				,@imgGA AS imgGA
				,@link AS link

		FROM [clientes].[dbo].[Cat_GerenteAreaAgencia] GAA
		INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] Us ON Us.usu_idusuario = GAA.idUsuario
		INNER JOIN  [clientes].[dbo].[Cat_CycRevisor] CYC ON  GAA.idEmpresa = CYC.idEmpresa AND  GAA.idSucursal = CYC.idSucursal
		INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = CYC.idUsuario		

		WHERE GAA.idEmpresa = @idEmpresa
		AND GAA.idSucursal = @idSucursal
		AND GAA.idDepartamento = @idDep
		
END

go

