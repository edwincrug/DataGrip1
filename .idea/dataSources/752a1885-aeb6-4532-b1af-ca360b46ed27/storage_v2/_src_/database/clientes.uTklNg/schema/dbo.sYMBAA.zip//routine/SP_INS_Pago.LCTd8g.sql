-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_Pago] 
	    @idOrigen int = 0
		,@idTrans numeric(18,0) = 0
		,@idCliente numeric(18,0)  = 0
		,@referencia varchar(100) =''
		,@nodo numeric(18,0)  = 0
		,@idConcepto varchar(100)  =''
		,@moneda int = 0
		,@importe decimal(18,2) = 0
		,@hmac nvarchar(300)=''
		,@Id numeric(18,0) OUTPUT
		,@payMethodtype int = 0
		,@mp_paymentmethod  varchar(100) =''
AS
BEGIN
	
	EXEC [referencias].[dbo].[SP_INS_Pago] 
												@idOrigen  = @idOrigen
												,@idTrans  = @idTrans
												,@idCliente   = @idCliente
												,@referencia  = @referencia
												,@nodo   =  @nodo
												,@idConcepto   = @idConcepto
												,@moneda  =  @moneda
												,@importe  = @importe
												,@hmac = @hmac
												,@Id = @Id 
												,@payMethodtype = @payMethodtype
												,@mp_paymentmethod = @mp_paymentmethod


	SELECT 1 AS resultado


END
go

