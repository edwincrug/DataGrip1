-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 27/09/2016       14hrs
-- Description:	Detalle de Documentos Pagados
-- 1.-Pago Puntual
-- 2.-Pago Inpuntual
-- ==========================================================================================
-- EXECUTE [SEL_TOTAL_DOC_PAG_DETALLE_SP_TODAS_2] 108, 4 , 0 ,'01/01/2019','01/07/2019'
CREATE PROCEDURE [dbo].[SEL_TOTAL_DOC_PAG_DETALLE_SP_TODAS_2] 
     @idCliente NUMERIC(18,0) = 0
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
	,@fechaInicial VARCHAR(10) = ''
	,@fechafin VARCHAR(10) = ''	
AS
BEGIN
	SET NOCOUNT ON;
	--@rfc de prueba MAPI731031HT4
	DECLARE @rfc VARCHAR(15) = ''
	SELECT @rfc = rfcCliente FROM Cliente WHERE idCliente = @idCliente

	IF @idSucursal = 0 
		SET @idSucursal = null

	DECLARE @documentosPagados TABLE  (ID INT IDENTITY(1,1),idCliente int,complemento int,rfcReceptor varchar(20),rfcEmisor varchar(50),serie varchar(150),folio varchar(150),idEmpresa int ,empresa nvarchar(150),idSucursal	int  ,sucursal nvarchar(150),idDepartamento int,departamento nvarchar(100),cartera nvarchar(10),idDocto  nvarchar(20),tipoDocto nvarchar(20),fechaVencimiento nvarchar(20),fechaUltimoPago  nvarchar(20),cargo numeric(18,5),abono numeric(18,5),saldo numeric(18,5) ,tipoPagoFecha   int,diasVencidos    int,formaPago nvarchar(100),fechaFormaPago nvarchar(20))

	DECLARE @aux               INT = 1
	DECLARE @max               INT = 0
	DECLARE @auxDos            INT = 1
	DECLARE @maxSuc            INT = 0
	DECLARE @idEmpresaBusca    INT = 0
	DECLARE @ipServidorConcentradoras NVARCHAR(50) =NULL
	DECLARE @nombreBase		   NVARCHAR(100) =NULL
	DECLARE @nomBaseMatriz     NVARCHAR(100) =NULL
	DECLARE @nomBaseConcentra  NVARCHAR(100) =NULL	
	DECLARE @rfcEmisor		   NVARCHAR(50) =NULL
	DECLARE @consulta   VARCHAR(max)=NULL;
	DECLARE @consultaDos   VARCHAR(max)=NULL;
	DECLARE @where      VARCHAR(max)=NULL;
	DECLARE @nom_suc NVARCHAR(200) = ''
	DECLARE @emp_nombre NVARCHAR(200) = ''
   
		SELECT @nomBaseConcentra = BASEMP.nombre_base
		FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
		WHERE emp.emp_idempresa = @idEmpresa
			  AND BASEMP.tipo = 2
		ORDER BY EMP.emp_idempresa

		SELECT	@rfcEmisor = rfc	
		FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP where tipo = 2 
				AND ISNULL(rfc,'') != '' AND emp_idempresa = @idEmpresa
	
		DECLARE @BDsuc TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(50), NombreBase VARCHAR(50),suc_idsucursal INT,suc_nombre VARCHAR(50))

		INSERT INTO @BDsuc
		SELECT EMP.emp_idempresa ,EMP.emp_nombre ,BASEMP.nombre_base ,BASEMP.suc_idsucursal ,sucursales.suc_nombre
		FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
		INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
		WHERE BASEMP.emp_idempresa = @idEmpresa
			  AND BASEMP.suc_idsucursal = COALESCE(@idSucursal, BASEMP.suc_idsucursal)  
			  AND BASEMP.tipo = 1

	SET @maxSuc = (SELECT MAX(IDBD) FROM @BDsuc)

	WHILE(@aux <= @maxSuc)
	BEGIN
			
			SELECT	@nombreBase = NombreBase, @nom_suc = suc_nombre,@emp_nombre = emp_nombre,@idSucursal = suc_idsucursal
					FROM @BDsuc WHERE IDBD = @aux
					
			SET @consulta =  'SELECT [CCP_IDPERSONA]' +
			                        ',Car_Externa.ccp_refer ' +
									 ','''+ @rfc + '''' +
									 ','''+ @rfcEmisor + '''' +
									 ', (select [referencias].[dbo].[fn_BuscaLetras](CCP_IDDOCTO)), (select [referencias].[dbo].[fn_BuscaNumeros](CCP_IDDOCTO))' +
									 ',' + CAST (@idEmpresa AS VARCHAR(2)) +' AS idEmpresa '
							
						   
			SET @consultaDos =      ','''+ @emp_nombre +  ''' AS empresa ' +
									',' + CAST (@idSucursal AS VARCHAR(2)) +' AS idSucursal' +
									',''' + @nom_suc + '''   AS sucursal  ' +
									',SUBSTRING(A.PAR_HORA1,4,2) AS idDepartamento  ' +
									',(SELECT [dep_nombre] FROM [ControlAplicaciones].[dbo].[cat_departamentos] WHERE [dep_iddepartamento] = SUBSTRING(A.PAR_HORA1,4,2))  AS departamento   ' +
									',ccp_cartera AS cartera ' +
									',CCP_IDDOCTO AS idDocto ' +
									',B.PAR_DESCRIP1 AS tipoDocto ' +
									',CONVERT(DATE, CCP_FECHVEN, 103) AS fechaVencimiento  ' +
									',CCP_FECHADOCTO  AS fechaUltimoPago   ' +
									',CCP_CARGO AS cargo ' +
									',(select isnull(sum(ccp_abono),0)  ' +
												'   from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' +
												'  where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  ' +
												'	and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  ' +
												'	and movimiento.ccp_cartera   = Car_Externa.ccp_cartera  ' +
												'	and movimiento.ccp_docori <> '+''''+'s'+''''+'     ' +
												'	and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+')    AS abono ' +
									',CCP_CARGO - (select isnull(sum(ccp_abono),0)    ' +
									'			   from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' + 
									'			  where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  ' +
									'				and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  ' +
									'				and movimiento.ccp_cartera   = Car_Externa.ccp_cartera  ' +
									'				and movimiento.ccp_docori <> '+''''+'s'+''''+'    ' +
									'				and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+') AS saldo  ' +
									',CASE WHEN (SELECT DATEDIFF(day,(select top 1 CONVERT(DATE,movimiento.CCP_FECHADOCTO, 103)    ' +
																	'	  from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento   ' + 
																	'	 where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto   ' +
																'	   and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona   ' +
																'	   and movimiento.ccp_cartera   = Car_Externa.ccp_cartera   ' +
																'	   and movimiento.ccp_docori <> '+''''+'s'+''''+
																'	   and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+
																'	   and movimiento.CCP_ABONO > 0   ' +
																'	 order by CCP_FECHADOCTO asc   ' +
																'		),CONVERT(DATE,Car_Externa.CCP_FECHVEN, 103))) >= 0  THEN  1   ' +   
										'  WHEN  (SELECT DATEDIFF(day,(select top 1 CONVERT(DATE,movimiento.CCP_FECHADOCTO, 103) 
																		from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento 
																		where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto 
																		and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona 
																		and movimiento.ccp_cartera   = Car_Externa.ccp_cartera 
																		and movimiento.ccp_docori <> '+''''+'s'+''''+' 
																		and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+'
																		and movimiento.CCP_ABONO > 0
																		order by CCP_FECHADOCTO asc
																		),CONVERT(DATE,Car_Externa.CCP_FECHVEN, 103) )) < 0  THEN  2 
											ELSE 3											
										END  AS tipoPagoFecha  
										,''diasVencidos'' = CASE WHEN isdate(CCP_FECHVEN) = 1 
																			then DATEDIFF(DAY,CONVERT(DATETIME,CCP_FECHVEN,103),GETDATE()) 
																		else 0 
																		end
										,PN.PAR_DESCRIP3,vt.VTE_FECHOPE '
	
			   SET @where='	FROM['+ @nomBaseConcentra +'].[dbo].[VIS_CONCAR01]  AS Car_Externa 
							INNER JOIN ['+ @nomBaseConcentra +'].[dbo].[PNC_PARAMETR] As A ON CCP_CARTERA = A.PAR_IDENPARA 
							LEFT OUTER JOIN ['+ @nomBaseConcentra +'].[dbo].[PNC_PARAMETR] As B ON CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = ''TIMO''
							INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] ON CCP_IDPERSONA = PER_IDPERSONA AND  PER_RFC = '''+ @rfc+' ''
							LEFT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] Z ON Car_Externa.ccp_iddocto = Z.oce_folioorden COLLATE Modern_Spanish_CI_AS  
							INNER JOIN ['+ @nombreBase +'].[dbo].[ADE_VTAFI] vt on  vt.VTE_DOCTO = CCP_IDDOCTO
							INNER JOIN ['+ @nombreBase +'].[dbo].PNC_PARAMETR PN ON PN.PAR_IDENPARA = vt.VTE_FORMAPAGO AND PN.PAR_TIPOPARA = ''VNT'' 
							WHERE   A.PAR_TIPOPARA = ''CARTERA''  
									AND A.PAR_IDMODULO = ''CXC''   
									AND a.par_importe5 <> 1   
									AND B.PAR_DESCRIP1 = ''FACTURA''
									AND DATEDIFF (DAY,CONVERT(DATE, CCP_FECHVEN, 103),GETDATE()) >= 0'+
									' AND'+
									' CONVERT(DATE,CCP_FECHADOCTO,103) ' +
									' BETWEEN CONVERT(DATE,'
									+char(39)+@fechaInicial+char(39)+',103) AND CONVERT(DATE,'+char(39)+@fechaFin+char(39)+
									',103) AND SUBSTRING(CCP_IDDOCTO,1,2) IN(SELECT SUBSTRING(FCF_SERIE,1,2) FROM ['+ @nombreBase +'].[dbo].ADE_CFDFOLIOS)' 
		
		print @consulta + @consultaDos + @where


		INSERT INTO  @documentosPagados
		    EXECUTE (@consulta+@consultaDos + @where);
		

			SET @aux = @aux + 1
		END
		
		SELECT 
				 ID 
				 ,complemento as com
				,idCliente 
				,rfcReceptor
				,rfcEmisor
				,serie 
				,folio
				,idEmpresa 
				,empresa
				,idSucursal
				,sucursal
				,idDepartamento 
				,departamento 
				,cartera 
				,idDocto
				,tipoDocto
				,fechaVencimiento
				,fechaUltimoPago  
				,cargo
				,abono 
				,saldo
				,tipoPagoFecha 
				,diasVencidos
				,formaPago 
				,fechaFormaPago 
				,'MAA000005726' AS complemento
		FROM @documentosPagados ORDER BY fechaVencimiento ASC
END

go

