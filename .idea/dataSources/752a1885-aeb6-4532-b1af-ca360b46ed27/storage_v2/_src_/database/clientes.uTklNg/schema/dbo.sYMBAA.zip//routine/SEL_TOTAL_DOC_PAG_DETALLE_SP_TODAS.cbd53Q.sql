-- ==========================================================================================
-- Author:		Lourdes Maldonado Sánchez
-- Create date: 27/09/2016       14hrs
-- Description:	Detalle de Documentos Pagados
-- 1.-Pago Puntual
-- 2.-Pago Inpuntual
-- ==========================================================================================
--EXECUTE [SEL_TOTAL_DOC_PAG_DETALLE_SP_TODAS] 18,0,0
CREATE PROCEDURE [dbo].[SEL_TOTAL_DOC_PAG_DETALLE_SP_TODAS] 
     @idCliente NUMERIC(18,0) = 0
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
	--,@fechaInicial VARCHAR(10) = ''
	--,@fechafin VARCHAR(10) = ''	
AS
BEGIN
	SET NOCOUNT ON;
	--=======================================================================================-- 
    --  Documentos Pagados 
	--  1.Fecha Pagado antes o en la FechaVencimiento 
	--  2.Fecha Pagado despues FechaVencimiento  
	--  3.No tiene Fecha de Vencimiento
	--=======================================================================================-- 
	declare @fechaInicio varchar(20);
	declare @fechaFin varchar(20);
	set @fechaInicio=(select convert(varchar(12), DATEADD(month, -2, getdate()), 103))
	set @fechaFin=convert(varchar(12), getdate(), 103)
	--print @fechaInicio+ 'hola'+@fechaFin

	-----------BEGIN Dependiendo del idCliente busca su rfc------------------------------------
	DECLARE @rfc VARCHAR(15) = 'MAPI731031HT4'
	--SELECT @rfc = rfcCliente FROM Cliente WHERE idCliente = @idCliente
	-----------END Dependiendo del idCliente busca su rfc--------------------------------------
	-----------BEGIN Variable tabla para guardar el resultado----------------------------------
	DECLARE @documentosPagados TABLE  (ID INT IDENTITY(1,1)
										,idCliente		 int
										,rfcReceptor	 varchar(20)
										,rfcEmisor		 varchar(50)
										,serie			 varchar(150)
										,folio			 varchar(150)
										,idEmpresa       int 
										,empresa	     nvarchar(150)
										,idSucursal	     int  --Cadena
										,sucursal        nvarchar(150)
										,idDepartamento  int
										,departamento    nvarchar(100)
										,cartera         nvarchar(10)
										,idDocto         nvarchar(20)
										,tipoDocto       nvarchar(20)
										,fechaVencimiento nvarchar(20)
										,fechaUltimoPago  nvarchar(20)
										,cargo           numeric(18,5)
										,abono           numeric(18,5)
										,saldo           numeric(18,5) 
										,tipoPagoFecha   int
										,diasVencidos    int
										)
	-----------END Variable tabla para guardar el resultado------------------------------------
	-----------BEGIN Se crea tabla para guarda las concentradoras------------------------------
	DECLARE @aux               INT = 1
	DECLARE @max               INT = 0
	DECLARE @auxDos            INT = 1
	DECLARE @maxDos            INT = 0
	DECLARE @idEmpresaBusca    INT = 0
	DECLARE @ipServidorConcentradoras NVARCHAR(50) =NULL
	DECLARE @nombreBase		   NVARCHAR(50) =NULL
	DECLARE @nomBaseMatriz     NVARCHAR(50) =NULL
	DECLARE @nomBaseConcentra  NVARCHAR(50) =NULL	
	DECLARE @rfcEmisor		   NVARCHAR(50) =NULL
	DECLARE @consulta   VARCHAR(max)=NULL;
	DECLARE @consultaDos   VARCHAR(max)=NULL;
	DECLARE @where      VARCHAR(max)=NULL;
    DECLARE @Bases TABLE  ( IDB INT IDENTITY(1,1),
	                        idEmpresa         int
							,nombreEmpresa     nvarchar(100)
							,nomCtoEmpresa     nvarchar(5)
							,nomBaseConcentra  nvarchar(50)
							,nomBaseMatriz     nvarchar(50)
							,ipServidor        nvarchar(20)
							)

	 INSERT INTO @Bases
		  SELECT EMP.emp_idempresa
		    	,EMP.emp_nombre
				,EMP.emp_nombrecto
				,BASEMP.nombre_base
				,ISNULL(BASEMP.nombre_base_matriz,BASEMP.nombre_base)
				,BASEMP.ip_servidor 
		   FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
			    INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				                                                        and emp.emp_idempresa in (4)
		  WHERE [catsuc_nombrecto] ='CONCENTRA' 
		    AND BASEMP.tipo = 2
			AND BASEMP.estatus = 1 --Activo para Pruebas
	   ORDER BY EMP.emp_idempresa
-----------END Se crea tabla para guarda las concentradoras------------------------------

	 SET @max = (SELECT MAX(IDB) FROM @Bases)

	 WHILE(@aux <= @max)
	 BEGIN         
		 SELECT  @idEmpresaBusca   = DB.idEmpresa 
				,@nomBaseConcentra = DB.nomBaseConcentra
				,@nomBaseMatriz    = DB.nomBaseMatriz
				,@ipServidorConcentradoras	   = DB.ipServidor
		   FROM @Bases AS DB 
		  WHERE DB.IDB = @aux --DB.idEmpresa = @aux 

	-----------BEGIN Se busca el rfc del Emisor es decir de la empresa-----------------------
		SELECT	 @rfcEmisor= rfc	
				FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP where tipo=2 
				AND ISNULL(rfc,'') != '' AND emp_idempresa=@idEmpresaBusca

				--print @rfcEmisor
    -----------END Se busca el rfc del Emisor es decir de la empresa-------------------------
	-----------BEGIN Se crea tabla para guardar las Bases de datos-----------------------------
		DECLARE @ipServidorSucursales NVARCHAR(30)
		DECLARE @BDs TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(50),
							emp_nombrecto VARCHAR(10), NombreBase VARCHAR(50),suc_idsucursal INT,suc_nombre VARCHAR(50),ipServidor VARCHAR(50))
		INSERT INTO @BDs
		SELECT 
					 EMP.emp_idempresa
					,EMP.emp_nombre
					,EMP.emp_nombrecto
					,BASEMP.nombre_base
					,BASEMP.suc_idsucursal
					,sucursales.suc_nombre
					,BASEMP.ip_servidor
				FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
					INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
					inner join [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
				WHERE  BASEMP.estatus = 1 AND BASEMP.tipo = 1 and sucursales.emp_idempresa= EMP.emp_idempresa AND BASEMP.nombre_sucursal != 'CRA Guadalajara' AND BASEMP.nombre_sucursal !='CRA Cuautitlan' AND EMP.emp_idempresa=4
			ORDER BY sucursales.suc_idsucursal

	--select * from @BDs
	-----------END Se crea tabla para guardar las Bases de datos-----------------------------
	--///////////////////////////////////////////////////////////////////////////////////////
	SET @maxDos = (SELECT MAX(IDBD) FROM @BDs)

	WHILE(@auxDos <= @maxDos)
		BEGIN
			-----------BEGIN Obtengo el nombre de las sucursales ----------------------------------
			SELECT	@nombreBase = NombreBase
					,@ipServidorSucursales= ipServidor
					FROM @BDs WHERE IDBD = @auxDos
			---------END Obtengo el nombre de las sucursales ------------------------------------
			--SELECT * FROM @documentosPagados WHERE serie  IN(SELECT SUBSTRING(FCF_SERIE,1,2) FROM [GAAU_Universidad]..ADE_CFDFOLIOS)
			print @nombreBase
			SET @consulta = 'SELECT [CCP_IDPERSONA],'+
							+char(39)+@rfc+char(39)+
							','+char(39)+@rfcEmisor+char(39)+
							', (select [referencias].[dbo].[fn_BuscaLetras](CCP_IDDOCTO)), (select [referencias].[dbo].[fn_BuscaNumeros](CCP_IDDOCTO)),'
							+ cast (@idEmpresaBusca as varchar(2)) +' AS idEmpresa '
							
						   
	SET @consultaDos=',(SELECT [emp_nombre]   '+
					'    FROM [ControlAplicaciones].[dbo].[cat_empresas]' +
					'   WHERE [emp_idempresa] = '+ cast (@idEmpresaBusca as varchar(2)) +')      AS empresa ' +
					',A.PAR_DESCRIP2                              AS idSucursal' +
					',(SELECT B.nombre_sucursal  ' +
					'   FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] AS B ' +
					'  WHERE B.catemp_nombrecto = (SELECT [emp_nombrecto]  empNombreCto ' + 
     				'								FROM [ControlAplicaciones].[dbo].[cat_empresas] ' +
					'							   WHERE [emp_idempresa] = '+ cast (@idEmpresaBusca as varchar(2)) +')
						AND B.num_base_BI = A.PAR_DESCRIP2 COLLATE Modern_Spanish_CI_AS
						AND B.num_base_BI IS NOT NULL
						)                                       AS sucursal  ' +
					',SUBSTRING(A.PAR_HORA1,4,2)                  AS idDepartamento  ' +
					',(SELECT [dep_nombre]    ' +
					'   FROM [ControlAplicaciones].[dbo].[cat_departamentos]    ' +
						' WHERE [dep_iddepartamento] = SUBSTRING(A.PAR_HORA1,4,2))  AS departamento   ' +
					--',(SELECT [dep_nombre]    ' +
					--'   FROM [ControlAplicaciones].[dbo].[cat_departamentos]    ' +
					-- ' WHERE [dep_iddepartamento] = SUBSTRING(A.PAR_HORA1,4,2))  AS departamento   ' +
					',ccp_cartera                                 AS cartera   ' +
					',CCP_IDDOCTO                                 AS idDocto    ' +
					',B.PAR_DESCRIP1                              AS tipoDocto    ' +
					',CONVERT(DATE, CCP_FECHVEN, 103)                                 AS fechaVencimiento  ' +
					',CCP_FECHADOCTO  ' +
						'   AS fechaUltimoPago   ' +
					',CCP_CARGO          AS cargo   ' +
					',(select isnull(sum(ccp_abono),0)  ' +
								'   from ['+@ipServidorConcentradoras+'].['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' +
								'  where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  ' +
								'	and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  ' +
								'	and movimiento.ccp_cartera   = Car_Externa.ccp_cartera  ' +
								'	and movimiento.ccp_docori <> '+''''+'s'+''''+'     ' +
								'	and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+')      AS abono ' +
					',CCP_CARGO - (select isnull(sum(ccp_abono),0)    ' +
					'			   from ['+@ipServidorConcentradoras+'].['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' + 
					'			  where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  ' +
					'				and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  ' +
					'				and movimiento.ccp_cartera   = Car_Externa.ccp_cartera  ' +
					'				and movimiento.ccp_docori <> '+''''+'s'+''''+'    ' +
					'				and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+')      AS saldo  ' +
					',CASE WHEN (SELECT DATEDIFF(day,(select top 1 CONVERT(DATE,movimiento.CCP_FECHADOCTO, 103)    ' +
													'	  from ['+@ipServidorConcentradoras+'].['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento   ' + 
													'	 where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto   ' +
												'	   and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona   ' +
												'	   and movimiento.ccp_cartera   = Car_Externa.ccp_cartera   ' +
												'	   and movimiento.ccp_docori <> '+''''+'s'+''''+
												'	   and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+
												'	   and movimiento.CCP_ABONO > 0   ' +
												'	 order by CCP_FECHADOCTO asc   ' +
												'		),CONVERT(DATE,Car_Externa.CCP_FECHVEN, 103))) >= 0  THEN  1   ' +   
						'  WHEN  (SELECT DATEDIFF(day,(select top 1 CONVERT(DATE,movimiento.CCP_FECHADOCTO, 103) 
														from ['+@ipServidorConcentradoras+'].['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento 
														where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto 
														and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona 
														and movimiento.ccp_cartera   = Car_Externa.ccp_cartera 
														and movimiento.ccp_docori <> '+''''+'s'+''''+' 
														and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+'
														and movimiento.CCP_ABONO > 0
														order by CCP_FECHADOCTO asc
														),CONVERT(DATE,Car_Externa.CCP_FECHVEN, 103) )) < 0  THEN  2 
							ELSE 3											
						END                                                           AS tipoPagoFecha  
						,'+''''+'diasVencidos'+''''+' = CASE WHEN isdate(CCP_FECHVEN) = 1 
															then DATEDIFF(DAY,CONVERT(DATETIME,CCP_FECHVEN,103),GETDATE()) 
														else 0 
														end'
		--PRINT @consulta
		--print 'jojojojojojojoj'
	   SET @where='	FROM ['+@ipServidorConcentradoras+'].['+ @nomBaseConcentra +'].[dbo].[VIS_CONCAR01]  AS Car_Externa 
						 INNER JOIN ['+@ipServidorConcentradoras+'].['+ @nomBaseConcentra +'].[dbo].[PNC_PARAMETR] As A ON CCP_CARTERA = A.PAR_IDENPARA 
						 LEFT OUTER JOIN ['+@ipServidorConcentradoras+'].['+ @nomBaseConcentra +'].[dbo].[PNC_PARAMETR] As B ON CCP_TIPODOCTO = B.PAR_IDENPARA 
			                       												  AND B.PAR_TIPOPARA = '+''''+'TIMO'+''''+' 
						 INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] ON CCP_IDPERSONA = PER_IDPERSONA AND  PER_RFC = '+char(39)+ @rfc+char(39) +' 
						 LEFT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] Z ON Car_Externa.ccp_iddocto = Z.oce_folioorden COLLATE Modern_Spanish_CI_AS  
				   WHERE A.PAR_TIPOPARA = '+''''+'CARTERA'+''''+'  
					 AND A.PAR_IDMODULO = '+''''+'CXC'+''''+'   
					 AND a.par_importe5 <> 1   
					 AND B.PAR_DESCRIP1 = '+''''+'FACTURA'+''''+' 
					 AND DATEDIFF (DAY,CONVERT(DATE, CCP_FECHVEN, 103),GETDATE()) >= 0'+
					 ' AND'+
					 ' CONVERT(DATE,CCP_FECHADOCTO,103) ' +
						' BETWEEN CONVERT(DATE,'
					 +char(39)+@fechaInicio+char(39)+',103) AND CONVERT(DATE,'+char(39)+@fechaFin+char(39)+
					 ',103)'+
					 --'AND OrigenMovimiento IN (''NUEVOS'',''SEMINUEVOS'',''REFACCIONES'',''SERVICIO'',''HOJALATERIA Y PINTURA'')'+
					 ' AND SUBSTRING(CCP_IDDOCTO,1,2) 
                    IN(SELECT SUBSTRING(FCF_SERIE,1,2) FROM ['+@ipServidorSucursales+'].['+ @nombreBase +'].[dbo].ADE_CFDFOLIOS)'+
					 ' '  --ORDER BY CCP_CONSCARTERA
		--print @where
		print @consulta+@consultaDos + @where


		INSERT INTO  @documentosPagados
		    EXECUTE (@consulta+@consultaDos + @where);
		

			SET @auxDos = @auxDos + 1
		END
	--//////////////////////////////////////////////////////////////////////////////////////
	
		  --INSERT INTO @documentosPagados
		  --EXECUTE [SEL_DOC_PAGADOS_DETALLE_SP] @rfc, @idEmpresaBusca
		  
		  
		 SET @aux = @aux + 1
	 END
	 --///////////////////////////////////////////////////////////////////////////////////////
	--SET @maxDos = (SELECT MAX(IDBD) FROM @BDs)

	--WHILE(@auxDos <= @maxDos)
	--	BEGIN
	--		-----------BEGIN Obtengo el nombre de las sucursales ----------------------------------
	--		SELECT	@nombreBase = NombreBase
	--				FROM @BDs WHERE IDBD = @auxDos
	--		-----------END Obtengo el nombre de las sucursales ------------------------------------
	--		SELECT * FROM @documentosPagados WHERE serie  IN(SELECT SUBSTRING(FCF_SERIE,1,2) FROM [GAAU_Universidad]..ADE_CFDFOLIOS)
	--		print @nombreBase
	--		SET @auxDos = @auxDos + 1
	--	END
	--//////////////////////////////////////////////////////////////////////////////////////
	 SELECT * FROM @documentosPagados	 
END

go

