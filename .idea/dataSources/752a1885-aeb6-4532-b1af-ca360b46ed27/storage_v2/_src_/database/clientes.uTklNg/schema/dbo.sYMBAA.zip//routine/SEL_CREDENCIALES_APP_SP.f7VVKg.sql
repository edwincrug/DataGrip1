-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [dbo].[SEL_CREDENCIALES_APP_SP]  'CYC'
CREATE PROCEDURE [dbo].[SEL_CREDENCIALES_APP_SP] 
	@rfcEnviado VARCHAR(500)
AS
BEGIN
		DECLARE @SEL NVARCHAR(MAX) = '', @rfc NVARCHAR(20),@pass VARCHAR(255)=''

		SELECT 
			@rfc = C.[rfcCliente]
			,@pass = U.passwordU   
		FROM [clientes].[dbo].Cliente C
		INNER JOIN [clientes].[dbo].Usuario U ON U.idCliente = C.idCliente
		WHERE C.rfcCliente =  @rfcEnviado
	
		DECLARE @passs table (rfc NVARCHAR(50),pass NVARCHAR(50))

		DECLARE @cadena varchar(max)
		SET  @cadena ='SELECT ''' + @rfc +  ''',convert(varchar(100),DecryptByPassPhrase(''4ndr4d3'',  '+ @pass +' )) '

		INSERT INTO @passs
		EXECUTE (@cadena) 

		select rfc,pass from @passs

END
go

