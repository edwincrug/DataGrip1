-- =============================================
-- Author:		ALEJANDRO LOPEZ QUIROZ
-- Create date: 24052016
-- Description:	obtiene las facturas por pagar por cliente
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FACTURA_DATOSPAGO_SP]  --[dbo].[SEL_FACTURA_DATOSPAGO_SP] @idFactura = '000027670',@idBanco = 2, @idEmpresa = 4
	@idFactura VARCHAR(10) = ''--NUMERIC(18,0) = 0
	,@idBanco NUMERIC(18,0) = 0
	,@idEmpresa NUMERIC(18,0) = 0
	--,@folio VARCHAR(10) = ''
AS
BEGIN	

	DECLARE @consecutivo TINYINT = 0, @referencia VARCHAR(20) = ''
	SELECT @consecutivo = consecutivoP FROM [dbo].[Consecutivo] WHERE [idConsecutivo] = 1


	IF((SELECT TOP 1 [consecutivoP] FROM [dbo].[Consecutivo]) = 99)
		UPDATE [dbo].[Consecutivo] SET [consecutivoP] = 1
	ELSE
		UPDATE [dbo].[Consecutivo] SET [consecutivoP] = [consecutivoP] + 1
   

	/*SELECT  'Zaragoza Motors S.A. de C.V.' nombreProveedor,
			 Banc.convenio,
			 [dbo].[referencia_fn](FAC.serie,FAC.noFactura,@consecutivo) + [dbo].[digito_verificador_fn]([dbo].[referencia_fn](FAC.serie,FAC.noFactura,@consecutivo)) referencia,
			 'Pago de factura' concepto,
			 importe cantidad, --'$ ' + CONVERT(varchar, CAST(importe AS money), 1) cantidad,
			 Banc.urlMicroSitio url,
			 Banc.nombre nombreBanco,
			 Banc.urlRespuesta url_redirect
	FROM Factura FAC 
	JOIN BANCO Banc ON Banc.idBanco = @idBanco
	--WHERE idFactura = @idFactura*/

	SELECT @referencia = [dbo].[referencia_fn](RIGHT(Cartera.SerieDoc,3),RIGHT(Cartera.NoDoc,6),@consecutivo) + [dbo].[digito_verificador_fn]([dbo].[referencia_fn](RIGHT(Cartera.SerieDoc,3),RIGHT(Cartera.NoDoc,6),@consecutivo))		   
	FROM [clientes].[dbo].[Cartera_Clientes_Agrupado] Cartera
	JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON Cartera.[IdAgencia] = SUC.[suc_idsucursal]
	JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON SUC.[emp_idempresa] = EMP.[emp_idempresa]
	LEFT JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] CAT ON EMP.[emp_nombrecto] = CAT.[catemp_nombrecto] AND CAT.tipo = 2	
	JOIN BANCO Banc ON Banc.idBanco = @idBanco
	WHERE Cartera.DES_TIPODOCTO = 'FACTURA'
		  AND Cartera.NoDoc = @idFactura

	print @referencia

	INSERT INTO Referencia (idBanco,idFactura,referencia,fecha,folio)
					 VALUES(@idBanco,1,@referencia,GETDATE(),@idFactura)
	

	SELECT EMP.[emp_nombre] nombreProveedor,
		   Banc.convenio,
		   --@referencia referencia,
		   'Pago de factura' concepto,
		   --1 cantidad,--
		   123321 orderNumber,
		   Cartera.SALDO cantidad,
		   Banc.urlMicroSitio url,
		   Banc.nombre nombreBanco,
		   Banc.urlRespuesta url_redirect
	FROM [clientes].[dbo].[Cartera_Clientes_Agrupado] Cartera
	JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON Cartera.[IdAgencia] = SUC.[suc_idsucursal]
	JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON SUC.[emp_idempresa] = EMP.[emp_idempresa]
	LEFT JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] CAT ON EMP.[emp_nombrecto] = CAT.[catemp_nombrecto] AND CAT.tipo = 2	
	JOIN Banco Banc ON Banc.idBanco = @idBanco
	WHERE Cartera.NoDoc = @idFactura
	--Cartera.DES_TIPODOCTO = 'FACTURA' AND Cartera.PER_RFC = @rfcCliente
END
go

