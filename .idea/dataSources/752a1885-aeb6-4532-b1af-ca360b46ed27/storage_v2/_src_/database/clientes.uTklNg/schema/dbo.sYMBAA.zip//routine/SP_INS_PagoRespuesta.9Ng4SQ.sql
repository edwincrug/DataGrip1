-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_INS_PagoRespuesta]
	 @idPago INT = 0
	,@numeroAutorizacion NVARCHAR(100) = ''
	,@mensaje NVARCHAR(500) = ''
	,@codigoRespuesta NVARCHAR(10) = ''
	,@mp_signature  NVARCHAR(100) = ''
	,@cli_signature  NVARCHAR(100) = ''
	,@mp_reference  NVARCHAR(100) = ''
	,@mp_amount NUMERIC (18,2)
	,@estatus bit = null
	,@mp_cardType nvarchar(10)=NULL
	,@mp_paymentMethod nvarchar(50)=NULL
	,@mp_bankcode nvarchar(25)=NULL
	,@mp_bankname nvarchar(100)=NULL
	,@mp_pan nvarchar(max)=NULL

AS
BEGIN

	EXEC [referencias].[dbo].[SP_INS_PagoRespuesta] 
														 @idTrans = @idPago
														,@numeroAutorizacion = @numeroAutorizacion
														,@mensaje = @mensaje
														,@codigoRespuesta = @codigoRespuesta
														,@mp_signature = @mp_signature
														,@cli_signature = @cli_signature
														,@mp_reference = @mp_reference
														,@mp_amount = @mp_amount
														,@estatus = @estatus
														,@mp_cardType =@mp_cardType
														,@mp_paymentMethod =@mp_paymentMethod
														,@mp_bankcode =@mp_bankcode
														,@mp_bankname =@mp_bankname
														,@mp_pan =@mp_pan

		SELECT 1 AS respuesta

END
go

