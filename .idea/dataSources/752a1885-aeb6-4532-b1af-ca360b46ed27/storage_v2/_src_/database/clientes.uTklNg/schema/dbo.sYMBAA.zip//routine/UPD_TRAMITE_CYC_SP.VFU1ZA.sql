-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- ============================================= 
--	UPD_TRAMITE_CYC_SP 412,0,0
CREATE PROCEDURE [dbo].[UPD_TRAMITE_CYC_SP] 
	  @idPertra INT = 0
	 ,@montoSolicitado DECIMAL(18,2)
	 ,@montoAutorizado DECIMAL(18,2)
	 ,@idUsuario INT = 0
AS
BEGIN

		UPDATE [clientes].[dbo].[TramiteCliente] 
		SET monto = @montoAutorizado  
		WHERE tramites_Id = @idPertra

		UPDATE [clientes].[dbo].[SolicitudMonto] 
		SET monto = @montoAutorizado 
		WHERE tramites_Id = @idPertra

		IF NOT EXISTS(SELECT id FROM  [clientes].[dbo].[CreditosAutorizados]  WHERE idPertra = @idPertra)
		BEGIN
				INSERT INTO  [clientes].[dbo].[CreditosAutorizados] 
				VALUES (@idPertra, @montoSolicitado, @montoAutorizado, @idUsuario,GETDATE() ,0)
		END
		ELSE
		BEGIN
				UPDATE [clientes].[dbo].[CreditosAutorizados]  
				SET montoSolicitado = @montoSolicitado, montoAutorizado = @montoAutorizado, idUsuarioAplico = @idUsuario,fecha = GETDATE()
				WHERE idPertra = @idPertra
		END
	
		SELECT 1 AS exito
END
go

