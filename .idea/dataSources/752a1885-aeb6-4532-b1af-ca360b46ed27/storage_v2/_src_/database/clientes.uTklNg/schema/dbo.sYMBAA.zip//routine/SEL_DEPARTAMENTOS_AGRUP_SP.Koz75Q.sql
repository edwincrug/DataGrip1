-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOS_AGRUP_SP] 
	 @idEmpresa INT = 0
	,@agrupacion INT = 0
AS
BEGIN
		
		SELECT  S.suc_idsucursal AS idSucursal,
				S.suc_nombre	  AS nombre,
		        C.claveCartera,
				0 AS montoSuc FROM  [clientes].[dbo].[CatalogoDepartamento]  C
		INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] S ON S.suc_idsucursal = C.idSucursal
		WHERE C.idEmpresa = @idEmpresa 
		AND C.tipoAgrupacion = @agrupacion
		ORDER BY S.suc_idsucursal
END
go

