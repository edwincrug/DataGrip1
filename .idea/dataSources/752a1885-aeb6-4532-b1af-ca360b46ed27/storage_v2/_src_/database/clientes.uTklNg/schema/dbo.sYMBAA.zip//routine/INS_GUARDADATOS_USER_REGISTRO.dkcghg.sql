-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez
-- Create date: 09/08/2018
-- Description:	Inserta usuario de Portal de Clientes
--   
-- ==========================================================================================
-- EXECUTE [dbo].[INS_GUARDADATOS_USER_REGISTRO] 'Lulu','CSO180718BU0','lmaldonado@bism.com.mx','123456'
CREATE PROCEDURE [dbo].[INS_GUARDADATOS_USER_REGISTRO]
		@nombre VARCHAR(150) = '',
		@rfc VARCHAR(50),
		@correoUsuario VARCHAR(150),
		@contrasena VARCHAR(50)

AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY	
	
	
	DECLARE @msg VARCHAR(500) = '', @estatus VARCHAR(10) = '',@respuesta INT
	DECLARE @per_idpersona INT = 0 ,@nombreP VARCHAR(300) = '' ,@aPaterno VARCHAR(300) = '', @aMaterno VARCHAR(300) = '',@perTipo VARCHAR(10) = '',@totalPersonas INT
	DECLARE @persona TABLE (PER_IDPERSONA INT,PER_NOMRAZON NVARCHAR(500),PER_PATERNO NVARCHAR(500),PER_MATERNO NVARCHAR(500),PER_TIPO NVARCHAR(500))

	INSERT INTO @persona
	SELECT PER_IDPERSONA , PER_NOMRAZON , PER_PATERNO , PER_MATERNO , PER_TIPO FROM GA_Corporativa.dbo.PER_PERSONAS WHERE per_rfc = @rfc
	SET @totalPersonas = (SELECT COUNT(PER_IDPERSONA) FROM  @persona)
		
	IF (@totalPersonas = 1)
	BEGIN

	SELECT  @per_idpersona = PER_IDPERSONA ,@nombreP = PER_NOMRAZON ,@aPaterno = PER_PATERNO ,@aMaterno = PER_MATERNO , @perTipo = PER_TIPO FROM @persona

	EXECUTE [dbo].[SEL_EXISTE_CLIENTE_SP] @per_idpersona, @result = @respuesta OUTPUT

	-- PRINT(@respuesta)

	IF (@per_idpersona <> 0)
		BEGIN
		IF (@respuesta <> 0)
		BEGIN
			IF NOT EXISTS(SELECT idCliente FROM Cliente WHERE rfcCliente = @rfc)
				BEGIN
						
						INSERT INTO Cliente (idTipoCliente ,nombreCliente ,apellidoPaterno ,apellidoMaterno ,fechaAlta ,idEstatus ,rfcCliente ,correo ,imagen,per_idpersona,per_tipo)
									  VALUES(1 ,@nombreP ,@aPaterno ,@aMaterno ,GETDATE() ,2 ,@rfc ,@correoUsuario,'avatar.png', @per_idpersona, @perTipo )

						DECLARE @idCliente NUMERIC(18,0) = @@IDENTITY

						DECLARE @cadena VARBINARY(200),  @cadenaEncrypt VARCHAR(200)   
						SELECT @cadena = EncryptByPassPhrase('4ndr4d3', @contrasena)  

						SET @cadenaEncrypt = (SELECT CONVERT(VARCHAR(300), @cadena, 1))

						INSERT INTO Usuario (passwordU ,idTipoUsuario ,idCliente )
									 VALUES (@cadenaEncrypt ,1 ,@idCliente )

						DECLARE @tokenID uniqueidentifier
						SET @tokenID = NEWID()
				
						INSERT INTO [clientes].[dbo].[CorreoActivacion]([token] ,[per_rfc] ,[fechaCreacion] ,[fechaActivacion] ,[idEstatus] )
																VALUES (@tokenID ,@rfc ,GETDATE() ,NULL ,1 )

						INSERT INTO UsuarioCorreo VALUES (@idCliente, @correoUsuario, 1, 1, 1 )
						

						INSERT INTO [clientes].[dbo].[NotificacionCliente] VALUES ('Bienvenido al portal Clientes','Le damos la bienvenida al portal donde podra dar seguimineto a sus facturas y créditos en Grupo Andrade',0,GETDATE(),'',@idCliente)
																			

						SELECT @estatus = 'ok', @msg ='Cliente con RFC: ' + @rfc + ' registrado con exito! Se ha enviado un correo para su activación a la dirección ' + @correoUsuario + ', favor de revisar su bandeja de entrada o spam.'
				END
			ELSE
				BEGIN
						SELECT @estatus = 'error', @msg ='Cliente con RFC: ' + @rfc + ' ya existe. No se registro.'
				END
			END
			ELSE
			BEGIN
				SELECT @estatus = 'error', @msg ='Usuario con RFC: ' + @rfc + ' no es Cliente de Grupo Andrade'
			END	

		END
	ELSE
		BEGIN
			SELECT @estatus = 'error', @msg ='Usuario con RFC: ' + @rfc + ' no existe en el catalogo de clientes. No se registro.'
		END	
	END
	ELSE
	BEGIN
			SELECT @estatus = 'error', @msg ='El usuario con RFC: ' + @rfc + ' cuenta con mas de un ID registrado en Grupo Andrade, favor de ponerse en contacto con el area de soporte.'
	END

		SELECT @estatus estatus,@msg mensaje, @nombreP nombre ,@aPaterno aPaterno ,@aMaterno aMaterno,@perTipo perTipo , @idCliente idCliente
END TRY
BEGIN CATCH
	PRINT ('Error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = '[INS_GUARDADATOS_USER_REGISTRO]'
	--SELECT @Mensaje = ERROR_MESSAGE()
	--EXECUTE INS_ERROR_SP @Componente, @Mensaje; 
	SELECT 'error' estatus,ERROR_MESSAGE() mensaje--@msg

END CATCH
END
go

