-- =============================================
-- Author:		ALEJANDRO LOPEZ QUIROZ
-- Create date: 24052016
-- Description:	obtiene las facturas por pagar por cliente
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FACTURAS_PAGADAS_SP]  --[dbo].[SEL_FACTURAS_PORPAGAR_SP] @idCliente = 5
	@idCliente NUMERIC(18,0) = 0
AS
BEGIN
	
	DECLARE @rfcCliente VARCHAR(13) = ''
	SELECT @rfcCliente = rfcCliente FROM Cliente WHERE idCliente = @idCliente

	SELECT --idFactura,
		   @idCliente idCliente,
		   Cartera.SerieDoc serie,--
		   Cartera.DES_CARTERA descripcion,--
		   Cartera.OrigenMovimiento departamento, --
		   CONVERT(DATE,Cartera.CCP_FECHADOCTO,103) fechaEmision, --
		   CONVERT(DATE,Cartera.CCP_FECHVEN,103) fechaPago,--
		   Cartera.IMPORTE importe,--1 importe,



		   Cartera.NoDoc folio,--
		   Cartera.DIASVENCIDOS diasCartera,--
		   CASE Cartera.DIASVENCIDOS ---0 dias, por vencer, vDIASVENCIDOS > 0 vencido,  por vencer, vencido
				WHEN 0 THEN 'Por Vencer'
				ELSE 'Vencido'
		   END estatus,		   
		   Cartera.SALDO saldo,--1 saldo,
		   SUC.[emp_idempresa] idEmpresa,--
		   SUC.[suc_idsucursal] idSucursal,--agencia		   
		   Cartera.Anio,--
		   Cartera.Mes,--
		   CAT.rfc rfcEmisor,	--tabla nombre corto ZM
		   Cartera.PER_RFC rfcReceptor -- cliente
		   ,SUC.suc_nombre --LQMA 12072016
		   ,EMP.emp_nombre --LQMA 12072016
	FROM [clientes].[dbo].[Cartera_Clientes_Agrupado] Cartera
	JOIN [ControlAplicaciones].[dbo].[cat_sucursales] SUC ON Cartera.[IdAgencia] = SUC.[suc_idsucursal]
	JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON SUC.[emp_idempresa] = EMP.[emp_idempresa]
	LEFT JOIN [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] CAT ON EMP.[emp_nombrecto] = CAT.[catemp_nombrecto] AND CAT.tipo = 2	
	WHERE Cartera.DES_TIPODOCTO = 'FACTURA' AND Cartera.PER_RFC = @rfcCliente

END

go

