-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	[dbo].[SEL_DEPARTAMENTOS_SP] 1,1,116
CREATE PROCEDURE [dbo].[SEL_DEPARTAMENTOS_SP] 
	 @idEmpresa INT = 0
	,@idSucursal INT = 0
	,@idCliente INT = 0
AS
BEGIN
		DECLARE @consecutivo_contable INT = 0, @consulta NVARCHAR(MAX) = '',  @nomBaseConcentra  NVARCHAR(100) = '',@discrimina NVARCHAR(MAX) = '', @per_idpersona INT = 0
		SELECT @consecutivo_contable = consecutivo_contable  FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal

		SELECT @nomBaseConcentra = BASEMP.nombre_base
		FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
		WHERE emp.emp_idempresa = @idEmpresa
			  AND BASEMP.tipo = 2
	
		SELECT @per_idpersona = per_idpersona FROM [clientes].[dbo].Cliente WHERE idCliente = @idCliente
	
		DECLARE @tabla TABLE (id int identity(1,1),idDepartamento NVARCHAR(10),nombre NVARCHAR(300))
		SET @consulta = 'SELECT PAR_IDENPARA ,   SUBSTRING(PAR_DESCRIP1,    CHARINDEX(''. -'',PAR_DESCRIP1) + 3    ,LEN(PAR_DESCRIP1))  as PAR_DESCRIP1
		FROM '+ @nomBaseConcentra +'.dbo.PNC_PARAMETR
		WHERE PAR_TIPOPARA = ''CARTERA''
		AND PAR_HORA1 NOT IN ('''')
		AND PAR_DESCRIP1 like ''1100-0030-000'+ CONVERT(NVARCHAR(10),@consecutivo_contable) +'%''
		AND PAR_DESCRIP1 NOT IN (SELECT cartera_descripcion  COLLATE Modern_Spanish_CI_AS FROM [clientes].[dbo].[Cat_CarteraDiscriminar] WHERE  idEmpresa = '+ CONVERT(NVARCHAR(10),@idEmpresa) +'  AND idSucursal = '+ CONVERT(NVARCHAR(10), @idSucursal) +' )
		--AND PAR_IDENPARA NOT IN (SELECT Con_ClaveCartera FROM  '+ @nomBaseConcentra +'.[dbo].[CXC_CONDCARTERA] where [Con_IdPersona] = '+ CONVERT(NVARCHAR(10),@per_idpersona) +')
		--AND PAR_IDENPARA NOT IN (SELECT cartera  COLLATE Modern_Spanish_CI_AS FROM  [clientes].[dbo].[TramiteCliente] WHERE idCliente = '+ CONVERT(NVARCHAR(10),@idCliente) +' AND estatus NOT IN(6,7))
		ORDER BY PAR_HORA1'
		PRINT(@consulta)
		INSERT INTO @tabla
		EXECUTE(@consulta)

		SELECT  T.idDepartamento ,T.nombre AS n, d.tipoAgrupacion,d.nombreDepartamento AS nombre
		FROM @tabla T
		INNER JOIN [clientes].[dbo].[CatalogoDepartamento] D ON D.claveCartera = T.idDepartamento
		
END


go

