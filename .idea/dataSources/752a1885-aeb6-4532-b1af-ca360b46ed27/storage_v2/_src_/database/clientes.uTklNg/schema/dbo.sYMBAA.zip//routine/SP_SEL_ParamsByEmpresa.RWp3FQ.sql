

-- =============================================
-- Author:		Emiliano Damazo	
-- Create date: 23-10-2019
-- Description:	obtiene el valor predeterminado del porcentaje inicial
-- =============================================
CREATE PROCEDURE [dbo].[SP_SEL_ParamsByEmpresa] 
(
	 @idEmpresa int = 0
	,@idDepartamento int = 0
)
AS
BEGIN

BEGIN TRY  --Start TryCatch
		
		SELECT 100 AS valor

		--SELECT [descripcion] AS msiDescripcion
		--      ,[valor] AS msiValor
		--  FROM [clientes].[dbo].[Parametros]
		-- WHERE [nombre] = 'MSI'

		-- SELECT CAST([valor] AS decimal(18,2)) AS msiMinimo
		--  FROM [clientes].[dbo].[Parametros]
		-- WHERE [nombre] = 'MSIminimo'


		SELECT 
				 pr_ValorString2 AS msiDescripcion
				,pr_ValorString1 AS msiValor
				,pr_Valor1 AS msiMinimo
		FROM [referencias].[dbo].[Parametros]
		WHERE pr_TipoParametro = 'BANCOWEB'



		-- Se comenta por que unicamente se puede pagar el 100% del valor de la factura
		--SELECT   [id]
		--		,[idEmpresa]
		--		,[idSucursal]
		--		,[idDepartamento]
		--		,[valor]
		--FROM [clientes].[dbo].[Cat_RestriccionPago]
		--WHERE [idEmpresa] = @idEmpresa
		--AND idDepartamento = @idDepartamento

END TRY  
BEGIN CATCH  
    SELECT  
        ERROR_NUMBER() AS ErrorNumber  
        ,ERROR_SEVERITY() AS ErrorSeverity  
        ,ERROR_STATE() AS ErrorState  
        ,ERROR_PROCEDURE() AS ErrorProcedure  
        ,ERROR_LINE() AS ErrorLine  
        ,ERROR_MESSAGE() AS ErrorMessage;  

END CATCH; --End TryCatch


END

go

