-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SEL_CORREOUSER_SP
	@idCliente INT = 0
AS
BEGIN
	
	SELECT usu_correo 
	FROM [ControlAplicaciones].[dbo].[cat_usuarios]
	WHERE usu_idusuario = @idCliente

END
go

