-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST UPD_TOKEN_APP_MOVIL_SP 123456789987654321
-- =============================================
CREATE PROCEDURE [dbo].[UPD_TOKEN_APP_MOVIL_SP]
@token VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [dbo].[Parametros] SET valor = @token WHERE nombre = 'TOKEN_APPMOVIL'
END
go

