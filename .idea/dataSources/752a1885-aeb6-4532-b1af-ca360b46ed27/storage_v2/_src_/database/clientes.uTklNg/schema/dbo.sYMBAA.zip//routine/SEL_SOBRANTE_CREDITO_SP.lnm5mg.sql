-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- SEL_SOBRANTE_CREDITO_SP 79672,4 , 1
CREATE PROCEDURE  [dbo].[SEL_SOBRANTE_CREDITO_SP]
	 @idCliente INT = 0
	,@idEmpresa INT = 0
	,@agrupacion INT = 0
AS
BEGIN
	
		DECLARE @aux INT= 1, @max INT = 0,@aux2 INT= 1, @max2 INT = 0,@rfcCliente VARCHAR(15) = ''
		DECLARE @carteras TABLE(id INT IDENTITY(1,1),cartera NVARCHAR(10),idSucursal INT)
		DECLARE @limite TABLE( ID INT IDENTITY(1,1),limite NUMERIC(18,0),idSucursal INT)
		DECLARE @limitesDisponibles TABLE(disponible NUMERIC(18,0),idSucursal INT,claveCartera VARCHAR(200),credTotal NUMERIC(18,0), credUtilizado NUMERIC(18,0))
		
		

		INSERT INTO @carteras
		SELECT claveCartera,idSucursal FROM [clientes].[dbo].[CatalogoDepartamento] WHERE idEmpresa = @idEmpresa AND tipoAgrupacion = @agrupacion
	

		SELECT @rfcCliente = rfcCliente FROM Cliente WHERE per_idpersona = @idCliente

		SET @max = (SELECT COUNT(id) FROM @carteras)


	

		WHILE(@aux <= @max)
		BEGIN
				DECLARE @Facturas TABLE( ID INT IDENTITY(1,1),saldo NUMERIC(18,0),idsu INT)
				DECLARE @idsuc INT ,@NombreBase VARCHAR(200),@cart VARCHAR(200),@cadena NVARCHAR(MAX) = '',@cadena2 NVARCHAR(MAX) = '', @limit NUMERIC(18,0) = 0,@debe NUMERIC(18,0) = 0

				SELECT @cart = cartera , @idsuc = idSucursal FROM @carteras WHERE @aux = id


				SELECT @NombreBase = nombre_base FROM  Centralizacionv2.dbo.dig_cat_bases_bpro WHERE suc_idsucursal = @idsuc


				SET  @cadena = '  SELECT Con_LimCredito ,' + CONVERT(NVARCHAR(20), @idsuc) + 
							   '  FROM ['+@nombreBase+'].[DBO].cxc_condcartera  ' +
							   '  WHERE Con_ClaveCartera = ''' + @cart + ''' 
								  AND Con_IdPersona = ' + CONVERT(NVARCHAR(20), @idCliente) 
								  PRINT(@cadena)
								  INSERT INTO @limite
								  EXECUTE (@cadena)	

				SET @cadena2 = '  SELECT  SALDO , ' + CONVERT(NVARCHAR(20), @idsuc) + '
										  FROM ['+@nombreBase+'].[DBO].[BI_CARTERA_CLIENTES] '  + 
										' WHERE DES_TIPODOCTO = ''FACTURA'' AND SUBSTRING(CCP_IDDOCTO,1,2) ' + char(13) + 
										' IN(SELECT SUBSTRING(FCF_SERIE,1,2)' + char(13) + 
										' FROM  ['+@nombreBase+'].[DBO].[ADE_CFDFOLIOS]) AND OrigenMovimiento IN (''NUEVOS'',''SEMINUEVOS'',''REFACCIONES'',''SERVICIO'',''HOJALATERIA Y PINTURA'') ' + char(13) + 
										' AND PER_RFC = ''' + @rfcCliente + '''
										  AND CCP_CARTERA = ''' + @cart + '''
										' 		
								 PRINT(@cadena2)
								 INSERT INTO @Facturas
								 EXECUTE (@cadena2)	

				SELECT @limit = limite FROM @limite WHERE idSucursal = @idsuc
				
				SET @debe = (SELECT ISNULL(SUM(saldo),0) FROM  @Facturas where idsu = @idsuc)
				

				INSERT INTO @limitesDisponibles
				SELECT @limit - @debe , @idsuc , @cart ,@limit , @debe
				
				SET @aux = @aux + 1	
		END
	
		SELECT   L.disponible,
				 L.idSucursal,
				 S.suc_nombre AS nombre,
				 0 AS ocupa,
				 L.disponible AS restante,
				 L.claveCartera,
				 L.credTotal,
				 L.credUtilizado
		FROM @limitesDisponibles L	
		INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] S ON S.suc_idsucursal = L.idSucursal
		ORDER BY L.idSucursal
END
go

