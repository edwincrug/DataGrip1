-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE INS_MONTO_SP 
	@monto DECIMAL(18,2) = 0
AS
BEGIN
	
		INSERT INTO [clientes].[dbo].[SolicitudMonto] (monto) 
		VALUES (@monto)


		DECLARE @id_SolicitudMonto INT = @@IDENTITY


		SELECT @id_SolicitudMonto AS id_SolicitudMonto



END
go

