-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	SEL_DEBE_FACTURAS_SP 1, 79672
CREATE PROCEDURE [dbo].[SEL_DEBE_FACTURAS_SP] 
	 @idEmpresa INT = 0
	,@idPersona INT = 0
AS
BEGIN
	   DECLARE @BDs TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(200), NombreBase VARCHAR(50),suc_idsucursal INT,suc_nombre VARCHAR(50))
	  
	   DECLARE @nombreBase VARCHAR(50) = '', @cadena NVARCHAR(MAX) = '', @nom_suc NVARCHAR(200) = '', @nom_emp NVARCHAR(100) = '',--  @idSucursal NVARCHAR(10) = '',
	   @rfcEmisor VARCHAR(50)='', @ipServidor VARCHAR(20)='', @rfcCliente VARCHAR(15) = '',@dias INT,@msj NVARCHAR(200) = 'Exito',@estatus INT = 1
	   
	   DECLARE @aux INT= 1, @max INT = 0,@maxf INT = 0

	   DECLARE @Facturas TABLE( ID INT IDENTITY(1,1),factura VARCHAR(50),diasVencidos INT)

		
	   INSERT INTO @BDs
	   SELECT EMP.emp_idempresa ,ME.marca ,BASEMP.nombre_base ,BASEMP.suc_idsucursal ,sucursales.suc_nombre
	   FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
	   INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
       INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.suc_idsucursal = sucursales.suc_idsucursal
	   INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  EMP.emp_idempresa
	   WHERE  BASEMP.emp_idempresa  = @idEmpresa
	   AND BASEMP.suc_idsucursal NOT IN (7,8,11)
	   AND BASEMP.tipo = 1

		
		
		SELECT @max = MAX(IDBD) FROM @BDs
		
		SELECT @rfcCliente = rfcCliente FROM Cliente WHERE per_idpersona = @idPersona
		SELECT @dias = dias FROM [clientes].[dbo].[Num_diasLimite] WHERE idEmpresa = @idEmpresa

	
		WHILE(@aux <= @max)
			BEGIN		
			
				DECLARE	@idSucursal INT = 0
			
				SELECT	@nombreBase = NombreBase,@idSucursal = suc_idsucursal ,@nom_suc = suc_nombre ,@nom_emp = emp_nombre FROM @BDs WHERE IDBD = @aux
				
				SET @cadena = 'SELECT CCP_IDDOCTO,DIASVENCIDOS' +
								' FROM ['+@nombreBase+'].[DBO].[BI_CARTERA_CLIENTES] '  + 
								' WHERE DES_TIPODOCTO = ''FACTURA'' AND SUBSTRING(CCP_IDDOCTO,1,2) ' + char(13) + 
								' IN(SELECT SUBSTRING(FCF_SERIE,1,2)' + char(13) + 
								' FROM  ['+@nombreBase+'].[DBO].[ADE_CFDFOLIOS]) AND OrigenMovimiento IN (''NUEVOS'',''SEMINUEVOS'',''REFACCIONES'',''SERVICIO'',''HOJALATERIA Y PINTURA'') ' + char(13) + 
								' AND PER_RFC = ''' + @rfcCliente + '''
								  AND DIASVENCIDOS >= ' +CONVERT(NVARCHAR(10),@dias) + '
								' 
								PRINT (@cadena)
								
								INSERT INTO @Facturas
								execute (@cadena)

								SET @maxf =(select COUNT(ID) FROM @Facturas)
								IF (@maxf >1)
								BEGIN
								SET @msj  = 'No puedes solicitar ningún  tipo de crédito ya que tienes facturas vencidas !!!'
								SET @estatus = 0
									BREAK;
								END

				SET @aux = @aux + 1	
	END

	SELECT @msj AS msj , @estatus AS estatus
	
END
go

