-- =============================================
-- Author:		Laura Gordillo
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [dbo].[SEL_FACTURA_DATOS_PAGO_SP] 13842,1,10
CREATE PROCEDURE [dbo].[SEL_FACTURA_DATOS_PAGO_SP] 
	 @idReferencia INT = 0
	,@idBanco INT = 0
	,@idTrans INT = 0
AS
BEGIN
	SELECT	empresas.emp_nombre,
		banc.convenio,
		'Pago de factura' concepto,
		@idReferencia orderNumber,
		T.importeDocumento AS cantidad,		
		Banc.urlMicroSitio url,
		Banc.nombre nombreBanco,
		Banc.urlRespuesta url_redirect,
		Banc.producto AS mp_product ,
		Banc.MONEDA AS mp_currency 
	FROM [referencias].DBO.[Referencia] REF
		INNER JOIN [referencias].DBO.[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia 
		INNER JOIN GA_Corporativa.dbo.PER_PERSONAS personas ON personas.per_idpersona = DEREF.idcliente
		INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = REF.idEmpresa
		INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = DEREF.idSucursal
		INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] departamentos  ON departamentos.dep_iddepartamento = DEREF.idDepartamento 
		INNER JOIN [referencias].DBO.[TipoDocumento] DOC ON DOC.idTipoDocumento = DEREF.idTipoDocumento
		INNER JOIN Banco Banc ON Banc.idBanco = @idBanco
		INNER JOIN [referencias].dbo.TransaccionReferencia TR ON TR.idReferencia = REF.idReferencia
		INNER JOIN [referencias].dbo.Transaccion T ON T.idTrans = TR.idTrans
		WHERE REF.idReferencia = @idReferencia
		AND T.idTrans = @idTrans
END

go

