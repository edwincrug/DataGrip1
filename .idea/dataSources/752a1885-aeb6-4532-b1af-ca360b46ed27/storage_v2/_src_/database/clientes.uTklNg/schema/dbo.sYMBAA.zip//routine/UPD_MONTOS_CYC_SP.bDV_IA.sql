-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	UPD_MONTOS_CYC_SP 412
CREATE PROCEDURE [dbo].[UPD_MONTOS_CYC_SP] 
	 @idPertra INT = 0
	,@idSucursal INT = 0
	,@monto DECIMAL(18,2)
AS
BEGIN
		DECLARE @idSolicitud INT = 0
		SELECT @idSolicitud = ID FROM [clientes].[dbo].[SolicitudMonto] WHERE tramites_Id = @idPertra
	
		UPDATE [clientes].[dbo].[DestinoMontoSucursal]
		SET monto = @monto
		WHERE idSucursal = @idSucursal
		AND id_SolicitudMonto = @idSolicitud

		SELECT 1 AS exito

END
go

