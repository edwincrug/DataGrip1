-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_DOCUMENTACYC_SP]
	 @id_docCycTra INT = 0
	,@observacion NVARCHAR(MAX)
AS
BEGIN
	
	UPDATE [docCycTramite] 
	SET observacion = @observacion 
	WHERE id_docCycTra = @id_docCycTra

	SELECT success = 1, msg = 'Se registro correctamente';

END
go

