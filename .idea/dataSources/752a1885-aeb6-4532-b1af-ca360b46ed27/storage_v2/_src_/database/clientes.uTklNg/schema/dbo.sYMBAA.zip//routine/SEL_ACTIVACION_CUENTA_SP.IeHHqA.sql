CREATE PROCEDURE [dbo].[SEL_ACTIVACION_CUENTA_SP]
@token VARCHAR(300) = '',
@rfcCliente VARCHAR(13) = '',
@opcion int = 1 --1 activacion, 2 cambio correo
AS
BEGIN

	DECLARE @msg VARCHAR(100) = '', @estatus VARCHAR(10) = 'ok'

	IF NOT EXISTS(SELECT * FROM [dbo].[CorreoActivacion] WHERE [token] = @token AND per_rfc = @rfcCliente AND idEstatus = 1)
		BEGIN
			SELECT @estatus = 'error', @msg = 'Link de activación no valido.'
		END
	ELSE
		BEGIN

				IF(@opcion = 1) --activar usuario
				BEGIN

					UPDATE Cliente
					SET idEstatus = 1
					WHERE rfcCliente = @rfcCliente

					SELECT @estatus = 'ok', @msg = 'El usuario ' + @rfcCliente + ' ha sido activado.'	

				END

				IF(@opcion = 2)--actualizar correo
				BEGIN					
					
					UPDATE Cliente
					SET correo = correoTemporal,
						correoTemporal = NULL
					WHERE rfcCliente = @rfcCliente

					SELECT @estatus = 'ok', @msg = 'Ha sido actualizado el correo del usuario ' + @rfcCliente + '.'	

				END

				UPDATE [dbo].[CorreoActivacion]
				SET fechaActivacion = GETDATE(), idEstatus = 2
				WHERE [token] = @token AND per_rfc = @rfcCliente
		END	

	SELECT @estatus estatus, @msg mensaje

END

go

