-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [dbo].[SEL_TRAMITE_CLIENTE_SP]  116,391,1,1
CREATE PROCEDURE [dbo].[SEL_TRAMITE_CLIENTE_SP] 
	 @idCliente INT = 0
	,@idTramite INT = 0
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
AS
BEGIN

		DECLARE @correoVend VARCHAR(200), @correoG VARCHAR(200),@correoGA NVARCHAR(200), @correoCyc VARCHAR(200),@idDepartamento INT

		SELECT @idEmpresa = idEmpresa , @idSucursal = idSucursal, @idDepartamento = idDepartamento FROM [clientes].[dbo].[TramiteCliente] WHERE tramites_Id = @idTramite
	
		SELECT  @correoG = U.[usu_correo]+ ';samuel.valdes@grupoandrade.com;david.vazquezr@outlook.com'
		FROM [clientes].[dbo].[Cat_GerenteAgencia] GR
		INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = GR.idUsuario
		WHERE GR.idEmpresa = @idEmpresa
		AND GR.idSucursal = @idSucursal


		SELECT @correoCyc = U.[usu_correo]+ ';samuel.valdes@grupoandrade.com;david.vazquezr@outlook.com'
		FROM [clientes].[dbo].[Cat_CycRevisor] C
		INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = C.idUsuario
		WHERE C.idEmpresa = @idEmpresa
		AND C.idSucursal = @idSucursal


		SELECT @correoGA = U.[usu_correo]+ ';samuel.valdes@grupoandrade.com;david.vazquezr@outlook.com'
		FROM [clientes].[dbo].[Cat_GerenteAreaAgencia] GAA
		INNER JOIN [ControlAplicaciones].[dbo].[cat_usuarios] U ON U.usu_idusuario = GAA.idUsuario
		WHERE GAA.idEmpresa = @idEmpresa
		AND GAA.idSucursal = @idSucursal
		AND GAA.idDepartamento = @idDepartamento
		

	SELECT 
			t.idEmpresa
			,t.idSucursal 
			--,t.idDepartamento 
			,t.monto
			,t.observacion
			,C.per_idpersona
			,t.cartera AS idDepartamento
			,t.descripcion AS PAR_DESCRIP1
			,ME.marca AS emp_nombre
			,S.suc_nombre
			,d.dep_nombre
			,t.estatus
			,UC.correo
			,UC.recibeNot
			,t.id_TramiteAsolicitar
			,CD.tipoAgrupacion
			,@correoCyc AS correoCYC
			,@correoG AS correoG 
			,P.valor as link
			,Pr.valor as imgGA
			,@correoGA as correoGA
	FROM [clientes].[dbo].[TramiteCliente] t
	INNER JOIN  [clientes].[dbo].[Cliente] C ON C.idCliente =  t.idCliente
	INNER JOIN [ControlAplicaciones].[dbo].cat_empresas E ON E.emp_idempresa = t.idEmpresa
	INNER JOIN [ControlAplicaciones].[dbo].cat_sucursales  S ON S.suc_idsucursal = t.idSucursal 
	INNER JOIN ControlAplicaciones.dbo.cat_departamentos  D ON D.dep_iddepartamento = t.idDepartamento 
	INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  t.idEmpresa
	INNER JOIN [clientes].[dbo].[UsuarioCorreo] UC ON UC.idCliente = t.idCliente
	INNER JOIN [clientes].[dbo].[CatalogoDepartamento] CD ON CD.claveCartera = t.cartera
	LEFT JOIN [clientes].[dbo].[Parametros] P ON P.nombre = 'url_panel'
	LEFT JOIN [clientes].[dbo].[Parametros] Pr ON Pr.nombre = 'img_GA'
	WHERE t.idCliente = @idCliente  AND t.tramites_id = @idTramite
	AND UC.idTipoCorreo = 1

	
END
go

