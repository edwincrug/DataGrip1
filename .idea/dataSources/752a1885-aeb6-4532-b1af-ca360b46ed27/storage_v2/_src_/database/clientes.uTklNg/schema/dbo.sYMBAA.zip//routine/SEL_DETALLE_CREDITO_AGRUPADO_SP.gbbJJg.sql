-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	SEL_DETALLE_CREDITO_AGRUPADO_SP 79672,4,1
CREATE PROCEDURE [dbo].[SEL_DETALLE_CREDITO_AGRUPADO_SP] 
	 @idCliente INT = 0
	,@idEmpresa INT = 0
	,@agrupacion INT = 0
AS
BEGIN
		DECLARE @aux INT= 1, @max INT = 0,@aux2 INT= 1, @max2 INT = 0,@rfcCliente VARCHAR(15) = ''
		DECLARE @carteras TABLE(id INT IDENTITY(1,1),cartera NVARCHAR(10),idSucursal INT)
		DECLARE @Facturas TABLE( ID INT IDENTITY(1,1),saldo NUMERIC(18,0))

		INSERT INTO @carteras
		SELECT claveCartera,idSucursal FROM [clientes].[dbo].[CatalogoDepartamento] WHERE idEmpresa = @idEmpresa AND tipoAgrupacion = @agrupacion
		and idSucursal not in(7,8)

		SET @max = (SELECT COUNT(id) FROM @carteras)
		

		SELECT @rfcCliente = rfcCliente FROM Cliente WHERE per_idpersona = @idCliente

		WHILE(@aux <= @max)
			BEGIN
				
				DECLARE @idsuc INT ,@NombreBase VARCHAR(200),@cart VARCHAR(200),@cadena NVARCHAR(MAX) = ''
				SELECT @idsuc = idSucursal, @cart = cartera FROM @carteras WHERE id = @aux
				

				
				SELECT @NombreBase = nombre_base FROM  Centralizacionv2.dbo.dig_cat_bases_bpro WHERE suc_idsucursal = @idsuc
		

						SET @cadena = 'SELECT 	SALDO 
										  FROM ['+@nombreBase+'].[DBO].[BI_CARTERA_CLIENTES] '  + 
										' WHERE DES_TIPODOCTO = ''FACTURA'' AND SUBSTRING(CCP_IDDOCTO,1,2) ' + char(13) + 
										' IN(SELECT SUBSTRING(FCF_SERIE,1,2)' + char(13) + 
										' FROM  ['+@nombreBase+'].[DBO].[ADE_CFDFOLIOS]) AND OrigenMovimiento IN (''NUEVOS'',''SEMINUEVOS'',''REFACCIONES'',''SERVICIO'',''HOJALATERIA Y PINTURA'') ' + char(13) + 
										' AND PER_RFC = ''' + @rfcCliente + '''
										  AND CCP_CARTERA = ''' + @cart + '''
										' 
										PRINT (@cadena)
								
										INSERT INTO @Facturas
										EXECUTE (@cadena)	
			SET @aux = @aux + 1	
		END
	
	SELECT ISNULL(SUM(saldo),0) AS saldoPendiente FROM  @Facturas 

END
go

