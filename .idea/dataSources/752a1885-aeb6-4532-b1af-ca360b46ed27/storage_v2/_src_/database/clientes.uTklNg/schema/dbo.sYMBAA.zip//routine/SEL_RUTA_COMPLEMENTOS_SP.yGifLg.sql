-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--   SEL_RUTA_COMPLEMENTOS_SP  4,6
CREATE PROCEDURE [dbo].[SEL_RUTA_COMPLEMENTOS_SP] 
	 @idEmpresa INT = 0
	,@idSucursal INT = 0
AS
BEGIN
		DECLARE @NombreBase NVARCHAR(200) = ''
		DECLARE @tabRuta TABLE(pdf nvarchar(200),xml nvarchar(200))

		SELECT @NombreBase = BASEMP.nombre_base 
		FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
		INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
		WHERE BASEMP.emp_idempresa = @idEmpresa
			  AND BASEMP.suc_idsucursal = @idSucursal
			  AND BASEMP.tipo = 1

	DECLARE @consulta   VARCHAR(max) = '';
	SET @consulta = ' SELECT PAR_DESCRIP3,PAR_DESCRIP1 FROM '+@NombreBase+'.DBO.PNC_PARAMETR
					  WHERE PAR_TIPOPARA = ''RT''
					  AND PAR_IDENPARA like ''CFD''	'

			
	INSERT INTO @tabRuta	
	EXECUTE(@consulta) 

	--print (@consulta)
	SELECT pdf,xml FROM @tabRuta
END
go

