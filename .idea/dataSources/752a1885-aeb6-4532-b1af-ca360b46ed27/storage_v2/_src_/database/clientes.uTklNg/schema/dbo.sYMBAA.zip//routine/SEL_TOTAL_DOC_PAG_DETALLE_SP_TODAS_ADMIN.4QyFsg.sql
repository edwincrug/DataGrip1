-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- SEL_TOTAL_DOC_PAG_DETALLE_SP_TODAS_ADMIN 'BRM840921P9A',4,8,'20/01/2019','01/07/2020'
CREATE PROCEDURE [dbo].[SEL_TOTAL_DOC_PAG_DETALLE_SP_TODAS_ADMIN]
     @rfc VARCHAR(100) = ''
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
	,@fechaInicial VARCHAR(10) = ''
	,@fechafin VARCHAR(10) = ''	
AS
BEGIN
SET NOCOUNT ON;
	--@rfc de prueba MAPI731031HT4
	

	--IF @idSucursal = 0 
	--	SET @idSucursal = null

		DECLARE @BDs TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(200), NombreBase VARCHAR(50),suc_idsucursal INT,suc_nombre VARCHAR(50))
	  
	   DECLARE @nombreBase VARCHAR(50) = '', @cadena NVARCHAR(MAX) = '', @nom_suc NVARCHAR(200) = '', @nom_emp NVARCHAR(100) = '',--  @idSucursal NVARCHAR(10) = '',
	   @rfcEmisor VARCHAR(50)='', @ipServidor VARCHAR(20)='', @rfcCliente VARCHAR(15) = ''
	   
	   DECLARE @aux INT= 1, @max INT = 0

	   DECLARE @Facturas TABLE( ID INT IDENTITY(1,1),idCliente NUMERIC(18,0),serie VARCHAR(50),folio VARCHAR(50)
	   ,descripcion VARCHAR(MAX),fechadoc VARCHAR(50),fechaVencimiento VARCHAR(50),diasCartera NUMERIC(18,0),estatus VARCHAR(50),importe decimal(18, 5),
				saldo decimal(18, 5),idEmpresa NUMERIC(18,0),idSucursal NUMERIC(18,0),departamento VARCHAR(50),rfcEmisor VARCHAR(50),rfcReceptor VARCHAR(50),suc_nombre VARCHAR(50),emp_nombre VARCHAR(50),idDepartamento NUMERIC(18,0),pedidos VARCHAR(50),cotizacion VARCHAR(50),emp_idPersona NUMERIC(18,0),nombreCliente NVARCHAR(500))

		


	   INSERT INTO @BDs
	   SELECT EMP.emp_idempresa ,ME.marca ,BASEMP.nombre_base ,BASEMP.suc_idsucursal ,sucursales.suc_nombre
	   FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
	   INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
       INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.suc_idsucursal = sucursales.suc_idsucursal
	   INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  EMP.emp_idempresa
	   WHERE  BASEMP.emp_idempresa  = @idEmpresa
	  AND BASEMP.suc_idsucursal =CASE WHEN  @idSucursal = 0 THEN BASEMP.suc_idsucursal ELSE @idSucursal END --NOT IN (7,8,11)
	   AND BASEMP.tipo = 1

		
		
		SELECT @max = MAX(IDBD) FROM @BDs

		set @rfcCliente = @rfc

	
		WHILE(@aux <= @max)
			BEGIN		
			
				--DECLARE	@idSucursal INT = 0
			
				SELECT	@nombreBase = NombreBase,@idSucursal = suc_idsucursal ,@nom_suc = suc_nombre ,@nom_emp = emp_nombre FROM @BDs WHERE IDBD = @aux
					SELECT @rfcEmisor = rfc FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP WHERE emp_idempresa = @idEmpresa AND  tipo = 2 

					
				SET @cadena = 'SELECT 0,(select [referencias].[dbo].[fn_BuscaLetras](CCP_IDDOCTO))' +
										',(select [referencias].[dbo].[fn_BuscaNumeros](CCP_IDDOCTO))' +
										',DES_CARTERA' +
										',CCP_FECHADOCTO' +
										',FECHAVENCIDO' +
										',DIASVENCIDOS' +
										',CASE'+
											' WHEN DIASVENCIDOS <= 0 THEN ''Por Vencer'' ' +
											'ELSE ''Vencido'' ' +
										'END AS ''estatus'' ' +
										',IMPORTE' +
										',SALDO' +
							            ','+CONVERT(NVARCHAR(10),@idEmpresa ) +
										','+CONVERT(NVARCHAR(10),@idSucursal) +
										',OrigenMovimiento'+ char(13) +
										','+char(39)+ @rfcEmisor + char(39) +
										', PER_RFC '+ char(13) +
										','+char(39)+ @nom_suc +char(39)+
										','+char(39)+ @nom_emp +char(39)+
										',(SELECT dep_iddepartamento FROM [ControlAplicaciones].[dbo].[cat_departamentos] WHERE emp_idempresa = ' +CONVERT(NVARCHAR(10),@idEmpresa )+' AND suc_idsucursal = '+CONVERT(NVARCHAR(10),@idSucursal)+' AND  dep_nombrecto = ' + char(13) + 
										' (SELECT CASE WHEN OrigenMovimiento = ''NUEVOS'' THEN ''UN'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''SEMINUEVOS'' THEN ''US'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''REFACCIONES'' THEN ''RE'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''SERVICIO '' THEN ''SE'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''NEGOCIOS '' THEN ''RE'' ' + char(13) + 
										' WHEN OrigenMovimiento = ''HOJALATERIA Y PINTURA '' THEN ''SE'' END))'+
										',CASE WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) IN (''A'',''B'',''D'') THEN (SELECT VTE_REFERENCIA1 FROM ['+@nombreBase+'].[DBO].[ADE_VTAFI] WHERE VTE_DOCTO = CCP_IDDOCTO)'+
										' WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''F'' THEN (SELECT PMM_REF2 FROM ['+@nombreBase+'].[DBO].[PAR_PEDMOST] WHERE PMM_REF2 = CCP_IDDOCTO AND PMM_COTPED = ''PEDIDO'' ) ELSE ''No identificado'' END ' +
										',CASE WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''A'' THEN (SELECT PMM_REF2 FROM  ['+@nombreBase+'].[DBO].[PAR_PEDMOST] WHERE PMM_REF2 = CCP_IDDOCTO AND PMM_COTPED = ''PEDIDO'' )'+
										' WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''D'' THEN ''SIN COTIZACIÓN'' ' + CHAR(13)+
										' WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) = ''B'' THEN ''PENDIENTE'' ' + CHAR(13)+
										' ELSE ''No identificado'' END ' +
										',CCP_IDPERSONA' + CHAR(13)+
										',Nombre ' + CHAR(13)+
								' FROM ['+@nombreBase+'].[DBO].[BI_CARTERA_CLIENTES] '  + 
								' WHERE DES_TIPODOCTO = ''FACTURA'' AND SUBSTRING(CCP_IDDOCTO,1,2) ' + char(13) + 
								' IN(SELECT SUBSTRING(FCF_SERIE,1,2)' + char(13) + 
								' FROM  ['+@nombreBase+'].[DBO].[ADE_CFDFOLIOS]) AND OrigenMovimiento IN (''NUEVOS'',''SEMINUEVOS'',''REFACCIONES'',''SERVICIO'',''HOJALATERIA Y PINTURA'') ' + char(13) + 
								' AND  CONVERT(DATE,CCP_FECHADOCTO,103)  BETWEEN CONVERT(DATE,' +char(39)+@fechaInicial+char(39)+',103) AND CONVERT(DATE,'+char(39)+@fechaFin+char(39)+',103) AND
								PER_RFC = ''' + @rfcCliente + '''' 
								PRINT (@cadena)
								
								INSERT INTO @Facturas
								execute (@cadena)

				SET @aux = @aux + 1	
	END

	SELECT F.idCliente ,F.serie ,F.folio ,F.descripcion,F.fechadoc ,F.fechaVencimiento ,F.diasCartera  ,F.estatus  ,F.importe ,F.saldo ,F.idEmpresa ,F.idSucursal ,F.departamento ,F.rfcEmisor ,F.rfcReceptor,F.suc_nombre ,F.emp_nombre ,F.idDepartamento ,F.pedidos,F.cotizacion ,F.emp_idPersona ,F.nombreCliente
	, 3 as mp_node
	, 7 as mp_concept
	--, P.PER_EMAIL AS correo
	,'david.vazquezr@outlook.com' AS correo
	,MMO.service_id
	,MMO.invoice_template_id
	,MMO.payment_template_id
	,MMO.basic AS basic
	,ISNULL(COMI.visa,0) AS visa
	,ISNULL(COMI.masterCard,0) AS masterCard
	,ISNULL(COMI.amex,0) AS amex
	FROM  @Facturas F
	--LEFT JOIN [clientes].[dbo].[Cat_DivisionOrg_BBVA] D ON D.idEmpresa = F.idEmpresa AND D.idSucursal = F.idSucursal
	--INNER JOIN  [GA_Corporativa].[dbo].[PER_PERSONAS] P ON P.PER_IDPERSONA = F.emp_idPersona
	LEFT JOIN  [clientes].[dbo].[Cat_ComisionPago] COMI ON COMI.idEmpresa = F.idEmpresa AND COMI.idDepartamento = F.idDepartamento
	LEFT JOIN [clientes].[dbo].[Cat_MMO] MMO ON MMO.idEmpresa  = F.idEmpresa AND MMO.idSucursal = F.idSucursal
	

	--DECLARE @documentosPagados TABLE  (ID INT IDENTITY(1,1),idCliente int,complemento int,rfcReceptor varchar(20),rfcEmisor varchar(50),serie varchar(150),folio varchar(150),idEmpresa int ,empresa nvarchar(150),idSucursal	int  ,sucursal nvarchar(150),idDepartamento int,departamento nvarchar(100),cartera nvarchar(10),idDocto  nvarchar(20),tipoDocto nvarchar(20),fechaVencimiento nvarchar(20),fechaUltimoPago  nvarchar(20),cargo numeric(18,5),abono numeric(18,5),saldo numeric(18,5) ,tipoPagoFecha   int,diasVencidos    int,formaPago nvarchar(100),fechaFormaPago nvarchar(20))

	--DECLARE @aux               INT = 1
	--DECLARE @max               INT = 0
	--DECLARE @auxDos            INT = 1
	--DECLARE @maxSuc            INT = 0
	--DECLARE @idEmpresaBusca    INT = 0
	--DECLARE @ipServidorConcentradoras NVARCHAR(50) =NULL
	--DECLARE @nombreBase		   NVARCHAR(100) =NULL
	--DECLARE @nomBaseMatriz     NVARCHAR(100) =NULL
	--DECLARE @nomBaseConcentra  NVARCHAR(100) =NULL	
	--DECLARE @rfcEmisor		   NVARCHAR(50) =NULL
	--DECLARE @consulta   VARCHAR(max)=NULL;
	--DECLARE @consultaDos   VARCHAR(max)=NULL;
	--DECLARE @where      VARCHAR(max)=NULL;
	--DECLARE @nom_suc NVARCHAR(200) = ''
	--DECLARE @emp_nombre NVARCHAR(200) = ''
   
	--	SELECT @nomBaseConcentra = BASEMP.nombre_base
	--	FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
	--	INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
	--	WHERE emp.emp_idempresa = @idEmpresa
	--		  AND BASEMP.tipo = 2
	--	ORDER BY EMP.emp_idempresa

	--	SELECT	@rfcEmisor = rfc	
	--	FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP where tipo = 2 
	--			AND ISNULL(rfc,'') != '' AND emp_idempresa = @idEmpresa
	
	--	DECLARE @BDsuc TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(50), NombreBase VARCHAR(50),suc_idsucursal INT,suc_nombre VARCHAR(50))

	--	INSERT INTO @BDsuc
	--	SELECT EMP.emp_idempresa ,EMP.emp_nombre ,BASEMP.nombre_base ,BASEMP.suc_idsucursal ,sucursales.suc_nombre
	--	FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
	--	INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
	--	INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
	--	WHERE BASEMP.emp_idempresa = @idEmpresa
	--		  AND BASEMP.suc_idsucursal = COALESCE(@idSucursal, BASEMP.suc_idsucursal)  
	--		  AND BASEMP.tipo = 1

	--SET @maxSuc = (SELECT MAX(IDBD) FROM @BDsuc)

	--WHILE(@aux <= @maxSuc)
	--BEGIN
			
	--		SELECT	@nombreBase = NombreBase, @nom_suc = suc_nombre,@emp_nombre = emp_nombre ,@idSucursal = suc_idsucursal
	--				FROM @BDsuc WHERE IDBD = @aux
					
	--		SET @consulta =  'SELECT [CCP_IDPERSONA]' +
	--		                        ',Car_Externa.ccp_refer ' +
	--								 ','''+ @rfc + '''' +
	--								 ','''+ @rfcEmisor + '''' +
	--								 ', (select [referencias].[dbo].[fn_BuscaLetras](CCP_IDDOCTO)), (select [referencias].[dbo].[fn_BuscaNumeros](CCP_IDDOCTO))' +
	--								 ',' + CAST (@idEmpresa AS VARCHAR(2)) +' AS idEmpresa '
							
						   
	--		SET @consultaDos =      ','''+ @emp_nombre +  ''' AS empresa ' +
	--								',' + CAST (@idSucursal AS VARCHAR(2)) +' AS idSucursal' +
	--								',''' + @nom_suc + '''   AS sucursal  ' +
	--								',SUBSTRING(A.PAR_HORA1,4,2) AS idDepartamento  ' +
	--								',(SELECT [dep_nombre] FROM [ControlAplicaciones].[dbo].[cat_departamentos] WHERE [dep_iddepartamento] = SUBSTRING(A.PAR_HORA1,4,2))  AS departamento   ' +
	--								',ccp_cartera AS cartera ' +
	--								',CCP_IDDOCTO AS idDocto ' +
	--								',B.PAR_DESCRIP1 AS tipoDocto ' +
	--								',CONVERT(DATE, CCP_FECHVEN, 103) AS fechaVencimiento  ' +
	--								',CCP_FECHADOCTO  AS fechaUltimoPago   ' +
	--								',CCP_CARGO AS cargo ' +
	--								',(select isnull(sum(ccp_abono),0)  ' +
	--											'   from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' +
	--											'  where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  ' +
	--											'	and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  ' +
	--											'	and movimiento.ccp_cartera   = Car_Externa.ccp_cartera  ' +
	--											'	and movimiento.ccp_docori <> '+''''+'s'+''''+'     ' +
	--											'	and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+')    AS abono ' +
	--								',CCP_CARGO - (select isnull(sum(ccp_abono),0)    ' +
	--								'			   from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento  ' + 
	--								'			  where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto  ' +
	--								'				and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona  ' +
	--								'				and movimiento.ccp_cartera   = Car_Externa.ccp_cartera  ' +
	--								'				and movimiento.ccp_docori <> '+''''+'s'+''''+'    ' +
	--								'				and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+') AS saldo  ' +
	--								',CASE WHEN (SELECT DATEDIFF(day,(select top 1 CONVERT(DATE,movimiento.CCP_FECHADOCTO, 103)    ' +
	--																'	  from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento   ' + 
	--																'	 where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto   ' +
	--															'	   and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona   ' +
	--															'	   and movimiento.ccp_cartera   = Car_Externa.ccp_cartera   ' +
	--															'	   and movimiento.ccp_docori <> '+''''+'s'+''''+
	--															'	   and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+
	--															'	   and movimiento.CCP_ABONO > 0   ' +
	--															'	 order by CCP_FECHADOCTO asc   ' +
	--															'		),CONVERT(DATE,Car_Externa.CCP_FECHVEN, 103))) >= 0  THEN  1   ' +   
	--									'  WHEN  (SELECT DATEDIFF(day,(select top 1 CONVERT(DATE,movimiento.CCP_FECHADOCTO, 103) 
	--																	from ['+ @nomBaseConcentra +'].[dbo].[vis_concar01] as movimiento 
	--																	where movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto 
	--																	and movimiento.ccp_idpersona = Car_Externa.ccp_idpersona 
	--																	and movimiento.ccp_cartera   = Car_Externa.ccp_cartera 
	--																	and movimiento.ccp_docori <> '+''''+'s'+''''+' 
	--																	and movimiento.CCP_TIPODOCTO <> '+''''+'FACTURA'+''''+'
	--																	and movimiento.CCP_ABONO > 0
	--																	order by CCP_FECHADOCTO asc
	--																	),CONVERT(DATE,Car_Externa.CCP_FECHVEN, 103) )) < 0  THEN  2 
	--										ELSE 3											
	--									END  AS tipoPagoFecha  
	--									,''diasVencidos'' = CASE WHEN isdate(CCP_FECHVEN) = 1 
	--																		then DATEDIFF(DAY,CONVERT(DATETIME,CCP_FECHVEN,103),GETDATE()) 
	--																	else 0 
	--																	end
	--									,PN.PAR_DESCRIP3,vt.VTE_FECHOPE '
	
	--		   SET @where='	FROM['+ @nomBaseConcentra +'].[dbo].[VIS_CONCAR01]  AS Car_Externa 
	--						INNER JOIN ['+ @nomBaseConcentra +'].[dbo].[PNC_PARAMETR] As A ON CCP_CARTERA = A.PAR_IDENPARA 
	--						LEFT OUTER JOIN ['+ @nomBaseConcentra +'].[dbo].[PNC_PARAMETR] As B ON CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = ''TIMO''
	--						INNER JOIN [GA_Corporativa].[dbo].[PER_PERSONAS] ON CCP_IDPERSONA = PER_IDPERSONA AND  PER_RFC = '''+ @rfc+' ''
	--						LEFT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] Z ON Car_Externa.ccp_iddocto = Z.oce_folioorden COLLATE Modern_Spanish_CI_AS  
	--						INNER JOIN ['+ @nombreBase +'].[dbo].[ADE_VTAFI] vt on  vt.VTE_DOCTO = CCP_IDDOCTO
	--						INNER JOIN ['+ @nombreBase +'].[dbo].PNC_PARAMETR PN ON PN.PAR_IDENPARA = vt.VTE_FORMAPAGO AND PN.PAR_TIPOPARA = ''VNT'' 
	--						WHERE   A.PAR_TIPOPARA = ''CARTERA''  
	--								AND A.PAR_IDMODULO = ''CXC''   
	--								AND a.par_importe5 <> 1   
	--								AND B.PAR_DESCRIP1 = ''FACTURA''
	--								AND DATEDIFF (DAY,CONVERT(DATE, CCP_FECHVEN, 103),GETDATE()) >= 0'+
	--								' AND'+
	--								' CONVERT(DATE,CCP_FECHADOCTO,103) ' +
	--								' BETWEEN CONVERT(DATE,'
	--								+char(39)+@fechaInicial+char(39)+',103) AND CONVERT(DATE,'+char(39)+@fechaFin+char(39)+
	--								',103) AND SUBSTRING(CCP_IDDOCTO,1,2) IN(SELECT SUBSTRING(FCF_SERIE,1,2) FROM ['+ @nombreBase +'].[dbo].ADE_CFDFOLIOS)' 
		
	--	print @consulta + @consultaDos + @where


	--	INSERT INTO  @documentosPagados
	--	    EXECUTE (@consulta+@consultaDos + @where);
		

	--		SET @aux = @aux + 1
	--	END
		
	--	SELECT 
	--			 ID 
	--			 ,complemento as com
	--			,idCliente 
	--			,rfcReceptor
	--			,rfcEmisor
	--			,serie 
	--			,folio
	--			,idEmpresa 
	--			,empresa
	--			,idSucursal
	--			,sucursal
	--			,idDepartamento 
	--			,departamento 
	--			,cartera 
	--			,idDocto
	--			,tipoDocto
	--			,fechaVencimiento
	--			,fechaUltimoPago  
	--			,cargo
	--			,abono 
	--			,saldo
	--			,tipoPagoFecha 
	--			,diasVencidos
	--			,formaPago 
	--			,fechaFormaPago 
	--			,'MAA000005726' AS complemento
	--	FROM @documentosPagados ORDER BY fechaVencimiento ASC
END
go

