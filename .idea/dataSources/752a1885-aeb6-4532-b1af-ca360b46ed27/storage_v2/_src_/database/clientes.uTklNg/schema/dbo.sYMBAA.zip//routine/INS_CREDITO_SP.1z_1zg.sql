-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- INS_CREDITO_SP 266
CREATE PROCEDURE [dbo].[INS_CREDITO_SP] 
	 --CXC_CONDCARTERA
	 @idPertra INT = 0
	,@plazo NVARCHAR(10) = ''
	,@PorDescto INT = 0 
	,@CveUsu NVARCHAR(10) = 'GMI'
	,@Con_Ejecutivo NVARCHAR(50)=''
	,@Con_FormaPago NVARCHAR(50)=''
	,@Con_Auxiliar NVARCHAR(50)=''
	,@Con_Notas NVARCHAR(50)=''
	-- CXC_CONDCRED
	,@RUTACOBRADOR NVARCHAR(100) = 'DIRECTO'
	,@DIASREV  NVARCHAR(10) = '000010'
	,@HORAREVINI  NVARCHAR(100) = '00:0000:0000:0000:0009:0000:00'
	,@HORAREVFINAL  NVARCHAR(100) = '00:0000:0000:0000:0018:0000:00'
	,@DIASCOBRO  NVARCHAR(100) = '000010'
	,@HORACOBROINI  NVARCHAR(100) = '00:0000:0000:0000:0009:0000:00'
	,@HORACOBROFIN  NVARCHAR(100) = '00:0000:0000:0000:0018:0000:00'
	,@STACUENTA  NVARCHAR(100) = ''
	,@EMPRESA  NVARCHAR(100) = '01'
	,@FECHOPE   NVARCHAR(100) = ''
	,@RUTAORDEN  INT = 0
	,@estatus INT = 0
	,@CDC_PAIS NVARCHAR(10)=''
	,@CDC_ESTADO NVARCHAR(10)=''
	,@CDC_CIUDAD NVARCHAR(40)=''
	,@CDC_DELEGACION NVARCHAR(60)=''
	,@CDC_COLONIA NVARCHAR(150)=''
	,@CDC_NoINT NVARCHAR(10)=''
	,@CDC_NoEXT NVARCHAR(10)=''
	,@CDC_CODPOS NVARCHAR(5)=''
	,@CDC_CALLE NVARCHAR(40)=''
	,@CDC_CALLE2 NVARCHAR(40)=''
	,@CDC_CALLE3 NVARCHAR(40)=''
	,@CDC_CLASIFCLIENTE NVARCHAR(10)=''
	,@CDC_STACUENTA NVARCHAR(10)=''
	,@CDC_GIRO NVARCHAR(10)=''
	,@CDC_TIPOCTA NVARCHAR(10)=''
	,@CDC_DIAREVISION NVARCHAR(2)=''
	,@CDC_DIACOBRO NVARCHAR(2)=''
	,@result INT OUTPUT
AS
BEGIN
	BEGIN TRY

	DECLARE @consulta NVARCHAR(MAX), @nomBaseSuc  NVARCHAR(200) = '',@nomBaseConcentra  NVARCHAR(200) = '', @exite INT = 0, @PER_NOMRAZON  NVARCHAR(200) = '', @PER_PATERNO  NVARCHAR(200) = '', @PER_MATERNO NVARCHAR(200) = '', @PER_RFC NVARCHAR(200) = ''
	,@idEmpresa INT = 0, @monto NUMERIC(18,2),@montoTotal NUMERIC(18,2), @cartera  NVARCHAR(20) = '', @idCliente INT, @per_idpersona INT,@idSuc INT = 0,@dep  NVARCHAR(200) = ''


	DECLARE @carteras TABLE(id  INT IDENTITY(1,1),cartera NVARCHAR(20),monto DECIMAL(18,0))

	INSERT INTO @carteras
	SELECT cartera, monto FROM [clientes].[dbo].[DestinoMontoSucursal] 
	WHERE id_SolicitudMonto IN (SELECT ID FROM [clientes].[dbo].[SolicitudMonto] WHERE tramites_Id = @idPertra)

	DECLARE @tot  INT = 0, @aux INT = 1
	SET @tot = (SELECT COUNT(id) FROM @carteras)



	SELECT @idCliente =  [idCliente], @idEmpresa = [idEmpresa],@idSuc = idSucursal , @montoTotal = monto, @dep = descripcion , @estatus = estatus FROM [clientes].[dbo].[TramiteCliente] WHERE [tramites_Id] = @idPertra
	SELECT @per_idpersona = [per_idpersona] FROM [clientes].[dbo].[Cliente] WHERE [idCliente] =  @idCliente
	SELECT @nomBaseConcentra = nombre_base FROM Centralizacionv2..DIG_CAT_BASES_BPRO   WHERE emp_idempresa = @idEmpresa AND tipo = 2
	SELECT @nomBaseSuc = nombre_base FROM Centralizacionv2..DIG_CAT_BASES_BPRO  WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSuc AND tipo = 1
	SELECT @plazo = observacion FROM [clientes].[dbo].[docCycTramite] WHERE id_docCyc = 1 AND id_perTra = @idPertra

	SELECT @PER_NOMRAZON = PER_NOMRAZON, @PER_PATERNO =  PER_PATERNO , @PER_MATERNO = PER_MATERNO , @PER_RFC =  PER_RFC FROM  GA_Corporativa.dbo.PER_PERSONAS WHERE PER_IDPERSONA = @per_idpersona



				WHILE(@aux <= @tot )
				BEGIN

				SELECT @cartera  = cartera , @monto = monto FROM @carteras WHERE id = @aux


						SET @consulta = '	
						IF NOT EXISTS(SELECT Con_IdPersona FROM '+ @nomBaseConcentra +'.DBO.CXC_CONDCARTERA WHERE Con_IdPersona ='+ CONVERT(NVARCHAR(20),@per_idpersona) +' AND Con_ClaveCartera = '''+ @cartera +''' )
						BEGIN
							INSERT INTO '+ @nomBaseConcentra +'.DBO.CXC_CONDCARTERA (Con_ClaveCartera, Con_IdPersona , Con_LimCredito , Con_Plazo ,Con_Ejecutivo , Con_PorDescto ,Con_FormaPago ,Con_Auxiliar ,Con_Notas ,Con_CveUsu , Con_Fechope ) 
																			 VALUES ('''+ @cartera +''' , '+CONVERT(NVARCHAR(20), @per_idpersona) +','+ CONVERT(NVARCHAR(20),@monto) +' , '''+ @plazo +''' ,''' + @Con_Ejecutivo + ''' ,'+ CONVERT(NVARCHAR(20),@PorDescto) +','''+ @Con_FormaPago +''' ,'''+@Con_Auxiliar+''','''+@Con_Notas+''',''' + @CveUsu + ''', (SELECT CONVERT(varchar, getdate(), 103)) )

		
							INSERT INTO '+ @nomBaseConcentra +'.[dbo].[CXC_CONDCRED] ( CDC_IdPERSONA , CDC_RUTACOBRADOR , CDC_PAIS ,  CDC_ESTADO ,   CDC_CIUDAD   , CDC_DELEGACION ,   CDC_COLONIA ,  CDC_NoINT ,   CDC_NoEXT ,  CDC_CODPOS , CDC_CALLE , CDC_CALLE2 , CDC_CALLE3 ,   CDC_DIASREV , CDC_HORAREVINI , CDC_HORAREVFINAL , CDC_DIASCOBRO ,    CDC_HORACOBROINI ,   CDC_HORACOBROFIN  , CDC_CLASIFCLIENTE, CDC_STACUENTA,    CDC_GIRO ,     CDC_TIPOCTA   ,  CDC_EMPRESA , CDC_CVEUSU , CDC_FECHOPE  , CDC_DIAREVISION, CDC_DIACOBRO, CDC_RFC , CDC_PATERNO , CDC_MATERNO ,CDC_NOMRAZON , CDC_RUTAORDEN )
																	  VALUES ( '+CONVERT(NVARCHAR(20), @per_idpersona) +','''+ @RUTACOBRADOR +''',  '''+@CDC_PAIS +''' , '''+@CDC_ESTADO +''' ,  '''+@CDC_CIUDAD +''' ,  '''+@CDC_DELEGACION +''' ,  '''+@CDC_PAIS +''' ,  '''+@CDC_COLONIA +''' ,  '''+@CDC_NoEXT +''' ,  '''+@CDC_CODPOS +''' , '''+@CDC_CALLE +''' , '''+@CDC_CALLE2 +''' ,  '''+@CDC_CALLE3 +''' , '''+ @DIASREV +''','''+@HORAREVINI+''','''+@HORAREVFINAL+''','''+@DIASCOBRO+''','''+@HORACOBROINI+''','''+@HORACOBROFIN+''', '''+@CDC_CLASIFCLIENTE+''','''+@CDC_STACUENTA+''','''+@CDC_GIRO+''','''+@CDC_TIPOCTA+''', '''+@EMPRESA+''','''+@CveUsu+''',(SELECT CONVERT(varchar, getdate(), 103)),'''+@CDC_DIAREVISION+''','''+@CDC_DIACOBRO+''','''+@PER_RFC+''','''+@PER_PATERNO+''','''+@PER_MATERNO+''','''+@PER_NOMRAZON+''',  '+ CONVERT(NVARCHAR(20), @RUTAORDEN ) + ' )
						END
						ELSE
						BEGIN
							 UPDATE '+ @nomBaseConcentra +'.DBO.CXC_CONDCARTERA SET  Con_LimCredito = '+CONVERT(NVARCHAR(20), @monto ) + ' + (SELECT Con_LimCredito FROM '+ @nomBaseConcentra +'.DBO.CXC_CONDCARTERA WHERE Con_IdPersona ='+ CONVERT(NVARCHAR(20),@per_idpersona) +' AND Con_ClaveCartera = '''+ @cartera +''') ,Con_Plazo =  '''+ @plazo +'''   WHERE Con_IdPersona ='+CONVERT(NVARCHAR(20), @per_idpersona )+' AND Con_ClaveCartera = '''+ @cartera +'''
						END
	
						IF NOT EXISTS(SELECT ROL_IDPERSONA  FROM ['+ @nomBaseSuc +'].[dbo].[PER_ROLES] WHERE ROL_ROL=''CRE'' AND  ROL_IDPERSONA = '+CONVERT(NVARCHAR(20), @per_idpersona) +' )
						BEGIN

							INSERT INTO   ['+ @nomBaseSuc +'].[dbo].[PER_ROLES]
							SELECT '+CONVERT(NVARCHAR(20), @per_idpersona) +',''CRE'',''GMI'',(SELECT CONVERT(varchar, getdate(), 103)),'' '',1

						END
						'
	
				--PRINT(@consulta)
				EXECUTE (@consulta)

	
				SET @aux = @aux + 1
				END

				INSERT INTO [clientes].[dbo].[NotificacionCliente] VALUES ('Resolución tramite #'+ CONVERT(NVARCHAR(10), @idPertra),'La solicitud de Crédito fue aprobada con exito para el departamento de ' + @dep + ' por un monto de $' + CONVERT(NVARCHAR(20), @montoTotal),0,GETDATE(),'',@idCliente)
								
				UPDATE [clientes].[dbo].[ProcesoTramite] SET hrFin = GETDATE() WHERE id_perTra = @idPertra AND estatus = @estatus 
				INSERT INTO [clientes].[dbo].[ProcesoTramite] VALUES (@idPertra , 7,GETDATE(),GETDATE())

				UPDATE  [clientes].[dbo].[TramiteCliente] 
				SET observacion = 'Aprobado', estatus = 7, fecha = GETDATE()
				WHERE tramites_Id = @idPertra

				-- SELECT * FROM [clientes].[dbo].[CreditosAutorizados] 
				IF NOT EXISTS (SELECT id FROM [clientes].[dbo].[CreditosAutorizados] WHERE idPertra = @idPertra)
				BEGIN
					INSERT INTO  [clientes].[dbo].[CreditosAutorizados] 
					VALUES (@idPertra, @montoTotal, @montoTotal, 1,GETDATE() ,1)
				END
				ELSE
				BEGIN
					UPDATE [clientes].[dbo].[CreditosAutorizados] 
					SET estatus = 1
					WHERE idPertra = @idPertra
				END


	SET  @result = 1
	RETURN @result
END TRY
BEGIN CATCH
	SET  @result = 0
	RETURN @result
END CATCH
END
go

