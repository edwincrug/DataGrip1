-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PERSONA_ROL_CLIENTE_SP] 
	@idCliente INT = 0
AS
BEGIN

		--SELECT EMP.emp_idempresa AS idEmpresa
		--	  ,ME.marca    AS nombre
		--FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] BASEMP
		--INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON  BASEMP.emp_idempresa = EMP.emp_idempresa
		--INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  EMP.emp_idempresa
		--WHERE tipo  = 2

	   DECLARE  @nom_emp NVARCHAR(100) = '',@idEmpresa INT = 0, @ipServidor VARCHAR(20)='', @per_idpersona INT = 0
	   DECLARE @aux INT= 1, @max INT = 0,@aux2 INT= 1, @max2 INT = 0
	   DECLARE @BDs TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(200))
	   DECLARE @BDsuc TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(200), NombreBase VARCHAR(50))
	   DECLARE @empresas TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(200))

	    SELECT @per_idpersona = per_idpersona FROM [clientes].[dbo].Cliente WHERE idCliente = @idCliente

	   INSERT INTO @BDs
	   SELECT EMP.emp_idempresa ,EMP.emp_nombre 
	   FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
	   INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
	   WHERE BASEMP.tipo = 2
	   AND BASEMP.emp_idempresa  IN (1,4,5)

	   SELECT @max = MAX(IDBD) FROM @BDs

		WHILE(@aux <= @max)
			BEGIN	
									
				
				
				SELECT	 @idEmpresa = emp_idempresa  ,@nom_emp = emp_nombre FROM @BDs WHERE IDBD = @aux

				INSERT INTO @BDsuc
				SELECT EMP.emp_idempresa ,EMP.emp_nombre ,BASEMP.nombre_base 
				FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
				INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
				WHERE BASEMP.tipo = 1
				AND BASEMP.emp_idempresa = @idEmpresa
				AND BASEMP.suc_idsucursal NOT IN (7,8,11)


				 SELECT @max2 = MAX(IDBD) FROM @BDsuc

				WHILE(@aux2 <= @max2)
					BEGIN
					DECLARE @tipo NVARCHAR(20) = ''
					DECLARE @nombreBase VARCHAR(50) = ''
					DECLARE @passEnc VARCHAR(100) = ''
					DECLARE @passDecry  VARCHAR(50) = ''
					DECLARE @SQLString NVARCHAR(500) = ''
					DECLARE @ParmDefinition NVARCHAR(500) = ''

					SELECT	@nombreBase = NombreBase FROM @BDsuc WHERE IDBD = @aux2
							
					SET @SQLString =N'SELECT   @passD = ROL_IDPERSONA FROM ['+ @nombreBase +'].[dbo].[PER_ROLES] WHERE ROL_ROL=''CRE'' AND  ROL_IDPERSONA = ' + CONVERT(NVARCHAR(10),@per_idpersona)    
					SET @ParmDefinition = N' @passD varchar(MAX) OUTPUT';        
					EXECUTE sp_executesql @SQLString, @ParmDefinition, @passD = @passDecry OUTPUT;
			
					PRINT @SQLString
					SET @aux2 = @aux2 + 1

					IF(@passDecry > 0)
					BEGIN 
						SET @tipo = 'CRE'
						SET @aux2 = @max2 + 1 
					END
						
				 END	
				 
				IF( @tipo = 'CRE')
				BEGIN
					INSERT INTO @empresas
					SELECT @idEmpresa, @nom_emp
				END

				SET @aux = @aux + 1	
		END

		SELECT   E.emp_idempresa AS idEmpresa ,ME.marca AS nombre FROM @empresas E
		INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  E.emp_idempresa
END
go

