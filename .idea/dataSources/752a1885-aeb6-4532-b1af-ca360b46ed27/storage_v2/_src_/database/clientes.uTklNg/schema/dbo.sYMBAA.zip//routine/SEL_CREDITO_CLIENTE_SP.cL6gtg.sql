-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- SEL_CREDITO_CLIENTE_SP 79672, 4 ,6
CREATE PROCEDURE [dbo].[SEL_CREDITO_CLIENTE_SP]
	 @idCliente INT = 0
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
AS
BEGIN

	DECLARE @consulta NVARCHAR(MAX), @nomBaseConcentra  NVARCHAR(200) = ''	
	DECLARE @cretidos TABLE (id INT IDENTITY(1,1),clave NVARCHAR(30),cartera NVARCHAR(200),limiteCredito NUMERIC(18,2))
		
	SELECT @nomBaseConcentra = nombre_base
	FROM Centralizacionv2..DIG_CAT_BASES_BPRO  
	WHERE emp_idempresa = @idEmpresa
	AND tipo = 2

	

	SET @consulta = 'SELECT  
							 CART.Con_ClaveCartera AS clave
							,SUBSTRING(PARM.PAR_DESCRIP1,    CHARINDEX(''. -'',PARM.PAR_DESCRIP1) + 3    ,LEN(PARM.PAR_DESCRIP1))
							,CART.Con_LimCredito  
					 FROM ' + @nomBaseConcentra + '.dbo.cxc_condcartera  CART
					 INNER JOIN	  ' + @nomBaseConcentra + '.[dbo].PNC_PARAMETR PARM ON PARM.PAR_IDENPARA = CART.Con_ClaveCartera
					 WHERE Con_IdPersona  =  ' + CONVERT(NVARCHAR(20), @idCliente) +
					 ' AND PARM.PAR_DESCRIP1 NOT IN(SELECT cartera_descripcion  COLLATE Modern_Spanish_CI_AS FROM [clientes].[dbo].[Cat_CarteraDiscriminar] WHERE  idEmpresa = '+ CONVERT(NVARCHAR(10),@idEmpresa) +'  AND idSucursal = '+ CONVERT(NVARCHAR(10), @idSucursal) +' )' +
					 ' AND  PARM.PAR_TIPOPARA = ''CARTERA'' AND PARM.PAR_IDMODULO = ''CXC'''

	PRINT(@Consulta)
	INSERT INTO @cretidos
	EXECUTE(@Consulta)
	
	SELECT clave , cartera , limiteCredito FROM @cretidos

END
go

