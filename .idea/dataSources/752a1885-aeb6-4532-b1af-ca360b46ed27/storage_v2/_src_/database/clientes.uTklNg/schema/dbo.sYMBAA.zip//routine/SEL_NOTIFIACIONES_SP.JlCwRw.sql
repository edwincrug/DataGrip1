-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_NOTIFIACIONES_SP]
	@idCliente INT = 0
AS
BEGIN
	SELECT idNotificacion, titulo, descripcion,  convert(varchar,fechaCreacion, 100) as fecha 
		FROM NotificacionCliente WHERE idCliente = @idCliente 
		ORDER BY idNotificacion DESC
END
go

