-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [dbo].[SEL_EMPRESAS_SP] 72
CREATE PROCEDURE [dbo].[SEL_EMPRESAS_SP] 
	@idCliente INT = 0
AS
BEGIN

		SELECT EMP.emp_idempresa AS idEmpresa
			  ,ME.marca    AS nombre
		FROM [Centralizacionv2].[dbo].[DIG_CAT_BASES_BPRO] BASEMP
		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON  BASEMP.emp_idempresa = EMP.emp_idempresa
		INNER JOIN [clientes].[dbo].[Cat_MarcaEmpresa] ME ON ME.emp_idempresa =  EMP.emp_idempresa
		WHERE tipo  = 2
END
go

