-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- TEST SEL_TOKEN_APP_MOVIL_SP 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TOKEN_APP_MOVIL_API_SP]
AS
BEGIN

	SET NOCOUNT ON;

	SELECT 
		valor AS token
	FROM [dbo].[Parametros] WHERE nombre = 'TOKEN_APPMOVIL'
END

SELECT 
		*
	FROM [dbo].[Parametros] WHERE nombre = 'TOKEN_APPMOVIL'
go

