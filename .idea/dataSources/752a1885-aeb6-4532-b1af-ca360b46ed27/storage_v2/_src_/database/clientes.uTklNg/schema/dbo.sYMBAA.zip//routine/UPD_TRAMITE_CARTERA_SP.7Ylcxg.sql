-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE UPD_TRAMITE_CARTERA_SP
	 @id_PerTra INT = 0
	,@cartera NVARCHAR(10)
	,@descripcion NVARCHAR(300)
AS
BEGIN
			UPDATE [clientes].[dbo].TramiteCliente SET cartera = @cartera , descripcion = @descripcion
			WHERE tramites_Id = @id_PerTra
END
go

