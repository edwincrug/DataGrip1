-- =============================================
-- Author:		<Author>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FACTURAS_POR_PAGAR_SP] --SEL_FACTURAS_POR_PAGAR_SP @idCliente = 26
	@idCliente NUMERIC(18,0) = 0
AS
BEGIN
	-----------BEGIN Dependiendo del idCliente busca su rfc------------------------------------
	DECLARE @rfcCliente VARCHAR(15) = ''
	SELECT @rfcCliente = rfcCliente FROM Cliente WHERE idCliente = @idCliente
-----------END Dependiendo del idCliente busca su rfc--------------------------------------	
	
	-----------BEGIN Se crea tabla para insertar los resulados de cada base de datos-----------
	DECLARE @Facturas TABLE(ID INT IDENTITY(1,1),
							idCliente NUMERIC(18,0),
							serie VARCHAR(50),
							folio VARCHAR(50),
							descripcion VARCHAR(MAX),
							fechadoc VARCHAR(50),
							--fechaEmision VARCHAR(50),
							fechaVencimiento VARCHAR(50),
							diasCartera NUMERIC(18,0),
							estatus VARCHAR(50),
							importe decimal(18, 5),
							saldo decimal(18, 5),
							idEmpresa NUMERIC(18,0),
							idSucursal NUMERIC(18,0),
							departamento VARCHAR(50),
							--Anio VARCHAR(50),
							--Mes VARCHAR(50),
							rfcEmisor VARCHAR(50),
							rfcReceptor VARCHAR(50),
							suc_nombre VARCHAR(50),
							emp_nombre VARCHAR(50),
							idDepartamento NUMERIC(18,0),
							pedidos VARCHAR(50),
							cotizacion VARCHAR(50),
							emp_idPersona NUMERIC(18,0)
							)
	-----------END Se crea tabla para insertar los resulados de cada base de datos-------------
	-----------BEGIN Se crea tabla para guardar las Bases de datos-----------------------------
	DECLARE @BDs TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(50),
					   emp_nombrecto VARCHAR(10), NombreBase VARCHAR(50), ipServidor VARCHAR(20),suc_idsucursal INT,suc_nombre VARCHAR(50))
	INSERT INTO @BDs
	SELECT 
				 EMP.emp_idempresa
                ,EMP.emp_nombre
                ,EMP.emp_nombrecto
                ,BASEMP.nombre_base
				,BASEMP.ip_servidor
				,BASEMP.suc_idsucursal
				,sucursales.suc_nombre
           FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
                INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				inner join [ControlAplicaciones].[dbo].[cat_sucursales] sucursales on BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
          WHERE  BASEMP.estatus = 1 AND BASEMP.tipo = 1 and sucursales.emp_idempresa= EMP.emp_idempresa AND BASEMP.nombre_sucursal != 'CRA Guadalajara' AND BASEMP.nombre_sucursal !='CRA Cuautitlan'
				--AND EMP.emp_idempresa not in (7)--Quitar despues
				AND EMP.emp_idempresa  in (4) -- Solo pruebas
				
       ORDER BY sucursales.suc_idsucursal
	--SELECT * FROM  @BDs
	-----------END Se crea tabla para guardar las Bases de datos-----------------------------
	-----------BEGIN Se realiza la busqueda de las facturas del cliente dinamicamente----------	
	DECLARE @aux INT= 1, @max INT = 0,@rowcnt INT = 0
	DECLARE @nombreBase VARCHAR(50) = '', @cadena NVARCHAR(MAX) = '', @idEmpresa NVARCHAR(10) = '', @idSucursal NVARCHAR(10) = '', @nom_suc NVARCHAR(30) = '',@nom_emp NVARCHAR(100) = ''
	DECLARE @tabla TABLE(Con_LimCredito DECIMAL(18,2), NOMBRE_AGENCIA VARCHAR(100))
	DECLARE @total TABLE(total INT)
	DECLARE @rfcEmisor VARCHAR(50)=''
	DECLARE @ipServidor VARCHAR(20)=''
	SELECT @max = MAX(IDBD) FROM @BDs

		WHILE(@aux <= @max)
			BEGIN			
				SELECT	@nombreBase = NombreBase
						,@idEmpresa= emp_idempresa
						,@idSucursal= suc_idsucursal
						,@nom_suc= suc_nombre
						,@nom_emp= emp_nombre
						,@ipServidor= ipServidor
						 FROM @BDs WHERE IDBD = @aux
				-----------BEGIN Se busca el rfc del Emisor es decir de la empresa-----------------------
				SELECT	 @rfcEmisor= rfc	
					 FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP where tipo=2 
					 AND ISNULL(rfc,'') != '' AND emp_idempresa=@idEmpresa
				-----------END Se busca el rfc del Emisor es decir de la empresa-------------------------				
				SELECT @idSucursal= suc_idsucursal FROM @BDs WHERE IDBD = @aux
				
				SET @cadena=	'SELECT '+CAST(@idCliente AS VARCHAR(10))+',(select [referencias].[dbo].[fn_BuscaLetras](CCP_IDDOCTO)),'+
								'(select [referencias].[dbo].[fn_BuscaNumeros](CCP_IDDOCTO)),'+
								'[DES_CARTERA],'+
								'[CCP_FECHADOCTO],'+
								--'[FECHAVENCIDO],'+
								'[FECHAVENCIDO],'+
								'[DIASVENCIDOS],'+
								'CASE'+
									' WHEN DIASVENCIDOS <=0 THEN '+char(39)+'Por Vencer'+char(39)+
									'ELSE '+char(39)+'Vencido'+char(39)+
								'END'+char(39)+'estatus'+char(39)+
								',[IMPORTE],'+
								'[SALDO],'+
								@idEmpresa+
								','+@idSucursal+
								',[OrigenMovimiento],'+
								char(39)+@rfcEmisor+char(39)+
								',[PER_RFC],'+
								char(39)+@nom_suc+char(39)+
								','+char(39)+@nom_emp+char(39)+
								',(select dep_iddepartamento from [ControlAplicaciones].[dbo].[cat_departamentos] where emp_idempresa = '+@idEmpresa+' and suc_idsucursal = '+@idSucursal+' ' + char(13) + 
								'and  dep_nombrecto = ' + char(13) + 
								'(select case when OrigenMovimiento = '+char(39)+'NUEVOS'+char(39)+' THEN '+char(39)+'UN'+char(39)+' ' + char(13) + 
								'when OrigenMovimiento = '+char(39)+'SEMINUEVOS'+char(39)+' THEN '+char(39)+'US'+char(39)+'' + char(13) + 
								'when OrigenMovimiento = '+char(39)+'REFACCIONES'+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
								'when OrigenMovimiento = '+char(39)+'SERVICIO '+char(39)+' THEN '+char(39)+'SE'+char(39)+'' + char(13) + 
								'when OrigenMovimiento = '+char(39)+'NEGOCIOS '+char(39)+' THEN '+char(39)+'RE'+char(39)+'' + char(13) + 
								'when OrigenMovimiento = '+char(39)+'HOJALATERIA Y PINTURA '+char(39)+' THEN '+char(39)+'SE'+char(39)+'end))'+
								', CASE WHEN SUBSTRING(CCP_IDDOCTO, 1, 1) IN ('+char(39)+'A'+char(39)+','+char(39)+'B'+char(39)+','+char(39)+'D'+char(39)+') THEN (SELECT VTE_REFERENCIA1 FROM ['+@ipServidor+'].['+@nombreBase+'].[DBO].[ADE_VTAFI] WHERE VTE_DOCTO = CCP_IDDOCTO)'+
								'WHEN SUBSTRING(CCP_IDDOCTO, 1, 1)='+char(39)+'F'+char(39)+' THEN (SELECT PMM_REF2 FROM ['+@ipServidor+'].['+@nombreBase+'].[DBO].[PAR_PEDMOST] WHERE PMM_REF2 = CCP_IDDOCTO AND PMM_COTPED = '+char(39)+'PEDIDO'+char(39)+')'+
								'ELSE '+CHAR(39)+'No identificado'+CHAR(39)+
								'END '+
								', CASE WHEN SUBSTRING(CCP_IDDOCTO, 1, 1)='+char(39)+'A'+char(39)+' THEN (SELECT PMM_REF2 FROM ['+@ipServidor+'].['+@nombreBase+'].[DBO].[PAR_PEDMOST] WHERE PMM_REF2 = CCP_IDDOCTO AND PMM_COTPED = '+char(39)+'PEDIDO'+char(39)+')'+
								' WHEN SUBSTRING(CCP_IDDOCTO, 1, 1)= '+char(39)+'D'+char(39)+' THEN '+CHAR(39)+'SIN COTIZACIÓN'+CHAR(39)+
								' WHEN SUBSTRING(CCP_IDDOCTO, 1, 1)= '+char(39)+'B'+char(39)+' THEN '+CHAR(39)+'PENDIENTE'+CHAR(39)+
								'ELSE '+CHAR(39)+'No identificado'+CHAR(39)+
								'END '+
								',[CCP_IDPERSONA]'+
								' FROM ['+@ipServidor+'].['+@nombreBase+'].[DBO].[BI_CARTERA_CLIENTES] '  + 
								'WHERE DES_TIPODOCTO = '+char(39)+'FACTURA'+char(39)+' AND SUBSTRING(CCP_IDDOCTO,1,2) ' + char(13) + 
								'IN(SELECT SUBSTRING(FCF_SERIE,1,2)' + char(13) + 
								'FROM ['+@ipServidor+'].['+@nombreBase+'].[DBO].[ADE_CFDFOLIOS]) AND OrigenMovimiento IN ('+char(39)+'NUEVOS'+char(39)+','+char(39)+'SEMINUEVOS'+char(39)+','+char(39)+'REFACCIONES'+char(39)+','+char(39)+'SERVICIO'+char(39)+','+char(39)+'HOJALATERIA Y PINTURA'+char(39)+') ' + char(13) + 
								'and PER_RFC = ''' + @rfcCliente + '''' 
				set @aux = @aux + 1				
				INSERT INTO @Facturas
				EXECUTE (@cadena)	
				PRINT (@cadena)				
	-----------BEGIN Se realiza la busqueda de las facturas del cliente dinamicamente----------				
			END	
	
	select * from  @Facturas --order by diasCartera DESC

END

go

