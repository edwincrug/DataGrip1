-- =============================================
-- Author:      Aldo Ortiz
-- Create date: 29/05/2020
-- Description:	Sucursales disponibles para pago por Mail Order y Bancomer
-- =============================================
-- EXEC SEL_SUCURSALES_MAIL_ORDER_BANCOMER_SP
CREATE PROCEDURE [dbo].[SEL_SUCURSALES_MAIL_ORDER_BANCOMER_SP]
AS
BEGIN
    SELECT 
        [idEmpresa], 
        [idSucursal] 
    FROM referencias.[dbo].[Cat_DivisionOrg_BBVA]
END
go

