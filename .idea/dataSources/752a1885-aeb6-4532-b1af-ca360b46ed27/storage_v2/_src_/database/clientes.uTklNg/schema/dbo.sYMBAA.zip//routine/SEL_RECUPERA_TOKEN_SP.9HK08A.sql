-- ==========================================================================================
-- Author:		Lourdes Maldonado Sanchez.
-- Create date: 10/08/2018
-- Description:	Recupera el Token de un Cliente
-- ==========================================================================================
-- EXECUTE [SEL_RECUPERA_TOKEN_SP] 'DICJ830423FK1'
CREATE PROCEDURE [dbo].[SEL_RECUPERA_TOKEN_SP] 
	@rfc VARCHAR(13) = ''
AS
BEGIN
	SET NOCOUNT ON;
BEGIN TRY
	
	 SELECT TOP 1 token,idCorreoActivacion,per_rfc,fechaCreacion,fechaActivacion,idEstatus
	   FROM [clientes].[dbo].[CorreoActivacion]
	  WHERE [per_rfc] = @rfc
   ORDER BY [fechaCreacion] DESC

END TRY
BEGIN CATCH
	Print('Se presento el error: ' + ERROR_MESSAGE())
	DECLARE @Mensaje  nvarchar(max),
	@Componente nvarchar(50) = 'SEL_RECUPERA_TOKEN_SP'
	SELECT @Mensaje = ERROR_MESSAGE()
END CATCH
END
go

