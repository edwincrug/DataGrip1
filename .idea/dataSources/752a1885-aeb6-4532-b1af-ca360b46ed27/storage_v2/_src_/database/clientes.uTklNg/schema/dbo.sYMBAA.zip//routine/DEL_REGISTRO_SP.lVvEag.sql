-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[DEL_REGISTRO_SP] 
	@idCliente INT = 0
AS
BEGIN

	DECLARE @msg VARCHAR(500) = 'Registro no disponible intentelo mas tarde', @estatus VARCHAR(10) = 'error'
	DELETE FROM Usuario WHERE idCliente = @idCliente
	DELETE FROM Log_Clientes WHERE idCliente = @idCliente
	DELETE FROM UsuarioCorreo WHERE idCliente = @idCliente
	DELETE FROM Cliente WHERE idCliente = @idCliente
	
	SELECT @estatus estatus,@msg mensaje
END
go

