-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	[dbo].[SEL_CARTERAS_SUC_SP]  4,6
CREATE PROCEDURE [dbo].[SEL_CARTERAS_SUC_SP]  
	 @idEmpresa int = 0
	,@idSucursal int = 0
AS
BEGIN
		DECLARE @consecutivo_contable INT = 0, @consulta NVARCHAR(MAX) = '',  @nomBaseConcentra  NVARCHAR(100) = '',@discrimina NVARCHAR(MAX) = ''
		SELECT @consecutivo_contable = consecutivo_contable  FROM Centralizacionv2.dbo.DIG_CAT_BASES_BPRO WHERE emp_idempresa = @idEmpresa AND suc_idsucursal = @idSucursal

		SELECT @nomBaseConcentra = BASEMP.nombre_base
		FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
		WHERE emp.emp_idempresa = @idEmpresa
			  AND BASEMP.tipo = 2
	
	
		DECLARE @tabla TABLE (id int identity(1,1),PAR_IDENPARA NVARCHAR(10),PAR_DESCRIP1 NVARCHAR(300))
		SET @consulta = 'SELECT PAR_IDENPARA , PAR_DESCRIP1
		FROM '+ @nomBaseConcentra +'.dbo.PNC_PARAMETR
		WHERE PAR_TIPOPARA = ''CARTERA''
		AND PAR_HORA1 NOT IN ('''')
		AND PAR_DESCRIP1 like ''1100-0030-000'+ CONVERT(NVARCHAR(10),@consecutivo_contable) +'%''
		AND PAR_DESCRIP1 NOT IN(SELECT cartera_descripcion  COLLATE Modern_Spanish_CI_AS FROM [clientes].[dbo].[Cat_CarteraDiscriminar] WHERE  idEmpresa = '+ CONVERT(NVARCHAR(10),@idEmpresa) +'  AND idSucursal = '+ CONVERT(NVARCHAR(10), @idSucursal) +' )
		ORDER BY PAR_HORA1'

		INSERT INTO @tabla
		EXECUTE(@consulta)

		SELECT id, PAR_IDENPARA ,PAR_DESCRIP1 FROM @tabla
		
END
go

