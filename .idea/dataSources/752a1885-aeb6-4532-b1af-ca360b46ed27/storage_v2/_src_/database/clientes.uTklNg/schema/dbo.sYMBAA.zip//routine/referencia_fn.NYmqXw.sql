-- =============================================
-- Author:		ALEJANDRO LOPEZ
-- Create date: 27052016
-- Description:	genera y regresa referencia bancaria
-- =============================================
CREATE FUNCTION [dbo].[referencia_fn]
(	
	@serie VARCHAR(3),
	@factura VARCHAR(6),
	@consecutivo TINYINT = 0
)
RETURNS VARCHAR(19)
AS
BEGIN	

	DECLARE @referencia VARCHAR(19) = '' 
	SET @serie = REPLICATE('0',3-LEN(@serie)) + @serie
	SET @factura = REPLICATE('0',6-LEN(@factura)) + CONVERT(VARCHAR(6),@factura)	
		
	SELECT  @referencia =
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(MM,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(MM,GETDATE())) + 
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(DD,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(DD,GETDATE())) +
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE())) +
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())))) + CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())) +
		 REPLICATE('0',2-LEN(CONVERT(VARCHAR(2),CONVERT(VARCHAR(2),@consecutivo)))) + CONVERT(VARCHAR(2),@consecutivo) + 
		 @serie + @factura
	
	RETURN @referencia
END

go

