-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_NOTIFIACIONES_CLIENTES_SP]
	@idCliente INT = 0
AS
BEGIN

		SELECT   [idNotificacion]
				,[titulo]
				,[descripcion]
				,[visto]
				,[fechaCreacion]
				,[fechaRevision]
				,[idCliente]
		FROM [clientes].[dbo].[NotificacionCliente]
		WHERE [idCliente] = @idCliente
		AND [visto] = 0
END
go

