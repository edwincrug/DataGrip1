-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--	SEL_DETALLE_CREDITO 79672,4,6,'Z3'
CREATE PROCEDURE [dbo].[SEL_DETALLE_CREDITO] 
	 @idCliente INT = 0
	,@idEmpresa INT = 0
	,@idSucursal INT = 0
	,@cartera NVARCHAR(20)
AS
BEGIN


	   DECLARE @BDs TABLE(IDBD INT IDENTITY(1,1) PRIMARY KEY, emp_idempresa INT, emp_nombre VARCHAR(200), NombreBase VARCHAR(50),suc_idsucursal INT,suc_nombre VARCHAR(50))
	  
	   DECLARE @nombreBase VARCHAR(50) = '', @cadena NVARCHAR(MAX) = '', @nom_suc NVARCHAR(200) = '', @nom_emp NVARCHAR(100) = '',--  @idSucursal NVARCHAR(10) = '',
	   @rfcEmisor VARCHAR(50)='', @ipServidor VARCHAR(20)='', @rfcCliente VARCHAR(15) = ''
	   
	   DECLARE @aux INT= 1, @max INT = 0

	   --DECLARE @Facturas TABLE( ID INT IDENTITY(1,1),idCliente NUMERIC(18,0),serie VARCHAR(50),folio VARCHAR(50)
	   --,descripcion VARCHAR(MAX),fechadoc VARCHAR(50),fechaVencimiento VARCHAR(50),diasCartera NUMERIC(18,0),estatus VARCHAR(50),importe decimal(18, 5),
				--saldo decimal(18, 5),idEmpresa NUMERIC(18,0),idSucursal NUMERIC(18,0),departamento VARCHAR(50),rfcEmisor VARCHAR(50),rfcReceptor VARCHAR(50),suc_nombre VARCHAR(50),emp_nombre VARCHAR(50),idDepartamento NUMERIC(18,0),pedidos VARCHAR(50),cotizacion VARCHAR(50),emp_idPersona NUMERIC(18,0))

		DECLARE @Facturas TABLE( ID INT IDENTITY(1,1),saldo NUMERIC(18,0))


	   INSERT INTO @BDs
	   SELECT EMP.emp_idempresa ,EMP.emp_nombre ,BASEMP.nombre_base ,BASEMP.suc_idsucursal ,sucursales.suc_nombre
	   FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
	   INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.emp_idempresa = EMP.emp_idempresa
       INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.suc_idsucursal = sucursales.suc_idsucursal
	   WHERE  BASEMP.emp_idempresa = @idEmpresa
	   AND BASEMP.suc_idsucursal = @idSucursal
	   AND BASEMP.tipo = 1

		
		
		SELECT @max = MAX(IDBD) FROM @BDs

		SELECT @rfcCliente = rfcCliente FROM Cliente WHERE per_idpersona = @idCliente

	
		WHILE(@aux <= @max)
			BEGIN		
			
		
			
				SELECT	@nombreBase = NombreBase, @idEmpresa = emp_idempresa ,@nom_suc = suc_nombre ,@nom_emp = emp_nombre FROM @BDs WHERE IDBD = @aux
					SELECT @rfcEmisor = rfc FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP WHERE emp_idempresa = @idEmpresa AND  tipo = 2 

					
				SET @cadena = 'SELECT 	SALDO 
								 FROM ['+@nombreBase+'].[DBO].[BI_CARTERA_CLIENTES] '  + 
								' WHERE DES_TIPODOCTO = ''FACTURA'' AND SUBSTRING(CCP_IDDOCTO,1,2) ' + char(13) + 
								' IN(SELECT SUBSTRING(FCF_SERIE,1,2)' + char(13) + 
								' FROM  ['+@nombreBase+'].[DBO].[ADE_CFDFOLIOS]) AND OrigenMovimiento IN (''NUEVOS'',''SEMINUEVOS'',''REFACCIONES'',''SERVICIO'',''HOJALATERIA Y PINTURA'') ' + char(13) + 
								' AND PER_RFC = ''' + @rfcCliente + '''
								AND CCP_CARTERA = ''' + @cartera + '''
								' 
								PRINT (@cadena)
								
								INSERT INTO @Facturas
								execute (@cadena)

				SET @aux = @aux + 1	
	END

	SELECT ISNULL(SUM(saldo),0) AS saldoPendiente FROM  @Facturas 

	


END
go

