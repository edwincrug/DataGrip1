-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,> --[dbo].[SEL_DETALLE_REFERENCIA_SP] 97
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DETALLE_REFERENCIA_SP] 
	@idReferencia INT = 0
AS
BEGIN
	SELECT

	    ROW_NUMBER() OVER (ORDER BY REF.idReferencia) AS ID,
		REF.idReferencia
		,empresas.emp_nombre
		,sucursales.suc_nombre
		,DEREF.documento
		,departamentos.dep_nombre
		, CONVERT(varchar(50), CONVERT(money, DEREF.importeDocumento), 1) importeDocumento
		,CONVERT(money, DEREF.importeDocumento) as Total
		,(personas.per_nomrazon +' '+ personas.per_paterno +' '+ personas.per_materno) AS nombreCliente
		,DOC.nombreDocumento
		,REF.referencia
	FROM [referencias].DBO.[Referencia] REF
		INNER JOIN [referencias].DBO.[DetalleReferencia] DEREF ON REF.idReferencia = DEREF.idReferencia 
		--INNER JOIN  BDPersonas.dbo.cat_personas personas ON personas.per_idpersona = DEREF.idcliente
		INNER JOIN  GA_Corporativa.DBO.PER_PERSONAS personas ON personas.per_idpersona = DEREF.idcliente
		INNER JOIN [ControlAplicaciones].[DBO].[cat_empresas] empresas  ON empresas.emp_idempresa = REF.idEmpresa
		INNER JOIN [ControlAplicaciones].[DBO].[cat_sucursales] sucursales  ON sucursales.suc_idsucursal = DEREF.idSucursal
		INNER JOIN [ControlAplicaciones].[DBO].[cat_departamentos] departamentos  ON departamentos.dep_iddepartamento = DEREF.idDepartamento 
		INNER JOIN [referencias].DBO.[TipoDocumento] DOC ON DOC.idTipoDocumento = DEREF.idTipoDocumento
	WHERE REF.idReferencia = @idReferencia
END

go

