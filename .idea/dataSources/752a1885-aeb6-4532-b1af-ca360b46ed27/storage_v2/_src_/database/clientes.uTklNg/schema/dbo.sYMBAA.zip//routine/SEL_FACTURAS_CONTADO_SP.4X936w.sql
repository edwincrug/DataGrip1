-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- SEL_FACTURAS_CONTADO_SP 79672,'01/01/2018','01/11/2019'
CREATE PROCEDURE [dbo].[SEL_FACTURAS_CONTADO_SP] 
	 @idCliente INT = 0
	,@fechaInicio VARCHAR(10)=''
	,@fechaFin VARCHAR(10)=''
AS
BEGIN
		DECLARE @rfc VARCHAR(15) = ''
		SELECT @rfc = rfcCliente FROM clientes.dbo.Cliente WHERE per_idpersona = @idCliente
	
		DECLARE @DBConsentras TABLE(id INT IDENTITY(1,1),bdConcentra NVARCHAR(300),emp_idempresa INT)
		INSERT INTO @DBConsentras
		SELECT  BASEMP.nombre_base,EMP.emp_idempresa
		FROM Centralizacionv2..DIG_CAT_BASES_BPRO BASEMP 
		INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
		WHERE BASEMP.tipo = 2
		AND EMP.emp_idempresa = 4
		ORDER BY EMP.emp_idempresa

		DECLARE @maxBDcons INT = 0,@auxDBcons INT = 1,@maxBDSuc INT = 0,@auxDBSuc INT = 1
		SET @maxBDcons = (SELECT COUNT(id) FROM @DBConsentras)
	
		DECLARE @BDsuc TABLE(idBDsuc INT IDENTITY(1,1) , emp_idempresa INT, emp_nombre VARCHAR(50), NombreBase VARCHAR(50),suc_idsucursal INT,suc_nombre VARCHAR(50))
		
		WHILE (@auxDBcons <= @maxBDcons)
		BEGIN
			DECLARE @facturas TABLE (cartera NVARCHAR(20),factura NVARCHAR(20),tipoDoc  NVARCHAR(20),fechaVencimiento NVARCHAR(20), fechaUltimoPago NVARCHAR(20),cargo DECIMAL(18,2), abono DECIMAL(18,2),saldo DECIMAL(18,2),diasVencidos INT,formaPago NVARCHAR(20),fehcaOpe NVARCHAR(20) )

			
			DECLARE @idConcentraActual INT, @bdConcentraActual  NVARCHAR(300),@emp_idempresa INT
			SELECT @idConcentraActual = id, @bdConcentraActual = bdConcentra,@emp_idempresa = emp_idempresa FROM @DBConsentras WHERE id = @auxDBcons

			 -- INICIO SUCURSALES
			 --SELECT @idConcentraActual AS idConcentraActual
				INSERT INTO @BDsuc
				SELECT EMP.emp_idempresa ,EMP.emp_nombre ,BASEMP.nombre_base ,BASEMP.suc_idsucursal ,sucursales.suc_nombre
				FROM Centralizacionv2..dig_cat_bases_bpro BASEMP
				INNER JOIN [ControlAplicaciones].[dbo].[cat_empresas] EMP ON BASEMP.catemp_nombrecto = EMP.emp_nombrecto
				INNER JOIN [ControlAplicaciones].[dbo].[cat_sucursales] sucursales ON BASEMP.catsuc_nombrecto = sucursales.suc_nombrecto
				WHERE BASEMP.emp_idempresa = @emp_idempresa AND BASEMP.tipo = 1
				AND BASEMP.suc_idsucursal = 6

					SET @maxBDSuc = (SELECT COUNT(idBDsuc) FROM @BDsuc)
				
					WHILE (@auxDBSuc <= @maxBDSuc)
					BEGIN

						DECLARE @idSucursalActual INT, @bdSucursalActual  NVARCHAR(300),@consulta NVARCHAR(MAX)
						SELECT @idSucursalActual = suc_idsucursal, @bdSucursalActual = NombreBase FROM @BDsuc WHERE idBDsuc = @auxDBSuc
						  
						SET @consulta = ' SELECT  
													ccp_cartera AS cartera ,
													ccp_iddocto AS  idDocto,
													B.par_descrip1 AS tipoDocto, 
													CONVERT(DATE, ccp_fechven, 103) AS fechaVencimiento, 
													ccp_fechadocto AS fechaUltimoPago, 
													ccp_cargo AS cargo, 
													(SELECT Isnull(Sum(ccp_abono), 0) 
													FROM  ['+ @bdConcentraActual +'].[dbo].[vis_concar01] AS movimiento 
													WHERE  movimiento.ccp_iddocto = Car_Externa.ccp_iddocto 
															AND movimiento.ccp_idpersona = Car_Externa.ccp_idpersona 
															AND movimiento.ccp_cartera = Car_Externa.ccp_cartera 
															AND movimiento.ccp_docori <> ''s'' 
															AND movimiento.ccp_tipodocto <> ''FACTURA'')             AS abono, 
													ccp_cargo - (SELECT Isnull(Sum(ccp_abono), 0) 
																FROM   ['+ @bdConcentraActual +'].[dbo].[vis_concar01] AS movimiento 
																WHERE  movimiento.ccp_iddocto = Car_Externa.ccp_iddocto 
																		AND movimiento.ccp_idpersona = 
																			Car_Externa.ccp_idpersona 
																		AND movimiento.ccp_cartera = Car_Externa.ccp_cartera 
																		AND movimiento.ccp_docori <> ''s'' 
																		AND movimiento.ccp_tipodocto <> ''FACTURA'') AS saldo, 
        
													CASE 
																		WHEN Isdate(ccp_fechven) = 1 THEN 
																		Datediff(day, CONVERT(DATETIME, ccp_fechven, 
																					103), Getdate()) 
																		ELSE 0 
																	END AS  diasVencidos, 
													PN.par_descrip3, 
													vt.vte_fechope 
											FROM  ['+ @bdConcentraActual +'].[dbo].[vis_concar01] AS Car_Externa 
													INNER JOIN ['+ @bdConcentraActual +'].[dbo].[pnc_parametr] AS A  ON ccp_cartera = A.par_idenpara 
													LEFT OUTER JOIN ['+ @bdConcentraActual +'].[dbo].[pnc_parametr] AS B  ON ccp_tipodocto = B.par_idenpara  AND B.par_tipopara = ''TIMO''
													INNER JOIN [GA_Corporativa].[dbo].[per_personas] ON ccp_idpersona = per_idpersona  AND per_rfc = '''+ @rfc+' '' 
													LEFT JOIN [cuentasxpagar].[dbo].[cxp_ordencompra] Z  ON Car_Externa.ccp_iddocto =  Z.oce_folioorden COLLATE modern_spanish_ci_as 
													INNER JOIN ['+ @bdSucursalActual +'].[dbo].[ade_vtafi] vt ON vt.vte_docto = ccp_iddocto 
													INNER JOIN ['+ @bdSucursalActual +'].[dbo].pnc_parametr PN  ON PN.par_idenpara = vt.vte_formapago  AND PN.par_tipopara = ''VNT'' 
											WHERE  A.par_tipopara = ''CARTERA'' 
													AND A.par_idmodulo = ''CXC'' 
													AND a.par_importe5 <> 1 
													AND B.par_descrip1 = ''FACTURA'' 
													AND PN.par_descrip3 = ''CONTADO''
													AND Datediff (day, CONVERT(DATE, ccp_fechven, 103), Getdate()) >= 0 
													AND CONVERT(DATE, ccp_fechadocto, 103) BETWEEN 
														CONVERT(DATE, '''+@fechaInicio+''', 103) AND CONVERT(DATE, '''+@fechafin+''', 103) 
													AND Substring(ccp_iddocto, 1, 2) IN(SELECT Substring(fcf_serie, 1, 2)  FROM  ['+ @bdSucursalActual +'].[dbo].ade_cfdfolios) '

									PRINT (@consulta)
									INSERT INTO  @facturas
									EXECUTE (@consulta);

					SET @auxDBSuc = @auxDBSuc + 1
					END


			


			 -- FIN SUCURSALES
			 SELECT 
					cartera,
					factura,
					tipoDoc,
					fechaVencimiento,
					fechaUltimoPago,
					cargo,
					abono,
					saldo,
					diasVencidos,
					formaPago,
					fehcaOpe 

				FROM @facturas

				DELETE FROM @facturas

			SET @auxDBcons = @auxDBcons + 1
		END

		

END
go

