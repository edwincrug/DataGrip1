create view [dbo].[SER_PAQUETES] as select * from GAAU_Concentra.dbo.SER_PAQUETES
go

