create view [dbo].[CON_CFDI012015] as select * from [GAAU_Concentra].dbo.[con_cfdi012015]
go

