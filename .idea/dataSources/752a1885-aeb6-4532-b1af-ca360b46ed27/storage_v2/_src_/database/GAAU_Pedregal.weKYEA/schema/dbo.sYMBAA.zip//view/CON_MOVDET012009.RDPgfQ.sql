create view 	[dbo].[CON_MOVDET012009]	 as select * from GAAU_Concentra.dbo.CON_MOVDET012009
go

