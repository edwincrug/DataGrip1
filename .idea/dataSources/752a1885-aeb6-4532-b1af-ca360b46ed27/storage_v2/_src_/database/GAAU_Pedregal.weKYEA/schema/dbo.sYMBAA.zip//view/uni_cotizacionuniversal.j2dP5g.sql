CREATE VIEW [dbo].[uni_cotizacionuniversal]
AS
SELECT     ucu_idcotizacion, ucu_foliocotizacion,
ucu_consefolio, ucu_idcliente, ucu_fechacotiza, ucu_idusuarioalta, ucu_idusuariomodifica, ucu_idagente, ucu_estatus, ucu_fechautoriza, ucu_tasainteres, ucu_impmensual, ucu_plazocredito, ucu_fechaoperacion, ucu_impenganche, ucu_refflotilla, ucu_iddivision,
 ucu_idempresa, ucu_idsucursal, ucu_iddepartamento, ucu_idtipoventa, ucu_idprospecto, ucu_tipocotizacion, ucu_tipoventaunidad, cec_idestatuscotiza, ucu_tipoprecio, ucu_financiera, ucu_norecibo, ucu_referenciabancaria, ucu_idpedidobpro, ucu_idcontacto
FROM       CUENTASPORCOBRAR.dbo.uni_cotizacionuniversal
go

