create view [dbo].[SQC_Tipo_Vehiculos] as select * from GAAU_Concentra.dbo.SQC_Tipo_Vehiculos
go

