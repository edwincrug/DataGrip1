create view 	[dbo].[CON_CARDETACON012006]	as select * from GAAU_Concentra.dbo.CON_CARDETACON012006
go

