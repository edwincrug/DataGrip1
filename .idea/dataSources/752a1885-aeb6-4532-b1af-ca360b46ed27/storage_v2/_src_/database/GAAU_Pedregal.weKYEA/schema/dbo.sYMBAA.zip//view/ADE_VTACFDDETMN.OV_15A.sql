create view [dbo].[ADE_VTACFDDETMN] as select * from GAAU_Concentra.dbo.ADE_VTACFDDETMN
go

