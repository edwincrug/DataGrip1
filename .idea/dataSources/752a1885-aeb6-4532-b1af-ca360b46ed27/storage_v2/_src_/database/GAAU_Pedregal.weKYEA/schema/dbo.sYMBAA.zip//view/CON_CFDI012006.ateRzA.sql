create view [dbo].[CON_CFDI012006] as select * from [GAAU_Concentra].dbo.[con_cfdi012006]
go

