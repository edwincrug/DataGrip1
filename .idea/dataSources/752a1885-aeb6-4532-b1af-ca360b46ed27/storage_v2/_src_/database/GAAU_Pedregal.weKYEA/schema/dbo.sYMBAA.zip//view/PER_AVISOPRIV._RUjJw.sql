create view [dbo].[PER_AVISOPRIV] as select * from GAAU_Concentra.dbo.PER_AVISOPRIV
go

