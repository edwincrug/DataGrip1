
create view [dbo].[CON_MOVTRANSFER012014] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012014

go

