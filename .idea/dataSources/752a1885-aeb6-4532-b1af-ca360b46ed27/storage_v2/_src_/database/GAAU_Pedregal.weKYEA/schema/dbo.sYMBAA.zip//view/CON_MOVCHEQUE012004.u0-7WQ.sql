
create view [dbo].[CON_MOVCHEQUE012004] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012004

go

