
create view [dbo].[CON_MOVCHEQUE012009] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012009

go

