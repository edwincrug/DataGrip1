create view 	[dbo].[CON_CARCON012003]	as select * from GAAU_Concentra.dbo.CON_CARCON012003
go

