create view [dbo].[SQC_Tiempos_Servicio_99] as select * from GAAU_Concentra.dbo.SQC_Tiempos_Servicio_99
go

