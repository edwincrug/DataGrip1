create view [dbo].[SQC_OperacionA] as select * from GAAU_Concentra.dbo.SQC_OperacionA
go

