create view 	[dbo].[CON_CARCON012011]	as select * from GAAU_Concentra.dbo.CON_CARCON012011
go

