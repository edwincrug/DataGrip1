CREATE VIEW [dbo].[cat_claveprodserv] AS Select * From GAAU_Concentra.dbo.cat_claveprodserv
go

