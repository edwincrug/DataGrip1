CREATE VIEW [dbo].[CON_CancelaSATDet] AS SELECT * FROM GAAU_Concentra.dbo.CON_CancelaSATDet
go

