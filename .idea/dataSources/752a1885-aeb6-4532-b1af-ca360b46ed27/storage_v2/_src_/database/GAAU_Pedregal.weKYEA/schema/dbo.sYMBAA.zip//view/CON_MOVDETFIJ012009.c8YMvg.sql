create view 	[dbo].[CON_MOVDETFIJ012009]	 as select * from GAAU_Concentra.dbo.CON_MOVDETFIJ012009
go

