
create view [dbo].[CON_MOVTRANSFER012006] as select * from GAAU_Concentra.dbo.CON_MOVTRANSFER012006

go

