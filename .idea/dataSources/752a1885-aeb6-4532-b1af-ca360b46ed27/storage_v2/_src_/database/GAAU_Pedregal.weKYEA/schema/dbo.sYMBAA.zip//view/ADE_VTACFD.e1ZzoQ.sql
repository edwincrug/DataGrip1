create view [dbo].[ADE_VTACFD] as select * from GAAU_Concentra.dbo.ADE_VTACFD
go

