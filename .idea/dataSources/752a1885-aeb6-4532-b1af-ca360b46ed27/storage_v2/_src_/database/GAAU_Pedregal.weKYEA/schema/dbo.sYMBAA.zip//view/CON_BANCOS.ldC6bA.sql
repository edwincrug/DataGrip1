create view [dbo].[CON_BANCOS] as select * from GAAU_Concentra.dbo.CON_BANCOS
go

