create view [dbo].[ADE_CANCFDDETMN] as select * from GAAU_Concentra.dbo.ADE_CANCFDDETMN
go

