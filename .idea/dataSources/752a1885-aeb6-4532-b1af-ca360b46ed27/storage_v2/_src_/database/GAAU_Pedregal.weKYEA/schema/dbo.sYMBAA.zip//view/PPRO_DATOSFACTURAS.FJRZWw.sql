       CREATE VIEW PPRO_DATOSFACTURAS
       AS 
       SELECT
       id_facturas, rfc_emisor, rfc_receptor, serie, folio, importe, uuid, fecha_factura, fecha_carga, usuario_carga, folioorden, estatus, iva, tipoDocumento
       FROM Centralizacionv2.dbo.PPRO_DATOSFACTURAS
       go

