create view [dbo].[SQC_Servicio_2000_Familia] as select * from GAAU_Concentra.dbo.SQC_Servicio_2000_Familia
go

