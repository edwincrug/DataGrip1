create view [dbo].[cxc_condcred] as select * from GAAU_Concentra.dbo.cxc_condcred
go

