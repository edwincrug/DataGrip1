create view 	[dbo].[CON_MOVDETFIJ012005]	 as select * from GAAU_Concentra.dbo.CON_MOVDETFIJ012005
go

