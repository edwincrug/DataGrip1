

create view [dbo].[PNC_CONCRED] as select * from GAAU_Concentra.dbo.PNC_CONCRED


go

