create view 	[dbo].[CON_MOVDETFIJ012010]	 as select * from GAAU_Concentra.dbo.CON_MOVDETFIJ012010
go

