create view 	[dbo].[CON_CARDETA012011]	as select * from GAAU_Concentra.dbo.CON_CARDETA012011
go

