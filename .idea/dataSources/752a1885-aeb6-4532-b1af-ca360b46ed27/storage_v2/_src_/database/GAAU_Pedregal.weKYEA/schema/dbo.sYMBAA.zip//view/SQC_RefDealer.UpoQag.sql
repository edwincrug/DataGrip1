create view [dbo].[SQC_RefDealer] as select * from GAAU_Concentra.dbo.SQC_RefDealer
go

