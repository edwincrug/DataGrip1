create view [dbo].[CON_CFDI012007] as select * from [GAAU_Concentra].dbo.[con_cfdi012007]
go

