create view 	[dbo].[CON_CARCON012008]	as select * from GAAU_Concentra.dbo.CON_CARCON012008
go

