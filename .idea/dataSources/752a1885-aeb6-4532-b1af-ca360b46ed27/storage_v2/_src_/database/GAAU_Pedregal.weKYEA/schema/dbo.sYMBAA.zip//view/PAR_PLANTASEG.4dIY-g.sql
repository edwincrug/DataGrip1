create view [dbo].[PAR_PLANTASEG] as select * from GAAU_Concentra.dbo.PAR_PLANTASEG
go

