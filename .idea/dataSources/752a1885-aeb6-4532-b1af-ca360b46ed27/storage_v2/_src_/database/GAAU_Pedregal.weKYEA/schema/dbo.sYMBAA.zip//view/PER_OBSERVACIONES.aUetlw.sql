create view [dbo].[PER_OBSERVACIONES] as select * from GAAU_Concentra.dbo.PER_OBSERVACIONES
go

