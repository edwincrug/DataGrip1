

create view [dbo].[CON_MOVCHEQUE012017] as select * from GAAU_Concentra.dbo.CON_MOVCHEQUE012017


go

