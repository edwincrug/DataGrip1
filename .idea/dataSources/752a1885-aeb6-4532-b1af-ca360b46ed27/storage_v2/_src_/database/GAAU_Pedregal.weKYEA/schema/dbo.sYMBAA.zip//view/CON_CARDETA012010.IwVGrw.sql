create view 	[dbo].[CON_CARDETA012010]	as select * from GAAU_Concentra.dbo.CON_CARDETA012010
go

