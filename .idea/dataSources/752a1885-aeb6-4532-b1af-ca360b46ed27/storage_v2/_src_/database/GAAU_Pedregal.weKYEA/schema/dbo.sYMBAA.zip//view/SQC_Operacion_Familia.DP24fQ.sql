create view [dbo].[SQC_Operacion_Familia] as select * from GAAU_Concentra.dbo.SQC_Operacion_Familia
go

