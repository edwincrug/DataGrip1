
-- =============================================
-- Author: Sandra Gil Rosales
-- Create date: 06-09-2019
-- Description: REALIZA ACTUALLIZACION DE DATOS (tiempoEstimado)
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[UPD_REGLAPASO_ORDEN_SP] 
	 'Automovil', 'ASE0508051B6', '0001', 92, 'Servicio',61, 2, 6077,  @salida OUTPUT;
	SELECT @salida AS salida;


*/
-- =============================================
CREATE PROCEDURE [fase].[UPD_REGLAPASO_ORDEN_SP] 
	@idClase				varchar(50),
	@rfcEmpresa				VARCHAR(13),
	@numeroContrato			VARCHAR(50),
	@idCliente				INT,
	@idTipoSolicitud		VARCHAR(10),
	@idReglaPaso			INT,
	@orden					INT,
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS



BEGIN TRY
BEGIN TRANSACTION

SET @err = '';		

BEGIN

  UPDATE [Solicitud].[fase].[ReglaPaso] 
  SET [orden] = @orden
  WHERE idClase = @idClase
	AND rfcEmpresa = @rfcEmpresa
	AND numeroContrato = @numeroContrato
	AND idCliente = @idCliente
	AND idTipoSolicitud = @idTipoSolicitud
	AND idReglaPaso = @idReglaPaso
	AND activo = 1

END

	SET @err = ''
	COMMIT
END TRY
BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH

go

