
-- =============================================
-- Author:			<Jose Luis Lozada Guerrero>
-- Create date: 	<28/08/2019>
-- Description:	    <Vista para obtener los totales por solicitud>
-- =============================================
/*
 SELECT 
     [idSolicitud]
     ,[idTipoSolicitud]
     ,[idClase]
     ,[rfcEmpresa]
     ,[numeroContrato]
     ,[idCliente]
     ,[subTotalCosto]
     ,[IVACosto]
     ,[totalCosto]
     ,[subTotalVenta]
     ,[IVAVenta]
     ,[totalVenta]
 FROM [solicitud].[SEL_TOTALES_SOLICITUD_VW]

 SELECT * FROM [solicitud].[SEL_TOTALES_SOLICITUD_VW]
 */
-- =============================================
CREATE VIEW [solicitud].[SEL_TOTALES_SOLICITUD_VW]
AS

SELECT 
    [idSolicitud]
    ,[idTipoSolicitud]
    ,[idClase]
    ,[rfcEmpresa]
    ,[numeroContrato]
    ,[idCliente]
    ,SUM([subTotalCosto]) subTotalCosto
    ,SUM([IVACosto]) IVACosto
    ,SUM([totalCosto]) totalCosto
    ,SUM([subTotalVenta]) subTotalVenta
    ,SUM([IVAVenta]) IVAVenta
    ,SUM([totalVenta]) totalVenta
FROM [Solicitud].[solicitud].[SEL_TOTALES_COTIZACION_VW]
GROUP BY [idSolicitud]
    ,[idTipoSolicitud]
    ,[idClase]
    ,[rfcEmpresa]
    ,[numeroContrato]
    ,[idCliente]
go

