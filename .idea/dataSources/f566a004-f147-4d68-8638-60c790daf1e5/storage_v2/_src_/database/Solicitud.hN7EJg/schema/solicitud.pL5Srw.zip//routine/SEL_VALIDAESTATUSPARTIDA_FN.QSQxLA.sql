
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <07/12/2020>
-- Description:	<Funcion que determina el estatus de autorizacion de una partida>

/*
	SELECT [solicitud].SEL_VALIDAESTATUSPARTIDA_FN(1429,'Automovil','Imagen','ASE0508051B6',185,'43',746045)
*/
-- =============================================
CREATE FUNCTION [solicitud].SEL_VALIDAESTATUSPARTIDA_FN
(
	@idSolicitud		INT,
	@idClase			VARCHAR(10),
	@idTipoSolicitud	VARCHAR(10),
	@rfcEmpresa			VARCHAR(13),	
	@idCliente			INT,
	@numeroContrato		VARCHAR(50),
	@idPartida			INT
)
RETURNS VARCHAR(20)
AS
BEGIN
	DECLARE @salida VARCHAR(20)=''
	DECLARE @txDatos TABLE(idEstatusAprobador VARCHAR(10))

	INSERT INTO @txDatos
	SELECT	DISTINCT idEstatusAprobador
	FROM	solicitud.SolicitudCotizacionAprobador
	WHERE	idSolicitud			= @idSolicitud
	AND     idTipoSolicitud		= @idTipoSolicitud
	AND		idClase				= @idClase
	AND		rfcEmpresa			= @rfcEmpresa
	AND		numeroContrato		= @numeroContrato
	AND		idCliente			= @idCliente
	AND		idPartida			= @idPartida
	
	IF EXISTS(SELECT 1 FROM @txDatos WHERE idEstatusAprobador='RECHAZADA')
		SET @salida='RECHAZADA'
	ELSE
		SET @salida='APROBADA'
	
	RETURN @salida


END
go

