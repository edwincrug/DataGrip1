CREATE procedure [solicitud].[DEL_LIMPIA_HOJATRABAJO_SP]
@idSolicitud			INT,
@idTipoSolicitud		VARCHAR(10),
@idClase				VARCHAR(10),
@rfcEmpresa				VARCHAR(13),
@idCliente				INT,
@numeroContrato			VARCHAR(50),
@idTipoObjeto			INT,
@idObjeto				INT,
@idDocumentoClase		INT

AS

BEGIN


	delete FROM [Solicitud].[documento].[SolicitudObjetoPaso] 
	WHERE idSolicitud = @idSolicitud
		AND idTipoSOlicitud = @idTipoSolicitud
		AND idClase = @idClase
		AND rfcEmpresa = @rfcEmpresa
		AND idCliente = @idCliente
		AND numeroContrato = @numeroContrato
		AND idTipoObjeto = @idTipoObjeto
		AND idObjeto = @idObjeto
		AND idDocumentoClase = @idDocumentoClase

END


--USE [Solicitud]
go

