-- =============================================
-- Author:		Martin Pacheco
-- Create date: 03/06/2019
-- Description:	Genera numero de solicitud.
-- Test:		SELECT [solicitud].[SEL_NUMEROSOLICITUD_FN]('DIC0503123MD3',78,'123PEMEX')
-- =============================================
CREATE FUNCTION [solicitud].[SEL_NUMEROSOLICITUD_FN]
(
	@rfcEmpresa VARCHAR(13),
	@idCliente	INT,
	@numeroContrato	VARCHAR(50)
)
RETURNS VARCHAR(50)
AS
BEGIN
	DECLARE 
		@VC_NumeroSolicitud		VARCHAR(60) = '',
		@VC_NumeroConsecutivo	VARCHAR(8) = '',
		@VC_FolioContrato		VARCHAR(20) = ''

	SELECT @VC_FolioContrato = (
		SELECT 
			[C].[folio]
		FROM [Cliente].[cliente].[Contrato] AS [C]
		WHERE 
			[C].[rfcEmpresa] = @rfcEmpresa AND
			[C].[idCliente] = @idCliente AND
			[C].[numeroContrato] = @numeroContrato
	)
	SELECT @VC_NumeroConsecutivo = (
		SELECT 
			TOP 1 [CC].[consecutivo]
		FROM [solicitud].[ContratoConsecutivo] AS [CC]
		WHERE 
			[CC].[rfcEmpresa] = @rfcEmpresa AND
			[CC].[idCliente] = @idCliente AND
			[CC].[numeroContrato] = @numeroContrato
	)
	IF (@VC_NumeroConsecutivo IS NOT NULL AND @VC_NumeroSolicitud IS NOT NULL)
	BEGIN
		SET @VC_NumeroSolicitud = @VC_FolioContrato +'-'+ @VC_NumeroConsecutivo
	END

	RETURN @VC_NumeroSolicitud
END
go

