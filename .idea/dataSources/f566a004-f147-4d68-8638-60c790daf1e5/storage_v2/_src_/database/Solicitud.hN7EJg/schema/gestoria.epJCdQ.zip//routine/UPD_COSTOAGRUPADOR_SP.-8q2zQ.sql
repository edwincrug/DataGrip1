
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 30-05-2019
-- Description: Actualiza agrupador
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[UPD_COSTOAGRUPADOR_SP]  1,'Sedan2', @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[UPD_COSTOAGRUPADOR_SP]
	@idAgrupador				int,
	@nombreAgrupador			varchar(200),
	@idUsuario					int,
	@err						varchar(500)OUTPUT
AS


BEGIN

	UPDATE gestoria.CostoAgrupador set nombre = @nombreAgrupador
	WHERE idCostoAgrupador = @idAgrupador
	

	
END
go

