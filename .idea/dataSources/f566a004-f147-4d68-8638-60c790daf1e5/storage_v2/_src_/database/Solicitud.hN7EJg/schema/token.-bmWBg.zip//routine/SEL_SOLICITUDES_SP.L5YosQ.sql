-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<06/07/2019>
-- Description:	    <Valida si el usuario es aprobador para poder generar tokens>
-- =============================================
-- EXEC [token].[SEL_SOLICITUDES_SP] 'Servicio', 'Automovil', 'ASE0508051B6', 92, '0001', 'EnEspera', 'Aprobacion', 55
-- =============================================
CREATE PROCEDURE [token].[SEL_SOLICITUDES_SP]
    (
        @idClase               varchar(10)
        ,@rfcEmpresa            varchar(13)
        ,@idCliente             int=78
        ,@numeroContrato        varchar(50)
        ,@idPaso                varchar(50)
        ,@idFase                varchar(20)
        ,@idUsuario			    int
        ,@err				    varchar(500) = '' OUTPUT
)
AS
BEGIN

    SELECT
        SSZV.[idSolicitud]
        , SSZV.[numeroOrden]
        , STS.[nombre] tipoSolicitud
        , 'paso' tipoPaso
        , SSZV.[zona]
        , SSZV.[idObjeto]
        , SSZV.[idTipoObjeto]
        , FSEP.[idPaso]
        , FSEP.[idTipoSolicitud]
    FROM [Solicitud].[fase].[SolicitudEstatusPaso] FSEP
        INNER JOIN [Solicitud].[solicitud].[SEL_SOLICITUD_ZONA_VW] SSZV
        ON FSEP.[idSolicitud] = SSZV.[idSolicitud]
            AND FSEP.[idClase]  = SSZV.[idClase]
            AND FSEP.[rfcEmpresa] = SSZV.[rfcEmpresa]
            AND FSEP.[idCliente] = SSZV.[idCliente]
            AND FSEP.[numeroContrato] = SSZV.[numeroContrato]
            AND FSEP.[idTipoSolicitud] = SSZV.[idTipoSolicitud]
        INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON SSZV.[idTipoSolicitud] = STS.[idTipoSolicitud]
            AND SSZV.[idClase] = STS.[idClase]
    WHERE FSEP.[idClase] = @idClase
        AND FSEP.[rfcEmpresa] = @rfcEmpresa
        AND FSEP.[idCliente] = @idCliente
        AND FSEP.[numeroContrato] = @numeroContrato
        AND FSEP.[idPaso] = @idPaso
        AND FSEP.[idFase] = @idFase
        AND FSEP.[fechaSalida] IS NULL
        AND FSEP.[idEstatus] = 1
        AND STS.[idClase] = @idClase
        AND SSZV.[idClase] = @idClase
        AND SSZV.[rfcEmpresa] = @rfcEmpresa
        AND SSZV.[idCliente] = @idCliente
        AND SSZV.[numeroContrato] = @numeroContrato
		AND SSZV.[idEstatusSolicitud] = 'ACTIVA'

    UNION

    SELECT
        SSZV.[idSolicitud]
        , SSZV.[numeroOrden]
        , STS.[nombre] tipoSolicitud
        , 'contrato' tipoPaso
        , SSZV.[zona]
        , SSZV.[idObjeto]
        , SSZV.[idTipoObjeto]
        , FCSEP.[idPaso]
        , FCSEP.[idTipoSolicitud]
    FROM [Solicitud].[faseContrato].[SolicitudEstatusPaso] FCSEP
        INNER JOIN [Solicitud].[solicitud].[SEL_SOLICITUD_ZONA_VW] SSZV
        ON FCSEP.[idSolicitud] = SSZV.[idSolicitud]
            AND FCSEP.[idClase]  = SSZV.[idClase]
            AND FCSEP.[rfcEmpresa] = SSZV.[rfcEmpresa]
            AND FCSEP.[idCliente] = SSZV.[idCliente]
            AND FCSEP.[numeroContrato] = SSZV.[numeroContrato]
            AND FCSEP.[idTipoSolicitud] = SSZV.[idTipoSolicitud]
        INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON SSZV.[idTipoSolicitud] = STS.[idTipoSolicitud]
            AND SSZV.[idClase] = STS.[idClase]
    WHERE FCSEP.[idClase] = @idClase
        AND FCSEP.[rfcEmpresa] = @rfcEmpresa
        AND FCSEP.[idCliente] = @idCliente
        AND FCSEP.[numeroContrato] = @numeroContrato
        AND FCSEP.[idPaso] = @idPaso
        AND FCSEP.[idFase] = @idFase
        AND FCSEP.[fechaSalida] IS NULL
        AND FCSEP.[idEstatus] = 1
        AND STS.[idClase] = @idClase
        AND SSZV.[idClase] = @idClase
        AND SSZV.[rfcEmpresa] = @rfcEmpresa
        AND SSZV.[idCliente] = @idCliente
        AND SSZV.[numeroContrato] = @numeroContrato
		AND SSZV.[idEstatusSolicitud] = 'ACTIVA'

END
go

