-- =============================================
-- Author:		Martin Pacheco
-- Create date: 06/07/2019
-- Description:	obtiene objeto por solicitud.
-- =============================================
/*
	select * from solicitud.solicitud.solicitud where numero='1-1045'
	EXEC [solicitud].[SEL_OBJETOPORSOLICITUD_SP] 1082,'Automovil','AAN910409135',218,'0001',6282,null

	select * from solicitud.solicitud.solicitudObjeto where idSolicitud=1082
	EXEC [solicitud].[SEL_OBJETOPORSOLICITUD_MULTIPLE_SP] '1-1045-13871-1', 1082,'Instala','Automovil','AAN910409135',218,'0001',6282,null

*/
CREATE PROCEDURE [solicitud].[SEL_OBJETOPORSOLICITUD_MULTIPLE_SP]
	@numeroCotizacion	VARCHAR(50),
	@idSolicitud		INT = 0,
	@idTipoSolicitud	VARCHAR(10),
	@idClase			VARCHAR(10) = '',
	@rfcEmpresa			VARCHAR(13) = '',
	@idCliente			INT = 0,
	@numeroContrato		VARCHAR(50) = '',
	@idUsuario			INT = 0,
	@err				VARCHAR(500) OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	SELECT  DISTINCT SCP.idTipoObjeto,SCP.idObjeto 
	FROM	[solicitud].[SolicitudCotizacion] [SC] INNER JOIN [solicitud].[SolicitudCotizacionPartida] [SCP] ON SC.idSolicitud =[SC].idSolicitud
	AND		SC.idTipoSolicitud	=SCP.idTipoSolicitud
	AND		SC.idClase			=SCP.idClase
	AND		SC.rfcEmpresa		=SCP.rfcEmpresa
	AND		SC.idCliente		=SCP.idCliente
	AND		SC.numeroContrato	=SCP.numeroContrato
	AND     SC.idCotizacion		=SCP.idCotizacion
	WHERE	SC.idSolicitud		=[SC].idSolicitud
	AND		SC.idTipoSolicitud	=@idTipoSolicitud
	AND		SC.idClase			=@idClase
	AND		SC.rfcEmpresa		=@rfcEmpresa
	AND		SC.idCliente		=@idCliente
	AND		SC.numeroContrato	=@numeroContrato
	AND     SC.numeroCotizacion	=@numeroCotizacion
	
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END

/*
SELECT * FROM [solicitud].[SolicitudObjeto] 
SELECT * FROM [solicitud].[SolicitudObjeto] 
SELECT * FROM [solicitud].[SolicitudCotizacion]  WHERE NUMEROCOTIZACION='1-1045-13871-1'
SELECT * FROM [solicitud].[SolicitudCotizacionPartida] where idSolicitud=1082
SELECT * FROM [solicitud].[SolicitudCotizacionPartida] where idCotizacion=1694

*/


--USE [Solicitud]
go

