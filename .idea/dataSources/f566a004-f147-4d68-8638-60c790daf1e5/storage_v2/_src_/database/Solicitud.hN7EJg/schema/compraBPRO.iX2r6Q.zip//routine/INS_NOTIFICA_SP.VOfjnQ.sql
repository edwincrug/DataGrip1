-- =============================================
-- Author:		<Alan Rosales Chávez>
-- Create date: <16/06/2020>
-- Description:	<Se genera la notificacion a BPRO>
-- Test:
/*
	exec [compraBPRO].[INS_NOTIFICA_SP]
		630
		,'ASE0508051B6'
		,221
		,49
		,'EM'
*/
-- =============================================
CREATE PROCEDURE [compraBPRO].[INS_NOTIFICA_SP]
	@idSolicitud			INT,
	@rfcEmpresa				VARCHAR(13) = '',
	@idCliente				INT = 0,
	@numeroContrato			VARCHAR(50) = '',
	@tipoNotificacion		varchar(10), --EM = Estudio de mercado, CM = Compra
	@idUsuario				INT = 0,
	@err					VARCHAR(8000) OUTPUT
AS
BEGIN
	
	DECLARE 
		@numeroOrden varchar(50),

		@idTipoSolicitud VARCHAR(20),
		@idClase varchar(20),

		@idSolicitante numeric(18,0),
		@idTipoNotificacion int,
		@descripcion  varchar(max),
		@idEmpresa int,
		@idSucursal int,
		@idDepartamento int,
		@claveArea varchar(10),
		@totalCosto float=0,

		@urlDocumento varchar(max)
	
	--OBTENEMOS EL COSTO DE LA SOLICITUD: SOLO APLICA CUANDO ES NOTIFICACION DE COMPRA
	IF (@tipoNotificacion='CM')
	BEGIN
		select @totalCosto = totalCosto from solicitud.SEL_TOTALES_SOLICITUD_VW where idSolicitud = @idSolicitud
	END

	select 
		@numeroOrden = SO.numeroOrden
		,@idTipoSolicitud = SO.idTipoSolicitud
		,@idClase = SO.idClase
		,@idSolicitante = SB.idUsuarioBPRO
		,@idTipoNotificacion = 
		CASE	
			WHEN @tipoNotificacion = 'EM' THEN 28
			when @tipoNotificacion = 'CM' THEN
				CASE
					WHEN @totalCosto<=5000 THEN 26
					ELSE 27
				END
		END
		,@descripcion = 
		CASE 
			WHEN @tipoNotificacion = 'EM' then 'Solicitud de aprobación de Estudio de Mercado SISCOv3: ' + SO.numeroOrden
			WHEN @tipoNotificacion = 'CM' then 'Solicitud de aprobación de Compra SISCOv3: ' + SO.numeroOrden
		END
		,@idEmpresa = SB.idEmpresa
		,@idSucursal = SB.idSucursal
		,@idDepartamento = SB.idArea
		,@urlDocumento = 
		CASE 
			WHEN @tipoNotificacion = 'EM' then 
			(
				select c.valor + '' + d.path
				from compraBPRO.Solicitud s
				inner join FileServer.documento.Documento d on d.idDocumento=s.idDocumentoEM
				,Common.configuracion.Configuracion c
				where 
					s.idSolicitud = @idSolicitud and c.nombre='fileServer'
			)
			WHEN @tipoNotificacion = 'CM' then (
				select c.valor + '' + d.path
				from compraBPRO.Solicitud s
				inner join FileServer.documento.Documento d on d.idDocumento=s.idDocumentoCM
				,Common.configuracion.Configuracion c
				where 
					s.idSolicitud = @idSolicitud and c.nombre='fileServer'
			)
		END

		
	from compraBPRO.Solicitud SB
	inner join solicitud.SolicitudObjeto SO on SO.idSolicitud = SB.idSolicitud
	where SB.idSolicitud = @idSolicitud

	select @claveArea = par_idenpara 
	from [192.168.20.29].Centralizacionv2.dbo.DIG_ESCALAMIENTO_AREA_AFECT where emp_idempresa = @idEmpresa and suc_idsucursal=@idSucursal and id=@idDepartamento


	CREATE TABLE #NOTIFICA(
		id				int,
		success			int,
		result			int,
		message			varchar(max)
	)
	
	insert into #notifica
	EXEC [192.168.20.29].[Notificacion].[dbo].[INS_NOTIFICACION_COMPRAS_SP]
			@identificador				= @numeroOrden
			,@idSolicitante				= @idSolicitante 
			,@idTipoNotificacion		= @idTipoNotificacion
			,@descripcion				= @descripcion
			,@idEmpresa					= @idEmpresa    
			,@idSucursal				= @idSucursal
			,@idDepartamento			= @idDepartamento
			,@area						= @claveArea
			,@linkBPRO					= @urlDocumento
	
	insert into compraBPRO.SolicitudNotificacion 
	select 
		 @idSolicitud
		 ,@idTipoSolicitud
		 ,@idClase
		 ,@rfcEmpresa
		 ,@idCliente
		 ,@numeroContrato
		 ,@idTipoNotificacion
		 ,n.id
		 ,n.success
		 ,n.result
		 ,n.message
	from #notifica n
END
go

