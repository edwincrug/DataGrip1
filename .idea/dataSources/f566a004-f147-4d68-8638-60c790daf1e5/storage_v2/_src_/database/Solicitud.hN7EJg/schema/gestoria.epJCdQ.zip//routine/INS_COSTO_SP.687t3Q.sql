
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 03-05-2019
-- Description: Inserta o actualiza costo de tipo objeto
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[INS_COSTO_SP]  1,1000,'Verificación','03', 6077,0,'Automovil', @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[INS_COSTO_SP] 
	@idCostoAgrupador				int,
	@newData						decimal(18,2),
	@key							varchar(100),
	@idEstado						varchar(2),
	@idUsuario						int,
	@idTipoObjeto					int,
	@idClase						varchar(10),
	@err							nvarchar(500)OUTPUT
AS


BEGIN
	DECLARE @idConcepto		INT
	DECLARE @idPartida		INT
	DECLARE @CONTPROPGEN	INT

	SELECT @idConcepto = idConcepto FROM gestoria.concepto WHERE nombre = @key

	IF OBJECT_ID('tempdb..#datos') IS NOT NULL
		BEGIN
			DROP TABLE #datos
		END

	IF OBJECT_ID('tempdb..#propGen') IS NOT NULL
		BEGIN
			DROP TABLE #propGen
		END


	SELECT 
	ROW_NUMBER() OVER(ORDER BY idPropiedadGeneral ASC) AS Row_Num,
	*
	INTO #propGen
	FROM [partida].[partida].[PropiedadGeneral] 


/******************************************************************SE VALIDA SI TIENE AGRUPADOR ***************************************************/
	IF(@idTipoObjeto = 0)
		BEGIN
		/******************************************************************SE ACTUALIZA AGRUPADOR SI EXISTE ***************************************************/
			IF EXISTS(SELECT * from gestoria.AgrupadorCosto WHERE idCostoAgrupador = @idCostoAgrupador AND idConcepto = @idConcepto AND idEstado = @idEstado)
				BEGIN
					UPDATE gestoria.AgrupadorCosto SET costo = @newData WHERE idCostoAgrupador = @idCostoAgrupador AND idConcepto = @idConcepto AND idEstado = @idEstado

				END
			ELSE
/******************************************************************SE INSERTA AGRUPADOR SI NO EXISTE ***************************************************/
				BEGIN
					INSERT INTO gestoria.AgrupadorCosto
					SELECT
						@idCostoAgrupador,
						@idEstado,
						@idConcepto,
						@newData,
						@idUsuario
				END

				DECLARE @CONT INT = 1
				DECLARE @idTipoObjeto2 INT

				SELECT 
				ROW_NUMBER() OVER(ORDER BY idCostoAgrupador ASC) AS Row_Num,
				*
				INTO #datos
				FROM gestoria.costoAgrupadorDetalle 
				WHERE idCostoAgrupador = @idCostoAgrupador


	/******************************************************************SE RECORREN TIPOS DE OBJETOS DE ESE AGRUPADOR ***************************************************/

					WHILE (SELECT COUNT(*) FROM gestoria.costoAgrupadorDetalle WHERE idCostoAgrupador = @idCostoAgrupador) >= @CONT
						BEGIN

							SELECT @idTipoObjeto2 = idTipoObjeto FROM #datos WHERE Row_NUm = @CONT

		
/******************************************************************************SE INSERTA EN PARTIDAS ***************************************************/
							INSERT INTO partida.partida.partida
							SELECT 
								@idTipoObjeto2,
								@idClase,
								1,
								@idUsuario

							SET @idPartida = @@IDENTITY

/**************************************************************************PROPIEDADES GENERALES ***************************************************/
							SET @CONTPROPGEN = 1
							WHILE(SELECT COUNT(*) FROM [partida].[partida].[PropiedadGeneral]) >= @CONTPROPGEN
								BEGIN
									INSERT INTO [partida].[partida].[PartidaPropiedadGeneral]
									SELECT
									@idPartida,
									@idTipoObjeto2,
									@idClase,
									idPropiedadGeneral,
									CASE
										WHEN agrupador = 'Partida' OR agrupador = 'noParte' THEN @idEstado + '-' + @key + '-' + CAST(@idTipoObjeto2 AS VARCHAR(50))
										WHEN agrupador = 'Foto' THEN (Select CAST(idFile AS VARCHAR(50)) FROM gestoria.Concepto WHERE idConcepto = @idConcepto) 
										WHEN agrupador = 'Instructivo' THEN '0'
										ELSE '' END,
									'',
									@idUsuario	
									FROM #propGen WHERE Row_Num = @CONTPROPGEN
									
									SET @CONTPROPGEN = @CONTPROPGEN + 1
								END

						

/**************************************************************************PROPIEDADES CLASE ***************************************************/
								INSERT INTO [partida].[partida].[PartidaPropiedadClase]
								SELECT
								@idPartida,
								@idTipoObjeto2,
								@idClase,
								(SELECT idPropiedadClase FROM [partida].[partida].[PropiedadClase] WHERE valor = 'Gestoría'),
								'',
								'',
								@idUsuario	

/******************************************************************SE ACTUALIZA TIPO DE OBJETO SI EXISTE DE ESE AGRUPADOR ***************************************************/

							IF EXISTS(SELECT * FROM gestoria.Costo C
										INNER JOIN gestoria.costoAgrupadorDetalle CAD ON CAD.idTipoObjeto = C.idTipoObjeto
										WHERE idConcepto = @idConcepto
										AND idCostoAgrupador = @idCostoAgrupador
										AND C.idTipoObjeto = @idTipoObjeto2
										AND C.idEstado = @idEstado
										AND C.idClase = @idClase)

								BEGIN
									UPDATE C SET costo = @newData
									FROM gestoria.Costo C
										INNER JOIN gestoria.costoAgrupadorDetalle CAD ON CAD.idTipoObjeto = C.idTipoObjeto
										WHERE idConcepto = @idConcepto
										AND idCostoAgrupador = @idCostoAgrupador
										AND C.idEstado = @idEstado
								END
/******************************************************************SE INSERTA TIPO DE OBJETO SI NO EXISTE ***************************************************/
							ELSE
								BEGIN 
									INSERT INTO gestoria.Costo
									SELECT 
										@idEstado,
										@idTipoObjeto2,
										@idClase,
										@idCOncepto,
										@newData,
										@idPartida,
										@idUsuario,
										1
								END

							SET @CONT = @CONT + 1

						END
			

	END

/******************************************************************SE ACTUALIZA TIPO OBJETO QUE NO TIENE AGRUPADOR ***************************************************/

	ELSE
		BEGIN
			IF EXISTS(SELECT * FROM gestoria.Costo WHERE idEstado = @idEstado AND idConcepto = @idConcepto AND idTipoObjeto = @idTipoObjeto)
				BEGIN
					UPDATE gestoria.Costo set costo = @newData
					WHERE idEstado = @idEstado 
					AND idConcepto = @idConcepto 
					AND idTipoObjeto = @idTipoObjeto
					AND idClase = @idClase
				END
			
			ELSE
				BEGIN
					IF NOT EXISTS(SELECT idTipoObjeto from integridad.TipoObjeto WHERE idTipoObjeto = @idTipoObjeto)
						BEGIN
							INSERT INTO integridad.TipoObjeto values(@idTipoObjeto, @idClase)
						END

					IF NOT EXISTS(SELECT idEstado from integridad.Estado WHERE idEstado = @idEstado)
						BEGIN
							INSERT INTO integridad.Estado values (@idEstado)
						END

					
		
/******************************************************************************SE INSERTA EN PARTIDAS ***************************************************/
							INSERT INTO partida.partida.partida
							SELECT 
								@idTipoObjeto,
								@idClase,
								1,
								@idUsuario

							SET @idPartida = @@IDENTITY

/**************************************************************************PROPIEDADES GENERALES ***************************************************/
							SET @CONTPROPGEN = 1
							WHILE(SELECT COUNT(*) FROM [partida].[partida].[PropiedadGeneral]) >= @CONTPROPGEN
								BEGIN
									INSERT INTO [partida].[partida].[PartidaPropiedadGeneral]
									SELECT
									@idPartida,
									@idTipoObjeto,
									@idClase,
									idPropiedadGeneral,
									CASE
										WHEN agrupador = 'Partida' OR agrupador = 'noParte' THEN @idEstado + '-' + @key + '-' + CAST(@idTipoObjeto AS VARCHAR(50))
										WHEN agrupador = 'Foto' THEN (Select CAST(idFile AS VARCHAR(50)) FROM gestoria.Concepto WHERE idConcepto = @idConcepto) 
										WHEN agrupador = 'Instructivo' THEN '0'
										ELSE '' END,
									'',
									@idUsuario	
									FROM #propGen WHERE Row_Num = @CONTPROPGEN
									
									SET @CONTPROPGEN = @CONTPROPGEN + 1
								END

						

/**************************************************************************PROPIEDADES CLASE ***************************************************/
								INSERT INTO [partida].[partida].[PartidaPropiedadClase]
								SELECT
								@idPartida,
								@idTipoObjeto,
								@idClase,
								(SELECT idPropiedadClase FROM [partida].[partida].[PropiedadClase] WHERE valor = 'Gestoría'),
								'',
								'',
								@idUsuario	

					INSERT INTO gestoria.Costo
					SELECT
						@idEstado,
						@idTipoObjeto,
						@idClase,
						@idConcepto,
						@newData,
						@idPartida,
						@idUsuario,
						1
				END
			
		END

END
go

