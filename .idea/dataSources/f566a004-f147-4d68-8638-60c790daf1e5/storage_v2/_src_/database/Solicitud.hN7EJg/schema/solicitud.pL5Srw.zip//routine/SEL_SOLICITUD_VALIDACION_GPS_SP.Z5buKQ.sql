-- =============================================
-- Author:		<DVR>
-- Create date: <20/08/2020>
-- Description:	<Regresa las solicitudes para la configuracion y liberacion de GPS>
-- TEST [solicitud].[SEL_SOLICITUD_VALIDACION_GPS_SP] 'ASE0508051B6',185,'127',15071,'Automovil',18393,6119, '';
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_SOLICITUD_VALIDACION_GPS_SP]
	@rfcEmpresa		varchar(13),  
	@idCliente		int,  
	@numeroContrato nvarchar(50),  
	@idSolicitud	int,    
	@idClase		varchar(10),
	@idObjeto		int,
	@idUsuario		int,  
	@err			varchar(500)OUTPUT 
AS
BEGIN
		DECLARE @idPropiedadCategoria int = 0

		SELECT @idPropiedadCategoria = idPropiedadCategoria 
		FROM inventario.inventario.PropiedadCategoria 
		WHERE idCategoria = 'GPS' and agrupador='DeviceID'

		SELECT  
				 a.idSolicitud as a
				,solicitud.idSolicitud  as b
				,a.[idTipoSolicitud]
				,a.[idClase] 
				,a.[rfcEmpresa]
				,a.[idCliente]
				,a.[numeroContrato]
				,a.idTipoObjeto			
				,a.[idObjeto] 												 												     						 								
				,(SELECT TOP 1 
						COALESCE(P.fixtime,'sinFecha')  AS primerReporte
						FROM [Tracker].Tracker_Socket1.dbo.tc_devices d
						INNER JOIN [Tracker].Tracker_Socket1.dbo.tc_positions p ON p.deviceid = d.id
						WHERE d.uniqueid =pc.valor
						ORDER BY p.fixtime
				) AS primerReporte
				,COALESCE(solicitud.fechaAlta,objeto.fechaAlta)  AS fechaAlta  
				,dev.lastupdate  AS ultimoReporte				
				,COALESCE(solicitud.idGPSSIM,objeto.idGPSSIM)  AS idGPSSIM 
				,c.idInventarioGPS
				,pc.valor as gpsTexto
				,solicitud.comentario				
		FROM [Solicitud].[solicitud].[SolicitudObjeto] a
			LEFT JOIN [Solicitud].[solicitud].[SolicitudObjetoGPSSIM]  solicitud ON a.idObjeto = solicitud.idObjeto AND solicitud.[idSolicitud] = @idSolicitud
			LEFT JOIN inventario.inventario.ObjetoGPSSIM objeto ON a.idObjeto = objeto.idObjeto AND activo = 1
			LEFT JOIN inventario.inventario.GPSSIM  c ON  ISNULL(solicitud.idGPSSIM, objeto.idGPSSIM) = c.idGPSSIM
			LEFT JOIN inventario.inventario.InventarioPropiedadCategoria pc on c.idInventarioGPS = pc.idInventario and  idPropiedadCategoria = (CASE WHEN pc.idCategoria = 'GPS' THEN 1 ELSE 7 END) --@idPropiedadCategoria
			LEFT JOIN [Tracker].Tracker_Socket1.dbo.tc_devices dev ON pc.valor = dev.uniqueid
		WHERE  a.[rfcEmpresa] = @rfcEmpresa
		AND a.[idCliente] = @idCliente
		AND a.[numeroContrato] = @numeroContrato
		AND a.[idClase]= @idClase		
		AND a.[idObjeto] = @idObjeto
		AND a.[idSolicitud] = @idSolicitud

		--	[solicitud].[SEL_SOLICITUD_VALIDACION_GPS_SP] 'AAN910409135',218,'0001',1135,'Automovil',13876,6143, '';
END

--USE [Solicitud]
go

