-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <11/07/2019>
-- Description:	<Obtiene informacion para el reporte de recepcion>
-- ============== Versionamiento ================
/*
	Fecha			Autor			Descripción
	

	*- Testing...
	DECLARE @err VARCHAR(50) 
	EXEC  solicitud.SEL_DATOS_COMPROBANTE_RECEPCION_SP  230,161,'Traslado',
	'Automovil','ASE0508051B6',219,'128',12941,123,521,'SAGA790528441','fileServer:"https://fileserver.centraldeoperaciones.com:443"',2,@err output
	PRINT @err
*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_DATOS_COMPROBANTE_RECEPCION_SP]
	@idComprobanteRecepcion		INT,
	@idSolicitud				INT,
	@idTipoSolicitud			VARCHAR(10),
	@idClase					VARCHAR(10),
	@rfcEmpresa					VARCHAR(13),
	@idCliente					INT,
	@numeroContrato				VARCHAR(50),
	@idObjeto					INT,
	@idTipoObjeto				INT,
	@idProveedorEntidad			INT,
	@rfcProveedor				VARCHAR(13),
	@version					INT,
	@fileServer					VARCHAR(max),
	@idUsuario					INT,
	@err						VARCHAR(500) OUTPUT
AS
BEGIN
	DECLARE @v_idd int,@v_idAgrupacion VARCHAR(max),@v_valor INT
	DECLARE @taby AS TABLE(alias VARCHAR(100),valor VARCHAR(max),descripcion VARCHAR(max))
	
	DECLARE @idPropiedadClase INT
	SELECT	@idPropiedadClase=tobcla.idPropiedadClase
	FROM	Objeto.objeto.objeto obj
	INNER	JOIN Partida.tipoobjeto.tipoobjeto tob ON obj.idTipoObjeto = tob.idTipoObjeto
	INNER	JOIN Partida.tipoobjeto.TipoObjetoPropiedadClase tobcla ON tobcla.idTipoObjeto = tob.idTipoObjeto AND tobcla.idClase = tob.idClase
	INNER	JOIN Partida.tipoobjeto.PropiedadClase procla ON procla.idPropiedadClase = tobcla.idPropiedadClase AND procla.idClase = tobcla.idClase
	WHERE	obj.idObjeto		= @idObjeto  
	AND		procla.agrupador	= 'Clase'

	INSERT INTO @taby(alias,valor,descripcion)
	SELECT  b.abreviatura,a.valor,
			a.valor 'descripcion'
	FROM	solicitud.SEL_DATOSCOMPROBANTE_VW a,
			solicitud.ComprobantePropiedades b
	WHERE	a.idAgrupacion				=   b.idAgrupacion
	AND     a.idPropiedadClase			=   b.idPropiedadClase
	AND		a.idSolicitud				=   @idSolicitud
	AND		a.idTipoSolicitud			=   @idTipoSolicitud
	AND     a.idClase					=   @idClase
	AND		a.rfcEmpresa				=   @rfcEmpresa
	AND		a.idCliente					=   @idCliente
	AND		a.numeroContrato			=   @numeroContrato
	AND		a.idObjeto					=   @idObjeto	
	AND     a.idTipoObjeto				=   @idTipoObjeto
	AND     a.idProveedorEntidad		=	@idProveedorEntidad
	AND     a.rfcProveedor				=	@rfcProveedor
	AND     a.idComprobanteRecepcion	=   @idComprobanteRecepcion
	AND     a.[version]					=	@version
	AND		a.idAgrupacion				IN  (SELECT idAgrupacion FROM solicitud.ComprobanteAgrupacion)
	UNION ALL
	SELECT  'img_'+idSubAgrupacion,'',ISNULL((	SELECT	@fileServer+PATH 
												-- SELECT *
												FROM	fileserver.[documento].[Documento] 
												WHERE	idDocumento=b.valor),'')


	 --select *
	FROM	solicitud.ComprobantePropiedadesValores b
	WHERE	b.idPropiedadClase			=@idPropiedadClase
	AND		b.idAgrupacion				='Fotos'

	UNION ALL
	SELECT 'Zona',descripcion,descripcion
	FROM	common.gerencia.contratoZona 
	WHERE   rfcEmpresa		=	@rfcEmpresa
	AND		idCliente		=	@idCliente
	AND		numeroContrato	=	@numeroContrato
	AND		idContratoZona IN (	SELECT	TOP 1 
										idContratoZona 
								FROM	cliente.contrato.objeto 
								WHERE	rfcEmpresa		=@rfcEmpresa
								AND		idcliente		=@idCliente 
								AND		numeroContrato	=@numeroContrato 
								AND		idClase			=@idClase
								AND		idTipoObjeto	=@idTipoObjeto 
								AND		idObjeto		=@idObjeto)
	UNION ALL
	SELECT 'userPrintName','',ISNULL((	SELECT TOP 1 ISNULL(PrimerNombre,'')+' '+ISNULL(SegundoNombre,'')+' '+ISNULL(PrimerApellido,'')+' '+ISNULL(SegundoApellido,'')
										FROM Seguridad.catalogo.users WHERE id=@idUsuario ),'')
	
	UNION ALL
	SELECT  'img_Logo','',ISNULL((	SELECT	@fileServer+PATH 
									-- SELECT *
									FROM	fileserver.[documento].[Documento] 
									WHERE	idDocumento = (	SELECT TOP 1 idFileAvatar 
															FROM	cliente.cliente.contrato 
															WHERE	rfcEmpresa		=@rfcEmpresa 
															AND		idCliente		=@idCliente 
															AND		idClase			=@idClase 
															AND		numeroContrato	=@numeroContrato )),'') 

	SELECT	CAST(ext_Antena as bit)					ext_Antena,
			CAST(ext_Claxon as bit)					ext_Claxon,
			CAST(ext_Cristales as bit)				ext_Cristales,
			CAST(ext_Emblemas as bit)				ext_Emblemas,
			CAST(ext_FarosDelanteros as bit)		ext_FarosDelanteros, 
			CAST(ext_TaponGasolina as bit)			ext_TaponGasolina, 
			CAST(ext_TaponLlantas as bit)			ext_TaponLlantas,
			CAST(int_Ac as bit)						int_Ac,
			CAST(int_BolsaAireDelantera as bit)		int_BolsaAireDelantera,
			CAST(int_BolsaAireLateral as bit)		int_BolsaAireLateral,
			CAST(int_CinturonSeguridad as bit)		int_CinturonSeguridad,
			CAST(int_EspejoRetrovisor as bit)		int_EspejoRetrovisor,
			CAST(int_LlavesUnidad as bit)			int_LlavesUnidad,
			CAST(int_ManijasSeguros as bit)			int_ManijasSeguros,
			CAST(int_Radio as bit)					int_Radio,
			CAST(int_Tapetes as bit)				int_Tapetes,
			CAST(acs_CableCorriente as bit)			acs_CableCorriente ,
			CAST(acs_Extintor as bit)				acs_Extintor,
			CAST(acs_LlantaRefaccion as bit)		acs_LlantaRefaccion,
			CAST(acs_PeliculaAntiasalto as bit)		acs_PeliculaAntiasalto,
			CAST(acs_Reflejantes as bit)			acs_Reflejantes,
			CAST(com_Bateria as bit)				com_Bateria,
			CAST(com_TaponMotor as bit)				com_TaponMotor,
			CAST(com_TaponAceite as bit)			com_TaponAceite,
			CAST(com_TaponRadiador as bit)			com_TaponRadiador,
			CAST(com_VarillaAceite as bit)			com_VarillaAceite,
			CAST(doc_PolizaSeguro as bit)			doc_PolizaSeguro,
			CAST(doc_TarjetaCirculacion as bit)		doc_TarjetaCirculacion,
			ISNULL((SELECT 	TOP 1 descripcion 
					FROM	solicitud.ComprobantePropiedades 
					WHERE	idPropiedadClase=tab_Descripcion),'')tab_Descripcion,
			tab_Odometro,
			ubi_TechoDesc,ubi_TraseraDesc,ubi_ParteDerechaDesc,ubi_DelanteraDesc,ubi_ParteIzquierdaDesc,
			img_ArribaDesc,img_AtrasDesc,img_DerechaDes,img_FrenteDesc,img_IzquierDes,
			img_Logo,Zona,userPrintName,
			tab_kilometrajeGps
	FROM	(SELECT p.alias,p.descripcion FROM @taby p)m
	PIVOT	(MAX(descripcion) 
	FOR		alias IN ([ext_Antena],[ext_Claxon],[ext_Cristales],[ext_Emblemas],[ext_FarosDelanteros],[ext_TaponGasolina],[ext_TaponLlantas],[int_Ac],[int_BolsaAireDelantera],
			[int_BolsaAireLateral],[int_CinturonSeguridad],[int_EspejoRetrovisor],[int_LlavesUnidad],[int_ManijasSeguros],[int_Radio],[int_Tapetes],
			[acs_CableCorriente],[acs_Extintor],[acs_LlantaRefaccion],[acs_PeliculaAntiasalto],[acs_Reflejantes],[com_Bateria],[com_TaponMotor],[com_TaponAceite],
			[com_TaponRadiador],[com_VarillaAceite],[doc_PolizaSeguro],[doc_TarjetaCirculacion],[tab_Descripcion],[tab_Odometro],[ubi_TechoDesc],[ubi_TraseraDesc],
			[ubi_ParteDerechaDesc],[ubi_DelanteraDesc],[ubi_ParteIzquierdaDesc],[img_ArribaDesc],[img_AtrasDesc],[img_DerechaDes],[img_FrenteDesc],[img_IzquierDes],
			[img_Logo],[Zona],[userPrintName],[tab_kilometrajeGps])) AS XX
	
	SELECT	'' 'idTaller'
				
	select	top 1 idobjeto 'idUnidad',
			idTipoObjeto 'idTipoUnidad',
			ISNULL((SELECT	valor 
					FROM	objeto.objeto.ObjetoPropiedadClase  
					WHERE	idClase			='Automovil' 
					AND		idTipoObjeto	=a.idTipoObjeto  
					AND		idObjeto		=a.idObjeto
					AND		idPropiedadClase IN (	SELECT idPropiedadClase 
													FROM	objeto.objeto.PropiedadClase 
													WHERE	idClase		=a.idClase
													AND		idTipoValor	='Unico' 
													AND		agrupador	='NumeroEconomico' )),'') 'numEconomico'
			
	FROM	solicitud.SEL_DATOSCOMPROBANTE_VW a
	WHERE	a.idComprobanteRecepcion	=   @idComprobanteRecepcion
	AND     a.idSolicitud				=   @idSolicitud
	AND		a.idTipoSolicitud			=   @idTipoSolicitud
	AND     a.idClase					=   @idClase
	AND		a.rfcEmpresa				=   @rfcEmpresa
	AND		a.idCliente					=   @idCliente
	AND		a.numeroContrato			=   @numeroContrato
	AND		a.idObjeto					=   @idObjeto	
	AND     a.idTipoObjeto				=   @idTipoObjeto
	AND     a.idProveedorEntidad		=	@idProveedorEntidad
	AND     a.rfcProveedor				=	@rfcProveedor
	AND     a.[version]					=	@version
	


END

go

