-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <10/06/2020>
-- Description:	<Guarda las nuevas partidas capturadas desde el alta de solicitudes>
-- Test: 
/*
	declare @err varchar(500) =''
	exec [compraBPRO].[INS_SOLICITUDPARTIDACOMPRA_SP]
		@idSolicitud		= 630
		,@idTipoSolicitud	= 'Compra'
		,@idClase			= 'Compra'
		,@rfcEmpresa		= 'ASE0508051B6'
		,@idCliente			= 221
		,@numeroContrato	= 49
		,@xmlPartidas		= ''
		,@idUsuario			= 3132
		,@err				= @err out
	select @err 'err'
		
*/
-- =============================================
CREATE PROCEDURE [compraBPRO].[INS_SOLICITUDPARTIDACOMPRA_SP]
	@idSolicitud			INT,
	@idTipoSolicitud		VARCHAR(50) = '',
	@idClase				VARCHAR(10) = '',
	@rfcEmpresa				VARCHAR(13) = '',
	@idCliente				INT = 0,
	@numeroContrato			VARCHAR(50) = '',
	@xmlPartidas			XML,
	@idUsuario				INT = 0,
	@err					VARCHAR(8000) OUTPUT
AS
BEGIN
	
	DECLARE @datos TABLE(cantidad INT, descripcion  VARCHAR(MAX))
	INSERT INTO @datos(cantidad,descripcion)    
	SELECT	ParamValues.col.value('cantidad[1]','int'),    
			ParamValues.col.value('descripcion[1]','nvarchar(500)')
	FROM	@xmlPartidas.nodes('partidas/partida') AS ParamValues(col)   


	INSERT INTO compraBPRO.SolicitudPartida(idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,cantidad,descripcion,idUsuario,activo)
	SELECT @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,cantidad,descripcion,@idUsuario,1 FROM @datos


	--1) NOTIFICAMOS
	
	EXEC [compraBPRO].[INS_NOTIFICA_SP] @idSolicitud, @rfcEmpresa,@idCliente,@numeroContrato,'EM'

	--2) SE AVANZA AUTOMATICAMENTE A "APPROBACIÓN DE ESTUDIO DE MERCADO"
	EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] 
		@idSolicitud
		,@idTipoSolicitud
		,@idClase
		,@rfcEmpresa
		,@idCliente
		,@numeroContrato
		,'AprobacionEstudioMercado'
		,'Solicitud'
		,3132		
		,@err out
END
go

