
-- =============================================
-- Author: Andres Farias
-- Create date: 26-06-2019
-- Description: Obtiene el historico de ordenes de un tipo de objeto
-- ============== Versionamiento ================
/*
	Fecha			Autor			Descripción 
	 13/08/2019		José Etmanuel	Agregando clase a la función Objeto.objeto.getPropiedadObjeto
	 09/09/2020		GZG				Agregando xml de los contratos seleccionados para filtrar las solicitudes de los vin conforme a los contratos que ha estado asignado
 

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[SEL_SOLICITUD_HISTORICOORDENES_SP]   'Automovil', 6077, 82, 92,
	@salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [solicitud].[SEL_SOLICITUD_HISTORICOORDENES_SP] 
	@idClase				varchar(50),
	@idUsuario				INT,	
	@idObjeto				int ,
	@idTipoObjeto			int ,
	@contratos				xml = '',
	@err					varchar(500) OUTPUT
AS


BEGIN

	DECLARE @contratosTable AS TABLE(
		_row                    INT IDENTITY(1,1),
		numeroContrato			VARCHAR(50),
		idCliente				INT,
		rfcEmpresa				VARCHAR(13)
	)

	INSERT INTO @contratosTable(numeroContrato,			
									idCliente,
									rfcEmpresa)		
								 	
    
	SELECT						  		
		ParamValues.col.value('numeroContrato[1]','varchar(50)'),
		ParamValues.col.value('idCliente[1]','int'),
		ParamValues.col.value('rfcEmpresa[1]','varchar(13)')
		FROM @contratos.nodes('contratos/contrato') AS ParamValues(col)

	select distinct 
		cli.nombre																	nombreCliente
		,con.nombre																	nombreContrato
		,sol.idSolicitud															idSolicitud
		,so.numeroOrden																numeroOrden
		,Objeto.objeto.getPropiedadObjeto(so.idObjeto,'NumeroEconomicoInt','Clase',@idClase)	numeroEconomico
		,ts.nombre																	tipoSolicitud
		,so.fechaAlta																fechaOrden
		,sol.comentarios															comentarios
		,sep.idPaso																	estatus
		,sep.rfcEmpresa															    rfcEmpresa
		,so.idTipoObjeto															idTipoObjeto
		,so.idObjeto																idObjeto
		,con.idFileAvatar															foto
		,sol.idCliente																idCliente
		,sol.idTipoSolicitud														idTipoSolicitud
		,con.numeroContrato															numeroContrato
	from solicitud.solicitud sol
	--SOLICITUD OBJETO
	inner join solicitud.SolicitudObjeto so on
		--Integridad con solicitud
		sol.idSolicitud = so.idSolicitud and
		sol.idTipoSolicitud = so.idTipoSolicitud and
		sol.idClase = so.idClase and
		--Integridad con contrato
		sol.rfcEmpresa = so.rfcEmpresa and
		sol.idCliente = so.idCliente and
		sol.numeroContrato = so.numeroContrato
	--SOLICITUD ESTATUS 
	inner join fase.SolicitudEstatusPaso sep on 
		--Integridad con solicitud
		sep.idSolicitud = sol.idSolicitud and 
		sep.idTipoSolicitud = so.idTipoSolicitud and
		sep.idClase = so.idClase and
		--Integridad con contrato
		sep.rfcEmpresa = sol.rfcEmpresa and 
		sep.idCliente = sol.idCliente and 
		sep.numeroContrato = sol.numeroContrato 
	--CONTRATO
	inner join Cliente.cliente.Contrato con on
		--Integridad con contrato
		con.rfcEmpresa = sol.rfcEmpresa and
		con.idCliente = sol.idCliente and 
		con.numeroContrato = sol.numeroContrato
	inner join @contratosTable CT on 
	  CT.numeroContrato = con.numeroContrato 
	  and CT.rfcEmpresa = con.rfcEmpresa 
	  and CT.idCliente = con.idCliente
	--CLIENTE
	inner join Cliente.cliente.Cliente cli on
		cli.idCliente = con.idCliente
	--OBJETO
	inner join Objeto.objeto.Objeto obj on
		--Integridad con objeto
		obj.idObjeto = so.idObjeto and
		obj.idTipoObjeto = so.idTipoObjeto and
		obj.idClase = so.idClase

	--TIPO DE SOLICITUD
	inner join solicitud.TipoSolicitud ts on
		ts.idTipoSolicitud = sol.idTipoSolicitud and
		ts.idClase = sol.idClase

	--USUARIO
	inner join Seguridad.Catalogo.Users su on 
		su.Id = sol.idUsuario

	WHERE
		sep.fechaSalida is null and
		sol.idEstatusSolicitud = 'FINALIZADA' and
		so.idObjeto = @idObjeto and
		so.idClase = @idClase and
		so.idTipoObjeto = @idTipoObjeto and
		con.activo = 1
	group by 
		cli.nombre
		,sol.idSolicitud
		,so.numeroOrden
		,Objeto.objeto.getPropiedadObjeto(so.idObjeto,'NumeroEconomicoInt','Clase',@idClase)
		,ts.nombre
		,so.fechaAlta
		,sol.comentarios	
		,sep.idPaso
		,sep.rfcEmpresa
		,so.idTipoObjeto
		,so.idObjeto
		,con.idFileAvatar
		,sol.idTipoSolicitud
		,con.numeroContrato
		,sol.idCliente
		,con.nombre
	having count(sol.idSolicitud)=1
	order by
		so.fechaAlta desc
			
END

go

