
-- =============================================
-- Author: Sandra Gil Rosales
-- Create date: 06-09-2019
-- Description: REALIZA ACTUALLIZACION DE DATOS (tiempoEstimado)
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[UPD_PASOS_PORIDTIPOSOLICITUD_SP]  
	'Automovil', 'ASE0508051B6', '0001', 92, 'Servicio', 'SinTaller',
	'Solicitud', '12:30:00',2, @salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [fase].[UPD_PASOS_PORIDTIPOSOLICITUD_SP] 
	@idClase				varchar(50),
	@rfcEmpresa				VARCHAR(13),
	@numeroContrato			VARCHAR(50),
	@idCliente				INT,
	@idTipoSolicitud		VARCHAR(10),
	@idPaso					varchar(50),
	@idFase					varchar(20),
	@tiempoEstimado			varchar(10),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS

BEGIN TRY
BEGIN TRANSACTION

SET @err = '';		


	IF EXISTS(SELECT * FROM [Solicitud].[fase].[Paso] WHERE idClase = @idClase
				AND idTipoSolicitud = @idTipoSolicitud AND [idPaso] = @idPaso AND [idFase] = @idFase)
		BEGIN
			UPDATE  [Solicitud].[fase].[Paso]
				SET [tiempoEstimado] = @tiempoEstimado
				WHERE idClase = @idClase
				AND idTipoSolicitud = @idTipoSolicitud
				AND [idPaso] = @idPaso
				AND [idFase] = @idFase
		END
			ELSE IF EXISTS(SELECT * FROM [Solicitud].[faseContrato].[Paso] WHERE idClase = @idClase
				AND idTipoSolicitud = @idTipoSolicitud AND rfcEmpresa = @rfcEmpresa
				AND numeroContrato = @numeroContrato AND idCliente = @idCliente
				AND [idPaso] = @idPaso AND [idFase] = @idFase)
		BEGIN 
			UPDATE [Solicitud].[faseContrato].[Paso]
			SET [tiempoEstimado] = @tiempoEstimado
				  WHERE idClase = @idClase
				  AND idTipoSolicitud = @idTipoSolicitud
				  AND rfcEmpresa = @rfcEmpresa
				  AND numeroContrato = @numeroContrato
				  AND idCliente = @idCliente 
				  AND [idPaso] = @idPaso
				  AND [idFase] = @idFase
		END
	SET @err = ''
	COMMIT
END TRY
BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH

go

