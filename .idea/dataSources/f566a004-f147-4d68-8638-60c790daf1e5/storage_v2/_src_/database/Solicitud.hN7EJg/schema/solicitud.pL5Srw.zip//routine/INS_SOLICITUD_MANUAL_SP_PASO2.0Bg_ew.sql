
/* TEST

exec [solicitud].[INS_SOLICITUD_MANUAL_SP]
    @rfcEmpresa					 = 'ASE0508051B6'
	,@idCliente					 = 185
	,@numeroContrato			 = '43'
	,@idCentroCosto				 = ''
	,@idCentroCostoFolio		 = ''
	,@idObjeto					 = 10580
	,@idTipoObjeto				 = 117
    ,@idClase					 = 'Automovil'
	,@idTipoSolicitud			 = 'Imagen'
	,@fecha						 = '2020-07-15T15:39:00.000Z'
	,@comentarios				 = 'Creando solicitud con query testeo'
	,@idUsuario					 = 6115
	,@partidas					 = '<partidas><partida><idPartida>746044</idPartida><cantidad>1</cantidad><costoInicial>5700</costoInicial><ventaInicial>7125</ventaInicial></partida><partida><idPartida>746045</idPartida><cantidad>1</cantidad><costoInicial>1762.91</costoInicial><ventaInicial>2203</ventaInicial></partida></partidas>'
	,@EstadodelaUnidad			 = 'Parado'
	,@idProveedorEntidad		 = 519
	,@rfcProveedor				 = 'OKW190528LZ9'
	,@uuid						 = '987ED080-0000-000-000-B0B7882C350C'
	,@serie						 = NULL
	,@folio						 ='7498'
	,@fechaFactura				 = '2020-05-27T13:02:14'
	,@rfcEmisor					 = 'OKW190528LZ9'
	,@rfcReceptor				 = 'ASE0508051B6'
	,@subTotal					 = 7462.91
	,@descuento					 = null
	,@traslado					 = 471.15
	,@retencion					 = null
	,@trasladosXml				 = null
	,@retencionesXml			 = null
	,@total						 = 3415.72
	,@xml						 = '{"_declaration":{"_attributes":{"version":"1.0","encoding":"utf-8"}},"cfdi:Comprobante":{"_attributes":{"xmlns:cfdi":"http://www.sat.gob.mx/cfd/3","xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance","xsi:schemaLocation":"http://www.sat.gob.mx/cfd/3 http://www.sat.gob.mx/sitio_internet/cfd/3/cfdv33.xsd","Version":"3.3","Folio":"7498","Fecha":"2020-05-27T13:02:14","FormaPago":"99","CondicionesDePago":"CREDITO 30 DÍAS","SubTotal":"7462.91","LugarExpedicion":"06760","TipoCambio":"1","Moneda":"MXN","Total":"3415.72","MetodoPago":"PPD","TipoDeComprobante":"I","xmlns:implocal":"http://www.sat.gob.mx/implocal","NoCertificado":"00001000000408452207","Certificado":"MIIGGzCCBAOgAwIBAgIUMDAwMDEwMDAwMDA0MDg0NTIyMDcwDQYJKoZIhvcNAQELBQAwggGyMTgwNgYDVQQDDC9BLkMuIGRlbCBTZXJ2aWNpbyBkZSBBZG1pbmlzdHJhY2nDs24gVHJpYnV0YXJpYTEvMC0GA1UECgwmU2VydmljaW8gZGUgQWRtaW5pc3RyYWNpw7NuIFRyaWJ1dGFyaWExODA2BgNVBAsML0FkbWluaXN0cmFjacOzbiBkZSBTZWd1cmlkYWQgZGUgbGEgSW5mb3JtYWNpw7NuMR8wHQYJKoZIhvcNAQkBFhBhY29kc0BzYXQuZ29iLm14MSYwJAYDVQQJDB1Bdi4gSGlkYWxnbyA3NywgQ29sLiBHdWVycmVybzEOMAwGA1UEEQwFMDYzMDAxCzAJBgNVBAYTAk1YMRkwFwYDVQQIDBBEaXN0cml0byBGZWRlcmFsMRQwEgYDVQQHDAtDdWF1aHTDqW1vYzEVMBMGA1UELRMMU0FUOTcwNzAxTk4zMV0wWwYJKoZIhvcNAQkCDE5SZXNwb25zYWJsZTogQWRtaW5pc3RyYWNpw7NuIENlbnRyYWwgZGUgU2VydmljaW9zIFRyaWJ1dGFyaW9zIGFsIENvbnRyaWJ1eWVudGUwHhcNMTcxMjA3MDM0MjM1WhcNMjExMjA3MDM0MjM1WjCBuzEfMB0GA1UEAxMWR1IgQVVUT01PVElWRSBTQSBERSBDVjEfMB0GA1UEKRMWR1IgQVVUT01PVElWRSBTQSBERSBDVjEfMB0GA1UEChMWR1IgQVVUT01PVElWRSBTQSBERSBDVjElMCMGA1UELRMcR0FVMTMwNTIzTEIyIC8gU0VMTzc1MTAxOU0zNTEeMBwGA1UEBRMVIC8gU0VMTzc1MTAxOUhERk1OUzA3MQ8wDQYDVQQLEwZNQVRSSVowggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCa8FQp+S69Ny/2uRlTY52nwkCcQa3/QJKlGBuDnSG5kn0yBhXOMfHTHTev6a/B3IhFu2SBIq1lGwFRIdjvkTp+hUghf37QIKZxTLGs4/3ussyFLqwHIYkUfdyss1BpvjQt4cfD60a9RIDA1ksXaY1WYmT9TjPYt4FzcROXwNwzCV9BDpNZDtkFYjRLzLk+N+JFE4Hoe02Y+wnYJysMjvcSTyANya5vS9y50LWdIaFfIV/oLAV+vT/wiMzOMxSyczSOWMffDDfpNIpZbDAj3kFQKWFh5hwYFBIVsJIPwx2cNDy4SDOU1EBuu4DqhweMoh6jtguUGjp4XcQedeW0RQEpAgMBAAGjHTAbMAwGA1UdEwEB/wQCMAAwCwYDVR0PBAQDAgbAMA0GCSqGSIb3DQEBCwUAA4ICAQAFDDOmYTPzXI5p6ftpeoX6Q8LU9HD1YeFrzNyaUank5MZkQYumA+IP9hrGo1ytjFQ8HajcwVHkIGCIxFsRaRd9cqMOykGbpSJKWHu6b/hJYzVCoAogZtdsX27f6NBCVOgaC3JjwQu5s9Kx2y0ajlmeoXlLO/Rijbljy/m1AxwMfp7oxNq6tngRDLTvqzoPbQDrlKsE2ZH1yWh7X51IbDwgx7lLpkpz6IQsNqoNLDotiUKiRS7yiKhRqZaRS6DmrAAP0L6E4hpeOJ5A6tJ/o8K6PbzsREQFZHJKAWTTYUyG3LamhnYpLqzucNqoZFkxtxoFAnjIEptmNtH4I3MRJ5ZcHebzxtkdPsuzKc89HsYFntSfeCHcw0q/AwU3CaGOP/Omq5yNHJhU76ajAwP8nl+b3ZyqXOli6+In1qkTFTVmzdCi3qQi6lqjkoHpBPey9iLulTtLcrnT9sYsBBRl5xsaD5fdi7SWnQdoJTzM3xBSwOleySZrCdCu4PeXOgC7l53WoStcU7UGLP3Itihzvm+RLze2Rq1R659ZOUPAze7RcQNYNG3NY3JVpfO9Usn88EM1D/u2YGQjqb8meS4tZmE10sWfztXwZzkQyPDW6Zf8t54MP6RVuXtJjZVmVzkJ7xTxH+4xllJfDp8bux0sM8TRX1BnfJELRHxv/GTobjWgCw==","Sello":"OaT1WAlAeoS7Au5k4Ds5BrlEvhf2k6T2fCSnGapVyWVQRg/XTdhDGbAsvPIhOOPBiJmXpibPGbVhu9lJo4Zw5mvHvsos7AkMpvZj545DhULPrbUTzlrWe/4/SyY5Q+Sy9jIqVhaaNWFyq79kVa5AZPjh3i5yWidxAOtEUT3nPXBg/5yRPmiKBDBOxklTBePrflmOBTdDadKf2gWI+lFIrbdz79+4AwkRvxURrNVyGCBVl56clyjXuwQnO70+1r6NRX1y8s5LGo1vIuhBvnrb1SmhBl2MSURa8s3NJhC79vfe5l/XCoFRGsWlqwnHA09+ZjmjcVYCTpLbJfNf20p0yg=="},"cfdi:Emisor":{"_attributes":{"Rfc":"OKW190528LZ9","Nombre":"GR AUTOMOTIVE S.A. DE C.V.","RegimenFiscal":"601"}},"cfdi:Receptor":{"_attributes":{"Rfc":"ASE0508051B6","Nombre":"AUTOEXPRESS SERVICIO DE EXCELENCIA PEDREGAL SA DE CV","UsoCFDI":"G03"}},"cfdi:Conceptos":{"cfdi:Concepto":[{"_attributes":{"Cantidad":"1","ClaveProdServ":"78181500","ClaveUnidad":"E48","Unidad":"Servicio","Descripcion":"CAMBIO DE BANDA DE MOTOR","ValorUnitario":"514.52","Importe":"514.52"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"514.52","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"82.33"}}}}},{"_attributes":{"Cantidad":"1","ClaveProdServ":"78181500","ClaveUnidad":"E48","Unidad":"Servicio","Descripcion":"LIMPIEZA CON AJUSTE DE FRENOS","ValorUnitario":"460.59","Importe":"460.59"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"460.59","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"73.70"}}}}},{"_attributes":{"Cantidad":"1","ClaveProdServ":"78181500","ClaveUnidad":"E48","Unidad":"Servicio","Descripcion":"LAVADO AL CUERPO DE ACELERACION","ValorUnitario":"213.84","Importe":"213.84"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"213.84","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"34.22"}}}}},{"_attributes":{"Cantidad":"1","ClaveProdServ":"78181500","ClaveUnidad":"E48","Unidad":"Servicio","Descripcion":"CAMBIO DE BUJIAS","ValorUnitario":"605.50","Importe":"605.50"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"605.50","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"96.88"}}}}},{"_attributes":{"Cantidad":"1","ClaveProdServ":"78181500","ClaveUnidad":"E48","Unidad":"Servicio","Descripcion":"AFINACION MAYOR","ValorUnitario":"1150.12","Importe":"1150.12"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"1150.12","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"184.02"}}}}}]},"cfdi:Impuestos":{"_attributes":{"TotalImpuestosTrasladados":"471.15"},"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Impuesto":"002","TasaOCuota":"0.160000","TipoFactor":"Tasa","Importe":"471.15"}}}},"cfdi:Complemento":{"tfd:TimbreFiscalDigital":{"_attributes":{"xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance","xsi:schemaLocation":"http://www.sat.gob.mx/TimbreFiscalDigital http://www.sat.gob.mx/sitio_internet/cfd/TimbreFiscalDigital/TimbreFiscalDigitalv11.xsd","Version":"1.1","RfcProvCertif":"CCF1011111K9","SelloSAT":"VKZEfmRQm0fWNMYYYpD4Qb8lNZkbsLK41W51wSldkkmba/Qtay9/Kzq04tqCqRyjAEpsYHIwiI4EydjbFg5p/aJDk7TNcAa/e2yk3tGWMyr0xkiLxADfrMQ/CqP2c4uGCA76VXIgVYiu6UxwnyNxJnhgjp9chm6NRxMI+p1dUd8eQVjOYNTp0aJYj2SgLT/29chydLsykw4B335ARJEKlc1paCx02RerNzTkMQI0gcu9PsoPu+SikKXEiY8AcxOnfZWKSrEnnSSUcoUaiRciXdBSV/cvH0127D7den3fVjqjwuDyHpqfvQ9hN9OVARJw01YqyHE01Uz8S6Zo5/PvYA==","NoCertificadoSAT":"00001000000407404815","FechaTimbrado":"2020-05-27T13:10:16","UUID":"581ED080-53F4-4FA5-9DC0-B0B7882C350C","SelloCFD":"OaT1WAlAeoS7Au5k4Ds5BrlEvhf2k6T2fCSnGapVyWVQRg/XTdhDGbAsvPIhOOPBiJmXpibPGbVhu9lJo4Zw5mvHvsos7AkMpvZj545DhULPrbUTzlrWe/4/SyY5Q+Sy9jIqVhaaNWFyq79kVa5AZPjh3i5yWidxAOtEUT3nPXBg/5yRPmiKBDBOxklTBePrflmOBTdDadKf2gWI+lFIrbdz79+4AwkRvxURrNVyGCBVl56clyjXuwQnO70+1r6NRX1y8s5LGo1vIuhBvnrb1SmhBl2MSURa8s3NJhC79vfe5l/XCoFRGsWlqwnHA09+ZjmjcVYCTpLbJfNf20p0yg==","xmlns:tfd":"http://www.sat.gob.mx/TimbreFiscalDigital"}}}}}'
	,@idDocumentoPdf			 = 0
	,@idDocumentoXml			 = 0
	

*/

CREATE PROCEDURE [solicitud].[INS_SOLICITUD_MANUAL_SP_PASO2]  
	@rfcEmpresa					VARCHAR(13)
	,@idCliente					INT
	,@numeroContrato			VARCHAR(50)
    ,@idClase					VARCHAR(10) = 'Automovil'
	,@idTipoSolicitud			VARCHAR(50)
	,@idUsuario					INT
	,@VI_IdSolicitud			INT = NULL
	--,@serie						VARCHAR(250) = NULL
	--,@folio						VARCHAR(250) = NULL
	--,@uuid						VARCHAR(50)
	--,@fechaFactura				DATETIME
	--,@rfcEmisor					VARCHAR(13)
	--,@rfcReceptor				VARCHAR(13)
	--,@subTotal					FLOAT
	--,@descuento					FLOAT = NULL
	--,@traslado					FLOAT = NULL
	--,@retencion					FLOAT = NULL
	--,@trasladosXml				XML
	--,@retencionesXml			XML
	--,@total						FLOAT
	--,@xml						VARCHAR(max)
	--,@idDocumentoPdf			INT
	--,@idDocumentoXml			INT



AS

BEGIN
	BEGIN TRY 
		BEGIN TRANSACTION INS_SOLICITUD_NUEVO_MANUAL_SP
/********************************************************* INSERTAR SOLICITUD ********************************/
--		@VC_NOSOLICITUD			VARCHAR(20)
		

--		DECLARE @VT_Table TABLE (
--		[Index]			    INT IDENTITY(1,1),
--		[idPartida]			INT,
--		[cantidad]			INT,
--		[costoInicial]		float, 
--		[ventaInicial]		float
--	);

--	DECLARE @VT_Propiedades TABLE (
--		[Index]			    INT IDENTITY(1,1),
--		[idPropiedadClase]	INT,
--		[Valor]				XML
--	);

--	INSERT INTO @VT_Table
--		SELECT
--			I.N.value('(idPartida)[1]',	'INT'),
--			I.N.value('(cantidad)[1]',	'INT'),
--			I.N.value('(costoInicial)[1]',	'float'),
--			I.N.value('(ventaInicial)[1]',	'float')
--		FROM @partidas.nodes('/partidas/partida') I(N);


--SELECT @VC_NOSOLICITUD = (SELECT [solicitud].[SEL_NUMEROSOLICITUD_FN](@rfcEmpresa, @idCliente, @numeroContrato));

--INSERT INTO [solicitud].[Solicitud] (
--						 [rfcEmpresa]
--						,[idCliente]
--						,[numeroContrato]
--						,[idCentroCosto]
--						,[folio]
--						,[idTipoSolicitud]
--						,[idClase]
--						,[fechaCreacion]
--						,[fechaCita]
--						,[numero]
--						,[comentarios]
--						,[idEstatusSolicitud]
--						,[idUsuario]
--					) VALUES (
--						@rfcEmpresa,
--						@idCliente,
--						@numeroContrato,
--						@idCentroCosto,
--						@idCentroCostoFolio,
--						@idTipoSolicitud,
--						@idClase,
--						GETDATE(),
--						@fecha,
--						@VC_NOSOLICITUD,
--						@comentarios,
--						'ACTIVA',
--						@idUsuario
--					)

--	SET @VI_IdSolicitud = SCOPE_IDENTITY()

--	INSERT INTO solicitud.solicitudTemporal VALUES(@VI_IdSolicitud)

--	IF(@VI_IdSolicitud IS NOT NULL)
--		BEGIN
--			UPDATE [solicitud].[ContratoConsecutivo]
--			SET [consecutivo] = (
--				SELECT 
--					CAST([consecutivo] AS INT) + 1
--				FROM [solicitud].[ContratoConsecutivo]
--				WHERE 
--					[rfcEmpresa] = @rfcEmpresa AND
--					[idCliente] = @idCliente AND
--					[numeroContrato] = @numeroContrato
--			)
--			WHERE 
--				[rfcEmpresa] = @rfcEmpresa AND
--				[idCliente] = @idCliente AND
--				[numeroContrato] = @numeroContrato 
--		END

--	INSERT INTO [solicitud].[SolicitudObjeto](
--						 [idSolicitud]
--						,[rfcEmpresa]
--						,[idCliente]
--						,[numeroContrato]
--						,[idTipoSolicitud]
--						,[idObjeto]
--						,[idTipoObjeto]
--						,[idClase]
--						,[numeroOrden]
--						,[fechaAlta]
--						,[idUsuario]
--					) VALUES (
--						@VI_IdSolicitud,
--						@rfcEmpresa,
--						@idCliente,
--						@numeroContrato,
--						@idTipoSolicitud,
--						@idObjeto,
--						@idTipoObjeto,
--						@idClase,
--						(@VC_NOSOLICITUD +'-'+ CONVERT(VARCHAR(20), @idObjeto)),
--						@fecha,
--						@idUsuario
--					)

--	INSERT INTO [solicitud].[SolicitudPartida] (
--								 [idSolicitud]
--								,[idTipoSolicitud]
--								,[idClase]
--								,[rfcEmpresa]
--								,[idCliente]
--								,[numeroContrato]
--								,[idObjeto]
--								,[idTipoObjeto]
--								,[idPartida]
--								,[cantidad]
--								,[costoInicial]
--								,[ventaInicial]
--								,[idEstatusSolicitudPartida]
--								,[idUsuario]
--							) 
--							SELECT
--							 @VI_IdSolicitud
--								,@idTipoSolicitud
--								,@idClase
--								,@rfcEmpresa
--								,@idCliente
--								,@numeroContrato
--								,@idObjeto
--								,@idTipoObjeto
--								,idPartida
--								,cantidad
--								,costoInicial
--								,ventaInicial
--								,'ENESPERA'
--								,@idUsuario
--							FROM @VT_Table

--	INSERT INTO [solicitud].[SolicitudPropiedadClase] (
--							[idSolicitud]
--							,[idTipoSolicitud]
--							,[idClase]
--							,[rfcEmpresa]
--							,[idCliente]
--							,[numeroContrato]
--							,[idPropiedadClase]
--							,[valor]
--							,[fechaCaducidad]
--							,[idUsuario]
--					) VALUES (
--						@VI_IdSolicitud,
--						@idTipoSolicitud,
--						@idClase,
--						@rfcEmpresa,
--						@idCliente,
--						@numeroContrato,
--						(SELECT idPropiedadClase FROM [solicitud].[PropiedadClase] WHERE valor = @EstadodelaUnidad and idClase = @idClase),
--						NULL,
--						NULL,
--						@idUsuario
--					)
--		INSERT INTO [fase].[SolicitudEstatusPaso] (
--						  [idSolicitud]
--						 ,[rfcEmpresa]
--						 ,[idCliente]
--						 ,[numeroContrato]
--						 ,[idPaso]
--						 ,[idFase]
--						 ,[idClase]
--						 ,[idTipoSolicitud]
--						 ,[fechaIngreso]
--						 ,[idEstatus]
--						 ,[idUsuarioIngreso]
--					) VALUES (
--						@VI_IdSolicitud
--						,@rfcEmpresa
--						,@idCliente
--						,@numeroContrato
--						,(SELECT 
--						top 1	[idPaso] 
--						from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
--						,(SELECT 
--						top 1	idFase 
--						from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
--						,@idClase
--						,@idTipoSolicitud
--						,GETDATE()
--						,1
--						,@idUsuario
--					)

--	/************************************************************************+ INSERTAR PROVEEDOR *********************************************************/

--	DECLARE 
--		@numeroCotizacion	VARCHAR(30) 
--		,@VI_idCotizacion	INT
--		,@manejoDescuentoVenta INT
--		, @porcentajeDescuentoVenta FLOAT

--	SET @numeroCotizacion = (SELECT [solicitud].[SEL_NUMEROCOTIZACION_FN](@VI_IdSolicitud,@rfcEmpresa,@idTipoSolicitud,@idClase,@idCliente,@numeroContrato))

--	SELECT @manejoDescuentoVenta=manejoDescuentoVenta, @porcentajeDescuentoVenta=porcentajeDescuentoVenta 
--	FROM [Cliente].Cliente.Contrato

--		INSERT INTO [solicitud].[SolicitudCotizacion] (
--						 [idSolicitud]
--						,[idTipoSolicitud]
--						,[idClase]
--						,[rfcEmpresa]
--						,[idCliente]
--						,[numeroContrato]
--						,[idProveedorEntidad]
--						,[rfcProveedor]
--						,[numeroCotizacion]
--						,[fechaAlta]
--						,[idUsuario]
--						,[idEstatusCotizacion]
--					) VALUES (
--						 @VI_IdSolicitud
--						,@idTipoSolicitud
--						,@idClase
--						,@rfcEmpresa
--						,@idCliente
--						,@numeroContrato
--						,@idProveedorEntidad
--						,@rfcProveedor
--						,@numeroCotizacion
--						,GETDATE()
--						,@idUsuario
--						,'ENESPERA'
--					)

--				SET @VI_idCotizacion = SCOPE_IDENTITY()

--			INSERT INTO solicitud.SolicitudCotizacionPartida ([idCotizacion]
--						, [idSolicitud]
--						, [idTipoSolicitud]
--						, [idClase]
--						, [rfcEmpresa]
--						, [numeroContrato]
--						, [idCliente]
--						, [rfcProveedor]
--						, [idProveedorEntidad]
--						, [idObjeto]
--						, [idTipoObjeto]
--						, [idPartida]
--						, [cantidad]
--						, [costo]
--						, [venta]
--						, [idEstatusCotizacionPartida]
--						, [fechaEstatus]
--						, [idUsuario])
--					SELECT @VI_idCotizacion
--						, @VI_IdSolicitud
--						, @idTipoSolicitud
--						, @idClase
--						, @rfcEmpresa
--						, @numeroContrato
--						, @idCliente
--						, @rfcProveedor
--						, @idProveedorEntidad
--						, @idObjeto
--						, @idTipoObjeto
--						, idPartida
--						, cantidad
--						, costoInicial
--						, ventaInicial
--						, 'ENESPERA'
--						, GETDATE()
--						, @idUsuario
--					FROM @VT_Table

--			IF(@manejoDescuentoVenta = 1)
--					BEGIN
--						INSERT INTO [solicitud].[SolicitudCotizacionPartidaDescuento] ([idCotizacion]
--							, [idSolicitud]
--							, [idTipoSolicitud]
--							, [idClase]
--							, [rfcEmpresa]
--							, [numeroContrato]
--							, [idCliente]
--							, [rfcProveedor]
--							, [idProveedorEntidad]
--							, [idObjeto]
--							, [idTipoObjeto]
--							, [idPartida]
--							, [porcentajeDescuentoVenta]
--							, [descuentoVenta]
--							, [fecha]
--							, [idUsuario])
--						SELECT @VI_idCotizacion
--							, @VI_IdSolicitud
--							, @idTipoSolicitud
--							, @idClase
--							, @rfcEmpresa
--							, @numeroContrato
--							, @idCliente
--							, @rfcProveedor
--							, @idProveedorEntidad
--							, @idObjeto
--							, @idTipoObjeto
--							, idPartida
--							, @porcentajeDescuentoVenta
--							, ((ventaInicial * @porcentajeDescuentoVenta) / 100)
--							, GETDATE()
--							, @idUsuario
--						FROM @VT_Table
--					END

--			INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
--					(fechaAlta
--					,idCotizacion
--					,idSolicitud
--					,idTipoSolicitud
--					,idClase
--					,rfcEmpresa
--					,idCliente
--					,numeroContrato
--					,idProveedorEntidad
--					,rfcProveedor
--					,idEstatusCotizacion
--					,idUsuario)
--					VALUES 
--					(GETDATE()
--					,@VI_idCotizacion
--					,@VI_IdSolicitud
--					,@idTipoSolicitud
--					,@idClase
--					,@rfcEmpresa
--					,@idCliente
--					,@numeroContrato
--					,@idProveedorEntidad
--					,@rfcProveedor
--					,'ENESPERA',@idUsuario)

--		EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
--		@idSolicitud  = @VI_IdSolicitud,  
--		 @idTipoSolicitud = @idTipoSolicitud,  
--		 @idClase  = @idClase ,  
--		 @rfcEmpresa  = @rfcEmpresa ,  
--		 @idCliente   = @idCliente,  
--		 @numeroContrato  = @numeroContrato,  
--		 @idUsuario   = @idUsuario,  
--		 @err    = ''


--/************************************************ SE INSERTA COMPROBANTE DE RECEPCION **********************************************/

--	DECLARE @idComprobanteRecepcion INT
--			,@idDocumentoClase INT

--	INSERT INTO solicitud.ComprobanteRecepcion(	
--		idSolicitud
--		,idTipoSolicitud
--		,idClase
--		,rfcEmpresa
--		,idCliente
--		,numeroContrato
--		,idObjeto
--		,idTipoObjeto
--		,idProveedorEntidad
--		,rfcProveedor
--		,[version]
--		,fechaAlta
--		,idUsuario)
--		VALUES(	@VI_IdSolicitud
--				,@idTipoSolicitud
--				,@idClase
--				,@rfcEmpresa
--				,@idCliente
--				,@numeroContrato
--				,@idObjeto
--				,@idTipoObjeto
--				,@idProveedorEntidad
--				,@rfcProveedor
--				,1
--				,GETDATE()
--				,@idUsuario)

--	SET @idComprobanteRecepcion=@@IDENTITY

--	INSERT INTO solicitud.ComprobanteRecepcionPropiedades (	
--		idComprobanteRecepcion
--		,idSolicitud
--		,idTipoSolicitud
--		,idClase
--		,rfcEmpresa
--		,idCliente
--		,numeroContrato
--		,idObjeto
--		,idTipoObjeto
--		,idProveedorEntidad
--		,rfcProveedor
--		,[version]
--		,idPropiedadClase
--		,idAgrupacion
--		,valor)

--		SELECT	@idComprobanteRecepcion
--				,@VI_IdSolicitud
--				,@idTipoSolicitud
--				,@idClase
--				,@rfcEmpresa
--				,@idCliente
--				,@numeroContrato
--				,@idObjeto
--				,@idTipoObjeto,
--				@idProveedorEntidad
--				,@rfcProveedor
--				,1
--				,idPropiedadClase
--				,idAgrupacion
--				, CASE
--					WHEN idPropiedadClase = 29 THEN ''
--					WHEN idPropiedadClase = 33 THEN 'false'
--					ELSE valor
--					END
--		FROM	solicitud.ComprobanteRecepcionPropiedades
--		WHERE idComprobanteRecepcion = 108

--		SELECT
--		@idDocumentoClase = idDocumentoClase
--			FROM [Solicitud].[documento].[Paso]
--			WHERE nombre = 'Comprobante de Recepción'
--			AND idClase = @idClase
--			and idTipoSolicitud = @idTipoSolicitud
--			AND activo = 1

--	INSERT INTO [Solicitud].[documento].[SolicitudObjetoPaso]
--	--INSERT INTO [Solicitud].[documento].[SolicitudPaso]
	
--			SELECT
--				[idDocumentoClase]
--				,[idPaso]
--				,[idFase]
--				,@idClase
--				,@idCliente
--				,@numeroContrato
--				,@idTipoSolicitud
--				,@VI_IdSolicitud
--				,@rfcEmpresa
--				,@idTipoObjeto
--				,@idObjeto
--				,1
--				,'.pdf'
--				,0
--				,[vigencia]
--				,(SELECT
--					numeroOrden
--					FROM [Solicitud].[solicitud].[SolicitudObjeto]
--					WHERE idSolicitud = @VI_IdSolicitud
--					AND idClase = @idClase
--					AND rfcEmpresa = @rfcEmpresa
--					AND idCliente = @idCliente
--					AND numeroContrato = @numeroContrato
--					AND idTipoSolicitud = @idTipoSolicitud)
--				,@idUsuario
--				,GETDATE()
--				,0
--				,null
--				,''
--			FROM
--			[Solicitud].[documento].[Paso]
--			WHERE idDocumentoClase = @idDocumentoClase

--	EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
--		@idSolicitud  = @VI_IdSolicitud,  
--		 @idTipoSolicitud = @idTipoSolicitud,  
--		 @idClase  = @idClase ,  
--		 @rfcEmpresa  = @rfcEmpresa ,  
--		 @idCliente   = @idCliente,  
--		 @numeroContrato  = @numeroContrato,  
--		 @idUsuario   = @idUsuario,  
--		 @err    = ''


--	/************************************************* ENVIA A APROBACION ***************************************************/

--	EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
--		@idSolicitud  = @VI_IdSolicitud,  
--		 @idTipoSolicitud = @idTipoSolicitud,  
--		 @idClase  = @idClase ,  
--		 @rfcEmpresa  = @rfcEmpresa ,  
--		 @idCliente   = @idCliente,  
--		 @numeroContrato  = @numeroContrato,  
--		 @idUsuario   = @idUsuario,  
--		 @err    = ''

--	/**************************************************** APRUEBA PARTIDAS ******************************/

--	UPDATE SP
--		SET idEstatusCotizacionPartida = 'APROBADA'
--	FROM [solicitud].[SolicitudCotizacionPartida] SP 
--	WHERE 
--		idSolicitud = @VI_IdSolicitud
--		AND idTipoSolicitud = @idTipoSolicitud
--		AND idClase = @idClase
--		AND rfcEmpresa = @rfcEmpresa
--		AND idCliente = @idCliente
--		AND numeroContrato = @numeroContrato
--		AND rfcProveedor = @rfcProveedor
--		AND idProveedorEntidad = @idProveedorEntidad
--		AND SP.idCotizacion = @VI_idCotizacion

--		UPDATE [solicitud].[SolicitudCotizacion]
--					SET idEstatusCotizacion='APROBADA'
--					WHERE idCotizacion= @VI_idCotizacion

--		INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
--			(fechaAlta
--			,idCotizacion
--			,idSolicitud
--			,idTipoSolicitud
--			,idClase,rfcEmpresa
--			,idCliente
--			,numeroContrato
--			,idProveedorEntidad
--			,rfcProveedor
--			,idEstatusCotizacion
--			,idUsuario)
--		VALUES 
--		(GETDATE()
--		,@VI_idCotizacion
--		,@VI_IdSolicitud
--		,@idTipoSolicitud
--		,@idClase,@rfcEmpresa
--		,@idCliente
--		,@numeroContrato
--		,@idProveedorEntidad
--		,@rfcProveedor 
--		,'APROBADA'
--		,@idUsuario)

--		INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] (
--			[idCotizacion],
--			[idSolicitud]
--			,[idTipoSolicitud]
--			,[idClase]
--			,[rfcEmpresa]
--			,[numeroContrato]
--			,[idCliente]
--			,[rfcProveedor]
--			,[idProveedorEntidad]
--			,[idObjeto]
--			,[idTipoObjeto]
--			,[idPartida]
--			,[idUsuarioAprobador]
--			,[fechaAprobacion])
--		SELECT [idCotizacion]
--			,SP.[idSolicitud]
--			,SP.[idTipoSolicitud]
--			,SP.[idClase]
--			,SP.[rfcEmpresa]
--			,SP.[numeroContrato]
--			,SP.[idCliente]
--			,SP.[rfcProveedor]
--			,SP.[idProveedorEntidad]
--			,SP.[idObjeto]
--			,SP.[idTipoObjeto]
--			,SP.[idPartida]
--			,@idUsuario
--			,GETDATE()
--		FROM [solicitud].[SolicitudCotizacionPartida] SP 
--		WHERE 
--			idSolicitud = @VI_IdSolicitud
--			AND idTipoSolicitud = @idTipoSolicitud
--			AND idClase = @idClase
--			AND rfcEmpresa = @rfcEmpresa
--			AND idCliente = @idCliente
--			AND numeroContrato = @numeroContrato
--			AND rfcProveedor = @rfcProveedor
--			AND idProveedorEntidad = @idProveedorEntidad
--			AND SP.idCotizacion = @VI_idCotizacion

--		EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
--		@idSolicitud  = @VI_IdSolicitud,  
--		 @idTipoSolicitud = @idTipoSolicitud,  
--		 @idClase  = @idClase ,  
--		 @rfcEmpresa  = @rfcEmpresa ,  
--		 @idCliente   = @idCliente,  
--		 @numeroContrato  = @numeroContrato,  
--		 @idUsuario   = @idUsuario,  
--		 @err    = ''

--	/************************************************ CREA HOJA DE TRABAJO *******************************************/
--	DECLARE @idDocumentoClaseHoja INT
	
--		SELECT
--		@idDocumentoClaseHoja = idDocumentoClase
--			FROM [Solicitud].[documento].[Paso]
--			WHERE nombre = 'Hoja de Trabajo'
--			AND idClase = @idClase
--			and idTipoSolicitud = @idTipoSolicitud
--			AND activo = 1

--	--INSERT INTO [Solicitud].[documento].[SolicitudPaso]
--	INSERT INTO [Solicitud].[documento].[SolicitudObjetoPaso]	
--			SELECT
--				[idDocumentoClase]
--				,[idPaso]
--				,[idFase]
--				,@idClase
--				,@idCliente
--				,@numeroContrato
--				,@idTipoSolicitud
--				,@VI_IdSolicitud
--				,@rfcEmpresa
--				,@idTipoObjeto
--				,@idObjeto
--				,1
--				,'.pdf'
--				,0
--				,[vigencia]
--				,(SELECT
--					numeroOrden
--					FROM [Solicitud].[solicitud].[SolicitudObjeto]
--					WHERE idSolicitud = @VI_IdSolicitud
--					AND idClase = @idClase
--					AND rfcEmpresa = @rfcEmpresa
--					AND idCliente = @idCliente
--					AND numeroContrato = @numeroContrato
--					AND idTipoSolicitud = @idTipoSolicitud)
--				,@idUsuario
--				,GETDATE()
--				,0
--				,null
--				,''
--			FROM
--			[Solicitud].[documento].[Paso]
--			WHERE idDocumentoClase = @idDocumentoClaseHoja



 -- /************************************************ Insertar factura *******************************************/

	--if (@serie='') set @serie=NULL
	--if (@folio='') set @folio=NULL
  
 -- INSERT INTO [Solicitud].[cxp].[Factura] (
	--	[uuid]
	--	,[serie]
	--	,[folio]
	--	,[fechaFactura]
	--	,[rfcEmisor]
	--	,[rfcReceptor]
	--	,[subtotal]
	--	,[descuento]
	--	,[total]
	--	,[saldo]
	--	,[idUsuario]
	--	,[xml]
	--	,[idDocumentoXml]
	--	,[idDocumentoPdf]
	--	,[traslado]
	--	,[retencion]
	--)VALUES(
	--	@uuid
	--	,ISNULL(@serie,'')
	--	,ISNULL(@folio,'')
	--	,@fechaFactura
	--	,@rfcEmisor
	--	,@rfcReceptor
	--	,@subTotal
	--	,@descuento
	--	,@total
	--	,@total
	--	,@idUsuario
	--	,@xml
	--	,@idDocumentoXml
	--	,@idDocumentoPdf
	--	,@traslado
	--	,@retencion
	--)

	--if (@serie is null and @folio is null)
	--begin
	--	update [Solicitud].[cxp].[Factura] SET serie = SUBSTRING(@uuid,25,12) where uuid = @uuid
	--end

	--IF(@trasladosXml IS NOT NULL)
	--BEGIN

	--	DECLARE @tbl_traslados AS TABLE (
	--		impuesto		varchar(3),			
	--		importe			float,
	--		tasa			float
	--	)

	--	INSERT INTO @tbl_traslados
	--	SELECT   
	--		ParamValues.col.value('impuesto[1]','varchar(3)')
	--		,ParamValues.col.value('importe[1]','float')
	--		,ParamValues.col.value('tasa[1]','float')
	--	FROM @trasladosXml.nodes('traslados/traslado') AS ParamValues(col)  
	
	--	INSERT INTO [Solicitud].[cxp].[FacturaImpuesto] 
	--		SELECT
	--			@uuid
	--			,T.tasa
	--			,importe
	--			,TFI.idTipoFacturaImpuesto
	--		FROM @tbl_traslados T 
	--		INNER JOIN [Solicitud].[cxp].[TipoFacturaImpuesto] TFI
	--			ON T.impuesto = TFI.clave
	--		WHERE TFI.idTipo = 1

	--END

	--IF(@retencionesXml IS NOT NULL)
	--BEGIN

	--	DECLARE @tbl_retenciones AS TABLE (
	--		impuesto		varchar(3),	
	--		importe			float,
	--		tasa			float
	--	)

	--	INSERT INTO @tbl_retenciones
	--	SELECT   
	--		ParamValues.col.value('impuesto[1]','varchar(3)')
	--		,ParamValues.col.value('importe[1]','float')
	--		,ParamValues.col.value('tasa[1]','float')
	--	FROM @retencionesXml.nodes('retenciones/retencion') AS ParamValues(col)  
	
	--	INSERT INTO [Solicitud].[cxp].[FacturaImpuesto] 
	--		SELECT
	--			@uuid
	--			,r.tasa
	--			,importe
	--			,TFI.idTipoFacturaImpuesto
	--		FROM @tbl_retenciones R
	--		INNER JOIN [Solicitud].[cxp].[TipoFacturaImpuesto] TFI
	--			ON R.impuesto = TFI.clave
	--		WHERE TFI.idTipo = 2

	--END

	--INSERT INTO cxp.SolicitudCotizacionFactura(  
	--			idCotizacion,  
	--			idSolicitud,  
	--			idTipoSolicitud,  
	--			idClase,  
	--			rfcEmpresa,  
	--			idCliente,  
	--			numeroContrato,  
	--			idProveedorEntidad,  
	--			rfcProveedor,  
	--			uuid  
	--		   ) 
	--   VALUES
	--	(
	--		@VI_idCotizacion,  
	--		@VI_IdSolicitud,  
	--		@idTipoSolicitud,  
	--		@idClase,  
	--		@rfcEmpresa,  
	--		@idCliente,  
	--		@numeroContrato,  
	--		@idProveedorEntidad,  
	--		@rfcProveedor,  
	--		@uuid  
	--	)


 --   INSERT INTO cxp.SolicitudCotizacionFacturaDetalle(  
	--			idCotizacion,  
	--			idSolicitud,  
	--			idTipoSolicitud,  
	--			idClase,  
	--			rfcEmpresa,  
	--			idCliente,  
	--			numeroContrato,  
	--			idProveedorEntidad,
	--			rfcProveedor,  
	--			uuid,  
	--			idObjeto,  
	--			idTipoObjeto,  
	--			idPartida,  
	--			montoAbonado,  
	--			fechaAbono,  
	--			idUsuario  
	--		   ) 

	--	   SELECT
	--			@VI_idCotizacion,  
	--			@VI_IdSolicitud,  
	--			@idTipoSolicitud,  
	--			@idClase,  
	--			@rfcEmpresa,  
	--			@idCliente,  
	--			@numeroContrato,  
	--			@idProveedorEntidad,  
	--			@rfcProveedor,  
	--			@uuid,  
	--			@idObjeto,  
	--			@idTipoObjeto,  
	--			SCP.idPartida,  
	--			SCP.costo,  
	--			GETDATE(),  
	--			@idUsuario  
	--	   FROM @VT_Table p
	--	   INNER JOIN solicitud.SolicitudCotizacionPartida SCP
	--				  ON SCP.idPartida = p.idPartida
	--		WHERE SCP.idSolicitud = @VI_IdSolicitud



	--EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
	--	@idSolicitud  = @VI_IdSolicitud,  
	--	 @idTipoSolicitud = @idTipoSolicitud,  
	--	 @idClase  = @idClase ,  
	--	 @rfcEmpresa  = @rfcEmpresa ,  
	--	 @idCliente   = @idCliente,  
	--	 @numeroContrato  = @numeroContrato,  
	--	 @idUsuario   = @idUsuario,  
	--	 @err    = ''

	--/******************************************************************* SE AVANZA A ENTREGA *****************************************************************/
	DECLARE
		@tokenAuditoria TABLE (idToken int, token varchar(6))

	DECLARE @token VARCHAR(6)

	select 'prueba1'

	INSERT INTO @tokenAuditoria
	EXEC [token].[INS_TOKEN_PASO_SP] @VI_IdSolicitud, 'TerminoTrabajo',@idUsuario, ''

	SELECT 
		@token = token
	FROM @tokenAuditoria

	select 'prueba2'

	EXEC [token].[UPD_TOKEN_PASO_SP] @VI_IdSolicitud, @token, @idUsuario, ''

	EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
		@idSolicitud  = @VI_IdSolicitud,  
		 @idTipoSolicitud = @idTipoSolicitud,  
		 @idClase  = @idClase ,  
		 @rfcEmpresa  = @rfcEmpresa ,  
		 @idCliente   = @idCliente,  
		 @numeroContrato  = @numeroContrato,  
		 @idUsuario   = @idUsuario,  
		 @err    = ''

	select 'prueba3'
	/*********************************************************** SE AVANZA A COBRANZA *******************************************************/

	DECLARE
		@tokenEntrega TABLE (idToken int, token varchar(6))

	DECLARE @tokenE VARCHAR(6)

	select 'prueba4'

	INSERT INTO @tokenEntrega
	EXEC [token].[INS_TOKEN_PASO_SP] @VI_IdSolicitud, 'Entrega',@idUsuario, ''

	SELECT 
		@tokenE = token
	FROM @tokenEntrega

	EXEC [token].[UPD_TOKEN_PASO_SP] @VI_IdSolicitud, @tokenE, @idUsuario, ''

	select 'prueba5'

	EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
		@idSolicitud  = @VI_IdSolicitud,  
		 @idTipoSolicitud = @idTipoSolicitud,  
		 @idClase  = @idClase ,  
		 @rfcEmpresa  = @rfcEmpresa ,  
		 @idCliente   = @idCliente,  
		 @numeroContrato  = @numeroContrato,  
		 @idUsuario   = @idUsuario,  
		 @err    = ''

	/******************** SE AVANZA A PREFACTURA GENERADA ****************/
	--select  @VI_IdSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idUsuario,''

	COMMIT TRANSACTION INS_SOLICITUD_NUEVO_MANUAL_SP

	select 'prueba6'

	--EXEC cxc.INS_FACTURA_PROCESACOMPRA_SP_MANUAL @VI_IdSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idUsuario,''
	--DECLARE @idFactura INT = (SELECT idFactura FROM [Solicitud].[cxc].[factura] WHERE idSolicitud = @VI_IdSolicitud), @fet datetime = GETDATE();
	--EXEC cxc.INS_FACTURAAGRUPADA_MANUAL_SP @idClase, @rfcEmpresa, @idCliente, @numeroContrato, @fet, @fet, NULL, NULL, 0, 0, 'xml', @idFactura, @idUsuario, @VI_IdSolicitud, @idTipoSolicitud
	
	select 'prueba7'

	END TRY
		BEGIN CATCH
			SELECT ERROR_MESSAGE()
			ROLLBACK TRANSACTION INS_SOLICITUD_NUEVO_MANUAL_SP
		END CATCH

END


go

