

-- =============================================
-- Author: Gerardo Zamudio González
-- Create date: 24-06-2019
-- Description: Inserta la evidencia de una solicitud (Documentos)
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [documento].[INS_SOLICITUDOBJETOEVIDENCIA_SP]  'DIC0503123MD3', 'Automovil' ,78, '123PEMEX', 29, 118, 1256, 17268, 2, NULL;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [documento].[INS_SOLICITUDOBJETOEVIDENCIA_SP]
	@rfcEmpresa				varchar(13),
	@idClase				varchar(10),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	@idSolicitud			int,
	@idTipoObjeto			int,
	@idObjeto				int,
	@idFileServer			int,
	@idUsuario				int,
	@err					varchar(500)OUTPUT
AS


BEGIN
	DECLARE @IDSOL INT = 0,
	@DEF INT = 1,
	@idTipoSolicitud varchar(10) = '';


SET @IDSOL = (SELECT TOP 1
	CAST([idSolicitudObjetoEvidencia] AS INT) AS [int]
  FROM [Solicitud].[documento].[SolicitudObjetoEvidencia]
WHERE idSolicitud = @idSolicitud AND
	[idClase] = @idClase AND
	[rfcEmpresa] = @rfcEmpresa AND
	[idCliente] = @idCliente AND 
	numeroContrato = @numeroContrato AND
	idTipoObjeto = @idTipoObjeto AND
	idObjeto = @idObjeto
	ORDER BY [idSolicitudObjetoEvidencia] DESC);

set @idTipoSolicitud = (
SELECT TOP 1
	[idTipoSolicitud]
  FROM [solicitud].[Solicitud]
WHERE idSolicitud = @idSolicitud AND
	[idClase] = @idClase AND
	[rfcEmpresa] = @rfcEmpresa AND
	[idCliente] = @idCliente AND 
	numeroContrato = @numeroContrato 
);

	IF (@IDSOL IS NULL)
		BEGIN
			INSERT INTO [documento].[SolicitudObjetoEvidencia] (
				[idSolicitud]
				,[idTipoObjeto]
				,[idTipoSolicitud]
				,[idClase]
				,[rfcEmpresa]
				,[idCliente]
				,[numeroContrato]
				,[idObjeto]
				,[idSolicitudObjetoEvidencia]
				,[idFileServer]
			) VALUES (
				@idSolicitud
				,@idTipoObjeto
				,@idTipoSolicitud
				,@idClase
				,@rfcEmpresa
				,@idCliente
				,@numeroContrato
				,@idObjeto
				,@DEF
				,@idFileServer
			)
		END
	ELSE 
		BEGIN
			INSERT INTO [documento].[SolicitudObjetoEvidencia] (
				[idSolicitud]
				,[idTipoObjeto]
				,[idTipoSolicitud]
				,[idClase]
				,[rfcEmpresa]
				,[idCliente]
				,[numeroContrato]
				,[idObjeto]
				,[idSolicitudObjetoEvidencia]
				,[idFileServer]
			) VALUES (
				@idSolicitud
				,@idTipoObjeto
				,@idTipoSolicitud
				,@idClase
				,@rfcEmpresa
				,@idCliente
				,@numeroContrato
				,@idObjeto
				,(@IDSOL + 1)
				,@idFileServer
			)
		END
END
go

