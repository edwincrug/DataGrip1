
-- =============================================
-- Author: José Etmanuel Hernández REjón
-- Create date: 05/07/2019
-- Description: Autoriza una partida
-- ============== Versionamiento ================
/*
	Fecha			Autor	Descripción 
	28/05/2020		GZG		Actualiza el estatus de una partida sin validar las reglas de la solicitud en el sp
	07/12/2020		JLG		Se agregaron validaciones para autorizar por n personas
	*- Testing...
	
	EXEC [solicitud].[UPD_PARTIDA_ESTATUS_SP]
	562,
	'Imagen',
	'Automovil',
	'ASE0508051B6',
	'OKW190528LZ9',
	519,
	185,
	'43',
	746044,
	6115,
	1154,
	'APROBADA',
	''
	
*/
-- =============================================

CREATE PROCEDURE [solicitud].[UPD_PARTIDA_ESTATUS_SP]
	@idSolicitud					INT,
	@idTipoSolicitud				VARCHAR(10),
	@idClase						VARCHAR(10),
	@rfcEmpresa						VARCHAR(13),
	@rfcProveedor					VARCHAR(13),
	@idProveedorEntidad				INT,
	@idCliente						INT,
	@numeroContrato					VARCHAR(50),
	@xmlPartidas					XML,
	@idUsuario						INT,
	@idCotizacion					INT,
	@err							VARCHAR(500) OUTPUT
AS
BEGIN
	BEGIN TRY  
		BEGIN TRANSACTION; 
			
			DECLARE @aplicaCentrodeCosto INT,
					@ventaTotalSolicitudes FLOAT,
					@noAutPendientes INT,
					@idEstatusCotizacionPartida VARCHAR(10)

			DECLARE @CCF TABLE (
					idCentroCosto INT,
					nombre VARCHAR(200),
					presupuestoCC FLOAT,
					folio VARCHAR(200),
					presupuestoCF FLOAT,
					fechaInicio DATETIME,
					fechaFin DATETIME,
					gastado float,
					restante FLOAT)

			DECLARE @listadoPartidas TABLE(
					id INT IDENTITY,
					idPartida INT,
					accion varchar(20))

			INSERT INTO @listadoPartidas
			SELECT 	I.N.value('idPartida[1]', 'INT'),
					I.N.value('accion[1]', 'VARCHAR(20)')
			FROM	@xmlPartidas.nodes('/partidas/partida') I(N);

			--quitar JLG
			--DELETE @listadoPartidas WHERE idPartida IN (SELECT idPartida FROM solicitud.SolicitudCotizacionAprobador WHERE idCotizacion = @idCotizacion)

			DECLARE @fechaInicioCentroCosto DATETIME, @fechaFinCentroCosto DATETIME, @restaCC FLOAT;

			SELECT	@aplicaCentrodeCosto = manejoDePresupuesto
			FROM	[cliente].[cliente].[Contrato] 
			WHERE	rfcEmpresa		= @rfcEmpresa
			AND		idCliente		= @idCliente
			AND		numeroContrato	= @numeroContrato
			AND		idClase			= @idClase
			AND		activo			= 1

			DECLARE @contador	INT = 1,
					@nPartidas	INT = (SELECT COUNT(*) FROM @listadoPartidas),
					@accion		VARCHAR(20),
					@idPartida	INT

			WHILE(@contador <= @nPartidas)
				BEGIN
					SELECT	@accion		= accion,
							@idPartida	= idPartida
					FROM	@listadoPartidas
					WHERE	id			= @contador

					/*CUANDO SE APRUEBA UNA PARTIDA ***************************************************************************/
					IF(@accion = 'APROBADA')
						BEGIN
							/* SI LA FECHA ACTUAL SE ENCUENTRA EN EL RANGO DE TERMINO DEL CONTRATO ***************************************************************************/
							IF EXISTS(	SELECT	*
										FROM	Cliente.cliente.Contrato 
										WHERE	GETDATE() BETWEEN fechaInicio AND fechaFin
										AND		numeroContrato	= @numeroContrato
										AND		idCliente		= @idCliente
										AND		rfcEmpresa		= @rfcEmpresa
										AND		activo			= 1)
								BEGIN
									/* SI APLICA CENTRO DE COSTO ***************************************************************************/
									IF (@aplicaCentrodeCosto > 0 AND @aplicaCentrodeCosto IS NOT NULL)
										BEGIN
											INSERT INTO @CCF
											EXECUTE Cliente.contrato.SEL_CENTRODECOSTO_FOLIO_SP @rfcEmpresa, @idCliente, @numeroContrato, @idUsuario, NULL
			
											SELECT	@fechaInicioCentroCosto = CC.fechaInicio,
													@fechaFinCentroCosto	= CC.fechaFin,
													@restaCC				= CC.restante
											FROM	@CCF AS CC
											INNER	JOIN Solicitud.solicitud.Solicitud AS S ON S.idCentroCosto = CC.idCentroCosto 
											AND		S.folio			= CC.folio
											WHERE	S.idSolicitud	= @idSolicitud

											SELECT	@ventaTotalSolicitudes = SUM(subTotalVenta)
											FROM	[solicitud].[SEL_TOTALES_SOLICITUD_VW] SV
											INNER	JOIN Solicitud.solicitud.Solicitud S ON S.idSolicitud = SV.idSolicitud
											WHERE	S.folio = (SELECT folio FROM Solicitud.solicitud.Solicitud WHERE idSolicitud = @idSolicitud)

											/* SI EL TOTAL DE LAS VENTAS DE LAS SOLICITUDES ESTA EN EL RANGO DEL FOLIO ***************************************************************************/
											IF(@ventaTotalSolicitudes <= @restaCC)
												BEGIN
													/*** SI LA FECHA ACTUAL SE ENCUENTRA EN EL RANGO DE TERMINO DEL CENTRO DE COSTO ***************************************************************************/
													IF((GETDATE() BETWEEN @fechaInicioCentroCosto AND @fechaFinCentroCosto))
														BEGIN
															INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
																		[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
																		[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[idEstatusAprobador],[fechaAprobacion])
															SELECT	[idCotizacion],SP.[idSolicitud],SP.[idTipoSolicitud],SP.[idClase],SP.[rfcEmpresa],SP.[numeroContrato],SP.[idCliente],
																	SP.[rfcProveedor],SP.[idProveedorEntidad],SP.[idObjeto],SP.[idTipoObjeto],SP.[idPartida],@idUsuario,@accion,GETDATE()
															FROM	[solicitud].[SolicitudCotizacionPartida] SP 
															WHERE	idSolicitud			= @idSolicitud
															AND		idTipoSolicitud		= @idTipoSolicitud
															AND		idClase				= @idClase
															AND		rfcEmpresa			= @rfcEmpresa
															AND		idCliente			= @idCliente
															AND		numeroContrato		= @numeroContrato
															AND		rfcProveedor		= @rfcProveedor
															AND		idProveedorEntidad	= @idProveedorEntidad
															AND		SP.idCotizacion		= @idCotizacion
															AND		sp.idPartida		= @idPartida

															/***Validamos si la partida esta configurada para ser autorizada por varias personas*/
															IF EXISTS(	SELECT 1
																		FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
																		WHERE	idClase				= @idClase
																		AND		idTipoSolicitud		= @idTipoSolicitud
																		AND		rfcEmpresa			= @rfcEmpresa
																		AND		idCliente			= @idCliente
																		AND		numeroContrato		= @numeroContrato
																		AND		idPartida			= @idPartida)
																BEGIN
																	/***Validamos si la partida esta configurada para ser autorizada por varias personas*/
																	SET @noAutPendientes= [solicitud].SEL_VALIDAAUTORIZACIONES_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,@idPartida,@idCotizacion)
																	IF @noAutPendientes=0
																		BEGIN
																			SET @idEstatusCotizacionPartida = [solicitud].[solicitud].SEL_VALIDAESTATUSPARTIDA_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,@idPartida)
																			/*Esta actualizacion solo se hace cuando ya no hay autorizaciones pendientes*/
																			UPDATE	SP 
																			SET		idEstatusCotizacionPartida = @idEstatusCotizacionPartida
																			FROM	[solicitud].[SolicitudCotizacionPartida] SP 
																			WHERE	idSolicitud			= @idSolicitud
																			AND		idTipoSolicitud		= @idTipoSolicitud
																			AND		idClase				= @idClase
																			AND		rfcEmpresa			= @rfcEmpresa
																			AND		idCliente			= @idCliente
																			AND		numeroContrato		= @numeroContrato
																			AND		rfcProveedor		= @rfcProveedor
																			AND		idProveedorEntidad	= @idProveedorEntidad
																			AND		SP.idCotizacion		= @idCotizacion
																			AND		sp.idPartida		= @idPartida
																		END
																END
															ELSE
																BEGIN
																	UPDATE	SP 
																	SET		idEstatusCotizacionPartida = @accion
																	FROM	[solicitud].[SolicitudCotizacionPartida] SP 
																	WHERE	idSolicitud			= @idSolicitud
																	AND		idTipoSolicitud		= @idTipoSolicitud
																	AND		idClase				= @idClase
																	AND		rfcEmpresa			= @rfcEmpresa
																	AND		idCliente			= @idCliente
																	AND		numeroContrato		= @numeroContrato
																	AND		rfcProveedor		= @rfcProveedor
																	AND		idProveedorEntidad	= @idProveedorEntidad
																	AND		SP.idCotizacion		= @idCotizacion
																	AND		sp.idPartida		= @idPartida
																END
															SELECT 'Se actualizaron las partidas' as msj
														END
													ELSE
														BEGIN
															SET @err = 'El centro de costo ha expirado..'
														END
												END
											ELSE
												BEGIN
													SET @err = 'La venta de la solicitud excede el monto del centro de costo.'
												END
										END
									/*** SI NO APLICA CENTRO DE COSTO ***************************************************************************/
									ELSE
										BEGIN
											INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
														[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
														[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[idEstatusAprobador],[fechaAprobacion])
											SELECT	[idCotizacion],SP.[idSolicitud],SP.[idTipoSolicitud],SP.[idClase],SP.[rfcEmpresa],SP.[numeroContrato],SP.[idCliente],
													SP.[rfcProveedor],SP.[idProveedorEntidad],SP.[idObjeto],SP.[idTipoObjeto],SP.[idPartida],@idUsuario,@accion,GETDATE()
											FROM	[solicitud].[SolicitudCotizacionPartida] SP 
											WHERE 	idSolicitud			= @idSolicitud
											AND		idTipoSolicitud		= @idTipoSolicitud
											AND		idClase				= @idClase
											AND		rfcEmpresa			= @rfcEmpresa
											AND		idCliente			= @idCliente
											AND		numeroContrato		= @numeroContrato
											AND		rfcProveedor		= @rfcProveedor
											AND		idProveedorEntidad	= @idProveedorEntidad
											AND		SP.idCotizacion		= @idCotizacion
											AND		sp.idPartida		= @idPartida
											
											/***Validamos si la partida esta configurada para ser autorizada por varias personas*/
											IF EXISTS(	SELECT 1
														FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
														WHERE	idClase				= @idClase
														AND		idTipoSolicitud		= @idTipoSolicitud
														AND		rfcEmpresa			= @rfcEmpresa
														AND		idCliente			= @idCliente
														AND		numeroContrato		= @numeroContrato
														AND		idPartida			= @idPartida)
												BEGIN
													

													/*Recuperamos el numero de autorizaciones pendientes de la partida*/
													SET @noAutPendientes= [solicitud].SEL_VALIDAAUTORIZACIONES_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,@idPartida,@idCotizacion)
													IF @noAutPendientes=0
														BEGIN
															SET @idEstatusCotizacionPartida = [solicitud].[solicitud].SEL_VALIDAESTATUSPARTIDA_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,@idPartida)

															/*Esta actualizacion solo se hace cuando ya no hay autorizaciones pendientes*/
															UPDATE	SP
															SET		idEstatusCotizacionPartida = @idEstatusCotizacionPartida
															FROM	[solicitud].[SolicitudCotizacionPartida] SP 
															WHERE 	idSolicitud			= @idSolicitud
															AND		idTipoSolicitud		= @idTipoSolicitud
															AND		idClase				= @idClase
															AND		rfcEmpresa			= @rfcEmpresa
															AND		idCliente			= @idCliente
															AND		numeroContrato		= @numeroContrato
															AND		rfcProveedor		= @rfcProveedor
															AND		idProveedorEntidad	= @idProveedorEntidad
															AND		SP.idCotizacion		= @idCotizacion
															AND		sp.idPartida		= @idPartida
														END
												END
											ELSE
												BEGIN
													UPDATE	SP 
													SET		idEstatusCotizacionPartida = @accion
													FROM	[solicitud].[SolicitudCotizacionPartida] SP 
													WHERE	idSolicitud			= @idSolicitud
													AND		idTipoSolicitud		= @idTipoSolicitud
													AND		idClase				= @idClase
													AND		rfcEmpresa			= @rfcEmpresa
													AND		idCliente			= @idCliente
													AND		numeroContrato		= @numeroContrato
													AND		rfcProveedor		= @rfcProveedor
													AND		idProveedorEntidad	= @idProveedorEntidad
													AND		SP.idCotizacion		= @idCotizacion
													AND		sp.idPartida		= @idPartida
												END
											SELECT 'Se actualizaron las partidas' as msj
										END
								END
							ELSE
								BEGIN
									SET @err = 'El contrato ya ha exirado.'
								END
						END
					/* CUANDO SE RECHACE UNA PARTIDA 	***************************************************************************/
					ELSE
						BEGIN
							INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
							[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
							[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[idEstatusAprobador],[fechaAprobacion])
							SELECT	[idCotizacion],SP.[idSolicitud],SP.[idTipoSolicitud],SP.[idClase],SP.[rfcEmpresa],SP.[numeroContrato],SP.[idCliente],
									SP.[rfcProveedor],SP.[idProveedorEntidad],SP.[idObjeto],SP.[idTipoObjeto],SP.[idPartida],@idUsuario,@accion,GETDATE()
							FROM	[solicitud].[SolicitudCotizacionPartida] SP 
							WHERE 	idSolicitud			= @idSolicitud
							AND		idTipoSolicitud		= @idTipoSolicitud
							AND		idClase				= @idClase
							AND		rfcEmpresa			= @rfcEmpresa
							AND		idCliente			= @idCliente
							AND		numeroContrato		= @numeroContrato
							AND		rfcProveedor		= @rfcProveedor
							AND		idProveedorEntidad	= @idProveedorEntidad
							AND		SP.idCotizacion		= @idCotizacion
							AND		sp.idPartida		= @idPartida
							/***Validamos si la partida esta configurada para ser autorizada por varias personas*/
							IF EXISTS(	SELECT 1
										FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
										WHERE	idClase				= @idClase
										AND		idTipoSolicitud		= @idTipoSolicitud
										AND		rfcEmpresa			= @rfcEmpresa
										AND		idCliente			= @idCliente
										AND		numeroContrato		= @numeroContrato
										AND		idPartida			= @idPartida)
								BEGIN
									/*Recuperamos el numero de autorizaciones pendientes de la partida*/
									SET @noAutPendientes = [solicitud].[solicitud].SEL_VALIDAAUTORIZACIONES_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,@idPartida,@idCotizacion)
									IF @noAutPendientes=0
										BEGIN
											SET @idEstatusCotizacionPartida = [solicitud].[solicitud].SEL_VALIDAESTATUSPARTIDA_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,@idPartida)

											/*Esta actualizacion solo se hace cuando ya no hay autorizaciones pendientes*/
											UPDATE	SP
											SET		idEstatusCotizacionPartida = @idEstatusCotizacionPartida
											FROM	[solicitud].[SolicitudCotizacionPartida] SP 
											WHERE	idSolicitud			= @idSolicitud
											AND		idTipoSolicitud		= @idTipoSolicitud
											AND		idClase				= @idClase
											AND		rfcEmpresa			= @rfcEmpresa
											AND		idCliente			= @idCliente
											AND		numeroContrato		= @numeroContrato
											AND		rfcProveedor		= @rfcProveedor
											AND		idProveedorEntidad	= @idProveedorEntidad
											AND		SP.idCotizacion		= @idCotizacion
											AND		sp.idPartida		= @idPartida
										END
								END
							ELSE
								BEGIN
									UPDATE	SP
									SET		idEstatusCotizacionPartida = @accion
									FROM	[solicitud].[SolicitudCotizacionPartida] SP 
									WHERE	idSolicitud			= @idSolicitud
									AND		idTipoSolicitud		= @idTipoSolicitud
									AND		idClase				= @idClase
									AND		rfcEmpresa			= @rfcEmpresa
									AND		idCliente			= @idCliente
									AND		numeroContrato		= @numeroContrato
									AND		rfcProveedor		= @rfcProveedor
									AND		idProveedorEntidad	= @idProveedorEntidad
									AND		SP.idCotizacion		= @idCotizacion
									AND		sp.idPartida		= @idPartida
								END
							
						SELECT 'Se actualizaron las partidas' as msj
					END

					/*****************************************************VALIDA ESTATUS COTIZACION APROBADA RECHAZADA **************************************/
					EXEC [solicitud].[UPD_COTIZACION_ESTATUS_SP] @idCotizacion, @idSolicitud, @idTipoSolicitud, @idClase, @rfcEmpresa, @numeroContrato, @idCliente, @rfcProveedor, @idProveedorEntidad, @idUsuario, @err = '' 
					/*****************************************************EJECUTA SP PARA AVANZAR DE PASO **************************************/

					IF EXISTS(SELECT * FROM solicitud.Solicitud WHERE idSolicitud = @idSolicitud AND idFase = 'Aprobacion')
						BEGIN
							EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP] @idSolicitud = @idSolicitud,@idTipoSolicitud = @idTipoSolicitud,@idClase = @idClase,@rfcEmpresa = @rfcEmpresa
																			,@idCliente	= @idCliente,@numeroContrato = @numeroContrato,@idUsuario = @idUsuario,@err = '' 
						END
					ELSE
						BEGIN
							SELECT 0 cambiaPaso
						END

					SET @contador = @contador + 1
				END
			COMMIT TRANSACTION;  
		END TRY
	BEGIN CATCH
		PRINT ERROR_NUMBER() 
		PRINT ERROR_MESSAGE()
		ROLLBACK TRANSACTION
		set @err = ERROR_MESSAGE();
	END CATCH
END



go

