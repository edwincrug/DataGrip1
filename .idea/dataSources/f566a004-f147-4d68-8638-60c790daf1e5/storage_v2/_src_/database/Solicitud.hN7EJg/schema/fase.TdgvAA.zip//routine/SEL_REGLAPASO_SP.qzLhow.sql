
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 27-08-2019
-- Description: Consulta trae las reglas de cada paso
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[SEL_REGLAPASO_SP] 'Automovil', 'ASE0508051B6', '0001', 92, 'Servicio', 6077,  @salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [fase].[SEL_REGLAPASO_SP] 
	@idClase				varchar(50),
	@rfcEmpresa				VARCHAR(13),
	@numeroContrato			VARCHAR(50),
	@idCliente				INT,
	@idTipoSolicitud		VARCHAR(10),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	  SELECT [idReglaPaso]
      --,[idPaso]
	 -- ,(SELECT nombre from (
		--					  SELECT idPaso,nombre 
		--					  FROM fase.paso
		--					  WHERE idClase = @idClase
		--						AND idTipoSolicitud = @idTipoSolicitud
		--					  UNION ALL
		--					  SELECT idPaso,nombre 
		--					  FROM faseContrato.paso
		--					  WHERE idClase = @idClase
		--						AND idTipoSolicitud = @idTipoSolicitud
		--						AND rfcEmpresa = @rfcEmpresa
		--						AND numeroContrato = @numeroContrato
		--						AND idCliente = @idCliente
		--					)t
		--	WHERE t.idPaso = RP.idPaso
		--) paso
  --    ,[idFase]
      ,[idClase]
      ,[idTipoSolicitud]
      ,[rfcEmpresa]
      ,[idCliente]
      ,[numeroContrato]
      --,[orden]
      ,[activo]
      ,[aplicaReglaRol]
      ,[aplicaReglaMonto]
      ,[aplicaReglaUsuario]
      ,[aplicaReglaPartida]
      ,[aplicaReglaObjeto]
      ,[idNivel]
      ,[descripcion]
  FROM [Solicitud].[fase].[ReglaPaso] RP
  WHERE idClase = @idClase
  AND idTipoSolicitud = @idTipoSolicitud
  AND rfcEmpresa = @rfcEmpresa
  AND numeroContrato = @numeroContrato
  AND idCliente = @idCliente
  AND activo = 1




END

go

