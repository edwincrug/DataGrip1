
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 29-05-2019
-- Description: Consulta trae agrupador por id
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[SEL_COSTOSAGRUPADORBYID_SP]  1, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[SEL_COSTOSAGRUPADORBYID_SP]
	@idAgrupador			int,
	@idUsuario				int,
	@err					varchar(500)OUTPUT
AS


BEGIN

	SELECT 
	*
	FROM gestoria.CostoAgrupador CA
	WHERE idCostoAgrupador = @idAgrupador
	AND activo = 1
	

	
END
go

