-- =============================================
-- Author:		<Jose Luis Lozada guerrero>
-- Create date: <06/05/2020>
-- Description:	<Obtiene las preordenes>
-- =============================================
/*
	exec [solicitud].SEL_SOLICITUDSEGURO_BYID_SP 13,6282,null
*/

CREATE PROCEDURE [solicitud].[SEL_SOLICITUDSEGURO_BYID_SP]
@idSolicitud	INT,
@idUsuario		INT,
@err			VARCHAR(8000) = '' OUTPUT		
AS
BEGIN
	SET @err=''
	SELECT	s.idSolicitud,s.idClase,s.rfcEmpresa,s.idCliente,s.numeroContrato,s.idCentroCosto,s.comentarios,s.idObjeto,s.idTipoObjeto,
			s.fechaCreacion,s.solicitudCorreoMessageId,sc.numeroSiniestro, 
			CONVERT(VARCHAR(10),s.fechaCreacion,120) AS xfechaCreacion,
			CONVERT(VARCHAR(10),s.fechaCreacion,108) AS xhoraCreacion
	FROM seguro.Solicitud s INNER JOIN seguro.SolicitudCorreo sc  ON s.solicitudCorreoMessageId=sc.messageId AND s.idSolicitud=@idSolicitud
END
go

