
/*

EXEC [solicitud].[INS_COTIZACION_MANUAL_SP]  
2326, 
'<partidas><partida><idPartida>783886</idPartida></partida><partida><idPartida>783889</idPartida></partida></partidas>',
479, 
'CME720930GM9',
'ASE0508051B6',
185,
'43',
'Automovil',
'Imagen'

*/

CREATE PROCEDURE [solicitud].[INS_COTIZACION_MANUAL_SP]  
	@idUsuario					INT
	,@partidas					XML
	,@idProveedorEntidad		INT
	,@rfcProveedor				VARCHAR(13)
	,@rfcEmpresa				VARCHAR(13)
	,@idCliente					INT
	,@numeroContrato			VARCHAR(100)
	,@idClase					VARCHAR(10)
	,@idTipoSolicitud			varchar(10)




AS

BEGIN
	BEGIN TRY 
		BEGIN TRANSACTION INS_COTIZACION_NUEVO_MANUAL_SP
/********************************************************* INSERTAR SOLICITUD ********************************/
	DECLARE
		@VC_NOSOLICITUD			VARCHAR(20)
		,@idSolicitud			INT
		,@contadorSolicitudes	INT = 1

		DECLARE @VT_Table TABLE (
		[Index]			    INT IDENTITY(1,1),
		[idPartida]			INT
	);

	DECLARE @solicitudes TABLE ([Index] INT IDENTITY(1,1),
								idSolicitud INT)

	INSERT INTO @VT_Table
		SELECT
			I.N.value('(idPartida)[1]',	'INT')
		FROM @partidas.nodes('/partidas/partida') I(N);

/******************************* SOLICITUDES *****************************************************/


INSERT INTO @solicitudes
SELECT idSolicitud FROM solicitud.SolicitudObjeto where numeroOrden in (
'150-1768-10581'
,'150-1624-10582'
,'150-1579-10606'
,'150-1542-11970'
,'150-1705-11976'
,'150-1703-11956'
,'150-1704-11958'
,'150-1723-11942'
,'150-1674-11904'
,'150-1698-11776'
,'150-1700-11784'
,'150-1701-11785'
,'150-1702-11786'
,'150-1721-11749'
,'150-1734-11751'
,'150-1720-11746'
,'150-1691-11431'
,'150-1696-11432'
,'150-1697-11433'
,'150-1680-11420'
,'150-1682-11421'
,'150-1683-11423'
,'150-1685-11424'
,'150-1687-11429'
,'150-1689-11430'
,'150-1677-11417'
,'150-1678-11419'
,'150-1732-11399'
,'150-1855-11400'
,'150-1858-11401'
,'150-1861-11404'
,'150-1718-11381'
,'150-1719-11383'
,'150-1727-11384'
,'150-1728-11385'
,'150-1730-11388'
,'150-1731-11397'
,'150-1714-11372'
,'150-1715-11374'
,'150-1716-11375'
,'150-1841-11376'
,'150-1845-11377'
,'150-1717-11378'
,'150-1738-11308'
,'150-1880-11312'
,'150-1527-11315'
,'150-1737-11307'
,'150-1618-11274'
,'150-1620-11275'
,'150-1623-11278'
,'150-1621-11280'
,'150-1736-11199'
,'150-1733-11208'
,'150-1655-11246'
,'150-1660-11247'
,'150-1724-11178'
,'150-1652-11180'
,'150-1726-11187'
,'150-1627-11191'
,'150-1611-11164'
,'150-1852-11169'
,'150-1613-11153'
,'150-1847-11161'
,'150-1616-11162'
,'150-1706-10868'
,'150-1707-10849'
,'150-1664-10851'
,'150-1708-10856'
,'150-1672-10840'
,'150-1671-10841'
,'150-1667-10843'
,'150-1675-10847'
,'150-1599-10829'
,'150-1602-10833'
,'150-1665-10835'
,'150-1666-10837'
,'150-1837-10796'
,'150-1839-10799'
,'150-1711-10809'
,'150-1713-10819'
,'150-1712-10794'
,'150-1795-10743'
,'150-1785-10744'
,'150-1771-10735'
,'150-1774-10737'
,'150-1777-10738'
,'150-1782-10740'
,'150-1788-10741'
,'150-1790-10742'
,'150-1663-10670'
,'150-1669-10675'
,'150-1625-10660'
,'150-1631-10652'
,'150-1630-10655'
,'150-1604-10645'
,'150-1710-10648'
,'150-1637-10630'
,'150-1635-10632'
,'150-1601-10634'
,'150-1606-10635'
,'150-1608-10639'
,'150-1587-10607'
,'150-1584-10608'
,'150-1597-10614'
,'150-1709-10618'
,'150-1594-10619'
,'150-1632-10629'

)


WHILE((SELECT COUNT(1) FROM @solicitudes) > @contadorSolicitudes)

	BEGIN

	--/************************************************************************+ INSERTAR PROVEEDOR *********************************************************/

	SELECT
		@idSolicitud = idSolicitud
	FROM @solicitudes
	WHERE [Index] = @contadorSolicitudes

	

	select 'crea cotizacion'

	DECLARE 
		@numeroCotizacion	VARCHAR(30) 
		,@idCotizacion	INT

	SET @numeroCotizacion = (SELECT [solicitud].[SEL_NUMEROCOTIZACION_FN](@idSolicitud,@rfcEmpresa,@idTipoSolicitud,@idClase,@idCliente,@numeroContrato))


		INSERT INTO [solicitud].[SolicitudCotizacion] (
						 [idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idProveedorEntidad]
						,[rfcProveedor]
						,[numeroCotizacion]
						,[fechaAlta]
						,[idUsuario]
						,[idEstatusCotizacion]
					) VALUES (
						 @idSolicitud
						,@idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,@idProveedorEntidad
						,@rfcProveedor
						,@numeroCotizacion
						,GETDATE()
						,@idUsuario
						,'ENESPERA'
					)

				SET @idCotizacion = SCOPE_IDENTITY()

			INSERT INTO solicitud.SolicitudCotizacionPartida ([idCotizacion]
						, [idSolicitud]
						, [idTipoSolicitud]
						, [idClase]
						, [rfcEmpresa]
						, [numeroContrato]
						, [idCliente]
						, [rfcProveedor]
						, [idProveedorEntidad]
						, [idObjeto]
						, [idTipoObjeto]
						, [idPartida]
						, [cantidad]
						, [costo]
						, [venta]
						, [idEstatusCotizacionPartida]
						, [fechaEstatus]
						, [idUsuario])
					SELECT @idCotizacion
						, @idSolicitud
						, @idTipoSolicitud
						, @idClase
						, @rfcEmpresa
						, @numeroContrato
						, @idCliente
						, @rfcProveedor
						, @idProveedorEntidad
						, idObjeto
						, idTipoObjeto
						, idPartida
						, cantidad
						, costo
						, venta
						, 'APROBADA'
						, GETDATE()
						, @idUsuario
					FROM solicitud.SolicitudCotizacionPartida 
					WHERE idPartida IN (SELECT idPartida FROM @VT_Table)
					AND idSolicitud = @idSolicitud

					/*************************************** AQUI BORRA PARTIDAS DE OTRA COTIZACION ***********************/


					DELETE FROM solicitud.SolicitudCotizacionPartida  
					WHERE idPartida IN (SELECT idPartida from @VT_Table)
					AND idSolicitud = @idSolicitud
					AND idCotizacion != @idCotizacion

					DELETE FROM [Solicitud].[solicitud].[SolicitudCotizacionAprobador]
					WHERE idPartida IN (SELECT idPartida from @VT_Table)
					AND idSolicitud = @idSolicitud
					AND idCotizacion != @idCotizacion


			INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
					(fechaAlta
					,idCotizacion
					,idSolicitud
					,idTipoSolicitud
					,idClase
					,rfcEmpresa
					,idCliente
					,numeroContrato
					,idProveedorEntidad
					,rfcProveedor
					,idEstatusCotizacion
					,idUsuario)
					VALUES 
					(GETDATE()
					,@idCotizacion
					,@IdSolicitud
					,@idTipoSolicitud
					,@idClase
					,@rfcEmpresa
					,@idCliente
					,@numeroContrato
					,@idProveedorEntidad
					,@rfcProveedor
					,'ENESPERA',@idUsuario)



	/**************************************************** APRUEBA PARTIDAS ******************************/
	select 'aprueba'
	--UPDATE SP
	--	SET idEstatusCotizacionPartida = 'APROBADA'
	--FROM [solicitud].[SolicitudCotizacionPartida] SP 
	--WHERE 
	--	idSolicitud = @IdSolicitud
	--	AND idTipoSolicitud = @idTipoSolicitud
	--	AND idClase = @idClase
	--	AND rfcEmpresa = @rfcEmpresa
	--	AND idCliente = @idCliente
	--	AND numeroContrato = @numeroContrato
	--	AND rfcProveedor = @rfcProveedor
	--	AND idProveedorEntidad = @idProveedorEntidad
	--	AND SP.idCotizacion = @idCotizacion

	--	UPDATE [solicitud].[SolicitudCotizacion]
	--				SET idEstatusCotizacion='APROBADA'
	--				WHERE idCotizacion= @idCotizacion

		INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
			(fechaAlta
			,idCotizacion
			,idSolicitud
			,idTipoSolicitud
			,idClase,rfcEmpresa
			,idCliente
			,numeroContrato
			,idProveedorEntidad
			,rfcProveedor
			,idEstatusCotizacion
			,idUsuario)
		VALUES 
		(GETDATE()
		,@idCotizacion
		,@IdSolicitud
		,@idTipoSolicitud
		,@idClase,@rfcEmpresa
		,@idCliente
		,@numeroContrato
		,@idProveedorEntidad
		,@rfcProveedor 
		,'APROBADA'
		,@idUsuario)

		INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] (
			[idCotizacion],
			[idSolicitud]
			,[idTipoSolicitud]
			,[idClase]
			,[rfcEmpresa]
			,[numeroContrato]
			,[idCliente]
			,[rfcProveedor]
			,[idProveedorEntidad]
			,[idObjeto]
			,[idTipoObjeto]
			,[idPartida]
			,[idUsuarioAprobador]
			,[fechaAprobacion])
		SELECT [idCotizacion]
			,SP.[idSolicitud]
			,SP.[idTipoSolicitud]
			,SP.[idClase]
			,SP.[rfcEmpresa]
			,SP.[numeroContrato]
			,SP.[idCliente]
			,SP.[rfcProveedor]
			,SP.[idProveedorEntidad]
			,SP.[idObjeto]
			,SP.[idTipoObjeto]
			,SP.[idPartida]
			,@idUsuario
			,GETDATE()
		FROM [solicitud].[SolicitudCotizacionPartida] SP 
		WHERE 
			idSolicitud = @IdSolicitud
			AND idTipoSolicitud = @idTipoSolicitud
			AND idClase = @idClase
			AND rfcEmpresa = @rfcEmpresa
			AND idCliente = @idCliente
			AND numeroContrato = @numeroContrato
			AND rfcProveedor = @rfcProveedor
			AND idProveedorEntidad = @idProveedorEntidad
			AND SP.idCotizacion = @idCotizacion



 -- /************************************************ Insertar factura *******************************************/

	--if (@serie='') set @serie=NULL
	--if (@folio='') set @folio=NULL
  
 -- INSERT INTO [Solicitud].[cxp].[Factura] (
	--	[uuid]
	--	,[serie]
	--	,[folio]
	--	,[fechaFactura]
	--	,[rfcEmisor]
	--	,[rfcReceptor]
	--	,[subtotal]
	--	,[descuento]
	--	,[total]
	--	,[saldo]
	--	,[idUsuario]
	--	,[xml]
	--	,[idDocumentoXml]
	--	,[idDocumentoPdf]
	--	,[traslado]
	--	,[retencion]
	--)VALUES(
	--	@uuid
	--	,ISNULL(@serie,'')
	--	,ISNULL(@folio,'')
	--	,@fechaFactura
	--	,@rfcEmisor
	--	,@rfcReceptor
	--	,@subTotal
	--	,@descuento
	--	,@total
	--	,@total
	--	,@idUsuario
	--	,@xml
	--	,@idDocumentoXml
	--	,@idDocumentoPdf
	--	,@traslado
	--	,@retencion
	--)

	--if (@serie is null and @folio is null)
	--begin
	--	update [Solicitud].[cxp].[Factura] SET serie = SUBSTRING(@uuid,25,12) where uuid = @uuid
	--end

	--IF(@trasladosXml IS NOT NULL)
	--BEGIN

	--	DECLARE @tbl_traslados AS TABLE (
	--		impuesto		varchar(3),			
	--		importe			float,
	--		tasa			float
	--	)

	--	INSERT INTO @tbl_traslados
	--	SELECT   
	--		ParamValues.col.value('impuesto[1]','varchar(3)')
	--		,ParamValues.col.value('importe[1]','float')
	--		,ParamValues.col.value('tasa[1]','float')
	--	FROM @trasladosXml.nodes('traslados/traslado') AS ParamValues(col)  
	
	--	INSERT INTO [Solicitud].[cxp].[FacturaImpuesto] 
	--		SELECT
	--			@uuid
	--			,T.tasa
	--			,importe
	--			,TFI.idTipoFacturaImpuesto
	--		FROM @tbl_traslados T 
	--		INNER JOIN [Solicitud].[cxp].[TipoFacturaImpuesto] TFI
	--			ON T.impuesto = TFI.clave
	--		WHERE TFI.idTipo = 1

	--END

	--IF(@retencionesXml IS NOT NULL)
	--BEGIN

	--	DECLARE @tbl_retenciones AS TABLE (
	--		impuesto		varchar(3),	
	--		importe			float,
	--		tasa			float
	--	)

	--	INSERT INTO @tbl_retenciones
	--	SELECT   
	--		ParamValues.col.value('impuesto[1]','varchar(3)')
	--		,ParamValues.col.value('importe[1]','float')
	--		,ParamValues.col.value('tasa[1]','float')
	--	FROM @retencionesXml.nodes('retenciones/retencion') AS ParamValues(col)  
	
	--	INSERT INTO [Solicitud].[cxp].[FacturaImpuesto] 
	--		SELECT
	--			@uuid
	--			,r.tasa
	--			,importe
	--			,TFI.idTipoFacturaImpuesto
	--		FROM @tbl_retenciones R
	--		INNER JOIN [Solicitud].[cxp].[TipoFacturaImpuesto] TFI
	--			ON R.impuesto = TFI.clave
	--		WHERE TFI.idTipo = 2

	--END

	--INSERT INTO cxp.SolicitudCotizacionFactura(  
	--			idCotizacion,  
	--			idSolicitud,  
	--			idTipoSolicitud,  
	--			idClase,  
	--			rfcEmpresa,  
	--			idCliente,  
	--			numeroContrato,  
	--			idProveedorEntidad,  
	--			rfcProveedor,  
	--			uuid  
	--		   ) 
	--   VALUES
	--	(
	--		@VI_idCotizacion,  
	--		@VI_IdSolicitud,  
	--		@idTipoSolicitud,  
	--		@idClase,  
	--		@rfcEmpresa,  
	--		@idCliente,  
	--		@numeroContrato,  
	--		@idProveedorEntidad,  
	--		@rfcProveedor,  
	--		@uuid  
	--	)


 --   INSERT INTO cxp.SolicitudCotizacionFacturaDetalle(  
	--			idCotizacion,  
	--			idSolicitud,  
	--			idTipoSolicitud,  
	--			idClase,  
	--			rfcEmpresa,  
	--			idCliente,  
	--			numeroContrato,  
	--			idProveedorEntidad,
	--			rfcProveedor,  
	--			uuid,  
	--			idObjeto,  
	--			idTipoObjeto,  
	--			idPartida,  
	--			montoAbonado,  
	--			fechaAbono,  
	--			idUsuario  
	--		   ) 

	--	   SELECT
	--			@VI_idCotizacion,  
	--			@VI_IdSolicitud,  
	--			@idTipoSolicitud,  
	--			@idClase,  
	--			@rfcEmpresa,  
	--			@idCliente,  
	--			@numeroContrato,  
	--			@idProveedorEntidad,  
	--			@rfcProveedor,  
	--			@uuid,  
	--			@idObjeto,  
	--			@idTipoObjeto,  
	--			SCP.idPartida,  
	--			SCP.costo,  
	--			GETDATE(),  
	--			@idUsuario  
	--	   FROM @VT_Table p
	--	   INNER JOIN solicitud.SolicitudCotizacionPartida SCP
	--				  ON SCP.idPartida = p.idPartida
	--		WHERE SCP.idSolicitud = @VI_IdSolicitud



	--EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
	--	@idSolicitud  = @VI_IdSolicitud,  
	--	 @idTipoSolicitud = @idTipoSolicitud,  
	--	 @idClase  = @idClase ,  
	--	 @rfcEmpresa  = @rfcEmpresa ,  
	--	 @idCliente   = @idCliente,  
	--	 @numeroContrato  = @numeroContrato,  
	--	 @idUsuario   = @idUsuario,  
	--	 @err    = ''

	--/******************************************************************* SE AVANZA A ENTREGA *****************************************************************/
	--DECLARE
	--	@tokenAuditoria TABLE (idToken int, token varchar(6))

	--DECLARE @token VARCHAR(6)

	--INSERT INTO @tokenAuditoria
	--EXEC [token].[INS_TOKEN_PASO_SP] @VI_IdSolicitud, 'TerminoTrabajo',@idUsuario, ''

	--SELECT 
	--	@token = token
	--FROM @tokenAuditoria

	--EXEC [token].[UPD_TOKEN_PASO_SP] @VI_IdSolicitud, @token, @idUsuario, ''

	--EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
	--	@idSolicitud  = @VI_IdSolicitud,  
	--	 @idTipoSolicitud = @idTipoSolicitud,  
	--	 @idClase  = @idClase ,  
	--	 @rfcEmpresa  = @rfcEmpresa ,  
	--	 @idCliente   = @idCliente,  
	--	 @numeroContrato  = @numeroContrato,  
	--	 @idUsuario   = @idUsuario,  
	--	 @err    = ''


	--/*********************************************************** SE AVANZA A COBRANZA *******************************************************/

	--DECLARE
	--	@tokenEntrega TABLE (idToken int, token varchar(6))

	--DECLARE @tokenE VARCHAR(6)

	--INSERT INTO @tokenEntrega
	--EXEC [token].[INS_TOKEN_PASO_SP] @VI_IdSolicitud, 'Entrega',@idUsuario, ''

	--SELECT 
	--	@tokenE = token
	--FROM @tokenEntrega

	--EXEC [token].[UPD_TOKEN_PASO_SP] @VI_IdSolicitud, @tokenE, @idUsuario, ''

	--EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
	--	@idSolicitud  = @VI_IdSolicitud,  
	--	 @idTipoSolicitud = @idTipoSolicitud,  
	--	 @idClase  = @idClase ,  
	--	 @rfcEmpresa  = @rfcEmpresa ,  
	--	 @idCliente   = @idCliente,  
	--	 @numeroContrato  = @numeroContrato,  
	--	 @idUsuario   = @idUsuario,  
	--	 @err    = ''

	--/******************** SE AVANZA A PREFACTURA GENERADA ****************/
	----select  @VI_IdSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idUsuario,''

END

	COMMIT TRANSACTION INS_COTIZACION_NUEVO_MANUAL_SP

	--EXEC cxc.INS_FACTURA_PROCESACOMPRA_SP @VI_IdSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idUsuario,''
	--DECLARE @idFactura INT = (SELECT idFactura FROM [Solicitud].[cxc].[factura] WHERE idSolicitud = @VI_IdSolicitud), @fet datetime = GETDATE();
	--EXEC cxc.INS_FACTURAAGRUPADA_MANUAL_SP @idClase, @rfcEmpresa, @idCliente, @numeroContrato, @fet, @fet, NULL, NULL, 0, 0, 'xml', @idFactura, 6115, @VI_IdSolicitud, @idTipoSolicitud
	

	END TRY
		BEGIN CATCH
			SELECT ERROR_MESSAGE()
			ROLLBACK TRANSACTION INS_COTIZACION_NUEVO_MANUAL_SP
		END CATCH

END


go

