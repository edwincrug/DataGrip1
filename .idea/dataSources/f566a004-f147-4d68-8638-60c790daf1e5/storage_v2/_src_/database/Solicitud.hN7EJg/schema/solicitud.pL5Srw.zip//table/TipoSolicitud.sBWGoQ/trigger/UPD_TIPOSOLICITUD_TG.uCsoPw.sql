-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <04/07/2019>
-- Description:	<ACTUALIZA de Integridades>
-- =============================================
CREATE TRIGGER [solicitud].[UPD_TIPOSOLICITUD_TG] 
   ON  [solicitud].[TipoSolicitud]
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @idTipoSolicitud	VARCHAR(10),
			@idClase			VARCHAR(10),
			@IdUsuario			INT,
			@activo				BIT,

			@idTipoSolicitudDel	VARCHAR(10),
			@idClaseDel			VARCHAR(10),
			@VC_ThrowTable		VARCHAR(300) = ''
	;

	SELECT TOP 1 @idTipoSolicitud= idTipoSolicitud, @idClase= idClase, @IdUsuario = IdUsuario, @activo = activo FROM INSERTED
	SELECT TOP 1 @idTipoSolicitudDel= idTipoSolicitud, @idClaseDel= idClase FROM deleted

	BEGIN TRANSACTION;
	BEGIN TRY

		--ACTUALIZAMOS INTEGRIDADES

		--Cliente
		SET @VC_ThrowTable = '[Cliente].[integridad].[TipoSolicitud] ';
		UPDATE [Cliente].[integridad].[TipoSolicitud]
		SET idTipoSolicitud =  @idTipoSolicitud,
		idClase =  @idClase
		WHERE idTipoSolicitud = @idTipoSolicitudDel
		AND idClase = @idClaseDel

		SET @VC_ThrowTable = 'Proveedor.integridad.TipoSolicitud'
		UPDATE Proveedor.integridad.TipoSolicitud
		SET activo = @activo
		WHERE idTipoSolicitud = @idTipoSolicitudDel
		AND idClase = @idClaseDel

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
	END CATCH

END
go

