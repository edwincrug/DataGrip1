-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Obtener la lista de partidas de una cotizacion, detalle de cotizacion>
-- =============================================
-- EXEC [solicitud].[SEL_DETALLE_COTIZACION_SP] 155, 396, 2
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_DETALLE_COTIZACION_SP]
(
    @idSolicitud        int
    ,@idCotizacion      int
	,@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN

    SELECT 
        SSTPV.idSolicitud
        ,SSTPV.idCotizacion
        ,SSC.numeroCotizacion
        ,SSTPV.[idPartida]
        ,SPV.[partida]
        ,SPV.[noParte]
        ,SPV.[descripcion]
        ,SPV.[instructivo]
        ,SPV.[foto]
        ,SSTPV.[cantidad]
        ,SSTPV.[costo]
        ,SSTPV.[venta]
        ,SSTPV.[subTotalCosto] subtotalCosto
        ,SSTPV.[IVACosto]
        ,SSTPV.[totalCosto]
        ,SSTPV.[subTotalVenta] subtotalVenta
        ,SSTPV.[IVAVenta]
        ,SSTPV.[totalVenta]
        ,SSTPV.[idEstatusCotizacionPartida]
    FROM [Solicitud].[solicitud].[SEL_TOTALES_PARTIDAS_VW] SSTPV 
    INNER JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SSC
        ON SSTPV.[idSolicitud] = SSC.[idSolicitud]
        AND SSTPV.[idCotizacion] = SSC.[idCotizacion]
        AND SSTPV.[idTipoSolicitud] = SSC.[idTipoSolicitud]
        AND SSTPV.[idClase] = SSC.[idClase]
        AND SSTPV.[rfcEmpresa] = SSC.[rfcEmpresa]
        AND SSTPV.[idCliente] = SSC.[idCliente]
        AND SSTPV.[numeroContrato] = SSC.[numeroContrato]
        AND SSTPV.[idProveedorEntidad] = SSC.[idProveedorEntidad]
        AND SSTPV.[rfcProveedor] = SSC.[rfcProveedor]
    INNER JOIN [Cliente].[contrato].[SEL_PARTIDAS_VW] SPV
        ON SSTPV.[idPartida] = SPV.[idPartida]
        AND SSTPV.[idClase] = SPV.[idClase]
        AND SSTPV.[idTipoObjeto] = SPV.[idTipoObjeto]
    WHERE SSTPV.[idSolicitud] = @idSolicitud
        AND SSTPV.idCotizacion = @idCotizacion
        AND SSC.[idSolicitud] = @idSolicitud
        
END
go

