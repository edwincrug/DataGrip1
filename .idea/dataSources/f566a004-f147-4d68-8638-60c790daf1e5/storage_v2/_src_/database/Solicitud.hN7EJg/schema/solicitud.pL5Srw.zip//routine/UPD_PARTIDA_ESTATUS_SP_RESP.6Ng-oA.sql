-- =============================================
-- Author: José Etmanuel Hernández REjón
-- Create date: 05/07/2019
-- Description: Autoriza una partida
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[UPD_PARTIDA_ESTATUS_SP]
	@idSolicitud = 1196,
	@idTipoSolicitud = 'Servicio',
	@idClase	= 'Automovil',
	@rfcEmpresa	= 'ASE0508051B6',
	@rfcProveedor = 'OFC040113KR6',
	@idProveedorEntidad	= 587,
	@idCliente = 220,
	@numeroContrato	='129',
	@xmlPartidas = '<partidas><partida><idObjeto>13408</idObjeto><idTipoObjeto>838</idTipoObjeto><idPartida>792546</idPartida><autorizaRechaza>1</autorizaRechaza><cantidad>1</cantidad></partida></partidas>',
	@idUsuario		= 3135,
	@reglaMonstoSolicitudMin= 1,
	@reglaMonstoSolicitudMax = 150000,
	@cantidadPartidas	= 0,
	@aplicaReglaMonto	= 1,
	@aplicaReglaCantidad	= 0,
	@idCotizacion	= 2165
	,@salida OUT = ''
    SELECT @salida AS salida;




	
*/
-- =============================================

CREATE PROCEDURE [solicitud].[UPD_PARTIDA_ESTATUS_SP_RESP]
	@idSolicitud					INT,
	@idTipoSolicitud				VARCHAR(10),
	@idClase						VARCHAR(10),
	@rfcEmpresa						VARCHAR(13),
	@rfcProveedor					VARCHAR(13),
	@idProveedorEntidad				INT,
	@idCliente						INT,
	@numeroContrato					VARCHAR(50),
	@xmlPartidas					XML,
	@idUsuario						INT,
	@reglaMonstoSolicitudMin		INT,
	@reglaMonstoSolicitudMax		INT,
	@cantidadPartidas				INT,
	@aplicaReglaMonto				BIT,
	@aplicaReglaCantidad			BIT,
	@idCotizacion					INT,
	@err							VARCHAR(500) OUTPUT
AS
BEGIN


	DECLARE @totalPartida		AS INT,
			@totalPartidaAnt	AS INT,
			@sumCantidad		AS INT,
			@sumCantidaAnt		AS INT


	DECLARE @tbl_propiedades AS TABLE(
	idObjeto				INT,
	idTipoObjeto			INT,
	idPartida				INT,
	cantidad				INT,
	autorizaRechaza			BIT
	)

	declare @aplicaCentrodeCosto	INT

	INSERT INTO @tbl_propiedades
	SELECT
		ParamValues.col.value('idObjeto[1]','int'),
		ParamValues.col.value('idTipoObjeto[1]','int'),
		ParamValues.col.value('idPartida[1]','int'),
		ParamValues.col.value('cantidad[1]','int'),
		ParamValues.col.value('autorizaRechaza[1]','bit')
      FROM @xmlPartidas.nodes('partidas/partida') AS ParamValues(col)

	--SELECT * from @tbl_propiedades

	SELECT 
		@totalPartida = SUM(ventaInicial * tbp.cantidad),
		@sumCantidad = SUM(tbp.cantidad)
	FROM @tbl_propiedades TBP 
	INNER JOIN [solicitud].[SolicitudPartida] SP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
	INNER JOIN partida.partida.partida P  ON TBP.idPartida = P.idPartida 
	WHERE P.activo = 1
	AND SP.idSolicitud = @idSolicitud
	AND TBP.autorizaRechaza = 1

	

	SELECT 
		@sumCantidaAnt = SUM(cantidad), 
		@totalPartidaAnt = SUM(cantidad * venta) 
		FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida]
	where idsolicitud = @idSolicitud 
	AND idEstatusCotizacionPartida = 'APROBADA'
	AND idTipoSolicitud = @idTipoSolicitud
	AND idClase = @idClase
	AND rfcEmpresa = @rfcEmpresa
	AND idCliente = @idCliente
	AND numeroContrato = @numeroContrato
	AND idusuario = @idusuario

	SET @sumCantidad = @sumCantidad + ISNULL(@sumCantidaAnt, 0)
	SET @totalPartida = @totalPartida + ISNULL(@totalPartidaAnt, 0)

	--select @sumcantidad, @totalPartida
	DECLARE @CCF TABLE (idCentroCosto INT, nombre VARCHAR(200), presupuestoCC FLOAT, folio VARCHAR(200),
	presupuestoCF FLOAT, fechaInicio DATETIME, fechaFin DATETIME, gastado float, restante FLOAT)
	DECLARE @fechaInicio DATETIME, @fechaFin DATETIME, @restaCC FLOAT;

	SELECT 
		@aplicaCentrodeCosto = ISNULL(manejoDePresupuesto ,0)
	FROM [cliente].[cliente].[Contrato] 
	WHERE rfcEmpresa = @rfcEmpresa
	AND idCliente = @idCliente
	AND numeroContrato = @numeroContrato
	AND idClase = @idClase
	AND activo = 1

	INSERT INTO @CCF
		EXECUTE Cliente.contrato.SEL_CENTRODECOSTO_FOLIO_SP @rfcEmpresa, @idCliente, @numeroContrato, @idUsuario, NULL
	SELECT
		@fechaInicio = CC.fechaInicio,
		@fechaFin = CC.fechaFin,
		@restaCC = CC.restante
	FROM @CCF AS CC
	INNER JOIN Solicitud.solicitud.Solicitud AS S ON S.idCentroCosto = CC.idCentroCosto AND
	S.folio = CC.folio
	WHERE S.idSolicitud = @idSolicitud

	IF EXISTS(SELECT * FROM @tbl_propiedades WHERE autorizaRechaza = 1)
		BEGIN
			print @aplicaCentrodeCosto
			IF((GETDATE() BETWEEN @fechaInicio AND @fechaFin) OR (@aplicaCentrodeCosto = 0))
				BEGIN
					IF ((@restaCC - @totalPartida < 0) AND (@aplicaCentrodeCosto = 1))
						BEGIN
							SET @err = 'La venta sobrepasa el monto del centro de costo permitido'
						END
					ELSE
						BEGIN 
							/********************************************* SI APLICA LA REGLA DE CANTIDAD Y TOTAL DE PARTIDA **************************/

							IF(@aplicaReglaMonto = 1 AND @aplicaReglaCantidad = 1)
								BEGIN
								PRINT '2 REGLAS'
									IF((@totalPartida BETWEEN @reglaMonstoSolicitudMin AND @reglaMonstoSolicitudMax) )
										BEGIN	
											IF(@sumCantidad <= @cantidadPartidas)
												BEGIN		
						
													UPDATE SP
														SET idEstatusCotizacionPartida = (CASE 
																							WHEN TBP.autorizaRechaza = 1 THEN 'APROBADA'
																							ELSE 'RECHAZADA' END)
													FROM [solicitud].[SolicitudCotizacionPartida] SP 
													INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
													WHERE 
														idSolicitud = @idSolicitud
														AND idTipoSolicitud = @idTipoSolicitud
														AND idClase = @idClase
														AND rfcEmpresa = @rfcEmpresa
														AND idCliente = @idCliente
														AND numeroContrato = @numeroContrato
														AND rfcProveedor = @rfcProveedor
														AND idProveedorEntidad = @idProveedorEntidad
														AND sp.idPartida = tbp.idPartida
														AND SP.idCotizacion = @idCotizacion


													INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
													[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
													[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[fechaAprobacion])
													SELECT [idCotizacion]
													  ,SP.[idSolicitud]
													  ,SP.[idTipoSolicitud]
													  ,SP.[idClase]
													  ,SP.[rfcEmpresa]
													  ,SP.[numeroContrato]
													  ,SP.[idCliente]
													  ,SP.[rfcProveedor]
													  ,SP.[idProveedorEntidad]
													  ,SP.[idObjeto]
													  ,SP.[idTipoObjeto]
													  ,SP.[idPartida]
													  ,@idUsuario
													  ,GETDATE()
													FROM [solicitud].[SolicitudCotizacionPartida] SP 
													INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
													WHERE 
														idSolicitud = @idSolicitud
														AND idTipoSolicitud = @idTipoSolicitud
														AND idClase = @idClase
														AND rfcEmpresa = @rfcEmpresa
														AND idCliente = @idCliente
														AND numeroContrato = @numeroContrato
														AND rfcProveedor = @rfcProveedor
														AND idProveedorEntidad = @idProveedorEntidad
														AND sp.idPartida = tbp.idPartida
														AND SP.idCotizacion = @idCotizacion


													--UPDATE SP
													--	SET idEstatusSolicitudPartida = (SELECT [solicitud].[SEL_ESTATUS_PARTIDAS_FN](@idSolicitud, @idTipoSolicitud, @rfcEmpresa, @numeroContrato, @idCliente, @idClase, TBP.idPartida))
													--FROM Solicitud.SolicitudPartida SP 
													--INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
													--WHERE 
													--	idSolicitud = @idSolicitud
													--	AND idTipoSolicitud = @idTipoSolicitud
													--	AND idClase = @idClase
													--	AND rfcEmpresa = @rfcEmpresa
													--	AND idCliente = @idCliente
													--	AND numeroContrato = @numeroContrato

													SELECT 'Se actualizaron partidas' as msj
												END
											ELSE
												BEGIN
													SET @err = 'La cantidad debe estar dentro del intervalo permitido'

												END
					
										END

									ELSE
										BEGIN
											SET @err = 'El monto debe estar dentro del intervalo permitido'
										END
								END

			/********************************************* SI SOLO APLICA REGLA DE TOTAL DE PARTIDA **************************/

					IF(@aplicaReglaMonto = 1 AND @aplicaReglaCantidad=0)
						BEGIN
							PRINT 'REGLA MONTO'
							PRINT @totalPartida
							IF((@totalPartida BETWEEN @reglaMonstoSolicitudMin AND @reglaMonstoSolicitudMax) )
							BEGIN	

								UPDATE SP
									SET idEstatusCotizacionPartida = (CASE 
																		WHEN TBP.autorizaRechaza = 1 THEN 'APROBADA'
																		ELSE 'RECHAZADA' END)
									FROM [solicitud].[SolicitudCotizacionPartida] SP 
									INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
									WHERE 
										idSolicitud = @idSolicitud
										AND idTipoSolicitud = @idTipoSolicitud
										AND idClase = @idClase
										AND rfcEmpresa = @rfcEmpresa
										AND idCliente = @idCliente
										AND numeroContrato = @numeroContrato
										AND rfcProveedor = @rfcProveedor
										AND idProveedorEntidad = @idProveedorEntidad
										AND sp.idPartida = tbp.idPartida
										AND SP.idCotizacion = @idCotizacion


									INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
													[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
													[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[fechaAprobacion])
													SELECT [idCotizacion]
													  ,SP.[idSolicitud]
													  ,SP.[idTipoSolicitud]
													  ,SP.[idClase]
													  ,SP.[rfcEmpresa]
													  ,SP.[numeroContrato]
													  ,SP.[idCliente]
													  ,SP.[rfcProveedor]
													  ,SP.[idProveedorEntidad]
													  ,SP.[idObjeto]
													  ,SP.[idTipoObjeto]
													  ,SP.[idPartida]
													  ,@idUsuario
													  ,GETDATE()
													FROM [solicitud].[SolicitudCotizacionPartida] SP 
													INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
													WHERE 
														idSolicitud = @idSolicitud
														AND idTipoSolicitud = @idTipoSolicitud
														AND idClase = @idClase
														AND rfcEmpresa = @rfcEmpresa
														AND idCliente = @idCliente
														AND numeroContrato = @numeroContrato
														AND rfcProveedor = @rfcProveedor
														AND idProveedorEntidad = @idProveedorEntidad
														AND sp.idPartida = tbp.idPartida
														AND SP.idCotizacion = @idCotizacion

								--UPDATE SP
								--	SET idEstatusSolicitudPartida = (SELECT [solicitud].[SEL_ESTATUS_PARTIDAS_FN](@idSolicitud, @idTipoSolicitud, @rfcEmpresa, @numeroContrato, @idCliente, @idClase, TBP.idPartida))
								--FROM Solicitud.SolicitudPartida SP 
								--INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
								--WHERE 
								--	idSolicitud = @idSolicitud
								--	AND idTipoSolicitud = @idTipoSolicitud
								--	AND idClase = @idClase
								--	AND rfcEmpresa = @rfcEmpresa
								--	AND idCliente = @idCliente
								--	AND numeroContrato = @numeroContrato

					

								SELECT 'Se actualizaron las partidas' as msj
							END

						ELSE
							BEGIN
								SET @err = 'El monto debe estar dentro del intervalo permitido'
							END
						END

			/********************************************* SI SOLO APLICA REGLA DE CANTIDAD DE PARTIDA **************************/

					IF(@aplicaReglaMonto = 0 AND @aplicaReglaCantidad=1)
						BEGIN
							PRINT 'REGLA CANTIDAD'
							IF(@sumCantidad <= @cantidadPartidas )
							BEGIN	
				
								UPDATE SP
									SET idEstatusCotizacionPartida = (CASE 
																		WHEN TBP.autorizaRechaza = 1 THEN 'APROBADA'
																		ELSE 'RECHAZADA' END)
								FROM [solicitud].[SolicitudCotizacionPartida] SP 
								INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
								WHERE 
									idSolicitud = @idSolicitud
									AND idTipoSolicitud = @idTipoSolicitud
									AND idClase = @idClase
									AND rfcEmpresa = @rfcEmpresa
									AND idCliente = @idCliente
									AND numeroContrato = @numeroContrato
									AND rfcProveedor = @rfcProveedor
									AND idProveedorEntidad = @idProveedorEntidad
									AND sp.idPartida = tbp.idPartida
									AND SP.idCotizacion = @idCotizacion


								INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
													[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
													[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[fechaAprobacion])
													SELECT [idCotizacion]
													  ,SP.[idSolicitud]
													  ,SP.[idTipoSolicitud]
													  ,SP.[idClase]
													  ,SP.[rfcEmpresa]
													  ,SP.[numeroContrato]
													  ,SP.[idCliente]
													  ,SP.[rfcProveedor]
													  ,SP.[idProveedorEntidad]
													  ,SP.[idObjeto]
													  ,SP.[idTipoObjeto]
													  ,SP.[idPartida]
													  ,@idUsuario
													  ,GETDATE()
													FROM [solicitud].[SolicitudCotizacionPartida] SP 
													INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
													WHERE 
														idSolicitud = @idSolicitud
														AND idTipoSolicitud = @idTipoSolicitud
														AND idClase = @idClase
														AND rfcEmpresa = @rfcEmpresa
														AND idCliente = @idCliente
														AND numeroContrato = @numeroContrato
														AND rfcProveedor = @rfcProveedor
														AND idProveedorEntidad = @idProveedorEntidad
														AND sp.idPartida = tbp.idPartida
														AND SP.idCotizacion = @idCotizacion
						
									
								--UPDATE SP
								--	SET idEstatusSolicitudPartida = (SELECT [solicitud].[SEL_ESTATUS_PARTIDAS_FN](@idSolicitud, @idTipoSolicitud, @rfcEmpresa, @numeroContrato, @idCliente, @idClase, TBP.idPartida))
								--FROM Solicitud.SolicitudPartida SP 
								--INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
								--WHERE 
								--	idSolicitud = @idSolicitud
								--	AND idTipoSolicitud = @idTipoSolicitud
								--	AND idClase = @idClase
								--	AND rfcEmpresa = @rfcEmpresa
								--	AND idCliente = @idCliente
								--	AND numeroContrato = @numeroContrato

					

								SELECT 'Se actualizaron las partidas' as msj
							END

						ELSE
							BEGIN
								SET @err = 'La cantidad debe estar dentro del intervalo permitido'
							END
						END

			/********************************************* SI NO APLICA NINGUNA REGLA **************************/

		
					IF(@aplicaReglaMonto = 0 AND @aplicaReglaCantidad=0)
						BEGIN		
							PRINT 'NO APLICA REGLA'	
				
							UPDATE SP
								SET idEstatusCotizacionPartida = (CASE 
																	WHEN TBP.autorizaRechaza = 1 THEN 'APROBADA'
																	ELSE 'RECHAZADA' END)
							FROM [solicitud].[SolicitudCotizacionPartida] SP 
							INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
							WHERE 
								idSolicitud = @idSolicitud
								AND idTipoSolicitud = @idTipoSolicitud
								AND idClase = @idClase
								AND rfcEmpresa = @rfcEmpresa
								AND idCliente = @idCliente
								AND numeroContrato = @numeroContrato
								AND rfcProveedor = @rfcProveedor
								AND idProveedorEntidad = @idProveedorEntidad
								AND sp.idPartida = tbp.idPartida
								AND SP.idCotizacion = @idCotizacion
					
							INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
													[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
													[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[fechaAprobacion])
													SELECT [idCotizacion]
													  ,SP.[idSolicitud]
													  ,SP.[idTipoSolicitud]
													  ,SP.[idClase]
													  ,SP.[rfcEmpresa]
													  ,SP.[numeroContrato]
													  ,SP.[idCliente]
													  ,SP.[rfcProveedor]
													  ,SP.[idProveedorEntidad]
													  ,SP.[idObjeto]
													  ,SP.[idTipoObjeto]
													  ,SP.[idPartida]
													  ,@idUsuario
													  ,GETDATE()
													FROM [solicitud].[SolicitudCotizacionPartida] SP 
													INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
													WHERE 
														idSolicitud = @idSolicitud
														AND idTipoSolicitud = @idTipoSolicitud
														AND idClase = @idClase
														AND rfcEmpresa = @rfcEmpresa
														AND idCliente = @idCliente
														AND numeroContrato = @numeroContrato
														AND rfcProveedor = @rfcProveedor
														AND idProveedorEntidad = @idProveedorEntidad
														AND sp.idPartida = tbp.idPartida
														AND SP.idCotizacion = @idCotizacion
						
							--UPDATE SP
							--	SET idEstatusSolicitudPartida = (SELECT [solicitud].[SEL_ESTATUS_PARTIDAS_FN](@idSolicitud, @idTipoSolicitud, @rfcEmpresa, @numeroContrato, @idCliente, @idClase, TBP.idPartida))
							--FROM Solicitud.SolicitudPartida SP 
							--INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
							--WHERE 
							--	idSolicitud = @idSolicitud
							--	AND idTipoSolicitud = @idTipoSolicitud
							--	AND idClase = @idClase
							--	AND rfcEmpresa = @rfcEmpresa
							--	AND idCliente = @idCliente
							--	AND numeroContrato = @numeroContrato

				

							SELECT 'Se actualizaron las partidas' as msj
						END

				END
		END
	ELSE
		BEGIN
			SET @err = 'La fecha de la solicitud no esta en el rango permitido del centro de costo'
		END
		END
	ELSE
		BEGIN

		UPDATE SP
			SET idEstatusCotizacionPartida = 'RECHAZADA'
			FROM [solicitud].[SolicitudCotizacionPartida] SP 
							INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
							WHERE 
								idSolicitud = @idSolicitud
								AND idTipoSolicitud = @idTipoSolicitud
								AND idClase = @idClase
								AND rfcEmpresa = @rfcEmpresa
								AND idCliente = @idCliente
								AND numeroContrato = @numeroContrato
								AND rfcProveedor = @rfcProveedor
								AND idProveedorEntidad = @idProveedorEntidad
								AND sp.idPartida = tbp.idPartida
								AND SP.idCotizacion = @idCotizacion



				INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
													[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
													[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[fechaAprobacion])
													SELECT [idCotizacion]
													  ,SP.[idSolicitud]
													  ,SP.[idTipoSolicitud]
													  ,SP.[idClase]
													  ,SP.[rfcEmpresa]
													  ,SP.[numeroContrato]
													  ,SP.[idCliente]
													  ,SP.[rfcProveedor]
													  ,SP.[idProveedorEntidad]
													  ,SP.[idObjeto]
													  ,SP.[idTipoObjeto]
													  ,SP.[idPartida]
													  ,@idUsuario
													  ,GETDATE()
													FROM [solicitud].[SolicitudCotizacionPartida] SP 
													INNER JOIN @tbl_propiedades TBP ON TBP.idPartida = SP.idPartida AND TBP.idTipoObjeto = SP.idTipoObjeto AND TBP.idObjeto = SP.idObjeto
													WHERE 
														idSolicitud = @idSolicitud
														AND idTipoSolicitud = @idTipoSolicitud
														AND idClase = @idClase
														AND rfcEmpresa = @rfcEmpresa
														AND idCliente = @idCliente
														AND numeroContrato = @numeroContrato
														AND rfcProveedor = @rfcProveedor
														AND idProveedorEntidad = @idProveedorEntidad
														AND sp.idPartida = tbp.idPartida
														AND SP.idCotizacion = @idCotizacion
				

				SELECT 'Se actualizaron las partidas' as msj
		END
		/*****************************************************VALIDA ESTATUS COTIZACION APROBADA RECHAZADA **************************************/
		EXEC [solicitud].[UPD_COTIZACION_ESTATUS_SP] @idCotizacion, @idSolicitud, @idTipoSolicitud, @idClase, @rfcEmpresa, @numeroContrato, @idCliente, @rfcProveedor, @idProveedorEntidad, @idUsuario, @err = '' 
		/*****************************************************EJECUTA SP PARA AVANZAR DE PASO **************************************/

		EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
		@idSolicitud = @idSolicitud
		,@idTipoSolicitud = @idTipoSolicitud
		,@idClase = @idClase
		,@rfcEmpresa = @rfcEmpresa
		,@idCliente	= @idCliente
		,@numeroContrato = @numeroContrato
		,@idUsuario = @idUsuario
		,@err = '' 

END


--USE [Solicitud]
go

