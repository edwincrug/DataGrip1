-- =============================================
-- Author: Alan Rosales Chávez
-- Create date: 25/06/2020
-- Description: Consulta para obtener los datos del kilometraje basado en la captura del comprobante de recepcion
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[SEL_OBTIENEUTILIDAD]  
		 @idSolicitud = 882  
		,@idComprobanteRecepcion = 687
		,@idTipoSolicitud = 'Imagen'  
		,@idClase = 'Automovil'  
		,@rfcEmpresa = 'ASE0508051B6'  
		,@idCliente = 185  
		,@numeroContrato = '43'  
		,@idUsuario = 6119
		,@err = @salida
	SELECT @salida AS salida;
*/
CREATE PROCEDURE [solicitud].[SEL_OBTIENEUTILIDAD]  
	@idSolicitud INT,  
	@idComprobanteRecepcion INT,
	@idTipoSolicitud VARCHAR(10) = NULL,  
	@idClase VARCHAR(10) = NULL,  
	@rfcEmpresa VARCHAR(13) = NULL,  
	@idCliente INT = NULL,  
	@numeroContrato VARCHAR(50) = NULL,  
	@idUsuario INT = NULL,  
	@err varchar(max) = NULL OUTPUT  
AS  
BEGIN  
	--*************************************************************
	--VARIABLES
	--*************************************************************
	DECLARE 
		@host VARCHAR(500) ,
		@uniqueid varchar(50)
	--*************************************************************
	--CREAMOS  TABLAS TEMPORALES
	--*************************************************************
	DECLARE @tableSolicitud TABLE(  
		idSolicitud INT,  
		fechaCreacion VARCHAR(50),  
		numeroOrden VARCHAR(50),  
		tipoSolicitud VARCHAR(250),
		zona VARCHAR(500),  
		solicitante VARCHAR(1000),  
		solicitanteCorreo VARCHAR(1000),  
		link VARCHAR(1000),  
		linkAccion VARCHAR(1000),
		contrato varchar(500)
	) 
	
	DECLARE @tableUnidad TABLE(  
		idSolicitud INT,  
		idObjeto INT,  
		idTipoObjeto INT,  
		placa VARCHAR(100),  
		modelo VARCHAR(100),  
		VIN VARCHAR(100),  
		combustible VARCHAR(100),  
		cilindraje VARCHAR(100),  
		tipoObjeto VARCHAR(100),  
		fotoUnidad VARCHAR(1000)
	)  

	DECLARE @tableKM TABLE(
		idSolicitud INT,  
		idObjeto INT,  
		idTipoObjeto INT,  
		kmIngresado	varchar(50),
		kmPlataforma varchar(50),
		kmDispositivo varchar(50),
		kmOBD varchar(50),
		fotoEvidencia varchar(1000)
	)

	declare @KM_AVL table(
		kmPlataforma float,
		kmDispositivo float,
		kmOBD float
	)


	--*************************************************************
	--LLENAMOS VARIABLES Y TABLAS
	--*************************************************************

	SELECT @host = valor  
	FROM Common.configuracion.Configuracion  
	WHERE idConfiguracion = 1  

	select 
		@uniqueid = OD.uniqueid
	from Solicitud.solicitud.Solicitud Solicitud  
	INNER JOIN Solicitud.solicitud.SolicitudObjeto SolicitudObjeto  
		ON Solicitud.idSolicitud = SolicitudObjeto.idSolicitud  
		AND Solicitud.idTipoSolicitud = SolicitudObjeto.idTipoSolicitud  
		AND Solicitud.idClase = SolicitudObjeto.idClase  
		AND Solicitud.rfcEmpresa = SolicitudObjeto.rfcEmpresa  
		AND Solicitud.idCliente = SolicitudObjeto.idCliente  
		AND Solicitud.numeroContrato = SolicitudObjeto.numeroContrato  
	INNER JOIN AVL.vehiculo.ObjetoDispositivo OD
		ON OD.idObjeto = SolicitudObjeto.idObjeto
		AND OD.idTipoObjeto = SolicitudObjeto.idTipoObjeto
	WHERE 
		Solicitud.idSolicitud = @idSolicitud  
		AND Solicitud.idTipoSolicitud = @idTipoSolicitud   
		AND Solicitud.idClase = @idClase   
		AND Solicitud.rfcEmpresa = @rfcEmpresa   
		AND Solicitud.idCliente = @idCliente   
		AND Solicitud.numeroContrato = @numeroContrato  
	
	set @uniqueid='2366631'

	--DATOS DE SOLICITUD
	INSERT INTO @tableSolicitud (idSolicitud, fechaCreacion, numeroOrden, tipoSolicitud,zona,solicitante,solicitanteCorreo, link, linkAccion, contrato)  
	SELECT   
		 Solicitud.idSolicitud   
		,CONVERT(varchar, Solicitud.fechaCreacion, 103) + ' ' + CONVERT(varchar, Solicitud.fechaCreacion, 8)  
		,SolicitudObjeto.numeroOrden  
		,Tipo.nombre  
		,Common.[gerencia].[SEL_OBTENERZONA_FN](solicitud.rfcEmpresa,Solicitud.idCliente,Solicitud.numeroContrato,Solicitud.idClase,SolicitudObjeto.idTipoObjeto,SolicitudObjeto.idObjeto)  
		,Usuario.PrimerNombre + ' ' + Usuario.PrimerApellido + ' ' + Usuario.SegundoApellido  
		,Usuario.Email  
		,@host + 'sel-solicitudes/' + CAST(@idSolicitud AS VARCHAR(10)) + '/' + @idTipoSolicitud + '/' + @idClase + '/' + @rfcEmpresa + '/' + CAST(@idCliente AS VARCHAR(10)) + '/' +  @numeroContrato  
		,'https://apiavl.centraldeoperaciones.com/vehiculo/postKM'
		,Contrato.nombre  
	FROM Solicitud.solicitud.Solicitud Solicitud  
	INNER JOIN Solicitud.solicitud.SolicitudObjeto SolicitudObjeto  
		ON Solicitud.idSolicitud = SolicitudObjeto.idSolicitud  
	INNER JOIN Solicitud.solicitud.TipoSolicitud Tipo  
		ON Solicitud.idTipoSolicitud = Tipo.idTipoSolicitud  
	AND Solicitud.idClase = Tipo.idClase  
	INNER JOIN Solicitud.solicitud.SEL_SOLICITUD_ZONA_VW Zona  
		ON Solicitud.idSolicitud = Zona.idSolicitud  
		AND Solicitud.idTipoSolicitud = Zona.idTipoSolicitud  
		AND Solicitud.idClase = Zona.idClase  
		AND Solicitud.rfcEmpresa = Zona.rfcEmpresa  
		AND Solicitud.idCliente = Zona.idCliente  
		AND Solicitud.numeroContrato = Zona.numeroContrato  
	INNER JOIN Seguridad.Catalogo.Users Usuario  
		ON Solicitud.idUsuario = Usuario.Id  
	INNER JOIN Cliente.Cliente.Contrato Contrato 
		ON Contrato.rfcEmpresa = Solicitud.rfcEmpresa  
		AND Contrato.idCliente = Solicitud.idCliente  
		AND Contrato.numeroContrato = Solicitud.numeroContrato  
	WHERE 
		Solicitud.idSolicitud = @idSolicitud  
		AND Solicitud.idTipoSolicitud = @idTipoSolicitud   
		AND Solicitud.idClase = @idClase   
		AND Solicitud.rfcEmpresa = @rfcEmpresa   
		AND Solicitud.idCliente = @idCliente   
		AND Solicitud.numeroContrato = @numeroContrato  
	--DATOS DE LA UNIDAD
	INSERT INTO @tableUnidad (idSolicitud, idObjeto, idTipoObjeto, placa, modelo, VIN, combustible, cilindraje, tipoObjeto, fotoUnidad)  
	SELECT Solicitud.idSolicitud  
		, SolicitudObjeto.idObjeto  
		, SolicitudObjeto.idTipoObjeto  
		, Objeto.objeto.getPropiedadObjeto (SolicitudObjeto.idObjeto, 'Placa', 'documentoClase',@idClase)  
		, Propiedades.modelo  
		, Propiedades.VIN  
		, TipoObjeto.combustible  
		, TipoObjeto.cilindros AS cilindraje  
		, TipoObjeto.marca + ' ' + TipoObjeto.submarca  
		, FileServer.documento.urlFileServer(Cliente.cliente.SEL_FOTOUNIDADOFOTOTIPOOBJETO_FN(SolicitudObjeto.idTipoObjeto, @idClase, SolicitudObjeto.idObjeto)) AS fotoUnidad  
	FROM Solicitud.solicitud.Solicitud Solicitud  
	INNER JOIN Solicitud.solicitud.SolicitudObjeto SolicitudObjeto  
		ON Solicitud.idSolicitud = SolicitudObjeto.idSolicitud  
		AND Solicitud.idTipoSolicitud = SolicitudObjeto.idTipoSolicitud  
		AND Solicitud.idClase = SolicitudObjeto.idClase  
		AND Solicitud.rfcEmpresa = SolicitudObjeto.rfcEmpresa  
		AND Solicitud.idCliente = SolicitudObjeto.idCliente  
		AND Solicitud.numeroContrato = SolicitudObjeto.numeroContrato  
	INNER JOIN Objeto.objeto.SEL_OBJETOS_PROPIEDAD_CLASE_VW Propiedades  
		ON SolicitudObjeto.idObjeto = Propiedades.idObjeto  
		AND SolicitudObjeto.idTipoObjeto = Propiedades.idTipoObjeto  
		AND SolicitudObjeto.idClase = Propiedades.idClase  
	INNER JOIN Partida.tipoobjeto.SEL_TIPO_OBJETO_CLASE_VW TipoObjeto  
		ON Propiedades.idTipoObjeto = TipoObjeto.idTipoObjeto  
		AND Propiedades.idClase = TipoObjeto.idClase  
	WHERE 
		Solicitud.idSolicitud = @idSolicitud  
		AND Solicitud.idTipoSolicitud = @idTipoSolicitud   
		AND Solicitud.idClase = @idClase   
		AND Solicitud.rfcEmpresa = @rfcEmpresa   
		AND Solicitud.idCliente = @idCliente   
		AND Solicitud.numeroContrato = @numeroContrato  
	--DATOS DEL KM
	INSERT INTO @KM_AVL
	SELECT  
		 CONVERT(float, ISNULL(AVL.dbo.SEL_ATRIBUTO_FN(P.attributes, 'totalDistance'), 0) ) / 1000 kmPlataforma  
		,CONVERT(float, ISNULL(AVL.dbo.SEL_ATRIBUTO_FN(P0.attributes, 'odometer'), 0) ) kmDispositivo  
		,CONVERT(float, ISNULL(AVL.dbo.SEL_ATRIBUTO_FN(P11.attributes, 'obdOdometer'), 0) ) / 1000 kmOBD  
		
	FROM [TRACKER].[Tracker_Socket1].[dbo].[tc_devices] D  
	 LEFT JOIN [TRACKER].[Tracker_Socket1].[dbo].[tc_positions] P   
	  ON D.positionid = P.id  
	 LEFT JOIN [TRACKER].[Tracker_Socket1].[dbo].[tc_positions] P11   
	  ON D.positionelevenid = P11.id  
	 LEFT JOIN [TRACKER].[Tracker_Socket1].[dbo].[tc_positions] P0   
	  ON D.positionzeroid = P0.id  
	 LEFT JOIN [TRACKER].[Tracker_Socket1].[dbo].[tc_status] S   
	  ON S.deviceid = D.id  
	 WHERE   
	 D.uniqueid = @uniqueid  

	INSERT INTO @tableKM(idSolicitud,idObjeto,idTipoObjeto,kmIngresado,kmPlataforma,kmDispositivo,kmOBD,fotoEvidencia)
	select 
		Solicitud.idSolicitud
		,SolicitudObjeto.idObjeto
		,SolicitudObjeto.idTipoObjeto
		,(
			select 
				P.valor
			from solicitud.ComprobanteRecepcion C
			inner join solicitud.ComprobanteRecepcionPropiedades P on C.idComprobanteRecepcion = P.idComprobanteRecepcion 
			inner join solicitud.ComprobantePropiedades CP on CP.idPropiedadClase = P.idPropiedadClase and CP.idAgrupacion = P.idAgrupacion
			where 
				P.idAgrupacion='Tablero' and CP.valor='Odometro'
				and C.idComprobanteRecepcion = @idComprobanteRecepcion
				
		) --INGRESADO 
		,(select isnull(kmPlataforma,0) from @KM_AVL)
		,(select isnull(kmDispositivo,0) from @KM_AVL)
		,(select isnull(kmOBD,0) from @KM_AVL)
		,FileServer.documento.urlFileServer((
			select 
				P.valor
			from solicitud.ComprobanteRecepcion C
			inner join solicitud.ComprobanteRecepcionPropiedades P on C.idComprobanteRecepcion = P.idComprobanteRecepcion
			inner join solicitud.ComprobantePropiedades CP on CP.idPropiedadClase = P.idPropiedadClase and CP.idAgrupacion = P.idAgrupacion
			where 
				c.idSolicitud=Solicitud.idSolicitud and P.idAgrupacion='Tablero' and CP.valor='Evidencia'
				and C.idComprobanteRecepcion=@idComprobanteRecepcion
		)) AS fotoEvidencia
	from solicitud.solicitud Solicitud
	INNER JOIN solicitud.SolicitudObjeto SolicitudObjeto 
		ON Solicitud.idSolicitud = SolicitudObjeto.idSolicitud
		AND Solicitud.rfcEmpresa = SolicitudObjeto.rfcEmpresa
		AND Solicitud.idCliente = SolicitudObjeto.idCliente
		AND Solicitud.numeroContrato = SolicitudObjeto.numeroContrato
		AND Solicitud.idClase = SolicitudObjeto.idClase
	INNER JOIN Solicitud.ComprobanteRecepcion Comprobante 
		ON Comprobante.idSolicitud = Solicitud.idSolicitud
		AND Comprobante.rfcEmpresa = Solicitud.rfcEmpresa
		AND Comprobante.idCliente = Solicitud.idCliente
		AND Comprobante.numeroContrato = Solicitud.numeroContrato
		AND Comprobante.idClase = Solicitud.idClase
	
	where 
		Solicitud.idSolicitud = @idSolicitud  
		AND Solicitud.idTipoSolicitud = @idTipoSolicitud   
		AND Solicitud.idClase = @idClase   
		AND Solicitud.rfcEmpresa = @rfcEmpresa   
		AND Solicitud.idCliente = @idCliente   
		AND Solicitud.numeroContrato = @numeroContrato  
		AND Comprobante.idComprobanteRecepcion = @idComprobanteRecepcion

	--*************************************************************
	--CONSULTA FINAL
	--*************************************************************
	;WITH TableXML (  
		tag 
		,parent
		,[Solicitud!1!idSolicitud]
		,[Solicitud!1!numeroOrden]
		,[Solicitud!1!tipoSolicitud]
		,[Solicitud!1!fechaSolicitud]
		,[Solicitud!1!zona]
		,[Solicitud!1!contrato]
		,[Solicitud!1!link]
		,[Solicitud!1!linkAccion]
		,[Solicitud!1!solicitante]
		,[Solicitud!1!solicitanteCorreo]
		,[Unidad!2!VIN]
		,[Unidad!2!placa]
		,[Unidad!2!tipoObjeto]
		,[Unidad!2!fotoUnidad]
		,[KM!3!kmIngresado]
		,[KM!3!kmDispositivo]
		,[KM!3!kmPlataforma]
		,[KM!3!kmOBD]
		,[KM!3!evidencia]
	) AS 
	(	
		--*************************************************************
		--1. DATOS DE LA SOLCIITUD
		--*************************************************************
		SELECT 
			1								AS tag
			, null							AS parent
			,S.idSolicitud					AS [Solicitud!1!idSolicitud]
			,S.numeroOrden					AS [Solicitud!1!numeroOrden]
			,S.tipoSolicitud				AS [Solicitud!1!tipoSolicitud]
			,S.fechaCreacion				AS [Solicitud!1!fechaSolicitud]
			,S.zona							AS [Solicitud!1!zona]
			,S.contrato						AS [Solicitud!1!contrato]
			,S.link							AS [Solicitud!1!link]
			,S.linkAccion					AS [Solicitud!1!linkAccion]
			,S.solicitante					AS [Solicitud!1!solicitante]
			,S.solicitanteCorreo			AS [Solicitud!1!solicitanteCorreo]
			,NULL							AS [Unidad!2!VIN]
			,NULL							AS [Unidad!2!placa]
			,NULL							AS [Unidad!2!tipoObjeto]
			,NULL							AS [Unidad!2!fotoUnidad]
			,NULL							AS [KM!3!kmIngresado]
			,NULL							AS [KM!3!kmDispositivo]
			,NULL							AS [KM!3!kmPlataforma]
			,NULL							AS [KM!3!kmOBD]
			,NULL							AS [KM!3!evidencia]
		FROM @tableSolicitud S
		--*************************************************************
		--2. DATOS DE LA UNIDAD
		--*************************************************************
		UNION ALL
		SELECT 
			2								AS tag
			,1								AS parent
			,U.idSolicitud					AS idSolicitud
			,null							AS [Solicitud!1!numeroOrden]
			,null							AS [Solicitud!1!tipoSolicitud]
			,null							AS [Solicitud!1!fechaSolicitud]
			,null							AS [Solicitud!1!zona]
			,null							AS [Solicitud!1!contrato]
			,null							AS [Solicitud!1!link]
			,null							AS [Solicitud!1!linkAccion]
			,null							AS [Solicitud!1!solicitante]
			,null							AS [Solicitud!1!solicitanteCorreo]
			,U.VIN							AS [Unidad!2!VIN]
			,U.placa						AS [Unidad!2!placa]
			,U.tipoObjeto					AS [Unidad!2!tipoObjeto]
			,U.fotoUnidad					AS [Unidad!2!fotoUnidad]
			,NULL							AS [KM!3!kmIngresado]
			,NULL							AS [KM!3!kmDispositivo]
			,NULL							AS [KM!3!kmPlataforma]
			,NULL							AS [KM!3!kmOBD]
			,NULL							AS [KM!3!evidencia]
		FROM @tableUnidad U
		--*************************************************************
		--3. DATOS DE KM
		--*************************************************************
		UNION ALL
		select
			3								AS tag
			,1								AS parent
			,K.idSolicitud					AS idSolicitud
			,null							AS [Solicitud!1!numeroOrden]
			,null							AS [Solicitud!1!tipoSolicitud]
			,null							AS [Solicitud!1!fechaSolicitud]
			,null							AS [Solicitud!1!zona]
			,null							AS [Solicitud!1!contrato]
			,null							AS [Solicitud!1!link]
			,null							AS [Solicitud!1!linkAccion]
			,null							AS [Solicitud!1!solicitante]
			,null							AS [Solicitud!1!solicitanteCorreo]
			,null							AS [Unidad!2!VIN]
			,null							AS [Unidad!2!placa]
			,null							AS [Unidad!2!tipoObjeto]
			,null							AS [Unidad!2!fotoUnidad]
			,K.kmIngresado					AS [KM!3!kmIngresado]
			,K.kmDispositivo				AS [KM!3!kmDispositivo]
			,K.kmPlataforma					AS [KM!3!kmPlataforma]
			,K.kmOBD						AS [KM!3!kmOBD]
			,K.fotoEvidencia				AS [KM!3!evidencia]
		from @tableKM K
	)
	SELECT (  
	SELECT * FROM TableXML  
	FOR XML EXPLICIT, TYPE) AS data  
END

--USE [Solicitud]
go

