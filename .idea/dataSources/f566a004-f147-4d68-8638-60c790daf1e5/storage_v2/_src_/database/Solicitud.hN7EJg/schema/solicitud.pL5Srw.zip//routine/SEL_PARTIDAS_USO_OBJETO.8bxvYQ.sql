
-- =============================================  
-- Author: Jose Luis Lozada Guerrero
-- Create date: 06/11/2020
-- Description: Obtiene las partidas que se han usado en un objeto
-- ============== Versionamiento ================  
/*  
	Fecha		Autor			Descripción   
  
 *-	Testing...  
	EXEC [solicitud].[SEL_PARTIDAS_USO_OBJETO]  'ASE0508051B6', 185, '127','Automovil',12353,128,6282,null
	select * from solicitud.solicitud.solicitudObjeto where numeroOrden='151-1558-12353'

*/  
-- =============================================  
CREATE PROCEDURE [solicitud].[SEL_PARTIDAS_USO_OBJETO]
@rfcEmpresa		VARCHAR(13),
@idCliente		INT,
@numeroContrato VARCHAR(50),
@idClase		VARCHAR(10),
@idObjeto		INT,
@idTipoObjeto	INT,
@idUsuario		INT,
@err VARCHAR(5000) OUTPUT
AS
BEGIN
	SELECT tx.* FROM (
	SELECT	SUM(cantidad) as Cantidad,MAX(fechaEstatus) as fechaEstatus,
			scp.idPartida,
			partida.partida.getPropiedadPartida(scp.idPartida,'Partida','general') Partida,
			partida.partida.getPropiedadPartida(scp.idPartida,'noParte','general') noParte,
			partida.partida.getPropiedadPartida(scp.idPartida,'Descripción','general') Descripción,
			partida.partida.getPropiedadPartida(scp.idPartida,'Especialidad','clase') Especialidad
	--		select *
	FROM	[solicitud].[SolicitudCotizacionPartida] SCP 
	INNER	JOIN [solicitud].[solicitudCotizacion] scot 
	ON		scot.idSolicitud		=SCP.idSolicitud
	AND     scot.idTipoSolicitud	=SCP.idTipoSolicitud
	AND     scot.idClase			=SCP.idClase
	AND     scot.rfcEmpresa			=SCP.rfcEmpresa
	AND		scot.idCliente			=SCP.idCliente
	AND     scot.numeroContrato		=SCP.numeroContrato
	AND     scot.idProveedorEntidad =SCP.idProveedorEntidad
	AND     scot.idCotizacion		=SCP.idCotizacion
	AND     scot.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')
	INNER	JOIN [solicitud].[solicitud] sol 
	ON		scp.idSolicitud			=sol.idSolicitud
	AND     scp.idTipoSolicitud		=sol.idTipoSolicitud
	AND     scp.idClase				=sol.idClase
	AND     scp.rfcEmpresa			=sol.rfcEmpresa
	AND		scp.idCliente			=sol.idCliente
	AND     scp.numeroContrato		=sol.numeroContrato
	AND     sol.idEstatusSolicitud	NOT IN ('CANCELADA','RECHAZADA')
	--INNER   JOIN [partida].[partida].[partida] pa on pa.idPartida=scp.idPartida and pa.idTipoObjeto=scp.idTipoObjeto AND pa.idPartidaEstatus='ACT'
	WHERE	SCP.idObjeto		= @idObjeto
	AND		SCP.idTipoObjeto	= @idTipoObjeto
	AND		SCP.idEstatusCotizacionPartida='APROBADA'
	AND		SCP.rfcEmpresa		= @rfcEmpresa
	AND		SCP.idCliente		= @idCliente 
	AND		SCP.numeroContrato	= @numeroContrato
	AND		SCP.idClase			= @idClase
	GROUP BY scp.idPartida)tx
	ORDER BY TX.Cantidad desc
	
END


go

