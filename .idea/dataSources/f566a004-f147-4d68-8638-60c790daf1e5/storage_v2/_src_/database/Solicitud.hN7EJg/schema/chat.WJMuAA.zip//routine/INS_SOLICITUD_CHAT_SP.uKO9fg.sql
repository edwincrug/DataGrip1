-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 08/07/2019
-- Description: Actualiza o crea el último usuario que escribio en una solicitud
/*
	EXEC chat.INS_SOLICITUD_CHAT_SP @idSolicitud = 57, @idUsuario = 6117
*/
-- =============================================
CREATE PROCEDURE [chat].[INS_SOLICITUD_CHAT_SP]
	@idSolicitud INT,
	@idUsuario INT = NULL,
	@err VARCHAR(8000) = NULL OUTPUT
AS
BEGIN
    BEGIN TRY

		DECLARE @idSolicitudChat INT,
			@idTipoSolicitud VARCHAR(10),
			@idClase VARCHAR(10),
			@rfcEmpresa VARCHAR(13),
			@idCliente INT,
			@numeroContrato VARCHAR(50)

		SELECT @idSolicitudChat = idSolicitudChat
		FROM chat.SolicitudChat
		WHERE idSolicitud = @idSolicitud

		IF EXISTS (SELECT idSolicitudChat FROM chat.SolicitudChat WHERE idSolicitud = @idSolicitud)
		BEGIN
			UPDATE chat.SolicitudChat
			SET UsersId = @idUsuario,
				fechaUltimaEscritura = GETDATE()
			WHERE idSolicitudChat = @idSolicitudChat
			IF NOT EXISTS (SELECT idSolicitudChat FROM chat.SolicitudChatUsers WHERE idSolicitudChat =  @idSolicitudChat AND UsersId = @idUsuario)
			BEGIN
				INSERT INTO chat.SolicitudChatUsers(idSolicitudChat, UsersId)
				VALUES (@idSolicitudChat, @idUsuario)
			END
		END
		ELSE
		BEGIN
			SELECT @idTipoSolicitud = idTipoSolicitud,
				@idClase = idClase,
				@rfcEmpresa = rfcEmpresa,
				@idCliente = idCliente,
				@numeroContrato = numeroContrato
			FROM solicitud.Solicitud
			WHERE idSolicitud = @idSolicitud

			INSERT INTO chat.SolicitudChat (idSolicitud, idTipoSolicitud, idClase, rfcEmpresa, idCliente, numeroContrato, UsersId, fechaUltimaEscritura)
			VALUES (@idSolicitud, @idTipoSolicitud, @idClase, @rfcEmpresa, @idCliente, @numeroContrato, @idUsuario, GETDATE())
			SELECT @idSolicitudChat = @@IDENTITY
		END
		SELECT @idSolicitudChat AS idSolicitudChat
	END TRY
	BEGIN CATCH
		SELECT @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
	END CATCH
END
go

