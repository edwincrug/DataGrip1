
-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 23/07/2019
-- Description: Obtiene los datos para la solicitud a la cual se va a redirigir, se agrupan los datos ya que una solicitud puede tener multiples tipos de objeto
-- se toma el primer valor para este caso, posteriormente se realizará una adecuación para cuando se hagan solicitudes masivas
-- ============== Versionamiento ================
/*
	*- Testing...
	EXEC solicitud.SEL_SOLICITUDREDIRECCION_SP @idSolicitud = 173, @idTipoSolicitud = 'Servicio', @idClase = 'Automovil', @rfcEmpresa = 'ASE0508051B6', @idCliente = 92, @numeroContrato = '0001'
*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_SOLICITUDREDIRECCION_SP]
	@idSolicitud INT,
	@idTipoSolicitud VARCHAR(10),
	@idClase VARCHAR(10),
	@rfcEmpresa VARCHAR(13),
	@idCliente INT,
	@numeroContrato VARCHAR(50),
	@idUsuario INT = NULL,
	@err VARCHAR(500) = NULL OUTPUT
AS
BEGIN
	BEGIN TRY
		SELECT TOP 1 S.idSolicitud
			, S.idTipoSolicitud
			, S.idClase
			, S.rfcEmpresa
			, S.idCliente
			, S.numeroContrato
			, SO.numeroOrden AS numeroOrden
			, C.idFileAvatar AS idLogoContrato
			, SO.idObjeto
			, SO.idTipoObjeto
			, 0 esMultiple
			, COUNT(SO.idObjeto) AS totalObjetos
		FROM solicitud.Solicitud S
		INNER JOIN Cliente.cliente.Contrato C
		ON S.rfcEmpresa = C.rfcEmpresa
		AND S.idCliente = C.idCliente
		AND S.numeroContrato = C.numeroContrato
		INNER JOIN solicitud.SolicitudObjeto SO
		ON S.idSolicitud = SO.idSolicitud
		AND S.idTipoSolicitud = SO.idTipoSolicitud
		AND S.idClase = SO.idClase
		AND S.rfcEmpresa = SO.rfcEmpresa
		AND S.idCliente = SO.idCliente
		AND S.numeroContrato = SO.numeroContrato
		WHERE S.idSolicitud = @idSolicitud
		AND S.idTipoSolicitud = @idTipoSolicitud
		AND S.idClase = @idClase
		AND S.rfcEmpresa = @rfcEmpresa
		AND S.idCliente = @idCliente
		AND S.numeroContrato = @numeroContrato
		GROUP BY S.idSolicitud
			, S.idTipoSolicitud
			, S.idClase
			, S.rfcEmpresa
			, S.idCliente
			, S.numeroContrato
			, SO.numeroOrden
			, C.idFileAvatar
			, SO.idObjeto
			, SO.idTipoObjeto
	END TRY
	BEGIN CATCH
		SELECT @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
	END CATCH
END
go

