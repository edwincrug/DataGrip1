-- =============================================
-- Author:		Martin Pacheco
-- Create date: 13/06/2019
-- Description:	.
-- Test:		exec [solicitud].[SEL_PARTIDA_POR_IDSOL_SP] 25, 'DIC0503123MD3', 78, '123PEMEX', 'Automovil', 1, null
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_PARTIDA_POR_IDSOL_SP]
	@idSolicitud		INT = 0,
	@rfcEmpresa			VARCHAR(13) = '',
	@idCliente			INT = 0,
	@numeroContrato		VARCHAR(50) = '',
	@idClase			VARCHAR(10) = '',
	@idUsuario			INT = 0,
	@err				VARCHAR(500)	OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	;WITH [PartidaCTE] AS (
		SELECT  
			[SP].[idPartida] AS [Id]
		FROM [solicitud].[SolicitudPartida] AS [SP]
	)
	SELECT * FROM [PartidaCTE]

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

