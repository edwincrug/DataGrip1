
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 31-05-2019
-- Description: Consulta trae costos de agrupadores
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[SEL_COSTO_SP]  '03','Automovil', 6036, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[SEL_COSTO_SP] 
	@idEstado				varchar(10),
	@idClase				varchar(50),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN


--*********************************************************COSTO AGRUPADOR ********************************************************************

	IF OBJECT_ID('tempdb..#datos') IS NOT NULL
		BEGIN
			DROP TABLE #datos
		END

	IF OBJECT_ID('tempdb..#datosSAgrupador') IS NOT NULL
		BEGIN
			DROP TABLE #datos
		END

	IF OBJECT_ID('tempdb..#resAgrupador') IS NOT NULL
		BEGIN
			DROP TABLE #resAgrupador
		END

	IF OBJECT_ID('tempdb..#resSINAgrupador') IS NOT NULL
		BEGIN
			DROP TABLE #resSINAgrupador
		END


	DECLARE @columnsName varchar(max) = ''

	SET @columnsName = STUFF((SELECT ',' + QUOTENAME(nombre) 
						FROM gestoria.concepto where idClase = @idClase and activo = 1
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')

	SELECT 
		CAST(ca.idCostoAgrupador AS varchar(100)) idCostoAgrupador, 
		ca.nombre as Agrupador, 
		0 idTipoObjeto,
		CON.nombre concepto, 
		(SELECT costo 
			FROM  gestoria.agrupadorCosto 
			WHERE idCostoAgrupador = CA.idCostoAgrupador 
			AND idEstado = @idEstado 
			AND	 idConcepto = CON.idConcepto) AS costo
	INTO #datos
	from gestoria.costoAgrupador CA
	LEFT JOIN gestoria.agrupadorCosto AC ON AC.idCostoAgrupador = CA.idCostoAgrupador
	LEFT JOIN gestoria.Concepto CON ON CON.idConcepto = AC.idCOncepto
	WHERE CA.activo = 1


	SELECT
	'S/A' idCostoAgrupador,
	(SELECT  [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](TOB.idTipoObjeto,'Submarca',@idClase)) AS Agrupador,
	TOB.idTipoObjeto,
	CON.nombre concepto,
	C.Costo
	INTO #datosSAgrupador
	FROM partida.tipoObjeto.tipoObjeto TOB
	LEFT JOIN gestoria.Costo C ON C.idTipoObjeto = TOB.idTipoObjeto AND idEstado = @idEstado
	LEFT JOIN gestoria.Concepto CON ON CON.idConcepto = C.idConcepto 
	LEFT JOIN gestoria.costoAgrupadorDetalle CAD ON CAD.idTipoObjeto = C.idTipoObjeto
	WHERE CAD.idCostoAgrupador is null
	AND TOB.idClase = @idClase
	AND TOB.activo = 1

	declare @query varchar(max)
	set @query = '

	select * 
	INTO #resAgrupador
	from #datos 
	PIVOT (AVG(costo) for concepto in(' + @columnsName + ')) AS tblPiv
	ORDER BY idCostoAgrupador
	
	select * 
	INTO #resSINAgrupador
	from #datosSAgrupador 
	PIVOT (AVG(costo) for concepto in(' + @columnsName + ')) AS tblPiv
	ORDER BY idCostoAgrupador
	
	SELECT * FROM #resAgrupador
	UNION ALL
	SELECT * FROM  #resSINAgrupador'

	execute (@query)

	

--*********************************************************COSTO DETALLE AUTOMOVIL ********************************************************************

	IF(@idClase = 'Automovil')
	BEGIN

		IF OBJECT_ID('tempdb..#datosdetalle') IS NOT NULL
		BEGIN
			DROP TABLE #datosdetalle
		END

		IF OBJECT_ID('tempdb..#detalle') IS NOT NULL
		BEGIN
			DROP TABLE #detalle
		END

		SELECT 
		CAD.idCostoAgrupador, 
			CAD.idTipoObjeto, 
			con.NOMBRE,
			C.costo
		INTO #datosdetalle
		from gestoria.costoAgrupadorDetalle CAD
		LEFT JOIN  gestoria.Costo C ON C.idTipoObjeto = CAD.idTipoObjeto AND C.idEstado = @idEstado
		LEFT JOIN gestoria.costoAgrupador CA ON CA.idCostoAgrupador = CAD.idCostoAgrupador
		LEFT JOIN gestoria.agrupadorCosto AC ON AC.idConcepto = C.idCOncepto
		LEFT JOIN gestoria.Concepto CON ON CON.idConcepto = AC.idCOncepto
		WHERE CA.activo = 1
		GROUP BY  CAD.idCostoAgrupador, CAD.idTipoObjeto, c.idConcepto, C.costo, CON.NOMBRE, C.idEstado


		declare @querydetalle varchar(max)
		set @querydetalle = '

		select 
		(SELECT  [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](idTipoObjeto,''Combustible'',''Automovil'')) AS combustible,
		(SELECT  [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](idTipoObjeto,''Clase'',''Automovil'')) AS clase,
		(SELECT  [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](idTipoObjeto,''Submarca'',''Automovil'')) AS marca,
		* 
		INTO #detalle
		from #datosdetalle
		PIVOT (SUM(costo) for nombre in(' + @columnsName + ')) AS tblPiv
		ORDER BY tblPiv.idCostoAgrupador
		
		SELECT * from #detalle'

		execute (@querydetalle)
	END

		

--*********************************************************PORCENTAJE DE PAGADOS ********************************************************************


	SELECT 
		(select count(*) from gestoria.costo WHERE idEstado = @idEstado) AS conPrecio,
		COUNT(*) * (SELECT COUNT(*) from gestoria.concepto WHERE activo = 1 AND idClase = @idClase) AS total
		FROM partida.tipoobjeto.tipoobjeto
		where idclase = @idClase and activo = 1
	
	SELECT nombre 
	from gestoria.concepto 
	where activo = 1 
	and idClase = @idClase


END
go

