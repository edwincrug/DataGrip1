
CREATE VIEW [solicitud].[SEL_SOLICITUD_ZONA_VW]
AS
SELECT S.idSolicitud
	, S.idTipoSolicitud
	, S.idClase
	, S.rfcEmpresa
	, S.idCliente
	, S.numeroContrato
	, S.idEstatusSolicitud
	, S.numero
	, S.multiple
	, SO.numeroOrden
	, SO.idTipoObjeto
	, SO.idObjeto
	, CZ.idContratoZona
	, CZ.idContratoNivel
	, CZ.descripcion AS zona
FROM [solicitud].[SEL_SOLICITUD_MULTIPLE_VW] AS S
INNER JOIN solicitud.SolicitudObjeto AS SO
ON S.idSolicitud = SO.idSolicitud
	AND S.idClase = SO.idClase
	AND S.rfcEmpresa = SO.rfcEmpresa
	AND S.idCliente = SO.idCliente
	AND S.numeroContrato = SO.numeroContrato
	AND S.idTipoSolicitud = SO.idTipoSolicitud
INNER JOIN Cliente.contrato.Objeto AS CCO
	ON SO.rfcEmpresa = CCO.rfcEmpresa
	AND SO.idCliente = CCO.idCliente
	AND SO.numeroContrato = CCO.numeroContrato
	AND SO.idClase = CCO.idClase 
	AND SO.idTipoObjeto = CCO.idTipoObjeto
	AND SO.idObjeto = CCO.idObjeto
INNER JOIN Common.gerencia.ContratoZona AS CZ
	ON CCO.idContratoZona = CZ.idContratoZona
	AND CCO.rfcEmpresa = CZ.rfcEmpresa
	AND CCO.idCliente = CZ.idCliente
	AND CCO.numeroContrato = CZ.numeroContrato
go

