-- =============================================
-- Author:		Gerardo Zamudio
-- Create date: 22/09/2020
-- Description:	Edita las partidas de una solicitud
-- =============================================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	EXEC [solicitud].[UPD_PARTIDASSOLICITUD_SP]
	'ASE0508051B6',
	185,
	'43',
	1137,
	10558,
	117,
	'Automovil',
	'Imagen',
	6115,
	'<partidas><partida><idPartida>746044</idPartida><cantidad>1</cantidad><costoInicial>5700</costoInicial><ventaInicial>7125</ventaInicial></partida><partida><idPartida>746045</idPartida><cantidad>2</cantidad><costoInicial>1762.91</costoInicial><ventaInicial>2203</ventaInicial></partida><partida><idPartida>783887</idPartida><cantidad>1</cantidad><costoInicial>700</costoInicial><ventaInicial>875</ventaInicial></partida><partida><idPartida>783900</idPartida><cantidad>1</cantidad><costoInicial>3125</costoInicial><ventaInicial>3126</ventaInicial></partida></partidas>'
	''

*/
-- =============================================
create PROCEDURE [solicitud].[UPD_PARTIDASSOLICITUD_SP]
	@rfcEmpresa				VARCHAR(13) = '',
	@idCliente				INT = 0,
	@numeroContrato			VARCHAR(50) = '',
	@idSolicitud			INT,
	@idObjeto				INT = 0,
	@idTipoObjeto			INT = 0,
    @idClase				VARCHAR(10) = '',
	@idTipoSolicitud		VARCHAR(50) = '',
	@idUsuario				INT = 0,
	@partidas				XML,
	@err					VARCHAR(8000) OUTPUT	
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	DECLARE
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en el stored: [UPD_PARTIDASSOLICITUD_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_ResultCount		INT = 0,
		@VI_IdSolicitud		INT = NULL,
		@VC_NOSOLICITUD		VARCHAR(20) = NULL,
		@VD_ExpiraContrato	DATE = NULL,
		@ERR_MENSAJE		VARCHAR(100) = '',
		@xmlPadre			XML

    BEGIN TRY 
			BEGIN TRANSACTION [UPD_PARTIDASSOLICITUD_SP]	
				DECLARE @partidasSolicitud TABLE (
					[Index]			    INT IDENTITY(1,1),
					[idPartida]			INT,
					[cantidad]			INT,
					[costoInicial]		float, 
					[ventaInicial]		float
				);

				INSERT INTO @partidasSolicitud
				
				SELECT
					I.N.value('(idPartida)[1]',	'INT'),
					I.N.value('(cantidad)[1]',	'INT'),
					I.N.value('(costoInicial)[1]',	'float'),
					I.N.value('(ventaInicial)[1]',	'float')
				FROM @partidas.nodes('/partidas/partida') I(N);

				DELETE
				FROM [solicitud].[SolicitudPartida] 
				WHERE idSolicitud = @idSolicitud 
					AND rfcEmpresa = @rfcEmpresa
					AND numeroContrato = @numeroContrato
					AND idCliente = @idCliente
					AND idClase = @idClase
				
				INSERT INTO [solicitud].[SolicitudPartida]
				SELECT
					@idSolicitud,
					@idTipoSolicitud,
					@idClase,
					@rfcEmpresa,
					@idCliente,
					@numeroContrato,
					@idObjeto,
					@idTipoObjeto,
					idPartida,
					cantidad,
					costoInicial,
					ventaInicial,
					'ENESPERA',
					@idUsuario
				FROM @partidasSolicitud
			
			COMMIT TRANSACTION [UPD_PARTIDASSOLICITUD_SP]
		END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION [UPD_PARTIDASSOLICITUD_SP]
				SET @VC_ErrorMessage = { 
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage
					) 
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
				SET @err = @VC_ErrorMessage;
			END
		END CATCH
    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END

go

