-- =============================================
-- Author:		Martin Pacheco
-- Create date: 22/07/2019
-- Description:	Rechaza una partida de cotizacion.
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	25/09/2020	JLuis Lozada	se agrego validacion al borrar de la tabla solicitudCotizacionPartidaDescuento

	*- Testing...
	EXEC [solicitud].[DEL_PARTIDA_COTIZACION_SP]1608,'<Ordenes><Orden><NumeroOrden>155-1233-14150-2</NumeroOrden><Partidas><Id>767165</Id><Id>619538</Id></Partidas></Orden></Ordenes>',1,null
*/
-- =============================================
CREATE PROCEDURE [solicitud].[DEL_PARTIDA_COTIZACION_SP]
	@idSolicitud		INT,
	@Data				XML,
	@idUsuario			INT,
	@err				VARCHAR(8000) OUTPUT	
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	DECLARE
		@VI_One				INT = 1,
		@VI_Zero			INT = 0,
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en el stored: [DEL_PARTIDA_COTIZACION_SP]',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0

	CREATE TABLE #VT_ORDENES (
		[Index]				INT IDENTITY(1,1),
		[NumeroOrden]		VARCHAR(20),
		[XmlData]			XML
	);

	DECLARE @msj VARCHAR(MAX)

	INSERT INTO #VT_ORDENES
		SELECT
			I.N.value('(NumeroOrden)[1]',	'VARCHAR(20)'),
			I.N.query('.')
		FROM @Data.nodes('/Ordenes/Orden') I(N)
	
	BEGIN TRY 
		BEGIN TRANSACTION DEL_PARTIDA_COTIZACION_SP

			DECLARE @idCotizacion	INT
			SELECT
				@idCotizacion = idCotizacion
			FROM solicitud.SolicitudCotizacion WHERE numeroCotizacion = (SELECT top 1 [NumeroOrden] FROM #VT_ORDENES)

			DECLARE @totalPartidas		INT

			SET @totalPartidas = (SELECT COUNT(*) FROM solicitud.SolicitudCotizacionPartida 
									WHERE  idCotizacion = @idCotizacion) 

			DECLARE @count INT = 1, @max INT = (SELECT COUNT([Index]) FROM #VT_ORDENES);

			IF EXISTS(select * from solicitud.[cxc].[FacturaDetalle] WHERE idCotizacion = @idCotizacion)
				BEGIN
					SET @err = 'No se puede modificar la cotización porque ya esta provisionada'
					SET @msj = 'ERR'
					SELECT @msj  AS mensaje
				END

			ELSE
				BEGIN

					WHILE (@count <= @max)
						BEGIN
							DECLARE @XML XML = (SELECT [XmlData] FROM #VT_ORDENES WHERE [Index] = @count)
							DECLARE @xmlChild XML = (
								SELECT 
									I.N.query('.')
								FROM @XML.nodes('/Orden/Partidas') I(N)
							)

							DECLARE @partidas TABLE(row_id INT IDENTITY, idPartida INT)

							INSERT INTO @partidas
							SELECT 
									I.N.value('.[1]',	'INT')
								FROM @xmlChild.nodes('/Partidas/Id') I(N) 

							DECLARE @contPartida INT = 1

							WHILE ((SELECT COUNT(*) FROM @partidas) > = @contPartida)

								BEGIN
									IF((SELECT idEstatusCotizacionPartida 
											FROM solicitud.SolicitudCotizacionPartida 
											WHERE  idCotizacion = @idCotizacion
											AND idPartida = (SELECT idPartida	
																FROM @partidas
																WHERE row_id = @contPartida)) != 'APROBADA')
										BEGIN


											IF(@totalPartidas = (SELECT COUNT(*) FROM @partidas))

												BEGIN
													SET @err = 'No es posible eliminar todas las partidas de la cotización, de ser asi, elija cancelar cotización.'
												END
											ELSE
												BEGIN
													/* Inicio validacion JLuis Lozada - 25/09/2020 - Descuento costos*/
													-- Validamos si esta partida tiene descuento costo, en caso de que lo tenga, solo actualizamos los 
													-- campos porcentajeDescuentoVenta y descuentoVenta a cero, en caso de que la partida no tenga descuento 
													-- costo entonces si la borramos
													IF (SELECT	ISNULL(porcentajeDescuentoCosto,0)+ISNULL(descuentoCosto,0)
														FROM	solicitud.solicitudCotizacionPartidaDescuento
														WHERE	idCotizacion	= @idCotizacion
														AND		idSolicitud		= @idSolicitud
														AND		idPartida		= (SELECT idPartida FROM @partidas WHERE row_id = @contPartida))>0
														BEGIN
															UPDATE	solicitud.solicitudCotizacionPartidaDescuento
															SET		porcentajeDescuentoVenta=0,descuentoVenta=0
															WHERE	idCotizacion	= @idCotizacion
															AND		idSolicitud		= @idSolicitud
															AND		idPartida		= (SELECT idPartida FROM @partidas WHERE row_id = @contPartida)
														END
													ELSE
														BEGIN
															DELETE FROM solicitud.solicitudCotizacionPartidaDescuento
															WHERE idCotizacion = @idCotizacion
															AND idSolicitud = @idSolicitud
															AND idPartida = (SELECT idPartida FROM @partidas WHERE row_id = @contPartida)
														END
													/* Fin validacion*/

													DELETE FROM solicitud.solicitudCotizacionPartida 
													WHERE idCotizacion = @idCotizacion
													AND idSolicitud = @idSolicitud
													AND idPartida = (SELECT 
																		idPartida
																	FROM @partidas
																	WHERE row_id = @contPartida)


													SET @msj = 'Las partidas seleccionadas fueron eliminadas.'
													SELECT @msj AS msj

												END

								

										END
									ELSE
										BEGIN
											SET @err = 'La partida no se puede eliminar porque ya fue aprobada'
										END

									set @contPartida = @contPartida + 1
								END


						SET @count = @count + 1
						END

				END

		COMMIT TRANSACTION DEL_PARTIDA_COTIZACION_SP
	END TRY
	BEGIN CATCH
		SELECT  
			@VC_ErrorMessage	= ERROR_MESSAGE(),
			@VC_ErrorSeverity	= ERROR_SEVERITY(),
			@VC_ErrorState		= ERROR_STATE();
		BEGIN
			ROLLBACK TRANSACTION DEL_PARTIDA_COTIZACION_SP
			SET @VC_ErrorMessage = { 
				fn CONCAT(
					@VC_ThrowMessage,
					@VC_ErrorMessage
				) 
			}
			RAISERROR (
				@VC_ErrorMessage, 
				@VC_ErrorSeverity, 
				@VC_ErrorState
			);
			SET @err = @VC_ErrorMessage;
		END
	END CATCH

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

