-- =============================================
-- Author:		Luis Martinez
-- Create date: 22/06/2020
-- Description:	.
/* Test:		
	declare @err varchar(500)
	exec [solicitud].[SEL_PROPIEDAD_INVENTARIO_SP] 'Automovil','CompraGPS',6147, @err OUTPUT

*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_PROPIEDAD_INVENTARIO_SP] 
	@idClase			varchar(10),
	@idTipoSolicitud	varchar(10),
	@idUsuario			int = null,
	@err				varchar(500) OUTPUT
AS
BEGIN

DECLARE @propiedades AS TABLE(
								id				INT,
								idPadre			INT,
								valor			NVARCHAR(500),
								arreglo			NVARCHAR(500),
								idClase			NVARCHAR(500),
								idTipoValor		NVARCHAR(20),
								idTipoDato		NVARCHAR(20),
								propiedad		NVARCHAR(50),
								idPropiedad		INT,
								obligatorio		BIT,
								posicion		INT,
								orden			INT
							--	idTipoObjeto	INT,
								)

	INSERT INTO @propiedades
	SELECT
		[idPropiedadInventarioGeneral] as id
		,ISNULL([idPadre], 0) AS idPadre
		,[valor]
		,'' as arreglo
		,[idClase]
		,[idTipoValor]
		,[idTipoDato]
		,'general' propiedad
		,1 idPropiedad		  
		,[obligatorio]
		,[posicion]
		,[orden]
	FROM [solicitud].[PropiedadInventarioGeneral]
	WHERE activo=1

	INSERT INTO @propiedades
	SELECT
		[idPropiedadInventarioTipoSolicitud] as id
		,ISNULL([idPadre], 0) AS idPadre
		,[valor]
		,'' as arreglo
		,[idClase]
		,[idTipoValor]
		,[idTipoDato]
		,'tipoSolicitud' propiedad
		,2 idPropiedad		  
		,[obligatorio]
		,[posicion]
		,[orden]
	FROM [solicitud].[PropiedadInventarioTipoSolicitud]
	WHERE idClase = @idClase 
		AND idTipoSolicitud = @idTipoSolicitud
		AND	activo=1

	SELECT * FROM @propiedades
	WHERE idPadre = 0
	ORDER BY idClase,posicion, orden asc

END


--USE [Solicitud]
go

