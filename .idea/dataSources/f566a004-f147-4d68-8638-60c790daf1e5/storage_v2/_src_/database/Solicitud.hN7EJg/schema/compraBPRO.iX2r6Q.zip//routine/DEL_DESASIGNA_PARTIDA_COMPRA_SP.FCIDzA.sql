

		


-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
/*
	exec [compraBPRO].[DEL_DESASIGNA_PARTIDA_COMPRA_SP] 'ROCA010101A54',693,'<Datos><Dato><noParte>1105</noParte></Dato><Dato><noParte>PARTE 02</noParte></Dato></Datos>',6282,null

*/

-- =============================================
CREATE PROCEDURE [compraBPRO].[DEL_DESASIGNA_PARTIDA_COMPRA_SP]
	@rfcProveedor		VARCHAR(13),
	@idProveedorEntidad INT,
	@partidas			XML,
	@idUsuario			INT,
	@err				VARCHAR(500) OUTPUT	
AS
BEGIN

	DECLARE @tblDatos AS TABLE(rfcProveedor VARCHAR(13),idProveedorEntidad INT, noParte VARCHAR(500))

	INSERT INTO @tblDatos
	SELECT  @rfcProveedor,@idProveedorEntidad,ParamValues.col.value('noParte[1]','varchar(500)')
    FROM @partidas.nodes('/Datos/Dato') AS ParamValues(col)   

	
	DELETE FROM  solicitud.compraBPRO.ProveedorEntidadPartida
	WHERE rfcProveedor+CAST(idProveedorEntidad AS varchar)+numeroParte
	IN (SELECT rfcProveedor+CAST(idProveedorEntidad AS VARCHAR)+noParte FROM @tblDatos)
		
END
go

