-- =============================================  
-- Author:  <Alan Rosales Chávez>  
-- Create date: <05/07/2017>  
-- Description: <Flujo de Solicitud Flujo Normal y Contrato>  
-- =============================================  
-- ============== Versionamiento ================    
/*    
 Fecha  Autor Descripción     
     
    
 *- Testing...    
SELECT * FROM [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN('Servicio','Automovil','DIC0503123MD3','78','123PEMEX')  
*/    
-- =============================================    
CREATE FUNCTION [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN]  
(  
 @idTipoSolicitud VARCHAR(10),  
 @idClase   VARCHAR(10),  
 @rfcEmpresa   VARCHAR(13)=NULL,  
 @idCliente   INT=NULL,  
 @numeroContrato  VARCHAR(50)=NULL  
)  
RETURNS @FLUJO TABLE   
(  
 numeroPaso   INT,  
 idFase    VARCHAR(20),  
 idPaso    VARCHAR(100),    
 idTipoSolicitud  VARCHAR(10),    
 idClase    VARCHAR(10),    
 nombre    VARCHAR(100),    
 idCliente   INT,    
 numeroContrato  VARCHAR(10),    
 idPasoAnterior  VARCHAR(50),    
 ordenFase   FLOAT,    
 ordenPaso   FLOAT,    
 tiempoEstimado  TIME(7) NULL,
 tipoPaso VARCHAR(10)
)  
AS  
BEGIN  
   
 DECLARE @paso TABLE(  
  idFase    VARCHAR(20),  
  idPaso    VARCHAR(100),    
  idTipoSolicitud  VARCHAR(10),    
  idClase    VARCHAR(10),    
  nombre    VARCHAR(100),    
  idCliente   INT,    
  numeroContrato  VARCHAR(10),    
  idPasoAnterior  VARCHAR(50),    
  ordenFase   FLOAT,    
  ordenPaso   FLOAT,    
  tiempoEstimado  TIME(7) NULL,
  tipoPaso	varchar(10)
 )  
  
  
 DECLARE @cont int = 1  
 DECLARE @pasoContrato TABLE (  
  contador   int,  
  idFase    VARCHAR(20),  
  idPaso    VARCHAR(100),    
  idTipoSolicitud  VARCHAR(10),    
  idClase    VARCHAR(10),    
  nombre    VARCHAR(100),    
  idCliente   INT,    
  numeroContrato  VARCHAR(10),    
  idPasoAnterior  VARCHAR(50),    
  ordenFase   FLOAT,    
  ordenPaso   FLOAT,    
  tiempoEstimado  TIME(7) NULL,
  tipoPaso	varchar(10)
 )  
  
 --INSERTAMOS PASOS PRINCIPALES  
 INSERT INTO @paso  
 select    
  p.idFase,    
  idPaso,    
  idTipoSolicitud,    
  idClase,    
  p.nombre,    
  '' idCliente,    
  '' numeroContrato,    
  '' idPasoAnterior,    
  f.orden,  
  CAST(p.orden as float) AS orden,    
  tiempoEstimado,
  'PASO'    
 from [fase].[Paso] p  
 inner join [fase].[Fase] f on p.idFase = f.idFase  
 WHERE idClase = @idClase AND    
 [idTipoSolicitud] = @idTipoSolicitud  
 ORDER BY f.orden, p.orden  
 --INSERTAMOS PASOS POR CONTRATO  
 insert into @pasoContrato  
 SELECT    
  ROW_NUMBER() OVER(ORDER BY PC.idTipoSolicitud, PC.orden) AS Row#,    
  PC.idFase,    
  PC.idPaso,    
  PC.idTipoSolicitud,    
  PC.idClase,    
  PC.nombre,    
  PC.idCliente,    
  PC.numeroContrato,    
  PC.idPasoAnterior,    
  f.orden,  
  PC.orden,    
  PC.tiempoEstimado,
  'CONTRATO'    
  FROM faseContrato.paso PC    
  inner join fase.Fase f on pc.idFase = f.idFase  
  WHERE PC.rfcEmpresa = @rfcEmpresa AND    
  PC.idCliente = @idCliente AND    
  PC.numeroContrato = @numeroContrato AND    
  PC.idClase = @idClase AND    
  PC.idTipoSolicitud = @idTipoSolicitud    
  order by f.orden, pc.orden  
 --UNIMOS PASOS  
 WHILE ( select COUNT(*)    
 from @pasoContrato) >= @cont    
 BEGIN    
  INSERT INTO @paso    
  SELECT    
  idFase,    
  idPaso,    
  idTipoSolicitud,    
  idClase,    
  idPaso,    
  idCliente,    
  numeroContrato,    
  idPasoAnterior,    
  pc.ordenFase,  
  (SELECT CAST(TPC.ordenPaso AS VARCHAR(10)) + '.' + CAST(PC.ordenPaso AS VARCHAR(10))    
  from @paso TPC    
  WHERE TPC.idPaso = PC.idPasoAnterior AND TPC.idFase = PC.idFase)    
  ,tiempoEstimado
  ,PC.tipoPaso 
  from @pasoContrato PC    
  WHERE contador = @cont    
  order by ordenFase, ordenPaso  
  SET @cont = @cont + 1    
 END    
  
 insert into @FLUJO  
 select ROW_NUMBER() OVER(ORDER BY ordenFase, ordenPaso ASC), * from @paso order by ordenFase, ordenPaso  
  
 RETURN   
END
go

