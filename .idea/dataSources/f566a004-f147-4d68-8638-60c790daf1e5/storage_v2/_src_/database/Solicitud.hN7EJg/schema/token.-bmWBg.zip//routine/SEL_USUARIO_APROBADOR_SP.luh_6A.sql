-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Valida si el usuario es aprobador para poder generar tokens>
-- =============================================
-- EXEC [token].[SEL_USUARIO_APROBADOR_SP] 6036
-- =============================================
CREATE PROCEDURE [token].[SEL_USUARIO_APROBADOR_SP]
(
	@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN
    SELECT 
        COUNT([idReglaPasoUsuario]) totalReglas
    FROM [Solicitud].[fase].[ReglaPasoUsuario] FRPU
    WHERE FRPU.[UsersId] = @idUsuario
        AND FRPU.[activo] = 1
END
go

