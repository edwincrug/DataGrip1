-- =============================================
-- Author:		Jose Luis Lozada Guerrero
-- Create date: 16/08/2020
-- Description:	Genera numero de cotizacion.
-- Test:		SELECT [solicitud].[SEL_NUMEROCOTIZACION_MULTIPLE_FN](70,'DIC0503123MD3','Servicio','Automovil',78,'123PEME')
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 


	*- Testing...
	EXEC [solicitud].[SEL_NUMEROCOTIZACION_MULTIPLE_FN]
*/
CREATE FUNCTION [solicitud].[SEL_NUMEROCOTIZACION_MULTIPLE_FN]
(
	@idSolicitud		INT,
	@rfcEmpresa			VARCHAR(20),
	@idTipoSolicitud	VARCHAR(10),
	@idClase			VARCHAR(10),
	@idCliente			INT,
	@numeroContrato		VARCHAR(50),
	@idObjeto INT, 
	@idTipoObjeto INT
)
RETURNS VARCHAR(50)
AS
BEGIN
	DECLARE 
		@VC_NumeroOrden			VARCHAR(60) = '',
		@VC_NumeroConsecutivo	VARCHAR(8) = '',
		@VC_NumeroCotizacion	VARCHAR(50) = ''

	SELECT @VC_NumeroOrden = (
		SELECT 
			[SO].[numeroOrden]
		FROM [solicitud].[SolicitudObjeto] AS [SO]
		WHERE 
			[SO].[idSolicitud] = @idSolicitud AND 
			[SO].[idObjeto] = @idObjeto AND 
	        [SO].[idTipoObjeto] = @idTipoObjeto
			
	)

	SELECT @VC_NumeroConsecutivo = (
		SELECT TOP 1
			 COALESCE(RIGHT([CC].[numeroCotizacion],CHARINDEX('-',REVERSE([CC].[numeroCotizacion]),0)-1), 0) AS [Index]
		FROM [solicitud].[SolicitudCotizacion] AS [CC]
			 JOIN [solicitud].[SolicitudObjeto] SO ON SO.idSolicitud = [CC].idSolicitud
			JOIN [solicitud].[SolicitudCotizacionPartida] SCP ON SCP.idCotizacion = [CC].idCotizacion AND SCP.idSolicitud = [CC].idSolicitud AND SO.idObjeto = SCP.idObjeto AND SO.idTipoObjeto = SCP.idTipoObjeto
		WHERE 
			[CC].[rfcEmpresa] = @rfcEmpresa AND
			[CC].[idCliente] = @idCliente AND
			[CC].[numeroContrato] = @numeroContrato AND
			[CC].[idTipoSolicitud] = @idTipoSolicitud AND
			[CC].[idClase] = @idClase AND
			[CC].[idSolicitud] = @idSolicitud AND 
			[SO].[idObjeto] = @idObjeto AND 
	        [SO].[idTipoObjeto] = @idTipoObjeto
		ORDER BY [Index] DESC
	)

	IF (@VC_NumeroConsecutivo IS NOT NULL AND @VC_NumeroOrden IS NOT NULL)
		BEGIN
			SET @VC_NumeroCotizacion = @VC_NumeroOrden +'-'+ CAST((CAST(@VC_NumeroConsecutivo AS INT) + 1) AS VARCHAR(10))
		END
	ELSE IF (@VC_NumeroOrden IS NOT NULL AND @VC_NumeroConsecutivo IS NULL)
		BEGIN
			SET @VC_NumeroCotizacion = @VC_NumeroOrden + '-' + '1'
		END
	RETURN @VC_NumeroCotizacion
END
go

