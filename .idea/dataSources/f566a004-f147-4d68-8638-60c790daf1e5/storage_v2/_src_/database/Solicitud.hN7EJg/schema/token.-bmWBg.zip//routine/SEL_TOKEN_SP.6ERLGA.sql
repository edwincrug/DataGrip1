-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/07/2019>
-- Description:	    <Obtener los tokens por usuario>
-- =============================================
-- EXEC [token].[SEL_TOKEN_SP] 2271
-- =============================================
CREATE PROCEDURE [token].[SEL_TOKEN_SP]
(
	@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN

	-- SELECT SOLO PARA HACER TOP 200
	SELECT
		TOP(200)
		T.[idToken]
        ,T.[token]
        ,T.[fechaCrea]
        ,T.[fechaUso]
        ,T.[idUsuarioCrea]
        ,T.[idUsuarioUsa]
        ,T.[idPaso]
        ,T.[idTipoToken]
        ,T.[estatus]
        ,T.[idSolicitud]
        ,T.[numeroOrden]
        ,T.[idTipoObjeto]
        ,T.[idObjeto]
        ,T.idTipoSolicitud
        ,T.[nombre]
        ,T.tipoSolicitudNombre
        ,T.idCotizacion
        ,T.numeroCotizacion
	FROM(

	-- TOKENS POR SOLICITUD

    SELECT 
        TT.[idToken]
        ,TT.[token]
        ,TT.[fechaCrea]
        ,TT.[fechaUso]
        ,TT.[idUsuarioCrea]
        ,TT.[idUsuarioUsa]
        ,TT.[idPaso]
        ,TT.[idTipoToken]
        ,TT.[estatus]
        ,TTS.[idSolicitud]
        ,SSO.[numeroOrden]
        ,SSO.[idTipoObjeto]
        ,SSO.[idObjeto]
        ,SSO.[idTipoSolicitud]
        ,FP.[nombre]
        ,STS.[nombre] tipoSolicitudNombre
        ,0 idCotizacion
        ,'' numeroCotizacion
    FROM [Solicitud].[token].[Token] TT
    INNER JOIN [Solicitud].[token].[TokenSolicitud] TTS
        ON TT.idToken = TTS.idToken
	INNER JOIN [Solicitud].[solicitud].[Solicitud] SS
        ON TTS.[idSolicitud] = SS.[idSolicitud]
    INNER JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO
        ON TTS.[idSolicitud] = SSO.[idSolicitud]
    INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON STS.idTipoSolicitud = SS.idTipoSolicitud
        AND STS.idClase = SSO.idClase
    INNER JOIN [Solicitud].[fase].[Paso] FP
        ON TT.[idPaso] = FP.[idPaso]
    WHERE TT.[idUsuarioCrea] = @idUsuario
        AND TT.[idTipoToken] = 1
		AND SS.[idEstatusSolicitud] = 'ACTIVA'

    UNION

	-- TOKENS POR SOLICITUD Y CONTRATO

    SELECT 
        TT.[idToken]
        ,TT.[token]
        ,TT.[fechaCrea]
        ,TT.[fechaUso]
        ,TT.[idUsuarioCrea]
        ,TT.[idUsuarioUsa]
        ,TT.[idPaso]
        ,TT.[idTipoToken]
        ,TT.[estatus]
        ,TTS.[idSolicitud]
        ,SSO.[numeroOrden]
        ,SSO.[idTipoObjeto]
        ,SSO.[idObjeto]
        ,SSO.idTipoSolicitud
        ,FCP.[nombre]
        ,STS.[nombre] tipoSolicitudNombre
        ,0 idCotizacion
        ,'' numeroCotizacion
    FROM [Solicitud].[token].[Token] TT
    INNER JOIN [Solicitud].[token].[TokenSolicitud] TTS
        ON TT.idToken = TTS.idToken
	INNER JOIN [Solicitud].[solicitud].[Solicitud] SS
        ON TTS.[idSolicitud] = SS.[idSolicitud]
    INNER JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO
        ON TTS.[idSolicitud] = SSO.[idSolicitud]
    INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON STS.idTipoSolicitud = SS.idTipoSolicitud
        AND STS.idClase = SSO.idClase
    INNER JOIN [Solicitud].[faseContrato].[Paso] FCP
        ON TT.[idPaso] = FCP.[idPaso]
    WHERE TT.[idUsuarioCrea] = @idUsuario
        AND TT.[idTipoToken] = 2
		AND SS.[idEstatusSolicitud] = 'ACTIVA'

    UNION

	-- TOKENS POR COTIZACION

    SELECT 
        TT.[idToken]
        ,TT.[token]
        ,TT.[fechaCrea]
        ,TT.[fechaUso]
        ,TT.[idUsuarioCrea]
        ,TT.[idUsuarioUsa]
        ,TT.[idPaso]
        ,TT.[idTipoToken]
        ,TT.[estatus]
        ,TTC.[idSolicitud]
        ,SSO.[numeroOrden]
        ,SSO.[idTipoObjeto]
        ,SSO.[idObjeto]
        ,SSO.idTipoSolicitud
        ,FP.[nombre]
        ,STS.[nombre] tipoSolicitudNombre
        ,SSC.idCotizacion
        ,SSC.numeroCotizacion
    FROM [Solicitud].[token].[Token] TT
    INNER JOIN [Solicitud].[token].[TokenCotizacion] TTC
        ON TT.idToken = TTC.idToken
	INNER JOIN [Solicitud].[solicitud].[Solicitud] SS
        ON TTC.[idSolicitud] = SS.[idSolicitud]
    INNER JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO
        ON TTC.[idSolicitud] = SSO.[idSolicitud]
    INNER JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SSC
        ON SSC.idSolicitud = TTC.idSolicitud
        AND SSC.idCotizacion = TTC.idCotizacion
    INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON STS.idTipoSolicitud = SSO.idTipoSolicitud
        AND STS.idClase = SSO.idClase
    INNER JOIN [Solicitud].[fase].[Paso] FP
        ON TT.[idPaso] = FP.[idPaso]
    WHERE TT.[idUsuarioCrea] = @idUsuario
        AND TT.[idTipoToken] = 1
		AND SS.[idEstatusSolicitud] = 'ACTIVA'

    UNION

	-- TOKENS POR COTIZACION Y CONTRATO

    SELECT 
        TT.[idToken]
        ,TT.[token]
        ,TT.[fechaCrea]
        ,TT.[fechaUso]
        ,TT.[idUsuarioCrea]
        ,TT.[idUsuarioUsa]
        ,TT.[idPaso]
        ,TT.[idTipoToken]
        ,TT.[estatus]
        ,TTC.[idSolicitud]
        ,SSO.[numeroOrden]
        ,SSO.[idTipoObjeto]
        ,SSO.[idObjeto]
        ,SSO.idTipoSolicitud
        ,FCP.[nombre]
        ,STS.[nombre] tipoSolicitudNombre
        ,SSC.idCotizacion
        ,SSC.numeroCotizacion
    FROM [Solicitud].[token].[Token] TT
    INNER JOIN [Solicitud].[token].[TokenCotizacion] TTC
        ON TT.idToken = TTC.idToken
	INNER JOIN [Solicitud].[solicitud].[Solicitud] SS
        ON TTC.[idSolicitud] = SS.[idSolicitud]
    INNER JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO
        ON TTC.[idSolicitud] = SSO.[idSolicitud]
    INNER JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SSC
        ON SSC.idSolicitud = TTC.idSolicitud
        AND SSC.idCotizacion = TTC.idCotizacion
    INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON STS.idTipoSolicitud = SSO.idTipoSolicitud
        AND STS.idClase = SSO.idClase
    INNER JOIN [Solicitud].[faseContrato].[Paso] FCP
        ON TT.[idPaso] = FCP.[idPaso]
    WHERE TT.[idUsuarioCrea] = @idUsuario
        AND TT.[idTipoToken] = 2
		AND SS.[idEstatusSolicitud] = 'ACTIVA'
	) T
    ORDER BY T.[idToken] DESC

END
go

