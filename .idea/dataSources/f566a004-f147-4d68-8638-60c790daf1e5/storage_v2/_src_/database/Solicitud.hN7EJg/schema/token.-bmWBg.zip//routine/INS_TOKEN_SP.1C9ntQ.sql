-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<04/07/2019>
-- Description:	    <Alta de los tokens para cotizaciones>
-- =============================================
-- EXEC [token].[INS_TOKEN_SP] '1-1184-250-1', 1, 73,'Automovil', 'ASE0508051B6', 92, '0001', 2
-- =============================================
CREATE PROCEDURE [token].[INS_TOKEN_SP]
(
    @numero                     [VARCHAR](20)
    ,@puedeCotizacion           [BIT]
    ,@rol                       [INT] -- 72,73 COTIZACION Y ENTREGA     --65 TERMINO DE TRABAJO
    ,@idClase                   [VARCHAR](10)
    ,@rfcEmpresa                [VARCHAR](13)
    ,@idCliente                 [INT]
    ,@numeroContrato            [VARCHAR](50)
    ,@idUsuario			        [INT]
	,@err				        [NVARCHAR](500) = '' OUTPUT
)
AS
DECLARE
@idSolicitud                [INT] = 0
,@idCotizacion              [INT] = 0
,@idPaso                    [VARCHAR](20) = NULL
,@idFase                    [VARCHAR](20) = NULL

BEGIN
    SELECT 
        @idSolicitud = SSO.[idSolicitud]
    FROM [Solicitud].[solicitud].[SolicitudObjeto] SSO
	INNER JOIN [Solicitud].[solicitud].[Solicitud] SS
		ON SSO.idSolicitud = SS.idSolicitud
    WHERE SSO.[numeroOrden] = @numero
        AND SSO.idClase = @idClase
        AND SSO.rfcEmpresa = @rfcEmpresa
        AND SSO.idCliente = @idCliente
        AND SSO.numeroContrato = @numeroContrato
		AND SS.[idEstatusSolicitud] = 'ACTIVA'

    IF(@idSolicitud > 0)
    BEGIN
        SELECT 
            @idPaso = [idPaso]
            ,@idFase = [idFase]
        FROM [Solicitud].[solicitud].[Solicitud]
        WHERE idSolicitud = @idSolicitud
        IF(@idPaso = 'Entrega' AND @idFase = 'Entrega')
        BEGIN
            IF(@rol = 72 OR @rol = 73)
                BEGIN
                    PRINT 'GENERAR TOKEN'
                    EXEC [token].[INS_TOKEN_PASO_SP] 
                        @idSolicitud
                        ,@idPaso
                        ,@idUsuario
                        ,@err OUTPUT
                END
                ELSE
                BEGIN
                    PRINT 'ROL INCORRECTO ORDEN'
                    SET @err = 'No tiene el perfil para generar un token para esta orden.'
                END
        END
        ELSE IF(@idPaso = 'TerminoTrabajo' AND @idFase = 'Entrega')
        BEGIN
            IF(@rol = 65)
            BEGIN
                PRINT 'GENERAR TOKEN'
                EXEC [token].[INS_TOKEN_PASO_SP] 
                    @idSolicitud
                    ,@idPaso
                    ,@idUsuario
                    ,@err OUTPUT
            END
            ELSE
            BEGIN
                PRINT 'ROL INCORRECTO ORDEN TERMINO'
                SET @err = 'No tiene el perfil para generar un token para esta orden.'
            END
        END
        ELSE
        BEGIN
            PRINT 'LA ORDEN SIN ESTATUS VALIDO'
            SET @err = 'La orden no tiene un estatus valido.'
        END
    END
    ELSE
    BEGIN
        SELECT 
            @idCotizacion = SSC.[idCotizacion]
            ,@idSolicitud = SSC.[idSolicitud]
        FROM [Solicitud].[solicitud].[SolicitudCotizacion] SSC
		INNER JOIN [Solicitud].[solicitud].[Solicitud] SS
			ON SSC.idSolicitud = SS.idSolicitud
        WHERE SSC.[numeroCotizacion] = @numero
            AND SSC.idClase = @idClase
            AND SSC.rfcEmpresa = @rfcEmpresa
            AND SSC.idCliente = @idCliente
            AND SSC.numeroContrato = @numeroContrato
			AND SS.[idEstatusSolicitud] = 'ACTIVA'

        IF(@idCotizacion > 0 AND @idSolicitud > 0)
        BEGIN

            SELECT 
                @idPaso = [idPaso]
                ,@idFase = [idFase]
            FROM [Solicitud].[solicitud].[Solicitud]
            WHERE idSolicitud = @idSolicitud
            IF(@idPaso = 'EnEspera' AND @idFase = 'Aprobacion')
            BEGIN
                IF(@puedeCotizacion > 0)
                BEGIN
                    IF(@rol = 72 OR @rol = 73)
                    BEGIN
                        PRINT 'GENERAR TOKEN'
                        EXEC [token].[INS_TOKEN_COTIZACION_SP] 
                        @idSolicitud
                        ,@idCotizacion
                        ,@idPaso
                        ,@idUsuario
                        ,@err OUTPUT
                    END
                    ELSE
                    BEGIN
                        PRINT 'ROL INCORRECTO COTIZACION'
                        SET @err = 'No tiene el perfil para generar un token para esta cotización.'
                    END
                END
                ELSE
                BEGIN
                    PRINT 'NO PUEDE'
                    SET @err = 'No tiene los permisos para generar un token para esta cotización.'
                END
            END
            ELSE
            BEGIN
                PRINT 'PASO INCORRECTO COTIZACION'
                SET @err = 'La cotización se encuentra en otro paso.'
            END        
        END
        ELSE
        BEGIN
            PRINT 'NO ES NADA'
            SET @err = 'No existe el numero de orden o de cotización.'
        END
    END
END
go

