
-- =============================================
-- Author: Luis Martinez
-- Create date: 17-07-2020
-- Description: Inserta documento de hoja de trabajo
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[INS_SOLICITUDOBJETOPASO_HOJATRABAJO_SP] 565, 'Servicio', 'Automovil', 'ASE0508051B6',216, '127',119, 13517,'http://189.204.141.199:5114',835, 23454,'Comprobante de Recepción',
 2326, @salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [solicitud].[INS_SOLICITUDOBJETOPASO_HOJATRABAJO_SP] 
	@idSolicitud			INT,
	@idTipoSolicitud		VARCHAR(10),
	@idClase				VARCHAR(10),
	@rfcEmpresa				VARCHAR(13),
	@idCliente				INT,
	@numeroContrato			VARCHAR(50),
	@idTipoObjeto			INT,
	@idObjeto				INT,
	@fileServer				NVARCHAR(500),
	@idComprobanteRecepcion INT = 0,
	@idDocumento			INT,
	@nombrePaso				VARCHAR(100),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	DECLARE @idDocumentoClase INT, @version INT = 1

	SELECT
		@idDocumentoClase = idDocumentoClase
	FROM [Solicitud].[documento].[Paso]
	WHERE nombre = @nombrePaso
	AND idClase = @idClase
	and idTipoSolicitud = @idTipoSolicitud
	AND activo = 1

	
	IF EXISTS(SELECT * FROM [Solicitud].[documento].[SolicitudObjetoPaso] 
						WHERE 
						idSolicitud = @idSolicitud
						AND idTipoSOlicitud = @idTipoSolicitud
						AND idClase = @idClase
						AND rfcEmpresa = @rfcEmpresa
						AND idCliente = @idCliente
						AND numeroContrato = @numeroContrato
						AND idTipoObjeto = @idTipoObjeto
						AND idObjeto = @idObjeto
						AND idDocumentoClase = @idDocumentoClase)
	BEGIN
		IF(@nombrePaso = 'Hoja de Trabajo')
			BEGIN
				DELETE FROM [Solicitud].[documento].[SolicitudObjetoPaso] 
								WHERE 
								idSolicitud = @idSolicitud
								AND idTipoSOlicitud = @idTipoSolicitud
								AND idClase = @idClase
								AND rfcEmpresa = @rfcEmpresa
								AND idCliente = @idCliente
								AND numeroContrato = @numeroContrato
								AND idTipoObjeto = @idTipoObjeto
								AND idObjeto = @idObjeto
								AND idDocumentoClase = @idDocumentoClase
			END

		SET @version = (select top 1 [version] from  [Solicitud].[documento].[SolicitudObjetoPaso] where 
			idSolicitud = @idSolicitud
			AND idTipoSOlicitud = @idTipoSolicitud
			AND idClase = @idClase
			AND rfcEmpresa = @rfcEmpresa
			AND idCliente = @idCliente
			AND numeroContrato = @numeroContrato
			AND idTipoObjeto = @idTipoObjeto
			AND idObjeto = @idObjeto
			AND idDocumentoClase = @idDocumentoClase
			Order by version desc
			) + 1

		IF @version is null 
		BEGIN
			SET @version = 1
		END
		ELSE IF @version = '' 
		BEGIN
			SET @version = 1
		END
	END


	INSERT INTO [Solicitud].[documento].[SolicitudObjetoPaso]
		
		SELECT
			[idDocumentoClase]
			,[idPaso]
			,[idFase]
			,@idClase
			,@idCliente
			,@numeroContrato
			,@idTipoSolicitud
			,@idSolicitud
			,@rfcEmpresa
			,@idTipoObjeto
			,@idObjeto
			,@version
			,'.pdf'
			,@idDocumento
			,[vigencia]
			,(SELECT 
			numeroOrden 
			FROM [Solicitud].[solicitud].[SolicitudObjeto]
			WHERE idSolicitud = @idSolicitud
			AND idClase = @idClase
			AND rfcEmpresa = @rfcEmpresa
			AND idCliente = @idCliente
			AND numeroContrato = @numeroContrato
			AND idTipoObjeto = @idTipoObjeto
			AND idObjeto = @idObjeto
			AND idTipoSolicitud = @idTipoSolicitud)
			,@idUsuario
			,GETDATE()
			,0
			,null
			,''
		FROM
		[Solicitud].[documento].[Paso]
		WHERE idDocumentoClase = @idDocumentoClase

		IF @idComprobanteRecepcion >0
		BEGIN
			UPDATE [solicitud].ComprobanteRecepcion
				SET 
				idDocumentoClase = @idDocumentoClase,
				[version] = @version
			WHERE idComprobanteRecepcion = @idComprobanteRecepcion
		END
END

go

