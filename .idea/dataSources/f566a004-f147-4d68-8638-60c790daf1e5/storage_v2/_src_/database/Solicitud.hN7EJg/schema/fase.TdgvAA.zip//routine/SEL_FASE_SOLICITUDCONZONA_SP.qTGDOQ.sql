  
  
-- =============================================  
-- Author: Edgar Mendoza Gómez   
-- Create date: 14-06-2019  
-- Description: Consulta trae fases y pasos de solicitudes CON FILTRO DE ZONA  
-- ============== Versionamiento ================  
/*  
 Fecha  Autor  Descripción   
 08/05/2020  JLLOZADA Se agrego la fase y paso preorden en codigo duro  
 12/05/2020 JLLOZADA Se grego filtro pot contrato y zona  
  
 *- Testing...  
 DECLARE @salida varchar(max) ='' ;  
 EXEC [fase].[SEL_FASE_SOLICITUDCONZONA_SP]  'Automovil', 6282, '<contratos><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Aguascalientes</estado></contrato><contrato><numeroContrato>43<
/numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California S
ur</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Campeche</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE050
8051B6</rfcEmpresa><estado>Chiapas</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chihuahua</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>
185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Ciudad de México</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Coahuila de Zaragoza</estado></contrato><co
ntrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Colima</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>
Durango</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guanajuato</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa
>ASE0508051B6</rfcEmpresa><estado>Guerrero</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Hidalgo</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCl
iente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Jalisco</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>México</estado></contrato><contrato><numeroCon
trato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Michoacán de Ocampo</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>More
los</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nayarit</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE050
8051B6</rfcEmpresa><estado>Nuevo León</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Oaxaca</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>
185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Puebla</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Querétaro</estado></contrato><contrato><numeroContrat
o>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Quintana Roo</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>San Luis Potosí
</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sinaloa</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE050805
1B6</rfcEmpresa><estado>Sonora</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tabasco</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</i
dCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tamaulipas</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tlaxcala</estado></contrato><contrato><numeroContrato>4
3</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Veracruz de Ignacio de la Llave</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado
>Yucatán</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Zacatecas</estado></contrato></contratos>',  
 6766, @salida OUTPUT;  

 SELECT @salida AS salida;  

  DECLARE @salida varchar(max) ='' ;  
 EXEC [fase].[SEL_FASE_SOLICITUDCONZONA_SP]  'Automovil', 6282, '<contratos><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Aguascalientes</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California Sur</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Campeche</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chiapas</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chihuahua</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Ciudad de México</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Coahuila de Zaragoza</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Colima</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Durango</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guanajuato</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guerrero</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Hidalgo</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>undefined</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>México</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>undefined</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Morelos</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nayarit</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nuevo León</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Oaxaca</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Puebla</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Querétaro</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Quintana Roo</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>San Luis Potosí</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sinaloa</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sonora</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tabasco</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tamaulipas</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tlaxcala</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Veracruz de Ignacio de la Llave</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Yucatán</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Zacatecas</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Aguascalientes</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California Sur</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Campeche</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chiapas</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chihuahua</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Ciudad de México</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Coahuila de Zaragoza</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Colima</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Durango</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guanajuato</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guerrero</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Hidalgo</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Jalisco</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>México</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Michoacán de Ocampo</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Morelos</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nayarit</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nuevo León</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Oaxaca</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Puebla</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Querétaro</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Quintana Roo</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>San Luis Potosí</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sinaloa</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sonora</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tabasco</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tamaulipas</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tlaxcala</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Veracruz de Ignacio de la Llave</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Yucatán</estado></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Zacatecas</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Aguascalientes</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California Sur</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Campeche</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chiapas</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chihuahua</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Ciudad de México</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Coahuila de Zaragoza</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Colima</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Durango</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guanajuato</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guerrero</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Hidalgo</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Jalisco</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>México</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Michoacán de Ocampo</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Morelos</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nayarit</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nuevo León</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Oaxaca</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Puebla</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Querétaro</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Quintana Roo</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>San Luis Potosí</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sinaloa</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sonora</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tabasco</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tamaulipas</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tlaxcala</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Veracruz de Ignacio de la Llave</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Yucatán</estado></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Zacatecas</estado></contrato></contratos>',  
 0,@salida OUTPUT; 
*/  
-- =============================================  
CREATE  PROCEDURE [fase].[SEL_FASE_SOLICITUDCONZONA_SP]   
 @idClase    varchar(50),  
 @idUsuario    INT,  
 @contratos    XML,  
 @idZona     INT,  
 @err     varchar(500)OUTPUT  
AS  
BEGIN  
  
 DECLARE @tbl_contratos AS TABLE(numeroContrato VARCHAR(50), idCliente INT,rfc VARCHAR(13))  
 DECLARE @tbl_solicitudes AS TABLE(  
   idSolicitud   INT,  
   idPaso    VARCHAR(50),  
   idFase    VARCHAR(20),  
   idClase    VARCHAR(10),  
   paso    VARCHAR(500),  
   idPasoAnterior  VARCHAR(50),  
   color    NVARCHAR(20),  
   fechaSalida   DATETIME,  
   montoC    FLOAT,  
   montoV    FLOAT,  
   fecha    DATETIME,  
   totalPaso   INT,  
   costo    FLOAT,  
   venta    FLOAT,  
   promH    INT)  
  
 /*PREORDENES*/  
 DECLARE @v_idPaso   VARCHAR(20)  ='Preorden',  
   @v_nombrePaso  NVARCHAR(500) ='Siniestro',  
   @v_idFase   VARCHAR(20)  ='Preorden',  
   @v_nombreFase  VARCHAR(250) ='Preorden',  
   @v_img_url   NVARCHAR(200) ='./assets/images/iconos-sisco/Mantenimiento/preorden.png',  
   @v_color   VARCHAR(20)  ='#FBA703',  
   @v_idPasoAnterior VARCHAR(20)  ='',  
   @v_totalPaso  INT    =0,  
   @v_ordenFase  INT    =0,  
   @v_ordenPaso  VARCHAR(5)  ='1',  
   @v_promH   INT  
 /*PREORDENES*/  
  
 INSERT INTO @tbl_contratos  
 SELECT DISTINCT  
      ParamValues.col.value('numeroContrato[1]','varchar(50)'),  
   ParamValues.col.value('idCliente[1]','int'),  
   ParamValues.col.value('rfcEmpresa[1]','varchar(13)')  
 FROM @contratos.nodes('contratos/contrato') AS ParamValues(col)  
  
  
 SELECT @v_totalPaso = COUNT(*),@v_promH=SUM(DATEDIFF(hour, fechaCreacion, GETDATE()))  
 --  SELECT COUNT(*)  
 FROM seguro.Solicitud s  
 INNER JOIN @tbl_contratos CON ON CON.numeroContrato = s.numeroContrato AND CON.idCliente = s.idCliente AND CON.rfc = s.rfcEmpresa  
 LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = s.idObjeto  
 LEFT JOIN [common].[gerencia].[ContratoZona] CGC ON CGC.idContratoZona = CCO.idContratoZona   
 WHERE   s.idClase   = @idClase  
 AND     cco.idContratoZona = COALESCE(@idZona,cco.idContratoZona)  
  
 -------------------------------------------SI EL USUARIO ES UN PROVEEDOR----------------------------------------------  
 IF EXISTS( SELECT 1  
    FROM [Seguridad].[Relacion].[Usser_Rol] UR  
    INNER JOIN [Seguridad].[Catalogo].[Rol] CR ON UR.RolId = CR.Id AND UR.AplicacionesId = CR.AplicacionesId  
    WHERE UsersId = @idUsuario  
    AND  CR.Nombre = 'Proveedor')  
  BEGIN  
   /****************************************************** FASES *************************************************/  
   SELECT t1.idFase,t1.fase,t1.color,t1.totalFase,t1.img_url   
   FROM (  
     SELECT idFase,nombre fase,color,  
       ( SELECT DISTINCT   
          COUNT(*)   
        FROM (  
          SELECT DISTINCT  
            SEP.idSolicitud   
          FROM fase.solicitudestatuspaso SEP  
          INNER JOIN solicitud.solicitud SOL ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase AND SOL.idTipoSolicitud = SEP.idTipoSolicitud 
          INNER JOIN [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP ON SCP.idSolicitud = SOL.idSolicitud   
            AND SCP.rfcProveedor IN (SELECT rfcProveedor FROM Seguridad.Relacion.Usser_proveedor WHERE idUsuario = @idUsuario)  
            AND SCP.idProveedorEntidad IN (SELECT idProveedorEntidad FROM Seguridad.Relacion.Usser_proveedor WHERE idUsuario = @idUsuario)  
          LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud  
          LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto  
          INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato   
            AND CON.idCliente = SOL.idCliente   
            AND CON.rfc = SOL.rfcEmpresa  
          WHERE SEP.idFase    = F.idFase   
          AND  SEP.idClase    = @idClase  
          AND  SOL.idEstatusSolicitud = 'ACTIVA'  
          AND  CCO.idContratoZona  = @idZona  
          AND  SEP.fechasalida   IS NULL  
          UNION ALL  
          SELECT SEP.idSolicitud   
          FROM faseContrato.solicitudestatuspaso SEP  
          INNER JOIN solicitud.solicitud SOL ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase AND SOL.idTipoSolicitud = SEP.idTipoSolicitud
          INNER JOIN [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP ON SCP.idSolicitud = SOL.idSolicitud   
            AND SCP.rfcProveedor IN (SELECT rfcProveedor FROM Seguridad.Relacion.Usser_proveedor WHERE idUsuario = @idUsuario)  
          AND  SCP.idProveedorEntidad IN (SELECT idProveedorEntidad FROM Seguridad.Relacion.Usser_proveedor WHERE idUsuario = @idUsuario)  
          LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud  
          LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto  
          INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato   
            AND  CON.idCliente = SOL.idCliente   
            AND  CON.rfc = SOL.rfcEmpresa  
          WHERE SEP.idFase    = F.idFase   
          AND  SEP.idClase    = @idClase  
          AND  SOL.idEstatusSolicitud = 'ACTIVA'  
          AND  CCO.idContratoZona  = @idZona  
          AND  SEP.fechasalida   IS NULL   
         ) AS t  
       ) totalFase,  
       img_url,  
       F.orden  
     FROM [fase].[Fase] F  
     UNION ALL   
     SELECT @v_idFase,@v_nombreFase,@v_color,@v_totalPaso,@v_img_url,@v_ordenFase  
    )t1  
   ORDER BY t1.orden  

   /****************************************************** PASOS *************************************************/  
  
   INSERT INTO @tbl_solicitudes  
   SELECT *,COUNT(*) totalPaso,ISNULL(SUM(montoC), 0) costo,ISNULL(SUM(montoV), 0) venta,ISNULL(SUM(fecha),0) promH   
   FROM ( SELECT DISTINCT SEP.idSolicitud,SEP.idPaso,SEP.idFase,SEP.idClase,FP.nombre paso,'' idPasoAnterior,FP.color,SEP.fechaSalida,  
        ( SELECT ISNULL(SUM(costo * cantidad),0)   
         FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
         WHERE idSolicitud      =  SOL.idSolicitud  
         AND  EP.idEstatusCotizacionPartida <> 'CANCELADA') montoC,  
        ( SELECT ISNULL(SUM(venta * cantidad),0)   
         FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP  
         LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
         WHERE idSolicitud = SOL.idSolicitud  
         AND  EP.idEstatusCotizacionPartida <> 'CANCELADA') montoV,  
        DATEDIFF(hour, fechaIngreso, ISNULL(fechaSalida, GETDATE())) as fecha  
      FROM [fase].[Paso] FP    
      LEFT JOIN fase.solicitudestatuspaso SEP ON FP.idPaso = SEP.idPaso AND FP.idClase = SEP.idClase AND FP.idTipoSolicitud = SEP.idTipoSolicitud   
      LEFT JOIN solicitud.solicitud SOL ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase   
      INNER JOIN [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP ON SCP.idSolicitud = SOL.idSolicitud   
        AND  SCP.rfcProveedor IN (SELECT rfcProveedor FROM Seguridad.Relacion.Usser_proveedor WHERE idUsuario = @idUsuario)  
        AND  SCP.idProveedorEntidad IN (SELECT idProveedorEntidad FROM Seguridad.Relacion.Usser_proveedor WHERE idUsuario = @idUsuario)  
      LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud  
      LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto  
      INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa  
      WHERE SEP.idClase    = @idClase  
      AND  FP.idClase    = @idClase  
      AND  SOL.idEstatusSolicitud = 'ACTIVA'  
      AND  SEP.fechaSalida   IS NULL  
      AND  CCO.idContratoZona  = @idZona  
      UNION ALL  
      SELECT DISTINCT CEP.idSolicitud,CEP.idPaso,CEP.idFase,CEP.idClase,FP.nombre paso,FP.idPasoAnterior,FP.color,CEP.fechaSalida,  
        ( SELECT ISNULL(SUM(costo * cantidad), 0) from [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP  
         LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
         WHERE idSolicitud = SOL.idSolicitud  
         AND  EP.idEstatusCotizacionPartida <> 'CANCELADA') montoC,  
        ( SELECT ISNULL(SUM(venta * cantidad), 0) from [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP  
         LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
         WHERE idSolicitud = SOL.idSolicitud  
         AND  EP.idEstatusCotizacionPartida <> 'CANCELADA') montoV,  
        DATEDIFF(HOUR, fechaIngreso, ISNULL(fechaSalida, GETDATE())) as fecha  
      FROM [faseContrato].[Paso] FP   
      LEFT JOIN  [faseContrato].[SolicitudEstatusPaso] CEP ON FP.idPaso = CEP.idPaso AND FP.idClase = CEP.idClase AND FP.idTipoSolicitud = CEP.idTipoSolicitud   
      LEFT JOIN solicitud.solicitud SOL ON SOL.idSolicitud = CEP.idSolicitud AND SOL.idClase = CEP.idClase   
      INNER JOIN [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP ON SCP.idSolicitud = SOL.idSolicitud AND SCP.rfcProveedor IN (SELECT rfcProveedor from Seguridad.Relacion.Usser_proveedor WHERE idUsuario = @idUsuario)  
        AND SCP.idProveedorEntidad IN (SELECT idProveedorEntidad from Seguridad.Relacion.Usser_proveedor WHERE idUsuario = @idUsuario)  
      LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud  
      LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto  
      INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa  
      WHERE CEP.idClase    = @idClase   
      AND  FP.idClase    = @idClase  
      AND  SOL.idEstatusSolicitud = 'ACTIVA'  
      AND  CEP.fechaSalida   IS NULL  
      AND  CCO.idContratoZona  = @idZona  
     )T  
   GROUP BY idSolicitud, idPaso, idFase, idClase, paso,idPasoAnterior, color, fechaSalida, montoC, montoV, fecha  
     
   SELECT t.idPaso,t.idFase,t.idClase,t.nombre as paso,t.idPasoAnterior,t.color,  
     ISNULL((SELECT SUM(totalPaso) from @tbl_solicitudes WHERE idPaso = t.idPaso),0) totalPaso,  
     ISNULL((SELECT SUM(costo) from @tbl_solicitudes WHERE idPaso = t.idPaso),0) costo,  
     ISNULL((SELECT SUM(venta) from @tbl_solicitudes WHERE idPaso = t.idPaso),0) venta,  
     ISNULL((SELECT SUM(promH) from @tbl_solicitudes WHERE idPaso = t.idPaso),0) promH,  
     orden  
   FROM(   
     SELECT DISTINCT idPaso,idFase,idClase,nombre,color,'' idPasoAnterior,CAST(orden AS VARCHAR(10)) orden   
     FROM [fase].[Paso] P  
     WHERE idClase = @idClase  
     UNION ALL  
     SELECT DISTINCT idPaso,idFase,idClase,nombre,color,idPasoAnterior,   
       (SELECT CAST(P.orden AS VARCHAR(10)) + '.' + CAST(FCP.orden AS VARCHAR(10))   FROM [fase].[Paso] P WHERE p.idPaso = FCP.idPasoAnterior) orden  
     from [faseContrato].[Paso] FCP  
     WHERE idClase = @idClase  
    )t  
   UNION ALL   
   SELECT @v_idPaso,@v_idFase,@idClase,@v_nombrePaso,@v_idPasoAnterior,@v_color,@v_totalPaso,0,0,@v_promH,@v_ordenPaso  
   ORDER BY t.idFase, orden  
  END  
 ELSE  
  BEGIN  
   /****************************************************** FASES *************************************************/  
   SELECT t1.idFase,t1.fase,t1.color,t1.totalFase,t1.img_url   
   FROM(  
     SELECT idFase,nombre fase,color,  
       ( SELECT DISTINCT COUNT(*)   
        FROM ( SELECT DISTINCT  
            SEP.idSolicitud   
          FROM fase.solicitudestatuspaso SEP  
          INNER JOIN solicitud.solicitud SOL ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase AND SOL.idTipoSolicitud = SEP.idTipoSolicitud
          LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud  
          LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto  
          INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa  
          WHERE SEP.idFase    = F.idFase   
          AND  SEP.idClase    = @idClase  
          AND  SOL.idEstatusSolicitud = 'ACTIVA'  
          AND  CCO.idContratoZona  = @idZona  
          AND  SEP.fechasalida   IS NULL  
          UNION ALL  
          SELECT SEP.idSolicitud   
          FROM faseContrato.solicitudestatuspaso SEP  
          INNER JOIN solicitud.solicitud SOL ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase AND SOL.idTipoSolicitud = SEP.idTipoSolicitud 
          LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud  
          LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto  
          INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa  
          WHERE SEP.idFase = F.idFase   
          AND  SEP.idClase = @idClase  
          AND  SOL.idEstatusSolicitud = 'ACTIVA'  
          AND  CCO.idContratoZona = @idZona  
          AND SEP.fechasalida is null   
         ) AS t  
       ) totalFase,  
       img_url,  
       F.orden  
     FROM [fase].[Fase] F  
     UNION ALL SELECT @v_idFase,@v_nombreFase,@v_color,@v_totalPaso,@v_img_url,@v_ordenFase --SOLO PREORDENES  
    )t1  
   ORDER BY orden  
  
   /****************************************************** PASOS *************************************************/  
   INSERT INTO @tbl_solicitudes  
   SELECT *,COUNT(*) totalPaso,ISNULL(SUM(montoC), 0) costo,ISNULL(SUM(montoV), 0) venta,ISNULL(SUM(fecha),0) promH  
   FROM( SELECT DISTINCT SEP.idSolicitud,SEP.idPaso,SEP.idFase,SEP.idClase,FP.nombre paso,'' idPasoAnterior,FP.color,SEP.fechaSalida,  
       ( SELECT ISNULL(SUM(costo * cantidad),0)   
        FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
        WHERE idSolicitud = SOL.idSolicitud  
        AND  EP.idEstatusCotizacionPartida <> 'CANCELADA') montoC,  
       ( SELECT ISNULL(SUM(venta * cantidad),0)   
        FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
        WHERE idSolicitud = SOL.idSolicitud  
        AND  EP.idEstatusCotizacionPartida <> 'CANCELADA') montoV,  
        DATEDIFF(hour, fechaIngreso, ISNULL(fechaSalida, GETDATE())) as fecha  
     FROM [fase].[Paso] FP    
     LEFT JOIN fase.solicitudestatuspaso SEP ON FP.idPaso = SEP.idPaso AND FP.idClase = SEP.idClase AND FP.idTipoSolicitud = SEP.idTipoSolicitud   
     LEFT JOIN solicitud.solicitud SOL ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase   
     LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud  
     LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto  
     INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa  
     WHERE SEP.idClase    = @idClase  
     AND  FP.idClase    = @idClase  
     AND  SOL.idEstatusSolicitud = 'ACTIVA'  
     AND  SEP.fechaSalida   IS NULL  
     AND  CCO.idContratoZona  = @idZona  
     UNION ALL  
     SELECT DISTINCT CEP.idSolicitud,CEP.idPaso,CEP.idFase,CEP.idClase,FP.nombre paso,FP.idPasoAnterior,FP.color,CEP.fechaSalida,  
       ( SELECT ISNULL(SUM(costo * cantidad), 0)   
        FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
        WHERE idSolicitud = SOL.idSolicitud  
        AND  EP.idEstatusCotizacionPartida <> 'CANCELADA') montoC,  
       ( SELECT ISNULL(SUM(venta * cantidad), 0)   
        FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
        WHERE idSolicitud = SOL.idSolicitud  
        AND  EP.idEstatusCotizacionPartida <> 'CANCELADA') montoV,  
       DATEDIFF(hour, fechaIngreso, ISNULL(fechaSalida, GETDATE())) as fecha  
     FROM [faseContrato].[Paso] FP   
     LEFT JOIN  [faseContrato].[SolicitudEstatusPaso] CEP ON FP.idPaso = CEP.idPaso AND FP.idClase = CEP.idClase AND FP.idTipoSolicitud = CEP.idTipoSolicitud 
     LEFT JOIN solicitud.solicitud SOL ON SOL.idSolicitud = CEP.idSolicitud AND SOL.idClase = CEP.idClase   
     LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud  
     LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto  
     INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa  
     WHERE CEP.idClase    = @idClase   
     AND  FP.idClase    = @idClase  
     AND  SOL.idEstatusSolicitud = 'ACTIVA'  
     AND  CEP.fechaSalida   IS NULL  
     AND  CCO.idContratoZona  = @idZona  
    )T  
   GROUP BY idSolicitud, idPaso, idFase, idClase, paso,idPasoAnterior, color, fechaSalida, montoC, montoV, fecha  
  
   SELECT t.idPaso,t.idFase,t.idClase,t.nombre as paso,t.idPasoAnterior,t.color,  
     ISNULL((SELECT SUM(totalPaso) from @tbl_solicitudes WHERE idPaso = t.idPaso and idFase = t.idFase and idClase = t.idClase),0) totalPaso,  
     ISNULL((SELECT SUM(costo) from @tbl_solicitudes WHERE idPaso = t.idPaso and idFase = t.idFase and idClase = t.idClase),0) costo,  
     ISNULL((SELECT SUM(venta) from @tbl_solicitudes WHERE idPaso = t.idPaso and idFase = t.idFase and idClase = t.idClase),0) venta,  
     ISNULL((SELECT SUM(promH) from @tbl_solicitudes WHERE idPaso = t.idPaso and idFase = t.idFase and idClase = t.idClase),0) promH,  
     orden  
   FROM(  
     SELECT DISTINCT idPaso,idFase,idClase,--nombre,
		(SELECT TOP 1 nombre FROM [fase].[Paso] WHERE idPaso = P.idPaso and idFase = P.idFase and idClase = P.idClase ORDER BY orden DESC) nombre,
		(SELECT TOP 1 color FROM [fase].[Paso] WHERE idPaso = P.idPaso and idFase = P.idFase and idClase = P.idClase ORDER BY orden DESC) color,
		'' idPasoAnterior,
		(SELECT TOP 1 CAST(orden AS VARCHAR(10)) FROM [fase].[Paso] WHERE idPaso = P.idPaso and idFase = P.idFase and idClase = P.idClase ORDER BY orden DESC) orden    
     FROM [fase].[Paso] P  
     WHERE idClase = @idClase  
     UNION ALL  
     SELECT DISTINCT idPaso,idFase,idClase,--nombre,
		(SELECT TOP 1 nombre FROM [faseContrato].[Paso] WHERE idPaso = FCP.idPaso and idFase = FCP.idFase and idClase = FCP.idClase ORDER BY orden DESC) nombre,
		(SELECT TOP 1 color FROM [faseContrato].[Paso] WHERE idPaso = FCP.idPaso and idFase = FCP.idFase and idClase = FCP.idClase ORDER BY orden DESC) color,
		idPasoAnterior,   
       (SELECT TOP 1 CAST(P.orden AS VARCHAR(10)) + '.' + CAST(FCP.orden AS VARCHAR(10)) FROM [fase].[Paso] P  WHERE P.idPaso = FCP.idPasoAnterior and P.idFase = FCP.idFase and P.idClase = FCP.idClase ORDER BY P.orden DESC) orden     
     FROM [faseContrato].[Paso] FCP  
     WHERE idClase = @idClase  
    )t  
   UNION ALL   
   SELECT @v_idPaso,@v_idFase,@idClase,@v_nombrePaso,@v_idPasoAnterior,@v_color,@v_totalPaso,0,0,@v_promH,@v_ordenPaso --SOLO PREORDENES  
   ORDER BY t.idFase, orden  
  END  
END
go

