-- =============================================
-- Author:		<DVR>
-- Create date: <24/08/2020>
-- Description:	<Selecciona los datos del Gps para su asignacion>
-- TEST [solicitud].[SEL_OBJETO_ASIGNA_VALIDACION_GPS_SP] '202004000515',2271,''
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_OBJETO_ASIGNA_VALIDACION_GPS_SP] 
	@gps				varchar(50),
	@idUsuario			int,  
	@err				varchar(500)OUTPUT 
AS
BEGIN
	BEGIN TRY
			
			declare @socket varchar(10) 
			--OBTENEMOS LA VERSION DEL SOCKET
			select 
				@socket = 
					case
						when d1.id is null and d2.id is null then ''
						when d1.id is not null and d2.id is null then 'Socket1'
						when d1.id is null and d2.id is not null then 'Socket2'
						when d1.id is not null and d2.id is not null then 
						case
							when isnull(d1.lastupdate,convert(date,'01/01/1900'))>isnull(d2.lastUpdate,convert(date,'01/01/1900')) then 'Socket1'
							when isnull(d2.lastupdate,convert(date,'01/01/1900'))>isnull(d1.lastUpdate,convert(date,'01/01/1900')) then 'Socket2'
						end
					end
			from [Tracker].Tracker_Socket1.dbo.tc_devices d1 
			left join [Tracker].Tracker_Socket2.dbo.tc_devices d2 on d1.uniqueid=d2.uniqueid
			where 
				d1.uniqueid=@gps or
				d2.uniqueid=@gps


			print @socket

			if (@socket='Socket1')
			BEGIN
				SELECT TOP 1 COALESCE(P.fixtime,'sinFecha')  AS primerReporte
				FROM [TRACKER].Tracker_Socket1.dbo.tc_devices d
				INNER JOIN [TRACKER].Tracker_Socket1.dbo.tc_positions p ON p.deviceid = d.id
				WHERE d.uniqueid = @gps
				ORDER BY p.fixtime 


				SELECT  COALESCE(d.lastupdate,'sinFecha')  AS ultimoReporte,				
						COALESCE(p.latitude,'sinLatitude') AS latitude,
						COALESCE(p.longitude,'sinlongitude') AS longitude,
						'Socket1' as Socket,
						d.id id
										
				FROM [TRACKER].Tracker_Socket1.dbo.tc_devices d
				INNER JOIN [TRACKER].Tracker_Socket1.dbo.tc_positions p ON d.positionid = p.id 
				WHERE d.uniqueid = @gps
				ORDER BY d.lastupdate
			END

			else if (@socket='Socket2')
			BEGIN
				SELECT TOP 1 COALESCE(P.fixtime,'sinFecha')  AS primerReporte
				FROM [TRACKER].Tracker_Socket2.dbo.tc_devices d
				INNER JOIN [TRACKER].Tracker_Socket2.dbo.tc_positions p ON p.deviceid = d.id
				WHERE d.uniqueid = @gps
				ORDER BY p.fixtime 


				SELECT  COALESCE(d.lastupdate,'sinFecha')  AS ultimoReporte,				
						COALESCE(p.latitude,'sinLatitude') AS latitude,
						COALESCE(p.longitude,'sinlongitude') AS longitude,
						'Socket2' as Socket,
						d.id id
										
				FROM [TRACKER].Tracker_Socket2.dbo.tc_devices d
				INNER JOIN [TRACKER].Tracker_Socket2.dbo.tc_positions p ON d.positionid = p.id 
				WHERE d.uniqueid = @gps
				ORDER BY d.lastupdate
			END
			else				
			begin
				SELECT '' primerReporte
				SELECT '' ultimoReporte, '19.3362541545884' latitude, '-99.194070002651' longitude, 'Socket0' as Socket, 0 id
			end
  		
			

	END TRY
	BEGIN CATCH
				SELECT
				ERROR_NUMBER() AS ErrorNumber,
				ERROR_STATE() AS ErrorState,
				ERROR_SEVERITY() AS ErrorSeverity,
				ERROR_PROCEDURE() AS ErrorProcedure,
				ERROR_LINE() AS ErrorLine,
				ERROR_MESSAGE() AS ErrorMessage;
	END CATCH;
END

--USE [Solicitud]
go

