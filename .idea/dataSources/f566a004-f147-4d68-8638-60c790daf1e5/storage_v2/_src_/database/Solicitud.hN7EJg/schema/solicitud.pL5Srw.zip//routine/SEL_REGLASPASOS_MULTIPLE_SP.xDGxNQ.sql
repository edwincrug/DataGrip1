  
-- =============================================  
-- Author: Adolfo Martinez 
-- Create date: 03-08-2020  
-- Description: Obtiene las reglas de los pasos de las solicitudes multiple
-- ============== Versionamiento ================  
/*  
 Fecha  Autor   Descripción   
 
  
 *- Testing...  
 
 EXEC [solicitud].[SEL_REGLASPASOS_MULTIPLE_SP] 1016, 'ASE0508051B6', 219, '128', 6115, 11, '';
 EXEC [solicitud].[SEL_REGLASPASOS_MULTIPLE_SP] 1039, 'AAN910409135', 218, '0001', 6334, 11, ''
 roles, usuarios y monto total de la solicitud
 aqui o puedes o no puedes el 100%
 select * from [Solicitud].[fase].[ReglaPaso] where rfcEmpresa='ASE0508051B6' and numerocontrato='128' and idcliente=219 and idTipoSolicitud='Servicio'
*/  
-- =============================================  
CREATE  PROCEDURE [solicitud].[SEL_REGLASPASOS_MULTIPLE_SP]  
 @idSolicitud		int,
 @rfcEmpresa		varchar(13),  
 @idCliente			int,  
 @numeroContrato	varchar(50),
 @idUsuario			int,  
 @idAplicacion		int,
 @err				varchar(500)OUTPUT  
AS  
  
  
BEGIN  
	DECLARE @idTipoSolicitud VARCHAR(20);

	SELECT 
		@idTipoSolicitud = idTipoSolicitud 
	FROM Solicitud.solicitud.Solicitud 
	WHERE idSolicitud = @idSolicitud

	SELECT R.Id INTO #idRolesUsuario FROM Seguridad.Relacion.Usser_Rol UR
	INNER JOIN Seguridad.Catalogo.Rol R ON R.Id = UR.RolId
	WHERE UsersId = @idUsuario 
	 AND R.AplicacionesId = @idAplicacion


	DECLARE @reglas TABLE (
		--id							int identity,
		aplicaReglaRol				bit,
		aplicaReglaMonto			bit,
		aplicaReglaUsuario			bit,
		--aplicaReglaPartida			bit,
		--aplicaReglaObjeto			bit,
		idRol						int,
		idTipoMonto					varchar(50),
		montoMinimo					float,
		montoMaximo					float,
		idUsuario					int,
		--idPartida					int,
		--idObjeto					int,
		idNivel						int
	)

	DECLARE @scp TABLE (
		id							int identity,
		idCotizacion				int,
		idSolicitud					int,
		rfcProveedor				varchar(13),
		idProveedorEntidad			int,
		rfcEmpresa					varchar(13),
		idCliente					int,
		numeroContrato				varchar(50),
		idObjeto					int,
		idPartida					int,
		cantidad					int,
		venta						float,
		aplicaRegla					bit,
		colorNivel					varchar(50)
	)
	

	INSERT INTO @reglas
	  SELECT 
		RP.aplicaReglaRol,
		RP.aplicaReglaMonto,
		RP.aplicaReglaUsuario,
		--RP.aplicaReglaPartida,
		--RP.aplicaReglaObjeto,
		RR.RolId,
		RM.idTipoMonto,
		RM.montoMinimo,
		RM.montoMaximo,
		RU.idUsuario,
		--RPP.idPartida,
		--RO.idObjeto,
		RP.idNivel
	  FROM [Solicitud].[fase].[ReglaPaso] RP
	  LEFT JOIN [fase].[ReglaPasoRol] RR ON RR.idReglaPaso = RP.idReglaPaso
	  LEFT JOIN [fase].[ReglaPasoMonto] RM ON RM.idReglaPaso = RP.idReglaPaso
	  LEFT JOIN [fase].[ReglaPasoUsuario] RU ON RU.idReglaPaso = RP.idReglaPaso
	  --LEFT JOIN [fase].[ReglaPasoPartida] RPP ON RPP.idReglaPaso = RP.idReglaPaso
	  --LEFT JOIN [fase].[ReglaPasoObjeto] RO ON RO.idReglaPaso = RP.idReglaPaso
	WHERE 
			RP.rfcEmpresa = @rfcEmpresa 
			AND RP.numeroContrato = @numeroContrato 
			AND RP.idCliente = @idCliente 
			AND RP.idTipoSolicitud = @idTipoSolicitud
			AND RP.activo = 1
			AND (RU.UsersId = @idUsuario
			OR RR.RolId IN (SELECT Id FROM #idRolesUsuario))


	INSERT INTO @scp
	SELECT
		idCotizacion
		,idSolicitud
		,rfcProveedor
		,idProveedorEntidad
		,rfcEmpresa
		,idCliente
		,numeroContrato
		,idObjeto
		,idPartida
		,cantidad
		,venta
		,0
		,0
	FROM [solicitud].[SolicitudCotizacionPartida]
	WHERE	rfcEmpresa = @rfcEmpresa 
			AND numeroContrato = @numeroContrato 
			AND idCliente = @idCliente 
			AND idTipoSolicitud = @idTipoSolicitud
			AND idSolicitud = @idSolicitud

	--SELECT * FROM @reglas
	--SELECT * FROM @scp

	IF EXISTS(SELECT aplicaReglaRol 
			FROM @reglas 
			WHERE aplicaReglaRol = 1 
			AND aplicaReglaUsuario = 0
			AND aplicaReglaMonto = 0
			--AND aplicaReglaPartida = 0
			--AND aplicaReglaObjeto = 0
			)
		BEGIN
			UPDATE @scp SET aplicaRegla = 1
		END
	
	IF EXISTS(SELECT aplicaReglaRol 
			FROM @reglas 
			WHERE aplicaReglaRol = 0
			AND aplicaReglaUsuario = 1
			AND aplicaReglaMonto = 0
			--AND aplicaReglaPartida = 0
			--AND aplicaReglaObjeto = 0
			)
		BEGIN
			UPDATE @scp SET aplicaRegla = 1
		END

	IF EXISTS(SELECT aplicaReglaMonto 
			FROM @reglas 
			WHERE aplicaReglaMonto = 1)
		BEGIN
			DECLARE @montoMaximo float,
				@montoMinimo float
			IF EXISTS(SELECT idTipoMonto FROM @reglas WHERE idTipoMonto = 'Solicitud')
			BEGIN
				DECLARE @montoSolicitudT TABLE (
					id					int identity,
					montoMinimo			float,
					montoMaximo			float
				)
				insert into @montoSolicitudT
				SELECT  
					montoMinimo,
					montoMaximo
				FROM @reglas
				WHERE aplicaReglaMonto = 1 AND idTipoMonto = 'Solicitud'
				DECLARE @contadorMonto INT = 1
				DECLARE @contadorReglas INT = (SELECT COUNT(*) FROM @montoSolicitudT )
				WHILE(@contadorMonto <= @contadorReglas)
					BEGIN
						SELECT  
							@montoMinimo = montoMinimo,
							@montoMaximo = montoMaximo
						FROM @montoSolicitudT
						WHERE id = @contadorMonto
						
						IF EXISTS(SELECT 
									subTotalVenta
								   FROM [Solicitud].[solicitud].[SEL_TOTALES_SOLICITUD_VW]
								   WHERE idSolicitud = @idSolicitud 
								   AND subTotalVenta BETWEEN @montoMinimo AND @montoMaximo)
						BEGIN
							UPDATE @scp SET aplicaRegla = 1
						END
						--SELECT 
						--	*
						--FROM @scp
						--WHERE venta BETWEEN @montoMinimo AND @montoMaximo
						
						SET @contadorMonto = @contadorMonto + 1;
					END
			END

			--IF EXISTS(SELECT idTipoMonto FROM @reglas WHERE idTipoMonto = 'Partida')
			--BEGIN
			--	DECLARE @montoPartidaT TABLE (
			--		id					int identity,
			--		montoMinimo			float,
			--		montoMaximo			float
			--	)
				
			--	insert into @montoPartidaT
			--	SELECT  
			--		montoMinimo,
			--		montoMaximo
			--	FROM @reglas
			--	WHERE aplicaReglaMonto = 1 AND idTipoMonto = 'Partida'
				
			--	DECLARE @contadorMontoPartida INT = 1
			--	DECLARE @contadorReglasPartida INT = (SELECT COUNT(*) FROM @montoPartidaT)
				
			--	WHILE(@contadorMontoPartida <= @contadorReglasPartida)
			--	BEGIN
			--		SELECT  
			--			@montoMinimo = montoMinimo,
			--			@montoMaximo = montoMaximo
			--		FROM @montoPartidaT
			--		WHERE id = @contadorMontoPartida

			--		DECLARE @contadorCotizacion INT = 1,
			--		@contadorSolicitudCotizacion INT = (SELECT COUNT(*) FROM @scp)
					
			--		WHILE(@contadorCotizacion <= @contadorSolicitudCotizacion)
			--			BEGIN

			--				UPDATE @scp SET aplicaRegla = 1 WHERE id = @contadorCotizacion AND (venta * cantidad) BETWEEN @montoMinimo AND @montoMaximo
			--				SET @contadorCotizacion = @contadorCotizacion + 1;
			--			END
					
			--		SET @contadorMontoPartida = @contadorMontoPartida + 1
			--	END
			--END

			--IF EXISTS(SELECT idTipoMonto FROM @reglas WHERE idTipoMonto = 'Cantidad')
			--BEGIN
			--	DECLARE @montoCantidadT TABLE (
			--		id					int identity,
			--		montoMinimo			float,
			--		montoMaximo			float
			--	)
				
			--	insert into @montoPartidaT
			--	SELECT  
			--		montoMinimo,
			--		montoMaximo
			--	FROM @reglas
			--	WHERE aplicaReglaMonto = 1 AND idTipoMonto = 'Cantidad'
				
			--	DECLARE @contadorMontoCantidad INT = 1
			--	DECLARE @contadorReglasCantidad INT = (SELECT COUNT(*) FROM @montoCantidadT)
				
			--	WHILE(@contadorMontoCantidad <= @contadorReglasCantidad)
			--	BEGIN
			--		SELECT  
			--			@montoMinimo = montoMinimo,
			--			@montoMaximo = montoMaximo
			--		FROM @montoCantidadT
			--		WHERE id = @contadorMontoCantidad

			--		DECLARE @contadorCotizacionCantidad INT = 1,
			--		@contadorSolicitudCotizacionCantidad INT = (SELECT COUNT(*) FROM @scp)
					
			--		WHILE(@contadorCotizacionCantidad <= @contadorSolicitudCotizacionCantidad)
			--			BEGIN

			--				UPDATE @scp SET aplicaRegla = 1 WHERE id = @contadorCotizacionCantidad 
			--												AND cantidad BETWEEN @montoMinimo AND @montoMaximo
			--												AND idPartida IN (SELECT idPartida FROM @reglas WHERE idTipoMonto = 'Cantidad')
			--				SET @contadorCotizacionCantidad = @contadorCotizacionCantidad + 1;
			--			END
					
			--		SET @contadorMontoCantidad = @contadorMontoCantidad + 1
			--	END
			--END

		END


	--IF EXISTS(SELECT aplicaReglaPartida 
	--		FROM @reglas 
	--		WHERE aplicaReglaPartida = 1)
	--	BEGIN
	--		UPDATE @scp SET aplicaRegla = 1 
	--		WHERE idPartida IN (SELECT idPartida FROM @reglas WHERE aplicaReglaPartida = 1)
	--	END

	--IF EXISTS(SELECT aplicaReglaObjeto 
	--		FROM @reglas 
	--		WHERE aplicaReglaObjeto = 1)
	--	BEGIN
	--		UPDATE @scp SET aplicaRegla = 1 
	--		WHERE idObjeto IN (SELECT idObjeto FROM @reglas WHERE aplicaReglaObjeto = 1)
	--	END


	IF EXISTS(SELECT idNivel 
			FROM @reglas 
			WHERE idNivel IS NOT NULL)
		BEGIN
			
			DECLARE @nivelT TABLE (
					id					int identity,
					idNivel				int,
					--idPartida			int,
					colorNivel			varchar(50)
				)
				
				insert into @nivelT
				SELECT  
					R.idNivel,
					--R.idPartida,
					CN.color
				FROM @reglas R
				INNER JOIN Cliente.contrato.ContratoNivel CN ON CN.idNivel = R.idNivel
				WHERE R.idNivel IS NOT NULL
				
				DECLARE @contadorNivel INT = 1
				DECLARE @contadorReglasNivel INT = (SELECT COUNT(*) FROM @nivelT)

				WHILE(@contadorNivel <= @contadorReglasNivel)
					BEGIN
						
						DECLARE @colorNivel varchar(50) = (SELECT CN.color FROM @nivelT N
																		 INNER JOIN Cliente.contrato.ContratoNivel CN ON CN.idNivel = N.idNivel
																		 WHERE N.id = @contadorNivel)

						UPDATE @scp 
							SET aplicaRegla = 1,	
								colorNivel = @colorNivel
						WHERE idPartida in (SELECT idPartida FROM @nivelT WHERE id = @contadorNivel)

						SET @contadorNivel = @contadorNivel + 1
					END
		END


		--select * from @reglas
		--select *  FROM @scp s
		SELECT DISTINCT
			idSolicitud, 
			idProveedorEntidad, 
			rfcProveedor, 
			--0 aplicaRegla
			(CASE WHEN EXISTS(SELECT 1 FROM @scp SS WHERE SS.idSolicitud= S.idSolicitud AND SS.aplicaRegla = 0) THEN 0 ELSE 1 END) aplicaRegla
		FROM @scp S
END  
--USE [Solicitud]
go

