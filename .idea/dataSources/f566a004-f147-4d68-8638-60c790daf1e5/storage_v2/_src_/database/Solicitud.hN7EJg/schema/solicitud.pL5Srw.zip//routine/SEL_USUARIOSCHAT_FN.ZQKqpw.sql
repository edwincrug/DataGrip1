-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 22/08/2019
-- Description: Seleccionar los usuarios de un chat concatenados por pipes
-- SELECT solicitud.SEL_USUARIOSCHAT_FN(16)
-- =============================================
CREATE FUNCTION solicitud.SEL_USUARIOSCHAT_FN
(
	@idSolicitudChat INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @usuarios VARCHAR(MAX) = ''
	SELECT @usuarios = @usuarios + COALESCE((U.PrimerNombre + ' ' + U.PrimerApellido + ' ' + U.SegundoApellido), '') + '|' FROM chat.SolicitudChatUsers SC
	INNER JOIN Seguridad.Catalogo.Users U ON SC.UsersId = U.Id
	WHERE idSolicitudChat = @idSolicitudChat
	RETURN @usuarios
END
go

