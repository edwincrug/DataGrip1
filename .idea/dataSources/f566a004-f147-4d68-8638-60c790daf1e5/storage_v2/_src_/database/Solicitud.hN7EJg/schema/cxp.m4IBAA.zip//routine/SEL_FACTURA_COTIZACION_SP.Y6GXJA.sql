
-- =============================================
-- Author: Andres Farias
-- Create date: 09-07-2019
-- Description: Obtener las facturas de una solicitud
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [cxp].[SEL_FACTURA_COTIZACION_SP] 'DIC0503123MD3','AFAB92111053A', 78, '123PEMEX', 98,  92, 'Automovil',6110, NULL;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [cxp].[SEL_FACTURA_COTIZACION_SP]
	@rfcEmpresa				varchar(13),
	@rfcProveedor           varchar(13),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	@idSolicitud			int = null,
	@idTipoObjeto			int,
	@idClase				varchar(10),
	@idUsuario				int,
	@err					varchar(500)OUTPUT
AS

BEGIN
	SELECT scfd.idCotizacion 
			,sc.numeroCotizacion
			,scfd.idProveedorEntidad
			,scfd.rfcProveedor
			,scfd.rfcEmpresa
			,scfd.montoAbonado
			,scfd.fechaAbono
			,scfd.idPartida
			,U.PrimerNombre + ' ' + U.SegundoNombre + ' ' + U.PrimerApellido + ' ' + U.SegundoApellido as usuario
			,f.fechaFactura
			,f.folio
			,f.subtotal
			,f.iva
			,f.total
			,f.uuid
	FROM cxp.SolicitudCotizacionFactura scf
	INNER JOIN  cxp.SolicitudCotizacionFacturaDetalle scfd ON scf.idCotizacion = scfd.idCotizacion and
												     scf.uuid = scfd.uuid and 
													 scf.idClase = scfd.idClase and 
													 scf.idCliente = scfd.idCliente and 
													 scf.rfcEmpresa = scfd.rfcEmpresa and
													 scf.idSolicitud = scfd.idSolicitud and
													 scf.idTipoSolicitud = scfd.idTipoSolicitud and
													 scf.idProveedorEntidad = scfd.idProveedorEntidad and
													 scf.rfcProveedor = scfd.rfcProveedor
	INNER JOIN solicitud.SolicitudCotizacion sc ON  sc.idClase = scf.idClase and 
													 sc.idCliente = scf.idCliente and 
													 sc.rfcEmpresa = scf.rfcEmpresa and
													 sc.idSolicitud = scf.idSolicitud and
													 sc.idTipoSolicitud = scf.idTipoSolicitud and
													 sc.idProveedorEntidad = scf.idProveedorEntidad and
													 sc.rfcProveedor = scf.rfcProveedor and
													 sc.idCotizacion = scfd.idCotizacion
	INNER JOIN cxp.Factura f ON f.uuid = scfd.uuid
	INNER JOIN Seguridad.Catalogo.Users U on U.Id = scfd.idUsuario
		WHERE scfd.idClase = @idClase and 
			  scfd.idCliente = @idCliente and 
			  scfd.idSolicitud = @idSolicitud and
			  scfd.rfcEmpresa = @rfcEmpresa and
			  scfd.numeroContrato = @numeroContrato and
			  scfd.idTipoObjeto = @idTipoObjeto and 
			  scfd.rfcProveedor = @rfcProveedor

END
go

