  
-- =============================================  
-- Author: Alan Rosales Chávez  
-- Create date: 04/07/2019  
-- Description: Verifica estatus actual de la orden y   
--    la avanza al siguiente paso en caso de cumplir reglas de negocio  
-- ============== Versionamiento ================  
/*  
 Fecha  Autor Descripción   
   
  
 *- Testing...  
	DECLARE @salida varchar(max) ='' ;  
    EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]  
         @idSolicitud = 12107  
        ,@idTipoSolicitud = 'Instala'  
        ,@idClase = 'Automovil'  
        ,@rfcEmpresa = 'ASE0508051B6'  
        ,@idCliente = 185  
        ,@numeroContrato = '43'  
		,@idTipoObjeto = 0
		,@idObjeto = 0
        ,@idUsuario = 2350
        ,@err = @salida out  
    SELECT @salida AS salida;  
*/  
-- =============================================  
  
CREATE PROCEDURE [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]  
 @idSolicitud  INT,  
 @idTipoSolicitud VARCHAR(10),  
 @idClase   VARCHAR(10),  
 @rfcEmpresa   VARCHAR(13),  
 @idCliente   INT,  
 @numeroContrato  VARCHAR(50),  
 @idTipoObjeto INT =0,
 @idObjeto INT = 0,
 @idUsuario   INT,  
 @err    VARCHAR(500) OUTPUT  
  
AS  
BEGIN  
   
 --VARIABLES DE FASE, PASO Y ESTATUS DE ORDEN  
 declare   
  @idFaseActual    VARCHAR(20),  
  @idPasoActual    VARCHAR(50),  
  @idFaseSiguiente   VARCHAR(20),  
  @idPasoSiguiente   VARCHAR(50),  
  @tipoPasoActual    VARCHAR(10), --PASO = FLUJO NORMAL, CONTRATO = FLUJO DE CONTRATO  
  @tipoPasoSiguiente   VARCHAR(10), --PASO = FLUJO NORMAL, CONTRATO = FLUJO DE CONTRATO  
  @idEstatusSolicitud   VARCHAR(10),  
  @procesaAvance    BIT = 0  
  
 --VARIABLES GLOBALES  
  
 declare   
   @totalPartidas int,   
   @totalPartidaEnEspera int  
  
 SELECT   
  @idFaseActual   = sol.idFase  
  ,@idPasoActual   = sol.idPaso,  
  @tipoPasoActual   = sol.tipoPaso  
 FROM [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud) sol  
   
  
 --VALIDAMOS QUE LA SOLICITUD NO ESTÉ YA FINALIZADA  
 if (@idFaseActual='' or @idFaseActual is null)  
 begin  
  set @err = 'El proceso no puede continuar, la solicitud no existe o ya está Finalizada.'  
  return  
 end  
 --OBTENEMOS EL SIGUIENTE PASO  
 select   
  @idFaseSiguiente = (select top 1 idFase from [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN(@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) where numeroPaso = flujo.numeroPaso+1),  
  @idPasoSiguiente = (select top 1  idPaso from [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN(@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) where numeroPaso = flujo.numeroPaso+1),  
  @tipoPasoSiguiente = (select top 1  tipoPaso from [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN(@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) where numeroPaso = flujo.numeroPaso+1)  
 from [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN(@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) flujo  
 where   
  flujo.idPaso = @idPasoActual  
  
/*+++++++++++++++++++++++++++++++++++++++INICIO DE VALIDACION POR TIPO DE CLASE Y ORDEN +++++++++++++++++++++++++++++++++++++++++++++*/     

 /*****************************************************************************************************************************  
 CLASE:					AUTOMOVIL  
******************************************************************************************************************************/  
IF @idClase='Automovil'
BEGIN
	/************************************************************************************************************************** 
	************************************************FASE SOLICITUD*************************************************************
	**************************************************************************************************************************/  
	IF (@idFaseActual='Solicitud')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Imagen,Corralon,Equipa,Gestoria,Grua,ManoObra,Refaccion,Servicio,Traslado
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Imagen'  OR
			@idTipoSolicitud = 'Corralon' OR
			@idTipoSolicitud = 'Equipa' OR
			@idTipoSolicitud = 'Gestoria' OR
			@idTipoSolicitud = 'Grua' OR
			@idTipoSolicitud = 'ManoObra' OR
			@idTipoSolicitud = 'Refaccion' OR
			@idTipoSolicitud = 'Servicio' OR
			@idTipoSolicitud = 'Traslado' OR
			@idTipoSolicitud = 'ordenLegal' OR
			@idTipoSolicitud = 'Instala' OR
			@idTipoSolicitud = 'Desinstala' OR
			@idTipoSolicitud = 'Garantia' OR
			@idTipoSolicitud = 'Revision' OR
			@idTipoSolicitud = 'Iguala'
		)
		BEGIN
			--PASO: SinTaller
			IF (@idPasoActual = 'SinTaller')
			BEGIN  
				/*  
				REGLA DE NEGOCIO PARA AVANZAR ORDEN:  
				1) VERIFICAR QUE LA SOLICITUD TENGA AL MENOS UNA COTIZACION CON LOS SIGUIENTES ESTATUS  
				1.1) EN ESPERA DE APROBACION  
				1.2) APROBADA  
  
				*/  
				--OBTENEMOS EL TOTAL DE PARTIDAS  
				select @totalPartidas = count(1)  
				from solicitud.SolicitudCotizacion [cot]  
				inner join solicitud.SolicitudCotizacionPartida [cotpar] on   
				[cot].idSolicitud = [cotpar].idSolicitud   
				and [cot].idTipoSolicitud = [cotpar].idTipoSolicitud   
				and [cot].idClase = [cotpar].idClase   
				and [cot].rfcEmpresa = [cotpar].rfcEmpresa   
				and [cot].idCliente = [cotpar].idCliente   
				and [cot].numeroContrato = [cotpar].numeroContrato   
				and [cot].idProveedorEntidad = [cotpar].idProveedorEntidad   
				and [cot].rfcProveedor = [cotpar].rfcProveedor   
				where  
				[cot].idSolicitud = @idSolicitud   
				and [cot].idSolicitud = @idSolicitud   
				and [cot].idTipoSolicitud = @idTipoSolicitud  
				and [cot].idClase = @idClase  
				and [cot].rfcEmpresa = @rfcEmpresa  
				and [cot].idCliente = @idCliente  
				and [cot].numeroContrato = @numeroContrato  
				--OBTENEMOS EL TOTAL DE PARTIDAS EN ESPERA  
				select @totalPartidaEnEspera = count(1)  
				from solicitud.SolicitudCotizacion [cot]  
				inner join solicitud.SolicitudCotizacionPartida [cotpar] on   
				[cot].idSolicitud = [cotpar].idSolicitud   
				and [cot].idTipoSolicitud = [cotpar].idTipoSolicitud   
				and [cot].idClase = [cotpar].idClase   
				and [cot].rfcEmpresa = [cotpar].rfcEmpresa   
				and [cot].idCliente = [cotpar].idCliente   
				and [cot].numeroContrato = [cotpar].numeroContrato   
				and [cot].idProveedorEntidad = [cotpar].idProveedorEntidad   
				and [cot].rfcProveedor = [cotpar].rfcProveedor   
				where  
				[cot].idSolicitud = @idSolicitud   
				and [cot].idSolicitud = @idSolicitud   
				and [cot].idTipoSolicitud = @idTipoSolicitud  
				and [cot].idClase = @idClase  
				and [cot].rfcEmpresa = @rfcEmpresa  
				and [cot].idCliente = @idCliente  
				and [cot].numeroContrato = @numeroContrato  
				and [cotpar].idEstatusCotizacionPartida = 'ENESPERA'      
				IF (@totalPartidas = @totalPartidaEnEspera)  
				BEGIN   
					SET @procesaAvance = 1  
				END  
				ELSE  
				BEGIN  
					set @err = 'La solicitud tiene cotizaciones con estatus diferente a APROBACION.'  
					return  
				END  
			END  		
			--PASO: CitaConfirmada
			IF (@idPasoActual = 'CitaConfirmada')  
			BEGIN  
				/*  
				REGLA DE NEGOCIO PARA AVANZAR ORDEN:  
				1) Se verifica que exista comprobane de recepcion  
  
				*/  
				set @procesaAvance = 1  
			END    
			--PASO: EnTaller  
			IF (@idPasoActual = 'EnTaller')  
			BEGIN  
				/*  
				REGLA DE NEGOCIO PARA AVANZAR ORDEN:  
				1) No aplica ninguna regla, unicamente se avanza por petición del cliente  
				*/  
				set @procesaAvance = 1  
			END   
		END
		/*******************************************************************************************************************  
		TIPOS DE SOLICITUD: Seguro, Siniestro, Robo
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Seguro'  OR
			@idTipoSolicitud = 'Siniestro' OR
			@idTipoSolicitud = 'Traslado' OR 
			@idTipoSolicitud = 'ordenLegal'
		)
		BEGIN
			--PASO: VALUACIÓN
			IF (@idPasoActual='Valuacion')
			BEGIN
				/*  
				REGLA DE NEGOCIO PARA AVANZAR ORDEN:  
				1) VERIFICAR QUE LA SOLICITUD TENGA AL MENOS UNA COTIZACION CON LOS SIGUIENTES ESTATUS  
				1.1) EN ESPERA DE APROBACION  
				1.2) APROBADA    
				*/  
				--OBTENEMOS EL TOTAL DE PARTIDAS  
				select @totalPartidas = count(1)  
				from solicitud.SolicitudCotizacion [cot]  
				inner join solicitud.SolicitudCotizacionPartida [cotpar] on   
				[cot].idSolicitud = [cotpar].idSolicitud   
				and [cot].idTipoSolicitud = [cotpar].idTipoSolicitud   
				and [cot].idClase = [cotpar].idClase   
				and [cot].rfcEmpresa = [cotpar].rfcEmpresa   
				and [cot].idCliente = [cotpar].idCliente   
				and [cot].numeroContrato = [cotpar].numeroContrato   
				and [cot].idProveedorEntidad = [cotpar].idProveedorEntidad   
				and [cot].rfcProveedor = [cotpar].rfcProveedor   
				where  
				[cot].idSolicitud = @idSolicitud   
				and [cot].idSolicitud = @idSolicitud   
				and [cot].idTipoSolicitud = @idTipoSolicitud  
				and [cot].idClase = @idClase  
				and [cot].rfcEmpresa = @rfcEmpresa  
				and [cot].idCliente = @idCliente  
				and [cot].numeroContrato = @numeroContrato  
				--OBTENEMOS EL TOTAL DE PARTIDAS EN ESPERA  
				select @totalPartidaEnEspera = count(1)  
				from solicitud.SolicitudCotizacion [cot]  
				inner join solicitud.SolicitudCotizacionPartida [cotpar] on   
				[cot].idSolicitud = [cotpar].idSolicitud   
				and [cot].idTipoSolicitud = [cotpar].idTipoSolicitud   
				and [cot].idClase = [cotpar].idClase   
				and [cot].rfcEmpresa = [cotpar].rfcEmpresa   
				and [cot].idCliente = [cotpar].idCliente   
				and [cot].numeroContrato = [cotpar].numeroContrato   
				and [cot].idProveedorEntidad = [cotpar].idProveedorEntidad   
				and [cot].rfcProveedor = [cotpar].rfcProveedor   
				where  
				[cot].idSolicitud = @idSolicitud   
				and [cot].idSolicitud = @idSolicitud   
				and [cot].idTipoSolicitud = @idTipoSolicitud  
				and [cot].idClase = @idClase  
				and [cot].rfcEmpresa = @rfcEmpresa  
				and [cot].idCliente = @idCliente  
				and [cot].numeroContrato = @numeroContrato  
				and [cotpar].idEstatusCotizacionPartida = 'ENESPERA'      
				IF (@totalPartidas = @totalPartidaEnEspera)  
				BEGIN   
					SET @procesaAvance = 1  
				END  
				ELSE  
				BEGIN  
					set @err = 'La solicitud tiene cotizaciones con estatus diferente a APROBACION.'  
					return  
				END  
			END
		END	
	END
	/**************************************************************************************************************************
	************************************************FASE APROBACION************************************************************
	**************************************************************************************************************************/
	IF (@idFaseActual='Aprobacion')
	BEGIN
		/********************************************************************************************************************* 
		****TIPOS DE SOLICITUD: Imagen,Corralon,Equipa,Gestoria,Grua,ManoObra,Refaccion,Servicio,Traslado
		**********************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Imagen'  OR
			@idTipoSolicitud = 'Corralon' OR
			@idTipoSolicitud = 'Equipa' OR
			@idTipoSolicitud = 'Gestoria' OR
			@idTipoSolicitud = 'Grua' OR
			@idTipoSolicitud = 'ManoObra' OR
			@idTipoSolicitud = 'Refaccion' OR
			@idTipoSolicitud = 'Servicio' OR
			@idTipoSolicitud = 'Traslado' OR
			@idTipoSolicitud = 'ordenLegal' OR
			@idTipoSolicitud = 'Instala' OR
			@idTipoSolicitud = 'Desinstala' OR
			@idTipoSolicitud = 'Garantia' OR
			@idTipoSolicitud = 'Revision' OR
			@idTipoSolicitud = 'Iguala'
		)
		BEGIN
			--PASO: EnEspera
			IF (@idPasoActual = 'EnEspera')  
			BEGIN  
				/*  
				REGLA DE NEGOCIO PARA AVANZAR ORDEN:  
				1) que no haya ninguna partida en espera, y con que haya una aprobada, pasa al siguiente paso  
				*/  
				IF NOT EXISTS(SELECT idEstatusCotizacionPartida   
					FROM solicitud.solicitud SOL  
					LEFT JOIN [solicitud].[SolicitudCotizacionPartida] SO ON SO.idSolicitud = SOL.idSolicitud  
					WHERE SOL.idSolicitud = @idSolicitud   
					AND SOL.idClase = @idClase  
					AND SOL.rfcEmpresa = @rfcEmpresa  
					AND SOL.idCliente = @idCliente  
					AND SOL.numeroContrato = @numeroContrato  
					AND idEstatusCotizacionPartida = 'ENESPERA') AND EXISTS(SELECT idEstatusCotizacionPartida   
									FROM solicitud.solicitud SOL  
									LEFT JOIN [solicitud].[SolicitudCotizacionPartida] SO ON SO.idSolicitud = SOL.idSolicitud  
									WHERE SOL.idSolicitud = @idSolicitud   
									AND SOL.idClase = @idClase  
									AND SOL.rfcEmpresa = @rfcEmpresa  
									AND SOL.idCliente = @idCliente  
									AND SOL.numeroContrato = @numeroContrato  
									AND idEstatusCotizacionPartida = 'APROBADA')  
				BEGIN  
					set @procesaAvance = 1  
					SELECT 1 cambiaPaso  
				END  
				ELSE  
				BEGIN  
					set @procesaAvance = 0  
					SELECT 0 cambiaPaso  
				END  
			END  
		END
		/********************************************************************************************************************* 
		****TIPOS DE SOLICITUD: Seguro, Siniestro, Robo
		**********************************************************************************************************************/
		IF (
			@idTipoSolicitud = 'Seguro'  OR
			@idTipoSolicitud = 'Siniestro' OR
			@idTipoSolicitud = 'Traslado'
		)
		BEGIN
			IF (@idPasoActual = 'AutorizaCosto')
			BEGIN
				/*  
				REGLA DE NEGOCIO PARA AVANZAR ORDEN:  
				1) que no haya ninguna partida en espera, y con que haya una aprobada, pasa al siguiente paso  
				*/  
				IF NOT EXISTS(SELECT idEstatusCotizacionPartida   
					FROM solicitud.solicitud SOL  
					LEFT JOIN [solicitud].[SolicitudCotizacionPartida] SO ON SO.idSolicitud = SOL.idSolicitud  
					WHERE SOL.idSolicitud = @idSolicitud   
					AND SOL.idClase = @idClase  
					AND SOL.rfcEmpresa = @rfcEmpresa  
					AND SOL.idCliente = @idCliente  
					AND SOL.numeroContrato = @numeroContrato  
					AND idEstatusCotizacionPartida = 'ENESPERA') AND EXISTS(SELECT idEstatusCotizacionPartida   
									FROM solicitud.solicitud SOL  
									LEFT JOIN [solicitud].[SolicitudCotizacionPartida] SO ON SO.idSolicitud = SOL.idSolicitud  
									WHERE SOL.idSolicitud = @idSolicitud   
									AND SOL.idClase = @idClase  
									AND SOL.rfcEmpresa = @rfcEmpresa  
									AND SOL.idCliente = @idCliente  
									AND SOL.numeroContrato = @numeroContrato  
									AND idEstatusCotizacionPartida = 'APROBADA')  
				BEGIN  
					set @procesaAvance = 1  
					SELECT 1 cambiaPaso  
				END  
				ELSE  
				BEGIN  
					set @procesaAvance = 0  
					SELECT 0 cambiaPaso  
				END  
			END
		END
	END
	/**************************************************************************************************************************  
	************************************************FASE PROCESO***************************************************************
	**************************************************************************************************************************/
	IF (@idFaseActual='Proceso')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Imagen,Corralon,Equipa,Gestoria,Grua,ManoObra,Refaccion,Servicio,Traslado
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Imagen'  OR
			@idTipoSolicitud = 'Corralon' OR
			@idTipoSolicitud = 'Equipa' OR
			@idTipoSolicitud = 'Gestoria' OR
			@idTipoSolicitud = 'Grua' OR
			@idTipoSolicitud = 'ManoObra' OR
			@idTipoSolicitud = 'Refaccion' OR
			@idTipoSolicitud = 'Servicio' OR
			@idTipoSolicitud = 'Traslado' OR
			@idTipoSolicitud = 'ordenLegal' OR
			@idTipoSolicitud = 'Iguala' OR 
			@idTipoSolicitud = 'Revision' or
			@idTipoSolicitud = 'Instala' or
			@idTipoSolicitud = 'Garantia'  or
			@idTipoSolicitud = 'Desinstala' 
		)
		BEGIN
			--Paso: EnProceso  
			IF (@idPasoActual = 'EnProceso')  
			BEGIN   
				/*  
				REGLA DE NEGOCIO PARA AVANZAR ORDEN:  
				1) Validamos que exista la hoja de trabajo  
				*/  
				IF EXISTS (  
					select 1   
					from [solicitud].[documento].[SolicitudObjetoPaso] sop  
						inner join documento.Paso pa on pa.idDocumentoClase = sop.idDocumentoClase
					where   
					sop.idFileServer is not null   
					and sop.idSolicitud = @idSolicitud  
					and sop.idClase = @idClase  
					and sop.idTipoSolicitud = @idTipoSolicitud  
					and sop.rfcEmpresa = @rfcEmpresa  
					and sop.idCliente = @idCliente  
					and sop.numeroContrato = @numeroContrato  
					and pa.nombre = 'Hoja de Trabajo'
				)  
				BEGIN  
					set @procesaAvance = 1  
				END  
			END
		END
		/********************************************************************************************************************* 
		****TIPOS DE SOLICITUD: Seguro, Siniestro, Robo
		**********************************************************************************************************************/
		IF (
			@idTipoSolicitud = 'Seguro'  OR
			@idTipoSolicitud = 'Siniestro' OR
			@idTipoSolicitud = 'Traslado'
		)
		BEGIN
			IF (@idPasoActual = 'EnProceso')
			BEGIN				
				set @procesaAvance = 1  				
			END
		END
	END
	/**************************************************************************************************************************  
	************************************************FASE ENTREGA***************************************************************
	**************************************************************************************************************************/
	IF (@idFaseActual='Entrega')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Imagen,Corralon,Equipa,Gestoria,Grua,ManoObra,Refaccion,Servicio,Traslado
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Imagen'  OR
			@idTipoSolicitud = 'Corralon' OR
			@idTipoSolicitud = 'Equipa' OR
			@idTipoSolicitud = 'Gestoria' OR
			@idTipoSolicitud = 'Grua' OR
			@idTipoSolicitud = 'ManoObra' OR
			@idTipoSolicitud = 'Refaccion' OR
			@idTipoSolicitud = 'Servicio' OR
			@idTipoSolicitud = 'Traslado' OR
			@idTipoSolicitud = 'ordenLegal' OR
			@idTipoSolicitud = 'Iguala' or
			@idTipoSolicitud = 'Revision' or
			@idTipoSolicitud = 'Instala' or
			@idTipoSolicitud = 'Garantia'  or
			@idTipoSolicitud = 'Desinstala' 
		)
		BEGIN
			--Paso: TerminoTrabajo
			IF (@idPasoActual = 'TerminoTrabajo')  
			BEGIN  
  
				DECLARE @tabla table (   
					[idToken] int  
				   ,[token] varchar(6)  
				   ,[fechaCrea] datetime  
				   ,[fechaUso] datetime  
				   ,[idUsuarioCrea] int  
				   ,[idUsuarioUsa] int  
				   ,[idPaso] varchar(50)  
				   ,[idTipoToken] int  
				   ,[estatus]  bit  
				   ,[idSolicitud] int  
				   ,[idTipoSolicitud] varchar(10)  
				   ,[idClase] varchar(10)  
				   ,[rfcEmpresa] varchar(13)  
				   ,[idCliente] int  
				   ,[numeroContrato] varchar(50))  
  
				INSERT INTO @tabla	
				EXEC [token].[SEL_TOKEN_POR_SOLICITUD_PASO_SP]  @idSolicitud, @idPasoActual, @idUsuario  
				IF EXISTS(select * from @tabla)  
				BEGIN  
					IF EXISTS (select fechaUso from @tabla)  
					BEGIN  
						SET @procesaAvance = 1  
					END  
					ELSE  
					BEGIN  
						SET @procesaAvance = 0  
					END  
				END  
				ELSE  
				BEGIN  
					SET @procesaAvance = 0  
				END  
			END  
			--Paso: Entrega
			IF (@idPasoActual = 'Entrega')  
			BEGIN
				INSERT INTO @tabla  
				EXEC [token].[SEL_TOKEN_POR_SOLICITUD_PASO_SP] @idSolicitud, @idPasoActual, @idUsuario  
				IF EXISTS(select * from @tabla)  
				BEGIN  
					IF EXISTS (select fechaUso from @tabla)  
					BEGIN  
						SET @procesaAvance = 1  
					END  
					ELSE  
					BEGIN  
						SET @procesaAvance = 0  
					END  
				END  
				ELSE  
				BEGIN  
					SET @procesaAvance = 0  
				END  
			END
		END
		/********************************************************************************************************************* 
		****TIPOS DE SOLICITUD: Seguro, Siniestro, Robo
		**********************************************************************************************************************/
		IF (
			@idTipoSolicitud = 'Seguro'  OR
			@idTipoSolicitud = 'Siniestro' OR
			@idTipoSolicitud = 'Traslado'
		)
		BEGIN
			IF (@idPasoActual = 'Finiquito')
			BEGIN				
				set @procesaAvance = 1  				
			END
		END
	END
	/**************************************************************************************************************************  
	************************************************FASE COBRANZA**************************************************************
	**************************************************************************************************************************/
	IF (@idFaseActual='Cobranza')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Imagen,Corralon,Equipa,Gestoria,Grua,ManoObra,Refaccion,Servicio,Traslado
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Imagen'  OR
			@idTipoSolicitud = 'Corralon' OR
			@idTipoSolicitud = 'Equipa' OR
			@idTipoSolicitud = 'Gestoria' OR
			@idTipoSolicitud = 'Grua' OR
			@idTipoSolicitud = 'ManoObra' OR
			@idTipoSolicitud = 'Refaccion' OR
			@idTipoSolicitud = 'Servicio' OR
			@idTipoSolicitud = 'Traslado' OR
			@idTipoSolicitud = 'ordenLegal' OR
			@idTipoSolicitud = 'Iguala' or
			@idTipoSolicitud = 'Revision' or
			@idTipoSolicitud = 'Instala' or
			@idTipoSolicitud = 'Garantia'  or
			@idTipoSolicitud = 'Desinstala' or
			@idTipoSolicitud = 'RentaGPS'
		)
		BEGIN
			--PASO: Cobranza
			IF (@idFaseActual = 'COBRANZA' AND @idPasoActual = 'Cobranza')  
			BEGIN  
				SET @procesaAvance = 1  
			END  
			--Paso: Prefacturagenerada  
			IF (@idFaseActual = 'COBRANZA' AND @idPasoActual = 'PrefacturaGenerada')  
			BEGIN  
				SET @procesaAvance = 1  
			END  
			--Paso: FacturaEnviadaCliente
			IF (@idFaseActual = 'COBRANZA' AND @idPasoActual = 'FacturaEnviadaCliente')  
			BEGIN  
				SET @procesaAvance = 1  
			END  
			--Paso: FacturaAbonada
			IF (@idFaseActual = 'COBRANZA' AND @idPasoActual = 'FacturaAbonada')  
			BEGIN  
				SET @procesaAvance = 1  
			END  	
			--Paso: CorteMensual
			IF (@idPasoActual = 'CorteMensual')
			BEGIN
				SET @procesaAvance = 1  
			END
		END
	END
END

  /*******************************************************************************************************************  
 TIPO DE SOLICITUD:      COMPRA  SIM
 CLASE:         Automovil
 *******************************************************************************************************************/  
  IF (@idFaseActual = 'Solicitud' and @idPasoActual = 'Requerimiento' and @idTipoSolicitud = 'CompraSIM' and @idClase = 'Automovil')
	  BEGIN
		SET @procesaAvance = 1;
	  END
  IF (@idFaseActual = 'Proceso' and @idPasoActual = 'EnProceso' and @idTipoSolicitud = 'CompraSIM' and @idClase = 'Automovil')
	  BEGIN
		SET @procesaAvance = 1;
	  END

  /*******************************************************************************************************************  
 TIPO DE SOLICITUD:      COMPRA  GPS
 CLASE:         Automovil
 *******************************************************************************************************************/  
  IF (@idFaseActual = 'Solicitud' and @idPasoActual = 'Requerimiento' and @idTipoSolicitud = 'CompraGPS' and @idClase = 'Automovil')
	  BEGIN
		SET @procesaAvance = 1;
	  END
  IF (@idFaseActual = 'Proceso' and @idPasoActual = 'EnProceso' and @idTipoSolicitud = 'CompraGPS' and @idClase = 'Automovil')
	  BEGIN
		SET @procesaAvance = 1;
	  END


   /*******************************************************************************************************************  
 TIPO DE SOLICITUD:      COMPRA  Accesorios
 CLASE:         Automovil
 *******************************************************************************************************************/  
  IF (@idFaseActual = 'Solicitud' and @idPasoActual = 'Requerimiento' and @idTipoSolicitud = 'CompraAcce' and @idClase = 'Automovil')
	  BEGIN
		SET @procesaAvance = 1;
	  END
  IF (@idFaseActual = 'Proceso' and @idPasoActual = 'EnProceso' and @idTipoSolicitud = 'CompraAcce' and @idClase = 'Automovil')
	  BEGIN
		SET @procesaAvance = 1;
	  END

/*******************************************************************************************************************  
 CLASE:					 COMPRA  
*******************************************************************************************************************/  
 IF @idClase='Compra'
 BEGIN
	/************************************************************************************************************************** 
	************************************************FASE SOLICITUD*************************************************************
	**************************************************************************************************************************/  
	IF (@idFaseActual='Solicitud')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Compra
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Compra' 
		)
		BEGIN
			--Paso: Requerimiento
			IF (@idPasoActual='Requerimiento')
			BEGIN
				BEGIN  
					--OBTENEMOS EL TOTAL DE PARTIDAS  
					select @totalPartidas = count(1)  
					from solicitud.SolicitudCotizacion [cot]  
					inner join solicitud.SolicitudCotizacionPartida [cotpar] on   
					[cot].idSolicitud = [cotpar].idSolicitud   
					and [cot].idTipoSolicitud = [cotpar].idTipoSolicitud   
					and [cot].idClase = [cotpar].idClase   
					and [cot].rfcEmpresa = [cotpar].rfcEmpresa   
					and [cot].idCliente = [cotpar].idCliente   
					and [cot].numeroContrato = [cotpar].numeroContrato   
					and [cot].idProveedorEntidad = [cotpar].idProveedorEntidad   
					and [cot].rfcProveedor = [cotpar].rfcProveedor   
					where  
					[cot].idSolicitud = @idSolicitud   
					and [cot].idSolicitud = @idSolicitud   
					and [cot].idTipoSolicitud = @idTipoSolicitud  
					and [cot].idClase = @idClase  
					and [cot].rfcEmpresa = @rfcEmpresa  
					and [cot].idCliente = @idCliente  
					and [cot].numeroContrato = @numeroContrato  
					--OBTENEMOS EL TOTAL DE PARTIDAS EN ESPERA  
					select @totalPartidaEnEspera = count(1)  
					from solicitud.SolicitudCotizacion [cot]  
					inner join solicitud.SolicitudCotizacionPartida [cotpar] on   
					[cot].idSolicitud = [cotpar].idSolicitud   
					and [cot].idTipoSolicitud = [cotpar].idTipoSolicitud   
					and [cot].idClase = [cotpar].idClase   
					and [cot].rfcEmpresa = [cotpar].rfcEmpresa   
					and [cot].idCliente = [cotpar].idCliente   
					and [cot].numeroContrato = [cotpar].numeroContrato   
					and [cot].idProveedorEntidad = [cotpar].idProveedorEntidad   
					and [cot].rfcProveedor = [cotpar].rfcProveedor   
					where  
					[cot].idSolicitud = @idSolicitud   
					and [cot].idSolicitud = @idSolicitud   
					and [cot].idTipoSolicitud = @idTipoSolicitud  
					and [cot].idClase = @idClase  
					and [cot].rfcEmpresa = @rfcEmpresa  
					and [cot].idCliente = @idCliente  
					and [cot].numeroContrato = @numeroContrato  
					and [cotpar].idEstatusCotizacionPartida = 'ENESPERA'      
					if (@totalPartidas = @totalPartidaEnEspera)  
					BEGIN   
						SET @procesaAvance = 1  
					END  
					ELSE  
					BEGIN  
						set @err = 'La solicitud tiene cotizaciones con estatus diferente a APROBACION.'  
						return  
					END  
				END  
			END
			--Paso: 
			IF (@idPasoActual = 'AprobacionEstudioMercado')  
			BEGIN  
				--validamos las tablas de bpro para verificar que existe  
				set @procesaAvance=1  
			END  
			--Paso: EstudioMercado
			IF (@idPasoActual = 'EstudioMercado')  
			BEGIN  
				--validamos las tablas de bpro para verificar que existe  
				set @procesaAvance=1  
			END  
		END
	END
	/************************************************************************************************************************** 
	************************************************FASE APROBACION*************************************************************
	**************************************************************************************************************************/  
	IF (@idFaseActual='Aprobacion')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Compra
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Compra' 
		)
		BEGIN
			--Paso: Aprobacion
			IF (@idPasoActual = 'Aprobacion')  
			BEGIN  
				--validamos las tablas de bpro para verificar que existe  
				set @procesaAvance=1  
				SELECT 1 cambiaPaso
			END  
		END
	END
	/************************************************************************************************************************** 
	************************************************FASE PROCESO*************************************************************
	**************************************************************************************************************************/  
	IF (@idFaseActual='Proceso')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Compra
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Compra' 
		)
		BEGIN
			--Paso: Surtimiento
			IF (@idPasoActual = 'Surtimiento')  
			BEGIN  
				--validamos las tablas de bpro para verificar que existe  
				set @procesaAvance=1  
			END  
		END
	END
	/************************************************************************************************************************** 
	************************************************FASE ENTREGA*************************************************************
	**************************************************************************************************************************/  
	IF (@idFaseActual='Entrega')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Compra
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Compra' 
		)
		BEGIN
			--Paso: Surtimiento
			IF (@idPasoActual = 'Entrega')  
			BEGIN  
				--validamos las tablas de bpro para verificar que existe  
				set @procesaAvance=1  
			END  
		END
	END
	/************************************************************************************************************************** 
	************************************************FASE COBRANZA*************************************************************
	**************************************************************************************************************************/  
	IF (@idFaseActual='Cobranza')
	BEGIN
		/*******************************************************************************************************************  
		****TIPOS DE SOLICITUD: Compra
		*******************************************************************************************************************/  	
		IF (
			@idTipoSolicitud = 'Compra' 
		)
		BEGIN
			--Paso: Cobranza
			IF (@idPasoActual = 'Pago')  
			BEGIN  
				--validamos las tablas de bpro para verificar que existe  
				set @procesaAvance=1  
			END  
		END
	END
 END
  
/*---------------------------------------FIN DE VALIDACION POR TIPO DE CLASE Y ORDEN-------------------------------------------------*/  

 /*************************************** AVANZA ORDEN ****************************************************/  
 IF (@procesaAvance = 1)  
 BEGIN  
  /*Matamos la tarea de la solicitud antes de crear la siguiente tarea*/  
  EXEC Evento.evento.Sel_TareaXSolicitud @idUsuario = @idUsuario, @idSolicitud = @idSolicitud  
 --ACTUALIZAMOS EL ESTATUS ACTUAL      
   IF (@tipoPasoActual='PASO')  
   BEGIN  
    UPDATE est  
    SET  
     est.fechaSalida = GETDATE(),  
     idEstatus = 1,  
     idUsuarioSalida = @idUsuario  
    FROM fase.SolicitudEstatusPaso est   
    where  
     est.idSolicitud = @idSolicitud  
     and est.idTipoSolicitud = @idTipoSolicitud  
     and est.idClase = @idClase  
     and est.rfcEmpresa = @rfcEmpresa  
     and est.idCliente = @idCliente  
     and est.numeroContrato = @numeroContrato  
     and est.idPaso = @idPasoActual  
     and est.idFase = @idFaseActual  
   END  
   IF (@tipoPasoActual='CONTRATO')  
   BEGIN  
    UPDATE est  
    SET  
     est.fechaSalida = GETDATE(),  
     idEstatus = 1,  
     idUsuarioSalida = @idUsuario  
    FROM faseContrato.SolicitudEstatusPaso est   
    where  
     est.idSolicitud = @idSolicitud  
     and est.idTipoSolicitud = @idTipoSolicitud  
     and est.idClase = @idClase  
     and est.rfcEmpresa = @rfcEmpresa  
     and est.idCliente = @idCliente  
     and est.numeroContrato = @numeroContrato  
     and est.idPaso = @idPasoActual  
     and est.idFase = @idFaseActual  
   END  
   --MOVEMOS AL SIGUIENTE PASO  
   IF (@tipoPasoSiguiente='PASO')  
   BEGIN  
    INSERT INTO fase.SolicitudEstatusPaso(  
     idSolicitud  
     ,idTipoSolicitud  
     ,idClase  
     ,rfcEmpresa  
     ,idCliente  
     ,numeroContrato  
     ,idPaso  
     ,idFase  
     ,fechaIngreso  
     ,idEstatus  
     ,idUsuarioIngreso  
    )  
     values  
     (  
     @idSolicitud,  
     @idTipoSolicitud,  
     @idClase,  
     @rfcEmpresa,  
     @idCliente,  
     @numeroContrato,  
     @idPasoSiguiente,  
     @idFaseSiguiente,  
     GETDATE(),  
     1,  
     @idUsuario  
    )  
  
    UPDATE solicitud.Solicitud  
    SET idPaso = @idPasoSiguiente  
     , idFase = @idFaseSiguiente  
    WHERE idSolicitud = @idSolicitud  
    AND idTipoSolicitud = @idTipoSolicitud  
    AND idClase = @idClase  
    AND rfcEmpresa = @rfcEmpresa  
    AND idCliente = @idCliente  
    AND numeroContrato = @numeroContrato  
  
   END  
   IF (@tipoPasoSiguiente='CONTRATO')  
   BEGIN  
      
    INSERT INTO faseContrato.SolicitudEstatusPaso(  
     idSolicitud  
     ,idTipoSolicitud  
     ,idClase  
     ,rfcEmpresa  
     ,idCliente  
     ,numeroContrato  
     ,idPaso  
     ,idFase  
     ,fechaIngreso  
     ,idEstatus  
     ,idUsuarioIngreso  
    )  
     values  
     (  
     @idSolicitud,  
     @idTipoSolicitud,  
     @idClase,  
     @rfcEmpresa,  
     @idCliente,  
     @numeroContrato,  
     @idPasoSiguiente,  
     @idFaseSiguiente,  
     GETDATE(),  
     1,  
     @idUsuario  
    )  
  
    UPDATE solicitud.Solicitud  
    SET idPaso = @idPasoSiguiente  
     , idFase = @idFaseSiguiente  
    WHERE idSolicitud = @idSolicitud  
    AND idTipoSolicitud = @idTipoSolicitud  
    AND idClase = @idClase  
    AND rfcEmpresa = @rfcEmpresa  
    AND idCliente = @idCliente  
    AND numeroContrato = @numeroContrato  
  
   END  
 END  
 
 END
go

