-- =============================================
-- Author:		Adolfo Martinez
-- Create date: 14/05/2020
-- Description:	Actualiza los saldos en las cuentas de CXC
-- [cxp].[SEL_ACTUALIZA_SALDOS_CXP_SP]
-- [Common].[configuracion].[PersonasBPRO]
-- [Common].[configuracion].[FacturacionBPRO]
-- ============== Versionamiento ================  

CREATE PROCEDURE [cxp].[SEL_ACTUALIZA_SALDOS_CXP_SP]
AS
BEGIN

		DECLARE @tbl_cxp AS TABLE(
			uuid VARCHAR(100),
			docto VARCHAR(100),
			importe DECIMAL(18,5),
			saldo DECIMAL(18,5)
		)
		DECLARE @sv VARCHAR(100),
				@db VARCHAR(100),
				@query VARCHAR(max) = '',
				@count INT = 0,
				@noServ int
				select @noServ = COUNT(1) FROM [Common].[configuracion].[FacturacionBPRO] WHERE activo=1
		DECLARE cxp CURSOR FOR SELECT [instancia], [nombreBD] FROM [Common].[configuracion].[FacturacionBPRO] WHERE activo=1
		OPEN cxp
		FETCH NEXT FROM cxp INTO @sv, @db
		WHILE @@fetch_status = 0
		BEGIN

			set @query = @query + '
			SELECT * FROM (
						SELECT 
							 F.uuid,
							 CCP_IDDOCTO,
							 ''IMPORTE'' = CASE CARTERA.PAR_IDMODULO
												 WHEN ''CXP''
												 THEN ccp_abono-ccp_cargo
												 ELSE ccp_cargo-ccp_abono
												END, 
							 ''SALDO'' = CASE CARTERA.PAR_IDMODULO
														WHEN ''CXP''
														THEN ccp_abono-ccp_cargo + (Select isnull(sum(CCP_ABONO-CCP_CARGO),0)                   
								 FROM [192.168.20.29].[GAAutoexpressConcentra].[dbo].Con_Car012020 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO
								 AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA
								 AND MOVIMIENTO.CCP_DOCORI<>''S'')
														ELSE ccp_CARGO-ccp_ABONO+(Select isnull(sum(CCP_CARGO-CCP_ABONO),0)
								 FROM [192.168.20.29].[GAAutoexpressConcentra].[dbo].Con_Car012020 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO
											AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA
											AND MOVIMIENTO.CCP_DOCORI<>''S'')
											END
						FROM [192.168.20.29].[GAAutoexpressConcentra].[dbo].[Con_Car012020] AS DOCUMENTO 
						--'+@sv+'.'+@db+'.[dbo].VIS_CONCAR01 AS DOCUMENTO 
						LEFT OUTER JOIN '+@sv+'.'+@db+'.[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA=''CARTERA'' and CARTERA.PAR_IDENPARA IN (''AE57'', ''TUM63'')
						--INNER JOIN [192.168.20.29].[GA_Corporativa].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA
						LEFT OUTER JOIN '+@sv+'.'+@db+'.[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = ''TIMO''
						LEFT OUTER JOIN '+@sv+'.'+@db+'.[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL 
						--INNER JOIN '+@sv+'.'+@db+'.[dbo].ADE_ORDSERENC  ON CCP_IDDOCTO = OTE_FACTURACOMPRA AND CCP_IDPERSONA = OTE_IDPROVEEDOR
						INNER JOIN [Solicitud].[cxp].[Factura] F ON ISNULL(CONVERT(VARCHAR(250), F.SERIE),'''') + ISNULL(CONVERT(VARCHAR(250), F.FOLIO),'''') = REPLACE(CCP_IDDOCTO,'','','''') COLLATE Modern_Spanish_CI_AS 
						INNER JOIN [proveedor].[proveedor].[proveedorEmpresa] PE ON PE.rfcProveedor = F.rfcEmisor AND PE.rfcEmpresa = F.rfcReceptor AND CCP_IDPERSONA = PE.idBPRO AND idPersonaBPRO=1
						--INNER JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SC ON SC.numeroCotizacion = OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS 
						WHERE CCP_DOCORI = ''S''  and CCP_TIPODOCTO = ''FAC'' AND CARTERA.PAR_IDMODULO IS NOT NULL AND F.SALDO > 0) AS CXP'
				SET @count = @count + 1
				IF (@count < @noServ )
				BEGIN
					SET @query = @query + 'union all'
				END
			FETCH NEXT FROM cxp INTO @sv, @db
		END
		CLOSE cxp
		DEALLOCATE cxp

		print @query
		INSERT @tbl_cxp
		EXEC(@query)

		UPDATE F
		SET SALDO=cxp.SALDO
		from @tbl_cxp cxp
		JOIN [Solicitud].[cxp].[Factura] F ON F.uuid = cxp.uuid

		select * from  @tbl_cxp cxp
		JOIN [Solicitud].[cxp].[Factura] F ON F.uuid = cxp.uuid

		;WITH detalleInsert (uuid,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO)
			AS  
			(  
				SELECT * FROM (
							SELECT 
								 F.uuid,
								 CCP_IDDOCTO,
							     CCP_FECHADOCTO,
							     CCP_FECHVEN,
							     CCP_FECHPROMPAG,
								 'IMPORTE' = CASE CARTERA.PAR_IDMODULO
													 WHEN 'CXP'
													 THEN ccp_abono-ccp_cargo
													 ELSE ccp_cargo-ccp_abono
													END, 
								 'SALDO' = CASE CARTERA.PAR_IDMODULO
															WHEN 'CXP'
															THEN ccp_abono-ccp_cargo + (Select isnull(sum(CCP_ABONO-CCP_CARGO),0)                   
									 FROM [192.168.20.29].[GAAutoexpressConcentra].[dbo].Con_Car012020 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO
									 AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA
									 AND MOVIMIENTO.CCP_DOCORI<>'S')
															ELSE ccp_CARGO-ccp_ABONO+(Select isnull(sum(CCP_CARGO-CCP_ABONO),0)
									 FROM [192.168.20.29].[GAAutoexpressConcentra].[dbo].Con_Car012020 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO
												AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA
												AND MOVIMIENTO.CCP_DOCORI<>'S')
												END
							FROM [192.168.20.29].[GAAutoexpressConcentra].[dbo].[Con_Car012020] AS DOCUMENTO 
							--'+@sv+'.'+@db+'.[dbo].VIS_CONCAR01 AS DOCUMENTO 
							LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA='CARTERA' and CARTERA.PAR_IDENPARA IN ('AE57', 'TUM63')
							--INNER JOIN [192.168.20.29].[GA_Corporativa].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA
							LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = 'TIMO'
							LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL 
							--INNER JOIN '+@sv+'.'+@db+'.[dbo].ADE_ORDSERENC  ON CCP_IDDOCTO = OTE_FACTURACOMPRA AND CCP_IDPERSONA = OTE_IDPROVEEDOR
							INNER JOIN [Solicitud].[cxp].[Factura] F ON ISNULL(CONVERT(VARCHAR(250), F.SERIE),'') + ISNULL(CONVERT(VARCHAR(250), F.FOLIO),'') = REPLACE(CCP_IDDOCTO,' ','') COLLATE Modern_Spanish_CI_AS 
							INNER JOIN [proveedor].[proveedor].[proveedorEmpresa] PE ON PE.rfcProveedor = F.rfcEmisor AND PE.rfcEmpresa = F.rfcReceptor AND CCP_IDPERSONA = PE.idBPRO AND idPersonaBPRO=1
							--INNER JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SC ON SC.numeroCotizacion = OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS 
							WHERE CCP_DOCORI = 'S'  and CCP_TIPODOCTO = 'FAC' AND CARTERA.PAR_IDMODULO IS NOT NULL) AS CXP
			)
			MERGE cxp.FacturaBPRO AS TARGET
			USING (SELECT uuid,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO FROM detalleInsert) AS SOURCE (uuid,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO)
			ON (TARGET.uuid = SOURCE.uuid)
			WHEN MATCHED THEN
				UPDATE SET 
						CCP_IDdocto = SOURCE.CCP_IDDOCTO,
						CCP_FECHADOCTO = SOURCE.CCP_FECHADOCTO,
						CCP_FECHVEN = SOURCE.CCP_FECHVEN,
						CCP_FECHPROMPAG = SOURCE.CCP_FECHPROMPAG,
						importe = SOURCE.IMPORTE,
						saldo = SOURCE.SALDO
			WHEN NOT MATCHED THEN
				INSERT (uuid,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO,idUsuario,activo)
				VALUES (uuid,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO,3132,1);

		--UPDATE F
		--SET SALDO=cxp.SALDO
		--FROM [Solicitud].[cxp].[SolicitudCotizacionFactura] SCF
		--JOIN @tbl_cxp cxp ON cxp.idCotizacion = SCF.idCotizacion
		--JOIN [Solicitud].[cxp].[Factura] F ON F.uuid = SCF.uuid

		--SELECT cxp.*, F.serie, F.folio, F.total, F.saldo 
		--FROM [Solicitud].[cxp].[SolicitudCotizacionFactura] SCF
		--JOIN @tbl_cxp cxp ON cxp.idCotizacion = SCF.idCotizacion
		--JOIN [Solicitud].[cxp].[Factura] F ON F.uuid = SCF.uuid

		--UPDATE F
		--SET SALDO=cxp.SALDO
		--FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaPorConsolidar] SCF
		--JOIN @tbl_cxp cxp ON cxp.idCotizacion = SCF.idCotizacion
		--JOIN [Solicitud].[cxp].[FacturaPorConsolidar] F ON F.uuid = SCF.uuid

		--SELECT cxp.*, F.serie, F.folio, F.total, F.saldo
		--FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaPorConsolidar] SCF
		--JOIN @tbl_cxp cxp ON cxp.idCotizacion = SCF.idCotizacion
		--JOIN [Solicitud].[cxp].[FacturaPorConsolidar] F ON F.uuid = SCF.uuid

END

go

