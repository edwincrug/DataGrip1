
CREATE VIEW [solicitud].[SEL_SOLICITUD_MULTIPLE_VW]
AS

SELECT S.idSolicitud
	, S.idTipoSolicitud
	, S.idClase
	, S.rfcEmpresa
	, S.idCliente
	, S.numeroContrato
	, S.idEstatusSolicitud
	, S.numero
	, COUNT(SO.idObjeto) multiple
FROM solicitud.Solicitud AS S
INNER JOIN solicitud.SolicitudObjeto AS SO
	ON S.idSolicitud = SO.idSolicitud
GROUP BY S.idSolicitud
	, S.idTipoSolicitud
	, S.idClase
	, S.rfcEmpresa
	, S.idCliente
	, S.numeroContrato
	, S.idEstatusSolicitud
	, S.numero

go

