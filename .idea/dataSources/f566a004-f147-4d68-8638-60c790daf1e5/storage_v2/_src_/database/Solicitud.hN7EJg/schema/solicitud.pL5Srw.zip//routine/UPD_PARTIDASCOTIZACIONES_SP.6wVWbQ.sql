
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <24/08/2020>
-- Description:	<Procedimiento para actualizar costos >

/*

	exec [solicitud].UPD_PARTIDASCOTIZACIONES_SP 1082,'Instala','Automovil','AAN910409135',218,'0001',787282,118,'CostoUnitario',555,6282,NULL
*/
-- =============================================
CREATE PROCEDURE [solicitud].[UPD_PARTIDASCOTIZACIONES_SP]
 @idSolicitud		INT,
 @idTipoSolicitud	VARCHAR(10),
 @idClase			VARCHAR(10),  
 @rfcEmpresa		VARCHAR(13),
 @idCliente			INT,  
 @numeroContrato	VARCHAR(50),  
 @idPartida			INT,
 @idTipoObjeto		INT,
 @campo				VARCHAR(50),
 @valor				DECIMAL(18,2),
 @idUsuario			INT,  
 @err				VARCHAR(500) OUTPUT  
 AS
BEGIN
	--delete from reporte.dbo.test
	--insert into reporte.dbo.test values('@campo',@campo,null)

	 

	IF @campo='Costo'
		BEGIN
			UPDATE	solicitud.solicitud.SolicitudCotizacionPartida 
			SET		costo			=@valor
			--SELECT * FROM solicitud.solicitud.SolicitudCotizacionPartida 
			WHERE	idSolicitud		=@idSolicitud
			AND		idTipoSolicitud	=@idTipoSolicitud
			AND     idClase			=@idClase
			AND     rfcEmpresa		=@rfcEmpresa
			AND     idCliente		=@idCliente
			AND     numeroContrato	=@numeroContrato
			AND     idPartida		=@idPartida
			AND     idTipoObjeto	=@idTipoObjeto
		END

	IF @campo='Venta'
		BEGIN
			UPDATE  Solicitud.solicitud.SolicitudCotizacionPartida
			SET		venta			=@valor
			WHERE	idSolicitud		=@idSolicitud
			AND		idTipoSolicitud	=@idTipoSolicitud
			AND     idClase			=@idClase
			AND     rfcEmpresa		=@rfcEmpresa
			AND     idCliente		=@idCliente
			AND     numeroContrato	=@numeroContrato
			AND     idPartida		=@idPartida
			AND     idTipoObjeto	=@idTipoObjeto
		END

END



--USE [Solicitud]
go

