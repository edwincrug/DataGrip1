
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <10/12/2020>
-- Description:	<Funcion para obtener datos de los autorizadores>
/*
SELECT [solicitud].SEL_OBTENERAUTORIZADORES_FN(1505,'Automovil','Imagen','ASE0508051B6',185,'43',746045,117,'nAutDesc','AUT_HECHAS_NUM',11) usuariosQueAutorizaron
SELECT [solicitud].SEL_OBTENERAUTORIZADORES_FN(1505,'Automovil','Imagen','ASE0508051B6',185,'43',746045,117,'nAutDesc','AUT_HECHAS_AUTORIZADORES',11) usuariosPorAutorizar
SELECT [solicitud].SEL_OBTENERAUTORIZADORES_FN(1505,'Automovil','Imagen','ASE0508051B6',185,'43',746045,117,'nAutDesc','AUT_PENDIENTES_AUTORIZADORES',11) usuariosPorAutorizar
*/
-- =============================================
CREATE FUNCTION [solicitud].[SEL_OBTENERAUTORIZADORES_FN]
(
	@idSolicitud		INT,
	@idClase			VARCHAR(10),
	@idTipoSolicitud	VARCHAR(10),
	@rfcEmpresa			VARCHAR(13),	
	@idCliente			INT,
	@numeroContrato		VARCHAR(50),
	@idPartida			INT,
	@idTipoObjeto		INT,
	@idTipoAutorizacion VARCHAR(15),
	@idTipoConsulta		VARCHAR(50),
	@idAplicacion		INT,
	@autorizPendie_No	INT
)
RETURNS VARCHAR(2000)
AS
BEGIN
	DECLARE @salida VARCHAR(2000)=''

	IF @idTipoConsulta='AUT_TOTALES_NUM'
		BEGIN
			IF @idTipoAutorizacion='nAutDesc'
				BEGIN
					SET @salida =(SELECT noAutorizadores 
					FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
					WHERE	aut.idClase				= @idClase
					AND		aut.idTipoSolicitud		= @idTipoSolicitud
					AND		aut.rfcEmpresa			= @rfcEmpresa
					AND		aut.idCliente			= @idCliente
					AND		aut.numeroContrato		= @numeroContrato
					AND		aut.idPartida			= @idPartida
					AND     aut.idTipoObjeto		= @idTipoObjeto
					AND     aut.idTipoAutorizacion	= @idTipoAutorizacion)
				END
			IF @idTipoAutorizacion='nAutRol'
				BEGIN
					SET @salida =(SELECT	noAutorizadores 
					FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
					WHERE	aut.idClase				= @idClase
					AND		aut.idTipoSolicitud		= @idTipoSolicitud
					AND		aut.rfcEmpresa			= @rfcEmpresa
					AND		aut.idCliente			= @idCliente
					AND		aut.numeroContrato		= @numeroContrato
					AND		aut.idPartida			= @idPartida
					AND     aut.idTipoObjeto		= @idTipoObjeto
					AND     aut.idTipoAutorizacion	= @idTipoAutorizacion)
				END
			IF @idTipoAutorizacion='nAutUserEspCO'
				BEGIN
					SET @salida =(SELECT	COUNT(*)
					FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
					WHERE	aut.idClase				= @idClase
					AND		aut.idTipoSolicitud		= @idTipoSolicitud
					AND		aut.rfcEmpresa			= @rfcEmpresa
					AND		aut.idCliente			= @idCliente
					AND		aut.numeroContrato		= @numeroContrato
					AND		aut.idPartida			= @idPartida
					AND     aut.idTipoObjeto		= @idTipoObjeto
					AND     aut.idTipoAutorizacion	= @idTipoAutorizacion)
				END
			IF @idTipoAutorizacion='nAutUserEspSO'
				BEGIN
					SET @salida =(SELECT	COUNT(*)
					FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
					WHERE	aut.idClase				= @idClase
					AND		aut.idTipoSolicitud		= @idTipoSolicitud
					AND		aut.rfcEmpresa			= @rfcEmpresa
					AND		aut.idCliente			= @idCliente
					AND		aut.numeroContrato		= @numeroContrato
					AND		aut.idPartida			= @idPartida
					AND     aut.idTipoObjeto		= @idTipoObjeto
					AND     aut.idTipoAutorizacion	= @idTipoAutorizacion)
				END
		END
	IF @idTipoConsulta='AUT_TOTALES_AUTORIZADORES'
		BEGIN
			IF @idTipoAutorizacion='nAutDesc'
				BEGIN
					SET @salida ='Usuarios con permiso de aprobación'
				END
			IF @idTipoAutorizacion='nAutRol'
				BEGIN
					SET @salida=(	SELECT  ISNULL((SELECT TOP 1 'Usuarios con el rol: '+nombre FROM seguridad.Catalogo.Rol WHERE Id= aut.idRolAutorizacion AND AplicacionesId=@idAplicacion),'')
									FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
									WHERE	aut.idClase				= @idClase
									AND		aut.idTipoSolicitud		= @idTipoSolicitud
									AND		aut.rfcEmpresa			= @rfcEmpresa
									AND		aut.idCliente			= @idCliente
									AND		aut.numeroContrato		= @numeroContrato
									AND		aut.idPartida			= @idPartida
									AND     aut.idTipoObjeto		= @idTipoObjeto
									AND     aut.idTipoAutorizacion	= @idTipoAutorizacion)
				END
			IF @idTipoAutorizacion='nAutUserEspCO'
				BEGIN
					SET @salida =ISNULL(STUFF	(	(	SELECT ',' + [Common].[common].SEL_NOMBRE_USUARIO_FN(idUsuarioAutorizacion) 
													FROM	[Cliente].[contrato].[PartidaAutorizacion] 
													WHERE	idTipoSolicitud	=@idTipoSolicitud 
													AND		idClase			=@idClase
													AND		rfcEmpresa		=@rfcEmpresa 
													AND		numeroContrato	=@numeroContrato 
													AND		idCliente		=@idCliente
													AND		idTipoObjeto	=@idTipoObjeto 
													AND		idPartida		=@idPartida
													ORDER BY ordenAutorizacion ASC  FOR XML PATH('')
												),1,1,''
											),'--')
				END
			IF @idTipoAutorizacion='nAutUserEspSO'
				BEGIN
					SET @salida =ISNULL(STUFF	(	(	SELECT ',' + [Common].[common].SEL_NOMBRE_USUARIO_FN(idUsuarioAutorizacion) 
													FROM	[Cliente].[contrato].[PartidaAutorizacion] 
													WHERE	idTipoSolicitud	=@idTipoSolicitud 
													AND		idClase			=@idClase
													AND		rfcEmpresa		=@rfcEmpresa 
													AND		numeroContrato	=@numeroContrato 
													AND		idCliente		=@idCliente
													AND		idTipoObjeto	=@idTipoObjeto 
													AND		idPartida		=@idPartida
													FOR XML PATH('')
												),1,1,''
											),'')
				END

			
			
		END


	IF @idTipoConsulta='AUT_PENDIENTES_AUTORIZADORES'
		BEGIN
			IF @idTipoAutorizacion='nAutDesc'
				BEGIN
					SET @salida=CAST(@autorizPendie_No AS VARCHAR)+' Usuarios con permiso de aprobación'
				END
			IF @idTipoAutorizacion='nAutRol'
				BEGIN
					SET @salida=(	SELECT  ISNULL((SELECT TOP 1 CAST(@autorizPendie_No AS VARCHAR)+' Usuarios con el rol '+nombre FROM seguridad.Catalogo.Rol WHERE Id= aut.idRolAutorizacion AND AplicacionesId=@idAplicacion),'')
									FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
									WHERE	aut.idClase				= @idClase
									AND		aut.idTipoSolicitud		= @idTipoSolicitud
									AND		aut.rfcEmpresa			= @rfcEmpresa
									AND		aut.idCliente			= @idCliente
									AND		aut.numeroContrato		= @numeroContrato
									AND		aut.idPartida			= @idPartida
									AND     aut.idTipoObjeto		= @idTipoObjeto
									AND     aut.idTipoAutorizacion	= @idTipoAutorizacion)
				END
			IF @idTipoAutorizacion='nAutUserEspCO'
				BEGIN
					SET @salida =ISNULL(STUFF	(	(	SELECT ',' + [Common].[common].SEL_NOMBRE_USUARIO_FN(cnf.idUsuarioAutorizacion) 
														FROM	[Cliente].[contrato].[PartidaAutorizacion] cnf		
														LEFT	JOIN SOLICITUD.SolicitudCotizacionAprobador aut
														ON		aut.idClase				=cnf.idClase
														AND		aut.idTipoSolicitud		=cnf.idTiposolicitud 
														AND		aut.rfcEmpresa			=cnf.rfcEmpresa
														AND		aut.idCliente			=cnf.idCliente
														AND		aut.numeroContrato		=cnf.numeroContrato
														AND		aut.idPartida			=cnf.idPartida
														AND		aut.idTipoObjeto		=cnf.idTipoObjeto
														AND		aut.idUsuarioAprobador	=cnf.idUsuarioAutorizacion
														AND		aut.idSolicitud			=@idSolicitud
														WHERE	cnf.idTipoSolicitud		=@idTipoSolicitud
														AND		cnf.idClase				=@idClase
														AND		cnf.rfcEmpresa			=@rfcEmpresa
														AND		cnf.numeroContrato		=@numeroContrato
														AND		cnf.idCliente			=@idCliente
														AND		cnf.idTipoObjeto		=@idTipoObjeto
														AND		cnf.idPartida			=@idPartida
														AND		cnf.idTipoAutorizacion	=@idTipoAutorizacion
														AND     aut.idUsuarioAprobador		IS NULL 
														ORDER BY cnf.ordenAutorizacion ASC  FOR XML PATH('')
													),1,1,''
												),'')
				END
			IF @idTipoAutorizacion='nAutUserEspSO'
				BEGIN
					SET @salida =ISNULL(STUFF	(	(	SELECT ',' + [Common].[common].SEL_NOMBRE_USUARIO_FN(cnf.idUsuarioAutorizacion) 
														FROM	[Cliente].[contrato].[PartidaAutorizacion] cnf		
														LEFT	JOIN SOLICITUD.SolicitudCotizacionAprobador aut
														ON		aut.idClase				=cnf.idClase
														AND		aut.idTipoSolicitud		=cnf.idTiposolicitud 
														AND		aut.rfcEmpresa			=cnf.rfcEmpresa
														AND		aut.idCliente			=cnf.idCliente
														AND		aut.numeroContrato		=cnf.numeroContrato
														AND		aut.idPartida			=cnf.idPartida
														AND		aut.idTipoObjeto		=cnf.idTipoObjeto
														AND		aut.idUsuarioAprobador	=cnf.idUsuarioAutorizacion
														AND		aut.idSolicitud			=@idSolicitud
														WHERE	cnf.idTipoSolicitud		=@idTipoSolicitud
														AND		cnf.idClase				=@idClase
														AND		cnf.rfcEmpresa			=@rfcEmpresa
														AND		cnf.numeroContrato		=@numeroContrato
														AND		cnf.idCliente			=@idCliente
														AND		cnf.idTipoObjeto		=@idTipoObjeto
														AND		cnf.idPartida			=@idPartida
														AND		cnf.idTipoAutorizacion	=@idTipoAutorizacion
														AND     aut.idUsuarioAprobador		IS NULL 
														ORDER BY fechaAprobacion ASC  FOR XML PATH('')
													),1,1,''
												),'')
				END
		END
	RETURN @salida
END


go

