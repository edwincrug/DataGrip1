
-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 05/07/2019
-- Description: Obtiene las solicitudes a partir de un contrato para el chat
-- ============== Versionamiento ================
/*

	EXEC solicitud.SEL_SOLICITUDES_BY_CONTRATO_SP
	@contratos = '<contratos>
	<contrato>
		<idClase>Automovil</idClase>
		<idCliente>92</idCliente>
		<numeroContrato>0001</numeroContrato>
		<rfcEmpresa>ASE0508051B6</rfcEmpresa>
	</contrato>
	<contrato>
		<idClase>Automovil</idClase>
		<idCliente>93</idCliente>
		<numeroContrato>0001</numeroContrato>
		<rfcEmpresa>ASE0508051B6</rfcEmpresa>
	</contrato>
	<contrato>
		<idClase>Automovil</idClase>
		<idCliente>95</idCliente>
		<numeroContrato>0002</numeroContrato>
		<rfcEmpresa>ASE0508051B6</rfcEmpresa>
	</contrato>
</contratos>'

*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_SOLICITUDES_BY_CONTRATO_SP]
	@contratos XML,
	@idUsuario INT = NULL,
	@err VARCHAR(500) = NULL OUTPUT
AS
BEGIN
	BEGIN TRY
		;WITH contratos (idClase, idCliente, numeroContrato, rfcEmpresa)
		AS (  
			SELECT I.N.value('(idClase)[1]', 'VARCHAR(MAX)')
				,I.N.value('(idCliente)[1]', 'int')
				,I.N.value('(numeroContrato)[1]', 'VARCHAR(MAX)')
				,I.N.value('(rfcEmpresa)[1]', 'VARCHAR(MAX)')
			FROM @contratos.nodes('/contratos/contrato') I(N)
		), solicitudXContrato
		AS (
			SELECT S.idSolicitud
				, S.idTipoSolicitud
				, S.idClase
				, S.rfcEmpresa
				, S.idCliente
				, S.numeroContrato
				, S.numero AS numeroOrden
				, CONVERT(VARCHAR(30), S.idSolicitud)+''+CONVERT(VARCHAR(30), S.idTipoSolicitud)+''+CONVERT(VARCHAR(30), S.idClase)+''+CONVERT(VARCHAR(30), S.rfcEmpresa)+''+CONVERT(VARCHAR(30), S.idCliente)+''+CONVERT(VARCHAR(30), S.numeroContrato) AS tokenSolicitud
				, FileServer.documento.urlFileServer(CB.idFileAvatar) AS urlAvatar
				, COALESCE(MAX(SC.fechaUltimaEscritura), GETDATE()) AS fechaUltimaEscritura
				, COALESCE(MAX(SC.UsersId), 0) AS idUsuario
				, SC.idSolicitudChat
			FROM solicitud.Solicitud S
			INNER JOIN contratos C
			ON S.idClase = C.idClase
			AND S.idCliente = C.idCliente
			AND S.numeroContrato = C.numeroContrato
			AND S.rfcEmpresa = C.rfcEmpresa
			INNER JOIN Cliente.cliente.Contrato CB
			ON C.idClase = CB.idClase
			AND C.idCliente = CB.idCliente
			AND C.numeroContrato = CB.numeroContrato
			AND C.rfcEmpresa = CB.rfcEmpresa
			LEFT JOIN chat.SolicitudChat SC
			ON S.idSolicitud = SC.idSolicitud
			AND S.idTipoSolicitud = SC.idTipoSolicitud
			AND S.idClase = SC.idClase
			AND S.rfcEmpresa = SC.rfcEmpresa
			AND S.idCliente = SC.idCliente
			AND S.numeroContrato = SC.numeroContrato
			WHERE S.idEstatusSolicitud = 'ACTIVA'
			GROUP BY S.idSolicitud
				, S.idTipoSolicitud
				, S.idClase
				, S.rfcEmpresa
				, S.idCliente
				, S.numeroContrato
				, S.numero
				, CB.idFileAvatar
				, SC.idSolicitudChat
		)
		SELECT SC.idSolicitud
			, SC.idTipoSolicitud
			, SC.idClase
			, SC.rfcEmpresa
			, SC.idCliente
			, SC.numeroContrato
			, SC.numeroOrden
			, SC.tokenSolicitud
			, SC.urlAvatar
			, SC.fechaUltimaEscritura
			, SC.idUsuario
			, COALESCE((U.PrimerNombre + ' ' + U.PrimerApellido + ' ' + U.SegundoApellido), '') AS nombreUsuario
			, solicitud.SEL_USUARIOSCHAT_FN(SC.idSolicitudChat) AS usuarios
		FROM solicitudXContrato SC INNER JOIN Seguridad.Catalogo.Users U
		ON SC.idUsuario = U.Id
		ORDER BY SC.fechaUltimaEscritura DESC
		, SC.idSolicitud DESC

	END TRY
	BEGIN CATCH
		SELECT @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
	END CATCH
END
go

