


CREATE FUNCTION [solicitud].[SEL_SPLIT_STRING_FN] ( @stringToSplit VARCHAR(MAX), @charIndex char)
RETURNS
@returnList TABLE ([Name] [nvarchar] (max))
AS
BEGIN

 DECLARE @name NVARCHAR(max)
 DECLARE @pos INT

 WHILE CHARINDEX(@charIndex, @stringToSplit) > 0
 BEGIN
  SELECT @pos  = CHARINDEX(@charIndex, @stringToSplit)  
  SELECT @name = SUBSTRING(@stringToSplit, 1, @pos-1)

  INSERT INTO @returnList 
  SELECT @name

  SELECT @stringToSplit = SUBSTRING(@stringToSplit, @pos+1, LEN(@stringToSplit)-@pos)
 END

 INSERT INTO @returnList
 SELECT @stringToSplit

 RETURN
END
go

