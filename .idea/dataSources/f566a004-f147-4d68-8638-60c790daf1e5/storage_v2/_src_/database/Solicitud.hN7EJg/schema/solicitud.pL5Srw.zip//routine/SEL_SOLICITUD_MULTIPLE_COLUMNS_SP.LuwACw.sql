
-- =============================================
-- Author: Adolfo Martinez
-- Create date: 27-05-2020
-- Description: Consulta  devuelve columnas solicitudes 
-- ============== Versionamiento ================
-- EXEC [solicitud].[SEL_SOLICITUD_MULTIPLE_COLUMNS_SP] 'Automovil',123,''
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_SOLICITUD_MULTIPLE_COLUMNS_SP]
	@idClase			VARCHAR(10),
	@idUsuario			INT,
	@err				VARCHAR(500)OUTPUT
AS


BEGIN

	DECLARE @columnas TABLE(caption VARCHAR(100),datafield VARCHAR(100),datatype VARCHAR(100),orden INT, bloque INT)

	DECLARE @camposPivot VARCHAR(MAX),
			@sq			 VARCHAR(MAX)

	insert into @columnas values('Orden','numeroOrden','String',1,1)
	insert into @columnas VALUES('Cotización','numeroCotizacion','String',2,1)
	insert into @columnas values('Datos del vehiculo','vehiculo','String',3,1)
	insert into @columnas values('Zona','zona','String',4,1)
	insert into @columnas values('No. Partidas','partidas','String',5,1)
	insert into @columnas values('Costo','Costo','Number',6,1)
	insert into @columnas values('Venta','Venta','Number',7,1)
	insert into @columnas values('Estatus','idEstatusCotizacion','String',8,1)

	SELECT * FROM @columnas ORDER BY bloque,orden ASC

END

--USE [Solicitud]
go

