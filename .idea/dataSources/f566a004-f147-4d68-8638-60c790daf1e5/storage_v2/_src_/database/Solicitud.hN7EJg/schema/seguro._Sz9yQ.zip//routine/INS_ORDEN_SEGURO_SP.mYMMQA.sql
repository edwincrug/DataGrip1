

-- =============================================
-- Author:		<Luis Martinez>
-- Create date: <08/04/2020>
-- Description:	<Inserta la pre solicitud recibida en correo de seguro>
/* 
	declare @err nvarchar(max)
	exec [seguro].[INS_ORDEN_SEGURO_SP] @idEmail = '<1968448809.2271.1588108234072@banorte.com>', @err = @err output
*/
-- =============================================
CREATE PROCEDURE [seguro].[INS_ORDEN_SEGURO_SP]
	-- Add the parameters for the stored procedure here
	--@vin   VARCHAR(50),  
	--@tipo   VARCHAR(50) = NULL,  
	--@fecha   DATETIME,  
	--@comentario  VARCHAR (2000),  
	@idEmail	VARCHAR(MAX) = '',
	@err   VARCHAR(500) OUTPUT  
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SET LANGUAGE spanish

	BEGIN TRY
		
		DECLARE @idObjeto				INT
				,@idTipoObjeto			INT
				,@rfcEmpresa			VARCHAR(13)
				,@idCliente				INT
				,@numeroContrato		VARCHAR(50)
				,@idCentroCosto			INT
				,@idCentroCostoFolio	VARCHAR(200)
				,@idClase				VARCHAR(10)
				,@idContratoZona		INT
				,@idSolicitud			INT

		DECLARE @tbl_Solicitud AS TABLE(
			idSolicitud				INT IDENTITY(1,1) NOT NULL
			,idClase				VARCHAR(10)
			,rfcEmpresa				VARCHAR(13)
			,idCliente				INT
			,numeroContrato			VARCHAR(50)
			,idCentroCosto			INT
			,comentarios			VARCHAR(2000)
			,idObjeto				INT
			,idTipoObjeto			INT
			,fechaCreacion			DATETIME
		)

		DECLARE @tbl_bitacoraCorreo AS TABLE(
			vin					VARCHAR(50)
			,fechaCita			DATETIME
			,comentarioOrden	VARCHAR(MAX)
			,envio				INT
			,pop3messageId		VARCHAR(MAX)
		)
				
		SET @err = ''

		DECLARE @vin   VARCHAR(50),
			@tipo   VARCHAR(50) = NULL,
			@numeroSiniestro VARCHAR(50) = NULL,
			@from varchar(200),
			@fecha   DATETIME,
			@comentario  VARCHAR (2000)

		IF EXISTS(
			SELECT 1 FROM seguro.SolicitudCorreo
			WHERE messageId = @idEmail
				AND procesado = 0
		)
		BEGIN

			SELECT @vin = numeroSerie
				,@tipo = tipo
				,@fecha = [date]
				,@comentario = comentario
				,@numeroSiniestro = numeroSiniestro
				,@from = [from]
			FROM seguro.SolicitudCorreo
			WHERE messageId = @idEmail

			IF NOT EXISTS( 
				SELECT 1 
				FROM seguro.SolicitudCorreo
				WHERE numeroSerie = @vin
					AND numeroSiniestro = @numeroSiniestro
					AND [from] = @from
					AND tipo = @tipo
					AND messageId != @idEmail
					AND procesado = 1
			)
			BEGIN

				IF (@vin = '')
				BEGIN
					UPDATE seguro.SolicitudCorreo
						SET procesado = 1
						WHERE messageId = @idEmail
				END
				ELSE
				BEGIN
					IF (CHARINDEX('.', @vin, 0) > 0)
					BEGIN
						SELECT @vin = SUBSTRING(@vin, 0, CHARINDEX('.', @vin, 0))
					END



					IF EXISTS( 
						SELECT 1 FROM Objeto.objeto.ObjetoPropiedadClase opc 
							INNER JOIN Objeto.objeto.PropiedadClase pc ON pc.idPropiedadClase = opc.idPropiedadClase
							INNER JOIN Cliente.contrato.Objeto obj ON obj.idObjeto = opc.idObjeto
							INNER JOIN Cliente.cliente.Contrato con ON con.rfcEmpresa = obj.rfcEmpresa and con.idCliente = obj.idCliente and con.numeroContrato = obj.numeroContrato
						WHERE pc.valor = 'VIN'
							AND opc.valor LIKE @vin + '%'
							AND obj.activo = 1 AND obj.idObjetoEstatus = 'ACT'
							AND con.activo = 1 AND con.idEstatus = 'ACT'
					)
					BEGIN
						SELECT @idObjeto = obj.idObjeto
							,@idTipoObjeto = obj.idTipoObjeto
							,@rfcEmpresa = obj.rfcEmpresa
							,@idCliente = obj.idCliente
							,@numeroContrato = obj.numeroContrato
							,@idClase = obj.idClase
							,@idCentroCosto = obj.idCentroCosto
							,@idContratoZona = obj.idContratoZona
						FROM Objeto.objeto.ObjetoPropiedadClase opc
							INNER JOIN Objeto.objeto.PropiedadClase pc ON pc.idPropiedadClase = opc.idPropiedadClase
							INNER JOIN Cliente.contrato.Objeto obj ON obj.idObjeto = opc.idObjeto
							INNER JOIN Cliente.cliente.Contrato con ON con.rfcEmpresa = obj.rfcEmpresa and con.idCliente = obj.idCliente and con.numeroContrato = obj.numeroContrato
						WHERE pc.valor = 'VIN'
							AND opc.valor LIKE @vin + '%'
							AND obj.activo = 1 AND obj.idObjetoEstatus = 'ACT'
							AND con.activo = 1 AND con.idEstatus = 'ACT'

						INSERT INTO seguro.Solicitud(idClase
						--INSERT INTO @tbl_Solicitud(idClase
							,rfcEmpresa
							,idCliente
							,numeroContrato
							,idCentroCosto
							,comentarios
							,idObjeto
							,idTipoObjeto
							,fechaCreacion
							,solicitudCorreoMessageId)
						VALUES(@idClase
							,@rfcEmpresa
							,@idCliente
							,@numeroContrato
							,@idCentroCosto
							,@comentario
							,@idObjeto
							,@idTipoObjeto
							,GETDATE()
							,@idEmail)

						SET @idSolicitud = SCOPE_IDENTITY()

						IF (@idSolicitud IS NOT NULL)
						BEGIN
							UPDATE seguro.SolicitudCorreo
							SET procesado = 1
							WHERE messageId = @idEmail
								OR (numeroSerie = @vin
									AND tipo = @tipo
									AND numeroSiniestro = @numeroSiniestro
									AND [from] = @from
									)

							SET @err = 'Se ha insertado una pre solicitud'
						END

						SELECT * FROM @tbl_Solicitud
					END

					ELSE
					BEGIN
			
						IF EXISTS ( 
							SELECT 1
							FROM ASEPROT.dbo.Unidades
							WHERE vin = @vin
							)
						BEGIN
							DECLARE @subject nvarchar(max)
									,@html nvarchar(max)
									,@date nvarchar(max)

							select @from = [from]
								,@subject = [subject]
								,@html = [html]
								,@date = CONVERT(varchar, [date], 21)
							from seguro.SolicitudCorreo
							where messageId = @idEmail

							EXEC SISCOV3.mail.CHECKMAIL @messageId = @idEmail, @numeroSerie = @vin, @tipo = @tipo, @from = @from, @date = @date, @subject = @subject, @html = @html, @err = @err

							EXEC SISCOV3.orden.INS_ORDEN_SERVICIOXCORREO_SP @vin = @vin, @tipo = @tipo, @fecha = @fecha, @comentario = @comentario, @idEmail = @idEmail, @err = @err

							UPDATE seguro.SolicitudCorreo
							SET procesado = 1
							WHERE messageId = @idEmail

						END
						ELSE
						BEGIN
							PRINT 'SE INSERTA BITACORA DE ERROR'
							INSERT INTO seguro.BitacoraCorreo(tipo, envio, solicitudCorreomessageId)
							--INSERT INTO @tbl_bitacoraCorreo(vin, fechaCita, comentarioOrden, envio, pop3messageId)
							VALUES('VIN inexistente', 0, @idEmail)

							SELECT * FROM @tbl_bitacoraCorreo
						END
					END
				END
			END
			ELSE
			BEGIN
				UPDATE seguro.SolicitudCorreo
				SET procesado = 1
					,[version] = 'NA'
					,numeroOrden = 'DUPLICADO'
				WHERE messageId = @idEmail
			END
		END

	END TRY
	BEGIN CATCH
		SET @err = 'Línea ' + CONVERT(VARCHAR, ERROR_LINE()) + ':' + ERROR_MESSAGE()
		select @err as msj, 0 as ok;
	END CATCH

	PRINT 'A'
	SELECT 'OUT = ' + @err AS mensaje
	RETURN
END
go

