
-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener los totales por unidad anual>
-- =============================================
CREATE VIEW [solicitud].[SEL_TOTAL_UNIDAD_ANIO_VW]
AS

SELECT 
	so.idObjeto,
	so.idTipoObjeto,
	so.numeroContrato,
	so.idCliente,
	sep.idFase AS idFase,
	SUM(cotpar.cantidad*cotpar.costo) AS costo,
	SUM(cotpar.cantidad*cotpar.venta) AS venta,
	YEAR(s.fechaCreacion) anio
FROM solicitud.SolicitudObjeto so
	INNER JOIN solicitud.solicitud s ON
		s.idSolicitud=so.idSolicitud 
		AND s.idTipoSolicitud = so.idTipoSolicitud 
		AND s.numeroContrato = so.numeroContrato 
		AND s.idCliente = so.idCliente 
		AND s.idClase = so.idClase
		AND S.idEstatusSolicitud = 'ACTIVA'
	INNER JOIN fase.SolicitudEstatusPaso sep ON
		sep.idSolicitud = so.idSolicitud 
		AND sep.idTipoSolicitud = so.idTipoSolicitud 
		AND sep.numeroContrato = so.numeroContrato 
		AND sep.idCliente = so.idCliente 
		AND sep.idClase = so.idClase
	INNER JOIN solicitud.SolicitudCotizacion coti ON
		coti.idSolicitud = so.idSolicitud 
		AND coti.numeroContrato = so.numeroContrato 
		AND coti.idCliente = so.idCliente 
		AND coti.idClase = so.idClase
	LEFT JOIN solicitud.SolicitudCotizacionPartida cotpar ON
		cotpar.idCotizacion = coti.idCotizacion
		AND cotpar.idEstatusCotizacionPartida  = 'APROBADA'
		AND cotpar.numeroContrato = coti.numeroContrato 
		AND cotpar.idCliente = coti.idCliente 
		AND cotpar.idClase = coti.idClase
WHERE
	sep.fechaSalida IS NULL
	AND sep.idPaso != 'Finalizada'
GROUP BY
	so.idObjeto,
	so.idTipoObjeto,
	so.numeroContrato,
	so.idCliente,
	sep.idFase
	,YEAR(s.fechaCreacion)

go

