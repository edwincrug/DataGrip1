
-- =============================================
-- Author:		Alan Rosales Chávez
-- Create date: 18/06/2020
-- Description:	Crea una nueva solicitud de partidas existentes BPRO.
-- =============================================
/*
	Fecha		Autor	Descripción 
	
	*- Testing...
	DECLARE @salida varchar(max) ='727';
	EXEC [compraBPRO].[INS_SOLICITUD_COTIZACION_SP]
		 @idSolicitud				= 864
		,@idClase					= 'Compra'
		,@rfcEmpresa				= 'ASE0508051B6'
		,@idCliente					= 221
		,@numeroContrato			= '49'		
		,@partidas					= 
		'
			<partidas>
				<partida><idPartida>787157</idPartida><cantidad>1</cantidad><costoInicial>1500</costoInicial><ventaInicial>1000</ventaInicial></partida>
				<partida><idPartida>787158</idPartida><cantidad>1</cantidad><costoInicial>200</costoInicial><ventaInicial>0</ventaInicial></partida></partidas>
		'
		,@idUsuario					= 6282
		,@err  = @salida out
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [compraBPRO].[INS_SOLICITUD_COTIZACION_SP]
	 @idSolicitud				INT
	,@idClase					VARCHAR(20)
	,@rfcEmpresa				VARCHAR(13) = ''
	,@idCliente					INT = 0
	,@numeroContrato			VARCHAR(50) = ''
	,@partidas					XML
	,@idUsuario					INT = 0
	,@err						VARCHAR(8000) OUTPUT	
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
    DECLARE
		@VI_One					INT = 1,
		@VI_Zero				INT = 0,
		@VC_ErrorMessage		VARCHAR(4000)	= '',
		@VC_ThrowMessage		VARCHAR(100)	= 'Ocurrio un error en el stored: [compraBPRO][INS_SOLICITUD_COTIZACION_SP]:',
		@VC_ErrorSeverity		INT = 0,
		@VC_ErrorState			INT = 0,
		@VI_ResultCount			INT = 0,
		@VI_IdSolicitud			INT = NULL,
		@VI_IdCotizacion		INT = NULL,
		@VC_NOSOLICITUD			VARCHAR(20) = NULL,
		@VC_NOCOTIZACION		VARCHAR(20) = NULL,
		@VD_ExpiraContrato		DATE = NULL,
		@ERR_MENSAJE			VARCHAR(100) = '',
		@xmlPadre				XML,
		@ACTUAL_idTipoSolicitud VARCHAR(20),
		@ACTUAL_idObjeto		INT,
		@ACTUAL_idTipoObjeto	INT,
		@ACTUAL_idCentroCosto	INT,
		@ACTUAL_idFolioCentroCosto INT,
		@ACTUAL_comentarios		VARCHAR(MAX),
		@ACTUAL_idEmpresa		INT,
		@ACTUAL_idSucursal		INT,
		@ACTUAL_idArea			INT

	DECLARE @VT_Table TABLE (
		[Index]			    INT IDENTITY(1,1),
		[idPartida]			INT,
		[cantidad]			INT,
		[costoInicial]		float, 
		[ventaInicial]		float
	);

	DECLARE @VT_SOLICITUDES TABLE(
		idSolicitud			INT,
		tipoSolciitudBPRO 	VARCHAR(2) --CM = Solicitud de compra, EM = Solicitud de estudio de mercado
	)

	DECLARE @VT_Proveedores TABLE(
		[Index]				INT IDENTITY(1,1),
		rfcProveedor		VARCHAR(13),
		idProveedorEntidad	INT
	)

	CREATE TABLE #VT_Table_ProveedorPartida (
		[Index]			    INT IDENTITY(1,1),
		[idPartida]			INT,
		[cantidad]			INT,
		[costoInicial]		float, 
		[ventaInicial]		float
	);
	
	BEGIN TRY

		
		--INSERTAMOS LAS PARTIDAS DE CATALOGO
		INSERT INTO @VT_Table
			SELECT
				I.N.value('(idPartida)[1]',	'INT'),
				I.N.value('(cantidad)[1]',	'INT'),
				I.N.value('(costoInicial)[1]',	'float'),
				I.N.value('(ventaInicial)[1]',	'float')
			FROM @partidas.nodes('/partidas/partida') I(N);

		--OBTENEMOS EL LISTADO DE PROVEEDORES QUE ATIENDEN LAS PARTIDAS SELECCIONADAS:
		INSERT INTO @VT_Proveedores
		SELECT DISTINCT 
			pe.rfcProveedor,
			pe.idProveedorEntidad
		FROM @VT_Table t
		INNER JOIN Partida.partida.Partida p on p.idPartida = t.idPartida
		INNER JOIN compraBPRO.ProveedorEntidadPartida pe on pe.numeroParte = partida.partida.getPropiedadPartida(p.idPartida,'noParte','general')

		--OBTENEMOS EL IDUSUARIO DE BPRO
		DECLARE @idUsuarioBPRO INT 
		SELECT TOP 1 @idUsuarioBPRO=ISNULL(idUsuarioBPRO,0) FROM common.configuracion.usuariosBPRO WHERE idUsuario=@idUsuario		

		--OBTENEMOS DATOS DE LA SOLICITUD ACTUAL
		SELECT
			 @ACTUAL_idTipoSolicitud = S.idTipoSolicitud
			,@ACTUAL_idObjeto = S.idObjeto
			,@ACTUAL_idTipoObjeto = S.idTipoObjeto
			,@ACTUAL_idCentroCosto = SS.idCentroCosto
			,@ACTUAL_comentarios = SS.comentarios
			,@ACTUAL_idEmpresa = SC.idEmpresa
			,@ACTUAL_idSucursal = SC.idSucursal
			,@ACTUAL_idArea = SC.idArea
		FROM solicitud.SolicitudObjeto S
		INNER JOIN solicitud.solicitud SS on SS.idSolicitud = S.idSolicitud
		INNER JOIN compraBPRO.Solicitud SC on SC.idSolicitud = S.idSolicitud
		WHERE
			S.idSolicitud=@idSolicitud

		DECLARE @prCount INT = 1, @prMax INT = (SELECT COUNT([Index]) FROM @VT_Proveedores); --PROVEEDORES
		

		SELECT @VD_ExpiraContrato = (
				SELECT 
					COALESCE([fechaFin], null) 
				FROM [Cliente].[cliente].[Contrato]
				WHERE 
					[rfcEmpresa] = @rfcEmpresa AND
					[idCliente] = @idCliente AND
					[numeroContrato] = @numeroContrato
			)


		
		BEGIN TRANSACTION INS
		IF (@VD_ExpiraContrato >= GETDATE())		
		BEGIN
			--INSERTAMOS SOLICITUDPARTIDA PARA LA PRIMER COTIZACION CREADA
			INSERT INTO [solicitud].[SolicitudPartida] (
				[idSolicitud]
				,[idTipoSolicitud]
				,[idClase]
				,[rfcEmpresa]
				,[idCliente]
				,[numeroContrato]
				,[idObjeto]
				,[idTipoObjeto]
				,[idPartida]
				,[cantidad]
				,[costoInicial]
				,[ventaInicial]
				,[idEstatusSolicitudPartida]
				,[idUsuario]
			)
			SELECT 
				 @idSolicitud
				,@ACTUAL_idTipoSolicitud
				,@idClase
				,@rfcEmpresa
				,@idCliente
				,@numeroContrato				
				,@ACTUAL_idObjeto
				,@ACTUAL_idTipoObjeto
				,T.idPartida
				,T.cantidad
				,T.costoInicial
				,T.ventaInicial
				,'ENESPERA'
				,@idUsuario
			FROM @VT_Table T
			INNER JOIN Partida.partida.Partida p on p.idPartida = t.idPartida
			INNER JOIN compraBPRO.ProveedorEntidadPartida pe on pe.numeroParte = partida.partida.getPropiedadPartida(p.idPartida,'noParte','general')
			INNER JOIN @VT_Proveedores PP ON PP.rfcProveedor = PE.rfcProveedor and PP.idProveedorEntidad=PP.idProveedorEntidad
			where 
				PP.[Index] = 1

			--CREAMOS LA COTIZACION PARA EL PRIMER PROVEEDOR:
			SET @VC_NOCOTIZACION = (SELECT [solicitud].[SEL_NUMEROCOTIZACION_FN](@idSolicitud,@rfcEmpresa,@ACTUAL_idTipoSolicitud,@idClase,@idCliente,@numeroContrato))
			INSERT INTO [solicitud].[SolicitudCotizacion] (
				[idSolicitud]
				,[idTipoSolicitud]
				,[idClase]
				,[rfcEmpresa]
				,[idCliente]
				,[numeroContrato]
				,[idProveedorEntidad]
				,[rfcProveedor]
				,[numeroCotizacion]
				,[fechaAlta]
				,[idUsuario]
				,[idEstatusCotizacion]
			) VALUES (
				 @idSolicitud
				,@ACTUAL_idTipoSolicitud
				,@idClase
				,@rfcEmpresa
				,@idCliente
				,@numeroContrato
				,(select idProveedorEntidad from @VT_Proveedores where [Index]=1)
				,(select rfcProveedor from @VT_Proveedores where [Index]=1)
				,@VC_NOCOTIZACION
				,GETDATE()
				,@idUsuario
				,'ENESPERA'
			)
			SET @VI_IdCotizacion = SCOPE_IDENTITY()	
			INSERT INTO solicitud.SolicitudCotizacionPartida ([idCotizacion]
				, [idSolicitud]
				, [idTipoSolicitud]
				, [idClase]
				, [rfcEmpresa]
				, [numeroContrato]
				, [idCliente]
				, [rfcProveedor]
				, [idProveedorEntidad]
				, [idObjeto]
				, [idTipoObjeto]
				, [idPartida]
				, [cantidad]
				, [costo]
				, [venta]
				, [idEstatusCotizacionPartida]
				, [fechaEstatus]
				, [idUsuario])
			SELECT @VI_idCotizacion
				, @idSolicitud
				, @ACTUAL_idTipoSolicitud
				, @idClase
				, @rfcEmpresa
				, @numeroContrato
				, @idCliente
				,(select rfcProveedor from @VT_Proveedores where [Index]=1)
				,(select idProveedorEntidad from @VT_Proveedores where [Index]=1)						
				, @ACTUAL_idObjeto
				, @ACTUAL_idTipoObjeto
				, T.idPartida
				, T.cantidad
				, T.costoInicial
				, T.ventaInicial
				, 'ENESPERA'
				, GETDATE()
				, @idUsuario
			FROM @VT_Table T
			INNER JOIN Partida.partida.Partida p on p.idPartida = t.idPartida
			INNER JOIN compraBPRO.ProveedorEntidadPartida pe on pe.numeroParte = partida.partida.getPropiedadPartida(p.idPartida,'noParte','general')
			INNER JOIN @VT_Proveedores PP ON PP.rfcProveedor = PE.rfcProveedor and PP.idProveedorEntidad=PP.idProveedorEntidad
			where 
				PP.[Index] = 1
			INSERT INTO [solicitud].[EstatusSolicitudCotizacion] (
					fechaAlta
					,idCotizacion
					,idSolicitud
					,idTipoSolicitud
					,idClase
					,rfcEmpresa
					,idCliente
					,numeroContrato
					,idProveedorEntidad
					,rfcProveedor
					,idEstatusCotizacion
					,idUsuario
				) VALUES (
					GETDATE()
					,@VI_idCotizacion
					,@idSolicitud
					,@ACTUAL_idTipoSolicitud
					,@idClase
					,@rfcEmpresa
					,@idCliente
					,@numeroContrato
					,(select idProveedorEntidad from @VT_Proveedores where [Index]=1)
					,(select rfcProveedor from @VT_Proveedores where [Index]=1)
					,'ENESPERA'
					,@idUsuario
				)
			INSERT INTO @VT_SOLICITUDES VALUES(@idSolicitud,'CM')
			--VERIFICAMOS SI EXISTEN MAS PROVEEDORES, 
			-- EN CASO DE SER ASÍ COMENZAMOS CON EL SEGUNDO REGISTRO Y CREAMOS SOLICITUDES PARA CADA PROVEEDOR
			IF @prMax>1
			BEGIN
				SET @prCount=2
				WHILE (@prCount<=@prMax)
				BEGIN			
					--INSERTAMOS LAS PARTIDAS CORRESPONDIENTES AL PROVEEDOR
					TRUNCATE TABLE #VT_Table_ProveedorPartida
					INSERT INTO #VT_Table_ProveedorPartida
					SELECT 
						T.idPartida
						,T.cantidad
						,T.costoInicial
						,T.ventaInicial
					FROM @VT_Table T
					INNER JOIN Partida.partida.Partida p on p.idPartida = t.idPartida
					INNER JOIN compraBPRO.ProveedorEntidadPartida pe on pe.numeroParte = partida.partida.getPropiedadPartida(p.idPartida,'noParte','general')
					INNER JOIN @VT_Proveedores PP ON PP.rfcProveedor = PE.rfcProveedor and PP.idProveedorEntidad=PE.idProveedorEntidad
					where 
						PP.[Index] = @prCount
					--***********************************************************************************************
					--0. OBTENEMOS NUMERO DE SOLICITUD
					--***********************************************************************************************
					SELECT @VC_NOSOLICITUD = (SELECT [solicitud].[SEL_NUMEROSOLICITUD_FN](@rfcEmpresa, @idCliente, @numeroContrato));
					--***********************************************************************************************
					--1. CREAMOS ENCABEZADO DE SOLICITUD
					--***********************************************************************************************
					INSERT INTO [solicitud].[Solicitud] (
							 [rfcEmpresa]
							,[idCliente]
							,[numeroContrato]
							,[idCentroCosto]
							,[folio]
							,[idTipoSolicitud]
							,[idClase]
							,[fechaCreacion]
							,[fechaCita]
							,[numero]
							,[comentarios]
							,[idEstatusSolicitud]
							,[idUsuario]
						) VALUES (
							@rfcEmpresa,
							@idCliente,
							@numeroContrato,
							@ACTUAL_idCentroCosto,
							@ACTUAL_idFolioCentroCosto,
							@ACTUAL_idTipoSolicitud,
							@idClase,
							GETDATE(),
							GETDATE(),
							@VC_NOSOLICITUD,
							@ACTUAL_comentarios,
							'ACTIVA',
							@idUsuario
						)
					SET @VI_IdSolicitud = SCOPE_IDENTITY()
					--***********************************************************************************************
					--2. ACTUALIZAMOS CONSECUTIVO DEL CONTRATO
					--***********************************************************************************************
					UPDATE [solicitud].[ContratoConsecutivo]
								SET [consecutivo] = (
									SELECT 
										CAST([consecutivo] AS INT) + 1
									FROM [solicitud].[ContratoConsecutivo]
									WHERE 
										[rfcEmpresa] = @rfcEmpresa AND
										[idCliente] = @idCliente AND
										[numeroContrato] = @numeroContrato
								)
								WHERE 
									[rfcEmpresa] = @rfcEmpresa AND
									[idCliente] = @idCliente AND
									[numeroContrato] = @numeroContrato 
					--***********************************************************************************************
					--3. INSERTAMOS SOLICITUDOBJETO
					--***********************************************************************************************
					INSERT INTO [solicitud].[SolicitudObjeto](
							 [idSolicitud]
							,[rfcEmpresa]
							,[idCliente]
							,[numeroContrato]
							,[idTipoSolicitud]
							,[idObjeto]
							,[idTipoObjeto]
							,[idClase]
							,[numeroOrden]
							,[fechaAlta]
							,[idUsuario]
						) VALUES (
							@VI_IdSolicitud,
							@rfcEmpresa,
							@idCliente,
							@numeroContrato,
							@ACTUAL_idTipoSolicitud,
							@ACTUAL_idObjeto,
							@ACTUAL_idTipoObjeto,
							@idClase,
							(@VC_NOSOLICITUD +'-'+ CONVERT(VARCHAR(20), @ACTUAL_idObjeto)),
							GETDATE(),
							@idUsuario
						)
					--***********************************************************************************************
					--4. INSERTAMOS LA SOLICITUD EN COMPRABPRO
					--***********************************************************************************************
					INSERT INTO [compraBPRO].[solicitud](
						idSolicitud
						,idTiposolicitud
						,idClase
						,rfcEmpresa
						,idCliente
						,numeroContrato
						,idUsuarioBPRO
						,idEmpresa
						,idSucursal
						,idArea
						,idUsuario
						,activo)
						VALUES(
							@VI_IdSolicitud
							,@ACTUAL_idTipoSolicitud
							,@idClase
							,@rfcEmpresa
							,@idCliente
							,@numeroContrato
							,@idUsuarioBPRO
							,@ACTUAL_idEmpresa
							,@ACTUAL_idSucursal
							,@ACTUAL_idArea
							,@idUsuario
							,1
						)
					--***********************************************************************************************
					--5. INSERTAMOS PARTIDAS DE CATALOGO
					--***********************************************************************************************
					DECLARE @pCCount INT = 1, @pCMax INT = (SELECT COUNT([Index]) FROM #VT_Table_ProveedorPartida);
					WHILE (@pCCount <= @pCMax)
					BEGIN
						INSERT INTO [solicitud].[SolicitudPartida] (
								[idSolicitud]
							,[idTipoSolicitud]
							,[idClase]
							,[rfcEmpresa]
							,[idCliente]
							,[numeroContrato]
							,[idObjeto]
							,[idTipoObjeto]
							,[idPartida]
							,[cantidad]
							,[costoInicial]
							,[ventaInicial]
							,[idEstatusSolicitudPartida]
							,[idUsuario]
						) VALUES (
							 @VI_IdSolicitud
							,@ACTUAL_idTipoSolicitud
							,@idClase
							,@rfcEmpresa
							,@idCliente
							,@numeroContrato
							,@ACTUAL_idObjeto
							,@ACTUAL_idTipoObjeto
							,(SELECT [idPartida] FROM #VT_Table_ProveedorPartida WHERE [Index] = @pCCount)
							,(SELECT [cantidad] FROM #VT_Table_ProveedorPartida WHERE [Index] = @pCCount)
							,(SELECT [costoInicial] FROM #VT_Table_ProveedorPartida WHERE [Index] = @pCCount)
							,(SELECT [ventaInicial] FROM #VT_Table_ProveedorPartida WHERE [Index] = @pCCount)
							,'ENESPERA'
							, @idUsuario
						)
						SET @pCCount = @pCCount + 1;
					END
					--***********************************************************************************************
					--6. INSERTAMOS PROPIEDADES DE CLASE
					--***********************************************************************************************
					INSERT INTO [solicitud].[SolicitudPropiedadClase] (
							[idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idPropiedadClase]
						,[valor]
						,[fechaCaducidad]
						,[idUsuario]
					)
					SELECT
						@VI_IdSolicitud
						,PC.idTipoSolicitud
						,PC.idClase
						,PC.rfcEmpresa
						,PC.idCliente
						,PC.numeroContrato
						,PC.idPropiedadClase
						,PC.valor
						,PC.fechaCaducidad
						,PC.idUsuario
					FROM solicitud.SolicitudPropiedadClase PC
					WHERE PC.idSolicitud=@idSolicitud					
					--***********************************************************************************************
					--7. INSERTAMOS PROPIEDADES POR TIPO DE SOLICITUD
					--***********************************************************************************************
					INSERT INTO [solicitud].[SolicitudPropiedadTipoSolicitud] (
						[idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idPropiedadTipoSolicitud]
						,[valor]
						,[fechaCaducidad]
						,[idUsuario]
					)
					SELECT
						@VI_IdSolicitud
						,PS.idTipoSolicitud
						,PS.idClase
						,PS.rfcEmpresa
						,PS.idCliente
						,PS.numeroContrato
						,PS.idPropiedadTipoSolicitud
						,PS.valor
						,PS.fechaCaducidad
						,PS.idUsuario
					FROM solicitud.[SolicitudPropiedadTipoSolicitud] PS
					WHERE PS.idSolicitud=@idSolicitud
					--***********************************************************************************************
					--8. INSERTAMOS HISTORICO DE LA SOLICITUD
					--***********************************************************************************************
					INSERT INTO [fase].[SolicitudEstatusPaso] (
							  [idSolicitud]
							 ,[rfcEmpresa]
							 ,[idCliente]
							 ,[numeroContrato]
							 ,[idPaso]
							 ,[idFase]
							 ,[idClase]
							 ,[idTipoSolicitud]
							 ,[fechaIngreso]
							 ,[idEstatus]
							 ,[idUsuarioIngreso]
						) VALUES (
							@VI_IdSolicitud
							,@rfcEmpresa
							,@idCliente
							,@numeroContrato
							,(SELECT 
							top 1	[idPaso] 
							from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@ACTUAL_idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
							,(SELECT 
							top 1	idFase 
							from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@ACTUAL_idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
							,@idClase
							,@ACTUAL_idTipoSolicitud
							,GETDATE()
							,1
							,@idUsuario
						)
					--***********************************************************************************************
					--9. AVANZAMOS LA ORDEN HASTA ESTUDIO DE MERCADO
					--***********************************************************************************************
					EXEC Solicitud.UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP @VI_IdSolicitud, @ACTUAL_idTipoSolicitud, @idClase, @rfcEmpresa, @idCliente, @numeroContrato,'EstudioMercado','Solicitud',@idUsuario,''
					--***********************************************************************************************
					--10. INSERTAMOS A LA TABLA DE SALIDA LA SOLICITUD GENERADA
					--***********************************************************************************************
					INSERT INTO @VT_SOLICITUDES VALUES(@VI_IdSolicitud,'CM')
					--***********************************************************************************************
					--11. CREAMOS LA COTIZACION DE FORMA AUTOMATICA
					--***********************************************************************************************
					SET @VC_NOCOTIZACION = (SELECT [solicitud].[SEL_NUMEROCOTIZACION_FN](@VI_IdSolicitud,@rfcEmpresa,@ACTUAL_idTipoSolicitud,@idClase,@idCliente,@numeroContrato))
					INSERT INTO [solicitud].[SolicitudCotizacion] (
							 [idSolicitud]
							,[idTipoSolicitud]
							,[idClase]
							,[rfcEmpresa]
							,[idCliente]
							,[numeroContrato]
							,[idProveedorEntidad]
							,[rfcProveedor]
							,[numeroCotizacion]
							,[fechaAlta]
							,[idUsuario]
							,[idEstatusCotizacion]
						) VALUES (
							 @VI_IdSolicitud
							,@ACTUAL_idTipoSolicitud
							,@idClase
							,@rfcEmpresa
							,@idCliente
							,@numeroContrato
							,(select idProveedorEntidad from @VT_Proveedores where [Index]=@prCount)
							,(select rfcProveedor from @VT_Proveedores where [Index]=@prCount)
							,@VC_NOCOTIZACION
							,GETDATE()
							,@idUsuario
							,'ENESPERA'
						)
					SET @VI_IdCotizacion = SCOPE_IDENTITY()	
					INSERT INTO solicitud.SolicitudCotizacionPartida ([idCotizacion]
							, [idSolicitud]
							, [idTipoSolicitud]
							, [idClase]
							, [rfcEmpresa]
							, [numeroContrato]
							, [idCliente]
							, [rfcProveedor]
							, [idProveedorEntidad]
							, [idObjeto]
							, [idTipoObjeto]
							, [idPartida]
							, [cantidad]
							, [costo]
							, [venta]
							, [idEstatusCotizacionPartida]
							, [fechaEstatus]
							, [idUsuario])
						SELECT @VI_idCotizacion
							, @VI_IdSolicitud
							, @ACTUAL_idTipoSolicitud
							, @idClase
							, @rfcEmpresa
							, @numeroContrato
							, @idCliente
							,(select rfcProveedor from @VT_Proveedores where [Index]=@prCount)
							,(select idProveedorEntidad from @VT_Proveedores where [Index]=@prCount)						
							, VT.idObjeto
							, VT.idTipoObjeto
							, VT.idPartida
							, VT.cantidad
							, VT.costoInicial
							, VT.ventaInicial
							, 'ENESPERA'
							, GETDATE()
							, @idUsuario
						FROM solicitud.SolicitudPartida VT
						where idSolicitud = @VI_IdSolicitud
					INSERT INTO [solicitud].[EstatusSolicitudCotizacion] (
						fechaAlta
						,idCotizacion
						,idSolicitud
						,idTipoSolicitud
						,idClase
						,rfcEmpresa
						,idCliente
						,numeroContrato
						,idProveedorEntidad
						,rfcProveedor
						,idEstatusCotizacion
						,idUsuario
					) VALUES (
						GETDATE()
						,@VI_idCotizacion
						,@VI_IdSolicitud
						,@ACTUAL_idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,(select idProveedorEntidad from @VT_Proveedores where [Index]=@prCount)
						,(select rfcProveedor from @VT_Proveedores where [Index]=@prCount)
						,'ENESPERA'
						,@idUsuario
					)
					--***********************************************************************************************
					--***********************************************************************************************
					--FIN
					--***********************************************************************************************
					set @prCount=@prCount+1
				END				
			END			
			COMMIT TRANSACTION INS
			SELECT 
				SO.idSolicitud				idSolicitud
				,SS.numero					numeroSolicitud
				,S.tipoSolciitudBPRO		tipoSolicitudBPRO
				,CON.idFileAvatar			idLogoContrato
				,''							error
				,SO.numeroOrden				numeroOrden
			FROM @VT_SOLICITUDES S
			INNER JOIN Solicitud.Solicitud SS ON SS.idSolicitud = S.idSolicitud
			INNER JOIN Solicitud.SolicitudObjeto SO ON S.idSolicitud = SO.idSolicitud
			INNER JOIN Cliente.cliente.Contrato CON ON 
				CON.rfcEmpresa = SO.rfcEmpresa
				AND CON.idCliente = SO.idCliente
				AND CON.numeroContrato = SO.numeroContrato

		END
		ELSE
		BEGIN
			SET @ERR_MENSAJE = 'El contrato ha expirado.'
			COMMIT TRANSACTION INS
		END		
	END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION INS
				SET @VC_ErrorMessage = { 
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage
					) 
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
				SET @err = @VC_ErrorMessage;
			END
		END CATCH
END
go

