
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 14-06-2019
-- Description: Consulta trae fases de solicitudes
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[SEL_FASE_SOLICITUD_SP_TEST]  'Automovil', 2270, 
	'<contratos><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Aguascalientes</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Baja California Sur</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Campeche</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chiapas</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Chihuahua</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Ciudad de México</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Coahuila de Zaragoza</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Colima</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Durango</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guanajuato</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Guerrero</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Hidalgo</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>undefined</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>México</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>undefined</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Morelos</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nayarit</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Nuevo León</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Oaxaca</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Puebla</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Querétaro</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Quintana Roo</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>San Luis Potosí</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sinaloa</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Sonora</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tabasco</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tamaulipas</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Tlaxcala</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Veracruz de Ignacio de la Llave</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Yucatán</estado></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa><estado>Zacatecas</estado></contrato></contratos>'
	,0, @salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [fase].[SEL_FASE_SOLICITUD_SP] 
	@idClase				varchar(50),
	@idUsuario				INT,
	@contratos				XML,
	@idZona					INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	DECLARE @salida varchar(max) ='' ;

	IF(@idZona = 0)
		BEGIN
			
			EXEC [fase].[SEL_FASE_SOLICITUDSINZONA_SP]  @idClase, @idUsuario, @contratos, @salida OUTPUT;
			SELECT @salida AS salida;
		END

	ELSE
		BEGIN
			EXEC [fase].[SEL_FASE_SOLICITUDCONZONA_SP]   @idClase, @idUsuario, @contratos,@idZona, @salida OUTPUT;
			SELECT @salida AS salida;
		END

	
END
go

