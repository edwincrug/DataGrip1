-- =============================================
-- Author:		Gerardo Zamudio
-- Create date: 10/07/2019
-- Description:	Genera el tiempo de direfencia de una fecha solo los dias.
-- Test:		SELECT [solicitud].[SEL_DIFERENCIAFECHA_FN]
-- =============================================
CREATE FUNCTION [solicitud].[SEL_DIFERENCIAFECHADIAS_FN]
(
  @fechaInicio				Datetime,       -- Dia inicio
  @fechaFin					Datetime        -- Dia fin
        -- Formato: #d HH:MM:SS
        -- Sample:
                        -- Set dateformat ymd
                        -- SELECT dbo.ufn_CalcularDiferenciaenHoras('2017-10-01 01:46:00', '2017-10-17 10:45:00')
                        -- Return: 16d 08:59:00
)
RETURNS VARCHAR(MAX)
AS 
BEGIN
  DECLARE @OUT VARCHAR(100)
  DECLARE @segundos BIGINT
  
  SET @segundos = ( SELECT datediff(SECOND,@fechaInicio, @fechaFin) ) -- AS Segundos
    SET @segundos = ISNULL(@segundos, 0)
  SET @OUT ='0d 00:00:00'
    
    IF (@segundos < 0)
        RETURN @OUT
    
    SET @OUT = CONVERT(VARCHAR, FLOOR(@segundos / 86400) )
    -------------
  RETURN @OUT
  -------------
END
go

