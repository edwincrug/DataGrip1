-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <08/05/2020>
-- Description:	<Actualiza datos de la preorden>
-- =============================================
create PROCEDURE [solicitud].[UPD_DATOSPREORDEN_SP]
@idPreorden	INT,
@numeroOrden	NVARCHAR(50),
@idUsuario		INT,
@err			VARCHAR(8000) = '' OUTPUT		
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION ACTUALIZAPREORDEN
		DECLARE @solicitudCorreoMessageId VARCHAR(300)
		SELECT @solicitudCorreoMessageId = solicitudCorreoMessageId FROM seguro.solicitud WHERE idSolicitud=@idPreorden

		UPDATE seguro.SolicitudCorreo SET numeroOrden=@numeroOrden,version='siscoV3' WHERE messageId = @solicitudCorreoMessageId
		--DELETE FROM seguro.solicitud WHERE idSolicitud=@idPreorden
		COMMIT TRANSACTION ACTUALIZAPREORDEN
	END TRY
	BEGIN CATCH
		SET @err='Error al actualizar los datos de la preorden.'
		ROLLBACK TRANSACTION ACTUALIZAPREORDEN
	END CATCH
END
go

