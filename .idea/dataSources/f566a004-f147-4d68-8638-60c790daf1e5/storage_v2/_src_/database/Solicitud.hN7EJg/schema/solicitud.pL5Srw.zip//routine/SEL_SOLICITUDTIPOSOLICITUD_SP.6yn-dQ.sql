-- =============================================
-- Author:		Gerardo Zamudio
-- Create date: 13/08/2019
-- Description:	obtiene un listado de tipos de solicitud.
-- Test;		exec [solicitud].[SEL_SOLICITUDTIPOSOLICITUD_SP] 'Automovil', null
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_SOLICITUDTIPOSOLICITUD_SP]
	@idUsuario			INT,
	@idClase			VARCHAR(10),
	@err				VARCHAR(MAX) OUTPUT
AS
BEGIN
	SET @err = ''
	SELECT 
		[idTipoSolicitud],
		[idClase],
		[nombre],
		[descripcion],
		[aplicaMovil],
		[activo],
		[idUsuario]
	FROM [solicitud].[TipoSolicitud]
	WHERE idClase = @idClase
END
go

