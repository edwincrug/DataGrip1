-- =============================================
-- Author:		Martin Pacheco
-- Create date: 23/05/2019
-- Description:	.
-- Test:		exec [solicitud].[SEL_PROPIEDAD_OBJETO_SP] 'Automovil',null
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_PROPIEDAD_OBJETO_SP] 
	@idClase			varchar(10),
	@idUsuario			int = null,
	@err				varchar(500) OUTPUT
AS
BEGIN

DECLARE @propiedades AS TABLE(
								id				INT,
								idPadre			INT,
								valor			NVARCHAR(500),
								arreglo			NVARCHAR(500),
								idClase			NVARCHAR(500),
								idTipoValor		NVARCHAR(20),
								idTipoDato		NVARCHAR(20),
								propiedad		NVARCHAR(50),
								idPropiedad		INT,
								obligatorio		BIT,
								posicion		INT,
								orden			INT
							--	idTipoObjeto	INT,
								)

	INSERT INTO @propiedades
		SELECT 
		idPropiedadClase	as id
		,ISNULL(idPadre,0)	 as idPadre
		,valor	
		,'' as arreglo
		,idClase
		,idTipoValor
		,idTipoDato
		,'clase' propiedad
		,2 idPropiedad
		,obligatorio
		,posicion
		,orden
	FROM [Solicitud].[PropiedadClase] 
	WHERE idClase = @idClase 
	AND	activo=1

	SELECT * FROM @propiedades
	ORDER BY idClase,posicion, orden asc

END
go

