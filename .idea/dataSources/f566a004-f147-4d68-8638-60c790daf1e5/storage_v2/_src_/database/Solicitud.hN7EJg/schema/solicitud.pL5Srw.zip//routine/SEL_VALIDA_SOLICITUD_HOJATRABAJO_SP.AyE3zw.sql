
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <20/08/2020>
-- Description:	<Valida si un proveedor puede o no ser actualizado en una cotizacion>
/*
	EXEC [solicitud].[SEL_VALIDA_SOLICITUD_HOJATRABAJO_SP] 1082,'Instala','Automovil','AAN910409135',218,'0001',118,13556,6282,null
	
*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_VALIDA_SOLICITUD_HOJATRABAJO_SP]
@idSolicitud		INT = 0,
@idTipoSolicitud	VARCHAR(10),
@idClase			VARCHAR(10) = '',
@rfcEmpresa			VARCHAR(13) = '',
@idCliente			INT = 0,
@numeroContrato		VARCHAR(50) = '',	
@idTipoObjeto		INT,
@idObjeto			INT,
@idUsuario			INT = 0,
@err				VARCHAR(500) OUTPUT
AS
BEGIN
	DECLARE @existe VARCHAR(100)

	IF EXISTS(	SELECT 1 
				FROM	documento.SolicitudObjetoPaso sop 
				INNER	JOIN documento.Paso pa ON sop.idDocumentoClase=pa.idDocumentoClase AND pa.nombre='Hoja de Trabajo'
				WHERE	sop.idSolicitud		=@idSolicitud
				AND		sop.idTipoSolicitud	=@idTipoSolicitud
				AND		sop.idClase			=@idClase
				AND     sop.rfcEmpresa		=@rfcEmpresa
				AND     sop.idCliente		=@idCliente
				AND     sop.numeroContrato	=@numeroContrato
				AND     sop.idTipoObjeto	=@idTipoObjeto
				AND     sop.idObjeto		=@idObjeto)
		SELECT estatus=0,errors='El proveedor no puede ser actualizado, este ya cuenta con una hoja de trabajo'
	ELSE
		SELECT estatus=1,errors=''
END


--USE [Solicitud]
go

