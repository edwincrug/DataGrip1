-- =============================================  
-- Author: Alan Rosales Chávez  
-- Create date: 24-07-2019  
-- Description: Obtencion de parametros adicionales para flujo de pasos dinámico
-- ============== Versionamiento ================  
/*  
 Fecha			Autor			Descripción   
 01/10/2020		JLuis Lozada	Se agrego el parametro @esMultiple y se condiciono en los querys
   
  
 *- Testing...  
 DECLARE @salida varchar(max) ='' ;  
 EXEC [fase].[SEL_SOLICITUD_PARAMETROSADICIONALES_SP] 503,'Servicio','Automovil','ASE0508051B6',219,'128',null,6119,@salida out
 SELECT @salida AS salida;  

*/  
  
CREATE PROCEDURE [fase].[SEL_SOLICITUD_PARAMETROSADICIONALES_SP]  
 @idSolicitud			int,
 @idTipoSolicitud		VARCHAR(10),  
 @idClase				VARCHAR(10),  
 @rfcEmpresa			varchar(13),
 @idCliente				int,
 @numeroContrato		varchar(50), 
 @esMultiple			bit=0,
 @idUsuario				INT = null,  
 @err     varchar(500)OUTPUT  
AS  
BEGIN  
	
	declare 
			@idPasoActual	varchar(50),
			@tipoPaso		varchar(10)

	

	select 
		@idPasoActual = aux.idPaso,
		@tipoPaso = aux.tipoPaso
	from [solicitud].SEL_PASO_SOLICITUD_FN(@idSolicitud) aux

	if (@tipoPaso='PASO' AND @esMultiple=0)
	BEGIN
		if (@idPasoActual in( 'EnTaller','EnProceso', 'Cobranza','Entrega','FacturaAbonada','FacturaEnviadaCliente','Finalizada','PrefacturaGenerada','TerminoTrabajo') )
		BEGIN
			--SOLO REQUERIMOS ADICIONALES DE IDOBJETO, IDTIPO OBJETO PARA LA ASIGNACION DE SUSTITUTO
			SELECT	DISTINCT TOP 1
					solobj.idObjeto,
					solobj.idTipoObjeto
			FROM	solicitud.Solicitud sol
			INNER	JOIN solicitud.SolicitudObjeto solobj ON sol.idSolicitud =solobj.idSolicitud
			AND		sol.idTipoSolicitud = solobj.idTipoSolicitud
			AND		sol.idClase = solobj.idClase
			AND		sol.rfcEmpresa = solobj.rfcEmpresa
			AND		sol.idCliente = solobj.idCliente
			AND		sol.numeroContrato = solobj.numeroContrato
			WHERE	sol.idSolicitud = @idSolicitud
		END
	END

	if (@tipoPaso='CONTRATO')
	BEGIN
		set @err = ''
	END
END


--USE [Solicitud]
go

