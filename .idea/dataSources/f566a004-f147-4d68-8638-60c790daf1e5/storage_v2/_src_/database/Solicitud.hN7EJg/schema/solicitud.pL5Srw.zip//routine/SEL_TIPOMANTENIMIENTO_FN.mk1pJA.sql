
CREATE FUNCTION [solicitud].[SEL_TIPOMANTENIMIENTO_FN]
(
	@idSolicitud INT
)
RETURNS VARCHAR(500)
AS
BEGIN
	DECLARE @tipoManto VARCHAR(500);
	DECLARE @idPropiedad INT = (select top 1 [idPropiedadClase] from [Partida].[partida].[PropiedadClase] where [valor] = 'Mantenimiento Preventivo')


	IF EXISTS (
		SELECT  distinct [idPropiedadClase] FROM [solicitud].[SolicitudCotizacionPartida] AS SCP
		INNER JOIN [Partida].[partida].[PartidaPropiedadClase] AS PPC ON SCP.idPartida = PPC.idPartida 
		WHERE idSolicitud = @idSolicitud AND [idPropiedadClase] = @idPropiedad
	)
		SET @tipoManto = 'Mantenimiento Preventivo'

	ELSE 
		--SET @tipoManto = 'Mantenimiento Correctivo'
		SET @tipoManto = 'No aplica'

	IF (@tipoManto = 'Mantenimiento Preventivo' AND exists (SELECT  distinct [idPropiedadClase] FROM [solicitud].[SolicitudCotizacionPartida] AS SCP
		INNER JOIN [Partida].[partida].[PartidaPropiedadClase] AS PPC ON SCP.idPartida = PPC.idPartida 
		WHERE idSolicitud = @idSolicitud AND [idPropiedadClase] != @idPropiedad )
	)
		SET @tipoManto = 'Mantenimiento Correctivo / Preventivo'

	RETURN @tipoManto
END
go

