
-- =============================================
-- Author:		<Jose Luis Lozada G>
-- Create date: <25/05/2020>
-- Description:	<Obtiene catalogo de empresas>
-- =============================================

/*
	exec  [compraBPRO].[SEL_OBTENERCATALOGOEMPRESAS_SP] 3902,null

*/
CREATE PROCEDURE [compraBPRO].[SEL_OBTENERCATALOGOEMPRESAS_SP]
@idUsuario			INT,
@err				VARCHAR(500) OUTPUT	
AS
BEGIN
	DECLARE @idUsuarioBPRO int
	SELECT @idUsuarioBPRO=idUsuarioBPRO FROM common.configuracion.usuariosBPRO WHERE idUsuario=@idUsuario
	print @idUsuarioBPRO
	select distinct e.emp_idempresa as 'id', e.emp_nombre as 'descripcion' 
	from [192.168.20.29].[ControlAplicaciones].dbo.cat_empresas e
	inner join [192.168.20.29].ControlAplicaciones.DBO.OPE_ORGANIGRAMA  o on e.emp_idEmpresa=o.emp_idEmpresa
	WHERE o.usu_idusuario = @idUsuarioBPRO
	
END
go

