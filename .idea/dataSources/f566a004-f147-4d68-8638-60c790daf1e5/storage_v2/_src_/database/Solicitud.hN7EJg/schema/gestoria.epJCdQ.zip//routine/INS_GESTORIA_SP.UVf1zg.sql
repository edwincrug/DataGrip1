
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 03-07-2019
-- Description: Inserta Gestoria y detalle
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[INS_GESTORIA_SP] 'Automovil','02', 2019, 5000, 100, 6077,
	'<partidas>
	<partida><idObjeto>7</idObjeto><idTipoObjeto>71</idTipoObjeto><idPartida>1</idPartida><costoInicial>2000</costoInicial></partida>
	<partida><idObjeto>13</idObjeto><idTipoObjeto>80</idTipoObjeto><idPartida>1</idPartida><costoInicial>null</costoInicial></partida>
	<partida><idObjeto>7</idObjeto><idTipoObjeto>71</idTipoObjeto><idPartida>2</idPartida><costoInicial>3000</costoInicial></partida>
	<partida><idObjeto>13</idObjeto><idTipoObjeto>80</idTipoObjeto><idPartida>2</idPartida><costoInicial>null</costoInicial></partida>
	</partidas>',
	 6077,
	 @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[INS_GESTORIA_SP] 

	@idClase				VARCHAR(10),
	@idEstado				VARCHAR(2),
	@anoFiscal				INT,
	@subTotal				FLOAT,
	@otrosGastos			FLOAT,
	@idResponsable			INT,
	@xmlPartidas			XML,
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	DECLARE @idGestoria		INT

	DECLARE @tbl_propiedades AS TABLE(
        _row                    INT IDENTITY(1,1),
		idObjeto				INT,
		idTipoObjeto			INT,
		idPartida				INT
    )

	INSERT INTO @tbl_propiedades
    SELECT
		ParamValues.col.value('idObjeto[1]','int'),
		ParamValues.col.value('idTipoObjeto[1]','int'),
		ParamValues.col.value('idPartida[1]','int')
        FROM @xmlPartidas.nodes('partidas/partida') AS ParamValues(col)


	INSERT INTO gestoria.Gestoria
	SELECT 
	@idClase,				
	@idEstado,				
	@anoFiscal,
	GETDATE(),				
	@subTotal,				
	@otrosGastos,
	@subTotal + @otrosGastos, 			
	@idResponsable,			
	'GUARDADA',			
	@idUsuario,
	1

	SET @idGestoria = @@IDENTITY

	DECLARE @CONT INT = 1

	WHILE(SELECT COUNT(*) FROM @tbl_propiedades) >= @CONT
		BEGIN
			INSERT INTO gestoria.GestoriaDetalle
			SELECT
			@idClase,
			@idGestoria,
			idPartida,
			idTipoObjeto,
			idObjeto,
			@idUsuario
			FROM @tbl_propiedades
			WHERE _row = @CONT

			SET @CONT = @CONT + 1 
		END

END
go

