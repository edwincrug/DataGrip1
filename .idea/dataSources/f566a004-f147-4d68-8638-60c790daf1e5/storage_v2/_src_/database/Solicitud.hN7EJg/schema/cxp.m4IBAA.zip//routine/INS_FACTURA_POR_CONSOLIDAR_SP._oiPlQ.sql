
--use solicitud
-- =============================================
-- Author: Adolfo Martinez
-- Create date: 08/04/2020
-- Description:	Hace insercion a para una fatura ficticia cxp.
-- EXEC [cxp].[INS_FACTURA_POR_CONSOLIDAR_SP] 421, 'Servicio', 'Automovil','TPC1208066U6',115,'00001-DEMO', 6119
-- =============================================
CREATE PROCEDURE [cxp].[INS_FACTURA_POR_CONSOLIDAR_SP]
@idSolicitud INT,
@idTipoSolicitud VARCHAR(10),
@idClase VARCHAR(10),
@rfcEmpresa	VARCHAR(13),
@idCliente INT,
@numeroContrato	VARCHAR(50),
@idUsuario INT,
@err VARCHAR(8000) = '' OUTPUT	
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
		DECLARE	@ote_indent NUMERIC(18,0)
		DECLARE @txDatos TABLE(id INT IDENTITY(1,1),idCotizacion INT,numeroCotizacion VARCHAR(50))
		DECLARE @v_idCotizacion	INT,@v_numeroCotizacion	VARCHAR(50),@v_idd	INT, @v_idFactura INT
		DECLARE @v_idObjeto INT, 
				@v_idTipoObjeto INT,
				@V_uuid NVARCHAR(100)


		SELECT  
			@v_idObjeto=idObjeto,
			@v_idTipoObjeto=idTipoObjeto
		FROM solicitud.SolicitudObjeto 
		WHERE idSolicitud=@idSolicitud 
		AND	idClase=@idClase 
		AND	rfcEmpresa=@rfcEmpresa 
		AND	idCliente=@idCliente
		AND numeroContrato=@numeroContrato
		AND idTipoSolicitud=@idTipoSolicitud


				INSERT INTO @txDatos(idCotizacion,numeroCotizacion)
				SELECT DISTINCT SC.idCotizacion,SC.numeroCotizacion 
				FROM solicitud.solicitud.SolicitudCotizacion SC
				JOIN solicitud.Sel_totales_cotizacion_vw vw ON SC.idCotizacion = vw.idCotizacion
				LEFT JOIN [cxp].[SolicitudCotizacionFactura] SFC ON SFC.idSolicitud = SC.idSolicitud AND  SFC.idCotizacion = SC.idCotizacion
				WHERE sc.idSolicitud=@idSolicitud
				AND sc.idTipoSolicitud=@idTipoSolicitud
				AND sc.idClase=@idClase
				AND sc.rfcEmpresa=@rfcEmpresa
				AND sc.idCliente=@idCliente
				AND sc.numeroContrato=@numeroContrato
				AND SFC.idCotizacion IS NULL

				WHILE EXISTS (SELECT 1 FROM @txDatos)
					BEGIN
						SELECT TOP 1 @v_idd=id,@v_idCotizacion=idCotizacion,@v_numeroCotizacion=numeroCotizacion FROM @txDatos
						PRINT '************************************************************************************************************************'
						PRINT 'Insertando idCotizacion:'+cast(@v_idCotizacion as varchar) +' numeroCotizacion:'+ @v_numeroCotizacion +' en tabla [cxc].[facturaPorConsolidar]'

						--SELECT * FROM [cxp].[facturaPorConsolidar]
						IF EXISTS(SELECT SC.idCotizacion,SC.numeroCotizacion 
						FROM solicitud.solicitud.SolicitudCotizacion SC
						JOIN solicitud.Sel_totales_cotizacion_vw vw ON SC.idCotizacion = vw.idCotizacion
						LEFT JOIN [cxp].[SolicitudCotizacionFacturaPorConsolidar] SFC ON SFC.idSolicitud = SC.idSolicitud AND  SFC.idCotizacion = @v_idCotizacion--SC.idCotizacion
						WHERE sc.idSolicitud=@idSolicitud
						AND sc.idTipoSolicitud=@idTipoSolicitud
						AND sc.idClase=@idClase
						AND sc.rfcEmpresa=@rfcEmpresa
						AND sc.idCliente=@idCliente
						AND sc.numeroContrato=@numeroContrato
						AND SFC.idCotizacion IS NULL)
							BEGIN
								SET @V_uuid = newid() 
								INSERT INTO [cxp].[facturaPorConsolidar](uuid,serie,folio,fechaFactura,rfcEmisor,rfcReceptor,subtotal,descuento,iva,total,saldo,idUsuario,xml,idDocumentoXml,idDocumentoPdf)											
								SELECT DISTINCT @V_uuid,'NA','',GETDATE(),sc.rfcProveedor,sc.rfcEmpresa,vw.subTotalCosto,NULL,vw.IVACosto,vw.totalCosto,vw.totalCosto,@idUsuario,'',0,0
								FROM solicitud.solicitud.Solicitud s
								JOIN solicitud.SolicitudCotizacion sc ON sc.idSolicitud = s.idSolicitud
								JOIN solicitud.Sel_totales_cotizacion_vw vw ON vw.idSolicitud = sc.idSolicitud and vw.idCotizacion = sc.idCotizacion
								WHERE sc.idSolicitud=@idSolicitud
									AND sc.idTipoSolicitud=@idTipoSolicitud
									AND sc.idClase=@idClase
									AND sc.rfcEmpresa=@rfcEmpresa
									AND sc.idCliente=@idCliente
									AND sc.numeroContrato=@numeroContrato
									AND sc.numeroCotizacion=@v_numeroCotizacion
									AND sc.idCotizacion=@v_idCotizacion

								--SELECT * FROM [cxp].[SolicitudCotizacionFacturaPorConsolidar]
								INSERT INTO [cxp].[SolicitudCotizacionFacturaPorConsolidar](idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,uuid)
								SELECT DISTINCT sc.idCotizacion,sc.idSolicitud,sc.idTipoSolicitud,sc.idClase,sc.rfcEmpresa,sc.idCliente,sc.numeroContrato,sc.idProveedorEntidad,sc.rfcProveedor,@V_uuid
								FROM solicitud.solicitud.Solicitud s
								JOIN solicitud.SolicitudCotizacion sc ON sc.idSolicitud = s.idSolicitud
								JOIN solicitud.Sel_totales_cotizacion_vw vw ON vw.idSolicitud = sc.idSolicitud and vw.idCotizacion = sc.idCotizacion
								WHERE sc.idSolicitud=@idSolicitud
									AND sc.idTipoSolicitud=@idTipoSolicitud
									AND sc.idClase=@idClase
									AND sc.rfcEmpresa=@rfcEmpresa
									AND sc.idCliente=@idCliente
									AND sc.numeroContrato=@numeroContrato
									AND sc.numeroCotizacion=@v_numeroCotizacion
									AND sc.idCotizacion=@v_idCotizacion
						
								--SELECT * FROM [cxp].[SolicitudCotizacionFacturaDetallePorConsolidar]
								INSERT INTO [cxp].[SolicitudCotizacionFacturaDetallePorConsolidar](idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,uuid,idObjeto,idTipoObjeto,idPartida,montoAbonado,fechaAbono,idUsuario)
								SELECT DISTINCT sc.idCotizacion,s.idSolicitud,s.idTipoSolicitud,s.idClase,s.rfcEmpresa,s.idCliente,s.numeroContrato,vw.idproveedorEntidad,vw.rfcProveedor,@V_uuid,@v_idObjeto,@v_idTipoObjeto,vw.idPartida,vw.costo,GETDATE(),@idUsuario
								FROM solicitud.solicitud.Solicitud s
								JOIN solicitud.SolicitudCotizacion sc ON sc.idSolicitud = s.idSolicitud
								--JOIN solicitud.Sel_totales_cotizacion_vw vwC ON vwC.idSolicitud = sc.idSolicitud and vwC.idCotizacion = sc.idCotizacion
								JOIN solicitud.Sel_totales_partidas_vw vw ON vw.idSolicitud = sc.idSolicitud and vw.idCotizacion = sc.idCotizacion AND idEstatusCotizacionPartida='APROBADA'
								WHERE sc.idSolicitud=@idSolicitud
									AND sc.idTipoSolicitud=@idTipoSolicitud
									AND sc.idClase=@idClase
									AND sc.rfcEmpresa=@rfcEmpresa
									AND sc.idCliente=@idCliente
									AND sc.numeroContrato=@numeroContrato
									AND sc.numeroCotizacion=@v_numeroCotizacion
									AND sc.idCotizacion=@v_idCotizacion
							END

						DELETE FROM @txDatos WHERE ID=@v_idd
					END
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al insertar en BPRO'
	END CATCH
END


go

