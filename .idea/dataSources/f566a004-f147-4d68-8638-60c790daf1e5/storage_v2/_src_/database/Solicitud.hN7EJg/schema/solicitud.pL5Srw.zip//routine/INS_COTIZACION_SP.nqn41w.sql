-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Agregar nueva solicitud en el paso de nueva con taller>
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	25/09/2020	JLuis Lozada	se agrego al insert de la tabla [SolicitudCotizacionPartidaDescuento] porcentajeDescuentoCosto,descuentoCosto

	*- Testing...
	EXEC [solicitud].[INS_COTIZACION_SP] 315, 'Servicio', 'Automovil', 'ASE0508051B6', 92, '0001', 147, 'DAC960820HV8', '<partidas><partida><idPartida>32068</idPartida><cantidad>1</cantidad><costo>50</costo><venta>55</venta></partida></partidas>',NULL, 2,6077
*/
-- =============================================
CREATE PROCEDURE [solicitud].[INS_COTIZACION_SP]
(
    @idSolicitud		    INT
    ,@idTipoSolicitud	    VARCHAR(10)
    ,@idClase			    VARCHAR(10)
    ,@rfcEmpresa			VARCHAR(13)
    ,@idCliente			    INT
    ,@numeroContrato		VARCHAR(50)
    ,@idObjeto				INT
	,@idTipoObjeto			INT
    ,@idProveedorEntidad    INT
    ,@rfcProveedor          VARCHAR(13)
    ,@partidas              XML
	,@idUsuario			    INT
)
AS
DECLARE
@numeroCotizacion           VARCHAR(30) = NULL
,@idCotizacion              INT

BEGIN

	DECLARE @manejoDescuentoVenta INT, @porcentajeDescuentoVenta FLOAT
	SELECT @manejoDescuentoVenta=manejoDescuentoVenta, @porcentajeDescuentoVenta=porcentajeDescuentoVenta 
	FROM [Cliente].Cliente.Contrato
	WHERE rfcEmpresa=@rfcEmpresa AND idCliente=@idCliente AND numeroContrato=@numeroContrato

    DECLARE @partidaVT as TABLE(
        [idPartida]                 INT
        , [idProveedorEntidad]      INT
        , [idObjeto]                INT
        , [idTipoObjeto]            INT
        , [rfcProveedor]            VARCHAR(13)
        , [cantidad]                INT
        , [costo]                   float
        , [venta]                   float);

    SELECT @numeroCotizacion = [solicitud].[SEL_NUMEROCOTIZACION_FN](
        @idSolicitud
        , @rfcEmpresa
        , @idTipoSolicitud
        , @idClase
        , @idCliente
        , @numeroContrato)

    INSERT INTO @partidaVT(
        [idPartida]
        , [cantidad]
        , [costo]
        , [venta]) 
    SELECT 
        partidaParametro.C.value('idPartida[1]', 'INT')
        , partidaParametro.C.value('cantidad[1]', 'INT')
        , partidaParametro.C.value('costo[1]', 'float')
        , partidaParametro.C.value('venta[1]', 'float')
    FROM @partidas.nodes('partidas/partida') as partidaParametro(C)
    INSERT INTO [solicitud].[SolicitudCotizacion] (
        [idSolicitud]
        ,[idTipoSolicitud]
        ,[idClase]
        ,[rfcEmpresa]
        ,[idCliente]
        ,[numeroContrato]
        ,[idProveedorEntidad]
        ,[rfcProveedor]
        ,[numeroCotizacion]
        ,[fechaAlta]
        ,[idUsuario]
		,[idEstatusCotizacion]
    ) VALUES (
            @idSolicitud
        ,@idTipoSolicitud
        ,@idClase
        ,@rfcEmpresa
        ,@idCliente
        ,@numeroContrato
        ,@idProveedorEntidad
        ,@rfcProveedor 
        ,@numeroCotizacion
        ,GETDATE()
        ,@idUsuario
		,'ENESPERA'
    )
    SET @idCotizacion = @@IDENTITY
    
    INSERT INTO [solicitud].[SolicitudCotizacionPartida] (
        [idCotizacion]
        ,[idSolicitud]
        ,[idTipoSolicitud]
        ,[idClase]
        ,[rfcEmpresa]
        ,[numeroContrato]
        ,[idCliente]
        ,[rfcProveedor]
        ,[idProveedorEntidad]
        ,[idObjeto]
        ,[idTipoObjeto]
        ,[idPartida]
        ,[cantidad]
        ,[costo]
        ,[venta]
        ,[idEstatusCotizacionPartida]
        ,[fechaEstatus]
        ,[idUsuario]
    ) 
    SELECT
        @idCotizacion
        ,@idSolicitud
        ,@idTipoSolicitud
        ,@idClase
        ,@rfcEmpresa
        ,@numeroContrato
        ,@idCliente
        ,@rfcProveedor
        ,@idProveedorEntidad
        ,@idObjeto
        ,@idTipoObjeto
        ,[idPartida]
        ,[cantidad]
        ,[costo]
        ,[venta]
        ,'ENESPERA'
        ,GETDATE()
        ,@idUsuario
    FROM @partidaVT

	IF(@manejoDescuentoVenta = 1)
		BEGIN
			INSERT INTO [solicitud].[SolicitudCotizacionPartidaDescuento] (
				[idCotizacion]
				,[idSolicitud]
				,[idTipoSolicitud]
				,[idClase]
				,[rfcEmpresa]
				,[numeroContrato]
				,[idCliente]
				,[rfcProveedor]
				,[idProveedorEntidad]
				,[idObjeto]
				,[idTipoObjeto]
				,[idPartida]
				,[porcentajeDescuentoVenta]
				,[descuentoVenta]
				,[porcentajeDescuentoCosto]
				,[descuentoCosto]
				,[fecha]
				,[idUsuario]
			) 
			SELECT
				@idCotizacion
				,@idSolicitud
				,@idTipoSolicitud
				,@idClase
				,@rfcEmpresa
				,@numeroContrato
				,@idCliente
				,@rfcProveedor
				,@idProveedorEntidad
				,@idObjeto
				,@idTipoObjeto
				,[idPartida]
				,@porcentajeDescuentoVenta
				,(([venta] * @porcentajeDescuentoVenta) / 100)
				,0
				,0
				,GETDATE()
				,@idUsuario
			FROM @partidaVT
		END

	INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
	(fechaAlta,idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,idEstatusCotizacion,idUsuario)
	VALUES 
	(GETDATE(),@idCotizacion,@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idProveedorEntidad,@rfcProveedor ,'ENESPERA',@idUsuario)


END
go

