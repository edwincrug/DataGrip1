-- =============================================
-- Author:		Martin Pacheco
-- Create date: 30/05/2019
-- Description:	Crea una nueva solicitud.
-- =============================================
/*
	Fecha		Autor	Descripción 
	
	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[INS_SOLICITUD_SP]
	'ASE0508051B6',
	171,
	'0001',
	'',
	'',
	13948,
	559,
	'Automovil',
	'Desinstala',
	'2019-07-06 00:00:00.000',
	'ACTIVA',
	'<Propiedades><propiedad><idPropiedad>1</idPropiedad><valores><valor>1</valor></valores></propiedad></Propiedades>',
	2271,
	'<partidas><partida><idPartida>799345</idPartida><cantidad>1</cantidad><costoInicial>250</costoInicial><ventaInicial>0</ventaInicial></partida></partidas>',
	'"adicionales"',
	null
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [solicitud].[INS_SOLICITUD_SP]
	@rfcEmpresa				VARCHAR(13) = '',
	@idCliente				INT = 0,
	@numeroContrato			VARCHAR(50) = '',
	@idCentroCosto			INT,
	@idCentroCostoFolio		VARCHAR(200) = '',
	@idObjeto				INT = 0,
	@idTipoObjeto			INT = 0,
    @idClase				VARCHAR(10) = '',
	@idTipoSolicitud		VARCHAR(50) = '',
	@fecha					DATETIME = null,
	@idEstatusSolicitud		VARCHAR(50) = '',
	@Propiedades			XML,
	@PropiedadesTipoSolicitud	XML = NULL,
	@idUsuario				INT = 0,
	@partidas				XML,
	@comentarios			VARCHAR(MAX) = '',
	@err					VARCHAR(8000) OUTPUT	
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;


    DECLARE
		@VI_One				INT = 1,
		@VI_Zero			INT = 0,
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en el stored: [INS_SOLICITUD_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_ResultCount		INT = 0,
		@VI_IdSolicitud		INT = NULL,
		@VC_NOSOLICITUD		VARCHAR(20) = NULL,
		@VD_ExpiraContrato	DATE = NULL,
		@ERR_MENSAJE		VARCHAR(100) = '',
		@xmlPadre			XML
	
	DECLARE @VT_Table TABLE (
		[Index]			    INT IDENTITY(1,1),
		[idPartida]			INT,
		[cantidad]			INT,
		[costoInicial]		float, 
		[ventaInicial]		float
	);

	DECLARE @VT_Propiedades TABLE (
		[Index]			    INT IDENTITY(1,1),
		[idPropiedadClase]	INT,
		[Valor]				XML
	);

	DECLARE @VT_PropiedadesSolicitud TABLE (
		[Index]			    INT IDENTITY(1,1),
		[idPropiedadTipoSolicitud]	INT,
		[Valor]				XML
	);

	INSERT INTO @VT_Table
		SELECT
			I.N.value('(idPartida)[1]',	'INT'),
			I.N.value('(cantidad)[1]',	'INT'),
			I.N.value('(costoInicial)[1]',	'float'),
			I.N.value('(ventaInicial)[1]',	'float')
		FROM @partidas.nodes('/partidas/partida') I(N);

	INSERT INTO @VT_Propiedades
		SELECT
			I.N.value('(idPropiedad)[1]',	'INT'),
			I.N.query('valores/.')
		FROM @Propiedades.nodes('/Propiedades/propiedad') I(N);

	INSERT INTO @VT_PropiedadesSolicitud
		SELECT
			I.N.value('(idPropiedad)[1]',	'INT'),
			I.N.query('valores/.')
		FROM @PropiedadesTipoSolicitud.nodes('/Propiedades/propiedad') I(N);

	DECLARE @pCount INT = 1, @pMax INT = (SELECT count([Index]) FROM @VT_Propiedades);
	DECLARE @count INT = 1, @max INT = (SELECT count([Index]) FROM @VT_Table);
	DECLARE @sCount INT = 1, @sMax INT = (SELECT COUNT([Index]) FROM @VT_PropiedadesSolicitud);

	
	
		BEGIN TRY 
			BEGIN TRANSACTION INS_SOLICITUD_NUEVO_SP	

			SELECT @VC_NOSOLICITUD = (SELECT [solicitud].[SEL_NUMEROSOLICITUD_FN](@rfcEmpresa, @idCliente, @numeroContrato));
			SELECT @VD_ExpiraContrato = (
				SELECT 
					COALESCE([fechaFin], null) 
				FROM [Cliente].[cliente].[Contrato]
				WHERE 
					[rfcEmpresa] = @rfcEmpresa AND
					[idCliente] = @idCliente AND
					[numeroContrato] = @numeroContrato
			)
			IF (@VD_ExpiraContrato >= GETDATE())
				BEGIN
					INSERT INTO [solicitud].[Solicitud] (
						 [rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idCentroCosto]
						,[folio]
						,[idTipoSolicitud]
						,[idClase]
						,[fechaCreacion]
						,[fechaCita]
						,[numero]
						,[comentarios]
						,[idEstatusSolicitud]
						,[idUsuario]
						,[esMultiple]
					) VALUES (
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idCentroCosto,
						@idCentroCostoFolio,
						@idTipoSolicitud,
						@idClase,
						GETDATE(),
						@fecha,
						@VC_NOSOLICITUD,
						@comentarios,
						'ACTIVA',
						@idUsuario,
						0
					)
					SET @VI_IdSolicitud = SCOPE_IDENTITY()
					IF(@VI_IdSolicitud IS NOT NULL)
						BEGIN
							UPDATE [solicitud].[ContratoConsecutivo]
							SET [consecutivo] = (
								SELECT 
									CAST([consecutivo] AS INT) + 1
								FROM [solicitud].[ContratoConsecutivo]
								WHERE 
									[rfcEmpresa] = @rfcEmpresa AND
									[idCliente] = @idCliente AND
									[numeroContrato] = @numeroContrato
							)
							WHERE 
								[rfcEmpresa] = @rfcEmpresa AND
								[idCliente] = @idCliente AND
								[numeroContrato] = @numeroContrato 
						END

					INSERT INTO [solicitud].[SolicitudObjeto](
						 [idSolicitud]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idTipoSolicitud]
						,[idObjeto]
						,[idTipoObjeto]
						,[idClase]
						,[numeroOrden]
						,[fechaAlta]
						,[idUsuario]
					) VALUES (
						@VI_IdSolicitud,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idTipoSolicitud,
						@idObjeto,
						@idTipoObjeto,
						@idClase,
						(@VC_NOSOLICITUD +'-'+ CONVERT(VARCHAR(20), @idObjeto)),
						@fecha,
						@idUsuario
					)
					WHILE (@count <= @max)
						BEGIN
							INSERT INTO [solicitud].[SolicitudPartida] (
								 [idSolicitud]
								,[idTipoSolicitud]
								,[idClase]
								,[rfcEmpresa]
								,[idCliente]
								,[numeroContrato]
								,[idObjeto]
								,[idTipoObjeto]
								,[idPartida]
								,[cantidad]
								,[costoInicial]
								,[ventaInicial]
								,[idEstatusSolicitudPartida]
								,[idUsuario]
							) VALUES (
								 @VI_IdSolicitud
								,@idTipoSolicitud
								,@idClase
								,@rfcEmpresa
								,@idCliente
								,@numeroContrato
								,@idObjeto
								,@idTipoObjeto
								,(SELECT [idPartida] FROM @VT_Table WHERE [Index] = @count)
								,(SELECT [cantidad] FROM @VT_Table WHERE [Index] = @count)
								,(SELECT [costoInicial] FROM @VT_Table WHERE [Index] = @count)
								,(SELECT [ventaInicial] FROM @VT_Table WHERE [Index] = @count)
								,'ENESPERA'
								, @idUsuario
							)
							SET @count = @count + 1;
						END
					WHILE (@pCount <= @pMax)
						BEGIN
							SET @xmlPadre = (SELECT [Valor] FROM @VT_Propiedades WHERE [Index] = @pCount)
							INSERT INTO [solicitud].[SolicitudPropiedadClase] (
								 [idSolicitud]
								,[idTipoSolicitud]
								,[idClase]
								,[rfcEmpresa]
								,[idCliente]
								,[numeroContrato]
								,[idPropiedadClase]
								,[valor]
								,[fechaCaducidad]
								,[idUsuario]
							) VALUES (
								@VI_IdSolicitud,
								@idTipoSolicitud,
								@idClase,
								@rfcEmpresa,
								@idCliente,
								@numeroContrato,
								case when 
									(
										select idTipoValor from solicitud.PropiedadClase where idPropiedadClase = 
										(
											SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount
										)
									)!='Unico' 
									THEN 
										(SELECT	I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))									
									ELSE
										(SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount)
								END,
								case when 
									(
										select idTipoValor from solicitud.PropiedadClase where idPropiedadClase = 
										(
											SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount
										)
									)!='Unico' 
									then ''
									ELSE
									(SELECT I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))
								END,
								NULL,
								@idUsuario
							)
							SET @pCount = @pCount + 1 
						END
					WHILE (@sCount <= @sMax)
						BEGIN
							SET @xmlPadre = (SELECT [Valor] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount)
							INSERT INTO [solicitud].[SolicitudPropiedadTipoSolicitud] (
								[idSolicitud]
							   ,[idTipoSolicitud]
							   ,[idClase]
							   ,[rfcEmpresa]
							   ,[idCliente]
							   ,[numeroContrato]
							   ,[idPropiedadTipoSolicitud]
							   ,[valor]
							   ,[fechaCaducidad]
							   ,[idUsuario]
							) VALUES (
								@VI_IdSolicitud,
								@idTipoSolicitud,
								@idClase,
								@rfcEmpresa,
								@idCliente,
								@numeroContrato,
								case when 
									(
										select idTipoValor from solicitud.PropiedadTipoSolicitud where idPropiedadTipoSolicitud = 
										(
											SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount
										)
									)!='Unico' 
									THEN 
										(SELECT	I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))									
									ELSE
										(SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount)
								END,
								case when 
									(
										select idTipoValor from solicitud.PropiedadTipoSolicitud where idPropiedadTipoSolicitud = 
										(
											SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount
										)
									)!='Unico' 
									then ''
									ELSE
									(SELECT I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))
								END,
								NULL,
								@idUsuario
							)
							SET @sCount = @sCount + 1 
						END
					INSERT INTO [fase].[SolicitudEstatusPaso] (
						  [idSolicitud]
						 ,[rfcEmpresa]
						 ,[idCliente]
						 ,[numeroContrato]
						 ,[idPaso]
						 ,[idFase]
						 ,[idClase]
						 ,[idTipoSolicitud]
						 ,[fechaIngreso]
						 ,[idEstatus]
						 ,[idUsuarioIngreso]
					) VALUES (
						@VI_IdSolicitud
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,(SELECT 
						top 1	[idPaso] 
						from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
						,(SELECT 
						top 1	idFase 
						from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
						,@idClase
						,@idTipoSolicitud
						,GETDATE()
						,1
						,@idUsuario
					)
				END
			ELSE 
				BEGIN
					SET @ERR_MENSAJE = 'El contrato ha expirado.'
				END
			COMMIT TRANSACTION INS_SOLICITUD_NUEVO_SP
		END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION INS_SOLICITUD_NUEVO_SP
				SET @VC_ErrorMessage = { 
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage
					) 
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
				SET @err = @VC_ErrorMessage;
			END
		END CATCH
		
		--set @err=@VI_IdSolicitud
		select 
			@VI_IdSolicitud idSolicitud, 
			@VC_NOSOLICITUD numeroSolicitud,
			con.idFileAvatar idLogoContrato,
			@ERR_MENSAJE AS error,
			(@VC_NOSOLICITUD +'-'+ CONVERT(VARCHAR(20), @idObjeto)) numeroOrden
		from Cliente.cliente.Contrato con
		where
			con.rfcEmpresa = @rfcEmpresa
			and con.idCliente = @idCliente
			and con.numeroContrato = @numeroContrato


		
    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END


--USE [Solicitud]
go

