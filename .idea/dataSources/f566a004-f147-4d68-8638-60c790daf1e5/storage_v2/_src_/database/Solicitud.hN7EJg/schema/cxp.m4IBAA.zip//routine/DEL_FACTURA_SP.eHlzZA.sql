-- =============================================
-- Author:			<Edgar Mendoza>
-- Create date: 	<14/07/2020>
-- Description:	    <Elimina factura>
-- =============================================
 /*
 EXEC [cxp].[DEL_FACTURA_SP]
 '<Ids><uuid>018AA99F-514B-444E-87E1-4AED27ECBB51</uuid><uuid>0A2C988B-A62D-42E2-BF25-D053F9A6CCB8</uuid><uuid>0CAD01CC-4F5F-4C3D-8EEF-17A77FCFC0AC</uuid></Ids>,'
 , 2326
 ,''
 */
-- =============================================
	CREATE PROCEDURE [cxp].[DEL_FACTURA_SP]
(
	@data					XML
	,@idUsuario				INT
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS


BEGIN

	DECLARE @tbl_uuid AS TABLE(
	uuid			VARCHAR(250)
	)


	INSERT INTO @tbl_uuid
	SELECT
	I.N.value('.','VARCHAR(250)')
	FROM @data.nodes('/Ids/uuid') AS I(N)


	IF EXISTS(select 1 from solicitud.SEL_CXC_VW CXC
					INNER JOIN [cxp].SolicitudCotizacionFactura SC ON SC.idSolicitud = CXC.idSolicitud 
					 WHERE SC.uuid IN (SELECT uuid from @tbl_uuid)
			)
	BEGIN
		SET @err = 'La factura ya esta provisionada, no se puede eliminar'
	END

	ELSE

	BEGIN
	DELETE FROM [cxp].[FacturaImpuesto]
	WHERE uuidFactura in (SELECT uuid FROM @tbl_uuid)

	DELETE FROM [cxp].[SolicitudCotizacionFacturaDetalle]
	WHERE uuid in (SELECT uuid FROM @tbl_uuid)
	
	DELETE FROM [cxp].[SolicitudCotizacionFactura]
	WHERE uuid in (SELECT uuid FROM @tbl_uuid)
	
	DELETE FROM [cxp].[Factura]
	WHERE uuid in (SELECT uuid FROM @tbl_uuid)

	END

END

go

