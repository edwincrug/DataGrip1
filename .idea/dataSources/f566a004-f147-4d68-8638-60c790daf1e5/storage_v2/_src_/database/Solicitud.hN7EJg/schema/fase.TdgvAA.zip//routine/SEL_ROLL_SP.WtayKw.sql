
-- =============================================
-- Author:		<DVR>
-- Create date: <14/12/2020>
-- Description:	<consulta el catalogo de rolles>
/*
	EXEC [fase].[SEL_ROLL_SP] 6282,NULL
*/
-- =============================================
CREATE PROCEDURE [fase].[SEL_ROLL_SP]
@idUsuario INT,
@err		VARCHAR(500)OUTPUT  
AS
BEGIN

		SELECT [Id] AS value
			  ,[Nombre] AS text
		  FROM [Seguridad].[Catalogo].[Rol] where AplicacionesId = 9
END

go

