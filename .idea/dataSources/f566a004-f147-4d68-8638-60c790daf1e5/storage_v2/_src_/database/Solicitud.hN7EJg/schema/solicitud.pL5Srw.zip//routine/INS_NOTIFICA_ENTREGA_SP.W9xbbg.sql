-- =============================================
-- Author:			<Adolfo Martinez>
-- Create date: 	<20/04/2020>
-- Description:	    <Cancelar Solicitud>
-- =============================================
-- EXEC [solicitud].[INS_NOTIFICA_ENTREGA_SP] 
-- =============================================
CREATE PROCEDURE [solicitud].[INS_NOTIFICA_ENTREGA_SP]
(
     @idSolicitud       INT
	,@idTipoSolicitud   VARCHAR(10)
	,@idClase			VARCHAR(10)
	,@rfcEmpresa        VARCHAR(13)
	,@idCliente         INT
	,@numeroContrato    VARCHAR(50)
	,@idUsuario			INT
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
DECLARE @entrega				INT=0
BEGIN
	BEGIN TRAN Entrega
    BEGIN TRY

		INSERT [solicitud].[NotificacionEntrega](idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,fecha,idUsuario)
		VALUES(@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,GETDATE(),@idUsuario)

		SELECT 'Se ha enviado la notificación.' msg

		COMMIT TRAN Entrega			
    END TRY
    BEGIN CATCH
        ROLLBACK TRAN Entrega
        SET @err = 'Ocurrio un error al guardar la notificación de entrega.'
    END CATCH
END
go

