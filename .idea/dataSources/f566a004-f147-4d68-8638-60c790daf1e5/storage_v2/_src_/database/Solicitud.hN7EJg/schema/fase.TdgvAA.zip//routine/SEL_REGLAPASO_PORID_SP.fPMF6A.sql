
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 05-09-2019
-- Description: Valores de regla paso
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	EXEC [fase].[SEL_REGLAPASO_PORID_SP]  
	@idReglaPaso = 69
	,@idUsuario = 6077
	,@err = ''

*/
-- =============================================
CREATE  PROCEDURE [fase].[SEL_REGLAPASO_PORID_SP] 
	@idReglaPaso				INT
	,@idUsuario					INT
	,@err						varchar(500)OUTPUT
AS


BEGIN


/****************************************************VALORES REGLA PASO **********************************/

	SELECT DISTINCT
		RP.idReglaPaso
		--,RP.idPaso
		--,RP.idFase
		,RP.idClase
		,RP.idTipoSolicitud
		,RP.rfcEmpresa
		,RP.idCliente
		,RP.numeroContrato
		--,RP.orden
		,RP.aplicaReglaRol
		,RP.aplicaReglaMonto
		,RP.aplicaReglaUsuario
		,RP.aplicaReglaPartida
		,RP.aplicaReglaObjeto
		,RP.idNivel
		,RP.descripcion
		,RPR.RolId
		,RPU.UsersId
		,RPP.idPartida 
		,RPP.idTipoObjeto as idTipoObjetoPartida
		,RPM.idTipoMonto
		,RPM.montoMinimo
		,RPM.montoMaximo
		,RPO.idObjeto
		,RPO.idTipoObjeto as idTipoObjeto
	FROM [fase].[ReglaPaso] RP
	LEFT JOIN [fase].[ReglaPasoRol] RPR ON RPR.idReglaPaso = RP.idReglaPaso AND RPR.activo = 1
	LEFT JOIN [fase].[ReglaPasoUsuario] RPU ON RPU.idReglaPaso = RP.idReglaPaso AND RPU.activo = 1
	LEFT JOIN [fase].[ReglaPasoPartida] RPP ON RPP.idReglaPaso = RP.idReglaPaso AND RPP.activo = 1
	LEFT JOIN [fase].[ReglaPasoMonto] RPM ON RPM.idReglaPaso = RP.idReglaPaso AND RPM.activo = 1
	LEFT JOIN [fase].[ReglaPasoObjeto] RPO ON RPO.idReglaPaso = RP.idReglaPaso AND RPO.activo = 1
	WHERE RP.idReglaPaso = @idReglaPaso
	AND RP.activo = 1



	
END

go

