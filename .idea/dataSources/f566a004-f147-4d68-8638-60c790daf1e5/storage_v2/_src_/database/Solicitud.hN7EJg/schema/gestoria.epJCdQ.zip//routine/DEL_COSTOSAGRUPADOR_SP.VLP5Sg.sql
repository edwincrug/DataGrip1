
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 30-05-2019
-- Description: Elimina agrupador
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[DEL_COSTOSAGRUPADOR_SP]  
	'<Ids>
		<idAgrupador>5</idAgrupador>
	</Ids>'
	, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[DEL_COSTOSAGRUPADOR_SP] 
	@data					XML,
	@idUsuario				INT,
	@err					nvarchar(500)OUTPUT
AS


BEGIN
    DECLARE @tbl_propiedades AS TABLE(
        idAgrupador			INT
    )


    INSERT INTO @tbl_propiedades
    SELECT
        I.N.value('.','int')
        FROM @data.nodes('/Ids/idAgrupador') AS I(N)

	UPDATE gestoria.CostoAgrupador SET activo = 0
	WHERE idCostoAgrupador in (SELECT idAgrupador 
							FROM @tbl_propiedades)
	
END
go

