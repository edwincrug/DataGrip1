-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<04/07/2019>
-- Description:	    <Quema el token>
-- =============================================
-- EXEC [token].[UPD_TOKEN_PASO_SP] 35, 'EEBCE8',13
-- =============================================
CREATE PROCEDURE [token].[UPD_TOKEN_PASO_SP]
(
    @idSolicitud        int
    ,@token             [varchar](6)
	,@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
DECLARE
@tipoPasoExistente          varchar(8)=NULL
,@idPasoExistente           varchar(50)=NULL
,@idTipoTokenExistente      int=0
,@idPaso                    varchar(50)=NULL
,@idTipoToken               int=0
,@idUsuarioUsa              int=0
,@idToken                   int=0

BEGIN
    --Valida existencias de la solicitud
    SELECT 
        @tipoPasoExistente = tipoPaso
        ,@idPasoExistente = idPaso
    FROM [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud) SF

    IF(@idPasoExistente IS NOT NULL)
    BEGIN

        SELECT 
            @idTipoToken = id 
        FROM token.tipoToken
        WHERE descripcion = @tipoPasoExistente

        SELECT 
            @idToken = TT.idToken
            ,@idPaso = TT.idPaso
            ,@idUsuarioUsa = TT.idUsuarioUsa
        FROM [Solicitud].[token].[Token] TT
        INNER JOIN [Solicitud].[token].[TokenSolicitud] TTS
            ON TT.idToken = TTS.idToken
        WHERE TTS.idSolicitud = @idSolicitud
            AND TT.token = @token
            AND TT.idTipoToken = @idTipoToken

        IF(@idPasoExistente = @idPaso)
        BEGIN
            PRINT 'La solicitud se dencuentra en el paso correcto.'
            IF(@idUsuarioUsa > 0)
            BEGIN
                PRINT 'El token ya fue utilizado.'
                SET @err = 'El token ya fue utilizado.'
                SELECT 0 Estatus
            END
            ELSE
            BEGIN
                PRINT 'El token esta listo para usarse.'
                UPDATE [Solicitud].[token].[Token]
                    SET fechaUso = GETDATE()
                    ,idUsuarioUsa = @idUsuario
                WHERE idToken = @idToken
                SELECT @idToken Estatus
            END
        END
        ELSE
        BEGIN
            PRINT 'El token no existe o la solicitud y el token estan en pasos diferentes.'
            SET @err = 'El token no existe o la solicitud y el token estan en pasos diferentes.'
            SELECT 0 Estatus
        END

    END
    ELSE
    BEGIN
        PRINT 'La solicitud no existe'
        SET @err = 'La solicitud no existe'
        SELECT 0 Estatus
    END
END
go

