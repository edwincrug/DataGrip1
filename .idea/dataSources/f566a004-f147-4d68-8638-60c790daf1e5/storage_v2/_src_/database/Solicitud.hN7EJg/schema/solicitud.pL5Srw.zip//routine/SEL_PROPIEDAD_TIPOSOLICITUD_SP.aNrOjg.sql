-- =============================================
-- Author:		Luis Martinez
-- Create date: 10/065/2020
-- Description:	.
/* Test:		
	declare @err varchar(500)
	exec [solicitud].[SEL_PROPIEDAD_TIPOSOLICITUD_SP] 'Automovil',null,6147, @err OUTPUT

*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_PROPIEDAD_TIPOSOLICITUD_SP] 
	@idClase			varchar(10),
	@idTipoSolicitud	varchar(10),
	@idUsuario			int = null,
	@err				varchar(500) OUTPUT
AS
BEGIN

DECLARE @propiedades AS TABLE(
								id				INT,
								idPadre			INT,
								valor			NVARCHAR(500),
								arreglo			NVARCHAR(500),
								idClase			NVARCHAR(500),
								idTipoValor		NVARCHAR(20),
								idTipoDato		NVARCHAR(20),
								propiedad		NVARCHAR(50),
								idPropiedad		INT,
								obligatorio		BIT,
								posicion		INT,
								orden			INT
							--	idTipoObjeto	INT,
								)

	INSERT INTO @propiedades
		SELECT
		  [idPropiedadTipoSolicitud] as id
		   ,ISNULL([idPadre], 0) AS idPadre
		   ,[valor]
		   ,'' as arreglo
		   ,[idClase]
		  ,[idTipoValor]
		  ,[idTipoDato]
		  ,'clase' propiedad
		  ,2 idPropiedad		  
		  ,[obligatorio]
		  ,[posicion]
		  ,[orden]
		  --,[idTipoSolicitud]
	/*
		idPropiedadClase	as id
		,ISNULL(idPadre,0)	 as idPadre
		,valor	
		,'' as arreglo
		,idClase
		,idTipoValor
		,idTipoDato
		,'clase' propiedad
		,2 idPropiedad
		,obligatorio
		,posicion
		,orden*/
	FROM [solicitud].[PropiedadTipoSolicitud]
	WHERE idClase = @idClase 
		AND idTipoSolicitud = @idTipoSolicitud
		AND	activo=1

	SELECT * FROM @propiedades
	ORDER BY idClase,posicion, orden asc

END


--USE [Solicitud]
go

