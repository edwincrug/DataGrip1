

-- =============================================
-- Author: Luis Martinez
-- Create date: 17-07-2020
-- Description: Obtener los documentos de una solicitud
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	
	--idSolicitud: 478,
--  idTipoSolicitud: 'Imagen',
--  idClase: 'Automovil',
--  rfcEmpresa: 'ASE0508051B6',
--  idCliente: 185,
--  numeroContrato: '43',
--  fileServer: 'http://189.204.141.199:5114',
--  idDocumento: 22013,
--  nombrePaso: 'Hoja de Trabajo'
	*- Testing...
	EXEC [solicitud].[SEL_DOCUMENTOSSOLICITUDOBJETO_SP]  478,'Imagen','Automovil','ASE0508051B6', 185, '43', 2, NULL;
*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_DOCUMENTOSSOLICITUDOBJETO_SP]
	@idSolicitud			INT,
	@idTipoSolicitud		varchar(20),
	@idClase				varchar(20),
	@rfcEmpresa				varchar(13),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	@idTipoObjeto			int,
	@idObjeto				int,
	@idUsuario				int,
	@err					varchar(500)OUTPUT
AS


BEGIN

	SELECT *
		
		into #prueba
	FROM
		(
		SELECT
			[idDocumentoClase]
		  , [idPaso]
		  , [idFase]
		  , [idClase]
		  , [idTipoSolicitud]
		  , '' as rfcEmpresa
		  , '' as idCliente
		  , '' as numeroContrato
		  , '' as idTipoObjeto
		  , '' as idObjeto
		  , [nombre]
		  , [idAgrupador]
		  , [tiposPermitidos]
		  , [obligatorio]
		  , [vigencia]
		  , [valor]
		  , [aplicaCosto]
		  , [orden]
		  , [idUsuario]
		  , [activo]
		  , [aplicaEstado]
		  , [aplicaComentario]
			FROM [Solicitud].[documento].[Paso]
			where idClase = @idClase
			AND idTipoSolicitud = @idTipoSolicitud
		UNION ALL
		SELECT
			[idDocumentoContrato]
		  , [idPaso]
		  , [idFase]
		  , [idClase]
		  , [idTipoSolicitud]
		  , [rfcEmpresa]
		  , [idCliente]
		  , [numeroContrato]
		  , '' as idTipoObjeto
		  , '' as idObjeto
		  , [nombre]
		  , [idAgrupador]
		  , [tiposPermitidos]
		  , [obligatorio]
		  , [vigencia]
		  , [valor]
		  , [aplicaCosto]
		  , [orden]
		  , [idUsuario]
		  , [activo]
		  , [aplicaEstado]
		  , [aplicaComentario]
			FROM [Solicitud].[documento].[PasoContrato]
			WHERE rfcEmpresa = @rfcEmpresa AND
				idCliente = @idCliente AND
				numeroContrato = @numeroContrato) T

	select COUNT(*) AS numeroDocumentos from #prueba

	SELECT *
	into #test
	FROM (	
		SELECT 
					[idDocumentoClase]
					, [idPaso]
					, [idFase]
					, [idClase]
					, [idCliente]
					, [numeroContrato]
					, [idTipoSolicitud]
					, [idSolicitud]
					, [rfcEmpresa]
					, [idTipoObjeto]
					, [idObjeto]
					, [version]
					, [idTipoDocumento]
					, [idFileServer]
					, [vigencia]
					, [valor]
					, [idUsuario]
					, [fecha]
					, [idCostoDocumentoClase]
					, [idEstado]
					, [comentario]
			FROM [Solicitud].[documento].[SolicitudObjetoPaso]
			WHERE [idSolicitud] = @idSolicitud
				AND [idTipoSolicitud] = @idTipoSolicitud
				AND [idClase] = @idClase
				AND [rfcEmpresa] = @rfcEmpresa
				AND [idCliente]= @idCliente
				AND [numeroContrato] = @numeroContrato
				AND [idTipoObjeto] = @idTipoObjeto
				AND [idObjeto] = @idObjeto

		UNION ALL
			SELECT [idDocumentoContrato]
					, [idPaso]
					, [idFase]
					, [idClase]
					, [idCliente]
					, [numeroContrato]
					, [idTipoSolicitud]
					, [idSolicitud]
					, [rfcEmpresa]
					, [idTipoObjeto]
					, [idObjeto]
					, [version]
					, [idTipoDocumento]
					, [idFileServer]
					, [vigencia]
					, [valor]
					, [idUsuario]
					, [fecha]
					, [idCostoDocumentoContrato]
					, [idEstado]
					, [comentario]
			FROM [Solicitud].[documento].[SolicitudPasoContrato]
			WHERE [idSolicitud] = @idSolicitud
				AND [idTipoSolicitud] = @idTipoSolicitud
				AND [idClase] = @idClase
				AND [rfcEmpresa] = @rfcEmpresa
				AND [idCliente]= @idCliente
				AND [numeroContrato] = @numeroContrato
				AND [idTipoObjeto] = @idTipoObjeto
				AND [idObjeto] = @idObjeto) A
	select * from #test

	
	select *
	into #final
	from(
	select 
	P.[idDocumentoClase],
	P.[idPaso],
	P.[idFase],
	P.[idClase],
	P.[idTipoSolicitud],
	P.[rfcEmpresa],
	P.[idCliente],
	P.[numeroContrato],
	P.[idTipoObjeto],
	P.[idObjeto],
	P.[nombre],
	P.[idAgrupador],
	P.[tiposPermitidos],
	P.[obligatorio],
	P.[vigencia],
	P.[valor],
	P.[aplicaCosto],
	P.[orden],
	P.[idUsuario],
	P.[activo],
	P.[aplicaEstado],
	P.[aplicaComentario],
	T.[idFileServer]
	from #prueba P
	left join #test T on T.idDocumentoClase = P.idDocumentoClase)C

	--select * from #final order by orden

	select * 
	into #todos
	from(
	select 
	TOD.[idDocumentoClase],
	TOD.[idPaso],
	TOD.[idFase],
	TOD.[idClase],
	TOD.[idTipoSolicitud],
	TOD.[rfcEmpresa],
	TOD.[idCliente],
	TOD.[numeroContrato],
	TOD.[idTipoObjeto],
	TOD.[idObjeto],
	TOD.[nombre],
	TOD.[idAgrupador],
	TOD.[tiposPermitidos],
	TOD.[obligatorio],
	TOD.[vigencia],
	TOD.[valor],
	TOD.[aplicaCosto],
	TOD.[orden],
	TOD.[idUsuario],
	TOD.[activo],
	TOD.[aplicaEstado],
	TOD.[aplicaComentario],
	TOD.[idFileServer]
	from #final TOD where TOD.nombre !='Hoja de Trabajo') D

	--select * from #todos

	select * 
	into #HojaRec
	from(
	select 
	HT.[idDocumentoClase],
	HT.[idPaso],
	HT.[idFase],
	HT.[idClase],
	HT.[idTipoSolicitud],
	HT.[rfcEmpresa],
	HT.[idCliente],
	HT.[numeroContrato],
	HT.[idTipoObjeto],
	HT.[idObjeto],
	HT.[nombre],
	HT.[idAgrupador],
	HT.[tiposPermitidos],
	HT.[obligatorio],
	HT.[vigencia],
	HT.[valor],
	HT.[aplicaCosto],
	HT.[orden],
	HT.[idUsuario],
	HT.[activo],
	HT.[aplicaEstado],
	HT.[aplicaComentario],
	HT.[idFileServer]
	from #final HT where HT.nombre ='Hoja de Trabajo')E

	--select * from #HojaRec

	--select COUNT(*) from #HojaRec where idFileServer is not null

	IF ((select COUNT(*) from #HojaRec where idFileServer is not null) > 0)
	begin

		select *
		into #HojaRecFin
		from
		(select 
		HRF.[idDocumentoClase],
		HRF.[idPaso],
		HRF.[idFase],
		HRF.[idClase],
		HRF.[idTipoSolicitud],
		HRF.[rfcEmpresa],
		HRF.[idCliente],
		HRF.[numeroContrato],
		HRF.[idTipoObjeto],
		HRF.[idObjeto],
		HRF.[nombre],
		HRF.[idAgrupador],
		HRF.[tiposPermitidos],
		HRF.[obligatorio],
		HRF.[vigencia],
		HRF.[valor],
		HRF.[aplicaCosto],
		HRF.[orden],
		HRF.[idUsuario],
		HRF.[activo],
		HRF.[aplicaEstado],
		HRF.[aplicaComentario],
		HRF.[idFileServer]
		 from #HojaRec HRF
		 INNER JOIN
		 (select 
		 idDocumentoClase,
		 idFase,
		 MAX(idFileServer) as 'idFileServer'
		 from #HojaRec
		 group by 
		 idDocumentoClase,
		 idFase) DA
		 on DA.idDocumentoClase = HRF.idDocumentoClase
		 AND DA.idFase = HRF.idFase
		 AND DA.idFileServer = HRF.idFileServer)F
	 
		select *
			 into #TablaFinIF
			from
			(select 
				HRF.[idDocumentoClase],
				HRF.[idPaso],
				HRF.[idFase],
				HRF.[idClase],
				HRF.[idTipoSolicitud],
				HRF.[rfcEmpresa],
				HRF.[idCliente],
				HRF.[numeroContrato],
				HRF.[idTipoObjeto],
				HRF.[idObjeto],
				HRF.[nombre],
				HRF.[idAgrupador],
				HRF.[tiposPermitidos],
				HRF.[obligatorio],
				HRF.[vigencia],
				HRF.[valor],
				HRF.[aplicaCosto],
				HRF.[orden],
				HRF.[idUsuario],
				HRF.[activo],
				HRF.[aplicaEstado],
				HRF.[aplicaComentario],
				HRF.[idFileServer]
			from #HojaRecFin HRF
			union ALL
			select 
				Tod.[idDocumentoClase],
				Tod.[idPaso],
				Tod.[idFase],
				Tod.[idClase],
				Tod.[idTipoSolicitud],
				Tod.[rfcEmpresa],
				Tod.[idCliente],
				Tod.[numeroContrato],
				Tod.[idTipoObjeto],
				Tod.[idObjeto],
				Tod.[nombre],
				Tod.[idAgrupador],
				Tod.[tiposPermitidos],
				Tod.[obligatorio],
				Tod.[vigencia],
				Tod.[valor],
				Tod.[aplicaCosto],
				Tod.[orden],
				Tod.[idUsuario],
				Tod.[activo],
				Tod.[aplicaEstado],
				Tod.[aplicaComentario],
				Tod.[idFileServer]
			from #todos Tod)H

			select * from #TablaFinIF order by orden

			drop table #HojaRecFin
			drop table #TablaFinIF
	 END
	 ELSE
	 BEGIN
			print 'Else'
			select *
			into #TablaFinElse
			from
			(select 
				HRF.[idDocumentoClase],
				HRF.[idPaso],
				HRF.[idFase],
				HRF.[idClase],
				HRF.[idTipoSolicitud],
				HRF.[rfcEmpresa],
				HRF.[idCliente],
				HRF.[numeroContrato],
				HRF.[idTipoObjeto],
				HRF.[idObjeto],
				HRF.[nombre],
				HRF.[idAgrupador],
				HRF.[tiposPermitidos],
				HRF.[obligatorio],
				HRF.[vigencia],
				HRF.[valor],
				HRF.[aplicaCosto],
				HRF.[orden],
				HRF.[idUsuario],
				HRF.[activo],
				HRF.[aplicaEstado],
				HRF.[aplicaComentario],
				HRF.[idFileServer]
			from #HojaRec HRF
			union ALL
			select 
				Tod.[idDocumentoClase],
				Tod.[idPaso],
				Tod.[idFase],
				Tod.[idClase],
				Tod.[idTipoSolicitud],
				Tod.[rfcEmpresa],
				Tod.[idCliente],
				Tod.[numeroContrato],
				Tod.[idTipoObjeto],
				Tod.[idObjeto],
				Tod.[nombre],
				Tod.[idAgrupador],
				Tod.[tiposPermitidos],
				Tod.[obligatorio],
				Tod.[vigencia],
				Tod.[valor],
				Tod.[aplicaCosto],
				Tod.[orden],
				Tod.[idUsuario],
				Tod.[activo],
				Tod.[aplicaEstado],
				Tod.[aplicaComentario],
				Tod.[idFileServer]
			from #todos Tod)I

			select * from #TablaFinElse order by orden
			drop table #TablaFinElse
	 END

	 

	

drop table #test
drop table #prueba
drop table #final
drop table #HojaRec
drop table #todos

	

END
go

