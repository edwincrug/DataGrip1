

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
/*

SELECT [solicitud].SEL_VALIDAAUTORIZACIONES_FN(1429,'Automovil','Imagen','ASE0508051B6',185,'43',746045,2182)
SELECT [solicitud].SEL_VALIDAAUTORIZACIONES_FN(1429,'Automovil','Imagen','ASE0508051B6',185,'43',746709,2182)
SELECT [solicitud].SEL_VALIDAAUTORIZACIONES_FN(1429,'Automovil','Imagen','ASE0508051B6',185,'43',783882,2182)
SELECT [solicitud].SEL_VALIDAAUTORIZACIONES_FN(1429,'Automovil','Imagen','ASE0508051B6',185,'43',778333,1566)



*/
-- =============================================
CREATE FUNCTION [solicitud].[SEL_VALIDAAUTORIZACIONES_FN]
(
	@idSolicitud		INT,
	@idClase			VARCHAR(10),
	@idTipoSolicitud	VARCHAR(10),
	@rfcEmpresa			VARCHAR(13),	
	@idCliente			INT,
	@numeroContrato		VARCHAR(50),
	@idPartida			INT,
	@idCotizacion		INT
)
RETURNS INT
AS
BEGIN
	DECLARE @idTipoObjeto INT
	DECLARE @idTipoAutorizacion VARCHAR(15)
	DECLARE @noAutorizadores INT
	DECLARE @noAutorizaciones INT
	DECLARE @salida INT

	SELECT	TOP 1  @idTipoObjeto=idTipoObjeto 
	FROM	partida.partida.Partida 
	WHERE	idPArtida	=@idPartida 
	AND		idClase		=@idClase 
	AND		activo		=1 
	AND		idPartidaEstatus='ACT'

	
	SELECT	TOP 1 @noAutorizadores=  
			CASE	WHEN idTipoAutorizacion='nAutDesc' THEN noAutorizadores
					WHEN idTipoAutorizacion='nAutRol'		THEN noAutorizadores
					WHEN idTipoAutorizacion='nAutUserEspCO'	THEN (	SELECT COUNT(*) 
																	FROM	[Cliente].[contrato].[PartidaAutorizacion]
																	WHERE	idClase				= aut.idClase
																	AND		idTipoSolicitud		= aut.idTipoSolicitud
																	AND		rfcEmpresa			= aut.rfcEmpresa
																	AND		idCliente			= aut.idCliente
																	AND		numeroContrato		= aut.numeroContrato
																	AND		idPartida			= aut.idPartida 
																	AND     idTipoObjeto		= aut.idTipoObjeto)
					WHEN idTipoAutorizacion='nAutUserEspSO'	THEN (	SELECT COUNT(*) 
																	FROM	[Cliente].[contrato].[PartidaAutorizacion] 
																	WHERE	idClase				= aut.idClase
																	AND		idTipoSolicitud		= aut.idTipoSolicitud
																	AND		rfcEmpresa			= aut.rfcEmpresa
																	AND		idCliente			= aut.idCliente
																	AND		numeroContrato		= aut.numeroContrato
																	AND		idPartida			= aut.idPartida 
																	AND     idTipoObjeto		= aut.idTipoObjeto)
			ELSE 0 END
	-- select *
	FROM	[Cliente].[contrato].[PartidaAutorizacion] aut
	WHERE	idClase				= @idClase
	AND		idTipoSolicitud		= @idTipoSolicitud
	AND		rfcEmpresa			= @rfcEmpresa
	AND		idCliente			= @idCliente
	AND		numeroContrato		= @numeroContrato
	AND		idPartida			= @idPartida
	AND     idTipoObjeto		= @idTipoObjeto

	IF @noAutorizadores>0
		BEGIN
			SELECT	@noAutorizaciones=COUNT(*) 
			FROM	[Solicitud].[solicitud].[SolicitudCotizacionAprobador]
			WHERE	idSolicitud			= @idSolicitud
			AND     idTipoSolicitud		= @idTipoSolicitud
			AND		idClase				= @idClase
			AND		rfcEmpresa			= @rfcEmpresa
			AND		numeroContrato		= @numeroContrato
			AND		idCliente			= @idCliente
			AND		idPartida			= @idPartida
			AND     idTipoObjeto		= @idTipoObjeto
			AND     idCotizacion		= @idCotizacion
			
			SET		@salida=ISNULL(@noAutorizadores,0)-ISNULL(@noAutorizaciones,0)
		END
	ELSE
		BEGIN
			SET @salida=0
		END

	RETURN @salida
END
go

