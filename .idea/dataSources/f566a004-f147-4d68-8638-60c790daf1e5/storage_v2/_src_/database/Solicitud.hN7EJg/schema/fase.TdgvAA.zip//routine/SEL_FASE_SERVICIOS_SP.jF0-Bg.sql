
-- =============================================
-- Author: Andres Farias
-- Create date: 25-06-2019
-- Description: Obtiene las fases con su tatal de cada fase de servicio
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	19-08-2019	JEHR	Quito el hardcode del id de clase
						Agrego filtros de finalizada
						Cambio estructura
						

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[SEL_FASE_SERVICIOS_SP]  'Automovil', 6110, '43', 185, 10558, 117,
	@salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [fase].[SEL_FASE_SERVICIOS_SP] 
	@idClase				VARCHAR(50),
	@idUsuario				INT,
	@numeroContrato			VARCHAR(50) = NULL,
	@idCliente				INT = NULL,
	@idObjeto				INT ,
	@idTipoObjeto			INT ,
	@err					VARCHAR(500) OUTPUT
AS


BEGIN
	
	DECLARE @salida VARCHAR(MAX) ='' ;
	DECLARE @datos TABLE (
		nombre VARCHAR(250),
		costo float,
		venta float,
		color VARCHAR(250),
		orden INT
	)
	
	INSERT INTO @datos
		SELECT 
			sep.idFase AS idFase,
			SUM(cotpar.cantidad*cotpar.costo) AS Costo,
			SUM(cotpar.cantidad*cotpar.venta) AS Venta,
			fas.color,
			fas.orden
		FROM solicitud.SolicitudObjeto so
			INNER JOIN solicitud.solicitud s ON
				s.idSolicitud=so.idSolicitud 
				AND s.idTipoSolicitud = so.idTipoSolicitud 
				AND s.numeroContrato = so.numeroContrato 
				AND s.idCliente = so.idCliente 
				AND s.idClase = so.idClase
				AND S.idEstatusSolicitud = 'ACTIVA'
			INNER JOIN fase.SolicitudEstatusPaso sep ON
				sep.idSolicitud = so.idSolicitud 
				AND sep.idTipoSolicitud = so.idTipoSolicitud 
				AND sep.numeroContrato = so.numeroContrato 
				AND sep.idCliente = so.idCliente 
				AND sep.idClase = so.idClase
			INNER JOIN solicitud.SolicitudCotizacion coti ON
				coti.idSolicitud = so.idSolicitud 
				AND coti.numeroContrato = so.numeroContrato 
				AND coti.idCliente = so.idCliente 
				AND coti.idClase = so.idClase
			LEFT JOIN solicitud.SolicitudCotizacionPartida cotpar ON
				cotpar.idCotizacion = coti.idCotizacion
				AND cotpar.idEstatusCotizacionPartida  = 'APROBADA'
				AND cotpar.numeroContrato = coti.numeroContrato 
				AND cotpar.idCliente = coti.idCliente 
				AND cotpar.idClase = coti.idClase
			INNER JOIN fase.Fase fas ON
				sep.idFase=fas.idFase
			WHERE
				sep.fechaSalida IS NULL
				AND  so.idObjeto = @idObjeto
				AND so.idTipoObjeto = @idTipoObjeto
				AND so.numeroContrato = @numeroContrato
				AND so.idCliente = @idCliente
				AND sep.idPaso != 'Finalizada'
			GROUP BY
				sep.idFase,
				fas.color,
				fas.orden
			

		INSERT INTO @datos
			SELECT 
				CEP.idFase AS idFase,
				(SELECT ISNULL(SUM(costo * cantidad), 0) 
					FROM solicitud.solicitudcotizacionpartida SCP
					LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida 
					WHERE idSolicitud = SOL.idSolicitud
						AND EP.idEstatusCotizacionPartida  = 'APROBADA'
				) AS Costo,
				(SELECT ISNULL(SUM(venta * cantidad), 0) 
					FROM solicitud.solicitudcotizacionpartida SCP
					LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida 
					WHERE idSolicitud = SOL.idSolicitud
						AND EP.idEstatusCotizacionPartida  = 'APROBADA'
				) AS Venta,
				fas.color,
				fas.orden
			FROM [faseContrato].[Paso] FP 
				LEFT JOIN  [faseContrato].[SolicitudEstatusPaso] CEP ON FP.idPaso = CEP.idPaso
				LEFT JOIN solicitud.solicitud SOL ON SOL.idSolicitud = CEP.idSolicitud AND SOL.idClase = @idClase 
				INNER JOIN fase.Fase fas on cep.idFase = fas.idFase
			WHERE CEP.idClase = @idClase
				AND SOL.idEstatusSolicitud = 'ACTIVA'
				AND CEP.fechaSalida IS NULL
				AND CEP.numeroContrato = @numeroContrato
				AND cep.idCliente = @idCliente
				AND cep.idClase = @idClase
				AND cep.idPaso != 'Finalizada'

		INSERT INTO @datos
			SELECT 'Finalizado' AS idFase,
			SUM(cotpar.cantidad*cotpar.costo) AS Costo,
			SUM(cotpar.cantidad*cotpar.venta) AS Venta,
			'#00BFFF',
			6
			FROM solicitud.SolicitudObjeto so
				INNER JOIN solicitud.solicitud s ON
					s.idSolicitud=so.idSolicitud 
					AND s.idTipoSolicitud = so.idTipoSolicitud 
					AND s.numeroContrato = so.numeroContrato 
					AND s.idCliente = so.idCliente 
					AND s.idClase = so.idClase
					AND s.idEstatusSolicitud = 'ACTIVA'
				INNER JOIN fase.SolicitudEstatusPaso sep ON
					sep.idSolicitud = so.idSolicitud 
					AND sep.idTipoSolicitud = so.idTipoSolicitud 
					AND sep.numeroContrato = so.numeroContrato 
					AND sep.idCliente = so.idCliente 
					AND sep.idClase = so.idClase
				INNER JOIN solicitud.SolicitudCotizacion coti ON
					coti.idSolicitud = so.idSolicitud 
					AND coti.numeroContrato = so.numeroContrato 
					AND coti.idCliente = so.idCliente 
					AND coti.idClase = so.idClase
				LEFT JOIN solicitud.SolicitudCotizacionPartida cotpar ON
					cotpar.idCotizacion = coti.idCotizacion
					AND cotpar.idEstatusCotizacionPartida  = 'APROBADA'
					AND cotpar.numeroContrato = coti.numeroContrato 
					AND cotpar.idCliente = coti.idCliente 
					AND cotpar.idClase = coti.idClase
				INNER JOIN fase.Fase fas ON
					sep.idFase=fas.idFase

				WHERE
					sep.fechaSalida IS NULL
					AND  so.idObjeto = @idObjeto
					AND so.idTipoObjeto = @idTipoObjeto
					AND so.numeroContrato = @numeroContrato
					AND so.idCliente = @idCliente
					AND sep.idPaso = 'Finalizada'

				GROUP BY
					sep.idFase,
					fas.color,
					fas.orden
			

		INSERT INTO @datos
			SELECT 
				'Finalizado' AS idFase,
				(SELECT ISNULL(SUM(costo * cantidad), 0) 
					FROM solicitud.solicitudcotizacionpartida SCP
					LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida 
					WHERE idSolicitud = SOL.idSolicitud
						AND EP.idEstatusCotizacionPartida  = 'APROBADA'
				) AS Costo,
				(SELECT ISNULL(SUM(venta * cantidad), 0) 
					FROM solicitud.solicitudcotizacionpartida SCP
					LEFT JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida 
					WHERE idSolicitud = SOL.idSolicitud
						AND EP.idEstatusCotizacionPartida  = 'APROBADA'
				) AS Venta,
				'#00BFFF',
				6
			FROM [faseContrato].[Paso] FP 
				LEFT JOIN  [faseContrato].[SolicitudEstatusPaso] CEP ON FP.idPaso = CEP.idPaso
				LEFT JOIN solicitud.solicitud SOL ON SOL.idSolicitud = CEP.idSolicitud AND SOL.idClase = @idClase 
				INNER JOIN fase.Fase fas on cep.idFase = fas.idFase
			WHERE CEP.idClase = @idClase
				AND SOL.idEstatusSolicitud = 'ACTIVA'
				AND CEP.fechaSalida IS NULL
				AND CEP.numeroContrato = @numeroContrato
				AND cep.idCliente = @idCliente
				AND cep.idClase = @idClase
				AND cep.idPaso = 'Finalizada'




		IF NOT EXISTS (SELECT nombre FROM @datos WHERE nombre ='Proceso' ) INSERT INTO @datos VALUES ('Porceso',0,0,'#9E0E31',3)
		IF NOT EXISTS (SELECT nombre FROM @datos WHERE nombre ='Entrega' ) INSERT INTO @datos VALUES ('Entrega',0,0,'#FCB142',4)
		IF NOT EXISTS (SELECT nombre FROM @datos WHERE nombre ='Cobranza' ) INSERT INTO @datos VALUES ('Cobranza',0,0,'#7F1480',5)
		IF NOT EXISTS (SELECT nombre FROM @datos WHERE nombre ='Finalizado' ) INSERT INTO @datos VALUES ('Finalizado',0,0,'#00BFFF',6)

		SELECT * FROM @datos ORDER BY orden;

		SELECT SUM(costo) AS costo, SUM(venta) AS venta FROM @datos;
END

go

