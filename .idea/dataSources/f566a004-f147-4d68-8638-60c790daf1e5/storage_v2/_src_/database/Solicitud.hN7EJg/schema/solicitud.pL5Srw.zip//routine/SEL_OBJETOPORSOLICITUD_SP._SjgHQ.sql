-- =============================================
-- Author:		Martin Pacheco
-- Create date: 06/07/2019
-- Description:	obtiene objeto por solicitud.
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_OBJETOPORSOLICITUD_SP]
	@idSolicitud		INT = 0,
	@idClase			VARCHAR(10) = '',
	@rfcEmpresa			VARCHAR(13) = '',
	@idCliente			INT = 0,
	@numeroContrato		VARCHAR(50) = '',
	@idUsuario			INT = 0,
	@err				VARCHAR(500) OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	SELECT 
		[SO].[idTipoObjeto],
		[SO].[idObjeto]
	FROM [solicitud].[SolicitudObjeto] AS [SO]
	WHERE 
		[SO].[idSolicitud] = @idSolicitud AND
		[SO].[idClase] = @idClase AND
		[SO].[rfcEmpresa] = @rfcEmpresa AND
		[SO].[idCliente] = @idCliente AND
		[SO].[numeroContrato] = @numeroContrato

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

