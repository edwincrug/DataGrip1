-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<04/07/2019>
-- Description:	    <Obtiene el estatus real de la cotizacion, fue creado por un dios>
-- =============================================
-- SELECT 
    -- SSC.[idCotizacion]
    -- ,[idSolicitud]
    -- ,[idTipoSolicitud]
    -- ,[idClase]
    -- ,[rfcEmpresa]
    -- ,[idCliente]
    -- ,[numeroContrato]
    -- ,[idProveedorEntidad]
    -- ,[rfcProveedor]
    -- ,[numeroCotizacion]
    -- ,[fechaAlta]
    -- ,[idUsuario]
    -- ,[totalPartidas]
    -- ,[estatusCotizacion]
    -- ,[estatusCotizacionNombre]
-- FROM [solicitud].[SEL_ESTATUS_COTIZACIONES_BY_SOLICITUD_FN](99)
-- =============================================
CREATE FUNCTION [solicitud].[SEL_ESTATUS_COTIZACIONES_BY_SOLICITUD_FN](@idSolicitud int, @idObjeto int)
RETURNS @SolicitudEstatusPaso 
TABLE (
    [idCotizacion] [int] NOT NULL,
	[idSolicitud] [int] NOT NULL,
	[idTipoSolicitud] [varchar](10) NOT NULL,
	[idClase] [varchar](10) NOT NULL,
	[rfcEmpresa] [varchar](13) NOT NULL,
	[idCliente] [int] NOT NULL,
	[numeroContrato] [varchar](50) NOT NULL,
	[idProveedorEntidad] [int] NOT NULL,
	[rfcProveedor] [varchar](13) NOT NULL,
	[numeroCotizacion] [varchar](50) NOT NULL,
	[fechaAlta] [datetime] NOT NULL,
	[idUsuario] [int] NOT NULL,
    [totalPartidas] [int] NULL,
    [totalPartidasAprobadas] [int] NULL,
    [totalPartidasEnEspera] [int] NULL,
    [totalPartidasCancelada] [int] NULL,
    [totalPartidasRechazada] [int] NULL,
    [estatusCotizacion] [varchar](10) NULL,
    [estatusCotizacionNombre] [varchar](10) NULL
)

AS

BEGIN
    DECLARE
    @idSolicitudExistente               int=0

    SELECT  
        @idSolicitudExistente = SS.[idSolicitud] 
    FROM [Solicitud].[solicitud].[Solicitud] SS 
    WHERE idEstatusSolicitud <> 'FINALIZADA'
        AND idSolicitud = @idSolicitud

    IF(@idSolicitudExistente > 0)
    BEGIN
        INSERT INTO @SolicitudEstatusPaso
        SELECT 
            SSC.[idCotizacion]
            ,SSC.[idSolicitud]
            ,SSC.[idTipoSolicitud]
            ,SSC.[idClase]
            ,SSC.[rfcEmpresa]
            ,SSC.[idCliente]
            ,SSC.[numeroContrato]
            ,SSC.[idProveedorEntidad]
            ,SSC.[rfcProveedor]
            ,SSC.[numeroCotizacion]
            ,SSC.[fechaAlta]
            ,SSC.[idUsuario]
            ,Partidas.[totalPartidas]
            ,Aprobada.[totalPartidasAprobadas]
            ,EnEspera.[totalPartidasEnEspera]
            ,Cancelada.[totalPartidasCancelada]
            ,Rechazada.[totalPartidasRechazada]
            ,CASE WHEN Partidas.[totalPartidas] = Rechazada.[totalPartidasRechazada] THEN 'RECHAZADA'
                WHEN Partidas.[totalPartidas] = Cancelada.[totalPartidasCancelada] THEN 'CANCELADA'
                WHEN (EnEspera.[totalPartidasEnEspera] IS NULL OR EnEspera.[totalPartidasEnEspera] = 0) 
                    AND Aprobada.[totalPartidasAprobadas] > 0 THEN 'APROBADA'
                ELSE 'ENESPERA'
            END estatusCotizacion
            ,CASE WHEN Partidas.[totalPartidas] = Rechazada.[totalPartidasRechazada] THEN 'Rechazada'
                WHEN Partidas.[totalPartidas] = Cancelada.[totalPartidasCancelada] THEN 'Cancelada'
                WHEN (EnEspera.[totalPartidasEnEspera] IS NULL OR EnEspera.[totalPartidasEnEspera] = 0) 
                    AND Aprobada.[totalPartidasAprobadas] > 0 THEN 'Aprobada'
                ELSE 'En Espera'
            END estatusCotizacionNombre
        FROM [Solicitud].[solicitud].[SolicitudCotizacion] SSC
        INNER JOIN [Solicitud].[solicitud].[SolicitudCotizacionPartida] SSCP
            ON SSC.idSolicitud = SSCP.idSolicitud
            AND SSC.idCotizacion = SSCP.idCotizacion
        INNER JOIN (
            SELECT 
                [idCotizacion]
                ,COUNT([idEstatusCotizacionPartida]) totalPartidas
            FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida]
            WHERE idSolicitud = @idSolicitud
			AND idObjeto = @idObjeto
            GROUP BY idCotizacion
        ) Partidas
            ON SSC.[idCotizacion] = Partidas.[idCotizacion]
        LEFT JOIN (
            SELECT 
                [idCotizacion]
                ,COUNT([idEstatusCotizacionPartida]) totalPartidasAprobadas
            FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida] 
            WHERE [idSolicitud] = @idSolicitud
			AND idObjeto = @idObjeto
                AND [idEstatusCotizacionPartida] = 'APROBADA'
            GROUP BY [idCotizacion]
        ) Aprobada
            ON SSC.[idCotizacion] = Aprobada.[idCotizacion]
        LEFT JOIN (
            SELECT 
                [idCotizacion]
                ,COUNT([idEstatusCotizacionPartida]) totalPartidasEnEspera
            FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida] 
            WHERE [idSolicitud] = @idSolicitud
			AND idObjeto = @idObjeto
                AND [idEstatusCotizacionPartida] = 'ENESPERA'
            GROUP BY [idCotizacion]
        ) EnEspera
            ON SSC.[idCotizacion] = EnEspera.[idCotizacion]
        LEFT JOIN (
            SELECT 
                [idCotizacion]
                ,COUNT([idEstatusCotizacionPartida]) totalPartidasCancelada
            FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida] 
            WHERE [idSolicitud] = @idSolicitud
			AND idObjeto = @idObjeto
                AND [idEstatusCotizacionPartida] = 'CANCELADA'
            GROUP BY [idCotizacion]
        ) Cancelada
            ON SSC.[idCotizacion] = Cancelada.[idCotizacion]
        LEFT JOIN (
            SELECT 
                [idCotizacion]
                ,COUNT([idEstatusCotizacionPartida]) totalPartidasRechazada
            FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida] 
            WHERE [idSolicitud] = @idSolicitud
			AND idObjeto = @idObjeto
                AND [idEstatusCotizacionPartida] = 'RECHAZADA'
            GROUP BY [idCotizacion]
        ) Rechazada
            ON SSC.[idCotizacion] = Rechazada.[idCotizacion]
        WHERE SSC.idSolicitud = @idSolicitud
		AND idObjeto = @idObjeto
            AND SSCP.idSolicitud = @idSolicitud
        GROUP BY 
            SSC.[idCotizacion]
            ,SSC.[idSolicitud]
            ,SSC.[idTipoSolicitud]
            ,SSC.[idClase]
            ,SSC.[rfcEmpresa]
            ,SSC.[idCliente]
            ,SSC.[numeroContrato]
            ,SSC.[idProveedorEntidad]
            ,SSC.[rfcProveedor]
            ,SSC.[numeroCotizacion]
            ,SSC.[fechaAlta]
            ,SSC.[idUsuario]
            ,Partidas.[totalPartidas]
            ,Aprobada.[totalPartidasAprobadas]
            ,EnEspera.[totalPartidasEnEspera]
            ,Cancelada.[totalPartidasCancelada]
            ,Rechazada.[totalPartidasRechazada]

    END

    RETURN
END
go

