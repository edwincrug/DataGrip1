
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 06-09-2019
-- Description: Actualiza regla de paso
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	EXEC [fase].[UPD_REGLAPASO_SP] 
	@idReglaPaso = 69 
	,@aplicaReglaMonto= false
	,@aplicaReglaNivel= false
	,@aplicaReglaObjeto= true
	,@aplicaReglaPartida= true
	,@aplicaReglaRol= true
	,@aplicaReglaUsuario= false
	,@idClase= 'Automovil'
	,@idCliente= 92
	,@idFase= 'Aprobacion'
	,@idNivel= ''
	,@idPaso= 'EnEspera'
	,@idTipoMonto= ''
	,@idTipoSolicitud= 'Servicio'
	,@montoMaximo= 0
	,@montoMinimo= 0
	,@numeroContrato= '0001'
	,@rfcEmpresa= 'ASE0508051B6'
	,@xmlObjetos= '<objetos><objeto><idObjeto>undefined</idObjeto></objeto><objeto><idObjeto>undefined</idObjeto></objeto></objetos>'
	,@xmlPartidas= '<partidas><partida><idPartida>undefined</idPartida></partida><partida><idPartida>undefined</idPartida></partida></partidas>'
	,@xmlRoles= '<roles><rol><idRol>undefined</idRol></rol></roles>'
	,@xmlUsuarios= null
	,@idUsuario = 6077
	,@descripcion = 'prueba 2'
	,@err = ''

*/
-- =============================================
CREATE  PROCEDURE [fase].[UPD_REGLAPASO_SP] 
	@idReglaPaso				INT
	,@rfcEmpresa				VARCHAR(13)
	,@numeroContrato			VARCHAR(50)
	,@idCliente					INT
	,@idTipoSolicitud			VARCHAR(10)
	,@idClase					VARCHAR(10)
	,@aplicaReglaRol			BIT
	,@aplicaReglaUsuario		BIT
	,@aplicaReglaPartida		BIT
	,@aplicaReglaMonto			BIT
	,@aplicaReglaObjeto			BIT
	,@aplicaReglaNivel			BIT
	,@xmlRoles					XML
	,@xmlUsuarios				XML
	,@xmlPartidas				XML
	,@idTipoMonto				VARCHAR(10)
	,@montoMinimo				DECIMAL(18,2)
	,@montoMaximo				DECIMAL(18,2)
	,@xmlObjetos				XML
	,@idNivel					INT
	,@idUsuario					INT
	,@descripcion				VARCHAR(500)
	,@idAplicacion				INT
	,@err						varchar(500)OUTPUT
AS


BEGIN

	
	DELETE from [fase].[ReglaPasoRol] where idreglapaso = @idReglaPaso
	DELETE from [fase].[ReglaPasoUsuario] where idreglapaso = @idReglaPaso
	DELETE from [fase].[ReglaPasoPartida] where idreglapaso = @idReglaPaso
	DELETE from [fase].[ReglaPasoMonto] where idreglapaso = @idReglaPaso
	DELETE from [fase].[ReglaPasoObjeto] where idreglapaso = @idReglaPaso

/****************************************************ACTUALIZA EN REGLA PASO **********************************/

	UPDATE [fase].[ReglaPaso]
	SET aplicaReglaRol = @aplicaReglaRol,
		aplicaReglaUsuario = @aplicaReglaUsuario,
		aplicaReglaPartida = @aplicaReglaPartida,
		aplicaReglaMonto = @aplicaReglaMonto,
		aplicaReglaObjeto = @aplicaReglaObjeto,
		descripcion = @descripcion
	WHERE idReglaPaso = @idReglaPaso

	IF(@aplicaReglaNivel = 1)
		BEGIN
			UPDATE [fase].[ReglaPaso]
			SET idNivel = @idNivel
			WHERE idReglaPaso = @idReglaPaso
		END

	ELSE
		BEGIN
			UPDATE [fase].[ReglaPaso]
			SET idNivel = NULL
			WHERE idReglaPaso = @idReglaPaso
		END


/****************************************************INSERTA EN REGLA ROL **********************************/

	IF(@aplicaReglaRol = 1)
		BEGIN
			DECLARE @tbl_roles AS TABLE(
			idRol					INT
			)

			INSERT INTO @tbl_roles(idRol)
			SELECT
				ParamValues.col.value('idRol[1]','int')
				FROM @xmlRoles.nodes('roles/rol') AS ParamValues(col)

			INSERT INTO [fase].[ReglaPasoRol]
			SELECT
				@idReglaPaso,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				@idAplicacion,
				idRol,
				1,
				@idUsuario
			FROM @tbl_roles
				
		END

/****************************************************INSERTA EN REGLA USUARIO **********************************/

	IF(@aplicaReglaUsuario = 1)
		BEGIN
			DECLARE @tbl_usuarios AS TABLE(
			idUsuario				INT
			)

			INSERT INTO @tbl_usuarios(idUsuario)
			SELECT
				ParamValues.col.value('idUsuario[1]','int')
				FROM @xmlUsuarios.nodes('usuarios/usuario') AS ParamValues(col)

			INSERT INTO [fase].[ReglaPasoUsuario]
			SELECT
				@idReglaPaso,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				idUsuario,
				@idAplicacion,
				1,
				@idUsuario
			FROM @tbl_usuarios
				
		END

/****************************************************INSERTA EN REGLA PARTIDA **********************************/

	IF(@aplicaReglaPartida = 1)
		BEGIN
			DECLARE @tbl_partidas AS TABLE(
			idPartida				INT
			)

			INSERT INTO @tbl_partidas(idPartida)
			SELECT
				ParamValues.col.value('idPartida[1]','int')
				FROM @xmlPartidas.nodes('partidas/partida') AS ParamValues(col)

			INSERT INTO [fase].[ReglaPasoPartida]
			SELECT
				@idReglaPaso,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				TBL.idPartida,
				PPP.idTipoObjeto,
				1,
				@idUsuario
			FROM @tbl_partidas TBL
			LEFT JOIN partida.partida.partida PPP ON PPP.idPartida = TBL.idPartida AND PPP.activo = 1
				
		END



/****************************************************INSERTA EN REGLA MONTO **********************************/

	IF(@aplicaReglaMonto = 1)
		BEGIN
			
			INSERT INTO [fase].[ReglaPasoMonto]
			SELECT
				@idReglaPaso,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				@idTipoMonto,
				@montoMinimo,
				@montoMaximo,
				1,
				@idUsuario
				
		END


/****************************************************INSERTA EN REGLA OBJETOS **********************************/

	IF(@aplicaReglaObjeto = 1)
		BEGIN

			DECLARE @tbl_objetos AS TABLE(
			idObjeto				INT
			)

			INSERT INTO @tbl_objetos(idObjeto)
			SELECT
				ParamValues.col.value('idObjeto[1]','int')
				FROM @xmlObjetos.nodes('objetos/objeto') AS ParamValues(col)
			
			INSERT INTO [fase].[ReglaPasoObjeto]
			SELECT
				@idReglaPaso,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				OOO.idTipoObjeto,
				TOJ.idObjeto,
				1,
				@idUsuario
			FROM @tbl_objetos TOJ
			LEFT JOIN objeto.objeto.objeto OOO ON OOO.idObjeto = TOJ.idObjeto AND OOO.activo = 1
				
		END
	
END

go

