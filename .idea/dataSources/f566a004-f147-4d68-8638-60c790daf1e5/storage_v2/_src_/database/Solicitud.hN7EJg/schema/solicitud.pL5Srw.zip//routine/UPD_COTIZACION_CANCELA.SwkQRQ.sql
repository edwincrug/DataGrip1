-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<20/04/2020>
-- Description:	    <Cancelar Cotización>
-- =============================================
-- EXEC [solicitud].[UPD_COTIZACION_CANCELA] 1043, 461, 6119
-- =============================================
CREATE PROCEDURE [solicitud].[UPD_COTIZACION_CANCELA]
(
	@idCotizacion			INT
	,@idSolicitud			INT
	,@idTipoSolicitud		VARCHAR(10)
	,@idClase				VARCHAR(10)
	,@rfcEmpresa			VARCHAR(13)
	,@idCliente				INT
	,@numeroContrato		VARCHAR(50)
	,@idProveedorEntidad    INT
	,@rfcProveedor			VARCHAR(13)
	,@idUsuario				INT
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS
DECLARE
@idFase					VARCHAR(20)=NULL
,@idEstatusCotizacion	VARCHAR(20)=0
,@cancelado				INT=0

BEGIN
    SELECT 
        @idFase = SF.[idFase]
    FROM [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud) SF

	--IF(@idFase = 'Proceso')
	--BEGIN
		SELECT @idEstatusCotizacion = [idEstatusCotizacion]
		FROM [Solicitud].[solicitud].[SolicitudCotizacion]
		WHERE idCotizacion = @idCotizacion
			AND idSolicitud = @idSolicitud
		--IF(@idEstatusCotizacion > 0)
		--BEGIN
			IF(@idEstatusCotizacion = 'CANCELADA')
			BEGIN
				SET @err = 'La cotización ya fue cancelada.'
			END
			ELSE
			BEGIN
				BEGIN TRAN CancelaCotizacion
                BEGIN TRY

					INSERT INTO [Solicitud].[solicitud].[EstatusSolicitudCotizacion]
					(
						fechaAlta
						,idCotizacion
						,idSolicitud
						,idTipoSolicitud
						,idClase
						,rfcEmpresa
						,idCliente
						,numeroContrato
						,idProveedorEntidad
						,rfcProveedor
						,idEstatusCotizacion
						,idUsuario
					)
					VALUES
					(
						GETDATE()
						,@idCotizacion
						,@idSolicitud
						,@idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,@idProveedorEntidad
						,@rfcProveedor
						,'CANCELADA' --Solicitud.EstatusCotizacion -CANCELADO-
						,@idUsuario
					)

					UPDATE [Solicitud].[solicitud].[SolicitudCotizacion]
						SET [idEstatusCotizacion] = 'CANCELADA'
					WHERE idCotizacion = @idCotizacion AND idSolicitud = @idSolicitud

					UPDATE solicitud.SolicitudCotizacionPartida
					SET idEstatusCotizacionPartida = 'CANCELADA'
					WHERE idCotizacion = @idCotizacion AND idSolicitud = @idSolicitud AND idEstatusCotizacionPartida = 'ENESPERA'

					--Unicamente aplica cuendo este en aprobacion debido a que si se cancela una cotizacion y era la ultima por aprobar la orden deberia avanzar a en proceso en automatico
					IF(@idFase = 'Aprobacion')
						BEGIN
							EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
							@idSolicitud = @idSolicitud
							,@idTipoSolicitud = @idTipoSolicitud
							,@idClase = @idClase
							,@rfcEmpresa = @rfcEmpresa
							,@idCliente	= @idCliente
							,@numeroContrato = @numeroContrato
							,@idUsuario = @idUsuario
							,@err = '' 
						END

					SET @cancelado = 1
					SET @err = 'La cotización se cancelo de forma correcta.'

                    COMMIT TRAN CancelaCotizacion
					
                END TRY
                BEGIN CATCH
                    ROLLBACK TRAN CancelaCotizacion
                    SET @err = 'Ocurrio un error al cancelar la cotización.'
					SET @cancelado = 0
                END CATCH
			END
		--END
		--ELSE
		--BEGIN
		--	SET @err = 'La cotización no existe.'
		--END
	--END
	--ELSE
	--BEGIN
	--	SET @err = 'Solo se puede eliminar cotizaciones con solicitudes en el estatus "En Proceso".'
	--END

	SELECT @cancelado cancelado

END



go

