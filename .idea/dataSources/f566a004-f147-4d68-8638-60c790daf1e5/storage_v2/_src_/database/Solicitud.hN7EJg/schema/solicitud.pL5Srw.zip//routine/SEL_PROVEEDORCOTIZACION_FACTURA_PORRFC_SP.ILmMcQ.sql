      
-- =============================================      
-- Author: Andres Farias      
-- Create date: 07-08-2019      
-- Description: Obtener las partidas aprobadas de un proveedor      
-- ============== Versionamiento ================      
/*      
 Fecha  Autor Descripción       
       
      
 *- Testing...      
 DECLARE @salida varchar(max) ='' ;      
 EXEC [solicitud].[SEL_PROVEEDORCOTIZACION_FACTURA_PORRFC_SP]   'AAHD740210I98', 'Automovil',2326, NULL;     
 SELECT @salida AS salida;      
*/      
-- =============================================      
CREATE PROCEDURE [solicitud].[SEL_PROVEEDORCOTIZACION_FACTURA_PORRFC_SP]      
 @rfcProveedor    varchar(13),      
 --@rfcEmpresa    varchar(13),      
 --@idCliente    int,      
 --@numeroContrato   nvarchar(50),      
 @idClase    varchar(10),      
 @idUsuario    int,      
 @err     varchar(500)OUTPUT      
AS      
      
      
BEGIN      

IF EXISTS (select 1 from solicitud.SolicitudCotizacionPartida SCP
				INNER JOIN solicitud.SolicitudCotizacion C ON C.idCotizacion = SCP.idCotizacion
				left JOIN cxp.solicitudcotizacionfacturadetalle FD on 
					FD.idSolicitud = scp.idSolicitud 
					AND FD.idPartida = scp.idPartida 
					and FD.idCotizacion = SCP.idCotizacion
					AND FD.rfcProveedor = SCP.rfcProveedor
				left join cxp.SolicitudCotizacionFacturaDetallePorConsolidar sfc on
					sfc.idSolicitud = scp.idSolicitud 
					AND sfc.idPartida = scp.idPartida 
					and sfc.idCotizacion = SCP.idCotizacion
					AND sfc.rfcProveedor = SCP.rfcProveedor
				where SCP.rfcProveedor = @rfcProveedor
				AND FD.uuid is null AND sfc.uuid IS NULL
				AND SCP.idEstatusCotizacionPartida = 'APROBADA'
				AND C.idEstatusCotizacion = 'APROBADA')

BEGIN
       
 create table #partidas(      
 idPartida     int,      
 agrupador   varchar(MAX),      
 valor    varchar(MAX),      
 orden    int,      
 posicion   int,      
 ordenFinal   INT      
)      
      
/**********************************************************************************************************************      
******************************************************CATALOGOS Y AGRUPADORES******************************************      
**********************************************************************************************************************/      
--PROPIEDADES GENERALES      
;with catalogos as(      
 select distinct       
  par.idPartida     idPartida,      
  prg.agrupador     agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'      
  prg.valor      valor,      
  prg.idPadre      idPadre,      
  prg.orden      orden,      
  prg.posicion     posicion,      
  0        ordenFinal      
 from       
 [Partida].partida.Partida par      
 inner join [Partida].partida.PartidaPropiedadGeneral tpg on par.idPartida = tpg.idPartida      
 inner join [Partida].partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral      
 inner join [Partida].integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato     
 inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
 inner join [Solicitud].Solicitud.Solicitud s on scp.idSolicitud = s.idSolicitud
 where       
  prg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES      
  AND par.idClase = @idClase      
  AND par.activo = 1    
  AND s.idEstatusSolicitud not in ('CANCELADA','RECHAZADA')
 UNION ALL       
 --HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR      
 select      
  cat.idPartida     idPartida,      
  prg.agrupador     agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'      
  prg.valor      valor,      
  prg.idPadre      idPadre,      
  prg.orden      orden,      
  prg.posicion     posicion,      
  0        ordenFinal      
 from [Partida].partida.PropiedadGeneral prg       
 inner join [Partida].integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato       
 inner join catalogos cat on cat.idPadre = prg.idPropiedadGeneral      
 and prg.activo = 1      
 )      
 insert into #partidas      
 select distinct      
  cat.idPartida,      
  cat.agrupador,      
  cat.valor,      
  cat.orden,      
  cat.posicion,      
  cat.ordenFinal      
 from catalogos cat       
 where       
  cat.idPadre is not null      
      
--PROPIEDADES DE CLASE      
;with catalogos as(      
 select  distinct    
  par.idPartida     idPartida,      
  prc.agrupador     agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'      
  isnull(prc.valor,'')   valor,      
  prc.idPadre      idPadre,      
  prc.orden      orden,      
  prc.posicion     posicion,      
  1        ordenFinal      
 from       
 [Partida].partida.Partida par      
 inner join [Partida].partida.PartidaPropiedadClase tpc on par.idPartida = tpc.idPartida      
 inner join [Partida].partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase      
 inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
 inner join [Solicitud].Solicitud.Solicitud s on scp.idSolicitud = s.idSolicitud
 where       
  prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES      
  AND par.idClase = @idClase      
  and par.activo = 1      
  AND s.idEstatusSolicitud not in ('CANCELADA','RECHAZADA')
 UNION ALL       
 --HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR      
 select      
  cat.idPartida     idPartida,      
  prc.agrupador     agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'      
  isnull(prc.valor,'')   valor,      
  prc.idPadre      idPadre,      
  prc.orden      orden,      
  prc.posicion     posicion,      
  1        ordenFinal      
 from [Partida].partida.PropiedadClase prc       
 inner join catalogos cat on cat.idPadre = prc.idPropiedadClase       
 WHERE prc.activo = 1      
 )      
 insert into #partidas      
 select distinct      
  cat.idPartida,      
  cat.agrupador,      
  cat.valor,      
  cat.orden,      
  cat.posicion,      
  cat.ordenFinal      
 from catalogos cat       
 where       
  cat.idPadre is not null      
      
      
--PROPIEDADES DE CONTRATO      
;with catalogos as(      
 select distinct     
  par.idPartida     idPartida,      
  prc.agrupador     agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'      
  isnull(prc.valor,'')   valor,      
  prc.idPadre      idPadre,      
  prc.orden      orden,      
  prc.posicion     posicion,      
  2        ordenFinal      
 from       
 [Partida].partida.Partida par      
 inner join [Partida].partida.PartidaPropiedadContrato tpc on par.idPartida = tpc.idPartida      
 inner join [Partida].partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato     
 inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
 inner join [Solicitud].Solicitud.Solicitud s on scp.idSolicitud = s.idSolicitud
 where       
  prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES      
  --and prc.numeroContrato = @numeroContrato      
  --and prc.idCliente = @idCLiente      
  AND par.idClase = @idClase      
  and par.activo = 1      
  AND s.idEstatusSolicitud not in ('CANCELADA','RECHAZADA')
 UNION ALL       
 --HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR      
 select      
  cat.idPartida     idPartida,      
  prc.agrupador     agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'      
  isnull(prc.valor,'')   valor,      
  prc.idPadre      idPadre,      
  prc.orden      orden,      
  prc.posicion     posicion,      
  2        ordenFinal      
 from [Partida].partida.PropiedadContrato prc       
 inner join catalogos cat on cat.idPadre = prc.idPropiedadContrato       
 WHERE prc.activo = 1      
 --and prc.numeroContrato = @numeroContrato      
 --and prc.idCliente = @idCLiente      
 )      
 insert into #partidas      
 select distinct      
  cat.idPartida,      
  cat.agrupador,      
  cat.valor,      
  cat.orden,      
  cat.posicion,      
  cat.ordenFinal      
 from catalogos cat       
 where       
  cat.idPadre is not null      
      
       
/**********************************************************************************************************************      
*********************************************************TAGS**********************************************************      
**********************************************************************************************************************/      
--PROPIEDADES GENERALES      
;with tags as(      
 select distinct      
  par.idPartida     idPartida,      
  prg.agrupador     agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'      
  prg.valor      valor,      
  prg.idPadre      idPadre,      
  prg.orden      orden,      
  prg.posicion     posicion,      
  0        ordenFinal      
 from       
 [Partida].partida.Partida par      
 inner join [Partida].partida.PartidaPropiedadGeneral tpg on par.idPartida = tpg.idPartida      
 inner join [Partida].partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral      
 inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
 inner join [Solicitud].Solicitud.Solicitud s on scp.idSolicitud = s.idSolicitud
 where prg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS      
 AND par.idClase = @idClase      
 and par.activo = 1      
 AND s.idEstatusSolicitud not in ('CANCELADA','RECHAZADA')
 UNION ALL       
 --HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR      
 select      
  tag.idPartida     idPartida,      
  prg.agrupador     agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'      
prg.valor      valor,      
  prg.idPadre      idPadre,      
  prg.orden      orden,      
  prg.posicion     posicion,      
  0        ordenFinal      
 from [Partida].partida.PropiedadGeneral prg       
 inner join [Partida].integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato       
 inner join tags tag on tag.idPadre = prg.idPropiedadGeneral      
 and prg.activo = 1      
 )      
 insert into #partidas      
 select distinct       
  idPartida,      
  agrupador,      
  (      
 SELECT STUFF(     
       
  (SELECT ', ' + valor      
  FROM tags tagsAux      
  WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags.idPartida and tagsAux.agrupador = tags.agrupador      
  FOR XML PATH ('')),      
 1,1, '') ) as valor, orden, posicion, ordenFinal from tags      
      
--PROPIEDADES CLASE      
;with tags as(      
 select  distinct     
  par.idPartida     idPartida,      
  prc.agrupador     agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'      
  isnull(prc.valor,'')   valor,      
  prc.idPadre      idPadre,      
  prc.orden      orden,      
  prc.posicion     posicion,      
  1        ordenFinal      
 from [Partida].partida.Partida par      
 inner join [Partida].partida.PartidaPropiedadClase tpc on par.idPartida = tpc.idPartida      
 inner join [Partida].partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase      
 inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
 inner join [Solicitud].Solicitud.Solicitud s on scp.idSolicitud = s.idSolicitud
 where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS      
 AND par.idClase = @idClase      
 and par.activo = 1      
 AND s.idEstatusSolicitud not in ('CANCELADA','RECHAZADA')
 UNION ALL       
 --HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR      
 select      
  tag.idPartida     idPartida,      
  prc.agrupador     agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'      
  isnull(prc.valor,'')   valor,      
  prc.idPadre      idPadre,      
  prc.orden      orden,      
  prc.posicion     posicion,      
  1        ordenFinal      
 from [Partida].partida.PropiedadClase prc       
 inner join tags tag on tag.idPadre = prc.idPropiedadClase      
 and prc.activo = 1      
 )      
 insert into #partidas      
 select distinct       
  idPartida,      
  agrupador,      
  (      
 SELECT STUFF(      
       
  (SELECT ', ' + valor      
  FROM tags tagsAux      
  WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags.idPartida and tagsAux.agrupador = tags.agrupador      
  FOR XML PATH ('')),      
 1,1, '') ) as valor, orden, posicion, ordenFinal from tags      
      
      
      
--PROPIEDADES CONTRATO      
;with tags as(      
 select distinct      
  par.idPartida     idPartida,      
  prc.agrupador     agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'      
  isnull(prc.valor,'')   valor,      
  prc.idPadre      idPadre,      
  prc.orden      orden,      
  prc.posicion     posicion,      
  2        ordenFinal      
 from [Partida].partida.Partida par      
 inner join [Partida].partida.PartidaPropiedadContrato tpc on par.idPartida = tpc.idPartida      
 inner join [Partida].partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato    
 inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
 inner join [Solicitud].Solicitud.Solicitud s on scp.idSolicitud = s.idSolicitud
 where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS      
 --and prc.numeroContrato = @numeroContrato      
 --and prc.idCliente = @idCLiente      
 AND par.idClase = @idClase      
 and par.activo = 1      
 AND s.idEstatusSolicitud not in ('CANCELADA','RECHAZADA')
 UNION ALL       
 --HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR      
 select      
  tag.idPartida     idPartida,      
  prc.agrupador     agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'      
  isnull(prc.valor,'')   valor,      
  prc.idPadre      idPadre,      
  prc.orden      orden,      
  prc.posicion     posicion,      
  2        ordenFinal      
 from [Partida].partida.PropiedadContrato prc       
 inner join tags tag on tag.idPadre = prc.idPropiedadContrato      
 --and prc.numeroContrato = @numeroContrato      
 --and prc.idCliente = @idCLiente      
 and prc.activo = 1      
 )      
 insert into #partidas      
 select distinct       
  idPartida,      
  agrupador,      
  (      
 SELECT STUFF(      
       
  (SELECT ', ' + valor      
  FROM tags tagsAux      
  WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags.idPartida and tagsAux.agrupador = tags.agrupador      
  FOR XML PATH ('')),      
 1,1, '') ) as valor, orden, posicion, ordenFinal from tags      
      
/**********************************************************************************************************************      
***************************************************VALORES FIJOS*******************************************************      
**********************************************************************************************************************/      
--PROPIEDADES GENERALES      
INSERT INTO #partidas      
select distinct      
 par.idPartida   idPartida,      
 prg.valor    agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'      
 tpg.valor    valor,      
 prg.orden    orden,      
 prg.posicion   posicion,      
 0      ordenFinal      
from [Partida].partida.Partida par       
inner join [Partida].partida.PartidaPropiedadGeneral tpg on tpg.idPartida = par.idPartida      
inner join [Partida].partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral      
inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
inner join [Solicitud].Solicitud.Solicitud s on scp.idSolicitud = s.idSolicitud
where      
 prg.idTipoValor = 'Unico'      
 AND par.idClase = @idClase      
 and par.activo = 1      
 AND s.idEstatusSolicitud not in ('CANCELADA','RECHAZADA')
      
--PROPIEDADES DE CLASE      
INSERT INTO #partidas      
select distinct      
 par.idPartida   idPartida,      
 prc.valor    agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'      
 tpc.valor    valor,      
 prc.orden    orden,      
 prc.posicion   posicion,      
 1      ordenFinal      
from [Partida].partida.Partida par      
inner join [Partida].partida.PartidaPropiedadClase tpc on tpc.idPartida = par.idPartida      
inner join [Partida].partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase     
inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
inner join [Solicitud].Solicitud.Solicitud s on scp.idSolicitud = s.idSolicitud
where      
 prc.idTipoValor = 'Unico'      
 AND par.idClase = @idClase      
 and par.activo = 1      
 AND s.idEstatusSolicitud not in ('CANCELADA','RECHAZADA')
--PROPIEDADES DE CONTRATO      
INSERT INTO #partidas      
select distinct      
 par.idPartida   idPartida,      
 prc.valor    agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'      
 tpc.valor    valor,      
 prc.orden    orden,      
 prc.posicion   posicion,      
 2      ordenFinal      
from [Partida].partida.Partida par      
inner join [Partida].partida.PartidaPropiedadContrato tpc on tpc.idPartida = par.idPartida      
inner join [Partida].partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato      
inner join [Solicitud].solicitud.SolicitudCotizacionPartida scp on scp.idPartida = par.idPartida and scp.rfcProveedor=@rfcProveedor
where      
 prc.idTipoValor = 'Unico'      
 --and prc.numeroContrato = @numeroContrato      
 AND par.idClase = @idClase      
 --and prc.idCliente = @idCLiente      
 and par.activo = 1      
      
      
      
/**********************************************************************************************************************      
*************************************************INSERTAMOS COSTOS*****************************************************      
**********************************************************************************************************************/      
      
INSERT INTO #partidas      
select distinct      
 par.idPartida    idPartida      
 ,tc.nombre     agrupador      
 --,isnull(parcos.costo,0)  valor      
 ,sc.costo valor
 ,1       orden      
 ,3       posicion      
 ,2      
from [Partida].tipoobjeto.TipoObjeto tob       
inner join [Partida].partida.Partida par on tob.idTipoObjeto = par.idTipoObjeto      
inner join [Partida].partida.PartidaCosto parcos on parcos.idPartida = par.idPartida       
inner join [Partida].partida.TipoCobro tc on parcos.idTipoCobro = tc.idTipoCobro    
inner join [Solicitud].SolicitudCotizacionPartida sc on sc.idPartida = par.idPartida and sc.rfcProveedor=@rfcProveedor
inner join [Solicitud].Solicitud.Solicitud s on sc.idSolicitud = s.idSolicitud
WHERE par.idClase = @idClase      
and par.activo = 1      





      
/**********************************************************************************************************************      
******************************************************PIVOTE***********************************************************      
**********************************************************************************************************************/      
declare       
 @columnsName varchar(max) = ''      
      
create table #propiedadesOrdenas      
 (      
  agrupador   varchar(500),      
  ordenFinal   int,      
  posicion   int,      
  orden    int      
 )      
      
insert into #propiedadesOrdenas      
select distinct       
 pr.agrupador,      
 min(pr.ordenFinal),      
 min(pr.posicion),      
 min(pr.orden)      
from #partidas pr group by pr.agrupador order by       
 min(pr.ordenFinal),      
 min(pr.posicion),      
 min(pr.orden)      
      
SET @columnsName = STUFF((SELECT ',' + QUOTENAME(prg.agrupador)       
      FROM #propiedadesOrdenas prg       
      FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')      
      
declare @query varchar(max)      
set @query = '      
 select      
  *,      
  0 Costo,      
  0 Venta      
 into #propiedadPartida      
 from      
 (select idPartida, agrupador, isnull(valor,0) valor from #partidas) t      
 pivot      
 (       
  MAX(valor)      
  for agrupador in (' + @columnsName + ')      
 ) AS resultado      
       
 SELECT [idCotizacion]      
    ,sc.[idSolicitud]      
    ,sc.[idTipoSolicitud]      
    ,sc.[idClase]      
    ,sc.[rfcEmpresa]      
    ,sc.[idCliente]      
    ,sc.[numeroContrato]      
    ,sc.[idProveedorEntidad]      
    ,sc.[rfcProveedor]      
    ,sc.[numeroCotizacion]      
    ,sc.[fechaAlta]      
    ,sc.[idUsuario]      
    into #cotizaciones      
   FROM [Solicitud].[solicitud].[SolicitudCotizacion] sc 
   INNER JOIN [Solicitud].[solicitud].[Solicitud] s on s.idSolicitud=sc.idSolicitud 
   where sc.idEstatusCotizacion NOT in (''CANCELADA'',''RECHAZADA'')   
   and s.idEstatusSolicitud NOT in (''CANCELADA'',''RECHAZADA'')
   and sc.rfcProveedor = ''' + @rfcProveedor +''' 
     
	IF NOT EXISTS(SELECT 1 FROM tempdb.INFORMATION_SCHEMA.COLUMNS 
						WHERE TABLE_NAME =(	SELECT	TOP 1 name FROM tempdb.sys.objects 
											WHERE	name like ''#propiedadPartida%'') 
											AND		column_name=''Foto'')

		BEGIN


			select * from Proveedor.proveedor.Proveedor pr 
			left join Proveedor.proveedor.ProveedorEntidad pe on pe.rfcProveedor = pr.rfcProveedor
			where pr.rfcProveedor = ''' + @rfcProveedor +''' 

		END

	ELSE
		BEGIN

  
			select      
				   [numeroCotizacion],      
				  SCP.[idCotizacion],      
				  SCP.[idSolicitud],      
				  SCP.[idTipoSolicitud],      
				  SCP.[idClase],      
				  SCP.[rfcEmpresa],      
				  SCP.[numeroContrato],      
				  SCP.[idCliente],      
				  SCP.[rfcProveedor],      
				  SCP.[idProveedorEntidad],      
				  SCP.[idObjeto],      
				  SCP.[idTipoObjeto],      
				  SCP.[idPartida],      
				  SCP.[costo],      
				  SCP.[venta],      
				  (SELECT [solicitud].[SEL_PARTIDA_UTILIDAD_FN](SCP.[idSolicitud],SCP.[idCotizacion],SCP.[idPartida])) AS puedeFacturar,
				  SCP.[idEstatusCotizacionPartida],      
				  SCP.[fechaEstatus],      
				  SCP.[cantidad],      
				  SP.[costoInicial],      
				  SP.[ventaInicial],      
				  ECP.[nombre] AS nombreEstatus,    
				 pp.Foto,
				  PP.[Instructivo],      
				  PP.[Descripción] AS Descripcion      
				  --, ({ fn CONCAT(COALESCE([U].[PrimerNombre], ''''), COALESCE([U].[SegundoNombre], ''''))}) AS [NombreCompleto]      
				  , (COALESCE([U].[PrimerNombre], '''') + '' '' + COALESCE([U].[SegundoNombre], '''')+ '' '' + COALESCE([U].[PrimerApellido], '''')+ '' '' + COALESCE([U].[SegundoApellido], '''')) AS [nombreCompleto]      
				  into #partidasCotizaciones2     
				   from #cotizaciones C      
				   inner join solicitud.SolicitudCotizacionPartida SCP on       
					SCP.idCotizacion = C.idCotizacion AND       
					SCP.idSolicitud = C.idSolicitud and      
					SCP.idTipoSolicitud = C.idTipoSolicitud and      
					SCP.idClase = C.idClase and      
					SCP.rfcEmpresa = C.rfcEmpresa and      
					SCP.idCliente = C.idCliente and      
					SCP.numeroContrato = C.numeroContrato and      
					SCP.rfcProveedor = C.rfcProveedor and      
					SCP.idProveedorEntidad = C.idProveedorEntidad      
				   inner join solicitud.SolicitudPartida SP on       
				  SCP.idSolicitud = SP.idSolicitud and      
				  SCP.idTipoSolicitud = SP.idTipoSolicitud and      
				  SCP.idClase = SP.idClase and      
				  SCP.rfcEmpresa = SP.rfcEmpresa and      
				  SCP.idCliente = SP.idCliente and      
				  SCP.numeroContrato = SP.numeroContrato and      
				  SCP.idObjeto = SP.idObjeto and      
				  SCP.idTipoObjeto = SP.idTipoObjeto and      
				  SCP.idPartida = SP.idPartida      
				 INNER JOIN #propiedadPartida PP on PP.idPartida = SP.idPartida      
				 INNER JOIN [solicitud].[EstatusCotizacionPartida] ECP ON ECP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida       
								AND SCP.idEstatusCotizacionPartida != ''CANCELADA''      
								AND SCP.idEstatusCotizacionPartida = ''APROBADA''      
				 INNER JOIN [Seguridad].[Catalogo].[Users] U ON U.Id = SCP.idUsuario  
	 
				 select scp.*      
				,pe.nombreComercial as nombreComercialPE      
				,pe.personaContacto as contactoPE      
				,pr.razonSocial      
				,scfd.uuid
				,CASE WHEN scp.puedeFacturar  = 0 THEN ''La orden no cubre el margen de utilidad mínimo establecido por el contrato, requiere un token de autorización.'' ELSE ''Disponible para facturar'' END motivoFacturacion
			  from #partidasCotizaciones2 scp       
			   inner join Proveedor.proveedor.Proveedor pr on scp.rfcProveedor = pr.rfcProveedor      
			   inner join Proveedor.proveedor.ProveedorEntidad pe on scp.idProveedorEntidad = pe.idProveedorEntidad      
			   left join cxp.solicitudcotizacionfacturadetalle scfd on scp.idPartida = scfd.idPartida and      
							 scp.idCotizacion = scfd.idCotizacion and      
							 scp.idSolicitud = scfd.idSolicitud and      
							 scp.rfcProveedor = scfd.rfcProveedor and      
							 scp.idTipoSolicitud = scfd.idTipoSolicitud and      
							 scp.idObjeto = scfd.idObjeto and      
							 scp.numeroContrato = scfd.numeroContrato and      
							 scp.idCliente = scfd.idCliente and      
							 scp.idClase = scfd.idClase      
			  where pr.rfcProveedor = ''' + @rfcProveedor +'''      
			  ORDER BY scp.puedeFacturar DESC    
	 
	END
 '      
      
PRINT  @query      
      
execute (@query)      
drop table #partidas      
drop table #propiedadesOrdenas      
END  

END
  


  --USE [Solicitud]

go

