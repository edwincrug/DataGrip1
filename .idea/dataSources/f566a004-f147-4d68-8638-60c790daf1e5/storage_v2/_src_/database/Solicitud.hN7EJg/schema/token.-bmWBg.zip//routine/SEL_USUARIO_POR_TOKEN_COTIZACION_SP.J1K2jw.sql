-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/07/2019>
-- Description:	    <Obtener los tokens por cotizacion, obtiene el usuario y sus permisos>
-- =============================================
-- EXEC [token].[SEL_USUARIO_POR_TOKEN_COTIZACION_SP] 148, 396, 'F5D219', 'Entrega', 55
-- =============================================
CREATE PROCEDURE [token].[SEL_USUARIO_POR_TOKEN_COTIZACION_SP]
(
    @idSolicitud        int
    ,@idCotizacion      int
    ,@token             varchar(6)
    ,@idPaso            varchar(50)
	,@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
DECLARE
    @idUsuarioExistente             int=0
    ,@idUsuarioUsaExistente         int=0
BEGIN

    SELECT 
        @idUsuarioExistente = [idUsuarioCrea]
        ,@idUsuarioUsaExistente = [idUsuarioUsa]
    FROM [Solicitud].[token].[Token] TT
    INNER JOIN [Solicitud].[token].[TokenCotizacion] TTC
        ON TT.idToken = TTC.idToken
    WHERE TTC.idSolicitud = @idSolicitud
        AND TTC.idCotizacion = @idCotizacion
        AND TT.token = @token
        AND TT.idPaso = @idPaso

    IF @idUsuarioExistente > 0
    BEGIN
        IF @idUsuarioUsaExistente > 0
        BEGIN
            PRINT 'El token ya ha sido utilizado anteriormente.'
            SET @err = 'El token ya ha sido utilizado anteriormente.'
            SELECT 0 idUsuario
        END
        ELSE
        BEGIN
            SELECT @idUsuarioExistente idUsuario
        END
    END
    ELSE
    BEGIN
        PRINT 'El token no existe'
        SET @err = 'El token no existe.'
        SELECT 0 idUsuario
    END
    
END
go

