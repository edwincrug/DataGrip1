-- =============================================
-- Author:		Martin Pacheco
-- Create date: .
-- Description:	.
-- =============================================
CREATE PROCEDURE [solicitud].[INS_SOLICITUD_COTIZACION_PARTIDA_SP]
	@idSolicitud		INT,
    @idTipoSolicitud	VARCHAR(10) = '',
    @idClase			vARCHAR(10) = '',
    @rfcEmpresa			VARCHAR(13) = '',
    @idCliente			INT,
    @numeroContrato		VARCHAR(50) = '',
    @idProveedorEntidad	INT,
    @rfcProveedor		VARCHAR(13) = '',
    @idUsuario			INT,
	@Partidas			XML,
	@err				VARCHAR(8000) OUTPUT	
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	 DECLARE
		@VI_One				INT = 1,
		@VI_Zero			INT = 0,
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en el stored: [INS_SOLICITUD_COTIZACION_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_ResultCount		INT = 0,
		@VI_IdSolicitud		INT = NULL,
		@VC_NOSOLICITUD		VARCHAR(20) = NULL

	INSERT INTO [solicitud].[SolicitudCotizacion] (
		 [idSolicitud]
		,[idTipoSolicitud]
		,[idClase]
		,[rfcEmpresa]
		,[idCliente]
		,[numeroContrato]
		,[idProveedorEntidad]
		,[rfcProveedor]
		,[numeroCotizacion]
		,[fechaAlta]
		,[idUsuario]
	) VALUES (
		 @idSolicitud
		,@idTipoSolicitud
		,@idClase
		,@rfcEmpresa
		,@idCliente
		,@numeroContrato
		,@idProveedorEntidad
		,@rfcProveedor
		,'01-01-01'
		,GETDATE()
		,@idUsuario
	)

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

