
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 28-08-2019
-- Description: Consulta trae tipos de monto
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[SEL_TIPOMONTO_SP] 6077,  @salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [fase].[SEL_TIPOMONTO_SP] 
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	SELECT 
		[idTipoMonto]
		,[nombre]
	FROM [Solicitud].[fase].[TipoMonto]

	
END
go

