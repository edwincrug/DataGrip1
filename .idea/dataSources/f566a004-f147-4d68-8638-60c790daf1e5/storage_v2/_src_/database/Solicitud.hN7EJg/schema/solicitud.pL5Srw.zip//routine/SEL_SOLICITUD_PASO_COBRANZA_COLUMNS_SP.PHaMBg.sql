
-- =============================================
-- Author: Adolfo Martinez
-- Create date: 05-07-2019
-- Description: Consulta devuelve solicitudes dependiendo el paso
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	30-07-2020	JLuis Lozada	Se agrego la columna Agrupamiento

	*- Testing...

	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[SEL_SOLICITUD_PASO_COBRANZA_COLUMNS_SP]  'Cobranza','Cobranza', 'Automovil', 2270,
	'<contratos><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato></contratos>',
	0, 0, 0, @salida OUTPUT;
	SELECT @salida AS salida;
	--385
*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_SOLICITUD_PASO_COBRANZA_COLUMNS_SP] 
	@idFase					varchar(50) = 'null',
	@idPaso					varchar(50) = 'null',
	@idClase				varchar(10),
	@idUsuario				INT,
	@contratos				XML,
	@idZona					INT = 0,
	@idObjeto				INT = 0,
	@idTipoObjeto			INT = 0,
	@err					varchar(500)OUTPUT
AS

BEGIN
	DECLARE @columnas TABLE(caption VARCHAR(100),datafield VARCHAR(100),datatype VARCHAR(100),orden INT, bloque INT)

	insert into @columnas VALUES('Número orden','numeroOrden','String',1,1)
	insert into @columnas VALUES('Agrupamiento','Agrupamiento','String',2,1)
	insert into @columnas values('RFC Empresa','rfcEmpresa','String',3,1)
	insert into @columnas values('Nombre contrato','nombreContrato','String',4,1)
	insert into @columnas values('Cliente','Cliente','String',5,1)
	insert into @columnas SELECT caption,campo,tipoDato,orden,2 FROM Common.reporte.Objeto WHERE idClase=@idClase ORDER BY orden ASC
	insert into @columnas VALUES('Zona','Zona','String',1,3)
	insert into @columnas VALUES('Fecha creación','fechaCreacion','Datetime',2,3)
	insert into @columnas VALUES('Fecha cita','fechaIngreso','Datetime',3,3)
	insert into @columnas VALUES('Tipo de orden','tipoDeOrden','String',4,3)
	insert into @columnas VALUES('Tipo de servicio','tipoDeServicio','String',5,3)
	insert into @columnas VALUES('Comentarios','Comentarios','String',6,3)
	insert into @columnas VALUES('Estatus','Estatus','String',7,3)
	insert into @columnas VALUES('Costo','Costo','number',8,3)
	insert into @columnas VALUES('Venta antes del descuento','ventaSnDesc','number',9,3)
	insert into @columnas VALUES('Monto Descuento','descuentoVenta','number',10,3)
	insert into @columnas VALUES('Venta','Venta','number',11,3)
	insert into @columnas VALUES('Agendó','Agendó','String',12,3)
	insert into @columnas VALUES('Tiempo transcurrido','tiempoTranscurrido','String',13,3)
	insert into @columnas SELECT caption,campo,tipoDato,orden,4 FROM Common.reporte.solicitud WHERE idClase=@idClase ORDER BY orden ASC
	insert into @columnas VALUES('RFC Proveedor','RFCProveedor','String',1,5)
	insert into @columnas VALUES('Razón social','razonSocial','String',2,5)
	insert into @columnas VALUES('Nombre comercial','nombreComercial','String',3,5)
	insert into @columnas VALUES('CXP Estatus provision','CXP_EstatusProvision','String',4,5)
	insert into @columnas VALUES('CXP No Compra','CXP_NoCompra','String',5,5)
	insert into @columnas VALUES('CXP Factura','CXP_Factura','String',6,5)
	insert into @columnas VALUES('CXC Factura','CXC_Factura','String',7,5)
	insert into @columnas VALUES('CXC Copade','CXC_Copade','String',8,5)
	insert into @columnas VALUES('CXC Importe','CXC_Importe','number',9,5)
	insert into @columnas VALUES('CXC Saldo','CXC_Saldo','number',10,5)
	insert into @columnas VALUES('CXC Fecha factura','CXC_FechaFactura','Date',11,5)

	SELECT * FROM @columnas ORDER BY bloque,orden ASC

END



--USE [Solicitud]
go

