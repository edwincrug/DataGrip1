
-- =============================================
-- Author: Adolfo Martinez
-- Create date: 18-06-2020
-- Description: Consulta devuelve proveedores
-- ============== Versionamiento ================
-- EXEC [solicitud].[SEL_OBJETO_GPSKM_COLUMNS_SP] 'Automovil',123,''
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_OBJETO_GPSKM_COLUMNS_SP] 
	@idClase			VARCHAR(10),
	@idUsuario			INT,
	@err				VARCHAR(500)OUTPUT
AS


BEGIN

	DECLARE @columnas TABLE(caption VARCHAR(100),datafield VARCHAR(100),datatype VARCHAR(100),orden INT, bloque INT)

	DECLARE @camposPivot VARCHAR(MAX),
			@sq			 VARCHAR(MAX)

	insert into @columnas values('Comprobante','idComprobanteRecepcion','String',1,1)
	insert into @columnas values('Solicitud','idSolicitud','String',2,1)
	insert into @columnas values('Objeto','idObjeto','String',3,1)
	insert into @columnas values('Odometro','KM','String',4,1)
	insert into @columnas values('GPS KM','gpsKM','String',5,1)
	insert into @columnas SELECT caption,campo,tipoDato,orden,2 FROM Common.reporte.objeto WHERE idClase=@idClase ORDER BY orden ASC


	SELECT * FROM @columnas ORDER BY bloque,orden ASC

END


--USE [Solicitud]
go

