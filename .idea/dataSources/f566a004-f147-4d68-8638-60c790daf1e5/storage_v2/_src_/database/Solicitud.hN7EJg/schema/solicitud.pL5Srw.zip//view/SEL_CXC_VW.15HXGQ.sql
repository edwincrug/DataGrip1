-- =============================================
-- Author:			<Adolfo Martinez>
-- Create date: 	<28/08/2020>
-- Description:	    <Vista para obtener datos de la cxc, la informacion esta a nivel de solicitud>
-- ============== Versionamiento ================  
/* 
SELECT * FROM [solicitud].[SEL_CXC_VW] WHERE idSolicitud=1760
*/

CREATE VIEW [solicitud].[SEL_CXC_VW]
AS	
	SELECT  
		F.idSolicitud,
		F.idTipoSolicitud,
		F.idClase,
		F.rfcEmpresa,
		F.idCliente,
		F.numeroContrato,
		F.idEstatus,
		FAB.numeroCopade AS 'Copade',
		FAB.CCP_IDDOCTO AS 'Factura',
		FAB.CCP_FECHADOCTO AS 'FechaFactura',
		FAB.CCP_FECHVEN AS 'FechaVencimiento',
		FAB.CCP_FECHPROMPAG AS 'FechaPago',
		FAB.IMPORTE AS 'Importe',
		FAB.SALDO AS 'Saldo'
	FROM [Solicitud].[cxc].[Factura] F
		JOIN [Solicitud].[cxc].[FacturaAgrupada] FA ON FA.idFactura = F.idFactura
		JOIN [Solicitud].[cxc].[FacturaAgrupadaBPRO] FAB ON FAB.numeroCopade = FA.numeroCopade
	GROUP BY F.idSolicitud,F.idTipoSolicitud,F.idClase,F.rfcEmpresa,F.idCliente,F.numeroContrato,F.idEstatus,FAB.numeroCopade,FAB.CCP_IDDOCTO,FAB.CCP_FECHADOCTO,FAB.CCP_FECHVEN,FAB.CCP_FECHPROMPAG,FAB.IMPORTE,FAB.SALDO

go

