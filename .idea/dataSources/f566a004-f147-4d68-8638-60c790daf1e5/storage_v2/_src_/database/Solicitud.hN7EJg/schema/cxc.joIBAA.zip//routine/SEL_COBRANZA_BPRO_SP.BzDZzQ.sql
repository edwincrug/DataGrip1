-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
/*
	EXEC cxc.SEL_COBRANZA_BPRO_SP

	update cxc.factura set idEstatus='PrefacturaGenerada'
	
	select * from cxc.factura
	select * from fase.SolicitudEstatusPaso where idSolicitud=179
	select * from cxc.facturaDetalle
*/

CREATE PROCEDURE cxc.SEL_COBRANZA_BPRO_SP
AS
BEGIN
	-- PrefacturaGenerada =>> FacturaEnviadaCliente

	DECLARE @txOrdenes TABLE (	idx INT IDENTITY(1,1),
								idSolicitud		INT, 
								idTipoSolicitud VARCHAR(10),
								idClase			VARCHAR(10),
								rfcEmpresa		VARCHAR(13),
								idCliente		INT, 
								numeroContrato  VARCHAR(50),
								numeroOrden		VARCHAR(50),
								idEstatus		VARCHAR(30))

	DECLARE @v_idx INT, 
			@v_numeroOrden		VARCHAR(50),
			@v_ote_ordenGlobal	VARCHAR(30),
			@v_idSolicitud		INT, 								
			@v_idTipoSolicitud	VARCHAR(10),
			@v_idClase			VARCHAR(10),
			@v_rfcEmpresa		VARCHAR(13),
			@v_idCliente		INT, 
			@v_numeroContrato	VARCHAR(50),
			@v_idEstatus		VARCHAR(30),
			@v_idEstatusDestino VARCHAR(50)
	
	INSERT INTO @txOrdenes(numeroOrden,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idEstatus)
	SELECT	distinct b.numeroOrden,a.idSolicitud,a.idTipoSolicitud,a.idClase,a.rfcEmpresa,a.idCliente,a.numeroContrato,a.idEstatus 
	FROM	cxc.Factura a, 
			solicitud.SolicitudObjeto b 
	WHERE	a.idSolicitud		=b.idSolicitud
	AND		a.idTipoSolicitud	=b.idTipoSolicitud
	AND		a.idClase			=b.idClase
	AND		a.rfcEmpresa		=b.rfcEmpresa
	AND		a.idCliente			=b.idCliente
	AND		a.numeroContrato	=b.numeroContrato
	AND		a.idEstatus			IN ('PrefacturaGenerada','FacturaEnviadaCliente','FacturaAbonada')
					   
	WHILE EXISTS (SELECT 1 FROM @txOrdenes)
		BEGIN
			SELECT	@v_idx=idx,
					@v_numeroOrden		=numeroOrden, 
					@v_idSolicitud		=idSolicitud,
					@v_idTipoSolicitud	=idTipoSolicitud,
					@v_idClase			=idClase,
					@v_rfcEmpresa		=rfcEmpresa,
					@v_idCliente		=idCliente,
					@v_numeroContrato	=numeroContrato,
					@v_idEstatus		=idEstatus
			FROM	@txOrdenes
			
			--Recuperamos el campo ote_ordenGlobal de la tabla ADE_ORDSERENC en funcion al numero de orden
			SELECT  TOP 1 
					@v_ote_ordenGlobal=OTE_ORDENGLOBAL 
			FROM	ASEPROTSISCOV3.DBO.ADE_ORDSERENC 
			WHERE	OTE_ORDENANDRADE	=@v_numeroOrden 
			AND		(OTE_ORDENGLOBAL IS NOT NULL OR OTE_ORDENGLOBAL<>'' OR LEN(OTE_ORDENGLOBAL)>0 )


			IF @v_idEstatus='PrefacturaGenerada'
				BEGIN
					IF EXISTS(	SELECT 1 
						FROM	ASEPROTSISCOV3.DBO.ADE_COPADE 
						WHERE	COP_ORDENGLOBAL=@v_OTE_ORDENGLOBAL
						AND     COP_IDDOCTO IS NOT NULL )
						BEGIN
							--Actualizamos el estatus de la tabla cxc.factura a FacturaEnviadaCliente
							UPDATE cxc.Factura		SET idEstatus='FacturaEnviadaCliente'
							WHERE idSolicitud		=@v_idSolicitud
							AND   idTipoSolicitud	=@v_idTipoSolicitud 
							AND   idClase			=@v_idClase
							AND   rfcEmpresa		=@v_rfcEmpresa
							AND   idCliente			=@v_idCliente
							AND   numeroContrato	=@v_numeroContrato
							AND   idEstatus			=@v_idEstatus

							EXEC  solicitud.UPD_SOLICITUD_AVANZAORDEN_SP @v_idSolicitud,@v_idTipoSolicitud,@v_idClase,@v_rfcEmpresa,@v_idCliente,@v_numeroContrato,6148,''
						END
				END
			IF @v_idEstatus='FacturaEnviadaCliente'
				BEGIN
					IF EXISTS(	SELECT 1 
								FROM	ASEPROTSISCOV3.DBO.ADE_COPADE 
								WHERE	COP_ORDENGLOBAL=@v_OTE_ORDENGLOBAL
								AND     COP_CARGO IS NOT NULL)
						BEGIN
							--Actualizamos el estatus de la tabla cxc.factura a FacturaAbonada
							UPDATE cxc.Factura		SET idEstatus='FacturaAbonada'
							WHERE idSolicitud		=@v_idSolicitud
							AND   idTipoSolicitud	=@v_idTipoSolicitud 
							AND   idClase			=@v_idClase
							AND   rfcEmpresa		=@v_rfcEmpresa
							AND   idCliente			=@v_idCliente
							AND   numeroContrato	=@v_numeroContrato
							AND   idEstatus			=@v_idEstatus
							EXEC  solicitud.UPD_SOLICITUD_AVANZAORDEN_SP @v_idSolicitud,@v_idTipoSolicitud,@v_idClase,@v_rfcEmpresa,@v_idCliente,@v_numeroContrato,6148,''
						END
				END
			IF @v_idEstatus='FacturaAbonada'
				BEGIN
					IF EXISTS(	SELECT 1 
								FROM	ASEPROTSISCOV3.DBO.ADE_COPADE 
								WHERE	COP_ORDENGLOBAL=@v_OTE_ORDENGLOBAL
								AND     COP_CARGO IS NOT NULL
								AND     COP_IDDOCTO IS NOT NULL )
						BEGIN
							--Actualizamos el estatus de la tabla cxc.factura a Finalizada
							UPDATE cxc.Factura		SET idEstatus='Finalizada'
							WHERE idSolicitud		=@v_idSolicitud
							AND   idTipoSolicitud	=@v_idTipoSolicitud 
							AND   idClase			=@v_idClase
							AND   rfcEmpresa		=@v_rfcEmpresa
							AND   idCliente			=@v_idCliente
							AND   numeroContrato	=@v_numeroContrato
							AND   idEstatus			=@v_idEstatus
							EXEC  solicitud.UPD_SOLICITUD_AVANZAORDEN_SP @v_idSolicitud,@v_idTipoSolicitud,@v_idClase,@v_rfcEmpresa,@v_idCliente,@v_numeroContrato,6148,''
						END
				END
			DELETE FROM @txOrdenes WHERE idx=@v_idx
		END
	/*
	SELECT * FROM cxc.Factura
	SELECT * FROM cxc.FacturaDetalle
	select * FROM ASEPROTSISCOV3.DBO.ADE_ORDSERENC
	select * FROM ASEPROTSISCOV3.DBO.ADE_ORDSERDET
	select * FROM ASEPROTSISCOV3.DBO.ADE_COPADE
	*/
END
go

