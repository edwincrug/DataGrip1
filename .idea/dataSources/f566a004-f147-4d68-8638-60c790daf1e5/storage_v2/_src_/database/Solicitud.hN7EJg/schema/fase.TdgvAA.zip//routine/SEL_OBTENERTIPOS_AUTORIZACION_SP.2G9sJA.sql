
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <10/12/2020>
-- Description:	<consulta el catalogo de tipos de autorizacion>
/*
	EXEC [fase].[SEL_OBTENERTIPOS_AUTORIZACION_SP] 6282,NULL
*/
-- =============================================
create PROCEDURE [fase].[SEL_OBTENERTIPOS_AUTORIZACION_SP]
@idUsuario INT,
@err		VARCHAR(500)OUTPUT  
AS
BEGIN

	SELECT	idTipoAutorizacion value,descripcion text 
	FROM	fase.tipoAutorizacion
	WHERE	activo=1
END
go

