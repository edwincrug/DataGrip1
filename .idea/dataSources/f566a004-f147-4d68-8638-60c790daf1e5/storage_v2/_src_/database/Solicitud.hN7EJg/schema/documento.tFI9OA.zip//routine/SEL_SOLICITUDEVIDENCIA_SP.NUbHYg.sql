
-- =============================================
-- Author: Gerardo Zamudio González
-- Create date: 24-06-2019
-- Description: Obtiene la evidencia de una solicitud (Documentos)
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [documento].[SEL_SOLICITUDEVIDENCIA_SP]  'DIC0503123MD3', 'Automovil' ,78, '123PEMEX', 29, 2, NULL;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [documento].[SEL_SOLICITUDEVIDENCIA_SP]
	@rfcEmpresa				varchar(13),
	@idClase				varchar(10),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	@idSolicitud			int,
	@idUsuario				int,
	@err					varchar(500)OUTPUT
AS


BEGIN

SELECT [idSolicitud]
      ,[idTipoSolicitud]
      ,[idClase]
      ,[rfcEmpresa]
      ,[idCliente]
      ,[numeroContrato]
      ,[idSolicitudEvidencia]
      ,[idFileServer]
  FROM [Solicitud].[documento].[SolicitudEvidencia]
  WHERE idSolicitud = @idSolicitud AND
  idClase = @idClase AND
  rfcEmpresa = @rfcEmpresa AND
  idCliente = @idCliente AND
  numeroContrato = @numeroContrato
END
go

