
-- =============================================
-- Author: Edgar Mendoza
-- Create date: 28-05-2020
-- Description: Elimina la evidencia de una solicitud (Documentos)
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [documento].[DEL_SOLICITUDEVIDENCIA_SP]  
	'ASE0508051B6', 
	'Automovil' ,
	185, 
	'43', 
	518, 
	6368, 
	'<Ids><idDocumento>22183</idDocumento><idDocumento>22184</idDocumento></Ids>',
	NULL;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [documento].[DEL_SOLICITUDEVIDENCIA_SP]
	@rfcEmpresa				varchar(13),
	@idClase				varchar(10),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	@idSolicitud			int,
	@idUsuario				int,
	@data					XML,
	@err					varchar(500)OUTPUT
AS


BEGIN

	 DECLARE @tbl_documentos AS TABLE(
        idDocumento                   INT

    )

    INSERT INTO @tbl_documentos(idDocumento)

    SELECT
		ParamValues.col.value('.','INT')
        FROM @data.nodes('/Ids/idDocumento') AS ParamValues(col)

	DELETE
	  FROM [Solicitud].[documento].[SolicitudEvidencia]
	  WHERE idSolicitud = @idSolicitud AND
	  idClase = @idClase AND
	  rfcEmpresa = @rfcEmpresa AND
	  idCliente = @idCliente AND
	  numeroContrato = @numeroContrato AND
	  idFileServer IN (SELECT idDocumento FROM @tbl_documentos)
END


SELECT * FROM [Solicitud].[documento].[SolicitudEvidencia] WHERE idSolicitud = 518
go

