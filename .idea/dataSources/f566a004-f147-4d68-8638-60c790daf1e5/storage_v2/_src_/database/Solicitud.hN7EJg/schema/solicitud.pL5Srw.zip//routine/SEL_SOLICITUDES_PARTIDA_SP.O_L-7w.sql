-- =============================================  
-- Author: Jose Luis Lozada Guerrero
-- Create date: 05-11-2020  
-- Description: Obtiene las solicitudes que han usado esa partida
-- ============== Versionamiento ================  
/*  
	Fecha		Autor			Descripción   
  
	*- Testing...  
	EXEC [solicitud].SEL_SOLICITUDES_PARTIDA_SP 'ASE0508051B6',185,'127','Automovil',767282,128,12353,6282,null
	
	select * from solicitud.solicitud.solicitudObjeto where numeroOrden='150-1164-10558'
*/
CREATE PROCEDURE [solicitud].[SEL_SOLICITUDES_PARTIDA_SP] 
@rfcEmpresa VARCHAR(13),
@idCliente	INT,
@numeroContrato VARCHAR(50),
@idClase VARCHAR(10),
@idPartida INT,
@idTipoObjeto INT,
@idObjeto INT,
@idUsuario INT,
@err VARCHAR(5000) OUTPUT
AS
BEGIN
	SELECT	DISTINCT SCP.idSolicitud,SSO.numeroOrden,CON.idFileAvatar idLogoContrato, SCP.idTipoSolicitud,SCP.rfcEmpresa,
			SCP.idCliente,SCP.numeroContrato,SCP.idObjeto,SCP.idTipoObjeto,0 esMultiple
			
	FROM	[solicitud].[SolicitudCotizacionPartida] SCP 
	INNER	JOIN [solicitud].[SolicitudObjeto] SSO
	ON		SCP.idSolicitud=SSO.idSolicitud
	AND     SCP.idTipoSolicitud		= SSO.idTipoSolicitud
	AND		SCP.idClase				= SSO.idClase
	AND		SCP.rfcEmpresa			= SSO.rfcEmpresa
	AND		SCP.idCliente			= SSO.idCliente
	AND		SCP.numeroContrato		= SSO.numeroContrato
	INNER	JOIN Cliente.cliente.Contrato CON 
	ON		CON.rfcEmpresa			= SCP.rfcEmpresa
	AND		CON.idCliente			= SCP.idCliente
	AND		CON.numeroContrato		= SCP.numeroContrato
	INNER	JOIN [solicitud].[solicitud] SOL 
	ON		SCP.idSolicitud			= SOL.idSolicitud
	AND     SCP.idTipoSolicitud		= SOL.idTipoSolicitud
	AND     SCP.idClase				= SOL.idClase
	AND     SCP.rfcEmpresa			= SOL.rfcEmpresa
	AND		SCP.idCliente			= SOL.idCliente
	AND     SCP.numeroContrato		= SOL.numeroContrato
	AND     SOL.idEstatusSolicitud	NOT IN ('CANCELADA','RECHAZADA')
	INNER   JOIN [partida].[partida].[partida] pa on pa.idPartida=scp.idPartida and pa.idTipoObjeto=scp.idTipoObjeto AND pa.idPartidaEstatus='ACT'
	WHERE	SCP.idPartida		= @idPartida 
	AND		SCP.idObjeto		= @idObjeto
	AND		SCP.idTipoObjeto	= @idTipoObjeto
	AND		SCP.idEstatusCotizacionPartida='APROBADA'
	AND		SCP.rfcEmpresa		= @rfcEmpresa
	AND		SCP.idCliente		= @idCliente 
	AND		SCP.numeroContrato	= @numeroContrato
	AND		SCP.idClase			= @idClase

END
go

