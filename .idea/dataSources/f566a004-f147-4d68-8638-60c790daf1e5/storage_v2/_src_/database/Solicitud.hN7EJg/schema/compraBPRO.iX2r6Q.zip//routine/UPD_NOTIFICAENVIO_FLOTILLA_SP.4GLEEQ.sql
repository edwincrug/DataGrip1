
-- =============================================
-- Author:		<JLuis Lozada Guerrero>
-- Create date: <13/10/2020>
-- Description:	<Procedimiento que recupera los datos que se envian al servicio de flotillas>
-- =============================================
/*
	Testing.....
	EXEC [compraBPRO].UPD_NOTIFICAENVIO_FLOTILLA_SP 1205,'Flotilla','Compra','ASE0508051B6',222,'C002',1,'Cotizacion actualizada con numero de orden: 1-1362-13549',6282,null
*/
CREATE PROCEDURE [compraBPRO].[UPD_NOTIFICAENVIO_FLOTILLA_SP]
@idSolicitud		INT,
@idTipoSolicitud	VARCHAR(50),
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@Succes				INT,
@Mensaje			VARCHAR(1000),
@observaciones		VARCHAR(1000),
@idUsuario			INT = 0,
@err				VARCHAR(8000) OUTPUT	
AS
BEGIN
	-- SELECT * FROM compraBPRO.SolicitudNotificacionFlotilla

	UPDATE	compraBPRO.SolicitudNotificacionFlotilla
	SET		success	=@Succes,
			message	=@Mensaje,
			observaciones=@observaciones
	WHERE	idSolicitud		=@idSolicitud
	AND		idTipoSolicitud	=@idTipoSolicitud
	AND		idClase			=@idClase
	AND		rfcEmpresa		=@rfcEmpresa
	AND		idCliente		=@idCliente
	AND		numeroContrato	=@numeroContrato

END
go

