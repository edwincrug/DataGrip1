
--use solicitud
-- =============================================
-- Author: Edgar Mendoza
-- Create date: 08/07/2020
-- Description:	Trae facturas cargadas de un proveedor
-- EXEC [cxp].[SEL_FACTURA_CONSOLIDADA_SP] 'CME720930GM9',115,''
-- EXEC [cxp].[SEL_FACTURA_CONSOLIDADA_SP] 'AUT661101NZ5',115,''
-- =============================================
CREATE PROCEDURE [cxp].[SEL_FACTURA_CONSOLIDADA_SP]
@rfcProveedor VARCHAR(13),
@idUsuario INT,
@err VARCHAR(8000) = '' OUTPUT	
AS
BEGIN

	select distinct
		SO.numeroOrden,
		SC.numeroCotizacion, 
		(select [Objeto].[objeto].[getPropiedadObjeto]  (SO.idObjeto, 'VIN', 'clase','Automovil')) VIN,
		(SELECT  PARTIDA.[partida].[SEL_PROPIEDADTIPOOBJETO_FN]('Automovil','Marca',SO.idTipoObjeto)) marca,
		(SELECT  PARTIDA.[partida].[SEL_PROPIEDADTIPOOBJETO_FN]('Automovil','Submarca',SO.idTipoObjeto)) subMarca,
		C.nombre contrato,
		TCV.subTotalCosto AS subTotalCotizacion,
		'SISCO V3' AS Version
		,SCFDC.idCotizacion
		,SCFDC.idSolicitud
		,SC.idProveedorEntidad
		,TCV.IVACosto IVACosto
		,TCV.totalCosto totalCosto
		,OTE_FACTURACOMPRA as facturaVirtual
		,P.descripcion AS paso
	from [cxp].[SolicitudCotizacionFacturaDetallePorConsolidar] SCFDC
	inner join [cxc].[FacturaBPRO] FBPRO ON FBPRO.idSolicitud = SCFDC.idSolicitud and FBPRO.idCotizacion = SCFDC.idCotizacion
	left join [cxp].[SolicitudCotizacionFacturaDetalle] SCFD on SCFD.idsolicitud = SCFDC.idsolicitud and SCFD.idCotizacion = SCFDC.idCotizacion
	inner join [solicitud].[SolicitudCotizacion] SC on SC.idCotizacion = SCFDC.idCotizacion
	INNER JOIN [Cliente].cliente.Contrato C ON C.numeroContrato = SC.numeroContrato AND C.idCliente = SC.idCliente AND C.rfcEmpresa = SC.rfcEmpresa AND C.idClase = SC.idClase AND C.activo = 1
	inner join [solicitud].[SolicitudObjeto] SO on SO.idSolicitud = SCFDC.idSolicitud
	INNER JOIN [solicitud].[Solicitud] SOL ON SOL.idSolicitud = SO.idSolicitud
	INNER JOIN fase.Paso P ON P.idPaso = SOL.idPaso AND P.idTipoSolicitud = SOL.idTipoSolicitud AND P.idClase = SOL.idClase
	inner join objeto.objeto.objetopropiedadclase OPC ON OPC.idobjeto = SCFDC.idobjeto 
	inner join [solicitud].[SEL_TOTALES_COTIZACION_VW] TCV ON TCV.idCotizacion =  SCFDC.idCotizacion
	where SCFD.idCotizacion is null 
	and SCFDC.rfcProveedor = @rfcProveedor
	and FBPRO.activo = 1

	union all

	SELECT 
	CotizacionCoincidencia.numeroOrden,
	CotizacionCoincidencia.numeroCotizacion,
	CotizacionCoincidencia.vin AS VIN,
	CotizacionCoincidencia.Marca AS marca,
	CotizacionCoincidencia.subMarca AS subMarca,
	CotizacionCoincidencia.contrato,
	CotizacionCoincidencia.montoCotizacion as subTotalCotizacion,
	'SISCO V2' AS Version
	,CotizacionCoincidencia.idCotizacion
	,CotizacionCoincidencia.idOrden As idSolicitud
	,0 AS idProveedorEntidad
	,(CotizacionCoincidencia.montoCotizacion * 0.16) AS IVACosto
	,(CotizacionCoincidencia.montoCotizacion * 1.16) totalCosto
	,numFactura AS facturaVirtual
	,CotizacionCoincidencia.nombreEstatusOrden AS paso
	FROM
		(
			select 
				ord.numeroOrden
				,c.numeroCotizacion
				,un.vin
				,SUB.nombre subMarca
				,CON.descripcion contrato
				,M.nombre Marca
				,(select ASEPROT.[dbo].[SEL_PRECIO_COSTO_COT_V2_V3_FN](C.idCotizacion)) as montoCotizacion
				,c.idCotizacion
				,ord.idOrden
				,FC.numFactura
				,EO.nombreEstatusOrden
			from ASEPROT.dbo.Ordenes ord
				INNER JOIN ASEPROT.dbo.Cotizaciones C ON C.idOrden = ORD.idOrden
				LEFT JOIN ASEPROT.[dbo].[facturaCotizacion] FC ON FC.idCotizacion = C.idCotizacion
				INNER JOIN DBO.ORDENES_EXISTEN_BPRO_VW OEV ON OEV.OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS = C.numeroCotizacion COLLATE Modern_Spanish_CI_AS
				inner join ASEPROT.dbo.EstatusOrdenes eo on eo.idEstatusOrden = ord.idEstatusOrden
				join ASEPROT.dbo.Unidades un on un.idUnidad = ord.idUnidad
				join ASEPROT.dbo.ContratoOperacion CO ON CO.idOperacion = un.idOperacion
				join Partidas.dbo.Contrato CON on CON.idContrato = CO.idContrato
				join Partidas.dbo.Unidad PUN ON PUN.idUnidad = un.idTipoUnidad
				join Partidas.dbo.SubMarca SUB ON SUB.idSubMarca = PUN.idSubMarca
				join Partidas.dbo.Marca M ON M.idMarca = SUB.idMarca
				join Partidas..Zona z on z.idZona = ord.idZona
				left join ASEPROT.dbo.PresupuestoOrden pro on pro.idOrden = ord.idOrden
				left join ASEPROT.dbo.Presupuestos pr on pr.idPresupuesto = pro.idPresupuesto
				left join Partidas..Proveedor P on p.idProveedor = c.idTaller
				INNER JOIN partidas.[dbo].[ProveedorEncabezado]  PE ON PE.idProveedorEncabezado = P.idProveedorEncabezado
			where ord.idEstatusOrden not in (13) and C.idEstatusCotizacion not in(4,5)
			--and PE.RFC = @rfcProveedor
			and uuid like 'N/A%'
			and C.idCotizacion not in(
				SELECT idCotizacion FROM ASEPROT.dbo.DatosFacturaConcentraCotizacion
			) 
		) 
	AS CotizacionCoincidencia   
END



go

