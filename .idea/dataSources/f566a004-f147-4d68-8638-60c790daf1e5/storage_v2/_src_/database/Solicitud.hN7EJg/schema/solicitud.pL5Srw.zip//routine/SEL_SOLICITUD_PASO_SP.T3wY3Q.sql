


-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 05-07-2019
-- Description: Consulta devuelve solicitudes dependiendo el paso
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	19-08-2019	JEHR	Agrego columnas de siscoV2

		DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[SEL_SOLICITUD_PASO_SP]  'Cobranza','Cobranza', 'Automovil', 2270,
	'<contratos><contrato><numeroContrato>127</numeroContrato><idCliente>216</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>219</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato></contratos>',
	0, 0, 0, @salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [solicitud].[SEL_SOLICITUD_PASO_SP] 
	@idFase					varchar(50) = 'null',
	@idPaso					varchar(50) = 'null',
	@idClase				varchar(10),
	@idUsuario				INT,
	@contratos				XML,
	@idZona					INT = 0,
	@idObjeto				INT = 0,
	@idTipoObjeto			INT = 0,
	@err					varchar(500)OUTPUT
AS


BEGIN

	DECLARE @tbl_solicitudes AS TABLE(
			idSolicitud			INT,
			color				VARCHAR(20),
			idPaso				VARCHAR(50),
			idFase				VARCHAR(50),
			fechaIngreso		DATETIME,
			fechaCita			DATETIME,
			numero				varchar(50),
			comentarios			VARCHAR(MAX),
			idZona				INT,
			pasoNombre			VARCHAR(500),
			zonaNombre			VARCHAR(500),
			cliente				VARCHAR(500),
			tipoSolicitud		VARCHAR(250),
			idTipoSolicitud		VARCHAR(10),
			rfcEmpresa			VARCHAR(13),
			idCliente			INT,
			numeroContrato		VARCHAR(50),
			idObjeto			INT,
			idTipoObjeto		INT,
			idLogoContrato		INT,
			costo				FLOAT,
			venta				FLOAT,
			numeroEconomico		VARCHAR(500),
			taller				VARCHAR(500),
			estatusProvision	VARCHAR(500),
			agendo				VARCHAR(500),
			tiempoA				INT,
			tipoSolPartida		VARCHAR(500),
			OTE_IDENT			VARCHAR(300)
		)

	DECLARE @tbl_contratos AS TABLE(
			numeroContrato			VARCHAR(50),
			idCliente				INT,
			rfc						VARCHAR(13)				
		)


	INSERT INTO @tbl_contratos
	SELECT
		ParamValues.col.value('numeroContrato[1]','varchar(50)'),
		ParamValues.col.value('idCliente[1]','int'),
        ParamValues.col.value('rfcEmpresa[1]','varchar(13)')
        FROM @contratos.nodes('contratos/contrato') AS ParamValues(col)

		INSERT INTO @tbl_solicitudes
		SELECT 	*
		FROM(
				SELECT	--DISTINCT
						SOL.idSolicitud,FP.color,SEP.idPaso,SEP.idFase,SEP.fechaIngreso,SOL.fechaCreacion,SSO.numeroOrden,SOL.comentarios,CCO.idContratoZona,FP.nombre,CGC.descripcion,
						CCC.nombre cliente,STS.nombre tipoSolicitud,STS.idTipoSolicitud,SEP.rfcEmpresa,SEP.idCliente,SEP.numeroContrato,SSO.idObjeto,SSO.idTipoObjeto,CLCO.idFileAvatar,
						(	SELECT	ISNULL(SUM(costo * cantidad),0) from solicitud.solicitudcotizacionpartida SCP
							LEFT	JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida 
							WHERE	idSolicitud						= SOL.idSolicitud
							AND		EP.idEstatusCotizacionPartida	NOT IN ('CANCELADA', 'RECHAZADA')) montoC,
						(	SELECT	ISNULL(SUM(venta * cantidad),0) from solicitud.solicitudcotizacionpartida SCP
							LEFT	JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida 
							WHERE	idSolicitud = SOL.idSolicitud
							AND		EP.idEstatusCotizacionPartida  NOT IN ('CANCELADA', 'RECHAZADA')) montoV,
						[Objeto].[objeto].[getPropiedadObjeto](SSO.idObjeto,'NumeroEconomico','clase',SSO.idClase) AS numeroEconomico,
						Solicitud.solicitud.SEL_TALLERES_FN(SSO.idSolicitud) AS taller,
						ISNULL((	SELECT	TOP 1 
											idEstatus 
									FROM	solicitud.cxc.factura fa 
									WHERE	fa.idSolicitud		=sol.idSolicitud 
									AND     fa.idTipoSolicitud	=sol.idTipoSolicitud
									AND		fa.idClase			=sol.idClase   
									AND     fa.rfcEmpresa		=sol.rfcEmpresa
									AND     fa.idCliente		=sol.idCliente
									AND     fa.numeroContrato	=sol.numeroContrato
									),'Sin provisionar') 'estatusProvision',
						PrimerNombre + ' ' + SegundoNombre + ' ' + PrimerApellido + ' ' + SegundoApellido AS agendo,
						[solicitud].[SEL_DIASSOL_FN](SSO.idSolicitud) AS tiempoA,
						CASE	WHEN @idClase = 'Automovil' THEN [solicitud].[SEL_TIPOMANTENIMIENTO_FN](SSO.idSolicitud) ELSE STS.nombre END AS tipoSolPartida,
						[solicitud].[SEL_OBTENERIDSCOMPRA_FN](sol.idSolicitud,sol.idTipoSolicitud,sol.idClase,sol.rfcEmpresa,sol.idCliente,sol.numeroContrato) AS 'OTE_IDENT'
				FROM	[fase].[Paso] FP  
				LEFT	JOIN fase.solicitudestatuspaso SEP ON FP.idPaso = SEP.idPaso AND FP.idClase = SEP.idClase AND FP.idTipoSolicitud = SEP.idTipoSolicitud
				LEFT	JOIN solicitud.solicitud SOL ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase 
				LEFT	JOIN [solicitud].[TipoSolicitud] STS ON STS.idTipoSolicitud = SOL.idTipoSolicitud
				LEFT	JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud
				LEFT	JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto
				LEFT	JOIN [cliente].[cliente].[Cliente] CCC ON CCC.idCliente = CCO.idCliente
				LEFT	JOIN [common].[gerencia].[ContratoZona] CGC ON CGC.idContratoZona = CCO.idContratoZona 
				LEFT	JOIN [Seguridad].[Catalogo].[Users] SCU ON SCU.Id = SOL.idUsuario
				INNER	JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa
				LEFT	JOIN [cliente].[cliente].[Contrato] CLCO ON CLCO.rfcEMpresa = SOL.rfcEmpresa AND CLCO.idCliente = SOL.idCliente AND CLCO.numeroContrato = SOL.numeroContrato
				WHERE	SEP.idClase = @idClase
				AND		SOL.idEstatusSolicitud = 'ACTIVA'
				AND		SEP.fechaSalida is null

				UNION ALL

				SELECT	--DISTINCT
						SOL.idSolicitud,FP.color,CEP.idPaso,CEP.idFase,CEP.fechaIngreso,SOL.fechaCreacion,SSO.numeroOrden,SOL.comentarios,CCO.idContratoZona,FP.nombre,CGC.descripcion,
						CCC.nombre cliente,STS.nombre tipoSolicitud,STS.idTipoSolicitud,CEP.rfcEmpresa,CEP.idCliente,CEP.numeroContrato,SSO.idObjeto,SSO.idTipoObjeto,CLCO.idFileAvatar,
						(	SELECT	ISNULL(SUM(costo * cantidad),0) from solicitud.solicitudcotizacionpartida SCP
							LEFT	JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida 
							WHERE	idSolicitud = SOL.idSolicitud
							AND		EP.idEstatusCotizacionPartida  NOT IN ('CANCELADA', 'RECHAZADA')) montoC,
						(	SELECT	ISNULL(SUM(venta * cantidad),0) from solicitud.solicitudcotizacionpartida SCP
							LEFT	JOIN [Solicitud].[solicitud].[EstatusCotizacionPartida] EP ON EP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida 
							WHERE	idSolicitud = SOL.idSolicitud
							AND		EP.idEstatusCotizacionPartida NOT IN ('CANCELADA', 'RECHAZADA')) montoV,
						[Objeto].[objeto].[getPropiedadObjeto](SSO.idObjeto,'NumeroEconomico','clase',SSO.idClase) AS numeroEconomico,
						Solicitud.solicitud.SEL_TALLERES_FN(SSO.idSolicitud) AS taller,
						ISNULL((	SELECT	TOP 1 
											idEstatus 
									FROM	solicitud.cxc.factura fa 
									WHERE	fa.idSolicitud		=sol.idSolicitud 
									AND     fa.idTipoSolicitud	=sol.idTipoSolicitud
									AND		fa.idClase			=sol.idClase   
									AND     fa.rfcEmpresa		=sol.rfcEmpresa
									AND     fa.idCliente		=sol.idCliente
									AND     fa.numeroContrato	=sol.numeroContrato
									),'Sin provisionar') 'estatusProvision',
						PrimerNombre + ' ' + SegundoNombre + ' ' + PrimerApellido + ' ' + SegundoApellido AS agendo,
						[solicitud].[SEL_DIASSOL_FN](SSO.idSolicitud) AS tiempoA,
						CASE
							WHEN @idClase = 'Automovil' THEN [solicitud].[SEL_TIPOMANTENIMIENTO_FN](SSO.idSolicitud) 
							ELSE STS.nombre END AS tipoSolPartida,
						[solicitud].[SEL_OBTENERIDSCOMPRA_FN](sol.idSolicitud,sol.idTipoSolicitud,sol.idClase,sol.rfcEmpresa,sol.idCliente,sol.numeroContrato) AS 'OTE_IDENT'
				FROM [faseContrato].[Paso] FP 
				LEFT JOIN  [faseContrato].[SolicitudEstatusPaso] CEP ON FP.idPaso = CEP.idPaso AND FP.idClase = CEP.idClase AND FP.idTipoSolicitud = CEP.idTipoSolicitud
				LEFT JOIN solicitud.solicitud SOL ON SOL.idSolicitud = CEP.idSolicitud AND SOL.idClase = CEP.idClase 
				LEFT JOIN [solicitud].[TipoSolicitud] STS ON STS.idTipoSolicitud = SOL.idTipoSolicitud
				LEFT JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud
				LEFT JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto
				LEFT JOIN [cliente].[cliente].[Cliente] CCC ON CCC.idCliente = CCO.idCliente
				LEFT JOIN [common].[gerencia].[ContratoZona] CGC ON CGC.idContratoZona = CCO.idContratoZona
				LEFT JOIN [Seguridad].[Catalogo].[Users] SCU ON SCU.Id = SOL.idUsuario
				INNER JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa
				LEFT JOIN [cliente].[cliente].[Contrato] CLCO ON CLCO.rfcEMpresa = SOL.rfcEmpresa AND CLCO.idCliente = SOL.idCliente AND CLCO.numeroContrato = SOL.numeroContrato
				WHERE CEP.idClase = @idClase 
				AND SOL.idEstatusSolicitud = 'ACTIVA'
				AND CEP.fechaSalida is null)T

-----------------------------------------------------------SE VALIDA SI HAY FILTRO POR ZONA------------------------------------------------

		SELECT * FROM @tbl_solicitudes
		WHERE (@idFase = 'null' OR (@idFase != 'null' AND idFase = @idFase)) AND
		      (@idPaso = 'null' OR (@idPaso != 'null' AND idPaso = @idPaso)) AND
			  (@idZona = 0 OR (@idZona > 0 AND idZona = @idZona)) AND
			  (@idObjeto = 0 OR (@idObjeto > 0 AND idObjeto = @idObjeto)) AND
			  (@idTipoObjeto = 0 OR (@idTipoObjeto > 0 AND idTipoObjeto = @idTipoObjeto))	
		ORDER BY idSolicitud DESC
	
END

go

