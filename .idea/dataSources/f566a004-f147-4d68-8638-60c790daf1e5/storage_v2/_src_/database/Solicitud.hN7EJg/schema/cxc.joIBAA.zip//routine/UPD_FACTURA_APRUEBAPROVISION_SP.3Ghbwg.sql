
-- =============================================
-- Author:		Jose Luis Lozada
-- Create date: 24/07/2019
-- Description:	Cambia de estatus de Provisionada a ProvisiónAprobada

/*

 DECLARE @err VARCHAR(8000)
 EXEC cxc.UPD_FACTURA_APRUEBAPROVISION_SP '<solicitudes><solicitud><idSolicitud>179</idSolicitud><idTipoSolicitud>Servicio</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa>
 <idCliente>92</idCliente><numeroContrato>0001</numeroContrato><idClase>Automovil</idClase></solicitud></solicitudes>',6148,@err output
 PRINT @err

 select * from cxc.factura where idSolicitud=179
 select * from ASEPROTSISCOV3.DBO.ADE_ORDSERENC
 

 update cxc.factura set idEstatus='Provisionada'
 where idSolicitud=179

 update ASEPROTSISCOV3.DBO.ADE_ORDSERENC set ote_status=0

*/
-- =============================================
CREATE PROCEDURE cxc.UPD_FACTURA_APRUEBAPROVISION_SP
@solicitudes XML,
@idUsuario	 INT,
@err		 VARCHAR(8000) OUTPUT  
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			DECLARE @tblSolicitudes AS TABLE(	idx						INT IDENTITY(1,1),       
												idSolicitud				INT,
												idTipoSolicitud			VARCHAR(10),
												rfcEmpresa				VARCHAR(13),
												idCliente				INT,
												numeroContrato			VARCHAR(50),
												idClase					VARCHAR(10))
			DECLARE @v_idx				INT, 
					@v_idSolicitud		INT,
					@v_idTipoSolicitud	VARCHAR(10),
					@v_rfcEmpresa		VARCHAR(13), 
					@v_idCliente		INT,
					@v_numeroContrato	VARCHAR(50),
					@v_idClase			VARCHAR(10),
					@v_idObjeto			INT,
					@v_idTipoObjeto		INT,
					@v_numeroOrden		VARCHAR(50)


			INSERT INTO @tblSolicitudes(idSolicitud,idTipoSolicitud,rfcEmpresa,idCliente,numeroContrato,idClase)    
			SELECT	ParamValues.col.value('idSolicitud[1]','INT'),    
					ParamValues.col.value('idTipoSolicitud[1]','VARCHAR(10)'),    
					ParamValues.col.value('rfcEmpresa[1]','VARCHAR(13)'),    
					ParamValues.col.value('idCliente[1]','INT'),    
					ParamValues.col.value('numeroContrato[1]','VARCHAR(50)'),    
					ParamValues.col.value('idClase[1]','VARCHAR(10)')    
			FROM	@solicitudes.nodes('solicitudes/solicitud') AS ParamValues(col) 

			WHILE EXISTS (SELECT 1 FROM @tblSolicitudes)
				BEGIN
					SELECT	TOP 1 @v_idx=idx,@v_idSolicitud=idSolicitud,@v_idTipoSolicitud=idTipoSolicitud,@v_rfcEmpresa=rfcEmpresa,
							@v_idCliente=idCliente,@v_numeroContrato=numeroContrato,@v_idClase=idClase
					FROM @tblSolicitudes

					-- obtenemos el idObjeto y idTipoObjeto en funcion a la solicitud
					SELECT  @v_idObjeto		=idObjeto,
							@v_idTipoObjeto	=idTipoObjeto
					FROM	solicitud.SolicitudObjeto 
					WHERE	idSolicitud		=@v_idSolicitud 
					AND		idClase			=@v_idClase 
					AND		rfcEmpresa		=@v_rfcEmpresa 
					AND		idCliente		=@v_idCliente
					AND     numeroContrato	=@v_numeroContrato
					AND     idTipoSolicitud	=@v_idTipoSolicitud

					-- Actualizamos estatus de Provisionada a ProvisiónAprobada de las solicitudes que lleguen
					UPDATE	cxc.factura set idEstatus='ProvisiónAprobada'
					WHERE	idSolicitud		=@v_idSolicitud
					AND		idTipoSolicitud	=@v_idTipoSolicitud
					AND		idClase			=@v_idClase
					AND		rfcEmpresa		=@v_rfcEmpresa
					AND     idCliente		=@v_idCliente
					AND     numeroContrato	=@v_numeroContrato

					-- Obtenemos el numero de orden en funcion a la llave de la solicitud
					SELECT	@v_numeroOrden	=numeroOrden 
					FROM	solicitud.solicitud.solicitudObjeto 
					WHERE	idSolicitud		=@v_idSolicitud
					AND     idTipoSolicitud	=@v_idTipoSolicitud
					AND     idClase			=@v_idClase
					AND		rfcEmpresa		=@v_rfcEmpresa
					AND     idCliente		=@v_idCliente
					AND     numeroContrato	=@v_numeroContrato
					AND     idObjeto		=@v_idObjeto
					AND     idTipoObjeto	=@v_idTipoObjeto

					--Cambiamos estatus en tabla cabecero de BPRO
					UPDATE	ASEPROTSISCOV3.DBO.ADE_ORDSERENC 
					SET		ote_status=1
					WHERE	ote_ordenAndrade=@v_numeroOrden

					EXEC  solicitud.UPD_SOLICITUD_AVANZAORDEN_SP @v_idSolicitud,@v_idTipoSolicitud,@v_idClase,@v_rfcEmpresa,@v_idCliente,@v_numeroContrato,@idUsuario,''

					DELETE FROM @tblSolicitudes WHERE idx=@v_idx
				END

		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al actualizar estatus a ProvisiónAprobada'
	END CATCH
END
go

