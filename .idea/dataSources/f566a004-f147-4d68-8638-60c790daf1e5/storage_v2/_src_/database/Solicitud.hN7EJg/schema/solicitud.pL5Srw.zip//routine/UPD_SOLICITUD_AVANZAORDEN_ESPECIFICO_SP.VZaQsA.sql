-- =============================================
-- Author:		<Adolfo Martinez>
-- Create date: <290/05/2020>
-- Description:	<Procesamos avanzar orden con base a estatus de compras BPRO>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	
	*- Testing...
		840	Compra	ASE0508051B6	221	49	Compra	13549	1-1091-13549	2020-06-17 15:19:00.000	6282

    EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP]
		@idSolicitud = 629,
		@idTipoSolicitud = 'Compra',
		@idClase = 'Compra',
		@rfcEmpresa = 'ASE0508051B6',
		@idCliente = 221,
		@numeroContrato = '49',
		@pasoAvanza = 'Aprobacion',
		@faseAvanza = 'Aprobacion',
		@idUsuario=6119,
		@err = ''
*/
CREATE PROCEDURE [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP]
	 @idSolicitud		   INT,  
	 @idTipoSolicitud	   VARCHAR(10),  
	 @idClase			   VARCHAR(10),  
	 @rfcEmpresa           VARCHAR(13),  
	 @idCliente            INT,  
	 @numeroContrato       VARCHAR(50), 
	 @pasoAvanza		   VARCHAR(50),
	 @faseAvanza		   VARCHAR(50),
	 @idUsuario			   INT,
	 @err					VARCHAR(500)  OUTPUT  
	 
AS
BEGIN
		/*OBTENEMOS LOS DATOS DE LA SOLCIITUD CON BASE A LA ORDEN DE COMPRA BPRO*/
	declare @idFaseActual		VARCHAR(20)
		,@idPasoActual			VARCHAR(50)
		,@salida				VARCHAR(500) = ''
		,@tipoPasoActual		VARCHAR(10) = 'PASO'
		,@tipoPasoSiguiente		VARCHAR(10) = 'PASO'
		,@idFaseActualUPD		VARCHAR(20)
		,@idPasoActualUPD		VARCHAR(50)
		,@idFaseSiguiente		VARCHAR(20) 
		,@idPasoSiguiente		VARCHAR(50) 

	declare @pasos as table(
		row	int identity(1,1)
		,idFase varchar(20)
		,idPaso varchar(50)
	)

	/*INICIO DE BLOQUE DE PASOS DINAMICOS*/
	INSERT INTO @pasos
	SELECT  
		T.idFase  
		,T.idPaso  
	FROM 
	(  
		SELECT   
			[idPaso]  
			,[idFase]  
			,[idClase]  
			,[idTipoSolicitud]  
			,[nombre]  
			,[descripcion]  
			,[orden]  
			,[color]  
			,CAST([tiempoEstimado] AS time(0)) tiempoEstimado  
			,[procedimientoAlmacenado]  
			,[parametros]  
		FROM [Solicitud].[fase].[Paso]  
		WHERE idClase = @idClase  
		AND idTipoSolicitud = @idTipoSolicitud
    ) T  
	LEFT JOIN [fase].[Fase] F ON F.idFase = T.idFase  
	ORDER BY F.orden, T.orden
	
	select 
		@idFaseActual = est.idFase
		,@idPasoActual = est.idPaso
	from fase.SolicitudEstatusPaso est 
	where 
		est.idSolicitud = @idSolicitud
		and est.fechaSalida is null

	--YA QUE TENEMOS EL PASO Y FASE ACTUAL, CORREMOS EL PROCESO DE AVANZAR ORDEN HASTA EL PASO Y FASE INDICADO.
	declare 
		@rowActual int
		,@rowFinal int
	set @rowActual = (select [row] from @pasos where idFase = @idFaseActual and idPaso = @idPasoActual)
	set @rowFinal = (select [row] from @pasos where idFase = @faseAvanza and idPaso = @pasoAvanza)

	print 'rowActual: ' + convert(varchar,@rowActual)
	print 'rowFinal: ' + convert(varchar,@rowFinal)

	if (@pasoAvanza = 'Cancelacion' and @faseAvanza='Cancelacion')
	BEGIN
		--CANCELAMOS
		set @salida = ''
		exec solicitud.UPD_SOLICITUD_CANCELA
			@idSolicitud
			,@idTipoSolicitud
			,@idClase
			,@rfcEmpresa
			,@idCliente
			,@numeroContrato
			,@idUsuario
			,@salida out
	END
	ELSE
	BEGIN
		--SI EL PASO ACTUAL ES MAYOR AL FINAL, NO PROCESAMOS NADA
		IF (@rowActual<@rowFinal)
		BEGIN
			--AVANZAMOS LA ORDEN HASTA LLEGAR AL PASO FINAL
			WHILE (@rowActual<@rowFinal)
			BEGIN
				set @salida = ''
				 --ACTUALIZAMOS EL ESTATUS ACTUAL      
				IF (@tipoPasoActual='PASO')  
				   BEGIN  
				   	select 
						@idFaseActualUPD = est.idFase
						,@idPasoActualUPD = est.idPaso
					from fase.SolicitudEstatusPaso est 
					where 
						est.idSolicitud = @idSolicitud
						and est.fechaSalida is null
						print 'Fase actual: ' + @idFaseActualUPD
						print 'Paso actual: ' + @idPasoActualUPD
						UPDATE est  
						SET  
						 est.fechaSalida = GETDATE(),  
						 idEstatus = 1,  
						 idUsuarioSalida = @idUsuario  
						FROM fase.SolicitudEstatusPaso est   
						where  
						 est.idSolicitud = @idSolicitud  
						 and est.idTipoSolicitud = @idTipoSolicitud  
						 and est.idClase = @idClase  
						 and est.rfcEmpresa = @rfcEmpresa  
						 and est.idCliente = @idCliente  
						 and est.numeroContrato = @numeroContrato  
						 and est.idPaso = @idPasoActualUPD  
						 and est.idFase = @idFaseActualUPD  
				   END  
			   --MOVEMOS AL SIGUIENTE PASO  
			   IF (@tipoPasoSiguiente='PASO')  
				   BEGIN
				    SELECT   
						  @idFaseSiguiente = (select top 1 idFase from [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN(@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) where numeroPaso = flujo.numeroPaso+1),  
						  @idPasoSiguiente = (select top 1  idPaso from [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN(@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) where numeroPaso = flujo.numeroPaso+1)
					 FROM [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN(@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) flujo  
					 WHERE   
					  flujo.idPaso = @idPasoActualUPD  
					  print 'se mueve a: ' + @idPasoSiguiente

						INSERT INTO fase.SolicitudEstatusPaso(  
						 idSolicitud  
						 ,idTipoSolicitud  
						 ,idClase  
						 ,rfcEmpresa  
						 ,idCliente  
						 ,numeroContrato  
						 ,idPaso  
						 ,idFase  
						 ,fechaIngreso  
						 ,idEstatus  
						 ,idUsuarioIngreso  
						)  
						 values  
						 (  
						 @idSolicitud,  
						 @idTipoSolicitud,  
						 @idClase,  
						 @rfcEmpresa,  
						 @idCliente,  
						 @numeroContrato,  
						 @idPasoSiguiente,  
						 @idFaseSiguiente,  
						 GETDATE(),  
						 1,  
						 @idUsuario  
						)  
  
						UPDATE solicitud.Solicitud  
						SET idPaso = @idPasoSiguiente  
						 , idFase = @idFaseSiguiente  
						WHERE idSolicitud = @idSolicitud  
						AND idTipoSolicitud = @idTipoSolicitud  
						AND idClase = @idClase  
						AND rfcEmpresa = @rfcEmpresa  
						AND idCliente = @idCliente  
						AND numeroContrato = @numeroContrato  
				   END 
				set @rowActual = @rowActual+1
			END
		END
		ELSE
		BEGIN
			--NO SE PROCESA NADA
			PRINT 'NO PROCESAMOS'
		END
	END
			  
END
go

