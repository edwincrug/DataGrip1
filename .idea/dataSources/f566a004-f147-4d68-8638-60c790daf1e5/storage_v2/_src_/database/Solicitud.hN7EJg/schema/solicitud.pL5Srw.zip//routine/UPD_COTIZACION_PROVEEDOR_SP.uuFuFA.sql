-- =============================================
-- Author:			<Edgar Mendoza>
-- Create date: 	<19/05/2020>
-- Description:	    <Actualiza Cotización>
-- =============================================
-- EXEC [solicitud].[UPD_COTIZACION_PROVEEDOR_SP] 'TMO191211832',528,'151-1546-12163-1',4380,'Traslado','Automovil','ASE0508051B6',185,'127', 2326, ''

-- =============================================
	CREATE PROCEDURE [solicitud].[UPD_COTIZACION_PROVEEDOR_SP]
(
	@rfcProveedor			VARCHAR(13)
	,@idProveedorEntidad	INT
	,@numeroCotizacion		VARCHAR(100)
	,@idSolicitud			INT
	,@idTipoSolicitud		VARCHAR(10)
	,@idClase				VARCHAR(10)
	,@rfcEmpresa			VARCHAR(13)
	,@idCliente				INT
	,@numeroContrato		VARCHAR(50)
	,@idUsuario				INT
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS


BEGIN
	
	DECLARE @idCotizacion		INT

	SELECT
		@idCotizacion = idCotizacion
	FROM Solicitud.solicitud.SolicitudCotizacion
	WHERE numeroCotizacion = @numeroCotizacion
	AND idSolicitud = @idSolicitud
	AND idClase = @idClase
	AND rfcEmpresa = @rfcEmpresa
	AND idCliente = @idCliente
	AND numeroContrato = @numeroContrato

	IF EXISTS(select * from solicitud.[cxc].[FacturaDetalle] WHERE idCotizacion = @idCotizacion)
		BEGIN
			SET @err = 'No se puede actualizar cotización porque ya esta provisionada'
			SELECT 'ERR' msj
		END

	ELSE
		BEGIN


		UPDATE solicitud.SolicitudCotizacion
			SET rfcProveedor = @rfcProveedor, idProveedorEntidad = @idProveedorEntidad
			WHERE idSolicitud = @idSolicitud
			AND idCotizacion = @idCotizacion
			AND idClase = @idClase
			AND idTipoSolicitud = @idTipoSolicitud
			AND numeroContrato = @numeroContrato
			AND idCliente = @idCliente
			AND rfcEmpresa = @rfcEmpresa
		

			UPDATE solicitud.ComprobanteRecepcion
			SET rfcProveedor = @rfcProveedor, idProveedorEntidad = @idProveedorEntidad
			WHERE idSolicitud = @idSolicitud
			AND idClase = @idClase
			AND idTipoSolicitud = @idTipoSolicitud
			AND numeroContrato = @numeroContrato
			AND idCliente = @idCliente
			AND rfcEmpresa = @rfcEmpresa
			

			IF(@@ERROR = 0)
				BEGIN

					SET @err = 'Se ha actualizado el proveedor'
					SELECT 'OK' msj
				END
		END

	

END



go

