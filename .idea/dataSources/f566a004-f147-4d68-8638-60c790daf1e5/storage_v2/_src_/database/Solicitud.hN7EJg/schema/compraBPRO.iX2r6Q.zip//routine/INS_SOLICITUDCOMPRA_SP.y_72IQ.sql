
-- =============================================
-- Author:		<Jose Luis Lozada G.>
-- Create date: <25/05/2020>
-- Description:	<Guarda datos de solicitud de compra>
/*
	select * from common.configuracion.usuariosBPRO
	exec [compraBPRO].[INS_SOLICITUDCOMPRA_SP] 535,'Compra','Compra','ASE0508051B6',221,'49',4,8,6282,null

*/
-- =============================================
CREATE PROCEDURE [compraBPRO].[INS_SOLICITUDCOMPRA_SP]
	@idSolicitud			INT,
	@idTipoSolicitud		VARCHAR(50) = '',
	@idClase				VARCHAR(10) = '',
	@rfcEmpresa				VARCHAR(13) = '',
	@idCliente				INT = 0,
	@numeroContrato			VARCHAR(50) = '',
	@idEmpresa				INT,
	@idSucursal				INT,
	@idArea					INT,
	@idUsuario				INT = 0,
	@err					VARCHAR(8000) OUTPUT		
AS
BEGIN

	DECLARE @idUsuarioBPRO INT
	
	SELECT TOP 1 @idUsuarioBPRO=idUsuarioBPRO FROM common.configuracion.usuariosBPRO WHERE idUsuario=@idUsuario
	
	IF NOT EXISTS(	SELECT 1 
					FROM	[compraBPRO].[solicitud] 
					WHERE	idSolicitud		=@idSolicitud 
					AND		idTipoSolicitud	=@idTipoSolicitud 
					AND		idClase			=@idClase 
					AND		rfcEmpresa		=@rfcEmpresa 
					AND		idCliente		=@idCliente
					AND     numeroContrato	=@numeroContrato)
		BEGIN
			INSERT INTO [compraBPRO].[solicitud](idSolicitud,idTiposolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idUsuarioBPRO,idEmpresa,idSucursal,idArea,idUsuario,activo)
			VALUES(@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idUsuarioBPRO,@idEmpresa,@idSucursal,@idArea,@idUsuario,1)
		END
	ELSE
		BEGIN
			UPDATE [compraBPRO].[solicitud] SET idUsuarioBPRO=@idUsuarioBPRO,idEmpresa=@idEmpresa,idSucursal=@idSucursal,idArea=@idArea
			WHERE	idSolicitud		=@idSolicitud 
				AND		idTipoSolicitud	=@idTipoSolicitud 
				AND		idClase			=@idClase 
				AND		rfcEmpresa		=@rfcEmpresa 
				AND		idCliente		=@idCliente
				AND     numeroContrato	=@numeroContrato 
		END
	
END
go

