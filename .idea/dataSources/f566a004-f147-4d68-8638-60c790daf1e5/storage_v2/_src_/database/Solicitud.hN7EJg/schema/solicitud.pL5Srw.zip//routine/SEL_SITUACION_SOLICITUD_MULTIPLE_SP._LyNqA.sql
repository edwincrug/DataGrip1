  
-- =============================================  
-- Author: Adolfo Martinez  
-- Create date: 30-07-2020  
-- Description: Obtener la solictud de cotización multiple 
-- ============== Versionamiento ================  
/*  
 
 DECLARE @salida varchar(max) ='' ;  
 EXEC [solicitud].[SEL_PROVEEDOR_MULTIPLE_SP] 'ASE0508051B6', 219, '128', 1016,'Automovil',6147, '';
 SELECT @salida AS salida;  
*/  
-- =============================================  
CREATE PROCEDURE [solicitud].[SEL_SITUACION_SOLICITUD_MULTIPLE_SP]  
 @rfcEmpresa    varchar(13),  
 @idCliente    int,  
 @numeroContrato   nvarchar(50),  
 @idSolicitud   int,  
 @idClase    varchar(10),  
 @idUsuario    int,  
 @err     varchar(500)OUTPUT  
AS  
  
  
BEGIN  
  
 SELECT [idCotizacion]  
    ,[idSolicitud]  
    ,[idTipoSolicitud]  
    ,[idClase]  
    ,[rfcEmpresa]  
    ,[idCliente]  
    ,[numeroContrato]  
    ,[idProveedorEntidad]  
    ,[rfcProveedor]  
    ,[numeroCotizacion]  
    ,[fechaAlta]  
    ,[idUsuario]
	,[idEstatusCotizacion]
   FROM [Solicitud].[solicitud].[SolicitudCotizacion]  
   WHERE [rfcEmpresa] = @rfcEmpresa  AND  
	   [idCliente] = CAST(@idCliente AS VARCHAR(50)) AND  
	   [numeroContrato] =  @numeroContrato  AND  
	   [idSolicitud] = CAST(@idSolicitud AS VARCHAR(50))   
  
END  

--USE [Solicitud]
go

