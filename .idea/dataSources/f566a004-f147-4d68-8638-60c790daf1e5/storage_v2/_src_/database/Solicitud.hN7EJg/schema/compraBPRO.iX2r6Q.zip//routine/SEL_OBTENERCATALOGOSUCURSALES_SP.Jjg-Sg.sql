
-- =============================================
-- Author:		<Jose Luis Lozada G>
-- Create date: <25/05/2020>
-- Description:	<Obtiene catalogo de sucursales>
-- =============================================

/*
	exec  [compraBPRO].[SEL_OBTENERCATALOGOSUCURSALES_SP] 4,3902,null

*/

CREATE PROCEDURE [compraBPRO].[SEL_OBTENERCATALOGOSUCURSALES_SP]
@idEmpresa		INT,
@idUsuario		INT,
@err			VARCHAR(500) OUTPUT	
AS
BEGIN
	select suc_idsucursal as 'id', suc_nombre as 'descripcion' 
	-- select *
	from [192.168.20.29].[ControlAplicaciones].dbo.cat_sucursales
	WHERE emp_idempresa =@idEmpresa
	ORDER BY suc_nombre asc
	
END



go

