-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <04/07/2019>
-- Description:	<Alta de Integridades>
-- =============================================
CREATE TRIGGER [solicitud].[INS_TIPOSOLICITUD_TG] 
   ON  [solicitud].[TipoSolicitud]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @idTipoSolicitud	VARCHAR(10),
			@idClase			VARCHAR(10),
			@IdUsuario			INT,
			@VC_ThrowTable		VARCHAR(300) = ''
	;
	SELECT TOP 1 @idTipoSolicitud= idTipoSolicitud, @idClase= idClase, @IdUsuario = IdUsuario FROM inserted
	BEGIN TRANSACTION;
	BEGIN TRY

		--INSERTAMOS INTEGRIDADES
		--Cliente
		SET @VC_ThrowTable = '[Cliente].[integridad].[TipoSolicitud] ';
		insert into [Cliente].[integridad].[TipoSolicitud] 
		VALUES( @idTipoSolicitud,@idClase)

		--Proveedor
		SET @VC_ThrowTable = 'Proveedor.integridad.TipoSolicitud'
		INSERT INTO Proveedor.integridad.TipoSolicitud(idTipoSolicitud, idClase, activo)
		VALUES (@idTipoSolicitud, @idClase, 1)

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
	END CATCH


END
go

