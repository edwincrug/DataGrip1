  
-- =============================================  
-- Author: Adolfo Martinez  
-- Create date: 30-07-2020  
-- Description: Obtener los proveedores de una cotización multiple 
-- ============== Versionamiento ================  
/*  
 
 DECLARE @salida varchar(max) ='' ;  
 EXEC [solicitud].[SEL_PROVEEDOR_MULTIPLE_SP] 'ASE0508051B6', 219, '128', 1016,'Automovil',6147, '';
  EXEC [solicitud].[SEL_PROVEEDOR_MULTIPLE_SP] 'AAN910409135', 218, '0001', 1095,'Automovil',6147, '';
  EXEC [solicitud].[SEL_PROVEEDOR_MULTIPLE_SP] 'ASE0508051B6', 185, '43', 12185,'Automovil',6147, '';
  EXEC [solicitud].[SEL_PROVEEDOR_MULTIPLE_SP] 'AAN910409135', 102, '35', 12212,'Automovil',6147, '';
 SELECT @salida AS salida;  
*/  
-- =============================================  
CREATE PROCEDURE [solicitud].[SEL_PROVEEDOR_MULTIPLE_SP]  
 @rfcEmpresa    varchar(13),  
 @idCliente    int,  
 @numeroContrato   nvarchar(50),  
 @idSolicitud   int,  
 @idClase    varchar(10),  
 @idUsuario    int,  
 @err     varchar(500)OUTPUT  
AS  
  
  
BEGIN  
   
  
 --SELECT * INTO #propiedadPartida FROM [Cliente].[contrato].[SEL_PARTIDAS_VW]  
  -------------------------------------- COTIZACION SOLICITUD --------------------------------------
 SELECT [idCotizacion]  
    ,[idSolicitud]  
    ,[idTipoSolicitud]  
    ,[idClase]  
    ,[rfcEmpresa]  
    ,[idCliente]  
    ,[numeroContrato]  
    ,[idProveedorEntidad]  
    ,[rfcProveedor]  
    ,[numeroCotizacion]  
    ,[fechaAlta]  
    ,[idUsuario]
	,[idEstatusCotizacion]
    into #cotizaciones  
   FROM [Solicitud].[solicitud].[SolicitudCotizacion]  
   WHERE [rfcEmpresa] = @rfcEmpresa  AND  
   [idCliente] = @idCliente AND  
   [numeroContrato] =  @numeroContrato  AND  
   [idSolicitud] = @idSolicitud  
 
 -------------------------------------- PROVEEDOR  --------------------------------------
 select   
   [idSolicitud]
  ,[idProveedorEntidad]  
  ,[rfcProveedor]  
 from #cotizaciones group by[numeroContrato] 
  ,[idSolicitud] 
  ,[idProveedorEntidad]  
  ,[rfcProveedor] ORDER BY idProveedorEntidad  

-- SQL dinamico
DECLARE @v_sq NVARCHAR(MAX),
        @TablaObjeto VARCHAR(50),
		@camposPivotObjeto VARCHAR(1000),
		@camposPivotKey	VARCHAR(MAX)	 
/*PROPIEDADES DINAMICAS [OBJETO Y TIPO DE OBJETO]*/
BEGIN
	DECLARE @tObjeto TABLE(idTipoObjeto INT, idObjeto INT)
	IF OBJECT_ID('tempdb..#tablaDatosObjeto')IS NOT NULL DROP TABLE #tablaDatosObjeto
	CREATE TABLE #tablaDatosObjeto([idTipoObjeto] [int] NULL, [idObjeto] [int] NULL, [agrupador] [varchar](250) NULL, [valor] [varchar](500) NULL)
		
	SET @TablaObjeto='TxObjeto_'+CAST(CAST(RAND(CHECKSUM(NEWID()))*10000000 AS INT) AS VARCHAR)

	/*Modificar el query que llena la tabla @tObjeto al integrar en sp para que tome los filtros de la consulta general*/
	INSERT	INTO @tObjeto (idTipoObjeto, idObjeto)
	SELECT DISTINCT idTipoObjeto,idObjeto FROM [solicitud].[SolicitudObjeto]   
	WHERE  [rfcEmpresa] = @rfcEmpresa  AND  
		   [idCliente] = @idCliente AND  
		   [numeroContrato] =  @numeroContrato  AND  
		   [idSolicitud] = @idSolicitud

	SET		@camposPivotObjeto	= ISNULL(STUFF((SELECT ',' + QUOTENAME(campo) FROM Common.reporte.objeto WHERE idClase=@idClase ORDER BY orden ASC  FOR XML PATH('')),1,1,''),'sinCoinicidencia')
	SET		@camposPivotKey		= 'idTIpoObjeto as Key_idTipoObjeto,idObjeto as Key_idObjeto' 
	SET 	@camposPivotObjeto 	= REPLACE(@camposPivotObjeto,' ','_')

	INSERT INTO #tablaDatosObjeto(idTipoObjeto,idObjeto,agrupador,valor) 
	SELECT	s.idTipoObjeto,s.idObjeto,tc.campo,
			[objeto].[objeto].[getPropiedadObjeto](case when tc.tipoObjeto='idTipoObjeto' then s.idTipoObjeto else s.idObjeto end, tc.campo, tc.tipoPropiedad,@idClase) 
	FROM	@tObjeto s,(SELECT campo,tipoPropiedad,tipoObjeto,orden FROM Common.reporte.Objeto (NOLOCK) WHERE idClase=@idClase) tc ORDER	BY tc.orden ASC
	
	SET @v_sq='SELECT r.* INTO '+ @TablaObjeto +' FROM (select '+@camposPivotKey+',agrupador,valor from #tablaDatosObjeto) AS tx PIVOT (max(valor) for agrupador in ('+@camposPivotObjeto+')) as r '
	EXEC SP_EXECUTESQL @v_sq

	SET @v_sq='	CREATE UNIQUE CLUSTERED INDEX [idx0001_'+@TablaObjeto+'] ON [dbo].['+@TablaObjeto+']
				([Key_idTipoObjeto] ASC,[Key_idObjeto] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, 
				ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY] '
	EXEC SP_EXECUTESQL @v_sq
END
/*************************************************/
-------------------------------------- PROVEEDOR COTIZACION --------------------------------------
--,[common].[gerencia].SEL_OBTENERZONA_FN(C.rfcEmpresa,C.idCliente,C.numeroContrato,C.idClase,SO.idTipoObjeto,SO.idObjeto) AS zona
 SET @v_sq ='
 select  
   SO.numeroOrden 
  ,C.numeroCotizacion
  ,C.idCotizacion
  ,C.idSolicitud
  ,C.idTipoSolicitud  
  ,C.idClase 
  ,C.rfcEmpresa  
  ,C.idCliente  
  ,C.numeroContrato 
  ,C.idProveedorEntidad  
  ,C.rfcProveedor 
  ,C.idEstatusCotizacion
  ,ISNULL(FB.OTE_IDENT,0) OTE_IDENT
  ,SO.idTipoObjeto
  ,SO.idObjeto
  ,COUNT(SCP.idCotizacion) partidas
  ,(SELECT COALESCE(SUM(VW.subTotalVenta), 0) FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] VW WHERE VW.idCotizacion = C.idCotizacion) Venta
  ,(SELECT COALESCE(SUM(VW.subTotalCosto), 0) FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] VW WHERE VW.idCotizacion = C.idCotizacion) Costo
  
  ,(O.Marca + '' - '' + O.Submarca + '' / '' + O.Año + '' / '' + ''Eco:'' + O.NumeroEconomico + '' / '' + ''VIN:'' + O.VIN) AS vehiculo
  ,CASE WHEN C.idEstatusCotizacion = ''RECHAZADA'' THEN ''1'' ELSE (SELECT TOP 1 SOP.valor FROM [Solicitud].[documento].[SolicitudObjetoPaso] SOP
	 JOIN [Solicitud].[documento].[Paso] P ON P.idDocumentoClase = SOP.idDocumentoClase
	 WHERE SOP.idsolicitud = C.idSolicitud AND SOP.idObjeto = SO.idObjeto AND SOP.idTipoObjeto = SO.idTipoObjeto AND SOP.valor = SO.numeroOrden AND P.nombre =''Hoja de Trabajo'') END AS existsHT
  ,(SELECT TOP 1 SOP.valor FROM [Solicitud].[documento].[SolicitudObjetoPaso] SOP
	 JOIN [Solicitud].[documento].[Paso] P ON P.idDocumentoClase = SOP.idDocumentoClase
	 WHERE SOP.idsolicitud = C.idSolicitud AND SOP.idObjeto = SO.idObjeto AND SOP.idTipoObjeto = SO.idTipoObjeto AND SOP.valor = SO.numeroOrden AND P.nombre =''Comprobante de Recepción'') AS existsCR
   ,CASE WHEN (SELECT TOP 1 SOP.valor FROM [Solicitud].[documento].[SolicitudObjetoPaso] SOP
	 JOIN [Solicitud].[documento].[Paso] P ON P.idDocumentoClase = SOP.idDocumentoClase
	 WHERE SOP.idsolicitud = C.idSolicitud AND SOP.idObjeto = SO.idObjeto AND SOP.idTipoObjeto = SO.idTipoObjeto AND SOP.valor = SO.numeroOrden AND P.nombre =''Comprobante de Recepción'') IS NULL THEN ''#ffffff'' ELSE 	 
	 CASE WHEN 
	 (SELECT TOP 1 SOP.valor FROM [Solicitud].[documento].[SolicitudObjetoPaso] SOP
	 JOIN [Solicitud].[documento].[Paso] P ON P.idDocumentoClase = SOP.idDocumentoClase
	 WHERE SOP.idsolicitud = C.idSolicitud AND SOP.idObjeto = SO.idObjeto AND SOP.idTipoObjeto = SO.idTipoObjeto AND SOP.valor = SO.numeroOrden AND P.nombre =''Hoja de Trabajo'') IS NULL
	 THEN ''#FFF3D5'' ELSE ''#C8D6FC''
		END
	 END AS backgroundcolor
 FROM #cotizaciones C
 JOIN [solicitud].[SolicitudCotizacionPartida] SCP ON SCP.idCotizacion = C.idCotizacion 
 JOIN [solicitud].[SolicitudObjeto] SO ON SO.idsolicitud = C.idSolicitud AND SO.idObjeto = SCP.idObjeto AND SO.idTipoObjeto = SCP.idTipoObjeto
 LEFT JOIN '+ @TablaObjeto +' O ON O.key_idTipoObjeto = SO.idtipoObjeto AND O.key_idObjeto = SO.idObjeto 
 LEFT JOIN [cxc].[Factura] F ON F.idSolicitud=C.idSolicitud and F.idCotizacion = C.idCotizacion
 LEFT JOIN [cxc].[FacturaBPRO] FB on F.idSolicitud = FB.idSolicitud and F.idCotizacion = FB.idCotizacion
 group by  
   SO.numeroOrden 
  ,C.numeroCotizacion 
  ,C.idCotizacion
  ,C.idSolicitud  
  ,C.idTipoSolicitud  
  ,C.idClase
  ,C.rfcEmpresa 
  ,C.idCliente 
  ,C.numeroContrato 
  ,C.idProveedorEntidad 
  ,C.rfcProveedor
  ,C.idEstatusCotizacion
  ,FB.OTE_IDENT
  ,SO.idTipoObjeto
  ,SO.idObjeto
  ,O.Marca
  ,O.Submarca
  ,O.Año
  ,O.NumeroEconomico
  ,O.VIN
  order by C.idProveedorEntidad'
  PRINT @v_sq
 EXEC SP_EXECUTESQL @v_sq
  --------------------------------------TOTAL PROVEEDOR--------------------------------------
  SELECT  
     T.[idSolicitud]  
     ,T.[rfcProveedor]  
     ,T.[idProveedorEntidad]  
     --,T.[idCotizacion]  
     ,COALESCE(SUM(T.[subTotalCosto]), 0) AS [subTotalCosto]
     ,COALESCE(SUM(T.[IVACosto]), 0) AS [IVACosto]
     ,COALESCE(SUM(T.[totalCosto]), 0) AS [totalCosto]
     ,COALESCE(SUM(T.[subTotalVenta]), 0) AS [subTotalVenta]  
     ,COALESCE(SUM(T.[IVAVenta]), 0) AS [IVAVenta]  
     ,COALESCE(SUM(T.[totalVenta]), 0) AS [totalVenta]  
     --,C.numeroCotizacion  
  FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] AS T  
	--INNER JOIN #cotizaciones C ON C.idCotizacion = T.idCotizacion  
  WHERE T.idSolicitud = @idSolicitud  
  GROUP BY T.[idSolicitud]  
     ,T.[rfcProveedor]  
     ,T.[idProveedorEntidad] 
  ORDER BY idProveedorEntidad  
  --------------------------------------TOTAL ORDEN--------------------------------------
  EXEC [solicitud].[SEL_TOTAL_PARTIDAS_SP] @idSolicitud, @idUsuario  

    --------------------------------------UTILIDAD--------------------------------------
    SELECT  
      VW.idSolicitud  
     ,VW.rfcProveedor
     ,VW.idProveedorEntidad
	 ,CASE WHEN C.manejoDeUtilidad = 1 THEN C.porcentajeUtilidad ELSE -1 END AS contratoUtilidad
	 ,CASE WHEN COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) = 0 THEN 0 
	ELSE CAST( ((COALESCE(SUM(VW.subTotalVenta), 0) - COALESCE(SUM(VW.subTotalCosto), 0)) / COALESCE(SUM(vw.subTotalVentaSinDescuento), 0)) * 100 AS DECIMAL(18,2)) END AS utilidad
  FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] AS VW 
	 JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = VW.rfcEmpresa AND C.numeroContrato = VW.numeroContrato AND C.idCliente = VW.idCliente AND C.idClase = VW.idClase
	 JOIN #cotizaciones Ct ON Ct.idCotizacion = VW.idCotizacion  
  WHERE VW.idSolicitud = @idSolicitud  
  GROUP BY VW.idSolicitud, VW.rfcProveedor, VW.idProveedorEntidad, C.manejoDeUtilidad, C.porcentajeUtilidad

  -------------------------------------- SOLICITUD ACTUAL PASO--------------------------------------

  SELECT S.idSolicitud,S.idTipoSolicitud,S.idClase,S.rfcEmpresa,S.idCliente,S.numeroContrato,S.idPaso,S.idFase,S.fechaIngreso FROM [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud) AS S

    ----------------------------------------IMPUESTOS---------------------------------------------------
	DECLARE @impuestos TABLE (
		idSolicitud					INT
		,idCotizacion				INT
		,idTipoFacturaImpuesto		INT
		,tasa						FLOAT
		,tipo						INT
		,uuid						VARCHAR(MAX)
		,tipoDescripcion			VARCHAR(50)
	)

	DECLARE @traslado TABLE(
		impuesto			VARCHAR(20)
		,subTotalCosto		FLOAT
		,tasa				FLOAT
		,tipoDescripcion	VARCHAR(50)
	)

	DECLARE @retencion TABLE(
		impuesto			VARCHAR(20)
		,importe			FLOAT
		,tipoDescripcion	VARCHAR(50)
	)

	INSERT INTO @impuestos
	SELECT 
		SCF.idSolicitud
		,SCF.idCotizacion
		,TFI.idTipoFacturaImpuesto
		,FI.tasa
		,T.idTipo
		,SCF.uuid
		,T.descripcion
	FROM cxp.SolicitudCotizacionFactura SCF
	INNER JOIN cxp.Factura F 
		ON F.uuid = SCF.uuid
	INNER JOIN cxp.FacturaImpuesto FI 
		ON FI.uuidFactura = F.uuid
	INNER JOIN cxp.TipoFacturaImpuesto TFI 
		ON TFI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto
	INNER JOIN cxp.Tipo T 
		ON T.idTipo = TFI.idTipo 
	WHERE idSolicitud = @idSolicitud
	GROUP BY
		SCF.idSolicitud
		,SCF.idCotizacion
		,TFI.idTipoFacturaImpuesto
		,FI.tasa
		,T.idTipo
		,SCF.uuid
		,T.descripcion
  -------------------------------------------TRASLADO------------------------------------------
	 IF EXISTS(SELECT * FROM @impuestos WHERE tipo = 1)
		BEGIN
			INSERT INTO @traslado
			SELECT
				--*
				TFI.impuesto
				,SUM(TCV.subTotalCosto) * I.tasa subTotalCosto
				,I.tasa
				,T.descripcion
			FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] TCV
			INNER JOIN @impuestos I 
				ON I.idCotizacion = TCV.idCotizacion 
				AND I.idSolicitud = TCV.idSolicitud
			INNER JOIN cxp.SolicitudCotizacionFactura SCF
				ON SCF.idSolicitud = I.idSolicitud 
				AND SCF.idCotizacion = I.idCotizacion 
			INNER JOIN cxp.Factura F 
				ON F.uuid = SCF.uuid
			INNER JOIN cxp.FacturaImpuesto FI 
				ON FI.uuidFactura = F.uuid
				AND FI.idTipoFacturaImpuesto = I.idTipoFacturaImpuesto
			INNER JOIN cxp.TipoFacturaImpuesto TFI 
				ON TFI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto
			INNER JOIN cxp.Tipo T 
				ON T.idTipo = TFI.idTipo 
			WHERE I.tipo = 1
			GROUP BY
				TFI.impuesto
				,I.tasa
				,T.descripcion
		
		END

	-------------------------------------------RETENCIÓN------------------------------------------
		IF EXISTS(SELECT * FROM @impuestos WHERE tipo = 2)
			BEGIN
				INSERT INTO @retencion
				SELECT
					TFI.impuesto
					,SUM(FI.importe) / (SELECT COUNT(uuid) FROM cxp.SolicitudCotizacionFactura 
										WHERE uuid = I.uuid)
					,T.descripcion
					--,* 
				FROM @impuestos I
				INNER JOIN cxp.SolicitudCotizacionFactura SCF
					ON SCF.idSolicitud = I.idSolicitud 
					AND SCF.idCotizacion = I.idCotizacion 
				INNER JOIN cxp.Factura F 
					ON F.uuid = SCF.uuid
				INNER JOIN cxp.FacturaImpuesto FI 
					ON FI.uuidFactura = F.uuid
					AND FI.idTipoFacturaImpuesto = I.idTipoFacturaImpuesto
				INNER JOIN cxp.TipoFacturaImpuesto TFI 
					ON TFI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto
				INNER JOIN cxp.Tipo T 
					ON T.idTipo = TFI.idTipo 
				WHERE I.tipo = 2
				GROUP BY
					TFI.impuesto
					,I.uuid
					,T.descripcion
					--,I.idCotizacion
			END
	select * from @traslado
	select * from @retencion

	------------------------------------------- OBJETOS -------------------------------------------
	 SELECT DISTINCT
	   C.idSolicitud
	  ,C.idTipoSolicitud  
	  ,C.idClase 
	  ,C.rfcEmpresa  
	  ,C.idCliente  
	  ,C.numeroContrato
	  ,SO.idTipoObjeto
	  ,SO.idObjeto
	 FROM #cotizaciones C
		JOIN [solicitud].[SolicitudCotizacionPartida] SCP ON SCP.idCotizacion = C.idCotizacion 
		JOIN [solicitud].[SolicitudObjeto] SO ON SO.idsolicitud = C.idSolicitud AND SO.idObjeto = SCP.idObjeto AND SO.idTipoObjeto = SCP.idTipoObjeto

IF OBJECT_ID(@TablaObjeto, 'U') IS NOT NULL  
	BEGIN
		SET @v_sq='DROP TABLE '+@TablaObjeto 
		EXEC SP_EXECUTESQL @v_sq
	END
IF OBJECT_ID('tempdb..#tablaDatosObjeto')	IS NOT NULL DROP TABLE #tablaDatosObjeto

drop table #cotizaciones  

END  

--USE [Solicitud]
go

