-- =============================================
-- Author:		<Jose Luis Lozada G>
-- Create date: <10/06/2020>
-- Description:	<Obtiene catalogo de departamentos>
-- =============================================

/*
	exec  [compraBPRO].[SEL_OBTENERCATALOGOAREAS_SP] 4,6119,null

*/



CREATE PROCEDURE [compraBPRO].[SEL_OBTENERCATALOGOAREAS_SP]
@idEmpresa		INT,
@idSucursal		INT,
@idUsuario		INT,
@err			VARCHAR(500) OUTPUT	
AS
BEGIN
	--select dep_iddepartamento as 'id', dep_nombre as 'descripcion' 
	---- select *
	--from [192.168.20.29].ControlAplicaciones.dbo.cat_departamentos
	--WHERE emp_idempresa =@idEmpresa
	--AND   suc_idsucursal=@idSucursal
	--ORDER BY dep_nombre asc
	
	SELECT id,otc_area as 'descripcion'
	FROM [192.168.20.29].[Centralizacionv2].[dbo].[DIG_ESCALAMIENTO_AREA_AFECT] 
	WHERE emp_idempresa =@idEmpresa
	AND   suc_idsucursal=@idSucursal
	order by 2 asc
END
go

