
-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Obtener el total de las partidas de una solicitud>
-- =============================================
-- EXEC [solicitud].[SEL_TOTAL_PARTIDAS_SP] 1885,2,''
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_TOTAL_PARTIDAS_SP]
(
    @idSolicitud        int
	,@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN

   WITH cte_datos as (
    SELECT 
        COALESCE(SUM(VW.subTotalCosto), 0) subTotalCosto
        ,COALESCE(SUM(VW.IVACosto), 0) IVACosto
        ,COALESCE(SUM(VW.totalCosto), 0) totalCosto
        ,COALESCE(SUM(VW.subTotalVenta), 0) subTotalVenta
        ,COALESCE(SUM(VW.IVAVenta), 0) IVAVenta
        ,COALESCE(SUM(VW.totalVenta), 0) totalVenta
		,CASE WHEN C.manejoDeUtilidad = 1 THEN C.porcentajeUtilidad ELSE -1 END AS contratoUtilidad
		,CASE WHEN COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) = 0 THEN 0 
			ELSE CAST( ((COALESCE(SUM(VW.subTotalVenta), 0) - COALESCE(SUM(VW.subTotalCosto), 0)) / COALESCE(SUM(vw.subTotalVentaSinDescuento), 0)) * 100 AS DECIMAL(18,2)) END AS utilidad
	
		,MAX(VW.porcentajeDescuentoVenta) porcentajeDescuentoVenta
		,C.manejoDescuentoVenta
		,COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) subTotalVentaSnDesc
		,COALESCE(SUM(VW.descuentoVenta), 0) descuentoVenta
    FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] VW
	JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = VW.rfcEmpresa AND C.numeroContrato = VW.numeroContrato AND C.idCliente = VW.idCliente AND C.idClase = VW.idClase
    WHERE [idSolicitud] = @idSolicitud
	    AND idEstatusCotizacionPartida IN ('ENESPERA','APROBADA')
		AND idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')
	GROUP BY C.porcentajeUtilidad,C.manejoDeUtilidad,C.manejoDescuentoVenta
	)

	select * from cte_datos

	UNION ALL

	SELECT
		0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
	WHERE NOT EXISTS (select * from cte_datos)

END

go

