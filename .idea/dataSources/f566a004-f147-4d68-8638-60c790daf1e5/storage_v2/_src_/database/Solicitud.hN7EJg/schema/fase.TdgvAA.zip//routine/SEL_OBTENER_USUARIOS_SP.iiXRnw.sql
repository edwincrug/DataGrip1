
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <10/12/2020>
-- Description:	<consulta el catalogo de usuarios>
/*
	EXEC [fase].[SEL_OBTENER_USUARIOS_SP] 6282,NULL
*/
-- =============================================
CREATE PROCEDURE [fase].[SEL_OBTENER_USUARIOS_SP]
@idUsuario INT,
@err		VARCHAR(500)OUTPUT  
AS
BEGIN

		SELECT  Id, 
				ISNULL(UserName, 'No registrado') AS UserName,
				ISNULL(PrimerNombre, '') AS PrimerNombre,
				ISNULL(SegundoNombre, '') AS SegundoNombre, 
				ISNULL(PrimerApellido, '') AS PrimerApellido, 
				ISNULL(SegundoApellido, '') AS SegundoApellido, 
				ISNULL(Email, 'No registrado') AS Email, 
				ISNULL(Celular, 'No registrado') AS Celular,
				EstatusId, 
				ISNULL(FechaRegistro, '') AS FechaRegistro,
				PassExpire, 
				(SELECT valor FROM Common.configuracion.configuracion where nombre = 'fileServer') + (select path from FileServer.documento.Documento where idDocumento = Avatar) as Avatar ,
				UID
		FROM Seguridad.[Catalogo].[Users]
		WHERE EstatusId = 1
		AND UID IS NOT NULL


		--SELECT id value,[Common].[common].SEL_NOMBRE_USUARIO_FN(id) text FROM seguridad.Catalogo.Users
		--WHERE EstatusId=1
		--ORDER BY 2 ASC
END

go

