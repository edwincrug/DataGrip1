
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 26-08-2019
-- Description: Consulta trae pasos por idtiposolicitud
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[SEL_PASOS_PORIDTIPOSOLICITUD_SP] 'Automovil', 'ASE0508051B6', '0001', 92, 'Servicio', 6077,  @salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [fase].[SEL_PASOS_PORIDTIPOSOLICITUD_SP] 
	@idClase				varchar(50),
	@rfcEmpresa				VARCHAR(13),
	@numeroContrato			VARCHAR(50),
	@idCliente				INT,
	@idTipoSolicitud		VARCHAR(10),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	SELECT
		T.idPaso
		,T.idFase
		,T.nombre
		,T.descripcion
		,T.tiempoEstimado  
		,T.idTipoSolicitud
	FROM (
					SELECT 
						[idPaso]
					  ,[idFase]
					  ,[idClase]
					  ,[idTipoSolicitud]
					  ,[nombre]
					  ,[descripcion]
					  ,[orden]
					  ,[color]
					  ,CAST([tiempoEstimado] AS time(0)) tiempoEstimado
					  ,[procedimientoAlmacenado]
					  ,[parametros]
				  FROM [Solicitud].[fase].[Paso]
				  WHERE idClase = @idClase
				  AND idTipoSolicitud = @idTipoSolicitud

				  UNION ALL

				  SELECT 
						[idPaso]
					  ,[idFase]
					  ,[idClase]
					  ,[idTipoSolicitud]
					  --,[rfcEmpresa]
					  --,[idCliente]
					  --,[numeroContrato]
					  ,[nombre]
					  ,[descripcion]
					  --,[idPasoAnterior]
					  ,[orden]
					  ,[color]
					  ,CAST([tiempoEstimado] AS time(0)) tiempoEstimado
					  ,[procedimientoAlmacenado]
					  ,[parametros]
				  FROM [Solicitud].[faseContrato].[Paso]
				  WHERE idClase = @idClase
				  AND idTipoSolicitud = @idTipoSolicitud
				  AND rfcEmpresa = @rfcEmpresa
				  AND numeroContrato = @numeroContrato
				  AND idCliente = @idCliente
				)T
	LEFT JOIN [fase].[Fase] F ON F.idFase = T.idFase
	ORDER BY F.orden, T.orden


END

go

