
-- =============================================
-- Author:		<Adolfo Martinez>
-- Create date: <10/06/2020>
-- Description:	<Procesamos estudio de mercado>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	
	*- Testing...
	declare @err varchar(500) = ''
	EXEC [compraBPRO].[UPD_APRUEBA_COMPRA_SV3_SP] 1024,'Compra','Compra','ASE0508051B6',221,'49',1,6282,null
	select @err 

*/
CREATE PROCEDURE [compraBPRO].[UPD_APRUEBA_COMPRA_SV3_SP]
	@idSolicitud INT,
	@idTipoSolicitud VARCHAR(10),
	@idClase VARCHAR(10),
	@rfcEmpresa VARCHAR(13),
	@idCliente INT,
	@numeroContrato VARCHAR(50),
	@estatusAprobacion BIT, --0 rechazada, 1 aprobada
	@idUsuario INT =null,
	@err varchar(500) OUT
AS
BEGIN

	set @err=''
	DECLARE @numeroCompraBPRO varchar(50),
			@numeroSolicitud VARCHAR(50),
			@idAutorizador INT
	
	SELECT @numeroSolicitud=numeroOrden
	FROM solicitud.SolicitudObjeto 
	WHERE idSolicitud	=@idSolicitud
	AND idTipoSolicitud	=@idTipoSolicitud
	AND idClase			=@idClase
	AND rfcEmpresa		=@rfcEmpresa
	AND idCliente		=@idCliente
	AND numeroContrato	=@numeroContrato

	SET @idAutorizador=@idUsuario

	UPDATE compraBPRO.Solicitud
	SET 
		aprobacionCompra=GETDATE(), 
		idAprobadorCompra=@idAutorizador
	WHERE 
		idSolicitud=@idSolicitud

	IF(@estatusAprobacion = 0)
		BEGIN
			UPDATE solicitud.solicitud
			SET idEstatusSolicitud='CANCELADA'
			WHERE idSolicitud=@idSolicitud
			
			UPDATE fase.SolicitudEstatusPaso 
			SET fechaSalida=GETDATE(), idUsuarioSalida=3132
			WHERE idSolicitud=@idSolicitud AND fechaSalida IS NULL AND idUsuarioSalida IS NULL

			return
		END

	--generamos la orden de compra de forma automatica
	DECLARE @salida varchar(max) ='' ;
    EXEC [compraBPRO].[UPD_SOLICITUD_GENERAORDENCOMPRA_SP] 
		@idSolicitud,
		'Compra',
		'Compra',
		@rfcEmpresa,
		@idCliente,
		@numeroContrato,
		3132,
		@salida out

	select @numeroCompraBPRO = ppg_ordenCompra from compraBPRO.Solicitud where idSolicitud=@idSolicitud
	
	--ACTUALIZAMOS AUTORIZADOR DE COMPRA QUE VIENE DE NOTIFICACIONES
	print 'actualizamos autorizador: ' + convert(varchar,@idAutorizador) + ' en: ' + @numeroCompraBPRO
	update [192.168.20.123].cuentasxpagar.dbo.pre_pedidogastos set ppg_idusuarioautoriza=@idAutorizador where ppg_ordencompra= @numeroCompraBPRO

	--AVANZAMOS LA ORDEN
	create table #temp(idTarea int)
	insert into #temp 
	EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP] @idSolicitud,'Compra','Compra',@rfcEmpresa,@idCliente,@numeroContrato,0,0,3132,''
	drop table #temp

END
go

