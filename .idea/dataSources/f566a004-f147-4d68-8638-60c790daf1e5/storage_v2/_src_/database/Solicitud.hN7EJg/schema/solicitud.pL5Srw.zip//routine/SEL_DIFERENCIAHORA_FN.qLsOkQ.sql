-- =============================================
-- Author:		Gerardo Zamudio
-- Create date: 23/07/2019
-- Description:	Genera el tiempo de direfencia de una fecha en horas.
-- Test:		SELECT [solicitud].[SEL_DIFERENCIAHORA_FN]
-- =============================================
CREATE FUNCTION [solicitud].[SEL_DIFERENCIAHORA_FN]
(
  @fechaInicio				Datetime,       -- Dia inicio
  @fechaFin					Datetime,        -- Dia fin
  @tiempoEstimado			time
        -- Formato: #d HH:MM:SS
        -- Sample:
                        -- Set dateformat ymd
                        -- SELECT dbo.ufn_CalcularDiferenciaenHoras('2017-10-01 01:46:00', '2017-10-17 10:45:00')
                        -- Return: 16d 08:59:00
)
RETURNS VARCHAR(MAX)
AS 
BEGIN
	DECLARE @segundos BIGINT, @tiempo VARCHAR(MAX), @tiempo2 varchar(MAX), @horas varchar(MAX);
	SET @segundos = ( SELECT datediff(SECOND,@fechaInicio, @fechaFin) )
	SET @segundos = @segundos % 86400
	SET @segundos = @segundos % 3600
	--SET @tiempo2 = (CONVERT(VARCHAR(MAX), @tiempoEstimado));
	SET @tiempo = (SELECT 
	--CONVERT(VARCHAR(MAX), DATEDIFF(DAY,@fechaInicio,@fechaFin )) +':'+
	CONVERT(VARCHAR(MAX), DATEDIFF(HOUR,@fechaInicio,@fechaFin ))+':'+
	CONVERT(VARCHAR, FLOOR(@segundos / 60))+':'+
	CONVERT(VARCHAR, @segundos % 60)
	as TotalSeconds);

	SET @horas = (select (CONVERT(INT, DATEDIFF(HOUR,@fechaInicio,@fechaFin )) - CONVERT(INT, DATEPART(HOUR, @tiempoEstimado))));
	RETURN (
	select DATEDIFF(minute, DATEPART(minute, @tiempoEstimado), FLOOR(@segundos / 60))
	)
END
go

