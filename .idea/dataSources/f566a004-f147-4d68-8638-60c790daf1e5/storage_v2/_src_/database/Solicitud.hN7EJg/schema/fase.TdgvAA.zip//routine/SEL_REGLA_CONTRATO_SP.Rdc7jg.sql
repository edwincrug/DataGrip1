
-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 02/07/2019
-- Description: Obtiene las reglas de paso o la regla de acuerdo al contrato enviado
-- ============== Versionamiento ================
/*
	*- Testing...
	EXEC fase.SEL_REGLA_CONTRATO_SP @idSolicitud = 730, @rfcEmpresa = 'ASE0508051B6', @idCliente = 220, @numeroContrato = '129', @idClase = 'Automovil', @idTipoSolicitud = 'Servicio', @idUsuario = 3135

*/
-- =============================================
CREATE PROCEDURE [fase].[SEL_REGLA_CONTRATO_SP]
	@idSolicitud INT,
	@idTipoSolicitud VARCHAR(10),
	@idClase VARCHAR(10),
	@rfcEmpresa VARCHAR(13),
	@idCliente INT,
	@numeroContrato VARCHAR(50),
	@idUsuario INT = NULL,
	@err VARCHAR(500) = NULL OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @idPaso VARCHAR(50)
			, @idFase VARCHAR(20)
		SELECT @idPaso = idPaso, @idFase = idFase from  [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud)

		SELECT RP.idReglaPaso
			, RP.idPaso
			, RP.idFase
			, RP.idClase
			, RP.idTipoSolicitud
			, RP.rfcEmpresa
			, RP.idCliente
			, RP.numeroContrato
			, RP.orden AS ordenReglaPaso
			, ISNULL(RP.activo, 0) AS activo
			, ISNULL(RP.aplicaReglaRol, 0) AS aplicaReglaRol
			, ISNULL(RP.aplicaReglaMonto, 0) AS aplicaReglaMonto
			, ISNULL(RP.aplicaReglaUsuario, 0) AS aplicaReglaUsuario
			, ISNULL(RP.aplicaReglaPartida, 0) AS aplicaReglaPartida
			, ISNULL(RP.aplicaReglaObjeto, 0) AS aplicaReglaObjeto
			, ISNULL(RP.idNivel, 0) AS idNivel
			, F.nombre AS nombreFase
			, F.descripcion AS descripcionFase
			, F.orden AS ordenFase
			, P.nombre AS pasoNombre
			, P.color AS pasoColor
			, @idUsuario AS idUsuario
			, CN.color AS colorNivel
		FROM fase.ReglaPaso RP
		LEFT JOIN fase.Fase F ON RP.idFase = F.idFase
		LEFT JOIN fase.Paso P ON RP.idPaso = P.idPaso
			AND RP.idFase = P.idFase
			AND RP.idClase = P.idClase
			AND RP.idTipoSolicitud = P.idTipoSolicitud
		LEFT JOIN [Cliente].[contrato].[ContratoNivel] CN ON RP.idNivel = CN.idNivel
			AND RP.rfcEmpresa = CN.rfcEmpresa
			AND RP.idCliente = CN.idCliente
			AND RP.numeroContrato = CN.numeroContrato
			AND RP.idTipoSolicitud = CN.idTipoSolicitud
			AND RP.idClase = CN.idClase
		WHERE RP.rfcEmpresa = @rfcEmpresa
			AND RP.idCliente = @idCliente
			AND RP.numeroContrato = @numeroContrato
			AND RP.idPaso = @idPaso
			AND RP.idFase = @idFase
			AND RP.idClase = @idClase
			AND RP.idTipoSolicitud = @idTipoSolicitud
			AND RP.activo = 1
		ORDER BY RP.orden ASC

		SELECT SCP.idCotizacion
			, SCP.idPartida
			, SCP.idTipoObjeto
			, SCP.idClase
			, SCP.cantidad
			, SCP.costo
			, SCP.venta
			, SCP.idEstatusCotizacionPartida
			,ROUND((ISNULL(SCP.venta,0) * ISNULL(SCP.cantidad,0)), 2) AS montoEvaluar
			, ECP.nombre AS nombreEstatusCotizacionPartida
			, '' AS colorNivel
		FROM solicitud.SolicitudObjeto SO
		INNER JOIN solicitud.SolicitudCotizacionPartida SCP
		ON SO.idSolicitud = SCP.idSolicitud
			AND SO.idTipoObjeto = SCP.idTipoObjeto
			AND SO.idClase = SCP.idClase
			AND SO.rfcEmpresa = SCP.rfcEmpresa
			AND SO.idCliente = SCP.idCliente
			AND SO.numeroContrato = SCP.numeroContrato
			AND SO.idTipoSolicitud = SCP.idTipoSolicitud
			AND SO.idObjeto = SCP.idObjeto
		INNER JOIN solicitud.EstatusCotizacionPartida ECP
			ON SCP.idEstatusCotizacionPartida = ECP.idEstatusCotizacionPartida
		WHERE SO.idSolicitud = @idSolicitud
			AND SO.idTipoSolicitud = @idTipoSolicitud
			AND SO.idClase = @idClase
			AND SO.rfcEmpresa = @rfcEmpresa
			AND SO.idCliente = @idCliente
			AND SO.numeroContrato = @numeroContrato
	END TRY
	BEGIN CATCH
		SELECT @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
	END CATCH
END

go

