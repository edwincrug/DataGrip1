
-- =============================================
-- Author: Adolfo Martinez
-- Create date: 05-07-2019
-- Description: Consulta devuelve solicitudes dependiendo el paso
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	25-06-2020  JLuis Lozada	Se agrego el campo CXC Copade
	30-07-2020	JLuis Lozada	Se agrego la columna Agrupamiento

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[SEL_SOLICITUD_PASO_COBRANZA_SP]  'Solicitud','Requerimiento', 'Compra', 2270,
	'<contratos><contrato><numeroContrato>49</numeroContrato><idCliente>221</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato></contratos>',
	0, 0, 0, @salida OUTPUT;
	SELECT @salida AS salida;

	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[SEL_SOLICITUD_PASO_COBRANZA_SP]  'Cobranza','PrefacturaGenerada', 'Automovil', 2270,
	'<contratos><contrato><numeroContrato>00001</numeroContrato><idCliente>152</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>00001</numeroContrato><idCliente>155</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>0001BONAFONT</numeroContrato><idCliente>156</idCliente><rfcEmpresa>AAN910409135</rfcEmpresa></contrato><contrato><numeroContrato>127</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>128</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>129</numeroContrato><idCliente>220</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>2244</numeroContrato><idCliente>213</idCliente><rfcEmpresa>AAN910409135</rfcEmpresa></contrato><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato><contrato><numeroContrato>131</numeroContrato><idCliente>106</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato></contratos>',
	0, 0, 0, @salida OUTPUT;
	SELECT @salida AS salida;
	--385
*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_SOLICITUD_PASO_COBRANZA_SP] 
	@idFase					varchar(50) = 'null',
	@idPaso					varchar(50) = 'null',
	@idClase				varchar(10),
	@idUsuario				INT,
	@contratos				XML,
	@idZona					INT = 0,
	@idObjeto				INT = 0,
	@idTipoObjeto			INT = 0,
	@err					varchar(500)OUTPUT
AS
BEGIN

	/************************************************** CONFIG CONTRATOS **************************************************/
	DECLARE @tbl_contratos AS TABLE(numeroContrato VARCHAR(50),idCliente INT,rfc VARCHAR(13))
	DECLARE @proveedores table (rfcProveedor VARCHAR(13), idProveedorEntidad INT)
	DECLARE @rolProveedor			BIT = 0
	DECLARE @camposPivot			VARCHAR(MAX),
			@camposPivotKey			VARCHAR(200),
			@sq						VARCHAR(MAX),
			@TablaObjetoFinal		VARCHAR(50),
			@TablaSolicitudFinal	VARCHAR(50),
			@sqx					VARCHAR(MAX) = ''

	INSERT INTO @proveedores
	SELECT	rfcProveedor,idProveedorEntidad
	FROM	Seguridad.[Relacion].[Usser_proveedor]
	WHERE	idUsuario = @idUsuario

	IF EXISTS(SELECT 1 FROM Seguridad.[Relacion].[Usser_proveedor] WHERE idUsuario = @idUsuario)
		BEGIN
			SET @rolProveedor = 1
			SELECT	DISTINCT idSolicitud
			INTO	#solicitudesProveedor
			FROM	Solicitud.solicitud.SolicitudCotizacion sc
			INNER	JOIN @proveedores p ON p.rfcProveedor = sc.rfcProveedor and  p.idProveedorEntidad = sc.idProveedorEntidad
		END

	INSERT INTO @tbl_contratos
	SELECT	ParamValues.col.value('numeroContrato[1]','varchar(50)'),
			ParamValues.col.value('idCliente[1]','int'),
			ParamValues.col.value('rfcEmpresa[1]','varchar(13)')
	FROM	@contratos.nodes('contratos/contrato') AS ParamValues(col)
	/************************************************** CONFIG CONTRATOS **************************************************/
	
	IF OBJECT_ID('tempdb..#tablaGeneralDatos')IS NOT NULL DROP TABLE #tablaGeneralDatos

	SELECT 	* INTO #tablaGeneralDatos
	FROM(	SELECT	SSO.numeroOrden,
					'Simple' 'Agrupamiento',
					CLCO.rfcEmpresa,
					CLCO.nombre AS 'nombreContrato',
					CCC.nombre AS 'Cliente',
					[common].[gerencia].SEL_OBTENERZONA_FN(SOL.rfcEmpresa,SOL.idCliente,SOL.numeroContrato,SOL.idClase,SSO.idTipoObjeto,SSO.idObjeto) AS 'Zona',
					SOL.fechaCreacion,
					SEP.fechaIngreso,
					STS.nombre AS 'tipoDeOrden',
					CASE WHEN 'Automovil' = 'Automovil' THEN [solicitud].[SEL_TIPOMANTENIMIENTO_FN](SSO.idSolicitud) ELSE STS.nombre END AS 'tipoDeServicio',
					SOL.comentarios AS 'Comentarios',
					FP.nombre AS 'Estatus',

					(	SELECT	COALESCE(SUM(VW.subTotalCosto), 0) 
						FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
						WHERE	VW.idSolicitud = SOL.idSolicitud 
						AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
						AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'Costo',
					
					(	SELECT	COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) 
						FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
						WHERE	VW.idSolicitud = SOL.idSolicitud 
						AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
						AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'ventaSnDesc',

					(	SELECT	COALESCE(SUM(VW.descuentoVenta), 0) 
						FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
						WHERE	VW.idSolicitud = SOL.idSolicitud 
						AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
						AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'descuentoVenta',
					
					(	SELECT	COALESCE(SUM(VW.subTotalVenta), 0) 
						FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
						WHERE	VW.idSolicitud = SOL.idSolicitud 
						AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
						AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'Venta',
					PrimerNombre + ' ' + SegundoNombre + ' ' + PrimerApellido + ' ' + SegundoApellido AS 'Agendó',
					[solicitud].[SEL_DIASSOL_FN](SSO.idSolicitud) AS 'Tiempo transcurrido',
					(	SELECT STUFF((	SELECT	',' + CAST(SC.rfcProveedor AS VARCHAR(MAX))
										FROM	[solicitud].[SolicitudCotizacion] AS SC
										WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'RFCProveedor',
					(	SELECT STUFF((	SELECT	',' + CAST(RazonSocial AS VARCHAR(MAX))
										FROM	[solicitud].[SolicitudCotizacion] AS SC
										INNER	JOIN [Proveedor].[proveedor].[Proveedor] AS PE ON SC.[rfcProveedor] = PE.rfcProveedor
										WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'razonSocial',
					(	SELECT STUFF((	SELECT	',' + CAST(nombreComercial AS VARCHAR(MAX))
										FROM	[solicitud].[SolicitudCotizacion] AS SC
										INNER	JOIN [Proveedor].[proveedor].[ProveedorEntidad] AS PE ON SC.[rfcProveedor] = PE.rfcProveedor AND SC.idProveedorEntidad = PE.idProveedorEntidad
										WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'nombreComercial',

					CASE WHEN EXISTS (	SELECT 1
										FROM	solicitud.cxc.factura fa 
										WHERE	fa.idSolicitud		=sol.idSolicitud 
										AND     fa.idTipoSolicitud	=sol.idTipoSolicitud
										AND		fa.idClase			=sol.idClase   
										AND     fa.rfcEmpresa		=sol.rfcEmpresa
										AND     fa.idCliente		=sol.idCliente
										AND     fa.numeroContrato	=sol.numeroContrato) THEN 'Provisionada' ELSE 'Sin provisionar' END AS 'CXP_EstatusProvision',

					(SELECT [solicitud].[SEL_OBTENERIDSCOMPRA_FN](sol.idSolicitud,sol.idTipoSolicitud,sol.idClase,sol.rfcEmpresa,sol.idCliente,sol.numeroContrato)) AS 'CXP_NoCompra',
					(	SELECT	STUFF((	SELECT	',' +  CAST(ISNULL(F.serie,'') AS VARCHAR(MAX)) + CAST(ISNULL(F.folio,'') AS VARCHAR(MAX))
										FROM	[Solicitud].[cxp].[Factura] F
										JOIN	[Solicitud].[cxp].[SolicitudCotizacionFactura] SCF ON SCF.UUID = F.UUID
										WHERE	SCF.idSolicitud		=sol.idSolicitud 
										AND		SCF.idTipoSolicitud	=sol.idTipoSolicitud
										AND		SCF.idClase			=sol.idClase   
										AND		SCF.rfcEmpresa		=sol.rfcEmpresa
										AND		SCF.idCliente		=sol.idCliente
										AND		SCF.numeroContrato	=sol.numeroContrato  FOR XML PATH('')),1,1,'')) AS 'CXP_Factura',
						/************************************************** CXP **************************************************/
					(	SELECT	TOP 1 FAB.CCP_IDDOCTO 
						FROM	cxc.Factura F
						JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
						JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
						WHERE	F.idSolicitud		=sol.idSolicitud 
						AND		F.idTipoSolicitud	=sol.idTipoSolicitud
						AND		F.idClase			=sol.idClase   
						AND		F.rfcEmpresa		=sol.rfcEmpresa
						AND		F.idCliente			=sol.idCliente
						AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Factura',
					(	SELECT	TOP 1 FA.numeroCopade 
						FROM	cxc.Factura F
						JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
						WHERE	F.idSolicitud		=sol.idSolicitud 
						AND		F.idTipoSolicitud	=sol.idTipoSolicitud
						AND		F.idClase			=sol.idClase   
						AND		F.rfcEmpresa		=sol.rfcEmpresa
						AND		F.idCliente			=sol.idCliente
						AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Copade',
					(	SELECT	TOP 1 FAB.IMPORTE 
						FROM	cxc.Factura F
						JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
						JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
						WHERE	F.idSolicitud		=sol.idSolicitud 
						AND		F.idTipoSolicitud	=sol.idTipoSolicitud
						AND		F.idClase			=sol.idClase   
						AND		F.rfcEmpresa		=sol.rfcEmpresa
						AND		F.idCliente			=sol.idCliente
						AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Importe',
					(	SELECT	TOP 1 FAB.SALDO 
						FROM	cxc.Factura F
						JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
						JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
						WHERE	F.idSolicitud		=sol.idSolicitud 
						AND		F.idTipoSolicitud	=sol.idTipoSolicitud
						AND		F.idClase			=sol.idClase   
						AND		F.rfcEmpresa		=sol.rfcEmpresa
						AND		F.idCliente			=sol.idCliente
						AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Saldo',
					(	SELECT	TOP 1 FAB.CCP_FECHADOCTO FROM cxc.Factura F
						JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
						JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
						WHERE	F.idSolicitud		=sol.idSolicitud 
						AND		F.idTipoSolicitud	=sol.idTipoSolicitud
						AND		F.idClase			=sol.idClase   
						AND		F.rfcEmpresa		=sol.rfcEmpresa
						AND		F.idCliente			=sol.idCliente
						AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_FechaFactura',

					--Otros
					SOL.idSolicitud,FP.color as colour,SEP.idPaso,SEP.idFase,SSO.idObjeto,SSO.idTipoObjeto,STS.idTipoSolicitud,
					CLCO.idFileAvatar AS 'idLogoContrato',SEP.idCliente,SEP.numeroContrato,CCO.idContratoZona

				FROM	[fase].[Paso] FP  
				INNER	JOIN fase.solicitudestatuspaso SEP					ON FP.idPaso = SEP.idPaso AND FP.idClase = SEP.idClase AND FP.idTipoSolicitud = SEP.idTipoSolicitud
				INNER	JOIN solicitud.solicitud SOL						ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase
				INNER	JOIN [solicitud].[TipoSolicitud] STS				ON STS.idTipoSolicitud = SOL.idTipoSolicitud  AND STS.idClase = SOL.idClase
				INNER	JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO	ON SSO.idSolicitud = SOL.idSolicitud
				INNER	JOIN [Cliente].[contrato].[Objeto] CCO				ON CCO.idObjeto = SSO.idObjeto
				INNER	JOIN [cliente].[cliente].[Cliente] CCC				ON CCC.idCliente = CCO.idCliente
				INNER	JOIN [common].[gerencia].[ContratoZona] CGC			ON CGC.idContratoZona = CCO.idContratoZona 
				LEFT	JOIN [Seguridad].[Catalogo].[Users] SCU				ON SCU.Id = SOL.idUsuario
				INNER	JOIN @tbl_contratos CON								ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa
				INNER	JOIN [cliente].[cliente].[Contrato] CLCO			ON CLCO.rfcEMpresa = SOL.rfcEmpresa AND CLCO.idCliente = SOL.idCliente AND CLCO.numeroContrato = SOL.numeroContrato
				WHERE	SEP.idClase				= @idClase
				AND		SOL.idEstatusSolicitud	= 'ACTIVA'
				AND		SEP.fechaSalida			IS NULL
				AND		SOL.esMultiple=0
				--AND     (	SELECT	COUNT(*) 
				--				FROM	Solicitud.solicitud.SolicitudObjeto 
				--				WHERE	idSolicitud		= sol.idSolicitud 
				--				AND     idTipoSolicitud	= sol.idTipoSolicitud
				--				AND     idClase			= sol.idClase
				--				AND     rfcEmpresa		= sol.rfcEmpresa
				--				AND		idCliente		= sol.idCliente
				--				AND     numeroContrato	= sol.numeroContrato)=1
				UNION
				SELECT	SOL.numero AS 'numeroOrden',
						'Multiple' 'Agrupamiento',
						CLCO.rfcEmpresa,
						CLCO.nombre AS 'nombreContrato',
						CCC.nombre AS 'Cliente',
						NULL Zona,
						SOL.fechaCreacion,
						SEP.fechaIngreso,
						STS.nombre AS 'tipoDeOrden',
						CASE WHEN 'Automovil' = 'Automovil' THEN [solicitud].[SEL_TIPOMANTENIMIENTO_FN](SOL.idSolicitud) ELSE STS.nombre END AS 'tipoDeServicio',
						SOL.comentarios AS 'Comentarios',
						FP.nombre AS 'Estatus',

						(	SELECT	COALESCE(SUM(VW.subTotalCosto), 0) 
							FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
							WHERE	VW.idSolicitud = SOL.idSolicitud 
							AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
							AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'Costo',
					
						(	SELECT	COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) 
							FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
							WHERE	VW.idSolicitud = SOL.idSolicitud 
							AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
							AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'ventaSnDesc',

						(	SELECT	COALESCE(SUM(VW.descuentoVenta), 0) 
							FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
							WHERE	VW.idSolicitud = SOL.idSolicitud 
							AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
							AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'descuentoVenta',
					
						(	SELECT	COALESCE(SUM(VW.subTotalVenta), 0) 
							FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
							WHERE	VW.idSolicitud = SOL.idSolicitud 
							AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
							AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'Venta',
						PrimerNombre + ' ' + SegundoNombre + ' ' + PrimerApellido + ' ' + SegundoApellido AS 'Agendó',
						[solicitud].[SEL_DIASSOL_FN](SOL.idSolicitud) AS 'Tiempo transcurrido',
						(	SELECT STUFF((	SELECT	',' + CAST(SC.rfcProveedor AS VARCHAR(MAX))
											FROM	[solicitud].[SolicitudCotizacion] AS SC
											WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'RFCProveedor',
						(	SELECT STUFF((	SELECT	',' + CAST(RazonSocial AS VARCHAR(MAX))
											FROM	[solicitud].[SolicitudCotizacion] AS SC
											INNER	JOIN [Proveedor].[proveedor].[Proveedor] AS PE ON SC.[rfcProveedor] = PE.rfcProveedor
											WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'razonSocial',
						(	SELECT STUFF((	SELECT	',' + CAST(nombreComercial AS VARCHAR(MAX))
											FROM	[solicitud].[SolicitudCotizacion] AS SC
											INNER	JOIN [Proveedor].[proveedor].[ProveedorEntidad] AS PE ON SC.[rfcProveedor] = PE.rfcProveedor AND SC.idProveedorEntidad = PE.idProveedorEntidad
											WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'nombreComercial',

						CASE WHEN EXISTS (	SELECT 1
											FROM	solicitud.cxc.factura fa 
											WHERE	fa.idSolicitud		=sol.idSolicitud 
											AND     fa.idTipoSolicitud	=sol.idTipoSolicitud
											AND		fa.idClase			=sol.idClase   
											AND     fa.rfcEmpresa		=sol.rfcEmpresa
											AND     fa.idCliente		=sol.idCliente
											AND     fa.numeroContrato	=sol.numeroContrato) THEN 'Provisionada' ELSE 'Sin provisionar' END AS 'CXP_EstatusProvision',

						(SELECT [solicitud].[SEL_OBTENERIDSCOMPRA_FN](sol.idSolicitud,sol.idTipoSolicitud,sol.idClase,sol.rfcEmpresa,sol.idCliente,sol.numeroContrato)) AS 'CXP_NoCompra',
						(	SELECT	STUFF((	SELECT	',' +  CAST(ISNULL(F.serie,'') AS VARCHAR(MAX)) + CAST(ISNULL(F.folio,'') AS VARCHAR(MAX))
											FROM	[Solicitud].[cxp].[Factura] F
											JOIN	[Solicitud].[cxp].[SolicitudCotizacionFactura] SCF ON SCF.UUID = F.UUID
											WHERE	SCF.idSolicitud		=sol.idSolicitud 
											AND		SCF.idTipoSolicitud	=sol.idTipoSolicitud
											AND		SCF.idClase			=sol.idClase   
											AND		SCF.rfcEmpresa		=sol.rfcEmpresa
											AND		SCF.idCliente		=sol.idCliente
											AND		SCF.numeroContrato	=sol.numeroContrato  FOR XML PATH('')),1,1,'')) AS 'CXP_Factura',
						(	SELECT	TOP 1 FAB.CCP_IDDOCTO 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Factura',
						(	SELECT	TOP 1 FA.numeroCopade 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Copade',
						(	SELECT	TOP 1 FAB.IMPORTE 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Importe',
						(	SELECT	TOP 1 FAB.SALDO 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Saldo',
						(	SELECT	TOP 1 FAB.CCP_FECHADOCTO FROM cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_FechaFactura',

						--Otros
						SOL.idSolicitud,FP.color as colour,SEP.idPaso,SEP.idFase,NULL idObjeto,NULL idTipoObjeto,STS.idTipoSolicitud,
						CLCO.idFileAvatar AS 'idLogoContrato',SEP.idCliente,SEP.numeroContrato, NULL idContratoZona

				FROM	[fase].[Paso] FP  
				INNER	JOIN fase.solicitudestatuspaso SEP					ON FP.idPaso = SEP.idPaso AND FP.idClase = SEP.idClase AND FP.idTipoSolicitud = SEP.idTipoSolicitud
				INNER	JOIN solicitud.solicitud SOL						ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase
				INNER	JOIN [solicitud].[TipoSolicitud] STS				ON STS.idTipoSolicitud = SOL.idTipoSolicitud  AND STS.idClase = SOL.idClase
				INNER	JOIN [cliente].[cliente].[Cliente] CCC				ON CCC.idCliente = SOL.idCliente
				LEFT	JOIN [Seguridad].[Catalogo].[Users] SCU				ON SCU.Id = SOL.idUsuario
				INNER	JOIN @tbl_contratos CON								ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa
				INNER	JOIN [cliente].[cliente].[Contrato] CLCO			ON CLCO.rfcEMpresa = SOL.rfcEmpresa AND CLCO.idCliente = SOL.idCliente AND CLCO.numeroContrato = SOL.numeroContrato
				WHERE	SEP.idClase				= @idClase
				AND		SOL.idEstatusSolicitud	= 'ACTIVA'
				AND		SEP.fechaSalida			IS NULL
				AND		SOL.esMultiple=1
				--AND     (	SELECT	COUNT(*) 
				--				FROM	Solicitud.solicitud.SolicitudObjeto 
				--				WHERE	idSolicitud		= sol.idSolicitud 
				--				AND     idTipoSolicitud	= sol.idTipoSolicitud
				--				AND     idClase			= sol.idClase
				--				AND     rfcEmpresa		= sol.rfcEmpresa
				--				AND		idCliente		= sol.idCliente
				--				AND     numeroContrato	= sol.numeroContrato)>1
				UNION
				SELECT
						SSO.numeroOrden,
						'Simple' 'Agrupamiento',
						CLCO.rfcEmpresa,
						CLCO.nombre AS 'nombreContrato',
						CCC.nombre AS 'Cliente',
						[common].[gerencia].SEL_OBTENERZONA_FN(SOL.rfcEmpresa,SOL.idCliente,SOL.numeroContrato,SOL.idClase,SSO.idTipoObjeto,SSO.idObjeto) AS 'Zona',
						SOL.fechaCreacion,
						SEP.fechaIngreso,
						STS.nombre AS 'tipoDeOrden',
						CASE WHEN 'Automovil' = 'Automovil' THEN [solicitud].[SEL_TIPOMANTENIMIENTO_FN](SSO.idSolicitud) ELSE STS.nombre END AS 'tipoDeServicio',
						SOL.comentarios AS 'Comentarios',
						FP.nombre AS 'Estatus',
						(	SELECT	COALESCE(SUM(VW.subTotalCosto), 0) 
							FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
							WHERE	VW.idSolicitud = SOL.idSolicitud 
							AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
							AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'Costo',
						
						(	SELECT	COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) 
							FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
							WHERE	VW.idSolicitud = SOL.idSolicitud 
							AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
							AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'ventaSnDesc',
						(	SELECT	COALESCE(SUM(VW.descuentoVenta), 0) 
							FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
							WHERE	VW.idSolicitud = SOL.idSolicitud AND VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
							AND VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'descuentoVenta',

						(	SELECT	COALESCE(SUM(VW.subTotalVenta), 0) 
							FROM	[solicitud].[SEL_TOTALES_PARTIDAS_VW] VW 
							WHERE	VW.idSolicitud = SOL.idSolicitud 
							AND		VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA') 
							AND		VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')) AS 'Venta',
						PrimerNombre + ' ' + SegundoNombre + ' ' + PrimerApellido + ' ' + SegundoApellido AS 'Agendó',
						[solicitud].[SEL_DIASSOL_FN](SSO.idSolicitud) AS 'Tiempo transcurrido',
						(	SELECT STUFF((	SELECT	',' + CAST(SC.rfcProveedor AS VARCHAR(MAX))
											FROM	[solicitud].[SolicitudCotizacion] AS SC
											WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'RFCProveedor',
						(	SELECT STUFF((	SELECT	',' + CAST(RazonSocial AS VARCHAR(MAX))
											FROM	[solicitud].[SolicitudCotizacion] AS SC
											INNER	JOIN [Proveedor].[proveedor].[Proveedor] AS PE ON SC.[rfcProveedor] = PE.rfcProveedor
											WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'razonSocial',
						(	SELECT STUFF((	SELECT	',' + CAST(nombreComercial AS VARCHAR(MAX))
											FROM	[solicitud].[SolicitudCotizacion] AS SC
											INNER	JOIN [Proveedor].[proveedor].[ProveedorEntidad] AS PE ON SC.[rfcProveedor] = PE.rfcProveedor AND SC.idProveedorEntidad = PE.idProveedorEntidad
											WHERE	idSolicitud = SOL.idSolicitud  FOR XML PATH('')),1,1,'')) AS 'nombreComercial',
						CASE WHEN EXISTS (	SELECT 1
											FROM	solicitud.cxc.factura fa 
											WHERE	fa.idSolicitud		=sol.idSolicitud 
											AND     fa.idTipoSolicitud	=sol.idTipoSolicitud
											AND		fa.idClase			=sol.idClase   
											AND     fa.rfcEmpresa		=sol.rfcEmpresa
											AND     fa.idCliente		=sol.idCliente
											AND     fa.numeroContrato	=sol.numeroContrato) THEN 'Provisionada' ELSE 'Sin provisionar' END AS 'CXP_EstatusProvision',
						(	SELECT [solicitud].[SEL_OBTENERIDSCOMPRA_FN](sol.idSolicitud,sol.idTipoSolicitud,sol.idClase,sol.rfcEmpresa,sol.idCliente,sol.numeroContrato)) AS 'CXP_NoCompra',
						(	SELECT	STUFF((	SELECT	',' +  CAST(ISNULL(F.serie,'') AS VARCHAR(MAX)) + CAST(ISNULL(F.folio,'') AS VARCHAR(MAX))
											FROM	[Solicitud].[cxp].[Factura] F
											JOIN	[Solicitud].[cxp].[SolicitudCotizacionFactura] SCF ON SCF.UUID = F.UUID
											WHERE	SCF.idSolicitud		=sol.idSolicitud 
											AND		SCF.idTipoSolicitud	=sol.idTipoSolicitud
											AND		SCF.idClase			=sol.idClase   
											AND		SCF.rfcEmpresa		=sol.rfcEmpresa
											AND		SCF.idCliente		=sol.idCliente
											AND		SCF.numeroContrato	=sol.numeroContrato  FOR XML PATH('')),1,1,'')) AS 'CXP_Factura',
						(	SELECT TOP 1 FAB.CCP_IDDOCTO 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Factura',
						(	SELECT	TOP 1 FA.numeroCopade 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Copade',
						(	SELECT TOP 1 FAB.IMPORTE 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Importe',
						(	SELECT	TOP 1 FAB.SALDO 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_Saldo',
						(	SELECT	TOP 1 FAB.CCP_FECHADOCTO 
							FROM	cxc.Factura F
							JOIN	cxc.FacturaAgrupada FA ON FA.idFactura = F.idFactura
							JOIN	cxc.FacturaAgrupadaBPRO FAB ON FAB.numeroCopade = FA.numeroCopade
							WHERE	F.idSolicitud		=sol.idSolicitud 
							AND		F.idTipoSolicitud	=sol.idTipoSolicitud
							AND		F.idClase			=sol.idClase   
							AND		F.rfcEmpresa		=sol.rfcEmpresa
							AND		F.idCliente			=sol.idCliente
							AND		F.numeroContrato	=sol.numeroContrato) AS 'CXC_FechaFactura',

						--Otros
						SOL.idSolicitud,FP.color as colour,SEP.idPaso,SEP.idFase,SSO.idObjeto,SSO.idTipoObjeto,STS.idTipoSolicitud,
						CLCO.idFileAvatar AS 'idLogoContrato',SEP.idCliente,SEP.numeroContrato,CCO.idContratoZona
						 
				FROM	[faseContrato].[Paso] FP  
				INNER	JOIN [faseContrato].[SolicitudEstatusPaso] SEP			ON FP.idPaso = SEP.idPaso AND FP.idClase = SEP.idClase AND FP.idTipoSolicitud = SEP.idTipoSolicitud
				INNER	JOIN solicitud.solicitud SOL							ON SOL.idSolicitud = SEP.idSolicitud AND SOL.idClase = SEP.idClase
				INNER	JOIN [solicitud].[TipoSolicitud] STS					ON STS.idTipoSolicitud = SOL.idTipoSolicitud AND STS.idClase = SOL.idClase
				INNER	JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO		ON SSO.idSolicitud = SOL.idSolicitud
				INNER	JOIN [Cliente].[contrato].[Objeto] CCO					ON CCO.idObjeto = SSO.idObjeto
				INNER	JOIN [cliente].[cliente].[Cliente] CCC					ON CCC.idCliente = CCO.idCliente
				INNER	JOIN [common].[gerencia].[ContratoZona] CGC				ON CGC.idContratoZona = CCO.idContratoZona 
				LEFT	JOIN [Seguridad].[Catalogo].[Users] SCU					ON SCU.Id = SOL.idUsuario
				INNER	JOIN @tbl_contratos CON									ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa
				INNER	JOIN [cliente].[cliente].[Contrato] CLCO				ON CLCO.rfcEMpresa = SOL.rfcEmpresa AND CLCO.idCliente = SOL.idCliente AND CLCO.numeroContrato = SOL.numeroContrato
				WHERE	SEP.idClase = @idClase
				AND		SOL.idEstatusSolicitud = 'ACTIVA'
				AND		SEP.fechaSalida			IS NULL
				AND		SOL.esMultiple=0
				--AND     (	SELECT	COUNT(*) 
				--				FROM	Solicitud.solicitud.SolicitudObjeto 
				--				WHERE	idSolicitud		= sol.idSolicitud 
				--				AND     idTipoSolicitud	= sol.idTipoSolicitud
				--				AND     idClase			= sol.idClase
				--				AND     rfcEmpresa		= sol.rfcEmpresa
				--				AND		idCliente		= sol.idCliente
				--				AND     numeroContrato	= sol.numeroContrato)=1
				)T
		WHERE	(@idFase = 'null' OR (@idFase != 'null' AND idFase = @idFase)) 
		AND		(@idPaso = 'null' OR (@idPaso != 'null' AND idPaso = @idPaso)) 
		AND		(@idZona = 0 OR (@idZona > 0 AND idContratoZona = @idZona)) 
		AND		(@idObjeto = 0 OR (@idObjeto > 0 AND idObjeto = @idObjeto)) 
		AND		(@idTipoObjeto = 0 OR (@idTipoObjeto > 0 AND idTipoObjeto = @idTipoObjeto))	


		/************************************************** OBJETO DINAMICO **************************************************/
		--JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa

		IF OBJECT_ID('tempdb..#tablaObjetoDatos')IS NOT NULL DROP TABLE #tablaObjetoDatos
		/*Modificar el query que llena la tabla @tObjeto al integrar en sp para que tome los filtros de la consulta general*/
		DECLARE @tObjeto TABLE(idTipoObjeto INT, idObjeto INT)
		SET @TablaObjetoFinal='TablaObjetoFinal_'+CAST(@idUsuario AS VARCHAR)+CAST(DATEPART(MINUTE,GETDATE()) AS VARCHAR)+CAST(DATEPART(SECOND,GETDATE()) AS VARCHAR) 

		INSERT INTO @tObjeto (idTipoObjeto, idObjeto) 
		SELECT	SO.idTipoObjeto, SO.idObjeto 
		FROM	[Solicitud].[solicitud].[SolicitudObjeto] SO
		INNER	JOIN solicitud.solicitud.solicitud SOL ON SOL.idSolicitud = SO.idSolicitud
		INNER	JOIN #tablaGeneralDatos DAT ON DAT.idSolicitud=SO.idSolicitud AND DAT.idObjeto=SO.idObjeto
		WHERE	SOL.idClase=@idClase 
		AND		SOL.idEstatusSolicitud='Activa'
		/*Modificar el query que llena la tabla @tObjeto al integrar en sp para que tome los filtros de la consulta general*/

		/*campos tabla common.reporte.Objeto*/
		DECLARE @tablaObjetoConfiguracion TABLE(idd INT identity,campo VARCHAR(100),tipoPropiedad VARCHAR(50),tipoObjeto varchar(50))
		/*campos tabla common.reporte.Objeto*/

		SET @camposPivot	 = ISNULL(STUFF((SELECT ',' + QUOTENAME(CAST(campo AS VARCHAR(MAX))) FROM Common.reporte.objeto WHERE idClase=@idClase ORDER BY orden ASC  FOR XML PATH('')),1,1,''),'sinCoinicidencia')
		SET @camposPivotKey	 ='idTipoObjeto AS key_idTipoObjeto,idObjeto AS key_idObjeto'
		SET @sq				 =''
  
		CREATE TABLE #tablaObjetoDatos([idTipoObjeto] [int] NULL, [idObjeto] [int] NULL, [agrupador] [varchar](250) NULL, [valor] [varchar](500) NULL)

		INSERT INTO @tablaObjetoConfiguracion(campo,tipoPropiedad,tipoObjeto) SELECT campo,tipoPropiedad,tipoObjeto FROM Common.reporte.Objeto WHERE idClase=@idClase ORDER BY orden ASC
	
		INSERT INTO #tablaObjetoDatos(idTipoObjeto,idObjeto,agrupador,valor) 
		SELECT	s.idTipoObjeto,s.idObjeto,tc.campo,[objeto].[objeto].[getPropiedadObjeto](case when tc.tipoObjeto='idTipoObjeto' then s.idTipoObjeto else s.idObjeto end, tc.campo, tc.tipoPropiedad,@idClase) FROM	@tObjeto s, @tablaObjetoConfiguracion tc
	
		SET @sq=''
		SET @sq+='SELECT r.* INTO '+ @TablaObjetoFinal +' FROM (select '+@camposPivotKey+',agrupador,valor from #tablaObjetoDatos) AS tx PIVOT (max(valor) for agrupador in ('+@camposPivot+')) as r '
		EXEC(@sq)
		
		/************************************************** OBJETO DINAMICO **************************************************/

		--INNER	JOIN @tbl_contratos CON ON CON.numeroContrato = SOL.numeroContrato AND CON.idCliente = SOL.idCliente AND CON.rfc = SOL.rfcEmpresa
		/************************************************** SOLICITUD DINAMICO **************************************************/
		IF OBJECT_ID('tempdb..#tablaSolicitudDatos')IS NOT NULL DROP TABLE #tablaSolicitudDatos
		/*Modificar el query que llena la tabla @tSolicitudes al integrar en sp para que tome los filtros de la consulta general*/
		DECLARE @tSolicitudes TABLE(idSolicitud INT)
		SET		@TablaSolicitudFinal = 'TablaSolicitudFinal_'+CAST(@idUsuario AS VARCHAR)+CAST(DATEPART(MINUTE,GETDATE()) AS VARCHAR)+CAST(DATEPART(SECOND,GETDATE()) AS VARCHAR) 

		INSERT INTO @tSolicitudes(idSolicitud) 
		SELECT	SOL.idSolicitud 
		FROM	solicitud.solicitud.solicitud SOL
		INNER	JOIN #tablaGeneralDatos DAT ON DAT.idSolicitud=SOl.idSolicitud
		WHERE	SOL.idClase				=@idClase 
		AND		SOL.idEstatusSolicitud	='Activa'

		/*Modificar el query que llena la tabla @tSolicitudes al integrar en sp para que tome los filtros de la consulta general*/

		/*campos tabla common.reporte.solicitud*/
		DECLARE @tablaSolicitudConfiguracion TABLE(idd INT identity,campo VARCHAR(100),tipoPropiedad VARCHAR(50))
		/*campos tabla common.reporte.solicitud*/

		SET @camposPivot	=ISNULL(STUFF((SELECT ',' + QUOTENAME(CAST(campo AS VARCHAR(MAX))) FROM Common.reporte.solicitud WHERE idClase=@idClase ORDER BY orden ASC  FOR XML PATH('')),1,1,''),'sinCoinicidencia')
		SET @camposPivotKey	='idSolicitud AS key_idSolicitud'
		SET @sq				=''		

		CREATE TABLE #tablaSolicitudDatos(idSolicitud int,agrupador VARCHAR(250),valor VARCHAR(500))

		INSERT INTO @tablaSolicitudConfiguracion(campo,tipoPropiedad) SELECT campo,tipoPropiedad FROM Common.reporte.solicitud WHERE idClase=@idClase ORDER BY orden ASC

		INSERT INTO #tablaSolicitudDatos(idSolicitud,agrupador,valor) 
		SELECT idSolicitud,tc.campo,[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, tc.campo, tc.tipoPropiedad,@idClase) from @tSolicitudes s,@tablaSolicitudConfiguracion tc

		SET @sq=''
		SET @sq+='SELECT r.* INTO '+ @TablaSolicitudFinal +' FROM (select '+ @camposPivotKey+',agrupador,valor from #tablaSolicitudDatos) AS tx PIVOT (max(valor) for agrupador in ('+@camposPivot+')) as r'
		EXEC(@sq)
	/************************************************** SOLICITUD DINAMICO **************************************************/



		SET @sqx+='SELECT TGD.*, O.*, SS.* FROM #tablaGeneralDatos tGD '
		SET @sqx+=' LEFT JOIN '+ @TablaObjetoFinal +' o  ON o.key_idObjeto=tGD.idObjeto AND o.key_idTipoObjeto=tGD.idTipoObjeto '
		SET @sqx+=' LEFT JOIN '+ @TablaSolicitudFinal +' ss ON ss.key_idSolicitud=tGD.idSolicitud '

		IF(@rolProveedor = 1)
			BEGIN
				SET @sqx+= ' INNER JOIN #solicitudesProveedor SOPR ON SOPR.idSolicitud = tGD.idSolicitud'
			END

		SET @sqx+=' ORDER BY tGD.idSolicitud DESC '

		EXEC(@sqx)

		Print 'Eliminando tablas fisicas al terminar SP'
		IF OBJECT_ID(@TablaObjetoFinal, 'U') IS NOT NULL  
			BEGIN
				SET @sqx='DROP TABLE '+@TablaObjetoFinal 
				EXEC (@sqx)
			END
		IF OBJECT_ID(@TablaSolicitudFinal, 'U') IS NOT NULL
			BEGIN
				SET @sqx='DROP TABLE '+@TablaSolicitudFinal 
				EXEC (@sqx)
			END

		IF OBJECT_ID('tempdb..#tablaGeneralDatos')IS NOT NULL DROP TABLE #tablaGeneralDatos
		IF OBJECT_ID('tempdb..#tablaObjetoDatos')IS NOT NULL DROP TABLE #tablaObjetoDatos
		IF OBJECT_ID('tempdb..#tablaSolicitudDatos')IS NOT NULL DROP TABLE #tablaSolicitudDatos
		IF OBJECT_ID('tempdb..#solicitudesProveedor')IS NOT NULL DROP TABLE #solicitudesProveedor

END
go

