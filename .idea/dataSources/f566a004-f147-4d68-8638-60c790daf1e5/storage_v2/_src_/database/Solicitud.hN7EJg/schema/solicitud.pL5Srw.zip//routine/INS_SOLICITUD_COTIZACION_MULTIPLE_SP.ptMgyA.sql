-- =============================================
-- Author:		Martin Pacheco
-- Create date: 24/06/2019
-- Description:	.
-- =============================================
-- ============== Versionamiento ================

/*
	Fecha		Autor	Descripción 
	26-09-2019  CON     Se quita la actualización de solicitudpartidas, ya que el merge realiza ese control por cantidades
	25/09/2020	JLuis Lozada	se agrego al insert de la tabla [SolicitudCotizacionPartidaDescuento] los campos porcentajeDescuentoCosto,descuentoCosto

	*- Testing...
	
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[INS_SOLICITUD_COTIZACION_MULTIPLE_SP] 
	1030,'Imagen', 'Automovil', 'ASE0508051B6', 185, '43',
	'<cotizaciones><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>746710</idPartida><idObjeto>10558</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>836</costo><venta>1000</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>783896</idPartida><idObjeto>10558</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>100</costo><venta>125</venta>
		</cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783900</idPartida><idObjeto>10558</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>3125</costo><venta>3126</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783901</idPartida><idObjeto>10558</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>10250</costo><venta>10251</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>746710</idPartida><idObjeto>10559</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>836</costo><venta>1000</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>783896</idPartida><idObjeto>10559</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>100</costo><venta>125</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783900</idPartida><idObjeto>10559</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>3125</costo><venta>3126</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783901</idPartida><idObjeto>10559</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>10250</costo><venta>10251</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>746710</idPartida><idObjeto>10560</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>836</costo><venta>1000</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>783896</idPartida><idObjeto>10560</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>100</costo><venta>125</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783900</idPartida><idObjeto>10560</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>3125</costo><venta>3126</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783901</idPartida><idObjeto>10560</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>10250</costo><venta>10251</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>746710</idPartida><idObjeto>10561</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>836</costo><venta>1000</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>783896</idPartida><idObjeto>10561</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>100</costo><venta>125</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783900</idPartida><idObjeto>10561</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>3125</costo><venta>3126</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783901</idPartida><idObjeto>10561</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>10250</costo><venta>10251</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>746710</idPartida><idObjeto>10562</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>836</costo><venta>1000</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>783896</idPartida><idObjeto>10562</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>100</costo><venta>125</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783900</idPartida><idObjeto>10562</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>3125</costo><venta>3126</venta></cotizacion><cotizacion><rfcProveedor>RIM0204046N9</rfcProveedor><idProveedorEntidad>523</idProveedorEntidad><idPartida>783901</idPartida><idObjeto>10562</idObjeto><idTipoObjeto>117</idTipoObjeto><cantidad>3</cantidad><costo>10250</costo><venta>10251</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746046</idPartida><idObjeto>10581</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>4700</costo><venta>5875</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746047</idPartida><idObjeto>10581</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1935.15</costo><venta>2418</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>778333</idPartida><idObjeto>10581</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1364</costo><venta>1550</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746046</idPartida><idObjeto>10582</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>4700</costo><venta>5875</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746047</idPartida><idObjeto>10582</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1935.15</costo><venta>2418</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>778333</idPartida><idObjeto>10582</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1364</costo><venta>1550</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746046</idPartida><idObjeto>10583</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>4700</costo><venta>5875</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746047</idPartida><idObjeto>10583</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1935.15</costo><venta>2418</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>778333</idPartida><idObjeto>10583</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1364</costo><venta>1550</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746046</idPartida><idObjeto>10584</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>4700</costo><venta>5875</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746047</idPartida><idObjeto>10584</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1935.15</costo><venta>2418</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>778333</idPartida><idObjeto>10584</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1364</costo><venta>1550</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746046</idPartida><idObjeto>10585</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>4700</costo><venta>5875</venta></cotizacion><cotizacion><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746047</idPartida><idObjeto>10585</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1935.15</costo><venta>2418</venta></cotizacion><cotizacion><rfcProveedor>AUT991215UZ2</rfcProveedor><idProveedorEntidad>522</idProveedorEntidad><idPartida>778333</idPartida><idObjeto>10585</idObjeto><idTipoObjeto>631</idTipoObjeto><cantidad>3</cantidad><costo>1364</costo><venta>1550</venta></cotizacion></cotizaciones>',
		8262,null
*/
-- =============================================

CREATE PROCEDURE [solicitud].[INS_SOLICITUD_COTIZACION_MULTIPLE_SP]
	@idSolicitud		INT,
    @idTipoSolicitud	VARCHAR(10) = '',
    @idClase			vARCHAR(10) = '',
    @rfcEmpresa			VARCHAR(13) = '',
    @idCliente			INT,
    @numeroContrato		VARCHAR(50) = '',
    @cotizaciones		XML,
	@idUsuario			INT,
	@err				VARCHAR(8000) OUTPUT
AS
BEGIN
	
	SET NOCOUNT OFF;
	BEGIN TRY  
		BEGIN TRANSACTION; 
		DECLARE @manejoDescuentoVenta INT, @porcentajeDescuentoVenta FLOAT
		SELECT @manejoDescuentoVenta=manejoDescuentoVenta, @porcentajeDescuentoVenta=porcentajeDescuentoVenta 
		FROM [Cliente].Cliente.Contrato
		WHERE rfcEmpresa=@rfcEmpresa AND idCliente=@idCliente AND numeroContrato=@numeroContrato

		DECLARE @tbl_proveedores AS TABLE(_row INT IDENTITY(1,1),idProveedorEntidad INT, rfcProveedor VARCHAR(13),idtipoObjeto INT, idObjeto INT)
		DECLARE @tbl_solicitudes AS TABLE(_row INT IDENTITY(1,1),idObjeto INT,idTipoObjeto INT, idProveedorEntidad INT, rfcProveedor VARCHAR(13), idPartida INT,cantidad INT, costo DECIMAL(18,2), venta DECIMAL(18,2))

		INSERT INTO @tbl_solicitudes(idObjeto, idTipoObjeto, idProveedorEntidad, rfcProveedor, idPartida, cantidad, costo, venta) 
		SELECT I.col.value('idObjeto[1]','int'),I.col.value('idTipoObjeto[1]','int'),I.col.value('idProveedorEntidad[1]','int'),I.col.value('rfcProveedor[1]','varchar(13)'),
		I.col.value('idPartida[1]','int'),I.col.value('cantidad[1]','int'),I.col.value('costo[1]','DECIMAL(18,2)'),I.col.value('venta[1]','DECIMAL(18,2)')  
		FROM @cotizaciones.nodes('cotizaciones/cotizacion') AS I(col)
		PRINT '1'

		INSERT INTO @tbl_proveedores
		SELECT DISTINCT idProveedorEntidad,rfcProveedor,idTipoObjeto, idObjeto FROM @tbl_solicitudes

		DECLARE @idObjeto INT, 
				@idTipoObjeto INT, 
				@idProveedorEntidad INT, 
				@rfcProveedor VARCHAR(13), 
				@numeroCotizacion	VARCHAR(30) = '', 
				@VI_idCotizacion	INT,
				@v_id	INT
		/*************************************************************************** SI LA FECHA ACTUAL SE ENCUENTRA EN EL RANGO DE TERMINO DEL CONTRATO ***************************************************************************/
		IF EXISTS(SELECT 1 FROM Cliente.cliente.Contrato WHERE numeroContrato = @numeroContrato AND idCliente = @idCliente AND rfcEmpresa = @rfcEmpresa AND activo = 1)
			BEGIN
				WHILE EXISTS(SELECT 1 FROM @tbl_proveedores)
					BEGIN
						SELECT	TOP 1  @v_id=_row,@idProveedorEntidad=idProveedorEntidad,@rfcProveedor=rfcProveedor,@idTipoObjeto=idTipoObjeto,@idObjeto=idObjeto 
						FROM	@tbl_proveedores
						SET		@numeroCotizacion = (SELECT [solicitud].[SEL_NUMEROCOTIZACION_MULTIPLE_FN](@idSolicitud,@rfcEmpresa,@idTipoSolicitud,@idClase,@idCliente,@numeroContrato,@idObjeto,@idTipoObjeto))

						INSERT INTO [solicitud].[SolicitudCotizacion] ( [idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[idCliente],[numeroContrato],[idProveedorEntidad],
									[rfcProveedor],[numeroCotizacion],[fechaAlta],[idUsuario],[idEstatusCotizacion]) 
						VALUES (	@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idProveedorEntidad,
									@rfcProveedor,@numeroCotizacion,GETDATE(),@idUsuario,'ENESPERA')

						SET @VI_idCotizacion = SCOPE_IDENTITY()
					
						INSERT INTO solicitud.SolicitudCotizacionPartida ([idCotizacion], [idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente], 
									[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[cantidad],[costo],[venta],[idEstatusCotizacionPartida],
									[fechaEstatus], [idUsuario])
						SELECT	@VI_idCotizacion,@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@numeroContrato,@idCliente,VT.rfcProveedor, VT.idProveedorEntidad,
								VT.idObjeto,VT.idTipoObjeto,VT.idPartida,VT.cantidad,VT.costo,VT.venta,'ENESPERA', GETDATE(), @idUsuario
						FROM	@tbl_solicitudes VT
						WHERE	idProveedorEntidad =@idProveedorEntidad AND rfcProveedor =@rfcProveedor AND idObjeto=@idObjeto AND idTipoObjeto=@idTipoObjeto

						IF(@manejoDescuentoVenta = 1)
							BEGIN
								INSERT INTO [solicitud].[SolicitudCotizacionPartidaDescuento] ([idCotizacion],[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],
								[numeroContrato],[idCliente],[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[porcentajeDescuentoVenta], 
								[descuentoVenta],[porcentajeDescuentoCosto],[descuentoCosto],[fecha],[idUsuario])
								SELECT	@VI_idCotizacion, @idSolicitud, @idTipoSolicitud, @idClase, @rfcEmpresa, @numeroContrato, @idCliente, VT.rfcProveedor,
										VT.idProveedorEntidad,VT.idObjeto,VT.idTipoObjeto,VT.idPartida,@porcentajeDescuentoVenta, ((VT.venta * @porcentajeDescuentoVenta) / 100)
										,0,0,GETDATE(),@idUsuario
								FROM	@tbl_solicitudes VT
								WHERE	idProveedorEntidad =@idProveedorEntidad AND rfcProveedor =@rfcProveedor AND idObjeto=@idObjeto AND idTipoObjeto=@idTipoObjeto
							END
					
						INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
						(fechaAlta,idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,idEstatusCotizacion,idUsuario)
						VALUES (GETDATE(),@VI_idCotizacion,@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idProveedorEntidad,@rfcProveedor,'ENESPERA',@idUsuario)

						DELETE	FROM @tbl_proveedores 
						WHERE	idObjeto			=@idObjeto 
						AND		idTipoObjeto		=@idTipoObjeto 
						AND		idProveedorEntidad	=@idProveedorEntidad 
						AND		rfcProveedor		=@rfcProveedor
					END
					COMMIT TRANSACTION; 
			END
		ELSE
			BEGIN
				SET @err = 'El contrato ya ha expirado.'
			END
		COMMIT TRANSACTION;  
	END TRY
	BEGIN CATCH
		PRINT ERROR_NUMBER() 
		PRINT ERROR_MESSAGE()
	END CATCH

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
	
END
go

