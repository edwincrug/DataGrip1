-- =============================================
-- Author:		<JLuis Lozada Guerrero>
-- Create date: <22/05/2020>
-- Description:	<Genera la orden de compra del tipo de solicitud compra y clase compra>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	
	*- Testing...
	DECLARE @salida varchar(max) ='' ;
    EXEC [compraBPRO].[UPD_SOLICITUD_GENERAORDENCOMPRA_SP] 
		626,
		'Compra',
		'Compra',
		'ASE0508051B6',
		221,
		'49',
		6119,
		@salida out
    SELECT @salida AS salida;

*/
-- =============================================
CREATE PROCEDURE [compraBPRO].[UPD_SOLICITUD_GENERAORDENCOMPRA_SP]
	@idSolicitud		INT,
	@idTipoSolicitud	VARCHAR(10),
	@idClase			VARCHAR(10),
	@rfcEmpresa			VARCHAR(13),
	@idCliente			INT,
	@numeroContrato		VARCHAR(50),
	@idUsuario			INT,
	@err				VARCHAR(500) OUTPUT	
AS
BEGIN
	BEGIN TRY
		DECLARE @result					TABLE(respuesta INT)
		DECLARE @idPersonaBPRO			INT,
				@rfcProveedor			VARCHAR(13),
				@idEmpresa				INT,
				@idSucursal				INT,
				@idDepartamento			INT,
				@claveArea				varchar(10),
				@idUsuarioBRO			INT,
				@idBPRO					INT,
				@ppg_tasaiva			DECIMAL(18,5)=16,
				@numeroOrden			VARCHAR(50),
				@ppg_idprepedidogastos	INT,
				@ppd_descuento			DECIMAL(18,5)=0,
				@ppg_fechaProceso		DATETIME	=NULL,
				@ppg_ordenCompra		VARCHAR(60)	=NULL
		

		SELECT TOP 1 @numeroOrden	=numeroOrden 
		FROM	solicitud.solicitud.solicitudoBJETO so 
		WHERE	so.idSolicitud		=@idSolicitud
		AND		so.idTipoSolicitud	=@idTipoSolicitud 
		AND		so.idClase			=@idClase
		AND		so.rfcEmpresa		=@rfcEmpresa
		AND		so.idCliente		=@idCliente
		AND		so.numeroContrato	=@numeroContrato

		SELECT	TOP 1 @rfcProveedor	=rfcProveedor 
		FROM	solicitud.solicitud.SolicitudCotizacion sc
		WHERE	sc.idSolicitud		=@idSolicitud 
		AND		sc.idTipoSolicitud	=@idTipoSolicitud
		AND		sc.idClase			=@idClase
		AND		sc.rfcEmpresa		=@rfcEmpresa
		AND		sc.idCliente		=@idCliente
		AND		sc.numeroContrato	=@numeroContrato

		SELECT  @idEmpresa			=idEmpresa,
				@idSucursal			=idSucursal,
				@idDepartamento		=idArea,
				@idUsuarioBRO		=idUsuarioBPRO
		FROM	compraBPRO.Solicitud sco
		WHERE	sco.idSolicitud		=@idSolicitud 
		AND		sco.idTipoSolicitud	=@idTipoSolicitud
		AND		sco.idClase			=@idClase
		AND		sco.rfcEmpresa		=@rfcEmpresa
		AND		sco.idCliente		=@idCliente
		AND		sco.numeroContrato	=@numeroContrato

		SELECT	TOP 1 @idBPRO=idBPRO 
		FROM	Proveedor.proveedor.ProveedorEmpresa
		WHERE	rfcProveedor	=@rfcProveedor
		AND		rfcEmpresa		=@rfcEmpresa
		AND		idPersonaBPRO	= ( SELECT	TOP 1
											idPersonaBPRO
									FROM	Cliente.cliente.Contrato 
									WHERE	numeroContrato	=@numeroContrato 
									AND		idCliente		=@idCliente 
									AND		rfcEmpresa		=@rfcEmpresa)

		print @idBPRO

		select @claveArea = par_idenpara 
		from [192.168.20.29].Centralizacionv2.dbo.DIG_ESCALAMIENTO_AREA_AFECT where emp_idempresa = @idEmpresa and suc_idsucursal=@idSucursal and id=@idDepartamento

		

		INSERT INTO [192.168.20.29].cuentasxpagar.dbo.pre_pedidogastos
					(	ppg_idempresa,ppg_idsucursal,ppg_idproveedor,ppg_fechaorden,
						ppg_tasaiva,ppg_observaciones,ppg_fechainsercion,ppg_usuariogenera,
						ppg_fechaproceso,ppg_ordencompra,ppg_estatus,ppg_areaafectacion
					)
			VALUES	(	@idEmpresa, @idSucursal, @idBPRO, GETDATE(), @ppg_tasaiva, 
						@numeroOrden, GETDATE(), @idUsuarioBRO, NULL, NULL, 0,@claveArea
					)
	
		SET @ppg_idprepedidogastos =(	SELECT	TOP 1 
												ppg_idprepedidogastos 
										FROM	[192.168.20.29].cuentasxpagar.dbo.pre_pedidogastos 
										WHERE	ppg_observaciones=@numeroOrden 
										ORDER	BY ppg_fechainsercion DESC
									)
		
		INSERT INTO [192.168.20.29].cuentasxpagar.dbo.pre_pedidogastosdet (ppd_cantidad, ppd_producto, ppd_preciounitario, ppd_descuento, ppg_idprepedidogastos)
		SELECT	scp.cantidad,
				[partida].[partida].[getPropiedadPartida](scp.idPartida, 'Descripción', 'general'),
				costo,
				@ppd_descuento,
				@ppg_idprepedidogastos 
		FROM	solicitud.SolicitudCotizacion SC 
		INNER	JOIN solicitud.SolicitudCotizacionPartida scp
		ON		SC.idSolicitud		=scp.idSolicitud
		AND		SC.idTipoSolicitud	=scp.idTipoSolicitud
		AND		SC.idClase			=scp.idClase
		AND		SC.rfcEmpresa		=scp.rfcEmpresa
		AND		SC.idCliente		=scp.idCliente
		AND		SC.numeroContrato	=scp.numeroContrato
		AND		SC.idCotizacion		=scp.idCotizacion
		WHERE	sc.idSolicitud		=@idSolicitud 
		AND		sc.idTipoSolicitud	=@idTipoSolicitud
		AND		sc.idClase			=@idClase
		AND		sc.rfcEmpresa		=@rfcEmpresa
		AND		sc.idCliente		=@idCliente
		AND		sc.numeroContrato	=@numeroContrato
	
		INSERT INTO @result
		EXEC [192.168.20.29].cuentasxpagar.dbo.sp_ordenesdegastocentralizadas @pedido = @ppg_idprepedidogastos

		--si la respuesta del sp es cero se avanza orden y se recuperan y actualizan valores fechaproceso y ordencompra
		
		DECLARE @salida varchar(max) ='' ;

		SELECT	@ppg_fechaProceso		=ppg_fechaProceso,
				@ppg_ordenCompra		=ppg_ordenCompra 
		FROM	[192.168.20.29].cuentasxpagar.dbo.pre_pedidogastos 
		WHERE	ppg_idprepedidogastos	=@ppg_idprepedidogastos

		UPDATE	compraBPRO.Solicitud 
		SET		ppg_fechaProceso=@ppg_fechaProceso,
				ppg_ordenCompra	=@ppg_ordenCompra
		WHERE	idSolicitud		=@idSolicitud 
		AND		idTipoSolicitud	=@idTipoSolicitud
		AND		idClase			=@idClase
		AND		rfcEmpresa		=@rfcEmpresa
		AND		idCliente		=@idCliente
		AND		numeroContrato	=@numeroContrato
			
	END TRY
	BEGIN CATCH
		SET @err='Error al procesar: ' +ERROR_MESSAGE()
	END CATCH
END
go

