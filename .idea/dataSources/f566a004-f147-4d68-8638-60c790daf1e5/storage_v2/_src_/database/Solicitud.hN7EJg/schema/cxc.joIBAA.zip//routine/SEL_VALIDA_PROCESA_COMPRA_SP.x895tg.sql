
-- =============================================
-- Author:		Adolfo Martinez
-- Create date: 21/05/2020
-- Description:	Valida procesar compra
/***************************************************
1) Validación de reglas de negocio para provisión:
	1.0 Validar que la solicitud tiene no tenga partidas con costo o venta en 0										OK
	1.1 Validar que tenga Facturacion BPRO																			OK
	1.2 Validar que tenga Personas BPRO																				OK			
	1.3 Validar que el objeto tenga asignado rfcCliente entidad.													OK
	1.4 validar que en la tabla de ContratoBPRO tengamos el idBPRO del contrato										OK
	1.5 Validar que el rfc del proveedor exista en ProveedorEmpresa, con base a idPersonasBPRO del contrato.		OK
	1.6 Validar que el contrato maneje utilidad																		OK
	1.7 Validar que el monto minimo del contrato no supere al monto de la orden										OK		
	1.8 Validar que el no exista el token de utilidad TokenSolicitud												OK
***************************************************/
-- ============== Versionamiento ================  
-- EXEC [cxc].[SEL_VALIDA_PROCESA_COMPRA_SP] 397,'Imagen','Automovil','ASE0508051B6',185,'43',1,''
-- EXEC [cxc].[SEL_VALIDA_PROCESA_COMPRA_SP] 564,'Imagen','Automovil','ASE0508051B6',185,'43',1,''
-- EXEC [cxc].[SEL_VALIDA_PROCESA_COMPRA_SP] 565,'Servicio','Automovil','ASE0508051B6',216,'127',1,''
-- =============================================
CREATE PROCEDURE [cxc].[SEL_VALIDA_PROCESA_COMPRA_SP]
@idSolicitud		INT,
@idTipoSolicitud	VARCHAR(10),
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@idUsuario			INT,
@err				VARCHAR(8000) = '' OUTPUT	
AS
BEGIN

	BEGIN TRY  

		IF NOT EXISTS(SELECT 1 FROM [solicitud].[SolicitudCotizacionPartida] SCP
		WHERE SCP.idSolicitud=@idSolicitud
		AND	SCP.rfcEmpresa= @rfcEmpresa
		AND	SCP.idCliente=@idCliente
		AND	SCP.numeroContrato=@numeroContrato
		AND	SCP.idClase=@idClase
		AND	SCP.idTipoSolicitud=@idTipoSolicitud
		AND SCP.costo = 0
		AND SCP.venta = 0
		AND SCP.idEstatusCotizacionPartida NOT IN('RECHAZADA','CANCELADA'))
			BEGIN
				IF EXISTS(SELECT 1 FROM [common].[configuracion].[FacturacionBPRO] FBPRO 
						JOIN [Cliente].[Cliente].[Contrato] CO ON  CO.idFacturacionBPRO = FBPRO.idFacturacionBPRO 
						WHERE	CO.idEstatus		= 'ACT'
						AND		FBPRO.activo		= 1 
						AND		CO.rfcEmpresa		= @rfcEmpresa
						AND		CO.idCliente		= @idCliente
						AND		CO.numeroContrato	= @numeroContrato
						AND		CO.idClase			= @idClase)
					BEGIN
						IF EXISTS(SELECT 1 FROM [common].[configuracion].[PersonasBPRO] PBPRO 
								JOIN [Cliente].[Cliente].[Contrato] CO ON  CO.idPersonaBPRO = PBPRO.idPersonaBPRO
								WHERE	CO.idEstatus		= 'ACT'
								AND		PBPRO.activo		= 1 
								AND		CO.rfcEmpresa		= @rfcEmpresa
								AND		CO.idCliente		= @idCliente
								AND		CO.numeroContrato	= @numeroContrato
								AND		CO.idClase			= @idClase)
							BEGIN
									IF NOT EXISTS(SELECT 1 FROM [Solicitud].[solicitud].[SolicitudObjeto] SO
										LEFT	JOIN [Cliente].[contrato].[Objeto] CO ON CO.idTipoObjeto=SO.idTipoObjeto AND CO.idObjeto=SO.idObjeto AND CO.rfcEmpresa=SO.rfcEmpresa AND CO.idCliente=SO.idCliente AND CO.numeroContrato=SO.numeroContrato AND CO.idClase=SO.idClase
										WHERE	SO.idSolicitud=@idSolicitud
										AND		SO.rfcEmpresa= @rfcEmpresa
										AND		SO.idCliente=@idCliente
										AND		SO.numeroContrato=@numeroContrato
										AND		SO.idClase=@idClase
										AND		SO.idTipoSolicitud=@idTipoSolicitud
										AND		CO.rfcClienteEntidad IS NULL)
									BEGIN
											IF EXISTS(SELECT 1 FROM	[Solicitud].[solicitud].[SolicitudObjeto] SO
													JOIN [Cliente].[contrato].[Objeto] CO ON CO.idTipoObjeto=SO.idTipoObjeto AND CO.idObjeto=SO.idObjeto AND CO.rfcEmpresa=SO.rfcEmpresa AND CO.idCliente=SO.idCliente AND CO.numeroContrato=SO.numeroContrato AND CO.idClase=SO.idClase
													JOIN [Cliente].[cliente].[ContratoBPRO] CBPRO ON CBPRO.rfcClienteEntidad = CO.rfcClienteEntidad AND CBPRO.rfcEmpresa = CO.rfcEmpresa AND CBPRO.idCliente = CO.idCliente AND CBPRO.numeroContrato = CO.numeroContrato
												WHERE	SO.idSolicitud=@idSolicitud
												AND		SO.rfcEmpresa= @rfcEmpresa
												AND		SO.idCliente=@idCliente
												AND		SO.numeroContrato=@numeroContrato
												AND		SO.idClase=@idClase
												AND		SO.idTipoSolicitud=@idTipoSolicitud
												AND     CBPRO.idBPRO != 0)
											BEGIN
													IF NOT EXISTS(SELECT 1 FROM [Solicitud].[solicitud].[SolicitudCotizacion] SC
														JOIN [Cliente].[Cliente].[Contrato] CO ON CO.rfcEmpresa=SC.rfcEmpresa AND CO.idCliente=SC.idCliente AND CO.numeroContrato=SC.numeroContrato AND CO.idClase=SC.idClase
														LEFT JOIN [Proveedor].[Proveedor].[proveedorEmpresa] PE ON PE.rfcProveedor = SC.rfcProveedor AND PE.rfcEmpresa = SC.rfcEmpresa AND PE.idPersonaBPRO=CO.idPersonaBPRO
														WHERE	SC.idSolicitud=@idSolicitud
														AND		SC.rfcEmpresa= @rfcEmpresa
														AND		SC.idCliente=@idCliente
														AND		SC.numeroContrato=@numeroContrato
														AND		SC.idClase=@idClase
														AND		SC.idTipoSolicitud=@idTipoSolicitud
														AND		SC.idEstatusCotizacion NOT IN('CANCELADA','RECHAZADA')
														AND		PE.rfcProveedor IS NULL)
													BEGIN
														IF EXISTS(SELECT 1 FROM [Cliente].[cliente].[Contrato] C 
															WHERE C.rfcEmpresa = @rfcEmpresa 
															AND C.numeroContrato = @numeroContrato 
															AND C.idCliente = @idCliente 
															AND C.idClase = @idClase
															AND C.manejoDeUtilidad = 1)
															BEGIN	
																DECLARE @contratoUtilidad DECIMAL(18,2)
																DECLARE @utilidad DECIMAL(18,2)
																--SELECT 
																--	@contratoUtilidad = (CASE WHEN C.manejoDeUtilidad = 1 THEN C.porcentajeUtilidad ELSE -1 END),
																--	@utilidad = (CASE WHEN COALESCE(SUM(VW.totalCosto), 0) = 0 THEN 0 ELSE CAST( ((COALESCE(SUM(VW.totalVenta), 0) / COALESCE(SUM(VW.totalCosto), 0)) -1) * 100 AS DECIMAL(18,2)) END)
																--FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] VW
																--	JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = VW.rfcEmpresa AND C.numeroContrato = VW.numeroContrato AND C.idCliente = VW.idCliente AND C.idClase = VW.idClase
																--WHERE VW.idSolicitud = @idSolicitud 
																--GROUP BY C.porcentajeUtilidad,C.manejoDeUtilidad
																   ;WITH cte_utilidad as (
																		SELECT 
																			 (CASE WHEN C.manejoDeUtilidad = 1 THEN C.porcentajeUtilidad ELSE -1 END) contratoUtilidad,
																			 (CASE WHEN COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) = 0 THEN 0 ELSE CAST( ((COALESCE(SUM(VW.subTotalVenta), 0) - COALESCE(SUM(VW.subTotalCosto), 0)) / COALESCE(SUM(vw.subTotalVentaSinDescuento), 0)) * 100 AS DECIMAL(18,2)) END) utilidad
																			-- (CASE WHEN COALESCE(SUM(VW.subTotalCosto), 0) = 0 THEN 0 ELSE CAST( ((COALESCE(SUM(VW.subTotalVenta), 0) / COALESCE(SUM(VW.subTotalCosto), 0)) -1) * 100 AS DECIMAL(18,2)) END) utilidad
																		FROM [solicitud].[solicitud].[SEL_TOTALES_COTIZACION_VW] VW
																			LEFT JOIN [cliente].[contrato].[ProveedorUtilidad] PU ON PU.rfcEmpresa = VW.rfcEmpresa AND PU.idCliente = VW.idCliente AND PU.numeroContrato = VW.numeroContrato AND PU.rfcProveedor = VW.rfcProveedor AND PU.idProveedorEntidad = VW.idProveedorEntidad
																			JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = VW.rfcEmpresa AND C.numeroContrato = VW.numeroContrato AND C.idCliente = VW.idCliente AND C.idClase = VW.idClase
																		WHERE VW.idSolicitud = @idSolicitud AND PU.idProveedorEntidad IS NULL
																		GROUP BY C.porcentajeUtilidad,C.manejoDeUtilidad
																	)
																	SELECT @contratoUtilidad=contratoUtilidad, @utilidad=utilidad FROM(
																			SELECT contratoUtilidad, utilidad FROM cte_utilidad
																		UNION
																			SELECT 0,0
																			WHERE NOT EXISTS (select 1 from cte_utilidad)
																	)utilidad
																										
																IF(@utilidad < @contratoUtilidad)
																	BEGIN
																		IF EXISTS(SELECT 1 FROM [Solicitud].[token].[Token] TT
																		INNER JOIN [Solicitud].[token].[TokenSolicitud] TTS ON TT.idToken = TTS.idToken AND TT.idUsuarioUsa IS NOT NULL
																		WHERE TTS.idSolicitud = @idSolicitud
																		AND TT.idTipoToken = 3)
																			BEGIN
																				SELECT 'La solicitud se validó correctamente.' msg
																			END
																		ELSE
																			BEGIN
																				  SET @err = 'utilidad'
																				--SET @err = 'No se puede procesar la compra. La orden no cubre el margen de utilidad mínimo establecido por el contrato, requiere un token de autorización.'
																			END
																	END
																ELSE
																	BEGIN
																		SELECT 'La solicitud se validó correctamente.' msg
																	END
															END
														ELSE
															BEGIN
																SELECT 'La solicitud se validó correctamente.' msg
															END
													END
												ELSE
													BEGIN
														SET @err = 'No se puede procesar la compra. El proveedor no se encuentra dado de alta en BPRO.'
													END
											END
										ELSE
											BEGIN
												SET @err = 'No se puede procesar la compra. La CXC del contrato no está configurada.'
											END
									END
								ELSE
									BEGIN
										SET @err = 'No se puede procesar la compra. El objeto no tiene configuración de facturación.'
									END
							END
						ELSE
							BEGIN
								SET @err = 'No se puede procesar la compra. La CXP del contrato no está configurada.'
							END
					END
				ELSE
					BEGIN
						SET @err = 'No se puede procesar la compra. El contrato no tiene asignado el ambiente de facturación BPRO.'	
					END
			END
		ELSE
			BEGIN
				SET @err = 'No se puede procesar la compra. La solicitud tiene partidas con costo o venta en 0.'	
			END
		PRINT @err

	END TRY
	BEGIN CATCH
		--ROLLBACK TRANSACTION
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al intentar validar el procesar compra.'
	END CATCH
END
go

