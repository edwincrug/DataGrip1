
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 05-09-2019
-- Description: Agrega regla de paso
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	EXEC [fase].[INS_REGLAPASO_SP]  
	@aplicaReglaMonto= false
	,@aplicaReglaNivel= false
	,@aplicaReglaObjeto= false
	,@aplicaReglaPartida= false
	,@aplicaReglaRol= true
	,@aplicaReglaUsuario= false
	,@idClase= 'Automovil'
	,@idCliente= 219
	,@idNivel= ''
	,@idTipoMonto= ''
	,@idTipoSolicitud= 'Servicio'
	,@montoMaximo= 0
	,@montoMinimo= 0
	,@numeroContrato= '128'
	,@rfcEmpresa= 'ASE0508051B6'
	,@xmlObjetos= NULL
	,@xmlPartidas= NULL
	,@xmlRoles= '<roles><rol><idRol>41</idRol></rol></roles>'
	,@xmlUsuarios= null
	,@idUsuario = 2326
	,@descripcion = 'Regla prueba'
	,@idAplicacion = 11
	,@err = ''

*/
-- =============================================
CREATE  PROCEDURE [fase].[INS_REGLAPASO_SP] 
	@rfcEmpresa					VARCHAR(13)
	,@numeroContrato			VARCHAR(50)
	,@idCliente					INT
	,@idTipoSolicitud			VARCHAR(10)
	--,@idFase					VARCHAR(20)
	--,@idPaso					VARCHAR(50)
	,@idClase					VARCHAR(10)
	,@aplicaReglaRol			BIT
	,@aplicaReglaUsuario		BIT
	,@aplicaReglaPartida		BIT
	,@aplicaReglaMonto			BIT
	,@aplicaReglaObjeto			BIT
	,@aplicaReglaNivel			BIT
	,@xmlRoles					XML
	,@xmlUsuarios				XML
	,@xmlPartidas				XML
	,@idTipoMonto				VARCHAR(10)
	,@montoMinimo				DECIMAL(18,2)
	,@montoMaximo				DECIMAL(18,2)
	,@xmlObjetos				XML
	,@idNivel					INT
	,@idUsuario					INT
	,@descripcion				VARCHAR(500)
	,@idAplicacion				INT
	,@err						varchar(500)OUTPUT
AS


BEGIN

	DECLARE 
		@idReglaPaso	INT

/****************************************************INSERTA EN REGLA PASO **********************************/

	INSERT INTO [fase].[ReglaPaso](
	idClase
	,idTipoSolicitud
	,rfcEmpresa
	,idCliente
	,numeroContrato
	,activo
	,aplicaReglaRol
	,aplicaReglaMonto
	,aplicaReglaUsuario
	,aplicaReglaPartida
	,aplicaReglaObjeto
	,idNivel
	,descripcion)
	SELECT
		--@idPaso, 
		--@idFase,
		@idClase,
		@idTipoSolicitud,
		@rfcEmpresa,
		@idCliente,
		@numeroContrato,
		1,
		@aplicaReglaRol,
		@aplicaReglaMonto,
		@aplicaReglaUsuario,
		@aplicaReglaPartida,
		@aplicaReglaObjeto,
		CASE
			WHEN @aplicaReglaNivel = 1 THEN @idNivel
			ELSE NULL END,
		@descripcion

		SET @idReglaPaso = @@IDENTITY

		SELECT @idReglaPaso

/****************************************************INSERTA EN REGLA ROL **********************************/

	IF(@aplicaReglaRol = 1)
		BEGIN
			DECLARE @tbl_roles AS TABLE(
			idRol					INT
			)

			INSERT INTO @tbl_roles(idRol)
			SELECT
				ParamValues.col.value('idRol[1]','int')
				FROM @xmlRoles.nodes('roles/rol') AS ParamValues(col)

			INSERT INTO [fase].[ReglaPasoRol]
			SELECT
				@idReglaPaso,
				--@idPaso,
				--@idFase,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				@idAplicacion,
				idRol,
				1,
				@idUsuario
			FROM @tbl_roles
				
		END

/****************************************************INSERTA EN REGLA USUARIO **********************************/

	IF(@aplicaReglaUsuario = 1)
		BEGIN
			DECLARE @tbl_usuarios AS TABLE(
			idUsuario				INT
			)

			INSERT INTO @tbl_usuarios(idUsuario)
			SELECT
				ParamValues.col.value('idUsuario[1]','int')
				FROM @xmlUsuarios.nodes('usuarios/usuario') AS ParamValues(col)

			INSERT INTO [fase].[ReglaPasoUsuario]
			SELECT
				@idReglaPaso,
				--@idPaso,
				--@idFase,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				idUsuario,
				@idAplicacion,
				1,
				@idUsuario
			FROM @tbl_usuarios
				
		END

/****************************************************INSERTA EN REGLA PARTIDA **********************************/

	IF(@aplicaReglaPartida = 1)
		BEGIN
			DECLARE @tbl_partidas AS TABLE(
			idPartida				INT
			)

			INSERT INTO @tbl_partidas(idPartida)
			SELECT
				ParamValues.col.value('idPartida[1]','int')
				FROM @xmlPartidas.nodes('partidas/partida') AS ParamValues(col)

			INSERT INTO [fase].[ReglaPasoPartida]
			SELECT
				@idReglaPaso,
				--@idPaso,
				--@idFase,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				TBL.idPartida,
				PPP.idTipoObjeto,
				1,
				@idUsuario
			FROM @tbl_partidas TBL
			LEFT JOIN partida.partida.partida PPP ON PPP.idPartida = TBL.idPartida AND PPP.activo = 1
				
		END



/****************************************************INSERTA EN REGLA MONTO **********************************/

	IF(@aplicaReglaMonto = 1)
		BEGIN
			
			INSERT INTO [fase].[ReglaPasoMonto]
			SELECT
				@idReglaPaso,
				--@idPaso,
				--@idFase,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				@idTipoMonto,
				@montoMinimo,
				@montoMaximo,
				1,
				@idUsuario
				
		END


/****************************************************INSERTA EN REGLA OBJETOS **********************************/

	IF(@aplicaReglaObjeto = 1)
		BEGIN

			DECLARE @tbl_objetos AS TABLE(
			idObjeto				INT
			)

			INSERT INTO @tbl_objetos(idObjeto)
			SELECT
				ParamValues.col.value('idObjeto[1]','int')
				FROM @xmlObjetos.nodes('objetos/objeto') AS ParamValues(col)
			
			INSERT INTO [fase].[ReglaPasoObjeto]
			SELECT
				@idReglaPaso,
				--@idPaso,
				--@idFase,
				@idClase,
				@idTipoSolicitud,
				@rfcEmpresa,
				@idCliente,
				@numeroContrato,
				OOO.idTipoObjeto,
				TOJ.idObjeto,
				1,
				@idUsuario
			FROM @tbl_objetos TOJ
			LEFT JOIN objeto.objeto.objeto OOO ON OOO.idObjeto = TOJ.idObjeto AND OOO.activo = 1
				
		END
	
END

go

