
--	=============================================
--	Author:		<Jose Luis Lozada Guerrero>
--	Create date:<26/06/2019>
--	Description:<Obtiene las propiedades del comprobante de recepcion>
--	=============================================
/*	Test:
	declare @err VARCHAR(8000)=''
	exec [solicitud].[SEL_COMPROBANTE_RECEPCION_SP] 
	@idClase='Automovil',@rfcEmpresa='ASE0508051B6',@idCliente=185,@numeroContrato='43',@idObjeto=10559,@idUsuario=null,@err='' 
	@err OUTPUT
	PRINT @err
*/
	

CREATE PROCEDURE [solicitud].[SEL_COMPROBANTE_RECEPCION_SP]
@idClase		VARCHAR(10),
@rfcEmpresa		VARCHAR(13) = NULL,
@idCliente		INT = NULL,
@numeroContrato	VARCHAR(50) = NULL,
@idObjeto		INT,
@idUsuario		INT = NULL,
@err			VARCHAR(8000) OUTPUT	
AS
BEGIN
	DECLARE @v_idAgrupacion VARCHAR(10),@v_idPropiedadClase INT
	DECLARE @tabx AS TABLE(idAgrupacion VARCHAR(10))
	INSERT INTO @tabx SELECT idAgrupacion FROM solicitud.ComprobanteAgrupacion ORDER BY orden asc
	
	DECLARE @idPropiedadClase INT
	SELECT	@idPropiedadClase=tobcla.idPropiedadClase
	FROM	Objeto.objeto.objeto obj
	INNER JOIN Partida.tipoobjeto.tipoobjeto tob ON obj.idTipoObjeto = tob.idTipoObjeto
	INNER JOIN Partida.tipoobjeto.TipoObjetoPropiedadClase tobcla ON tobcla.idTipoObjeto = tob.idTipoObjeto AND tobcla.idClase = tob.idClase
	INNER JOIN Partida.tipoobjeto.PropiedadClase procla ON procla.idPropiedadClase = tobcla.idPropiedadClase AND procla.idClase = tobcla.idClase
	WHERE	obj.idObjeto		= @idObjeto  
	AND		procla.agrupador	= 'Clase'
	PRINT @idPropiedadClase
	DECLARE @propiedades AS TABLE(	id				INT,
									idPadre			INT,
									valor			NVARCHAR(500),
									arreglo			NVARCHAR(500),
									idClase			NVARCHAR(500),
									idTipoValor		NVARCHAR(20),
									idTipoDato		NVARCHAR(20),
									propiedad		NVARCHAR(50),
									idPropiedad		INT,
									obligatorio		BIT,
									posicion		INT,
									orden			INT,
									idAgrupacion	VARCHAR(10),
									rutaImagen		VARCHAR(150),
									valorExterno    VARCHAR(100))

	INSERT INTO @propiedades
	SELECT	idPropiedadClase 'id',
			ISNULL(idPadre,0) 'idPadre',
			descripcion 'valor',
			'' 'arreglo',
			idClase,
			idTipoValor,
			idTipoDato,
			'clase' 'propiedad',
			2 'idPropiedad',
			obligatorio,
			posicion,
			orden,
			idAgrupacion,
			ISNULL((SELECT	 PATH 
					-- SELECT *
					FROM	fileserver.[documento].[Documento] 
					WHERE	idDocumento = (	SELECT	valor 
											FROM	solicitud.ComprobantePropiedadesValores 
											WHERE	idPropiedadClase	=@idPropiedadClase 
											AND		idAgrupacion		=a.idAgrupacion 
											AND		idSubAgrupacion		=a.valor)),NULL)'rutaImagen',
			NULL
			
	-- select *
	FROM	solicitud.ComprobantePropiedades a
	WHERE	a.activo=1
	AND		a.idAgrupacion IN (SELECT idAgrupacion FROM @tabx)

	IF NOT EXISTS(SELECT 1 FROM [Cliente].[cliente].[Contrato] WHERE rfcEmpresa=@rfcEmpresa AND idCliente=@idCliente AND numeroContrato=@numeroContrato AND geolocalizacion=1)
		BEGIN
			--DELETE FROM @propiedades WHERE idAgrupacion='Tablero' AND  valor in('Evidencia Fotográfica','Kilometraje Odometro')
			DELETE FROM @propiedades WHERE idAgrupacion='Tablero' AND  valor in('Evidencia Fotográfica','Kilometraje GPS')
		END 

	SELECT * FROM @propiedades order by  orden
	select 0 as kmGps
END
go

