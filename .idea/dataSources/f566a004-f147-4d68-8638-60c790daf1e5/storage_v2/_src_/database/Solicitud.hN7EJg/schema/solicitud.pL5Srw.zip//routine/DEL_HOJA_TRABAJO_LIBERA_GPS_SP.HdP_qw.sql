-- =============================================
-- Author:		<DVR>
-- Create date: <03/09/2020>
-- Description:	<Elimina la hoja de trabajo previamente existente para liberar y crear una nueva en la asignación del gps>
-- TEST :
/*
[solicitud].[DEL_HOJA_TRABAJO_LIBERA_GPS_SP]  
		@rfcEmpresa = 'AAN910409135',
		@idCliente = 218,
		@numeroContrato = '0001', 
		@idClase = 'Automovil',
		@idTipoObjeto = '118',
		@idObjeto = 13556,
		@idSolicitud = 1095,
		@idtipoSolicitud = 'Instala',
		@idUsuario = 1,
		@err = ''
*/
-- =============================================
CREATE PROCEDURE [solicitud].[DEL_HOJA_TRABAJO_LIBERA_GPS_SP] 
	@rfcEmpresa         varchar(15),
	@idCliente			int,
	@numeroContrato		varchar(50),
	@idClase			varchar(10),
	@idTipoObjeto		int,
	@idObjeto			int,
	@idSolicitud		int,
	@idtipoSolicitud	varchar(10),
	@idUsuario			int,  
	@err				varchar(500)OUTPUT 
AS
BEGIN
	BEGIN TRY

	DECLARE @idDocumentoClase INT = 0

	SELECT @idDocumentoClase = idDocumentoClase 
	FROM Solicitud.documento.Paso 
	WHERE idClase = @idClase
	AND idTipoSolicitud = @idtipoSolicitud
	AND nombre = 'Hoja de Trabajo'
	AND activo = 1
	
	DELETE FROM Solicitud.documento.SolicitudObjetoPaso 
	WHERE idClase = @idClase
	AND idCliente = @idCliente
	AND numeroContrato = @numeroContrato
	AND idTipoSolicitud = @idTipoSolicitud
	AND idSolicitud = @idSolicitud
	AND rfcEmpresa = @rfcEmpresa
	AND idTipoObjeto = @idTipoObjeto
	AND idObjeto = @idObjeto
	AND idDocumentoClase = @idDocumentoClase
	
	SELECT 1 AS exito
	
	END TRY
	BEGIN CATCH
				SELECT
				0 as exito,
				ERROR_NUMBER() AS ErrorNumber,
				ERROR_STATE() AS ErrorState,
				ERROR_SEVERITY() AS ErrorSeverity,
				ERROR_PROCEDURE() AS ErrorProcedure,
				ERROR_LINE() AS ErrorLine,
				ERROR_MESSAGE() AS ErrorMessage;
	END CATCH;
END

--USE [Solicitud]
go

