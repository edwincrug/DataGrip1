-- =============================================
-- Author:		Edgar Mendoza
-- Create date: 16/07/2019
-- Description:	Regresa estatus de solicitud tomando en cuenta sus partidas
-- Test:		SELECT [solicitud].[SEL_ESTATUS_PARTIDAS_FN](58, 'automovil', 31950)
-- =============================================
CREATE FUNCTION [solicitud].[SEL_ESTATUS_PARTIDAS_FN]
(
	@idSolicitud		INT,
	@idTipoSolicitud	VARCHAR(10),
	@rfcEmpresa			VARCHAR(13),
	@numeroContrato		VARCHAR(50),
	@idCliente			INT,
	@idClase			VARCHAR(13),
	@idPartida			INT
	
)
RETURNS VARCHAR(50)
AS
BEGIN
	DECLARE 
		@VC_Estatus		VARCHAR(60) = ''

		SELECT
		@VC_Estatus = 
						CASE 
							WHEN EXISTS(SELECT idEstatusCotizacionPartida 
											FROM [solicitud].[SolicitudCotizacionPartida]
											WHERE idEstatusCotizacionPartida = 'ENESPERA'
											AND idPartida = @idPartida
											AND idSolicitud = @idSolicitud
											AND idTipoSolicitud = @idTipoSolicitud
											AND rfcEmpresa = @rfcEmpresa
											AND numeroContrato = @numeroContrato
											AND idCliente = @idCliente
											AND idClase = @idClase) THEN 'ENESPERA'  

							WHEN EXISTS(SELECT idEstatusCotizacionPartida 
											FROM [solicitud].[SolicitudCotizacionPartida]
											WHERE idEstatusCotizacionPartida = 'APROBADA'
											AND idPartida = @idPartida
											AND idSolicitud = @idSolicitud
											AND idTipoSolicitud = @idTipoSolicitud
											AND rfcEmpresa = @rfcEmpresa
											AND numeroContrato = @numeroContrato
											AND idCliente = @idCliente
											AND idClase = @idClase)
								AND NOT EXISTS(SELECT idEstatusCotizacionPartida 
												FROM [solicitud].[SolicitudCotizacionPartida]
												WHERE idEstatusCotizacionPartida = 'ENESPERA'
												AND idPartida = @idPartida
												AND idSolicitud = @idSolicitud
												AND idTipoSolicitud = @idTipoSolicitud
												AND rfcEmpresa = @rfcEmpresa
												AND numeroContrato = @numeroContrato
												AND idCliente = @idCliente
												AND idClase = @idClase) THEN 'APROBADA'

							WHEN EXISTS(SELECT idEstatusCotizacionPartida 
											FROM [solicitud].[SolicitudCotizacionPartida]
											WHERE idEstatusCotizacionPartida = 'RECHAZADA'
											AND idPartida = @idPartida
											AND idSolicitud = @idSolicitud
											AND idTipoSolicitud = @idTipoSolicitud
											AND rfcEmpresa = @rfcEmpresa
											AND numeroContrato = @numeroContrato
											AND idCliente = @idCliente
											AND idClase = @idClase)
								AND NOT EXISTS(SELECT idEstatusCotizacionPartida 
												FROM [solicitud].[SolicitudCotizacionPartida]
												WHERE idEstatusCotizacionPartida IN ('ENESPERA', 'APROBADA')
												AND idPartida = @idPartida
												AND idSolicitud = @idSolicitud
												AND idTipoSolicitud = @idTipoSolicitud
												AND rfcEmpresa = @rfcEmpresa
												AND numeroContrato = @numeroContrato
												AND idCliente = @idCliente
												AND idClase = @idClase) THEN 'RECHAZADA'
						END

	RETURN @VC_Estatus
END
go

