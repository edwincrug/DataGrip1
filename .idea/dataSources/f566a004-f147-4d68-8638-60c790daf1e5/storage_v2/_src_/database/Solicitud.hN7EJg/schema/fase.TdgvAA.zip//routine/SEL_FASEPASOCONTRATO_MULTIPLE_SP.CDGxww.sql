
-- =============================================
-- Author: Adolfo Martinez
-- Create date: 30-07-2020
-- Description: Obtener faces y pasos por contrato multiple
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[SEL_FASEPASOCONTRATO_MULTIPLE_SP]  'ASE0508051B6', 185, '43', 457, 'Imagen', 'Automovil', 2, NULL;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [fase].[SEL_FASEPASOCONTRATO_MULTIPLE_SP]
	@rfcEmpresa				varchar(13),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	@idSolicitud			int,
	@idTipoSolicitud		varchar(10),
	@idClase				varchar(10),
	@idUsuario				int,
	@err					varchar(500)OUTPUT
AS


BEGIN

	DECLARE @cont INT = 1

	DECLARE @tbl_pasoContrato AS TABLE(
		idFase VARCHAR(100),
		idPaso VARCHAR(100),
		idTipoSolicitud varchar(10),
		idClase VARCHAR(10),
		nombre VARCHAR(100),
		idCliente INT,
		numeroContrato VARCHAR(10),
		idPasoAnterior VARCHAR(50),
		orden FLOAT,
		tiempoEstimado time(7) NULL
        )
	INSERT INTO @tbl_pasoContrato
	select
		idFase,
		idPaso,
		idTipoSolicitud,
		idClase,
		nombre,
		'' idCliente,
		'' numeroContrato,
		'' idPasoAnterior,
		CAST(orden as float) AS orden,
		tiempoEstimado
	from [fase].[Paso]
	WHERE idClase = @idClase AND
	[idTipoSolicitud] = @idTipoSolicitud
	IF OBJECT_ID('tempdb..#tmp_pasoContrato') IS NOT NULL
        BEGIN
		DROP TABLE #tmp_pasoContrato
	END
	SELECT
		ROW_NUMBER() OVER(ORDER BY PC.idTipoSolicitud, PC.orden) AS Row#,
		PC.idFase,
		PC.idPaso,
		PC.idTipoSolicitud,
		PC.idClase,
		PC.nombre,
		PC.idCliente,
		PC.numeroContrato,
		PC.idPasoAnterior,
		PC.orden,
		PC.tiempoEstimado
	INTO #tmp_pasoContrato
	FROM faseContrato.paso PC
	WHERE PC.rfcEmpresa = @rfcEmpresa AND
		PC.idCliente = @idCliente AND
		PC.numeroContrato = @numeroContrato AND
		PC.idClase = @idClase AND
		PC.idTipoSolicitud = @idTipoSolicitud

	--select * from #tmp_pasoContrato
	WHILE ( select COUNT(*)
	from #tmp_pasoContrato) >= @cont
        BEGIN
		INSERT INTO @tbl_pasoContrato
		SELECT
			idFase,
			idPaso,
			idTipoSolicitud,
			idClase,
			idPaso,
			idCliente,
			numeroContrato,
			idPasoAnterior,
			(SELECT CAST(TPC.orden AS VARCHAR(10)) + '.' + CAST(PC.orden AS VARCHAR(10))
			from @tbl_pasoContrato TPC
			WHERE TPC.idPaso = PC.idPasoAnterior AND TPC.idFase = PC.idFase)
			,tiempoEstimado
		from #tmp_pasoContrato PC
		WHERE Row# = @cont

		SET @cont = @cont + 1
	END

	-------------------------------------------FASES
	SELECT * FROM fase.Fase ORDER BY ORDEN


	select distinct
	FNP.idPaso as paso,
	S.idSolicitud,
	S.idTipoSolicitud,
	S.idClase,
	S.rfcEmpresa,
	S.idCliente,
	S.numeroContrato,
	S.idCentroCosto,
	S.fechaCreacion,
	S.fechaCita,
	S.numero,
	S.comentarios,
	S.idEstatusSolicitud,
	S.idUsuario,
	P.nombre
	into #test
	from [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud) FNP
	INNER JOIN solicitud.solicitud S ON
				S.idSolicitud = FNP.idSolicitud
	INNER JOIN fase.Paso P on P.idPaso = FNP.idPaso
	WHERE P.idClase = @idClase

	SELECT 
	 P.numeroPaso
	,P.idFase
	,P.idPaso
	,P.idTipoSolicitud
	,P.idClase
	,P.nombre
	,P.ordenFase
	,P.ordenPaso
	,P.tiempoEstimado
	,P.tipoPaso
	,T.idSolicitud
	INTO #prueba
	FROM [solicitud].SEL_PASO_PORTIPOSOLICITUD_FN(@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) AS P, #test AS T


	-------------------------------------------PASOS
	select DISTINCT
	P.numeroPaso
	,P.idFase
	,P.idPaso
	,P.idTipoSolicitud
	,P.idClase
	,P.nombre
	,P.ordenFase
	,P.ordenPaso
	,P.tiempoEstimado
	,P.tipoPaso
	,P.idSolicitud
	,SEP.fechaIngreso
	,SEP.fechaSalida
	,(SELECT solicitud.SEL_DIFERENCIAFECHADIAS_FN(SEP.fechaIngreso, SEP.fechaSalida)) AS tiempo
	,(COALESCE([U].[PrimerNombre], '') + ' '  + COALESCE([U].[SegundoNombre], '') + ' ' + COALESCE([U].[PrimerApellido], '')+ ' ' + COALESCE([U].[SegundoApellido], '')) AS [nombreCompleto]
	--,CASE WHEN SEP.fechaSalida IS NULL THEN 0
	--ELSE 1
	--END AS estatusPaso

	,CASE WHEN SEP.fechaIngreso IS NOT NULL AND SEP.fechaSalida IS NOT NULL THEN 1
		  WHEN SEP.fechaIngreso IS NOT NULL AND SEP.fechaSalida IS NULL THEN 2
		  WHEN SEP.fechaSalida IS NULL THEN 3
	END AS estatusPaso
	from #prueba P
	LEFT JOIN [Solicitud].[fase].[SolicitudEstatusPaso] AS SEP 
	ON SEP.idSolicitud = P.idSolicitud AND SEP.idPaso = P.idPaso AND SEP.idClase = P.idClase
	LEFT JOIN [Seguridad].[Catalogo].[Users] AS U ON u.Id = SEP.idUsuarioSalida

	---------------------------------------------------------------------------PASO ACTUAL
	
	SELECT 
		  S.[idSolicitud]
		 ,S.[idTipoSolicitud]
		 ,S.[descripcion]
		 ,S.[idClase]
		 ,S.[rfcEmpresa]
		 ,S.[idCliente]
		 ,S.[numeroContrato]
		 ,S.[idPaso]
		 ,S.[idFase]
		 ,S.[fechaIngreso]
		 ,S.[idEstatus]
		 ,S.[tipoPaso]
		 ,SS.[numero] AS 'numeroOrden'
		 --,CZ.descripcion as zona
		 ,TPC.tiempoEstimado
		 ,ISNULL(PC.valor,'No especificado') AS estadoUnidad
		 ,TPC.nombre AS estatus
		 ,SOL.fechaCita
		 ,CC.nombre AS nombreCentroCosto
		 ,CC.presupuesto AS centroCosto
		 ,SS.comentarios,
		 --(
			--SELECT
			--CONVERT(INT, ROUND(((ROUND((SUM(DATEDIFF(SECOND, SEP.fechaIngreso, getdate() )) / CONVERT(DECIMAL, 3600)), 0)) / 24), 0))
			--from #prueba P
			--LEFT JOIN [Solicitud].[fase].[SolicitudEstatusPaso] AS SEP 
			--ON SEP.idSolicitud = P.idSolicitud AND SEP.idPaso = P.idPaso AND SEP.idClase = P.idClase
			--LEFT JOIN [Seguridad].[Catalogo].[Users] AS U ON u.Id = SEP.idUsuarioSalida
			--WHERE SEP.fechaIngreso IS NOT NULL AND SEP.fechaSalida IS NOT NULL AND SEP.idSolicitud = @idSolicitud
		 --) 
		 DATEDIFF(day,SOL.fechaCreacion, GETDATE()) AS diasPasos,
		 CASE 
			WHEN S.idPaso = 'Finalizada' THEN (
			SELECT
			CONVERT(INT,ROUND((SUM(DATEDIFF(SECOND, S.fechaCreacion, SEP.fechaIngreso )) / CONVERT(DECIMAL, 3600)), 0))
			from #prueba P
			LEFT JOIN [Solicitud].[fase].[SolicitudEstatusPaso] AS SEP 
			ON SEP.idSolicitud = P.idSolicitud AND SEP.idPaso = P.idPaso AND SEP.idClase = P.idClase
			LEFT JOIN [Seguridad].[Catalogo].[Users] AS U ON u.Id = SEP.idUsuarioSalida
			INNER JOIN solicitud.Solicitud as s on s.idSolicitud = p.idSolicitud
			where p.idPaso = 'Finalizada'
		 )
			ELSE NULL
		END AS solicitudFinalizadaHoras,
		CASE 
			WHEN S.idPaso = 'Finalizada' THEN (
			SELECT
			CONVERT(INT, ROUND(((ROUND((SUM(DATEDIFF(SECOND, S.fechaCreacion, SEP.fechaIngreso )) / CONVERT(DECIMAL, 3600)), 0)) / 24), 0))
			from #prueba P
			LEFT JOIN [Solicitud].[fase].[SolicitudEstatusPaso] AS SEP 
			ON SEP.idSolicitud = P.idSolicitud AND SEP.idPaso = P.idPaso AND SEP.idClase = P.idClase
			LEFT JOIN [Seguridad].[Catalogo].[Users] AS U ON u.Id = SEP.idUsuarioSalida
			INNER JOIN solicitud.Solicitud as s on s.idSolicitud = p.idSolicitud
			where p.idPaso = 'Finalizada'
		 )
			ELSE NULL
		END AS solicitudFinalizadaDias
		,ss.idEstatusSolicitud
		 --,SOL.fechaCreacion
		 --,(SELECT solicitud.SEL_DIFERENCIAHORA_FN(S.fechaIngreso, GETDATE(), TPC.tiempoEstimado)) AS tiempoHoras
	 FROM [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud) AS S
	 INNER JOIN solicitud.Solicitud AS SS ON SS.idSolicitud = S.idSolicitud
	 --INNER JOIN [Solicitud].[solicitud].[SolicitudObjeto] AS SO ON
		-- SO.idSolicitud = S.idSolicitud AND 
		-- SO.idTipoSolicitud = S.idTipoSolicitud AND
		-- SO.idClase = S.idClase AND
		-- SO.rfcEmpresa = S.rfcEmpresa AND
		-- SO.idCliente = S.idCliente AND
		-- SO.numeroContrato = S.numeroContrato
	 --inner join [Cliente].[contrato].[Objeto] O on 
		--O.rfcEmpresa = SO.rfcEmpresa and 
		--O.idClase = SO.idClase and 
		--O.idCliente = SO.idCliente and 
		--O.numeroContrato = SO.numeroContrato AND
		--O.idObjeto = SO.idObjeto
	 --inner join [Common].[gerencia].[ContratoZona] CZ on 
		--CZ.idContratoZona = O.idContratoZona AND
		--CZ.rfcEmpresa = O.rfcEmpresa AND
		--CZ.idCliente = O.idCliente AND
		--CZ.numeroContrato = O.numeroContrato
	 inner join @tbl_pasoContrato TPC on 
		TPC.idClase = S.idClase AND TPC.idPaso = S.idPaso AND TPC.idTipoSolicitud = S.idTipoSolicitud
	INNER JOIN solicitud.solicitud SOL ON
				SOL.idSolicitud = S.idSolicitud
	INNER JOIN fase.Paso P on P.idPaso = S.idPaso
	LEFT JOIN [Solicitud].[solicitud].[SolicitudPropiedadClase] SPC ON
				SPC.idSolicitud = S.idSolicitud AND 
				SPC.idTipoSolicitud = S.idTipoSolicitud AND
				SPC.idClase = S.idClase AND
				SPC.rfcEmpresa = S.rfcEmpresa AND
				SPC.idCliente = S.idCliente AND
				SPC.numeroContrato = S.numeroContrato
	LEFT JOIN [Solicitud].[solicitud].[PropiedadClase] PC ON 
				PC.idPropiedadClase = SPC.idPropiedadClase AND
				PC.idClase = SPC.idClase
	left JOIN [Cliente].[contrato].[CentroCosto] CC ON
				CC.idCentroCosto = SOL.idCentroCosto AND
				CC.idCliente = SOL.idCliente AND
				CC.numeroContrato = SOL.numeroContrato AND
				CC.rfcEmpresa = SOL.rfcEmpresa
	 group by 
		 S.[idSolicitud]
		,S.[idTipoSolicitud]
		,S.[descripcion]
		,S.[idClase]
		,S.[rfcEmpresa]
		,S.[idCliente]
		,S.[numeroContrato]
		,S.[idPaso]
		,S.[idFase]
		,S.[fechaIngreso]
		,S.[idEstatus]
		,S.[tipoPaso]
		,SS.[numero]
		--,CZ.descripcion
		,TPC.tiempoEstimado
		,PC.valor
		,TPC.nombre
		,SOL.fechaCita
		,CC.nombre
		,CC.presupuesto
		,SS.comentarios
		,SOL.fechaCreacion
		,ss.idEstatusSolicitud
	
	----------------------------------------------------------------------------PASO ACTUAL CON TIEMPO
	EXEC [solicitud].[SEL_TOTAL_PARTIDAS_SP] @idSolicitud, @idUsuario
	DROP TABLE #tmp_pasoContrato, #test, #prueba;

END

--USE [Solicitud]
go

