
-- =============================================
-- Author:		Adolfo Martinez
-- Create date: 14/04/2020
-- Description:	Valida existencia de el procesar compra y si genera cxc de lo contrario avanza a finalizado
-- solicitud.solicitud.Solicitud
-- [cxc].[SEL_GENERA_CXC_SP] 1467,'Iguala','Automovil','ASE0508051B6',185,'43',1,''
-- [cxc].[SEL_GENERA_CXC_SP] 180, 'Imagen', 'Automovil','ASE0508051B6',185,'43', 6119
-- =============================================
CREATE PROCEDURE [cxc].[SEL_GENERA_CXC_SP]
@idSolicitud		INT,
@idTipoSolicitud	VARCHAR(10),
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@idUsuario			INT,
@err				VARCHAR(8000) = '' OUTPUT	

AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION

		DECLARE @v_instancia VARCHAR(150),
				@v_nombreBD	VARCHAR(150),
				@v_sq VARCHAR(MAX)=''
		DECLARE @tabletemp TABLE(val INT)
		DECLARE @generaCXC BIT =(SELECT generaCXC FROM [solicitud].[TipoSolicitud] WHERE idTipoSolicitud=@idTipoSolicitud AND idClase=@idClase)

		--print '1'
		SELECT  @v_instancia=instancia, @v_nombreBD=nombreBD 
				FROM common.configuracion.FacturacionBPRO fac 
				INNER JOIN cliente.cliente.contrato co ON  fac.idFacturacionBPRO=co.idFacturacionBPRO 
				WHERE co.rfcEmpresa=@rfcEmpresa
				AND	co.idCliente=@idCliente
				AND	co.numeroContrato=@numeroContrato
				AND	fac.activo=1 
		--print '2'
		DECLARE @queryText varchar(max) = 'SELECT CASE WHEN exists(SELECT 1 FROM solicitud.SolicitudCotizacion sc
					JOIN solicitud.Sel_totales_cotizacion_vw vw ON SC.idCotizacion = vw.idCotizacion
					LEFT JOIN '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC ose ON ose.OTE_ORDENPEMEX=sc.numeroCotizacion COLLATE Modern_Spanish_CI_AI
					WHERE sc.idSolicitud='+ CAST(@idSolicitud AS NVARCHAR(30))+'
					AND sc.idTipoSolicitud='''+@idTipoSolicitud+'''
					AND sc.idClase='''+@idClase+'''
					AND sc.rfcEmpresa='''+@rfcEmpresa+'''
					AND sc.idCliente='''+CAST(@idCliente AS NVARCHAR(30))+'''
					AND sc.numeroContrato='''+@numeroContrato+'''
					AND ose.OTE_ORDENPEMEX IS NULL) then 1 else 0 end'
		print @queryText
		--print '3'
		
		INSERT INTO @tabletemp 
		EXEC (@queryText) 

		--print '4'
	IF ((SELECT TOP 1 val FROM @tabletemp) = 1)
		BEGIN
			--print '5'
			SELECT 'La solicitud aun no ha procesado la compra!' msg, 1 estatus
		END
	ELSE
		BEGIN 
			IF(@generaCXC = 1)
				BEGIN
					SELECT 'La solicitud genera la cuenta por cobrar!' msg, 1 estatus
				END
			ELSE
				BEGIN
					EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,'Provisionada','Cobranza',3132,''

					SELECT 'La solicitud no genera la cuenta por cobrar!' msg, 0 estatus
				END
		END


		COMMIT
	
	END TRY
	BEGIN CATCH
		--ROLLBACK TRANSACTION
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al intentar guardar la prefactura.'
	END CATCH
END
go

