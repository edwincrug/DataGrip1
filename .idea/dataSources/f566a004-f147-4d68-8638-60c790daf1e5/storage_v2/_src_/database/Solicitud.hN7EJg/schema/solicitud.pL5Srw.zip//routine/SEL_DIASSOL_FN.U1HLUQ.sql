-- =============================================
-- Author:		José Etmanuel Hernández Rejón
-- Create date: 21/08/2019
-- Description:	Función para traerr los días de una solicitud

-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	--

	--Test
	[solicitud].[SEL_DIASSOL_FN]
*/

CREATE FUNCTION [solicitud].[SEL_DIASSOL_FN]
(
	@idSolicitud	INT
)
RETURNS INT
AS
BEGIN
	DECLARE @dias INT;
	DECLARE @finalizada DATETIME;

	SET @finalizada = (SELECT fechaIngreso FROM  [fase].[SolicitudEstatusPaso] WHERE idSolicitud = @idSolicitud AND idPaso = 'Finalizada') ;

	SET @dias = (SELECT CASE WHEN @finalizada IS NULL THEN
						DATEDIFF(day,fechaCita,GETDATE()) 
					ELSE
						DATEDIFF(day,fechaCita,@finalizada)		
					END  FROM Solicitud.solicitud.Solicitud
					WHERE idSolicitud = @idSolicitud
				)
	
	RETURN @dias;
END
go

