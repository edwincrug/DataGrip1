-- =============================================
-- Author:		Martin Pacheco
-- Create date: 31/07/2019
-- Description:	<Description,,>
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	25/09/2020	JLuis Lozada	se agrego al insert de la tabla [SolicitudCotizacionPartidaDescuento] porcentajeDescuentoCosto,descuentoCosto

	*- Testing...
	EXEC [solicitud].[INS_PARTIDA_COTIZACION_SP] 699, '153-1021-13285-1', 'ASE0508051B6',  'Servicio', '129', 220, 'Automovil', '<Partidas><partida><idPartida>620029</idPartida><cantidad>1</cantidad><idProveedorEntidad>undefined</idProveedorEntidad><rfcProveedor>undefined</rfcProveedor><costo>514.53</costo><venta>706.77</venta></partida></Partidas>', 148, 'DAC960820HV8', 6113,null
*/
-- =============================================
CREATE PROCEDURE [solicitud].[INS_PARTIDA_COTIZACION_SP]
	@idSolicitud		INT,
	@Cotizacion			VARCHAR(50) = '',
	@rfcEmpresa			VARCHAR(13) = '',
	@idTipoSolicitud	VARCHAR(50) = '',
	@numeroContrato		VARCHAR(50) = '',
	@idCliente			INT,
	@idClase			VARCHAR(10) = '',
	@Data				XML,
	@idProveedorEntidad	INT,
	@rfcProveedor		VARCHAR(13) = '',
	@idUsuario			INT,
	@err				VARCHAR(8000) OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	DECLARE @manejoDescuentoVenta INT, @porcentajeDescuentoVenta FLOAT
	SELECT @manejoDescuentoVenta=manejoDescuentoVenta, @porcentajeDescuentoVenta=porcentajeDescuentoVenta 
	FROM [Cliente].Cliente.Contrato
	WHERE rfcEmpresa=@rfcEmpresa AND idCliente=@idCliente AND numeroContrato=@numeroContrato

	 DECLARE
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en el stored: [INS_PARTIDA_COTIZACION_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_One				INT = 1,
		@VI_Zero			INT = 0,
		@idObjeto			INT,
		@idTipoObjeto		INT,
		@idCotizacion		INT

	SET @idObjeto = (
		SELECT 
			[idObjeto] 
		FROM [solicitud].[SolicitudObjeto] AS [SO]
		WHERE 
			[SO].[idSolicitud] = @idSolicitud
	)

	SET @idTipoObjeto = (
		SELECT 
			[idTipoObjeto] 
		FROM [solicitud].[SolicitudObjeto] AS [SO]
		WHERE 
			[SO].[idSolicitud] = @idSolicitud
	)

	SET @idCotizacion = (
		SELECT 
			[idCotizacion] 
		FROM [solicitud].[SolicitudCotizacion] AS [SO]
		WHERE 
			[SO].[idSolicitud] = @idSolicitud AND
			[SO].[numeroCotizacion] = @Cotizacion
	)

	select @idCotizacion 
		
	DECLARE @VT_Table TABLE (
		[Index]			INT IDENTITY(1,1),
		[idPartida]		INT,
		[cantidad]		INT,
		[costo]			float,
		[venta]			float
	);

	INSERT INTO @VT_Table
		SELECT
			I.N.value('(idPartida)[1]',	'INT'),
			I.N.value('(cantidad)[1]',	'INT'),
			I.N.value('(costo)[1]',		'float'),
			I.N.value('(venta)[1]',		'float')
		FROM @Data.nodes('/Partidas/partida') I(N);

	DECLARE @count INT = 1, @max INT = (SELECT count([Index]) FROM @VT_Table);
	BEGIN TRY 
		BEGIN TRANSACTION INS_PARTIDA_COTIZACION_SP
		WHILE (@count <= @max)
			BEGIN
				
				IF NOT EXISTS(SELECT 1 FROM  [solicitud].[SolicitudPartida] WHERE idSolicitud = @idSolicitud AND idPartida = (SELECT [idPartida] FROM @VT_Table WHERE [Index] = @count))
					BEGIN

						INSERT INTO [solicitud].[SolicitudPartida] (
							 [idSolicitud]
							,[idTipoSolicitud]
							,[idClase]
							,[rfcEmpresa]
							,[idCliente]
							,[numeroContrato]
							,[idObjeto]
							,[idTipoObjeto]
							,[idPartida]
							,[cantidad]
							,[costoInicial]
							,[ventaInicial]
							,[idEstatusSolicitudPartida]
							,[idUsuario]
						) VALUES (
							 @idSolicitud
							,@idTipoSolicitud
							,@idClase
							,@rfcEmpresa
							,@idCliente
							,@numeroContrato
							,@idObjeto
							,@idTipoObjeto
							,(SELECT [idPartida] FROM @VT_Table WHERE [Index] = @count)
							,(SELECT [cantidad] FROM @VT_Table WHERE [Index] = @count)
							,(SELECT [costo] FROM @VT_Table WHERE [Index] = @count)
							,(SELECT [venta] FROM @VT_Table WHERE [Index] = @count)
							,'ENESPERA'
							,@idUsuario
						)
					END
			
				INSERT INTO [solicitud].[SolicitudCotizacionPartida] (
					 [idCotizacion]
					,[idSolicitud]
					,[idTipoSolicitud]
					,[idClase]
					,[rfcEmpresa]
					,[numeroContrato]
					,[idCliente]
					,[rfcProveedor]
					,[idProveedorEntidad]
					,[idObjeto]
					,[idTipoObjeto]
					,[idPartida]
					,[cantidad]
					,[costo]
					,[venta]
					,[idEstatusCotizacionPartida]
					,[fechaEstatus]
					,[idUsuario]
				) VALUES (
					 @idCotizacion
					,@idSolicitud
					,@idTipoSolicitud
					,@idClase
					,@rfcEmpresa
					,@numeroContrato
					,@idCliente
					,@rfcProveedor
					,@idProveedorEntidad
					,@idObjeto
					,@idTipoObjeto
					,(SELECT [idPartida] FROM @VT_Table WHERE [Index] = @count)
					,(SELECT [cantidad] FROM @VT_Table WHERE [Index] = @count)
					,(SELECT [costo] FROM @VT_Table WHERE [Index] = @count)
					,(SELECT [venta] FROM @VT_Table WHERE [Index] = @count)
					,'ENESPERA'
					,GETDATE()
					,@idUsuario
				)
				IF(@manejoDescuentoVenta = 1)
					BEGIN
						INSERT INTO [solicitud].[SolicitudCotizacionPartidaDescuento] (
							 [idCotizacion]
							,[idSolicitud]
							,[idTipoSolicitud]
							,[idClase]
							,[rfcEmpresa]
							,[numeroContrato]
							,[idCliente]
							,[rfcProveedor]
							,[idProveedorEntidad]
							,[idObjeto]
							,[idTipoObjeto]
							,[idPartida]
							,[porcentajeDescuentoVenta]
							,[descuentoVenta]
							,[porcentajeDescuentoCosto]
							,[descuentoCosto]
							,[fecha]
							,[idUsuario]
						) VALUES (
							 @idCotizacion
							,@idSolicitud
							,@idTipoSolicitud
							,@idClase
							,@rfcEmpresa
							,@numeroContrato
							,@idCliente
							,@rfcProveedor
							,@idProveedorEntidad
							,@idObjeto
							,@idTipoObjeto
							,(SELECT [idPartida] FROM @VT_Table WHERE [Index] = @count)
							,@porcentajeDescuentoVenta
							,(SELECT (([venta] * @porcentajeDescuentoVenta) / 100) FROM @VT_Table WHERE [Index] = @count)
							,0
							,0
							,GETDATE()
							,@idUsuario)
					END

			SET @count =  @count + 1
			END
		COMMIT TRANSACTION INS_PARTIDA_COTIZACION_SP
	END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION INS_PARTIDA_COTIZACION_SP
				SET @VC_ErrorMessage = { 
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage
					) 
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
				SET @err = @VC_ErrorMessage;
			END
		END CATCH

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
	SET NOCOUNT OFF;
END

go

