-- =============================================
-- Author: Adolfo Martinez
-- Create date: 18-06-2020
-- Description: Consulta devuelve los objetos que esten por arriba y debajo del rango
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ='' ; EXEC [solicitud].[SEL_OBJETO_GPSKM_SP] 'Automovil', 0, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_OBJETO_GPSKM_SP] 
	@idClase				VARCHAR(10),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS
BEGIN

	/************************************************** CONFIG CONTRATOS **************************************************/
	DECLARE @camposPivot			VARCHAR(MAX),
			@camposPivotKey			VARCHAR(200),
			@sq						VARCHAR(MAX),
			@TablaObjetoFinal		VARCHAR(50),
			@TablaSolicitudFinal	VARCHAR(50),
			@sqx					VARCHAR(MAX) = '',
			@rango					DECIMAL(18,2)
	/************************************************** OBJETO DINAMICO **************************************************/
		--DECLARE @idClase VARCHAR(10)='Automovil'
		--IF OBJECT_ID('tempdb..#tablaObjetoFinal')IS NOT NULL DROP TABLE ##tablaObjetoFinal
		IF OBJECT_ID('tempdb..#tablaObjetoDatos')IS NOT NULL DROP TABLE #tablaObjetoDatos
		/*Modificar el query que llena la tabla @tObjeto al integrar en sp para que tome los filtros de la consulta general*/
		DECLARE @tObjeto TABLE(idTipoObjeto INT, idObjeto INT)
		SET @TablaObjetoFinal='TablaObjetoFinal_'+CAST(@idUsuario AS VARCHAR)+CAST(DATEPART(MINUTE,GETDATE()) AS VARCHAR)+CAST(DATEPART(SECOND,GETDATE()) AS VARCHAR) 

		INSERT INTO @tObjeto (idTipoObjeto, idObjeto) SELECT DISTINCT SO.idTipoObjeto, SO.idObjeto FROM [Solicitud].[solicitud].[ComprobanteRecepcion] SO
		JOIN [Cliente].Cliente.Contrato CON ON CON.numeroContrato = SO.numeroContrato AND CON.idCliente = SO.idCliente AND CON.rfcEmpresa = SO.rfcEmpresa AND CON.geolocalizacion = 1
		WHERE SO.idClase=@idClase --and SOL.idEstatusSolicitud='Activa'
		/*Modificar el query que llena la tabla @tObjeto al integrar en sp para que tome los filtros de la consulta general*/

		/*campos tabla common.reporte.Objeto*/
		DECLARE @tablaObjetoConfiguracion TABLE(idd INT identity,campo VARCHAR(100),tipoPropiedad VARCHAR(50),tipoObjeto varchar(50))
		/*campos tabla common.reporte.Objeto*/

		SET @camposPivot	 = ISNULL(STUFF((SELECT ',' + QUOTENAME(CAST(campo AS VARCHAR(MAX))) FROM Common.reporte.objeto WHERE idClase=@idClase ORDER BY orden ASC  FOR XML PATH('')),1,1,''),'sinCoinicidencia')
		SET @camposPivotKey	 ='idTipoObjeto AS key_idTipoObjeto,idObjeto AS key_idObjeto'
		SET @sq				 =''
  
		CREATE TABLE #tablaObjetoDatos([idTipoObjeto] [int] NULL, [idObjeto] [int] NULL, [agrupador] [varchar](250) NULL, [valor] [varchar](500) NULL)

		INSERT INTO @tablaObjetoConfiguracion(campo,tipoPropiedad,tipoObjeto) SELECT campo,tipoPropiedad,tipoObjeto FROM Common.reporte.Objeto WHERE idClase=@idClase ORDER BY orden ASC
	
		INSERT INTO #tablaObjetoDatos(idTipoObjeto,idObjeto,agrupador,valor) 
		SELECT	s.idTipoObjeto,s.idObjeto,tc.campo,[objeto].[objeto].[getPropiedadObjeto](case when tc.tipoObjeto='idTipoObjeto' then s.idTipoObjeto else s.idObjeto end, tc.campo, tc.tipoPropiedad,@idClase) FROM	@tObjeto s, @tablaObjetoConfiguracion tc
	
		SET @sq=''
		SET @sq+='SELECT r.* INTO '+ @TablaObjetoFinal +' FROM (select '+@camposPivotKey+',agrupador,valor from #tablaObjetoDatos) AS tx PIVOT (max(valor) for agrupador in ('+@camposPivot+')) as r '
		EXEC(@sq)

	/************************************************** PROVEEDOR DINAMICO **************************************************/
		IF OBJECT_ID('tempdb..#tablaKM')IS NOT NULL DROP TABLE #tablaKM
		--IF OBJECT_ID('tempdb..#tablaKMGPS')IS NOT NULL DROP TABLE #tablaKMGPS

		SELECT 	* INTO #tablaKM
		FROM(
				SELECT 
					CR.idComprobanteRecepcion,
					CR.idSolicitud,
					CR.idObjeto,
					CR.idTipoObjeto,
					(SELECT CRD.valor FROM [Solicitud].[solicitud].[ComprobanteRecepcionPropiedades] CRD JOIN [Solicitud].[solicitud].[ComprobantePropiedades] CP ON CP.idPropiedadClase=CRD.idPropiedadClase AND CP.descripcion IN('Kilometraje') WHERE CRD.idSolicitud=CR.idSolicitud AND CRD.idComprobanteRecepcion=CR.idComprobanteRecepcion AND CRD.idAgrupacion='Tablero')  AS KM,
					(SELECT CRD.valor FROM [Solicitud].[solicitud].[ComprobanteRecepcionPropiedades] CRD JOIN [Solicitud].[solicitud].[ComprobantePropiedades] CP ON CP.idPropiedadClase=CRD.idPropiedadClase AND CP.descripcion IN('Kilometraje GPS') WHERE CRD.idSolicitud=CR.idSolicitud AND CRD.idComprobanteRecepcion=CR.idComprobanteRecepcion AND CRD.idAgrupacion='Tablero') AS gpsKM
				FROM [Solicitud].[solicitud].[ComprobanteRecepcion] CR
				JOIN [Cliente].Cliente.Contrato CON ON CON.numeroContrato = CR.numeroContrato AND CON.idCliente = CR.idCliente AND CON.rfcEmpresa = CR.rfcEmpresa AND CON.geolocalizacion = 1
				--JOIN [Solicitud].[solicitud].[ComprobanteRecepcionPropiedades] CRD ON CRD.idSolicitud=CR.idSolicitud AND CRD.idComprobanteRecepcion=CR.idComprobanteRecepcion AND CRD.idAgrupacion='Tablero'
				--JOIN [Solicitud].[solicitud].[ComprobantePropiedades] CP ON CP.idPropiedadClase=CRD.idPropiedadClase AND CP.descripcion IN('Kilometraje','Kilometraje GPS')
			)T

		SET @sqx+='SELECT TGD.idComprobanteRecepcion, TGD.idSolicitud, TGD.idObjeto, TGD.idTipoObjeto, ISNULL(TGD.KM,0) KM, ISNULL(TGD.gpsKM,0) gpsKM, O.* FROM #tablaKM tGD '
		SET @sqx+=' LEFT JOIN '+ @TablaObjetoFinal +' o  ON o.key_idObjeto=tGD.idObjeto AND o.key_idTipoObjeto=tGD.idTipoObjeto '
		SET @sqx+=' WHERE Abs(ISNULL(TGD.KM,0)) - Abs(ISNULL(TGD.gpsKM,0)) BETWEEN 0 AND 200 '
		SET @sqx+=' ORDER BY tGD.idComprobanteRecepcion DESC '

		EXEC(@sqx)


		Print 'Eliminando tablas fisicas al terminar SP'
		IF OBJECT_ID(@TablaObjetoFinal, 'U') IS NOT NULL  
			BEGIN
				SET @sqx='DROP TABLE '+@TablaObjetoFinal 
				EXEC (@sqx)
			END	

		IF OBJECT_ID('tempdb..#tablaKM')IS NOT NULL DROP TABLE #tablaKM
		--IF OBJECT_ID('tempdb..#tablaKMGPS')IS NOT NULL DROP TABLE #tablaKMGPS
		IF OBJECT_ID('tempdb..#tablaObjetoDatos')IS NOT NULL DROP TABLE #tablaObjetoDatos

END


--USE [Solicitud]
go

