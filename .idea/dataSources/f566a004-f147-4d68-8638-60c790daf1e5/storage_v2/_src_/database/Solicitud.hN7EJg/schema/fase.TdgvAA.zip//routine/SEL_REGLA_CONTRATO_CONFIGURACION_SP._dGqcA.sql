
-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 02/07/2019
-- Description: Obtiene las reglas de paso o la regla de acuerdo al contrato enviado y paso enviado
-- ============== Versionamiento ================
/*
	*- Testing...*
	EXEC fase.SEL_REGLA_CONTRATO_CONFIGURACION_SP 
	@idSolicitud = 730,
	@idReglaPaso = 94,
	@idPaso = 'EnEspera',
	@idFase = 'Aprobacion',
	@idClase = 'Automovil',
	@idTipoSolicitud = 'Servicio',
	@rfcEmpresa = 'ASE0508051B6',
	@idCliente = 220,
	@numeroContrato = '129',
	@aplicacionesId = 9,
	@aplicaReglaRol = 0,
	@aplicaReglaMonto = 1,
	@aplicaReglaUsuario = 1,
	@aplicaReglaPartida = 0,
	@aplicaReglaObjeto = 0,
	@idUsuario = 3135,
	@roles = '<roles><rol>83</rol></roles>'

*/
-- =============================================
CREATE PROCEDURE [fase].[SEL_REGLA_CONTRATO_CONFIGURACION_SP]
	@idSolicitud INT,
	@idReglaPaso INT,
	@idPaso VARCHAR(50),
	@idFase VARCHAR(20),
	@idClase VARCHAR(10),
	@idTipoSolicitud VARCHAR(10),
	@rfcEmpresa VARCHAR(13),
	@idCliente INT,
	@numeroContrato VARCHAR(50),
	@aplicacionesId INT,
	@aplicaReglaRol BIT,
	@aplicaReglaMonto BIT,
	@aplicaReglaUsuario BIT,
	@aplicaReglaPartida BIT,
	@aplicaReglaObjeto BIT,
	@idUsuario INT = NULL,
	@roles XML = NULL,
	@err VARCHAR(500) = NULL OUTPUT
AS
BEGIN
	BEGIN TRY

		DECLARE @rolesTable TABLE (idRol INT, aplicacionesId INT)
		INSERT INTO @rolesTable (idRol, aplicacionesId)
		SELECT ParamValues.col.value('.[1]','int')
			,@aplicacionesId
		FROM @roles.nodes('roles/rol') AS ParamValues(col)


		SELECT montoMaximo
			, montoMinimo
			, idTipoMonto
		FROM fase.ReglaPasoMonto
		WHERE idReglaPaso = @idReglaPaso
		AND idPaso = @idPaso
		AND idFase = @idFase
		AND idClase = @idClase
		AND idTipoSolicitud = @idTipoSolicitud
		AND rfcEmpresa = @rfcEmpresa
		AND idCliente = @idCliente
		AND numeroContrato = @numeroContrato
		AND activo = 1
		AND @aplicaReglaMonto = 1

		SELECT DISTINCT RPR.AplicacionesId
			, RolId
		FROM fase.ReglaPasoRol RPR
		INNER JOIN @rolesTable RT
		ON RPR.RolId = RT.idRol
		AND RPR.AplicacionesId = RT.aplicacionesId
		WHERE idReglaPaso = @idReglaPaso
		AND idPaso = @idPaso
		AND idFase = @idFase
		AND idClase = @idClase
		AND idTipoSolicitud = @idTipoSolicitud
		AND rfcEmpresa = @rfcEmpresa
		AND idCliente = @idCliente
		AND numeroContrato = @numeroContrato
		AND RPR.AplicacionesId = @aplicacionesId
		AND activo = 1
		AND @aplicaReglaRol = 1

		SELECT DISTINCT UsersId
			, AplicacionesId
		FROM fase.ReglaPasoUsuario
		WHERE idReglaPaso = @idReglaPaso
		AND idPaso = @idPaso
		AND idFase = @idFase
		AND idClase = @idClase
		AND idTipoSolicitud = @idTipoSolicitud
		AND rfcEmpresa = @rfcEmpresa
		AND idCliente = @idCliente
		AND numeroContrato = @numeroContrato
		AND AplicacionesId = @aplicacionesId
		AND activo = 1
		AND UsersId = @idUsuario
		AND @aplicaReglaUsuario = 1

		SELECT SCP.idCotizacion
			, SCP.idPartida
			, SCP.idTipoObjeto
			, SCP.idClase
		FROM fase.ReglaPasoPartida RPP
		INNER JOIN solicitud.SolicitudCotizacionPartida SCP
		ON RPP.idClase = SCP.idClase
		AND RPP.idTipoSolicitud = SCP.idTipoSolicitud
		AND RPP.rfcEmpresa = SCP.rfcEmpresa
		AND RPP.idCliente = SCP.idCliente
		AND RPP.numeroContrato = SCP.numeroContrato
		AND RPP.idPartida = SCP.idPartida
		AND RPP.idTipoObjeto = SCP.idTipoObjeto
		WHERE RPP.idReglaPaso = @idReglaPaso
		AND RPP.idPaso = @idPaso
		AND RPP.idFase = @idFase
		AND SCP.idClase = @idClase
		AND SCP.idTipoSolicitud = @idTipoSolicitud
		AND SCP.rfcEmpresa = @rfcEmpresa
		AND SCP.idCliente = @idCliente
		AND SCP.numeroContrato = @numeroContrato
		AND SCP.idSolicitud = @idSolicitud
		AND RPP.activo = 1
		AND @aplicaReglaPartida = 1

		--SELECT idPartida
		--	, idTipoObjeto
		--	, idClase
		--FROM fase.ReglaPasoPartida
		--WHERE idReglaPaso = @idReglaPaso
		--AND idPaso = @idPaso
		--AND idFase = @idFase
		--AND idClase = @idClase
		--AND idTipoSolicitud = @idTipoSolicitud
		--AND rfcEmpresa = @rfcEmpresa
		--AND idCliente = @idCliente
		--AND numeroContrato = @numeroContrato
		--AND activo = 1
		--AND @aplicaReglaPartida = 1

		SELECT idTipoObjeto
			, idObjeto
			,idClase
		FROM fase.ReglaPasoObjeto
		WHERE idReglaPaso = @idReglaPaso
		AND idPaso = @idPaso
		AND idFase = @idFase
		AND idClase = @idClase
		AND idTipoSolicitud = @idTipoSolicitud
		AND rfcEmpresa = @rfcEmpresa
		AND idCliente = @idCliente
		AND numeroContrato = @numeroContrato
		AND activo = 1
		AND @aplicaReglaObjeto = 1

		SELECT SCP.idCotizacion
			, SCP.idPartida
			, SCP.idTipoObjeto
			, SCP.idClase
			, SCP.cantidad
			, SCP.costo
			, SCP.venta
			, SCP.idEstatusCotizacionPartida
			, ROUND((ISNULL(SCP.venta,0) * ISNULL(SCP.cantidad,0)), 2) AS montoEvaluar
			, ECP.nombre AS nombreEstatusSolicitudPartida
		FROM solicitud.SolicitudObjeto SO
		INNER JOIN solicitud.SolicitudCotizacionPartida SCP
		ON SO.idSolicitud = SCP.idSolicitud
		AND SO.idTipoObjeto = SCP.idTipoObjeto
		AND SO.idClase = SCP.idClase
		AND SO.rfcEmpresa = SCP.rfcEmpresa
		AND SO.idCliente = SCP.idCliente
		AND SO.numeroContrato = SCP.numeroContrato
		AND SO.idTipoSolicitud = SCP.idTipoSolicitud
		AND SO.idObjeto = SCP.idObjeto
		INNER JOIN solicitud.EstatusCotizacionPartida ECP
		ON SCP.idEstatusCotizacionPartida = ECP.idEstatusCotizacionPartida
		WHERE SO.idSolicitud = @idSolicitud
		AND SO.idTipoSolicitud = @idTipoSolicitud
		AND SO.idClase = @idClase
		AND SO.rfcEmpresa = @rfcEmpresa
		AND SO.idCliente = @idCliente
		AND SO.numeroContrato = @numeroContrato

	END TRY
	BEGIN CATCH
		SELECT @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
	END CATCH
END

go

