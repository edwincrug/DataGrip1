

-- =============================================
-- Author: Adolfo Martinez
-- Create date: 08/04/2020
-- Description: Obtener el detalle de la solicitud por facturas
-- [cxc].[SEL_FACTURA_POR_SOLICITUD_SP] 97, 'Imagen', 'Automovil','ASE0508051B6',185,'43', 6119
-- =============================================
CREATE  PROCEDURE [cxc].[SEL_FACTURA_POR_SOLICITUD_SP]
@idSolicitud INT,
@idTipoSolicitud VARCHAR(10),
@idClase VARCHAR(10),
@rfcEmpresa	VARCHAR(13),
@idCliente INT,
@numeroContrato	VARCHAR(50),
@idUsuario INT,
@err VARCHAR(8000) = '' OUTPUT	
AS

BEGIN

	SELECT idFactura,subtotal,total,GETDATE() as fecha
	FROM [Solicitud].[cxc].[factura] 
	WHERE idSolicitud =@idSolicitud
		AND idTipoSolicitud	=@idTipoSolicitud
		AND idClase	=@idClase
		AND rfcEmpresa =@rfcEmpresa
		AND idCliente =@idCliente
		AND numeroContrato =@numeroContrato


	SELECT idSolicitud, idTipoSolicitud
	FROM [Solicitud].[solicitud].[Solicitud]
	WHERE idSolicitud =@idSolicitud
		AND idTipoSolicitud	=@idTipoSolicitud
		AND idClase	=@idClase
		AND rfcEmpresa =@rfcEmpresa
		AND idCliente =@idCliente
		AND numeroContrato =@numeroContrato

END
go

