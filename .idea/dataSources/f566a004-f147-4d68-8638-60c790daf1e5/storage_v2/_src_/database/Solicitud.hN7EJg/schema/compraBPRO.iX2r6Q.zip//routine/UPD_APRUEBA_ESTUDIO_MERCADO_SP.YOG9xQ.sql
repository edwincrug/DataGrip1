
-- =============================================
-- Author:		<Adolfo Martinez>
-- Create date: <10/06/2020>
-- Description:	<Procesamos estudio de mercado>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	
	*- Testing...
	declare @err varchar(500) = ''
    EXEC [compraBPRO].[UPD_APRUEBA_ESTUDIO_MERCADO_SP] 
		'1-1314-13549'
		,71
		,1
		,@err out
	select @err

*/
CREATE PROCEDURE [compraBPRO].[UPD_APRUEBA_ESTUDIO_MERCADO_SP]
	@numeroSolicitud VARCHAR(50),
	@idAutorizador INT,
	@estatusAprobacion BIT, --0 rechazada, 1 aprobada
	@err varchar(500) OUT
AS
BEGIN

	set @err=''
	DECLARE @idSolicitud INT,
			@idClase	VARCHAR(20),
			@rfcEmpresa VARCHAR(13),
			@idCliente INT,
			@numeroContrato VARCHAR(50)
	SELECT 
		@idSolicitud=idSolicitud,
		@rfcEmpresa=rfcEmpresa,
		@idCliente=idCliente,
		@idClase = idClase,
		@numeroContrato=numeroContrato
	FROM solicitud.SolicitudObjeto 
	WHERE numeroOrden=@numeroSolicitud

	UPDATE compraBPRO.Solicitud
	SET 
		aprobacionEstudioMercado=GETDATE(), 
		idAprobadorEstudioMercado=@idAutorizador
	WHERE 
		idSolicitud=@idSolicitud

	IF(@estatusAprobacion = 0)
		BEGIN
			UPDATE solicitud.solicitud
			SET idEstatusSolicitud='RECHAZADA'
			WHERE idSolicitud=@idSolicitud
			
			UPDATE fase.SolicitudEstatusPaso 
			SET fechaSalida=GETDATE(), idUsuarioSalida=3132
			WHERE idSolicitud=@idSolicitud AND fechaSalida IS NULL AND idUsuarioSalida IS NULL
			
		END
	ELSE
		BEGIN
			create table #temp(idTarea int)
			insert into #temp 
			EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP] 
				@idSolicitud= @idSolicitud,
				@idTipoSolicitud='Compra',
				@idClase = 'Compra',
				@rfcEmpresa = @rfcEmpresa,
				@idCliente=@idCliente,
				@numeroContrato=@numeroContrato,
				@idUsuario=3132,
				@err = @err out
			drop table #temp
		END
END

go

