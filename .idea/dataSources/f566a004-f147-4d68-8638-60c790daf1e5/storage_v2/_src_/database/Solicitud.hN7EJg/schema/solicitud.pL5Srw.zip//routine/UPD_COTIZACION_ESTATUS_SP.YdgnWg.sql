-- =============================================
-- Author: aDOLFO mARTINEZ
-- Create date: 05/05/2020
-- Description: Autoriza una partida
-- [solicitud].[UPD_COTIZACION_ESTATUS_SP] 1057, 473, 'Imagen', 'Automovil', 'ASE0508051B6', '43', 185, 'ZEA1703078E1', 520, 6334
-- =============================================

CREATE PROCEDURE [solicitud].[UPD_COTIZACION_ESTATUS_SP]
	@idCotizacion					INT,
	@idSolicitud					INT,
	@idTipoSolicitud				VARCHAR(10),
	@idClase						VARCHAR(10),
	@rfcEmpresa						VARCHAR(13),
	@numeroContrato					VARCHAR(50),
	@idCliente						INT,
	@rfcProveedor					VARCHAR(13),
	@idProveedorEntidad				INT,
	@idUsuario						INT,
	@err				            VARCHAR(500) OUTPUT
AS
BEGIN
	DECLARE @TotalPartida INT,
			@TotalRechazada INT
			
	IF NOT EXISTS(SELECT 1 FROM [solicitud].[SolicitudCotizacionPartida] WHERE idCotizacion = @idCotizacion AND idSolicitud=@idSolicitud AND cantidad > 0 AND idEstatusCotizacionPartida = 'ENESPERA')
		BEGIN	
			SET @TotalPartida =  (SELECT COUNT(1) FROM [solicitud].[SolicitudCotizacionPartida] WHERE idCotizacion = @idCotizacion AND idSolicitud=@idSolicitud AND cantidad > 0)
			SET @TotalRechazada = (SELECT COUNT(1) FROM [solicitud].[SolicitudCotizacionPartida] WHERE idCotizacion = @idCotizacion AND idSolicitud=@idSolicitud AND cantidad > 0 AND idEstatusCotizacionPartida = 'RECHAZADA')
			
			IF(@TotalPartida = @TotalRechazada)
				BEGIN
					UPDATE [solicitud].[SolicitudCotizacion]
					SET idEstatusCotizacion='RECHAZADA'
					WHERE idCotizacion=@idCotizacion

					INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
					(fechaAlta,idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,idEstatusCotizacion,idUsuario)
					VALUES 
					(GETDATE(),@idCotizacion,@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idProveedorEntidad,@rfcProveedor ,'RECHAZADA',@idUsuario)
				END
			ELSE
				BEGIN
					UPDATE [solicitud].[SolicitudCotizacion]
					SET idEstatusCotizacion='APROBADA'
					WHERE idCotizacion=@idCotizacion

					INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
					(fechaAlta,idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,idEstatusCotizacion,idUsuario)
					VALUES 
					(GETDATE(),@idCotizacion,@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idProveedorEntidad,@rfcProveedor ,'APROBADA',@idUsuario)
				END
		END
END
go

