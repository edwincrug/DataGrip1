
-- =============================================
-- Author:		Andres Farias
-- Create date: 24/07/2019
-- Description:	Inserta los datos de la prefactura
-- ============== Versionamiento ================  
/* 
	Fecha			Autor		Descripción   
	18/04/2020		JLLOZADA	Se modificaron los querys que hacen operaciones a tablas de bpro, se hicieron dinamicos recuperando configuracion de common.configuracion.FacturacionBPRO en funcion al contrato de la orden
	25/06/2020		JLLOZADA	Se agrego el dato numero de copade en la salida del SP, usado en el front

	DECLARE @err VARCHAR(8000)=''
	EXEC cxc.[INS_FACTURAAGRUPADA_SP] 'Automovil','ASE0508051B6',185,'43','24/07/2019 10:24:27','24/07/2019 10:24:27',NULL,NULL,0,0,'xml'
	,'<facturas><factura><idFactura>326</idFactura></factura></facturas>',6110
	,'<solicitudes><solicitud><idSolicitud>938</idSolicitud><idTipoSolicitud>Imagen</idTipoSolicitud></solicitud></solicitudes>',''

*/
-- =============================================
CREATE PROCEDURE [cxc].[INS_FACTURAAGRUPADA_SP]
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@fechaCarga         DATETIME,
@fechaRecepcion     DATETIME,
@numeroCopade       VARCHAR(500) = NULL,
@numeroEstimacion   VARCHAR(500) = NULL,
@subtotal		    FLOAT,
@total				FLOAT,
@xml				VARCHAR(MAX) = NULL,
@xmlFacturas        XML,
@idUsuario			INT,
@xmlSolicitudes     XML,
@err				VARCHAR(8000) = '' OUTPUT	
AS
BEGIN
	BEGIN TRY  
		IF OBJECT_ID('tempdb..#tbl_facturas')is not null DROP TABLE #tbl_facturas
		DECLARE @idFactura INT
		DECLARE @tbl_solicitudes AS TABLE(_row INT IDENTITY(1,1),idSolicitud INT,idTipoSolicitud VARCHAR(MAX))
		DECLARE @contOrden INT = 1, @idSolicitud INT, @idTipoSolicitud VARCHAR(MAX),@v_instancia NVARCHAR(150),@v_nombreBD NVARCHAR(150),@v_sq NVARCHAR(MAX)=''
		CREATE TABLE #tbl_facturas(_row INT IDENTITY(1,1),idFactura INT)
		INSERT INTO #tbl_facturas(idFactura) SELECT DISTINCT ParamValues.col.value('idFactura[1]','int') FROM @xmlFacturas.nodes('facturas/factura') AS ParamValues(col)
		INSERT INTO @tbl_solicitudes(idSolicitud, idTipoSolicitud) SELECT DISTINCT ParamValues.col.value('idSolicitud[1]','int'),ParamValues.col.value('idTipoSolicitud[1]','varchar(max)') FROM @xmlSolicitudes.nodes('solicitudes/solicitud') AS ParamValues(col)
				
		--BEGIN TRANSACTION
		IF NOT EXISTS(SELECT 1 FROM cxc.FacturaAgrupada FA WHERE FA.idFactura IN(SELECT idFactura FROM #tbl_facturas))
			BEGIN
				SELECT  @v_instancia=instancia,@v_nombreBD=nombreBD 
				FROM	common.configuracion.FacturacionBPRO fac 
				INNER	JOIN cliente.cliente.contrato co ON  fac.idFacturacionBPRO=co.idFacturacionBPRO 
				WHERE	co.rfcEmpresa		=@rfcEmpresa
				AND		co.idCliente		=@idCliente
				AND		co.numeroContrato	=@numeroContrato
				AND		fac.activo			=1 

				IF LEN(@v_instancia)>0 AND LEN(@v_nombreBD)>0 
					BEGIN
						IF (@numeroEstimacion IS NULL) SET @numeroEstimacion = solicitud.SEL_NUMERO_AGRUPADORFACTURA_FN(@rfcEmpresa, @idClase,@idCliente,@numeroContrato)
		
						IF (@numeroCopade IS NULL) SET @numeroCopade = solicitud.SEL_NUMERO_AGRUPADORFACTURA_FN(@rfcEmpresa, @idClase,@idCliente,@numeroContrato)

						DECLARE @cont int = 1
						WHILE(@cont <= (SELECT COUNT(*) FROM #tbl_facturas))
							BEGIN
								INSERT INTO cxc.FacturaAgrupada([idFactura],[rfcEmpresa],[idCliente],[numeroContrato],[fechaCarga],[fechaRecepcion],[numeroCopade],[numeroEstimacion],[xml],[idUsuario],[activo]) 
								VALUES((SELECT idFactura FROM #tbl_facturas WHERE _row = @cont),@rfcEmpresa,@idCliente,@numeroContrato,@fechaCarga,@fechaRecepcion,@numeroCopade,@numeroEstimacion,@xml,@idUsuario,1)
								--Actualizar el estatus de la factura
								UPDATE cxc.Factura SET idEstatus = 'PrefacturaGenerada' WHERE idFactura = (SELECT idFactura FROM #tbl_facturas WHERE _row = @cont)
								SET @cont = @cont + 1
							END

						SET @v_sq=''
						SET @v_sq+=' INSERT INTO '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_COPADE(COP_ORDENGLOBAL,COP_COPADE,COP_CVEUSU,COP_FECHOPE,COP_HORAOPE,COP_IDDOCTO,COP_STATUS,COP_CARGO,COP_SALDO,COP_FECHULTPAG) '
						SET @v_sq+=' VALUES(@numeroEstimacion,'''',''GMI'',CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(TIME,GETDATE(),103),NULL,1,NULL,NULL,NULL) '
						--SET @v_sq+=' VALUES(@numeroEstimacion,@numeroCopade,''GMI'',CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(TIME,GETDATE(),103),NULL,1,NULL,NULL,NULL) '
						EXEC sp_executesql  @v_sq, N'@numeroEstimacion VARCHAR(500),@numeroCopade VARCHAR(500) ',
											@numeroEstimacion	=@numeroEstimacion,
											@numeroCopade		=@numeroCopade

						SET @v_sq=''
						SET @v_sq+=' UPDATE '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC SET OTE_ORDENGLOBAL = @numeroEstimacion '
						SET @v_sq+=' WHERE OTE_ORDENANDRADE COLLATE MODERN_SPANISH_CI_AS IN(	SELECT	so.numeroOrden '
						SET @v_sq+='							FROM	cxc.Factura fac '
						SET @v_sq+='							INNER	JOIN solicitud.Solicitud s ON s.idSolicitud = fac.idsolicitud AND s.idCliente = fac.idCliente AND s.idClase = fac.idClase AND s.numeroContrato = fac.numeroContrato '
						SET @v_sq+='							INNER	JOIN solicitud.SolicitudObjeto so ON so.idSolicitud = s.idSolicitud AND so.idCliente = s.idCliente AND so.idClase = s.idClase AND so.numeroContrato = s.numeroContrato '
						SET @v_sq+='							WHERE	fac.numeroContrato = @numeroContrato AND fac.rfcEmpresa = @rfcEmpresa AND fac.idCliente = @idCliente AND fac.idClase = @idClase AND fac.idFactura IN (SELECT idFactura FROM #tbl_facturas) GROUP BY so.numeroOrden) '
						SET @v_sq+=' AND OTE_ORDENPEMEX COLLATE MODERN_SPANISH_CI_AS IN (SELECT fac.numeroCotizacion FROM cxc.Factura fac WHERE fac.idFactura in (SELECT idFactura FROM #tbl_facturas))'
						print @v_sq
						EXEC sp_executesql  @v_sq, N'@numeroEstimacion VARCHAR(500),@numeroContrato VARCHAR(50),@rfcEmpresa VARCHAR(13),@idCliente INT,@idClase VARCHAR(10)',
											@numeroEstimacion	=@numeroEstimacion,
											@numeroContrato		=@numeroContrato,
											@rfcEmpresa			=@rfcEmpresa,
											@idCliente			=@idCliente,
											@idClase			=@idClase

						-- Avanzar la orden
						SELECT *,@numeroCopade numeroCopade FROM @tbl_solicitudes

						WHILE (@contOrden <= (SELECT COUNT(*) FROM @tbl_solicitudes))
							BEGIN 
								SELECT	@idSolicitud = idSolicitud  FROM @tbl_solicitudes WHERE _row = @contOrden
								SELECT	@idTipoSolicitud = idTipoSolicitud FROM @tbl_solicitudes WHERE _row = @contOrden
								--EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idUsuario,''
								EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,'PrefacturaGenerada','Cobranza',@idUsuario,''
								SET @contOrden = @contOrden + 1
							END
					END
				ELSE
					BEGIN
						SET @err = 'Error, El contrato no tiene asignada configuración para facturación'
					END
			END
		ELSE
			BEGIN
				SET @err = 'Error, Alguna de las facturas enviada ya han sido registradas previamente'
			END
		--COMMIT
	END TRY
	BEGIN CATCH
		--ROLLBACK TRANSACTION
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al intentar guardar la prefactura.'
	END CATCH
END
go

