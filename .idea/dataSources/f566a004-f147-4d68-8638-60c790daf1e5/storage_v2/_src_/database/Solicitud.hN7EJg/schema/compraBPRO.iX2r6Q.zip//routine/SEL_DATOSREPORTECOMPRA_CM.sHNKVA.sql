--use Solicitud
-- =============================================
-- Author:		<José Luis Lozada Guerrero>
-- Create date: <17/06/2020>
-- Description:	<Obtiene informacion para el reporte de aprobacion de compra>


/*
	EXEC [compraBPRO].SEL_DATOSREPORTECOMPRA_CM 627,'Compra','Compra','ASE0508051B6',221,'49',6282,null
	
*/
-- =============================================
CREATE PROCEDURE [compraBPRO].[SEL_DATOSREPORTECOMPRA_CM]
	@idSolicitud			INT,
	@idTipoSolicitud		VARCHAR(50) = '',
	@idClase				VARCHAR(10) = '',
	@rfcEmpresa				VARCHAR(13) = '',
	@idCliente				INT = 0,
	@numeroContrato			VARCHAR(50) = '',
	@idUsuario				INT = 0,
	@err					VARCHAR(8000) OUTPUT
AS
BEGIN
	
	SELECT  so.numeroOrden 'noRequerimiento',
			ISNULL((select emp_nombre FROM [192.168.20.29].ControlAplicaciones.dbo.cat_empresas WHERE emp_idempresa=cs.idEmpresa),'') 'empresaSolicitante',
			ISNULL((select suc_nombre FROM [192.168.20.29].ControlAplicaciones.dbo.cat_sucursales WHERE emp_idempresa =cs.idEmpresa AND suc_idSucursal=cs.idSucursal),'') 'sucursalSolicitante',
			ISNULL((SELECT otc_area FROM [192.168.20.29].Centralizacionv2.dbo.DIG_ESCALAMIENTO_AREA_AFECT WHERE emp_idempresa =cs.idEmpresa AND suc_idsucursal=cs.idSucursal AND id=cs.idArea ),'') 'areaSolicitante',
			[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, 'LugarEntrega', 'clase',@idClase) 'lugarDeEntrega',
			[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, 'contactoEntrega1', 'clase',@idClase) + ', '+
			[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, 'contactoEntrega2', 'clase',@idClase) 'contactosEntrega',
			CONVERT(VARCHAR(15),s.fechaCreacion,101)+ ' '+CONVERT(VARCHAR(15),s.fechaCreacion,108) 'fechaSolicitud',
			[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, 'justificacionCompra', 'clase',@idClase) 'justificacionCompra',
			[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, 'LugarEntrega', 'clase',@idClase) 'lugarDeEntrega',
			[objeto].[objeto].[getPropiedadObjeto](so.idObjeto, 'Nombre', 'clase',@idClase) 'nombreSolicitante',
			ISNULL((SELECT email FROM seguridad.catalogo.users 
					WHERE id =(	SELECT	TOP 1 idUsuario 
								FROM	Common.configuracion.usuariosBPRO 
								WHERE	idUsuarioBPRO=[objeto].[objeto].[getPropiedadObjeto](so.idObjeto, 'Clave', 'clase',@idClase))),'')'contactoSolicitante',
			[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, 'condicionEntrega', 'clase',@idClase) 'condicionDeEntrega',
			[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, 'urgenciaDeLaCompra', 'clase',@idClase) 'urgenciaDeLaCompra',
			[solicitud].[solicitud].[getPropiedadSolicitud](s.idSolicitud, 'fechaLimiteEntrega', 'clase',@idClase) 'fechaLimiteEntrega',		
			s.comentarios
	FROM	solicitud.solicitud s
	INNER	JOIN solicitud.SolicitudObjeto so 
			ON s.idSolicitud		= so.idSolicitud 
			AND s.idTipoSolicitud	= so.idTipoSolicitud 
			AND s.idClase			= so.idClase 
			AND s.rfcEmpresa		= so.rfcEmpresa 
			AND s.idCliente			= so.idCliente 
			AND s.numeroContrato	= so.numeroContrato	
	INNER	JOIN compraBPRO.Solicitud cs 
			ON cs.idSolicitud		= s.idSolicitud 
			AND cs.idTipoSolicitud	= s.idTipoSolicitud 
			AND cs.idClase			= s.idClase 
			AND cs.rfcEmpresa		= s.rfcEmpresa 
			AND cs.idCliente		= s.idCliente 
			AND cs.numeroContrato	= s.numeroContrato	
	WHERE	s.idSolicitud		=@idSolicitud
	AND		s.idTipoSolicitud	=@idTipoSolicitud
	AND		s.idClase			=@idClase
	AND		s.rfcEmpresa		=@rfcEmpresa
	AND		s.idCliente			=@idCliente
	AND		s.numeroContrato	=@numeroContrato

	SELECT	[Partida].[partida].getPropiedadPartida(scp.idPartida,'Partida','general') 'partida',
			scp.cantidad,
			ISNULL([Partida].[partida].getPropiedadPartida(scp.idPartida,'UnidadDeMedida','clase'),'VACIO') 'unidadDeMedida',
			ISNULL([Partida].[partida].getPropiedadPartida(scp.idPartida,'BienOServicio','clase') ,'VACIO') 'noUnicoProductoServicio',
			[Partida].[partida].getPropiedadPartida(scp.idPartida,'Descripción','general') 'descripcion',
			scp.venta 'precioUnitario',
			scp.venta * scp.cantidad 'importe'
	FROM	solicitud.SolicitudCotizacionPartida scp 
	WHERE	scp.idSolicitud		=@idSolicitud
	AND		scp.idTipoSolicitud	=@idTipoSolicitud
	AND		scp.idClase			=@idClase
	AND		scp.rfcEmpresa		=@rfcEmpresa
	AND		scp.idCliente		=@idCliente
	AND		scp.numeroContrato	=@numeroContrato

	SELECT	T1.subtotal							'subtotal',
			T1.subtotal * .16					'iva',
			T1.subtotal+(T1.subtotal * .16)		'total'
	FROM (	SELECT  SUM(scp.venta * cantidad)	'subtotal'
			FROM	solicitud.SolicitudCotizacionPartida scp 
			WHERE	scp.idSolicitud		=@idSolicitud
			AND		scp.idTipoSolicitud	=@idTipoSolicitud
			AND		scp.idClase			=@idClase
			AND		scp.rfcEmpresa		=@rfcEmpresa
			AND		scp.idCliente		=@idCliente
			AND		scp.numeroContrato	=@numeroContrato) T1


END
go

