--use solicitud
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <30/10/2020>
-- Description:	<Valida los usos maximos de cada partida>
/*
	EXEC [solicitud].[SEL_VALIDAUSO_PARTIDA_SP] 'ASE0508051B6',185,'43','Automovil',
	'<partidas>
		<partida>
			<idPartida>791944</idPartida>
			<cantidad>6</cantidad>
			<costoInicial>5000</costoInicial>
			<ventaInicial>6500</ventaInicial>
		</partida>
	</partidas>',6282,NULL

*/


-- =============================================
CREATE PROCEDURE [solicitud].[SEL_VALIDAUSO_PARTIDA_SP]
@rfcEmpresa				VARCHAR(13) = '',
@idCliente				INT = 0,
@numeroContrato			VARCHAR(50) = '',
@idClase				VARCHAR(10)	='',
@partidas				XML,
@idUsuario				INT = 0,
@err					VARCHAR(8000) OUTPUT
AS
BEGIN
	
	DECLARE @VT_TablePartidas		TABLE ([idPartida] INT,[cantidad] INT);
	DECLARE @VT_TablePartidasUso	TABLE ([Index] INT IDENTITY(1,1),[idPartida] INT,[cantidad] INT,[usoMax]INT);
	DECLARE @VT_TableTipos			TABLE (i INT IDENTITY(1,1),idTipoUso VARCHAR(15),prioridadValidacion INT)
	DECLARE @VT_TableSalida			TABLE (idPartida INT,idTipoUso VARCHAR(15),usoMax INT,valorCompara INT,valid bit,mensaje varchar(200),prioridadValidacion INT)

	INSERT INTO @VT_TablePartidas			SELECT I.N.value('(idPartida)[1]',	'INT') as idPartida,I.N.value('(cantidad)[1]',	'INT') as cantidad FROM	@partidas.nodes('/partidas/partida') I(N)
	INSERT INTO @VT_TableTipos(idTipoUso,prioridadValidacion)	SELECT idTipoUso,prioridadValidacion FROM Partida.partida.TipoUso WHERE idClase=@idClase ORDER BY prioridadValidacion ASC
	INSERT INTO @VT_TableSalida				SELECT	pa.idPartida,uso.idTipoUso,0,0,0,'',0 FROM	@VT_TablePartidas pa, @VT_TableTipos uso
		
	DECLARE @V_idTipoUso VARCHAR(15),@v_idPartida INT,@v_cantidad INT,@v_usoMax INT,@v_valorComparacion INT,@v_i INT,@v_index INT,@v_mensaje VARCHAR(200),@v_op VARCHAR(50),
			@v_partida VARCHAR(500),@v_mensajesSalida VARCHAR(MAX),@v_prioridadValidacion INT

	WHILE EXISTS(SELECT 1 FROM @VT_TableTipos)  
		BEGIN 
			SELECT TOP 1 @v_i=i,@V_idTipoUso=idTipoUso,@v_prioridadValidacion=prioridadValidacion FROM @VT_TableTipos ORDER BY i ASC
						
			INSERT INTO @VT_TablePartidasUso(idPartida,cantidad,usoMax)
			SELECT	pa.idPartida,pa.cantidad,
					ISNULL((SELECT usoMax FROM cliente.contrato.partidaUso uso 
							WHERE	pa.idPartida=uso.idPartida 
							AND		uso.rfcEmpresa		=@rfcEmpresa 
							AND		uso.idCliente		=@idCliente 
							AND		uso.numeroContrato	=@numeroContrato
							AND		uso.idClase			=@idClase
							AND     uso.idTipoUso		=usos.idTipoUso),0) as usoMax
			FROM	@VT_TablePartidas pa, @VT_TableTipos usos
			WHERE	usos.idTipoUso=@V_idTipoUso
			
			WHILE EXISTS(SELECT 1 FROM @VT_TablePartidasUso)
				BEGIN
					SELECT	TOP 1 @v_index=[Index],@v_idPartida=idPartida,@v_cantidad = cantidad,@v_usoMax=usoMax FROM @VT_TablePartidasUso 

					IF @V_idTipoUso='maxPorContrato' 
						BEGIN
							SELECT	@v_valorComparacion=ISNULL(SUM(cantidad),0)+@v_cantidad 
							FROM	solicitud.SolicitudCotizacionPartida scp
							INNER	JOIN solicitud.solicitud.solicitud sol ON scp.idSolicitud=sol.idSolicitud
							AND		scp.idTipoSolicitud	=sol.idTipoSolicitud
							AND		scp.idClase			=sol.idClase
							AND     scp.rfcEmpresa		=sol.rfcEmpresa
							AND     scp.idCliente		=sol.idCliente
							AND		scp.numeroContrato	=sol.numeroContrato
							WHERE	scp.rfcEmpresa = @rfcEmpresa AND scp.idCliente = @idCliente AND scp.numeroContrato = @numeroContrato
							AND     scp.idClase = @idClase AND scp.idEstatusCotizacionPartida='APROBADA' AND scp.idPartida = @v_idPartida
							AND     sol.idEstatusSolicitud NOT IN ('CANCELADA','RECHAZADA')
						END
					ELSE IF @V_idTipoUso='maxPorSolicitud'
						SET @v_valorComparacion=@v_cantidad

					IF @v_usoMax > 0
						BEGIN
							IF @v_usoMax >= @v_valorComparacion
								BEGIN
									UPDATE	@VT_TableSalida SET	valid=1,usoMax = @v_usoMax,valorCompara=@v_valorComparacion,mensaje='OK',prioridadValidacion=@v_prioridadValidacion
									WHERE	idPartida	=@v_idPartida AND idTipoUso	=@V_idTipoUso
								END
							ELSE
								BEGIN
									SET @v_op = CASE @V_idTipoUso  WHEN 'maxPorContrato' THEN 'contrato' WHEN 'maxPorSolicitud' THEN 'solicitud' ELSE '' END
									SET @v_partida=partida.partida.getPropiedadPartida(@v_idPartida,'Partida','general')+' ['+CAST(@v_idPartida AS VARCHAR)+'] '

									SET @v_mensaje='La partida '+ @v_partida + ' supera el uso máximo permitido por '+ @v_op + ' (uso máximo: '+CAST(@v_usoMax AS VARCHAR)+')'

									UPDATE	@VT_TableSalida SET	valid=1,usoMax=@v_usoMax,valorCompara=@v_valorComparacion,mensaje=@v_mensaje,prioridadValidacion=@v_prioridadValidacion
									WHERE	idPartida	=@v_idPartida AND idTipoUso	=@V_idTipoUso
								END
						END
					ELSE
						BEGIN
							UPDATE	@VT_TableSalida SET	valid=1,usoMax=@v_usoMax,valorCompara=@v_valorComparacion,mensaje='OK',prioridadValidacion=@v_prioridadValidacion
							WHERE	idPartida	=@v_idPartida AND idTipoUso	=@V_idTipoUso
						END
					DELETE FROM @VT_TablePartidasUso  WHERE [index]=@v_index
				END
			DELETE FROM @VT_TableTipos WHERE i=@v_i
		END
	
	SET @v_mensajesSalida=ISNULL(STUFF((SELECT ',  ' + mensaje.mensaje FROM @VT_TableSalida mensaje  WHERE mensaje<>'OK' AND prioridadValidacion=1 FOR XML PATH('')),1, 2, ''),'') 
	IF @v_mensajesSalida=''
		BEGIN
			SET @v_mensajesSalida=ISNULL(STUFF((SELECT ',  ' + mensaje.mensaje FROM @VT_TableSalida mensaje  WHERE mensaje<>'OK' AND prioridadValidacion=2 FOR XML PATH('')),1, 2, ''),'')
		END
	SELECT @v_mensajesSalida As mensajes
	SELECT * FROM @VT_TableSalida ORDER BY 1,2 ASC

END
go

