-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2020>
-- Description:	    <Obtener la lista de ordenes por idsolicitud>
-- =============================================
-- EXEC [solicitud].[SEL_SOLICITUDES_MULTI_SP] 1138, 2
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_SOLICITUDES_MULTI_SP]
(
    @idSolicitud        int
	,@idUsuario			int
	,@err				NVARCHAR(100) = '' OUTPUT
)
AS
BEGIN

SELECT
        SSZV.[idSolicitud]
        ,SSZV.[idTipoSolicitud]
        ,SSZV.[idClase]
        ,SSZV.[rfcEmpresa]
        ,SSZV.[idCliente]
        ,SSZV.[numeroContrato]
		,SSZV.[numero]
        ,SSZV.[idContratoZona]
        ,SSZV.[idContratoNivel]
        ,SSZV.[zona]
        ,SSZV.[numeroOrden]
        ,SSZV.[idObjeto]
        ,SSZV.[idTipoObjeto]
        ,STS.[nombre] tipoSolicitud
        ,'paso' tipoPaso
        ,FSEP.idPaso
        ,FSEP.idFase
		,SOPCV.[VIN]
    FROM [Solicitud].[solicitud].[SEL_SOLICITUD_ZONA_VW] SSZV
    INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON SSZV.[idTipoSolicitud] = STS.[idTipoSolicitud]
            AND SSZV.[idClase] = STS.[idClase]
    INNER JOIN [Solicitud].[fase].[SolicitudEstatusPaso] FSEP
        ON FSEP.[idSolicitud] = SSZV.[idSolicitud]
            AND FSEP.[idClase]  = SSZV.[idClase]
            AND FSEP.[rfcEmpresa] = SSZV.[rfcEmpresa]
            AND FSEP.[idCliente] = SSZV.[idCliente]
            AND FSEP.[numeroContrato] = SSZV.[numeroContrato]
            AND FSEP.[idTipoSolicitud] = SSZV.[idTipoSolicitud]
	INNER JOIN [Objeto].[objeto].[SEL_OBJETOS_PROPIEDAD_CLASE_VW] SOPCV
		ON SOPCV.[idObjeto] = SSZV.[idObjeto]
		AND SOPCV.[idClase] = SSZV.[idClase]
		AND SOPCV.[idTipoObjeto] = SSZV.[idTipoObjeto]
    WHERE SSZV.[idEstatusSolicitud] = 'ACTIVA'			 -- SOLO ORDENES ACTIVAS
        AND FSEP.[fechaSalida] IS NULL
		AND SSZV.[multiple] > 1
		AND SSZV.[idSolicitud] = @idSolicitud
        AND FSEP.[idEstatus] = 1

    UNION

    SELECT
        SSZV.[idSolicitud]
        ,SSZV.[idTipoSolicitud]
        ,SSZV.[idClase]
        ,SSZV.[rfcEmpresa]
        ,SSZV.[idCliente]
        ,SSZV.[numeroContrato]
		,SSZV.[numero]
        ,SSZV.[idContratoZona]
        ,SSZV.[idContratoNivel]
        ,SSZV.[zona]
        ,SSZV.[numeroOrden]
        ,SSZV.[idObjeto]
        ,SSZV.[idTipoObjeto]
        ,STS.[nombre] tipoSolicitud
        ,'contrato' tipoPaso
        ,FCSEP.idPaso
        ,FCSEP.idFase
		,SOPCV.[VIN]
    FROM [Solicitud].[solicitud].[SEL_SOLICITUD_ZONA_VW] SSZV
    INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON SSZV.[idTipoSolicitud] = STS.[idTipoSolicitud]
            AND SSZV.[idClase] = STS.[idClase]
    INNER JOIN [Solicitud].[faseContrato].[SolicitudEstatusPaso] FCSEP
        ON FCSEP.[idSolicitud] = SSZV.[idSolicitud]
            AND FCSEP.[idClase]  = SSZV.[idClase]
            AND FCSEP.[rfcEmpresa] = SSZV.[rfcEmpresa]
            AND FCSEP.[idCliente] = SSZV.[idCliente]
            AND FCSEP.[numeroContrato] = SSZV.[numeroContrato]
            AND FCSEP.[idTipoSolicitud] = SSZV.[idTipoSolicitud]
	INNER JOIN [Objeto].[objeto].[SEL_OBJETOS_PROPIEDAD_CLASE_VW] SOPCV
		ON SOPCV.[idObjeto] = SSZV.[idObjeto]
		AND SOPCV.[idClase] = SSZV.[idClase]
		AND SOPCV.[idTipoObjeto] = SSZV.[idTipoObjeto]
    WHERE SSZV.[idEstatusSolicitud] = 'ACTIVA' -- SOLO ORDENES ACTIVAS
        AND FCSEP.[fechaSalida] IS NULL
		AND SSZV.[idSolicitud] = @idSolicitud
		AND SSZV.[multiple] > 1
        AND FCSEP.[idEstatus] = 1
        
END
go

