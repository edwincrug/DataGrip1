
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 29-05-2019
-- Description: Consulta trae agrupadores de tipo de objeto
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[SEL_COSTOSAGRUPADOR_SP]  'Automovil', @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[SEL_COSTOSAGRUPADOR_SP] 
	@idClase				varchar(10),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	SELECT 
	CA.idCostoAgrupador,
	CA.nombre,
	(SELECT COUNT(*) 
		from gestoria.CostoAgrupadorDetalle CAD 
		INNER JOIN partida.tipoobjeto.tipoObjeto TOB ON TOB.idTipoObjeto = CAD.idTipoObjeto
		WHERE TOB.activo = 1 
		and idClase = @idClase
		and idCostoAgrupador = CA.idCostoAgrupador) AS total
	FROM gestoria.CostoAgrupador CA
	WHERE CA.activo = 1


	
END
go

