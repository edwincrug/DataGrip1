--
-- =============================================    
-- Author:  José Etmanuel    
-- Create date: 11/04/2019    
-- Description: Resolver el valor de una propiedad dinamica de un objeto     
-- =============================================    
/*    
 ------ Versionamiento    
 Fecha			Autor      Descrición    
 22/05/2019		Alan Rosales Chávez   Cuando se busca en la documentacion del objeto, cuando no tienen valor, se devuelvo el id del documento   
 25/07/2017		José Etmanuel Agregando le cast a la corrección anterior

     
 *- Testing...    
    select [objeto].[getPropiedadObjeto]  (250, 'Foto Frente', 'documentoClaseFile','Automovil')
*/    
create FUNCTION [solicitud].[getPropiedadSolicitud]    
 (    
  @idSolicitud int
  ,@propiedad varchar(max)
  ,@tipoPropiedad varchar(20)
  ,@idClase varchar(20)
)    
RETURNS varchar(500)    
AS    
BEGIN    
	DECLARE @result varchar(500)
	DECLARE @ApValor BIT, @idDocumento INT
	--- Buscando en las propiedades de los objetos  
	
	IF @tipoPropiedad  = 'clase'    
		BEGIN    
			SET @result =(	SELECT	CASE WHEN idTipoValor = 'Unico' THEN  Opc.valor    
									ELSE    
										CASE	WHEN  PC.valor = @propiedad THEN  	''  
										ELSE	 PC.valor    
										END  
									END as valor    
							FROM	[Solicitud].[solicitud].[SolicitudPropiedadClase] Opc    
							INNER	JOIN  [Solicitud].[Solicitud].[PropiedadClase] PC ON PC.idPropiedadClase = opc.idPropiedadClase    
							WHERE	idSolicitud = @idSolicitud AND agrupador = @propiedad AND Opc.idClase = @idClase  
							);    
	END    
	
	
    
 
    
  RETURN @result    
    
END

go

