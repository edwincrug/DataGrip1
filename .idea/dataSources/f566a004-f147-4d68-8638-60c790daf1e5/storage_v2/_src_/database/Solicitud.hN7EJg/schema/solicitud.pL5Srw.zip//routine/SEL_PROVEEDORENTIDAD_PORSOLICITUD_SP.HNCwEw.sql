-- =============================================
-- Author: Jose Luis Lozada Guerrero
-- Create date: 08/07/2019
-- Description: Consulta dinámica recursiva para obtener las propiedades de la entidad proveedor
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	*- Testing...

	declare @err VARCHAR(8000)
	EXEC [SOLICITUD].[SEL_PROVEEDORENTIDAD_PORSOLICITUD_SP] 922,'Imagen','Automovil','ASE0508051B6',185,'43',NULL,2,''
	EXEC [SOLICITUD].[SEL_PROVEEDORENTIDAD_PORSOLICITUD_SP] 922,'Servicio','Automovil','ASE0508051B6',219,'128','152-1122-12980',2,''    @err output
	print @err

	*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_PROVEEDORENTIDAD_PORSOLICITUD_SP] 
	@idSolicitud		INT,
	@idTipoSolicitud	VARCHAR(10),
	@idClase			VARCHAR(10),
	@rfcEmpresa			VARCHAR(13),
	@idCliente			INT,
	@numeroContrato		VARCHAR(50),
	@numeroOrden		varchar(30) = NULL, 
	@idUsuario			INT = NULL,
	@err			varchar(500) = '' OUTPUT
AS
BEGIN
	DECLARE 
		@rfcProveedor	varchar(13),
		@idProveedorEntidad	int


	create table #proveedores(
		rfcProveedor	varchar(13),
		idProveedorEntidad	int
	)

	insert into #proveedores
	SELECT	DISTINCT
		SC.rfcProveedor,
		SC.idProveedorEntidad
	FROM	solicitud.solicitudCotizacion SC
		JOIN [solicitud].[SolicitudObjeto] SO ON SO.idSolicitud = SC.idSolicitud
		JOIN [solicitud].[SolicitudCotizacionPartida] SCP ON SCP.idCotizacion = SC.idCotizacion AND SCP.idSolicitud = SC.idSolicitud AND SO.idObjeto = SCP.idObjeto AND SO.idTipoObjeto = SCP.idTipoObjeto
	WHERE	SC.idSolicitud		=@idSolicitud
	AND     SC.idTipoSolicitud	=@idTipoSolicitud
	AND		SC.idClase			=@idClase
	AND		SC.rfcEmpresa		=@rfcEmpresa
	AND		SC.idCliente		=@idCliente
	AND		SC.numeroContrato	=@numeroContrato
	AND SO.[numeroOrden] = COALESCE(@numeroOrden, SO.numeroorden)

	--creamos tabla temporal para insertar las propiedades del tipo objeto dependiendo del tipo de valor
	create table #propiedades(
	idProveedorEntidad		int,
	agrupador			varchar(500),
	valor				varchar(MAX)
	)

/**********************************************************************************************************************
******************************************************CATALOGOS Y AGRUPADORES******************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with catalogos as(
	select	
		pe.idProveedorEntidad				idProveedorEntidad,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre
	from 
	proveedor.proveedor.ProveedorEntidad pe
	inner join proveedor.proveedor.ProveedorEntidadPropiedadGeneral tpg on pe.idProveedorEntidad = tpg.idProveedorEntidad
	inner join proveedor.proveedor.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
	inner join integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	inner join #proveedores aux on aux.rfcProveedor = pe.rfcProveedor and aux.idProveedorEntidad = pe.idProveedorEntidad
	where 
		prg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		/*and pe.rfcProveedor = @rfcProveedor
		and pe.idProveedorEntidad = @idProveedorEntidad*/
		and pe.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idProveedorEntidad				idProveedorEntidad,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre
	from proveedor.proveedor.PropiedadGeneral prg 
	inner join integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	inner join catalogos cat on cat.idPadre = prg.idPropiedadGeneral
	and prg.activo = 1
	)
	insert into #propiedades
	select 
		cat.idProveedorEntidad,
		cat.agrupador,
		cat.valor
	from catalogos cat 
	where 
		cat.idPadre is not null

--PROPIEDADES DE CLASE
;with catalogos as(
	select
		pe.idProveedorEntidad				idProveedorEntidad,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre
	from 
	proveedor.proveedor.ProveedorEntidad pe
	inner join proveedor.proveedor.ProveedorEntidadPropiedadClase tpc on pe.idProveedorEntidad = tpc.idProveedorEntidad
	inner join proveedor.proveedor.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
	inner join #proveedores aux on aux.rfcProveedor = pe.rfcProveedor and aux.idProveedorEntidad = pe.idProveedorEntidad
	where 
		prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		/*and pe.rfcProveedor = @rfcProveedor
		and pe.idProveedorEntidad = @idProveedorEntidad*/
		and pe.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idProveedorEntidad				idProveedorEntidad,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre
	from proveedor.proveedor.PropiedadClase prc 
	inner join catalogos cat on cat.idPadre = prc.idPropiedadClase 
	WHERE prc.activo = 1
	)
	insert into #propiedades
	select 
		cat.idProveedorEntidad,
		cat.agrupador,
		cat.valor
	from catalogos cat 
	where 
		cat.idPadre is not null

	
/**********************************************************************************************************************
*********************************************************TAGS**********************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with tags as(
	select	
		pe.idProveedorEntidad				idProveedorEntidad,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prg.valor,'')			valor,
		prg.idPadre						idPadre
	from proveedor.proveedor.ProveedorEntidad pe
	inner join proveedor.proveedor.ProveedorEntidadPropiedadGeneral tpg on pe.idProveedorEntidad = tpg.idProveedorEntidad
	inner join proveedor.proveedor.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
	inner join #proveedores aux on aux.rfcProveedor = pe.rfcProveedor and aux.idProveedorEntidad = pe.idProveedorEntidad
	where prg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	/*and pe.rfcProveedor = @rfcProveedor
	and pe.idProveedorEntidad = @idProveedorEntidad*/
	and pe.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idProveedorEntidad				idProveedorEntidad,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prg.valor,'')			valor,
		prg.idPadre						idPadre
	from proveedor.proveedor.PropiedadGeneral prg 
	inner join tags tag on tag.idPadre = prg.idPropiedadGeneral
	WHERE prg.activo = 1
	)
	insert into #propiedades
	select distinct 
		idProveedorEntidad,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idProveedorEntidad = tags. idProveedorEntidad and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor from tags


--PROPIEDADES CLASE
;with tags as(
	select	
		pe.idProveedorEntidad				idProveedorEntidad,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre
	from proveedor.proveedor.ProveedorEntidad pe
	inner join proveedor.proveedor.ProveedorEntidadPropiedadClase tpc on pe.idProveedorEntidad = tpc.idProveedorEntidad
	inner join proveedor.proveedor.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
	inner join #proveedores aux on aux.rfcProveedor = pe.rfcProveedor and aux.idProveedorEntidad = pe.idProveedorEntidad
	where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	/*and pe.rfcProveedor = @rfcProveedor
	and pe.idProveedorEntidad = @idProveedorEntidad*/
	and pe.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idProveedorEntidad				idProveedorEntidad,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre
	from proveedor.proveedor.PropiedadClase prc 
	inner join tags tag on tag.idPadre = prc.idPropiedadClase
	and prc.activo = 1
	)
	insert into #propiedades
	select distinct 
		idProveedorEntidad,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idProveedorEntidad = tags.idProveedorEntidad and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor from tags

/**********************************************************************************************************************
***************************************************VALORES FIJOS*******************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
INSERT INTO #propiedades
select 
	pto.idProveedorEntidad		idProveedorEntidad,
	prg.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	tpg.valor				valor
from proveedor.proveedor.ProveedorEntidad pto 
inner join proveedor.proveedor.ProveedorEntidadPropiedadGeneral tpg on tpg.idProveedorEntidad = pto.idProveedorEntidad
inner join proveedor.proveedor.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
inner join #proveedores aux on aux.rfcProveedor = pto.rfcProveedor and aux.idProveedorEntidad = pto.idProveedorEntidad
where
	prg.idTipoValor = 'Unico'
	/*and pto.rfcProveedor = @rfcProveedor
	and pto.idProveedorEntidad = @idProveedorEntidad*/
	and pto.activo = 1

--PROPIEDADES DE CLASE
INSERT INTO #propiedades
select 
	pto.idProveedorEntidad				idProveedorEntidad,
	prc.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	tpc.valor				valor
from proveedor.proveedor.ProveedorEntidad pto 
inner join proveedor.proveedor.ProveedorEntidadPropiedadClase tpc on tpc.idProveedorEntidad = pto.idProveedorEntidad
inner join proveedor.proveedor.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
inner join #proveedores aux on aux.rfcProveedor = pto.rfcProveedor and aux.idProveedorEntidad = pto.idProveedorEntidad
where
	prc.idTipoValor = 'Unico'
	/*and pto.rfcProveedor = @rfcProveedor
	and pto.idProveedorEntidad=@idProveedorEntidad*/
	and pto.activo = 1



/**********************************************************************************************************************
******************************************************PIVOTE***********************************************************
**********************************************************************************************************************/
declare 
	@columnsName varchar(max) = ''

SET @columnsName = STUFF((SELECT distinct ',' + QUOTENAME(prg.agrupador) FROM #propiedades prg FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')

declare @query varchar(max)
set @query = '
	select
		pe.rfcProveedor,
		pe.nombreComercial,
		pe.personaContacto,
		pe.telefono,
		pe.email,
		pe.fechaModificacion
		,pe.[idPais]
		  ,pe.[idEstado]
		  ,pe.[idMunicipio]
		  ,pe.[codigoPostal]
		  ,pe.[idTipoAsentamiento]
		  ,pe.[asentamiento]
		  ,pe.[idTipoVialidad]
		  ,pe.[vialidad]
		  ,pe.[numeroExterior]
		  ,pe.[numeroInterior]
		  ,pe.[lat]
		  ,pe.[lon]  as lng
		  ,est.nombre estado
		  ,mun.nombre municipio
		,resultado.*
	from
	(select idProveedorEntidad, agrupador, valor from #propiedades) t
	pivot
	(	
		max(valor)
		for agrupador in (' + @columnsName + ')
	) AS resultado 
	inner join proveedor.proveedor.ProveedorEntidad pe on resultado.idProveedorEntidad = pe.idProveedorEntidad
	inner join Common.direccion.Estado est on (est.idPais = pe.idPais and est.idEstado = pe.idEstado)
	inner join Common.direccion.Municipio mun on (mun.idPais = pe.idPais and mun.idEstado = pe.idEstado and mun.idMunicipio = pe.idMunicipio)'

	print @query

execute (@query)

SELECT geolocalizacion FROM Cliente.cliente.Contrato WHERE rfcEmpresa = @rfcEmpresa AND idCliente = @idCliente AND numeroContrato = @numeroContrato

drop table #propiedades
end


--USE [Solicitud]
go

