--use solicitud
-- =============================================
-- Author:		JLLOZADA
-- Create date: 23/07/2019
-- Description:	Hace insercion a tablas de bpro.
-- ============== Versionamiento ================  
/*  
 Fecha			Autor		Descripción   
 18/08/2020		ADOLFO		Se modifica el stored para que pueda soportar el poder procesar compra de solicitudes de ingreso.

*- Testing...  
DECLARE @err VARCHAR(8000)=''
EXEC [cxc].[INS_FACTURA_PROCESACOMPRA_INGRESO_SP] 1081,'CompraGPS','Automovil','AAN910409135',218,'0001',2927,''
SELECT @err

SELECT * FROM [Inventario].[tipoinventario].[TipoInventario] WHERE idCategoria='ACCESORIO'
SELECT * FROM [Inventario].[inventario].[Inventario] WHERE idCategoria='ACCESORIO'
SELECT * FROM [Inventario].[inventario].[Movimiento] WHERE idCategoria='ACCESORIO'
SELECT * FROM [Inventario].[inventario].[PropiedadCategoria] WHERE idCategoria='ACCESORIO'
SELECT * FROM [Inventario].[inventario].[InventarioPropiedadCategoria] WHERE idCategoria='ACCESORIO'
SELECT * FROM [Inventario].[tipoinventario].[TipoInventarioPropiedadCategoria] WHERE idCategoria='ACCESORIO'
*/
-- =============================================
CREATE PROCEDURE [cxc].[INS_FACTURA_PROCESACOMPRA_INGRESO_SP]
@idSolicitud		INT,
@idTipoSolicitud	VARCHAR(10),
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@idUsuario			INT,
@err				VARCHAR(8000) = '' OUTPUT	
AS
BEGIN
	BEGIN TRY

DECLARE @agrupaDatos	 TABLE(id INT IDENTITY(1,1), valor VARCHAR(200), existencia INT)
DECLARE @maestroDatos	 TABLE(id INT IDENTITY(1,1), valor VARCHAR(200), idInventario INT)
DECLARE @v_idd INT, @v_idInventario INT, @v_valor VARCHAR(200), @v_existencia INT, @v_Inventario INT, @v_existenciaReal INT

DECLARE @referencia VARCHAR(50) = NEWID(), @idTipoMovimiento VARCHAR(20) = (SELECT idTipoMovimiento FROM [Inventario].[inventario].[TipoMovimiento] WHERE idTipoMovimiento='compra')
DECLARE @orden VARCHAR(50) = (SELECT S.numeroOrden FROM [solicitud].[Solicitud].[SolicitudObjeto] S
							  WHERE S.idSolicitud=@idSolicitud AND
									S.idTipoSolicitud=@idTipoSolicitud AND
									S.idClase=@idClase AND
									S.rfcEmpresa=@rfcEmpresa AND
									S.idCliente=@idCliente AND
									S.numeroContrato=@numeroContrato)


	IF NOT EXISTS(SELECT 1
	FROM [Solicitud].[solicitud].[SolicitudPropiedadInventarioGeneral] G
		JOIN [Solicitud].[solicitud].[PropiedadInventarioGeneral] P ON P.idPropiedadInventarioGeneral = G.idPropiedadInventarioGeneral
		LEFT JOIN [Inventario].[tipoinventario].[TipoInventario] TI ON TI.idTipoInventario = G.valor
	WHERE 
		G.idSolicitud=@idSolicitud AND TI.idTipoInventario IS NULL AND
		P.valor = 'NoParte')
		BEGIN
			IF EXISTS(SELECT idCategoria FROM [solicitud].[TipoSolicitudCategoria] WHERE idTipoSolicitud=@idTipoSolicitud)
				BEGIN
					DECLARE @idCategoria VARCHAR(20) = (SELECT idCategoria FROM [solicitud].[TipoSolicitudCategoria] WHERE idTipoSolicitud=@idTipoSolicitud)
					PRINT 'P 1'
						INSERT INTO @agrupaDatos(valor,existencia)
						SELECT G.valor, COUNT(G.valor)
						FROM [Solicitud].[solicitud].[SolicitudPropiedadInventarioGeneral] G
							JOIN [Solicitud].[solicitud].[PropiedadInventarioGeneral] P ON P.idPropiedadInventarioGeneral = G.idPropiedadInventarioGeneral
						WHERE 
							G.idSolicitud=@idSolicitud AND
							G.idTipoSolicitud=@idTipoSolicitud AND
							G.idClase=@idClase AND
							G.rfcEmpresa=@rfcEmpresa AND
							G.idCliente=@idCliente AND
							G.numeroContrato=@numeroContrato AND
							P.valor = 'NoParte'
						GROUP BY G.valor
					PRINT 'P 2'
						WHILE EXISTS (SELECT 1 FROM @agrupaDatos)
							BEGIN
								SELECT TOP 1 @v_idd=id,@v_valor=valor,@v_existencia=existencia FROM @agrupaDatos
									PRINT 'P 3'
									--VALIDAR QUE YA EXISTE AUMENTAR EXISTENCIA
									IF EXISTS(SELECT 1 FROM [Inventario].[tipoinventario].[TipoInventario] WHERE idTipoInventario=@v_valor)
										BEGIN
											PRINT 'P 4'
											PRINT 'P 5'
											DECLARE @v_existenciaActual INT = (SELECT existencia FROM [Inventario].[tipoinventario].[TipoInventario] WHERE idTipoInventario=@v_valor)

											UPDATE [Inventario].[tipoinventario].[TipoInventario]
											SET existencia = @v_existenciaActual + @v_existencia
											WHERE idTipoInventario=@v_valor

											--INSERT INTO [Inventario].[tipoinventario].[TipoInventario](idTipoInventario,idCategoria,existencia,fechaAlta,activo,idUsuario)
											--VALUES (@v_valor,@idCategoria,@v_existencia,GETDATE(), 1, @idUsuario)

										END

										PRINT 'P 6'

									INSERT [Inventario].[inventario].[Movimiento](idTipoInventario,idCategoria,idTipoMovimiento,entrada,salida,fechaMovimiento,referencia,observaciones,idUsuario)
									VALUES(@v_valor,@idCategoria,@idTipoMovimiento,@v_existencia,0,GETDATE(),@referencia,@orden,@idUsuario)

								DELETE FROM @agrupaDatos WHERE ID=@v_idd
							END
					PRINT 'P 7'
						INSERT INTO @maestroDatos(valor,idInventario)
						SELECT G.valor,G.idInventario
						FROM [Solicitud].[solicitud].[SolicitudPropiedadInventarioGeneral] G
							JOIN [Solicitud].[solicitud].[PropiedadInventarioGeneral] P ON P.idPropiedadInventarioGeneral = G.idPropiedadInventarioGeneral
						WHERE 
							G.idSolicitud=@idSolicitud AND
							G.idTipoSolicitud=@idTipoSolicitud AND
							G.idClase=@idClase AND
							G.rfcEmpresa=@rfcEmpresa AND
							G.idCliente=@idCliente AND
							G.numeroContrato=@numeroContrato AND
							P.valor = 'NoParte'

						WHILE EXISTS  (SELECT 1 FROM @maestroDatos)
							BEGIN
								SELECT TOP 1 @v_idd=id,@v_valor=valor,@v_Inventario=idInventario FROM @maestroDatos
				
									INSERT [Inventario].[inventario].[Inventario](idTipoInventario,idCategoria,fechaAlta,disponible,activo,idUsuario)
									VALUES(@v_valor,@idCategoria,GETDATE(),1,1,@idUsuario)

									SET @v_idInventario=@@IDENTITY

									--SE LLAMEN IGUAL agrupador
									INSERT [Inventario].[inventario].[InventarioPropiedadCategoria](idInventario,idTipoInventario,idCategoria,idPropiedadCategoria,valor,fechaCaducidad,idUsuario)
									SELECT @v_idInventario,@v_valor,@idCategoria,PC.idPropiedadCategoria,T.valor,GETDATE(),@idUsuario 
									FROM [Solicitud].[solicitud].[SolicitudPropiedadInventarioTipoSolicitud] T
									JOIN [solicitud].[solicitud].[PropiedadInventarioTipoSolicitud] P ON P.idPropiedadInventarioTipoSolicitud = T.idPropiedadInventarioTipoSolicitud
									JOIN [Inventario].[inventario].[PropiedadCategoria] PC ON PC.idCategoria=@idCategoria AND PC.agrupador = P.agrupador
									WHERE T.idSolicitud=@idSolicitud AND
										T.idTipoSolicitud=@idTipoSolicitud AND
										T.idClase=@idClase AND
										T.rfcEmpresa=@rfcEmpresa AND
										T.idCliente=@idCliente AND
										T.numeroContrato=@numeroContrato AND
										T.idInventario =@v_Inventario --AND
										--T.valor NOT IN(SELECT valor FROM [Inventario].[inventario].[InventarioPropiedadCategoria] IP
										--				WHERE idCategoria=@idCategoria)

								DELETE FROM @maestroDatos WHERE ID=@v_idd
							END

						EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,'PrefacturaGenerada','Cobranza',@idUsuario,''

					SELECT 'Se completo corrreactamente el proceso.' msg, 1 estatus
				END
			ELSE
				BEGIN
					SET @err = 'La solicitud no tiene categoria configurada.'
				END
		END
	ELSE
		BEGIN
			SET @err = 'El tipo de inventario esta incompleto.'
		END

	END TRY
	BEGIN CATCH
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al insertar en BPRO'
	END CATCH
END


--USE [Solicitud]
go

