-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Obtener cotizaciones por solicitud>
-- =============================================
-- EXEC [solicitud].[SEL_COTIZACION_POR_SOLICITUD_SP] 1138, 13878,2
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_COTIZACION_POR_SOLICITUD_SP]
(
    @idSolicitud        int
	,@idObjeto			int
	,@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS

BEGIN

    SELECT
        ECF.[idCotizacion]
        ,ECF.[idSolicitud]
        ,ECF.[idTipoSolicitud]
        ,ECF.[idClase]
        ,ECF.[rfcEmpresa]
        ,ECF.[idCliente]
        ,ECF.[numeroContrato]
        ,ECF.[idProveedorEntidad]
        ,ECF.[rfcProveedor]
        ,ECF.[numeroCotizacion]
        ,COALESCE(ECF.[totalPartidasAprobadas], 0) + COALESCE(ECF.[totalPartidasEnEspera], 0) totalPartidas
        ,ECF.[estatusCotizacion]
        ,ECF.[estatusCotizacionNombre]
        ,PDV.[nombreComercial]
        ,PDV.[personaContacto]
        ,PDV.[telefono]
        ,PDV.[email]
        ,PDV.[lat]
        ,PDV.[lon] lng
        ,PDV.[direccion]
        ,TCV.[subTotalCosto]
        ,TCV.[IVACosto]
        ,TCV.[totalCosto]
        ,TCV.[subTotalVenta]
        ,TCV.[IVAVenta]
        ,TCV.[totalVenta]
        ,PPEPG.[valor] idImagen
    FROM [solicitud].[SEL_ESTATUS_COTIZACIONES_BY_SOLICITUD_FN](@idSolicitud, @idObjeto) ECF
    INNER JOIN [proveedor].[proveedor].[SEL_PROVEEDOR_DIRECCION_VW] PDV
        ON ECF.[idProveedorEntidad] = PDV.[idProveedorEntidad]
        AND ECF.[rfcProveedor] = PDV.[rfcProveedor]
    LEFT JOIN [Proveedor].[proveedor].[ProveedorEntidadPropiedadGeneral] PPEPG
        ON PPEPG.[idProveedorEntidad] = ECF.[idProveedorEntidad]
		AND PPEPG.[rfcProveedor] = ECF.[rfcProveedor]
		AND PPEPG.[idPropiedadGeneral] = 5
    INNER JOIN [solicitud].[SEL_TOTALES_COTIZACION_VW] TCV
        ON ECF.[idSolicitud] = TCV.[idSolicitud]
        AND ECF.[idCotizacion] = TCV.[idCotizacion]
    WHERE TCV.[idSolicitud] = @idSolicitud
        AND ECF.[estatusCotizacion] IN ('ENESPERA','APROBADA')
        --AND ECF.[estatusCotizacion] NOT IN ('CANCELADA','RECHAZADA')

END
go

