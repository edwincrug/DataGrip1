-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<30/09/2019>
-- Description:	    <Obtener la informacion de la solicitud por numero de cotización>
-- =============================================
-- EXEC [solicitud].[SEL_ORDEN_NO_COTIZACION_SP] '1-1184-250-1', 'Automovil', 'ASE0508051B6', 92, '0001', 2
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_ORDEN_NO_COTIZACION_SP]
(
    @numeroCotizacion           [VARCHAR](20)
    ,@idClase                   [VARCHAR](10)
    ,@rfcEmpresa                [VARCHAR](13)
    ,@idCliente                 [INT]
    ,@numeroContrato            [VARCHAR](50)
    ,@idUsuario			        [INT]
	,@err				        [NVARCHAR](500) = '' OUTPUT
)
AS

BEGIN

    SELECT 
        [idCotizacion]
        ,[idSolicitud]
        ,[idTipoSolicitud]
    FROM [Solicitud].[solicitud].[SolicitudCotizacion]
    WHERE [numeroCotizacion] = @numeroCotizacion
        AND [estatusFinalizada] IS NULL
        AND idClase = @idClase
        AND rfcEmpresa = @rfcEmpresa
        AND idCliente = @idCliente
        AND numeroContrato = @numeroContrato

END
go

