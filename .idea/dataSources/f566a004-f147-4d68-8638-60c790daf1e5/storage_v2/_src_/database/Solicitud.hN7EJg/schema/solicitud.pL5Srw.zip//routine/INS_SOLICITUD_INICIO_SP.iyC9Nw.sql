-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Agregar nueva solicitud en el paso de nueva con taller>
-- =============================================
-- EXEC [solicitud].[INS_SOLICITUD_INICIO_SP] 'ASE0508051B6', 92, '0001', 237, 100, 'Automovil', 'Servicio', '20180917', '<partidas><partida><idPartida>32068</idPartida><cantidad>1</cantidad><costo>50</costo><venta>55</venta></partida></partidas>',NULL, 2, 147, 'DAC960820HV8', 6077
-- =============================================
CREATE PROCEDURE [solicitud].[INS_SOLICITUD_INICIO_SP]
(
    @rfcEmpresa				VARCHAR(13)
	,@idCliente				INT
	,@numeroContrato		VARCHAR(10)
    ,@idObjeto				INT
	,@idTipoObjeto			INT
    ,@idClase				VARCHAR(10)
    ,@idTipoSolicitud		VARCHAR(20)
	,@fecha					DATETIME
	,@partidas				XML
	,@comentarios			VARCHAR(250) = ''
    ,@idPropiedadClase      INT = 2
    ,@idProveedorEntidad    INT
    ,@rfcProveedor          VARCHAR(13)
	,@idUsuario			    INT
	,@err				    NVARCHAR(500) = '' OUTPUT
)
AS
DECLARE 
    @numeroSolicitud        VARCHAR(20)=NULL
    ,@contratoExiste        INT=0
    ,@idCentroCosto         INT=0
    ,@folio                 VARCHAR(20)=NULL
    ,@consecutivo           INT=0
    ,@idSolicitud           INT=0
    ,@idPaso                VARCHAR(10)
    ,@idFase                VARCHAR(10)
BEGIN

    SELECT 
        @contratoExiste = COUNT([idCliente]) 
    FROM [Cliente].[cliente].[Contrato] CC
    WHERE [activo] = 1
        AND [rfcEmpresa] = @rfcEmpresa
        AND [idCliente] = @idCliente
        AND [numeroContrato] = @numeroContrato
        AND [idClase] = @idClase
        AND [fechaFin] > GETDATE()

    SELECT 
        @idCentroCosto = [idCentroCosto]
    FROM [Cliente].[contrato].[CentroCosto]
    WHERE [rfcEmpresa] = @rfcEmpresa
        AND [idCliente] = @idCliente
        AND [numeroContrato] = @numeroContrato
        AND [activo] = 1

    SELECT
        @folio = [folio]
    FROM [Cliente].[contrato].[CentroCostoFolio]
    WHERE [rfcEmpresa] = @rfcEmpresa
        AND [idCliente] = @idCliente
        AND [numeroContrato] = @numeroContrato
        AND [idCentroCosto] = @idCentroCosto
        AND [fechaFin] > GETDATE()
        AND [idEstatusCentroCostoFolio] = 'ACTIVO'
        AND [activo] = 1

    SELECT 
        @consecutivo = CAST([consecutivo] AS INT) + 1
    FROM [solicitud].[ContratoConsecutivo]
    WHERE [rfcEmpresa] = @rfcEmpresa 
        AND [idCliente] = @idCliente
        AND [numeroContrato] = @numeroContrato

    SELECT 
        TOP(1) @idPaso = [idPaso]
    FROM [Solicitud].[fase].[Paso]
    WHERE idFase = 'Solicitud'
        AND idClase = 'Automovil'
        AND idTipoSolicitud = 'Servicio'
    ORDER BY orden

    IF(@contratoExiste > 0)
    BEGIN
        SELECT @numeroSolicitud = [solicitud].[SEL_NUMEROSOLICITUD_FN](
            @rfcEmpresa
            , @idCliente
            , @numeroContrato)

        DECLARE @partidaVT as TABLE(
            [idPartida]         INT
            , [cantidad]        INT
            , [costo]           DECIMAL
            , [venta]           DECIMAL);

        INSERT INTO @partidaVT(
            idPartida
            , cantidad
            , costo
            , venta) 
            SELECT 
                partidaParametro.C.value('idPartida[1]', 'INT')
                , partidaParametro.C.value('cantidad[1]', 'INT')
                , partidaParametro.C.value('costo[1]', 'DECIMAL')
                , partidaParametro.C.value('venta[1]', 'DECIMAL')
                FROM @partidas.nodes('partidas/partida') as partidaParametro(C)
        BEGIN TRAN altaSolicitud

                BEGIN TRY

                    INSERT INTO [solicitud].[Solicitud] (
						 [rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idCentroCosto]
						,[folio]
						,[idTipoSolicitud]
						,[idClase]
						,[fechaCreacion]
						,[fechaCita]
						,[numero]
						,[comentarios]
						,[idEstatusSolicitud]
						,[idUsuario]
					) VALUES (
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idCentroCosto,
						@folio,
						@idTipoSolicitud,
						@idClase,
						GETDATE(),
						@fecha,
						@numeroSolicitud,
						@comentarios,
						'ACTIVA',
						@idUsuario
					)
                    PRINT '1'
                    SET @idSolicitud = @@IDENTITY

                    UPDATE [solicitud].[ContratoConsecutivo]
						SET [consecutivo] = @consecutivo
					WHERE 
                        [rfcEmpresa] = @rfcEmpresa
                        AND [idCliente] = @idCliente
                        AND [numeroContrato] = @numeroContrato 
                    PRINT '2'
                    INSERT INTO [solicitud].[SolicitudObjeto](
						 [idSolicitud]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idTipoSolicitud]
						,[idObjeto]
						,[idTipoObjeto]
						,[idClase]
						,[numeroOrden]
						,[fechaAlta]
						,[idUsuario]
					) VALUES (
						@idSolicitud,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idTipoSolicitud,
						@idObjeto,
						@idTipoObjeto,
						@idClase,
						@numeroSolicitud + '-' + CONVERT(VARCHAR(20), @idObjeto),
						GETDATE(),
						@idUsuario
					)
                    PRINT '3'
                    INSERT INTO [solicitud].[SolicitudPartida] (
				        [idSolicitud]
                        ,[idTipoSolicitud]
                        ,[idClase]
                        ,[rfcEmpresa]
                        ,[idCliente]
                        ,[numeroContrato]
                        ,[idObjeto]
                        ,[idTipoObjeto]
                        ,[idPartida]
                        ,[cantidad]
                        ,[costoInicial]
                        ,[ventaInicial]
                        ,[idEstatusSolicitudPartida]
                        ,[idUsuario]
					) 
                    SELECT @idSolicitud
                        ,@idTipoSolicitud
                        ,@idClase
                        ,@rfcEmpresa
                        ,@idCliente
                        ,@numeroContrato
                        ,@idObjeto
                        ,@idTipoObjeto
                        ,idPartida
                        ,cantidad
                        ,costo
                        ,venta
                        ,'ENESPERA'
						, @idUsuario
                    FROM @partidaVT
                    PRINT '4'
                    INSERT INTO [solicitud].[SolicitudPropiedadClase] (
                        [idSolicitud]
                        ,[idTipoSolicitud]
                        ,[idClase]
                        ,[rfcEmpresa]
                        ,[idCliente]
                        ,[numeroContrato]
                        ,[idPropiedadClase]
                        ,[fechaCaducidad]
                        ,[idUsuario]
                    ) VALUES (
                        @idSolicitud,
                        @idTipoSolicitud,
                        @idClase,
                        @rfcEmpresa,
                        @idCliente,
                        @numeroContrato,
                        @idPropiedadClase,
                        NULL,
                        @idUsuario
                    )
                    PRINT '5'
                    INSERT INTO [fase].[SolicitudEstatusPaso] (
						  [idSolicitud]
						 ,[rfcEmpresa]
						 ,[idCliente]
						 ,[numeroContrato]
						 ,[idPaso]
						 ,[idFase]
						 ,[idClase]
						 ,[idTipoSolicitud]
						 ,[fechaIngreso]
                         ,[fechaSalida]
						 ,[idEstatus]
						 ,[idUsuarioIngreso]
                         ,[idUsuarioSalida]
					) VALUES (
						@idSolicitud
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
                        ,@idPaso
                        ,'Solicitud'
						,@idClase
						,@idTipoSolicitud
						,GETDATE()
                        ,GETDATE()
						,1
						,@idUsuario
                        ,@idUsuario
					)

                    INSERT INTO [fase].[SolicitudEstatusPaso] (
						  [idSolicitud]
						 ,[rfcEmpresa]
						 ,[idCliente]
						 ,[numeroContrato]
						 ,[idPaso]
						 ,[idFase]
						 ,[idClase]
						 ,[idTipoSolicitud]
						 ,[fechaIngreso]
						 ,[idEstatus]
						 ,[idUsuarioIngreso]
					) VALUES (
						@idSolicitud
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
                        ,'CitaConfirmada'
                        ,'Solicitud'
						,@idClase
						,@idTipoSolicitud
						,GETDATE()
						,1
						,@idUsuario
					)
                    PRINT '6'

                    EXEC [solicitud].[INS_COTIZACION_SP] 
                        @idSolicitud
                        ,@idTipoSolicitud
                        ,@idClase
                        ,@rfcEmpresa
                        ,@idCliente
                        ,@numeroContrato
                        ,@idObjeto
                        ,@idTipoObjeto
                        ,@idProveedorEntidad
                        ,@rfcProveedor
                        ,@partidas
                        ,@idUsuario

                    COMMIT TRAN altaSolicitud

                END TRY
                BEGIN CATCH
                    PRINT ERROR_MESSAGE()
                    ROLLBACK TRAN altaSolicitud
                    SET @err = ERROR_MESSAGE()
                    SET @idSolicitud = 0
                    set @numeroSolicitud = NULL
                END CATCH
    END
    ELSE
    BEGIN
        SET @err = 'El contrato no existe o ha expirado.'
    END

    SELECT @idSolicitud idSolicitud, @numeroSolicitud + '-' + CONVERT(VARCHAR(20), @idObjeto) numeroSolicitud 
END
go

