-- =============================================
-- Author:		Martin Pacheco.
-- Create date: 20/05/2019
-- Description:	.
-- Test:		exec [solicitud].[SEL_CENTROCOSTOS_SP] 92,'0001',null,null
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_CENTROCOSTOS_SP]
	--@rfcEmpresa			VARCHAR(13) = '',
    @idCliente			INT = 0,
    @numeroContrato		VARCHAR(50) = '',
	@idUsuario			int = null,
	@err				VARCHAR(8000) OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	DECLARE @DiferenciaCostos		INT = 0

	SELECT @DiferenciaCostos = (
		SELECT 		
			SUM(COALESCE(([SP].[cantidad] * [SP].[venta]), 0))
		FROM [solicitud].[SolicitudCotizacionPartida] AS [SP]
		WHERE 
			[SP].[idCliente] = @idCliente AND
			[SP].[numeroContrato] = @numeroContrato
		)

	;WITH [TipoSolCTE] AS (
		SELECT 
			[CL].[idCentroCosto] AS [idCentroCosto],
			[CL].[nombre] AS [NombreCentro],
			([CL].[presupuesto] - @DiferenciaCostos) AS [CantidadCentro]
		FROM [integridad].[CentroCosto] AS [C]
		INNER JOIN [cliente].[contrato].[CentroCosto] AS [CL]
			ON 
				[C].[idCentroCosto] = [CL].[idCentroCosto] AND
				[C].[rfcEmpresa] = [CL].[rfcEmpresa] AND
				[C].[idCliente] = [CL].[idCliente] AND
				[C].[numeroContrato] = [CL].[numeroContrato]
		WHERE 
			--[C].[rfcEmpresa] = @rfcEmpresa AND
			[C].[idCliente] = @idCliente AND
			[C].[numeroContrato] = @numeroContrato
	)
	SELECT 
	    [CTE].[idCentroCosto],
		[CTE].[NombreCentro],
		[CTE].[CantidadCentro]
	FROM [TipoSolCTE] AS [CTE]

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

