-- =============================================
-- Author:		Martin Pacheco
-- Create date: 
-- Description:	Obtiene ordenes por solicitud y sus partidas.
-- Test:		exec [solicitud].[SEL_COTIZACION_PARTIDAS_SP] 'ASE0508051B6',92,'0001','Automovil',173,null,null
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_COTIZACION_PARTIDAS_SP]
	@rfcEmpresa			VARCHAR(13) = '',
	@idCliente			INT,
	@numeroContrato		VARCHAR(50) = '',
	@idClase			VARCHAR(10) = '',
	@idSolicitud		INT,
	@idUsuario			INT,
	@err				VARCHAR(500) OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	;WITH [OrdenesCTE] AS (
		SELECT
			[SC].[idCotizacion],
			[SC].[idSolicitud],
			[SC].[numeroCotizacion],
			[PE].[rfcProveedor],
			[PE].[idProveedorEntidad],
			[PE].[nombreComercial],
			[PE].[personaContacto],
			[PE].[telefono],
			[PE].[email],
			[SCP].[cantidad],
			[SCP].[idPartida],
			(SELECT [valor] 
			 FROM [Partida].[partida].[PartidaPropiedadGeneral] 
			 WHERE [idPartida] = [SCP].[idPartida] AND [idPropiedadGeneral] = 1 
			) AS [nombrePartida],
			(
				(SELECT valor FROM Common.configuracion.Configuracion WHERE nombre = 'fileServer')
				+
				(SELECT path FROM FileServer.documento.Documento WHERE idDocumento = (SELECT [valor] 
			 FROM [Partida].[partida].[PartidaPropiedadGeneral] 
			 WHERE [idPartida] = [SCP].[idPartida] AND [idPropiedadGeneral] = 2
			))) AS [foto],
			(SELECT [valor] 
			 FROM [Partida].[partida].[PartidaPropiedadGeneral] 
			 WHERE [idPartida] = [SCP].[idPartida] AND [idPropiedadGeneral] = 4			
			 ) AS [NoParte],
			(SELECT [valor] 
			 FROM [Partida].[partida].[PartidaPropiedadGeneral] 
			 WHERE [idPartida] = [SCP].[idPartida] AND [idPropiedadGeneral] = 6 
			) AS [descripcionPartida],
			[SCP].[costo],
			[SCP].[venta],
			[SCP].[idEstatusCotizacionPartida] AS [Estatus]
		FROM [solicitud].[SolicitudCotizacion] AS [SC]
		INNER JOIN [solicitud].[SolicitudCotizacionPartida] AS [SCP]
			ON [SC].[idSolicitud] = [SCP].[idSolicitud] AND
			   [SC].[idCotizacion] = [SCP].[idCotizacion]
		INNER JOIN [Proveedor].[proveedor].[ProveedorEntidad] AS [PE]
			ON [PE].[rfcProveedor] = [SCP].[rfcProveedor] AND
			   [PE].[idProveedorEntidad] = [SCP].[idProveedorEntidad]
		WHERE 
			[SC].[rfcEmpresa] = @rfcEmpresa AND
			[SC].[idCliente] = @idCliente AND
			[SC].[numeroContrato] = @numeroContrato AND
			[SC].[idClase] = @idClase AND
			[SC].[idSolicitud] = @idSolicitud
	) 
	SELECT
		[CTE].[idCotizacion],
		[CTE].[idSolicitud],
		[CTE].[numeroCotizacion],
		[CTE].[rfcProveedor],
		[CTE].[idProveedorEntidad],
		[CTE].[nombreComercial],
		[CTE].[personaContacto],
		[CTE].[telefono],
		[CTE].[email],
		[CTE].[cantidad],
		[CTE].[idPartida],
		[CTE].[nombrePartida],
		[CTE].[foto],
		[CTE].[NoParte],
		[CTE].[descripcionPartida],
		[CTE].[costo],
		[CTE].[venta],
		[CTE].[Estatus]
	FROM [OrdenesCTE] AS [CTE]

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

