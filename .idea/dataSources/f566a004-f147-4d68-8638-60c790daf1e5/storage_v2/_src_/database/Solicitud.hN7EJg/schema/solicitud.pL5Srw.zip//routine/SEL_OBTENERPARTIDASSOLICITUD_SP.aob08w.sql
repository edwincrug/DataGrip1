-- =============================================  
-- Author: Jose Luis Lozada Guerrero
-- Create date: 17-04-2020  
-- Description: Obtiene las partidas de una solicitud que aun no tiene cotizaciones
-- ============== Versionamiento ================  
/*  
	Fecha		Autor			Descripción   
	05/11/2020	JLuis Lozada	Se corrigio la bandera muestraPartidasNuevas
	
 *- Testing...  
	
	EXEC [solicitud].SEL_OBTENERPARTIDASSOLICITUD_SP 560,'Servicio','Automovil','ASE0508051B6',219,'128',6115,null
	EXEC [solicitud].SEL_OBTENERPARTIDASSOLICITUD_SP 1395,'Imagen','Automovil','ASE0508051B6',185,'43',6115,null
	EXEC [solicitud].SEL_OBTENERPARTIDASSOLICITUD_SP 341,'Imagen','Automovil','ASE0508051B6',185,'43',6115,null

	select * from solicitud.solicitud.solicitudObjeto where numeroOrden='150-1453-10558'
	select * from solicitud.solicitud.solicitudObjeto where numeroOrden='150-1164-10558'
*/  
-- =============================================  
CREATE PROCEDURE [solicitud].[SEL_OBTENERPARTIDASSOLICITUD_SP]
@idSolicitud INT,
@idTipoSolicitud VARCHAR(10),
@idClase VARCHAR(10),
@rfcEmpresa VARCHAR(13),
@idCliente INT,
@numeroContrato VARCHAR(50),
@idUsuario INT,
@err VARCHAR(5000) OUTPUT
AS
BEGIN
	DECLARE @muestraPartidasNuevas int =0
		IF	EXISTS (	SELECT 1 
						FROM	compraBPRO.SolicitudPartida scp
						WHERE	SCP.idSolicitud		=@idSolicitud 
						AND		SCP.idTipoSolicitud	=@idTipoSolicitud
						AND		SCP.idClase			=@idClase 
						AND		SCP.rfcEmpresa		=@rfcEmpresa
						AND		SCP.idCliente		=@idCliente
						AND		SCP.numeroContrato	=@numeroContrato)
		BEGIN
			SET @muestraPartidasNuevas=1
		END

	SELECT	@muestraPartidasNuevas	as verGridPartidasNuevasSinCotizacion

	IF @muestraPartidasNuevas=1
		BEGIN
			SELECT	cantidad,descripcion 
			FROM	compraBPRO.SolicitudPartida
			WHERE	idSolicitud		=@idSolicitud 
			AND		idTipoSolicitud	=@idTipoSolicitud
			AND		idClase			=@idClase 
			AND		rfcEmpresa		=@rfcEmpresa
			AND		idCliente		=@idCliente
			AND		numeroContrato	=@numeroContrato
		END

	IF @muestraPartidasNuevas=0
		BEGIN
			SELECT	SCP.[idPartida],  
			SCP.[cantidad],
		  (CASE WHEN PP.[Foto] IS NULL OR PP.[Foto] = 0 THEN 
			(SELECT idDocumento FROM [Common].[configuracion].[DocumentoDefault] WHERE activo=1 AND descripcion='pieza') ELSE PP.[Foto] END) AS [Foto],
		  (CASE WHEN PP.[Instructivo] IS NULL OR PP.[Instructivo] = 0 THEN 
			(SELECT idDocumento FROM [Common].[configuracion].[DocumentoDefault] WHERE activo=1 AND descripcion='instructivo') ELSE PP.[Instructivo] END) AS [Instructivo],    
			SCP.[costoInicial],  
			SCP.[costoInicial]  * SCP.cantidad AS [subTotalCosto], 
			SCP.[costoInicial] *.16  [IVACosto],
			(SCP.[costoInicial]  * SCP.cantidad)+SCP.[costoInicial] *.16 [totalCosto],
			SCP.[ventaInicial],  
			SCP.[ventaInicial]  * SCP.cantidad AS [subTotalVenta],
			SCP.[ventaInicial] *.16  [IVAVenta],
			(SCP.[ventaInicial]  * SCP.cantidad)+SCP.[ventaInicial] *.16 [totalVenta],
			--0 partidaUso,
			(SELECT top 1 valor FROM [Partida].[partida].[PartidaPropiedadGeneral] WHERE idPartida = SCP.idPartida AND idPropiedadGeneral = (SELECT TOP 1 idPropiedadGeneral FROM  [Partida].[partida].[PropiedadGeneral] where valor = 'Partida')) as partida,  
			(SELECT top 1 valor FROM [Partida].[partida].[PartidaPropiedadGeneral] WHERE idPartida = SCP.idPartida AND idPropiedadGeneral = (SELECT TOP 1 idPropiedadGeneral FROM  [Partida].[partida].[PropiedadGeneral] where valor = 'noParte')) as noParte,
			0 as partidaUso,
			PP.[descripcion] AS Descripcion,
			ESP.nombre nombreEstatus
	FROM	solicitud.SolicitudPartida SCP
	INNER	JOIN [Cliente].[contrato].[SEL_PARTIDAS_VW] PP on PP.idPartida = SCP.idPartida  
	INNER	JOIN [solicitud].[EstatusSolicitudPartida] ESP ON ESP.idEstatussolicitudPartida = SCP.idEstatusSolicitudPartida   
	WHERE	SCP.idSolicitud		=@idSolicitud 
	AND		SCP.idTipoSolicitud	=@idTipoSolicitud
	AND		SCP.idClase			=@idClase 
	AND		SCP.rfcEmpresa		=@rfcEmpresa
	AND		SCP.idCliente		=@idCliente
	AND		SCP.numeroContrato	=@numeroContrato
	
	SELECT	tx.subTotalCosto,tx.IVACosto,TX.subTotalCosto+IVACosto AS totalCosto,
			tx.subTotalVenta,tx.IVAVenta,TX.subTotalVenta+IVAVenta AS totalVenta
	FROM (	SELECT  SUM(SCP.cantidad * SCP.costoInicial) AS subTotalCosto,
					SUM(SCP.costoInicial)*.16 AS IVACosto,
					SUM(SCP.cantidad * SCP.ventaInicial) AS subTotalVenta,
					SUM(SCP.ventaInicial)*.16 AS IVAVenta
			FROM	solicitud.SolicitudPartida SCP
			INNER	JOIN [Cliente].[contrato].[SEL_PARTIDAS_VW] PP on PP.idPartida = SCP.idPartida  
			INNER	JOIN [solicitud].[EstatusSolicitudPartida] ESP ON ESP.idEstatussolicitudPartida = SCP.idEstatusSolicitudPartida   
			WHERE	SCP.idSolicitud		=@idSolicitud 
			AND		SCP.idTipoSolicitud	=@idTipoSolicitud
			AND		SCP.idClase			=@idClase 
			AND		SCP.rfcEmpresa		=@rfcEmpresa
			AND		SCP.idCliente		=@idCliente
			AND		SCP.numeroContrato	=@numeroContrato)tx
		END


	

	
END
go

