
--use solicitud
-- =============================================
-- Author: ERIC REYES
-- Create date: 08/07/2020
-- Description:	Consulta el detalle de las facturas cargadas
-- EXEC [cxp].[SEL_DETALLE_FACTURA_SP] '<uuids><uuid>0F09685F-8498-49B4-AA6A-5E7CA3F13681</uuid></uuids>',115,''
-- =============================================
CREATE PROCEDURE [cxp].[SEL_DETALLE_FACTURA_SP]
@uuids XML,
@idUsuario INT,
@err VARCHAR(8000) = '' OUTPUT	
AS
BEGIN

	DECLARE @tbl_uuids AS TABLE(
	uuid					VARCHAR(100)
	)

	INSERT INTO @tbl_uuids(uuid)
	SELECT
		ParamValues.col.value('.','varchar(100)')
		FROM @uuids.nodes('uuids/uuid') AS ParamValues(col)

	SELECT F.uuid, 
		F.rfcEmisor,
		SO.numeroorden AS numeroOrden,
		SC.numeroCotizacion,
		(SELECT valor FROM objeto.objeto.objetopropiedadclase OPC WHERE OPC.idObjeto = So.idObjeto AND idPropiedadClase = 1 ) AS vin,
		'SISCO V3' AS version,
		F.serie,
		F.folio,
		STP. subTotalCosto,
		STP.IVACosto,
		STP.totalCosto,
		STP.idPartida,
		STP.cantidad,
		(select [Partida].[partida].[getPropiedadPartida] (STP.idPartida, 'Descripción', 'general')) AS descripcion,
		OTE_FACTURACOMPRA as facturaVirtual
	FROM [Solicitud].[cxp].[Factura] F
	INNER JOIN Solicitud.cxp.SolicitudCotizacionFactura SCF ON SCF.uuid = F.uuid
	inner join [cxc].[FacturaBPRO] FBPRO ON FBPRO.idSolicitud = SCF.idSolicitud and FBPRO.idCotizacion = SCF.idCotizacion
	INNER JOIN Solicitud.[solicitud].[SolicitudObjeto] SO on SO.idSolicitud = SCF.idSolicitud
	INNER JOIN Solicitud.[solicitud].[SolicitudCotizacion] SC on SC.idCotizacion = SCF.idCotizacion
	INNER JOIN [solicitud].[SEL_TOTALES_PARTIDAS_VW] STP ON STP.idCotizacion = SC.idCotizacion
	WHERE F.uuid in (SELECT uuid from @tbl_uuids)
	AND STP.idEstatusCotizacionPartida = 'APROBADA'
	AND SC.idEstatusCotizacion = 'APROBADA'

	UNION ALL

	SELECT 
		DFC.Uuid AS uuid, 
		DFC.RfcEmisor AS rfcEmisor, 
		O.numeroOrden, 
		C.numeroCotizacion, 
		U.vin,
		'SISCO V2' AS version,
		'' as serie,
		DFC.Folio AS folio,
		CD.costo as subtotalCosto,
		(CD.costo * 0.16) as IVACosto,
		(CD.costo * 1.16) as totalCosto,
		CD.idPartida,
		CD.cantidad,
		P.descripcion as descripcion,
		FC.numFactura AS facturaVirtual
	FROM [aseprot].[dbo].[DatosFacturaConcentra] DFC
	INNER JOIN [aseprot].[dbo].[DatosFacturaConcentraCotizacion] DFCC ON DFCC.IdDatosFacturaConcentra = DFC.IdDatosFacturaConcentra
	INNER JOIN [aseprot].[dbo].[Cotizaciones] C ON C.idCotizacion = DFCC.IdCotizacion
	LEFT JOIN ASEPROT.[dbo].[facturaCotizacion] FC ON FC.idCotizacion = C.idCotizacion
	INNER JOIN [ASEPROT].[dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion
	INNER JOIN [Partidas].[dbo].[partida] P ON P.idpartida = CD.idPartida
	INNER JOIN [aseprot].[dbo].[Ordenes] O ON O.idOrden = C.idOrden
	INNER JOIN [aseprot].[dbo].[Unidades] U ON U.idunidad = O.idunidad 
	where DFC.Uuid in (SELECT uuid from @tbl_uuids)
	AND C.idEstatusCotizacion = 3
	AND CD.idEstatusPartida = 2

END

go

