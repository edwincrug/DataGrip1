-- =============================================
-- Author:		<DVR>
-- Create date: <25/08/2020>
-- Description:	<Regresa lista de GPS sin asignar>
-- TEST [solicitud].[SEL_LISTA_GPS_SP] 1,6147, ''
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_LISTA_GPS_SP]
	@idSolicitud    INT,
	@idUsuario		INT,  
	@err			VARCHAR(500)OUTPUT 
AS
BEGIN

	--DECLARE @idSolicitud    INT = 1158
SELECT 
	GPSSIM.idInventarioGPS, 
	IPC.valor
FROM inventario.inventario.InventarioPropiedadCategoria IPC
	JOIN inventario.inventario.PropiedadCategoria PC ON PC.idPropiedadCategoria = IPC.idPropiedadCategoria AND PC.idCategoria IN('GPS','DVR') AND PC.agrupador = 'DeviceID'
	JOIN inventario.inventario.GPSSIM GPSSIM ON GPSSIM.idInventarioGPS = IPC.idInventario
	LEFT JOIN inventario.inventario.ObjetoGPSSIM OGPSSIM ON OGPSSIM.idGPSSIM = GPSSIM.idGPSSIM AND OGPSSIM.activo = 1
	LEFT JOIN Solicitud.solicitud.SolicitudObjetoGPSSIM SOGPSSIM ON SOGPSSIM.idGPSSIM = GPSSIM.idGPSSIM AND SOGPSSIM.idSolicitud = @idSolicitud
WHERE OGPSSIM.idGPSSIM IS NULL AND SOGPSSIM.idGPSSIM IS NULL

/*
			SELECT  a.idInventario AS idInventarioGPS,
				    a.valor
					--,c.*
					--,U.idGPSSIM
			FROM inventario.inventario.InventarioPropiedadCategoria a
			INNER JOIN inventario.inventario.PropiedadCategoria  b ON a.idPropiedadCategoria = b.idPropiedadCategoria 																
			LEFT JOIN inventario.inventario.GPSSIM  c ON a.idInventario = c.idInventarioGPS
			LEFT JOIN 
						(
						SELECT idGPSSIM
						FROM [solicitud].[SolicitudObjetoGPSSIM]
						WHERE desinstalacion = 0 
							UNION
						SELECT idGPSSIM
						FROM inventario.inventario.ObjetoGPSSIM 
						WHERE activo = 1
						) 
						AS u ON u.idGPSSIM = c.idGPSSIM
			WHERE 
			b.idCategoria ='GPS' AND b.agrupador='DeviceID'
			AND c.idGPSSIM IS NOT NULL
			AND u.idGPSSIM IS NULL
			ORDER BY 1 DESC
*/			
END

--USE [Solicitud]
go

