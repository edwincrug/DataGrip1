-- =============================================
-- Author:		Adolfo Martinez
-- Create date: 14/05/2020
-- Description:	Actualiza los de siscov3 con sintonia de BPRO
-- EXEC [cxc].[SEL_ACTUALIZA_ESTATUS_BPRO_SP]
/*
	SELECT DISTINCT
		enc.ote_ident,so.numeroOrden, so.idSolicitud,so.idTipoSolicitud,so.idClase,so.rfcEmpresa,so.idCliente,so.numeroContrato,3132,s.idPaso,s.idFase
	FROM Solicitud.solicitud.SolicitudObjeto so
		join Solicitud.solicitud.Solicitud s on s.idSolicitud = so.idSolicitud
		join [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] enc on enc.ote_ordenandrade = so.numeroOrden COLLATE MODERN_SPANISH_CI_AS
		join [192.168.20.29].[GAAutoExpress].[dbo].[ADE_COPADE] cop on cop.cop_ordenGlobal = enc.ote_ordenGlobal
	WHERE OTE_STATUS=3
*/
-- ============== Versionamiento ================  


CREATE PROCEDURE [cxc].[SEL_ACTUALIZA_ESTATUS_BPRO_SP]
AS
BEGIN
	--SELECT 1
	
	
	DECLARE @idSolicitud INT, @idTipoSolicitud VARCHAR(10), @idClase VARCHAR(10), @rfcEmpresa VARCHAR(13), @idCliente INT, @numeroContrato VARCHAR(50), @idPaso VARCHAR(50),
			@saldocxp DECIMAL(18,2), @saldocxc DECIMAL(18,2),@saldoInicialcxp DECIMAL(18,2), @saldoInicialcxc DECIMAL(18,2)
	DECLARE @ids TABLE (id INT)
	INSERT INTO @ids (id)
		SELECT 
			so.idSolicitud
		FROM Solicitud.solicitud.Solicitud S
			JOIN Solicitud.solicitud.SolicitudObjeto SO ON SO.idSolicitud = S.idSolicitud
			JOIN [solicitud].[SEL_CXC_VW] CC ON CC.idSolicitud = S.idSolicitud
			JOIN [solicitud].[SEL_CXP_VW] CP ON CP.idSolicitud = S.idSolicitud
		WHERE S.idFase='Cobranza' AND s.idPaso NOT IN('Finalizada') AND s.idPaso IN('PrefacturaGenerada','FacturaEnviadaCliente','FacturaAbonada')

	WHILE EXISTS(SELECT 1 FROM @ids)
	BEGIN
		SELECT TOP 1 @idSolicitud=id FROM @ids	
		SELECT
			@idTipoSolicitud=SO.idTipoSolicitud,
			@idClase=SO.idClase,
			@rfcEmpresa=SO.rfcEmpresa,
			@idCliente=SO.idCliente,
			@numeroContrato=SO.numeroContrato,
			@idPaso=S.idPaso,
			@saldocxc=CC.saldo,
			@saldoInicialcxc=CC.IMPORTE,
			@saldocxp=CP.saldo,
			@saldoInicialcxp=CP.IMPORTE
		FROM Solicitud.solicitud.Solicitud S
			JOIN Solicitud.solicitud.SolicitudObjeto SO ON SO.idSolicitud = S.idSolicitud
			JOIN [solicitud].[SEL_CXC_VW] CC ON CC.idSolicitud = S.idSolicitud
			JOIN [solicitud].[SEL_CXP_VW] CP ON CP.idSolicitud = S.idSolicitud
		WHERE S.idSolicitud=@idSolicitud AND S.idFase='Cobranza' AND s.idPaso NOT IN('Finalizada') AND s.idPaso IN('PrefacturaGenerada','FacturaEnviadaCliente','FacturaAbonada')

		IF(@idPaso='PrefacturaGenerada')
			BEGIN
				EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,'FacturaEnviadaCliente','Cobranza',3132,''

				UPDATE F
				SET idEstatus=S.idPaso
				FROM Solicitud.solicitud.Solicitud S
					JOIN Solicitud.[cxc].[factura] F ON F.idSolicitud = S.idSolicitud
				WHERE S.idSolicitud = @idSolicitud AND S.idTipoSolicitud = @idTipoSolicitud AND S.idClase = @idClase AND S.rfcEmpresa = @rfcEmpresa AND S.idCliente = @idCliente AND S.numeroContrato = @numeroContrato

				--SET @idPaso='FacturaEnviadaCliente'
			END
		IF(@idPaso='FacturaEnviadaCliente' OR @idPaso='FacturaAbonada')
			BEGIN
				IF(@saldocxp = 0 AND @saldocxc=0)
					BEGIN
						EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,'Finalizada','Cobranza',3132,''

						UPDATE F
						SET idEstatus=S.idPaso
						FROM Solicitud.solicitud.Solicitud S
							JOIN Solicitud.[cxc].[factura] F ON F.idSolicitud = S.idSolicitud
						WHERE S.idSolicitud = @idSolicitud AND S.idTipoSolicitud = @idTipoSolicitud AND S.idClase = @idClase AND S.rfcEmpresa = @rfcEmpresa AND S.idCliente = @idCliente AND S.numeroContrato = @numeroContrato

						--UPDATE Solicitud.solicitud.Solicitud
						--SET idEstatusSolicitud='ACTIVA'
						--FROM Solicitud.solicitud.Solicitud S
						--WHERE S.idSolicitud = @idSolicitud AND S.idTipoSolicitud = @idTipoSolicitud AND S.idClase = @idClase AND S.rfcEmpresa = @rfcEmpresa AND S.idCliente = @idCliente AND S.numeroContrato = @numeroContrato

					END
					--@saldocxp < @saldoInicialcxp  OR 
				ELSE IF(@saldocxc < @saldoInicialcxc)
					BEGIN
						EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,'FacturaAbonada','Cobranza',3132,''
						
						UPDATE F
						SET idEstatus=S.idPaso
						FROM Solicitud.solicitud.Solicitud S
							JOIN Solicitud.[cxc].[factura] F ON F.idSolicitud = S.idSolicitud
						WHERE S.idSolicitud = @idSolicitud AND S.idTipoSolicitud = @idTipoSolicitud AND S.idClase = @idClase AND S.rfcEmpresa = @rfcEmpresa AND S.idCliente = @idCliente AND S.numeroContrato = @numeroContrato

					END			
			END

		DELETE FROM @ids WHERE id = @idSolicitud
	END


	--DECLARE @idSolicitud INT, @idTipoSolicitud VARCHAR(MAX), @idClase VARCHAR(MAX), @rfcEmpresa VARCHAR(MAX), @idCliente INT, @numeroContrato VARCHAR(MAX)
	--DECLARE ProdInfo CURSOR FOR 
	--SELECT DISTINCT
	--	so.idSolicitud,so.idTipoSolicitud,so.idClase,so.rfcEmpresa,so.idCliente,so.numeroContrato
	--FROM Solicitud.solicitud.SolicitudObjeto so
	--	JOIN Solicitud.solicitud.Solicitud s on s.idSolicitud = so.idSolicitud
	--	JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] enc ON enc.ote_ordenandrade COLLATE MODERN_SPANISH_CI_AS = so.numeroOrden COLLATE MODERN_SPANISH_CI_AS
	--	JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_COPADE] cop ON cop.cop_ordenglobal = enc.ote_ordenglobal
	--WHERE OTE_STATUS IN(3) and s.idPaso='PrefacturaGenerada' and idFase='Cobranza' AND cop.COP_IDDOCTO IS NOT NULL
	--OPEN ProdInfo
	--FETCH NEXT FROM ProdInfo INTO @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato
	--WHILE @@fetch_status = 0
	--BEGIN
	--	EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,'FacturaEnviadaCliente','Cobranza',3132,''
	--	UPDATE F
	--	SET idEstatus=S.idPaso
	--	FROM Solicitud.solicitud.Solicitud S
	--		JOIN Solicitud.[cxc].[factura] F ON F.idSolicitud = S.idSolicitud
	--	WHERE S.idSolicitud = @idSolicitud AND S.idTipoSolicitud = @idTipoSolicitud AND S.idClase = @idClase AND S.rfcEmpresa = @rfcEmpresa AND S.idCliente = @idCliente AND S.numeroContrato = @numeroContrato
	--	FETCH NEXT FROM ProdInfo INTO @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato
	--END
	--CLOSE ProdInfo
	--DEALLOCATE ProdInfo

END
go

