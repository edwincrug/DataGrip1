-- =============================================
-- Author:		Adolfo Martinez
-- Create date: 14/05/2020
-- Description:	Actualiza los saldos en las cuentas de CXC
-- EXEC [cxc].[SEL_ACTUALIZA_SALDOS_CXC_SP] 
-- ============== Versionamiento ================  


CREATE PROCEDURE [cxc].[SEL_ACTUALIZA_SALDOS_CXC_SP]
AS
BEGIN

	;WITH detalleInsert (cop_ordenGlobal,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO)
        AS  
        (  
            SELECT
                   cop_ordenGlobal,
                   CCP_IDDOCTO,
                   CCP_FECHADOCTO,
                   CCP_FECHVEN,
                   CCP_FECHPROMPAG,
                   'IMPORTE' = CASE CARTERA.PAR_IDMODULO 
                   when 'CXC' then ccp_cargo-ccp_abono else ccp_abono-ccp_cargo end,  
                   'SALDO' = CASE CARTERA.PAR_IDMODULO when 'CXC' then ccp_cargo-ccp_abono + (Select isnull(sum(CCP_CARGO-CCP_ABONO),0) 
                    from [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO 
                        AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA 
                        AND MOVIMIENTO.CCP_DOCORI<>'S' ) else ccp_abono-ccp_cargo+(Select isnull(sum(CCP_ABONO-CCP_CARGO),0) 
                    from [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO 
                    AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA 
                    AND MOVIMIENTO.CCP_DOCORI<>'S') end
            FROM [192.168.20.29].[GAAutoexpressConcentra].[dbo].[Con_Car012020] AS DOCUMENTO 
			--[192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 AS DOCUMENTO 
			LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA='CARTERA'  
			INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA 
			LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = 'TIMO'  
			LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL 
            INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_COPADE ON CCP_IDDOCTO = COP_IDDOCTO
            WHERE CCP_DOCORI='S'  and CCP_TIPODOCTO = 'FAC' and cop_ordenglobal COLLATE MODERN_SPANISH_CI_AS  IN(SELECT numeroCopade FROM cxc.FacturaAgrupada)
        )
        MERGE cxc.FacturaAgrupadaBPRO AS TARGET
        USING (SELECT cop_ordenGlobal,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO FROM detalleInsert) AS SOURCE (cop_ordenGlobal,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO)
        ON (TARGET.numeroCopade = SOURCE.cop_ordenGlobal COLLATE MODERN_SPANISH_CI_AS )
        WHEN MATCHED THEN
            UPDATE SET 
					CCP_IDdocto = SOURCE.CCP_IDDOCTO,
                    CCP_FECHADOCTO = SOURCE.CCP_FECHADOCTO,
                    CCP_FECHVEN = SOURCE.CCP_FECHVEN,
                    CCP_FECHPROMPAG = SOURCE.CCP_FECHPROMPAG,
                    importe = SOURCE.IMPORTE,
                    saldo = SOURCE.SALDO
        WHEN NOT MATCHED THEN
            INSERT (numeroCopade,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO,idUsuario,activo)
            VALUES (cop_ordenGlobal,CCP_IDDOCTO,CCP_FECHADOCTO,CCP_FECHVEN,CCP_FECHPROMPAG,IMPORTE,SALDO,3132,1);

END
go

