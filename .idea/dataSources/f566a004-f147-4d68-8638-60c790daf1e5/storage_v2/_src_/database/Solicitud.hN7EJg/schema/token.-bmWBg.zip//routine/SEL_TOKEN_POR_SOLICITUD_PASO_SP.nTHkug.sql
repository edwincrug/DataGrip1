-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/07/2019>
-- Description:	    <Obtener los tokens por solicitud y paso>
-- =============================================
-- EXEC [token].[SEL_TOKEN_POR_SOLICITUD_PASO_SP] 57, 'SinTaller', 55
-- =============================================
CREATE PROCEDURE [token].[SEL_TOKEN_POR_SOLICITUD_PASO_SP]
(
    @idSolicitud        int
    ,@idPaso             varchar(50)
	,@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN

    SELECT 
        TT.[idToken]
        ,TT.[token]
        ,TT.[fechaCrea]
        ,TT.[fechaUso]
        ,TT.[idUsuarioCrea]
        ,TT.[idUsuarioUsa]
        ,TT.[idPaso]
        ,TT.[idTipoToken]
        ,TT.[estatus]  
        ,SS.[idSolicitud]
        ,SS.[idTipoSolicitud]
        ,SS.[idClase]
        ,SS.[rfcEmpresa]
        ,SS.[idCliente]
        ,SS.[numeroContrato] 
    FROM [Solicitud].[token].[Token] TT
    INNER JOIN [Solicitud].[token].[TokenSolicitud] TTS
        ON TT.idToken = TTS.idToken
    INNER JOIN [Solicitud].[solicitud].[Solicitud] SS
        ON TTS.[idSolicitud] = SS.[idSolicitud]
    WHERE TTS.idSolicitud = @idSolicitud
        AND SS.idSolicitud = @idSolicitud
        AND TT.idPaso = @idPaso
END
go

