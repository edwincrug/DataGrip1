-- =============================================
-- Author:		Andres Farias
-- Create date: 24/07/2019
-- Description:	Genera el agrupador por contrato
-- Test:		SELECT [solicitud].[SEL_NUMERO_AGRUPADORFACTURA_FN]('ASE0508051B6','Automovil',92,'0001')
-- =============================================
CREATE FUNCTION [solicitud].[SEL_NUMERO_AGRUPADORFACTURA_FN]
(
	@rfcEmpresa			VARCHAR(20),
	@idClase			VARCHAR(10),
	@idCliente			INT,
	@numeroContrato		VARCHAR(50)
)
RETURNS VARCHAR(50)
AS
BEGIN
	DECLARE 
		@VC_NumeroConsecutivo	VARCHAR(8) = '',
		@VC_AGRUPADORFACTURA	VARCHAR(50) = ''


	SELECT @VC_NumeroConsecutivo = (
		SELECT TOP 1
			 COALESCE(RIGHT([FA].[numeroEstimacion],CHARINDEX('-',REVERSE([FA].[numeroEstimacion]),0)-1), 0) AS [Index]
		FROM [cxc].[FacturaAgrupada] AS [FA]
		WHERE 
			[FA].[rfcEmpresa] = @rfcEmpresa AND
			[FA].[idCliente] = @idCliente AND
			[FA].[numeroContrato] = @numeroContrato
		ORDER BY [Index] DESC
	)

	IF (@VC_NumeroConsecutivo IS NOT NULL)
		BEGIN
			SET @VC_AGRUPADORFACTURA = @rfcEmpresa + CAST(@idCliente AS VARCHAR(10)) + @numeroContrato + '-' + CAST((CAST(@VC_NumeroConsecutivo AS INT) + 1) AS VARCHAR(10))
		END
	ELSE IF (@VC_NumeroConsecutivo IS NULL)
		BEGIN
			SET @VC_AGRUPADORFACTURA = @rfcEmpresa + CAST(@idCliente AS VARCHAR(10)) + @numeroContrato + '-' + '1'
		END
	RETURN @VC_AGRUPADORFACTURA
END
go

