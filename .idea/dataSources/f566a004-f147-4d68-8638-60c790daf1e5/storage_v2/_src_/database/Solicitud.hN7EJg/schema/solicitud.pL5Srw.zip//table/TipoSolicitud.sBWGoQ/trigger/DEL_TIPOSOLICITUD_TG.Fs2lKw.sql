-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <04/07/2019>
-- Description:	<ELIMINA de Integridades>
-- =============================================
CREATE TRIGGER [solicitud].[DEL_TIPOSOLICITUD_TG] 
   ON  [solicitud].[TipoSolicitud]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @idTipoSolicitud	VARCHAR(10),
			@idClase			VARCHAR(10),
			@IdUsuario			INT,
			@VC_ThrowTable		VARCHAR(300) = ''
	;
	SELECT TOP 1 @idTipoSolicitud= idTipoSolicitud, @idClase= idClase, @IdUsuario = IdUsuario FROM deleted
	BEGIN TRANSACTION;
	BEGIN TRY
	--ELIMINAMOS INTEGRIDADES

		--Cliente
		SET @VC_ThrowTable = '[Cliente].[integridad].[TipoSolicitud] ';
		DELETE FROM [Cliente].[integridad].[TipoSolicitud]
		WHERE idTipoSolicitud =  @idTipoSolicitud 
		AND idClase = @idClase

		SET @VC_ThrowTable = 'Proveedor.integridad.TipoSolicitud'
		DELETE 
		FROM Proveedor.integridad.TipoSolicitud
		WHERE idTipoSolicitud = @idTipoSolicitud
		AND idClase = @idClase

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
	END CATCH

END
go

