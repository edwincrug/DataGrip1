
-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener los totales de cada partida>
-- ============== Versionamiento ================  
/*
	Fecha			Autor		Descripción   
	28/06/2020		JLLOZADA	Se agregaron los campos porcentajeDescuentoCosto y descuentoCosto
	07/12/2020		JLLOZADA	Se modifico el campo fechaEstatus y idUsuario - Autorizaciones por n personas

 SELECT top 10 * FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW]
 
*/
CREATE VIEW [solicitud].[SEL_TOTALES_PARTIDAS_VW]
AS

SELECT *, (ISNULL(subTotalCosto,0)) + (ISNULL(trasladoIVA,0) - ISNULL(retencionIVA,0)) totalCosto FROM(
SELECT 
	SCP.[idCotizacion]
    ,SCP.[idSolicitud]
    ,SCP.[idTipoSolicitud]
    ,SCP.[idClase]
    ,SCP.[rfcEmpresa]
    ,SCP.[numeroContrato]
    ,SCP.[idCliente]
    ,SCP.[rfcProveedor]
    ,SCP.[idProveedorEntidad]
    ,SCP.[idObjeto]
    ,SCP.[idTipoObjeto]
    ,SCP.[idPartida]
    ,SCP.[cantidad]
    ,([costo]-ISNULL([descuentoCosto],0)) [costo]
    ,SCP.[venta] as ventaSinDescuento
	,(SCP.[venta]-ISNULL([descuentoVenta],0)) AS venta
    ,SCP.[idEstatusCotizacionPartida]
	,SC.[idEstatusCotizacion]
    --,[fechaEstatus]
    --,[idUsuario]
	--,SCA.fechaAprobacion AS fechaEstatus,
	/*,ISNULL((	SELECT	TOP 1 SCA.fechaAprobacion  
				FROM	[solicitud].[solicitud].[SolicitudCotizacionAprobador]  SCA
				WHERE	SCA.idCotizacion		= SCP.idCotizacion
				AND		SCA.idSolicitud			= SCP.idSolicitud
				AND		SCA.idTipoSolicitud		= SCP.idTipoSolicitud
				AND		SCA.idClase				= SCP.idClase
				AND		SCA.rfcEmpresa			= SCP.rfcEmpresa
				AND		SCA.numeroContrato		= SCP.numeroContrato
				AND		SCA.idCliente			= SCP.idCliente
				AND		SCA.rfcProveedor		= SCP.rfcProveedor
				AND		SCA.idProveedorEntidad	= SCP.idProveedorEntidad
				AND		SCA.idObjeto			= SCP.idObjeto
				AND		SCA.idTipoObjeto		= SCP.idTipoObjeto
				AND		SCA.idPartida			= SCP.idPartida
				ORDER   BY SCA.fechaAprobacion DESC),'') AS fechaEstatus	*/
	,'' fechaEstatus
	/*,ISNULL((	SELECT	TOP 1 SCA.idUsuarioAprobador  
				FROM	[solicitud].[solicitud].[SolicitudCotizacionAprobador] SCA
				WHERE	SCA.idCotizacion		= SCP.idCotizacion
				AND		SCA.idSolicitud			= SCP.idSolicitud
				AND		SCA.idTipoSolicitud		= SCP.idTipoSolicitud
				AND		SCA.idClase				= SCP.idClase
				AND		SCA.rfcEmpresa			= SCP.rfcEmpresa
				AND		SCA.numeroContrato		= SCP.numeroContrato
				AND		SCA.idCliente			= SCP.idCliente
				AND		SCA.rfcProveedor		= SCP.rfcProveedor
				AND		SCA.idProveedorEntidad	= SCP.idProveedorEntidad
				AND		SCA.idObjeto			= SCP.idObjeto
				AND		SCA.idTipoObjeto		= SCP.idTipoObjeto
				AND		SCA.idPartida			= SCP.idPartida
				ORDER   BY SCA.fechaAprobacion DESC),'') AS idUsuario*/
	,'' idUsuario	
	--,SCA.idUsuarioAprobador AS idUsuario

    ,([costo] * [cantidad]) subTotalCostoSinDescuento
	,(([costo]-ISNULL([descuentoCosto],0)) * [cantidad]) subTotalCosto
	,(([costo]-ISNULL([descuentoCosto],0)) * [cantidad]) * .16 IVACosto
	,(([costo]-ISNULL([descuentoCosto],0)) * [cantidad]) + ((([costo]-ISNULL([descuentoCosto],0)) * [cantidad]) * .16) totalCostoAnterior
	,ISNULL(SCPD.porcentajeDescuentoCosto,0) porcentajeDescuentoCosto
	,(ISNULL(SCPD.descuentoCosto,0) * [cantidad]) descuentoCosto
	
	
    ,([venta] * [cantidad]) subTotalVentaSinDescuento
    ,(([venta]-ISNULL([descuentoVenta],0)) * [cantidad]) subTotalVenta
    ,(([venta]-ISNULL([descuentoVenta],0)) * [cantidad]) * .16 IVAVenta
    ,(([venta]-ISNULL([descuentoVenta],0)) * [cantidad]) + ((([venta]-ISNULL([descuentoVenta],0)) * [cantidad]) * .16) totalVenta
	,ISNULL(SCPD.porcentajeDescuentoVenta,0) porcentajeDescuentoVenta
	,(ISNULL(SCPD.descuentoVenta,0) * [cantidad]) descuentoVenta
	
	--,([venta] * [cantidad]) * .16 IVAVentaSinDescuento
    --,([venta] * [cantidad]) + (([venta] * [cantidad]) * .16) totalVentaSinDescuento
	
	,SS.[idEstatusSolicitud]
	--,(SELECT F.traslado FROM [Solicitud].[cxp].[Factura] F WHERE F.uuid = SCF.uuid)/ CASE WHEN (SELECT COUNT(uuid) FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=SC.idSolicitud AND idCotizacion=SC.idCotizacion)) = 0 THEN 1 ELSE (SELECT COUNT(uuid) FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=SC.idSolicitud AND idCotizacion=SC.idCotizacion)) END AS trasladoIVA
	,(SELECT [solicitud].[SEL_TRASLADO_FN] (SCF.uuid,SC.idSolicitud, SC.idCotizacion, SCP.idPartida)) AS trasladoIVA
	--,(SELECT F.retencion FROM [Solicitud].[cxp].[Factura] F WHERE F.uuid = SCF.uuid)/CASE WHEN (SELECT COUNT(uuid) FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=SC.idSolicitud AND idCotizacion=SC.idCotizacion)) = 0 THEN 1 ELSE (SELECT COUNT(uuid) FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=SC.idSolicitud AND idCotizacion=SC.idCotizacion)) END AS retencionIVA
	,(SELECT [solicitud].[SEL_RETENCION_FN] (SCF.uuid,SC.idSolicitud, SC.idCotizacion, SCP.idPartida)) AS retencionIVA
FROM	[Solicitud].[solicitud].[Solicitud] SS 
INNER JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa=SS.rfcEmpresa AND C.idCliente=SS.idCliente AND C.numeroContrato=SS.numeroContrato
INNER JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SC ON SS.idSolicitud = SC.idSolicitud
INNER JOIN [Solicitud].[solicitud].[SolicitudCotizacionPartida] SCP ON SC.idCotizacion = SCP.idCotizacion AND SC.idSolicitud = SCP.idSolicitud
LEFT	JOIN [Solicitud].[solicitud].[SolicitudCotizacionPartidaDescuento] SCPD ON SCPD.idCotizacion = SCP.idCotizacion AND SCPD.idSolicitud = SCP.idSolicitud AND SCPD.idPartida = SCP.idPartida
--LEFT	JOIN [solicitud].[solicitud].[SolicitudCotizacionAprobador] SCA ON SCA.idCotizacion = SCP.idCotizacion
--	AND SCA.idSolicitud = SCP.idSolicitud
--	AND SCA.idTipoSolicitud = SCP.idTipoSolicitud
--	AND SCA.idClase = SCP.idClase
--	AND SCA.rfcEmpresa = SCP.rfcEmpresa
--	AND SCA.numeroContrato = SCP.numeroContrato
--	AND SCA.idCliente = SCP.idCliente
--	AND SCA.rfcProveedor = SCP.rfcProveedor
--	AND SCA.idProveedorEntidad = SCP.idProveedorEntidad
--	AND SCA.idObjeto = SCP.idObjeto
--	AND SCA.idTipoObjeto = SCP.idTipoObjeto
--	AND SCA.idPartida = SCP.idPartida
  LEFT JOIN [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] SCF
  ON SCF.idCotizacion = SCP.idCotizacion 
	AND SCF.idSolicitud = SCP.idSolicitud
	AND SCF.idTipoSolicitud = SCP.idTipoSolicitud
	AND SCF.idClase = SCP.idClase
	AND SCF.rfcEmpresa = SCP.rfcEmpresa
	AND SCF.numeroContrato = SCP.numeroContrato
	AND SCF.idCliente = SCP.idCliente
	AND SCF.rfcProveedor = SCP.rfcProveedor
	AND SCF.idProveedorEntidad = SCP.idProveedorEntidad
	AND SCF.idObjeto = SCP.idObjeto
	AND SCF.idTipoObjeto = SCP.idTipoObjeto
	AND SCF.idPartida = SCP.idPartida)PARTIDA
go

