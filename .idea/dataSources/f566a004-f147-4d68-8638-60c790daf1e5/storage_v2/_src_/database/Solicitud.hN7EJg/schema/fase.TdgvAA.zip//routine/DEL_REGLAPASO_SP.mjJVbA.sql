
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 10-09-2019
-- Description: Elimina reglas de paso
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [fase].[DEL_REGLAPASO_SP]  '<Ids><idRegla>61</idRegla><idRegla>62</idRegla><idRegla>63</idRegla></Ids>',
	6036, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [fase].[DEL_REGLAPASO_SP] 
	@data					XML,
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	 DECLARE @tbl_propiedades AS TABLE(
        idReglaPaso			INT
    )


    INSERT INTO @tbl_propiedades
    SELECT
        I.N.value('.','int')
        FROM @data.nodes('/Ids/idRegla') AS I(N)

	--select * from @tbl_propiedades

	UPDATE [fase].[ReglaPaso]
		SET activo = 0
	WHERE idReglaPaso in (select idReglaPaso from @tbl_propiedades)

	UPDATE [fase].[ReglaPasoRol]
		SET activo = 0
	WHERE idReglaPaso in (select idReglaPaso from @tbl_propiedades)

	UPDATE [fase].[ReglaPasoUsuario]
		SET activo = 0
	WHERE idReglaPaso in (select idReglaPaso from @tbl_propiedades)

	UPDATE [fase].[ReglaPasoPartida]
		SET activo = 0
	WHERE idReglaPaso in (select idReglaPaso from @tbl_propiedades)

	UPDATE [fase].[ReglaPasoMonto]
		SET activo = 0
	WHERE idReglaPaso in (select idReglaPaso from @tbl_propiedades)

	UPDATE [fase].[ReglaPasoObjeto]
		SET activo = 0
	WHERE idReglaPaso in (select idReglaPaso from @tbl_propiedades)

END



go

