

-- =============================================
-- Author: Luis Martinez
-- Create date: 11-07-2020
-- Description: Obtiene la evidencia de una solicitud (Documentos)
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [documento].[SEL_SOLICITUDOBJETOEVIDENCIA_SP]  'DIC0503123MD3', 'Automovil' ,78, '123PEMEX', 29, 118, 1256 2, NULL;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [documento].[SEL_SOLICITUDOBJETOEVIDENCIA_SP]
	@rfcEmpresa				varchar(13),
	@idClase				varchar(10),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	@idSolicitud			int,
	@idTipoObjeto			int,
	@idObjeto				int,
	@idUsuario				int,
	@err					varchar(500)OUTPUT
AS


BEGIN

	SELECT [idSolicitud]
		,[idTipoobjeto]
		,[idTipoSolicitud]
		,[idClase]
		,[rfcEmpresa]
		,[idCliente]
		,[numeroContrato]
		,[idObjeto]
		,[idSolicitudObjetoEvidencia]
		,[idFileServer]
	FROM [Solicitud].[documento].[SolicitudObjetoEvidencia]
	WHERE idSolicitud = @idSolicitud 
		AND idClase = @idClase
		AND rfcEmpresa = @rfcEmpresa
		AND idCliente = @idCliente
		AND numeroContrato = @numeroContrato
		AND idTipoObjeto = @idTipoObjeto
		AND idObjeto = @idObjeto
  
END
go

