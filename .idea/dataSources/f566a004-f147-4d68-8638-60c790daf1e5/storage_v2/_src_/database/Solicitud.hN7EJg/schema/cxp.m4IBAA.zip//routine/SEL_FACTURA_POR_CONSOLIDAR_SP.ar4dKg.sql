

-- =============================================
-- Author: Adolfo Martinez
-- Create date: 08/04/2020
-- Description: Obtener el detalle de la solicitud por facturas pendientes por consolidar
-- [cxp].[SEL_FACTURA_POR_CONSOLIDAR_SP] 421, 'Servicio', 'Automovil','TPC1208066U6',115,'00001-DEMO', 6119
-- [cxp].[SEL_FACTURA_POR_CONSOLIDAR_SP] 180, 'Imagen', 'Automovil','ASE0508051B6',185,'43', 6119
-- =============================================
CREATE  PROCEDURE [cxp].[SEL_FACTURA_POR_CONSOLIDAR_SP]
@idSolicitud INT,
@idTipoSolicitud VARCHAR(10),
@idClase VARCHAR(10),
@rfcEmpresa	VARCHAR(13),
@idCliente INT,
@numeroContrato	VARCHAR(50),
@idUsuario INT,
@err VARCHAR(8000) = '' OUTPUT	
AS

BEGIN

	IF EXISTS(SELECT 1 FROM solicitud.Sel_totales_cotizacion_vw SC
			LEFT JOIN solicitud.[cxp].[SolicitudCotizacionFacturaDetalle] SFC ON SFC.idSolicitud = SC.idSolicitud AND  SFC.idCotizacion = SC.idCotizacion
			WHERE sc.idSolicitud=@idSolicitud
			AND sc.idTipoSolicitud=@idTipoSolicitud
			AND sc.idClase=@idClase
			AND sc.rfcEmpresa=@rfcEmpresa
			AND sc.idCliente=@idCliente
			AND sc.numeroContrato=@numeroContrato
			--AND SC.idEstatusCotizacionPartida='APROBADA'
			AND SFC.idCotizacion IS NULL)
		BEGIN
			SELECT 'Pendientes' msg, 0 estatus
		END
	ELSE
		BEGIN
			SELECT 'Cargadas' msg, 1 estatus
		END

END
go

