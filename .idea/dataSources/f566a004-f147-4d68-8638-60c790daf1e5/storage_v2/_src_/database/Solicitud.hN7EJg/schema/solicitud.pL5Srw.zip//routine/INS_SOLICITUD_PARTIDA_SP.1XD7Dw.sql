-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 25-09-2019
-- Description: Guarda las partidas por solicitud faltantes cuando se crea una nueva cotización y debe asignarse a taller
-- =============================================
CREATE PROCEDURE solicitud.INS_SOLICITUD_PARTIDA_SP
	@idUsuario INT,
	@partidas XML,
	@err VARCHAR(MAX) = NULL OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		BEGIN TRANSACTION INSPS
			DECLARE @tablePartidas TABLE (
				idSolicitud INT,
				idTipoSolicitud  VARCHAR(10),
				idClase VARCHAR(10),
				rfcEmpresa VARCHAR(13),
				idCliente INT,
				numeroContrato VARCHAR(50),
				idObjeto INT,
				idTipoObjeto INT,
				idPartida INT,
				cantidad FLOAT,
				costoInicial FLOAT,
				ventaInicial FLOAT,
				idEstatusSolicitudPartida VARCHAR(10),
				idUsuario INT
			)
			INSERT INTO @tablePartidas (idSolicitud, idTipoSolicitud, idClase, rfcEmpresa, idCliente, numeroContrato, idObjeto, idTipoObjeto, idPartida, cantidad, costoInicial, ventaInicial, idEstatusSolicitudPartida, idUsuario)
			SELECT p.col.value('idSolicitud[1]', 'int')
				, p.col.value('idTipoSolicitud[1]', 'VARCHAR(50)')
				, p.col.value('idClase[1]', 'VARCHAR(50)')
				, p.col.value('rfcEmpresa[1]', 'VARCHAR(50)')
				, p.col.value('idCliente[1]', 'int')
				, p.col.value('numeroContrato[1]', 'VARCHAR(50)')
				, p.col.value('idObjeto[1]', 'int')
				, p.col.value('idTipoObjeto[1]', 'int')
				, p.col.value('idPartida[1]', 'int')
				, p.col.value('cantidad[1]', 'FLOAT')
				, p.col.value('costoInicial[1]', 'FLOAT')
				, p.col.value('ventaInicial[1]', 'FLOAT')
				, 'ENESPERA'
				, @idUsuario
			FROM @partidas.nodes('partidas/partida') AS p(col)

			MERGE solicitud.SolicitudPartida AS TARGET
			USING (SELECT idSolicitud,
				idTipoSolicitud,
				idClase,
				rfcEmpresa,
				idCliente,
				numeroContrato,
				idObjeto,
				idTipoObjeto,
				idPartida,
				cantidad,
				costoInicial,
				ventaInicial,
				idEstatusSolicitudPartida,
				idUsuario FROM @tablePartidas) AS SOURCE
			ON TARGET.idSolicitud = SOURCE.idSolicitud
			AND TARGET.idTipoSolicitud = SOURCE.idTipoSolicitud
			AND TARGET.idClase = SOURCE.idClase
			AND TARGET.rfcEmpresa = SOURCE.rfcEmpresa
			AND TARGET.idCliente = SOURCE.idCliente
			AND TARGET.numeroContrato = SOURCE.numeroContrato
			AND TARGET.idObjeto = SOURCE.idObjeto
			AND TARGET.idTipoObjeto = SOURCE.idTipoObjeto
			AND TARGET.idPartida = SOURCE.idPartida
			WHEN NOT MATCHED BY TARGET THEN
				INSERT (idSolicitud, idTipoSolicitud, idClase, rfcEmpresa, idCliente, numeroContrato, idObjeto, idTipoObjeto, idPartida, cantidad, costoInicial, ventaInicial, idEstatusSolicitudPartida, idUsuario)
				VALUES (idSolicitud, idTipoSolicitud, idClase, rfcEmpresa, idCliente, numeroContrato, idObjeto, idTipoObjeto, idPartida, cantidad, costoInicial, ventaInicial, idEstatusSolicitudPartida, idUsuario)
			WHEN MATCHED THEN
				UPDATE SET
				TARGET.cantidad = TARGET.cantidad + SOURCE.cantidad;

		COMMIT TRANSACTION INSPS
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION INSPS
		SELECT @err = ERROR_NUMBER() + ' ' + ERROR_MESSAGE() + ' ' + ERROR_STATE()
	END CATCH
	
END
go

