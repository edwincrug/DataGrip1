-- =============================================
-- Author:		Martin Pacheco
-- Create date: 
-- Description:	Obtiene ordenes por solicitud y sus partidas.
/*
select * from solicitud.solicitud.solicitud where idSolicitud=1082
exec [solicitud].[SEL_COTIZACION_PARTIDAS_MULTIPLE_SP] 1082,'Instala','Automovil','AAN910409135',218,'0001',6282,null

*/
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_COTIZACION_PARTIDAS_MULTIPLE_SP]
	@idSolicitud		INT,
	@idTipoSolicitud	VARCHAR(10),
	@idClase			VARCHAR(10) = '',
	@rfcEmpresa			VARCHAR(13) = '',
	@idCliente			INT,
	@numeroContrato		VARCHAR(50) = '',
	@idUsuario			INT,
	@err				VARCHAR(500) OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	;WITH [OrdenesCTE] AS (
		SELECT
				[SC].[idCotizacion],
				[SC].[idSolicitud],
				[SC].[numeroCotizacion],
				[PE].[rfcProveedor],
				[PE].[idProveedorEntidad],
				[PE].[nombreComercial],
				[PE].[personaContacto],
				[PE].[telefono],
				[PE].[email],
				[SCP].[cantidad],
				[SCP].[idPartida],
				(	SELECT	[valor] 
					FROM	[Partida].[partida].[PartidaPropiedadGeneral] 
					WHERE	[idPartida] = [SCP].[idPartida] AND [idPropiedadGeneral] = 1 
				) AS [nombrePartida],
				(	SELECT	[valor] 
					FROM	[Partida].[partida].[PartidaPropiedadGeneral] 
					WHERE	[idPartida] = [SCP].[idPartida] AND [idPropiedadGeneral] = 4			
				) AS [NoParte],
				(	SELECT	[valor] 
					FROM	[Partida].[partida].[PartidaPropiedadGeneral] 
					WHERE	[idPartida] = [SCP].[idPartida] AND [idPropiedadGeneral] = 6 
				) AS [descripcionPartida],
				[SCP].[costo],
				[SCP].[venta],
				[SCP].[idEstatusCotizacionPartida] AS [Estatus],
				[objeto].[objeto].[getPropiedadObjeto]([SCP].idObjeto, 'VIN', 'Clase',@idClase) as 'VIN',
				[objeto].[objeto].[getPropiedadObjeto]([SCP].idTipoObjeto, 'Marca',    'tipoClase',@idClase) as 'Marca',
				[objeto].[objeto].[getPropiedadObjeto]([SCP].idTipoObjeto, 'Submarca', 'tipoClase',@idClase) as 'Submarca',
				[objeto].[objeto].[getPropiedadObjeto]([SCP].idTipoObjeto, 'Clase',    'tipoClase',@idClase) as 'Clase'
				,SSO.numeroOrden
				,SOL.numero
		FROM	[solicitud].[SolicitudCotizacion] AS [SC]
		INNER	JOIN [solicitud].[SolicitudCotizacionPartida] AS [SCP] ON [SC].[idSolicitud] = [SCP].[idSolicitud] AND [SC].[idCotizacion] = [SCP].[idCotizacion]
		INNER	JOIN [Proveedor].[proveedor].[ProveedorEntidad] AS [PE]	ON [PE].[rfcProveedor] = [SCP].[rfcProveedor] AND [PE].[idProveedorEntidad]	= [SCP].[idProveedorEntidad]
		
		INNER   JOIN [solicitud].[solicitud].[SolicitudObjeto] AS SSO ON SSO.idSolicitud =SCP.idSolicitud AND SSO.idTipoSolicitud=SCP.idTipoSolicitud
		AND     SSO.idClase=SCP.idClase AND SSO.rfcEmpresa=SCP.rfcEmpresa AND SSO.idCliente=SCP.idCliente AND SSO.numeroContrato=SCP.numeroContrato
		AND     SSO.idTipoObjeto=SCP.idTipoObjeto AND SSO.idObjeto=SCP.idObjeto
		
		INNER   JOIN [solicitud].[solicitud].[Solicitud] AS SOL ON SOL.idSolicitud =SCP.idSolicitud AND SOL.idTipoSolicitud=SCP.idTipoSolicitud
		AND     SOL.idClase=SCP.idClase AND SOL.rfcEmpresa=SOL.rfcEmpresa AND SSO.idCliente=SOL.idCliente AND SOL.numeroContrato=SCP.numeroContrato
		
		WHERE 	[SC].[idSolicitud]			= @idSolicitud
		AND     [SC].[idTipoSolicitud]		= @idTipoSolicitud
		AND		[SC].[idClase]				= @idClase 
		AND		[SC].[rfcEmpresa]			= @rfcEmpresa 
		AND		[SC].[idCliente]			= @idCliente 
		AND		[SC].[numeroContrato]		= @numeroContrato) 
	SELECT
		[CTE].[idCotizacion],
		[CTE].[idSolicitud],
		[CTE].[numero],
		[CTE].[numeroOrden],
		[CTE].[VIN],
		[CTE].[Marca],
		[CTE].[Submarca],
		[CTE].[Clase],
		[CTE].[numeroCotizacion],
		[CTE].[rfcProveedor],
		[CTE].[idProveedorEntidad],
		[CTE].[nombreComercial],
		[CTE].[personaContacto],
		[CTE].[telefono],
		[CTE].[email],
		[CTE].[cantidad],
		[CTE].[idPartida],
		[CTE].[nombrePartida],
		[CTE].[NoParte],
		[CTE].[descripcionPartida],
		[CTE].[costo],
		[CTE].[venta],
		[CTE].[Estatus]
	FROM [OrdenesCTE] AS [CTE]

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END

/*
select * from solicitud.solicitud.SolicitudObjeto
select * from 

*/

--USE [Solicitud]
go

