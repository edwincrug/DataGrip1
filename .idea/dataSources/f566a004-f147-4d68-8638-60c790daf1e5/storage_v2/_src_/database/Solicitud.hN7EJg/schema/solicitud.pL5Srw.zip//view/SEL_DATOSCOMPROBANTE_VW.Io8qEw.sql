

create view [solicitud].[SEL_DATOSCOMPROBANTE_VW]
as
	select	b.* ,
			a.fechaAlta,
			a.idUsuario
	from	solicitud.ComprobanteRecepcion a,
			solicitud.ComprobanteRecepcionPropiedades b
	where	a.idComprobanteRecepcion=b.idComprobanteRecepcion
	and		a.idSolicitud=b.idSolicitud
	and     a.idTipoSolicitud=b.idTipoSolicitud
	and     a.idClase=b.idClase
	and     a.rfcEmpresa=b.rfcEmpresa
	and     a.idCliente=b.idCliente
	and     a.numeroContrato=b.numeroContrato
	and		a.idObjeto=b.idObjeto
	and     a.idTipoObjeto=b.idTipoObjeto
	and		a.idProveedorEntidad=b.idProveedorEntidad
	and     a.rfcProveedor=b.rfcProveedor
	and     a.version=b.version
go

