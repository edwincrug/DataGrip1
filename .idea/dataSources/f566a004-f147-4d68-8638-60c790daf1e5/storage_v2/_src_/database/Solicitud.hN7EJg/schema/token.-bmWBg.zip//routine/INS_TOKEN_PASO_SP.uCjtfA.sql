-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<04/07/2019>
-- Description:	    <Alta de los tokens>
-- =============================================
-- EXEC [token].[INS_TOKEN_PASO_SP] 75, 'EnEspera',55
-- =============================================
CREATE PROCEDURE [token].[INS_TOKEN_PASO_SP]
(
    @idSolicitud        int
    ,@idPaso            [varchar](50)
	,@idUsuario			int
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
DECLARE
@error                  int=0
,@idFaseExistente       [varchar](20)=NULL
,@idPasoExistente       [varchar](50)=NULL
,@tipoPaso              [varchar](8)=NULL
,@idTipoToken           int=0
,@idTokenExistente      int=0
,@idTokenNuevo          int=0
,@token                 varchar(8) = NULL

BEGIN

    SELECT 
        @idFaseExistente = SF.[idFase] 
        ,@idPasoExistente = SF.[idPaso]
        ,@tipoPaso = SF.[tipoPaso]
    FROM [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud) SF

    --Obtenemos el identificador del tipo de paso Paso o Contrato
    SELECT @idTipoToken = id
    FROM [Solicitud].[token].[tipoToken] 
    WHERE descripcion = @tipoPaso

    IF(@idPasoExistente = @idPaso)
    BEGIN
        --Valida que sean diferentes los usuario que generan los tokens
        --Pero puede aplicarlos un solo usuario
        SELECT 
            @idTokenExistente = TT.idToken
            ,@token =TT.token
        FROM [Solicitud].[token].[Token] TT
        INNER JOIN [Solicitud].[token].[TokenSolicitud] TTS
            ON TT.idToken = TTS.idToken
        INNER JOIN [Solicitud].[token].[tipoToken] TTT
            ON TT.idTipoToken = TTT.id
        WHERE TT.estatus = 1
            AND TT.idPaso = @idPaso
            AND TTS.idSolicitud = @idSolicitud
            AND TTT.id = @idTipoToken
            AND TT.idUsuarioCrea = @idUsuario

        IF(@idTokenExistente > 0)
        BEGIN
            SET @err = 'El usuario ya generó un token para la orden en ese paso. Token: ' + @token
        END
        ELSE
        BEGIN
            BEGIN TRAN altaToken

                BEGIN TRY

                    SET @token = substring(replace(newid(), 'AES', ''), 1, 6)

                    INSERT INTO [Solicitud].[token].[Token]
                    (
                        token
                        ,fechaCrea
                        ,idUsuarioCrea
                        ,fechaUso
                        ,idUsuarioUsa
                        ,idPaso
                        ,idTipoToken
                        ,estatus
                    )VALUES
                    (
                        @token
                        ,GETDATE()
                        ,@idUsuario
                        ,NULL
                        ,NULL
                        ,@idPasoExistente
                        ,@idTipoToken
                        ,1
                    )

                    SET @idTokenNuevo = @@IDENTITY

                    INSERT INTO [Solicitud].[token].[TokenSolicitud]
                    (
                        idToken
                        ,idSolicitud
                    )VALUES
                    (
                        @idTokenNuevo
                        ,@idSolicitud
                    )

                    COMMIT TRAN altaToken

                END TRY
                BEGIN CATCH
                    ROLLBACK TRAN altaToken
                    SET @err = 'Ocurrio un error al generar el token.'
                    SET @idTokenNuevo = 0
                    SET @token = NULL
                END CATCH
        END
    END
    ELSE
    BEGIN
        SET @err = 'La solicitud esta finalizada o se encuentra en una paso diferente.'
    END

    SELECT @idTokenNuevo idToken, @token token
END
go

