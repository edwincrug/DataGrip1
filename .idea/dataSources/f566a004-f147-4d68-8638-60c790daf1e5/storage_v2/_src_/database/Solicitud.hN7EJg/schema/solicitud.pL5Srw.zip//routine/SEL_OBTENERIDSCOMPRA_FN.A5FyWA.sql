
-- =============================================
-- Author:		<Josè Luis Lozada Guerrero>
-- Create date: <27/04/2020>
-- Description:	<Funcion para obtener lod ids de compra de una orden
-- =============================================
/*
	SELECT [solicitud].[SEL_OBTENERIDSCOMPRA_FN](98,'Imagen','Automovil','ASE0508051B6',185,'43')
	
	select * from solicitud.cxc.Factura where idSolicitud=98
*/
CREATE FUNCTION [solicitud].[SEL_OBTENERIDSCOMPRA_FN]
(
	@idSolicitud		INT,
	@idTipoSolicitud	VARCHAR(10),
	@idClase			VARCHAR(10),
	@rfcEmpresa			VARCHAR(13),
	@idCliente			INT,
	@numeroContrato		VARCHAR(50)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @tx TABLE(idd INT IDENTITY(1,1),OTE_IDENT INT)
	DECLARE @idsCompra VARCHAR(MAX)='',@v_idd INT,@v_OTE_IDENT INT

	INSERT INTO @tx(OTE_IDENT)
	SELECT	OTE_IDENT
	FROM	[Solicitud].[cxc].[FacturaBPRO] sp
	WHERE	sp.idSolicitud		= @idSolicitud
	AND		sp.idTipoSolicitud	= @idTipoSolicitud
	AND		sp.idClase			= @idClase
	AND		sp.rfcEmpresa		= @rfcEmpresa
	AND		sp.idCliente		= @idCliente
	AND		sp.numeroContrato	= @numeroContrato
	ORDER BY OTE_IDENT ASC

	WHILE EXISTS  (SELECT 1 FROM @tx)
		BEGIN
			SELECT TOP 1 @v_idd=idd,@v_OTE_IDENT=OTE_IDENT FROM @tx
			--============================================================

			SET @idsCompra=@idsCompra+CAST(@v_OTE_IDENT AS VARCHAR) + ','
			--============================================================
			DELETE FROM @tx WHERE idd=@v_idd
		END
	
	IF LEN(@idsCompra)>0
		BEGIN
			IF SUBSTRING(@idsCompra,LEN(@idsCompra),1)=','
				SET @idsCompra=SUBSTRING(@idsCompra,1,LEN(@idsCompra)-1)
		END

	RETURN @idsCompra

	 
END

go

