-- =============================================    
-- Author: José Luis Lozada Guerrero
-- Create date: 05-07-2019
-- Description: Inserta valores seleccionados del comprobante de recepcion
-- ============== Versionamiento ================  
/*
 DECLARE @salida varchar(max) ='' ;    
 EXEC [solicitud].[INS_COMPROBANTE_RECEPCION_SP] 10401,'Imagen','Automovil','ASE0508051B6',185,'43',11293,631,586,'GTR120112LZ1',    
    '<propiedades><propiedad><valor>true</valor><idPropiedad>1</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>2</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>3</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>4</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>5</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>6</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>7</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>8</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>9</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>10</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>11</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>12</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>13</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>14</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>15</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>16</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>17</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>18</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>19</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>20</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>21</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>22</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>23</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>24</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>25</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>26</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>27</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>true</valor><idPropiedad>28</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>30</valor><idPropiedad>29</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Catalogo</idTipoValor></propiedad><propiedad><valor/><idPropiedad>34</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor/><idPropiedad>35</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor/><idPropiedad>36</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor/><idPropiedad>37</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor/><idPropiedad>38</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>0</valor><idPropiedad>39</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>50000</valor><idPropiedad>33</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>263627</valor><idPropiedad>42</idPropiedad><propiedadDesc>clase</propiedadDesc><fechaCaducidad/><idTipoValor>Unico</idTipoValor></propiedad></propiedades>'
	,3652,   
     @salida OUTPUT;    
 SELECT @salida AS salida;  
 
 */

CREATE PROCEDURE [solicitud].[INS_COMPROBANTE_RECEPCION_SP]	
@idSolicitud		INT,
@idTipoSolicitud	VARCHAR(10),
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@idObjeto			NCHAR(20),
@idTipoObjeto		NCHAR(20),		
@idProveedorEntidad INT,
@rfcProveedor		VARCHAR(13),	
@propiedades		XML, 
@idUsuario			INT,
@err				NVARCHAR(500) OUTPUT  	
AS
BEGIN

	DECLARE @idComprobanteRecepcion INT
	DECLARE @idFaseActual           VARCHAR(20)
    DECLARE @idPasoActual           VARCHAR(50)
	DECLARE @version				INT
	DECLARE @tbl_propiedades AS TABLE(	_row					INT IDENTITY(1,1),       
										propiedadDesc			VARCHAR(250),    
										idPropiedad				INT, 
										valor                   VARCHAR(500),    
										fechaCaducidad			DATETIME,    
										activo                  BIT,    
										idTipoValor				VARCHAR(250))    
    
	BEGIN TRY
		BEGIN TRANSACTION; 

		SELECT	@idFaseActual            = sol.idFase,
				@idPasoActual            = sol.idPaso
		FROM [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud) sol
		
	print '1'
		INSERT INTO @tbl_propiedades(propiedadDesc,idPropiedad,valor,fechaCaducidad,idTipoValor)    
		SELECT	ParamValues.col.value('propiedadDesc[1]','nvarchar(250)'),    
				ParamValues.col.value('idPropiedad[1]','int'),    
				ParamValues.col.value('valor[1]','nvarchar(500)'),    
				ParamValues.col.value('fechaCaducidad[1]','datetime'),    
				ParamValues.col.value('idTipoValor[1]','nvarchar(250)')    
		FROM	@propiedades.nodes('propiedades/propiedad') AS ParamValues(col)   


		SET @version =(	SELECT ISNULL(MAX([version])+1,1) 
						FROM	solicitud.ComprobanteRecepcion 
						WHERE	idSolicitud			=@idSolicitud
						AND		idTipoSolicitud		=@idTipoSolicitud
						AND     idClase				=@idClase
						AND     rfcEmpresa			=@rfcEmpresa
						AND     idCliente			=@idCliente
						AND     numeroContrato		=@numeroContrato
						AND     idObjeto			=@idObjeto
						AND     idTipoObjeto		=@idTipoObjeto
						AND     idProveedorEntidad	=@idProveedorEntidad
						AND     rfcProveedor		=@rfcProveedor )
print '2'
		INSERT INTO solicitud.ComprobanteRecepcion(	idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idObjeto,
													idTipoObjeto,idProveedorEntidad,rfcProveedor,[version],fechaAlta,idUsuario)
		VALUES(	@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,
				@idObjeto,@idTipoObjeto,@idProveedorEntidad,@rfcProveedor,@version,GETDATE(),@idUsuario)

		SET @idComprobanteRecepcion=@@IDENTITY

		print '3'
		INSERT INTO solicitud.ComprobanteRecepcionPropiedades (	idComprobanteRecepcion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,
																idObjeto,idTipoObjeto,idProveedorEntidad,rfcProveedor,[version],idPropiedadClase,idAgrupacion,valor)

		SELECT	@idComprobanteRecepcion,@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idObjeto,@idTipoObjeto,
				@idProveedorEntidad,@rfcProveedor,@version,a.idPropiedad, 
				ISNULL((SELECT	TOP 1
								idAgrupacion 
						FROM	solicitud.ComprobantePropiedades 
						WHERE	idPropiedadClase	=a.idPropiedad),NULL),
				a.valor
		FROM	@tbl_propiedades a

		DECLARE @kmObjeto FLOAT = 0
		DECLARE @kmComprobante INT = 0
		DECLARE @GPSID VARCHAR(200) = (SELECT [Objeto].[objeto].[getPropiedadObjeto]  (@idObjeto, 'ID GPS', 'clase',@idClase))

		IF NOT EXISTS(SELECT 1 FROM Cliente.cliente.Contrato
			WHERE rfcEmpresa = @rfcEmpresa 
			AND idCliente = @idCliente 
			AND numeroContrato = @numeroContrato 
			AND idClase = @idClase
			AND geolocalizacion = 1)

			BEGIN

				DELETE Objeto.objeto.ObjetoPropiedadClase 
				WHERE idClase = @idClase 
				AND idTipoObjeto = @idTipoObjeto 
				AND idObjeto = @idObjeto 
				AND idPropiedadClase = (SELECT idPropiedadClase FROM Objeto.objeto.PropiedadClase WHERE agrupador = 'KilometrajeAct')

print '4'

				INSERT INTO Objeto.objeto.ObjetoPropiedadClase
				select 
					@idClase
					,(SELECT idPropiedadClase FROM Objeto.objeto.PropiedadClase WHERE agrupador = 'KilometrajeAct')
					,@idTipoObjeto
					,@idObjeto
					,TP.valor
					,@idUsuario
					,1
				from  @tbl_propiedades TP
				INNER JOIN [solicitud].[ComprobantePropiedades] CP ON CP.idPropiedadClase = TP.idPropiedad
				WHERE CP.abreviatura = 'tab_Odometro'
			END
		ELSE
			BEGIN
				SET @kmObjeto = (SELECT ISNULL(O.valor,0) FROM Objeto.objeto.ObjetoPropiedadClase O
				WHERE O.idClase = @idClase 
				AND O.idTipoObjeto = @idTipoObjeto 
				AND O.idObjeto = @idObjeto 
				AND O.idPropiedadClase = (SELECT idPropiedadClase FROM Objeto.objeto.PropiedadClase WHERE agrupador = 'KilometrajeAct'))

				SET @kmComprobante =(SELECT ISNULL(TP.valor,0) FROM  @tbl_propiedades TP
					INNER JOIN [solicitud].[ComprobantePropiedades] CP ON CP.idPropiedadClase = TP.idPropiedad
				WHERE CP.abreviatura = 'tab_Odometro')

				IF(@kmComprobante IS NOT NULL OR @kmComprobante != 0 OR @kmComprobante != '')
					BEGIN
						IF(@GPSID IS NULL OR @GPSID = '0' OR @GPSID = '')
							BEGIN
								DELETE Objeto.objeto.ObjetoPropiedadClase 
								WHERE idClase = @idClase 
								AND idTipoObjeto = @idTipoObjeto 
								AND idObjeto = @idObjeto 
								AND idPropiedadClase = (SELECT idPropiedadClase FROM Objeto.objeto.PropiedadClase WHERE agrupador = 'KilometrajeAct')
print '5'
								INSERT INTO Objeto.objeto.ObjetoPropiedadClase
								select 
									@idClase
									,(SELECT idPropiedadClase FROM Objeto.objeto.PropiedadClase WHERE agrupador = 'KilometrajeAct')
									,@idTipoObjeto
									,@idObjeto
									,TP.valor
									,@idUsuario
									,1
								from  @tbl_propiedades TP
								INNER JOIN [solicitud].[ComprobantePropiedades] CP ON CP.idPropiedadClase = TP.idPropiedad
								WHERE CP.abreviatura = 'tab_Odometro'
							END
					END
			END

		DECLARE @idDocumento INT = (SELECT ISNULL(TP.valor,0) FROM  @tbl_propiedades TP
					INNER JOIN [solicitud].[ComprobantePropiedades] CP ON CP.idPropiedadClase = TP.idPropiedad
		WHERE CP.abreviatura = 'tab_Evidencia')

		IF(@idDocumento != 0 OR @idDocumento != '')
			BEGIN
				DECLARE @idSolicitudObjetoEvidencia INT
				IF EXISTS(SELECT 1 FROM [Solicitud].documento.SolicitudObjetoEvidencia WHERE idSolicitud=@idSolicitud)
						BEGIN
							SET @idSolicitudObjetoEvidencia = (SELECT MAX(idSolicitudObjetoEvidencia) + 1 FROM [Solicitud].documento.SolicitudObjetoEvidencia WHERE idSolicitud=@idSolicitud)
						END 
					ELSE
						BEGIN
							SET @idSolicitudObjetoEvidencia = 1
						END
print '6'
				INSERT INTO [Solicitud].documento.SolicitudObjetoEvidencia(
					idSolicitud
					,idTipoObjeto
					,idClase
					,rfcEmpresa
					,idCliente
					,numeroContrato
					,idTipoSolicitud
					,idObjeto
					,idSolicitudObjetoEvidencia
					,idFileServer							
				) VALUES(
						@idSolicitud
					,@idTipoObjeto
					,@idClase
					,@rfcEmpresa
					,@idCliente							
					,@numeroContrato
					,@idTipoSolicitud
					,@idObjeto
					,@idSolicitudObjetoEvidencia
					,@idDocumento
				)
		END	

		SELECT	@idComprobanteRecepcion AS 'idComprobanteRecepcion',
				CASE @idPasoActual WHEN 'CitaConfirmada' THEN 1 ELSE 0 END 'avanzaOrden',
				@version 'version',
				CASE WHEN @GPSID IS NULL OR @GPSID = '0' OR @GPSID = '' THEN CONVERT(Bit, 0)
					ELSE CASE WHEN ABS(ISNULL(@kmComprobante,0)-ISNULL(@kmObjeto,0)) <= 100 THEN CONVERT(Bit, 0) ELSE CONVERT(Bit, 1) END 
				END AS validaKM
    COMMIT TRANSACTION ;
	END TRY
	BEGIN CATCH
		PRINT ERROR_NUMBER() 
		PRINT ERROR_MESSAGE()
		ROLLBACK TRANSACTION
		--set @err = ERROR_MESSAGE();
		SET @err ='Se produjo un error al guardar las propiedades del comprobante de recepcion [SOLICITUD.INS_COMPROBANTE_RECEPCION_SP]'
	END CATCH
    
END
go

