
-- =============================================
-- Author:		<Alan Rosales Chávez>
-- Create date: <290/05/2020>
-- Description:	<Procesamos avanzar orden con base a estatus de compras BPRO>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	
	*- Testing...
	
    EXEC [compraBPRO].[UPD_SOLICITUD_AVANZAORDEN_BPRO_SP]
		@ordenCompra = 'AU-ZM-NZA-OT-PE-17831'
		,@pasoAvanza = 'Entrega'
		,@faseAvanza = 'Entrega'

*/
CREATE PROCEDURE [compraBPRO].[UPD_SOLICITUD_AVANZAORDEN_BPRO_SP]
	@ordenCompra	varchar(50),
	@pasoAvanza		varchar(50), --paso final
	@faseAvanza		varchar(50)  --fase final
AS
BEGIN
	
	/*OBTENEMOS LOS DATOS DE LA SOLCIITUD CON BASE A LA ORDEN DE COMPRA BPRO*/
	declare
		@idSolicitud		int
		,@rfcEmpresa		varchar(13)
		,@idCliente			int
		,@numeroContrato	varchar(50)
		,@idFaseActual		varchar(20)
		,@idPasoActual		varchar(20)
		,@salida			varchar(500) = ''

	declare @pasos as table(
		row	int identity(1,1)
		,idFase varchar(20)
		,idPaso varchar(50)
	)

	/*INICIO DE BLOQUE DE PASOS DINAMICOS*/
	INSERT INTO @pasos
	SELECT  
		T.idFase  
		,T.idPaso  
	FROM 
	(  
		SELECT   
			[idPaso]  
			,[idFase]  
			,[idClase]  
			,[idTipoSolicitud]  
			,[nombre]  
			,[descripcion]  
			,[orden]  
			,[color]  
			,CAST([tiempoEstimado] AS time(0)) tiempoEstimado  
			,[procedimientoAlmacenado]  
			,[parametros]  
		FROM [Solicitud].[fase].[Paso]  
		WHERE idClase = 'Compra'  
		AND idTipoSolicitud = 'Compra'
    ) T  
	LEFT JOIN [fase].[Fase] F ON F.idFase = T.idFase  
	ORDER BY F.orden, T.orden  
	/*FIN DE BLOQUE DE PASOS DINAMICOS*/
	
	if exists (select 1 from compraBPRO.Solicitud where ltrim(rtrim(ppg_ordenCompra))=ltrim(rtrim(@ordenCompra)))
	begin
		--OBTENEMOS DATOS DE LA SOLICITUD
		select 
			@idSolicitud		=	bpro.idSolicitud
			,@rfcEmpresa		=	bpro.rfcEmpresa
			,@idCliente			=	bpro.idCliente
			,@numeroContrato	=	bpro.numeroContrato
		from compraBPRO.Solicitud bpro
		where ltrim(rtrim(bpro.ppg_ordenCompra)) = ltrim(rtrim(@ordenCompra))

		select 
			@idFaseActual = est.idFase
			,@idPasoActual = est.idPaso
		from fase.SolicitudEstatusPaso est 
		where 
			est.idSolicitud = @idSolicitud
			and est.fechaSalida is null

		--YA QUE TENEMOS EL PASO Y FASE ACTUAL, CORREMOS EL PROCESO DE AVANZAR ORDEN HASTA EL PASO Y FASE INDICADO.
		declare 
			@rowActual int
			,@rowFinal int
		set @rowActual = (select [row] from @pasos where idFase = @idFaseActual and idPaso = @idPasoActual)
		set @rowFinal = (select [row] from @pasos where idFase = @faseAvanza and idPaso = @pasoAvanza)

		print 'rowActual: ' + convert(varchar,@rowActual)
		print 'rowFinal: ' + convert(varchar,@rowFinal)

		--SI EL PASO ACTUAL ES MAYOR AL FINAL, NO PROCESAMOS NADA
		if (@pasoAvanza = 'Cancelacion' and @faseAvanza='Cancelacion')
		BEGIN
			--CANCELAMOS
			set @salida = ''
			exec solicitud.UPD_SOLICITUD_CANCELA
				@idSolicitud
				,'Compra'
				,'Compra'
				,@rfcEmpresa
				,@idCliente
				,@numeroContrato
				,3132
				,@salida out
		END
		ELSE
		BEGIN
			IF (@rowActual<@rowFinal)
			BEGIN
				--AVANZAMOS LA ORDEN HASTA LLEGAR AL PASO FINAL
				PRINT 'PROCESAMOS'
				WHILE (@rowActual<@rowFinal)
				BEGIN
					print 'avanzamos: ' + convert(varchar,@idSolicitud)
					set @salida = ''
					Exec solicitud.UPD_SOLICITUD_AVANZAORDEN_SP
						@idSolicitud
						,'Compra'
						,'Compra'
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,3132
						,@salida out
					set @rowActual = @rowActual+1
				END
			END
			ELSE
			BEGIN
				--NO SE PROCESA NADA
				PRINT 'NO PROCESAMOS'
			END
		END
	end
	else
	begin
		select 'La orden de compra no se encuentra registrada.'
	end
END
go

