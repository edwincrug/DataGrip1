
--use solicitud
-- =============================================
-- Author: Edgar Mendoza
-- Create date: 08/07/2020
-- Description:	Trae facturas cargadas de un proveedor
-- EXEC [cxp].[SEL_FACTURA_PROVEEDOR_SP] 'NFM0307091L9', 6119, ''
--select * from [cxp].[SolicitudCotizacionFacturaDetallePorConsolidar]
-- =============================================
CREATE PROCEDURE [cxp].[SEL_FACTURA_PROVEEDOR_SP]
@rfcProveedor VARCHAR(13),
@idUsuario INT,
@err VARCHAR(8000) = '' OUTPUT	
AS
BEGIN
	SELECT [uuid]
      ,[serie]
      ,[folio]
      ,[fechaFactura]
      ,[rfcEmisor]
      ,[rfcReceptor]
      ,[subtotal]
      ,[descuento]
      ,[traslado]
      ,[retencion]
      ,[total]
      ,[saldo]
      ,[idUsuario]
      ,[xml]
      ,[idDocumentoXml]
      ,[idDocumentoPdf]
	  ,(SELECT 
			valor 
		FROM Common.configuracion.Configuracion 
		WHERE nombre = 'fileServer') + (SELECT 
											path 
										FROM FileServer.documento.Documento 
										WHERE idDocumento = F.idDocumentoXml) AS pathXML
	  ,(SELECT 
			valor 
		FROM Common.configuracion.Configuracion 
		WHERE nombre = 'fileServer') + (SELECT 
											path 
										FROM FileServer.documento.Documento 
										WHERE idDocumento = F.idDocumentoPdf) AS pathPDF
	  ,CASE
		WHEN EXISTS(select SCFDC.uuid from [cxp].[SolicitudCotizacionFacturaDetallePorConsolidar] SCFDC
					inner join [cxp].[SolicitudCotizacionFacturaDetalle] SCFD on SCFD.uuid = SCFDC.uuid where SCFDC.uuid = F.uuid )
			THEN 'Consolidada'
			ELSE 'Normal'
	  END AS [tipoFactura]   
  FROM [Solicitud].[cxp].[Factura] F
  WHERE rfcEmisor = @rfcProveedor

END


go

