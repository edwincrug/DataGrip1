-- =============================================
-- Author:		Martin Pacheco
-- Create date: 20/05/2019
-- Description:	obtiene un listado de tipos de solicitud.
-- Test;		exec [solicitud].[SEL_TIPOSOLICITUD_SP] null
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_TIPOSOLICITUD_SP]
	@rfcEmpresa			VARCHAR(13) = '',
	@idCliente			INT,
	@numeroContrato		VARCHAR(50) = '',
	@idUsuario			int = null,
	@err				VARCHAR(8000) OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	;WITH [TipoSolCTE] AS (
		SELECT 
		    [TS].[idTipoSolicitud]
		  , [TS].[nombre]
		  , [TS].[descripcion]
		FROM [solicitud].[TipoSolicitud] AS [TS]
	)
	SELECT
		*
	FROM [TipoSolCTE]

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

