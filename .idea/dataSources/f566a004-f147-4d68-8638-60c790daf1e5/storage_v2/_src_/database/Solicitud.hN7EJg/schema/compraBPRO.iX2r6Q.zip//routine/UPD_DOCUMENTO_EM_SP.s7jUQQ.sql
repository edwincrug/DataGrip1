--use Solicitud
-- =============================================
-- Author:		<José Luis Lozada Guerrero>
-- Create date: <17/06/2020>
-- Description:	<guarda documento Estudio de Mercado >

/*
	EXEC [compraBPRO].UPD_DOCUMENTO_EM_SP 627,'Compra','Compra','ASE0508051B6',221,'49',22425,6282,null

*/
CREATE PROCEDURE [compraBPRO].[UPD_DOCUMENTO_EM_SP]
@idSolicitud			INT,
@idTipoSolicitud		VARCHAR(50) = '',
@idClase				VARCHAR(10) = '',
@rfcEmpresa				VARCHAR(13) = '',
@idCliente				INT = 0,
@numeroContrato			VARCHAR(50) = '',
@idDocumentoEM			INT,
@idUsuario				INT = 0,
@err					VARCHAR(8000) OUTPUT
AS
BEGIN

	UPDATE  compraBPRO.Solicitud 
	SET     idDocumentoEM   =@idDocumentoEM
	WHERE	idSolicitud		=@idSolicitud
	AND		idTipoSolicitud	=@idTipoSolicitud
	AND		idClase			=@idClase
	AND		rfcEmpresa		=@rfcEmpresa
	AND		idCliente		=@idCliente
	AND		numeroContrato	=@numeroContrato
END
go

