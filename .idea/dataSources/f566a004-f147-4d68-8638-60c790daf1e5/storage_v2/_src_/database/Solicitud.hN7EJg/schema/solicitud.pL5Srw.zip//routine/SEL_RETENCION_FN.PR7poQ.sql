-- =============================================
-- Author:		Edgar Mendoza
-- Create date: 24/08/2020
-- Description:	Función para traerr los días de una solicitud

-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	29/09/2020	Jluis Lozada	se agrego la parte del descuento

	--Test
*/

CREATE FUNCTION [solicitud].[SEL_RETENCION_FN]
(
	@UUID	VARCHAR(100),
	@idSolicitud	INT,
	@idCotizacion	INT,
	@idPartida		INT
)
RETURNS FLOAT
AS
BEGIN
	DECLARE @retencion FLOAT = 0;
	DECLARE @retencionPartida FLOAT;
	DECLARE @impuestos INT = 1
	DECLARE @tasa FLOAT

	DECLARE @tablaRetenciones TABLE (Fila_ INT IDENTITY(1,1), tasa FLOAT)

	INSERT INTO @tablaRetenciones
	SELECT FI.TASA FROM solicitud.cxp.FacturaImpuesto FI
	INNER JOIN solicitud.cxp.TipoFacturaImpuesto TFI ON TFI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto
	INNER JOIN [cxp].[Tipo] T ON T.idTipo = TFI.idTipo
	where uuidFactura = @UUID AND tfi.idTipo = 2

	WHILE ((SELECT COUNT(*) from @tablaRetenciones) >= @impuestos)

	BEGIN

		SET @tasa = (SELECT tasa FROM  @tablaRetenciones WHERE Fila_ = @impuestos)
		
		SET @retencionPartida = (	SELECT	(costo-ISNULL(de.descuentoVenta,0)) * cantidad * @tasa 
									FROM	solicitud.solicitud.SolicitudCotizacionPartida pa
									LEFT JOIN solicitud.solicitud.SolicitudCotizacionPartidaDescuento de ON pa.idSolicitud=de.idSolicitud AND pa.idCotizacion=de.idCotizacion AND pa.idPartida=de.idPartida
									WHERE	pa.idSolicitud	= @idSolicitud 
									AND		pa.idCotizacion = @idCotizacion 
									AND		pa.idPartida	= @idPartida)

		SET @retencion = @retencion + @retencionPartida

		SET @impuestos = @impuestos + 1
	END
	
	
	RETURN @retencion;
END



go

