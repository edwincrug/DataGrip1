--[solicitud].[SEL_REGLA_SP]
CREATE PROCEDURE [solicitud].[SEL_REGLA_SP]
AS
BEGIN
declare
	@idClase nvarchar(20) = 'Automovil'

select 
	*
from solicitud.Fase fas
inner join solicitud.Paso pas on fas.idFase = pas.idFase
inner join catalogo.TipoSolicitud tis on tis.idTipoSolicitud = pas.idTipoSolicitud
inner join Common.propiedad.Clase cla on cla.idClase = pas.idClase
left join solicitud.ReglaPaso reg on 
	--INTEGRIDAD
	reg.idPaso = pas.idPaso 
	and reg.idFase = pas.idFase
	and reg.idClase = pas.idClase
	and reg.idTipoSolicitud = pas.idTipoSolicitud

--OBTENEMOS LAS REGLAS PARA ROL
left join solicitud.ReglaPasoRol rpr on rpr.idReglaPaso = reg.idReglaPaso

--SE DEFINEN UNION CON BASE A LAS REGLAS APLICABLES



where
	pas.idClase = @idClase	
order by
	fas.orden,
	pas.orden
END
go

