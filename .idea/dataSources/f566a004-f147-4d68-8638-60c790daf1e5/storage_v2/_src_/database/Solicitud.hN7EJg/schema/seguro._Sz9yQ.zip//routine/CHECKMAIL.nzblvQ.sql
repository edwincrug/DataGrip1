

CREATE PROCEDURE [seguro].[CHECKMAIL]
	-- Add the parameters for the stored procedure here
	@messageId			varchar(300),
	@numeroSerie		VARCHAR(100) = '',
	@numeroSiniestro	VARCHAR(50) = '',
	@tipo				VARCHAR(50) = '',
	@from				VARCHAR(max),
	@date				VARCHAR(max),
	@subject			VARCHAR(max),
	--@html				VARCHAR(max),
	@comentario			VARCHAR(MAX),
	@err				VARCHAR(200) OUTPUT
AS
BEGIN
	BEGIN TRY
		
		SET  @err = ''
		INSERT INTO [seguro].[SolicitudCorreo]
			([messageId],[numeroSerie],[numeroSiniestro],[tipo],[from],[date],[subject],[comentario],[procesado])
		VALUES
			(@messageId, @numeroSerie, @numeroSiniestro, @tipo, @from,GETDATE(),@subject,@comentario,0)
				
		Select 'Se escribió el mensaje: ' + @messageId as msj, 1 as ok;
	END TRY
	BEGIN CATCH
		set  @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
		select @err as msj, 0 as ok;
	END CATCh

	PRINT 'OUT = ' +  @err
	RETURN
END
go

