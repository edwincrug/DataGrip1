
-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
/*
EXEC [solicitud].[INS_PARTIDASCOTIZACION_MANUAL_SP] @rfcProveedor = 'CME720930GM9', @idUsuario = 2927
*/

CREATE PROCEDURE [solicitud].[INS_PARTIDASCOTIZACION_MANUAL_SP]

@rfcProveedor VARCHAR(13),
@idUsuario INT = 2

AS

BEGIN
	BEGIN TRY 
		BEGIN TRANSACTION INS_PARTIDASCOTIZACION_SP

			DECLARE @solicitudes TABLE (row_ int IDENTITY(1,1), idSolicitud  INT)
			DECLARE @partidas TABLE (ROW_ INT IDENTITY(1,1), idPartida INT , costo FLOAT, venta FLOAT)
			DECLARE	@contadorSolicitud int = 1,
					@idSolicitud int,
					@rfcEmpresa VARCHAR(13),
					@numeroContrato VARCHAR(50),
					@idCliente INT,
					@idTipoSolicitud VARCHAR(10),
					@idClase VARCHAR(10),
					@idObjeto INT,
					@idTipoObjeto INT

			INSERT INTO @solicitudes
			SELECT idSolicitud
			FROM solicitud.solicitud.SolicitudObjeto
			WHERE numeroOrden IN (
'150-1898-11202'
,'150-1901-10950'
,'150-1906-11177'
,'150-1917-11368'
,'150-1926-11445'
,'150-1927-11444'
,'150-1935-10644'
,'150-1937-10623'
,'150-1942-10734'
,'150-1963-11316'
,'150-1965-11321'
,'150-1979-11256'
,'150-2019-11292'
,'150-2038-11287')

			select * from @solicitudes

			/**********UNIDAD 631*********/
			INSERT INTO @partidas VALUES (783890, 100, 125)

			/**********UNIDAD 117*********/
			--INSERT INTO @partidas VALUES (783882, 700, 875)
			--INSERT INTO @partidas VALUES (783887, 700, 875)
			--INSERT INTO @partidas VALUES (783896, 100, 125)


			WHILE(@contadorSolicitud <= (SELECT COUNT(idSolicitud) FROM @solicitudes) )
			BEGIN
				/**************************** SE INSERTA EN SOLICITUD PARTIDA ************/

				SELECT @idSolicitud = idSolicitud FROM @solicitudes where row_ = @contadorSolicitud

				SELECT
					@idTipoSolicitud = S.idTipoSolicitud
					,@idClase = S.idClase
					,@rfcEmpresa = S.rfcEmpresa
					,@numeroContrato = S.numeroContrato
					,@idCliente = S.idCliente
					,@idObjeto = SO.idObjeto
					,@idTipoObjeto = SO.idTipoObjeto
				FROM solicitud.solicitud S
				INNER JOIN solicitud.SolicitudObjeto SO ON SO.idSolicitud = S.idSolicitud
				WHERE S.idSolicitud = @idSolicitud

				select 'inserta solicitud partida'
	

				INSERT INTO [solicitud].[SolicitudPartida] 
					SELECT DISTINCT
						@idSolicitud
						,@idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,@idObjeto
						,@idTipoObjeto
						,P.idPartida
						,3
						,P.costo
						,P.venta
						,'ENESPERA'
						,@idUsuario
					FROM  @partidas P

				/************************************ INSERTA PARTIDAS EN COTIZACION ************************************/
				select 'partidas'
				INSERT INTO solicitud.SolicitudCotizacionPartida 
				
				SELECT DISTINCT
					idCotizacion
					,@idSolicitud
					,@idTipoSolicitud
					,@idClase
					,@rfcEmpresa
					,@numeroContrato
					,@idCliente
					,@rfcProveedor
					,SP.idProveedorEntidad
					,@idObjeto
					,@idTipoObjeto
					,P.idPartida
					,3
					,P.costo
					,P.venta
					,'APROBADA'
					, GETDATE()
					,@idUsuario
				FROM solicitud.SolicitudCotizacionPartida SP, @partidas P
				WHERE idSolicitud = @idSolicitud
				AND rfcProveedor = @rfcProveedor

				select 'aprobador'

				INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] 
				

				SELECT  DISTINCT
					[idCotizacion]
					,SP.[idSolicitud]
					,SP.[idTipoSolicitud]
					,SP.[idClase]
					,SP.[rfcEmpresa]
					,SP.[numeroContrato]
					,SP.[idCliente]
					,SP.[rfcProveedor]
					,SP.[idProveedorEntidad]
					,SP.[idObjeto]
					,SP.[idTipoObjeto]
					,P.[idPartida]
					,@idUsuario
					,GETDATE()
				FROM [solicitud].[SolicitudCotizacionPartida] SP, @partidas P
				WHERE 
					idSolicitud = @idSolicitud
					AND idTipoSolicitud = @idTipoSolicitud
					AND idClase = @idClase
					AND rfcEmpresa = @rfcEmpresa
					AND idCliente = @idCliente
					AND numeroContrato = @numeroContrato
					AND rfcProveedor = @rfcProveedor

			SET @contadorSolicitud = @contadorSolicitud + 1

			END

	COMMIT TRANSACTION INS_PARTIDASCOTIZACION_SP

	END TRY
		BEGIN CATCH
			SELECT ERROR_MESSAGE()
			ROLLBACK TRANSACTION INS_PARTIDASCOTIZACION_SP
		END CATCH

END

go

