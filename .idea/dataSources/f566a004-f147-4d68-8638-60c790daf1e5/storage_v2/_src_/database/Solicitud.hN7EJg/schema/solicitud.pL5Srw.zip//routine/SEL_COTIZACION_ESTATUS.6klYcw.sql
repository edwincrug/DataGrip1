-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<20/04/2020>
-- Description:	    <Obtener los estatus de las cotizaciones>
-- =============================================
-- EXEC [solicitud].[SEL_COTIZACION_ESTATUS] 461
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_COTIZACION_ESTATUS]
(
	@idSolicitud		INT
	,@idUsuario			INT=NULL
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS

BEGIN

	SELECT
		ESC.[idEstatusSolicitudCotizacion]
		,SC.[idCotizacion]
		,SC.idSolicitud
		,SC.idTipoSolicitud
		,SC.idClase
		,SC.rfcEmpresa
		,SC.idCliente
		,SC.numeroContrato
		,SC.idProveedorEntidad
		,SC.rfcProveedor
		,ESC.[fechaAlta]
		,ESC.[idUsuario]
		,CU.PrimerNombre + ' ' + CU.PrimerApellido + ' ' + CU.SegundoApellido usuario
		,ESC.[idEstatusCotizacion]
		,EC.[nombre]
	FROM [Solicitud].[solicitud].[SolicitudCotizacion] SC
	INNER JOIN [Solicitud].[solicitud].[EstatusSolicitudCotizacion] ESC
		ON SC.idCotizacion = ESC.idCotizacion
	INNER JOIN [Solicitud].[solicitud].[EstatusCotizacion] EC
		ON ESC.idEstatusCotizacion = EC.idEstatusCotizacion
	LEFT JOIN [Seguridad].[Catalogo].[Users] CU
		ON ESC.idUsuario = CU.Id
	WHERE SC.idSolicitud = @idSolicitud
	ORDER BY ESC.idCotizacion
		,ESC.idEstatusSolicitudCotizacion

END



go

