
-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener los totales por cotizacion>
-- =============================================
-- SELECT 
    -- [idSolicitud]
    -- ,[idTipoSolicitud]
    -- ,[idClase]
    -- ,[rfcEmpresa]
    -- ,[idCliente]
    -- ,[numeroContrato]
    -- ,[idObjeto]
    -- ,[idTipoObjeto]
    -- ,[idPartida]
    -- ,[subTotalCosto]
    -- ,[IVACosto]
    -- ,[totalCosto]
    -- ,[subTotalVenta]
    -- ,[IVAVenta]
    -- ,[totalVenta]
-- FROM [solicitud].[SEL_SOLICITUD_PARTIDA_TOTALES_VW]
-- =============================================
CREATE VIEW [solicitud].[SEL_SOLICITUD_PARTIDA_TOTALES_VW]
AS
SELECT 
    [idSolicitud]
    ,[idTipoSolicitud]
    ,[idClase]
    ,[rfcEmpresa]
    ,[idCliente]
    ,[numeroContrato]
    ,[idObjeto]
    ,[idTipoObjeto]
    ,[idPartida]
    ,SUM([subTotalCosto]) subTotalCosto
    ,SUM([IVACosto]) IVACosto
    ,SUM([totalCosto]) totalCosto
    ,SUM([subTotalVenta]) subTotalVenta
    ,SUM([IVAVenta]) IVAVenta
    ,SUM([totalVenta]) totalVenta
	,[idEstatusSolicitud]
FROM [Solicitud].[solicitud].[SEL_TOTALES_PARTIDAS_VW]
WHERE [idEstatusCotizacionPartida] NOT IN ('RECHAZADA')
GROUP BY [idSolicitud]
    ,[idTipoSolicitud]
    ,[idClase]
    ,[rfcEmpresa]
    ,[idCliente]
    ,[numeroContrato]
    ,[idObjeto]
    ,[idTipoObjeto]
    ,[idPartida]
	,[idEstatusSolicitud]
go

