
-- =============================================  
-- Author:  Andres Farias  
-- Create date: 08/07/2019  
-- Description: Guardar una factura.  
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	28/09/2020	JLuis Lozada	Se agrego el bloque para guardar los campos porcentajeDescuentoCosto y DescuentoCosto de la tabla SolicitudCotizacionPartidaDescuento
	

	*- Testing...
	DECLARE @err VARCHAR(8000)
	exec [cxp].[INS_FACTURA_SOLICITUDPARTIDAS_SP]   
	@idClase ='Automovil',@rfcProveedor	='OKW190528LZ9',@uuid='981b3eb6-411d-4c82-a30c-352ce9edcd99',
	@serie	='FPS',	@folio	='210593',@fechaFactura='Oct 30 2019 11:12AM',@rfcEmisor='OKW190528LZ9',
	@rfcReceptor='LOGL850825MX7',@subTotal = 8000,@descuento = NULL, @traslado =35.45,
	@retencion	=NULL,@trasladosXml	='<traslados><traslado><impuesto>002</impuesto><importe>35.45</importe><tasa>0.160000</tasa></traslado></traslados>',
	@retencionesXml	=NULL,@total	=257,
	@xml	='{"_declaration":{"_attributes":{"version":"1.0","encoding":"utf-8"}},"cfdi:Comprobante":{"_attributes":{"xsi:schemaLocation":"http://www.sat.gob.mx/cfd/3 http://www.sat.gob.mx/sitio_internet/cfd/3/cfdv33.xsd","Version":"3.3","Serie":"FPS","Folio":"210593","Fecha":"2019-10-30T11:12:52","Sello":"UuO9FaEYtW6tYq0wnLA2DBT8Wr5yH/noKIw4HPwxKeBh3vEHb16KRmhJ2U/Gir89g1UcJR40OO2DCqD5zeEKkk+BUDG2NsIutNATLmRJneUu6DC6/ZUStbXNS6b1mZ+7o8QYL5lLXTKxv4k4mQE32254L7AX4oSpdO2TkaHLKCkrvnypbkJxRjRV9UOAVSxa7WmmZH69DNjk/DY7y5Wp246rojmnOQc+pwLEhw/GEq1IErC9YIfrg0VHONolYYn7ErAnUvACQ66Vz+SoJ9iT3Lcs1qhtCkshk8i9hH13r4tygAF0h0IbHsVsyOj6/BMNedYhfrShuxmbCTc7Q/bhdw==","FormaPago":"01","NoCertificado":"00001000000403923765","Certificado":"MIIGJzCCBA+gAwIBAgIUMDAwMDEwMDAwMDA0MDM5MjM3NjUwDQYJKoZIhvcNAQELBQAwggGyMTgwNgYDVQQDDC9BLkMuIGRlbCBTZXJ2aWNpbyBkZSBBZG1pbmlzdHJhY2nDs24gVHJpYnV0YXJpYTEvMC0GA1UECgwmU2VydmljaW8gZGUgQWRtaW5pc3RyYWNpw7NuIFRyaWJ1dGFyaWExODA2BgNVBAsML0FkbWluaXN0cmFjacOzbiBkZSBTZWd1cmlkYWQgZGUgbGEgSW5mb3JtYWNpw7NuMR8wHQYJKoZIhvcNAQkBFhBhY29kc0BzYXQuZ29iLm14MSYwJAYDVQQJDB1Bdi4gSGlkYWxnbyA3NywgQ29sLiBHdWVycmVybzEOMAwGA1UEEQwFMDYzMDAxCzAJBgNVBAYTAk1YMRkwFwYDVQQIDBBEaXN0cml0byBGZWRlcmFsMRQwEgYDVQQHDAtDdWF1aHTDqW1vYzEVMBMGA1UELRMMU0FUOTcwNzAxTk4zMV0wWwYJKoZIhvcNAQkCDE5SZXNwb25zYWJsZTogQWRtaW5pc3RyYWNpw7NuIENlbnRyYWwgZGUgU2VydmljaW9zIFRyaWJ1dGFyaW9zIGFsIENvbnRyaWJ1eWVudGUwHhcNMTYxMDExMTczMTAwWhcNMjAxMDExMTczMTAwWjCBxzEjMCEGA1UEAxMaQUxEQU4gRUxFQ1RST05JQ0EgU0EgREUgQ1YxIzAhBgNVBCkTGkFMREFOIEVMRUNUUk9OSUNBIFNBIERFIENWMSMwIQYDVQQKExpBTERBTiBFTEVDVFJPTklDQSBTQSBERSBDVjElMCMGA1UELRMcQUVMMDUwNjIwVEo5IC8gRk9SRDcxMDUwMThQODEeMBwGA1UEBRMVIC8gRk9SRDcxMDUwMUhERkxTTjAwMQ8wDQYDVQQLEwZNQVRSSVowggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCnozetdYzGsWo9hx/YizWqINoDRaoq/1rXnoTPnWe1wmfsIyQaiC7JMx88QKW9R+5q+3C2t5Bw+5uj8Q5Tnt+yvEZJnoyzJXrN0HzMl3fqWgKjYXX/g0XEnR67q39Zo5Hi53JwSvSvTbFtRw+d5LHC73RkrEKGItafx0vE3QhtGx7aG6nhvuog9WHagznd/MCP70tfi3iwi4ZB/7KU1atXE9HXN9NvBwIlx6+KJB86jSBIUcAvy3h25u6wfk5Asqg3+GpE186sX04ScNTTUynTWkuPDOAT3OKhEy0mnobPJqzRPArCuLaWtJVJ0UKZmFdNOjFrCKZnHmaCJfHWKgiXAgMBAAGjHTAbMAwGA1UdEwEB/wQCMAAwCwYDVR0PBAQDAgbAMA0GCSqGSIb3DQEBCwUAA4ICAQB6i3DbxFNbV8XpdnXKt4sMXsuGmY3efBZ5HkSAzVa2nHQRFw/gE8Mojos47D3hn24hWiuD6ka3Bw/h/uh9IWYZ/LfgCtqZ8/Mg2MqGax1KRS3Ja7UxBkypl/vL6au9mCkZnyoG/MrnB+VsUq4oky0W6f371zPltPpy6/4pnhw8FE1N6QcHXSSsHBMcVEka4Vsol4g2kihj0Dp3uHaJFByFt2YiTvz8//REew4NqcHaqHlwMd5OyeEKlknBHysxqLZlMY38/EkuHWep4Z2OoKRUQuDNzVItfVUDuLxfYt4n6j80eSBG9SA/JGg3Hw8TTD2iG7EqGCxbH6lxb1EpSNC9W0oR24rlxbLwlG8C0K4HZuZITw6JsVyeeHi5cxIhvEPwke+070DWVkj3nwe2LQT3niokMJoXzTlsh3V8qI6AdIFWW//DCR21Kq/sVtBx6G3EETmS/nXpwjt4YYf7NyJnWnZkTM04UIcZRokHKmfSo73LXgvZeNEmSqyu/Os9AX/UA4nAnvkgicLB/q2eMqVpX7CuSchGdcpVezlhDVIbqkSYpFX6VwxzM5id+HLVjKRr7ACuwnSkDKuBLQM2O+JjuIiXDfed1Dmr+n2gULumc5+fa8bwCI4OsCo1mXAGUSsZCpP55ThVeXDsW6zX1NgyumPkIRiOrR4Byf5QpXA7pg==","SubTotal":"8000.00","Moneda":"MXN","Total":"257.00","TipoDeComprobante":"I","MetodoPago":"PUE","LugarExpedicion":"53100","xmlns:cfdi":"http://www.sat.gob.mx/cfd/3","xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance"},"cfdi:Emisor":{"_attributes":{"Rfc":"OKW190528LZ9","Nombre":"OM KW Sa. de Cv","RegimenFiscal":"601"}},"cfdi:Receptor":{"_attributes":{"Rfc":"LOGL850825MX7","Nombre":"JOSE LUIS LOPEZ HUERTA ","UsoCFDI":"G03"}},"cfdi:Conceptos":{"cfdi:Concepto":[{"_attributes":{"ClaveProdServ":"26111700","NoIdentificacion":"BAT-9V","Cantidad":"1.00","ClaveUnidad":"H87","Unidad":"PIEZA","Descripcion":"PILA ALCALINA DE 9 VOLTS","ValorUnitario":"50.86","Importe":"50.86","Descuento":"0"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"50.86","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"8.14"}}}}},{"_attributes":{"ClaveProdServ":"39121400","NoIdentificacion":"258-810 E02","Cantidad":"1.00","ClaveUnidad":"H87","Unidad":"PIEZA","Descripcion":"JUEGO DE 2 BROCHES PORTA-PILA 9 VOLTS","ValorUnitario":"41.38","Importe":"41.38","Descuento":"0"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"41.38","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"6.62"}}}}},{"_attributes":{"ClaveProdServ":"32131000","NoIdentificacion":"509-010","Cantidad":"1.00","ClaveUnidad":"H87","Unidad":"PIEZA","Descripcion":"PROTOBOARD 1 BLOQUE 2 TIRAS ENSAMBLE PRE","ValorUnitario":"129.31","Importe":"129.31","Descuento":"0"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"129.31","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"20.69"}}}}}]},"cfdi:Impuestos":{"_attributes":{"TotalImpuestosTrasladados":"35.45"},"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"35.45"}}}},"cfdi:Complemento":{"tfd:TimbreFiscalDigital":{"_attributes":{"xsi:schemaLocation":"http://www.sat.gob.mx/TimbreFiscalDigital http://www.sat.gob.mx/sitio_internet/cfd/timbrefiscaldigital/TimbreFiscalDigitalv11.xsd","Version":"1.1","UUID":"981b3eb6-411d-4c82-a30c-352ce9edcd99","FechaTimbrado":"2019-10-30T11:12:54","RfcProvCertif":"DIG130917F9A","SelloCFD":"UuO9FaEYtW6tYq0wnLA2DBT8Wr5yH/noKIw4HPwxKeBh3vEHb16KRmhJ2U/Gir89g1UcJR40OO2DCqD5zeEKkk+BUDG2NsIutNATLmRJneUu6DC6/ZUStbXNS6b1mZ+7o8QYL5lLXTKxv4k4mQE32254L7AX4oSpdO2TkaHLKCkrvnypbkJxRjRV9UOAVSxa7WmmZH69DNjk/DY7y5Wp246rojmnOQc+pwLEhw/GEq1IErC9YIfrg0VHONolYYn7ErAnUvACQ66Vz+SoJ9iT3Lcs1qhtCkshk8i9hH13r4tygAF0h0IbHsVsyOj6/BMNedYhfrShuxmbCTc7Q/bhdw==","NoCertificadoSAT":"00001000000411500203","SelloSAT":"WFxePA2fP358VYFz3jLlFwaUFR7ZReDbZN2hhtFc5Nax5/HWFR5h4Ov2yiD8EntEBPLqlfttZcq4ZX/6HEPmTZ3xh+zSC8g9sbecsVfFoR/pSoAUunGP3a7pcDHGufReyCB2uESl+rutj4AsjTihnUBVOveRmkN0UQjoreGw644cr3/4xZCMuLHImpIiB8ETgWtALYVZs7iPSLgXj0iKIEhI9p8oImXKTiEuhlooYQuScKshxj7NY4m5noPmHknyskFplwPkvd3wD1t4jbVbD6uFkJM2M47f1PuiNjSGynUM5ZeiCISRChtUaOnmE99VkeYmKfBXv/nvHiNmNvYgaw==","xmlns:tfd":"http://www.sat.gob.mx/TimbreFiscalDigital","xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance"}}},"cfdi:Addenda":{"digibox:CamposAdicionales":{"_attributes":{"xmlns:digibox":"http://www.digibox.com.mx/cfdi/camposadicionales"},"digibox:CampoAdicional":[{"_attributes":{"valor":"433245","nombre":"remision"}},{"_attributes":{"valor":"Steren Shop Plaza Satelite","nombre":"sucursal"}},{"_attributes":{"valor":"25548","nombre":"cliente"}},{"_attributes":{"valor":"Cliente Recoge","nombre":"transporte"}},{"_attributes":{"valor":"0000580004","nombre":"KUNNR"}},{"_attributes":{"valor":"FERNANDO US08297","nombre":"vendedor"}},{"_attributes":{"valor":"plazasatelite@steren.com.mx","nombre":"emisor_correoF"}},{"_attributes":{"valor":"Patriotismo 229 107 San Pedro de los Pinos Distrito Federal MEX MX 03800","nombre":"emisor_domiciliofiscal"}},{"_attributes":{"valor":"JLLOZADA@HOTMAIL.COM","nombre":"receptor_correo"}},{"_attributes":{"valor":"Circuito Centro Comercial No.2251 Local R402  C.D Satelite Naucalpan MEX MX 53100","nombre":"emisor_expedidoen"}},{"_attributes":{"valor":"JOSE LUIS LOZADA GUERRERO ","nombre":"DomicilioEnvio_nombre"}},{"_attributes":{"valor":"     MEX MX 54892","nombre":"DomicilioEnvio_domicilio"}},{"_attributes":{"valor":"     MEX MX 54892","nombre":"receptor_Domicilio"}},{"_attributes":{"valor":"ticket","nombre":"FormatoPdf"}},{"_attributes":{"valor":"false","nombre":"Retimbrar"}}]}}}}',
	@idDocumentoPdf	=24805,	@idDocumentoXml	=24806,
	@xmlPartidas	='<partidas><partida><idCotizacion>1414</idCotizacion><idSolicitud>938</idSolicitud><idObjeto>10580</idObjeto><idTipoObjeto>117</idTipoObjeto><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746045</idPartida><montoAbonado>1762.91</montoAbonado></partida><partida><idCotizacion>1413</idCotizacion><idSolicitud>937</idSolicitud><idObjeto>10580</idObjeto><idTipoObjeto>117</idTipoObjeto><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746045</idPartida><montoAbonado>1762.91</montoAbonado></partida><partida><idCotizacion>1456</idCotizacion><idSolicitud>980</idSolicitud><idObjeto>10580</idObjeto><idTipoObjeto>117</idTipoObjeto><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746045</idPartida><montoAbonado>1762.91</montoAbonado></partida><partida><idCotizacion>1455</idCotizacion><idSolicitud>979</idSolicitud><idObjeto>10580</idObjeto><idTipoObjeto>117</idTipoObjeto><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746045</idPartida><montoAbonado>1762.91</montoAbonado></partida><partida><idCotizacion>1460</idCotizacion><idSolicitud>984</idSolicitud><idObjeto>10580</idObjeto><idTipoObjeto>117</idTipoObjeto><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><rfcProveedor>OKW190528LZ9</rfcProveedor><idProveedorEntidad>519</idProveedorEntidad><idPartida>746045</idPartida><montoAbonado>1762.91</montoAbonado></partida></partidas>',
	@xmlCotizaciones='<cotizaciones><cotizacion><idCotizacion>1414</idCotizacion><idProveedorEntidad>519</idProveedorEntidad><idSolicitud>938</idSolicitud><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><idCliente>185</idCliente><numeroContrato>43</numeroContrato></cotizacion><cotizacion><idCotizacion>1413</idCotizacion><idProveedorEntidad>519</idProveedorEntidad><idSolicitud>937</idSolicitud><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><idCliente>185</idCliente><numeroContrato>43</numeroContrato></cotizacion><cotizacion><idCotizacion>1456</idCotizacion><idProveedorEntidad>519</idProveedorEntidad><idSolicitud>980</idSolicitud><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><idCliente>185</idCliente><numeroContrato>43</numeroContrato></cotizacion><cotizacion><idCotizacion>1455</idCotizacion><idProveedorEntidad>519</idProveedorEntidad><idSolicitud>979</idSolicitud><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><idCliente>185</idCliente><numeroContrato>43</numeroContrato></cotizacion><cotizacion><idCotizacion>1460</idCotizacion><idProveedorEntidad>519</idProveedorEntidad><idSolicitud>984</idSolicitud><idTipoSolicitud>Imagen</idTipoSolicitud><rfcEmpresa>ASE0508051B6</rfcEmpresa><idCliente>185</idCliente><numeroContrato>43</numeroContrato></cotizacion></cotizaciones>',
	@porcentajeCosto=5.10,@idUsuario	=6282,@err =NULL

	PRINT @err
*/  
-- =============================================  
CREATE PROCEDURE [cxp].[INS_FACTURA_SOLICITUDPARTIDAS_SP]  
    @idClase varchar(50),  
    @rfcProveedor varchar(50),  
    @uuid varchar(50),  
    @serie varchar(250) = NULL,  
    @folio varchar(250)=NULL,  
    @fechaFactura datetime,  
    @rfcEmisor varchar(13),  
	@rfcReceptor varchar(13),  
    @subTotal float=0,  
	@descuento float=null,
	@traslado float=null,
	@retencion float=null,
    @trasladosXml xml,
	@retencionesXml xml,
    @total float,  
    @xml varchar(max),  
	@idDocumentoPdf int,  
	@idDocumentoXml int,  
    @xmlPartidas xml,   
    @xmlCotizaciones xml, 
	@porcentajeCosto float=0,
	@idUsuario int,  
	@err     VARCHAR(8000) = '' OUTPUT   
AS  
BEGIN TRY  
		BEGIN TRANSACTION   
    
		if (@serie='') set @serie=NULL
		if (@folio='') set @folio=NULL
  
		--create table test(campo VARCHAR(100),valor VARCHAR(100),datos XML)  
		DECLARE @tbl_cotizaciones AS TABLE (  
		_row int identity(1,1),  
		idProveedorEntidad int,  
		idCotizacion int,  
		idSolicitud int,  
		idTipoSolicitud varchar(10),  
		rfcEmpresa varchar(50),  
		idCliente varchar(50),  
		numeroContrato varchar(50)  
		)  
  
		DECLARE @tbl_partidas AS TABLE (  
		_row int identity(1,1),  
		idProveedorEntidad int,  
		idCotizacion int,  
		idObjeto int,  
		idTipoObjeto int,  
		idPartida int,  
		montoAbonado float,  
		rfcProveedor varchar(13)  
		)  
  
		INSERT INTO @tbl_cotizaciones  
		SELECT	ParamValues.col.value('idProveedorEntidad[1]','int')  
		,ParamValues.col.value('idCotizacion[1]','int')  
		,ParamValues.col.value('idSolicitud[1]','int')  
		,ParamValues.col.value('idTipoSolicitud[1]','varchar(10)')  
		,ParamValues.col.value('rfcEmpresa[1]','varchar(50)')  
		,ParamValues.col.value('idCliente[1]','varchar(50)')  
		,ParamValues.col.value('numeroContrato[1]','varchar(50)')  
		FROM @xmlCotizaciones.nodes('cotizaciones/cotizacion') AS ParamValues(col)  
  
		INSERT INTO @tbl_partidas  
		SELECT	ParamValues.col.value('idProveedorEntidad[1]','int')  
				,ParamValues.col.value('idCotizacion[1]','int')  
				,ParamValues.col.value('idObjeto[1]','int')  
				,ParamValues.col.value('idTipoObjeto[1]','int')  
				,ParamValues.col.value('idPartida[1]','int')  
				,ParamValues.col.value('montoAbonado[1]','float')  
				,ParamValues.col.value('rfcProveedor[1]','varchar(13)')  
		FROM @xmlPartidas.nodes('partidas/partida') AS ParamValues(col)  

		INSERT INTO [Solicitud].[cxp].[Factura] ([uuid],[serie],[folio],[fechaFactura],[rfcEmisor],[rfcReceptor],[subtotal],[descuento],[total],
					[saldo],[idUsuario],[xml],[idDocumentoXml],[idDocumentoPdf],[traslado],[retencion])
			VALUES	(@uuid,ISNULL(@serie,''),ISNULL(@folio,''),@fechaFactura,@rfcEmisor,@rfcReceptor,@subTotal,@descuento
					,@total,@total,@idUsuario,@xml,@idDocumentoXml,@idDocumentoPdf,@traslado,@retencion)

		if (@serie is null and @folio is null)
			begin
				update [Solicitud].[cxp].[Factura] SET serie = SUBSTRING(@uuid,25,12) where uuid = @uuid
			end

		IF(@trasladosXml IS NOT NULL)
			BEGIN
				DECLARE @tbl_traslados AS TABLE (impuesto varchar(3), importe float,tasa float)

				INSERT INTO @tbl_traslados
				SELECT	ParamValues.col.value('impuesto[1]','varchar(3)')
						,ParamValues.col.value('importe[1]','float')
						,ParamValues.col.value('tasa[1]','float')
				FROM @trasladosXml.nodes('traslados/traslado') AS ParamValues(col)  
	
				INSERT	INTO [Solicitud].[cxp].[FacturaImpuesto] 
				SELECT	@uuid,T.tasa,T.importe,TFI.idTipoFacturaImpuesto
				FROM	@tbl_traslados T 
				INNER	JOIN [Solicitud].[cxp].[TipoFacturaImpuesto] TFI ON T.impuesto = TFI.clave
				WHERE	TFI.idTipo = 1
			END

		IF(@retencionesXml IS NOT NULL)
			BEGIN
				DECLARE @tbl_retenciones AS TABLE (impuesto varchar(3),importe float,tasa float)

				INSERT INTO @tbl_retenciones
				SELECT	ParamValues.col.value('impuesto[1]','varchar(3)')
						,ParamValues.col.value('importe[1]','float')
						,ParamValues.col.value('tasa[1]','float')
				FROM @retencionesXml.nodes('retenciones/retencion') AS ParamValues(col)  
	
				INSERT	INTO [Solicitud].[cxp].[FacturaImpuesto] 
				SELECT	@uuid,R.tasa,R.importe,TFI.idTipoFacturaImpuesto
				FROM	@tbl_retenciones R
				INNER	JOIN [Solicitud].[cxp].[TipoFacturaImpuesto] TFI ON R.impuesto = TFI.clave
				WHERE TFI.idTipo = 2

			END

		INSERT INTO cxp.SolicitudCotizacionFactura(idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,uuid) 
		SELECT	idCotizacion,idSolicitud,idTipoSolicitud,@idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,@rfcProveedor,@uuid  
		FROM	@tbl_cotizaciones

		INSERT INTO cxp.SolicitudCotizacionFacturaDetalle(	idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,  
															uuid,idObjeto,idTipoObjeto,idPartida,montoAbonado,fechaAbono,idUsuario) 
		SELECT	P.idCotizacion,idSolicitud,idTipoSolicitud,@idClase,rfcEmpresa,idCliente,numeroContrato,P.idProveedorEntidad,rfcProveedor,@uuid,idObjeto,idTipoObjeto,idPartida,montoAbonado,GETDATE(),@idUsuario
		FROM	@tbl_partidas p INNER JOIN @tbl_cotizaciones C ON C.idCotizacion = p.idCotizacion

		/*INICIO DESCUENTO COSTO*/
		IF @porcentajeCosto IS NOT NULL OR @porcentajeCosto > 0 
			BEGIN
				DECLARE @v_idd INT,  
				@v_idProveedorEntidad INT,  
				@v_idCotizacion		INT,  
				@v_idObjeto			INT,  
				@v_idTipoObjeto		INT,  
				@v_idPartida		INT,
				@v_rfcProveedor		VARCHAR(13),
				@v_idSolicitud		INT,
				@v_idTipoSolicitud	VARCHAR(10),
				@v_rfcEmpresa		VARCHAR(13),
				@v_idCliente		INT,
				@v_numeroContrato	VARCHAR(50),
				@v_costo			FLOAT,
				@v_descuentoCosto	DECIMAL(18,2)

				WHILE EXISTS (SELECT 1 FROM @tbl_partidas)
					BEGIN	
						SELECT TOP 1 @v_idd=_row, @v_idProveedorEntidad=idProveedorEntidad,@v_idCotizacion=idCotizacion,@v_idObjeto=idObjeto,
									 @v_idTipoObjeto=idTipoObjeto,@v_idPartida=idPartida,@v_rfcProveedor=rfcProveedor,@v_costo=montoAbonado FROM @tbl_partidas

						SELECT	@v_idSolicitud=idSolicitud,@v_idTipoSolicitud=idTipoSolicitud,@v_rfcEmpresa=rfcEmpresa,@v_idCliente=idCliente,@v_numeroContrato=numeroContrato  
						FROM	@tbl_cotizaciones 
						WHERE	idCotizacion	=	@v_idCotizacion

						--SELECT	@v_costo =costo
						--FROM	solicitud.solicitud.SolicitudCotizacionPartida 
						--WHERE	idCotizacion	=@v_idCotizacion
						--AND		idSolicitud		=@v_idSolicitud
						--AND		idTipoSolicitud	=@v_idTipoSolicitud
						--AND		idClase			=@idClase
						--AND		rfcEmpresa		=@v_rfcEmpresa
						--AND		numeroContrato	=@v_numeroContrato
						--AND		idCliente		=@v_idCliente
						--AND		rfcProveedor	=@v_rfcProveedor
						--AND		idProveedorEntidad=@v_idProveedorEntidad
						--AND		idObjeto		=@v_idObjeto
						--AND		idTipoObjeto	=@v_idTipoObjeto
						--AND		idPartida		=@v_idPartida

						SET @v_descuentoCosto=(@porcentajeCosto * @v_costo)/100

						--PRINT '@v_idCotizacion=>'+CAST(@v_idCotizacion AS VARCHAR) + '  '+ '@v_costo=>'+CAST(@v_costo AS VARCHAR)
						
						IF EXISTS(	SELECT	1 
									FROM	solicitud.solicitud.SolicitudCotizacionPartidaDescuento 
									WHERE	idCotizacion	=@v_idCotizacion
									AND		idSolicitud		=@v_idSolicitud
									AND		idTipoSolicitud	=@v_idTipoSolicitud
									AND		idClase			=@idClase
									AND		rfcEmpresa		=@v_rfcEmpresa
									AND		numeroContrato	=@v_numeroContrato
									AND		idCliente		=@v_idCliente
									AND		rfcProveedor	=@v_rfcProveedor
									AND		idProveedorEntidad=@v_idProveedorEntidad
									AND		idObjeto		=@v_idObjeto
									AND		idTipoObjeto	=@v_idTipoObjeto
									AND		idPartida		=@v_idPartida)
							BEGIN
								UPDATE	solicitud.solicitud.SolicitudCotizacionPartidaDescuento 
								SET		porcentajeDescuentoCosto=@porcentajeCosto,
										descuentoCosto			=@v_descuentoCosto
								WHERE	idCotizacion	=@v_idCotizacion
								AND		idSolicitud		=@v_idSolicitud
								AND		idTipoSolicitud	=@v_idTipoSolicitud
								AND		idClase			=@idClase
								AND		rfcEmpresa		=@v_rfcEmpresa
								AND		numeroContrato	=@v_numeroContrato
								AND		idCliente		=@v_idCliente
								AND		rfcProveedor	=@v_rfcProveedor
								AND		idProveedorEntidad=@v_idProveedorEntidad
								AND		idObjeto		=@v_idObjeto
								AND		idTipoObjeto	=@v_idTipoObjeto
								AND		idPartida		=@v_idPartida
							END
						ELSE
							BEGIN
								INSERT INTO solicitud.solicitud.SolicitudCotizacionPartidaDescuento(idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,numeroContrato,
								idCliente,rfcProveedor,idProveedorEntidad,idObjeto,idTipoObjeto,idPartida,porcentajeDescuentoVenta,descuentoVenta,porcentajeDescuentoCosto,
								descuentoCosto,fecha,idUsuario)
								VALUES(@v_idCotizacion,@v_idSolicitud,@v_idTipoSolicitud,@idClase,@v_rfcEmpresa,@v_numeroContrato,@v_idCliente,@v_rfcProveedor,@v_idProveedorEntidad,
								@v_idObjeto,@v_idTipoObjeto,@v_idPartida,0,0,@porcentajeCosto,@v_descuentoCosto,GETDATE(),@idUsuario)
							END

						DELETE FROM @tbl_partidas WHERE _row= @v_idd
					END
			END
		

		/*FIN DESCUENTO COSTO*/

 -- DECLARE @cont int= 1;  
  
 -- WHILE(@cont <= (SELECT COUNT(*) FROM @tbl_cotizaciones))  
 -- BEGIN   
 --  INSERT INTO cxp.SolicitudCotizacionFactura(  
 --   idCotizacion,  
 --   idSolicitud,  
 --   idTipoSolicitud,  
 --   idClase,  
 --   rfcEmpresa,  
 --   idCliente,  
 --   numeroContrato,  
 --   idProveedorEntidad,  
 --   rfcProveedor,  
 --   uuid  
 --  ) 
 --  VALUES(  
 --   (SELECT TOP 1 idCotizacion FROM @tbl_cotizaciones WHERE _row = @cont),  
 --   (SELECT TOP 1 idSolicitud FROM @tbl_cotizaciones WHERE _row = @cont),  
 --   (SELECT TOP 1 idTipoSolicitud FROM @tbl_cotizaciones WHERE _row = @cont),  
 --   @idClase,  
 --   (SELECT TOP 1 rfcEmpresa FROM @tbl_cotizaciones WHERE _row = @cont),  
 --   (SELECT TOP 1 idCliente FROM @tbl_cotizaciones WHERE _row = @cont),  
 --   (SELECT TOP 1 numeroContrato FROM @tbl_cotizaciones WHERE _row = @cont),  
 --   (SELECT TOP 1 idProveedorEntidad FROM @tbl_cotizaciones WHERE _row = @cont),  
 --   @rfcProveedor,  
 --   @uuid  
 --  )  
  
  
 --  SET @cont = @cont + 1   
 -- END  
  
 -- SET @cont = 1  
 -- WHILE(@cont <= (SELECT COUNT(*) FROM @tbl_partidas))  
 -- BEGIN   
	--print 'insertamos detalle' + convert(varchar,@cont)
 --  INSERT INTO cxp.SolicitudCotizacionFacturaDetalle(  
 --   idCotizacion,  
 --   idSolicitud,  
 --   idTipoSolicitud,  
 --   idClase,  
 --   rfcEmpresa,  
 --   idCliente,  
 --   numeroContrato,  
 --   idProveedorEntidad,  
 --   rfcProveedor,  
 --   uuid,  
 --   idObjeto,  
 --   idTipoObjeto,  
 --   idPartida,  
 --   montoAbonado,  
 --   fechaAbono,  
 --   idUsuario  
 --  ) 
 --  VALUES(  
 --   (SELECT TOP 1 idCotizacion FROM @tbl_partidas WHERE _row = @cont),  
 --   (SELECT TOP 1 idSolicitud FROM @tbl_cotizaciones WHERE idCotizacion = (SELECT TOP 1 idCotizacion FROM @tbl_partidas WHERE _row = @cont)),  
 --   (SELECT TOP 1 idTipoSolicitud FROM @tbl_cotizaciones WHERE idCotizacion = (SELECT TOP 1 idCotizacion FROM @tbl_partidas WHERE _row = @cont)),  
 --   @idClase,  
 --   (SELECT TOP 1 rfcEmpresa FROM @tbl_cotizaciones WHERE idCotizacion = (SELECT TOP 1 idCotizacion FROM @tbl_partidas WHERE _row = @cont)),  
 --   (SELECT TOP 1 idCliente FROM @tbl_cotizaciones WHERE idCotizacion = (SELECT TOP 1 idCotizacion FROM @tbl_partidas WHERE _row = @cont)),  
 --   (SELECT TOP 1 numeroContrato FROM @tbl_cotizaciones WHERE idCotizacion = (SELECT TOP 1 idCotizacion FROM @tbl_partidas WHERE _row = @cont)),  
 --   (SELECT TOP 1 idProveedorEntidad FROM @tbl_partidas WHERE _row = @cont),  
 --   @rfcProveedor,  
 --   @uuid,  
 --   (SELECT TOP 1 idObjeto FROM @tbl_partidas WHERE _row = @cont),  
 --   (SELECT TOP 1 idTipoObjeto FROM @tbl_partidas WHERE _row = @cont),  
 --   (SELECT TOP 1 idPartida FROM @tbl_partidas WHERE _row = @cont),  
 --   (SELECT TOP 1 montoAbonado FROM @tbl_partidas WHERE _row = @cont),  
 --   GETDATE(),  
 --   @idUsuario  
 --  )    
 --  SET @cont = @cont + 1   
 -- END  
   
 COMMIT  
END TRY  
  
BEGIN CATCH  
ROLLBACK TRANSACTION  
SELECT     
        ERROR_NUMBER() AS ErrorNumber    
       ,ERROR_MESSAGE() AS ErrorMessage;  
SET @err = 'Error al intentar guardar la factura. Puede que ya exista una Factura con los mismos datos en el sistema'  
END CATCH


go

