-- =============================================
-- Author:		Martin Pacheco
-- Create date: 24/06/2019
-- Description:	.
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	26-09-2019  CON				Se quita la actualización de solicitudpartidas, ya que el merge realiza ese control por cantidades
	25/09/2020	JLuis Lozada	se agrego al insert de la tabla [SolicitudCotizacionPartidaDescuento] los campos porcentajeDescuentoCosto,descuentoCosto


	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[INS_SOLICITUD_COTIZACION_SP] 
	160, 
	'Servicio', 
	'Automovil', 
	'ASE0508051B6', 
	92, 
	'0001', 
	6119, 
	'<Proveedores><proveedor><idProveedorEntidad>121</idProveedorEntidad><rfcProveedor>AFAB92111053A</rfcProveedor><Partidas><partida><idPartida>32025</idPartida><idProveedorEntidad>121</idProveedorEntidad><rfcProveedor>AFAB92111053A</rfcProveedor><idObjeto>241</idObjeto><idTipoObjeto>100</idTipoObjeto><costo>4200</costo><venta>10</venta><cantidad>10</cantidad></partida><partida><idPartida>32024</idPartida><idProveedorEntidad>121</idProveedorEntidad><rfcProveedor>AFAB92111053A</rfcProveedor><idObjeto>241</idObjeto><idTipoObjeto>100</idTipoObjeto><costo>3500</costo><venta>10</venta><cantidad>1</cantidad></partida><partida><idPartida>32023</idPartida><idProveedorEntidad>121</idProveedorEntidad><rfcProveedor>AFAB92111053A</rfcProveedor><idObjeto>241</idObjeto><idTipoObjeto>100</idTipoObjeto><costo>10500</costo><venta>10</venta><cantidad>1</cantidad></partida></Partidas></proveedor></Proveedores>',
	 null
	SELECT @salida AS salida;
*/
-- =============================================

CREATE PROCEDURE [solicitud].[INS_SOLICITUD_COTIZACION_SP]
	@idSolicitud		INT,
    @idTipoSolicitud	VARCHAR(10) = '',
    @idClase			vARCHAR(10) = '',
    @rfcEmpresa			VARCHAR(13) = '',
    @idCliente			INT,
    @numeroContrato		VARCHAR(50) = '',
    @idUsuario			INT,
	@data				XML,
	@err				VARCHAR(8000) OUTPUT	
AS
BEGIN
	
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	DECLARE @manejoDescuentoVenta INT, @porcentajeDescuentoVenta FLOAT
	SELECT @manejoDescuentoVenta=manejoDescuentoVenta, @porcentajeDescuentoVenta=porcentajeDescuentoVenta 
	FROM [Cliente].Cliente.Contrato
	WHERE rfcEmpresa=@rfcEmpresa AND idCliente=@idCliente AND numeroContrato=@numeroContrato

	 DECLARE
		@VI_One				INT = 1,
		@VI_Zero			INT = 0,
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en el stored: [INS_SOLICITUD_COTIZACION_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0,
		@VI_ResultCount		INT = 0,
		@VI_IdSolicitud		INT = NULL,
		@VC_NOSOLICITUD		VARCHAR(20) = NULL,
		@VI_idCotizacion	INT,
		@numeroCotizacion	VARCHAR(30) = '',
		@xmlPadre			XML,
		@xmlPartidas		XML


	CREATE TABLE #VT_PROVEEDORES (
		[Index]				INT IDENTITY(1,1),
		[xmlData]			XML
	);

	--CREATE TABLE #VT_PARTIDAS (
	--	[Index]					INT IDENTITY(1,1),
	--	[idPartida]				INT,
	--	[idProveedorEntidad]	INT,
	--	[idObjeto]				INT,
	--	[idTipoObjeto]			INT,
	--	[rfcProveedor]			VARCHAR(13),
	--	[cantidad]				INT,
	--	[costoInicial]			DECIMAL, 
	--	[ventaInicial]			DECIMAL
	--);
	DECLARE @VT_PARTIDAS TABLE (
		[idPartida]				INT,
		[idProveedorEntidad]	INT,
		[idObjeto]				INT,
		[idTipoObjeto]			INT,
		[rfcProveedor]			VARCHAR(13),
		[cantidad]				INT,
		[costoInicial]			float, 
		[ventaInicial]			float
	)

	 INSERT INTO #VT_PROVEEDORES
	 	SELECT
			I.N.query('.') AS result
		FROM @data.nodes('/Proveedores/proveedor') I(N)

	BEGIN TRY 
		BEGIN TRANSACTION INS_SOLICITUD_COTIZACION_SP
			DECLARE @count INT = 1, @max INT = (SELECT COUNT([Index]) FROM #VT_PROVEEDORES);
			WHILE (@count <= @max)
				BEGIN
					SET @numeroCotizacion = (SELECT [solicitud].[SEL_NUMEROCOTIZACION_FN](@idSolicitud,@rfcEmpresa,@idTipoSolicitud,@idClase,@idCliente,@numeroContrato))
					SET @xmlPadre = (SELECT [xmlData] FROM #VT_PROVEEDORES WHERE [Index] = @count)
					INSERT INTO [solicitud].[SolicitudCotizacion] (
						 [idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idProveedorEntidad]
						,[rfcProveedor]
						,[numeroCotizacion]
						,[fechaAlta]
						,[idUsuario]
						,[idEstatusCotizacion]
					) VALUES (
						 @idSolicitud
						,@idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,(SELECT I.N.value('(idProveedorEntidad)[1]',	'INT') FROM  @xmlPadre.nodes('/proveedor') I(N))
						,(SELECT I.N.value('(rfcProveedor)[1]',			'VARCHAR(13)') FROM  @xmlPadre.nodes('/proveedor') I(N))
						,@numeroCotizacion
						,GETDATE()
						,@idUsuario
						,'ENESPERA'
					)
					SET @VI_idCotizacion = SCOPE_IDENTITY()

					INSERT INTO @VT_PARTIDAS
					SELECT I.N.value('(idPartida)[1]',				'INT'),
						I.N.value('(idProveedorEntidad)[1]',	'INT'),
						I.N.value('(idObjeto)[1]',				'INT'),
						I.N.value('(idTipoObjeto)[1]',			'INT'),
						I.N.value('(rfcProveedor)[1]',			'VARCHAR(13)'),
						I.N.value('(cantidad)[1]',				'INT'),
						I.N.value('(costo)[1]',					'float'),
						I.N.value('(venta)[1]',					'float')
					FROM @xmlPadre.nodes('/proveedor/Partidas/partida') I(N);

					INSERT INTO solicitud.SolicitudCotizacionPartida ([idCotizacion]
						, [idSolicitud]
						, [idTipoSolicitud]
						, [idClase]
						, [rfcEmpresa]
						, [numeroContrato]
						, [idCliente]
						, [rfcProveedor]
						, [idProveedorEntidad]
						, [idObjeto]
						, [idTipoObjeto]
						, [idPartida]
						, [cantidad]
						, [costo]
						, [venta]
						, [idEstatusCotizacionPartida]
						, [fechaEstatus]
						, [idUsuario])
					SELECT @VI_idCotizacion
						, @idSolicitud
						, @idTipoSolicitud
						, @idClase
						, @rfcEmpresa
						, @numeroContrato
						, @idCliente
						, VT.rfcProveedor
						, VT.idProveedorEntidad
						, VT.idObjeto
						, VT.idTipoObjeto
						, VT.idPartida
						, VT.cantidad
						, VT.costoInicial
						, VT.ventaInicial
						, 'ENESPERA'
						, GETDATE()
						, @idUsuario
					FROM @VT_PARTIDAS VT

				
				IF(@manejoDescuentoVenta = 1)
					BEGIN
						INSERT INTO [solicitud].[SolicitudCotizacionPartidaDescuento] ([idCotizacion]
							, [idSolicitud]
							, [idTipoSolicitud]
							, [idClase]
							, [rfcEmpresa]
							, [numeroContrato]
							, [idCliente]
							, [rfcProveedor]
							, [idProveedorEntidad]
							, [idObjeto]
							, [idTipoObjeto]
							, [idPartida]
							, [porcentajeDescuentoVenta]
							, [descuentoVenta]
							, [porcentajeDescuentoCosto]
							, [descuentoCosto]
							, [fecha]
							, [idUsuario])
						SELECT @VI_idCotizacion
							, @idSolicitud
							, @idTipoSolicitud
							, @idClase
							, @rfcEmpresa
							, @numeroContrato
							, @idCliente
							, VT.rfcProveedor
							, VT.idProveedorEntidad
							, VT.idObjeto
							, VT.idTipoObjeto
							, VT.idPartida
							, @porcentajeDescuentoVenta
							, ((VT.ventaInicial * @porcentajeDescuentoVenta) / 100)
							,0
							,0
							, GETDATE()
							, @idUsuario
						FROM @VT_PARTIDAS VT
					END

					INSERT INTO [solicitud].[EstatusSolicitudCotizacion] 
					(fechaAlta,idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,rfcProveedor,idEstatusCotizacion,idUsuario)
					VALUES 
					(GETDATE(),@VI_idCotizacion,@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,(SELECT I.N.value('(idProveedorEntidad)[1]',	'INT') FROM  @xmlPadre.nodes('/proveedor') I(N)),(SELECT I.N.value('(rfcProveedor)[1]',			'VARCHAR(13)') FROM  @xmlPadre.nodes('/proveedor') I(N)) ,'ENESPERA',@idUsuario)

					DELETE FROM @VT_PARTIDAS
					--DECLARE @pCount INT = 1, @pMax INT = (SELECT COUNT([Index]) FROM #VT_PARTIDAS);
					--WHILE (@pCount <= @pMax)
					--	BEGIN
					--		--DECLARE @CantidadPartida INT = (
					--		--	SELECT [SP].[cantidad]
					--		--	FROM [solicitud].[SolicitudPartida] AS [SP]
					--		--	WHERE  
					--		--		[SP].[idSolicitud] = @idSolicitud AND
					--		--		[SP].[idTipoSolicitud]	= @idTipoSolicitud AND
					--		--		[SP].[idClase]	= @idClase AND
					--		--		[SP].[rfcEmpresa] = @rfcEmpresa AND
					--		--		[SP].[idCliente] = @idCliente AND
					--		--		[SP].[numeroContrato] = @numeroContrato AND
					--		--		[SP].[idObjeto] = (SELECT [idObjeto] FROM #VT_PARTIDAS WHERE [Index] = @pCount) AND
					--		--		[SP].[idTipoObjeto] = (SELECT [idTipoObjeto] FROM #VT_PARTIDAS WHERE [Index] = @pCount) AND
					--		--		[SP].[idPartida] = (SELECT [idPartida] FROM #VT_PARTIDAS WHERE [Index] = @pCount) AND
					--		--		[SP].[idEstatusSolicitudPartida] = 'ENESPERA'
					--		--)
					--		--IF (@CantidadPartida > 0)
					--		--	BEGIN
					--		--		UPDATE [solicitud].[SolicitudPartida]
					--		--		SET [cantidad] = (
					--		--			@CantidadPartida + (SELECT [cantidad] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--		--		)
					--		--		WHERE 
					--		--			[idSolicitud] = @idSolicitud AND
					--		--			[idTipoSolicitud]	= @idTipoSolicitud AND
					--		--			[idClase]	= @idClase AND
					--		--			[rfcEmpresa] = @rfcEmpresa AND
					--		--			[idCliente] = @idCliente AND
					--		--			[numeroContrato] = @numeroContrato AND
					--		--			[idObjeto] = (SELECT [idObjeto] FROM #VT_PARTIDAS WHERE [Index] = @pCount) AND
					--		--			[idTipoObjeto] = (SELECT [idTipoObjeto] FROM #VT_PARTIDAS WHERE [Index] = @pCount) AND
					--		--			[idPartida] = (SELECT [idPartida] FROM #VT_PARTIDAS WHERE [Index] = @pCount) AND
					--		--			[idEstatusSolicitudPartida] = 'ENESPERA'
					--		--	END
					--		--ELSE
					--		--	BEGIN
					--		--		INSERT INTO [solicitud].[SolicitudPartida] (
					--		--			 [idSolicitud]
					--		--			,[idTipoSolicitud]
					--		--			,[idClase]
					--		--			,[rfcEmpresa]
					--		--			,[idCliente]
					--		--			,[numeroContrato]
					--		--			,[idObjeto]
					--		--			,[idTipoObjeto]
					--		--			,[idPartida]
					--		--			,[cantidad]
					--		--			,[costoInicial]
					--		--			,[ventaInicial]
					--		--			,[idEstatusSolicitudPartida]
					--		--			,[idUsuario]
					--		--		) VALUES (
					--		--			 @idSolicitud
					--		--			,@idTipoSolicitud
					--		--			,@idClase
					--		--			,@rfcEmpresa
					--		--			,@idCliente
					--		--			,@numeroContrato
					--		--			,(SELECT [idObjeto] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--		--			,(SELECT [idTipoObjeto] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--		--			,(SELECT [idPartida] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--		--			,(SELECT [cantidad] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--		--			,(SELECT [costoInicial] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--		--			,(SELECT [ventaInicial] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--		--			,'ENESPERA'
					--		--			,@idUsuario
					--		--		)
					--		--	END
					--		INSERT INTO [solicitud].[SolicitudCotizacionPartida] (
					--			 [idCotizacion]
					--			,[idSolicitud]
					--			,[idTipoSolicitud]
					--			,[idClase]
					--			,[rfcEmpresa]
					--			,[numeroContrato]
					--			,[idCliente]
					--			,[rfcProveedor]
					--			,[idProveedorEntidad]
					--			,[idObjeto]
					--			,[idTipoObjeto]
					--			,[idPartida]
					--			,[cantidad]
					--			,[costo]
					--			,[venta]
					--			,[idEstatusCotizacionPartida]
					--			,[fechaEstatus]
					--			,[idUsuario]
					--		) VALUES (
					--			 @VI_idCotizacion
					--			,@idSolicitud
					--			,@idTipoSolicitud
					--			,@idClase
					--			,@rfcEmpresa
					--			,@numeroContrato
					--			,@idCliente
					--			,(SELECT [rfcProveedor] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--			,(SELECT [idProveedorEntidad] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--			,(SELECT [idObjeto] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--			,(SELECT [idTipoObjeto] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--			,(SELECT [idPartida] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--			,(SELECT [cantidad] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--			,(SELECT [costoInicial] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--			,(SELECT [ventaInicial] FROM #VT_PARTIDAS WHERE [Index] = @pCount)
					--			,'ENESPERA'
					--			,GETDATE()
					--			,@idUsuario
					--		)
					--		SET @pCount = @pCount + 1;
					--	END
					--DBCC CHECKIDENT(#VT_PARTIDAS,RESEED,0)
					--DELETE #VT_PARTIDAS
					SET @count = @count + 1;
				END
		COMMIT TRANSACTION INS_SOLICITUD_COTIZACION_SP
	END TRY
	BEGIN CATCH
		SELECT  
			@VC_ErrorMessage	= ERROR_MESSAGE(),
			@VC_ErrorSeverity	= ERROR_SEVERITY(),
			@VC_ErrorState		= ERROR_STATE();
		BEGIN
			ROLLBACK TRANSACTION INS_SOLICITUD_COTIZACION_SP
			SET @VC_ErrorMessage = { 
				fn CONCAT(
					@VC_ThrowMessage,
					@VC_ErrorMessage
				) 
			}
			RAISERROR (
				@VC_ErrorMessage, 
				@VC_ErrorSeverity, 
				@VC_ErrorState
			);
			SET @err = @VC_ErrorMessage;
		END
	END CATCH

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

	
END
go

