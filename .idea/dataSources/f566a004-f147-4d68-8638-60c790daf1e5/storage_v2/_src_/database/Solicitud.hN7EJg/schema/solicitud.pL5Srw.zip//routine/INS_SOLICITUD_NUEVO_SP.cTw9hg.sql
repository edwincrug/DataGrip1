-- =============================================  
-- Author:  Martin Pacheco  
-- Create date: 30/05/2019  
-- Description: Crea una nueva solicitud.  
-- =============================================  
CREATE PROCEDURE [solicitud].[INS_SOLICITUD_NUEVO_SP]  
 @rfcEmpresa    VARCHAR(13) = '',  
 @idCliente    INT = 0,  
 @numeroContrato   NVARCHAR(50) = '',  
 @idObjeto    INT = 0,  
 @idTipoObjeto   INT = 0,  
    @idClase    VARCHAR(10) = '',  
 @idTipoSolicitud  VARCHAR(50) = '',  
 --@numero    VARCHAR(50) = '',  
 @fecha     DATETIME = null,  
 @idEstatusSolicitud  INT = 0,  
 @fechaCaducidad   DATE = NULL,  
 @idPropiedadClase  INT = 0,  
 @PropiedadClaseValor INT = 0,  
 @idUsuario    INT = 0,  
 @partidas    XML,  
 @comentarios   VARCHAR(250) = '',  
 @err     VARCHAR(8000) OUTPUT   
AS  
BEGIN  
 SET NOCOUNT OFF;  
 SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;  
  
    DECLARE  
  @VI_One    INT = 1,  
  @VI_Zero   INT = 0,  
  @VC_ErrorMessage VARCHAR(4000) = '',  
  @VC_ThrowMessage VARCHAR(100) = 'Ocurrio un error en el stored: [INS_SOLICITUD_NUEVO_SP]:',  
  @VC_ErrorSeverity INT = 0,  
  @VC_ErrorState  INT = 0,  
  @VI_ResultCount  INT = 0,  
  @VI_IdSolicitud  INT = NULL,  
  @VC_NOSOLICITUD  VARCHAR(20) = NULL  
   
 DECLARE @VT_Table TABLE (  
  [Index]       INT IDENTITY(1,1),  
  [idPartida]   INT,  
  [cantidad]   INT,  
  [costoInicial]  float,   
  [ventaInicial]   float
 );  
  
 INSERT INTO @VT_Table  
  SELECT  
   I.N.value('(idPartida)[1]', 'INT'),  
   I.N.value('(cantidad)[1]', 'INT'),  
   I.N.value('(costoInicial)[1]', 'float'),  
   I.N.value('(ventaInicial)[1]', 'float')  
  FROM @partidas.nodes('/partidas/partida') I(N);  
  
 DECLARE @count INT = 1, @max INT = (SELECT count([Index]) FROM @VT_Table);  
   
   
  BEGIN TRY   
   BEGIN TRANSACTION INS_SOLICITUD_NUEVO_SP   
  
   SELECT @VC_NOSOLICITUD = (SELECT [solicitud].[SEL_NUMEROSOLICITUD_FN](@rfcEmpresa, @idCliente, @numeroContrato));  
      
    INSERT INTO [solicitud].[Solicitud] (  
         [rfcEmpresa]  
     ,[idCliente]  
     ,[numeroContrato]  
     ,[idCentroCosto]  
     ,[idTipoSolicitud]  
     ,[idClase]  
     ,[fechaCreacion]  
     ,[fechaCita]  
     ,[numero]  
     ,[comentarios]  
     ,[idEstatusSolicitud]  
     ,[idUsuario]  
    ) VALUES (  
     @rfcEmpresa,  
     @idCliente,  
     @numeroContrato,  
     7,  
     @idTipoSolicitud,  
     @idClase,  
     GETDATE(),  
     @fecha,  
     @VC_NOSOLICITUD,  
     @comentarios,  
     'ACTIVA',  
     @idUsuario  
    )  
  
    SET @VI_IdSolicitud = SCOPE_IDENTITY()  
    IF(@VI_IdSolicitud IS NOT NULL)  
     BEGIN  
      UPDATE [solicitud].[ContratoConsecutivo]  
      SET [consecutivo] = (  
       SELECT   
        CAST([consecutivo] AS INT) + 1  
       FROM [solicitud].[ContratoConsecutivo]  
       WHERE   
        [rfcEmpresa] = @rfcEmpresa AND  
        [idCliente] = @idCliente AND  
        [numeroContrato] = @numeroContrato  
      )  
      WHERE   
       [rfcEmpresa] = @rfcEmpresa AND  
       [idCliente] = @idCliente AND  
       [numeroContrato] = @numeroContrato   
     END  
  
    INSERT INTO [solicitud].[SolicitudObjeto](  
         [idSolicitud]  
     ,[rfcEmpresa]  
     ,[idCliente]  
     ,[numeroContrato]  
     ,[idTipoSolicitud]  
     ,[idObjeto]  
     ,[idTipoObjeto]  
     ,[idClase]  
     ,[numeroOrden]  
     ,[fechaAlta]  
     ,[idUsuario]  
    ) VALUES (  
     @VI_IdSolicitud,  
     @rfcEmpresa,  
     @idCliente,  
     @numeroContrato,  
     @idTipoSolicitud,  
     @idObjeto,  
     @idTipoObjeto,  
     @idClase,  
     (@VC_NOSOLICITUD +'-'+ CONVERT(VARCHAR(20), @idObjeto)),  
     @fecha,  
     @idUsuario  
    )  
  
    INSERT INTO [solicitud].[SolicitudPropiedadClase] (  
      [idSolicitud]  
     ,[idTipoSolicitud]  
     ,[idClase]  
     ,[rfcEmpresa]  
     ,[idCliente]  
     ,[numeroContrato]  
     ,[idPropiedadClase]  
     ,[fechaCaducidad]  
     ,[idUsuario]  
    ) VALUES (  
     @VI_IdSolicitud,  
     @idTipoSolicitud,  
     @idClase,  
     @rfcEmpresa,  
     @idCliente,  
     @numeroContrato,  
     @idPropiedadClase,  
     @fechaCaducidad,  
     @idUsuario  
    )  
  
    WHILE (@count <= @max)  
     BEGIN  
      INSERT INTO [solicitud].[SolicitudPartida] (  
         [idSolicitud]  
        ,[idTipoSolicitud]  
        ,[idClase]  
        ,[rfcEmpresa]  
        ,[idCliente]  
        ,[numeroContrato]  
        ,[idObjeto]  
        ,[idTipoObjeto]  
        ,[idPartida]  
        ,[cantidad]  
        ,[costoInicial]  
        ,[ventaInicial]  
        --,[idEstatusPartida]  
        ,[idUsuario]  
      ) VALUES (  
         @VI_IdSolicitud  
        ,@idTipoSolicitud  
        ,@idClase  
        ,@rfcEmpresa  
        ,@idCliente  
        ,@numeroContrato  
        ,@idObjeto  
        ,@idTipoObjeto  
        ,(SELECT [idPartida] FROM @VT_Table WHERE [Index] = @count)  
        ,(SELECT [cantidad] FROM @VT_Table WHERE [Index] = @count)  
        ,(SELECT [costoInicial] FROM @VT_Table WHERE [Index] = @count)  
        ,(SELECT [ventaInicial] FROM @VT_Table WHERE [Index] = @count)  
        --,5  
        , @idUsuario  
      )  
      SET @count = @count + 1;  
     END  
  
    INSERT INTO [fase].[SolicitudEstatusPaso] (  
       [idSolicitud]  
      ,[rfcEmpresa]  
      ,[idCliente]  
      ,[numeroContrato]  
      ,[idPaso]  
      ,[idFase]  
      ,[idClase]  
      ,[idTipoSolicitud]  
      ,[fechaIngreso]  
      ,[idEstatus]  
    ) VALUES (  
     @VI_IdSolicitud  
     ,@rfcEmpresa  
     ,@idCliente  
     ,@numeroContrato  
     ,(SELECT   
      TOP 1 [idPaso]   
       FROM [fase].[Paso]   
       WHERE   
      [idClase] = @idClase AND  
      [idTipoSolicitud] = @idTipoSolicitud AND  
      [idFase] = 'Solicitud'  
       ORDER BY [orden] ASC)  
     ,'Solicitud'  
     ,@idClase  
     ,@idTipoSolicitud  
     ,GETDATE()  
     ,1  
    )  
  
   COMMIT TRANSACTION INS_SOLICITUD_NUEVO_SP  
  END TRY  
  BEGIN CATCH  
   SELECT    
    @VC_ErrorMessage = ERROR_MESSAGE(),  
    @VC_ErrorSeverity = ERROR_SEVERITY(),  
    @VC_ErrorState  = ERROR_STATE();  
   BEGIN  
    ROLLBACK TRANSACTION INS_SOLICITUD_NUEVO_SP  
    SET @VC_ErrorMessage = {   
     fn CONCAT(  
      @VC_ThrowMessage,  
      @VC_ErrorMessage  
     )   
    }  
    RAISERROR (  
     @VC_ErrorMessage,   
     @VC_ErrorSeverity,   
     @VC_ErrorState  
    );  
    SET @err = @VC_ErrorMessage;  
   END  
  END CATCH  
    SET NOCOUNT OFF;  
 SET TRANSACTION ISOLATION LEVEL READ COMMITTED;  
END
go

