
-- =============================================
-- Author:		Adolfo Martinez
-- Create date: 14/04/2020
-- Description:	Valida existencia de el procesar compra y la factura agrupada en la tabla ADE_ORDSERENC
-- solicitud.solicitud.Solicitud
-- [cxc].[SEL_FACTURAAGRUPADA_SP] 449,'Servicio','Automovil','TPC1208066U6',115,'00001-DEMO',1,''
-- [cxc].[SEL_FACTURAAGRUPADA_SP] 180, 'Imagen', 'Automovil','ASE0508051B6',185,'43', 6119
-- 1-1003-331-1   414
-- 1-1015-331-1   426
-- 1-1010-331-1  421
-- 1-1186-250-1 388
-- =============================================
CREATE PROCEDURE [cxc].[SEL_FACTURAAGRUPADA_SP]
@idSolicitud		INT,
@idTipoSolicitud	VARCHAR(10),
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@idUsuario			INT,
@err				VARCHAR(8000) = '' OUTPUT	

AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION

		DECLARE @v_instancia VARCHAR(150),
				@v_nombreBD	VARCHAR(150),
				@v_sq VARCHAR(MAX)=''
		DECLARE @tabletemp TABLE(val INT)

		--print '1'
		SELECT  @v_instancia=instancia, @v_nombreBD=nombreBD 
				FROM common.configuracion.FacturacionBPRO fac 
				INNER JOIN cliente.cliente.contrato co ON  fac.idFacturacionBPRO=co.idFacturacionBPRO 
				WHERE co.rfcEmpresa=@rfcEmpresa
				AND	co.idCliente=@idCliente
				AND	co.numeroContrato=@numeroContrato
				AND	fac.activo=1 
		--print '2'
		DECLARE @queryText varchar(max) = 'SELECT CASE WHEN exists(SELECT 1 FROM solicitud.SolicitudCotizacion sc
					JOIN solicitud.Sel_totales_cotizacion_vw vw ON SC.idCotizacion = vw.idCotizacion
					LEFT JOIN '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC ose ON ose.OTE_ORDENPEMEX=sc.numeroCotizacion COLLATE Modern_Spanish_CI_AI
					WHERE sc.idSolicitud='+ CAST(@idSolicitud AS NVARCHAR(30))+'
					AND sc.idTipoSolicitud='''+@idTipoSolicitud+'''
					AND sc.idClase='''+@idClase+'''
					AND sc.rfcEmpresa='''+@rfcEmpresa+'''
					AND sc.idCliente='''+CAST(@idCliente AS NVARCHAR(30))+'''
					AND sc.numeroContrato='''+@numeroContrato+'''
					AND ose.OTE_ORDENPEMEX IS NULL) then 1 else 0 end'
		print @queryText
		--print '3'
		
		INSERT INTO @tabletemp 
		EXEC (@queryText) 

		--print '4'
	IF ((SELECT TOP 1 val FROM @tabletemp) = 1)
		BEGIN
			--print '5'
			SELECT 'La solicitud aun no ha procesado la compra!' msg, 0 estatus
		END
	ELSE
		BEGIN 
			--print '6'
			DECLARE @queryText2 varchar(max) = 'SELECT CASE WHEN exists(SELECT 1 FROM solicitud.SolicitudCotizacion sc
			JOIN solicitud.Sel_totales_cotizacion_vw vw ON SC.idCotizacion = vw.idCotizacion
			LEFT JOIN '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC ose ON ose.OTE_ORDENPEMEX=sc.numeroCotizacion COLLATE Modern_Spanish_CI_AI
			WHERE sc.idSolicitud='+ CAST(@idSolicitud AS NVARCHAR(30))+'
			AND sc.idTipoSolicitud='''+@idTipoSolicitud+'''
			AND sc.idClase='''+@idClase+'''
			AND sc.rfcEmpresa='''+@rfcEmpresa+'''
			AND sc.idCliente='''+CAST(@idCliente AS NVARCHAR(30))+'''
			AND sc.numeroContrato='''+@numeroContrato+'''
			AND OTE_ORDENGLOBAL IS NULL) then 1 else 0 end'
			--print '7'
			DECLARE @tabletemp2 TABLE(val INT)
			INSERT INTO @tabletemp2 exec(@queryText2) 
			--print '8'
			IF ((SELECT TOP 1 val FROM @tabletemp2) = 1)
				BEGIN
					--print '9'
					SELECT 'La solicitud esta pendiente de generar la relacion Agrupada!' msg, 1 estatus
					
				END
			ELSE
				BEGIN
					--print '10'
					SELECT 'La solicitud ya se genero la relacion Agrupada!' msg, 0 estatus
				END
		END
		COMMIT
	
	END TRY
	BEGIN CATCH
		--ROLLBACK TRANSACTION
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al intentar guardar la prefactura.'
	END CATCH
END
go

