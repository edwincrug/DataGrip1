
-- =============================================
-- Author:		aDOLFO mARTINEZ
-- Create date: <28/05/2020>
-- Description:	<Funcion para obtener los comentarios de las observaciones de provision>
-- Common.reporte.objeto
-- =============================================
/*
	SELECT [solicitud].[getObservaciones](125)
*/

CREATE FUNCTION [solicitud].[getObservaciones]
(
	@idCotizacion INT
)
RETURNS VARCHAR(500)
AS
BEGIN
	--DECLARE @idCotizacion INT = 950, @consolidada INT =1
	DECLARE @ote_observaciones VARCHAR(500) = '',
			@parameters VARCHAR(500) = '',
			@Delimitador VARCHAR(10) = '/',
			@Empieza INT = 1, 
			@Termina INT,
			@propiedad VARCHAR(200) = '',
			@valor VARCHAR(200) = ''

	SELECT @parameters = CBPRO.observaciones
	FROM [Solicitud].[solicitud].[SolicitudObjeto] SO
		JOIN [Cliente].[contrato].[Objeto] CO ON CO.idTipoObjeto=SO.idTipoObjeto AND CO.idObjeto=SO.idObjeto AND CO.rfcEmpresa=SO.rfcEmpresa AND CO.idCliente=SO.idCliente AND CO.numeroContrato=SO.numeroContrato AND CO.idClase=SO.idClase
		JOIN [Cliente].[cliente].[ContratoBPRO] CBPRO ON CBPRO.rfcClienteEntidad = CO.rfcClienteEntidad AND CBPRO.rfcEmpresa = CO.rfcEmpresa AND CBPRO.idCliente = CO.idCliente AND CBPRO.numeroContrato = CO.numeroContrato
		JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SC ON SC.idSolicitud=SO.idsolicitud
	WHERE SC.idCotizacion = @idCotizacion

	IF(@parameters IS NOT NULL)
		BEGIN
			SELECT @Termina= CHARINDEX(@Delimitador, @parameters)
			WHILE @Empieza < LEN(@parameters) + 1 
				BEGIN
					IF @Termina = 0  
					SET @Termina = LEN(@parameters) + 1
					SET @propiedad = SUBSTRING(@parameters, @Empieza, @Termina - @Empieza)

					IF(@propiedad = 'contrato')
						BEGIN
							SELECT
								@valor = (LTRIM(RTRIM(ISNULL(CN.nombre,''))) + ' // ')
							FROM [Solicitud].[solicitud].[SolicitudCotizacion] SC 
								JOIN [Cliente].[cliente].[Contrato] CN on CN.rfcEmpresa = SC.rfcEmpresa AND CN.idCliente = SC.idCliente AND CN.numeroContrato = SC.numeroContrato
							WHERE SC.idCotizacion = @idCotizacion
						END
					IF(@propiedad = 'vin')
						BEGIN
							SELECT 
								@valor = (SELECT [Objeto].[objeto].[getPropiedadObjeto](SO.idObjeto,'VIN','clase',SO.idClase) + ' // ' )
							FROM [Solicitud].[solicitud].[SolicitudObjeto] SO
								JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SC ON SC.idSolicitud=SO.idsolicitud
							WHERE SC.idCotizacion = @idCotizacion
						END
					IF(@propiedad = 'marca')
						BEGIN
							SELECT 
								@valor = (SELECT [Objeto].[objeto].[getPropiedadObjeto](SO.idTipoObjeto,'Marca','tipoClase',SO.idClase) + ' // ' )
							FROM [Solicitud].[solicitud].[SolicitudObjeto] SO
								JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SC ON SC.idSolicitud=SO.idsolicitud
							WHERE SC.idCotizacion = @idCotizacion
						END
					IF(@propiedad = 'submarca')
						BEGIN
							SELECT 
								@valor = (SELECT [Objeto].[objeto].[getPropiedadObjeto](SO.idTipoObjeto,'Submarca','tipoClase',SO.idClase) + ' // ' )
							FROM [Solicitud].[solicitud].[SolicitudObjeto] SO
								JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SC ON SC.idSolicitud=SO.idsolicitud
							WHERE SC.idCotizacion = @idCotizacion
						END
					IF(@propiedad = 'razonsocial')
						BEGIN
							SELECT 
								@valor = (LTRIM(RTRIM(ISNULL(P.razonSocial,''))) + ' // ' )
							FROM [Solicitud].[solicitud].[SolicitudCotizacion] SC
								JOIN [Proveedor].[proveedor].[Proveedor] P on P.rfcProveedor = SC.rfcProveedor
							WHERE SC.idCotizacion = @idCotizacion		
						END
					IF(@propiedad = 'serieFolio')
						BEGIN
							IF EXISTS(SELECT 1 FROM cxp.SolicitudCotizacionFactura SFC WHERE SFC.idCotizacion=@idCotizacion)
								BEGIN
										SELECT 
											@valor = (LTRIM(RTRIM(ISNULL(F.serie,''))) + LTRIM(RTRIM(ISNULL(F.folio,''))) + ' // ' ) 
										FROM [Solicitud].[solicitud].[SolicitudCotizacion] SC 
											LEFT JOIN [Solicitud].[cxp].[SolicitudCotizacionFactura] SCF on SCF.idCotizacion = SC.idCotizacion AND SCF.idSolicitud = SC.idSolicitud
											LEFT JOIN [Solicitud].[cxp].[Factura] F on F.uuid = SCF.uuid 
										WHERE SC.idCotizacion = @idCotizacion
								END
							ELSE
								BEGIN
									SET @valor = 'N/A // '
								END
						END
					IF(@propiedad = 'orden')
						BEGIN
							SELECT 
								@valor = (LTRIM(RTRIM(ISNULL(SO.numeroOrden,''))) + ' // ' )
							FROM [Solicitud].[solicitud].[SolicitudObjeto] SO
								JOIN [Solicitud].[solicitud].[SolicitudCotizacion] SC ON SC.idSolicitud=SO.idsolicitud
							WHERE SC.idCotizacion = @idCotizacion
						END

					SET @ote_observaciones += @valor

					SET @Empieza = @Termina + 1
					SET @Termina = CHARINDEX(@Delimitador, @parameters, @Empieza)
				END
			SET @ote_observaciones = LEFT(@ote_observaciones, LEN(@ote_observaciones) - 3)
		END
	ELSE
		BEGIN
			SET @ote_observaciones = ''
		END

	RETURN @ote_observaciones
END

go

