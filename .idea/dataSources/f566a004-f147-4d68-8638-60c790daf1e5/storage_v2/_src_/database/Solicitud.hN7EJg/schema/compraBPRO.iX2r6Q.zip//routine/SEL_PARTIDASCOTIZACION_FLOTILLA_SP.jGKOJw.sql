
-- =============================================
-- Author:		<JLuis Lozada Guerrero>
-- Create date: <13/10/2020>
-- Description:	<Procedimiento que recupera los datos que se envian al servicio de flotillas>
-- =============================================
/*
	SELECT * FROM solicitud.solicitud.solicitud where idTipoSolicitud='Flotilla'
	--  delete from compraBPRO.SolicitudNotificacionFlotilla


	  SELECT * from compraBPRO.SolicitudNotificacionFlotilla

	Testing......
	EXEC [compraBPRO].SEL_PARTIDASCOTIZACION_FLOTILLA_SP 1272,'Flotilla','Compra','ASE0508051B6',222,'C002','ENVIADA',6282,null
*/

CREATE PROCEDURE [compraBPRO].[SEL_PARTIDASCOTIZACION_FLOTILLA_SP]
@idSolicitud		INT,
@idTipoSolicitud	VARCHAR(50),
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@estatus			VARCHAR(15),
@idUsuario			INT = 0,
@err				VARCHAR(8000) OUTPUT	
AS
BEGIN
	/*
		<partidas>
			<partida>
				<idPartida>21321</idPartida>
				<noParte>321321A</noParte>
				<cantidad>1</cantidad>
				<descripcion>Partidanueva1</descripcion>
				<costo>1000.00</costo>
				<venta>1000.00</venta>
				<idProveedor>3215</idProveedor>
				<nombreProveedor>Refacciones UnidasS.A.</nombreProveedor>
				<estatus>3</estatus>
			</partida>
		</partidas>
	*/
	DECLARE @datos TABLE(	idd					INT IDENTITY(1,1),
							idPartida			INT,
							noParte				VARCHAR(100),
							cantidad			INT,
							descripcion			VARCHAR(200),
							costo				FLOAT, 
							venta				FLOAT, 
							idProveedor			INT,
							nombreProveedor		VARCHAR(250),
							numeroCotizacion	VARCHAR(50),
							nombreSucursal		VARCHAR(250),
							estatus				INT)

	DECLARE @v_idd				INT,
			@v_idPartida		INT,
			@v_noParte			VARCHAR(100),
			@v_cantidad			INT,
			@v_descripcion		VARCHAR(200),
			@v_costo			FLOAT, 
			@v_venta			FLOAT, 
			@v_idProveedor		INT,
			@v_nombreProveedor	VARCHAR(250),
			@v_estatus			INT,
			@v_xml				VARCHAR(MAX)='',
			@v_numeroOrden		VARCHAR(30),
			@v_flag				INT=0,
			@v_numeroCotizacion	VARCHAR(50)='',
			@v_nombreSucursal	VARCHAR(250)=''


	SELECT	TOP 1 
			@v_numeroOrden		=numeroOrden 
	FROM	solicitud.solicitud.SolicitudObjeto sso
	WHERE	sso.idSolicitud		=@idSolicitud
	AND		sso.idTipoSolicitud	=@idTipoSolicitud
	AND		sso.idClase			=@idClase
	AND		sso.rfcEmpresa		=@rfcEmpresa
	AND		sso.idCliente		=@idCliente
	AND		sso.numeroContrato	=@numeroContrato




	INSERT INTO @datos(idPartida,noParte,cantidad,descripcion,costo,venta,idProveedor,nombreProveedor,numeroCotizacion,nombreSucursal,estatus)
	SELECT  scp.idPartida,ISNULL(partida.partida.getPropiedadPartida(scp.idPartida,'noParte','general'),'') noParte,
			scp.cantidad, ISNULL(partida.partida.getPropiedadPartida(scp.idPartida,'Descripción','general'),'') Descripcion,
			ISNULL(scp.costo,0),ISNULL(scp.venta,0),
			ISNULL((SELECT	idBPRO FROM Proveedor.proveedor.ProveedorEmpresa 
					WHERE	rfcProveedor=scp.rfcProveedor 
					AND		idPersonaBPRO= (SELECT	TOP 1 idPersonaBPRO 
											FROM	Cliente.cliente.contrato 
											WHERE	rfcempresa		= scp.rfcEmpresa 
											AND		idCliente		= scp.idCliente 
											AND		numeroContrato	= scp.numeroContrato )),'') 'idProveedor',
			ISNULL((SELECT nombreComercial FROM Proveedor.proveedor.proveedor WHERE rfcProveedor=SCP.rfcProveedor),'') nombreProveedor,
			sc.numeroCotizacion,
			ISNULL((SELECT	nombreComercial 
					FROM	proveedor.proveedor.proveedorEntidad 
					WHERE	rfcProveedor		=scp.rfcProveedor 
					AND		idProveedorEntidad	=scp.idProveedorEntidad),'')'nombreSucursal',
			CASE @estatus WHEN 'ENVIADA' then '3' WHEN 'CANCELADA' THEN  '5' ELSE '3' END
	-- select * 
	FROM	solicitud.SolicitudCotizacionPartida scp inner join solicitud.SolicitudCotizacion sc
	ON		scp.idSolicitud		=sc.idSolicitud
	AND     scp.idTipoSolicitud	=sc.idTipoSolicitud
	AND		scp.idClase			=sc.idClase
	AND     scp.rfcEmpresa		=sc.rfcEmpresa
	AND     scp.idCliente		=sc.idCliente
	AND     scp.numeroContrato	=sc.numeroContrato
	AND     scp.idCotizacion	=sc.idCotizacion
	WHERE	scp.idSolicitud		=@idSolicitud
	AND		scp.idTipoSolicitud	=@idTipoSolicitud
	AND		scp.idClase			=@idClase
	AND		scp.rfcEmpresa		=@rfcEmpresa
	AND		scp.idCliente		=@idCliente
	AND		scp.numeroContrato	=@numeroContrato


	


	WHILE EXISTS(SELECT 1 FROM @datos)
		BEGIN
			IF @v_flag=0 
				BEGIN
					SET @v_xml='<partidas>'
					SET @v_flag=1
				END

			SELECT	TOP 1  
					@v_idd=idd,@v_idPartida=idPartida,@v_noParte=noParte,@v_cantidad=cantidad,@v_descripcion=descripcion,@v_costo=costo,
					@v_venta=venta,@v_idProveedor=idProveedor,@v_nombreProveedor=nombreProveedor,@v_numeroCotizacion=numeroCotizacion,
					@v_nombreSucursal=nombreSucursal,@v_estatus=estatus
			FROM	@datos 

			SET @v_xml+='<partida><idPartida>'+CAST(@v_idPartida AS VARCHAR)+'</idPartida>'
			SET @v_xml+='<noParte>'+ @v_noParte +'</noParte>'
			SET @v_xml+='<cantidad>'+ CAST(@v_cantidad AS VARCHAR) +'</cantidad>'
			SET @v_xml+='<descripcion>'+ @v_descripcion +'</descripcion>'
			SET @v_xml+='<costo>'+ CAST(@v_costo AS VARCHAR) +'</costo>'
			SET @v_xml+='<venta>'+ CAST(@v_venta AS VARCHAR) +'</venta>'
			SET @v_xml+='<idProveedor>'+CAST(@v_idProveedor AS VARCHAR) +'</idProveedor>'
			SET @v_xml+='<nombreProveedor>'+ @v_nombreProveedor +'</nombreProveedor>'
			SET @v_xml+='<numeroCotizacion>'+ @v_numeroCotizacion +'</numeroCotizacion>'
			SET @v_xml+='<nombreSucursal>'+ @v_nombreSucursal +'</nombreSucursal>'
			SET @v_xml+='<estatus>'+ CAST(@v_estatus AS VARCHAR) +'</estatus></partida>'


			PRINT @v_xml
			DELETE FROM @datos WHERE idd=@v_idd

			IF (SELECT COUNT(*) FROM @datos)=0
				BEGIN
					SET @v_xml+='</partidas>'
				END
		END
		

		IF EXISTS(	SELECT 1 FROM compraBPRO.SolicitudNotificacionFlotilla
					WHERE	idSolicitud		=@idSolicitud
					AND		idTipoSolicitud	=@idTipoSolicitud
					AND		idClase			=@idClase
					AND		rfcEmpresa		=@rfcEmpresa
					AND		idCliente		=@idCliente
					AND		numeroContrato	=@numeroContrato)
			BEGIN
				DELETE FROM compraBPRO.SolicitudNotificacionFlotilla
				WHERE	idSolicitud		=@idSolicitud
				AND		idTipoSolicitud	=@idTipoSolicitud
				AND		idClase			=@idClase
				AND		rfcEmpresa		=@rfcEmpresa
				AND		idCliente		=@idCliente
				AND		numeroContrato	=@numeroContrato
			END
		
		INSERT INTO compraBPRO.SolicitudNotificacionFlotilla(idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,xmlcotizacionEnviada,observaciones,estatus,fechaEnvio,idUsuario)
		SELECT	idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,@v_xml,null,
				CASE @estatus WHEN 'ENVIADA' then 3 WHEN 'CANCELADA' THEN  5 ELSE 3 END,
				getdate(),
				@idUsuario
		FROM	Solicitud.Solicitud 
		WHERE	idSolicitud		=@idSolicitud
		AND		idTipoSolicitud	=@idTipoSolicitud
		AND		idClase			=@idClase
		AND		rfcEmpresa		=@rfcEmpresa
		AND		idCliente		=@idCliente
		AND		numeroContrato	=@numeroContrato
		
		
		SELECT	@v_numeroOrden numeroOrden,xmlcotizacionEnviada 'partidas',fechaEnvio,idUsuario,estatus 
		FROM	compraBPRO.SolicitudNotificacionFlotilla
		WHERE	idSolicitud		=@idSolicitud
		AND		idTipoSolicitud	=@idTipoSolicitud
		AND		idClase			=@idClase
		AND		rfcEmpresa		=@rfcEmpresa
		AND		idCliente		=@idCliente
		AND		numeroContrato	=@numeroContrato

END
go

