--use Solicitud
-- =============================================
-- Author:		<José Luis Lozada Guerrero>
-- Create date: <17/06/2020>
-- Description:	<guarda documento compra>

/*
	EXEC [compraBPRO].UPD_DOCUMENTO_CM_SP 627,'Compra','Compra','ASE0508051B6',221,'49',5252,6282,null
	
*/
CREATE PROCEDURE [compraBPRO].[UPD_DOCUMENTO_CM_SP]
@idSolicitud			INT,
@idTipoSolicitud		VARCHAR(50) = '',
@idClase				VARCHAR(10) = '',
@rfcEmpresa				VARCHAR(13) = '',
@idCliente				INT = 0,
@numeroContrato			VARCHAR(50) = '',
@idDocumentoCM			INT,
@idUsuario				INT = 0,
@err					VARCHAR(8000) OUTPUT
AS
BEGIN
	UPDATE  compraBPRO.Solicitud 
	SET     idDocumentoCM	=@idDocumentoCM
	WHERE	idSolicitud		=@idSolicitud
	AND		idTipoSolicitud	=@idTipoSolicitud
	AND		idClase			=@idClase
	AND		rfcEmpresa		=@rfcEmpresa
	AND		idCliente		=@idCliente
	AND		numeroContrato	=@numeroContrato
END
go

