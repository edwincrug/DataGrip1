
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 06-07-2019
-- Description: Consulta trae datos de solicitud para generar hoja de trabajo
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [solicitud].[SEL_SOLICITUD_HOJATRABAJO_SP]  452, 'Imagen', 'Automovil','ASE0508051B6', 185, '43', 'http://189.204.141.199:5114',  2326, @salida OUTPUT;
	SELECT @salida AS salida

	EXEC [solicitud].[SEL_SOLICITUD_HOJATRABAJO_SP]  1083, 'Instala', 'Automovil','AAN910409135', 218, '0001', 'http://189.204.141.199:5114',115,13872, 2326, ''
	select * from solicitud.solicitud where numero='1-1046'
	select * from solicitud.SolicitudObjeto where IDsOLICITUD=1083
*/
-- =============================================
CREATE  PROCEDURE [solicitud].[SEL_SOLICITUD_HOJATRABAJO_SP] 
	@idSolicitud			INT,
	@idTipoSolicitud		VARCHAR(10),
	@idClase				VARCHAR(10),
	@rfcEmpresa				VARCHAR(13),
	@idCliente				INT,
	@numeroContrato			VARCHAR(50),
	@fileServer				NVARCHAR(500),
	@idTipoObjeto			INT,
	@idObjeto				INT,
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

-----------------------------------------------------ENCABEZADO------------------------------------------------------

	select 
		SO.numeroOrden as NoReporte,
		CCC.nombre as nombreOperacion,
		CCC.idCliente as operacion,
		CCC.rfcEmpresa as RFC,
		CEE.razonSocial razonSocial,
		--GETDATE() AS fechaActual,
		CASE 
			WHEN EXISTS (select fechaIngreso from [Solicitud].[fase].[SolicitudEstatusPaso] where idSolicitud = @idSolicitud and idPaso = 'TerminoTrabajo') THEN (select fechaIngreso from [Solicitud].[fase].[SolicitudEstatusPaso] where idSolicitud = @idSolicitud and idPaso = 'TerminoTrabajo')
			ELSE GETDATE() END
		AS fechaActual,
		'*SE EXIME DE TODA RESPONSABILIDAD AL PERSONAL QUE EMITE ESTE REPORTE DE CONFORMIDAD, CUANDO A LA ENTREGA DE LOS BIENES, ARRENDAMIENTOS O SERVICIOS EN DESTINO FINAL O EN LA OPERACIÓN SE DETERMINEN FALTANTES, AVERIAS, DISCREPANCIAS, ENTREGAS INCOMPLETAS, O SE DETECTEN FALLAS O VICIOS O CUALTOS DE ACUERDO A LO ESTABLECIDO EN EL CONTRATO.' as txtLegal,
		(select @fileServer + [path] from fileserver.[documento].[Documento] where idDocumento = CCC.idFileAvatar) as logo,
		(select @fileServer + [path] from fileserver.[documento].[Documento] where idDocumento = CCC.idFileFirma) as firma,
		CCC.numeroContrato as contrato,
		CCOS.folio as noPresupuesto,
		CEE.puesto as puesto,
		OPC.valor AS VIN
	from solicitud.solicitud SOL
	INNER JOIN [cliente].[cliente].[Contrato] CCC ON CCC.idCliente = SOL.idCliente AND CCC.rfcEmpresa = SOL.rfcEmpresa AND CCC.numeroContrato = SOL.numeroContrato
	LEFT JOIN [cliente].[empresa].[Empresa] CEE ON CCC.rfcEmpresa = CEE.rfcEmpresa
	LEFT JOIN cliente.[contrato].[CentroCostoFolio] CCOS ON CCOS.rfcEmpresa = @rfcEmpresa AND  CCOS.idCliente = @idCliente AND CCOS.numeroContrato = @numeroContrato AND SOL.folio = CCOS.folio
	LEFT JOIN solicitud.SolicitudObjeto SO ON SO.idSolicitud = SOL.idSolicitud 
	INNER JOIN  objeto.objeto.ObjetoPropiedadClase OPC ON OPC.idObjeto = SO.idObjeto 
	where SOL.idSolicitud = @idSolicitud AND SO.idTipoObjeto = @idTipoObjeto AND SO.idObjeto = @idObjeto AND idPropiedadClase = 1

-----------------------------------------------------PARTIDAS------------------------------------------------------
	;with datos AS (
	select
			(SELECT  [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](SP.idTipoObjeto,'Submarca',@idClase)) as UNIDAD,
			SP.idPartida,
			(SELECT valor from partida.[partida].[PartidaPropiedadGeneral]
				WHERE idPartida = SP.idPartida
				AND idPropiedadGeneral = (select idPropiedadGeneral
											from partida.[partida].[PropiedadGeneral]
											WHERE agrupador = 'Descripción')) as descripcion,
			(SELECT valor from partida.[partida].[PartidaPropiedadGeneral]
				WHERE idPartida = SP.idPartida
				AND idPropiedadGeneral = (select idPropiedadGeneral
											from partida.[partida].[PropiedadGeneral]
											WHERE agrupador = 'Partida')) as partida,
			SP.cantidad as Cantidad,
			SP.venta AS PrecioUnitario,
			--SOL.numero AS numeroOrden,
			--CONVERT(VARCHAR(10), getdate(), 103) FechaInspeccion,
		SP.subTotalVenta as venta
		from solicitud.solicitud SOL
		INNER JOIN [solicitud].[SEL_TOTALES_PARTIDAS_VW] SP ON SP.idSolicitud = SOL.idSolicitud
		INNER JOIN partida.partida.partida PPP ON PPP.idPartida = SP.idPartida
		where SOL.idSolicitud = @idSolicitud AND SP.idTipoObjeto = @idTipoObjeto AND SP.idObjeto = @idObjeto
		AND SP.[idEstatusCotizacionPartida] = 'APROBADA'
   )

   select UNIDAD, idPartida, descripcion, partida, sum(cantidad) as Cantidad, PrecioUnitario, sum(venta) as venta from datos
   group by UNIDAD, idPartida, descripcion, partida,PrecioUnitario 
   ;

   
    select SUM(subTotalVenta) as    total
    FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] VW
    WHERE VW.[idEstatusCotizacionPartida] = 'APROBADA'
    AND VW.idSolicitud = @idSolicitud AND VW.idTipoObjeto = @idTipoObjeto AND VW.idObjeto = @idObjeto


	declare @firma table (
						idToken int,
						token varchar(6),
						fechaCrea datetime,
						fechaUso datetime,
						idUsuarioCrea int ,
						idUsuarioUsa int,
						idPaso varchar(50),
						idTipoToken int,
						estatus bit,
						idSolicitud int,
						idTipoSolicitud VARCHAR(10),
						idClase varchar(50),
						rfcEmpresa varchar(13),
						idCliente int,
						numeroContrato varchar(50)
						)
	insert into @firma
	EXEC [token].[SEL_TOKEN_POR_SOLICITUD_PASO_SP]
	@idSolicitud,
	'Entrega',
	@idUsuario

	--select * from @firma


	--SELECT token, fechaUso, idUsuarioCrea, idUsuarioUsa  FROM @firma WHERE fechaUso is null

	IF EXISTS(SELECT token, fechaUso, idUsuarioUsa  FROM @firma WHERE fechaUso is null) --OR NOT EXISTS (SELECT token, fechaUso, idUsuarioUsa  FROM @firma WHERE fechaUso is null)
		BEGIN
			select 
			'' as token,
			'' as fechaHora,
			'' as nombreCompleto

		END

	ELSE
		BEGIN
			select 
			token as token,
			fechaUso as fechaHora,
			ISNULL(U.PrimerNombre, '') + ' ' + isnull(U.SegundoNombre, '') + ' ' + ISNULL(U.PrimerApellido, '') + ' ' + ISNULL(U.segundoApellido,'') as nombreCompleto
			FROM @firma F
			LEFT JOIN [seguridad].[Catalogo].[Users] U ON U.id = F.idUsuarioUsa
		END
	

	select
	CGC.descripcion as nombreNivel,
	CGZ.descripcion as nombre
	from 
	solicitud.solicitud SOL 
	INNER JOIN [Solicitud].[solicitud].[SolicitudObjeto] SSO ON SSO.idSolicitud = SOL.idSolicitud
	INNER JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = SSO.idObjeto
	INNER JOIN [common].[gerencia].[ContratoZona] CGZ ON CGZ.idContratoZOna =  CCO.idContratoZona
	INNER JOIN [common].[gerencia].[ContratoNivel] CGC ON CGC.idContratoNivel = CGZ.idContratoNivel
	WHERE SOL.idSolicitud = @idSolicitud AND SSO.idTipoObjeto = @idTipoObjeto AND SSO.idObjeto = @idObjeto
	AND SOL.idClase = @idClase
END

--USE [Solicitud]
go

