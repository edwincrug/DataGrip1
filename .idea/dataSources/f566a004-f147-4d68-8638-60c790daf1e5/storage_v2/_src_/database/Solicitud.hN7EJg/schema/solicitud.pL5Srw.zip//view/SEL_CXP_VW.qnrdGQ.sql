




-- =============================================
-- Author:			<Adolfo Martinez>
-- Create date: 	<28/08/2020>
-- Description:	    <Vista para obtener datos de la cxp, la informacion esta a nivel de solicitud>
-- ============== Versionamiento ================  
/* 
SELECT * FROM [solicitud].[SEL_CXP_VW] WHERE idSolicitud=1760
*/

CREATE VIEW [solicitud].[SEL_CXP_VW]
AS
	
	SELECT  
		SCF.idSolicitud,
		SCF.idTipoSolicitud,
		SCF.idClase,
		SCF.rfcEmpresa,
		SCF.idCliente,
		SCF.numeroContrato,
		(SELECT STUFF((SELECT ',' + CAST(ISNULL(FF.OTE_IDENT,'') AS VARCHAR(MAX)) FROM [Solicitud].[cxc].[FacturaBPRO] FF WHERE FF.idSolicitud	= SCF.idSolicitud FOR XML PATH('')),1,1,'')) AS 'OTE_IDENT',
		(SELECT STUFF((SELECT ',' + CAST(ISNULL(FF.OTE_FACTURACOMPRA,'') AS VARCHAR(MAX)) FROM [Solicitud].[cxc].[FacturaBPRO] FF WHERE FF.idSolicitud	= SCF.idSolicitud FOR XML PATH('')),1,1,'')) AS 'OTE_FACTURACOMPRA',
		(SELECT	STUFF((SELECT ',' + CAST(ISNULL(FF.serie,'') AS VARCHAR(MAX)) + CAST(ISNULL(FF.folio,'') AS VARCHAR(MAX))
		 FROM [Solicitud].[cxp].[Factura] FF JOIN [Solicitud].[cxp].[SolicitudCotizacionFactura] SS ON SS.UUID = FF.UUID
		 WHERE	SS.idSolicitud	= SCF.idSolicitud ORDER BY SS.idCotizacion FOR XML PATH('')),1,1,'')) AS 'Factura',
		SUM(total) AS 'Importe',
		SUM(saldo) AS 'Saldo',
		 (SELECT STUFF((SELECT ',' + CAST(ISNULL(FB.CCP_FECHADOCTO,'') AS VARCHAR(MAX))
		 FROM [Solicitud].[cxp].[FacturaBPRO] FB JOIN [Solicitud].[cxp].[SolicitudCotizacionFactura] SS ON SS.UUID = FB.UUID
		 WHERE	SS.idSolicitud	= SCF.idSolicitud ORDER BY SS.idCotizacion FOR XML PATH('')),1,1,'')) AS 'FechaFactura',
		 (SELECT STUFF((SELECT ',' + CAST(ISNULL(FB.CCP_FECHVEN,'') AS VARCHAR(MAX))
		 FROM [Solicitud].[cxp].[FacturaBPRO] FB JOIN [Solicitud].[cxp].[SolicitudCotizacionFactura] SS ON SS.UUID = FB.UUID
		 WHERE	SS.idSolicitud	= SCF.idSolicitud ORDER BY SS.idCotizacion FOR XML PATH('')),1,1,'')) AS 'FechaVencimiento',
		 (SELECT STUFF((SELECT ',' + CAST(ISNULL(FB.CCP_FECHPROMPAG,'') AS VARCHAR(MAX))
		 FROM [Solicitud].[cxp].[FacturaBPRO] FB JOIN [Solicitud].[cxp].[SolicitudCotizacionFactura] SS ON SS.UUID = FB.UUID
		 WHERE	SS.idSolicitud	= SCF.idSolicitud ORDER BY SS.idCotizacion FOR XML PATH('')),1,1,'')) AS 'FechaPago'		
	FROM [Solicitud].[cxp].[SolicitudCotizacionFactura] SCF
		JOIN [Solicitud].[cxp].[Factura] F ON SCF.uuid = F.uuid
	GROUP BY SCF.idSolicitud,SCF.idTipoSolicitud,SCF.idClase,SCF.rfcEmpresa,SCF.idCliente,SCF.numeroContrato

	UNION

	SELECT  
		SCF.idSolicitud,
		SCF.idTipoSolicitud,
		SCF.idClase,
		SCF.rfcEmpresa,
		SCF.idCliente,
		SCF.numeroContrato,
		(SELECT STUFF((SELECT ',' + CAST(ISNULL(FF.OTE_IDENT,'') AS VARCHAR(MAX)) FROM [Solicitud].[cxc].[FacturaBPRO] FF WHERE FF.idSolicitud	= SCF.idSolicitud FOR XML PATH('')),1,1,'')) AS 'OTE_IDENT',
		(SELECT STUFF((SELECT ',' + CAST(ISNULL(FF.OTE_FACTURACOMPRA,'') AS VARCHAR(MAX)) FROM [Solicitud].[cxc].[FacturaBPRO] FF WHERE FF.idSolicitud	= SCF.idSolicitud FOR XML PATH('')),1,1,'')) AS 'OTE_FACTURACOMPRA',
		NULL AS 'Factura',
		SUM(total) AS 'Importe',
		SUM(saldo) AS 'Saldo',
		(SELECT	STUFF((SELECT ',' + CAST(ISNULL(FB.CCP_FECHADOCTO,'') AS VARCHAR(MAX))
		 FROM [Solicitud].[cxp].[FacturaBPRO] FB JOIN [Solicitud].[cxp].[SolicitudCotizacionFactura] SS ON SS.UUID = FB.UUID
		 WHERE	SS.idSolicitud	= SCF.idSolicitud ORDER BY SS.idCotizacion FOR XML PATH('')),1,1,'')) AS 'FechaFactura',
		 (SELECT STUFF((SELECT ',' + CAST(ISNULL(FB.CCP_FECHVEN,'') AS VARCHAR(MAX))
		 FROM [Solicitud].[cxp].[FacturaBPRO] FB JOIN [Solicitud].[cxp].[SolicitudCotizacionFactura] SS ON SS.UUID = FB.UUID
		 WHERE	SS.idSolicitud	= SCF.idSolicitud ORDER BY SS.idCotizacion FOR XML PATH('')),1,1,'')) AS 'FechaVencimiento',
		 (SELECT STUFF((SELECT ',' + CAST(ISNULL(FB.CCP_FECHPROMPAG,'') AS VARCHAR(MAX))
		 FROM [Solicitud].[cxp].[FacturaBPRO] FB JOIN [Solicitud].[cxp].[SolicitudCotizacionFactura] SS ON SS.UUID = FB.UUID
		 WHERE	SS.idSolicitud	= SCF.idSolicitud ORDER BY SS.idCotizacion FOR XML PATH('')),1,1,'')) AS 'FechaPago'		
	FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaPorConsolidar] SCF
		JOIN [Solicitud].[cxp].[FacturaPorConsolidar] F ON SCF.uuid = F.uuid
	GROUP BY SCF.idSolicitud,SCF.idTipoSolicitud,SCF.idClase,SCF.rfcEmpresa,SCF.idCliente,SCF.numeroContrato

go

