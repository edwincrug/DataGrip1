
-- =============================================
-- Author:		Alan Rosales Chávez
-- Create date: 18/06/2020
-- Description:	Crea una nueva solicitud de partidas existentes BPRO.
-- =============================================
/*
	Fecha		Autor			Descripción 
	19/10/2020	JLuis Lozada	Se hizo ajuste para flotillas
	
	*- Testing...
	'
		<partidas>
			<partida><idPartida>787157</idPartida><cantidad>1</cantidad><costoInicial>1500</costoInicial><ventaInicial>1000</ventaInicial></partida>
			<partida><idPartida>787158</idPartida><cantidad>1</cantidad><costoInicial>200</costoInicial><ventaInicial>0</ventaInicial></partida>
		</partidas>
	'


	DECLARE @salida varchar(max) ='' ;
	EXEC [compraBPRO].[INS_SOLICITUD_SP]
		 @rfcEmpresa				= 'ASE0508051B6'
		,@idCliente					= 221
		,@numeroContrato			= '49'
		,@idCentroCosto				= ''
		,@idCentroCostoFolio		= ''
		,@idObjeto					= 13549
		,@idTipoObjeto				= 840
		,@idClase					= 'Compra'
		,@idTipoSolicitud			= 'Compra'
		,@fecha						= '2019-07-06 00:00:00.000'
		,@Propiedades				=	
		'
			<Propiedades>
				<propiedad><idPropiedad>9</idPropiedad><valores><valor>oficinas san jeronimo</valor></valores></propiedad>
				<propiedad><idPropiedad>10</idPropiedad><valores><valor>55555555</valor></valores></propiedad>
				<propiedad><idPropiedad>11</idPropiedad><valores><valor>55555555</valor></valores></propiedad>
				<propiedad><idPropiedad>12</idPropiedad><valores><valor>justificación</valor></valores></propiedad>
				<propiedad><idPropiedad>13</idPropiedad><valores><valor>15</valor></valores></propiedad>
				<propiedad><idPropiedad>19</idPropiedad><valores><valor>21</valor></valores></propiedad>
				<propiedad><idPropiedad>23</idPropiedad><valores><valor>18/06/2020</valor></valores></propiedad>
			</Propiedades>,
		'
		,@partidas					= 
		'
			<partidas>
				<partida><idPartida>787157</idPartida><cantidad>1</cantidad><costoInicial>1500</costoInicial><ventaInicial>1000</ventaInicial></partida>
				<partida><idPartida>787158</idPartida><cantidad>1</cantidad><costoInicial>200</costoInicial><ventaInicial>0</ventaInicial></partida>
			</partidas>
		'
		,@partidasNuevas			= 
		'
			<partidas><partida><cantidad>1</cantidad><descripcion>Partida nueva</descripcion></partida></partidas>
		'
		,@comentarios				= 'TEST DE SP INS BPRO'
		,@idEmpresaBPRO				= 4
		,@idSucursalBPRO			= 8
		,@idAreaBPRO				= 138
		,@idUsuario					= 6282
		,@err  = @salida out
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [compraBPRO].[INS_SOLICITUD_SP]
	@rfcEmpresa					VARCHAR(13) = ''
	,@idCliente					INT = 0
	,@numeroContrato			VARCHAR(50) = ''
	,@idCentroCosto				INT
	,@idCentroCostoFolio		VARCHAR(200) = ''
	,@idObjeto					INT = 0
	,@idTipoObjeto				INT = 0
    ,@idClase					VARCHAR(10) = ''
	,@idTipoSolicitud			VARCHAR(50) = ''
	,@fecha						DATETIME = null
	,@propiedades				XML
	,@propiedadesTipoSolicitud	XML = NULL
	,@partidas					XML
	,@partidasNuevas			XML
	,@comentarios				VARCHAR(MAX) = ''
	,@idEmpresaBPRO				INT=null
	,@idSucursalBPRO			INT=null
	,@idAreaBPRO				INT=null
	,@idUsuario					INT = 0
	,@err						VARCHAR(8000) OUTPUT	
AS
BEGIN

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED


    DECLARE
		@VI_One				INT				= 1,
		@VI_Zero			INT				= 0,
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en el stored: [INS_SOLICITUD_SP]:',
		@VC_ErrorSeverity	INT				= 0,
		@VC_ErrorState		INT				= 0,
		@VI_ResultCount		INT				= 0,
		@VI_IdSolicitud		INT				= NULL,
		@VI_IdCotizacion	INT				= NULL,
		@VC_NOSOLICITUD		VARCHAR(20)		= NULL,
		@VC_NOCOTIZACION	VARCHAR(20)		= NULL,
		@VD_ExpiraContrato	DATE			= NULL,
		@ERR_MENSAJE		VARCHAR(100)	= '',
		@xmlPadre			XML

	DECLARE @VT_Table TABLE (
		[Index]			    INT IDENTITY(1,1),
		[idPartida]			INT,
		[cantidad]			INT,
		[costoInicial]		float, 
		[ventaInicial]		float
	);

	DECLARE @VT_Propiedades TABLE (
		[Index]			    INT IDENTITY(1,1),
		[idPropiedadClase]	INT,
		[Valor]				XML
	);

	DECLARE @VT_PropiedadesSolicitud TABLE (
		[Index]			    INT IDENTITY(1,1),
		[idPropiedadTipoSolicitud]	INT,
		[Valor]				XML
	);
	
	DECLARE @VT_PartidasNuevas TABLE(
		[Index]				INT IDENTITY(1,1),
		[cantidad]			FLOAT,
		[descripcion]		VARCHAR(MAX)
	)

	DECLARE @VT_SOLICITUDES TABLE(
		idSolicitud			INT,
		tipoSolciitudBPRO 	VARCHAR(2) --CM = Solicitud de compra, EM = Solicitud de estudio de mercado
	)

	DECLARE @VT_Proveedores TABLE(
		[Index]				INT IDENTITY(1,1),
		rfcProveedor		VARCHAR(13),
		idProveedorEntidad	INT
	)

	CREATE TABLE  #VT_Table_ProveedorPartida (
		[Index]			    INT IDENTITY(1,1),
		[idPartida]			INT,
		[cantidad]			INT,
		[costoInicial]		float, 
		[ventaInicial]		float
	);
	
	BEGIN TRY

		--INSERTAMOS PROPIEDADES DE CLASE
		INSERT INTO @VT_Propiedades
			SELECT
				I.N.value('(idPropiedad)[1]',	'INT'),
				I.N.query('valores/.')
			FROM @Propiedades.nodes('/Propiedades/propiedad') I(N);
		--INSERTAMOS PROPIEDADES POR TIPO DE SOLICITUD
		INSERT INTO @VT_PropiedadesSolicitud
			SELECT
				I.N.value('(idPropiedad)[1]',	'INT'),
				I.N.query('valores/.')
			FROM @PropiedadesTipoSolicitud.nodes('/Propiedades/propiedad') I(N);

		--INSERTAMOS LAS PARTIDAS DE CATALOGO
		INSERT INTO @VT_Table
			SELECT
				I.N.value('(idPartida)[1]',	'INT'),
				I.N.value('(cantidad)[1]',	'INT'),
				I.N.value('(costoInicial)[1]',	'float'),
				I.N.value('(ventaInicial)[1]',	'float')
			FROM @partidas.nodes('/partidas/partida') I(N);

		--INSERTAMOS LAS PARTIDAS PARA ESTUDIO DE MERCADO
		INSERT INTO @VT_PartidasNuevas
			SELECT	
				ParamValues.col.value('cantidad[1]','int'),    
				ParamValues.col.value('descripcion[1]','nvarchar(1000)')
		FROM	@partidasNuevas.nodes('partidas/partida') AS ParamValues(col)   

		--OBTENEMOS EL LISTADO DE PROVEEDORES QUE ATIENDEN LAS PARTIDAS SELECCIONADAS:
		INSERT INTO @VT_Proveedores
		SELECT DISTINCT 
			pe.rfcProveedor,
			pe.idProveedorEntidad
		FROM @VT_Table t
		INNER JOIN Partida.partida.Partida p on p.idPartida = t.idPartida
		INNER JOIN compraBPRO.ProveedorEntidadPartida pe on pe.numeroParte = partida.partida.getPropiedadPartida(p.idPartida,'noParte','general')

		--OBTENEMOS EL IDUSUARIO DE BPRO
		DECLARE @idUsuarioBPRO INT 
		SELECT TOP 1 @idUsuarioBPRO=ISNULL(idUsuarioBPRO,0) FROM common.configuracion.usuariosBPRO WHERE idUsuario=@idUsuario		

		
		DECLARE @pCount INT = 1, @pMax INT = (SELECT count([Index]) FROM @VT_Propiedades); --PROPIEDADES DE CLASE
		DECLARE @sCount INT = 1, @sMax INT = (SELECT COUNT([Index]) FROM @VT_PropiedadesSolicitud); --PROPIEDADES DE TIPO SOLICITUD
		DECLARE @count INT = 1, @max INT = (SELECT count([Index]) FROM @VT_Table); --PARTIDAS DE CATALOGO
		DECLARE @pnCount INT = 1, @pnMax INT = (SELECT COUNT([Index]) FROM @VT_PartidasNuevas); --PARTIDAS NUEVAS
		DECLARE @prCount INT = 1, @prMax INT = (SELECT COUNT([Index]) FROM @VT_Proveedores); --PROVEEDORES
		

		SELECT @VD_ExpiraContrato = (
				SELECT 
					COALESCE([fechaFin], null) 
				FROM [Cliente].[cliente].[Contrato]
				WHERE 
					[rfcEmpresa] = @rfcEmpresa AND
					[idCliente] = @idCliente AND
					[numeroContrato] = @numeroContrato
			)
		
		BEGIN TRANSACTION INS
		IF (@VD_ExpiraContrato >= GETDATE())		
		BEGIN
			-- VERIFICAMOS SI EXISTEN PARTIDAS DE CATALOGO
			IF @max>0
			BEGIN
				WHILE (@prCount<=@prMax)
				BEGIN
					SELECT 
						 @pCount=1
						,@sCount=1
						,@count=1
						,@pnCount=1
					--INSERTAMOS LAS PARTIDAS CORRESPONDIENTES AL PROVEEDOR
					TRUNCATE TABLE #VT_Table_ProveedorPartida
					INSERT INTO #VT_Table_ProveedorPartida
					SELECT 
						T.idPartida
						,T.cantidad
						,T.costoInicial
						,T.ventaInicial
					FROM @VT_Table T
					INNER JOIN Partida.partida.Partida p on p.idPartida = t.idPartida
					INNER JOIN compraBPRO.ProveedorEntidadPartida pe on pe.numeroParte = partida.partida.getPropiedadPartida(p.idPartida,'noParte','general')
					INNER JOIN @VT_Proveedores PP ON PP.rfcProveedor = PE.rfcProveedor and PP.idProveedorEntidad=PP.idProveedorEntidad
					where 
						PP.[Index] = @prCount
					--***********************************************************************************************
				--0. OBTENEMOS NUMERO DE SOLICITUD
				--***********************************************************************************************
				SELECT @VC_NOSOLICITUD = (SELECT [solicitud].[SEL_NUMEROSOLICITUD_FN](@rfcEmpresa, @idCliente, @numeroContrato));
				--***********************************************************************************************
				--1. CREAMOS ENCABEZADO DE SOLICITUD
				--***********************************************************************************************
				INSERT INTO [solicitud].[Solicitud] (
						 [rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idCentroCosto]
						,[folio]
						,[idTipoSolicitud]
						,[idClase]
						,[fechaCreacion]
						,[fechaCita]
						,[numero]
						,[comentarios]
						,[idEstatusSolicitud]
						,[idUsuario]
						,[esMultiple]
					) VALUES (
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idCentroCosto,
						@idCentroCostoFolio,
						@idTipoSolicitud,
						@idClase,
						GETDATE(),
						@fecha,
						@VC_NOSOLICITUD,
						@comentarios,
						'ACTIVA',
						@idUsuario,
						0
					)
				SET @VI_IdSolicitud = SCOPE_IDENTITY()
				--***********************************************************************************************
				--2. ACTUALIZAMOS CONSECUTIVO DEL CONTRATO
				--***********************************************************************************************
				UPDATE [solicitud].[ContratoConsecutivo]
							SET [consecutivo] = (
								SELECT 
									CAST([consecutivo] AS INT) + 1
								FROM [solicitud].[ContratoConsecutivo]
								WHERE 
									[rfcEmpresa] = @rfcEmpresa AND
									[idCliente] = @idCliente AND
									[numeroContrato] = @numeroContrato
							)
							WHERE 
								[rfcEmpresa] = @rfcEmpresa AND
								[idCliente] = @idCliente AND
								[numeroContrato] = @numeroContrato 
				--***********************************************************************************************
				--3. INSERTAMOS SOLICITUDOBJETO
				--***********************************************************************************************
				INSERT INTO [solicitud].[SolicitudObjeto](
						 [idSolicitud]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idTipoSolicitud]
						,[idObjeto]
						,[idTipoObjeto]
						,[idClase]
						,[numeroOrden]
						,[fechaAlta]
						,[idUsuario]
					) VALUES (
						@VI_IdSolicitud,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idTipoSolicitud,
						@idObjeto,
						@idTipoObjeto,
						@idClase,
						(@VC_NOSOLICITUD +'-'+ CONVERT(VARCHAR(20), @idObjeto)),
						@fecha,
						@idUsuario
					)
				
				--***********************************************************************************************
				--4. INSERTAMOS LA SOLICITUD EN COMPRABPRO
				--***********************************************************************************************
				INSERT INTO [compraBPRO].[solicitud](
					idSolicitud
					,idTiposolicitud
					,idClase
					,rfcEmpresa
					,idCliente
					,numeroContrato
					,idUsuarioBPRO
					,idEmpresa
					,idSucursal
					,idArea
					,idUsuario
					,activo)
					VALUES(
						@VI_IdSolicitud
						,@idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,@idUsuarioBPRO
						,@idEmpresaBPRO
						,@idSucursalBPRO
						,@idAreaBPRO
						,@idUsuario
						,1
					)
				--***********************************************************************************************
				--5. INSERTAMOS PARTIDAS DE CATALOGO
				--***********************************************************************************************
				DECLARE @pCCount INT = 1, @pCMax INT = (SELECT COUNT([Index]) FROM #VT_Table_ProveedorPartida);
				WHILE (@pCCount <= @pCMax)
				BEGIN
					INSERT INTO [solicitud].[SolicitudPartida] (
							[idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idObjeto]
						,[idTipoObjeto]
						,[idPartida]
						,[cantidad]
						,[costoInicial]
						,[ventaInicial]
						,[idEstatusSolicitudPartida]
						,[idUsuario]
					) VALUES (
						@VI_IdSolicitud
						,@idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,@idObjeto
						,@idTipoObjeto
						,(SELECT [idPartida] FROM #VT_Table_ProveedorPartida WHERE [Index] = @pCCount)
						,(SELECT [cantidad] FROM #VT_Table_ProveedorPartida WHERE [Index] = @pCCount)
						,(SELECT [costoInicial] FROM #VT_Table_ProveedorPartida WHERE [Index] = @pCCount)
						,(SELECT [ventaInicial] FROM #VT_Table_ProveedorPartida WHERE [Index] = @pCCount)
						,'ENESPERA'
						, @idUsuario
					)
					SET @pCCount = @pCCount + 1;
				END
				--***********************************************************************************************
				--6. INSERTAMOS PROPIEDADES DE CLASE
				--***********************************************************************************************
				WHILE (@pCount <= @pMax)
				BEGIN
					SET @xmlPadre = (SELECT [Valor] FROM @VT_Propiedades WHERE [Index] = @pCount)
					INSERT INTO [solicitud].[SolicitudPropiedadClase] (
							[idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idPropiedadClase]
						,[valor]
						,[fechaCaducidad]
						,[idUsuario]
					) VALUES (
						@VI_IdSolicitud,
						@idTipoSolicitud,
						@idClase,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						case when 
							(
								select idTipoValor from solicitud.PropiedadClase where idPropiedadClase = 
								(
									SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount
								)
							)!='Unico' 
							THEN 
								(SELECT	I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))									
							ELSE
								(SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount)
						END,
						case when 
							(
								select idTipoValor from solicitud.PropiedadClase where idPropiedadClase = 
								(
									SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount
								)
							)!='Unico' 
							then ''
							ELSE
							(SELECT I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))
						END,
						NULL,
						@idUsuario
					)

					IF @idTipoSolicitud='Compra'
						BEGIN
							--EN CASO DE QUE LA PROPIEDAD SEA DE TIPO ARCHIVO Y SEA PARA COMPRAS, LA INSERTAMOS COMO EVIDENCIA
							IF EXISTS(	SELECT 1 FROM solicitud.PropiedadClase 
										WHERE idPropiedadClase = (	SELECT	[idPropiedadClase] 
																	FROM	@VT_Propiedades 
																	WHERE	[Index] = @pCount) 
																	AND		idTipoDato='File')
							BEGIN
								INSERT INTO documento.SolicitudObjetoEvidencia(
									idSolicitud
									,idTipoObjeto
									,idClase
									,rfcEmpresa
									,idCliente
									,numeroContrato
									,idTipoSolicitud
									,idObjeto
									,idSolicitudObjetoEvidencia
									,idFileServer							
								) VALUES(
									@VI_IdSolicitud
									,@idTipoObjeto
									,@idClase
									,@rfcEmpresa
									,@idCliente							
									,@numeroContrato
									,@idTipoSolicitud
									,@idObjeto
									,1
									,(SELECT	I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))	
								)
							END
						END
					SET @pCount = @pCount + 1 
				END

				--***********************************************************************************************
				--7. INSERTAMOS PROPIEDADES POR TIPO DE SOLICITUD
				--***********************************************************************************************
				WHILE (@sCount <= @sMax)
				BEGIN
					SET @xmlPadre = (SELECT [Valor] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount)
					INSERT INTO [solicitud].[SolicitudPropiedadTipoSolicitud] (
						[idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idPropiedadTipoSolicitud]
						,[valor]
						,[fechaCaducidad]
						,[idUsuario]
					) VALUES (
						@VI_IdSolicitud,
						@idTipoSolicitud,
						@idClase,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						case when 
							(
								select idTipoValor from solicitud.PropiedadTipoSolicitud where idPropiedadTipoSolicitud = 
								(
									SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount
								)
							)!='Unico' 
							THEN 
								(SELECT	I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))									
							ELSE
								(SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount)
						END,
						case when 
							(
								select idTipoValor from solicitud.PropiedadTipoSolicitud where idPropiedadTipoSolicitud = 
								(
									SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount
								)
							)!='Unico' 
							then ''
							ELSE
							(SELECT I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))
						END,
						NULL,
						@idUsuario
					)
					SET @sCount = @sCount + 1 
				END
				--***********************************************************************************************
				--8. INSERTAMOS HISTORICO DE LA SOLICITUD
				--***********************************************************************************************
				INSERT INTO [fase].[SolicitudEstatusPaso] (
						  [idSolicitud]
						 ,[rfcEmpresa]
						 ,[idCliente]
						 ,[numeroContrato]
						 ,[idPaso]
						 ,[idFase]
						 ,[idClase]
						 ,[idTipoSolicitud]
						 ,[fechaIngreso]
						 ,[idEstatus]
						 ,[idUsuarioIngreso]
					) VALUES (
						@VI_IdSolicitud
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,(SELECT 
						top 1	[idPaso] 
						from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
						,(SELECT 
						top 1	idFase 
						from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
						,@idClase
						,@idTipoSolicitud
						,GETDATE()
						,1
						,@idUsuario
					)
				--***********************************************************************************************
				--9. INSERTAMOS A LA TABLA DE SALIDA LA SOLICITUD GENERADA
				--***********************************************************************************************
				INSERT INTO @VT_SOLICITUDES VALUES(@VI_IdSolicitud,'CM')
				--***********************************************************************************************
				--10. CREAMOS LA COTIZACION DE FORMA AUTOMATICA
				--***********************************************************************************************
				SET @VC_NOCOTIZACION = (SELECT [solicitud].[SEL_NUMEROCOTIZACION_FN](@VI_IdSolicitud,@rfcEmpresa,@idTipoSolicitud,@idClase,@idCliente,@numeroContrato))
				INSERT INTO [solicitud].[SolicitudCotizacion] (
						 [idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idProveedorEntidad]
						,[rfcProveedor]
						,[numeroCotizacion]
						,[fechaAlta]
						,[idUsuario]
						,[idEstatusCotizacion]
					) VALUES (
						 @VI_IdSolicitud
						,@idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,(select idProveedorEntidad from @VT_Proveedores where [Index]=@prCount)
						,(select rfcProveedor from @VT_Proveedores where [Index]=@prCount)
						,@VC_NOCOTIZACION
						,GETDATE()
						,@idUsuario
						,'ENESPERA'
					)
				SET @VI_IdCotizacion = SCOPE_IDENTITY()	
				INSERT INTO solicitud.SolicitudCotizacionPartida ([idCotizacion]
						, [idSolicitud]
						, [idTipoSolicitud]
						, [idClase]
						, [rfcEmpresa]
						, [numeroContrato]
						, [idCliente]
						, [rfcProveedor]
						, [idProveedorEntidad]
						, [idObjeto]
						, [idTipoObjeto]
						, [idPartida]
						, [cantidad]
						, [costo]
						, [venta]
						, [idEstatusCotizacionPartida]
						, [fechaEstatus]
						, [idUsuario])
					SELECT @VI_idCotizacion
						, @VI_IdSolicitud
						, @idTipoSolicitud
						, @idClase
						, @rfcEmpresa
						, @numeroContrato
						, @idCliente
						,(select rfcProveedor from @VT_Proveedores where [Index]=@prCount)
						,(select idProveedorEntidad from @VT_Proveedores where [Index]=@prCount)						
						, VT.idObjeto
						, VT.idTipoObjeto
						, VT.idPartida
						, VT.cantidad
						, VT.costoInicial
						, VT.ventaInicial
						, 'ENESPERA'
						, GETDATE()
						, @idUsuario
					FROM solicitud.SolicitudPartida VT
					where idSolicitud = @VI_IdSolicitud
				INSERT INTO [solicitud].[EstatusSolicitudCotizacion] (
					fechaAlta
					,idCotizacion
					,idSolicitud
					,idTipoSolicitud
					,idClase
					,rfcEmpresa
					,idCliente
					,numeroContrato
					,idProveedorEntidad
					,rfcProveedor
					,idEstatusCotizacion
					,idUsuario
				) VALUES (
					GETDATE()
					,@VI_idCotizacion
					,@VI_IdSolicitud
					,@idTipoSolicitud
					,@idClase
					,@rfcEmpresa
					,@idCliente
					,@numeroContrato
					,(select idProveedorEntidad from @VT_Proveedores where [Index]=@prCount)
					,(select rfcProveedor from @VT_Proveedores where [Index]=@prCount)
					,'ENESPERA'
					,@idUsuario
				)
				--***********************************************************************************************
				--***********************************************************************************************
				--FIN
				--***********************************************************************************************
				set @prCount=@prCount+1
				END				
			END
			-- VERIFICAMOS SI EXISTEN PARTIDAS NUEVAS
			IF @pnMax>0
			BEGIN
				--CREAMOS UNA SOLICITUD QUE SE ENVIARÁ A ESTUDIO DE MERCADO
				--***********************************************************************************************
				--0. OBTENEMOS NUMERO DE SOLICITUD
				--***********************************************************************************************
				SELECT @VC_NOSOLICITUD = (SELECT [solicitud].[SEL_NUMEROSOLICITUD_FN](@rfcEmpresa, @idCliente, @numeroContrato));
				--***********************************************************************************************
				--1. CREAMOS ENCABEZADO DE SOLICITUD
				--***********************************************************************************************
				INSERT INTO [solicitud].[Solicitud] (
						 [rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idCentroCosto]
						,[folio]
						,[idTipoSolicitud]
						,[idClase]
						,[fechaCreacion]
						,[fechaCita]
						,[numero]
						,[comentarios]
						,[idEstatusSolicitud]
						,[idUsuario]
						,esMultiple
					) VALUES (
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idCentroCosto,
						@idCentroCostoFolio,
						@idTipoSolicitud,
						@idClase,
						GETDATE(),
						@fecha,
						@VC_NOSOLICITUD,
						@comentarios,
						'ACTIVA',
						@idUsuario,
						0
					)
				SET @VI_IdSolicitud = SCOPE_IDENTITY()
				--***********************************************************************************************
				--2. ACTUALIZAMOS CONSECUTIVO DEL CONTRATO
				--***********************************************************************************************
				UPDATE [solicitud].[ContratoConsecutivo]
							SET [consecutivo] = (
								SELECT 
									CAST([consecutivo] AS INT) + 1
								FROM [solicitud].[ContratoConsecutivo]
								WHERE 
									[rfcEmpresa] = @rfcEmpresa AND
									[idCliente] = @idCliente AND
									[numeroContrato] = @numeroContrato
							)
							WHERE 
								[rfcEmpresa] = @rfcEmpresa AND
								[idCliente] = @idCliente AND
								[numeroContrato] = @numeroContrato 
				--***********************************************************************************************
				--3. INSERTAMOS SOLICITUDOBJETO
				--***********************************************************************************************
				INSERT INTO [solicitud].[SolicitudObjeto](
						 [idSolicitud]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idTipoSolicitud]
						,[idObjeto]
						,[idTipoObjeto]
						,[idClase]
						,[numeroOrden]
						,[fechaAlta]
						,[idUsuario]
					) VALUES (
						@VI_IdSolicitud,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idTipoSolicitud,
						@idObjeto,
						@idTipoObjeto,
						@idClase,
						(@VC_NOSOLICITUD +'-'+ CONVERT(VARCHAR(20), @idObjeto)),
						@fecha,
						@idUsuario
					)
				--***********************************************************************************************
				--4. INSERTAMOS LA SOLICITUD EN COMPRABPRO
				--***********************************************************************************************
					INSERT INTO [compraBPRO].[solicitud](
					idSolicitud
					,idTiposolicitud
					,idClase
					,rfcEmpresa
					,idCliente
					,numeroContrato
					,idUsuarioBPRO
					,idEmpresa
					,idSucursal
					,idArea
					,idUsuario
					,activo)
					VALUES(
						@VI_IdSolicitud
						,@idTipoSolicitud
						,@idClase
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,@idUsuarioBPRO
						,@idEmpresaBPRO
						,@idSucursalBPRO
						,@idAreaBPRO
						,@idUsuario
						,1)
					
				--***********************************************************************************************
				--5. INSERTAMOS LAS PARTIDAS NUEVAS
				--***********************************************************************************************
				INSERT INTO compraBPRO.SolicitudPartida(
					idSolicitud
					,idTipoSolicitud
					,idClase
					,rfcEmpresa
					,idCliente
					,numeroContrato
					,cantidad
					,descripcion
					,idUsuario
					,activo
				)
				SELECT 
					@VI_IdSolicitud
					,@idTipoSolicitud
					,@idClase
					,@rfcEmpresa
					,@idCliente
					,@numeroContrato
					,cantidad
					,descripcion
					,@idUsuario
					,1 
				FROM @VT_PartidasNuevas
				--***********************************************************************************************
				--6. INSERTAMOS PROPIEDADES DE CLASE
				--***********************************************************************************************
				WHILE (@pCount <= @pMax)
				BEGIN
					SET @xmlPadre = (SELECT [Valor] FROM @VT_Propiedades WHERE [Index] = @pCount)
					INSERT INTO [solicitud].[SolicitudPropiedadClase] (
							[idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idPropiedadClase]
						,[valor]
						,[fechaCaducidad]
						,[idUsuario]
					) VALUES (
						@VI_IdSolicitud,
						@idTipoSolicitud,
						@idClase,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						case when 
							(
								select idTipoValor from solicitud.PropiedadClase where idPropiedadClase = 
								(
									SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount
								)
							)!='Unico' 
							THEN 
								(SELECT	I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))									
							ELSE
								(SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount)
						END,
						case when 
							(
								select idTipoValor from solicitud.PropiedadClase where idPropiedadClase = 
								(
									SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount
								)
							)!='Unico' 
							then ''
							ELSE
							(SELECT I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))
						END,
						NULL,
						@idUsuario
					)
					--EN CASO DE QUE LA PROPIEDAD SEA DE TIPO ARCHIVO, LA INSERTAMOS COMO EVIDENCIA
					IF @idTipoSolicitud='Compra'
						BEGIN
							if exists(
										select 1 from solicitud.PropiedadClase where idPropiedadClase = 
												(
													SELECT [idPropiedadClase] FROM @VT_Propiedades WHERE [Index] = @pCount
												) and idTipoDato='File'
									)
									BEGIN
										INSERT INTO documento.SolicitudObjetoEvidencia(
											idSolicitud
											,idTipoObjeto
											,idClase
											,rfcEmpresa
											,idCliente
											,numeroContrato
											,idTipoSolicitud
											,idObjeto
											,idSolicitudObjetoEvidencia
											,idFileServer							
										) VALUES(
											@VI_IdSolicitud
											,@idTipoObjeto
											,@idClase
											,@rfcEmpresa
											,@idCliente							
											,@numeroContrato
											,'Compra'
											,@idObjeto
											,1
											,(SELECT	I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))	
										)
									END
						END
					
					SET @pCount = @pCount + 1 
				END
				--***********************************************************************************************
				--7. INSERTAMOS PROPIEDADES POR TIPO DE SOLICITUD
				--***********************************************************************************************
				WHILE (@sCount <= @sMax)
				BEGIN
					SET @xmlPadre = (SELECT [Valor] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount)
					INSERT INTO [solicitud].[SolicitudPropiedadTipoSolicitud] (
						[idSolicitud]
						,[idTipoSolicitud]
						,[idClase]
						,[rfcEmpresa]
						,[idCliente]
						,[numeroContrato]
						,[idPropiedadTipoSolicitud]
						,[valor]
						,[fechaCaducidad]
						,[idUsuario]
					) VALUES (
						@VI_IdSolicitud,
						@idTipoSolicitud,
						@idClase,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						case when 
							(
								select idTipoValor from solicitud.PropiedadTipoSolicitud where idPropiedadTipoSolicitud = 
								(
									SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount
								)
							)!='Unico' 
							THEN 
								(SELECT	I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))									
							ELSE
								(SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount)
						END,
						case when 
							(
								select idTipoValor from solicitud.PropiedadTipoSolicitud where idPropiedadTipoSolicitud = 
								(
									SELECT [idPropiedadTipoSolicitud] FROM @VT_PropiedadesSolicitud WHERE [Index] = @sCount
								)
							)!='Unico' 
							then ''
							ELSE
							(SELECT I.N.value('(valor)[1]',	'nvarchar(500)') FROM  @xmlPadre.nodes('/valores') I(N))
						END,
						NULL,
						@idUsuario
					)
					SET @sCount = @sCount + 1 
				END
				--***********************************************************************************************
				--8. INSERTAMOS HISTORICO DE LA SOLICITUD
				--***********************************************************************************************
				INSERT INTO [fase].[SolicitudEstatusPaso] (
						  [idSolicitud]
						 ,[rfcEmpresa]
						 ,[idCliente]
						 ,[numeroContrato]
						 ,[idPaso]
						 ,[idFase]
						 ,[idClase]
						 ,[idTipoSolicitud]
						 ,[fechaIngreso]
						 ,[idEstatus]
						 ,[idUsuarioIngreso]
					) VALUES (
						@VI_IdSolicitud
						,@rfcEmpresa
						,@idCliente
						,@numeroContrato
						,(SELECT 
						top 1	[idPaso] 
						from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
						,(SELECT 
						top 1	idFase 
						from [solicitud].[SEL_PASO_PORTIPOSOLICITUD_FN] (@idTipoSolicitud,@idClase, @rfcEmpresa, @idCliente, @numeroCOntrato) ) 
						,@idClase
						,@idTipoSolicitud
						,GETDATE()
						,1
						,@idUsuario
					)
				--***********************************************************************************************
				--9. INSERTAMOS A LA TABLA DE SALIDA LA SOLICITUD GENERADA
				--***********************************************************************************************
				INSERT INTO @VT_SOLICITUDES VALUES(@VI_IdSolicitud,'EM')
				--***********************************************************************************************
				--FIN
				--***********************************************************************************************
			END
			
			COMMIT TRANSACTION INS
			SELECT 
				SO.idSolicitud				idSolicitud
				,SS.numero					numeroSolicitud
				,S.tipoSolciitudBPRO		tipoSolicitudBPRO
				,CON.idFileAvatar			idLogoContrato
				,''							error
				,SO.numeroOrden				numeroOrden
			FROM @VT_SOLICITUDES S
			INNER JOIN Solicitud.Solicitud SS ON SS.idSolicitud = S.idSolicitud
			INNER JOIN Solicitud.SolicitudObjeto SO ON S.idSolicitud = SO.idSolicitud
			INNER JOIN Cliente.cliente.Contrato CON ON 
				CON.rfcEmpresa = SO.rfcEmpresa
				AND CON.idCliente = SO.idCliente
				AND CON.numeroContrato = SO.numeroContrato

		END
		ELSE
		BEGIN
			SET @ERR_MENSAJE = 'El contrato ha expirado.'
			COMMIT TRANSACTION INS
		END		
	END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION INS
				SET @VC_ErrorMessage = { 
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage
					) 
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
				SET @err = @VC_ErrorMessage;
			END
		END CATCH
END
go

