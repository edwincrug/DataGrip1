-- =============================================
-- Author: Adolfo Martinez
-- Create date: 14/04/2020
-- Description: Obtener el id de la compra procesada
-- [cxc].[SEL_ID_COMPRA_PROCESADA_SP] 97, 'Imagen', 'Automovil','ASE0508051B6',185,'43', 2927
-- [cxc].[SEL_ID_COMPRA_PROCESADA_SP] 180, 'Imagen', 'Automovil','ASE0508051B6',185,'43', 6119
-- =============================================
CREATE  PROCEDURE [cxc].[SEL_ID_COMPRA_PROCESADA_SP]
@idSolicitud INT,
@idTipoSolicitud VARCHAR(10),
@idClase VARCHAR(10),
@rfcEmpresa	VARCHAR(13),
@idCliente INT,
@numeroContrato	VARCHAR(50),
@idUsuario INT,
@err VARCHAR(8000) = '' OUTPUT	
AS

BEGIN
	IF @idClase='Compra'
		BEGIN
			SELECT TOP 1
					s.ppg_ordenCompra as OTE_IDENT,sc.idCotizacion,sc.idSolicitud, sc.idTipoSolicitud, sc.idClase, sc.rfcEmpresa, sc.idCliente, sc.numeroContrato 
			FROM	compraBPRO.Solicitud s INNER JOIN solicitud.SolicitudCotizacion sc 
			ON sc.idSolicitud=s.idSolicitud 
			AND		sc.idTipoSolicitud=s.idTipoSolicitud AND sc.idClase=s.idClase AND sc.rfcEmpresa=s.rfcEmpresa
			AND		sc.idCliente=s.idCliente AND sc.numeroContrato=s.numeroContrato
			WHERE	s.idSolicitud=@idSolicitud
			AND		s.idTipoSolicitud=@idTipoSolicitud
			AND		s.idClase=@idClase
			AND		s.rfcEmpresa=@rfcEmpresa
			AND		s.idCliente=@idCliente
			AND		s.numeroContrato=@numeroContrato 
		END
	ELSE
		BEGIN
			SELECT OTE_IDENT, idCotizacion, idSolicitud, idTipoSolicitud, idClase, rfcEmpresa, idCliente, numeroContrato FROM [cxc].[FacturaBPRO] 
			WHERE idSolicitud=@idSolicitud
					AND idTipoSolicitud=@idTipoSolicitud
					AND idClase=@idClase
					AND rfcEmpresa=@rfcEmpresa
					AND idCliente=@idCliente
					AND numeroContrato=@numeroContrato 
			ORDER BY OTE_IDENT
		END

	--SELECT [solicitud].[SEL_OBTENERIDSCOMPRA_FN](@idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato) AS OTE_IDENT

END


go

