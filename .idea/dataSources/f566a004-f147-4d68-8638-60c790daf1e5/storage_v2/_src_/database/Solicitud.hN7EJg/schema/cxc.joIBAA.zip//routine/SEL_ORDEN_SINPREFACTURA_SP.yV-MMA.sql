

-- =============================================
-- Author: Andres Farias
-- Create date: 23-07-2019
-- Description: Obtener las facturas de una solicitud
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	13/08/2019	José Etmanuel	Agregando clase a la función Objeto.objeto.getPropiedadObjeto
	09/04/2020	JLLOZADA		Se cambio el estatus de las facturas a Provisionada y se agregaron algunos campos

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [cxc].[SEL_ORDEN_SINPREFACTURA_SP] '129', 220, 'ASE0508051B6', 'Automovil', 6282, null
	SELECT @salida AS salida;

*/
-- =============================================
CREATE  PROCEDURE [cxc].[SEL_ORDEN_SINPREFACTURA_SP]
	@numeroContrato			nvarchar(50),
	@idCliente				int,
	@rfcEmpresa				varchar(13),
	@idClase				varchar(10),
	@idUsuario				int,
	@err					varchar(500)OUTPUT
AS

BEGIN
	select	so.numeroOrden,
			fac.numeroCotizacion,
			s.numeroContrato,			
			ISNULL((SELECT nombre FROM cliente.cliente.contrato WHERE rfcEmpresa=s.rfcEmpresa AND idCliente=s.idCliente AND numeroContrato=s.numeroContrato ),'') 'nombreContrato',
			CONVERT(VARCHAR(10),s.fechaCreacion,103) + ' '+CONVERT(VARCHAR(10),s.fechaCreacion,108) 'fechaCreacion',
			--s.fechaCreacion,
			ccc.nombre 'nombreCliente',
			so.idTipoObjeto,
			so.idObjeto,
			Objeto.objeto.getPropiedadObjeto(so.idObjeto,'Número económico','Clase',@idClase)	numeroEconomico,
			fac.idCotizacion,
			fac.idFactura,
			fac.idSolicitud,
			fac.idTipoSolicitud,
			CONVERT(DECIMAL (18,2), sum(facd.subtotalVenta)) subtotal
	from	cxc.Factura fac
	INNER	JOIN cxc.FacturaDetalle facd		on facd.idFactura	= fac.idFactura
	INNER	JOIN solicitud.Solicitud s			on s.idSolicitud = fac.idsolicitud and fac.idTipoSolicitud=s.idTipoSolicitud and s.idClase = fac.idClase and fac.rfcEmpresa=s.rfcEmpresa and s.idCliente = fac.idCliente and s.numeroContrato = fac.numeroContrato
	INNER	JOIN solicitud.SolicitudObjeto so	on so.idSolicitud= s.idSolicitud and so.idTipoSolicitud=s.idTipoSolicitud and so.idClase = s.idClase and so.rfcEmpresa=s.rfcEmpresa and so.idCliente = s.idCliente and so.numeroContrato = s.numeroContrato
	INNER   JOIN solicitud.fase.SolicitudEstatusPaso sep on sep.idSolicitud= s.idSolicitud and sep.idTipoSolicitud=s.idTipoSolicitud and sep.idClase = s.idClase and sep.rfcEmpresa=s.rfcEmpresa and sep.idCliente = s.idCliente and sep.numeroContrato = s.numeroContrato and fechaSalida is null
	LEFT	JOIN [cliente].[cliente].[Cliente] CCC ON CCC.idCliente = S.idCliente
	WHERE	sep.idFase='Cobranza' AND sep.idPaso='Cobranza'
	AND     fac.numeroContrato	= @numeroContrato 
	and		fac.rfcEmpresa		= @rfcEmpresa 
	and		fac.idCliente		= @idCliente 
	and		fac.idClase			= @idClase 
	and		fac.idEstatus		= 'Provisionada'
	group by so.numeroOrden,so.idTipoObjeto,so.idObjeto,fac.idCotizacion,fac.idFactura,fac.idSolicitud,fac.idTipoSolicitud,s.numeroContrato,ccc.nombre,s.rfcEmpresa,s.idCliente,fac.numeroCotizacion,s.fechaCreacion
END

/*


*/


go

