-- =============================================
-- Author:		Edgar Mendoza
-- Create date: 24/08/2020
-- Description:	Función para traerr los días de una solicitud

-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	29/09/2020	Jluis Lozada	se agrego la parte del descuento

	--Test
	[solicitud].[SEL_DIASSOL_FN]
*/

CREATE FUNCTION [solicitud].[SEL_TRASLADO_FN]
(
	@UUID	VARCHAR(100),
	@idSolicitud	INT,
	@idCotizacion	INT,
	@idPartida		INT
)
RETURNS FLOAT
AS
BEGIN
	DECLARE @traslado FLOAT = 0;
	DECLARE @trasladoPartida FLOAT;
	DECLARE @impuestos INT = 1
	DECLARE @tasa FLOAT

	DECLARE @tablaImpuestos TABLE (Fila_ INT IDENTITY(1,1), tasa FLOAT)

	IF NOT EXISTS(SELECT 1 FROM solicitud.cxp.FacturaImpuesto WHERE uuidFactura = @UUID)
		BEGIN
			INSERT INTO @tablaImpuestos
			select tasa from solicitud.cxp.TipoFacturaImpuesto where idTipoFacturaImpuesto = 2
		END

	ELSE
		BEGIN

			INSERT INTO @tablaImpuestos
			SELECT FI.TASA FROM solicitud.cxp.FacturaImpuesto FI
			INNER JOIN solicitud.cxp.TipoFacturaImpuesto TFI ON TFI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto
			INNER JOIN [cxp].[Tipo] T ON T.idTipo = TFI.idTipo
			where uuidFactura = @UUID AND tfi.idTipo = 1

		END

	WHILE ((SELECT COUNT(*) from @tablaImpuestos) >= @impuestos)

	BEGIN

		SET @tasa = (SELECT tasa FROM  @tablaImpuestos WHERE Fila_ = @impuestos)
		
		SET @trasladoPartida = ( SELECT (costo-ISNULL(de.descuentoCosto,0)) * cantidad * @tasa 
								 FROM solicitud.solicitud.SolicitudCotizacionPartida pa 
								 LEFT JOIN solicitud.solicitud.SolicitudCotizacionPartidaDescuento de ON pa.idSolicitud=de.idSolicitud AND pa.idCotizacion=de.idCotizacion
								 AND pa.idPartida=de.idPartida
								 WHERE pa.idSolicitud = @idSolicitud 
								 AND pa.idCotizacion = @idCotizacion 
								 AND pa.idPartida = @idPartida)

		SET @traslado = @traslado + @trasladoPartida

		SET @impuestos = @impuestos + 1
	END
	
	
	RETURN @traslado;
END



go

