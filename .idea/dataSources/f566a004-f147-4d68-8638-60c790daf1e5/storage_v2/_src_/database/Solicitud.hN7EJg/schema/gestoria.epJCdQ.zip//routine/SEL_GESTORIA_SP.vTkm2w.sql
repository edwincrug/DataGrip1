
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 02-07-2019
-- Description: Consulta trae gestorias
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[SEL_GESTORIA_SP] 'Automovil',6036, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[SEL_GESTORIA_SP] 

	@idClase				VARCHAR(10),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	SELECT 
	E.nombre as estado,
	EG.nombre as estatus,
	(SELECT COUNT(*) FROM gestoria.GestoriaSolicitud WHERE idGestoria = G.idGestoria ) noSolicitudes,
	G.* 
	FROM gestoria.Gestoria G
	INNER JOIN [common].[direccion].[Estado] E ON E.idEstado = G.idEstado
	INNER JOIN gestoria.EstatusGestoria EG ON EG.idEstatusGestoria = G.idEstatusGestoria
	WHERE idClase = @idClase
	AND activo = 1

	SELECT
	GS.idClase,
	GS.idGestoria,
	GS.idSolicitud,
	GS.idTipoSolicitud,
	GS.rfcEmpresa,
	GS.idCliente,
	GS.numeroContrato,
	S.idEstatusSolicitud
	FROM
	gestoria.GestoriaSolicitud GS
	INNER JOIN [solicitud].[solicitud] S ON S.idSolicitud = GS.idSolicitud
	WHERE GS.idClase = @idClase


END
go

