-- =============================================  
-- Author:   <Miguel Angel Reyes Xinaxtle>  
-- Create date:  <04/07/2019>  
-- Description:     <Obtiene el estatus real de la solicitud(Orden), fue creado por un dios>  
-- =============================================  
-- SELECT   
--     [idSolicitud]  
--     ,[idTipoSolicitud]  
--     ,[idClase]  
--     ,[rfcEmpresa]  
--     ,[idCliente]  
--     ,[numeroContrato]  
--     ,[idPaso]  
--     ,[idFase]  
--     ,[fechaIngreso]  
--     ,[fechaSalida]  
--     ,[idEstatus]  
--     ,[tipoPaso]  
-- FROM [solicitud].[SEL_PASO_SOLICITUD_FN](3354)  
-- =============================================  
CREATE FUNCTION [solicitud].[SEL_PASO_SOLICITUD_FN](@idSolicitud int)  
RETURNS @SolicitudEstatusPaso   
TABLE (  
 [idSolicitud] [int] NOT NULL,  
 [idTipoSolicitud] [varchar](10) NOT NULL,  
 [descripcion] [varchar](80) NOT NULL, 
 [idClase] [varchar](10) NOT NULL,  
 [rfcEmpresa] [varchar](13) NOT NULL,  
 [idCliente] [int] NOT NULL,  
 [numeroContrato] [varchar](50) NOT NULL,  
 [idPaso] [varchar](50) NOT NULL,  
 [idFase] [varchar](20) NOT NULL,  
 [fechaIngreso] [datetime] NOT NULL,  
 [fechaSalida] [datetime] NULL,  
 [idEstatus] [int] NOT NULL,  
 [tipoPaso] [varchar](8) NOT NULL  
)  
  
AS  
  
BEGIN  
    DECLARE  
    @idSolicitudExistente               int=0  
    ,@idSolicitudEstatusPasoExistente   int=0  
    ,@idFaseUltimo                      varchar(20)=NULL  
    ,@idPasoUltimo                      varchar(50)=NULL  
  
    SELECT    
        @idSolicitudExistente = SS.[idSolicitud]   
    FROM [Solicitud].[solicitud].[Solicitud] SS   
    WHERE idEstatusSolicitud <> 'FINALIZADA'  
        AND idSolicitud = @idSolicitud  
  
 IF(SELECT idEstatusSolicitud FROM solicitud.solicitud.Solicitud WHERE idSolicitud = @idSolicitud) NOT IN ('CANCELADA','RECHAZADA')
	
 
  BEGIN  
  
   IF(@idSolicitudExistente > 0)  
   BEGIN  
    --Existe la solicitud.  
    SELECT  
     @idSolicitudEstatusPasoExistente = SSE.[idSolicitud]  
    FROM [Solicitud].[fase].[SolicitudEstatusPaso] SSE  
    WHERE idSolicitud = @idSolicitud  
     AND fechaSalida IS NULL  
    IF(@idSolicitudEstatusPasoExistente > 0)  
    BEGIN  
     --Tenemos la solicitud en estatus basicos.  
     INSERT INTO @SolicitudEstatusPaso  
     SELECT   
      FSEP.[idSolicitud]  
      ,FSEP.[idTipoSolicitud]  
	  ,TS.[descripcion]
      ,FSEP.[idClase]  
      ,FSEP.[rfcEmpresa]  
      ,FSEP.[idCliente]  
      ,FSEP.[numeroContrato]  
      ,FSEP.[idPaso]  
      ,FSEP.[idFase]  
      ,FSEP.[fechaIngreso]  
      ,FSEP.[fechaSalida]  
      ,FSEP.[idEstatus]  
      ,'paso'  
     FROM [Solicitud].[fase].[Paso] FP  
     INNER JOIN [Solicitud].[fase].[SolicitudEstatusPaso] FSEP  
      ON FP.idTipoSolicitud = FSEP.idTipoSolicitud  
      AND FP.[idClase] = FSEP.[idClase]  
      AND FP.[idPaso] = FSEP.[idPaso]  
      AND FP.[idFase] = FSEP.[idFase]  
	 INNER JOIN [solicitud].[TipoSolicitud] TS 
	 ON TS.idTipoSolicitud = FP.idTipoSolicitud
     WHERE FSEP.[idSolicitud] = @idSolicitud  
      AND FSEP.[fechaSalida] IS NULL  
    END  
    ELSE  
    BEGIN  
     --No hay solicitudes con estatus basicos, MODELO DE MIERDA.  
     --Ultimo fase y paso de la solicitud en los estatus basicos  
     SELECT   
      TOP(1)   
      @idFaseUltimo = FSEP.[idFase]  
      ,@idPasoUltimo = fsep.[idPaso]   
     FROM [Solicitud].[fase].[SolicitudEstatusPaso] FSEP  
     INNER JOIN [Solicitud].[fase].[Fase] FF  
      ON FSEP.[idFase] = FF.[idFase]   
     INNER JOIN [Solicitud].[fase].[Paso] FP  
      ON FF.[idFase] = FP.[idFase]  
      AND FSEP.[idPaso] = FP.[idPaso]  
      AND FSEP.[idFase] = FP.[idFase]  
      AND FSEP.[idClase] = FP.[idClase]  
      AND FSEP.[idTipoSolicitud] = FP.[idTipoSolicitud]  
     WHERE FSEP.[idSolicitud] = @idSolicitud  
     ORDER BY   
      FF.[orden] DESC  
      ,FP.[orden] DESC  
              
     --Paso del contrato  
     INSERT INTO @SolicitudEstatusPaso  
     SELECT   
      FCSEP.[idSolicitud]  
      ,FCSEP.[idTipoSolicitud] 
	  ,TS.[descripcion]
      ,FCSEP.[idClase]  
      ,FCSEP.[rfcEmpresa]  
      ,FCSEP.[idCliente]  
      ,FCSEP.[numeroContrato]  
      ,FCSEP.[idPaso]  
      ,FCSEP.[idFase]  
      ,FCSEP.[fechaIngreso]  
      ,FCSEP.[fechaSalida]  
      ,FCSEP.[idEstatus]  
      ,'contrato'  
     FROM [Solicitud].[faseContrato].[Paso] FCP  
     INNER JOIN [Solicitud].[faseContrato].[SolicitudEstatusPaso] FCSEP  
      ON FCP.idTipoSolicitud = FCSEP.idTipoSolicitud  
      AND FCP.[idClase] = FCSEP.[idClase]  
      AND FCP.[rfcEmpresa] = FCSEP.[rfcEmpresa]  
      AND FCP.[idCliente] = FCSEP.[idCliente]  
      AND FCP.[numeroContrato] = FCSEP.[numeroContrato]  
      AND FCP.[idPaso] = FCSEP.[idPaso]  
      AND FCP.[idFase] = FCSEP.[idFase]  
	 INNER JOIN [solicitud].[TipoSolicitud] TS 
	 ON TS.idTipoSolicitud = FCP.idTipoSolicitud
     WHERE FCSEP.[idSolicitud] = @idSolicitud  
      AND FCSEP.[fechaSalida] IS NULL  
      AND FCP.[idPasoAnterior] = @idPasoUltimo  
      AND FCP.[idFase] = @idFaseUltimo  
    END  
   END  
  END  
 ELSE  
  BEGIN  
  
   INSERT INTO @SolicitudEstatusPaso  
   SELECT TOP 1  
    SEP.[idSolicitud]
    ,SEP.[idTipoSolicitud]
	,TS.[descripcion]
    ,SEP.[idClase]
    ,SEP.[rfcEmpresa]  
    ,SEP.[idCliente]  
    ,SEP.[numeroContrato]  
    ,SEP.[idPaso]  
    ,SEP.[idFase]  
    ,SEP.[fechaIngreso]  
    ,SEP.[fechaSalida]  
    ,SEP.[idEstatus]  
    ,'paso'  
   FROM Solicitud.fase.SolicitudEstatusPaso SEP
   	INNER JOIN [solicitud].[TipoSolicitud] TS 
	ON TS.idTipoSolicitud = SEP.idTipoSolicitud
   WHERE idSolicitud = @idSolicitud  
   ORDER BY SEP.fechaSalida DESC  
  
  END  
    -- ELSE  
    -- BEGIN  
    --     No existe la solicitud o esta finalizada.  
    -- END  
  
    RETURN  
END
go

