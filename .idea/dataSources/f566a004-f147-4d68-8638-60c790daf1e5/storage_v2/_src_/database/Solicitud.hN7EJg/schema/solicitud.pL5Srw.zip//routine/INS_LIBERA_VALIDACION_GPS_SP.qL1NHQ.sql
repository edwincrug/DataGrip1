-- =============================================
-- Author:		<DVR>
-- Create date: <24/08/2020>
-- Description:	<Libera el Gps al vehiculo>
/* Test: 
	exec [solicitud].[INS_LIBERA_VALIDACION_GPS_SP] 
	@idSolicitud = 12966,
	@idTipoObjeto = 627,
	@idClase = 'Automovil',
	@rfcEmpresa = 'TPC1208066U6',
	@idCliente = 105,
	@numeroContrato = '0001',
	@idTipoSolicitud = 'Revision',
	@idObjeto = 13531,
	@idInventarioGPS = 45151,
	@gps = '213GDP2018008063',
	@fechaInstalacion = '2020-12-04T06:00:00.000Z',
	@comentario = '4260 km',
	@desinstalar = 0,
	@idUsuario = 1882,
	@err = null
*/

-- =============================================
CREATE PROCEDURE [solicitud].[INS_LIBERA_VALIDACION_GPS_SP] 
	@idSolicitud		int,
	@idTipoObjeto		int,
	@idClase			varchar(10),
	@rfcEmpresa         varchar(15),
	@idCliente			int,
	@numeroContrato		varchar(50),
	@idTipoSolicitud	varchar(50),	
	@idObjeto			int,
	@idInventarioGPS	int,
	@gps				varchar(10),
	@fechaInstalacion   datetime,
	@comentario			varchar(500) = null,
	@desinstalar		int,
	@idUsuario			int,  
	@err				varchar(500)OUTPUT 
AS
BEGIN
	BEGIN TRY

	DECLARE @idPropiedadClase int = 0,@idGPSSIM_catalogo int = 0,@idGPSSIM_valor int = 0,@fechaInstalacion_valor datetime

	SELECT @idGPSSIM_catalogo = idGPSSIM 
	FROM Inventario.inventario.GPSSIM 
	WHERE idInventarioGPS = @idInventarioGPS
		
	DELETE FROM [Solicitud].[solicitud].[SolicitudObjetoGPSSIM] 
	WHERE idObjeto = @idObjeto AND idSolicitud = @idSolicitud

		INSERT INTO  [Solicitud].[solicitud].[SolicitudObjetoGPSSIM]  
		VALUES
		(
		  @idSolicitud,
		  @idTipoObjeto,
		  @idClase,
		  @rfcEmpresa,
		  @idCliente,
		  @numeroContrato,
		  @idTipoSolicitud,
		  @idObjeto,
		  @idGPSSIM_catalogo,
		  @fechaInstalacion,
		  @idUsuario,
		  @comentario,
		  @desinstalar
		)
	
	SELECT 1 AS exito
		
	END TRY
	BEGIN CATCH
				SELECT
				0 as exito,
				ERROR_NUMBER() AS ErrorNumber,
				ERROR_STATE() AS ErrorState,
				ERROR_SEVERITY() AS ErrorSeverity,
				ERROR_PROCEDURE() AS ErrorProcedure,
				ERROR_LINE() AS ErrorLine,
				ERROR_MESSAGE() AS ErrorMessage;
	END CATCH;
END
--USE [Solicitud]
go

