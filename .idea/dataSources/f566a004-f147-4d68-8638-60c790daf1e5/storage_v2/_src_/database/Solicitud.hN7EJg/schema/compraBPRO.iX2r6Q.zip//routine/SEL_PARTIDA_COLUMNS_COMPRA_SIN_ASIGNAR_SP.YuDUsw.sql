-- =============================================
-- Author: Edgar Mendoza	
-- Create date: 03-04-2019
-- Description: Devuelve los tipo de dato de cada columna
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [compraBPRO].[SEL_PARTIDA_COLUMNS_COMPRA_SIN_ASIGNAR_SP] '',0,0, 'Compra',@salida OUTPUT;
	SELECT @salida AS salida;
*/

-- =============================================
CREATE  PROCEDURE [compraBPRO].[SEL_PARTIDA_COLUMNS_COMPRA_SIN_ASIGNAR_SP] 
	@numeroContrato		VARCHAR(50),
	@idCliente			INT,
	@idUsuario			INT,
	@idClase			VARCHAR(10),
	@err nvarchar(500) OUTPUT
AS
BEGIN
--creamos tabla temporal para insertar las propiedades del tipo objeto dependiendo del tipo de valor
create table #partidas(
	idPartida					int,
	agrupador			varchar(500),
	valor				varchar(250),
	orden				int,
	posicion			int,
	ordenFinal			INT
)

/**********************************************************************************************************************
******************************************************CATALOGOS Y AGRUPADORES******************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with catalogos as(
	select	
		par.idPartida					idPartida,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		/*
		CASE 
		WHEN prg.agrupador = 'Descripción' THEN 2
		ELSE 0 end ordenFinal
		*/ 
		0 ordenFinal
	from 
	partida.partida.Partida par
	inner join partida.partida.PartidaPropiedadGeneral tpg on par.idPartida = tpg.idPartida
	inner join partida.partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1
	inner join integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	where 
		prg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		--and par.idTipoObjeto = @idTipoObjeto
		AND par.idClase = @idClase
		and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idPartida					idPartida,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from partida.partida.PropiedadGeneral prg 
	inner join integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	inner join catalogos cat on cat.idPadre = prg.idPropiedadGeneral
	and prg.activo = 1
	)
	insert into #partidas
	select 
		cat.idPartida,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

--PROPIEDADES DE CLASE
;with catalogos as(
	select
		par.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from 
	partida.partida.Partida par
	inner join partida.partida.PartidaPropiedadClase tpc on par.idPartida = tpc.idPartida
	inner join partida.partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.activo = 1 and prc.idClase= @idClase
	where 
		prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		--and par.idTipoObjeto = @idTipoObjeto
		AND par.idClase = @idClase
		and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.partida.PropiedadClase prc 
	inner join catalogos cat on cat.idPadre = prc.idPropiedadClase 
	WHERE prc.activo = 1
	)
	insert into #partidas
	select 
		cat.idPartida,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null


--PROPIEDADES DE CONTRATO
;with catalogos as(
	select
		par.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		2								ordenFinal
	from 
	partida.partida.Partida par
	inner join partida.partida.PartidaPropiedadContrato tpc on par.idPartida = tpc.idPartida
	inner join partida.partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato and prc.activo = 1 and prc.numeroContrato = @numeroContrato and prc.idCliente = @idCLiente
	where 
		prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		--and par.idTipoObjeto = @idTipoObjeto
		AND par.idClase = @idClase
		and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		2								ordenFinal
	from partida.partida.PropiedadContrato prc 
	inner join catalogos cat on cat.idPadre = prc.idPropiedadContrato 
	WHERE prc.activo = 1
	and prc.numeroContrato = @numeroContrato
	and prc.idCliente = @idCLiente
	)
	insert into #partidas
	select 
		cat.idPartida,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null



/**********************************************************************************************************************
*********************************************************TAGS**********************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with tags as(
	select	
		par.idPartida					idPartida,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prg.idTipoDato AS VARCHAR(250)),'')			valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		/*
		CASE 
		WHEN prg.agrupador = 'Descripción' THEN 2
		ELSE 0 end ordenFinal
		*/
		0 ordenFinal
	from 
	partida.partida.Partida par
	inner join partida.partida.PartidaPropiedadGeneral tpg on par.idPartida = tpg.idPartida
	inner join partida.partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1 
	where prg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	--and par.idTipoObjeto = @idTipoObjeto
	AND par.idClase = @idClase
	and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idPartida					idPartida,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prg.idTipoDato AS VARCHAR(250)),'')			valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		/*
		CASE 
		WHEN prg.agrupador = 'Descripción' THEN 2
		ELSE 0 end ordenFinal
		*/
		0 ordenFinal
	from partida.partida.PropiedadGeneral prg 
	inner join tags tag on tag.idPadre = prg.idPropiedadGeneral
	WHERE prg.activo = 1
	)
	insert into #partidas
	select distinct 
		idPartida,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags. idPartida and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

--PROPIEDADES CLASE
;with tags as(
	select	
		par.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.partida.Partida par
	inner join partida.partida.PartidaPropiedadClase tpc on par.idPartida = tpc.idPartida
	inner join partida.partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.activo = 1 and prc.idClase= @idClase
	where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	--and par.idTipoObjeto = @idTipoObjeto
	AND par.idClase = @idClase
	and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.partida.PropiedadClase prc 
	inner join tags tag on tag.idPadre = prc.idPropiedadClase
	and prc.activo = 1
	)
	insert into #partidas
	select distinct 
		idPartida,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags.idPartida and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags


--PROPIEDADES CONTRATO
;with tags as(
	select	
		par.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		2								ordenFinal
	from partida.partida.Partida par
	inner join partida.partida.PartidaPropiedadContrato tpc on par.idPartida = tpc.idPartida
	inner join partida.partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato and prc.activo = 1 and prc.numeroContrato = @numeroContrato and prc.idCliente = @idCLiente
	where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	--and par.idTipoObjeto = @idTipoObjeto
	and prc.numeroContrato = @numeroContrato
	and prc.idCliente = @idCLiente
	AND par.idClase = @idClase
	and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		2								ordenFinal
	from partida.partida.PropiedadContrato prc 
	inner join tags tag on tag.idPadre = prc.idPropiedadContrato
	and prc.activo = 1
	and prc.numeroContrato = @numeroContrato
	and prc.idCliente = @idCLiente
	)
	insert into #partidas
	select distinct 
		idPartida,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags.idPartida and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags


/**********************************************************************************************************************
***************************************************VALORES FIJOS*******************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
INSERT INTO #partidas
select 
	par.idPartida			idPartida,
	prg.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	isnull(CAST(prg.idTipoDato AS VARCHAR(250)),'')			valor,
	prg.orden						orden,
	prg.posicion					posicion,
	/*CASE 
		WHEN prg.agrupador = 'Descripción' THEN 2
		ELSE 0 end ordenFinal
		*/
	0 ordenFinal
from partida.partida.Partida par
inner join partida.partida.PartidaPropiedadGeneral tpg on tpg.idPartida = par.idPartida
inner join partida.partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1
where
	prg.idTipoValor = 'Unico'
	--and par.idTipoObjeto = @idTipoObjeto
	AND par.idClase = @idClase
	and par.activo = 1

--PROPIEDADES DE CLASE
INSERT INTO #partidas
select 
	par.idPartida			idPartida,
	prc.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
	prc.orden						orden,
	prc.posicion					posicion,
	1								ordenFinal
from partida.partida.Partida par
inner join partida.partida.PartidaPropiedadClase tpc on tpc.idPartida = par.idPartida
inner join partida.partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.activo = 1 and prc.idClase= @idClase
where
	prc.idTipoValor = 'Unico'
	--and par.idTipoObjeto = @idTipoObjeto
	AND par.idClase = @idClase
	and par.activo = 1


--PROPIEDADES DE CONTRATO
INSERT INTO #partidas
select 
	par.idPartida			idPartida,
	prc.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	isnull(CAST(prc.idTipoDato AS VARCHAR(250)),'')			valor,
	prc.orden						orden,
	prc.posicion					posicion,
	2								ordenFinal
from partida.partida.Partida par
inner join partida.partida.PartidaPropiedadContrato tpc on tpc.idPartida = par.idPartida
inner join partida.partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato and prc.activo = 1 and prc.numeroContrato = @numeroContrato and prc.idCliente = @idCLiente
where
	prc.idTipoValor = 'Unico'
	--and par.idTipoObjeto = @idTipoObjeto
	and prc.numeroContrato = @numeroContrato
	and prc.idCliente = @idCLiente
	AND par.idClase = @idClase
	and par.activo = 1


/**********************************************************************************************************************
******************************************************PIVOTE***********************************************************
**********************************************************************************************************************/
declare 
	@columnsName varchar(max) = ''

create table #propiedadesOrdenas
	(
		agrupador			varchar(500),
		ordenFinal			int,
		posicion			int,
		orden				int
	)

insert into #propiedadesOrdenas
select distinct 
	pr.agrupador,
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)
from #partidas pr group by pr.agrupador order by 
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)




SET @columnsName = ISNULL(STUFF((SELECT ',' + QUOTENAME(prg.agrupador) 
						FROM #propiedadesOrdenas prg 
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,''),'sinCoinicidencia')


print @columnsName
declare @query varchar(max)
set @query = '
	select
		*
		,''String'' AS idTipoSolicitud
		,''String'' as ''estatus partida''
	from
	(select idPartida, agrupador, valor from #partidas) t
	pivot
	(	
		max(valor)
		for agrupador in (' + @columnsName + ')
	) AS resultado'

execute (@query)
drop table #partidas
drop table #propiedadesOrdenas
end

go

