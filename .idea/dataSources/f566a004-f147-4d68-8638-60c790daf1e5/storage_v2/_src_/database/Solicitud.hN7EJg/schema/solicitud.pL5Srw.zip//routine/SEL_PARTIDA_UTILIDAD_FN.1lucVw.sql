-- =============================================
-- Author:		<aDOLFO mARTINEZ>
-- Create date: <12/06/2020>
-- Description:	<Obtiene la utilidad de cada una de las partidas>
-- =============================================
/*
	SELECT [solicitud].[SEL_PARTIDA_UTILIDAD_FN](9351,10906,777663)
	select * from solicitud.solicitud.solicitudcotizacionpartida where idsolicitud = 9351
	select * from solicitud.solicitud.solicitudobjeto where numeroorden = '153-1045-13367'
*/

CREATE FUNCTION [solicitud].[SEL_PARTIDA_UTILIDAD_FN]
(
	@idSolicitud	INT,
	@idCotizacion	INT,
	@idPartida		INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @utilidad VARCHAR(MAX)=''

	IF NOT EXISTS(SELECT 1 FROM [solicitud].[SolicitudCotizacionPartida] SCP 
		JOIN [cliente].[contrato].[ProveedorUtilidad] PU ON PU.rfcEmpresa = SCP.rfcEmpresa AND PU.idCliente = SCP.idCliente AND PU.numeroContrato = SCP.numeroContrato AND PU.rfcProveedor = SCP.rfcProveedor AND PU.idProveedorEntidad = SCP.idProveedorEntidad
	WHERE SCP.idPartida = @idPartida AND SCP.idCotizacion = @idCotizacion AND SCP.idSolicitud = @idSolicitud)
		BEGIN
			IF EXISTS(SELECT 1 FROM [Solicitud].[token].[Token] TT
					INNER JOIN [Solicitud].[token].[TokenSolicitud] TTS ON TT.idToken = TTS.idToken AND TT.idUsuarioUsa IS NOT NULL
				WHERE TTS.idSolicitud = @idSolicitud
				AND TT.idTipoToken = 3)
				BEGIN
					SET @utilidad=1
				END
			ELSE
				BEGIN
					SET @utilidad=(SELECT
						(CASE WHEN C.manejoDeUtilidad = 1 THEN 
							CASE WHEN 
								CASE WHEN SUM(SCP.subTotalVentaSinDescuento) = 0 THEN 0 ELSE CAST( ((SUM(SCP.subTotalVenta) - SUM(SCP.subTotalCosto)) / SUM(SCP.subTotalVentaSinDescuento)) * 100 AS DECIMAL(18,2)) END <  C.porcentajeUtilidad THEN
									0 ELSE 1 END
						ELSE 1 END)		
					FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP
						JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = SCP.rfcEmpresa AND C.numeroContrato = SCP.numeroContrato AND C.idCliente = SCP.idCliente AND C.idClase = SCP.idClase 
					WHERE SCP.idSolicitud = @idSolicitud 
					and idEstatusCotizacionPartida = 'APROBADA'
					AND idEstatusCotizacion = 'APROBADA'
					GROUP BY C.manejoDeUtilidad, C.porcentajeUtilidad) 
				END
		END
	ELSE
		BEGIN
			SET @utilidad=1
		END

	RETURN ISNULL(@utilidad,-1)

END

go

