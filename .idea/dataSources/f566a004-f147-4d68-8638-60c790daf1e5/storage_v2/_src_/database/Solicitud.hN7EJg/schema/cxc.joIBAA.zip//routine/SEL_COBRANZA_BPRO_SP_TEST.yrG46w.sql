
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

/*
	EXEC cxc.SEL_COBRANZA_BPRO_SP_TEST 288,'Servicio','Automovil','ASE0508051B6',92,'0001','COP_IDDOCTO','FAC0001'
	EXEC cxc.SEL_COBRANZA_BPRO_SP_TEST 288,'Servicio','Automovil','ASE0508051B6',92,'0001','COP_CARGO','10000'




*/
-- =============================================
CREATE PROCEDURE [cxc].[SEL_COBRANZA_BPRO_SP_TEST] 
@idSolicitud			INT, 
@idTipoSolicitud		VARCHAR(10),
@idClase				VARCHAR(10),
@rfcEmpresa				VARCHAR(13),
@idCliente				INT, 
@numeroContrato			VARCHAR(50),
@campoBPROActualizar	VARCHAR(20),
@valueBPROActualizar	VARCHAR(20)
AS
BEGIN
	DECLARE @v_numeroOrden		VARCHAR(50),
			@v_ote_ordenGlobal	VARCHAR(30) 
	
	SELECT	@v_numeroOrden=b.numeroOrden 
	FROM	cxc.Factura a, solicitud.SolicitudObjeto b 
	WHERE	a.idSolicitud		=b.idSolicitud
	AND		a.idTipoSolicitud	=b.idTipoSolicitud
	AND		a.idClase			=b.idClase
	AND		a.rfcEmpresa		=b.rfcEmpresa
	AND		a.idCliente			=b.idCliente
	AND		a.numeroContrato	=b.numeroContrato
	AND     a.idSolicitud		=@idSolicitud
	AND     a.idTipoSolicitud	=@idTipoSolicitud
	AND     a.idClase			=@idClase
	AND     a.rfcEmpresa		=@rfcEmpresa
	AND     a.idCliente			=@idCliente
	AND     a.numeroContrato	=@numeroContrato

	SELECT  TOP 1 
			@v_ote_ordenGlobal=OTE_ORDENGLOBAL 
	FROM	ASEPROTSISCOV3.DBO.ADE_ORDSERENC 
	WHERE	OTE_ORDENANDRADE	=@v_numeroOrden 

	IF @v_ote_ordenGlobal IS NOT NULL 
		BEGIN
			IF @campoBPROActualizar='COP_IDDOCTO'
				BEGIN
					UPDATE	ASEPROTSISCOV3.DBO.ADE_COPADE 
					SET		COP_IDDOCTO		=@valueBPROActualizar
					WHERE	COP_ORDENGLOBAL	=@v_ote_ordenGlobal

					exec solicitud.UPD_SOLICITUD_AVANZAORDEN_SP @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,6148,''
				END
			IF @campoBPROActualizar='COP_CARGO'
				BEGIN
					UPDATE	ASEPROTSISCOV3.DBO.ADE_COPADE 
					SET		COP_CARGO		=CAST(@valueBPROActualizar AS NUMERIC(18,2))
					WHERE	COP_ORDENGLOBAL	=@v_ote_ordenGlobal

					exec solicitud.UPD_SOLICITUD_AVANZAORDEN_SP @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,6148,''
				END
		END
	
END
go

