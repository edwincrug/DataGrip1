-- =============================================
-- Author:			Adolfo Martinez
-- Create date: 	<27/04/2020>
-- Description:	    <Cancelar Ordenes>
-- =============================================
-- EXEC [solicitud].[UPD_ORDEN_CANCELA] 'Automovil','AAN910409135',218,'0001','<solicitudes><solicitud><idSolicitud>1088</idSolicitud><orden>1-1050-13874</orden></solicitud></solicitudes>',6334,''
/*
1083 1-1046	1-1046-13873  1083	115    1738 1751 1729
SELECT * FROM [solicitud].[Solicitud] WHERE idSolicitud='1088'
SELECT * FROM [solicitud].[SolicitudObjeto] WHERE idSolicitud='1088'
SELECT * FROM [solicitud].[SolicitudCotizacion] WHERE idSolicitud='1088'
SELECT * FROM [Solicitud].[solicitud].[EstatusSolicitudCotizacion] WHERE idSolicitud='1088'
SELECT * FROM [Solicitud].[SolicitudCotizacionPartida] WHERE idSolicitud='1088'
SELECT * FROM [Solicitud].[fase].[SolicitudEstatusPaso] WHERE idSolicitud='1088'

UPDATE [solicitud].[SolicitudCotizacion]
SET idEstatusCotizacion='APROBADA'
WHERE idSolicitud='1088' AND idCotizacion=1756

UPDATE [Solicitud].[SolicitudCotizacionPartida]
SET idEstatusCotizacionPartida='APROBADA'
WHERE idSolicitud='1088' AND idCotizacion=1756

DELETE FROM [Solicitud].[solicitud].[EstatusSolicitudCotizacion]
WHERE idSolicitud='1088'  AND idEstatusCotizacion='CANCELADA' AND idCotizacion=1756

UPDATE [solicitud].[Solicitud]
SET idEstatusSolicituD='ACTIVA'
WHERE idSolicitud='1088'

UPDATE [Solicitud].[fase].[SolicitudEstatusPaso]
SET fechaSalida=null, idUsuarioSalida=null
WHERE idSolicitud='1088' and idPAso='CorteMensual'

*/
-- =============================================
CREATE PROCEDURE [solicitud].[UPD_ORDEN_CANCELA](
	 @idClase				VARCHAR(10)
	,@rfcEmpresa			VARCHAR(13)
	,@idCliente				INT
	,@numeroContrato		VARCHAR(50)
	,@xmlSolicitudes		XML
	,@idUsuario				INT
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN
	BEGIN TRAN CancelaOrden
    BEGIN TRY
		DECLARE @tbl_solicitudes AS TABLE(_row INT IDENTITY(1,1),idSolicitud INT,orden VARCHAR(50))
		INSERT INTO @tbl_solicitudes(idSolicitud, orden) 
		SELECT I.col.value('idSolicitud[1]','int'),I.col.value('orden[1]','varchar(50)')
		FROM @xmlSolicitudes.nodes('solicitudes/solicitud') AS I(col)

	DECLARE @cancelado INT=0
	DECLARE @idSolicitud INT
	DECLARE @orden VARCHAR(50)
	DECLARE @idObjeto INT
	DECLARE @idTipoObjeto INT

	WHILE EXISTS(SELECT 1 FROM @tbl_solicitudes)
		BEGIN
			SELECT TOP 1 @idSolicitud=idSolicitud, @orden=orden FROM @tbl_solicitudes	
				IF EXISTS(SELECT 1 FROM [solicitud].[Solicitud] WHERE idSolicitud=@idSolicitud AND idEstatusSolicitud='ACTIVA')	
					BEGIN	
						SELECT 
							@idObjeto=idObjeto,
							@idTipoObjeto=idTipoObjeto
						FROM [solicitud].[SolicitudObjeto] 
						WHERE idSolicitud=@idSolicitud AND numeroOrden = @orden


						UPDATE [Solicitud].[solicitud].[SolicitudCotizacion]
							SET [idEstatusCotizacion] = 'CANCELADA'
						WHERE idSolicitud = @idSolicitud 
						AND idCotizacion IN(SELECT DISTINCT idCotizacion FROM [solicitud].[SolicitudCotizacionPartida] WHERE idSolicitud=@idSolicitud AND idObjeto=@idObjeto AND idTipoObjeto=@idTipoObjeto) 

						UPDATE solicitud.SolicitudCotizacionPartida
						SET idEstatusCotizacionPartida = 'CANCELADA'
						WHERE idSolicitud = @idSolicitud
						AND idObjeto=@idObjeto AND idTipoObjeto=@idTipoObjeto

						INSERT INTO [Solicitud].[solicitud].[EstatusSolicitudCotizacion]
							(fechaAlta,
							idCotizacion,
							idSolicitud,
							idTipoSolicitud,
							idClase,
							rfcEmpresa,
							idCliente,
							numeroContrato,
							idProveedorEntidad,
							rfcProveedor,
							idEstatusCotizacion,
							idUsuario)
						SELECT 
							GETDATE(),
							idCotizacion,
							idSolicitud,
							idTipoSolicitud,
							idClase,
							rfcEmpresa,
							idCliente,
							numeroContrato,
							idProveedorEntidad,
							rfcProveedor,
							'CANCELADA',
							@idUsuario
						FROM [Solicitud].[solicitud].[SolicitudCotizacion]
						WHERE idSolicitud = @idSolicitud 
						AND idCotizacion IN(SELECT DISTINCT idCotizacion FROM [solicitud].[SolicitudCotizacionPartida] WHERE idSolicitud=@idSolicitud AND idObjeto=@idObjeto AND idTipoObjeto=@idTipoObjeto) 

						IF NOT EXISTS(SELECT 1 FROM [solicitud].[SolicitudCotizacion] WHERE idSolicitud=@idSolicitud AND idEstatusCotizacion IN('APROBADA','ENESPERA'))
							BEGIN
								UPDATE [Solicitud].[solicitud].[Solicitud]
								SET [idEstatusSolicitud] = 'CANCELADA'
								WHERE idSolicitud = @idSolicitud
									AND idClase = @idClase
									--AND rfcEmpresa = @rfcEmpresa
									--AND idCliente = @idCliente
									--AND numeroContrato = @numeroContrato

								UPDATE [Solicitud].[fase].[SolicitudEstatusPaso]
								SET fechaSalida=GETDATE(), idUsuarioSalida=@idUsuario
								WHERE idSolicitud = @idSolicitud
									AND idClase = @idClase
									--AND rfcEmpresa = @rfcEmpresa
									--AND idCliente = @idCliente
									--AND numeroContrato = @numeroContrato
									AND fechaSalida IS NULL
									AND idUsuarioSalida IS NULL
							END
					END
			DELETE FROM @tbl_solicitudes WHERE idSolicitud=@idSolicitud AND orden=@orden
		END

		SET @cancelado = 1
		SELECT 'La orden se cancelo correctamente' msg, @cancelado estatus

		COMMIT TRAN CancelaOrden
					
    END TRY
    BEGIN CATCH
        ROLLBACK TRAN CancelaOrden
        SET @err = 'Ocurrio un error al cancelar la solicitud.'
		SET @cancelado = 0
    END CATCH

END


--USE [Solicitud]
go

