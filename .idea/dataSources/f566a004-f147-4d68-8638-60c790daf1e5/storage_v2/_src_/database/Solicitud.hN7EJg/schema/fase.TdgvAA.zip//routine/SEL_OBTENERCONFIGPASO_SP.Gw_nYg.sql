
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <15/04/2020>
-- Description:	<Procedimiento que obtiene la configuracion del paso>

/*

	declare @err			 VARCHAR(8000) = ''
	exec  [fase].SEL_OBTENERCONFIGPASO_SP 'Cobranza','Cobranza','Automovil',8292

	declare @err			 VARCHAR(8000) = ''
	exec  [fase].SEL_OBTENERCONFIGPASO_SP 'PrefacturaGenerada','PrefacturaGenerada','Automovil',8292

*/
-- =============================================
CREATE PROCEDURE [fase].[SEL_OBTENERCONFIGPASO_SP]
@idPaso			 VARCHAR(50),
@idFase			 VARCHAR(50),
@idClase		 VARCHAR(10),
@idUsuario		 INT,
@err			 VARCHAR(8000) = '' OUTPUT	
AS
BEGIN
	SELECT	idPaso,idFase,nombre titulo,color, 0 idZona
	FROM	solicitud.fase.Paso 
	WHERE	idPaso			=@idPaso 
	AND		idClase			=@idClase 
END
go

