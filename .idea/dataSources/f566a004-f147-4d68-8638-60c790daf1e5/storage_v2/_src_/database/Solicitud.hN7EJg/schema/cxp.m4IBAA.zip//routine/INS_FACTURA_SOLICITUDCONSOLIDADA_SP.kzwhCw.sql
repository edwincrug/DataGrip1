
-- =============================================  
-- Author:  Eric Reyes Xinaxtle  
-- Create date: 08/07/2019  
-- Description: Guardar una factura consolidada.  
/*  
  
  exec [cxp].[INS_FACTURA_SOLICITUDCONSOLIDADA_SP]   
  'Automovil'
  ,'CME720930GM9'
  ,'B38E604A-30FD-4CBF-A838-80232E679264'
  ,NULL
  ,'FG00025633'
  ,'2020-08-26T09:24:08'
  ,'CME720930GM9'
  ,'ASE0508051B6'
  ,99303.47
  ,null
  ,'15888.56'
  ,null
  ,'<traslados><traslado><impuesto>002</impuesto><importe>15888.56</importe><tasa>0.160000</tasa></traslado></traslados>'
  ,null
  ,115192.03
  ,'{"_declaration":{"_attributes":{"version":"1.0","encoding":"UTF-8"}},"cfdi:Comprobante":{"_attributes":{"xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance","xsi:schemaLocation":"http://www.sat.gob.mx/cfd/3 http://www.sat.gob.mx/sitio_internet/cfd/3/cfdv33.xsd","Version":"3.3","Folio":"FG00025633","Fecha":"2020-08-26T09:24:08","Sello":"RpuCGbdinWkrXkVs5fmF/xyQF9VaGsE6/Y31wqe53MJUoaI8PaBm/cWpjcZl5NaL5r9N+AUMJX7CrZbUUumYRFPLrFFo1tsifJYHmLqVAN3lvoLTPyFKNs9lEXllnHmiYK5DQqmJJya8lJ3vjZ1y/NzS3dbLF2tlMgMmk8831rOpxDnOXJT8lU/hs3HC/sdVNWhr61bGE/Ngqf9luiy+6ijx74JEzLHAawopPD8flSv3j+wA41ed+zizYucmgwhYTM1CLBopM6ZuG/0OiyK/jAoOxx+4b2LJ5o17McZ/31+2jUiQX+ZBTrCRDC1HwsWEjFvmnhUVKv0iIEOJr9EA2g==","FormaPago":"99","NoCertificado":"00001000000413167723","Certificado":"MIIGFDCCA/ygAwIBAgIUMDAwMDEwMDAwMDA0MTMxNjc3MjMwDQYJKoZIhvcNAQELBQAwggGyMTgwNgYDVQQDDC9BLkMuIGRlbCBTZXJ2aWNpbyBkZSBBZG1pbmlzdHJhY2nDs24gVHJpYnV0YXJpYTEvMC0GA1UECgwmU2VydmljaW8gZGUgQWRtaW5pc3RyYWNpw7NuIFRyaWJ1dGFyaWExODA2BgNVBAsML0FkbWluaXN0cmFjacOzbiBkZSBTZWd1cmlkYWQgZGUgbGEgSW5mb3JtYWNpw7NuMR8wHQYJKoZIhvcNAQkBFhBhY29kc0BzYXQuZ29iLm14MSYwJAYDVQQJDB1Bdi4gSGlkYWxnbyA3NywgQ29sLiBHdWVycmVybzEOMAwGA1UEEQwFMDYzMDAxCzAJBgNVBAYTAk1YMRkwFwYDVQQIDBBEaXN0cml0byBGZWRlcmFsMRQwEgYDVQQHDAtDdWF1aHTDqW1vYzEVMBMGA1UELRMMU0FUOTcwNzAxTk4zMV0wWwYJKoZIhvcNAQkCDE5SZXNwb25zYWJsZTogQWRtaW5pc3RyYWNpw7NuIENlbnRyYWwgZGUgU2VydmljaW9zIFRyaWJ1dGFyaW9zIGFsIENvbnRyaWJ1eWVudGUwHhcNMTkwMTExMTc0ODQ1WhcNMjMwMTExMTc0ODQ1WjCBtDEcMBoGA1UEAxMTRkNBIE1FWElDTyBTQSBERSBDVjEcMBoGA1UEKRMTRkNBIE1FWElDTyBTQSBERSBDVjEcMBoGA1UEChMTRkNBIE1FWElDTyBTQSBERSBDVjElMCMGA1UELRMcQ01FNzIwOTMwR005IC8gUklDTDY2MDYyM1U3QTEeMBwGA1UEBRMVIC8gUklDTDY2MDYyM0hNQ1ZSUzA3MREwDwYDVQQLEwhTYW50YSBGZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAPgynpxd47lCeyf7M0YLt4hMiwIYW6xzJJfHgDbskNEQCRWi5efaWqhl8OrObUKr19FcZBHlgV3aNqCqZQ3hhqKooHdqQZEvOAmYc+jvSMQOVG+2zrAutq08WH1vEvNaSeEiZo+cb0H9EzUAVCkoE2gcgZFBn9Xs2ykrH7XGOb6bZgbWYXK8dMPsqciDrSKj5XKdMczIwpoczCs7wHmKbRWS+qGzkrX9tIKnOT1uXfA9JnHbNyxeVHnnAvKY2fWEUvvDMXhm9+SvBod1Sq4K5pfqaXn1PmDwzosQ0S+tbBJS0gNjGnoeueK2WeJP243PMZxbkVzlO3OZjxyse2ushPsCAwEAAaMdMBswDAYDVR0TAQH/BAIwADALBgNVHQ8EBAMCBsAwDQYJKoZIhvcNAQELBQADggIBACNO+IBQ6j82Bg112Y3VyTpThDsrASxWlZHXcsjtZo4DMoo82l/TuJeaPaIDT8m4M40rFKOKOH4B2sNlvDjwKBC8So7pSPw6vK47o4gBB+oDoiZ/3ZNQbvYWoBweIzxWwcioziW+ZpsMhxtthehhy8B4ZChatMhOMbXYc6dDnzKWuvxrl0tgKisOF4Xus+S1KAbNiY8UGzwa9Ypc2fSXaywuZKDv/rvNmgkql2zXYmMIFO/SjxRaLQfistylEloJvUgp+It6D9sG2kCoF7H58sPWlKii/a1CprE1PY5PfGHtAL00nFTHjqNz93JPhWYxRKd9ivgAtNVZBi9/gsUf0flXwOU3SaxJlgpEPm/pfRhTD/GLHuFIyfwh4RU6aJ4EhjWEMe3JSWrSl2fNZpjpYedU/ytX9WvbX4cYQTmUyhXPzhAYuhvvlri54gEq/n0P9e/gaJnX/s/reNjIcamQ83LBK5HEfMPuX/OXBV2eWo1xS3ZCJaQsef9pOLfTVB+RepDchA4STAY57URbTLgA5AqlEAXelWD5tVqUv1K/sQkxnygO2OmyAfQ+Y84tO6WjZZSEntaZcIAq7qTMcxkTwpOWSwttKstSOCguyj8UjFVhIelJboLbi2ATN2KhcKSfng8pZqMCdp521UM2cKyOAN69xprgrJSLqkRiY2OUp0kd","SubTotal":"99303.47","Moneda":"MXN","TipoCambio":"1","Total":"115192.03","TipoDeComprobante":"I","MetodoPago":"PPD","LugarExpedicion":"05348","xmlns:cfdi":"http://www.sat.gob.mx/cfd/3"},"cfdi:Emisor":{"_attributes":{"Rfc":"CME720930GM9","Nombre":"FCA MÉXICO S.A. DE C.V.","RegimenFiscal":"601"}},"cfdi:Receptor":{"_attributes":{"Rfc":"ASE0508051B6","Nombre":"AUTOEXPRESS SERVICIO DE EXCELENCIA PEDREGAL SA DE CV","UsoCFDI":"P01"}},"cfdi:Conceptos":{"cfdi:Concepto":{"_attributes":{"ClaveProdServ":"78181500","Cantidad":"1.0000","ClaveUnidad":"E48","Unidad":"SERV","Descripcion":"FACTURA 5/16","ValorUnitario":"99303.470000","Importe":"99303.47"},"cfdi:Impuestos":{"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Base":"99303.470000","Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"15888.56"}}}}}},"cfdi:Impuestos":{"_attributes":{"TotalImpuestosTrasladados":"15888.56"},"cfdi:Traslados":{"cfdi:Traslado":{"_attributes":{"Impuesto":"002","TipoFactor":"Tasa","TasaOCuota":"0.160000","Importe":"15888.56"}}}},"cfdi:Complemento":{"tfd:TimbreFiscalDigital":{"_attributes":{"xmlns:tfd":"http://www.sat.gob.mx/TimbreFiscalDigital","xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance","xsi:schemaLocation":"http://www.sat.gob.mx/TimbreFiscalDigital http://www.sat.gob.mx/sitio_internet/cfd/TimbreFiscalDigital/TimbreFiscalDigitalv11.xsd","Version":"1.1","UUID":"B38E604A-30FD-4CBF-A838-80232E679264","FechaTimbrado":"2020-08-26T09:24:47","RfcProvCertif":"ASE0209252Q1","SelloCFD":"RpuCGbdinWkrXkVs5fmF/xyQF9VaGsE6/Y31wqe53MJUoaI8PaBm/cWpjcZl5NaL5r9N+AUMJX7CrZbUUumYRFPLrFFo1tsifJYHmLqVAN3lvoLTPyFKNs9lEXllnHmiYK5DQqmJJya8lJ3vjZ1y/NzS3dbLF2tlMgMmk8831rOpxDnOXJT8lU/hs3HC/sdVNWhr61bGE/Ngqf9luiy+6ijx74JEzLHAawopPD8flSv3j+wA41ed+zizYucmgwhYTM1CLBopM6ZuG/0OiyK/jAoOxx+4b2LJ5o17McZ/31+2jUiQX+ZBTrCRDC1HwsWEjFvmnhUVKv0iIEOJr9EA2g==","NoCertificadoSAT":"00001000000404481161","SelloSAT":"EavKAOOd3Y60Jr5FmeV6GdLgkkwqSMBHDv8K3lNr8O3rVpo66e71Mr0dVRL6EtdjR1nCSxVLvil8Io3j2J8H/MM9pBibKkY9/0iPABd3gA2N4vqGO0wtSi0OO04KwJXU8HJb7gO8kP+iBahOlKMKBvBPFdkp6GRNxXvOJzECttx5rfwjq52HJ8gzyD+lWNho0tdQ09tSVoHdZ7oPvNcb98na7HTfhEzdirEDk6gv34PELT1DZ4IV9GIeFtEssSPeK92Yq1IaUvWXA0vzLi0te4p35/zjEZ2eavhuvpmYtXiQV7P/OodS1QTcdflUlwfYLDu4yOItsFqkYdVYzADGmQ=="}}},"cfdi:Addenda":{"CFDEnc":{"_attributes":{"Empresa":"0000000018","Factura":"FG00025633","Cliente":"MS080","RazonSocial":"AUTOEXPRESS SERVICIO DE EXCELENCIA PEDREGAL SA DE CV","RFC":"ASE0508051B6","Calle":"AV. SAN JERONIMO","Numero":"220","Colonia":"LA OTRA BANDA","Delegacion":"COYOACAN","Estado":"DIF","CP":"04519","Pais":"MEX","Monto":"115192.03","SubTotal":"99303.47","Descuento":"0.00","Impuesto":"15888.56","Retencion":"0.00","FechaEmision":"2020-08-26T09:24:08","customfield01":"","customfield02":"","customfield03":"","customfield04":"","Moneda":"MXN","TipoCambio":"1.0000","FechaGenerada":"2020-08-26T09:24:08","SinIVA":"0","ImprimePartidas":"1","Serie":"","FolioFiscal":"B38E604A-30FD-4CBF-A838-80232E679264","NoAprobacion":"0","AñoAprobacion":"0","FechaHoraExpedicion":"2020-08-26T09:24:08","Sello":"RpuCGbdinWkrXkVs5fmF/xyQF9VaGsE6/Y31wqe53MJUoaI8PaBm/cWpjcZl5NaL5r9N+AUMJX7CrZbUUumYRFPLrFFo1tsifJYHmLqVAN3lvoLTPyFKNs9lEXllnHmiYK5DQqmJJya8lJ3vjZ1y/NzS3dbLF2tlMgMmk8831rOpxDnOXJT8lU/hs3HC/sdVNWhr61bGE/Ngqf9luiy+6ijx74JEzLHAawopPD8flSv3j+wA41ed+zizYucmgwhYTM1CLBopM6ZuG/0OiyK/jAoOxx+4b2LJ5o17McZ/31+2jUiQX+ZBTrCRDC1HwsWEjFvmnhUVKv0iIEOJr9EA2g==","CadenaOriginal":"||3.3|FG00025633|2020-08-26T09:24:08|99|00001000000413167723|99303.47|MXN|1|115192.03|I|PPD|05348|CME720930GM9|FCA MÉXICO S.A. DE C.V.|601|ASE0508051B6|AUTOEXPRESS SERVICIO DE EXCELENCIA PEDREGAL SA DE CV|P01|78181500|1.0000|E48|SERV|FACTURA 5/16|99303.470000|99303.47|99303.470000|002|Tasa|0.160000|15888.56|002|Tasa|0.160000|15888.56|15888.56||","FormaPago":"99","CustomField03":"","CustomField01":"","formaDePago":"PPD","EDesCorta":"","EDes":"Ciudad de México","DFCalle":"PROLONGACION PASEO DE LA REFORMA ","DFNumero":"1240                ","DFColonia":"SANTA FE CUAJIMALPA                               ","DFDelegacion":"DEL. CUAJIMALPA                                   ","DFEstado":"Ciudad de México","DFCP":"05348       ","CertificadoSerie":"00001000000413167723","Emisor":"FCA MÉXICO S.A. DE C.V.                                                                                                                              ","EmisorRFC":"CME720930GM9   ","CFDDes":"01-Factura","CFDTipoEfecto":"ingreso","ImpuestoDetalle":"002 16%15888.56\r\n","PorcentajeImpuesto":"16.0000","FechaLarga":"26 de Agosto del 2020 09:24:08","tipodocumento":"01","facturastatus":"DG","MesEspa":"Agosto"},"CFDEnc2":{"_attributes":{"TipoDireccion":"002","CodigoDireccion":"08480","Nombre":"FCA MEXICO, S.A. DE C.V.","Calle":"PROLONGACION PASEO DE LA REFORMA","NoExterior":"","NoInterior":"","Colonia":"SANTA FE CUAJIMALPA","Localidad":"","Referencia":"","Municipio":"","Pais":"ME","CodigoPostal":"","CustomField01":"DISTRITO FEDERAL"}},"CFDEnc3":{"_attributes":{"TipoDireccion":"003","CodigoDireccion":"MS080","Nombre":"AUTOEXPRESS SERVICIO DE EXCELENCIA","Calle":"AV. SAN JERONIMO","NoExterior":"","NoInterior":"","Colonia":"LA OTRA BANDA","Localidad":"","Referencia":"","Municipio":"","Pais":"ME","CodigoPostal":"","CustomField01":"DIF"}},"CFDEnc5":{"_attributes":{"Nota":""}},"CFDEnc6":{"_attributes":{"Nota":""}},"CFDEnc8":{"_attributes":{"Moneda":"MXN","MontoPesosNumero":"115192.03","MontoPesosLetra":"(CIENTO QUINCE MIL CIENTO NOVENTA Y DOS PESOS 03/100)","MontoTotalMoneda":"5239.81","MontoMonedaConLetra":"(CINCO MIL DOSCIENTOS TREINTA Y NUEVE US.DLLS. 81/100)","TipoCambio":"1.00000"}},"CFDEnc11":{"_attributes":{"Nota":""}},"CFDEnc12":{"_attributes":{"Consecutivo":"1","Regimen":"601                                                                                                                                                   "}},"CFDEnc13":{"_attributes":{"Cliente":"MS080","RazonSocial":"AUTOEXPRESS SERVICIO DE EXCELENCIA PEDREGAL SA DE CV","RFC":"ASE0508051B6","Giro":"OTR","CuentaContable":"","Activo":"1","Linea1":"","Linea2":"","Linea3":"","Linea4":"","Linea5":"","Linea6":"","Rol":"C","DirImpFE":"","DirExpFE":"","NombreCertificado":"","Formato1":"0","Formato2":"0","Formato3":"0","Formato4":"0","Formato5":"0","Formato6":"0","Formato7":"0","Formato8":"0","Formato9":"1","Formato10":"0","Formato11":"0","Formato12":"0","Formato13":"1","Formato14":"0","Formato15":"0","Adenda":"61","Transporte":"10","NoProveedor":"","GLN":"","FormaPago":"","NumCtaPago":"","tin":"","curp":"","usoCFDI":""}},"CFDEnc15":{"_attributes":{"UUID":"B38E604A-30FD-4CBF-A838-80232E679264","FechaTimbrado":"2020-08-26T09:24:47","selloCFD":"RpuCGbdinWkrXkVs5fmF/xyQF9VaGsE6/Y31wqe53MJUoaI8PaBm/cWpjcZl5NaL5r9N+AUMJX7CrZbUUumYRFPLrFFo1tsifJYHmLqVAN3lvoLTPyFKNs9lEXllnHmiYK5DQqmJJya8lJ3vjZ1y/NzS3dbLF2tlMgMmk8831rOpxDnOXJT8lU/hs3HC/sdVNWhr61bGE/Ngqf9luiy+6ijx74JEzLHAawopPD8flSv3j+wA41ed+zizYucmgwhYTM1CLBopM6ZuG/0OiyK/jAoOxx+4b2LJ5o17McZ/31+2jUiQX+ZBTrCRDC1HwsWEjFvmnhUVKv0iIEOJr9EA2g==","selloSAT":"EavKAOOd3Y60Jr5FmeV6GdLgkkwqSMBHDv8K3lNr8O3rVpo66e71Mr0dVRL6EtdjR1nCSxVLvil8Io3j2J8H/MM9pBibKkY9/0iPABd3gA2N4vqGO0wtSi0OO04KwJXU8HJb7gO8kP+iBahOlKMKBvBPFdkp6GRNxXvOJzECttx5rfwjq52HJ8gzyD+lWNho0tdQ09tSVoHdZ7oPvNcb98na7HTfhEzdirEDk6gv34PELT1DZ4IV9GIeFtEssSPeK92Yq1IaUvWXA0vzLi0te4p35/zjEZ2eavhuvpmYtXiQV7P/OodS1QTcdflUlwfYLDu4yOItsFqkYdVYzADGmQ==","noCertificadoSAT":"00001000000404481161","cadenaoriginal3":"||1.1|B38E604A-30FD-4CBF-A838-80232E679264|2020-08-26T09:24:47|ASE0209252Q1|RpuCGbdinWkrXkVs5fmF/xyQF9VaGsE6/Y31wqe53MJUoaI8PaBm/cWpjcZl5NaL5r9N+AUMJX7CrZbUUumYRFPLrFFo1tsifJYHmLqVAN3lvoLTPyFKNs9lEXllnHmiYK5DQqmJJya8lJ3vjZ1y/NzS3dbLF2tlMgMmk8831rOpxDnOXJT8lU/hs3HC/sdVNWhr61bGE/Ngqf9luiy+6ijx74JEzLHAawopPD8flSv3j+wA41ed+zizYucmgwhYTM1CLBopM6ZuG/0OiyK/jAoOxx+4b2LJ5o17McZ/31+2jUiQX+ZBTrCRDC1HwsWEjFvmnhUVKv0iIEOJr9EA2g==|00001000000404481161||"}},"CFDEnc17":{"_attributes":{"IVAGlobal":"1","TasaIVA":"16.0000","RetencionGlobal":"1","usoCFDI":"P01"}},"CFDEnc18":{"_attributes":{"LugarExpedicion":"05348                                                                                                                                                 "}},"CFDEnc19":{"_attributes":{"rutaQR":"D:\\ATEB\\ATEBCOFIDI\\EXPORT\\COFIDI\\MISCELANEOS\\202008\\26\\01\\FG00025633_B38E604A-30FD-4CBF-A838-80232E679264.jpg"}},"CFDEnc20":{"_attributes":{"DESPF":"99 - Por definir"}},"CFDEnc21":{"_attributes":{"DESRF":"601 - General de Ley Personas Morales"}},"CFDEnc22":{"_attributes":{"DESMF":"PPD - Pago en parcialidades o diferido"}},"CFDEnc23":{"_attributes":{"UUID":"B38E604A-30FD-4CBF-A838-80232E679264","FechaTimbrado":"2020-08-26T09:24:47","selloCFD":"RpuCGbdinWkrXkVs5fmF/xyQF9VaGsE6/Y31wqe53MJUoaI8PaBm/cWpjcZl5NaL5r9N+AUMJX7CrZbUUumYRFPLrFFo1tsifJYHmLqVAN3lvoLTPyFKNs9lEXllnHmiYK5DQqmJJya8lJ3vjZ1y/NzS3dbLF2tlMgMmk8831rOpxDnOXJT8lU/hs3HC/sdVNWhr61bGE/Ngqf9luiy+6ijx74JEzLHAawopPD8flSv3j+wA41ed+zizYucmgwhYTM1CLBopM6ZuG/0OiyK/jAoOxx+4b2LJ5o17McZ/31+2jUiQX+ZBTrCRDC1HwsWEjFvmnhUVKv0iIEOJr9EA2g==","selloSAT":"EavKAOOd3Y60Jr5FmeV6GdLgkkwqSMBHDv8K3lNr8O3rVpo66e71Mr0dVRL6EtdjR1nCSxVLvil8Io3j2J8H/MM9pBibKkY9/0iPABd3gA2N4vqGO0wtSi0OO04KwJXU8HJb7gO8kP+iBahOlKMKBvBPFdkp6GRNxXvOJzECttx5rfwjq52HJ8gzyD+lWNho0tdQ09tSVoHdZ7oPvNcb98na7HTfhEzdirEDk6gv34PELT1DZ4IV9GIeFtEssSPeK92Yq1IaUvWXA0vzLi0te4p35/zjEZ2eavhuvpmYtXiQV7P/OodS1QTcdflUlwfYLDu4yOItsFqkYdVYzADGmQ==","noCertificadoSAT":"00001000000404481161","cadenaoriginal13":"||1.1|B38E604A-30FD-4CBF-A838-80232E679264|2020-08-26T09:24:47|ASE0209252Q1|","cadenaoriginal23":"RpuCGbdinWkrXkVs5fmF/xyQF9VaGsE6/Y31wqe53MJUoaI8PaBm/cWpjcZl5NaL5r9N+AUMJX7CrZbUUumYRFPLrFFo1tsifJYHmLqVAN3lvoLTPyFKNs9lEXllnHmiYK5DQqmJJya8lJ3vjZ1y/NzS3dbLF2tlMgMmk8831rOpxDnOXJT8lU/hs3HC/sdVNWhr61bGE/Ngqf9luiy+6ijx74JEzLHAawopPD8flSv3j+wA41ed+zizYucmgwhYTM1CLBopM6ZuG/0OiyK/jAoOxx+4b2LJ5o17McZ/31+2jUiQX+ZBTrCRDC1HwsWEjFvmnhUVKv0iIEOJr9EA2g==|","cadenaoriginal33":"00001000000404481161||"}},"CFDDet":{"_attributes":{"Consecutivo":"1","Cantidad":"1.0000","Descripcion":"FACTURA 5/16","Precio":"99303.470000","UnidadMedida":"SERV","Cargo":"0.0000","CustomField01":"99303.47","CustomField02":""}}}}}}'
  ,'<cotizaciones><cotizacion><idCotizacion>228662</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>133623</idSolicitud><numeroCotizacion>37-18838-9456-2</numeroCotizacion><numeroOrden>37-18838-9456</numeroOrden><version>SISCO V2</version><montoAbonado>17646.65</montoAbonado></cotizacion><cotizacion><idCotizacion>242571</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>142063</idSolicitud><numeroCotizacion>37-18639-9979-2</numeroCotizacion><numeroOrden>37-18639-9979</numeroOrden><version>SISCO V2</version><montoAbonado>7819.17</montoAbonado></cotizacion><cotizacion><idCotizacion>246226</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>143943</idSolicitud><numeroCotizacion>37-18276-10173-2</numeroCotizacion><numeroOrden>37-18276-10173</numeroOrden><version>SISCO V2</version><montoAbonado>12015</montoAbonado></cotizacion><cotizacion><idCotizacion>263432</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>152912</idSolicitud><numeroCotizacion>37-18276-10921-2</numeroCotizacion><numeroOrden>37-18276-10921</numeroOrden><version>SISCO V2</version><montoAbonado>3427.6</montoAbonado></cotizacion><cotizacion><idCotizacion>254850</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>148446</idSolicitud><numeroCotizacion>37-18284-10549-2</numeroCotizacion><numeroOrden>37-18284-10549</numeroOrden><version>SISCO V2</version><montoAbonado>8103.7</montoAbonado></cotizacion><cotizacion><idCotizacion>244224</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>142889</idSolicitud><numeroCotizacion>37-18163-10059-2</numeroCotizacion><numeroOrden>37-18163-10059</numeroOrden><version>SISCO V2</version><montoAbonado>3520.7</montoAbonado></cotizacion><cotizacion><idCotizacion>246681</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>144157</idSolicitud><numeroCotizacion>37-18787-10210-2</numeroCotizacion><numeroOrden>37-18787-10210</numeroOrden><version>SISCO V2</version><montoAbonado>2240.1</montoAbonado></cotizacion><cotizacion><idCotizacion>252501</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>147024</idSolicitud><numeroCotizacion>37-18802-10473-2</numeroCotizacion><numeroOrden>37-18802-10473</numeroOrden><version>SISCO V2</version><montoAbonado>3520.7</montoAbonado></cotizacion><cotizacion><idCotizacion>242421</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>141988</idSolicitud><numeroCotizacion>37-18315-9960-2</numeroCotizacion><numeroOrden>37-18315-9960</numeroOrden><version>SISCO V2</version><montoAbonado>2193.55</montoAbonado></cotizacion><cotizacion><idCotizacion>252498</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>147007</idSolicitud><numeroCotizacion>37-18342-10470-2</numeroCotizacion><numeroOrden>37-18342-10470</numeroOrden><version>SISCO V2</version><montoAbonado>2193.55</montoAbonado></cotizacion><cotizacion><idCotizacion>245278</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>143398</idSolicitud><numeroCotizacion>37-18376-10089-2</numeroCotizacion><numeroOrden>37-18376-10089</numeroOrden><version>SISCO V2</version><montoAbonado>12015</montoAbonado></cotizacion><cotizacion><idCotizacion>246430</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>144040</idSolicitud><numeroCotizacion>37-18327-10193-2</numeroCotizacion><numeroOrden>37-18327-10193</numeroOrden><version>SISCO V2</version><montoAbonado>8112.55</montoAbonado></cotizacion><cotizacion><idCotizacion>244152</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>142847</idSolicitud><numeroCotizacion>37-18780-10054-2</numeroCotizacion><numeroOrden>37-18780-10054</numeroOrden><version>SISCO V2</version><montoAbonado>2193.55</montoAbonado></cotizacion><cotizacion><idCotizacion>230892</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>134816</idSolicitud><numeroCotizacion>37-18654-9576-2</numeroCotizacion><numeroOrden>37-18654-9576</numeroOrden><version>SISCO V2</version><montoAbonado>2286.65</montoAbonado></cotizacion><cotizacion><idCotizacion>249467</idCotizacion><idProveedorEntidad>0</idProveedorEntidad><idSolicitud>145552</idSolicitud><numeroCotizacion>37-19281-10351-2</numeroCotizacion><numeroOrden>37-19281-10351</numeroOrden><version>SISCO V2</version><montoAbonado>12015</montoAbonado></cotizacion></cotizaciones>'
  ,66156
  ,66157
  ,2326
  ,''

*/  
-- =============================================  
CREATE PROCEDURE [cxp].[INS_FACTURA_SOLICITUDCONSOLIDADA_SP]  
    @idClase varchar(50),  
    @rfcProveedor varchar(50),  
    @uuid varchar(50),  
    @serie varchar(250) = NULL,  
    @folio varchar(250)=NULL,  
    @fechaFactura datetime,  
    @rfcEmisor varchar(13),  
	@rfcReceptor varchar(13),  
    @subTotal float=0,  
	@descuento float=null,
	@traslado float=null,
	@retencion float=null,
    @trasladosXml xml,
	@retencionesXml xml,
    @total float,  
    @xml varchar(max),  
	@xmlCotizaciones xml,
	@idDocumentoPdf int,  
	@idDocumentoXml int,  
	@disponible int,
	@idUsuario int,  
	@err     VARCHAR(8000) = '' OUTPUT   
AS  
BEGIN TRY  
 BEGIN TRANSACTION   
    
	DECLARE @IdDatosFacturaConcentra int = 0

	if (@serie='') set @serie=NULL
	if (@folio='') set @folio=NULL
   
  DECLARE @tbl_cotizaciones AS TABLE (  
   _row int identity(1,1),  
   idCotizacion int,
   idProveedorEntidad int,    
   idSolicitud int, 
   numeroCotizacion varchar(50),
   numeroOrden varchar(50),  
   version varchar(50),
   montoAbonado float
  )  
  
  INSERT INTO @tbl_cotizaciones  
  SELECT   
	ParamValues.col.value('idCotizacion[1]','int') 
	,ParamValues.col.value('idProveedorEntidad[1]','int')   
	,ParamValues.col.value('idSolicitud[1]','int')  
	,ParamValues.col.value('numeroCotizacion[1]','varchar(10)')   
	,ParamValues.col.value('numeroOrden[1]','varchar(50)')  
	,ParamValues.col.value('version[1]','varchar(50)')  
	,ParamValues.col.value('montoAbonado[1]','float')  
  FROM @xmlCotizaciones.nodes('cotizaciones/cotizacion') AS ParamValues(col)  

  --SE SEPARAN LOS REGISTROS PARA SISCO V2
  DECLARE @tbl_cotizacionesV2 AS TABLE (  
   _row int identity(1,1),  
   IdDatosFacturaConcentra INT,
   idCotizacion int,
   fechaAsignacion DATETIME
  )  

  INSERT INTO @tbl_cotizacionesV2 SELECT 0, idCotizacion, getdate() FROM @tbl_cotizaciones WHERE VERSION = 'SISCO V2'

  --SE SEPARAN LOS REGISTROS PARA SISCO V3
  DECLARE @tbl_cotizacionesV3 AS TABLE (  
   _row int identity(1,1),  
   idCotizacion int,
   idProveedorEntidad int,    
   idSolicitud int, 
   numeroCotizacion varchar(50),
   numeroOrden varchar(50),  
   version varchar(50),
   montoAbonado float
  )  

  INSERT INTO @tbl_cotizacionesV3 SELECT idCotizacion, idProveedorEntidad,idSolicitud,numeroCotizacion,numeroOrden, version,montoAbonado 
  FROM @tbl_cotizaciones WHERE VERSION = 'SISCO V3'



  IF ((SELECT COUNT(*) from @tbl_cotizacionesV2) > 0) AND ((SELECT COUNT(*) FROM [aseprot].[dbo].[DatosFacturaConcentra] WHERE Uuid = @uuid) = 0 )
  BEGIN
	--SI ES VERSION SISCO 2
	
	INSERT INTO [aseprot].[dbo].[DatosFacturaConcentra](
		IdCatalogoFacturaConcentra	
		,SubTotal	
		,Total	
		,Disponible	
		,FechaCarga	
		,FechaFactura	
		,Folio	
		,Uuid	
		,Moneda	
		,RfcEmisor	
		,RfcReceptor	
		,Xml
	)VALUES(
	CASE
		WHEN (SELECT TOP(1) idProveedorEncabezado FROM partidas..Proveedor where RFC = @rfcProveedor) = 1616--FEC
		THEN  1
		WHEN (SELECT TOP(1) idProveedorEncabezado FROM partidas..Proveedor where RFC = @rfcProveedor) = 1056--FCA
		THEN  2
		WHEN (SELECT TOP(1) idProveedorEncabezado FROM partidas..Proveedor where RFC = @rfcProveedor) = 1086--FCA
		THEN  3
		WHEN (SELECT TOP(1) idProveedorEncabezado FROM partidas..Proveedor where RFC = @rfcProveedor) = 1161--FCA
		THEN  4
		WHEN (SELECT TOP(1) idProveedorEncabezado FROM partidas..Proveedor where RFC = @rfcProveedor) = 1589--MIDA
		THEN  5
		ELSE 1
	END 
	,@subTotal
	,@total
	,@disponible
	,GETDATE()
	,@fechaFactura
	,@folio
	,@uuid
	,'MXN'
	,@rfcEmisor
	,@rfcReceptor
	,@xml
	)

	SELECT @IdDatosFacturaConcentra = MAX(IdDatosFacturaConcentra)
	FROM [aseprot].[dbo].[DatosFacturaConcentra] 

	--SE ACTUALIZAN LOS DATOS DE LA TABLA TEMPORAL CON EL @IdDatosFacturaConcentra
	UPDATE @tbl_cotizacionesV2 SET IdDatosFacturaConcentra = @IdDatosFacturaConcentra

	--SE INSERTAN LOS IDS DE COTIZACION CON EL CONSECUTIVO DE LA OTRA TABLA
	INSERT INTO [aseprot].[dbo].[DatosFacturaConcentraCotizacion]
	SELECT IdDatosFacturaConcentra,idCotizacion,fechaAsignacion FROM @tbl_cotizacionesV2
  END

  ELSE
	BEGIN
		SET @err = 'Ya existe UUID en SISCOV2'
	END

  	INSERT INTO [Solicitud].[cxp].[Factura] (
		[uuid]
		,[serie]
		,[folio]
		,[fechaFactura]
		,[rfcEmisor]
		,[rfcReceptor]
		,[subtotal]
		,[descuento]
		,[total]
		,[saldo]
		,[idUsuario]
		,[xml]
		,[idDocumentoXml]
		,[idDocumentoPdf]
		,[traslado]
		,[retencion]
	)VALUES(
		@uuid
		,ISNULL(@serie,'')
		,ISNULL(@folio,'')
		,@fechaFactura
		,@rfcEmisor
		,@rfcReceptor
		,@subTotal
		,@descuento
		,@total
		,@total
		,@idUsuario
		,@xml
		,@idDocumentoXml
		,@idDocumentoPdf
		,@traslado
		,@retencion
	)

  IF (SELECT COUNT(*) from @tbl_cotizacionesV3) > 0
  BEGIN
	--SI ES VERSION SISCO 3
	if (@serie is null and @folio is null)
	begin
		update [Solicitud].[cxp].[Factura] SET serie = SUBSTRING(@uuid,25,12) where uuid = @uuid
	end

	IF(@trasladosXml IS NOT NULL)
	BEGIN

		DECLARE @tbl_traslados AS TABLE (
			impuesto		varchar(3),			
			importe			float,
			tasa			float
		)

		INSERT INTO @tbl_traslados
		SELECT   
			ParamValues.col.value('impuesto[1]','varchar(3)')
			,ParamValues.col.value('importe[1]','float')
			,ParamValues.col.value('tasa[1]','float')
		FROM @trasladosXml.nodes('traslados/traslado') AS ParamValues(col)  
	
		INSERT INTO [Solicitud].[cxp].[FacturaImpuesto] 
			SELECT
				@uuid
				,T.tasa
				,T.importe
				,TFI.idTipoFacturaImpuesto
			FROM @tbl_traslados T 
			INNER JOIN [Solicitud].[cxp].[TipoFacturaImpuesto] TFI
				ON T.impuesto = TFI.clave
			WHERE TFI.idTipo = 1

	END

	IF(@retencionesXml IS NOT NULL)
	BEGIN

		DECLARE @tbl_retenciones AS TABLE (
			impuesto		varchar(3),	
			importe			float,
			tasa			float
		)

		INSERT INTO @tbl_retenciones
		SELECT   
			ParamValues.col.value('impuesto[1]','varchar(3)')
			,ParamValues.col.value('importe[1]','float')
			,ParamValues.col.value('tasa[1]','float')
		FROM @retencionesXml.nodes('retenciones/retencion') AS ParamValues(col)  
	
		INSERT INTO [Solicitud].[cxp].[FacturaImpuesto] 
			SELECT
				@uuid
				,R.tasa
				,R.importe
				,TFI.idTipoFacturaImpuesto
			FROM @tbl_retenciones R
			INNER JOIN [Solicitud].[cxp].[TipoFacturaImpuesto] TFI
				ON R.impuesto = TFI.clave
			WHERE TFI.idTipo = 2

	END

	INSERT INTO cxp.SolicitudCotizacionFactura(  
    idCotizacion,  
    idSolicitud,  
    idTipoSolicitud,  
    idClase,  
    rfcEmpresa,  
    idCliente,  
    numeroContrato,  
    idProveedorEntidad,  
    rfcProveedor,  
    uuid  
   ) 
   SELECT
    TC.idCotizacion,  
    TC.idSolicitud,  
    idTipoSolicitud,  
    @idClase,  
    rfcEmpresa,  
    idCliente,  
    numeroContrato,  
    TC.idProveedorEntidad,  
    @rfcProveedor,  
    @uuid  
   FROM @tbl_cotizaciones TC
   INNER JOIN [solicitud].[SolicitudCotizacion] SC ON SC.idCotizacion = TC.idCotizacion
   
      INSERT INTO cxp.SolicitudCotizacionFacturaDetalle(  
    idCotizacion,  
    idSolicitud,  
    idTipoSolicitud,  
    idClase,  
    rfcEmpresa,  
    idCliente,  
    numeroContrato,  
    idProveedorEntidad,  
    rfcProveedor,  
    uuid,  
    idObjeto,  
    idTipoObjeto,  
    idPartida,  
    montoAbonado,  
    fechaAbono,  
    idUsuario  
   ) 

   SELECT
    C.idCotizacion,  
    C.idSolicitud,  
    idTipoSolicitud,  
    @idClase,  
    rfcEmpresa,  
    idCliente,  
    numeroContrato,  
    C.idProveedorEntidad,  
    rfcProveedor,  
    @uuid,  
    idObjeto,  
    idTipoObjeto,  
    idPartida,  
    montoAbonado,  
    GETDATE(),  
    @idUsuario  
   FROM @tbl_cotizaciones C
   INNER JOIN [solicitud].[SolicitudCotizacionPartida] SCP ON SCP.idCotizacion = C.idCotizacion
  END

 COMMIT  
END TRY  
  
BEGIN CATCH  
ROLLBACK TRANSACTION  
 SELECT     
        ERROR_NUMBER() AS ErrorNumber    
       ,ERROR_MESSAGE() AS ErrorMessage;  
SET @err = 'Error al intentar guardar la factura. Puede que ya exista una Factura con los mismos datos en el sistema'  
END CATCH

go

