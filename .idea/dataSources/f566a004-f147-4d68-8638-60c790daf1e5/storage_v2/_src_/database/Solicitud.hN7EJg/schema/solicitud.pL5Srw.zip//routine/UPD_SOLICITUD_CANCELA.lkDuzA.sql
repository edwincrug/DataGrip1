-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<20/04/2020>
-- Description:	    <Cancelar Solicitud>
-- =============================================
-- EXEC [solicitud].[UPD_SOLICITUD_CANCELA] 1976, 'Servicio', 'Automovil', 'ASE0508051B6',185, '128', 2326, ''

--select * from solicitud.solicitud.SolicitudObjeto where numeroOrden = '152-1212-12974'
-- =============================================
CREATE PROCEDURE [solicitud].[UPD_SOLICITUD_CANCELA]
(
     @idSolicitud       INT
	,@idTipoSolicitud   VARCHAR(10)
	,@idClase			VARCHAR(10)
	,@rfcEmpresa        VARCHAR(13)
	,@idCliente         INT
	,@numeroContrato    VARCHAR(50)
	,@idUsuario			INT
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
DECLARE @cancelado				INT=0
BEGIN
	BEGIN TRAN CancelaSolicitud
    BEGIN TRY

		UPDATE [Solicitud].[solicitud].[Solicitud]
		SET [idEstatusSolicitud] = 'CANCELADA'
		WHERE idSolicitud = @idSolicitud
			AND idTipoSolicitud = @idTipoSolicitud
			AND idClase = @idClase
			AND rfcEmpresa = @rfcEmpresa
			AND idCliente = @idCliente
			AND numeroContrato = @numeroContrato
		--SELECT * FROM [Solicitud].[solicitud].[Solicitud] WHERE idSolicitud = 405
		
		UPDATE [Solicitud].[fase].[SolicitudEstatusPaso]
		SET fechaSalida=GETDATE(), idUsuarioSalida=@idUsuario
		WHERE idSolicitud = @idSolicitud
			AND idTipoSolicitud = @idTipoSolicitud
			AND idClase = @idClase
			AND rfcEmpresa = @rfcEmpresa
			AND idCliente = @idCliente
			AND numeroContrato = @numeroContrato
			AND fechaSalida IS NULL
			AND idUsuarioSalida IS NULL

		SET @cancelado = 1
		SET @err = 'La SOLICITUD se cancelo de forma correcta.'
        	
		SELECT @cancelado cancelado

		COMMIT TRAN CancelaSolicitud
					
    END TRY
    BEGIN CATCH
        ROLLBACK TRAN CancelaSolicitud
        SET @err = 'Ocurrio un error al cancelar la solicitud.'
		SET @cancelado = 0
    END CATCH
END
go

