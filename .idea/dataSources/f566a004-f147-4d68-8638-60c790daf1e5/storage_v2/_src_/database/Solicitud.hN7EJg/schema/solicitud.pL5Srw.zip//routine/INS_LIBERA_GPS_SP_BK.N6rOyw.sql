-- =============================================
-- Author:		<DVR>
-- Create date: <09/09/2020>
-- Description:	<Libera el Gps al vehiculo>
-- TEST

/*

[solicitud].[INS_LIBERA_GPS_SP]  
@idSolicitud  = 12196,  
@idTipoSolicitud = 'Instala', 
@rfcEmpresa   = 'AAN910409135', 
@idCliente   = 104,  
@numeroContrato  = 'INTEGRA02',
@idClase    = 'Automovil',  
@idUsuario = 2271,
@err = ''

*/
-- =============================================
CREATE PROCEDURE [solicitud].[INS_LIBERA_GPS_SP_BK] 
	@idSolicitud	    int,
	@idTipoSolicitud	varchar(50),
	@rfcEmpresa         varchar(15),
	@idCliente			int,
	@numeroContrato		varchar(50),
	@idClase			varchar(10),
	@idUsuario			int,  
	@err				varchar(500)OUTPUT 
AS
BEGIN
	BEGIN TRY

		DECLARE @total INT = 0,@aux INT = 1
		DECLARE @v_idTipoInventario VARCHAR(40),@v_idCategoria VARCHAR(40),@v_cantidad INT,@v_aux INT

		DECLARE @TABLA_GPS TABLE(id int identity(1,1),
		idSolicitud int,
		idTipoObjeto int,
		idClase varchar(50),
		rfcEmpresa varchar(50),
		idCliente int,
		numeroContrato varchar(50),
		idTipoSolicitud varchar(50),
		idObjeto int,
		idGPSSIM int,
		fechaAlta datetime,
		idUsuario int,
		desinstalacion int
		)

		INSERT INTO @TABLA_GPS
		SELECT 
		[idSolicitud]
		,[idTipoObjeto]
		,[idClase]
		,[rfcEmpresa]
		,[idCliente]
		,[numeroContrato]
		,[idTipoSolicitud]
		,[idObjeto]
		,[idGPSSIM]
		,[fechaAlta]
		,[idUsuario]
		,[desinstalacion]
		FROM [Solicitud].[solicitud].[SolicitudObjetoGPSSIM]
		WHERE idSolicitud = @idSolicitud
		AND idTipoSolicitud = @idTipoSolicitud
		AND idClase =  @idClase   
		AND rfcEmpresa = @rfcEmpresa     
		AND idCliente = @idCliente   
		AND numeroContrato = @numeroContrato 

		select * from @TABLA_GPS

		DECLARE @detalleDesinstalar TABLE(id int identity(1,1),idTipoObjeto INT,idObjeto INT,idTipoInventario VARCHAR(90),idCategoria VARCHAR(40))
		DECLARE @detalleSolicitud TABLE(id int identity(1,1),idTipoObjeto INT,idObjeto INT,idTipoInventario VARCHAR(90),idCategoria VARCHAR(40),cantidad INT)
		DECLARE @numeroOrden VARCHAR(50) = (SELECT numero FROM [solicitud].[Solicitud] WHERE idSolicitud=@idSolicitud)
		DECLARE @referencia VARCHAR(50) = NEWID()

		print 'INSERTAMOS MOVIMIENTOS DE ENTRADA'
		
		INSERT Inventario.inventario.Movimiento (idTipoInventario,idCategoria,idTipoMovimiento,entrada,salida,fechaMovimiento,referencia,observaciones,idUsuario)
		SELECT DISTINCT
				PP.parte,
				TP.idCategoria,
				'renta',
				0,
				PP.cantidad,
				GETDATE(),
				@referencia,
				@numeroOrden,
				@idUsuario
			FROM (
			SELECT
				SUM(p.cantidad) cantidad,	
				[Partida].[partida].[getPropiedadPartida] (P.idPartida, 'noParte', 'general') parte,
				[Partida].[partida].[getPropiedadPartida] (P.idPartida, 'Inventariable', 'general') inventariable 
			FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida] P
			JOIN solicitud.SolicitudObjetoGPSSIM SO ON SO.idSolicitud = P.idSolicitud AND SO.idTipoObjeto = P.idTipoObjeto AND SO.idObjeto = P.idObjeto
			WHERE P.idSolicitud=@idSolicitud AND SO.desinstalacion=0 AND P.idEstatusCotizacionPartida = 'APROBADA'
			GROUP BY P.idPartida) PP
		JOIN [Inventario].[tipoinventario].[TipoInventario] TP ON TP.idTipoInventario = PP.parte
		WHERE PP.inventariable = 'true'

		print 'INSERTAMOS MOVIMIENTOS DE DESINSTALACION'
		INSERT Inventario.inventario.Movimiento (idTipoInventario,idCategoria,idTipoMovimiento,entrada,salida,fechaMovimiento,referencia,observaciones,idUsuario)
		SELECT DISTINCT
				PP.parte,
				TP.idCategoria,
				'devolucion',
				PP.cantidad,
				0,
				GETDATE(),
				@referencia,
				@numeroOrden,
				@idUsuario
			FROM (
			SELECT
				SUM(p.cantidad) cantidad,	
				[Partida].[partida].[getPropiedadPartida] (P.idPartida, 'noParte', 'general') parte,
				[Partida].[partida].[getPropiedadPartida] (P.idPartida, 'Inventariable', 'general') inventariable 
			FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida] P
			JOIN solicitud.SolicitudObjetoGPSSIM SO ON SO.idSolicitud = P.idSolicitud AND SO.idTipoObjeto = P.idTipoObjeto AND SO.idObjeto = P.idObjeto
			WHERE P.idSolicitud=@idSolicitud AND SO.desinstalacion=1 AND P.idEstatusCotizacionPartida = 'APROBADA'
			GROUP BY P.idPartida) PP
		JOIN [Inventario].[tipoinventario].[TipoInventario] TP ON TP.idTipoInventario = PP.parte
		WHERE PP.inventariable = 'true'


		SET @total = (SELECT COUNT(idGPSSIM) FROM @TABLA_GPS)

		PRINT 'TOTAL DE GPS EN LA ORDES SISCO: ' + CONVERT(VARCHAR,@total)

		WHILE (@aux <= @total)
		BEGIN

		DECLARE 		
				@idTipoObjeto_ int,
				@idClase_ varchar(50),
				@rfcEmpresa_ varchar(50),
				@idCliente_ int,
				@numeroContrato_ varchar(50),
				@idObjeto_ int,
				@idGPSSIM_ int,
				@fechaAlta_ datetime,
				@idUsuario_ int,
				@idGPSSIM_valorActual int = 0,
				@fechaInstalacion_valorActual datetime,
				@desinstalacion_ int


		SELECT	
				@idTipoObjeto_		= idTipoObjeto,
				@idClase_			= idClase,
				@rfcEmpresa_		= rfcEmpresa,
				@idCliente_			= idCliente,
				@numeroContrato_	= numeroContrato,
				@idObjeto_			= idObjeto,
				@idGPSSIM_			= idGPSSIM,
				@fechaAlta_			= fechaAlta,
				@idUsuario_			= idUsuario,
				@desinstalacion_	= desinstalacion

		FROM @TABLA_GPS WHERE id = @aux


		--SELECT	
		--		@idTipoObjeto_	,
		--		@idClase_		,
		--		@rfcEmpresa_	,
		--		@idCliente_		,
		--		@numeroContrato_,
		--		@idObjeto_		,
		--		@idGPSSIM_		,
		--		@fechaAlta_		,
		--		@idUsuario_		

		DECLARE @idPropiedadClase int = 0,@idPropiedadCategoria INT = 0,@idInventarioGPS INT = 0,@valor varchar(50)

		SELECT @idPropiedadClase = idPropiedadClase 
		FROM Objeto.objeto.PropiedadClase 
		WHERE idClase = @idClase
		AND agrupador = 'ID GPS' 
		AND idPadre IS NULL

		SELECT @idPropiedadCategoria = idPropiedadCategoria 
		FROM inventario.inventario.PropiedadCategoria 
		WHERE idCategoria in ('GPS') and agrupador='DeviceID'

		SELECT @idInventarioGPS = idInventarioGPS 
		FROM inventario.inventario.GPSSIM 
		WHERE idGPSSIM = @idGPSSIM_

		SELECT @valor = valor 
		FROM inventario.inventario.InventarioPropiedadCategoria  
		WHERE idInventario = @idInventarioGPS 
		AND idPropiedadCategoria = @idPropiedadCategoria


		--INSERTAMOS EL DETALLE DE LA ORDEN DE SERVICIO CUANDO SE TRATA DE INSTALACIONES DE PARTIDAS INVENTARIABLES
		INSERT INTO @detalleSolicitud(idTipoObjeto,idObjeto,idTipoInventario,idCategoria,cantidad)
		SELECT DISTINCT
			PP.idTipoObjeto,
			PP.idObjeto,
			PP.parte,
			TP.idCategoria,
			PP.cantidad
			FROM (
			SELECT
				P.idTipoObjeto,
				P.idObjeto,
				p.cantidad,	
				[Partida].[partida].[getPropiedadPartida] (P.idPartida, 'noParte', 'general') parte,
				[Partida].[partida].[getPropiedadPartida] (P.idPartida, 'Inventariable', 'general') inventariable 
			FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida] P
			WHERE P.idSolicitud=@idSolicitud AND P.idTipoObjeto=@idTipoObjeto_ AND P.idObjeto=@idObjeto_ AND P.idEstatusCotizacionPartida = 'APROBADA') PP
		JOIN [Inventario].[tipoinventario].[TipoInventario] TP ON TP.idTipoInventario = PP.parte
		WHERE PP.inventariable = 'true' AND TP.idCategoria NOT IN(SELECT idCategoria FROM [Inventario].[tipoinventario].[Categoria] WHERE idCategoria='GPS')	
	 
			IF(@desinstalacion_ = 0)
				BEGIN
					----------------------------------------------------------------------------------------							
					------------------------- INICIO ISNTALACION -------------------------------------------
					----------------------------------------------------------------------------------------
					WHILE EXISTS  (SELECT 1 FROM @detalleSolicitud)
						BEGIN							
							SELECT TOP 1
								@v_aux=id,
								@v_idTipoInventario=idTipoInventario,
								@v_idCategoria=idCategoria,
								@v_cantidad=cantidad 
							FROM @detalleSolicitud 
							--DAR DE BAJA LA DISPONIBILIDAD DEL GPS
							UPDATE TOP (1) Inventario.inventario.inventario
							SET disponible=0
							WHERE idTipoInventario = @v_idTipoInventario AND idCategoria = @v_idCategoria AND disponible=1 

							DELETE FROM @detalleSolicitud WHERE id=@v_aux
						END

					--INSERTAMOS EL VALOR DEL GPS EN EL VEHICULO DE SISCO
					print 'Analizamos valor de GPS en SISCO: ' + convert(varchar,@idObjeto_)
					IF NOT EXISTS(SELECT valor FROM Objeto.objeto.ObjetoPropiedadClase WHERE idClase = @idClase_ AND idPropiedadClase = @idPropiedadClase AND idTipoObjeto = @idTipoObjeto_ AND idObjeto = @idObjeto_)
					BEGIN 
							print 'Insertamos GPS en SISCO'
							INSERT INTO  Objeto.objeto.ObjetoPropiedadClase VALUES
							(@idClase, @idPropiedadClase, @idTipoObjeto_, @idObjeto_, @valor, @idUsuario_, 1)
					END
					ELSE
					BEGIN
							--ACTUALIZAMOS EL VALOR DEL GPS EN EL VEHICULO DE SISCO
							print 'Actualizamos GPS en SISCO: ' + convert(varchar,@idPropiedadClase) + ' ' + @valor
							UPDATE Objeto.objeto.ObjetoPropiedadClase
							SET valor = @valor
							WHERE  idClase = @idClase 
							AND idPropiedadClase = @idPropiedadClase
							AND idTipoObjeto = @idTipoObjeto_ 
							AND idObjeto = @idObjeto_ 
					END
					--------------------------------------------
					--OBTENEMOS EL GPS ACTUAL DEL VEHICULO EN INVENTARIOS
					SELECT @idGPSSIM_valorActual = idGPSSIM, @fechaInstalacion_valorActual = fechaAlta
					FROM inventario.inventario.ObjetoGPSSIM 
					WHERE idTipoObjeto = @idTipoObjeto_
					AND idObjeto = @idObjeto_ 
					AND activo = 1
	

					print 'Validamos que la relacion GPS/VIN exista en inventarios' + convert(varchar,@idGPSSIM_)

					IF NOT EXISTS(SELECT idGPSSIM FROM inventario.inventario.ObjetoGPSSIM WHERE idTipoObjeto = @idTipoObjeto_ AND idObjeto = @idObjeto_ AND idGPSSIM = @idGPSSIM_ AND activo = 1)
						BEGIN 
								--EN CASO DE NO EXISTIR EL GPS/VEHICULO
								--1. INSERTAMOS LA RELACION
								print 'SE INSERTA LA RELACION OBJETO/GPSSIM'
								INSERT INTO inventario.inventario.ObjetoGPSSIM  VALUES
								(@rfcEmpresa_, @idCliente_, @numeroContrato_, @idClase_, @idTipoObjeto_, @idObjeto_, @idGPSSIM_, @fechaAlta_, NULL,'', 1, @idUsuario_)
								--2. MARCAMOS COMO NO DISPONIBLE EL GPS
								print 'SE AMRCA EL GPS COMO NO DISPONIBLE'
								UPDATE I
								SET disponible=0
								FROM Inventario.inventario.GPSSIM G
									JOIN Inventario.inventario.Inventario I on G.idInventarioGPS=I.idInventario
								WHERE G.idGPSSIM  = @idGPSSIM_
								--2. MARCAMOS COMO NO DISPONIBLE LA SIM
								print 'SE MARCA LA SIM COMO NO DISPONIBLE'
								UPDATE I
								SET disponible=0
								FROM Inventario.inventario.GPSSIM G
									JOIN Inventario.inventario.Inventario I on G.idInventarioSIM=I.idInventario
								WHERE G.idGPSSIM  = @idGPSSIM_

						END

					
					IF(@fechaInstalacion_valorActual <> @fechaAlta_)
					BEGIN
						
						UPDATE inventario.inventario.ObjetoGPSSIM
						SET fechaAlta = @fechaAlta_	
						WHERE idTipoObjeto = @idTipoObjeto_
					    AND idObjeto = @idObjeto_
						AND idGPSSIM = @idGPSSIM_valorActual

						UPDATE I
						SET disponible=0
						FROM Inventario.inventario.GPSSIM G
							JOIN Inventario.inventario.Inventario I on G.idInventarioGPS=I.idInventario
						WHERE G.idGPSSIM  = @idGPSSIM_valorActual

						UPDATE I
						SET disponible=0
						FROM Inventario.inventario.GPSSIM G
							JOIN Inventario.inventario.Inventario I on G.idInventarioSIM=I.idInventario
						WHERE G.idGPSSIM  = @idGPSSIM_valorActual

					END
	
					IF(@idGPSSIM_valorActual <> 0)
					BEGIN
		
						IF(@idGPSSIM_ <> @idGPSSIM_valorActual)
							BEGIN

								UPDATE inventario.inventario.ObjetoGPSSIM
								SET fechaBaja = GETDATE(),
									activo = 0
								WHERE idTipoObjeto = @idTipoObjeto_
								AND idObjeto = @idObjeto_
								AND idGPSSIM = @idGPSSIM_valorActual

								UPDATE I
								SET disponible=1
								FROM Inventario.inventario.GPSSIM G
									JOIN Inventario.inventario.Inventario I on G.idInventarioGPS=I.idInventario
								WHERE G.idGPSSIM  = @idGPSSIM_valorActual

								UPDATE I
								SET disponible=1
								FROM Inventario.inventario.GPSSIM G
									JOIN Inventario.inventario.Inventario I on G.idInventarioSIM=I.idInventario
								WHERE G.idGPSSIM  = @idGPSSIM_valorActual


							END

					END

						--============================================ INICIO AVL ===========================================================
							-- Inicio Integridad
							IF NOT EXISTS(SELECT idObjeto FROM avl.integridad.Objeto WHERE idTipoObjeto = @idTipoObjeto_ AND idObjeto = @idObjeto_ )
							BEGIN 
									INSERT INTO avl.integridad.Objeto  VALUES
									(@rfcEmpresa_, @idCliente_, @numeroContrato_, @idClase_, @idTipoObjeto_, @idObjeto_,'' ,'' )
							END
							-- Fin Integridad

							-- Inicio Traker
							DECLARE @id_t1 INT = 0,@id_t2 INT = 0,@lastUpdate_1 DATETIME  ,@lastUpdate_2 DATETIME,@id_devices int = 0 

							SELECT @id_t1 = id ,  @lastUpdate_1 = lastUpdate from [TRACKER].Tracker_Socket1.dbo.tc_devices where uniqueid  = @valor
							SELECT @id_t2 = id ,  @lastUpdate_2 = lastUpdate from [TRACKER].Tracker_Socket2.dbo.tc_devices where uniqueid = @valor

							-- si existe registro de fechas en ambas tablas toma el id de la ultmia fecha
							IF(@lastUpdate_1 IS NOT NULL AND @lastUpdate_2 IS NOT NULL)
							BEGIN		
								IF(@lastUpdate_1 > @lastUpdate_2)
								BEGIN
									set @id_devices = @id_t1
								END
								else
								BEGIN 
									set @id_devices = @id_t2
								END
							END
							ELSE
							BEGIN
							-- de lo contrario se revisa quien si tiene id y fecha para tomar su registro, en caso que no exista fecha en alguno pero si tenga registro no se inserta
									IF(@id_t1 > 0)
									BEGIN						
											IF(@lastUpdate_1 IS NOT NULL)
											BEGIN		
													set @id_devices = @id_t1	
											END
											ELSE
											BEGIN
													set @id_devices = 0		
											END							
									END
			
									IF ( @id_t2 > 0 AND @id_devices = 0)
									BEGIN 	
											IF(@lastUpdate_2 IS NOT NULL)
											BEGIN		
													set @id_devices = @id_t2										
											END
											ELSE
											BEGIN
													set @id_devices = 0		
											END
									END
							END

							IF(@id_devices > 0)
							BEGIN	
								PRINT 'Error 0'
								DECLARE @deviceid_valorActual int = 0,@uniqueid_valorActual nvarchar(10) = ''
								
								SELECT 
										@deviceid_valorActual = deviceid,
										@uniqueid_valorActual = uniqueid								
								FROM avl.vehiculo.ObjetoDispositivo 
								WHERE idObjeto = @idObjeto_ 
								AND rfcEmpresa = @rfcEmpresa_
								AND idCliente = @idCliente_
								AND numeroContrato = @numeroContrato_
								AND idClase = @idClase_
								AND idTipoObjeto = @idTipoObjeto_
								AND activo = 1
								PRINT 'Error 1'
								-- si no existe el ojeto con el id y unique lo inserto
								IF NOT EXISTS(SELECT 1 FROM avl.vehiculo.ObjetoDispositivo 
											  WHERE rfcEmpresa = @rfcEmpresa_
											  AND idCliente = @idCliente_
											  AND numeroContrato = @numeroContrato_
											  AND idClase = @idClase_
											  AND idTipoObjeto = @idTipoObjeto_
											  AND idObjeto = @idObjeto_
											  AND deviceid = @id_devices
											  AND uniqueid = @valor
											  AND activo = 1)
									BEGIN 
									PRINT 'Error 2'
										IF EXISTS(SELECT 1 FROM avl.vehiculo.ObjetoDispositivo 
											WHERE rfcEmpresa = @rfcEmpresa_
											AND idCliente = @idCliente_
											AND numeroContrato = @numeroContrato_
											AND idClase = @idClase_
											AND idTipoObjeto = @idTipoObjeto_
											AND idObjeto = @idObjeto_
											AND deviceid = @id_devices
											AND uniqueid = @valor
											AND activo = 0)
												BEGIN
											  		UPDATE avl.vehiculo.ObjetoDispositivo 
													SET activo=1, fecha=GETDATE()
													WHERE idObjeto = @idObjeto_
														AND deviceid = @id_devices
														AND uniqueid = @valor
														AND rfcEmpresa = @rfcEmpresa_
														AND idCliente = @idCliente_
														AND numeroContrato = @numeroContrato_
														AND idClase = @idClase_
														AND idTipoObjeto = @idTipoObjeto_
														AND activo = 0
												END
											ELSE
												BEGIN
													INSERT INTO avl.vehiculo.ObjetoDispositivo
													SELECT @rfcEmpresa_, @idCliente_, @numeroContrato_, @idClase_, @idTipoObjeto_, @idObjeto_, @id_devices, @valor, @fechaAlta_, 1
												END

									END
									PRINT 'Error 3'
								
								-- si ya existia un registro para ese objeto 
								IF(@deviceid_valorActual <> 0)
								BEGIN	
								-- pregunto si es diferente el id en tabla vs el id que me regreso la ultmia consulta
									IF(@id_devices <> @deviceid_valorActual OR @valor <> @uniqueid_valorActual)
										BEGIN

											UPDATE avl.vehiculo.ObjetoDispositivo
											SET activo = 0								 
											WHERE idTipoObjeto = @idTipoObjeto_
											AND idObjeto = @idObjeto_
											AND uniqueid != @valor
											AND deviceid != @id_devices
											
										END
								END		
							END		

							/****************************************************************************************************************/
							-- si no existe el ojeto con el id y unique lo inserto
							;WITH detalleInsert (rfcEmpresa,idCliente,numeroContrato,idClase,idTipoObjeto,idObjeto,parte,idCategoria)
							AS  
							(  
								SELECT DISTINCT
									PP.rfcEmpresa,
									PP.idCliente,
									PP.numeroContrato,
									PP.idClase,
									PP.idTipoObjeto,
									PP.idObjeto,
									PP.parte,
									TP.idCategoria FROM (
									SELECT
										P.rfcEmpresa,
										P.idCliente,
										P.numeroContrato,
										P.idClase,
										P.idTipoObjeto,
										P.idObjeto,
										[Partida].[partida].[getPropiedadPartida] (P.idPartida, 'noParte', 'general') parte,
										[Partida].[partida].[getPropiedadPartida] (P.idPartida, 'Inventariable', 'general') inventariable 
									FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida] P
									WHERE P.idSolicitud=@idSolicitud AND P.idTipoObjeto=@idTipoObjeto_ AND P.idObjeto=@idObjeto_ AND P.idEstatusCotizacionPartida = 'APROBADA') PP
								--JOIN [Inventario].[tipoinventario].[TipoInventario] TP ON TP.idTipoInventario = PP.parte
								JOIN [AVL].[integridad].[TipoInventario] TP ON TP.idTipoInventario = PP.parte
								WHERE PP.inventariable = 'true' AND TP.idCategoria IN(SELECT idCategoria FROM [Inventario].[tipoinventario].[Categoria] WHERE idCategoria='ACCESORIO')
							)
							MERGE avl.vehiculo.ObjetoDispositivoTipoInventario AS TARGET
							USING (SELECT rfcEmpresa,idCliente,numeroContrato,idClase,idTipoObjeto,idObjeto,parte,idCategoria FROM detalleInsert) AS SOURCE (rfcEmpresa,idCliente,numeroContrato,idClase,idTipoObjeto,idObjeto,parte,idCategoria)
							ON (TARGET.rfcEmpresa = SOURCE.rfcEmpresa AND TARGET.idCliente = SOURCE.idCliente AND TARGET.numeroContrato = SOURCE.numeroContrato AND TARGET.idClase = SOURCE.idClase AND TARGET.idTipoObjeto = SOURCE.idTipoObjeto AND TARGET.idObjeto = SOURCE.idObjeto AND TARGET.idTipoInventario = SOURCE.parte AND TARGET.activo=1)
							WHEN MATCHED THEN
								UPDATE SET 
									activo = 1
							WHEN NOT MATCHED THEN
								INSERT (rfcEmpresa,idCliente,numeroContrato,idClase,idTipoObjeto,idObjeto,idTipoInventario,idCategoria,activo,deviceid,uniqueid)
								VALUES (rfcEmpresa,idCliente,numeroContrato,idClase,idTipoObjeto,idObjeto,parte,idCategoria,1,@id_devices,@valor);
							-- Fin Traker
						--============================================ FIN AVL ===========================================================

						----------------------------------------------------------------------------------------							
						-------------------------- FINAL ISNTALACION -------------------------------------------
						----------------------------------------------------------------------------------------
				END
			ELSE IF(@desinstalacion_ = 1)
				BEGIN
					----------------------------------------------------------------------------------------							
					-------------------------- INICIO DESISNTALACION ---------------------------------------
					----------------------------------------------------------------------------------------
						INSERT INTO @detalleDesinstalar(idTipoObjeto,idObjeto,idTipoInventario,idCategoria)
						SELECT idTipoObjeto,idObjeto,idTipoInventario,idCategoria 
						FROM [AVL].[vehiculo].[ObjetoDispositivoTipoInventario] 
						WHERE idTipoObjeto = @idTipoObjeto_  AND idObjeto = @idObjeto_	
						
							WHILE EXISTS  (SELECT 1 FROM @detalleDesinstalar)
								BEGIN							
									SELECT TOP 1
										@v_aux=id,
										@v_idTipoInventario=idTipoInventario,
										@v_idCategoria=idCategoria
									FROM @detalleDesinstalar 

									UPDATE TOP (1) Inventario.inventario.inventario
									SET disponible=1
									WHERE idTipoInventario = @v_idTipoInventario AND idCategoria = @v_idCategoria AND disponible=0

									DELETE FROM @detalleDesinstalar WHERE id=@v_aux
								END

							DELETE FROM [AVL].[vehiculo].[ObjetoDispositivoTipoInventario]
							WHERE idTipoObjeto = @idTipoObjeto_ AND idObjeto = @idObjeto_

							UPDATE I
							SET disponible=1
							FROM Inventario.inventario.GPSSIM G
								JOIN Inventario.inventario.Inventario I on G.idInventarioGPS=I.idInventario
							WHERE G.idGPSSIM IN(SELECT idGPSSIM FROM inventario.inventario.ObjetoGPSSIM WHERE idTipoObjeto = @idTipoObjeto_ AND idObjeto = @idObjeto_ AND activo = 1)

							UPDATE I
							SET disponible=1
							FROM Inventario.inventario.GPSSIM G
								JOIN Inventario.inventario.Inventario I on G.idInventarioSIM=I.idInventario
							WHERE G.idGPSSIM IN(SELECT idGPSSIM FROM inventario.inventario.ObjetoGPSSIM WHERE idTipoObjeto = @idTipoObjeto_ AND idObjeto = @idObjeto_ AND activo = 1)

							UPDATE Objeto.objeto.ObjetoPropiedadClase
							SET valor = ''
							WHERE  idClase = @idClase 
							AND idPropiedadClase = @idPropiedadClase
							AND idTipoObjeto = @idTipoObjeto_ 
							AND idObjeto = @idObjeto_ 

							UPDATE inventario.inventario.ObjetoGPSSIM
							SET fechaBaja = GETDATE(),
							activo = 0
							WHERE idTipoObjeto = @idTipoObjeto_ 
							AND idObjeto = @idObjeto_
							AND activo = 1

							UPDATE avl.vehiculo.ObjetoDispositivo
							SET activo = 0
							WHERE idTipoObjeto = @idTipoObjeto_ 
							AND idObjeto = @idObjeto_
							AND activo = 1		
					----------------------------------------------------------------------------------------							
					-------------------------- FINAL DESISNTALACION ----------------------------------------
					----------------------------------------------------------------------------------------
				END

		SET @aux = @aux + 1

		END

			
	
	SELECT 1 AS exito
		
	END TRY
	BEGIN CATCH
				SELECT
				0 as exito,
				ERROR_NUMBER() AS ErrorNumber,
				ERROR_STATE() AS ErrorState,
				ERROR_SEVERITY() AS ErrorSeverity,
				ERROR_PROCEDURE() AS ErrorProcedure,
				ERROR_LINE() AS ErrorLine,
				ERROR_MESSAGE() AS ErrorMessage;
	END CATCH;
END

--USE [Solicitud]
go

