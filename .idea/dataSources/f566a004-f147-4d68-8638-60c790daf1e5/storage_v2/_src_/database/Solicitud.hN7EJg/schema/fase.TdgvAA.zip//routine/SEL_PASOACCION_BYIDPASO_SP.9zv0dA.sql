
-- =============================================  
-- Author: Alan Rosales Chávez  
-- Create date: 18-06-2019  
-- Description: Consulta de acciones dependiendo el paso seleccionado  
-- ============== Versionamiento ================  
/*  
 Fecha			Autor			Descripción   
 16/04/2020		JLuis Lozada	Se agrego el campo activo a las tablas fase.PasoAccion y faseContrato.PasoAccion y se agregaron reglas para no mostrar ciertos botones cuando la orden ya esta provisionada
 01/10/2020		JLuis Lozada	Se agrego el parametro @esMultiple y se condiciono en los querys
 *- Testing...  
 DECLARE @salida varchar(max) ='' ;  
 EXEC [fase].[SEL_PASOACCION_BYIDPASO_SP]  @idSolicitud=1310, @idTipoSolicitud='Imagen', @idClase='Automovil', @rfcEmpresa='ASE0508051B6', 
			@idCliente=185, @numeroContrato='43', @idUsuario=6334, @idAplicacion=11,@esMultiple=0, @err=@salida
 SELECT @salida AS salida;    
*/  
CREATE PROCEDURE [fase].[SEL_PASOACCION_BYIDPASO_SP]  
 @idSolicitud			INT,
 @idTipoSolicitud		VARCHAR(10),  
 @idClase				VARCHAR(10),  
 @rfcEmpresa			VARCHAR(13),
 @idCliente				INT,
 @numeroContrato		VARCHAR(50), 
 @esMultiple			BIT=0,
 @idUsuario				INT = null,  
 @idAplicacion			INT = 9,
 @err					VARCHAR(500)OUTPUT  
AS  
BEGIN  

	declare @txTabla TABLE(	[Fase] [varchar](20) NOT NULL,
							[FaseNombre] [varchar](250) NULL,
							[FaseOrden] [int] NULL,
							[TipoSolicitud] [varchar](10) NOT NULL,
							[Paso] [varchar](50) NOT NULL,
							[PasoNombre] [nvarchar](250) NOT NULL,
							[PasoOrden] [int] NOT NULL,
							[AccionCaption] [varchar](max) NULL,
							[AccionFuncionComponente] [varchar](250) NULL,
							[AccionTipoAccion] [varchar](20) NOT NULL,
							[AccionParametro] [varchar](max) NOT NULL)

	DECLARE @idPasoActual	VARCHAR(50),
			@tipoPaso		VARCHAR(10)
	SELECT 	@idPasoActual = aux.idPaso,
			@tipoPaso = aux.tipoPaso
	FROM	[solicitud].SEL_PASO_SOLICITUD_FN(@idSolicitud) aux
	
	DECLARE @cargaInventario INT
	DECLARE @totalInventario INT
	DECLARE @contratoUtilidad DECIMAL(18,2)
	DECLARE @utilidad DECIMAL(18,2)

	;WITH cte_utilidad AS (
		SELECT 
				(CASE WHEN C.manejoDeUtilidad = 1 THEN C.porcentajeUtilidad ELSE -1 END) contratoUtilidad,
				(CASE WHEN COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) = 0 
					THEN 0 
				ELSE CAST( ((COALESCE(SUM(VW.subTotalVenta), 0) - COALESCE(SUM(VW.subTotalCosto), 0)) / COALESCE(SUM(vw.subTotalVentaSinDescuento), 0)) * 100 AS DECIMAL(18,2)) END) utilidad
		FROM	[solicitud].[solicitud].[SEL_TOTALES_COTIZACION_VW] VW
		LEFT	JOIN [cliente].[contrato].[ProveedorUtilidad] PU ON PU.rfcEmpresa = VW.rfcEmpresa AND PU.idCliente = VW.idCliente AND PU.numeroContrato = VW.numeroContrato AND PU.rfcProveedor = VW.rfcProveedor AND PU.idProveedorEntidad = VW.idProveedorEntidad
		JOIN	[Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = VW.rfcEmpresa AND C.numeroContrato = VW.numeroContrato AND C.idCliente = VW.idCliente AND C.idClase = VW.idClase
		WHERE	VW.idSolicitud = @idSolicitud 
		AND		PU.idProveedorEntidad IS NULL
		GROUP BY C.porcentajeUtilidad,C.manejoDeUtilidad
	)

	SELECT @contratoUtilidad=contratoUtilidad, @utilidad=utilidad 
	FROM(	SELECT contratoUtilidad, utilidad 
			FROM cte_utilidad
			UNION
			SELECT 0,0
			WHERE NOT EXISTS (select 1 from cte_utilidad)
		)utilidad

	IF (@tipoPaso='PASO')
		BEGIN
			INSERT INTO @txTabla(Fase,FaseNombre,FaseOrden,TipoSolicitud,Paso,PasoNombre,PasoOrden,AccionCaption,AccionFuncionComponente,AccionTipoAccion,AccionParametro)		
			SELECT	f.idFase			Fase,  
					f.nombre			FaseNombre,
					f.orden				FaseOrden,  
					p.idTipoSolicitud	TipoSolicitud,
					p.idPaso			Paso,
					p.nombre			PasoNombre,
					p.orden				PasoOrden,
					pa.caption			AccionCaption,
					pa.funcionComponente AccionFuncionComponente,
					pa.idTipoAccion		AccionTipoAccion,
					pa.parametro		AccionParametro
			FROM	fase.fase f  
			INNER	JOIN fase.Paso p				ON f.idFase = p.idFase  
			INNER	JOIN solicitud.TipoSolicitud ts ON ts.idClase = p.idClase AND ts.idTipoSolicitud = p.idTipoSolicitud  
			INNER	JOIN fase.PasoAccion pa			ON p.idPaso = pa.idPaso AND	p.idClase = pa.idClase AND p.idTipoSolicitud = pa.idTipoSolicitud  
		    WHERE	p.idClase			= @idClase 
			AND  	p.idPaso			= @idPasoActual 
			AND		p.idTipoSolicitud	= @idTipoSolicitud
			AND     pa.esMultiple		= @esMultiple
			AND     pa.activo			=1
			AND		pa.idPasoAccion		IN (SELECT	DISTINCT idPasoAccion 
											FROM	Solicitud.Solicitud.Rol_PasoAccion 
											WHERE	idRol in (	SELECT	RolId 
																FROM	Seguridad.Relacion.Usser_Rol 
																WHERE	UsersId = @idUsuario 
																AND		AplicacionesId = @idAplicacion))
			ORDER BY f.orden, p.orden, pa.caption  

			--INGRESO INVENTARIO FACTURA SI COSTO ES 0 NO CARGO FACTURA
			/* Compra GPS Muestra el boton de Procesar Compra siempre y cuando se cargue las facturas y el inventario 100%*/	
			IF EXISTS(SELECT 1 FROM [solicitud].[TipoSolicitud] WHERE idTipoSolicitud=@idTipoSolicitud AND esIngreso=1)
				BEGIN
					IF EXISTS(SELECT 1 FROM [solicitud].[SEL_TOTALES_SOLICITUD_VW] WHERE idSolicitud=@idSolicitud AND subTotalCosto > 0)
						BEGIN
							IF EXISTS(SELECT 1 FROM [solicitud].[SolicitudCotizacion] SC
								LEFT JOIN [cxp].[SolicitudCotizacionFactura] SCF ON SCF.idSolicitud = SC.idSolicitud AND SCF.idCotizacion = SC.idCotizacion
								WHERE SC.idEstatusCotizacion != 'RECHAZADA' AND SC.idEstatusCotizacion != 'CANCELADA' AND SC.idSolicitud=@idSolicitud AND SC.idTipoSolicitud=@idTipoSolicitud
									AND SC.idClase=@idClase AND SC.rfcEmpresa=@rfcEmpresa
									AND SC.idCliente=@idCliente
									AND SC.numeroContrato=@numeroContrato
									AND SCF.idCotizacion IS NULL)
								BEGIN
									DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN('Procesar compra')
								END
						END
					SET @cargaInventario = (SELECT COUNT(1) FROM [Solicitud].[solicitud].[SolicitudPropiedadInventarioGeneral] SPIG
					JOIN [solicitud].[PropiedadInventarioGeneral] PIG ON PIG.idPropiedadInventarioGeneral = SPIG.idPropiedadInventarioGeneral
					WHERE PIG.valor = 'NoParte' AND SPIG.idSolicitud=@idSolicitud AND SPIG.idTipoSolicitud=@idTipoSolicitud AND SPIG.idClase=@idClase 
					AND SPIG.rfcEmpresa=@rfcEmpresa AND SPIG.idCliente=@idCliente AND SPIG.numeroContrato=@numeroContrato)
					SET @totalInventario = (SELECT SUM(cantidad) FROM Solicitud.solicitud.SolicitudcotizacionPartida SCP 
					WHERE SCP.idEstatusCotizacionPartida != 'RECHAZADA' AND SCP.idEstatusCotizacionPartida != 'CANCELADA' AND SCP.idSolicitud=@idSolicitud 
					AND SCP.idTipoSolicitud=@idTipoSolicitud AND SCP.idClase=@idClase AND SCP.rfcEmpresa=@rfcEmpresa AND SCP.idCliente=@idCliente AND SCP.numeroContrato=@numeroContrato)
					IF(@cargaInventario < @totalInventario)
						BEGIN
							DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN('Procesar compra')
						END
				END
			/* Muestra el boton de enviar a aprobacion siempre y cuando exista una cotización*/			
			IF EXISTS(SELECT 1 FROM Solicitud.SolicitudCotizacion
			 WHERE idSolicitud=@idSolicitud
				AND idTipoSolicitud=@idTipoSolicitud
				AND idClase=@idClase
				AND rfcEmpresa=@rfcEmpresa
				AND idCliente=@idCliente
				AND numeroContrato=@numeroContrato)
				BEGIN
					IF(@idPasoActual='EstudioMercado')
						BEGIN
							DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN('Nueva cotización')
						END
				END
			ELSE
				BEGIN
					IF(@idPasoActual='EstudioMercado')
						BEGIN
							DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN('Enviar a aprobación') 
						END
				END
			/* Muestra los botones en aprobacion unicamente cuando tenga la aprobacion realizada*/
			IF EXISTS(	SELECT 1 FROM compraBPRO.Solicitud
						WHERE	idSolicitud			=@idSolicitud
						AND		idTipoSolicitud		=@idTipoSolicitud
						AND		idClase				=@idClase
						AND		rfcEmpresa			=@rfcEmpresa
						AND		idCliente			=@idCliente
						AND		numeroContrato		=@numeroContrato
						AND		aprobacionCompra	IS NULL )
				BEGIN
					IF(@idPasoActual='Aprobacion')
						BEGIN
							DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN ('Genera orden de compra','Cancelar solicitud','Plan de acción')
						END
				END
			
			/* Cargar factura y Procesar compra
			1.- Utilidad por Contrato
			2.- Si es menor al minimo 
			3.- No existe el token de utilidad  */
			IF(@contratoUtilidad >= 1)
				BEGIN
					IF(@utilidad < @contratoUtilidad)
						BEGIN
							IF EXISTS(	SELECT	1 
										FROM	[Solicitud].[token].[Token] TT
										INNER	JOIN [Solicitud].[token].[TokenSolicitud] TTS ON TT.idToken = TTS.idToken 
										AND		TT.idUsuarioUsa IS NOT NULL
										WHERE	TTS.idSolicitud = @idSolicitud
										AND		TT.idTipoToken	= 3)
								BEGIN
									DELETE FROM @txTabla WHERE AccionCaption IN ('Token de utilidad')
								END
						END
					ELSE
						BEGIN
							DELETE FROM @txTabla WHERE AccionCaption IN ('Token de utilidad')
						END 
				END
			ELSE
				BEGIN
					DELETE FROM @txTabla WHERE AccionCaption IN ('Token de utilidad')
				END
			/* Accion de notificacion solo se mostrara siempre y cuando no exista previemente realizada */ 
			IF EXISTS(SELECT 1 FROM [Solicitud].[solicitud].[NotificacionEntrega] 
						WHERE   idSolicitud		=@idSolicitud 
						AND		idTipoSolicitud	=@idTipoSolicitud 
						AND		idClase			=@idClase 
						AND		rfcEmpresa		=@rfcEmpresa 
						AND		idCliente		=@idCliente 
						AND		numeroContrato	=@numeroContrato)
			BEGIN
				DELETE FROM @txTabla WHERE AccionCaption IN ('Notificar entrega')
			END

			IF EXISTS(	SELECT	1 FROM cxc.Factura 
						WHERE	idSolicitud		=@idSolicitud 
						AND		idTipoSolicitud	=@idTipoSolicitud 
						AND		idClase			=@idClase 
						AND		rfcEmpresa		=@rfcEmpresa 
						AND		idCliente		=@idCliente 
						AND		numeroContrato	=@numeroContrato)
				SELECT * FROM @txTabla WHERE AccionCaption NOT IN ('Cargar factura','Nueva cotización','Procesar compra','Editar cotización','Cancelar solicitud','Token de utilidad') ORDER BY FaseOrden, PasoOrden, AccionCaption   
			ELSE
				SELECT * FROM @txTabla ORDER BY FaseOrden, PasoOrden, AccionCaption   

		END


	IF (@tipoPaso='CONTRATO')
		BEGIN
			INSERT INTO @txTabla(Fase,FaseNombre,FaseOrden,TipoSolicitud,Paso,PasoNombre,PasoOrden,AccionCaption,AccionFuncionComponente,AccionTipoAccion,AccionParametro)		
			SELECT	f.idFase				Fase,  
					f.nombre				FaseNombre,  
					f.orden					FaseOrden,  
					p.idTipoSolicitud		TipoSolicitud,  
					p.idPaso				Paso,  
					p.nombre				PasoNombre,  
					p.orden					PasoOrden,  
					pa.caption				AccionCaption,  
					pa.funcionComponente	AccionFuncionComponente,  
					pa.idTipoAccion			AccionTipoAccion,  
					pa.parametro			AccionParametro  
			FROM	fase.fase f  
			INNER	JOIN faseContrato.Paso p		ON f.idFase = p.idFase  
			INNER	JOIN solicitud.TipoSolicitud ts ON ts.idClase = p.idClase and ts.idTipoSolicitud  = p.idTipoSolicitud  
			INNER	JOIN faseContrato.PasoAccion pa ON p.idPaso = pa.idPaso and p.idClase   = pa.idClase and p.idTipoSolicitud = pa.idTipoSolicitud  
			WHERE	p.idClase			= @idClase 
			AND  	p.idPaso			= @idPasoActual 
			AND		p.idTipoSolicitud	= @idTipoSolicitud 
			AND     pa.esMultiple		= @esMultiple
			AND     pa.activo			=1
			ORDER BY f.orden, p.orden, pa.caption  

			/* Compra GPS Muestra el boton de Procesar Compra siempre y cuando se cargue las facturas y el inventario 100%*/	
			IF(@idTipoSolicitud = 'CompraGPS')
				BEGIN
					IF EXISTS(SELECT 1 FROM [solicitud].[SolicitudCotizacion] SC
						LEFT JOIN [cxp].[SolicitudCotizacionFactura] SCF ON SCF.idSolicitud = SC.idSolicitud AND SCF.idCotizacion = SC.idCotizacion
						WHERE SC.idEstatusCotizacion != 'RECHAZADA' AND SC.idEstatusCotizacion != 'CANCELADA' AND SC.idSolicitud=@idSolicitud AND SC.idTipoSolicitud=@idTipoSolicitud
							AND SC.idClase=@idClase AND SC.rfcEmpresa=@rfcEmpresa
							AND SC.idCliente=@idCliente
							AND SC.numeroContrato=@numeroContrato
							AND SCF.idCotizacion IS NULL)
						BEGIN
							DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN('Procesar compra')
						END

					SET @cargaInventario = (SELECT COUNT(1) FROM [Solicitud].[solicitud].[SolicitudPropiedadInventarioGeneral] SPIG
					JOIN [solicitud].[PropiedadInventarioGeneral] PIG ON PIG.idPropiedadInventarioGeneral = SPIG.idPropiedadInventarioGeneral
					WHERE PIG.valor = 'NoParte' AND SPIG.idSolicitud=@idSolicitud AND SPIG.idTipoSolicitud=@idTipoSolicitud AND SPIG.idClase=@idClase 
					AND SPIG.rfcEmpresa=@rfcEmpresa AND SPIG.idCliente=@idCliente AND SPIG.numeroContrato=@numeroContrato)
					SET @totalInventario = (SELECT SUM(cantidad) FROM Solicitud.solicitud.SolicitudcotizacionPartida SCP 
					WHERE SCP.idEstatusCotizacionPartida != 'RECHAZADA' AND SCP.idEstatusCotizacionPartida != 'CANCELADA' AND SCP.idSolicitud=@idSolicitud 
					AND SCP.idTipoSolicitud=@idTipoSolicitud AND SCP.idClase=@idClase AND SCP.rfcEmpresa=@rfcEmpresa AND SCP.idCliente=@idCliente AND SCP.numeroContrato=@numeroContrato)
					IF(@cargaInventario < @totalInventario)
						BEGIN
							DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN('Procesar compra')
						END
				END
			/* Muestra el boton de enviar a aprobacion siempre y cuando exista una cotización*/
			IF EXISTS(	SELECT 1 
						FROM	Solicitud.SolicitudCotizacion
						WHERE	idSolicitud		=@idSolicitud
						AND		idTipoSolicitud	=@idTipoSolicitud
						AND		idClase			=@idClase
						AND		rfcEmpresa		=@rfcEmpresa
						AND		idCliente		=@idCliente
						AND		numeroContrato	=@numeroContrato)
				BEGIN
					IF(@idPasoActual='EstudioMercado')
						BEGIN
							DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN('Nueva cotización')		
						END
				END
			ELSE
				BEGIN
					IF(@idPasoActual='EstudioMercado')
						BEGIN
							 DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN('Enviar a aprobación') 
						END
				END
			/* Muestra los botones en aprobacion unicamente tenga la aprobacion realizada*/
			IF EXISTS(	SELECT	1 
						FROM	compraBPRO.Solicitud
						WHERE	idSolicitud			=@idSolicitud
						AND		idTipoSolicitud		=@idTipoSolicitud
						AND		idClase				=@idClase
						AND		rfcEmpresa			=@rfcEmpresa
						AND		idCliente			=@idCliente
						AND		numeroContrato		=@numeroContrato
						AND		aprobacionCompra	IS NULL )
				BEGIN
					IF(@idPasoActual='Aprobacion')
						BEGIN
							DELETE FROM @txTabla WHERE Paso = @idPasoActual AND AccionCaption IN ('Genera orden de compra','Cancelar solicitud','Plan de acción')
						END
				END
			/* Cargar factura y Procesar compra
			1.- Utilidad por Contrato
			2.- Si es menor al minimo 
			3.- No existe el token de utilidad  */
			IF(@contratoUtilidad >= 1)
				BEGIN
					IF(@utilidad < @contratoUtilidad)
						BEGIN
							IF EXISTS(	SELECT 1 
										FROM	[Solicitud].[token].[Token] TT
										INNER	JOIN [Solicitud].[token].[TokenSolicitud] TTS ON TT.idToken = TTS.idToken AND TT.idUsuarioUsa IS NOT NULL
										WHERE	TTS.idSolicitud = @idSolicitud
										AND		TT.idTipoToken = 3)
								BEGIN
									DELETE FROM @txTabla WHERE AccionCaption IN ('Token de utilidad')
								END
						END
					ELSE
						BEGIN
							DELETE FROM @txTabla WHERE AccionCaption IN ('Token de utilidad')
						END 
				END
			ELSE
				BEGIN
					DELETE FROM @txTabla WHERE AccionCaption IN ('Token de utilidad')
				END
			/* Accion de notificacion solo se mostrara siempre y cuando no exista previemente realizada */ 
			IF EXISTS(SELECT 1 FROM [Solicitud].[solicitud].[NotificacionEntrega] 
						WHERE   idSolicitud		=@idSolicitud 
						AND		idTipoSolicitud	=@idTipoSolicitud 
						AND		idClase			=@idClase 
						AND		rfcEmpresa		=@rfcEmpresa 
						AND		idCliente		=@idCliente 
						AND		numeroContrato	=@numeroContrato)
			BEGIN
				DELETE FROM @txTabla WHERE AccionCaption IN ('Notificar entrega')
			END

			IF EXISTS(	SELECT	1 FROM cxc.Factura 
						WHERE	idSolicitud		=@idSolicitud 
						AND		idTipoSolicitud	=@idTipoSolicitud 
						AND		idClase			=@idClase 
						AND		rfcEmpresa		=@rfcEmpresa 
						AND		idCliente		=@idCliente 
						AND		numeroContrato	=@numeroContrato)
				SELECT * FROM @txTabla WHERE AccionCaption NOT IN ('Cargar factura','Nueva cotización','Procesar compra','Editar cotización','Cancelar solicitud','Token de utilidad') ORDER BY FaseOrden, PasoOrden, AccionCaption   
			ELSE
				SELECT * FROM @txTabla ORDER BY FaseOrden, PasoOrden, AccionCaption   

		END  
END
go

