
-- =============================================
-- Author:		Andres Farias
-- Create date: 24/07/2019
-- Description:	Inserta los datos de la prefactura
-- ============== Versionamiento ================  
/* 
	Fecha			Autor		Descripción   
	18/04/2020		JLLOZADA	Se modificaron los querys que hacen operaciones a tablas de bpro, se hicieron dinamicos recuperando configuracion de common.configuracion.FacturacionBPRO en funcion al contrato de la orden
	25/06/2020		JLLOZADA	Se agrego el dato numero de copade en la salida del SP, usado en el front

	DECLARE @err VARCHAR(8000)=''
	EXEC cxc.[INS_FACTURAAGRUPADA_MANUAL_SP] 'Automovil','ASE0508051B6',185,'43','21/07/2019 08:24:27','23/07/2019 9:24:27',NULL,NULL,0,0,'xml'
	,399,6110
	,1002,'Imagen', ''

*/
-- =============================================
CREATE PROCEDURE [cxc].[INS_FACTURAAGRUPADA_MANUAL_SP]
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@fechaCarga         DATETIME,
@fechaRecepcion     DATETIME,
@numeroCopade       VARCHAR(max) = NULL,
@numeroEstimacion   VARCHAR(max) = NULL,
@subtotal		    FLOAT,
@total				FLOAT,
@xml				VARCHAR(MAX) = NULL,
@idFactura          int,
@idUsuario			INT,
@idSolicitud        int,
@idTipoSolicitud VARCHAR(MAX),
@err				VARCHAR(8000) = '' OUTPUT	
AS
BEGIN
	BEGIN TRY  
		DECLARE @contOrden INT = 1, @v_instancia NVARCHAR(max),@v_nombreBD NVARCHAR(max),@v_sq NVARCHAR(MAX)=''
		
		--BEGIN TRANSACTION
		IF NOT EXISTS(SELECT 1 FROM cxc.FacturaAgrupada FA WHERE FA.idFactura = @idFactura)
			BEGIN
				SELECT  @v_instancia=instancia,@v_nombreBD=nombreBD 
				FROM	common.configuracion.FacturacionBPRO fac 
				INNER	JOIN cliente.cliente.contrato co ON  fac.idFacturacionBPRO=co.idFacturacionBPRO 
				WHERE	co.rfcEmpresa		=@rfcEmpresa
				AND		co.idCliente		=@idCliente
				AND		co.numeroContrato	=@numeroContrato
				AND		fac.activo			=1 

				IF LEN(@v_instancia)>0 AND LEN(@v_nombreBD)>0 
					BEGIN
					print 1
						IF (@numeroEstimacion IS NULL) SET @numeroEstimacion = solicitud.SEL_NUMERO_AGRUPADORFACTURA_FN(@rfcEmpresa, @idClase,@idCliente,@numeroContrato)
		print 2
						IF (@numeroCopade IS NULL) SET @numeroCopade = solicitud.SEL_NUMERO_AGRUPADORFACTURA_FN(@rfcEmpresa, @idClase,@idCliente,@numeroContrato)
						print 3
						
						INSERT INTO cxc.FacturaAgrupada([idFactura],[rfcEmpresa],[idCliente],[numeroContrato],[fechaCarga],[fechaRecepcion],[numeroCopade],[numeroEstimacion],[xml],[idUsuario],[activo]) 
						VALUES(@idFactura,@rfcEmpresa,@idCliente,@numeroContrato,@fechaCarga,@fechaRecepcion,@numeroCopade,@numeroEstimacion,@xml,@idUsuario,1)
						--Actualizar el estatus de la factura
						UPDATE cxc.Factura SET idEstatus = 'PrefacturaGenerada' WHERE idFactura = @idFactura
								

						SET @v_sq=''
						SET @v_sq+=' INSERT INTO '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_COPADE(COP_ORDENGLOBAL,COP_COPADE,COP_CVEUSU,COP_FECHOPE,COP_HORAOPE,COP_IDDOCTO,COP_STATUS,COP_CARGO,COP_SALDO,COP_FECHULTPAG) '
						SET @v_sq+=' VALUES(@numeroEstimacion,'''',''GMI'',CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(TIME,GETDATE(),103),NULL,1,NULL,NULL,NULL) '
						--SET @v_sq+=' VALUES(@numeroEstimacion,@numeroCopade,''GMI'',CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(TIME,GETDATE(),103),NULL,1,NULL,NULL,NULL) '
						EXEC sp_executesql  @v_sq, N'@numeroEstimacion VARCHAR(500),@numeroCopade VARCHAR(500) ',
											@numeroEstimacion	=@numeroEstimacion,
											@numeroCopade		=@numeroCopade

						SET @v_sq=''
						SET @v_sq+=' UPDATE '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC SET OTE_ORDENGLOBAL = @numeroEstimacion '
						SET @v_sq+=' WHERE OTE_ORDENANDRADE COLLATE MODERN_SPANISH_CI_AS IN(	SELECT	so.numeroOrden '
						SET @v_sq+='							FROM	cxc.Factura fac '
						SET @v_sq+='							INNER	JOIN solicitud.Solicitud s ON s.idSolicitud = fac.idsolicitud AND s.idCliente = fac.idCliente AND s.idClase = fac.idClase AND s.numeroContrato = fac.numeroContrato '
						SET @v_sq+='							INNER	JOIN solicitud.SolicitudObjeto so ON so.idSolicitud = s.idSolicitud AND so.idCliente = s.idCliente AND so.idClase = s.idClase AND so.numeroContrato = s.numeroContrato '
						SET @v_sq+='							WHERE	fac.numeroContrato = @numeroContrato AND fac.rfcEmpresa = @rfcEmpresa AND fac.idCliente = @idCliente AND fac.idClase = @idClase AND fac.idFactura IN ('+CAST(@idFactura as varchar)+') GROUP BY so.numeroOrden) '
						SET @v_sq+=' AND OTE_ORDENPEMEX COLLATE MODERN_SPANISH_CI_AS IN (SELECT fac.numeroCotizacion FROM cxc.Factura fac WHERE fac.idFactura in ('+CAST(@idFactura as varchar)+'))'
						print @v_sq
						EXEC sp_executesql  @v_sq, N'@numeroEstimacion VARCHAR(500),@numeroContrato VARCHAR(50),@rfcEmpresa VARCHAR(13),@idCliente INT,@idClase VARCHAR(10)',
											@numeroEstimacion	=@numeroEstimacion,
											@numeroContrato		=@numeroContrato,
											@rfcEmpresa			=@rfcEmpresa,
											@idCliente			=@idCliente,
											@idClase			=@idClase

						-- Avanzar la orden
								--EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,@idUsuario,''
								EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_ESPECIFICO_SP] @idSolicitud,@idTipoSolicitud,@idClase,@rfcEmpresa,@idCliente,@numeroContrato,'PrefacturaGenerada','Cobranza',@idUsuario,''
								
					END
				ELSE
					BEGIN
						SET @err = 'Error, El contrato no tiene asignada configuración para facturación'
					END
			END
		ELSE
			BEGIN
				SET @err = 'Error, Alguna de las facturas enviada ya han sido registradas previamente'
			END
		--COMMIT
	END TRY
	BEGIN CATCH
		--ROLLBACK TRANSACTION
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al intentar guardar la prefactura.'
	END CATCH
END

go

