-- =============================================
-- Author: Adolfo Martinez
-- Create date: 31/07/2020
-- Description: Autoriza una partida
-- ============== Versionamiento ================
/*
	Fecha			Autor	Descripción 

	*- Testing...
	
	EXEC [solicitud].[UPD_PROVEEDOR_COTIZACION_ESTATUS_SP] 1016,'Servicio','Automovil','ASE0508051B6',219,'128',6334,'APROBADA','<solicitudes><solicitud><idSolicitud>1016</idSolicitud><idCotizacion>1503</idCotizacion><rfcProveedor>TAT180226ST1</rfcProveedor><idProveedorEntidad>526</idProveedorEntidad></solicitud><solicitud><idSolicitud>1016</idSolicitud><idCotizacion>1504</idCotizacion><rfcProveedor>TAT180226ST1</rfcProveedor><idProveedorEntidad>526</idProveedorEntidad></solicitud><solicitud><idSolicitud>1016</idSolicitud><idCotizacion>1505</idCotizacion><rfcProveedor>TAT180226ST1</rfcProveedor><idProveedorEntidad>526</idProveedorEntidad></solicitud><solicitud><idSolicitud>1016</idSolicitud><idCotizacion>1506</idCotizacion><rfcProveedor>TAT180226ST1</rfcProveedor><idProveedorEntidad>526</idProveedorEntidad></solicitud><solicitud><idSolicitud>1016</idSolicitud><idCotizacion>1507</idCotizacion><rfcProveedor>TAT180226ST1</rfcProveedor><idProveedorEntidad>526</idProveedorEntidad></solicitud></solicitudes>',''

*/
-- =============================================

CREATE PROCEDURE [solicitud].[UPD_PROVEEDOR_COTIZACION_ESTATUS_MULTIPLE_SP]
	@idSolicitud					INT,
	@idTipoSolicitud				VARCHAR(10),
	@idClase						VARCHAR(10),
	@rfcEmpresa						VARCHAR(13),
	@idCliente						INT,
	@numeroContrato					VARCHAR(50),
	@idUsuario						INT,
	@accion							VARCHAR(20),
	@xmlSolicitudes					XML,
	@err							VARCHAR(500) OUTPUT
AS
BEGIN
	BEGIN TRY  
		BEGIN TRANSACTION; 

		DECLARE @tbl_solicitudes AS TABLE(_row INT IDENTITY(1,1),idSolicitud INT,idCotizacion INT,rfcProveedor VARCHAR(50),idProveedorEntidad INT)
		INSERT INTO @tbl_solicitudes(idSolicitud, idCotizacion, rfcProveedor,idProveedorEntidad) 
		SELECT I.col.value('idSolicitud[1]','int'),I.col.value('idCotizacion[1]','int'),I.col.value('rfcProveedor[1]','varchar(50)'),I.col.value('idProveedorEntidad[1]','int') 
		FROM @xmlSolicitudes.nodes('solicitudes/solicitud') AS I(col)
				
		DECLARE @aplicaCentrodeCosto INT,
				@ventaTotalSolicitudes FLOAT
		DECLARE @CCF TABLE (
			idCentroCosto INT,
			nombre VARCHAR(200),
			presupuestoCC FLOAT,
			folio VARCHAR(200),
			presupuestoCF FLOAT,
			fechaInicio DATETIME,
			fechaFin DATETIME,
			gastado float,
			restante FLOAT)
		DECLARE @fechaInicioCentroCosto DATETIME, @fechaFinCentroCosto DATETIME, @restaCC FLOAT, @idCotizacion INT,@rfcProveedor VARCHAR(50),@idProveedorEntidad INT
		SELECT 
			@aplicaCentrodeCosto = manejoDePresupuesto
		FROM [cliente].[cliente].[Contrato] 
		WHERE rfcEmpresa = @rfcEmpresa
		AND idCliente = @idCliente
		AND numeroContrato = @numeroContrato
		AND idClase = @idClase
		AND activo = 1

		--SELECT *, @idTipoSolicitud, @idClase, @rfcEmpresa, @idCliente,@numeroContrato,@idUsuario,@accion FROM @tbl_solicitudes
	/*************************************************************************** SI LA FECHA ACTUAL SE ENCUENTRA EN EL RANGO DE TERMINO DEL CONTRATO ***************************************************************************/
	IF EXISTS(SELECT 1 FROM Cliente.cliente.Contrato WHERE numeroContrato = @numeroContrato AND idCliente = @idCliente AND rfcEmpresa = @rfcEmpresa AND activo = 1)
		BEGIN
			WHILE EXISTS(SELECT 1 FROM @tbl_solicitudes)
				BEGIN
				SELECT TOP 1 @idCotizacion=idCotizacion, @rfcProveedor=rfcProveedor, @idProveedorEntidad=idProveedorEntidad FROM @tbl_solicitudes	
					IF EXISTS(SELECT 1 FROM [solicitud].[SolicitudCotizacion] where idSolicitud=@idSolicitud AND idCotizacion=@idCotizacion AND idEstatusCotizacion='ENESPERA')
					BEGIN
						/*************************************************************************** CUANDO SE APRUEBA UNA PARTIDA ***************************************************************************/
						IF(@accion = 'APROBADA')
							BEGIN
								/*************************************************************************** SI APLICA CENTRO DE COSTO ***************************************************************************/
								IF (@aplicaCentrodeCosto > 0 AND @aplicaCentrodeCosto IS NOT NULL)
									BEGIN
										INSERT INTO @CCF
										EXECUTE Cliente.contrato.SEL_CENTRODECOSTO_FOLIO_SP @rfcEmpresa, @idCliente, @numeroContrato, @idUsuario, NULL
			
										SELECT
											@fechaInicioCentroCosto = CC.fechaInicio,
											@fechaFinCentroCosto = CC.fechaFin,
											@restaCC = CC.restante
										FROM @CCF AS CC
										INNER JOIN Solicitud.solicitud.Solicitud AS S 
											ON S.idCentroCosto = CC.idCentroCosto 
												AND S.folio = CC.folio
										WHERE S.idSolicitud = @idSolicitud


										SELECT 
											@ventaTotalSolicitudes = SUM(subTotalVenta)
										FROM [solicitud].[SEL_TOTALES_SOLICITUD_VW] SV
										INNER JOIN Solicitud.solicitud.Solicitud S
											ON S.idSolicitud = SV.idSolicitud
										WHERE S.folio = (SELECT folio FROM Solicitud.solicitud.Solicitud WHERE idSolicitud = @idSolicitud)

										/*************************************************************************** SI EL TOTAL DE LAS VENTAS DE LAS SOLICITUDES ESTA EN EL RANGO DEL FOLIO ***************************************************************************/
										IF(@ventaTotalSolicitudes <= @restaCC)
											BEGIN
										/*************************************************************************** SI LA FECHA ACTUAL SE ENCUENTRA EN EL RANGO DE TERMINO DEL CENTRO DE COSTO ***************************************************************************/
												IF((GETDATE() BETWEEN @fechaInicioCentroCosto AND @fechaFinCentroCosto))
													BEGIN
														INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
														[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
														[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[fechaAprobacion])
														SELECT [idCotizacion]
															,SP.[idSolicitud]
															,SP.[idTipoSolicitud]
															,SP.[idClase]
															,SP.[rfcEmpresa]
															,SP.[numeroContrato]
															,SP.[idCliente]
															,SP.[rfcProveedor]
															,SP.[idProveedorEntidad]
															,SP.[idObjeto]
															,SP.[idTipoObjeto]
															,SP.[idPartida]
															,@idUsuario
															,GETDATE()
														FROM [solicitud].[SolicitudCotizacionPartida] SP 
														WHERE 
															idSolicitud = @idSolicitud
															AND idTipoSolicitud = @idTipoSolicitud
															AND idClase = @idClase
															AND rfcEmpresa = @rfcEmpresa
															AND idCliente = @idCliente
															AND numeroContrato = @numeroContrato
															AND rfcProveedor = @rfcProveedor
															AND idProveedorEntidad = @idProveedorEntidad
															--AND sp.idPartida = @idPartida
															AND SP.idCotizacion = @idCotizacion
															AND SP.idEstatusCotizacionPartida = 'ENESPERA'
														
														UPDATE SP
															SET idEstatusCotizacionPartida = @accion
														FROM [solicitud].[SolicitudCotizacionPartida] SP 
														WHERE 
															idSolicitud = @idSolicitud
															AND idTipoSolicitud = @idTipoSolicitud
															AND idClase = @idClase
															AND rfcEmpresa = @rfcEmpresa
															AND idCliente = @idCliente
															AND numeroContrato = @numeroContrato
															AND rfcProveedor = @rfcProveedor
															AND idProveedorEntidad = @idProveedorEntidad
															--AND sp.idPartida = @idPartida
															AND SP.idCotizacion = @idCotizacion
															AND SP.idEstatusCotizacionPartida = 'ENESPERA'

														SELECT 'Se actualizaron las partidas' as msj
													END
												ELSE
													BEGIN
														SET @err = 'El centro de costo ha expirado..'
													END
											END
										ELSE
											BEGIN
												SET @err = 'La venta de la solicitud excede el monto del centro de costo.'
											END
									END
									/*************************************************************************** SI NO APLICA CENTRO DE COSTO ***************************************************************************/
								ELSE
									BEGIN
										INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
										[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
										[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[fechaAprobacion])
										SELECT [idCotizacion]
											,SP.[idSolicitud]
											,SP.[idTipoSolicitud]
											,SP.[idClase]
											,SP.[rfcEmpresa]
											,SP.[numeroContrato]
											,SP.[idCliente]
											,SP.[rfcProveedor]
											,SP.[idProveedorEntidad]
											,SP.[idObjeto]
											,SP.[idTipoObjeto]
											,SP.[idPartida]
											,@idUsuario
											,GETDATE()
										FROM [solicitud].[SolicitudCotizacionPartida] SP 
										WHERE 
											idSolicitud = @idSolicitud
											AND idTipoSolicitud = @idTipoSolicitud
											AND idClase = @idClase
											AND rfcEmpresa = @rfcEmpresa
											AND idCliente = @idCliente
											AND numeroContrato = @numeroContrato
											AND rfcProveedor = @rfcProveedor
											AND idProveedorEntidad = @idProveedorEntidad
											--AND sp.idPartida = @idPartida
											AND SP.idCotizacion = @idCotizacion
											AND SP.idEstatusCotizacionPartida = 'ENESPERA'

										UPDATE SP
											SET idEstatusCotizacionPartida = @accion
										FROM [solicitud].[SolicitudCotizacionPartida] SP 
										WHERE 
											idSolicitud = @idSolicitud
											AND idTipoSolicitud = @idTipoSolicitud
											AND idClase = @idClase
											AND rfcEmpresa = @rfcEmpresa
											AND idCliente = @idCliente
											AND numeroContrato = @numeroContrato
											AND rfcProveedor = @rfcProveedor
											AND idProveedorEntidad = @idProveedorEntidad
											--AND sp.idPartida = @idPartida
											AND SP.idCotizacion = @idCotizacion
											AND SP.idEstatusCotizacionPartida = 'ENESPERA'

										SELECT 'Se actualizaron las partidas' as msj
									END
							END
							/*************************************************************************** CUANDO SE RECHACE UNA PARTIDA 	***************************************************************************/
						ELSE
							BEGIN

								INSERT INTO [Solicitud].[solicitud].[SolicitudCotizacionAprobador] ([idCotizacion],
								[idSolicitud],[idTipoSolicitud],[idClase],[rfcEmpresa],[numeroContrato],[idCliente],
								[rfcProveedor],[idProveedorEntidad],[idObjeto],[idTipoObjeto],[idPartida],[idUsuarioAprobador],[fechaAprobacion])
								SELECT [idCotizacion]
									,SP.[idSolicitud]
									,SP.[idTipoSolicitud]
									,SP.[idClase]
									,SP.[rfcEmpresa]
									,SP.[numeroContrato]
									,SP.[idCliente]
									,SP.[rfcProveedor]
									,SP.[idProveedorEntidad]
									,SP.[idObjeto]
									,SP.[idTipoObjeto]
									,SP.[idPartida]
									,@idUsuario
									,GETDATE()
								FROM [solicitud].[SolicitudCotizacionPartida] SP 
								WHERE 
									idSolicitud = @idSolicitud
									AND idTipoSolicitud = @idTipoSolicitud
									AND idClase = @idClase
									AND rfcEmpresa = @rfcEmpresa
									AND idCliente = @idCliente
									AND numeroContrato = @numeroContrato
									AND rfcProveedor = @rfcProveedor
									AND idProveedorEntidad = @idProveedorEntidad
									--AND sp.idPartida = @idPartida
									AND SP.idCotizacion = @idCotizacion
									AND SP.idEstatusCotizacionPartida = 'ENESPERA'

								UPDATE SP
									SET idEstatusCotizacionPartida = @accion
								FROM [solicitud].[SolicitudCotizacionPartida] SP 
								WHERE 
									idSolicitud = @idSolicitud
									AND idTipoSolicitud = @idTipoSolicitud
									AND idClase = @idClase
									AND rfcEmpresa = @rfcEmpresa
									AND idCliente = @idCliente
									AND numeroContrato = @numeroContrato
									AND rfcProveedor = @rfcProveedor
									AND idProveedorEntidad = @idProveedorEntidad
									--AND sp.idPartida = @idPartida
									AND SP.idCotizacion = @idCotizacion
									AND SP.idEstatusCotizacionPartida = 'ENESPERA'

								SELECT 'Se actualizaron las partidas' as msj
							END

							/*****************************************************VALIDA ESTATUS COTIZACION APROBADA RECHAZADA **************************************/
							EXEC [solicitud].[UPD_COTIZACION_ESTATUS_SP] @idCotizacion, @idSolicitud, @idTipoSolicitud, @idClase, @rfcEmpresa, @numeroContrato, @idCliente, @rfcProveedor, @idProveedorEntidad, @idUsuario, @err = '' 
							/*****************************************************EJECUTA SP PARA AVANZAR DE PASO **************************************/

							IF EXISTS(SELECT 1 FROM solicitud.Solicitud WHERE idSolicitud = @idSolicitud AND idFase = 'Aprobacion')
								BEGIN
									EXEC [solicitud].[UPD_SOLICITUD_AVANZAORDEN_SP]
										@idSolicitud = @idSolicitud
										,@idTipoSolicitud = @idTipoSolicitud
										,@idClase = @idClase
										,@rfcEmpresa = @rfcEmpresa
										,@idCliente	= @idCliente
										,@numeroContrato = @numeroContrato
										,@idUsuario = @idUsuario
										,@err = '' 
								END
							ELSE
								BEGIN
									SELECT 0 cambiaPaso
								END
					END
					DELETE FROM @tbl_solicitudes WHERE idCotizacion = @idCotizacion
				END
		END
	ELSE
		BEGIN
			SET @err = 'El contrato ya ha exirado.'
		END

		COMMIT TRANSACTION;  
	END TRY
	BEGIN CATCH
		PRINT ERROR_NUMBER() 
		PRINT ERROR_MESSAGE()
	END CATCH
END
go

