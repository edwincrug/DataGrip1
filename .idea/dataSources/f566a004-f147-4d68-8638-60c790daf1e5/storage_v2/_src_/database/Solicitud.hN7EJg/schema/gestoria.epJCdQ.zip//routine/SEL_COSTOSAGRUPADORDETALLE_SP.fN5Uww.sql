
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 29-05-2019
-- Description: Consulta trae detalle de agrupadores
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[SEL_COSTOSAGRUPADORDETALLE_SP]  'Automovil',1,6036, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[SEL_COSTOSAGRUPADORDETALLE_SP] 
	@idClase				varchar(10),
	@idAgrupador			int,
	@idUsuario				int,
	@err					nvarchar(500)OUTPUT
AS


BEGIN

	create table #propiedades(
	idTipoObjeto		int,
	agrupador			varchar(500),
	valor				varchar(250),
	orden				int,
	posicion			int,
	ordenFinal			INT
)

	/**********************************************************************************************************************
	******************************************************CATALOGOS Y AGRUPADORES******************************************
	**********************************************************************************************************************/
	--PROPIEDADES GENERALES
	;with catalogos as(
		select	
			tob.idTipoObjeto				idTipoObjeto,
			prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
			prg.valor						valor,
			prg.idPadre						idPadre,
			prg.orden						orden,
			prg.posicion					posicion,
			0								ordenFinal
		from 
		partida.tipoobjeto.TipoObjeto tob
		inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tob.idTipoObjeto = tpg.idTipoObjeto
		inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
		inner join partida.integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
		where 
			prg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
			and tob.idClase = @idClase
			and tob.activo = 1
		UNION ALL	
		--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
		select
			cat.idTipoObjeto				idTipoObjeto,
			prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
			prg.valor						valor,
			prg.idPadre						idPadre,
			prg.orden						orden,
			prg.posicion					posicion,
			0								ordenFinal
		from partida.tipoobjeto.PropiedadGeneral prg 
		inner join partida.integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
		inner join catalogos cat on cat.idPadre = prg.idPropiedadGeneral
		and prg.activo = 1
		)
		insert into #propiedades
		select 
			cat.idTipoObjeto,
			cat.agrupador,
			cat.valor,
			cat.orden,
			cat.posicion,
			cat.ordenFinal
		from catalogos cat 
		where 
			cat.idPadre is not null

	--PROPIEDADES DE CLASE
	;with catalogos as(
		select
			tob.idTipoObjeto				idTipoObjeto,
			prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
			isnull(prc.valor,'')			valor,
			prc.idPadre						idPadre,
			prc.orden						orden,
			prc.posicion					posicion,
			1								ordenFinal
		from 
		partida.tipoobjeto.TipoObjeto tob
		inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tob.idTipoObjeto = tpc.idTipoObjeto
		inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
		where 
			prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
			and tob.idClase = @idClase
			and tob.activo = 1
		UNION ALL	
		--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
		select
			cat.idTipoObjeto				idTipoObjeto,
			prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
			isnull(prc.valor,'')			valor,
			prc.idPadre						idPadre,
			prc.orden						orden,
			prc.posicion					posicion,
			1								ordenFinal
		from partida.tipoobjeto.PropiedadClase prc 
		inner join catalogos cat on cat.idPadre = prc.idPropiedadClase 
		WHERE prc.activo = 1
		)
		insert into #propiedades
		select 
			cat.idTIpoObjeto,
			cat.agrupador,
			cat.valor,
			cat.orden,
			cat.posicion,
			cat.ordenFinal
		from catalogos cat 
		where 
			cat.idPadre is not null

	
	/**********************************************************************************************************************
	*********************************************************TAGS**********************************************************
	**********************************************************************************************************************/
	--PROPIEDADES GENERALES
	;with tags as(
		select	
			tob.idTipoObjeto				idTipoObjeto,
			prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
			isnull(prg.valor,'')			valor,
			prg.idPadre						idPadre,
			prg.orden						orden,
			prg.posicion					posicion,
			0								ordenFinal
		from 
		partida.tipoobjeto.TipoObjeto tob
		inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tob.idTipoObjeto = tpg.idTipoObjeto
		inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
		where prg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
		and tob.idClase = @idClase
		and tob.activo = 1
		UNION ALL	
		--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
		select
			tag.idTipoObjeto				idTipoObjeto,
			prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
			isnull(prg.valor,'')			valor,
			prg.idPadre						idPadre,
			prg.orden						orden,
			prg.posicion					posicion,
			0								ordenFinal
		from partida.tipoobjeto.PropiedadGeneral prg 
		inner join tags tag on tag.idPadre = prg.idPropiedadGeneral
		WHERE prg.activo = 1
		)
		insert into #propiedades
		select distinct 
			idTipoObjeto,
			agrupador,
			(
		SELECT STUFF(
	
			(SELECT ', ' + valor
			FROM tags tagsAux
			WHERE tagsAux.idPadre is not null and tagsAux.idTipoObjeto = tags. idTipoObjeto and tagsAux.agrupador = tags.agrupador
			FOR XML PATH ('')),
		1,1, '') ) as valor, orden, posicion, ordenFinal from tags

	--PROPIEDADES CLASE
	;with tags as(
		select	
			tob.idTipoObjeto				idTipoObjeto,
			prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
			isnull(prc.valor,'')			valor,
			prc.idPadre						idPadre,
			prc.orden						orden,
			prc.posicion					posicion,
			1								ordenFinal
		from partida.tipoobjeto.TipoObjeto tob
		inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tob.idTipoObjeto = tpc.idTipoObjeto
		inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
		where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
		and tob.idClase = @idClase
		and tob.activo = 1
		UNION ALL	
		--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
		select
			tag.idTipoObjeto				idTipoObjeto,
			prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
			isnull(prc.valor,'')			valor,
			prc.idPadre						idPadre,
			prc.orden						orden,
			prc.posicion					posicion,
			1								ordenFinal
		from partida.tipoobjeto.PropiedadClase prc 
		inner join tags tag on tag.idPadre = prc.idPropiedadClase
		and prc.activo = 1
		)
		insert into #propiedades
		select distinct 
			idTipoObjeto,
			agrupador,
			(
		SELECT STUFF(
	
			(SELECT ', ' + valor
			FROM tags tagsAux
			WHERE tagsAux.idPadre is not null and tagsAux.idTipoObjeto = tags.idTipoObjeto and tagsAux.agrupador = tags.agrupador
			FOR XML PATH ('')),
		1,1, '') ) as valor, orden, posicion, ordenFinal from tags

	/**********************************************************************************************************************
	***************************************************VALORES FIJOS*******************************************************
	**********************************************************************************************************************/
	--PROPIEDADES GENERALES
	INSERT INTO #propiedades
	select 
		pto.idTipoObjeto		idTipoObjeto,
		prg.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
		tpg.valor				valor,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from partida.tipoobjeto.TipoObjeto pto 
	inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tpg.idTipoObjeto = pto.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
	where
		prg.idTipoValor = 'Unico'
		and pto.idClase = @idClase
		and pto.activo = 1

	--PROPIEDADES DE CLASE
	INSERT INTO #propiedades
	select 
		pto.idTipoObjeto				idTipoObjeto,
		prc.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
		tpc.valor				valor,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.tipoobjeto.TipoObjeto pto 
	inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tpc.idTipoObjeto = pto.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
	where
		prc.idTipoValor = 'Unico'
		and pto.idClase = @idClase
		and pto.activo = 1



	/**********************************************************************************************************************
	******************************************************PIVOTE***********************************************************
	**********************************************************************************************************************/
	declare 
		@columnsName varchar(max) = ''

	--select * from #propiedades order by ordenFinal, posicion, orden

	create table #propiedadesOrdenas
		(
			agrupador			varchar(500),
			ordenFinal			int,
			posicion			int,
			orden				int
		)
	insert into #propiedadesOrdenas
	select distinct 
		pr.agrupador,
		min(pr.ordenFinal),
		min(pr.posicion),
		min(pr.orden)
	from #propiedades pr group by pr.agrupador order by 
		min(pr.ordenFinal),
		min(pr.posicion),
		min(pr.orden)


	SET @columnsName = STUFF((SELECT ',' + QUOTENAME(prg.agrupador) 
							FROM #propiedadesOrdenas prg 
							FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')



	declare @query varchar(max)
	set @query = '

	
	IF OBJECT_ID(''tempdb..#tipoObjeto'') IS NOT NULL
			BEGIN
				DROP TABLE #tipoObjeto
			END

	IF OBJECT_ID(''tempdb..#tbl_idTipoObjeto'') IS NOT NULL
		BEGIN
			DROP TABLE #tbl_idTipoObjeto
		END

		SELECT
			*,
			(select count(*) from 
			partida.partida.partida par 
			where par.idTipoObjeto = resultado.idTipoObjeto and par.activo=1 ) as TotalPartidas
		INTO #tipoObjeto
		from
		(select idTipoObjeto, agrupador, valor from #propiedades) t  
		pivot
		(	
			max(valor)
			for agrupador in (' + @columnsName + ')
		) AS resultado

		select * from #tipoObjeto

		SELECT 
		CAD.idTipoObjeto,
		idCostoAgrupador
		INTO #tbl_idTipoObjeto
		FROM gestoria.CostoAgrupadorDetalle CAD 
		INNER JOIN partida.tipoobjeto.tipoObjeto TOB ON TOB.idTipoObjeto = CAD.idTipoObjeto
		WHERE TOB.idClase = '''+ @idClase+ '''
		AND TOB.activo = 1

		SELECT idCostoAgrupador,T.* from #tipoObjeto T
		INNER JOIN #tbl_idTipoObjeto ITO ON ITO.idTipoObjeto = T.idTipoObjeto
		
		'


	EXECUTE (@query)
	

	

	DROP TABLE #propiedades
	DROP TABLE #propiedadesOrdenas

END
go

