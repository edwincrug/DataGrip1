  
-- =============================================  
-- Author: Gerardo Zamudio González  
-- Create date: 21-06-2019  
-- Description: Obtener los proveedores de una cotización  
-- ============== Versionamiento ================  
/*  
	Fecha		Autor			Descripción   
	13/08/2019	José Etmanuel	Agregando el documento de la factura y el nuemero de veces de la partida  
	29/09/2020	JLuis Lozada	Se agrego la tabla 9 para obtener la moneda
	09/11/2020	JLuis Lozada	Se modifico el campo partidaUso
  
 *- Testing...  
	 DECLARE @salida varchar(max) ='' ;  
	 EXEC [solicitud].[SEL_PROVEEDORCOTIZACION_SP]  'ASE0508051B6', 185, '43', 614, 631, 'Automovil',NULL,6334, '';
	 EXEC [solicitud].[SEL_PROVEEDORCOTIZACION_SP]  'ASE0508051B6', 219, '128', 1016, 123, 'Automovil','152-1122-12980',6334, '';
	 EXEC [solicitud].[SEL_PROVEEDORCOTIZACION_SP]  'ASE0508051B6', 185, '43', 1429, 117, 'Automovil','150-1464-10558',6334, '';

	 EXEC [solicitud].[SEL_PROVEEDORCOTIZACION_SP_test]  'ASE0508051B6', 185, '43', 13009, 631, 'Automovil','150-10200-22023',2270, '';
	 SELECT @salida AS salida;  
	 
*/  
-- =============================================  
CREATE  PROCEDURE [solicitud].[SEL_PROVEEDORCOTIZACION_SP_test]  
@rfcEmpresa		varchar(13),  
 @idCliente			int,  
 @numeroContrato	nvarchar(50),  
 @idSolicitud		int,  
 @idTipoObjeto		int,  
 @idClase			varchar(10),  
 @numeroOrden		varchar(30) = NULL, 
 @idUsuario			int,  
 @err				varchar(500)OUTPUT
AS  
  
  
BEGIN  
 --SELECT * INTO #propiedadPartida FROM [Cliente].[contrato].[SEL_PARTIDAS_VW]  
 IF(@numeroOrden IS NULL)
	 BEGIN
		SET @numeroOrden = (SELECT TOP 1 numeroOrden FROM [solicitud].[SolicitudObjeto] WHERE idSolicitud=@idSolicitud)
	 END

	SELECT DISTINCT
		SC.[idCotizacion]  
		,SC.[idSolicitud]  
		,SC.[idTipoSolicitud]  
		,TS.[generaCXC]
		,SC.[idClase]  
		,SC.[rfcEmpresa]  
		,SC.[idCliente]  
		,SC.[numeroContrato]  
		,SC.[idProveedorEntidad]  
		,SC.[rfcProveedor]  
		,SC.[numeroCotizacion]  
		,SC.[fechaAlta]  
		,SC.[idUsuario]
		,SC.[idEstatusCotizacion]
	into #cotizaciones
	FROM [Solicitud].[solicitud].[SolicitudCotizacion] SC
		JOIN [solicitud].[TipoSolicitud] TS ON TS.idTipoSolicitud = SC.idTipoSolicitud
		JOIN [solicitud].[SolicitudObjeto] SO ON SO.idSolicitud = SC.idSolicitud
		JOIN [solicitud].[SolicitudCotizacionPartida] SCP ON SCP.idCotizacion = SC.idCotizacion AND SCP.idSolicitud = SC.idSolicitud AND SO.idObjeto = SCP.idObjeto AND SO.idTipoObjeto = SCP.idTipoObjeto
	WHERE SC.[rfcEmpresa] = @rfcEmpresa  AND  
	SC.[idCliente] = CAST(@idCliente AS VARCHAR(50)) AND  
	SC.[numeroContrato] =  @numeroContrato  AND  
	SC.[idSolicitud] = CAST(@idSolicitud AS VARCHAR(50))
	AND SO.[numeroOrden] = COALESCE(NULL, @numeroOrden)

 select   
  [idProveedorEntidad]  
  ,[rfcProveedor]  
 from #cotizaciones group by[numeroContrato]  
  ,[idProveedorEntidad]  
  ,[rfcProveedor] ORDER BY idProveedorEntidad  
  
	select   
			C.numeroCotizacion
			,C.idCotizacion
			,C.idSolicitud
			,C.idTipoSolicitud 
			,C.generaCXC
			,C.idClase 
			,C.rfcEmpresa  
			,C.idCliente  
			,C.numeroContrato 
			,C.idProveedorEntidad  
			,C.rfcProveedor 
			,C.idEstatusCotizacion
			,ISNULL(FB.OTE_IDENT,0) OTE_IDENT
	from #cotizaciones C
	LEFT JOIN [cxc].[Factura] F ON F.idSolicitud=C.idSolicitud and F.idCotizacion=C.idCotizacion
	LEFT JOIN [cxc].[FacturaBPRO] FB on F.idSolicitud = FB.idSolicitud and F.idCotizacion = FB.idCotizacion
	group by  
	C.numeroCotizacion 
	,C.idCotizacion
	,C.idSolicitud  
	,C.idTipoSolicitud  
	,C.generaCXC
	,C.idClase
	,C.rfcEmpresa 
	,C.idCliente 
	,C.numeroContrato 
	,C.idProveedorEntidad 
	,C.rfcProveedor
	,C.idEstatusCotizacion
	,FB.OTE_IDENT
	order by C.idProveedorEntidad  
  
	SELECT	C.numeroCotizacion,  
			SCP.[idCotizacion],  
			SCP.[idSolicitud],  
			SCP.[idTipoSolicitud],  
			SCP.[idClase],  
			SCP.[rfcEmpresa],  
			SCP.[numeroContrato],  
			SCP.[idCliente],  
			SCP.[rfcProveedor],  
			SCP.[idProveedorEntidad],  
			SCP.[idObjeto],  
			SCP.[idTipoObjeto],  
			SCP.[idPartida],  
			SCP.[cantidad],  
			SCP.[costo] AS costoInicial,  
			SCP.[subTotalCosto],  
			SCP.[IVACosto],  
			SCP.[totalCosto],  
			SCP.[venta] AS ventaInicial,  
			SCP.[subTotalVenta],  
			SCP.[IVAVenta],  
			SCP.[totalVenta],  
			SCP.[idEstatusCotizacionPartida],  
			SCP.[fechaEstatus],  
			--SP.[ventaInicial],  
			ECP.[nombre] AS nombreEstatus,  
			(CASE WHEN PP.[Foto] IS NULL OR PP.[Foto] = 0 THEN 
				(SELECT idDocumento FROM [Common].[configuracion].[DocumentoDefault] WHERE activo=1 AND descripcion='pieza') ELSE PP.[Foto] END) AS [Foto],
			(CASE WHEN PP.[Instructivo] IS NULL OR PP.[Instructivo] = 0 THEN 
				((SELECT valor from Common.configuracion.Configuracion where nombre = 'fileServer')+(Select path from FileServer.documento.documento where idDocumento = (SELECT idDocumento from Common.configuracion.DocumentoDefault where descripcion = 'instructivo')))
			ELSE ((select valor from Common.configuracion.Configuracion where nombre = 'fileServer') + (select path from FileServer.documento.Documento where idDocumento = PP.[Instructivo])) END) AS [Instructivo],    
			(SELECT top 1 valor FROM [Partida].[partida].[PartidaPropiedadGeneral] WHERE idPartida = SCP.idPartida AND idPropiedadGeneral = (SELECT TOP 1 idPropiedadGeneral FROM  [Partida].[partida].[PropiedadGeneral] where valor = 'Partida')) as partida,  
			(SELECT top 1 valor FROM [Partida].[partida].[PartidaPropiedadGeneral] WHERE idPartida = SCP.idPartida AND idPropiedadGeneral = (SELECT TOP 1 idPropiedadGeneral FROM  [Partida].[partida].[PropiedadGeneral] where valor = 'noParte')) as noParte,  
			CAST((ISNULL((	SELECT SUM(tx.cantidad) 
							FROM (
									SELECT	cantidad 
									FROM	[solicitud].[SolicitudCotizacionPartida]scpp 
									INNER	JOIN [solicitud].[solicitudCotizacion] scot 
									ON		scot.idSolicitud		=scpp.idSolicitud
									AND     scot.idTipoSolicitud	=scpp.idTipoSolicitud
									AND     scot.idClase			=scpp.idClase
									AND     scot.rfcEmpresa			=scpp.rfcEmpresa
									AND		scot.idCliente			=scpp.idCliente
									AND     scot.numeroContrato		=scpp.numeroContrato
									AND     scot.idProveedorEntidad =scpp.idProveedorEntidad
									AND     scot.idCotizacion		=scpp.idCotizacion
									AND     scot.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')
									INNER	JOIN [solicitud].[solicitud] sol 
									ON		scpp.idSolicitud		=sol.idSolicitud
									AND     scpp.idTipoSolicitud	=sol.idTipoSolicitud
									AND     scpp.idClase			=sol.idClase
									AND     scpp.rfcEmpresa			=sol.rfcEmpresa
									AND		scpp.idCliente			=sol.idCliente
									AND     scpp.numeroContrato		=sol.numeroContrato
									AND     sol.idEstatusSolicitud	NOT IN ('CANCELADA','RECHAZADA')
									WHERE	scpp.idPartida			=SCP.[idPartida] 
									AND		scpp.idObjeto			=SCP.[idObjeto] 
									AND		scpp.idTipoObjeto		=@idTipoObjeto
									AND		scpp.idEstatusCotizacionPartida='APROBADA'
									AND		scpp.rfcEmpresa			=@rfcEmpresa
									AND		scpp.idCliente			=@idCliente 
									AND		scpp.numeroContrato		=@numeroContrato
									AND		scpp.idClase			=@idClase
								)tx
							
							),0)) AS VARCHAR) as partidaUso,
			PP.[descripcion] as Descripcion
			,(	SELECT (ISNULL([F].[serie], '')  + ISNULL(CAST([F].[folio] AS VARCHAR(MAX)),'SN')) AS serieFolio  
				FROM	[Solicitud].[cxp].[SolicitudCotizacionFactura] AS SCF  
				INNER	JOIN [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] AS SCFD ON SCFD.idCotizacion = SCF.idCotizacion 
				AND		SCFD.idSolicitud		= SCF.idSolicitud 
				AND		SCFD.idTipoSolicitud	= SCF.idTipoSolicitud 
				AND		SCFD.idClase			= SCF.idClase 
				AND		SCFD.rfcEmpresa			= SCF.rfcEmpresa 
				AND		SCFD.idCliente			= SCF.idCliente 
				AND		SCFD.numeroContrato		= SCF.numeroContrato 
				AND		SCFD.idProveedorEntidad = SCF.idProveedorEntidad 
				AND		SCFD.rfcProveedor		= SCF.rfcProveedor 
				AND		SCFD.uuid				= SCF.uuid 
				AND		SCFD.idPartida			= SCP.[idPartida]  
				INNER	JOIN [Solicitud].[cxp].[Factura] F ON F.uuid = SCF.uuid  
				WHERE	SCF.idClase				= C.idClase 
				AND		SCF.idCotizacion		= C.idCotizacion 
				AND		SCF.idProveedorEntidad	= C.idProveedorEntidad 
				AND     SCF.idSolicitud			= C.idSolicitud 
				AND     SCF.idTipoSolicitud		= C.idTipoSolicitud 
				AND     SCF.numeroContrato		= C.numeroContrato 
				AND     SCF.rfcEmpresa			= C.rfcEmpresa 
				AND     SCF.rfcProveedor		= C.rfcProveedor) AS folio,  
			(	COALESCE([U].[PrimerNombre], '') + ' ' + COALESCE([U].[SegundoNombre], '')+ ' ' + COALESCE([U].[PrimerApellido], '')+ ' ' + COALESCE([U].[SegundoApellido], '')) AS [nombreCompleto],  
			FileServer.documento.urlFileServer(  
			(	SELECT	idDocumentoPdf  
				FROM	[Solicitud].[cxp].[SolicitudCotizacionFactura] AS SCF  
				INNER	JOIN [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] AS SCFD ON   SCFD.idCotizacion = SCF.idCotizacion 
				AND  	SCFD.idSolicitud		= SCF.idSolicitud 
				AND  	SCFD.idTipoSolicitud	= SCF.idTipoSolicitud 
				AND		SCFD.idClase			= SCF.idClase 
				AND  	SCFD.rfcEmpresa			= SCF.rfcEmpresa 
				AND		SCFD.idCliente			= SCF.idCliente 
				AND  	SCFD.numeroContrato		= SCF.numeroContrato 
				AND  	SCFD.idProveedorEntidad = SCF.idProveedorEntidad 
				AND  	SCFD.rfcProveedor		= SCF.rfcProveedor 
				AND  	SCFD.uuid				= SCF.uuid 
				AND  	SCFD.idPartida			= SCP.[idPartida]  
  				INNER	JOIN [Solicitud].[cxp].[Factura] F ON F.uuid = SCF.uuid  
				WHERE	SCF.idClase = C.idClase AND  SCF.idCotizacion = C.idCotizacion 
				AND  	SCF.idProveedorEntidad	= C.idProveedorEntidad 
				AND  	SCF.idSolicitud			= C.idSolicitud 
				AND  	SCF.idTipoSolicitud		= C.idTipoSolicitud 
				AND  	SCF.numeroContrato		= C.numeroContrato 
				AND  	SCF.rfcEmpresa			= C.rfcEmpresa 
				AND  	SCF.rfcProveedor		= C.rfcProveedor)) AS factura 
				--[solicitud].[solicitud].SEL_VALIDAAUTORIZACIONES_FN(SCP.idSolicitud,SCP.idClase,SCP.idTipoSolicitud,SCP.rfcEmpresa,SCP.idCliente,SCP.numeroContrato,SCP.idPartida,SCP.idCotizacion) autPendientes
	into	#partidasCotizaciones  
	from	#cotizaciones C  
	left	join [solicitud].[SEL_TOTALES_PARTIDAS_VW] SCP on   SCP.idCotizacion = C.idCotizacion 
	AND   	SCP.idSolicitud			= C.idSolicitud 
	and  	SCP.idTipoSolicitud		= C.idTipoSolicitud 
	and  	SCP.idClase				= C.idClase 
	and  	SCP.rfcEmpresa			= C.rfcEmpresa 
	and  	SCP.idCliente			= C.idCliente 
	and  	SCP.numeroContrato		= C.numeroContrato 
	and  	SCP.rfcProveedor		= C.rfcProveedor 
	and  	SCP.idProveedorEntidad	= C.idProveedorEntidad  
	inner	join solicitud.SolicitudPartida SP on  SCP.idSolicitud = SP.idSolicitud 
	and  	SCP.idTipoSolicitud		= SP.idTipoSolicitud 
	and  	SCP.idClase				= SP.idClase 
	and  	SCP.rfcEmpresa			= SP.rfcEmpresa 
	and  	SCP.idCliente			= SP.idCliente 
	and  	SCP.numeroContrato		= SP.numeroContrato 
	and  	SCP.idObjeto			= SP.idObjeto 
	and  	SCP.idTipoObjeto		= SP.idTipoObjeto 
	and  	SCP.idPartida			= SP.idPartida  
	INNER	JOIN [Cliente].[contrato].[SEL_PARTIDAS_VW] PP on PP.idPartida = SP.idPartida  
	INNER	JOIN [solicitud].[EstatusCotizacionPartida] ECP ON ECP.idEstatusCotizacionPartida = SCP.idEstatusCotizacionPartida   
	LEFT	JOIN [Seguridad].[Catalogo].[Users] U ON U.Id = SCP.idUsuario  
	WHERE	C.[rfcEmpresa]			= @rfcEmpresa 
	AND  	C.[idCliente]			= @idCliente 
	AND  	C.[numeroContrato]		= @numeroContrato 
	AND  	C.[idSolicitud]			= @idSolicitud  
  
  select 'bonita'
	select * from #partidasCotizaciones order by idProveedorEntidad  
  
	select  C.idCotizacion  
			,C.[numeroCotizacion]  
			,C.idProveedorEntidad  
			,C.rfcProveedor  
			,(COALESCE([U].[PrimerNombre], '') + ' ' + COALESCE([U].[SegundoNombre], '')+ ' ' + COALESCE([U].[PrimerApellido], '')+ ' ' + COALESCE([U].[SegundoApellido], '')) AS [nombreCompleto]  
			,C.fechaAlta  
			,C.estatusCotizacionNombre  
			,(select top 1 fechaAprobacion from solicitud.SolicitudCotizacionAprobador where idSolicitud = C.idSolicitud order by fechaAprobacion desc) fechaFin  
			,(select top 1 COALESCE([U].[PrimerNombre], '') + ' ' + COALESCE([U].[SegundoNombre], '')+ ' ' + COALESCE([U].[PrimerApellido], '')+ ' ' + COALESCE([U].[SegundoApellido], '')   
	from	solicitud.solicitud.SolicitudCotizacionAprobador SP INNER JOIN [Seguridad].[Catalogo].[Users] U ON U.Id = SP.idUsuarioAprobador where idSolicitud = C.idSolicitud ORDER BY SP.fechaAprobacion DESC) idUsuarioAprobador  
		 ,CASE  
		  WHEN C.[estatusCotizacionNombre] = 'En Espera' THEN 'soloespera'  
		  WHEN C.[estatusCotizacionNombre] = 'Aprobada' THEN 'aprobada'  
		  WHEN C.[estatusCotizacionNombre] = 'Rechazada' THEN 'rechazada'  
		  WHEN C.[estatusCotizacionNombre] = 'Cancelada' THEN 'cancelada'  
		  END AS clase  
	INTO #cotEstatus  
	from [solicitud].[SEL_ESTATUS_COTIZACIONES_FN](@idSolicitud) as C  
	INNER JOIN [Seguridad].[Catalogo].[Users] U ON U.Id = C.idUsuario  
  
	select * from #cotEstatus  
  
  SELECT  
     T.[idSolicitud]  
     ,T.[rfcProveedor]  
     ,T.[idProveedorEntidad]  
     ,T.[idCotizacion]  
     ,T.[subTotalCosto]  
     ,T.[IVACosto]  
     ,T.[totalCosto]  
     ,T.[subTotalVenta]  
     ,T.[IVAVenta]  
     ,T.[totalVenta]  
     ,C.numeroCotizacion  
  FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] AS T  
   INNER JOIN #cotizaciones C ON C.idCotizacion = T.idCotizacion 
  --INNER JOIN #partidasCotizaciones P ON P.numeroCotizacion = C.numeroCotizacion  
  WHERE C.idSolicitud = @idSolicitud  
  order by idProveedorEntidad  
 -- select * from [solicitud].[SEL_TOTALES_COTIZACION_VW] where idSolicitud=1016

  --EXEC [solicitud].[SEL_TOTAL_PARTIDAS_SP] @idSolicitud, @idUsuario  
    --------------------------------------TOTALES--------------------------------------
    ;WITH cte_datos as (
    SELECT 
        COALESCE(SUM(VW.subTotalCosto), 0) subTotalCosto
        ,COALESCE(SUM(VW.IVACosto), 0) IVACosto
        ,COALESCE(SUM(VW.totalCosto), 0) totalCosto
        ,COALESCE(SUM(VW.subTotalVenta), 0) subTotalVenta
        ,COALESCE(SUM(VW.IVAVenta), 0) IVAVenta
        ,COALESCE(SUM(VW.totalVenta), 0) totalVenta
		,CASE WHEN C.manejoDeUtilidad = 1 THEN C.porcentajeUtilidad ELSE -1 END AS contratoUtilidad
		,CASE WHEN COALESCE(SUM(VW.subTotalVenta), 0) = 0 THEN 0 
			ELSE CAST( ((COALESCE(SUM(VW.subTotalVenta), 0) - COALESCE(SUM(VW.subTotalCosto), 0)) / COALESCE(SUM(vw.SUBTOTALVENTA), 0)) * 100 AS DECIMAL(18,2)) END AS utilidad
		,MAX(VW.porcentajeDescuentoVenta) porcentajeDescuentoVenta
		,C.manejoDescuentoVenta
		,COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) subTotalVentaSnDesc
		,COALESCE(SUM(VW.descuentoVenta), 0) descuentoVenta
		,MAX(VW.porcentajeDescuentoCosto) porcentajeDescuentoCosto
		,COALESCE(SUM(VW.descuentoCosto), 0) descuentoCosto
		,COALESCE(SUM(VW.subTotalCostoSinDescuento), 0) subTotalCostoSnDesc
    FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] VW
	INNER JOIN #cotizaciones CT ON CT.idCotizacion = VW.idCotizacion 
	JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = VW.rfcEmpresa AND C.numeroContrato = VW.numeroContrato AND C.idCliente = VW.idCliente AND C.idClase = VW.idClase
    WHERE VW.[idSolicitud] = @idSolicitud
	    AND VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA')
		AND VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')
	GROUP BY C.porcentajeUtilidad,C.manejoDeUtilidad,C.manejoDescuentoVenta
	)

	select * from cte_datos

	UNION ALL

	SELECT
		0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
		,0
	WHERE NOT EXISTS (select * from cte_datos)

  --------------------------------------UTILIDAD--------------------------------------
    SELECT  
      VW.idSolicitud  
     ,VW.rfcProveedor
     ,VW.idProveedorEntidad
	 ,CASE WHEN C.manejoDeUtilidad = 1 THEN C.porcentajeUtilidad ELSE -1 END AS contratoUtilidad
	 ,CASE WHEN COALESCE(SUM(VW.subTotalVentaSinDescuento), 0) = 0 THEN 0 
	ELSE CAST( ((COALESCE(SUM(VW.subTotalVenta), 0) - COALESCE(SUM(VW.subTotalCosto), 0)) / COALESCE(SUM(vw.subTotalVentaSinDescuento), 0)) * 100 AS DECIMAL(18,2)) END AS utilidad
  FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] AS VW 
  JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = VW.rfcEmpresa AND C.numeroContrato = VW.numeroContrato AND C.idCliente = VW.idCliente AND C.idClase = VW.idClase
  INNER JOIN #cotizaciones Ct ON Ct.idCotizacion = VW.idCotizacion  
  WHERE VW.idSolicitud = @idSolicitud  
  GROUP BY VW.idSolicitud, VW.rfcProveedor, VW.idProveedorEntidad, C.manejoDeUtilidad, C.porcentajeUtilidad
  

  ----------------------------------------IMPUESTOS---------------------------------------------------
	DECLARE @impuestos TABLE (
		idSolicitud					INT
		,idCotizacion				INT
		,idTipoFacturaImpuesto		INT
		,tasa						FLOAT
		,tipo						INT
		,uuid						VARCHAR(MAX)
		,tipoDescripcion			VARCHAR(50)
	)

	DECLARE @traslado TABLE(
		impuesto			VARCHAR(20)
		,subTotalCosto		FLOAT
		,tasa				FLOAT
		,tipoDescripcion	VARCHAR(50)
	)

	DECLARE @retencion TABLE(
		impuesto			VARCHAR(20)
		,importe			FLOAT
		,tipoDescripcion	VARCHAR(50)
	)

	INSERT INTO @impuestos
	SELECT 
		SCF.idSolicitud
		,SCF.idCotizacion
		,TFI.idTipoFacturaImpuesto
		,FI.tasa
		,T.idTipo
		,SCF.uuid
		,T.descripcion
	FROM cxp.SolicitudCotizacionFactura SCF
	INNER JOIN cxp.Factura F 
		ON F.uuid = SCF.uuid
	INNER JOIN cxp.FacturaImpuesto FI 
		ON FI.uuidFactura = F.uuid
	INNER JOIN cxp.TipoFacturaImpuesto TFI 
		ON TFI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto
	INNER JOIN cxp.Tipo T 
		ON T.idTipo = TFI.idTipo 
	WHERE idSolicitud = @idSolicitud
	GROUP BY
		SCF.idSolicitud
		,SCF.idCotizacion
		,TFI.idTipoFacturaImpuesto
		,FI.tasa
		,T.idTipo
		,SCF.uuid
		,T.descripcion

 -------------------------------------------TRASLADO------------------------------------------

	 IF EXISTS(SELECT * FROM @impuestos WHERE tipo = 1)
		BEGIN
			INSERT INTO @traslado
			SELECT
				--*
				TFI.impuesto
				,SUM(TCV.subTotalCosto) * I.tasa subTotalCosto
				,I.tasa
				,T.descripcion
			FROM [solicitud].[SEL_TOTALES_COTIZACION_VW] TCV
			INNER JOIN @impuestos I 
				ON I.idCotizacion = TCV.idCotizacion 
				AND I.idSolicitud = TCV.idSolicitud
			INNER JOIN cxp.SolicitudCotizacionFactura SCF
				ON SCF.idSolicitud = I.idSolicitud 
				AND SCF.idCotizacion = I.idCotizacion 
			INNER JOIN cxp.Factura F 
				ON F.uuid = SCF.uuid
			INNER JOIN cxp.FacturaImpuesto FI 
				ON FI.uuidFactura = F.uuid
				AND FI.idTipoFacturaImpuesto = I.idTipoFacturaImpuesto
			INNER JOIN cxp.TipoFacturaImpuesto TFI 
				ON TFI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto
			INNER JOIN cxp.Tipo T 
				ON T.idTipo = TFI.idTipo 
			WHERE I.tipo = 1
			GROUP BY
				TFI.impuesto
				,I.tasa
				,T.descripcion
		
		END

	-------------------------------------------RETENCIÓN------------------------------------------


		IF EXISTS(SELECT * FROM @impuestos WHERE tipo = 2)
			BEGIN
				INSERT INTO @retencion
				SELECT
					TFI.impuesto
					,SUM(FI.importe) / (SELECT COUNT(uuid) FROM cxp.SolicitudCotizacionFactura 
										WHERE uuid = I.uuid)
					,T.descripcion
					--,* 
				FROM @impuestos I
				INNER JOIN cxp.SolicitudCotizacionFactura SCF
					ON SCF.idSolicitud = I.idSolicitud 
					AND SCF.idCotizacion = I.idCotizacion 
				INNER JOIN cxp.Factura F 
					ON F.uuid = SCF.uuid
				INNER JOIN cxp.FacturaImpuesto FI 
					ON FI.uuidFactura = F.uuid
					AND FI.idTipoFacturaImpuesto = I.idTipoFacturaImpuesto
				INNER JOIN cxp.TipoFacturaImpuesto TFI 
					ON TFI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto
				INNER JOIN cxp.Tipo T 
					ON T.idTipo = TFI.idTipo 
				WHERE I.tipo = 2
				GROUP BY
					TFI.impuesto
					,I.uuid
					,T.descripcion
					--,I.idCotizacion
			END
	select * from @traslado
	select * from @retencion

	SELECT TOP 1 ISNULL((	SELECT	'('+ISNULL(idMoneda,'')+')' 
					FROM	common.configuracion.monedaSAT 
					WHERE	descripcion=(	SELECT	valor 
											FROM	partida.partida.PartidapropiedadGeneral 
											WHERE	idPartida=vw.idPartida 
											AND		idPropiedadGeneral IN (	SELECT	idPropiedadGeneral 
																			FROM	partida.partida.propiedadGeneral 
																			WHERE	agrupador='Moneda'))),'') 'idMoneda'
	FROM [solicitud].[SEL_TOTALES_PARTIDAS_VW] VW
	INNER JOIN #cotizaciones CT ON CT.idCotizacion = VW.idCotizacion 
	JOIN [Cliente].[cliente].[Contrato] C ON C.rfcEmpresa = VW.rfcEmpresa AND C.numeroContrato = VW.numeroContrato AND C.idCliente = VW.idCliente AND C.idClase = VW.idClase
    WHERE VW.[idSolicitud] = @idSolicitud
	    AND VW.idEstatusCotizacionPartida IN ('ENESPERA','APROBADA')
		AND VW.idEstatusCotizacion NOT IN ('CANCELADA','RECHAZADA')

drop table #partidasCotizaciones, #cotizaciones--, #propiedadPartida  
END
go

