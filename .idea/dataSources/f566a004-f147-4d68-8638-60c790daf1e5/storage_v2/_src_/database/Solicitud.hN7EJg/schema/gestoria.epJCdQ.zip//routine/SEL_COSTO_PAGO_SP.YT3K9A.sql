

-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <05-06-2019>
-- Description:	<Obtiene propiedades de objeto y sus documentos >
-- =============================================

/*

	------ Versionamiento
	Fecha 		Autor	Descrición
	 13/08/2019	José Etmanuel	Agregando clase a la función Objeto.objeto.getPropiedadObjeto
 
	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[SEL_COSTO_PAGO_SP]  'Automovil', '02',6036, @salida OUTPUT;
	SELECT @salida AS salida;
*/

CREATE PROCEDURE [gestoria].[SEL_COSTO_PAGO_SP]
      @idClase				varchar(20),
	  @idEstado				varchar(2),
	  @idUsuario			INT,	
	  @err					varchar(max) OUTPUT

AS

BEGIN

	IF OBJECT_ID('tempdb..#datos') IS NOT NULL
		BEGIN
			DROP TABLE #datos
		END

	DECLARE @columnsName varchar(max) = ''

	SET @columnsName = STUFF((SELECT ',' + QUOTENAME(nombre) 
						FROM gestoria.concepto where idClase = @idClase and activo = 1
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')


	SELECT
		O.idObjeto,
		TOB.idTipoObjeto,
		(SELECT [objeto].objeto.[getPropiedadObjeto](O.idObjeto,'modelo', 'clase',@idClase)) as modelo,
		(SELECT [objeto].objeto.[getPropiedadObjeto](O.idObjeto,'vin', 'clase',@idClase)) as vin,
		(SELECT [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](TOB.idTipoObjeto,'Submarca',@idClase)) as marca,
		(SELECT [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](TOB.idTipoObjeto,'Combustible',@idClase)) as combustible,
		CON.nombre as concepto,
		C.costo
	INTO #datos
	FROM objeto.objeto.objeto O
	LEFT JOIN partida.tipoObjeto.tipoObjeto TOB ON TOB.idTipoObjeto = O.idTipoObjeto
	LEFT JOIN gestoria.costo C ON C.idTipoObjeto = TOB.idTipoObjeto AND idEstado = @idEstado
	LEFT JOIN gestoria.Concepto CON ON CON.idConcepto = C.idCOncepto
	WHERE O.activo = 1
	ORDER BY O.idObjeto, TOB.idTipoObjeto
	

	declare @query varchar(max)
	set @query = '

	select * 
	from #datos 
	PIVOT (SUM(costo) for concepto in(' + @columnsName + ')) AS tblPiv'

	execute (@query)

	SELECT idConcepto,nombre 
	from gestoria.concepto 
	where activo = 1 
	and idClase = @idClase
END
go

