




-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener los totales por cotizacion>
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
	28/09/2020	JLuis Lozada	se agrego campo descuentoCosto

	SELECT	[idSolicitud]
			,[idCotizacion]
			,[idTipoSolicitud]
			,[idClase]
			,[rfcEmpresa]
			,[numeroContrato]
			,[idCliente]
			,[rfcProveedor]
			,[idProveedorEntidad]
			,[subTotalCosto]
			,[IVACosto]
			,[totalCosto]
			,[subTotalVenta]
			,[IVAVenta]
			,[totalVenta]
	FROM	[solicitud].[SEL_TOTALES_COTIZACION_VW]

*/
CREATE VIEW [solicitud].[SEL_TOTALES_COTIZACION_VW]
AS

SELECT 
    [idSolicitud]
    ,[idCotizacion]
    ,[idTipoSolicitud]
    ,[idClase]
    ,[rfcEmpresa]
    ,[numeroContrato]
    ,[idCliente]
    ,[rfcProveedor]
    ,[idProveedorEntidad]
    ,SUM([subTotalCosto]) subTotalCosto
    ,SUM([IVACosto]) IVACosto
    ,SUM([totalCosto]) totalCosto
    ,SUM([subTotalVenta]) subTotalVenta
    ,SUM([IVAVenta]) IVAVenta
    ,SUM([totalVenta]) totalVenta
	,SUM(subTotalVentaSinDescuento) subTotalVentaSinDescuento
	,SUM(descuentoVenta) descuentoVenta
	,SUM(descuentoCosto) descuentoCosto
FROM [Solicitud].[solicitud].[SEL_TOTALES_PARTIDAS_VW]
WHERE idEstatusCotizacionPartida NOT IN ('CANCELADA','RECHAZADA')
AND idEstatusCotizacion NOT IN('CANCELADA','RECHAZADA')
GROUP BY [idSolicitud]
    ,[idCotizacion]
    ,[idTipoSolicitud]
    ,[idClase]
    ,[rfcEmpresa]
    ,[numeroContrato]
    ,[idCliente]
    ,[rfcProveedor]
    ,[idProveedorEntidad]


go

