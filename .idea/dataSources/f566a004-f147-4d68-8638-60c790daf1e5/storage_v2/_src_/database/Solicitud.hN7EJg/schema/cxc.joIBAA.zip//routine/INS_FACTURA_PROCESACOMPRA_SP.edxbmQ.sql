

--use solicitud
-- =============================================
-- Author:		JLLOZADA
-- Create date: 23/07/2019
-- Description:	Hace insercion a tablas de bpro.
-- ============== Versionamiento ================  
/*  
 Fecha			Autor		Descripción   
 16/04/2020		ADOLFO		Se modifica el stored para que pueda soportar el poder procesar compra incluso no tenga una factura cargada y reglas para COPADE
								Regla 1.- Si no tiene Factura cargada la solicitud tendra que generar una factura dommy mientras se le carga la factura que le corresponde y los datos 
										  que se procesen en la compra seran guardados con los datos de esta factura dommy registrada
								Regla 2.- Unicamente cuando este en cobranza y no necesitar de tener copade avanzara a prefactura Generada y si necesita Copade se quedara en cobranza
								Regla 3.- Si se encuentra en en la fase de en Proceso, en Entrega se tendra que evitar que avance la orden de paso
							Observaciones:
								La nomenclatura de la factura sera NA-OTE_IDENT-AÑO
								Los demas datos de la factura dommy se insertaran como NA
 17/04/2020		JLLOZADA	Se modificaron los querys que insertan a tablas de bpro, se hicieron dinamicos recuperando configuracion de common.configuracion.FacturacionBPRO en funcion al contrato de la orden
 --CAST((CAST(vw.ivacosto AS FLOAT)/CAST(vw.subTotalCosto AS FLOAT)*100) AS INTEGER) OTE_TASAIVA,
 21/07/2020		ADOLFO		Se modifica el stored para que pueda soportar manejo de impuestos

*- Testing...  

DECLARE @err VARCHAR(8000)=''
EXEC cxc.INS_FACTURA_PROCESACOMPRA_SP 396,'Imagen','Automovil','ASE0508051B6',185,'43',2927,''
SELECT @err

*/
-- =============================================
CREATE PROCEDURE [cxc].[INS_FACTURA_PROCESACOMPRA_SP]
@idSolicitud		INT,
@idTipoSolicitud	VARCHAR(10),
@idClase			VARCHAR(10),
@rfcEmpresa			VARCHAR(13),
@idCliente			INT,
@numeroContrato		VARCHAR(50),
@idUsuario			INT,
@err				VARCHAR(8000) = '' OUTPUT	
AS
BEGIN
	BEGIN TRY
		--BEGIN TRANSACTION
		DECLARE @tabletemp TABLE(val INT)
		DECLARE	@ote_ident				NUMERIC(18,0)
		DECLARE @ote_facturacompra		VARCHAR(50) = ''
		DECLARE @ote_tasaiva		    NUMERIC(18,0)
		DECLARE @v_iva					NUMERIC(18,2)
		DECLARE @ote_retiva				NUMERIC(18,2)
		DECLARE @ote_retisr				NUMERIC(18,2)
		DECLARE @otd_retiva				NUMERIC(18,2)
		DECLARE @otd_retisr				NUMERIC(18,2)
		DECLARE @txDatos				TABLE(	id INT IDENTITY(1,1),idCotizacion INT,numeroCotizacion VARCHAR(50))
		DECLARE @v_idCotizacion			INT,@v_numeroCotizacion	VARCHAR(50),@v_idd	INT, @v_idFactura INT
		DECLARE @v_idObjeto				INT, 
				@v_idTipoObjeto			INT,
				@v_folioFactura			NVARCHAR(100),
				@v_folioFacUUID			NVARCHAR(100),
				@v_ano					NVARCHAR(100)=CONVERT(varchar(5), YEAR(GETDATE())),
				@v_rfcClienteEntidad	NVARCHAR(13),
				@v_instancia			NVARCHAR(150),
				@v_nombreBD				NVARCHAR(150),
				@v_sq					NVARCHAR(MAX)='',
				@v_existe				INT,
				@v_numeroOrden			VARCHAR(50),
				@v_idBPROProveedor		INT,
				@v_idBPROCliente		INT,
				@v_countUUID			INT,
				@queryText              varchar(max)='',
				@v_observaciones        varchar(max)=''

		SELECT  @v_instancia=instancia,@v_nombreBD=nombreBD 
		FROM	common.configuracion.FacturacionBPRO fac 
		INNER	JOIN cliente.cliente.contrato co ON  fac.idFacturacionBPRO=co.idFacturacionBPRO 
		WHERE	co.rfcEmpresa		=@rfcEmpresa
		AND		co.idCliente		=@idCliente
		AND		co.numeroContrato	=@numeroContrato
		AND		fac.activo			=1 
		print @v_instancia
		IF LEN(@v_instancia)>0 AND LEN(@v_nombreBD)>0
			BEGIN
				SELECT	@v_rfcClienteEntidad=ISNULL(CO.rfcClienteEntidad,''),
						@v_idObjeto			=SO.idObjeto,
						@v_idTipoObjeto		=SO.idTipoObjeto,
						@v_numeroOrden		=SO.numeroOrden,
						@v_idBPROCliente	=CBPRO.idBPro
				FROM	Solicitud.solicitud.SolicitudObjeto SO
				LEFT	JOIN Cliente.contrato.Objeto CO ON CO.idTipoObjeto=SO.idTipoObjeto AND CO.idObjeto=SO.idObjeto AND CO.rfcEmpresa=SO.rfcEmpresa AND CO.idCliente=SO.idCliente AND CO.numeroContrato=SO.numeroContrato AND CO.idClase=SO.idClase
				LEFT	JOIN [Cliente].[cliente].[ContratoBPRO] CBPRO ON CBPRO.rfcClienteEntidad = CO.rfcClienteEntidad AND CBPRO.rfcEmpresa = CO.rfcEmpresa AND CBPRO.idCliente = CO.idCliente AND CBPRO.numeroContrato = CO.numeroContrato
				WHERE	SO.idSolicitud=@idSolicitud
				AND		SO.rfcEmpresa= @rfcEmpresa
				AND		SO.idCliente=@idCliente
				AND		SO.numeroContrato=@numeroContrato
				AND		SO.idClase=@idClase
				AND		SO.idTipoSolicitud=@idTipoSolicitud
				print @v_idBPROCliente

						INSERT INTO @txDatos(idCotizacion,numeroCotizacion)
						SELECT  SC.idCotizacion,SC.numeroCotizacion 
						FROM	solicitud.solicitud.SolicitudCotizacion SC 
						INNER JOIN solicitud.Sel_totales_cotizacion_vw vw ON SC.idCotizacion = vw.idCotizacion
						WHERE	sc.idSolicitud		=@idSolicitud
						AND     sc.idTipoSolicitud	=@idTipoSolicitud
						AND     sc.idClase			=@idClase
						AND     sc.rfcEmpresa		=@rfcEmpresa
						AND     sc.idCliente		=@idCliente
						AND     sc.numeroContrato	=@numeroContrato

						WHILE EXISTS  (SELECT 1 FROM @txDatos)
							BEGIN
								SELECT TOP 1 @v_idd=id,@v_idCotizacion=idCotizacion,@v_numeroCotizacion=numeroCotizacion FROM @txDatos
				
								PRINT '************************************************************************************************************************'
								PRINT 'Insertando idCotizacion:'+CAST(@v_idCotizacion as varchar) +' numeroCotizacion:'+ @v_numeroCotizacion +' en tabla [cxc].[factura]'
								IF NOT EXISTS(SELECT 1 FROM [cxc].[factura] WHERE idCotizacion = @v_idCotizacion AND idSolicitud= @idSolicitud)
									BEGIN
										PRINT '0.1'
										INSERT INTO [cxc].[factura](idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,rfcClienteEntidad,numeroContrato,idProveedorEntidad,
																	rfcProveedor,numeroCotizacion,numeroFactura,subtotal,iva,total,fechaAlta,idEstatus,idUsuario)

										SELECT  sc.idCotizacion,sc.idSolicitud,sc.idTipoSolicitud,sc.idClase,sc.rfcEmpresa,sc.idCliente,@v_rfcClienteEntidad,sc.numeroContrato,
												sc.idProveedorEntidad,sc.rfcProveedor,sc.numeroCotizacion,null,vw.subTotalVenta,vw.IVAVenta,totalVenta,getdate(),'Provisionada',@idUsuario
										FROM	solicitud.solicitud.Solicitud s,
												solicitud.SolicitudCotizacion sc,
												solicitud.Sel_totales_cotizacion_vw vw
										WHERE	
												s.idSolicitud			=sc.idSolicitud
										AND		s.idTipoSolicitud		=sc.idTipoSolicitud
										AND		s.idClase				=sc.idClase
										AND		s.rfcEmpresa			=sc.rfcEmpresa
										AND		s.idCliente				=sc.idCliente
										AND		s.numeroContrato		=sc.numeroContrato
										AND     sc.idSolicitud			=vw.idSolicitud
										AND		sc.idTipoSolicitud		=vw.idTipoSolicitud
										AND		sc.idClase				=vw.idClase
										AND		sc.rfcEmpresa			=vw.rfcEmpresa
										AND		sc.idCliente			=vw.idCliente
										AND		sc.numeroContrato		=vw.numeroContrato
										AND     sc.idCotizacion			=vw.idCotizacion
										AND     sc.idProveedorEntidad	=vw.idProveedorEntidad
										AND     sc.rfcProveedor			=vw.rfcProveedor
										AND     sc.idSolicitud			=@idSolicitud
										AND     sc.idTipoSolicitud		=@idTipoSolicitud
										AND     sc.idClase				=@idClase
										AND     sc.rfcEmpresa			=@rfcEmpresa
										AND     sc.idCliente			=@idCliente
										AND     sc.numeroContrato		=@numeroContrato
										AND     sc.numeroCotizacion		=@v_numeroCotizacion
										AND     sc.idCotizacion			=@v_idCotizacion

										SET @v_idFactura=@@IDENTITY

										PRINT '************************************************************************************************************************'
										PRINT 'Insertando idCotizacion:'+cast(@v_idCotizacion AS VARCHAR) +' numeroCotizacion:'+ @v_numeroCotizacion +' en tabla [cxc].[facturaDetalle]'
										INSERT INTO cxc.facturaDetalle(	idFactura,idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,idProveedorEntidad,
																		rfcProveedor,numeroCotizacion,consecutivo,descripcion,cantidad,precioUnitarioCompra,subtotalCompra,ivaCompra,totalCompra,
																		precioUnitarioVenta,subtotalVenta,ivaVenta,totalVenta,fechaAlta,idUsuario)
										SELECT  @v_idFactura,vw.idCotizacion,s.idSolicitud,s.idTipoSolicitud,s.idClase,s.rfcEmpresa,
												s.idCliente,s.numeroContrato,vw.idproveedorEntidad,vw.rfcProveedor,sc.numeroCotizacion,
												ROW_NUMBER() OVER(ORDER BY vw.cantidad ASC),
												ISNULL((SELECT	valor 
														FROM	[Partida].[partida].[PartidaPropiedadGeneral] 
														WHERE	idPropiedadGeneral =(	SELECT	TOP 1 
																								idPropiedadGeneral 
																						FROM	partida.partida.propiedadGeneral 
			
	

																		WHERE	agrupador	='Descripción')
														AND		idPartida		=	vw.idPartida 
														AND		idTipoObjeto	=	@v_idTipoObjeto
														AND     idClase			=	@idClase),'')	descripcion,
												vw.cantidad,vw.costo,vw.subTotalCosto,vw.IVACosto,vw.totalCosto,vw.venta,vw.subtotalVenta,vw.ivaVenta,vw.totalVenta,GETDATE(),@idUsuario
										FROM	solicitud.solicitud.Solicitud s,
												solicitud.SolicitudCotizacion sc,
												solicitud.Sel_totales_partidas_vw vw
										WHERE	
												s.idSolicitud			=sc.idSolicitud
										AND		s.idTipoSolicitud		=sc.idTipoSolicitud
										AND		s.idClase				=sc.idClase
										AND		s.rfcEmpresa			=sc.rfcEmpresa
										AND		s.idCliente				=sc.idCliente
										AND		sc.numeroContrato		=sc.numeroContrato
							
										AND		sc.idSolicitud			=vw.idSolicitud
										AND     sc.idTipoSolicitud		=vw.idTipoSolicitud
										AND     sc.idClase				=vw.idClase
										AND     sc.rfcEmpresa			=vw.rfcEmpresa
										AND     sc.idCliente			=vw.idCliente
										AND     sc.numeroContrato		=vw.numeroContrato
										AND     sc.idCotizacion			=vw.idCotizacion
										AND     sc.idProveedorEntidad	=vw.idProveedorEntidad
										AND     sc.rfcProveedor			=vw.rfcProveedor
										AND     vw.idSolicitud			=@idSolicitud
										AND     vw.idTipoSolicitud		=@idTipoSolicitud
										AND     vw.idClase				=@idClase
										AND     vw.rfcEmpresa			=@rfcEmpresa
										AND     vw.idCliente			=@idCliente
										AND     vw.idEstatusCotizacionPartida ='APROBADA'
										AND     sc.numeroCotizacion		=@v_numeroCotizacion
										AND     sc.idCotizacion			=@v_idCotizacion
									END

									IF EXISTS(SELECT 1 FROM cxp.SolicitudCotizacionFactura scf WHERE scf.idSolicitud=@idSolicitud AND scf.idCotizacion=@v_idCotizacion)
										BEGIN
											PRINT '***************************************************************************************************************************************************'
											PRINT 'Insertando idCotizacion:'+CAST(@v_idCotizacion AS VARCHAR) +' numeroCotizacion:'+ @v_numeroCotizacion +' en tabla ASEPROTSISCOV3.DBO.ADE_ORDSERENC'
											PRINT '1.1'
											DELETE FROM @tabletemp 
											SET @queryText='SELECT CASE WHEN exists(SELECT 1 FROM '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC WHERE OTE_ORDENPEMEX = '''+ @v_numeroCotizacion +''') then 1 else 0 end'

											PRINT @queryText
											INSERT INTO @tabletemp 
											EXEC (@queryText)
											PRINT '1.2'

											IF ((SELECT TOP 1 val FROM @tabletemp) = 0)
												BEGIN
													PRINT '1.3'
													SELECT 
														@v_idBPROProveedor = PE.idBPRO 
													FROM [Solicitud].[solicitud].[SolicitudCotizacion] SC
														JOIN [Cliente].[Cliente].[Contrato] CO ON CO.rfcEmpresa=SC.rfcEmpresa AND CO.idCliente=SC.idCliente AND CO.numeroContrato=SC.numeroContrato AND CO.idClase=SC.idClase
														JOIN [Proveedor].[Proveedor].[proveedorEmpresa] PE ON PE.rfcProveedor = SC.rfcProveedor AND PE.rfcEmpresa = SC.rfcEmpresa AND PE.idPersonaBPRO=CO.idPersonaBPRO
													WHERE	SC.idSolicitud=@idSolicitud
													AND		SC.rfcEmpresa= @rfcEmpresa
													AND		SC.idCliente=@idCliente
													AND		SC.numeroContrato=@numeroContrato
													AND		SC.idClase=@idClase
													AND		SC.idTipoSolicitud=@idTipoSolicitud
													AND		SC.idCotizacion = @v_idCotizacion
													SET @v_observaciones = (SELECT [solicitud].[getObservaciones](@v_idCotizacion))
													PRINT '1.3.1'
													SELECT 
														@ote_facturacompra =  ISNULL(F.serie,'') + ISNULL(F.folio, '')
													FROM [Solicitud].[cxp].[SolicitudCotizacionFactura] SCF
														JOIN [Solicitud].[cxp].[Factura] F ON F.uuid = SCF.uuid
														LEFT JOIN [cxp].[FacturaImpuesto] FI ON FI.uuidFactura = F.uuid
													WHERE SCF.idSolicitud = @idSolicitud AND SCF.idCotizacion = @v_idCotizacion
													PRINT '1.3.2'
													--SELECT TFI.tasa FROM [cxp].[TipoFacturaImpuesto] TFI JOIN [cxp].[Tipo] TT ON TT.idTipo = TFI.idTipo AND TT.descripcion='Traslado' WHERE TFI.impuesto='IVA'
													SELECT TOP 1
														@ote_tasaiva = 
														ISNULL((SELECT TOP 1 CAST(REPLACE(FI.tasa, '0.','') AS INT) FROM [cxp].[FacturaImpuesto] FI
														LEFT JOIN [cxp].[TipoFacturaImpuesto] TI ON TI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto AND TI.impuesto='IVA'
														LEFT JOIN [cxp].[Tipo] T ON T.idTipo = TI.idTipo AND T.descripcion='Traslado'
														WHERE FI.uuidFactura = SCF.uuid),(SELECT CAST(REPLACE(TFI.tasa, '0.','') AS INT) FROM [cxp].[TipoFacturaImpuesto] TFI JOIN [cxp].[Tipo] TT ON TT.idTipo = TFI.idTipo AND TT.descripcion='Traslado' WHERE TFI.impuesto='IVA')),
														@v_iva = 
														ISNULL((SELECT TOP 1 FI.tasa FROM [cxp].[FacturaImpuesto] FI
														LEFT JOIN [cxp].[TipoFacturaImpuesto] TI ON TI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto AND TI.impuesto='IVA'
														LEFT JOIN [cxp].[Tipo] T ON T.idTipo = TI.idTipo AND T.descripcion='Traslado'
														WHERE FI.uuidFactura = SCF.uuid),(SELECT TFI.tasa FROM [cxp].[TipoFacturaImpuesto] TFI JOIN [cxp].[Tipo] TT ON TT.idTipo = TFI.idTipo AND TT.descripcion='Traslado' WHERE TFI.impuesto='IVA')),
														@ote_retiva = 
														(SELECT TOP 1 FI.importe FROM [cxp].[FacturaImpuesto] FI
														JOIN [cxp].[TipoFacturaImpuesto] TI ON TI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto AND TI.impuesto='IVA'
														JOIN [cxp].[Tipo] T ON T.idTipo = TI.idTipo AND T.descripcion='Retención'
														WHERE FI.uuidFactura = SCF.uuid),
														@ote_retisr = 
														(SELECT TOP 1 FI.importe FROM [cxp].[FacturaImpuesto] FI
														JOIN [cxp].[TipoFacturaImpuesto] TI ON TI.idTipoFacturaImpuesto = FI.idTipoFacturaImpuesto AND TI.impuesto='ISR'
														JOIN [cxp].[Tipo] T ON T.idTipo = TI.idTipo AND T.descripcion='Retención'
														WHERE FI.uuidFactura = SCF.uuid)
													FROM [Solicitud].[cxp].[SolicitudCotizacionFactura] SCF
													WHERE SCF.idSolicitud = @idSolicitud AND SCF.idCotizacion = @v_idCotizacion
													PRINT '1.3.3'
													SET @ote_retiva = @ote_retiva/(SELECT COUNT(uuid) FROM [Solicitud].[cxp].[SolicitudCotizacionFactura] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=@idSolicitud AND idCotizacion=@v_idCotizacion))
													SET @ote_retisr = @ote_retisr/(SELECT COUNT(uuid) FROM [Solicitud].[cxp].[SolicitudCotizacionFactura] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=@idSolicitud AND idCotizacion=@v_idCotizacion))
													PRINT '1.4'
													SET @v_sq=''
													SET @v_sq+=' INSERT INTO '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC(OTE_ORDENPEMEX,OTE_ORDENANDRADE,OTE_REFERENCIA,OTE_IDPROVEEDOR,OTE_FECHAORDEN,OTE_FACTURACOMPRA,'
													SET @v_sq+=' OTE_TASAIVA,OTE_SUBTOTAL,OTE_IVA,OTE_TOTAL,OTE_UUID,OTE_XMLCOMPRA,OTE_FECHOPE,OTE_HORAOPE,OTE_STATUS,OTE_FECHAPROCESO,OTE_HORAPROCESO,OTE_ORDENGLOBAL,'
													SET @v_sq+=' OTE_PDFCOMPRA,OTE_RUTAXML,OTE_RUTAPDF,OTE_IDCLIENTE,OTE_DESGLOSE,OTE_SUBMO,OTE_SUBREF,OTE_SUBLUB,OTE_OBSERVACIONES,OTE_NUMPOLIZA,OTE_NUMSINIESTRO,OTE_GENERA,OTE_PORREF,OTE_IVAOC,OTE_RETIVA,OTE_RETISR,OTE_COMPROBANTE) '
													SET @v_sq+=' SELECT	sc.numeroCotizacion AS OTE_ORDENPEMEX,'
													SET @v_sq+='		ISNULL((SELECT	numeroOrden FROM solicitud.solicitud.solicitudObjeto WHERE idSolicitud=s.idSolicitud AND idTipoSolicitud=s.idTipoSolicitud '
													SET @v_sq+='				AND     idClase	= s.idClase AND rfcEmpresa =s.rfcEmpresa AND idCliente=s.idCliente AND numeroContrato=s.numeroContrato '
													SET @v_sq+='				AND     idObjeto = @v_idObjeto AND idTipoObjeto=@v_idTipoObjeto),''xx'')OTE_ORDENANDRADE,''01'' OTE_REFERENCIA,'
													SET @v_sq+='		'+  CAST(@v_idBPROProveedor AS NVARCHAR(30)) +'  OTE_IDPROVEEDOR,'
													SET @v_sq+='		CONVERT(NVARCHAR(10),ISNULL(s.fechaCreacion, GETDATE()),103) OTE_FECHAORDEN, '''+ @ote_facturacompra +''' OTE_FACTURACOMPRA, '+ CAST(@ote_tasaiva AS NVARCHAR(30)) +' OTE_TASAIVA, '
													SET @v_sq+='		vw.subTotalCosto OTE_SUBTOTAL,vw.subTotalCosto * '+ CAST(@v_iva AS NVARCHAR(30)) +' OTE_IVA,vw.subTotalCosto + vw.subTotalCosto * '+ CAST(@v_iva AS NVARCHAR(30)) +' OTE_TOTAL,fac.uuid OTE_UUID,'
													SET @v_sq+='		ISNULL((SELECT	TOP 1 nombreOriginal FROM fileserver.documento.documento WHERE	idDocumento=fac.idDocumentoXml),''SIN DATO'') OTE_XMLCOMPRA,'
													SET @v_sq+='		CONVERT(VARCHAR(10),GETDATE(),103) OTE_FECHOPE,CONVERT(TIME,GETDATE(),103) OTE_HORAOPE,1 OTE_STATUS,'''' OTE_FECHAPROCESO,'''' OTE_HORAPROCESO,NULL OTE_ORDENGLOBAL,'
													SET @v_sq+='		ISNULL((SELECT TOP 1 nombreOriginal FROM fileserver.documento.documento WHERE idDocumento=fac.idDocumentoPdf),''SIN DATO'') OTE_PDFCOMPRA,'
													SET @v_sq+='		ISNULL((SELECT	TOP 1 PATH FROM	fileserver.documento.documento WHERE idDocumento=fac.idDocumentoXml),''SIN DATO'') OTE_RUTAXML,'
													SET @v_sq+='		ISNULL((SELECT	TOP 1 PATH FROM	fileserver.documento.documento WHERE idDocumento=fac.idDocumentoPdf),''SIN DATO'') OTE_RUTAPDF,'
													SET @v_sq+='		'+  CAST(@v_idBPROCliente AS NVARCHAR(30)) +' OTE_IDCLIENTE,'
													SET @v_sq+='		''A'' OTE_DESGLOSE,NULL OTE_SUBMO,NULL OTE_SUBREF,NULL OTE_SUBLUB,'''+@v_observaciones+''' OTE_OBSERVACIONES,NULL OTE_NUMPOLIZA,NULL OTE_NUMSINIESTRO,'''' OTE_GENERA, ''0'' OTE_PORREF, ''16'' OTE_IVAOC, '+ CASE WHEN @ote_retiva IS NULL THEN 'NULL' ELSE CAST(@ote_retiva AS NVARCHAR(30)) END +' OTE_RETIVA, '+ CASE WHEN @ote_retisr IS NULL THEN 'NULL' ELSE CAST(ISNULL(@ote_retisr,'0') AS NVARCHAR(30)) END +' OTE_RETISR, NULL OTE_COMPROBANTE '
													SET @v_sq+=' FROM   solicitud.solicitud.Solicitud s,solicitud.SolicitudCotizacion sc,solicitud.Sel_totales_cotizacion_vw vw,cxp.SolicitudCotizacionFactura scf,cxp.factura fac '
													SET @v_sq+=' WHERE	s.idSolicitud = sc.idSolicitud AND s.idTipoSolicitud = sc.idTipoSolicitud AND s.idClase = sc.idClase AND s.rfcEmpresa = sc.rfcEmpresa'
													SET @v_sq+=' AND	s.idCliente = sc.idCliente AND s.numeroContrato = sc.numeroContrato AND sc.idSolicitud = scf.idSolicitud AND sc.idTipoSolicitud = scf.idTipoSolicitud'
													SET @v_sq+=' AND	sc.idClase = scf.idClase AND sc.rfcEmpresa = scf.rfcEmpresa AND sc.idCliente = scf.idCliente AND sc.numeroContrato = scf.numeroContrato'
													SET @v_sq+=' AND    sc.idCotizacion = scf.idCotizacion AND sc.idSolicitud = vw.idSolicitud AND sc.idTipoSolicitud = vw.idTipoSolicitud AND sc.idClase = vw.idClase'
													SET @v_sq+=' AND	sc.rfcEmpresa = vw.rfcEmpresa AND sc.idCliente = vw.idCliente AND sc.numeroContrato = vw.numeroContrato AND sc.idCotizacion = vw.idCotizacion'
													SET @v_sq+=' AND    sc.idProveedorEntidad = vw.idProveedorEntidad AND sc.rfcProveedor = vw.rfcProveedor AND scf.uuid = fac.uuid AND scf.idSolicitud = @idSolicitud'
													SET @v_sq+=' AND    scf.idTipoSolicitud = @idTipoSolicitud AND scf.idClase = @idClase AND scf.rfcEmpresa = @rfcEmpresa AND scf.idCliente = @idCliente'
													SET @v_sq+=' AND    scf.numeroContrato = @numeroContrato AND sc.numeroCotizacion = @v_numeroCotizacion AND sc.idCotizacion = @v_idCotizacion ' 
													PRINT @v_sq
													PRINT '1.5'
													EXEC sp_executesql  @v_sq, N'@v_idObjeto INT,@v_idTipoObjeto INT,@idSolicitud INT,@idTipoSolicitud VARCHAR(10),@idClase VARCHAR(10),@rfcEmpresa VARCHAR(13),@idCliente INT,@numeroContrato VARCHAR(50),@v_numeroCotizacion VARCHAR(50),@v_idCotizacion INT',
																		@v_idObjeto			=@v_idObjeto,
																		@v_idTipoObjeto		=@v_idTipoObjeto,
																		@idSolicitud		=@idSolicitud,
																		@idTipoSolicitud	=@idTipoSolicitud,
																		@idClase			=@idClase,
																		@rfcEmpresa			=@rfcEmpresa,
																		@idCliente			=@idCliente,
																		@numeroContrato		=@numeroContrato,
																		@v_numeroCotizacion	=@v_numeroCotizacion,
																		@v_idCotizacion		=@v_idCotizacion
																	
													SET @v_sq='SELECT	TOP 1 @ote_ident=ote_ident FROM '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC WHERE OTE_ORDENPEMEX=@v_numeroCotizacion AND OTE_ORDENANDRADE=@v_numeroOrden ORDER BY CAST(OTE_FECHOPE+'' ''+OTE_HORAOPE AS DATETIME) DESC'
													EXEC sp_executesql  @v_sq, N'@v_numeroCotizacion VARCHAR(50),@v_numeroOrden VARCHAR(50),@ote_ident NUMERIC(18,0) OUTPUT',
																		@v_numeroCotizacion =@v_numeroCotizacion,
																		@v_numeroOrden		=@v_numeroOrden,
																		@ote_ident			=@ote_ident OUTPUT

													PRINT '@ote_ident=>'+CAST(ISNULL(@ote_ident,-1) AS VARCHAR)

													SET @v_countUUID = (SELECT COUNT(1) FROM [cxp].[SolicitudCotizacionFactura] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=@idSolicitud AND idCotizacion=@v_idCotizacion))
													IF(@v_countUUID >= 2)
														BEGIN
															PRINT 'Repetido UUID'

															SET @v_folioFactura = 'VI-'+CONVERT(VARCHAR(18), @ote_ident)+'-'+ @v_ano
															
															SET @v_sq=''
															SET @v_sq+='UPDATE '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC SET OTE_FACTURACOMPRA=@v_folioFactura, OTE_UUID=''NA'', OTE_XMLCOMPRA='''', OTE_PDFCOMPRA='''', OTE_RUTAXML='''', OTE_RUTAPDF='''' WHERE OTE_IDENT=@ote_ident '
															EXEC sp_executesql  @v_sq, N'@v_folioFactura nvarchar(100),@ote_ident NUMERIC(18,0)',
																				@v_folioFactura	=@v_folioFactura,
																				@ote_ident		=@ote_ident	
															
															INSERT INTO [cxc].[FacturaBPRO] (idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,OTE_IDENT,OTE_FACTURACOMPRA,fechaAlta,idUsuario,activo)
															SELECT idCotizacion, idSolicitud, idTipoSolicitud, idClase, rfcEmpresa, idCliente, numeroContrato, @ote_ident, @v_folioFactura,GETDATE(),@idUsuario,1
															FROM [cxc].[factura] WHERE idCotizacion = @v_idCotizacion AND idSolicitud= @idSolicitud	
														
														END
													ELSE
														BEGIN
															INSERT INTO [cxc].[FacturaBPRO] (idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,OTE_IDENT,OTE_FACTURACOMPRA,fechaAlta,idUsuario,activo)
															SELECT idCotizacion, idSolicitud, idTipoSolicitud, idClase, rfcEmpresa, idCliente, numeroContrato, @ote_ident, @ote_facturacompra,GETDATE(),@idUsuario,1
															FROM [cxc].[factura] WHERE idCotizacion = @v_idCotizacion AND idSolicitud= @idSolicitud
														END
													PRINT '***************************************************************************************************************************************************'
													PRINT 'Insertando idCotizacion:'+CAST(@v_idCotizacion AS VARCHAR) +' numeroCotizacion:'+ @v_numeroCotizacion +' en tabla ASEPROTSISCOV3.DBO.ADE_ORDSERDET'
													
													PRINT '1.5.1'
													SET @otd_retiva = @ote_retiva/(SELECT COUNT(uuid) FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=@idSolicitud AND idCotizacion=@v_idCotizacion) AND idCotizacion=@v_idCotizacion) 
													SET @otd_retisr = @ote_retisr/(SELECT COUNT(uuid) FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaDetalle] where uuid IN(SELECT uuid FROM [cxp].[SolicitudCotizacionFactura] WHERE idSolicitud=@idSolicitud AND idCotizacion=@v_idCotizacion) AND idCotizacion=@v_idCotizacion) 
													
													PRINT @otd_retiva
													PRINT @otd_retisr
													PRINT '1.5.2'
													SET @v_sq=''
													SET @v_sq+=' INSERT INTO '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERDET ('	
													SET @v_sq+=' OTD_IDENT,OTD_CONSECUTIVO,OTD_DESCRIPCION,OTD_CANTIDAD,OTD_PRECIOUNITARIOCOMPRA, '
													SET @v_sq+=' OTD_SUBTOTALUNITARIO,OTD_IVAUNITARIO,OTD_TOTALUNITARIO,OTD_PRECIOUNITARIOVENTA,OTD_FECHOPE,OTD_HORAOPE,OTD_PORCENTAJE,OTD_IDPARTE,OTD_CVESAT,OTD_FAMILIA,OTD_RETIVA,OTD_RETISR,OTD_REFERENCIA) '
													SET @v_sq+=' SELECT	@ote_ident	OTD_IDENT,ROW_NUMBER() OVER(ORDER BY sp.cantidad ASC) OTD_CONSECUTIVO,ISNULL((SELECT valor FROM	[Partida].[partida].[PartidaPropiedadGeneral] '
													SET @v_sq+=' WHERE idPropiedadGeneral =( SELECT	TOP 1 idPropiedadGeneral FROM partida.partida.propiedadGeneral WHERE agrupador=''Descripción'') AND idPartida = sp.idPartida '
													SET @v_sq+=' AND idTipoObjeto=@v_idTipoObjeto AND idClase =@idClase),'''') OTD_DESCRIPCION,sp.cantidad OTD_CANTIDAD,sp.costo OTD_PRECIOUNITARIOCOMPRA,sp.subTotalCosto OTD_SUBTOTALUNITARIO, '
													SET @v_sq+=' sp.subTotalCosto * '+ CAST(@v_iva AS NVARCHAR(30)) +' OTD_IVAUNITARIO,sp.subTotalCosto + sp.subTotalCosto * '+ CAST(@v_iva AS NVARCHAR(30)) +' OTD_TOTALUNITARIO, sp.venta OTD_PRECIOUNITARIOVENTA, CONVERT(VARCHAR(10),GETDATE(),103) OTD_FECHOPE, CONVERT(VARCHAR(8),CONVERT(TIME,GETDATE(),103)) OTD_HORAOPE, '
													SET @v_sq+=' 16 OTD_PORCENTAJE,ISNULL((SELECT valor FROM [Partida].[partida].[PartidaPropiedadGeneral] WHERE idPropiedadGeneral	=(SELECT TOP 1 idPropiedadGeneral FROM	partida.partida.propiedadGeneral '
													SET @v_sq+=' WHERE agrupador=''noParte'') AND idPartida = sp.idPartida AND	idTipoObjeto = @v_idTipoObjeto AND idClase = @idClase),'''') OTD_IDPARTE, NULL OTD_CVESAT, NULL OTD_FAMILIA,'+ CASE WHEN @otd_retiva IS NULL THEN 'NULL' ELSE CAST(@otd_retiva AS NVARCHAR(30)) END +' OTD_RETIVA,'+ CASE WHEN @otd_retisr IS NULL THEN 'NULL' ELSE CAST(@otd_retisr AS NVARCHAR(30)) END +' OTD_RETISR, '''' OTD_REFERENCIA '
													SET @v_sq+=' FROM (SELECT  s.idSolicitud,s.idTipoSolicitud,s.idClase,s.rfcEmpresa,s.idCliente,s.numeroContrato,vw.idCotizacion,vw.idPartida,vw.cantidad,vw.costo,vw.subTotalCosto, '
													SET @v_sq+=' vw.IvaCosto,vw.totalCosto,vw.venta FROM solicitud.solicitud.Solicitud s,solicitud.SolicitudCotizacion sc,solicitud.SEL_TOTALES_PARTIDAS_VW vw WHERE s.idSolicitud=sc.idSolicitud '
													SET @v_sq+=' AND s.idTipoSolicitud = sc.idTipoSolicitud AND s.idClase = sc.idClase AND s.rfcEmpresa = sc.rfcEmpresa AND s.idCliente = sc.idCliente AND sc.numeroContrato = sc.numeroContrato '
													SET @v_sq+=' AND sc.idSolicitud =vw.idSolicitud AND sc.idTipoSolicitud = vw.idTipoSolicitud AND sc.idClase = vw.idClase AND sc.rfcEmpresa = vw.rfcEmpresa AND sc.idCliente = vw.idCliente '
													SET @v_sq+=' AND sc.numeroContrato = vw.numeroContrato AND sc.idCotizacion = vw.idCotizacion AND vw.idEstatusCotizacionPartida =''APROBADA'' AND sc.numeroCotizacion =@v_numeroCotizacion '
													SET @v_sq+=' AND sc.idCotizacion = @v_idCotizacion)sp '
													EXEC sp_executesql  @v_sq, N'@ote_ident NUMERIC(18,0),@v_idTipoObjeto INT,@idClase VARCHAR(10),@v_numeroCotizacion VARCHAR(50),@v_idCotizacion INT',
																		@ote_ident			=@ote_ident,
																		@v_idTipoObjeto		=@v_idTipoObjeto,
																		@idClase			=@idClase,
																		@v_numeroCotizacion	=@v_numeroCotizacion,
																		@v_idCotizacion		=@v_idCotizacion

													PRINT '1.6'
													--UPDATE [Solicitud].[cxc].[factura] 
													--SET OTE_IDENT=@ote_ident
													--WHERE idSolicitud =@idSolicitud 
													--AND idCotizacion=@v_idCotizacion

												END
										END
									ELSE
										BEGIN
											PRINT '2'
											PRINT '***************************************************************************************************************************************************'
											PRINT 'Insertando idCotizacion:'+cast(@v_idCotizacion AS VARCHAR) +' numeroCotizacion:'+ @v_numeroCotizacion +' en tabla ASEPROTSISCOV3.DBO.ADE_ORDSERENC'
											SET @v_iva = (SELECT TFI.tasa FROM [cxp].[TipoFacturaImpuesto] TFI JOIN [cxp].[Tipo] TT ON TT.idTipo = TFI.idTipo AND TT.descripcion='Traslado' WHERE TFI.impuesto='IVA')
											PRINT '2.1'
											DELETE FROM @tabletemp 
											SET @queryText='SELECT CASE WHEN exists(SELECT 1 FROM '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC WHERE OTE_ORDENPEMEX = '''+ @v_numeroCotizacion +''') then 1 else 0 end'
											PRINT @queryText
											INSERT INTO @tabletemp 
											EXEC (@queryText)
											PRINT '2.2'
											IF ((SELECT TOP 1 val FROM @tabletemp) = 0)
												BEGIN
													PRINT '2.3'
													SELECT 
														@v_idBPROProveedor = PE.idBPRO 
													FROM [Solicitud].[solicitud].[SolicitudCotizacion] SC
														JOIN [Cliente].[Cliente].[Contrato] CO ON CO.rfcEmpresa=SC.rfcEmpresa AND CO.idCliente=SC.idCliente AND CO.numeroContrato=SC.numeroContrato AND CO.idClase=SC.idClase
														JOIN [Proveedor].[Proveedor].[proveedorEmpresa] PE ON PE.rfcProveedor = SC.rfcProveedor AND PE.rfcEmpresa = SC.rfcEmpresa AND PE.idPersonaBPRO=CO.idPersonaBPRO
													WHERE	SC.idSolicitud=@idSolicitud
													AND		SC.rfcEmpresa= @rfcEmpresa
													AND		SC.idCliente=@idCliente
													AND		SC.numeroContrato=@numeroContrato
													AND		SC.idClase=@idClase
													AND		SC.idTipoSolicitud=@idTipoSolicitud
													AND		SC.idCotizacion = @v_idCotizacion
													SET @v_observaciones = (SELECT [solicitud].[getObservaciones](@v_idCotizacion))
													SELECT 
														@ote_facturacompra =  ISNULL(F.serie,'') + ISNULL(F.folio,'')
													FROM [Solicitud].[cxp].[SolicitudCotizacionFacturaPorConsolidar] SCF
														JOIN [Solicitud].[cxp].[FacturaPorConsolidar] F ON F.uuid = SCF.uuid
													WHERE SCF.idSolicitud = @idSolicitud AND SCF.idCotizacion = @v_idCotizacion

													PRINT '2.4'
													SET @v_sq=''
													SET @v_sq+=' INSERT INTO '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC(OTE_ORDENPEMEX,OTE_ORDENANDRADE,OTE_REFERENCIA,OTE_IDPROVEEDOR,OTE_FECHAORDEN,OTE_FACTURACOMPRA,'
													SET @v_sq+=' OTE_TASAIVA,OTE_SUBTOTAL,OTE_IVA,OTE_TOTAL,OTE_UUID,OTE_XMLCOMPRA,OTE_FECHOPE,OTE_HORAOPE,OTE_STATUS,OTE_FECHAPROCESO,OTE_HORAPROCESO,OTE_ORDENGLOBAL,'
													SET @v_sq+=' OTE_PDFCOMPRA,OTE_RUTAXML,OTE_RUTAPDF,OTE_IDCLIENTE,OTE_DESGLOSE,OTE_SUBMO,OTE_SUBREF,OTE_SUBLUB,OTE_OBSERVACIONES,OTE_NUMPOLIZA,OTE_NUMSINIESTRO,OTE_GENERA,OTE_PORREF,OTE_IVAOC) '
													SET @v_sq+=' SELECT	sc.numeroCotizacion AS OTE_ORDENPEMEX,'
													SET @v_sq+=' 		ISNULL((SELECT 	numeroOrden FROM	solicitud.solicitud.solicitudObjeto WHERE idSolicitud = s.idSolicitud AND idTipoSolicitud = s.idTipoSolicitud '
													SET @v_sq+='				AND 	idClase = s.idClase AND rfcEmpresa = s.rfcEmpresa AND idCliente = s.idCliente AND numeroContrato	=s.numeroContrato '
													SET @v_sq+='				AND 	idObjeto = @v_idObjeto AND idTipoObjeto = @v_idTipoObjeto),''xx'')OTE_ORDENANDRADE,''01'' OTE_REFERENCIA, '
													SET @v_sq+='		'+  CAST(@v_idBPROProveedor AS NVARCHAR(30)) +'  OTE_IDPROVEEDOR,'
													SET @v_sq+='		CONVERT(NVARCHAR(10),ISNULL(s.fechaCreacion, GETDATE()),103) OTE_FECHAORDEN,'''+ @ote_facturacompra +''' OTE_FACTURACOMPRA,CAST((CAST(vw.ivacosto AS FLOAT)/CAST(vw.subTotalCosto AS FLOAT)*100) AS INTEGER) OTE_TASAIVA, '
													SET @v_sq+='		vw.subTotalCosto OTE_SUBTOTAL,vw.IVACosto OTE_IVA,vw.subTotalCosto + vw.subTotalCosto * '+ CAST(@v_iva AS NVARCHAR(30)) +' OTE_TOTAL,''NA'' OTE_UUID, '
													SET @v_sq+='		ISNULL((SELECT TOP 1 nombreOriginal FROM fileserver.documento.documento WHERE idDocumento=fac.idDocumentoXml),'''') OTE_XMLCOMPRA, '
													SET @v_sq+='		CONVERT(VARCHAR(10),GETDATE(),103) OTE_FECHOPE,CONVERT(TIME,GETDATE(),103) OTE_HORAOPE,1 OTE_STATUS,'''' OTE_FECHAPROCESO,'''' OTE_HORAPROCESO,NULL OTE_ORDENGLOBAL, '
													SET @v_sq+='		ISNULL((SELECT TOP 1 nombreOriginal FROM fileserver.documento.documento WHERE idDocumento=fac.idDocumentoPdf),'''') OTE_PDFCOMPRA, '
													SET @v_sq+='		ISNULL((SELECT TOP 1 PATH FROM fileserver.documento.documento WHERE	idDocumento=fac.idDocumentoXml),'''') OTE_RUTAXML, '
													SET @v_sq+='		ISNULL((SELECT TOP 1 PATH FROM fileserver.documento.documento WHERE	idDocumento=fac.idDocumentoPdf),'''') OTE_RUTAPDF, '
													SET @v_sq+=' 		'+  CAST(@v_idBPROCliente AS NVARCHAR(30)) +' OTE_IDCLIENTE,'
													SET @v_sq+='		''A'' OTE_DESGLOSE,NULL OTE_SUBMO,NULL OTE_SUBREF,NULL OTE_SUBLUB, '''+@v_observaciones+''' OTE_OBSERVACIONES,NULL OTE_NUMPOLIZA,NULL OTE_NUMSINIESTRO,'''' OTE_GENERA, ''0'' OTE_PORREF, ''16'' OTE_IVAOC '
													SET @v_sq+=' FROM	solicitud.solicitud.Solicitud s,solicitud.SolicitudCotizacion sc,solicitud.Sel_totales_cotizacion_vw vw,cxp.SolicitudCotizacionFacturaPorConsolidar scf,cxp.facturaPorConsolidar fac '
													SET @v_sq+=' WHERE	s.idSolicitud = sc.idSolicitud AND s.idTipoSolicitud = sc.idTipoSolicitud AND s.idClase = sc.idClase AND s.rfcEmpresa = sc.rfcEmpresa '
													SET @v_sq+=' AND	s.idCliente = sc.idCliente AND s.numeroContrato = sc.numeroContrato AND sc.idSolicitud = scf.idSolicitud AND sc.idTipoSolicitud = scf.idTipoSolicitud '
													SET @v_sq+=' AND	sc.idClase = scf.idClase AND sc.rfcEmpresa = scf.rfcEmpresa AND sc.idCliente = scf.idCliente AND sc.numeroContrato = scf.numeroContrato '
													SET @v_sq+=' AND    sc.idCotizacion = scf.idCotizacion AND sc.idSolicitud = vw.idSolicitud AND sc.idTipoSolicitud = vw.idTipoSolicitud AND sc.idClase = vw.idClase '
													SET @v_sq+=' AND	sc.rfcEmpresa =vw.rfcEmpresa AND sc.idCliente = vw.idCliente AND sc.numeroContrato = vw.numeroContrato AND sc.idCotizacion = vw.idCotizacion '
													SET @v_sq+=' AND    sc.idProveedorEntidad = vw.idProveedorEntidad AND sc.rfcProveedor = vw.rfcProveedor AND scf.uuid = fac.uuid AND scf.idSolicitud = @idSolicitud '
													SET @v_sq+=' AND    scf.idTipoSolicitud = @idTipoSolicitud AND scf.idClase = @idClase AND scf.rfcEmpresa = @rfcEmpresa AND scf.idCliente = @idCliente '
													SET @v_sq+=' AND    scf.numeroContrato = @numeroContrato AND sc.numeroCotizacion = @v_numeroCotizacion AND sc.idCotizacion = @v_idCotizacion '
													PRINT '2.5'
													EXEC sp_executesql  @v_sq, N'@v_idObjeto INT,@v_idTipoObjeto INT,@idSolicitud INT,@idTipoSolicitud VARCHAR(10),@idClase VARCHAR(10),@rfcEmpresa VARCHAR(13),@idCliente INT,@numeroContrato VARCHAR(50),@v_numeroCotizacion VARCHAR(50),@v_idCotizacion INT',
																		@v_idObjeto			=@v_idObjeto,
																		@v_idTipoObjeto		=@v_idTipoObjeto,
																		@idSolicitud		=@idSolicitud,
																		@idTipoSolicitud	=@idTipoSolicitud,
																		@idClase			=@idClase,
																		@rfcEmpresa			=@rfcEmpresa,
																		@idCliente			=@idCliente,
																		@numeroContrato		=@numeroContrato,
																		@v_numeroCotizacion	=@v_numeroCotizacion,
																		@v_idCotizacion		=@v_idCotizacion

												
												
													SET @v_sq='SELECT	TOP 1 @ote_ident=ote_ident FROM '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC WHERE OTE_ORDENPEMEX=@v_numeroCotizacion AND OTE_ORDENANDRADE=@v_numeroOrden ORDER BY CAST(OTE_FECHOPE+'' ''+OTE_HORAOPE AS DATETIME) DESC'
													EXEC sp_executesql  @v_sq, N'@v_numeroCotizacion VARCHAR(50),@v_numeroOrden VARCHAR(50),@ote_ident NUMERIC(18,0) OUTPUT',
																		@v_numeroCotizacion =@v_numeroCotizacion,
																		@v_numeroOrden		=@v_numeroOrden,
																		@ote_ident			=@ote_ident OUTPUT

													PRINT '@ote_ident=>'+CAST(ISNULL(@ote_ident,-1) AS VARCHAR)
												
													PRINT '***************************************************************************************************************************************************'
													PRINT 'Insertando idCotizacion:'+cast(@v_idCotizacion as varchar) +' numeroCotizacion:'+ @v_numeroCotizacion +' en tabla ASEPROTSISCOV3.DBO.ADE_ORDSERDET'
												
													SET @v_sq=''
													SET @v_sq+=' INSERT INTO '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERDET ('	
													SET @v_sq+=' OTD_IDENT,OTD_CONSECUTIVO,OTD_DESCRIPCION,OTD_CANTIDAD,OTD_PRECIOUNITARIOCOMPRA, '
													SET @v_sq+=' OTD_SUBTOTALUNITARIO,OTD_IVAUNITARIO,OTD_TOTALUNITARIO,OTD_PRECIOUNITARIOVENTA,OTD_FECHOPE,OTD_HORAOPE,OTD_PORCENTAJE,OTD_IDPARTE,OTD_CVESAT,OTD_FAMILIA,OTD_REFERENCIA) '
													SET @v_sq+=' SELECT	@ote_ident	OTD_IDENT,ROW_NUMBER() OVER(ORDER BY sp.cantidad ASC) OTD_CONSECUTIVO,ISNULL((SELECT valor FROM	[Partida].[partida].[PartidaPropiedadGeneral] '
													SET @v_sq+=' WHERE	idPropiedadGeneral =( SELECT TOP 1 idPropiedadGeneral FROM partida.partida.propiedadGeneral WHERE	agrupador=''Descripción'') AND idPartida = sp.idPartida '
													SET @v_sq+=' AND idTipoObjeto = @v_idTipoObjeto AND idClase = @idClase),'''')	OTD_DESCRIPCION,sp.cantidad OTD_CANTIDAD, sp.costo OTD_PRECIOUNITARIOCOMPRA, sp.subTotalCosto OTD_SUBTOTALUNITARIO, '
													SET @v_sq+=' sp.IVACosto OTD_IVAUNITARIO,sp.subTotalCosto + sp.subTotalCosto * '+ CAST(@v_iva AS NVARCHAR(30)) +' OTD_TOTALUNITARIO,sp.venta OTD_PRECIOUNITARIOVENTA,CONVERT(VARCHAR(10),GETDATE(),103) OTD_FECHOPE,  CONVERT(VARCHAR(8),CONVERT(TIME,GETDATE(),103)) OTD_HORAOPE, '
													SET @v_sq+=' 16 OTD_PORCENTAJE,ISNULL((SELECT valor FROM [Partida].[partida].[PartidaPropiedadGeneral] WHERE idPropiedadGeneral	=(SELECT TOP 1 idPropiedadGeneral FROM	partida.partida.propiedadGeneral '
													SET @v_sq+=' WHERE	agrupador=''noParte'') AND idPartida = sp.idPartida AND idTipoObjeto = @v_idTipoObjeto AND idClase = @idClase),'''') OTD_IDPARTE,NULL OTD_CVESAT,NULL OTD_FAMILIA,'''' OTD_REFERENCIA '
													SET @v_sq+=' FROM	(SELECT  s.idSolicitud,s.idTipoSolicitud,s.idClase,s.rfcEmpresa,s.idCliente,s.numeroContrato,vw.idCotizacion,vw.idPartida,vw.cantidad,vw.costo,vw.subTotalCosto,vw.IvaCosto,vw.totalCosto, '
													SET @v_sq+=' vw.venta FROM solicitud.solicitud.Solicitud s,solicitud.SolicitudCotizacion sc,solicitud.SEL_TOTALES_PARTIDAS_VW vw WHERE s.idSolicitud = sc.idSolicitud '
													SET @v_sq+=' AND s.idTipoSolicitud = sc.idTipoSolicitud AND s.idClase = sc.idClase AND s.rfcEmpresa = sc.rfcEmpresa AND s.idCliente = sc.idCliente AND sc.numeroContrato = sc.numeroContrato '
													SET @v_sq+=' AND sc.idSolicitud = vw.idSolicitud AND sc.idTipoSolicitud	= vw.idTipoSolicitud AND sc.idClase = vw.idClase AND sc.rfcEmpresa = vw.rfcEmpresa AND sc.idCliente = vw.idCliente '
													SET @v_sq+=' AND sc.numeroContrato = vw.numeroContrato AND sc.idCotizacion = vw.idCotizacion AND vw.idEstatusCotizacionPartida =''APROBADA'' AND sc.numeroCotizacion =@v_numeroCotizacion '
													SET @v_sq+=' AND sc.idCotizacion = @v_idCotizacion)sp '
													EXEC sp_executesql  @v_sq, N'@ote_ident NUMERIC(18,0),@v_idTipoObjeto INT,@idClase VARCHAR(10),@v_numeroCotizacion VARCHAR(50),@v_idCotizacion INT',
																		@ote_ident			=@ote_ident,
																		@v_idTipoObjeto		=@v_idTipoObjeto,
																		@idClase			=@idClase,
																		@v_numeroCotizacion	=@v_numeroCotizacion,
																		@v_idCotizacion		=@v_idCotizacion
																	
													SET @v_folioFactura = 'NA-'+CONVERT(VARCHAR(18), @ote_ident)+'-'+ @v_ano
													
													SET @v_sq=''
													SET @v_sq+='UPDATE '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC SET OTE_FACTURACOMPRA=@v_folioFactura WHERE OTE_IDENT=@ote_ident '
													EXEC sp_executesql  @v_sq, N'@v_folioFactura nvarchar(100),@ote_ident NUMERIC(18,0)',
																		@v_folioFactura	=@v_folioFactura,
																		@ote_ident		=@ote_ident

													INSERT INTO [cxc].[FacturaBPRO] (idCotizacion,idSolicitud,idTipoSolicitud,idClase,rfcEmpresa,idCliente,numeroContrato,OTE_IDENT,OTE_FACTURACOMPRA,fechaAlta,idUsuario,activo)
													SELECT idCotizacion, idSolicitud, idTipoSolicitud, idClase, rfcEmpresa, idCliente, numeroContrato, @ote_ident, @v_folioFactura,GETDATE(),@idUsuario,1
													FROM [cxc].[factura] WHERE idCotizacion = @v_idCotizacion AND idSolicitud= @idSolicitud

													UPDATE [cxp].[facturaPorConsolidar]
													SET SERIE	=@v_folioFactura
													WHERE uuid 	IN(	SELECT uuid 
																	FROM 	cxp.SolicitudCotizacionFacturaPorConsolidar scf 
																	WHERE 	scf.idSolicitud		=@idSolicitud 
																	AND 	scf.idCotizacion	=@v_idCotizacion)
													PRINT '2.6'
													--UPDATE [Solicitud].[cxc].[factura] 
													--SET OTE_IDENT=@ote_ident
													--WHERE idSolicitud =@idSolicitud 
													--AND idCotizacion=@v_idCotizacion

												END
										END

								DELETE FROM @txDatos WHERE ID=@v_idd
							END

				
				SET @v_sq=''
				SET @v_sq+='SELECT OTE_IDENT id, ''Se proceso la compra de forma correcta'' msg, 1 estatus FROM '+@v_instancia+'.'+@v_nombreBD+'.DBO.ADE_ORDSERENC WHERE OTE_ORDENPEMEX = @v_numeroCotizacion '
				EXEC sp_executesql  @v_sq, N'@v_numeroCotizacion VARCHAR(50)',
									@v_numeroCotizacion=@v_numeroCotizacion

			END
		ELSE
			BEGIN
				SET @err = 'Error, El contrato no tiene asignada configuración para facturación'
			END
		--COMMIT
	END TRY
	BEGIN CATCH
		--ROLLBACK TRANSACTION
		SELECT  ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
		SET @err = 'Error al insertar en BPRO'
	END CATCH
END


go

