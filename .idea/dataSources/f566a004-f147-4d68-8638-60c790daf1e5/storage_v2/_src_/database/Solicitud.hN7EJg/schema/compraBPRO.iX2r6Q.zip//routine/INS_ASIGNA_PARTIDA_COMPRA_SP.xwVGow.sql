
-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [compraBPRO].[INS_ASIGNA_PARTIDA_COMPRA_SP]
	@rfcProveedor		VARCHAR(13),
	@idProveedorEntidad INT,
	@partidas			XML,
	@idUsuario			INT,
	@err				VARCHAR(500) OUTPUT	
AS
BEGIN

	DECLARE @tblDatos AS TABLE(noParte VARCHAR(500))
	INSERT INTO solicitud.compraBPRO.ProveedorEntidadPartida
	SELECT  @rfcProveedor, 
			@idProveedorEntidad, 
			ParamValues.col.value('noParte[1]','Varchar(500)')
    FROM @partidas.nodes('/Datos/Dato') AS ParamValues(col)   
	
END
go

