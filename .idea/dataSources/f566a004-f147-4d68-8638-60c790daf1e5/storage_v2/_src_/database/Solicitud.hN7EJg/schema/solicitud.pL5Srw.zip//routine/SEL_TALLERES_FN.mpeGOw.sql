
CREATE FUNCTION solicitud.SEL_TALLERES_FN
(
	@idSolicitud INT
)
RETURNS VARCHAR(500)
AS
BEGIN
	DECLARE @talleres VARCHAR(500);

	SELECT  @talleres= COALESCE(@talleres + ', ', '') + nombreComercial FROM [solicitud].[SolicitudCotizacion] AS SC
	INNER JOIN [Proveedor].[proveedor].[ProveedorEntidad] AS PE ON SC.[rfcProveedor] = PE.rfcProveedor AND SC.idProveedorEntidad = PE.idProveedorEntidad
	WHERE idSolicitud = @idSolicitud

	RETURN @talleres
END
go

