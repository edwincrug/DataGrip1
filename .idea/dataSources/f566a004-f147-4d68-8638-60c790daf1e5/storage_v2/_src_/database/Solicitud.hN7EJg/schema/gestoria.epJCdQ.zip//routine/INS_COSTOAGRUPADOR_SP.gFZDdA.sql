
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 30-05-2019
-- Description: Inserta agrupador
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[INS_COSTOAGRUPADOR_SP] 'Sedan2', 78, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[INS_COSTOAGRUPADOR_SP]
	@nombreAgrupador			varchar(200),
	@idUsuario					int,
	@err						nvarchar(500)OUTPUT
AS


BEGIN

	INSERT INTO gestoria.CostoAgrupador 
	SELECT
	@nombreAgrupador,
	@idUsuario,
	1

	SELECT @@IDENTITY AS idAgrupador

	
END
go

