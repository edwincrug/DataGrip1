-- =============================================  
-- Author: Gerardo Zamudio González  
-- Create date: 21-06-2019  
-- Description: Obtiene las reglas de los pasos de las solicitudes
-- ============== Versionamiento ================  
/*  
	Fecha		Autor			Descripción   
	04/12/2020	JLuis Lozada	Se agrego la configuracion para autorizar partidas por N personas
	10/12/2020  JLuis Lozada	Se agrego informacion extra en el estatus de las autorizaciones
 *- Testing...  
 EXEC [solicitud].[SEL_REGLASPASOS_SP] 1505, 'ASE0508051B6', 185, '43', 6282, 11, '';
 
*/  
-- =============================================  
CREATE  PROCEDURE [solicitud].[SEL_REGLASPASOS_SP]  
 @idSolicitud		int,
 @rfcEmpresa		varchar(13),  
 @idCliente			int,  
 @numeroContrato	varchar(50),
 @idUsuario			int,  
 @idAplicacion		int,
 @err				varchar(500)OUTPUT  
AS  
BEGIN

	
	DECLARE @idTipoSolicitud	VARCHAR(20);
	DECLARE @idClase			VARCHAR(20);
	DECLARE @idTipoObjeto		INT;

	SELECT	@idTipoSolicitud	=sol.idTipoSolicitud, 
			@idClase			=sol.idClase,
			@idTipoObjeto		=sso.idTipoObjeto
	FROM	Solicitud.solicitud.Solicitud sol INNER JOIN Solicitud.solicitud.SolicitudObjeto sso
	ON		sol.idSolicitud		= sso.idSolicitud
	AND		sol.idTipoSolicitud	= sso.idTipoSolicitud
	AND		sol.idClase			= sso.idClase
	AND		sol.rfcEmpresa		= sso.rfcEmpresa
	AND		sol.idCliente		= sso.idCliente
	AND		sol.numeroContrato	= sso.numeroContrato
	WHERE	sol.idSolicitud		= @idSolicitud
	

	SELECT R.Id INTO #idRolesUsuario FROM Seguridad.Relacion.Usser_Rol UR
	INNER JOIN Seguridad.Catalogo.Rol R ON R.Id = UR.RolId
	WHERE UsersId = @idUsuario 
	 AND R.AplicacionesId = @idAplicacion


	DECLARE @reglas TABLE (
		--id							int identity,
		aplicaReglaRol				bit,
		aplicaReglaMonto			bit,
		aplicaReglaUsuario			bit,
		aplicaReglaPartida			bit,
		aplicaReglaObjeto			bit,
		idRol						int,
		idTipoMonto					varchar(50),
		montoMinimo					float,
		montoMaximo					float,
		idUsuario					int,
		idPartida					int,
		idObjeto					int,
		idNivel						int
	)

	DECLARE @scp TABLE (
		id							int identity,
		idCotizacion				int,
		idSolicitud					int,
		rfcProveedor				varchar(13),
		idProveedorEntidad			int,
		rfcEmpresa					varchar(13),
		idCliente					int,
		numeroContrato				varchar(50),
		idObjeto					int,
		idPartida					int,
		cantidad					int,
		venta						float,
		aplicaRegla					bit,
		colorNivel					varchar(50))

	INSERT INTO @reglas
	SELECT	RP.aplicaReglaRol,RP.aplicaReglaMonto,RP.aplicaReglaUsuario,RP.aplicaReglaPartida,RP.aplicaReglaObjeto,RR.RolId,RM.idTipoMonto,RM.montoMinimo,RM.montoMaximo,RU.idUsuario,RPP.idPartida,RO.idObjeto,RP.idNivel 
	FROM	[Solicitud].[fase].[ReglaPaso] RP
	LEFT	JOIN [fase].[ReglaPasoRol] RR		ON RR.idReglaPaso = RP.idReglaPaso
	LEFT	JOIN [fase].[ReglaPasoMonto] RM		ON RM.idReglaPaso = RP.idReglaPaso
	LEFT	JOIN [fase].[ReglaPasoUsuario] RU	ON RU.idReglaPaso = RP.idReglaPaso
	LEFT	JOIN [fase].[ReglaPasoPartida] RPP	ON RPP.idReglaPaso = RP.idReglaPaso
	LEFT	JOIN [fase].[ReglaPasoObjeto] RO	ON RO.idReglaPaso = RP.idReglaPaso
	WHERE 	RP.rfcEmpresa		= @rfcEmpresa 
	AND		RP.numeroContrato	= @numeroContrato 
	AND		RP.idCliente		= @idCliente 
	AND		RP.idTipoSolicitud	= @idTipoSolicitud
	AND		RP.activo			= 1
	AND		(RU.UsersId = @idUsuario OR RR.RolId IN (SELECT Id FROM #idRolesUsuario))

	INSERT INTO @scp
	SELECT	idCotizacion,idSolicitud,rfcProveedor,idProveedorEntidad,rfcEmpresa,idCliente,numeroContrato,idObjeto,idPartida,cantidad,venta,0,0
	FROM	[solicitud].[SolicitudCotizacionPartida]
	WHERE	rfcEmpresa		= @rfcEmpresa 
	AND		numeroContrato	= @numeroContrato 
	AND		idCliente		= @idCliente 
	AND		idTipoSolicitud = @idTipoSolicitud
	AND		idSolicitud		= @idSolicitud

	IF EXISTS(	SELECT aplicaReglaRol 
				FROM @reglas 
				WHERE aplicaReglaRol = 1 
				AND aplicaReglaUsuario = 0
				AND aplicaReglaMonto = 0
				AND aplicaReglaPartida = 0
				AND aplicaReglaObjeto = 0)
		BEGIN
			UPDATE @scp SET aplicaRegla = 1
		END
	
	IF EXISTS(	SELECT aplicaReglaRol 
				FROM @reglas 
				WHERE aplicaReglaRol = 0
				AND aplicaReglaUsuario = 1
				AND aplicaReglaMonto = 0
				AND aplicaReglaPartida = 0
				AND aplicaReglaObjeto = 0)
		BEGIN
			UPDATE @scp SET aplicaRegla = 1
		END

	IF EXISTS(	SELECT aplicaReglaMonto 
				FROM @reglas 
				WHERE aplicaReglaMonto = 1)
		BEGIN
			DECLARE @montoMaximo float,@montoMinimo float

			IF EXISTS(SELECT idTipoMonto FROM @reglas WHERE idTipoMonto = 'Solicitud')
				BEGIN
					DECLARE @montoSolicitudT TABLE (id int identity,montoMinimo	float,montoMaximo float)
				
					insert into @montoSolicitudT
					SELECT  montoMinimo,
							montoMaximo
					FROM	@reglas
					WHERE	aplicaReglaMonto = 1 
					AND		idTipoMonto = 'Solicitud'

					DECLARE @contadorMonto INT = 1
					DECLARE @contadorReglas INT = (SELECT COUNT(*) FROM @montoSolicitudT )
					WHILE(@contadorMonto <= @contadorReglas)
						BEGIN
							SELECT  @montoMinimo = montoMinimo,
									@montoMaximo = montoMaximo
							FROM	@montoSolicitudT
							WHERE id = @contadorMonto
						
							IF EXISTS(	SELECT	subTotalVenta
										FROM	[Solicitud].[solicitud].[SEL_TOTALES_SOLICITUD_VW]
										WHERE	idSolicitud = @idSolicitud 
										AND		subTotalVenta BETWEEN @montoMinimo AND @montoMaximo)
								BEGIN
									UPDATE @scp SET aplicaRegla = 1
								END
							SET @contadorMonto = @contadorMonto + 1;
						END
				END

			IF EXISTS(SELECT idTipoMonto FROM @reglas WHERE idTipoMonto = 'Partida')
				BEGIN
					DECLARE @montoPartidaT TABLE (id int identity,montoMinimo float,montoMaximo float)
				
					insert into @montoPartidaT
					SELECT  montoMinimo,montoMaximo
					FROM @reglas
					WHERE aplicaReglaMonto = 1 AND idTipoMonto = 'Partida'
				
					DECLARE @contadorMontoPartida INT = 1
					DECLARE @contadorReglasPartida INT = (SELECT COUNT(*) FROM @montoPartidaT)
				
					WHILE(@contadorMontoPartida <= @contadorReglasPartida)
						BEGIN
							SELECT  @montoMinimo = montoMinimo,
									@montoMaximo = montoMaximo
							FROM	@montoPartidaT
							WHERE	id = @contadorMontoPartida

							DECLARE @contadorCotizacion INT = 1,
							@contadorSolicitudCotizacion INT = (SELECT COUNT(*) FROM @scp)
					
							WHILE(@contadorCotizacion <= @contadorSolicitudCotizacion)
								BEGIN
									UPDATE	@scp SET aplicaRegla = 1 
									WHERE	id = @contadorCotizacion AND (venta * cantidad) BETWEEN @montoMinimo AND @montoMaximo
									SET		@contadorCotizacion = @contadorCotizacion + 1;
								END
							SET @contadorMontoPartida = @contadorMontoPartida + 1
						END
				END

			IF EXISTS(SELECT idTipoMonto FROM @reglas WHERE idTipoMonto = 'Cantidad')
				BEGIN
					DECLARE @montoCantidadT TABLE (id int identity, montoMinimo float,montoMaximo float)
				
					insert into @montoPartidaT
					SELECT  montoMinimo,montoMaximo
					FROM	@reglas
					WHERE	aplicaReglaMonto = 1 AND idTipoMonto = 'Cantidad'
				
					DECLARE @contadorMontoCantidad INT = 1
					DECLARE @contadorReglasCantidad INT = (SELECT COUNT(*) FROM @montoCantidadT)
				
					WHILE(@contadorMontoCantidad <= @contadorReglasCantidad)
						BEGIN
							SELECT  @montoMinimo = montoMinimo,
									@montoMaximo = montoMaximo
							FROM	@montoCantidadT
							WHERE	id = @contadorMontoCantidad

							DECLARE @contadorCotizacionCantidad		INT = 1,
							@contadorSolicitudCotizacionCantidad	INT = (SELECT COUNT(*) FROM @scp)
					
							WHILE(@contadorCotizacionCantidad <= @contadorSolicitudCotizacionCantidad)
								BEGIN
									UPDATE @scp 
									SET		aplicaRegla = 1 
									WHERE	id = @contadorCotizacionCantidad 
									AND		cantidad BETWEEN @montoMinimo AND @montoMaximo
									AND		idPartida IN (SELECT idPartida FROM @reglas WHERE idTipoMonto = 'Cantidad')
									SET @contadorCotizacionCantidad = @contadorCotizacionCantidad + 1;
								END
							SET @contadorMontoCantidad = @contadorMontoCantidad + 1
						END
				END

		END


	IF EXISTS(SELECT aplicaReglaPartida 
			FROM @reglas 
			WHERE aplicaReglaPartida = 1)
		BEGIN
			UPDATE @scp SET aplicaRegla = 1 
			WHERE idPartida IN (SELECT idPartida FROM @reglas WHERE aplicaReglaPartida = 1)
		END

	IF EXISTS(SELECT aplicaReglaObjeto 
			FROM @reglas 
			WHERE aplicaReglaObjeto = 1)
		BEGIN
			UPDATE @scp SET aplicaRegla = 1 
			WHERE idObjeto IN (SELECT idObjeto FROM @reglas WHERE aplicaReglaObjeto = 1)
		END

	IF EXISTS(SELECT idNivel 
			FROM @reglas 
			WHERE idNivel IS NOT NULL)
		BEGIN
			DECLARE @nivelT TABLE (
					id					int identity,
					idNivel				int,
					idPartida			int,
					colorNivel			varchar(50)
				)
				INSERT	INTO @nivelT
				SELECT	R.idNivel,R.idPartida,CN.color
				FROM	@reglas R
				INNER	JOIN Cliente.contrato.ContratoNivel CN ON CN.idNivel = R.idNivel
				WHERE	R.idNivel IS NOT NULL
				
				DECLARE @contadorNivel INT = 1
				DECLARE @contadorReglasNivel INT = (SELECT COUNT(*) FROM @nivelT)

				WHILE(@contadorNivel <= @contadorReglasNivel)
					BEGIN
						DECLARE @colorNivel varchar(50) = (	SELECT	CN.color 
															FROM	@nivelT N
															INNER	JOIN Cliente.contrato.ContratoNivel CN ON CN.idNivel = N.idNivel
															WHERE	N.id = @contadorNivel)
						UPDATE	@scp		
						SET		aplicaRegla = 1,colorNivel = @colorNivel
						WHERE	idPartida in (SELECT idPartida FROM @nivelT WHERE id = @contadorNivel)
						SET @contadorNivel = @contadorNivel + 1
					END
		END
	
	/*INICIO AUTORIZACION DE PARTIDAS MULTIPLE*/
	DECLARE @txDatos TABLE(	[idRow][int] identity(1,1),
							[idReglaPaso] [int],
							[idClase] [varchar](10),
							[idTipoSolicitud] [varchar](10),
							[rfcEmpresa] [varchar](13),
							[idCliente] [int],
							[numeroContrato] [varchar](50),
							[idPartida] [int],
							[idTipoObjeto] [int],
							[idTipoAutorizacion] [varchar](15),
							[noAutorizadores] [int],
							[idRolAutorizacion] [int])
	
	DECLARE @config TABLE ( idx int IDENTITY(1,1),ordenAutorizacion INT,idUsuarioAutorizacion INT)

	DECLARE @detalleEstatus TABLE(	idPartida					INT,
									idTipoObjeto				INT,
									idTipoAutorizacion			VARCHAR(15),
									estatus						VARCHAR(200),
									autorizPendie_No			INT)

	DECLARE @detalleAut TABLE(idPartida INT,idTipoObjeto INT,idTipoAutorizacion	VARCHAR(15),ordenAutorizacion INT,idUsuarioAprobador VARCHAR(400),fechaAprobacion DATETIME,idEstatusCotizacionPartida VARCHAR(20))

	DECLARE @v_idRow				INT,
			@v_idReglaPaso			INT,
			@v_idClase				VARCHAR(10),
			@v_idTipoSolicitud		VARCHAR(10),
			@v_rfcEmpresa			VARCHAR(13),
			@v_idCliente			INT,
			@v_numeroContrato		VARCHAR(50),
			@v_idPartida			INT,
			@v_idTipoObjeto			INT,
			@v_idTipoAutorizacion	VARCHAR(15),
			@v_noAutorizadores		INT,
			@v_noAutorizaciones		INT,
			@v_idRolAutorizacion	INT,
			@v_idx					INT,
			@v_ordenAutorizacion	INT,
			@v_idUsuarioAutorizacion INT,
			@v_idUsuarioAutorizacionAnt INT,
			@v_cont					INT,
			@v_estatusAutorizaciones VARCHAR(200),
			@partidasNoConfiguradas	INT=0

	INSERT INTO @txDatos
	SELECT  DISTINCT 
			aut.idReglaPaso,aut.idClase,aut.idTipoSolicitud,aut.rfcEmpresa,aut.idCliente,aut.numeroContrato,aut.idPartida,aut.idTipoObjeto,aut.idTipoAutorizacion,aut.noAutorizadores,aut.idRolAutorizacion
	FROM	fase.ReglaPasoPartidaAutorizacion aut 
	INNER	JOIN fase.ReglaPasoPartida pa 
	ON		aut.idReglaPaso		=pa.idReglaPaso 
	AND		aut.idClase			=pa.idClase 
	AND		aut.idTipoSolicitud	=pa.idTipoSolicitud 
	AND		aut.rfcEmpresa		=pa.rfcEmpresa
	AND		aut.idCliente		=pa.idCliente 
	AND		aut.numeroContrato	=pa.numeroContrato 
	AND		aut.idPartida		=pa.idPartida 
	AND		aut.idTipoObjeto	=pa.idTipoObjeto
	AND     aut.activo			=1
	INNER	JOIN @scp p 
	ON		p.rfcEmpresa		=pa.rfcEmpresa
	AND		p.idCliente			=pa.idCliente
	AND		P.numeroContrato	=pa.numeroContrato
	AND     P.idPartida			=pa.idPartida
	INNER	JOIN solicitud.SolicitudCotizacion sc
	ON		sc.idSolicitud		=p.idSolicitud
	AND		sc.idCotizacion		=p.idCotizacion
	AND		sc.rfcEmpresa		=p.rfcEmpresa
	AND		sc.idCliente		=p.idCliente
	AND		sc.numeroContrato	=p.numeroContrato
	AND		sc.idEstatusCotizacion IN ('ENESPERA','APROBADA') -- Se agrego como condicion el estatus de la cotizacion para excluir las canceladas
	
	INSERT INTO @detalleEstatus SELECT idPartida,idTipoObjeto,idTipoAutorizacion,'',0 FROM @txDatos

	WHILE EXISTS(SELECT 1 FROM @txDatos)
		BEGIN
			SELECT	TOP 1
					@v_idRow=idRow,@v_idReglaPaso=idReglaPaso,@v_idClase=idClase,@v_idTipoSolicitud=idTipoSolicitud,@v_rfcEmpresa=rfcEmpresa,@v_idCliente=idCliente,@v_numeroContrato=numeroContrato,
					@v_idPartida=idPartida,@v_idTipoObjeto=idTipoObjeto,@v_idTipoAutorizacion=idTipoAutorizacion,@v_noAutorizadores=noAutorizadores,@v_idRolAutorizacion=idRolAutorizacion
			FROM	@txDatos

			IF @v_idTipoAutorizacion='nAutDesc'			-- N autorizadores desconocidos
				BEGIN
					-- 1. Recuperamos el numero de veces que se ha autorizado esta partida para esta solicitud
					SELECT	@v_noAutorizaciones	=COUNT(*) 
					FROM	SOLICITUD.SolicitudCotizacionAprobador 
					WHERE	idSolicitud		=@idSolicitud
					AND		idTipoSolicitud	=@v_idTipoSolicitud 
					AND		idClase			=@v_idClase
					AND		rfcEmpresa		=@v_rfcEmpresa 
					AND		numeroContrato	=@v_numeroContrato 
					AND		idCliente		=@v_idCliente
					AND		idTipoObjeto	=@v_idTipoObjeto 
					AND		idPartida		=@v_idPartida

					--2. Comparamos ambos valores si el numero de autorizaciones es menor a el numero de autorizadores, habilitamos el permiso, caso contrario desabilitamos el permiso
					IF @v_noAutorizaciones < @v_noAutorizadores
						BEGIN
							SET @v_estatusAutorizaciones='Autorizaciones pendientes '+ CAST(@v_noAutorizadores-@v_noAutorizaciones AS VARCHAR) + ' de '+ CAST(@v_noAutorizadores AS VARCHAR)
							IF @v_noAutorizaciones>0
								BEGIN
									INSERT INTO @detalleAut(idPartida,idTipoObjeto,idTipoAutorizacion,ordenAutorizacion,idUsuarioAprobador,fechaAprobacion,idEstatusCotizacionPartida)
									SELECT  idPartida,idTipoObjeto,@v_idTipoAutorizacion,0,[Common].[common].SEL_NOMBRE_USUARIO_FN(idUsuarioAprobador),fechaAprobacion,idEstatusAprobador
									-- SELECT * 
									FROM	SOLICITUD.SolicitudCotizacionAprobador 
									WHERE	idSolicitud		=@idSolicitud
									AND		idTipoSolicitud	=@v_idTipoSolicitud 
									AND		idClase			=@v_idClase
									AND		rfcEmpresa		=@v_rfcEmpresa 
									AND		numeroContrato	=@v_numeroContrato 
									AND		idCliente		=@v_idCliente
									AND		idTipoObjeto	=@v_idTipoObjeto 
									AND		idPartida		=@v_idPartida
								END
							
							UPDATE @detalleEstatus SET estatus=@v_estatusAutorizaciones,autorizPendie_No=@v_noAutorizadores-@v_noAutorizaciones WHERE	idPartida =@v_idPartida

							IF NOT EXISTS(	SELECT 1 FROM SOLICITUD.SolicitudCotizacionAprobador 
											WHERE	idSolicitud			=@idSolicitud
											AND		idTipoSolicitud		=@v_idTipoSolicitud 
											AND		idClase				=@v_idClase
											AND		rfcEmpresa			=@v_rfcEmpresa 
											AND		numeroContrato		=@v_numeroContrato 
											AND		idCliente			=@v_idCliente
											AND		idTipoObjeto		=@v_idTipoObjeto 
											AND		idPartida			=@v_idPartida
											AND     idUsuarioAprobador	=@idUsuario)
								BEGIN
									UPDATE	@scp SET aplicaRegla = 1 WHERE	idPartida =@v_idPartida		
								END
							ELSE
								BEGIN
									UPDATE	@scp SET aplicaRegla = 0 WHERE	idPartida =@v_idPartida		
								END
						END
					ELSE
						BEGIN
							INSERT INTO @detalleAut(idPartida,idTipoObjeto,idTipoAutorizacion,ordenAutorizacion,idUsuarioAprobador,fechaAprobacion,idEstatusCotizacionPartida)
							SELECT  idPartida,idTipoObjeto,@v_idTipoAutorizacion,0,[Common].[common].SEL_NOMBRE_USUARIO_FN(idUsuarioAprobador),fechaAprobacion,idEstatusAprobador
							-- SELECT * 
							FROM	SOLICITUD.SolicitudCotizacionAprobador 
							WHERE	idSolicitud		=@idSolicitud
							AND		idTipoSolicitud	=@v_idTipoSolicitud 
							AND		idClase			=@v_idClase
							AND		rfcEmpresa		=@v_rfcEmpresa 
							AND		numeroContrato	=@v_numeroContrato 
							AND		idCliente		=@v_idCliente
							AND		idTipoObjeto	=@v_idTipoObjeto 
							AND		idPartida		=@v_idPartida
							UPDATE	@scp SET aplicaRegla = 0 WHERE	idPartida =@v_idPartida
							UPDATE @detalleEstatus SET estatus='Autorizaciones pendientes 0' WHERE	idPartida =@v_idPartida

						END
				END

			IF @v_idTipoAutorizacion='nAutRol'			-- N autorizadores que tengan un rol en especifico
				BEGIN
					print 'nAutRol' + cast(@v_idPartida as varchar)
					--1.0 validamos si el rol del usuario esta configurado para autorizar esta partida
					IF EXISTS(SELECT 1 FROM #idRolesUsuario WHERE id=@v_idRolAutorizacion)
						BEGIN
							--2. Recuperamos el numero de veces que se ha autorizado esta partida para esta solicitud
							SELECT	@v_noAutorizaciones	=COUNT(*) 
							FROM	SOLICITUD.SolicitudCotizacionAprobador 
							WHERE	idSolicitud		=@idSolicitud
							AND		idTipoSolicitud	=@v_idTipoSolicitud 
							AND		idClase			=@v_idClase
							AND		rfcEmpresa		=@v_rfcEmpresa 
							AND		numeroContrato	=@v_numeroContrato 
							AND		idCliente		=@v_idCliente
							AND		idTipoObjeto	=@v_idTipoObjeto 
							AND		idPartida		=@v_idPartida

							--2. Comparamos ambos valores si el numero de autorizaciones es menor a el numero de autorizadores, habilitamos el permiso, caso contrario desabilitamos el permiso
							IF @v_noAutorizaciones < @v_noAutorizadores
								BEGIN
									SET @v_estatusAutorizaciones='Autorizaciones pendientes '+ CAST(@v_noAutorizadores-@v_noAutorizaciones AS VARCHAR) + ' de '+ CAST(@v_noAutorizadores AS VARCHAR)
									IF @v_noAutorizaciones>0
										BEGIN
											INSERT INTO @detalleAut(idPartida,idTipoObjeto,idTipoAutorizacion,ordenAutorizacion,idUsuarioAprobador,fechaAprobacion,idEstatusCotizacionPartida)
											SELECT  idPartida,idTipoObjeto,@v_idTipoAutorizacion,0,[Common].[common].SEL_NOMBRE_USUARIO_FN(idUsuarioAprobador),fechaAprobacion,idEstatusAprobador
											FROM	SOLICITUD.SolicitudCotizacionAprobador 
											WHERE	idSolicitud		=@idSolicitud
											AND		idTipoSolicitud	=@v_idTipoSolicitud 
											AND		idClase			=@v_idClase
											AND		rfcEmpresa		=@v_rfcEmpresa 
											AND		numeroContrato	=@v_numeroContrato 
											AND		idCliente		=@v_idCliente
											AND		idTipoObjeto	=@v_idTipoObjeto 
											AND		idPartida		=@v_idPartida
										END
									UPDATE @detalleEstatus SET estatus=@v_estatusAutorizaciones,autorizPendie_No=@v_noAutorizadores-@v_noAutorizaciones WHERE	idPartida =@v_idPartida

									IF NOT EXISTS(	SELECT 1 FROM SOLICITUD.SolicitudCotizacionAprobador 
											WHERE	idSolicitud			=@idSolicitud
											AND		idTipoSolicitud		=@v_idTipoSolicitud 
											AND		idClase				=@v_idClase
											AND		rfcEmpresa			=@v_rfcEmpresa 
											AND		numeroContrato		=@v_numeroContrato 
											AND		idCliente			=@v_idCliente
											AND		idTipoObjeto		=@v_idTipoObjeto 
											AND		idPartida			=@v_idPartida
											AND     idUsuarioAprobador	=@idUsuario)
										BEGIN
											UPDATE	@scp SET aplicaRegla = 1 WHERE	idPartida =@v_idPartida		
										END
									ELSE
										BEGIN
											UPDATE	@scp SET aplicaRegla = 0 WHERE	idPartida =@v_idPartida		
										END
								END
							ELSE
								BEGIN
									INSERT INTO @detalleAut(idPartida,idTipoObjeto,idTipoAutorizacion,ordenAutorizacion,idUsuarioAprobador,fechaAprobacion,idEstatusCotizacionPartida)
									SELECT  idPartida,idTipoObjeto,@v_idTipoAutorizacion,0,[Common].[common].SEL_NOMBRE_USUARIO_FN(idUsuarioAprobador),fechaAprobacion,idEstatusAprobador

									-- SELECT * 
									FROM	SOLICITUD.SolicitudCotizacionAprobador 
									WHERE	idSolicitud		=@idSolicitud
									AND		idTipoSolicitud	=@v_idTipoSolicitud 
									AND		idClase			=@v_idClase
									AND		rfcEmpresa		=@v_rfcEmpresa 
									AND		numeroContrato	=@v_numeroContrato 
									AND		idCliente		=@v_idCliente
									AND		idTipoObjeto	=@v_idTipoObjeto 
									AND		idPartida		=@v_idPartida

									UPDATE	@scp SET aplicaRegla = 0 WHERE	idPartida =@v_idPartida
									UPDATE  @detalleEstatus SET estatus='Autorizaciones pendientes 0' WHERE	idPartida =@v_idPartida
								END
						END
					ELSE
						BEGIN
							UPDATE	@scp SET aplicaRegla = 0 WHERE	idPartida IN (SELECT idPartida FROM @reglas WHERE aplicaReglaPartida = 1)
						END
				END

			IF @v_idTipoAutorizacion='nAutUserEspCO'	-- N autorizadores con usuarios especificos y con orden de autorizacion
				BEGIN
					PRINT @v_idTipoAutorizacion + '=> Partida=>' + CAST(@v_idPartida AS VARCHAR)
					
					INSERT INTO @config(ordenAutorizacion,idUsuarioAutorizacion)
					SELECT  ordenAutorizacion,idUsuarioAutorizacion
					FROM	fase.ReglaPasoPartidaAutorizacion
					WHERE	idReglaPaso			=@v_idReglaPaso
					AND		idClase				=@v_idClase
					AND		idTipoSolicitud		=@v_idTipoSolicitud
					AND     rfcEmpresa			=@v_rfcEmpresa
					AND     idCliente			=@v_idCliente
					AND     numeroContrato		=@v_numeroContrato
					AND     idPartida			=@v_idPartida
					AND     idTipoObjeto		=@v_idTipoObjeto
					AND     idTipoAutorizacion	=@v_idTipoAutorizacion

					SET @v_noAutorizadores	=(SELECT COUNT(*) FROM @config)
					WHILE EXISTS(SELECT 1 FROM @config)
						BEGIN
							SET @v_idUsuarioAutorizacionAnt=@v_idUsuarioAutorizacion
							SELECT	TOP 1
									@v_idx=idx,
									@v_ordenAutorizacion	=ordenAutorizacion,
									@v_idUsuarioAutorizacion=idUsuarioAutorizacion
							FROM	@config
							ORDER BY ordenAutorizacion ASC
							PRINT '@idUsuario=>'+CAST(@idUsuario AS VARCHAR) + ' @v_idUsuarioAutorizacion=>'+CAST(@v_idUsuarioAutorizacion AS VARCHAR)
							IF @idUsuario = @v_idUsuarioAutorizacion 
								BEGIN
									IF @v_idUsuarioAutorizacionAnt IS NOT NULL --2da ITERACION
										BEGIN
											IF EXISTS(	SELECT 1
														FROM	SOLICITUD.SolicitudCotizacionAprobador 
														WHERE	idSolicitud		=@idSolicitud
														AND		idTipoSolicitud	=@v_idTipoSolicitud 
														AND		idClase			=@v_idClase
														AND		rfcEmpresa		=@v_rfcEmpresa 
														AND		numeroContrato	=@v_numeroContrato 
														AND		idCliente		=@v_idCliente
														AND		idTipoObjeto	=@v_idTipoObjeto 
														AND		idPartida		=@v_idPartida
														AND     idUsuarioAprobador=@v_idUsuarioAutorizacionAnt)
													BEGIN
														IF NOT EXISTS(	SELECT 1
																	FROM	SOLICITUD.SolicitudCotizacionAprobador 
																	WHERE	idSolicitud		=@idSolicitud
																	AND		idTipoSolicitud	=@v_idTipoSolicitud 
																	AND		idClase			=@v_idClase
																	AND		rfcEmpresa		=@v_rfcEmpresa 
																	AND		numeroContrato	=@v_numeroContrato 
																	AND		idCliente		=@v_idCliente
																	AND		idTipoObjeto	=@v_idTipoObjeto 
																	AND		idPartida		=@v_idPartida
																	AND     idUsuarioAprobador=@v_idUsuarioAutorizacion)
															BEGIN
																UPDATE	@scp SET aplicaRegla = 1 WHERE	idPartida =@v_idPartida
																DELETE FROM @config
															END
													END
										END
									ELSE
										BEGIN
											IF NOT EXISTS(	SELECT 1
															FROM	SOLICITUD.SolicitudCotizacionAprobador 
															WHERE	idSolicitud		=@idSolicitud
															AND		idTipoSolicitud	=@v_idTipoSolicitud 
															AND		idClase			=@v_idClase
															AND		rfcEmpresa		=@v_rfcEmpresa 
															AND		numeroContrato	=@v_numeroContrato 
															AND		idCliente		=@v_idCliente
															AND		idTipoObjeto	=@v_idTipoObjeto 
															AND		idPartida		=@v_idPartida
															AND     idUsuarioAprobador=@v_idUsuarioAutorizacion)
												BEGIN
													UPDATE	@scp SET aplicaRegla = 1 WHERE	idPartida =@v_idPartida
													DELETE FROM @config
												END
										END
								END
							ELSE 
								BEGIN
									UPDATE	@scp SET aplicaRegla = 0 WHERE	idPartida =@v_idPartida
								END
							DELETE FROM @config WHERE idx=@v_idx
						END
					
					INSERT INTO @detalleAut(idPartida,idTipoObjeto,idTipoAutorizacion,ordenAutorizacion,idUsuarioAprobador,fechaAprobacion,idEstatusCotizacionPartida)
					SELECT  a.idPartida,a.idTipoObjeto,@v_idTipoAutorizacion,b.ordenAutorizacion,[Common].[common].SEL_NOMBRE_USUARIO_FN(a.idUsuarioAprobador),a.fechaAprobacion,idEstatusAprobador
					FROM	SOLICITUD.SolicitudCotizacionAprobador a
					INNER	JOIN fase.ReglaPasoPartidaAutorizacion b 
					ON		a.idClase			=b.idClase 
					AND		a.idTipoSolicitud	=b.idTipoSolicitud 
					AND		a.rfcEmpresa		=b.rfcEmpresa 
					AND		a.numeroContrato	=b.numeroContrato
					AND		a.idCliente			=b.idCliente 
					AND		a.idTipoObjeto		=b.idTipoObjeto 
					AND		a.idPartida			=b.idPartida 
					AND     a.idUsuarioAprobador=b.idUsuarioAutorizacion
					WHERE	a.idSolicitud		=@idSolicitud
					AND		a.idTipoSolicitud	=@v_idTipoSolicitud 
					AND		a.idClase			=@v_idClase
					AND		a.rfcEmpresa		=@v_rfcEmpresa 
					AND		a.numeroContrato	=@v_numeroContrato 
					AND		a.idCliente			=@v_idCliente
					AND		a.idTipoObjeto		=@v_idTipoObjeto 
					AND		a.idPartida			=@v_idPartida
					AND     b.idTipoAutorizacion='nAutUserEspCO'

					SELECT	@v_noAutorizaciones	=COUNT(*) 
					FROM	SOLICITUD.SolicitudCotizacionAprobador 
					WHERE	idSolicitud		=@idSolicitud
					AND		idTipoSolicitud	=@v_idTipoSolicitud 
					AND		idClase			=@v_idClase
					AND		rfcEmpresa		=@v_rfcEmpresa 
					AND		numeroContrato	=@v_numeroContrato 
					AND		idCliente		=@v_idCliente
					AND		idTipoObjeto	=@v_idTipoObjeto 
					AND		idPartida		=@v_idPartida
					
					IF @v_noAutorizaciones < @v_noAutorizadores
						SET @v_estatusAutorizaciones='Autorizaciones pendientes '+ CAST(@v_noAutorizadores-@v_noAutorizaciones AS VARCHAR) + ' de '+ CAST(@v_noAutorizadores AS VARCHAR)
					ELSE
						SET @v_estatusAutorizaciones='Autorizaciones pendientes 0'

					UPDATE @detalleEstatus SET estatus=@v_estatusAutorizaciones,autorizPendie_No=@v_noAutorizadores-@v_noAutorizaciones WHERE	idPartida =@v_idPartida
				END

			IF @v_idTipoAutorizacion='nAutUserEspSO'	-- N autorizadores con usuarios especificos y sin orden de autorizacion
				BEGIN
					PRINT @v_idTipoAutorizacion + '=> Partida=>' + CAST(@v_idPartida AS VARCHAR)
					INSERT INTO @config(ordenAutorizacion,idUsuarioAutorizacion)
					SELECT  ordenAutorizacion,idUsuarioAutorizacion
					FROM	fase.ReglaPasoPartidaAutorizacion
					WHERE	idReglaPaso			=@v_idReglaPaso
					AND		idClase				=@v_idClase
					AND		idTipoSolicitud		=@v_idTipoSolicitud
					AND     rfcEmpresa			=@v_rfcEmpresa
					AND     idCliente			=@v_idCliente
					AND     numeroContrato		=@v_numeroContrato
					AND     idPartida			=@v_idPartida
					AND     idTipoObjeto		=@v_idTipoObjeto
					AND     idTipoAutorizacion	=@v_idTipoAutorizacion

					SET @v_noAutorizadores	=(SELECT COUNT(*) FROM @config)

					WHILE EXISTS(SELECT 1 FROM @config)
						BEGIN
							SELECT	TOP 1
									@v_idx=idx,
									@v_ordenAutorizacion	=ordenAutorizacion,
									@v_idUsuarioAutorizacion=idUsuarioAutorizacion
							FROM	@config
							ORDER BY ordenAutorizacion ASC
							
							PRINT '@idUsuario=>'+CAST(@idUsuario AS VARCHAR) + ' @v_idUsuarioAutorizacion=>'+CAST(@v_idUsuarioAutorizacion AS VARCHAR)
							
							IF @idUsuario = @v_idUsuarioAutorizacion 
								BEGIN
									IF NOT EXISTS(	SELECT 1
													FROM	SOLICITUD.SolicitudCotizacionAprobador 
													WHERE	idSolicitud		=@idSolicitud
													AND		idTipoSolicitud	=@v_idTipoSolicitud 
													AND		idClase			=@v_idClase
													AND		rfcEmpresa		=@v_rfcEmpresa 
													AND		numeroContrato	=@v_numeroContrato 
													AND		idCliente		=@v_idCliente
													AND		idTipoObjeto	=@v_idTipoObjeto 
													AND		idPartida		=@v_idPartida
													AND     idUsuarioAprobador=@v_idUsuarioAutorizacion)
											BEGIN
												UPDATE	@scp SET aplicaRegla = 1 WHERE	idPartida =@v_idPartida
												DELETE FROM @config
											END
								END
							ELSE 
								BEGIN
									UPDATE	@scp SET aplicaRegla = 0 WHERE	idPartida =@v_idPartida
								END
								
							DELETE FROM @config WHERE idx=@v_idx
						END
						INSERT INTO @detalleAut(idPartida,idTipoObjeto,idTipoAutorizacion,ordenAutorizacion,idUsuarioAprobador,fechaAprobacion,idEstatusCotizacionPartida)
						SELECT  a.idPartida,a.idTipoObjeto,@v_idTipoAutorizacion,b.ordenAutorizacion,[Common].[common].SEL_NOMBRE_USUARIO_FN(a.idUsuarioAprobador),a.fechaAprobacion,idEstatusAprobador
						FROM	SOLICITUD.SolicitudCotizacionAprobador a
						INNER	JOIN fase.ReglaPasoPartidaAutorizacion b 
						ON		a.idClase			=b.idClase 
						AND		a.idTipoSolicitud	=b.idTipoSolicitud 
						AND		a.rfcEmpresa		=b.rfcEmpresa 
						AND		a.numeroContrato	=b.numeroContrato
						AND		a.idCliente			=b.idCliente 
						AND		a.idTipoObjeto		=b.idTipoObjeto 
						AND		a.idPartida			=b.idPartida 
						AND     a.idUsuarioAprobador=b.idUsuarioAutorizacion
						WHERE	a.idSolicitud		=@idSolicitud
						AND		a.idTipoSolicitud	=@v_idTipoSolicitud 
						AND		a.idClase			=@v_idClase
						AND		a.rfcEmpresa		=@v_rfcEmpresa 
						AND		a.numeroContrato	=@v_numeroContrato 
						AND		a.idCliente			=@v_idCliente
						AND		a.idTipoObjeto		=@v_idTipoObjeto 
						AND		a.idPartida			=@v_idPartida
						AND     b.idTipoAutorizacion='nAutUserEspSO'

						SELECT	@v_noAutorizaciones	=COUNT(*) 
						FROM	SOLICITUD.SolicitudCotizacionAprobador 
						WHERE	idSolicitud		=@idSolicitud
						AND		idTipoSolicitud	=@v_idTipoSolicitud 
						AND		idClase			=@v_idClase
						AND		rfcEmpresa		=@v_rfcEmpresa 
						AND		numeroContrato	=@v_numeroContrato 
						AND		idCliente		=@v_idCliente
						AND		idTipoObjeto	=@v_idTipoObjeto 
						AND		idPartida		=@v_idPartida
					
						IF @v_noAutorizaciones < @v_noAutorizadores
							SET @v_estatusAutorizaciones='Autorizaciones pendientes '+ CAST(@v_noAutorizadores-@v_noAutorizaciones AS VARCHAR) + ' de '+ CAST(@v_noAutorizadores AS VARCHAR)
						ELSE
							SET @v_estatusAutorizaciones='Autorizaciones pendientes 0'

						UPDATE @detalleEstatus SET estatus=@v_estatusAutorizaciones,autorizPendie_No=@v_noAutorizadores-@v_noAutorizaciones WHERE	idPartida =@v_idPartida
				END

			DELETE FROM @txDatos WHERE idRow=@v_idRow
		END

	/*Obtenemos las autorizaciones pendientes de las partidas que no estan configuradas para ser autorizadas por N niveles*/
	DECLARE @max INT,@cont INT=1,@idCotizacion INT, @idPartida INT, @contPartPend INT
	SELECT	@max=COUNT(*) FROM @scp
	WHILE	@cont<=@max
		BEGIN
			SELECT @idCotizacion=idCotizacion,@idPartida=idPartida FROM @scp WHERE id=@cont
			IF NOT EXISTS(	SELECT 1 FROM fase.ReglaPasoPartidaAutorizacion 
							WHERE	idClase			=@idClase
							AND     idTipoSolicitud =@idTipoSolicitud
							AND		rfcEmpresa		=@rfcEmpresa
							AND		idCliente		=@idCliente 
							AND		numeroContrato	=@numeroContrato
							AND		idPartida		=@idPartida)
				BEGIN
					--print 'partida=>'+CAST(@idPartida AS VARCHAR)
					SELECT @contPartPend=count(*) FROM solicitud.SolicitudCotizacion sc
					INNER JOIN solicitud.SolicitudCotizacionPartida scp
					ON	sc.idSolicitud					=scp.idSolicitud
					AND sc.idCotizacion					=scp.idCotizacion
					AND sc.rfcEmpresa					=scp.rfcEmpresa
					AND sc.idCliente					=scp.idCliente
					AND sc.numeroContrato				=scp.numeroContrato
					AND sc.idEstatusCotizacion			='ENESPERA'
					AND scp.idEstatusCotizacionPartida	='ENESPERA'
					WHERE	sc.idSolicitud		=@idSolicitud
					AND     sc.idTipoSolicitud  =@idTipoSolicitud
					AND     sc.idClase			=@idClase
					AND		sc.rfcEmpresa		=@rfcEmpresa
					AND		sc.numeroContrato	=@numeroContrato
					AND		sc.idCliente		=@idCliente
					AND     scp.idPartida		=@idPartida
					AND     scp.idCotizacion	=@idCotizacion

					SET @partidasNoConfiguradas=@partidasNoConfiguradas+@contPartPend
				END
				SET @cont=@cont+1
		END
	/*FIN AUTORIZACION DE PARTIDAS MULTIPLE*/
		
	SELECT	* FROM @scp

	SELECT	idPartida,idTipoObjeto,idTipoAutorizacion,estatus, 
			autorizPendie_No,
			[solicitud].SEL_OBTENERAUTORIZADORES_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,idPartida,idTipoObjeto,idTipoAutorizacion,'AUT_PENDIENTES_AUTORIZADORES',@idAplicacion,autorizPendie_No) autorizPendie_Autorizadores,
			[solicitud].SEL_OBTENERAUTORIZADORES_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,idPartida,idTipoObjeto,idTipoAutorizacion,'AUT_TOTALES_NUM',@idAplicacion,autorizPendie_No) autorizTotales_No,
			[solicitud].SEL_OBTENERAUTORIZADORES_FN(@idSolicitud,@idClase,@idTipoSolicitud,@rfcEmpresa,@idCliente,@numeroContrato,idPartida,idTipoObjeto,idTipoAutorizacion,'AUT_TOTALES_AUTORIZADORES',@idAplicacion,autorizPendie_No) autorizTotales_Autorizadores
			
	from	@detalleEstatus ORDER BY idPartida,idTipoObjeto ASC
	

	SELECT	idPartida,idUsuarioAprobador,
			CONVERT(VARCHAR(12),fechaAprobacion,103) + ' '+CONVERT(VARCHAR(8),fechaAprobacion,108) fechaAprobacion,
			idEstatusCotizacionPartida 
	from @detalleAut ORDER BY idPartida,idTipoObjeto,ordenAutorizacion ASC

	SELECT	ISNULL(SUM(autorizPendie_No),0)+ISNULL(@partidasNoConfiguradas,0) 'noAutorizacionesPendientes' FROM  @detalleEstatus

END  

 /*


 */

go

