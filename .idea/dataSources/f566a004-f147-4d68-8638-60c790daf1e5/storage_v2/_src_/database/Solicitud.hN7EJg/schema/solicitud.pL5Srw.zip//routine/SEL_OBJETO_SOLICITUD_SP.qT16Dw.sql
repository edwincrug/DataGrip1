

-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 24-06-2019
-- Description: Obtiene el idObjeto e idTipoObjeto de la solicitud enviada
-- =============================================
/*
	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC solicitud.SEL_OBJETO_SOLICITUD_SP 29, 6036;
	SELECT @salida AS salida;
*/

CREATE PROCEDURE [solicitud].[SEL_OBJETO_SOLICITUD_SP]
	@idSolicitud INT,
	@idUsuario INT = NULL,
	@err VARCHAR(max) = NULL OUTPUT

AS

BEGIN
	BEGIN TRY
		SELECT SO.idTipoObjeto
			, SO.idObjeto
			, S.idClase
			, S.rfcEmpresa
			, S.idCliente
			, S.numeroContrato
		FROM solicitud.Solicitud S
		INNER JOIN solicitud.SolicitudObjeto SO
		ON S.idSolicitud = SO.idSolicitud
		AND S.idTipoSolicitud = SO.idTipoSolicitud
		AND S.idClase = SO.idClase
		AND S.rfcEmpresa = SO.rfcEmpresa
		AND S.idCliente = SO.idCliente
		AND S.numeroContrato = SO.numeroContrato
		WHERE S.idSolicitud = @idSolicitud

	END TRY
	BEGIN CATCH
		SET @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
	END CATCH
	RETURN
END
go

