
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 30-05-2019
-- Description: Inserta objetos en agrupador
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[INS_COSTOSAGRUPADORDETALLE_SP]  
	'<propiedades>
	<ids><idTipoObjeto>71</idTipoObjeto></ids>
	<ids><idTipoObjeto>72</idTipoObjeto></ids>
	<ids><idTipoObjeto>73</idTipoObjeto></ids>
	</propiedades>',
	1,78, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[INS_COSTOSAGRUPADORDETALLE_SP]
	@xml						XML,
	@idAgrupador				int,
	@idUsuario					int,
	@err						nvarchar(500)OUTPUT
AS


BEGIN

	DECLARE @tbl_propiedades AS TABLE(
        _row                    INT IDENTITY(1,1),
		idTipoObjeto			INT
    )

	INSERT INTO @tbl_propiedades(idTipoObjeto)

    SELECT
		ParamValues.col.value('idTipoObjeto[1]','int')
        FROM @xml.nodes('propiedades/ids') AS ParamValues(col)

	--SELECT * FROM @tbl_propiedades

	DECLARE @cont INT = 1

	WHILE((SELECT COUNT(*) FROM @tbl_propiedades)>= @cont)

		BEGIN
			insert into gestoria.CostoAgrupadorDetalle
			SELECT 
			@idAgrupador,
			idTipoObjeto,
			@idUsuario
			FROM
			@tbl_propiedades
			WHERE _row = @cont

			SET @cont = @cont + 1
		END

	
END
go

