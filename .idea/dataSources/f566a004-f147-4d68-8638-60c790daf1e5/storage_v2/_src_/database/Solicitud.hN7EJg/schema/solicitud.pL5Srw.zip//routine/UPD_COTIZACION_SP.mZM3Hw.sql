-- =============================================
-- Author:			<Edgar Mendoza>
-- Create date: 	<13/05/2020>
-- Description:	    <Actualiza Cotización>
-- =============================================
-- EXEC [solicitud].[UPD_COTIZACION_SP] 
-- =============================================
	CREATE PROCEDURE [solicitud].[UPD_COTIZACION_SP]
(
	@datoEditado			FLOAT
	,@keyEditado			VARCHAR(50)
	,@idPartida				INT
	,@numeroCotizacion		VARCHAR(100)
	,@idSolicitud			INT
	,@idTipoSolicitud		VARCHAR(10)
	,@idClase				VARCHAR(10)
	,@rfcEmpresa			VARCHAR(13)
	,@idCliente				INT
	,@numeroContrato		VARCHAR(50)
	,@idUsuario				INT
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS


BEGIN
	
	DECLARE @idCotizacion		INT,
			@dato				VARCHAR(100),
			@msj				VARCHAR(100)

	DECLARE @manejoDescuentoVenta INT, @porcentajeDescuentoVenta FLOAT
	SELECT @manejoDescuentoVenta=manejoDescuentoVenta, @porcentajeDescuentoVenta=porcentajeDescuentoVenta 
	FROM [Cliente].Cliente.Contrato
	WHERE rfcEmpresa=@rfcEmpresa AND idCliente=@idCliente AND numeroContrato=@numeroContrato

	SELECT
		@idCotizacion = idCotizacion
	FROM Solicitud.solicitud.SolicitudCotizacion
	WHERE numeroCotizacion = @numeroCotizacion
	AND idSolicitud = @idSolicitud
	AND idClase = @idClase
	AND rfcEmpresa = @rfcEmpresa
	AND idCliente = @idCliente
	AND numeroContrato = @numeroContrato

	IF(@keyEditado = 'Costo' OR @keyEditado = 'Venta')
		BEGIN
			IF EXISTS(select * from solicitud.[cxc].[FacturaDetalle] WHERE idCotizacion = @idCotizacion)
				BEGIN
					SET @err = 'No se puede actualizar cotización porque ya esta provisionada'
					SET @msj = 'ERR'
					SELECT @msj  AS mensaje
				END
			ELSE
				BEGIN
					IF(@keyEditado = 'Costo')
						BEGIN

							IF EXISTS(SELECT 1 FROM Seguridad.[Relacion].[Usser_Rol] where UsersId = @idUsuario AND RolId in (36, 65, 88, 91))
								BEGIN
									SET @dato = 'Costo'
									UPDATE solicitud.solicitud.SolicitudCotizacionPartida 
									SET costo = @datoEditado
									WHERE idCotizacion = @idCotizacion
									AND idPartida = @idPartida

									SET @err = @dato + ' actualizada de la partida ' + CAST(@idPartida AS VARCHAR(50))
									SET @msj = 'OK'
									SELECT @msj  AS mensaje
								END
							ELSE
								BEGIN
									IF EXISTS(SELECT 1 FROM Partida.partida.PartidaPropiedadGeneral WHERE idPartida = @idPartida AND idPropiedadGeneral = 7 AND valor = 'true')
										BEGIN
											SET @dato = 'Costo'
											UPDATE solicitud.solicitud.SolicitudCotizacionPartida 
											SET costo = @datoEditado
											WHERE idCotizacion = @idCotizacion
											AND idPartida = @idPartida

											SET @err = @dato + ' actualizada de la partida ' + CAST(@idPartida AS VARCHAR(50))
											SET @msj = 'OK'
											SELECT @msj  AS mensaje
										END
									ELSE
										BEGIN
											SET @err = 'La partida no esta configurada para editar su costo.'
											SET @msj = 'ERR'
											SELECT @msj  AS mensaje
										END
								END
						END
					IF(@keyEditado = 'Venta')
						BEGIN
							IF EXISTS(SELECT 1 FROM Seguridad.[Relacion].[Usser_Rol] where UsersId = @idUsuario AND RolId in (36, 65, 88, 91))
								BEGIN
									SET @dato = 'Venta'
									UPDATE solicitud.solicitud.SolicitudCotizacionPartida 
									SET venta = @datoEditado
									WHERE idCotizacion = @idCotizacion
									AND idPartida = @idPartida
									
									IF(@manejoDescuentoVenta = 1)
										BEGIN
											UPDATE solicitud.solicitud.[SolicitudCotizacionPartidaDescuento] 
											SET descuentoVenta = ((@datoEditado * porcentajeDescuentoVenta) / 100)
											WHERE idCotizacion = @idCotizacion
											AND idPartida = @idPartida
										END

									SET @err = @dato + ' actualizada de la partida ' + CAST(@idPartida AS VARCHAR(50))
									SET @msj = 'OK'
									SELECT @msj  AS mensaje
								END
							ELSE
								BEGIN
									IF EXISTS(SELECT 1 FROM Partida.partida.PartidaPropiedadGeneral WHERE idPartida = @idPartida AND idPropiedadGeneral = 8 AND valor = 'true')
										BEGIN
											SET @dato = 'Venta'
											UPDATE solicitud.solicitud.SolicitudCotizacionPartida 
											SET venta = @datoEditado
											WHERE idCotizacion = @idCotizacion
											AND idPartida = @idPartida

											IF(@manejoDescuentoVenta = 1)
												BEGIN
													UPDATE solicitud.solicitud.[SolicitudCotizacionPartidaDescuento] 
													SET descuentoVenta = ((@datoEditado * porcentajeDescuentoVenta) / 100)
													WHERE idCotizacion = @idCotizacion
													AND idPartida = @idPartida
												END

											SET @err = @dato + ' actualizada de la partida ' + CAST(@idPartida AS VARCHAR(50))
											SET @msj = 'OK'
											SELECT @msj  AS mensaje
										END
									ELSE
										BEGIN
											SET @err = 'La partida no esta configurada para editar su venta.'
											SET @msj = 'ERR'
											SELECT @msj  AS mensaje
										END
								END
						END
				END
		END

		IF(@keyEditado = 'cant')
			BEGIN
				IF EXISTS(select idEstatusCotizacionPartida 
							from solicitud.solicitud.SolicitudCotizacionPartida 
							WHERE idCotizacion = @idCotizacion 
							AND idPartida = @idPartida 
							AND idEstatusCotizacionPartida = 'APROBADA')
					BEGIN
						SET @err = 'No se puede actualizar cotización porque la partida ya esta aprobada'
						SET @msj = 'ERR'
						SELECT @msj  AS mensaje
					END
				ELSE
					BEGIN
						SET @dato = 'Cantidad'
						UPDATE solicitud.solicitud.SolicitudCotizacionPartida 
						SET cantidad = @datoEditado
						WHERE idCotizacion = @idCotizacion
						AND idPartida = @idPartida

						SET @err = @dato + ' actualizada de la partida ' + CAST(@idPartida AS VARCHAR(50))
						SET @msj = 'OK'
						SELECT @msj  AS mensaje
					END
			END


END

--USE [Solicitud]
go

