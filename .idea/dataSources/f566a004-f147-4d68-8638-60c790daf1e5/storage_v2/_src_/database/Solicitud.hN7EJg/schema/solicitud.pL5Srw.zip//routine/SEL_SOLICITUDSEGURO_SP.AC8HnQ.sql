-- =============================================
-- Author:		<Jose Luis Lozada guerrero>
-- Create date: <06/05/2020>
-- Description:	<Obtiene las preordenes>
-- =============================================
/*
	exec [solicitud].SEL_SOLICITUDSEGURO_SP null,'Preorden','Automovil',6282,
	'<contratos><contrato><numeroContrato>43</numeroContrato><idCliente>185</idCliente><rfcEmpresa>ASE0508051B6</rfcEmpresa></contrato></contratos>',6766,0,0,null

*/
CREATE PROCEDURE [solicitud].[SEL_SOLICITUDSEGURO_SP]
@idFase					varchar(50) = 'null',
@idPaso					varchar(50) = 'null',
@idClase				varchar(10),
@idUsuario				INT,
@contratos				XML,
@idZona					INT = 0,
@idObjeto				INT = 0,
@idTipoObjeto			INT = 0,
@err					varchar(500)OUTPUT	
AS
BEGIN

	DECLARE @tbl_contratos AS TABLE(numeroContrato VARCHAR(50),idCliente INT,rfc VARCHAR(13))
	DECLARE @tbl_solicitudes AS TABLE(	[ID] [int] NULL,
										[rfcEmpresa] [varchar](13) NULL,
										[nombreContrato] [varchar](100) NULL,
										[Cliente] [nvarchar](250) NULL,
										[Zona] [varchar](500) NULL,
										[Referencia] [varchar](50) NULL,
										[VIN] [varchar](500) NULL,
										[Anio] [varchar](500) NULL,
										[NumeroEconomico] [varchar](500) NULL,
										[Marca] [varchar](250) NULL,
										[Submarca] [varchar](250) NULL,
										[Combustible] [varchar](250) NULL,
										[Clase] [varchar](250) NULL,
										[Cilindros] [varchar](250) NULL,
										[fechaCreacion] [datetime] NULL,
										[idZona] [INT],
										[idObjeto] [INT],
										[idTipoObjeto] [INT])
										
	INSERT INTO @tbl_contratos
	SELECT
		ParamValues.col.value('numeroContrato[1]','varchar(50)'),
		ParamValues.col.value('idCliente[1]','int'),
        ParamValues.col.value('rfcEmpresa[1]','varchar(13)')
        FROM @contratos.nodes('contratos/contrato') AS ParamValues(col)

	INSERT INTO @tbl_solicitudes
	SELECT	s.idSolicitud ID,
			s.rfcEmpresa,
			ISNULL((SELECT nombre FROM cliente.cliente.contrato WHERE rfcEmpresa=s.rfcEmpresa AND idCliente=s.idCliente AND numeroContrato=s.numeroContrato),'')'nombreContrato',
			ISNULL((SELECT nombre FROM cliente.Cliente.Cliente WHERE	idCliente=S.idCliente AND activo=1),'') 'Cliente',
			common.gerencia.SEL_OBTENERZONA_FN(s.rfcEmpresa,s.idCliente,s.numeroContrato,s.idClase,s.idTipoObjeto,s.idObjeto) 'Zona',
			sc.numeroSiniestro 'Referencia',
			Objeto.objeto.getPropiedadObjeto(s.idObjeto,'VIN','Clase',s.idClase)	'VIN',
			Objeto.objeto.getPropiedadObjeto(s.idObjeto,'Año','Clase',s.idClase)	'Anio',
			Objeto.objeto.getPropiedadObjeto(s.idObjeto,'NumeroEconomico','Clase',s.idClase)	'NumeroEconomico',
			partida.partida.SEL_PROPIEDADTIPOOBJETO_FN(s.idClase,'Marca',s.idTipoObjeto) 'Marca',
			partida.partida.SEL_PROPIEDADTIPOOBJETO_FN(s.idClase,'Submarca',s.idTipoObjeto) 'Submarca',
			partida.partida.SEL_PROPIEDADTIPOOBJETO_FN(s.idClase,'Combustible',s.idTipoObjeto) 'Combustible',
			partida.partida.SEL_PROPIEDADTIPOOBJETO_FN(s.idClase,'Clase',s.idTipoObjeto) 'Clase',
			partida.partida.SEL_PROPIEDADTIPOOBJETO_FN(s.idClase,'Cilindros',s.idTipoObjeto) 'Cilindros',
			fechaCreacion,
			CCO.idContratoZona,
			s.idObjeto,
			s.idTipoObjeto
			
	--,		SELECT * 
	FROM	seguro.Solicitud s 
	INNER	JOIN seguro.SolicitudCorreo sc ON s.solicitudCorreoMessageId=sc.messageId
	INNER	JOIN @tbl_contratos CON ON CON.numeroContrato = s.numeroContrato AND CON.idCliente = s.idCliente AND CON.rfc = s.rfcEmpresa
	LEFT	JOIN [Cliente].[contrato].[Objeto] CCO ON CCO.idObjeto = s.idObjeto
	LEFT	JOIN [common].[gerencia].[ContratoZona] CGC ON CGC.idContratoZona = CCO.idContratoZona 
	WHERE   s.idClase	=@idClase
	ORDER BY 1 asc

	SELECT * FROM @tbl_solicitudes
	WHERE	(@idZona = 0 OR (@idZona > 0 AND idZona = @idZona)) AND
			(@idObjeto = 0 OR (@idObjeto > 0 AND idObjeto = @idObjeto)) AND
			(@idTipoObjeto = 0 OR (@idTipoObjeto > 0 AND idTipoObjeto = @idTipoObjeto))	
	ORDER BY ID DESC

END
go

