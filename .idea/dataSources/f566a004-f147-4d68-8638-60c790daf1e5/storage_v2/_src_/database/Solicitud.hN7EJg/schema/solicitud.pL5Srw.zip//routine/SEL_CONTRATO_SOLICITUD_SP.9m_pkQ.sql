-- =============================================
-- Author:		Martin Pacheco
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [solicitud].[SEL_CONTRATO_SOLICITUD_SP]
	@idSolicitud		INT,
	@idUsuario			INT,
	@err				VARCHAR(MAX) OUTPUT
AS
BEGIN
	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	;WITH [ContratoCTE] AS (
		SELECT 
			 [C].[idFileAvatar]
			,[S].[numero]
		FROM [solicitud].[Solicitud] AS [S]
		INNER JOIN [Cliente].[cliente].[Contrato] AS [C] ON 
			[S].[rfcEmpresa] = [C].[rfcEmpresa] AND
			[S].[idClase] = [C].[idClase] AND
			[S].[idCliente] = [C].[idCliente]
		WHERE [S].[idSolicitud] = @idSolicitud	
	)
	SELECT 
		 [idFileAvatar]
		,[numero]
	FROM [ContratoCTE]

	SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

