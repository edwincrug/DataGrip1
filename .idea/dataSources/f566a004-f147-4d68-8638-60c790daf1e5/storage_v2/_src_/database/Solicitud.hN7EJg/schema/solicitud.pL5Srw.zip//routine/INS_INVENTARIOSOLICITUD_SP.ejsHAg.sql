-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
/*
	Test:
	declare @salida nvarchar(max);
	EXEC [solicitud].[INS_INVENTARIOSOLICITUD_SP]
	'<propiedades>
		<propiedad><index>0</index><valor>0</valor><propiedadDesc>index</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>0</index><valor>213WP2019003090</valor><propiedadDesc>DeviceID</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>0</index><valor>357050060501305</valor><propiedadDesc>DeviceIMEI</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>0</index><valor>Dispositivo</valor><propiedadDesc>Tipo</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>1</index><valor>1</valor><propiedadDesc>index</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>1</index><valor>213WP2019003322</valor><propiedadDesc>DeviceID</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>1</index><valor>357050060520610</valor><propiedadDesc>DeviceIMEI</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>1</index><valor>Dispositivo</valor><propiedadDesc>Tipo</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>2</index><valor>2</valor><propiedadDesc>index</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>2</index><valor>213WP2019003331</valor><propiedadDesc>DeviceID</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>2</index><valor>357050060519919</valor><propiedadDesc>DeviceIMEI</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>2</index><valor>Dispositivo</valor><propiedadDesc>Tipo</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>3</index><valor>3</valor><propiedadDesc>index</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>3</index><valor>213WP2019003001</valor><propiedadDesc>DeviceID</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>3</index><valor>357050060520099</valor><propiedadDesc>DeviceIMEI</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
		<propiedad><index>3</index><valor>Dispositivo</valor><propiedadDesc>Tipo</propiedadDesc><fechaCaducidad/><id>0</id></propiedad>
	</propiedades>', 880, 'CompraGPS', 0, 'CONCATENAR', @salida output
	print @salida
*/
-- =============================================
CREATE PROCEDURE [solicitud].[INS_INVENTARIOSOLICITUD_SP]
	-- Add the parameters for the stored procedure here
	@propiedades		    XML,
	@idSolicitud			INT,
	@idTipoSolicitud		VARCHAR(10),
	@idUsuario				INT,
	@idTipoAccion					VARCHAR(10),
	@err					VARCHAR(8000) OUTPUT
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT OFF;

	DECLARE @tbl_propiedades AS TABLE (
		_row                    INT IDENTITY(1,1),
		[index]					INT,
		propiedadDesc			NVARCHAR(250),
        valor                   NVARCHAR(500),
		fechaCaducidad			DATETIME,
		id						INT
	)

	declare @tbl_inventario as table (
		noParte			varchar(max),
		cantidad		int
	)

	DECLARE @tbl_error AS TABLE (
		fila		INT,
		error		VARCHAR(250)
	)

	DECLARE @avanza INT = 1;

	-- Insert statements for procedure here
	INSERT INTO @tbl_propiedades([index], propiedadDesc, valor, fechaCaducidad, id)
	SELECT --p.col.value('id[1]', 'INT')
		p.col.value('index[1]', 'int')
		,p.col.value('propiedadDesc[1]', 'NVARCHAR(250)')
		,p.col.value('valor[1]', 'NVARCHAR(500)')
		,p.col.value('fechaCaducidad[1]', 'datetime')
		,p.col.value('id[1]', 'int')
	FROM @propiedades.nodes('propiedades/propiedad') AS p(col);

	IF(@idTipoAccion IN ('REEMPLAZAR', 'CONCATENAR'))
	BEGIN
		DELETE FROM solicitud.SolicitudPropiedadInventarioGeneral WHERE idSolicitud = @idSolicitud;
		DELETE FROM solicitud.SolicitudPropiedadInventarioTipoSolicitud WHERE idSolicitud = @idSolicitud;
	END

	DECLARE @index INT = 0
	
	INSERT INTO solicitud.SolicitudPropiedadInventarioGeneral
	SELECT @idSolicitud idSolicitud
		,sol.idTipoSolicitud
		,sol.idClase
		,sol.rfcEmpresa
		,sol.idCliente
		,sol.numeroContrato
		,tbl.[index] + 1 as idInventario
		,CASE WHEN pig.idTipoValor = 'Unico' THEN pig.idPropiedadInventarioGeneral ELSE pigval.idPropiedadInventarioGeneral END idPropiedadInventarioGeneral
		,CASE WHEN pig.idTipoValor = 'Unico' THEN tbl.valor ELSE '' END valor
		,tbl.fechaCaducidad
		,@idUsuario idUsuario
	FROM @tbl_propiedades tbl
		INNER JOIN solicitud.PropiedadInventarioGeneral pig on pig.valor = tbl.propiedadDesc
		LEFT JOIN solicitud.PropiedadInventarioGeneral pigval on pigval.valor = tbl.valor
		INNER JOIN solicitud.Solicitud sol on sol.idSolicitud = @idSolicitud

	INSERT INTO solicitud.SolicitudPropiedadInventarioTipoSolicitud
	SELECT  @idSolicitud idSolicitud
		,sol.idTipoSolicitud
		,sol.idClase
		,sol.rfcEmpresa
		,sol.idCliente
		,sol.numeroContrato
		,tbl.[index] + 1 as idInventario
		,CASE WHEN pig.idTipoValor = 'Unico' THEN pig.idPropiedadInventarioTipoSolicitud ELSE pigval.idPropiedadInventarioTipoSolicitud END idPropiedadInventarioTipoSolicitud
		,CASE WHEN pig.idTipoValor = 'Unico' THEN tbl.valor ELSE '' END valor
		,tbl.fechaCaducidad
		,@idUsuario idUsuario
	FROM @tbl_propiedades tbl
		INNER JOIN solicitud.PropiedadInventarioTipoSolicitud pig on pig.valor = tbl.propiedadDesc
		LEFT JOIN solicitud.PropiedadInventarioTipoSolicitud pigval on pigval.valor = tbl.valor
		INNER JOIN solicitud.Solicitud sol on sol.idSolicitud = @idSolicitud
	

	DECLARE @cantidad INT

	SELECT @cantidad = COUNT(DISTINCT idInventario) FROM solicitud.SolicitudPropiedadInventarioTipoSolicitud WHERE idSolicitud = @idSolicitud

	-- Se valida que la cantidada cargada sea la misma que la cantidad registrada en la partida
	IF ( (SELECT sum(cantidad) FROM solicitud.SolicitudCotizacionPartida sp WHERE idSolicitud = @idSolicitud and idEstatusCotizacionPartida = 'APROBADA') != @cantidad )
	BEGIN
		SET @err = 'Existe una diferencia entre la cantidad registrada y la cantidad cargada';
		
		INSERT INTO @tbl_error
		SELECT @index AS fila
			,'Existe una diferencia entre la cantidad registrada y la cantidad cargada' AS error
	END

	-- Se valida que existan las propiedades generales
	IF EXISTS (SELECT 1 FROM solicitud.SolicitudPropiedadInventarioGeneral WHERE idSolicitud = @idSolicitud AND idPropiedadInventarioGeneral IS NULL)
	BEGIN
		INSERT INTO @tbl_error
		SELECT idInventario as fila
			,'No se encontró la propiedad' as error
		FROM solicitud.SolicitudPropiedadInventarioGeneral
		WHERE idSolicitud = @idSolicitud
			AND idPropiedadInventarioGeneral IS NULL;

	END

	--Se verifica que exista el número de Parte en alguna partida
	INSERT INTO @tbl_inventario
	SELECT spig.valor, COUNT(1)
	FROM Solicitud.solicitud.SolicitudPropiedadInventarioGeneral spig
		INNER JOIN Solicitud.solicitud.PropiedadInventarioGeneral pig on pig.idPropiedadInventarioGeneral = spig.idPropiedadInventarioGeneral and pig.valor = 'noParte'
	WHERE spig.idSolicitud = @idSolicitud
	GROUP BY spig.valor


	IF EXISTS(SELECT 1
		FROM solicitud.solicitud.SolicitudCotizacionPartida scp
			INNER JOIN Partida.partida.PartidaPropiedadGeneral ppg on ppg.idPartida = scp.idPartida
			INNER JOIN Partida.partida.PropiedadGeneral pg on pg.idPropiedadGeneral = ppg.idPropiedadGeneral
			LEFT JOIN @tbl_inventario tbl on tbl.cantidad = scp.cantidad AND tbl.noParte = ppg.valor
		WHERE scp.idSolicitud = @idSolicitud
			AND pg.valor = 'noParte'
			AND scp.idEstatusCotizacionPartida = 'APROBADA'
			AND tbl.cantidad IS NULL
		)
	BEGIN
		SET @err = 'No coincide la cantidad de los números de parte registrados con los cargados';

		INSERT INTO @tbl_error
		SELECT ROW_NUMBER() over (order by scp.idSolicitud ) as fila
			,'para el noParte ' + ppg.valor + ' debe haber ' + convert(varchar,scp.cantidad) + ' registros'  as error
		FROM solicitud.solicitud.SolicitudCotizacionPartida scp
			INNER JOIN Partida.partida.PartidaPropiedadGeneral ppg on ppg.idPartida = scp.idPartida
			INNER JOIN Partida.partida.PropiedadGeneral pg on pg.idPropiedadGeneral = ppg.idPropiedadGeneral
		WHERE scp.idSolicitud = @idSolicitud
			AND pg.valor = 'noParte'
			AND scp.idEstatusCotizacionPartida = 'APROBADA'
	END


	IF ( @idTipoSolicitud = 'CompraGPS' )
	BEGIN
		-- Se valida que no exista un deviceIMEI repetido
		IF EXISTS (select 1
			FROM [Solicitud].[solicitud].[SolicitudPropiedadInventarioTipoSolicitud] spi
				inner join Solicitud.solicitud.PropiedadInventarioTipoSolicitud spt on spt.idPropiedadInventarioTipoSolicitud = spi.idPropiedadInventarioTipoSolicitud
				inner join Solicitud.solicitud.SolicitudPropiedadInventarioTipoSolicitud sp2 on sp2.valor = spi.valor and sp2.idSolicitud != @idSolicitud
				inner join Solicitud.solicitud.PropiedadInventarioTipoSolicitud spt2 on spt2.idPropiedadInventarioTipoSolicitud = spi.idPropiedadInventarioTipoSolicitud
			where spt.valor = 'deviceIMEI'
				and spi.idSolicitud = @idSolicitud
				and spt2.valor = 'deviceIMEI'
			)
		BEGIN
			SET @err = 'El GPS IMEI se encuentra repetido para algunos dispositivos.';

			INSERT INTO @tbl_error
			SELECT a.fila, a.error
			FROM
			(
				SELECT ROW_NUMBER() OVER (ORDER BY spi.idinventario) AS fila
					,'El GPS IMEI ya existe en la base: ' + spi.valor as error
					,sp2.idInventario
				FROM [Solicitud].[solicitud].[SolicitudPropiedadInventarioTipoSolicitud] spi
					INNER JOIN Solicitud.solicitud.PropiedadInventarioTipoSolicitud spt on spt.idPropiedadInventarioTipoSolicitud = spi.idPropiedadInventarioTipoSolicitud
					LEFT JOIN Solicitud.solicitud.SolicitudPropiedadInventarioTipoSolicitud sp2 on sp2.valor = spi.valor and sp2.idSolicitud != @idSolicitud
					LEFT JOIN Solicitud.solicitud.PropiedadInventarioTipoSolicitud spt2 on spt2.idPropiedadInventarioTipoSolicitud = spi.idPropiedadInventarioTipoSolicitud and spt2.valor = 'deviceIMEI'
				WHERE spt.valor = 'deviceIMEI'
					AND spi.idSolicitud = @idSolicitud
			) a 
			WHERE a.idInventario IS NOT NULL
		END
	END

	-- En dado caso de que existan errores se eliminan para una nueva carga
	IF ( (SELECT COUNT(1) FROM @tbl_error) > 0)
	BEGIN
		SELECT *
		FROM @tbl_error

		DELETE FROM solicitud.SolicitudPropiedadInventarioGeneral WHERE idSolicitud = @idSolicitud;
		DELETE FROM solicitud.SolicitudPropiedadInventarioTipoSolicitud WHERE idSolicitud = @idSolicitud;
	END
	
END



--USE [Solicitud]
go

