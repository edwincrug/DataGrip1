--[solicitud].[SEL_REGLA_SP]
CREATE PROCEDURE [solicitud].[SEL_EXISTE_PROVEEDOR_SP]
	@rfcProveedor			varchar(13) = '',
	@idProveedorEntidad		int = 0,
	@idUsuario				int,
	@err				    NVARCHAR(500) = '' OUTPUT
AS
BEGIN
	IF (@idProveedorEntidad != 0)
		BEGIN
			SELECT
			 [idProveedorEntidad]
			FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida]
			WHERE idProveedorEntidad = @idProveedorEntidad
			GROUP BY [rfcProveedor]
			  ,[idProveedorEntidad]
		END
	ELSE
		BEGIN
			SELECT
			  [rfcProveedor]
			FROM [Solicitud].[solicitud].[SolicitudCotizacionPartida]
			WHERE rfcProveedor = @rfcProveedor 
			GROUP BY [rfcProveedor]
		END
END
go

