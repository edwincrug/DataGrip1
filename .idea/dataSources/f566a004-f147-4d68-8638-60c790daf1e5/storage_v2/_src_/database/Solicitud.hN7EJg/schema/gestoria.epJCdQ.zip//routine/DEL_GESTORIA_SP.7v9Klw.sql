
-- =============================================
-- Author: Edgar Mendoza Gómez	
-- Create date: 03-07-2019
-- Description: Elimina gestorias
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [gestoria].[DEL_GESTORIA_SP] 1,'Automovil',6036, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [gestoria].[DEL_GESTORIA_SP] 
	@data					INT,
	@idClase				VARCHAR(10),
	@idUsuario				INT,
	@err					varchar(500)OUTPUT
AS


BEGIN

	--SELECT * FROM 
	UPDATE 
	gestoria.Gestoria 
	SET idEstatusGestoria = 'CANCELADA', activo = 0
	WHERE idGestoria = @data
	AND idClase = @idClase

END
go

