-- =============================================
-- Author:		Andres Farias
-- Create date: 30/05/2019
-- Description:	Regresa los tipos de cobro dependiendo la clase
-- =============================================
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	EXEC [partida].[SEL_PARTIDATIPOCOBRO_SP] @idClase = 'Automovil'
*/
-- =============================================
CREATE PROCEDURE [partida].[SEL_PARTIDATIPOCOBRO_SP]
@idClase            varchar(250),
@idUsuario			int,
@err				nvarchar(500) = '' OUTPUT

AS
BEGIN
	SELECT idTipoCobro, nombre, descripcion FROM partida.tipocobro where idClase = @idClase and activo = 1
END
go

