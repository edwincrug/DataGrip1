-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
/*
	DELETE FROM migracionFotos
	EXEC SEL_OBTENER_FOTOS_PARTIDAS_SP

*/
CREATE PROCEDURE SEL_OBTENER_FOTOS_PARTIDAS_SP
	
AS
BEGIN

	DECLARE @tabla TABLE(idd int identity(1,1),partida nvarchar(50),foto nvarchar(500),instructivo nvarchar(500))
	--CREATE TABLE migracionFotos (partidaSV2 nvarchar(50),foto nvarchar(500),instructivo nvarchar(500),idPartidaSV3 int)
	
	INSERT INTO @tabla(partida,foto,instructivo)
	SELECT	p.partida,p.foto,p.instructivo
			--uni.idUnidad,mar.nombre,sub.nombre,tc.tipoCombustible,cil.cilindros,tu.tipo, p.partida,p.foto,p.instructivo --ppg.idPartida
	FROM	[partidas]..Unidad uni 
	INNER	JOIN [partidas]..TipoCombustible tc on uni.idTipoCombustible=tc.idTipoCombustible
	INNER	JOIN [partidas]..SubMarca sub on uni.idSubMarca=sub.idSubMarca
	INNER	JOIN [partidas]..Marca mar on mar.idMarca=sub.idMarca
	INNER	JOIN [partidas]..Cilindros cil on uni.idCilindros = cil.idCilindros
	INNER	JOIN [partidas]..TipoUnidad tu on tu.idTipoUnidad=uni.idTipoUnidad
	--PARTIDAS
	inner	join [partidas]..Partida p on p.idUnidad=uni.idUnidad
	where (p.foto !='' or p.instructivo!='') 


	DECLARE @v_idd int,@v_partida NVARCHAR(50),@v_foto nvarchar(500),@v_instructivo nvarchar(500),@v_idPartida INT
	PRINT 'PASO 1'
	WHILE EXISTS(SELECT 1 FROM @tabla)
		BEGIN
			SELECT TOP 1 @v_idd=idd,@v_partida=partida,@v_foto=foto,@v_instructivo=instructivo FROM @tabla
			
			SET @v_idPartida=NULL
			SELECT	@v_idPartida=idPartida 
			FROM	Partida.partida.partidapropiedadgeneral 
			WHERE	valor	=	@v_partida

			IF @v_idPartida IS NOT NULL
				BEGIN
					INSERT INTO migracionFotos(partidaSV2,foto,instructivo,idPartidaSV3)
					VALUES(@v_partida,@v_foto,@v_instructivo,@v_idPartida)
				END
			DELETE FROM @tabla WHERE idd=@v_idd
		END

		SELECT * FROM migracionFotos
--(275518 rows affected)
END


go

