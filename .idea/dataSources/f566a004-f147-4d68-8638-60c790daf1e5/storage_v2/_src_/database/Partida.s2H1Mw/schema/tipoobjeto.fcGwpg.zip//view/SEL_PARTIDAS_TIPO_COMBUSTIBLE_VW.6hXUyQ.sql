
-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<30/04/2020>
-- Description:	    <Vista para obtener los tipos de gasolina para partidas>
-- =============================================
--SELECT 
--	[idTipoObjeto]
--	,[idClase]
--	,[idPropiedadClase]
--	,[idPadre]
--	,[idTipoValor]
--	,[idTipoDato]
--	,[agrupador]
--	,[valor]
--	,[obligatorio]
--	,[orden]
--	,[posicion]
--	,[activo]
--	,[idUsuario]
--[tipoobjeto].[SEL_PARTIDAS_TIPO_COMBUSTIBLE_VW]
-- =============================================
CREATE VIEW [tipoobjeto].[SEL_PARTIDAS_TIPO_COMBUSTIBLE_VW]
AS

SELECT 
	TTOPC.[idTipoObjeto]
	,TTOPC.[idClase]
	,TTOPC.[idPropiedadClase]
	,TOPC.[idPadre]
	,TOPC.[idTipoValor]
	,TOPC.[idTipoDato]
	,TOPC.[agrupador]
	,TOPC.[valor]
	,TOPC.[obligatorio]
	,TOPC.[orden]
	,TOPC.[posicion]
	,TOPC.[activo]
	,TOPC.[idUsuario]
FROM [Partida].[tipoobjeto].[PropiedadClase] TOPC
INNER JOIN [Partida].[tipoobjeto].[TipoObjetoPropiedadClase] TTOPC
	ON TOPC.[idPropiedadClase] = TTOPC.[idPropiedadClase]
	AND TOPC.[idClase] = TTOPC.[idClase]
WHERE TOPC.[agrupador] = 'Combustible'
	AND TOPC.[idPadre] IS NOT NULL
	AND TOPC.[activo] = 1
go

