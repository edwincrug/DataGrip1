
-- =============================================
-- Author:		<José Luis Lozada Guerrero>
-- Create date: <27/04/2020>
-- Description:	<Actualiza las versiones del tipo de objeto en la tabla partida.tipoobjeto.Version>
	/*
	EXEC [tipoobjeto].[UPD_TIPOOBJETOVERSION_SP] 1,109,'Automovil','version','100YTYTY',6282,null

	*/
-- =============================================
CREATE PROCEDURE [tipoobjeto].[UPD_TIPOOBJETOVERSION_SP]
@idVersion		INT,
@idTipoObjeto	INT,
@idClase		VARCHAR(10),
@campo			VARCHAR(500),
@valor			VARCHAR(500),
@idUsuario		INT,
@err			VARCHAR(500) OUTPUT
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
		

			SET @err=''
			DECLARE @query VARCHAR(300)=''
			DECLARE @setFields VARCHAR(200)=''

			IF @campo='version'			SET @setFields='version='''+@valor+''''

			SET @query	=' UPDATE partida.tipoobjeto.Version '
			SET @query +=' SET ' + @setFields
			SET @query +=' WHERE   idVersion	='+CAST(@idVersion AS VARCHAR)
			SET @query +=' AND     idTipoObjeto ='+CAST(@idTipoObjeto AS VARCHAR)
			SET @query +=' AND     idClase		='''+@idClase+''''
			print @query
			EXEC(@query)
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH

END
go

