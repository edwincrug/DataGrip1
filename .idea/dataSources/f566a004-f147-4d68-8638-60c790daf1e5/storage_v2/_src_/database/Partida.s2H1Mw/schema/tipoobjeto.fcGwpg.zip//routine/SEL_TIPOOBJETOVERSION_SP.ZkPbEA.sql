-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <27/04/2020>
-- Description:	<Obtiene todas las versiones de un tipo de objeto>
/*
	exec [tipoobjeto].[SEL_TIPOOBJETOVERSION_SP] 1,109,'automovil',6282,null	
	exec [tipoobjeto].[SEL_TIPOOBJETOVERSION_SP] 0,109,'automovil',6282,null	
*/
-- =============================================
CREATE PROCEDURE [tipoobjeto].[SEL_TIPOOBJETOVERSION_SP]
@idVersion		 INT,
@idTipoObjeto	 INT,
@idClase		 VARCHAR(10),
@idUsuario		 INT,
@err			 VARCHAR(8000) = '' OUTPUT		
AS
BEGIN

	/*El parametro @idVersion en algunas pantallas en las que no se requiere recuperar todo el listado de versiones, este parametro se envia con valor cero
	  en caso de que se requieran los datos de una sola version, este llega al sp con valor distinto de cero y obtiene los datos solo de 1 registro
	*/
	IF @idVersion=0 SET @idVersion=NULL
	SET @err=''
	SELECT	idVersion,
			idTipoObjeto,
			idClase,
			version,
			activo,
			idUsuario 
	FROM partida.tipoobjeto.Version
	WHERE idVersion =COALESCE(@idVersion,idVersion)
	AND idTipoObjeto=@idTipoObjeto 
	AND idClase		=@idClase
	AND activo=1
END
go

