
-- =============================================
-- Author: JLuis Lozada
-- Create date: 01/10/2020
-- Description: Consulta dinámica recursiva para obtener las propiedades de un grupo de partidas
-- ============== Versionamiento ================
/*
	Fecha		Autor			Descripción 
 exec [partida].[SEL_PROPIEDADES_PARTIDAS_MULTIPLE_SP] 1055,'Instala','Automovil','AAN910409135',218,'0001', 
 '<datos>
	<item><idTipoObjeto>118</idTipoObjeto><idPartida>499544</idPartida></item>
	<item><idTipoObjeto>118</idTipoObjeto><idPartida>787282</idPartida></item>
	<item><idTipoObjeto>118</idTipoObjeto><idPartida>787283</idPartida></item>
	<item><idTipoObjeto>118</idTipoObjeto><idPartida>787284</idPartida></item>
	<item><idTipoObjeto>118</idTipoObjeto><idPartida>787285</idPartida></item>
	<item><idTipoObjeto>115</idTipoObjeto><idPartida>624077</idPartida></item>
	<item><idTipoObjeto>115</idTipoObjeto><idPartida>787289</idPartida></item>
	<item><idTipoObjeto>115</idTipoObjeto><idPartida>787290</idPartida></item>
	<item><idTipoObjeto>115</idTipoObjeto><idPartida>787291</idPartida></item>
	<item><idTipoObjeto>115</idTipoObjeto><idPartida>787292</idPartida></item>
  </datos>',
 1, null  

*/


-- =============================================  
CREATE PROCEDURE [partida].[SEL_PROPIEDADES_PARTIDAS_MULTIPLE_SP]
 @idSolicitud		INT,
 @idTipoSolicitud	VARCHAR(10),
 @idClase			VARCHAR(10),  
 @rfcEmpresa		VARCHAR(13),
 @idCliente			INT,  
 @numeroContrato	VARCHAR(50),  
 @partidas			XML,
 @idUsuario			INT,  
 @err				VARCHAR(500) OUTPUT  
AS  
BEGIN
	DECLARE @v_sq				NVARCHAR(max)='',
			@TablaPartida		VARCHAR(100)='',
			@camposPivotPartida VARCHAR(1000),
			@camposPivotKey		VARCHAR(1000)
	DECLARE @tPartida TABLE(idd INT identity, idPartida INT,idTipoObjeto INT)
	DECLARE @tCamposExtras TABLE(campo VARCHAR(50),orden int)
	DECLARE @txPartidas TABLE(idTipoObjeto INT, idPartida INT)

	INSERT INTO @txPartidas(idTipoObjeto,idPartida) 
	SELECT	I.col.value('idTipoObjeto[1]','int'),I.col.value('idPartida[1]','int')
	FROM	@partidas.nodes('datos/item') AS I(col)


	IF OBJECT_ID('tempdb..#tablaDatosPartida')IS NOT NULL DROP TABLE #tablaDatosPartida
	CREATE TABLE #tablaDatosPartida([idPartida] [int] NULL,[idTipoObjeto] [int] NULL, [agrupador] [varchar](250) NULL, [valor] [varchar](500) NULL)

	SET @TablaPartida ='TxPartida_'+CAST(CAST(RAND(CHECKSUM(NEWID()))*10000000 AS INT) AS VARCHAR)

	INSERT INTO @tCamposExtras VALUES('Mano de Obra',100)
	INSERT INTO @tCamposExtras VALUES('Refacciones',101)
	INSERT INTO @tCamposExtras VALUES('Lubricantes',102)

	/*PROPIEDADES DINAMICAS [PARTIDAS]*/
	BEGIN
		INSERT INTO @tPartida (idPartida,idTipoObjeto) 
		SELECT	DISTINCT idPartida,idtipoObjeto	
		FROM	@txPartidas
		
	
		SET		@camposPivotPartida		= ISNULL(STUFF((SELECT ',' + QUOTENAME(px.campo) FROM(	SELECT  pa.campo,pa.orden
																								FROM	Common.reporte.partida pa  
																								WHERE	idClase = @idClase
																								AND     pa.campo NOT IN ('Marca')
																								UNION	ALL 
																								SELECT	campo,orden 
																								FROM	@tCamposExtras)px
														ORDER BY px.orden ASC  FOR XML PATH('')),1,1,''),'sinCoinicidencia')
		SET		@camposPivotKey			= 'idPartida,idTipoObjeto'
		SET		@camposPivotPartida 	= REPLACE(@camposPivotPartida,' ','_')
	
		INSERT INTO #tablaDatosPartida(idPartida,idTipoObjeto,agrupador,valor) 
		select	s.idPartida,s.idTipoObjeto,tc.campo,
				CASE 
					WHEN tc.tipoDato in ('Image', 'Pdf', 'Documento' )  THEN (	SELECT	valor 
																				FROM	Common.configuracion.configuracion 
																				WHERE	nombre = 'fileServer') + (	SELECT	PATH 
																													FROM	FileServer.documento.Documento 
																													WHERE	idDocumento = [partida].[partida].[getPropiedadPartida](s.idPartida, tc.campo, tc.tipoPropiedad)) 
					ELSE [partida].[partida].[getPropiedadPartida](s.idPartida, tc.campo, tc.tipoPropiedad)	
				END	valor
		FROM	@tPartida s,(SELECT campo,tipoPropiedad,orden,tipoDato FROM Common.reporte.partida (NOLOCK) WHERE idClase=@idClase) tc ORDER BY tc.orden ASC 

		INSERT INTO #tablaDatosPartida
		SELECT	par.idPartida,par.idTipoObjeto,tc.nombre ,ISNULL(parcos.costo,0) valor  
		FROM	partida.tipoobjeto.TipoObjeto tob   
		INNER	JOIN @tPartida par on tob.idTipoObjeto = par.idTipoObjeto  
		INNER	JOIN partida.partida.PartidaCosto parcos on parcos.idPartida = par.idPartida   
		INNER	JOIN partida.TipoCobro tc on parcos.idTipoCobro = tc.idTipoCobro  

		SET @v_sq='SELECT r.* INTO '+ @TablaPartida +' from (select '+@camposPivotKey+',agrupador,valor from #tablaDatosPartida) AS tx PIVOT (max(valor) for agrupador in ('+@camposPivotPartida+')) as r '
		EXEC SP_EXECUTESQL @v_sq
	END

	SET @v_sq=  ' SELECT tx.*, '
	SET @v_sq+= ' ISNULL((SELECT SUM(costo) FROM partida.PartidaCosto cos WHERE cos.idPartida = tx.idPartida),0)* tx.cant Costo,'
	SET @v_sq+= ' ISNULL((SELECT SUM(Venta) FROM cliente.contrato.PartidaPrecio pre WHERE pre.idPartida = tx.idPartida AND pre.idCliente = ' + CAST(@idCliente AS VARCHAR) + ' AND numeroContrato = ''' + @numeroContrato + ''')* tx.cant,0) Venta'
	SET @v_sq+= ' FROM  ('
	SET @v_sq+= '			SELECT	[objeto].[objeto].[getPropiedadObjeto](pa.idTipoObjeto, ''Marca'',    ''tipoClase'','''+@idClase+''') as ''Marca unidad'','
	SET @v_sq+= '					[objeto].[objeto].[getPropiedadObjeto](pa.idTipoObjeto, ''Submarca'', ''tipoClase'','''+@idClase+''') as ''Submarca unidad'','
	SET @v_sq+= '					[objeto].[objeto].[getPropiedadObjeto](pa.idTipoObjeto, ''Clase'',    ''tipoClase'','''+@idClase+''') as ''Clase unidad'','
	SET @v_sq+= '					pa.*,'
	SET @v_sq+= '					ISNULL((	SELECT SUM(cantidad) FROM solicitud.solicitud.solicitudPartida spa WHERE spa.idTipoObjeto=pa.idTipoObjeto AND spa.idPartida=pa.idPartida '
	SET @v_sq+= '								AND spa.idSolicitud		= '  +CAST(@idSolicitud AS VARCHAR)
	SET @v_sq+= '								AND spa.idTipoSolicitud = '''+@idTipoSolicitud+''''
	SET @v_sq+= '								AND spa.idClase			= '''+@idClase+''''
	SET @v_sq+= '								AND spa.rfcEmpresa		= '''+@rfcEmpresa+''''
	SET @v_sq+= '								AND spa.idCliente		= '  +CAST(@idCliente AS VARCHAR)
	SET @v_sq+= '								AND spa.numeroContrato	= '''+@numeroContrato+''' GROUP BY idTipoObjeto,idPartida),0)cant'
	SET @v_sq+= '			FROM '+@TablaPartida +' pa'
	SET @v_sq+= '		)tx order by tx.[Marca unidad],tx.[Submarca unidad]'
	
	print @v_sq
	EXECUTE (@v_sq)

	SET @v_sq   =' DROP TABLE '+@TablaPartida 
	EXECUTE (@v_sq)
	
	SELECT	'' rfcProveedor, 0 idProveedorEntidad,idPartida,idObjeto,idTipoObjeto,partida.getPropiedadPartida(idPartida,'noParte','general') noParte,0 costo, 0 venta
	-- select *
	FROM solicitud.solicitud.solicitudPartida 
	where idSolicitud	=@idSolicitud
	AND idClase			=@idClase
	and idCliente		=@idCliente
	and numeroContrato	=@numeroContrato

	
end



go

