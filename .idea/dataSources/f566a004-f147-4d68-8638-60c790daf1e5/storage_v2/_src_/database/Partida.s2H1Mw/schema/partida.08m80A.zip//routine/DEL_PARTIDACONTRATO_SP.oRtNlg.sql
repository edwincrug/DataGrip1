-- =============================================
-- Author: Edgar Mendoza Gomez	
-- Create date: 03-04-2019
-- Description: Elimina Partida Propia
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [partida].[DEL_PARTIDACONTRATO_SP] 
	'<Ids>
		<idPartida>11</idPartida>
	</Ids>'
   ,
	@salida OUTPUT;
	SELECT @salida AS salida;

	
*/
-- =============================================
CREATE  PROCEDURE [partida].[DEL_PARTIDACONTRATO_SP] 
@data					XML,
@idUsuario				INT,
@idClase				VARCHAR(10),
@numeroContrato			VARCHAR(50),
@idCliente				INT,
@rfc					VARCHAR(13),
@err				    NVARCHAR(500) OUTPUT
AS
BEGIN
	
	DECLARE @idPartida	AS INT
    DECLARE @tbl_propiedades AS TABLE(
        idPartida			INT
    )


    INSERT INTO @tbl_propiedades
    SELECT
        I.N.value('.','int')
        FROM @data.nodes('/Ids/idPartida') AS I(N)

	UPDATE partida.PartidaContrato 
	SET activo = 0 
	WHERE idPartidaContrato in (SELECT idPartida 
							FROM @tbl_propiedades)
	AND idClase = @idClase
	AND numeroContrato = @numeroContrato
	AND rfcEmpresa = @rfc
	AND idCliente = @idCliente

END
go

