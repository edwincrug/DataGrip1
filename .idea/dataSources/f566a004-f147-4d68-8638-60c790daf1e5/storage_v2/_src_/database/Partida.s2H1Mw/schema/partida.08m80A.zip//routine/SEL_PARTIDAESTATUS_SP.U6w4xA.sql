
-- =============================================
-- Author:		<Gerardo Zamudio>
-- Create date: <19/05/2020>
-- Description:	<Obtener los estatus de las partidas >
-- =============================================
/*
	Fecha		Autor	Descripción 
	--2019

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [contrato].[SEL_ESTATUS_SP]
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [partida].[SEL_PARTIDAESTATUS_SP]
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS

BEGIN
	 SET @err = '';

	SELECT 
		idPartidaEstatus
		,nombre
		,activo
	FROM Partida.partida.PartidaEstatus
	WHERE activo = 1
END
go

