
-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<30/04/2020>
-- Description:	    <Vista para obtener las especialidades de las partidas>
-- =============================================
--SELECT
--	[idPartida]
--    ,[idTipoObjeto]
--    ,[idClase]
--    ,[idPropiedadClase]
--	,[idPadre]
--	,[idTipoValor]
--	,[idTipoDato]
--	,[agrupador]
--	,[valor]
--	,[obligatorio]
--	,[orden]
--	,[posicion]
--	,[activo]
--	,[idUsuario]
--FROM [partida].[SEL_PARTIDAS_ESPECIALIDADES_VW]
-- =============================================
CREATE VIEW [partida].[SEL_PARTIDAS_ESPECIALIDADES_VW]
AS
SELECT
	PPPC.[idPartida]
    ,PPPC.[idTipoObjeto]
    ,PPPC.[idClase]
    ,PPPC.[idPropiedadClase]
	,PPC.[idPadre]
	,PPC.[idTipoValor]
	,PPC.[idTipoDato]
	,PPC.[agrupador]
	,PPC.[valor]
	,PPC.[obligatorio]
	,PPC.[orden]
	,PPC.[posicion]
	,PPC.[activo]
	,PPC.[idUsuario]
FROM [Partida].[partida].[PartidaPropiedadClase] PPPC 
INNER JOIN [Partida].[partida].[PropiedadClase] PPC
	ON PPPC.idPropiedadClase = PPC.idPropiedadClase
WHERE PPC.agrupador = 'Especialidad'
	AND PPC.idPadre IS NOT NULL
	AND PPC.activo = 1
go

