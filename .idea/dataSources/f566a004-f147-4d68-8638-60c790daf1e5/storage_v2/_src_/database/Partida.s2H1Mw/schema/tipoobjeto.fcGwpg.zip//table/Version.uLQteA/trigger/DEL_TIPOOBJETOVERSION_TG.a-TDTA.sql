-- =============================================
-- Author:		<Jose Luis Lozada>
-- Create date: <04/05/2020>
-- Description:	<borrado de Integridades>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	
	--Test

*/

create TRIGGER [tipoobjeto].[DEL_TIPOOBJETOVERSION_TG] 
   ON  [tipoobjeto].[Version]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	--ELIMINAMOS INTEGRIDADES
	DECLARE @UID varchar(50),
			@UserName varchar(50), 
			@Email varchar(max),
			@idVersion			INT,
			@idTipoObjeto		INT,
			@idClase			VARCHAR(10),
			@IdUsuario			INT,
			@VC_ThrowTable		VARCHAR(300) = ''
	
	SELECT	@IdUsuario	= 2 
	

	--Cliente
	BEGIN TRANSACTION;
	BEGIN TRY

		SET @VC_ThrowTable = '[Objeto].[integridad].[Version]';
		DELETE FROM [Objeto].[integridad].[Version]
		WHERE CAST(idVersion AS VARCHAR) + CAST(idTipoObjeto AS VARCHAR) + idClase 
			IN (SELECT CAST(idVersion AS VARCHAR) + CAST(idTipoObjeto AS VARCHAR) + idClase	FROM deleted)

	COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
	END CATCH
	

END

go

