-- =============================================  
-- Author:  Andres Farias  
-- Create date: 30/05/2019  
-- Description: Agregar tipo de cobro a partidas  
-- =============================================  
/*  
 Fecha  Autor Descripción   
   
  
 *- Testing...  
 DECLARE @salida varchar(max) ='' ;  
 EXEC [partida].[INS_PARTIDACOSTO_SP]  
 '<tiposCostos><tipocosto><idPartida>31899</idPartida><costo>0</costo><idTipoCobro>LU</idTipoCobro><idClase>Automovil</idClase><idUsuario>6036</idUsuario></tipocosto><tipocosto><idPartida>31899</idPartida><costo>45</costo><idTipoCobro>MO</idTipoCobro><idC
lase>Automovil</idClase><idUsuario>6036</idUsuario></tipocosto><tipocosto><idPartida>31899</idPartida><costo>0</costo><idTipoCobro>RE</idTipoCobro><idClase>Automovil</idClase><idUsuario>6036</idUsuario></tipocosto></tiposCostos>'  
 ,  
 @salida OUTPUT;  
 SELECT @salida AS salida;  
  
   
*/  
-- =============================================  
CREATE PROCEDURE [partida].[INS_PARTIDACOSTO_SP]  
@costos     XML,  
@idTipoObjeto   INT,
@idClase	varchar(10),  
@idUsuario    INT,  
@err        NVARCHAR(500) = '' OUTPUT  
AS  
BEGIN  
   
 INSERT INTO partida.PartidaCosto( costo, idPartida, idTipoCobro, idClase, idUsuario, idTipoObjeto)  
 SELECT  
  ParamValues.col.value('costo[1]','varchar(250)'),  
  ParamValues.col.value('idPartida[1]','int'),  
  ParamValues.col.value('idTipoCobro[1]','varchar(10)'),
  @idClase,
  @idusuario,
  @idTipoObjeto  
 FROM @costos.nodes('tiposCostos/tipocosto') AS ParamValues(col) 

 DECLARE @idPartida INT

	SELECT
		@idPartida = ParamValues.col.value('idPartida[1]','int')
	FROM @costos.nodes('tiposCostos/tipocosto') AS ParamValues(col) 
 
 
 IF (@idClase = 'Automovil')

	BEGIN
	IF NOT EXISTS(select 1 from [Cliente].[integridad].[PartidaCosto] WHERE idPartida = @idPartida AND idTipoCobro = 'MO' AND idClase = @idClase)

		BEGIN
				INSERT INTO [Cliente].[integridad].[PartidaCosto]
				SELECT DISTINCT
					@idpartida
					,'MO'
					,@idClase

		END

	IF NOT EXISTS(select 1 from [Cliente].[integridad].[PartidaCosto] WHERE idPartida = @idPartida AND idTipoCobro = 'RE' AND idClase = @idClase)

		BEGIN
				INSERT INTO [Cliente].[integridad].[PartidaCosto]
				SELECT DISTINCT
					@idpartida
					,'RE'
					,@idClase

		END

	IF NOT EXISTS(select 1 from [Cliente].[integridad].[PartidaCosto] WHERE idPartida = @idPartida AND idTipoCobro = 'LU' AND idClase = @idClase)

		BEGIN
				INSERT INTO [Cliente].[integridad].[PartidaCosto]
				SELECT DISTINCT
					@idpartida
					,'LU'
					,@idClase

		END

	END

		
END
go

