-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 10/08/2019
-- Description:	Obtiene la propiedad del objeto
-- SELECT tipoObjeto.SEL_PROPIEDADOBJETO_FN(100, 'Automovil', 2)
-- =============================================
CREATE FUNCTION [tipoobjeto].[SEL_PROPIEDADOBJETO_FN] 
(
	@idTipoObjeto INT, @idClase VARCHAR(10), @idPropiedadGeneral INT 
)
RETURNS VARCHAR(500)
AS
BEGIN
	DECLARE @valor VARCHAR(500)

	SELECT @valor = valor
	FROM tipoobjeto.TipoObjetoPropiedadGeneral
	WHERE idTipoObjeto = @idTipoObjeto
	AND idClase = @idClase
	AND idPropiedadGeneral = @idPropiedadGeneral

	RETURN @valor

END
go

