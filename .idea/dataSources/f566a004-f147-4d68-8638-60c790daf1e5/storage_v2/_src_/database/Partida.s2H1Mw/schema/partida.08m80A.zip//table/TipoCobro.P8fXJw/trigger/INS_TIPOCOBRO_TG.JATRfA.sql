
-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <04/07/2019>
-- Description:	<Alta de Integridades>
-- =============================================
CREATE TRIGGER [partida].[INS_TIPOCOBRO_TG] 
   ON  [partida].[TipoCobro]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @idTipoCobro		VARCHAR(13),
			@idClase			VARCHAR(10),
			@IdUsuario			INT,
			@VC_ThrowTable		VARCHAR(300) = ''

	SELECT TOP 1 @idTipoCobro=idTipoCobro, @idClase=idClase, @IdUsuario = IdUsuario FROM inserted
	--INSERTAMOS INTEGRIDADES

	BEGIN TRANSACTION;
	BEGIN TRY

		--Cliente
		SET @VC_ThrowTable = '[Cliente].[integridad].[TipoCobro]';
		INSERT INTO [Cliente].[integridad].[TipoCobro] 
		VALUES(@idTipoCObro, @idClase)
		--Proveedor
		SET @VC_ThrowTable = '[Proveedor].[integridad].[TipoCobro]';
		insert into [Proveedor].[integridad].[TipoCobro] 
		VALUES(@idTipoCObro, @idClase)

	COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
	END CATCH

END
go

