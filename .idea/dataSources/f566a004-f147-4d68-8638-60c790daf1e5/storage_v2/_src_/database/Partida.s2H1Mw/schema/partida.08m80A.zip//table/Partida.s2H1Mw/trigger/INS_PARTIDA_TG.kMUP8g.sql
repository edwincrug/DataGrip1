-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <04/07/2019>
-- Description:	<Alta de Integridades>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	05-08-2019  JLLG	Agregando variables, try catch y comentarios
*/
CREATE TRIGGER [partida].[INS_PARTIDA_TG] 
   ON  partida.Partida
   AFTER INSERT
AS 
BEGIN
	--INSERTAMOS INTEGRIDADES
	DECLARE @IdUsuario			INT,
		@idPartida				INT,
			@idTipoObjeto		INT,
			@idClase			VARCHAR(10),
			@VC_ThrowTable		VARCHAR(300) = '';


	SELECT TOP 1 @idPartida=idPartida,@idTipoObjeto=idTipoObjeto,@idClase=idClase, @IdUsuario = IdUsuario FROM INSERTED
	--BEGIN TRANSACTION
		--BEGIN TRY 
			--Cliente
			SET @VC_ThrowTable = '[Cliente].[integridad].[Partida]';
			INSERT INTO [Cliente].[integridad].[Partida] VALUES(@idPartida,@idTipoObjeto,@idClase)
			--Proveedor
			SET @VC_ThrowTable = '[Proveedor].[integridad].[Partida]';
			INSERT INTO [Proveedor].[integridad].[Partida] VALUES(@idPartida,@idTipoObjeto,@idClase)
			--Solicitud
			SET @VC_ThrowTable = '[Solicitud].[integridad].[Partida]';
			INSERT INTO [Solicitud].[integridad].[Partida] VALUES(@idPartida,@idTipoObjeto,@idClase)

		--	COMMIT TRANSACTION;
		--END TRY
		--BEGIN CATCH
		--	ROLLBACK TRANSACTION;
		--	EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
		--END CATCH
END
go

