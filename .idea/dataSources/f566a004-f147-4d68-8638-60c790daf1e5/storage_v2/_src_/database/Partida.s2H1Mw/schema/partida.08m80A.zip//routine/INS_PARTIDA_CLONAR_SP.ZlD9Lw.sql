  
  
-- =============================================  
-- Author: Edgar Mendoza Gomez   
-- Create date: 21-05-2019  
-- Description: Clonar Partida  
-- ============== Versionamiento ================  
/*  
 Fecha  Autor Descripción   
   
  
 *- Testing...  
 DECLARE @salida varchar(max) ='' ;  
 EXEC [partida].[INS_PARTIDA_CLONAR_SP]   
 '<propiedadesPartidas><ids><idPartida>32096</idPartida></ids></propiedadesPartidas>',  
 '<propiedadesTiposObjetos><ids><idTipoObjeto>100</idTipoObjeto></ids></propiedadesTiposObjetos>',  
 6077,  
 'Automovil',  
 @salida OUTPUT;  
 SELECT @salida AS salida;  
  
   
*/  
-- =============================================  
CREATE  PROCEDURE [partida].[INS_PARTIDA_CLONAR_SP]   
@xmlPartidas   XML,  
@xmlTiposObjetos  XML,  
@idUsuario    INT,  
@idClase    VARCHAR(10),  
@err        NVARCHAR(500) OUTPUT  
AS  
  
BEGIN   
 BEGIN TRANSACTION  

	declare @tbl_xmlPartidas as TABLE(
		[xml] XML
	)
	declare @tbl_xmlTipoObjetos as TABLE(
		[xml] XML
	)

	--INSERTAMOS LOS XML RECIBIDOS
	insert into @tbl_xmlPartidas  (xml) values (@xmlPartidas)
	insert into @tbl_xmlTipoObjetos  (xml) values (@xmlTiposObjetos)
  
  DECLARE @tbl_idPartidas AS TABLE(  
    _row                    INT IDENTITY(1,1),  
    idPartida    INT  
   )  
  
  DECLARE @tbl_idTipoObjetos AS TABLE(  
    _row                    INT IDENTITY(1,1),  
    idTipoObjeto   INT  
   )  
  
 --******************************** SE INSERTA EN TABLA TEMPORAL ID DE PARTIDAS *****************************  
  
  INSERT INTO @tbl_idPartidas  
  SELECT  
	ParamValues.value('idPartida[1]','int')  
  FROM @tbl_xmlPartidas
		CROSS APPLY xml.nodes('/propiedadesPartidas/ids') t(ParamValues)
  --FROM @xmlPartidas.nodes('propiedadesPartidas/ids') AS idPartidasValues(col)  
  
  
 --******************************** SE INSERTA EN TABLA TEMPORAL ID DE TIPO OBJETO *****************************  
  
  
  INSERT INTO @tbl_idTipoObjetos  
  SELECT  
	ParamValues.value('idTipoObjeto[1]','int')  
  FROM @tbl_xmlTipoObjetos
		CROSS APPLY xml.nodes('/propiedadesTiposObjetos/ids') t(ParamValues)
  --FROM @xmlTiposObjetos.nodes('propiedadesTiposObjetos/ids') AS idTiposObjetosValues(col)  
  
  --select * from @tbl_idPartidas  
  --select * from @tbl_idTipoObjetos  
  
  DECLARE @contTipoObjeto INT = 1  
   
 --******************************** SE RECORRE CUANTOS TIPO DE OBJETO SON *****************************  
  
  
  WHILE ((SELECT COUNT (*) FROM @tbl_idTipoObjetos) >= @contTipoObjeto)  
   BEGIN  
    DECLARE @idTipoObjeto INT  
  
    SELECT @idTipoObjeto = idTipoObjeto   
    FROM @tbl_idTipoObjetos   
    WHERE _row = @contTipoObjeto  
  
    --SELECT @idTipoObjeto idTipoObjeto  
  
    DECLARE @contPartida INT = 1  
  
 --******************************** SE RECORRE CUANTAS PARTIDAS SON *****************************  
  
    WHILE ((SELECT COUNT(*) FROM @tbl_idPartidas) >= @contPartida)  
     BEGIN  
      DECLARE @idPartida   INT,  
        @idPartidaNueva  INT,  
        @partida   VARCHAR(MAX)  
  
      SELECT @idPartida = idPartida   
      FROM @tbl_idPartidas  
      WHERE _row =  @contPartida  
  
      --SELECT @idPartida idPartida  
  
   /****************************SE VALIDA QUE NO EXISTA YA ESA PARTIDA ************************************/  
   SELECT   
    @partida = valor   
   from partida.PartidaPropiedadGeneral   
   WHERE  idPropiedadGeneral = 1   
   AND idPartida = @idPartida  
  
      IF NOT EXISTS(SELECT * from partida.PartidaPropiedadGeneral PG  
          INNER JOIN partida.partida P ON P.idPartida = PG.idPartida  
           WHERE PG.idTipoObjeto = @idTipoObjeto  
           AND PG.valor = @partida  
           AND P.activo = 1  
           AND idPropiedadGeneral = 1)  
       BEGIN  
  
  
   --********************************** SE INSERTA PARTIDA ***************************  
  
        INSERT INTO partida.partida  
        SELECT  
        @idTipoObjeto,  
        @idClase,  
        1,  
        'ACT',  
        @idUsuario  
  
        SET @idPartidaNueva = @@IDENTITY  
  
   --**********************************SE INSERTA PROPIEDAD GENERAL***************************  
  
        INSERT INTO partida.PartidaPropiedadGeneral  
        SELECT  
        @idPartidaNueva,  
        @idTipoObjeto,  
        idClase,  
        idPropiedadGeneral,  
        valor,  
        fechaCaducidad,  
        @idUsuario  
        FROM partida.PartidaPropiedadGeneral  
        WHERE idPartida = @idPartida  
        and idClase = @idClase  
  
   --**********************************SE INSERTA PROPIEDAD CLASE***************************  
  
        INSERT INTO partida.PartidaPropiedadClase  
        SELECT  
        @idPartidaNueva,  
        @idTipoObjeto,  
        idClase,  
        idPropiedadClase,  
        valor,  
        fechaCaducidad,  
        @idUsuario  
        FROM partida.PartidaPropiedadClase  
        WHERE idPartida = @idPartida  
        and idClase = @idClase  
  
   --**********************************SE INSERTA PROPIEDAD CONTRATO***************************  
  
        INSERT INTO partida.PartidaPropiedadContrato  
        SELECT  
        @idPartidaNueva,  
        @idTipoObjeto,  
        idClase,  
        idPropiedadContrato,  
        rfcEmpresa,  
        idCliente,  
        numeroContrato,  
        valor,  
        fechaCaducidad,  
        @idUsuario  
        FROM partida.PartidaPropiedadContrato  
        WHERE idPartida = @idPartida  
        and idClase = @idClase  
  
  
  
   --**********************************SE INSERTA TIPO DE SOLICITUD***************************  
          
        INSERT INTO [partida].[TipoSolicitud] (  
         idPartida,  
         idTipoObjeto,  
         idClase,  
         idTipoSolicitud,  
         idUsuario                
        )  
        SELECT   
         @idPartidaNueva,  
         @idTipoObjeto,  
         idClase,  
         idTipoSolicitud,  
         @idUsuario  
        FROM [partida].[TipoSolicitud]  
        where idPartida = @idPartida  
        --INSERT INTO [partida].[TipoSolicitud]  
        --(  
        -- [idPartida],  
        -- [idTipoObjeto],  
        -- [idClase],  
        -- [idTipoSolicitud],  
        -- [idUsuario]  
        --)  
        --VALUES(  
        -- @idPartidaNueva,  
        -- @idTipoObjeto,  
        -- @idClase,  
        -- (SELECT idTipoSolicitud FROM [partida].[TipoSolicitud] WHERE idPartida = @idPartida),  
        -- @idUsuario  
        --)  
  
   --**********************************SE INSERTA COSTOS PARTIDA***************************  
          
        INSERT INTO [Partida].[partida].[PartidaCosto] (  
            idPartida  
           ,[idTipoObjeto]  
           ,[idClase]  
           ,[idTipoCobro]  
           ,[costo]  
           ,[idUsuario]              
        )  
        SELECT   
         @idPartidaNueva  
         ,@idTipoObjeto  
         ,@idClase  
         ,[idTipoCobro]  
         ,[costo]  
         ,@idUsuario  
        FROM [Partida].[partida].[PartidaCosto]  
        where idPartida = @idPartida  
       END  
  
      SET @contPartida = @contPartida + 1  
     END  
  
    SET @contTipoObjeto = @contTipoObjeto + 1  
   END  
 COMMIT  
END

go

