
-- =============================================
-- Author:		<José Luis Lozada Guerrero>
-- Create date: <27/04/2020>
-- Description:	<Actualiza las versiones del tipo de objeto en la tabla partida.tipoobjeto.VersionCosto>
	/*
	EXEC [tipoobjeto].[UPD_TIPOOBJETOVERSIONCOSTO_SP] 1,109,'Automovil',1,'version','100YTYTY',6282,null

	*/
-- =============================================
CREATE PROCEDURE [tipoobjeto].[UPD_TIPOOBJETOVERSIONCOSTO_SP]
@idVersion		INT,
@idTipoObjeto	INT,
@idClase		VARCHAR(10),
@consecutivo	INT,
@campo			VARCHAR(500),
@valor			VARCHAR(500),
@idUsuario		INT,
@err			VARCHAR(500) OUTPUT
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			SET @err=''
			DECLARE @query VARCHAR(300)=''
			DECLARE @setFields VARCHAR(200)=''

			IF @campo='version'			SET @setFields='version='''+@valor+''''
			IF @campo='costo'			SET @setFields='costo='+@valor
			IF @campo='venta'			SET @setFields='venta='+@valor
			IF @campo='equipamiento'	SET @setFields='equipamiento='+@valor
			IF @campo='otro'			SET @setFields='otro='+@valor

			SET @query	=' UPDATE partida.tipoobjeto.VersionCosto '
			SET @query +=' SET ' + @setFields
			SET @query +=' WHERE   idVersion	='+CAST(@idVersion AS VARCHAR)
			SET @query +=' AND     idTipoObjeto ='+CAST(@idTipoObjeto AS VARCHAR)
			SET @query +=' AND     idClase		='''+@idClase+''''
			SET @query +=' AND     consecutivo	='+CAST(@consecutivo AS VARCHAR)
			print @query
			EXEC(@query)
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH

END
go

