-- =============================================
-- Author:		Andres Farias
-- Create date: 30/05/2019
-- Description:	Agregar tipo de cobro a partidas
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [partida].[UPD_PARTIDA_TIPOCOBRO_SP]
	92,
	'<tiposCostos>
		<tipocosto><costo>1000</costo><idTipoCobro>LU</idTipoCobro><idPartida>31910</idPartida></tipocosto>
		<tipocosto><costo>1000</costo><idTipoCobro>MO</idTipoCobro><idPartida>31910</idPartida></tipocosto>
		<tipocosto><costo>1000</costo><idTipoCobro>RE</idTipoCobro><idPartida>31910</idPartida></tipocosto>
	</tiposCostos>',
	'Automovil',
	6036,
	@salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [partida].[UPD_PARTIDA_TIPOCOBRO_SP]
@idTipoObjeto			INT,
@costos                 XML,
@idClase				VARCHAR(10),
@idUsuario              int,
@err				    NVARCHAR(500) OUTPUT
AS
BEGIN

	DECLARE @tbl_costos AS TABLE(
		_row INT IDENTITY(1, 1)
		,idTipoCobro VARCHAR(10)
		,costo FLOAT
		,idPartida	INT
	)

	INSERT INTO @tbl_costos
	SELECT 
	 ParamValues.col.value('idTipoCobro[1]','varchar(10)')
	,ParamValues.col.value('costo[1]','float')
	,ParamValues.col.value('idPartida[1]','int')
	FROM @costos.nodes('tiposCostos/tipocosto') AS ParamValues(col)

	-- VALIDAR SI LA PARTIDA YA TIENE ASIGNADO TipoCobro
	
	DECLARE @cont INT= 1;
	WHILE(@cont <= (SELECT COUNT(*) FROM @tbl_costos))
	BEGIN
		IF((SELECT COUNT(*) FROM partida.PartidaCosto WHERE idPartida = (SELECT idPartida FROM @tbl_costos WHERE _row = @cont) AND idClase = @idClase) > 0)
		BEGIN
			
			UPDATE partida.PartidaCosto
			SET costo = (SELECT costo FROM @tbl_costos WHERE _row = @cont),
			idUsuario = @idUsuario
			WHERE idPartida = (SELECT idPartida FROM @tbl_costos WHERE _row = @cont)
			AND idClase = @idClase
			AND idTipoCobro = (SELECT idTipoCobro FROM @tbl_costos WHERE _row = @cont)
		END	
		ELSE 
		BEGIN
			EXECUTE [partida].[INS_PARTIDACOSTO_SP] @costos, @idTipoObjeto, @idClase, @idUsuario, @err out
		END
		SET @cont = @cont + 1
	END	
END
go

