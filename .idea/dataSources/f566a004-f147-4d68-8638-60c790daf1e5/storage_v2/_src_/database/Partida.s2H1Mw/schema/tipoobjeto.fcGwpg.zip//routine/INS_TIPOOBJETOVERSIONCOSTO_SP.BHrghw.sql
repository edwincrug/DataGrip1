
-- =============================================
-- Author:		<José Luis Lozada Guerrero>
-- Create date: <27/04/2020>
-- Description:	<Inserta las versiones del tipo de objeto en la tabla partida.tipoobjeto.VersionCosto>
-- =============================================
CREATE PROCEDURE [tipoobjeto].[INS_TIPOOBJETOVERSIONCOSTO_SP]
@idVersion		INT,
@idTipoObjeto	INT,
@idClase		VARCHAR(10),
@anio			INT,
@mes			INT,
@costo			FLOAT,
@venta			FLOAT,
@equipamiento	FLOAT,
@otro			FLOAT,
@idUsuario		INT,
@err			VARCHAR(MAX) OUTPUT
AS
BEGIN
	
	BEGIN TRY
		BEGIN TRANSACTION
			SET @err=''
			INSERT INTO  partida.tipoobjeto.VersionCosto(idVersion,idTipoObjeto,idClase,anio,mes,costo,venta,equipamiento,otro,activo,idUsuario)
			VALUES(@idVersion,@idTipoObjeto,@idClase,@anio,@mes,@costo,@venta,@equipamiento,@otro,1,@idUsuario)
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH

END

go

