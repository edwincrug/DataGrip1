
-- =============================================
-- Author:		<José Luis Lozada Guerrero>
-- Create date: <27/04/2020>
-- Description:	<Inserta las versiones del tipo de objeto en la tabla partida.tipoobjeto.Version>
-- =============================================
CREATE PROCEDURE [tipoobjeto].[INS_TIPOOBJETOVERSION_SP]
@idTipoObjeto	INT,
@idClase		VARCHAR(10),
@version		VARCHAR(500),
@idUsuario		INT,
@err			VARCHAR(MAX) OUTPUT
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			SET @err=''
			INSERT INTO  partida.tipoobjeto.Version(idTipoObjeto,idClase,version,activo,idUsuario)
			VALUES(@idTipoObjeto,@idClase,@version,1,@idUsuario)
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH

END
go

