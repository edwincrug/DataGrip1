-- =============================================
-- Author: Edgar Mendoza Gomez	
-- Create date: 03-04-2019
-- Description: Elimina Partida
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [partida].[DEL_PARTIDA_SP] 
	'<Ids>
		<idPartida>11</idPartida>
	</Ids>'
   ,
	@salida OUTPUT;
	SELECT @salida AS salida;

	
*/
-- =============================================
CREATE  PROCEDURE [partida].[DEL_PARTIDA_SP] 
@data					XML,
@idUsuario				INT,
@idClase				VARCHAR(10),
@err				    NVARCHAR(500) OUTPUT
AS
BEGIN
	
	DECLARE @idPartida	AS INT
    DECLARE @tbl_propiedades AS TABLE(
        idPartida			INT
    )


    INSERT INTO @tbl_propiedades
    SELECT
        I.N.value('.','int')
        FROM @data.nodes('/Ids/idPartida') AS I(N)



	UPDATE partida.Partida 
	SET activo = 0 
	WHERE idPartida in (SELECT idPartida 
							FROM @tbl_propiedades)
	AND idClase = @idClase

END
go

