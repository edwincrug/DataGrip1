
-- =============================================  
/*
 EXEC [partida].[SEL_PARTIDA_POR_SOLICITUD_MULTIPLE_AGRUPDA_SP] 1122, 'Instala', 'Automovil','AAN910409135',218,'0001', 1, null  
*/
-- select * from solicitud.solicitud.solicitud where idSolicitud=1064
-- =============================================  
CREATE PROCEDURE [partida].[SEL_PARTIDA_POR_SOLICITUD_MULTIPLE_AGRUPDA_SP]  
	@idSolicitud		INT,  
	@idTipoSolicitud	VARCHAR(10),  
	@idClase			VARCHAR(10),  
	@rfcEmpresa			VARCHAR(13),
	@idCliente			INT,  
	@numeroContrato		VARCHAR(50),  
	@idUsuario			INT,  
	@err				VARCHAR(500) OUTPUT  
AS  
BEGIN  
	DECLARE @v_sq				NVARCHAR(max)='',
			@TablaPartida		VARCHAR(100)='',
			@camposPivotPartida VARCHAR(1000),
			@camposPivotKey		VARCHAR(1000)


	DECLARE @tPartida TABLE(idd INT identity, idPartida INT,idTipoObjeto INT)
	DECLARE @tCamposExtras TABLE(campo VARCHAR(50),orden int)

	IF OBJECT_ID('tempdb..#tablaDatosPartida')IS NOT NULL DROP TABLE #tablaDatosPartida
	CREATE TABLE #tablaDatosPartida([idPartida] [int] NULL,[idTipoObjeto] [int] NULL, [agrupador] [varchar](250) NULL, [valor] [varchar](500) NULL)
	SET @TablaPartida ='TxPartida_'+CAST(CAST(RAND(CHECKSUM(NEWID()))*10000000 AS INT) AS VARCHAR)

	INSERT INTO @tCamposExtras VALUES('Mano de Obra',100)
	INSERT INTO @tCamposExtras VALUES('Refacciones',101)
	INSERT INTO @tCamposExtras VALUES('Lubricantes',102)

	/*PROPIEDADES DINAMICAS [PARTIDAS]*/
	BEGIN
		INSERT INTO @tPartida (idPartida,idTipoObjeto) 
		SELECT	DISTINCT idPartida,idtipoObjeto	FROM solicitud.solicitud.solicitudPartida WHERE idSolicitud	=@idSolicitud AND idClase = @idClase AND idCliente = @idCliente	AND numeroContrato=@numeroContrato  
	
		SET		@camposPivotPartida		= ISNULL(STUFF((SELECT ',' + QUOTENAME(px.campo) FROM(	SELECT  pa.campo,pa.orden
																								FROM	Common.reporte.partida pa  
																								WHERE	idClase = @idClase
																								UNION	ALL 
																								SELECT	campo,orden 
																								FROM	@tCamposExtras)px
														ORDER BY px.orden ASC  FOR XML PATH('')),1,1,''),'sinCoinicidencia')
		SET		@camposPivotKey			= 'idPartida,idTipoObjeto'
		SET		@camposPivotPartida 	= REPLACE(@camposPivotPartida,' ','_')
	
		INSERT INTO #tablaDatosPartida(idPartida,idTipoObjeto,agrupador,valor) 
		select	s.idPartida,s.idTipoObjeto,tc.campo,
				CASE 
					WHEN tc.tipoDato in ('Image', 'Pdf', 'Documento' )  THEN (	SELECT	valor 
																				FROM	Common.configuracion.configuracion 
																				WHERE	nombre = 'fileServer') + (	SELECT	PATH 
																													FROM	FileServer.documento.Documento 
																													WHERE	idDocumento = [partida].[partida].[getPropiedadPartida](s.idPartida, tc.campo, tc.tipoPropiedad)) 
					ELSE [partida].[partida].[getPropiedadPartida](s.idPartida, tc.campo, tc.tipoPropiedad)	
				END	valor
		FROM	@tPartida s,(SELECT campo,tipoPropiedad,orden,tipoDato FROM Common.reporte.partida (NOLOCK) WHERE idClase=@idClase) tc ORDER BY tc.orden ASC 

		INSERT INTO #tablaDatosPartida
		SELECT	par.idPartida,par.idTipoObjeto,tc.nombre ,ISNULL(parcos.costo,0) valor  
		FROM	partida.tipoobjeto.TipoObjeto tob   
		INNER	JOIN @tPartida par on tob.idTipoObjeto = par.idTipoObjeto  
		INNER	JOIN partida.partida.PartidaCosto parcos on parcos.idPartida = par.idPartida   
		INNER	JOIN partida.TipoCobro tc on parcos.idTipoCobro = tc.idTipoCobro  

		SET @v_sq='SELECT r.* INTO '+ @TablaPartida +' from (select '+@camposPivotKey+',agrupador,valor from #tablaDatosPartida) AS tx PIVOT (max(valor) for agrupador in ('+@camposPivotPartida+')) as r '
		EXEC SP_EXECUTESQL @v_sq
	END
	--,SUM(P.Mano_de_Obra),SUM(P.Refacciones),SUM(P.Lubricantes),
	SET @v_sq=  ' SELECT MAX(P.Descripción) Descripción,MAX(P.Partida) Partida,P.noParte,MAX(P.Instructivo) Instructivo,MAX(P.Foto) Foto,MAX(P.noEventos) noEventos,MAX(P.EditaCosto) EditaCosto,MAX(P.EditaVenta) EditaVenta,MAX(P.Inventariable) Inventariable,MAX(P.Clasificación) Clasificación,MAX(P.Tipo_de_partida) Tipo_de_partida,MAX(P.Especialidad) Especialidad,MAX(P.Marca) Marca,SUM(P.cant) cant,SUM(P.Costo) Costo,SUM(P.Venta) Venta FROM( '
	SET @v_sq+=  'SELECT tx.*, '
	SET @v_sq+= ' ISNULL((SELECT SUM(costo) FROM partida.PartidaCosto cos WHERE cos.idPartida = tx.idPartida),0)* tx.cant Costo,'
	SET @v_sq+= ' ISNULL((SELECT SUM(Venta) FROM cliente.contrato.PartidaPrecio pre WHERE pre.idPartida = tx.idPartida AND pre.idCliente = ' + CAST(@idCliente AS VARCHAR) + ' AND numeroContrato = ''' + @numeroContrato + ''')* tx.cant,0) Venta'
	SET @v_sq+= ' FROM  ('
	SET @v_sq+= '			SELECT	pa.*, '
	SET @v_sq+= '					ISNULL((	SELECT SUM(cantidad) FROM solicitud.solicitud.solicitudPartida spa WHERE spa.idTipoObjeto=pa.idTipoObjeto AND spa.idPartida=pa.idPartida '
	SET @v_sq+= '								AND spa.idSolicitud		= '  +CAST(@idSolicitud AS VARCHAR)
	SET @v_sq+= '								AND spa.idTipoSolicitud = '''+@idTipoSolicitud+''''
	SET @v_sq+= '								AND spa.idClase			= '''+@idClase+''''
	SET @v_sq+= '								AND spa.rfcEmpresa		= '''+@rfcEmpresa+''''
	SET @v_sq+= '								AND spa.idCliente		= '  +CAST(@idCliente AS VARCHAR)
	SET @v_sq+= '								AND spa.numeroContrato	= '''+@numeroContrato+''' GROUP BY idTipoObjeto,idPartida),0)cant'
	SET @v_sq+= '			FROM ' + @TablaPartida +' pa'
	SET @v_sq+= '		)tx'
	SET @v_sq+= '		)p GROUP BY P.NoParte'
	
	print @v_sq
	EXECUTE (@v_sq)

	SET @v_sq   =' DROP TABLE '+@TablaPartida 
	EXECUTE (@v_sq)

END
go

