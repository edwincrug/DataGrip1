

-- =============================================
-- Author: Adolfo Martinez
-- Create date: 27-05-2020
-- Description: Consulta  devuelve columnas solicitudes 
-- ============== Versionamiento ================
-- EXEC [partida].[SEL_SOLICITUD_PARTIDAS_MULTIPLE_COLUMNS_SP] 'Automovil',123,''
-- =============================================
CREATE PROCEDURE [partida].[SEL_SOLICITUD_PARTIDAS_MULTIPLE_COLUMNS_SP]
	@idClase			VARCHAR(10),
	@idUsuario			INT,
	@err				VARCHAR(500)OUTPUT
AS


BEGIN

	DECLARE @columnas TABLE(caption VARCHAR(100),datafield VARCHAR(100),datatype VARCHAR(100),orden INT, bloque INT)

	DECLARE @camposPivot VARCHAR(MAX),
			@sq			 VARCHAR(MAX)

	insert into @columnas SELECT caption,campo,tipoDato,orden,1 FROM Common.reporte.partida WHERE idClase=@idClase ORDER BY orden ASC
	insert into @columnas values('Cantidad','cant','String',14,2)
	insert into @columnas values('Costo','Costo','Number',15,2)
	insert into @columnas values('Venta','Venta','Number',16,2)
	insert into @columnas values('Total','TotalCosto','Number',17,2)
	insert into @columnas values('Total','TotalVenta','Number',18,2)

	SELECT * FROM @columnas ORDER BY bloque,orden ASC

END


go

