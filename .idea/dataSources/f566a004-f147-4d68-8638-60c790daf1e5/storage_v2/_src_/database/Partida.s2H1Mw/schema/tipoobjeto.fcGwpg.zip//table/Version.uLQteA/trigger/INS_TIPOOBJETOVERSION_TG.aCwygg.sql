-- =============================================
-- Author:		<Jose Luis Lozada>
-- Create date: <04/05/2020>
-- Description:	<Alta de Integridades>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	--Test

*/

CREATE TRIGGER [tipoobjeto].[INS_TIPOOBJETOVERSION_TG] 
   ON  [tipoobjeto].[version]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;

	
	DECLARE @UID varchar(50),
			@UserName varchar(50), 
			@Email varchar(max),
			@idVersion			INT,
			@idTipoObjeto		INT,
			@idClase			VARCHAR(10),
			@IdUsuario			INT,
			@VC_ThrowTable		VARCHAR(300) = '',
			@consecutivo		INT
	

	SELECT	@idVersion		= idVersion,
			@idTipoObjeto	= idTipoObjeto,
			@idClase		= idClase,
			@IdUsuario		= idUsuario 
	FROM inserted;

	BEGIN TRANSACTION;
	BEGIN TRY

		SET @VC_ThrowTable = '[Objeto].[integridad].[Version]';
		INSERT INTO [Objeto].[integridad].[Version](idVersion,idTipoObjeto,idClase) 
		VALUES (@idVersion,@idTipoObjeto,@idClase);

	COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
	END CATCH
	
END
go

