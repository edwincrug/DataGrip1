-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener el costo de las partidas con IVA>
-- =============================================
-- SELECT 
    -- [idPartida]
    -- ,[idTipoObjeto]
    -- ,[idClase]
    -- ,[costo]
    -- ,[IVA]
    -- ,[costoTotal]
-- FROM [Partida].[partida].[SEL_PARTIDAS_COSTO_VW]
-- =============================================
CREATE VIEW [partida].[SEL_PARTIDAS_COSTO_VW]
AS

SELECT 
    [idPartida]
    ,[idTipoObjeto]
    ,[idClase]
    ,COALESCE(SUM([costo]), 0) costo
    ,COALESCE(SUM([costo]) * .16, 0) IVA
    ,COALESCE(SUM([costo]) + (SUM([costo]) * .16), 0) costoTotal
FROM [Partida].[partida].[PartidaCosto]
GROUP BY [idPartida]
    ,[idTipoObjeto]
    ,[idClase]
go

