-- =============================================
-- Author:		<Jose Luis Lozada>
-- Create date: <04/05/2020>
-- Description:	<Alta de Integridades>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	--Test

*/

CREATE TRIGGER [tipoobjeto].[INS_TIPOOBJETOVERSIONCOSTO_TG] 
   ON  [tipoobjeto].[versionCosto]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;

	
	DECLARE @UID varchar(50),
			@UserName varchar(50), 
			@Email varchar(max),
			@idVersion			INT,
			@idTipoObjeto		INT,
			@idClase			VARCHAR(10),
			@IdUsuario			INT,
			@VC_ThrowTable		VARCHAR(300) = '',
			@consecutivo		INT
	

	SELECT	@idVersion		= idVersion,
			@idTipoObjeto	= idTipoObjeto,
			@idClase		= idClase,
			@consecutivo    = consecutivo,
			@IdUsuario		= idUsuario 
	FROM inserted;

	BEGIN TRANSACTION;
	BEGIN TRY

		SET @VC_ThrowTable = '[Objeto].[integridad].[VersionCosto]';
		INSERT INTO [Objeto].[integridad].[VersionCosto](idVersion,idTipoObjeto,idClase,consecutivo) 
		VALUES (@idVersion,@idTipoObjeto,@idClase,@consecutivo);

	COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
	END CATCH
	
END
go

