-- =============================================  
-- Author: Edgar Mendoza Gomez   
-- Create date: 09-04-2019  
-- Description: Inserta Partidas Masiva  
-- ============== Versionamiento ================  
/*  
 Fecha   Autor     Descripción   
 21/05/2019  Alan Rosales Chávez  Se modifica sp para recibir parametros de Reemplazar, Actualizar y Concatenar  
  
 *- Testing...  
 DECLARE @salida varchar(max) ='' ;  
 EXEC [partida].[INS_PARTIDA_MASIVA_SP]  
 498,  
 'Automovil',  
 6036,  
 '',  
 0,  
 '',  
 '<propiedades><propiedad><index>0</index><valor>0</valor><propiedadDesc>index</propiedadDesc><fechaCaducidad/><id>0</id></propiedad><propiedad><index>0</index><valor>VOLGOL18.00811875</valor><propiedadDesc>Partida</propiedadDesc><fechaCaducidad/><id>0</i
d></propiedad><propiedad><index>0</index><valor>2316</valor><propiedadDesc>noParte</propiedadDesc><fechaCaducidad/><id>0</id></propiedad><propiedad><index>0</index><valor>1</valor><propiedadDesc>noEventos</propiedadDesc><fechaCaducidad/><id>0</id></propie
dad><propiedad><index>0</index><valor>Mantenimiento</valor><propiedadDesc>Clasificación</propiedadDesc><fechaCaducidad/><id>0</id></propiedad><propiedad><index>0</index><valor>Mano de obra</valor><propiedadDesc>Tipo de partida</propiedadDesc><fechaCaducid
ad/><id>0</id></propiedad><propiedad><index>0</index><valor>Frenos</valor><propiedadDesc>Especialidad</propiedadDesc><fechaCaducidad/><id>0</id></propiedad><propiedad><index>0</index><valor/><propiedadDesc>Marca</propiedadDesc><fechaCaducidad/><id>0</id><
/propiedad><propiedad><index>0</index><valor>REVISAR BALATAS X RUEDA</valor><propiedadDesc>Descripción</propiedadDesc><fechaCaducidad/><id>0</id></propiedad><propiedad><index>0</index><valor>Servicio</valor><propiedadDesc>idTipoSolicitud</propiedadDesc><f
echaCaducidad/><id>0</id></propiedad></propiedades>',  
 'Concatenar',  
 @salida OUTPUT;  
 SELECT @salida AS salida;  
  
   
*/  
-- =============================================  
CREATE  PROCEDURE [partida].[INS_PARTIDA_MASIVA_SP]   
@idTipoObjeto   INT,  
@idClase    varchar(10),  
@idUsuario    int,  
@rfc     varchar(13),  
@idCliente    int,  
@numeroContrato   varchar(50),  
---------parametros fijos para sp de carga masiva-------------  
@idTipoAccion   varchar(20),  
@propiedades   XML,  
@err        NVARCHAR(500) OUTPUT  
AS  
  
BEGIN  
  
   DECLARE @idPartida AS INT   

   declare @tbl_xml as TABLE(
	[xml] XML
   )

   DECLARE @tbl_propiedades AS TABLE(  
    _row                    INT IDENTITY(1,1),  
    [index]     INT,  
    propiedadDesc   NVARCHAR(250),  
    valor                   NVARCHAR(500),  
    fechaCaducidad   DATETIME,  
    id      INT  
   )  

	insert into @tbl_xml  (xml) values (@propiedades)
	INSERT INTO @tbl_propiedades(
			[index],  
			propiedadDesc,  
			valor,  
			fechaCaducidad,  
			id)  
	SELECT 
		ParamValues.value('index[1]','int'),  
		ParamValues.value('propiedadDesc[1]','nvarchar(250)'),  
		ParamValues.value('valor[1]','nvarchar(500)'),  
		ParamValues.value('fechaCaducidad[1]','datetime'),
		CASE WHEN @idTipoAccion = 'Actualizar' THEN ParamValues.value('id[1]','int')  
		ELSE 0 END  
	FROM @tbl_xml
		CROSS APPLY xml.nodes('/propiedades/propiedad') t(ParamValues)
	where
		ParamValues.value('propiedadDesc[1]','nvarchar(250)') != 'index'  
  
   DECLARE @cont  INT = 1,  
     @index  INT = 0  
  
   --select * from @tbl_propiedades  
  
   --SI EL TIPO DE ACCION ES REEMPLAZAR, BORRAMOS LAS PARTIDAS ACTUALES PARA ESE TIPO DE OBJETO  
   --if (@idTipoAccion = 'Reemplazar')  
   --begin  
   -- --BORRAMOS PROPIEDADES  
   -- delete pro  
   -- from partida.PartidaPropiedadGeneral pro  
   -- inner join partida.partida p on pro.idTipoObjeto = p.idTipoObjeto  
   -- where p.idTipoObjeto = @idTipoObjeto AND pro.idClase = @idClase  
   -- delete pro  
   -- from partida.PartidaPropiedadClase pro  
   -- inner join partida.partida p on pro.idTipoObjeto = p.idTipoObjeto  
   -- where p.idTipoObjeto = @idTipoObjeto AND pro.idClase = @idClase  
   -- delete pro  
   -- from partida.PartidaPropiedadContrato pro  
   -- inner join partida.partida p on pro.idTipoObjeto = p.idTipoObjeto  
   -- where p.idTipoObjeto = @idTipoObjeto AND pro.idClase = @idClase  
   -- --BORRAMOS PARTIDAS  
   -- delete from partida.Partida where idTipoObjeto = @idTipoObjeto AND idClase = @idClase  
   -- -- Asignamos el comportamiento de 'Concatenar para que se guarden las nuevas partidas'  
   -- --BORRAMOS TIPO DE SOLICITUD  
   -- delete from partida.TipoSolicitud WHERE idTipoObjeto = @idTipoObjeto AND idClase = @idClase  
   -- set @idTipoAccion = 'Concatenar'  
   --end  
  
  
   --EN CASO DE QUE SEA CONCATENAR SE INSERTAN SIEMPRE REGISTROS NUEVOS   
   IF(@idTipoAccion = 'Concatenar')  
   BEGIN  
    INSERT INTO partida.Partida   
    SELECT TOP 1  
     @idTipoObjeto,  
     @idClase,  
     1,  
     'ACT',  
     @idUsuario  
    FROM @tbl_propiedades  
  
    SET @idPartida = @@IDENTITY  
    print @idPartida  
   END  
  
     WHILE((SELECT COUNT(*) FROM @tbl_propiedades)>= @cont)  
  
   BEGIN  
    DECLARE   
    @propiedad  NVARCHAR(250),  
    @idTipoValor NVARCHAR(250),  
    @idPropiedad INT,  
    @valor   NVARCHAR(500),  
    @id    INT  
  
    
  
  
    IF(@index != (Select [index] from @tbl_propiedades WHERE _row = @cont))  
     BEGIN  
      SET @index = @index + 1  
      IF(@idTipoAccion = 'Concatenar')  
      BEGIN  
      INSERT INTO partida.Partida   
      SELECT TOP 1  
       @idTipoObjeto,  
       @idClase,  
       1,  
       'ACT',  
       @idUsuario  
      FROM @tbl_propiedades  
  
      SET @idPartida = @@IDENTITY  
      END      
     END    
    
    SELECT   
    @id = id,  
    @propiedad =   
       CASE  
       WHEN propiedadDesc IN (SELECT valor FROM partida.propiedadGeneral) THEN 'general'  
       WHEN propiedadDesc IN (SELECT valor FROM partida.propiedadClase) THEN 'clase'  
       WHEN propiedadDesc = 'idTipoSolicitud' THEN 'idTipoSolicitud'  
       ELSE 'contrato' END,  
    @idTipoValor = (SELECT TOP 1 * FROM (  
             SELECT idTipoValor   
             FROM [partida].[PropiedadGeneral]  
             WHERE agrupador = prop.propiedadDesc  
             UNION ALL  
             SELECT idTipoValor   
             FROM [partida].[PropiedadClase]  
             WHERE agrupador = prop.propiedadDesc  
             UNION ALL  
             SELECT idTipoValor   
             FROM [partida].[PropiedadContrato]  
             WHERE agrupador = 'Clasificación'  
             ) as tbl1  
        ),  
    @valor = ( SELECT  idPropiedadGeneral from [partida].[PropiedadGeneral] WHERE valor = prop.valor  
       UNION ALL  
       SELECT idPropiedadClase  from [partida].[PropiedadClase] WHERE valor = prop.valor  
       UNION ALL  
       SELECT idPropiedadContrato from [partida].[PropiedadContrato] WHERE valor = prop.valor  
      ),  
    @idPropiedad = (SELECT top 1  idPropiedadGeneral from [partida].[PropiedadGeneral] WHERE valor = prop.propiedadDesc  
        UNION ALL  
        SELECT top 1 idPropiedadClase  from [partida].[PropiedadClase] WHERE valor = prop.propiedadDesc  
        UNION ALL  
        SELECT top 1 idPropiedadContrato from [partida].[PropiedadContrato] WHERE valor = prop.propiedadDesc  
        )  
    FROM @tbl_propiedades prop  
    WHERE _row = @cont   
  
    --select @propiedad, @idTipoValor, @idPropiedad, @valor, @id  
  
    IF(@propiedad = 'general')  
     BEGIN  
      if (@idTipoAccion = 'Concatenar')  
      begin  
       INSERT INTO partida.PartidaPropiedadGeneral   
       SELECT  
        @idPartida idPartida,  
        @idTipoObjeto idObjeto,  
        @idClase,  
        CASE  
         WHEN (@idTipoValor != 'Unico') THEN @valor  
         ELSE @idPropiedad  
         END idPropiedadGeneral,  
        CASE   
         WHEN (@idTipoValor != 'Unico') THEN ''  
         ELSE valor  
         END valor,  
        fechaCaducidad,  
        @idUsuario  
       FROM @tbl_propiedades   
       WHERE _row = @cont  
      END  
      if (@idTipoAccion = 'Actualizar')  
      begin  
       if (@idTipoValor = 'Unico')  
       begin  
        update pro   
         set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont)  
        from partida.PartidaPropiedadGeneral pro  
        where  
         pro.idPartida = @id  
         and pro.idTipoObjeto = @idTipoObjeto  
         and idPropiedadGeneral = @idPropiedad  
         and idClase = @idClase  
         
       end  
       else if (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
       BEGIN  
        --EN CASO DE QUE SEA CATALOGO O AGRUPADOR  
        --buscamos el id de la propiedad con base al nombre del agrupador  
        select   
         @idPropiedad = [partida].[SEL_PARTIDA_BUSCAIDPORAGRUPADOR_FN](@idTipoObjeto,@id,@idClase,propiedadDesc,@propiedad)  
        from @tbl_propiedades where _row = @cont  
  
        update pro   
         set  
          pro.idPropiedadGeneral = @valor,  
          pro.valor = ''  
        from partida.PartidaPropiedadGeneral pro  
        where  
         pro.idPartida = @id  
         and pro.idTipoObjeto = @idTipoObjeto  
         and idPropiedadGeneral = @idPropiedad  
         and idClase = @idClase  
  
       END  
      end  
     END  
    ELSE IF(@propiedad = 'clase')  
     BEGIN  
      if (@idTipoAccion = 'Concatenar')  
      begin  
       INSERT INTO partida.PartidaPropiedadClase  
       SELECT  
        @idPartida idPartida,  
        @idTipoObjeto idTipoObjeto,  
        @idClase,  
        CASE  
         WHEN (@idTipoValor != 'Unico') THEN @valor  
         ELSE @idPropiedad  
         END idPropiedadClase,  
        CASE   
         WHEN (@idTipoValor != 'Unico') THEN ''  
         ELSE valor  
         END valor,  
        fechaCaducidad,  
        @idUsuario  
       FROM @tbl_propiedades prop  
       WHERE _row = @cont  
      end  
      if (@idTipoAccion = 'Actualizar')  
      begin  
       if (@idTipoValor = 'Unico')  
       begin  
        update pro   
         set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont)  
        from partida.PartidaPropiedadClase pro  
        where  
         pro.idPartida = @id  
         and pro.idTipoObjeto = @idTipoObjeto  
         and idPropiedadClase = @idPropiedad  
         and pro.idClase = @idClase  
         
       end  
       else if (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
       BEGIN  
        --EN CASO DE QUE SEA CATALOGO O AGRUPADOR  
        --buscamos el id de la propiedad con base al nombre del agrupador  
        
        select   
         @idPropiedad = [partida].[SEL_PARTIDA_BUSCAIDPORAGRUPADOR_FN](@idTipoObjeto,@id,@idClase,propiedadDesc,@propiedad)  
        from @tbl_propiedades where _row = @cont  
  
        update pro   
         set  
          pro.idPropiedadClase = @valor,  
          pro.valor = ''  
        from partida.PartidaPropiedadClase pro  
        where  
         pro.idPartida = @id  
         and pro.idTipoObjeto = @idTipoObjeto  
         and idPropiedadClase = @idPropiedad  
         and pro.idClase = @idClase  
       end  
      end  
  
     END  
  
    ELSE IF(@propiedad = 'contrato')  
     BEGIN  
      if (@idTipoAccion = 'Concatenar')  
      begin  
       INSERT INTO partida.PartidaPropiedadContrato  
       SELECT  
        @idPartida idPartida,  
        @idTipoObjeto idTipoObjeto,  
        @idClase,  
        CASE  
         WHEN (@idTipoValor != 'Unico') THEN @valor  
         ELSE @idPropiedad  
         END idPropiedadContrato,  
        @rfc,  
        @idCliente,  
        @numeroContrato,  
        CASE   
         WHEN (@idTipoValor != 'Unico') THEN ''  
         ELSE valor  
         END valor,  
        fechaCaducidad,  
        @idUsuario  
       FROM @tbl_propiedades  
       WHERE _row = @cont  
      end  
      if (@idTipoAccion = 'Actualizar')  
      begin  
       if (@idTipoValor = 'Unico')  
       begin  
        update pro   
         set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont)  
        from partida.PartidaPropiedadContrato pro  
        where  
         pro.idPartida = @id  
         and pro.idTipoObjeto = @idTipoObjeto  
         and idPropiedadContrato = @idPropiedad  
         and pro.idClase = @idClase  
         
       end  
       else if (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
       BEGIN  
        --EN CASO DE QUE SEA CATALOGO O AGRUPADOR  
        --buscamos el id de la propiedad con base al nombre del agrupador  
        select   
         @idPropiedad = [partida].[SEL_PARTIDA_BUSCAIDPORAGRUPADOR_FN](@idTipoObjeto,@id,'Automovil',propiedadDesc,@propiedad)  
        from @tbl_propiedades where _row = @cont  
  
        update pro   
         set  
          pro.idPropiedadContrato = @valor,  
          pro.valor = ''  
        from partida.PartidaPropiedadContrato pro  
        where  
         pro.idPartida = @id  
         and pro.idTipoObjeto = @idTipoObjeto  
         and idPropiedadContrato = @idPropiedad  
         and pro.idClase = @idClase  
  
       end  
      end  
  
     END  
  
    ELSE IF(@propiedad = 'idTipoSolicitud')  
     BEGIN  
      DECLARE @idtipoSolicitudValor TABLE (idTipoSolicitud VARCHAR(100))  
  
     
      INSERT INTO @idtipoSolicitudValor  
      SELECT * FROM migracion.dbo.SEL_SPLIT_FN((SELECT valor FROM @tbl_propiedades WHERE _row = @cont), ',')  
  
      IF (@idTipoAccion = 'Concatenar')  
       BEGIN  
        INSERT INTO partida.TipoSolicitud  
        SELECT  
         @idPartida idPartida,  
         @idTipoObjeto idTipoObjeto,  
         @idClase,  
         idTipoSolicitud,  
         @idUsuario  
        FROM @idtipoSolicitudValor  
       END  
      IF (@idTipoAccion = 'Actualizar')  
       BEGIN  
        DELETE FROM partida.TipoSolicitud WHERE idPartida = @id AND idClase = @idClase  
        INSERT INTO partida.TipoSolicitud  
        SELECT  
         @id idPartida,  
         @idTipoObjeto idTipoObjeto,  
         @idClase,  
         idTipoSolicitud,  
         @idUsuario  
        FROM @idtipoSolicitudValor  
       END  
      DELETE FROM @idtipoSolicitudValor  
     END  
  
      SET @cont = @cont + 1  
   END  
 END

go

