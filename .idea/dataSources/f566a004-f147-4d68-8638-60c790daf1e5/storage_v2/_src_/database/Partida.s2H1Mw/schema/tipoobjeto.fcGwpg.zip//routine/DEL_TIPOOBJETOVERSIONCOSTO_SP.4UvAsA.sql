-- use partida
-- =============================================
-- Author:		<José Luis Lozada Guerrero>
-- Create date: <27/04/2020>
-- Description:	<borra uno o varios registros de la tabla partida.tipoobjeto.VersionCosto>
-- =============================================
CREATE PROCEDURE [tipoobjeto].[DEL_TIPOOBJETOVERSIONCOSTO_SP]
@data			XML,
@idUsuario		INT,
@err			VARCHAR(500) OUTPUT
AS
BEGIN
	DECLARE @tbl_versiones AS TABLE(idVersion INT,idTipoObjeto	INT,idClase VARCHAR(10),consecutivo INT)
	BEGIN TRY
		BEGIN TRANSACTION

		INSERT INTO @tbl_versiones(idVersion,idTipoObjeto,idClase,consecutivo)
		SELECT  ParamValues.col.value('idVersion[1]','INT'), 
				ParamValues.col.value('idTipoObjeto[1]','INT'), 
				ParamValues.col.value('idClase[1]','Varchar(10)'),
				ParamValues.col.value('consecutivo[1]','INT')
        FROM @data.nodes('/versiones/version') AS ParamValues(col)   

		SET @err=''

		UPDATE tipoobjeto.Versioncosto SET activo=0
		WHERE	CAST(idVersion AS VARCHAR) + CAST(idTipoObjeto AS VARCHAR)+idClase+CAST(consecutivo AS VARCHAR) 
		IN (SELECT CAST(idVersion AS VARCHAR) + CAST(idTipoObjeto AS VARCHAR)+idClase+CAST(consecutivo AS VARCHAR) FROM @tbl_versiones)

		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH

END
go

