-- =============================================
-- Author: Edgar Mendoza Gomez	
-- Create date: 22-04-2019
-- Description: Inserta Partidas Propia Masiva
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [partida].[INS_PARTIDACONTRATO_MASIVA_SP] 
	71,
	'123PEMEX',
	78,
    '<propiedades><propiedad><index>0</index><valor>0</valor><propiedadDesc>index</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>0</id></propiedad><propiedad><index>0</index><valor>CAJTO</valor><propiedadDesc>Partida</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>0</index><valor>55556</valor><propiedadDesc>noParte</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>0</index><valor>ARO MZ 3 10-13 FQQQQQQ</valor><propiedadDesc>Descripción</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>0</index><valor>930</valor><propiedadDesc>Costo</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>0</index><valor>Refacción</valor><propiedadDesc>Tipo de Partida</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>0</index><valor>Eléctrico</valor><propiedadDesc>Especialidad</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>0</index><valor>Mantenimiento</valor><propiedadDesc>Clasificación</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>0</index><valor>80</valor><propiedadDesc>Marca</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>0</index><valor>Grupo 1</valor><propiedadDesc>Grupo</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>56</id></propiedad><propiedad><index>1</index><valor>1</valor><propiedadDesc>index</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>0</id></propiedad><propiedad><index>1</index><valor>CAJTOD197888888</valor><propiedadDesc>Partida</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad><propiedad><index>1</index><valor>555557</valor><propiedadDesc>noParte</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad><propiedad><index>1</index><valor>ARO MZ 3 10 22222</valor><propiedadDesc>Descripción</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad><propiedad><index>1</index><valor>930</valor><propiedadDesc>Costo</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad><propiedad><index>1</index><valor>Mano de Obra</valor><propiedadDesc>Tipo de Partida</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad><propiedad><index>1</index><valor>Motor</valor><propiedadDesc>Especialidad</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad><propiedad><index>1</index><valor>Full Service</valor><propiedadDesc>Clasificación</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad><propiedad><index>1</index><valor>Marca</valor><propiedadDesc>Marca</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad><propiedad><index>1</index><valor>Grupo 1</valor><propiedadDesc>Grupo</propiedadDesc><idClase>Automovil</idClase><fechaCaducidad/><id>57</id></propiedad></propiedades>',
	'Actualizar',
	@salida OUTPUT;
	SELECT @salida AS salida;

	
*/
-- =============================================
CREATE  PROCEDURE [partida].[INS_PARTIDACONTRATO_MASIVA_SP] 
@idTipoObjeto			INT,
@numeroContrato			VARCHAR(50),
@idCliente				INT,	
@rfc					varchar(13),		
@propiedades			XML,
@idTipoAccion			varchar(20),
@idUsuario				INT,
@idClase				VARCHAR(10),
@err				    NVARCHAR(500) OUTPUT
AS

	DECLARE @idPartida	AS INT 
    DECLARE @tbl_propiedades AS TABLE(
        _row                    INT IDENTITY(1,1),
		[index]					INT,
		idClase					VARCHAR(10),
		propiedadDesc			NVARCHAR(250),
        valor                   NVARCHAR(500),
		fechaCaducidad			DATETIME,
		id						int
    )

    INSERT INTO @tbl_propiedades([index],
								propiedadDesc,
                                valor,
								fechaCaducidad,
                                id)

    SELECT
		ParamValues.col.value('index[1]','int'),
		ParamValues.col.value('propiedadDesc[1]','nvarchar(250)'),
        ParamValues.col.value('valor[1]','nvarchar(500)'),
		ParamValues.col.value('fechaCaducidad[1]','datetime'),
        CASE WHEN @idTipoAccion = 'Actualizar' THEN ParamValues.col.value('id[1]','int')
		ELSE 0 END
        FROM @propiedades.nodes('propiedades/propiedad') AS ParamValues(col)
		WHERE ParamValues.col.value('propiedadDesc[1]','nvarchar(250)') != 'index'


    DECLARE @cont		INT = 1,
			@index		INT = 0

	--SI EL TIPO DE ACCION ES REEMPLAZAR, BORRAMOS LAS PARTIDAS ACTUALES PARA ESE TIPO DE OBJETO
	if (@idTipoAccion = 'Reemplazar')
	begin
		--BORRAMOS PROPIEDADES
		delete pro
		from partida.PartidaContratoPropiedadGeneral pro
		inner join partida.partidaContrato p on pro.idTipoObjeto = p.idTipoObjeto
		where p.idTipoObjeto = @idTipoObjeto 
		AND pro.idClase = @idClase
		AND pro.rfcEmpresa = @rfc
		AND pro.idCliente = @idCliente
		AND pro.numeroContrato = @numeroContrato
		delete pro
		from partida.PartidaContratoPropiedadClase pro
		inner join partida.partidaContrato p on pro.idTipoObjeto = p.idTipoObjeto
		where p.idTipoObjeto = @idTipoObjeto
		AND pro.idClase = @idClase
		AND pro.rfcEmpresa = @rfc
		AND pro.idCliente = @idCliente
		AND pro.numeroContrato = @numeroContrato
		delete pro
		from partida.PartidaContratoPropiedadContrato pro
		inner join partida.partida p on pro.idTipoObjeto = p.idTipoObjeto
		where p.idTipoObjeto = @idTipoObjeto
		AND pro.idClase = @idClase
		AND pro.rfcEmpresa = @rfc
		AND pro.idCliente = @idCliente
		AND pro.numeroContrato = @numeroContrato
		--BORRAMOS PARTIDAS
		delete from partida.PartidaContrato where idTipoObjeto = @idTipoObjeto
		AND idClase = @idClase
		AND rfcEmpresa = @rfc
		AND idCliente = @idCliente
		AND numeroContrato = @numeroContrato
		-- Asignamos el comportamiento de 'Concatenar para que se guarden las nuevas partidas'
		set @idTipoAccion = 'Concatenar'
	end


	--EN CASO DE QUE SEA CONCATENAR SE INSERTAN SIEMPRE REGISTROS NUEVOS	
	IF(@idTipoAccion = 'Concatenar')
	BEGIN
		INSERT INTO partida.PartidaContrato 
		SELECT TOP 1
			@idTipoObjeto,
			@idClase,
			@rfc,
			@idCliente,
			@numeroContrato,
			1,
			@idUsuario
		FROM @tbl_propiedades

		SET @idPartida = @@IDENTITY
	END

   WHILE((SELECT COUNT(*) FROM @tbl_propiedades)>= @cont)

    BEGIN
        DECLARE 
		@propiedad		NVARCHAR(250),
		@idTipoValor	NVARCHAR(250),
		@idPropiedad	INT,
		@valor			NVARCHAR(500),
		@id				INT


		IF(@index != (Select [index] from @tbl_propiedades WHERE _row = @cont))
			BEGIN
				SET @index = @index + 1
				IF(@idTipoAccion = 'Concatenar')
				BEGIN
				INSERT INTO partida.PartidaContrato 
				SELECT TOP 1
					@idTipoObjeto,
					@idClase,
					@rfc,
					@idCliente,
					@numeroContrato,
					1,
					@idUsuario
				FROM @tbl_propiedades

				SET @idPartida = @@IDENTITY
				END				
			END		
		
		SELECT 
		@id = id,
		@propiedad = 
					CASE
					WHEN propiedadDesc IN (SELECT valor FROM partida.propiedadGeneral) THEN 'general'
					WHEN propiedadDesc IN (SELECT valor FROM partida.propiedadClase) THEN 'clase'
					ELSE 'contrato' END,
		@idTipoValor = (SELECT TOP 1 * FROM (
											SELECT idTipoValor 
											FROM [partida].[PropiedadGeneral]
											WHERE agrupador = prop.propiedadDesc
											UNION ALL
											SELECT idTipoValor 
											FROM [partida].[PropiedadClase]
											WHERE agrupador = prop.propiedadDesc
											UNION ALL
											SELECT idTipoValor 
											FROM [partida].[PropiedadContrato]
											WHERE agrupador = 'Clasificación'
											) as tbl1
						),
		@valor = (	SELECT  idPropiedadGeneral from [partida].[PropiedadGeneral] WHERE valor = prop.valor
					UNION ALL
					SELECT idPropiedadClase  from [partida].[PropiedadClase] WHERE valor = prop.valor
					UNION ALL
					SELECT idPropiedadContrato from [partida].[PropiedadContrato] WHERE valor = prop.valor
				),
		@idPropiedad = (SELECT  idPropiedadGeneral from [partida].[PropiedadGeneral] WHERE valor = prop.propiedadDesc
						UNION ALL
						SELECT idPropiedadClase  from [partida].[PropiedadClase] WHERE valor = prop.propiedadDesc
						UNION ALL
						SELECT idPropiedadContrato from [partida].[PropiedadContrato] WHERE valor = prop.propiedadDesc
						)
		FROM @tbl_propiedades prop
        WHERE _row = @cont 
		print @propiedad
		IF(@propiedad = 'general')
			BEGIN
				if (@idTipoAccion = 'Concatenar')
				begin
					INSERT INTO partida.PartidaContratoPropiedadGeneral 
					SELECT
						@idPartida idPartida,
						@idTipoObjeto idObjeto,
						@idClase,
						@rfc,
						@idCliente,
						@numeroContrato,
						CASE
							WHEN (@idTipoValor != 'Unico') THEN @valor
							ELSE @idPropiedad
							END idPropiedadGeneral,
						CASE 
							WHEN (@idTipoValor != 'Unico') THEN ''
							ELSE valor
							END valor,
						fechaCaducidad,
						@idUsuario
					FROM @tbl_propiedades 
					WHERE _row = @cont
				END
				if (@idTipoAccion = 'Actualizar')
				begin
					if (@idTipoValor = 'Unico')
					begin
						update pro 
							set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont)
						from partida.PartidaContratoPropiedadGeneral pro
						where
							pro.idPartidaContrato = @id
							and pro.idTipoObjeto = @idTipoObjeto
							and idPropiedadGeneral = @idPropiedad
							AND pro.idClase = @idClase
							AND pro.rfcEmpresa = @rfc
							AND pro.idCliente = @idCliente
							AND pro.numeroContrato = @numeroContrato
							
					end
					else if (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')
					BEGIN
						--EN CASO DE QUE SEA CATALOGO O AGRUPADOR
						--buscamos el id de la propiedad con base al nombre del agrupador
						select 
							@idPropiedad = [partida].[SEL_PARTIDAPROPIA_BUSCAIDPORAGRUPADOR_FN](@idTipoObjeto,@id,@idClase,propiedadDesc,@propiedad)
						from @tbl_propiedades where _row = @cont
						print(@idPropiedad)
						update pro 
							set
								pro.idPropiedadGeneral = @valor,
								pro.valor = ''
						from partida.PartidaContratoPropiedadGeneral pro
						where
							pro.idPartidaContrato = @id
							and pro.idTipoObjeto = @idTipoObjeto
							and idPropiedadGeneral = @idPropiedad
							AND pro.idClase = @idClase
							AND pro.rfcEmpresa = @rfc
							AND pro.idCliente = @idCliente
							AND pro.numeroContrato = @numeroContrato

					END
				end
			END
        ELSE IF(@propiedad = 'clase')
            BEGIN
				if (@idTipoAccion = 'Concatenar')
				begin
					INSERT INTO partida.PartidaContratoPropiedadClase
					SELECT
						@idPartida idPartida,
						@idTipoObjeto idObjeto,
						@idClase,
						@rfc,
						@idCliente,
						@numeroContrato,
						CASE
							WHEN (@idTipoValor != 'Unico') THEN @valor
							ELSE @idPropiedad
							END idPropiedadClase,
						CASE 
							WHEN (@idTipoValor != 'Unico') THEN ''
							ELSE valor
							END valor,
						fechaCaducidad,
						@idUsuario
					FROM @tbl_propiedades prop
					WHERE _row = @cont
				end
				if (@idTipoAccion = 'Actualizar')
				begin
					if (@idTipoValor = 'Unico')
					begin
						update pro 
							set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont)
						from partida.PartidaContratoPropiedadClase pro
						where
							pro.idPartidaContrato = @id
							and pro.idTipoObjeto = @idTipoObjeto
							and idPropiedadClase = @idPropiedad
							AND pro.idClase = @idClase
							AND pro.rfcEmpresa = @rfc
							AND pro.idCliente = @idCliente
							AND pro.numeroContrato = @numeroContrato
							
					end
					else if (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')
					BEGIN
						--EN CASO DE QUE SEA CATALOGO O AGRUPADOR
						--buscamos el id de la propiedad con base al nombre del agrupador
						
						select 
							@idPropiedad = [partida].[SEL_PARTIDAPROPIA_BUSCAIDPORAGRUPADOR_FN](@idTipoObjeto,@id,'Automovil',propiedadDesc,@propiedad)
						from @tbl_propiedades where _row = @cont
						print(@idPropiedad)
						update pro 
							set
								pro.idPropiedadClase = @valor,
								pro.valor = ''
						from partida.PartidaContratoPropiedadClase pro
						where
							pro.idPartidaContrato = @id
							and pro.idTipoObjeto = @idTipoObjeto
							and idPropiedadClase = @idPropiedad
							AND pro.idClase = @idClase
							AND pro.rfcEmpresa = @rfc
							AND pro.idCliente = @idCliente
							AND pro.numeroContrato = @numeroContrato
					end
				end

            END

		ELSE IF(@propiedad = 'contrato')
            BEGIN
				if (@idTipoAccion = 'Concatenar')
				begin
					INSERT INTO partida.PartidaContratoPropiedadContrato
					SELECT
						@idPartida idPartida,
						@idTipoObjeto idObjeto,
						@idClase,
						@rfc,
						@idCliente,
						@numeroContrato,
						CASE
							WHEN (@idTipoValor != 'Unico') THEN @valor
							ELSE @idPropiedad
							END idPropiedadContrato,
						CASE 
							WHEN (@idTipoValor != 'Unico') THEN ''
							ELSE valor
							END valor,
						fechaCaducidad,
						@idUsuario
					FROM @tbl_propiedades
					WHERE _row = @cont
				end
				if (@idTipoAccion = 'Actualizar')
				begin
					if (@idTipoValor = 'Unico')
					begin
						update pro 
							set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont)
						from partida.PartidaContratoPropiedadContrato pro
						where
							pro.idPartidaContrato = @id
							and pro.idTipoObjeto = @idTipoObjeto
							and idPropiedadContrato = @idPropiedad
							AND pro.idClase = @idClase
							AND pro.rfcEmpresa = @rfc
							AND pro.idCliente = @idCliente
							AND pro.numeroContrato = @numeroContrato
							
					end
					else if (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')
					BEGIN
						--EN CASO DE QUE SEA CATALOGO O AGRUPADOR
						--buscamos el id de la propiedad con base al nombre del agrupador
						select 
							@idPropiedad = [partida].[SEL_PARTIDAPROPIA_BUSCAIDPORAGRUPADOR_FN](@idTipoObjeto,@id,'Automovil',propiedadDesc,@propiedad)
						from @tbl_propiedades where _row = @cont
						print('contrato')
						print(@idPropiedad)
						update pro 
							set
								pro.idPropiedadContrato = @valor,
								pro.valor = ''
						from partida.PartidaContratoPropiedadContrato pro
						where
							pro.idPartidaContrato = @id
							and pro.idTipoObjeto = @idTipoObjeto
							and idPropiedadContrato = @idPropiedad
							AND pro.idClase = @idClase
							AND pro.rfcEmpresa = @rfc
							AND pro.idCliente = @idCliente
							AND pro.numeroContrato = @numeroContrato

					end
				end

            END

        SET @cont = @cont + 1
    END
go

