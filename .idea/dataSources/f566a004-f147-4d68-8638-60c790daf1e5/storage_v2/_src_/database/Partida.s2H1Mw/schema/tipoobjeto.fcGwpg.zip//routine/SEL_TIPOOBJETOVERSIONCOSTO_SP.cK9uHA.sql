-- =============================================
-- Author:		<Jose Luis Lozada Guerrero>
-- Create date: <27/04/2020>
-- Description:	<Obtiene todas las versiones de un tipo de objeto>
/*
	exec [tipoobjeto].[SEL_TIPOOBJETOVERSIONCOSTO_SP] 1,109,'automovil',6282,null	
*/
-- =============================================
CREATE PROCEDURE [tipoobjeto].[SEL_TIPOOBJETOVERSIONCOSTO_SP]
@idVersion		 INT,
@idTipoObjeto	 INT,
@idClase		 VARCHAR(10),
@idUsuario		 INT,
@err			 VARCHAR(8000) = '' OUTPUT		
AS
BEGIN
	SET @err=''
	SELECT	idVersion,
			idTipoObjeto,
			idClase,
			consecutivo,
			anio,
			--mes,
			CASE mes WHEN 1 THEN 'Enero' WHEN 2 THEN 'Febrero' WHEN 3 THEN 'Marzo' WHEN 4 THEN 'Abril' WHEN 5 THEN 'Mayo' WHEN 6 THEN 'Junio'
					 WHEN 7 THEN 'Julio' WHEN 8 THEN 'Agosto' WHEN 9 THEN 'Septiembre' WHEN 10 THEN 'Octubre' WHEN 11 THEN 'Noviembre' WHEN 12 THEN 'Diciembre'
			end mes,
			costo,
			venta,
			equipamiento,
			otro,
			activo,
			idUsuario 
	FROM partida.tipoobjeto.VersionCosto 
	WHERE 
		idversion	=@idVersion 
	AND idTipoObjeto=@idTipoObjeto 
	AND idClase		=@idClase
	AND activo=1
	ORDER BY anio,mes DESC
END
go

