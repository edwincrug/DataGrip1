-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 25-09-2019
-- Description: Obtiene las partidas utilizadas en cotizaciones para posteriormente calcular las restantes
-- EXEC partida.SEL_PARTIDASUTILIZADASXSOLICITUD_SP @idSolicitud = 378, @numeroContrato = '0001', @idCliente = 92, @idClase = 'Automovil'
-- =============================================
CREATE PROCEDURE [partida].[SEL_PARTIDASUTILIZADASXSOLICITUD_SP]
	@idSolicitud INT,
	@numeroContrato VARCHAR(50),
	@idCliente INT,
	@idClase VARCHAR(10),
	@idUsuario INT = NULL,
	@err VARCHAR(MAX) = NULL OUTPUT
AS
BEGIN
	SELECT idSolicitud
		, idPartida
		, SUM(cantidad) AS total
	FROM Solicitud.solicitud.SolicitudCotizacionPartida
	WHERE idSolicitud = @idSolicitud
	AND numeroContrato = @numeroContrato
	AND idCliente = @idCliente
	AND idClase = @idClase
	GROUP BY idSolicitud, idPartida 
END
go

