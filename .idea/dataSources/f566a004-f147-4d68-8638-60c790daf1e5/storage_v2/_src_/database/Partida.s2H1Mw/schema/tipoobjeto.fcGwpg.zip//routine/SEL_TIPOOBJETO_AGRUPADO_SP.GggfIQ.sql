-- =============================================
-- Author: Gerardo Zamudio		
-- Create date: 08-04-2020
-- Description: Obtiene los tipos de objetos agrupados por marca y clase
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	EXEC [tipoobjeto].[SEL_TIPOOBJETO_AGRUPADO_SP] 'Automovil',6077, '';
*/
-- =============================================
CREATE  PROCEDURE [tipoobjeto].[SEL_TIPOOBJETO_AGRUPADO_SP] 
	@idClase		VARCHAR(10),
	@idUsuario		INT,
	@err			nvarchar(500) OUTPUT
AS
BEGIN
	SELECT 
	*
		  --[marca]
		  --,[clase]
		  --,[marca] +' / '+ [clase] AS marcaClase
	FROM [Partida].[tipoobjeto].[SEL_TIPO_OBJETO_CLASE_VW]
	WHERE idClase = @idClase
	--GROUP BY
	--[clase]
	--,[marca]
	ORDER BY 6
end

go

