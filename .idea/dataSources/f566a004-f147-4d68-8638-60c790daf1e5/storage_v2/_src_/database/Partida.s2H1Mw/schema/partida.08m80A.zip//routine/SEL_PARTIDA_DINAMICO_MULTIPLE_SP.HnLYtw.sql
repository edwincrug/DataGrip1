
-- =============================================
-- Author: Edgar Mendoza	
-- Create date: 02-04-2019
-- Description: Consulta dinámica recursiva para obtener las partidas
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	 13/08/2019	José Etmanuel	Agregando filtro por tipo de solicitud

	*- Testing...
	EXEC [partida].[SEL_PARTIDA_DINAMICO_MULTIPLE_SP] 1037,'Imagen','Automovil','ASE0508051B6',185,'43',6282,null;
	EXEC [partida].[SEL_PARTIDA_DINAMICO_MULTIPLE_SP] 1037,'Imagen','Automovil','ASE0508051B6',185,'43',6282, null;

*/
-- =============================================
CREATE PROCEDURE [partida].[SEL_PARTIDA_DINAMICO_MULTIPLE_SP] 
	@idSolicitud		INT,
	@idTipoSolicitud	VARCHAR(10)=NULL,
	@idClase			VARCHAR(10),
	@rfcEmpresa			VARCHAR(13),
	@idCliente			INT,
	@numeroContrato		VARCHAR(50),
	@idUsuario			INT,
	@err				VARCHAR(500) OUTPUT
	
AS
BEGIN
	DECLARE @txTiposObjeto TABLE(idTipoObjeto INT)

	INSERT INTO @txTiposObjeto
	SELECT  DISTINCT idTipoObjeto
	FROM	solicitud.solicitud.solicitudObjeto 
	WHERE	idSolicitud		=@idSolicitud
	AND		idTipoSolicitud	=@idTipoSolicitud
	AND		idClase			=@idClase
	AND		rfcEmpresa		=@rfcEmpresa
	AND     idCliente		=@idCliente
	AND     numeroContrato	=@numeroContrato
	
	create table #partidas(
		idPartida					int,
		agrupador			varchar(500),
		valor				varchar(MAX),
		orden				int,
		posicion			int,
		ordenFinal			INT
	)

	/**********************************************************************************************************************
	******************************************************CATALOGOS Y AGRUPADORES******************************************
	**********************************************************************************************************************/
	--PROPIEDADES GENERALES
	;with catalogos as(
	select	
		par.idPartida					idPartida,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from 
	partida.Partida par
	inner join partida.PartidaPropiedadGeneral tpg on par.idPartida = tpg.idPartida
	inner join partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1
	inner join integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	where 
		prg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		AND par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
		AND par.idClase = @idClase
		AND par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idPartida					idPartida,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from partida.PropiedadGeneral prg 
	inner join integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	inner join catalogos cat on cat.idPadre = prg.idPropiedadGeneral
	and prg.activo = 1
	)
	insert into #partidas
	select	cat.idPartida,
			cat.agrupador,
			cat.valor,
			cat.orden,
			cat.posicion,
			cat.ordenFinal
	from	catalogos cat 
	where	cat.idPadre is not null

	--PROPIEDADES DE CLASE
	;with catalogos as(
	select
		par.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from 
	partida.Partida par
	inner join partida.PartidaPropiedadClase tpc on par.idPartida = tpc.idPartida
	inner join partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.activo = 1 and prc.idClase = @idClase
	where 
		prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
		AND par.idClase = @idClase
		and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.PropiedadClase prc 
	inner join catalogos cat on cat.idPadre = prc.idPropiedadClase 
	WHERE prc.activo = 1
	)
	insert into #partidas
	select 
		cat.idPartida,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null


--PROPIEDADES DE CONTRATO
;with catalogos as(
	select
		par.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		2								ordenFinal
	from 
	partida.Partida par
	inner join partida.PartidaPropiedadContrato tpc on par.idPartida = tpc.idPartida
	inner join partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato and prc.activo = 1 and prc.idCliente = @idCLiente  and prc.numeroContrato = @numeroContrato
	where 
		prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
		and par.activo = 1
		AND par.idClase = @idClase
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		2								ordenFinal
	from partida.PropiedadContrato prc 
	inner join catalogos cat on cat.idPadre = prc.idPropiedadContrato 
	WHERE prc.activo = 1
	and prc.numeroContrato = @numeroContrato
	and prc.idCliente = @idCLiente
	)
	insert into #partidas
	select 
		cat.idPartida,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

	
/**********************************************************************************************************************
*********************************************************TAGS**********************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with tags as(
	select	
		par.idPartida					idPartida,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from 
	partida.Partida par
	inner join partida.PartidaPropiedadGeneral tpg on par.idPartida = tpg.idPartida
	inner join partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1
	where prg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
	AND par.idClase = @idClase
	and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idPartida					idPartida,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from partida.PropiedadGeneral prg 
	inner join integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	inner join tags tag on tag.idPadre = prg.idPropiedadGeneral
	and prg.activo = 1
	)
	insert into #partidas
	select distinct 
		idPartida,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags.idPartida and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

--PROPIEDADES CLASE
;with tags as(
	select	
		par.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.Partida par
	inner join partida.PartidaPropiedadClase tpc on par.idPartida = tpc.idPartida
	inner join partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.activo = 1 and prc.idClase = @idClase
	where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
	AND par.idClase = @idClase
	and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.PropiedadClase prc 
	inner join tags tag on tag.idPadre = prc.idPropiedadClase
	and prc.activo = 1
	)
	insert into #partidas
	select distinct 
		idPartida,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags.idPartida and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags



--PROPIEDADES CONTRATO
;with tags as(
	select	
		par.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		2								ordenFinal
	from partida.Partida par
	inner join partida.PartidaPropiedadContrato tpc on par.idPartida = tpc.idPartida
	inner join partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato and prc.activo = 1 and prc.idCliente = @idCLiente  and prc.numeroContrato = @numeroContrato
	where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
	and prc.numeroContrato = @numeroContrato
	and prc.idCliente = @idCLiente
	AND par.idClase = @idClase
	and par.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idPartida					idPartida,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		2								ordenFinal
	from partida.PropiedadContrato prc 
	inner join tags tag on tag.idPadre = prc.idPropiedadContrato
	and prc.numeroContrato = @numeroContrato
	and prc.idCliente = @idCLiente
	and prc.activo = 1
	)
	insert into #partidas
	select distinct 
		idPartida,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idPartida = tags.idPartida and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

/**********************************************************************************************************************
***************************************************VALORES FIJOS*******************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
INSERT INTO #partidas
select 
	par.idPartida			idPartida,
	prg.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	CASE 
		WHEN prg.idTipoDato in ('Image', 'Pdf', 'Documento' )  THEN (SELECT valor 
																		FROM Common.configuracion.configuracion 
																		where nombre = 'fileServer') + (select path from FileServer.documento.Documento where idDocumento = tpg.valor) 
		ELSE tpg.valor	END			valor,
	prg.orden				orden,
	prg.posicion			posicion,
	0						ordenFinal
from partida.Partida par 
inner join partida.PartidaPropiedadGeneral tpg on tpg.idPartida = par.idPartida
inner join partida.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1 
where
	prg.idTipoValor = 'Unico'
	and par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
	AND par.idClase = @idClase
	and par.activo = 1

--PROPIEDADES DE CLASE
INSERT INTO #partidas
select 
	par.idPartida			idPartida,
	prc.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	tpc.valor				valor,
	prc.orden				orden,
	prc.posicion			posicion,
	1						ordenFinal
from partida.Partida par
inner join partida.PartidaPropiedadClase tpc on tpc.idPartida = par.idPartida
inner join partida.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.activo = 1 and prc.idClase = @idClase
where
	prc.idTipoValor = 'Unico'
	and par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
	AND par.idClase = @idClase
	and par.activo = 1

--PROPIEDADES DE CONTRATO
INSERT INTO #partidas
select 
	par.idPartida			idPartida,
	prc.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	tpc.valor				valor,
	prc.orden				orden,
	prc.posicion			posicion,
	2						ordenFinal
from partida.Partida par
inner join partida.PartidaPropiedadContrato tpc on tpc.idPartida = par.idPartida
inner join partida.PropiedadContrato prc on tpc.idPropiedadContrato = prc.idPropiedadContrato 
and prc.activo = 1 and prc.idCliente = @idCLiente  and prc.numeroContrato = @numeroContrato
where
	prc.idTipoValor = 'Unico'
	and par.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
	and prc.numeroContrato = @numeroContrato
	AND par.idClase = @idClase
	and prc.idCliente = @idCLiente
	and par.activo = 1



/**********************************************************************************************************************
*************************************************INSERTAMOS COSTOS*****************************************************
**********************************************************************************************************************/

/**********************************************************************************************************************
*************************************************INSERTAMOS COSTOS*****************************************************
**********************************************************************************************************************/

INSERT INTO #partidas
select
	
	par.idPartida				idPartida
	,tc.nombre					agrupador
	,case 
		when parcos.costo is null then 0
		else parcos.costo
	end costo
	,1							orden
	,3							posicion
	,2							posicionFinal
	
from Partida.partida.partida par
--TIPO OBJETO
inner join Partida.tipoobjeto.TipoObjeto tob on 
	tob.idTipoObjeto = par.idTipoObjeto 
	and par.idClase = tob.idClase
--TIPOS DE COBRO POR PARTIDA
left join Partida.partida.TipoCobro tc on
	par.idClase = tc.idClase
--COSTOS DE LISTA DE PARTIDAS 
left join Partida.partida.partidaCosto parcos on 
	parcos.idPartida = par.idPartida
	and parcos.idTipoObjeto = par.idTipoObjeto
	and parcos.idClase = par.idClase
	and parcos.idTipoCobro = tc.idTipoCobro
	

WHERE 
	par.idClase = @idClase
	and tob.idtipoobjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
	and par.activo = 1


DECLARE @partidasTmp TABLE (
		idPartida			int,
		agrupador			varchar(max),
		valor				varchar(max),
		orden				int,
		posicion			int,
		ordenFinal			INT
	)

-- Filtro por tipo de solicitud
IF isnull(@idTipoSolicitud,'') != ''
BEGIN
	INSERT INTO @partidasTmp
		SELECT 
			p.idPartida,
			agrupador,
			valor,
			orden,
			posicion,
			ordenFinal
		FROM #partidas AS P
		INNER JOIN partida.TipoSolicitud AS T ON P.idPartida = T.idPartida 
		AND T.idTipoObjeto IN (SELECT idTipoObjeto FROM @txTiposObjeto)
		AND T.idClase = @idClase
		WHERE idTipoSolicitud = @idTipoSolicitud

	DELETE FROM #partidas;
	
	INSERT INTO #partidas
	SELECT * FROM @partidasTmp

	--EN CASO DE QUE SEA COMPRA ELIMINAMOS LAS PARTIDAS QUE NO TIENEN ASIGNADO PROVEEDOR
	if (@idClase='Compra')
	BEGIN
		DELETE FROM #partidas where idPartida not in (
			select 
				P.idPartida
			from Solicitud.compraBPRO.ProveedorEntidadPartida PEP
			inner join partida.partida.Partida P on PEP.numeroParte = partida.getPropiedadPartida(P.idPartida,'noParte','general')
		)
	END
	delete @partidasTmp


END


/**********************************************************************************************************************
******************************************************PIVOTE***********************************************************
**********************************************************************************************************************/
declare 
	@columnsName varchar(max) = ''

create table #propiedadesOrdenas
	(
		agrupador			varchar(max),
		ordenFinal			int,
		posicion			int,
		orden				int
	)

	--select * from #partidas

insert into #propiedadesOrdenas
select distinct 
	pr.agrupador,
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)
from #partidas pr group by pr.agrupador order by 
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)

SET @columnsName = ISNULL(STUFF((SELECT ',' + QUOTENAME(prg.agrupador) 
						FROM #propiedadesOrdenas prg 
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,''),'sinCoinicidencia')

declare @query varchar(max)


set @query = '
	select
		*,
		(select case when sum(costo) is not null then sum(costo)
		else 0 end from partida.PartidaCosto cos where cos.idPartida = resultado.idPartida) Costo,
		ISNULL((select sum(Venta) from cliente.contrato.PartidaPrecio pre where pre.idPartida = resultado.idPartida and pre.idCliente = ' + convert(varchar,@idCliente) + ' and numeroContrato = ''' + @numeroContrato + '''),0) Venta ,
		(SELECT STUFF(
		(SELECT '', '' + idTipoSolicitud
			FROM partida.TipoSolicitud TS
			WHERE TS.idPartida = resultado.idPartida 
			FOR XML PATH ('''')),
			1,1, '''') ) AS idTipoSolicitud
			into #parFinal
	from
	(select idPartida, agrupador, isnull(valor,0) valor from #partidas) t
	pivot
	(	
		MAX(valor)
		for agrupador in (' + @columnsName + ')
	) AS resultado

	select pf.*,
	CASE 
		WHEN p.activo = 1 THEN ''Activo''
		ELSE ''Inactivo'' 
	END as ''activo partida'',
	PE.nombre as ''estatus partida'',p.idTipoObjeto
	from #parFinal PF
	INNER JOIN partida.Partida p on pf.idPartida = p.idPartida
	inner join partida.PartidaEstatus PE on pe.idPartidaEstatus = p.idPartidaEstatus order by p.idTipoObjeto asc'

print @query

execute (@query)
drop table #partidas
drop table #propiedadesOrdenas

end

go

