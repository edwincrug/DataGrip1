-- ==========================================================================================
-- CREAT AUTH:  Jordan Gómez
-- AUTH MOD: YJH
-- CREAT DATE:  23/05/2018
-- CREAT DESC:  Store solo para Banorte 
-- ==========================================================================================
-- [Banorte].[INS_ORDEN_DETALLE_REFACCIONES_SP] 48152, 15, 1, 20, 0
CREATE PROCEDURE [Banorte].[INS_ORDEN_DETALLE_REFACCIONES_SP]
    @idCotizacion NUMERIC(18,0) = 0,
    @idEncabezado NUMERIC(18,0) = 0,    
    @tipoDetalle SMALLINT = 1,-- 1: servicio, 2: refacciones
    @idOperacion NUMERIC(18,0),
    @isProduction NUMERIC(18,0)
AS
BEGIN   
DECLARE @db NVARCHAR(100)
DECLARE @query NVARCHAR(MAX)
DECLARE @queryUpdatePrecios NVARCHAR(MAX)
DECLARE @queryInsertDet NVARCHAR(MAX)
DECLARE @queryCreatTableSumetorias NVARCHAR(MAX)
DECLARE @queryInsertSumetorias NVARCHAR(MAX)
DECLARE @queryUpdateEnc NVARCHAR(MAX)
DECLARE @queryDropSumatorias NVARCHAR(MAX)
DECLARE @orden NVARCHAR(MAX)
DECLARE @queryupdateEncLet NVARCHAR(MAX)
DECLARE @queryupdateEncTot NVARCHAR(MAX)
DECLARE @totalOrdenes NUMERIC(18,0)
DECLARE @totalMano NUMERIC(18,0)
DECLARE @totalRefacciones NUMERIC(18,0)
DECLARE @totalLubricantes NUMERIC(18,0)
DECLARE @tablaValor TABLE (ORD NVARCHAR(MAX))
DECLARE @valorOrden NVARCHAR(MAX)
DECLARE @idContratoOperacion VARCHAR(5)
DECLARE @actualizaObs NVARCHAR(MAX)
DECLARE @xmlProveedor xml
CREATE TABLE ##tempClaveSat(ClaveProdServ nchar(30), Descripcion varchar(max),
		                       Cantidad numeric(18,2), ValorUnitario numeric(18,2), Importe NUMERIC(18,2),
							   ClaveUnidad varchar(50))
							   
SELECT @idContratoOperacion=idContratoOperacion FROM ContratoOperacion WHERE idOperacion=@idOperacion

IF(@isProduction = 1)
    BEGIN
        SELECT                 
               @db= SERVER+'.'+DBProduccion                
        FROM ASEPROT.dbo.ContratoOperacionFacturacion 
        WHERE idContratoOperacion =  @idContratoOperacion
    END
ELSE
    BEGIN
        SELECT 
                @db=DB
        FROM ASEPROT.dbo.ContratoOperacionFacturacion
		WHERE idContratoOperacion = @idContratoOperacion
	END

	SET @xmlProveedor = (SELECT REPLACE(REPLACE(REPLACE(xml, 'ÿ', ''), 'cfdi:', ''), '<?xml version="1.0" encoding="UTF-8"?>', '')
	FROM facturaCotizacion WHERE idCotizacion = @idCotizacion)
	
	INSERT INTO ##tempClaveSat 
	(ClaveProdServ, Descripcion, Cantidad, ValorUnitario, Importe, ClaveUnidad)
	SELECT 
	ClaveProdServ    = T.Item.value('@ClaveProdServ', 'nchar(20)'),
	Descripcion		 = T.Item.value('@Descripcion', 'varchar(max)'),
	Cantidad		 = T.Item.value('@Cantidad', 'numeric(18,2)'),
	ValorUnitario	 = T.Item.value('@ValorUnitario', 'numeric(18,2)'),
	Importe			 = T.Item.value('@Importe', 'numeric(18,2)'),
	ClaveUnidad      = T.Item.value('@ClaveUnidad', 'varchar(50)')
	FROM   @xmlProveedor.nodes(' Comprobante/Conceptos/Concepto') AS T(Item)

	select * from ##tempClaveSat
	print @tipoDetalle
    IF(@tipoDetalle = 1) -- SERVICIO
        BEGIN
        SET @query = 'INSERT INTO '+@db+'.[dbo].[ADE_ORDSERDET](
                        [OTD_IDENT],
                        [OTD_CONSECUTIVO],
                        [OTD_DESCRIPCION],
                        [OTD_CANTIDAD],
                        [OTD_PRECIOUNITARIOCOMPRA],
                        [OTD_SUBTOTALUNITARIO],
                        [OTD_IVAUNITARIO],
                        [OTD_TOTALUNITARIO],
                        [OTD_PRECIOUNITARIOVENTA],
                        [OTD_FECHOPE],
                        [OTD_HORAOPE],
						[OTD_IDPARTE],
                        [OTD_CVESAT])
                SELECT                 
                       '+CAST(@idEncabezado AS NVARCHAR(30))+',
                       ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
                       P.descripcion, --OTD_DESCRIPCION
                       CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
                       CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
                       CAST(CAST((CAST(CD.cantidad AS DECIMAL(18,2)) * CAST(CD.costo AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
                       CAST(CAST((CAST(CD.cantidad AS DECIMAL(18,2)) * (CAST(CD.costo  AS DECIMAL(18,2))* .16)) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
                       CAST(CAST((CAST(CD.cantidad AS DECIMAL(18,2)) * CAST(CD.costo AS DECIMAL(18,2))) + (CD.cantidad * (CD.costo * .16)) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
                       CAST(CD.venta AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
                       CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
                       CONVERT(VARCHAR(8),GETDATE(),108),--hora de la base
					   TEMP.ClaveUnidad, 
					   TEMP.ClaveProdServ
                    FROM Ordenes O
                        JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
                        JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
						JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
						INNER JOIN ##tempClaveSat TEMP ON TEMP.Cantidad = CD.cantidad AND (TEMP.ValorUnitario - .10) <= CD.costo AND (TEMP.ValorUnitario + .10) >= CD.costo 
                        WHERE C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) AND CD.cantidad >0
                        GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida, TEMP.ClaveUnidad, TEMP.ClaveProdServ'
			print @query
            EXECUTE SP_EXECUTESQL @query

            --SET @queryUpdatePrecios = 'UPDATE osdet

            --SET
            --osdet.OTD_PRECIOUNITARIOVENTA = cdet.venta            
            --FROM '  + @db + '.dbo.[ADE_ORDSERDET] osdet
            --INNER JOIN ' + @db + '.dbo.[ADE_ORDSERENC] osenc ON osenc.OTE_IDENT = osdet.OTD_IDENT
            --INNER JOIN Cotizaciones coti ON coti.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+'
            --INNER JOIN CotizacionDetalle cdet ON cdet.idCotizacion = coti.idCotizacion             
            --WHERE osdet.OTD_IDENT = '+CAST(@idEncabezado AS NVARCHAR(30))+' '
			
            --EXECUTE SP_EXECUTESQL @queryUpdatePrecios
			SET @orden = 'SELECT OTE_ORDENGLOBAL FROM '  + @db + '.dbo.[ADE_ORDSERENC] WHERE OTE_IDENT = '+ CAST(@idEncabezado AS nvarchar(MAX))+''
			INSERT INTO @tablaValor
			EXECUTE SP_EXECUTESQL @orden
			
			SELECT @valorOrden = ORD FROM @tablaValor
			SET @actualizaObs = 'UPDATE ' + @db + '.dbo.[ADE_ORDSERENC]
			SET OTE_OBSERVACIONES = '' ORDEN: ' + @valorOrden + '''+ '' ECO:' +  substring(@valorOrden,4,7) + '''
			WHERE OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '';

			EXECUTE SP_EXECUTESQL @actualizaObs

            SET @queryCreatTableSumetorias = 'CREATE TABLE sumatoriasTemporal(
                OTD_IDENT  numeric(18,0)
                ,SUM_MO decimal(18,2)
                ,SUM_REF decimal(18,2)'            
			CREATE TABLE ##sumatoriasTemporal (
                OTD_IDENT  numeric(18,0)
                )
            --EXECUTE SP_EXECUTESQL @queryCreatTableSumetorias
            SET @queryInsertSumetorias = 'INSERT INTO  ##sumatoriasTemporal
            SELECT 
            OTD_IDENT
            --,SUM(OTD_CANTIDAD*OTD_MO)
            --,SUM(OTD_CANTIDAD*OTD_REF)
            --,SUM(OTD_CANTIDAD*OTD_LUB)
            FROM ' + @db + '.dbo.[ADE_ORDSERDET] 
            GROUP BY OTD_IDENT'
			
            EXECUTE SP_EXECUTESQL @queryInsertSumetorias
            SET @queryUpdateEnc = 'UPDATE osenc
            SET
            -- osenc.OTE_SUBMO = SUM_MO
            --,osenc.OTE_SUBREF = SUM_REF
            --,osenc.OTE_SUBLUB = SUM_LUB
            FROM '+@db+'.dbo.[ADE_ORDSERENC] osenc
            INNER JOIN ##sumatoriasTemporal suma ON osenc.OTE_IDENT = suma.OTD_IDENT
            WHERE osenc.OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30))

           -- EXECUTE SP_EXECUTESQL @queryUpdateEnc
           
            SET @queryupdateEncLet = 'UPDATE B
                SET B.OTE_DESGLOSE = ''A''
                FROM '+@db+'.dbo.ADE_ORDSERENC B
                INNER JOIN 
                (SELECT OTE_ORDENGLOBAL, 
                CASE
                     WHEN count(OTE_ORDENGLOBAL) > 1 THEN 
                         1 END S 
                FROM '+@db+'.dbo.ADE_ORDSERenc group by OTE_ORDENGLOBAL) A ON A.S is not null AND A.OTE_ORDENGLOBAL = ' + ''''+@valorOrden+''''
            
            EXECUTE SP_EXECUTESQL @queryupdateEncLet
            SET @queryupdateEncTot = 'UPDATE  ENC
                SET 
                ENC.OTE_SUBMO = OK.MANO,
                ENC.OTE_SUBREF = OK.REFA,
                ENC.OTE_SUBLUB = OK.LUB
                FROM '+@db+'.dbo.ADE_ORDSERENC ENC
                INNER JOIN (
                SELECT SUM(B.OTE_SUBMO) MANO,
                SUM(B.OTE_SUBREF) REFA, 
                SUM(B.OTE_SUBLUB) LUB,
                B.OTE_ORDENGLOBAL
                FROM '+@db+'.dbo.ADE_ORDSERENC B
                INNER JOIN 
                (SELECT OTE_ORDENGLOBAL, 
                CASE
                     WHEN count(OTE_ORDENGLOBAL) > 1 THEN 
                         1 END S 
                FROM '+@db+'.dbo.ADE_ORDSERENC group by OTE_ORDENGLOBAL) A ON A.OTE_ORDENGLOBAL = B.OTE_ORDENGLOBAL AND A.S is not null
                WHERE B.OTE_ORDENGLOBAL = '+ ''''+@valorOrden+'''' +'
				group by B.OTE_ORDENGLOBAL 
                ) OK ON OK.OTE_ORDENGLOBAL = ENC.OTE_ORDENGLOBAL'
            
            EXECUTE SP_EXECUTESQL @queryupdateEncTot
            
        END
		DROP TABLE ##sumatoriasTemporal
		DROP TABLE ##tempClaveSat
END
go

grant execute, view definition on Banorte.INS_ORDEN_DETALLE_REFACCIONES_SP to DevOps
go

