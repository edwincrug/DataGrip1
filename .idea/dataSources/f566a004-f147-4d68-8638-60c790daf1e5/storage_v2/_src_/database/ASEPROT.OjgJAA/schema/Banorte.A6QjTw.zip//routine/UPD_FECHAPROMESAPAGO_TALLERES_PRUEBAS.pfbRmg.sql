
-- =============================================
-- Author:		<YJH>
-- Create date: <25/03/2019>
-- Description:	<Actualiza los comentarios en las cxc y cxp de Ase y cxc de las agencias>
-- [BANORTE].[UPD_FECHAPROMESAPAGO_TALLERES_PRUEBAS] 26, 1
-- =============================================

CREATE PROCEDURE [Banorte].[UPD_FECHAPROMESAPAGO_TALLERES_PRUEBAS]
	@idContratoOperacion int,
	@isProduction int 	 
AS
BEGIN
	DECLARE @dbBanorte NVARCHAR(100)

	DECLARE @dbProveedor NVARCHAR(100)

	DECLARE @facturasProveedor as TABLE ( idOrden int, numeroOrden nvarchar(200), numeroReclamo nvarchar(200), facturaProveedor nvarchar(max),
	 idCotizacion int, servidor nvarchar(100),  facturaCeros nvarchar(100), idCotizacionTaller int, facturaComentarios nvarchar(max), tipoOrden nvarchar(20))
	
	DECLARE @doctosTable as TABLE (totalDoctos int, totalDoctosSubidos int, doctosSubidos nvarchar(max), idOrden int, idCotizacionTaller int, fechaEvidenciaCompleta date)

	DECLARE @doctosSubidosTable as TABLE (idOrden int, doctosSubidos nvarchar(max))
	
	DECLARE @provisionBanorte AS TABLE (idProvision [int] IDENTITY(1,1), idOrden int, idCotizacionTaller int, numeroOrden nvarchar(max),
	                                    numeroReclamo nvarchar(max), facturaBanorte nvarchar(max), fechaProvision nvarchar(20), 
										fechaPromesa date, contraRecibo nvarchar(200), fechaContraRecibo date, fechaFactura nvarchar(20), tipoOrden nvarchar(20)) 	
	
	DECLARE @cuentasPorPagar AS TABLE (idCuenta [int] IDENTITY(1,1) , numeroReclamo nvarchar(max), idCotizacionTaller int, fechaPromesa date, 
	facturaProveedor nvarchar(max), servidor nvarchar(100), comentario nvarchar(max), tablaProveedor nvarchar(100), facturasinCeros nvarchar(max), tipoOrden nvarchar(20))	

	IF(@isProduction = 1)
	    BEGIN
		    SELECT @dbBanorte= SERVER+'.'+DBProduccion
			FROM ASEPROT.dbo.ContratoOperacionFacturacion 
			WHERE idContratoOperacion =  @idContratoOperacion			
		END
	ELSE
		BEGIN
	        SELECT @dbBanorte=DB
			FROM ASEPROT.dbo.ContratoOperacionFacturacion
			WHERE idContratoOperacion = @idContratoOperacion							
		END

	---Facturas Agencia
	insert into @facturasProveedor
		select O.idOrden, O.numeroOrden, S.numeroReclamo, 
		(SELECT ASEPROT.[dbo].[SEL_FACBYPEDIDOZEROS_TFN](S.numeroReclamo, M.idMarca))
		, C.idCotizacion, 
		( case when M.server ='192.168.20.71' or M.server ='192.168.20.3'  then '' else '['+ M.server + '].' end) + M.dbCon_Car,		
		(SELECT ASEPROT.[dbo].[SEL_FACBYPEDIDO_TFN](S.numeroReclamo, M.idMarca))--, M.idMarca
		,CT.idCotizacionTaller
		,(SELECT ASEPROT.[dbo].[SEL_FACBYPEDIDO2_TFN](S.numeroReclamo, M.idMarca))--, M.idMarca
		, case when O.idCatalogoTipoOrdenServicio=10 then '(R)' else '(MO)' end
	from ASEPROT.dbo.Ordenes O
	inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion <> 4
	inner join RefaccionMultiMarca.Relacion.UnidadSiniestroOrden SOC on SOC.orden = O.idOrden --and SOC.idCotizacionSISCO= C.idCotizacion
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
	inner join RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden = O.idOrden or CT.idOrdenRefaccion = O.idOrden
	inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
	inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = U.marca
	where  O.idContratoOperacion=@idContratoOperacion AND S.id NOT IN(SELECT idSiniestro 
																	  FROM [RefaccionMultiMarca].[Operacion].[CotizacionTaller]
																	  GROUP BY idSiniestro
																	  HAVING COUNT(idSiniestro) > 1)--and O.idOrden in (72589)
	order by O.idOrden						
	
	insert into @facturasProveedor
	select O.idOrden, O.numeroOrden, S.numeroReclamo, 
		(SELECT ASEPROT.[dbo].[SEL_FACBYPEDIDOZEROS_TFN_COMPLEMENTO](S.numeroReclamo,CT.ore_idorden,M.idMarca))
		, C.idCotizacion, 
		( case when M.server ='192.168.20.71' or M.server ='192.168.20.3'  then '' else '['+ M.server + '].' end) + M.dbCon_Car,		
		(SELECT ASEPROT.[dbo].[SEL_FACBYPEDIDO_TFN_COMPLEMENTO](S.numeroReclamo,CT.ore_idorden,M.idMarca))--, M.idMarca
		,CT.idCotizacionTaller
		,(SELECT ASEPROT.[dbo].[SEL_FACBYPEDIDO2_TFN_COMPLEMENTO](S.numeroReclamo,CT.ore_idorden,M.idMarca))--, M.idMarca
		, case when O.idCatalogoTipoOrdenServicio=10 then '(R)' else '(MO)' end
	from ASEPROT.dbo.Ordenes O
	inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion <> 4
	inner join RefaccionMultiMarca.Relacion.UnidadSiniestroOrden SOC on SOC.orden = O.idOrden --and SOC.idCotizacionSISCO= C.idCotizacion
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
	inner join RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden = O.idOrden or CT.idOrdenRefaccion = O.idOrden
	inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
	inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = U.marca
	where  O.idContratoOperacion=@idContratoOperacion AND S.id IN(SELECT idSiniestro 
																  FROM [RefaccionMultiMarca].[Operacion].[CotizacionTaller]
																  GROUP BY idSiniestro
																  HAVING COUNT(idSiniestro) > 1)
	order by O.idOrden	

	-- Documentacion Requerida y Subida de cada orden 
	insert into @doctosTable (totalDoctos, idOrden, idCotizacionTaller)	
	select count(distinct DT.documento), FP.idOrden, CT.idCotizacionTaller	
	from @facturasProveedor FP
	inner join RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden=FP.idOrden OR CT.idOrdenRefaccion = FP.idOrden
	inner join RefaccionMultiMarca.[Catalogo].[ConfiguracionDocumentoTaller] CDT on CDT.idConfiguracionDocumentoTaller = CT.idConfiguracionDocumentoTaller
	inner join RefaccionMultiMarca.[Catalogo].[ConfiguracionDetalleDocumentoTaller] Conf on Conf.idConfiguracionDocumentoTaller = CDT.idConfiguracionDocumentoTaller
	inner join RefaccionMultiMarca.Catalogo.DocumentoTaller DT on DT.idDocumentoTaller = Conf.idDocumentoTaller	
	where (FP.facturaProveedor is not null or FP.facturaProveedor <> '') and Conf.requerido=1 and Conf.activo=1 and Conf.esObligatorio=1 --and DT.esFactura=0 -- 13	
	group by FP.idOrden, CT.idCotizacionTaller
		
	update @doctosTable set totalDoctosSubidos =  (select COUNT(DISTINCT descripcionEvidencia) from ASEPROT.dbo.Evidencias E
	inner join RefaccionMultiMarca.Catalogo.DocumentoTaller DT on DT.documento = E.descripcionEvidencia --and DT.requerido=1 and DT.activo=1 and DT.esObligatorio=1
	inner join RefaccionMultiMarca.[Catalogo].[ConfiguracionDetalleDocumentoTaller] Conf on DT.idDocumentoTaller = Conf.idDocumentoTaller
	where E.idOrdenServicio = idOrden and Conf.requerido=1 and Conf.activo=1 and Conf.esObligatorio=1 and DT.esFactura=0)

	update @doctosTable set totalDoctosSubidos = totalDoctosSubidos + ISNULL((select top 1 1), 0) from ASEPROT.dbo.facturaCotizacion  FC
	inner join @facturasProveedor FP on FP.idCotizacion = FC.idCotizacion
	
	insert into @doctosSubidosTable				
		SELECT FP.idOrden, STUFF((
			select distinct ','+ DT.documento 
			FROM RefaccionMultiMarca.Operacion.CotizacionTaller CT --on CT.idCotizacionTaller = FP.idCotizacionTaller
			inner join RefaccionMultiMarca.[Catalogo].[ConfiguracionDocumentoTaller] CDT on CDT.idConfiguracionDocumentoTaller = CT.idConfiguracionDocumentoTaller
			inner join RefaccionMultiMarca.[Catalogo].[ConfiguracionDetalleDocumentoTaller] Conf on Conf.idConfiguracionDocumentoTaller = CDT.idConfiguracionDocumentoTaller
			inner join RefaccionMultiMarca.Catalogo.DocumentoTaller DT on DT.idDocumentoTaller = Conf.idDocumentoTaller			
			WHERE Conf.requerido=1 and Conf.activo=1 and Conf.esObligatorio=1 and DT.esFactura=0 and DT.documento NOT IN(SELECT E.descripcionEvidencia from ASEPROT.dbo.Evidencias E where E.idOrdenServicio = FP.idOrden) and CT.idCotizacionTaller = FP.idCotizacionTaller
        FOR XML PATH('')) ,1,1,'') AS evidencias 
		from @facturasProveedor FP		
		
	update @doctosSubidosTable set doctosSubidos = doctosSubidos + case when (ISNULL((select top 1 1), 0)=1) then '' else ',Factura' end 
	from ASEPROT.dbo.facturaCotizacion  FC
	inner join @facturasProveedor FP on FP.idCotizacion = FC.idCotizacion

	UPDATE @doctosTable SET doctosSubidos = DST.doctosSubidos,fechaEvidenciaCompleta = (
	select MAX(fechaInicial) from ASEPROT.dbo.HistorialEstatusOrden where idOrden = DT.idOrden and idEstatusOrden = 8) FROM @doctosTable AS DT
			INNER JOIN @doctosSubidosTable DST on DST.idOrden = DT.idOrden	
	
	--select * from @doctosTable
	--select * from @doctosSubidosTable

	--Datos para actualizar cuentas por cobrar de ASE
	insert into @provisionBanorte
		select distinct FP.idOrden, FP.idCotizacionTaller, FP.numeroOrden, FP.numeroReclamo, AC.COP_IDDOCTO,
		convert(datetime, C.fechaContrarecibo, 103),
		dateadd(day,30,convert(datetime, C.fechaContrarecibo, 103)) as fechaPromesa, 
		C.numeroContraRecibo, convert(datetime, C.fechaContrarecibo, 103), CC.CCP_FECHADOCTO, FP.tipoOrden
	from @facturasProveedor FP
	left join [192.168.20.29].[GAAutoExpressBanorte].dbo.ADE_COPADE AC on FP.numeroOrden = AC.COP_ORDENGLOBAL COLLATE Modern_Spanish_CI_AS
	--left join [GAAutoExpressBanorte].dbo.ADE_COPADE AC on O.numeroOrden = AC.COP_ORDENGLOBAL COLLATE Modern_Spanish_CI_AS
	left join [192.168.20.29].[GAAutoExpressBanorte].dbo.[Con_Car012019] CC on AC.COP_IDDOCTO = CC.CCP_IDDOCTO and CC.CCP_TIPODOCTO='FAC'
	left join ASEPROT.dbo.DatosCopade D on D.numeroCopade = FP.numeroOrden
	left join [ASEPROT].[dbo].[ContrareciboDatosCopade] CDC on CDC.idDatosCopade = D.idDatosCopade
	left join [ASEPROT].[dbo].[Contrarecibo] C on C.idContrarecibo =CDC.idContrarecibo
	order by FP.numeroOrden	

	insert into @cuentasPorPagar  	
		select  FP.numeroReclamo, FP.idCotizacionTaller, MAX(PB.fechaPromesa), MAX(FP.facturaCeros), MAX(FP.servidor),
		'Factura' + case when CHARINDEX(',',MAX(FP.facturaComentarios), 0) > 0 then '(s)' else '' end +		
		' Agencia: ' + MAX(FP.facturaComentarios) + 
		'. Siniestro ' + FP.numeroReclamo  + ' Orden(es) ' 
		+ STUFF((SELECT ', ' + FP1.tipoOrden + ' ' + FP1.numeroOrden FROM @facturasProveedor FP1 
		WHERE FP1.idCotizacionTaller = FP.idCotizacionTaller FOR XML PATH('')), 1, 2, '') + ' «SISRE: Documentos: ' + 		 		
		CAST(MIN(DT.totalDoctosSubidos) as varchar(100))+ '/' + CAST(MIN(DT.totalDoctos) as varchar(100)) +
		case when MIN(DT.doctosSubidos) IS NOT NULL then ' Documentos faltantes: ' + MIN(DT.doctosSubidos) else '' end
		+ (CASE WHEN MIN(DT.fechaEvidenciaCompleta) is not null THEN '; Fecha Evidencia Completada: ' + 
		CONVERT(VARCHAR(10), MIN(DT.fechaEvidenciaCompleta), 103) ELSE '' END) + '; ' +
		--case when MIN(PB.facturaBanorte) IS NULL then 'NO Provisionada' else 
		STUFF((SELECT 
		case when MIN(PB.facturaBanorte) IS NULL then 'NO Provisionada' else 
		', Factura Banorte: ' + PB1.tipoOrden + ' ' + PB1.facturaBanorte end +
		case when MIN(PB.fechaFactura) IS NULL then '' else 
		'; Fecha: ' + convert(nvarchar(MAX), PB1.fechaFactura, 103) end +
		case when MIN(PB.contraRecibo) IS NULL then '' else 
		'; Contra Recibo: ' + PB1.tipoOrden + ' ' + PB1.contraRecibo end +
		case when MIN(PB.fechaContraRecibo) IS NULL then '' else 
		'; Fecha: ' + convert(nvarchar(MAX), PB1.fechaContraRecibo, 103) end
		FROM @provisionBanorte PB1 
		inner join @facturasProveedor FP2 on FP2.idOrden = PB1.idOrden
		WHERE FP2.idCotizacionTaller = FP.idCotizacionTaller FOR XML PATH('')), 1, 2, '') --end				
		 + '»', '', MAX(FP.facturaProveedor), FP.tipoOrden
	from @doctosTable DT
	inner join @facturasProveedor FP on FP.idCotizacionTaller = DT.idCotizacionTaller 
	left join @provisionBanorte PB on PB.idCotizacionTaller = FP.idCotizacionTaller
	group by FP.numeroReclamo, FP.idOrden, FP.tipoOrden, FP.idCotizacionTaller --FP.facturaProveedor, FP.facturaCeros, FP.servidor, DT.totalDoctosSubidos, DT.totalDoctos, DT.doctosSubidos, DT.fechaEvidenciaCompleta, PB.facturaBanorte, PB.contraRecibo
	order by FP.idOrden
	print ('DOC')
	select * from @doctosTable
	print ('PROVEEDOR')
	select * from @facturasProveedor
	print ('BANORTE')
	select * from @provisionBanorte
	print ('TODO')
	select * from @cuentasPorPagar order by numeroReclamo

print ('Cuentas Por Cobrar ASE')

--Declare @id int,
--        @count int

--Set @id=1
--select @count=count(*)from @provisionBanorte 
--declare @updateAutoExpressBan nvarchar(max)=''
--DECLARE @result nvarchar(100)
--DECLARE @facturaBanorte nvarchar(100)
--DECLARE @tablaConCar nvarchar(100)
--DECLARE @observacion nvarchar(max)
--DECLARE @fechaPromesa nvarchar(10)
--while @id<=@count
--begin	
--	select @updateAutoExpressBan = ''
--	select @facturaBanorte= facturaBanorte, @fechaPromesa = CONVERT(VARCHAR(15), fechaPromesa, 103) from @provisionBanorte where idProvision=@id

--	if( @facturaBanorte is not null or @facturaBanorte <> '')
--	begin 
--		EXECUTE ASEPROT.[Banorte].[GET_ANIO_FAC] @isProduction,@idContratoOperacion,@facturaBanorte, @result output	
--		if(@result<>0)
--		BEGIN
--			SELECT @tablaConCar = tabla FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@result			
--			select @observacion = '' + 'Siniestro ' + numeroReclamo + ' Orden ' + numeroOrden + 		
--				(case when contraRecibo is not null then '; Contra Recibo: ' +
--				contraRecibo  + ', Fecha: ' + convert(nvarchar(MAX), fechaContraRecibo, 103) 
--				else '' end ) from  @provisionBanorte where idProvision=@id
--				if(@fechaPromesa is not null or @fechaPromesa <> '')
--				begin 
--					select @updateAutoExpressBan = 'update '+@dbBanorte+'.dbo.'+@tablaConCar+'
--					set CCP_OBSGEN='''+@observacion+''', CCP_FECHPROMPAG='''+@fechaPromesa+
--					''' where CCP_TIPODOCTO = ''FAC'' and CCP_IDDOCTO='''+@facturaBanorte+''''
--				end 				
--				else 
--				begin 
--					select @updateAutoExpressBan = 'update '+@dbBanorte+'.dbo.'+@tablaConCar+'
--					set CCP_OBSGEN='''+@observacion+''' where CCP_TIPODOCTO = ''FAC'' and CCP_IDDOCTO='''+@facturaBanorte+''''
--				end 
--		END
--		print @updateAutoExpressBan
--		execute (@updateAutoExpressBan)
--	end	
--	select @id=@id+1	
--end 

print ('Cuentas Por Cobrar Agencia y Cuentas por Pagar ASE')
---------------------------------ACTUALIZAR CUENTAS POR PAGAR -----------------
--Set @id=1
--select @count=count(*)from @cuentasPorPagar
--declare @update nvarchar(max) =''
--declare @updateBanorte nvarchar(max) =''
--declare @query nvarchar(max) =''
--declare @query2 nvarchar(max) =''
--declare @anio nvarchar(20) = '', @nuevaFactura nvarchar(100) =''

--declare @anioB nvarchar(20) = ''
--declare @resA bit=0;
--while @id<=@count
--begin	
--	select @anio='2019', @query='', @query2='', @nuevaFactura='', @update='', @updateBanorte=''
--	if((select facturaProveedor from @cuentasPorPagar where idCuenta=@id) <>'')
--	begin		
--			update @cuentasPorPagar set tablaProveedor = (select tabla FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio)
--			where idCuenta=@id
--			IF(@isProduction = 1)		
--					SELECT @dbProveedor=server+'.'+db FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio			
--			ELSE			
--				SELECT @dbProveedor=db FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio								

--			if((select servidor from @cuentasPorPagar where idCuenta=@id) is not null and (select tablaProveedor from @cuentasPorPagar where idCuenta=@id) is not null and (select fechaPromesa from @cuentasPorPagar where idCuenta=@id) is not null)
--				begin		
--					select @update =  '  update ' + (select servidor from @cuentasPorPagar where idCuenta=@id) + + '.dbo.' + (select tablaProveedor from @cuentasPorPagar where idCuenta=@id ) + 
--					' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + ''', CCP_FECHPROMPAG= ''' +
--					CONVERT(VARCHAR(15), (select fechaPromesa from @cuentasPorPagar where idCuenta=@id), 103)  +
--					''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO in (' + (select facturaProveedor from @cuentasPorPagar where idCuenta=@id) + ')  '	

--					select @updateBanorte ='  update '+@dbProveedor+'.dbo.'+(select tablaProveedor from @cuentasPorPagar where idCuenta=@id) +
--					' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + ''', CCP_FECHPROMPAG= ''' +
--					CONVERT(VARCHAR(15), (select fechaPromesa from @cuentasPorPagar where idCuenta=@id), 103)  +
--					''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO in (' + (select facturasinCeros from @cuentasPorPagar where idCuenta=@id)  + ') '	
--				end
--			else
--				begin 		
--					if((select servidor from @cuentasPorPagar where idCuenta=@id) is not null and (select tablaProveedor from @cuentasPorPagar where idCuenta=@id) is not null)		
--						begin
--							select @update = '  update ' + (select servidor from @cuentasPorPagar where idCuenta=@id) + '.dbo.' + (select tablaProveedor from @cuentasPorPagar where idCuenta=@id )+
--							 ' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + 
--							 ''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO in (' + (select facturaProveedor from @cuentasPorPagar where idCuenta=@id) + ')  '	

--							select @updateBanorte = '  update  '+@dbProveedor+'.dbo.'+(select tablaProveedor from @cuentasPorPagar where idCuenta=@id) +
--							 ' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + 
--							 ''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO in (' + (select facturasinCeros from @cuentasPorPagar where idCuenta=@id) + ')  '	
--						end 
--				end										
--		print @update
--		print @updateBanorte
--		execute (@update)
--		execute(@updateBanorte)
--	end	
--	select @id=@id+1	
--	end


	
	--select * from @provisionBanorte

END
go

