


-- =============================================
-- Description:	Obtiene las ordenes de servicio en proceso es decir que no esten canceladas o finalizadas
-- =============================================
-- [SEL_ORDENES_CALLCENTER_SP] @idUsuario = 120, @idContratoOperacion = 57, @tipo=0, @idRol=2

CREATE PROCEDURE [dbo].[SEL_ORDENES_CALLCENTER_SP]
	@idUsuario NUMERIC(18,0) = NULL,
	@idContratoOperacion NVARCHAR(50) = 1,
	@tipo NUMERIC(18,0) = 0,
	@idRol INT

AS
BEGIN
		--SET TRANSACTION ISOLATION LEVEL READ COMMITTED
		SET NOCOUNT ON
		SET DATEFORMAT DMY;

		DECLARE @tipoUsuario INT
		DECLARE @preLibera BIT

		SELECT @tipoUsuario=idCatalogoTipoUsuarios FROM Usuarios WHERE idUsuario=@idUsuario
		--SELECT idCatalogoTipoUsuarios FROM Usuarios WHERE idUsuario=127

		IF(@tipoUsuario = 2)
			SET @idUsuario = 168

		DECLARE @idOpe INT = (SELECT idOperacion FROM ContratoOperacion WHERE idContratoOperacion = @idContratoOperacion)

		SELECT @preLibera = preAprobacion FROM Operaciones WHERE idOperacion = @idOpe
		--SELECT preAprobacion FROM Operaciones WHERE idOperacion = 3

		DECLARE @idCOU NUMERIC(18,0) = [dbo].[GET_CONTRATO_OPERACION_USR_FN](@idUsuario,@idOpe)
		DECLARE @zonasAsignadas TABLE (idZona INT)
		IF(@idRol = 3 OR @idRol = 2)
			BEGIN
			--PRINT @idUsuario
			--PRINT @idRol
			--PRINT @idCOU
				INSERT INTO @zonasAsignadas 
				SELECT idZona FROM [dbo].[GET_ZONAS_USR_FN](@idCOU)
				--SELECT * FROM @zonasAsignadas
			END
		ELSE IF(@idRol = 9)
			BEGIN

				INSERT INTO @zonasAsignadas
				SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
					JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
					JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
				WHERE EG.estatus=0 AND EZ.estatus=0 
				AND COUG.idContratoOperacionUsuario=@idCOU AND EZ.idContratoOperacion= @idContratoOperacion

			END

		IF (@preLibera = 1)
			BEGIN
				IF @tipo = 0 -- CON ATRASO
					BEGIN
						SELECT * FROM (
							SELECT 
								O.idOrden AS consecutivo,
								O.consecutivoOrden,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O WITH (NOLOCK)
							LEFT JOIN [dbo].[VwStatusBpro] BPRO WITH (NOLOCK) ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO WITH (NOLOCK) ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z WITH (NOLOCK) ON Z.idZona = O.idZona
							LEFT JOIN Acciones A WITH (NOLOCK) ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							JOIN HistorialEstatusOrden HEO WITH (NOLOCK) ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (1,2,3,6,7,8)--4,5,
							AND O.idZona IN (select idZona from @zonasAsignadas)) X
						UNION
						SELECT * FROM (
							SELECT DISTINCT
								O.idOrden AS consecutivo,
								O.consecutivoOrden,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O WITH (NOLOCK)
							LEFT JOIN [dbo].[VwStatusBpro] BPRO WITH (NOLOCK) ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO WITH (NOLOCK) ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z WITH (NOLOCK) ON Z.idZona = O.idZona
							LEFT JOIN Acciones A WITH (NOLOCK) ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							INNER JOIN Preaprobacion PA WITH (NOLOCK) ON PA.idCotizacion in (select idCotizacion from Cotizaciones where idOrden = O.idOrden)
							JOIN HistorialEstatusOrden HEO WITH (NOLOCK) ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (4,5)
							AND O.idZona IN (select idZona from @zonasAsignadas)) X

					END

				IF @tipo = 1 -- CON ATRASO
					BEGIN
						SELECT * FROM (
							SELECT 
								O.idOrden AS consecutivo,
								O.consecutivoOrden,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O WITH (NOLOCK)
							LEFT JOIN [dbo].[VwStatusBpro] BPRO WITH (NOLOCK) ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO WITH (NOLOCK) ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z WITH (NOLOCK) ON Z.idZona = O.idZona
							LEFT JOIN Acciones A WITH (NOLOCK) ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							JOIN HistorialEstatusOrden HEO WITH (NOLOCK) ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (1,2,3,6,7,8)--4,5,
							AND O.idZona IN (select idZona from @zonasAsignadas)) X
							WHERE horasTranscurrido > 24

						UNION
						SELECT * FROM (
							SELECT DISTINCT
								O.idOrden AS consecutivo,
								O.consecutivoOrden,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O
							LEFT JOIN [dbo].[VwStatusBpro] BPRO ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							INNER JOIN Preaprobacion PA ON PA.idCotizacion in (select idCotizacion from Cotizaciones WITH (NOLOCK) where idOrden = O.idOrden)
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (4,5)
							AND O.idZona IN (select idZona from @zonasAsignadas)) X
							WHERE horasTranscurrido > 24

					END

				IF @tipo = 2 -- PARA HOY
					BEGIN
						SELECT * FROM (
							SELECT 
								O.idOrden AS consecutivo,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								O.consecutivoOrden,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O WITH (NOLOCK)
							LEFT JOIN [dbo].[VwStatusBpro] BPRO ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (1,2,3,6,7,8)--4,5,
							AND O.idZona IN (select idZona from @zonasAsignadas)) X
							WHERE horasTranscurrido <= 24

						UNION
						SELECT * FROM (
							SELECT DISTINCT
								O.idOrden AS consecutivo,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								O.consecutivoOrden,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O
							LEFT JOIN [dbo].[VwStatusBpro] BPRO ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							INNER JOIN Preaprobacion PA ON PA.idCotizacion in (select idCotizacion from Cotizaciones WITH (NOLOCK) where idOrden = O.idOrden)
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (4,5)
							AND O.idZona IN (select idZona from @zonasAsignadas)) X
							WHERE horasTranscurrido <= 24

					END

				IF @tipo = 3 -- SIN PLAN DE ACCIÓN
					BEGIN
						SELECT * FROM (
							SELECT 
								O.idOrden AS consecutivo,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								O.consecutivoOrden,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O WITH (NOLOCK)
							LEFT JOIN [dbo].[VwStatusBpro] BPRO ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z WITH (NOLOCK) ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (1,2,3,6,7,8)--4,5,
							AND O.idZona IN (select idZona from @zonasAsignadas)
							AND A.texto IS NULL) X

						UNION
						SELECT * FROM (
							SELECT DISTINCT
								O.idOrden AS consecutivo,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								O.consecutivoOrden,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O
							LEFT JOIN [dbo].[VwStatusBpro] BPRO ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							INNER JOIN Preaprobacion PA ON PA.idCotizacion in (select idCotizacion from Cotizaciones WITH (NOLOCK) where idOrden = O.idOrden)
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (4,5)
							AND O.idZona IN (select idZona from @zonasAsignadas)
							AND A.texto IS NULL) X

					END
			END
		ELSE
			BEGIN
				IF @tipo = 0 -- CON ATRASO
					BEGIN
						SELECT  * FROM (
							SELECT 
								O.idOrden AS consecutivo,
								O.consecutivoOrden,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--'prueba' as comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O WITH (NOLOCK)
							LEFT JOIN [dbo].[VwStatusBpro] BPRO WITH (NOLOCK) ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO WITH (NOLOCK) ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (1,2,3,4,5,6,7,8)
							AND O.idZona IN (select idZona from @zonasAsignadas)) X
					END

				IF @tipo = 1 -- CON ATRASO
					BEGIN
						SELECT * FROM (
							SELECT 
								O.idOrden AS consecutivo,
								O.consecutivoOrden,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O
							LEFT JOIN [dbo].[VwStatusBpro] BPRO ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (1,2,3,4,5,6,7,8)
							AND O.idZona IN (select idZona from @zonasAsignadas)) X
							WHERE horasTranscurrido > 24
					END

				IF @tipo = 2 -- PARA HOY
					BEGIN
						SELECT * FROM (
							SELECT 
								O.idOrden AS consecutivo,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								O.consecutivoOrden,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O WITH (NOLOCK)
							LEFT JOIN [dbo].[VwStatusBpro] BPRO ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (1,2,3,4,5,6,7,8)
							AND O.idZona IN (select idZona from @zonasAsignadas)) X
							WHERE horasTranscurrido <= 24

					END

				IF @tipo = 3 -- SIN PLAN DE ACCIÓN
					BEGIN
						SELECT * FROM (
							SELECT 
								O.idOrden AS consecutivo,
								O.numeroOrden,
								[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
								--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' and O.idEstatusOrden in (1,2,3,4) THEN 1
								--ELSE 0 END
								--AS aplicaFondo,
								CASE WHEN @idContratoOperacion IN(37,19,17,55) AND O.idEstatusOrden IN (5,6,7) 
								AND (SELECT COUNT(*) FROM BitacoraAvisoEntrega where idorden=O.idOrden)=0 THEN 1 ELSE 0 END AS aplicaEnvio,
								O.consecutivoOrden,
								Z.nombre,
								(select [dbo].[SEL_TALLERES_ORDEN_FN] (o.idOrden)) as Taller,
								--(select [dbo].[SEL_STATUS_PROVISION_BPRO_FN] (O.idOrden)) AS EstatusProvision,
								CASE WHEN ISNULL(BPRO.estatusBpro,'')<>'' THEN 'PROVISIONADO' ELSE 'NO PROVISIONADO' END AS EstatusProvision,
								(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) costo,
								(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
									FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
									INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
									INNER JOIN [dbo].[Ordenes] ORD WITH (NOLOCK) ON C.idOrden = ORD.idOrden
									INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON ORD.idContratoOperacion = CO.idContratoOperacion
								WHERE ORD.idOrden = O.idOrden 
								AND CO.idContratoOperacion = @idContratoOperacion
								AND CD.idEstatusPartida IN(1,2) 
								AND C.idEstatusCotizacion IN(1,2,3)) venta,
								REPLACE(REPLACE(O.comentarioOrden, '>',''), '<','') comentarioOrden,--O.comentarioOrden,
								EO.nombreEstatusOrden,
								A.texto,
								HEO.fechaInicial,
								DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
								[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
								DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
							FROM Ordenes O WITH (NOLOCK)
							LEFT JOIN [dbo].[VwStatusBpro] BPRO ON BPRO.numeroOrden=O.numeroOrden
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
							JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
							WHERE O.idContratoOperacion = @idContratoOperacion 
							AND O.idEstatusOrden IN (1,2,3,4,5,6,7,8)
							AND O.idZona IN (select idZona from @zonasAsignadas)
							AND A.texto IS NULL) X
					END
			END

			SET NOCOUNT OFF
END

	/*SET @select = 'SELECT 
						isnull(A.idAccion,0) as idAccion,
						isnull(A.texto,'''') as texto,
						isnull(A.fecha, getdate()) as fecha,
						isnull(A.idEstatusAccion,0) as idEstatusAccion,
						isnull(A.idUsuario,0) as idUsuario,
						OD.idOrden,
						isnull(A.fechaAlta,getdate()) as fechaAlta,
						isnull(EA.nombreEstatusAccion,'''') as nombreEstatusAccion,
						OD.fechaCreacionOden,
						OD.fechaCita,
						OD.numeroOrden,
						OD.consecutivoOrden,
						OD.comentarioOrden,
						Z.nombre,
						(SELECT [dbo].[diferenciaTiempo] (isnull(A.fecha,getdate()))) tiempo,	
						(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C 
							INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = OD.idOrden
						AND (NOT (O.idEstatusOrden = 13))
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3)) AS costo,
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C 
							INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = OD.idOrden
						AND (NOT (O.idEstatusOrden = 13))
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3)) AS venta,
							EO.nombreEstatusOrden		
				FROM Ordenes OD
				LEFT JOIN Acciones A  ON OD.idOrden = A.idOrden and OD.idEstatusOrden = A.idEstatusOrden
				LEFT JOIN EstatusAccion EA ON EA.idEstatusAccion = A.idEstatusAccion
				LEFT JOIN Usuarios U ON U.idUsuario = A.idUsuario
				LEFT JOIN Partidas.dbo.Zona Z ON Z.idZona = OD.idZona
				LEFT JOIN Partidas.dbo.NivelZona NZ ON NZ.idNivelZona = Z.idNivelZona
				LEFT JOIN EstatusOrdenes EO ON EO.idEstatusOrden = OD.idEstatusOrden 
				WHERE OD.idZona in(SELECT z.idZona 
							FROM ContratoOperacionUsuarioZona z 
							join ContratoOperacionUsuario c on z.idContratoOperacionUsuario = c.idContratoOperacionUsuario  
							where c.idUsuario= '+convert(varchar(max),@idUsuario) +') 
					AND OD.idContratoOperacion = ' +convert(varchar(max),@idContratoOperacion)+
					' AND OD.idEstatusOrden NOT IN (12, 13)'*/
--GO
--USE [ASEPROT]
go

grant execute, view definition on SEL_ORDENES_CALLCENTER_SP to DevOps
go

