
--
-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Description:	valida utilidad
-- [SEL_VALIDA_UTILIDAD_SP]
-- =============================================

  CREATE PROCEDURE [dbo].[SEL_VALIDA_UTILIDAD_SP]
 @idOrden int = NULL


AS
BEGIN
	

		IF  EXISTS (SELECT idAprobacionUtilidad FROM [AprobacionesUtilidad] WHERE idOrden = @idOrden)
			BEGIN
				SELECT tOP 1 idAprobacionUtilidad, margenAprobacion, estatusAprobacion 
					FROM [AprobacionesUtilidad]
					WHERE idOrden = @idOrden ORDER BY fechaAprobacion DESC
			END
		ELSE
			BEGIN
				SELECT 0 AS idAprobacionUtilidad 
			END 

			
END

go

