-- =============================================
-- Author:		<YJH>
-- Create date: <29/06/2018>
-- Description:	<Consulta el número de orden de BPro>
-- [Banorte].[SEL_ORDEN_BPRO] '26-11960-155', 1, 26
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_ORDEN_BPRO] 
	@numOrden varchar(max),
	@isProduction int, 
	@idContratoOperacion int 
AS
BEGIN
	DECLARE @Base NVARCHAR(MAX) = '', 
			@idEncabezado numeric(18,0)=0	
		
IF(@isProduction = 1)
    BEGIN
        SELECT                 
               @Base= SERVER+'.'+DBProduccion                
        FROM ASEPROT.dbo.ContratoOperacionFacturacion 
        WHERE idContratoOperacion =  @idContratoOperacion
    END
ELSE
    BEGIN
        SELECT 
                @Base=DB
        FROM ASEPROT.dbo.ContratoOperacionFacturacion
		WHERE idContratoOperacion = @idContratoOperacion
	END
	
	DECLARE @query NVARCHAR(MAX) = ''
	SET @query = '
	DECLARE @values varchar(max) = '''';
	select @values = COALESCE(@values + '', '', '''') +  CAST(OTE_IDENT AS varchar(max)) '+ 
	'from '+@Base+'.dbo.ADE_ORDSERENC where OTE_ORDENANDRADE =  ''' + convert(nvarchar(max),@numOrden) + ''''+
	'select @values= STUFF(@values, 1, 1, '''')'+
	'select @values as idEncabezado'+''

	print @query

	EXECUTE SP_EXECUTESQL @query	

END
go

grant execute, view definition on Banorte.SEL_ORDEN_BPRO to DevOps
go

