
-- ==========================================================================================
-- Author:		Jordan Gomez
-- Create date: 09/10/2017
-- Description:	Store que registra los datos de la COPADE
-- ==========================================================================================

CREATE PROC [dbo].[INS_DATOS_COPADE_SIN_XML_SP]
	@idContratoOperacion DECIMAL(18,0),
	@fechaRecepcionCopade NVARCHAR(20) = NULL
	
AS
	BEGIN
	DECLARE @subTotal DECIMAL(18,2) = 10000000,--L
		@total DECIMAL(18,2) = 10000000,	--L
		@moneda NVARCHAR(20) = 'MXN',	--L
		@cantidad DECIMAL(18,4) = 1,	--L
		@descripcion NVARCHAR(250),	--L
		@importeConcepto DECIMAL(18,2) = 10000000, --L
		@unidad NVARCHAR(50) = 'SER', --L
		@valorUnitario DECIMAL(18,2) = 10000000, --L
		@totalImpuestosRetenidos DECIMAL(18,2) = 0,	--L
		@totalImpuestosTrasladados DECIMAL(18,2) = 0, --L
		@impuesto NVARCHAR(30) = 'IVA',	--L
		@importeTraslado DECIMAL(18,2) = 0, --L
		@tasa DECIMAL(18,2) = 16, --L	
		@contrato NVARCHAR(150), --L
		@ordenSurtimiento NVARCHAR(250), --L
		@numeroEstimacion NVARCHAR(250) = '', --L
		@numeroAcreedor NVARCHAR(200) = NULL,
		@gestor NVARCHAR(150) = NULL,
		@finiquito NVARCHAR(150) = 0,	
		@posicionap NVARCHAR(150) = NULL,
		@numeroCopade NVARCHAR(250),
		@ejercicio NVARCHAR(150) = NULL,
		@xmlCopade NVARCHAR(MAX) = ''
		
		SET @numeroEstimacion = (SELECT IDENT_CURRENT('DatosCopade')+1)
		SET @ordenSurtimiento = CONVERT(nvarchar(10),@idContratoOperacion)

		IF(@idContratoOperacion = 32)
			BEGIN
				SET @numeroEstimacion = ('PF-' + @numeroEstimacion)
			END
		ELSE IF(@idContratoOperacion = 44)
			BEGIN
				SET @numeroEstimacion = ('TOTALPLAY-' + @numeroEstimacion)
			END
		ELSE IF(@idContratoOperacion = 36)
			BEGIN
				SET @numeroEstimacion = ('FLOTADHL-' + @numeroEstimacion)
			END
		ELSE IF(@idContratoOperacion = 50)
			BEGIN
				SET @numeroEstimacion = ('F-INLOD-' + @numeroEstimacion)
			END
		ELSE IF(@idContratoOperacion = 51)
			BEGIN
				SET @numeroEstimacion = ('F-FANAFESA-' + @numeroEstimacion)
			END
		ELSE IF(@idContratoOperacion = 53)
			BEGIN
				SET @numeroEstimacion = ('F-FANASA-' + @numeroEstimacion)
			END
		ELSE IF(@idContratoOperacion = 54)
			BEGIN
				SET @numeroEstimacion = ('F-FESA-' + @numeroEstimacion)
			END
		ELSE IF(@idContratoOperacion = 56)
			BEGIN
				SET @numeroEstimacion = ('P-BCSTOTALPARTS-' + @numeroEstimacion)
			END

		SET @numeroCopade = @numeroEstimacion
		select @descripcion = CLI.nombreComercial, @contrato = PC.numero
        from ContratoOperacion CO 
        inner join Partidas..Contrato PC on CO.idContrato = PC.idContrato
        inner join Partidas..Licitacion L on L.idLicitacion = PC.idLicitacion
        inner join Partidas..Cliente CLI on CLI.idCliente = L.idCliente
        where CO.idContratoOperacion=@idContratoOperacion
        group by CLI.nombreComercial, PC.numero, CO.idContratoOperacion
		--print @descripcion
		--print @contrato
		--print @ordenSurtimiento
		--print @idCO
			

		INSERT INTO DatosCopade(
						subTotal,
						total,
						moneda,
						cantidad,
						descripcion,
						importeConcepto,
						unidad,
						valorUnitario,
						totalImpuestosRetenidos,
						totalImpuestosTrasladados,
						impuesto,
						importeTraslado,
						tasa,
						contrato,
						ordenSurtimiento,
						numeroEstimacion,
						numeroAcreedor,
						gestor,
						finiquito,
						posicionap,
						numeroCopade,
						ejercicio,
						fechaCarga,
						fechaRecepcionCopade,
						xmlCopade,
						idContratoOperacion)
						VALUES
						(
						@subTotal,
						@total,	
						@moneda,	
						@cantidad,	
						@descripcion,	
						@importeConcepto,	
						@unidad,	
						@valorUnitario,
						@totalImpuestosRetenidos,	
						@totalImpuestosTrasladados,	
						@impuesto,	
						@importeTraslado,
						@tasa,	
						@contrato,
						@ordenSurtimiento,	
						@numeroEstimacion,	
						@numeroAcreedor,	
						@gestor,
						@finiquito,	
						@posicionap,
						@numeroCopade,
						@ejercicio,
						GETDATE(),
						@fechaRecepcionCopade,
						@xmlCopade,
						@idContratoOperacion
						)
			SELECT id = @@IDENTITY 
	END
go

