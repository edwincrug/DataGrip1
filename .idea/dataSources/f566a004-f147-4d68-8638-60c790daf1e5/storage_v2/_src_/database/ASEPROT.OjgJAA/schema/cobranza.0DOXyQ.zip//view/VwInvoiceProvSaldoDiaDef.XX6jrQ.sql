
CREATE VIEW [cobranza].[VwInvoiceProvSaldoDiaDef]
AS
SELECT [NumFactura]
      ,sum([DeudaDia]) as [DeudaDia]
  FROM [ASEPROT].[cobranza].[VwInvoiceProvSaldoDiaBase]
  group by [NumFactura]

go

