-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 25/05/2017
-- Description:	Obtiene el catalogo de modulos operativos
-- SEL_CATALOGO_MODULOS_SP @idOperacion=3, @tipo='ADI'
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_CATALOGO_MODULOS_SP]
	@idOperacion INT,
	@tipo NVARCHAR(50)
AS
BEGIN
	IF @tipo = 'Default'	
		BEGIN
		  IF NOT EXISTS (SELECT idOperacion FROM Modulos WHERE idOperacion = @idOperacion) 
			BEGIN
			  INSERT INTO Modulos
			  SELECT idCatalogoModulos, @idOperacion FROM catalogoModulos WHERE tipoModulo = 'Default'
			END

		  SELECT M.idModulo, CM.idCatalogoModulos, CM.nombreModulos 
			FROM Modulos M 
		    INNER JOIN catalogoModulos CM ON M.idCatalogoModulo = CM.idCatalogoModulos
			WHERE  M.idOperacion = @idOperacion AND CM.tipoModulo = @tipo
		END
	ELSE
		BEGIN
			SELECT *,CASE WHEN (M.idOperacion = @idOperacion) THEN 'true' ELSE 'false' END as verificar 
			FROM CatalogoModulos CM
			LEFT JOIN Modulos M ON M.idCatalogoModulo = CM.idCatalogoModulos and M.idOperacion = @idOperacion
			WHERE tipoModulo = 'Adicional'
		END
END



go

