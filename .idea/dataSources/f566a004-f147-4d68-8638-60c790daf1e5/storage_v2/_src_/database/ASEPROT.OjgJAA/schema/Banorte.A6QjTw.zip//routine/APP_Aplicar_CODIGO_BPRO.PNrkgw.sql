/*
 Objetivo: Guardar los códigos cangeados desde bPro

 Fecha			Autor   Descripción
 06-Jul-2018	José Etmanuel Se crea el SP para aplicar codigo de promoción desde BPro
 31-Jul-2018	José Etmanuel Cambio la salida por una variable OUTPUT
 
 declare @ok int;
 EXEC [Banorte].[APP_Aplicar_CODIGO_BPRO] 816765,'N0023032','AUN14022117H9',@ok OUTPUT
 SELECT @ok status

*/


CREATE PROCEDURE [Banorte].[APP_Aplicar_CODIGO_BPRO] 
 @codigo varchar(max),
 @idOrdenBpro varchar(max),
 @RFCAgencia varchar(max),
 @status int OUTPUT 
AS   
BEGIN
 declare @sobran int = 0,
   @mensaje varchar(max)= 'Código invalido',
   @idCanjeo int = 0,
   @idPoliza varchar(50)
   ;
 SET @status = 0;

 IF EXISTS (SELECT TOP 1 * FROM [dbo].[PromocionesCodigos] WHERE  [Codigo]= @codigo)
 BEGIN

  SELECT TOP 1 @sobran= ISNULL([NumeroMaximo] - [Aplicadas],0), @idPoliza = [IdPoliza]
  FROM [PromocionesCodigos] AS PC
  INNER JOIN [Banorte].[Promociones] as P on P.id = PC.IdPromocion
  WHERE [Codigo] = @codigo
  AND Aplicadas<NumeroMaximo
  AND P.fechaTermino >= GETDATE()

  IF @sobran >0
  BEGIN
   
   UPDATE [PromocionesCodigos] 
    SET [Aplicadas] = ([Aplicadas] +1)
    WHERE [Codigo]= @codigo

  
   SET @mensaje = 'Código válido, APLICADO';
   SET @status = 1;
  
   SELECT TOP 1 @idCanjeo = isnull(id,0) 
    FROM [Banorte].[PromocionesCodigosDet] 
    WHERE  [Codigo]= @codigo
   ORDER BY id DESC

   
   INSERT INTO [Banorte].[PromocionesCodigosDet]
    ([Codigo],[IdPoliza],[Id],[PatrocinadorId],[IdSucursales],[FechaCanjeo],[IpCanje],[IdOrdenBpro],[RFCagencia])
    VALUES (@codigo,@idPoliza,(@idCanjeo +1),0,0,GETDATE(),(SELECT TOP 1 client_net_address FROM sys.dm_exec_connections WHERE session_id = @@SPID),@idOrdenBpro,@RFCAgencia)

   SET @sobran = @sobran -1
  END
 END
 RETURN 0
 -- Select @status as status, @mensaje as msg,  @sobran as sobran;
END
go

grant execute, view definition on Banorte.APP_Aplicar_CODIGO_BPRO to DevOps
go

