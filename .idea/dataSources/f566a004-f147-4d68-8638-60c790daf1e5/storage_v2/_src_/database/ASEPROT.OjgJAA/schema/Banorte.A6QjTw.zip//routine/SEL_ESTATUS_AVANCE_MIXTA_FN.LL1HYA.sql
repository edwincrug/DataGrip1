-- =============================================
-- Author:		<YJH>
-- Create date: <25/06/2018>
-- Description:	<Verifca que la orden de servicio tenga factura y vale de surtimiento>
--39137, 39138, 39139, 39145
/*
declare @hasFactura int, @hasDocumentos int
 EXECUTE [Banorte].[SEL_ESTATUS_AVANCE_MIXTA_FN] 42108, @hasFactura output, @hasDocumentos output
		select @hasFactura as hasFactura, @hasDocumentos as hasDocumentos*/
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_ESTATUS_AVANCE_MIXTA_FN] 
	@idOrden NUMERIC,	
	@hasFactura NUMERIC output,
	@hasDocumentos NUMERIC output
AS
BEGIN
	declare @totalDocumentos int =0
	declare @documentosIngresados int =0

	--select @totalDocumentos=count(*) from RefaccionMultiMarca.Catalogo.DocumentoTaller where requerido=1 and activo=1 and esObligatorio=1 and esFactura=0 -- 13
	select @totalDocumentos=count(*) from RefaccionMultiMarca.Operacion.CotizacionTaller CT
	inner join RefaccionMultiMarca.[Catalogo].[ConfiguracionDocumentoTaller] CDT on CDT.idConfiguracionDocumentoTaller = CT.idConfiguracionDocumentoTaller
	inner join RefaccionMultiMarca.[Catalogo].[ConfiguracionDetalleDocumentoTaller] Conf on Conf.idConfiguracionDocumentoTaller = CDT.idConfiguracionDocumentoTaller
	inner join RefaccionMultiMarca.Catalogo.DocumentoTaller DT on DT.idDocumentoTaller = Conf.idDocumentoTaller
	where (CT.idOrden=@idOrden OR CT.idOrdenRefaccion = @idOrden) and  Conf.requerido=1 and Conf.activo=1 and Conf.esObligatorio=1 and DT.esFactura=0 -- 13

	select @documentosIngresados=count(*) from Evidencias E --where idOrdenServicio=40296
		inner join RefaccionMultiMarca.Catalogo.DocumentoTaller DT on DT.documento = E.descripcionEvidencia and DT.requerido=1
		and DT.activo=1 and DT.esObligatorio=1
	where E.idOrdenServicio=@idOrden 
	
	if(@documentosIngresados >= @totalDocumentos)
		select @hasDocumentos=1
	else 
		select @hasDocumentos=0
	
	SELECT @hasFactura= MIN([dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](ORD.idOrden,3,COTI.ConsecutivoCotizacion))	
	from Ordenes ORD 
		INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden and COTI.idEstatusCotizacion <> 4
	where ORD.idOrden= @idOrden

return @hasFactura
return @hasDocumentos 
END
go

grant execute, view definition on Banorte.SEL_ESTATUS_AVANCE_MIXTA_FN to DevOps
go

