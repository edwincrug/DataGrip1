
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- SEL_COTIZACIONES_ORDEN_BY_FOLIO_SP 527,6, 38
-- =============================================
CREATE PROCEDURE [dbo].[SEL_COTIZACIONES_ORDEN_BY_FOLIO_SP]
		@idUsuario INT,  
		@idContratoOperacion INT,
		@idFolio	numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	/*
	select 
		*
	from FolioOrden fo
	inner join Ordenes o on o.idOrden = fo.idOrden
	where idFolio = @idFolio*/


	DECLARE @idOperacion int = (select idOperacion from ContratoOperacion where idContratoOperacion = @idContratoOperacion) 



  
 DECLARE @query NVARCHAR(MAX) = ''  
 DECLARE @where NVARCHAR(MAX) = ''  
 -- IF (@estatusOrden != 4)  
 
   SET @query='SELECT COTI.* '  
 
  
 IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 4  
  BEGIN  
   SET @where = ' '  
  END  
 ELSE  
  BEGIN  
   SET @where = ' AND COTI.idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+CONVERT(varchar(10), @idUsuario)+', '+CONVERT(varchar(10), @idOperacion)+')) '  
  END  
   
   SET @query= @query + ',(SELECT [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](ORD.idOrden,3,COTI.ConsecutivoCotizacion)) AS factura,   
     ORD.idTaller AS idTaller,
	 ORD.numeroOrden as numeroOrden,
	 u.vin as VIN,
	 u.combustible as combustible,
	 u.modelo as modelo,
	 tp.tipo + '' ' + ''' + u.numeroEconomico as unidad, 
	 m.nombre as marca,
	 sm.nombre as subMarca,
	 cil.cilindros as cilindros,
	 convert(nvarchar,coti.fechaCotizacion, 103) fechaCreacion,
     P.nombreComercial AS nombreTaller,  
     P.razonSocial AS razonSocial,  
     P.direccion AS direccion,  
     ISNULL(Z.nombre, '''') AS nombreZona,  
     USU.nombreCompleto,  
     EC.nombreEstatusCotizacion AS nombreEstatusCotizacion,  
     (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0)   
      FROM [dbo].[Cotizaciones] C        INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion         INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.
idContratoOperacion  
     WHERE C.idCotizacion = COTI.idCotizacion  
     AND CD.idEstatusPartida IN(1,2)) AS sumaCosto,  
	 (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0)   
      FROM [dbo].[Cotizaciones] C        INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion         INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.
idContratoOperacion  
     WHERE C.idCotizacion = COTI.idCotizacion  
     AND CD.idEstatusPartida IN(1,2)) * [dbo].[fnFactorIVA_Orden](ORD.idOrden ,0) as IVA,
	 (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0)   
      FROM [dbo].[Cotizaciones] C        INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion         INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.
idContratoOperacion  
     WHERE C.idCotizacion = COTI.idCotizacion  
     AND CD.idEstatusPartida IN(1,2)) * 1.16 as total,
     (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
      FROM [dbo].[Cotizaciones] C        INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion         INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.
idContratoOperacion  
     WHERE C.idCotizacion = COTI.idCotizacion  
     AND CD.idEstatusPartida IN(1,2)) AS sumaVenta,  
     (select nombreCentroTrabajo from CentroTrabajos where idCentroTrabajo= ORD.idCentroTrabajo ) centroTrabajo  
   FROM [dbo].[Ordenes] ORD  
     INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden  
	 INNER JOIN [dbo].[Unidades] u on u.idUnidad = ORD.idUnidad
	 inner join [Partidas].[dbo].[Unidad] pu on pu.idUnidad = u.idTipoUnidad
	 inner join [Partidas].[dbo].[TipoUnidad] tp on tp.idTipoUnidad = pu.idTipoUnidad
	 inner join [Partidas].[dbo].[SubMarca] sm on sm.idSubMarca = pu.idSubMarca
	 inner join [Partidas].[dbo].[Marca] m on m.idMarca = sm.idMarca
	 inner join [Partidas].[dbo].[Cilindros] cil on cil.idCilindros = pu.idCilindros
     INNER JOIN [dbo].[Usuarios] USU ON COTI.idUsuario = USU.idUsuario  
     INNER JOIN [dbo].[EstatusCotizaciones] EC ON EC.idEstatusCotizacion = COTI.idEstatusCotizacion  
     LEFT JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = COTI.idTaller  
     LEFT JOIN [Partidas].[dbo].[Zona] Z ON Z.idZona = ORD.idZona  
   WHERE ORD.numeroOrden in( select numeroOrden from Ordenes o inner join folioorden fo on fo.idOrden = o.idOrden where fo.idFolio = ' + convert(varchar,@idFolio) + 
   ' ) AND COTI.idEstatusCotizacion in ( select case when idEstatusOrden = 8 then 3 else idEstatusOrden end from Ordenes o inner join folioorden fo on fo.idOrden = o.idOrden where fo.idFolio = ' + convert(varchar,@idFolio) + ' )' + @where + '  
   ORDER BY ORD.idOrden, COTI.[consecutivoCotizacion] ASC'  
  --print @query
  EXECUTE(@query)  
END

go

