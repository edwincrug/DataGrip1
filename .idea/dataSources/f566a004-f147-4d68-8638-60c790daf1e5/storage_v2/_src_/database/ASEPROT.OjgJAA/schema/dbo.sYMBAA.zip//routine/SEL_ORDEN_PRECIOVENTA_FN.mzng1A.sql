-- =============================================
-- Author:		Edwin CRUZ
-- Create date: 2018-11-18
-- Description:	Obtiene el precio de venta de una orden
-- =============================================
CREATE FUNCTION [dbo].[SEL_ORDEN_PRECIOVENTA_FN]
(
	
	@idOrden INT
	, @tipoConsulta INT  -- Precio de acuerdo al estatus de la partida y cotización
	, @idUsuario INT
)
RETURNS DECIMAL(18,2)
AS
BEGIN

	DECLARE @venta NUMERIC(18,2) = 0
	DECLARE @numero TABLE(estatusCotizacion int, estatusPartida int)
	DECLARE @idRol INT 

	select @idRol = cou.idCatalogoRol from dbo.usuarios usu
	inner join dbo.contratooperacionusuario COU on cou.idusuario = usu.idusuario
	where usu.idusuario = @idUsuario


	IF(@tipoConsulta = 1)
	insert @numero values(1, 1)
	IF(@tipoConsulta = 2)
	insert @numero values(1, 1)
	insert @numero values(2, 2)
	IF(@tipoConsulta = 3)
	insert @numero values(3, 2)
	IF(@tipoConsulta = 4)
	insert @numero values(2, 1)
	insert @numero values(3, 2)

	if (@idRol <> 4)
		begin

		SELECT @venta = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
			FROM  [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
		WHERE O.idOrden = @idOrden 
		AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
		AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero)	

	end
	else
		begin
			declare @idOperacion INT = (select idOperacion 
											from dbo.ContratoOperacion cop
											inner join dbo.Ordenes ord on ord.IdContratoOperacion = cop.IdContratoOperacion
											where idOrden = @idOrden )

			SELECT @venta = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
			WHERE O.idOrden = @idOrden 
			AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
			AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero)	
			AND C.idTaller in (
				SELECT        COUP.idProveedor
					FROM          dbo.ContratoOperacion CO
				INNER JOIN dbo.ContratoOperacionUsuario COU ON CO.idContratoOperacion = COU.idContratoOperacion
				INNER JOIN dbo.ContratoOperacionUsuarioProveedor COUP on COUP.idContratoOperacionUsuario =  COU.idContratoOperacionUsuario
				WHERE COU.idUsuario = @idUsuario and CO.idOperacion = @idOperacion
			)

		end
	
	RETURN @venta
END
go

