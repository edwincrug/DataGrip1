-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 2018 Octubre 08
-- Description:	Obtiene los kilometrajes de la unidad registrada en sisco
-- Exec [GPS].[SEL_KILOMETROS_UNIDAD_SP] 7
-- =============================================

CREATE PROCEDURE [GPS].[SEL_KILOMETROS_UNIDAD_SP]
@idUnidad varchar(100)

AS
DECLARE
	@vin	varchar(20)
BEGIN

	SET NOCOUNT ON;

	SELECT 
		@vin = vin 
	FROM [ASEPROT].[dbo].[Unidades] 
	WHERE idUnidad = @idUnidad

	IF(@vin IS NOT NULL AND @vin <> '')
	BEGIN
		select 
			tpl.lo longitud,
			tpl.la latitud, 
			tpl.mileage kilometros,
			tpl.gpsTime	fecha,
			u.numeroEconomico,
			u.placas
		from 
			[192.168.20.110].[GPS].[cxc].[UnidadGPSSIM] ugs
				inner join [192.168.20.110].[GPS].[inventario].GPSSIM gs on ugs.idGPSSIM = gs.idGPSSIM
				inner join [192.168.20.110].[GPS].[inventario].GPS g on gs.idGPS = g.idGPS 
				inner join [192.168.20.110].[8833test].[dbo].[tCar] tc on g.deviceID = tc.carNO
				inner join [192.168.20.110].[8833test].[dbo].tPosition_last tpl on tc.carID = tpl.carID
				inner join unidades u on u.vin = ugs.vin
		where ugs.vin = @vin
	END
	ELSE
	BEGIN
		select 
			0 longitud,
			0 latitud, 
			0 kilometros,
			GETDATE() fecha,
			0 numeroEconomico,
			'' placas
	END

END
go

grant execute, view definition on GPS.SEL_KILOMETROS_UNIDAD_SP to DevOps
go

