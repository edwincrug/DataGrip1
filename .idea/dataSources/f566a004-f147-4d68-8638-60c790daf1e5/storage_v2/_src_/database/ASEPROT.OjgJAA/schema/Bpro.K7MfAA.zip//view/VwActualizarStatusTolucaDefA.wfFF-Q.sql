

CREATE VIEW [Bpro].[VwActualizarStatusTolucaDefA]
AS
SELECT [MODULO]
      ,[DES_CARTERA]
      ,[DES_TIPODOCTO]
      ,[CCP_IDDOCTO]
      ,[CCP_NODOCTO]
      ,[CCP_IDPERSONA]
      ,[Nombre]
      ,[PER_TELEFONO1]
      ,[CCP_FECHVEN]
      ,[CCP_FECHPAG]
      ,[CCP_FECHPROMPAG]
      ,[CCP_FECHREV]
      ,[IMPORTE]
      ,[SALDO]
      ,[CCP_FECHADOCTO]
      ,[CCP_TIPODOCTO]
      ,[CCP_ORIGENCON]
      ,[COP_STATUS]
	  ,[NewStatus]
		 , case when [COP_STATUS] = [NewStatus]
		        then 0
				else 1
				end as [ReqUpdate]


		 FROM [ASEPROT].[Bpro].[VwActualizarStatusTolucaDef]

go

grant select, view definition on Bpro.VwActualizarStatusTolucaDefA to DevOps
go

