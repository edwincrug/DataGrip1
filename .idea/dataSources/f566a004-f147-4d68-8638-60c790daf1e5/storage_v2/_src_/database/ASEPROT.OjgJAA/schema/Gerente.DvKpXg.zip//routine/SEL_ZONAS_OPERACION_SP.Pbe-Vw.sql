 CREATE PROCEDURE [Gerente].[SEL_ZONAS_OPERACION_SP] 
 	@idContratoOperacion INT,
	@idZona INT
AS
BEGIN	

	DECLARE @nivelZonas INT =
	(SELECT COUNT(DISTINCT ZO.idNivelZona) FROM [Partidas].[dbo].[Zona] ZO
			 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
			 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
			 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
			 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
	WHERE CO.idContratoOperacion = @idContratoOperacion)

	IF(@nivelZonas = 1)
		BEGIN
			IF(@idZona = 0)
				BEGIN
					SELECT ZO.idZona,
						   ZO.idPadre,
						   0 AS checked,
						   --CASE  WHEN COUG.ContratoOperacionUsuarioGerente IS NULL THEN 0 ELSE 1 END AS checked,
						   --(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  ZO.nombre AS nombre,
						   ZO.nombre AS nombre,
						   ZO.idNivelZona
					FROM [Partidas].[dbo].[Zona] ZO
					 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
					 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
					 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
					 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
					 --LEFT JOIN ContratoOperacionUsuarioGerente COUG ON ZO.idZona = COUG.idZona --AND COUZ.idContratoOperacionUsuario = @idContratoOperacionUsuario
					WHERE ZO.estatus=1 
					AND CO.idContratoOperacion = @idContratoOperacion 
					--AND ZO.idPadre <> 0
					AND ZO.idZona NOT IN(SELECT EZ.idZona FROM [Gerente].[EstadoZona] EZ
						JOIN [Partidas].[dbo].[Zona] Z ON Z.idZona = EZ.idZona 
						WHERE EZ.estatus = 0 AND EZ.idContratoOperacion = @idContratoOperacion)
				END
			ELSE
				BEGIN
					SELECT ZO.idZona,
						   ZO.idPadre,
						   0 AS checked,
						   --CASE  WHEN COUG.ContratoOperacionUsuarioGerente IS NULL THEN 0 ELSE 1 END AS checked,
						   --(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  ZO.nombre AS nombre,
						   ZO.nombre AS nombre,
						   ZO.idNivelZona
					FROM [Partidas].[dbo].[Zona] ZO
					 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
					 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
					 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
					 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
					 --LEFT JOIN ContratoOperacionUsuarioGerente COUG ON ZO.idZona = COUG.idZona --AND COUZ.idContratoOperacionUsuario = @idContratoOperacionUsuario
					WHERE ZO.estatus=1 
					AND CO.idContratoOperacion = @idContratoOperacion 
					AND ZO.idZona = @idZona
					--AND ZO.idPadre <> 0
				END
		END
	ELSE
		BEGIN
			IF(@idZona = 0)
				BEGIN
					SELECT ZO.idZona,
						   ZO.idPadre,
						   0 AS checked,
						   --CASE  WHEN COUG.ContratoOperacionUsuarioGerente IS NULL THEN 0 ELSE 1 END AS checked,
						   --(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  ZO.nombre AS nombre,
						   ZO.nombre AS nombre,
						   ZO.idNivelZona
					FROM [Partidas].[dbo].[Zona] ZO
					 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
					 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
					 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
					 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
					 --LEFT JOIN ContratoOperacionUsuarioGerente COUG ON ZO.idZona = COUG.idZona --AND COUZ.idContratoOperacionUsuario = @idContratoOperacionUsuario
					WHERE ZO.estatus=1 
					AND CO.idContratoOperacion = @idContratoOperacion 
					--AND ZO.idPadre <> 0
					AND ZO.idZona NOT IN(SELECT EZ.idZona FROM [Gerente].[EstadoZona] EZ
						JOIN [Partidas].[dbo].[Zona] Z ON Z.idZona = EZ.idZona 
						WHERE EZ.idContratoOperacion = @idContratoOperacion AND EZ.estatus = 0 AND Z.idPadre <> 0)
				END
			ELSE
				BEGIN
					SELECT ZO.idZona,
						   ZO.idPadre,
						   0 AS checked,
						   --CASE  WHEN COUG.ContratoOperacionUsuarioGerente IS NULL THEN 0 ELSE 1 END AS checked,
						   --(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  ZO.nombre AS nombre,
						   ZO.nombre AS nombre,
						   ZO.idNivelZona
					FROM [Partidas].[dbo].[Zona] ZO
					 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
					 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
					 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
					 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
					 --LEFT JOIN ContratoOperacionUsuarioGerente COUG ON ZO.idZona = COUG.idZona --AND COUZ.idContratoOperacionUsuario = @idContratoOperacionUsuario
					WHERE ZO.estatus=1 
					AND CO.idContratoOperacion = @idContratoOperacion 
					AND ZO.idZona = @idZona
					--AND ZO.idPadre <> 0
				END
		END
END

/*
	IF(@idContratoOperacion <> 0)
		BEGIN
			SELECT ZO.idZona,
				   ZO.idPadre,
				   --0 AS checked,
				   CASE WHEN COUG.idContratoOperacionUsuarioGerente IS NULL THEN 0 ELSE 1 END AS checked,
				   --(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  ZO.nombre AS nombre,
				   ZO.nombre AS nombre,
				   ZO.idNivelZona
			FROM [Partidas].[dbo].[Zona] ZO
			 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
			 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
			 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
			 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
			 LEFT JOIN [Gerente].[EstadoZona] EZ ON EZ.idZona = ZO.idZona AND EZ.estatus=0
			 LEFT JOIN [Gerente].[EstadoGerencia] EG ON EG.idEstado = EZ.idEstado AND EG.estatus=0
			 LEFT JOIN ContratoOperacionUsuarioGerente COUG ON COUG.idGerencias = EG.idGerencia 
			WHERE ZO.estatus=1 
			AND CO.idContratoOperacion = @idContratoOperacion 
			--AND ZO.idPadre <> 0
			--AND ZO.idZona NOT IN(SELECT idZona FROM [Gerente].[EstadoZona] WHERE idContratoOperacion = @idContratoOperacion AND estatus = 0)
		END
	ELSE
		BEGIN
			SELECT ZO.idZona,
				   ZO.idPadre,
				   0 AS checked,
				   --CASE  WHEN COUG.ContratoOperacionUsuarioGerente IS NULL THEN 0 ELSE 1 END AS checked,
				   --(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  ZO.nombre AS nombre,
				   ZO.nombre AS nombre,
				   ZO.idNivelZona
			FROM [Partidas].[dbo].[Zona] ZO
			 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
			 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
			 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
			 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
			 --LEFT JOIN ContratoOperacionUsuarioGerente COUG ON ZO.idZona = COUG.idZona --AND COUZ.idContratoOperacionUsuario = @idContratoOperacionUsuario
			WHERE ZO.estatus=1 --AND ZO.idPadre <> 0
		END
*/


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.SEL_ZONAS_OPERACION_SP to DevOps
 go

