CREATE PROCEDURE [dbo].[EXT_UPD_MOVER_PRESUPUESTO_SP]
	@idOrden NUMERIC(18,0),
	@idPresupuesto NUMERIC(18,0),
	@idUsuarioOperacion NUMERIC(18,0)
AS
BEGIN
DECLARE @IdZona INT
		DECLARE @Zona NVARCHAR(100)
		DECLARE @Consecutivo INT
		DECLARE @idCentroTrabajo INT
		DECLARE @numTAR INT
	IF EXISTS(SELECT 1 FROM PresupuestoOrden WHERE idOrden=@idOrden)
		BEGIN
			SELECT @IdZona=idZona, @idCentroTrabajo=idCentroTrabajo FROM Ordenes WHERE idOrden = @idOrden

			declare @zonaPadre table(ID INT, idPadre INT, nombreNivel varchar(50), nombre varchar(50))
			insert into @zonaPadre
			EXEC [SEL_ZONAS_PADRES_SP]  @IdZona
			select top 1 @Zona = SUBSTRING(nombre, 1, 1) from @zonaPadre

			SELECT @numTAR = extra1 FROM CentroTrabajos WHERE idCentroTrabajo=@idCentroTrabajo
			SELECT @Consecutivo = (SELECT consecutivo FROM PresupuestoOrden WHERE idOrden=@idOrden)
			UPDATE PresupuestoOrden
			SET 
			idPresupuesto=@idPresupuesto,
			folio = 'RC-GLR' + @Zona + '-' + CONVERT(VARCHAR(5), @numTAR) + '-' + RIGHT('00000' + CONVERT(VARCHAR(5), @Consecutivo),5) + '-' + CONVERT(varchar(10), YEAR(GETDATE()))
			WHERE idOrden=@idOrden

			SELECT 10;
		END
	ELSE
		BEGIN
			DECLARE @idOperacion NUMERIC(18,0)
			
			SELECT @idOperacion = idOperacion 
			FROM Ordenes O 
			INNER JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
			WHERE idOrden = @idOrden
			
			EXEC [dbo].[INS_PRESUPUESTO_ORDEN_SP] @idPresupuesto, @idOrden, @idUsuarioOperacion, @idOperacion
			
			SELECT 11
			
		END

END

go

