create procedure dbo.SEL_ORDEN_PAGO_SP (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		idOrdenPago,
		folio,
		convert(nvarchar(10),fecha,103) as fecha,
		monto,
		idEstatusOrdenPago,
		convert(nvarchar(10),fecha,103) as fechaCarga
	FROM
		dbo.OrdenPago;

end
go

