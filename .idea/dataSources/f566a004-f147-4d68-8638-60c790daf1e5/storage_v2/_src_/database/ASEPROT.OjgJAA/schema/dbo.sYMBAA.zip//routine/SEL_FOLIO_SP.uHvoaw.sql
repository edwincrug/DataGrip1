-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--Test: SEL_FOLIO_SP 527,6
-- =============================================
CREATE PROCEDURE [dbo].[SEL_FOLIO_SP](
	-- Add the parameters for the stored procedure here
	@idUsuario				numeric(18,0),
	@idContratoOperacion	numeric(18,0)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	select 
		result.idFolio			idFolio,
		result.folio			folio,
		''						ordenSurtimiento,
		''						numEstimacion,
		sum(subTotal)			subTotal,
		sum(subTotal)*1.16		total
	from (
		select 
			f.idFolio,
			folio,
			(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3,510, 2)) AS subTotal,
			f.fechaCarga
		from 
			Ordenes o
			inner join folioOrden fo on fo.idOrden = o.idOrden
			inner join folio f on f.idFolio = fo.idFolio
			left join DatosCopade dc on dc.numeroCopade = f.folio
		where 
			f.idContratoOperacion = @idContratoOperacion
			and dc.idDatosCopade is null
		) as result
	group by result.idFolio, result.folio
END
go

