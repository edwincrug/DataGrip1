-- =============================================
-- Description:	Busca todas las órdenes existentes
-- NOTA: Falta verificar el usuario, su rol y el tipo de operación 
-- =============================================
-- [dbo].[SEL_ORDENES_EVIDENCIA_SP_P] 57

CREATE PROCEDURE [dbo].[SEL_ORDENES_EVIDENCIA_SP_P]
@idContratoOperacion INT,
@fechaInicio VARCHAR(MAX) = NULL,
@fechaFin VARCHAR(MAX) = NULL,
@idOrden NUMERIC (18,0) = NULL,
@accion INT=0
AS
BEGIN
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; -- turn it on

SET DATEFORMAT DMY;

EXEC [192.168.20.18].ASEPROT.[dbo].[SEL_ORDENES_EVIDENCIA_SP_P] @idContratoOperacion ,@fechaInicio ,@fechaFin ,@idOrden , @accion

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED; -- turn it off
END
go

