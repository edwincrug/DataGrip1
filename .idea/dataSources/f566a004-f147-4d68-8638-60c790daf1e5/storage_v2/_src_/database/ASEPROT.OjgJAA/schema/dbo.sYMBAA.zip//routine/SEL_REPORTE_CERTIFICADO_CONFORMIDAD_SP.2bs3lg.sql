
-- [dbo].[SEL_REPORTE_CERTIFICADO_CONFORMIDAD_SP] @idOperacion = 3, @idUsuario = 705,@talleres=null,@idZona=56,@banderaConsulta=1
-- @banderaConsulta=2 = POR COTIZACION
-- [dbo].[SEL_REPORTE_CERTIFICADO_CONFORMIDAD_SP] @idOperacion = 57, @idUsuario = 538, @banderaConsulta = 1
CREATE procedure  [dbo].[SEL_REPORTE_CERTIFICADO_CONFORMIDAD_SP]

@idOperacion int,
@idUsuario int,
@talleres as VARCHAR(150) = NULL,
@fechaInicial varchar(25) = NULL,
@fechaFinal varchar(25) = NULL,
@idZona int = NULL,
@numeroOrden varchar(50) = NULL,
@banderaConsulta int

AS
BEGIN

		DECLARE @idCO int, @idCOU int, @cliente nvarchar(100), @rol int,@idPresupuesto int 

		SELECT @idCO = CO.idContratoOperacion, @idCOU = COU.idContratoOperacionUsuario, @rol = COU.idCatalogoRol
		FROM ContratoOperacionUsuario COU 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COU.idContratoOperacion
		WHERE idUsuario = @idUsuario and CO.idOperacion = @idOperacion

		set @idPresupuesto = (select presupuesto from Operaciones where idOperacion = @idOperacion)

		set @cliente = (SELECT [dbo].[SEL_NOMBRE_CLIENTE](@idCO))

		declare @query varchar(max) = '', @queryZonas varchar(max) = '', @queryClose varchar(max) = '', @FinalQuery nvarchar(max), @headQueryZonas nvarchar(max) = ''
		declare @headZonasFiltro nvarchar(max) = '', @headProveedoresFiltro nvarchar(max) = '', @queryZonasFiltro nvarchar(max) = '', @queryProveedoresFIltro nvarchar(max) = ''
		declare @sumCosto numeric(18,2)
		declare @sumVenta numeric(18,2)
			DECLARE @usuario NVARCHAR(MAX) = '' 
	if(@banderaConsulta = 2)
	begin
	PRINT 'ENTRO POR CONSULTA COTIZACION'
	declare @total table(Cliente varchar(max), consecutivoOrden int,numeroCotizacion varchar(max), numeroOrden varchar(max), numeroEconomico varchar(max), idZona int,costoCot numeric(18,2),ventaCot numeric(18,2), venta numeric(18,2), costo numeric(18,2), descripcion varchar(max), estatus varchar(max), idEstatus int, fechaCreacionOrden datetime, fechaTerminoTrabajo datetime, entrega datetime, cobranza datetime, zonasConcatenadas varchar(max), nombreZona varchar(max), folioPresupuesto varchar(max), solpe varchar(50), codigoSAP varchar(MAX), folioCertificado varchar(max), numeroCopade varchar(max), numCotizacion varchar(max), taller varchar(max), numeroFactura varchar (max), estatusBpro varchar(max), fechaRecepcionCopade datetime, aplicaFondo varchar(30), Color VARCHAR(30))
		
		if (@rol <> 2)
			begin

					if (@rol = 1)
					begin
					SET @usuario = ' and ORD.idOrden not in(select idOrden from Cotizaciones where idTaller=689)'
					end
				

				IF(@rol <> 9)
						BEGIN
						PRINT 'ROL DIFERENTE'
											set @headQueryZonas = '	
				
				declare @zonas table (idZona int)
				insert into @zonas
				select idZona from [dbo].[GET_ZONAS_USR_FN]('+convert(varchar(max),@idCOU)+')										
				'
						END
					ELSE
						BEGIN
						PRINT 'ROL 9'
							set @headQueryZonas = '	
											declare @zonas table (idZona int)
				insert into @zonas
							SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
												JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
												JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
											WHERE EG.estatus=0 AND EZ.estatus=0 
											AND COUG.idContratoOperacionUsuario='+ convert(varchar(5), @idCOU) +' AND EZ.idContratoOperacion='+ convert(varchar(5), @idCO) +' '
						END

				set @queryZonas = ' AND ORD.idZona in (select idZona from @zonas) '
				
					if(@rol = 4)
						begin
							set @headProveedoresFiltro = '
							
							declare @provs table (idProveedores int)
							insert into @provs
							select idProveedor from ContratoOperacionUsuarioProveedor where idContratoOperacionUsuario = '+CONVERT(varchar(max),@idCOU)+'
							'
							
							set @queryProveedoresFIltro = ' AND C.idTaller in (select idProveedores from @provs) AND C.idEstatusCotizacion not in (4, 5)'
							
						end
						
				
			end
			
		if (@idZona is not null)
			begin
				set @headZonasFiltro = '
				declare @zonasFiltro table (idZona int)
				insert into @zonasFiltro 
				select idZona from [dbo].[GET_ZONAS_FILTRO_FN]('+CONVERT(varchar(max),@idZona)+')
				'
				
				set @queryZonasFiltro = ' AND idZona in (select idZona from @zonasFiltro)'
			end
	if(@rol = 2)
	begin
	PRINT 'ENTRO POR ROLL 2 COTIZACION'
		if(@idPresupuesto = 1)
		BEGIN
			set @query = '	
			SELECT *, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM 
				(
					select distinct
							 '''+@cliente+''' AS Cliente
							,ORD.consecutivoOrden
							,C.numeroCotizacion
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							,(SELECT [dbo].[SEL_PRECIO_VENTA_COT_FN](C.idCotizacion, ORD.idContratoOperacion, 3, 107, 2)) as ventaCot
							,(SELECT [dbo].[SEL_PRECIO_COSTO_COT_FN](C.idCotizacion, ORD.idContratoOperacion, 3, 107, 2)) as costoCot
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo
							,ORD.comentarioOrden as descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 6)  as fechaTerminoTrabajo
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 7)  as entrega
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 8)  as cobranza
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORD.idOrden),'''') codigoSAP
							,isnull(PO.folio, ''S/N'') folioCertificado
							,isnull(DC.numeroCopade, ''S/N'') numeroCopade
							,(SELECT [dbo].[SEL_COTIZACIONESX_ORDEN_FN](ORD.idOrden)) AS numCotizacion
							,PP.nombreComercial AS taller
							--,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden)) AS taller
							,FC.numFactura AS numeroFactura
							--,(SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](ORD.idOrden)) AS numeroFactura
							--,[dbo].[SEL_STATUS_PROVISION_FN_ERIC] (ORD.idOrden) estatusP
							,ISNULL(VB.estatusBpro, ''No provisionada'') AS estatusBpro
							,isnull(DC.fechaRecepcionCopade, '''') AS fechaRecepcionCopade,
							CASE WHEN ORD.fechaCreacionOden <=''12/11/2018'' THEN ''rowAzulDark''
							ELSE ISNULL(CB.codigoCSS,'''') END
							AS aplicaFondo
							
					FROM Ordenes ORD
						LEFT JOIN ASEPROT.dbo.OrdenesColores OC 
							LEFT JOIN ASEPROT.dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
						ON OC.numeroOrden=ORD.numeroOrden AND OC.idContratoOperacion=ORD.idContratoOperacion
						INNER JOIN Cotizaciones C on C.idOrden = ORD.idOrden 
						INNER JOIN CotizacionDetalle CDD on C.idCotizacion = CDD.idCotizacion
						INNER JOIN facturaCotizacion FC on FC.idCotizacion=C.idCotizacion
						inner join Partidas..Proveedor PP on PP.idProveedor = C.idTaller
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden					
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						INNER JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						INNER JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
						LEFT JOIN VwStatusBpro VB ON ORD.numeroOrden = VB.numeroOrden 
					WHERE  ORD.idEstatusOrden not in (13) and (C.idEstatusCotizacion <> 4) AND	('''+isnull(@talleres,'null')+''' IS NULL OR PP.nombreComercial LIKE ''%'+isnull(@talleres,'')+'%'') AND ORD.idContratoOperacion = '+convert(varchar(max),@idCO) + '
					' + + @queryProveedoresFIltro
			END
			ELSE
			BEGIN
				set @query = '	
			SELECT *, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM 
				(
					select distinct
							 '''+@cliente+''' AS Cliente
							,ORD.consecutivoOrden
							,C.numeroCotizacion
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							,(SELECT [dbo].[SEL_PRECIO_VENTA_COT_FN](C.idCotizacion, ORD.idContratoOperacion, 3, 107, 2)) as ventaCot
							,(SELECT [dbo].[SEL_PRECIO_COSTO_COT_FN](C.idCotizacion, ORD.idContratoOperacion, 3, 107, 2)) as costoCot
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo
							,ORD.comentarioOrden as descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 6)  as fechaTerminoTrabajo
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 7)  as entrega
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 8)  as cobranza
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORD.idOrden),'''') codigoSAP
							,isnull(PO.folio, ''S/N'') folioCertificado
							,isnull(DC.numeroCopade, ''S/N'') numeroCopade
							,(SELECT [dbo].[SEL_COTIZACIONESX_ORDEN_FN](ORD.idOrden)) AS numCotizacion
							,PP.nombreComercial AS taller
							--,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden)) AS taller
							,FC.numFactura AS numeroFactura
							--,(SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](ORD.idOrden)) AS numeroFactura
							--,[dbo].[SEL_STATUS_PROVISION_FN_ERIC] (ORD.idOrden) estatusP
							,ISNULL(VB.estatusBpro, ''No provisionada'') AS estatusBpro
							,isnull(DC.fechaRecepcionCopade, '''') AS fechaRecepcionCopade,
							CASE WHEN ORD.fechaCreacionOden <=''12/11/2018'' THEN ''rowAzulDark''
							ELSE ISNULL(CB.codigoCSS,'''') END
							AS aplicaFondo
							
					FROM Ordenes ORD
						LEFT JOIN ASEPROT.dbo.OrdenesColores OC 
							LEFT JOIN ASEPROT.dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
						ON OC.numeroOrden=ORD.numeroOrden AND OC.idContratoOperacion=ORD.idContratoOperacion
						INNER JOIN Cotizaciones C on C.idOrden = ORD.idOrden 
						INNER JOIN CotizacionDetalle CDD on C.idCotizacion = CDD.idCotizacion
						INNER JOIN facturaCotizacion FC on FC.idCotizacion=C.idCotizacion
						inner join Partidas..Proveedor PP on PP.idProveedor = C.idTaller
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden					
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						LEFT JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						LEFT JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
						LEFT JOIN VwStatusBpro VB ON ORD.numeroOrden = VB.numeroOrden 
					WHERE  ORD.idEstatusOrden not in (13) and (C.idEstatusCotizacion <> 4) AND	('''+isnull(@talleres,'null')+''' IS NULL OR PP.nombreComercial LIKE ''%'+isnull(@talleres,'')+'%'') AND ORD.idContratoOperacion = '+convert(varchar(max),@idCO) + '
					' + + @queryProveedoresFIltro
			END
end
else
begin
PRINT 'ENTRO POR ROLL OTRO COTIZACION'

		IF(@idPresupuesto = 1)
		BEGIN
			set @query = '	
			SELECT *, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM 
				(
					select distinct
							 '''+@cliente+''' AS Cliente
							,ORD.consecutivoOrden
							,C.numeroCotizacion
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							,(SELECT [dbo].[SEL_PRECIO_VENTA_COT_FN](C.idCotizacion, ORD.idContratoOperacion, 3, 107, 2)) as ventaCot
							,(SELECT [dbo].[SEL_PRECIO_COSTO_COT_FN](C.idCotizacion, ORD.idContratoOperacion, 3, 107, 2)) as costoCot
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo
							,ORD.comentarioOrden as descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 6)  as fechaTerminoTrabajo
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 7)  as entrega
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 8)  as cobranza
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORD.idOrden),'''') codigoSAP
							,isnull(PO.folio, ''S/N'') folioCertificado
							,isnull(DC.numeroCopade, ''S/N'') numeroCopade
							,(SELECT [dbo].[SEL_COTIZACIONESX_ORDEN_FN](ORD.idOrden)) AS numCotizacion
							,PP.nombreComercial AS taller
							--,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden)) AS taller
							,FC.numFactura AS numeroFactura
							--,(SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](ORD.idOrden)) AS NumeroFactura
							--,[dbo].[SEL_STATUS_PROVISION_FN_ERIC] (ORD.idOrden) estatusP
							--,''BPRO'' AS estatusBpro
							,ISNULL(VB.estatusBpro, ''No provisionada'') AS estatusBpro
							,isnull(DC.fechaRecepcionCopade, '''') AS fechaRecepcionCopade,
							CASE WHEN ORD.fechaCreacionOden <=''12/11/2018'' THEN ''rowAzulDark''
							ELSE ISNULL(CB.codigoCSS,'''') END
							AS aplicaFondo
							
					FROM Ordenes ORD
						LEFT JOIN ASEPROT.dbo.OrdenesColores OC 
							LEFT JOIN ASEPROT.dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
						ON OC.numeroOrden=ORD.numeroOrden AND OC.idContratoOperacion=ORD.idContratoOperacion
						INNER JOIN Cotizaciones C on C.idOrden = ORD.idOrden
						INNER JOIN facturaCotizacion FC on FC.idCotizacion=C.idCotizacion
						inner join Partidas..Proveedor PP on PP.idProveedor = C.idTaller 
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden					
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						INNER JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						INNER JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
						LEFT JOIN VwStatusBpro VB ON ORD.numeroOrden = VB.numeroOrden 
					WHERE ORD.idEstatusOrden not in (13) AND ORD.idContratoOperacion = '+convert(varchar(max),@idCO) + '
					' + + @queryProveedoresFIltro
			END
			ELSE
			BEGIN
				set @query = '	
			SELECT *, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM 
				(
					select distinct
							 '''+@cliente+''' AS Cliente
							,ORD.consecutivoOrden
							,C.numeroCotizacion
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							,(SELECT [dbo].[SEL_PRECIO_VENTA_COT_FN](C.idCotizacion, ORD.idContratoOperacion, 3, 107, 2)) as ventaCot
							,(SELECT [dbo].[SEL_PRECIO_COSTO_COT_FN](C.idCotizacion, ORD.idContratoOperacion, 3, 107, 2)) as costoCot
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo
							,ORD.comentarioOrden as descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 6)  as fechaTerminoTrabajo
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 7)  as entrega
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 8)  as cobranza
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORD.idOrden),'''') codigoSAP
							,isnull(PO.folio, ''S/N'') folioCertificado
							,isnull(DC.numeroCopade, ''S/N'') numeroCopade
							,(SELECT [dbo].[SEL_COTIZACIONESX_ORDEN_FN](ORD.idOrden)) AS numCotizacion
							,PP.nombreComercial AS taller
							--,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden)) AS taller
							,FC.numFactura AS numeroFactura
							--,(SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](ORD.idOrden)) AS NumeroFactura
							--,[dbo].[SEL_STATUS_PROVISION_FN_ERIC] (ORD.idOrden) estatusP
							--,''BPRO'' AS estatusBpro
							,ISNULL(VB.estatusBpro, ''No provisionada'') AS estatusBpro
							,isnull(DC.fechaRecepcionCopade, '''') AS fechaRecepcionCopade,
							CASE WHEN ORD.fechaCreacionOden <=''12/11/2018'' THEN ''rowAzulDark''
							ELSE ISNULL(CB.codigoCSS,'''') END
							AS aplicaFondo
							
					FROM Ordenes ORD
						LEFT JOIN ASEPROT.dbo.OrdenesColores OC 
							LEFT JOIN ASEPROT.dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
						ON OC.numeroOrden=ORD.numeroOrden AND OC.idContratoOperacion=ORD.idContratoOperacion
						INNER JOIN Cotizaciones C on C.idOrden = ORD.idOrden
						INNER JOIN facturaCotizacion FC on FC.idCotizacion=C.idCotizacion
						inner join Partidas..Proveedor PP on PP.idProveedor = C.idTaller 
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden					
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						LEFT JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						LEFT JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
						LEFT JOIN VwStatusBpro VB ON ORD.numeroOrden = VB.numeroOrden 
					WHERE ORD.idEstatusOrden not in (13) AND ORD.idContratoOperacion = '+convert(varchar(max),@idCO) + '
					' + + @queryProveedoresFIltro
			END
end
		set @queryClose = '		) as tableResult 

		WHERE	fechaTerminoTrabajo BETWEEN COALESCE(CAST('+COALESCE(''''+@fechaInicial+'''','NULL')+' AS DATE),fechaTerminoTrabajo) 
		AND COALESCE (CAST('+COALESCE(''''+@fechaFinal+'''','NULL')+' AS DATE),fechaTerminoTrabajo)		
		AND		numeroOrden = COALESCE('+COALESCE(''''+@numeroOrden+'''','NULL')+', numeroOrden)'
		
		set @FinalQuery = @headQueryZonas + @headProveedoresFiltro + @headZonasFiltro + @query + @usuario + @queryZonas + @queryClose + @queryZonasFiltro 
		print @FinalQuery
		insert into @total
		EXECUTE SP_EXECUTESQL @FinalQuery

		select @sumCosto = sum(ventaCot), @sumVenta = sum(costoCot)
		from @total

		select *, @sumCosto sumaCosto, @sumVenta sumaVenta
		from @total
		end
		else
		begin
		declare @totalorden table(Cliente varchar(max), consecutivoOrden int, numeroOrden varchar(max), numeroEconomico varchar(max), idZona int, venta numeric(18,2), costo numeric(18,2), descripcion varchar(max), estatus varchar(max), idEstatus int, fechaCreacionOrden datetime, fechaTerminoTrabajo datetime, entrega datetime, cobranza datetime, zonasConcatenadas varchar(max), nombreZona varchar(max), folioPresupuesto varchar(max), solpe varchar(50), codigoSAP varchar(MAX), folioCertificado varchar(max), numeroCopade varchar(max), taller varchar(max), numeroFactura varchar (max), estatusBpro varchar(max), fechaRecepcionCopade datetime, aplicaFondo varchar(30), Color VARCHAR(30))
		
		if (@rol <> 2)
		
			begin

					if (@rol = 1)
					begin
					SET @usuario = ' and ORD.idOrden not in(select idOrden from Cotizaciones where idTaller=689)'
					end
				
				IF(@rol <> 9)
						BEGIN
						PRINT 'ROL DIFERENTE'
											set @headQueryZonas = '	
				
				declare @zonas table (idZona int)
				insert into @zonas
				select idZona from [dbo].[GET_ZONAS_USR_FN]('+convert(varchar(max),@idCOU)+')										
				'
						END
					ELSE
						BEGIN
						PRINT 'ROL 9'
							set @headQueryZonas = '	
											declare @zonas table (idZona int)
				insert into @zonas
							SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
												JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
												JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
											WHERE EG.estatus=0 AND EZ.estatus=0 
											AND COUG.idContratoOperacionUsuario='+ convert(varchar(5), @idCOU) +' AND EZ.idContratoOperacion='+ convert(varchar(5), @idCO) +' '
						END
				
				set @queryZonas = ' AND ORD.idZona in (select idZona from @zonas) '
				
					if(@rol = 4)
						begin
							set @headProveedoresFiltro = '
							
							declare @provs table (idProveedores int)
							insert into @provs
							select idProveedor from ContratoOperacionUsuarioProveedor where idContratoOperacionUsuario = '+CONVERT(varchar(max),@idCOU)+'
							'
							
							set @queryProveedoresFIltro = ' AND C.idTaller in (select idProveedores from @provs) AND C.idEstatusCotizacion not in (4, 5)'
							
						end
						
				
			end
			
		if (@idZona is not null)
			begin
				set @headZonasFiltro = '
				declare @zonasFiltro table (idZona int)
				insert into @zonasFiltro 
				select idZona from [dbo].[GET_ZONAS_FILTRO_FN]('+CONVERT(varchar(max),@idZona)+')
				'
				
				set @queryZonasFiltro = ' AND idZona in (select idZona from @zonasFiltro)'
			end
	if(@rol = 2)
	begin
	PRINT 'ENTRO POR ROLL 2 ORDEN'

		IF (@idPresupuesto = 1)
		BEGIN
			set @query = '	
			SELECT *, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM 
				(
					select distinct
							 '''+@cliente+''' AS Cliente
							,ORD.consecutivoOrden
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo
							,ORD.comentarioOrden as descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 6)  as fechaTerminoTrabajo
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 7)  as entrega
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 8)  as cobranza
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORD.idOrden),'''') codigoSAP
							,isnull(PO.folio, ''S/N'') folioCertificado
							,isnull(DC.numeroCopade, ''S/N'') numeroCopade
							,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden)) AS taller
							,(SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](ORD.idOrden)) AS numeroFactura
							--,[dbo].[SEL_STATUS_PROVISION_FN_ERIC] (ORD.idOrden) estatusP
							,ISNULL(VB.estatusBpro, ''No provisionada'') AS estatusBpro
							,isnull(DC.fechaRecepcionCopade, '''') AS fechaRecepcionCopade,
							CASE WHEN ORD.fechaCreacionOden <=''12/11/2018'' THEN ''rowAzulDark''
							ELSE ISNULL(CB.codigoCSS,'''') END
							AS aplicaFondo
							
					FROM Ordenes ORD
						LEFT JOIN ASEPROT.dbo.OrdenesColores OC 
							LEFT JOIN ASEPROT.dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
						ON OC.numeroOrden=ORD.numeroOrden AND OC.idContratoOperacion=ORD.idContratoOperacion
						INNER JOIN Cotizaciones C on C.idOrden = ORD.idOrden 
						inner join Partidas..Proveedor PP on PP.idProveedor = C.idTaller
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden					
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						INNER JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						INNER JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
						LEFT JOIN VwStatusBpro VB ON ORD.numeroOrden = VB.numeroOrden 
					WHERE ORD.idEstatusOrden not in (13) AND ('''+isnull(@talleres,'null')+''' IS NULL OR PP.nombreComercial LIKE ''%'+isnull(@talleres,'')+'%'') AND ORD.idContratoOperacion = '+convert(varchar(max),@idCO) + '
					' + + @queryProveedoresFIltro
			END
			ELSE
			BEGIN
				set @query = '	
			SELECT *, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM 
				(
					select distinct
							 '''+@cliente+''' AS Cliente
							,ORD.consecutivoOrden
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo
							,ORD.comentarioOrden as descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 6)  as fechaTerminoTrabajo
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 7)  as entrega
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 8)  as cobranza
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORD.idOrden),'''') codigoSAP
							,isnull(PO.folio, ''S/N'') folioCertificado
							,isnull(DC.numeroCopade, ''S/N'') numeroCopade
							,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden)) AS taller
							,(SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](ORD.idOrden)) AS numeroFactura
							--,[dbo].[SEL_STATUS_PROVISION_FN_ERIC] (ORD.idOrden) estatusP
							,ISNULL(VB.estatusBpro, ''No provisionada'') AS estatusBpro
							,isnull(DC.fechaRecepcionCopade, '''') AS fechaRecepcionCopade,
							CASE WHEN ORD.fechaCreacionOden <=''12/11/2018'' THEN ''rowAzulDark''
							ELSE ISNULL(CB.codigoCSS,'''') END
							AS aplicaFondo
							
					FROM Ordenes ORD
						LEFT JOIN ASEPROT.dbo.OrdenesColores OC 
							LEFT JOIN ASEPROT.dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
						ON OC.numeroOrden=ORD.numeroOrden AND OC.idContratoOperacion=ORD.idContratoOperacion
						INNER JOIN Cotizaciones C on C.idOrden = ORD.idOrden 
						inner join Partidas..Proveedor PP on PP.idProveedor = C.idTaller
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden					
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						LEFT JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						LEFT JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
						LEFT JOIN VwStatusBpro VB ON ORD.numeroOrden = VB.numeroOrden 
					WHERE ORD.idEstatusOrden not in (13) AND ('''+isnull(@talleres,'null')+''' IS NULL OR PP.nombreComercial LIKE ''%'+isnull(@talleres,'')+'%'') AND ORD.idContratoOperacion = '+convert(varchar(max),@idCO) + '
					' + + @queryProveedoresFIltro
			END
end
else
begin
	PRINT 'ENTRO POR ROLL OTRO ORDEN'

		IF(@idPresupuesto = 1)
		BEGIN
			set @query = '	
			SELECT *, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM 
				(
					select distinct
							 '''+@cliente+''' AS Cliente
							,ORD.consecutivoOrden
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo
							,ORD.comentarioOrden as descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 6)  as fechaTerminoTrabajo
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 7)  as entrega
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 8)  as cobranza
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORD.idOrden),'''') codigoSAP
							,isnull(PO.folio, ''S/N'') folioCertificado
							,isnull(DC.numeroCopade, ''S/N'') numeroCopade
							,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden)) AS taller
							,(SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](ORD.idOrden)) AS NumeroFactura
							--,[dbo].[SEL_STATUS_PROVISION_FN_ERIC] (ORD.idOrden) estatusP
							--,''BPRO'' AS estatusBpro
							,ISNULL(VB.estatusBpro, ''No provisionada'') AS estatusBpro
							,isnull(DC.fechaRecepcionCopade, '''') AS fechaRecepcionCopade,
							CASE WHEN ORD.fechaCreacionOden <=''12/11/2018'' THEN ''rowAzulDark''
							ELSE ISNULL(CB.codigoCSS,'''') END
							AS aplicaFondo
							
					FROM Ordenes ORD
						LEFT JOIN ASEPROT.dbo.OrdenesColores OC 
							LEFT JOIN ASEPROT.dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
						ON OC.numeroOrden=ORD.numeroOrden AND OC.idContratoOperacion=ORD.idContratoOperacion
						INNER JOIN Cotizaciones C on C.idOrden = ORD.idOrden 
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden					
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						INNER JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						INNER JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
						LEFT JOIN VwStatusBpro VB ON ORD.numeroOrden = VB.numeroOrden 
					WHERE ORD.idEstatusOrden not in (13) AND ORD.idContratoOperacion = '+convert(varchar(max),@idCO) + '
					' + + @queryProveedoresFIltro
			END
			ELSE
			BEGIN
				set @query = '	
			SELECT *, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM 
				(
					select distinct
							 '''+@cliente+''' AS Cliente
							,ORD.consecutivoOrden
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo
							,ORD.comentarioOrden as descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 6)  as fechaTerminoTrabajo
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 7)  as entrega
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden = 8)  as cobranza
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORD.idOrden),'''') codigoSAP
							,isnull(PO.folio, ''S/N'') folioCertificado
							,isnull(DC.numeroCopade, ''S/N'') numeroCopade
							,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden)) AS taller
							,(SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](ORD.idOrden)) AS NumeroFactura
							--,[dbo].[SEL_STATUS_PROVISION_FN_ERIC] (ORD.idOrden) estatusP
							--,''BPRO'' AS estatusBpro
							,ISNULL(VB.estatusBpro, ''No provisionada'') AS estatusBpro
							,isnull(DC.fechaRecepcionCopade, '''') AS fechaRecepcionCopade,
							CASE WHEN ORD.fechaCreacionOden <=''12/11/2018'' THEN ''rowAzulDark''
							ELSE ISNULL(CB.codigoCSS,'''') END
							AS aplicaFondo
							
					FROM Ordenes ORD
						LEFT JOIN ASEPROT.dbo.OrdenesColores OC 
							LEFT JOIN ASEPROT.dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
						ON OC.numeroOrden=ORD.numeroOrden AND OC.idContratoOperacion=ORD.idContratoOperacion
						INNER JOIN Cotizaciones C on C.idOrden = ORD.idOrden 
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden					
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						LEFT JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						LEFT JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
						LEFT JOIN VwStatusBpro VB ON ORD.numeroOrden = VB.numeroOrden 
					WHERE ORD.idEstatusOrden not in (13) AND ORD.idContratoOperacion = '+convert(varchar(max),@idCO) + '
					' + + @queryProveedoresFIltro
			END
end
		set @queryClose = '		) as tableResult 

		WHERE	fechaTerminoTrabajo BETWEEN COALESCE(CAST('+COALESCE(''''+@fechaInicial+'''','NULL')+' AS DATE),fechaTerminoTrabajo) 
		AND COALESCE (CAST('+COALESCE(''''+@fechaFinal+'''','NULL')+' AS DATE),fechaTerminoTrabajo)		
		AND		numeroOrden = COALESCE('+COALESCE(''''+@numeroOrden+'''','NULL')+', numeroOrden)'
		
		set @FinalQuery = @headQueryZonas + @headProveedoresFiltro + @headZonasFiltro + @query + @usuario + @queryZonas + @queryClose + @queryZonasFiltro 

		print @FinalQuery
		insert into @totalorden
		EXECUTE SP_EXECUTESQL @FinalQuery

		select @sumCosto = sum(costo), @sumVenta = sum(venta)
		from @totalorden

		select *, @sumCosto sumaCosto, @sumVenta sumaVenta
		from @totalorden

		end
		END

go

grant execute, view definition on SEL_REPORTE_CERTIFICADO_CONFORMIDAD_SP to DevOps
go

