
--[dbo].[INS_PARTIDAS_CHRYSLER]
CREATE PROCEDURE [dbo].[INS_PARTIDAS_CHRYSLER]
	
AS
BEGIN

	/*Marcas: 1 Nissan, 8 Vw, 12 Chrysler*/
	DECLARE @IdMarca int = 1000

	/*idUnidad*/

	DECLARE @IdUnidad int = 619

	--UPDATE PP
	--SET PP.ESTATUS = 3 
	--FROM Partidas..Partida PP 
	--INNER JOIN RefaccionMultiMarca.Catalogo.Partida RP ON 
	--	RP.noParte = PP.noParte AND PP.descripcion = RP.descripcion AND PP.idUnidad = RP.idUnidad
	--WHERE RP.estatus = 0 AND RP.marca = @IdMarca

	DECLARE @noParte NVARCHAR(MAX)
	DECLARE @descripcion AS NVARCHAR(MAX)
	DECLARE @idOrdenAgrupada NUMERIC(18,0)
	DECLARE @idContratoUnidad NUMERIC(18,0) = isnull((SELECT idContratoUnidad FROM Partidas..ContratoUnidad WHERE idContrato = 70 AND idUnidad = @IdUnidad ),1)
	DECLARE @idPartida NUMERIC(18,0)
	DECLARE @venta DECIMAL(18,4)
	DECLARE @costo DECIMAL(18,4)
	DECLARE @estatus NUMERIC(18,0)
	DECLARE ProdInfo CURSOR FOR 
	SELECT DISTINCT RP.noParte, RP.descripcion, RP.costo, RP.estatus 
	FROM RefaccionMultiMarca.Catalogo.Partida RP
	WHERE RP.estatus in (1,2) AND RP.marca = @IdMarca
	OPEN ProdInfo
	FETCH NEXT FROM ProdInfo INTO @noParte, @descripcion, @venta, @estatus
	WHILE @@fetch_status = 0
	BEGIN
		set @costo = 0
		if(@venta > 0)
			begin
				print 'entra'
				set @costo = @venta - (@venta*.13)
				print @costo
			end

		IF(@estatus = 1)
		BEGIN
			IF NOT EXISTS(SELECT 1 FROM  Partidas..Partida WHERE noParte = @noParte AND descripcion = @DESCRIPCION AND idUnidad = @IdUnidad)
			BEGIN
				--print('insert into Partidas..Partida')
				insert into Partidas..Partida
				SELECT 
					@IdUnidad,
					idTipoPartida,
					idEspecialidad,
					idPartidaClasificacion,
					idPartidaSubClasificacion,
					partida,
					44,
					noParte,
					descripcion,
					foto,
					instructivo,
					1,
					551,
					GETDATE(),
					'Carga masiva BPRO'
				FROM RefaccionMultiMarca.Catalogo.Partida
				WHERE noParte = @noParte AND descripcion = @descripcion

				SET @idPartida = (SELECT @@IDENTITY AS 'Partidas..Partida')
				
				insert into Partidas..ContratoPartida values(@idContratoUnidad, @idPartida, @venta, getdate(), 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '00:00:00.0000000', @venta, 0, 0)
				--select top(10)* from Partidas..ContratoPartida 
				INSERT INTO Partidas..ProveedorPartida
				SELECT 
				idProveedorCotizacion,
				@idPartida,
				@costo,
				0,
				@costo,
				0,
				getdate(),
				1,
				4
				FROM Partidas..ProveedorCotizacion WHERE idUnidad = @IdUnidad AND idProveedor IN(
				1375
				,2244
				,2245
				)

				UPDATE RefaccionMultiMarca.Catalogo.Partida SET estatus = 0 WHERE noParte = @noParte and idUnidad = @IdUnidad
				
			END
		END
		ELSE IF(@estatus = 2)
		BEGIN 
			SELECT @idPartida = idPartida FROM  Partidas..Partida WHERE noParte = @noParte AND descripcion = @DESCRIPCION AND idUnidad = @IdUnidad
			print('actualiza into Partidas..Partida')
			UPDATE Partidas..ContratoPartida 
			SET precio7Respaldo = venta,
			venta = @venta
			WHERE idPartida = @idPartida and idContratoUnidad = @idContratoUnidad

			UPDATE PPP 
			SET
			PPP.costoPieza = @costo,
			PPP.costo = @costo
			FROM Partidas..ProveedorPartida PPP
			INNER JOIN Partidas..ProveedorCotizacion PPC ON PPP.idProveedorCotizacion = PPC.idProveedorCotizacion
			WHERE PPC.idUnidad = @IdUnidad AND PPC.idProveedor IN(
			1375
			,2244
			,2245
			) AND PPP.idPartida = @idPartida

		END
		FETCH NEXT FROM ProdInfo INTO @noParte, @descripcion, @venta, @estatus
	END
CLOSE ProdInfo
DEALLOCATE ProdInfo
END
go

