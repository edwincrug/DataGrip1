
-- [EXT_DEL_ORDEN_PAGO_PROVISION_SP] 109,12
-- [EXT_DEL_ORDEN_PAGO_PROVISION_SP] 30920, 107, 3, 1
-- [EXT_DEL_ORDEN_PAGO_PROVISION_SP] 30920, 107, 1, 1
CREATE PROC [dbo].[EXT_DEL_ORDEN_PAGO_PROVISION_SP]
@idOrden NUMERIC(18,0),
@idUsuario NUMERIC(18,0),
@idContratoOperacion NUMERIC(18,0),
@isProduction NUMERIC(18,0)

AS
BEGIN
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @numeroOrden NVARCHAR(100)
	DECLARE @max NUMERIC(18,0)
	--////////////////////////////////
	DECLARE @idProveedor NUMERIC(18,0)
	DECLARE @server NVARCHAR(100)
	DECLARE @db NVARCHAR(100)
	--////////////////////////////////
	DECLARE @queryText NVARCHAR(MAX)
	DECLARE @tableTemp TABLE (val INT)
	DECLARE @queryM NVARCHAR(MAX)
	DECLARE @queryH NVARCHAR(MAX)
	DECLARE @queryC NVARCHAR(MAX)
	DECLARE @OTD_IDENT NVARCHAR(MAX)
	DECLARE @existe INT = 0
	DECLARE @proveedorInterno NUMERIC(18,0)
	--////////////////////////////////
	SELECT @numeroOrden=numeroOrden 
	FROM Ordenes WHERE idOrden=@idOrden

	  --Actualiza el trabajo de estatus y inserta en BPRO
	  SELECT @idCotizacion = MIN(C.idCotizacion) FROM Cotizaciones C 
				INNER JOIN CotizacionDetalle CD on C.idCotizacion = CD.idCotizacion
				WHERE C.idOrden = @idOrden AND idTaller <> 0 

		SELECT @proveedorInterno = proveedorInterno
		FROM ContratoOperacionFacturacion 
		WHERE idContratoOperacion = @idContratoOperacion
				
		SELECT @idProveedor = idTaller FROM Cotizaciones WHERE idCotizacion=@idCotizacion
		IF((@idProveedor <> 291 AND @idProveedor <> 292 AND @idProveedor <> 293 AND @idProveedor <> 294) OR @proveedorInterno = 0)
			BEGIN
				IF(@isProduction = 1)
					BEGIN
						SELECT 
								@server = SERVER,
								@db = DBProduccion
						FROM ContratoOperacionFacturacion COF 
						inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
						WHERE CO.idContratoOperacion =  @idContratoOperacion
					END
				ELSE
					BEGIN
						SELECT 
								@server=SERVER,
								@db=DB
						FROM ContratoOperacionFacturacion COF 
						inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
						WHERE CO.idContratoOperacion =  @idContratoOperacion
					END

							IF(@idContratoOperacion = 3)
								BEGIN
									SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_STATUS] IN(0,1,2) AND [OTE_ORDENANDRADE] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
									INSERT INTO @tableTemp EXEC(@queryText) 
									SET @existe = (SELECT TOP 1 val FROM @tableTemp)

									IF(@existe = 1)
										BEGIN
											IF NOT EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
												BEGIN
													SELECT 1 Success, 'La Orden se quito la provision exitosamente GAAutoExpress' Msg
												IF EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
													BEGIN
														UPDATE AprobacionProvision
														SET estatus=0
														where idOrden=@idOrden
													END
														SET @OTD_IDENT = 'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
													SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET] WHERE [OTD_IDENT] = ('+@OTD_IDENT+') '
													SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
													EXEC(@queryM) EXEC(@queryH) 
												END
											ELSE
												BEGIN
													SELECT 0 Success, 'La Orden ya se encuentra asociada no se puede eliminar GAAutoExpress' Msg
												END
										END
									ELSE
										BEGIN
											SELECT 0 Success, 'Orden registrada en Bpro con estados procesado que no se puede eliminar GAAutoExpress' Msg
										END
								END
                            ELSE IF(@idContratoOperacion = 1)
								BEGIN
									SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_STATUS] IN(0,1,2) AND [OTE_ORDENANDRADE] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
									INSERT INTO @tableTemp EXEC(@queryText) 
									SET @existe = (SELECT TOP 1 val FROM @tableTemp)

									IF(@existe = 1)
										BEGIN
											--IF NOT EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
												--BEGIN
													SELECT 1 Success, 'La Orden se quito la provision exitosamente GATPartsToluca' Msg
													
													IF EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
													BEGIN
														UPDATE AprobacionProvision
														SET estatus=0
														where idOrden=@idOrden
													END
														SET @OTD_IDENT = 'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
													SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET] WHERE [OTD_IDENT] = ('+@OTD_IDENT+') '
													SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
													EXEC(@queryM) EXEC(@queryH) 
												--END
											--ELSE
												--BEGIN
													--SELECT 0 Success, 'La Orden ya se encuentra asociada no se puede eliminar GATPartsToluca' Msg
												--END
										END
									ELSE
										BEGIN
											SELECT 0 Success, 'Orden registrada en Bpro con estados procesado que no se puede eliminar GATPartsToluca' Msg
										END
								END
							ELSE IF(@idContratoOperacion = 5 or @idContratoOperacion = 17)
								BEGIN
									SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_STATUS] IN(0,1,2) AND [OTE_ORDENANDRADE] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
									INSERT INTO @tableTemp EXEC(@queryText) 
									SET @existe = (SELECT TOP 1 val FROM @tableTemp)

									IF(@existe = 1)
										BEGIN
											IF NOT EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
												BEGIN
												SELECT 1 Success, 'La Orden se quito la provision exitosamente GAIntegra' Msg
													IF EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
													BEGIN
														UPDATE AprobacionProvision
														SET estatus=0
														where idOrden=@idOrden
													END
														SET @OTD_IDENT = 'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
													SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET] WHERE [OTD_IDENT] = ('+@OTD_IDENT+') '
													SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
													EXEC(@queryM) EXEC(@queryH) 
												END
											ELSE
												BEGIN
													SELECT 0 Success, 'La Orden ya se encuentra asociada no se puede eliminar GAIntegra' Msg
												END
										END
									ELSE
										BEGIN
											SELECT 0 Success, 'Orden registrada en Bpro con estados procesado que no se puede eliminar GAIntegra' Msg
										END
								END
					 --SELECT 1 Proceso
			END
		ELSE
			BEGIN

				IF(@isProduction = 1)
				BEGIN
					SELECT 
								@server = SERVER,
								@db = DBProduccion
						FROM CatalogoTecnico CT 
						WHERE CT.IdProveedor =  @idProveedor
					END
				ELSE
					BEGIN
						SELECT 
								@server = SERVER,
								@db = DBProduccion
						FROM CatalogoTecnico CT 
						WHERE CT.IdProveedor =  @idProveedor
					END
						BEGIN	
								SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE [oae_estatus] IN(0,1) AND [oae_ordenglobal] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
								INSERT INTO @tableTemp EXEC(@queryText) 
								SET @existe = (SELECT TOP 1 val FROM @tableTemp)
								print @queryText
								IF(@existe = 1)
									BEGIN
										IF NOT EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
											BEGIN
												SELECT 1 Success, 'La Orden se quito la provision exitosamente GATPartsDHL' Msg	
													SET @OTD_IDENT = 'SELECT oae_idorden FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE [oae_ordenglobal] = '''+@numeroOrden+''' '
												SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ser_ordenasedet] WHERE [oad_iddetalle] = ('+@OTD_IDENT+') '
												SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE [oae_ordenglobal] = '''+@numeroOrden+''' '
												EXEC(@queryM) EXEC(@queryH) 
											END
										ELSE
											BEGIN
												SELECT 0 Success, 'La Orden ya se encuentra asociada no se puede eliminar GATPartsDHL' Msg
											END
									END
								ELSE
									BEGIN
										SELECT 0 Success, 'Orden registrada en Bpro con estados procesado que no se puede eliminar GATPartsDHL' Msg
									END
						END
					-- SELECT 1 Proceso
			END
END
go

