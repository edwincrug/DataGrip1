 CREATE PROCEDURE [Gerente].[SEL_RELACION_GERENCIA_SP]
	@idGerencias INT,
	@accion INT
AS
BEGIN
	IF(@accion = 0)
		BEGIN
			IF NOT EXISTS(SELECT 1 FROM [ContratoOperacionUsuarioGerente] WHERE idGerencias=@idGerencias)
				BEGIN
					SELECT 0 AS valida
				END
			ELSE
				BEGIN
					SELECT 1 AS valida
				END
		END
	ELSE IF(@accion = 1)
		BEGIN
			DELETE FROM [ContratoOperacionUsuarioGerente]
			WHERE idGerencias=@idGerencias

			SELECT 1
		END
END


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.SEL_RELACION_GERENCIA_SP to DevOps
 go

