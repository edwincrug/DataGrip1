-- =============================================
-- Create date: 03/10/2017
-- Description:	Stored que consulta ordenes con estatus 1 Citas sin taller
-- [SEL_OPE_APROBACIONES_SP] 3,538,'',0
-- =============================================

 CREATE PROCEDURE [dbo].[SEL_OPE_APROBACIONES_SP]
	@idContratoOperacion INT = 3,
	@idUsuario INT = 489, 
	@numeroOrden VARCHAR(50) = '',
	@idZona int = null,
	@idEjecutivoFiltro INT = null,
	@fechaIni varchar(max) = null,--'2017/09/01 00:00:00',
	@fechaFin varchar(max) = null,--'2017/09/30 23:59:59'
	@estatus int		
AS
BEGIN

	SET NOCOUNT ON; 
	SET DATEFORMAT DMY; 
 
	DECLARE @idCatalogoRol INT  
	DECLARE @idContratoOperacionUsuario INT
	DECLARE @idContratoOperacionUsuarioEjecutivo INT
	DECLARE @idOperacion INT
	DECLARE @select NVARCHAR(MAX) = '' 
	DECLARE @where NVARCHAR(MAX) = '' 
	DECLARE @query NVARCHAR(MAX) = ''
	DECLARE @join NVARCHAR(MAX) = ''
	DECLARE @usuario NVARCHAR(MAX) = '' 
	DECLARE @zonas NVARCHAR(MAX) = ''
	DECLARE @zonasEjecutivo NVARCHAR(MAX) = ''
	DECLARE @groupBy NVARCHAR(MAX)

	SELECT @idContratoOperacionUsuario = COU.idContratoOperacionUsuario, @idCatalogoRol = COU.idCatalogoRol, @idOperacion = CO.idOperacion
	FROM Usuarios U 
		JOIN ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
		JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
	WHERE U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	IF(@idCatalogoRol <> 2)
		BEGIN
		    IF(@idCatalogoRol <> 4)
				BEGIN
					IF(@idCatalogoRol <> 9)
						BEGIN
							SET @usuario  = 'AND Z.idZona in (SELECT idZona FROM ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = '+ convert(varchar(5), @idContratoOperacionUsuario) +') '
						END
					ELSE
						BEGIN
							SET @usuario  = 'AND Z.idZona in (SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
												JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
												JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
											WHERE EG.estatus=0 AND EZ.estatus=0 
											AND COUG.idContratoOperacionUsuario='+ convert(varchar(5), @idContratoOperacionUsuario) +' AND EZ.idContratoOperacion='+ convert(varchar(5), @idContratoOperacion) +') '
						END
				END
			ELSE
				BEGIN
					set @usuario  = ' AND C.idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idOperacion)+')) '
				END
		END
	
	SET @select = 
		'SELECT 
		(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente,
		O.consecutivoOrden,
		O.numeroOrden,
		U.numeroEconomico,
		Z.nombre AS nombreZona,
		CTO.nombreTipoOrdenServicio AS nombreTipoOrdenServicio,
		O.fechaCreacionOden,
		CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <=''12/11/2018'' THEN 1
		ELSE 0 END
		AS aplicaFondo,	
		ISNULL(O.comentarioOrden, '''') AS comentarioOrden,
		C.numeroCotizacion,
		EC.[idEstatusCotizacion],
		EC.[nombreEstatusCotizacion] AS nombreEstatusCotizacion,
		TP.TienePresupuesto AS tienePresupuesto,
		UR.nombreCompleto AS nombreUsuario,
		UR.idUsuario,
		ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)  venta,
		ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) costo,
		--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 2,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS venta,
		--(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 2,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS costo,
		DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEspera,
		O.idOrden,
		Z.idZona
	FROM Ordenes O
		INNER JOIN Cotizaciones C ON C.idOrden = O.idOrden
		INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion
		INNER JOIN Unidades U ON U.idUnidad = O.idUnidad
		INNER JOIN EstatusCotizaciones EC ON EC.idEstatusCotizacion = C.idEstatusCotizacion
		INNER JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
		INNER JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
		INNER JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden AND HE.fechaFinal is null
		INNER JOIN Usuarios UR ON UR.idUsuario = C.idUsuario
		LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
		LEFT JOIN VwTienePresupuesto TP on TP.idOrden = O.idOrden '
		
	IF EXISTS(select preAprobacion from Operaciones WHERE idOperacion=@idOperacion AND ISNULL(preAprobacion,0)=1)
		BEGIN
			SET @where = 'WHERE CO.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+' AND O.idEstatusOrden IN(4,5) AND C.idEstatusCotizacion IN(1,2) AND CD.idEstatusPartida in (1,2)
				  AND C.idCotizacion IN(select idCotizacion from PreAprobacion where estatus = 0)
				  AND O.idZona = COALESCE('+COALESCE(convert(varchar(max),@idZona),'NULL')+', O.idZona)
				  AND O.idUsuario = COALESCE(' + COALESCE(convert(varchar(max),@idEjecutivoFiltro),'NULL')+ ',O.idUsuario)
				  AND O.fechaCreacionOden between COALESCE(' + COALESCE(''''+@fechaIni+'''', 'NULL') + ',O.fechaCreacionOden) and COALESCE(' + COALESCE(''''+@fechaFin+'''', 'NULL') + ',O.fechaCreacionOden)
				  AND C.idEstatusCotizacion = COALESCE('+COALESCE(convert(varchar(max),@estatus), 'NULL')+', C.idEstatusCotizacion)'
		END
	ELSE
		BEGIN
			SET @where = 'WHERE CO.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+' AND O.idEstatusOrden IN(4,5) AND C.idEstatusCotizacion IN(1,2) AND CD.idEstatusPartida in (1,2)
				  AND O.idZona = COALESCE('+COALESCE(convert(varchar(max),@idZona),'NULL')+', O.idZona)
				  AND O.idUsuario = COALESCE(' + COALESCE(convert(varchar(max),@idEjecutivoFiltro),'NULL')+ ',O.idUsuario)
				  AND O.fechaCreacionOden between COALESCE(' + COALESCE(''''+@fechaIni+'''', 'NULL') + ',O.fechaCreacionOden) and COALESCE(' + COALESCE(''''+@fechaFin+'''', 'NULL') + ',O.fechaCreacionOden)
				  AND C.idEstatusCotizacion = COALESCE('+COALESCE(convert(varchar(max),@estatus), 'NULL')+', C.idEstatusCotizacion)'
		END
	
	SET @groupBy = 'GROUP BY O.idOrden, O.idGarantia, O.numeroOrden, O.fechaCita, O.fechaCreacionOden, O.fechaInicioTrabajo, HE.fechaInicial, O.comentarioOrden, U.[numeroEconomico], 
	[consecutivoOrden], [requiereGrua], Z.[idZona], Z.nombre, U.[idUnidad], O.[idContratoOperacion], Ur.[idUsuario] , Ur.nombreCompleto, CTO.[idCatalogoTipoOrdenServicio], 
	CTO.[nombreTipoOrdenServicio], C.[idEstatusCotizacion], C.idCotizacion, C.[numeroCotizacion], EC.idEstatusCotizacion, EC.[nombreEstatusCotizacion], TP.TienePresupuesto, C.numeroCotizacion'

	IF(@numeroOrden != '')
	  BEGIN
		SET @numeroOrden =' AND O.numeroOrden like ''%'+@numeroOrden+'%'''
	  END

	SET @query = @select + @where + @usuario + @numeroOrden + @groupBy
	EXECUTE SP_EXECUTESQL @query
	PRINT @query
END
go

