-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03/06/2017
-- [SEL_VALIDA_SESION_ACTIVA_SP] 189,29764
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDA_SESION_ACTIVA_SP] 
	@idUsuario numeric(18,0),
	@idSesion int
AS
BEGIN
	DECLARE @sesionesActivas int = (SELECT count([idHistorialLogin])
	FROM [dbo].[HistorialLogin] as HL 
	INNER JOIN [dbo].[Usuarios] AS US ON US.idUsuario = HL.idUsuario
	WHERE US.[idUsuario] = @idUsuario and idHistorialLogin = @idSesion and [FechaFin] IS NULL)
	
	IF NOT EXISTS(SELECT 1 FROM Usuarios U JOIN ContratoOperacionUsuario CO ON CO.idUsuario = U.idUsuario WHERE CO.idContratoOperacion=3 AND CO.idCatalogoRol=1 AND CO.idUsuario=@idUsuario)
		BEGIN
			IF (@sesionesActivas > 0)
					BEGIN
						SELECT 'True' AS HasSession
					END
			ELSE
					BEGIN
						SELECT 'False' AS HasSession
					END
		END
	ELSE
		BEGIN
			SELECT 'True' AS HasSession
		END
END
go

