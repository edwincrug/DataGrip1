-- =============================================
-- Author:		YJH
-- Create date: 03/08/2018
-- Description:	Reporte de piezas vendidas por marca
-- Banorte.SEL_PIEZASVENDIDAS 3, 18
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_PIEZASVENDIDAS]
	@idMarca int,
	@idContratoOperacion int, 
	@isProduction int 
AS
BEGIN

DECLARE @db NVARCHAR(100)
DECLARE @query NVARCHAR(max)

IF(@isProduction = 1)
    BEGIN
        SELECT                 
               @db= SERVER+'.'+DBProduccion
        FROM ASEPROT.dbo.ContratoOperacionFacturacion 
        WHERE idContratoOperacion =  @idContratoOperacion
    END
ELSE
    BEGIN
        SELECT 
                @db=DB
        FROM ASEPROT.dbo.ContratoOperacionFacturacion
		WHERE idContratoOperacion = @idContratoOperacion
	END

	set @query='select distinct O.idOrden, C.idCotizacion, 
		CD.idCotizacionDetalle, PP.PTS_IDPARTESINESPACIOS as noParte, P.descripcion, 
		isnull(CD.precioLista,0) as lista, 
		CD.venta,
		AC.COP_IDDOCTO as numFactura,AC.COP_FECHOPE as fecha, CD.cantidad, PR.pre_pedidobpro as pedido,
		SI.numeroReclamo
	from ASEPROT.dbo.Ordenes O
	inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden
	inner join ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
	inner join Partidas.dbo.Partida P on P.idPartida = CD.idPartida
	inner join '+@db+'.dbo.ADE_COPADE AC on AC.COP_ORDENGLOBAL = O.numeroOrden collate Modern_Spanish_CI_AS
	inner join RefaccionMultiMarca.Catalogo.Par_Partes PP on PP.PTS_IDPARTE =P.noParte
	inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden	 and SOC.idCotizacionSisco =C.idCotizacion
	inner join RefaccionMultiMarca.Operacion.Siniestro SI on SI.id = SOC.idSiniestro
	LEFT JOIN [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PR ON SOC.idCotizacion = PR.pre_idcotizacion
	where O.idContratoOperacion='+ CAST(@idContratoOperacion as varchar(25))  +' and AC.COP_IDDOCTO is not null
	and PP.idMarca=' + CAST(@idMarca as varchar(25)) + ' and CD.cantidad > 0 and PR.pre_pedidobpro <> 0 '

	exec(@query) 
END
go

grant execute, view definition on Banorte.SEL_PIEZASVENDIDAS to DevOps
go

