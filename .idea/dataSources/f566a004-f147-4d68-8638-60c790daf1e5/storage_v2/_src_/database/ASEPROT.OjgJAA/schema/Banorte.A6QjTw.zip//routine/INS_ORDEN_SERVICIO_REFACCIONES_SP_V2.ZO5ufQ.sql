
CREATE PROCEDURE [Banorte].[INS_ORDEN_SERVICIO_REFACCIONES_SP_V2] 
	@idUnidad NUMERIC(18,0), 	
	@comentario VARCHAR(500),
	@idZona  NUMERIC(18,0),	
	@taller INT, 
	@idUsuario  NUMERIC(18,0),
	@idBproTaller INT=0,
	@idTipoOrdenServicio NUMERIC(18,0)=1,
	@idEstatus int = 1
AS
BEGIN
	DECLARE 	
	@idEstadoUnidad NUMERIC(18,0) = 2,
	@grua INT = 0,
	@especialidades nvarchar(5)='',
	@idCentroTrabajo INT=0,
	@Tipo_Servicio INT=0,
	@evento INT =0,
	@estatusOrden INT =5,
	------------------
	@idOperacion NUMERIC(18,0),	
	@numeroEconomico VARCHAR(50), 
	@idContratoOperacion NUMERIC(18,0), 
	@consecutivoOrden INT,
	@numeroOrden varchar(20)
	
	
	--Obtengo los datos necesarios de la unidad para formar el numero de la orden para el campo [numeroOrden]
	SELECT @idOperacion = UNI.idOperacion, @numeroEconomico = numeroEconomico, @idContratoOperacion = CP.idContratoOperacion
	FROM [Unidades] UNI
	INNER JOIN [ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion
	WHERE idUnidad = @idUnidad

	--Obtengo el consecutivo para formar el numero de la orden 
	IF (EXISTS(SELECT TOP 1 consecutivoOrden FROM [Ordenes] WHERE idContratoOperacion = @idContratoOperacion))
		BEGIN
			SET @consecutivoOrden = (SELECT TOP 1 consecutivoOrden FROM [Ordenes] WHERE idContratoOperacion = @idContratoOperacion ORDER BY consecutivoOrden DESC) +1
		END
	ELSE 
		BEGIN
			SET @consecutivoOrden = 1
		END
	
	--Si el usuario no selecciono taller el estatus de la orden debe crearce con 1  	
	--Si @taller = 1 significa que se selecciono un taller para la orden de servicio por lo cual el idEstatusOrden debe nacer en 2 	
	
	DECLARE @idOrdenServicio INT, 
			@idGrua INT
	select @numeroOrden = ISNULL(RIGHT('00' + CAST(@idContratoOperacion AS varchar(2)), 2),'S/N')  + '-' + ISNULL(convert(varchar(max),@idUnidad),'S/N') + '-' + ISNULL(RIGHT( CAST(@consecutivoOrden AS varchar(6)), 6),'S/N')
	INSERT INTO [Ordenes] 
		([fechaCreacionOden], [fechaCita], [fechaInicioTrabajo], [numeroOrden], [consecutivoOrden]
		,[comentarioOrden], [requiereGrua], [idCatalogoEstadoUnidad], [idZona], [idUnidad]
		,[idContratoOperacion], [idUsuario], [idCatalogoTipoOrdenServicio], [idTipoOrden]
		,[idEstatusOrden], [idCentroTrabajo], [idTaller], [idGarantia], [motivoGarantia], [idBproProveedor])
	    values (GETDATE(), GETDATE(), GETDATE(),
		@numeroOrden,
		@consecutivoOrden, @comentario, @grua, @idEstadoUnidad, @idZona, @idUnidad, @idContratoOperacion,
		@idUsuario, @idTipoOrdenServicio, 1, @idEstatus, @idCentroTrabajo, @taller, 0, '', @idBproTaller)
		
	SET @idOrdenServicio = @@IDENTITY
		
	UPDATE Unidades set Ultimo_Servicio = @evento where idUnidad=@idUnidad

	declare @id int =1
	
	while (@id <= @idEstatus)
	begin 
		INSERT INTO [HistorialEstatusOrden] (
			[idOrden], [idEstatusOrden], [fechaInicial], [fechaFinal], [idUsuario] )
			VALUES (@idOrdenServicio, @id,GETDATE(), GETDATE(), @idUsuario)

		select @id = @id+1
	end

	DECLARE @numeroOrdenes INT = 0;
		SELECT @numeroOrdenes = COUNT(idOrden) FROM [Ordenes] WHERE idUnidad = @idUnidad AND idEstatusOrden = @estatusOrden
		
			select @idOrdenServicio as idOrden, @numeroOrden as numeroOrden		
END


go

grant execute, view definition on Banorte.INS_ORDEN_SERVICIO_REFACCIONES_SP_V2 to DevOps
go

