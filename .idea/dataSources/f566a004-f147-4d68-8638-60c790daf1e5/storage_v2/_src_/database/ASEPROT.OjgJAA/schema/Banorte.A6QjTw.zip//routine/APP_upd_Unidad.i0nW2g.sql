-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 08/08/2018
-- Description:	Actualizar la unidad por id, solo para unidades registradas en app banorte
-- =============================================
 CREATE PROCEDURE [Banorte].[APP_upd_Unidad]
	@idUsuario			INT,
	@idUnidad			int,
	@nombreFisico		nvarchar(max) = null,
	@alias				NVARCHAR (max),
	@poliza				varchar(100) = null,
	@placas				NVARCHAR(50)
AS
BEGIN

	IF(@poliza = 'null')
	BEGIN
		SET @poliza = NULL
	END

IF exists (select 
				u.idUnidad 
			from unidades u 
				inner join usuarioUnidadContratoOperacion uuco on u.idUnidad = uuco.idUnidad
			where u.idUnidad = @idUnidad 
				and uuco.idUnidad = @idUnidad 
				and uuco.idUsuario = @idUsuario)
		Begin

			IF (@nombreFisico IS NULL)
			BEGIN
				update unidades set
					descripcion = @alias
					,noPoliza = @poliza
					,placas = @placas
				where idunidad = @idUnidad
			END
			ELSE
			BEGIN
				update unidades set
					frente = @nombreFisico
					,descripcion = @alias
					,noPoliza = @poliza
					,placas = @placas
				where idunidad = @idUnidad
			END

			SELECT @@ROWCOUNT actualizado, 'La unidad se actualizó de forma correcta' mensaje

			EXEC [Mobile].[Add_Poliza_Sp] @idUnidad, @poliza

			Select u.[idUnidad]
				,u.[descripcion] alias
				,u.[noPoliza] noPoliza
				,p.[numero] noPoliza
				,u.[vin] serie
				,u.[placas]
				,u.[frente] foto 
			from [dbo].[Unidades] u 
				LEFT JOIN (SELECT id, numero, estatus, idUnidad FROM [Mobile].[Poliza] WHERE estatus = 1) p
				ON u.idUnidad = p.idUnidad
			--LEFT JOIN [Mobile].[Poliza] p ON u.idUnidad = p.idUnidad 
			where u.idUnidad = @idUnidad
		End
	ELSE
		Begin
			SELECT 0 actualizado, 'La unidad no se encuentra' mensaje
		End

END
go

grant execute, view definition on Banorte.APP_upd_Unidad to DevOps
go

