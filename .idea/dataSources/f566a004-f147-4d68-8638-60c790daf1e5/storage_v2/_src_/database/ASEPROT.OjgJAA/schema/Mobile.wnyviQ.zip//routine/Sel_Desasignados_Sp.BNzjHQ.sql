-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 10/08/2018
-- Description:	Obtener los mensajes de los usuarios desasignados
-- EXEC [Mobile].[Sel_Desasignados_Sp] 683
-- =============================================
CREATE PROCEDURE [Mobile].[Sel_Desasignados_Sp]
	@idUsuario			int
AS
BEGIN

	SELECT 
		id
		,idUsuario
		,idUnidad
		,vin
		,placas
		,noPoliza
		,descripcion
		,desasignado
		,visto
	FROM [ASEPROT].[Mobile].[UsuarioUnidadContratoOperacionDesAsignado] 
	WHERE idUsuario = @idUsuario
		AND visto = 0

END
go

grant execute, view definition on Mobile.Sel_Desasignados_Sp to DevOps
go

