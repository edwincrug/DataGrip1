CREATE PROC [dbo].[INS_ORDEN_PAGO_PROVISION_SP_errores]
@numeroorden NVARCHAR(100)

AS
BEGIN
	
	--select * from ordenes where numeroorden = '57-PMX11612-711'
	--select * from presupuestoorden where idorden = 104194


	--declare @numeroorden NVARCHAR(100) = '57-PMX09366-348' 

	declare @idOrden NUMERIC(18,0)
	DECLARE @idPresupuestoOrden NUMERIC(18,0)
	DECLARE @IdZona INT
	DECLARE @Consecutivo INT
	DECLARE @Zona NVARCHAR(100)
	DECLARE @idCentroTrabajo INT
	DECLARE @numTAR INT

	select @idOrden = idorden from ordenes where numeroorden = @numeroorden

	select @idPresupuestoOrden = idpresupuestoorden from presupuestoorden where idorden = @idOrden

	SELECT @IdZona=idZona, @idCentroTrabajo=idCentroTrabajo FROM Ordenes WHERE idOrden = @idOrden

	declare @zonaPadre table(ID INT, idPadre INT, nombreNivel varchar(50), nombre varchar(50))
	insert into @zonaPadre
	EXEC [SEL_ZONAS_PADRES_SP]  @IdZona

	select top 1 @Zona = SUBSTRING(nombre, 1, 1) from @zonaPadre

	UPDATE [PresupuestoOrden]
	SET zona = @Zona
	WHERE idPresupuestoOrden = @idPresupuestoOrden

	SELECT @Consecutivo = ISNULL(MAX(consecutivo),0) + 1 FROM PresupuestoOrden WHERE zona = @Zona

	UPDATE [PresupuestoOrden]
	SET consecutivo = @Consecutivo
	WHERE idPresupuestoOrden = @idPresupuestoOrden

	SELECT @numTAR = extra1 FROM CentroTrabajos WHERE idCentroTrabajo=@idCentroTrabajo

	UPDATE [PresupuestoOrden]
	SET folio = 'RC-GLR' + @Zona + '-' + CONVERT(VARCHAR(5), @numTAR) + '-' + RIGHT('00000' + CONVERT(VARCHAR(5), @Consecutivo),5) + '-' + CONVERT(varchar(10), YEAR(GETDATE()))
	WHERE idPresupuestoOrden = @idPresupuestoOrden

	print @numTAR

end
go

