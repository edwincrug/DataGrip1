-----------------------------------------------
-- [SEL_HISTORIAL_UNIDAD_SP] '12',1,1
-- SELECT * FROM UNIDADES
-----------------------------------------------
create PROCEDURE [dbo].[SEL_HISTORIAL_UNIDAD_SP]
	@numeroEconomico VARCHAR(100),
	@tipoConsulta INT,
	@idOperacion INT

AS
BEGIN

	SET NOCOUNT ON;
	IF(@tipoConsulta = 1)
		BEGIN
			SELECT 
				O.consecutivoOrden,
				O.numeroOrden,
				CLI.nombreComercial as Cliente,
				U.numeroEconomico,
				SM.nombre +' '+ M.nombre +' '+ U.modelo unidad, 
				CTOS.nombreTipoOrdenServicio,
				O.fechaCreacionOden  as fechaCreacionOrden,
				(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idOrden=O.idOrden AND idEstatusOrden=6)fechaFin,
				(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idOrden=O.idOrden AND idEstatusOrden=7)fechaInicioReal,
				(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idOrden=O.idOrden AND idEstatusOrden=6)fechaCertificadoGenerado,
				(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idOrden=O.idOrden AND idEstatusOrden=8)CertificadoDescargadoCliente,
				(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idOrden=O.idOrden AND idEstatusOrden=4)fechaAprobacion,
				EO.nombreEstatusOrden,
				O.comentarioOrden,
				Z.nombre,
				[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) talleres
			FROM Ordenes O
				JOIN Unidades U ON U.idUnidad = O.idUnidad
				JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
				JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
				JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
				JOIN Partidas..Zona Z ON Z.idZona = O.idZona
				JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
				JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
				JOIN ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
				JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
				JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
				JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
				JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
			WHERE O.idEstatusOrden NOT IN(13)
			AND U.numeroEconomico LIKE'%'+@numeroEconomico+'%'
			AND OPE.idOperacion = @idOperacion
		END
	ELSE
		BEGIN
			SELECT 
				O.consecutivoOrden,
				O.numeroOrden,
				CLI.nombreComercial as Cliente,
				U.numeroEconomico,
				SM.nombre +' '+ M.nombre +' '+ U.modelo unidad, 
				CTOS.nombreTipoOrdenServicio,
				O.fechaCreacionOden  as fechaCreacionOrden,
				EO.nombreEstatusOrden,
				O.comentarioOrden,
				Z.nombre,
				COTI.fechaCotizacion,
				(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idOrden=O.idOrden AND idEstatusOrden=5)fechaAutorizacionCot,
				COTI.numeroCotizacion,
				[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) talleres
			FROM Ordenes O
				JOIN Unidades U ON U.idUnidad = O.idUnidad
				JOIN Partidas..Zona Z ON Z.idZona = O.idZona
				JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
				JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
				JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
				JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
				JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
				JOIN Cotizaciones COTI on COTI.idOrden = O.idOrden
				--JOIN CotizacionDetalle CD on CD.idCotizacion = COTI.idCotizacion
				JOIN ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
				JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
				JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
				JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
				JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
			WHERE O.idEstatusOrden NOT IN(13)
			AND U.numeroEconomico LIKE'%'+@numeroEconomico+'%'
			AND OPE.idOperacion = @idOperacion

		END
END

select * from EstatusOrdenes
go

