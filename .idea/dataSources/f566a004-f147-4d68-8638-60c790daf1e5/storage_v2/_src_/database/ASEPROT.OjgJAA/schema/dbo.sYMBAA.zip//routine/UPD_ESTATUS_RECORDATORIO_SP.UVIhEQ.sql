--select * from Recordatorio

-- [INS_RECORDATORIO_SP] 'uno', '03/017/2017',5, 3,10

CREATE PROCEDURE [dbo].[UPD_ESTATUS_RECORDATORIO_SP]
  @idRecordatorio INT 


AS
BEGIN
			
		UPDATE Recordatorio 
		SET
			idEstatus = 0
		WHERE idRecordatorio = @idRecordatorio

		SELECT @idRecordatorio
			
		
END

go

