


-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 31/05/2017
-- Description:	Devuelve los resultados del cuadrante de Ordenes por Cobrar en el Dashboard
-- ==========================================================================================
-- [dbo].[SEL_DASHBOARD_ORDENES_COBRAR_GATPARTSASE_SP] 3, null, 538, 1
CREATE PROCEDURE [dbo].[SEL_DASHBOARD_ORDENES_COBRAR_GATPARTSASE_SP] --15,null,null,1
@idOperacion NUMERIC(20,0),
@idZona NUMERIC( 20,0 ),
@idUsuario NUMERIC(18,0) = NULL,
@isProduction int = 1
AS
BEGIN

	
DECLARE	@server  NVARCHAR(MAX) = ''
DECLARE	@db  NVARCHAR(MAX) = ''		
DECLARE @query NVARCHAR(MAX) = ''
DECLARE @idContratoOperacionUsuario int;

DECLARE @rolUsuario int = [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion)

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server = SERVER,
				@db = DBProduccion			
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB								
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END

DECLARE @Cobranza TABLE( idEstatus NUMERIC(18), 
						estatus VARCHAR(MAX), 
						total NUMERIC(18), 
						promedio NUMERIC(18), 
						color VARCHAR(9), 
						Monto NUMERIC(18,2), 
						MontoCosto NUMERIC(18,2) );


DECLARE @idEstatusOrden NUMERIC(13) = 8;
WHILE (@idEstatusOrden < 13)
	BEGIN
		/*IF( @idZona = 0 )
			BEGIN
				set @idZona = null
			END*/
		IF @rolUsuario <> 2
			BEGIN
				IF @rolUsuario <> 4
					BEGIN
					--------------------CLIENTE-------------------------------						
					SELECT @idContratoOperacionUsuario = COU.idContratoOperacionUsuario
					FROM Usuarios U 
						JOIN ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
						JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
					WHERE U.idUsuario = @idUsuario and CO.idOperacion = @idOperacion

					IF @idEstatusOrden = 8
						BEGIN
						INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
							((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
							isnull(sum(venta),0) as venta,
							isnull(sum(costo),0) as costo
							from (select								
								(SELECT [dbo].[SEL_NOMBRE_CLIENTE](O.idContratoOperacion)) AS nombreCliente,
								O.consecutivoOrden,
								O.numeroOrden,
								U.numeroEconomico,
								Z.nombre AS nombreZona,
								CTO.nombreTipoOrdenServicio,
								O.fechaCreacionOden,	
								O.comentarioOrden,
								EO.nombreEstatusOrden,
								UR.nombreCompleto,
								(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS venta,
								(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS costo,
								DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEsperaTranscurrido,
								O.idOrden,
								Z.idZona
							FROM Ordenes O
								JOIN Unidades U ON U.idUnidad = O.idUnidad
								JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
								JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
								JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
								JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
								JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
								JOIN Partidas..Zona Z ON Z.idZona = O.idZona WHERE CO.idOperacion = @idOperacion AND O.idEstatusOrden = @idEstatusOrden AND Z.idZona in (SELECT idZona FROM ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario) 
						)as sel))
						END
					IF @idEstatusOrden = 9
						BEGIN
					------------------------PREFACTURA INI-------------------------
					INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
							((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
							isnull(sum(total),0) as venta,
							isnull(sum(subtotal),0) as costo
							from (SELECT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,

								dc.numeroCopade As numeroCopade,
								dc.ordensurtimiento As ordenSurtimiento,
								dc.numeroEstimacion As numeroEstimaicon,
								dc.descripcion As descripcion,
								dc.subTotal As subTotal,
								dc.total As Total,
								ade.COP_IDDOCTO,
								dc.fechaRecepcionCopade As fechaCopade

									FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
								inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
								inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
								inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
								inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
								inner join Ordenes o on o.idOrden = dco.idOrden 
								inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion 
								where ade.COP_STATUS = 1 and co.idOperacion = @idOperacion
					)as sel))
					------------------------PREFACTURA END-------------------------
					END	
					IF @idEstatusOrden = 10
						BEGIN
						------------------------ENVIADAS Ini-------------------------
						INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
							((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
							isnull(sum(total),0) as venta,
							isnull(sum(subtotal),0) as costo
							from (SELECT DISTINCT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
										dc.numeroCopade,dc.ordensurtimiento,
										dc.numeroEstimacion,dc.descripcion,
										dc.subTotal as subtotal,[COP_IDDOCTO],
										dc.total,dc.fechaRecepcionCopade
									FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
										inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
										inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
										inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
										inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
										inner join Ordenes o on o.idOrden = dco.idOrden 
										inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
										where ade.COP_STATUS = 2 and co.idOperacion = @idOperacion )as sel))
						------------------------ENVIADAS Ini-------------------------
						END
					/*IF @idEstatusOrden = 11
						BEGIN
						------------------------ENVIADAS Ini-------------------------
						INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
							((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
							isnull(sum(total),0) as venta,
							isnull(sum(subtotal),0) as costo
							from (SELECT DISTINCT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
										dc.numeroCopade,dc.ordensurtimiento,
										dc.numeroEstimacion,dc.descripcion,
										dc.subTotal as subtotal,[COP_IDDOCTO],
										dc.total,dc.fechaRecepcionCopade
									FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
										inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
										inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
										inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
										inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
										inner join Ordenes o on o.idOrden = dco.idOrden 
										inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
										where ade.COP_STATUS = 4 and co.idOperacion = @idOperacion )as sel))
						------------------------ENVIADAS Ini-------------------------
						END*/
					IF @idEstatusOrden = 12
						BEGIN
					------------------------ENVIADAS Ini-------------------------
					INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
							((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
							isnull(sum(total),0) as venta,
							isnull(sum(subtotal),0) as costo
							from (SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
								dc.numeroCopade,
								dc.ordensurtimiento,
								dc.numeroEstimacion,
								dc.descripcion,
								dc.subTotal,
								[COP_IDDOCTO],
								dc.total,
								dc.fechaRecepcionCopade
								FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
								inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
								inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
								inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
								inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
								inner join Ordenes o on o.idOrden = dco.idOrden 
								inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
								inner join Partidas..Zona z on z.idZona = o.idZona
								inner join Unidades u on u.idUnidad = o.idUnidad
								inner join CatalogoTipoOrden t on t.idTipoOrden = o.idTipoOrden
								inner join EstatusOrdenes e on e.idEstatusOrden = o.idEstatusOrden

									where ade.COP_STATUS = 3 
											and co.idOperacion = @idOperacion
											and o.idZona in(
											select distinct idZona from ContratoOperacionUsuarioZona couz 
																	join ContratoOperacionUsuario cou on cou.idContratoOperacionUsuario=couz.idContratoOperacionUsuario
											where idUsuario = @idUsuario
											)
						)as sel))
					------------------------ENVIADAS Ini-------------------------
					END
					--------------------CLIENTE-------------------------------
					END
				ELSE
					BEGIN
					--------------------PROVEDOR-------------------------------
					IF @idEstatusOrden = 8
						BEGIN
						INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
							((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
							isnull(sum(venta),0) as venta,
							isnull(sum(costo),0) as costo
							from (SELECT 
									(SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente,
									O.consecutivoOrden,
									O.numeroOrden,
									U.numeroEconomico,
									Z.nombre AS nombreZona,
									CTO.nombreTipoOrdenServicio,
									O.fechaCreacionOden,	
									O.comentarioOrden,
									EO.nombreEstatusOrden,
									UR.nombreCompleto,
									(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS venta,
									(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS costo,
									DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEsperaTranscurrido,
									O.idOrden,
									Z.idZona
								FROM Ordenes O
									JOIN Unidades U ON U.idUnidad = O.idUnidad
									JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
									JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
									JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
									JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
									JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
									JOIN Partidas..Zona Z ON Z.idZona = O.idZona WHERE CO.idOperacion = @idOperacion AND O.idEstatusOrden = @idEstatusOrden 
									AND (SELECT CASE WHEN EXISTS (SELECT 1 FROM Cotizaciones C where C.idOrden = O.idOrden and C.idEstatusCotizacion in (3) AND C.idTaller in (SELECT COUP.idProveedor
										FROM ContratoOperacionUsuario COU 
										INNER JOIN ContratoOperacion CO on CO.idContratoOperacion = COU.idContratoOperacion
										INNER JOIN ContratoOperacionUsuarioProveedor COUP ON COUP.idContratoOperacionUsuario =  COU.idContratoOperacionUsuario
										WHERE COU.idUsuario = @idUsuario and CO.idOperacion = @idOperacion) ) THEN 'true' ELSE 'false' END ) = 'true') as tab1 ))
						END
					IF @idEstatusOrden = 9
					BEGIN
					------------------------PREFACTURA INI-------------------------
					INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					isnull(sum(total),0) as venta,
					isnull(sum(subtotal),0) as costo
					from (SELECT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
						dc.numeroCopade As numeroCopade,
						dc.ordensurtimiento As ordenSurtimiento,
						dc.numeroEstimacion As numeroEstimaicon,
						dc.descripcion As descripcion,
						dc.subTotal As subTotal,
						dc.total As Total,
						ade.COP_IDDOCTO,
						dc.fechaRecepcionCopade As fechaCopade
							FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
						inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
						inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
						inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
						inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
						inner join Ordenes o on o.idOrden = dco.idOrden 
						inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion 
						inner join Cotizaciones c on c.idOrden=o.idOrden  
										where co.idOperacion = @idOperacion and c.idTaller in (
												select coup.idProveedor from ContratoOperacionUsuario cou 
														join ContratoOperacionUsuarioProveedor coup on cou.idContratoOperacionUsuario=coup.idContratoOperacionUsuario and cou.idUsuario = @idUsuario
										) ) as tab1 ))
					------------------------PREFACTURA END-------------------------
					END	
					IF @idEstatusOrden = 10
					BEGIN
					------------------------ENVIADAS Ini-------------------------
					INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					isnull(sum(total),0) as venta,
					isnull(sum(subtotal),0) as costo
					from (SELECT DISTINCT
						(SELECT [dbo].[SEL_NOMBRE_CLIENTE](O.idContratoOperacion)) nombreCliente,
						DC.numeroCopade,
						ISNULL(DC.ordenSurtimiento, 'SIN SURTIMIENTO')as folio,
						ISNULL(DC.total,0) total,
						Z.nombre,
						COP.COP_IDDOCTO,
						COP.COP_CARGO,
						(COP.COP_CARGO - COP.COP_SALDO ) abono,
						COP.COP_SALDO,
						ISNULL(COP.COP_FECHULTPAG, '') AS COP_FECHULTPAG,
						DC.descripcion,
						COP.COP_FECHOPE,	
						DC.idDatosCopade,
						COP.COP_ORDENGLOBAL,
						TA.idOrdenAgrupada,
						DC.fechaRecepcionCopade,
						DC.subTotal,
						DC.numeroEstimacion
						FROM DatosCopade DC 
						JOIN DatosCopadeOrden DCO ON DCO.idDatosCopade = DC.idDatosCopade
						JOIN Ordenes O ON O.idOrden = DCO.idOrden 
						JOIN ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
						JOIN Cotizaciones C ON C.idOrden = O.idOrden
						LEFT JOIN FacturaCotizacion FCO ON FCO.idCotizacion = C.idCotizacion
						JOIN Unidades U ON U.idUnidad=O.idUnidad
						JOIN Partidas..Zona Z ON Z.idZona = O.idZona
						JOIN OrdenAgrupadaDetalle TAD ON TAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
						JOIN OrdenAgrupada TA ON TA.idOrdenAgrupada = TAD.idOrdenAgrupada
						--LEFT JOIN [cobranza].[VwStatusCotizacion] VSC ON VSC.[idCotizacion] = C.[idCotizacion]
						JOIN [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] COP ON COP.COP_ORDENGLOBAL = TA.numero COLLATE Modern_Spanish_CS_AS    
									where co.idOperacion = @idOperacion and c.idTaller in (
											select coup.idProveedor from ContratoOperacionUsuario cou 
													join ContratoOperacionUsuarioProveedor coup on cou.idContratoOperacionUsuario=coup.idContratoOperacionUsuario and cou.idUsuario = @idUsuario
									) ) as tab1 ))
						 							
					------------------------ENVIADAS Ini-------------------------
					END
					/*IF @idEstatusOrden = 11
					BEGIN
					------------------------ENVIADAS Ini-------------------------
					INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					isnull(sum(total),0) as venta,
					isnull(sum(subtotal),0) as costo
					from (SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
						dc.numeroCopade,
						dc.ordensurtimiento,
						dc.numeroEstimacion,
						dc.descripcion,
						dc.subTotal,
						[COP_IDDOCTO],
						dc.total,
						dc.fechaRecepcionCopade
						FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
						inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
						inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
						inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
						inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
						inner join Ordenes o on o.idOrden = dco.idOrden 
						inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
						inner join Partidas..Zona z on z.idZona = o.idZona
						inner join Unidades u on u.idUnidad = o.idUnidad
						inner join CatalogoTipoOrden t on t.idTipoOrden = o.idTipoOrden
						inner join EstatusOrdenes e on e.idEstatusOrden = o.idEstatusOrden  
							where co.idOperacion = @idOperacion and ade.COP_STATUS = 4 
								and o.idOrden in(
								select distinct idOrden from Cotizaciones where idTaller in(
									select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario,@idOperacion)
								)) ) as tab1 ))
						 							
					------------------------ENVIADAS Ini-------------------------
					END*/
					IF @idEstatusOrden = 12
					BEGIN
					------------------------ENVIADAS Ini-------------------------
					INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					isnull(sum(total),0) as venta,
					isnull(sum(subtotal),0) as costo
					from (SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
						dc.numeroCopade,
						dc.ordensurtimiento,
						dc.numeroEstimacion,
						dc.descripcion,
						dc.subTotal,
						[COP_IDDOCTO],
						dc.total,
						dc.fechaRecepcionCopade
						FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
						inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
						inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
						inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
						inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
						inner join Ordenes o on o.idOrden = dco.idOrden 
						inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
						inner join Partidas..Zona z on z.idZona = o.idZona
						inner join Unidades u on u.idUnidad = o.idUnidad
						inner join CatalogoTipoOrden t on t.idTipoOrden = o.idTipoOrden
						inner join EstatusOrdenes e on e.idEstatusOrden = o.idEstatusOrden

							where co.idOperacion = @idOperacion and ade.COP_STATUS = 3 
								and o.idOrden in(
								select distinct idOrden from Cotizaciones where idTaller in(
									select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario,@idOperacion)
								)) ) as tab1 ))
					------------------------ENVIADAS Ini-------------------------
					END
					--------------------PROVEDOR-------------------------------
					END
			END
		ELSE
			BEGIN
			------------------------admin INI------------------------------
			IF @idEstatusOrden = 8
				BEGIN					
				------------------------por cobrar Ini-------------------------
				INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					isnull(sum(venta),0) as venta,
					isnull(sum(costo),0) as costo
					from (SELECT DISTINCT
							(SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente,
							O.consecutivoOrden,
							O.numeroOrden,
							U.numeroEconomico,
							Z.nombre AS nombreZona,
							CTO.nombreTipoOrdenServicio,
							O.fechaCreacionOden,	
							O.comentarioOrden,
							EO.nombreEstatusOrden,
							UR.nombreCompleto,
							(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS venta,
							(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS costo,
							DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEsperaTranscurrido,
							O.idOrden,
							Z.idZona
						FROM Ordenes O
							JOIN Unidades U ON U.idUnidad = O.idUnidad
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
							JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
							JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
							JOIN Partidas..Zona Z ON Z.idZona = O.idZona WHERE CO.idOperacion = @idOperacion AND O.idEstatusOrden = @idEstatusOrden ) as tab1 ))
				------------------------por cobrar Fin-------------------------			
				END		
			IF @idEstatusOrden = 9
				BEGIN
				------------------------PREFACTURA INI-------------------------
				INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					isnull(sum(total),0) as venta,
					isnull(sum(subtotal),0) as costo
					from 
					(	 SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,

						dc.numeroCopade As numeroCopade,
						dc.ordensurtimiento As ordenSurtimiento,
						dc.numeroEstimacion As numeroEstimaicon,
						dc.descripcion As descripcion,
						dc.subTotal As subTotal,
						dc.total As Total,
						ade.COP_IDDOCTO,
						dc.fechaRecepcionCopade As fechaCopade
							FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
						inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
						inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
						inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
						inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
						inner join Ordenes o on o.idOrden = dco.idOrden 
						inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
						where co.idOperacion = @idOperacion and ade.COP_STATUS = 1 ) as sel ))
				------------------------PREFACTURA END-------------------------
				END	
			IF @idEstatusOrden = 10
				BEGIN
				------------------------ENVIADAS Ini-------------------------
				INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					isnull(sum(total),0) as venta,
					isnull(sum(subtotal),0) as costo
					from 
					(	 SELECT DISTINCT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
								dc.numeroCopade,dc.ordensurtimiento,
								dc.numeroEstimacion,dc.descripcion,
								dc.subTotal as subtotal,[COP_IDDOCTO],
								dc.total,dc.fechaRecepcionCopade
							FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
								inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
								inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
								inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
								inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
								inner join Ordenes o on o.idOrden = dco.idOrden  
								inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
								where co.idOperacion = @idOperacion and ade.COP_STATUS = 2 ) as sel ))
				------------------------ENVIADAS Ini-------------------------
				END
			IF @idEstatusOrden = 11
				BEGIN
				------------------------ABONADAS Ini-------------------------
				INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					ISNULL(sum(total),0) as venta,ISNULL(sum(subtotal),0) as costo
					from 
					(	SELECT DISTINCT
							(SELECT [dbo].[SEL_NOMBRE_CLIENTE](O.idContratoOperacion)) nombreCliente,
							DC.numeroCopade,
							ISNULL(DC.ordenSurtimiento, 'SIN SURTIMIENTO')as folio,								
							ISNULL(DC.total,0) total,							
							Z.nombre,
							COP.COP_IDDOCTO,
							COP.COP_CARGO,
							(COP.COP_CARGO - COP.COP_SALDO ) abono,
							COP.COP_SALDO,
							ISNULL(COP.COP_FECHULTPAG, '') AS COP_FECHULTPAG,								
							DC.descripcion,
							COP.COP_FECHOPE,	
							DC.idDatosCopade,
							COP.COP_ORDENGLOBAL,
							TA.idOrdenAgrupada,
							DC.fechaRecepcionCopade,
							DC.subTotal,
							DC.numeroEstimacion
							FROM DatosCopade DC 
							JOIN DatosCopadeOrden DCO ON DCO.idDatosCopade = DC.idDatosCopade
							JOIN Ordenes O ON O.idOrden = DCO.idOrden 
							JOIN ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
							JOIN Cotizaciones C ON C.idOrden = O.idOrden
							LEFT JOIN FacturaCotizacion FCO ON FCO.idCotizacion = C.idCotizacion
							JOIN Unidades U ON U.idUnidad=O.idUnidad
							JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							JOIN OrdenAgrupadaDetalle TAD ON TAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
							JOIN OrdenAgrupada TA ON TA.idOrdenAgrupada = TAD.idOrdenAgrupada
							--LEFT JOIN [cobranza].[VwStatusCotizacion] VSC ON VSC.[idCotizacion] = C.[idCotizacion]
							JOIN [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] COP ON COP.COP_ORDENGLOBAL = TA.numero COLLATE Modern_Spanish_CS_AS  
							where CO.idOperacion = @idOperacion and COP.COP_STATUS = 4 AND COP.COP_ORDENGLOBAL COLLATE Modern_Spanish_CS_AS IN (SELECT numeroOrdenGlobal FROM OrdenGlobalAbono)) as sel ))
				------------------------ABONADAS Ini-------------------------
				END
			IF @idEstatusOrden = 12
				BEGIN
				------------------------PAGADAS Ini-------------------------
				INSERT INTO @Cobranza ( idEstatus, estatus, total, promedio, color, Monto, MontoCosto ) 
					((select @idEstatusOrden as id,  (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = @idEstatusOrden) as esta, count(*) as total,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP)) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					(CASE @idEstatusOrden WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color,
					ISNULL(sum(total),0) as venta,ISNULL(sum(subtotal),0) as costo
					from 
					(	SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,		
							dc.numeroCopade,
							dc.ordensurtimiento,
							dc.numeroEstimacion,
							dc.descripcion,
							dc.subTotal,
							[COP_IDDOCTO],
							dc.total,
							dc.fechaRecepcionCopade
							FROM [192.168.20.29].[GATPARTSASE].[dbo].[ADE_COPADE] ade
							inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
							inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
							inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
							inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
							inner join Ordenes o on o.idOrden = dco.idOrden 
							inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
							inner join Partidas..Zona z on z.idZona = o.idZona
							inner join Unidades u on u.idUnidad = o.idUnidad
							inner join CatalogoTipoOrden t on t.idTipoOrden = o.idTipoOrden
							inner join EstatusOrdenes e on e.idEstatusOrden = o.idEstatusOrden

								where co.idOperacion = @idOperacion and ade.COP_STATUS = 3 ) as sel ))
				------------------------PAGADAS Ini-------------------------
				END
			------------------------admin END------------------------------
			END			
						
	SET @idEstatusOrden = @idEstatusOrden + 1;
	END

SELECT idEstatus,  estatus, total, isnull(promedio,0) as promedio, color, Monto,  MontoCosto FROM @Cobranza;
END

go

