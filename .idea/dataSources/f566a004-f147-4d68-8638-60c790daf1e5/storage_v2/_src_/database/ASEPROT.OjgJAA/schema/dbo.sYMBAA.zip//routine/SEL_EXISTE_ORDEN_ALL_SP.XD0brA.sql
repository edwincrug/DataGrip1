-- =============================================
-- Description:	Busca si existe la orden
-- [dbo].[SEL_EXISTE_ORDEN_ALL_SP] 676,'02-10127-16'
-- =============================================

CREATE PROCEDURE [dbo].[SEL_EXISTE_ORDEN_ALL_SP]
	@idUsuario INT = 0,
	@numeroOrden VARCHAR(50) = ''
AS
	BEGIN
		
		DECLARE @idContratoOperacion			INT
				,@idContratoOperacionUsuario	INT
				,@idOperacion					INT
				
		SELECT 
			@idContratoOperacion = idContratoOperacion 
		FROM Ordenes 
		WHERE numeroOrden = @numeroOrden

		SELECT 
			@idOperacion = idOperacion 
		from ContratoOperacion 
		where idContratoOperacion = @idContratoOperacion

		SELECT 
			@idContratoOperacionUsuario = idContratoOperacionUsuario
		FROM ContratoOperacionUsuario COU
		WHERE idUsuario = @idUsuario 
		AND idContratoOperacion = @idContratoOperacion

		IF(@idContratoOperacionUsuario = NULL)
			BEGIN
				SELECT 
					0 AS respuesta,
					'El usuario no tiene permisos para esa operación' AS mensaje
			END
		ELSE
			BEGIN
				IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 4
					BEGIN
						IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario, @idOperacion) <> 2
							BEGIN
								IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario, @idOperacion) <> 9
									BEGIN
										IF(EXISTS(SELECT [numeroOrden] FROM [dbo].[Ordenes] ORD 
														INNER JOIN [dbo].[ContratoOperacion] CO on CO.idContratoOperacion = ORD.idContratoOperacion 
														INNER JOIN ContratoOperacionUsuario COU on COU.idContratoOperacion = CO.idContratoOperacion 
														WHERE ORD.[numeroOrden] = @numeroOrden 
														and ORD.[idContratoOperacion] = @idContratoOperacion 
														and idOrden not in(select idOrden from Cotizaciones where idTaller=689)
														and COU.idUsuario = @idUsuario
														and ORD.idZona in (select idZona from [dbo].[GET_ZONAS_USR_FN]([dbo].[GET_CONTRATO_OPERACION_USR_FN](@idUsuario, @idOperacion)))
														))
											BEGIN
												SELECT 1 AS respuesta
												,'Orden encontrada con éxito' AS mensaje
											END
										ELSE
											BEGIN
												SELECT 0 AS respuesta , 
												'No se encontró la orden con el número de orden ' + @numeroOrden AS mensaje
											END
									END
								ELSE
									BEGIN
										IF(EXISTS(SELECT [numeroOrden] FROM [dbo].[Ordenes] ORD 
													INNER JOIN [dbo].[ContratoOperacion] CO on CO.idContratoOperacion = ORD.idContratoOperacion 
													INNER JOIN ContratoOperacionUsuario COU on COU.idContratoOperacion = CO.idContratoOperacion 
													WHERE ORD.[numeroOrden] = @numeroOrden and ORD.[idContratoOperacion] = @idContratoOperacion 
													and idOrden not in(select idOrden from Cotizaciones where idTaller=689)
													and COU.idUsuario = @idUsuario
													and ORD.idZona in (SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
																		JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
																		JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
																	WHERE EG.estatus=0 AND EZ.estatus=0
																	AND COUG.idContratoOperacionUsuario=@idContratoOperacionUsuario AND EZ.idContratoOperacion=@idContratoOperacion)
													))
											BEGIN
												SELECT 1 AS respuesta
												,'Orden encontrada con éxito' AS mensaje
											END
										ELSE
											BEGIN
												SELECT 0 AS respuesta , 
												'No se encontró la orden con el número de orden ' + @numeroOrden AS mensaje
												
											END
									END
							END
						ELSE
							BEGIN
								IF EXISTS(SELECT [numeroOrden] 
											FROM [dbo].[Ordenes] ORD 
											INNER JOIN [dbo].[ContratoOperacion] CO on CO.idContratoOperacion = ORD.idContratoOperacion 
											INNER JOIN ContratoOperacionUsuario COU on COU.idContratoOperacion = CO.idContratoOperacion 
											WHERE ORD.[numeroOrden] = @numeroOrden 
											and ORD.[idContratoOperacion] = @idContratoOperacion 
											and COU.idUsuario = @idUsuario)
									BEGIN
										SELECT 1 AS respuesta
										,'Orden encontrada con éxito' AS mensaje
									END
								ELSE
									BEGIN
										SELECT 0 AS respuesta , 
										'No se encontró la orden con el número de orden ' + @numeroOrden AS mensaje

									END
							END
					END
				ELSE
					BEGIN
						DECLARE @tablaProveedoresAsignados table(idProveedor int)

						INSERT INTO @tablaProveedoresAsignados
						SELECT idProveedor 
						FROM [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)

						IF EXISTS(SELECT [numeroOrden] 
									FROM [dbo].[Ordenes] ORD 
									INNER JOIN [dbo].[ContratoOperacion] CO on CO.idContratoOperacion = ORD.idContratoOperacion 
									INNER JOIN ContratoOperacionUsuario COU on COU.idContratoOperacion = CO.idContratoOperacion 
									WHERE ORD.[numeroOrden] = @numeroOrden 
									AND ORD.[idContratoOperacion] = @idContratoOperacion 
									AND COU.idUsuario = @idUsuario 
									AND ((SELECT CASE WHEN exists 
											(select 1 from Cotizaciones C 
												where C.idOrden = ORD.idOrden 
												and C.idTaller in (select idProveedor 
																	from @tablaProveedoresAsignados)) THEN 'true' 
											ELSE 'false' END ) = 'true') 
									OR ORD.idUsuario = @idUsuario)
				
							BEGIN
								SELECT 1 AS respuesta
									  ,'Orden encontrada con éxito' AS mensaje
							END
						ELSE
							BEGIN
								SELECT 0 AS respuesta , 
								'No se encontró la orden con el número de orden ' + @numeroOrden AS mensaje
							END
					END
				
			END
	END
go

