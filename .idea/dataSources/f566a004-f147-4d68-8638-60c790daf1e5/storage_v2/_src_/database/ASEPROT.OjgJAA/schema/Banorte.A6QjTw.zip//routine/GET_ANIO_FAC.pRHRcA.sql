-- =============================================
-- Author:		<YJH>
-- Create date: <01/10/2018>
-- Description:	<Obtiene el año de una Factura de Banorte>
-- [Banorte].[SEL_ESTATUS_AVANCE_FN] 0, 18, 39197, 0, 18
	/*DECLARE @result nvarchar(100)
	EXECUTE [Banorte].[GET_ANIO_FAC] 0,18, NULL, @result output
	select @result*/
-- =============================================
CREATE PROCEDURE [Banorte].[GET_ANIO_FAC] 
	@isProduction int=0, 
	@idContratoOperacion int,
	@facturaBanorte nvarchar(max),
	@result nvarchar(100) output
AS
BEGIN
	DECLARE 
	@anio nvarchar(100),			
	@Base NVARCHAR(MAX) = ''

	IF(@facturaBanorte is not null)
	begin
		IF(@isProduction = 1)
		BEGIN
			SELECT                 
               @Base= SERVER+'.'+DBProduccion                
				FROM ASEPROT.dbo.ContratoOperacionFacturacion 
				WHERE idContratoOperacion =  @idContratoOperacion
		END
		ELSE
		BEGIN
			SELECT 
                @Base=DB
				FROM ASEPROT.dbo.ContratoOperacionFacturacion
				WHERE idContratoOperacion = @idContratoOperacion
		END
		
		DECLARE @queryOrd nvarchar(max) = '
		SELECT @anio=Vcc_AnNo FROM '+@Base+'.[dbo].[VIS_CONCAR01] 
		WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO = '''+@facturaBanorte+''''
		print @queryOrd
		EXEC SP_EXECUTESQL @Query  = @queryOrd, @Params = N'@anio INT OUTPUT', @anio = @anio OUTPUT

		select @result= @anio 		
	end 
	else 
	begin 
		select @anio=0
		select @result=@anio
	end 
return @anio
END
go

grant execute, view definition on Banorte.GET_ANIO_FAC to DevOps
go

