-- [SEL_PRESUPUESTO_CDT_SP] @idCentroTrabajo = 71, @idOperacion = 3
CREATE PROCEDURE  [dbo].[SEL_PRESUPUESTO_CDT_SP]
	@idCentroTrabajo INT = NULL,
	@idOperacion INT = NULL

AS
BEGIN
	IF(@idOperacion=3)
		BEGIN
			SELECT P.idPresupuesto,
				   P.presupuesto,
				   P.folioPresupuesto,
				   P.solpe,
				   P.fechaInicioPresupuesto,
				   P.fechaFinalPresupuesto,
				   P.idCentroTrabajo,
				   P.idEstatusPresupuesto,
				   P.orden,
				   EP.nombreEstatusPresupuesto,
				   CT.idCentroTrabajo idCentroTrabajoDos,
				   CT.nombreCentroTrabajo,
				   CT.idOperacion,
					(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto)  montoTraspaso,--+
					--(select isnull(sum(isnull(Monto,0)),0) from ASEPROT.dbo.traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,

				(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
					FROM [dbo].[Cotizaciones] C 
					INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
					INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
					LEFT JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden
					INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
				WHERE PO.idPresupuesto = P.idPresupuesto
				AND CO.idOperacion = @idOperacion
				AND CD.idEstatusPartida IN(2) 
				AND C.idEstatusCotizacion IN(3)) +
				(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
					FROM ASEPROTSISCO.[dbo].[Cotizaciones] C 
					INNER JOIN ASEPROTSISCO.[dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
					INNER JOIN ASEPROTSISCO.[dbo].[Ordenes]	O ON C.idOrden = O.idOrden
					LEFT JOIN ASEPROTSISCO.[dbo].PresupuestoOrden PO ON PO.idOrden = O.idOrden
					INNER JOIN ASEPROTSISCO.[dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
				WHERE PO.idPresupuesto = P.idPresupuesto
				AND CO.idOperacion = @idOperacion
				AND CD.idEstatusPartida IN(2) 
				AND C.idEstatusCotizacion IN(3)) utilizado,

				(presupuesto 			
				+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
				- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
				+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
					FROM [dbo].[Cotizaciones] C 
					INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
					INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
					LEFT JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden
					INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
				WHERE  PO.idPresupuesto = P.idPresupuesto
				AND CO.idOperacion = @idOperacion
				AND CD.idEstatusPartida IN(2) 
				AND C.idEstatusCotizacion IN(3))) +
				( 			
				--+ (select isnull(sum(isnull(Monto,0)),0) from ASEPROT.[dbo].traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
				- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
				--+ (select isnull(sum(isnull(Monto,0)),0) from ASEPROT.[dbo].traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
					FROM ASEPROTSISCO.[dbo].[Cotizaciones] C 
					INNER JOIN ASEPROTSISCO.[dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
					INNER JOIN ASEPROTSISCO.[dbo].[Ordenes]	O ON C.idOrden = O.idOrden
					LEFT JOIN ASEPROTSISCO.dbo.PresupuestoOrden PO ON PO.idOrden = O.idOrden
					INNER JOIN ASEPROTSISCO.[dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
				WHERE  PO.idPresupuesto = P.idPresupuesto
				AND CO.idOperacion = @idOperacion
				AND CD.idEstatusPartida IN(2) 
				AND C.idEstatusCotizacion IN(3))) saldo,
				(SELECT [dbo].[SEL_PENDIENTE_HOJA_FN](CT.idCentroTrabajo)) ordPendiente	,
				case when (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) > 0 then 1 else 0 end esTraspaso    
			FROM [dbo].[Presupuestos] P
			JOIN [dbo].[EstatusPresupuestos] EP ON EP.idEstatusPresupuesto = P.idEstatusPresupuesto
			JOIN [dbo].[CentroTrabajos] CT ON CT.idCentroTrabajo = P.idCentroTrabajo
			left join dbo.TraspasoPresupuesto TP on TP.idPresupuestoOrigen = P.idPresupuesto 
			WHERE P.idCentroTrabajo = COALESCE(@idCentroTrabajo, P.idCentroTrabajo) 
			AND CT.idOperacion = COALESCE(@idOperacion, CT.idOperacion)
			AND P.idPresupuesto <= 953
			UNION
			SELECT P.idPresupuesto,
				   P.presupuesto,
				   P.folioPresupuesto,
				   P.solpe,
				   P.fechaInicioPresupuesto,
				   P.fechaFinalPresupuesto,
				   P.idCentroTrabajo,
				   P.idEstatusPresupuesto,
				   P.orden,
				   EP.nombreEstatusPresupuesto,
				   CT.idCentroTrabajo idCentroTrabajoDos,
				   CT.nombreCentroTrabajo,
				   CT.idOperacion,
					(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,

				(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
					FROM [dbo].[Cotizaciones] C 
					INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
					INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
					LEFT JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden
					INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
				WHERE PO.idPresupuesto = P.idPresupuesto
				AND CO.idOperacion in (3, 9)--= @idOperacion
				AND CD.idEstatusPartida IN(2) 
				AND C.idEstatusCotizacion IN(3)) utilizado,

				(presupuesto 			
				+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
				- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
				+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
					FROM [dbo].[Cotizaciones] C 
					INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
					INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
					LEFT JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden
					INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
				WHERE  PO.idPresupuesto = P.idPresupuesto
				AND CO.idOperacion in (3, 9)--= @idOperacion
				AND CD.idEstatusPartida IN(2) 
				AND C.idEstatusCotizacion IN(3))) saldo,
				(SELECT [dbo].[SEL_PENDIENTE_HOJA_FN](CT.idCentroTrabajo)) ordPendiente	,
				case when (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) > 0 then 1 else 0 end esTraspaso    
			FROM [dbo].[Presupuestos] P
			JOIN [dbo].[EstatusPresupuestos] EP ON EP.idEstatusPresupuesto = P.idEstatusPresupuesto
			JOIN [dbo].[CentroTrabajos] CT ON CT.idCentroTrabajo = P.idCentroTrabajo
			left join dbo.TraspasoPresupuesto TP on TP.idPresupuestoOrigen = P.idPresupuesto 
			WHERE P.idCentroTrabajo = COALESCE(@idCentroTrabajo, P.idCentroTrabajo) 
			AND CT.idOperacion = COALESCE(@idOperacion, CT.idOperacion)
			AND P.idPresupuesto >= 954
		END
	ELSE
		BEGIN
				SELECT P.idPresupuesto,
				   P.presupuesto,
				   P.folioPresupuesto,
				   P.solpe,
				   P.fechaInicioPresupuesto,
				   P.fechaFinalPresupuesto,
				   P.idCentroTrabajo,
				   P.idEstatusPresupuesto,
				   P.orden,
				   EP.nombreEstatusPresupuesto,
				   CT.idCentroTrabajo idCentroTrabajoDos,
				   CT.nombreCentroTrabajo,
				   CT.idOperacion,
					(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,

				(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
					FROM [dbo].[Cotizaciones] C 
					INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
					INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
					LEFT JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden
					INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
				WHERE PO.idPresupuesto = P.idPresupuesto
				AND CO.idOperacion = @idOperacion
				AND CD.idEstatusPartida IN(2) 
				AND C.idEstatusCotizacion IN(3)) utilizado,

				(presupuesto 			
				+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
				- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
				+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
					FROM [dbo].[Cotizaciones] C 
					INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
					INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
					LEFT JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden
					INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
				WHERE  PO.idPresupuesto = P.idPresupuesto
				AND CO.idOperacion = @idOperacion
				AND CD.idEstatusPartida IN(2) 
				AND C.idEstatusCotizacion IN(3))) saldo,
				(SELECT [dbo].[SEL_PENDIENTE_HOJA_FN](CT.idCentroTrabajo)) ordPendiente	,
				case when (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) > 0 then 1 else 0 end esTraspaso    
			FROM [dbo].[Presupuestos] P
			JOIN [dbo].[EstatusPresupuestos] EP ON EP.idEstatusPresupuesto = P.idEstatusPresupuesto
			JOIN [dbo].[CentroTrabajos] CT ON CT.idCentroTrabajo = P.idCentroTrabajo
			left join dbo.TraspasoPresupuesto TP on TP.idPresupuestoOrigen = P.idPresupuesto 
			WHERE P.idCentroTrabajo = COALESCE(@idCentroTrabajo, P.idCentroTrabajo) 
			AND CT.idOperacion = COALESCE(@idOperacion, CT.idOperacion)
		END
END



go

