--JOB_EXECUTE
CREATE PROCEDURE [report].[JOB_EXECUTE]
AS
BEGIN
	
	DECLARE 
		--VARIABLES DE CURSOR
		@nombreProcedimientoAlmacenado	varchar(200),
		@nombreTablaResultado			varchar(200),
		@periodicidadMinutos			int,
		--OTRAS VARIABLES
		@fecha							nvarchar(20),
		@command						nvarchar(max)
	DECLARE JOBS CURSOR FOR
	SELECT nombreProcedimientoAlmacenado, nombreTablaResultado, periodicidadMinutos FROM report.JOB
	OPEN JOBS
	FETCH NEXT FROM JOBS INTO @nombreProcedimientoAlmacenado, @nombreTablaResultado, @periodicidadMinutos
	WHILE @@FETCH_STATUS=0
	BEGIN		
		--VERIFICAMOS SI SE EJCUTA EL SP
		set @command = '
			--declare @fechaActualizacion nvarchar(20)
			select top 1 @fechaActualizacion = CONVERT(NVARCHAR,fechaActualizacion) from ' + @nombreTablaResultado + ' order by fechaActualizacion desc'
			set @fecha=''
			exec sp_executesql @command,N'@fechaActualizacion nvarchar(20) out',@fecha out
			
			--YA QUE TENEMOS LA FECHA VERIFICAMOS SI DEBEMOS DE ACTUALIZAR EL CONTENIDO DE LA TABL
			
			if (datediff(n,convert(datetime,@fecha),getdate())>@periodicidadMinutos)
			begin
				print 'ACTUALIZAMOS'
				exec @nombreProcedimientoAlmacenado
			end
		FETCH NEXT FROM JOBS INTO @nombreProcedimientoAlmacenado, @nombreTablaResultado, @periodicidadMinutos
	END
	CLOSE JOBS
	DEALLOCATE JOBS
END
go

grant execute, view definition on report.JOB_EXECUTE to DevOps
go

