-- =============================================
-- Author:		
-- Create date: 
-- =============================================
CREATE PROCEDURE [dbo].[INS_COMENTARIO_ORDEN] 
	@comentario varchar(MAX) = NULL,
	@idOrden numeric(18,0),
	@idUsuario numeric(18,0)

AS
BEGIN
	SET NOCOUNT ON;

	IF @comentario is not null 
	BEGIN
		INSERT INTO [dbo].[ComentarioOrden]
					([idOrden],[idUsuario],[comentario],[fecha])
			 VALUES (@idOrden, @idUsuario, @comentario, GETDATE())
			 
		SELECT @@IDENTITY AS idComentarioOrden, @comentario AS Comentario
	END	
	ELSE
	BEGIN
	SELECT 0 AS idComentarioOrden
	END 

	--SELECT N.[idUsuario], U.[nombreCompleto], N.[descripcionNota] AS texto, DATEADD(hh, 5, N.[fechaNota]) AS fecha, EO.[nombreEstatusOrden] AS nombreEstatus
	--FROM   [dbo].[Notas] AS N
	--		INNER JOIN [dbo].[Usuarios] AS U ON U.[idUsuario] = N.[idUsuario]
	--		INNER JOIN [dbo].[Ordenes] AS O ON N.idOrden = O.idOrden 
	--		INNER JOIN [dbo].[EstatusOrdenes] AS EO ON EO.idEstatusOrden = N.idEstatusOrden
	--WHERE  O.numeroOrden = @numOrden
	--ORDER BY [fechaNota]
END
go

