CREATE PROCEDURE [dbo].[SEL_SALDOSXML_CARGADOS_SP]
    @idCotizacion int
AS
    SELECT Subtotal,SubtotalReal=Subtotal-ISNULL(descuento,0), iva, total as total, descuento, idCotizacion, retenido, tasaOCuota
    FROM FacturaCotizacion
    WHERE idCotizacion = @idCotizacion

go

grant execute, view definition on SEL_SALDOSXML_CARGADOS_SP to DevOps
go

