


CREATE VIEW [report].[VwOrdenTotales]
AS

    SELECT  COTI.idOrden,
            CONVERT(numeric(18,2),ISNULL(SUM(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00)) [costo],
	        CONVERT(numeric(18,2),ISNULL(SUM(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)) [venta],
			MIN(COTI.fechaCotizacion) AS [FechaCotizacionMin],
	        MAX(COTI.fechaCotizacion) AS [FechaCotizacionMax]
      FROM  Cotizaciones COTI 
INNER JOIN  CotizacionDetalle CD on CD.idCotizacion = COTI.idCotizacion
INNER JOIN  Ordenes O ON O.idOrden = COTI.idOrden AND O.idEstatusOrden < 5
     WHERE  CD.idEstatusPartida in( 1,2) 
	   AND  COTI.idEstatusCotizacion in (1,2,3) 
	  
  GROUP BY COTI.idOrden

  UNION ALL

  SELECT  COTI.idOrden,
            CONVERT(numeric(18,2),ISNULL(SUM(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00)) [costo],
	        CONVERT(numeric(18,2),ISNULL(SUM(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)) [venta],
			MIN(COTI.fechaCotizacion) AS [FechaCotizacionMin],
	        MAX(COTI.fechaCotizacion) AS [FechaCotizacionMax]
      FROM  Cotizaciones COTI 
INNER JOIN  CotizacionDetalle CD on CD.idCotizacion = COTI.idCotizacion
INNER JOIN  Ordenes O ON O.idOrden = COTI.idOrden AND O.idEstatusOrden >= 5
     WHERE  CD.idEstatusPartida in( 2) 
	   AND  COTI.idEstatusCotizacion in (3) 
	  
  GROUP BY COTI.idOrden

go

