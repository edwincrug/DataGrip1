-- =============================================
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- [UPD_DETALLE_APROBACION_MONTO_SP]
-- =============================================
 CREATE PROCEDURE [dbo].[UPD_DETALLE_APROBACION_MONTO_SP]
	@idOperacionContrato NUMERIC(18, 0),
	@nivel NUMERIC(18, 0),
	@montoDe NUMERIC(18, 2),
	@montoA NUMERIC(18, 2)
AS
BEGIN
	
	UPDATE DetalleOperacionAprobacionMonto 
	SET montoDe=@montoDe, montoA=@montoA
	WHERE idOperacionContrato=@idOperacionContrato AND nivel=@nivel
		
END


go

