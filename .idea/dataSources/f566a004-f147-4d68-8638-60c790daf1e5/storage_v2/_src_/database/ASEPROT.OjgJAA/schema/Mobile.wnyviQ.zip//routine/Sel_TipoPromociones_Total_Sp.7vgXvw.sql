-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 08/08/2018
-- Description:	Actualizar la unidad por id, solo para unidades registradas en app banorte
-- EXEC [Mobile].[Sel_TipoPromociones_Total_Sp] 747
-- =============================================
CREATE PROCEDURE [Mobile].[Sel_TipoPromociones_Total_Sp]
	@idUsuario					int

AS
BEGIN

	SELECT 
		[id]
		,[descripcion]
		,[status]
		,[img]
		,[order]
		,[total]
	FROM [ASEPROT].[Banorte].[CatalogoTipoPromocion] ctp
	LEFT JOIN (SELECT 
			count(nu.id) total
			,np.idtipoPromocion
		From [Notificaciones].[Catalogo].[Usuario] u
			inner join [Notificaciones].[Relacion].[NotificacionUsuario] nu on u.id = nu.idUsuario
			inner join [Notificaciones].[Operacion].[Notificacion] n on n.id = nu.idNotificacion
			inner join [Notificaciones].[Catalogo].[Aplicacion] a on a.id = u.idAplicacion
			inner join [Notificaciones].[Catalogo].[TipoUsuario] tu on tu.id = u.idTipoUsuario
			inner join [Notificaciones].[Catalogo].[TiposNotificacion] tn on tn.id = n.idTipoNotificacion
			inner join [Notificaciones].[Catalogo].[NotificacionPromocion] np on np.idNotificacionUsuario = nu.id
		where u.idEstatus = 1 
			and nu.idEstatus = 1
			and n.idEstatus = 1
			and a.idEstatus = 1
			and tu.idEstatus = 1
			and u.idAplicacion = 1
			and u.idUsuario = @idUsuario
		GROUP BY np.idtipoPromocion) tn ON ctp.id = tn.idtipoPromocion

END
go

grant execute, view definition on Mobile.Sel_TipoPromociones_Total_Sp to DevOps
go

