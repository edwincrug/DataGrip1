





CREATE VIEW [cobranza].[VwStatusCotizacionF]
AS
SELECT 
       DISTINCT
       VwCPI.[numeroCotizacion]
      ,VwCPI.[idCotizacion]
      ,VwCPI.[OTE_IDPROVEEDOR]
      ,VwCPI.[numFactura] 
	  ,VwIPS.[NumFactura] as [NumFacturaF]
	  ,VwIPS.[idProveedor]
	  ,CASE WHEN VwIPS.[DeudaDia] < 0
	   THEN 0
	   ELSE VwIPS.[DeudaDia]
	   END AS [DeudaDia]

  FROM [cobranza].[VwCotizacionProvInvoiceC] VwCPI

LEFT JOIN [cobranza].[VwInvoiceProvSaldoDia] VwIPS
        ON VwIPS.[NumFactura] = VwCPI.[numFactura] COLLATE Modern_Spanish_CI_AS
       AND VwIPS.[idProveedor] = VwCPI.[OTE_IDPROVEEDOR]

go

