
CREATE PROCEDURE [dbo].[UPD_CONTRARECIBO_SP]
	@idContrarecibo AS INT
AS
BEGIN

	UPDATE Contrarecibo
	SET estatus=1
	WHERE idContrarecibo=@idContrarecibo

	SELECT 10

	/* INSERT INTO Contrarecibo VALUES(@numeroContrarecibo, GETDATE(), @idContratoOperacion, @idUsuario, 0) SELECT @@IDENTITY */
END
go

