-- =============================================
-- Author:		Raul Arce Florentino
-- Create date: 28/12/2016
-- Description:	Obtiene la unidad y el sustituto

-- Author Modifica: Adolfo Martinez
-- Modifica date: 04/01/2017
-- Description:	Se añade filtro por idMotivo + numeroTrabajo 
-- SELECT * FROM UnidadSustituto 
-- EXEC [Sustituto].[SEL_REPORTE_SUSTITUTO_SP] null,5

-- Author Modifica: Yadira Jarvio Hernandez
-- Modifica date: 15/03/2018
-- Description:	Se añade campos de la unidad sustituto y original
-- =============================================
CREATE PROC [Sustituto].[SEL_REPORTE_SUSTITUTO_SP]
@idMotivo NVARCHAR(5) = NULL,
@idContratoOperacion int

AS
BEGIN

	DECLARE @select NVARCHAR(MAX) = ''
	DECLARE @where NVARCHAR(MAX) = ''
	DECLARE @and NVARCHAR(MAX) = ''
	DECLARE @query  NVARCHAR(MAX) = ''
	DECLARE @idOperacion NUMERIC(18,0)

	SELECT @idOperacion=idOperacion FROM ContratoOperacion WHERE idContratoOperacion=@idContratoOperacion

SET @select = '   SELECT US.idUnidadSustituto,
				  CONVERT (char(10), US.fecha, 103) fecha,
				  U.[numeroEconomico] numEconomicoUnidad,				  
				  z.nombre as [Hijo],				  
				  ZP.nombre as [Padre],
				  SM.nombre submarca, 
				  M.nombre marca,
				  U.modelo,
				  U.vin,	
				  U.verGPS as verGPSOr,
				  (SELECT verGPS from [dbo].[Unidades] WHERE idUnidad = US.idSustitutoUni)  verGPSSutituto,
				  U.placas,		----placas de la unidad original	--- YJH 
				 (SELECT [dbo].[diferenciaTiempo] (US.fecha)) tiempoTranscurrido,
				 (SELECT UN.[numeroEconomico] from [dbo].[Unidades]  UN WHERE UN.idUnidad = US.idSustitutoUni)  numEconomicoSustituto,
				 MSC.nombre  marcaSustituto,
				 (SELECT UN.modelo from [dbo].[Unidades] UN WHERE UN.idUnidad = US.idSustitutoUni)  modeloSustituto,
				 SM.nombre  SubMarcaSustituto,
				 (SELECT UN.vin from [dbo].[Unidades] UN WHERE UN.idUnidad = US.idSustitutoUni)  vinSustituto,				 
				 --(SELECT UN.TAR from UNIDAD UN WHERE UN.idUnidad = US.idSustitutoUni)  tarSustituto,
				 (SELECT UN.placas from [dbo].[Unidades] UN WHERE UN.idUnidad = US.idSustitutoUni)  placasSustituto,	--- placas de la unidad sustituto --- YJH 
				 zs.nombre as [HijoSustituto],
				 --(SELECT UN.GAR from UNIDAD UN WHERE UN.idUnidad = US.idSustitutoUni)  garSustituto,
				 zps.nombre as [PadreSustituto],
				 US.idUnidad,
				 US.idSustitutoUni,
				 US.estatus,
				 US.idMotivo,
				 ''En circulación'' estatusText,
				 MS.Descripcion,
				 US.[numeroOrden],
				 O.[idOrden],
				 E.[nombreEstatusOrden] 	   
			 FROM [Sustituto].[UnidadSustituto] US
			 INNER JOIN [dbo].[Unidades] U ON U.idUnidad=US.idUnidad 
			 INNER JOIN [Sustituto].[MotivoSustituto] MS ON MS.idMotivo = US.idMotivo
			 LEFT JOIN Ordenes O ON O.[numeroOrden] = US.[numeroOrden] 
			 LEFT JOIN [dbo].[EstatusOrdenes] E ON E.[idEstatusOrden] = O.[idEstatusOrden]
			 JOIN Partidas..Unidad UP ON UP.idUnidad = U.idTipoUnidad
			 JOIN Partidas..SubMarca SM ON SM.idSubMarca = up.idSubMarca
			 JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
			 LEFT JOIN [dbo].[Unidades] USU ON USU.idUnidad=US.[idSustitutoUni] 
			 LEFT JOIN Partidas..Unidad UPS ON UPS.idUnidad = USU.[idTipoUnidad]
			 LEFT JOIN Partidas..SubMarca SMS ON SMS.idSubMarca = UPS.idSubMarca
			 LEFT JOIN Partidas..Marca MSC ON MSC.idMarca = SMS.idMarca
			 LEFT JOIN partidas..zona Z ON z.idZona = U.idzona
             LEFT JOIN partidas..zona ZP ON zp.idZona = z.idPadre
			 LEFT JOIN partidas..zona ZS ON ZS.idZona = USU.idzona
             LEFT JOIN partidas..zona ZPS ON ZPS.idZona = ZS.idPadre
			 '

		SET @where = ' WHERE US.estatus = 0 AND US.idContratoOPeracion = ' + Convert(nvarchar(20),@idContratoOperacion) + ' '

	IF(@idMotivo IS NOT NULL)
	  BEGIN
		SET @and=' AND US.idMotivo =' + @idMotivo+' '
      END

    SET @query = @select+@where+@and

    EXECUTE SP_EXECUTESQL @query
	PRINT @query

END

go

