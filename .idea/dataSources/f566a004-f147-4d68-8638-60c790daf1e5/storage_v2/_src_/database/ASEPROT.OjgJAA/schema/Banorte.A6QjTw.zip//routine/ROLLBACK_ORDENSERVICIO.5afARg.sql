-- =============================================
-- Author:		<YJH>
-- Create date: <22/08/2018>
-- Description:	<Simulación de rollback para cuando hay un error al insertar ordenes o cotizaciones desde SISRE>
-- [Banorte].[ROLLBACK_ORDENSERVICIO] 4, 53361, 0
-- =============================================
CREATE PROCEDURE [Banorte].[ROLLBACK_ORDENSERVICIO]
	@tipo int, --tipo de eliminacion 1=Orden, 2=Cotizacion y Orden, 3 =Cotizacion
	@idOrden int, 
	@idCotizacion int 
AS
BEGIN	
	SET NOCOUNT ON;
	
	IF @tipo = 1 -- Eliminar Orden
		BEGIN 
			DELETE FROM HistorialEstatusOrden WHERE idOrden = @idOrden

			DELETE FROM Ordenes WHERE idOrden = @idOrden	
		END 
		 
	IF @tipo = 2 -- Eliminar Orden y Cotizacion
		BEGIN 			
			DELETE FROM HistorialEstatusCotizacion WHERE idCotizacion = @idCotizacion

			DELETE FROM Cotizaciones WHERE idCotizacion = @idCotizacion

			DELETE FROM HistorialEstatusOrden WHERE idOrden = @idOrden

			DELETE FROM Ordenes WHERE idOrden = @idOrden
		END 
	IF @tipo = 3 -- Eliminar Cotizacion
		BEGIN 
			DELETE FROM HistorialEstatusCotizacion WHERE idCotizacion = @idCotizacion

			DELETE FROM Cotizaciones WHERE idCotizacion = @idCotizacion
		END 
	IF @tipo = 4 -- Eliminar Orden, Cotizacion, CotizacionDetalle
		BEGIN 	
			DELETE FROM DetalleAutorizacionCotizacion WHERE idCotizacionDetalle in 
			(select idCotizacionDetalle from CotizacionDetalle WHERE idCotizacion IN (SELECT idCotizacion FROM Cotizaciones WHERE idOrden = @idOrden))
			
			DELETE FROM CotizacionDetalle WHERE idCotizacion IN (SELECT idCotizacion FROM Cotizaciones WHERE idOrden = @idOrden)
			
			DELETE FROM AutorizacionCotizacion WHERE idCotizacion IN (SELECT idCotizacion FROM Cotizaciones WHERE idOrden = @idOrden)

			DELETE FROM HistorialEstatusCotizacion WHERE idCotizacion IN (SELECT idCotizacion FROM Cotizaciones WHERE idOrden = @idOrden)
			 
			DELETE FROM Cotizaciones WHERE idOrden = @idOrden

			DELETE FROM HistorialEstatusOrden WHERE idOrden = @idOrden

			DELETE FROM OrdenSiniestro WHERE idOrden=@idOrden /*SE MOVIO POR EL ORDEN DE LAS FK*/

			DELETE FROM Ordenes WHERE idOrden = @idOrden

		END
END
go

grant execute, view definition on Banorte.ROLLBACK_ORDENSERVICIO to DevOps
go

