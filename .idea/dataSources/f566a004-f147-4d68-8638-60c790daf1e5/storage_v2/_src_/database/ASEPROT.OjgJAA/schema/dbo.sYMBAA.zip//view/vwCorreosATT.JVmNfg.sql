



CREATE VIEW [dbo].[vwCorreosATT]
AS

/*PRODUCCION*/
--SELECT 'NADSHIELY GUADALUPE ALONSO SANTOSCOY' AS Nombre,'na273c@att.com' AS Email
--UNION 
--SELECT 'MANUEL VAZQUEZ SALAS' AS Nombre,'mv628j@att.com' AS Email
--UNION 
SELECT 'Ejecutivo de Cuenta AT&T' AS Nombre,'ejecutivodecuentaatt@centraldeoperaciones.com' AS Email
UNION 
SELECT 'Brauilio Solano' AS Nombre,'ejecutivodecuenta2@centraldeoperaciones.com' AS Email
UNION
SELECT 'Justino Jesús Laureles López' AS Nombre,'asesoratt@centraldeoperaciones.com' AS Email

go

