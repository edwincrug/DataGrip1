
CREATE PROCEDURE [dbo].[EXT_SOPORTE_SP] 
	@idOrden NUMERIC(18,0),
	@idCotizacion NUMERIC(18,0),
	@idUsuario NUMERIC(18,0),
	@idContratoOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0),
	@idSoporte NUMERIC(18,0),
	@idPresupuesto NUMERIC(18,0)

AS
BEGIN
	DECLARE @idUsuarioOperacion INT
	DECLARE @numeroOrden NVARCHAR(100)
	DECLARE @numeroCotizacion NVARCHAR(100)
	DECLARE @descripcion NVARCHAR(100)

	SELECT @numeroOrden = numeroOrden FROM ordenes WHERE idOrden = @idOrden

	IF(@idCotizacion <> 0)
		BEGIN
			SELECT @numeroCotizacion = numeroCotizacion FROM Cotizaciones WHERE idCotizacion = @idCotizacion
		END

	SET @idUsuarioOperacion = (SELECT TOP 1 CO.idUsuario FROM Ordenes O
    JOIN ContratoOperacionUsuario CO ON CO.idContratoOperacion = O.idContratoOperacion
    JOIN ContratoOperacionUsuarioZona COZ ON COZ.idContratoOperacionUsuario = CO.idContratoOperacionUsuario
    JOIN Partidas..Zona Z ON Z.idZona = COZ.idZona AND Z.idZona = O.idZona
    WHERE CO.idUsuario IN(119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150) AND
    O.idOrden = @idOrden AND CO.idContratoOperacion= @idContratoOperacion)
		
	IF(@idSoporte = 1)
		BEGIN
			SET @descripcion='Correo Utilidad'
			EXEC [EXT_SEL_CORREO_UTILIDAD_SP] @idOrden, @idUsuarioOperacion, @idCotizacion
		END
	ELSE IF(@idSoporte = 2)
		BEGIN
			SET @descripcion='Borra Provision'
			EXEC [dbo].[EXT_DEL_ORDEN_PAGO_PROVISION_SP] @idOrden, @idUsuarioOperacion, @idContratoOperacion, @isProduction
		END
	ELSE IF(@idSoporte = 3)
		BEGIN
			SET @descripcion='Cancela Orden'
			EXEC [dbo].[EXT_UPD_CANCELA_ORDEN_SP] @idUsuarioOperacion, @idOrden
		END
	ELSE IF(@idSoporte = 4)
		BEGIN
			SET @descripcion='Cancela Cotizacion'
			EXEC [dbo].[EXT_CANCELA_COTIZACION_SP] @numeroCotizacion, @idUsuarioOperacion
		END
	ELSE IF(@idSoporte = 5)
		BEGIN
			SET @descripcion='Avanza Orden'
			EXEC [dbo].[EXT_UPD_AVANZA_ORDEN_SP] @idOrden, @idUsuarioOperacion
		END
	ELSE IF(@idSoporte = 6)
		BEGIN
			SET @descripcion='Mueve Presupuesto'
			EXEC [dbo].[EXT_UPD_MOVER_PRESUPUESTO_SP] @idOrden, @idPresupuesto, @idUsuarioOperacion
		END
	ELSE IF(@idSoporte = 7)
		BEGIN
			SET @descripcion='Actualizar taller y costos'
			--EXEC [dbo].[EXT_COTIZACION_TALLER_SP] @idCotizacion, @idTaller
		END
	/*
	@idSoporte = 8
		EXT_INTEGRA_COTIZACION_SP
	@idSoporte = 9
		EXT_UPD_CANCELA_DETALLE_COTIZACION_SP
	@idSoporte = 10
		[EXT_DEL_DATOS_COPADE_SP]
	@idSoporte = 11
		[UPD_PRESUPUESTO_SP]
	*/
	INSERT INTO LogSoporte VALUES(@idOrden, @idUsuario, @idContratoOperacion, GETDATE(), @idSoporte, @descripcion,@idCotizacion)

END

go

grant execute, view definition on EXT_SOPORTE_SP to DevOps
go

