


Create VIEW [report].[VwOrdenStatusMaxDateDias]
AS
SELECT [FechaMax]
      ,[idOrden]
      ,[idEstatusOrden]
	  ,DATEDIFF (day,[FechaMax],getdate()) as [Dias]
  FROM [ASEPROT].[report].[VwOrdenStatusMaxDate]
go

