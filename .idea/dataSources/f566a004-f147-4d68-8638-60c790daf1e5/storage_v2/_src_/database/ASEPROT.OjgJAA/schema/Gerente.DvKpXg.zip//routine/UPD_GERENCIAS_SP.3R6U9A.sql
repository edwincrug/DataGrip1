 CREATE PROCEDURE [Gerente].[UPD_GERENCIAS_SP]
	@idGerencias INT,
	@nombreGerencia NVARCHAR(250),
	@descripcionGerencia NVARCHAR(500),
	@idUsuario INT,
	@cancela INT
AS
BEGIN
	IF(@cancela = 0)
		BEGIN 
			IF(@idGerencias = 0)
				BEGIN
					IF NOT EXISTS(SELECT 1 FROM [Gerente].[Gerencias] WHERE nombreGerencia=@nombreGerencia AND descripcionGerencia=@descripcionGerencia AND estatus=0)
						BEGIN
							INSERT [Gerente].[Gerencias] VALUES(@nombreGerencia,@descripcionGerencia,GETDATE(),@idUsuario, @cancela)

							SELECT 'El registro se ha guardado correctamente!' msg, 1 estatus
						END
					ELSE
						BEGIN
							SELECT 'El nombre y/o descripción ya existen!' msg, 0 estatus
						END
				END
			ELSE
				BEGIN
					IF NOT EXISTS(SELECT 1 FROM [Gerente].[Gerencias] WHERE nombreGerencia=@nombreGerencia AND descripcionGerencia=@descripcionGerencia AND estatus=0)
						BEGIN
							UPDATE [Gerente].[Gerencias]
							SET nombreGerencia=@nombreGerencia,descripcionGerencia=@descripcionGerencia,@idUsuario=@idUsuario
							WHERE idGerencias = @idGerencias
							SELECT 'El registro se ha guardado correctamente!' msg, 1 estatus
						END
					ELSE
						BEGIN
							SELECT 'El nombre y/o descripción ya existen!' msg, 0 estatus
						END
				END
		END
	ELSE
		BEGIN
			UPDATE [Gerente].[Gerencias]
			SET estatus=@cancela
			WHERE idGerencias = @idGerencias

				IF EXISTS(SELECT 1 FROM [Gerente].[EstadoGerencia] WHERE idGerencia = @idGerencias)
				BEGIN
					UPDATE [Gerente].[EstadoGerencia]
					SET estatus=@cancela
					WHERE idGerencia = @idGerencias
				END

			SELECT 'El registro se ha cancelado correctamente!' msg, 1 estatus
		END
END
 go

 grant execute, view definition on Gerente.UPD_GERENCIAS_SP to DevOps
 go

