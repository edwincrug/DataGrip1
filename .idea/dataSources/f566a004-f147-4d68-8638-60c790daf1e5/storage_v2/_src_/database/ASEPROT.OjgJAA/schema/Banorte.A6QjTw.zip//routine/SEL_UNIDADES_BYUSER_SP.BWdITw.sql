

-- =============================================
-- Author:		<YJH>
-- Create date: <17/05/2018>
-- Description:	<Obtiene las unidades relacionadas con un usuario>
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_UNIDADES_BYUSER_SP]
	@idUsuario int
AS
BEGIN
	select 
		idUnidad, vin, numeroEconomico, idTipoUnidad,
		idOperacion, placas, idZona, modelo, combustible 
	from Unidades where idUsuario = @idUsuario
END

go

grant execute, view definition on Banorte.SEL_UNIDADES_BYUSER_SP to DevOps
go

