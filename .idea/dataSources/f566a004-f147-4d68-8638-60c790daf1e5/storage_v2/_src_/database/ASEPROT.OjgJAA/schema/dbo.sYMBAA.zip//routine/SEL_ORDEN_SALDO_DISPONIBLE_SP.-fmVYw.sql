
-- SEL_ORDEN_SALDO_DISPONIBLE_SP '03-1111111111-000101'

CREATE Procedure  [dbo].[SEL_ORDEN_SALDO_DISPONIBLE_SP]
@numeroOrden  nvarchar(100) ='',
@saldoDisponible decimal(18,6) OUTPUT  
as
begin

		declare  @idCentroTrabajo int = 0

		select @idCentroTrabajo=idCentroTrabajo 
		from ordenes 
		where numeroOrden = @numeroOrden 
		SET NOCOUNT ON;
		select @saldoDisponible =  
			isnull((
				SELECT sum(ctd.costo) 
				FROM ordenes
				inner join Cotizaciones ctz
				on ctz.idOrden =ordenes.idOrden
				inner join CotizacionDetalle ctd
				on ctz.idCotizacion = ctd.idCotizacion
				where idCentroTrabajo=@idCentroTrabajo 
				and idEstatusOrden =9
			) ,0) 
		
		from presupuestos 
		where idCentroTrabajo=@idCentroTrabajo

		RETURN  
 
end
go

