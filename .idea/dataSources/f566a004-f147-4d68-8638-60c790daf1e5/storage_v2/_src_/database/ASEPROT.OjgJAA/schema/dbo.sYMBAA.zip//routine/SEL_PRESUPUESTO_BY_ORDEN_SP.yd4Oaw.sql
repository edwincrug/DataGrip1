
-- =============================================
-- [SEL_PRESUPUESTO_BY_ORDEN_SP] 11905, 2
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PRESUPUESTO_BY_ORDEN_SP]
	@idOrden NUMERIC(18,0),
	@consulta NUMERIC(18,0)
AS
BEGIN
DECLARE @idCentroTrabajo INT
	SELECT @idCentroTrabajo=idCentroTrabajo FROM Ordenes WHERE idOrden=@idOrden

	IF(@Consulta = 1)
		BEGIN
			SELECT O.numeroOrden, O.comentarioOrden, O.fechaCreacionOden, [dbo].[GET_ZONAS_ORDEN_FN](O.idZona) zona, P.presupuesto, P.folioPresupuesto, p.orden, CT.nombreCentroTrabajo
			FROM PresupuestoOrden PO
				JOIN Ordenes O ON O.idOrden = PO.idOrden
				JOIN CentroTrabajos CT ON CT.idCentroTrabajo = O.idCentroTrabajo
				JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto
			WHERE PO.idOrden=@idOrden AND  O.idCentroTrabajo=@idCentroTrabajo
		END
	ELSE IF(@Consulta = 2)
		BEGIN
			SELECT P.idPresupuesto, P.presupuesto, P.folioPresupuesto, P.orden, CT.nombreCentroTrabajo FROM Presupuestos P 
			JOIN CentroTrabajos CT ON CT.idCentroTrabajo = P.idCentroTrabajo
			WHERE P.idCentroTrabajo=@idCentroTrabajo AND P.idPresupuesto NOT IN(SELECT idPresupuesto FROM PresupuestoOrden WHERE idOrden = @idOrden)
			ORDER BY P.orden
		END

END
go

