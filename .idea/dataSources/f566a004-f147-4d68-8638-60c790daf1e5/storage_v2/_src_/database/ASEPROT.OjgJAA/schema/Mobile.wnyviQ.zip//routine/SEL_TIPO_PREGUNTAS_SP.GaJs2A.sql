
-- =============================================
--Fecha Creación: 23/01/19
--Autor: Miguel Angel Reyes Xinaxtle
--Descripción: obtener los tipos de preguntas para sisco movil por aplicacion
--[Mobile].[SEL_TIPO_PREGUNTAS_SP] 1
-- =============================================
CREATE PROCEDURE [Mobile].[SEL_TIPO_PREGUNTAS_SP]
	@idAplicacion int
AS

BEGIN

	SELECT 
		tp.idTipoPregunta
		,tp.nombre
		,tp.icono 
		,COUNT(p.idPregunta) totalPreguntas
	FROM Mobile.TipoPregunta tp 
		LEFT JOIN Mobile.Pregunta p ON tp.idTipoPregunta = p.idTipoPregunta
	WHERE tp.idAplicacion = @idAplicacion
		AND tp.estatus = 1
	GROUP BY tp.idTipoPregunta
		,tp.nombre
		,tp.icono

END
go

grant execute, view definition on Mobile.SEL_TIPO_PREGUNTAS_SP to DevOps
go

