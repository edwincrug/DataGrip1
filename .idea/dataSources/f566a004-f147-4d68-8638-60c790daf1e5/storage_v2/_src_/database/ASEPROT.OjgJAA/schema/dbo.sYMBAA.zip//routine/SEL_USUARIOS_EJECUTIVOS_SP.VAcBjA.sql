
-- ==========================================================================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 10/05/2017
-- ==========================================================================================

CREATE PROC [dbo].[SEL_USUARIOS_EJECUTIVOS_SP]
@idContratoOperacion numeric(18,0)
AS
BEGIN

	SELECT us.idUsuario, us.nombreCompleto, us.nombreUsuario, us.correoElectronico
	FROM dbo.Usuarios AS us
		INNER JOIN dbo.ContratoOperacionUsuario AS contrOpUs ON us.idUsuario = contrOpUs.idUsuario
		INNER JOIN dbo.CatalogoRoles AS catRol ON contrOpUs.idCatalogoRol = catRol.idCatalogoRol
	WHERE (contrOpUs.idCatalogoRol = 3) AND contrOpUs.idContratoOperacion = @idContratoOperacion
	
END
go

