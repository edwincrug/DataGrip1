

/*
	Fecha			Autor			Descripción
	26-Jun-2018		Jose Etmanuel	Se crea el SP para obtener el mail y el pass
	
*/


CREATE PROCEDURE [Banorte].[APP_OBTENER_USUARIO]
	@telefono VARCHAR(MAX),
	@email VARCHAR(MAX)
AS   
BEGIN
	IF EXISTS (SELECT * FROM [dbo].[Usuarios] where [nombreUsuario] = @email AND [telefonoUsuario] =@telefono )
	BEGIN
		SELECT * FROM [dbo].[Usuarios] where [nombreUsuario] = @email AND [telefonoUsuario] =@telefono 
	END
	ELSE
	BEGIN
		SELECT '' as correoElectronico;
	END
END
go

grant execute, view definition on Banorte.APP_OBTENER_USUARIO to DevOps
go

