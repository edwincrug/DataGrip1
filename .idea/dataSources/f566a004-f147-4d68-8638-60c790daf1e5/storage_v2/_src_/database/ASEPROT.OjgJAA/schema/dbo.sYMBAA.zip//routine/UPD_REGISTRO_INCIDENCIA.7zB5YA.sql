CREATE PROCEDURE [dbo].[UPD_REGISTRO_INCIDENCIA]
	@idTask  VARCHAR(50) = '',
	@idError INT = 0
AS
BEGIN
		
		
	UPDATE ASEPROT.dbo.SaveError
	SET idTask = @idTask
	WHERE idError =  @idError
	SELECT 1 AS ok
END
go

