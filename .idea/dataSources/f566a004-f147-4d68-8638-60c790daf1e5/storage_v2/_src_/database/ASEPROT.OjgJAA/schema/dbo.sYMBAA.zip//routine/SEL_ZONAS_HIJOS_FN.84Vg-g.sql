
--SELECT [dbo].[SEL_ZONAS_HIJOS_FN](1)
CREATE FUNCTION [dbo].[SEL_ZONAS_HIJOS_FN](@idZona INT)

RETURNS VARCHAR(MAX)
AS
BEGIN
DECLARE @zonas NVARCHAR(MAX)= ''
DECLARE @idPrueba int = 0
DECLARE @zonaminas NVARCHAR(MAX) = ' ';
DECLARE @plusZona NVARCHAR(MAX) = ' ';
--DECLARE @idZona int = 1
DECLARE @idPadre int = 0

DECLARE @VariableTabla TABLE ( --ID INT IDENTITY(1,1),
								idZona INT, 
								idPadre INT, 
								nombreNivel NVARCHAR(150),
								nombre NVARCHAR(150))

INSERT INTO @VariableTabla (idZona, idPadre,nombreNivel,nombre) 
SELECT Zona.idZona, Zona.idPadre, NivelZ.etiqueta AS nombreNivel, Zona.nombre 
FROM Partidas.dbo.Zona AS Zona
	INNER JOIN Partidas.dbo.NivelZona AS NivelZ
	ON Zona.idNivelZona = NivelZ.idNivelZona
WHERE idZona = @IdZona

DECLARE @VariableTablaXXX TABLE (idZona INT)

INSERT INTO @VariableTablaXXX(idZona)
SELECT Zona.idZona FROM Partidas.dbo.Zona AS Zona
	INNER JOIN Partidas.dbo.NivelZona as NivelZ
	ON Zona.idNivelZona = NivelZ.idNivelZona
    WHERE Zona.idPadre in(@IdZona)

	WHILE (@IdZona != @idPrueba)
		BEGIN
			SET @idPrueba = @IdZona
			DECLARE nivel CURSOR FOR
				SELECT Zona.idZona FROM Partidas.dbo.Zona AS Zona
						INNER JOIN Partidas.dbo.NivelZona as NivelZ
						ON Zona.idNivelZona = NivelZ.idNivelZona
				WHERE Zona.idZona in(SELECT idZona FROM @VariableTablaXXX)

					OPEN nivel
					FETCH NEXT FROM nivel INTO @idZona
						WHILE @@FETCH_STATUS = 0
						BEGIN
								INSERT INTO @VariableTabla (idZona,idPadre,nombreNivel,nombre) 
								SELECT Zona.idZona, Zona.idPadre, NivelZ.etiqueta AS nombreNivel, Zona.nombre 
								FROM Partidas.dbo.Zona AS Zona
									INNER JOIN Partidas.dbo.NivelZona as NivelZ ON Zona.idNivelZona = NivelZ.idNivelZona
									WHERE Zona.idZona = @idZona

								INSERT INTO @VariableTablaXXX 
								SELECT idZona 
								FROM @VariableTabla 
								WHERE idZona NOT IN(SELECT idZona FROM @VariableTablaXXX) 

								INSERT INTO @VariableTablaXXX
								SELECT idZona 
								FROM Partidas.dbo.Zona 
								WHERE idPadre IN(SELECT idZona FROM @VariableTablaXXX) AND idZona NOT IN(SELECT idZona FROM @VariableTabla) AND idZona NOT IN(SELECT idZona FROM @VariableTablaXXX)

							FETCH NEXT FROM nivel INTO @idZona
						END
					CLOSE nivel
					DEALLOCATE nivel
			END 
			--SELECT DISTINCT * FROM @VariableTabla
	DECLARE contact_cursor CURSOR FOR
	SELECT DISTINCT idZona FROM @VariableTabla

	OPEN contact_cursor  
	FETCH NEXT FROM contact_cursor INTO @idZona
	WHILE @@FETCH_STATUS = 0  
		BEGIN 

		SET @zonaminas =(SELECT TOP 1 idZona FROM @VariableTabla where idZona=@idZona)
		SET @plusZona = @plusZona + @zonaminas + ', '

		FETCH NEXT FROM contact_cursor INTO @idZona
		END  
	CLOSE contact_cursor  
	DEALLOCATE contact_cursor

	IF((@plusZona IS NOT NULL) AND @plusZona != '')
		SET @zonas= SUBSTRING (@plusZona, 1, Len(@plusZona) - 1 )

	RETURN @zonas;
		
END
go

