


/*
Fecha Creacion 27/11/17
Autor Franck
Desc: crea una nueva
[Banorte].[APP_SERVICIO_NUEVA_CITA] 3824,5,621,171,5,'25/05/2018 00:00:00.000'
*/
CREATE proc [Banorte].[APP_SERVICIO_NUEVA_CITA]
@idUnidad int=0,
@idContratoOperacion int=0,
@idUsuario int=0,
@idTaller int=0,
@idServicio int=0,
@fechaCita NVARCHAR(MAX)=null
as
begin
DECLARE @consecutivoOrden int=0;
DECLARE @idOrdenServicio int=0;
DECLARE @numeroEconomico varchar (20)='';
DECLARE @consecutivoCotizacion int =0;
DECLARE @idCotizacion int=0;
DECLARE @idPreorden int=0;
DECLARE @Taller varchar (max)='';
DECLARE @servicio varchar (max)='';

set @servicio='App móvil, Servicio solicitado:  '+cast((select [descripcion] FROM [Partidas]..[Partida] where [idPartida]= @idServicio) as varchar(max));
set @servicio= substring(@servicio,0,1500);

set @Taller='Taller Solicitado: '+(select nombreComercial from Partidas..Proveedor where idProveedor=@idTaller);

IF (EXISTS(SELECT TOP 1 consecutivoOrden FROM [Ordenes] WHERE idContratoOperacion = @idContratoOperacion))
	BEGIN
		SET @consecutivoOrden = (SELECT TOP 1 consecutivoOrden FROM [Ordenes] WHERE idContratoOperacion = @idContratoOperacion ORDER BY consecutivoOrden DESC) +1
	END
ELSE 
	BEGIN
		SET @consecutivoOrden = 1
	END

	DECLARE @idZona int=0;
	DECLARE @idCentroTrabajo int=0;

SELECT 
	   @numeroEconomico = numeroEconomico,
	   @idContratoOperacion = CP.idContratoOperacion,
	   @idZona=UNI.idZona,@idCentroTrabajo=UNI.idCentroTrabajo
FROM [Unidades] UNI
				INNER JOIN [ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion
WHERE idUnidad = @idUnidad

DECLARE @numeroOrden varchar(max)=(select ISNULL(RIGHT('00' + CAST(@idContratoOperacion AS varchar(2)), 2),'S/N')  
						+ '-' + ISNULL(convert(varchar(max),@numeroEconomico),'S/N') 
						+ '-' + ISNULL(RIGHT( CAST(@consecutivoOrden AS varchar(6)), 6),'S/N'));

insert into Ordenes (fechaCreacionOden,
                     fechaCita,
					 fechaInicioTrabajo,
					 numeroOrden,
					 consecutivoOrden,
					 comentarioOrden,
					 requiereGrua,
					 idCatalogoEstadoUnidad,
					 idZona,
					 idUnidad,
					 idContratoOperacion,
					 idUsuario,
					 idCatalogoTipoOrdenServicio,			 
                     idTipoOrden,
					 idEstatusOrden,
					 idCentroTrabajo,
					 idTaller,
					 idGarantia
					 )
values(getdate(),
       cast(@fechaCita as datetime2),
	   null,
	   @numeroOrden,
	   @consecutivoOrden,
	   @servicio,
	   0,
	   1,
	   @idZona,
	   @idUnidad,
	   @idContratoOperacion,
	   @idUsuario,
	   2,
	   1,
	   1,
	   ISNULL(@idCentroTrabajo,0),
	   @idTaller,
	   0
	   )

SET @idOrdenServicio = @@IDENTITY
INSERT INTO [HistorialEstatusOrden] ([idOrden]
									,[idEstatusOrden]
									,[fechaInicial]
									,[fechaFinal]
									,[idUsuario])
VALUES(@idOrdenServicio,1,GETDATE(),NULL,@idUsuario)    

INSERT INTO  OrdenesConfirmacion (idOrden
								,Id
								,Fecha
								,Observacion
								,idUsuario
								,TallerUsr
								)
VALUES(@idOrdenServicio,1,cast(@fechaCita as datetime2),'Cita generada desde App MiAuto, Favor de confirmar.',@idUsuario,0);

INSERT INTO [dbo].[Notas]([descripcionNota],[idOrden],[idUsuario],[fechaNota],[idEstatusOrden])
VALUES (@servicio, @idOrdenServicio, @idUsuario, GETDATE(),1)
         
        IF (EXISTS(SELECT TOP 1 consecutivoCotizacion FROM [dbo].[Cotizaciones] WHERE idOrden = @idOrdenServicio))
			BEGIN
				SET @consecutivoCotizacion = (SELECT TOP 1 consecutivoCotizacion FROM [dbo].[Cotizaciones] WHERE idOrden = @idOrdenServicio ORDER BY consecutivoCotizacion DESC) +1
			END
		ELSE 
			BEGIN
				SET @consecutivoCotizacion = 1
			END
		
		INSERT INTO [dbo].[Cotizaciones] 
		VALUES(getdate(), 0, @idUsuario,5 , @idOrdenServicio,@numeroOrden+'-'+CONVERT (varchar(5), @consecutivoCotizacion),@consecutivoCotizacion,2,null,null)
		
		SET @idPreorden = (select idCotizacion from cotizaciones where idOrden=@idOrdenServicio)

		INSERT INTO [dbo].[HistorialEstatusCotizacion]
			(fechaInicial,idCotizacion,idUsuario,idEstatusCotizacion)
		VALUES (getdate(), @idPreorden, @idUsuario, 5)

		/*Hasta aqui es la Orden con eststus 1 y preorden*/
		
		update HistorialEstatusOrden set fechaFinal =getdate() where idOrden=@idOrdenServicio

		IF (EXISTS(SELECT TOP 1 consecutivoCotizacion FROM [dbo].[Cotizaciones] WHERE idOrden = @idOrdenServicio))
			BEGIN
				SET @consecutivoCotizacion = (SELECT TOP 1 consecutivoCotizacion FROM [dbo].[Cotizaciones] WHERE idOrden = @idOrdenServicio ORDER BY consecutivoCotizacion DESC) +1
			END
		ELSE 
			BEGIN
				SET @consecutivoCotizacion = 1
			END
		
		INSERT INTO [dbo].[Cotizaciones] 
		VALUES(getdate(), @idTaller, @idUsuario,1 , @idOrdenServicio,@numeroOrden+'-'+CONVERT (varchar(5), @consecutivoCotizacion),@consecutivoCotizacion,2,@idPreorden, null)
		SET @idCotizacion = (select top 1 idCotizacion from cotizaciones where idOrden=@idOrdenServicio order by consecutivoCotizacion desc)

		INSERT INTO [dbo].[HistorialEstatusCotizacion]
			(fechaInicial,idCotizacion,idUsuario,idEstatusCotizacion)
		VALUES (getdate(), @idCotizacion, @idUsuario, 1)

		/*
		INSERT INTO [dbo].[HistorialEstatusCotizacion]
			(fechaInicial,idCotizacion,idUsuario,idEstatusCotizacion)
		VALUES (getdate(), @idCotizacion, @idUsuario, 2)
		*/
				
		insert into CotizacionDetalle values(@idCotizacion,0,1,0,104554,2,null,null,null,null,null,null)

		-- select * from CotizacionDetalle
		update ordenes set idEstatusOrden=1 where idOrden=@idOrdenServicio
		/*
		INSERT INTO [HistorialEstatusOrden] ([idOrden]
									,[idEstatusOrden]
									,[fechaInicial]
									,[fechaFinal]
									,[idUsuario])
        VALUES(@idOrdenServicio,2,GETDATE(),NULL,@idUsuario)    
 */
  		select numeroOrden from Ordenes where idOrden=@idOrdenServicio
end

go

grant execute, view definition on Banorte.APP_SERVICIO_NUEVA_CITA to DevOps
go

