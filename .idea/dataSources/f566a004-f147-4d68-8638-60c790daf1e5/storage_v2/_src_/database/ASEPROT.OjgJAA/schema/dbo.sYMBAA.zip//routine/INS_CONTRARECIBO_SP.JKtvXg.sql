
CREATE PROCEDURE [dbo].[INS_CONTRARECIBO_SP]
	@numeroContrarecibo AS NVARCHAR(200),
	@fechaContrarecibo AS DATETIME = NULL,
	@idContratoOperacion AS INT,
	@idUsuario AS INT
AS
BEGIN

	IF(@fechaContrarecibo IS NULL OR @fechaContrarecibo = '')
		SET @fechaContrarecibo = GETDATE()

	INSERT INTO Contrarecibo VALUES(@numeroContrarecibo, @fechaContrarecibo, @idContratoOperacion, @idUsuario, 0)
	SELECT @@IDENTITY

END
go

