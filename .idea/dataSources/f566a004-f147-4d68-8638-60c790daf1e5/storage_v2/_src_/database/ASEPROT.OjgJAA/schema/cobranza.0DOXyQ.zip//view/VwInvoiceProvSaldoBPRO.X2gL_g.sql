




CREATE VIEW [cobranza].[VwInvoiceProvSaldoBPRO]

AS
select CARTERA.PAR_IDMODULO MODULO,

             CARTERA.PAR_DESCRIP1 DES_CARTERA,

             TIMO.PAR_DESCRIP1 DES_TIPODOCTO, 

             CCP_IDDOCTO,CCP_NODOCTO,

             CCP_IDPERSONA, 

             rtrim(ltrim(PER_PATERNO + ' ' + PER_MATERNO + ' ' + PER_NOMRAZON)) as Nombre, 

             PER_TELEFONO1,

             CCP_FECHVEN,

             CCP_FECHPAG,

             CCP_FECHPROMPAG,

             CCP_FECHREV,

             'IMPORTE' = CASE CARTERA.PAR_IDMODULO

                                         when 'CXP'

                                         then ccp_abono-ccp_cargo

                                         else ccp_cargo-ccp_abono

                                        end, 

             'SALDO' = CASE CARTERA.PAR_IDMODULO

                                        when 'CXP'

                                        then ccp_abono-ccp_cargo + (Select isnull(sum(CCP_ABONO-CCP_CARGO),0)

                 from [192.168.20.29].[GAAutoExpressBanorte].[dbo].VIS_CONCAR01 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO

                 AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA

                 AND MOVIMIENTO.CCP_DOCORI<>'S')

                                        else ccp_CARGO-ccp_ABONO+(Select isnull(sum(CCP_CARGO-CCP_ABONO),0)

                 from [192.168.20.29].[GAAutoExpressBanorte].[dbo].VIS_CONCAR01 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO

                            AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA

                            AND MOVIMIENTO.CCP_DOCORI<>'S')

                            end, 

                            CCP_FECHADOCTO,

                 --CCP_FECHVEN,

                 CCP_TIPODOCTO,

                 CCP_ORIGENCON
FROM [192.168.20.29].[GAAutoExpressBanorte].[dbo].VIS_CONCAR01 AS DOCUMENTO 
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA='CARTERA' 
INNER JOIN [192.168.20.29].[GA_Corporativa].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = 'TIMO' 
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL 
INNER JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].ADE_ORDSERENC  ON CCP_IDDOCTO = OTE_FACTURACOMPRA
WHERE CCP_DOCORI = 'S'  and CCP_TIPODOCTO = 'FAC'  
--AND CCP_IDDOCTO = '281' AND CCP_IDPERSONA=221

UNION ALL
select CARTERA.PAR_IDMODULO MODULO,

             CARTERA.PAR_DESCRIP1 DES_CARTERA,

             TIMO.PAR_DESCRIP1 DES_TIPODOCTO, 

             CCP_IDDOCTO,CCP_NODOCTO,

             CCP_IDPERSONA, 

             rtrim(ltrim(PER_PATERNO + ' ' + PER_MATERNO + ' ' + PER_NOMRAZON)) as Nombre, 

             PER_TELEFONO1,

             CCP_FECHVEN,

             CCP_FECHPAG,

             CCP_FECHPROMPAG,

             CCP_FECHREV,

             'IMPORTE' = CASE CARTERA.PAR_IDMODULO

                                         when 'CXP'

                                         then ccp_abono-ccp_cargo

                                         else ccp_cargo-ccp_abono

                                        end, 

             'SALDO' = CASE CARTERA.PAR_IDMODULO

                                        when 'CXP'

                                        then ccp_abono-ccp_cargo + (Select isnull(sum(CCP_ABONO-CCP_CARGO),0)

                 from [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO

                 AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA

                 AND MOVIMIENTO.CCP_DOCORI<>'S')

                                        else ccp_CARGO-ccp_ABONO+(Select isnull(sum(CCP_CARGO-CCP_ABONO),0)

                 from [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO

                            AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA

                            AND MOVIMIENTO.CCP_DOCORI<>'S')

                            end, 

                            CCP_FECHADOCTO,

                 --CCP_FECHVEN,

                 CCP_TIPODOCTO,

                 CCP_ORIGENCON
FROM [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 AS DOCUMENTO 
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA='CARTERA' 
INNER JOIN [192.168.20.29].[GA_Corporativa].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = 'TIMO' 
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL 
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_ORDSERENC  ON CCP_IDDOCTO = OTE_FACTURACOMPRA
WHERE CCP_DOCORI = 'S'  and CCP_TIPODOCTO = 'FAC'  
--AND CCP_IDDOCTO = '281' AND CCP_IDPERSONA=221


go

