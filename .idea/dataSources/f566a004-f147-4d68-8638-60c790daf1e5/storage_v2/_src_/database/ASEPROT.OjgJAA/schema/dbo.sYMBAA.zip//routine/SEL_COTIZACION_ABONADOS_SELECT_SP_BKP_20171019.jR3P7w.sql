-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>[SEL_COTIZACION_ABONADOS_SELECT_SP] 518,3,1
-- TEST Proveedor   [SEL_COTIZACION_ABONADOS_SELECT_SP] 107,3,1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_COTIZACION_ABONADOS_SELECT_SP_BKP_20171019] --9
 (
	@idUsuario numeric(18,0),
	@idContratoOperacion numeric(18,0),
	@isProduction numeric(18,0)
)
	
AS
BEGIN
	DECLARE @isProveedor NUMERIC(18,0)
	DECLARE @select NVARCHAR(MAX) = ''
	DECLARE	@join	NVARCHAR(MAX) = ''
	DECLARE	@and  NVARCHAR(MAX) = ''
	DECLARE	@order  NVARCHAR(MAX) = ''	
	DECLARE	@where  NVARCHAR(MAX) = ''
	DECLARE	@query  NVARCHAR(MAX) = ''
	DECLARE	@usuario  NVARCHAR(MAX) = ''
	DECLARE @idOperacion INT
	SELECT  @isProveedor = case idCatalogoTipoUsuarios 
	                       when 4 then 1
	                       else 0 
	                       end 
	from Usuarios where idUsuario=@idUsuario 

	DECLARE	@server  NVARCHAR(MAX) = ''
		DECLARE	@db  NVARCHAR(MAX) = ''		

		IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server = SERVER,
				@db = DBProduccion			
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idContratoOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idContratoOperacion
	END

	select @idOperacion = CO.idOperacion
    from ContratoOperacion CO
    where idContratoOperacion = @idContratoOperacion

	SET @select ='

	SELECT DISTINCT
		(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+cast(@idContratoOperacion as varchar)+')) nombreCliente,
		DC.numeroCopade,
		ISNULL(DC.ordenSurtimiento, ''SIN SURTIMIENTO'')as folio,
		O.consecutivoOrden,
		O.numeroOrden,
		--TA.numero as numeroOrdenGlobal,
		C.numeroCotizacion,
		ISNULL(FCO.numFactura,''S/N'') numFactura,
		ISNULL(FCO.total,0) total,		
		--ISNULL(ISNULL([dbo].[SEL_STATUS_COTIZACION_FN](C.idCotizacion),FCO.total),0) as saldoProveedorF,
		--ISNULL(ISNULL(VSC.[DeudaDia],FCO.total),0) as saldoProveedor,
		U.numeroEconomico,
		Z.nombre,
		O.comentarioOrden,
		--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, 2, 2)) AS precioCotizacion,
		COP.COP_IDDOCTO,
		COP.COP_CARGO,
		(COP.COP_CARGO - COP.COP_SALDO ) abono,
		COP.COP_SALDO,
		ISNULL(COP.COP_FECHULTPAG, '''') AS COP_FECHULTPAG,
		(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = O.idOrden  and idEstatusOrden = 3) as fechaIngresoUnidad,  
		O.fechaCreacionOden AS fechaInicio,
		(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = O.idOrden  and idEstatusOrden = O.idEstatusOrden) as fechaFin,  
		C.idCotizacion,
		DC.descripcion,
		COP.COP_FECHOPE,	
		DC.idDatosCopade,
		COP.COP_ORDENGLOBAL,
		TA.idOrdenAgrupada,
		DC.fechaRecepcionCopade
		--DC.subTotal,
		--DC.numeroEstimacion
	 FROM DatosCopade DC 
		JOIN DatosCopadeOrden DCO ON DCO.idDatosCopade = DC.idDatosCopade
		JOIN Ordenes O ON O.idOrden = DCO.idOrden and o.idContratoOperacion = '+cast(@idContratoOperacion as varchar)+'
		JOIN Cotizaciones C ON C.idOrden = O.idOrden
		LEFT JOIN FacturaCotizacion FCO ON FCO.idCotizacion = C.idCotizacion
		JOIN Unidades U ON U.idUnidad=O.idUnidad
		JOIN Partidas..Zona Z ON Z.idZona = O.idZona
		JOIN OrdenAgrupadaDetalle TAD ON TAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
		JOIN OrdenAgrupada TA ON TA.idOrdenAgrupada = TAD.idOrdenAgrupada
		LEFT JOIN [cobranza].[VwStatusCotizacionBase] VSC ON VSC.[idCotizacion] = C.idCotizacion
		JOIN '+@server+'.'+@db+'.[dbo].[ADE_COPADE] COP ON COP.COP_ORDENGLOBAL = TA.numero COLLATE Modern_Spanish_CS_AS'
		

	 IF(@isProveedor = 1)
		BEGIN
			SET @join =
				' inner join Cotizaciones cp on cp.idOrden=o.idOrden '

			SET @and = 
				' and C.idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idOperacion)+')) '
		END
	
	SET @where = ' where COP.COP_STATUS = 4 AND COP.COP_ORDENGLOBAL COLLATE Modern_Spanish_CS_AS NOT IN (SELECT numeroOrdenGlobal FROM OrdenGlobalAbono) '
	
	SET @order = 'order by DC.numeroCopade, O.consecutivoOrden'
	
	SET @query = @select+@where+@and+@order
	print @query
	EXECUTE SP_EXECUTESQL @query
	--SELECT *FROM OrdenGlobalAbono
	
	END
go

