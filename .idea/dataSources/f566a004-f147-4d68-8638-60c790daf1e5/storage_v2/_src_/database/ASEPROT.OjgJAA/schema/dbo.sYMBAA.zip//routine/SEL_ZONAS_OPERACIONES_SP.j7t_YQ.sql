-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 24/05/2017
-- Description:	Obtiene los centros de trabajo por operación 
-- [SEL_ZONAS_OPERACIONES_SP] 1
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_ZONAS_OPERACIONES_SP]
	@idContratoOperacion INT
AS
BEGIN
	
			SELECT ZO.idZona,
				   ZO.nombre 
			FROM [Partidas].dbo.Zona ZO
			INNER JOIN .[Partidas].dbo.nivelZona NZ ON ZO.idNivelZona = NZ.idNivelZona
			INNER JOIN .[Partidas].dbo.licitacion LI ON LI.idCliente = NZ.idCliente
			INNER JOIN .[Partidas].dbo.contrato CON ON LI.idLicitacion = CON.idLicitacion
			INNER JOIN contratoOperacion CO ON CO.idContrato = CON.idContrato
			WHERE CO.idContratoOperacion = @idContratoOperacion AND ZO.estatus=1
			ORDER BY ZO.nombre
	 
END


go

