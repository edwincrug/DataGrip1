/*
	SEL_DETALLE_COTIZACION_SINTALLER_SP @idCotizacion = 88, @idContratoOperacion = 1
*/
CREATE PROCEDURE [dbo].[SEL_DETALLE_COTIZACION_SINTALLER_SP]
	@idCotizacion NUMERIC(18,0) = 0,
	@idContratoOperacion NUMERIC(18,0) = 1
AS
		-- ESTE TOMA EL IDuNIDAD DE NUESTRA TABLA UNIDAD AQUI SE REALIZA UNA UNIDAD CON TIPOUNIDAD
		--DECLARE @idTipoUnidad NUMERIC(18,0) = 0

		--SELECT @idTipoUnidad = UNI.idUnidad 
		--FROM Cotizaciones COTI  --idOrden 62
		--JOIN Ordenes ORD ON COTI.idOrden = ORD.idOrden --62 --idUnidad = 467
		--JOIN Unidades UNI ON ORD.idUnidad = UNI.idUnidad
		--WHERE COTI.idCotizacion = @idCotizacion		
		
		--DECLARE @idContratoUnidad INT = 0
		--DECLARE @idtipounidadencontrado INT = 0

		--SELECT        @idtipounidadencontrado =  idTipoUnidad
		--FROM            Unidades
		--WHERE        (idUnidad = @idTipoUnidad)
		
		
		--SELECT        @idContratoUnidad = idContratoUnidad
		--FROM            Partidas..ContratoUnidad
		--WHERE idContrato = @idContratoOperacion AND idUnidad = @idtipounidadencontrado
				
		
		SELECT --top 1
		 PART.idPartida,
				CONT.idContrato,
				ESP.idEspecialidad,
				ESP.especialidad,
				PARCLAS.idPartidaClasificacion,
				PARCLAS.clasificacion,
				CL2.idPartidaSubClasificacion,
				CL2.subClasificacion,
				partida,
				noParte,
				PART.descripcion,
				PART.foto,
				PART.instructivo,
				ISNULL(CONTPART.venta,0.00) as costo, -- FAL en realidad es el precio de venta quedo asi para no modificar el front
				CONTPART.venta venta,
				PARTEST.idPartidaEstatus,
				isnull(PARTEST.estatus, 'Sin Asignar') as partidaEstatus,
				COTDET.cantidad
		FROM Partidas..Partida PART
		--LQMA 10072017
		-----------------
		--JOIN [Partidas].[dbo].[ProveedorPartida] PROVPART ON PART.idPartida = PROVPART.idPartida --ORIGINAL
		---LQMA 10072017
		JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON PART.idPartida = CONTPART.idPartida 
		JOIN [Partidas].[dbo].[PartidaClasificacion] PARCLAS ON PART.idPartidaClasificacion = PARCLAS.idPartidaClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaSubClasificacion] CL2 ON CL2.idPartidaSubClasificacion = PART.idPartidaSubClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaEstatus] PARTEST ON PARTEST.idPartidaEstatus = PART.estatus--PROVPART.idPartidaEstatus						
		LEFT JOIN [Partidas].[dbo].[ContratoUnidad] CONTUNIDAD ON CONTPART.idContratoUnidad = CONTUNIDAD.idContratoUnidad
		LEFT JOIN [Partidas].[dbo].[Contrato] CONT ON CONTUNIDAD.idContrato = CONT.idContrato
		LEFT JOIN [dbo].[ContratoOperacion] OPE ON OPE.idContrato = CONT.idContrato
		--LEFT JOIN [Partidas].[dbo].[ProveedorCotizacion] PROVCOT ON PROVCOT.idProveedor = PROV.idProveedor --LQMA COMMENT
		LEFT JOIN [Partidas].[dbo].[Unidad] UNI ON UNI.idUnidad = PART.idUnidad
		LEFT JOIN [Partidas].[dbo].[Especialidad] ESP ON ESP.idEspecialidad = PART.idEspecialidad
		LEFT JOIN CotizacionDetalle COTDET ON COTDET.idCotizacion = @idCotizacion AND COTDET.idPartida = PART.idPartida
		WHERE 
		 --CONTPART.idContratoUnidad = @idContratoUnidad
		 --AND 
		 PART.idPartida IN (SELECT idPartida FROM CotizacionDetalle WHERE idCotizacion = @idCotizacion) 
		 AND COTDET.idEstatusPartida = 1

    /*
	SELECT * from ContratoOperacion --idContratoOperacion
	SELECT * FROM Ordenes WHERE --idUnidad
	SELECT * from [Partidas].[dbo].[Contrato]

	SELECT * FROM Unidades
	SELECT * FROM Partidas..Unidad
	
	SELECT * from [Partidas].[dbo].[ContratoUnidad]
	SELECT * from [Partidas].[dbo].[ContratoPartida] 
	*/
go

