--[dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP] 3,null,null,null,null,null,null,'93799912374'
--       [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP] 3
CREATE procedure[dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP_1]
	@idOperacion as INT = null,
    @fechaInicial as VARCHAR(max) = null,
    @fechaFinal as VARCHAR(max) = NULL,
    @taller as VARCHAR(150) = NULL,
    @idCallcenter as INT = NULL,
    @idEstatus as INT = NULL,
    @idZona as INT = NULL,
    @numeroOrden VARCHAR(50) = NULL

AS

	SET DATEFORMAT DMY;

	declare @query nvarchar(max)='';
	declare @whereZona nvarchar(max)='';
	DECLARE @idContratoOperacion NUMERIC(18,0) 

	SET @idContratoOperacion = (SELECT idContratoOperacion FROM ContratoOperacion WHERE idOperacion = @idOperacion)

	set @query='DECLARE @idContrato NUMERIC(18,0) 
	DECLARE @nombreCliente VARCHAR(MAX)

	SET @idContrato= (SELECT idContrato 
	FROM [ContratoOperacion] 
	WHERE idOperacion = '+cast(@idOperacion as nvarchar)+')

	SET @nombreCliente =(SELECT Cli.razonSocial 
	FROM [Partidas].[dbo].[Cliente] Cli
		INNER JOIN [Partidas].[dbo].[Licitacion] Lic ON Lic.idCliente = Cli.idCliente
		INNER JOIN [Partidas].[dbo].[Contrato] Con ON Con.idLicitacion = Lic.idLicitacion
	WHERE Con.idContrato = @idContrato)

	SELECT *, CASE WHEN aplicaFondo=1 THEN ''SI'' ELSE ''NO'' END AS Conciliacion FROM(
			SELECT
				@nombreCliente AS Cliente,
				O.consecutivoOrden AS consecutivoOrden,
				O.numeroOrden AS numeroOrden,
				U.numeroEconomico AS numeroEconomico,
				isnull(DC.numeroCopade,''Sin numero'') AS numeroCopade,
				isnull(PO.folio,''Sin folio'') AS folioPreuspuesto,
				
				[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) talleres,
				Tot.costo AS costo,
				Tot.venta AS venta,
				--DC.total AS venta,
				[dbo].[fnReemplazaASCII_1](isnull(O.comentarioOrden, ''Sin descripcion'')) AS descripcion,
				EO.nombreEstatusOrden AS estatus,
				EO.idEstatusOrden AS idEstatus,
				--ZP.nombre AS nombrePadre,
				(SELECT [dbo].[GET_ZONAS_ORDEN_FN] (Z.idZona)) nombrePadre,
				Z.nombre AS nombreZona,
				Z.idZona,
				O.fechaCreacionOden AS fechaCreacionOrden,
				CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <=''12/11/2018'' THEN 1
				ELSE 0 END
				AS aplicaFondo,
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =4) AS fechaAprobacion,      
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =5) AS fechaProceso,   
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =6) AS fechaTerminoTrabajo,
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =7) AS fechaSalida,
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =8) AS fechaFinaliza,
				VOSDO.Dias AS Dias,
				isnull(P.folioPresupuesto,''Sin Orden de Surtimiento'') as ordenSurtimiento
			FROM Ordenes O
				JOIN Unidades U ON U.idUnidad = O.idUnidad
				JOIN EstatusOrdenes EO ON EO.idEstatusOrden = o.idEstatusOrden
				JOIN Partidas..Zona Z ON Z.idZona = O.idZona
				--JOIN Partidas..Zona ZP ON ZP.idZona = Z.idPadre
				LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = O.idOrden
				LEFT JOIN DatosCopade DC ON DC.idDatosCopade = DCO.idDatosCopade
				LEFT JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden
				LEFT JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto
				LEFT JOIN [report].[VwOrdenTotales] Tot ON  Tot.idOrden = o.idOrden
				LEFT JOIN  [report].[VwOrdenStatusMaxDateDias] VOSDO ON VOSDO.[idOrden] = O.[idOrden]  and VOSDO.[idEstatusOrden] = O.[idEstatusOrden]
	             		WHERE O.idEstatusOrden not in (13) AND O.idContratoOperacion='+cast(@idContratoOperacion as nvarchar)+')X
      WHERE fechaCreacionOrden BETWEEN COALESCE('+isnull(@fechaInicial,'null')+',fechaCreacionOrden) AND COALESCE('+isnull(@fechaFinal,'null')+',fechaCreacionOrden)
			AND numeroOrden not in (
		                select ordenesFuera.numeroOrden from ( 
		                    select distinct ord.numeroOrden,count (d.idDatosCopadeOrden) cuenta from Ordenes ord
                               join DatosCopadeOrden d on ord.idOrden=d.idOrden 
                               group by ord.numeroOrden having count(d.idDatosCopadeOrden)>1
					    ) ordenesFuera
						)
			AND	('''+isnull(@taller,'null')+''' IS NULL OR talleres LIKE ''%'+isnull(@taller,'')+'%'')
			AND	idEstatus = COALESCE('+isnull(cast(@idEstatus as varchar),'null')+', idEstatus)
			AND	('''+isnull(@numeroOrden,'null')+''' IS NULL OR numeroOrden like ''%'+isnull(@numeroOrden,'')+'%'')  
	    '
		if(@idZona is not null)
		BEGIN
		  set @whereZona=' AND idZona ='+ cast(@idZona as varchar)+' '
		END
		if (@idCallcenter is not null)
		BEGIN
		  set @whereZona=@whereZona+' AND idZona in(
		  select idZona from ContratoOperacionUsuario cou 
		         join ContratoOperacionUsuarioZona couz on cou.idContratoOperacionUsuario=couz.idContratoOperacionUsuario
		  where idUsuario='+cast(@idCallcenter as varchar)+')'
		END
		set @query=@query+@whereZona
	    EXECUTE SP_EXECUTESQL @query
		print @query
go

