-- =============================================
-- Author:		<YJH>
-- Create date: <30/11/2018>
-- Description:	<INSERTA LA PROVISIÓN EN BPRO>
-- [Banorte].[INS_PROVISION] 20, 0, 40546


-- =============================================
CREATE PROCEDURE [Banorte].[INS_PROVISION]
	@idOperacion int,
	@isProduction int,
	@idOrden int
AS
BEGIN
	declare @db nvarchar(100), 
	    @OTE_IDCLIENTE nvarchar(100), 
		@DESGLOSE nvarchar (100)

DECLARE @idTipoOrdenMixta int = 10
DECLARE @idCotizacionRefacciones int = 1
DECLARE @idCotizacionManoObra int = 2
DECLARE @referencia NVARCHAR(10) = '01'
DECLARE @idTaller INT
DECLARE @iva int = 16
DECLARE @status NUMERIC(18,0) = 0
DECLARE @rutaCompra NVARCHAR(100)= 'Factura_'
DECLARE @rutainicio NVARCHAR(100) = '\\192.168.20.18\orden\'
DECLARE @rutafin NVARCHAR(100) = '\'
DECLARE @pdf NVARCHAR(100) = '.pdf'
DECLARE @xml NVARCHAR(100) = '.xml'
DECLARE @OTE_NUMSINIESTRO VARCHAR(30)
DECLARE @OTE_NUMPOLIZA VARCHAR(100)
DECLARE @xmlProveedor xml
DECLARE @numeroOrden nvarchar(100)
DECLARE @idContratoOperacion int

DECLARE @tableEncabezadoRefacciones as table (id [int] IDENTITY(1,1), OTE_IDENT int, OTE_ORDENPEMEX varchar(100), OTE_ORDENANDRADE varchar(100), 
			OTE_REFERENCIA varchar(50), OTE_IDPROVEEDOR numeric(18, 0), OTE_FECHAORDEN varchar(10), OTE_FACTURACOMPRA varchar(20), OTE_TASAIVA numeric(18, 0), 
			OTE_SUBTOTAL numeric(18, 2), OTE_IVA numeric(18, 2), OTE_TOTAL numeric(18, 2), OTE_UUID varchar(36), OTE_XMLCOMPRA varchar(max), 
			OTE_FECHOPE varchar(10), OTE_HORAOPE varchar(8), OTE_STATUS varchar(1), OTE_FECHAPROCESO varchar(10), OTE_HORAPROCESO varchar(8), 
			OTE_ORDENGLOBAL varchar(30), OTE_PDFCOMPRA varchar(100), OTE_RUTAXML varchar(100), OTE_RUTAPDF varchar(100),OTE_IDCLIENTE numeric(18, 0), 
			OTE_DESGLOSE varchar(1), OTE_NUMPOLIZA varchar(100), OTE_NUMSINIESTRO varchar(100), xmlFactura nvarchar(max))

DECLARE @tableEncabezadoManoObra as table (id [int] IDENTITY(1,1), OTE_IDENT int, OTE_ORDENPEMEX varchar(100), OTE_ORDENANDRADE varchar(100), 
			OTE_REFERENCIA varchar(50), OTE_IDPROVEEDOR numeric(18, 0), OTE_FECHAORDEN varchar(10), OTE_FACTURACOMPRA varchar(20), OTE_TASAIVA numeric(18, 0), 
			OTE_SUBTOTAL numeric(18, 2), OTE_IVA numeric(18, 2), OTE_TOTAL numeric(18, 2), OTE_UUID varchar(36), OTE_XMLCOMPRA varchar(max), 
			OTE_FECHOPE varchar(10), OTE_HORAOPE varchar(8), OTE_STATUS varchar(1), OTE_FECHAPROCESO varchar(10), OTE_HORAPROCESO varchar(8), 
			OTE_ORDENGLOBAL varchar(30),OTE_PDFCOMPRA varchar(100), OTE_RUTAXML varchar(100), OTE_RUTAPDF varchar(100),OTE_IDCLIENTE numeric(18, 0), 
			OTE_DESGLOSE varchar(1), OTE_NUMPOLIZA varchar(100), OTE_NUMSINIESTRO varchar(100), xmlFactura nvarchar(max))

DECLARE  @tempClaveSat as table (ClaveProdServ nchar(30), Descripcion varchar(max), Cantidad numeric(18,2), ValorUnitario numeric(18,2),
								 Importe NUMERIC(18,2), ClaveUnidad varchar(50))

DECLARE @tableDetalle as table (OTD_IDENT numeric (18, 0), OTD_CONSECUTIVO numeric (18, 0), OTD_DESCRIPCION varchar (max), OTD_CANTIDAD numeric (18, 0)
           ,OTD_PRECIOUNITARIOCOMPRA numeric (18, 2), OTD_SUBTOTALUNITARIO numeric (18, 2), OTD_IVAUNITARIO numeric (18, 2), OTD_TOTALUNITARIO numeric (18, 2)
		   ,OTD_PRECIOUNITARIOVENTA numeric (18, 2), OTD_FECHOPE varchar (10), OTD_HORAOPE varchar (8), OTD_PORCENTAJE numeric (18, 2), OTD_IDPARTE varchar (60)
		   ,OTD_CVESAT varchar (50))

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
	BEGIN TRAN TranInsertaProvision
	
	SELECT @idTaller=O.idTaller, @numeroOrden=O.numeroOrden, @idContratoOperacion=O.idContratoOperacion
	FROM Ordenes O WHERE O.idOrden = @idOrden
   
	select @referencia=Z.referencia from Partidas.dbo.Proveedor P 
	inner join Partidas.dbo.ContratoProveedor CP on CP.idProveedor = P.idProveedor
	inner join Partidas.dbo.ContratoProveedorZona CPZ on CP.idContratoProveedor = CPZ.idContratoProveedor
	inner join Partidas.dbo.Zona Z on Z.idZona = CPZ.idZona
	where P.idProveedor=@idTaller
	
	SELECT @OTE_NUMSINIESTRO = S.numeroReclamo, @OTE_NUMPOLIZA = S.numeroPoliza 
	FROM Ordenes O
	INNER JOIN [RefaccionMultiMarca].[Relacion].[SiniestroOrdenCotizacion] SOC ON SOC.idOrden = O.idOrden
	INNER JOIN [RefaccionMultiMarca].[Operacion].[Siniestro] S ON SOC.idSiniestro = S.id
	WHERE O.idOrden = @idOrden
		
	IF(@isProduction = 1)
    BEGIN
		SELECT                 
			@db= SERVER+'.'+DBProduccion, 
			@OTE_IDCLIENTE = [idClienteBpro],
			@DESGLOSE = desglose
        FROM ASEPROT.dbo.ContratoOperacionFacturacion 
        WHERE idContratoOperacion =  @idContratoOperacion
    END
	ELSE
    BEGIN
        SELECT 
			@db= SERVER+'.'+DB,
			@OTE_IDCLIENTE = [idClienteBpro],
			@DESGLOSE = desglose
        FROM ASEPROT.dbo.ContratoOperacionFacturacion
		WHERE idContratoOperacion = @idContratoOperacion		
	END

	declare @queryText varchar(max) = 'SELECT OTE_IDENT FROM '+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''''
	declare @tableTemp table (val int)
    insert into @tableTemp exec(@queryText) 		

	IF ( (SELECT COUNT(*) FROM @tableTemp) = 0 ) 
	BEGIN 

		IF ( (SELECT idCatalogoTipoOrdenServicio FROM Ordenes WHERE numeroOrden=@numeroOrden) = @idTipoOrdenMixta)
		BEGIN -- ORDEN DE REFACCIONES Y MANO DE OBRA			
			insert into @tableEncabezadoManoObra
			select 0, C.numeroCotizacion, O.numeroOrden, @referencia, C.idBproProveedor,  CONVERT(VARCHAR(10),GETDATE(),103), FC.numFactura,
			 @iva, SUM(CD.costo * CD.cantidad), SUM(CD.costo * CD.cantidad) * .16, SUM(CD.costo * CD.cantidad) + (SUM(CD.costo * CD.cantidad) * .16)
			, FC.uuid ,@rutaCompra + C.numeroCotizacion + @xml, CONVERT(VARCHAR(10),GETDATE(),103), CONVERT(VARCHAR(8),GETDATE(),108), @status
			, '', '', C.numeroCotizacion,@rutaCompra + C.numeroCotizacion + @pdf		
			,@rutainicio+convert(varchar(max),+O.idOrden)+'\factura\'+convert(varchar(max),+C.idCotizacion)+'\'
			,@rutainicio+convert(varchar(max),+O.idOrden)+'\factura\'+convert(varchar(max),+C.idCotizacion)+'\', @OTE_IDCLIENTE, @DESGLOSE
			,@OTE_NUMPOLIZA, @OTE_NUMSINIESTRO, FC.xml
			 from Ordenes O 
			inner join Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
			inner join CotizacionDetalle CD on Cd.idCotizacion = C.idCotizacion
			inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
			where O.numeroOrden=@numeroOrden and C.idTipoCotizacion = @idCotizacionManoObra			
			GROUP BY C.numeroCotizacion, O.numeroOrden, C.idBproProveedor, FC.numFactura, FC.uuid, O.idOrden, C.idCotizacion, FC.xml
		END 		
		
		insert into @tableEncabezadoRefacciones
			select 0, C.numeroCotizacion, O.numeroOrden, @referencia, C.idBproProveedor,  CONVERT(VARCHAR(10),GETDATE(),103), FC.numFactura
				  , @iva, SUM(CD.costo * CD.cantidad), SUM(CD.costo * CD.cantidad) * .16, SUM(CD.costo * CD.cantidad) + (SUM(CD.costo * CD.cantidad) * .16)
				  , FC.uuid, @rutaCompra + C.numeroCotizacion + @xml, CONVERT(VARCHAR(10),GETDATE(),103), CONVERT(VARCHAR(8),GETDATE(),108), @status
				  , '', '', O.numeroOrden,@rutaCompra + C.numeroCotizacion + @pdf			
				  ,@rutainicio+convert(varchar(max),+O.idOrden)+'\factura\'+convert(varchar(max),+C.idCotizacion)+'\'
				  ,@rutainicio+convert(varchar(max),+O.idOrden)+'\factura\'+convert(varchar(max),+C.idCotizacion)+'\', @OTE_IDCLIENTE, @DESGLOSE
				  ,@OTE_NUMPOLIZA, @OTE_NUMSINIESTRO, FC.xml
			from Ordenes O 
				inner join Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
				inner join CotizacionDetalle CD on Cd.idCotizacion = C.idCotizacion
				inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
				where O.numeroOrden=@numeroOrden 
			GROUP BY C.numeroCotizacion, O.numeroOrden, C.idBproProveedor, FC.numFactura, FC.uuid, O.idOrden, C.idCotizacion, FC.xml		

		insert into [192.168.20.29].GAAutoExpressBanorte.dbo.ADE_ORDSERENC 
		(OTE_ORDENPEMEX, OTE_ORDENANDRADE, OTE_REFERENCIA, OTE_IDPROVEEDOR, OTE_FECHAORDEN, OTE_FACTURACOMPRA, OTE_TASAIVA
		,OTE_SUBTOTAL, OTE_IVA, OTE_TOTAL, OTE_UUID, OTE_XMLCOMPRA, OTE_FECHOPE, OTE_HORAOPE, OTE_STATUS, OTE_FECHAPROCESO, OTE_HORAPROCESO
		,OTE_ORDENGLOBAL, OTE_PDFCOMPRA, OTE_RUTAXML, OTE_RUTAPDF, OTE_IDCLIENTE, OTE_DESGLOSE, OTE_NUMPOLIZA, OTE_NUMSINIESTRO)
		 select OTE_ORDENPEMEX, OTE_ORDENANDRADE, OTE_REFERENCIA, OTE_IDPROVEEDOR, OTE_FECHAORDEN, OTE_FACTURACOMPRA, OTE_TASAIVA
		,OTE_SUBTOTAL, OTE_IVA, OTE_TOTAL, OTE_UUID, OTE_XMLCOMPRA, OTE_FECHOPE, OTE_HORAOPE, OTE_STATUS, OTE_FECHAPROCESO, OTE_HORAPROCESO
		,OTE_ORDENGLOBAL, OTE_PDFCOMPRA, OTE_RUTAXML, OTE_RUTAPDF, OTE_IDCLIENTE, OTE_DESGLOSE, OTE_NUMPOLIZA, OTE_NUMSINIESTRO from @tableEncabezadoRefacciones
		union 
		select OTE_ORDENPEMEX, OTE_ORDENANDRADE, OTE_REFERENCIA, OTE_IDPROVEEDOR, OTE_FECHAORDEN, OTE_FACTURACOMPRA, OTE_TASAIVA
		,OTE_SUBTOTAL, OTE_IVA, OTE_TOTAL, OTE_UUID, OTE_XMLCOMPRA, OTE_FECHOPE, OTE_HORAOPE, OTE_STATUS, OTE_FECHAPROCESO, OTE_HORAPROCESO
		,OTE_ORDENGLOBAL, OTE_PDFCOMPRA, OTE_RUTAXML, OTE_RUTAPDF, OTE_IDCLIENTE, OTE_DESGLOSE, OTE_NUMPOLIZA, OTE_NUMSINIESTRO from @tableEncabezadoManoObra
		
		INSERT INTO [192.168.20.29].GAAutoExpressBanorte.[dbo].[ADE_COPADE]
		(COP_ORDENGLOBAL,COP_COPADE,COP_CVEUSU,COP_FECHOPE,COP_HORAOPE,COP_IDDOCTO,COP_STATUS)
		select OTE_ORDENGLOBAL, '', 'GMI', CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(VARCHAR(8),GETDATE(),108), NULL, 1
		from @tableEncabezadoRefacciones
		union 
		select OTE_ORDENGLOBAL, '', 'GMI', CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(VARCHAR(8),GETDATE(),108), NULL, 1
		from @tableEncabezadoManoObra

		UPDATE @tableEncabezadoRefacciones SET OTE_IDENT = GA.OTE_IDENT FROM @tableEncabezadoRefacciones AS ER
		INNER JOIN [192.168.20.29].GAAutoExpressBanorte.dbo.ADE_ORDSERENC AS GA ON (GA.OTE_ORDENPEMEX = ER.OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS) 

		UPDATE @tableEncabezadoManoObra SET OTE_IDENT = GA.OTE_IDENT FROM @tableEncabezadoManoObra AS ER
		INNER JOIN [192.168.20.29].GAAutoExpressBanorte.dbo.ADE_ORDSERENC AS GA ON (GA.OTE_ORDENPEMEX = ER.OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS)		

		Declare @id int, @count int
		Set @id=1
		select @count=count(*)from @tableEncabezadoRefacciones
		while @id<=@count
		begin 
			delete from @tempClaveSat			
			SET @xmlProveedor = (SELECT REPLACE(REPLACE(REPLACE(xmlFactura, 'ÿ', ''), 'cfdi:', ''), '<?xml version="1.0" encoding="UTF-8"?>', '')
			                     FROM @tableEncabezadoRefacciones where id=@id)
			
			INSERT INTO @tempClaveSat (ClaveProdServ, Descripcion, Cantidad, ValorUnitario, Importe, ClaveUnidad)
				SELECT ClaveProdServ    = T.Item.value('@ClaveProdServ', 'nchar(20)'),
				       Descripcion		 = T.Item.value('@Descripcion', 'varchar(max)'),
					   Cantidad		 = T.Item.value('@Cantidad', 'numeric(18,2)'),
					   ValorUnitario	 = T.Item.value('@ValorUnitario', 'numeric(18,2)'),
					   Importe			 = T.Item.value('@Importe', 'numeric(18,2)'),
					   ClaveUnidad      = T.Item.value('@ClaveUnidad', 'varchar(50)')
				FROM   @xmlProveedor.nodes(' Comprobante/Conceptos/Concepto') AS T(Item)
			
			INSERT INTO [192.168.20.29].GAAutoExpressBanorte.[dbo].[ADE_ORDSERDET]([OTD_IDENT],[OTD_CONSECUTIVO],[OTD_DESCRIPCION],[OTD_CANTIDAD],
						[OTD_PRECIOUNITARIOCOMPRA],[OTD_SUBTOTALUNITARIO],[OTD_IVAUNITARIO],[OTD_TOTALUNITARIO],[OTD_PRECIOUNITARIOVENTA],
                        [OTD_FECHOPE],[OTD_HORAOPE],[OTD_IDPARTE],[OTD_CVESAT])
			SELECT      
				       ER.OTE_IDENT
                       ,ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
                       P.descripcion, --OTD_DESCRIPCION
                       CD.cantidad, --OSD_CANTIDAD                  
                       CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
                       (CD.cantidad * CD.costo), --OTD_SUBTOTALUNITARIO
                       (CD.cantidad * (CD.costo * .16)), --OTD_IVAUNITARIO
                       (CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * .16)), --OTD_TOTALUNITARIO
                       CAST(CD.venta AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
                       CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
                       CONVERT(VARCHAR(8),GETDATE(),108),--hora de la base
					   TEMP.ClaveUnidad, 
					   TEMP.ClaveProdServ
                    FROM Ordenes O
                        JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
                        JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
						JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
						left JOIN @tempClaveSat TEMP ON TEMP.Cantidad = CD.cantidad AND (TEMP.ValorUnitario - .10) <= CD.costo 
													AND (TEMP.ValorUnitario + .10) >= CD.costo 
						inner join @tableEncabezadoRefacciones ER on ER.id=@id
                        WHERE C.numeroCotizacion = ER.OTE_ORDENPEMEX
						AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) AND CD.cantidad >0                       						
						GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida, 
						TEMP.ClaveUnidad, TEMP.ClaveProdServ, ER.OTE_IDENT

				select @id=@id+1
			end
			
			Set @id=1
			select @count=count(*)from @tableEncabezadoManoObra
			while @id<=@count
			begin 
				delete from @tempClaveSat			
				SET @xmlProveedor = (SELECT REPLACE(REPLACE(REPLACE(xmlFactura, 'ÿ', ''), 'cfdi:', ''), 
									'<?xml version="1.0" encoding="UTF-8"?>', '')
										    FROM @tableEncabezadoManoObra where id=@id)

				INSERT INTO @tempClaveSat (ClaveProdServ, Descripcion, Cantidad, ValorUnitario, Importe, ClaveUnidad)
					SELECT ClaveProdServ    = T.Item.value('@ClaveProdServ', 'nchar(20)'),
					       Descripcion		 = T.Item.value('@Descripcion', 'varchar(max)'),
						   Cantidad		 = T.Item.value('@Cantidad', 'numeric(18,2)'),
						   ValorUnitario	 = T.Item.value('@ValorUnitario', 'numeric(18,2)'),
						   Importe			 = T.Item.value('@Importe', 'numeric(18,2)'),
						   ClaveUnidad      = T.Item.value('@ClaveUnidad', 'varchar(50)')
						   FROM   @xmlProveedor.nodes(' Comprobante/Conceptos/Concepto') AS T(Item)

				INSERT INTO [192.168.20.29].GAAutoExpressBanorte.[dbo].[ADE_ORDSERDET]([OTD_IDENT],[OTD_CONSECUTIVO],[OTD_DESCRIPCION],[OTD_CANTIDAD],
						[OTD_PRECIOUNITARIOCOMPRA],[OTD_SUBTOTALUNITARIO],[OTD_IVAUNITARIO],[OTD_TOTALUNITARIO],[OTD_PRECIOUNITARIOVENTA],
                        [OTD_FECHOPE],[OTD_HORAOPE],[OTD_IDPARTE],[OTD_CVESAT])				
				SELECT      
				       ER.OTE_IDENT
                       ,ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
                       P.descripcion, --OTD_DESCRIPCION
                       CD.cantidad, --OSD_CANTIDAD                  
                       CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
                       (CD.cantidad * CD.costo), --OTD_SUBTOTALUNITARIO
                       (CD.cantidad * (CD.costo * .16)), --OTD_IVAUNITARIO
                       (CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * .16)), --OTD_TOTALUNITARIO
                       CAST(CD.venta AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
                       CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
                       CONVERT(VARCHAR(8),GETDATE(),108),--hora de la base
					   TEMP.ClaveUnidad, 
					   TEMP.ClaveProdServ
                    FROM Ordenes O
                        JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
                        JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
						JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
						INNER JOIN @tempClaveSat TEMP ON TEMP.Cantidad = CD.cantidad AND (TEMP.ValorUnitario - .10) <= CD.costo 
													AND (TEMP.ValorUnitario + .10) >= CD.costo 
						inner join @tableEncabezadoManoObra ER on ER.id=@id
                        WHERE C.numeroCotizacion = ER.OTE_ORDENPEMEX
						AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) AND CD.cantidad >0                       						
						GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida, 
						TEMP.ClaveUnidad, TEMP.ClaveProdServ, ER.OTE_IDENT

				select @id=@id+1
			end
			--select * from [192.168.20.29].GAAutoExpressBanorte.dbo.ADE_ORDSERDET where OTD_IDENT=82
--			select top 1 * from facturaCotizacion	
			select OTE_IDENT as idEncabezado from @tableEncabezadoRefacciones 
			union 
			select OTE_IDENT as idEncabezado from @tableEncabezadoManoObra
	END 
	ELSE 
	BEGIN
		SELECT val as idEncabezado from @tableTemp
	END          
	COMMIT TRAN TranInsertaProvision			
END TRY
BEGIN CATCH
	ROLLBACK TRAN TranInsertaProvision
	SELECT ERROR_NUMBER() AS Number,
           ERROR_SEVERITY() AS Severity,
		   ERROR_STATE() AS [State],
		   ERROR_PROCEDURE() AS [Procedure],
		   ERROR_LINE() AS Line,
		   ERROR_MESSAGE() AS [Message]
END CATCH

SET NOCOUNT OFF;
SET XACT_ABORT OFF;
END
go

grant execute, view definition on Banorte.INS_PROVISION to DevOps
go

