CREATE PROC [dbo].[UPD_ESTATUS_ORDENES_COPADE_HISTORICO]
/*
CREATE DATE 05,10,2017
DESC Actualiza los estatus de las ordenes si no corresponden con su correspondiente Estatus en Copades
[UPD_ESTATUS_ORDENES_COPADE_HISTORICO] 1,3
*/
@isProduction numeric(20) = null,
@idContratoOperacion numeric(20) = null

as
DECLARE	@server  VARCHAR(max) = ''
DECLARE	@db  VARCHAR(max) = ''	
DECLARE	@historicoBase  VARCHAR(max) = ''	

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server = SERVER,
				@db = DBProduccion		
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idContratoOperacion =  @idContratoOperacion
	END
ELSE 
	BEGIN
		SELECT 
				@server=SERVER,
				@db = DB
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idContratoOperacion =  @idContratoOperacion
	END
IF (@idContratoOperacion=3)
BEGIN
  SET @historicoBase='9'
END
ELSE
BEGIN 
  SET @historicoBase='8'
END


declare @query nvarchar(max)='
DECLARE @idOrden AS numeric(18)
DECLARE @idEstatuscopade AS numeric(18)
DECLARE ordenCursor CURSOR FOR select distinct o.idOrden,a.COP_STATUS
from DatosCopadeOrden dco 
     inner join OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
     inner join OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
     inner join Ordenes o on o.idOrden=dco.idOrden
     inner join  '+@server+'.'+@db+'.dbo.ADE_COPADE a on a.COP_ORDENGLOBAL=oa.numero COLLATE Latin1_General_CI_AS
where 
(a.COP_STATUS=3 and o.idEstatusOrden not in (12,13)) or (a.COP_STATUS=4 and o.idEstatusOrden not in (11,13))
 or(a.COP_STATUS=2 and o.idEstatusOrden not in (10,13))or(a.COP_STATUS=1 and o.idEstatusOrden not in (9,13))
  and o.idOrden not in
(
select ordenesFuera.idOrden from
(
select distinct o.idOrden,count(a.COP_STATUS) count
from DatosCopadeOrden dco 
     inner join OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
     inner join OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
     inner join Ordenes o on o.idOrden=dco.idOrden
     inner join  '+@server+'.'+@db+'.dbo.ADE_COPADE a on a.COP_ORDENGLOBAL=oa.numero COLLATE Latin1_General_CI_AS
  group by o.idorden having count(a.COP_STATUS)>1) ordenesFuera
)
OPEN ordenCursor
FETCH NEXT FROM ordenCursor INTO @idOrden,@idEstatuscopade 
WHILE @@fetch_status = 0
BEGIN

	 if (@idEstatuscopade=1)
	 begin
	 if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden='+@historicoBase+')
	 begin
		update Ordenes
		set idEstatusOrden=9 
		where idOrden=@idOrden

		update HistorialEstatusOrden
		  set fechaFinal=GETDATE()
		where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
		
	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

		insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		select top 1 @idOrden,9,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
	 end
	 end
	 if (@idEstatuscopade=2)
	 begin

	 if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden='+@historicoBase+')
	 begin

		update Ordenes
		set idEstatusOrden=10
		where idOrden=@idOrden

		update HistorialEstatusOrden
		  set fechaFinal=GETDATE()
		where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
		
	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=9)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,9,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

		insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		select top 1 @idOrden,10,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
	 end
	 end
	 if (@idEstatuscopade=3)
	 begin
	 if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden='+@historicoBase+')
	 begin

		update Ordenes
		set idEstatusOrden=12 
		where idOrden=@idOrden

		update HistorialEstatusOrden
		  set fechaFinal=GETDATE()
		where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)

	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end
		
	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=9)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,9,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=10)
		begin 
		    insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		    select top 1 @idOrden,10,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

		if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=11)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,11,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

		insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		select top 1 @idOrden,12,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
	 end
	 end 

	 if (@idEstatuscopade=4)
	 begin

	 if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden='+@historicoBase+')
	 begin
	    print @idOrden

		update Ordenes
		set idEstatusOrden=11 
		where idOrden=@idOrden

		update HistorialEstatusOrden
		  set fechaFinal=GETDATE()
		where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)

	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=9)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,9,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=10)
		begin 
		      insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		      select top 1 @idOrden,10,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

		insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		select top 1 @idOrden,11,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
	 end
	 end
    FETCH NEXT FROM ordenCursor INTO @idOrden, @idEstatuscopade 
END
CLOSE ordenCursor
DEALLOCATE ordenCursor
'
EXECUTE SP_EXECUTESQL @query
--print @query
go

