
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 07/07/2017
-- Description:	Obtiene los RFC de los actores con respecto al numero de cotización}
-- Test: [dbo].[SEL_VALIDA_RFC_FACTURA_SP] '26-23350-10559-1', '1A1D46FF-D9D0-42BA-9415-04EE8B888C66'
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_VALIDA_RFC_FACTURA_SP]
    @numeroCotizacion NVARCHAR(MAX),
	@UUID NVARCHAR(MAX) = NULL
AS   
	-- DECLARE @numeroCotizacion VARCHAR(MAX) = '03-1648111060099-000072-1';
	
	-- Se obtiene el RFC del Cliente
	DECLARE @idOrden NUMERIC(18,0) = ( SELECT idOrden FROM Cotizaciones WHERE numeroCotizacion = @numeroCotizacion AND idOrden is not null AND idEstatusCotizacion<>4);
	DECLARE @idCotizacion NUMERIC(18,0) = ( SELECT idCotizacion FROM Cotizaciones WHERE numeroCotizacion = @numeroCotizacion AND idOrden is not null AND idEstatusCotizacion<>4);
	DECLARE @idContratoOperacion NUMERIC(18,0) = ( SELECT idContratoOperacion FROM Ordenes WHERE idOrden = @idOrden );
	DECLARE @idOperacion NUMERIC(18,0) = ( SELECT idOperacion FROM ContratoOperacion WHERE idContrato = @idContratoOperacion );
	DECLARE @idContrato NUMERIC(18,0) = ( SELECT idContrato FROM ContratoOperacion WHERE idContrato = @idContratoOperacion );

	/*DECLARE @RFCCliente VARCHAR(MAX) = (SELECT E.rfc FROM ContratoOperacion CO
										JOIN Partidas..Contrato C ON C.idContrato = CO.idContrato
										JOIN Partidas..Licitacion L ON L.idLicitacion=C.idLicitacion
										JOIN Partidas..Empresa E ON E.idEmpresa = L.idEmpresa
										WHERE CO.idContratoOperacion=@idContratoOperacion);*/
	DECLARE @RFCCliente VARCHAR(MAX) = (SELECT RFC FROM ContratoOperacionFacturacion WHERE idContratoOperacion=@idContratoOperacion);
	
	DECLARE @existeUUID INT
	IF EXISTS(SELECT 1 FROM facturaCotizacion WHERE uuid=@UUID AND idCotizacion<>@idCotizacion)
		BEGIN
			SET @existeUUID = 1
		END
	ELSE
		BEGIN
			SET @existeUUID = 0
		END

	DECLARE @UUIDD VARCHAR(MAX) = (SELECT uuid FROM FacturaCotizacion WHERE idCotizacion=@idCotizacion)
	-- Se obtiene el RFC del Taller
	DECLARE @RFCTaller VARCHAR(MAX) = (SELECT PRO.RFC FROM Cotizaciones COTI
										INNER JOIN [Partidas].dbo.[Proveedor] PRO ON COTI.idTaller = PRO.idProveedor
										INNER JOIN Partidas..ProveedorEncabezado PE ON PE.idProveedorEncabezado = PRO.idProveedorEncabezado
										WHERE numeroCotizacion = @numeroCotizacion AND idOrden is not null AND idEstatusCotizacion<>4);
										
	SELECT @idOrden idOrden, @idCotizacion idCotizacion, @RFCCliente RFCCliente, @RFCTaller RFCTaller, @UUIDD UUIDB, @existeUUID existeUUID;

	--select * from FacturaCotizacion where idCotizacion=21457
go

