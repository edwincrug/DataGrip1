-- =============================================
-- Autor: Miguel Angel Reyes
-- Fecha: 07/09/2018
-- Insertar las sugerencia enviadas desde la aplicacion mobile
-- [Mobile].[Ins_Sugerencia_SP] 123,'EL CHIDO','Tu aplicacion no vale pa ni ma..', 777
-- =============================================

CREATE PROCEDURE [Mobile].[Ins_Sugerencia_SP]
	@codigo				int
	,@destino			nvarchar(100)
	,@mensaje			nvarchar(400)
	,@idUsuario			numeric

AS
BEGIN

	BEGIN TRY

	INSERT INTO [Mobile].[Sugerencia] (
		[codigo]
		,[destino]
		,[mensaje]
		,[alta]
		,[idUsuario]
	) VALUES (
		@codigo
		,@destino
		,@mensaje
		,GETDATE()
		,@idUsuario
	)

	--SELECT 1 estatus, @@IDENTITY idSugerencia, 'Agregado correctamente' mensaje, 'destajador57@gmail.com' correo
	SELECT 1 estatus, @@IDENTITY idSugerencia, 'Agregado correctamente' mensaje, 'comentarios@aexpress.com.mx' correo

	SELECT 
		[idUsuario]
		,[nombreUsuario]
		,[nombreCompleto]
		,[correoElectronico]
		,[telefonoUsuario] 
	FROM [dbo].[Usuarios] 
	WHERE idUsuario = @idUsuario

	END TRY
	BEGIN CATCH

	SELECT 0 estatus, 0 idSugerencia, 'Ocurrio un error' mensaje

	END CATCH

END
go

grant execute, view definition on Mobile.Ins_Sugerencia_SP to DevOps
go

