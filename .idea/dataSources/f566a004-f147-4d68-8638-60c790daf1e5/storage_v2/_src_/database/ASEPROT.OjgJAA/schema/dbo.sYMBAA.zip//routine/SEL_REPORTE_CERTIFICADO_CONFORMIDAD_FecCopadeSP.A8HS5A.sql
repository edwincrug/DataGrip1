-- EXEC [dbo].[SEL_REPORTE_CERTIFICADO_CONFORMIDAD_FecCopadeSP] 3


CREATE procedure  [dbo].[SEL_REPORTE_CERTIFICADO_CONFORMIDAD_FecCopadeSP] 

@idOperacion as int ,
@fechaInicial as varchar(25) =NULL,
@fechaFinal as varchar(25)= NULL,
@idZona as int=NULL,
@numeroOrden varchar(50) = NULL

AS
BEGIN

		SELECT * FROM 
				(
					select (SELECT [dbo].[SEL_NOMBRE_CLIENTE](@idOperacion)) AS Cliente
							,ORD.consecutivoOrden
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona	
							--,[dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden) talleres		
							,(SELECT [dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS venta
							,(SELECT [dbo].[SEL_PRECIO_COSTO_FN](ORD.idOrden, ORD.idContratoOperacion, 3, 107, 2)) AS costo				
							--,0 costo
							--,0 venta
							,ORD.comentarioOrden descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus							
							,ORD.fechaCreacionOden as fechaCreacionOrden        						
							,(select top 1 fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =6)  as fechaTerminoTrabajo
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
							,isnull(p.folioPresupuesto,0 ) folioPresupuesto
							,isnull(P.solpe,0) solpe
							,isnull(PO.folio, 'S/N') folioCertificado
							,isnull(DC.numeroCopade, 'S/N') numeroCopade
							,isnull(DC.fechaRecepcionCopade, '') fechaRecepcionCopade
					FROM Ordenes ORD
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden						
						INNER JOIN ContratoOperacion CO on CO.idContratoOperacion = ORD.idContratoOperacion
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						INNER JOIN PresupuestoOrden PO on ORD.idOrden =PO.idOrden
						INNER JOIN Presupuestos P on p.idPresupuesto =PO.idPresupuesto 
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = ORD.idOrden
						left JOIN DatosCopade DC ON DC.idDatosCopade = dco.idDatosCopade				
					WHERE ORD.idEstatusOrden not in (13) AND ORD.idContratoOperacion = @idOperacion
				) as tableResult

		WHERE	fechaTerminoTrabajo
		BETWEEN isnull(@fechaInicial,convert(datetime,'1/1/1800')) 
		AND		isnull(@fechaFinal,convert(datetime,'1/1/2500'))		
		AND		(@numeroOrden IS NULL OR numeroOrden like '%'+ @numeroOrden+ '%') 
		AND		(@idZona IS NULL OR idZona = @idZona )  
		

		
END
go

