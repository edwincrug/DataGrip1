

CREATE VIEW [dbo].[vwCorreosTOTALPLAY]
AS

/*PRODUCCION*/
SELECT 'Rubén Reyna'  AS Nombre,'ruben.reyna@grupoandrade.com.mx' AS Email
UNION 
SELECT 'Ejecutivo de cuenta' AS Nombre,'ejecutivodecuenta@centraldeoperaciones.com' AS Email
UNION 
SELECT 'Brauilio Solano' AS Nombre,'ejecutivodecuenta2@centraldeoperaciones.com' AS Email

go

