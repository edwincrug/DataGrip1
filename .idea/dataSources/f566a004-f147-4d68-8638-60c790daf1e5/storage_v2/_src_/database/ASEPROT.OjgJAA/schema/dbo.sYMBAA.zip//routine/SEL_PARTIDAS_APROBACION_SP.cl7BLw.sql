/*
	SEL_PARTIDAS_APROBACION_SP @idCotizacion = 416363, @usuario = 2179
*/

CREATE PROCEDURE [dbo].[SEL_PARTIDAS_APROBACION_SP]
@idCotizacion NUMERIC = 0,
@usuario NUMERIC = 0,
@estatus NUMERIC = null
AS

DECLARE @idRol INT, @tienePartidaSalidaEnFalso INT,@apruebasPartidaSalidaEnFalso INT

SET @apruebasPartidaSalidaEnFalso = (SELECT COUNT(*) FROM ParametrosGeneralUsuario where IdParametroGeneral=25 and idUsuario=@usuario)

SET @tienePartidaSalidaEnFalso = (SELECT COUNT(*) FROM CotizacionDetalle CD
									INNER JOIN Partidas..Partida P ON P.idPartida=CD.idPartida
									WHERE idCotizacion=@idCotizacion AND P.partida='Salida.Falso')

SELECT @idRol=idCatalogoTipoUsuarios FROM Usuarios WHERE idUsuario=@usuario

DECLARE @excluyePartidasStatus NUMERIC = null
	IF(@estatus != 4) BEGIN SET @excluyePartidasStatus = 3; END
			
	DECLARE @niveles TABLE(id INT IDENTITY(1,1), nivel INT)	
	DECLARE @nivelesTotales TABLE(id INT IDENTITY(1,1), nivel INT)	

	DECLARE  @tipoAprobacion INT = 0, @idContratoOperacion NUMERIC(18,0) = 0
			
	DECLARE @idTaller NUMERIC(18,0) = (SELECT idTaller FROM Cotizaciones WHERE idCotizacion = @idCotizacion);
	IF( @idTaller = 0 )
		BEGIN
			 -- CON LEFT JOIN
			SELECT TOP(1)  @tipoAprobacion = OPEAP.idCatalogoTipo, @idContratoOperacion = CONTOP.idContratoOperacion
			FROM [dbo].[Cotizaciones] COTI 
			inner join [dbo].[CotizacionDetalle] CODE ON COTI.idCotizacion = CODE.idCotizacion 
			inner join [dbo].[Ordenes] ORD on ORD.idOrden = COTI.idOrden
			inner join [ContratoOperacion] CONTOP ON ORD.idContratoOperacion = CONTOP.idContratoOperacion
			inner JOIN [dbo].[OperacionAprobacion] OPEAP ON OPEAP.idOperacionContrato = CONTOP.idContratoOperacion
			WHERE COTI.idCotizacion = @idCotizacion
			AND (@excluyePartidasStatus IS NULL OR CODE.idEstatusPartida !=@excluyePartidasStatus)
			
			--print @idContratoOperacion
				
			INSERT INTO @niveles
			SELECT nivel FROM ContratoOperacionUsuarioNivel 
			WHERE idContratoOperacionUsuario = (SELECT idContratoOperacionUsuario 
			FROM  [dbo].[ContratoOperacionUsuario]
			WHERE idContratoOperacion = @idContratoOperacion AND idUsuario = @usuario)
			
			SELECT DISTINCT PART.idPartida,
							ESP.idEspecialidad,
							ESP.especialidad,
							CL1.idPartidaClasificacion,
							CL1.clasificacion,
							CL2.idPartidaSubClasificacion,
							CL2.subClasificacion,
							PART.partida,
							PART.noParte,
							PART.descripcion,
							PART.foto,
							PART.instructivo,
							ISNULL(CODE.cantidad * PROVPART.costo,0.00) AS costoTotal,
							ISNULL(CODE.cantidad * CONTPART.venta,0.00) AS ventaTotal,--PART.idTaller,
								CODE.idEstatusPartida,
								OPEAP.idCatalogoTipo,
								PARTEST.idPartidaEstatus,
								ISNULL(PARTEST.estatus, 'Sin Asignar') AS partidaEstatus,
								CASE OPEAP.idCatalogoTipo 
								WHEN 1 THEN
										(SELECT nivel
											FROM DetalleOperacionAprobacionMonto
											WHERE nivel IN
												(SELECT nivel
												FROM @niveles)
											AND CONTPART.venta BETWEEN montoDe AND montoA
											AND idOperacionContrato = @idContratoOperacion )
									WHEN 2 THEN --aprobacion por partida
										(SELECT nivel
											FROM DetalleOperacionAprobacionPartida
											WHERE nivel IN
												(SELECT nivel
												FROM @niveles)
											AND idPartida = PART.idPartida
											AND idOperacionContrato = @idContratoOperacion )
									ELSE 0
								END nivel,
								CASE OPEAP.idCatalogoTipo
									WHEN 1 THEN --aprobacion por monto
										(SELECT COUNT(*)
											FROM DetalleOperacionAprobacionMonto
											WHERE nivel IN
												(SELECT nivel
												FROM @niveles)
											AND CONTPART.venta BETWEEN montoDe AND montoA
											AND idOperacionContrato = @idContratoOperacion )
									WHEN 2 THEN --aprobacion por partida
										(SELECT COUNT(*)
											FROM DetalleOperacionAprobacionPartida
											WHERE nivel IN
												(SELECT nivel
												FROM @niveles)
											AND idPartida = PART.idPartida
											AND idOperacionContrato = @idContratoOperacion )
									ELSE OPEAP.idCatalogoTipo
								END Aprueba,
								CODE.cantidad AS cantidad,
								PROVPART.costo,
								CONTPART.venta,
								COTI.idTaller,
								CODE.idCotizacionDetalle,
							CASE WHEN PART.noParte='0003' AND idOperacionContrato IN(31,32) AND @idRol=1 THEN 1 ELSE 0 END AS esNRFM,
			CASE
			WHEN @apruebasPartidaSalidaEnFalso>0 and PART.partida='Salida.Falso' THEN 1 
			ELSE 0
			END ModSalFalso,
			@tienePartidaSalidaEnFalso AS tienePartidaSalidaEnFalso,
			@apruebasPartidaSalidaEnFalso AS apruebasPartidaSalidaEnFalso
			FROM [dbo].[Cotizaciones] COTI
					INNER JOIN [dbo].[CotizacionDetalle] CODE ON COTI.idCotizacion = CODE.idCotizacion
					INNER JOIN [Partidas].[dbo].[Partida] PART ON CODE.idPartida = PART.idPartida
					INNER JOIN [dbo].[Ordenes] ORD ON COTI.idOrden = ORD.idOrden
					INNER JOIN [dbo].[ContratoOperacion] CONTOP ON ORD.idContratoOperacion = CONTOP.idContratoOperacion
					LEFT JOIN [Partidas].[dbo].[ContratoProveedor] CPRO ON CPRO.idContrato = CONTOP.idContrato
					AND COTI.idTaller = CPRO.idProveedor
					LEFT JOIN [Partidas].[dbo].[Contrato] CONT ON CPRO.idContrato = CONT.idContrato
					LEFT JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON PART.idPartida = CONTPART.idPartida
					LEFT JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = CPRO.idProveedor
					LEFT JOIN [Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = P.idProveedor
					AND PE.idEspecialidad = PART.idEspecialidad
					LEFT JOIN .[Partidas].[dbo].[Especialidad] ESP ON ESP.idEspecialidad = PE.idEspecialidad
					LEFT JOIN [Partidas]..[ProveedorCotizacion] PROVCOT ON P.idProveedor = PROVCOT.idProveedor
					AND PROVCOT.idCotizacionEstatus = 3
					LEFT JOIN [Partidas].[dbo].[ProveedorPartida] PROVPART ON PART.idPartida = PROVPART.idPartida
					AND PROVPART.idProveedorCotizacion = PROVCOT.idProveedorCotizacion 
					LEFT JOIN [Partidas].[dbo].[PartidaEstatus] PARTEST ON PARTEST.idPartidaEstatus = PART.estatus
					LEFT JOIN [Partidas].[dbo].[Unidad] UNID ON UNID.idUnidad = PART.idUnidad
					LEFT JOIN [Partidas].[dbo].[PartidaClasificacion] CL1 ON CL1.idPartidaClasificacion = PART.idPartidaClasificacion
					LEFT JOIN [Partidas].[dbo].[PartidaSubClasificacion] CL2 ON CL2.idPartidaSubClasificacion = PART.idPartidaSubClasificacion
					LEFT JOIN [dbo].[OperacionAprobacion] OPEAP ON CONTOP.idContratoOperacion = OPEAP.idOperacionContrato
			WHERE COTI.idCotizacion = @idCotizacion
				AND CODE.idEstatusPartida !=4
				AND (@excluyePartidasStatus IS NULL OR CODE.idEstatusPartida !=@excluyePartidasStatus)
				AND CONTOP.idContratoOperacion = @idContratoOperacion

		END
	ELSE
		BEGIN
			-- CON INNER JOIN
			SELECT TOP(1)  @tipoAprobacion = OPEAP.idCatalogoTipo, @idContratoOperacion = CONTOP.idContratoOperacion
			FROM [dbo].[Cotizaciones] COTI 
			inner join [dbo].[CotizacionDetalle] CODE ON COTI.idCotizacion = CODE.idCotizacion 
			inner join [dbo].[Ordenes] ORD on ORD.idOrden = COTI.idOrden
			inner join [ContratoOperacion] CONTOP ON ORD.idContratoOperacion = CONTOP.idContratoOperacion
			inner JOIN [dbo].[OperacionAprobacion] OPEAP ON OPEAP.idOperacionContrato = CONTOP.idContratoOperacion
			WHERE COTI.idCotizacion = @idCotizacion
			AND (@excluyePartidasStatus IS NULL OR CODE.idEstatusPartida !=@excluyePartidasStatus)

			PRINT @tipoAprobacion
			PRINT @idContratoOperacion
						
			INSERT INTO @niveles
			SELECT nivel FROM ContratoOperacionUsuarioNivel 
			WHERE idContratoOperacionUsuario = (SELECT idContratoOperacionUsuario 
			FROM  [dbo].[ContratoOperacionUsuario]
			WHERE idContratoOperacion = @idContratoOperacion AND idUsuario = @usuario)

			if (select idCatalogoTipo from OperacionAprobacion OA where idOperacionContrato = @idContratoOperacion) = 1
				begin
					insert into @nivelesTotales
					select nivel from DetalleOperacionAprobacionMonto where idOperacionContrato = @idContratoOperacion
				end
			else
				begin
					insert into @nivelesTotales
					select nivel from DetalleOperacionAprobacionPartida where idOperacionContrato = @idContratoOperacion
				end
			
			--select * from @niveles
			
			SELECT DISTINCT PART.idPartida,
			ESP.idEspecialidad,
			ESP.especialidad,
			CL1.idPartidaClasificacion,
			CL1.clasificacion,
			CL2.idPartidaSubClasificacion,
			CL2.subClasificacion,
			PART.partida,
			PART.noParte,
			PART.descripcion,
			PART.foto,
			PART.instructivo,
			ISNULL(CODE.cantidad * CODE.costo,0.00) AS costoTotal,
			ISNULL(CODE.cantidad * CODE.venta,0.00) AS ventaTotal,
			CODE.idEstatusPartida,
			OPEAP.idCatalogoTipo,
			PARTEST.idPartidaEstatus,
			ISNULL(PARTEST.estatus, 'Sin Asignar') AS partidaEstatus,
			CASE OPEAP.idCatalogoTipo
				WHEN 1 THEN --aprobacion por monto
					(SELECT nivel
						FROM DetalleOperacionAprobacionMonto
						WHERE nivel IN
							(SELECT nivel
							FROM @nivelesTotales)
						AND CODE.venta BETWEEN montoDe AND montoA
						AND idOperacionContrato = @idContratoOperacion )
				WHEN 2 THEN --aprobacion por partida
					(SELECT nivel
						FROM DetalleOperacionAprobacionPartida
						WHERE nivel IN
							(SELECT nivel
							FROM @nivelesTotales)
						AND idPartida = PART.idPartida
						AND idOperacionContrato = @idContratoOperacion )
				ELSE 0
			END nivel,
			CASE OPEAP.idCatalogoTipo
				WHEN 1 THEN --aprobacion por monto
					(SELECT COUNT(*)
						FROM DetalleOperacionAprobacionMonto
						WHERE nivel IN
							(SELECT nivel
							FROM @niveles)
						AND CODE.venta BETWEEN montoDe AND montoA
						AND idOperacionContrato = @idContratoOperacion )
				WHEN 2 THEN --aprobacion por partida
					(SELECT COUNT(*)
						FROM DetalleOperacionAprobacionPartida
						WHERE nivel IN
							(SELECT nivel
							FROM @niveles)
						AND idPartida = PART.idPartida
						AND idOperacionContrato = @idContratoOperacion )
				ELSE OPEAP.idCatalogoTipo
			END Aprueba,
			CODE.cantidad AS cantidad,
			CODE.costo,
			CODE.venta,
			COTI.idTaller,
			isnull(AutCODE.fechaAutorizacion,'') as fechaAprobacion,
			isnull(USR.nombreCompleto, '') as usuario,
			CODE.idCotizacionDetalle,
			CODE.rechazadas,
			CASE WHEN PART.noParte='0003' AND idOperacionContrato IN(31,32) AND @idRol=1 THEN 1 ELSE 0 END AS esNRFM,
			CASE 
			WHEN @apruebasPartidaSalidaEnFalso>0 and PART.partida='Salida.Falso' THEN 1 
			ELSE 0
			END ModSalFalso,
			@tienePartidaSalidaEnFalso AS tienePartidaSalidaEnFalso,
			@apruebasPartidaSalidaEnFalso AS apruebasPartidaSalidaEnFalso
			FROM [dbo].[Cotizaciones] COTI
				INNER JOIN [dbo].[CotizacionDetalle] CODE ON COTI.idCotizacion = CODE.idCotizacion
				INNER JOIN [dbo].[Ordenes] ORD ON COTI.idOrden = ORD.idOrden
				INNER JOIN [dbo].[Unidades] U ON ORD.idUnidad = U.idUnidad
				INNER JOIN [dbo].[ContratoOperacion] CONTOP ON ORD.idContratoOperacion = CONTOP.idContratoOperacion
				INNER JOIN [Partidas].[dbo].Contrato CONT ON CONTOP.idContrato = CONT.idContrato
				INNER JOIN [Partidas].[dbo].ContratoUnidad CONTUNI ON CONTUNI.idContrato = CONT.idContrato AND CONTUNI.idUnidad = U.idTipoUnidad
				LEFT JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON CONTPART.idContratoUnidad = CONTUNI.idContratoUnidad AND CONTPART.idPartida = CODE.idPartida
				INNER JOIN [Partidas].[dbo].[Partida] PART ON PART.idPartida = CONTPART.idPartida
				LEFT JOIN [Partidas].[dbo].[ContratoProveedor] CPRO ON CPRO.idContrato = CONT.idContrato AND idProveedor = COTI.idTaller
				LEFT JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = CPRO.idProveedor
				LEFT JOIN [Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = P.idProveedor	AND PE.idEspecialidad = PART.idEspecialidad
				LEFT JOIN .[Partidas].[dbo].[Especialidad] ESP ON ESP.idEspecialidad = PE.idEspecialidad
				LEFT JOIN [Partidas].[dbo].[PartidaEstatus] PARTEST ON PARTEST.idPartidaEstatus = PART.estatus
				LEFT JOIN [Partidas].[dbo].[Unidad] UNID ON UNID.idUnidad = CONTUNI.idUnidad
				LEFT JOIN [Partidas].[dbo].[PartidaClasificacion] CL1 ON CL1.idPartidaClasificacion = PART.idPartidaClasificacion
				LEFT JOIN [Partidas].[dbo].[PartidaSubClasificacion] CL2 ON CL2.idPartidaSubClasificacion = PART.idPartidaSubClasificacion
				LEFT JOIN [dbo].[OperacionAprobacion] OPEAP ON CONTOP.idContratoOperacion = OPEAP.idOperacionContrato
				LEFT JOIN [dbo].[DetalleAutorizacionCotizacion] AutCODE ON AutCODE.idCotizacionDetalle = CODE.idCotizacionDetalle and CODE.idEstatusPartida = AutCODE.idEstatusAutorizacion
				LEFT JOIN [dbo].[Usuarios] USR ON USR.idUsuario = AutCODE.idUsuario
			WHERE COTI.idCotizacion = @idCotizacion
			--AND CODE.idEstatusPartida IN(1,2)
			  AND CODE.idEstatusPartida != 4
			  AND (@excluyePartidasStatus IS NULL
				OR CODE.idEstatusPartida !=@excluyePartidasStatus)
			  AND CONTOP.idContratoOperacion = @idContratoOperacion
		END

go

