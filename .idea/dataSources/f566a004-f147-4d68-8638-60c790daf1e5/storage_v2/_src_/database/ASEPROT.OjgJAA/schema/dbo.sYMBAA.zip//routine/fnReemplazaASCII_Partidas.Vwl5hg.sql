-- =============================================
-- Author:		Eric Reyes X
-- Create date: 15/11/2018
-- Description:	Reemplazamos caracteres especiales
-- =============================================
CREATE FUNCTION [dbo].[fnReemplazaASCII_Partidas]
(
	@cadena VARCHAR(MAX)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	
	DECLARE @retorno VARCHAR(MAX)=''

	
	SET @retorno = REPLACE(ISNULL(@cadena,''),CHAR(29),'')
	SET @retorno = REPLACE(ISNULL(@retorno,''),CHAR(19),'')
	SET @retorno = REPLACE(ISNULL(@retorno,''),CHAR(28),'')
	--SET @retorno = REPLACE(ISNULL(@retorno,''),CHAR(32),'')
	
	RETURN @retorno

END
go

