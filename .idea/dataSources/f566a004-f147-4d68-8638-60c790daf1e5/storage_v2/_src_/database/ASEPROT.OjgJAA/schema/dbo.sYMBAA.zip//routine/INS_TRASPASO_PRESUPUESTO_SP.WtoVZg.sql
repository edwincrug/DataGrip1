create PROCEDURE [dbo].[INS_TRASPASO_PRESUPUESTO_SP]
@idPresupuestoOrigen  as int,
@idPresupuestoDestino as int,
@monto as numeric(18,4)
as
begin

insert into traspasopresupuesto (idPresupuestoOrigen ,idPresupuestoDestino,	monto) 
values (@idPresupuestoOrigen,@idPresupuestoDestino ,@monto )

select @@IDENTITY result
end
go

