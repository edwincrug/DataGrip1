/*
JAGA
FUNCION PARA EXTRAER LOS CORREOS PARA ATT
21/09/2018
*/
CREATE FUNCTION [dbo].[fnCorreosTOTALPLAY]()
Returns VARCHAR(MAX)
AS
BEGIN 

DECLARE @result varchar(max) = ''

SELECT @result=COALESCE(CASE WHEN @result = '' THEN '' ELSE @result + ', ' END,'')+ Email FROM [vwCorreosTOTALPLAY]

RETURN @result
END
go

