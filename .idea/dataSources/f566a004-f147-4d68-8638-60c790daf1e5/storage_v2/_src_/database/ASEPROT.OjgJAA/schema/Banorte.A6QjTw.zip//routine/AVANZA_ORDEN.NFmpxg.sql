-- =============================================
-- Author:		<YJH>
-- Create date: <2018/12/07>
-- Description:	<Avanza la orden al estatus indicado>
-- [BANORTE].[AVANZA_ORDEN] 43054, 5, 836 --18-6766-4407
--update Ordenes set idEstatusOrden=4 where idOrden = 43054
--update Cotizaciones set idEstatusCotizacion=1 where idCotizacion=53793
--delete HistorialEstatusCotizacion where idHistorialEstatusCotizacion in (111582,111583)
--update Ordenes set idEstatusOrden = 4 where idOrden = 43054
-- =============================================
CREATE PROCEDURE [Banorte].[AVANZA_ORDEN]
	@idOrden INT, 
	@idEstatus INT, 
	@idUsuario INT
AS
BEGIN
	SET NOCOUNT ON;		
	BEGIN TRY 
		BEGIN TRAN UpdTrans
		DECLARE @idEstatusA int 
		DECLARE @estatus int = 0
		DECLARE @idEstatusCobranza int = 8 		
		DECLARE @idEstatusProceso int = 5
		DECLARE @idEstatusAceptada int = 3
		DECLARE @idsCotizaciones as table (id int IDENTITY(1,1), idCotizacion int)

		SELECT @idEstatusA=idEstatusOrden FROM Ordenes WHERE idOrden=@idOrden
		
		IF (@idEstatus <= @idEstatusA or @idEstatus > @idEstatusCobranza)
		BEGIN
			SELECT @estatus=1
		END 
		ELSE 
		BEGIN 
			
			UPDATE Ordenes SET idEstatusOrden=@idEstatus WHERE idOrden=@idOrden			
			declare @id int =@idEstatusA+1
			
			while (@id <= @idEstatus)
			begin 
				if( (select count(*) from HistorialEstatusOrden where idOrden = @idOrden
							and idEstatusOrden = @id) = 0)
				INSERT INTO [HistorialEstatusOrden] (idOrden, idEstatusOrden, fechaInicial, fechaFinal, idUsuario)
					VALUES (@idOrden, @id,GETDATE(), GETDATE(), @idUsuario)
				
				select @id = @id+1
			end

			if(@idEstatus>=5)
				update Cotizaciones set idEstatusCotizacion = 3 where 
				idOrden=@idOrden and idEstatusCotizacion<>4

			if (@idEstatusProceso=@idEstatus)
			begin 	
				update Cotizaciones set idEstatusCotizacion = @idEstatusAceptada where 
				idOrden=@idOrden and idEstatusCotizacion<>4

				insert into @idsCotizaciones 
				select idCotizacion from Cotizaciones where idOrden = @idOrden
				declare @idCO int = 1, @lCO int 
				select @lCO = count(*) from @idsCotizaciones 	
							
				declare @idCotizacion int = 0, @idCE int = 2
				while (@idCO <= @lCO)
				begin 		
					select @idCotizacion= idCotizacion from @idsCotizaciones where id= @idCO												
					
					select @idCE= idEstatusCotizacion + 1 from Cotizaciones where idCotizacion = @idCotizacion																				

					while (@idCE <= @idEstatusAceptada)
					begin 				
						if ( (select count(*) from HistorialEstatusCotizacion where idCotizacion = @idCotizacion
							and idEstatusCotizacion = @idCE) = 0)
						begin
							INSERT INTO HistorialEstatusCotizacion (fechaInicial, fechaFinal, idCotizacion, idUsuario, idEstatusCotizacion)
							VALUES (GETDATE(), GETDATE(), @idCotizacion, @idUsuario, @idCE)
						end
						select @idCE = @idCE+1
					end
					
					select @idCO = @idCO+1
				end				
			end 

			SELECT @estatus=1
		END
		
		SELECT @estatus AS ESTATUS, 'ORDEN AVANZADA' AS MSJ

		COMMIT TRAN UpdTrans
	END TRY 	
	BEGIN CATCH
		ROLLBACK TRAN UpdTrans
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.AVANZA_ORDEN to DevOps
go

