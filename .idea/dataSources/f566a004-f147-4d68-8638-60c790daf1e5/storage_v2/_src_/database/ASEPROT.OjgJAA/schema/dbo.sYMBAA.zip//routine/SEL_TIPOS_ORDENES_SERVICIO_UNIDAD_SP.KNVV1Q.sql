
-- =============================================
-- Description:	Obtengo el catalago de tipo de ordenes de servicio con validacion de ordenes
-- =============================================
-- [dbo].[SEL_TIPOS_ORDENES_SERVICIO_UNIDAD_SP] 40700
CREATE PROCEDURE [dbo].[SEL_TIPOS_ORDENES_SERVICIO_UNIDAD_SP]
	@idUnidad INT
AS
BEGIN
	--IF  NOT EXISTS(SELECT 1 FROM Ordenes WHERE idUnidad = @idUnidad AND idEstatusOrden<8  )
		--BEGIN
		declare @idOperacion Numeric(18,0) = (SELECT idOperacion FROM UNIDADES WHERE IDUNIDAD = @idUnidad)
		print @idOperacion
		IF(@idOperacion = 108)
		BEGIN
			SELECT CT.[idCatalogoTipoOrdenServicio] AS idTipoCita
				  ,CT.[nombreTipoOrdenServicio] AS tipoCita
				  ,CT.[descripcionTipoOrden] AS descripcionTipoCita
				  , 0 AS orden 
				  ,CT.Manual as manual
			FROM [dbo].[CatalogoTiposOrdenServicio] CT
			WHERE CT.idCatalogoTipoOrdenServicio = 2
		END
		ELSE
		BEGIN
			SELECT CT.[idCatalogoTipoOrdenServicio] AS idTipoCita
				  ,CT.[nombreTipoOrdenServicio] AS tipoCita
				  ,CT.[descripcionTipoOrden] AS descripcionTipoCita
				  , 0 AS orden 
				  ,CT.Manual as manual
			FROM [dbo].[CatalogoTiposOrdenServicio] CT
		END
			


			  --WHERE [Manual]=1
		--END
	/*ELSE
		BEGIN
			SELECT CT.[idCatalogoTipoOrdenServicio] AS idTipoCita
				  ,CT.[nombreTipoOrdenServicio] AS tipoCita
				  ,CT.[descripcionTipoOrden] AS descripcionTipoCita
				  ,ISnull((SELECT TOP 1  1 FROM Ordenes WHERE idUnidad = @idUnidad AND idEstatusOrden<8 AND  idCatalogoTipoOrdenServicio =  CT.idCatalogoTipoOrdenServicio), 0) AS orden 
			  FROM [dbo].[CatalogoTiposOrdenServicio] CT
		END*/

END

go

