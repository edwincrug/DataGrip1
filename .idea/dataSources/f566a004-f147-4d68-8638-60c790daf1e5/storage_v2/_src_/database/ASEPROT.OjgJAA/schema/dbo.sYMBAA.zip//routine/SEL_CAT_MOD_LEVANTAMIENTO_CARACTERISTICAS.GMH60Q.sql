-- ==========================================================================================
-- DATE:   04/10/2016
-- DESC:   Modificacion al Store que CATALOGOS DE MODULO DE LEVANTAMIENTO POR OPERACION
-- [SEL_CAT_MOD_LEVANTAMIENTO_CARACTERISTICAS] '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21'
-- ==========================================================================================
create PROCEDURE [dbo].[SEL_CAT_MOD_LEVANTAMIENTO_CARACTERISTICAS] (
	@idsCatalogoModuloLevantamientoDetalle varchar(1000)
)
as
begin
	DECLARE @Ids_Cat_MLevantamientoD table(Id numeric(18,0))

	set @idsCatalogoModuloLevantamientoDetalle = @idsCatalogoModuloLevantamientoDetalle+',';
	with cte as
	(
		select SUBSTRING(@idsCatalogoModuloLevantamientoDetalle,1,charindex(',',@idsCatalogoModuloLevantamientoDetalle,1)-1) as val, SUBSTRING(@idsCatalogoModuloLevantamientoDetalle,charindex(',',@idsCatalogoModuloLevantamientoDetalle,1)+1,len(@idsCatalogoModuloLevantamientoDetalle)) as rem 
		UNION ALL
		select SUBSTRING(a.rem,1,charindex(',',a.rem,1)-1)as val, SUBSTRING(a.rem,charindex(',',a.rem,1)+1,len(A.rem)) 
		from cte a where LEN(a.rem)>=1
	) insert into @Ids_Cat_MLevantamientoD select val from cte


	SELECT 
		CMLC.idCatalogoModuloLevantamientoCaracteristica, 
		CMLC.idCatalogoModuloLevantamientoDetalle, 
		CMLC.idCatalogoTipoControl, 
		alias, 
		NombreControl, 
		tipoDato,
		CMLC.consecutivo,
		CMLC.requerido,
		CMLC.descripcion
		FROM 
			CatalogoModuloLevantamientoCaracteristica CMLC
			INNER JOIN CatalogoTipoControl CTC ON CTC.idCatalogoTipoControl = CMLC.idCatalogoTipoControl
	WHERE CMLC.idCatalogoModuloLevantamientoDetalle IN 
	(SELECT Id from @Ids_Cat_MLevantamientoD)
	--SELECT * FROM CatalogoModuloLevantamientoCaracteristica
end
go

