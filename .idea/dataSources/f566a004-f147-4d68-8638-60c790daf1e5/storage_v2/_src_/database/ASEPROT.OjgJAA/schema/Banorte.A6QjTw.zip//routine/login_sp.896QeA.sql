-- =============================================
-- Autor: Miguel Angel Reyes
-- Fecha: 09/08/2018
-- Login para los usuarios de sisco dentro de la aplicacion movil
-- [Banorte].[login_sp] 'SAHI.LLANES', 'SAHI'
-- =============================================
CREATE PROCEDURE [Banorte].[login_sp]
	@usuario		varchar(50),
	@contrasena		varchar(50) 
AS
DECLARE
	@idUsuario int = 0
BEGIN

	SELECT 
		@idUsuario = u.[idUsuario]
	FROM [Usuarios] u inner join Banorte.UsuariosMiAuto uma on u.idUsuario = uma.idUsuario
	WHERE [nombreUsuario] = @usuario 
		AND [contrasenia] = @contrasena	
		AND idCatalogoTipoUsuarios <> 6

	IF (@idUsuario > 0)
	BEGIN
		select 1 estatus, 'Usuario valido' mensaje

		SELECT 
			u.[idUsuario]
			,u.[nombreCompleto] nombre
			,u.telefonoUsuario telefono
			,u.[correoElectronico] correo
		FROM [Usuarios] u inner join Banorte.UsuariosMiAuto uma on u.idUsuario = uma.idUsuario
		WHERE [nombreUsuario] = @usuario 
			AND [contrasenia] = @contrasena
			AND u.idUsuario = @idUsuario
			AND uma.idUsuario = @idUsuario	
			AND idCatalogoTipoUsuarios <> 6

		select 
			u.idUnidad
			,u.numeroEconomico numero
			,u.vin
			,u.placas
			,u.frente 
			,u.modelo
			,tu.tipo
		from unidades u 
			inner join ContratoOperacion co on u.idOperacion = co.idOperacion
			inner join ContratoOperacionUsuario cou on co.idContratoOperacion = cou.idContratoOperacion
			left join [Partidas].dbo.tipounidad tu on tu.idTipoUnidad = u.idTipoUnidad
		where cou.idUsuario = @idUsuario
	END
	ELSE
	BEGIN
		select 0 estatus, 'El usuario no existe' mensaje
	END

END
go

grant execute, view definition on Banorte.login_sp to DevOps
go

