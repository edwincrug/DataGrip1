






CREATE VIEW [cobranza].[VwCotizacionAbonadoSelectGAAutoExpress]
AS
SELECT DISTINCT
		DC.numeroCopade,
		ISNULL(DC.ordenSurtimiento, 'SIN SURTIMIENTO')as folio,
		O.consecutivoOrden,
		O.numeroOrden,
		o.idContratoOperacion,
		--TA.numero as numeroOrdenGlobal,
		C.numeroCotizacion,
		ISNULL(FCO.numFactura,'S/N') numFactura,
		ISNULL(FCO.total,0) total,		
		--ISNULL(ISNULL([dbo].[SEL_STATUS_COTIZACION_FN](C.idCotizacion),FCO.total),0) as saldoProveedorF,
		--ISNULL(ISNULL(VSC.[DeudaDia],FCO.total),0) as saldoProveedor,
		U.numeroEconomico,
		Z.nombre,
		O.comentarioOrden,
		(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, 2, 2)) AS precioCotizacion,
		COP.COP_IDDOCTO,
		COP.COP_CARGO,
		(COP.COP_CARGO - COP.COP_SALDO ) abono,
		COP.COP_SALDO,
		ISNULL(COP.COP_FECHULTPAG, '') AS COP_FECHULTPAG,
		(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = O.idOrden  and idEstatusOrden = 3) as fechaIngresoUnidad,  
		O.fechaCreacionOden AS fechaInicio,
		(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = O.idOrden  and idEstatusOrden = O.idEstatusOrden) as fechaFin,  
		C.idCotizacion,
		DC.descripcion,
		COP.COP_FECHOPE,	
		DC.idDatosCopade,
		COP.COP_ORDENGLOBAL,
		TA.idOrdenAgrupada,
		DC.fechaRecepcionCopade,
		C.idTaller,
		COP.COP_STATUS,
		--COP.COP_ORDENGLOBAL
		--DC.subTotal,
		--DC.numeroEstimacion
		(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden)) as razonSocial,
		O.idZona,
		O.idUsuario
	 FROM DatosCopade DC 
		JOIN DatosCopadeOrden DCO ON DCO.idDatosCopade = DC.idDatosCopade
		JOIN Ordenes O ON O.idOrden = DCO.idOrden 
		--and o.idContratoOperacion = 3
		JOIN Cotizaciones C ON C.idOrden = O.idOrden
		LEFT JOIN FacturaCotizacion FCO ON FCO.idCotizacion = C.idCotizacion
		JOIN Unidades U ON U.idUnidad=O.idUnidad
		JOIN Partidas..Zona Z ON Z.idZona = O.idZona
		JOIN OrdenAgrupadaDetalle TAD ON TAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
		JOIN OrdenAgrupada TA ON TA.idOrdenAgrupada = TAD.idOrdenAgrupada
		--LEFT JOIN [cobranza].[VwStatusCotizacionBase] VSC ON VSC.[idCotizacion] = C.idCotizacion
		JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].[ADE_COPADE] COP 
		  ON COP.COP_ORDENGLOBAL = TA.numero COLLATE Modern_Spanish_CS_AS 
--   where COP.COP_STATUS = 4 
     --AND COP.COP_ORDENGLOBAL COLLATE Modern_Spanish_CS_AS NOT IN (SELECT numeroOrdenGlobal FROM OrdenGlobalAbono) order by DC.numeroCopade, O.consecutivoOrden
	 UNION ALL
	 SELECT DISTINCT
		DC.numeroCopade,
		ISNULL(DC.ordenSurtimiento, 'SIN SURTIMIENTO')as folio,
		O.consecutivoOrden,
		O.numeroOrden,
		o.idContratoOperacion,
		--TA.numero as numeroOrdenGlobal,
		C.numeroCotizacion,
		ISNULL(FCO.numFactura,'S/N') numFactura,
		ISNULL(FCO.total,0) total,		
		--ISNULL(ISNULL([dbo].[SEL_STATUS_COTIZACION_FN](C.idCotizacion),FCO.total),0) as saldoProveedorF,
		--ISNULL(ISNULL(VSC.[DeudaDia],FCO.total),0) as saldoProveedor,
		U.numeroEconomico,
		Z.nombre,
		O.comentarioOrden,
		(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, 2, 2)) AS precioCotizacion,
		COP.COP_IDDOCTO,
		COP.COP_CARGO,
		(COP.COP_CARGO - COP.COP_SALDO ) abono,
		COP.COP_SALDO,
		ISNULL(COP.COP_FECHULTPAG, '') AS COP_FECHULTPAG,
		(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = O.idOrden  and idEstatusOrden = 3) as fechaIngresoUnidad,  
		O.fechaCreacionOden AS fechaInicio,
		(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = O.idOrden  and idEstatusOrden = O.idEstatusOrden) as fechaFin,  
		C.idCotizacion,
		DC.descripcion,
		COP.COP_FECHOPE,	
		DC.idDatosCopade,
		COP.COP_ORDENGLOBAL,
		TA.idOrdenAgrupada,
		DC.fechaRecepcionCopade,
		C.idTaller,
		COP.COP_STATUS,
		--COP.COP_ORDENGLOBAL
		--DC.subTotal,
		--DC.numeroEstimacion
		(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden)) as razonSocial,
		O.idZona,
		O.idUsuario
	 FROM DatosCopade DC 
		JOIN DatosCopadeOrden DCO ON DCO.idDatosCopade = DC.idDatosCopade
		JOIN Ordenes O ON O.idOrden = DCO.idOrden 
		--and o.idContratoOperacion = 3
		JOIN Cotizaciones C ON C.idOrden = O.idOrden
		LEFT JOIN FacturaCotizacion FCO ON FCO.idCotizacion = C.idCotizacion
		JOIN Unidades U ON U.idUnidad=O.idUnidad
		JOIN Partidas..Zona Z ON Z.idZona = O.idZona
		JOIN OrdenAgrupadaDetalle TAD ON TAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
		JOIN OrdenAgrupada TA ON TA.idOrdenAgrupada = TAD.idOrdenAgrupada
		--LEFT JOIN [cobranza].[VwStatusCotizacionBase] VSC ON VSC.[idCotizacion] = C.idCotizacion
		JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_COPADE] COP 
		  ON COP.COP_ORDENGLOBAL = TA.numero COLLATE Modern_Spanish_CS_AS 
--   where COP.COP_STATUS = 4 
     --AND COP.COP_ORDENGLOBAL COLLATE Modern_Spanish_CS_AS NOT IN (SELECT numeroOrdenGlobal FROM OrdenGlobalAbono) order by DC.numeroCopade, O.consecutivoOrden
go

