-- [INS_COMPROBANTE_RECEPCION_LEVANTAMIENTO_DETALLE_SP] 
CREATE PROCEDURE [dbo].[INS_COMPROBANTE_RECEPCION_LEVANTAMIENTO_DETALLE_SP]
@idOrdenModuloLevantamiento INT,
@idCatalogoModuloLevantamientoDetalle INT
--,
--@vin varchar(50),
--@kilometraje int
AS
BEGIN
		DECLARE @idOrdenModuloLevantamientoDetalle INT
		INSERT INTO OrdenModuloLevantamientoDetalle VALUES(@idOrdenModuloLevantamiento, @idCatalogoModuloLevantamientoDetalle)
		--UPDATE unidades set Kilometraje_Actual= @kilometraje where vin= @vin
		SET @idOrdenModuloLevantamientoDetalle = @@IDENTITY
		SELECT @idOrdenModuloLevantamientoDetalle AS idOrdenModuloLevantamientoDetalle, 'Se agrego el detalle del modulo'AS msg,1 AS estatus
END
go

