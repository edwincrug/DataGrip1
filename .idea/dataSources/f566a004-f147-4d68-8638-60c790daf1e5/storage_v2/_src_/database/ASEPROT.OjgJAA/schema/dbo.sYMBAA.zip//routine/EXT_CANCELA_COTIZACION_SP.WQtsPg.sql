
CREATE PROCEDURE [dbo].[EXT_CANCELA_COTIZACION_SP] 
@numeroCotizacion nvarchar(50),
@idUsuario INT

AS
BEGIN

DECLARE @idCotizacion INT
DECLARE @existeFacturaCot NUMERIC (18,0)

SELECT @idCotizacion=idCotizacion FROM Cotizaciones WHERE numeroCotizacion=@numeroCotizacion

	--ACTUALIZA LA COTIZACIÓN A rechazada
	UPDATE Cotizaciones SET idEstatusCotizacion = 4 WHERE idCotizacion = @idCotizacion

	INSERT INTO [dbo].[HistorialEstatusCotizacion]([fechaInicial], [fechaFinal], [idCotizacion], [idUsuario], [idEstatusCotizacion])
	VALUES (GETDATE(), GETDATE(), @idCotizacion, @idUsuario, 4)

	--ACTUALIZA EL DETALLE DE LA COTIZACIÓN A rechazada
	UPDATE CotizacionDetalle SET idEstatusPartida = 3 WHERE idCotizacion = @idCotizacion

	--Valora si existen registros en tabla de facturaCotizacion 
				SELECT @existeFacturaCot= COUNT(*) FROM ASEPROT.dbo.facturaCotizacion where idCotizacion =  @idCotizacion

				IF(@existeFacturaCot > 0)
				BEGIN
				---Eliminar registro en facturaCotizacion
					DELETE FROM ASEPROT.dbo.facturaCotizacion where idCotizacion = @idCotizacion 
				END

    SELECT 10;

END

go

