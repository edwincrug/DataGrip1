-- =============================================
-- Author:		<YJH>
-- Create date: <2019/01/18>
-- Description:	<Obtiene las facturas de proveedores genéricos para poner comentarios en la cxc y cxp de ase>
-- [Banorte].[SEL_DATOS_FACTURACION_GEN] 18
-- =============================================

CREATE PROCEDURE [Banorte].[SEL_DATOS_FACTURACION_GEN]
	@idContratoOperacion int
AS
BEGIN

	DECLARE @facturasProveedor as TABLE ( idOrden int, numeroOrden nvarchar(200), numeroReclamo nvarchar(200), 
		facturaProveedor nvarchar(max), idCotizacion int, servidor nvarchar(100),  facturaCeros nvarchar(100),
		valeInicial int, valeFinal int, factura int, entrega int, fechaEvidenciaCompleta DateTime null, provisionado varchar(100),
		fechaContraRecibo datetime, fechaPromesa datetime, contraRecibo nvarchar(200))
		
	insert into @facturasProveedor
		select O.idOrden, O.numeroOrden, S.numeroReclamo, FC.numFactura, C.idCotizacion, 
		'[192.168.20.29]',
		SUBSTRING(FC.numFactura, 0, PATINDEX('%[0-9]%', FC.numFactura)) +
        REPLICATE('0', ((11-PATINDEX('%[0-9]%', FC.numFactura)) - LEN(SUBSTRING(FC.numFactura, PATINDEX('%[0-9]%', FC.numFactura), len(FC.numFactura)-PATINDEX('%[0-9]%', FC.numFactura))))) + SUBSTRING(FC.numFactura, PATINDEX('%[0-9]%', FC.numFactura), len(FC.numFactura)-PATINDEX('%[0-9]%', FC.numFactura)+1)
		,ISNULL((select top 1 1 from aseprot..evidencias  where idordenservicio=O.idOrden and descripcionEvidencia='ValeInicial'),0) valeInicial,
		ISNULL((select top 1 1 from aseprot..evidencias  where idordenservicio=O.idOrden and descripcionEvidencia='ValeFinal'),0) valeFinal,
		ISNULL((select top 1 1 from aseprot..facturaCotizacion  where idCotizacion = C.idCotizacion),0) factura,
		1 entrega,		
		(select MAX(fechaInicial) from aseprot..HistorialEstatusOrden where idOrden = O.idOrden and idEstatusOrden = 8) fechaEvidenciaCompleta,
		'Entrega Total' provisionado	
		,convert(datetime, CR.fechaContrarecibo, 103),
		dateadd(day,30,convert(datetime, CR.fechaContrarecibo, 103)) as fechaPromesa, 
		CR.numeroContraRecibo
	from ASEPROT.dbo.Ordenes O
	inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
	inner join ASEPROT.DBO.facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
	inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden and SOC.idCotizacionSISCO= C.idCotizacion
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
	inner join RefaccionMultiMarca.Operacion.Cotizacion OC on OC.idCotizacion = SOC.idCotizacion
	inner join RefaccionMultiMarca.[Seguridad].[UsuarioModuloSeguridad] UMS ON UMS.idUsuario = OC.idUsuario and UMS.idProveedorGenerico=1
	inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
	inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = U.marca
	left join ASEPROT.dbo.DatosCopade D on D.numeroCopade = O.numeroOrden
	left join [ASEPROT].[dbo].[ContrareciboDatosCopade] CDC on CDC.idDatosCopade = D.idDatosCopade
	left join [ASEPROT].[dbo].[Contrarecibo] CR on CR.idContrarecibo =CDC.idContrarecibo
	where  O.idContratoOperacion=@idContratoOperacion and UMS.idProveedorGenerico=1 and C.fechaCotizacion >= DATEADD(DAY, -30, GETDATE()) and C.fechaCotizacion <= GETDATE()
	order by O.idOrden			


	select * from @facturasProveedor

END

go

grant execute, view definition on Banorte.SEL_DATOS_FACTURACION_GEN to DevOps
go

