-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 08/08/2018
-- Description:	Elimina la unidad para el usuario banorte
-- =============================================

CREATE PROCEDURE [Banorte].[Elimina_Rel_Uni] 
	@idUnidad int,
	@idUsuario int
AS
BEGIN
	IF exists (select * from [usuarioUnidadContratoOperacion]  WHERE [idUsuario] = @idUsuario and [idUnidad] = @idUnidad)
	BEGIN TRY
		DELETE FROM [usuarioUnidadContratoOperacion]
		WHERE [idUsuario] = @idUsuario and [idUnidad] = @idUnidad;
		SELECT 'OK' AS OK
	END TRY
	BEGIN CATCH
		SELECT  
			'Error' AS OK
			,ERROR_NUMBER() AS ErrorNumber  
			,ERROR_SEVERITY() AS ErrorSeverity  
			,ERROR_STATE() AS ErrorState  
			,ERROR_PROCEDURE() AS ErrorProcedure  
			,ERROR_LINE() AS ErrorLine  
			,ERROR_MESSAGE() AS ErrorMessage;  
	END CATCH
	ELSE
	BEGIN
		SELECT 'Error' AS OK, 'La combianción Usr:' + cast(isnull(@idUsuario,'') as varchar(max))+ ' Unidad: '  + cast(isnull(@idUnidad,'') as varchar(max)) + ' no existe' AS ErrorMessage		
	END
  --select 'ok' as ok;
END

go

grant execute, view definition on Banorte.Elimina_Rel_Uni to DevOps
go

