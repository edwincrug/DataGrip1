-- =============================================
-- Description:	Actualiza datos de telemetria de unidad
-- [UPD_TELEMETRIA_SP]
-- =============================================
/****** Script for SelectTopNRows command from SSMS  ******/

CREATE PROCEDURE [dbo].[UPD_TELEMETRIA_SP]

AS
BEGIN

	CREATE TABLE #SOCKET(
		--DEVICES
		dev_id	INT,
		dev_uniqueid VARCHAR(128) collate modern_spanish_ci_as,		
		dev_lastupdate	DATETIME,
		--POSITION
		pos_mileage FLOAT,
		pos_latitud FLOAT,
		pos_longitud FLOAT,
		pos_fixtime DATETIME
	)

	CREATE TABLE #Kilometrajes (
		deviceID		VARCHAR(128) collate modern_spanish_ci_as,
		kilometraje		FLOAT,
		vin				VARCHAR(50),
		latitud			FLOAT,
		longitud		FLOAT,
		fecha			DATETIME
	)


	--INSERTAMOS EN POSICIONES DATOS DE SOCKET 1
	INSERT INTO #SOCKET
	SELECT
		dev.id
		,dev.uniqueid
		,dev.lastupdate
		,convert ( float, isnull(dbo.SEL_ATRIBUTO_FN(pos.attributes, 'totalDistance'), 0) ) / 1000 plataforma
		,pos.latitude
		,pos.longitude
		,pos.fixtime
	FROM [192.168.20.110].[Tracker].[dbo].[tc_devices] dev
		LEFT JOIN [192.168.20.110].[Tracker].[dbo].[tc_positions] pos ON dev.positionid = pos.id

	--INSERTAMOS EN POSICIONES DATOS DE SOCKET 2
	INSERT INTO #SOCKET
	SELECT
		dev.id
		,dev.uniqueid
		,dev.lastupdate
		,convert ( float, isnull(dbo.SEL_ATRIBUTO_FN(pos.attributes, 'totalDistance'), 0) ) / 1000
		,pos.latitude
		,pos.longitude
		,pos.fixtime
	FROM [192.168.20.110].[Tracker2].[dbo].[tc_devices] dev
		LEFT JOIN [192.168.20.110].[Tracker2].[dbo].[tc_positions] pos ON dev.positionid = pos.id


	INSERT INTO #Kilometrajes
	SELECT A.deviceID
		,A.pos_mileage
		,A.vin
		,A.pos_latitud
		,A.pos_longitud
		,A.pos_fixtime
	FROM (
		SELECT g.deviceID
			, s.pos_mileage
			, uni.vin
			, s.pos_latitud
			, s.pos_longitud
			, S.pos_fixtime
			, ROW_NUMBER() OVER(Partition by s.dev_uniqueid order by s.dev_lastupdate) as fila
		FROM #SOCKET s
			INNER JOIN [192.168.20.110].GPS.inventario.GPS g on g.deviceID = s.dev_uniqueid
			INNER JOIN [192.168.20.110].GPS.cxc.UnidadGPSSIM uni on uni.idGPS = g.idGPS
		WHERE s.pos_mileage > 0
			AND uni.fechaBaja IS NULL
	) A WHERE A.fila = 1


	--SELECT *
	UPDATE u SET
		gps = km.deviceID
		,Kilometraje_Actual = km.kilometraje
		,lat = km.latitud
		,long = km.longitud
		,fecha_loc = km.fecha
	FROM #Kilometrajes km
		INNER JOIN Unidades u WITH(NOLOCK) ON u.vin = km.vin

	--SELECT *, act.valor, CASE WHEN pc.valor = 'GPS' THEN convert(varchar(max), km.deviceID) WHEN pc.valor = 'Kilometraje actual' THEN convert(varchar(max), km.kilometraje) ELSE act.valor END
	UPDATE act SET
		valor = CASE WHEN pc.valor = 'GPS' THEN convert(varchar(max), km.deviceID) WHEN pc.valor = 'Kilometraje actual' THEN convert(varchar(max), km.kilometraje) ELSE act.valor END
	FROM #Kilometrajes km
		INNER JOIN Objeto.objeto.ObjetoPropiedadClase opc on opc.valor = km.vin
		INNER JOIN Objeto.objeto.PropiedadClase opcvin on opcvin.idPropiedadClase = opc.idPropiedadClase
		INNER JOIN Objeto.objeto.ObjetoPropiedadClase act on act.idObjeto = opc.idObjeto
		INNER JOIN Objeto.objeto.PropiedadClase pc on pc.idPropiedadClase = act.idPropiedadClase
	WHERE opc.activo = 1
		and opcvin.valor = 'VIN'


	drop table #SOCKET
	drop table #Kilometrajes
	
	
	/*
	UPDATE U	
	SET U.Kilometraje_Actual = ((select  convert(float, isnull([dbo].[SEL_ATRIBUTO_FN] (pos.attributes, 'totalDistance'), 0) ) / 1000)),--(CAST(ISNULL(TM.odometer,0) AS float))/1000.00,  
		U.lat = pos.latitude,
		U.long = pos.longitude,
		--U.temp = TM.coolantTemp,
		--U.voltaje = TM.batteryLevel,
		U.fecha_loc = pos.fixtime
		--select pos.*
	FROM Unidades U with(nolock)
		INNER JOIN [192.168.20.110].[GPS].[cxc].[UnidadGPSSIM] UNI with(nolock) ON UNI.VIN = U.VIN
		INNER JOIN   [192.168.20.110].[GPS].inventario.GPSSIM gpssim with(nolock) on uni.idGPSSIM = gpssim.idGPSSIM
		INNER JOIN   [192.168.20.110].[GPS].inventario.GPS gps with(nolock) on gps.idGPS = gpssim.idGPS
		left join   [192.168.20.110].Tracker.dbo.tc_devices dev with(nolock) on dev.uniqueid = gps.deviceid
		left join   [192.168.20.110].Tracker.dbo.tc_positions pos with(nolock) on pos.id = dev.positionid
	--OUTER  APPLY [GET_TELEMETRIABYID_FN](pos.deviceid) TM
	where uni.estatus = 1 
		and uni.fechaBaja is null
		and dev.positionid is not null
		and pos.id is not null
		--and U.idOperacion NOT IN( 108)--la actualización es incorrecta se debe descartar la operacion 108
		*/
END



go

