
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 08/06/2017
-- Description:	Store para la búsqueda del Número de Orden
-- [dbo].[INS_FACTURA_SP] 'http://189.204.141.193:5101/orden/166848/Factura/1/Factura_26-41084-10834-1.pdf',166848, 1 
-- ==========================================================================================
--select * from DocumentosOrdenes where idOrden=166848
CREATE PROCEDURE [dbo].[INS_FACTURA_SP]
	@ruta VARCHAR(MAX),
    @idOrden NUMERIC(20,0),
    @idCotizacion NUMERIC(20,0)
AS 
BEGIN 
	IF NOT EXISTS(SELECT 1 FROM DocumentosOrdenes WHERE idOrden=@idOrden AND idCotizacion=@idCotizacion AND idCatalogoDocumento=3)
		BEGIN
			INSERT INTO DocumentosOrdenes VALUES(@ruta,CURRENT_TIMESTAMP,@idOrden,3,@idCotizacion); 
		END
	ELSE
		BEGIN
			UPDATE DocumentosOrdenes
			SET rutaDocumento=@ruta,fechaDocumento=CURRENT_TIMESTAMP
			WHERE idOrden=@idOrden AND idCotizacion=@idCotizacion AND idCatalogoDocumento=3
		END
	--SELECT LastInsertId = @@IDENTITY;
	SELECT idDocumentosOrden as LastInsertId FROM DocumentosOrdenes WHERE idOrden=@idOrden AND idCotizacion=@idCotizacion AND idCatalogoDocumento=3	
	--SELECT @@IDENTITY LastInsertId;
	
END
go

