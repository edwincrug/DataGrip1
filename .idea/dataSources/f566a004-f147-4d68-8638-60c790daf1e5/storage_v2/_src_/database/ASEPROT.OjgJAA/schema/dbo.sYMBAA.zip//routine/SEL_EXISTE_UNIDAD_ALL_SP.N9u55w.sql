-- [dbo].[SEL_EXISTE_UNIDAD_ALL_SP] 676, 'FF0160(AGENCIA)', 1
CREATE PROCEDURE [dbo].[SEL_EXISTE_UNIDAD_ALL_SP]
	@idUsuario INT = 0,
	@economico nvarchar(max) = '',
	@tipo int = 1
AS
BEGIN

	DECLARE @idUnidad TABLE(idUnidad INT,economico VARCHAR(100), idOperacion INT, idContratoOperacion INT, nombreOperacion VARCHAR(500))
	DECLARE @idOperaciones TABLE (idOperacion	INT)

	INSERT INTO @idOperaciones
	SELECT CO.idOperacion FROM ContratoOperacionUsuario CU
	INNER JOIN ContratoOperacion CO ON CO.idContratoOperacion = CU.idContratoOperacion
	WHERE idUsuario = @idUsuario

	IF(@tipo = 2)
		BEGIN
			INSERT INTO @idUnidad
			SELECT 
				U.idUnidad
				,U.numeroEconomico
				,CO.idOperacion
				,CO.idContratoOperacion
				,pc.descripcion
			FROM [dbo].[Unidades] U
			INNER JOIN ContratoOperacion CO ON CO.idOperacion = U.idOperacion
			INNER JOIN partidas..contrato PC ON PC.idContrato = CO.idContrato
			WHERE vin = @economico
			AND CO.idOperacion in (SELECT idOperacion FROM @idOperaciones)
		END

    ELSE IF (@tipo = 3)
		BEGIN
			INSERT INTO @idUnidad
			SELECT 
				idUnidad
				,U.numeroEconomico
				,CO.idOperacion
				,CO.idContratoOperacion
				,pc.descripcion
			FROM [dbo].[Unidades] U
			INNER JOIN ContratoOperacion CO ON CO.idOperacion = U.idOperacion
			INNER JOIN partidas..contrato PC ON PC.idContrato = CO.idContrato
			WHERE placas = @economico
			AND CO.idOperacion in (SELECT idOperacion FROM @idOperaciones)

		END

	ELSE
		BEGIN

			INSERT INTO @idUnidad
			SELECT 
				idUnidad
				,@economico
				,CO.idOperacion
				,CO.idContratoOperacion
				,pc.descripcion
				FROM [dbo].[Unidades] U
				INNER JOIN ContratoOperacion CO ON CO.idOperacion = U.idOperacion
				INNER JOIN partidas..contrato PC ON PC.idContrato = CO.idContrato
				WHERE numeroEconomico = @economico
				AND CO.idOperacion in (SELECT idOperacion FROM @idOperaciones)
		END

	DECLARE @filtroZona INT = 1, 
			@tipoUsuario INT = 1, 
			@ageupador INT = 0;

	IF EXISTS(SELECT * FROM @idUnidad )
		BEGIN
			SELECT 
				@tipoUsuario = idCatalogoTipoUsuarios 
			FROM Usuarios WHERE idUsuario = @idUsuario

			IF EXISTS(SELECT 1 
						FROM [dbo].UsuarioAgrupador 
						where idUsuario = @idUsuario) 
						OR @tipoUsuario = 10
				BEGIN
					IF EXISTS( SELECT 1 FROM UnidadAgrupador UNI
								INNER JOIN UsuarioAgrupador US ON US.idAgrupador = UNI.idAgrupador
								WHERE US.idUsuario = @idUsuario  AND UNI.idUnidad IN (SELECT idUnidad FROM @idUnidad))
						BEGIN
							SELECT 
								1 AS respuesta
								,'Unidad encontrada con éxito' AS mensaje
								,U.* 
							FROM @idUnidad U
							INNER JOIN UnidadAgrupador UNI ON UNI.idUnidad = U.idUnidad
							INNER JOIN UsuarioAgrupador US ON US.idAgrupador = UNI.idAgrupador
							WHERE US.idUsuario = @idUsuario
						END
					ELSE
						BEGIN
							SELECT 2 AS respuesta, 
							'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico '  AS mensaje
							--, @economicoTemp as economico
						END
				END
			ELSE
				BEGIN
					IF (@tipoUsuario = 2)
						BEGIN
							SET @filtroZona = 0;
						END

					ELSE
						BEGIN
							SET @filtroZona = 1;
						END
					IF(@filtroZona = 1)
						BEGIN
							IF( @tipoUsuario = 4 )
								BEGIN
									IF EXISTS (SELECT 1
												FROM ASEPROT.dbo.ContratoOperacionUsuario cou   
												INNER JOIN ASEPROT.dbo.ContratoOperacionUsuarioProveedor cop ON cop.idContratoOperacionUsuario =  cou.idContratoOperacionUsuario  
												INNER JOIN ASEPROT.dbo.ContratoOperacion cpe ON cpe.idContratoOperacion = cou.idContratoOperacion
												WHERE cou.idUsuario = @idUsuario  
													AND cpe.idOperacion IN (SELECT	
																				idOperacion
																			FROM @idOperaciones)
												) 
										BEGIN
											SELECT 
												1 AS respuesta
												,'Unidad encontrada con éxito' AS mensaje
												,* 
											FROM @idUnidad U
										END
									ELSE
										BEGIN
											SELECT 
												2 AS respuesta , 
												'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico '  AS mensaje 
												--@economicoTemp as economico
										END
								END
							ELSE IF (@tipoUsuario = 9) 
								BEGIN -- Gerente de Zona
									IF EXISTS ( SELECT	1
													FROM [dbo].[Unidades] UNI
														INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
														INNER JOIN ASEPROT.dbo.ContratoOperacionUsuario cou on cou.idContratoOperacion = CO.idContratoOperacion
														INNER JOIN ASEPROT.dbo.[ContratoOperacionUsuarioGerente] cog  ON cog.idContratoOperacionUsuario = cou.idContratoOperacionUsuario
														INNER JOIN ASEPROT.[Gerente].[EstadoGerencia] esg ON esg.idGerencia = cog.idGerencias  
														INNER JOIN ASEPROT.[Gerente].[EstadoZona] ezo ON ezo.idEstado = esg.idEstado  
						  
													WHERE   
														esg.estatus=0 --activo  
														AND ezo.estatus=0 --activo  
														AND cou.idUsuario = @idUsuario 
														AND UNI.idUnidad IN (SELECT idUnidad FROM @idUnidad))

										BEGIN
											SELECT 
												1 AS respuesta
												,'Unidad encontrada con éxito' AS mensaje
												,U.*
											FROM @idUnidad U
												INNER JOIN [dbo].[Unidades] UNI ON UNI.idUnidad = U.idUnidad
												INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
												INNER JOIN ASEPROT.dbo.ContratoOperacionUsuario cou on cou.idContratoOperacion = CO.idContratoOperacion
												INNER JOIN ASEPROT.dbo.[ContratoOperacionUsuarioGerente] cog  ON cog.idContratoOperacionUsuario = cou.idContratoOperacionUsuario
												INNER JOIN ASEPROT.[Gerente].[EstadoGerencia] esg ON esg.idGerencia = cog.idGerencias  
												INNER JOIN ASEPROT.[Gerente].[EstadoZona] ezo ON ezo.idEstado = esg.idEstado  
											WHERE   
												esg.estatus=0 --activo  
												AND ezo.estatus=0 --activo  
												AND cou.idUsuario = @idUsuario 
										END

									ELSE
										BEGIN
											SELECT 
												2 AS respuesta , 
												'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico '  AS mensaje
												--, @economicoTemp as economico
										END
									
								END

							ELSE
								BEGIN
									IF EXISTS( SELECT	1
												FROM	[dbo].[Unidades] UNI
													INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
													INNER JOIN [dbo].[ContratoOperacionUsuario] COU ON COU.idContratoOperacion = CO.idContratoOperacion
													INNER JOIN [dbo].[ContratoOperacionUsuarioZona] COUZ ON COUZ.idContratoOperacionUsuario = COU.idContratoOperacionUsuario AND COUZ.idZona = UNI.idZona
												WHERE	UNI.idUnidad IN (SELECT idUnidad FROM @idUnidad )
												AND COU.idUsuario = @idUsuario 
											)
										
										BEGIN
											SELECT 
												1 AS respuesta
												,'Unidad encontrada con éxito' AS mensaje
												, U.*
											FROM @idUnidad U
											INNER JOIN [dbo].[Unidades] UNI ON UNI.idUnidad = U.idUnidad
											INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
											INNER JOIN [dbo].[ContratoOperacionUsuario] COU ON COU.idContratoOperacion = CO.idContratoOperacion
											INNER JOIN [dbo].[ContratoOperacionUsuarioZona] COUZ ON COUZ.idContratoOperacionUsuario = COU.idContratoOperacionUsuario AND COUZ.idZona = UNI.idZona
											WHERE COU.idUsuario = @idUsuario 
										END

									ELSE
										BEGIN
											SELECT 
												2 AS respuesta , 
												'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico '  AS mensaje 
												--@economicoTemp as economico
										END
								END
						END
					ELSE
						BEGIN
							IF EXISTS( SELECT	1 
										FROM	[dbo].[Unidades] UNI
											INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
											INNER JOIN [dbo].[ContratoOperacionUsuario] COU ON COU.idContratoOperacion = CO.idContratoOperacion
										WHERE	UNI.idUnidad IN (SELECT idUnidad FROM @idUnidad ) 
										AND COU.idUsuario = @idUsuario 
									)
								BEGIN
									SELECT 
										1 AS respuesta
										,'Unidad encontrada con éxito' AS mensaje
										,U.*
									FROM @idUnidad U
									INNER JOIN [dbo].[Unidades] UNI ON U.idUnidad = UNI.idUnidad
									INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
									INNER JOIN [dbo].[ContratoOperacionUsuario] COU ON COU.idContratoOperacion = CO.idContratoOperacion
									WHERE COU.idUsuario = @idUsuario 
								END

							ELSE
								BEGIN
									SELECT 
										2 AS respuesta 
										,'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico ' AS mensaje
										--, @economicoTemp as economico
								END
						END
				END
		END
	ELSE
		BEGIN
			SELECT 
				0 AS respuesta , 
				'No se encontró la unidad con el número económico ' + @economico AS mensaje
				, @economico as economico
		END
END

go

