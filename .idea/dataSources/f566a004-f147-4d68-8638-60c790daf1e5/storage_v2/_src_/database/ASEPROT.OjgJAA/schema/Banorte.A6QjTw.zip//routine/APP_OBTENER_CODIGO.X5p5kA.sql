/*
	Fecha			Autor			Descripción
	16-May-2018		Jose Armando	Se crea el SP para obtener codigo de promoción
	21-May-2018		José Etmanuel	Agrego bitácora
	22-May-2018		José Etmanuel	Cambio Token por IdUsuario
	28-May-2018		José Etmanuel	Regreso instrucciónes de promoción
	01-Jun-2018		José Etmanuel	Regreso la imagen para enviarla por mail
	06-Jun-2018		José Etmanuel	Orden y valido que no se pida una promoción ya pedia
	26-Jul-2018		José Etmanuel	Agrego lógica para que el código no se repita
*/


CREATE PROCEDURE [Banorte].[APP_OBTENER_CODIGO]
	@idPoliza VARCHAR(MAX),
	@idUnidad VARCHAR(MAX),
	@idPromocion VARCHAR(MAX),
	@idUsuario VARCHAR(MAX)
AS   
BEGIN

	IF EXISTS (SELECT * FROM [dbo].[PromocionesCodigos] where [IdPoliza] = @idPoliza and [IdPromocion] = @idPromocion) 
	BEGIN
		SELECT [Codigo] AS CodigoProm
			,(SELECT correoElectronico from Usuarios where idUsuario = @idUsuario) as email 
			,p.[instrucciones]
			,c.[Descripcion]
			,[urlImagen]
			,CASE WHEN Aplicadas > p.MaximoUso THEN 0
            ELSE (isnull(p.MaximoUso,0) - isnull(Aplicadas,0)) END AS Sobran
			--,(isnull(p.MaximoUso,0) - isnull(Aplicadas,0)) as Sobran
			FROM [dbo].[PromocionesCodigos] as r
			inner join [Banorte].[Promociones] as p on p.id = r.[IdPromocion]
			inner join [Banorte].[CatalogoTipoPromocion] as c on p.idTipoPromocion = c.id
			where [IdPoliza] = @idPoliza and [IdPromocion] = @idPromocion
	END
	ELSE
	BEGIN
		DECLARE @Random int = ROUND(((999999 - 100000 -1) * RAND() + 100000), 0);

		-- Evito que el códogo se repita
		WHILE EXISTS(SELECT [Codigo] FROM [dbo].[PromocionesCodigos] WHERE [Codigo] = @Random)
		BEGIN
			SET @Random = ROUND(((999999 - 100000 -1) * RAND() + 100000), 0);
		END
		
		INSERT INTO [dbo].[PromocionesCodigos]
			Values(@Random,@idPoliza,@idPromocion,@idUnidad,'NA',@idUsuario,getdate(),(Select MaximoUso from Promociones where id = @idPromocion),0)

		Select 
			@Random AS CodigoProm
			,(SELECT correoElectronico from Usuarios where idUsuario = @idUsuario) as email 
			,p.[instrucciones]
			,c.[Descripcion]
			,[urlImagen]
			,p.MaximoUso as Sobran
		from [Banorte].[Promociones] as p
		inner join [Banorte].[CatalogoTipoPromocion] as c on p.idTipoPromocion = c.id
		where p.id = @idPromocion
	END

	select @idPoliza idpol,
	@idUnidad iduni,
	@idPromocion idprom,
	@idUsuario idusr
END
go

grant execute, view definition on Banorte.APP_OBTENER_CODIGO to DevOps
go

