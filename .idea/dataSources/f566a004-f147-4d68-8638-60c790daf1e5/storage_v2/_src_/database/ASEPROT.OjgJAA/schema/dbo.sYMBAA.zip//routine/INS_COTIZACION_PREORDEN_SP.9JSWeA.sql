CREATE PROCEDURE [dbo].[INS_COTIZACION_PREORDEN_SP]
	@idCotizacion INT =0 ,
	@idUsuario INT = 0,
	@idTaller INT = 0,
	@idCotizacionesDetalle VARCHAR(MAX) = '',
	@idZona INT = 0,
	@idTipoCita INT = 0
AS
BEGIN
		
	SET NOCOUNT ON;
	BEGIN TRY
		BEGIN TRAN TrnInsPreOrden
		
		
		declare @nombreUsuario nvarchar(50)
		set @nombreUsuario  = (select nombreUsuario FROM ASEPROT.DBO.Usuarios	where idUsuario = @idUsuario)
		declare @idOrden int = (select [idOrden] from [dbo].[Cotizaciones] with(nolock) where [idCotizacion] = @idCotizacion)
		IF (@idTipoCita != 0)
		BEGIN
			Update Ordenes set idCatalogoTipoOrdenServicio = @idTipoCita where idOrden = @idOrden
			Update Cotizaciones set idCatalogoTipoOrdenServicio = @idTipoCita where idCotizacion = @idCotizacion
		END
		DECLARE @consecutive varchar(max) = convert(varchar(max),
		(SELECT  MAX([consecutivoCotizacion])+1
		FROM    Cotizaciones with(nolock)
		WHERE   idOrden = @idOrden))
		
		DECLARE @numeroOrden NVARCHAR(MAX) , @idContratoOperacion int , @idTipoOrdenServicio int
		SELECT @numeroOrden = numeroOrden, @idContratoOperacion = idContratoOperacion , @idTipoOrdenServicio =idCatalogoTipoOrdenServicio
		FROM  Ordenes with(nolock) WHERE   idOrden = @idOrden
		
		--declare  @numeroOrden varchar(max) = (SELECT  numeroOrden
		--										FROM    Ordenes
		--										WHERE   idOrden = @idOrden)
		----REXE
		--declare  @idContratoOperacion int = (SELECT  idContratoOperacion
		--										FROM    Ordenes
		--										WHERE   idOrden = @idOrden)
		--declare  @idTipoOrdenServicio int = (SELECT  idCatalogoTipoOrdenServicio
		--										FROM    Ordenes
		--										WHERE   idOrden = @idOrden)
		----REXE
		declare @numeroCotizacion VARCHAR(max) = @numeroOrden + '-' +@consecutive
		
		INSERT INTO  Cotizaciones
		SELECT
					GETDATE() fechaCotizacion,
					@idTaller idTaller,
					@idUsuario  idUsuario,
					1 idEstatusCotizacion,
					idOrden,
					@numeroCotizacion,
					@consecutive  consecutivoCotizacion,
					idCatalogoTipoOrdenServicio,
					@idCotizacion idPreorden,
					NULL, -- idProveedor
					NULL idTipoCotizacion
		FROM	Cotizaciones with(nolock)
		WHERE	idCotizacion = @idCotizacion
			
		DECLARE @newCotID int = @@IDENTITY
		DECLARE @updateDetalle VARCHAR(MAX) =
		' UPDATE CotizacionDetalle SET idCotizacion = '+ CONVERT(VARCHAR(10), @newCotID  ) +
		' WHERE idPartida IN ('+ @idCotizacionesDetalle +') AND idCotizacion = ' + CONVERT(VARCHAR(10),@idCotizacion)
		--print @updateDetalle
		EXEC (@updateDetalle)
	
		UPDATE aseprot.[dbo].[CotizacionDetalle]
		SET [costo] = isnull(PROVPART.costo, 0.00),[venta] =  isnull(CONTPART.venta, 0.00)
			FROM CotizacionDetalle CODE with(nolock)
			INNER JOIN Cotizaciones COTI ON COTI.idCotizacion = CODE.idCotizacion
			INNER JOIN Ordenes ORD ON ORD.idOrden = COTI.idOrden
			INNER JOIN ContratoOperacion CONTOPE ON CONTOPE.idContratoOperacion = ORD.idContratoOperacion
			INNER JOIN Unidades U ON U.idUnidad = ORD.idUnidad
			INNER JOIN Partidas..Contrato CONT ON CONT.idContrato = CONTOPE.idContrato
			INNER JOIN [Partidas].[dbo].[Partida] PART ON CODE.idPartida = PART.idPartida
			INNER JOIN [Partidas].dbo.ContratoUnidad CUNI ON CUNI.idContrato  =  CONT.idContrato and CUNI.idUnidad = U.idTipoUnidad
			LEFT JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON PART.idPartida = CONTPART.idPartida and CUNI.idContratoUnidad = CONTPART.idContratoUnidad
			LEFT JOIN [Partidas].[dbo].[ContratoProveedor] CONTPROV ON CONTPROV.idProveedor = COTI.idTaller and CONTPROV.idContrato = CONT.idContrato
			LEFT JOIN [Partidas].[dbo].[ProveedorCotizacion] PROVCOT ON  PROVCOT.idProveedor = CONTPROV.idProveedor and PROVCOT.idUnidad = CUNI.idUnidad
			LEFT JOIN [Partidas].[dbo].[ProveedorPartida] PROVPART ON PROVPART.idProveedorCotizacion = PROVCOT.idProveedorCotizacion and PROVPART.idPartida = PART.idPartida
			where COTI.idCotizacion = @newCotID and PART.estatus = 1 and PROVCOT.idCotizacionEstatus = 3 and PROVPART.idPartidaEstatus = 4
		--Se inserta en el historico del estatus de la cotizacion
		--select * from [dbo].[HistorialEstatusCotizacion]
		--select * from
		INSERT INTO [dbo].[HistorialEstatusCotizacion] ([fechaInicial],[fechaFinal],[idCotizacion],[idUsuario],[idEstatusCotizacion])
												VALUES (GETDATE(),null,@newCotID,@idUsuario,1)
		UPDATE [dbo].[Ordenes]
		SET [idTaller] = @idTaller
		WHERE idOrden = (select idOrden from Cotizaciones with(nolock) where idCotizacion = @idCotizacion)
		declare @estatusActualOrden int = (select idEstatusOrden from Ordenes with(nolock) where idOrden = @idOrden)
		if (@estatusActualOrden = 1)
		begin
			UPDATE [dbo].[HistorialEstatusOrden]
			SET		[fechaFinal] = GETDATE()
			WHERE idEstatusOrden = 1 and fechaFinal is null and idOrden = (select idOrden from Cotizaciones with(nolock) where idCotizacion = @idCotizacion)
			UPDATE [dbo].[Ordenes]
			SET idEstatusOrden =2 ---error ---2
			WHERE idOrden = (select idOrden from Cotizaciones with(nolock) where idCotizacion = @idCotizacion)
			INSERT INTO [dbo].[HistorialEstatusOrden] ([idOrden],[idEstatusOrden],[fechaInicial],[fechaFinal],[idUsuario])
				VALUES ( @idOrden,2,GETDATE(),null,@idUsuario)
			--REXE
			--IF (@idContratoOperacion = 3 AND @idTipoOrdenServicio = 1)
			IF @idTipoOrdenServicio = 1 OR @idContratoOperacion = 47
			BEGIN
				UPDATE [dbo].[Ordenes]
				SET idEstatusOrden = 3 ---error ---3
				WHERE idOrden = (select idOrden from Cotizaciones with(nolock) where idCotizacion = @idCotizacion)
				INSERT INTO [dbo].[HistorialEstatusOrden] ([idOrden],[idEstatusOrden],[fechaInicial],[fechaFinal],[idUsuario])
				VALUES ( @idOrden,3,GETDATE(),null,@idUsuario)
				UPDATE [dbo].[Ordenes]
				SET idEstatusOrden = 4
				WHERE idOrden = (select idOrden from Cotizaciones with(nolock) where idCotizacion = @idCotizacion)
				INSERT INTO [dbo].[HistorialEstatusOrden] ([idOrden],[idEstatusOrden],[fechaInicial],[fechaFinal],[idUsuario])
				VALUES ( @idOrden,4,GETDATE(),null,@idUsuario)
			END
			--REXE
			
		end
		select @newCotID idCotizacion, @idOrden idOrden,1 estatus
	COMMIT TRAN TrnInsPreOrden
	END TRY
	BEGIN CATCH
		ROLLBACK TRAN TrnInsPreOrden
		--SELECT ERROR_NUMBER() AS Number,
		--	ERROR_SEVERITY() AS Severity,
		--	ERROR_STATE() AS [State],
		--	ERROR_PROCEDURE() AS [Procedure],
		--	ERROR_LINE() AS Line,
		--	ERROR_MESSAGE() AS [Message],
		--	0 estatus
		declare @err nvarchar(max)
		set  @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE() + ': ' + ERROR_PROCEDURE()
			 INSERT INTO ASEPROT.[dbo].[SaveError]
			 VALUES(ERROR_LINE(),ERROR_MESSAGE(),@idUsuario,@idCotizacion,1,@idOrden,@estatusActualOrden,ERROR_PROCEDURE(),@err,'',GETDATE())
			 SELECT TOP 1
			 idError AS idError,
			 error as [Message],
			 stored as [Procedure],
			 stackTrace,
			 @nombreUsuario AS nombreUsuario,
			 0 as estatus
			 FROM ASEPROT.[dbo].[SaveError] with(nolock)
			 WHERE cotizacion = @idCotizacion
			 ORDER BY idError desc
		
			
	END CATCH
	SET NOCOUNT OFF;
END
go

grant execute, view definition on INS_COTIZACION_PREORDEN_SP to DevOps
go

