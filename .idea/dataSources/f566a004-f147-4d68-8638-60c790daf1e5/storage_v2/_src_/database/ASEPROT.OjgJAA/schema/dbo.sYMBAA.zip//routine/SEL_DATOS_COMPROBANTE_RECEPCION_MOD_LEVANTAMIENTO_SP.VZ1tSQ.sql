-- =============================================
-- Create date: 28/05/2017
-- Description:	Obtiene el catalogo de modulos operativos
-- [SEL_DATOS_COMPROBANTE_RECEPCION_MOD_LEVANTAMIENTO_SP] @idOrden=38234
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATOS_COMPROBANTE_RECEPCION_MOD_LEVANTAMIENTO_SP]
	@idOrden INT
AS
BEGIN
DECLARE @idUnidad INT
DECLARE @idContratooperacion INT
DECLARE @idTipoUnidad INT
DECLARE @rutaImagen NVARCHAR(100) = 'http://189.204.141.193:5101'
DECLARE @TipoUnidad NVARCHAR(100)
DECLARE @numeroOrden NVARCHAR(100)
DECLARE @JSON VARCHAR(max) = '',
		@JSON2 VARCHAR(max) = '',
		@JSON3 VARCHAR(max) = '',
		@folio NVARCHAR(100),
		@numeroEconomico NVARCHAR(100),
		@fecha DATETIME,
		@ParteIzquierda NVARCHAR(1000),
		@ParteDerecha NVARCHAR(100),
		@ParteDelantera NVARCHAR(100),
		@ParteTrasera NVARCHAR(100),
		@ParteArriba NVARCHAR(100),
		@logo NVARCHAR(100),
		@TtipoUnidad NVARCHAR(100),
		@unidad NVARCHAR(100),
		@zona NVARCHAR(100),
		@userName NVARCHAR(500),
		@tecnico NVARCHAR(500),
		@responsable NVARCHAR(500),
		@nombre NVARCHAR(500)
	CREATE TABLE #TablaLevantamientoInicial (
				idOrdenModuloLevantamiento INT,
				idCatalogoModuloLevantamiento INT,
				NombreModuloLevantamiento NVARCHAR(100),
				idOrden int,
				idOrdenModuloLevantamientoDetalle INT,
				idCatalogoModuloLevantamientoDetalle INT, 
				nombreModuloLevantamientoDetalle NVARCHAR(100),
				idOrdenModuloLevantamientoCaracteristica INT,
				idCatalogoModuloLevantamientoCaracteristica INT,
				alias NVARCHAR(100),
				NombreControl NVARCHAR(1000),
				dato NVARCHAR(200),
				detalle INT,
				dano INT,
				observacion INT,
				descripcion NVARCHAR(200))
	CREATE TABLE #TablaVerificadoraRegistro (
        idCatalogoModuloLevantamiento INT,
        idOrdenModuloLevantamientoDetalle INT)
/**************************************************************************************************************************************************************/
	INSERT INTO #TablaLevantamientoInicial
	SELECT	OML.idOrdenModuloLevantamiento, 
			OML.idCatalogoModuloLevantamiento, CML.NombreModuloLevantamiento, 
			idOrden,
			OMLD.idOrdenModuloLevantamientoDetalle,
			OMLD.idCatalogoModuloLevantamientoDetalle, CMLD.nombreModuloLevantamientoDetalle,
			OMLC.idOrdenModuloLevantamientoCaracteristica,
			OMLC.idCatalogoModuloLevantamientoCaracteristica, CMLC.alias,
			CTC.NombreControl,
			OMLC.dato,
			CMLC.detalle,
			CMLC.dano,
			CMLC.observacion,
			CMLC.descripcion
	FROM OrdenModuloLevantamiento OML
	JOIN CatalogoModuloLevantamiento CML ON CML.idCatalogoModuloLevantamiento = OML.idCatalogoModuloLevantamiento
	JOIN OrdenModuloLevantamientoDetalle OMLD ON OMLD.idOrdenModuloLevantamiento = OML.idOrdenModuloLevantamiento
	JOIN CatalogoModuloLevantamientoDetalle CMLD ON CMLD.idCatalogoModuloLevantamientoDetalle = OMLD.idCatalogoModuloLevantamientoDetalle
	JOIN OrdenModuloLevantamientoCaracteristica OMLC ON OMLC.idOrdenModuloLevantamientoDetalle = OMLD.idOrdenModuloLevantamientoDetalle
	JOIN CatalogoModuloLevantamientoCaracteristica CMLC ON CMLC.idCatalogoModuloLevantamientoCaracteristica = OMLC.idCatalogoModuloLevantamientoCaracteristica
	JOIN CatalogoTipoControl CTC on CTC.idCatalogoTipoControl = CMLC.idCatalogoTipoControl
	WHERE idOrden = @idOrden

/****************************************************************************************************************************************************************/
		SELECT @idUnidad=idUnidad, @idContratooperacion=idContratooperacion, @numeroOrden= numeroOrden
		FROM Ordenes WHERE idOrden=@idOrden
		
		SELECT @nombre=U.nombreCompleto 
		FROM HistorialEstatusOrden HO 
		JOIN Usuarios U ON U.idUsuario = HO.idUsuario 
		WHERE HO.idEstatusOrden=2 AND HO.idOrden=@idOrden

		SELECT @idTipoUnidad=UP.idTipoUnidad
		FROM Unidades U
		JOIN Partidas..Unidad UP ON UP.idUnidad = U.idTipoUnidad
		WHERE U.idUnidad=@idUnidad
		IF NOT EXISTS(SELECT * FROM TipoUnidadRecepcion WHERE idTipounidad = @idTipoUnidad) SET @idTipoUnidad = 999

		SELECT	@folio = @numeroOrden,
				@numeroEconomico = numeroEconomico,
				@fecha = GETDATE(),
				@ParteIzquierda = (SELECT  @rutaImagen +  izquierda FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad),
				@ParteDerecha = (SELECT  @rutaImagen +  derecha FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad),
				@ParteDelantera = (SELECT  @rutaImagen +  frente FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad),
				@ParteTrasera = (SELECT  @rutaImagen +  atras FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad),
				@ParteArriba = (SELECT  @rutaImagen +  arriba FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad),
				@logo = (SELECT @rutaImagen + logo FROM ContratoOperacionFacturacion WHERE idContratoOperacion=@idContratooperacion),
				@TtipoUnidad = TU.tipo,
				@unidad = M.nombre + ' ' + SM.nombre + ' ' + US.modelo,
				@zona = (SELECT dbo.[SEL_ZONAS_NAME_FN]((SELECT idZona FROM Ordenes WHERE idOrden =@idOrden))),
				@userName = @nombre,
				@tecnico = @nombre,
				@responsable = @nombre
		FROM Unidades US
			JOIN Partidas..Unidad U ON U.idUnidad = US.idTipoUnidad
			JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = U.idTipoUnidad
		    JOIN Partidas..SubMarca SM ON SM.idSubMarca = U.idSubMarca
		    JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
		WHERE US.idUnidad=@idUnidad
/****************************************************************************************************************************************************************/
	SET @JSON = '{"InfoGeneral":{' +
		'"numeroEconomico":"' + @numeroEconomico + '",' +
		'"unidad":"' + @unidad + '",' +
		'"tipoUnidad":"' + @TtipoUnidad + '",' +
		'"zona":"' + @zona + '",' +
		'"folio":"' + @folio + '",' +
		'"fecha":"' + LEFT(CONVERT(VARCHAR, @fecha, 120), 10) + '",' +
		'"logo":"' + @logo + '",' +
		'"ParteDerecha":"' + @ParteDerecha + '",' +
		'"ParteDelantera":"' + @ParteDelantera + '",' +
		'"ParteArriba":"' + @ParteArriba + '",' +
		'"ParteTrasera":"' + @ParteTrasera + '",' +
		'"ParteIzquierda":"' + @ParteIzquierda + '",' +
		'"userName":"' + @userName + '",' +
		'"tecnico":"' + @tecnico + '",' +
		'"responsable":"' + @responsable + '"' +
		'},"LevantamientoInicial":[' ;
	--SELECT * FROM #TablaLevantamientoInicial 
/****************************************************************************************************************************************************************/
	DECLARE @idOrdenModuloLevantamiento INT
    DECLARE @idOrdenModuloLevantamientoDetalle INT
    DECLARE @idOrdenModuloLevantamientoCaracteristica INT
	DECLARE @idCatalogoModuloLevantamiento INT
	DECLARE @NombreModuloLevantamiento NVARCHAR(100),
			@bDetalle INT,
			@bDano INT,
			@bObservacion INT,
			@detalle NVARCHAR(200),
			@dano NVARCHAR(200),
			@observacion NVARCHAR(200),
			@dato NVARCHAR(200)
	DECLARE contact_cursor CURSOR FOR
	SELECT idCatalogoModuloLevantamiento, NombreModuloLevantamiento FROM CatalogoModuloLevantamiento --WHERE idCatalogoModuloLevantamiento IN(1,2,3,4,5,6,7,8,9,10,11,12)
		OPEN contact_cursor  
			FETCH NEXT FROM contact_cursor INTO @idCatalogoModuloLevantamiento,@NombreModuloLevantamiento
				WHILE @@FETCH_STATUS = 0  
					BEGIN 
					IF (@idCatalogoModuloLevantamiento NOT IN(8,9,10,11,12))
						BEGIN
							SET @JSON2 += '{"data":{' +
									'"titleCpto":"'+@NombreModuloLevantamiento+'",'+
									'"titleDet":"DETALLE",'+
									'"titleDano":"",'+
									'"titleObs":"",'+
									'"definicion":[';
						END
					ELSE
						BEGIN						
							SET @JSON3 += '{"data":{' +
									'"titleCpto":"'+@NombreModuloLevantamiento+'",'+
									'"titleDet":"DETALLE",'+
									'"titleDano":"PIEZA DAÑADA",'+
									'"titleObs":"OBSERVACIONES",'+
									'"definicion":[';
						END
									DECLARE @cont int = 0
									DECLARE @limit int = 0
									DECLARE @limit2 int = 0
									DECLARE @nombreModuloLevantamientoDetalle NVARCHAR(100)
									SELECT @limit = count(idCatalogoModuloLevantamiento) FROM #TablaLevantamientoInicial WHERE idCatalogoModuloLevantamiento = @idCatalogoModuloLevantamiento
								    SELECT @limit2 = count(idCatalogoModuloLevantamiento)/3 FROM #TablaLevantamientoInicial WHERE idCatalogoModuloLevantamiento = @idCatalogoModuloLevantamiento
									DECLARE contact_cursor2 CURSOR FOR
									SELECT nombreModuloLevantamientoDetalle, dato, idOrdenModuloLevantamientoDetalle FROM #TablaLevantamientoInicial WHERE idCatalogoModuloLevantamiento = @idCatalogoModuloLevantamiento
									OPEN contact_cursor2  
									FETCH NEXT FROM contact_cursor2 INTO @nombreModuloLevantamientoDetalle, @dato, @idOrdenModuloLevantamientoDetalle
									WHILE @@FETCH_STATUS = 0  
										BEGIN 
										  IF (@idCatalogoModuloLevantamiento IN(1,2,3,4,5))
											BEGIN
												IF((@cont + 1) < @limit)
													BEGIN
														SET @JSON2 += '{' +
															'"concepto":"'+ @nombreModuloLevantamientoDetalle+'",' +
															'"detalle":'+CASE @dato WHEN 1 THEN 'true' ELSE 'false' END+','+
															'"dano":"",'+
															'"observacion":""},';
														SET @cont += 1;
													END
												ELSE IF((@cont + 1) = @limit)
													BEGIN
														SET @JSON2 += '{' +
															'"concepto":"'+@nombreModuloLevantamientoDetalle+'",' +
															'"detalle":'+CASE @dato WHEN 1 THEN 'true' ELSE 'false' END+','+
															'"dano":"",'+
															'"observacion":""}]}},';
													END
												END
											ELSE IF(@idCatalogoModuloLevantamiento IN(6,7))
												BEGIN
													IF((@cont + 1) < @limit)
														BEGIN
															SET @JSON2 += '{' +
																'"concepto":"'+ @nombreModuloLevantamientoDetalle+'",' +
																'"detalleText":"'+ @dato +'",' +
																'"dano":"",'+
																'"observacion":""},';
															SET @cont += 1;
														END
													ELSE IF((@cont + 1) = @limit)
														BEGIN
															SET @JSON2 += '{' +
																'"concepto":"'+ @nombreModuloLevantamientoDetalle+'",' +
																'"detalleText":"'+ @dato +'",' +
																'"dano":"",'+
																'"observacion":""}]}},';
														END
												END
											ELSE IF(@idCatalogoModuloLevantamiento IN(8,9,10,11,12))
												BEGIN
													IF NOT EXISTS(SELECT 1 FROM #TablaVerificadoraRegistro 
														WHERE idCatalogoModuloLevantamiento = @idCatalogoModuloLevantamiento
														AND idOrdenModuloLevantamientoDetalle = @idOrdenModuloLevantamientoDetalle)
															BEGIN
																DECLARE DetallesModulo CURSOR FOR
																SELECT idOrdenModuloLevantamientoCaracteristica FROM #TablaLevantamientoInicial WHERE idOrdenModuloLevantamientoDetalle=@idOrdenModuloLevantamientoDetalle
																OPEN DetallesModulo
																FETCH NEXT FROM DetallesModulo INTO @idOrdenModuloLevantamientoCaracteristica
																WHILE @@FETCH_STATUS = 0
																BEGIN
																	SELECT 
																	@dato = dato,
																	@bDetalle = detalle,
																	@bDano = dano,
																	@bObservacion = observacion
																	FROM #TablaLevantamientoInicial 
																	WHERE idOrdenModuloLevantamientoCaracteristica = @idOrdenModuloLevantamientoCaracteristica 
																
																	IF(@bDetalle = 1)
																	BEGIN 
																		SET @detalle = @dato
																	END
																	ELSE IF(@bDano = 1)
																	BEGIN 
																		SET @dano = @dato
																	END
																	ELSE IF(@bObservacion = 1)
																	BEGIN 
																		SET @observacion = @dato
																	END
																	INSERT INTO #TablaVerificadoraRegistro (idCatalogoModuloLevantamiento, idOrdenModuloLevantamientoDetalle)
																	VALUES (@idCatalogoModuloLevantamiento, @idOrdenModuloLevantamientoDetalle)
																	FETCH NEXT FROM DetallesModulo INTO @idOrdenModuloLevantamientoCaracteristica
																END
																CLOSE DetallesModulo
																DEALLOCATE DetallesModulo	

																IF((@cont + 1) < @limit2)
																	BEGIN
																		SET @JSON3 += '{' +
																			'"concepto":"'+ @nombreModuloLevantamientoDetalle+'",' +
																			'"detalle":"'+ @detalle +'",' +
																			'"dano":"'+ @dano +'",'+
																			'"observacion":"'+ @observacion +'"},';
																		SET @cont += 1;
																	END
																ELSE IF((@cont + 1) = @limit2)
																	BEGIN
																		SET @JSON3 += '{' +
																			'"concepto":"'+ @nombreModuloLevantamientoDetalle+'",' +
																			'"detalle":"'+ @detalle +'",' +
																			'"dano":"'+ @dano +'",'+
																			'"observacion":"'+ @observacion +'"}]}},';
																	END
																SET @detalle = ''
																SET @dano = ''
																SET @observacion = ''
													 END
												END
										FETCH NEXT FROM contact_cursor2 INTO @nombreModuloLevantamientoDetalle, @dato, @idOrdenModuloLevantamientoDetalle
										END  
									CLOSE contact_cursor2
									DEALLOCATE contact_cursor2
						FETCH NEXT FROM contact_cursor INTO @idCatalogoModuloLevantamiento, @NombreModuloLevantamiento
					END  
		CLOSE contact_cursor  
	DEALLOCATE contact_cursor 
/****************************************************************************************************************************************************************/
SET @JSON3 = (SELECT SUBSTRING (@JSON3, 1, Len(@JSON3)-1))
PRINT @JSON3
select (@JSON + @JSON2 + @JSON3 + ']}') as Json
--SELECT LEN(@JSON2);
END
go

