


CREATE VIEW [dbo].[vwCorreosFARMACOS]
AS

/*PRODUCCION*/
SELECT 'Braulio Solano'  AS Nombre,'ejecutivodecuenta2@centraldeoperaciones.com' AS Email
UNION
SELECT 'Fármacos'  AS Nombre,'farmacos@centraldeoperaciones.com' AS Email

go

