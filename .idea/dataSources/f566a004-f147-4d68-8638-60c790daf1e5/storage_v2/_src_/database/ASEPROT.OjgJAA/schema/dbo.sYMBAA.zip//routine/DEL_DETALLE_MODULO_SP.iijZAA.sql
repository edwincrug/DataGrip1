-- =============================================
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- [INS_DETALLE_APROBACION_MONTO_SP]
-- =============================================
 CREATE PROCEDURE [dbo].[DEL_DETALLE_MODULO_SP]
	@idDetalleModulo NUMERIC(18, 0)
AS
BEGIN

	DELETE FROM DetalleModulo
	WHERE idDetalleModulo=@idDetalleModulo

	SELECT 1
			
END


go

