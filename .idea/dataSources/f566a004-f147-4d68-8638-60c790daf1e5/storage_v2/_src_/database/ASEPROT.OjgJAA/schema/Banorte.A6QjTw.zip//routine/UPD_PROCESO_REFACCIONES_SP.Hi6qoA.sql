
-- =============================================
-- Author:		<YJH>
-- Create date: <22/05/2018>
-- Description:	<Inserta registros en la tabla >
-- =============================================
CREATE PROCEDURE [Banorte].[UPD_PROCESO_REFACCIONES_SP] --39287, '18-5456-834', 74, 0, 18, 'wer4', '8239493|'
	@idOrden int,
	@numOrden varchar(max),
	@idEncabezado int, 
	@isProduction int, 
	@idContratoOperacion int, 
	@idPoliza varchar(max),
	@idSiniestro varchar(max)
AS
BEGIN
	DECLARE @Base NVARCHAR(MAX) = '',	
			@adenda NVARCHAR(MAX) = ''
	
	
IF(@isProduction = 1)
    BEGIN
        SELECT                 
               @Base= SERVER+'.'+DBProduccion                
        FROM ASEPROT.dbo.ContratoOperacionFacturacion 
        WHERE idContratoOperacion =  @idContratoOperacion
    END
ELSE
    BEGIN
        SELECT 
			@Base= SERVER+'.'+DB
        FROM ASEPROT.dbo.ContratoOperacionFacturacion
		WHERE idContratoOperacion = @idContratoOperacion
	END

	DECLARE @proveedor INT = (select idSucursal from  RefaccionMultimarca.operacion.cotizacion C 
	INNER JOIN RefaccionMultimarca.relacion.siniestroordencotizacion RS ON RS.idCotizacion = C.idCotizacion
	where RS.idOrden = @idOrden)

	--SELECT @PROVEEDOR

	update ASEPROT.[dbo].[AprobacionProvision] set estatus = 1  where idOrden = @idOrden

	declare @estatus int =2
	/*
	IF @proveedor = 14
		BEGIN
			select @estatus = 2
		END

	ELSE
		BEGIN
			select @estatus = 1
		END*/
	DECLARE @queryUpd NVARCHAR(MAX) = ''
	
	SET @queryUpd = 'update '+@Base+'.dbo.ADE_ORDSERENC set OTE_STATUS= '+CONVERT(varchar(10), @estatus)+' where OTE_ORDENGLOBAL like '''+convert(nvarchar(max),@numOrden) + '%'''

	EXECUTE (@queryUpd)	
	/*set @adenda=''--'<cfdi:Addenda xmlns:cfdi="http://www.sat.gob.mx/cfd/3">
				--<POLIZA>'+@idPoliza+'</POLIZA>
				--<SINIESTRO>'+@idSiniestro+'</SINIESTRO>
			 --</cfdi:Addenda>'

	DECLARE @queryIns NVARCHAR(MAX) = ''
			set @queryIns = '
	INSERT INTO '+@Base+'.[dbo].[ADE_COPADE](COP_ORDENGLOBAL,COP_COPADE,COP_CVEUSU,COP_FECHOPE,COP_HORAOPE,COP_IDDOCTO,COP_STATUS)
	VALUES ('''+@numOrden+''','''+@adenda+''',''GMI'', CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(VARCHAR(8),GETDATE(),108),NULL,''1'')
	'
	EXECUTE SP_EXECUTESQL @queryIns	*/

	select 1 as proceso

END
go

grant execute, view definition on Banorte.UPD_PROCESO_REFACCIONES_SP to DevOps
go

