




CREATE VIEW [report].[VwReporteGeneralCopadeExpressDef]
AS

   		SELECT  
		        [Cliente]
			   ,VRA.[idOrden]
               ,[consecutivoOrden]
               ,[numeroOrden]
               ,[numeroEconomico]
               ,[idZona]
               ,[talleres]
               ,[costo]
               ,[venta]
               ,[descripcion]
               ,[estatus]
               ,[idEstatus]
               ,[fechaCreacionOrden]
               ,[fechaAprobacion]
               ,[fechaProceso]
               ,[fechaTerminoTrabajo]
               ,[fechaSalidaV]
               ,[fechadeFinalizacionV]
               ,[dias_0_30]
               ,[dias_31_45]
               ,[dias_46_60]
               ,[dias_mas_60]
               ,[dias]
               ,[diasD]
               ,[zonasConcatenadas]
               ,[nombrePadre]
               ,[nombreZona]
               ,[tipoUnidad]
               ,[tipoCombustible]
               ,[marca]
               ,[subMarca]
               ,[modelo]
               ,[folio]
               ,[folioPresupuesto]
               ,[idOperacion]
               ,[idEstatusOrden] 
		--	   ,VRC.[COP_IDDOCTO] as numCop
		FROM 	[report].[VwReporteAntiguedadSaldos] VRA
		where [idOperacion]=3	
  --LEFT JOIN    [report].[VwReporteGeneralCopadeUnique] VRC
    --      ON    VRA.idOrden = VRC.idOrden


go

