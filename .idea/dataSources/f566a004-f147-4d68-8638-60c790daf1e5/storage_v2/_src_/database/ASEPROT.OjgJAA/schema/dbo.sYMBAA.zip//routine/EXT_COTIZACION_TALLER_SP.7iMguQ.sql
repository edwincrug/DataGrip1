
CREATE PROCEDURE [dbo].[EXT_COTIZACION_TALLER_SP]
	@idCotizacion INT, 
	@idTaller INT = 0, 
	@idUsuario INT,
	@idContratoOperacion INT
AS
BEGIN
	
DECLARE @idUsuarioOperacion INT
DECLARE @idOrden INT
DECLARE @descripcion NVARCHAR(100)
DECLARE @idSoporte NUMERIC(18,0) = 7

	SELECT @idOrden = idOrden FROM Cotizaciones WHERE idCotizacion = @idCotizacion

	SET @idUsuarioOperacion = (SELECT TOP 1 CO.idUsuario FROM Ordenes O
		JOIN ContratoOperacionUsuario CO ON CO.idContratoOperacion = O.idContratoOperacion
		JOIN ContratoOperacionUsuarioZona COZ ON COZ.idContratoOperacionUsuario = CO.idContratoOperacionUsuario
		JOIN Partidas..Zona Z ON Z.idZona = COZ.idZona AND Z.idZona = O.idZona
	WHERE CO.idUsuario IN(119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150) AND
	O.idOrden = @idOrden AND CO.idContratoOperacion= @idContratoOperacion)
	
	UPDATE Cotizaciones
	SET idTaller=@idTaller
	WHERE idCotizacion=@idCotizacion

	--Aqui se manda a llamar el sp para que elimine las relaciones de la partida antes de actualizar las demas
	--exec INS_PARTIDA_NISSAN @idOrden,@idUsuario

	DECLARE @out int

	--EXEC UPD_PARTIDA_NISSAN_PORCENTAJE @idOrden,@idUsuario,@idCotizacion,@out output

	DECLARE @catalogoTemp table (idCotizacionDetalle numeric(18,0), costo decimal(18,6), venta decimal(18,6))

	INSERT INTO @catalogoTemp 
	SELECT CODE.idCotizacionDetalle, isnull(PROVPART.costo, 0.00), isnull(CONTPART.venta, 0.00)
		FROM CotizacionDetalle CODE		
		INNER JOIN Cotizaciones COTI ON COTI.idCotizacion = CODE.idCotizacion
		INNER JOIN Ordenes ORD ON ORD.idOrden = COTI.idOrden 
		INNER JOIN ContratoOperacion CONTOPE ON CONTOPE.idContratoOperacion = ORD.idContratoOperacion
		INNER JOIN Unidades U ON U.idUnidad = ORD.idUnidad
		INNER JOIN Partidas..Contrato CONT ON CONT.idContrato = CONTOPE.idContrato
		INNER JOIN [Partidas].[dbo].[Partida] PART ON CODE.idPartida = PART.idPartida 
		INNER JOIN [Partidas].dbo.ContratoUnidad CUNI ON CUNI.idContrato  =  CONT.idContrato and CUNI.idUnidad = U.idTipoUnidad
		LEFT JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON PART.idPartida = CONTPART.idPartida and CUNI.idContratoUnidad = CONTPART.idContratoUnidad
		LEFT JOIN [Partidas].[dbo].[ContratoProveedor] CONTPROV ON CONTPROV.idProveedor = COTI.idTaller and CONTPROV.idContrato = CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[ProveedorCotizacion] PROVCOT ON  PROVCOT.idProveedor = CONTPROV.idProveedor and PROVCOT.idUnidad = CUNI.idUnidad 
		LEFT JOIN [Partidas].[dbo].[ProveedorPartida] PROVPART ON PROVPART.idProveedorCotizacion = PROVCOT.idProveedorCotizacion and PROVPART.idPartida = PART.idPartida 
		where COTI.idCotizacion = @idCotizacion and PART.estatus = 1 and PROVCOT.idCotizacionEstatus = 3 and PROVPART.idPartidaEstatus = 4


	DECLARE @idPart int = 0 , @costo decimal(18,6) = 0, @venta decimal(18,6) = 0;  

		DECLARE detalle_cursor CURSOR FOR  
		select idCotizacionDetalle, costo, venta from @catalogoTemp

		OPEN detalle_cursor;  

		FETCH NEXT FROM detalle_cursor INTO @idPart, @costo, @venta;  

		WHILE @@FETCH_STATUS = 0  
		BEGIN  
			IF ISNULL(@out,0) = 0
			BEGIN
			UPDATE [dbo].[CotizacionDetalle]
			   SET [costo] = @costo, [venta] = @venta
			 WHERE idCotizacionDetalle = @idPart
			 END
		   FETCH NEXT FROM detalle_cursor INTO @idPart, @costo, @venta;  
		END  

		CLOSE detalle_cursor; 
		DEALLOCATE detalle_cursor;  

	SET @descripcion='Actualizar taller y costos'

	INSERT INTO LogSoporte VALUES(@idOrden, @idUsuario, @idContratoOperacion, GETDATE(), @idSoporte, @descripcion,@idCotizacion)

	SELECT Success = 1, Msg = 'La cotizacion fue cambiada de taller';

END

--GO
--BEGIN TRAN

--EXEC [dbo].[EXT_COTIZACION_TALLER_SP] 129512, 1851, 538, 32

--SELECT * FROM BitacoraUpdPartidaNissan
--where IdOrden=79405

--SELECT * FROM CotizacionDetalle
--where idCotizacion=129512 AND idCotizacionDetalle=247520

--ROLLBACK TRAN
go

