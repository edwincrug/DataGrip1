-- select [dbo].[SEL_PORCENTAJE_APROBACION_FT](93)
CREATE FUNCTION [dbo].[SEL_PORCENTAJE_APROBACION_FT]
(	
	@idCotizacion NUMERIC(18,0)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- FUNCIÓN PARA MOSTRAR EL NOMBRE DEL CLIENTE
	DECLARE @porcentaje VARCHAR(MAX) = 0

	DECLARE @totalPartidas int = (select count(*) from dbo.CotizacionDetalle as CD 
									where CD.idCotizacion = @idCotizacion)

	IF (@totalPartidas > 0)
	BEGIN
		SELECT @porcentaje = (select count(*) from dbo.CotizacionDetalle as CD where CD.idCotizacion = Coti.idCotizacion and CD.idEstatusPartida not in (1,4)) * 100 / 
		(select count(*) from dbo.CotizacionDetalle as CD where CD.idCotizacion = Coti.idCotizacion and CD.idEstatusPartida not in (4))
		FROM [dbo].[Cotizaciones] Coti
		WHERE (Coti.idEstatusCotizacion = 1 OR Coti.idEstatusCotizacion = 2) AND Coti.idCotizacion = @idCotizacion
	END

	RETURN @porcentaje

END

go

