
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_STATUS_PROVISION_BPRO_FN](@idOrden int)

RETURNS VARCHAR(100)
AS
BEGIN
	
	
		
	DECLARE @numeroOrden NVARCHAR(100)
	DECLARE @proveedorInterno NUMERIC(18,0)
	DECLARE @idOperacion NUMERIC(18,0)
	DECLARE @server NVARCHAR(100)
	DECLARE @db NVARCHAR(100)
	DECLARE @status NVARCHAR(MAX)
	DECLARE @Result VARCHAR(100);
	DECLARE @Existe int;
	

	SELECT @idOperacion = idOperacion FROM CONTRATOOPERACION CO
	INNER JOIN Ordenes  O WITH (NOLOCK) ON CO.idcontratooperacion = O.idcontratooperacion 
	WHERE IdOrden = @idOrden;

	SELECT 
			@server=SERVER,
			@db=DBProduccion
	FROM ContratoOperacionFacturacion COF 
	inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
	WHERE CO.idOperacion =  @idOperacion

	SELECT @numeroOrden=numeroOrden FROM Ordenes WITH (NOLOCK) WHERE idOrden=@idOrden

	SELECT @proveedorInterno = CO.proveedorInterno
	FROM ContratoOperacion C
	INNER JOIN ContratoOperacionFacturacion CO ON CO.idContratoOperacion = C.idContratoOperacion
	WHERE idOperacion = @idOperacion

	IF ((select case when not exists (select 1 from Cotizaciones C1 where C1.idOrden = @idOrden and C1.idTaller in (select idProveedor from Partidas..Proveedor  where razonSocial like '%TOTAL PARTS AND COMPONENTS%') AND @proveedorInterno = 1) then 1 else 0 end) = 1)
	BEGIN
		IF(@server = '[192.168.20.29]' AND @db = '[GATPartsToluca]')
		BEGIN
			IF((SELECT top 1 1 FROM [192.168.20.29].[GATPartsToluca].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = @numeroOrden)>0) 
			BEGIN
				SET @Result = (SELECT top 1 OTE_STATUS FROM [192.168.20.29].[GATPartsToluca].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = @numeroOrden)
			END
			ELSE
			BEGIN
				SET @Result = -1;
			END
		END
		ELSE IF(@server = '[192.168.20.29]' AND @db = '[GAAutoExpress]')
		BEGIN
			IF((SELECT top 1 1 FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = @numeroOrden)>0) 
			BEGIN
				SET @Result = (SELECT top 1 OTE_STATUS FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = @numeroOrden)
			END
			ELSE
			BEGIN
				set @Result = -1;
			END
		END
		ELSE
		BEGIN
			set @Result = -1
		END
	END
	ELSE
	BEGIN
		declare @idProveedor int = (select top 1 idTaller from Cotizaciones where idOrden = @idOrden and idEstatusCotizacion not in (5))

		SELECT 
		@server = SERVER,
		@db = DBProduccion
		FROM CatalogoTecnico CT 
		WHERE CT.IdProveedor =  @idProveedor
		
		IF(@server = '[192.168.20.29]' AND @db = '[GATPartsDHLMex]')
		BEGIN
			IF((SELECT top 1 1 FROM [192.168.20.29].[GATPartsDHLMex].[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = @numeroOrden)>0) 
			BEGIN
				SET @Result = (SELECT top 1 oae_estatus FROM [192.168.20.29].[GATPartsDHLMex].[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = @numeroOrden)
			END
			ELSE
			BEGIN
				SET @Result = -1;
			END
		END
		ELSE IF(@server = '[192.168.20.29]' AND @db = '[GATPartsDHLTlalne]')
		BEGIN
			IF((SELECT top 1 1 FROM [192.168.20.29].[GATPartsDHLTlalne].[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = @numeroOrden)>0) 
			BEGIN
				SET @Result = (SELECT top 1 oae_estatus FROM [192.168.20.29].[GATPartsDHLTlalne].[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = @numeroOrden)
			END
			ELSE
			BEGIN
				set @Result = -1;
			END
		END
		ELSE IF(@server = '[192.168.20.29]' AND @db = '[GATPartsDHLGdl]')
		BEGIN
			IF((SELECT top 1 1 FROM [192.168.20.29].[GATPartsDHLGdl].[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = @numeroOrden)>0) 
			BEGIN
				SET @Result = (SELECT top 1 oae_estatus FROM [192.168.20.29].[GATPartsDHLGdl].[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = @numeroOrden)
			END
			ELSE
			BEGIN
				set @Result = -1;
			END
		END
		ELSE IF(@server = '[192.168.20.29]' AND @db = '[GATPartsMty]')
		BEGIN
			IF((SELECT top 1 1 FROM [192.168.20.29].[GATPartsMty].[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = @numeroOrden)>0) 
			BEGIN
				SET @Result = (SELECT top 1 oae_estatus FROM [192.168.20.29].[GATPartsMty].[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = @numeroOrden)
			END
			ELSE
			BEGIN
				set @Result = -1;
			END
		END

	END
	
	IF(@Result >= 0)
	BEGIN
		SET @Result = 'PROVISIONADO'
	END
	ELSE
	BEGIN
		SET @Result = 'NO PROVISIONADO'
	END
	
	RETURN @Result;
END
go

