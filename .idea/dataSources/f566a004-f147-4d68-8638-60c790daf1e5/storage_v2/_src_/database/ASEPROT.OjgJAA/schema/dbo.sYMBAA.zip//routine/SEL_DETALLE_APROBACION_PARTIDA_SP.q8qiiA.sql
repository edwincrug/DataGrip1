-- =============================================
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- [SEL_DETALLE_APROBACION_PARTIDA_SP] 2
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_DETALLE_APROBACION_PARTIDA_SP]
	@idContratoOperacion INT = 0--,
	--@idTipoUnidad INT = 0

AS
BEGIN
	
	SELECT  PART.idPartida,
				CONTUNI.idUnidad,
				CONT.idContrato,
				CL1.idPartidaClasificacion,
				CL1.clasificacion,
				CL2.idPartidaSubClasificacion,
				CL2.subClasificacion,
				partida,
				noParte,
				PART.descripcion,
				PART.foto,
				PART.instructivo,
				0.00 as costo,
				CONTPART.venta venta,
				PARTEST.idPartidaEstatus,
				isnull(PARTEST.estatus, 'Sin Asignar') as partidaEstatus,
				ISNULL((SELECT nivel FROM  DetalleOperacionAprobacionPartida WHERE PART.idPartida = idPartida AND idOperacionContrato = @idContratoOperacion ), 0) AS nivel
		FROM ContratoOperacion CONTOPE
		INNER JOIN Partidas..Contrato CONT ON CONT.idContrato = CONTOPE.idContrato
		LEFT JOIN Partidas..ContratoUnidad CONTUNI ON CONTUNI.idContrato = CONT.idContrato
		LEFT JOIN Partidas..ContratoPartida CONTPART ON CONTPART.idContratoUnidad = CONTUNI.idContratoUnidad
		LEFT JOIN Partidas..Partida PART ON PART.idPartida = CONTPART.idPartida		
		LEFT JOIN [Partidas].[dbo].[PartidaClasificacion] PARCLAS ON PART.idPartidaClasificacion = PARCLAS.idPartidaClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaClasificacion] CL1 ON CL1.idPartidaClasificacion = PART.idPartidaClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaSubClasificacion] CL2 ON CL2.idPartidaSubClasificacion = PART.idPartidaSubClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaEstatus] PARTEST ON PARTEST.idPartidaEstatus = PART.estatus
		WHERE  CONTOPE.idContratoOperacion = @idContratoOperacion
		
END


go

