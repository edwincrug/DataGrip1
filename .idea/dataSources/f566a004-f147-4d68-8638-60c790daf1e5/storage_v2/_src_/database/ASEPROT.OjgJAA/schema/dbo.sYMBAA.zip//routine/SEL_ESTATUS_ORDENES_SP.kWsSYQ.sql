
create procedure [dbo].[SEL_ESTATUS_ORDENES_SP]
as
begin
select * from EstatusOrdenes
end
go

