
/*		SEL_REPORTE_CONFORMIDAD_SP @idOrden = 35214, @idContratoOperacion=1, @idUsuario=107	
select * from PresupuestoORden where idOrden = 35214
select * from Cotizaciones where idOrden = 35214
select * from CotizacionDEtalle where idCotizacion=41127
select * from DatosCopadeOrden where idOrden = 35214
select * from OrdenAgrupadaDetalle where idDatosCopadeOrden=28128
SELECT * FROM Ordenes where numeroOrden='01-2010233-1713' 
EXEC [dbo].[SEL_REPORTE_CONFORMIDAD_SP] 253547,57,538  TEST
*/

CREATE PROCEDURE [dbo].[SEL_REPORTE_CONFORMIDAD_SP]
	@idOrden NUMERIC(18,0),
	@idContratoOperacion NUMERIC(18,0),
	@idUsuario NUMERIC(18,0) = NULL


AS

declare @nombreOperacion as nvarchar(500);
declare @numOrden as varchar(50);
declare @folio as varchar(50);
declare @NomCentroTrabajo as varchar(50);
declare @saldoDis as decimal(18,2);
declare @folioPresupuesto as varchar(50);
declare @solpe as varchar(50);
declare @numeroSAP as varchar(MAX);
declare @IdZona INT;
declare @aplicaFirmaPEMEX INT, @fechaFinalTerminoTrabajo DATE

SELECT TOP 1 @fechaFinalTerminoTrabajo=fechaFinal FROM HistorialEstatusOrden
where idEstatusOrden=6 AND idOrden=@idOrden

declare @RFC varchar(max);
declare @RazonSocial varchar(max);
declare @idCentroTrabajo int;
declare @idOperacion int;
declare @monto nvarchar(max) = '535,524,361.33 M.N.';
declare @contrato nvarchar(15) = ''

SELECT @nombreOperacion = BDPartida.descripcion,
	   @idCentroTrabajo = BDCentro.idCentroTrabajo, 
	   @idOperacion = BDContrato.idOperacion, 
	   @RFC= BDContratoFacturacion.RFC, 
	   @RazonSocial = BDContratoFacturacion.razonSocial,
	   @numOrden = BDOrden.numeroOrden, 
	   @IdZona = BDOrden.idZona, 
	   @NomCentroTrabajo = BDCentro.nombreCentroTrabajo,
	   @aplicaFirmaPEMEX = CASE WHEN BDOrden.idContratoOperacion=57 AND CAST(@fechaFinalTerminoTrabajo AS DATE)<='02/03/2020' THEN 1 ELSE 0 END
FROM Ordenes as BDOrden
	 JOIN ContratoOperacion as BDContrato ON BDOrden.idContratoOperacion = BDContrato.idContratoOperacion
	 JOIN ContratoOperacionFacturacion as BDContratoFacturacion ON BDContrato.idContratoOperacion = BDContratoFacturacion.idContratoOperacion
	 JOIN Partidas.dbo.Contrato as BDPartida ON BDContrato.idContrato = BDPartida.idContrato
	 LEFT JOIN CentroTrabajos as BDCentro ON BDOrden.idCentroTrabajo = BDCentro.idCentroTrabajo
WHERE idOrden = @idOrden 

declare @tabPresupuesto table(idPresupuesto int, presupuesto decimal(18,4), folioPresupuesto varchar(50), solpe varchar(50), fechaInicioPresupuesto datetime, fechaFinalPresupuesto datetime, idCentroTrabajo numeric(18,0), idEstatusPresupuesto int, orden numeric(18,0), nombreEstatusPresupuesto varchar(max), idCentroTrabajoDos numeric(18,0), nombreCentroTrabajo varchar(max), idOperacion int, montoTraspaso numeric(18,2), utilizado numeric(18,2), saldo numeric(18,6), ordPendiente numeric(18,0), esTraspaso numeric(18,0))
insert into @tabPresupuesto
EXEC [SEL_PRESUPUESTO_CDT_CONFORMIDAD_SP]  @idCentroTrabajo, @idOperacion

IF NOT EXISTS(SELECT folio FROM PresupuestoOrden WHERE idOrden=@idOrden)
	BEGIN
		select @saldoDis = ISNULL(presupuesto,0) from @tabPresupuesto
		select @folioPresupuesto = ISNULL(folioPresupuesto,'0') from @tabPresupuesto
		select @solpe = ISNULL(solpe,'0') from @tabPresupuesto
	END
ELSE
	BEGIN
		SELECT 
				@saldoDis=0,
				@folioPresupuesto=ISNULL(P.folioPresupuesto,'0'),
				@solpe=ISNULL(P.solpe,'0')
		FROM PresupuestoOrden PO
		JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto 
		WHERE idOrden=@idOrden
	END

SELECT @folio=folio FROM PresupuestoOrden WHERE idOrden=@idOrden
SET LANGUAGE Spanish;


DECLARE @IdPadre int
DECLARE @VariableTabla TABLE ( ID INT IDENTITY(1,1),
								idPadre int, 
								nombreNivel   	    nvarchar(150),
								nombre	        nvarchar(150)
								  )
INSERT INTO @VariableTabla (idPadre,nombreNivel,nombre) 
SELECT Zona.idPadre, NivelZ.etiqueta AS nombreNivel, Zona.nombre from Partidas.dbo.Zona AS Zona
				INNER JOIN Partidas.dbo.NivelZona as NivelZ
				ON Zona.idNivelZona = NivelZ.idNivelZona
				where idZona = @IdZona

SELECT @IdPadre = @IdZona from Partidas.dbo.Zona AS Zona
				INNER JOIN Partidas.dbo.NivelZona as NivelZ
				ON Zona.idNivelZona = NivelZ.idNivelZona
				where idZona = @IdZona

WHILE (@IdPadre > 0)

	BEGIN

		SELECT @IdPadre = Zona.idPadre from Partidas.dbo.Zona AS Zona
				INNER JOIN Partidas.dbo.NivelZona as NivelZ
				ON Zona.idNivelZona = NivelZ.idNivelZona
				where idZona = @IdPadre
		INSERT INTO @VariableTabla (idPadre,nombreNivel,nombre) 
		SELECT Zona.idPadre, NivelZ.etiqueta AS nombreNivel, Zona.nombre from Partidas.dbo.Zona AS Zona
				INNER JOIN Partidas.dbo.NivelZona as NivelZ
				ON Zona.idNivelZona = NivelZ.idNivelZona
				where idZona = @IdPadre
	END 

IF EXISTS
	(
		SELECT 
			 PG.IdParametroGeneral
		FROM ParametrosGeneral PG
		INNER JOIN ParametrosGeneralContratoZona PGCZ ON PG.IdParametroGeneral = PGCZ.IdParametroGeneral
		WHERE PG.IdParametroGeneral = 8 AND PGCZ.IdZona = (select idPadre from partidas..zona where idzona = @IdZona) AND PGCZ.IdOperacion = @idOperacion/*Parametro de contrato por zona padre*/
	)
	BEGIN
		print 'subcontrato'
		SELECT 
			 --@folioPresupuesto = PGCZ.Presupuesto,
			 --@monto = convert(varchar,cast(PGCZ.Presupuesto as money), 1) + ' M.N.',
			 @contrato = PGCZ.Contrato
		FROM ParametrosGeneral PG
		INNER JOIN ParametrosGeneralContratoZona PGCZ ON PG.IdParametroGeneral = PGCZ.IdParametroGeneral
		WHERE PG.IdParametroGeneral = 8 AND PGCZ.IdZona = (select idPadre from partidas..zona where idzona = @IdZona) AND PGCZ.IdOperacion = @idOperacion
	END	
--print 'monto'
--print @monto

SELECT  
		CASE WHEN  @idContratoOperacion IN(3,8,57) THEN @folio ELSE @numOrden END NoReporte,
		@nombreOperacion as nombreOperacion, 
		@saldoDis as SaldoDisponible, 
		@NomCentroTrabajo as centroTrabajo, 
		@RFC as RFC, 
		@RazonSocial as razonSocial,
		(SELECT nombre FROM @VariableTabla WHERE idPadre = 0)padre,
		(SELECT TOP 1 nombre FROM @VariableTabla WHERE idPadre <> 0)hijo,
		(select TOP 1 fechaInicial from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=6) AS fechaActual,
		'*SE EXIME DE TODA RESPONSABILIDAD AL PERSONAL QUE EMITE ESTE REPORTE DE CONFORMIDAD, CUANDO A LA ENTREGA DE LOS BIENES, ARRENDAMIENTOS O SERVICIOS EN DESTINO FINAL O EN LA OPERACIÓN SE DETERMINEN FALTANTES, AVERIAS, DISCREPANCIAS,
         ENTREGAS INCOMPLETAS, O SE DETECTEN FALLAS O VICIOS OCULTOS DE ACUERDO A LO ESTABLECIDO EN EL CONTRATO.' as txtLegal,
		 'CDMX' Lugar,
		 CASE WHEN  @idContratoOperacion=3 THEN '1' ELSE '' END operacion,
		 (select firma from ContratoOperacionFacturacion 
		 where idContratoOperacion=CASE WHEN @aplicaFirmaPEMEX=1 THEN 3 ELSE @idContratoOperacion END) as firmaDoc,
		 (select imagen from ContratoOperacionFacturacion where idContratoOperacion=@idContratoOperacion) as img,
         --CAMBIO ETGLOBAL
		 --'5400027380' contrato,
		 CASE WHEN @idContratoOperacion = 15 THEN '1' ELSE '' END esETGLOBAL,
         case when @contrato = '' then CONT.numero else @contrato end contrato,
		 --CAMBIO ETGLOBAL
		 @solpe AS solpe,
		 CASE WHEN @idContratoOperacion = 57 THEN '1' ELSE '' END aplicaSAP,
		 ORDE.numeroOrden AS numeroOrden,
		 ISNULL((SELECT CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORDE.idOrden),'') numeroSAP,
         @folioPresupuesto AS noPresupuesto,
         --'$382,427,879.00 M.N.' monto,
		 @monto monto,
         @numOrden pedido,
        'Representante Legal' puesto,
	    CASE LEN(CONVERT(VARCHAR(2),DATEPART(dd,GETDATE())))
			WHEN 1 THEN '0' + CONVERT(VARCHAR(2),DATEPART(dd,GETDATE()))
			ELSE CONVERT(VARCHAR(2),DATEPART(dd,GETDATE()))
		END diaLugar,
		CASE LEN(CONVERT(VARCHAR(2),DATEPART(mm,GETDATE()))) 
			WHEN 1 THEN '0' + CONVERT(VARCHAR(2),DATEPART(mm,GETDATE()))
			ELSE CONVERT(VARCHAR(2),DATEPART(mm,GETDATE()))
		END
		mesLugar,
		(SELECT DATENAME(MONTH, GETDATE())) AS mesLugar2,
		CONVERT(VARCHAR(4),DATEPART(year,GETDATE())) anioLugar,
		CASE LEN(CONVERT(VARCHAR(2),DATEPART(dd,GETDATE())))
			WHEN 1 THEN '0' + CONVERT(VARCHAR(2),DATEPART(dd,GETDATE()))
			ELSE CONVERT(VARCHAR(2),DATEPART(dd,GETDATE()))
		END diaRecibo,
		CASE LEN(CONVERT(VARCHAR(2),DATEPART(mm,CONT.fechaInicio))) 
			WHEN 1 THEN '0' + CONVERT(VARCHAR(2),DATEPART(mm,GETDATE()))
			ELSE CONVERT(VARCHAR(2),DATEPART(mm,GETDATE()))
		END
		mesRecibo,
		CONVERT(VARCHAR(4),DATEPART(year,GETDATE())) anioRecibo,
		CASE LEN(CONVERT(VARCHAR(2),DATEPART(dd,CONT.fechaInicio)))
			WHEN 1 THEN '0' + CONVERT(VARCHAR(2),DATEPART(dd,CONT.fechaInicio))
			ELSE CONVERT(VARCHAR(2),DATEPART(dd,CONT.fechaInicio))
		END diaFormalizacion,
		CASE LEN(CONVERT(VARCHAR(2),DATEPART(mm,CONT.fechaInicio))) 
			WHEN 1 THEN '0' + CONVERT(VARCHAR(2),DATEPART(mm,CONT.fechaInicio))
			ELSE CONVERT(VARCHAR(2),DATEPART(mm,CONT.fechaInicio))
		END
		mesFormalizacion,
		CONVERT(VARCHAR(4),DATEPART(year,CONT.fechaInicio)) anioFormalizacion,
		CASE LEN(CONVERT(VARCHAR(2),DATEPART(dd,CONT.fechaInicio)))
			WHEN 1 THEN '0' + CONVERT(VARCHAR(2),DATEPART(dd,CONT.fechaInicio))
			ELSE CONVERT(VARCHAR(2),DATEPART(dd,CONT.fechaInicio))
		END diaRecepcion,
		CASE LEN(CONVERT(VARCHAR(2),DATEPART(mm,CONT.fechaInicio))) 
			WHEN 1 THEN '0' + CONVERT(VARCHAR(2),DATEPART(mm,CONT.fechaInicio))
			ELSE CONVERT(VARCHAR(2),DATEPART(mm,CONT.fechaInicio))
		END
		mesRecepcion,
		CONVERT(VARCHAR(4),DATEPART(year,CONT.fechaInicio)) anioRecepcion		  
FROM Ordenes ORDE
LEFT JOIN [dbo].[ContratoOperacion] CONTOP ON ORDE.idContratoOperacion = CONTOP.idContratoOperacion
LEFT JOIN [Partidas]..[Contrato] CONT ON CONTOP.idContrato = CONT.idContrato
WHERE ORDE.idOrden = @idOrden
--------------------------------------------
/*	SELECT
			_PART.idPartida,		       
			_PART.partida,
			_PART.descripcion,	
            --_PART.idPartida Cantidad,
			SUM(_CODE.cantidad) Cantidad,
			TIPOUNI.tipo + ' ' + CONVERT(VARCHAR(10),UNID.anio) UNIDAD,
			_ORD.numeroOrden,
			CONVERT(VARCHAR(10),GETDATE(),103) FechaInspeccion,
			ISNULL(SUM((ISNULL(_CODE.venta,0) * ISNULL(_CODE.cantidad,0))),0) as venta
		FROM [dbo].[Cotizaciones] _COTI 
		INNER JOIN [dbo].[CotizacionDetalle] _CODE ON _COTI.idCotizacion = _CODE.idCotizacion  
		INNER JOIN [Partidas].[dbo].[Partida] _PART	ON _CODE.idPartida = _PART.idPartida
		INNER JOIN [dbo].[Ordenes]	_ORD	  ON _COTI.idOrden = _ORD.idOrden
		INNER JOIN [dbo].[ContratoOperacion] _CONTOP ON _ORD.idContratoOperacion = _CONTOP.idContratoOperacion
		INNER JOIN [Partidas].[dbo].[ContratoProveedor]	_CPRO ON _CPRO.idContrato = _CONTOP.idContrato  AND _COTI.idTaller = _CPRO.idProveedor
		LEFT JOIN [Partidas].[dbo].[Contrato] _CONT	ON _CPRO.idContrato = _CONT.idContrato
		--LEFT JOIN [Partidas].[dbo].[ContratoUnidad]	_CONTUNI  ON _CONTUNI.idContratoUnidad = _CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON _PART.idPartida = CPVenta.idPartida --AND CPVenta.idContratoUnidad = _CONTUNI.idContratoUnidad   
		INNER JOIN [Partidas].[dbo].[Proveedor]	_P ON _P.idProveedor = _CPRO.idProveedor
		LEFT JOIN [Partidas].[dbo].[Unidad] UNID ON UNID.idUnidad = _PART.idUnidad
		LEFT JOIN [Partidas].[dbo].[TipoUnidad] TIPOUNI ON UNID.idTipoUnidad = TIPOUNI.idTipoUnidad
		INNER JOIN [Partidas].[dbo].[ProveedorEspecialidad] _PE ON _PE.idProveedor = _P.idProveedor AND _PE.idEspecialidad = _PART.idEspecialidad
		INNER JOIN .[Partidas].[dbo].[Especialidad]	_ESP ON _ESP.idEspecialidad = _PE.idEspecialidad 
	WHERE _ORD.idOrden = @idOrden 
	AND _CONTOP.idContratoOperacion = @idContratoOperacion
	AND _CODE.idEstatusPartida IN(2) 
	AND _COTI.idEstatusCotizacion IN(3)
	GROUP BY _PART.idPartida,_PART.partida,_PART.descripcion,_ORD.numeroOrden, TIPOUNI.tipo, UNID.anio */
		SELECT
			PART.idPartida,		       
			PART.partida,
			REPLACE(PART.descripcion,'"','') descripcion,	
			SUM(CODE.cantidad) Cantidad,
			TIPOUNI.tipo + ' ' + CONVERT(VARCHAR(10),U.modelo) UNIDAD,
			ORD.numeroOrden,
			CONVERT(VARCHAR(10),GETDATE(),103) FechaInspeccion,
			ISNULL(SUM((ISNULL(CODE.venta,0) * ISNULL(CODE.cantidad,0))),0) as venta
		FROM [dbo].[Cotizaciones] COTI
				INNER JOIN [dbo].[CotizacionDetalle] CODE ON COTI.idCotizacion = CODE.idCotizacion
				INNER JOIN [dbo].[Ordenes] ORD ON COTI.idOrden = ORD.idOrden
				INNER JOIN [dbo].[Unidades] U ON ORD.idUnidad = U.idUnidad
				INNER JOIN [dbo].[ContratoOperacion] CONTOP ON ORD.idContratoOperacion = CONTOP.idContratoOperacion
				INNER JOIN [Partidas].[dbo].Contrato CONT ON CONTOP.idContrato = CONT.idContrato
				INNER JOIN [Partidas].[dbo].ContratoUnidad CONTUNI ON CONTUNI.idContrato = CONT.idContrato AND CONTUNI.idUnidad = U.idTipoUnidad
				LEFT JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON CONTPART.idContratoUnidad = CONTUNI.idContratoUnidad AND CONTPART.idPartida = CODE.idPartida
				INNER JOIN [Partidas].[dbo].[Partida] PART ON PART.idPartida = CONTPART.idPartida
				LEFT JOIN [Partidas].[dbo].[ContratoProveedor] CPRO ON CPRO.idContrato = CONT.idContrato AND idProveedor = COTI.idTaller
				LEFT JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = CPRO.idProveedor
				LEFT JOIN [Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = P.idProveedor	AND PE.idEspecialidad = PART.idEspecialidad
				LEFT JOIN .[Partidas].[dbo].[Especialidad] ESP ON ESP.idEspecialidad = PE.idEspecialidad
				LEFT JOIN [Partidas].[dbo].[PartidaEstatus] PARTEST ON PARTEST.idPartidaEstatus = PART.estatus
				LEFT JOIN [Partidas].[dbo].[Unidad] UNID ON UNID.idUnidad = CONTUNI.idUnidad
				LEFT JOIN [Partidas].[dbo].[TipoUnidad] TIPOUNI ON UNID.idTipoUnidad = TIPOUNI.idTipoUnidad
				LEFT JOIN [Partidas].[dbo].[PartidaClasificacion] CL1 ON CL1.idPartidaClasificacion = PART.idPartidaClasificacion
				LEFT JOIN [Partidas].[dbo].[PartidaSubClasificacion] CL2 ON CL2.idPartidaSubClasificacion = PART.idPartidaSubClasificacion
				LEFT JOIN [dbo].[OperacionAprobacion] OPEAP ON CONTOP.idContratoOperacion = OPEAP.idOperacionContrato
	WHERE ORD.idOrden = @idOrden
	AND CONTOP.idContratoOperacion = @idContratoOperacion
	AND CODE.idEstatusPartida IN(2) 
	AND COTI.idEstatusCotizacion IN(3)
	GROUP BY PART.idPartida,PART.partida,PART.descripcion,ORD.numeroOrden, TIPOUNI.tipo, U.modelo
/*	SELECT 
				 SUM((ISNULL(CPVenta.venta,0) * ISNULL(_CODE.cantidad,0))) total
		FROM [dbo].[Cotizaciones] _COTI 
		INNER JOIN [dbo].[CotizacionDetalle] _CODE ON _COTI.idCotizacion = _CODE.idCotizacion  
		INNER JOIN [Partidas].[dbo].[Partida] _PART	ON _CODE.idPartida = _PART.idPartida
		INNER JOIN [dbo].[Ordenes]	_ORD	  ON _COTI.idOrden = _ORD.idOrden
		INNER JOIN [dbo].[ContratoOperacion] _CONTOP ON _ORD.idContratoOperacion = _CONTOP.idContratoOperacion
		INNER JOIN [Partidas].[dbo].[ContratoProveedor]	_CPRO ON _CPRO.idContrato = _CONTOP.idContrato  AND _COTI.idTaller = _CPRO.idProveedor
		LEFT JOIN [Partidas].[dbo].[Contrato] _CONT	ON _CPRO.idContrato = _CONT.idContrato
		--LEFT JOIN [Partidas].[dbo].[ContratoUnidad]	_CONTUNI  ON _CONTUNI.idContratoUnidad = _CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON _PART.idPartida = CPVenta.idPartida -- AND CPVenta.idContratoUnidad = _CONTUNI.idContratoUnidad   
		INNER JOIN [Partidas].[dbo].[Proveedor]	_P		  ON _P.idProveedor = _CPRO.idProveedor
		INNER JOIN [Partidas].[dbo].[ProveedorEspecialidad] _PE ON _PE.idProveedor = _P.idProveedor AND _PE.idEspecialidad = _PART.idEspecialidad
		INNER JOIN .[Partidas].[dbo].[Especialidad]	_ESP ON _ESP.idEspecialidad = _PE.idEspecialidad 
	WHERE _ORD.idOrden = @idOrden 
	AND _CONTOP.idContratoOperacion = @idContratoOperacion
	AND _CODE.idEstatusPartida IN(2) 
	AND _COTI.idEstatusCotizacion IN(3) */

	SELECT 
		ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) total
	FROM [dbo].[Cotizaciones] C 
		INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
		INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
		INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
	WHERE O.idOrden = @idOrden 
	AND CO.idContratoOperacion = @idContratoOperacion
	AND CD.idEstatusPartida IN(2) 
	AND C.idEstatusCotizacion IN(3)	
	
	DECLARE @Token VARCHAR(10);
	SET @Token = (SELECT TOP 1 token FROM Token TOK
					INNER JOIN Ordenes ORD ON TOK.idOrdenServicio = ORD.idOrden
					INNER JOIN Usuarios USU ON TOK.idUsuario = USU.idUsuario
					WHERE TOK.idOrdenServicio = @idOrden
						  AND TOK.idEstatusOrden IN(7,8)
					ORDER BY idToken DESC);
					
	IF( @Token IS NULL )
		BEGIN
			IF(@idContratoOperacion IN(3,8, 57))
				BEGIN
					SELECT token = '', fechaHora = '', nombreUsuario = '', nombreCompleto = '', token2 = '', fechaHora2 = '', nombreUsuario2 = '', nombreCompleto2 = '',  CASE WHEN  @idContratoOperacion in(3,57) THEN 'Jefe de mantenimiento de terminal' ELSE 'Cordinador SAD' END bajo, CASE WHEN  @idContratoOperacion in(3,57) THEN 'Superintedente de terminal' ELSE 'Superintendente General de Mantenimiento SAD' END alto;
				END
			ELSE
				BEGIN
					SELECT Token = '', fechaHora = '', nombreUsuario = '', nombreCompleto = '';
				END
		END
	ELSE
		BEGIN
			IF(@idContratoOperacion IN(3,8,57))
				BEGIN
					PRINT 'ENTRA AQUI1'
					--SELECT TOP 1 token, fechaHora, nombreUsuario,nombreCompleto FROM Token TOK
					--INNER JOIN Ordenes ORD ON TOK.idOrdenServicio = ORD.idOrden
					--INNER JOIN Usuarios USU ON TOK.idUsuario = USU.idUsuario
					--WHERE TOK.idOrdenServicio = @idOrden
					--	  AND TOK.idEstatusOrden = 7
					--ORDER BY idToken DESC;
					
				/*	DECLARE @token2 NVARCHAR(100) = ''
					DECLARE @fechaHora2 NVARCHAR(100) = ''
					DECLARE @nombreUsuario2 NVARCHAR(100) = ''
					DECLARE @nombreCompleto2 NVARCHAR(100) = ''
					SELECT @token2=token, @fechaHora2=fechaHora, @nombreUsuario2=nombreUsuario, @nombreCompleto2=nombreCompleto FROM Token TOK
					INNER JOIN Ordenes ORD ON TOK.idOrdenServicio = ORD.idOrden
					INNER JOIN Usuarios USU ON TOK.idUsuario = USU.idUsuario
					INNER JOIN [ClientePerfilZona] CPZ ON CPZ.idUsuario = TOK.idUsuario
					WHERE TOK.idOrdenServicio = @idOrden
						  AND TOK.idEstatusOrden = 7
						  AND CPZ.idPerfil = 2
						  AND TOK.estatusToken = 1
					ORDER BY idToken DESC;

					SELECT token, fechaHora, nombreUsuario,nombreCompleto, @token2 AS token2, @fechaHora2 AS fechaHora2, @nombreUsuario2 AS nombreUsuario2, @nombreCompleto2 AS nombreCompleto2
					FROM Token TOK
					INNER JOIN Ordenes ORD ON TOK.idOrdenServicio = ORD.idOrden
					INNER JOIN Usuarios USU ON TOK.idUsuario = USU.idUsuario
					INNER JOIN [ClientePerfilZona] CPZ ON CPZ.idUsuario = TOK.idUsuario
					WHERE TOK.idOrdenServicio = @idOrden
						  AND TOK.idEstatusOrden = 7
						  AND CPZ.idPerfil = 1
						  AND TOK.estatusToken = 1
					ORDER BY idToken DESC;*/
				DECLARE @token2 NVARCHAR(100) = ''
				DECLARE @fechaHora2 NVARCHAR(100) = ''
				DECLARE @nombreUsuario2 NVARCHAR(100) = ''
				DECLARE @nombreCompleto2 NVARCHAR(100) = ''
					SELECT @token2=token, @fechaHora2=fechaHora, @nombreUsuario2=nombreUsuario, @nombreCompleto2=nombreCompleto 
					FROM Token TOK
						INNER JOIN Ordenes ORD ON TOK.idOrdenServicio = ORD.idOrden
						INNER JOIN Usuarios USU ON TOK.idUsuario = USU.idUsuario
						INNER JOIN [ClientePerfilZona] CPZ ON CPZ.idUsuario = TOK.idUsuario
					WHERE TOK.idOrdenServicio = @idOrden
						  AND TOK.idEstatusOrden in(7,8)
						  AND CPZ.idPerfil = 1
						  AND TOK.estatusToken = 2
					ORDER BY idToken DESC;

				DECLARE @token1 NVARCHAR(100) = ''
				DECLARE @fechaHora NVARCHAR(100) = ''
				DECLARE @nombreUsuario NVARCHAR(100) = ''
				DECLARE @nombreCompleto NVARCHAR(100) = ''
					SELECT @token1=token, @fechaHora=fechaHora, @nombreUsuario=nombreUsuario, @nombreCompleto=nombreCompleto 
					FROM Token TOK
						INNER JOIN Ordenes ORD ON TOK.idOrdenServicio = ORD.idOrden
						INNER JOIN Usuarios USU ON TOK.idUsuario = USU.idUsuario
						INNER JOIN [ClientePerfilZona] CPZ ON CPZ.idUsuario = TOK.idUsuario
					WHERE TOK.idOrdenServicio = @idOrden
						  AND TOK.idEstatusOrden in(7,8)
						  AND CPZ.idPerfil = 2
						  AND TOK.estatusToken = 2
					ORDER BY idToken DESC;

					SELECT TOP 1 @token1 AS token, @fechaHora AS fechaHora, @nombreUsuario AS nombreUsuario, @nombreCompleto AS nombreCompleto, @token2 AS token2, @fechaHora2 AS fechaHora2, @nombreUsuario2 AS nombreUsuario2, @nombreCompleto2 AS nombreCompleto2, CASE WHEN  @idContratoOperacion in(3,57) THEN 'Jefe de mantenimiento de terminal' ELSE 'Cordinador SAD' END bajo, CASE WHEN  @idContratoOperacion in(3,57) THEN 'Superintedente de terminal' ELSE 'Superintendente General de Mantenimiento SAD' END alto
					FROM Token
				END
			ELSE
				BEGIN
				PRINT 'ENTRA AQUI2'
					SELECT TOP 1 token, fechaHora, nombreUsuario,nombreCompleto FROM Token TOK
					INNER JOIN Ordenes ORD ON TOK.idOrdenServicio = ORD.idOrden
					INNER JOIN Usuarios USU ON TOK.idUsuario = USU.idUsuario
					WHERE TOK.idOrdenServicio = @idOrden
						  AND TOK.idEstatusOrden = 7
					ORDER BY idToken DESC;
				END
		END

SELECT * FROM @VariableTabla ORDER BY ID DESC

SELECT  
		@nombreOperacion as nombreOperacionEnc, 
		CASE WHEN  @idContratoOperacion=3 THEN '1' ELSE '' END operacionEnc,
		@saldoDis as SaldoDisponibleEnc, 
		@NomCentroTrabajo as centroTrabajoEnc, 
		case when @contrato = '' then CONT.numero else @contrato end contratoEnc,
		@solpe AS solpeEnc,
		@folioPresupuesto AS noPresupuestoEnc,
		@monto montoEnc,
		@numOrden pedidoEnc,
		CASE WHEN @idContratoOperacion = 15 THEN '1' ELSE '' END esETGLOBALEnc,
		CASE WHEN @idContratoOperacion = 57 THEN '1' ELSE '' END aplicaSAPEnc,
		ISNULL((SELECT CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = ORDE.idOrden),'') numeroSAPEnc,
		ORDE.numeroOrden AS numeroOrdenEnc,
		(SELECT nombre FROM @VariableTabla WHERE idPadre = 0)padreEnc,
		(SELECT TOP 1 nombre FROM @VariableTabla WHERE idPadre <> 0)hijoEnc
         --'$382,427,879.00 M.N.' monto,
FROM Ordenes ORDE
LEFT JOIN [dbo].[ContratoOperacion] CONTOP ON ORDE.idContratoOperacion = CONTOP.idContratoOperacion
LEFT JOIN [Partidas]..[Contrato] CONT ON CONTOP.idContrato = CONT.idContrato
WHERE ORDE.idOrden = @idOrden

--GO
--EXEC [dbo].[SEL_REPORTE_CONFORMIDAD_SP] 163899,57,538
go

grant execute, view definition on SEL_REPORTE_CONFORMIDAD_SP to DevOps
go

