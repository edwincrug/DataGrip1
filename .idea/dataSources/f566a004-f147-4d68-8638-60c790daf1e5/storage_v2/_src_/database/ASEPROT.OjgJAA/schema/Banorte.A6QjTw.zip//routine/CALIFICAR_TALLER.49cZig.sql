


/*
	Fecha			Autor			Descripción
	21-May-2018		José Etmanuel	Se crea el SP que califica taller
*/

CREATE PROC [Banorte].[CALIFICAR_TALLER]
@idOrden int=0,
@calificacion1 int=1,
@calificacion2 int=1,
@calificacion3 int=1,
@calificacion4 int=1,
@calificacion5 int=1 
as
begin
/*empieza el sp*/
declare @idTaller int = (select idTaller from Ordenes where idOrden=@idOrden);
declare @c1 int=0,@c2 int=0,@c3 int=0,@c4 int=0,@c5 int=0;
DECLARE @Promedio decimal(18,6)=1;
DECLARE @n decimal(18,6)=0;


insert into calificacionTaller values(@idTaller,@calificacion1,@calificacion2,@calificacion3,@calificacion4,@calificacion5,@idOrden)
       if not exists (select * from rankTaller where idTaller=@idTaller)
	   begin
	      select @Promedio=ceiling(exp(avg(log(calificacion1+calificacion2+calificacion3+calificacion4+calificacion5)))/5) from calificacionTaller where idTaller=@idTaller
		  insert into rankTaller(idTaller,Rank) values(@idTaller,@Promedio)
		  select 1 as ok
	   end
	   else
	   begin
	      select @Promedio=ceiling(exp(avg(log(calificacion1+calificacion2+calificacion3+calificacion4+calificacion5)))/5) from calificacionTaller where idTaller=@idTaller
		  update rankTaller set Rank=@Promedio where idTaller=@idTaller
		  select 2 as ok
	   end
end

go

grant execute, view definition on Banorte.CALIFICAR_TALLER to DevOps
go

