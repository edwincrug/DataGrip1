-- =============================================
-- Author:		<YJH>
-- Create date: <06/06/2018>
-- Description:	<INSERTA USUARIOS CREADOS DESDE EL SISTEMA DE REFACCIONES>
-- =============================================
CREATE PROCEDURE [Banorte].[INSERT_USUARIOS]
	@username varchar(50),
	@password varchar(50),
	@nombreCompleto nvarchar(50), 
	@mail nvarchar(100),
	@numTel varchar(50),
	@extension varchar(50),
	@empresa varchar(50),
	@idTipoUsuario int = 4 -- Proveedor
AS
BEGIN

DECLARE @idUsuario int = 0
	
	IF (NOT EXISTS (SELECT nombreUsuario FROM Usuarios WHERE nombreUsuario = @username))
		BEGIN
			INSERT INTO Usuarios (
			     [nombreUsuario],[contrasenia],[idCatalogoTipoUsuarios],[nombreCompleto]
				,[correoElectronico],[telefonoUsuario],[extensionUsuario],[empresa])
		    VALUES (
					@username, @password,@idTipoUsuario,@nombreCompleto,@mail,@numTel
				   ,@extension,@empresa)
			SET @idUsuario = @@IDENTITY
		END
	ELSE
		BEGIN
			SELECT @idUsuario=idUsuario FROM Usuarios WHERE nombreUsuario = @username
		END


  SELECT @idUsuario AS idUsuarioSisco
END
go

grant execute, view definition on Banorte.INSERT_USUARIOS to DevOps
go

