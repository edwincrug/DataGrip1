


/*
	Objetivo: Devuelve el usaurio de un Token activo
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	05/07/18		JEHR	Creación del SP

	------ Pruebas

*/
CREATE proc [Banorte].[VALIDA_LOGIN_PAG]
	@nombreUsuario varchar(max),
	@contrasenia varchar(max)
as
begin

	declare @status int = 0,
			@msg varchar(max) = 'Error: Sql, no se pudo login'

	--select @status as [status], @msg as [msg], @nombreUsuario as us, @contrasenia as psw
	print @nombreUsuario;
	if isnull(@nombreUsuario,'') = ''
	begin 
		SET @status = 0;
		SET @msg = 'Error: Nombre de usuario vacio'
		select @status as [status], @msg as [msg]
	end 
	else
	begin
		if isnull(@contrasenia,'') = ''
		begin 
			SET @status = 0;
			SET @msg = 'Error: Contraseña vacia'
			select @status as [status], @msg as [msg]
		end 
		else
		begin
			DECLARE
				@idUsuario INT,
				@idUnidad INT
			;

			select @idUsuario = [idUsuario] from 
			Usuarios where nombreUsuario=@nombreUsuario and contrasenia=@contrasenia

			if EXISTS (SELECT * FROM [Banorte].[User_Suc] WHERE [idUsuario] = @idUsuario)
			begin
				set @status = 1;
				SELECT @msg = [idUsuario]FROM [Banorte].[User_Suc] WHERE [idUsuario] = @idUsuario
				
				select @status as [status], @msg as [msg]
			end
			else
			begin
				SET @status = 0;
				SET @msg = 'Error: No coincide usuario y contraseña'
				select @status as [status], @msg as [msg]
			end
		end
	end
end

go

grant execute, view definition on Banorte.VALIDA_LOGIN_PAG to DevOps
go

