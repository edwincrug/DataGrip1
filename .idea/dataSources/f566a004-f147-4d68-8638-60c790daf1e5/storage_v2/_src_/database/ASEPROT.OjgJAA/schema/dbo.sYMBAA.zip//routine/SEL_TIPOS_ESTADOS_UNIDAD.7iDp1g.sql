-- =============================================
-- Obtiene los estados de la unidad
-- =============================================
-- [dbo].[SEL_TIPOS_ESTADOS_UNIDAD]
CREATE PROCEDURE [dbo].[SEL_TIPOS_ESTADOS_UNIDAD]
AS
BEGIN
	SELECT [idCatalogoEstadoUnidad] AS idEstadoUnidad
		  ,[descripcionEstadoUnidad] AS descripcion
	  FROM [dbo].[CatalogoEstadoUnidad]
END


go

