
CREATE VIEW [dbo].[VwTraspasoPresupuestoOrigen]
AS
SELECT sum(monto) as [Acumulado],[idPresupuestoOrigen]
    FROM traspasopresupuesto
  GROUP BY [idPresupuestoOrigen]
go

