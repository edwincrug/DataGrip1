-- =============================================
-- Author:		<YJH>
-- Create date: <02/01/2019>
-- Description:	<Obtiene datos para insertar la provisión en Bpro>'
-- [Banorte].[SEL_DATOS_PROVISION_B] '26-43618-11644'
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_DATOS_PROVISION_B]
	@numeroOrden nvarchar(max)
AS
BEGIN
	DECLARE @idCotizacionRefacciones int = 1, @idCotizacionManoObra int = 2, @idNA int =22
	
	DECLARE @referencia nvarchar(10), @idCatalogoTipoOrdenServicio int, @idTaller int, @idContratoOperacion int, @OTE_NUMSINIESTRO nvarchar(30),
			@OTE_NUMPOLIZA nvarchar(100), @OTE_IDCLIENTE nvarchar(100), @DESGLOSE nvarchar (100), @global int =0, @multimarca int=0
	
	SET NOCOUNT ON;

	BEGIN TRY
		DECLARE @tableManoObra as table (id [int] IDENTITY(1,1), numeroCotizacion nvarchar(100), numeroOrden nvarchar(100), idBproProveedor int
		        , numFactura nvarchar(100), costo numeric(18,2), cantidad int, rechazadas int, solicitadasOrg int, venta numeric(18,2), uuid nvarchar(100), idOrden int
				, idCotizacion int, xmlFactura nvarchar(max), descripcion nvarchar(max), claveProd nvarchar(100), claveUnidad nvarchar(100)
				, idCotizacionDetalle int, tipoProvision bit, fechaCambio nvarchar(20), ipServicios nvarchar(100), urlServices nvarchar(100)
				,ipBD nvarchar(100), db nvarchar(100), dbConcentra nvarchar(100), idTipoCotizacion int, estatus int, porcentajeNCR DECIMAL(18,2), idMarca int, proveedorExterno int)

		DECLARE @tableRefacciones as table (id [int] IDENTITY(1,1), numeroCotizacion nvarchar(100), numeroOrden nvarchar(100), idBproProveedor int
		        , numFactura nvarchar(100), costo numeric(18,2), cantidad int, rechazadas int, solicitadasOrg int, venta numeric(18,2), uuid nvarchar(100), idOrden int
				, idCotizacion int, xmlFactura nvarchar(max), descripcion nvarchar(max), claveProd nvarchar(100), claveUnidad nvarchar(100)
				, idCotizacionDetalle int, tipoProvision bit, fechaCambio nvarchar(20), ipServicios nvarchar(100), urlServices nvarchar(100)
				,ipBD nvarchar(100), db nvarchar(100), dbConcentra nvarchar(100), idTipoCotizacion int, estatus int, porcentajeNCR DECIMAL(18,2), idMarca int, proveedorExterno int)

		SELECT  @idTaller=O.idTaller, @idContratoOperacion=O.idContratoOperacion, @idCatalogoTipoOrdenServicio=O.idCatalogoTipoOrdenServicio
          , @OTE_NUMSINIESTRO = S.numeroReclamo, @OTE_NUMPOLIZA = S.numeroPoliza
		FROM Ordenes O 
		INNER JOIN [RefaccionMultiMarca].[Relacion].UnidadSiniestroOrden USO ON USO.orden = O.idOrden
		INNER JOIN [RefaccionMultiMarca].[Operacion].[Siniestro] S ON USO.idSiniestro = S.id	
		WHERE O.numeroOrden = @numeroOrden		

		declare @idContrato int 
		select @idContrato = idContrato from ASEPROT.dbo.ContratoOperacion where idContratoOperacion=@idContratoOperacion
		
		SELECT  @OTE_IDCLIENTE = idClienteBpro, @DESGLOSE = desglose
		    FROM ASEPROT.dbo.ContratoOperacionFacturacion 
		    WHERE idContratoOperacion =  @idContratoOperacion
		
		if (@idCatalogoTipoOrdenServicio = 10 or @idCatalogoTipoOrdenServicio =11)
		begin 
			select @global=CT.reparacionGlobal, @multimarca= (case when CT.idTipoCotizacion=2 then 1 else 0 end)  from RefaccionMultiMarca.Operacion.CotizacionTaller CT 
			inner join ASEPROT.dbo.Ordenes O on O.idOrden = CT.idOrden or O.idOrden = CT.idOrdenRefaccion
			where O.numeroOrden=@numeroOrden
		end

		select @referencia= 		
		case when @idCatalogoTipoOrdenServicio = 1 then Z.referencia
		     when @idCatalogoTipoOrdenServicio = 10 then case when (@global=1 or @multimarca=1) then Z.referenciaRefG else Z.referenciaRef end
	    else case when (@global=1 or @multimarca=1) then Z.referenciaMOG else Z.referenciaMO end end
		from Partidas.dbo.Proveedor P 
		inner join Partidas.dbo.ContratoProveedor CP on CP.idProveedor = P.idProveedor
		inner join Partidas.dbo.ContratoProveedorZona CPZ on CP.idContratoProveedor = CPZ.idContratoProveedor
		inner join Partidas.dbo.Zona Z on Z.idZona = CPZ.idZona
		where P.idProveedor=@idTaller and CP.idContrato=@idContrato

		insert into @tableManoObra
		select C.numeroCotizacion, O.numeroOrden, ISNULL(C.idBproProveedor,O.idBproProveedor) as idBproProveedor,  FC.numFactura, CD.costo
		      , CD.cantidad, CD.rechazadas, CD.solicitadasOrg, CD.venta, FC.uuid,O.idOrden, C.idCotizacion, cast(FC.xml as nvarchar(max)), P.descripcion, '', '', CD.idCotizacionDetalle
			  , CP.tipoProvision, CP.fechaCambio
			  , case when M.server='192.168.20.31' then 'http://189.204.141.193:4172' else 'http://189.204.141.193:4171' end
			  , case when M.server='192.168.20.31' then 'provision' else 'cotizaciones' end, M.server, M.dbNameConcentradora, M.dbCon_Car
			  , @idCotizacionManoObra
			  , case when RCS.idMarca is null or CP.tipoProvision=0 then 1 else 2 end
			  ,0, RCS.idMarca, case when RCS.idMarca = 8 or RCS.idMarca=9 then 1 else RCS.proveedorExterno end
		from Ordenes O 
		inner join Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
		inner join CotizacionDetalle CD on Cd.idCotizacion = C.idCotizacion
		inner join Partidas.dbo.Partida P on CD.idPartida = P.idPartida
		inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
		inner join RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden=O.idOrden and CT.idCotizacionMO=C.idCotizacion
		inner join Banorte.ConfiguracionProvision CP on CP.idSucursal = CT.idSucursal
		inner join RefaccionMultiMarca.Relacion.Configuracion_Sucursal RCS on RCS.idSucursal = CP.idSucursal		
		inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = CT.idMarca
		where O.numeroOrden=@numeroOrden and C.idTipoCotizacion = @idCotizacionManoObra and CD.cantidad>0
		
		--GROUP BY C.numeroCotizacion, O.numeroOrden, FC.numFactura, FC.uuid, O.idOrden, C.idCotizacion, FC.xml, CD.costo
		--,CD.cantidad, CD.venta, C.idBproProveedor,O.idBproProveedor, P.descripcion

		insert into @tableRefacciones
		select C.numeroCotizacion, O.numeroOrden, ISNULL(C.idBproProveedor,O.idBproProveedor) as idBproProveedor,  FC.numFactura, CD.costo
		      , CD.cantidad, CD.rechazadas, CD.solicitadasOrg, CD.venta, FC.uuid,O.idOrden, C.idCotizacion, cast(FC.xml as nvarchar(max)), P.descripcion, '', '', CD.idCotizacionDetalle
			  , CP.tipoProvision, CP.fechaCambio
			  , case when M.server='192.168.20.31' then 'http://189.204.141.193:4172' else 'http://189.204.141.193:4171' end
			  , case when M.server='192.168.20.31' then 'provision' else 'cotizaciones' end, M.server, M.dbNameConcentradora, M.dbCon_Car
			, @idCotizacionRefacciones
			, case when RCS.idMarca is null or CP.tipoProvision=0 then 1 else 2 end
			,(SELECT ASEPROT.[dbo].[SEL_VALNCR_FN](O.idCatalogoTipoOrdenServicio, @OTE_NUMSINIESTRO, SOC.idCotizacion, M.idMarca))
			, RCS.idMarca, case when RCS.idMarca = 8 or RCS.idMarca=9 then 1 else RCS.proveedorExterno end
		from Ordenes O 
		inner join Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
		inner join CotizacionDetalle CD on Cd.idCotizacion = C.idCotizacion
		inner join Partidas.dbo.Partida P on CD.idPartida = P.idPartida
		inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
		inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden=O.idOrden and SOC.idCotizacionSISCO=C.idCotizacion
		inner join RefaccionMultiMarca.Operacion.Cotizacion RC on RC.idCotizacion = SOC.idCotizacion
		inner join Banorte.ConfiguracionProvision CP on CP.idSucursal = RC.idSucursal
		inner join RefaccionMultiMarca.Relacion.Configuracion_Sucursal RCS on RCS.idSucursal = RC.idSucursal
		inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro		
		inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
		inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = U.marca
		where O.numeroOrden=@numeroOrden and C.idCotizacion not in (select idCotizacion from @tableManoObra) and CD.cantidad>0
		--GROUP BY C.numeroCotizacion, O.numeroOrden, C.idBproProveedor, FC.numFactura, FC.uuid, O.idOrden, C.idCotizacion, FC.xml, CD.costo
		--,CD.cantidad, CD.venta, O.idBproProveedor, P.descripcion

		Declare @id int, @count int
		Set @id=1
		select @count=count(*)from @tableManoObra

		DECLARE @xmlProveedor xml, @idCotizacion int

		DECLARE  @tempClaveSat as table (ClaveProdServ nchar(30), Descripcion varchar(max), Cantidad numeric(18,2), ValorUnitario numeric(18,2),
								 Importe NUMERIC(18,2), ClaveUnidad varchar(50))

		while @id<=@count
		begin 
			delete from @tempClaveSat
			SET @idCotizacion=0
			if ((select claveProd from @tableManoObra where id=@id ) ='' and (select claveUnidad from @tableManoObra where id=@id) = '')
			begin 
				select @idCotizacion=idCotizacion from @tableManoObra where id=@id
				SET @xmlProveedor = (SELECT REPLACE(REPLACE(REPLACE(xmlFactura, 'ÿ', ''), 'cfdi:', ''), '<?xml version="1.0" encoding="UTF-8"?>', '')
			                     FROM @tableManoObra where id=@id)
			
				INSERT INTO @tempClaveSat (ClaveProdServ, Descripcion, Cantidad, ValorUnitario, Importe, ClaveUnidad)
					SELECT ClaveProdServ    = T.Item.value('@ClaveProdServ', 'nchar(20)'),
				       Descripcion		 = T.Item.value('@Descripcion', 'varchar(max)'),
					   Cantidad		 = T.Item.value('@Cantidad', 'numeric(18,2)'),
					   ValorUnitario	 = T.Item.value('@ValorUnitario', 'numeric(18,2)'),
					   Importe			 = T.Item.value('@Importe', 'numeric(18,2)'),
					   ClaveUnidad      = T.Item.value('@ClaveUnidad', 'varchar(50)')
					FROM   @xmlProveedor.nodes(' Comprobante/Conceptos/Concepto') AS T(Item)

				UPDATE @tableManoObra SET claveProd = TEMP.ClaveProdServ, claveUnidad = TEMP.ClaveUnidad FROM @tableManoObra AS TMO
				INNER JOIN @tempClaveSat AS TEMP ON (TEMP.Cantidad = TMO.cantidad AND (TEMP.ValorUnitario - .10) <= TMO.costo 
													AND (TEMP.ValorUnitario + .10) >= TMO.costo) 
				WHERE TMO.idCotizacion=@idCotizacion
			end 			
			
			select @id=@id+1
		end

		Set @id=1
		select @count=count(*)from @tableRefacciones
		while @id<=@count
		begin 
			delete from @tempClaveSat
			SET @idCotizacion=0
			if ((select claveProd from @tableRefacciones where id=@id ) ='' and (select claveUnidad from @tableRefacciones where id=@id  ) = '')
			begin 			
				select @idCotizacion=idCotizacion from @tableRefacciones where id=@id
				SET @xmlProveedor = (SELECT REPLACE(REPLACE(REPLACE(xmlFactura, 'ÿ', ''), 'cfdi:', ''), '<?xml version="1.0" encoding="UTF-8"?>', '')
			                     FROM @tableRefacciones where id=@id)
			
				INSERT INTO @tempClaveSat (ClaveProdServ, Descripcion, Cantidad, ValorUnitario, Importe, ClaveUnidad)
					SELECT ClaveProdServ    = T.Item.value('@ClaveProdServ', 'nchar(20)'),
				       Descripcion		 = T.Item.value('@Descripcion', 'varchar(max)'),
					   Cantidad		 = T.Item.value('@Cantidad', 'numeric(18,2)'),
					   ValorUnitario	 = T.Item.value('@ValorUnitario', 'numeric(18,2)'),
					   Importe			 = T.Item.value('@Importe', 'numeric(18,2)'),
					   ClaveUnidad      = T.Item.value('@ClaveUnidad', 'varchar(50)')
					FROM   @xmlProveedor.nodes(' Comprobante/Conceptos/Concepto') AS T(Item)
				
				UPDATE @tableRefacciones SET claveProd = TEMP.ClaveProdServ, claveUnidad = TEMP.ClaveUnidad FROM @tableRefacciones AS TMO
				INNER JOIN @tempClaveSat AS TEMP ON (TEMP.Cantidad = TMO.cantidad AND (TEMP.ValorUnitario - .10) <= TMO.costo 
													AND (TEMP.ValorUnitario + .10) >= TMO.costo) 
				WHERE TMO.idCotizacion=@idCotizacion
			end 			
			select @id=@id+1
		end

		if (@global=1 or @multimarca=1)
		begin 
			insert into @tableRefacciones
			select numeroCotizacion, numeroOrden, max(idBproProveedor), max(numFactura), SUM(costo*cantidad), 1, max(rechazadas), 1, SUM(venta*cantidad)
				   , max(uuid), idOrden, idCotizacion, max(xmlFactura), 'Refacciones', max(claveProd), max(claveUnidad), max(idCotizacionDetalle)
				   ,tipoProvision, max(fechaCambio), max(ipServicios), max(urlServices), max(ipBD), max(db), max(dbConcentra), 
				   max(idTipoCotizacion), max(estatus), max(porcentajeNCR), max(idMarca), max(proveedorExterno)
			from @tableRefacciones	where descripcion <> 'Mano de Obra'
			group by numeroCotizacion, numeroOrden, idOrden, idCotizacion, tipoProvision

			delete from @tableRefacciones where descripcion not in ('Refacciones','Mano de Obra')			
			if (@multimarca=1)
				update @tableRefacciones set descripcion = (case when @global=1 then 'Reparación Global' else 'Reparación Integral' end) where descripcion='Mano de Obra'
		end

		select @numeroOrden as numeroOrden, @referencia as referencia, @idCatalogoTipoOrdenServicio as idCatalogoTipoOrdenServicio, 
		       @OTE_NUMSINIESTRO as numSiniestro, @OTE_NUMPOLIZA as numPoliza, @OTE_IDCLIENTE as idCliente, @DESGLOSE as desglose

		select numeroCotizacion, numeroOrden, idBproProveedor, numFactura, costo, cantidad, rechazadas, solicitadasOrg, venta, uuid, idOrden, idCotizacion
		      , descripcion, claveProd, claveUnidad, idCotizacionDetalle, tipoProvision, fechaCambio, ipServicios, urlServices
			  , ipBD, db, dbConcentra, idTipoCotizacion, case when idMarca=@idNA then 2 else estatus end estatus, porcentajeNCR, proveedorExterno, 
			  case when proveedorExterno =1 then @referencia else NULL end referencia,
			  case when (@global=1 or @multimarca=1) then 1 else 0 end ordenGlobal
			  from @tableManoObra
		union
		select numeroCotizacion, tR.numeroOrden, tR.idBproProveedor, numFactura, costo, cantidad, rechazadas, solicitadasOrg, venta, uuid, tR.idOrden, idCotizacion
		      ,descripcion, claveProd, claveUnidad, idCotizacionDetalle, tipoProvision, fechaCambio, ipServicios, urlServices
			  , ipBD, db, dbConcentra, idTipoCotizacion, case when idMarca=@idNA then 2 else tR.estatus end estatus, porcentajeNCR, proveedorExterno, 
			  case when (@global=1 or @multimarca=1) then (case when tR.descripcion ='Refacciones' then Z.referenciaRefG else Z.referenciaMOG end) 
			       when proveedorExterno =1 then @referencia
			  else NULL end as referencia,
			  case when (@global=1 or @multimarca=1) then 1 else 0 end ordenGlobal
		from @tableRefacciones tR
		inner join ordenes O on tR.idOrden=O.idOrden
		inner join Partidas.dbo.Zona Z on Z.idZona = O.idZona
	END TRY
	BEGIN CATCH		
		SELECT ERROR_NUMBER() AS Number,
		       ERROR_SEVERITY() AS Severity,
			   ERROR_STATE() AS [State],
			   ERROR_PROCEDURE() AS [Procedure],
			   ERROR_LINE() AS Line,
			   ERROR_MESSAGE() AS [Message]
	END CATCH

SET NOCOUNT OFF;
END

--USE [ASEPROT]
--GO
--/****** Object:  StoredProcedure [Banorte].[SEL_DATOS_PROVISION_B]    Script Date: 07/02/2019 01:05:07 p. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
---- =============================================
---- Author:		<YJH>
---- Create date: <02/01/2019>
---- Description:	<Obtiene datos para insertar la provisión en Bpro>'
---- [Banorte].[SEL_DATOS_PROVISION_B] '26-22399-1058'
---- =============================================
--ALTER PROCEDURE [Banorte].[SEL_DATOS_PROVISION_B]
--	@numeroOrden nvarchar(max)
--AS
--BEGIN
--	DECLARE @idCotizacionRefacciones int = 1, @idCotizacionManoObra int = 2
	
--	DECLARE @referencia nvarchar(10), @idCatalogoTipoOrdenServicio int, @idTaller int, @idContratoOperacion int, @OTE_NUMSINIESTRO nvarchar(30),
--			@OTE_NUMPOLIZA nvarchar(100), @OTE_IDCLIENTE nvarchar(100), @DESGLOSE nvarchar (100)	
	
--	SET NOCOUNT ON;

--	BEGIN TRY
--		DECLARE @tableManoObra as table (id [int] IDENTITY(1,1), numeroCotizacion nvarchar(100), numeroOrden nvarchar(100), idBproProveedor int
--		        , numFactura nvarchar(100), costo numeric(18,2), cantidad int, venta numeric(18,2), uuid nvarchar(100), idOrden int
--				, idCotizacion int, xmlFactura nvarchar(max), descripcion nvarchar(max), claveProd nvarchar(100), claveUnidad nvarchar(100)
--				, idCotizacionDetalle int, tipoProvision bit, fechaCambio nvarchar(20), ipServicios nvarchar(100), urlServices nvarchar(100)
--				,ipBD nvarchar(100), db nvarchar(100), dbConcentra nvarchar(100), idTipoCotizacion int, estatus int)

--		DECLARE @tableRefacciones as table (id [int] IDENTITY(1,1), numeroCotizacion nvarchar(100), numeroOrden nvarchar(100), idBproProveedor int
--		        , numFactura nvarchar(100), costo numeric(18,2), cantidad int, venta numeric(18,2), uuid nvarchar(100), idOrden int
--				, idCotizacion int, xmlFactura nvarchar(max), descripcion nvarchar(max), claveProd nvarchar(100), claveUnidad nvarchar(100)
--				, idCotizacionDetalle int, tipoProvision bit, fechaCambio nvarchar(20), ipServicios nvarchar(100), urlServices nvarchar(100)
--				,ipBD nvarchar(100), db nvarchar(100), dbConcentra nvarchar(100), idTipoCotizacion int, estatus int)

--		SELECT  @idTaller=O.idTaller, @idContratoOperacion=O.idContratoOperacion, @idCatalogoTipoOrdenServicio=O.idCatalogoTipoOrdenServicio
--          , @OTE_NUMSINIESTRO = S.numeroReclamo, @OTE_NUMPOLIZA = S.numeroPoliza 
--		FROM Ordenes O 
--		INNER JOIN [RefaccionMultiMarca].[Relacion].[SiniestroOrdenCotizacion] SOC ON SOC.idOrden = O.idOrden
--		INNER JOIN [RefaccionMultiMarca].[Operacion].[Siniestro] S ON SOC.idSiniestro = S.id	
--		WHERE O.numeroOrden = @numeroOrden		

--		declare @idContrato int 
--		select @idContrato = idContrato from ASEPROT.dbo.ContratoOperacion where idContratoOperacion=@idContratoOperacion

--		select @referencia=Z.referencia from Partidas.dbo.Proveedor P 
--		inner join Partidas.dbo.ContratoProveedor CP on CP.idProveedor = P.idProveedor
--		inner join Partidas.dbo.ContratoProveedorZona CPZ on CP.idContratoProveedor = CPZ.idContratoProveedor
--		inner join Partidas.dbo.Zona Z on Z.idZona = CPZ.idZona
--		where P.idProveedor=@idTaller and CP.idContrato=@idContrato
		
		
--		SELECT  @OTE_IDCLIENTE = idClienteBpro, @DESGLOSE = desglose
--		    FROM ASEPROT.dbo.ContratoOperacionFacturacion 
--		    WHERE idContratoOperacion =  @idContratoOperacion
		
--		insert into @tableManoObra
--		select C.numeroCotizacion, O.numeroOrden, ISNULL(C.idBproProveedor,O.idBproProveedor) as idBproProveedor,  FC.numFactura, CD.costo
--		      , CD.cantidad, CD.venta, FC.uuid,O.idOrden, C.idCotizacion, cast(FC.xml as nvarchar(max)), P.descripcion, '', '', CD.idCotizacionDetalle
--			  , CP.tipoProvision, CP.fechaCambio
--			  , case when M.server='192.168.20.31' then 'http://189.204.141.193:4172' else 'http://189.204.141.193:4171' end
--			  , case when M.server='192.168.20.31' then 'provision' else 'cotizaciones' end, M.server, M.dbNameConcentradora, M.dbCon_Car
--			  , @idCotizacionManoObra
--			  , case when RCS.idMarca is null or CP.tipoProvision=0 then 1 else 2 end
--		from Ordenes O 
--		inner join Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
--		inner join CotizacionDetalle CD on Cd.idCotizacion = C.idCotizacion
--		inner join Partidas.dbo.Partida P on CD.idPartida = P.idPartida
--		inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
--		inner join RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden=O.idOrden and CT.idCotizacionMO=C.idCotizacion
--		inner join Banorte.ConfiguracionProvision CP on CP.idSucursal = CT.idSucursal
--		inner join RefaccionMultiMarca.Relacion.Configuracion_Sucursal RCS on RCS.idSucursal = CP.idSucursal		
--		inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = CT.idMarca
--		where O.numeroOrden=@numeroOrden and C.idTipoCotizacion = @idCotizacionManoObra
		
--		--GROUP BY C.numeroCotizacion, O.numeroOrden, FC.numFactura, FC.uuid, O.idOrden, C.idCotizacion, FC.xml, CD.costo
--		--,CD.cantidad, CD.venta, C.idBproProveedor,O.idBproProveedor, P.descripcion

--		insert into @tableRefacciones
--		select C.numeroCotizacion, O.numeroOrden, ISNULL(C.idBproProveedor,O.idBproProveedor) as idBproProveedor,  FC.numFactura, CD.costo
--		      , CD.cantidad, CD.venta, FC.uuid,O.idOrden, C.idCotizacion, cast(FC.xml as nvarchar(max)), P.descripcion, '', '', CD.idCotizacionDetalle
--			  , CP.tipoProvision, CP.fechaCambio
--			  , case when M.server='192.168.20.31' then 'http://189.204.141.193:4172' else 'http://189.204.141.193:4171' end
--			  , case when M.server='192.168.20.31' then 'provision' else 'cotizaciones' end, M.server, M.dbNameConcentradora, M.dbCon_Car
--			, @idCotizacionRefacciones
--			, case when RCS.idMarca is null or CP.tipoProvision=0 then 1 else 2 end
--		from Ordenes O 
--		inner join Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
--		inner join CotizacionDetalle CD on Cd.idCotizacion = C.idCotizacion
--		inner join Partidas.dbo.Partida P on CD.idPartida = P.idPartida
--		inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
--		inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden=O.idOrden and SOC.idCotizacionSISCO=C.idCotizacion
--		inner join RefaccionMultiMarca.Operacion.Cotizacion RC on RC.idCotizacion = SOC.idCotizacion
--		inner join Banorte.ConfiguracionProvision CP on CP.idSucursal = RC.idSucursal
--		inner join RefaccionMultiMarca.Relacion.Configuracion_Sucursal RCS on RCS.idSucursal = RC.idSucursal
--		inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro		
--		inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
--		inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = U.marca
--		where O.numeroOrden=@numeroOrden and C.idCotizacion not in (select idCotizacion from @tableManoObra)
--		--GROUP BY C.numeroCotizacion, O.numeroOrden, C.idBproProveedor, FC.numFactura, FC.uuid, O.idOrden, C.idCotizacion, FC.xml, CD.costo
--		--,CD.cantidad, CD.venta, O.idBproProveedor, P.descripcion
		
--		Declare @id int, @count int
--		Set @id=1
--		select @count=count(*)from @tableManoObra

--		DECLARE @xmlProveedor xml, @idCotizacion int

--		DECLARE  @tempClaveSat as table (ClaveProdServ nchar(30), Descripcion varchar(max), Cantidad numeric(18,2), ValorUnitario numeric(18,2),
--								 Importe NUMERIC(18,2), ClaveUnidad varchar(50))

--		while @id<=@count
--		begin 
--			delete from @tempClaveSat
--			SET @idCotizacion=0
--			if ((select claveProd from @tableManoObra where id=@id ) ='' and (select claveUnidad from @tableManoObra where id=@id) = '')
--			begin 
--				select @idCotizacion=idCotizacion from @tableManoObra where id=@id
--				SET @xmlProveedor = (SELECT REPLACE(REPLACE(REPLACE(xmlFactura, 'ÿ', ''), 'cfdi:', ''), '<?xml version="1.0" encoding="UTF-8"?>', '')
--			                     FROM @tableManoObra where id=@id)
			
--				INSERT INTO @tempClaveSat (ClaveProdServ, Descripcion, Cantidad, ValorUnitario, Importe, ClaveUnidad)
--					SELECT ClaveProdServ    = T.Item.value('@ClaveProdServ', 'nchar(20)'),
--				       Descripcion		 = T.Item.value('@Descripcion', 'varchar(max)'),
--					   Cantidad		 = T.Item.value('@Cantidad', 'numeric(18,2)'),
--					   ValorUnitario	 = T.Item.value('@ValorUnitario', 'numeric(18,2)'),
--					   Importe			 = T.Item.value('@Importe', 'numeric(18,2)'),
--					   ClaveUnidad      = T.Item.value('@ClaveUnidad', 'varchar(50)')
--					FROM   @xmlProveedor.nodes(' Comprobante/Conceptos/Concepto') AS T(Item)

--				UPDATE @tableManoObra SET claveProd = TEMP.ClaveProdServ, claveUnidad = TEMP.ClaveUnidad FROM @tableManoObra AS TMO
--				INNER JOIN @tempClaveSat AS TEMP ON (TEMP.Cantidad = TMO.cantidad AND (TEMP.ValorUnitario - .10) <= TMO.costo 
--													AND (TEMP.ValorUnitario + .10) >= TMO.costo) 
--				WHERE TMO.idCotizacion=@idCotizacion
--			end 			
			
--			select @id=@id+1
--		end

--		Set @id=1
--		select @count=count(*)from @tableRefacciones
--		while @id<=@count
--		begin 
--			delete from @tempClaveSat
--			SET @idCotizacion=0
--			if ((select claveProd from @tableRefacciones where id=@id ) ='' and (select claveUnidad from @tableRefacciones where id=@id  ) = '')
--			begin 			
--				select @idCotizacion=idCotizacion from @tableRefacciones where id=@id
--				SET @xmlProveedor = (SELECT REPLACE(REPLACE(REPLACE(xmlFactura, 'ÿ', ''), 'cfdi:', ''), '<?xml version="1.0" encoding="UTF-8"?>', '')
--			                     FROM @tableRefacciones where id=@id)
			
--				INSERT INTO @tempClaveSat (ClaveProdServ, Descripcion, Cantidad, ValorUnitario, Importe, ClaveUnidad)
--					SELECT ClaveProdServ    = T.Item.value('@ClaveProdServ', 'nchar(20)'),
--				       Descripcion		 = T.Item.value('@Descripcion', 'varchar(max)'),
--					   Cantidad		 = T.Item.value('@Cantidad', 'numeric(18,2)'),
--					   ValorUnitario	 = T.Item.value('@ValorUnitario', 'numeric(18,2)'),
--					   Importe			 = T.Item.value('@Importe', 'numeric(18,2)'),
--					   ClaveUnidad      = T.Item.value('@ClaveUnidad', 'varchar(50)')
--					FROM   @xmlProveedor.nodes(' Comprobante/Conceptos/Concepto') AS T(Item)
				
--				UPDATE @tableRefacciones SET claveProd = TEMP.ClaveProdServ, claveUnidad = TEMP.ClaveUnidad FROM @tableRefacciones AS TMO
--				INNER JOIN @tempClaveSat AS TEMP ON (TEMP.Cantidad = TMO.cantidad AND (TEMP.ValorUnitario - .10) <= TMO.costo 
--													AND (TEMP.ValorUnitario + .10) >= TMO.costo) 
--				WHERE TMO.idCotizacion=@idCotizacion
--			end 			
--			select @id=@id+1
--		end

--		select @numeroOrden as numeroOrden, @referencia as referencia, @idCatalogoTipoOrdenServicio as idCatalogoTipoOrdenServicio, 
--		       @OTE_NUMSINIESTRO as numSiniestro, @OTE_NUMPOLIZA as numPoliza, @OTE_IDCLIENTE as idCliente, @DESGLOSE as desglose

--		select numeroCotizacion, numeroOrden, idBproProveedor, numFactura, costo, cantidad, venta, uuid, idOrden, idCotizacion
--		      , descripcion, claveProd, claveUnidad, idCotizacionDetalle, tipoProvision, fechaCambio, ipServicios, urlServices
--			  , ipBD, db, dbConcentra, idTipoCotizacion, estatus from @tableManoObra
--		union
--		select numeroCotizacion, numeroOrden, idBproProveedor, numFactura, costo, cantidad, venta, uuid, idOrden, idCotizacion
--		      ,descripcion, claveProd, claveUnidad, idCotizacionDetalle, tipoProvision, fechaCambio, ipServicios, urlServices
--			  , ipBD, db, dbConcentra, idTipoCotizacion, estatus from @tableRefacciones
--	END TRY
--	BEGIN CATCH		
--		SELECT ERROR_NUMBER() AS Number,
--		       ERROR_SEVERITY() AS Severity,
--			   ERROR_STATE() AS [State],
--			   ERROR_PROCEDURE() AS [Procedure],
--			   ERROR_LINE() AS Line,
--			   ERROR_MESSAGE() AS [Message]
--	END CATCH

--SET NOCOUNT OFF;
--END

go

grant execute, view definition on Banorte.SEL_DATOS_PROVISION_B to DevOps
go

