-- =============================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 30/05/2017
-- [SEL_VALIDA_LOGIN_SP] 'CCDEMO', '12345'
--GO
-- [SEL_VALIDA_LOGIN_SP] 'LUIS.ADMIN', 'TENAVARO'

-- modificado por Lisandro Martínez 
-- modificación: unicamente se valida el usuario ya que la validaciopn completa pasa por el modulo de seguridad
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDA_LOGIN_SP] 
	@login varchar(50),
	@pass varchar(MAX) 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @id numeric(18,0) = (SELECT idUsuario FROM Usuarios WHERE nombreUsuario = @login)
	DECLARE @sesionesActivas int = 0

	IF (@id is not null)		
		BEGIN
			--PRINT 'EL USUARIO EXISTE'
			DECLARE @TieneHistorial int = (Select count([idHistorialLogin]) 
											FROM [dbo].[HistorialLogin] AS HL
											WHERE HL.idUsuario = @id)

			IF (@TieneHistorial > 0)
				BEGIN
					--PRINT 'EL USUARIO SE HA LOGUEADO ANTES '
					SET @sesionesActivas = (SELECT count([idHistorialLogin])
							FROM [dbo].[HistorialLogin] as HL 
							INNER JOIN [dbo].[Usuarios] AS US ON US.idUsuario = HL.idUsuario
							WHERE US.[idUsuario] = @id and [FechaFin] IS NULL)
				END
			ELSE
				BEGIN
					PRINT 'ES PRIMER LOGIN DEL USUARIO Y SUS SESIONES ACTIVAS SON: ' + CONVERT(VARCHAR(MAX),@sesionesActivas)
				END
			
		END
	--ELSE
	--	BEGIN
	--		PRINT 'EL USUARIO NO EXISTE'
	--	END
	
	
	IF (@sesionesActivas > 0)
			BEGIN
				SELECT 'True' AS HasSession , @id as idUsuario
			END
		ELSE 
			BEGIN

				
				declare @DBname varchar(max) = (SELECT DB_NAME() AS [Current Database])
				declare @isProduction int
				
				if (@DBname = 'ASEPROT' OR @DBname = 'ASEPROTSISCO')
					begin						
						set @isProduction = 1
					end 
				else
					begin
						set @isProduction = 0
					end
				
				SELECT [Usuarios].[idUsuario]
						,[nombreCompleto] 
						,ISNULL([correoElectronico],'') AS Correo
						,ISNULL([telefonoUsuario],'') AS Telefono
						,ISNULL([extensionUsuario],'') AS Extension
						,@isProduction AS isProduction
						,'False' AS HasSession
						,ISNULL([empresa], '') as Empresa 
					FROM [dbo].[Usuarios]
					WHERE [nombreUsuario] = @login 				

			END
END
go

