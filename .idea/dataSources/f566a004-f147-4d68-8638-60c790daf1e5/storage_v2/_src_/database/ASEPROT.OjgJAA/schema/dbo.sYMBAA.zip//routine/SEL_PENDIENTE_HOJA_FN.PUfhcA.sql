CREATE FUNCTION [dbo].[SEL_PENDIENTE_HOJA_FN](@idCentroTrabajo NUMERIC(18,0))
RETURNS NUMERIC(18,0)
AS
BEGIN
DECLARE @Result NUMERIC(18,0)
SET @Result=
		(SELECT COUNT(O.idOrden)
		FROM Ordenes O
		JOIN CentroTrabajos CT ON CT.idCentroTrabajo = O.idCentroTrabajo
		WHERE O.idEstatusOrden = 5 AND CT.idCentroTrabajo = @idCentroTrabajo AND O.idOrden not in (select idOrden from OrdenesPresupuestoEspecial))
	-------------------------------------REGRESAMOS EL VALOR -----------------------------------------------
	RETURN @Result;
	
END
go

