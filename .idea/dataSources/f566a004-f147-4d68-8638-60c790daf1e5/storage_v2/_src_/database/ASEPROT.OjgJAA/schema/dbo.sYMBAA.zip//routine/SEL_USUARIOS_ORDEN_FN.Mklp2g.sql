-- =============================================
-- Author:		JJSY
-- Create date: 16 09 2018
-- SELECT [dbo].[SEL_USUARIOS_ORDEN_FN](11199)
-- FUNCION DEVULVE LOS IDS DE USURIOS POR ORDEN
-- =============================================
-- 
CREATE FUNCTION [dbo].[SEL_USUARIOS_ORDEN_FN](@idOrden INT)

RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @usuarios NVARCHAR(MAX) = '';
	DECLARE @idusuarios NVARCHAR(MAX) = '';
	DECLARE @Result NVARCHAR(MAX) = '';

	DECLARE contact_cursor CURSOR FOR

	SELECT distinct
				U.idUsuario
			
				FROM ContratoOperacion CO
				LEFT JOIN ContratoOperacionFacturacion COF ON CO.idContratoOperacion = COF.idContratoOperacion
				LEFT JOIN ContratoOperacionUsuario cou on cou.idContratoOperacion = CO.idContratoOperacion
				LEFT join ContratoOperacionUsuarioZona couz on couz.idContratoOperacionUsuario = cou.idContratoOperacionUsuario

				inner join Usuarios u on u.idUsuario = cou.idUsuario
				inner join Partidas..Zona pz on pz.idZona = couz.idZona
				left join Partidas..Zona pzpadre on pz.idPadre = pzpadre.idZona
				inner join Ordenes O on O.idZona = pz.idZona

				--INNER JOIN ContratoOperacionUsuario COU ON U.idUsuario=COU.idUsuario
				--INNER JOIN ContratoOperacionUsuarioZona COUZ ON COU.idContratoOperacionUsuario = COUZ.idContratoOperacionUsuarioZona
				--INNER JOIN Ordenes O ON COUZ.idZona = O.idZona
				WHERE O.idOrden= @idOrden  --O.idEstatusOrden in (1,4,5,6,7,8)  

	OPEN contact_cursor  
	FETCH NEXT FROM contact_cursor INTO @usuarios
	WHILE @@FETCH_STATUS = 0  
		BEGIN 

		--SET @talleres =(SELECT idTaller FROM Taller where idTaller=@idTaller)
		SET @idusuarios =  @idusuarios + @usuarios +    ','

		FETCH NEXT FROM contact_cursor INTO @usuarios
		END  
	CLOSE contact_cursor  
	DEALLOCATE contact_cursor

	IF((@idusuarios IS NOT NULL) AND @idusuarios != '')
		SET @Result= SUBSTRING (@idusuarios, 1, Len(@idusuarios) - 1 )

	RETURN @Result;
	
END
go

