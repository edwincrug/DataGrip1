--[Banorte].[UPD_COBRANZA_REFACCIONES_SP] 40303, 677, 0, 18
CREATE PROCEDURE [Banorte].[UPD_COBRANZA_REFACCIONES_SP] 
	@idOrden NUMERIC(18,0), 		
	@idUsuario  NUMERIC(18,0), 
	@isProduction int=0, 
	@idContratoOperacion int	
AS
BEGIN
	DECLARE @estatusOrden INT =8
	declare @hasFactura numeric
	declare @hasValeI numeric
	declare @hasValeF numeric
	declare @hasDocumentos numeric
	declare @Entregado numeric
	declare @idTipoOrden int 
	declare @tipoOrdenMixta int =10
	declare @idEstatusCobranza int = 8
	declare @idEstatusOrden int

	declare @estatusDocumentos int =0

	select @idTipoOrden=idCatalogoTipoOrdenServicio, @idEstatusOrden= idEstatusOrden from Ordenes where idOrden=@idOrden

	IF (@idTipoOrden=@tipoOrdenMixta)
	begin 
		EXECUTE [Banorte].[SEL_ESTATUS_AVANCE_MIXTA_FN] @idOrden, @hasFactura output, @hasDocumentos output

		IF (@hasFactura=1 and @hasDocumentos=1)
			select @estatusDocumentos=1
		else 
			select @estatusDocumentos=0
	end 
	else 
	begin 
		EXECUTE [Banorte].[SEL_ESTATUS_AVANCE_FN] @idOrden, @isProduction, @idContratoOperacion, @hasFactura output, @hasValeI output, @hasValeF output
		IF (@hasFactura=1 and @hasValeI>0 and @hasValeF>0 )
			select @estatusDocumentos=1
		else 
			select @estatusDocumentos=0

	end 
	
	EXECUTE [Banorte].[ObtenerStatusDespacho_FN] @idOrden, @Entregado output

	--SELECT @hasFactura as hasFactura,  @hasValeI as valeInicial, @hasValeF as valeFinal

	IF (@estatusDocumentos=1 and @Entregado=1)
	BEGIN	
		IF (@idEstatusOrden <> @idEstatusCobranza)
		BEGIN			
			UPDATE Ordenes SET idEstatusOrden=@idEstatusCobranza WHERE idOrden=@idOrden

			declare @id int =@idEstatusOrden
	
			while (@id <= @idEstatusCobranza)
			begin 
				INSERT INTO [HistorialEstatusOrden] (idOrden, idEstatusOrden, fechaInicial, fechaFinal, idUsuario)
					VALUES (@idOrden, @id,GETDATE(), GETDATE(), @idUsuario)
				
				select @id = @id+1
			end

			select 1 as Estatus, 'Se actualizó la orden correctamente' as descripcion
		END	
		ELSE 
		BEGIN 
			SELECT 0 as Estatus, 'La orden ya se encuentra en cobranza' as descripcion
		END 			
	END
	ELSE
	BEGIN
		select 0 as Estatus, 'Falta evidencia o no se han entregado pedidos' as descripcion
	END
			
END



go

grant execute, view definition on Banorte.UPD_COBRANZA_REFACCIONES_SP to DevOps
go

