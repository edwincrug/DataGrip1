-- =============================================
-- Author:		Sahirely Yam
-- Create date: 16 10 2017
-- =============================================
CREATE PROCEDURE [dbo].[EX_DEL_FACTURA_COTIZACION_SP]
	@numeroCotizacion varchar(50)
AS
BEGIN
		
	declare @idCotizacion numeric(18,0) = 0, @idOrden numeric(18,0) = 0, @consecutivo int = 0

	select @idCotizacion = idCotizacion, @idOrden = idOrden, @consecutivo = consecutivoCotizacion from Cotizaciones C
	where numeroCotizacion = @numeroCotizacion

	if (@idCotizacion is not null and @idCotizacion != 0 and @idOrden is not null and @idOrden != 0 and @consecutivo is not null and @consecutivo != 0)
		begin
			print 'se eliminarán las facturas'
			delete from facturaCotizacion where idCotizacion = @idCotizacion

			delete from DocumentosOrdenes where idOrden = @idOrden and idCatalogoDocumento = 3 and idCotizacion = @consecutivo
		end
	else
		begin
			print 'no se encontró la cotización con el número '+ @numeroCotizacion
		end
END
go

