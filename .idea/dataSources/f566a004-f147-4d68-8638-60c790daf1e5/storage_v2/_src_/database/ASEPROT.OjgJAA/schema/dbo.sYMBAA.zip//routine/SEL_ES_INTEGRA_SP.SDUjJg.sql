-- =============================================
-- Author:		Jose Armando Garcia Arroyo
-- Create date: 20 11 2019
-- [SEL_ES_INTEGRA_SP] 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ES_INTEGRA_SP]
@idOperacion INT
AS
BEGIN

SET NOCOUNT ON;

IF @idOperacion IN(41)
BEGIN
SELECT 1 AS esIntegra
END
ELSE
BEGIN
SELECT 0 AS esIntegra
END

END
go

