-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--SEL_ZONA_SP '1'
CREATE PROCEDURE [dbo].[SEL_ZONA_SP]
	-- Add the parameters for the stored procedure here
	@idOperacion	numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--
	DECLARE @idClientePartidas numeric(18,0)
		
	SELECT 
		@idClientePartidas = L.idCliente
	FROM ContratoOperacion CO
	inner join Partidas.dbo.Contrato C on C.idContrato = CO.idContrato
	inner join Partidas.dbo.Licitacion L on C.idLicitacion=L.idLicitacion
   where 
	CO.idOperacion = @idOperacion

	execute Partidas.dbo.SEL_ZONA_SP '1',@idClientePartidas
	
END
go

