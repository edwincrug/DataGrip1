-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>[SEL_COTIZACION_ABONADOS_SELECT_GAAutoExpress_SP] 518,3,1
-- TEST Proveedor   [SEL_COTIZACION_ABONADOS_SELECT_GAAutoExpress_SP] 107,3,1
-- TEST Proveedor   [SEL_COTIZACION_ABONADOS_SELECT_GAAutoExpress_SP] 407,3,1
-- TEST DICONSA   [SEL_COTIZACION_ABONADOS_SELECT_GAAutoExpress_SP] 518,1,1  --- aqui no 
-- TEST PEMEX   [SEL_COTIZACION_ABONADOS_SELECT_GAAutoExpress_SP] 509,3,1 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_COTIZACION_ABONADOS_SELECT_GAAutoExpress_SP] --9
 (
	@idUsuario numeric(18,0),
	@idContratoOperacion numeric(18,0),
	@isProduction numeric(18,0),	
	@idZona int = null,
	@idEjecutivoFiltro INT = null,
	@fechaIni varchar(max) = null,--'2017/09/01 00:00:00',
	@fechaFin varchar(max) = null--'2017/09/30 23:59:59'
)
	
AS
BEGIN
	DECLARE @isProveedor NUMERIC(18,0)
	DECLARE @select NVARCHAR(MAX) = ''
	DECLARE	@join	NVARCHAR(MAX) = ''
	DECLARE	@and  NVARCHAR(MAX) = ''
	DECLARE	@order  NVARCHAR(MAX) = ''	
	DECLARE	@where  NVARCHAR(MAX) = ''
	DECLARE	@query  NVARCHAR(MAX) = ''
	DECLARE	@usuario  NVARCHAR(MAX) = ''
	DECLARE @idOperacion INT
	SELECT  @isProveedor = case idCatalogoTipoUsuarios 
	                       when 4 then 1
	                       else 0 
	                       end 
	from Usuarios where idUsuario=@idUsuario 

	print 'idCatalogoTipoUsuario'
	print @isProveedor

--	DECLARE	@server  NVARCHAR(MAX) = ''
--		DECLARE	@db  NVARCHAR(MAX) = ''		

--		IF(@isProduction = 1)
--	BEGIN
--		SELECT 
--				@server = SERVER,
--				@db = DBProduccion			
--		FROM ContratoOperacionFacturacion COF 
--		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
--		WHERE CO.idContratoOperacion =  @idContratoOperacion
--	END
--ELSE
--	BEGIN
--		SELECT 
--				@server=SERVER,
--				@db=DB
--		FROM ContratoOperacionFacturacion COF 
--		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
--		WHERE CO.idContratoOperacion =  @idContratoOperacion
--	END

    	---STEP 00 Create Table with collation from Database, desde BPRO
	--DROP TABLE [cobranza].[InvoiceProvSaldoDiaDef]

	--SELECT         
	--	   CAST([NumFactura] as varchar(20)) COLLATE Modern_Spanish_CI_AS AS [NumFactura],
	--	   [DeudaDia]
	--  INTO [cobranza].[InvoiceProvSaldoDiaDef]   
 --     FROM [cobranza].[VwInvoiceProvSaldoDiaDef]


	select @idOperacion = CO.idOperacion
    from ContratoOperacion CO
    where idContratoOperacion = @idContratoOperacion

	declare @nombreCliente nvarchar(100)
	SELECT @nombreCliente = [dbo].[SEL_NOMBRE_CLIENTE](cast(@idContratoOperacion as varchar))

	SET @select ='

	SELECT DISTINCT
		'''+@nombreCliente+''' as [nombreCliente],
		[numeroCopade]
      ,[folio]
      ,[consecutivoOrden]
      ,[numeroOrden]
      ,[idContratoOperacion]
      ,[numeroCotizacion]
      ,VG.[numFactura]
      ,[total]
      ,[numeroEconomico]
      ,[nombre]
      ,[comentarioOrden]
      ,[precioCotizacion]
      ,[COP_IDDOCTO]
      ,[COP_CARGO]
      ,[abono]
      ,[COP_SALDO]
      ,[COP_FECHULTPAG]
      ,[fechaIngresoUnidad]
      ,[fechaInicio]
      ,[fechaFin]
      ,VG.[idCotizacion]
      ,[descripcion]
      ,[COP_FECHOPE]
      ,[idDatosCopade]
      ,[COP_ORDENGLOBAL]
      ,[idOrdenAgrupada]
      ,[fechaRecepcionCopade]
	  ,ISNULL(VSC.[DeudaDia],0) as saldoProveedor
	  ,razonsocial as [razonSocial]
  FROM [cobranza].[VwCotizacionAbonadoSelectGAAutoExpressCollateNot] VG

  JOIN [cobranza].[VwStatusCotizacionBaseCollate] VSC 
    ON VSC.[idCotizacion] = VG.idCotizacion
	AND VSC.[numFactura] = VG.[numFactura]'
		

	 IF(@isProveedor = 1)
		BEGIN
			SET @join =
				' inner join Cotizaciones cp on cp.idOrden=o.idOrden '

			SET @and = 
				' and idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idOperacion)+')) '
		END
	
	SET @where = ' where  idZona = COALESCE('+COALESCE(convert(varchar(max),@idZona),'NULL')+', idZona)
								AND idUsuario = COALESCE(' + COALESCE(convert(varchar(max),@idEjecutivoFiltro),'NULL')+ ', idUsuario)
								AND fechaRecepcionCopade between COALESCE(' + COALESCE(''''+@fechaIni+'''', 'NULL') + ', fechaRecepcionCopade) and COALESCE(' + COALESCE(''''+@fechaFin+'''', 'NULL') + ', fechaRecepcionCopade)'
	
	SET @order = 'order by numeroCopade, consecutivoOrden'
	
	SET @query = @select+@where+@and+@order
	print @query
	EXECUTE SP_EXECUTESQL @query
	--SELECT * FROM OrdenGlobalAbono
	
	END
go

