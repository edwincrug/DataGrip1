-- =============================================
-- Author:		Edwin CRUZ
-- Create date: 2020-02-07
-- Description:	Obtiene la lista de ordenes facturadas pendientes de pago con descuento
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORTE_COBRANZA_INTEGRA_CD_SP]
	-- Add the parameters for the stored procedure here
	@idContratos AS XML
AS
BEGIN


	DECLARE @tbl_contratos AS TABLE(
		idContrato				INT
    )

    INSERT INTO @tbl_contratos(idContrato)
    SELECT
		ParamValues.col.value('idContrato[1]','int')
        FROM @idContratos.nodes('contratos/contrato') AS ParamValues(col)

	SELECT 
		C.idContrato
		,C.descripcion contrato
		,(SUM(BPD.OTD_PRECIOUNITARIOVENTA * BPD.[OTD_CANTIDAD]) * 100 / 90) * 1.16 montoOriginal
		,((SUM(BPD.OTD_PRECIOUNITARIOVENTA * BPD.[OTD_CANTIDAD]) * 100 / 90) * 0.10) * 1.16 descuento
		,((SUM(BPD.OTD_PRECIOUNITARIOVENTA * BPD.[OTD_CANTIDAD]) * 100 / 90) * 0.90) * 1.16 montoFinal
	--FROM [ASEPROT].[dbo].[DescuentoIntegraBPro] D
	--	INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] BPE
	--		ON D.OTD_IDENT = BPE.OTE_IDENT
	--	INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERDET] BPD
	--		ON D.OTD_IDENT = BPD.OTD_IDENT 
	--		AND D.OTD_CONSECUTIVO = BPD.OTD_CONSECUTIVO
	--	INNER JOIN [ASEPROT].[dbo].[Ordenes] O
	--		ON BPE.OTE_ORDENANDRADE COLLATE MODERN_SPANISH_CI_AS = O.numeroOrden
	--	INNER JOIN [ASEPROT].[dbo].[ContratoOperacion] CO 
	--		ON O.idContratoOperacion = CO.idContratoOperacion
	--	INNER JOIN [Partidas].[dbo].[Contrato] C 
	--		ON CO.idContrato = C.idContrato
	--	INNER JOIN [Partidas].[dbo].[Licitacion] L 
	--		ON C.idLicitacion = L.idLicitacion
	--	INNER JOIN @tbl_contratos TMC
	--		ON TMC.idContrato = C.idContrato

	FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_COPADE] ade
		INNER JOIN ASEPROT..OrdenAgrupada OA ON OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
		INNER JOIN ASEPROT..OrdenAgrupadaDetalle OAD ON OAD.idOrdenAgrupada = OA.idOrdenAgrupada
		INNER JOIN ASEPROT..DatosCopadeOrden dco ON dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
		INNER JOIN ASEPROT..DatosCopade dc ON dc.idDatosCopade = dco.idDatosCopade
		INNER JOIN ASEPROT.dbo.Ordenes O  ON O.idOrden = dco.idOrden
		INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] BPE ON BPE.OTE_ORDENANDRADE COLLATE MODERN_SPANISH_CI_AS = O.numeroOrden
		INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERDET] BPD ON BPE.OTE_IDENT = BPD.OTD_IDENT
		INNER JOIN [ASEPROT].[dbo].[ContratoOperacion] CO 
			ON O.idContratoOperacion = CO.idContratoOperacion
		INNER JOIN [Partidas].[dbo].[Contrato] C 
			ON CO.idContrato = C.idContrato
		INNER JOIN [Partidas].[dbo].[Licitacion] L 
			ON C.idLicitacion = L.idLicitacion
		INNER JOIN @tbl_contratos TMC
			ON TMC.idContrato = C.idContrato
	WHERE 
		ade.COP_STATUS = 2
		AND BPE.OTE_IDENT IN (
		SELECT OTD_IDENT FROM [ASEPROT].[dbo].[DescuentoIntegraBPro]
		)
	 --( (ade.COP_STATUS = 2) OR (ade.COP_STATUS = 4  
		--				      AND ade.COP_ORDENGLOBAL COLLATE Modern_Spanish_CS_AS NOT IN(select numeroOrdenGlobal from ASEPROT..OrdenGlobalAbono) 	
		--	) 
		--) 
	GROUP BY C.idContrato
		,C.descripcion

END
go

