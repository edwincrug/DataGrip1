
CREATE VIEW [dbo].[vwCorreosATLASCOPCO]
AS

/*PRODUCCION*/
SELECT 'Brauilio Solano' AS Nombre,'ejecutivodecuenta2@centraldeoperaciones.com' AS Email
UNION
SELECT 'Inplant' AS Nombre,'implantac@centraldeoperaciones.com' AS Email

go

