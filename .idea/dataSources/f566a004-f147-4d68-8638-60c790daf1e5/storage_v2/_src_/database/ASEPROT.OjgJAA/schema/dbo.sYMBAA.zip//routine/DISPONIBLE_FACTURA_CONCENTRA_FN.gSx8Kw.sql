-- =============================================
-- Author:		Jordan Gómez Domínguez
-- Create date: 18/02/2019 12:55:20 p. m.
-- Description:	Devuelve el disponible de la factura concentrada según sus ordenes asociadas
-- =============================================
--SELECT [dbo].[DISPONIBLE_FACTURA_CONCENTRA_FN] (14, 2, 538)
CREATE FUNCTION  [dbo].[DISPONIBLE_FACTURA_CONCENTRA_FN] (
	@IdContratoOperacion numeric(18,0),
	@IdDatosFacturaConcentra numeric(18,0),
	@idUsuario numeric(18,0)
)
RETURNS NUMERIC(18,2)
AS
BEGIN

	DECLARE @idOperacion int = (SELECT idContratoOperacion FROM ContratoOperacion WHERE idContratoOperacion = @idContratoOperacion)
    DECLARE @rolUsuario int = [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion)
	DECLARE @totalFec NUMERIC(18,2) = 0
	DECLARE @totalCotizacion NUMERIC(18,2) = 0
	DECLARE @disponible NUMERIC(18,2)

	Select @totalCotizacion = SUM(Monto) from (
	SELECT 
	(select [dbo].[SEL_PRECIO_COSTO_COT_FN](C.idCotizacion,O.idContratoOperacion,3,@idUsuario,@rolUsuario) )as Monto
	--(select [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden,O.idContratoOperacion,3,@idUsuario,@rolUsuario) ) as Monto 
	FROM 
	DatosFacturaConcentraCotizacion DFCC 
	INNER JOIN DatosFacturaConcentra DFC ON DFC.IdDatosFacturaConcentra = DFCC.IdDatosFacturaConcentra
	INNER JOIN Cotizaciones C ON DFCC.IdCotizacion = C.idCotizacion
	INNER JOIN Ordenes O ON C.idOrden = O.idOrden
	WHERE DFCC.IdDatosFacturaConcentra=@IdDatosFacturaConcentra 
	) as Montos

	SELECT @totalFec = SubTotal FROM DatosFacturaConcentra WHERE IdDatosFacturaConcentra = @IdDatosFacturaConcentra

	set @disponible = (@totalFec - @totalCotizacion)

	return @disponible

END
go

