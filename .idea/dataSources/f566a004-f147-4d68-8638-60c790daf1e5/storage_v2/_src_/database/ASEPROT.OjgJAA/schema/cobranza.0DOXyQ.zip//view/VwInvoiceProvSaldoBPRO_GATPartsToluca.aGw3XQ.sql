

--SELECT * FROM [cobranza].[VwInvoiceProvSaldoBPRO_GATPartsToluca] WHERE DES_CARTERA IS NOT NULL
CREATE VIEW [cobranza].[VwInvoiceProvSaldoBPRO_GATPartsToluca]

AS
select 
             --FC.idCotizacion,
             CARTERA.PAR_IDMODULO MODULO,
             CARTERA.PAR_DESCRIP1 DES_CARTERA,
             TIMO.PAR_DESCRIP1 DES_TIPODOCTO, 
             --,CCP_IDDOCTO 
			 CAST([CCP_IDDOCTO] as varchar(50)) COLLATE Modern_Spanish_CI_AS AS [CCP_IDDOCTO]
			 ,CCP_NODOCTO,
             CCP_IDPERSONA, 
             rtrim(ltrim(PER_PATERNO + ' ' + PER_MATERNO + ' ' + PER_NOMRAZON)) as Nombre, 
             PER_TELEFONO1,
             CCP_FECHVEN,
             CCP_FECHPAG,
             CCP_FECHPROMPAG,
             CCP_FECHREV,
             'IMPORTE' = CASE CARTERA.PAR_IDMODULO

                                         when 'CXP'

                                         then ccp_abono-ccp_cargo

                                         else ccp_cargo-ccp_abono

                                        end, 

             'SALDO' = CASE CARTERA.PAR_IDMODULO

                                        when 'CXP'

                                        then ccp_abono-ccp_cargo + (Select isnull(sum(CCP_ABONO-CCP_CARGO),0)

                 from [192.168.20.29].[GATPartsToluca].[dbo].VIS_CONCAR01 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO
				 --from [BPro].[vWVIS_CONCAR01_GATPartsToluca] as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO

                 AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA

                 AND MOVIMIENTO.CCP_DOCORI<>'S')

                                        else ccp_CARGO-ccp_ABONO+(Select isnull(sum(CCP_CARGO-CCP_ABONO),0)

                 from [192.168.20.29].[GATPartsToluca].[dbo].VIS_CONCAR01 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO
				 --from [BPro].[vWVIS_CONCAR01_GATPartsToluca] as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO

                            AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA

                            AND MOVIMIENTO.CCP_DOCORI<>'S')

                            end, 

                            CCP_FECHADOCTO,

                 --CCP_FECHVEN,

                 CCP_TIPODOCTO,

                 CCP_ORIGENCON
FROM [192.168.20.29].[GATPartsToluca].[dbo].VIS_CONCAR01 AS DOCUMENTO 
LEFT OUTER JOIN [192.168.20.29].[GATPartsToluca].[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA='CARTERA' 
INNER JOIN [192.168.20.29].[GATPartsToluca].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA
LEFT OUTER JOIN [192.168.20.29].[GATPartsToluca].[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = 'TIMO' 
WHERE CCP_DOCORI = 'S'  and CCP_TIPODOCTO = 'FAC'  AND CARTERA.PAR_IDMODULO IS NOT NULL

go

