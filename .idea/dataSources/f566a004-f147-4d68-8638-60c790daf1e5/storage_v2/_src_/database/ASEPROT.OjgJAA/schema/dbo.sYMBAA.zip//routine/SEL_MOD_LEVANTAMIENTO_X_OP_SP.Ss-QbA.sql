-- ==========================================================================================
-- DATE:   04/10/2016
-- DESC:   Modificacion al Store que CATALOGOS DE MODULO DE LEVANTAMIENTO POR OPERACION
-- [SEL_MOD_LEVANTAMIENTO_X_OP_SP] 15
-- ==========================================================================================
create PROCEDURE [dbo].[SEL_MOD_LEVANTAMIENTO_X_OP_SP] (
	@idOperacion numeric(18,0)
)
as
begin
	
	SELECT 
		cml.idCatalogoModuloLevantamiento, 
		cml.NombreModuloLevantamiento,
		cml.consecutivo
	FROM CatalogoModuloLevantamiento cml	
	WHERE cml.idOperacion = @idOperacion;
	
end
go

