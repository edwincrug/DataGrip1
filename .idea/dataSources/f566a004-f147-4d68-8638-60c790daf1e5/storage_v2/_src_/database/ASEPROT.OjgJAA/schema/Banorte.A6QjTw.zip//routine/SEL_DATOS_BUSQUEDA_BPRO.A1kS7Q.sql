-- =============================================
-- Author:		<YJH>
-- Create date: <2018/01/03>
-- Description:	<Obtiene los datos necesarios para buscar en bpro>
-- [BANORTE].[SEL_DATOS_BUSQUEDA_BPRO] 40184, 18,20
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_DATOS_BUSQUEDA_BPRO]
	 @idOrden int,
	 @idContratoOperacion int,
	 @idOperacion int
AS
BEGIN
	DECLARE @db nvarchar(100), @tabla nvarchar(100), @campoBusqueda nvarchar(100)

	DECLARE @proveedorInterno NUMERIC(18,0)

	SELECT @proveedorInterno = CO.proveedorInterno
		FROM ContratoOperacion C
		INNER JOIN ContratoOperacionFacturacion CO ON CO.idContratoOperacion = C.idContratoOperacion
		WHERE idOperacion = @idOperacion	

	if ((select case when not exists (select 1 from Cotizaciones C1 where C1.idEstatusCotizacion = 3 AND C1.idOrden = @idOrden and C1.idTaller in (select idProveedor from Partidas..Proveedor  where razonSocial like '%TOTAL PARTS AND COMPONENTS%') AND @proveedorInterno = 1) then 1 else 0 end) = 1) --si el taller de la cotizacion no es total parts
	BEGIN
		select @db=DBProduccion, @tabla = tablaBusqueda, @campoBusqueda=campoBusqueda from ContratoOperacionFacturacion where idContratoOperacion=@idContratoOperacion

	END
	ELSE -- si el taller es total parts
	BEGIN
		declare @idProveedor int = (select top 1 idTaller from Cotizaciones where idOrden = @idOrden and idEstatusCotizacion not in (4,5))
		select @db=DBProduccion, @tabla = tablaBusqueda, @campoBusqueda=campoBusqueda from CatalogoTecnico where IdProveedor=@idProveedor
	END
	select @db as db, @tabla as tabla, @campoBusqueda as campoBusqueda
END
go

grant execute, view definition on Banorte.SEL_DATOS_BUSQUEDA_BPRO to DevOps
go

