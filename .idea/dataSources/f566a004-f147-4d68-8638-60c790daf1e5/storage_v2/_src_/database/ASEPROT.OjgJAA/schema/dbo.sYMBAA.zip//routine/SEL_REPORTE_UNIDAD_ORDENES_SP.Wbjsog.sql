/* -------------------------------------
-- [SEL_REPORTE_UNIDAD_ORDENES_SP] 57, null, null, null, null, null, null
 ------------------------------------- */
CREATE PROCEDURE [dbo].[SEL_REPORTE_UNIDAD_ORDENES_SP] 
	@idContratoOperacion INT = 1,
	@idZona INT = NULL,
	@idCatalogoTipoOrdenServicio INT = NULL,
	@idCatalogoEstadoUnidad INT = NULL,
	@idServicio INT = NULL,
	@fechaInicial varchar(25) = NULL,
	@fechaFinal varchar(25) = NULL,
	@idUsuario INT = NULL
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @idOperacion INT=(SELECT idOperacion FROM ContratoOperacion WHERE idContratoOperacion=@idContratoOperacion)
	DECLARE @idCatalogo INT = NULL
	IF(@idCatalogoTipoOrdenServicio IS NOT NULL OR @idCatalogoEstadoUnidad IS NOT NULL OR @idServicio IS NOT NULL)
		SET @idCatalogo = 3
		
	DECLARE @idCatalogoRol INT
	DECLARE @esAgrupador BIT = 0

	SELECT  
	@idCatalogoRol = idCatalogoTipoUsuarios
	,@esAgrupador = CASE WHEN ISNULL((SELECT 1 FROM UsuarioAgrupador where idUsuario = @idUsuario),0)>0 THEN 1 ELSE 0 END
	FROM Usuarios
	WHERE idUsuario=@idUsuario

CREATE TABLE #datos(numeroEconomico VARCHAR(MAX), vin VARCHAR(MAX),talleres VARCHAR(MAX),idOperacion INT, idCentroTrabajo INT, placas VARCHAR(MAX), modelo VARCHAR(MAX)
, combustible VARCHAR(MAX),	verificada INT ,tipo VARCHAR(MAX), tipoCombustible VARCHAR(MAX),	subMarca VARCHAR(MAX),Marca VARCHAR(MAX)
,nombre VARCHAR(MAX),nombreCentroTrabajo VARCHAR(MAX),idOrden INT,idZona INT,	numeroOrden VARCHAR(MAX),	idEstatusOrden INT, nombreEstatusOrden VARCHAR(MAX)
, nombreTipoOrdenServicio VARCHAR(MAX),	descripcionEstadoUnidad VARCHAR(MAX), evento VARCHAR(MAX),tipoMantenimiento VARCHAR(MAX),idUnidad NUMERIC(18,0)
, fechaNuevaTaller DATETIME, fechaEntrada DATETIME, fechaProceso DATETIME, fechaEntrega DATETIME, fechaEntregaUsuario DATETIME
, fechaCreacionOden DATETIME, fechaCita DATETIME, diferenciaDias INT, costo FLOAT, venta FLOAT, facturaCotizacion INT)
	

if (@idZona is not null)
begin

declare @zonasFiltro table (idZona int)
insert into @zonasFiltro 
select idZona from [dbo].[GET_ZONAS_FILTRO_FN](@idZona)

end

IF(@idServicio IS NULL)
	INSERT INTO #datos
	SELECT
		U.numeroEconomico,
		U.vin,
		[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) talleres,
		--[dbo].[SEL_STATUS_PROVISION_FN](O.idOrden) estatusP,
		U.idOperacion,
		U.idCentroTrabajo,
		U.placas,
		U.modelo,
		U.combustible,
		U.verificada,
		TU.tipo,
		TC.tipoCombustible,
		SM.nombre subMarca,
		M.nombre Marca,
		Z.nombre,
		CT.nombreCentroTrabajo,
		o.idOrden,
		O.idZona,
		o.numeroOrden,
		o.idEstatusOrden,
		EO.nombreEstatusOrden,  
		CTOS.nombreTipoOrdenServicio,
		CEU.descripcionEstadoUnidad,
		--(SELECT TOP 1 PC.clasificacion FROM Ordenes ORD JOIN Cotizaciones C on C.idOrden = ORD.idOrden JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion JOIN Partidas..Partida P ON P.idPartida = CD.idPartida JOIN Partidas..PartidaClasificacion PC ON PC.idPartidaClasificacion = P.idPartidaClasificacion  WHERE P.idPartidaClasificacion IN(1,2) AND ORD.idOrden = O.idOrden) evento,
		(SELECT [dbo].[SEL_TIPO_EVENTO_FN](O.idOrden)) evento,
		CASE WHEN EXISTS(select P.idEspecialidad from ASEPROT..cotizaciones C
					INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
					INNER JOIN partidas..partida P ON P.idPartida = CD.idPartida
					where idorden = O.idOrden
					AND idEspecialidad = 11) THEN 'Preventivo' ELSE 'Correctivo' END tipoMantenimiento,
		PU.idUnidad,
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 2) AS fechaNuevaTaller, 
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3) AS fechaEntrada, 
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 5) AS fechaProceso, 
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 6) AS fechaEntrega,
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 8) AS fechaEntregaUsuario,
		O.fechaCreacionOden,
		O.fechaCita,
		DATEDIFF (day, (SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3), (SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 6)) AS diferenciaDias
		 ,ISNULL((SELECT SUM(CD.costo * CD.cantidad * 1.16) AS Expr1
								FROM Unidades U 
								INNER JOIN Ordenes Orden ON U.idUnidad = Orden.idUnidad 
								INNER JOIN Cotizaciones C ON C.idOrden = Orden.idOrden 
								INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
								WHERE (Orden.idOrden = O.idOrden) ),0) AS costo,
		ISNULL((SELECT SUM(CD.venta * CD.cantidad * 1.16) AS Expr1
				FROM Unidades U 
				INNER JOIN Ordenes Orden ON U.idUnidad = Orden.idUnidad 
				INNER JOIN Cotizaciones C ON C.idOrden = Orden.idOrden 
				INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
				WHERE (Orden.idOrden = O.idOrden) ),0) AS venta
		,CASE 
			WHEN EXISTS(SELECT idFacturaCotizacion
								FROM ASEPROT..Cotizaciones C
								LEFT JOIN ASEPROT..facturaCotizacion FC ON FC.idCotizacion = C.idCotizacion
								WHERE C.idOrden = O.idOrden AND C.idEstatusCotizacion IN (1,2,3) AND FC.idFacturaCotizacion IS NULL) THEN 0 
			WHEN NOT EXISTS(SELECT idFacturaCotizacion
								FROM ASEPROT..Cotizaciones C
								INNER JOIN ASEPROT..facturaCotizacion FC ON FC.idCotizacion = C.idCotizacion
								WHERE C.idOrden = O.idOrden AND C.idEstatusCotizacion IN (1,2,3)) THEN 0
			ELSE 1 END  facturaCotizacion
	FROM Ordenes O
	INNER JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden  
	JOIN CatalogoTiposOrdenServicio CTOS ON CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
	JOIN CatalogoEstadoUnidad CEU ON CEU.idCatalogoEstadoUnidad = O.idCatalogoEstadoUnidad
	--JOIN CatalogoTipoOrden CTO ON CTO.idTipoOrden = O.idTipoOrden
	JOIN Unidades U ON U.idUnidad = O.idUnidad 
	JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
	JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
	JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
	JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
	JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
	JOIN Partidas..Zona Z ON Z.idZona = U.idZona
	LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
	WHERE O.idContratoOperacion = @idContratoOperacion AND
	O.idCatalogoTipoOrdenServicio = COALESCE(@idCatalogoTipoOrdenServicio, O.idCatalogoTipoOrdenServicio) AND
	O.idCatalogoEstadoUnidad = COALESCE(@idCatalogoEstadoUnidad, O.idCatalogoEstadoUnidad) AND
	--O.idOrden IN (SELECT DISTINCT ORD.idOrden FROM Ordenes ORD JOIN Cotizaciones C on C.idOrden = ORD.idOrden JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion JOIN Partidas..Partida P ON P.idPartida = CD.idPartida JOIN Partidas..PartidaClasificacion PC ON PC.idPartidaClasificacion = P.idPartidaClasificacion WHERE P.idPartidaClasificacion IN(@idServicio) AND ORD.idContratoOperacion = @idContratoOperacion) AND
	--O.idOrden IN COALESCE(SELECT TOP 1 ord.idOrden FROM Ordenes ORD JOIN Cotizaciones C on C.idOrden = ORD.idOrden JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion JOIN Partidas..Partida P ON P.idPartida = CD.idPartida JOIN Partidas..PartidaClasificacion PC ON PC.idPartidaClasificacion = P.idPartidaClasificacion  WHERE P.idPartidaClasificacion IN(1) AND ORD.idOrden = O.idOrden, O.idOrden) AND
	(O.idZona = COALESCE(@idZona,O.idZona) OR O.idZona IN(SELECT idZona FROM @zonasFiltro)) 
	AND O.idEstatusOrden NOT IN(13) 
	AND O.fechaCreacionOden BETWEEN COALESCE(@fechaInicial,O.fechaCreacionOden) AND COALESCE (@fechaFinal,O.fechaCreacionOden)	
	--UNION
	--	SELECT 		
	--	U.numeroEconomico,
	--	U.vin,
	--	[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) talleres,
	--	--[dbo].[SEL_STATUS_PROVISION_FN](O.idOrden) estatusP,
	--	U.idOperacion,
	--	U.idCentroTrabajo,
	--	U.placas,
	--	U.modelo,
	--	U.combustible,
	--	U.verificada,
	--	TU.tipo,
	--	TC.tipoCombustible,
	--	SM.nombre subMarca,
	--	M.nombre Marca,
	--	Z.nombre,
	--	CT.nombreCentroTrabajo,
	--	O.numeroOrden,
	--	o.idEstatusOrden,
	--	'Unidad Fuera de Operación' AS nombreTipoOrdenServicio,
	--	'Parada' AS descripcionEstadoUnidad,
	--	 MS.Descripcion evento,
	--	 US.fecha AS fechaNuevaTaller, -- cual es?
	--	 US.fecha AS fechaEntrada, 
	--	 US.fecha AS fechaProceso,  -- cual es?
	--	 US.fechaSalida AS fechaEntrega,
	--	 US.fechaSalida AS fechaEntregaUsuario,
	--	 US.fecha AS fechaCreacionOden,
	--	 US.fecha AS fechaCita,
	--	 DATEDIFF (day, US.fecha, isnull(US.fechaSalida, getdate())) AS diferenciaDias,
	--	 ISNULL((SELECT SUM(CD.costo * CD.cantidad * 1.16) AS Expr1
	--							FROM Unidades U 
	--							INNER JOIN Ordenes Orden ON U.idUnidad = Orden.idUnidad 
	--							INNER JOIN Cotizaciones C ON C.idOrden = Orden.idOrden 
	--							INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	--							WHERE (Orden.idOrden = O.idOrden) AND (NOT (Orden.idEstatusOrden = 10)) AND (O.idEstatusOrden > 4)),0) AS costo,
	--	ISNULL((SELECT SUM(CD.venta * CD.cantidad * 1.16) AS Expr1
	--			FROM Unidades U 
	--			INNER JOIN Ordenes Orden ON U.idUnidad = Orden.idUnidad 
	--			INNER JOIN Cotizaciones C ON C.idOrden = Orden.idOrden 
	--			INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	--			WHERE (Orden.idOrden = O.idOrden) AND 
	--				(NOT (Orden.idEstatusOrden = 10)) AND 
	--				(Orden.idEstatusOrden > 4)),0) AS venta
	--FROM [Sustituto].[UnidadSustituto] US
	--	JOIN [Sustituto].[MotivoSustituto] MS ON MS.idMotivo = US.idMotivo
	--	JOIN Unidades U ON U.idUnidad = US.idUnidad
	--	JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
	--	JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
	--	JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
	--	JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
	--	JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
	--	JOIN Partidas..Zona Z ON Z.idZona = U.idZona
	--	LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
	--	LEFT JOIN Ordenes O ON O.numeroOrden = US.numeroOrden
	--WHERE U.idOperacion = @idOperacion AND
	--US.estatus = COALESCE(@idCatalogo, US.estatus) AND
	--U.idZona = COALESCE(@idZona,U.idZona) AND
	----US.estatus = 0 AND
	--US.fecha BETWEEN COALESCE(@fechaInicial,US.fecha) AND COALESCE (@fechaFinal,US.fecha)
ELSE
INSERT INTO #datos
	SELECT
		U.numeroEconomico,
		U.vin,
		[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) talleres,
		[dbo].[SEL_STATUS_PROVISION_FN](O.idOrden) estatusP,
		U.idOperacion,
		U.idCentroTrabajo,
		U.placas,
		U.modelo,
		U.combustible,
		U.verificada,
		TU.tipo,
		TC.tipoCombustible,
		SM.nombre subMarca,
		M.nombre Marca,
		Z.nombre,
		CT.nombreCentroTrabajo,
		o.idOrden,
		o.idZona,
		o.numeroOrden,
		o.idEstatusOrden,
		EO.nombreEstatusOrden,  
		CTOS.nombreTipoOrdenServicio,
		CEU.descripcionEstadoUnidad,
		--(SELECT TOP 1 PC.clasificacion FROM Ordenes ORD JOIN Cotizaciones C on C.idOrden = ORD.idOrden JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion JOIN Partidas..Partida P ON P.idPartida = CD.idPartida JOIN Partidas..PartidaClasificacion PC ON PC.idPartidaClasificacion = P.idPartidaClasificacion  WHERE P.idPartidaClasificacion IN(1,2) AND ORD.idOrden = O.idOrden) evento,
		(SELECT [dbo].[SEL_TIPO_EVENTO_FN](O.idOrden)) evento,
		CASE WHEN EXISTS(select P.idEspecialidad from ASEPROT..cotizaciones C
					INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
					INNER JOIN partidas..partida P ON P.idPartida = CD.idPartida
					where idorden = O.idOrden
					AND idEspecialidad = 11) THEN 'Preventivo' ELSE 'Correctivo' END tipoMantenimiento,
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 2) AS fechaNuevaTaller, 
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3) AS fechaEntrada, 
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 5) AS fechaProceso, 
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 6) AS fechaEntrega,
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 8) AS fechaEntregaUsuario,
		O.fechaCreacionOden,
		O.fechaCita,
		DATEDIFF (day, (SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3), (SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 6)) AS diferenciaDias,
		 ISNULL((SELECT SUM(CD.costo * CD.cantidad * 1.16) AS Expr1
								FROM Unidades U 
								INNER JOIN Ordenes Orden ON U.idUnidad = Orden.idUnidad 
								INNER JOIN Cotizaciones C ON C.idOrden = Orden.idOrden 
								INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
								WHERE (Orden.idOrden = O.idOrden) ),0) AS costo,
		ISNULL((SELECT SUM(CD.venta * CD.cantidad * 1.16) AS Expr1
				FROM Unidades U 
				INNER JOIN Ordenes Orden ON U.idUnidad = Orden.idUnidad 
				INNER JOIN Cotizaciones C ON C.idOrden = Orden.idOrden 
				INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
				WHERE (Orden.idOrden = O.idOrden) ),0) AS venta
		,CASE 
			WHEN EXISTS(SELECT idFacturaCotizacion
								FROM ASEPROT..Cotizaciones C
								LEFT JOIN ASEPROT..facturaCotizacion FC ON FC.idCotizacion = C.idCotizacion
								WHERE C.idOrden = O.idOrden AND C.idEstatusCotizacion IN (1,2,3) AND FC.idFacturaCotizacion IS NULL) THEN 0 
			WHEN NOT EXISTS(SELECT idFacturaCotizacion
								FROM ASEPROT..Cotizaciones C
								INNER JOIN ASEPROT..facturaCotizacion FC ON FC.idCotizacion = C.idCotizacion
								WHERE C.idOrden = O.idOrden AND C.idEstatusCotizacion IN (1,2,3)) THEN 0
			ELSE 1 END  facturaCotizacion
	FROM Ordenes O
	INNER JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden  
	JOIN CatalogoTiposOrdenServicio CTOS ON CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
	JOIN CatalogoEstadoUnidad CEU ON CEU.idCatalogoEstadoUnidad = O.idCatalogoEstadoUnidad
	--JOIN CatalogoTipoOrden CTO ON CTO.idTipoOrden = O.idTipoOrden
	JOIN Unidades U ON U.idUnidad = O.idUnidad
	JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
	JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
	JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
	JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
	JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
	JOIN Partidas..Zona Z ON Z.idZona = U.idZona
	LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
	WHERE O.idContratoOperacion = @idContratoOperacion AND
	O.idCatalogoTipoOrdenServicio = COALESCE(@idCatalogoTipoOrdenServicio, O.idCatalogoTipoOrdenServicio) AND
	O.idCatalogoEstadoUnidad = COALESCE(@idCatalogoEstadoUnidad, O.idCatalogoEstadoUnidad) AND
	O.idOrden IN (SELECT DISTINCT ORD.idOrden 
					FROM Ordenes ORD JOIN Cotizaciones C on C.idOrden = ORD.idOrden 
					JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
					JOIN Partidas..Partida P ON P.idPartida = CD.idPartida 
					JOIN Partidas..PartidaClasificacion PC ON PC.idPartidaClasificacion = P.idPartidaClasificacion 
					WHERE P.idPartidaClasificacion IN(@idServicio) 
					AND ORD.idContratoOperacion = @idContratoOperacion) AND
	--O.idOrden IN COALESCE(SELECT TOP 1 ord.idOrden FROM Ordenes ORD JOIN Cotizaciones C on C.idOrden = ORD.idOrden JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion JOIN Partidas..Partida P ON P.idPartida = CD.idPartida JOIN Partidas..PartidaClasificacion PC ON PC.idPartidaClasificacion = P.idPartidaClasificacion  WHERE P.idPartidaClasificacion IN(1) AND ORD.idOrden = O.idOrden, O.idOrden) AND
	(O.idZona = COALESCE(@idZona,O.idZona) OR O.idZona IN(SELECT idZona FROM @zonasFiltro))
	AND O.idEstatusOrden NOT IN(13) 
	AND O.fechaCreacionOden BETWEEN COALESCE(@fechaInicial,O.fechaCreacionOden) AND COALESCE (@fechaFinal,O.fechaCreacionOden)	
	--UNION
	--	SELECT 		
	--	U.numeroEconomico,
	--	U.vin,
	--	[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) talleres,
	--	[dbo].[SEL_STATUS_PROVISION_FN](O.idOrden) estatusP,
	--	U.idOperacion,
	--	U.idCentroTrabajo,
	--	U.placas,
	--	U.modelo,
	--	U.combustible,
	--	U.verificada,
	--	TU.tipo,
	--	TC.tipoCombustible,
	--	SM.nombre subMarca,
	--	M.nombre Marca,
	--	Z.nombre,
	--	CT.nombreCentroTrabajo,
	--	O.numeroOrden,
	--	o.idEstatusOrden,
	--	'Unidad Fuera de Operación' AS nombreTipoOrdenServicio,
	--	'Parada' AS descripcionEstadoUnidad,
	--	 MS.Descripcion evento,
	--	 US.fecha AS fechaNuevaTaller, -- cual es?
	--	 US.fecha AS fechaEntrada, 
	--	 US.fecha AS fechaProceso,  -- cual es?
	--	 US.fechaSalida AS fechaEntrega,
	--	 US.fechaSalida AS fechaEntregaUsuario,
	--	 US.fecha AS fechaCreacionOden,
	--	 US.fecha AS fechaCita,
	--	 DATEDIFF (day, US.fecha, isnull(US.fechaSalida, getdate())) AS diferenciaDias,
	--	  ISNULL((SELECT SUM(CD.costo * CD.cantidad * 1.16) AS Expr1
	--							FROM Unidades U 
	--							INNER JOIN Ordenes Orden ON U.idUnidad = Orden.idUnidad 
	--							INNER JOIN Cotizaciones C ON C.idOrden = Orden.idOrden 
	--							INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	--							WHERE (Orden.idOrden = O.idOrden) AND (NOT (Orden.idEstatusOrden = 10)) AND (O.idEstatusOrden > 4)),0) AS costo,
	--	ISNULL((SELECT SUM(CD.venta * CD.cantidad * 1.16) AS Expr1
	--			FROM Unidades U 
	--			INNER JOIN Ordenes Orden ON U.idUnidad = Orden.idUnidad 
	--			INNER JOIN Cotizaciones C ON C.idOrden = Orden.idOrden 
	--			INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	--			WHERE (Orden.idOrden = O.idOrden) AND 
	--				(NOT (Orden.idEstatusOrden = 10)) AND 
	--				(Orden.idEstatusOrden > 4)),0) AS venta
	--FROM [Sustituto].[UnidadSustituto] US
	--	JOIN [Sustituto].[MotivoSustituto] MS ON MS.idMotivo = US.idMotivo
	--	JOIN Unidades U ON U.idUnidad = US.idUnidad
	--	JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
	--	JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
	--	JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
	--	JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
	--	JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
	--	JOIN Partidas..Zona Z ON Z.idZona = U.idZona
	--	LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
	--	LEFT JOIN Ordenes O ON O.numeroOrden = US.numeroOrden
	--WHERE U.idOperacion = @idOperacion AND
	--US.estatus = COALESCE(@idCatalogo, US.estatus) AND
	--U.idZona = COALESCE(@idZona,U.idZona) AND
	----US.estatus = 0 AND
	--US.fecha BETWEEN COALESCE(@fechaInicial,US.fecha) AND COALESCE (@fechaFinal,US.fecha)
END
IF (@idCatalogoRol=4)
BEGIN
declare @tablaProveedoresAsignados table(idProveedor int)
	insert into @tablaProveedoresAsignados
	select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)

SELECT * FROM #datos
WHERE idOrden IN(
	SELECT idOrden FROM Cotizaciones
	WHERE idTaller IN(
	SELECT idProveedor FROM @tablaProveedoresAsignados
	)
)
END
ELSE IF (@idCatalogoRol=2 OR @esAgrupador=1)
BEGIN
SELECT * FROM #datos
END
ELSE IF (@idCatalogoRol=9 OR @idCatalogoRol=3)
BEGIN

declare @idCOU numeric(18,0) = [dbo].[GET_CONTRATO_OPERACION_USR_FN](@idUsuario,@idOperacion)
	declare @zonasAsignadas table (idZona int)
	insert into @zonasAsignadas
	select idZona from [dbo].[GET_ZONAS_USR_FN](@idCOU)

SELECT * FROM #datos
WHERE idZona IN(
SELECT idZona FROM @zonasAsignadas
)
END
ELSE
BEGIN
SELECT * FROM #datos
END

DROP TABLE #datos
go

