
-- =============================================
-- Description:	Obtiene el historial de las ordenes de servicio finalizadas o canceladas 
-- =============================================
-- [SEL_ORDENES_HISTORIAL_SP] @idUsuario = 113, @economico = '1210160', @idContratoOperacion = 1
-- [SEL_ORDENES_HISTORIAL_SP] @idUsuario = 153, @economico = 9304, @idContratoOperacion = 3
CREATE PROCEDURE [dbo].[SEL_ORDENES_HISTORIAL_SP]
	@idUsuario NUMERIC(18,0),
	@economico NVARCHAR(50),
	@idContratoOperacion INT
AS
BEGIN
	--Obtendo el id de la Unidad
	DECLARE @idUnidad INT
	SELECT @idUnidad=idUnidad FROM Unidades u 
	inner join ContratoOperacion CO on u.idOperacion = CO.idOperacion
	WHERE u.numeroEconomico = @economico and CO.idContratoOperacion = @idContratoOperacion
	print @idUnidad

	DECLARE @idCatalogoRol INT 
	DECLARE @idOperacion INT
	DECLARE @idCOU INT

	SELECT @idCatalogoRol=COU.idCatalogoRol , @idOperacion = CO.idOperacion, @idCOU = COU.idContratoOperacionUsuario
	FROM [dbo].[ContratoOperacionUsuario] COU
	JOIN [dbo].[CatalogoRoles] CR ON CR.idCatalogoRol = COU.idCatalogoRol
	JOIN [dbo].[ContratoOperacion] CO ON CO.idContratoOperacion = COU.idContratoOperacion 
	WHERE idUsuario = @idUsuario and CO.idContratoOperacion = @idContratoOperacion
	--PRINT @idCatalogoRol
	declare @tablaProveedoresAsignados table(idProveedor int)
	insert into @tablaProveedoresAsignados
	select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)
	
	declare @zonasAsignadas table(idZona int)
	insert into @zonasAsignadas
	select idZona from [dbo].[GET_ZONAS_USR_FN](@idCOU)
	--select idZona from [dbo].[GET_ZONAS_USR_FN](630)	
	-----------------------------------------------------------------------------------
	--Verifico si la unidad tiene Ordenes de serevicio canceladas o finalizadas 
	-- respuesta = 0 <-- No tiene Ordenses de servicio  
	-- respuesta = 1 <-- Tiene Ordenes de Servicio  
	-----------------------------------------------------------------------------------
	IF(EXISTS(SELECT * FROM [dbo].[Ordenes] WHERE idUnidad = @idUnidad AND idEstatusOrden IN (12,13)))
		BEGIN 
			SELECT O.[idOrden] AS idOrden
				  ,[fechaCreacionOden] AS fechaCreacionOrden
				  ,[fechaCita] AS FechaCita
				  ,[numeroOrden] AS numeroOrden
				  ,[comentarioOrden] AS descripcion
				  ,[idCatalogoEstadoUnidad] AS idEstadoUnidad
				  ,O.[idUsuario] AS idUsuario
				  ,U.nombreCompleto AS nombreCompleto
				  ,O.idCatalogoTipoOrdenServicio AS idTipoOrden
				  ,CTO.nombreTipoOrdenServicio AS tipoOrden
				  ,O.[idEstatusOrden] AS idEstatusOrden
				  ,EO.nombreEstatusOrden AS estatusOrden
				  ,1 AS respuesta
				  ,[dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, @idContratoOperacion, 3, @idUsuario, @idCatalogoRol) AS costo
				  ,[dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, @idContratoOperacion, 3, @idUsuario, @idCatalogoRol) AS precio
				  --,nombreComercial AS nombreTaller
				  --,razonSocial AS razonSocial
				  --,P.direccion AS direccion
				  ,HEO.fechaInicial AS ultimaModificacion
			 FROM [dbo].[Ordenes] AS O
				  INNER JOIN [dbo].[EstatusOrdenes] AS EO ON O.idEstatusOrden = EO.idEstatusOrden
				  INNER JOIN [dbo].[Usuarios] AS U ON U.idUsuario = O.idUsuario
				  INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio  
				  LEFT JOIN  [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden
				  LEFT JOIN  [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion
				  --INNER JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = O.idTaller
				  INNER JOIN [dbo].[HistorialEstatusOrden] HEO ON HEO.idOrden = O.idOrden AND HEO.idEstatusOrden = O.idEstatusOrden
			WHERE idUnidad = @idUnidad AND O.idEstatusOrden IN (12,13)
					--AND (SELECT CASE WHEN @idCatalogoRol <> 4 THEN 'true' ELSE (SELECT CASE WHEN exists (select 1 from Cotizaciones C where C.idOrden = O.idOrden and C.idTaller in (select idProveedor from @tablaProveedoresAsignados)) THEN 'true'
					--															ELSE 'false' END ) 
					--													END) = 'true'
					AND (SELECT CASE WHEN @idCatalogoRol <> 4 and @idCatalogoRol <> 2
										THEN (SELECT CASE WHEN exists (select 1 from Ordenes otemp where otemp.idOrden = O.idOrden and O.idZona in (select idZona from @zonasAsignadas)) THEN 'true' ELSE 'false' END)
										ELSE 'true' END) = 'true'
			GROUP BY O.[idOrden], [fechaCreacionOden], [fechaCita], [numeroOrden], [comentarioOrden], [idCatalogoEstadoUnidad]
					,O.[idUsuario], U.nombreCompleto, O.idCatalogoTipoOrdenServicio, CTO.nombreTipoOrdenServicio, O.[idEstatusOrden], nombreEstatusOrden
					, HEO.fechaInicial
		END
	ELSE 
		BEGIN
			SELECT 0 AS respuesta,
				   '' AS mensaje

				   --Poner aqui mensaje en caso de que no haya ordenes
		END
END
go

