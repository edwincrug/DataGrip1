-- =============================================
-- Create date: 09/04/2018
-- Description:	Obtiene el catalogo de modulos operativos
-- [SEL_DATOS_LEVANTAMIENTO_INICIAL_SP] @idOrden=38234
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATOS_LEVANTAMIENTO_INICIAL_SP]
	@idOrden INT
AS
BEGIN
DECLARE @idUnidad INT
DECLARE @idContratooperacion INT
DECLARE @idTipoUnidad INT
DECLARE @rutaImagen NVARCHAR(100) = 'http://189.204.141.193:5101'
DECLARE @TipoUnidad NVARCHAR(100)
DECLARE @numeroOrden NVARCHAR(100)
/**************************************************************************************************************************************************************/
	SELECT	OML.idOrdenModuloLevantamiento, 
			OML.idCatalogoModuloLevantamiento, CML.NombreModuloLevantamiento, 
			idOrden,
			OMLD.idOrdenModuloLevantamientoDetalle,
			OMLD.idCatalogoModuloLevantamientoDetalle, CMLD.nombreModuloLevantamientoDetalle,
			OMLC.idOrdenModuloLevantamientoCaracteristica,
			OMLC.idCatalogoModuloLevantamientoCaracteristica, CMLC.alias,
			CTC.NombreControl,
			OMLC.dato,
			CMLC.detalle,
			CMLC.dano,
			CMLC.observacion
	FROM OrdenModuloLevantamiento OML
	JOIN CatalogoModuloLevantamiento CML ON CML.idCatalogoModuloLevantamiento = OML.idCatalogoModuloLevantamiento
	JOIN OrdenModuloLevantamientoDetalle OMLD ON OMLD.idOrdenModuloLevantamiento = OML.idOrdenModuloLevantamiento
	JOIN CatalogoModuloLevantamientoDetalle CMLD ON CMLD.idCatalogoModuloLevantamientoDetalle = OMLD.idCatalogoModuloLevantamientoDetalle
	JOIN OrdenModuloLevantamientoCaracteristica OMLC ON OMLC.idOrdenModuloLevantamientoDetalle = OMLD.idOrdenModuloLevantamientoDetalle
	JOIN CatalogoModuloLevantamientoCaracteristica CMLC ON CMLC.idCatalogoModuloLevantamientoCaracteristica = OMLC.idCatalogoModuloLevantamientoCaracteristica
	JOIN CatalogoTipoControl CTC on CTC.idCatalogoTipoControl = CMLC.idCatalogoTipoControl
	WHERE idOrden = @idOrden

/****************************************************************************************************************************************************************/
		SELECT @idUnidad=idUnidad, @idContratooperacion=idContratooperacion, @numeroOrden= numeroOrden
		FROM Ordenes WHERE idOrden=@idOrden

		SELECT @idTipoUnidad=UP.idTipoUnidad
		FROM Unidades U
		JOIN Partidas..Unidad UP ON UP.idUnidad = U.idTipoUnidad
		WHERE U.idUnidad=@idUnidad
		IF NOT EXISTS(SELECT * FROM TipoUnidadRecepcion WHERE idTipounidad = @idTipoUnidad) SET @idTipoUnidad = 999

		SELECT	@numeroOrden AS folio,
				numeroEconomico,
				GETDATE() fecha,
				(SELECT  @rutaImagen +  izquierda FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad) AS ParteIzquierda,
				(SELECT  @rutaImagen +  derecha FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad) AS ParteDerecha,
				(SELECT  @rutaImagen +  frente FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad) AS ParteDelantera,
				(SELECT  @rutaImagen +  atras FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad) AS ParteTrasera,
				(SELECT  @rutaImagen +  arriba FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad) AS ParteArriba,
				(SELECT @rutaImagen + logo FROM ContratoOperacionFacturacion WHERE idContratoOperacion=@idContratooperacion) logo,
				TU.tipo AS tipoUnidad,
				 M.nombre + ' ' + SM.nombre + ' ' + US.modelo AS unidad,
				(SELECT dbo.[SEL_ZONAS_NAME_FN]((SELECT idZona FROM Ordenes WHERE idOrden =@idOrden))) AS zona,
				'Juanito Perez' userName,
				'Robert Calamey' tecnico,
				'Pierre Dante' responsable
		FROM Unidades US
			JOIN Partidas..Unidad U ON U.idUnidad = US.idTipoUnidad
			JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = U.idTipoUnidad
		    JOIN Partidas..SubMarca SM ON SM.idSubMarca = U.idSubMarca
		    JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
		WHERE US.idUnidad=@idUnidad
/****************************************************************************************************************************************************************/

END

go

