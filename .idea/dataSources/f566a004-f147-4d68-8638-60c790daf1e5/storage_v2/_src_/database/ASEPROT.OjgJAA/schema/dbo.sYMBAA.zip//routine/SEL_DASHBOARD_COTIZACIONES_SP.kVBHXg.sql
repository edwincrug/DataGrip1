
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 31/05/2017
-- Description:	Devuelve los resultados del cuadrante de cotizaciones en el Dashboard
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_DASHBOARD_COTIZACIONES_SP]
    @idOperacion NUMERIC(20,0) = 1,
    @idZona NUMERIC(38,0) = NULL,
	@idUsuario NUMERIC(18,0) = 107
AS
	BEGIN
		-- DECLARE @idOperacion NUMERIC(12,0); 
		DECLARE @EstausOrden NUMERIC(12,0);

		-- SET @idOperacion = 3;
		SET @EstausOrden = 4;

		declare @idCOU numeric(18,0) = [dbo].[GET_CONTRATO_OPERACION_USR_FN](@idUsuario,@idOperacion)

		declare @zonasAsignadas table (idZona int)
		insert into @zonasAsignadas 
		select idZona from [dbo].[GET_ZONAS_USR_FN](@idCOU)

		declare @tablaProveedoresAsignados table(idProveedor int)
		insert into @tablaProveedoresAsignados
		select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)


	
		IF( @idZona = 0 )
			BEGIN
				set @idZona = null
			END 

				IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 2
					BEGIN
							IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 4
							BEGIN
							------------------------cliente INI------------------------
														SELECT 
								ESCO.idEstatusCotizacion idEstatus,
								ESCO.nombreEstatusCotizacion estatus,
								(SELECT COUNT(distinct ORD.idOrden) 
									FROM Cotizaciones				COTI
									INNER JOIN Ordenes				ORD  ON COTI.idOrden = ORD.idOrden
									INNER JOIN ContratoOperacion    COP  ON ORD.idContratoOperacion = COP.idContratoOperacion
									INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = COTI.idCotizacion
									WHERE 
										idEstatusCotizacion = ESCO.idEstatusCotizacion
										AND COP.idOperacion = @idOperacion
										AND ORD.idZona = COALESCE(@idZona, idZona)
										AND CD.idEstatusPartida IN (1,2)
										AND ORD.idEstatusOrden IN ( 4,5 ) AND ORD.idZona in (select idZona from @zonasAsignadas)) total,
								ISNULL( (SELECT AVG( DATEDIFF(hour, fechaInicial, CURRENT_TIMESTAMP) ) 
									FROM Cotizaciones					  COTI
									INNER JOIN Ordenes					  ORD  ON COTI.idOrden = ORD.idOrden
									INNER JOIN ContratoOperacion		  COP  ON ORD.idContratoOperacion = COP.idContratoOperacion
									INNER JOIN HistorialEstatusCotizacion HEC  ON COTI.idCotizacion = HEC.idCotizacion AND COTI.idEstatusCotizacion = HEC.idEstatusCotizacion
									WHERE COTI.idEstatusCotizacion = ESCO.idEstatusCotizacion
										AND COP.idOperacion = @idOperacion AND ORD.idEstatusOrden IN ( 4,5 ) AND ORD.idZona = COALESCE(@idZona, idZona) AND ORD.idZona in (select idZona from @zonasAsignadas)), 0 ) promedio,
								(CASE ESCO.idEstatusCotizacion
									WHEN 1 THEN '#d1fc35' 
									WHEN 2 THEN '#208021'  
									WHEN 3 THEN '#36c734' 
									ELSE '#80ff00' 
								END) color,
								Monto = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
														FROM [dbo].[Cotizaciones] C 
														INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
														INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
														INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
													WHERE C.idEstatusCotizacion = ESCO.idEstatusCotizacion
													AND CD.idEstatusPartida IN (1,2)
													AND CO.idOperacion = @idOperacion
													AND O.idZona = COALESCE(@idZona, idZona)
													AND O.idEstatusOrden IN (4,5) AND O.idZona in (select idZona from @zonasAsignadas)),
								MontoCosto =( SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
														FROM [dbo].[Cotizaciones] C 
														INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
														INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
														INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
													WHERE	C.idEstatusCotizacion = ESCO.idEstatusCotizacion 
													AND CD.idEstatusPartida IN (1,2)
													AND CO.idOperacion = @idOperacion
													AND O.idZona = COALESCE(@idZona, idZona)
													AND O.idEstatusOrden IN (4,5) AND O.idZona in (select idZona from @zonasAsignadas))
							FROM EstatusCotizaciones ESCO WHERE idEstatusCotizacion <= 2;
							------------------------cliente END------------------------
							END
							ELSE
							BEGIN
							------------------------proveedor INI------------------------
														SELECT 
								ESCO.idEstatusCotizacion idEstatus,
								ESCO.nombreEstatusCotizacion estatus,
								(SELECT COUNT(distinct ORD.idOrden) 
									FROM Cotizaciones				COTI
									INNER JOIN Ordenes				ORD  ON COTI.idOrden = ORD.idOrden
									INNER JOIN ContratoOperacion    COP  ON ORD.idContratoOperacion = COP.idContratoOperacion
									INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = COTI.idCotizacion
									WHERE 
										idEstatusCotizacion = ESCO.idEstatusCotizacion
										AND COP.idOperacion = @idOperacion
										AND ORD.idZona = COALESCE(@idZona, idZona)
										AND CD.idEstatusPartida IN (1,2)
										AND ORD.idEstatusOrden IN ( 4,5 ) AND COTI.idTaller in (select idProveedor from @tablaProveedoresAsignados)) total,
								ISNULL( (SELECT AVG( DATEDIFF(hour, fechaInicial, CURRENT_TIMESTAMP) ) 
									FROM Cotizaciones					  COTI
									INNER JOIN Ordenes					  ORD  ON COTI.idOrden = ORD.idOrden
									INNER JOIN ContratoOperacion		  COP  ON ORD.idContratoOperacion = COP.idContratoOperacion
									INNER JOIN HistorialEstatusCotizacion HEC  ON COTI.idCotizacion = HEC.idCotizacion AND COTI.idEstatusCotizacion = HEC.idEstatusCotizacion
									WHERE COTI.idEstatusCotizacion = ESCO.idEstatusCotizacion
										AND ORD.idZona = COALESCE(@idZona, idZona)
										AND COP.idOperacion = @idOperacion AND ORD.idEstatusOrden IN ( 4,5 ) 
										AND COTI.idTaller in (select idProveedor from @tablaProveedoresAsignados) ), 0 ) promedio,
								(CASE ESCO.idEstatusCotizacion
									WHEN 1 THEN '#d1fc35' 
									WHEN 2 THEN '#208021'  
									WHEN 3 THEN '#36c734' 
									ELSE '#80ff00' 
								END) color,
								Monto = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
														FROM [dbo].[Cotizaciones] C 
														INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
														INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
														INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
													WHERE C.idEstatusCotizacion = ESCO.idEstatusCotizacion
													AND CD.idEstatusPartida IN (1,2)
													AND CO.idOperacion = @idOperacion
													AND O.idZona = COALESCE(@idZona, idZona)
													AND O.idEstatusOrden IN (4,5) 
													AND C.idTaller in (select idProveedor from @tablaProveedoresAsignados) ),
								MontoCosto =( SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
														FROM [dbo].[Cotizaciones] C 
														INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
														INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
														INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
													WHERE	C.idEstatusCotizacion = ESCO.idEstatusCotizacion 
													AND CD.idEstatusPartida IN (1,2)
													AND CO.idOperacion = @idOperacion
													AND O.idZona = COALESCE(@idZona, idZona)
													AND O.idEstatusOrden IN (4,5) 
													AND C.idTaller in (select idProveedor from @tablaProveedoresAsignados))
							FROM EstatusCotizaciones ESCO WHERE idEstatusCotizacion <= 2;
							------------------------proveedor END------------------------
							END
					END
				ELSE
					BEGIN
					------------------------admin INI------------------------------
										SELECT 
						ESCO.idEstatusCotizacion idEstatus,
						ESCO.nombreEstatusCotizacion estatus,
						(SELECT COUNT(distinct ORD.idOrden) 
							FROM Cotizaciones				COTI
							INNER JOIN Ordenes				ORD  ON COTI.idOrden = ORD.idOrden
							INNER JOIN ContratoOperacion    COP  ON ORD.idContratoOperacion = COP.idContratoOperacion
							INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = COTI.idCotizacion
							WHERE 
								idEstatusCotizacion = ESCO.idEstatusCotizacion
								AND COP.idOperacion = @idOperacion
								AND ORD.idZona = COALESCE(@idZona, idZona)
								AND CD.idEstatusPartida IN (1,2)
								AND ORD.idEstatusOrden IN ( 4,5 )
							 ) total,
						ISNULL( (SELECT AVG( DATEDIFF(hour, fechaInicial, CURRENT_TIMESTAMP) ) 
							FROM Cotizaciones					  COTI
							INNER JOIN Ordenes					  ORD  ON COTI.idOrden = ORD.idOrden
							INNER JOIN ContratoOperacion		  COP  ON ORD.idContratoOperacion = COP.idContratoOperacion
							INNER JOIN HistorialEstatusCotizacion HEC  ON COTI.idCotizacion = HEC.idCotizacion AND COTI.idEstatusCotizacion = HEC.idEstatusCotizacion
							WHERE COTI.idEstatusCotizacion = ESCO.idEstatusCotizacion
								AND ORD.idZona = COALESCE(@idZona, idZona)
								AND COP.idOperacion = @idOperacion AND ORD.idEstatusOrden IN ( 4,5 ) ), 0 ) promedio,
						(CASE ESCO.idEstatusCotizacion
						  WHEN 1 THEN '#d1fc35' 
						  WHEN 2 THEN '#208021'  
						  WHEN 3 THEN '#36c734' 
						  ELSE '#80ff00' 
						END) color,
						Monto = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
												FROM [dbo].[Cotizaciones] C 
												INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
												INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
												INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
											WHERE C.idEstatusCotizacion = ESCO.idEstatusCotizacion AND
											 CD.idEstatusPartida IN (1,2) and
											 --C.idEstatusCotizacion in (1,2) AND
											 CO.idOperacion = @idOperacion
											AND O.idZona = COALESCE(@idZona, idZona)
											AND O.idEstatusOrden IN (4,5) ),
						MontoCosto =( SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
												FROM [dbo].[Cotizaciones] C 
												INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
												INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
												INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
											WHERE	C.idEstatusCotizacion = ESCO.idEstatusCotizacion AND
											 CD.idEstatusPartida IN (1,2) AND
											 --C.idEstatusCotizacion in (1,2) AND
											 CO.idOperacion = @idOperacion
											AND O.idZona = COALESCE(@idZona, idZona)
											AND O.idEstatusOrden IN (4,5) )											
					FROM EstatusCotizaciones ESCO 
					WHERE ESCO.idEstatusCotizacion IN(1,2)
					--SELECT * FROM EstatusCotizaciones
					--WHERE idEstatusCotizacion <= 2;
					------------------------admin END------------------------------
					END


			--END
		--ELSE
		--	BEGIN
		--		SELECT 
		--			ESCO.idEstatusCotizacion idEstatus,
		--			ESCO.nombreEstatusCotizacion estatus,
		--			(SELECT COUNT(COTI.idCotizacion) 
		--				FROM Cotizaciones				COTI
		--				INNER JOIN Ordenes				ORD  ON COTI.idOrden = ORD.idOrden
		--				INNER JOIN ContratoOperacion    COP  ON ORD.idContratoOperacion = COP.idContratoOperacion
		--				WHERE 
		--					idEstatusCotizacion = ESCO.idEstatusCotizacion
		--					AND COP.idOperacion = @idOperacion
		--					AND ORD.idEstatusOrden IN ( 4,5 )
		--					AND idZona = @idZona )  total,
		--			ISNULL( (SELECT AVG( DATEDIFF(hour, fechaInicial, CURRENT_TIMESTAMP) ) 
		--				FROM Cotizaciones					  COTI
		--				INNER JOIN Ordenes					  ORD  ON COTI.idOrden = ORD.idOrden
		--				INNER JOIN ContratoOperacion		  COP  ON ORD.idContratoOperacion = COP.idContratoOperacion
		--				INNER JOIN HistorialEstatusCotizacion HEC  ON COTI.idCotizacion = HEC.idCotizacion AND COTI.idEstatusCotizacion = HEC.idEstatusCotizacion
		--				WHERE 
		--					COTI.idEstatusCotizacion = ESCO.idEstatusCotizacion
		--					AND COP.idOperacion = @idOperacion
		--					AND ORD.idEstatusOrden IN ( 4,5 )
		--					AND idZona = @idZona ) , 0 ) promedio,
		--			(CASE ESCO.idEstatusCotizacion
		--			  WHEN 1 THEN '#d1fc35' 
		--			  WHEN 2 THEN '#208021'  
		--			  WHEN 3 THEN '#36c734' 
		--			  ELSE '#80ff00' 
		--			END) color,
		--			Monto = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
		--									FROM [dbo].[Cotizaciones] C 
		--									INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
		--									INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
		--									INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		--								WHERE C.idEstatusCotizacion = ESCO.idEstatusCotizacion
		--								AND CD.idEstatusPartida IN (1,2)
		--								AND O.idZona = @idZona
		--								AND CO.idContratoOperacion = @idOperacion
		--								AND O.idEstatusOrden IN (4,5) ) ,
		--			MontoCosto =( SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
		--									FROM [dbo].[Cotizaciones] C 
		--									INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
		--									INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
		--									INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		--								WHERE	C.idEstatusCotizacion = ESCO.idEstatusCotizacion 
		--								AND CD.idEstatusPartida IN (1,2)
		--								AND O.idZona = @idZona
		--								AND CO.idContratoOperacion = @idOperacion
		--								AND O.idEstatusOrden IN (4,5) ) 
		--		FROM EstatusCotizaciones ESCO WHERE idEstatusCotizacion <= 2;
		--	END	
	END
go

