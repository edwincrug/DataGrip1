



/*
	Fecha			Autor			Descripción
	28-Jun-2018		José Etmanuel	Se crea el SP que regresa los tipos de preguntas
	
	[Banorte].[GET_PROMOCIONES_CANJEADAS] 731
*/

CREATE PROCEDURE [Banorte].[GET_PREGUNTAS_FRECUENTES] 
AS
BEGIN

	SELECT 
			Id AS idPreguntaFrecuente,
			Nombre	AS titulo,
			Icono,
			(SELECT count([Id]) FROM [Banorte].[Preguntas] AS B WHERE B.[TipoPreguntasId] = T.Id) AS noPreguntas
	FROM [Banorte].[TipoPreguntas] AS T
END


go

grant execute, view definition on Banorte.GET_PREGUNTAS_FRECUENTES to DevOps
go

