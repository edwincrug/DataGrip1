
-- =============================================
-- Author:		<YJH>
-- Create date: <09/04/19>
-- Description:	<Inserta o Actualiza las cotizaciones>
/*
[Banorte].[UPD_NCOTIZACIONES] @idTipoUnidad=186, @idContratoUnidad=748, @idUsuarioPartidas = 59, @partidas = '<parte><idTipoPartida>1</idTipoPartida><partida>REVESTIMIE                                        </partida><marca>8</marca><noParte>6K4867011CSHDZ             </noParte><descripcion>REVESTIMIE                                        </descripcion><precioCompraR>2575.1</precioCompraR><precioCompraMano>2575.1</precioCompraMano><precioVenta>2085.83</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>2</idCotizacion><idCotizacionSisco>0</idCotizacionSisco><editCotizacion>false</editCotizacion></parte><parte><idTipoPartida>1</idTipoPartida><partida> PASSAT 2013                                      </partida><marca>8</marca><noParte>1325M3JGP62                </noParte><descripcion> PASSAT 2013                                      </descripcion><precioCompraR>17.42</precioCompraR><precioCompraMano>17.42</precioCompraMano><precioVenta>14.11</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>2</idCotizacion><idCotizacionSisco>0</idCotizacionSisco><editCotizacion>false</editCotizacion></parte><parte><idTipoPartida>1</idTipoPartida><partida> LITERATURA PASSAT 2016                           </partida><marca>8</marca><noParte>561012762AA
      </noParte><descripcion> LITERATURA PASSAT 2016                           </descripcion><precioCompraR>215.62</precioCompraR><precioCompraMano>215.62</precioCompraMano><precioVenta>174.65</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>2</idCotizacion><idCotizacionSisco>0</idCotizacionSisco><editCotizacion>false</editCotizacion></parte><parte><idTipoPartida>1</idTipoPartida><partida>REVESTIMIE                                        </partida><marca>8</marca><noParte>6K4867011CSHDZ             </noParte><descripcion>REVESTIMIE                                        </descripcion><precioCompraR>2575.1</precioCompraR><precioCompraMano>2575.1</precioCompraMano><precioVenta>2085.83</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>1</idCotizacion><idCotizacionSisco>54809</idCotizacionSisco><editCotizacion>false</editCotizacion><borrar>true</borrar></parte><parte><idTipoPartida>1</idTipoPartida><partida> PASSAT 2013                                      </partida><marca>8</marca><noParte>1325M3JGP62                </noParte><descripcion> PASSAT 2013                                      </descripcion><precioCompraR>17.42</precioCompraR><precioCompraMano>17.42</precioCompraMano><precioVenta>14.11</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>1</idCotizacion><idCotizacionSisco>54809</idCotizacionSisco><editCotizacion>false</editCotizacion><borrar>true</borrar></parte><parte><idTipoPartida>1</idTipoPartida><partida> LITERATURA PASSAT 2016                           </partida><marca>8</marca><noParte>561012762AA                </noParte><descripcion> LITERATURA PASSAT 2016                           </descripcion><precioCompraR>215.62</precioCompraR><precioCompraMano>215.62</precioCompraMano><precioVenta>174.65</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>1</idCotizacion><idCotizacionSisco>54809</idCotizacionSisco><editCotizacion>false</editCotizacion><borrar>true</borrar></parte>',
@idUsuario= 710, @idEstatusCotizacion=3, @idTipoCotizacion=1, @idOrden= 43991
*/
-- =============================================
CREATE PROCEDURE [Banorte].[UPD_NCOTIZACIONES_BK]
	@idTipoUnidad int,
	@idContratoUnidad int, 
	@idUsuarioPartidas int,
	@partidas XML, 
	
	@idOrden int,
	@idUsuario  NUMERIC(18,0),
	
	@idEstatusCotizacion int,
	@idTipoCotizacion int
AS
BEGIN

	--Tipos de partida
	DECLARE 
		@idEspecialidad int = 20,
		@idClasificacion int = 1, 
		@idSubClasificacion int =1, 
		@idPartida int=0, 
		@idContratoPartida int=0,
		@count int

	DECLARE 					
		@taller INT, 
		@idBproTaller int,
		@idTipoOrdenServicio NUMERIC(18,0)=1

	DECLARE 
		@cotizacionesIns as table (idCotizacion int, numeroCotizacion nvarchar(20), idCotizacionS int, tipo bit)		

	DECLARE @idEstatusPartida INT = 2

	declare @partes as table (idUnidad int , idTipoPartida int, partida nvarchar (50), marca nvarchar (200), noParte nvarchar (200),
			 descripcion nvarchar (max), idContratoUnidad int, precioCompraR decimal(18,2), precioCompraMano decimal(18,2), 
			 precioVenta decimal(18,2), tiempo nvarchar(8), isBackorder int, idPartida int, idCotizacion int, cantidad int,
			 idCotizacionSisco int, editCotizacion bit, borrar bit);
		
	BEGIN TRY
		BEGIN TRAN TranInsertaOrden

		INSERT INTO @partes 
			(idUnidad, idTipoPartida, partida, marca, noParte, descripcion, idContratoUnidad, precioCompraR, precioCompraMano, precioVenta,
			 tiempo, isBackorder, idCotizacion, cantidad, idCotizacionSisco, editCotizacion, borrar)
		   SELECT 
		    @idTipoUnidad, x.value('idTipoPartida[1]', 'INT'), x.value('partida[1]', 'nvarchar(50)'),
			x.value('marca[1]', 'nvarchar(200)'), x.value('noParte[1]', 'nvarchar(200)'), x.value('descripcion[1]', 'nvarchar(max)'), 		
			@idContratoUnidad, x.value('precioCompraR[1]', 'decimal(18,2)'), x.value('precioCompraMano[1]', 'decimal(18,2)'),
			x.value('precioVenta[1]', 'decimal(18,2)'), x.value('tiempo[1]', 'nvarchar(7)'), x.value('isBackorder[1]', 'bit'),
			x.value('idCotizacion[1]', 'int'), x.value('cantidad[1]', 'int'), x.value('idCotizacionSisco[1]', 'int'), 
			x.value('editCotizacion[1]', 'bit'), x.value('borrar[1]', 'bit')
		   FROM @partidas.nodes('//parte') partidas(x)				
		
		--1. Inserta partidas
		MERGE Partidas.dbo.Partida AS target  
		USING @partes AS source 
		ON (target.noParte = source.noParte and target.idUnidad = source.idUnidad)
		WHEN NOT MATCHED THEN  
			INSERT (idUnidad, idTipoPartida, idEspecialidad, idPartidaClasificacion, idPartidaSubClasificacion, partida, marca, noParte, 
			        descripcion, foto, instructivo, estatus)  
			VALUES (source.idUnidad, source.idTipoPartida, @idEspecialidad, @idClasificacion, @idSubClasificacion, source.partida,
				    source.marca, source.noParte, source.descripcion,'', '', 1)		
		;
				
		UPDATE @partes SET idPartida = PP.idPartida FROM @partes AS P
			INNER JOIN Partidas.dbo.Partida AS PP ON P.noParte = PP.noParte and P.idUnidad = PP.idUnidad			

		MERGE Partidas.dbo.ContratoPartida AS target  
		USING @partes AS source 
		ON (target.idPartida = source.idPartida and target.idContratoUnidad = source.idContratoUnidad and source.idPartida <> 0 )
		WHEN NOT MATCHED THEN  
			INSERT (idContratoUnidad, idPartida, venta, fecha, idUsuario, precio1, precio2, precio3, precio4, precio5, precio6, precio7,
			        precioMano, precioRefaccion, precioLubricante, tiempo, precio7Respaldo)
			VALUES (source.idContratoUnidad, source.idPartida, source.precioVenta, GETDATE(), @idUsuarioPartidas, source.precioCompraR,
			        source.precioCompraR, source.precioCompraR, source.precioCompraR, source.precioCompraR, source.precioCompraR, 
					source.precioCompraR, source.precioCompraMano, source.precioCompraR, 0.00, CAST(source.tiempo AS TIME), 0.00)
		;
			
		select @taller= idTaller, @idBproTaller= idBproProveedor, @idTipoOrdenServicio = idCatalogoTipoOrdenServicio 
		from ASEPROT.dbo.Ordenes where idOrden = @idOrden				
		
		-- 3. Inserta cotizaciones 
		declare @id int
		set @id=1; 
		declare @len int, @consecutivoCotizacion int, @idCotizacion int, @idAutorizacionCot int, @idC int=1, @editar bit
		select @len= COUNT(distinct idCotizacion) from @partes 
		
		--select * from @partes 
		while (@id < = @len)
		begin 
			set @consecutivoCotizacion=0
			set @idCotizacion=0
			set @idAutorizacionCot=0
			set @idC=1
						
			if ( (select top 1 idCotizacionSisco from @partes where idCotizacion = @id) = 0)
			begin 				
				IF (EXISTS(SELECT TOP 1 consecutivoCotizacion FROM ASEPROT.dbo.Cotizaciones WHERE idOrden = @idOrden))			
					SET @consecutivoCotizacion = (SELECT TOP 1 consecutivoCotizacion FROM ASEPROT.dbo.Cotizaciones WHERE idOrden = @idOrden ORDER BY consecutivoCotizacion DESC) +1
				ELSE
					SET @consecutivoCotizacion = 1			
			
				INSERT INTO ASEPROT.dbo.Cotizaciones 
				(fechaCotizacion, idTaller, idUsuario, idEstatusCotizacion, idOrden, numeroCotizacion, consecutivoCotizacion,
				idCatalogoTipoOrdenServicio, idPreorden, idBproProveedor, idTipoCotizacion) VALUES
				(GETDATE(), @taller, @idUsuario, @idEstatusCotizacion, @idOrden, @idOrden+'-'+CONVERT (varchar(5), @consecutivoCotizacion),
				@consecutivoCotizacion,@idTipoOrdenServicio,null, @idBproTaller, @idTipoCotizacion)
		
				SET @idCotizacion = @@IDENTITY 
			
				while (@idC <= @idEstatusCotizacion)
				begin 
					INSERT INTO ASEPROT.dbo.HistorialEstatusCotizacion (fechaInicial,idCotizacion,idUsuario,idEstatusCotizacion)
					VALUES (GETDATE(), @idCotizacion, @idUsuario, @idC)			
					
					set @idC = @idC + 1;
				end 			

				INSERT INTO ASEPROT.dbo.AutorizacionCotizacion (fechaNotificacion, fechaAutorizacion, idCotizacion)
				VALUES (GETDATE(), GETDATE(), @idCotizacion)
				
				SET @idAutorizacionCot = @@IDENTITY
			end 
			else 
			begin 
				select top 1 @idCotizacion = idCotizacionSisco, @editar=editCotizacion from @partes where idCotizacion = @id
				select @idAutorizacionCot = idAutorizacionCotizacion from ASEPROT.dbo.AutorizacionCotizacion where idCotizacion = @idCotizacion
			end 			
			--4. Inserta detalle de cotizacion 					
			MERGE ASEPROT.dbo.CotizacionDetalle AS target  			
			USING (SELECT precioCompraR, cantidad, precioVenta, idPartida, precioCompraMano, editCotizacion from @partes where idCotizacion = @id)
			 AS SOURCE (precioCompraR, cantidad, precioVenta, idPartida, precioCompraMano, editCotizacion)
			ON (target.idPartida = source.idPartida and target.idCotizacion = @idCotizacion)
			WHEN MATCHED THEN   
				UPDATE SET costo = source.precioCompraR, venta=source.precioVenta, cantidad=source.cantidad, solicitadasOrg= source.cantidad				
			WHEN NOT MATCHED BY SOURCE and (target.idCotizacion = @idCotizacion and @editar = 1 ) THEN		
				DELETE
			WHEN NOT MATCHED THEN  
				INSERT (idCotizacion, costo, cantidad, venta, idPartida, idEstatusPartida, rechazadas, solicitadasOrg, precioLista)  
				VALUES (@idCotizacion, source.precioCompraR, source.cantidad, source.precioVenta, source.idPartida, @idEstatusPartida, 0,
						source.cantidad, source.precioCompraMano)		
			;			
			
			DELETE DAC FROM ASEPROT.dbo.DetalleAutorizacionCotizacion DAC
			INNER JOIN ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacionDetalle = DAC.idCotizacionDetalle
			where CD.idCotizacion = @idCotizacion and CD.idPartida in ( select idPartida from @partes where idCotizacion = @id and borrar=1) 			

			delete from ASEPROT.dbo.CotizacionDetalle where idCotizacion = @idCotizacion and idPartida in ( select idPartida from @partes where idCotizacion = @id and borrar=1)

			if ( (select count(*) from ASEPROT.dbo.CotizacionDetalle where idCotizacion = @idCotizacion) =0)
			begin -- borrar relaciones sisre
				declare @idCS int = 0
				
				delete from ASEPROT.dbo.AutorizacionCotizacion where idCotizacion= @idCotizacion
				delete from ASEPROT.dbo.HistorialEstatusCotizacion where idCotizacion=@idCotizacion
				delete from ASEPROT.dbo.Cotizaciones where idCotizacion = @idCotizacion
				
				select @idCS = idCotizacion from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion where idCotizacionSISCO= @idCotizacion
				
				delete from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion where idCotizacion = @idCS
				delete from RefaccionMultiMarca.Operacion.CotizacionDetalle where idCotizacion = @idCS								
				delete from RefaccionMultiMarca.Operacion.Cotizacion where idCotizacion = @idCS				
			end 
			--INSERT INTO ASEPROT.dbo.DetalleAutorizacionCotizacion 
			--select GETDATE(), @idUsuario, @idAutorizacionCot, @idEstatusPartida, idCotizacionDetalle from 
			--ASEPROT.dbo.CotizacionDetalle where idCotizacion = @idCotizacion							

			insert into @cotizacionesIns 
			select idCotizacion, numeroCotizacion, @id, (select top 1 isBackorder from @partes where idCotizacion = @id) 
				from ASEPROT.dbo.Cotizaciones where idCotizacion = @idCotizacion

			set @id= @id+1;
		end
		select * from @cotizacionesIns

		select CI.idCotizacion,P.noParte from @cotizacionesIns CI 
		inner join ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = CI.idCotizacion
		inner join Partidas.dbo.Partida P on P.idPartida = CD.idPartida

		COMMIT TRAN TranInsertaOrden			

	END TRY
	BEGIN CATCH
		ROLLBACK TRAN TranInsertaOrden
		SELECT ERROR_NUMBER() AS Number,
	           ERROR_SEVERITY() AS Severity,
			   ERROR_STATE() AS [State],
			   ERROR_PROCEDURE() AS [Procedure],
			   ERROR_LINE() AS Line,
			   ERROR_MESSAGE() AS [Message]
	END CATCH	
END
go

