CREATE PROCEDURE [dbo].[SEL_PERMISOS_USUARIOS_SP]
@usuario varchar(50)
,@contrasenia varchar(50)

AS
BEGIN
	SELECT
		Ope.idOperacion
		,Ope.nombreOperacion 
		,Usu.idUsuario
		,Usu.nombreUsuario
		,CaRo.nombreCatalogoRol
		-- ,
	FROM [dbo].[ContratoOperacionUsuario] CoOpUs
		INNER JOIN CatalogoRoles CaRo	ON CaRo.idCatalogoRol = CoOpUs.idCatalogoRol
		INNER JOIN Usuarios Usu ON Usu.idUsuario = CoOpUs.idUsuario
		INNER JOIN ContratoOperacion ContOpe ON ContOpe.idContratoOperacion = CoOpUs.idContratoOperacion
		INNER JOIN Operaciones Ope ON Ope.idOperacion = ContOpe.idOperacion
	WHERE	Usu.nombreUsuario = @usuario AND Usu.contrasenia = @contrasenia
END

go

