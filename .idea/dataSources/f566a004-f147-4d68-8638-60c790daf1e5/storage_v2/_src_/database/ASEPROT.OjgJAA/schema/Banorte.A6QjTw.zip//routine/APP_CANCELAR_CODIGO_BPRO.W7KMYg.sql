
/*
	Objetivo: Marcar com ocancelado un código.

	Fecha			Autor			Descripción
	27-JuL-2018		José Etmanuel	Se crea el SP para cancelar codigo de promoción desde BPro
	31-Jul-2018		José Etmanuel	Cambio la salida por una variable OUTPUT

	declare @ok int;
	EXEC [Banorte].[APP_CANCELAR_CODIGO_BPRO] 816765,'N0023032',@ok OUTPUT
	SELECT @ok status
*/

CREATE PROCEDURE [Banorte].[APP_CANCELAR_CODIGO_BPRO] 
	@codigo varchar(max),
	@idOrdenBpro varchar(max),
	@status int OUTPUT 
AS   
BEGIN
	declare @mensaje varchar(max)= 'El código no se pudo cancelar';
	SET @status = 0;

	IF EXISTS (SELECT * FROM [Banorte].[PromocionesCodigosDet] WHERE  [Codigo]= @codigo AND [IdOrdenBpro] = @idOrdenBpro AND isnull(BCancelBpro,0) != 1)
	BEGIN
		UPDATE [PromocionesCodigos] 
			SET [Aplicadas] = ([Aplicadas] - 1)
			WHERE [Codigo]= @codigo

		
		SET @mensaje = 'Código cancelado';
		SET @status = 1;
		
		UPDATE [Banorte].[PromocionesCodigosDet] 
			SET BCancelBpro = 1
		WHERE  [Codigo]= @codigo AND [IdOrdenBpro] = @idOrdenBpro AND isnull(BCancelBpro,0)!= 1
	END
	
	ELSE
	BEGIN
		SET @mensaje = 'No se encontró el código con esa órden';
	END
	
END
go

grant execute, view definition on Banorte.APP_CANCELAR_CODIGO_BPRO to DevOps
go

