    
-- =============================================    
-- Author:  <Jose Luis Lozada Guerrero>    
-- Create date: <30/12/2019>    
-- Description: <Procedimiento para obtener los datos de una orden >    
/* 
	DECLARE @err varchar(max)   
	EXEC SEL_ORDEN_PF_SP 
		@idOrden = 9934, 
		@err = @err out
	print 'Error: ' + @err

*/    
    
-- =============================================    

CREATE PROCEDURE [dbo].[SEL_ORDEN_PF_SP]
	@idOrden	int = null,
	@idUsuario	int = null,
	@err varchar(max) out
AS    
BEGIN    

	set @err = ''
	--DATOS ENCABEZADO

	select 
		ord.idOrden									idOrden
		,ord.numeroOrden							numeroOrden
		,convert(varchar,ord.fechaCreacionOden,13)  fechaCreacionOrden
		,ord.fechaCita								fechaCita
		,zon.nombre									zona
		,usu.nombreCompleto							nombreUsuario
		,uni.idUnidad								idUnidad
		,uni.placas									placas
		,uni.vin									vin
		,uni.numeroEconomico
		,uni.modelo								
		--DATOS DE TIPO UNIDAD
		,tu.tipo									tipoUnidad
		,tc.tipoCombustible							combustible
		,cil.cilindros								cilindros
		,mar.nombre									marca
		,sub.nombre									submarca
		--TOTALES				
		,sum(cotdet.cantidad)						totalPartidas
		,sum(cotdet.cantidad*cotdet.venta)			subtotal
		,(sum(cotdet.cantidad*cotdet.venta))*0.16	IVA
		,(sum(cotdet.cantidad*cotdet.venta))*1.16	total
		--DATOS DE ESTATUS	
		,ISNULL((
			select top 1 CONVERT(VARCHAR,fechaInicial,13) from HistorialEstatusOrden his where his.idOrden = ord.idOrden and idEstatusOrden = 5
		),'')											fechaAprobacion
		,ISNULL((
			select top 1 usuaux.nombreCompleto  from HistorialEstatusOrden his 
			inner join Usuarios usuaux on his.idUsuario = usuaux.idUsuario
			where his.idOrden = ord.idOrden and idEstatusOrden = 5
		),'')											usuarioAprobacion
		,ISNULL((
			select top 1 CONVERT(VARCHAR,fechaInicial,13) from HistorialEstatusOrden his where his.idOrden = ord.idOrden and idEstatusOrden = 8
		),'')											fechaEntrega
		,case 
			when idEstatusOrden between 1 and 4 then 'En Aprobación'
			when idEstatusOrden between 5 and 6 then 'En Proceso'
			when idEstatusOrden between 7 and 12 then 'Entregada'
		end											estatus

	from Ordenes ord
	inner join Unidades uni on ord.idUnidad = uni.idUnidad
	inner join Cotizaciones cot on cot.idOrden = ord.idOrden
	inner join CotizacionDetalle cotdet on cot.idCotizacion = cotdet.idCotizacion
	left join Partidas.dbo.Zona zon on zon.idZona = ord.idZona
	left join Usuarios usu on ord.idUsuario = usu.idUsuario

	--DATOS DE LA UNIDAD
	inner join Partidas.dbo.Unidad uniPar on uniPar.idUnidad = uni.idTipoUnidad
	inner join Partidas.dbo.TipoUnidad tu on tu.idTipoUnidad = uniPar.idTipoUnidad
	inner join Partidas.dbo.TipoCombustible tc on uniPar.idTipoCombustible = tc.idTipoCombustible
	inner join Partidas.dbo.Cilindros cil on cil.idCilindros = uniPar.idCilindros
	inner join Partidas.dbo.SubMarca sub on sub.idSubMarca = uniPar.idSubMarca
	inner join Partidas.dbo.Marca mar on mar.idMarca = sub.idMarca

	where
		ord.idOrden=@idOrden
		and ord.idEstatusOrden not in (13,15,15)
		and cot.idEstatusCotizacion not in (4)
		and cotdet.idEstatusPartida = 2

	GROUP BY 
		ord.idOrden									
		,ord.numeroOrden							
		,ord.fechaCreacionOden						
		,ord.fechaCita								
		,zon.nombre
		,usu.nombreCompleto
		,uni.idUnidad								
		,uni.placas									
		,uni.vin
		,uni.numeroEconomico
		,uni.modelo									
		--DATOS DE TIPO UNIDAD
		,tu.tipo									
		,tc.tipoCombustible							
		,cil.cilindros								
		,mar.nombre									
		,sub.nombre		
		,ord.idEstatusOrden							

	--DETALLE PARTIDAS
	declare @partidas table(
		partida	varchar(max)
	)

	insert into @partidas
	select 
		convert(varchar,cotdet.cantidad) + ' ' +
		par.descripcion + ' '
	from Ordenes ord
	inner join Cotizaciones cot on cot.idOrden = ord.idOrden
	inner join CotizacionDetalle cotdet on cot.idCotizacion = cotdet.idCotizacion
	inner join Partidas.dbo.Partida par on par.idPartida = cotdet.idPartida
	where 
		ord.idOrden=@idOrden
		and ord.idEstatusOrden not in (13,15,16)
		and cot.idEstatusCotizacion not in (4)
		and cotdet.idEstatusPartida = 2

	/*select * from @partidas*/

	SELECT  STUFF(( SELECT ', ' + par.partida
                FROM @partidas par
              FOR
                XML PATH('')
              ), 1, 1, '') AS partidas
	
END



go

