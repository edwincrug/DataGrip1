/*
SELECT * FROM Ordenes WHERE idOrden=232
SELECT * FROM Cotizaciones WHERE idOrden=232 
SELECT * FROM facturaCotizacion
select * from Cotizaciones where idCotizacion=78
select * from [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERENC]
SELECT * FROM Ordenes WHERE numeroOrden='01-310035-61'
SELECT * FROM [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = '01-310035-61'
*/
-- [UPD_PROVISION_POR_ORDEN_SP] 230, 1, 600, 1016, 0, 1, 0, 538, 24, '3180.00', '17256.83', '0', '1616'
CREATE PROCEDURE [dbo].[UPD_PROVISION_POR_ORDEN_SP]
	@ident NUMERIC(18,0),
	@consecutivo NUMERIC(18,0),
	@manoObra NVARCHAR(MAX),
	@refaccion NVARCHAR(MAX),
	@lubricante NVARCHAR(MAX),
	@idOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0),
	@idUsuario NUMERIC(18,0),
	@idOrden NUMERIC(18,0),
	@subTotalMO NVARCHAR(MAX),
	@subTotalREF NVARCHAR(MAX),
	@subTotalLUB NVARCHAR(MAX),
	@precioVenta NVARCHAR(MAX)

AS
BEGIN

DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE @encabezadoProvision NVARCHAR(MAX)
DECLARE @updDetalleProvision NVARCHAR(MAX)
DECLARE @tablaValor TABLE (IDENT NVARCHAR(MAX))
DECLARE @valorIdent NVARCHAR(MAX)
DECLARE @insTempSub NVARCHAR(MAX)
DECLARE @ote_submo NVARCHAR(MAX)
DECLARE @ote_subref NVARCHAR(MAX)
DECLARE @ote_sublub NVARCHAR(MAX)
DECLARE @ote_ident int
DECLARE @updateEncabezadoO NVARCHAR(MAX)
DECLARE @queryupdateEncTot NVARCHAR(MAX)

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DBProduccion
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END

DECLARE @numeroOrden NVARCHAR(100)

SELECT @numeroOrden=numeroOrden FROM Ordenes WHERE idOrden=@idOrden

if ((select case when not exists (select 1 from Cotizaciones C1 where C1.idOrden = @idOrden and C1.idTaller in (select idProveedor from Partidas..Proveedor  where razonSocial like '%TOTAL PARTS AND COMPONENTS%')) then 1 else 0 end) = 1)
--si el taller de la cotizacion no es total parts
	BEGIN
		declare @queryText varchar(max) = 
		'SELECT CASE WHEN exists(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = '''+@numeroOrden+''') then 1 else 0 end' + char(13) + 
		'' 

		declare @tabletemp table(val int)
		insert into @tabletemp exec(@queryText) 

		IF ((select top 1 val from @tabletemp) = 1)
			BEGIN
				SET @encabezadoProvision = 
				'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE OTE_IDENT = ' + ''+CAST(@ident AS NVARCHAR(30))+' AND OTE_ORDENANDRADE = ' + ''''+@numeroOrden+''''
				INSERT INTO @tablaValor
				EXECUTE SP_EXECUTESQL @encabezadoProvision
				SELECT @valorIdent = IDENT FROM @tablaValor
				IF(CAST(@valorIdent AS NVARCHAR(30)) = CAST(@ident AS NVARCHAR(30)))
					BEGIN
						SET @updDetalleProvision = 
						'UPDATE '+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET] 
							SET OTD_MO = ' + @manoObra + ',
							OTD_REF = ' + @refaccion + ',
							OTD_LUB = ' + @lubricante  + ',
							OTD_PRECIOUNITARIOVENTA = ' + @precioVenta  + '
							WHERE OTD_IDENT = ' + CAST(@valorIdent AS NVARCHAR(30)) + ' AND OTD_CONSECUTIVO = ' + CAST(@consecutivo AS NVARCHAR(30)) + ''
						EXECUTE SP_EXECUTESQL @updDetalleProvision
						
						CREATE TABLE #sumatorias (OTE_IDENT INT NOT NULL, OTE_MO NVARCHAR(MAX), OTE_REF NVARCHAR(MAX), OTE_LUB NVARCHAR(MAX))
						
						SET @insTempSub = 
						'INSERT INTO #sumatorias 
						SELECT OTD_IDENT 
						,SUM(OTD_CANTIDAD*OTD_MO) 
						,SUM(OTD_CANTIDAD*OTD_REF) 
						,SUM(OTD_CANTIDAD*OTD_LUB) 						 
						FROM ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET] D
						INNER JOIN ' + @server + '.' + @db + '.dbo.[ADE_ORDSERENC] E ON D.OTD_IDENT = E.OTE_IDENT
						WHERE E.OTE_ORDENANDRADE = ' + ''''+@numeroOrden+''''+'
						GROUP BY OTD_IDENT';
						
						EXECUTE SP_EXECUTESQL @insTempSub
						
						DECLARE contact_cursor CURSOR FOR
							SELECT * FROM #sumatorias
						
						OPEN contact_cursor
						FETCH NEXT FROM contact_cursor INTO @ote_ident, @ote_submo, @ote_subref, @ote_sublub
						WHILE @@FETCH_STATUS = 0
							BEGIN

								set @updateEncabezadoO = 
								'UPDATE '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC]
									SET OTE_SUBMO = ' + @ote_submo + ',
									OTE_SUBREF = ' + @ote_subref + ',
									OTE_SUBLUB = ' + @ote_sublub + '
									WHERE OTE_IDENT = ' + CAST(@ote_ident AS NVARCHAR(30)) + ''

									EXECUTE SP_EXECUTESQL @updateEncabezadoO

								FETCH NEXT FROM contact_cursor INTO @ote_ident, @ote_submo, @ote_subref, @ote_sublub
							END
						CLOSE contact_cursor
						DEALLOCATE contact_cursor

						SET @queryupdateEncTot = 'UPDATE  ENC
							SET 
							ENC.OTE_SUBMO = OK.MANO,
							ENC.OTE_SUBREF = OK.REFA,
							ENC.OTE_SUBLUB = OK.LUB
							FROM '+@server+'.'+@db+'.dbo.ADE_ORDSERENC ENC
							INNER JOIN (
							SELECT SUM(B.OTE_SUBMO) MANO,
							SUM(B.OTE_SUBREF) REFA, 
							SUM(B.OTE_SUBLUB) LUB,
							B.OTE_ORDENGLOBAL
							FROM '+@server+'.'+@db+'.dbo.ADE_ORDSERENC B
							INNER JOIN 
							(SELECT OTE_ORDENGLOBAL, 
							CASE
								 WHEN count(OTE_ORDENGLOBAL) > 1 THEN 
									 1 END S 
							FROM '+@server+'.'+@db+'.dbo.ADE_ORDSERENC group by OTE_ORDENGLOBAL) A ON A.OTE_ORDENGLOBAL = B.OTE_ORDENGLOBAL AND A.S is not null
							WHERE B.OTE_ORDENGLOBAL = '+ ''''+@numeroOrden+'''' +'
							group by B.OTE_ORDENGLOBAL 
							) OK ON OK.OTE_ORDENGLOBAL = ENC.OTE_ORDENGLOBAL'
            
							EXECUTE SP_EXECUTESQL @queryupdateEncTot

							DROP TABLE #sumatorias
					END
			END
		ELSE
			BEGIN
				SELECT 0 Success, 'No existe provision para esta orden ' + @numeroOrden Msg
			END
	END
ELSE
-- si el taller es total parts
	BEGIN
		print 'entra en 2'
		declare @idProveedor int = (select top 1 idTaller from Cotizaciones where idOrden = @idOrden and idEstatusCotizacion not in (5))

		IF(@isProduction = 1)
			BEGIN
			SELECT 
						@server = SERVER,
						@db = DBProduccion
				FROM CatalogoTecnico CT 
				WHERE CT.IdProveedor =  @idProveedor
			END
		ELSE
			BEGIN
				SELECT 
						@server = SERVER,
						@db = DBProduccion
				FROM CatalogoTecnico CT 
				WHERE CT.IdProveedor =  @idProveedor
			END

		declare @queryText2 varchar(max) = 
		'SELECT CASE WHEN exists(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = '''+@numeroOrden+''') then 1 else 0 end' + char(13) + 
		'' 
		PRINT @queryText2
		declare @tabletemp2 table(val int)
		insert into @tabletemp2 exec(@queryText2) 

		IF ((select top 1 val from @tabletemp2) = 1)
			BEGIN
				SET @updDetalleProvision = 'SELECT * FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = ' + ''''+@numeroOrden+''''
				PRINT @updDetalleProvision
				exec @updDetalleProvision
			END
		ELSE
			BEGIN
				SELECT 0 Success, 'No existe provision para esta orden ' + @numeroOrden Msg
			END
	END
END
go

