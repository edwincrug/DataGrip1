
create PROCEDURE [dbo].[UPD_PRE_CANCELA_ORDEN_SP]
	@idUsuario numeric(18, 0), 
	@idOrden numeric(18,0),
	@comentario varchar(500)
AS
BEGIN 
	DECLARE @existeOrden numeric(18,0)
	DECLARE @existeCancelaciones numeric(18, 0)
	DECLARE @idOrdenCancelacion int
	
	SELECT @existeOrden= COUNT(1) FROM Ordenes where idOrden=@idOrden
	SELECT @existeCancelaciones= COUNT(1) FROM PreCancelacionOrdenes where idOrden=@idOrden

	IF(@existeOrden>0 AND @existeCancelaciones<1)
	BEGIN
		INSERT INTO PreCancelacionOrdenes([idOrden]) VALUES(@idOrden);
		Select @idOrdenCancelacion= idCancelacion from PreCancelacionOrdenes where idOrden= @idOrden
		INSERT INTO PreCancelacionDetalle(idCancelacion, fechaCancelacion, idUsuario, comentarioPreCancelacion) values(@idOrdenCancelacion, GetDate(), @idUsuario, @comentario)
	END
		SELECT 10
END
go

