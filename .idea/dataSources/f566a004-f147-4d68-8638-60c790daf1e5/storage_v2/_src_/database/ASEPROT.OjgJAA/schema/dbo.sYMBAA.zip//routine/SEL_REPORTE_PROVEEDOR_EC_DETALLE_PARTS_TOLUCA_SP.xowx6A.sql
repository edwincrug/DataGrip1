-- =============================================
-- Author:		<Alan Rosales Chávez>
-- Create date: <07/11/2017>
-- Description:	<Estado de cuenta por proveedor>
-- =============================================
--SEL_REPORTE_PROVEEDOR_EC_DETALLE_PARTS_TOLUCA_SP '3','683','FACTURADO'
CREATE PROCEDURE [dbo].[SEL_REPORTE_PROVEEDOR_EC_DETALLE_PARTS_TOLUCA_SP]
	@idOperacion	numeric(18,0),
	@idProveedor	numeric(18,0),
	@tipoDetalle	nvarchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--****************************************************************************************************************
	--***********************************************TOTAL ABONADAS***************************************************
	--****************************************************************************************************************

	if @tipoDetalle = 'FACTURAS ABONADAS'
	BEGIN
		
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			DC.numeroCopade,
			DC.fechaRecepcionCopade,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from report.EC_DETALLEGAT_PARTSTOLUCA R

		inner join DatosCopadeOrden DCO on DCO.idOrden = R.idOrden
		left join DatosCopade DC ON DC.idDatosCopade = DCO.idDatosCopade
		inner join OrdenAgrupadaDetalle OAD on OAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
		inner join OrdenAgrupada OA on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
		inner join OrdenGlobalAbono OGA on OGA.numeroOrdenGlobal = OA.numero
		inner join Ordenes o on o.idOrden = R.idOrden

		inner join Unidades U on O.idUnidad = U.idUnidad
		inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
		inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
		inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN IN (11)
			AND R.SALDO >0
			and R.idProveedor = @idProveedor	
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			DC.numeroCopade,
			DC.fechaRecepcionCopade,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
		
	END
	
	if @tipoDetalle = 'SELECCION ABONOS'
	BEGIN

		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			DC.numeroCopade,
			DC.fechaRecepcionCopade,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
			
		from report.EC_DETALLEGAT_PARTSTOLUCA R

		inner join DatosCopadeOrden DCO on DCO.idOrden = R.idOrden
		left join DatosCopade DC ON DC.idDatosCopade = DCO.idDatosCopade
		inner join OrdenAgrupadaDetalle OAD on OAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
		inner join OrdenAgrupada OA on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
		left join OrdenGlobalAbono OGA on OGA.numeroOrdenGlobal = OA.numero
		inner join Ordenes o on o.idOrden = R.idOrden
		inner join Unidades U on O.idUnidad = U.idUnidad
		inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
		inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
		inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN IN (11)
			AND R.SALDO >0
			and OGA.numeroOrdenGlobal is null
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			DC.numeroCopade,
			DC.fechaRecepcionCopade,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	END

	if @tipoDetalle = 'PAGADO'
	BEGIN

		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from report.EC_DETALLEGAT_PARTSTOLUCA R
			inner join Ordenes o on o.idOrden = R.idOrden
			inner join Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN NOT IN (1,2,3,4,13)
			AND R.SALDO = 0
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	END

	if @tipoDetalle = 'FACTURADO'
	BEGIN
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from report.EC_DETALLEGAT_PARTSTOLUCA R
			inner join Ordenes o on o.idOrden = R.idOrden
			inner join Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN NOT IN (1,2,3,4,11,12,13)
			AND R.SALDO >0
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
		
	END

	if @tipoDetalle = 'POR FACTURAR'
	BEGIN
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from report.EC_DETALLEGAT_PARTSTOLUCA R
			inner join Ordenes o on o.idOrden = R.idOrden
			inner join Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN NOT IN (1,2,3,4,13) AND 
			R.FACTURA IS NULL --unicamente lo que tenemos en SISCO
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	END

	if @tipoDetalle = 'TRABAJADO'
	BEGIN
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from report.EC_DETALLEGAT_PARTSTOLUCA R
			inner join Ordenes o on o.idOrden = R.idOrden
			inner join Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where R.IDESTATUSORDEN NOT IN (1,2,3,4,13)
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	end

	if @tipoDetalle = 'FINALIZADO'
	BEGIN
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from report.EC_DETALLEGAT_PARTSTOLUCA R
			inner join Ordenes o on o.idOrden = R.idOrden
			inner join Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN IN (12)
			AND R.SALDO >0
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	END
	if @tipoDetalle = 'FACTURAS ABONADAS AFO'
	BEGIN
		
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			DC.numeroCopade,
			DC.fechaRecepcionCopade,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from [ASEPROTSISCO].[report].EC_DETALLE R

		inner join [ASEPROTSISCO].[dbo].DatosCopadeOrden DCO on DCO.idOrden = R.idOrden
		inner join [ASEPROTSISCO].[dbo].DatosCopade DC ON DC.idDatosCopade = DCO.idDatosCopade
		inner join [ASEPROTSISCO].[dbo].OrdenAgrupadaDetalle OAD on OAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
		inner join [ASEPROTSISCO].[dbo].OrdenAgrupada OA on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
		inner join [ASEPROTSISCO].[dbo].OrdenGlobalAbono OGA on OGA.numeroOrdenGlobal = OA.numero
		inner join [ASEPROTSISCO].[dbo].Ordenes o on o.idOrden = R.idOrden

		inner join [ASEPROTSISCO].[dbo].Unidades U on O.idUnidad = U.idUnidad
		inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
		inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
		inner join [ASEPROTSISCO].[dbo].EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN IN (11)
			AND R.SALDO >0
			and R.idProveedor = @idProveedor	
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			DC.numeroCopade,
			DC.fechaRecepcionCopade,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
		
	END
	
	if @tipoDetalle = 'SELECCION ABONOS AFO'
	BEGIN

		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			DC.numeroCopade,
			DC.fechaRecepcionCopade,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
			
		from [ASEPROTSISCO].[report].EC_DETALLE R

		inner join [ASEPROTSISCO].[dbo].DatosCopadeOrden DCO on DCO.idOrden = R.idOrden
		inner join [ASEPROTSISCO].[dbo].DatosCopade DC ON DC.idDatosCopade = DCO.idDatosCopade
		inner join [ASEPROTSISCO].[dbo].OrdenAgrupadaDetalle OAD on OAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
		inner join [ASEPROTSISCO].[dbo].OrdenAgrupada OA on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
		left join [ASEPROTSISCO].[dbo].OrdenGlobalAbono OGA on OGA.numeroOrdenGlobal = OA.numero
		inner join [ASEPROTSISCO].[dbo].Ordenes o on o.idOrden = R.idOrden
		inner join [ASEPROTSISCO].[dbo].Unidades U on O.idUnidad = U.idUnidad
		inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
		inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
		inner join [ASEPROTSISCO].[dbo].EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN IN (11)
			AND R.SALDO >0
			and OGA.numeroOrdenGlobal is null
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			DC.numeroCopade,
			DC.fechaRecepcionCopade,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
		
	END

	if @tipoDetalle = 'PAGADO AFO'
	BEGIN

		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from [ASEPROTSISCO].[report].EC_DETALLE R
			inner join [ASEPROTSISCO].[dbo].Ordenes o on o.idOrden = R.idOrden
			inner join [ASEPROTSISCO].[dbo].Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join [ASEPROTSISCO].[dbo].EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN NOT IN (1,2,3,4,13)
			AND R.SALDO = 0
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	END

	if @tipoDetalle = 'FACTURADO AFO'
	BEGIN
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from [ASEPROTSISCO].[report].EC_DETALLE R
			inner join [ASEPROTSISCO].[dbo].Ordenes o on o.idOrden = R.idOrden
			inner join [ASEPROTSISCO].[dbo].Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join [ASEPROTSISCO].[dbo].EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN NOT IN (1,2,3,4,11,12,13)
			AND R.SALDO >0
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	END

	if @tipoDetalle = 'POR FACTURAR AFO'
	BEGIN
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from [ASEPROTSISCO].[report].EC_DETALLE R
			inner join [ASEPROTSISCO].[dbo].Ordenes o on o.idOrden = R.idOrden
			inner join [ASEPROTSISCO].[dbo].Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join [ASEPROTSISCO].[dbo].EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN NOT IN (1,2,3,4,13) AND 
			R.FACTURA IS NULL --unicamente lo que tenemos en SISCO
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	END

	if @tipoDetalle = 'TRABAJADO AFO'
	BEGIN
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from [ASEPROTSISCO].[report].EC_DETALLE R
			inner join [ASEPROTSISCO].[dbo].Ordenes o on o.idOrden = R.idOrden
			inner join [ASEPROTSISCO].[dbo].Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join [ASEPROTSISCO].[dbo].EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where R.IDESTATUSORDEN NOT IN (1,2,3,4,13)
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	end

	if @tipoDetalle = 'FINALIZADO AFO'
	BEGIN
		select
			R.NOMBRECOMERCIAL razonSocial,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre tipoUnidad,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			SUM(R.total) total,
			EO.nombreEstatusOrden,
			R.factura numeroFactura,
			R.saldo,
			O.numeroOrden hojaTrabajo
		from [ASEPROTSISCO].[report].EC_DETALLE R
			inner join [ASEPROTSISCO].[dbo].Ordenes o on o.idOrden = R.idOrden
			inner join [ASEPROTSISCO].[dbo].Unidades U on O.idUnidad = U.idUnidad
			inner join Partidas.dbo.Unidad UP on UP.idUnidad = U.idTipoUnidad
			inner join Partidas.dbo.SubMarca SM on UP.idSubMarca = SM.idSubMarca
			inner join Partidas.dbo.Marca M on SM.idMarca = M.idMarca
			inner join [ASEPROTSISCO].[dbo].EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
		where 
			R.IDESTATUSORDEN IN (12)
			AND R.SALDO >0
			and R.idProveedor = @idProveedor
			AND R.idOperacion = @idOperacion
			group by
			R.NOMBRECOMERCIAL,
			CONVERT(VARCHAR,UP.idUnidad) + '/' + M.nombre + '/' + SM.nombre,
			U.numeroEconomico,
			U.placas,
			O.numeroOrden,
			O.fechaCreacionOden,
			EO.nombreEstatusOrden,
			R.factura,
			R.saldo,
			O.numeroOrden
	END
END
go

