-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_FOLIO_ORDEN_SP]
	-- Add the parameters for the stored procedure here
	@folio		nvarchar(100),
	@idContratoOperacion	numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @idFolio	numeric(18,0)
	insert into Folio (folio, idContratoOperacion, fechaCarga) values (@folio, @idContratoOperacion, GETDATE())

	set @idFolio = @@IDENTITY

	--Se eliminan las ordenes previamente registradas
	delete from FolioOrden where idOrden in (
		select 
			idOrden 
		from 
			Ordenes o 
		where	
			o.idEstatusOrden = 8 
			and o.idContratoOperacion = @idContratoOperacion
	)


	--Se agregan las ordenes
	insert into FolioOrden(idFolio, idOrden)
	select 
		@idFolio, o.idOrden
	from 
		Ordenes o
		left join FolioOrden fo on fo.idOrden = o.idOrden
	where	
		o.idEstatusOrden = 8 
		and o.idContratoOperacion = @idContratoOperacion
		and fo.idFolioOrden is null

	select 
		@idFolio as idFolio,
		count(*) as numOrdenes,
		sum(total) as total
	from (
		select 
			o.idOrden, 
			(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3,510, 2)) * 1.16 AS total
		from
			Ordenes o
			inner join folioOrden fo on fo.idOrden = o.idOrden
		where 
			fo.idFolio = @idFolio
		) as result
END
go

