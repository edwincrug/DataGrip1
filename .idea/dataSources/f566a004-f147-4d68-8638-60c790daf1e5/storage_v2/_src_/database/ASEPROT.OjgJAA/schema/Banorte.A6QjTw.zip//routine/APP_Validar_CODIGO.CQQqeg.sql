
/*
	Fecha			Autor			Descripción
	26-Jul-2018		José Etmanuel	Se crea el SP para validar codigo de promoción BPRO

	[Banorte].[APP_Validar_CODIGO] 
	@codigo = 816765
*/


CREATE PROCEDURE [Banorte].[APP_Validar_CODIGO]
	@codigo VARCHAR(MAX)
AS   
BEGIN
	declare @sobran int = 0,
			@mensaje varchar(max)= 'Código invalido',
			@prct_descuento float = 0.0,
			@status int = 0,
			@idPoliza varchar(50)
		;

	IF EXISTS (SELECT * FROM [dbo].[PromocionesCodigos] WHERE [Codigo] = @codigo)
	BEGIN
		SELECT @sobran= ISNULL([NumeroMaximo] - [Aplicadas],0), @idPoliza = [IdPoliza]
			FROM [PromocionesCodigos] AS PC
			INNER JOIN [Banorte].[Promociones] as P on P.id = PC.IdPromocion
			WHERE [Codigo] = @codigo
			AND Aplicadas<NumeroMaximo
			AND P.fechaTermino >= GETDATE()

		IF @sobran >0
		BEGIN
			SET @mensaje = 'Código válido';
			SET @status = 1;

			SELECT 
				 @sobran= ([NumeroMaximo] - [Aplicadas]) 
				,@prct_descuento = P.descuento
			FROM [dbo].[PromocionesCodigos] AS PC
			INNER JOIN [Banorte].[Promociones] AS P ON P.[id] = PC.IdPromocion
			WHERE [Codigo] = @codigo;
		END
	END
	
	Select @status as status, @mensaje as msg,  @sobran as sobran, @prct_descuento as prct_descuento;
END
go

grant execute, view definition on Banorte.APP_Validar_CODIGO to DevOps
go

