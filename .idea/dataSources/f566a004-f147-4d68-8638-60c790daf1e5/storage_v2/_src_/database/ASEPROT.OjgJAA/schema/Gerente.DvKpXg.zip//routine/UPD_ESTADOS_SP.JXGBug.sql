 CREATE PROCEDURE [Gerente].[UPD_ESTADOS_SP]
 	@idEstados INT,
	@nombreEstado NVARCHAR(250),
	@descripcionEstado NVARCHAR(500),
	@idUsuario INT,
	@cancela INT
AS
BEGIN
	IF(@cancela = 0)
		BEGIN 
			IF(@idEstados = 0)
				BEGIN

				IF NOT EXISTS(SELECT 1 FROM [Gerente].[Estados] WHERE nombreEstado=@nombreEstado AND descripcionEstado=@descripcionEstado AND estatus=0)
					BEGIN
						INSERT [Gerente].[Estados] VALUES(@nombreEstado,@descripcionEstado,GETDATE(),@idUsuario, @cancela)
						
						SELECT 'El registro se ha guardado correctamente!' msg, 1 estatus
					END
				ELSE
					BEGIN
						SELECT 'El nombre y/o descripción ya existen!' msg, 0 estatus
					END
				END
			ELSE
				BEGIN
				IF NOT EXISTS(SELECT 1 FROM [Gerente].[Estados] WHERE nombreEstado=@nombreEstado AND descripcionEstado=@descripcionEstado AND estatus=0)
					BEGIN
						UPDATE [Gerente].[Estados]
						SET nombreEstado=@nombreEstado,descripcionEstado=@descripcionEstado,@idUsuario=@idUsuario
						WHERE idEstados = @idEstados

						SELECT 'El registro se ha actualizado correctamente!' msg, 1 estatus

					END
				ELSE
					BEGIN
						SELECT 'El nombre y/o descripción ya existen!' msg, 0 estatus
					END

					SELECT * FROM [Gerente].[Estados] WHERE idEstados = @idEstados
				END
		END
	ELSE 
		BEGIN
			UPDATE [Gerente].[Estados]
			SET estatus=@cancela
			WHERE idEstados = @idEstados

			IF EXISTS(SELECT 1 FROM [Gerente].[EstadoZona] WHERE idEstado=@idEstados)
				BEGIN
					UPDATE [Gerente].[EstadoZona]
					SET estatus=@cancela
					WHERE idEstado = @idEstados
				END

			IF EXISTS(SELECT 1 FROM [Gerente].[EstadoGerencia] WHERE idEstado=@idEstados)
				BEGIN
					UPDATE [Gerente].[EstadoGerencia]
					SET estatus=@cancela
					WHERE idEstado=@idEstados
				END

			SELECT 'El registro se ha cancelado correctamente!' msg, 1 estatus
		END
END


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.UPD_ESTADOS_SP to DevOps
 go

