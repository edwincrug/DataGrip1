-- =============================================
-- Author:		YJH
-- Create date: 16/05/11
-- EXEC [SEL_REPORTE_MARGEN_UTILIDAD_SP_PRUEBA] @tipoConsulta=1,@idOperacion=28,@numOrden=NULL,@fechaInicial=NULL,@fechaFinal=NULL,@fechaMes=NULL,@idZona=NULL,@rangoInicial=NULL,@rangoFinal=NULL,@idTipoOrden=NULL,@idEstatus=NULL, @isProduction=1
-- EXEC [SEL_REPORTE_MARGEN_UTILIDAD_SP] @tipoConsulta=1,@idOperacion=20,@numOrden=NULL,@fechaInicial='2017-07-20 10:59:54.780',@fechaFinal='2017-07-24 10:59:54.780',@fechaMes=NULL,@idZona=29,@rangoInicial=46.00,@rangoFinal=70.00,@idTipoOrden=2,@idEstatus=7,@isProduction=0
-- EXEC [SEL_REPORTE_MARGEN_UTILIDAD_SP] @tipoConsulta=1,@idOperacion=20,@numOrden=NULL,@fechaInicial=null,@fechaFinal=null,@fechaMes=NULL,@idZona=null,@rangoInicial=null,@rangoFinal=null,@idTipoOrden=null,@idEstatus=null,@isProduction=0
-- EXEC [SEL_REPORTE_MARGEN_UTILIDAD_SP] @tipoConsulta=2,@idOperacion=28,@isProduction=1,@numOrden='26-25509-2365'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORTE_MARGEN_UTILIDAD_SP]
	@tipoConsulta INT = NULL,
	@idOperacion INT = NULL,
	@numOrden NVARCHAR(max) = NULL,
	@fechaInicial NVARCHAR(MAX) = NULL,
	@fechaFinal NVARCHAR(MAX) = NULL,
	@fechaMes NVARCHAR(MAX) = NULL,
	@idZona INT = NULL,
	@rangoInicial NUMERIC(18,2) = NULL,
	@rangoFinal NUMERIC(18,2) = NULL,
	@idTipoOrden INT = NULL,
	@idEstatus INT = NULL,
	@isProduction INT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	declare @idOBan int, @idCO int 
	select @idOBan=valor from ASEPROT.Banorte.Parametros where id=2	
	select @idCO=idContratoOperacion from ASEPROT.dbo.ContratoOperacion where idOperacion=@idOperacion
	
	declare @ordenes as table (idOrden int, numeroOrden nvarchar(100), numeroEconomico nvarchar(max), consecutivoOrden int, idEstatusOrden int
	,idCatalogoTipoOrdenServicio int, idContratoOperacion int, idZona int, fechaCreacionOrden datetime, nombreEstatusOrden nvarchar(100)
	,nombreComercial nvarchar(max), nombreZona nvarchar(100), nombreTipoOrdenServicio nvarchar(100)
	, margenConfigurado float, cantidad int,solicitadasOrg int, venta float, costo float, precioLista float
	, montoNCR decimal(10,2), porcentajeNCR float, porcentaje float, tipoOrden int, marca nvarchar(100), idMarca int)
	IF(@tipoConsulta = 1)
		BEGIN
			DECLARE @fechaFin NVARCHAR(50)
			IF(@fechaMes IS NOT NULL)
				BEGIN
					SET @fechaFin = DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,@fechaMes)+1,0))
				END
			DECLARE @tableEstatus table (idEstatusBPRO int)
			IF(@idEstatus IS NOT NULL)
				BEGIN
					if @idEstatus  = 1
						begin
							declare @y int = 1

							while @y <= 6
								begin
									insert into @tableEstatus values (@y)
									set @y = @y + 1
								end						
						end
					else
						begin
							insert into @tableEstatus values (@idEstatus)
						end										
				END
			ELSE
				BEGIN
					declare @x int = 0

					while @x <= 7
						begin
							insert into @tableEstatus values (@x)
							set @x = @x + 1
						end					
				END
				if (@idCO = @idOBan) 
				begin		
					PRINT 'Entra 1'													
					INSERT INTO @ordenes
					SELECT 
						O.idOrden, O.numeroOrden, AU.numeroEconomico, 
						O.consecutivoOrden, O.idEstatusOrden, O.idCatalogoTipoOrdenServicio,
						O.idContratoOperacion, O.idZona, O.fechaCreacionOden,
						EO.nombreEstatusOrden, 'BANORTE', Z.nombre, CTOS.nombreTipoOrdenServicio,
						--CASE WHEN CONF.id = 1 THEN '19.0000' ELSE CONF.porcentaje end - CONF.porcentajeSalida,
						CONF.porcentaje - CONF.porcentajeSalida,
						CD.cantidad, CD.venta, CD.solicitadasOrg, CD.costo, CD.precioLista
						,0,0
						--,case when O.idCatalogoTipoOrdenServicio = 1 then ISNULL(NCRR.montoNCR,0) else 0.0 end
						--,case when O.idCatalogoTipoOrdenServicio = 1 then ISNULL(NCRR.porcentajeNCR,0) else 0.0 end
						,CONF.porcentaje, O.idCatalogoTipoOrdenServicio, MM.marca, RCS.idMarca
					FROM ASEPROT.dbo.Ordenes O 
						JOIN ASEPROT.dbo.Unidades AU on AU.idUnidad = O.idUnidad
						JOIN ASEPROT.dbo.EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
						JOIN ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden 
						JOIN ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
						JOIN Partidas.dbo.Zona Z on Z.idZona = O.idZona
						JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
						LEFT JOIN RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden and SOC.idCotizacionSISCO = C.idCotizacion
						LEFT JOIN RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden=O.idOrden or CT.idOrdenRefaccion = O.idOrden
						JOIN RefaccionMultiMarca.Operacion.Siniestro RS on RS.id = CT.idSiniestro or RS.id = SOC.idSiniestro
						JOIN RefaccionMultiMarca.Operacion.Unidad U on U.id = RS.idUnidad
						JOIN RefaccionMultiMarca.Relacion.ClienteConfiguracionMarca CCM ON CCM.idMarca = U.marca
						JOIN RefaccionMultiMarca.Precio.Configuracion CONF ON CONF.id = CCM.idConfiguracion AND CCM.idCliente = 1
						LEFT JOIN RefaccionMultiMarca.Operacion.Cotizacion RC on RC.idCotizacion = SOC.idCotizacion
						JOIN RefaccionMultiMarca.Catalogo.Sucursal S on S.idSucursal = CT.idSucursal or S.idSucursal = RC.idSucursal
						JOIN RefaccionMultiMarca.Relacion.Configuracion_Sucursal RCS on RCS.idSucursal = S.idSucursal
						JOIN RefaccionMultiMarca.Catalogo.Marca MM ON MM.idMarca = RCS.idMarca
					WHERE O.idContratoOperacion=@idCO-- and O.idOrden=56177					
						AND O.idEstatusOrden NOT IN (13,15) 
						and C.idEstatusCotizacion IN(2,3)
						and CD.idEstatusPartida  IN(1,2) 
						AND O.idCatalogoTipoOrdenServicio = COALESCE(@idTipoOrden, O.idCatalogoTipoOrdenServicio)
						AND O.idZona = COALESCE(@idZona, O.idZona)					
						AND O.fechaCreacionOden BETWEEN COALESCE(@fechaInicial,O.fechaCreacionOden) AND COALESCE(@fechaFinal,O.fechaCreacionOden)
						AND O.fechaCreacionOden BETWEEN COALESCE(@fechaMes,O.fechaCreacionOden) AND COALESCE(@fechaFin,O.fechaCreacionOden)

					--select 
					--O.idOrden, O.numeroOrden, AU.numeroEconomico, O.consecutivoOrden, O.idEstatusOrden, O.idCatalogoTipoOrdenServicio,
					--O.idContratoOperacion, O.idZona, O.fechaCreacionOden, EO.nombreEstatusOrden, CLI.nombreComercial, Z.nombre, CTOS.nombreTipoOrdenServicio,
					--CONF.porcentaje - CONF.porcentajeSalida, CD.cantidad, CD.venta, CD.costo, CD.precioLista
					--,0,0
					----,case when O.idCatalogoTipoOrdenServicio = 1 then ISNULL(NCRR.montoNCR,0) else 0.0 end
					----,case when O.idCatalogoTipoOrdenServicio = 1 then ISNULL(NCRR.porcentajeNCR,0) else 0.0 end
					--,CONF.porcentaje
					--,O.idCatalogoTipoOrdenServicio
					--,MM.marca
					--,RCS.idMarca
					--from ASEPROT.dbo.Ordenes O 
					--inner join ASEPROT.dbo.Unidades AU on AU.idUnidad = O.idUnidad
					--inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
					--inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden 
					--inner join ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
					--inner JOIN ASEPROT.dbo.ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
					--inner JOIN ASEPROT.dbo.Operaciones OPE on OPE.idOperacion = CO.idOperacion
					--inner JOIN Partidas.dbo.Contrato PC on PC.idContrato = CO.idContrato
					--inner JOIN Partidas.dbo.Licitacion L on L.idLicitacion = PC.idLicitacion
					--inner JOIN Partidas.dbo.Cliente CLI on CLI.idCliente = L.idCliente
					--inner join Partidas.dbo.Zona Z on Z.idZona = O.idZona
					--inner JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
					--left join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden and SOC.idCotizacionSISCO = C.idCotizacion
					--left join RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden=O.idOrden or CT.idOrdenRefaccion = O.idOrden
					--inner join RefaccionMultiMarca.Operacion.Siniestro RS on RS.id = CT.idSiniestro or RS.id = SOC.idSiniestro
					--inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = RS.idUnidad
					--inner join RefaccionMultiMarca.Relacion.ClienteConfiguracionMarca CCM ON CCM.idMarca = U.marca
					--inner join RefaccionMultiMarca.Precio.Configuracion CONF ON CONF.id = CCM.idConfiguracion AND CCM.idCliente = 1
					--left join RefaccionMultiMarca.Operacion.Cotizacion RC on RC.idCotizacion = SOC.idCotizacion
					--inner join RefaccionMultiMarca.Catalogo.Sucursal S on S.idSucursal = CT.idSucursal or S.idSucursal = RC.idSucursal
					--inner join RefaccionMultiMarca.Relacion.Configuracion_Sucursal RCS on RCS.idSucursal = S.idSucursal
					--inner join RefaccionMultiMarca.Catalogo.Marca MM ON MM.idMarca = RCS.idMarca
					----CROSS APPLY ASEPROT.dbo.[SEL_VALNCRREFAC_FN](O.idOrden, RCS.idMarca) NCRR
					--where O.idContratoOperacion=@idCO-- and O.idOrden=56177					
					--AND O.idEstatusOrden NOT IN (13,15) and CD.idEstatusPartida  IN(2,3) 
					--AND O.idCatalogoTipoOrdenServicio = COALESCE(@idTipoOrden, O.idCatalogoTipoOrdenServicio)
					--AND O.idZona = COALESCE(@idZona, O.idZona)					
					--AND O.fechaCreacionOden BETWEEN COALESCE(@fechaInicial,O.fechaCreacionOden) AND COALESCE(@fechaFinal,O.fechaCreacionOden)
					--AND O.fechaCreacionOden BETWEEN COALESCE(@fechaMes,O.fechaCreacionOden) AND COALESCE(@fechaFin,O.fechaCreacionOden)

					SELECT * FROM (
						SELECT O.idOrden
							,O.idZona
							,O.nombreComercial as Cliente
							,O.consecutivoOrden
							,O.numeroOrden
							,O.numeroEconomico
							--,[dbo].[SEL_PROVEEDOR_ORDEN_FN](O.idOrden) talleres
							,O.marca talleres
							,O.fechaCreacionOrden  as fechaCreacionOrden		
							,O.nombreEstatusOrden as estatus
							,O.idCatalogoTipoOrdenServicio
							,O.nombreTipoOrdenServicio
							,[dbo].[SEL_ESTATUS_BPRO_FN](O.numeroOrden, @idOperacion, @isProduction) estatusProvision
							--,[dbo].[SEL_ESTATUS_IDBPRO_FN](O.numeroOrden, @idOperacion, @isProduction) idEstatusProvision
							,ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00) costo
							,ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00) venta
							--,ISNULL(ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00) - ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00),0) utilidad
							--, case when (ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0) = 0) then 0 else 
							--(((ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)-ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00)) * 100) / ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)) end margen
							, O.margenConfigurado
							--,[dbo].[SEL_ZONAS_NAME_FN](O.idZona) as zonasConcatenadas
							,O.nombreZona as zonasConcatenadas
							,O.nombreZona
							--,case when O.tipoOrden = 1 and O.porcentajeNCR <> 0 and ISNULL(sum((ISNULL(O.venta,0) + ISNULL(O.precioLista * O.porcentaje / 100.0,0)) * ISNULL(O.cantidad,0)),0.00) > 0 then (((ISNULL(sum((ISNULL(O.venta,0) + ISNULL(O.precioLista * O.porcentaje / 100.0,0)) * ISNULL(O.cantidad,0)),0.00) -ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00)) * 100) / ISNULL(sum((ISNULL(O.venta,0) + ISNULL(O.precioLista * O.porcentaje / 100.0,0)) * ISNULL(O.cantidad,0)),0.00)) else 0 end margenCalculado
							--,case when O.tipoOrden = 1 and O.porcentajeNCR <> 0 then ((ISNULL(SUM(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0) - ISNULL(ISNULL(SUM(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0) - O.montoNCR,0)) * 100) / (ISNULL(SUM(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0)) else 0 end margenNCR
							--,O.porcentajeNCR
							,O.porcentaje AS teorico
							,0 AS real--O.porcentajeNCR AS real
							--,O.montoNCR AS importe
							,0 importe
							,0 utilidad--,ISNULL(ISNULL(SUM(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00) - ISNULL(SUM(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00),0) + ISNULL(O.montoNCR,0) utilidad
							,0 margen --,case when (ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0) = 0) then 0 else ((((ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)-ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00)) + ISNULL(O.montoNCR,0)) * 100) / ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)) end margen
							,O.idMarca
					FROM @ordenes O												
					GROUP BY O.idOrden, O.nombreComercial, O.consecutivoOrden, O.numeroOrden, O.numeroEconomico, O.idZona
					,O.fechaCreacionOrden, O.nombreEstatusOrden, O.nombreTipoOrdenServicio, O.nombreZona, O.margenConfigurado, O.tipoOrden, O.idCatalogoTipoOrdenServicio
					,O.porcentaje, O.marca,O.idMarca)ADOLFO
					WHERE margen BETWEEN COALESCE(@rangoInicial,margen) AND COALESCE(@rangoFinal,margen)					
					--AND idEstatusProvision in (select idEstatusBPRO from @tableEstatus)
				end 
				else 
				begin
					PRINT 'Entra 2'
					SELECT * FROM (
						SELECT ORD.idOrden
							,ORD.idZona
							,CLI.nombreComercial as Cliente
							,ORD.consecutivoOrden
							,ORD.numeroOrden
							,U.numeroEconomico
							,[dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden) talleres
							,ORD.fechaCreacionOden  as fechaCreacionOrden		
							,EO.nombreEstatusOrden as estatus
							,CTOS.idCatalogoTipoOrdenServicio
							,CTOS.nombreTipoOrdenServicio
							,[dbo].[SEL_ESTATUS_BPRO_FN](ORD.numeroOrden, @idOperacion, @isProduction) estatusProvision
							,[dbo].[SEL_ESTATUS_IDBPRO_FN](ORD.numeroOrden, @idOperacion, @isProduction) idEstatusProvision
							,ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00) costo
							,ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00) venta
							,ISNULL(ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00) - ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00),0) utilidad
							, case when (ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0) = 0) then 0 else 
							(((ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)-ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00)) * 100) / ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)) end margen
							,OPE.porcentajeUtilidad as margenConfigurado
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,Z.nombre as nombreZona
					FROM Ordenes ORD
						JOIN Unidades U on U.idUnidad = ORD.idUnidad
						JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden
						JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = ORD.idCatalogoTipoOrdenServicio
						JOIN Cotizaciones COTI on COTI.idOrden = ORD.idOrden
						JOIN CotizacionDetalle CD on CD.idCotizacion = COTI.idCotizacion
						JOIN ContratoOperacion CO on CO.idContratoOperacion = ORD.idContratoOperacion
						JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
						JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
						JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
						JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
						JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
					WHERE	ORD.idEstatusOrden NOT IN (13,15) 
							and COTI.idEstatusCotizacion IN(2,3)
							and CD.idEstatusPartida  IN(1,2) 
							AND OPE.idOperacion = @idOperacion
							GROUP BY ORD.idOrden, CLI.nombreComercial, ORD.consecutivoOrden, ORD.numeroOrden, U.numeroEconomico, ORD.idZona, ORD.fechaCreacionOden, EO.nombreEstatusOrden, CTOS.nombreTipoOrdenServicio, CTOS.idCatalogoTipoOrdenServicio, OPE.porcentajeUtilidad, Z.nombre)ADOLFO
					WHERE margen BETWEEN COALESCE(@rangoInicial,margen) AND COALESCE(@rangoFinal,margen)
					AND idCatalogoTipoOrdenServicio = COALESCE(@idTipoOrden, idCatalogoTipoOrdenServicio)
					AND idZona = COALESCE(@idZona, idZona)
					AND fechaCreacionOrden BETWEEN COALESCE(@fechaInicial,fechaCreacionOrden) AND COALESCE(@fechaFinal,fechaCreacionOrden)
					AND fechaCreacionOrden BETWEEN COALESCE(@fechaMes,fechaCreacionOrden) AND COALESCE(@fechaFin,fechaCreacionOrden)
					AND idEstatusProvision in (select idEstatusBPRO from @tableEstatus)
			end
		END
	ELSE
		BEGIN
			IF (@numOrden is null)
				BEGIN
					set @numOrden = ''
				END
			if (@idCO = @idOBan) 
			begin
				PRINT 'Entra 3'	
				INSERT INTO @ordenes
					SELECT 
						O.idOrden, O.numeroOrden, AU.numeroEconomico, 
						O.consecutivoOrden, O.idEstatusOrden, O.idCatalogoTipoOrdenServicio,
						O.idContratoOperacion, O.idZona, O.fechaCreacionOden,
						 EO.nombreEstatusOrden, 'BANORTE', Z.nombre, CTOS.nombreTipoOrdenServicio,
						CONF.porcentaje - CONF.porcentajeSalida,
						 CD.cantidad, CD.solicitadasOrg, CD.venta, CD.costo, CD.precioLista
						,0,0
						--,case when O.idCatalogoTipoOrdenServicio = 1 then ISNULL(NCRR.montoNCR,0) else 0.0 end
						--,case when O.idCatalogoTipoOrdenServicio = 1 then ISNULL(NCRR.porcentajeNCR,0) else 0.0 end
						,CONF.porcentaje, O.idCatalogoTipoOrdenServicio, MM.marca, RCS.idMarca
					FROM ASEPROT.dbo.Ordenes O 
						JOIN ASEPROT.dbo.Unidades AU on AU.idUnidad = O.idUnidad
						JOIN ASEPROT.dbo.EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
						JOIN ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden 
						JOIN ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
						JOIN Partidas.dbo.Zona Z on Z.idZona = O.idZona
						JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
						left JOIN RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden and SOC.idCotizacionSISCO = C.idCotizacion
						left JOIN RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden=O.idOrden or CT.idOrdenRefaccion = O.idOrden
						JOIN RefaccionMultiMarca.Operacion.Siniestro RS on RS.id = CT.idSiniestro or RS.id = SOC.idSiniestro
						JOIN RefaccionMultiMarca.Operacion.Unidad U on U.id = RS.idUnidad
						JOIN RefaccionMultiMarca.Relacion.ClienteConfiguracionMarca CCM ON CCM.idMarca = U.marca
						JOIN RefaccionMultiMarca.Precio.Configuracion CONF ON CONF.id = CCM.idConfiguracion AND CCM.idCliente = 1
						left JOIN RefaccionMultiMarca.Operacion.Cotizacion RC on RC.idCotizacion = SOC.idCotizacion
						JOIN RefaccionMultiMarca.Catalogo.Sucursal S on S.idSucursal = CT.idSucursal or S.idSucursal = RC.idSucursal
						JOIN RefaccionMultiMarca.Relacion.Configuracion_Sucursal RCS on RCS.idSucursal = S.idSucursal
						JOIN RefaccionMultiMarca.Catalogo.Marca MM ON MM.idMarca = RCS.idMarca
					WHERE O.numeroOrden LIKE '%'+@numOrden+'%' AND O.idContratoOperacion=26 AND O.idEstatusOrden NOT IN (13,15) and C.idEstatusCotizacion IN(2,3)
							and CD.idEstatusPartida  IN(1,2) 

					--select 
					--O.idOrden, O.numeroOrden, AU.numeroEconomico, O.consecutivoOrden, O.idEstatusOrden, O.idCatalogoTipoOrdenServicio,
					--O.idContratoOperacion, O.idZona, O.fechaCreacionOden, EO.nombreEstatusOrden, CLI.nombreComercial, Z.nombre, CTOS.nombreTipoOrdenServicio,
					--CONF.porcentaje - CONF.porcentajeSalida, CD.cantidad, CD.venta, CD.costo, CD.precioLista
					--,0,0
					----,case when O.idCatalogoTipoOrdenServicio = 1 then ISNULL(NCRR.montoNCR,0) else 0.0 end
					----,case when O.idCatalogoTipoOrdenServicio = 1 then ISNULL(NCRR.porcentajeNCR,0) else 0.0 end
					--,CONF.porcentaje
					--,O.idCatalogoTipoOrdenServicio
					--,MM.marca
					--,RCS.idMarca
					--from ASEPROT.dbo.Ordenes O 
					--inner JOIN ASEPROT.dbo.Unidades AU on AU.idUnidad = O.idUnidad
					--inner JOIN ASEPROT.dbo.EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
					--inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden 
					--inner join ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
					--inner JOIN ASEPROT.dbo.ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
					--inner JOIN ASEPROT.dbo.Operaciones OPE on OPE.idOperacion = CO.idOperacion
					--inner JOIN Partidas.dbo.Contrato PC on PC.idContrato = CO.idContrato
					--inner JOIN Partidas.dbo.Licitacion L on L.idLicitacion = PC.idLicitacion
					--inner JOIN Partidas.dbo.Cliente CLI on CLI.idCliente = L.idCliente
					--inner join Partidas.dbo.Zona Z on Z.idZona = O.idZona
					--inner join CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
					--left join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden and SOC.idCotizacionSISCO = C.idCotizacion
					--left join RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idOrden=O.idOrden or CT.idOrdenRefaccion = O.idOrden
					--inner join RefaccionMultiMarca.Operacion.Siniestro RS on RS.id = CT.idSiniestro or RS.id = SOC.idSiniestro
					--inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = RS.idUnidad
					--inner join RefaccionMultiMarca.Relacion.ClienteConfiguracionMarca CCM ON CCM.idMarca = U.marca
					--inner join RefaccionMultiMarca.Precio.Configuracion CONF ON CONF.id = CCM.idConfiguracion AND CCM.idCliente = 1
					--left join RefaccionMultiMarca.Operacion.Cotizacion RC on RC.idCotizacion = SOC.idCotizacion
					--inner join RefaccionMultiMarca.Catalogo.Sucursal S on S.idSucursal = CT.idSucursal or S.idSucursal = RC.idSucursal
					--inner join RefaccionMultiMarca.Relacion.Configuracion_Sucursal RCS on RCS.idSucursal = S.idSucursal
					--inner join RefaccionMultiMarca.Catalogo.Marca MM ON MM.idMarca = RCS.idMarca
					----CROSS APPLY ASEPROT.dbo.[SEL_VALNCRREFAC_FN](O.idOrden, RCS.idMarca) NCRR
					--where O.numeroOrden LIKE '%'+@numOrden+'%' and O.idEstatusOrden NOT IN (13,15) 
					--AND CD.idEstatusPartida IN(2,3) 

				SELECT  O.idOrden
						,O.nombreComercial as Cliente
						,O.consecutivoOrden
						,O.numeroOrden
						,O.numeroEconomico
						--,[dbo].[SEL_PROVEEDOR_ORDEN_FN](O.idOrden) talleres
						,O.marca talleres
						,O.fechaCreacionOrden  as fechaCreacionOrden		
						,O.nombreEstatusOrden as estatus
						,O.nombreTipoOrdenServicio
						,[dbo].[SEL_ESTATUS_BPRO_FN](O.numeroOrden, @idOperacion, @isProduction) estatusProvision
						,ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.solicitadasOrg,0)),0.00) costo
						,ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.solicitadasOrg,0)),0.00) venta
						--,ISNULL(ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00) - ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00),0) utilidad
						--, case when (ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0) = 0) then 0 else 
						--(((ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)-ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00)) * 100) / ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)) end margen
						, O.margenConfigurado 
						--,[dbo].[SEL_ZONAS_NAME_FN](O.idZona) as zonasConcatenadas
						,O.nombreZona as zonasConcatenadas
						,O.nombreZona
						--,case when O.tipoOrden = 1 and O.porcentajeNCR <> 0 and ISNULL(sum((ISNULL(O.venta,0) + ISNULL(O.precioLista * O.porcentaje / 100.0,0)) * ISNULL(O.cantidad,0)),0.00) > 0 then (((ISNULL(sum((ISNULL(O.venta,0) + ISNULL(O.precioLista * O.porcentaje / 100.0,0)) * ISNULL(O.cantidad,0)),0.00) -ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00)) * 100) / ISNULL(sum((ISNULL(O.venta,0) + ISNULL(O.precioLista * O.porcentaje / 100.0,0)) * ISNULL(O.cantidad,0)),0.00)) else 0 end margenCalculado
						--,case when O.tipoOrden = 1 and O.porcentajeNCR <> 0 then ((ISNULL(SUM(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0) - ISNULL(ISNULL(SUM(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0) - O.montoNCR,0)) * 100) / (ISNULL(SUM(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0)) else 0 end margenNCR
						--,O.porcentajeNCR
						,O.porcentaje AS teorico
						,0 AS real --O.porcentajeNCR AS real
						,0 AS importe--O.montoNCR AS importe
						--,case when O.tipoOrden = 1 and O.porcentajeNCR <> 0 then ISNULL(ISNULL(SUM(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00) - ISNULL(SUM(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00),0) + ISNULL(O.montoNCR,0) else 0 end utilidad
						--,case when O.tipoOrden = 1 and O.porcentajeNCR <> 0 then case when (ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0) = 0) then 0 else ((((ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)-ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00)) + ISNULL(O.montoNCR,0)) * 100) / ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)) end else 0 end margen
						,0 AS utilidad--ISNULL(ISNULL(SUM(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00) - ISNULL(SUM(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00),0) + ISNULL(O.montoNCR,0) utilidad
						,0 AS margen --case when (ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0) = 0) then 0 else ((((ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)-ISNULL(sum(ISNULL(O.costo,0) * ISNULL(O.cantidad,0)),0.00)) + ISNULL(O.montoNCR,0)) * 100) / ISNULL(sum(ISNULL(O.venta,0) * ISNULL(O.cantidad,0)),0.00)) end margen
						, O.idMarca
				FROM @ordenes O 															
				GROUP BY O.idOrden, O.nombreComercial, O.consecutivoOrden, O.numeroOrden, O.numeroEconomico, O.idZona, O.fechaCreacionOrden
				, O.nombreEstatusOrden, O.nombreTipoOrdenServicio, O.nombreZona,
				O.margenConfigurado, O.tipoOrden,O.porcentaje, O.marca, O.idMarca
			end 
			else 
			begin
				PRINT 'Entra 4'	
				SELECT  ORD.idOrden
					,CLI.nombreComercial as Cliente
					,ORD.consecutivoOrden
					,ORD.numeroOrden
					,U.numeroEconomico
					,[dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden) talleres
					,ORD.fechaCreacionOden  as fechaCreacionOrden		
					,EO.nombreEstatusOrden as estatus
					,CTOS.nombreTipoOrdenServicio
					,[dbo].[SEL_ESTATUS_BPRO_FN](ORD.numeroOrden, @idOperacion, @isProduction) estatusProvision
					,ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00) costo
					,ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00) venta
					,ISNULL(ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00) - ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00),0) utilidad
					, case when (ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0) = 0) then 0 else 
					(((ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)-ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00)) * 100) / ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)) end margen
					,OPE.porcentajeUtilidad as margenConfigurado
					,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
					,Z.nombre as nombreZona
			FROM Ordenes ORD
				JOIN Unidades U on U.idUnidad = ORD.idUnidad
				JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden
				JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = ORD.idCatalogoTipoOrdenServicio
				JOIN Cotizaciones COTI on COTI.idOrden = ORD.idOrden
				JOIN CotizacionDetalle CD on CD.idCotizacion = COTI.idCotizacion
				JOIN ContratoOperacion CO on CO.idContratoOperacion = ORD.idContratoOperacion
				JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
				JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
				JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
				JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
				JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
			WHERE	ORD.idEstatusOrden NOT IN (13,15)
					and COTI.idEstatusCotizacion IN(2,3) 
					and CD.idEstatusPartida  IN(1,2)  
					AND OPE.idOperacion = @idOperacion
					AND ORD.numeroOrden LIKE '%'+@numOrden+'%'
			GROUP BY ORD.idOrden, CLI.nombreComercial, ORD.consecutivoOrden, ORD.numeroOrden, U.numeroEconomico, ORD.idZona, ORD.fechaCreacionOden, EO.nombreEstatusOrden, CTOS.nombreTipoOrdenServicio, OPE.porcentajeUtilidad, Z.nombre
			end
		END

END
go

