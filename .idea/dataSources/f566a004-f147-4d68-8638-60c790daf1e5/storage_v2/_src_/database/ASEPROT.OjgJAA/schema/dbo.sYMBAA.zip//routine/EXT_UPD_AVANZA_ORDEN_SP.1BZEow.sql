-- =============================================
-- Description:	Actualiza la Orden de Servicio 
-- =============================================
/*[dbo].[EXT_UPD_AVANZA_ORDEN_SP] 48057, 126
*/
CREATE PROCEDURE [dbo].[EXT_UPD_AVANZA_ORDEN_SP]
	@idOrden NUMERIC(18,0), 
	@idUsuario  NUMERIC(18,0)
AS
BEGIN
	DECLARE @idHistorico NUMERIC(15,0);
	DECLARE @Estatus NUMERIC(15,0);
	DECLARE @NuevoEstatus NUMERIC(15,0);

	SET @Estatus = (SELECT idEstatusOrden FROM Ordenes WHERE idOrden = @idOrden);

	IF( @Estatus IS NOT NULL )
		BEGIN
			IF(@Estatus >= 1 AND @Estatus <= 12)
				BEGIN
					SET @idHistorico = (SELECT TOP 1 idHistorialEstatusOrden FROM HistorialEstatusOrden WHERE idOrden = @idOrden AND idEstatusOrden = @Estatus ORDER BY idHistorialEstatusOrden DESC );
			
					IF( @idHistorico IS NOT NULL )
						BEGIN
							SET @NuevoEstatus = (@Estatus + 1)
							-- Aquí debe ocurrir la magia
							UPDATE HistorialEstatusOrden SET fechaFinal = CURRENT_TIMESTAMP WHERE idHistorialEstatusOrden = @idHistorico;
							INSERT INTO HistorialEstatusOrden VALUES( @idOrden, @NuevoEstatus, CURRENT_TIMESTAMP, NULL, @idUsuario );
							UPDATE Ordenes SET idEstatusOrden = @NuevoEstatus WHERE idOrden = @idOrden;
							SELECT Success = 1, Msg = 'Se cambio el estatus de la Orden correctamente';
							--si se avanza la orden de estatus 4 a estatus 5 se agrega la partida
							--IF (@NuevoEstatus = 5)
							--BEGIN
							--	EXEC UPD_PARTIDA_NISSAN_PORCENTAJE @idOrden,@idUsuario
							--END
						END
					ELSE
						BEGIN
							SELECT Success = 0, Msg = 'El registro esta corrumpo, no se encontro ';
						END	
				END
			ELSE
				BEGIN
					SELECT Success = 0, Msg = 'El SP solo funciona para las Ordenes en estatus 1 a 8, y tu orden se encuentra en estatus ' + CONVERT(VARCHAR(10),@Estatus);
				END	
		END
	ELSE
		BEGIN
			SELECT Success = 0, Msg = 'No se ha encontrado la Orden que buscaba';
		END

END
go

