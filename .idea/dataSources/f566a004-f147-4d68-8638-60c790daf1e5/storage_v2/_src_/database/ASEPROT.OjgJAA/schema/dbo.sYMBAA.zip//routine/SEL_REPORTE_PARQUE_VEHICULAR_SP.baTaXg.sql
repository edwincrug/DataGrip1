-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03/06/2017
-- =============================================

--exec [dbo].[SEL_REPORTE_PARQUE_VEHICULAR_SP] 23,null,null,1074
CREATE PROCEDURE [dbo].[SEL_REPORTE_PARQUE_VEHICULAR_SP] 
	@idOperacion INT = 1,
	@idTipoUnidad INT = NULL,
	@idZona INT = NULL,
	@idUsuario INT = NULL
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @idop INT=(select idOperacion from ContratoOperacion c
    join Partidas..Contrato o on c.idContrato=o.idContrato and idContratoOperacion=@idOperacion)
   
    declare @idRol int = (select idCatalogoTipoUsuarios from Usuarios where idUsuario = @idUsuario)


   IF @idZona != null OR @idZona !=''--Si trae alguna zona se consulta por zona ya sea administrador o algun otro rol
   BEGIN
		
		IF @idZona is not null AND @idTipoUnidad is not NULL
		BEGIN
		print 'nullos'
		SELECT
			U.numeroEconomico,
			U.vin,
			U.idOperacion,
			U.idCentroTrabajo,
			U.placas,
			U.modelo,
			U.combustible,
			U.verificada,
			TU.tipo,
			TC.tipoCombustible,
			SM.nombre subMarca,
			M.nombre Marca,
			Z.nombre,
			CT.nombreCentroTrabajo,
			'http://189.204.141.193:5101/partidas/' + PU.foto as foto, 
			(select SUM([dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden,@idOperacion,2,2,1))
						from Ordenes ORD
						where ORD.idUnidad = U.idUnidad
							and ORD.idEstatusOrden in(5,6,7,8,9,10,11,12)) as monto,
		   OPE.geolocalizacion as gps,
		   U.verGPS as isGPS,
			U.idOrigenUnidad,
			OU.Descripcion as OrigenUnidad,
			U.contratoUnidad,
			ISNULL(U.perdidaTotal,0) AS perdidaTotal
		FROM Unidades U
		LEFT JOIN [dbo].OrigenUnidad OU ON OU.idOrigenUnidad = U.IdOrigenUnidad
		JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
		JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
		JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
		JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
		JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
		JOIN Partidas..Zona Z ON Z.idZona = U.idZona
		LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
		LEFT JOIN Operaciones OPE ON OPE.idOperacion = @idop
		WHERE U.idOperacion= @idop AND
		U.idTipoUnidad = COALESCE(@idTipoUnidad,TU.idTipoUnidad) AND
		U.idZona = COALESCE(@idZona,U.idZona)
		END
		ELSE IF @idZona is not null AND   @idTipoUnidad is null
		BEGIN
			print 'else 1'
			SELECT
			U.numeroEconomico,
			U.vin,
			U.idOperacion,
			U.idCentroTrabajo,
			U.placas,
			U.modelo,
			U.combustible,
			U.verificada,
			TU.tipo,
			TC.tipoCombustible,
			SM.nombre subMarca,
			M.nombre Marca,
			Z.nombre,
			CT.nombreCentroTrabajo,
			'http://189.204.141.193:5101/partidas/' + PU.foto as foto, 
			(select SUM([dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden,@idOperacion,2,2,1))
						from Ordenes ORD
						where ORD.idUnidad = U.idUnidad
							and ORD.idEstatusOrden in(5,6,7,8,9,10,11,12)) as monto,
		   OPE.geolocalizacion as gps,
		   U.verGPS as isGPS
		FROM Unidades U
		JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
		JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
		JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
		JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
		JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
		JOIN Partidas..Zona Z ON Z.idZona = U.idZona
		LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
		LEFT JOIN Operaciones OPE ON OPE.idOperacion = @idop
		WHERE U.idOperacion= @idop AND
		U.idZona = COALESCE(@idZona,U.idZona)

		END
		ELSE IF @idZona is null AND   @idTipoUnidad is not null
		BEGIN
		print 'else 1'
			SELECT
			U.numeroEconomico,
			U.vin,
			U.idOperacion,
			U.idCentroTrabajo,
			U.placas,
			U.modelo,
			U.combustible,
			U.verificada,
			TU.tipo,
			TC.tipoCombustible,
			SM.nombre subMarca,
			M.nombre Marca,
			Z.nombre,
			CT.nombreCentroTrabajo,
			'http://189.204.141.193:5101/partidas/' + PU.foto as foto, 
			(select SUM([dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden,@idOperacion,2,2,1))
						from Ordenes ORD
						where ORD.idUnidad = U.idUnidad
							and ORD.idEstatusOrden in(5,6,7,8,9,10,11,12)) as monto,
		   OPE.geolocalizacion as gps,
		   U.verGPS as isGPS
		FROM Unidades U
		JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
		JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
		JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
		JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
		JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
		JOIN Partidas..Zona Z ON Z.idZona = U.idZona
		LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
		LEFT JOIN Operaciones OPE ON OPE.idOperacion = @idop
		WHERE U.idOperacion= @idop AND
		U.idTipoUnidad = COALESCE(@idTipoUnidad,TU.idTipoUnidad) 

		END
	END
	ELSE--Si no trae zona se consultan todas las zonas que tenga el perfil
	BEGIN
		IF @idRol = 2--si es rol administrador consulta todo asi como esta el querie jala
		BEGIN
			print '@idRol = 2'
			SELECT
				U.numeroEconomico,
				U.vin,
				U.idOperacion,
				U.idCentroTrabajo,
				U.placas,
				U.modelo,
				U.combustible,
				U.verificada,
				TU.tipo,
				TC.tipoCombustible,
				SM.nombre subMarca,
				M.nombre Marca,
				Z.nombre,
				CT.nombreCentroTrabajo,
				'http://189.204.141.193:5101/partidas/' + PU.foto as foto, 
				(select SUM([dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden,@idOperacion,2,2,1))
							from Ordenes ORD
							where ORD.idUnidad = U.idUnidad
								and ORD.idEstatusOrden in(5,6,7,8,9,10,11,12)) as monto,
			   OPE.geolocalizacion as gps,
			   U.verGPS as isGPS
			FROM Unidades U
			JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
			JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
			JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
			JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
			JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
			JOIN Partidas..Zona Z ON Z.idZona = U.idZona
			LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
			LEFT JOIN Operaciones OPE ON OPE.idOperacion = @idop
			WHERE U.idOperacion= @idop --AND
			--U.idTipoUnidad = COALESCE(@idTipoUnidad,TU.idTipoUnidad) AND
			--U.idZona = COALESCE(@idZona,U.idZona)
		END
		ELSE--cuando no es administrador debe consultar solo las zonas que tiene asignadas para la primera consulta
		BEGIN

			print 'OTROS'
			declare @zonasContrato table(idZona int)

			insert into @zonasContrato select distinct COUZ.idZona from ContratoOperacionUsuario COU
			join ContratoOperacionUsuarioZona COUZ on couz.idContratoOperacionUsuario = COU.idContratoOperacionUsuario
			join Partidas..Zona Z on Z.idZona = COUZ.idZona
			where idUsuario = @idUsuario and idContratoOperacion = @idOperacion --and  idPadre != 0

			SELECT
				U.numeroEconomico,
				U.vin,
				U.idOperacion,
				U.idCentroTrabajo,
				U.placas,
				U.modelo,
				U.combustible,
				U.verificada,
				TU.tipo,
				TC.tipoCombustible,
				SM.nombre subMarca,
				M.nombre Marca,
				Z.nombre,
				CT.nombreCentroTrabajo,
				'http://189.204.141.193:5101/partidas/' + PU.foto as foto, 
				(select SUM([dbo].[SEL_PRECIO_VENTA_FN](ORD.idOrden,23,2,2,1))
							from Ordenes ORD
							where ORD.idUnidad = U.idUnidad
								and ORD.idEstatusOrden in(5,6,7,8,9,10,11,12)) as monto,
			   OPE.geolocalizacion as gps,
			   U.verGPS as isGPS
			FROM Unidades U
			JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
			JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
			JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
			JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
			JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
			JOIN Partidas..Zona Z ON Z.idZona = U.idZona
			LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
			LEFT JOIN Operaciones OPE ON OPE.idOperacion = @idop
			WHERE U.idOperacion= @idop AND
			--U.idTipoUnidad = COALESCE(@idTipoUnidad,TU.idTipoUnidad) AND
			U.idZona in (select idZona from @zonasContrato)--= COALESCE(@idZona,U.idZona)
		END
	END
END
go

