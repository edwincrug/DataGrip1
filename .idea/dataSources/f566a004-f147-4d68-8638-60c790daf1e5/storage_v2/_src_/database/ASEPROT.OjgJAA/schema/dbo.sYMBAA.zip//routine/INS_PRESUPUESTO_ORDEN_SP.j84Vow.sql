/*
SELECT * FROM [PresupuestoOrden]
SELECT * FROM Ordenes
SELECT * FROM CentroTrabajos where idCentroTrabajo = 40
select * from Presupuestos where idCentroTrabajo=40
[INS_PRESUPUESTO_ORDEN_SP] 1588, 63733, 510, 3

*/
CREATE PROCEDURE  [dbo].[INS_PRESUPUESTO_ORDEN_SP]
	@idPresupuesto NUMERIC(18,0),
	@idOrden NUMERIC(18,0),
	@idUsuario NUMERIC(18,0),
	@idOperacion INT
AS
BEGIN
	IF NOT EXISTS(SELECT 1 FROM [PresupuestoOrden] WHERE idOrden=@idOrden)
		BEGIN

		DECLARE @idPresupuestoOrden NUMERIC(18,0)
		DECLARE @IdZona INT
		DECLARE @Zona NVARCHAR(100)
		DECLARE @Consecutivo INT
		DECLARE @idCentroTrabajo INT
		DECLARE @numTAR INT

		INSERT INTO [dbo].[PresupuestoOrden]
		VALUES (@idPresupuesto, @idOrden, GETDATE(), @idUsuario, null, null, null)
		
		IF(@idOperacion IN(3,9,58))
			BEGIN
				SET @idPresupuestoOrden = (SELECT @@IDENTITY)

				SELECT @IdZona=idZona, @idCentroTrabajo=idCentroTrabajo FROM Ordenes WHERE idOrden = @idOrden

				declare @zonaPadre table(ID INT, idPadre INT, nombreNivel varchar(50), nombre varchar(50))
				insert into @zonaPadre
				EXEC [SEL_ZONAS_PADRES_SP]  @IdZona

				select top 1 @Zona = SUBSTRING(nombre, 1, 1) from @zonaPadre

				UPDATE [PresupuestoOrden]
				SET zona = @Zona
				WHERE idPresupuestoOrden = @idPresupuestoOrden

				SELECT @Consecutivo = ISNULL(MAX(consecutivo),0) + 1 FROM PresupuestoOrden WHERE zona = @Zona

				UPDATE [PresupuestoOrden]
				SET consecutivo = @Consecutivo
				WHERE idPresupuestoOrden = @idPresupuestoOrden

				SELECT @numTAR = extra1 FROM CentroTrabajos WHERE idCentroTrabajo=@idCentroTrabajo

				UPDATE [PresupuestoOrden]
				SET folio = 'RC-GLR' + @Zona + '-' + CONVERT(VARCHAR(5), @numTAR) + '-' + RIGHT('00000' + CONVERT(VARCHAR(5), @Consecutivo),5) + '-' + CONVERT(varchar(10), YEAR(GETDATE()))
				WHERE idPresupuestoOrden = @idPresupuestoOrden

				print @numTAR
			END
		END
	ELSE
		BEGIN
			UPDATE [dbo].[PresupuestoOrden]
			SET idPresupuesto=@idPresupuesto, idUsuario=@idUsuario, fechaAlta=GETDATE()
			WHERE idOrden=@idOrden
		END

		SELECT 1 

END
go

