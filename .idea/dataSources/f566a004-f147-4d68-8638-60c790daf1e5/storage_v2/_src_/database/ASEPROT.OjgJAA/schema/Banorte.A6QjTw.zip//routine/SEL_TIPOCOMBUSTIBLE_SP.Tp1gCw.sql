
-- =============================================
-- Author:		Jose Armando Garcia Arroyo
-- Create date: 21/05/2018
-- [Banorte].[SEL_TIPOCOMBUSTIBLE_SP]
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_TIPOCOMBUSTIBLE_SP]

AS

BEGIN
	select 
	*
	from partidas.[dbo].[TipoCombustible]

END
go

grant execute, view definition on Banorte.SEL_TIPOCOMBUSTIBLE_SP to DevOps
go

