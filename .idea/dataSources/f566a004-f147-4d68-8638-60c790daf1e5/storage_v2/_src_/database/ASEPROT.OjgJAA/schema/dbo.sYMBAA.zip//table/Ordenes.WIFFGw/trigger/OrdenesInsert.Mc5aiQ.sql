
CREATE TRIGGER [dbo].[OrdenesInsert] ON [dbo].[Ordenes]
AFTER INSERT
AS 
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON;

  -- get the last id value of the record inserted or updated
  DECLARE @id INT

  SELECT @id = [idOrden]
  FROM INSERTED

  -- Insert statements for trigger here
  UPDATE [Ordenes]
  SET [idZona] = 3548,
      [storedProcedureUpdate] = 'u'
  WHERE [idOrden] = @id AND idContratoOperacion = 26 AND idZona < 3500

END
go

