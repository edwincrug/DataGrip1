-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 18/05/2017
-- Description:	Obtiene todas las formas de pago
-- SEL_FORMA_DE_PAGO_SP
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_FORMA_DE_PAGO_SP]

AS
BEGIN
  

	SELECT idFormaPago, 
		nombreFormaPago 
	FROM CatalogoFormaPago
  
  
END


go

