-- =============================================
-- Author:		Sahirely Yam
-- Create date: 13 09 2017
-- =============================================
-- exec [dbo].[SEL_USUARIO_MODIFICA_COSTOS] 510, 200
CREATE PROCEDURE [dbo].[SEL_USUARIO_MODIFICA_COSTOS]
	@idUsuario int,
	@idOperacion int
AS
BEGIN

	SET NOCOUNT ON;

	select Estatus from ParametrosGeneralUsuario 
	where IdUsuario = @idUsuario and IdOperacion = @idOperacion and IdParametroGeneral = 15

END
go

