
CREATE FUNCTION [dbo].[GET_USUARIO_RESTRICCION_FN](@idUsuario INT ,@idOperacion INT)

RETURNS INT
AS
BEGIN
		DECLARE @estatus int  =   0

		SELECT @estatus = PGU.Estatus FROM ParametrosGeneral PG
		INNER JOIN ParametrosGeneralUsuario PGU ON PGU.IdParametroGeneral = PG.IdParametroGeneral  
		WHERE PGU.idUsuario = @idUsuario AND PGU.IdOperacion = @idOperacion and PG.IdParametroGeneral = 7

	RETURN @estatus;
		
END
go

