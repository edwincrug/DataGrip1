
CREATE PROCEDURE [dbo].[INS_CONTRARECIBO_COPADE_SP]
	@idDatosCopades NVARCHAR(1000),
	@idContrarecibo AS INT

AS
BEGIN

	DECLARE @Posicion NUMERIC(18,0)
	DECLARE @idDatosCopade NUMERIC(18,0)

	WHILE patindex('%,%' , @idDatosCopades) <> 0
		BEGIN
		  SELECT @Posicion =  patindex('%,%' , @idDatosCopades)
		  SELECT @idDatosCopade = left(@idDatosCopades, @Posicion - 1)
		  SET @idDatosCopade = CONVERT (numeric(18,0),@idDatosCopade)

			INSERT INTO ContrareciboDatosCopade
			VALUES(@idContrarecibo, @idDatosCopade, GETDATE())

			SELECT @idDatosCopades = stuff(@idDatosCopades, 1, @Posicion, '')
		END

	SELECT 1

END

go

