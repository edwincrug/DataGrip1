-- =============================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 30/05/2017
-- [SEL_VALIDA_USUARIO_AFO_SP] 'syam@bism.com.mx'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDA_USUARIO_AFO_SP] 
	@Correo VARCHAR(100) 

AS
BEGIN
	
	SELECT idUsuario FROM ASEPROTSISCO.dbo.Usuarios WHERE correoElectronico = @Correo

END

go

