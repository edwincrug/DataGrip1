/*

select [dbo].[cadenaToken] ('03-11612-52616')

select [dbo].[cadena_un_Token] ('55-MX337A1-5060')

*/

CREATE function [dbo].[cadena_un_Token](@numeroOrden varchar(max))
returns varchar (max)
as begin

	declare @string varchar (max) = ''
	declare @var varchar (max) = ''
	
		select @var = cast(count(t.token) as varchar)  from Ordenes o
				join Token t on o.idOrden=t.idOrdenServicio and t.idEstatusOrden=7 -- and o.idContratoOperacion=3
				and t.estatusToken=1 and o.idEstatusOrden=8
		where o.numeroOrden=@numeroOrden
		group by o.idOrden,t.idEstatusOrden,estatusToken,t.idUsuario having  count(t.token)>0

		if (@var = '' or @var is null)
		BEGIN
			SET @var = '0'
		end
		   

return cast(@var as varchar)
end



go

