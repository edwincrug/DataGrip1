
-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 2018 Marzo 15
-- Description:	Obtiene la informacion del gps vinculandola con el vin de sisco
-- Depende completamente del linkserver con la aplicacion de Edwin
-- Exec [GPS].[SEL_KILOMETROS_SP] '9BD341A55JY509469'
-- =============================================

CREATE PROCEDURE [GPS].[SEL_KILOMETROS_SP]
@vin varchar(100)

AS
BEGIN

	SET NOCOUNT ON;

	select tpl.lo longitud,
		tpl.la latitud, 
		tpl.mileage kilometros,
		tpl.gpsTime	fecha,
		u.numeroEconomico,
		u.placas
	from 
		[192.168.20.110].[GPS].[cxc].[UnidadGPSSIM] ugs
			inner join [192.168.20.110].[GPS].[inventario].GPSSIM gs on ugs.idGPSSIM = gs.idGPSSIM
			inner join [192.168.20.110].[GPS].[inventario].GPS g on gs.idGPS = g.idGPS 
			inner join [192.168.20.110].[8833test].[dbo].[tCar] tc on g.deviceID = tc.carNO COLLATE SQL_Latin1_General_CP1_CI_AS
			inner join [192.168.20.110].[8833test].[dbo].tPosition_last tpl on tc.carID = tpl.carID
			inner join unidades u on u.vin = ugs.vin
	where ugs.vin = @vin

END
go

grant execute, view definition on GPS.SEL_KILOMETROS_SP to DevOps
go

