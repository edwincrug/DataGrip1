

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--SEL_MEMORANDUM_BY_USUARIO_SP '181'
CREATE PROCEDURE [dbo].[UPD_MEMORANDUM_LOG_SP]
	-- Add the parameters for the stored procedure here
	@idMemorandum	numeric(18,0),
	@idUsuario		numeric(18,0),
	@leido			int,
	@aceptado		int,
	@comentarios	nvarchar(max)
AS
BEGIN
	
	--VERIFICAMOS SI YA EXISTE UN REGISTRO EN LA BD
	IF NOT EXISTS (SELECT * FROM MemorandumLog where idUsuario = @idUsuario and idMemorandum = @idMemorandum)
	begin
		INSERT INTO MemorandumLog(idMemorandum,idUsuario,leido,fechaLeido,aceptado,comentarios)
		values(
			@idMemorandum,
			@idUsuario,
			@leido,
			case when @leido = 0 then null when @leido is null then null else GETDATE() end,
			case when @leido = 0 then null when @leido is null then null else @aceptado end,
			@comentarios)
	end
	else
	begin
		update MemorandumLog
			set 
				leido = @leido,
				aceptado = @aceptado,
				comentarios = @comentarios,
				fechaLeido = GETDATE()
		where idMemorandum = @idMemorandum and idUsuario = @idUsuario
	end

	select  @idMemorandum
END
go

