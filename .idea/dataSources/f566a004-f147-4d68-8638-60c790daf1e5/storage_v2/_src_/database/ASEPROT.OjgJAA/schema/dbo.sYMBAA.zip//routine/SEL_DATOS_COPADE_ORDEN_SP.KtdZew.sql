

-- ==========================================================================================
-- Author:
-- Create date: 09/10/2017
-- Description:	Store que obtiene las copades sin asignación

-- [SEL_DATOS_COPADE_ORDEN_SP] 57, '312312312', '32131213'
-- ==========================================================================================

CREATE PROC [dbo].[SEL_DATOS_COPADE_ORDEN_SP]
	@idContratoOperacion numeric(18,0),
	@numeroCopade NVARCHAR(250),
	@numeroOrden NVARCHAR(250)
	AS
BEGIN
	DECLARE @idOrden AS NUMERIC(18,0) = 0
	DECLARE @idDatosCopade AS NUMERIC(18,0) = 0
	DECLARE @subTotalCopade AS NUMERIC(18,2) = 0
	DECLARE @totalCopade AS NUMERIC(18,2) = 0
	DECLARE @subTotalOrden AS NUMERIC(18,2) = 0
	DECLARE @totalOrden AS NUMERIC(18,2) = 0

	SELECT 
		@idDatosCopade = idDatosCopade,
		@subtotalCopade = subTotal,
		@totalCopade = ISNULL(total,'0.00')
		FROM DatosCopade 
	WHERE NOT EXISTS
		(
			SELECT 
				idDatosCopade 
			FROM DatosCopadeOrden 
			where DatosCopadeOrden.idDatosCopade=DatosCopade.idDatosCopade
		)
		and idContratoOperacion = @idContratoOperacion AND numeroCopade = @numeroCopade

	SELECT 
		@idOrden = idOrden,
		@subTotalOrden = (SELECT [dbo].[SEL_PRECIO_VENTA_FN](idOrden, idContratoOperacion, 3, 538, 2)),
		@totalOrden = (SELECT [dbo].[SEL_PRECIO_VENTA_FN](idOrden, idContratoOperacion, 3, 538, 2)) * 1.16
		FROM Ordenes 
	WHERE NOT EXISTS
		(
			SELECT 
				idOrden
			FROM DatosCopadeOrden 
			where DatosCopadeOrden.idOrden=Ordenes.idOrden
		)
		and idContratoOperacion = @idContratoOperacion AND numeroOrden = @numeroOrden


		SELECT 'idOrden' = @idOrden 
		,'idDatosCopade' =  @idDatosCopade
		,'subTotalCopade' = @subTotalCopade
		,'totalCopade' = @totalCopade
		,'subTotalOrden' =  @subTotalOrden
		,'totalOrden' = @totalOrden

END
go

