
-- SEL_PARTIDAS_TALLER_SP @idTaller = 2521, @especialidad = '2,4', @idContratoOperacion=40, @tipoUnidad = 5, @idtipocita = 0

CREATE PROCEDURE [dbo].[SEL_PARTIDAS_TALLER_SP]
	@idTaller NUMERIC(18,0) = null,
	@especialidad VARCHAR(500) = '',
	@idContratoOperacion NUMERIC(18,0) = 1,
	@tipoUnidad int = null,
	@idTipoCita INT = NULL
AS
		
	IF(@idTipoCita = 0)
		BEGIN
			SET @idTipoCita = null
		END
		
		DECLARE @total INT = 0
		DECLARE @especialidades TABLE(ID INT IDENTITY(1,1), idEspecialidad INT)
		
		IF((SELECT LEN(@especialidad)) > 0)
			BEGIN

					DECLARE @numero INT = 0
					--DECLARE @especialidad VARCHAR(100) = '34,2,94,5'
					
					WHILE(CHARINDEX(',',@especialidad,1) > 0) --(LEN(@cadena) > 0)
						BEGIN
								--SELECT SUBSTRING(@especialidad,1,CHARINDEX(',',@especialidad,1)-1)		

								IF(ISNUMERIC(SUBSTRING(@especialidad,1,CHARINDEX(',',@especialidad,1)-1)) = 1)
									BEGIN

										INSERT INTO @especialidades
										SELECT SUBSTRING(@especialidad,1,CHARINDEX(',',@especialidad,1)-1)

									END

							SELECT @numero = SUBSTRING(@especialidad,1,CHARINDEX(',',@especialidad,1)-1) 
							SELECT @especialidad = SUBSTRING(@especialidad,CHARINDEX(',',@especialidad) + 1,100)
						
						END

					--SELECT @cadena
					IF(ISNUMERIC(@especialidad) = 1)
							INSERT INTO @especialidades
							SELECT @especialidad
			
			END

		SELECT @total = COUNT(ID) FROM @especialidades 

		SELECT --top 1
			DISTINCT
				PART.idPartida,
				CONT.idContrato,
				ESP.idEspecialidad,
				ESP.especialidad,
				PARCLAS.idPartidaClasificacion,
				PARCLAS.clasificacion,
				CL2.idPartidaSubClasificacion,
				CL2.subClasificacion,
				partida,
				noParte,
				PART.descripcion,
				PART.foto,
				PART.instructivo,
				ISNULL(PROVPART.costo,0.00) as costo,
				ISNULL(CONTPART.venta,0.00) as venta,
				PARTEST.idPartidaEstatus,
				isnull(PARTEST.estatus, 'Sin Asignar') as partidaEstatus
		FROM ContratoOperacion OPE 
		INNER JOIN [Partidas].[dbo].[Contrato] CONT ON OPE.idContrato = CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[ContratoUnidad] CONTUNIDAD ON CONTUNIDAD.idContrato = CONT.idContrato AND CONTUNIDAD.idUnidad = @tipoUnidad
		LEFT JOIN [Partidas].[dbo].[ContratoProveedor] CONTPROV ON CONTPROV.idContrato = CONT.idContrato AND idProveedor = @idTaller
		--INNER JOIN [Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = CONTPROV.idProveedor
		LEFT JOIN [Partidas]..[ProveedorCotizacion] PROVCOT ON PROVCOT.idProveedor = CONTPROV.idProveedor AND PROVCOT.idUnidad = CONTUNIDAD.idUnidad
		LEFT JOIN [Partidas].[dbo].[ProveedorPartida] PROVPART ON PROVPART.idProveedorCotizacion = PROVCOT.idProveedorCotizacion
		INNER JOIN Partidas..Partida PART ON PART.idPartida = PROVPART.idPartida --AND PART.idEspecialidad = PE.idEspecialidad
		LEFT JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON PART.idPartida = CONTPART.idPartida AND CONTPART.idContratoUnidad = CONTUNIDAD.idContratoUnidad
		LEFT JOIN [Partidas].[dbo].[PartidaClasificacion] PARCLAS ON PART.idPartidaClasificacion = PARCLAS.idPartidaClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaSubClasificacion] CL2 ON CL2.idPartidaSubClasificacion = PART.idPartidaSubClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaEstatus] PARTEST ON PARTEST.idPartidaEstatus = PART.estatus						
		LEFT JOIN [Partidas].[dbo].[Proveedor] PROV ON CONTPROV.idProveedor = PROV.idProveedor
		LEFT JOIN [Partidas].[dbo].[Unidad] UNI ON UNI.idUnidad = CONTUNIDAD.idUnidad
		LEFT JOIN [Partidas].[dbo].[Especialidad] ESP ON ESP.idEspecialidad = PART.idEspecialidad
		LEFT JOIN [partidas].[dbo].[PartidaTipoOrdenServicio] PTOS ON PTOS.idPartida = PART.idPartida AND PTOS.idCatalogoTipoOrdenServicio = COALESCE(@idTipoCita, PTOS.idCatalogoTipoOrdenServicio)
		WHERE PART.estatus = 1
		AND PROVPART.idPartidaEstatus = 4 -- aprobado
		AND PROVCOT.idCotizacionEstatus = 3
		and OPE.idContratoOperacion = @idContratoOperacion

go

