-- =============================================
-- Description:	Busca si existe la orden
-- =============================================
-- [dbo].[SEL_EXISTE_ORDEN_SP] @idUsuario = 107, @numeroOrden = '01-2110131-8', @idContratoOperacion = 2
-- [dbo].[SEL_EXISTE_ORDEN_SP] @idUsuario = 312, @numeroOrden = '03-10336-31314', @idContratoOperacion = 3
CREATE PROCEDURE [dbo].[SEL_EXISTE_ORDEN_SP]
	@idUsuario INT = 0,
	@numeroOrden VARCHAR(50) = '',
	@idContratoOperacion INT
AS
BEGIN
	-------------------------------------------------------------------------------------------------------------------------
	-- Busca si la orden existe y si el usuario cumple con los permisos necesarios
	--		 respuesta = 0 <-- No existe la unidad 
	--		 respuesta = 1 <-- Existe la unidad y tiene todos los permisos necesarios 
	--		 respuesta = 2 <-- Existe la unidad pero el tipo de operación no le corresponde
	--		 respuesta = 3 <-- Existe la unidad pero el rol no tiene permisos para visualizar la información
	-------------------------------------------------------------------------------------------------------------------------
	declare @idOperacion int = (select idOperacion from ContratoOperacion where idContratoOperacion = @idContratoOperacion)

	DECLARE @idContratoOperacionUsuario INT
	SELECT @idContratoOperacionUsuario = COU.idContratoOperacionUsuario
	FROM Usuarios U 
		JOIN ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
		JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
	WHERE U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 4
		BEGIN
			IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario, @idOperacion) <> 2
				BEGIN	
					IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario, @idOperacion) <> 9
						BEGIN
								IF(EXISTS(SELECT [numeroOrden] FROM [dbo].[Ordenes] ORD 
														INNER JOIN [dbo].[ContratoOperacion] CO on CO.idContratoOperacion = ORD.idContratoOperacion 
														INNER JOIN ContratoOperacionUsuario COU on COU.idContratoOperacion = CO.idContratoOperacion 
														WHERE ORD.[numeroOrden] = @numeroOrden and ORD.[idContratoOperacion] = @idContratoOperacion 
														and idOrden not in(select idOrden from Cotizaciones where idTaller=689)
														and COU.idUsuario = @idUsuario
														and ORD.idZona in (select idZona from [dbo].[GET_ZONAS_USR_FN]([dbo].[GET_CONTRATO_OPERACION_USR_FN](@idUsuario, @idOperacion)))
														))
									BEGIN
									print '1'
										SELECT 1 AS respuesta
												,'Orden encontrada con éxito' AS mensaje
											FROM [dbo].[Ordenes]
										WHERE [numeroOrden] = @numeroOrden 
									END
								ELSE
									BEGIN
										print 'aqui'
										SELECT 0 AS respuesta , 
												'No se encontró la orden con el número de orden ' + @numeroOrden AS mensaje
												
									END
						END
					ELSE
						BEGIN
							IF(EXISTS(SELECT [numeroOrden] FROM [dbo].[Ordenes] ORD 
										INNER JOIN [dbo].[ContratoOperacion] CO on CO.idContratoOperacion = ORD.idContratoOperacion 
										INNER JOIN ContratoOperacionUsuario COU on COU.idContratoOperacion = CO.idContratoOperacion 
									WHERE ORD.[numeroOrden] = @numeroOrden and ORD.[idContratoOperacion] = @idContratoOperacion 
									and idOrden not in(select idOrden from Cotizaciones where idTaller=689)
									and COU.idUsuario = @idUsuario
									and ORD.idZona in (SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
														JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
														JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
													WHERE EG.estatus=0 AND EZ.estatus=0
													AND COUG.idContratoOperacionUsuario=@idContratoOperacionUsuario AND EZ.idContratoOperacion=@idContratoOperacion)
									))
									BEGIN
									print'2'
										SELECT 1 AS respuesta
												,'Orden encontrada con éxito' AS mensaje
											FROM [dbo].[Ordenes]
										WHERE [numeroOrden] = @numeroOrden 
									END
								ELSE
									BEGIN
								print '7'	
										SELECT 0 AS respuesta , 
												'No se encontró la orden con el número de orden ' + @numeroOrden AS mensaje
												
									END
					END
				END
			ELSE
				BEGIN
					IF(EXISTS(SELECT [numeroOrden] FROM [dbo].[Ordenes] ORD INNER JOIN [dbo].[ContratoOperacion] CO on CO.idContratoOperacion = ORD.idContratoOperacion INNER JOIN ContratoOperacionUsuario COU on COU.idContratoOperacion = CO.idContratoOperacion WHERE ORD.[numeroOrden] = @numeroOrden and ORD.[idContratoOperacion] = @idContratoOperacion and COU.idUsuario = @idUsuario))
						BEGIN
						print '3'
							SELECT 1 AS respuesta
									,'Orden encontrada con éxito' AS mensaje
								FROM [dbo].[Ordenes]
							WHERE [numeroOrden] = @numeroOrden
						END
					ELSE
						BEGIN
						print '6'
							SELECT 0 AS respuesta , 
									'No se encontró la orden con el número de orden ' + @numeroOrden AS mensaje
						END
				END



		END
	ELSE
		BEGIN
			declare @tablaProveedoresAsignados table(idProveedor int)
			insert into @tablaProveedoresAsignados
			select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)

			IF(EXISTS(SELECT [numeroOrden] 
						FROM [dbo].[Ordenes] ORD INNER JOIN [dbo].[ContratoOperacion] CO on CO.idContratoOperacion = ORD.idContratoOperacion INNER JOIN ContratoOperacionUsuario COU on COU.idContratoOperacion = CO.idContratoOperacion 
						WHERE ORD.[numeroOrden] = @numeroOrden and ORD.[idContratoOperacion] = @idContratoOperacion and COU.idUsuario = @idUsuario 
								and ((SELECT CASE WHEN exists 
								(select 1 from Cotizaciones C where C.idOrden = ORD.idOrden and C.idTaller in (select idProveedor from @tablaProveedoresAsignados)) THEN 'true' ELSE 'false' END ) = 'true') 
								or ORD.idUsuario = @idUsuario))
				BEGIN
				print '4'
					SELECT 1 AS respuesta
						  ,'Orden encontrada con éxito' AS mensaje
					 FROM [dbo].[Ordenes]
					WHERE [numeroOrden] = @numeroOrden
				END
			ELSE
				BEGIN
				print '5'
					SELECT 0 AS respuesta , 
						   'No se encontró la orden con el número de orden ' + @numeroOrden AS mensaje
				END

		END
END

--USE [ASEPROT]
go

