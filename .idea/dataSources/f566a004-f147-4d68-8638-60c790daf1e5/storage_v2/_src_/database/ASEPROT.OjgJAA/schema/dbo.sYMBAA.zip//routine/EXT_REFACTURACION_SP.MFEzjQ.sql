
-- [EXT_REFACTURACION_SP] 1
CREATE PROC [dbo].[EXT_REFACTURACION_SP] --1
@isProduction NUMERIC(18,0)
AS
BEGIN
------------------------------------------------------------------------------------------------------------------------------------------
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @idOrden NUMERIC(18,0)
	DECLARE @idOperacion NUMERIC(18,0)
	DECLARE @idContratoOperacion NUMERIC(18,0)
	DECLARE @idUsuario NUMERIC(18,0) =551
	DECLARE @numeroOrden NVARCHAR(100)
	DECLARE @max NUMERIC(18,0)
	--////////////////////////////////
	DECLARE @idProveedor NUMERIC(18,0)
	DECLARE @server NVARCHAR(100)
	DECLARE @db NVARCHAR(100)
	--////////////////////////////////
	DECLARE @queryText NVARCHAR(MAX)
	DECLARE @tableTemp TABLE (val INT)
	DECLARE @queryM NVARCHAR(MAX)
	DECLARE @queryH NVARCHAR(MAX)
	DECLARE @queryC NVARCHAR(MAX)
	DECLARE @OTD_IDENT NVARCHAR(MAX)
	DECLARE @existe INT = 0
	DECLARE @proveedorInterno NUMERIC(18,0)
	--////////////////////////////////
	DECLARE @idDatosCopade INT
	DECLARE @idDatosCopadeOrden INT
	DECLARE @idOrdenAgrupada INT
	DECLARE @idOrdenAgrupadaDetalle INT
	DECLARE @numero NVARCHAR(100)
	--////////////////////////////////

	DECLARE cursor_refacturacion CURSOR FOR
	SELECT numeroOrden FROM Refacturacion WHERE estatus=0

	OPEN cursor_refacturacion  
	FETCH NEXT FROM cursor_refacturacion INTO @numeroOrden
	WHILE @@FETCH_STATUS = 0  
		BEGIN 

		SELECT @idOrden=idOrden, 
			   @idContratoOperacion=idContratoOperacion 
		FROM Ordenes 
		WHERE numeroOrden = @numeroOrden

		SELECT @idOperacion=idOperacion FROM ContratoOperacion WHERE idContratoOperacion = @idContratoOperacion

		  --Actualiza el trabajo de estatus y inserta en BPRO
		  SELECT @idCotizacion = MIN(C.idCotizacion) 
		  FROM Cotizaciones C 
		  WHERE C.idOrden = @idOrden AND idTaller <> 0 

		  SELECT @proveedorInterno = proveedorInterno
		  FROM ContratoOperacionFacturacion 
		  WHERE idContratoOperacion = @idContratoOperacion
				
			SELECT @idProveedor = idTaller FROM Cotizaciones WHERE idCotizacion=@idCotizacion
			IF((@idProveedor <> 291 AND @idProveedor <> 292 AND @idProveedor <> 293 AND @idProveedor <> 294) OR @proveedorInterno = 0)
				BEGIN
					IF(@isProduction = 1)
						BEGIN
							SELECT 
									@server = SERVER,
									@db = DBProduccion
							FROM ContratoOperacionFacturacion COF 
							inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
							WHERE CO.idContratoOperacion =  @idContratoOperacion
						END
					ELSE
						BEGIN
							SELECT 
									@server=SERVER,
									@db=DB
							FROM ContratoOperacionFacturacion COF 
							inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
							WHERE CO.idContratoOperacion =  @idContratoOperacion
						END

								IF(@idContratoOperacion = 3)
									BEGIN
										SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_STATUS] IN(9) AND [OTE_ORDENANDRADE] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
										INSERT INTO @tableTemp EXEC(@queryText) 
										SET @existe = (SELECT TOP 1 val FROM @tableTemp)

										IF(@existe = 1)
											BEGIN
												IF NOT EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
													BEGIN
														SELECT 1 Success, 'La Orden se quito la provision exitosamente GAAutoExpress' Msg
													IF EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
														BEGIN
															UPDATE AprobacionProvision
															SET estatus=0
															where idOrden=@idOrden
														END
															SET @OTD_IDENT = 'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
														SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET] WHERE [OTD_IDENT] = ('+@OTD_IDENT+') '
														SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
														EXEC(@queryM) EXEC(@queryH) 
													END
												ELSE
													BEGIN
														SELECT 0 Success, 'La Orden ya se encuentra asociada no se puede eliminar GAAutoExpress' Msg
													END
											END
										ELSE
											BEGIN
												SELECT 0 Success, 'Orden registrada en Bpro con estados procesado que no se puede eliminar GAAutoExpress' Msg
											END
									END
								ELSE IF(@idContratoOperacion = 1)
									BEGIN
										SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_STATUS] IN(0,1,2,3,4,5,6) AND [OTE_ORDENANDRADE] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
										INSERT INTO @tableTemp EXEC(@queryText) 
										SET @existe = (SELECT TOP 1 val FROM @tableTemp)

										IF(@existe = 1)
											BEGIN
											print 'entra'
												IF EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
													BEGIN
													print 'ya entra'
														SELECT 1 Success, 'La Orden se quito la provision exitosamente GATPartsToluca' Msg
													
														--IF EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
														--	BEGIN
														--		UPDATE AprobacionProvision
														--		SET estatus=0
														--		where idOrden=@idOrden
														--	END
														--ELSE
														--	BEGIN
														--		INSERT AprobacionProvision VALUES(@idOrden,GETDATE(),@idUsuario,0)
														--	END
															
														SET @OTD_IDENT = 'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
														SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET] WHERE [OTD_IDENT] = ('+@OTD_IDENT+') '
														SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
														EXEC(@queryM) EXEC(@queryH) 

															--UPDATE Ordenes
															--SET idEstatusOrden=8
															--WHERE idOrden=@idOrden

															--DELETE FROM HistorialEstatusOrden 
															--WHERE idOrden=@idOrden AND idEstatusOrden IN(9,10,11,12,14)

															--UPDATE HistorialEstatusOrden 
															--SET fechaFinal=NULL
															--WHERE idOrden=@idOrden AND idEstatusOrden IN(8)

															EXEC [INS_ORDEN_PAGO_PROVISION_SP] @idOrden, @idUsuario, @idOperacion, @isProduction

															UPDATE Refacturacion
															SET estatus=1
															WHERE numeroOrden = @numeroOrden

													END
												--ELSE
												--	BEGIN
												--		SELECT @idDatosCopade=idDatosCopade FROM DatosCopadeOrden WHERE idOrden=@idOrden
												--			IF EXISTS (SELECT idDatosCopade FROM DatosCopade WHERE idDatosCopade=@idDatosCopade)
												--				BEGIN
												--					--SELECT @idDatosCopade=idDatosCopade FROM DatosCopade WHERE numeroCopade=@numeroCopade
												--					SELECT @idDatosCopadeOrden=idDatosCopadeOrden FROM DatosCopadeOrden WHERE idDatosCopade=@idDatosCopade
												--					SELECT @idOrdenAgrupadaDetalle=idOrdenAgrupadaDetalle, @idOrdenAgrupada=idOrdenAgrupada FROM OrdenAgrupadaDetalle where idDatosCopadeOrden=@idDatosCopadeOrden
												--					SELECT @numero=numero FROM OrdenAgrupada WHERE idOrdenAgrupada=@idOrdenAgrupada

												--					DELETE FROM OrdenAgrupadaDetalle
												--					WHERE idDatosCopadeOrden=@idDatosCopadeOrden

												--					DELETE FROM OrdenAgrupada
												--					WHERE idOrdenAgrupada=@idOrdenAgrupada

												--					DELETE FROM DatosCopadeOrden
												--					WHERE idDatosCopade=@idDatosCopade

												--					DELETE FROM [192.168.20.31].[GATPartsToluca].[dbo].[ADE_COPADE]
												--					WHERE COP_ORDENGLOBAL=@numero

												--					IF NOT EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
												--						BEGIN
												--							SELECT 1 Success, 'La Orden se quito la provision exitosamente GATPartsToluca' Msg
													
												--							IF EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
												--								BEGIN
												--									UPDATE AprobacionProvision
												--									SET estatus=0
												--									where idOrden=@idOrden
												--								END
												--							ELSE
												--								BEGIN
												--									INSERT AprobacionProvision VALUES(@idOrden,GETDATE(),@idUsuario,0)
												--								END
															
												--							SET @OTD_IDENT = 'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
												--							SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET] WHERE [OTD_IDENT] = ('+@OTD_IDENT+') '
												--							SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
												--							EXEC(@queryM) EXEC(@queryH) 

												--							UPDATE Ordenes
												--							SET idEstatusOrden=8
												--							WHERE idOrden=@idOrden

												--							DELETE FROM HistorialEstatusOrden 
												--							WHERE idOrden=@idOrden AND idEstatusOrden IN(9,10,11,12,14)

												--							UPDATE HistorialEstatusOrden 
												--							SET fechaFinal=NULL
												--							WHERE idOrden=@idOrden AND idEstatusOrden IN(8)

												--							EXEC [INS_ORDEN_PAGO_PROVISION_SP] @idOrden, @idUsuario, @idOperacion, @isProduction

												--							UPDATE Refacturacion
												--							SET estatus=1
												--							WHERE numeroOrden = @numeroOrden

												--						END
												--				END
												--			ELSE
												--				BEGIN
												--					 PRINT 'LA EL NUMERO DE COPADE NO EXISTE'
												--				END
												--		--SELECT 0 Success, 'La Orden ya se encuentra asociada no se puede eliminar GATPartsToluca' Msg
												--	END
											END
										ELSE
											BEGIN
												SELECT 0 Success, 'Orden registrada en Bpro con estados procesado que no se puede eliminar GATPartsToluca' Msg
											END
									END
								ELSE IF(@idContratoOperacion = 5)
									BEGIN
										SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_STATUS] IN(9) AND [OTE_ORDENANDRADE] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
										INSERT INTO @tableTemp EXEC(@queryText) 
										SET @existe = (SELECT TOP 1 val FROM @tableTemp)

										IF(@existe = 1)
											BEGIN
												IF NOT EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
													BEGIN
													SELECT 1 Success, 'La Orden se quito la provision exitosamente GAIntegra' Msg
														IF EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
														BEGIN
															UPDATE AprobacionProvision
															SET estatus=0
															where idOrden=@idOrden
														END
															SET @OTD_IDENT = 'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
														SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET] WHERE [OTD_IDENT] = ('+@OTD_IDENT+') '
														SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
														EXEC(@queryM) EXEC(@queryH) 
													END
												ELSE
													BEGIN
														SELECT 0 Success, 'La Orden ya se encuentra asociada no se puede eliminar GAIntegra' Msg
													END
											END
										ELSE
											BEGIN
												SELECT 0 Success, 'Orden registrada en Bpro con estados procesado que no se puede eliminar GAIntegra' Msg
											END
									END
						 --SELECT 1 Proceso
				END
			ELSE
				BEGIN
					IF(@isProduction = 1)
					BEGIN
						SELECT 
									@server = SERVER,
									@db = DBProduccion
							FROM CatalogoTecnico CT 
							WHERE CT.IdProveedor =  @idProveedor
						END
					ELSE
						BEGIN
							SELECT 
									@server = SERVER,
									@db = DBProduccion
							FROM CatalogoTecnico CT 
							WHERE CT.IdProveedor =  @idProveedor
						END
							BEGIN	
									SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE [oae_estatus] IN(0,1,2,3,4,5,6) AND [oae_ordenglobal] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
									INSERT INTO @tableTemp EXEC(@queryText) 
									SET @existe = (SELECT TOP 1 val FROM @tableTemp)
									print @queryText
									IF(@existe = 1)
										BEGIN
											IF NOT EXISTS(SELECT 1 FROM DatosCopadeOrden WHERE idOrden = @idOrden)
												BEGIN
													SELECT 1 Success, 'La Orden se quito la provision exitosamente GATPartsDHL' Msg	
														SET @OTD_IDENT = 'SELECT oae_idorden FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE [oae_ordenglobal] = '''+@numeroOrden+''' '
													SET @queryM = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ser_ordenasedet] WHERE [oad_iddetalle] = ('+@OTD_IDENT+') '
													SET @queryH = 'DELETE FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE [oae_ordenglobal] = '''+@numeroOrden+''' '
													EXEC(@queryM) EXEC(@queryH) 

														UPDATE Refacturacion
														SET estatus=1
														WHERE numeroOrden = @numeroOrden
												END
											ELSE
												BEGIN
													SELECT 0 Success, 'La Orden ya se encuentra asociada no se puede eliminar GATPartsDHL' Msg
												END
										END
									ELSE
										BEGIN
											SELECT 0 Success, 'Orden registrada en Bpro con estados procesado que no se puede eliminar GATPartsDHL' Msg
										END
							END
						-- SELECT 1 Proceso
				END


			FETCH NEXT FROM cursor_refacturacion INTO @numeroOrden
		END  
	CLOSE cursor_refacturacion  
	DEALLOCATE cursor_refacturacion
------------------------------------------------------------------------------------------------------------------------------------------
END
go

