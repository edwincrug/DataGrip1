CREATE procedure [dbo].[SEL_ORDEN_SSC_SP]
AS
BEGIN
SELECT id, idOrden, numeroOrden FROM OrdenSSC WHERE id > 10000
END
go

