
-- =============================================
-- Author:		
-- Create date: <12/01/2018>
-- Description:	<GENERA EL DETALLE DEL EC PROVEEDOR OPERACION 3>
--Test: [report].[INS_EC_DETALLEGAT_PARTSArrenda]
--select * from report.EC_DETALLEGAT_PARTSArrenda
-- =============================================

CREATE PROCEDURE [report].[INS_EC_DETALLEGAT_PARTSArrenda]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE FROM report.EC_DETALLEGAT_PARTSArrenda
	INSERT INTO report.EC_DETALLEGAT_PARTSArrenda
	select DISTINCT
		cont.idOperacion,
		ISNULL(ose.OTE_FACTURACOMPRA, 'S/F') FACTURA, 
		ord.idOrden,
		ord.numeroOrden,
		--cot.idCotizacion,
		enc.idBPRO,
		pe.razonSocial,
		ROUND((select (ISNULL(SUM(costo * cantidad),0)) * [dbo].[fnFactorIVA_Orden](ord.idOrden ,1) from CotizacionDetalle where idCotizacion = cot.idCotizacion),2) TOTALSISCO,
		ISNULL(VSC.SALDO,ROUND((select (ISNULL(SUM(costo * cantidad),0)) * [dbo].[fnFactorIVA_Orden](ord.idOrden ,1) from CotizacionDetalle where idCotizacion = cot.idCotizacion),2)) SALDO,
		est.idEstatusOrden IDESTATUSORDEN,
		est.nombreEstatusOrden ESTATUSORDEN,
		GETDATE()
	from Ordenes ord
	inner join Cotizaciones cot on ord.idOrden = cot.idOrden and cot.idestatuscotizacion not in(4,5)
	inner join Partidas..Proveedor p on cot.idTaller = p.idProveedor
	inner join Partidas..ProveedorEncabezado pe on p.idProveedorEncabezado = pe.idProveedorEncabezado
	inner join Partidas..ProveedorEncabezadoEmpresa enc on pe.idProveedorEncabezado = enc.idProveedorEncabezado and enc.idEmpresa = 1 
	inner join ContratoOperacion cont on cont.idContratoOperacion = ord.idContratoOperacion	
	inner join EstatusOrdenes est on est.idEstatusOrden = ord.idEstatusOrden
	full outer join [192.168.20.29].GATPartsArrenda.dbo.ADE_ORDSERENC ose on ose.OTE_ORDENANDRADE = ord.numeroOrden collate MODERN_SPANISH_CI_AS and ose.OTE_IDPROVEEDOR = enc.idBPRO
	left join [ASEPROT].[cobranza].[VwInvoiceProvSaldoBPRO_GATPartsArrenda] VSC on VSC.CCP_IDPERSONA = ose.OTE_IDPROVEEDOR and VSC.CCP_IDDOCTO collate MODERN_SPANISH_CI_AS = ose.OTE_FACTURACOMPRA collate MODERN_SPANISH_CI_AS
	where cot.idTaller <> 0 and cont.idContratoOperacion = 55
	order by PE.RAZONSOCIAL
	



	/*
	select
		cont.idOperacion,
		ose.OTE_FACTURACOMPRA FACTURA,
		ord.idOrden	IDORDEN,
		ord.numeroOrden NUMEROORDEN,
		cot.idCotizacion NOCOTIZACION,
		p.idProveedor IDPROVEEDOR,
		p.nombreComercial NOMBRECOMERCIAL,
		--ose.OTE_TOTAL TOTALBPRO,
		(select (ISNULL(SUM(costo * cantidad),0)) * 1.16 from CotizacionDetalle where idCotizacion = cot.idCotizacion),
		ISNULL(VSC.SALDO,0) SALDO,
		est.idEstatusOrden IDESTATUSORDEN,
		est.nombreEstatusOrden ESTATUSORDEN,
		GETDATE()
	from [192.168.20.29].GAAutoExpress.dbo.ADE_ORDSERENC ose
	full outer join Ordenes ord on ose.OTE_ORDENANDRADE collate MODERN_SPANISH_CI_AS = ord.numeroOrden collate MODERN_SPANISH_CI_AS
	left join Cotizaciones cot on ord.idOrden = cot.idOrden
	
	--left join CotizacionDetalle cdet on cot.idCotizacion = cdet.idcotizacion
	left join ContratoOperacion cont on cont.idContratoOperacion = ord.idContratoOperacion
	--left join [cobranza].[VwStatusCotizacionBase] VSC ON VSC.[idCotizacion] = cot.idCotizacion
	left join Partidas..Proveedor p on cot.idTaller = p.idProveedor
	left join Partidas..ProveedorEncabezadoEmpresa enc on P.idProveedorEncabezado = enc.idProveedorEncabezado and enc.idEmpresa = 1
	left join EstatusOrdenes est on est.idEstatusOrden = ord.idEstatusOrden

	left join [ASEPROT].[cobranza].[VwInvoiceProvSaldoBPRO_GAAutoExpress] VSC on VSC.CCP_IDPERSONA = enc.idBPRO and VSC.CCP_IDDOCTO collate MODERN_SPANISH_CI_AS = ose.OTE_FACTURACOMPRA collate MODERN_SPANISH_CI_AS
	where cot.idTaller<>0 --and ord.idContratoOperacion = 3 
order by NOMBRECOMERCIAL*/

END
go

