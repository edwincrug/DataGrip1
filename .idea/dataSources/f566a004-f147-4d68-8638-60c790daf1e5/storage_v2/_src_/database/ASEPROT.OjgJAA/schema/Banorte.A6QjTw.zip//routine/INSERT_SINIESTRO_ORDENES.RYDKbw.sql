-- =============================================
-- Author:		<YJH>
-- Create date: <28/06/2018>
-- Description:	<Inserta la relacion de Siniestros Banorte con Ordnes de SISCO>
-- =============================================
CREATE PROCEDURE [Banorte].[INSERT_SINIESTRO_ORDENES]
	@idOrden int, 
	@idSiniestro varchar(max)
AS
BEGIN
	DECLARE @fecha date= GETDATE()
	IF NOT EXISTS(select 1 from OrdenSiniestro where idSiniestro = @idSiniestro and idOrden = @idOrden)
	BEGIN
		INSERT INTO OrdenSiniestro (idOrden, idSiniestro, fechaAlta) 
		VALUES (@idOrden, @idSiniestro, @fecha)
	END
END
go

grant execute, view definition on Banorte.INSERT_SINIESTRO_ORDENES to DevOps
go

