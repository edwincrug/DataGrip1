-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 02/10/2018
-- Description:	Obtiene la lista de tokens y los mensajes para enviarlos a los dispositivos moviles
-- EXEC [Mobile].[Sel_Token_Notification_Sp]
-- =============================================
CREATE PROCEDURE [Mobile].[Sel_Token_Notification_Sp]
AS
BEGIN

	SELECT DISTINCT 
		up.idUnidad
		,up.vin
		,up.idDocumento
		,up.valor
		,CONVERT(Date, up.valor, 103) fecha
		,CASE WHEN up.idDocumento = 48 
			THEN 'Estimado ' + us.nombreCompleto + ' tu póliza de la unidad ' + up.vin + ' esta proxima a vencerse el dia ' + up.valor
			WHEN up.idDocumento = 49 
			THEN 'Estimado ' + us.nombreCompleto + ' tu verificación de la unidad ' + up.vin + ' esta proxima a vencerse el dia ' + up.valor
			WHEN up.idDocumento = 50 
			THEN 'Estimado ' + us.nombreCompleto + ' tu tenencia de la unidad ' + up.vin + ' esta proxima a vencerse el dia ' + up.valor
		END mensaje
		,us.nombreCompleto
		,mu.token
	FROM [Flotillas].[dbo].[UnidadPropiedad] up 
		INNER JOIN [dbo].[Unidades] u ON up.vin = u.vin
		INNER JOIN [dbo].[usuarioUnidadContratoOperacion] uuco ON u.idUnidad = uuco.idUnidad
		INNER JOIN [dbo].[Usuarios] us ON us.idUsuario = uuco.idUsuario
		INNER JOIN [ASEPROT].[Mobile].[Usuario] mu ON us.idUsuario = mu.idUsuario 
	WHERE up.idDocumento IN (48,49,50) 
		AND (CONVERT(Date, up.valor, 103) BETWEEN DATEADD(day, -1, GETDATE()) AND DATEADD(day, 1, GETDATE())
		OR CONVERT(Date, up.valor, 103) BETWEEN DATEADD(day, 4, GETDATE()) AND DATEADD(day, 6, GETDATE()))

END
go

grant execute, view definition on Mobile.Sel_Token_Notification_Sp to DevOps
go

