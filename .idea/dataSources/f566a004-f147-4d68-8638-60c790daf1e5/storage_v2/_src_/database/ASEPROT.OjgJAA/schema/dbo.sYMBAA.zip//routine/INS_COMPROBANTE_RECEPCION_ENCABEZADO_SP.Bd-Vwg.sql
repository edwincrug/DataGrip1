-- [INS_COMPROBANTE_RECEPCION_SP] 1,'03-1633010405572-000067'
create PROCEDURE [dbo].[INS_COMPROBANTE_RECEPCION_ENCABEZADO_SP]
@idCatalogoModuloLevantamiento INT,
@numeroOrden VARCHAR(50)
--,@idUsuario INT
AS
BEGIN
		 DECLARE @idOrden NUMERIC(18,0)
		 DECLARE @idOrdenModuloLevantamiento INT

	 SET @idOrden = (SELECT idOrden FROM Ordenes WHERE numeroOrden = @numeroOrden )
	
	INSERT INTO OrdenModuloLevantamiento VALUES(@idCatalogoModuloLevantamiento, @idOrden)
	SET @idOrdenModuloLevantamiento = @@IDENTITY
	SELECT @idOrdenModuloLevantamiento AS idOrdenModuloLevantamiento, 'Se agrego modulo'AS msg,1 AS estatus

END
go

