-- =============================================
-- Author:		<YJH>
-- Create date: <25/06/2018>
-- Description:	<Verifca que la orden de servicio tenga factura y vale de surtimiento>
--39137, 39138, 39139, 39145
-- [Banorte].[SEL_ESTATUS_AVANCE_FN] 39197, 0, 18
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_ESTATUS_AVANCE_FN] 
	@idOrden NUMERIC,	
	@idContratoOperacion int,
	@cantidadNumCompra int,
	@hasFactura NUMERIC output,
	@hasValeI NUMERIC output,
	@hasValeF NUMERIC output	
AS
BEGIN
	DECLARE @result NUMERIC = 0

if (@cantidadNumCompra > 0) 
	set @result=-1 -- no se puede modificar la orden

SELECT	
	  --ORD.idOrden,
	  --COTI.idCotizacion,
	  --COTI.numeroCotizacion,
	@hasFactura= MIN([dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](ORD.idOrden,3,COTI.ConsecutivoCotizacion))
	,@hasValeI=MIN((ISNULL([Banorte].[GET_VALES_BANORTE](ORD.idOrden, 'ValeInicial'),0)))
	,@hasValeF=MIN((ISNULL([Banorte].[GET_VALES_BANORTE](ORD.idOrden, 'ValeFinal'),0)))
from Ordenes ORD 
INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden and COTI.idEstatusCotizacion=3
where ORD.idOrden= @idOrden


return @hasFactura
return @hasValeI 
return @hasValeF
END

go

grant execute, view definition on Banorte.SEL_ESTATUS_AVANCE_FN to DevOps
go

