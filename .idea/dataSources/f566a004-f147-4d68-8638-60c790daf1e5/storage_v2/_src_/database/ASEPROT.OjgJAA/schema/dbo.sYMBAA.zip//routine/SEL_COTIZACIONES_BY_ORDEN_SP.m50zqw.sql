
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 29/05/2017
-- Description:	Se obtienen las cotizaciones de una orden 
-- ==========================================================================================
-- [SEL_COTIZACIONES_BY_ORDEN_SP] @numeroOrden ='01-2810044-142',@estatus = '2'

CREATE PROCEDURE [dbo].[SEL_COTIZACIONES_BY_ORDEN_SP]
    @idOrden INT

AS   
BEGIN

	SELECT idCotizacion, numeroCotizacion FROM Cotizaciones 
	WHERE idOrden=@idOrden --AND idTaller <> 0 
	AND idEstatusCotizacion IN(1,2,3)

END
go

