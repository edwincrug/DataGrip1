-- [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP_Alcabelu]  1
-- [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP_Alcabelu]  3
-- [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP_Alcabelu]  3,null,null,null,12
CREATE procedure  [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP_Alcabelu] 

@idOperacion as int = null,
@fechaInicial as varchar(25) =NULL,
@fechaFinal as varchar(25)= NULL,
@taller as varchar(150)= NULL,
@idCallcenter as int=NULL,
@idEstatus as int= NULL,
@idZona as int=NULL,
@numeroOrden varchar(50) = NULL

AS
BEGIN
       print 'ZonaAsisnada'
	   print @idZona
		DECLARE @zonasAsignadas TABLE (idZona INT NOT NULL)
		if(@idZona IS NOT NULL)
		BEGIN
			print 'Voy a insertar'
			INSERT INTO @zonasAsignadas values(isnull(@idZona,0))
		END

		IF(@idCallcenter IS NOT NULL)
		BEGIN
		    print 'Voy por las zonas del idCallcenter'
			DECLARE @idCOU NUMERIC(18,0) = [dbo].[GET_CONTRATO_OPERACION_USR_FN](@idCallcenter ,@idOperacion)		
			print 'Valor de idCou'
			print @idCOU
			INSERT INTO @zonasAsignadas 
			SELECT idZona FROM [dbo].[GET_ZONAS_USR_FN](@idCOU)			
		END

		IF(@idCallcenter IS NULL AND  @idZona IS NULL)
		BEGIN
		    print 'IDcalllcenter null and idZOna is null'
			--INSERT INTO @zonasAsignadas 			
			--SELECT Z.idZona FROM ContratoOperacion CO
			--INNER JOIN Partidas..Contrato C ON CO.idContrato= C.idContrato
			--INNER JOIN Partidas..Licitacion L ON l.idLicitacion = c.idLicitacion
			--INNER JOIN Partidas..NivelZona NZ ON l.idCliente = NZ.idCliente
			--INNER JOIN Partidas..Zona Z ON NZ.idNivelZona = Z.idNivelZona
			--WHERE idOperacion=@idOperacion 
			print 'inserte todas las zonas por idOperacion'
		END

		--Declare @SumCosto NUMERIC(18,4)
		Declare @SumVenta NUMERIC(18,4)

		--SELECT  @SumCosto = sum(costo), @SumVenta = sum(Venta)
		--FROM 	[report].[VwReporteAntiguedadSaldos]	
			
		--WHERE	fechaCreacionOrden 
		--BETWEEN isnull(@fechaInicial,convert(datetime,'1/1/1800')) 
		--AND		isnull(@fechaFinal,convert(datetime,'1/1/2500'))
		--AND		(@taller IS NULL OR talleres like '%'+ @taller +'%') 
		--AND		(@idEstatus IS NULL OR idEstatus=@idEstatus ) 
		--AND		(@numeroOrden IS NULL OR numeroOrden like '%'+ @numeroOrden+ '%') 
		--AND		idZona IN (select idZona from @zonasAsignadas)
		--AND     [idOperacion] = @idOperacion
		--AND     [idEstatusOrden] < 13


if(@idOperacion = 3)
		BEGIN

		    declare @rowZones int
			select @rowZones = count(*)
			from @zonasAsignadas
			where idZona > 0

			print 'Row Zones'
			print @rowZones

			if(@rowZones = 0)

			begin

			SELECT [Cliente]
				  ,[idOrden]
				  ,[consecutivoOrden]
				  ,[numeroOrden]
				  ,[numeroEconomico]
				  ,[idZona]
				  ,[talleres]
				  ,[costo]
				  ,[venta]
				  ,[descripcion]
				  ,[estatus]
				  ,[idEstatus]
				  ,[fechaCreacionOrden]
				  ,[fechaAprobacion]
				  ,[fechaProceso]
				  ,[fechaTerminoTrabajo]
				  ,[fechaSalidaV]
				  ,[fechadeFinalizacionV]
				  ,[dias_0_30]
				  ,[dias_31_45]
				  ,[dias_46_60]
				  ,[dias_mas_60]
				  ,[dias]
				  ,[diasD]
				  ,[zonasConcatenadas]
				  ,[nombrePadre]
				  ,[nombreZona]
				  ,[tipoUnidad]
				  ,[tipoCombustible]
				  ,[marca]
				  ,[subMarca]
				  ,[modelo]
				  ,isnull([folio],'Sin Folio') as [folio]
				  ,[folioPresupuesto]
				  ,[idOperacion]
				  ,[idEstatusOrden]
				  ,[numCop]
			  FROM [ASEPROT].[report].[VwReporteGeneralCopadeExpressDef]			

			  WHERE	(fechaCreacionOrden 
					 BETWEEN isnull(@fechaInicial,convert(datetime,'1/1/2000')) 
					 AND		isnull(@fechaFinal,convert(datetime,'1/1/2050')) 
					 )
		    	AND		(@taller IS NULL OR talleres like '%'+ @taller +'%') 
					AND		(@idEstatus IS NULL OR idEstatus=@idEstatus ) 
					AND		(@numeroOrden IS NULL OR numeroOrden like '%'+ @numeroOrden + '%') 
					--AND (
					--      CASE @rowZones  
					--	  WHEN 0
					--	  THEN
					--		   [idZona] = [idZona]
					--	  ELSE idZONA IN (select idZona from @zonasAsignadas)
					--	  END
					--	)
					--AND		idZona IN (select idZona from @zonasAsignadas)
					--AND     [idOperacion] = @idOperacion
					--AND     [idEstatusOrden] < 13
			  end
			  else
			  begin

					SELECT [Cliente]
				  ,[idOrden]
				  ,[consecutivoOrden]
				  ,[numeroOrden]
				  ,[numeroEconomico]
				  ,[idZona]
				  ,[talleres]
				  ,[costo]
				  ,[venta]
				  ,[descripcion]
				  ,[estatus]
				  ,[idEstatus]
				  ,[fechaCreacionOrden]
				  ,[fechaAprobacion]
				  ,[fechaProceso]
				  ,[fechaTerminoTrabajo]
				  ,[fechaSalidaV]
				  ,[fechadeFinalizacionV]
				  ,[dias_0_30]
				  ,[dias_31_45]
				  ,[dias_46_60]
				  ,[dias_mas_60]
				  ,[dias]
				  ,[diasD]
				  ,[zonasConcatenadas]
				  ,[nombrePadre]
				  ,[nombreZona]
				  ,[tipoUnidad]
				  ,[tipoCombustible]
				  ,[marca]
				  ,[subMarca]
				  ,[modelo]
				  ,isnull([folio],'Sin Folio') as [folio]
				  ,[folioPresupuesto]
				  ,[idOperacion]
				  ,[idEstatusOrden]
				  ,[numCop]
			  FROM [ASEPROT].[report].[VwReporteGeneralCopadeExpressDef]			

			  WHERE	(fechaCreacionOrden 
					 BETWEEN isnull(@fechaInicial,convert(datetime,'1/1/2000')) 
					 AND		isnull(@fechaFinal,convert(datetime,'1/1/2050')) 
					 )
		    	AND		(@taller IS NULL OR talleres like '%'+ @taller +'%') 
					AND		(@idEstatus IS NULL OR idEstatus=@idEstatus ) 
					AND		(@numeroOrden IS NULL OR numeroOrden like '%'+ @numeroOrden + '%') 
					--AND (
					--      CASE @rowZones  
					--	  WHEN 0
					--	  THEN
					--		   [idZona] = [idZona]
					--	  ELSE idZONA IN (select idZona from @zonasAsignadas)
					--	  END
					--	)
					AND		idZona IN (select idZona from @zonasAsignadas)
					--AND     [idOperacion] = @idOperacion
					--AND     [idEstatusOrden] < 13

			  end

		
		end
		else
		begin


		SELECT  
		        [Cliente]
			   ,VRA.[idOrden]
               ,[consecutivoOrden]
               ,[numeroOrden]
               ,[numeroEconomico]
               ,[idZona]
               ,[talleres]
               ,[costo]
               ,[venta]
               ,[descripcion]
               ,[estatus]
               ,[idEstatus]
               ,[fechaCreacionOrden]
               ,[fechaAprobacion]
               ,[fechaProceso]
               ,[fechaTerminoTrabajo]
               ,[fechaSalidaV]
               ,[fechadeFinalizacionV]
               ,[dias_0_30]
               ,[dias_31_45]
               ,[dias_46_60]
               ,[dias_mas_60]
               ,[dias]
               ,[diasD]
               ,[zonasConcatenadas]
               ,[nombrePadre]
               ,[nombreZona]
               ,[tipoUnidad]
               ,[tipoCombustible]
               ,[marca]
               ,[subMarca]
               ,[modelo]
               ,isnull([folio],'Sin Folio') as [folio]
               ,[folioPresupuesto]
               ,[idOperacion]
               ,[idEstatusOrden] 
			   ,VRC.[COP_IDDOCTO] as numCop
		FROM 	[report].[VwReporteAntiguedadSaldos] VRA	
  INNER JOIN    [report].[VwReporteGeneralCopadeTolucaUnique] VRC
          ON    VRA.idOrden = VRC.idOrden
			
		WHERE	fechaCreacionOrden 
		BETWEEN isnull(@fechaInicial,convert(datetime,'1/1/2000')) 
		AND		isnull(@fechaFinal,convert(datetime,'1/1/2050'))
		--AND		(@taller IS NULL OR talleres like '%'+ @taller +'%') 
		AND		(@idEstatus IS NULL OR idEstatus=@idEstatus ) 
		--AND		(@numeroOrden IS NULL OR numeroOrden like '%'+ @numeroOrden+ '%') 
		AND		idZona IN (select idZona from @zonasAsignadas)
		AND     [idOperacion] = @idOperacion
		--AND     [idEstatusOrden] < 13

		end
		
END
go

