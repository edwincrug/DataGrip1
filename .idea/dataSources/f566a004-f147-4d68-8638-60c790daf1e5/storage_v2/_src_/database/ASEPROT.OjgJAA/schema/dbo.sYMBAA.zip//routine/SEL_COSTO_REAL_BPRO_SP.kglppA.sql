-- =============================================
-- Author:		
-- Create date: 01/06/2018
-- Description:	
-- SEL_COSTO_REAL_BPRO_SP 27299
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_COSTO_REAL_BPRO_SP]
	@idOrden INT 
AS
BEGIN
	DECLARE @numeroOrden nvarchar(30)

	set @numeroOrden = (SELECT numeroOrden FROM Ordenes WHERE idorden = @idOrden)

	SELECT COSTO FROM [Bpro].[CostoRealOrden] WHERE OAE_ORDENGLOBAL = @numeroOrden

END


go

