
/*
	Objetivo: Obtiene el detalle de las ordenes levantadas desde el sistema de refacciones
	Fecha			Autor			Descripción
	06/06/2018		YJH				Creacion del SP
	07/08/2018		José Etmanuel	Se modifico Para rechazos parciales
	05/09/2018      Juan Carlos		Se modifico el nivel de Orden para traer el Pedido y Cotización Inpart
	12/09/2018		Christian Ochoa	Se agrega el usuario a la orden y cotización para poder filtrar ordenes por usuario
	16/10/2018		Christian Ochoa	Se agregan columnas de usuario, proveedor, taller, contrato, unidad
	*---  Pruebas
	 [Banorte].[SEL_ORDENES_REFACCIONES] '39359','39360','39363','39364', 1176, 0, 18
	 [Banorte].[SEL_ORDENES_REFACCIONES] @ordenes='43850,43851,43852,43862,43868', @idTaller=1194, @isProduction=0, @idContratoOperacion=18

	 select * from ordenes where idContratoOperacion=18
*/

CREATE PROCEDURE [Banorte].[SEL_ORDENES_REFACCIONES_BK]
	@ordenes varchar(max),
	@idTaller int,
	@isProduction int,
	@idContratoOperacion int 
AS
BEGIN
DECLARE @queryOrdenes nvarchar(max) = 'select  ORD.idOrden, ORD.fechaCreacionOden,  ORD.idEstatusOrden as estatus,
ORD.numeroOrden, ORD.idUsuario, 
  (CASE idEstatusOrden WHEN 15 THEN '''+'NO ASIGNADA'+''' ELSE '''+'' +''' END) as estatusAsignada,
CASE WHEN cs.idCotizacionSisre IS NULL 
THEN (SELECT TOP 1 Co.cotizacionInpart FROM [RefaccionMultiMarca].[Relacion].[SiniestroOrdenCotizacion] SiOrCo JOIN [RefaccionMultiMarca].[Operacion].[Cotizacion] Co ON SiOrCo.idCotizacion = Co.idCotizacion WHERE SiOrCo.idSiniestro=SOC.idSiniestro AND SiOrCo.idOrden=SOC.idOrden AND Co.cotizacionInpart IS NOT NULL ORDER BY Co.idCotizacion ASC) 
ELSE (SELECT TOP 1 SO.folioSolicitud FROM [RefaccionMultiMarca].[Operacion].[CotizacionSisre] CSE JOIN [RefaccionMultiMarca].[Operacion].[Solicitud] SO ON SO.idSolicitud = CSE.idSolicitud AND CSE.idCotizacionSisre = cs.idCotizacionSisre) END cotizacionInpart,
CASE WHEN cs.idCotizacionSisre IS NULL 
THEN (SELECT TOP 1 Co.pedidoInpart FROM [RefaccionMultiMarca].[Relacion].[SiniestroOrdenCotizacion] SiOrCo JOIN [RefaccionMultiMarca].[Operacion].[Cotizacion] Co ON SiOrCo.idCotizacion = Co.idCotizacion WHERE SiOrCo.idSiniestro=SOC.idSiniestro AND SiOrCo.idOrden=SOC.idOrden AND Co.pedidoInpart IS NOT NULL ORDER BY Co.idCotizacion ASC) 
ELSE (SELECT TOP 1 CSE.folioPedido FROM [RefaccionMultiMarca].[Operacion].[CotizacionSisre] CSE JOIN [RefaccionMultiMarca].[Operacion].[Solicitud] SO ON SO.idSolicitud = CSE.idSolicitud AND CSE.idCotizacionSisre = cs.idCotizacionSisre) END pedidoInpart,
CASE WHEN cs.idCotizacionSisre IS NULL THEN ''1'' ELSE ''0'' END validaPedido,
U.idUnidad, CU.idContratoUnidad, PU.idUnidad AS idTipoUnidad, ORD.idTaller, ORD.idBproProveedor, cs.idUsuario AS idUsuarioSISRE, cs.idDireccion, 
COF.DBProduccion as db, COF.tablaBusqueda as tabla, COF.campoBusqueda as campo
from Ordenes ORD 
left join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion soc on ORD.idOrden = soc.idOrden 
left join RefaccionMultiMarca.Operacion.Cotizacion cs on cs.idCotizacion = soc.idCotizacion
inner join Unidades U on U.idUnidad = ORD.idUnidad
inner join Partidas.dbo.Unidad PU on PU.idUnidad = U.idTipoUnidad
inner join Partidas..ContratoUnidad CU on CU.idUnidad = PU.idUnidad
inner join Partidas.dbo.TipoUnidad TU on TU.idTipoUnidad = PU.idTipoUnidad
inner join ContratoOperacionFacturacion COF on COF.idContratoOperacion = ORD.idContratoOperacion
where ORD.idOrden in ('+@ordenes+') and ORD.idTaller ='+ CONVERT(varchar(10), @idTaller)+'
group by  ORD.idOrden, ORD.fechaCreacionOden, 
ORD.numeroOrden, ORD.idUsuario,  ORD.idEstatusOrden, U.idUnidad,
CU.idContratoUnidad, PU.idUnidad, ORD.idTaller, ORD.idBproProveedor, cs.idUsuario, cs.idDireccion, COF.DBProduccion, COF.tablaBusqueda, COF.campoBusqueda,
SOC.idSiniestro, SOC.idOrden, CS.idCotizacionSisre' 

print @queryOrdenes
PRINT '----------------------------------------------------------'

DECLARE @queryCoti nvarchar (max) = 'select C.idCotizacion, C.idOrden, C.numeroCotizacion, C.ConsecutivoCotizacion as consecutivo,
(SELECT [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](C.idOrden,3,C.ConsecutivoCotizacion)) AS idEstatusCotizacion, C.idTaller, C.idUsuario, 
isCancelada=(CASE C.idEstatusCotizacion
 WHEN 4 THEN '''+'CANCELADA'+'''
 ELSE '''+'' +'''
 END), CS.idSucursal, CS.idProveedor from Cotizaciones C
 left join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion soc on C.idCotizacion = soc.idCotizacionSISCO 
 left join RefaccionMultiMarca.Operacion.Cotizacion cs on cs.idCotizacion = soc.idCotizacion
 where  C.idOrden 
in ('+@ordenes+')  and  C.idTaller = '+CONVERT(varchar(10), @idTaller) + ''

print @queryCoti 
PRINT '----------------------------------------------------------'
DECLARE @queryCotiDet nvarchar (max) = 'select CotDet.idCotizacionDetalle, CotDet.idCotizacion, 
	   CotDet.costo, CotDet.venta, CotDet.cantidad, CotDet.idPartida, Part.partida, Part.noParte, CotDet.rechazadas,
	   CotDet.solicitadasOrg as solicitadas, CotDet.diasEntrega, CotDet.precioLista
	   from CotizacionDetalle CotDet 
	   INNER JOIN Cotizaciones Cot on Cot.idCotizacion = CotDet.idCotizacion
	   INNER JOIN Partidas..Partida Part ON Part.idPartida = CotDet.idPartida
	   where idOrden in (select idOrden from Ordenes where idOrden in ('+@ordenes+') )'
print @queryCotiDet
EXECUTE SP_EXECUTESQL @queryOrdenes
EXECUTE SP_EXECUTESQL @queryCoti
EXECUTE SP_EXECUTESQL @queryCotiDet
END



go

