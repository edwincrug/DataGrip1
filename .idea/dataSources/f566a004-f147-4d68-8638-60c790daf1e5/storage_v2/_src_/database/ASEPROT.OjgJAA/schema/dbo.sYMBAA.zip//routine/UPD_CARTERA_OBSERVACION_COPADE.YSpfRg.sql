-- =============================================
-- Author:		Armando Garcia
-- Create date: 10/04/2019
-- Description:	Se actualizan las observaciones de las copades en diferentes casos
-- [UPD_CARTERA_OBSERVACION_COPADE]
-- =============================================
CREATE PROCEDURE [dbo].[UPD_CARTERA_OBSERVACION_COPADE]
AS
BEGIN

--1er caso Fecha de recepcion de copade = null y  c.CCP_OBSGEN = '' entonces c.CCP_OBSGEN = '*Sin copade*'
INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM cobranza.VwActualizaFPCRA V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS 
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 2073
AND V.fechaRecepcionCopade is null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''

UPDATE C
SET 
C.CCP_OBSGEN = '*Sin copade*',
C.CCP_FECHPROMPAG = ''
FROM cobranza.VwActualizaFPCRA V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 2073
AND V.fechaRecepcionCopade is null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''


INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM cobranza.VwActualizaFPCRACEuropeos V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 263867
AND V.fechaRecepcionCopade is null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''

UPDATE C
SET 
C.CCP_OBSGEN = '*Sin copade*',
C.CCP_FECHPROMPAG = ''
FROM cobranza.VwActualizaFPCRACEuropeos V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 263867
AND V.fechaRecepcionCopade is null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''


INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM [cobranza].[VwActualizaFPTP] V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 84814
AND V.fechaRecepcionCopade is null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''

UPDATE C
SET 
C.CCP_OBSGEN = '*Sin copade*',
C.CCP_FECHPROMPAG = ''
FROM [cobranza].[VwActualizaFPTP] V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 84814
AND V.fechaRecepcionCopade is null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''


/*2 CASO Tenga copade y no tenga leyenda*/

INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM cobranza.VwActualizaFPCRA V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 2073
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''

UPDATE C
SET 
C.CCP_OBSGEN = C.CCP_OBSGEN + '*No. Copade: ' + V.numeroCopade + ' // fecha de recepción de copade: ' + CONVERT(varchar(10), V.fechaRecepcionCopade, 103) + '*',
C.CCP_FECHPROMPAG = ''+CONVERT(varchar(10), DATEADD(DAY, 90, V.fechaRecepcionCopade), 103)
FROM cobranza.VwActualizaFPCRA V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 2073
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''


INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM cobranza.VwActualizaFPCRACEuropeos V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 263867
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''

UPDATE C
SET 
C.CCP_OBSGEN = C.CCP_OBSGEN + '*No. Copade: ' + V.numeroCopade + ' // fecha de recepción de copade: ' + CONVERT(varchar(10), V.fechaRecepcionCopade, 103) + '*',
C.CCP_FECHPROMPAG = ''+CONVERT(varchar(10), DATEADD(DAY, 90, V.fechaRecepcionCopade), 103)
FROM cobranza.VwActualizaFPCRACEuropeos V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 263867
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''


INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM [cobranza].[VwActualizaFPTP] V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 84814
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''

UPDATE C
SET 
C.CCP_OBSGEN = C.CCP_OBSGEN + '*No. Copade: ' + V.numeroCopade + ' // fecha de recepción de copade: ' + CONVERT(varchar(10), V.fechaRecepcionCopade, 103) + '*',
C.CCP_FECHPROMPAG = ''+CONVERT(varchar(10), DATEADD(DAY, 90, V.fechaRecepcionCopade), 103)
FROM [cobranza].[VwActualizaFPTP] V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 84814
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = ''


/*3 CASO Tenga copade y tenga leyenda sin copade*/

INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM cobranza.VwActualizaFPCRA V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 2073
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = '*Sin copade*'

UPDATE C
SET 
C.CCP_OBSGEN = C.CCP_OBSGEN + '*No. Copade: ' + V.numeroCopade + ' // fecha de recepción de copade: ' + CONVERT(varchar(10), V.fechaRecepcionCopade, 103) + '*',
C.CCP_FECHPROMPAG = ''+CONVERT(varchar(10), DATEADD(DAY, 90, V.fechaRecepcionCopade), 103)
FROM cobranza.VwActualizaFPCRA V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 2073
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = '*Sin copade*'


INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM cobranza.VwActualizaFPCRACEuropeos V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 263867
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = '*Sin copade*'

UPDATE C
SET 
C.CCP_OBSGEN = C.CCP_OBSGEN + '*No. Copade: ' + V.numeroCopade + ' // fecha de recepción de copade: ' + CONVERT(varchar(10), V.fechaRecepcionCopade, 103) + '*',
C.CCP_FECHPROMPAG = ''+CONVERT(varchar(10), DATEADD(DAY, 90, V.fechaRecepcionCopade), 103)
FROM cobranza.VwActualizaFPCRACEuropeos V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 263867
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = '*Sin copade*'


INSERT INTO ASEPROT..HistorialCarteraObservacion
SELECT C.CCP_IDDOCTO,C.CCP_IDPERSONA,C.CCP_FECHPROMPAG,C.CCP_OBSGEN,GETDATE()
FROM [cobranza].[VwActualizaFPTP] V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 84814
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = '*Sin copade*'

UPDATE C
SET 
C.CCP_OBSGEN = C.CCP_OBSGEN + '*No. Copade: ' + V.numeroCopade + ' // fecha de recepción de copade: ' + CONVERT(varchar(10), V.fechaRecepcionCopade, 103) + '*',
C.CCP_FECHPROMPAG = ''+CONVERT(varchar(10), DATEADD(DAY, 90, V.fechaRecepcionCopade), 103)
FROM [cobranza].[VwActualizaFPTP] V
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].CON_CAR012019 C 
ON V.CCP_IDDOCTO = C.CCP_IDDOCTO COLLATE Modern_Spanish_CI_AS
WHERE C.CCP_TIPODOCTO = 'FAC' AND V.MODULO = 'CXP' AND C.CCP_IDPERSONA = 84814
AND V.fechaRecepcionCopade is not null and CCP_CARTERA = 'AE57' and  c.CCP_OBSGEN = '*Sin copade*'
END
go

