CREATE FUNCTION [dbo].[fnFactorIVA_Cotizacion](@idCotizacion INT,@aux int)

RETURNS DECIMAL(18,2)
AS
BEGIN

DECLARE @factorIVA DECIMAL(18,2) = 0.16

SELECT TOP(1)
@factorIVA=FC.tasaIVA
FROM Cotizaciones C
INNER JOIN FacturaCotizacion FC ON FC.idCotizacion = C.idCotizacion
where C.idCotizacion=@idCotizacion

IF @factorIVA IS NULL OR @factorIVA = 0
BEGIN
SET @factorIVA = 0.16
END

RETURN @factorIVA
END
go

