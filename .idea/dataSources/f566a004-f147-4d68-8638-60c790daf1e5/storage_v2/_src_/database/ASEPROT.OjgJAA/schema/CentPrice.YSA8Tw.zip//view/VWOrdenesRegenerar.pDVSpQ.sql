

CREATE VIEW [CentPrice].[VWOrdenesRegenerar]
AS
select distinct O.idOrden, O.numeroOrden, U.numeroEconomico, EO.nombreEstatusOrden, O.idEstatusOrden
from [CentPrice].[PartidasActualizar] PA
inner join Partidas..Partida P on P.partida = PA.numeroPartida
inner join CotizacionDetalle CD on CD.idPartida = P.idPartida
inner join Cotizaciones C on C.idCotizacion = CD.idCotizacion
inner join Ordenes O on O.idOrden = C.idOrden 
inner join Unidades U on U.idUnidad = O.idUnidad
inner join EstatusOrdenes EO on EO.idEstatusOrden = O.idEstatusOrden
where [Comparacion F vs H] = 0
and O.idEstatusOrden in (6,7,8,9,10)
--and O.idEstatusOrden in (6)
--order by O.idEstatusOrden, EO.nombreEstatusOrden, O.idOrden, O.numeroOrden, U.numeroEconomico asc

go

grant select, view definition on CentPrice.VWOrdenesRegenerar to DevOps
go

