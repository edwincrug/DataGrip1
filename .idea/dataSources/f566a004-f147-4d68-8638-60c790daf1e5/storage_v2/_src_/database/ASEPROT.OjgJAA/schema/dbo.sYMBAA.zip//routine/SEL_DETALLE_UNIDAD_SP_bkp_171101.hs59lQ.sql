-- =============================================  
-- Description: Busca el detalle de la uniad   
-- NOTA: Falta verificar el usuario, su rol y el tipo de operación   
-- =============================================  
-- [dbo].[SEL_DETALLE_UNIDAD_SP] @idUsuario = 107, @economico = '1810103' , @idContratoOperacion = 1  
-- [dbo].[SEL_DETALLE_UNIDAD_SP] @idUsuario = 2, @economico = '9748742468'  
-- [dbo].[SEL_DETALLE_UNIDAD_SP] @idUsuario = 2, @economico = '8'  
-- [dbo].[SEL_DETALLE_UNIDAD_SP] 107, '10156', 1
Create PROCEDURE [dbo].[SEL_DETALLE_UNIDAD_SP_bkp_171101]   
 @idUsuario INT = 0,  
 @economico VARCHAR(50) = '' ,
 @idOperacion NUMERIC(18,0) = 1
AS  
BEGIN  
 -------------------------------------------------------------------------------------------------------------------------  
 --Busqueda de unidad respuesta = 1 <-- Respuesta Correcta  
 --      respuesta = 0 <-- No se encontraron registros  
 --      respuesta = 2 <-- El usuario no tiene los permisos necesarios  
 --                   respuesta = 3 <-- La unidad tiene una orden de servicio en proceso   
 --Cuando situacionOrden = 0 <--No tiene ordenes de servicio en proceso   
 --   situacionOrden = 1 <--Tiene ordenes de servicio en proceso   
 -------------------------------------------------------------------------------------------------------------------------  
 IF(EXISTS(SELECT [numeroEconomico] FROM [dbo].[Unidades] WHERE [numeroEconomico] = @economico))  
  BEGIN  
   IF(EXISTS(SELECT *  
      FROM [dbo].[Unidades] UNI  
        INNER JOIN [dbo].[ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion  
        INNER JOIN [dbo].[ContratoOperacionUsuario] COU ON CP.idContratoOperacion = COU.idContratoOperacion AND COU.idUsuario = @idUsuario  
        WHERE numeroEconomico = @economico))  
    BEGIN  
     DECLARE @situacionOrden INT=0, @numeroOrdensesServicios INT=0, @costo NUMERIC (18,2) = 0, @venta NUMERIC (18,2) = 0, @enProceso NUMERIC (18,2) = 0, @finalizado NUMERIC(18,2)  
       ,@pendienteCertificado NUMERIC (18,2) = 0,@porCobrar NUMERIC (18,2) = 0, @idUnidad INT   
     SET @numeroOrdensesServicios = ISNULL((  
                SELECT COUNT (*)  
                FROM [dbo].[Unidades] U  
                  INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad  
                WHERE numeroEconomico = @economico AND NOT idEstatusOrden = 10 AND idEstatusOrden > 2  
               ),0)  
     SET @situacionOrden = (CASE WHEN EXISTS(SELECT *  
                 FROM [dbo].[Unidades] AS U  
                   INNER JOIN [dbo].[Ordenes] AS O ON U.idUnidad = O.idUnidad  
                WHERE numeroEconomico = @economico AND idEstatusOrden < 8)  
            THEN 1  
            ELSE 0 END)  
       /* SELECT @costo = case when O.idEstatusOrden = 13 then 0 else SUM(CD.costo * CD.cantidad * 1.16) end  
       ,@venta =  case when O.idEstatusOrden = 13 then 0 else SUM(CD.venta * CD.cantidad * 1.16) end  
     FROM [dbo].[Unidades] U  
       INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
       INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
       INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
     WHERE numeroEconomico = @economico AND NOT idEstatusOrden = 10 AND idEstatusOrden > 4   
     group by O.idEstatusOrden */  
  
     SELECT   
      @costo = ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0),  
      @venta = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
     FROM [dbo].[Unidades] U  
      INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
      INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
      INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
     WHERE U.numeroEconomico = @economico AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
     AND O.idEstatusOrden NOT IN(13) AND O.idEstatusOrden > 4   
  
     SELECT @enProceso = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
     FROM [dbo].[Unidades] U  
       INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
       INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
       INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
     WHERE numeroEconomico = @economico AND idEstatusOrden = 5  
       AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
  
     SELECT @pendienteCertificado = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
     FROM [dbo].[Unidades] U  
       INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
       INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
       INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
     WHERE numeroEconomico = @economico AND idEstatusOrden in(6,7)  
       AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
  
     SELECT @porCobrar = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
     FROM [dbo].[Unidades] U  
       INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
       INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
       INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
     WHERE numeroEconomico = @economico AND idEstatusOrden in(8)  
       AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
  
     SELECT @finalizado = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
     FROM [dbo].[Unidades] U  
       INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
       INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
       INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
     WHERE numeroEconomico = @economico AND idEstatusOrden in(9)  
       AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
  
     SELECT @idUnidad = idUnidad FROM [dbo].[Unidades] WHERE numeroEconomico = @economico  
     DECLARE @ultimoServicio NVARCHAR(50), @ultimaModificacion NVARCHAR(50), @usuarioModifico NVARCHAR(200)  
     SET @ultimoServicio = CONVERT(VARCHAR(10),( SELECT TOP 1 fechaInicial   
           FROM [dbo].[Ordenes] O  
             INNER JOIN [dbo].[HistorialEstatusOrden] HEO ON HEO.idOrden = O.idOrden  
           WHERE  idUnidad = @idUnidad  
           ORDER BY fechaInicial DESC),103)  
     SELECT @ultimaModificacion = CONVERT(VARCHAR(10),fechaInicial,103)  
       ,@usuarioModifico = nombreCompleto  
     FROM [dbo].[Ordenes] O  
       INNER JOIN [dbo].[HistorialEstatusOrden] HEO ON HEO.idOrden = O.idOrden  
       INNER JOIN [dbo].[Usuarios] USU ON USU.idUsuario = HEO.idUsuario  
     WHERE idUnidad = @idUnidad AND fechaFinal IS NULL AND NOT HEO.idEstatusOrden in (9,10)  
     --PRINT @situacionOrden   
     ------Obtengo la ip del servidor donde se encuntra la BD Partidas  
  
     DECLARE @query NVARCHAR(MAX)  
       
     -----------------------------------------------------------------   
       
     SET @query = 'SELECT  UNI.[idUnidad] AS idUnidad' + char(13) +   
         '  ,[numeroEconomico] AS numeroEconomico' + char(13) +   
         '  ,[vin] AS vin' + char(13) +   
         '      ,ISNULL(UNI.placas,'''') as placas' + char(13) +  
         '  ,MA.[nombre] AS marca' + char(13) +   
         '  ,SM.[nombre] AS subMarca' + char(13) +            
         '  ,(select nombre from [Partidas].dbo.Zona where idZona = UNI.idZona) zona' + char(13) +   
         --'  ,UNIP.[anio] AS modelo' + char(13) +   
         '  ,UNI.combustible AS version' + char(13) +            
         '  ,UNI.[modelo] AS modelo' + char(13) +   
         '  ,[gps] AS gps' + char(13) +   
         '  ,[sustituto] AS sustituto' + char(13) +   
         '  ,UNI.[idOperacion] AS idOperacion' + char(13) +   
         '  ,[idCentroTrabajo] AS idCentroTrabajo' + char(13) +   
         '  ,'+CONVERT(varchar(100), ISNULL(@numeroOrdensesServicios,0))+' AS numeroOrdenesSerevicio' + char(13) +   
         '  , 1 AS respuesta' + char(13) +   
         '  , '+CONVERT(varchar(100), ISNULL(@situacionOrden,0))+' AS situacionOrden' + char(13) +   
         '  , '+CONVERT(varchar(100), ISNULL(@costo,0))+' AS costoTotal' + char(13) +   
         '  , '+CONVERT(varchar(100), ISNULL(@venta,0))+' AS precioTotal' + char(13) +   
         '  , '+CONVERT(varchar(100), ISNULL(@enProceso,0))+' AS enProceso' + char(13) +   
         '  , '+CONVERT(varchar(100), ISNULL(@pendienteCertificado,0))+' AS pendienteCertificado' + char(13) +   
         '  , '+CONVERT(varchar(100), ISNULL(@porCobrar,0))+' AS porCobrar' + char(13) +   
         '  , '+CONVERT(varchar(100), ISNULL(@finalizado,0))+' AS finalizado' + char(13) +   
         '  , '''+ ISNULL(@ultimoServicio,'')+''' AS ultimoServicio' + char(13) +  
         '  , '''+ ISNULL(@ultimaModificacion,'')+''' AS ultimaModificacion' + char(13) +  
         '  , '''+ ISNULL(@usuarioModifico,'')+''' AS usuarioModifico' + char(13) +  
         '  ,UNIP.idUnidad AS idTipoUnidad' + char(13) +  
         '  ,TU.tipo AS nombreTipoUnidad' + char(13) +  
         '  ,UNIP.foto as foto' + char(13) +  
         '      ,cil.cilindros' + char(13) +  
         '  ,UNI.verificada' + char(13) +  
		 --'  ,19.4428321  as [Latitud]' + char(13) +  
		 --'  ,-99.1933742  as [Longitud]' + char(13) + 
		 '  ,0  as [Latitud]' + char(13) +  
		 '  ,0  as [Longitud]' + char(13) +  
         --'  ,UNIP.version AS version' + char(13) +  
         ' FROM [dbo].[Unidades]  UNI' + char(13) +   
         '  INNER JOIN [dbo].[ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion' + char(13) +   
         '  INNER JOIN .[Partidas].[dbo].[ContratoUnidad] CU ON CU.idContrato = CP.idContrato AND CU.idUnidad = UNI.idTipoUnidad' + char(13) +   
         '  INNER JOIN .[Partidas].[dbo].[Unidad] UNIP ON UNIP.idUnidad = CU.idUnidad' + char(13) +   
         '  INNER JOIN .[Partidas].dbo.SubMarca SM ON UNIP.idSubMarca = SM.idSubMarca' + char(13) +   
         '  INNER JOIN .[Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca' + char(13) +   
         '      LEFT JOIN  .[Partidas].dbo.Cilindros cil ON cil.idCilindros = UNIP.idCilindros' + char(13) +   
         '  INNER JOIN .[Partidas].[dbo].[TipoUnidad] TU ON TU.idTipoUnidad = UNIP.idTipoUnidad' + char(13) +   
         'WHERE [numeroEconomico] = '''+CONVERT(varchar(100), @economico)+'''' + char(13) +   
		 'AND CP.idOperacion = '+CONVERT(varchar(100), @idOperacion)+''  + char(13) +   
         ''        
      print @query  
      EXECUTE (@query)    
       
    END   
   ELSE  
    BEGIN  
     SELECT 2 AS respuesta,  
     'El usuario no tiene los permisos necesarios' AS mensaje  
    END    
  END  
 ELSE  
  BEGIN  
   SELECT 0 AS respuesta,  
     'No se encontraron registros' AS mensaje  
  END  
     
   
END


go

