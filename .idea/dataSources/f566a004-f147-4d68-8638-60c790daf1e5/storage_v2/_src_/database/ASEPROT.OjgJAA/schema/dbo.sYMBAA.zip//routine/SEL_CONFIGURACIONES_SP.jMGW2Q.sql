-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 18/05/2017
-- Description:	Obtiene todas las operaciones existentes
-- SEL_CONFIGURACIONES_SP 
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_CONFIGURACIONES_SP]

AS
BEGIN
  
	DECLARE @idOperacion INT
	
	DECLARE @queryText varchar(max) = 
	'' + char(13) + 
	'' + char(13) + 
	'	SELECT CL.razonSocial,' + char(13) +  
	'		CON.fechaInicio, ' + char(13) + 
	'		CON.fechaFin, ' + char(13) + 
	'		OPER.idOperacion,' + char(13) + 
	'	    CON.descripcion,' + char(13) + 
	'		OPER.geolocalizacion,' + char(13) + 
	'		OPER.idEstatusOperacion' + char(13) + 
	'	FROM operaciones OPER' + char(13) + 
	'		LEFT  JOIN ContratoOperacion CP ON CP.idOperacion = OPER.idOperacion' + char(13) + 
	'		LEFT  JOIN .[Partidas].[dbo].[Contrato] CON ON CP.idContrato = CON.idContrato' + char(13) + 
	'		LEFT  JOIN .[Partidas].[dbo].[Licitacion] LIC ON LIC.idLicitacion = CON.idLicitacion' + char(13) + 
	'		LEFT  JOIN .[Partidas].[dbo].[Cliente] CL ON LIC.idCliente = CL.idCliente' + char(13) + 
	'  ' + char(13) + 
	'' + char(13) + 
	'' + char(13) + 
	'' + char(13) + 
	'' 
		exec(@queryText) 
		---select @queryText
  
  
END


go

