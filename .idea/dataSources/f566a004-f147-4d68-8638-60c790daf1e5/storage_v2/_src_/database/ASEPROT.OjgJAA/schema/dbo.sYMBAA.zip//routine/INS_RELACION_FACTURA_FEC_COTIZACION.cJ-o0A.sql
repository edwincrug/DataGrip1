
-- ==========================================================================================
-- Author:		Jordan Gómez Domínguez
-- Create date: 26/09/2018
-- Description:	Vincula factura fec a ordenes de sisco

--[INS_RELACION_FACTURA_FEC_COTIZACION] '47918,',25322,3
-- ==========================================================================================
CREATE PROC [dbo].[INS_RELACION_FACTURA_FEC_COTIZACION]
	@IdCotizacion NVARCHAR(500),
	@IdDatosFacturaFec NUMERIC(18,0)
AS
BEGIN
	
	DECLARE @Posicion NUMERIC(18,0)
	DECLARE @Trabajo NUMERIC(18,0)

WHILE patindex('%,%' , @idCotizacion) <> 0
BEGIN
  SELECT @Posicion =  patindex('%,%' , @IdCotizacion)
  SELECT @Trabajo = left(@IdCotizacion, @Posicion - 1)
  SET @Trabajo = CONVERT (numeric(18,0),@Trabajo)

			IF NOT EXISTS (SELECT 1 FROM DatosFacturaFecCotizacion WHERE IdDatosFacturaFec=@IdDatosFacturaFec AND IdCotizacion = @Trabajo)
				BEGIN 
					INSERT INTO DatosFacturaFecCotizacion 
					VALUES(@IdDatosFacturaFec, @Trabajo, GETDATE())
				END

		SELECT @idCotizacion = stuff(@idCotizacion, 1, @Posicion, '')
	END
	
	SELECT '1' as id
	
END
go

