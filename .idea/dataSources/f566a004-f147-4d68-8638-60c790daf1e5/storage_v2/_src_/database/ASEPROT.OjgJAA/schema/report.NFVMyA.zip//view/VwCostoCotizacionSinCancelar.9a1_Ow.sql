







CREATE VIEW [report].[VwCostoCotizacionSinCancelar]
AS

    SELECT 
	O.idOrden, 
	C.idCotizacion,
	ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) costo
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			--INNER JOIN [Partidas].[dbo].[Partida] P	ON CD.idPartida = P.idPartida
			INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
			INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		WHERE 
		CD.idEstatusPartida NOT IN(3,4) 
		AND C.idEstatusCotizacion NOT IN(4,5)	
		group by O.idOrden, C.idCotizacion
go

