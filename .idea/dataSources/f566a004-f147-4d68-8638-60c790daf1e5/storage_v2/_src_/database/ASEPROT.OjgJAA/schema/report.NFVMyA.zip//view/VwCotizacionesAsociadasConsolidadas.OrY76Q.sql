




CREATE VIEW [report].[VwCotizacionesAsociadasConsolidadas]
AS

    SELECT DISTINCT DFCC.IDCOTIZACION, numeroCotizacion FROM DatosFacturaConcentra DFC 
	INNER JOIN DatosFacturaConcentraCotizacion DFCC ON DFCC.IdDatosFacturaConcentra = DFC.IdDatosFacturaConcentra
	INNER JOIN COTIZACIONES C ON C.IDCOTIZACION = DFCC.IDCOTIZACION
	WHERE DFC.IdCatalogoFacturaConcentra = 2
go

