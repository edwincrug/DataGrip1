/*
	Objetivo:	Guardar la relacion entre los usuarios de sisco con los de seguridad

	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	10/08/2018		LUDM	Creación del SP

*/
CREATE PROCEDURE [Operacion].[Ins_Rel_Users]
	@User_Id int,		-- usuario de sisco 
	@User_Seg_Id int	-- Usuario de seguridad
AS
BEGIN
	DECLARE @msj varchar(50) = 'Carga exitosa.',
			@idUsuarioRel int = 0;

	IF EXISTS(SELECT * FROM [Relacion].Usuarios_Seguridad WHERE [User_Id] = @User_Id )
	BEGIN
		SET @idUsuarioRel = (SELECT User_Seg_Id FROM [Relacion].Usuarios_Seguridad WHERE [User_Id] = @User_Id );
		SET @msj = 'Usuario de SISCO ya asignado al ID_SEGURIDAD: ' + CAST(@idUsuarioRel AS VARCHAR(10) );
	END
	ELSE
	BEGIN
		IF EXISTS(SELECT * FROM [Relacion].Usuarios_Seguridad WHERE [User_Seg_Id] = @User_Seg_Id )
		BEGIN
			SET @idUsuarioRel = (SELECT [User_Id] FROM [Relacion].Usuarios_Seguridad WHERE [User_Seg_Id] = @User_Seg_Id );
			SET @msj = 'Usuario de Seguridad ya asignado al ID_SISCO: ' + CAST(@idUsuarioRel AS VARCHAR(10) );
		END
		ELSE
		BEGIN
			INSERT INTO [Relacion].[Usuarios_Seguridad]([User_Id], [User_Seg_Id])
				VALUES(@User_Id, @User_Seg_Id);
		END
	END;

	SELECT @msj AS msj, @idUsuarioRel AS idUsuarioRel;
END
go

grant execute, view definition on Operacion.Ins_Rel_Users to DevOps
go

