
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_USUARIOMEETINGCREDENCIALES_BY_USUARIO_SP]
	@idUsuario	numeric(18,0)
AS
BEGIN


SELECT [idUsuarioMeeting]
      ,[idUsuario]
      ,[emailMeeting]
      ,[passMeeting]
      ,[accessToken]
      ,[organizerKey]
  FROM [dbo].[UsuariosMeetingCredenciales]
  where idUsuario = @idUsuario


END
go

