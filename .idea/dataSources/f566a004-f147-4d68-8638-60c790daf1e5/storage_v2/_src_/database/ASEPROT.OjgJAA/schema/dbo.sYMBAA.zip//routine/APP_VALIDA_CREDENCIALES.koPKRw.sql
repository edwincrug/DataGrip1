
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 10/05/2017
-- Description:	Validación de credenciales de usuario para la APP Token
-- ==========================================================================================

CREATE PROCEDURE [dbo].[APP_VALIDA_CREDENCIALES]
    @usuario NVARCHAR(250),
	@contrasena NVARCHAR(50)
AS   
BEGIN
	SELECT
		Usu.idUsuario,
		Usu.nombreUsuario,
		CaRo.idCatalogoRol,
		CaRo.nombreCatalogoRol,
		Ope.idOperacion,
		--Ope.nombreOperacion,
		CaRo.nombreCatalogoRol
	FROM [ContratoOperacionUsuario]		CoOpUs
	INNER JOIN [CatalogoRoles]			CaRo	ON CaRo.idCatalogoRol = CoOpUs.idCatalogoRol
	INNER JOIN [Usuarios]				Usu		ON Usu.idUsuario = CoOpUs.idUsuario
	INNER JOIN [ContratoOperacion]		ContOpe ON ContOpe.idContratoOperacion = CoOpUs.idContratoOperacion
	INNER JOIN [Operaciones]			Ope		ON Ope.idOperacion = ContOpe.idOperacion
	WHERE 
		nombreUsuario = @usuario AND
		contrasenia = @contrasena AND
		CaRo.idCatalogoRol IN (1,2)
END
go

