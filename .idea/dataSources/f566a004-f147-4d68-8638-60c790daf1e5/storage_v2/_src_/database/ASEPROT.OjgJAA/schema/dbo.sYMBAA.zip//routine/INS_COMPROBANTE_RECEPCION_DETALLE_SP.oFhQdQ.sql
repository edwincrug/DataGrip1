
CREATE PROCEDURE [dbo].[INS_COMPROBANTE_RECEPCION_DETALLE_SP]
@accion INT,
@idCatalogoDetalleModuloComprobante INT,
@idModuloComprobante INT,
@descripcion VARCHAR(MAX),
@vin varchar(50),
@kilometraje int,
@Evento int 
AS
BEGIN
		DECLARE @idDetalleModuloComprobante INT
		INSERT INTO DetalleModuloComprobante VALUES(@accion, @idCatalogoDetalleModuloComprobante, @idModuloComprobante, @descripcion)
		--UPDATE unidades set Kilometraje_Actual= @kilometraje, Ultimo_Servicio = @Evento where vin= @vin
		SET @idDetalleModuloComprobante = @@IDENTITY
		SELECT @idDetalleModuloComprobante AS idDetalleModuloComprobante, 'Se agrego el detalle del modulo'AS msg,1 AS estatus
END
go

