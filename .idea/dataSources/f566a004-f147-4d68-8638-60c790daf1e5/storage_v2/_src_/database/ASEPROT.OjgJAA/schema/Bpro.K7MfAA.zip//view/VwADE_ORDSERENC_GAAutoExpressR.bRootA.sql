



-- SELECT * FROM [BPro].[VwADE_ORDSERENC_GAAutoExpressR]
-- RECORDS 21317      TIME 1 Second
CREATE VIEW [Bpro].[VwADE_ORDSERENC_GAAutoExpressR]

AS

SELECT --[OTE_IDENT]
      --,[OTE_ORDENPEMEX]
      --,[OTE_ORDENANDRADE]
	     CAST([OTE_ORDENANDRADE] as varchar(100)) COLLATE Modern_Spanish_CI_AS AS [OTE_ORDENANDRADE]
      --,[OTE_REFERENCIA]
      ,[OTE_IDPROVEEDOR]
      --,[OTE_FECHAORDEN]
      --,[OTE_FACTURACOMPRA]
      --,[OTE_TASAIVA]
      --,[OTE_SUBTOTAL]
      ,[OTE_IVA]
      ,[OTE_TOTAL]
      --,[OTE_UUID]
      --,[OTE_XMLCOMPRA]
      --,[OTE_FECHOPE]
      --,[OTE_HORAOPE]
      --,[OTE_STATUS]
      --,[OTE_FECHAPROCESO]
      --,[OTE_HORAPROCESO]
      --,[OTE_ORDENGLOBAL]
      --,[OTE_PDFCOMPRA]
      --,[OTE_RUTAXML]
      --,[OTE_RUTAPDF]
      --,[OTE_IDCLIENTE]
      --,[OTE_DESGLOSE]

  FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC]
go

grant select, view definition on Bpro.VwADE_ORDSERENC_GAAutoExpressR to DevOps
go

