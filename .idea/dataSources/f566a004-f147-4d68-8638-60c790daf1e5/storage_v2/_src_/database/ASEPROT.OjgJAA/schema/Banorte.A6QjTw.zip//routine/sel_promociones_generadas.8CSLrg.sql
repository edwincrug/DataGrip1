-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 01/08/2018
-- Description:	Retorna el detalle y codigo de promocion para mis promociones en la aplicacion movil
-- exec [Banorte].[sel_promociones_generadas] 783, 3
-- =============================================
CREATE PROCEDURE [Banorte].[sel_promociones_generadas] 
(
	@idUsuario			INT,
	@idPromocion		int
)
AS
BEGIN

	SELECT 
		Codigo codigo
		,(isnull(p.MaximoUso,0) - isnull(pc.Aplicadas,0)) oportunidades
		,p.urlImagen imagen
		,p.fechaTermino	vigencia
	FROM PromocionesCodigos pc
		inner join Banorte.Promociones p on p.id = pc.IdPromocion
	where pc.IdPromocion = @idPromocion
		and pc.idUsuario = @idUsuario
	
END

go

grant execute, view definition on Banorte.sel_promociones_generadas to DevOps
go

