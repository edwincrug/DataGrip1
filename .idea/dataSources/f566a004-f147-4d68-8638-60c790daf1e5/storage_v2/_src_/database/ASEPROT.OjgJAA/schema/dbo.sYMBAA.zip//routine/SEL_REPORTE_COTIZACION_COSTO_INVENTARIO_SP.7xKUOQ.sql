
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [dbo].[SEL_REPORTE_COTIZACION_COSTO_INVENTARIO_SP] 57
CREATE PROCEDURE [dbo].[SEL_REPORTE_COTIZACION_COSTO_INVENTARIO_SP]
	@idContratoOperacion NUMERIC(18,0)
AS
BEGIN
	SELECT 
		O.idOrden,
		Z.idZona,
		C.idCotizacion,
		A_O.ote_ident,
		O.consecutivoOrden,
		A_O.OTE_FACTURACOMPRA folioFactura,
		O.numeroOrden,
		C.numeroCotizacion,
		U.numeroEconomico,
		Z.nombre AS nombreZona,
		O.fechaCreacionOden,
		A_O.OTE_TASAIVA tasaIva,
		(select [dbo].[SEL_PRECIO_COSTO_COT_FN](C.idCotizacion,O.idContratoOperacion,3,538,2) )as costo,
		(SELECT [dbo].[SEL_PRECIO_VENTA_COT_FN](C.idCotizacion, O.idContratoOperacion, 3,538, 2)) AS venta,
		CASE 
		WHEN A_O.OTE_GENERA = '' THEN '0'
		WHEN A_O.OTE_GENERA is null THEN '0'
		WHEN A_O.OTE_GENERA = 'S' THEN '1'
		WHEN A_O.OTE_GENERA = 'G' THEN '2'
		END Estatus
	FROM ParametrosGeneralOrden PGO
	INNER JOIN Ordenes O ON O.idOrden = PGO.idOrden
	INNER JOIN Cotizaciones C ON C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
	INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] A_O ON C.numeroCotizacion collate SQL_Latin1_General_CP1_CI_AS = A_O.OTE_ORDENPEMEX 
	INNER JOIN Unidades U ON U.idUnidad = O.idUnidad
	INNER JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
	JOIN Partidas..Zona Z ON Z.idZona = O.idZona
	WHERE PGO.IdParametroGeneral = 12 AND O.idContratoOperacion = @idContratoOperacion
	order by O.numeroOrden
END
go

