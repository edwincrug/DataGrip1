


-- [SEL_CUENTAS_CXC_SP] 1, 1
-- [SEL_CUENTAS_CXC_SP] 3, 1
-- 2017 10 October 16
-- Luis Alvarez del Castillo Bermudez
-- Actualizar el estatus en Bpro desde Toluca
-- select * from FacturaCotizacion
CREATE PROC [dbo].[UDP_CUENTAS_X_COBRAR_GATPartsToluca_SP]


AS
BEGIN
	
	---Respaldo de la ADE_COPADE
	-- DROP TABLE [dbo].ADE_COPADE_BKP
	--SELECT *
	--INTO [dbo].ADE_COPADE_BKP
	--FROM [192.168.20.29].[GATPartsToluca].[dbo].ADE_COPADE


	--- Step 00 Variables de Inicio
    declare @FecIni datetime = getdate()


	--- STEP 01
	--- Logger Data to Update

	
	INSERT INTO [Bpro].[FacturasActulizarSP]
			   ([COP_STATUS]
			   ,[NewStatus]
			   ,[COP_CARGO]
			   ,[ImporteUpdate]
			   ,[COP_SAlDO]
			   ,[SaldoUpdate]
			   ,[COP_FECHULTPAG]
			   ,[FechaVenUpdate]
			   ,[CCP_IDDOCTO]
			   ,[COP_IDDOCTO]
			   ,[ReqUpdate]
			   ,[StoredName]
			   ,[DateExecution])
    


		SELECT   D.[COP_STATUS]     , O.[NewStatus],
			 D.[COP_CARGO]      , O.[Importe] as [ImporteUpdate],
			 D.[COP_SAlDO]      , O.[Saldo] as [SaldoUpdate],
			 D.[COP_FECHULTPAG] , O.[CCP_FECHVEN] as [FechaVenUpdate],
			 O.[CCP_IDDOCTO]    , D.COP_IDDOCTO,
			 O.[ReqUpdate] ,
			 'UDP_CUENTAS_X_COBRAR_GATPartsToluca_SP' as [StoredName],
			 getdate() as [DateExecution]

			 --select * from [BPRO].[FacturasActulizarSP]
			 --INTO [BPRO].[FacturasActulizarSP]
			 --truncate table [BPRO].[FacturasActulizarSP]

		 
			FROM [192.168.20.29].[GATPartsToluca].[dbo].ADE_COPADE D
	  INNER JOIN [Bpro].[VwActualizarStatusTolucaDefA] O
			  ON O.[CCP_IDDOCTO] = D.COP_IDDOCTO
		   WHERE O.[ReqUpdate] =1



    --Step 02
	-- Update Status, Cop_Cargo, Cop_saldo, Fecha Ult Pag

	UPDATE D
     SET D.[COP_STATUS]     = O.[NewStatus],
         D.[COP_CARGO]      = O.[IMporte],
	     D.[COP_SAlDO]      = O.[Saldo],
         D.[COP_FECHULTPAG] = O.[CCP_FECHVEN]
        FROM [192.168.20.29].[GATPartsToluca].[dbo].ADE_COPADE D
  INNER JOIN [ASEPROT].[Bpro].[VwActualizarStatusTolucaDefA] O
          ON O.[CCP_IDDOCTO] = D.COP_IDDOCTO
       WHERE O.[ReqUpdate] = 1


	     -- Step 03  Variables de Fin de Execution
       --declare @FecIni datetime = getdate()
       declare @NumUpdate int = @@ROWCOUNT
       declare @FecFin datetime = getdate()


-- Step 04  Log Execution
INSERT INTO [Bpro].[ProcessExecution]
           ([Process Init]
           ,[Number Rows Update]
           ,[Process Finish]
           ,[Process Duration]
		   ,[Process Name])

   Select @FecIni as [Process Init],
          @NumUpdate as [Number Rows Update],
		  @FecFin as [Process Finish],
		  datediff(ss,@FecIni,@FecFin) as [Process Duration],
		  'UDP_CUENTAS_X_COBRAR_GATPartsToluca_SP' as [ProcessName]



---- VALIDATIONS


--SELECT   D.[COP_STATUS]     , O.[NewStatus],
--         D.[COP_CARGO]      , O.[Importe] as [ImporteUpdate],
--	     D.[COP_SAlDO]      , O.[Saldo] as [SaldoUpdate],
--         D.[COP_FECHULTPAG] , O.[CCP_FECHVEN] as [FechaVenUpdate],
--		 O.[CCP_IDDOCTO]    , D.COP_IDDOCTO,
--		 O.[ReqUpdate] ,
--		 'UDP_CUENTAS_X_COBRAR_GATPartsToluca_SP' as [StoredName],
--		 getdate() as [DateExecution]


--		 --INTO [BPRO].[FacturasActulizarSP]
		 
--        FROM [192.168.20.29].[GATPartsToluca].[dbo].ADE_COPADE D
--  INNER JOIN [Bpro].[VwActualizarStatusTolucaDefA] O
--          ON O.[CCP_IDDOCTO] = D.COP_IDDOCTO
--       WHERE O.[ReqUpdate] = 1

--	   SElect *
--	   from [Bpro].[VwActualizarStatusTolucaDefA]

--	   Select *
--	   from [Bpro].[VwActualizarStatusTolucaDef]

--	   Select *
--	   from [Bpro].[VwActualizarStatusTolucaBase]
--  Select 1   --Remove 

END
go

