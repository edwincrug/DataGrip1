-- [dbo].[SEL_EXISTE_UNIDAD_SP] 2128, 'PMX11514', 58, 1
CREATE PROCEDURE [dbo].[SEL_EXISTE_UNIDAD_SP]
	@idUsuario INT = 0,
	@economico nvarchar(max) = '',
	@idOperacion int,
	@tipo int = 1
AS
BEGIN
	-------------------------------------------------------------------------------------------------------------------------
	-- Busca si la unidad existe y si el usuario cumple con los permisos necesarios
	--		 respuesta = 0 <-- No existe la unidad 
	--		 respuesta = 1 <-- Existe la unidad y tiene todos los permisos necesarios 
	--		 respuesta = 2 <-- Existe la unidad pero el tipo de operación no le corresponde
	--		 respuesta = 3 <-- Existe la unidad pero el rol no tiene permisos para visualizar la información
	-------------------------------------------------------------------------------------------------------------------------
	DECLARE @economicoTemp nvarchar(max)= '',
			@idUnidad INT = 0;
	IF(@tipo = 2)
	BEGIN
		SET @economicoTemp = (SELECT numeroEconomico FROM [dbo].[Unidades] WHERE vin = @economico and idOperacion = @idOperacion)
		SET @idUnidad = (SELECT idUnidad FROM [dbo].[Unidades] WHERE vin = @economico and idOperacion = @idOperacion)
	END
    ELSE IF (@tipo = 3)
    BEGIN
        SET @economicoTemp = (SELECT numeroEconomico FROM [dbo].[Unidades] WHERE placas = @economico and idOperacion = @idOperacion)
		SET @idUnidad = (SELECT idUnidad FROM [dbo].[Unidades] WHERE placas = @economico and idOperacion = @idOperacion)
    END
	ELSE
	BEGIN
		SET @economicoTemp = @economico;
		SET @idUnidad = (SELECT idUnidad FROM [dbo].[Unidades] WHERE numeroEconomico = @economico and idOperacion = @idOperacion)
	END

    DECLARE @filtroZona INT = 1, @tipoUsuario INT = 1, @ageupador INT = 0;
	
	IF(EXISTS(SELECT 1 FROM [dbo].[Unidades] WHERE idUnidad = @idUnidad))
	BEGIN
		SET @tipoUsuario = (SELECT idCatalogoTipoUsuarios FROM Usuarios WHERE idUsuario = @idUsuario);
        IF (EXISTS(SELECT 1 FROM [dbo].UsuarioAgrupador where idUsuario = @idUsuario) OR @tipoUsuario = 10)
        BEGIN
			IF	(	EXISTS( SELECT 1 FROM UnidadAgrupador UNI
								INNER JOIN UsuarioAgrupador US ON US.idAgrupador = UNI.idAgrupador
								WHERE US.idUsuario = @idUsuario  AND UNI.idUnidad = @idUnidad))
            BEGIN
                SELECT 1 AS respuesta
                    ,'Unidad encontrada con éxito' AS mensaje, @economicoTemp as economico
            END
			ELSE
            BEGIN
			print 'otro4'
                SELECT 2 AS respuesta , 
					'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico ' + @economicoTemp AS mensaje, @economicoTemp as economico
            END	
        END ELSE BEGIN
            IF (@tipoUsuario = 2)
            BEGIN
                SET @filtroZona = 0;
            END
            ELSE
            BEGIN
                SET @filtroZona = 1;
            END
            

			IF(@filtroZona = 1)
			BEGIN
				IF( @tipoUsuario = 4 ) BEGIN --Proveedor
					
					--IF EXISTS (SELECT  1 
					--				FROM ASEPROT.dbo.Cotizaciones ctz  
					--				INNER JOIN ASEPROT.dbo.Ordenes ord on ord.idOrden = ctz.idOrden
					--				INNER JOIN ASEPROT.dbo.Unidades uni on uni.idUnidad = ord.idUnidad 
					--				WHERE ctz.idTaller in ( SELECT cop.idProveedor  
					--										FROM ASEPROT.dbo.ContratoOperacionUsuario cou   
					--										INNER JOIN ASEPROT.dbo.ContratoOperacionUsuarioProveedor cop ON cop.idContratoOperacionUsuario =  cou.idContratoOperacionUsuario  
					--										INNER JOIN ASEPROT.dbo.ContratoOperacion cpe ON cpe.idContratoOperacion = cou.idContratoOperacion
					--										WHERE cou.idUsuario = @idUsuario  
					--											AND cpe.idOperacion = @idOperacion  
					--										)  
					IF EXISTS (SELECT 1
															FROM ASEPROT.dbo.ContratoOperacionUsuario cou   
															INNER JOIN ASEPROT.dbo.ContratoOperacionUsuarioProveedor cop ON cop.idContratoOperacionUsuario =  cou.idContratoOperacionUsuario  
															INNER JOIN ASEPROT.dbo.ContratoOperacion cpe ON cpe.idContratoOperacion = cou.idContratoOperacion
															WHERE cou.idUsuario = @idUsuario  
																AND cpe.idOperacion = @idOperacion  
															) 
										BEGIN
											SELECT 1 AS respuesta
												,'Unidad encontrada con éxito' AS mensaje, @economicoTemp as economico
											
										END
									ELSE
										BEGIN
										print 'otro3'
											SELECT 2 AS respuesta , 
										'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico ' + @economicoTemp AS mensaje, @economicoTemp as economico
										END	

				END
				ELSE IF (@tipoUsuario = 9) BEGIN -- Gerente de Zona
					IF EXISTS ( SELECT	1
							FROM	[dbo].[Unidades] UNI
								INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
								INNER JOIN ASEPROT.dbo.ContratoOperacionUsuario cou on cou.idContratoOperacion = CO.idContratoOperacion
								INNER JOIN ASEPROT.dbo.[ContratoOperacionUsuarioGerente] cog  ON cog.idContratoOperacionUsuario = cou.idContratoOperacionUsuario
								INNER JOIN ASEPROT.[Gerente].[EstadoGerencia] esg ON esg.idGerencia = cog.idGerencias  
								INNER JOIN ASEPROT.[Gerente].[EstadoZona] ezo ON ezo.idEstado = esg.idEstado  
						  
							WHERE   
								esg.estatus=0 --activo  
								AND ezo.estatus=0 --activo  
								AND cou.idUsuario = @idUsuario 
								AND UNI.idOperacion = @idOperacion
								AND UNI.idUnidad = @idUnidad)
							BEGIN
								SELECT 1 AS respuesta
									,'Unidad encontrada con éxito' AS mensaje, @economicoTemp as economico
											
							END
							ELSE BEGIN
							print 'otro2'
								SELECT 2 AS respuesta , 
									'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico ' + @economicoTemp AS mensaje, @economicoTemp as economico
							END	

				END
				ELSE BEGIN --Cliente & Otros

					IF EXISTS( SELECT	1
							FROM	[dbo].[Unidades] UNI
								INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
								INNER JOIN [dbo].[ContratoOperacionUsuario] COU ON COU.idContratoOperacion = CO.idContratoOperacion
								INNER JOIN [dbo].[ContratoOperacionUsuarioZona] COUZ ON COUZ.idContratoOperacionUsuario = COU.idContratoOperacionUsuario AND COUZ.idZona = UNI.idZona
							WHERE	UNI.idUnidad = @idUnidad AND COU.idUsuario = @idUsuario AND UNI.idOperacion = @idOperacion
					)
					BEGIN
						SELECT 1 AS respuesta
							,'Unidad encontrada con éxito' AS mensaje, @economicoTemp as economico
						FROM [dbo].[Unidades] 
						WHERE idUnidad = @idUnidad and [idOperacion] = @idOperacion
					END
				ELSE
					BEGIN
					print 'otro1'
						SELECT 2 AS respuesta , 
					'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico ' + @economicoTemp AS mensaje, @economicoTemp as economico
					END	

				END
			END ELSE BEGIN
				IF	(	EXISTS( SELECT	1 
						FROM	[dbo].[Unidades] UNI
							INNER JOIN [dbo].[ContratoOperacion] CO ON CO.idOperacion = UNI.idOperacion
							INNER JOIN [dbo].[ContratoOperacionUsuario] COU ON COU.idContratoOperacion = CO.idContratoOperacion
						WHERE	UNI.idUnidad = @idUnidad AND COU.idUsuario = @idUsuario AND UNI.idOperacion = @idOperacion
				))
					BEGIN
						SELECT 1 AS respuesta
							,'Unidad encontrada con éxito' AS mensaje, @economicoTemp as economico
					END
				ELSE
					BEGIN
						print 'otro'
						SELECT 2 AS respuesta , 
					'El usuario no cuenta con los permisos necesarios para consultar la unidad con el número económico ' + @economicoTemp AS mensaje, @economicoTemp as economico
					END	
				END
			END
		END
	ELSE
	BEGIN
		SELECT 0 AS respuesta , 
				'No se encontró la unidad con el número económico ' + @economico AS mensaje, @economico as economico
	END
END


go

