
-- ==========================================================================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 16/05/2017
-- ==========================================================================================
-- [dbo].[SEL_ZONAS_PARQUE_VEHICULAR_SP] @idContratoOperacion = 1, @idNivel=1 
CREATE PROC [dbo].[SEL_ZONAS_PARQUE_VEHICULAR_SP]
	@idContratoOperacion numeric(18,0),
	@idNivel numeric(18, 0),
	@idUsuario numeric(18,0)
AS
BEGIN
	
	declare @bdPartidas varchar(max) = (select nombreBD from [dbo].[Parametros] where [idParametros] = 1)
	declare @consulta varchar(max) = ''

	declare @idCOU numeric(18,0), @idRol numeric(18,0)--contratooperacionusuario

	select @idCOU = COU.idContratoOperacionUsuario, @idRol = COU.idCatalogoRol from Usuarios U 
	inner join ContratoOperacionUsuario COU on COU.idUsuario = U.idUsuario
	where U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	--declare @zonasAsignadas table (idZona int)
	declare @zonasContrato table(etiqueta varchar(max), idZona int, nombre varchar(max), idPadre int, orden int)

	if @idRol = 2 --Rol de administrador
	begin
		print 'Rol2'
		--los que son administradores
		insert into @zonasContrato 
		SELECT      NivZo.etiqueta, z.idZona, z.nombre, z.idPadre, NivZo.orden
		FROM		Partidas.dbo.Contrato AS Con INNER JOIN
				Partidas.dbo.Licitacion AS Li ON Con.idLicitacion = Li.idLicitacion INNER JOIN
				Partidas.dbo.Cliente AS Cli ON Li.idCliente = Cli.idCliente INNER JOIN
				Partidas.dbo.NivelZona AS NivZo ON Cli.idCliente = NivZo.idCliente INNER JOIN
				Partidas.dbo.Zona AS Z ON z.idNivelZona = NivZo.idNivelZona
		WHERE z.idNivelZona = @idNivel AND Con.idContrato IN (SELECT ConOp.idContrato
							FROM ContratoOperacion AS ConOp 
							WHERE ConOp.idContratoOperacion = @idContratoOperacion)

	end
	else
	begin
		print 'Rol!=2'
		--los que no son administradores
		insert into @zonasContrato 
		select NZ.etiqueta, Z.idZona, nombre, idPadre, orden from ContratoOperacionUsuario COU
		left join ContratoOperacionUsuarioZona COUZ on COUZ.idContratoOperacionUsuario = COU.idContratoOperacionUsuario
		left join Partidas..Zona Z on Z.idZona = COUZ.idZona
		left join Partidas..NivelZona NZ on NZ.idNivelZona = Z.idNivelZona 
		where idUsuario = @idUsuario and idContratoOperacion = @idContratoOperacion and NZ.idNivelZona = @idNivel--idPadre !=0

	end

	select * from @zonasContrato
END


--USE [ASEPROT]
go

