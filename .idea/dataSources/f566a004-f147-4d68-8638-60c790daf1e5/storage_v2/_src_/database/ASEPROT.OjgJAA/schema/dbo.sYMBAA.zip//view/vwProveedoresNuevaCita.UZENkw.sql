CREATE VIEW [dbo].[vwProveedoresNuevaCita]
AS

SELECT
P.idProveedor,P.nombreComercial,P.razonSocial
FROM Partidas..Proveedor P
WHERE P.idProveedor IN(1770,2526,447,613)


go

