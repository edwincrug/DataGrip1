--   [SEL_TOTAL_ORDENES_SERVICIO_SP] @fechaInicial='21/05/2017',@fechaFin = '01/06/2017',@idContratoOperacion = 2,@idZona = 1,@tipoConsulta = 1
--  [SEL_TOTAL_ORDENES_SERVICIO_SP] @tipoConsulta = 1,@idContratoOperacion = 2,@fechaEspecifico  = '24/05/2017'
CREATE PROCEDURE [dbo].[SEL_TOTAL_ORDENES_SERVICIO_SP_PRUEBAS]
@fechaInicial VARCHAR(MAX) = '', 
@fechaFin VARCHAR(MAX) = '',
@idContratoOperacion INT = 0,
@idZona NUMERIC(18,0)= 0,
@fechaEspecifico VARCHAR(MAX) ='',
@fechaMes VARCHAR(max) = '',
@tipoConsulta INT = 0,
@numeroOrden VARCHAR(50) = '',
@nivelZona INT = 0,
@idUsuario INT = 0
AS
BEGIN
	DECLARE @ipServidorPartidas NVARCHAR(300)='',@anio VARCHAR(10),@mes VARCHAR(10), @fechaprimer VARCHAR(10), @fechaFinal VARCHAR(10)
	SELECT @ipServidorPartidas = ipServidor FROM [ASEPROT].[dbo].[Parametros] where nombreBD='Partidas'
	DECLARE @queryText VARCHAR(max)
	IF(@fechaMes != '')
	BEGIN
		SET @fechaFin = @fechaMes
		SET @anio = YEAR(@fechaFin)
		SET @mes  = MONTH(@fechaFin)
		SET @fechaprimer = '01/0'+@mes+'/'+@anio
		SET @fechaFinal =  CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@fechaMes))),DATEADD(mm,1,@fechaMes)),103)

	END
	PRINT CONVERT (VARCHAR,@fechaEspecifico,103)
	PRINT @fechaFinal

	DECLARE @todo TABLE  (IDB INT IDENTITY(1,1),
							idOrden INT,
							numeroOrden NVARCHAR(MAX),
							fechaCita DATETIME,
							fechaCreacionOden  DATETIME,
							fechaInicioTrabajo DATETIME,
							fechaEstatusActual DATETIME,
							comentarioOrden NVARCHAR(MAX),
							numeroEconomico NVARCHAR(MAX),
							consecutivoOrden NVARCHAR(MAX),
							requiereGrua INT,
							descripcionEstadoUnidad NVARCHAR(MAX),
							idZona INT,
							nombreZona NVARCHAR(MAX),
							idUnidad INT,
							nombreCliente  NVARCHAR(MAX),
							idEstatusOrden INT,
							nombreEstatusOrden NVARCHAR(MAX),
							idContratoOperacion INT,
							idUsuario INT, 
							nombreUsuario NVARCHAR(MAX),
							idCatalogoTipoOrdenServicio INT,
							nombreTipoOrdenServicio NVARCHAR(MAX),
							idTipoOrden INT,
							nombreTipoORden NVARCHAR(MAX),
							estadistica  NVARCHAR(MAX),
							porcentaje  NVARCHAR(MAX),
							marcaUnidad NVARCHAR(MAX),
							modeloUnidad NVARCHAR(MAX),
							nombreTaller  NVARCHAR(MAX),
							idEstatusCotizacion INT,
							idCotizacion INT,
							nombreEstatusCotizacion NVARCHAR(MAX),
							numeroCotizacion NVARCHAR(MAX)
							)
	IF @tipoConsulta = 1
	BEGIN
			SET @queryText = 
							'SELECT ' + char(13) + 
				'					  Orden.[idOrden]' + char(13) + 
				'					  ,[numeroOrden]' + char(13) + 
				'					  ,[fechaCita] as fecha' + char(13) + 
				'					  ,convert(datetime, fechaCreacionOden, 103) as fechaCreacionOden' + char(13) + 
				'					  ,fechaInicioTrabajo' + char(13) + 
				'					  ,Histo.fechaInicial AS fechaEstatusActual' + char(13) + 
				'					  ,comentarioOrden' + char(13) + 
				'					  ,Uni.[numeroEconomico]' + char(13) + 
				'					  ,[consecutivoOrden] AS consecutivoOrden' + char(13) + 
				'					  ,[requiereGrua]' + char(13) + 
				'					  ,EstadoUni.descripcionEstadoUnidad' + char(13) + 
				'					  ,zona.[idZona]' + char(13) + 
				'					  ,zona.nombre' + char(13) + 
				'					  ,Uni.[idUnidad]' + char(13) + 
				'					  ,(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente' + char(13) + 
				'					  ,EtsOrden.[idEstatusOrden]' + char(13) + 
				'					  ,EtsOrden.[nombreEstatusOrden]' + char(13) + 
				'					  ,ConOpe.[idContratoOperacion]' + char(13) + 
				'					  ,Usu.[idUsuario]' + char(13) + 
				'					  ,Usu.nombreCompleto' + char(13) + 
				'					  ,CaTiOrSe.[idCatalogoTipoOrdenServicio]' + char(13) + 
				'					  ,CaTiOrSe.[nombreTipoOrdenServicio]' + char(13) + 
				'					  ,CaTiOr.[idTipoOrden]' + char(13) + 
				'					  ,CaTiOr.nombreTipoORden ' + char(13) + 
				'					  ,'+char(39)+''+char(39)+' AS estadistica ' + char(13) + 
				'					  ,'+char(39)+''+char(39)+' AS porcentaje ' + char(13) + 
				'					  ,'+char(39)+'FORD'+char(39)+' AS marcaUnidad' + char(13) + 
				'					  ,'+char(39)+'F-150'+char(39)+' AS modeloUnidad' + char(13) + 
				'					  ,'+char(39)+''+char(39)+' AS nombreTaller ' + char(13) + 
				'                     ,'+char(39)+''+char(39)+' AS idEstatusCotizacion ' + char(13) +
				'                     ,'+char(39)+''+char(39)+' AS idCotizacion ' + char(13) +
				'                     ,'+char(39)+''+char(39)+' AS nombreEstatusCotizacion ' + char(13) + 
				'                     ,'+char(39)+''+char(39)+' AS numeroCotizacion ' + char(13) +
				'			FROM [dbo].[Ordenes] Orden' + char(13) + 
				'						INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad' + char(13) + 
				'						INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad' + char(13) + 
				'						INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND ' + char(13) + 
				'						INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion' + char(13) + 
				'						INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario' + char(13) + 
				'						INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio' + char(13) + 
				--'						INNER JOIN ['+@ipServidorPartidas+'].[Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) + 
				'						INNER JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) + 
				'						INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden' + char(13) + 
				'						INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden' + char(13) + 
				'			WHERE		Orden.idEstatusOrden IN (1,2)' + char(13) +  
								'						AND Orden.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+'' + char(13) + 
								'						AND ((0 = '+CONVERT(NVARCHAR(100),@idZona)+')'+'OR(Orden.idZona = '+CONVERT(NVARCHAR(100),@idZona)+'))' + char(13) + 
								'' 
				INSERT INTO @todo EXECUTE (@queryText)


	END
ELSE
	BEGIN
		IF @tipoConsulta = 2
			BEGIN
			print 'Aprobaciones'
				SET @queryText = 
				'SELECT ' + char(13) + 
				'Orden.[idOrden] AS idOrden' + char(13) + 
'						  ,[numeroOrden] AS numeroOrden' + char(13) + 
'						  ,[fechaCita] as fechaCita' + char(13) + 
'						  ,convert(datetime, fechaCreacionOden, 103) as fechaCreacionOden ' + char(13) + 
'						  ,fechaInicioTrabajo AS fechaInicioTrabajo' + char(13) + 
'						  ,Histo.fechaInicial AS fechaEstatusActual' + char(13) + 
'						  ,comentarioOrden AS comentarioOrden' + char(13) + 
'						  ,Uni.[numeroEconomico] AS numeroEconomico' + char(13) + 
'						  ,[consecutivoOrden] AS consecutivoOrden' + char(13) + 
'						  ,[requiereGrua] AS requiereGrua' + char(13) + 
'						  ,EstadoUni.descripcionEstadoUnidad AS descripcionEstadoUnidad' + char(13) + 
'						  ,zona.[idZona] AS idZona' + char(13) + 
'						  ,zona.nombre AS nombreZona' + char(13) + 
'						  ,Uni.[idUnidad] AS idUnidad' + char(13) + 
'						  ,(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente ' + char(13) + 
'						  ,EtsOrden.[idEstatusOrden] AS idEstatusOrden' + char(13) + 
'						  ,EtsOrden.[nombreEstatusOrden] AS nombreEstatusOrden' + char(13) + 
'						  ,ConOpe.[idContratoOperacion] AS idContratoOperacion' + char(13) + 
'						  ,Usu.[idUsuario] AS idUsuario' + char(13) + 
'						  ,Usu.nombreCompleto AS nombreUsuario' + char(13) + 
'						  ,CaTiOrSe.[idCatalogoTipoOrdenServicio] AS idCatalogoTipoOrdenServicio' + char(13) + 
'						  ,CaTiOrSe.[nombreTipoOrdenServicio] AS nombreTipoOrdenServicio' + char(13) + 
'						  ,CaTiOr.[idTipoOrden] AS idTipoOrden' + char(13) + 
'						  ,CaTiOr.nombreTipoORden AS nombreTipoORden' + char(13) + 
'						  ,(SELECT [dbo].[SEL_ESTADISTICA_APROBACION_FT](Orden.idOrden)) AS estadistica ' + char(13) + 
'						  ,(SELECT [dbo].[SEL_PORCENTAJE_APROBACION_FT](Orden.idOrden)) AS porcentaje ' + char(13) + 
'						  ,'+char(39)+'FORD'+char(39)+' AS marcaUnidad' + char(13) + 
'						  ,'+char(39)+'F-150'+char(39)+' AS modeloUnidad' + char(13) + 
'						  ,'+char(39)+''+char(39)+' AS nombreTaller ' + char(13) + 
'                         ,Coti.[idEstatusCotizacion] AS idEstatusCotizacion ' + char(13) +
'                         ,Coti.[idCotizacion] AS idCotizacion ' + char(13) +
'                         ,EstCoti.[nombreEstatusCotizacion] AS nombreEstatusCotizacion ' + char(13) + 
'                         ,Coti.[numeroCotizacion] AS numeroCotizacion ' + char(13) +
'					FROM [dbo].[Ordenes] Orden' + char(13) + 
'						INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad' + char(13) + 
'						INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad' + char(13) + 
'						INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND ' + char(13) + 
'						INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion' + char(13) + 
'						INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario' + char(13) + 
'						INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio' + char(13) + 
--'						INNER JOIN ['+@ipServidorPartidas+'].[Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) + 
'						INNER JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) + 
'						INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden' + char(13) + 
'						INNER JOIN [dbo].[Cotizaciones] Coti ON Orden.idOrden = Coti.idOrden' + char(13) + 
'						INNER JOIN [dbo].[EstatusCotizaciones] EstCoti ON EstCoti.[idEstatusCotizacion] = Coti.[idEstatusCotizacion]' + char(13) +
'						INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden' + char(13) + 
'					WHERE ' + char(13) + 
'					   Histo.idEstatusOrden  = 4' + char(13) + 
'					   AND (Coti.idEstatusCotizacion = 1 OR Coti.idEstatusCotizacion = 2)' + char(13) +
								'						AND Orden.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+'' + char(13) + 
								'						AND ((0 = '+CONVERT(NVARCHAR(100),@idZona)+')'+'OR(Orden.idZona = '+CONVERT(NVARCHAR(100),@idZona)+'))' + char(13) + 
								'' 
						INSERT INTO @todo EXECUTE (@queryText)
			END
		ELSE
			BEGIN
			print 'ordenes de servicio'
			SET @queryText = 
				'SELECT ' + char(13) + 
'				  Orden.[idOrden] AS idOrden' + char(13) + 
'						  ,[numeroOrden] AS numeroOrden' + char(13) + 
'						  ,[fechaCita] as fechaCita' + char(13) + 
'						  ,convert(datetime, fechaCreacionOden, 103) as fechaCreacionOden ' + char(13) + 
'						  ,fechaInicioTrabajo AS fechaInicioTrabajo' + char(13) + 
'						  ,Histo.fechaInicial AS fechaEstatusActual' + char(13) + 
'						  ,comentarioOrden AS comentarioOrden' + char(13) + 
'						  ,Uni.[numeroEconomico] AS numeroEconomico' + char(13) + 
'						  ,[consecutivoOrden] AS consecutivoOrden' + char(13) + 
'						  ,[requiereGrua] AS requiereGrua' + char(13) + 
'						  ,EstadoUni.descripcionEstadoUnidad AS descripcionEstadoUnidad' + char(13) + 
'						  ,zona.[idZona] AS idZona' + char(13) + 
'						  ,zona.nombre AS nombreZona' + char(13) + 
'						  ,Uni.[idUnidad] AS idUnidad' + char(13) + 
'						  ,(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente ' + char(13) + 
'						  ,EtsOrden.[idEstatusOrden] AS idEstatusOrden' + char(13) + 
'						  ,EtsOrden.[nombreEstatusOrden] AS nombreEstatusOrden' + char(13) + 
'						  ,ConOpe.[idContratoOperacion] AS idContratoOperacion' + char(13) + 
'						  ,Usu.[idUsuario] AS idUsuario' + char(13) + 
'						  ,Usu.nombreCompleto AS nombreUsuario' + char(13) + 
'						  ,CaTiOrSe.[idCatalogoTipoOrdenServicio] AS idCatalogoTipoOrdenServicio' + char(13) + 
'						  ,CaTiOrSe.[nombreTipoOrdenServicio] AS nombreTipoOrdenServicio' + char(13) + 
'						  ,CaTiOr.[idTipoOrden] AS idTipoOrden' + char(13) + 
'						  ,CaTiOr.nombreTipoORden AS nombreTipoORden' + char(13) + 
'					  ,'+char(39)+''+char(39)+' AS estadistica ' + char(13) + 
'					  ,'+char(39)+''+char(39)+' AS porcentaje ' + char(13) + 
'						  ,'+char(39)+'FORD'+char(39)+' AS marcaUnidad' + char(13) + 
'						  ,'+char(39)+'F-150'+char(39)+' AS modeloUnidad' + char(13) + 
'						  ,'+char(39)+''+char(39)+' AS nombreTaller ' + char(13) +
'                         ,'+char(39)+''+char(39)+' AS idEstatusCotizacion ' + char(13) +
'                         ,'+char(39)+''+char(39)+' AS idCotizacion ' + char(13) +
'                         ,'+char(39)+''+char(39)+' AS nombreEstatusCotizacion ' + char(13) + 
'                         ,'+char(39)+''+char(39)+' AS numeroCotizacion ' + char(13) +
'					FROM [dbo].[Ordenes] Orden' + char(13) + 
'						INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad' + char(13) + 
'						INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad' + char(13) + 
'						INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND ' + char(13) + 
'						INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion' + char(13) + 
'						INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario' + char(13) + 
'						INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio' + char(13) + 
--'						INNER JOIN ['+@ipServidorPartidas+'].[Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) + 
'						INNER JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) + 
'						INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden' + char(13) + 
'						INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden' + char(13) + 
'					WHERE histo.idEstatusOrden  in (5,6,7)' + char(13) + 
'						AND Orden.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+'' + char(13) + 
'						AND ((0 = '+CONVERT(NVARCHAR(100),@idZona)+')'+'OR(Orden.idZona = '+CONVERT(NVARCHAR(100),@idZona)+'))' + char(13) + 
'' 
					INSERT INTO @todo EXECUTE (@queryText)
			END
	END
	SELECT * FROM @todo WHERE ((@fechaInicial = '')OR(fechaEstatusActual BETWEEN CONVERT (VARCHAR,@fechaInicial,103) AND  CONVERT (VARCHAR,@fechaFin,103)))
					   AND ((@idZona = 0)OR(idZona = @idZona))
					   AND ((@numeroOrden = '' ) OR(numeroOrden = @numeroOrden))
					   AND ((@fechaMes = '')OR(fechaEstatusActual BETWEEN CONVERT(VARCHAR,@fechaprimer,103) AND CONVERT(DATETIME,@fechaFinal,103)))
					   AND((@fechaEspecifico = '')OR( CONVERT (VARCHAR,fechaEstatusActual,103) = CONVERT (VARCHAR,@fechaEspecifico,103)))
END


go

