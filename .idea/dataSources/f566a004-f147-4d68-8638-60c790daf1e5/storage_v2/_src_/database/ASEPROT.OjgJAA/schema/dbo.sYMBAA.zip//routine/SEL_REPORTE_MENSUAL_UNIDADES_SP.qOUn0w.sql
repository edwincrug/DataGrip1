/* -------------------------------------
-- Author:		<Jose Armando Garcia Arroyo>
-- Create date: <06/03/2019>
-- Description:	<SP para extraer las unidades/ordenes especial para INTEGRA PF>
-- [SEL_REPORTE_MENSUAL_UNIDADES_SP] 37, null, null, null, null, null, null
 ------------------------------------- */
CREATE PROCEDURE [dbo].[SEL_REPORTE_MENSUAL_UNIDADES_SP] 
	@idContratoOperacion INT = 1,
	@idZona INT = NULL,
	@idCatalogoTipoOrdenServicio INT = NULL,
	@idCatalogoEstadoUnidad INT = NULL,
	@idServicio INT = NULL,
	@fechaInicial varchar(25) = NULL,
	@fechaFinal varchar(25) = NULL
AS
BEGIN

SET NOCOUNT ON;
SET DATEFORMAT YMD;

IF @fechaFinal IS NULL
BEGIN
 SET @fechaFinal = GETDATE()
END

DECLARE @idContrato INT = (SELECT idContrato FROM ContratoOperacion where idContratoOperacion=@idContratoOperacion)

DECLARE @zonas TABLE(idZona INT)

IF @idZona IS NOT NULL
BEGIN
INSERT INTO @zonas
SELECT * FROM [dbo].[fnZonaXZona](@idZona)
END
ELSE
BEGIN
INSERT INTO @zonas
SELECT NULL
END

SELECT
  UNI.[numeroEconomico]
  ,MA.[nombre] AS marca
  ,SM.nombre AS subMarca
  ,UNI.[vin]
  ,TU.tipo AS tipoUnidad
  ,dbo.fnNombreZona(UNI.idZona,3) AS area
  ,ISNULL(O.numeroOrden,'N/A') AS numeroOrden
  ,ISNULL(UPPER(EO.nombreEstatusOrden),'SIN ORDENES') AS estatus
  ,CONVERT(VARCHAR(50),O.fechaCreacionOden,103) as fechaSolicitud
  ,CONVERT(VARCHAR(50),O.fechaCreacionOden,108) as horaSolicitud
  ,(SELECT TOP 1 CONVERT(VARCHAR(50),HEO.fechaInicial,103) FROM HistorialEstatusOrden HEO
	where HEO.idorden=O.idOrden AND HEO.idEstatusOrden=2) AS fechaAtencion
  ,(SELECT TOP 1 CONVERT(VARCHAR(50),HEO.fechaInicial,108) FROM HistorialEstatusOrden HEO
	where HEO.idorden=O.idOrden AND HEO.idEstatusOrden=2) AS horaAtencion
  ,(SELECT TOP 1 CONVERT(VARCHAR(50),HEO.fechaInicial,103) FROM HistorialEstatusOrden HEO
	where HEO.idorden=O.idOrden AND HEO.idEstatusOrden=3) AS fechaIngreso
  ,(SELECT TOP 1 CONVERT(VARCHAR(50),HEO.fechaInicial,108) FROM HistorialEstatusOrden HEO
	where HEO.idorden=O.idOrden AND HEO.idEstatusOrden=3) AS horaIngreso
  ,(SELECT TOP 1 CONVERT(VARCHAR(50),BAE.FechaAviso,103) FROM HistorialEstatusOrden HEO
	where HEO.idorden=O.idOrden) AS fechaEntrega
  ,(SELECT TOP 1 CONVERT(VARCHAR(50),BAE.FechaAviso,108) FROM HistorialEstatusOrden HEO
	where HEO.idorden=O.idOrden) AS horaEntrega
	,[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) AS taller
	,ISNULL(U.nombreCompleto,'N/A')+': '+O.comentarioOrden AS Comentario
 FROM [dbo].[Unidades]  UNI
  LEFT JOIN dbo.Ordenes O
	LEFT JOIN Usuarios U ON U.idUsuario=O.idUsuario 
	LEFT JOIN BitacoraAvisoEntrega BAE ON BAE.idOrden=O.idOrden
	INNER JOIN dbo.EstatusOrdenes EO ON EO.idEstatusOrden=O.idEstatusOrden
  ON O.idUnidad=UNI.idUnidad
  INNER JOIN [dbo].[ContratoOperacion] CP 
	INNER JOIN .[Partidas].[dbo].[Contrato] C ON C.idContrato = CP.idContrato
  ON UNI.idOperacion = CP.idOperacion
  INNER JOIN .[Partidas].[dbo].[ContratoUnidad] CU ON CU.idContrato = CP.idContrato AND CU.idUnidad = UNI.idTipoUnidad
  INNER JOIN .[Partidas].[dbo].[Unidad] UNIP ON UNIP.idUnidad = CU.idUnidad
  INNER JOIN .[Partidas].dbo.SubMarca SM ON UNIP.idSubMarca = SM.idSubMarca
  INNER JOIN .[Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca
  LEFT JOIN  .[Partidas].dbo.Cilindros cil ON cil.idCilindros = UNIP.idCilindros
  INNER JOIN .[Partidas].[dbo].[TipoUnidad] TU ON TU.idTipoUnidad = UNIP.idTipoUnidad
WHERE C.idContrato=@idContrato
AND UNI.idZona IN (SELECT COALESCE(idZona,UNI.idZona) FROM @zonas)
AND O.fechaCreacionOden >= COALESCE(@fechaInicial,O.fechaCreacionOden) 
AND O.fechaCreacionOden < COALESCE(dateadd(d,1,CAST(@fechaFinal AS DATETIME)),O.fechaCreacionOden)
AND O.idCatalogoTipoOrdenServicio = COALESCE(@idCatalogoTipoOrdenServicio, O.idCatalogoTipoOrdenServicio)
AND O.idEstatusOrden NOT IN(13)
--AND O.idEstatusOrden IN(1,2,3)

ORDER BY UNI.vin
END
go

