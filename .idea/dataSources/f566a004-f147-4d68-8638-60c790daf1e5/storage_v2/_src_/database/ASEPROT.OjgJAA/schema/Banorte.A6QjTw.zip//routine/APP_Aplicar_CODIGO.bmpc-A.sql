

/*
	Fecha			Autor			Descripción
	06-Jun-2018		José Etmanuel	Se crea el SP para aplicar codigo de promoción
	27-Jun-2018     Jesús Santibañez Cambios en parametros que recibe el store para la promoción
	05-Jul-2018		José Etmanuel	Agrego el insert a la tabla de detalle para llecar cuando se cambian las promociones 
	29-Oct-2018		José Etmanuel	Agrego funcionalidad para pág. quito la obligatoriedad de la póliza
									Trato de conservar retrocompatibilidad

[Banorte].[APP_Aplicar_CODIGO] 0,111491,1
	
*/


CREATE PROCEDURE [Banorte].[APP_Aplicar_CODIGO] 
	@idPoliza VARCHAR(50) = 0,
	@codigo INT,
	@idUsaurio INT
AS   
BEGIN
	declare @sobran int = 0,
			@mensaje varchar(max)= 'No se pudo canjear el código.',
			@status int = 0,
			@idCanjeo int = 0,
			@idPatrocinador int = null,
			@idSucursal int = null
			;

	IF EXISTS (SELECT * FROM [dbo].[PromocionesCodigos] WHERE  [Codigo]= @codigo)
	BEGIN

	--	declare @sobran int = 0;
		SELECT @sobran= ISNULL([NumeroMaximo] - [Aplicadas],0)
		FROM [PromocionesCodigos] AS PC
		INNER JOIN [Banorte].[Promociones] as P on P.id = PC.IdPromocion
		WHERE [Codigo] = @codigo -- 111491
		AND Aplicadas<NumeroMaximo
		AND P.fechaTermino >= GETDATE()
		print @sobran;

		SET @mensaje = 'El código ha caducado.';

		IF @sobran >0
		BEGIN

			SELECT @idPoliza = IdPoliza FROM [PromocionesCodigos] where Codigo = @codigo;
			UPDATE [PromocionesCodigos] 
				SET [Aplicadas] = ([Aplicadas] +1)
				WHERE [Codigo]= @codigo

		
			SET @mensaje = 'Código se ha utilizado de manera correcta.';
			SET @status = 1;
		
			SELECT TOP 1 @idCanjeo = isnull(id,0) 
				FROM [Banorte].[PromocionesCodigosDet] 
				WHERE  [Codigo]= @codigo 
			ORDER BY id DESC

			SELECT @idPatrocinador = ISNULL([PatrocinadorId],0),@idSucursal =  ISNULL([IdSucursales],0) FROM [Banorte].[User_Suc] WHERE [idUsuario] = @idUsaurio;
			
			INSERT INTO [Banorte].[PromocionesCodigosDet]
				([Codigo],[IdPoliza],[Id],[PatrocinadorId],[IdSucursales],[FechaCanjeo],[idUsuario],[bBpro])
				VALUES (@codigo,@idPoliza,(@idCanjeo +1),isnull(@idPatrocinador,0),isnull(@idSucursal,0),GETDATE(),@idUsaurio,0)

			SET @sobran = @sobran -1
		END
	END
	
	Select @status as status, @mensaje as msg,  @sobran as sobran;
END
go

grant execute, view definition on Banorte.APP_Aplicar_CODIGO to DevOps
go

