
CREATE PROCEDURE [Banorte].[UPD_DESASIGNA_CR_SP]
	@idDatosCopade INT,
	@idUsuario INT
AS
BEGIN
	
	IF EXISTS(SELECT 1 FROM [ASEPROT].[dbo].[ContrareciboDatosCopade]
		WHERE idDatosCopade=@idDatosCopade)
			BEGIN

				INSERT [ASEPROT].[Banorte].[Bitacora] ([idUsuario],[fechaBitacora],[tabla],[descripcionID],[id],[descripcion],[estatus])
				VALUES(@idUsuario, GETDATE(),'[ASEPROT].[dbo].[ContrareciboDatosCopade]','[idDatosCopade]',@idDatosCopade,'Desvincula CR de la COPADE',1)

				DELETE [ASEPROT].[dbo].[ContrareciboDatosCopade]
				WHERE idDatosCopade=@idDatosCopade

					SELECT Success = 1, Msg = 'Se desvinculo correctamente el contrarecibo!';   
			END
		ELSE
			BEGIN

				SELECT Success = 0, Msg = 'No se encontro referencia del contrarecibo que se desea desvincular!';

			END 


END

go

