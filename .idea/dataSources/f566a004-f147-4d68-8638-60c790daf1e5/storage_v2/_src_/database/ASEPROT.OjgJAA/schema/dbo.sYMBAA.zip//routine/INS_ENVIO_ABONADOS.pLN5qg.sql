
CREATE PROC [dbo].[INS_ENVIO_ABONADOS] 
@string NVARCHAR(MAX)=null
as
BEGIN
    DECLARE @delimiter CHAR(1) =','
    DECLARE @start INT, @end INT
	 
    SELECT @start = 1, @end = CHARINDEX(@delimiter, @string) 
    WHILE @start < LEN(@string) + 1 BEGIN 
        IF @end = 0  
            SET @end = LEN(@string) + 1
			if not exists (select *from OrdenGlobalAbono where numeroOrdenGlobal=SUBSTRING(@string, @start, @end - @start))
			insert into OrdenGlobalAbono(numeroOrdenGlobal)
			values(SUBSTRING(@string, @start, @end - @start))
        SET @start = @end + 1 
        SET @end = CHARINDEX(@delimiter, @string, @start)
    END 
END
go

