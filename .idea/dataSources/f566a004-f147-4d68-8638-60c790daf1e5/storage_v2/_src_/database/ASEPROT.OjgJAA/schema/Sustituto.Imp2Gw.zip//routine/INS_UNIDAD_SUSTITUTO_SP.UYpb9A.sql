-- ==========================================================================================
-- Author:		Anel Candi Pérez Pérez 
-- Create date: 27/12/2016
-- Description:	Stored que inserta la relación de unidad con su sustituto 
-- [Sustituto].[INS_UNIDAD_SUSTITUTO_SP] 7714, 0 , 2, 538, '0', 17, 'SINIESTRO 418401230104099', NULL
-- ==========================================================================================
CREATE PROCEDURE [Sustituto].[INS_UNIDAD_SUSTITUTO_SP]
	@idUnidad	NUMERIC(18,0),
	@idSustituto	NUMERIC(18,0),
	@idMotivo	NUMERIC(18,0),
	@idUsuario	NUMERIC(18,0),
	@numeroOrden nvarchar(50),
	@idContratoOperacion NUMERIC(18,0),
	@comentarios nvarchar(100),
	@fechaAsignacion DATETIME
AS
BEGIN
    --select * from UnidadSustituto
	INSERT INTO [Sustituto].[UnidadSustituto]
		(	idUnidad,
			idSustitutoUni,
			idMotivo,
			fecha,
			idUsuario,
			estatus, 
			numeroOrden,
            idContratoOperacion,
			comentarios,
			fechaSalida
		)
		VALUES
		(
			@idUnidad,
			@idSustituto,
			@idMotivo,
			GETDATE(),
			@idUsuario,
			0,
			@numeroOrden,
			@idContratoOperacion,
			@comentarios,
			NULL
		)

		SELECT @@IDENTITY AS ID
END
go

