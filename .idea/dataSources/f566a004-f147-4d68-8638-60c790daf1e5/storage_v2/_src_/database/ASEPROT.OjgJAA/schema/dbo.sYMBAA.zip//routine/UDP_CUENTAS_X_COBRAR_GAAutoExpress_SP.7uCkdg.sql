
-- Actualizacion de Estatus de Bpro Ade Copade
-- TEST [dbo].[UDP_CUENTAS_X_COBRAR_GAAutoExpress_SP]

CREATE PROC [dbo].[UDP_CUENTAS_X_COBRAR_GAAutoExpress_SP]


AS
BEGIN
select 1

--- Step 00 Variables de Inicio
    declare @FecIni datetime = getdate()


--- STEP 01
	--- Logger Data to Update

	-- SELECT * FROM 
	INSERT INTO [Bpro].[FacturasActulizarSP]
			   ([COP_STATUS]
			   ,[NewStatus]
			   ,[COP_CARGO]
			   ,[ImporteUpdate]
			   ,[COP_SAlDO]
			   ,[SaldoUpdate]
			   ,[COP_FECHULTPAG]
			   ,[FechaVenUpdate]
			   ,[CCP_IDDOCTO]
			   ,[COP_IDDOCTO]
			   ,[ReqUpdate]
			   ,[StoredName]
			   ,[DateExecution])
    


		SELECT  D.[COP_STATUS]     , O.[NewStatus],
			    D.[COP_CARGO]      , O.[Importe] as [ImporteUpdate],
			    D.[COP_SAlDO]      , O.[Saldo] as [SaldoUpdate],
			    D.[COP_FECHULTPAG] , O.[CCP_FECHVEN] as [FechaVenUpdate],
			    O.[CCP_IDDOCTO]    , D.COP_IDDOCTO,
			    O.[ReqUpdate] ,
			    'UDP_CUENTAS_X_COBRAR_GAAutoExpress_SP' as [StoredName],
			    GETDATE() as [DateExecution]
			 		 
			FROM [192.168.20.29].[GAAutoExpress].[dbo].ADE_COPADE D
	  INNER JOIN [Bpro].[VwActualizarStatusDefA] O
			  ON O.[CCP_IDDOCTO] = D.COP_IDDOCTO
		   WHERE O.[ReqUpdate] =1


		 --  SELECT *
		 --    FROM [Bpro].[VwActualizarStatusDefA]
			--WHERE [ReqUpdate] = 1


    --Step 02
	-- Update Status, Cop_Cargo, Cop_saldo, Fecha Ult Pag
	
	UPDATE D
     SET D.[COP_STATUS]     = O.[NewStatus],
         D.[COP_CARGO]      = O.[IMporte],
	     D.[COP_SAlDO]      = O.[Saldo],
         D.[COP_FECHULTPAG] = O.[CCP_FECHVEN]
        FROM [192.168.20.29].[GAAutoExpress].[dbo].ADE_COPADE D
  INNER JOIN [Bpro].[VwActualizarStatusDefA] O
          ON O.[CCP_IDDOCTO] = D.COP_IDDOCTO
       WHERE O.[ReqUpdate] = 1


  -- Step 03  Variables de Fin de Execution
       --declare @FecIni datetime = getdate()
       declare @NumUpdate int = @@ROWCOUNT
       declare @FecFin datetime = getdate()


-- Step 04  Log Execution
INSERT INTO [Bpro].[ProcessExecution]
           ([Process Init]
           ,[Number Rows Update]
           ,[Process Finish]
           ,[Process Duration]
		   ,[Process Name])

   Select @FecIni as [Process Init],
          @NumUpdate as [Number Rows Update],
		  @FecFin as [Process Finish],
		  datediff(ss,@FecIni,@FecFin) as [Process Duration],
		  'UDP_CUENTAS_X_COBRAR_GAAutoExpress_SP' as [ProcessName]
     --into [Bpro].[ProcessExecution]

	
END
go

