
-- EXEC SEL_PARTIDAS_UNIDAD_SP @idContratoOperacion = 3, @idTipoUnidad = 8

CREATE PROCEDURE [dbo].[SEL_PARTIDAS_UNIDAD_SP]
	@idContratoOperacion NUMERIC(18,0) = 0,
	@idTipoUnidad NUMERIC(18,0) = 0
AS
		
		SELECT  PART.idPartida,
				PART.idUnidad,
				CONTUNIDAD.idContrato,
				CL1.idPartidaClasificacion,
				CL1.clasificacion,
				CL2.idPartidaSubClasificacion,
				CL2.subClasificacion,
				partida,
				noParte,
				PART.descripcion,
				PART.foto,
				PART.instructivo,
				ISNULL(PROVPART.costo,0.00) as costo,
				ISNULL(CONTPART.venta,0.00) as venta,
				PARTEST.idPartidaEstatus,
				isnull(PARTEST.estatus, 'Sin Asignar') as partidaEstatus,
				TU.tipo
		FROM Partidas..Partida PART
		JOIN [Partidas].[dbo].[ProveedorPartida] PROVPART ON PART.idPartida = PROVPART.idPartida 
		JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON PART.idPartida = CONTPART.idPartida
		LEFT JOIN [Partidas].[dbo].[ContratoUnidad] CONTUNIDAD ON CONTPART.idContratoUnidad = CONTUNIDAD.idContratoUnidad
		LEFT JOIN [Partidas].[dbo].[Contrato] CONT ON CONTUNIDAD.idContrato = CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[ContratoProveedor] CONTPROV ON CONT.idContrato = CONTPROV.idContrato
		JOIN [Partidas].[dbo].[PartidaClasificacion] PARCLAS ON PART.idPartidaClasificacion = PARCLAS.idPartidaClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaClasificacion] CL1 ON CL1.idPartidaClasificacion = PART.idPartidaClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaSubClasificacion] CL2 ON CL2.idPartidaSubClasificacion = PART.idPartidaSubClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaEstatus] PARTEST ON PARTEST.idPartidaEstatus = PART.estatus--PROVPART.idPartidaEstatus
		LEFT JOIN [Partidas].[dbo].[Unidad] UNI ON UNI.idUnidad = PART.idUnidad
		left join [Partidas].[dbo].TipoUnidad TU ON TU.idTipoUnidad = UNI.idTipoUnidad
		WHERE  CONT.idContrato IN (SELECT idContrato FROM ContratoOperacion WHERE idContratoOperacion = @idContratoOperacion)
			   AND UNI.idUnidad = @idTipoUnidad
		--AND PART.estatus = 4 -- aprobado
		--AND PROVCOT.idCotizacionEstatus = 3
		/*select * from Unidades
		select * from [Partidas].[dbo].[ContratoUnidad]
		
		select * from [Partidas].[dbo].Unidad
		select * from [Partidas].[dbo].[ContratoProveedor]
		select * from [Partidas].[dbo].ProveedorPartida

		select * from [Partidas].[dbo].Partida
		select * from [Partidas].[dbo].TipoUnidad*/

go

