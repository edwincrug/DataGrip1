
CREATE PROCEDURE [dbo].[SEL_CONTRARECIBO_SP]
	@idContratoOperacion AS INT
AS
BEGIN

	SELECT 
		CR.idContrarecibo,
		CR.numeroContrarecibo, 
		CR.fechaContrarecibo, 
		CR.estatus, 
		C.descripcion, 
		U.nombreCompleto 
	FROM Contrarecibo CR
	JOIN ContratoOperacion CO ON CO.idContratoOperacion = CR.idContratoOperacion
	JOIN Partidas..Contrato C ON C.idContrato = CO.idContrato
	JOIN Usuarios U ON U.idUsuario = CR.idUsuario
	WHERE CO.idContratoOperacion = @idContratoOperacion AND CR.estatus = 0 AND CR.idContrarecibo NOT IN(SELECT idContrarecibo FROM ContrareciboDatosCopade)

END

go

