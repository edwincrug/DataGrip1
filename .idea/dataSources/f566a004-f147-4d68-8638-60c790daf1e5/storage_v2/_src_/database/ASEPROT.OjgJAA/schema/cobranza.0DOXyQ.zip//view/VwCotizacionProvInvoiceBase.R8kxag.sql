








-- DROP VIEW [cobranza].[VwCotizacionProvInvoiceBase]
-- SELECT * FROM [cobranza].[VwCotizacionProvInvoiceBase]
--  REcords 21,573   TIME 1 Second
CREATE VIEW [cobranza].[VwCotizacionProvInvoiceBase]
AS

  SELECT
DISTINCT 
	     O.[idOrden], 
	     C.[numeroCotizacion],
	     C.[idCotizacion],
	   --GAE.OTE_IDPROVEEDOR,
	     PE.idBPRO as [idProveedor],
	    FC.numFactura

   FROM Ordenes O

INNER JOIN [dbo].[Cotizaciones] C --with (nolock)
        ON O.[idOrden] = c.[idOrden]

--INNER JOIN [192.168.20.31].[192.168.20.31].[GAAutoExpress].[dbo].[ADE_ORDSERENC]  GAE --with (nolock)
--  INNER JOIN [BPro].[VwADE_ORDSERENC_GAAutoExpress] GAE
--        ON GAE.OTE_ORDENANDRADE = O.numerooRDEN --COLLATE Modern_Spanish_CS_AS

 INNER JOIN Partidas..Proveedor p 
         ON p.idProveedor = C.idTaller 

 INNER JOIN Partidas..ProveedorEncabezadoEmpresa pe 
         ON pe.idProveedorEncabezado = p.idProveedorEncabezado 		
		AND pe.idEmpresa = 1

 
INNER JOIN FacturaCotizacion FC
      ON FC.idCotizacion=C.idCotizacion

go

