-- =============================================
-- Autor: Miguel Angel Reyes
-- Fecha: 09/08/2018
-- Login para los usuarios de sisco dentro de la aplicacion movil
-- [Banorte].[ValidaUsuario] 'SAHI.LLANES', 'SAHI'
-- =============================================
CREATE PROCEDURE [Banorte].[ValidaUsuario]
	@usuario		varchar(50),
	@contrasena		varchar(50) 
AS
DECLARE @idUsuario int=0
BEGIN

	SELECT @idUsuario = u.idUsuario
	FROM [Usuarios] u
	WHERE [nombreUsuario] = @usuario 
		AND [contrasenia] = @contrasena

	IF (@idUsuario > 0)
	BEGIN
		IF EXISTS (SELECT u.idUsuario FROM [Usuarios] u WHERE idUsuario = @idUsuario
		AND idCatalogoTipoUsuarios in (1,4))
		BEGIN
			SELECT 1 estatus, 'El usuario y password son validos' mensaje

			SELECT 
				u.[idUsuario]
				,u.[nombreCompleto] nombre
				,u.telefonoUsuario telefono
				,u.[correoElectronico] correo
			FROM [Usuarios] u
			WHERE idUsuario = @idUsuario
		END
		ELSE
		BEGIN
			SELECT 2 estatus, 'El perfil del usuario no tiene acceso' mensaje
		END
	END
	ELSE
	BEGIN
		SELECT 0 estatus, 'El usuario o el password son incorrectos' mensaje
	END

END
go

grant execute, view definition on Banorte.ValidaUsuario to DevOps
go

