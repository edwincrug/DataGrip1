



CREATE VIEW [report].[VwReporteGeneralCopadeTolucaUnique]
AS

   SELECT
   *
   FROM [report].[VwReporteGeneralCopadeToluca]

   where idOrden not in
   (
   
select [idOrden]
from (
select count(*) as [Events],[idOrden]
      --,[COP_IDDOCTO]
  FROM [report].[VwReporteGeneralCopadeToluca]
  group by [idOrden]
     -- ,[COP_IDDOCTO]
  --order  by count(*) desc
	  having count(*) > 1
	  ) as Dobles
	  )

go

