-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03/06/2017
-- [UPD_PROVISION_BPRO_SP] 344, 12, 1, 0
-- =============================================
CREATE PROCEDURE [dbo].[UPD_PROVISION_BPRO_SP] 
	@idOrden NUMERIC(18,0),
	@idUsuario NUMERIC(18,0),
	@idOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0)
AS
BEGIN

DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE	@query NVARCHAR(MAX)
DECLARE @idContratoOperacion NUMERIC(18,0)

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DBProduccion,
				@idContratoOperacion = CO.idContratoOperacion
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB,
				@idContratoOperacion = CO.idContratoOperacion
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END

	DECLARE @numeroOrden NVARCHAR(100)

	SELECT  @numeroOrden = numeroOrden
	FROM Ordenes 
	WHERE idOrden = @idOrden
	
	UPDATE aprobacionProvision
	SET estatus = 1
	WHERE idOrden = @idOrden

	SET @query = ' UPDATE '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC]
	SET OTE_STATUS = 1
	WHERE OTE_ORDENANDRADE = '''+@numeroOrden+''' '

	EXECUTE SP_EXECUTESQL @query

	IF (@idContratoOperacion = 3)
		BEGIN
			EXEC UPD_PROVISION_BPRO_CONCAR_SP @numeroOrden, @idContratoOperacion, @isProduction
		END

	SELECT 1
END
go

