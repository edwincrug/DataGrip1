-- =============================================
-- Create date: 21/04/2017
-- Description:	Obtiene el historico de reclamaciones generados.
-- [SEL_HISTORIAL_RECLAMACION_SP] null,null
-- =============================================
create PROC [dbo].[SEL_HISTORIAL_RECLAMACION_SP]
	@noReporte NVARCHAR(100) = NULL,
	@fechaInicio NVARCHAR(50) = NULL,
	@fechaFin NVARCHAR(50) = NULL

AS
BEGIN
	DECLARE @select NVARCHAR(MAX) = ''
	DECLARE	@where  NVARCHAR(MAX) = ''
	DECLARE	@query  NVARCHAR(MAX) = ''
	DECLARE	@fecha  NVARCHAR(MAX) = ''
	DECLARE	@report NVARCHAR(MAX) = ''

	SET @select =
	'SELECT * FROM Reclamacion'

	SET @where=' WHERE 1=1 '

		IF(@fechaInicio IS NOT NULL AND @fechaFin IS NOT NULL)
		  BEGIN
			SET @fecha=' AND fechaAlta BETWEEN CAST('+''''+@fechaInicio+''''+' AS DATETIME) AND CAST('+''''+@fechaFin+''''+' AS DATETIME) '
		  END
		IF(@noReporte IS NOT NULL)
		  BEGIN
		  	SET @report =
				' AND (noReporte LIKE ''%'+@noReporte+'%'' ) '
		  END

	SET @query = @select+@where+@fecha+@report
	EXECUTE SP_EXECUTESQL @query 
	PRINT @query 

END
go

