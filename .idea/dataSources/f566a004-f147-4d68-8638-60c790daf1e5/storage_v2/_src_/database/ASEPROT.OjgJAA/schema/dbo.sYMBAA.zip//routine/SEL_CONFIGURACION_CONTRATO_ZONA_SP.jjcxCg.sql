
--SEL_CONFIGURACION_CONTRATO_ZONA_SP 58

CREATE PROCEDURE [dbo].[SEL_CONFIGURACION_CONTRATO_ZONA_SP] (
	@IdOperacion INT
)
as
begin

DECLARE @IdNivelPadre int
DECLARE @VariableTabla TABLE ( ID INT IDENTITY(1,1),
								idNivelZona int, 
								idZona   	    nvarchar(150),
								nombre	        nvarchar(150),
								contrato		nvarchar(150),
								presupuesto		nvarchar(150)
								  )
INSERT INTO @VariableTabla (idNivelZona, idZona, nombre, contrato, presupuesto) 
SELECT ZO.idNivelZona, ZO.idZona, ZO.nombre, PGCZ.Contrato, ISNULL(PGCZ.Presupuesto,0) Presupuesto 
		FROM [Partidas].[dbo].[Zona] ZO
			 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
			 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
			 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
			 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
			 LEFT JOIN ParametrosGeneralContratoZona PGCZ ON PGCZ.IdOperacion = CO.idOperacion AND PGCZ.IdZona = ZO.idZona 
			 AND PGCZ.IdParametroGeneral = 8 /*Parametro de contrato por zona padre*/
WHERE CO.idOperacion = @IdOperacion ORDER BY NZ.idNivelZona, ZO.idZona

SELECT @IdNivelPadre = MIN(idNivelZona) from @VariableTabla

SELECT * FROM @VariableTabla WHERE idNivelZona = @IdNivelPadre ORDER BY nombre DESC

end
go

