-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 23/05/2017
-- Description:	Obtiene los centros de trabajo por operación 
-- SEL_CENTROS_DE_TRABAJO_SP 
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_CENTROS_DE_TRABAJO_SP]
	@idOperacion INT
AS
BEGIN
	
  SELECT idCentroTrabajo, nombreCentroTrabajo FROM CentroTrabajos WHERE idOperacion = @idOperacion
   
END


go

