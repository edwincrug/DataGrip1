-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 10/08/2018
-- Description:	Obtener los mensajes de los usuarios desasignados
-- EXEC [Mobile].[Upd_Desasignados_Sp] 1
-- =============================================
CREATE PROCEDURE [Mobile].[Upd_Desasignados_Sp]
	@id				int
AS
BEGIN

	UPDATE [ASEPROT].[Mobile].[UsuarioUnidadContratoOperacionDesAsignado] SET visto = 1
	WHERE id = @id
	SELECT @@ROWCOUNT visto

END
go

grant execute, view definition on Mobile.Upd_Desasignados_Sp to DevOps
go

