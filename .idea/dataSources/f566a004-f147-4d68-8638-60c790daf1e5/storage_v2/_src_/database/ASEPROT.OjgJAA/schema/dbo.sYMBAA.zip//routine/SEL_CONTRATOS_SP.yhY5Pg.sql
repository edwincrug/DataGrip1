-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 19/05/2017
-- Description:	Obtiene los contratos de la BD.Partidas que no estan ligados con una operación
-- SEL_CONTRATOS_SP 5
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_CONTRATOS_SP]
	@idOperacion INT = NULL
AS
BEGIN

	

	DECLARE @queryText varchar(max) = 
		'' + char(13) + 
		'' + char(13) + 
		'	IF '+convert(varchar (10), @idOperacion)+'= NULL'+ char(13) + 
		'		BEGIN' + char(13) + 
		'		  SELECT LIC.idLicitacion,' + char(13) + 
		'				 LIC.nombre, ' + char(13) + 
		'				 CON.idContrato,' + char(13) + 
		'				 CL.razonSocial, ' + char(13) + 
		'				 CON.fechaInicio, ' + char(13) + 
		'				 CON.fechaFin, ' + char(13) + 
		'				 CON.descripcion' + char(13) + 
		'		   FROM .[Partidas].dbo.Contrato CON' + char(13) + 
		'				INNER JOIN .[Partidas].dbo.Licitacion LIC ON CON.idLicitacion = LIC.idLicitacion' + char(13) + 
		'				INNER JOIN .[Partidas].dbo.cliente CL ON CL.idCliente = LIC.idCliente' + char(13) + 
		'		   WHERE NOT EXISTS (SELECT idContrato FROM ContratoOperacion WHERE CON.idContrato = idContrato)' + char(13) + 
		'		END' + char(13) + 
		'	ELSE' + char(13) + 
		'		BEGIN' + char(13) + 
		'			SELECT LIC.idLicitacion,' + char(13) + 
		'				 LIC.nombre, ' + char(13) + 
		'				 CON.idContrato,' + char(13) + 
		'				 CL.razonSocial, ' + char(13) + 
		'				 CON.fechaInicio, ' + char(13) + 
		'				 CON.fechaFin, ' + char(13) + 
		'				 CP.idOperacion,' + char(13) + 
		'				 CP.idContratoOperacion,' + char(13) + 
		'				 CON.descripcion' + char(13) + 
		'		   FROM .[Partidas].dbo.Contrato CON' + char(13) + 
		'				INNER JOIN .[Partidas].dbo.Licitacion LIC ON CON.idLicitacion = LIC.idLicitacion' + char(13) + 
		'				INNER JOIN .[Partidas].dbo.cliente CL ON CL.idCliente = LIC.idCliente' + char(13) + 
		'				LEFT JOIN ContratoOperacion CP ON CP.idContrato = CON.idContrato ' + char(13) + 
		'		END' + char(13) + 
		'  ' + char(13) + 
		'' + char(13) + 
		'' + char(13) + 
		'' + char(13) + 
		'' 
		 exec(@queryText)
		 --print @queryText
  
END


go

