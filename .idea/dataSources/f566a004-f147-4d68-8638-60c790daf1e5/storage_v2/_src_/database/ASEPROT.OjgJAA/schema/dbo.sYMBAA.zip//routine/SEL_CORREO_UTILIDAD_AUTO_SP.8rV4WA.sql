
-- EXEC [SEL_CORREO_UTILIDAD_SP] 484, 137, 600
-- EXEC [SEL_CORREO_UTILIDAD_SP] 377, 142, 313
CREATE PROCEDURE [dbo].[SEL_CORREO_UTILIDAD_AUTO_SP]
	@idOrden NUMERIC(18,0),
	@idUsuario NUMERIC(18,0)

AS
BEGIN
	DECLARE @nombreEstatusOrden VARCHAR(50) = ''
	DECLARE @idCotizacionX INT
	DECLARE @idCotizacionDetalleX INT
	DECLARE @numeroCotizacion NVARCHAR(200)
	DECLARE @descripcionLarga NVARCHAR(1500)
	DECLARE @partida NVARCHAR(300)
	DECLARE @noParte NVARCHAR(300)
	DECLARE @descripcion NVARCHAR(1500)
	DECLARE @cantidad DECIMAL(18,0)
	DECLARE @precioCompra  DECIMAL(18,2) = 0
	DECLARE @precioTotalCompra DECIMAL(18,2) = 0
	DECLARE @precioVenta  DECIMAL(18,2) = 0
	DECLARE @precioTotalVenta DECIMAL(18,2) = 0
	DECLARE @utilidadPartida DECIMAL(18,2) 
	DECLARE @margenPartida DECIMAL(18,2)
	DECLARE @style  NVARCHAR(1000)
	DECLARE @tabla NVARCHAR(MAX) = ' '
	DECLARE @totalCliente DECIMAL(18,2) = 0
	DECLARE @totalTaller DECIMAL(18,2) = 0
	DECLARE @htmlPartidas  NVARCHAR(MAX) = ' '
	DECLARE @totalUtilidad DECIMAL(18,2) = 0
	DECLARE @totalMargen DECIMAL(18,2) = 0

	SELECT @nombreEstatusOrden = EO.nombreEstatusOrden
	FROM Ordenes O
	JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
	WHERE O.idOrden = @idOrden

	DECLARE @html NVARCHAR(MAX) = '',
			@cadena NVARCHAR(MAX) = '',
			@nombreCompleto NVARCHAR(500) = '', 
			@numeroOrden NVARCHAR(500) = '',
			@destinatarios VARCHAR(500) = '', 
			@idEstatusOrden INT

	SELECT @nombreCompleto = nombreCompleto,
		   @cadena = correoElectronico
	FROM Usuarios 
	WHERE idUsuario=@idUsuario

	SELECT @numeroOrden=numeroOrden,
		   @idEstatusOrden=idEstatusOrden
	FROM Ordenes 
	WHERE idOrden=@idOrden


	DECLARE @texto VARCHAR(200) = 'La orden ' + @numeroOrden + ' ha cambio ' +  + ' al estatus ' + @nombreEstatusOrden
	DECLARE @tallerDiv VARCHAR(1000) = '', 
			@nombreTaller VARCHAR(100) = '',
			@nombreZona VARCHAR(100) = ''

	SELECT @nombreZona = ISNULL(Z.nombre, 'Sin zona asignada')
	FROM Ordenes ORD
	LEFT JOIN [Partidas]..[Zona] Z ON ORD.idZona = Z.idZona
	WHERE ORD.idOrden = @idOrden

	IF EXISTS(SELECT * FROM Ordenes WHERE idTaller <> 0 AND idOrden = @idOrden)
		BEGIN
			SELECT @nombreTaller = PRO.nombreComercial 
			FROM Ordenes ORD
			LEFT JOIN [Partidas]..[Proveedor] PRO ON ORD.idTaller = PRO.idProveedor
			WHERE ORD.idOrden = @idOrden

			SET @tallerDiv = '<div style="font-size: 14px;color: #0489B1;margin-left: 10px;margin-top: 10px;">
								Taller: <span  style="font-size: 14px;color: #000000;">'+ @nombreTaller +'</span>
							  </div>'
		END

	-- INICIO CUERPO DE CORREO DE UTILIDAD PARTIDAS
	DECLARE eCotiza CURSOR FOR
		SELECT idCotizacion 
		FROM Ordenes O
		JOIN Cotizaciones C ON C.idOrden = O.idOrden
		WHERE C.idOrden = @idOrden AND C.idEstatusCotizacion<4--AND C.idCotizacion = @idCotizacion

	OPEN eCotiza
	FETCH NEXT FROM eCotiza INTO @idCotizacionX
		WHILE @@FETCH_STATUS = 0
		BEGIN	

	DECLARE cElementos CURSOR FOR
		SELECT CD.idCotizacionDetalle
		FROM Ordenes O
		JOIN Cotizaciones C ON C.idOrden = O.idOrden
		JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
		WHERE C.idCotizacion = @idCotizacionX AND CD.idEstatusPartida IN (1,2)

	OPEN cElementos
	FETCH NEXT FROM cElementos INTO @idCotizacionDetalleX
		WHILE @@FETCH_STATUS = 0
		BEGIN
				SELECT 
					  @numeroCotizacion = C.numeroCotizacion,
					  @descripcionLarga = EO.nombreEstatusOrden,
					  @partida = P.partida,
					  @noParte = P.noParte,
					  @descripcion = P.descripcion,
					  @cantidad = CD.cantidad,
					  @precioCompra = CD.costo, 
					  @precioTotalCompra = (CD.costo * CD.cantidad),
					  @precioVenta = CD.venta,
					  @precioTotalVenta = (CD.venta * CD.cantidad),
					  @utilidadPartida = ((CD.venta * CD.cantidad)-(CD.costo * CD.cantidad)),	
					  @margenPartida = ((((CD.venta * CD.cantidad)-(CD.costo * CD.cantidad))* 100)/(CD.venta * CD.cantidad))
				FROM Ordenes O
				JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
				JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
				JOIN Operaciones OS ON OS.idOperacion = CO.idOperacion
				JOIN Cotizaciones C ON C.idOrden = O.idOrden
				JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
				JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
				WHERE CD.idCotizacionDetalle = @idCotizacionDetalleX AND CD.idEstatusPartida IN (1,2)

			IF((@precioTotalVenta) <= (@precioTotalCompra))
				BEGIN
					SET @style = 'style="background-color: #f2dede; font-family: Arial; font-size: 14px; border: 2px solid #cec8c8;"'
				END
			ELSE
				BEGIN
					SET @style = 'style="font-family: Arial; font-size: 14px; border: 2px solid #cec8c8; "'
				END 
		
		
			SET @tabla = @tabla + '<tr '+@style+'><td style=" border: 1px solid #cec8c8; ">' + @partida + '</td>' +
                                 '<td style=" border: 1px solid #cec8c8; ">' + @noParte + '</td>' +
								 '<td style=" border: 1px solid #cec8c8; font-size: 12px; text-align: justify">' + UPPER(@descripcion) + '</td>' +
								 '<td style=" border: 1px solid #cec8c8; ">' + CONVERT(VARCHAR(50),@cantidad) + '</td>' +
                                 '<td style=" border: 1px solid #cec8c8; ">$' + CONVERT(VARCHAR, CAST(@precioTotalCompra AS MONEY)) + '</td>' +
                                 '<td style=" border: 1px solid #cec8c8; ">$' + CONVERT(VARCHAR, CAST(@precioTotalVenta AS MONEY)) + '</td>'+
								 '<td style=" border: 1px solid #cec8c8; ">$' + CONVERT(VARCHAR, CAST(@utilidadPartida AS MONEY)) + '</td>' +
								 '<td style=" border: 1px solid #cec8c8; ">' + CONVERT(VARCHAR, CAST(@margenPartida AS MONEY)) + '%</td></tr>  '

			SET @totalCliente= ((@totalCliente) + (@precioTotalVenta))
			SET @totalTaller= ((@totalTaller) + (@precioTotalCompra))

			FETCH NEXT FROM cElementos INTO @idCotizacionDetalleX		 

		END
	CLOSE cElementos
	DEALLOCATE cElementos
	-- ================================================================================	
	SET @totalUtilidad = ((@totalCliente) - (@totalTaller))
	SET @totalMargen = ((( @totalCliente - @totalTaller)*100)/@totalCliente)

	SET @htmlPartidas='
		<!DOCTYPE html>
		<html lang="es">
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		</head>
		<body>
			<div style="font-family: Arial;">
				<div style="font-size: 16px;color: #0489B1;margin-left: 10px; text-align: center;">
						<h3>Margen de utilidad por debajo de lo esperado para la orden ' + @numeroOrden + '</h3>
					</div>

				<div style="font-family: Arial;font-size: 14px; text-align: center;">

					<div style="font-size: 14px;color: #0489B1;margin-left: 10px; text-align: center;">
						<h3>Detalle de partidas.</h3>
					</div>

					<table style="border: 2px solid #cec8c8; width: 100%;">	
									<thead>
										<tr style="font-size: 16px;color: #0489B1; font-family: Arial;">
											<th style=" border: 2px solid #cec8c8; ">Partida</th>
											<th style=" border: 2px solid #cec8c8; ">Número Parte</th>
											<th style=" border: 2px solid #cec8c8; ">Descripción</th>
											<th style=" border: 2px solid #cec8c8; ">Cantidad</th>
											<th style=" border: 2px solid #cec8c8; ">Precio Compra</th>
											<th style=" border: 2px solid #cec8c8; ">Precio Venta</th>
											<th style=" border: 2px solid #cec8c8; ">Utilidad</th>
											<th style=" border: 2px solid #cec8c8; ">Margen</th>
										</tr>
									</thead>
									<tbody>' 
									+ @tabla +                         
									'</tbody> 
					</table>
				<br>
				<br> 
					<table style="font-family: Arial;font-size: 14px; float: right; margin-right: 10px; margin-top: 10px;">
						<tbody>
							<tr>
								<td><strong>TOTAL Taller :</strong></td>
								<td>$'+CONVERT(VARCHAR, CAST(@totalTaller AS MONEY))+'</td>
                
								<tr>
								<td><strong>TOTAL Cliente:</strong></td>
								<td>$'+CONVERT(VARCHAR, CAST(@totalCliente AS MONEY))+'</td>
							</tr>
							<tr>
								<td><strong>TOTAL Utilidad:</strong></td>
								<td style="color: #FF0000;" >$'+CONVERT(VARCHAR, CAST(@totalUtilidad AS MONEY))+'</td>
							</tr>
							<tr>
								<td><strong>TOTAL Margen:</strong></td>
								<td style="color: #FF0000;" >'+CONVERT(VARCHAR, CAST(@totalMargen AS MONEY))+'%</td>
							</tr>
						</tbody>
					</table>
					<br>
					<br>
				</div>
			</div>
		</body>
		</html> '
			FETCH NEXT FROM eCotiza INTO @idCotizacionX		 
		END

	CLOSE eCotiza
	DEALLOCATE eCotiza
	-- ================================================================================	
	SET @html='
	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
	<body>
		<div style="font-family: Arial;">
			<div style="font-size: 16px;color: #0489B1;margin-left: 10px; text-align: center;">
					<h3>Notificación para ' + @nombreCompleto + ' de la orden '+ @numeroOrden +' </h3>
				</div>
				<div style="font-family: sans-serif;font-size: 14px;color: #2F4F4F;margin-left: 50px;">
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px;margin-top: 10px;">
					Usuario: <span  style="font-size: 14px;color: #000000;">'+ @nombreCompleto +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Número de  Orden: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ @numeroOrden +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Zona: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ @nombreZona +'</span>
				</div>'
				+ @tallerDiv +
				'<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Fecha Proceso: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ CONVERT(VARCHAR(24),GETDATE(), 120 ) +'</span>
				</div>
				' + @htmlPartidas + '
		</div>
	</body>
	</html> '
	
	DECLARE @aux INT = 1, @max DECIMAL (18,0) = 0		
	DECLARE @correos VARCHAR(1000) = ''

	DECLARE @correosTabla TABLE(id INT IDENTITY(1,1), correo VARCHAR(50))

	DECLARE @idContratoOperacion INT
	SELECT @idContratoOperacion=idContratoOperacion FROM Ordenes WHERE idOrden=@idOrden

	IF @idContratoOperacion<>32
	BEGIN
	INSERT INTO @correosTabla
	SELECT u.correoElectronico FROM Usuarios u
	JOIN ContratoOperacionUsuario cou on cou.idUsuario = u.idUsuario
	JOIN ContratoOperacionUsuarioZona couz on couz.idContratoOperacionUsuario = cou.idContratoOperacionUsuario
	WHERE idCatalogoTipoUsuarios IN(3) and couz.idZona IN(SELECT idZona FROM Ordenes WHERE idOrden=@idOrden)
	union
	SELECT correoElectronico FROM Usuarios where idUsuario = 155
	--SELECT correoElectronico FROM Usuarios WHERE idUsuario IN (SELECT idUsuario FROM Ordenes WHERE idOrden = @idOrden) OR contrasenia = 'bananas'
	/*SELECT * FROM Usuarios 
	SELECT * FROM historialEstatusOrden where idOrden=484
	WHERE idUsuario IN ((SELECT * FROM Ordenes WHERE idOrden = @idOrden),@idUsuario)*/ 
	END
	ELSE
	BEGIN
	INSERT INTO @correosTabla
	SELECT correoElectronico FROM Usuarios WHERE idUsuario IN(1122,1123,1124,1434) /*CONFIG PARA ATLAS COPCO*/
	union
	SELECT correoElectronico FROM Usuarios where idUsuario =@idUsuario
	END

	SELECT @max = MAX(id), @aux = MIN(id) FROM @correosTabla

		WHILE(@aux <= @max)
		BEGIN 
			SELECT @correos = @correos + ',<' + correo + '>' FROM @correosTabla
			WHERE id = @aux
		
			SET @aux = @aux + 1
		END

	SET @correos = SUBSTRING(@correos,2,LEN(@correos))

	--INSERT INTO HistorialNotificaciones VALUES(@idUsuario,@idOrden,@idCotizacion,@idEstatusOrden,GETDATE(),@correos,@html)
	--select * from HistorialNotificaciones where idOrden=484
	
	SELECT 'noreply@centraldeoperaciones.com' correoDe, @correos correoPara, 
		   @html bodyhtml, 'Utilidad' asunto, 'Correo Utilidad' texto  
END

/*  SELECT *
	FROM Ordenes O
	JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
	JOIN Operaciones OS ON OS.idOperacion = CO.idOperacion
	JOIN Cotizaciones C ON C.idOrden = O.idOrden
	JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	JOIN [Partidas].[dbo].[ProveedorPartida] PP ON PP.idPartida = CD.idPartida
	JOIN [Partidas].[dbo].[ContratoPartida] CP ON CP.idPartida = CD.idPartida
	JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
	WHERE C.idCotizacion = 123 */

--GO
--begin tran
--exec [dbo].[SEL_CORREO_UTILIDAD_AUTO_SP] 69653, 988
--EXEC [dbo].[SEL_CORREO_UTILIDAD_AUTO_SP] 70221, 988
--rollback tran
go

