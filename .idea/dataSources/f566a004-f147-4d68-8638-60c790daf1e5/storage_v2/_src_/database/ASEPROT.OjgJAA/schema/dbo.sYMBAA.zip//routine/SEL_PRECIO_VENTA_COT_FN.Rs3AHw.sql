-- select [dbo].[SEL_PRECIO_VENTA_COT_FN](2830,3,3,107,2)
CREATE FUNCTION [dbo].[SEL_PRECIO_VENTA_COT_FN](@idCotizacion INT, @idContratoOperacion INT, @tipoConsulta INT, @idUsuario INT, @idRol INT)

RETURNS NUMERIC(18,2)
AS
BEGIN
DECLARE @venta NUMERIC(18,2) = 0
DECLARE @numero TABLE(estatusCotizacion int, estatusPartida int)

IF(@tipoConsulta = 1)
insert @numero values(1, 1)
IF(@tipoConsulta = 2)
insert @numero values(1, 1)
insert @numero values(2, 2)
IF(@tipoConsulta = 3)
insert @numero values(3, 2)
IF(@tipoConsulta = 4)
insert @numero values(2, 1)
insert @numero values(3, 2)

if (@idRol <> 4)
	begin

		SELECT @venta = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			--INNER JOIN [Partidas].[dbo].[Partida] P	ON CD.idPartida = P.idPartida
			--INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
			--INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		WHERE CD.idCotizacion = @idCotizacion 
		--AND CO.idContratoOperacion = @idContratoOperacion
		AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
		AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero)	

	end
	else
		begin
			declare @idOperacion INT = (select idOperacion from ContratoOperacion where idContratoOperacion = @idContratoOperacion)

			declare @tablaProveedoresAsignados table(idProveedor int)
			insert into @tablaProveedoresAsignados
			select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)

			SELECT @venta = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			--INNER JOIN [Partidas].[dbo].[Partida] P	ON CD.idPartida = P.idPartida
			--INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
			--INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
			WHERE CD.idCotizacion = @idCotizacion 
			--AND CO.idContratoOperacion = @idContratoOperacion
			AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
			AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero)	
			AND C.idTaller in (select idProveedor from @tablaProveedoresAsignados)

		end
	
	RETURN @venta
END
/*	SELECT @venta = ISNULL(SUM((ISNULL(CPVenta.venta,0) * ISNULL(_CODE.cantidad,0))),0) 
		FROM [dbo].[Cotizaciones] _COTI 
		INNER JOIN [dbo].[CotizacionDetalle] _CODE ON _COTI.idCotizacion = _CODE.idCotizacion  
		INNER JOIN [Partidas].[dbo].[Partida] _PART	ON _CODE.idPartida = _PART.idPartida
		INNER JOIN [dbo].[Ordenes]	_ORD	  ON _COTI.idOrden = _ORD.idOrden
		INNER JOIN [dbo].[ContratoOperacion] _CONTOP ON _ORD.idContratoOperacion = _CONTOP.idContratoOperacion
		INNER JOIN [Partidas].[dbo].[ContratoProveedor]	_CPRO ON _CPRO.idContrato = _CONTOP.idContrato  AND _COTI.idTaller = _CPRO.idProveedor
		LEFT JOIN [Partidas].[dbo].[Contrato] _CONT	ON _CPRO.idContrato = _CONT.idContrato
		--LEFT JOIN [Partidas].[dbo].[ContratoUnidad]	_CONTUNI  ON _CONTUNI.idContratoUnidad = _CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON _PART.idPartida = CPVenta.idPartida --AND CPVenta.idContratoUnidad = _CONTUNI.idContratoUnidad   
		INNER JOIN [Partidas].[dbo].[Proveedor]	_P		  ON _P.idProveedor = _CPRO.idProveedor
		INNER JOIN [Partidas].[dbo].[ProveedorEspecialidad] _PE ON _PE.idProveedor = _P.idProveedor AND _PE.idEspecialidad = _PART.idEspecialidad
		INNER JOIN .[Partidas].[dbo].[Especialidad]	_ESP ON _ESP.idEspecialidad = _PE.idEspecialidad 
	WHERE _ORD.idOrden = @idOrden 
	AND _CONTOP.idContratoOperacion = @idContratoOperacion
	AND _CODE.idEstatusPartida IN(select estatusPartida from @numero) 
	AND _COTI.idEstatusCotizacion IN(select estatusCotizacion from @numero)	
*/

/*	ISNULL((SELECT SUM( _CONTPART.venta * _CODE.cantidad ) as sumaVenta
		FROM [dbo].[Cotizaciones] _COTI 
		INNER JOIN [dbo].[CotizacionDetalle] _CODE ON _COTI.idCotizacion = _CODE.idCotizacion  
		INNER JOIN [Partidas].[dbo].[Partida] _PART	ON _CODE.idPartida = _PART.idPartida
		INNER JOIN [dbo].[Ordenes] _ORD	ON _COTI.idOrden = _ORD.idOrden
		INNER JOIN [dbo].[ContratoOperacion] _CONTOP ON _ORD.idContratoOperacion = _CONTOP.idContratoOperacion
		INNER JOIN [Partidas].[dbo].[ContratoProveedor]	_CPRO ON _CPRO.idContrato = _CONTOP.idContrato  AND _COTI.idTaller = _CPRO.idProveedor
		LEFT JOIN [Partidas].[dbo].[Contrato] _CONT	ON _CPRO.idContrato = _CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[ContratoUnidad]	_CONTUNI  ON _CONTUNI.idContratoUnidad = _CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[ContratoPartida] _CONTPART ON _PART.idPartida = _CONTPART.idPartida AND _CONTPART.idContratoUnidad = _CONTUNI.idContratoUnidad   
		INNER JOIN [Partidas].[dbo].[Proveedor]	_P ON _P.idProveedor = _CPRO.idProveedor
		INNER JOIN [Partidas].[dbo].[ProveedorEspecialidad] _PE	ON _PE.idProveedor = _P.idProveedor AND _PE.idEspecialidad = _PART.idEspecialidad
		INNER JOIN .[Partidas].[dbo].[Especialidad] _ESP ON _ESP.idEspecialidad = _PE.idEspecialidad
		WHERE _COTI.idEstatusCotizacion IN (3) 
			AND _CODE.idEstatusPartida = 2 AND _CONTOP.idContratoOperacion = @idOperacion
			AND _ORD.idZona = @idZona AND _ORD.idEstatusOrden = @idEstatusOrden), 0.00 )*/



go

