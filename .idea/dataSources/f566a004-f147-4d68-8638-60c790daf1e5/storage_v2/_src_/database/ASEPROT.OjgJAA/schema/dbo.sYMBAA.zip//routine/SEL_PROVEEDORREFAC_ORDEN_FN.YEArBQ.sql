-- =============================================
-- Author: YJH
-- Create date: 2019/02/21
-- SELECT [dbo].[SEL_PROVEEDORREFAC_ORDEN_FN](40327)
-- =============================================
-- Add the parameters for the function here

CREATE FUNCTION [dbo].[SEL_PROVEEDORREFAC_ORDEN_FN](@idOrden INT)

RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @nombreComercial NVARCHAR(MAX) = '- ';
	DECLARE @Result NVARCHAR(MAX) = ' ';

	select top 1 @nombreComercial= P.nombreComercial 
	from RefaccionMultiMarca.Relacion.UnidadSiniestroOrden USO
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = USO.idSiniestro
	inner join REfaccionMultiMarca.Catalogo.Taller T on T.idTaller = S.idTaller
	inner join Partidas.dbo.Proveedor P on P.idProveedor = T.idTallerPartidas
	where USO.orden = @idOrden

	IF((@nombreComercial IS NOT NULL) AND @nombreComercial != '- ')
		SET @Result= @nombreComercial
	else 
	begin 
		select  top 1 @nombreComercial= P.nombreComercial 
		from RefaccionMultiMarca.Relacion.UnidadSiniestroOrden USO
		inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = USO.idSiniestro	
		inner join Partidas.dbo.Proveedor P on P.idProveedor = S.idTaller
		where USO.orden = @idOrden

		IF((@nombreComercial IS NOT NULL) AND @nombreComercial != '')
			SET @Result= @nombreComercial
	end
	

	RETURN @Result;			
	
END
go

