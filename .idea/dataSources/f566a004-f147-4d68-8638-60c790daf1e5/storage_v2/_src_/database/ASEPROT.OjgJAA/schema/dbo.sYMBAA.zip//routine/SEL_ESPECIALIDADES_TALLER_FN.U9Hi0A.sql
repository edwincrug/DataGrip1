-- =============================================
-- Author:		Sahirely Yam
-- Create date: 14/06/2017
-- =============================================
CREATE FUNCTION [dbo].[SEL_ESPECIALIDADES_TALLER_FN] 
(
	@idProveedor numeric(18,0)
)
RETURNS varchar(max)
AS
BEGIN
				DECLARE @result varchar(max) = ''

		DECLARE @especialidad nvarchar(200)
		DECLARE Especialidad_Cursor CURSOR FOR 
		(SELECT especialidad
		FROM [Partidas].dbo.ProveedorEspecialidad AS PE 
		INNER JOIN [Partidas].dbo.Especialidad AS E ON PE.idEspecialidad = E.idEspecialidad
		WHERE PE.idProveedor = @idProveedor)

		OPEN Especialidad_Cursor

		FETCH NEXT FROM Especialidad_Cursor INTO @especialidad
		WHILE @@FETCH_STATUS = 0
		BEGIN			
			SET @result += ' ' + @especialidad
			FETCH NEXT FROM Especialidad_Cursor INTO @especialidad
			if (@@FETCH_STATUS = 0)
			begin
				SET @result += ', '
			end
		END
		
		close Especialidad_Cursor
		DEALLOCATE Especialidad_Cursor

	RETURN @result

END
go

