-- ==========================================================================================
-- CREAT AUTH:  Jordan Gómez
-- CREAT DATE:  03/10/2017
-- CREAT DESC:  Store solo para toluca
-- ==========================================================================================
/*
SELECT * FROM [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERenc]
SELECT * FROM [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERdet]
select * from Cotizaciones where numeroCotizacion='01-3110073-126-2'
[INS_ORDEN_DETALLE_TOLUCA_SP] 413610,7359,1,37,1
*/
CREATE PROCEDURE [dbo].[INS_ORDEN_DETALLE_TOLUCA_SP]
    @idCotizacion NUMERIC(18,0) = 0,
    @idEncabezado NUMERIC(18,0) = 0,    
    @tipoDetalle SMALLINT = 1,-- 1: servicio, 2: refacciones
    @idOperacion NUMERIC(18,0),
    @isProduction NUMERIC(18,0)
AS
BEGIN   
DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE @query NVARCHAR(MAX)
DECLARE @queryUpdatePrecios NVARCHAR(MAX)
DECLARE @queryInsertDet NVARCHAR(MAX)
DECLARE @queryCreatTableSumetorias NVARCHAR(MAX)
DECLARE @queryInsertSumetorias NVARCHAR(MAX)
DECLARE @queryUpdateEnc NVARCHAR(MAX)
DECLARE @queryDropSumatorias NVARCHAR(MAX)
DECLARE @orden NVARCHAR(MAX)
DECLARE @queryupdateEncLet NVARCHAR(MAX)
DECLARE @queryupdateEncTot NVARCHAR(MAX)
DECLARE @totalOrdenes NUMERIC(18,0)
DECLARE @totalMano NUMERIC(18,0)
DECLARE @totalRefacciones NUMERIC(18,0)
DECLARE @totalLubricantes NUMERIC(18,0)
DECLARE @tablaValor TABLE (ORD NVARCHAR(MAX))
DECLARE @valorOrden NVARCHAR(MAX)
DECLARE @idContratoOperacion VARCHAR(5)
DECLARE @actualizaObs NVARCHAR(MAX)
DECLARE @idContratoUnidad NUMERIC(18,0)
DECLARE @queryCreatTableFamilia NVARCHAR(MAX)

SELECT @idContratoOperacion=idContratoOperacion FROM ContratoOperacion WHERE idOperacion=@idOperacion

SELECT 			
@idContratoUnidad = PCU.idContratoUnidad
FROM Cotizaciones C
	INNER JOIN Ordenes O ON O.idOrden = C.idOrden
	INNER JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
	INNER JOIN Partidas..Contrato PC ON PC.idContrato = CO.idContrato
	INNER JOIN Unidades U ON U.idUnidad = O.idUnidad
	INNER JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
	INNER JOIN Partidas..ContratoUnidad PCU ON PCU.idUnidad = PU.idUnidad AND PCU.idContrato = PC.idContrato
WHERE idCotizacion = @idCotizacion AND CO.idOperacion = @idOperacion

IF(@isProduction = 1)
    BEGIN
        SELECT 
                @server=SERVER,
                @db=DBProduccion
        FROM ContratoOperacionFacturacion 
        WHERE idContratoOperacion=@idContratoOperacion
    END
ELSE
    BEGIN
        SELECT 
                @server=SERVER,
                @db=DB
        FROM ContratoOperacionFacturacion 
        WHERE idContratoOperacion=@idContratoOperacion
    END
    IF(@tipoDetalle = 1) -- SERVICIO
        BEGIN
			IF(@idOperacion = 37)
				BEGIN
				IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE  TABLE_NAME = 'TABLAFAMILIA'))
				BEGIN
					DROP TABLE TABLAFAMILIA
				END

					SET @queryCreatTableFamilia = 'CREATE TABLE TABLAFAMILIA(
						IdOrden  numeric(18,0),
						Descripcion nvarchar(max),
						Cantidad nvarchar(max),
						PrecioUnitarioCompra nvarchar(max),
						SubtotalUnitario nvarchar(max),
						IvaUnitario nvarchar(max),
						TotalUnitario nvarchar(max),
						PrecioVenta nvarchar(max),
						FechaOpe nvarchar(10),
						HoraOpe nvarchar(10),
						IdPartida numeric(18,0),
						SUM_MO decimal(18,2),
						SUM_REF decimal(18,2),
						SUM_LUB decimal(18,2),
						OTD_TIPMTO VARCHAR(10),
						Familia nvarchar(2)
						)'
			
					EXECUTE SP_EXECUTESQL @queryCreatTableFamilia
					--Mano de obra preventivo
					SET @query = 'insert into TABLAFAMILIA
					SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO MANO DE OBRA PREVENTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.precioMano AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   cp.precioMano,
						   0 precioRefaccion,
						   0 precioLubricante,
						   ''PR'', --OTD_TIPMTO 
						   6
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad = 11 AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.precioMano is not null and cp.precioMano > 0
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.precioMano, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							SET @query = ''
							--Mano de obra CORRECTIVO
					SET @query = 'insert into TABLAFAMILIA
					SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO MANO DE OBRA CORRECTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.precioMano AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   cp.precioMano,
						   0 precioRefaccion,
						   0 precioLubricante,
						   ''CO'', --OTD_TIPMTO 
						   6
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad NOT IN (11) AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.precioMano is not null and cp.precioMano > 0
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.precioMano, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							--refacciones PREVENTIVO
							SET @query = ''
							SET @query = 'insert into TABLAFAMILIA
							SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO REFACCIONES PREVENTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.precioRefaccion AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   0 precioMano,
						   cp.precioRefaccion,
						   0 precioLubricante,
						   ''PR'', --OTD_TIPMTO
						   3
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad = 11 AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.precioRefaccion is not null and cp.precioRefaccion > 0
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.precioRefaccion, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							--refacciones CORRECTIVO
							SET @query = ''
							SET @query = 'insert into TABLAFAMILIA
							SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO REFACCIONES CORRECTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.precioRefaccion AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   0 precioMano,
						   cp.precioRefaccion,
						   0 precioLubricante,
						   ''CO'', --OTD_TIPMTO
						   3
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad NOT IN(11) AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.precioRefaccion is not null and cp.precioRefaccion > 0
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.precioRefaccion, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							--lubricantes PREVENTIVO
							SET @query = ''
							SET @query = 'insert into TABLAFAMILIA
							SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO LUBRICANTES PREVENTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.precioLubricante AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   0 precioMano,
						   0 precioRefaccion,
						   cp.precioLubricante,
						   ''PR'', --OTD_TIPMTO
						   5
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad = 11 AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.precioLubricante is not null and cp.precioLubricante > 0
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.precioLubricante, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							--lubricantes CORRECTIVO
							SET @query = ''
							SET @query = 'insert into TABLAFAMILIA
							SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO LUBRICANTES CORRECTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.precioLubricante AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   0 precioMano,
						   0 precioRefaccion,
						   cp.precioLubricante,
						   ''CO'', --OTD_TIPMTO
						   5
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad NOT IN (11) AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.precioLubricante is not null and cp.precioLubricante > 0
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.precioLubricante, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							--HYP PREVENTIVO
							SET @query = ''
							SET @query = 'insert into TABLAFAMILIA
							SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO H. Y P. PREVENTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.preciohojalateria AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   0 precioMano,
						   0 precioRefaccion,
						   cp.preciohojalateria,
						   ''PR'', --OTD_TIPMTO
						   1
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad = 11 AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.preciohojalateria is not null and cp.preciohojalateria > 0 
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.preciohojalateria, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							--HYP CORRECTIVO
							SET @query = ''
							SET @query = 'insert into TABLAFAMILIA
							SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO H. Y P. CORRECTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.preciohojalateria AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   0 precioMano,
						   0 precioRefaccion,
						   cp.preciohojalateria,
						   ''CO'', --OTD_TIPMTO
						   1
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad NOT IN (11) AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.preciohojalateria is not null and cp.preciohojalateria > 0 
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.preciohojalateria, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							--llantas PREVENTIVO
							SET @query = ''
							SET @query = 'insert into TABLAFAMILIA
							SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO LLANTAS PREVENTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.precioLlanta AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   0 precioMano,
						   0 precioRefaccion,
						   cp.precioLlanta,
						   ''PR'', --OTD_TIPMTO
						   4
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad = 11 AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.precioLlanta is not null and cp.precioLlanta > 0
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.precioLlanta, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							--llantas CORRECTIVO
							SET @query = ''
							SET @query = 'insert into TABLAFAMILIA
							SELECT                 
						   --ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   o.idOrden,
						   ''FACTURACION SISCO LLANTAS CORRECTIVO'', --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(cp.precioLlanta AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108),
						   p.idPartida,
						   0 precioMano,
						   0 precioRefaccion,
						   cp.precioLlanta,
						   ''CO'', --OTD_TIPMTO
						   4
						FROM Ordenes O
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN PARTIDAS..CONTRATO PC ON PC.IDCONTRATO = CO.IDCONTRATO
							JOIN Unidades U ON O.idUnidad = U.idUnidad
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							JOIN Partidas..ContratoUnidad cu on cu.idContrato = co.idContrato and cu.idUnidad = u.idTipoUnidad
							JOIN Partidas..ContratoPartida cp on cp.idContratoUnidad = cu.idContratoUnidad and cp.idPartida = cd.idPartida
							WHERE P.idEspecialidad NOT IN(11) AND C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3) and cp.precioLlanta is not null and cp.precioLlanta > 0
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida,
							cp.precioLlanta, p.idPartida'
							EXECUTE SP_EXECUTESQL @query
							--print @query
							SET @query = ''
							SET @query = 'INSERT INTO'+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET](
							[OTD_IDENT],
							[OTD_CONSECUTIVO],
							[OTD_DESCRIPCION],
							[OTD_CANTIDAD],
							[OTD_PRECIOUNITARIOCOMPRA],
							[OTD_SUBTOTALUNITARIO],
							[OTD_IVAUNITARIO],
							[OTD_TOTALUNITARIO],
							[OTD_PRECIOUNITARIOVENTA],
							[OTD_FECHOPE],
							[OTD_HORAOPE],
							[OTD_IDPARTIDA],
							[OTD_MO],
							[OTD_REF],
							[OTD_LUB],
							[OTD_FAMILIA],
							[OTD_TIPMTO])
					SELECT                 
						   '+CAST(@idEncabezado AS NVARCHAR(30))+',
						   ROW_NUMBER() OVER(ORDER BY idOrden DESC) AS Row,
						   descripcion, --OTD_DESCRIPCION
						   cantidad, --OSD_CANTIDAD                  
						   CONVERT(NVARCHAR(MAX),CONVERT(decimal(18,2), PrecioUnitarioCompra) / DIV.dividir), --OTD_PRECIOUNITARIOCOMPRA
						   CONVERT(NVARCHAR(MAX),CONVERT(decimal(18,2), SubtotalUnitario) / DIV.dividir), --OTD_SUBTOTALUNITARIO
						   CONVERT(NVARCHAR(MAX),CONVERT(decimal(18,2), IvaUnitario) / DIV.dividir), --OTD_IVAUNITARIO
						   CONVERT(NVARCHAR(MAX),CONVERT(decimal(18,2), TotalUnitario) / DIV.dividir), --OTD_TOTALUNITARIO
						   PrecioVenta,--OTD_PRECIOUNITARIOVENTA
						   FechaOpe, --fecha de la base
						   HoraOpe, --hora de la base
						   T.IdPartida,
						   SUM_MO,
						   SUM_REF,
						   SUM_LUB,
						   Familia,
						   OTD_TIPMTO
						FROM TABLAFAMILIA T 
						INNER JOIN (select COUNT(IdPartida) dividir, IdPartida from TABLAFAMILIA group by IdPartida) DIV ON DIV.IdPartida = T.IdPartida '
				END
			ELSE
				BEGIN
					SET @query = 'INSERT INTO'+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET](
							[OTD_IDENT],
							[OTD_CONSECUTIVO],
							[OTD_DESCRIPCION],
							[OTD_CANTIDAD],
							[OTD_PRECIOUNITARIOCOMPRA],
							[OTD_SUBTOTALUNITARIO],
							[OTD_IVAUNITARIO],
							[OTD_TOTALUNITARIO],
							[OTD_PRECIOUNITARIOVENTA],
							[OTD_FECHOPE],
							[OTD_HORAOPE],
							[OTD_FAMILIA])
					SELECT                 
						   '+CAST(@idEncabezado AS NVARCHAR(30))+',
						   ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
						   P.descripcion, --OTD_DESCRIPCION
						   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD                  
						   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
						   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
						   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
						   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
						   CAST(CD.venta AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
						   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
						   CONVERT(VARCHAR(8),GETDATE(),108), --hora de la base
						   ''''
						FROM Ordenes O
							JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
							JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
							JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
							WHERE C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)
							GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida'
							
				END
        
			--print @query
			EXECUTE SP_EXECUTESQL @query
			DROP TABLE TABLAFAMILIA

            IF(@idOperacion <> 37)
			BEGIN
				SET @queryUpdatePrecios = 'UPDATE osdet

            SET
            osdet.OTD_PRECIOUNITARIOVENTA = cpa.venta
            ,osdet.OTD_IDPARTIDA = par.idPartida
            ,osdet.OTD_MO = cpa.precioMano
            ,osdet.OTD_REF = cpa.precioRefaccion
            ,osdet.OTD_LUB = cpa.precioLubricante
            FROM ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET] osdet
            INNER JOIN ' + @server + '.' + @db + '.dbo.[ADE_ORDSERENC] osenc ON osenc.OTE_IDENT = osdet.OTD_IDENT
            INNER JOIN Cotizaciones coti ON coti.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+'
            INNER JOIN CotizacionDetalle cdet ON cdet.idCotizacion = coti.idCotizacion
            INNER JOIN Partidas.dbo.Partida par ON par.idPartida = cdet.idPartida AND osdet.OTD_DESCRIPCION collate MODERN_SPANISH_CI_AS = par.descripcion collate MODERN_SPANISH_CI_AS
            INNER JOIN Partidas.dbo.ContratoPartida cpa ON cpa.idPartida = par.idPartida AND cpa.idContratoUnidad = '+CAST(@idContratoUnidad AS NVARCHAR(30))+'
            WHERE osdet.OTD_IDENT = '+CAST(@idEncabezado AS NVARCHAR(30))+' '
			
            EXECUTE SP_EXECUTESQL @queryUpdatePrecios
			END

			SET @orden = 'SELECT OTE_ORDENGLOBAL FROM ' + @server + '.' + @db + '.dbo.[ADE_ORDSERENC] WHERE OTE_IDENT = '+ CAST(@idEncabezado AS nvarchar(MAX))+''
			INSERT INTO @tablaValor
			EXECUTE SP_EXECUTESQL @orden
			
			SELECT @valorOrden = ORD FROM @tablaValor

			IF(@idOperacion = 1)
			BEGIN
				SET @actualizaObs = 'UPDATE ' + @server + '.' + @db + '.dbo.[ADE_ORDSERENC]
				SET OTE_OBSERVACIONES = '' ORDEN: ' + @valorOrden + '''+ '' ECO:' +  substring(@valorOrden,4,7) + '''
				WHERE OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '';

				EXECUTE SP_EXECUTESQL @actualizaObs
			END
			
   --         SET @queryInsertDet = 'INSERT INTO ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET]
			--SELECT 
			--E.OTE_IDENT,
			--MAX(D.OTD_CONSECUTIVO) + 1,
			--+ '' ORDEN: '' + Cast(E.OTE_ORDENANDRADE as nvarchar(max)) + '' ECO: '' + substring(E.OTE_ORDENANDRADE,4,7),
			--1,
   --         0,
   --         0,
   --         0,
   --         0,
   --         0,
			--CONVERT(VARCHAR,GETDATE(),103),
			--CONVERT(VARCHAR,GETDATE(),108),
   --         NULL,0,0,0,0 
   --         FROM ' + @server + '.' + @db + '.dbo.[ADE_ORDSERENC] E
   --         inner join ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET] D on E.OTE_IDENT = D.OTD_IDENT
   --         WHERE D.OTD_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '
   --         GROUP BY E.OTE_IDENT,E.OTE_ORDENANDRADE'
			
   --         EXECUTE SP_EXECUTESQL @queryInsertDet

				IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE  TABLE_NAME = 'sumatoriasTemporal'))
				BEGIN
					DROP TABLE sumatoriasTemporal
				END

            SET @queryCreatTableSumetorias = 'CREATE TABLE sumatoriasTemporal(
                OTD_IDENT  numeric(18,0)
                ,SUM_MO decimal(18,2)
                ,SUM_REF decimal(18,2)
                ,SUM_LUB decimal(18,2))'
			
            EXECUTE SP_EXECUTESQL @queryCreatTableSumetorias
            
            SET @queryInsertSumetorias = 'INSERT INTO  sumatoriasTemporal
            SELECT 
            OTD_IDENT
            ,SUM(OTD_CANTIDAD*OTD_MO)
            ,SUM(OTD_CANTIDAD*OTD_REF)
            ,SUM(OTD_CANTIDAD*OTD_LUB)
            FROM ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET] 
            GROUP BY OTD_IDENT'
			
            EXECUTE SP_EXECUTESQL @queryInsertSumetorias
            
            SET @queryUpdateEnc = 'UPDATE osenc
            SET
             osenc.OTE_SUBMO = SUM_MO
            ,osenc.OTE_SUBREF = SUM_REF
            ,osenc.OTE_SUBLUB = SUM_LUB
            FROM '+@server+'.'+@db+'.dbo.[ADE_ORDSERENC] osenc
            INNER JOIN sumatoriasTemporal suma ON osenc.OTE_IDENT = suma.OTD_IDENT
            WHERE osenc.OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30))
			
            EXECUTE SP_EXECUTESQL @queryUpdateEnc
            
            DROP TABLE sumatoriasTemporal
            
            SET @queryupdateEncLet = 'UPDATE B
                SET B.OTE_DESGLOSE = ''A''
                FROM '+@server+'.'+@db+'.dbo.ADE_ORDSERENC B
                INNER JOIN 
                (SELECT OTE_ORDENGLOBAL, 
                CASE
                     WHEN count(OTE_ORDENGLOBAL) > 1 THEN 
                         1 END S 
                FROM '+@server+'.'+@db+'.dbo.ADE_ORDSERenc group by OTE_ORDENGLOBAL) A ON A.S is not null AND A.OTE_ORDENGLOBAL = ' + ''''+@valorOrden+''''
            
            EXECUTE SP_EXECUTESQL @queryupdateEncLet
            
            SET @queryupdateEncTot = 'UPDATE  ENC
                SET 
                ENC.OTE_SUBMO = OK.MANO,
                ENC.OTE_SUBREF = OK.REFA,
                ENC.OTE_SUBLUB = OK.LUB
                FROM '+@server+'.'+@db+'.dbo.ADE_ORDSERENC ENC
                INNER JOIN (
                SELECT SUM(B.OTE_SUBMO) MANO,
                SUM(B.OTE_SUBREF) REFA, 
                SUM(B.OTE_SUBLUB) LUB,
                B.OTE_ORDENGLOBAL
                FROM '+@server+'.'+@db+'.dbo.ADE_ORDSERENC B
                INNER JOIN 
                (SELECT OTE_ORDENGLOBAL, 
                CASE
                     WHEN count(OTE_ORDENGLOBAL) > 1 THEN 
                         1 END S 
                FROM '+@server+'.'+@db+'.dbo.ADE_ORDSERENC group by OTE_ORDENGLOBAL) A ON A.OTE_ORDENGLOBAL = B.OTE_ORDENGLOBAL AND A.S is not null
                WHERE B.OTE_ORDENGLOBAL = '+ ''''+@valorOrden+'''' +'
				group by B.OTE_ORDENGLOBAL 
                ) OK ON OK.OTE_ORDENGLOBAL = ENC.OTE_ORDENGLOBAL'
            
            EXECUTE SP_EXECUTESQL @queryupdateEncTot
            
        END
END
go

grant execute, view definition on INS_ORDEN_DETALLE_TOLUCA_SP to DevOps
go

