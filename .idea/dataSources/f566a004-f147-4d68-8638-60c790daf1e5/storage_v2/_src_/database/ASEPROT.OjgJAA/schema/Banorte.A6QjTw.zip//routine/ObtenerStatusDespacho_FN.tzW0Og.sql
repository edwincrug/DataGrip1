
-- =============================================
-- Author: Christian Ochoa Nicolas
-- Modfica: YJH 20/09/18
-- Create date: 04-07-2018
-- Description: Obtener el status de despacho
-- [Banorte].[ObtenerStatusDespacho_FNV2] 53718
-- =============================================
CREATE PROCEDURE [Banorte].[ObtenerStatusDespacho_FN] 
	@idOrden INT,	 
	@xmlPedidoRef XML,
	@Entregado NUMERIC output
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY	

		DECLARE @pre_pedidoref as table (pre_idpedidoref int, pre_idcotizacion nvarchar(100), pre_pedidobpro nvarchar(100),
		spe_idsituacionpedido int)

		DECLARE @proveedor INT = (select top 1 idSucursal from  RefaccionMultimarca.operacion.cotizacion C 
		INNER JOIN RefaccionMultimarca.relacion.siniestroordencotizacion RS ON RS.idCotizacion = C.idCotizacion
		inner join Cotizaciones AC on AC.idCotizacion = RS.idCotizacionSISCO 
		where RS.idOrden = @idOrden and AC.idEstatusCotizacion = 3)

		DECLARE @esSurtido int =0
		select @esSurtido=S.esSurtido from 
		RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC
		inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
		where SOC.idOrden = @idOrden


		IF(@proveedor in(1,2,14) or @esSurtido=0)
		BEGIN
				SELECT         
				@Entregado=CAST(1 AS BIT)
				FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC
				WHERE SOC.idOrden = @idOrden 
		END
	ELSE
		BEGIN
			insert into @pre_pedidoref							  				 				  			
				SELECT pre_idpedidoref, pre_idcotizacion, pre_pedidobpro, spe_idsituacionpedido
				FROM (  
					SELECT x.y.value('pre_idpedidoref[1]', 'int') as pre_idpedidoref
					, x.y.value('pre_idcotizacion[1]', 'nvarchar(100)') as pre_idcotizacion
					, x.y.value('pre_pedidobpro[1]', 'nvarchar(100)') as pre_pedidobpro
					, x.y.value('spe_idsituacionpedido[1]', 'int') as spe_idsituacionpedido
					FROM @xmlPedidoRef.nodes('pedidos/pedido') x(y)     
				) x
			
			SELECT         
				@Entregado=CAST(MIN(CASE WHEN PedEnt.tipoEntrega = 3 or PedEnt.tipoEntrega = 4 THEN 1 ELSE 0 END)as BIT)
				FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC
				inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
				inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
				INNER JOIN @pre_pedidoref PR ON SOC.idCotizacion = PR.pre_idcotizacion
				LEFT JOIN PortalDespacho.dbo.PedidoEntrega PedEnt ON PR.pre_pedidobpro = PedEnt.pre_pedidobpro and PedEnt.idMarca = U.marca
				WHERE SOC.idOrden = @idOrden and PR.spe_idsituacionpedido not in (6, 1)
		END
		return @Entregado
	END TRY
	BEGIN CATCH
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END



go

grant execute, view definition on Banorte.ObtenerStatusDespacho_FN to DevOps
go

