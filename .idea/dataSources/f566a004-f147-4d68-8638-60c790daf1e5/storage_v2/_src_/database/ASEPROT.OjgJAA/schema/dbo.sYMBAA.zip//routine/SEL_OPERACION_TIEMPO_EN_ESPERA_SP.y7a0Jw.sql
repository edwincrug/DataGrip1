-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 18/05/2017
-- Description:	Inserta la relacion de operacion con el contrato de la licitación
-- INS_CONTRATO_OPERACION_SP 3, 1
-- =============================================
 create PROCEDURE [dbo].[SEL_OPERACION_TIEMPO_EN_ESPERA_SP]
	 @idOperacion int

AS
BEGIN

	SELECT * FROM OperacionTiempoEnEspera
	WHERE idOperacion=@idOperacion 

END


go

