
-- DROP VIEW [cobranza].[VwStatusCotizacionBaseCollateCA]
-- SELECT * from [cobranza].[VwStatusCotizacionBaseCollateCA]
-- RECORDS  32,834    TIME 6:28
CrEate VIEW [cobranza].[VwStatusCotizacionBaseCollateCA]
AS
SELECT 
         VwCPI.[idCotizacion]     
        ,VwCPI.[numFactura] 
	    ,VwIPS.[CCP_IDDOCTO] as [NumFacturaF]
			 
	    ,CASE WHEN (VwIPS.[SALDO]) < 0.01
	          THEN NULL
	          ELSE (VwIPS.[SALDO])
	     END AS [DeudaDia]
		    
  FROM [cobranza].[VwCotizacionProvInvoiceDef] VwCPI

  INNER JOIN [cobranza].[InvoiceProvSaldoBPRO_GAAutoExpressC] VwIPS 
          ON VwIPS.[CCP_IDPERSONA] = VwCPI.[idProveedor]  
         AND VwIPS.[CCP_IDDOCTO] = VwCPI.[numFactura]  --COLLATE Modern_Spanish_CI_AS

go

