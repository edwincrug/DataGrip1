CREATE FUNCTION [dbo].[fnFactorIVA_Orden](@idOrden INT,@aux int)

RETURNS DECIMAL(18,2)
AS
BEGIN

DECLARE @idFacturaCotizacion INT,@factorIVA DECIMAL(18,2) = 0.16,@fechaCreacionOrden DATETIME,@idContratoOperacion INT

SELECT TOP(1)
@idFacturaCotizacion = FC.idFacturaCotizacion,
@fechaCreacionOrden = fechaCreacionOden,
@idContratoOperacion=idContratoOperacion 
FROM Ordenes O
INNER JOIN Cotizaciones C ON C.idOrden = O.idOrden 
INNER JOIN FacturaCotizacion FC ON FC.idCotizacion = C.idCotizacion
where O.idOrden=@idOrden

IF @idFacturaCotizacion IS NOT NULL
BEGIN
SELECT @factorIVA = ISNULL(tasaIVA,.16) FROM FacturaCotizacion l
WHERE idFacturaCotizacion=@idFacturaCotizacion

END
ELSE
BEGIN
SET @factorIVA = 0.16
END

IF @factorIVA=0 OR @idContratoOperacion=26 BEGIN SET @factorIVA=0.16 END

IF @aux = 1
BEGIN
SET @factorIVA = @factorIVA + 1
END

RETURN @factorIVA
END
go

