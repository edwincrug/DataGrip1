CREATE proc [dbo].[APP_MI_AUTO_GET_DOCUMENTACION]
@idUnidad int=0
as
begin
  DECLARE	@placas varchar(max)='',-- 13
			@tarjetaDeCirculacion varchar(max)='',-- 19
			@PólizaDeSeguros varchar(max)='',--23
			@PagoVerificación varchar(max)='',-- 22
			@Tenencia varchar(max)='',--31
			@Verificación varchar(max)='',--36
			@vin varchar(max)='',
			@extencion varchar(max)='',
			@fechaActual datetime,

			@fechaVigenciaPólizaSeguro datetime,
			@fechaVigenciaTenencia datetime,
			@fechaVerificación datetime,
			@url varchar(255) = ''
  Set dateformat DMY;
	
  set @vin=(select vin from Unidades where idUnidad=@idUnidad)
  set @fechaActual=(SELECT getDate())
  SET @url = (SELECT valor FROM ASEPROT.Mobile.Catalogo WHERE idCatalogo = 3)

  IF EXISTS (select idDocumento from Flotillas..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=13)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,13)
     set @placas=CASE WHEN (@extencion = '' OR @extencion IS NULL) THEN NULL
	        	ELSE @url + @vin+'/'+@extencion
	      	END;
  END
  IF EXISTS (select idDocumento from Flotillas..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=19)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,19)
     set @tarjetaDeCirculacion=CASE WHEN (@extencion = '' OR @extencion IS NULL) THEN NULL
	        	ELSE @url + @vin+'/'+@extencion
	      	END;
  END
  IF EXISTS (select idDocumento from Flotillas..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=23)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,23)
     set @PólizaDeSeguros=CASE WHEN (@extencion = '' OR @extencion IS NULL) THEN NULL
	        	ELSE @url + @vin+'/'+@extencion
	      	END;   
  END
  IF EXISTS (select idDocumento from Flotillas..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=22)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,22)
     set @PagoVerificación=CASE WHEN (@extencion = '' OR @extencion IS NULL) THEN NULL
	        	ELSE @url + @vin+'/'+@extencion
	      	END;
  END
  IF EXISTS (select idDocumento from Flotillas..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=31)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,31)
     set @Tenencia=CASE WHEN (@extencion = '' OR @extencion IS NULL) THEN NULL
	        	ELSE @url + @vin+'/'+@extencion
	      	END;
  END
  IF EXISTS (select idDocumento from Flotillas..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=36)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,36)
     set @Verificación=CASE WHEN (@extencion = '' OR @extencion IS NULL) THEN NULL
	        	ELSE @url + @vin+'/'+@extencion
	      	END;
  END

   /* Cambio a nueva forma de docuemtntos */
	declare @imgs table(
		vin varchar(max),
		idDocumento int, 
		valor varchar(max),
		consecutivo int,
		nombre varchar(max),
		descripcion	varchar(max),
		tipo varchar(max),
		ruta varchar(max),
		FechaLimite	datetime,
		Estructura varchar(max)
	);

	declare	@IdOpe int, @NoEco varchar(max);

	select @IdOpe = idOperacion, @NoEco = numeroEconomico from unidades
	where idUnidad = @IdUnidad
	;


	begin try
	
	insert into @imgs
	exec SEL_DOCUMENTOS_UNIDAD_SP @NoEco,@IdOpe;

	select @fechaVerificación= FechaLimite from @imgs where idDocumento=22; --Verificación
	select @fechaVigenciaPólizaSeguro=FechaLimite from @imgs where idDocumento=23; --Póliza de Seguro 
	select @fechaVigenciaTenencia=FechaLimite from @imgs where idDocumento=31; --tenencia
	end try
	begin catch
	end catch

  Declare	@fechaVigenciaPólizaSeguroVencida int=0,
			@fechaVerificaciónVencida int=0,
			@fechaVigenciaTenenciaVencida int=0,
			@multas int = 0;
		;
  
  SET @multas = (
		SELECT COUNT ([CConIdContribucion])
		FROM [Flotillas]..[Contribuciones_Datos] as c
		INNER JOIN Unidades as u on u.vin = c.CConVIN
		WHERE u.idUnidad = @idUnidad
		AND [CConIdTipoPago] = 3
	);


  if(@fechaVigenciaPólizaSeguro <=@fechaActual) set @fechaVigenciaPólizaSeguroVencida=1;
  if(@fechaVerificación <=@fechaActual) set @fechaVerificaciónVencida=1;
  if(@fechaVigenciaTenencia <=@fechaActual) set @fechaVigenciaTenenciaVencida=1;

  select @placas as placas,
         @tarjetaDeCirculacion as tarjetaDeCirculacion,
		 @PólizaDeSeguros as PolizaDeSeguros,
		 @PagoVerificación as PagoVerificacion,
		 @Tenencia as Tenencia,
		 @Verificación as Verificacion,
		
		 /*fecha Vigencia Póliza Seguro*/
		 @fechaVigenciaPólizaSeguro as fechaVigenciaPolizaSeguro,
		 @fechaVigenciaPólizaSeguroVencida as fechaVigenciaPolizaSeguroVencida,
		 /*fecha Verificación*/
		 @fechaVerificación as fechaVerificacion,
		 @fechaVerificaciónVencida as fechaVerificacionVencida,
		 /*fecha Vigencia Tenencia*/
		 @fechaVigenciaTenencia as fechaVigenciaTenencia,
		 @fechaVigenciaTenenciaVencida as fechaVigenciaTenenciaVencida,
		 @fechaActual as fechaActual,
		 @multas as multas
end
go

