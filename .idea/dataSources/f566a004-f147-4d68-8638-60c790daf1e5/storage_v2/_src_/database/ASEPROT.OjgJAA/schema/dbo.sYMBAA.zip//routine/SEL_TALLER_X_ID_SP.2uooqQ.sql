-- =============================================
-- Busca taller con idTaller
-- =============================================
--[SEL_TALLER_X_ID_SP] @idTaller=1
CREATE PROCEDURE [dbo].[SEL_TALLER_X_ID_SP] 
	@idTaller NUMERIC(18,0)
AS
BEGIN
	SELECT	idProveedor AS idProveedor
			,nombreComercial
			,razonSocial
			,direccion
	FROM	[Partidas].[dbo].[Proveedor]
	WHERE   idProveedor = @idTaller
END
go

