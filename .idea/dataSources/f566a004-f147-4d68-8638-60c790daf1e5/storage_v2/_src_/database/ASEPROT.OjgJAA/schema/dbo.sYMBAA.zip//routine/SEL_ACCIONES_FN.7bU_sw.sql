-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION  [dbo].[SEL_ACCIONES_FN] (
	@idOrden numeric(18,0)
)
RETURNS nvarchar(max)
AS
BEGIN

	DECLARE @result nvarchar(max)
		SET @result = ''
		
		IF EXISTS(SELECT 1 FROM Acciones WHERE idOrden=@idOrden)
			BEGIN
				SELECT TOP 1 @result = texto 
				FROM Acciones 
				WHERE idOrden=@idOrden
				ORDER BY idAccion DESC 
			END 
		ELSE
			BEGIN
				SET @result = 'Sin Plan de Acción'
			END

	return @result

END
go

