




CREATE VIEW [report].[VwCostoCotizacion]
AS

    SELECT 
	O.idOrden, 
	C.idCotizacion,
	C.NumeroCotizacion,
	ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) costo
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			--INNER JOIN [Partidas].[dbo].[Partida] P	ON CD.idPartida = P.idPartida
			INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
			INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		WHERE 
		--C.numerocotizacion = '57-PMX09540-13670-2' and
		--AND CO.idContratoOperacion = @idContratoOperacion
		--AND 
		CD.idEstatusPartida IN(2) 
		AND C.idEstatusCotizacion IN(3)	
		group by O.idOrden, C.idCotizacion,C.NumeroCotizacion
go

