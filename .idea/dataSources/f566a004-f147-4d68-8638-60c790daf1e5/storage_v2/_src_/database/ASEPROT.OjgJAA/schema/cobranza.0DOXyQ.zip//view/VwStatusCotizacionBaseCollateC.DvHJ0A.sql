



CREATE VIEW [cobranza].[VwStatusCotizacionBaseCollateC]
AS
SELECT 
      -- DISTINCT
      -- VwCPI.[numeroCotizacion]
      VwCPI.[idCotizacion]
     -- ,VwCPI.[OTE_IDPROVEEDOR]
     ,VwCPI.[numFactura] 
	 ,VwIPS.[NumFactura] as [NumFacturaF]
	 -- ,VwIPS.[idProveedor]
	  ,CASE WHEN (VwIPS.[DeudaDia]) < 0.01
	   THEN NULL
	   ELSE (VwIPS.[DeudaDia])
	   END AS [DeudaDia]

  FROM [cobranza].[VwCotizacionProvInvoiceDef] VwCPI

--INNER JOIN [cobranza].[InvoiceProvSaldoDiaDef] VwIPS
INNER JOIN [cobranza].[VwInvoiceProvSaldoDiaBase] VwIPS
        ON VwIPS.[NumFactura] = VwCPI.[numFactura]  COLLATE Modern_Spanish_CI_AS
       AND VwIPS.[idCotizacion] = VwCPI.[idCotizacion] 

--WHERE VwIPS.[idProveedor] = VwCPI.[OTE_IDPROVEEDOR]

---group by VwCPI.[idCotizacion]

--order by idCoTizacion, NumFactura

go

