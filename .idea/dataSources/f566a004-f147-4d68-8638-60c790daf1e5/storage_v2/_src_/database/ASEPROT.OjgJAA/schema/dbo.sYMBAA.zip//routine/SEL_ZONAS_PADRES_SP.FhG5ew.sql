
--SEL_ZONAS_PADRES_SP 17

CREATE procedure [dbo].[SEL_ZONAS_PADRES_SP] (
	@IdZona INT
)
as
begin

DECLARE @IdPadre int
DECLARE @VariableTabla TABLE ( ID INT IDENTITY(1,1),
								idPadre int, 
								nombreNivel   	    nvarchar(150),
								nombre	        nvarchar(150)
								  )
INSERT INTO @VariableTabla (idPadre,nombreNivel,nombre) 
SELECT Zona.idPadre, NivelZ.etiqueta AS nombreNivel, Zona.nombre from Partidas.dbo.Zona AS Zona
				INNER JOIN Partidas.dbo.NivelZona as NivelZ
				ON Zona.idNivelZona = NivelZ.idNivelZona
				where idZona = @IdZona

SELECT @IdPadre = @IdZona from Partidas.dbo.Zona AS Zona
				INNER JOIN Partidas.dbo.NivelZona as NivelZ
				ON Zona.idNivelZona = NivelZ.idNivelZona
				where idZona = @IdZona

WHILE (@IdPadre > 0)

	BEGIN

		SELECT @IdPadre = Zona.idPadre from Partidas.dbo.Zona AS Zona
				INNER JOIN Partidas.dbo.NivelZona as NivelZ
				ON Zona.idNivelZona = NivelZ.idNivelZona
				where idZona = @IdPadre
		INSERT INTO @VariableTabla (idPadre,nombreNivel,nombre) 
		SELECT Zona.idPadre, NivelZ.etiqueta AS nombreNivel, Zona.nombre from Partidas.dbo.Zona AS Zona
				INNER JOIN Partidas.dbo.NivelZona as NivelZ
				ON Zona.idNivelZona = NivelZ.idNivelZona
				where idZona = @IdPadre
	END 

	SELECT * FROM @VariableTabla ORDER BY ID DESC

end
go

