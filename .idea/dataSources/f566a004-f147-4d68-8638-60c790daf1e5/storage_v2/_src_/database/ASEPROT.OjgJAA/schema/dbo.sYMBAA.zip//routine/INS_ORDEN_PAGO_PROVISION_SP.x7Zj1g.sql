--SELECT * FROM Ordenes WHERE numeroOrden = '14-839(TALLER MULTIMARCA)-1'
--SELECT * FROM Ordenes WHERE idOrden = 38233
--SELECT * FROM Cotizaciones WHERE idOrden = 38233
--47164
--SELECT * FROM Ordenes WHERE idContratoOperacion = 14
--SELECT * FROM ContratoOperacion WHERE idContratoOperacion = 14
--SELECT * FROM ContratoOperacionFacturacion WHERE idContratoOperacion = 14
--UPDATE ContratoOperacionFacturacion
--SET
--idClienteBpro = 145
--WHERE idContratoOperacion = 14
--SELECT * FROM CONTRATOOPERACION WHERE idContratoOperacion = 14 IDOPE 15
--SELECT * FROM facturaCotizacion WHERE idCotizacion = 47164
--SELECT * FROM DocumentosOrdenes WHERE idOrden = 38233
--92542
--IDORDEN 86883
--86884
--UPDATE DocumentosOrdenes
--SET
--rutaDocumento = 38233
--WHERE idDocumentosOrden IN (86883, 86884)

-- [INS_ORDEN_PAGO_PROVISION_SP] 109,12
-- [INS_ORDEN_PAGO_PROVISION_SP] 31576, 107, 1, 1 
-- [INS_ORDEN_PAGO_PROVISION_SP] 38233, 549, 15, 0
-- select * from FacturaCotizacion
-- [dbo].[INS_ORDEN_PAGO_PROVISION_SP] 81101, 538, 38, 1

/*
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	14/08/18		JEHR	Agrego la variable @@idOperacionBanorete  para que se tome por parametros
	
*/
CREATE PROC [dbo].[INS_ORDEN_PAGO_PROVISION_SP]
@idOrden NUMERIC(18,0),
@idUsuario NUMERIC(18,0),
@idOperacion NUMERIC(18,0),
@isProduction NUMERIC(18,0)

AS
BEGIN
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @max NUMERIC(18,0)
    DECLARE @fecha NVARCHAR(30)
	DECLARE @numFactura nvarchar(50)
	DECLARE @UUID nvarchar(50)
	DECLARE @XMLFactura nvarchar(MAX)
	DECLARE @totalFactura decimal(18, 2)
	DECLARE @idProveedor NUMERIC(18,0)
	DECLARE @proveedorInterno NUMERIC(18,0)

	BEGIN
	  --Actualiza el trabajo de estatus y inserta en BPRO
	  SELECT @idCotizacion = MIN(C.idCotizacion) FROM Cotizaciones C 
				INNER JOIN CotizacionDetalle CD on C.idCotizacion = CD.idCotizacion
				WHERE C.idOrden = @idOrden AND idTaller <> 0 and C.idEstatusCotizacion <> 4
	  
	  DECLARE @idOperacionBanorete int = CAST((select top 1 [Valor] FROM [Banorte].[Parametros] WHERE Id = 1) AS INT);

		SELECT @idProveedor = idTaller FROM Cotizaciones WHERE idCotizacion=@idCotizacion

		SELECT @proveedorInterno = CO.proveedorInterno
		FROM ContratoOperacion C
		INNER JOIN ContratoOperacionFacturacion CO ON CO.idContratoOperacion = C.idContratoOperacion
		WHERE idOperacion = @idOperacion
			
			IF((@idProveedor <> 291 AND @idProveedor <> 292 AND @idProveedor <> 293 AND @idProveedor <> 294) OR @proveedorInterno = 0)
				BEGIN
					IF NOT EXISTS ( SELECT C.idCotizacion, FC.idCotizacion 
						FROM  Cotizaciones C 
						LEFT JOIN FacturaCotizacion FC ON C.idCotizacion = FC.idCotizacion 
						WHERE idOrden = @idOrden AND FC.idCotizacion IS NULL AND C.idEstatusCotizacion IN(1,2,3))  
						
						BEGIN 					
							-- SELECT * FROM AprobacionProvision
							IF NOT EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
								BEGIN
									INSERT INTO AprobacionProvision VALUES (@idOrden, GETDATE(), @idUsuario, 1)
								END
								SELECT @max = MAX(C.idCotizacion) FROM Cotizaciones C 
									INNER JOIN CotizacionDetalle CD on C.idCotizacion = CD.idCotizacion
									WHERE idOrden = @idOrden AND idTaller <> 0 
					
								SELECT @fecha=fechaCreacionOden FROM Ordenes WHERE idOrden = @idOrden
								WHILE(@idCotizacion <= @max)
									BEGIN	
										IF EXISTS(SELECT idOperacion FROM [vwEncabezadoXOperacionProvision] WHERE idOperacion=@idOperacion AND tipo=1)
											BEGIN
												print '21' 
												SELECT @numFactura=numFactura, @UUID=uuid, @XMLFactura=xml, @totalFactura=total FROM FacturaCotizacion WHERE idCotizacion=@idCotizacion
												EXEC INS_ORDEN_ENCABEZADO_SP @idCotizacion, @fecha, @numFactura, @UUID, @XMLFactura, @totalFactura, @idUsuario, @idOperacion, @isProduction
												SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden AND idCotizacion > @idCotizacion
											END
										ELSE IF EXISTS(SELECT idOperacion FROM [vwEncabezadoXOperacionProvision] WHERE idOperacion=@idOperacion AND tipo=2)
											BEGIN
											print '20'
												SELECT @numFactura=numFactura, @UUID=uuid, @XMLFactura=xml, @totalFactura=total FROM FacturaCotizacion WHERE idCotizacion=@idCotizacion
												EXEC INS_ORDEN_ENCABEZADO_INTEGRA_SP @idCotizacion, @fecha, @numFactura, @UUID, @XMLFactura, @totalFactura, @idUsuario, @idOperacion, @isProduction
												SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden AND idCotizacion > @idCotizacion
											END
										ELSE
											BEGIN		
												print '22'							
												SELECT @numFactura=numFactura, @UUID=uuid, @XMLFactura=xml, @totalFactura=total FROM FacturaCotizacion WHERE idCotizacion=@idCotizacion
												IF (@idOperacion=@idOperacionBanorete)
													BEGIN 		
														EXEC [Banorte].[INS_PROVISION] @idOperacion, @isProduction, @idOrden																																								
														--EXEC Banorte.INS_ORDEN_ENCABEZADO_REFACCIONES_SP @idCotizacion, @fecha, @numFactura, @UUID, @XMLFactura, @totalFactura, @idUsuario, @idOperacion, @isProduction
													END
												ELSE
													BEGIN

														EXEC INS_ORDEN_ENCABEZADO_TOLUCA_SP @idCotizacion, @fecha, @numFactura, @UUID, @XMLFactura, @totalFactura, @idUsuario, @idOperacion, @isProduction
													END
												SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden AND idCotizacion > @idCotizacion	
											END
									END
								SELECT 1 Proceso
							END
		ELSE 
			BEGIN
				SELECT 0 Proceso
			END
		END
		ELSE
			BEGIN
				SELECT @max = MAX(C.idCotizacion) FROM Cotizaciones C 
				INNER JOIN CotizacionDetalle CD on C.idCotizacion = CD.idCotizacion
				WHERE idOrden = @idOrden AND idTaller <> 0
					 WHILE(@idCotizacion <= @max)
						BEGIN	
							EXEC INS_ORDEN_ENCABEZADO_TPARTS_SP @idCotizacion, @idProveedor, @idUsuario, @idOperacion, @isProduction
							SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden AND idCotizacion > @idCotizacion
						END
					 SELECT 1 Proceso
			END
	END
END
go

grant execute, view definition on INS_ORDEN_PAGO_PROVISION_SP to DevOps
go

