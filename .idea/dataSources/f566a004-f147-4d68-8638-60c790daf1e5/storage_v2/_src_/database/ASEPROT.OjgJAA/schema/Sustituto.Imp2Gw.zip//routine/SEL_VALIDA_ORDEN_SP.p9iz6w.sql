
-- ==========================================================================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 04/01/2017
-- [Sustituto].[SEL_VALIDA_ORDEN_SP] '01-1310076-1109',1
-- ==========================================================================================

CREATE PROC [Sustituto].[SEL_VALIDA_ORDEN_SP]
	@numeroOrden nvarchar(50),
	@idContratoOperacion int
AS
BEGIN
	IF EXISTS  (SELECT 1 FROM Ordenes  WHERE numeroOrden  = @numeroOrden and idContratoOperacion = @idContratoOperacion
	) 
		BEGIN
			
			IF EXISTS (SELECT 1 FROM Ordenes  WHERE numeroOrden  = @numeroOrden AND [idEstatusOrden] not in (8,9,10,11,12,13,14) and idContratoOperacion = @idContratoOperacion)  
				BEGIN
					SELECT 1 AS estatus-- NÚMERO DE ORDEN VALIDA
				END
			ELSE
				BEGIN
					SELECT 2 AS estatus--  EL ESTATUS DEL NÚMERO DE ORDEN NO ES VALIDA
				END	
		END
	ELSE
		BEGIN
			SELECT 0 AS estatus-- NO ES VALIDO EL NÚMERO DE ORDEN
		END

END
go

