-- [Banorte].[UPD_ESTATUS_ORDENES_REFACCIONES] 0, 18, '8'
-- [Banorte].[UPD_ESTATUS_ORDENES_REFACCIONES] 0, 18, '10'
CREATE PROC [Banorte].[UPD_ESTATUS_ORDENES_REFACCIONES]
/*
CREATE DATE 05,10,2017
DESC Actualiza los estatus de las ordenes si no corresponden con su correspondiente Estatus en Copades
select * from ContratoOperacionFacturacion
[UPD_ESTATUS_ORDENES_COPADE] 1,3
*/
@isProduction numeric(20) = null,
@idContratoOperacion numeric(20) = null,
@historicoBase  VARCHAR(max) = ''	

as
DECLARE	@db  VARCHAR(max) = ''	

IF(@isProduction = 1)
    BEGIN
        SELECT                 
               @db= SERVER+'.'+DBProduccion                
        FROM ASEPROT.dbo.ContratoOperacionFacturacion 
        WHERE idContratoOperacion =  @idContratoOperacion
    END
ELSE
    BEGIN
        SELECT 
                @db=DB
        FROM ASEPROT.dbo.ContratoOperacionFacturacion
		WHERE idContratoOperacion = @idContratoOperacion
	END
IF (@idContratoOperacion=3 OR @idContratoOperacion =15)
BEGIN
  SET @historicoBase='14'
END

DECLARE @idOrden AS numeric(18)
DECLARE @idEstatuscopade AS numeric(18)

declare @query nvarchar(max)='
DECLARE ordenCursor CURSOR FOR select distinct o.idOrden,a.COP_STATUS from DatosCopadeOrden dco
     inner join OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
     inner join OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
     inner join Ordenes o on o.idOrden=dco.idOrden
     inner join  '+@db+'.dbo.ADE_COPADE a on a.COP_ORDENGLOBAL=oa.numero COLLATE Latin1_General_CI_AS
where
(a.COP_STATUS=3 and o.idEstatusOrden not in (12,13)) or (a.COP_STATUS=4 and o.idEstatusOrden not in (11,13))
 or(a.COP_STATUS=2 and o.idEstatusOrden not in (10,13))or(a.COP_STATUS=1 and o.idEstatusOrden not in (9,13))
  and o.idOrden not in (
select ordenesFuera.idOrden from (
	select distinct o.idOrden,count(a.COP_STATUS) count from DatosCopadeOrden dco
    inner join OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
    inner join OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
    inner join Ordenes o on o.idOrden=dco.idOrden
    inner join  '+@db+'.dbo.ADE_COPADE a on a.COP_ORDENGLOBAL=oa.numero COLLATE Latin1_General_CI_AS
	group by o.idorden having count(a.COP_STATUS)>1) ordenesFuera
)'
EXECUTE SP_EXECUTESQL @query
print @query
OPEN ordenCursor
FETCH NEXT FROM ordenCursor INTO @idOrden,@idEstatuscopade
WHILE @@fetch_status = 0
BEGIN
	 if (@idEstatuscopade=1)
	 begin
		if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=@historicoBase)
		begin
			update Ordenes set idEstatusOrden=9 where idOrden=@idOrden
			update HistorialEstatusOrden set fechaFinal=GETDATE() where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)

			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
			begin
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=9)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,9,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end 
		end
	 end
	 if (@idEstatuscopade=2)
	 begin
		if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=@historicoBase)
		begin
			update Ordenes set idEstatusOrden=10 where idOrden=@idOrden
			update HistorialEstatusOrden set fechaFinal=GETDATE() where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
			
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
			begin
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=9)
			begin
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,9,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=10)
			begin
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,10,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
		end
	 end
	 if (@idEstatuscopade=3)
	 begin
		if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=@historicoBase)
		begin
			update Ordenes set idEstatusOrden=12 where idOrden=@idOrden
			update HistorialEstatusOrden set fechaFinal=GETDATE() where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
			
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end		
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=9)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,9,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=10)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,10,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=11)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,11,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=12)
			begin
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,12,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
		end
	 end 
	 if (@idEstatuscopade=4)
	 begin
		if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=@historicoBase)
		begin	    
			update Ordenes set idEstatusOrden=11 where idOrden=@idOrden
			update HistorialEstatusOrden set fechaFinal=GETDATE() where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
			
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=9)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,9,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=10)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,10,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=11)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,11,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end			
		end
	 end
	 FETCH NEXT FROM ordenCursor INTO @idOrden, @idEstatuscopade 
END
CLOSE ordenCursor
DEALLOCATE ordenCursor
--EXECUTE SP_EXECUTESQL @query
--print @query
go

grant execute, view definition on Banorte.UPD_ESTATUS_ORDENES_REFACCIONES to DevOps
go

