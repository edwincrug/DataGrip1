

CREATE PROCEDURE [dbo].[INS_PLAN_ACCION_SP]
  @texto NVARCHAR(1000),
  @fecha VARCHAR(50),
  @idUsuario INT,
  @idOrden INT,
  @estatusOrden INT
AS
BEGIN
	declare @ID numeric(18,0)=  (SELECT idAccion FROM Acciones where idOrden = @idOrden and idEstatusOrden = @estatusOrden)
	IF @ID is null
		BEGIN
			INSERT INTO Acciones VALUES(@texto,@fecha,1,@idUsuario,@idOrden,GETDATE(),@estatusOrden)
			SELECT @@IDENTITY
		END
	ELSE 
		BEGIN
			UPDATE Acciones
			SET texto = @texto, fecha = @fecha, idEstatusAccion = 1, idUsuario = @idUsuario, fechaAlta = GETDATE()
			where idAccion = @ID
			SELECT @ID
		END
END
go

