-- =============================================
-- Author:		Sahirely Yam
-- Create date: 14/06/2017
-- EXECUTE [dbo].[SEL_TIEMPO_TRANCURRIDO_ORDEN_SP] '03-3001-000086'
-- EXECUTE [dbo].[SEL_TIEMPO_TRANCURRIDO_ORDEN_SP] '01-2210035-5'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIEMPO_TRANCURRIDO_ORDEN_SP]
	@numOrden varchar(50) 
AS
BEGIN
	/*Se obtienen los datos de la orden -ID, Estatus Actual y Operación */
	declare @idOrden numeric(18,0) = (select idOrden from Ordenes where numeroOrden = @numOrden)
	declare @idEstatusOrden int = (select idEstatusOrden from Ordenes where idOrden = @idOrden)
	declare @idOperacion numeric(18,0) = (select [idOperacion] from [dbo].[ContratoOperacion] where [idContratoOperacion] in (select idContratoOperacion from [dbo].[Ordenes] where idOrden = @idOrden))

	/*se valida si la operación maneja tiempo asignado por estatus*/
	if ((select tiempoAsignado from Operaciones where idOperacion = @idOperacion) = 1)
	begin
		/*Se obtiene la fecha hora en que entró en dicho estatus*/
		declare @fechaHoraInicio datetime = (select fechaInicial from HistorialEstatusOrden where [idOrden] = @idOrden and idEstatusOrden = @idEstatusOrden and fechaFinal is null)
		
		/*Se agrega el tiempo asignado para obtener la fecha hora límite*/
		declare @tiempoAsignado varchar(max) = (select [tiempoEnEspera] from [dbo].[OperacionTiempoEnEspera] where [idOperacion] = @idOperacion and [idEstatusOrden] = @idEstatusOrden )
		declare @fechaHoraLimite datetime = DATEADD(HH, /*DATEPART(HOUR, @tiempoAsignado)*/ convert(int,SUBSTRING(@tiempoAsignado,0,2)), @fechaHoraInicio)
	
		/*Se obtiene la fecha hora actual para hacer la comparación*/
		declare @fechaHoraActual datetime = SYSDATETIME()

		declare @sinTiempoDisponible int = 0
		if  (@fechaHoraActual < @fechaHoraLimite )
		begin
			print 'no ha sobrepasado la hora límite'
			set @sinTiempoDisponible = 0
		end
		else
		begin
			print 'ha sobrepasado la hora límite'
			set @sinTiempoDisponible = 1
		end
	
		select [dbo].[SEL_TIEMPO_ASIGNADO_TRANSCURRIDO](@idOrden) as tiempoTranscurridoDisplay, @sinTiempoDisponible as sinTiempoDisponible 

	end
	else
	begin
		select '00:00 / 00:00' as tiempoTranscurridoDisplay, 1 as sinTiempoDisponible
	end
	
END
go

