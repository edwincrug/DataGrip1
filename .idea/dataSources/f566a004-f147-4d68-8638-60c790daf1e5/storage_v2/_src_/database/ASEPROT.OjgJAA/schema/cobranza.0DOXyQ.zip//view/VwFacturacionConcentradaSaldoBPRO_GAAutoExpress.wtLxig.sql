










--DROP VIEW [cobranza].[VwFacturacionConcentradaSaldoBPRO_GAAutoExpress]
CREATE VIEW [cobranza].[VwFacturacionConcentradaSaldoBPRO_GAAutoExpress]

AS
-- SELECT * FROM [cobranza].[VwFacturacionConcentradaSaldoBPRO_GAAutoExpressC]
--  RECORDS 33,714   TIME  31 seconds

	SELECT DISTINCT
			 CARTERA.PAR_IDMODULO MODULO,

			 --U.NumeroEconomico,

			 --U.Vin,

			 CCP_FECHVEN,

			 --O.NumeroOrden,

			 --C.NumeroCotizacion,

			 --PP.razonSocial Proveedor,

			 CAST([CCP_IDDOCTO] as varchar(50)) COLLATE Modern_Spanish_CI_AS AS [CCP_IDDOCTO],

             'Importe' = CASE CARTERA.PAR_IDMODULO

                                         when 'CXP'

                                         then ccp_abono-ccp_cargo

                                         else ccp_cargo-ccp_abono

                                        end, 

             'Saldo' = CASE CARTERA.PAR_IDMODULO

                                        when 'CXP'

                                        then ccp_abono-ccp_cargo + (Select isnull(sum(CCP_ABONO-CCP_CARGO),0)

                 from [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO

                 AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA

                 AND MOVIMIENTO.CCP_DOCORI<>'S')

                                        else ccp_CARGO-ccp_ABONO+(Select isnull(sum(CCP_CARGO-CCP_ABONO),0)

                 from [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO

                            AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA

                            AND MOVIMIENTO.CCP_DOCORI<>'S')

                            end

	FROM [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 AS DOCUMENTO 
	
	LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA='CARTERA' and CARTERA.PAR_IDENPARA = 'AE57'
	
	INNER JOIN [192.168.20.29].[GA_Corporativa].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA
	
	LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = 'TIMO' 
	
	--LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL 
	
	--INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_ORDSERENC ADEO  ON CCP_IDDOCTO = ADEO.OTE_FACTURACOMPRA AND CCP_IDPERSONA = ADEO.OTE_IDPROVEEDOR 
	
	--INNER JOIN Cotizaciones C ON C.numeroCotizacion = ADEO.OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS AND C.idEstatusCotizacion = 3

	--INNER JOIN FacturaCotizacion FC ON FC.idCotizacion = C.idCotizacion
	
	--INNER JOIN Partidas..Proveedor PP ON PP.idProveedor = C.idTaller
	
	--INNER JOIN Ordenes O ON C.idOrden = O.idOrden and O.idContratoOperacion IN (37) and o.idEstatusOrden <> 13
	
	--INNER JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
	
	--INNER JOIN Partidas..Contrato PC ON PC.idContrato = CO.idContrato
	
	--INNER JOIN Unidades U ON U.idUnidad = O.idUnidad AND U.idOperacion = CO.idOperacion
	
	--INNER JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden 
	
	WHERE CCP_DOCORI = 'S'  and CCP_TIPODOCTO = 'FAC'  AND CARTERA.PAR_IDMODULO IS NOT NULL AND CCP_IDPERSONA IN(
	273200
	,308096
	,265497
	,49422
	)

	--AND CCP_IDDOCTO = 'FG00022525'

--AND CCP_IDDOCTO = '281' AND CCP_IDPERSONA=221

go

