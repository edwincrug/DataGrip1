
-- =============================================
-- Author:		<Edgar Mendoza Gomez>
-- Create date: <13/11/2018>
-- Description:	<Proceso diario para insertar unidades y sus fechas en taller>
-- Test: [report].[INS_UNIDADES_FECHAS_TALLER_SP] 
-- ============== Versionamiento ================
/*
	Fecha			Autor			Descripción
	
*/
-- =============================================

CREATE PROCEDURE [report].[INS_UNIDADES_FECHAS_TALLER_SP] 

	
AS
BEGIN

	DECLARE 
	@idUnidad int,
	@numeroOrden varchar(30),
	@fechaInicial datetime,
	@fechaFinal datetime


	create table #prueba(fecha datetime, hora int)

	DECLARE fecha_cursor CURSOR FOR						
		SELECT distinct
		ord.idUnidad,
		ord.numeroOrden, 
		max(hisI.fechaInicial),  
		case 
			when max(hisF.fechaInicial) is null then max(hisC.fechaInicial)
			else max(hisF.fechaInicial)
		end fechaInicial
		FROM ASEPROT..Ordenes  ord
		inner JOIN [HistorialEstatusOrden] hisI ON hisI.idOrden = ord.idOrden and hisI.idEstatusOrden = 3
		left JOIN [HistorialEstatusOrden] hisF ON hisF.idOrden = ord.idOrden and hisF.idEstatusOrden = 6
		left JOIN [HistorialEstatusOrden] hisC ON hisC.idOrden = ord.idOrden and hisC.idEstatusOrden = 13
		where 
			ord.idUnidad is not null
			--ord.fechaCreacionOden BETWEEN '01/01/2019' and GETDATE()			
			--idUnidad in (6229)
			--ord.idOrden in (42090)
		 group by ord.idUnidad, ord.numeroOrden

	OPEN fecha_cursor 

	FETCH NEXT FROM fecha_cursor   
	INTO @idUnidad, @numeroOrden, @fechaInicial, @fechaFinal

		WHILE @@FETCH_STATUS = 0  
			BEGIN  
				--select @idUnidad, @numeroOrden, @fechaInicial,@fechaFinal

				;WITH FECHAS(fecha, horas) AS (
				SELECT @fechaInicial fecha, DATEDIFF(hour, @fechainicial, DATEADD(mi,-1,CONVERT(DATETIME,(DATEADD(day,1,convert(date,@fechaInicial))))))
				UNION ALL 
				SELECT ISNULL(@fechaFinal,GETDATE()), DATEDIFF(hour,DATEADD(mi,1,CONVERT(DATETIME,(DATEADD(day,0,convert(date,ISNULL(@fechaFinal,GETDATE())))))),ISNULL(@fechaFinal,GETDATE()))
				UNION ALL
				SELECT DATEADD(day, 1, fecha) fecha, 24
				FROM FECHAS
				WHERE fecha < DATEADD(day,-1, isnull(@fechaFinal,getdate()))
			
				)
			
				insert into #prueba
				select * from FECHAS 
				OPTION (MaxRecursion 0)

				insert into report.unidades_DiasTaller
				select  @idUnidad, convert(date,p.fecha), max(p.hora) from #prueba P
				left JOIN report.unidades_DiasTaller RUD oN RUD.idUnidad = @idUnidad and convert(date,p.fecha) = convert(date,rud.fecha )
				where rud.idunidad is null
				group by convert(date,p.fecha)

				delete from #prueba

			FETCH NEXT FROM fecha_cursor INTO @idUnidad, @numeroOrden, @fechaInicial, @fechaFinal 
			END 

	CLOSE fecha_cursor  
	DEALLOCATE fecha_cursor 

	drop table #prueba

END



go

