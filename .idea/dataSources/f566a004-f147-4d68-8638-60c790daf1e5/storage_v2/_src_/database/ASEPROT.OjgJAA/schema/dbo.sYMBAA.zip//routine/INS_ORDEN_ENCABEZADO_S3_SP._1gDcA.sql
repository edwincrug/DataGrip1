
-- ==========================================================================================
-- ALTER AUTH:  Adolfo Martinez
-- ALTER DATE:  09/08/2016
-- ALTER DESC:	Se inserta los datos en las tablas de bpro dependiendo SER o REF
-- SELECT * FROM tRABAJO WHERE idTrabajo=1074
-- select * from CotizacionMaestro where idTrabajo= 1074
-- EXEC [INS_ORDEN_ENCABEZADO_S3_SP] 51557,'','','','' ,0, 107, 16, 1
-- ==========================================================================================

CREATE PROC [dbo].[INS_ORDEN_ENCABEZADO_S3_SP] 
	@idCotizacion NUMERIC(18,0),
	@fecha DATETIME = NULL,
	@numFactura NVARCHAR(MAX) = '0',
	@UUID NVARCHAR(MAX) = '0',
	@XMLFactura NVARCHAR(MAX) = '0',
	@totalFactura DECIMAL(18,2) = 0.00,
	@idUsuario NUMERIC(18,0),
	@idOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0)

AS
BEGIN

DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE @idCliBPRO INT
DECLARE @DESGLOSE VARCHAR(5)
DECLARE @idContratoOperacion VARCHAR(5)

SELECT @idContratoOperacion=idContratoOperacion FROM ContratoOperacion WHERE idOperacion=@idOperacion

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server = SERVER,
				@db = DBProduccion,
				@idCliBPRO = [idClienteBpro],
				@DESGLOSE = desglose
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idContratoOperacion =  @idContratoOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB,
				@idCliBPRO = [idClienteBpro],
				@DESGLOSE = desglose
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idContratoOperacion =  @idContratoOperacion
	END
----------------------------------------------------------------
DECLARE @idCita DECIMAL(18,0)
DECLARE @OTE_IDCLIENTE DECIMAL(18,0)
----------------------------------------------------------------
DECLARE @IdEncabezado DECIMAL(18,0) = 0
DECLARE @fechaFormat NVARCHAR(10);
DECLARE @montoMinimo DECIMAL(18,2)
DECLARE @montoMaximo DECIMAL(18,2)
DECLARE @tipoDetalle SMALLINT = 1 --1: servicio, 2: refacciones
DECLARE @referencia NVARCHAR(10) = '01'
SET @montoMinimo = @totalFactura - 1
SET @montoMaximo = @totalFactura + 1 
DECLARE @numeroTrabajo  NVARCHAR(100) = ''
DECLARE @existe INT = 0
DECLARE @numeroCotizacion NVARCHAR(100) = ''
DECLARE @isProveedor NUMERIC(18,0)
DECLARE @status NUMERIC(18,0)
----------------------------------------------------------------
DECLARE @numerodeCotizacion NVARCHAR(100)
DECLARE @idTrabajo NVARCHAR(100)
DECLARE @ideCotizacion NVARCHAR(100)
DECLARE @rutainicio NVARCHAR(100) = '\\192.168.20.18\orden\'
DECLARE @rutafin NVARCHAR(100) = '\'
DECLARE @archivo NVARCHAR(100) = 'Factura_'
DECLARE @extencionPDF NVARCHAR(100) = '.pdf'
DECLARE @extencionXML NVARCHAR(100) = '.xml'
DECLARE @OTE_XMLCOMPRA NVARCHAR(MAX)
DECLARE @OTE_PDFCOMPRA NVARCHAR(MAX)
DECLARE @OTE_RUTAXML NVARCHAR(MAX)
DECLARE @OTE_RUTAPDF NVARCHAR(MAX)
DECLARE @idBPRO NUMERIC(18,0)
DECLARE @actualizaFac nvarchar(MAX) = ''
----------------------------------------------------------------
SELECT @fechaFormat = CONVERT(NVARCHAR(10),ISNULL(@fecha, GETDATE()),103)   

	SET @status = '0'
----------------------------------------------------------------
-- 03/10/2016
-- AJUSTE TEMPORAL TODAS LAS ORDENES DE REFACCIONES SE CAMBIAN A SERVICIO
-- UGM
--SELECT @tipoDetalle= ISNULL(idTipoCotizacion,1) FROM CotizacionMaestro WHERE idCotizacion = @idCotizacion
SET @tipoDetalle = 1
----------------------------------------------------------------
	SELECT 
		@numeroTrabajo=O.numeroOrden
	FROM Ordenes O
	JOIN Cotizaciones C ON C.idOrden = O.idOrden
	JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	WHERE C.idCotizacion = @idCotizacion AND CD.idEstatusPartida IN(1,2)
	GROUP BY O.numeroOrden
----------------------------------------------------------------
	SET @numeroCotizacion = (SELECT numeroCotizacion FROM Cotizaciones WHERE idCotizacion=@idCotizacion)
----------------------------------------------------------------
-- select * from [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERENC]
-- [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERdet]


	IF(@tipoDetalle=1) --servicio
		BEGIN

			declare @queryText varchar(max) = 
			'SELECT CASE WHEN EXISTS(SELECT 1 FROM [dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENPEMEX] = '''+@numeroCotizacion+''') THEN 1 ELSE 0 END' + char(13) + 
			'' 
			declare @tableTemp table (val int)
			insert into @tableTemp exec(@queryText) 
						
			set @existe = (select top 1 val from @tableTemp)
			PRINT 'EXISTE'
			PRINT @existe
		END
----------------------------------------------------------------
		SELECT	@numerodeCotizacion=numeroCotizacion, 
				@idTrabajo=idOrden,
				@ideCotizacion=idCotizacion  
		FROM Cotizaciones 
		WHERE idCotizacion=@idCotizacion

	SET @OTE_RUTAXML = @rutainicio+@idTrabajo+'\factura\'+@ideCotizacion+@rutafin
	SET @OTE_RUTAPDF = @rutainicio+@idTrabajo+'\factura\'+@ideCotizacion+@rutafin
	SET @OTE_PDFCOMPRA = @archivo+@numerodeCotizacion+@extencionPDF
	SET @OTE_XMLCOMPRA = @archivo+@numerodeCotizacion+@extencionXML
----------------------------------------------------------------
SELECT @idCita = idOrden FROM Ordenes WHERE idOrden=@idTrabajo

	--// Empresa
	DECLARE @idEmpresa INT
	DECLARE @idProveedorEncabezado INT

	SELECT @idEmpresa=E.idEmpresa FROM ContratoOperacion CO
	JOIN Partidas..Contrato C ON C.idContrato = CO.idContrato
	JOIN Partidas..Licitacion L ON L.idLicitacion=C.idLicitacion
	JOIN Partidas..Empresa E ON E.idEmpresa = L.idEmpresa
	WHERE CO.idContratoOperacion=@idContratoOperacion

	SELECT @idProveedorEncabezado=P.idProveedorEncabezado
	FROM Cotizaciones C 
	JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = C.idTaller
	WHERE idCotizacion=@idCotizacion
		
	SELECT @idBPRO=idBPRO 
	FROM Partidas..ProveedorEncabezadoEmpresa 
	WHERE idEmpresa=@idEmpresa AND idProveedorEncabezado=@idProveedorEncabezado

	-- @idBPRO = 89
		SELECT @OTE_IDCLIENTE = @idCliBPRO--1313 --1420 
        --SELECT @DESGLOSE= 'S'
----------------------------------------------------------------
	--SET @existe = 0
	IF(@existe = 0)
		BEGIN
			IF(@tipoDetalle=1) --servicio
			BEGIN
						declare @insertQuery varchar(max) = 
'						INSERT INTO [dbo].[ADE_ORDSERENC](' + char(13) + 
'								[OTE_ORDENPEMEX],' + char(13) + 
'								[OTE_ORDENANDRADE],' + char(13) + 
'								[OTE_REFERENCIA],' + char(13) + 
'								[OTE_IDPROVEEDOR],' + char(13) + 
'								[OTE_FECHAORDEN],' + char(13) + 
'								[OTE_FACTURACOMPRA],' + char(13) + 
'								[OTE_TASAIVA],' + char(13) + 
'								[OTE_SUBTOTAL],' + char(13) + 
'								[OTE_IVA],' + char(13) + 
'								[OTE_TOTAL],' + char(13) + 
'								[OTE_UUID],' + char(13) + 
'								[OTE_XMLCOMPRA],' + char(13) + 
'								[OTE_FECHOPE],' + char(13) + 
'								[OTE_HORAOPE],' + char(13) + 
'								[OTE_STATUS],' + char(13) + 
'								[OTE_FECHAPROCESO],' + char(13) + 
'								[OTE_HORAPROCESO],' + char(13) + 
'								[OTE_ORDENGLOBAL],' + char(13) + 
'								[OTE_PDFCOMPRA],' + char(13) + 
'								[OTE_RUTAXML],' + char(13) + 
'								[OTE_RUTAPDF],' + char(13) + 
'								[OTE_IDCLIENTE],' + char(13) + 
'								[OTE_DESGLOSE],' + char(13) + 
'                               [OTE_OBSERVACIONES],' + char(13) + 
'                               [OTE_IVAOC]' + char(13) + 
'								)' + char(13) + 
'						SELECT ' + char(13) + 
'							  CAST(C.numeroCotizacion AS NVARCHAR(MAX)), -- OTE_ORDENPEMEX' + char(13) + 
'							  --CAST(CM.idCotizacion AS NVARCHAR(MAX)), -- OTE_ORDENANDRADE' + char(13) + 
'							  CAST(O.numeroOrden AS NVARCHAR(MAX)), -- OTE_ORDENGLOBAL' + char(13) + 
'							  '''+@referencia+''', -- OTE_REFERENCIA' + char(13) + 
'							  '+convert(varchar(max),@idBPRO)+',--CAST(TL.idProveedor AS NVARCHAR(MAX)), -- OTE_IDPROVEEDOR' + char(13) + 
'							  '''+@fechaFormat+''', -- OTE_FECHAORDEN' + char(13) + 
'							  '''+CAST(@numFactura AS NVARCHAR(MAX))+''', -- OTE_FACTURACOMPRA' + char(13) + 
'							  CAST([dbo].[fnFactorIVA_Orden](O.idOrden,0)*100 AS VARCHAR(25)), -- OTE_TASAIVA' + char(13) + 
'							  CAST(CAST(SUM(CD.costo * CD.cantidad) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), -- OTE_SUBTOTAL' + char(13) + 
'							  CAST(CAST(SUM(CD.costo * CD.cantidad) * [dbo].[fnFactorIVA_Orden](O.idOrden ,0) AS DECIMAL(18,2))AS NVARCHAR(MAX)), -- OTE_IVA ' + char(13) + 
'							  CASE WHEN (SUM(CD.costo * CD.cantidad) + (SUM(CD.costo * CD.cantidad) * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) IN ('+convert(varchar(max),@montoMinimo)+', '+convert(varchar(max),@montoMaximo)+') THEN CAST('+convert(varchar(max),@totalFactura)+' AS NVARCHAR(MAX))  ELSE CAST(CAST((SUM(CD.costo * CD.cantidad) + (SUM(CD.costo * CD.cantidad) * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)) END, -- OTE_TOTAL' + char(13) + 
'							  '''+@UUID+''', -- OTE_UUID' + char(13) + 
'							  --@XMLFactura, --OTE_XMLCOMPRA' + char(13) + 
'							  '''+@OTE_XMLCOMPRA+''',' + char(13) + 
'							  CONVERT(VARCHAR(10),GETDATE(),103), -- OTE_FECHOPE' + char(13) + 
'							  CONVERT(VARCHAR(8),GETDATE(),108), -- OTE_HORAOPE' + char(13) + 
'							  '+convert(varchar(max),@status)+', --OTE_STATUS' + char(13) + 
'							  '+char(39)+''+char(39)+', -- OTE_FECHAPROCESO' + char(13) + 
'							  '+char(39)+''+char(39)+', -- OTE_HORAPROCESO' + char(13) + 
'							  CAST(O.numeroOrden AS NVARCHAR(MAX)), -- OTE_ORDENGLOBAL' + char(13) + 
'							  '''+@OTE_PDFCOMPRA+''',' + char(13) + 
'							  '''+@OTE_RUTAXML+''',' + char(13) + 
'							  '''+@OTE_RUTAPDF+''',' + char(13) + 
'							  '+convert(varchar(max),@OTE_IDCLIENTE)+',--@OTE_IDCLIENTE,' + char(13) + 
'							  '''+@DESGLOSE+''',' + char(13) + 
'                             '''',' + char(13) + 
'							  16 --@OTE_IVAOC' + char(13) + 
'						FROM Ordenes O' + char(13) + 
'						JOIN Cotizaciones C ON C.idOrden  = O.idOrden ' + char(13) + 
'						JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion ' + char(13) + 
'						WHERE C.idCotizacion = '+convert(varchar(max),@idCotizacion)+' ' + char(13) + 
'						AND CD.idEstatusPartida IN(2)' + char(13) + 
'						AND C.idEstatusCotizacion IN(3)' + char(13) + 
'						GROUP BY C.numeroCotizacion, O.numeroOrden, O.idOrden' + char(13) + 
'' 
PRINT @insertQuery
exec(@insertQuery) 

						IF(@numFactura = 'N/A')
						BEGIN
	
							SET @actualizaFac = 'UPDATE [dbo].[ADE_ORDSERENC] SET OTE_FACTURACOMPRA = OTE_FACTURACOMPRA + ''-'' + CONVERT(NVARCHAR(10),OTE_IDENT) + ''-'' + CONVERT(NVARCHAR(10),YEAR(GETDATE())) WHERE OTE_ORDENANDRADE = '''+@numeroTrabajo+'''' + char(13) + ''
							PRINT @actualizaFac
							exec(@actualizaFac)
							--UPDATE SET OTE_FACTURACOMPRA = OTE_FACTURACOMPRA + '-' + CONVERT(NVARHCAR(10),OTE_IDENT) + '-' + YEAR(GETDATE()) 
							--WHERE OTE_ORDENANDRADE = @numeroTrabajo
						END

						-----------------------------

						IF(@numeroTrabajo <> '' and @idContratoOperacion in (1,2))
						BEGIN
							declare @qTemp varchar(max) = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM [dbo].[ADE_COPADE] WHERE COP_ORDENGLOBAL = '''+@numeroTrabajo+''') THEN 1 ELSE 0 END' + char(13) + 
														  '' 
							
							declare @tTemp table (val int)
							insert into @tTemp exec(@qTemp) 

							declare @val int = (SELECT top 1 val from @tTemp)
							print @val
							IF (@val = 0)
							BEGIN
								declare @queryT varchar(max) = 'INSERT INTO [dbo].[ADE_COPADE] VALUES('+char(39)+@numeroTrabajo+char(39)+', '+char(39)+''+char(39)+', '+char(39)+'GMI'+char(39)+', CONVERT(VARCHAR(10),GETDATE(),103), CONVERT(VARCHAR(8),GETDATE(),108), NULL, 1)' + char(13) + 
															   '' 
								print @queryT
								exec(@queryT) 
								
							END
								
						END
							
						-----------------------------
						
						declare @qT varchar(max) = 'SELECT ISNULL(MAX(OTE_IDENT),1) FROM [dbo].[ADE_ORDSERENC]' + char(13) + 
												   '' 
						declare @tT table (val int)

						insert into @tT
						exec(@qT) 

						SELECT @IdEncabezado = (select top 1 val from @tT)
						
			END
			ELSE IF(@tipoDetalle=2) --refacciones
				 BEGIN
				  select 1
				END			
			EXEC INS_ORDEN_DETALLE_S3_SP @idCotizacion, @IdEncabezado, @tipoDetalle, @idOperacion, @isProduction
		END	
END
go

