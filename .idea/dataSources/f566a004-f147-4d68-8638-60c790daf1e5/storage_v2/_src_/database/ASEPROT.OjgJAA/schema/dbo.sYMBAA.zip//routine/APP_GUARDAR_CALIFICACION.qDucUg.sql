
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 11/05/2017
-- Description:	Inserta la calificación y KPI's que se le da a una Operación
-- ==========================================================================================

CREATE PROCEDURE [dbo].[APP_GUARDAR_CALIFICACION]
    @idToken numeric(3,0),
    @calificacionToken numeric(3,0),
    @comentariosToken NVARCHAR(250),
    @kpi1 numeric(3,0),
    @kpi2 numeric(3,0),
    @kpi3 numeric(3,0),
    @kpi4 numeric(3,0),
    @kpi5 numeric(3,0)
AS
BEGIN
	DECLARE @Calificiacion numeric,
			@idOrden INT,
			@idUsuario INT,
			@idEstatusOrden INT

	
	SET @Calificiacion = (SELECT calificacionToken FROM [Token] WHERE idToken = @idToken)
	SET @idOrden = ( SELECT idOrdenServicio FROM Token WHERE idToken = @idToken)
	SET @idUsuario = ( SELECT idUsuario FROM Token WHERE idToken = @idToken)
	SET @idEstatusOrden = ( SELECT idEstatusOrden FROM Token WHERE idToken = @idToken)
	
	IF( @Calificiacion IS NULL )
		BEGIN
			UPDATE 
				[Token] 
			SET 
				comentariosToken = @comentariosToken,
				calificacionToken = @calificacionToken
			WHERE idToken = @idToken;

			--NOTAS
			INSERT INTO [Notas]
				([descripcionNota],[idOrden],[idUsuario],[fechaNota],[idEstatusOrden])
				 VALUES (@comentariosToken +' Calificación '+ CAST(@calificacionToken AS NVARCHAR(30)), @idOrden, @idUsuario, GETDATE(), @idEstatusOrden)
			
			-- Insertamos los KPI's de esta calificación
			-- Insertamos los KPI's de esta calificación
			
			-- KPI 1
			IF ( @kpi1 <> 0 ) 
				BEGIN
				
					INSERT INTO [TokenKPI] (
						idToken, 
						idCatalogoKpi
					) 
					VALUES (
						@idToken,
						@kpi1
					)
				END
			
			-- KPI 2
			IF ( @kpi2 <> 0 ) 
				BEGIN
				
					INSERT INTO [TokenKPI] (
						idToken, 
						idCatalogoKpi
					) 
					VALUES (
						@idToken,
						@kpi2
					)
				END
				
			-- KPI 3
			IF ( @kpi3 <> 0 ) 
				BEGIN
				
					INSERT INTO [TokenKPI] (
						idToken, 
						idCatalogoKpi
					) 
					VALUES (
						@idToken,
						@kpi3
					)
				END
		    
			-- KPI 4
			IF ( @kpi4 <> 0 ) 
				BEGIN
				
					INSERT INTO [TokenKPI] (
						idToken, 
						idCatalogoKpi
					) 
					VALUES (
						@idToken,
						@kpi4
					)
				END
				
			-- KPI 5
			IF ( @kpi5 <> 0 ) 
				BEGIN
				
					INSERT INTO [TokenKPI] (
						idToken, 
						idCatalogoKpi
					) 
					VALUES (
						@idToken,
						@kpi5
					)
				END

			SELECT 1 Success, 'Su calificación se ha guardado con exito' Msg
		END
	ELSE
		BEGIN
			SELECT 0 Success, 'Ya se ha calificado con anterioridad' Msg
		END
	
	
END


go

