/*
	Objetivo: Mostrar las evidencias de SISCO en SISRE

	Fecha			Autor			Descripción
	10-Ago-2018		José Etmanuel	Se crea el SP 
	*---  Pruebas
	
*/
CREATE PROCEDURE Operacion.GET_Evidencias
	@idOrden INT 
AS
BEGIN

	SET NOCOUNT ON;

  SELECT *
  FROM [ASEPROT].[dbo].[Evidencias] AS e
  INNER JOIN [ASEPROT].[dbo].Ordenes AS o ON o.idOrden = e.idOrdenServicio
  WHERE idOrdenServicio = @idOrden
  ORDER BY e.idCotizacion

END
go

grant execute, view definition on Operacion.GET_Evidencias to DevOps
go

