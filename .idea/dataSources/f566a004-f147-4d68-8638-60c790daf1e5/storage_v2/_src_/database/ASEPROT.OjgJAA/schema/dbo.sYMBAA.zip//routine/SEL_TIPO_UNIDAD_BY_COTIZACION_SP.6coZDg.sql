-- =============================================
-- Author:		Sahirely Yam
-- Create date: 19 07 2017
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPO_UNIDAD_BY_COTIZACION_SP]
	@idCotizacion int
AS
BEGIN
	SET NOCOUNT ON;

	select idTipoUnidad 
	from Unidades
	where idUnidad = (select idUnidad 
						from Ordenes 
						where idOrden = (select idOrden 
											from Cotizaciones 
											where idCotizacion = @idCotizacion))
END
go

