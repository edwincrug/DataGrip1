-- =============================================
-- Author:		Sahirely Yam
-- Create date: 28 07 2017
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOS_UNIDAD_SIS_PROVEEDORES_SP] 
	@idOperacion INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT UNI.idUnidad AS idTipoUnidad, TU.tipo, M.nombre AS marca, SM.nombre as subMarca
	FROM Partidas..Unidad UNI
	INNER JOIN Partidas..TipoUnidad TU ON UNI.idTipoUnidad = TU.idTipoUnidad
	INNER JOIN Partidas..SubMarca SM ON SM.idSubMarca = UNI.idSubMarca
	INNER JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
	INNER JOIN Partidas..ContratoUnidad CU ON UNI.idUnidad = CU.idUnidad
	INNER JOIN ContratoOperacion CO ON CO.idContrato = CU.idContrato
	WHERE CO.idOperacion = @idOperacion
	order by TU.idTipoUnidad, M.nombre
END
go

