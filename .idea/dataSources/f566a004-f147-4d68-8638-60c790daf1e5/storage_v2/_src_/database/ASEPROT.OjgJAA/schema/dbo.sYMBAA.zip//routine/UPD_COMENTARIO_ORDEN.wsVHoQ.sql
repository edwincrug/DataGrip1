-- =============================================
-- Author:		
-- Create date: 
-- =============================================
CREATE PROCEDURE [dbo].[UPD_COMENTARIO_ORDEN] 
	@idComentarioOrden numeric(18,0),
	@comentario varchar(MAX) = NULL,
	@idOrden numeric(18,0),
	@idUsuario numeric(18,0)

AS
BEGIN
	SET NOCOUNT ON;

	IF @comentario is not null 
	BEGIN
		UPDATE ComentarioOrden SET comentario = @comentario WHERE idComentarioOrden = @idComentarioOrden
		SELECT @idComentarioOrden AS idComentarioOrden, @comentario AS Comentario
	END	 
	ELSE
	BEGIN
	SELECT 0 AS idComentarioOrden
	END
	--SELECT N.[idUsuario], U.[nombreCompleto], N.[descripcionNota] AS texto, DATEADD(hh, 5, N.[fechaNota]) AS fecha, EO.[nombreEstatusOrden] AS nombreEstatus
	--FROM   [dbo].[Notas] AS N
	--		INNER JOIN [dbo].[Usuarios] AS U ON U.[idUsuario] = N.[idUsuario]
	--		INNER JOIN [dbo].[Ordenes] AS O ON N.idOrden = O.idOrden 
	--		INNER JOIN [dbo].[EstatusOrdenes] AS EO ON EO.idEstatusOrden = N.idEstatusOrden
	--WHERE  O.numeroOrden = @numOrden
	--ORDER BY [fechaNota]
END
go

