CREATE procedure  [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP_BKP_20171017] 

@idOperacion as int = null,
@fechaInicial as varchar(25) =NULL,
@fechaFinal as varchar(25)= NULL,
@taller as varchar(150)= NULL,
@idCallcenter as int=NULL,
@idEstatus as int= NULL,
@idZona as int=NULL,
@numeroOrden varchar(50) = NULL

AS
BEGIN
		DECLARE @zonasAsignadas TABLE (idZona INT)
		INSERT INTO @zonasAsignadas values(@idZona)

		IF(@idCallcenter IS NOT NULL)
		BEGIN
			DECLARE @idCOU NUMERIC(18,0) = [dbo].[GET_CONTRATO_OPERACION_USR_FN](@idCallcenter ,@idOperacion)		
			INSERT INTO @zonasAsignadas 
			SELECT idZona FROM [dbo].[GET_ZONAS_USR_FN](@idCOU)			
		END

		IF(@idCallcenter IS NULL AND  @idZona IS NULL)
		BEGIN
			INSERT INTO @zonasAsignadas 			
			SELECT Z.idZona FROM ContratoOperacion CO
			INNER JOIN Partidas..Contrato C ON CO.idContrato= C.idContrato
			INNER JOIN Partidas..Licitacion L ON l.idLicitacion = c.idLicitacion
			INNER JOIN Partidas..NivelZona NZ ON l.idCliente = NZ.idCliente
			INNER JOIN Partidas..Zona Z ON NZ.idNivelZona = Z.idNivelZona
			WHERE idOperacion=@idOperacion 
		END

		
		SELECT * FROM 
				(
					  SELECT CLI.nombreComercial as [Cliente]
							,ORD.consecutivoOrden
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona							
							,[dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden) talleres
							,convert(numeric(18,2),ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00)) costo
							--,convert(numeric(18,2),ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)) venta
							,ORD.comentarioOrden descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus
							--,'' folioCertificado
							--,'' copade
							,ORD.fechaCreacionOden as fechaCreacionOrden        
							,COTI.fechaCotizacion as fechaCotizacion
							,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =4) as fechaAprobacion     
							--,VOSD4.[FechaMax] as [fechaAprobacion]     
							,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =5)  as fechaProceso
							--,VOSD5.[FechaMax] as [fechaProceso]     
							,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =6)  as fechaTerminoTrabajo
							,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =7)  as fechaSalida
							----,getdate()  fechaCertificado
							,case when (select top 1 DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) <= 30 then 1 else 0 end as   dias_0_30
							,case when (select top 1  DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) between 31 and 45  then 1 else 0 end as dias_31_45
							,case when (select top 1  DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) between 36 and 60  then 1 else 0 end as dias_46_60
							,case when (select top 1  DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) > 60  then 1 else 0 end as dias_mas_60
							,(select top 1  DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) dias
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,zp.nombre as nombrePadre
							,Z.nombre as nombreZona
							,TU.tipo AS tipoUnidad
							,TC.tipoCombustible as tipoCombustible
							, M.nombre AS marca
							,SM.nombre as subMarca
							,U.modelo as modelo		 			
							,PO.[folio] as [folio]
							,P.[folioPresupuesto] as [folioPresupuesto]
					FROM Ordenes ORD
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden
						INNER JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = ORD.idCatalogoTipoOrdenServicio
						INNER JOIN Cotizaciones COTI on COTI.idOrden = ORD.idOrden
						INNER JOIN CotizacionDetalle CD on CD.idCotizacion = COTI.idCotizacion
						INNER JOIN ContratoOperacion CO on CO.idContratoOperacion = ORD.idContratoOperacion
						INNER JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
						INNER JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
						INNER JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
						INNER JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						INNER JOIN Partidas..Zona Zp on Zp.idZona = z.idPadre
						INNER JOIN Partidas..Unidad PU on PU.idUnidad= U.idTipoUnidad
						INNER JOIN Partidas..TipoUnidad TU on TU.idTipoUnidad= PU.idTipoUnidad
						INNER JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible 
						INNER JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
						INNER JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
						LEFT JOIN  [dbo].[PresupuestoOrden] PO ON PO.[idOrden] = ORD.[idOrden]
						LEFT JOIN  [dbo].[Presupuestos] P ON P.[idPresupuesto] = PO.[idPresupuesto]
						--LEFT JOIN  [report].[VwOrdenStatusMaxDate] VOSD4 ON VOSD4.[idEstatusOrden] = ORD.idOrden  and VOSD4.idEstatusOrden = 4 
						--LEFT JOIN  [report].[VwOrdenStatusMaxDate] VOSD5 ON VOSD4.[idEstatusOrden] = ORD.idOrden  and VOSD4.idEstatusOrden = 5
					WHERE ORD.idEstatusOrden not in (13) 
				    --WHERE ORD.idEstatusOrden not in (9,10,11,12,13) 
						AND CD.idEstatusPartida in( 1,2) 
						AND coti.idEstatusCotizacion in (1,2,3) 
						AND OPE.idOperacion = 3

					GROUP BY ORD.idOrden,
						CLI.nombreComercial,
						ORD.consecutivoOrden,
						ORD.numeroOrden,
						U.numeroEconomico,
						ORD.idZona,
						ORD.fechaCreacionOden,
						EO.nombreEstatusOrden,
						CTOS.nombreTipoOrdenServicio,
						OPE.porcentajeUtilidad,
						COTI.fechaCotizacion,
						ORD.comentarioOrden,
						ORD.idEstatusOrden,
						zp.nombre,
						Z.nombre,
						EO.idEstatusOrden, 
						TU.tipo,
						TC.tipoCombustible,
						M.nombre,
						SM.nombre,
						U.modelo,
						PO.[folio],
					    P.[folioPresupuesto]
						--VOSD4.[FechaMax],
						--VOSD5.[FechaMax]
				) as tableResult

		WHERE	fechaCreacionOrden 
		BETWEEN isnull(@fechaInicial,convert(datetime,'1/1/1800')) 
		AND		isnull(@fechaFinal,convert(datetime,'1/1/2500'))
		AND		(@taller IS NULL OR talleres like '%'+ @taller +'%') 
		AND		(@idEstatus IS NULL OR idEstatus=@idEstatus ) 
		AND		(@numeroOrden IS NULL OR numeroOrden like '%'+ @numeroOrden+ '%') 
		AND		idZona IN (select idZona from @zonasAsignadas)
		

		
END
go

