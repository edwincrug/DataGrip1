-- [SEL_ORDEN_PENDIENTE_HOJA_TRABAJO_SP] 62
CREATE PROC [dbo].[SEL_ORDEN_PENDIENTE_HOJA_TRABAJO_SP]
	@idCentroTrabajo INT

AS
BEGIN
		SELECT 
			O.idOrden,
			O.consecutivoOrden,
			O.fechaCreacionOden,
			O.numeroOrden,
			O.comentarioOrden,
			O.idUnidad,
			O.idContratoOperacion,
			O.idUsuario,
			O.idCatalogoTipoOrdenServicio,
			O.idTipoOrden,
			O.idEstatusOrden,
			O.idCentroTrabajo,
			O.idTaller,
			CT.nombreCentroTrabajo,
			CT.idOperacion,
			U.numeroEconomico,
			EO.nombreEstatusOrden,
			Z.nombre AS nombreZona,
			(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			INNER JOIN [dbo].[Ordenes]	ORD ON C.idOrden = ORD.idOrden
			INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
			WHERE ORD.idOrden = O.idOrden 
			AND CO.idContratoOperacion = O.idContratoOperacion
			AND CD.idEstatusPartida IN(1,2) 
			AND C.idEstatusCotizacion IN(1,2,3)	) AS costo,
			(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			INNER JOIN [dbo].[Ordenes]	ORD ON C.idOrden = ORD.idOrden
			INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
			WHERE ORD.idOrden = O.idOrden 
			AND CO.idContratoOperacion = O.idContratoOperacion
			AND CD.idEstatusPartida IN(1,2) 
			AND C.idEstatusCotizacion IN(1,2,3)	) AS venta
		FROM Ordenes O
		JOIN CentroTrabajos CT ON CT.idCentroTrabajo = O.idCentroTrabajo
		JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden		 
		LEFT JOIN [Partidas].[dbo].[Zona] Z ON O.idZona = Z.idZona
		JOIN Unidades U ON U.idUnidad = O.idUnidad 
		--JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion AND U.idOperacion = CO.idOperacion
		WHERE O.idEstatusOrden = 5 AND CT.idCentroTrabajo = @idCentroTrabajo AND O.idOrden not in (select idOrden from OrdenesPresupuestoEspecial)


END
go

