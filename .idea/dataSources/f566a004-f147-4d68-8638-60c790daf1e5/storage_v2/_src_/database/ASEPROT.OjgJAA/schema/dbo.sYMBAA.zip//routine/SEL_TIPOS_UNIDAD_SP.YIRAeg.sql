
-- =============================================
-- Author:		Sahirely Yam
-- Create date: 28 07 2017
-- [SEL_TIPOS_UNIDAD_SP] 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPOS_UNIDAD_SP]
	@idOperacion INT
AS
BEGIN

	SET NOCOUNT ON;

	SELECT CU.idUnidad,(TU.tipo + ' ' + Sb.nombre+ ' '+ M.nombre) as tipo FROM ContratoOperacion CO
	JOIN Partidas..ContratoUnidad CU ON CU.idContrato = CO.idContrato
	JOIN Partidas..Unidad U ON U.idUnidad = CU.idUnidad
	JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = U.idTipoUnidad
	JOIN Partidas..SubMarca Sb on Sb.idSubMarca= U.idSubMarca
	JOIN Partidas..Marca M ON M.idMarca= Sb.idMarca
	WHERE idOperacion =  @idOperacion
		
END

go

