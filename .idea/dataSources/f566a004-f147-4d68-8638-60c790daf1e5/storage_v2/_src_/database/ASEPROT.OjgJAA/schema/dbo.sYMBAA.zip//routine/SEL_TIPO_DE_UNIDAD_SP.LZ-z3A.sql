-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 24/05/2017
-- Description:	Obtiene los centros de trabajo por operación 
-- SEL_TIPO_DE_UNIDAD_SP 6
-- =============================================
-- [SEL_TIPO_DE_UNIDAD_SP] 41
 CREATE PROCEDURE [dbo].[SEL_TIPO_DE_UNIDAD_SP] 
	@idOperacion INT
AS
BEGIN
	

	SELECT  U.vin,
			U.numeroEconomico,
			U.placas,
			U.idTipoUnidad, 
			TU.tipo,
			(MA.nombre) marca,
			(SM.nombre) subMarca,
			U.modelo AS anio,
			UPPER(U.combustible) as version, 
			CT.nombreCentroTrabajo,
			U.gps gps,
			U.sustituto,
			U.verificada,
			(SELECT [dbo].[SEL_NUMERO_UNIDADES_FN] (@idOperacion, UNI.idUnidad))AS registros,
			(SELECT cantidad FROM UnidadesOperacion WHERE idOperacion = @idOperacion  AND idTipoUnidad = U.idTipoUnidad) AS cantidad,
			tl.gpsTime AS fechaReporteGPS,
			CASE
			WHEN GETDATE() - DATEADD(hour,6, tl.gpsTime) < 0.5 then 1   --Menor a 12 horas
			WHEN GETDATE() - DATEADD(hour, 6, tl.gpsTime) >= 0.5 and GETDATE() - DATEADD(hour, 6, tl.gpsTime) < 3 then 2  --Entre 12 horas y 3 dias
			WHEN GETDATE() - DATEADD(hour, 6, tl.gpsTime) > 3 then 3   --Mayor a 3 dias
			ELSE 3
		    END							AS estatusReporte,
			U.idOrigenUnidad,
			OU.Descripcion as OrigenUnidad,
		    U.contratoUnidad,
		    ISNULL(U.perdidaTotal,0) AS perdidaTotal			
		FROM Unidades U
			LEFT JOIN [dbo].OrigenUnidad OU ON OU.idOrigenUnidad = U.IdOrigenUnidad
			INNER JOIN .[Partidas].dbo.Unidad UNI ON UNI.idUnidad = U.idTipoUnidad
			INNER JOIN .[Partidas].dbo.TipoUnidad TU ON UNI.idTipoUnidad = TU.idTipoUnidad
			INNER JOIN .[Partidas].dbo.SubMarca SM ON UNI.idSubMarca = SM.idSubMarca
			INNER JOIN .[Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca
			INNER JOIN .[Partidas].dbo.ContratoUnidad CU ON UNI.idUnidad = CU.idUnidad
			INNER JOIN ContratoOperacion CO ON CO.idContrato = CU.idContrato
			LEFT JOIN [CentroTrabajos] CT ON CT.idCentroTrabajo = U.idCentroTrabajo

			LEFT JOIN [192.168.20.110].[GPS].[cxc].[UnidadGPSSIM] ugs 
			ON ugs.vin = U.vin and ugs.estatus=1 and ugs.fechaBaja IS NULL
			AND ugs.idGPS NOT IN( SELECT GPSMod.idGPS FROM [192.168.20.110].[GPS].inventario.GPS GPSMod
			WHERE GPSMod.idGPSModelo=2 )
			LEFT JOIN [192.168.20.110].[GPS].inventario.GPSSIM gpssim on gpssim.idGPSsim = ugs.idGPSsim and gpssim.fechaBaja is null
			LEFT JOIN [192.168.20.110].[GPS].inventario.SIM sim on sim.idSIM = gpssim.idSIM
			LEFT JOIN [192.168.20.110].[GPS].inventario.GPS gps on gps.idGPS = gpssim.idGPS
			LEFT JOIN [192.168.20.110].[GPS].catalogo.GPSModelo gpsmod on gpsmod.idGPSModelo = gps.idGPSModelo  
			LEFT JOIN [192.168.20.110].[8833test].dbo.tCar tc on tc.machineNO = 
			case when gps.idGPSModelo = 3 then gps.deviceID
				when gps.idGPSModelo = 4 then gps.deviceIMEI
				when gps.idGPSModelo = 5 then gps.deviceID
				else gps.deviceID
			end
			LEFT JOIN [192.168.20.110].[8833test].dbo.tPosition_last tl on tl.carID = tc.carID
			WHERE CO.idOperacion = @idOperacion and U.idOperacion = @idOperacion
	 

END

go

