-- =============================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 02/06/2017 
--[SEL_DETALLE_MODULO_OPERACION] 1, 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DETALLE_MODULO_OPERACION]
	@idModulo int, 
	@idOperacion int
AS
BEGIN
	SET NOCOUNT ON;

    SELECT   ISNULL(DetMod.idDetalleModulo, 0) AS idDetalleModulo
			,ISNULL(DetMod.activo, 0) AS DetModActivo
			,ISNULL(DetMod.idCatalogoDetalleModulo, 0) AS idCatalogoDetalleModulo
			,ISNULL(CatDet.activo, 0) AS CatDetActivo
			,ISNULL(CatDet.nombreDetalleModulo, '') AS nombreDetalleModulo
	FROM	dbo.Modulos AS Modu LEFT OUTER JOIN
			dbo.CatalogoModulos AS CatMod ON Modu.idCatalogoModulo = CatMod.idCatalogoModulos LEFT OUTER JOIN
			dbo.DetalleModulo AS DetMod ON Modu.idModulo = DetMod.idModulo LEFT OUTER JOIN
			dbo.CatalogoDetalleModulo AS CatDet ON DetMod.idCatalogoDetalleModulo = CatDet.idCatalogoDetalleModulo
			WHERE  Modu.idOperacion = @idOperacion
			and Modu.idModulo = @idModulo
END
go

