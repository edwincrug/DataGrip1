-- =============================================
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- [SEL_DETALLE_APROBACION_MONTO_SP]3
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_DETALLE_APROBACION_MONTO_SP]
	@idOperacionContrato INT

AS
BEGIN
	
	SELECT * FROM DetalleOperacionAprobacionMonto WHERE idOperacionContrato= @idOperacionContrato
		
END


go

