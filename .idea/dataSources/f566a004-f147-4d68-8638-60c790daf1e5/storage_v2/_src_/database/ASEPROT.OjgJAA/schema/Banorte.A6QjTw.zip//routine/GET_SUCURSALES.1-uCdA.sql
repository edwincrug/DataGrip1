



/*
	Fecha			Autor			Descripción
	28-Jun-2018		Jesus Santibañez Se crea SP para obtener sucursales 

*/
CREATE PROCEDURE [Banorte].[GET_SUCURSALES] 
	@idPromocion INT,
	@latitud float,
	@longitud float 
AS
BEGIN


 SELECT 
	SUC.id as idSucursal
	,SUC.Nombre AS titulo
	,SUC.Latitud AS latitud
	,SUC.Longitud AS longitud
	,'' as distanciaentiempo
 FROM Banorte.Promociones P
	INNER JOIN [Banorte].[PromocionesSuc] AS S ON S.[idPromociones] = P.id
	INNER JOIN [Banorte].[Patrocinador] PAT ON PAT.Id = s.[PatrocinadorId]
	INNER JOIN [Banorte].[Sucursales] SUC ON SUC.[PatrocinadorId] = S.[PatrocinadorId] AND SUC.[Id] = S.[SucursalId]
  WHERE P.id=@idPromocion --and ((SUC.latitud BETWEEN  @latitud-1 and @latitud+1) and (SUC.longitud BETWEEN  @longitud-1 and @longitud+1))


	
END


go

grant execute, view definition on Banorte.GET_SUCURSALES to DevOps
go

