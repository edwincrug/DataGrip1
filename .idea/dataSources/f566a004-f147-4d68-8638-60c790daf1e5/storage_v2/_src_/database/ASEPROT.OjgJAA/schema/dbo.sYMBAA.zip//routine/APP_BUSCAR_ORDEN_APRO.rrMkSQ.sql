
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio	
-- Create date: 14/06/2017					
-- Description:	Store para la búsqueda del Número de Orden
-- [APP_BUSCAR_ORDEN_APRO] '57-PMX10367-1233', 315, 0
-- ==========================================================================================

CREATE PROCEDURE [dbo].[APP_BUSCAR_ORDEN_APRO]
    @numeroOrden VARCHAR(MAX),
    @idUsuario NUMERIC( 10,0 ),
    @consecutivoCotizacion NUMERIC( 10,0 )
AS   
BEGIN
	DECLARE @idEstatusOrden NUMERIC(18,0);
	DECLARE @idOrden NUMERIC(18,0);
	DECLARE @idOperacion NUMERIC(18,0);
	DECLARE @idContratoOperacionUsuario NUMERIC(18,0);
	DECLARE @idCotizacion NUMERIC(18,0);
	DECLARE @idAprobacionUtilidad NUMERIC(18,0);
	DECLARE @idZona NUMERIC(18,0);
	DECLARE @TokenAplicado NUMERIC(18,0);
	DECLARE @idPerfil NUMERIC(18,0);
	DECLARE @validacionPorToken NUMERIC(1,0);

	SET @idEstatusOrden = ( SELECT idEstatusOrden FROM [Ordenes] WHERE numeroOrden = @numeroOrden );
	SET @idOperacion = ( SELECT OPE.idOperacion 
						 FROM Ordenes					ORD
						 INNER JOIN ContratoOperacion	COP ON ORD.idContratoOperacion = COP.idContratoOperacion
						 INNER JOIN Operaciones			OPE ON OPE.idOperacion = COP.idOperacion
						 WHERE numeroOrden = @numeroOrden );

	SET @idContratoOperacionUsuario = (	SELECT COU.idContratoOperacionUsuario
										FROM ContratoOperacionUsuario COU
										INNER JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
										WHERE idUsuario = @idUsuario AND idOperacion = @idOperacion );

	SET @idZona = ( SELECT ORD.idZona FROM Ordenes ORD
					INNER JOIN ClientePerfilZona CPZ ON ORD.idZona = CPZ.idZona
					WHERE numeroOrden = @numeroOrden
						  AND CPZ.idUsuario = @idUsuario
						  AND CPZ.idOperacion = @idOperacion );
						  
	SET @idPerfil = ( SELECT CPZ.idPerfil FROM Ordenes ORD
					INNER JOIN ClientePerfilZona CPZ ON ORD.idZona = CPZ.idZona
					WHERE numeroOrden = @numeroOrden
						  AND CPZ.idUsuario = @idUsuario 
						  AND CPZ.idOperacion = @idOperacion );
						  
	SET @validacionPorToken = ( SELECT validacionPorToken FROM ContratoOperacionFacturacion COF
								INNER JOIN ContratoOperacion CO ON COF.idContratoOperacion = CO.idContratoOperacion
								WHERE idOperacion = @idOperacion );
								

	-- Validaciones
	IF ( @idEstatusOrden IS NULL )
		BEGIN
			SELECT 0 Success, 'La Orden que busca no se encuentra registrada.' Msg
		END
	ELSE IF ( @idContratoOperacionUsuario IS NULL )
		BEGIN
			SELECT 0 Success, 'No tienes permiso para autorizar en esta operación.' Msg
		END
	ELSE
		BEGIN
			-- @idOperacion
			SET @idOrden = ( SELECT idOrden FROM [Ordenes] WHERE numeroOrden = @numeroOrden );
			SET @idAprobacionUtilidad = ( SELECT TOP 1 idAprobacionUtilidad FROM AprobacionesUtilidad WHERE idOrden = @idOrden AND estatusAprobacion = 1 );
			
			-- SELECT @idAprobacionUtilidad, @idEstatusOrden;
			-- SET @idEstatusOrden = 4;
			IF ( @idAprobacionUtilidad IS NOT NULL AND ( @idEstatusOrden = 3 OR ( @idEstatusOrden >= 5 AND @idEstatusOrden <= 8 ) ) )
				BEGIN
					SELECT 
						Success = 1,
						Msg = 'Token de Utilidades',
						idEstatusOrden = @idEstatusOrden,
						idOrden = @idOrden,
						Calificacion = 0,
						Operacion = @idOperacion,
						idCotizacion = 0,
						tipo = 1
				END
			ELSE IF ( @idEstatusOrden = 4 OR @idEstatusOrden = 5 ) -- ( Aprobación ) -> En Aprobación
				BEGIN
					IF( @consecutivoCotizacion = 0 )
						BEGIN
							SELECT Success = 0, Msg = 'Para esta operación se debe proporcionar el consecutivo de la cotización';
						END
					ELSE
						BEGIN
							SET @idCotizacion = ( SELECT idCotizacion 
												  FROM Cotizaciones 
												  WHERE numeroCotizacion = @numeroOrden + '-' + CONVERT(VARCHAR(10),@consecutivoCotizacion)
														AND idEstatusCotizacion IN ( 1,2 ) );
							
							IF( @idCotizacion IS NULL )
								BEGIN
									SELECT Success = 0, Msg = 'La cotización que proporcionó no existe o ya fue aprobada o cancelada.';
								END
							ELSE
								BEGIN
									SELECT 
										Success = 1,
										Msg = 'Token Aprobaciones',
										idEstatusOrden = @idEstatusOrden,
										idOrden = @idOrden,
										Calificacion = 0,
										Operacion = @idOperacion,
										idCotizacion = @idCotizacion,
										tipo = 2
								END
						END
				END
			ELSE IF ( @idEstatusOrden = 6 ) -- ( Admin ) -> Término de Trabajo
				BEGIN
					SELECT 
						Success = 1,
						Msg = 'Admin :: Estatus : Termino de Trabajo',
						idEstatusOrden = @idEstatusOrden,
						idOrden = @idOrden,
						Calificacion = 0,
						Operacion = @idOperacion,
						idCotizacion = 0,
						tipo = 3
				END
			ELSE IF ( @idEstatusOrden = 7 ) -- ( Cliente ) -> Entrega
				BEGIN
					IF( @validacionPorToken = 2 )
						BEGIN
							IF ( @idZona IS NULL AND @validacionPorToken = 2 )
								BEGIN
								print '1'
									SELECT 0 Success, 'El usuario no pertenece a la misma zona de la orden de servicio.' Msg
								END
							ELSE
								BEGIN
									SET @TokenAplicado = (  SELECT TOK.idToken FROM [Token] TOK 
														INNER JOIN [Ordenes] ORD ON TOK.idOrdenServicio = ORD.idOrden 
														INNER JOIN [ClientePerfilZona] CPZ ON CPZ.idUsuario = TOK.idUsuario AND CPZ.idZona = ORD.idZona
														WHERE idOrden = @idOrden AND estatusToken = 2 AND CPZ.idPerfil = @idPerfil );
								
								-- SELECT @TokenAplicado;
								IF( @TokenAplicado IS NULL )
									BEGIN
										SELECT 
											Success = 1, 
											idEstatusOrden = @idEstatusOrden,
											idOrden = @idOrden,
											Calificacion = 1,
											Msg = 'Cliente :: Estatus : Entrega.',
											Operacion = @idOperacion,
											idCotizacion = 0,
											tipo = 4,
											validacionPorToken = @validacionPorToken
									END
								ELSE
									BEGIN
										IF( @idPerfil = 1 )
											BEGIN
												SELECT Success = 0, Msg = 'Para esta orden ya se cuenta con el Token del Superintendente, favor de solicitar el del Jefe de Mantenimiento.';
											END
										ELSE
											BEGIN
												SELECT Success = 0, Msg = 'Para esta orden ya se cuenta con el Token del Jefe de Mantenimiento, favor de solicitar el del Superintendente.';
											END	
									END
								END
						END
					ELSE
						BEGIN
							SELECT 
								Success = 1, 
								idEstatusOrden = @idEstatusOrden,
								idOrden = @idOrden,
								Calificacion = 1,
								Msg = 'Cliente :: Estatus : Entrega.',
								Operacion = @idOperacion,
								idCotizacion = 0,
								tipo = 4,
								validacionPorToken = @validacionPorToken
						END
				END
			ELSE IF ( @idEstatusOrden = 8 AND @validacionPorToken = 2 ) -- ( Cliente ) -> Entrega CASO ESPECIAL PARA LA OPERACION 3
				BEGIN
					IF ( @idZona IS NULL AND @validacionPorToken = 2 )
						BEGIN
						print '2'
							SELECT 0 Success, 'El usuario no pertenece a la misma zona de la orden de servicio.' Msg
						END
					ELSE
						BEGIN
							SET @TokenAplicado = (  SELECT TOK.idToken FROM [Token] TOK 
													INNER JOIN [Ordenes] ORD ON TOK.idOrdenServicio = ORD.idOrden 
													INNER JOIN [ClientePerfilZona] CPZ ON CPZ.idUsuario = TOK.idUsuario
													WHERE idOrden = @idOrden AND estatusToken = 2 AND CPZ.idPerfil = @idPerfil );
							
							IF( @TokenAplicado IS NULL )
								BEGIN
									SELECT 
										Success = 1, 
										idEstatusOrden = @idEstatusOrden,
										idOrden = @idOrden,
										Calificacion = 1,
										Msg = 'Cliente :: Estatus : Entrega :: Segundo Token',
										Operacion = @idOperacion,
										idCotizacion = 0,
										tipo = 4,
										validacionPorToken = @validacionPorToken
								END
							ELSE
								BEGIN
									IF( @idPerfil = 1 )
										BEGIN
											SELECT Success = 0, Msg = 'Para esta orden ya se cuenta con el Token del Superintendente, favor de solicitar el del Jefe de Mantenimiento.';
										END
									ELSE
										BEGIN
											SELECT Success = 0, Msg = 'Para esta orden ya se cuenta con el Token del Jefe de Mantenimiento, favor de solicitar el del Superintendente.';
										END	
								END
						END
				END
			ELSE
				BEGIN
					SELECT 0 Success, 'No cuenta con los privilegios necesarios para realizar el Token' Msg
				END
		END
	/*
	DECLARE @idEstatusOrden NUMERIC(18,0)
	DECLARE @idOrden NUMERIC(18,0)
	DECLARE @idOperacion NUMERIC(18,0)
	DECLARE @idContratoOperacionUsuario NUMERIC(18,0)
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @idAprobacionUtilidad NUMERIC(18,0)
	DECLARE @idZona NUMERIC(18,0)

	SET @idEstatusOrden = ( SELECT idEstatusOrden FROM [Ordenes] WHERE numeroOrden = @numeroOrden );
	SET @idOperacion = ( SELECT OPE.idOperacion 
						 FROM Ordenes					ORD
						 INNER JOIN ContratoOperacion	COP ON ORD.idContratoOperacion = COP.idContratoOperacion
						 INNER JOIN Operaciones			OPE ON OPE.idOperacion = COP.idOperacion
						 WHERE numeroOrden = @numeroOrden );

	SET @idContratoOperacionUsuario = (	SELECT COU.idContratoOperacionUsuario
										FROM ContratoOperacionUsuario COU
										INNER JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
										WHERE idUsuario = @idUsuario AND idOperacion = @idOperacion);
	
	SET @idZona = ( SELECT ORD.idZona FROM Ordenes ORD
					INNER JOIN ClientePerfilZona CPZ ON ORD.idZona = CPZ.idZona
					WHERE numeroOrden = @numeroOrden
						  AND CPZ.idUsuario = @idUsuario );
	-- Validaciones
	IF ( @idEstatusOrden IS NULL )
		BEGIN
			SELECT 0 Success, 'La Orden que busca no se encuentra registrada.' Msg
		END
	ELSE IF ( @idContratoOperacionUsuario IS NULL )
		BEGIN
			SELECT 0 Success, 'No tienes permiso para autorizar en esta opración.' Msg
		END
	ELSE IF ( @idZona IS NULL AND @idOperacion = 3 )
		BEGIN
			SELECT 0 Success, 'El usuario no pertenece a la misma zona de la orden de servicio.' Msg
		END
	ELSE
		BEGIN
			-- @idOperacion
			SET @idOrden = ( SELECT idOrden FROM [Ordenes] WHERE numeroOrden = @numeroOrden );
			SET @idAprobacionUtilidad = ( SELECT TOP 1 idAprobacionUtilidad FROM AprobacionesUtilidad WHERE idOrden = @idOrden AND estatusAprobacion = 1 );
			
			-- SELECT @idAprobacionUtilidad, @idEstatusOrden;
			-- SET @idEstatusOrden = 4;
			IF ( @idAprobacionUtilidad IS NOT NULL AND ( @idEstatusOrden = 3 OR ( @idEstatusOrden >= 5 AND @idEstatusOrden <= 8 ) ) )
				BEGIN
					SELECT 
						Success = 1,
						Msg = 'Token de Utilidades',
						idEstatusOrden = @idEstatusOrden,
						idOrden = @idOrden,
						Calificacion = 0,
						Operacion = @idOperacion,
						idCotizacion = 0,
						tipo = 1
				END
			ELSE IF ( @idEstatusOrden = 4 OR @idEstatusOrden = 5 ) -- ( Aprobación ) -> En Aprobación
				BEGIN
					IF( @consecutivoCotizacion = 0 )
						BEGIN
							SELECT Success = 0, Msg = 'Para esta operación se debe proporcionar el consecutivo de la cotización';
						END
					ELSE
						BEGIN
							SET @idCotizacion = ( SELECT idCotizacion 
												  FROM Cotizaciones 
												  WHERE numeroCotizacion = @numeroOrden + '-' + CONVERT(VARCHAR(10),@consecutivoCotizacion)
														AND idEstatusCotizacion IN ( 1,2 ) );
							
							IF( @idCotizacion IS NULL )
								BEGIN
									SELECT Success = 0, Msg = 'La cotización que proporcionó no existe o ya fue aprobada o cancelada.';
								END
							ELSE
								BEGIN
									SELECT 
										Success = 1,
										Msg = 'Token Aprobaciones',
										idEstatusOrden = @idEstatusOrden,
										idOrden = @idOrden,
										Calificacion = 0,
										Operacion = @idOperacion,
										idCotizacion = @idCotizacion,
										tipo = 2
								END
						END
				END
			ELSE IF ( @idEstatusOrden = 6 ) -- ( Admin ) -> Término de Trabajo
				BEGIN
					SELECT 
						Success = 1,
						Msg = 'Admin :: Estatus : Termino de Trabajo',
						idEstatusOrden = @idEstatusOrden,
						idOrden = @idOrden,
						Calificacion = 0,
						Operacion = @idOperacion,
						idCotizacion = 0,
						tipo = 3
				END
			ELSE IF ( @idEstatusOrden = 7 ) -- ( Cliente ) -> Entrega
				BEGIN
					SELECT 
						Success = 1, 
						idEstatusOrden = @idEstatusOrden,
						idOrden = @idOrden,
						Calificacion = 1,
						Msg = 'Cliente :: Estatus : Entrega.',
						Operacion = @idOperacion,
						idCotizacion = 0,
						tipo = 4
				END
			ELSE
				BEGIN
					SELECT 0 Success, 'No cuenta con los privilegios necesarios para realizar el Token' Msg
				END
		END
	*/
END

go

