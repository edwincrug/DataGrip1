-- =============================================
-- Author:		Jose Armando Garcia Arroyo
-- Create date: 28 07 2017
-- [SEL_ESPECIFICACION_UNIDAD_SP] 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ESPECIFICACION_UNIDAD_SP]
AS
BEGIN

SET NOCOUNT ON;
SELECT IdEspecificacionUnidad, Descripcion FROM dbo.EspecificacionUnidad
END
go

