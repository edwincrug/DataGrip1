 
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 13/06/2017
-- Description:	Stored para obtener las facturas por cotiación
-- ==========================================================================================
--select * from ordenes where numeroOrden = '26-12051-290'
--select * from Ordenes where idorden= 53358
--select * from Cotizaciones where idOrden = 53358
--EXEC [dbo].[SEL_FACTURAS_SP] 53358, 4    -- 78054, 78821, 80061
CREATE PROCEDURE [dbo].[SEL_FACTURAS_SP] 
    @idOrden NUMERIC(20,0),
    @idCotizacion NUMERIC(20,0),
	@path VARCHAR(100)  = 'E:\\ASEv2Documentos\\public\\orden\\', 
	@pathSend VARCHAR(100) = 'http://189.204.141.193:5101' 
AS   
	--SELECT * 
	--FROM DocumentosOrdenes 
	--WHERE 
	--	idOrden = @idOrden 
	--	AND idCotizacion = @idCotizacion 
	--	AND idCatalogoDocumento = 3;


	DECLARE @numeroCotización VARCHAR(max), @Archivo VARCHAR(255), @Existe INT, @tempCount INT = 1, @ContratoOperacion INT, @Banorte INT = 0, @Consecutivo INT = 0, @id INT, @primero INT = 0, @idCotizacionT int
	DECLARE @extensionesArchivos TABLE (ext varchar(3))
	DECLARE @Result table(idDocumentosOrden int, rutaDocumento varchar(max), fechaDocumento datetime, idOrden numeric(18,0), idCatalogoDocumento int, idCotizacion numeric(18,0))

	INSERT INTO @extensionesArchivos values('pdf')
	INSERT INTO @extensionesArchivos values('xml')

	SELECT @numeroCotización = numeroCotizacion , @idCotizacionT = idCotizacion
	FROM Cotizaciones 
	WHERE idOrden = @idOrden AND consecutivoCotizacion = @idCotizacion


	SELECT @ContratoOperacion = idContratoOperacion
	FROM Ordenes 
	WHERE idOrden = @idOrden
	print @ContratoOperacion

	IF EXISTS(select 1 from [Banorte].[Parametros] where Valor = @ContratoOperacion)
		BEGIN	
			SELECT @Id = id
			FROM [Banorte].[Parametros] 
			WHERE  Valor = @ContratoOperacion
		if(@Id = 2)
			BEGIN
				SET @Banorte = 1; 
			END
		END
	print @Banorte
	--select @Banorte = count(id) 
	--from [Banorte].[Parametros] 
	--where Valor = @ContratoOperacion

	IF(@Banorte = 1)
	BEGIN 
	IF EXISTS(select 1 from [ASEPROT].[dbo].[EvidenciasBitacora] 
					where idOrdenServicio = @idOrden and descripcionEvidencia like '%Factura%' and idCotizacion = @idCotizacionT)
			BEGIN
			DECLARE @Cadena VARCHAR(MAX),
			@aBuscar VARCHAR(MAX),
			@Longitud_Palabra INT
			SET @Cadena = (select top 1 rutaEvidencia from [ASEPROT].[dbo].[EvidenciasBitacora] eb
			left join  [ASEPROT].[dbo].Cotizaciones c on c.idCotizacion = eb.idCotizacion 
			where idOrdenServicio = @idOrden and descripcionEvidencia like '%Factura%' and c.consecutivoCotizacion = @idCotizacion
			order by eb.idEvidenciaBitacora desc
						)
			SET @aBuscar ='.'
			SET @Longitud_Palabra = LEN(@aBuscar)
			SET @Consecutivo = SUBSTRING(@Cadena, CHARINDEX(@aBuscar,@Cadena) -1, 1); 

			--SET @Consecutivo = (select count(idEvidenciaBitacora)/2 from [ASEPROT].[dbo].[EvidenciasBitacora] 
			--					where idOrdenServicio = @idOrden and descripcionEvidencia like '%Factura%') + 1
			END
			ELSE
			BEGIN
			SET @Consecutivo =	(SELECT count(idDocumentosOrden) FROM [ASEPROT].[dbo].[DocumentosOrdenes]  where  idorden =@idOrden) 
			SET @primero = 1
			END

			if ( (select count (*) from RefaccionMultiMarca.Relacion.UnidadSiniestroOrden US
					inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = US.idsiniestro
					inner join RefaccionMultiMarca.Operacion.CotizacionTaller T on T.idSiniestro = S.id
					where US.orden = @idOrden) > 0) 
			SET @Consecutivo=0
	--select @Consecutivo = count(idDocumentosOrden) from DocumentosOrdenes where idOrden = @idOrden
	END
	print @Consecutivo
	DECLARE @ext varchar(3)

	DECLARE docs_cursor CURSOR FOR  
	SELECT * FROM @extensionesArchivos

	OPEN docs_cursor;  

	FETCH NEXT FROM docs_cursor INTO @ext;  
 
	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		IF(@Consecutivo=0 or @primero =1)
		BEGIN
		SELECT @Archivo= @path + convert(varchar(max),@idOrden) + '/Factura/' + convert(varchar(max),@idCotizacion) + '/Factura_' + @numeroCotización + '.' + @ext				
		--EXEC Master.dbo.xp_fileexist @Archivo , @Existe OUT
		END
		ELSE
		BEGIN
		SELECT @Archivo= @path + convert(varchar(max),@idOrden) + '/Factura/' + convert(varchar(max),@idCotizacion) + '/Factura_' + @numeroCotización + '_' + convert(varchar(max),@Consecutivo) + '.' + @ext
		END
		set @Existe=1
		IF @Existe = 1
		BEGIN
		IF(@Consecutivo=0  or @primero =1)
		BEGIN
			SET @Archivo = @pathSend  + '/orden/' + convert(varchar(max),@idOrden) + '/Factura/' + convert(varchar(max),@idCotizacion) + '/Factura_' + @numeroCotización + '.' + @ext
		END
		ELSE
		BEGIN
		SET @Archivo = @pathSend  + '/orden/' + convert(varchar(max),@idOrden) + '/Factura/' + convert(varchar(max),@idCotizacion) + '/Factura_' + @numeroCotización + '_' + convert(varchar(max),@Consecutivo) + '.' + @ext
		END
			INSERT INTO @Result			
			SELECT @tempCount, @Archivo, GETDATE(), @idOrden, 3, @idCotizacion

			SET @tempCount = @tempCount + 1
		END

		FETCH NEXT FROM docs_cursor INTO @ext;   
	END  

	CLOSE docs_cursor;  
	DEALLOCATE docs_cursor;  

	SELECT * FROM @Result
go

grant execute, view definition on SEL_FACTURAS_SP to DevOps
go

