
-- [UPD_PROVISION_GENERA_PASIVO_SP] 84522, '57-PMX10285-7839-3', 124577, 538, 58,1
CREATE PROCEDURE [dbo].[UPD_PROVISION_GENERA_PASIVO_SP]
	@oteIdent NUMERIC(18,0),
	@numeroCotizacion NVARCHAR(100),
	@idOrden NUMERIC(18,0), --106 -- 25 -- o  11
	@idUsuario NUMERIC(18,0),
	@idOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0)
	
AS
BEGIN

DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE @encabezadoProvision NVARCHAR(MAX)
DECLARE @detalleProvision NVARCHAR(MAX)

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DBProduccion
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END

DECLARE @numeroOrden NVARCHAR(100)

SELECT @numeroOrden=numeroOrden FROM Ordenes WHERE idOrden=@idOrden

if ((select case when not exists (select 1 from Cotizaciones C1 where C1.idOrden = @idOrden and C1.idTaller in (select idProveedor from Partidas..Proveedor  where razonSocial like '%TOTAL PARTS AND COMPONENTS%') and @idOperacion in(1)) then 1 else 0 end) = 1)
--si el taller de la cotizacion no es total parts
	BEGIN
	print 'entra en 1'
		declare @queryText varchar(max) = 
		'SELECT CASE WHEN exists(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE OTE_IDENT = '+CONVERT(NVARCHAR(15),@oteIdent)+') then 1 else 0 end' + char(13) + 
		'' 
		PRINT @queryText
		declare @tabletemp table(val int)
		insert into @tabletemp exec(@queryText) 

		IF ((select top 1 val from @tabletemp) = 1)
			BEGIN
				SET @encabezadoProvision = 
				'
				UPDATE  '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] SET
				OTE_GENERA = ''S''
				FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] 
				WHERE OTE_IDENT = ' + CAST(@oteIdent AS NVARCHAR(30)) + ''
				--PRINT @encabezadoProvision
				EXECUTE SP_EXECUTESQL @encabezadoProvision

				IF EXISTS(SELECT 1 FROM BitacoraProvisionGeneraPasivo WHERE Ote_Ident = @oteIdent)
				BEGIN
					UPDATE BitacoraProvisionGeneraPasivo 
					set FechaActualiza = GETDATE(),
					IdUsuarioActualiza = @idUsuario
					WHERE Ote_Ident = @oteIdent
				END
				ELSE
				BEGIN 
					INSERT INTO BitacoraProvisionGeneraPasivo VALUES(@oteIdent,@idOrden,@idUsuario,@idOperacion,@numeroCotizacion,GETDATE(),NULL,NULL)
				END
				SELECT 1 Success, 'Se ingresa a inventario la cotización ' + @numeroCotizacion Msg
			END
		ELSE
			BEGIN
				SELECT 0 Success, 'No existe provision para esta orden ' + @numeroCotizacion Msg
			END
	END
ELSE
-- si el taller es total parts
	BEGIN
		print 'entra en 2'
		declare @idProveedor int = (select top 1 idTaller from Cotizaciones where idOrden = @idOrden and idEstatusCotizacion in (3))
		print @idProveedor
		IF(@isProduction = 1)
			BEGIN
			SELECT 
						@server = SERVER,
						@db = DBProduccion
				FROM CatalogoTecnico CT 
				WHERE CT.IdProveedor =  @idProveedor
			END
		ELSE
			BEGIN
				SELECT 
						@server = SERVER,
						@db = DBProduccion
				FROM CatalogoTecnico CT 
				WHERE CT.IdProveedor =  @idProveedor
			END

		declare @queryText2 varchar(max) = 
		'SELECT CASE WHEN exists(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = '''+@numeroOrden+''') then 1 else 0 end' + char(13) + 
		'' 
		--PRINT @queryText2
		declare @tabletemp2 table(val int)
		insert into @tabletemp2 exec(@queryText2) 

		IF ((select top 1 val from @tabletemp2) = 1)
			BEGIN
			print 'okas lokas'
				--SET @detalleProvision = 'SELECT * FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal =  '''+@numeroOrden+''''
				SET @detalleProvision = 'SELECT * FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE oae_ordenglobal = ' + ''''+@numeroOrden+''''
				PRINT @detalleProvision
				EXECUTE SP_EXECUTESQL @detalleProvision
			END
		ELSE
			BEGIN
				SELECT 0 Success, 'No existe provision para esta orden ' + @numeroCotizacion Msg
			END
	END
END
go

