CREATE FUNCTION [dbo].[GET_ODOMETRO_FN](@deviceid int)

returns float
as 
begin

	DECLARE @atributo varchar(max)
	,@protocol varchar(max)
	DECLARE @value float

	--declare @tbl_atributos as table(
	--	idAtributo int identity(1,1),
	--	atributo nvarchar(max),
	--	valor varchar(max)
	--)
	
	select top 1 @atributo = attributes 
	from [TRACKER].[Tracker].[dbo].[tc_positions] 
	where deviceId = @deviceId  
		and attributes like '%odometer%'
	order by id desc
	--PRINT @protocol

	--IF (@protocol = 'cellocator')
	--BEGIN
	--	SET @atributo = STUFF(
	--		(	
	--			SELECT top 1 ',' + attributes
	--			from [TRACKER].[Tracker].[dbo].[tc_positions]
	--			where deviceId = @deviceId
	--				and  [attributes] LIKE '%odometer%'
	--			order by fixtime desc
	--			FOR XML PATH(''), TYPE
	--		).value('.', 'NVARCHAR(MAX)'), 1, 1, ''
	--	)
	--END
	--ELSE
	--BEGIN
	--	SET @atributo = STUFF(
	--		(	
	--			SELECT top 1 ',' + attributes
	--			from [TRACKER].[Tracker].[dbo].[tc_positions]
	--			where deviceId = @deviceId
	--			and attributes like '%odometer%'
	--			order by fixtime desc
	--			FOR XML PATH(''), TYPE
	--		).value('.', 'NVARCHAR(MAX)'), 1, 1, ''
	--	)
	--END


	--select @atributo
	SET @value = (select [dbo].[SEL_ATRIBUTO_FN] (@atributo, 'odometer'))

	----insert into @tbl_atributos
	--select @value = a.valor
	--from(
	--	select replace(SUBSTRING([Name] , 1, CHARINDEX(':', [Name], 0) - 1 ), '"', '') as atributo
	--		,replace(SUBSTRING([Name], CHARINDEX(':', [Name], 0) + 1, LEN([Name]) ), '"', '') as valor
	--	from avl..splitstring(REPLACE( REPLACE( @atributo, '}', '' ), '{', ''),',')
	--	where [Name] like '%:%'
	--) a where a.atributo = 'odometer'

	--select * from @tbl_atributos

	return @value
end

go

