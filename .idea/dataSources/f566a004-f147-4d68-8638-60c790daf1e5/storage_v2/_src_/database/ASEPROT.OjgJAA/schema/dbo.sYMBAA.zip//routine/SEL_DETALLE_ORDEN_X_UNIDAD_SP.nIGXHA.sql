-- =============================================
-- Description:	Obtiene la informacion de la orden de servicio por unidad 
--				para editar la Orden de Servicio en la pantalla nuevacita
-- =============================================
-- SEL_DETALLE_ORDEN_X_UNIDAD_SP 256
CREATE PROCEDURE [dbo].[SEL_DETALLE_ORDEN_X_UNIDAD_SP]
	@idOrden INT
AS
BEGIN
	IF(EXISTS(	SELECT	*
				FROM	[dbo].[Unidades] UNI
						INNER JOIN [dbo].[Ordenes] ORD ON UNI.idUnidad = ORD.idUnidad
				WHERE	ORD.idOrden = @idOrden AND idEstatusOrden IN (1,2) AND  idTipoOrden = 1 
			  ))
		BEGIN
			DECLARE @idZona INT = 0
			SELECT	@idZona = ORD.idZona
			FROM	[dbo].[Unidades] UNI
					INNER JOIN [dbo].[Ordenes] ORD ON UNI.idUnidad = ORD.idUnidad			
			WHERE	ORD.idOrden = @idOrden AND idEstatusOrden IN (1,2) AND  idTipoOrden = 1
			PRINT @idZona
			DECLARE @idZonaPadre INT = 0, @zonas NVARCHAR(50) = '', @nombreZonas NVARCHAR(50) = '', @nombreZonas2 NVARCHAR(50) = '', @idUltimaZona INT = 0 
			SET @zonas = CONVERT(NVARCHAR(10),@idZona)
			SELECT @idZonaPadre = idPadre, @nombreZonas = nombre FROM [Partidas].[dbo].[Zona] WHERE idZona = @idZona
			WHILE (@idZonaPadre != 0)
				BEGIN
					SET @zonas = CONVERT(NVARCHAR(50),@idZonaPadre) + ',' + @zonas
					SELECT @idZonaPadre = idPadre, @nombreZonas2 = nombre, @idUltimaZona = idZona FROM [Partidas].[dbo].[Zona] WHERE idZona = @idZonaPadre
					SET @nombreZonas = @nombreZonas2 +', '+ @nombreZonas
				END
			PRINT @nombreZonas 
			PRINT @zonas
			SELECT	idOrden AS idOrden
					,numeroEconomico AS numeroEconomico
					,numeroOrden AS numeroOrden
					,comentarioOrden AS comenatario
					,requiereGrua AS grua
					,ORD.idCatalogoEstadoUnidad AS idEstadoUnidad
					,CEU.descripcionEstadoUnidad AS nombreEstadoUnidad
					,ORD.idCatalogoTipoOrdenServicio AS idTipoCita
					,CTOS.nombreTipoOrdenServicio AS nombreTipoCita
					,fechaCita AS fechaCita
					,1 AS respuesta
					,@zonas AS zonas
					,@nombreZonas AS nombreZonas
					,ORD.idTaller AS idTaller
					,ORD.idZona AS idZona
					,(CASE	WHEN EXISTS(SELECT * FROM [Cotizaciones] WHERE idOrden = ORD.idOrden) 
							THEN (SELECT Top 1 idCotizacion FROM [Cotizaciones] WHERE idOrden = ORD.idOrden)
							ELSE 0
							END) AS idCotizacion
					,ORD.idCentroTrabajo
			FROM	[Ordenes] ORD
					INNER JOIN [dbo].[Unidades] UNI ON UNI.idUnidad = ORD.idUnidad
					INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CTOS ON CTOS.idCatalogoTipoOrdenServicio = ORD.idCatalogoTipoOrdenServicio
					INNER JOIN [dbo].[CatalogoEstadoUnidad] CEU ON CEU.idCatalogoEstadoUnidad =ORD.idCatalogoEstadoUnidad
			WHERE	ORD.idOrden = @idOrden AND idEstatusOrden IN (1,2,3) AND  idTipoOrden = 1 
		END
	ELSE
		BEGIN
		 SELECT 0 AS respuesta,
				'La unidad no puede ser editada debido a los estatus en los que se encuentra la orden' AS mensaje 
		END
END
go

