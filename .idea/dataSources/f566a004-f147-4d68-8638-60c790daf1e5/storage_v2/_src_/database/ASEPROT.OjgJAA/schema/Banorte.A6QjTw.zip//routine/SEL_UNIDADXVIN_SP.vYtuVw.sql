--EXEC [Banorte].[SEL_UNIDADXVIN_SP] 28,'AFAHR6DA2KP101099'
CREATE PROCEDURE [Banorte].[SEL_UNIDADXVIN_SP]


@idLicitacion int,
@VIN varchar(30)

AS

BEGIN

	select 
	U.idUnidad as idUnidad,
	numeroeconomico as NumeroEconomico,
	U.idTipoUnidad as idTipoUnidad,
	TU.tipo as TipoUnidad,
	MA.idMarca as idMarca,
	MA.nombre as Marca,
	SU.idSubmarca as idSubmarca,
	SU.nombre as Submarca,
	placas as Placas ,
	modelo as Modelo,
	idTipoCombustible as idTipoCombustible,
	combustible as TipoCombustible,
	verificada as Verificada,
	ISNULL(U.Kilometraje_Actual,0) as Kilometraje
	--* 
	from unidades U
	INNER JOIN partidas..unidad PU ON Pu.idUnidad = U.idtipounidad
	INNER JOIN partidas..tipounidad Tu ON Tu.idtipounidad = Pu.idtipounidad
	LEFT JOIN partidas..submarca SU ON SU.idsubmarca = PU.idsubmarca
	LEFT JOIN partidas..marca MA ON MA.idMarca = SU.idMarca

	--LEFT Join [192.168.20.110].[GPS].[cxc].[UnidadGPSSIM]	UGS On UGS.vin = U.vin
	--LEFT join [192.168.20.110].[GPS].[inventario].GPSSIM gs on ugs.idGPSSIM = gs.idGPSSIM
	--LEFT join [192.168.20.110].[GPS].[inventario].GPS g on gs.idGPS = g.idGPS 
	--LEFT join [192.168.20.110].[8833test].[dbo].[tCar] tc on g.deviceID = tc.carNO
	--LEFT join [192.168.20.110].[8833test].[dbo].tPosition_last tpl on tc.carID = tpl.carID

	--INNER JOIN partidas..Servicio S On S.idservicio = Pu.idservicio
	--INNER JOIN  partidas..TServicio TS On TS.idtservicio = Pu.idtservicio
	--LEFT JOIN  [ContratoOperacion] CO ON CO.idOperacion = U.idoperacion
	--LEFT JOIN [Partidas].dbo.Contrato PC ON PC.idContrato = CO.idContrato
	WHERE U.VIN = @VIN AND U.idOperacion= @idLicitacion

END
go

grant execute, view definition on Banorte.SEL_UNIDADXVIN_SP to DevOps
go

