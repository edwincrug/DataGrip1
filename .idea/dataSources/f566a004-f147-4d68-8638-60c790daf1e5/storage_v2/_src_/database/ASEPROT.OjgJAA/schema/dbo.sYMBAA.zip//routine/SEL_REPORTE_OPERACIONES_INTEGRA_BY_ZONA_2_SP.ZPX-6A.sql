
-- =============================================  
-- Author:  <Author,,Name>  
-- Create date: <Create Date,,>  
-- Description: <Description,,>  
-- Test : SEL_REPORTE_OPERACIONES_INTEGRA_BY_ZONA_2_SP  
-- =============================================  
CREATE PROCEDURE [dbo].[SEL_REPORTE_OPERACIONES_INTEGRA_BY_ZONA_2_SP]  
   
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
  
    -- Insert statements for procedure here  
 select --top 5  
  b.REGION,  
  isnull(b.nombreCompleto, 'SIN EJECUTIVO CONFIGURADO')  nombreCompleto,  
  b.estatusOrden,  
  cast(round(sum(b.costoOrden), 2) as decimal(18,2)) costoOrden,  
  sum(b.numOrdenes) numOrdenes,  
  sum(b.[Ordenes menores a 10000]) 'ordenesMenores10000',  
  max(b.[antiguedad ordenes menores 10000]) 'antiguedadOrdenesMenor10000',  
  sum(b.NumLlantas) 'numLlantas',  
  max(b.[Dias de la orden mas antigua]) 'diasOrdenMasAntigua',  
  sum(b.numUnidades) numUnidades,  
  isnull(max(b.numUnidadesParque),sum(b.numUnidades)) numUnidadesParque,  
  cast(  
   round(   
    convert(  
     decimal, 100 * sum(b.numUnidades)) / convert(decimal,isnull(max(b.numUnidadesParque),sum(b.numUnidades)))  
     , 2)  
    as decimal(18,2))  porcentajeUnidades   
    
 from(  
  select   
   coalesce(est.nombreEstado, 'SIN ESTADO CONFIGURADO')  'REGION',  
   eso.nombreEstatusOrden  estatusOrden,  
   eso.idEstatusOrden   idEstatusOrden,  
   COUNT(DISTINCT ORD.idUnidad) numUnidades,  
   COUNT(distinct ord.idOrden) numOrdenes,  
   isnull(sum(cd.costo * cd.cantidad), 0) costoOrden,  
   usu.nombreCompleto,  
   --Subquery para obtener las ordenes con monto mayor a 5000 pesos  
   (  
    select count(a.idOrden) from   
     (  
      select isnull(sum(code.costo * code.cantidad),0) costo, edo.nombreEstado, usuar.nombreCompleto, es.nombreEstatusOrden, o.idOrden  
      from Partidas.dbo.Contrato c 
       left join ASEPROT.dbo.ContratoOperacion copera on copera.idContrato = c.idContrato   
       left join ASEPROT.dbo.Ordenes o on o.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.dbo.Cotizaciones co on co.idOrden = o.idOrden and co.idTaller =  
        case when o.idEstatusOrden = 1 then 0  
         else co.idTaller  
        end --and coti.idTaller != 0  
       left join ASEPROT.dbo.CotizacionDetalle code on code.idCotizacion = co.idCotizacion and code.idEstatusPartida in(1,2)  
       left join ASEPROT.dbo.EstatusOrdenes es on es.idEstatusOrden = o.idEstatusOrden  
       left join ASEPROT.Gerente.EstadoZona eszo on eszo.idZona = o.idZona and eszo.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.Gerente.Estados edo on edo.idEstados = eszo.idEstado  
       left join ASEPROT.Gerente.EstadoGerencia esger on esger.idEstado = edo.idEstados  
       left join ASEPROT.dbo.ContratoOperacionUsuarioGerente coperuge on coperuge.idGerencias = esger.idGerencia  
       left join ASEPROT.dbo.ContratoOperacionUsuario copeus on copeus.idContratoOperacionUsuario = coperuge.idContratoOperacionUsuario and copeus.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.dbo.Usuarios usuar on usuar.idUsuario = copeus.idUsuario  
      WHERE c.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
      --((e.idEmpresa = 5 and c.idContrato not in (34, 31)) or c.idContrato in(5, 7, 14, 23, 27, 41))  --34  
       and o.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)  
      group by edo.nombreEstado, usuar.nombreCompleto, es.nombreEstatusOrden, o.idOrden, o.idEstatusOrden  
     ) a  
    where a.costo < 10000  
     and isnull(a.nombreCompleto,0) = isnull(usu.nombreCompleto,0)  
     and a.nombreEstado = est.nombreEstado  
     and a.nombreEstatusOrden = eso.nombreEstatusOrden  
   )   'Ordenes menores a 10000',  
   --Subquery para obtener la fecha de mayor antigüedad con monto menor a 10000 pesos  
   (  
    select isnull(max(a.numDias), 0) from   
     (  
      select isnull(sum(code.costo * code.cantidad),0) costo, edo.nombreEstado, usuar.nombreCompleto, es.nombreEstatusOrden, o.idOrden, DATEDIFF( day, h.fechaInicial, coalesce( h.fechaFinal, getdate() ) ) numDias  
      from Partidas.dbo.Contrato c 
       left join ASEPROT.dbo.ContratoOperacion copera on copera.idContrato = c.idContrato   
       left join ASEPROT.dbo.Ordenes o on o.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.dbo.Cotizaciones co on co.idOrden = o.idOrden and co.idTaller =  
        case when o.idEstatusOrden = 1 then 0  
         else co.idTaller  
        end --and coti.idTaller != 0  
       left join ASEPROT.dbo.CotizacionDetalle code on code.idCotizacion = co.idCotizacion and code.idEstatusPartida in(1,2)  
       left join ASEPROT.dbo.HistorialEstatusOrden h on h.idEstatusOrden = o.idEstatusOrden and h.idOrden = o.idOrden  
       left join ASEPROT.dbo.EstatusOrdenes es on es.idEstatusOrden = o.idEstatusOrden  
       left join ASEPROT.Gerente.EstadoZona eszo on eszo.idZona = o.idZona and eszo.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.Gerente.Estados edo on edo.idEstados = eszo.idEstado  
       left join ASEPROT.Gerente.EstadoGerencia esger on esger.idEstado = edo.idEstados  
       left join ASEPROT.dbo.ContratoOperacionUsuarioGerente coperuge on coperuge.idGerencias = esger.idGerencia  
       left join ASEPROT.dbo.ContratoOperacionUsuario copeus on copeus.idContratoOperacionUsuario = coperuge.idContratoOperacionUsuario and copeus.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.dbo.Usuarios usuar on usuar.idUsuario = copeus.idUsuario  
      WHERE c.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
      --((e.idEmpresa = 5 and c.idContrato not in (34, 31)) or c.idContrato in(5, 7, 14, 23, 27, 41))  --34  
       and o.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)  
      group by edo.nombreEstado, usuar.nombreCompleto, es.nombreEstatusOrden, o.idOrden, h.fechaInicial, h.fechaFinal, o.idEstatusOrden  
     ) a  
    where a.costo < 10000  
     and isnull(a.nombreCompleto,0) = isnull(usu.nombreCompleto,0)  
     and a.nombreEstado = est.nombreEstado  
     and a.nombreEstatusOrden = eso.nombreEstatusOrden  
   )   'antiguedad ordenes menores 10000',  
   --Subquery para obtener las ordenes con cambio de llanta  
   (  
    select isnull(sum(a.numLlantas), 0) from  
     (  
      select edo.nombreEstado, usuar.nombreCompleto, es.nombreEstatusOrden, o.idOrden, count(distinct code.idCotizacionDetalle) * code.cantidad as numLlantas  
      from Partidas.dbo.Contrato c 
       left join ASEPROT.dbo.ContratoOperacion copera on copera.idContrato = c.idContrato   
       left join ASEPROT.dbo.Ordenes o on o.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.dbo.Cotizaciones co on co.idOrden = o.idOrden and co.idTaller != 0 and co.idEstatusCotizacion in(1,2,3) and co.idTaller =  
        case when o.idEstatusOrden = 1 then 0  
         else co.idTaller  
        end --and coti.idTaller != 0  
       left join ASEPROT.dbo.CotizacionDetalle code on code.idCotizacion = co.idCotizacion and code.idEstatusPartida in (1,2)  
       left join ASEPROT.dbo.EstatusOrdenes es on es.idEstatusOrden = o.idEstatusOrden  
       left join Partidas.dbo.partida par on par.idPartida = code.idPartida  
       left join ASEPROT.Gerente.EstadoZona eszo on eszo.idZona = o.idZona and eszo.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.Gerente.Estados edo on edo.idEstados = eszo.idEstado  
       left join ASEPROT.Gerente.EstadoGerencia esger on esger.idEstado = edo.idEstados  
       left join ASEPROT.dbo.ContratoOperacionUsuarioGerente coperuge on coperuge.idGerencias = esger.idGerencia  
       left join ASEPROT.dbo.ContratoOperacionUsuario copeus on copeus.idContratoOperacionUsuario = coperuge.idContratoOperacionUsuario and copeus.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.dbo.Usuarios usuar on usuar.idUsuario = copeus.idUsuario  
      WHERE c.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
      --((e.idEmpresa = 5 and c.idContrato not in (34, 31)) or c.idContrato in(5, 7, 14, 23, 27, 41))  --34  
       and o.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)  
       and par.descripcion like '%CAMBIO DE LLANTA%'  
      group by edo.nombreEstado, usuar.nombreCompleto, es.nombreEstatusOrden, o.idOrden, code.cantidad, o.idEstatusOrden  
     ) a  
    where   
     isnull(a.nombreCompleto,0) = isnull(usu.nombreCompleto,0)  
     and a.nombreEstado = est.nombreEstado  
     and a.nombreEstatusOrden = eso.nombreEstatusOrden  
   ) 'NumLlantas',  
   --Subquery para obtener las ordenes de mayor antigüedad  
   (  
    select isnull(max(a.tiempoDesfasado), 0) from   
     (  
      select DATEDIFF( day, h.fechaInicial, coalesce( h.fechaFinal, getdate() ) ) numDias, edo.nombreEstado, usuar.nombreCompleto, es.nombreEstatusOrden, o.idOrden,  
       case   
        when opte.tiempoEnEspera is null then 0  
        when GETDATE() > DATEADD( hour, convert( int, substring( opte.tiempoEnEspera, 0, 3 ) ), h.fechaInicial )   
         then DATEDIFF(DAY, DATEADD(hour, convert(int, substring(opte.tiempoEnEspera, 0, 3 ) ), h.fechaInicial), getdate())  
        else 0  
       end     as tiempoDesfasado  
      from Partidas.dbo.Contrato c 
       left join ASEPROT.dbo.ContratoOperacion copera on copera.idContrato = c.idContrato   
       left join ASEPROT.dbo.Ordenes o on o.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.dbo.HistorialEstatusOrden h on h.idEstatusOrden = o.idEstatusOrden and h.idOrden = o.idOrden  
       left join ASEPROT.dbo.EstatusOrdenes es on es.idEstatusOrden = o.idEstatusOrden  
       left join ASEPROT.Gerente.EstadoZona eszo on eszo.idZona = o.idZona and eszo.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.Gerente.Estados edo on edo.idEstados = eszo.idEstado  
       left join ASEPROT.Gerente.EstadoGerencia esger on esger.idEstado = edo.idEstados  
       left join ASEPROT.dbo.ContratoOperacionUsuarioGerente coperuge on coperuge.idGerencias = esger.idGerencia  
       left join ASEPROT.dbo.ContratoOperacionUsuario copeus on copeus.idContratoOperacionUsuario = coperuge.idContratoOperacionUsuario and copeus.idContratoOperacion = copera.idContratoOperacion  
       left join ASEPROT.dbo.Usuarios usuar on usuar.idUsuario = copeus.idUsuario  
       left join ASEPROT.dbo.OperacionTiempoEnEspera opte on opte.idOperacion = copera.idOperacion and opte.idEstatusOrden = o.idEstatusOrden  
       left join ASEPROT.dbo.Operaciones oper on oper.idOperacion = copera.idOperacion and tiempoAsignado = 1  
      WHERE c.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
       and o.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)  
      group by edo.nombreEstado, usuar.nombreCompleto, es.nombreEstatusOrden, o.idOrden, h.fechaFinal, h.fechaInicial, opte.tiempoEnEspera  
     ) a  
    where   
     isnull(a.nombreCompleto,0) = isnull(usu.nombreCompleto,0)  
     and a.nombreEstado = est.nombreEstado  
     and a.nombreEstatusOrden = eso.nombreEstatusOrden  
   ) 'Dias de la orden mas antigua',  
   (  
    select count(distinct uni.idUnidad)  
    from ASEPROT.dbo.Unidades uni  
     left join ASEPROT.dbo.ContratoOperacion copera on copera.idOperacion = uni.idOperacion  
     left join ASEPROT.Gerente.EstadoZona edozo on edozo.idZona = uni.idZona and edozo.idContratoOperacion = copera.idContratoOperacion  
     left join ASEPROT.Gerente.Estados edos on edos.idEstados = edozo.idEstado  
    where uni.idOperacion in(  
      select idOperacion from contratooperacion where idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
     )  
     and edos.nombreEstado = est.nombreEstado  
    group by edos.nombreEstado  
   )  'numUnidadesParque'  
     
  from Partidas.dbo.Contrato con 
   inner join ASEPROT.dbo.ContratoOperacion cop on cop.idContrato = con.idContrato   
   inner join ASEPROT.dbo.Ordenes ord on ord.idContratoOperacion = cop.idContratoOperacion   
   left join ASEPROT.dbo.Cotizaciones coti on coti.idOrden = ord.idOrden and coti.idTaller =  
    case when ord.idEstatusOrden = 1 then 0  
     else coti.idTaller  
    end --and coti.idTaller != 0  
   left join ASEPROT.dbo.CotizacionDetalle cd on cd.idCotizacion = coti.idCotizacion and cd.idEstatusPartida in (1,2)  
   left join ASEPROT.dbo.EstatusOrdenes eso on eso.idEstatusOrden = ord.idEstatusOrden  
   left join ASEPROT.dbo.HistorialEstatusOrden heo on heo.idEstatusOrden = eso.idEstatusOrden and heo.idOrden = ord.idOrden  
   left join ASEPROT.Gerente.EstadoZona ez on ez.idZona = ord.idZona and ez.idContratoOperacion = cop.idContratoOperacion  
   left join ASEPROT.Gerente.Estados est on est.idEstados = ez.idEstado  
   left join ASEPROT.Gerente.EstadoGerencia ege on ege.idEstado = est.idEstados  
   left join ASEPROT.dbo.ContratoOperacionUsuarioGerente couge on couge.idGerencias = ege.idGerencia  
   left join ASEPROT.dbo.ContratoOperacionUsuario cou on cou.idContratoOperacionUsuario = couge.idContratoOperacionUsuario and cou.idContratoOperacion = cop.idContratoOperacion  
   left join ASEPROT.dbo.Usuarios usu on usu.idUsuario = cou.idUsuario  
   left join Partidas.dbo.partida par on par.idPartida = cd.idPartida  
  where con.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
  --((emp.idEmpresa = 5 and con.idContrato not in (34, 31)) or con.idContrato in(5, 7, 14, 23, 27, 41))  --34  
   and ord.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)  
  group by est.nombreEstado, usu.nombreCompleto, eso.nombreEstatusOrden, eso.idEstatusOrden  
 ) b  
  
group by b.REGION, b.nombreCompleto, b.idEstatusOrden, b.estatusOrden  
order by b.REGION, b.idEstatusOrden  
END
go

