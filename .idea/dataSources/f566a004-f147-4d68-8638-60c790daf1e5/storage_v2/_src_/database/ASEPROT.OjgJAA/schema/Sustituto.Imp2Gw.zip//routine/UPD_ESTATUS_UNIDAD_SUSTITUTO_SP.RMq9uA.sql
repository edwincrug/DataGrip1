-- =============================================
-- Author:		Raul ArceFlorentino
-- Create date: 30/12/2016
-- Description:	Cambia el estatus de Unidad-Sustituto
-- Fecha de mod: 
-- EXEC [UPD_ESTATUS_UNIDAD_SUSTITUTO_SP]
-- =============================================

CREATE PROCEDURE [Sustituto].[UPD_ESTATUS_UNIDAD_SUSTITUTO_SP]
 @idUnidadSustituto NUMERIC (18,0)
AS
BEGIN
	 UPDATE [Sustituto].UnidadSustituto 
	 SET estatus = 1, fechaSalida = GETDATE()
	 WHERE idUnidadSustituto=@idUnidadSustituto
	 SELECT 1
END
go

