
/*
SELECT * FROM Ordenes WHERE idOrden=24
SELECT * FROM Cotizaciones WHERE idOrden=232 
SELECT * FROM facturaCotizacion
select * from Cotizaciones where idCotizacion=78
select * from [192.168.20.31].[GATPartsToluca].[dbo].[ADE_ORDSERENC]
SELECT * FROM Ordenes WHERE numeroOrden='01-310035-61'
SELECT * FROM [192.168.20.31].[GATPartsToluca].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = '01-310035-61'
*/
-- [SEL_PROVISION_POR_COTIZACION_SP] 125753, 538, 58, 1
CREATE PROCEDURE [dbo].[SEL_PROVISION_POR_COTIZACION_SP]
	 @idOrden NUMERIC(18,0), --106 -- 25 -- o  11
	 @idUsuario NUMERIC(18,0),
	@idOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0)

AS
BEGIN

DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE @encabezadoProvision NVARCHAR(MAX)
DECLARE @detalleProvision NVARCHAR(MAX)
DECLARE @tablaValor TABLE (IDENT NVARCHAR(MAX))
DECLARE @valorIdent NVARCHAR(MAX)

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DBProduccion
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idOperacion =  @idOperacion
	END

DECLARE @numeroOrden NVARCHAR(100)

SELECT @numeroOrden=numeroOrden FROM Ordenes WHERE idOrden=@idOrden

print @server
print @db 

if ((select case when not exists (select 1 from Cotizaciones C1 where C1.idOrden = @idOrden and C1.idTaller in (select idProveedor from Partidas..Proveedor  where razonSocial like '%TOTAL PARTS AND COMPONENTS%') and @idOperacion in(1)) then 1 else 0 end) = 1)
--si el taller de la cotizacion no es total parts
	BEGIN
	print 'entra en 1'
		declare @queryText varchar(max) = 
		'SELECT CASE WHEN exists(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE OTE_GENERA <> ''G'' AND OTE_ORDENANDRADE = '''+@numeroOrden+''') then 1 else 0 end' + char(13) + 
		'' 

		declare @tabletemp table(val int)
		insert into @tabletemp exec(@queryText) 

		IF ((select top 1 val from @tabletemp) = 1)
			BEGIN
				SET @encabezadoProvision = 
				'SELECT OTE_IDENT, OTE_ORDENPEMEX, OTE_FACTURACOMPRA FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE OTE_GENERA <> ''G'' AND OTE_ORDENANDRADE = ' + ''''+@numeroOrden+''''
				EXECUTE SP_EXECUTESQL @encabezadoProvision
			END
		ELSE
			BEGIN
				SELECT 0 Success, 'No existe provision para esta orden ' + @numeroOrden Msg
			END
	END
END
go

