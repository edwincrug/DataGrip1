
--INS_CONFIGURACION_CONTRATO_ZONA_SP 58, 55, '540210312', '114621790.06'

CREATE PROCEDURE [dbo].[INS_CONFIGURACION_CONTRATO_ZONA_SP] (
	@IdOperacion INT,
	@IdZona INT,
	@Contrato nvarchar(50),
	@Presupuesto decimal(18, 4)
)
as
begin
	
	IF NOT EXISTS
		(
			SELECT 
				 PGCZ.IdParametrosGeneralContratoZona
			FROM ParametrosGeneralContratoZona PGCZ
			INNER JOIN ParametrosGeneral PG ON PG.IdParametroGeneral = PGCZ.IdParametroGeneral
			WHERE PGCZ.IdZona = @IdZona AND PGCZ.IdOperacion = @IdOperacion AND PG.IdParametroGeneral = 8 /*Parametro de contrato por zona padre*/
		)
		BEGIN
			insert into ParametrosGeneralContratoZona values(8, @IdZona, @Contrato, @Presupuesto, @IdOperacion, getdate(), 1)
		END
	ELSE
		BEGIN
			UPDATE PGCZ 
			SET 
			PGCZ.Contrato = @Contrato, 
			PGCZ.Presupuesto = @Presupuesto 
			FROM ParametrosGeneralContratoZona PGCZ
			INNER JOIN ParametrosGeneral PG ON PG.IdParametroGeneral = PGCZ.IdParametroGeneral
			WHERE PGCZ.IdZona = @IdZona AND PGCZ.IdOperacion = @IdOperacion AND PG.IdParametroGeneral = 8 /*Parametro de contrato por zona padre*/
		END
	

	SELECT scope_identity() AS 'IdParametrosGeneralContratoZona';
end
go

