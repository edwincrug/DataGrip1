-- ==========================================================================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 16/05/2017
-- ==========================================================================================
CREATE PROC [dbo].[SEL_CONSULTA_ORDENES_SP]
	@idusuario numeric(18,0) = 2,
	@idzona nvarchar(18) = NULL,
	@idejecutivo nvarchar(18) = NULL,
	@fechaMes nvarchar(50) = NULL,
	@rangoInicial nvarchar(50) = NULL,
	@rangoFinal nvarchar(50) = NULL,
	@fecha nvarchar(50) = NULL,
	@numorden nvarchar(18) = NULL,
	@porOrden bit = 1,
	@presupuesto bit = 1
AS
BEGIN
	DECLARE @select NVARCHAR(MAX) = '',
			@condiciones NVARCHAR(MAX) = ''



	SET @select = 
	'SELECT 
		CLI.razonSocial AS Cliente, 
		O.consecutivoOrden AS Consecutivo, 
		O.numeroOrden AS NumeroOrden, 
		UN.numeroEconomico AS NumeroEconomico, 
		Z.nombre AS Zona, 
		TA.razonSocial AS Taller, 
		T.nombreTipoORden AS TipoOrden, 
		O.fechaCita AS Fecha, 
		COT.idCotizacion AS numeroCotizacion,
		TiUn.tipo AS MarcaModelo,
		Ecot.nombreEstatusCotizacion AS Estatus,
		US.nombreUsuario AS Cotizo,
		Porcentaje = (select count(*) from CotizacionDetalle as CD where CD.idCotizacion = COT.idCotizacion and CD.idEstatusPartida != 1) * 100 / (select count(*) from CotizacionDetalle as CD where CD.idCotizacion = COT.idCotizacion),
		Estadistica = convert(varchar(max), (select count(*) from CotizacionDetalle as CD where CD.idCotizacion = COT.idCotizacion and CD.idEstatusPartida = 1)) + ''|'' + convert(varchar(max), (select count(*) from CotizacionDetalle as CD where CD.idCotizacion = COT.idCotizacion and CD.idEstatusPartida = 2)) + ''|'' + convert(varchar(1), (select count(*) from CotizacionDetalle as CD where CD.idCotizacion = COT.idCotizacion and CD.idEstatusPartida = 3)) + ''|'' + convert(varchar(1), (select count(*) from CotizacionDetalle as CD where CD.idCotizacion = COT.idCotizacion)),
		Ecot.idEstatusCotizacion AS EstatusAprobacion,
		TiempoEspera = '''',		
		OP.presupuesto,
		COT.idCotizacion
	FROM Ordenes AS O JOIN
		 ContratoOperacion AS CO ON O.idContratoOperacion = CO.idContratoOperacion INNER JOIN
		 Unidades AS UN ON O.idUnidad = UN.idUnidad INNER JOIN
		 Operaciones AS OP ON CO.idOperacion = OP.idOperacion AND UN.idOperacion = OP.idOperacion INNER JOIN
		 Cotizaciones AS COT ON O.idOrden = COT.idOrden INNER JOIN
		 Taller AS TA ON COT.idTaller = TA.idTaller INNER JOIN
		 CatalogoTipoOrden AS T ON O.idTipoOrden = T.idTipoOrden INNER JOIN
		 EstatusOrdenes AS E ON E.idEstatusOrden = O.idEstatusOrden INNER JOIN 
		 EstatusCotizaciones AS Ecot ON Ecot.idEstatusCotizacion = COT.idEstatusCotizacion INNER JOIN
		 Usuarios AS US ON US.idUsuario = COT.idUsuario INNER JOIN
		Partidas.dbo.Contrato AS C ON C.idContrato = CO.idContrato INNER JOIN
		Partidas.dbo.Licitacion AS LI ON LI.idLicitacion = C.idLicitacion INNER JOIN
		Partidas.dbo.Cliente AS CLI ON CLI.idCliente = LI.idCliente INNER JOIN
		Partidas.dbo.Zona AS Z ON Z.idZona = O.idZona INNER JOIN
		Partidas.dbo.TipoUnidad AS TiUn ON UN.idTipoUnidad = TiUn.idTipoUnidad
		WHERE O.idEstatusOrden = 4 AND (COT.idEstatusCotizacion = 1 OR COT.idEstatusCotizacion = 2)
		AND OP.presupuesto = ' + convert(varchar(max),@presupuesto)
		+ ' AND O.idContratoOperacion IN (SELECT contrOpUs.idContratoOperacion
																FROM dbo.Usuarios AS us
																INNER JOIN dbo.ContratoOperacionUsuario AS contrOpUs ON us.idUsuario = contrOpUs.idUsuario
																WHERE us.idUsuario = '+ convert(varchar(max),@idusuario)+')'

		IF (@porOrden = 1 and (@numorden is not null))
			BEGIN
				SET @condiciones = ' AND O.numeroOrden like ''%' + @numorden + '%'''
			END
		ELSE IF (@porOrden = 0)
			BEGIN
				IF (@idzona is not null)
					BEGIN
						SET @condiciones = @condiciones + ' AND Z.idZona = ' + @idzona
					END
				IF (@idejecutivo is not null)
					BEGIN
						SET @condiciones = @condiciones + ' AND US.idUsuario = ' + @idejecutivo
					END
				IF (@fechaMes is not null)
					BEGIN
						DECLARE @fechaInicio DATE = CONVERT(DATE,@fechaMes)
						DECLARE @fechaFin DATE = CONVERT(DATE,DATEADD(d,-1,DATEADD(mm, DATEDIFF(m,0,@fechaMes)+1,0)))
						SET @condiciones = @condiciones + ' AND O.fechaCita BETWEEN ' + convert(varchar(max),@fechaInicio) + ' AND ' + convert(varchar(max),@fechaFin)
					END
				IF (@rangoInicial is not null and @rangoFinal is not null)
					BEGIN
						SET @condiciones = @condiciones + ' AND O.fechaCita BETWEEN CAST('+''''+@rangoInicial+''''+' AS DATETIME) AND CAST('+''''+@rangoFinal+''''+' AS DATETIME)'
					END
				IF (@fecha is not null)
					BEGIN
						SET @condiciones = @condiciones +	' AND O.fechaCita = CAST('+''''+@fecha+''''+' AS DATETIME)'
					END

			END

		DECLARE @query NVARCHAR(MAX) = @select + @condiciones
		EXECUTE SP_EXECUTESQL @query
		PRINT @query
END

go

