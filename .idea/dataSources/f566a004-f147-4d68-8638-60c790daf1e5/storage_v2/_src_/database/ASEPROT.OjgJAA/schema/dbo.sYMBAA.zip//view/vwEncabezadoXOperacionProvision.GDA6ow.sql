








CREATE VIEW [dbo].[vwEncabezadoXOperacionProvision]
AS

SELECT idOperacion,idContrato,tipo=1 FROM ContratoOperacion
WHERE idOperacion IN(3,9,58)
UNION ALL
SELECT idOperacion,idContrato,tipo=2 FROM ContratoOperacion
WHERE idOperacion IN(5, 6, 12, 13, 7, 8, 14, 15, 16, 20, 18, 26, 25, 32, 38, 36, 23, 33, 41, 35, 42, 44, 45, 47, 48, 53, 46, 56, 59, 60, 63, 49, 34, 39, 40, 43,51,52,54,55,85,87,89,
65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,86,88,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,61,64,108,107
)
go

