-- ==========================================================================================
-- Create date: 25/05/2018
-- exec [UPD_CANTIDAD_COTIZACION_DETALLE_SP] 13323, 3
-- ==========================================================================================
create PROCEDURE [dbo].[UPD_CANTIDAD_COTIZACION_DETALLE_SP]
	@idCotizacionDetalle INT,
	@cantidad INT
AS
BEGIN

	IF EXISTS(SELECT 1 FROM CotizacionDetalle WHERE idCotizacionDetalle=@idCotizacionDetalle)
		BEGIN	
			UPDATE CotizacionDetalle
			SET cantidad=@cantidad
			WHERE idCotizacionDetalle=@idCotizacionDetalle

			SELECT 
					idCotizacionDetalle,
					idCotizacion, 
					costo, 
					cantidad, 
					venta, 
					idPartida, 
					idEstatusPartida,
					'Cotizacion actualizada correctamente!' AS msg, 
					1 AS edo 
			FROM CotizacionDetalle 
			WHERE idCotizacionDetalle=@idCotizacionDetalle
		END
	ELSE
		BEGIN
			SELECT 'No existe la cotizacion buscada!' AS msg, 0 AS edo 
		END
END
go

