-- =============================================
-- Description:	Busca detalle de la orden 
-- [SEL_DETALLE_ORDEN_SP]@numeroOrden='03-1632012972999-000017'
-- =============================================
/****** Script for SelectTopNRows command from SSMS  ******/
--[dbo].[SEL_DETALLE_ORDEN_SP] @idUsuario = 2, @numeroOrden = '01-510052-115'
--[dbo].[SEL_DETALLE_ORDEN_SP] 133, '933462554'
CREATE PROCEDURE [dbo].[SEL_DETALLE_ORDEN_SP_bk20171027]
@idUsuario INT = 0,
@numeroOrden varchar(50)
AS
BEGIN
	
	DECLARE @cotizaciones TABLE (ID INT IDENTITY(1,1), idCotizacion INT)

	INSERT INTO @cotizaciones
	SELECT	idCotizacion
	FROM	[dbo].[Ordenes] ORD
			INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden
	WHERE	ORD.numeroOrden = @numeroOrden AND NOT COTI.idEstatusCotizacion = 4

	--SELECT * FROM @cotizaciones
	DECLARE @contador INT = 1, @numeroOrdenes INT = 0, @sumaCosto NUMERIC(18,2)=0, @sumaVenta NUMERIC(18,2)=0, @idCotizacion INT = 0
	SET @numeroOrdenes = (SELECT	COUNT(idCotizacion)
							FROM	[dbo].[Ordenes] ORD
									INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden
							WHERE	ORD.numeroOrden = @numeroOrden AND NOT	COTI.idEstatusCotizacion = 4)
	WHILE(@contador <= @numeroOrdenes)
		BEGIN
			SELECT @idCotizacion = idCotizacion FROM @cotizaciones WHERE ID = @contador 
			SET @sumaCosto = (SELECT SUM(costo * cantidad ) FROM [dbo].[CotizacionDetalle] WHERE idCotizacion = @idCotizacion AND NOT idEstatusPartida IN (3,4)) + @sumaCosto
			SET @sumaVenta = (SELECT SUM(venta * cantidad ) FROM [dbo].[CotizacionDetalle] WHERE idCotizacion = @idCotizacion AND NOT idEstatusPartida IN (3,4)) + @sumaVenta
			print @sumaCosto
			print @sumaVenta
			SET @contador = @contador + 1
		END
	
	SELECT 
		   Orden.idOrden
		  ,Orden.numeroOrden
		  ,Orden.comentarioOrden
		  ,Uni.numeroEconomico
		  ,Uni.placas
		  ,Uni.vin
		  ,Uni.gps
		  ,Uni.idUnidad
			,Uni.modelo
			,Uni.fecha as fechaModificacion
		  , Est.idEstatusOrden
		  ,CASE WHEN Orden.idGarantia = 1 AND Est.[idEstatusOrden] = 5 THEN 'En Proceso - Garantia' ELSE Est.[nombreEstatusOrden] END AS nombreEstatusOrden
		  ,(SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END FROM HistorialEstatusOrden WHERE idOrden = Orden.idOrden AND idEstatusOrden = 6 AND idUsuario = 514)migracion
		  --, Est.nombreEstatusOrden
		  ,Orden.idTaller
		  ,taller.nombreComercial
		  ,@sumaCosto AS CostoTotal
		  ,@sumaVenta AS VentaTotal
		  ,('Orden de ' + catTipOrd.nombreTipoOrdenServicio) as nombreTipoOrden
		  --,(SELECT [dbo].[SEL_ACCIONES_FN] (Orden.idOrden)) accion
		  ,isnull(A.texto, 'Sin Plan de Acción') accion
		  ,isnull(DATEADD(HH,5,A.fecha), '') fechaAccion
		  ,case when A.texto is null then 0 else 1 end hasAccion
			
			--Datos de la unidad
			--,UNIP.idUnidad,
			--,TU.idTipoUnidad,
			,TU.tipo as tipoUnidad,
			tco.tipoCombustible,
			tco.idTipoCombustible,
			cil.cilindros,
			cil.idCilindros,
			SM.nombre as subMarca,
			SM.idSubMarca,
			MA.nombre as marca,
			UNIP.foto as foto
			--Unidad
			
		  ,Z.nombre as nombreZona
		  ,orden.[motivoGarantia]
		  ,Orden.idGarantia
		  ,CT.nombreCentroTrabajo		  
		  ,Orden.idZona --LQMA add 11072017 
		  ,Uni.idTipoUnidad
		  ,Uni.verificada
			,Uni.idUnidad
			--,dbo.cadenaToken(@numeroOrden) as estatusToken
	  FROM [dbo].[Ordenes] Orden
			INNER JOIN [dbo].[CatalogoTiposOrdenServicio] catTipOrd ON catTipOrd.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio
			INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad
			INNER JOIN [dbo].[EstatusOrdenes] Est ON Orden.idEstatusOrden = Est.idEstatusOrden
			LEFT JOIN [dbo].Acciones A ON A.idOrden = Orden.idOrden and A.idEstatusOrden = Orden.idEstatusOrden
			LEFT JOIN [dbo].[CentroTrabajos] CT ON CT.idCentroTrabajo = Orden.idCentroTrabajo
			LEFT JOIN [Partidas].[dbo].[Proveedor] taller ON taller.idProveedor = Orden.idTaller
			INNER JOIN [dbo].[ContratoOperacion] CP ON Uni.idOperacion = CP.idOperacion
			INNER JOIN .[Partidas].[dbo].[ContratoUnidad] CU ON CU.idContrato = CP.idContrato AND CU.idUnidad = Uni.idTipoUnidad
			INNER JOIN .[Partidas].[dbo].[Unidad] UNIP ON UNIP.idUnidad = CU.idUnidad
			LEFT JOIN .[Partidas].dbo.SubMarca SM ON UNIP.idSubMarca = SM.idSubMarca 
			INNER JOIN .[Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca
			INNER JOIN .[Partidas].[dbo].[TipoUnidad] TU ON TU.idTipoUnidad = UNIP.idTipoUnidad
			LEFT JOIN .[Partidas].dbo.TipoCombustible tco ON tco.idTipoCombustible = UNIP.idTipoCombustible
			LEFT JOIN .[Partidas].dbo.Cilindros cil ON cil.idCilindros = UNIP.idCilindros
			LEFT JOIN [Partidas].[dbo].[Zona] Z ON Z.idZona = Orden.idZona
	WHERE Orden.numeroOrden = @numeroOrden




END
go

