create procedure [dbo].[SEL_TALLER_PRUEBA_SP]
AS
BEGIN
	SELECT * FROM Taller
END

go

