
-- ==========================================================================================
-- Author:		JORDAN GOMEZ
-- Create date: 11/01/2019
-- Description:	Store que registra un CONCAR como concluido (después de órden por pagar)
-- EXEC [INS_TRABAJO_CONCLUIDO_CONCAR_TOTAL_PARTS_SP] '5015399540', '27/12/2017', '27/03/2018', '03-10947-26658', 3, 1
-- ==========================================================================================
CREATE PROC [dbo].[INS_TRABAJO_CONCLUIDO_CONCAR_TOTAL_PARTS_SP]
	@numCopade nvarchar(50),
	@fechaCra nvarchar(10),
	@fecha nvarchar(10),
	@numeroOrden nvarchar(100),
	@idContratoOperacion numeric(18,0) = null,
	@isProduction NUMERIC(18,0)
AS
BEGIN
/*---------------------------------------*/
DECLARE @Base NVARCHAR(MAX) = ''
DECLARE @queryString NVARCHAR(MAX) = ''
DECLARE @ObsGen NVARCHAR(MAX) = ''
/*---------------------------------------*/
	DECLARE @SERVERNAME NVARCHAR(50)
	DECLARE @DBASE NVARCHAR(50)
	DECLARE @TABLES NVARCHAR(50)
	DECLARE @DIRECCION NVARCHAR(250)
/*---------------------------------------*/
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @max NUMERIC(18,0)
	DECLARE @NUMFACT NVARCHAR(50)
/*---------------------------------------*/

	if (@isProduction = 1)
		begin
			SELECT @Base = cast(COF.[SERVER]+'.'+DBProduccion as nvarchar(max))
			FROM ContratoOperacionFacturacion COF 
			WHERE COF.idContratoOperacion = @idContratoOperacion
		end
	else
		begin
			SELECT @Base = cast(COF.[SERVER]+'.'+DB as nvarchar(max))
			FROM ContratoOperacionFacturacion COF 
			WHERE COF.idContratoOperacion = @idContratoOperacion 
		end

	SELECT @idCotizacion = MIN(OTE_IDENT) FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = @numeroOrden
	SELECT @max = MAX(OTE_IDENT) FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = @numeroOrden

	WHILE(@idCotizacion <= @max)
		BEGIN	

		SELECT @NUMFACT = OTE_FACTURACOMPRA FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] WHERE OTE_IDENT = @idCotizacion

		DECLARE @ANIO NVARCHAR(100)
		DECLARE @Obs NVARCHAR(MAX) = ''
		DECLARE @DireccionCra NVARCHAR(MAX) = ''
		DECLARE @QueryCra NVARCHAR(MAX) = ''
		SET @ObsGen = 'No. Copade: ' + @numCopade + '//fecha de Recepción Copade: ' + @fechaCra + '//no. orden: ' + @numeroOrden;

		SELECT @ANIO=Vcc_AnNo FROM [192.168.20.29].[GAAutoExpress].[dbo].[VIS_CONCAR01] 
		WHERE CCP_TIPODOCTO = 'FAC' AND CCP_IDPERSONA = 84814 AND CCP_IDDOCTO = @NUMFACT

		SELECT 
			@SERVERNAME=server,
			@DBASE=db,
			@TABLES=tabla 
		FROM ConCar
		WHERE idContratoOperacion=3 AND fecha=@ANIO
		
		SET @DIRECCION = @SERVERNAME +'.'+@DBASE +'.[DBO].'+@TABLES

		SET @DireccionCra = '[192.168.20.29].[GACE_Concentra].[DBO].'+@TABLES
		
		set @queryString = '
		UPDATE '+@DIRECCION+'
        SET CCP_FECHPROMPAG='''+@fecha+''', CCP_OBSGEN = CCP_OBSGEN + '' *'+ @ObsGen +'*''
        WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDPERSONA = 84814 AND CCP_IDDOCTO='''+@NUMFACT+'''
        '
		PRINT @queryString
		EXECUTE SP_EXECUTESQL @queryString

		SET @QueryCra = '
		UPDATE '+@DireccionCra+'
        SET CCP_FECHPROMPAG='''+@fecha+''', CCP_OBSGEN = CCP_OBSGEN + '' *'+ @ObsGen +'*''
        WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDPERSONA = 1136 AND CCP_IDDOCTO LIKE (SELECT (''%''+ substring('''+ @NUMFACT +''', (LEN(''' + @NUMFACT + ''') - 3) , (LEN(''' + @NUMFACT +'''))) + ''%'' ))
        '
		PRINT @QueryCra
        --EXECUTE SP_EXECUTESQL @QueryCra

		SELECT @idCotizacion = MIN(OTE_IDENT) FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = @numeroOrden AND OTE_IDENT > @idCotizacion
		END
	

	

END
go

