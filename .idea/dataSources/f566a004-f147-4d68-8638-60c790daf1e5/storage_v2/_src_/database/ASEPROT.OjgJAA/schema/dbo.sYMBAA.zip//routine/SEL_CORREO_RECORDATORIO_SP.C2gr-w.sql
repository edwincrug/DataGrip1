-- [SEL_CORREO_RECORDATORIO_SP] 23072, 510
CREATE PROCEDURE [dbo].[SEL_CORREO_RECORDATORIO_SP] 
@idOrden NUMERIC(18,0) = 7,
@idUsuario NUMERIC(18,0) = 9
AS
BEGIN

	DECLARE @estatusI VARCHAR(50) = '', 
			@estatusF VARCHAR(50) = '',
			@nombreEstatusOrden VARCHAR(50) = ''
/*
	SELECT TOP(1)  @estatusF = ESTOR.nombreEstatusOrden 
	FROM HistorialEstatusOrden ORD
	LEFT JOIN EstatusOrdenes ESTOR ON ORD.idEstatusOrden = ESTOR.idEstatusOrden
	WHERE ORD.idOrden = @idOrden 
	ORDER BY ORD.idHistorialEstatusOrden DESC
	
	SELECT TOP(1) @estatusI = ESTOR.nombreEstatusOrden
	FROM HistorialEstatusOrden ORD
	LEFT JOIN EstatusOrdenes ESTOR ON ORD.idEstatusOrden = ESTOR.idEstatusOrden
	WHERE ORD.idOrden = @idOrden  
	  AND ORD.idHistorialEstatusOrden < (SELECT TOP(1) idHistorialEstatusOrden 
	                                 FROM HistorialEstatusOrden 
									 WHERE idOrden = @idOrden ORDER BY idHistorialEstatusOrden DESC) 
	ORDER BY ORD.idHistorialEstatusOrden DESC	
*/
	SELECT @nombreEstatusOrden = EO.nombreEstatusOrden
	FROM Ordenes O
	JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
	WHERE O.idOrden = @idOrden

	DECLARE @html NVARCHAR(MAX) = '',
			@cadena NVARCHAR(MAX) = '',
			@nombreCompleto NVARCHAR(500) = '', 
			@numeroOrden NVARCHAR(500) = '',
			@destinatarios VARCHAR(500) = '', 
			@idEstatusOrden INT,
			@idUnidad INT,
			@numeroEconomico VARCHAR(500),
			@vin VARCHAR(500)

	SELECT @nombreCompleto = nombreCompleto,
		   @cadena = correoElectronico
	FROM Usuarios 
	WHERE idUsuario=@idUsuario

	SELECT @numeroOrden = numeroOrden,
		   @idEstatusOrden = idEstatusOrden,
		   @idUnidad = idUnidad
	FROM Ordenes 
	WHERE idOrden=@idOrden

	SELECT  @numeroEconomico=numeroEconomico, 
			@vin=vin 
	FROM Unidades 
	WHERE idUnidad = @idUnidad


	DECLARE @texto VARCHAR(500)
	IF(@idEstatusOrden = 1)
		SET @texto = 'Se ha agendado una cita sin taller para la unidad ' + @numeroEconomico + ' con número de orden ' + @numeroOrden + ' en estatus ' + @nombreEstatusOrden
	IF(@idEstatusOrden = 2)
		SET @texto = 'Tiene una cita con taller para la unidad ' + @numeroEconomico + ' con el número de orden ' + @numeroOrden + ' en estatus ' + @nombreEstatusOrden
	IF(@idEstatusOrden = 3)
		SET @texto = 'La unidad ' + @numeroEconomico + ' esta en taller, con el número de orden ' + @numeroOrden + ' en estatus ' + @nombreEstatusOrden
	IF(@idEstatusOrden = 4)
		SET @texto = 'Se encuentra en aprobación la orden ' + @numeroOrden --+ ' en estatus ' + @nombreEstatusOrden
	IF(@idEstatusOrden = 5)
		SET @texto = 'Se autorizo y se encuentra en proceso la orden ' + @numeroOrden --+ ' en estatus ' + @nombreEstatusOrden
	IF(@idEstatusOrden = 6)
		SET @texto = 'Se terminó el trabajo de la orden ' + @numeroOrden + ' en estatus ' + @nombreEstatusOrden
	IF(@idEstatusOrden = 7)
		SET @texto = 'La orden ' + @numeroOrden + 'se encuentra en estatus ' + @nombreEstatusOrden
	IF(@idEstatusOrden = 8)
		SET @texto = 'La orden ' + @numeroOrden + 'se encuentra en estatus ' + @nombreEstatusOrden
	IF(@idEstatusOrden = 12)
		SET @texto = 'El trabajo con número de orden ' + @numeroOrden + ' finalizó ' -- + @nombreEstatusOrden
	IF(@idEstatusOrden = 13)
		SET @texto = 'Se canceló el número de orden ' + @numeroOrden + ' en estatus ' + @nombreEstatusOrden
	-- SELECT * FROM EstatusOrdenes

	--DECLARE @texto VARCHAR(200) = 'La orden ' + @numeroOrden + ' ha cambio ' +  + ' al estatus ' + @nombreEstatusOrden
	DECLARE @tallerDiv VARCHAR(1000) = '', 
			@nombreTaller VARCHAR(100) = '',
			@nombreZona VARCHAR(100) = ''

	SELECT @nombreZona = ISNULL(Z.nombre, 'Sin zona asignada')
	FROM Ordenes ORD
	LEFT JOIN [Partidas]..[Zona] Z ON ORD.idZona = Z.idZona
	WHERE ORD.idOrden = @idOrden


	IF EXISTS(SELECT * FROM Ordenes WHERE idTaller <> 0 AND idOrden = @idOrden)
		BEGIN
			SELECT @nombreTaller = PRO.nombreComercial 
			FROM Ordenes ORD
			LEFT JOIN [Partidas]..[Proveedor] PRO ON ORD.idTaller = PRO.idProveedor
			WHERE ORD.idOrden = @idOrden

			SET @tallerDiv = '<div style="font-size: 14px;color: #0489B1;margin-left: 10px;margin-top: 10px;">
								Taller: <span  style="font-size: 14px;color: #000000;">'+ @nombreTaller +'</span>
							  </div>'
		END

	SET @html='
	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
	<body>
		<div style="font-family: Arial;">
			<div style="font-size: 16px;color: #0489B1;margin-left: 10px; text-align: center;">
					<h3>Notificación para ' + @nombreCompleto + ' de la orden '+ @numeroOrden +' </h3>
				</div>
				<div style="font-family: sans-serif;font-size: 14px;color: #2F4F4F;margin-left: 50px;">
			
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Orden: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ @texto +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px;margin-top: 10px;">
					Usuario: <span  style="font-size: 14px;color: #000000;">'+ @nombreCompleto +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Número de  Orden: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ @numeroOrden +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Zona: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ @nombreZona +'</span>
				</div>'
				+ @tallerDiv +
				'<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Fecha Proceso: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ CONVERT(VARCHAR(24),GETDATE(), 120 ) +'</span>
				</div>
		</div>
	</body>
	</html> '
	
	DECLARE @aux INT = 1, @max DECIMAL (18,0) = 0		
	DECLARE @correos VARCHAR(900) = ''

	DECLARE @correosTabla TABLE(id INT IDENTITY(1,1), correo VARCHAR(50))

	DECLARE @idContratoOperacion INT
	SELECT @idContratoOperacion=idContratoOperacion FROM Ordenes WHERE idOrden=@idOrden

	IF(@idEstatusOrden = 5)
		BEGIN
		IF @idContratoOperacion<>32
			BEGIN
			INSERT INTO @correosTabla
			SELECT correoElectronico FROM Usuarios 
			WHERE idUsuario IN ((SELECT idUsuario FROM Ordenes WHERE idOrden = @idOrden),@idUsuario)
			union
			SELECT correoElectronico FROM Usuarios where idUsuario IN(155)
			END
			ELSE
			BEGIN
			INSERT INTO @correosTabla
			SELECT correoElectronico FROM Usuarios WHERE idUsuario IN(1122,1123,1124,1434) /*CONFIG PARA ATLAS COPCO*/
			union
			SELECT correoElectronico FROM Usuarios where idUsuario =@idUsuario
			END
			--union 
			--select correoElectronico
			--from Usuarios u 
			--inner join ContratoOperacionUsuario cou on cou.idUsuario = u.idUsuario and cou.idContratoOperacion in (select idContratoOperacion from Ordenes where idOrden = @idOrden) 
			--inner join ContratoOperacionUsuarioZona couz on cou.idContratoOperacionUsuario = couz.idContratoOperacionUsuario
			--where couz.idZona in (select idZona from Ordenes where idOrden = @idOrden) and cou.idCatalogoRol = 1 and correoElectronico is not null
	
		END
	ELSE
		BEGIN

			IF @idContratoOperacion<>32
			BEGIN
			INSERT INTO @correosTabla
			SELECT correoElectronico FROM Usuarios 
			WHERE idUsuario IN ((SELECT idUsuario FROM Ordenes WHERE idOrden = @idOrden),@idUsuario)
			union
			SELECT correoElectronico FROM Usuarios where idUsuario IN(155)
			--UNION
			--SELECT 'jgarcia@bism.com.mx'
			--union
			--select correoElectronico
			--from Usuarios u 
			--inner join ContratoOperacionUsuario cou on cou.idUsuario = u.idUsuario and cou.idContratoOperacion in (select idContratoOperacion from Ordenes where idOrden = @idOrden) 
			--inner join ContratoOperacionUsuarioZona couz on cou.idContratoOperacionUsuario = couz.idContratoOperacionUsuario
			--where couz.idZona in (select idZona from Ordenes where idOrden = @idOrden) and cou.idCatalogoRol = 1 and correoElectronico is not null
			END
			ELSE
			BEGIN
			INSERT INTO @correosTabla
			SELECT correoElectronico FROM Usuarios WHERE idUsuario IN(1122,1123,1124,1434) /*CONFIG PARA ATLAS COPCO*/
			union
			SELECT correoElectronico FROM Usuarios where idUsuario =@idUsuario
			END
	
		END

	SELECT @max = MAX(id), @aux = MIN(id) FROM @correosTabla

		WHILE(@aux <= @max)
		BEGIN 
			SELECT @correos = @correos + ',<' + correo + '>' FROM @correosTabla
			WHERE id = @aux
		
			SET @aux = @aux + 1
		END

	SET @correos = SUBSTRING(@correos,2,LEN(@correos))

	--SELECT @correos
	INSERT INTO HistorialNotificaciones VALUES(@idUsuario,@idOrden,NULL,@idEstatusOrden,GETDATE(),@correos,@html)
	--select * from HistorialNotificaciones
	
	SELECT 'noreply@centraldeoperaciones.com' correoDe, @correos correoPara, 
		   @html bodyhtml, 'Orden' asunto, 'Ordenes' texto  

END
--GO
--exec [SEL_CORREO_RECORDATORIO_SP] 69653, 988
--EXEC [SEL_CORREO_RECORDATORIO_SP] 70221, 988
go

