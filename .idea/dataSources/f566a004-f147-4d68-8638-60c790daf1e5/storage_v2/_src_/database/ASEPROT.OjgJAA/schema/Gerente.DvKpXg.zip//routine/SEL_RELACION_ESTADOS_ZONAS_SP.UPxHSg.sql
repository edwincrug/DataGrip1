 CREATE PROCEDURE [Gerente].[SEL_RELACION_ESTADOS_ZONAS_SP]
	@idContratoOperacion INT = 0
AS
BEGIN

	DECLARE @nivelZonas INT =
	(SELECT COUNT (DISTINCT ZO.idNivelZona) FROM [Partidas].[dbo].[Zona] ZO
			 JOIN [Partidas].[dbo].[nivelZona] NZ ON ZO.idNivelZona = NZ.idNivelZona
			 JOIN [Partidas].[dbo].[licitacion] LI ON LI.idCliente = NZ.idCliente
			 JOIN [Partidas].[dbo].[contrato] CON ON LI.idLicitacion = CON.idLicitacion
			 JOIN ContratoOperacion CO ON CO.idContrato = CON.idContrato
	WHERE CO.idContratoOperacion = @idContratoOperacion)

	IF(@nivelZonas = 1)
		BEGIN
			IF(@idContratoOperacion = 0)
				BEGIN
					SELECT	EZ.idEstadoZona, 
							E.nombreEstado, 
							E.descripcionEstado, 
							--(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  
							ZO.nombre AS nombre,
							EZ.fechaAlta, 
							U.nombreCompleto, 
							C.descripcion, 
							CO.idContratoOperacion,
							E.idEstados,
							ZO.idZona
					FROM [Gerente].[EstadoZona] EZ
						JOIN [Gerente].[Estados] E ON E.idEstados = EZ.idEstado
						JOIN [Partidas]..[Zona] ZO ON ZO.idZona = EZ.idZona
						JOIN [Usuarios] U ON U.idUsuario = EZ.idUsuario
						JOIN [ContratoOperacion] CO ON CO.idContratoOperacion = EZ.idContratoOperacion
						JOIN [Partidas]..[Contrato] C ON C.idContrato = CO.idContrato
					WHERE EZ.estatus=0 --AND ZO.idPadre <> 0
				END
			ELSE
				BEGIN
					SELECT	EZ.idEstadoZona, 
							E.nombreEstado, 
							E.descripcionEstado, 
							--(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  
							ZO.nombre AS nombre,
							EZ.fechaAlta, 
							U.nombreCompleto, 
							C.descripcion, 
							CO.idContratoOperacion,
							E.idEstados,
							ZO.idZona
					FROM [Gerente].[EstadoZona] EZ
						JOIN [Gerente].[Estados] E ON E.idEstados = EZ.idEstado
						JOIN [Partidas]..[Zona] ZO ON ZO.idZona = EZ.idZona
						JOIN [Usuarios] U ON U.idUsuario = EZ.idUsuario
						JOIN [ContratoOperacion] CO ON CO.idContratoOperacion = EZ.idContratoOperacion
						JOIN [Partidas]..[Contrato] C ON C.idContrato = CO.idContrato
					WHERE EZ.estatus=0 AND EZ.idContratoOperacion = @idContratoOperacion --AND ZO.idPadre <> 0
				END
		END
	ELSE
		BEGIN
			IF(@idContratoOperacion = 0)
				BEGIN
					SELECT	EZ.idEstadoZona, 
							E.nombreEstado, 
							E.descripcionEstado, 
							(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  ZO.nombre AS nombre,
							EZ.fechaAlta, 
							U.nombreCompleto, 
							C.descripcion, 
							CO.idContratoOperacion,
							E.idEstados,
							ZO.idZona
					FROM [Gerente].[EstadoZona] EZ
						JOIN [Gerente].[Estados] E ON E.idEstados = EZ.idEstado
						JOIN [Partidas]..[Zona] ZO ON ZO.idZona = EZ.idZona
						JOIN [Usuarios] U ON U.idUsuario = EZ.idUsuario
						JOIN [ContratoOperacion] CO ON CO.idContratoOperacion = EZ.idContratoOperacion
						JOIN [Partidas]..[Contrato] C ON C.idContrato = CO.idContrato
					WHERE EZ.estatus=0 AND ZO.idPadre <> 0
				END
			ELSE
				BEGIN
					SELECT	EZ.idEstadoZona, 
							E.nombreEstado, 
							E.descripcionEstado, 
							(SELECT nombre FROM Partidas.dbo.Zona Z WHERE Z.idZona = ZO.idPadre) + ' - ' +  ZO.nombre AS nombre,
							EZ.fechaAlta, 
							U.nombreCompleto, 
							C.descripcion, 
							CO.idContratoOperacion,
							E.idEstados,
							ZO.idZona
					FROM [Gerente].[EstadoZona] EZ
						JOIN [Gerente].[Estados] E ON E.idEstados = EZ.idEstado
						JOIN [Partidas]..[Zona] ZO ON ZO.idZona = EZ.idZona
						JOIN [Usuarios] U ON U.idUsuario = EZ.idUsuario
						JOIN [ContratoOperacion] CO ON CO.idContratoOperacion = EZ.idContratoOperacion
						JOIN [Partidas]..[Contrato] C ON C.idContrato = CO.idContrato
					WHERE EZ.estatus=0 AND EZ.idContratoOperacion = @idContratoOperacion AND ZO.idPadre <> 0
				END
		END
END


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.SEL_RELACION_ESTADOS_ZONAS_SP to DevOps
 go

