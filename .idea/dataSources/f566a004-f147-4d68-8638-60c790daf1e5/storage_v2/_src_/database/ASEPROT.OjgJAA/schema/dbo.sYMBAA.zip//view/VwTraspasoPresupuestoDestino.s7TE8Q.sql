create VIEW [dbo].[VwTraspasoPresupuestoDestino]
AS
SELECT SUM(monto) AS Acumulado, idPresupuestoDestino
FROM     dbo.TraspasoPresupuesto
GROUP BY idPresupuestoDestino
go

