

-- ==========================================================================================
-- Author:		Sahirely Yam
-- Create date: 09/10/2017
-- Description:	Store que obtiene las copades sin asignación

-- [SEL_COPADES_SP] 3, 510, 0
--[SEL_COPADES_SP] 57, 538, 1
-- ==========================================================================================

CREATE PROC [dbo].[SEL_COPADES_SP]
	@idContratoOperacion numeric(18,0),
	@idUsuario numeric(18,0),
	@isProduction numeric(18,0)
	AS

	--For Test of Performance 
	--alcabelu 20171025
	SET transaction isolation level read uncommitted

	SELECT 
		idDatosCopade,
		ordenSurtimiento,
		numeroEstimacion,
		subTotal,
		ISNULL(total,'0.00')as total,
		DATEADD(hh,5,fechaCarga)as fechaCarga,
		xmlCopade,
		convert(varchar, convert(datetime, fechaRecepcionCopade), 103) as fechaRecepcionCopade,
		numeroCopade
		FROM DatosCopade 
	WHERE NOT EXISTS
		(
			SELECT 
				idDatosCopade 
			FROM DatosCopadeOrden 
			where DatosCopadeOrden.idDatosCopade=DatosCopade.idDatosCopade
		)
		and idContratoOperacion = @idContratoOperacion
go

