-- select [dbo].[SEL_PRECIO_COSTO_COT_V2_V3_FN](206612)
create FUNCTION [dbo].[SEL_PRECIO_COSTO_COT_V2_V3_FN](@idCotizacion INT)--, @idContratoOperacion INT, @idUsuario INT, @idRol INT)

RETURNS NUMERIC(18,2)
AS
BEGIN
DECLARE @costo NUMERIC(18,2) = 0
DECLARE @numero TABLE(estatusCotizacion int, estatusPartida int)

insert @numero values(3, 2)

		SELECT @costo=ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
			INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		WHERE CD.idCotizacion = @idCotizacion 
		AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
		AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero)	
	
	RETURN @costo

END
go

