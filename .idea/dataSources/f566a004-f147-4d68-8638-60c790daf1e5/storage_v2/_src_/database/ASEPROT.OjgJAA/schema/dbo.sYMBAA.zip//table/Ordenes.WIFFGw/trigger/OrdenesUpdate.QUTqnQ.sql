
CREATE TRIGGER [dbo].[OrdenesUpdate]
ON [dbo].[Ordenes]
AFTER UPDATE
AS 
BEGIN
  SET NOCOUNT ON;


   UPDATE O
   SET [HostUpdate] = HOST_NAME(),
       [DateUpdate] = GETDATE(),
       --[ColumnsUpdate] = SUBSTRING(COLUMNS_UPDATED(),1,299)
	   [ColumnsUpdate] = 'Status Old ' + Cast(d.idEstatusOrden as nvarchar(10))
   FROM [dbo].[Ordenes] AS O
   INNER JOIN inserted AS i
   ON O.[idOrden] = i.[idOrden]
   INNER JOIN Deleted d 
      ON O.[idOrden] = d.[idOrden]

   UPDATE O
   SET [idZona] = 3548,
	   [storedProcedureUpdate] = 'i'
   FROM [dbo].[Ordenes] AS O
   INNER JOIN inserted AS i
   ON O.[idOrden] = i.[idOrden]
   INNER JOIN Deleted d 
      ON O.[idOrden] = d.[idOrden]
   WHERE O.idContratoOperacion = 26 AND O.idZona < 3500

END
go

