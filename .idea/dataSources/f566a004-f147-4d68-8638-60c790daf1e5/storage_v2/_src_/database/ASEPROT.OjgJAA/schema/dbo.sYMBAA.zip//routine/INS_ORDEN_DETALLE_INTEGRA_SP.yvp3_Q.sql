/*
SELECT * FROM [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERenc]
SELECT * FROM [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERdet]
select * from Cotizaciones where numeroCotizacion='01-3110073-126-2'
[INS_ORDEN_DETALLE_INTEGRA_SP] 13,13,1,1,0
*/
CREATE PROCEDURE [dbo].[INS_ORDEN_DETALLE_INTEGRA_SP]
	@idCotizacion NUMERIC(18,0) = 0,
	@idEncabezado NUMERIC(18,0) = 0,	
	@tipoDetalle SMALLINT = 1,-- 1: servicio, 2: refacciones
	@idOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0)
AS
BEGIN	

DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE	@query NVARCHAR(MAX)
DECLARE @idContratoOperacion VARCHAR(5)

SELECT @idContratoOperacion=idContratoOperacion FROM ContratoOperacion WHERE idOperacion=@idOperacion

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DBProduccion
		FROM ContratoOperacionFacturacion 
		WHERE idContratoOperacion=@idContratoOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB
		FROM ContratoOperacionFacturacion 
		WHERE idContratoOperacion=@idContratoOperacion
	END

    IF(@tipoDetalle = 1) -- SERVICIO
		BEGIN
			SET @query = 'INSERT INTO'+@server+'.'+@db+'.[dbo].[ADE_ORDSERDET](
						[OTD_IDENT],
						[OTD_CONSECUTIVO],
						[OTD_DESCRIPCION],
						[OTD_CANTIDAD],
						[OTD_PRECIOUNITARIOCOMPRA],
						[OTD_SUBTOTALUNITARIO],
						[OTD_IVAUNITARIO],
						[OTD_TOTALUNITARIO],
						[OTD_PRECIOUNITARIOVENTA],
						[OTD_FECHOPE],
						[OTD_HORAOPE],
						[OTD_FAMILIA])
				SELECT 				   
					   '+CAST(@idEncabezado AS NVARCHAR(30))+',
					   ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
					   P.descripcion, --OTD_DESCRIPCION
					   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD				   
					   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
					   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
					   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
					   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
					   CAST(CD.venta AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
					   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
					   CONVERT(VARCHAR(8),GETDATE(),108), --hora de la base
					   ''''
				   	FROM Ordenes O
						JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
						JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
						JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
						WHERE C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)
						GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida'

			EXECUTE SP_EXECUTESQL @query
		END
END
go

