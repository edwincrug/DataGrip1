/*
CREATE DATE 17-01-2018
DESC Actualiza los estatus de las ordenes si no corresponden con su correspondiente TP
[UPD_ESTATUS_ORDENES_TOTALPARTS] 
*/
CREATE PROC [dbo].[UPD_ESTATUS_ORDENES_TOTALPARTS]
AS
BEGIN

	DECLARE @idOrden INT
	DECLARE @idTaller INT
	DECLARE @existe INT = 0

	DECLARE contact_cursor CURSOR FOR
	SELECT DISTINCT O.idOrden, C.idTaller FROM Ordenes O
	JOIN Cotizaciones C ON C.idOrden = O.idOrden
	WHERE C.idTaller in(291,292,293,294,970) AND O.idContratoOperacion = 1 --AND O.idEstatusOrden=8

	OPEN contact_cursor  
	FETCH NEXT FROM contact_cursor INTO @idOrden, @idTaller
	WHILE @@FETCH_STATUS = 0  
		BEGIN 		

			DECLARE @numeroOrden NVARCHAR(100)
			DECLARE @idEstatusOrden INT
			DECLARE @NuevoEstatus INT;
			DECLARE @idHistorico NUMERIC(18,0);
			DECLARE @server NVARCHAR(100)
			DECLARE @db NVARCHAR(100)

			SELECT 
					@server = SERVER,
					@db = DBProduccion
			FROM CatalogoTecnico CT 
			WHERE CT.IdProveedor =  @idTaller

			SELECT 
				@numeroOrden=numeroOrden, 
				@idEstatusOrden=idEstatusOrden 
			FROM Ordenes 
			WHERE idOrden=@idOrden

		IF(@idEstatusOrden = 8)
			BEGIN
			PRINT 'ENTRA EN EL ESTATUS 8 ORDEN'
			PRINT @idOrden
				declare @queryText varchar(max) = 
				'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE [oae_ordenglobal] = '''+@numeroOrden+''' AND oae_estatus=1) THEN 1 ELSE 0 END' 
			
				declare @tableTemp table (val int)
				insert into @tableTemp exec(@queryText) 
						
				set @existe = (select top 1 val from @tableTemp)

				IF(@existe = 1)
					BEGIN
						SET @NuevoEstatus = (@idEstatusOrden + 1)
						SET @idHistorico = (SELECT TOP 1 idHistorialEstatusOrden FROM HistorialEstatusOrden WHERE idOrden = @idOrden AND idEstatusOrden = @idEstatusOrden ORDER BY idHistorialEstatusOrden DESC );

						UPDATE HistorialEstatusOrden 
						SET fechaFinal = GETDATE() 
						WHERE idHistorialEstatusOrden = @idHistorico;
				
						INSERT INTO HistorialEstatusOrden 
						VALUES( @idOrden, @NuevoEstatus, GETDATE(), NULL, 551);
				
						UPDATE Ordenes 
						SET idEstatusOrden = @NuevoEstatus 
						WHERE idOrden = @idOrden;

						SET @idEstatusOrden = @NuevoEstatus 
					END
			END
		IF (@idEstatusOrden = 9)
			BEGIN
			PRINT 'ENTRA EN EL ESTATUS 9 ORDEN'
			PRINT @idOrden
				DECLARE @SELECT1 nvarchar(MAX)

				/*SELECT OS.ORE_STATUS 
				FROM [192.168.20.31].[GATPARTSDHLGDL].[dbo].ser_ordenesaseenc E 
				INNER JOIN [192.168.20.31].[GATPARTSDHLGDL].[dbo].SER_ORDEN OS ON OS.ORE_IDORDEN = E.oae_ordenbpro
				WHERE e.oae_ordenglobal = '01-1410070-1413'
				*/
				SET @SELECT1 = 
				'SELECT OS.ORE_STATUS 
				FROM '+@server+'.'+@db+'.[dbo].ser_ordenesaseenc E 
				INNER JOIN '+@server+'.'+@db+'.[dbo].SER_ORDEN OS ON OS.ORE_IDORDEN = E.oae_ordenbpro
				WHERE e.oae_ordenglobal = '''+@numeroOrden+''' '

				DECLARE @suTabla1 TABLE(estado NVARCHAR(10))

				INSERT INTO @suTabla1
				execute SP_EXECUTESQL @SELECT1

				DECLARE @statusBpro NVARCHAR(10) = (SELECT estado FROM @suTabla1)
				PRINT @statusBpro
				IF (@statusBpro = 'T' OR @statusBpro='I')	
					BEGIN

						SET @NuevoEstatus = (@idEstatusOrden + 1)
						SET @idHistorico = (SELECT TOP 1 idHistorialEstatusOrden FROM HistorialEstatusOrden WHERE idOrden = @idOrden AND idEstatusOrden = @idEstatusOrden ORDER BY idHistorialEstatusOrden DESC );

						UPDATE HistorialEstatusOrden 
						SET fechaFinal = GETDATE() 
						WHERE idHistorialEstatusOrden = @idHistorico;
				
						INSERT INTO HistorialEstatusOrden 
						VALUES( @idOrden, @NuevoEstatus, GETDATE(), NULL, 551);
				
						UPDATE Ordenes 
						SET idEstatusOrden = @NuevoEstatus 
						WHERE idOrden = @idOrden;

						SET @idEstatusOrden = @NuevoEstatus 

					END
			END
		 IF(@idEstatusOrden = 10 OR @idEstatusOrden = 11)
			BEGIN
			DECLARE @SELECT nvarchar(MAX)

			SET @SELECT = 
				'SELECT 
				''SALDO'' = CASE CARTERA.PAR_IDMODULO
										   when ''CXC''
										   then ccp_cargo-ccp_abono + (Select isnull(sum(CCP_CARGO-CCP_ABONO),0)
					from '+@server+'.'+@db+'.[dbo].VIS_CONCAR01 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO
					AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA
					AND MOVIMIENTO.CCP_DOCORI<>''S'' )
										   else ccp_abono-ccp_cargo+(Select isnull(sum(CCP_ABONO-CCP_CARGO),0)
					from '+@server+'.'+@db+'.[dbo].VIS_CONCAR01 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO
							   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA
							   AND MOVIMIENTO.CCP_DOCORI<>''S'')
							   end
				FROM '+@server+'.'+@db+'.[dbo].VIS_CONCAR01 AS DOCUMENTO 
				LEFT OUTER JOIN '+@server+'.'+@db+'.[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA=''CARTERA''  
				INNER JOIN '+@server+'.'+@db+'.[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA 
				LEFT OUTER JOIN '+@server+'.'+@db+'.[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = ''TIMO''  
				LEFT OUTER JOIN '+@server+'.'+@db+'.[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL AND VTE_STATUS=''I'' AND CCP_IDPERSONA = VTE_IDCLIENTE  
				JOIN '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] E ON E.oae_ordenbpro = vte_referencia1
				WHERE CCP_TIPODOCTO = ''FAC'' AND E.oae_ordenglobal='''+@numeroOrden +''' '

				DECLARE @suTabla TABLE(saldo nvarchar(30))

				INSERT INTO @suTabla
				execute SP_EXECUTESQL @SELECT

				DECLARE @saldo numeric(18,2) = convert(numeric(18,2),(SELECT saldo FROM @suTabla))

				IF(@saldo IS NOT NULL)
				BEGIN
					IF(@idEstatusOrden = 10)
						BEGIN
							IF(@saldo >= 0)
								PRINT 'ENTRA EN EL ESTATUS 10 ORDEN'
								PRINT @idOrden
								SET @NuevoEstatus = (@idEstatusOrden + 1)
								SET @idHistorico = (SELECT TOP 1 idHistorialEstatusOrden FROM HistorialEstatusOrden WHERE idOrden = @idOrden AND idEstatusOrden = @idEstatusOrden ORDER BY idHistorialEstatusOrden DESC );
								UPDATE HistorialEstatusOrden 
								SET fechaFinal = GETDATE() 
								WHERE idHistorialEstatusOrden = @idHistorico;
				
								INSERT INTO HistorialEstatusOrden 
								VALUES( @idOrden, @NuevoEstatus, GETDATE(), NULL, 551);
				
								UPDATE Ordenes 
								SET idEstatusOrden = @NuevoEstatus 
								WHERE idOrden = @idOrden;

								SET @idEstatusOrden = @NuevoEstatus 
						
						END
					IF(@idEstatusOrden = 11)
						BEGIN
							IF(@saldo = 0)
							PRINT 'ENTRA EN EL ESTATUS 11 ORDEN'
							PRINT @idOrden
								SET @NuevoEstatus = (@idEstatusOrden + 1)
								SET @idHistorico = (SELECT TOP 1 idHistorialEstatusOrden FROM HistorialEstatusOrden WHERE idOrden = @idOrden AND idEstatusOrden = @idEstatusOrden ORDER BY idHistorialEstatusOrden DESC );
								UPDATE HistorialEstatusOrden 
								SET fechaFinal = GETDATE() 
								WHERE idHistorialEstatusOrden = @idHistorico;
				
								INSERT INTO HistorialEstatusOrden 
								VALUES( @idOrden, @NuevoEstatus, GETDATE(), NULL, 551);
				
								UPDATE Ordenes 
								SET idEstatusOrden = @NuevoEstatus 
								WHERE idOrden = @idOrden;

								SET @idEstatusOrden = @NuevoEstatus 

						END
				  END
			END

		FETCH NEXT FROM contact_cursor INTO @idOrden, @idTaller
		END  
	CLOSE contact_cursor  
	DEALLOCATE contact_cursor

END


/*
select CARTERA.PAR_IDMODULO MODULO,
             CARTERA.PAR_DESCRIP1 DES_CARTERA,
             TIMO.PAR_DESCRIP1 DES_TIPODOCTO,  
             CCP_IDDOCTO,CCP_NODOCTO,
             CCP_IDPERSONA,  
             rtrim(ltrim(PER_PATERNO + ' ' + PER_MATERNO + ' ' + PER_NOMRAZON)) as Nombre,  
             PER_TELEFONO1,
             CCP_FECHVEN,
             CCP_FECHPAG,
             CCP_FECHPROMPAG,
             CCP_FECHREV,
             'IMPORTE' = CASE CARTERA.PAR_IDMODULO 
                                         when 'CXC' 
                                         then ccp_cargo-ccp_abono 
                                         else ccp_abono-ccp_cargo 
                                         end,  
             'SALDO' = CASE CARTERA.PAR_IDMODULO 
                                        when 'CXC' 
                                        then ccp_cargo-ccp_abono + (Select isnull(sum(CCP_CARGO-CCP_ABONO),0) 
                 from [192.168.20.31].[GATPartsDHLGdl].[dbo].VIS_CONCAR01 as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO 
                 AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA 
                 AND MOVIMIENTO.CCP_DOCORI<>'S' ) 
                                        else ccp_abono-ccp_cargo+(Select isnull(sum(CCP_ABONO-CCP_CARGO),0) 
                 from [192.168.20.31].[GATPartsDHLGdl].[dbo].VIS_CONCAR01 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO 
                            AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA 
                            AND MOVIMIENTO.CCP_DOCORI<>'S') 
                            end,  
                            CCP_FECHADOCTO,
                 CCP_FECHVEN,
                 CCP_TIPODOCTO,
                 CCP_ORIGENCON

FROM [192.168.20.31].[GATPartsDHLGdl].[dbo].VIS_CONCAR01 AS DOCUMENTO 
LEFT OUTER JOIN [192.168.20.31].[GATPartsDHLGdl].[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA='CARTERA'  
INNER JOIN [192.168.20.31].[GATPartsDHLGdl].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA 
LEFT OUTER JOIN [192.168.20.31].[GATPartsDHLGdl].[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = 'TIMO'  
LEFT OUTER JOIN [192.168.20.31].[GATPartsDHLGdl].[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL AND VTE_STATUS='I' AND CCP_IDPERSONA = VTE_IDCLIENTE  
JOIN [192.168.20.31].[GATPartsDHLGdl].[dbo].[ser_ordenesaseenc] E ON E.oae_ordenbpro = vte_referencia1
WHERE CCP_TIPODOCTO = 'FAC' AND E.oae_ordenglobal='01-1410070-1413'
*/
go

