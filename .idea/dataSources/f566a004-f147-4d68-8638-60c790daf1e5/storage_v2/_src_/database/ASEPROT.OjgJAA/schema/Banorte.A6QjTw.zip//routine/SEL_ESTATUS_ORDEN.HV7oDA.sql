-- =============================================
-- Author:		<YJH>
-- Create date: <2018/12/07>
-- Description:	<Obtiene el estatus de una orden>
-- [BANORTE].[SEL_ESTATUS_ORDEN] 40303
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_ESTATUS_ORDEN]
	@idOrden INT	
AS
BEGIN
	SET NOCOUNT ON;	
	BEGIN TRY 
		DECLARE @idEstatus int 
		DECLARE @descripcion nvarchar(100)

		SELECT @idEstatus = O.idEstatusOrden, @descripcion = EO.nombreEstatusOrden from Ordenes O 
		inner join EstatusOrdenes EO on O.idEstatusOrden=EO.idEstatusOrden
		where O.idOrden = @idOrden
					
		select @idEstatus as idEstatus, @descripcion as descripcion

	END TRY 	
	BEGIN CATCH	
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.SEL_ESTATUS_ORDEN to DevOps
go

