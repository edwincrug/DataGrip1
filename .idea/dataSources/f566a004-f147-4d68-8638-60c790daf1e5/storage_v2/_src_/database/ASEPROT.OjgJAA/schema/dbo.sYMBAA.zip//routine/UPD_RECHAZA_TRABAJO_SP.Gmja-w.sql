
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 08/06/2017
-- Description:	Store para rechazar un trabajo realizando el cambio de estatus de 
--              la orden a 5 y dejando en el Historico el paso de un estatus a otro
-- ==========================================================================================

CREATE PROCEDURE [dbo].[UPD_RECHAZA_TRABAJO_SP]
    @idOrden NUMERIC( 19,0 ),
    @idUsuario NUMERIC( 19,0 ),
	@motivo NVARCHAR (MAX)
AS   
BEGIN
	-- DECLARE @idOrden NUMERIC( 19,0 );
	-- SET @idOrden = 107;

	-- DECLARE @idUsuario NUMERIC( 19,0 );
	-- SET @idUsuario = 2;

	UPDATE Ordenes SET idEstatusOrden = 5, idGarantia = 1, motivoGarantia = @motivo  WHERE idOrden = @idOrden;
	UPDATE HistorialEstatusOrden SET fechaFinal = CURRENT_TIMESTAMP WHERE idEstatusOrden = 7 AND idOrden = @idOrden;
	INSERT INTO HistorialEstatusOrden VALUES( @idOrden, 5, CURRENT_TIMESTAMP, NULL, @idUsuario );

	DECLARE @idPresupuesto numeric(18,0)
						
	DECLARE PresupuestoInfo CURSOR FOR SELECT idPresupuesto FROM PresupuestoOrden WHERE idOrden=@idOrden 
			 
	OPEN PresupuestoInfo 
	FETCH NEXT FROM PresupuestoInfo INTO @idPresupuesto

	WHILE @@fetch_status= 0
	BEGIN

		INSERT INTO Bitacora (IdUsuario, fechaBitacora, tabla, idOrden, operacion) VALUES (@idusuario, GETDATE(), 'PresupuestoOrden', @idOrden, 'Eliminado del presupuesto número ' +Cast( @idPresupuesto as varchar(25)))
				
		FETCH NEXT FROM PresupuestoInfo INTO @idPresupuesto
	END

	CLOSE PresupuestoInfo
	DEALLOCATE PresupuestoInfo

	DELETE FROM PresupuestoOrden WHERE idOrden= @idOrden
	
	SELECT Success = 1, Msg = 'Se ha rechado el trabajo de manera exitosa' 

	-- SELECT * FROM Ordenes WHERE idOrden = @idOrden;
	-- SELECT * FROM HistorialEstatusOrden WHERE idEstatusOrden = 7 AND idOrden = @idOrden
	-- SELECT * FROM HistorialEstatusOrden WHERE idOrden = @idOrden
END
go

