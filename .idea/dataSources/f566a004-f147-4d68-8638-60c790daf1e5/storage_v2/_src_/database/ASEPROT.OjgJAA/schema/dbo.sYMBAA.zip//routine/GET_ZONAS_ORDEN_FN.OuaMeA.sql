
CREATE FUNCTION [dbo].[GET_ZONAS_ORDEN_FN]
(
	@idZona int
)
RETURNS varchar(max)
AS
BEGIN
	DECLARE @result varchar(max) = ''
	
	DECLARE  @nombreZona varchar(max)
DECLARE @zonasTemp table(idZona int, nombre varchar(max), etiqueta varchar(max), orden int)

	IF not(@idZona = 0)
	BEGIN
		insert into @zonasTemp
		select z.idZona, z.nombre, nz.etiqueta, nz.orden
		from Partidas..Zona z
		inner join Partidas..NivelZona nz on nz.idNivelZona = z.idNivelZona
		where idZona =@idZona
		
		select @idZona = idPadre 
		from Partidas..Zona where idZona = @idZona
	END
	
	IF(SELECT COUNT(*) FROM @zonasTemp)>0
	BEGIN
	DECLARE zonas_cursor CURSOR FOR  
	SELECT etiqueta + ': ' + nombre FROM @zonasTemp
	ORDER BY orden;  

	OPEN zonas_cursor;    

	FETCH NEXT FROM zonas_cursor  
	INTO @nombreZona;  
 
	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		
		set @result = @result + @nombreZona + ' - ' 

		FETCH NEXT FROM zonas_cursor  
		INTO @nombreZona;   
	END  

	CLOSE zonas_cursor;  
	DEALLOCATE zonas_cursor;  
	
	IF (LEN(@result) > 2)
		BEGIN
			set @result = SUBSTRING(@result , 1, LEN(@result) - 2)
		END
	END
	
	RETURN @result

END
go

