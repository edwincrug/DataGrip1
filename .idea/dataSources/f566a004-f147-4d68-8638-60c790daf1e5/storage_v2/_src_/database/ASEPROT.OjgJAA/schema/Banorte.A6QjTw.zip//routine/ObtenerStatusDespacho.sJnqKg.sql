-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 04-07-2018
-- Description: Obtener el status de despacho
-- [Banorte].[ObtenerStatusDespacho] 53816
-- =============================================
CREATE PROCEDURE [Banorte].[ObtenerStatusDespacho] 
	@idOrden INT	
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	/*
		SELECT PedEnt.idPedidoEntrega
			,PedEnt.tipoEntrega
			,PedEnt.comentario
			,PR.pre_idpedidoref
			,PR.pre_idcotizacion
			,PR.pre_pedidobpro
			,SOC.idCotizacion
			,SOC.idOrden
			,SOC.idCotizacionSISCO
			,SOC.idSiniestro
			,CAST(
				CASE 
					WHEN PedEnt.tipoEntrega = 3 
					THEN 1
					ELSE 0
				END
			AS BIT) AS Entregado
		FROM PortalDespacho.dbo.PedidoEntrega PedEnt
		INNER JOIN [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PR
		ON PedEnt.pre_pedidobpro = PR.pre_pedidobpro
		INNER JOIN RefaccionMultimarca.Relacion.SiniestroOrdenCotizacion SOC
		ON SOC.idCotizacion = PR.pre_idcotizacion
		WHERE SOC.idOrden = @idOrden
	
		SELECT PedEnt.idPedidoEntrega
				,PedEnt.tipoEntrega
				,PedEnt.comentario
				,PR.pre_idpedidoref
				,PR.pre_idcotizacion
				,PR.pre_pedidobpro
				,SOC.idCotizacion
				,SOC.idOrden
				,SOC.idCotizacionSISCO
				,SOC.idSiniestro
				,/*CAST(
					CASE 
						WHEN PedEnt.tipoEntrega = 3 
						THEN 1
						ELSE 0
					END
				AS BIT)*/ 1 AS Entregado 
		FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC
		INNER JOIN [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PR
		ON SOC.idCotizacion = PR.pre_idcotizacion
		LEFT JOIN PortalDespacho.dbo.PedidoEntrega PedEnt
		ON PR.pre_pedidobpro = PedEnt.pre_pedidobpro
		WHERE SOC.idOrden = @idOrden
		*/
		--DECLARE @proveedorGenerico INT = (SELECT TOP 1 ISNULL(idProveedorGenerico,0) AS idProveedorGenerico
		--FROM RefaccionMultiMarca.[Operacion].[Cotizacion] C
		--	JOIN RefaccionMultiMarca.[Operacion].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion
		--	JOIN RefaccionMultiMarca.[Relacion].[SiniestroOrdenCotizacion] SC ON SC.idCotizacion = CD.idCotizacion
		--	JOIN RefaccionMultiMarca.[Catalogo].[PAR_PARTES] P ON P.id = CD.id
		--WHERE sc.idOrden = @idOrden)

		DECLARE @proveedorGenerico INT = (SELECT TOP 1 ISNULL(idProveedorGenerico,0) AS idProveedorGenerico
		 FROM RefaccionMultiMarca.[Operacion].[Cotizacion] C
			JOIN RefaccionMultiMarca.[Relacion].[SiniestroOrdenCotizacion] SC ON SC.idCotizacion = C.idCotizacion
			JOIN RefaccionMultiMarca.[Seguridad].[UsuarioModuloSeguridad] UMS ON UMS.idUsuario = C.idUsuario
		WHERE sc.idOrden = @idOrden)

		IF(@proveedorGenerico = 1)
		BEGIN
				SELECT         
				0 as idPedidoEntrega
				,0 as tipoEntrega
				,0 as comentario
				,0 as pre_idpedidoref
				,0 as pre_pedidobpro
				,0 as pre_pedidobpro
				,MAX(SOC.idCotizacion) as idCotizacion
				,MAX(SOC.idOrden) as idOrden
				,MAX(SOC.idCotizacionSISCO) as idCotizacionSISCO
				,MAX(SOC.idSiniestro) as idSiniestro
				,CAST(1 AS BIT) as Entregado
				FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC
				WHERE SOC.idOrden = @idOrden 
		END
	ELSE
		BEGIN
			SELECT         
				MAX(PedEnt.idPedidoEntrega) as idPedidoEntrega
				,MAX(PedEnt.tipoEntrega) as tipoEntrega
				,MAX(PedEnt.comentario) as comentario
				,MAX(PR.pre_idpedidoref) as pre_idpedidoref
				,MAX(PR.pre_idcotizacion) as pre_pedidobpro
				,MAX(PR.pre_pedidobpro) as pre_pedidobpro
				,MAX(SOC.idCotizacion) as idCotizacion
				,MAX(SOC.idOrden) as idOrden
				,MAX(SOC.idCotizacionSISCO) as idCotizacionSISCO
				,MAX(SOC.idSiniestro) as idSiniestro
				,CAST(MIN(CASE WHEN PedEnt.tipoEntrega = 3 or PedEnt.tipoEntrega = 4 THEN 1 ELSE 0 END)as BIT) as Entregado
				FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC
				inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
				inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
				INNER JOIN [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PR
				ON SOC.idCotizacion = PR.pre_idcotizacion
				LEFT JOIN PortalDespacho.dbo.PedidoEntrega PedEnt
				ON PR.pre_pedidobpro = PedEnt.pre_pedidobpro and PedEnt.idMarca = U.marca
				WHERE SOC.idOrden = @idOrden and PR.spe_idsituacionpedido not in (6, 1)
		END
	END TRY
	BEGIN CATCH
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.ObtenerStatusDespacho to DevOps
go

