
-- =============================================
-- Description:	Obtengo el catalago de tipo de ordenes de servicio
-- =============================================
-- [dbo].[SEL_TIPOS_ORDENES_SERVICIO_SP]
CREATE PROCEDURE [dbo].[SEL_TIPOS_ORDENES_SERVICIO_SP]
AS
BEGIN
	SELECT [idCatalogoTipoOrdenServicio] AS idTipoCita
		  ,[nombreTipoOrdenServicio] AS tipoCita
		  ,[descripcionTipoOrden] AS descripcionTipoCita
		  ,[Seguro] as seguro
	  FROM [dbo].[CatalogoTiposOrdenServicio]
	  --WHERE [Manual]=1
END


go

