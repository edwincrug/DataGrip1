
-- =============================================
-- Author: Jose Armando Garcia Arroyo
-- Create date: 21/05/2018
-- [Banorte].[SEL_ZONA_SP] 20
-- Modify: Christian Ochoa Nicolas
-- Modify Date: 18/02/2019
-- Modify Desc: Buscamos las zonas de acuerdo al contrato operación
-- EXEC Banorte.SEL_ZONA_SP @idContratoOperacion = 18
-- =============================================
--SEL_ZONA_SP '1'
CREATE PROCEDURE [Banorte].[SEL_ZONA_SP]
	@idContratoOperacion INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @idClientePartidas NUMERIC(18,0)
		, @idOperacion INT

	SELECT @idOperacion = idOperacion 
	FROM ContratoOperacion
	WHERE idContratoOperacion = @idContratoOperacion

	SELECT @idClientePartidas = L.idCliente
	FROM ContratoOperacion CO
	INNER JOIN Partidas.dbo.Contrato C on C.idContrato = CO.idContrato
	INNER JOIN Partidas.dbo.Licitacion L on C.idLicitacion=L.idLicitacion
	WHERE CO.idOperacion = @idOperacion

	EXECUTE Partidas.dbo.SEL_ZONA_SP '1',@idClientePartidas
	
	SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.SEL_ZONA_SP to DevOps
go

