

-- =============================================
-- Create date: 12/10/2017
-- Description:	Actualiza detalle cotizacion
-- [UPD_CANCELA_DETALLE_COTIZACION_SP] 91297, 538, 3
-- User : Jordan Gomez
-- =============================================
 CREATE PROCEDURE [dbo].[UPD_CANCELA_DETALLE_COTIZACION_SP]
	@idCotizacionDetalle INT,
	@idUsuario INT,
	@idContratoOperacion INT
	
AS
BEGIN

DECLARE @query NVARCHAR(MAX)
	BEGIN
		SET @query = 'INSERT INTO LogSoporte (
			idOrden,
			idUsuario,
			idContratoOperacion,
			fecha,
			idSoporte,
			descripcion
			)
		SELECT 
			O.idOrden,
			'+CAST(@idUsuario AS NVARCHAR(30))+',
			O.idContratoOperacion,
			getdate(),
			9,
			''Eliminar partida''
		FROM CotizacionDetalle CD 
		INNER JOIN Cotizaciones C ON CD.idCotizacion = C.idCotizacion 
		INNER JOIN Ordenes O ON O.idOrden = C.idOrden AND O.idContratoOperacion = ' + CAST(@idContratoOperacion AS NVARCHAR(30)) + '
		WHERE idCotizacionDetalle = '+CAST(@idCotizacionDetalle AS NVARCHAR(30))
		
		--PRINT @query

		EXECUTE SP_EXECUTESQL @query

		UPDATE CotizacionDetalle 
		SET idEstatusPartida = 4
		WHERE idCotizacionDetalle=@idCotizacionDetalle
	
		SELECT @idCotizacionDetalle AS idCotizacionDetalle
	END		
END
go

