-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Banorte].[SEL_DATOS_FACTURACION] 18
-- =============================================

CREATE PROCEDURE [Banorte].[SEL_DATOS_FACTURACION]
	@idContratoOperacion int
AS
BEGIN

	DECLARE @facturasProveedor as TABLE ( idOrden int, numeroOrden nvarchar(200), numeroReclamo nvarchar(200), idCotizacionSISCO int, ipServicios nvarchar(100), urlServices nvarchar(100)
										, idCotizacionSISRE int, ipBD nvarchar(100), db nvarchar(100), dbConcentra nvarchar(100), idMarca int, valeInicial int
										, valeFinal int, hasFactura int, entrega int, fechaEvidenciaCompleta DateTime null, fechaContraRecibo datetime
										, fechaPromesa datetime, contraRecibo nvarchar(200))
		
	insert into @facturasProveedor	
		select top 3 O.idOrden, O.numeroOrden, S.numeroReclamo, C.idCotizacion, case when M.server='192.168.20.71' then 'http://localhost:4100' else 'http://localhost:4200' end
			, case when M.server='192.168.20.71' then 'provision' else 'cotizaciones' end, SOC.idCotizacion, M.server, M.dbNameConcentradora
			, M.dbCon_Car, M.idMarca
			,ISNULL((select top 1 1 from aseprot..evidencias  where idordenservicio=O.idOrden and descripcionEvidencia='ValeInicial'),0)
			,ISNULL((select top 1 1 from aseprot..evidencias  where idordenservicio=O.idOrden and descripcionEvidencia='ValeFinal'),0) 
			,ISNULL((select top 1 1 from aseprot..facturaCotizacion  where idCotizacion = C.idCotizacion),0) 
			,ISNULL((select top 1 1 from aseprot..evidencias  where idCotizacion=C.idCotizacion and descripcionEvidencia like'Ev%'),0) 
			,(select MAX(fechaInicial) from aseprot..HistorialEstatusOrden where idOrden = O.idOrden and idEstatusOrden = 8) 
			,convert(datetime, CR.fechaContrarecibo, 103), dateadd(day,30,convert(datetime, CR.fechaContrarecibo, 103)) 
			,CR.numeroContraRecibo--, C.fechaCotizacion
		from ASEPROT.dbo.Ordenes O
		inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3	
		left join ASEPROT.dbo.DatosCopade D on D.numeroCopade = O.numeroOrden
		left join [ASEPROT].[dbo].[ContrareciboDatosCopade] CDC on CDC.idDatosCopade = D.idDatosCopade
		left join [ASEPROT].[dbo].[Contrarecibo] CR on CR.idContrarecibo =CDC.idContrarecibo
		inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden and SOC.idCotizacionSISCO= C.idCotizacion
		inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro		
		inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
		inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = U.marca
		where  O.idContratoOperacion=@idContratoOperacion and C.fechaCotizacion >= DATEADD(DAY, -30, GETDATE()) and C.fechaCotizacion <= GETDATE()
		--and M.idMarca = 3
		order by O.idOrden					

	select * from @facturasProveedor

END

go

grant execute, view definition on Banorte.SEL_DATOS_FACTURACION to DevOps
go

