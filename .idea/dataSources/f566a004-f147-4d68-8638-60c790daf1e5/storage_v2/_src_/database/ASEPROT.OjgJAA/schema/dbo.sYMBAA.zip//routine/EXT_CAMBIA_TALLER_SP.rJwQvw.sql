CREATE PROCEDURE EXT_CAMBIA_TALLER_SP
(
	@ordenes NVARCHAR(400),
	@idTaller INT
)
AS

Declare @query varchar(500) = null

BEGIN

	-- Agregar la lista de numero de ordenes
	--select idOrden from Ordenes 
	--where numeroorden in ()

	-- Agregar la lista de numero de ordenes
	--select * from Cotizaciones 
	--where idorden in(select idOrden from Ordenes 
	--where numeroorden in () ) and idTaller > 0

	-- Obtener el taller
	--select * from Partidas..Proveedor 
	-- Agrega la razon social
	--where razonSocial like '%%'

	-- idProveedor es el id del taller para las ordenes
	-- Actualiza el taller para ordenes

	SET @query = 'update  Cotizaciones set idTaller = @idTaller 
	where idorden in(select idOrden from Ordenes 
	where numeroorden in (' + @ordenes + ') ) and idTaller > 0'

	EXEC @query
END
go

