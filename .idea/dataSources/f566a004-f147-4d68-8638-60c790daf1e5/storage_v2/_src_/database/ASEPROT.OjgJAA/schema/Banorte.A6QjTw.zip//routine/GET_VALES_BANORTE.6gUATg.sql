CREATE FUNCTION [Banorte].[GET_VALES_BANORTE](@idOrden int, @tipoVale varchar(max))

returns int
as 
begin
	
	DECLARE @value int 	
	select @value=ISNULL(idEvidencia,0) from Evidencias where idOrdenServicio=@idOrden
	and descripcionEvidencia like '%'+@tipoVale+'%'  

	return @value
end
go

grant execute, view definition on Banorte.GET_VALES_BANORTE to DevOps
go

