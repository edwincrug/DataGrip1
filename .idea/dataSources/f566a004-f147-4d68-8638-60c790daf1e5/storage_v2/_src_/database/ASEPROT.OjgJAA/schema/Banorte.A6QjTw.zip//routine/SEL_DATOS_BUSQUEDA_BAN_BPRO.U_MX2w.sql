-- =============================================
-- Author:		<YJH>
-- Create date: <2019/01/22>
-- Description:	<Obtiene los datos necesarios para buscar en bpro>
-- [Banorte].[SEL_DATOS_BUSQUEDA_BAN_BPRO] 39013, 18
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_DATOS_BUSQUEDA_BAN_BPRO]
	 @idOrden int,
	 @idContratoOperacion int	 
AS
BEGIN
	DECLARE @db nvarchar(100), @tabla nvarchar(100), @campoBusqueda nvarchar(100), @numeroOrden nvarchar(100)

	select @db=DBProduccion, @tabla = tablaBusqueda, @campoBusqueda=campoBusqueda from ContratoOperacionFacturacion where idContratoOperacion=@idContratoOperacion
	
	select @numeroOrden=numeroOrden from Ordenes where idOrden=@idOrden

	select @db as db, @tabla as tabla, @campoBusqueda as campoBusqueda, @numeroOrden as numeroOrden
END
go

grant execute, view definition on Banorte.SEL_DATOS_BUSQUEDA_BAN_BPRO to DevOps
go

