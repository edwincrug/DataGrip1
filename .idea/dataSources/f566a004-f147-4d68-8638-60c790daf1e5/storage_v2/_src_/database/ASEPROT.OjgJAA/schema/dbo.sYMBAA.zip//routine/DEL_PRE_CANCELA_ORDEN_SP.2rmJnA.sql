create PROCEDURE [dbo].[DEL_PRE_CANCELA_ORDEN_SP]
		@idOrden numeric(18,0)
AS
BEGIN

	DELETE FROM PreCancelacionOrdenes WHERE idOrden= @idOrden
	
	SELECT @@IDENTITY
END
go

