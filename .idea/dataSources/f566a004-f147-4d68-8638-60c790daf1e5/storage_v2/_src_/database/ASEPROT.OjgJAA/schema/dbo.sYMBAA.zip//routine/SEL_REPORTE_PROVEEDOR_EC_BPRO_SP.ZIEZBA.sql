
-- ==========================================================================================
-- Create date: 25/01/2018
-- ==========================================================================================
-- [dbo].[SEL_REPORTE_PROVEEDOR_EC_BPRO_SP] 3
CREATE PROC [dbo].[SEL_REPORTE_PROVEEDOR_EC_BPRO_SP]
	@idOperacion NUMERIC(18, 0)
AS
BEGIN
	IF(@idOperacion = 3)
		BEGIN
			SELECT idProveedor, razonSocial, saldo FROM [cobranza].[VwCXPBproProveedor]	
		END
	ELSE
	BEGIN
		SELECT idProveedor = 0, razonSocial = '', saldo = 0
	END
END

go

