-- =============================================
-- Author:		<YJH>
-- Create date: <25/06/2018>
-- Description:	<Verifca que la orden de servicio tenga factura y vale de surtimiento>
--39137, 39138, 39139, 39145
-- [Banorte].[SEL_ESTATUS_AVANCE] 63763, 1, 26
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_ESTATUS_AVANCE] 
	@idOrden NUMERIC,
	@isProduction int=0, 
	@idContratoOperacion int
AS
BEGIN
	DECLARE 
	@estatus NUMERIC,
	@hasFactura NUMERIC = 0,
	@hasValeI NUMERIC = 0, 
	@hasValeF NUMERIC = 0, 
	@result NUMERIC = 0
	
	Declare @numeroOrden varchar(30)

	select @numeroOrden = numeroOrden from Ordenes where idOrden = @idOrden

	select @result as estatus 

	SELECT
		  ORD.idOrden,
		  COTI.idCotizacion,
		  COTI.numeroCotizacion,
		  [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](ORD.idOrden,3,COTI.ConsecutivoCotizacion) as hasFactura, 
		  ISNULL( (select top 1 idEvidencia from Evidencias where idCotizacion= COTI.idCotizacion and descripcionEvidencia like '%ValeInicial%'), 0) as valeInicial,
		  ISNULL( (select top 1 idEvidencia from Evidencias where idCotizacion= COTI.idCotizacion and descripcionEvidencia like '%ValeFinal%'), 0) as valeFinal	  
	from Ordenes ORD 
	INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden
	where ORD.idOrden= @idOrden


END
go

grant execute, view definition on Banorte.SEL_ESTATUS_AVANCE to DevOps
go

