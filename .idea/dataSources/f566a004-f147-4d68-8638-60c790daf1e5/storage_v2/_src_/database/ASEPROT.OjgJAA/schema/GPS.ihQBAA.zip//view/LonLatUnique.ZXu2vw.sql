


Create VIEW [GPS].[LonLatUnique]
AS

select distinct 
       idUnidad,
	   lat,
	   long,
	   direccion,
	   fecha_loc
from  [Casanova].[dbo].[Localizacion]


go

grant select, view definition on GPS.LonLatUnique to DevOps
go

