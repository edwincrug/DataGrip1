
-- =============================================  
-- Description: Busca el detalle de la uniad   
-- NOTA: Falta verificar el usuario, su rol y el tipo de operación   
-- =============================================  
-- [dbo].[SEL_DETALLE_UNIDAD_SP] @idUsuario = 181, @economico = 'HR169128' , @idOperacion = 18
-- [dbo].[SEL_DETALLE_UNIDAD_SP] @idUsuario = 509, @economico = '55' , @idOperacion = 12
-- [dbo].[SEL_DETALLE_UNIDAD_SP] @idUsuario = 509, @economico = 'PMX0219' , @idOperacion = 8
-- [dbo].[SEL_DETALLE_UNIDAD_SP] @idUsuario = 509, @economico = '9748742468'  
-- [dbo].[SEL_DETALLE_UNIDAD_SP] @idUsuario = 2, @economico = '8'  
-- [dbo].[SEL_DETALLE_UNIDAD_SP] 528, 'RS-VE-02',7  -- SalvaGuardia 7 
-- [dbo].[SEL_DETALLE_UNIDAD_SP] 676, '52',14 
CREATE PROCEDURE [dbo].[SEL_DETALLE_UNIDAD_SP]   
 @idUsuario INT = 0,  
 @economico VARCHAR(50) = '' ,
 @idOperacion NUMERIC(18,0) = 1
AS  
BEGIN  
 -------------------------------------------------------------------------------------------------------------------------  
 --Busqueda de unidad respuesta = 1 <-- Respuesta Correcta  
 --      respuesta = 0 <-- No se encontraron registros  
 --      respuesta = 2 <-- El usuario no tiene los permisos necesarios  
 --                   respuesta = 3 <-- La unidad tiene una orden de servicio en proceso   
 --Cuando situacionOrden = 0 <--No tiene ordenes de servicio en proceso   
 --   situacionOrden = 1 <--Tiene ordenes de servicio en proceso   
 -------------------------------------------------------------------------------------------------------------------------  
 DECLARE @situacionOrden INT=0, @numeroOrdensesServicios INT=0, @costo NUMERIC (18,2) = 0, @venta NUMERIC (18,2) = 0, @enProceso NUMERIC (18,2) = 0, @finalizado NUMERIC(18,2)  
			   ,@pendienteCertificado NUMERIC (18,2) = 0,@porCobrar NUMERIC (18,2) = 0, @idUnidad INT, @perdidaTotal int  

DECLARE @ultimoServicio NVARCHAR(50), @ultimaModificacion NVARCHAR(50), @usuarioModifico NVARCHAR(200) 
 DECLARE @query NVARCHAR(MAX)  

--para GPS Alcabelu 20171031
declare @Vin Nvarchar(50)
--declare @lat Nvarchar(50) = '19.3295518'
--declare @long Nvarchar(50) = '-99.2065204'
declare @lat Nvarchar(50) = '0'
declare @long Nvarchar(50) = '0'
DECLARE @kilometraje numeric(18,2) = '0'
DECLARE @kilometrajeFin Nvarchar(100) = '0'
--print @numeroOrden
DECLARE @timeGPS DATETIME

 IF(EXISTS(SELECT [numeroEconomico] FROM [dbo].[Unidades] WHERE [numeroEconomico] = @economico OR [VIN] = @economico OR [placas] = @economico))  
  
		BEGIN  
		   IF(EXISTS(SELECT *  
			  FROM [dbo].[Unidades] UNI  
				INNER JOIN [dbo].[ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion  
				INNER JOIN [dbo].[ContratoOperacionUsuario] COU ON CP.idContratoOperacion = COU.idContratoOperacion AND COU.idUsuario = @idUsuario  
				WHERE (numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico) and UNI.idOperacion = @idOperacion))  
			BEGIN  
			
			 SET @numeroOrdensesServicios = ISNULL((  
						SELECT COUNT (*)  
						FROM [dbo].[Unidades] U  
						  INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad  
						WHERE (numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico) 
						AND U.idOperacion = @idOperacion AND NOT idEstatusOrden = 10 AND idEstatusOrden > 2  
					   ),0)  
			 SET @situacionOrden = (CASE WHEN EXISTS(SELECT *  
						 FROM [dbo].[Unidades] AS U  
						   INNER JOIN [dbo].[Ordenes] AS O ON U.idUnidad = O.idUnidad  
						WHERE (numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico)
							and U.idOperacion = @idOperacion AND idEstatusOrden < 8)  
					THEN 1  
					ELSE 0 END)  
			   /* SELECT @costo = case when O.idEstatusOrden = 13 then 0 else SUM(CD.costo * CD.cantidad * 1.16) end  
			   ,@venta =  case when O.idEstatusOrden = 13 then 0 else SUM(CD.venta * CD.cantidad * 1.16) end  
			 FROM [dbo].[Unidades] U  
			   INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
			   INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
			   INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
			 WHERE numeroEconomico = @economico AND NOT idEstatusOrden = 10 AND idEstatusOrden > 4   
			 group by O.idEstatusOrden */  
  
			 SELECT   
			  @costo = ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0),  
			  @venta = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
			 FROM [dbo].[Unidades] U  
			  INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
			  INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
			  INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
			 WHERE (U.numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico)
			 AND U.idOperacion = @idOperacion AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
			 AND O.idEstatusOrden NOT IN(13) AND O.idEstatusOrden > 4   
  
			 SELECT @enProceso = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
			 FROM [dbo].[Unidades] U  
			   INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
			   INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
			   INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
			 WHERE (numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico)
				AND U.idOperacion = @idOperacion AND idEstatusOrden = 5  
			   AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
  
			 SELECT @pendienteCertificado = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
			 FROM [dbo].[Unidades] U  
			   INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
			   INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
			   INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
			 WHERE (numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico)
			 AND U.idOperacion =  @idOperacion AND idEstatusOrden in(6,7)  
			   AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
  
			 SELECT @porCobrar = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
			 FROM [dbo].[Unidades] U  
			   INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
			   INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
			   INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
			 WHERE (numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico)
			 AND U.idOperacion = @idOperacion AND idEstatusOrden in(8)  
			   AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
  
			 SELECT @finalizado = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
			 FROM [dbo].[Unidades] U  
			   INNER JOIN [dbo].[Ordenes] O ON U.idUnidad = O.idUnidad   
			   INNER JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden  
			   INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion  
			 WHERE (numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico)
			 AND U.idOperacion = @idOperacion AND idEstatusOrden in(9)  
			   AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)  
  
			 SELECT @idUnidad = idUnidad FROM [dbo].[Unidades] WHERE (numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico) and idOperacion = @idOperacion
			 
			 SET @ultimoServicio = CONVERT(VARCHAR(10),( SELECT TOP 1 fechaInicial   
				   FROM [dbo].[Ordenes] O  
					 INNER JOIN [dbo].[HistorialEstatusOrden] HEO ON HEO.idOrden = O.idOrden  
				   WHERE  idUnidad = @idUnidad  
				   ORDER BY fechaInicial DESC),103)  

			-- ver si la unidad ha tenido una orden en perdida total
			SELECT @perdidaTotal = COUNT (*) FROM Ordenes O
				INNER JOIN Unidades U ON U.idUnidad = O.idUnidad
				WHERE (U.numeroEconomico = @economico OR [VIN] = @economico OR [placas] = @economico)
				AND O.idCatalogoTipoOrdenServicio = 9

			 SELECT @ultimaModificacion = CONVERT(VARCHAR(10),fechaInicial,103)  
			   ,@usuarioModifico = nombreCompleto  
			 FROM [dbo].[Ordenes] O  
			   INNER JOIN [dbo].[HistorialEstatusOrden] HEO ON HEO.idOrden = O.idOrden  
			   INNER JOIN [dbo].[Usuarios] USU ON USU.idUsuario = HEO.idUsuario  
			 WHERE idUnidad = @idUnidad AND fechaFinal IS NULL AND NOT HEO.idEstatusOrden in (9,10)  
			 --PRINT @situacionOrden   
			 ------Obtengo la ip del servidor donde se encuntra la BD Partidas  

			
				  SET @timeGPS = GETDATE()

				   select @vin = vin
					 FROM Unidades 	              
					WHERE idUnidad = @idUnidad
					-- SELECT * FROM Partidas..Contrato
					-- SELECT * FROM ContratoOperacion
	
		
			SELECT @long = U.long ,
					@lat = U.lat, 
					@kilometraje=U.Kilometraje_Actual,
					@timeGPS= U.fecha_loc
			FROM Unidades U
			WHERE U.vin = @vin

			SET @kilometrajeFin = REPLACE(CONVERT(VARCHAR,CONVERT(Money, ISNULL(@kilometraje,0)),1),'.00','')
		
		
			 -----------------------------------------------------------------   
       
			 SELECT  UNI.[idUnidad]					AS idUnidad  
					,UNI.[numeroEconomico]			AS numeroEconomico 
					,UNI.[vin]						AS vin
				    ,ISNULL(UNI.placas,'')			as placas
					,MA.[nombre]					AS marca  
					,SM.[nombre]					AS subMarca           
					,(select nombre from [Partidas].dbo.Zona where idZona = UNI.idZona) zona  
				 --'  ,UNIP.[anio] AS modelo
				   ,UNI.combustible					AS version          
				   ,UNI.[modelo]					AS modelo  
				   ,UNI.[gps]						AS gps 
				   ,[sustituto]						AS sustituto
				   ,UNI.[idOperacion]				AS idOperacion  
				   ,UNI.[idCentroTrabajo]			AS idCentroTrabajo
				   ,ISNULL(@numeroOrdensesServicios,0) AS numeroOrdenesSerevicio  
				   , 1 AS respuesta
				   ,  ISNULL(@situacionOrden,0)		AS situacionOrden
				   , ISNULL(@costo,0)				AS costoTotal
				   , ISNULL(@venta,0)				AS precioTotal  
				   , ISNULL(@enProceso,0)			AS enProceso  
				   , ISNULL(@perdidaTotal,0)		AS perdidaTotal  
				   , ISNULL(@pendienteCertificado,0) AS pendienteCertificado  
				   , ISNULL(@porCobrar,0)			AS porCobrar  
				   , ISNULL(@finalizado,0)			AS finalizado 
				   , ISNULL(@ultimoServicio,'')		AS ultimoServicio
				   , ISNULL(@ultimaModificacion,'') AS ultimaModificacion
				   , ISNULL(@usuarioModifico,'')	AS usuarioModifico
				   ,UNIP.idUnidad					AS idTipoUnidad 
				   ,TU.tipo							AS nombreTipoUnidad 
				   ,UNIP.foto						as foto  
				    ,cil.cilindros 
				   ,UNI.verGPS						as isGPSU 
				   , @kilometrajeFin				AS kilometraje
				   ,ISNULL(@lat,0)					as [Latitud] 
				   ,ISNULL(@long,0)					as [Longitud]
				   ,ISNULL(@timeGPS,0)				as [fechaLocalizacion]
				 --'  ,UNIP.version AS version' + char(13) +  
				  ,ISNULL(UR.Estatus, 0)			as UnidadRestriccion
				  ,50								AS capacidadTanque
				  ,ISNULL(UNI.temp, 0)				AS temperaturaMotor
				  ,ISNULL(UNI.voltaje, 0)			AS voltaje
				  ,10								AS rendimiento
				 --' ,TELE.nombreCompleto			AS nombreCompleto' + char(13) +
				 --' ,TELE.operadorDireccion			AS operadorDireccion' + char(13) +
				 --' ,TELE.operadorTelefono			AS operadorTelefono' + char(13) +
				 --' ,TELE.operadorLiciencia			AS operadorLiciencia' + char(13) +
				  , @lat							AS lat
				  , @long							AS lon
				  FROM [dbo].[Unidades]  UNI
				   INNER JOIN [dbo].[ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion 
				   INNER JOIN .[Partidas].[dbo].[ContratoUnidad] CU ON CU.idContrato = CP.idContrato AND CU.idUnidad = UNI.idTipoUnidad
				   INNER JOIN .[Partidas].[dbo].[Unidad] UNIP ON UNIP.idUnidad = CU.idUnidad
				   INNER JOIN .[Partidas].dbo.SubMarca SM ON UNIP.idSubMarca = SM.idSubMarca
				   INNER JOIN .[Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca
				   LEFT JOIN  .[Partidas].dbo.Cilindros cil ON cil.idCilindros = UNIP.idCilindros
				   INNER JOIN .[Partidas].[dbo].[TipoUnidad] TU ON TU.idTipoUnidad = UNIP.idTipoUnidad
				   LEFT JOIN  dbo.UnidadRestriccion UR ON UR.idUnidad = UNI.idUnidad AND UR.idOperacion = UNI.idOperacion
				 --'  LEFT JOIN [SISCOV3].[unidad].[SEL_UNIDAD_TELEMETRIA_FN](''' + @vin + ''') TELE ON ''' + @VIN + ''' = TELE.VIN' + char(13) +   
				 WHERE (UNI.[numeroEconomico] = @economico
					or uni.vin = @economico  or uni.placas =@economico )
				  AND CP.idOperacion =  @idOperacion       

       
			END   
		   ELSE  
			BEGIN  
			 SELECT 2 AS respuesta,  
			 'El usuario no tiene los permisos necesarios' AS mensaje  
			END    
		  END  
	
  
 ELSE  
  BEGIN  
   SELECT 0 AS respuesta,  
     'No se encontraron registros' AS mensaje  
  END  
     
   
END

go

