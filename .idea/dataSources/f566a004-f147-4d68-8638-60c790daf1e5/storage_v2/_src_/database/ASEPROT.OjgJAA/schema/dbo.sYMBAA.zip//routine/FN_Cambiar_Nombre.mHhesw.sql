-- =============================================
-- Author:		<Javier Grijalva>
-- Create date: <05 de Occtubre de 2020>
-- Description:	<Cambia el nombre completo en un nombre de usuario>
-- SELECT [dbo].[FN_Cambiar_Nombre] ('José Javier Grijalva')
-- =============================================
CREATE FUNCTION [dbo].[FN_Cambiar_Nombre] (@nombreUsuario nvarchar(100))
RETURNS NVARCHAR (max)
AS
BEGIN	
		DECLARE @nombreCompleto NVARCHAR(100) = @nombreUsuario--'Lizbeth Lopez'
		--DECLARE @nombreUsuario NVARCHAR(50)

		--SELECT @nombreCompleto

		SET @nombreUsuario= REPLACE(@nombreCompleto, 'a','4');
		SET @nombreUsuario= REPLACE(@nombreUsuario, '.','');
		SET @nombreUsuario= REPLACE(@nombreUsuario, 'á','4');
		SET @nombreUsuario= REPLACE(@nombreUsuario, 'e','3');
		SET @nombreUsuario= REPLACE(@nombreUsuario, 'é','3');
		SET @nombreUsuario= REPLACE(@nombreUsuario, 'i','1');
		SET @nombreUsuario= REPLACE(@nombreUsuario, 'í','1');
		SET @nombreUsuario= REPLACE(@nombreUsuario, 'o','0');
		SET @nombreUsuario= REPLACE(@nombreUsuario, 'ó','0');

		IF ( len(@nombreUsuario) > 20)
		BEGIN

			SELECT @nombreUsuario = 
				SUBSTRING(
					@nombreUsuario,
					CHARINDEX(' ', @nombreUsuario)+1,
					LEN(@nombreUsuario)-CHARINDEX(' ', @nombreUsuario)
					)
		END

		SET @nombreUsuario= REPLACE(@nombreUsuario, ' ','.');

		IF ( len(@nombreUsuario) > 15)
		BEGIN

			SELECT @nombreUsuario = 
				SUBSTRING(
					@nombreUsuario,
					CHARINDEX('.', @nombreUsuario)+1,
					LEN(@nombreUsuario)-CHARINDEX('.', @nombreUsuario)
					)
		END
		return @nombreUsuario


END
go

