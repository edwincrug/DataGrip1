-- exec [dbo].[INS_PRESUPUESTO_SP] @presupuesto = 100000, @folioPresupuesto = '1234', @fechaInicioPresupuesto = '10/08/2017', @fechaFinalPresupuesto = '10/08/2017', @idCentroTrabajo = 34, @idUsuario = 107, @isEspecial = 0
CREATE PROCEDURE  [dbo].[INS_PRESUPUESTO_SP]
	@presupuesto DECIMAL(18,2),
	@folioPresupuesto VARCHAR(50),
	@fechaInicioPresupuesto NVARCHAR(20),
	@fechaFinalPresupuesto NVARCHAR(20),
	@idCentroTrabajo INT,
	@idUsuario INT,
	@solpe NVARCHAR(50) = null,
	@isEspecial bit
AS
BEGIN

DECLARE @orden NUMERIC(18,0),
		@estatus NUMERIC(18,0)

	IF EXISTS(SELECT idPresupuesto FROM Presupuestos WHERE idEstatusPresupuesto = 1 AND idCentroTrabajo= @idCentroTrabajo)
		BEGIN
			SET @estatus = 2
		END
	ELSE
		BEGIN
			SET @estatus = 1
		END

	IF (@isEspecial = 'true')
		BEGIN
			SET @estatus = 4
		END

	IF NOT EXISTS(SELECT 1 FROM Presupuestos where idCentroTrabajo = @idCentroTrabajo)
		BEGIN
			SET @orden = 1
		END
	ELSE
		BEGIN
			SET @orden = (SELECT MAX(orden) FROM Presupuestos where idCentroTrabajo= @idCentroTrabajo)
			SET @orden = @orden + 1
		END
	

	INSERT INTO [dbo].[Presupuestos]
	VALUES (@presupuesto,@folioPresupuesto,@fechaInicioPresupuesto,@fechaFinalPresupuesto,@idCentroTrabajo,@estatus,@orden,GETDATE(),@idUsuario,@solpe)

	SELECT @@IDENTITY as result

END
go

