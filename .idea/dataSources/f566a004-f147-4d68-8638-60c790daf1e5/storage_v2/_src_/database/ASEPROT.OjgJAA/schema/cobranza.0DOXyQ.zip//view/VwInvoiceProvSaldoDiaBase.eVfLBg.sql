










CREATE VIEW [cobranza].[VwInvoiceProvSaldoDiaBase]
AS
SELECT 
       Car_Externa.CCP_IDDOCTO as [NumFactura],
	   FC.idCotizacion,
	   C.numeroCotizacion,
	   ADE.OTE_IDPROVEEDOR,	   
       Car_Externa.CCP_IDPERSONA as [idProveedor],
	   PER.PER_NOMRAZON,

       CCP_ABONO - (SELECT  ISNULL(SUM(ccp_cargo),0) 
							FROM [192.168.20.29].[GAAutoExpressBanorte].[dbo].[VIS_CONCAR01] AS movimiento 
						   WHERE movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto 
							 AND movimiento.ccp_idpersona = Car_Externa.ccp_idpersona 
							 AND movimiento.ccp_cartera   = Car_Externa.ccp_cartera 
							 AND movimiento.ccp_docori <> 's'
							 AND movimiento.CCP_TIPODOCTO <> 'FAC') AS [DeudaDia]--Deuda al dia
	FROM [192.168.20.29].[GAAutoExpressBanorte].[dbo].[VIS_CONCAR01] AS Car_Externa 
		 INNER JOIN [192.168.20.29].[GA_Corporativa].[dbo].[PER_PERSONAS] PER
		         ON  Car_Externa.CCP_IDPERSONA = PER.PER_IDPERSONA 
		
		 INNER JOIN FacturaCotizacion FC
		         ON FC.numFactura = Car_Externa.CCP_IDDOCTO collate Modern_Spanish_CI_AS
		 inner join Cotizaciones C
                 on C.idCotizacion = FC.idCotizacion
		 INNER JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC] ADE
		         ON ADE.OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS   = C.numeroCotizacion
				AND Car_Externa.CCP_IDPERSONA = ADE.OTE_IDPROVEEDOR

							---AND Car_Externa.CCP_IDPERSONA =  @idProveedor   
							INNER JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].[PNC_PARAMETR] AS A  ON Car_Externa.CCP_CARTERA = A.PAR_IDENPARA 
							LEFT OUTER JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].[PNC_PARAMETR] AS B  ON Car_Externa.CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = 'TIMO' 
					  WHERE A.PAR_TIPOPARA  = 'CARTERA'  
						AND A.PAR_IDMODULO  = 'CXP'    --Cuentas por Pagar
						AND a.par_importe5  <> 1   
						AND B.PAR_DESCRIP1  = 'FACTURA' 
						AND Car_Externa.CCP_TIPODOCTO = 'FAC'   
						--AND Car_Externa.CCP_IDDOCTO   =  'A9727'
						AND Car_Externa.CCP_ABONO > 0
UNION ALL

SELECT 
       Car_Externa.CCP_IDDOCTO as [NumFactura],
	   FC.idCotizacion,
	   C.numeroCotizacion,
	   ADE.OTE_IDPROVEEDOR,	   
       Car_Externa.CCP_IDPERSONA as [idProveedor],
	   PER.PER_NOMRAZON,

       CCP_ABONO - (SELECT  ISNULL(SUM(ccp_cargo),0) 
							FROM [192.168.20.29].[GAAutoExpressBanorte].[dbo].[VIS_CONCAR01] AS movimiento 
						   WHERE movimiento.ccp_iddocto   = Car_Externa.ccp_iddocto 
							 AND movimiento.ccp_idpersona = Car_Externa.ccp_idpersona 
							 AND movimiento.ccp_cartera   = Car_Externa.ccp_cartera 
							 AND movimiento.ccp_docori <> 's'
							 AND movimiento.CCP_TIPODOCTO <> 'FAC') AS [DeudaDia]--Deuda al dia
	FROM [192.168.20.29].[GAAutoExpress].[dbo].[VIS_CONCAR01] AS Car_Externa 
		 INNER JOIN [192.168.20.29].[GA_Corporativa].[dbo].[PER_PERSONAS] PER
		         ON  Car_Externa.CCP_IDPERSONA = PER.PER_IDPERSONA 
		
		 INNER JOIN FacturaCotizacion FC
		         ON FC.numFactura = Car_Externa.CCP_IDDOCTO collate Modern_Spanish_CI_AS
		 inner join Cotizaciones C
                 on C.idCotizacion = FC.idCotizacion
		 INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC] ADE
		         ON ADE.OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS   = C.numeroCotizacion
				AND Car_Externa.CCP_IDPERSONA = ADE.OTE_IDPROVEEDOR

							---AND Car_Externa.CCP_IDPERSONA =  @idProveedor   
							INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].[PNC_PARAMETR] AS A  ON Car_Externa.CCP_CARTERA = A.PAR_IDENPARA 
							LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].[PNC_PARAMETR] AS B  ON Car_Externa.CCP_TIPODOCTO = B.PAR_IDENPARA AND B.PAR_TIPOPARA = 'TIMO' 
					  WHERE A.PAR_TIPOPARA  = 'CARTERA'  
						AND A.PAR_IDMODULO  = 'CXP'    --Cuentas por Pagar
						AND a.par_importe5  <> 1   
						AND B.PAR_DESCRIP1  = 'FACTURA' 
						AND Car_Externa.CCP_TIPODOCTO = 'FAC'   
						--AND Car_Externa.CCP_IDDOCTO   =  'A9727'
						AND Car_Externa.CCP_ABONO > 0
go

