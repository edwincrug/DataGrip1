-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--SEL_MEMORANDUM_BY_USUARIO_SP '181',0
CREATE PROCEDURE [dbo].[SEL_MEMORANDUM_BY_USUARIO_SP]
	-- Add the parameters for the stored procedure here
	@idUsuario		numeric(18,0)
AS
BEGIN
	
	declare @idPerfil numeric(18,0)
	select @idPerfil = idCatalogoTipoUsuarios from Usuarios where idUsuario = @idUsuario

	

	select
		M.idMemorandum,
		M.fecha,
		M.titulo,
		M.descripcion,
		ME.idEvidencia,
		ME.evidencia,

		--CONTROL DE LECTURA DE USUARIO
		CASE 
			WHEN ML.idMemorandum is null then -1
			else ML.leido
		end leido,
		CASE 
			WHEN ML.idMemorandum is null then -1
			else ML.aceptado
		end aceptado,
		CASE 
			WHEN ML.idMemorandum is null then ''
			else ML.comentarios
		end comentarios
	from Memorandum M
	left join MemorandumUsuario MU on M.idMemorandum = MU.idMemorandum and MU.idUsuario = @idUsuario
	left join MemorandumPerfil MP on M.idMemorandum = MP.idMemorandum and MP.idPerfil = @idPerfil
	left join MemorandumEvidencias ME on M.idMemorandum = ME.idMemorandum
	left join MemorandumLog ML on M.idMemorandum = ML.idMemorandum and ML.idUsuario=@idUsuario
	where 
		MU.idMemorandum is not null
		or MP.idMemorandum is not null			
	
END
go

