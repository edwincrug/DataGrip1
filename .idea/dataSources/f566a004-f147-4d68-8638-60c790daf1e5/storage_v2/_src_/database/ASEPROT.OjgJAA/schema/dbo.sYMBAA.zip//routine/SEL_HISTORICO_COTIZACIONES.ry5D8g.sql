CREATE PROCEDURE [dbo].[SEL_HISTORICO_COTIZACIONES]
	@idCotizacion numeric(18,0)
AS
BEGIN


			SELECT HC.[idCotizacion] ,
			   C.[numeroCotizacion], 
			   EC.idEstatusCotizacion AS idEstatusCotizacion, 
			   EC.[nombreEstatusCotizacion],
			   Us.[idUsuario], 
			   Us.[nombreCompleto],  
			   HC.[fechaInicial] AS fecha, 
			   CASE HC.idEstatusCotizacion 
					WHEN 1 THEN 10 WHEN 2 
					THEN [dbo].[SEL_PORCENTAJE_APROBACION_COTIZACION_FT](@idCotizacion)
					 WHEN 3 THEN 10 WHEN 4 THEN 10 END AS Porcentaje,
				C.[idEstatusCotizacion], 
				C.consecutivoCotizacion as consecutivo,
				CASE C.[idEstatusCotizacion] WHEN 5 THEN 1 ELSE 0 END as isPreorden,
				CASE (select count(*) from CotizacionDetalle CD where CD.idCotizacion = @idCotizacion and CD.idEstatusPartida = 1) WHEN 0 THEN 0 ELSE 1 END as hasPart
			FROM [dbo].[EstatusCotizaciones] AS EC  WITH (NOLOCK)
				 INNER JOIN [dbo].[HistorialEstatusCotizacion] AS HC WITH (NOLOCK) ON EC.[idEstatusCotizacion] = HC.idEstatusCotizacion
  				 INNER JOIN [dbo].[Usuarios] AS Us WITH (NOLOCK) ON HC.idUsuario = Us.idUsuario 
				 INNER JOIN [dbo].[Cotizaciones] AS C WITH (NOLOCK) ON C.idCotizacion = HC.idCotizacion
			WHERE HC.[idCotizacion] IN (@idCotizacion)
	UNION
			SELECT 0  AS idCotizacion ,
			   '' AS numeroCotizacion, 
			   EC.idEstatusCotizacion as idEstatusCotizacion, 
			   EC.[nombreEstatusCotizacion],
			   0  AS idUsuario, 
			   '' AS nombreCompleto,  
			   '' AS fecha, 
			   '' AS Porcentaje,
			   '' AS idEstatusCotizacion, 
			   '' AS consecutivo,
			   0 AS isPreorden,
			   0 AS hasPart
			FROM [dbo].[EstatusCotizaciones] AS EC WITH (NOLOCK)
				 INNER JOIN [dbo].[HistorialEstatusCotizacion] AS HC WITH (NOLOCK) ON EC.[idEstatusCotizacion] = HC.idEstatusCotizacion
  				 INNER JOIN [dbo].[Usuarios] AS Us WITH (NOLOCK) ON HC.idUsuario = Us.idUsuario 
				 INNER JOIN [dbo].[Cotizaciones] AS C WITH (NOLOCK) ON C.idCotizacion = HC.idCotizacion
			WHERE  HC.[idEstatusCotizacion]  NOT IN (SELECT idEstatusCotizacion FROM [HistorialEstatusCotizacion] WITH (NOLOCK) WHERE idCotizacion = @idCotizacion)
			AND HC.[idEstatusCotizacion] > (SELECT TOP 1 idEstatusCotizacion FROM [HistorialEstatusCotizacion] WITH (NOLOCK) WHERE idCotizacion = @idCotizacion ORDER BY idEstatusCotizacion DESC)
			AND EC.idEstatusCotizacion != 5
			ORDER BY EC.idEstatusCotizacion ASC 
	

END

go

grant execute, view definition on SEL_HISTORICO_COTIZACIONES to DevOps
go

