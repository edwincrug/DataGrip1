
CREATE FUNCTION [dbo].[SEL_TIEMPO_ASIGNADO_TRANSCURRIDO](
@idOrden numeric(18,0)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	declare @resultado varchar(max) = ''
	
		declare @idEstatusOrden int = (select idEstatusOrden from Ordenes where idOrden = @idOrden)
		declare @idOperacion numeric(18,0) = (select [idOperacion] from [dbo].[ContratoOperacion] where [idContratoOperacion] in (select idContratoOperacion from [dbo].[Ordenes] where idOrden = @idOrden))
		
	if ((select tiempoAsignado from Operaciones where idOperacion = @idOperacion) = 1)
	begin	
		declare @fecha datetime = (select fechaInicial from HistorialEstatusOrden where [idOrden] = @idOrden and idEstatusOrden = @idEstatusOrden and fechaFinal is null)
		declare @tiempoAsignado nvarchar(50) = (select [tiempoEnEspera] from [dbo].[OperacionTiempoEnEspera] where [idOperacion] = @idOperacion and [idEstatusOrden] = @idEstatusOrden )
			
		set @resultado = @tiempoAsignado + ' / ' + (select [dbo].[SEL_TIEMPO_TRANSCURRIDO](@fecha))
	end

	return @resultado
END

go

