
-- =============================================
-- Create date: 29 05 2018
-- SELECT [dbo].[SEL_COTIZACIONESX_ORDEN_FN](29433)
-- =============================================
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_COTIZACIONESX_ORDEN_FN](@idOrden INT)

RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @cotizaciones NVARCHAR(MAX) = ' ';
	DECLARE @numeroCotizaciones NVARCHAR(MAX) = '- ';
	DECLARE @Result NVARCHAR(MAX) = ' ';

	DECLARE contact_cursor CURSOR FOR
	select distinct numeroCotizacion -- numFactura --- 
		from Cotizaciones 
		where idOrden = @idOrden and idEstatusCotizacion <> 4 and idEstatusCotizacion <> 5

	OPEN contact_cursor  
	FETCH NEXT FROM contact_cursor INTO @cotizaciones
	WHILE @@FETCH_STATUS = 0  
		BEGIN 

		--SET @talleres =(SELECT idTaller FROM Taller where idTaller=@idTaller)
		--SET @numerosFacturas =  @numerosFacturas + @facturas + char(13) + char(10)+'-'
		SET @numeroCotizaciones =  @numeroCotizaciones + @cotizaciones + char(13) + char(10)+'-'

		FETCH NEXT FROM contact_cursor INTO @cotizaciones
		END  
	CLOSE contact_cursor  
	DEALLOCATE contact_cursor

	IF((@numeroCotizaciones IS NOT NULL) AND @numeroCotizaciones != '')
		SET @Result= SUBSTRING (@numeroCotizaciones, 1, Len(@numeroCotizaciones) - 1 )

	RETURN @Result;
	
END


go

