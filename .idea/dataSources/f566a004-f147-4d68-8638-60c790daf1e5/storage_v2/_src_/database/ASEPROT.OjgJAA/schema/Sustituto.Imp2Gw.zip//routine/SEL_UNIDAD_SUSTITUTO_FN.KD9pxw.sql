
-- =============================================
-- Author:		Carlos Adolfo Martinez Diosdado
-- Create date: 2016-12-01
-- Description:	Obtiene la cantidad total de las notas
-- EXEC  [SEL_CANTIDAD_NOTAS_FN] 433
-- =============================================
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_UNIDAD_SUSTITUTO_FN](@idUnidad NUMERIC(18,0))

RETURNS NUMERIC(18,0)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result NUMERIC(18,0) = 1;

	   IF EXISTS(SELECT 1 FROM UnidadSustituto WHERE idUnidad=@idUnidad AND estatus = 0)
	        SET @Result = 2;
	   IF EXISTS(SELECT 1 FROM UnidadSustituto WHERE idSustitutoUni=@idUnidad AND estatus = 0)
	        SET @Result = 2;

	RETURN @Result;
	
END

go

