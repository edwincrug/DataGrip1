-- Description:	Busca todas las evidencias relacionados a la orden
-- NOTA: 
-- [SEL_DETALLE_ORDEN_EVIDENCIA_SP] @numeroOrden ='03-1605062222899-000003'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DETALLE_ORDEN_EVIDENCIA_SP]
@idUsuario INT = 0,
@numeroOrden varchar(50) = ''
AS
BEGIN
	DECLARE @idOrden NUMERIC(18,0)
	SET @idOrden = (SELECT idOrden FROM Ordenes WHERE numeroOrden = @numeroOrden)
	SELECT Evi.[idEvidencia]
      ,Evi.[nombreEvidencia]
      ,Evi.[descripcionEvidencia]
      ,Evi.[rutaEvidencia]
      ,Evi.[idOrdenServicio] 
	FROM Evidencias Evi
	INNER JOIN Ordenes Ord ON Evi.idOrdenServicio = Ord.idOrden
	WHERE Ord.idOrden = @idOrden
END

go

