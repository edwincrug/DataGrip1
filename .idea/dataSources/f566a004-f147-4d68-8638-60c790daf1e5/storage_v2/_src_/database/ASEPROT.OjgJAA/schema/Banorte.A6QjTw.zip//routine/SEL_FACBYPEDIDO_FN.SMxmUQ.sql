 --SELECT [Banorte].[SEL_FACBYPEDIDO_FN](120)
 CREATE FUNCTION [Banorte].[SEL_FACBYPEDIDO_FN] ( @idPedidoBpro int, @idMarca int )
returns varchar(max)
as 
begin

	
	DECLARE @factura varchar(max) = '';
	IF @idMarca =1 --NISSAN
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.31].[GAZM_Zaragoza].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.31].[GAZM_Zaragoza].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro

	END 
	ELSE IF @idMarca=2 --GM
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.31].[GAAS_Satelite].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.31].[GAAS_Satelite].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro

	END 
	ELSE IF @idMarca=3 --Ford
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GAAAF_Viga].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAAF_Viga].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=4 --Suzuki
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GAAU_Universidad].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAU_Universidad].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=5 --Hyundai
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GAHyundai].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAHyundai].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=6 --CRA
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GACRA_Cuautitlan].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GACRA_Cuautitlan].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=7 --Honda
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GAHondaZaragoza].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAHondaZaragoza].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=8 --Volkswagen
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.31].[GADLA_VW].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.31].[GADLA_VW].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=9 --Seat
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.31].[GADLA_SEAT].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.31].[GADLA_SEAT].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=11 --Chevrolet
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GAAA_Azcapo].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAA_Azcapo].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=12 --Chrysler
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GAAutoAngarTlahuac].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAutoAngarTlahuac].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=13 --Hyundai Cam
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GAVC_Hyundai].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAVC_Hyundai].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	ELSE IF @idMarca=16 --Mitsubishi
	BEGIN 
		select  @factura=PMM_REF2 from [192.168.20.29].[GAAutoAngarMitsu].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAutoAngarMitsu].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro
	END
	
	return @factura
end
 go

 grant execute, view definition on Banorte.SEL_FACBYPEDIDO_FN to DevOps
 go

