
-- =============================================    
-- Author:  <Author,,Name>    
-- Create date: <Create Date,,>    
-- Description: <Description,,>    
-- Test : SEL_REPORTE_OPERACIONES_INTEGRA_BY_OPERACION_SP    
-- =============================================    
CREATE PROCEDURE [dbo].[SEL_REPORTE_OPERACIONES_INTEGRA_BY_OPERACION_SP]    
     
AS    
BEGIN    
 -- SET NOCOUNT ON added to prevent extra result sets from    
 -- interfering with SELECT statements.    
 SET NOCOUNT ON;    
    
    -- Insert statements for procedure here    
    
	select     
		b.contrato,    
		b.estatusOrden,    
		b.costoOrden,    
		b.numOrdenes,    
		b.ordenesMenores10000,    
		b.antiguedadOrdenesMenor10000,    
		b.numLlantas,    
		b.diasOrdenMasAntigua,    
		b.numUnidadesParque,    
		cast( round(convert(decimal,b.numUnidades) / convert(decimal,numUnidadesParque), 4) * 100 as decimal(18,2))   porcentajeUnidades,    
		b.numUnidades    
	from     
	(    
		select     
			con.descripcion  contrato,    
			eso.idEstatusOrden,    
			eso.nombreEstatusOrden  estatusOrden,    
			(    
				select count(*)     
				from ASEPROT.dbo.Unidades u    
					left join ASEPROT.dbo.ContratoOperacion copera on copera.idOperacion = u.idOperacion    
				where copera.idContratoOperacion = cop.idContratoOperacion    
			) numUnidadesParque,    
			COUNT(distinct ord.idOrden) numOrdenes,    
			count(distinct ord.idUnidad) numUnidades,    
			cast( round(isnull(sum(cd.costo * cd.cantidad), 0), 2) as decimal(18,2))  costoOrden,      
	--Subquery para obtener las ordenes con monto mayor a 5000 pesos    
			(    
				select count(a.idOrden) 
				from     
				(    
					select isnull(sum(code.costo * code.cantidad),0) costo, c.descripcion, es.nombreEstatusOrden, o.idOrden    
					from Partidas.dbo.Contrato c
						left join SISCOReportServices.dbo.Contrato co2 on co2.idContrato = c.idContrato
						left join ASEPROT.dbo.ContratoOperacion copera on copera.idContrato = c.idContrato     
						left join ASEPROT.dbo.Ordenes o on o.idContratoOperacion = copera.idContratoOperacion    
						left join ASEPROT.dbo.Cotizaciones co on co.idOrden = o.idOrden and co.idEstatusCotizacion in(1,2,3) and co.idTaller =    
							case when o.idEstatusOrden = 1 then 0    
							else co.idTaller    
							end --and coti.idTaller != 0    
						left join ASEPROT.dbo.CotizacionDetalle code on code.idCotizacion = co.idCotizacion and code.idEstatusPartida in(1,2)    
						left join ASEPROT.dbo.EstatusOrdenes es on es.idEstatusOrden = o.idEstatusOrden    
					--WHERE c.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
					--((e.idEmpresa = 5 and c.idContrato not in (34, 31)) or c.idContrato in(5, 7, 14, 23, 27, 41))  --34    
					where co2.idContrato is not null
						and o.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)    
					group by c.descripcion, es.nombreEstatusOrden, o.idOrden, o.idEstatusOrden    
				) a    
				where a.costo < 10000    
					and a.descripcion = con.descripcion    
					and a.nombreEstatusOrden = eso.nombreEstatusOrden    
			)   'ordenesMenores10000',    
	--Subquery para obtener las ordenes con monto mayor a 5000 pesos    
			(    
				select isnull(max(a.numDias), 0) from     
				(    
					select isnull(sum(code.costo * code.cantidad),0) costo, c.descripcion, es.nombreEstatusOrden, o.idOrden, DATEDIFF( day, h.fechaInicial, coalesce( h.fechaFinal, getdate() ) ) numDias    
					from Partidas.dbo.Contrato c
						left join SISCOReportServices.dbo.Contrato co2 on co2.idContrato = c.idContrato
						left join ASEPROT.dbo.ContratoOperacion copera on copera.idContrato = c.idContrato     
						left join ASEPROT.dbo.Ordenes o on o.idContratoOperacion = copera.idContratoOperacion    
						left join ASEPROT.dbo.Cotizaciones co on co.idOrden = o.idOrden and co.idEstatusCotizacion in(1,2,3) and co.idTaller =    
							case when o.idEstatusOrden = 1 then 0    
							else co.idTaller    
							end --and coti.idTaller != 0    
						left join ASEPROT.dbo.CotizacionDetalle code on code.idCotizacion = co.idCotizacion and code.idEstatusPartida in(1,2)    
						left join ASEPROT.dbo.HistorialEstatusOrden h on h.idEstatusOrden = o.idEstatusOrden and h.idOrden = o.idOrden    
						left join ASEPROT.dbo.EstatusOrdenes es on es.idEstatusOrden = o.idEstatusOrden    
					--WHERE c.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
					--((e.idEmpresa = 5 and c.idContrato not in (34, 31)) or c.idContrato in(5, 7, 14, 23, 27, 41))  --34    
					where co2.idContrato is not null
						and o.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)    
					group by c.descripcion, es.nombreEstatusOrden, o.idOrden, h.fechaInicial, h.fechaFinal, o.idEstatusOrden    
				) a    
				where a.costo < 10000    
					and a.descripcion = con.descripcion    
					and a.nombreEstatusOrden = eso.nombreEstatusOrden    
			)   'antiguedadOrdenesMenor10000',    
	--Subquery para obtener las ordenes con cambio de llanta    
			(    
				select ISNULL(sum(a.numLlantas), 0) from    
				(    
					select c.descripcion, es.nombreEstatusOrden, o.idOrden, count(distinct code.idCotizacionDetalle) * code.cantidad as numLlantas    
					from Partidas.dbo.Contrato c 
						left join SISCOReportServices.dbo.Contrato co2 on co2.idContrato = c.idContrato
						left join ASEPROT.dbo.ContratoOperacion copera on copera.idContrato = c.idContrato     
						left join ASEPROT.dbo.Ordenes o on o.idContratoOperacion = copera.idContratoOperacion    
						left join ASEPROT.dbo.Cotizaciones co on co.idOrden = o.idOrden and co.idEstatusCotizacion in (1,2,3) and co.idTaller =    
							case when o.idEstatusOrden = 1 then 0    
							else co.idTaller    
							end --and coti.idTaller != 0    
						left join ASEPROT.dbo.CotizacionDetalle code on code.idCotizacion = co.idCotizacion and code.idEstatusPartida in(1,2)    
						left join ASEPROT.dbo.EstatusOrdenes es on es.idEstatusOrden = o.idEstatusOrden    
						left join Partidas.dbo.partida par on par.idPartida = code.idPartida         
					--WHERE c.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
					--((e.idEmpresa = 5 and c.idContrato not in (34, 31)) or c.idContrato in(5, 7, 14, 23, 27, 41))  --34    
					where co2.idContrato is not null
						and o.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)    
						and par.descripcion like '%CAMBIO DE LLANTA%'    
					group by c.descripcion, es.nombreEstatusOrden, o.idOrden, code.cantidad, o.idEstatusOrden    
				) a    
				where a.descripcion = con.descripcion    
					and a.nombreEstatusOrden = eso.nombreEstatusOrden    
			) 'numLlantas',    
	--Subquery para obtener las ordenes de mayor antigüedad    
			(    
				select max(a.tiempoDesfasado) from     
				(    
					select DATEDIFF( day, h.fechaInicial, coalesce( h.fechaFinal, getdate() ) ) numDias, c.descripcion, es.nombreEstatusOrden, o.idOrden,    
						case     
							when opte.tiempoEnEspera is null then 0--'00:00 / 00:00'    
							when GETDATE() > DATEADD( hour, convert( int, substring( opte.tiempoEnEspera, 0, 3 ) ), h.fechaInicial )     
								then DATEDIFF(DAY, DATEADD(hour, convert(int, substring(opte.tiempoEnEspera, 0, 3 ) ), h.fechaInicial), getdate())    
							else 0    
						end     as tiempoDesfasado    
					from Partidas.dbo.Contrato c 
						left join SISCOReportServices.dbo.Contrato co2 on co2.idContrato = c.idContrato
						left join ASEPROT.dbo.ContratoOperacion copera on copera.idContrato = c.idContrato     
						left join ASEPROT.dbo.Ordenes o on o.idContratoOperacion = copera.idContratoOperacion    
						left join ASEPROT.dbo.HistorialEstatusOrden h on h.idEstatusOrden = o.idEstatusOrden and h.idOrden = o.idOrden    
						left join ASEPROT.dbo.EstatusOrdenes es on es.idEstatusOrden = o.idEstatusOrden    
						left join ASEPROT.dbo.OperacionTiempoEnEspera opte on opte.idOperacion = copera.idOperacion and opte.idEstatusOrden = o.idEstatusOrden    
						left join ASEPROT.dbo.Operaciones oper on oper.idOperacion = copera.idOperacion and tiempoAsignado = 1    
					--WHERE c.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
					--((e.idEmpresa = 5 and c.idContrato not in (34, 31)) or c.idContrato in(5, 7, 14, 23, 27, 41))  --34    
					where co2.idContrato is not null
						and o.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)    
					group by c.descripcion, es.nombreEstatusOrden, o.idOrden, h.fechaFinal, h.fechaInicial, opte.tiempoEnEspera    
				) a    
				where a.descripcion = con.descripcion    
					and a.nombreEstatusOrden = eso.nombreEstatusOrden    
			) 'diasOrdenMasAntigua'    
		from Partidas.dbo.Contrato con 
			inner join SISCOReportServices.dbo.Contrato co on co.idContrato = con.idContrato
			inner join ASEPROT.dbo.ContratoOperacion cop on cop.idContrato = con.idContrato     
			inner join ASEPROT.dbo.Ordenes ord on ord.idContratoOperacion = cop.idContratoOperacion     
			left join ASEPROT.dbo.Cotizaciones coti on coti.idOrden = ord.idOrden and coti.idEstatusCotizacion in(1,2,3) and coti.idTaller =     
				case when ord.idEstatusOrden = 1 then 0    
				else coti.idTaller    
				end --and coti.idTaller != 0    
			left join ASEPROT.dbo.CotizacionDetalle cd on cd.idCotizacion = coti.idCotizacion and cd.idEstatusPartida in (1,2)    
			left join ASEPROT.dbo.EstatusOrdenes eso on eso.idEstatusOrden = ord.idEstatusOrden    
			left join ASEPROT.dbo.HistorialEstatusOrden heo on heo.idEstatusOrden = eso.idEstatusOrden and heo.idOrden = ord.idOrden    
			left join Partidas.dbo.partida par on par.idPartida = cd.idPartida    
		where --con.idContrato in(1,4,21,7,5,30,8,27,41,34,35,13,23,19)  
		--((emp.idEmpresa = 5 and con.idContrato not in (34, 31)) or con.idContrato in(5, 7, 14, 23, 27, 41))  --34    
			ord.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)    
		group by con.descripcion, eso.idEstatusOrden, eso.nombreEstatusOrden, cop.idContratoOperacion    
	) b    
    
	order by b.contrato, b.idEstatusOrden    
END
go

