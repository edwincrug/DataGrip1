-- =============================================
-- Author:		Sahirely Yam
-- Create date: 29 08 2017
-- exec  [dbo].[INS_ORDEN_PRESUPUESTO_ESPECIAL_SP] 334, 41, 107
-- =============================================
create PROCEDURE [dbo].[INS_ORDEN_PRESUPUESTO_ESPECIAL_SP]
	@idOrden numeric(18,0),
	@idPresupuesto numeric(18,0),
	@idUsuario numeric(18,0)
AS
BEGIN
	declare @result int

		if not exists (select 1 from OrdenesPresupuestoEspecial where idOrden = @idOrden)
			begin
				INSERT INTO [dbo].[OrdenesPresupuestoEspecial] ([idOrden], [idPresupuesto], [idUsuario], [fechaAlta])
				VALUES (@idOrden, @idPresupuesto, @idUsuario, GETDATE())

				set @result = @@IDENTITY
			end
		else
			begin
				update OrdenesPresupuestoEspecial set idPresupuesto = @idPresupuesto, idUsuario = @idUsuario, fechaAlta = GETDATE()
				where idOrden = @idOrden

				select @result = [idOrdenPresupuestoEspecial]
				from [dbo].[OrdenesPresupuestoEspecial]
				where [idOrden] = @idOrden
			end

	 select @result as idOrdenEspecial
END
go

