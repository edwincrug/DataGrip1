-- =============================================
-- Author:		Sahirely Yam
-- Create date: 30 08 2017
-- =============================================
create PROCEDURE [dbo].[SEL_ORDENES_BY_PRESUPUESTO_ESPECIAL_SP] 
	@idPresupuesto numeric(18,0),
	@idContratoOperacion numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;

		select	ORD.idOrden
				, consecutivoOrden
				, numeroOrden
				, fechaCreacionOden as fechaCreacionOrden
				, EO.nombreEstatusOrden as estatus
				, ORD.comentarioOrden as comentario
				, CT.nombreCentroTrabajo
				, isnull(sum(isnull(COTDET.venta,0) * isnull(COTDET.cantidad,0)),0) as venta
				, isnull(sum(isnull(COTDET.costo,0) * isnull(COTDET.cantidad,0)),0) as costo
				, CASE  WHEN exists (select 1 from PresupuestoOrden P where P.idOrden = ORD.idOrden) THEN 1 
						ELSE 0  
					END  as isPaid
				, CASE  WHEN exists (select 1 from PresupuestoOrden P where P.idOrden = ORD.idOrden) THEN 'Cobrado'
					ELSE 'Pendiente de Cobro'
				END  as estatusCobro
		from Ordenes ORD 
		inner join ContratoOperacion CONTOPE on CONTOPE.idContratoOperacion = ORD.idContratoOperacion
		inner join Cotizaciones COTI on COTI.idOrden = ORD.idOrden
		inner join CotizacionDetalle COTDET on COTDET.idCotizacion = COTI.idCotizacion
		inner join EstatusOrdenes EO on ORD.idEstatusOrden = EO.idEstatusOrden
		inner join CentroTrabajos CT on CT.idCentroTrabajo = ORD.idCentroTrabajo and CONTOPE.idOperacion = CT.idOperacion
		inner join OrdenesPresupuestoEspecial ORDpe ON ORDpe.idOrden = ORD.idOrden
		where	ORD.idContratoOperacion = @idContratoOperacion
				and COTI.idEstatusCotizacion in (1,2,3) 
				and COTDET.idEstatusPartida in (1,2) 
				and ORDpe.idPresupuesto = @idPresupuesto
		group by ORD.idOrden, consecutivoOrden, numeroOrden, fechaCreacionOden, nombreEstatusOrden, comentarioOrden, nombreCentroTrabajo
END
go

