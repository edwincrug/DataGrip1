-- [INS_COMPROBANTE_RECEPCION_SP] 1,'03-1633010405572-000067'
CREATE PROCEDURE [dbo].[INS_COMPROBANTE_RECEPCION_SP]
@idCatalogoModuloCOmprobante INT,
@numeroOrden VARCHAR(50),
@idUsuario INT
AS
BEGIN
		 DECLARE @idOrden NUMERIC(18,0)
		 DECLARE @numeroModulos INT
		 DECLARE @idModuloComprobante INT

	 SET @idOrden = (SELECT idOrden FROM Ordenes WHERE numeroOrden = @numeroOrden )
	 SET @numeroModulos = CONVERT(INT,(SELECT COUNT(idCatalogoModuloComprobante) FROM ModuloComprobante WHERE idOrden = @idOrden))
	
	INSERT INTO ModuloComprobante VALUES(@idCatalogoModuloCOmprobante, @idOrden)
	SET @idModuloComprobante = @@IDENTITY
	SELECT @idModuloComprobante AS idModuloComprobante, 'Se agrego modulo'AS msg,1 AS estatus

END

go

