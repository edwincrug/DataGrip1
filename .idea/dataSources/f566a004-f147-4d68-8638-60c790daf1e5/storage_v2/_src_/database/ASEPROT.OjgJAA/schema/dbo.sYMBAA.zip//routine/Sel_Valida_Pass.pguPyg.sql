/*
	Objetivo: Regresa los datos de un usuario 
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrici�n
	16/08/18		LUDH	Creaci�n del SP
	
*/
CREATE PROCEDURE [dbo].[Sel_Valida_Pass]
	@idUser int,
	@msj varchar(50) OUTPUT,
	@fehcaTemp date OUTPUT 
AS
BEGIN

	 set @msj  = 'Autorizado'
	 SET @fehcaTemp = (SELECT TOP(1) [Fecha_Ins] FROM [Seguridad].[Catalogo].Pass_Expired WHERE [UserId] = 38 ORDER BY [Fecha_Ins] DESC, Id DESC)

	IF (SELECT [PassExpire] FROM [Seguridad].[Catalogo].[Users] WHERE [Id] = @idUser) = 1
	BEGIN
		IF EXISTS(SELECT * FROM [Seguridad].[Catalogo].[Pass_Expired] WHERE [UserId] = @idUser )
		BEGIN
			IF EXISTS(SELECT * FROM [Seguridad].[Catalogo].[Pass_Expired] WHERE GETDATE() >= DATEADD( MONTH, 3, @fehcaTemp))
			BEGIN
				SET @msj = 'Autorizado';
				SELECT 1 AS authorized, @msj AS msj, @idUser AS userID;
			END
			ELSE
			BEGIN
				IF EXISTS(SELECT * FROM [Seguridad].[Catalogo].[Pass_Expired] WHERE GETDATE() >= DATEADD( DAY, 85, @fehcaTemp))
				BEGIN
					SET @msj = 'Autorizado';
					SELECT 1 AS authorized,@msj AS msj, @idUser AS userID, DATEADD( MONTH, 3, @fehcaTemp) AS fechaCad;
				END
				ELSE
				BEGIN
					SET @msj = 'Autorizado';
					SELECT 1 AS authorized,@msj AS msj, @idUser AS userID;
				END
			END
		END
		ELSE
		BEGIN
			SET @msj = 'Autorizado';
			SELECT 1 AS authorized, @msj AS msj, @idUser AS userID;
		END
	END
	ELSE
	BEGIN
		SET @msj = 'Autorizado';
		SELECT 1 AS authorized, @msj AS msj, @idUser AS userID;
	END
END
go

