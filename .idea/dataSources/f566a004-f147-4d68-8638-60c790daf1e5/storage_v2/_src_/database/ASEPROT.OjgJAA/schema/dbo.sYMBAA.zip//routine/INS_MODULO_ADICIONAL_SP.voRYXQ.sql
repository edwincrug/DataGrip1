-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 28/05/2017
-- Description:	Inserta modulos adicionales por operación
-- INS_MODULO_ADICIONAL_SP 
-- =============================================
 CREATE PROCEDURE [dbo].[INS_MODULO_ADICIONAL_SP]
	 @idOperacion INT
	,@modulos NVARCHAR (MAX)
AS
BEGIN
	
  DECLARE @idCatalogoModulos INT,
		  @idModulo INT,
		  @lnuPosComa int

		WHILE  LEN(@modulos)> 0
			BEGIN
				SET @lnuPosComa = CHARINDEX(',', @modulos ) -- Buscamos el caracter separador
				IF ( @lnuPosComa!=0 )
				BEGIN
					SET @idCatalogoModulos = Substring( @modulos , 1  , @lnuPosComa-1)
					SET @modulos = Substring( @modulos , @lnuPosComa + 1 , LEN(@modulos))
				END
			IF NOT EXISTS (SELECT 1 FROM Modulos WHERE idCatalogoModulo = @idCatalogoModulos AND idOperacion = @idOperacion) 
				INSERT INTO [Modulos] (
							 [idCatalogoModulo]
							,[idOperacion])
						VALUES(
						 @idCatalogoModulos
						,@idOperacion)
			END

			SET @idModulo = @@IDENTITY 
			SELECT @idModulo AS idModulo
  
  
END


go

