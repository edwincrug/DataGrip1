 CREATE PROCEDURE [Gerente].[INS_RELACION_ESTADOS_ZONAS_SP]
	@idEstadoZona INT,
 	@idEstado INT,
	@idZona INT,
	@idContratoOperacion INT,
	@idUsuario INT,
	@cancela INT

AS
BEGIN
	--DECLARE @idZonaPadre INT
	IF(@cancela = 0)
		BEGIN 
			IF(@idEstadoZona = 0)
				BEGIN 
					IF NOT EXISTS(SELECT 1 FROM [Gerente].[EstadoZona] WHERE idZona=@idZona AND idContratoOperacion=@idContratoOperacion AND estatus=0)
						BEGIN

							INSERT [Gerente].[EstadoZona] 
							VALUES(@idEstado,@idZona,@idContratoOperacion,GETDATE(),@idUsuario,0)
							
							SELECT 'El registro se ha guardado correctamente!' msg, 1 estatus
						END
					ELSE
						BEGIN
							SELECT 'La zona a registrar ya existe!' msg, 0 estatus
						END
				END
			ELSE
				BEGIN
					IF NOT EXISTS(SELECT 1 FROM [Gerente].[EstadoZona] WHERE idEstado=@idEstado AND idZona=@idZona AND idContratoOperacion=@idContratoOperacion AND estatus=0)
					BEGIN
							UPDATE [Gerente].[EstadoZona] 
							SET idEstado=@idEstado,idZona=@idZona,idContratoOperacion=@idContratoOperacion,idUsuario=@idUsuario
							WHERE idEstadoZona=@idEstadoZona
							SELECT 'El registro se ha guardado correctamente!' msg, 1 estatus
					END
				ELSE
					BEGIN
							SELECT 'La Zona y Estado a actualizar ya existe!' msg, 0 estatus
					END
			END
		END
	ELSE
		BEGIN
			UPDATE [Gerente].[EstadoZona]
			SET estatus=1
			WHERE idEstadoZona=@idEstadoZona

			SELECT 'El registro se ha cancelado correctamente!' msg, 1 estatus
		END
END


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.INS_RELACION_ESTADOS_ZONAS_SP to DevOps
 go

