

CREATE function [dbo].[extencionArchivo](@idUnidad int,@idDocumento int)
returns varchar (max)
as begin
 declare @cons int = ( 
	select top 1 consecutivo from Flotillas..[ListaDocumentos] fup 
	join Unidades as u on u.vin=fup.vin 
	where u.idUnidad=@idUnidad 
	and fup.idDocumento=@idDocumento order by consecutivo desc)

	
 declare @extencion varchar(max)= (select top 1  valor from Flotillas..[ListaDocumentos] fup 
	join Unidades as u on u.vin=fup.vin 
	where u.idUnidad=@idUnidad 
	and fup.idDocumento=@idDocumento order by consecutivo desc)
	
	
 select top 1  @extencion= '.'+ Item from SplitString(@extencion,'.') where item in ('png','jpg','jpeg','pdf','bit')

 if @cons >1
 begin
	SET @extencion = '_' + cast(@cons as nvarchar)  +  @extencion
 end
return  cast(@idDocumento as nvarchar)+ @extencion;
end


go

