
-- =============================================
CREATE PROCEDURE [Banorte].[INS_COT_DETALLE_REFACCIONES_SPV2]
	@detalle XML,
	@idUsuario int
 AS
 BEGIN
  
 DECLARE
  @idCotizacionDetalle NUMERIC(18,0),
  @costo DECIMAL(18,4),
  @cantidad INT,
  @venta DECIMAL(18,4) = 0,
  @idEstatusPartida INT = 2,

  @idCotizacion NUMERIC(18,0),
  @idPartida NUMERIC(18,0),
  @count int,
  @idAutorizacionCot int,
  @idCotDetalle numeric(18,0), 
  @precioLista DECIMAL (18,4) = 0,
  @diasEntrega int = 0

  declare @tempIds as table (idCotizacionDetalle int);
  declare @tempDetalle as table (idTemp int, idCotizacion NUMERIC(18,0),costo DECIMAL(18,4),
		                       cantidad INT, venta DECIMAL(18,4), idPartida NUMERIC(18,0), 
							   idEstatusPartida INT, precioLista DECIMAL(18,4), diasEntrega int)


		 
	INSERT INTO @tempDetalle 
		(idTemp, idCotizacion, costo, cantidad, venta, idPartida, idEstatusPartida, precioLista, diasEntrega)
       SELECT 
	    x.value('idTemp[1]', 'INT') AS idTemp, x.value('idCotizacion[1]', 'NUMERIC(18,0)') AS idCotizacion,
	    x.value('costo[1]', 'DECIMAL(18,4)') AS costo, x.value('cantidad[1]', 'INT') AS cantidad,
		x.value('venta[1]', 'DECIMAL(18,4)') AS venta, x.value('idPartida[1]', 'NUMERIC(18,0)') AS idPartida, 
		x.value('idEstatusPartida[1]', 'INT') AS idEstatusPartida,
		x.value('precioLista[1]', 'DECIMAL(18,4)') AS precioLista,
		x.value('diasEntrega[1]', 'INT') AS diasEntrega
       FROM @detalle.nodes('//cotizacion') detalle(x)
	--select * from ##tempPartida;

	SELECT TOP 1 @idCotizacion = idCotizacion FROM @tempDetalle
	INSERT INTO [dbo].[AutorizacionCotizacion]
				   (fechaNotificacion, fechaAutorizacion, idCotizacion)
			 VALUES
				   (GETDATE(), GETDATE(), @idCotizacion)
	SET @idAutorizacionCot = @@IDENTITY

	INSERT INTO [dbo].[HistorialEstatusCotizacion] 
	([fechaInicial], [idCotizacion], [idUsuario], [idEstatusCotizacion])
	VALUES (GETDATE(), @idCotizacion, @idUsuario, 1)

	INSERT INTO [dbo].[HistorialEstatusCotizacion] 
	([fechaInicial], [idCotizacion], [idUsuario], [idEstatusCotizacion])
	VALUES (GETDATE(), @idCotizacion, @idUsuario, 2)


	WHILE (SELECT COUNT(*) FROM @tempDetalle) > 0
	BEGIN
		SELECT TOP 1 @count = idTemp, @idCotizacion = idCotizacion, @idPartida = idPartida,
				     @costo = costo, @cantidad = cantidad, @venta = venta, 
					 @precioLista = precioLista ,
					 @diasEntrega = diasEntrega FROM @tempDetalle
		
		IF NOT EXISTS( SELECT idCotizacionDetalle FROM [CotizacionDetalle] WHERE 
		               idCotizacion = @idCotizacion AND idPartida = @idPartida)
			BEGIN
				BEGIN TRY
				select top 1 * from [CotizacionDetalle] 
					INSERT INTO [CotizacionDetalle] 
						([idCotizacion],[costo],[cantidad],[venta],[idPartida],[idEstatusPartida],[rechazadas], [solicitadasOrg], [precioLista], [diasEntrega])
						values 
						(@idCotizacion, @costo, @cantidad, @venta, @idPartida, @idEstatusPartida, 0, @cantidad, @precioLista, @diasEntrega)
			 	
					SET @idCotizacionDetalle = @@IDENTITY
					
					
					IF( @idCotizacionDetalle>0)
						BEGIN
							INSERT INTO [dbo].[DetalleAutorizacionCotizacion]
							([fechaAutorizacion],[idUsuario],[idAprobacionCotizacion],
							 [idEstatusAutorizacion],[idCotizacionDetalle])
							VALUES
							(GETDATE(),@idUsuario,@idAutorizacionCot,@idEstatusPartida,@idCotizacionDetalle)

							INSERT INTO @tempIds (idCotizacionDetalle) VALUES (@idCotizacionDetalle)	
						END
					ELSE
						rollback;						 
				END TRY  
				BEGIN CATCH
					select ERROR_MESSAGE()
				END CATCH;	
			END			
		ELSE
		BEGIN
			UPDATE [CotizacionDetalle] 
					SET cantidad = @cantidad ,
						costo = @costo,
						venta = @venta,
						idEstatusPartida = @idEstatusPartida
					WHERE idCotizacion = @idCotizacion AND idPartida = @idPartida

			SELECT @idCotizacionDetalle= idCotizacionDetalle FROM [CotizacionDetalle] WHERE 
		               idCotizacion = @idCotizacion AND idPartida = @idPartida
			INSERT INTO @tempIds (idCotizacionDetalle) VALUES (@idCotizacionDetalle)
		END	
		DELETE @tempDetalle WHERE idTemp = @count
	END

	select * from @tempIds;
	
  END
go

grant execute, view definition on Banorte.INS_COT_DETALLE_REFACCIONES_SPV2 to DevOps
go

