-- =============================================
-- Author:		<Alan Rosales>
-- Create date: <07/12/2017>
-- Description:	<Obtiene número telefonico requerido para consulta de API Movistar>
-- Test: SEL_GPS_CONSULTA_MSISDN_SP 'VF3YDUMF9H2E26789'
-- =============================================
CREATE PROCEDURE SEL_GPS_CONSULTA_MSISDN_SP
	@vin	nvarchar(50)
AS
BEGIN
	select 
		SIM.carrier,
		LTRIM(RTRIM(SIM.icc)) icc,
		LTRIM(RTRIM(SIM.msisdn)) msisdn
	from GPS.dbo.UnidadGPSSIM UGPS
	inner join GPS.dbo.GPSSIM GPSSIM on GPSSIM.idGPSSIM = UGPS.idGPSSIM
	inner join GPS.dbo.SIM SIM on SIM.idSIM = GPSSIM.idSIM
	WHERE LTRIM(RTRIM(UGPS.vin)) = LTRIM(RTRIM(@vin))
END
go

