
-- Add the parameters for the function here
--[dbo].[SEL_ESTATUS_BPRO_FN] (@numeroOrden = '01-2010135-1678', @idOperacion = 1, @isProduction = 1)
CREATE FUNCTION [dbo].[SEL_ESTATUS_BPRO_FN](@numeroOrden NVARCHAR(100), @idOperacion NUMERIC(18,0), @isProduction NUMERIC(18,0))

RETURNS NVARCHAR(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result NVARCHAR(100);
	DECLARE @server NVARCHAR(100)
	DECLARE @db NVARCHAR(100)
	DECLARE	@query NVARCHAR(MAX)

	IF(@isProduction = 1)
		BEGIN
			IF(@idOperacion IN(1,2))
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					FROM [192.168.20.29].[GATPartsToluca].[dbo].[ADE_ORDSERENC]
					--FROM [GATPartsToluca].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
			ELSE IF (@idOperacion=28) --Banorte 20-Dev, 28-Prod
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					--FROM [GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]
					FROM [192.168.20.29].[GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
				ELSE
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					--FROM [GAAutoExpress].[dbo].[ADE_ORDSERENC]
					FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
		END
	ELSE
		BEGIN
			IF(@idOperacion IN(1,2))
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					FROM [GATPartsToluca_P].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
			ELSE IF (@idOperacion=20) --Banorte 20-Dev, 28-Prod
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					FROM [GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]
					--FROM [192.168.20.29].[GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
				ELSE
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					FROM [GAAutoExpress].[dbo].[ADE_ORDSERENC]
					--FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
		END

	SET @Result=
	CASE @Result
	WHEN 0 THEN 'Enviada a Aprobacion'
	WHEN 1 THEN 'Solicitada'
	WHEN 2 THEN 'Procesada'
	WHEN 3 THEN 'Aplicada'
	WHEN 4 THEN 'Cancelada'
	WHEN 5 THEN 'Autorizada para pago'
	WHEN 6 THEN 'Pago aplicado' 
	WHEN 7 THEN 'No provisionada' 
	END

	RETURN @Result;
	
END

go

