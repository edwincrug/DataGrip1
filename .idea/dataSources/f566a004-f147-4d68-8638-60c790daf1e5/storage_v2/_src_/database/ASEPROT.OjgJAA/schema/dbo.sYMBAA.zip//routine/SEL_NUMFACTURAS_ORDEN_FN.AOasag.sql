
-- =============================================
-- Create date: 29 05 2018
-- SELECT [dbo].[SEL_NUMFACTURAS_ORDEN_FN](3247)
-- =============================================
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_NUMFACTURAS_ORDEN_FN](@idOrden INT)

RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @facturas NVARCHAR(MAX) = ' ';
	DECLARE @numerosFacturas NVARCHAR(MAX) = '- ';
	DECLARE @Result NVARCHAR(MAX) = ' ';

	DECLARE contact_cursor CURSOR FOR
	select distinct numFactura
		from Cotizaciones C
		inner join facturaCotizacion FC on FC.idCotizacion=C.idCotizacion
		where idOrden = @idOrden

	OPEN contact_cursor  
	FETCH NEXT FROM contact_cursor INTO @facturas
	WHILE @@FETCH_STATUS = 0  
		BEGIN 

		--SET @talleres =(SELECT idTaller FROM Taller where idTaller=@idTaller)
		SET @numerosFacturas =  @numerosFacturas + @facturas + char(13) + char(10)+'-'

		FETCH NEXT FROM contact_cursor INTO @facturas
		END  
	CLOSE contact_cursor  
	DEALLOCATE contact_cursor

	IF((@numerosFacturas IS NOT NULL) AND @numerosFacturas != '')
		SET @Result= SUBSTRING (@numerosFacturas, 1, Len(@numerosFacturas) - 1 )

	RETURN @Result;
	
END
go

