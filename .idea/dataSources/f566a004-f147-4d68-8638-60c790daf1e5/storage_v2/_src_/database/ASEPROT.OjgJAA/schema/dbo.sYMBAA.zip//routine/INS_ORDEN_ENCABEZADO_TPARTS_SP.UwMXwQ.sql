--SELECT * FROM Cotizaciones
--SELECT * FROM ContratoOperacionFacturacion
CREATE PROC [dbo].[INS_ORDEN_ENCABEZADO_TPARTS_SP] --54,291,107,1,0
	@idCotizacion NUMERIC(18,0),
	@idProveedor NUMERIC(18,0),
	@idUsuario NUMERIC(18,0),
	@idOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0)

AS
BEGIN
--INFORMACION DE LA OPERACION BD
DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE @idCliBPRO INT
DECLARE @DESGLOSE VARCHAR(5)
DECLARE @IdEncabezado DECIMAL(18,0)
--INFORMACION DE LA ORDEN
DECLARE @numeroTrabajo  NVARCHAR(100) 
DECLARE @numeroCotizacion  NVARCHAR(100) 
DECLARE @idOrden INT
DECLARE @existe INT 
--DATOS DE IDBPRO
DECLARE @idBPRO NUMERIC(18,0)
--DATOS DE UNIDAD
DECLARE @fechaCreacionOrden  varchar(50)
declare @numeroSerie varchar(50)
declare @marcaVehiculo  varchar(200)
declare @placas varchar(50)
declare @catalogo varchar(500)
declare @modelo varchar(10)
declare @tipoMotor varchar(100)
declare @cilindros varchar(50)
declare @tipoAuto varchar(200)
declare @kilometraje varchar(200) = 1
declare @asesor varchar(50)
declare @tecnico varchar(50)
declare @clasificacionMO varchar(50)
declare @colorExterior varchar(50)
declare @colorInterior varchar(50)
declare @identificadorTO varchar(50)
DECLARE @idContratoOperacion VARCHAR(5)

SELECT @idContratoOperacion=idContratoOperacion FROM ContratoOperacion WHERE idOperacion=@idOperacion

IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server = SERVER,
				@db = DBProduccion
		FROM CatalogoTecnico CT 
		WHERE CT.IdProveedor =  @idProveedor
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB
		FROM CatalogoTecnico CT 
		WHERE CT.IdProveedor =  @idProveedor
	END
----------------------------------------------------------------
--INFORMACION DE LA ORDEN
	SELECT	@numeroCotizacion=numeroCotizacion, 
			@idOrden=idOrden
	FROM Cotizaciones 
	WHERE idCotizacion=@idCotizacion

	SELECT TOP 1
		@numeroTrabajo=O.numeroOrden,
		@fechaCreacionOrden=O.fechaCreacionOden
	FROM Ordenes O
	JOIN Cotizaciones C ON C.idOrden = O.idOrden
	WHERE C.idCotizacion = @idCotizacion

	--GROUP BY O.numeroOrden,O.fechaCreacionOden
----------------------------------------------------------------
--COMPRUEBA ESTADO DE LA ORDEN
	DECLARE @queryText VARCHAR(MAX) = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc] WHERE [oae_ordenglobal] = '''+@numeroTrabajo+''') THEN 1 ELSE 0 END'
	DECLARE @tableTemp TABLE (val INT)
	INSERT INTO @tableTemp 
	EXEC(@queryText) 				
	SET @existe = (SELECT TOP 1 val FROM @tableTemp)
	--SET @existe = 0

----------------------------------------------------------------
--DATOS DE IDBPRO Empresa
	DECLARE @idEmpresa INT
	DECLARE @idProveedorEncabezado INT

	SELECT @idEmpresa=E.idEmpresa FROM ContratoOperacion CO
	JOIN Partidas..Contrato C ON C.idContrato = CO.idContrato
	JOIN Partidas..Licitacion L ON L.idLicitacion=C.idLicitacion
	JOIN Partidas..Empresa E ON E.idEmpresa = L.idEmpresa
	WHERE CO.idContratoOperacion=@idContratoOperacion

	SELECT @idProveedorEncabezado=P.idProveedorEncabezado
	FROM Cotizaciones C 
	JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = C.idTaller
	WHERE idCotizacion=@idCotizacion
		
	SELECT @idBPRO=idBPRO 
	FROM Partidas..ProveedorEncabezadoEmpresa 
	WHERE idEmpresa=@idEmpresa AND idProveedorEncabezado=@idProveedorEncabezado

----------------------------------------------------------------
--Datos de catalogo de tecnicos
	SELECT	
	@asesor = Asesor,
	@tecnico = Tecnico,
	@clasificacionMO = ClasificacionMO,
	@colorExterior = ColorExterior,
	@colorInterior = ColorInterior,
	@identificadorTO = IdentificadorTO 
	FROM CatalogoTecnico WHERE IdProveedor = @idProveedor


---------------------------------------------------------------------
--DATOS DE UNIDAD
		select @numeroSerie = vin
		from Ordenes O
		inner join Cotizaciones C on C.idOrden = O.idOrden
		inner join Unidades U on U.idUnidad = O.idUnidad
		where C.idCotizacion = @idCotizacion
		select @marcaVehiculo = M.nombre
		from Ordenes O
		inner join Cotizaciones C on C.idOrden = O.idOrden
		inner join Unidades U on U.idUnidad = O.idUnidad
		inner join Partidas..Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas..SubMarca SM on SM.idSubMarca = UP.idSubMarca
		inner join Partidas..Marca M on M.idMarca = SM.idMarca
		where C.idCotizacion = @idCotizacion
		select @placas = placas
		from Ordenes O
		inner join Cotizaciones C on C.idOrden = O.idOrden
		inner join Unidades U on U.idUnidad = O.idUnidad
		where C.idCotizacion = @idCotizacion
		select @catalogo = TU.tipo
		from Ordenes O
		inner join Cotizaciones C on C.idOrden = O.idOrden
		inner join Unidades U on U.idUnidad = O.idUnidad
		inner join Partidas..Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas..TipoUnidad TU on TU.idTipoUnidad = UP.idTipoUnidad
		where C.idCotizacion = @idCotizacion
		select @modelo = modelo
		from Ordenes O
		inner join Cotizaciones C on C.idOrden = O.idOrden
		inner join Unidades U on U.idUnidad = O.idUnidad
		where C.idCotizacion = @idCotizacion
		select @tipoMotor = TC.tipoCombustible
		from Ordenes O
		inner join Cotizaciones C on C.idOrden = O.idOrden
		inner join Unidades U on U.idUnidad = O.idUnidad
		inner join Partidas..Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas..TipoCombustible TC on TC.idTipoCombustible = UP.idTipoCombustible
		where C.idCotizacion = @idCotizacion
		select @cilindros = CIL.cilindros
		from Ordenes O
		inner join Cotizaciones C on C.idOrden = O.idOrden
		inner join Unidades U on U.idUnidad = O.idUnidad
		inner join Partidas..Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas..Cilindros CIL on CIL.idCilindros = UP.idCilindros
		where C.idCotizacion = @idCotizacion
		select @tipoAuto = SM.nombre
		from Ordenes O
		inner join Cotizaciones C on C.idOrden = O.idOrden
		inner join Unidades U on U.idUnidad = O.idUnidad
		inner join Partidas..Unidad UP on UP.idUnidad = U.idTipoUnidad
		inner join Partidas..SubMarca SM on SM.idSubMarca = UP.idSubMarca
		where C.idCotizacion = @idCotizacion
		select @kilometraje = descripcion
		from DetalleModuloComprobante DMC
		inner join ModuloComprobante MC on MC.idModuloComprobante = DMC.idModuloComprobante
		inner join Ordenes O on O.idOrden = MC.idOrden
		inner join Cotizaciones C on C.idOrden = O.idOrden 
		where C.idCotizacion = @idCotizacion
		and idCatalogoDetalleModuloComprobante = 30
		print 'prueba 1'
	IF(@existe = 0)
		BEGIN
			DECLARE @insertQuery VARCHAR(MAX) = 
		'INSERT INTO '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc](' + char(13) + 
				'oae_tipoorden,' + char(13) +
				'oae_idcliente,' + char(13) +
				'oae_numeroserie,' + char(13) +
				'oae_kilometraje,' + char(13) +
				'oae_fechaorden,' + char(13) +
				'oae_horaorden,' + char(13) +
				'oae_torre,' + char(13) +
				'oae_idasesor,' + char(13) +
				'oae_fecpromentrega,' + char(13) +
				'oae_horapromentrega,' + char(13) +
				'oae_ivaorden,' + char(13) +
				'oae_marca,' + char(13) +
				'oae_placas,' + char(13) +
				'oae_colorexterior,' + char(13) +
				'oae_colorinterior,' + char(13) +
				'oae_catalogo,' + char(13) +
				'oae_aniomodelo,' + char(13) +
				'oae_tipomotor,' + char(13) +
				'oae_cilindros,' + char(13) +
				'oae_transmision,' + char(13) +
				'oae_traccion,' + char(13) +
				'oae_tipoauto,' + char(13) +
				'oae_moneda,' + char(13) +
				'oae_estatus,' + char(13) +
				'oae_ordenbpro,' + char(13) +
				'oae_submo,' + char(13) +
				'oae_subref,' + char(13) +
				'oae_sublub,' + char(13) +
				'oae_ordenglobal,' + char(13) +
				'oae_observaciones' + char(13) + 
				')' + char(13) + 
				'SELECT ' + char(13) + 
				' '''+convert(varchar(max),@identificadorTO)+''',' + char(13) +
				' '+convert(varchar(max),@idBPRO)+',' + char(13) + 
				' '''+convert(varchar(max),@numeroSerie)+''',' + char(13) + -- unidad
				' '+convert(varchar(max),@kilometraje)+',' + char(13) + -- unidad
				' CONVERT(VARCHAR(10),O.fechaCreacionOden,103),' + char(13) + 
				' CONVERT(VARCHAR(5),O.fechaCreacionOden,108),' + char(13) + 
				' ''N/A'',' + char(13) + 
				' '''+convert(varchar(max),@asesor)+''',' + char(13) + 
				' CONVERT(VARCHAR(10),DATEADD(day, 5, O.fechaCreacionOden),103),' + char(13) + 
				' CONVERT(VARCHAR(5),O.fechaCreacionOden,108),' + char(13) + 
				' CAST([dbo].[fnFactorIVA_Orden](O.idOrden,0)*100 AS VARCHAR(25)), ' + char(13) + 
				' '''+convert(varchar(max),@marcaVehiculo)+''',' + char(13) + -- unidad
				' '''+convert(varchar(max),@placas)+''',' + char(13) + -- unidad
				' '''+convert(varchar(max),@colorExterior)+''',' + char(13) + 
				' '''+convert(varchar(max),@colorInterior)+''',' + char(13) +
				' '''+convert(varchar(max),@catalogo)+''',' + char(13) + -- unidad 
				' '''+convert(varchar(max),@modelo)+''',' + char(13) + -- unidad 
				' '''+convert(varchar(max),@tipoMotor)+''',' + char(13) + -- unidad 
				--' '''+convert(varchar(max),@cilindros)+''',' + char(13) + -- unidad 
				' ''N/A'', ' + char(13) + 
				' ''ACTUALIZAR'', ' + char(13) + 
				' ''ACTUALIZAR'', ' + char(13) +
				' '''+convert(varchar(max),@tipoAuto)+''',' + char(13) + -- unidad 
				' ''PE'', ' + char(13) +
				' 0, ' + char(13) +
				' '''', ' + char(13) +
				' 0,' + char(13) +
				' 0,' + char(13) +
				' 0,' + char(13) +
				' '''+convert(varchar(max),@numeroTrabajo)+''',' + char(13) + -- unidad
				' ''''' + char(13) + 
		'FROM Ordenes O' + char(13) + 
			'JOIN Cotizaciones C ON C.idOrden  = O.idOrden ' + char(13) + 
			'JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion ' + char(13) + 
		'WHERE C.idCotizacion = '+convert(varchar(max),@idCotizacion)+' ' + char(13) + 
			'AND CD.idEstatusPartida IN(2)' + char(13) + 
			'AND C.idEstatusCotizacion IN(3)' + char(13) + 
		'GROUP BY C.numeroCotizacion, O.numeroOrden, O.idOrden, O.fechaCreacionOden'
		print @insertQuery	
			EXEC(@insertQuery) 
								
			print 'prueba 2'
			DECLARE @qT VARCHAR(MAX) = 'SELECT ISNULL(MAX(OAE_IDORDEN),1) FROM '+@server+'.'+@db+'.[dbo].[ser_ordenesaseenc]' 
			DECLARE @tT TABLE (val INT)
			INSERT INTO @tT
			EXEC(@qT) 
			print 'prueba 3'
			SELECT @IdEncabezado = (SELECT TOP 1 val FROM @tT)
			PRINT 'EL ENCABEZADO LLAMA AL DETALLE'				
			EXEC [INS_ORDEN_DETALLE_TPARTS_SP] @idCotizacion, @IdEncabezado, @clasificacionMO, @tecnico , @idOperacion, @isProduction, @idProveedor
		END	
END
go

