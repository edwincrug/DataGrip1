
-- =============================================
-- Author:		Jose Armando Garcia Arroyo
-- Create date: 18/05/2018
-- [Banorte].[GET_TALLERES_RANKING]
-- =============================================

CREATE PROC [Banorte].[GET_TALLERES_RANKING]
@idUnidad int=0,
@latitud VARCHAR(MAX),
@longitud VARCHAR(MAX)
AS
BEGIN

DECLARE @origen GEOGRAPHY;
SET @origen = GEOGRAPHY::STPointFromText('POINT('+@longitud+' '+@latitud+')',4326);

DECLARE @idTipoUnidad int=0;
DECLARE @idZona int=0;
DECLARE @idContratoOperacion int=0;

SET @idTipoUnidad=(select idTipoUnidad from Unidades where idUnidad=@idUnidad);
SET @idZona=(select distinct idZona from Unidades where idUnidad=@idUnidad);
SET @idContratoOperacion=(select top 1 idContratoOperacion from usuarioUnidadContratoOperacion where idUnidad=@idUnidad)

SELECT 
idProveedor,nombreComercial,idTaller,razonSocial,RFC,direccion,latitud,longitud,calificacionTaller
,Distancia = CAST(@origen.STDistance(Destino)/1000 AS VARCHAR(25))+' Km'
FROM(
SELECT * 
, Destino= 
	CASE WHEN ISNUMERIC(SUBSTRING(latitud,0,8))=1 
	AND ISNUMERIC(SUBSTRING(longitud,0,8))=1
	AND CONVERT(FLOAT,SUBSTRING(latitud,0,8)) BETWEEN -90 AND 90 
	AND CONVERT(FLOAT,SUBSTRING(longitud,0,8)) BETWEEN -180 AND 180 
	THEN
	GEOGRAPHY::STPointFromText('POINT('+longitud+' '+latitud+')',4326)
	--'SI'
	--CONVERT(FLOAT,SUBSTRING(longitud,0,8))
	ELSE 
	NULL
	END
FROM (
SELECT	DISTINCT P.idProveedor AS idProveedor
		,P.nombreComercial
		,P.idProveedor idTaller
		,P.razonSocial
		,P.RFC 
		,P.direccion
		,latitud=REPLACE(REPLACE(P.latitud,' ',''),',','')
		,longitud=REPLACE(REPLACE(P.longitud,' ',''),',','')
		,isnull(Rank,0) as calificacionTaller
		--,z.nombre
FROM	[dbo].[ContratoOperacion] CO
		INNER JOIN .[Partidas].[dbo].[ContratoProveedor] CPRO ON CPRO.idContrato = CO.idContrato
		INNER JOIN .[Partidas].[dbo].[Proveedor] P ON P.idProveedor = CPRO.idProveedor
		INNER JOIN .[Partidas].[dbo].Unidad U ON U.idUnidad =  @idTipoUnidad
        INNER JOIN [Partidas].[dbo].ProveedorTipoCombustible tc on tc.idTipoCombustible = u.idTipoCombustible and tc.idProveedor = P.idProveedor 
		INNER JOIN .[Partidas].[dbo].[ContratoProveedorZona] CPROZ ON CPROZ.idContratoProveedor = CPRO.idContratoProveedor
		INNER JOIN .[Partidas].[dbo].[Zona] Z ON Z.idZona = CPROZ.idZona --and CPROZ.idZona=@idZona
		INNER JOIN .[Partidas].[dbo].[NivelZona] NZ ON Z.idNivelZona = NZ.idNivelZona
		INNER JOIN usuarioUnidadContratoOperacion uucop on uucop.idContratoOperacion=co.idContratoOperacion
		LEFT JOIN rankTaller on P.idProveedor=idTaller 
 where  CO.idContratoOperacion= @idContratoOperacion and len(P.latitud)>0 and len(P.longitud)>0
-- where  CO.idContratoOperacion= 9 and len(P.latitud)>0 and len(P.longitud)>0
) AS R1
) AS R2
END
go

grant execute, view definition on Banorte.GET_TALLERES_RANKING to DevOps
go

