-- select [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](190, 1, null)
CREATE FUNCTION [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](@idOrden NUMERIC(18,0), @idTipoDocumento INT, @idCotizacion INT)
RETURNS INT
AS
BEGIN
	-- FUNCIÓN PARA SABER SI LA ORDEN TIENE DETERMINADO DOCUMENTO
	DECLARE @TieneDocumento INT = 0
	DECLARE @CuantosDocumentos INT = (SELECT COUNT(*) 
											FROM [dbo].[DocumentosOrdenes] 
											WHERE [idOrden] = @idOrden 
												  AND [idCatalogoDocumento] = @idTipoDocumento
												  AND ((@idCotizacion = 0)OR(idCotizacion = @idCotizacion)))

	IF (@CuantosDocumentos > 0)
		BEGIN
			SET @TieneDocumento = 1
		END

	RETURN @TieneDocumento

END

go

