

-- =============================================
-- Author:		<YJH>
-- Create date: <17/05/2018>
-- Description:	<Devuele todas las partidas de mantenimiento existentes>
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_PARTIDAS_MTO_SP] 	
@descripcion nvarchar(max)
AS
BEGIN
	  SELECT distinct descripcion
	  --idTipoPartida	  
      --,idTipoPartida	  
      --,PART.idUnidad, 
	  ,idPartida, 
	  PART.partida, PART.noParte,
	  PART.foto, PART.instructivo, PART.[idEspecialidad]
  FROM [Partidas].[dbo].[Partida] PART 
  where idTipoPartida is not null and idEspecialidad = 11 and Part.descripcion like '%'+@descripcion+'%'  
  GROUP BY idEspecialidad, PART.idPartida, PART.partida, PART.noParte,
		   PART.descripcion, PART.foto, PART.instructivo
END

go

grant execute, view definition on Banorte.SEL_PARTIDAS_MTO_SP to DevOps
go

