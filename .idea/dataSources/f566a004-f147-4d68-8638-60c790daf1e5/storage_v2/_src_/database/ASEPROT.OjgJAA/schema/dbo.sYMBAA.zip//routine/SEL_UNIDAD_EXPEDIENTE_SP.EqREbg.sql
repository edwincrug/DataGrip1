-- =============================================
-- Description:	Obtiene el expediente electrónico de documentos de una unidad
-- SEL_UNIDAD_EXPEDIENTE_SP
-- =============================================
CREATE PROCEDURE [dbo].[SEL_UNIDAD_EXPEDIENTE_SP]
  @idUnidad numeric(18,0)
AS
BEGIN

	SELECT 'http://189.204.141.193:5101/partidas/' + frente as foto
					,1 as tipo
					,'Foto Frente' as descripcion
					,null as vigencia
					,1 as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and frente is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + derecho as foto
					,1 as tipo
					,'Foto Derecha' as descripcion
					,null as vigencia
					,1 as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and derecho is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + izquierdo as foto
					,1 as tipo
					,'Foto Izquierda' as descripcion
					,null as vigencia
					,1 as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and izquierdo is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + atras as foto
						,1 as tipo
					,'Foto Atrás' as descripcion
					,null as vigencia
					,1 as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and atras is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + tarjeta as foto
						,1 as tipo
					,'Tarjeta' as descripcion
					,null as vigencia
					,1 as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and tarjeta is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + repuve as foto
						,2 as tipo
					,'REPUVE' as descripcion
					,null as vigencia
					,1 as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and repuve is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + placavin as foto
						,1 as tipo
					,'Placa VIN' as descripcion
					,null as vigencia
					,1 as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and placavin is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + verificacionAmbiental as foto
						,1 as tipo
					,'Verificación Ambiental' as descripcion
					,fechaVencimientoVerificacionAmbiental as vigencia
					,(case when fechaVencimientoVerificacionAmbiental <= getdate() then 0 else 1 end) as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and verificacionAmbiental is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + verificacionFisicoMecanica as foto
						,1 as tipo
					,'Verificación Físicomecánica' as descripcion
					,fechaVencimientoVerificacionFisicoMecanica as vigencia
					,(case when fechaVencimientoVerificacionFisicoMecanica <= getdate() then 0 else 1 end) as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and verificacionFisicoMecanica is not null
	UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + refrendo as foto
						,1 as tipo
					,'Refrendo' as descripcion
					,fechaVencimientoRefrendo as vigencia
					,(case when fechaVencimientoRefrendo <= getdate() then 0 else 1 end) as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and refrendo is not null
	UNION ALL
		SELECT 'http://189.204.141.193:5101/partidas/' + tenencia as foto
					,1 as tipo
					,'Tenencia' as descripcion
					,fechaVencimientoTenencia as vigencia
					,(case when fechaVencimientoTenencia <= getdate() then 0 else 1 end) as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and tenencia is not null
		UNION ALL
	SELECT 'http://189.204.141.193:5101/partidas/' + autorizacion as foto
					,2 as tipo
					,'Autorización' as descripcion
					,null as vigencia
					,1 as estatusVigencia
				FROM	
				Unidades 
				where idUnidad =  @idUnidad
				and autorizacion is not null
				
	END
go

