
-- =============================================
-- Description:	Genera preorden de servicio a ordenes que no se les creo la preorden 
-- =============================================
--SELECT * FROM ORDENES WHERE NUMEROORDEN = '57-PMX08624-40590'
--SELECT * FROM Cotizaciones WHERE idorden = 251730
--SELECT * FROM cotizacionDetalle WHERE idCotizacion = 459401
-- PEMEX 305699
-- 97 315177
--SSC 166347
-- 23 373406
-- 65 441863
-- 75 430622
/*[dbo].[EXT_GENERA_PREORDEN_SP] 251730
*/
CREATE PROCEDURE [dbo].[EXT_GENERA_PREORDEN_SP] 
	@idOrden NUMERIC(18,0)
AS
BEGIN
	DECLARE @IDUSUARIO NUMERIC(18,0);
	DECLARE @NUMEROCOTIZACION VARCHAR (50);
	DECLARE @TIPOORDENSERVICIO NUMERIC(18,0);
	DECLARE @IDCOTIZACION NUMERIC(18,0);

	SET @IDUSUARIO = (SELECT idUsuario FROM Ordenes WHERE idOrden = @idOrden);
	SET @NUMEROCOTIZACION = (SELECT numeroOrden + '-1' FROM Ordenes WHERE idOrden = @idOrden);
	SET @TIPOORDENSERVICIO = (SELECT idCatalogoTipoOrdenServicio FROM Ordenes WHERE idOrden = @idOrden);

	--select @IDUSUARIO
	--select @NUMEROCOTIZACION
	--select @TIPOORDENSERVICIO


	INSERT INTO Cotizaciones
		VALUES(
		GETDATE(),
		0,
		@IDUSUARIO,
		5,
		@IDORDEN,
		@NUMEROCOTIZACION,
		1,
		@TIPOORDENSERVICIO,
		NULL,
		NULL,
		NULL
		)

	SET @IDCOTIZACION = (SELECT idcotizacion FROM Cotizaciones WHERE idOrden = @idOrden);

	--select @IDCOTIZACION

	INSERT INTO CotizacionDetalle
		SELECT top(1)
		@IDCOTIZACION	
		,costo	
		,1	
		,venta	
		,idPartida	
		,1	
		,rechazadas	
		,solicitadasOrg	
		,idCotizacionDetalleOrg	
		,idCotizacionOrg	
		,precioLista	
		,diasEntrega	
		,idMotivoDevolucion	
		,recibidas
		FROM CotizacionDetalle WHERE idCotizacion = 305699

	

	insert into HistorialEstatusCotizacion values (GETDATE(),NULL,@IDCOTIZACION,@IDUSUARIO,5)
END
go

