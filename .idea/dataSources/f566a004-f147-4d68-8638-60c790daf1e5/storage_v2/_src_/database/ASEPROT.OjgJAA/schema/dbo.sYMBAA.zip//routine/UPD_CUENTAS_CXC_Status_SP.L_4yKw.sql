


-- [SEL_CUENTAS_CXC_SP] 1, 1
-- [SEL_CUENTAS_CXC_SP] 3, 1
-- 2017 10 October 16
-- Luis Alvarez del Castillo Bermudez
-- Actualizar el estatus en Bpro
-- select * from FacturaCotizacion
CREATE PROC [dbo].[UPD_CUENTAS_CXC_Status_SP]
@idOperacion NUMERIC(18,0),
@isProduction NUMERIC(18,0)


AS
BEGIN
	
	BEGIN
	IF(@isProduction = 1)
		BEGIN
		IF(@idOperacion = 1)
			BEGIN
				EXEC UDP_CUENTAS_X_COBRAR_GATPartsToluca_SP
			END
		ELSE
			BEGIN
				EXEC UDP_CUENTAS_X_COBRAR_GAAUTOEXPRESS_SP
			END 	
		END
	ELSE IF(@isProduction = 0)
		BEGIN
			IF(@idOperacion = 1)
				BEGIN
					EXEC SEL_CUENTAS_X_COBRAR_GATPartsToluca_P_SP
				END
			ELSE
				BEGIN
					EXEC SEL_CUENTAS_X_COBRAR_GAAutoExpressprueba_SP
				END
		END	
	END
END
go

