-- ==========================================================================================
-- CREAT AUTH:  Jordan Gómez
--- AUTH MOD: YJH
-- CREAT DATE:  23/05/2018
-- ALTER DESC:  Se inserta los datos en las tablas de bpro dependiendo SER o REF
-- ==========================================================================================
CREATE PROC [Banorte].[INS_ORDEN_ENCABEZADO_REFACCIONES_SP] 
    @idCotizacion NUMERIC(18,0),
    @fecha DATETIME = NULL,
    @numFactura NVARCHAR(MAX) = '0',
    @UUID NVARCHAR(MAX) = '0',
    @XMLFactura NVARCHAR(MAX) = '0',
    @totalFactura DECIMAL(18,2) = 0.00,
    @idUsuario NUMERIC(18,0),
    @idOperacion NUMERIC(18,0),
    @isProduction NUMERIC(18,0)
AS
BEGIN
DECLARE @db NVARCHAR(100)
DECLARE @idCliBPRO INT
DECLARE @DESGLOSE VARCHAR(5)
DECLARE @idContratoOperacion VARCHAR(5)
DECLARE @idTaller INT
SELECT @idContratoOperacion=idContratoOperacion FROM ContratoOperacion WHERE idOperacion=@idOperacion

IF(@isProduction = 1)
    BEGIN
        SELECT                 
               @db= SERVER+'.'+DBProduccion, 
			   @idCliBPRO = [idClienteBpro],
			   @DESGLOSE = desglose
        FROM ASEPROT.dbo.ContratoOperacionFacturacion 
        WHERE idContratoOperacion =  @idContratoOperacion
    END
ELSE
    BEGIN
        SELECT 
                @db=DB,
				 @idCliBPRO = [idClienteBpro],
				 @DESGLOSE = desglose
        FROM ASEPROT.dbo.ContratoOperacionFacturacion
		WHERE idContratoOperacion = @idContratoOperacion
	END
----------------------------------------------------------------
DECLARE @idCita DECIMAL(18,0)
DECLARE @OTE_IDCLIENTE DECIMAL(18,0)
----------------------------------------------------------------
DECLARE @IdEncabezado DECIMAL(18,0) = 0
DECLARE @fechaFormat NVARCHAR(10);
DECLARE @montoMinimo DECIMAL(18,2)
DECLARE @montoMaximo DECIMAL(18,2)
DECLARE @tipoDetalle SMALLINT = 1 --1: servicio, 2: refacciones
DECLARE @referencia NVARCHAR(10) = '01'
SET @montoMinimo = @totalFactura - 1
SET @montoMaximo = @totalFactura + 1 
DECLARE @numeroTrabajo  NVARCHAR(100) = ''
DECLARE @existe INT = 0
DECLARE @numeroCotizacion NVARCHAR(100) = ''
DECLARE @isProveedor NUMERIC(18,0)
DECLARE @status NUMERIC(18,0)
----------------------------------------------------------------
DECLARE @numerodeCotizacion NVARCHAR(100)
DECLARE @idTrabajo NVARCHAR(100)
DECLARE @ideCotizacion NVARCHAR(100)
DECLARE @rutainicio NVARCHAR(100) = '\\192.168.20.18\orden\'
DECLARE @rutafin NVARCHAR(100) = '\'
DECLARE @archivo NVARCHAR(100) = 'Factura_'
DECLARE @extencionPDF NVARCHAR(100) = '.pdf'
DECLARE @extencionXML NVARCHAR(100) = '.xml'
DECLARE @OTE_XMLCOMPRA NVARCHAR(MAX)
DECLARE @OTE_PDFCOMPRA NVARCHAR(MAX)
DECLARE @OTE_RUTAXML NVARCHAR(MAX)
DECLARE @OTE_RUTAPDF NVARCHAR(MAX)
DECLARE @idBPRO NUMERIC(18,0)
DECLARE @OTE_NUMSINIESTRO VARCHAR(30)
DECLARE @OTE_NUMPOLIZA VARCHAR(100)

----------------------------------------------------------------
SELECT @fechaFormat = CONVERT(NVARCHAR(10),ISNULL(@fecha, GETDATE()),103)   
    SET @status = '0'
----------------------------------------------------------------
SET @tipoDetalle = 1

----------------------------------------------------------------
    SELECT 
        @numeroTrabajo=O.numeroOrden, 
		@idTaller=O.idTaller,
		@idBPRO = O.idBproProveedor
    FROM Ordenes O
    JOIN Cotizaciones C ON C.idOrden = O.idOrden
    JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
    WHERE C.idCotizacion = @idCotizacion AND CD.idEstatusPartida IN(1,2)
    GROUP BY O.numeroOrden, O.idTaller, O.idBproProveedor
	
	declare @idContrato int 
	select @idContrato = idContrato from ASEPROT.dbo.ContratoOperacion where idContratoOperacion=@idContratoOperacion

	select @referencia=Z.referencia from Partidas.dbo.Proveedor P 
	inner join Partidas.dbo.ContratoProveedor CP on CP.idProveedor = P.idProveedor
	inner join Partidas.dbo.ContratoProveedorZona CPZ on CP.idContratoProveedor = CPZ.idContratoProveedor
	inner join Partidas.dbo.Zona Z on Z.idZona = CPZ.idZona
	where P.idProveedor=@idTaller and CP.idContrato=@idContrato --and P.idContrato=@idContrato
	
----------------------------------------------------------------
    SET @numeroCotizacion = (SELECT numeroCotizacion FROM Cotizaciones WHERE idCotizacion=@idCotizacion)
----------------------------------------------------------------
    IF(@tipoDetalle=1) --servicio
        BEGIN
            declare @queryText varchar(max) = 
            'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENPEMEX] = '''+@numeroCotizacion+''') THEN 1 ELSE 0 END' + char(13) + ''
			--PRINT 'QUERY TEXT: ' + @queryText
            declare @tableTemp table (val int)
            insert into @tableTemp exec(@queryText) 
            set @existe = (select top 1 val from @tableTemp)
			
        END
----------------------------------------------------------------
        SELECT  @numerodeCotizacion=numeroCotizacion, 
                @idTrabajo=idOrden,
                @ideCotizacion=idCotizacion  
        FROM Cotizaciones 
        WHERE idCotizacion=@idCotizacion

	SELECT @OTE_NUMSINIESTRO = RMOS.numeroReclamo, @OTE_NUMPOLIZA = RMOS.numeroPoliza 
	FROM Ordenes O
	INNER JOIN Cotizaciones C ON O.idOrden = C.idOrden AND C.idEstatusCotizacion = 3
	INNER JOIN Unidades U ON O.idUnidad = U.idUnidad
	INNER JOIN [RefaccionMultiMarca].[Operacion].[Unidad] RMOU ON RMOU.vin = U.vin
	INNER JOIN [RefaccionMultiMarca].[Relacion].[SiniestroOrdenCotizacion] RRSO ON RRSO.idOrden = O.idOrden
	INNER JOIN [RefaccionMultiMarca].[Operacion].[Siniestro] RMOS ON RRSO.idSiniestro = RMOS.id
	WHERE C.idCotizacion = @idCotizacion

    SET @OTE_RUTAXML = @rutainicio+@idTrabajo+'\factura\'+@ideCotizacion+@rutafin
    SET @OTE_RUTAPDF = @rutainicio+@idTrabajo+'\factura\'+@ideCotizacion+@rutafin
    SET @OTE_PDFCOMPRA = @archivo+@numerodeCotizacion+@extencionPDF
    SET @OTE_XMLCOMPRA = @archivo+@numerodeCotizacion+@extencionXML
----------------------------------------------------------------
SELECT @idCita = idOrden FROM Ordenes WHERE idOrden=@idTrabajo

	--// Empresa
	DECLARE @idEmpresa INT
	DECLARE @idProveedorEncabezado INT

	SELECT @idEmpresa=E.idEmpresa FROM ContratoOperacion CO
	JOIN Partidas..Contrato C ON C.idContrato = CO.idContrato
	JOIN Partidas..Licitacion L ON L.idLicitacion=C.idLicitacion
	JOIN Partidas..Empresa E ON E.idEmpresa = L.idEmpresa
	WHERE CO.idContratoOperacion=@idContratoOperacion

	SELECT @idProveedorEncabezado=P.idProveedorEncabezado
	FROM Cotizaciones C 
	JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = C.idTaller
	WHERE idCotizacion=@idCotizacion
	
	--select @idBPRO = ISNULL( (SELECT idBPRO FROM Partidas..ProveedorEncabezadoEmpresa  WHERE idEmpresa=@idEmpresa AND idProveedorEncabezado=@idProveedorEncabezado), 0) 

    SELECT @OTE_IDCLIENTE = @idCliBPRO--1313 --1420 
----------------------------------------------------------------
	IF(@existe = 0)
        BEGIN
            IF(@tipoDetalle=1) --servicio
            BEGIN
			PRINT 'IDBPRO : '
			PRINT @idBPRO
			print @OTE_IDCLIENTE
                        declare @insertQuery varchar(max) = 
'                       INSERT INTO '+@db+'.[dbo].[ADE_ORDSERENC](' + char(13) + 
'                               [OTE_ORDENPEMEX],' + char(13) + 
'                               [OTE_ORDENANDRADE],' + char(13) + 
'                               [OTE_REFERENCIA],' + char(13) + 
'                               [OTE_IDPROVEEDOR],' + char(13) + 
'                               [OTE_FECHAORDEN],' + char(13) + 
'                               [OTE_FACTURACOMPRA],' + char(13) + 
'                               [OTE_TASAIVA],' + char(13) + 
'                               [OTE_SUBTOTAL],' + char(13) + 
'                               [OTE_IVA],' + char(13) + 
'                               [OTE_TOTAL],' + char(13) + 
'                               [OTE_UUID],' + char(13) + 
'                               [OTE_XMLCOMPRA],' + char(13) + 
'                               [OTE_FECHOPE],' + char(13) + 
'                               [OTE_HORAOPE],' + char(13) + 
'                               [OTE_STATUS],' + char(13) + 
'                               [OTE_FECHAPROCESO],' + char(13) + 
'                               [OTE_HORAPROCESO],' + char(13) + 
'                               [OTE_ORDENGLOBAL],' + char(13) + 
'                               [OTE_PDFCOMPRA],' + char(13) + 
'                               [OTE_RUTAXML],' + char(13) + 
'                               [OTE_RUTAPDF],' + char(13) + 
'                               [OTE_IDCLIENTE],' + char(13) + 
'                               [OTE_DESGLOSE],' + char(13) + 
'                               [OTE_NUMPOLIZA],' + char(13) + 
'                               [OTE_NUMSINIESTRO]' + char(13) + 
'                               )' + char(13) + 
'                       SELECT ' + char(13) + 
'                             CAST(C.numeroCotizacion AS NVARCHAR(MAX)), -- OTE_ORDENPEMEX' + char(13) + 
'                             --CAST(CM.idCotizacion AS NVARCHAR(MAX)), -- OTE_ORDENANDRADE' + char(13) + 
'                             CAST(O.numeroOrden AS NVARCHAR(MAX)), -- OTE_ORDENGLOBAL' + char(13) + 
'                             '''+@referencia+''', -- OTE_REFERENCIA' + char(13) + 
'                             '+convert(varchar(max),@idBPRO)+',--CAST(TL.idProveedor AS NVARCHAR(MAX)), -- OTE_IDPROVEEDOR' + char(13) + 
'                             '''+@fechaFormat+''', -- OTE_FECHAORDEN' + char(13) + 
'                             '''+CAST(@numFactura AS NVARCHAR(MAX))+''', -- OTE_FACTURACOMPRA' + char(13) + 
'                             '+char(39)+'16.00'+char(39)+', -- OTE_TASAIVA' + char(13) + 
'                             CAST(CAST(SUM(CD.costo * CD.cantidad) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), -- OTE_SUBTOTAL' + char(13) + 
'                             CAST(CAST(SUM(CD.costo * CD.cantidad) * .16 AS DECIMAL(18,2))AS NVARCHAR(MAX)), -- OTE_IVA ' + char(13) + 
'                             CASE WHEN (SUM(CD.costo * CD.cantidad) + (SUM(CD.costo * CD.cantidad) * .16)) IN ('+convert(varchar(max),@montoMinimo)+', '+convert(varchar(max),@montoMaximo)+') THEN CAST('+convert(varchar(max),@totalFactura)+' AS NVARCHAR(MAX))  ELSE CAST(CAST((SUM(CD.costo * CD.cantidad) + (SUM(CD.costo * CD.cantidad) * .16)) AS DECIMAL(18,2)) AS NVARCHAR(MAX)) END, -- OTE_TOTAL' + char(13) + 
'                             '''+@UUID+''', -- OTE_UUID' + char(13) + 
'                             --@XMLFactura, --OTE_XMLCOMPRA' + char(13) + 
'                             '''+@OTE_XMLCOMPRA+''',' + char(13) + 
'                             CONVERT(VARCHAR(10),GETDATE(),103), -- OTE_FECHOPE' + char(13) + 
'                             CONVERT(VARCHAR(8),GETDATE(),108), -- OTE_HORAOPE' + char(13) + 
'                             '+convert(varchar(max),@status)+', --OTE_STATUS' + char(13) + 
'                             '+char(39)+''+char(39)+', -- OTE_FECHAPROCESO' + char(13) + 
'                             '+char(39)+''+char(39)+', -- OTE_HORAPROCESO' + char(13) + 
'                             CAST(O.numeroOrden AS NVARCHAR(MAX)), -- OTE_ORDENGLOBAL' + char(13) + 
'                             '''+@OTE_PDFCOMPRA+''',' + char(13) + 
'                             '''+@OTE_RUTAXML+''',' + char(13) + 
'                             '''+@OTE_RUTAPDF+''',' + char(13) + 
'                             '+convert(varchar(max),@OTE_IDCLIENTE)+',--@OTE_IDCLIENTE,' + char(13) + 
'                             '''+@DESGLOSE+''',' + char(13) + 
'                             '''+@OTE_NUMPOLIZA+''',' + char(13) + 
'                             '''+@OTE_NUMSINIESTRO+'''' + char(13) + 
'                       FROM Ordenes O' + char(13) + 
'                       JOIN Cotizaciones C ON C.idOrden  = O.idOrden ' + char(13) + 
'                       JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion ' + char(13) + 
'                       WHERE C.idCotizacion = '+convert(varchar(max),@idCotizacion)+' ' + char(13) + 
'                       AND CD.idEstatusPartida IN(2)' + char(13) + 
'                       AND C.idEstatusCotizacion IN(3)' + char(13) + 
'                       GROUP BY C.numeroCotizacion, O.numeroOrden' + char(13) + '' 

						exec(@insertQuery) 
                        -----------------------------						
                        IF(@numeroTrabajo <> '' and @idContratoOperacion in (1,2,3,4,5,6))
                        BEGIN							
                            declare @qTemp varchar(max) = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@db+'.[dbo].[ADE_COPADE] WHERE COP_ORDENGLOBAL = '''+@numeroTrabajo+''') THEN 1 ELSE 0 END' + char(13) + 
                                                          '' 
                            
                            declare @tTemp table (val int)
                            insert into @tTemp exec(@qTemp) 
                            declare @val int = (SELECT top 1 val from @tTemp)
                            
                            IF (@val = 0)
                            BEGIN
                                declare @queryT varchar(max) = 'INSERT INTO '+@db+'.[dbo].[ADE_COPADE] VALUES('+char(39)+@numeroTrabajo+char(39)+', '+char(39)+''+char(39)+', '+char(39)+'GMI'+char(39)+', CONVERT(VARCHAR(10),GETDATE(),103), CONVERT(VARCHAR(8),GETDATE(),108), NULL, 0, NULL, NULL, NULL)' + char(13) + 
                                                               '' 
                                
                                exec(@queryT) 
                                
                            END
                                
                        END
                            
                        -----------------------------                        
                        declare @qT varchar(max) = 'SELECT ISNULL(MAX(OTE_IDENT),1) FROM '+@db+'.[dbo].[ADE_ORDSERENC]' + char(13) + 
                                                   '' 
                        declare @tT table (val int)

                        insert into @tT
                        exec(@qT) 
                        SELECT @IdEncabezado = (select top 1 val from @tT)
            END
            ELSE IF(@tipoDetalle=2) --refacciones
                 BEGIN
                  select 1
                END 	        
			select @IdEncabezado as encabezado
            EXEC Banorte.INS_ORDEN_DETALLE_REFACCIONES_SP @idCotizacion, @IdEncabezado, @tipoDetalle, @idOperacion, @isProduction
        END 
END
go

grant execute, view definition on Banorte.INS_ORDEN_ENCABEZADO_REFACCIONES_SP to DevOps
go

