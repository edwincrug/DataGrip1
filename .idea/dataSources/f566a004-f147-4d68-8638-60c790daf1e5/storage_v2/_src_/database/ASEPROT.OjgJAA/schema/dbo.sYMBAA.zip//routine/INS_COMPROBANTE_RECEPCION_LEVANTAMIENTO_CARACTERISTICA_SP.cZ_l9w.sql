-- [INS_COMPROBANTE_RECEPCION_LEVANTAMIENTO_DETALLE_SP] 
create PROCEDURE [dbo].[INS_COMPROBANTE_RECEPCION_LEVANTAMIENTO_CARACTERISTICA_SP]
@idOrdenModuloLevantamientoDetalle INT,
@idCatalogoModuloLevantamientoCaracteristica INT,
@dato VARCHAR(1000)
AS
BEGIN
		DECLARE @idOrdenModuloLevantantamientoCaracteristica INT
		
		INSERT INTO OrdenModuloLevantamientoCaracteristica 
		VALUES(@idOrdenModuloLevantamientoDetalle, @idCatalogoModuloLevantamientoCaracteristica, @dato)
		
		SET @idOrdenModuloLevantantamientoCaracteristica = @@IDENTITY
		
		SELECT @idOrdenModuloLevantantamientoCaracteristica AS idOrdenModuloLevantantamientoCaracteristica, 'Se agrego la caracteristica del modulo'AS msg,1 AS estatus
END
go

