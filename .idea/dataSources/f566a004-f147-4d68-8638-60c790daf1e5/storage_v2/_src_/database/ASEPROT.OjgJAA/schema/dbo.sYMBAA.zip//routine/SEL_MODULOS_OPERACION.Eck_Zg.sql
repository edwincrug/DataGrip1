-- =============================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 02/06/2017 
--[SEL_MODULOS_OPERACION] 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_MODULOS_OPERACION] 
	@idOperacion int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT       Modu.idModulo
				,Modu.idCatalogoModulo
				,CatMod.nombreModulos AS nombreModulo
				,CatMod.tipoModulo
	FROM        dbo.Modulos AS Modu inner join
				dbo.CatalogoModulos AS CatMod ON Modu.idCatalogoModulo = CatMod.idCatalogoModulos			
	WHERE        (idOperacion = @idOperacion)

END
go

