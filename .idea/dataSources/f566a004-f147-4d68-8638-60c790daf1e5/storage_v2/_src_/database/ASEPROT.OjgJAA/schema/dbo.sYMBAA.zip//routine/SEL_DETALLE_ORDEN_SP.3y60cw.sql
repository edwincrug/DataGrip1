-- =============================================
-- Description:	Busca detalle de la orden 
-- [SEL_DETALLE_ORDEN_SP]@numeroOrden='03-1632012972999-000017'
-- =============================================
/****** Script for SelectTopNRows command from SSMS  ******/
--[dbo].[SEL_DETALLE_ORDEN_SP] @idUsuario = 2, @numeroOrden = '01-510052-115'
--[dbo].[SEL_DETALLE_ORDEN_SP] 133, '933462554'
--[dbo].[SEL_DETALLE_ORDEN_SP_1] 676,'26-11136-4'
CREATE PROCEDURE [dbo].[SEL_DETALLE_ORDEN_SP]
@idUsuario INT = 0,
@numeroOrden varchar(50)
AS
BEGIN
	
	DECLARE @cotizaciones TABLE (ID INT IDENTITY(1,1), idCotizacion INT)

	INSERT INTO @cotizaciones
	SELECT	idCotizacion
	FROM	[dbo].[Ordenes] ORD
			INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden
	WHERE	ORD.numeroOrden = @numeroOrden AND NOT COTI.idEstatusCotizacion = 4

	--SELECT * FROM @cotizaciones
	DECLARE @contador INT = 1, @numeroOrdenes INT = 0, @sumaCosto NUMERIC(18,2)=0, @sumaVenta NUMERIC(18,2)=0, @idCotizacion INT = 0
	SET @numeroOrdenes = (SELECT	COUNT(idCotizacion)
							FROM	[dbo].[Ordenes] ORD
									INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden
							WHERE	ORD.numeroOrden = @numeroOrden AND NOT	COTI.idEstatusCotizacion = 4)
	WHILE(@contador <= @numeroOrdenes)
		BEGIN
			SELECT @idCotizacion = idCotizacion FROM @cotizaciones WHERE ID = @contador 
			SET @sumaCosto = (SELECT SUM(costo * cantidad ) FROM [dbo].[CotizacionDetalle] WHERE idCotizacion = @idCotizacion AND NOT idEstatusPartida IN (3,4)) + @sumaCosto
			SET @sumaVenta = (SELECT SUM(venta * cantidad ) FROM [dbo].[CotizacionDetalle] WHERE idCotizacion = @idCotizacion AND NOT idEstatusPartida IN (3,4)) + @sumaVenta
			print @sumaCosto
			print @sumaVenta
			SET @contador = @contador + 1
		END

		--para GPS Alcabelu 20171031
		  declare @Vin Nvarchar(50)
		  --declare @lat Nvarchar(50) = '19.3295518'
	      --declare @long Nvarchar(50) = '-99.2065204'
	      declare @lat Nvarchar(50) = '0'
	      declare @long Nvarchar(50) = '0'
		  DECLARE @kilometraje NVARCHAR(100) = '0'
		  --print @numeroOrden
		  DECLARE @timeGPS DATETIME
		  SET @timeGPS = GETDATE()
		  declare @idOperacion INT
		  --print @numeroOrden

		   select @vin = vin,
				  @idOperacion = U.idOperacion
	            from dbo.Ordenes O
	      inner join Unidades U
	              on O.idUnidad = U.idUnidad
	           where O.numeroOrden = @numeroOrden

			 --  Select 'vin'   
		--			  ,@vin

	IF(@idOperacion = 8 or @idOperacion = 18 )
		BEGIN
				SELECT 
					TOP 1
						@lat = lat, 
						@long = long,
						@timeGPS=fecha_loc
					FROM [Casanova].[dbo].[Localizacion] l
			 JOIN [Casanova].[dbo].[Unidad] U
					on L.idunidad = U.[idUnidad]
				where U.[vin] = @vin
				order by [fecha_loc] desc
		END
	ELSE
		BEGIN
			SELECT @long = tpl.lo ,
				   @lat = tpl.la, 
				   @kilometraje=tpl.mileage,
				   @timeGPS=tpl.gpsTime
			FROM 
				[192.168.20.110].[GPS].[cxc].[UnidadGPSSIM] ugs
				inner join [192.168.20.110].[GPS].[inventario].GPSSIM gs on ugs.idGPSSIM = gs.idGPSSIM
				inner join [192.168.20.110].[GPS].[inventario].GPS g on gs.idGPS = g.idGPS 
				inner join [192.168.20.110].[8833test].[dbo].[tCar] tc on g.deviceID = tc.carNO
				inner join [192.168.20.110].[8833test].[dbo].tPosition_last tpl on tc.carID = tpl.carID
			WHERE ugs.vin = @vin
			order by ugs.idUnidadGPSSIM desc

			SET @kilometraje = REPLACE(CONVERT(VARCHAR,CONVERT(Money, ISNULL(@kilometraje,0)),1),'.00','')
		
		END


	SELECT 
		   Orden.idOrden
		  ,Orden.numeroOrden
		  ,Orden.comentarioOrden
		  ,Uni.numeroEconomico
		  ,Uni.placas
		  ,Uni.vin
		  ,Uni.gps
		  ,Uni.verGPS
		  ,Uni.idUnidad
			,Uni.modelo
			,Uni.fecha as fechaModificacion
		  , Est.idEstatusOrden
		  ,CASE WHEN Orden.idGarantia = 1 AND Est.[idEstatusOrden] = 5 THEN 'En Proceso - Garantia' ELSE Est.[nombreEstatusOrden] END AS nombreEstatusOrden
		  ,(SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END FROM HistorialEstatusOrden WHERE idOrden = Orden.idOrden AND idEstatusOrden = 6 AND idUsuario = 514)migracion
		  --, Est.nombreEstatusOrden
		  ,Orden.idTaller
		  ,taller.nombreComercial
		  ,@sumaCosto AS CostoTotal
		  ,@sumaVenta AS VentaTotal
		  ,('Orden de ' + catTipOrd.nombreTipoOrdenServicio) as nombreTipoOrden
		  --,(SELECT [dbo].[SEL_ACCIONES_FN] (Orden.idOrden)) accion
		  ,isnull(A.texto, 'Sin Plan de Acción') accion
		  ,isnull(DATEADD(HH,5,A.fecha), '') fechaAccion
		  ,case when A.texto is null then 0 else 1 end hasAccion
		  ,(SELECT [dbo].[GET_ZONAS_ORDEN_FN](Orden.idZona)) AS productoZonas
			--Datos de la unidad
			--,UNIP.idUnidad,
			--,TU.idTipoUnidad,
			,TU.tipo as tipoUnidad,
			tco.tipoCombustible,
			tco.idTipoCombustible,
			cil.cilindros,
			cil.idCilindros,
			SM.nombre as subMarca,
			SM.idSubMarca,
			MA.nombre as marca,
			UNIP.foto as foto
			--Unidad
			
		  ,Z.nombre as nombreZona
		  ,orden.[motivoGarantia]
		  ,Orden.idGarantia
		  ,CT.nombreCentroTrabajo		  
		  ,Orden.idZona --LQMA add 11072017 
		  ,Uni.idTipoUnidad
		  ,Uni.verificada
			,Uni.idUnidad
			--, '0, hola' as estatusToken
			,dbo.cadenaToken(@numeroOrden) as estatusToken
			,@kilometraje AS [kilometraje]
			,@lat AS [Latitud]
			,@long AS [Longitud]
			,@timeGPS AS [fechaLocalizacion]
			,isnull(E.claveEmpleado,'') as numEmpleado
			,catTipOrd.idCatalogoTipoOrdenServicio as idTipoOrdenServ
			--REXE
			,ISNULL(UR.Estatus, 0) as UnidadRestriccion
			--REXE
	  FROM [dbo].[Ordenes] Orden
			INNER JOIN [dbo].[CatalogoTiposOrdenServicio] catTipOrd ON catTipOrd.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio
			INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad
			INNER JOIN [dbo].[EstatusOrdenes] Est ON Orden.idEstatusOrden = Est.idEstatusOrden
			LEFT JOIN [dbo].Acciones A ON A.idOrden = Orden.idOrden and A.idEstatusOrden = Orden.idEstatusOrden
			LEFT JOIN [dbo].[CentroTrabajos] CT ON CT.idCentroTrabajo = Orden.idCentroTrabajo
			LEFT JOIN [Partidas].[dbo].[Proveedor] taller ON taller.idProveedor = Orden.idTaller
			INNER JOIN [dbo].[ContratoOperacion] CP ON Uni.idOperacion = CP.idOperacion
			INNER JOIN .[Partidas].[dbo].[ContratoUnidad] CU ON CU.idContrato = CP.idContrato AND CU.idUnidad = Uni.idTipoUnidad
			INNER JOIN .[Partidas].[dbo].[Unidad] UNIP ON UNIP.idUnidad = CU.idUnidad
			LEFT JOIN .[Partidas].dbo.SubMarca SM ON UNIP.idSubMarca = SM.idSubMarca 
			INNER JOIN .[Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca
			INNER JOIN .[Partidas].[dbo].[TipoUnidad] TU ON TU.idTipoUnidad = UNIP.idTipoUnidad
			LEFT JOIN .[Partidas].dbo.TipoCombustible tco ON tco.idTipoCombustible = UNIP.idTipoCombustible
			LEFT JOIN .[Partidas].dbo.Cilindros cil ON cil.idCilindros = UNIP.idCilindros
			LEFT JOIN [Partidas].[dbo].[Zona] Z ON Z.idZona = Orden.idZona
			LEFT JOIN [dbo].[OrdenEmpleado] OE ON OE.idOrden = Orden.idOrden
			LEFT JOIN [dbo].[Empleados] E on E.idEmpleado = OE.idEmpleado
			--REXE
			LEFT JOIN dbo.UnidadRestriccion UR ON UR.idUnidad = UNI.idUnidad AND UR.idOperacion = UNI.idOperacion
			--REXE
	WHERE Orden.numeroOrden = @numeroOrden




END

go

