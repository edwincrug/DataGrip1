/* -------------------------------------
-- [SEL_REPORTE_UNIDAD_OPERATIVOS_SP] 1, null, null, null, null, null
 ------------------------------------- */
CREATE PROCEDURE [dbo].[SEL_REPORTE_UNIDAD_OPERATIVOS_SP] 
	@idContratoOperacion INT = 1,
	@idZona INT = NULL,
	@idCatalogoTipoOrdenServicio INT = NULL,
	@idCatalogoEstadoUnidad INT = NULL,
	@idServicio INT = NULL,
	@fechaInicial varchar(25) = NULL,
	@fechaFinal varchar(25) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @idOperacion INT=(SELECT idOperacion FROM ContratoOperacion WHERE idContratoOperacion=@idContratoOperacion)

	SELECT 	
		U.idUnidad,	
		'Economico: '+ U.numeroEconomico+', '+
		'VIN: '+U.vin+', '+
		'Placas: '+U.placas+', '+
		'Modelo: '+U.modelo+', '+
		'Combustible: '+TC.tipoCombustible as datosUnidad,
		(SELECT SUM(isnull(horas,0)) AS horas FROM(
		  SELECT SUM(DATEDIFF(DAY, fechaEntrada, fechaEntrega)) AS horas FROM(
				SELECT 
					(SELECT TOP 1  ISNULL(fechaInicial, GETDATE()) FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3) AS fechaEntrada, 
					(SELECT TOP 1  ISNULL(fechaInicial, GETDATE()) FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 7) AS fechaEntrega
				FROM Ordenes O
			WHERE idUnidad=U.idUnidad)Ordenes
			UNION 
			SELECT SUM(DATEDIFF(DAY, fechaEntrada, fechaEntrega)) AS horas FROM(
				SELECT 
					(ISNULL(US.fecha, GETDATE())) AS fechaEntrada, 
					(ISNULL(US.fechaSalida, GETDATE())) AS fechaEntrega
				FROM [Sustituto].[UnidadSustituto] US
			WHERE idUnidad=U.idUnidad)Sustituto
		)horas)diasfueraoperacion,

		(SELECT SUM(isnull(horas,0)) AS horas FROM(
		  SELECT SUM(DATEDIFF(hour, fechaEntrada, fechaEntrega)) AS horas FROM(
				SELECT 
					(SELECT TOP 1  ISNULL(fechaInicial, GETDATE()) FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3) AS fechaEntrada, 
					(SELECT TOP 1  ISNULL(fechaInicial, GETDATE()) FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 7) AS fechaEntrega
				FROM Ordenes O
			WHERE idUnidad=U.idUnidad)Ordenes
			UNION 
			SELECT SUM(DATEDIFF(hour, fechaEntrada, fechaEntrega)) AS horas FROM(
				SELECT 
					(ISNULL(US.fecha, GETDATE())) AS fechaEntrada, 
					(ISNULL(US.fechaSalida, GETDATE())) AS fechaEntrega
				FROM [Sustituto].[UnidadSustituto] US
			WHERE idUnidad=U.idUnidad)Sustituto
		)horas)horasfueraoperacion
		/*(SELECT SUM(DATEDIFF(DAY, fechaEntrada, fechaEntrega)) AS horas FROM(
			SELECT 
				(SELECT TOP 1  ISNULL(fechaInicial, GETDATE()) FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3) AS fechaEntrada, 
				(SELECT TOP 1  ISNULL(fechaInicial, GETDATE()) FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 6) AS fechaEntrega
		FROM Ordenes O WHERE idUnidad=U.idUnidad)x) as dias*/
		--U.idOperacion,
		--U.idCentroTrabajo,
		--U.verificada,
		--TU.tipo,
		--TC.tipoCombustible,
		--SM.nombre subMarca,
		--M.nombre Marca,
		--Z.nombre
	FROM Unidades U 
		JOIN Ordenes O ON O.idUnidad = U.idUnidad
		LEFT JOIN [Sustituto].UnidadSustituto USO ON USO.idUnidad = U.idUnidad
		JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
		JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
		JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
		JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
		JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
		--JOIN Partidas..Zona Z ON Z.idZona = U.idZona
	WHERE U.idOperacion = @idOperacion AND
	O.idEstatusOrden NOT IN(13) AND
	O.idCatalogoTipoOrdenServicio = COALESCE(@idCatalogoTipoOrdenServicio, O.idCatalogoTipoOrdenServicio) AND
	O.idCatalogoEstadoUnidad = COALESCE(@idCatalogoEstadoUnidad, O.idCatalogoEstadoUnidad) AND
	O.idZona = COALESCE(@idZona,U.idZona) AND
	O.fechaCreacionOden BETWEEN COALESCE(@fechaInicial,O.fechaCreacionOden) AND COALESCE (@fechaFinal,O.fechaCreacionOden)
	GROUP BY U.idUnidad, U.numeroEconomico, U.vin, U.placas, U.modelo, TC.tipoCombustible
	ORDER BY U.numeroEconomico DESC

	/*
		select * from [Sustituto].[UnidadSustituto]
		select * from [Sustituto].[MotivoSustituto]
		select * from Usuarios
		SELECT * FROM UNIDADES
		select * from Partidas..unidad
		select * from Partidas..SubMarca
	*/
END
go

