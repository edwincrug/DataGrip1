
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 31/05/2017
-- Description:	Devuelve los resultados del cuadrante de Ordenes de Servicio en el Dashboard
-- [SEL_DASHBOARD_ORDENES_SERVICIO_SP] 3, 0
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_DASHBOARD_ORDENES_SERVICIO_SP]
    @idOperacion NUMERIC(20,0),
    @idZona NUMERIC( 20,0 ),
	@idUsuario NUMERIC(18,0) = NULL
AS
	BEGIN
		DECLARE @tmp_cotizacion TABLE (id char(1), estatus char(55), total char(15), promedio char(15), color char(7), Monto char(15), MontoCosto char(15))
		-- DECLARE @idOperacion NUMERIC(38,0)
		-- DECLARE @idContratoOperacion NUMERIC(5,0);

		-- Variables para Totales
		DECLARE @Proceso NUMERIC(18,00);
		DECLARE @Termino NUMERIC(18,00);
		DECLARE @Entrega  NUMERIC(18,00);

		-- Variables para Promedios
		DECLARE @Prom_Proceso NUMERIC(10,0);
		DECLARE @Prom_Termino NUMERIC(10,0);
		DECLARE @Prom_Entrega  NUMERIC(10,0);
		
		-- Variables para Montos
		DECLARE @Mon_Proceso NUMERIC(10,0);
		DECLARE @Mon_Termino NUMERIC(10,0);
		DECLARE @Mon_Entrega  NUMERIC(10,0);
		
		-- Variables para Montos Costo
		DECLARE @Cos_Proceso NUMERIC(10,0);
		DECLARE @Cos_Termino NUMERIC(10,0);
		DECLARE @Cos_Entrega  NUMERIC(10,0);

		-- SET @idOperacion = 2;
		
		declare @idCOU numeric(18,0) = [dbo].[GET_CONTRATO_OPERACION_USR_FN](@idUsuario,@idOperacion)

		declare @zonasAsignadas table (idZona int)
		insert into @zonasAsignadas 
		select idZona from [dbo].[GET_ZONAS_USR_FN](@idCOU)

		declare @tablaProveedoresAsignados table(idProveedor int)
		insert into @tablaProveedoresAsignados
		select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)
	
		IF( @idZona = 0 )
			BEGIN
				set @idZona = null
			END

				IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 2
					BEGIN
							IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 4
							BEGIN
									------------------------cliente INI------------------------
							
									SET @Termino = ( SELECT COUNT(idOrden) FROM Ordenes ORD INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion WHERE idEstatusOrden = 6 AND idOperacion = @idOperacion AND Ord.idZona = COALESCE(@idZona, idZona) AND ORD.idZona in (select idZona from @zonasAsignadas));
									SET @Entrega = ( SELECT COUNT(idOrden) FROM Ordenes ORD INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion WHERE idEstatusOrden = 7 AND idOperacion = @idOperacion AND Ord.idZona = COALESCE(@idZona, idZona) AND ORD.idZona in (select idZona from @zonasAsignadas));
										
										
									SET @Prom_Termino = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
															FROM Ordenes ORD
															INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
															INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
															WHERE ORD.idEstatusOrden = 6 AND idOperacion = @idOperacion 
															AND Ord.idZona = COALESCE(@idZona, idZona) 
															AND ORD.idZona in (select idZona from @zonasAsignadas));
										
									SET @Prom_Entrega = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
															FROM Ordenes ORD
															INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
															INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
															WHERE ORD.idEstatusOrden = 7 AND idOperacion = @idOperacion 
															AND Ord.idZona = COALESCE(@idZona, idZona) 
															AND ORD.idZona in (select idZona from @zonasAsignadas));	
									
									SET @Mon_Termino = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
																FROM [dbo].[Cotizaciones] C 
																INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
																INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
																INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
															WHERE C.idEstatusCotizacion IN (3)
															AND CD.idEstatusPartida IN (2)
															AND CO.idOperacion = @idOperacion
															AND O.idEstatusOrden IN (6) 
															AND O.idZona = COALESCE(@idZona, idZona)
															AND O.idZona in (select idZona from @zonasAsignadas));
				
									SET @Mon_Entrega = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
																FROM [dbo].[Cotizaciones] C 
																INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
																INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
																INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
															WHERE C.idEstatusCotizacion IN (3)
															AND CD.idEstatusPartida IN (2)
															AND CO.idOperacion = @idOperacion
															AND O.idZona = COALESCE(@idZona, idZona)
															AND O.idEstatusOrden IN (7) AND O.idZona in (select idZona from @zonasAsignadas));
										
				
									SET @Cos_Termino = ( SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
																FROM [dbo].[Cotizaciones] C 
																INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
																INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
																INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
															WHERE	C.idEstatusCotizacion IN (3)
															AND CD.idEstatusPartida IN (2)
															AND CO.idOperacion = @idOperacion
															AND O.idZona = COALESCE(@idZona, idZona)
															AND O.idEstatusOrden IN (6) AND O.idZona in (select idZona from @zonasAsignadas));
				
									SET @Cos_Entrega = (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
																FROM [dbo].[Cotizaciones] C 
																INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
																INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
																INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
															WHERE	C.idEstatusCotizacion IN (3)
															AND CD.idEstatusPartida IN (2)
															AND CO.idOperacion = @idOperacion
															AND O.idZona = COALESCE(@idZona, idZona)
															AND O.idEstatusOrden IN (7) AND O.idZona in (select idZona from @zonasAsignadas));
										
				
									------------------------cliente END------------------------
							END
							ELSE
							BEGIN
									------------------------proveedor INI------------------------
							
									SET @Termino = ( SELECT COUNT(idOrden) 
														FROM Ordenes ORD INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion 
														WHERE idEstatusOrden = 6 AND idOperacion = @idOperacion 
														and ORD.idZona = COALESCE(@idZona, idZona)
														and (SELECT CASE WHEN exists (select 1 from Cotizaciones C where C.idOrden = ORD.idOrden and C.idEstatusCotizacion in (3) and C.idTaller in (select idProveedor from @tablaProveedoresAsignados)) THEN 'true'
																							  ELSE 'false'
																						   END ) = 'true');

									SET @Entrega = ( SELECT COUNT(idOrden) 
														FROM Ordenes ORD INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion 
														WHERE idEstatusOrden = 7 AND idOperacion = @idOperacion
														and ORD.idZona = COALESCE(@idZona, idZona) 
														and (SELECT CASE WHEN exists (select 1 from Cotizaciones C where C.idOrden = ORD.idOrden and C.idEstatusCotizacion in (3) and C.idTaller in (select idProveedor from @tablaProveedoresAsignados)) THEN 'true'
																							  ELSE 'false'
																						   END ) = 'true');
																			
									SET @Prom_Termino = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
															FROM Ordenes ORD
															INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
															INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
															WHERE ORD.idEstatusOrden = 6 AND idOperacion = @idOperacion 
															and ORD.idZona = COALESCE(@idZona, idZona)
															and (SELECT CASE WHEN exists (select 1 from Cotizaciones C where C.idOrden = ORD.idOrden and C.idEstatusCotizacion in (3)  and C.idTaller in (select idProveedor from @tablaProveedoresAsignados)) THEN 'true'
																							  ELSE 'false'
																						   END ) = 'true');
										
									SET @Prom_Entrega = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
															FROM Ordenes ORD
															INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
															INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
															WHERE ORD.idEstatusOrden = 7 AND idOperacion = @idOperacion 
															and ORD.idZona = COALESCE(@idZona, idZona)
															and (SELECT CASE WHEN exists (select 1 from Cotizaciones C where C.idOrden = ORD.idOrden and C.idEstatusCotizacion in (3) and C.idTaller in (select idProveedor from @tablaProveedoresAsignados)) THEN 'true'
																							  ELSE 'false'
																						   END ) = 'true');
									
									SET @Mon_Termino = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
																FROM [dbo].[Cotizaciones] C 
																INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
																INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
																INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
															WHERE C.idEstatusCotizacion IN (3)
															AND CD.idEstatusPartida IN (2)
															AND CO.idOperacion = @idOperacion
															AND O.idEstatusOrden IN (6) 
															AND O.idZona = COALESCE(@idZona, idZona)
															AND C.idTaller in (select idProveedor from @tablaProveedoresAsignados));
				
									SET @Mon_Entrega = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
																FROM [dbo].[Cotizaciones] C 
																INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
																INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
																INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
															WHERE C.idEstatusCotizacion IN (3)
															AND CD.idEstatusPartida IN (2)
															AND CO.idOperacion = @idOperacion
															AND O.idEstatusOrden IN (7) 
															AND O.idZona = COALESCE(@idZona, idZona)
															AND C.idTaller in (select idProveedor from @tablaProveedoresAsignados));
										
				
									SET @Cos_Termino = ( SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
																FROM [dbo].[Cotizaciones] C 
																INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
																INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
																INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
															WHERE	C.idEstatusCotizacion IN (3)
															AND CD.idEstatusPartida IN (2)
															AND CO.idOperacion = @idOperacion
															AND O.idEstatusOrden IN (6) 
															AND O.idZona = COALESCE(@idZona, idZona)
															AND C.idTaller in (select idProveedor from @tablaProveedoresAsignados));
				
									SET @Cos_Entrega = (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
																FROM [dbo].[Cotizaciones] C 
																INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
																INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
																INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
															WHERE	C.idEstatusCotizacion IN (3)
															AND CD.idEstatusPartida IN (2)
															AND CO.idOperacion = @idOperacion
															AND O.idEstatusOrden IN (7) 
															AND O.idZona = COALESCE(@idZona, idZona)
															AND C.idTaller in (select idProveedor from @tablaProveedoresAsignados));
										
				
									------------------------proveedor END------------------------
							END
					END
				ELSE
					BEGIN
							------------------------admin INI------------------------------
					
							SET @Termino = ( SELECT COUNT(idOrden) FROM Ordenes ORD 
												INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion 
												WHERE idEstatusOrden = 6 AND idOperacion = @idOperacion 
												AND ORD.idZona = COALESCE(@idZona, idZona));

							SET @Entrega = ( SELECT COUNT(idOrden) FROM Ordenes ORD 
												INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion 
												WHERE idEstatusOrden = 7 AND idOperacion = @idOperacion 
												AND ORD.idZona = COALESCE(@idZona, idZona));

	
										
							SET @Prom_Termino = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
													FROM Ordenes ORD
													INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
													INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
													WHERE ORD.idEstatusOrden = 6 AND idOperacion = @idOperacion
													AND ORD.idZona = COALESCE(@idZona, idZona));
										
							SET @Prom_Entrega = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
													FROM Ordenes ORD
													INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
													INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
													WHERE ORD.idEstatusOrden = 7 AND idOperacion = @idOperacion
													AND ORD.idZona = COALESCE(@idZona, idZona));	
									
							SET @Mon_Termino = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
														FROM [dbo].[Cotizaciones] C 
														INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
														INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
														INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
													WHERE C.idEstatusCotizacion IN (3)
													AND CD.idEstatusPartida IN (2)
													AND CO.idOperacion = @idOperacion
													AND O.idEstatusOrden IN (6)
													AND O.idZona = COALESCE(@idZona, idZona));
				
							SET @Mon_Entrega = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
														FROM [dbo].[Cotizaciones] C 
														INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
														INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
														INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
													WHERE C.idEstatusCotizacion IN (3)
													AND CD.idEstatusPartida IN (2)
													AND CO.idOperacion = @idOperacion
													AND O.idEstatusOrden IN (7)
													AND O.idZona = COALESCE(@idZona, idZona));
										
				
							SET @Cos_Termino = ( SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
														FROM [dbo].[Cotizaciones] C 
														INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
														INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
														INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
													WHERE	C.idEstatusCotizacion IN (3)
													AND CD.idEstatusPartida IN (2)
													AND CO.idOperacion = @idOperacion
													AND O.idEstatusOrden IN (6)
													AND O.idZona = COALESCE(@idZona, idZona));
				
							SET @Cos_Entrega = (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
														FROM [dbo].[Cotizaciones] C 
														INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
														INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
														INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
													WHERE	C.idEstatusCotizacion IN (3)
													AND CD.idEstatusPartida IN (2)
													AND CO.idOperacion = @idOperacion
													AND O.idEstatusOrden IN (7)
													AND O.idZona = COALESCE(@idZona, idZona));
										
				
							------------------------admin END------------------------------
					END

				
		--	END
		--ELSE
		--	BEGIN
		--		-- Se obtienen los totales de las citas
		--		-- SET @Proceso = ( SELECT COUNT(idOrden) FROM Ordenes ORD INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion WHERE idEstatusOrden = 5 AND idOperacion = @idOperacion AND idZona = @idZona );
		--		SET @Termino = ( SELECT COUNT(idOrden) FROM Ordenes ORD INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion WHERE idEstatusOrden = 6 AND idOperacion = @idOperacion AND idZona = @idZona );
		--		SET @Entrega  = ( SELECT COUNT(idOrden) FROM Ordenes ORD INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion WHERE idEstatusOrden = 7 AND idOperacion = @idOperacion AND idZona = @idZona );

		--		-- Se obtienen los promedios decada estatus
		--		/*SET @Prom_Proceso = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
		--								FROM Ordenes ORD
		--								INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
		--								INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
		--								WHERE ORD.idEstatusOrden = 5 AND idOperacion = @idOperacion AND idZona = @idZona);*/
										
		--		SET @Prom_Termino = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
		--								FROM Ordenes ORD
		--								INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
		--								INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
		--								WHERE ORD.idEstatusOrden = 6 AND idOperacion = @idOperacion AND idZona = @idZona);
										
		--		SET @Prom_Entrega = ( SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
		--								FROM Ordenes ORD
		--								INNER JOIN ContratoOperacion     COP ON ORD.idContratoOperacion = COP.idContratoOperacion
		--								INNER JOIN HistorialEstatusOrden HEO ON ORD.idOrden = HEO.idOrden AND ORD.idEstatusOrden = HEO.idEstatusOrden
		--								WHERE ORD.idEstatusOrden = 7 AND idOperacion = @idOperacion AND idZona = @idZona);
				
		--		-- Se obtienen los Montos totales de las citas
		--		/*SET @Mon_Proceso = ( SELECT SUM((cantidad * COPA.venta)) Monto
		--								FROM Ordenes ORD
		--								INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
		--								LEFT JOIN Cotizaciones COTI ON ORD.idOrden = COTI.idOrden
		--								LEFT JOIN CotizacionDetalle CODE ON CODE.idCotizacion = COTI.idCotizacion
		--								LEFT JOIN [Partidas].[dbo].[ContratoPartida] COPA ON CODE.idPartida = COPA.idPartida
		--								WHERE idEstatusOrden = 5 AND idOperacion = @idOperacion );*/
				
		--		SET @Mon_Termino = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
		--									FROM [dbo].[Cotizaciones] C 
		--									INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
		--									INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
		--									INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		--								WHERE C.idEstatusCotizacion IN (3)
		--								AND CD.idEstatusPartida IN (2)
		--								AND CO.idContratoOperacion = @idOperacion
		--								AND O.idZona = @idZona
		--								AND O.idEstatusOrden IN (6));
				
		--		SET @Mon_Entrega = (SELECT  ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
		--									FROM [dbo].[Cotizaciones] C 
		--									INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
		--									INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
		--									INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		--								WHERE C.idEstatusCotizacion IN (3)
		--								AND CD.idEstatusPartida IN (2)
		--								AND CO.idContratoOperacion = @idOperacion
		--								AND O.idZona = @idZona
		--								AND O.idEstatusOrden IN (7));
										
		--		-- Se obtienen los Montos Costo totales de las citas
		--		/*SET @Cos_Proceso = ( SELECT SUM((cantidad * PRPA.costo)) Monto
		--								FROM Ordenes ORD
		--								INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
		--								LEFT JOIN Cotizaciones COTI ON ORD.idOrden = COTI.idOrden
		--								LEFT JOIN CotizacionDetalle CODE ON CODE.idCotizacion = COTI.idCotizacion
		--								LEFT JOIN [Partidas].[dbo].[ProveedorPartida] PRPA ON CODE.idPartida = PRPA.idPartida
		--								WHERE idEstatusOrden = 5 AND idOperacion = @idOperacion );*/
				
		--		SET @Cos_Termino = ( SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
		--									FROM [dbo].[Cotizaciones] C 
		--									INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
		--									INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
		--									INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		--								WHERE	C.idEstatusCotizacion IN (3)
		--								AND CD.idEstatusPartida IN (2)
		--								AND CO.idContratoOperacion = @idOperacion
		--								AND O.idZona = @idZona
		--								AND O.idEstatusOrden IN (6));
				
		--		SET @Cos_Entrega = (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
		--									FROM [dbo].[Cotizaciones] C 
		--									INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
		--									INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
		--									INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		--								WHERE	C.idEstatusCotizacion IN (3)
		--								AND CD.idEstatusPartida IN (2)
		--								AND CO.idContratoOperacion = @idOperacion
		--								AND O.idZona = @idZona
		--								AND O.idEstatusOrden IN (7));
		--	END

		-- Se valida si un promedio es NULL se cambia por un 0
		IF( @Prom_Proceso IS NULL )
			BEGIN
				SET @Prom_Proceso = 0;
			END

		IF( @Prom_Termino IS NULL )
			BEGIN
				SET @Prom_Termino = 0;
			END

		IF( @Prom_Entrega IS NULL )
			BEGIN
				SET @Prom_Entrega = 0;
			END
		
		
		-- Se valida si un Monto es NULL se cambia por un 0
		IF( @Mon_Proceso IS NULL )
			BEGIN
				SET @Mon_Proceso = 0;
			END

		IF( @Mon_Termino IS NULL )
			BEGIN
				SET @Mon_Termino = 0;
			END

		IF( @Mon_Entrega IS NULL )
			BEGIN
				SET @Mon_Entrega = 0;
			END
			
		-- Se valida si un Monto es NULL se cambia por un 0
		IF( @Cos_Proceso IS NULL )
			BEGIN
				SET @Cos_Proceso = 0;
			END

		IF( @Cos_Termino IS NULL )
			BEGIN
				SET @Cos_Termino = 0;
			END

		IF( @Mon_Entrega IS NULL )
			BEGIN
				SET @Cos_Entrega = 0;
			END

		-- Se llena la tabla temporal
		--INSERT INTO @tmp_cotizacion VALUES( 5, 'En proceso', @Proceso, @Prom_Proceso, '#ffe033', @Mon_Proceso, @Cos_Proceso );
		INSERT INTO @tmp_cotizacion VALUES( 6, 'Término Trabajo', @Termino, @Prom_Termino, '#ffa600', @Mon_Termino, @Cos_Termino );
		INSERT INTO @tmp_cotizacion VALUES( 7, 'Entrega', @Entrega, @Prom_Entrega, '#d66a27', @Mon_Entrega, @Cos_Entrega );

		-- Se regresan los valores
		SELECT * FROM @tmp_cotizacion;

	END
go

