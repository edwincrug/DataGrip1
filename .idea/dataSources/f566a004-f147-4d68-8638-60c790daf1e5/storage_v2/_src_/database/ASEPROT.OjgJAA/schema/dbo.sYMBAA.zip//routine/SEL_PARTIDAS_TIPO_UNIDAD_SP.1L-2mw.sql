
-- SEL_PARTIDAS_TIPO_UNIDAD_SP  @idContratoOperacion=1, @idTipoUnidad = 7, @idTipoCita = 1

CREATE PROCEDURE [dbo].[SEL_PARTIDAS_TIPO_UNIDAD_SP]

	@idTipoUnidad INT = 0,
	@idContratoOperacion NUMERIC(18,0) = 1,
	@idTipoCita INT = NULL

AS

		IF (@idTipoCita = 0)
			BEGIN
				SET @idTipoCita = null
			END
		
		DECLARE @idContratoUnidad INT = 0		
		
		SELECT @idContratoUnidad = idContratoUnidad
		FROM Partidas..ContratoUnidad CU
		inner join ContratoOperacion CO on CU.idContrato = CO.idContrato
		WHERE CO.idContratoOperacion = @idContratoOperacion AND idUnidad = @idTipoUnidad

		
		SELECT 
			DISTINCT
		 PART.idPartida,
				CONT.idContrato,
				ESP.idEspecialidad,
				ESP.especialidad,
				PARCLAS.idPartidaClasificacion,
				PARCLAS.clasificacion,
				CL2.idPartidaSubClasificacion,
				CL2.subClasificacion,
				partida,
				noParte,
				PART.descripcion,
				PART.foto,
				PART.instructivo,
				0.00 as costo, -- FAL en realidad es el precio de venta quedo asi para no modificar el front
				CONTPART.venta venta,
				PARTEST.idPartidaEstatus,
				isnull(PARTEST.estatus, 'Sin Asignar') as partidaEstatus
		FROM Partidas..Partida PART
		JOIN [Partidas].[dbo].[ContratoPartida] CONTPART ON PART.idPartida = CONTPART.idPartida 
		JOIN [Partidas].[dbo].[PartidaClasificacion] PARCLAS ON PART.idPartidaClasificacion = PARCLAS.idPartidaClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaSubClasificacion] CL2 ON CL2.idPartidaSubClasificacion = PART.idPartidaSubClasificacion
		LEFT JOIN [Partidas].[dbo].[PartidaEstatus] PARTEST ON PARTEST.idPartidaEstatus = PART.estatus--PROVPART.idPartidaEstatus						
		LEFT JOIN [Partidas].[dbo].[ContratoUnidad] CONTUNIDAD ON CONTPART.idContratoUnidad = CONTUNIDAD.idContratoUnidad
		LEFT JOIN [Partidas].[dbo].[Contrato] CONT ON CONTUNIDAD.idContrato = CONT.idContrato
		LEFT JOIN [dbo].[ContratoOperacion] OPE ON OPE.idContrato = CONT.idContrato
		LEFT JOIN [Partidas].[dbo].[Unidad] UNI ON UNI.idUnidad = PART.idUnidad
		LEFT JOIN [Partidas].[dbo].[Especialidad] ESP ON ESP.idEspecialidad = PART.idEspecialidad
		LEFT JOIN [partidas].[dbo].[PartidaTipoOrdenServicio] PTOS ON PTOS.idPartida = PART.idPartida 
		WHERE CONTPART.idContratoUnidad = @idContratoUnidad 
		AND PART.estatus = 1
		AND PTOS.idCatalogoTipoOrdenServicio = COALESCE(@idTipoCita, PTOS.idCatalogoTipoOrdenServicio)


go

