-- =============================================
-- Author:		Jose Armando Garcia Arroyo
-- Create date: 28 07 2017
-- [SEL_ORIGEN_UNIDAD_SP] 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ORIGEN_UNIDAD_SP]
AS
BEGIN

SET NOCOUNT ON;
SELECT IdOrigenUnidad, Descripcion FROM dbo.OrigenUnidad
END
go

