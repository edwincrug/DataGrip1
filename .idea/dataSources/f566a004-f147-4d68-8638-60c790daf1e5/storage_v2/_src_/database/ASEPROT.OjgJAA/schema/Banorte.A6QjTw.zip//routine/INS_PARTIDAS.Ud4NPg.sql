
CREATE PROCEDURE [Banorte].[INS_PARTIDAS]
@partidas XML,
@idUsuario int
AS

BEGIN

DECLARE 
@idEspecialidad int = 20,
@idClasificacion int = 1, 
@idSubClasificacion int =1, 
@idPartida int=0, 
@idContratoPartida int=0,
@count int

	declare @tempIds as table (idPartida int);
	declare @tempPartida as table (idTemp int, idUnidad int , idTipoPartida int, 
			 partida nvarchar (50), marca nvarchar (200), noParte nvarchar (200),
			 descripcion nvarchar (max), 
			 idContratoUnidad int, precioCompraR decimal(18,2), 
			 precioCompraMano decimal(18,2), precioVenta decimal(18,2), tiempo nvarchar(8));
		 
	INSERT INTO @tempPartida 
		(idTemp, idUnidad, idTipoPartida, partida, marca, noParte, descripcion, idContratoUnidad, 
		precioCompraR, precioCompraMano, precioVenta, tiempo)
       SELECT 
	    x.value('idTemp[1]', 'INT') AS idTemp, x.value('idTipoUnidad[1]', 'INT') AS idUnidad,
	    x.value('idTipoPartida[1]', 'INT') AS idTipoPartida, x.value('partidaRef[1]', 'nvarchar(50)') AS partida,
		x.value('marca[1]', 'nvarchar(200)') AS marca, x.value('noParte[1]', 'nvarchar(200)') AS noParte, 
		x.value('descripcion[1]', 'nvarchar(max)') AS descripcion, 
		-----------------
		x.value('idContratoUnidad[1]', 'INT'), 
		x.value('precioCompraR[1]', 'decimal(18,2)'),
		x.value('precioCompraMano[1]', 'decimal(18,2)'), x.value('precioVenta[1]', 'decimal(18,2)'),
		x.value('tiempo[1]', 'nvarchar(7)')
       FROM @partidas.nodes('//partida') partidas(x)
	--select * from @tempPartida;

	WHILE (SELECT COUNT(*) FROM @tempPartida) > 0
	BEGIN
		SELECT TOP 1 @count = idTemp FROM @tempPartida

		IF (NOT EXISTS (SELECT noParte FROM Partidas.dbo.Partida WHERE noParte =
			(SELECT noParte FROM @tempPartida WHERE idTemp = @count) 
			and idUnidad = (SELECT top 1 idUnidad FROM @tempPartida WHERE idTemp = @count))) 
			BEGIN
				BEGIN TRY

				INSERT INTO Partidas.dbo.Partida 
						(idUnidad, idTipoPartida, idEspecialidad, 
						 idPartidaClasificacion, idPartidaSubClasificacion, 
						 partida, marca, noParte, descripcion, foto, instructivo, estatus)
					(SELECT x.idUnidad, x.idTipoPartida AS idTipoPartida,
					        @idEspecialidad, @idClasificacion, @idSubClasificacion, x.partida AS partida,
							x.marca AS marca, x.noParte AS noParte, x.descripcion AS descripcion,
							'', '', 1
					 FROM @tempPartida x WHERE  idTemp = @count)						 
			 	
				SELECT @idPartida =  (SELECT idPartida FROM Partidas.dbo.Partida WHERE 
				noParte=(SELECT top 1 noParte FROM @tempPartida WHERE idTemp = @count)
				and idUnidad = (SELECT top 1 idUnidad FROM @tempPartida WHERE idTemp = @count))

				IF( @idPartida>0)
					BEGIN

						insert into [Partidas].[dbo].[ContratoPartida] 
						 (idContratoUnidad, idPartida, venta, fecha, idUsuario, 
						  precio1, precio2, precio3, precio4, precio5, precio6, 
						  precio7, precioMano, precioRefaccion, precioLubricante,
						  tiempo, precio7Respaldo) 

						  (SELECT x.idContratoUnidad, @idPartida,
					        x.precioVenta,GETDATE(), @idUsuario, 
							x.precioCompraR, x.precioCompraR, x.precioCompraR, x.precioCompraR,
							x.precioCompraR, x.precioCompraR, x.precioCompraR, x.precioCompraMano,
							x.precioCompraR, 0.00, CAST(x.tiempo AS TIME), 0.00
					 FROM @tempPartida x WHERE  idTemp = @count)
						
						 select @idContratoPartida =  @@IDENTITY
						 if(@idContratoPartida>0)
						 Begin
							INSERT INTO @tempIds (idPartida) VALUES (@idPartida)	
						 end 
						 else
							rollback;
						 
					END	
				ELSE
					BEGIN
					select ERROR_MESSAGE() 
						delete from Partidas.dbo.Partida where idPartida =@idPartida
					END
			END TRY  
			BEGIN CATCH
				select ERROR_MESSAGE()  	
				delete from Partidas.dbo.Partida where idPartida =@idPartida							
				--INSERT INTO @tempIds (idPartida) VALUES (0)
			END CATCH;	
			END
		ELSE
		BEGIN
			select @idPartida = idPartida FROM Partidas.dbo.Partida WHERE
			 noParte = (SELECT x.noParte FROM @tempPartida x WHERE  idTemp = @count)
			 and idUnidad = (SELECT top 1 idUnidad FROM @tempPartida WHERE idTemp = @count)
			INSERT INTO @tempIds (idPartida) VALUES (@idPartida)
		END	

		DELETE @tempPartida WHERE idTemp = @count
	END
	select * from @tempIds;
	 
END
go

grant execute, view definition on Banorte.INS_PARTIDAS to DevOps
go

