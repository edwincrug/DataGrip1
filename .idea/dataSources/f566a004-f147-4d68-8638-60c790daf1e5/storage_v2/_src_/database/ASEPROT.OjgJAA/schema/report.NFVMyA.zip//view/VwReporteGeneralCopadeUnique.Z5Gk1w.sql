


CREATE VIEW [report].[VwReporteGeneralCopadeUnique]
AS

   SELECT
   *
   FROM [report].[VwReporteGeneralCopade]

   where idOrden not in
   (
   
select [idOrden]
from (
select count(*) as [Events],[idOrden]
      --,[COP_IDDOCTO]
  FROM [report].[VwReporteGeneralCopade]
  group by [idOrden]
     -- ,[COP_IDDOCTO]
  --order  by count(*) desc
	  having count(*) > 1
	  ) as Dobles
	  )

go

