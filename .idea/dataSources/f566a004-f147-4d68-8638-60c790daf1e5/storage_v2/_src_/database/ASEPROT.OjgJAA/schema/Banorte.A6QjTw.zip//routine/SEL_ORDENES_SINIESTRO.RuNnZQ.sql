-- =============================================
-- Author:		<YJH>
-- Create date: <13/03/2019>
-- Description:	<Obtiene las ordenes relacionadas a un siniestro>
-- [BANORTE].[SEL_ORDENES_SINIESTRO] '2019-03-12-011', '18-7049-4736'
-- =============================================
CREATE PROCEDURE [BANORTE].[SEL_ORDENES_SINIESTRO]
	@numReclamo nvarchar(100),
	@numeroOrden nvarchar(100)
AS
BEGIN		
	SET NOCOUNT ON;

	BEGIN TRY
		
		SELECT O.idOrden, O.numeroOrden FROM RefaccionMultiMarca.Operacion.Siniestro S 
		inner join RefaccionMultiMarca.Relacion.UnidadSiniestroOrden US on S.id = US.idSiniestro
		inner JOIN ASEPROT.dbo.Ordenes O ON O.idOrden = US.orden
		WHERE S.numeroReclamo=@numReclamo AND O.numeroOrden <> @numeroOrden and O.idEstatusOrden not in (13,15)

	END TRY
	BEGIN CATCH		
		SELECT ERROR_NUMBER() AS Number,
		       ERROR_SEVERITY() AS Severity,
			   ERROR_STATE() AS [State],
			   ERROR_PROCEDURE() AS [Procedure],
			   ERROR_LINE() AS Line,
			   ERROR_MESSAGE() AS [Message]
	END CATCH

SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.SEL_ORDENES_SINIESTRO to DevOps
go

