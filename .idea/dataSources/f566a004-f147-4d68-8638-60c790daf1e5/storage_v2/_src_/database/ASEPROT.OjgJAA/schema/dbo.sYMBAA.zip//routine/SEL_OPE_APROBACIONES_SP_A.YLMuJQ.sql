-- =============================================
-- Create date: 03/10/2017
-- Description:	Stored que consulta ordenes con estatus 1 Citas sin taller
-- [SEL_OPE_APROBACIONES_SP_A] 3,107,'',0
-- =============================================

 CREATE PROCEDURE [dbo].[SEL_OPE_APROBACIONES_SP_A]
	@idContratoOperacion INT = 3,
	@idUsuario INT = 489, 
	@numeroOrden VARCHAR(50) = '',
	@idEjecutivo INT = 0
		
AS
BEGIN

	SET NOCOUNT ON;  
 
	DECLARE @idCatalogoRol INT  
	DECLARE @idContratoOperacionUsuario INT
	DECLARE @idContratoOperacionUsuarioEjecutivo INT
	DECLARE @idOperacion INT
	DECLARE @select NVARCHAR(MAX) = '' 
	DECLARE @where NVARCHAR(MAX) = '' 
	DECLARE @query NVARCHAR(MAX) = ''
	DECLARE @join NVARCHAR(MAX) = ''
	DECLARE @usuario NVARCHAR(MAX) = '' 
	DECLARE @zonas NVARCHAR(MAX) = ''
	DECLARE @zonasEjecutivo NVARCHAR(MAX) = ''

	SELECT @idContratoOperacionUsuario = COU.idContratoOperacionUsuario, @idCatalogoRol = COU.idCatalogoRol, @idOperacion = CO.idOperacion
	FROM Usuarios U 
		JOIN ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
		JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
	WHERE U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	IF(@idCatalogoRol <> 2 AND @idEjecutivo = 0)
		BEGIN
		    IF(@idCatalogoRol <> 4)
				BEGIN
					SET @usuario  = 'AND Z.idZona in (SELECT idZona FROM ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = '+ convert(varchar(5), @idContratoOperacionUsuario) +') '
				END
			ELSE
				BEGIN
					set @usuario  = ' AND C.idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idOperacion)+')) '
				END
		END
	ELSE IF(@idCatalogoRol = 2 AND @idEjecutivo != 0)
		BEGIN 
			SET @usuario  = 'AND Z.idZona in (SELECT idZona FROM ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = '+ convert(varchar(5), @idContratoOperacionUsuario) +') '
		END
	
	SET @select = 
		'SELECT 
		(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente,
		O.consecutivoOrden,
		O.numeroOrden,
		U.numeroEconomico,
		Z.nombre AS nombreZona,
		CTO.nombreTipoOrdenServicio AS nombreTipoOrdenServicio,
		O.fechaCreacionOden,	
		O.comentarioOrden AS comentarioOrden,
		EC.[idEstatusCotizacion],
		EC.[nombreEstatusCotizacion] AS nombreEstatusCotizacion,
		O.idOrden as [idOrden],
		(SELECT [dbo].[SEL_OPERACION_TIENE_PRESUPUESTO](O.idOrden)) AS tienePresupuesto,
		UR.nombreCompleto AS nombreUsuario,
		(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 2,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS venta,
		(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 2,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS costo,
		DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEspera,
		O.idOrden,
		Z.idZona
	FROM Ordenes O
		JOIN Cotizaciones C ON C.idOrden = O.idOrden
		JOIN Unidades U ON U.idUnidad = O.idUnidad
		JOIN [dbo].[EstatusCotizaciones] EC ON EC.[idEstatusCotizacion] = C.[idEstatusCotizacion]
		JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
		JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
		JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
		JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
		JOIN Partidas..Zona Z ON Z.idZona = O.idZona '

	SET @where = 'WHERE CO.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+' AND O.idEstatusOrden IN(4,5) AND C.idEstatusCotizacion IN(1,2) '

	IF(@numeroOrden != '')
	  BEGIN
		SET @numeroOrden =' AND O.numeroOrden like ''%'+@numeroOrden+'%'''
	  END

	SET @query = @select + @where + @usuario + @numeroOrden
	EXECUTE SP_EXECUTESQL @query
	PRINT @query
END
go

