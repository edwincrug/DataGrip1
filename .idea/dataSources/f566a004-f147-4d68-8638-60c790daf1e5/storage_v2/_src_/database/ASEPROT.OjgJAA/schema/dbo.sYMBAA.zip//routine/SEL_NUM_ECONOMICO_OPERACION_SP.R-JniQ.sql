-- =============================================
-- Create date: 13/06/2017
-- Description:	Números economicos de una operación
-- [SEL_NUM_ECONOMICO_OPERACION_SP]15,676
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_NUM_ECONOMICO_OPERACION_SP]
	@idContratoOperacion INT,
	@idUsuario INT = 0
AS
BEGIN

	IF EXISTS(SELECT 1 FROM UsuarioAgrupador WHERE idUsuario = @idUsuario) BEGIN

		SELECT U.idUnidad, U.numeroEconomico, 'económico' AS tipo FROM UnidadAgrupador UNI
			INNER JOIN UsuarioAgrupador US ON US.idAgrupador = UNI.idAgrupador
			INNER JOIN Unidades U ON U.idUnidad = UNI.idUnidad
			WHERE US.idUsuario = @idUsuario AND U.numeroEconomico IS NOT NULL


		union all

		SELECT U.idUnidad, U.placas, 'placas' AS tipo FROM UnidadAgrupador UNI
			INNER JOIN UsuarioAgrupador US ON US.idAgrupador = UNI.idAgrupador
			INNER JOIN Unidades U ON U.idUnidad = UNI.idUnidad
			WHERE US.idUsuario = 840 AND U.placas IS NOT NULL

		union all

		SELECT U.idUnidad, U.vin, 'vin' AS tipo FROM UnidadAgrupador UNI
			INNER JOIN UsuarioAgrupador US ON US.idAgrupador = UNI.idAgrupador
			INNER JOIN Unidades U ON U.idUnidad = UNI.idUnidad
			WHERE US.idUsuario = @idUsuario AND U.vin IS NOT NULL
		
	END ELSE BEGIN

		--SELECT idUnidad, numeroEconomico, 'económico' as tipo FROM Unidades UN 
		--	INNER JOIN ContratoOperacion CO ON UN.idOperacion = CO.idOperacion
		--	WHERE CO.idContratoOperacion= @idContratoOperacion AND numeroEconomico IS NOT NULL
		
		--union all

		--SELECT idUnidad, placas, 'placas' as tipo FROM Unidades UN 
		--	INNER JOIN ContratoOperacion CO ON UN.idOperacion = CO.idOperacion
		--	WHERE CO.idContratoOperacion= @idContratoOperacion AND placas IS NOT NULL

		--union all

		--SELECT idUnidad, vin, 'vin' as tipo  FROM Unidades UN 
		--	INNER JOIN ContratoOperacion CO ON UN.idOperacion = CO.idOperacion
		--	WHERE CO.idContratoOperacion= @idContratoOperacion AND vin IS NOT NULL

		SELECT idUnidad, numeroEconomico, 'económico' as tipo FROM Unidades UN 
			INNER JOIN ContratoOperacion CO ON UN.idOperacion = CO.idOperacion
			INNER JOIN ContratoOperacionUsuario CU ON CU.idContratoOperacion = CO.idContratoOperacion
			WHERE CU.idUsuario = @idUsuario
			AND numeroEconomico IS NOT NULL
		
		union all

		SELECT idUnidad, placas, 'placas' as tipo FROM Unidades UN 
			INNER JOIN ContratoOperacion CO ON UN.idOperacion = CO.idOperacion
			INNER JOIN ContratoOperacionUsuario CU ON CU.idContratoOperacion = CO.idContratoOperacion
			WHERE CU.idUsuario = @idUsuario
			AND placas IS NOT NULL

		union all

		SELECT idUnidad, vin, 'vin' as tipo  FROM Unidades UN 
			INNER JOIN ContratoOperacion CO ON UN.idOperacion = CO.idOperacion
			INNER JOIN ContratoOperacionUsuario CU ON CU.idContratoOperacion = CO.idContratoOperacion
			WHERE CU.idUsuario = @idUsuario
			AND vin IS NOT NULL

	END
		
END


go

