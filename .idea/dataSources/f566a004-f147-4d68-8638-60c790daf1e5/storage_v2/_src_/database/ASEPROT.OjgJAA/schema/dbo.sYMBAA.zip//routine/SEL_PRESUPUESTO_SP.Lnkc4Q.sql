--[SEL_PRESUPUESTO_SP] '03-10166-29379'
CREATE Procedure  [dbo].[SEL_PRESUPUESTO_SP]
@numeroOrden  nvarchar(100) =''

AS
BEGIN

DECLARE  @idCentroTrabajo INT = 0
DECLARE  @idOrden INT = 0
DECLARE  @idContratoOperacion INT = 0
DECLARE	 @estatusOrden INT = 0

	SELECT @idCentroTrabajo = idCentroTrabajo,
		   @idOrden = idOrden,
		   @idContratoOperacion = idContratoOperacion,
		   @estatusOrden = [idEstatusOrden]
	FROM Ordenes WITH (NOLOCK)
	WHERE numeroOrden = @numeroOrden 

	DECLARE @numero TABLE(estatusCotizacion int, estatusPartida int)
	IF(@estatusOrden = 4)
		insert @numero values(1, 1)
		insert @numero values(2, 2)
	IF(@estatusOrden = 5)
		insert @numero values(3, 2)

	IF(@idContratoOperacion=3)
	BEGIN
		if not exists (select 1 from OrdenesPresupuestoEspecial where idOrden = @idOrden)
				begin
					SELECT *,
						   saldo - venta AS presupuestoVenta
					 FROM(
						SELECT
							idPresupuesto,
							folioPresupuesto,
							fechaInicioPresupuesto,
							fechaFinalPresupuesto,
							idCentroTrabajo,
							idEstatusPresupuesto,
							orden,
							fechaAlta,
							presupuesto,
							(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
						FROM [dbo].[Cotizaciones] C  WITH (NOLOCK)
						INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
						LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
					WHERE PO.idPresupuesto = P.idPresupuesto
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3)) +
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
						FROM ASEPROTSISCO.[dbo].[Cotizaciones] C WITH (NOLOCK)
						INNER JOIN ASEPROTSISCO.[dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN ASEPROTSISCO.[dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
						LEFT JOIN ASEPROTSISCO.dbo.PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
						INNER JOIN ASEPROTSISCO.[dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
					WHERE PO.idPresupuesto = P.idPresupuesto
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3)) utilizado,
					(presupuesto 			
					+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
					- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
					+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
						FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
						INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
						LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
					WHERE  PO.idPresupuesto = P.idPresupuesto
					AND CO.idOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3))) +
					( 			
					--+ (select isnull(sum(isnull(Monto,0)),0) from ASEPROTSISCO.[dbo].traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
					- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
					--+ (select isnull(sum(isnull(Monto,0)),0) from ASEPROTSISCO.[dbo].traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
						FROM ASEPROTSISCO.[dbo].[Cotizaciones] C WITH (NOLOCK)
						INNER JOIN ASEPROTSISCO.[dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN ASEPROTSISCO.[dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
						LEFT JOIN ASEPROTSISCO.dbo.PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
						INNER JOIN ASEPROTSISCO.[dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
					WHERE  PO.idPresupuesto = P.idPresupuesto
					AND CO.idOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3))) saldo,
							--(SELECT [dbo].[SEL_PRECIO_COSTO_FN](@idOrden, @idContratoOperacion, 4)) AS costo,
							--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](@idOrden, @idContratoOperacion, 4)) AS venta
							(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
								FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
								INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
								INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
								INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
							WHERE O.idOrden = @idOrden 
							AND CO.idContratoOperacion = @idContratoOperacion
							AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
							AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))venta,			
							(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
								FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
								INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
								INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
								INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
							WHERE O.idOrden = @idOrden 
							AND CO.idContratoOperacion = @idContratoOperacion 
							AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
							AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))costo
						FROM Presupuestos P WITH (NOLOCK)
						WHERE P.idCentroTrabajo=@idCentroTrabajo AND P.idEstatusPresupuesto = 1
						AND P.idPresupuesto <= 953
						UNION
						SELECT
						idPresupuesto,
						folioPresupuesto,
						fechaInicioPresupuesto,
						fechaFinalPresupuesto,
						idCentroTrabajo,
						idEstatusPresupuesto,
						orden,
						fechaAlta,
						presupuesto,
						(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE PO.idPresupuesto = P.idPresupuesto
						AND CO.idContratoOperacion  in (3, 8)--= @idContratoOperacion 
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3)) utilizado,
						(presupuesto
						+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
						 - (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						 + (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
							FROM [dbo].[Cotizaciones] C  WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE  PO.idPresupuesto = P.idPresupuesto
						AND CO.idContratoOperacion  in (3, 8)--= @idContratoOperacion 
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3))) saldo,
						--(SELECT [dbo].[SEL_PRECIO_COSTO_FN](@idOrden, @idContratoOperacion, 4)) AS costo,
						--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](@idOrden, @idContratoOperacion, 4)) AS venta
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = @idOrden 
						AND CO.idContratoOperacion  in (3, 8)--= @idContratoOperacion 
						AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
						AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))venta,			
						(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = @idOrden 
						AND CO.idContratoOperacion  in (3, 8)--= @idContratoOperacion 
						AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
						AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))costo
					FROM Presupuestos P WITH (NOLOCK)
					WHERE P.idCentroTrabajo=@idCentroTrabajo AND P.idEstatusPresupuesto = 1
					AND P.idPresupuesto >= 954) Presupuesto
				end
			else
				begin
					SELECT *,
						   saldo - venta AS presupuestoVenta
					 FROM(
						SELECT
							P.idPresupuesto,
							folioPresupuesto,
							fechaInicioPresupuesto,
							fechaFinalPresupuesto,
							idCentroTrabajo,
							idEstatusPresupuesto,
							orden,
							P.fechaAlta,
							presupuesto,
							(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,
							(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
						FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
						INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
						LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
					WHERE PO.idPresupuesto = P.idPresupuesto
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3)) +
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
						FROM ASEPROTSISCO.[dbo].[Cotizaciones] C 
						INNER JOIN ASEPROTSISCO.[dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN ASEPROTSISCO.[dbo].[Ordenes]	O ON C.idOrden = O.idOrden
						LEFT JOIN ASEPROTSISCO.dbo.PresupuestoOrden PO ON PO.idOrden = O.idOrden
						INNER JOIN ASEPROTSISCO.[dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
					WHERE PO.idPresupuesto = P.idPresupuesto
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3)) utilizado,
					(presupuesto 			
					+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
					- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
					+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
						FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
						INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
						LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
					WHERE  PO.idPresupuesto = P.idPresupuesto
					AND CO.idOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3))) +
					( 			
					--+ (select isnull(sum(isnull(Monto,0)),0) from ASEPROT.[dbo].traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
					- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 			
					--+ (select isnull(sum(isnull(Monto,0)),0) from ASEPROT.[dbo].traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
						FROM ASEPROTSISCO.[dbo].[Cotizaciones] C 
						INNER JOIN ASEPROTSISCO.[dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN ASEPROTSISCO.[dbo].[Ordenes]	O ON C.idOrden = O.idOrden
						LEFT JOIN ASEPROTSISCO.dbo.PresupuestoOrden PO ON PO.idOrden = O.idOrden
						INNER JOIN ASEPROTSISCO.[dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
					WHERE  PO.idPresupuesto = P.idPresupuesto
					AND CO.idOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3))) saldo,
							--(SELECT [dbo].[SEL_PRECIO_COSTO_FN](@idOrden, @idContratoOperacion, 4)) AS costo,
							--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](@idOrden, @idContratoOperacion, 4)) AS venta
							(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
								FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
								INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
								INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
								INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
							WHERE O.idOrden = @idOrden 
							AND CO.idContratoOperacion = @idContratoOperacion
							AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
							AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))venta,			
							(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
								FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
								INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
								INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
								INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
							WHERE O.idOrden = @idOrden 
							AND CO.idContratoOperacion = @idContratoOperacion 
							AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
							AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))costo
						FROM Presupuestos P
						inner join OrdenesPresupuestoEspecial PO on P.idPresupuesto = PO.idPresupuesto and PO.idOrden = @idOrden
						WHERE P.idCentroTrabajo=@idCentroTrabajo AND P.idEstatusPresupuesto = 4 AND P.idPresupuesto <= 953
						UNION
						SELECT
						P.idPresupuesto,
						folioPresupuesto,
						fechaInicioPresupuesto,
						fechaFinalPresupuesto,
						idCentroTrabajo,
						idEstatusPresupuesto,
						orden,
						P.fechaAlta,
						presupuesto,
						(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE PO.idPresupuesto = P.idPresupuesto
						AND CO.idContratoOperacion  in (3, 8)--= @idContratoOperacion 
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3)) utilizado,
						(presupuesto 
						+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
						- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE  PO.idPresupuesto = P.idPresupuesto
						AND CO.idContratoOperacion  in (3, 8)--= @idContratoOperacion 
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3))) saldo,
						--(SELECT [dbo].[SEL_PRECIO_COSTO_FN](@idOrden, @idContratoOperacion, 4)) AS costo,
						--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](@idOrden, @idContratoOperacion, 4)) AS venta
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = @idOrden 
						AND CO.idContratoOperacion  in (3, 8)--= @idContratoOperacion 
						AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
						AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))venta,			
						(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = @idOrden 
						AND CO.idContratoOperacion  in (3, 8)--= @idContratoOperacion 
						AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
						AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))costo
					FROM Presupuestos P WITH (NOLOCK)
					inner join OrdenesPresupuestoEspecial PO on P.idPresupuesto = PO.idPresupuesto and PO.idOrden = @idOrden
					WHERE P.idCentroTrabajo=@idCentroTrabajo AND P.idEstatusPresupuesto = 4
					AND P.idPresupuesto >= 954) Presupuesto
				end
	end
else
	begin
		if not exists (select 1 from OrdenesPresupuestoEspecial where idOrden = @idOrden)
			begin
				SELECT *,
					   saldo - venta AS presupuestoVenta
				 FROM(
					SELECT
						idPresupuesto,
						folioPresupuesto,
						fechaInicioPresupuesto,
						fechaFinalPresupuesto,
						idCentroTrabajo,
						idEstatusPresupuesto,
						orden,
						fechaAlta,
						presupuesto,
						(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE PO.idPresupuesto = P.idPresupuesto
						AND CO.idContratoOperacion = @idContratoOperacion
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3)) utilizado,
						(presupuesto
						+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
						 - (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						 + (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE  PO.idPresupuesto = P.idPresupuesto
						AND CO.idContratoOperacion = @idContratoOperacion
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3))) saldo,
						--(SELECT [dbo].[SEL_PRECIO_COSTO_FN](@idOrden, @idContratoOperacion, 4)) AS costo,
						--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](@idOrden, @idContratoOperacion, 4)) AS venta
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = @idOrden 
						AND CO.idContratoOperacion = @idContratoOperacion
						AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
						AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))venta,			
						(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = @idOrden 
						AND CO.idContratoOperacion = @idContratoOperacion 
						AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
						AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))costo
					FROM Presupuestos P WITH (NOLOCK)
					WHERE P.idCentroTrabajo=@idCentroTrabajo AND P.idEstatusPresupuesto = 1) Presupuesto
			end
		else
			begin
				SELECT *,
					   saldo - venta AS presupuestoVenta
				 FROM(
					SELECT
						P.idPresupuesto,
						folioPresupuesto,
						fechaInicioPresupuesto,
						fechaFinalPresupuesto,
						idCentroTrabajo,
						idEstatusPresupuesto,
						orden,
						P.fechaAlta,
						presupuesto,
						(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE PO.idPresupuesto = P.idPresupuesto
						AND CO.idContratoOperacion = @idContratoOperacion
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3)) utilizado,
						(presupuesto 
						+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto) 
						- (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							LEFT JOIN PresupuestoOrden PO WITH (NOLOCK) ON PO.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE  PO.idPresupuesto = P.idPresupuesto
						AND CO.idContratoOperacion = @idContratoOperacion
						AND CD.idEstatusPartida IN(2) 
						AND C.idEstatusCotizacion IN(3))) saldo,
						--(SELECT [dbo].[SEL_PRECIO_COSTO_FN](@idOrden, @idContratoOperacion, 4)) AS costo,
						--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](@idOrden, @idContratoOperacion, 4)) AS venta
						(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = @idOrden 
						AND CO.idContratoOperacion = @idContratoOperacion
						AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
						AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))venta,			
						(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
							FROM [dbo].[Cotizaciones] C WITH (NOLOCK)
							INNER JOIN [dbo].[CotizacionDetalle] CD WITH (NOLOCK) ON C.idCotizacion = CD.idCotizacion  
							INNER JOIN [dbo].[Ordenes]	O WITH (NOLOCK) ON C.idOrden = O.idOrden
							INNER JOIN [dbo].[ContratoOperacion] CO WITH (NOLOCK) ON O.idContratoOperacion = CO.idContratoOperacion
						WHERE O.idOrden = @idOrden 
						AND CO.idContratoOperacion = @idContratoOperacion 
						AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
						AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero))costo
					FROM Presupuestos P WITH (NOLOCK)
					inner join OrdenesPresupuestoEspecial PO on P.idPresupuesto = PO.idPresupuesto and PO.idOrden = @idOrden
					WHERE P.idCentroTrabajo=@idCentroTrabajo AND P.idEstatusPresupuesto = 4) Presupuesto
			end
end
END
go

grant execute, view definition on SEL_PRESUPUESTO_SP to DevOps
go

