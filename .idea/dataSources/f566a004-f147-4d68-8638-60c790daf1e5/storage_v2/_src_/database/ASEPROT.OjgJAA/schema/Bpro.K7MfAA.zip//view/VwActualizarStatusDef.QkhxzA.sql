
CREATE VIEW [Bpro].[VwActualizarStatusDef]
AS
SELECT [MODULO]
      ,[DES_CARTERA]
      ,[DES_TIPODOCTO]
      ,[CCP_IDDOCTO]
      ,[CCP_NODOCTO]
      ,[CCP_IDPERSONA]
      ,[Nombre]
      ,[PER_TELEFONO1]
      ,[CCP_FECHVEN]
      ,[CCP_FECHPAG]
      ,[CCP_FECHPROMPAG]
      ,[CCP_FECHREV]
      ,[IMPORTE]
      ,[SALDO]
      ,[CCP_FECHADOCTO]
      ,[CCP_TIPODOCTO]
      ,[CCP_ORIGENCON]
      ,[COP_STATUS]
	  , case when [IMPORTE] = [SALDO]
	          then 2
			  else
			        case when [IMPORTE] > [SALDO]
					     and  [SALDO] > 1
					then 4
					else
					case when Saldo between 0 and 0.99
					then 3
					end
			 end
         end as [NewStatus]

		 FROM [Bpro].[VwActualizarStatusBase]

go

grant select, view definition on Bpro.VwActualizarStatusDef to DevOps
go

