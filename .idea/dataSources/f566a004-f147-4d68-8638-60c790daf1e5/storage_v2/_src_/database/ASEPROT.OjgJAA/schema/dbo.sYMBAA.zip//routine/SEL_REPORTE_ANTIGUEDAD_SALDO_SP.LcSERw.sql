--[dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP] 103,null,null,null,null,null,null,null
--       [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP] 58
CREATE procedure[dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP]
	@idOperacion as INT = null,
    @fechaInicial as VARCHAR(max) = null,
    @fechaFinal as VARCHAR(max) = NULL,
    @taller as VARCHAR(150) = NULL,
    @idCallcenter as INT = NULL,
    @idEstatus as INT = NULL,
    @idZona as INT = NULL,
    @numeroOrden VARCHAR(50) = NULL

AS

	SET DATEFORMAT DMY;

	declare @query VARCHAR(max)='';
	declare @whereZona VARCHAR(max)='';
	declare @condiciones VARCHAR(max)='';
	DECLARE @idContratoOperacion NUMERIC(18,0) 

	SET @idContratoOperacion = (SELECT idContratoOperacion FROM ContratoOperacion WHERE idOperacion = @idOperacion)

	set @query='SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @idContrato NUMERIC(18,0) 
	DECLARE @nombreCliente VARCHAR(MAX)

	SET @idContrato= (SELECT idContrato 
	FROM [ContratoOperacion] 
	WHERE idOperacion = '+cast(@idOperacion as varchar(3))+')

	SET @nombreCliente =(SELECT Cli.razonSocial 
	FROM [Partidas].[dbo].[Cliente] Cli
		INNER JOIN [Partidas].[dbo].[Licitacion] Lic ON Lic.idCliente = Cli.idCliente
		INNER JOIN [Partidas].[dbo].[Contrato] Con ON Con.idLicitacion = Lic.idLicitacion
	WHERE Con.idContrato = @idContrato)
	
		CREATE TABLE #datos(Cliente VARCHAR(MAX),consecutivoOrden int,numeroOrden VARCHAR(MAX)
	, numeroEconomico VARCHAR(MAX), numeroCopade  VARCHAR(MAX), folioPreuspuesto VARCHAR(MAX)
	,talleres VARCHAR(MAX),costo FLOAT,venta FLOAT,descripcion VARCHAR(MAX),estatus VARCHAR(MAX)
	,idEstatus NUMERIC(18,0), nombrePadre  VARCHAR(MAX),nombreZona VARCHAR(MAX),idZona INT
	, fechaCreacionOrden DATETIME,aplicaFondo VARCHAR(MAX),fechaAprobacion DATETIME,fechaProceso DATETIME
	,fechaTerminoTrabajo DATETIME,fechaSalida DATETIME, fechaFinaliza DATETIME,Dias INT,ordenSurtimiento  VARCHAR(MAX)
	,	codigoSAP VARCHAR(MAX),fechaRecepcionCopade DATETIME,fechaPago DATETIME,	Color VARCHAR(MAX))

	INSERT INTO #datos
	SELECT *
	, CASE WHEN aplicaFondo=''rowAzulDark'' THEN ''Azul'' 
	WHEN aplicaFondo=''rowAmarillo'' THEN ''Amarillo''
	ELSE '''' END AS Color FROM(
			SELECT
				@nombreCliente AS Cliente,
				O.consecutivoOrden AS consecutivoOrden,
				O.numeroOrden AS numeroOrden,
				U.numeroEconomico AS numeroEconomico,
				isnull(DC.numeroCopade,''Sin numero'') AS numeroCopade,
				isnull(PO.folio,''Sin folio'') AS folioPreuspuesto,
				
				[dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden) talleres,
				Tot.costo AS costo,
				Tot.venta AS venta,
				--DC.total AS venta,
				[dbo].[fnReemplazaASCII](isnull(O.comentarioOrden, ''Sin descripcion'')) AS descripcion,
				EO.nombreEstatusOrden AS estatus,
				EO.idEstatusOrden AS idEstatus,
				--ZP.nombre AS nombrePadre,
				CASE 
					WHEN O.IDCONTRATOOPERACION = 57 THEN 
					(SELECT NOMBRE FROM PARTIDAS..ZONA WHERE idZona = Z.idPadre )
					ELSE (SELECT [dbo].[GET_ZONAS_ORDEN_FN] (Z.idZona)) 
					END nombrePadre,
				Z.nombre AS nombreZona,
				Z.idZona,
				O.fechaCreacionOden AS fechaCreacionOrden,
				--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <=''12/11/2018'' AND O.idEstatusOrden in (1,2,3,4) THEN 1
				--ELSE 0 END
				--AS aplicaFondo,
				--[dbo].[fnColorBackgroudFila](O.idOrden, O.numeroOrden, O.idContratoOperacion) AS aplicaFondo,
				CASE WHEN ISNULL(OC.numeroOrden,'''')<>'''' THEN CB.codigoCSS
				WHEN O.idContratoOperacion=OC.idContratoOperacion AND ISNULL(OC.numeroOrden,'''')='''' THEN CB.codigoCSS
				ELSE '''' END AS aplicaFondo,
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =4) AS fechaAprobacion,      
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =5) AS fechaProceso,   
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =6) AS fechaTerminoTrabajo,
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =7) AS fechaSalida,
				(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =8) AS fechaFinaliza,
				VOSDO.Dias AS Dias,
				isnull(P.folioPresupuesto,''Sin Orden de Surtimiento'') as ordenSurtimiento
				,ISNULL((SELECT TOP 1 CodigoSAP.numeroSAP FROM CodigoSAP WHERE CodigoSAP.idOrden = O.idOrden),'''') codigoSAP
				,DC.fechaRecepcionCopade
				,(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden =12) AS fechaPago
			FROM Ordenes O
				LEFT JOIN Ordenescolores OC 
					INNER JOIN ColoresBackground CB ON oc.idColor=CB.idColoresBackground
				ON OC.numeroOrden=o.numeroOrden
				JOIN Unidades U ON U.idUnidad = O.idUnidad
				JOIN EstatusOrdenes EO ON EO.idEstatusOrden = o.idEstatusOrden
				JOIN Partidas..Zona Z ON Z.idZona = O.idZona
				--JOIN Partidas..Zona ZP ON ZP.idZona = Z.idPadre
				LEFT JOIN DatosCopadeOrden DCO ON DCO.idOrden = O.idOrden
				LEFT JOIN DatosCopade DC ON DC.idDatosCopade = DCO.idDatosCopade
				LEFT JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden
				LEFT JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto
				LEFT JOIN [report].[VwOrdenTotales] Tot ON  Tot.idOrden = o.idOrden
				LEFT JOIN  [report].[VwOrdenStatusMaxDateDias] VOSDO ON VOSDO.[idOrden] = O.[idOrden]  and VOSDO.[idEstatusOrden] = O.[idEstatusOrden]
	            WHERE O.idEstatusOrden not in (13) AND O.idContratoOperacion='+cast(@idContratoOperacion as varchar(3))+'
	            ) AS X '
				print @query
	         SET @query = @query + ' SELECT * FROM #datos '
	            print @query
	  SET @condiciones = '
      WHERE numeroOrden not in (select ordenesFuera.numeroOrden from ( 
		                    select distinct ord.numeroOrden,count (d.idDatosCopadeOrden) cuenta from Ordenes ord
                               join DatosCopadeOrden d on ord.idOrden=d.idOrden 
                               group by ord.numeroOrden having count(d.idDatosCopadeOrden)>1
					    ) ordenesFuera )'
	IF (@fechaInicial IS NOT NULL OR @fechaFinal IS NOT NULL)
		SET @condiciones = @condiciones + '
						AND  fechaCreacionOrden BETWEEN COALESCE(CAST('''+isnull(@fechaInicial,'null')+''' AS DATE),fechaCreacionOrden) AND COALESCE(CAST('''+isnull(@fechaFinal,'null')+''' AS DATE),fechaCreacionOrden)
						'
	IF (@taller IS NOT NULL)
		SET @condiciones = @condiciones + 
							' AND	('''+isnull(@taller,'null')+''' IS NULL OR talleres LIKE ''%'+isnull(@taller,'')+'%'')'
	IF (@idEstatus IS NOT NULL)
		SET @condiciones = @condiciones + 					
			'AND	idEstatus = COALESCE('+isnull(cast(@idEstatus as varchar(2)),'null')+', idEstatus)'
	IF (@numeroOrden IS NOT NULL)
		SET @condiciones = @condiciones + 	
			'AND	('''+isnull(@numeroOrden,'null')+''' IS NULL OR numeroOrden like ''%'+isnull(@numeroOrden,'')+'%'')'
	    
		if(@idZona is not null)
		BEGIN
		  set @whereZona=' AND idZona ='+ cast(@idZona as varchar(2))+' '
		END
		if (@idCallcenter is not null)
		BEGIN
		  set @whereZona=@whereZona+' AND idZona in(
		  select idZona from ContratoOperacionUsuario cou 
		         join ContratoOperacionUsuarioZona couz on cou.idContratoOperacionUsuario=couz.idContratoOperacionUsuario
		  where idUsuario='+cast(@idCallcenter as varchar(2))+')'
		END
		set @query=@query+@condiciones+@whereZona +' DROP TABLE #datos SET TRANSACTION ISOLATION LEVEL READ COMMITTED'
		print @condiciones+@whereZona +' DROP TABLE #datos SET TRANSACTION ISOLATION LEVEL READ COMMITTED'
	   
	    EXEC(@query)

go

