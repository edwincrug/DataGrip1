-- =============================================
-- Create date: 13/06/2017
-- Description:	Números de órdenes de una operación
-- [SEL_NUM_ORDEN_OPERACION_SP]3
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_NUM_ORDEN_OPERACION_SP]
	@idContratoOperacion INT
AS
BEGIN
	
	SELECT TOP 800 numeroOrden FROM Ordenes 
		WHERE idContratoOperacion= @idContratoOperacion
		
END


go

