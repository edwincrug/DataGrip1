CREATE PROCEDURE [dbo].[SEL_ESTADO_SERVICIO_SP] 

AS
BEGIN
	
	SELECT idPartidaClasificacion AS idService, clasificacion AS nameService
	FROM Partidas..PartidaClasificacion

END
go

