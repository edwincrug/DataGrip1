/*
	Objetivo: Devuelve las piezas rechazadas por Despacho
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	31/07/18		JEHR	Creación del SP
	[Banorte].[SEL_SISRE_RECHAZADAS] 38689
	
*/
CREATE PROCEDURE[Banorte].[SEL_SISRE_RECHAZADAS]
	@idOrden int
AS
BEGIN
	SELECT
		 c.idCotizacionSISCO as idCotizacion,
		 PTS_IDPARTE as no_pieza
	FROM [PortalDespacho].[dbo].[PedidoEntregaDetalle] AS e
	INNER JOIN [PortalRefacciones].[dbo].[pre_pedidoref] AS r ON r.pre_pedidobpro = e.pre_pedidobpro
	INNER JOIN  [RefaccionMultiMarca].[Relacion].[SiniestroOrdenCotizacion] AS c ON c.idCotizacion = R.pre_idcotizacion
	INNER JOIN [RefaccionMultiMarca].[Operacion].[Cotizacion] AS z ON z.idCotizacion = c.idCotizacion
	INNER JOIN [RefaccionMultiMarca].[Operacion].[CotizacionDetalle] AS cd ON cd.idCotizacion = c.idCotizacion and e.ncd_codigoparte = cd.PTS_IDPARTE
	INNER JOIN [ASEPROT].[dbo].[Ordenes] AS Ord ON Ord.idOrden = c.idOrden 
	INNER JOIN [RefaccionMultiMarca].[Catalogo].Marca AS Ma ON Ma.idMarca = cd.idMarca
	WHERE	
			e.MotivoDevolucion IN  (SELECT [Nombre] FROM [RefaccionMultiMarca].[Catalogo].[StatusOrdenAut]) AND 
			e.idPedidoEntregaDetalle NOT IN (SELECT [idPedidoEntregaDetalle] FROM [RefaccionMultiMarca].[Operacion].[Reorden]) AND 
			c.idOrden = @idOrden

END
go

grant execute, view definition on Banorte.SEL_SISRE_RECHAZADAS to DevOps
go

