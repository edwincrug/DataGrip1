

--[dbo].[INS_MEMORANDUM_SP] 'asd','asd',1,1,1,'[{"id":6},{"id":7},{"id":8},{"id":9}]','[{"id":2,"text":"Administrador"}]','[{"id":181,"text":"Edwin Cruz"}]'
CREATE PROCEDURE [dbo].[INS_MEMORANDUM_SP]
	-- Add the parameters for the stored procedure here
	@titulo						NVARCHAR(100),
	@descripcion				NVARCHAR(MAX),
	@notificaZona				INT,	
	@notificaPerfil				INT,
	@notificaUsuario			INT,	
	@contieneEvidencias			INT,
	@jsonZonas					NVARCHAR(MAX),
	@jsonPerfiles				NVARCHAR(MAX),
	@jsonUsuarios				NVARCHAR(MAX),
	@jsonEvidencias				NVARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	DECLARE @idMemorandum NUMERIC(18,0)

	--INSERTAMOS ENCABEZADO

	INSERT INTO Memorandum
	(
		fecha,
		titulo,
		descripcion,
		notificaZona,
		notificaPerfil,
		notificaUsuario
	)
	VALUES
	(
		GETDATE(),
		@titulo,
		@descripcion,
		@notificaZona,
		@notificaPerfil,
		@notificaUsuario
	)

	set @idMemorandum =  @@IDENTITY 

	DECLARE @parent AS INT

	--1. EN CASO DE ZONAS

	IF (@notificaZona=1)
	BEGIN
		DECLARE @idZona NUMERIC(18,0)
		
		--CREAMOS TABLA TEMPORAL PARA EL JSON
		CREATE TABLE #JSONZonas(
			element_id numeric(18,0),
			secuenceNo numeric(18,0),
			parent_ID numeric(18,0),
			Object_ID numeric(18,0),
			NAME nvarchar(MAX),
			StringValue nvarchar(MAX),
			ValueType nvarchar(MAX)
		)
		--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
		INSERT INTO #JSONZonas
		SELECT * FROM parseJSON(@jsonZonas)
		--Insertar cotizaciones
		DECLARE _cursor CURSOR FOR 
		SELECT Object_ID FROM #JSONZonas
		WHERE 
		Object_ID IS NOT NULL
		AND ValueType = 'object' 
		ORDER BY Object_ID

		OPEN _cursor 
		FETCH NEXT FROM _cursor INTO @parent
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			SELECT  @idZona = REPLACE(StringValue,'"','')  FROM #JSONZonas
			WHERE 
				parent_ID = @parent
				AND NAME = 'id'
				AND Object_ID IS NULL
			INSERT INTO MemorandumZona(idMemorandum, idZona) values (@idMemorandum,@idZona)
			FETCH NEXT FROM _cursor INTO @parent
		END
		CLOSE _cursor
		DEALLOCATE _cursor
		DROP TABLE #JSONZonas
	END


	--2. EN CASO DE PERFILES

	IF (@notificaPerfil=1)
	BEGIN
		DECLARE @idPerfil NUMERIC(18,0)
		
		--CREAMOS TABLA TEMPORAL PARA EL JSON
		CREATE TABLE #JSONPerfiles(
			element_id numeric(18,0),
			secuenceNo numeric(18,0),
			parent_ID numeric(18,0),
			Object_ID numeric(18,0),
			NAME nvarchar(MAX),
			StringValue nvarchar(MAX),
			ValueType nvarchar(MAX)
		)
		--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
		INSERT INTO #JSONPerfiles
		SELECT * FROM parseJSON(@jsonPerfiles)
		--Insertar cotizaciones
		DECLARE _cursor CURSOR FOR 
		SELECT Object_ID FROM #JSONPerfiles
		WHERE 
		Object_ID IS NOT NULL
		AND ValueType = 'object' 
		ORDER BY Object_ID

		OPEN _cursor 
		FETCH NEXT FROM _cursor INTO @parent
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			SELECT @idPerfil = REPLACE(StringValue,'"','')  FROM #JSONPerfiles
			WHERE 
				parent_ID = @parent
				AND NAME = 'id'
				AND Object_ID IS NULL
			INSERT INTO MemorandumPerfil(idMemorandum, idPerfil) values (@idMemorandum,@idPerfil)
			FETCH NEXT FROM _cursor INTO @parent
		END
		CLOSE _cursor
		DEALLOCATE _cursor
		DROP TABLE #JSONPerfiles
	END


	--3. EN CASO DE NOTIFICAR USUARIOS

	IF (@notificaUsuario=1)
	BEGIN
		DECLARE @idUsuario NUMERIC(18,0)
		
		--CREAMOS TABLA TEMPORAL PARA EL JSON
		CREATE TABLE #JSONUsuarios(
			element_id numeric(18,0),
			secuenceNo numeric(18,0),
			parent_ID numeric(18,0),
			Object_ID numeric(18,0),
			NAME nvarchar(MAX),
			StringValue nvarchar(MAX),
			ValueType nvarchar(MAX)
		)
		--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
		INSERT INTO #JSONUsuarios
		SELECT * FROM parseJSON(@jsonUsuarios)
		--Insertar cotizaciones
		DECLARE _cursor CURSOR FOR 
		SELECT Object_ID FROM #JSONUsuarios
		WHERE 
		Object_ID IS NOT NULL
		AND ValueType = 'object' 
		ORDER BY Object_ID

		OPEN _cursor 
		FETCH NEXT FROM _cursor INTO @parent
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			SELECT @idUsuario = REPLACE(StringValue,'"','')  FROM #JSONUsuarios
			WHERE 
				parent_ID = @parent
				AND NAME = 'id'
				AND Object_ID IS NULL
			INSERT INTO MemorandumUsuario(idMemorandum, idUsuario) values (@idMemorandum,@idUsuario)
			FETCH NEXT FROM _cursor INTO @parent
		END
		CLOSE _cursor
		DEALLOCATE _cursor
		DROP TABLE #JSONUsuarios
	END

	--4. EN CASO DE EVIDENCIAS

	IF (@contieneEvidencias=1)
	BEGIN
		DECLARE @evidencia varchar(500)
		
		--CREAMOS TABLA TEMPORAL PARA EL JSON
		CREATE TABLE #JSONEvidencias(
			element_id numeric(18,0),
			secuenceNo numeric(18,0),
			parent_ID numeric(18,0),
			Object_ID numeric(18,0),
			NAME nvarchar(MAX),
			StringValue nvarchar(MAX),
			ValueType nvarchar(MAX)
		)
		--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
		INSERT INTO #JSONEvidencias
		SELECT * FROM parseJSON(@jsonEvidencias)
		--Insertar cotizaciones
		DECLARE _cursor CURSOR FOR 
		SELECT Object_ID FROM #JSONEvidencias
		WHERE 
		Object_ID IS NOT NULL
		AND ValueType = 'object' 
		ORDER BY Object_ID

		OPEN _cursor 
		FETCH NEXT FROM _cursor INTO @parent
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			SELECT @evidencia = REPLACE(StringValue,'"','')  FROM #JSONEvidencias
			WHERE 
				parent_ID = @parent
				AND NAME = 'evidencia'
				AND Object_ID IS NULL
			INSERT INTO MemorandumEvidencias( idMemorandum, evidencia) values (@idMemorandum,@evidencia)
			FETCH NEXT FROM _cursor INTO @parent
		END
		CLOSE _cursor
		DEALLOCATE _cursor
		DROP TABLE #JSONEvidencias
	END

	SELECT @idMemorandum idMemorandum

END
go

