-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- [Banorte].[UPD_FECHAPROMESAPAGO_PRUEBAS] 26, 1
-- =============================================

CREATE PROCEDURE [Banorte].[UPD_FECHAPROMESAPAGO_PRUEBAS]
	@idContratoOperacion int,
	@isProduction int 	 
AS
BEGIN
	DECLARE @dbBanorte NVARCHAR(100)

	DECLARE @dbProveedor NVARCHAR(100)

	DECLARE @facturasProveedor as TABLE ( idOrden int, numeroOrden nvarchar(200), numeroReclamo nvarchar(200), facturaProveedor nvarchar(max),
	 idCotizacion int, servidor nvarchar(100),  facturaCeros nvarchar(100))

	DECLARE @pedidosEntregados as TABLE ( idOrden int, pedidosEntregados int, totalPedidos int) 
	
	DECLARE @doctosTable as TABLE (valeInicial int, valeFinal int, factura int, entrega int, idCotizacion int, fechaEvidenciaCompleta date null, provisionado varchar(100), idOrden int)
	
	DECLARE @provisionBanorte AS TABLE (idProvision [int] IDENTITY(1,1), idOrden int, numeroOrden nvarchar(max),
	                                    numeroReclamo nvarchar(max), facturaBanorte nvarchar(max), fechaProvision nvarchar(20), 
										fechaPromesa date, contraRecibo nvarchar(200), fechaContraRecibo date, fechaFactura nvarchar(20)) 	
	
	DECLARE @cuentasPorPagar AS TABLE (idCuenta [int] IDENTITY(1,1) , idOrden int, numeroOrden nvarchar(max), numeroReclamo nvarchar(max), 
	facturaBanorte nvarchar(max), fechaProvision nvarchar(20), fechaPromesa date, facturaProveedor nvarchar(max), servidor nvarchar(100), 
	comentario nvarchar(max), tablaProveedor nvarchar(100), facturasinCeros nvarchar(max))	

	IF(@isProduction = 1)
	    BEGIN
		    SELECT @dbBanorte= SERVER+'.'+DBProduccion
			FROM ASEPROT.dbo.ContratoOperacionFacturacion 
			WHERE idContratoOperacion =  @idContratoOperacion			
		END
	ELSE
		BEGIN
	        SELECT @dbBanorte=DB
			FROM ASEPROT.dbo.ContratoOperacionFacturacion
			WHERE idContratoOperacion = @idContratoOperacion							
		END

	insert into @facturasProveedor
		select O.idOrden, O.numeroOrden, S.numeroReclamo, 
		(SELECT ASEPROT.[dbo].[SEL_FACBYPEDIDOZEROS_FN](PREF.pre_pedidobpro,M.idMarca, PREF.pre_idcliente)), C.idCotizacion, 
		( case when M.server ='192.168.20.71' or M.server ='192.168.20.3'  then '' else '['+ M.server + '].' end) + M.dbCon_Car,
		/*SUBSTRING(FC.numFactura, 0, PATINDEX('%[0-9]%', FC.numFactura)) +
        REPLICATE('0', ((11-PATINDEX('%[0-9]%', FC.numFactura)) - LEN(SUBSTRING(FC.numFactura, PATINDEX('%[0-9]%', FC.numFactura), len(FC.numFactura)-PATINDEX('%[0-9]%', FC.numFactura))))) + SUBSTRING(FC.numFactura, PATINDEX('%[0-9]%', FC.numFactura), len(FC.numFactura)-PATINDEX('%[0-9]%', FC.numFactura)+1)	*/		
		(SELECT ASEPROT.[dbo].[SEL_FACBYPEDIDO_FN](PREF.pre_pedidobpro, M.idMarca, PREF.pre_idcliente))
	from ASEPROT.dbo.Ordenes O
	inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
	--inner join ASEPROT.DBO.facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
	inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden and SOC.idCotizacionSISCO= C.idCotizacion
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
	left join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PREF on PREF.pre_idcotizacion = SOC.idCotizacion
	inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
	inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = U.marca
	where  O.idContratoOperacion=@idContratoOperacion --and O.idOrden = 80493 --and U.marca  not in (16, 17,20, 21,19) --Mitsubishi,Toyota, Mazda, Renault, BMW
	order by O.idOrden				
		
	insert into @pedidosEntregados
		select O.idOrden, SUM(CASE WHEN PedEnt.tipoEntrega = 3 or PedEnt.tipoEntrega = 4 THEN 1 ELSE 0 END), COUNT(*)
	from ASEPROT.dbo.Ordenes O				
	inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden --and SOC.idCotizacionSISCO= C.idCotizacion
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
	inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
	inner JOIN [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PR ON SOC.idCotizacion = PR.pre_idcotizacion and PR.spe_idsituacionpedido not in (6, 1)
	LEFT JOIN PortalDespacho.dbo.PedidoEntrega PedEnt ON PR.pre_pedidobpro = PedEnt.pre_pedidobpro and PedEnt.idMarca = U.marca --and PR.spe_idsituacionpedido not in (6, 1)				
	where  O.idContratoOperacion=@idContratoOperacion --and O.idOrden = 80493
	group by O.idOrden
	
	insert into @doctosTable
	select 
		ISNULL((select top 1 1 from aseprot..evidencias  where idordenservicio=FP.idOrden and descripcionEvidencia='ValeInicial'),0) valeInicial,
		ISNULL((select top 1 1 from aseprot..evidencias  where idordenservicio=FP.idOrden and descripcionEvidencia='ValeFinal'),0) valeFinal,
		ISNULL((select top 1 1 from aseprot..facturaCotizacion  where idCotizacion = FP.idCotizacion),0) factura,
		ISNULL((select top 1 1 from aseprot..evidencias  where idCotizacion=FP.idCotizacion and descripcionEvidencia like'Ev%'),0) entrega,
		FP.idCotizacion,
		(select MAX(fechaInicial) from aseprot..HistorialEstatusOrden where idOrden = FP.idOrden and idEstatusOrden = 8) fechaEvidenciaCompleta,
		(CASE WHEN PE.pedidosEntregados = 0 THEN 'Pendiente Entrega' ELSE 
			CASE WHEN PE.totalPedidos > PE.pedidosEntregados THEN 'Entrega Parcial' ELSE 'Entrega Total' END END) provisionado,
		FP.idOrden
	from @facturasProveedor FP
	inner join @pedidosEntregados PE on PE.idOrden = FP.idOrden
	where FP.facturaCeros is not null
	
	insert into @provisionBanorte
		select distinct O.idOrden, O.numeroOrden, S.numeroReclamo, AC.COP_IDDOCTO,
		convert(datetime, C.fechaContrarecibo, 103),
		dateadd(day,30,convert(datetime, C.fechaContrarecibo, 103)) as fechaPromesa, 
		C.numeroContraRecibo, convert(datetime, C.fechaContrarecibo, 103), case when CC.CCP_FECHADOCTO is null then CC1.CCP_FECHADOCTO else CC.CCP_FECHADOCTO end
	from ASEPROT.dbo.Ordenes O
	left join [192.168.20.29].[GAAutoExpressBanorte].dbo.ADE_COPADE AC on O.numeroOrden = AC.COP_ORDENGLOBAL COLLATE Modern_Spanish_CI_AS
	--left join [GAAutoExpressBanorte].dbo.ADE_COPADE AC on O.numeroOrden = AC.COP_ORDENGLOBAL COLLATE Modern_Spanish_CI_AS
	left join [192.168.20.29].[GAAutoExpressBanorte].dbo.[Con_Car012018] CC on AC.COP_IDDOCTO = CC.CCP_IDDOCTO
	left join [192.168.20.29].[GAAutoExpressBanorte].dbo.[Con_Car012019] CC1 on AC.COP_IDDOCTO = CC1.CCP_IDDOCTO
	inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
	left join ASEPROT.dbo.DatosCopade D on D.numeroCopade = O.numeroOrden
	left join [ASEPROT].[dbo].[ContrareciboDatosCopade] CDC on CDC.idDatosCopade = D.idDatosCopade
	left join [ASEPROT].[dbo].[Contrarecibo] C on C.idContrarecibo =CDC.idContrarecibo
	where O.idContratoOperacion=@idContratoOperacion --and O.idOrden = 80493 order by O.numeroOrden

	insert into @cuentasPorPagar  	
		select  FP.idOrden, FP.numeroOrden, FP.numeroReclamo, PB.facturaBanorte, PB.fechaProvision, PB.fechaPromesa, 
		FP.facturaCeros, FP.servidor,
		case when FP.facturaCeros ='' then '' else 'Factura Agencia: '+ FP.facturaCeros end
		+'; Siniestro ' + FP.numeroReclamo  + ' Orden ' + FP.numeroOrden + ' «SISRE: ' + 
		cast(DT.valeInicial + DT.valeFinal + DT.factura + DT.entrega as varchar) + '/4 Documentos' 
		+ case when (DT.valeInicial + DT.valeFinal + DT.factura + DT.entrega) = 4 then '' else '. Documentos faltantes: ' end
		+ SUBSTRING((case when DT.valeInicial = 1 then '' else ' Vale Inicial,' end + 
		           case when DT.valeFinal = 1 then '' else ' Vale Final,' end + 
				   case when DT.factura = 1 then '' else ' Factura,' end + 
				   case when DT.entrega = 1 then '' else ' Entrega,' end), 0, 
				   len((case when DT.valeInicial = 1 then '' else ' Vale Inicial,' end + 
				   case when DT.valeFinal = 1 then '' else ' Vale Final,' end + 
				   case when DT.factura = 1 then '' else ' Factura,' end + 
				   case when DT.entrega = 1 then '' else ' Entrega,' end))) 
		+ (CASE WHEN DT.fechaEvidenciaCompleta is not null THEN '; Fecha Evidencia Completada: ' + 
		CONVERT(VARCHAR(10), DT.fechaEvidenciaCompleta, 103) ELSE '' END) + 
		'; Factura Banorte: '+ ISNULL(PB.facturaBanorte, 'NO Provisionada') + 
		case when  PB.fechaFactura is null  then '' else ', Fecha: '+ convert(nvarchar(MAX), PB.fechaFactura, 103)  end
		+'; ' + DT.provisionado +
		(case when PB.contraRecibo is not null 
		then '; Contra Recibo: ' + PB.contraRecibo  + ', Fecha: ' + convert(nvarchar(MAX), fechaContraRecibo, 103)		
		else '' end ) + '»'
		, '', FP.facturaProveedor
	from @doctosTable DT
	inner join @facturasProveedor FP on FP.idOrden = DT.idOrden  and FP.idCotizacion = DT.idCotizacion
	left join @provisionBanorte PB on PB.idOrden = FP.idOrden
	group by FP.numeroOrden, FP.idCotizacion, FP.numeroReclamo , DT.valeInicial, DT.valeFinal, DT.factura, DT.entrega, 
		     DT.fechaEvidenciaCompleta, DT.provisionado, PB.facturaBanorte,  FP.idOrden, FP.servidor, FP.facturaCeros, 
			 PB.fechaProvision, PB.fechaPromesa, FP.facturaProveedor, PB.contraRecibo, PB.fechaContraRecibo , PB.fechaFactura
	order by FP.numeroOrden
		
	print ('DOC')
	select * from @doctosTable
	print ('PROVEEDOR')
	select * from @facturasProveedor
	print ('BANORTE')
	select * from @provisionBanorte
	print ('TODO')
	select * from @cuentasPorPagar order by numeroReclamo

	
--Declare @id int,
--        @count int

--Set @id=1
--select @count=count(*)from @provisionBanorte 
--declare @updateAutoExpressBan nvarchar(max)=''
--DECLARE @result nvarchar(100)
--DECLARE @facturaBanorte nvarchar(100)
--DECLARE @tablaConCar nvarchar(100)
--DECLARE @observacion nvarchar(max)
--DECLARE @fechaPromesa nvarchar(10)
--while @id<=@count
--begin	
--	select @updateAutoExpressBan = ''
--	select @facturaBanorte= facturaBanorte, @fechaPromesa = CONVERT(VARCHAR(15), fechaPromesa, 103) from @provisionBanorte where idProvision=@id

--	if( @facturaBanorte is not null or @facturaBanorte <> '')
--	begin 
--		EXECUTE ASEPROT.[Banorte].[GET_ANIO_FAC] @isProduction,@idContratoOperacion,@facturaBanorte, @result output	
--		if(@result<>0)
--		BEGIN
--			SELECT @tablaConCar = tabla FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@result			
--			select @observacion = '' + 'Siniestro ' + numeroReclamo + ' Orden ' + numeroOrden + 		
--				(case when contraRecibo is not null then '; Contra Recibo: ' +
--				contraRecibo  + ', Fecha: ' + convert(nvarchar(MAX), fechaContraRecibo, 103) 
--				else '' end ) from  @provisionBanorte where idProvision=@id
--				if(@fechaPromesa is not null or @fechaPromesa <> '')
--				begin 
--					select @updateAutoExpressBan = 'update '+@dbBanorte+'.dbo.'+@tablaConCar+'
--					set CCP_OBSGEN='''+@observacion+''', CCP_FECHPROMPAG='''+@fechaPromesa+
--					''' where CCP_TIPODOCTO = ''FAC'' and CCP_IDDOCTO='''+@facturaBanorte+''''
--				end 				
--				else 
--				begin 
--					select @updateAutoExpressBan = 'update '+@dbBanorte+'.dbo.'+@tablaConCar+'
--					set CCP_OBSGEN='''+@observacion+''' where CCP_TIPODOCTO = ''FAC'' and CCP_IDDOCTO='''+@facturaBanorte+''''
--				end 
--		END
--	end
--	print @updateAutoExpressBan
--	execute (@updateAutoExpressBan)
--	select @id=@id+1	
--end 

-----------------------------------ACTUALIZAR CUENTAS POR PAGAR -----------------
--Set @id=1
--select @count=count(*)from @cuentasPorPagar
--declare @update nvarchar(max) =''
--declare @updateBanorte nvarchar(max) =''
--declare @query nvarchar(max) =''
--declare @query2 nvarchar(max) =''
--declare @anio nvarchar(20) = '', @nuevaFactura nvarchar(100) =''

--declare @anioB nvarchar(20) = ''
--declare @resA bit=0;
--while @id<=@count
--begin	
--	select @anio='', @query='', @query2='', @nuevaFactura=''
--	if((select facturaProveedor from @cuentasPorPagar where idCuenta=@id) <>'')
--	begin
--	select @query = 'SELECT @anio=Vcc_AnNo FROM [192.168.20.29].[GAAutoExpressConcentra].[dbo].[VIS_CONCAR01] 
--		WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO = ''' +(select facturasinCeros from @cuentasPorPagar where idCuenta=@id) + ''''
	
--	EXEC SP_EXECUTESQL 
--        @Query  = @query
--      , @Params = N'@anio nvarchar(100) OUTPUT'
--      , @anio = @anio OUTPUT
--	print '1er consulta año'
--	print @query
--	print @anio
--	print '---1----'
--	if(@anio ='')
--	begin
--		select @query2 = 'SELECT top 1 @anio=Vcc_AnNo, @nuevaFactura=CCP_IDDOCTO FROM [192.168.20.29].[GAAutoExpressConcentra].[dbo].[VIS_CONCAR01] 
--		WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_OBSGEN like ''%'+(select facturaProveedor from @cuentasPorPagar where idCuenta=@id)+'%''
--		order by CCP_CONSCARTERA desc'		 	
--		EXEC SP_EXECUTESQL 
--			@Query  = @query2
--		  , @Params = N'@anio nvarchar(100) OUTPUT, @nuevaFactura nvarchar(100) OUTPUT'
--		  , @anio = @anio OUTPUT
--		  , @nuevaFactura = @nuevaFactura OUTPUT
--		print '2da consulta año'
--		print @query2
--		print @anio
--		print @nuevaFactura
--		if(@anio<>'')
--		begin
--			set @resA=1
--		end
--		else 
--			set @resA=0
--	end
--	else 
--		set @resA=1
	
--	if(@resA=1)
--	BEGIN
--		update @cuentasPorPagar set tablaProveedor = (select tabla FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio)
--		where idCuenta=@id
--		IF(@isProduction = 1)		
--				SELECT @dbProveedor=server+'.'+db FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio			
--		ELSE			
--			SELECT @dbProveedor=db FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio								

--		if((select servidor from @cuentasPorPagar where idCuenta=@id) is not null and (select tablaProveedor from @cuentasPorPagar where idCuenta=@id) is not null and (select fechaPromesa from @cuentasPorPagar where idCuenta=@id) is not null)
--			begin		
--				select @update =  '  update ' + (select servidor from @cuentasPorPagar where idCuenta=@id) + + '.dbo.' + (select tablaProveedor from @cuentasPorPagar where idCuenta=@id ) + 
--				' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + ''', CCP_FECHPROMPAG= ''' +
--				CONVERT(VARCHAR(15), (select fechaPromesa from @cuentasPorPagar where idCuenta=@id), 103)  +
--				''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO = ''' + (select facturaProveedor from @cuentasPorPagar where idCuenta=@id) + '''  '	

--				select @updateBanorte ='  update '+@dbProveedor+'.dbo.'+(select tablaProveedor from @cuentasPorPagar where idCuenta=@id) +
--				' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + ''', CCP_FECHPROMPAG= ''' +
--				CONVERT(VARCHAR(15), (select fechaPromesa from @cuentasPorPagar where idCuenta=@id), 103)  +
--				''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO = ''' + case when @nuevaFactura = '' then 
--				 (select facturasinCeros from @cuentasPorPagar where idCuenta=@id) else @nuevaFactura end + ''' '	
--			end
--		else
--			begin 		
--				if((select servidor from @cuentasPorPagar where idCuenta=@id) is not null and (select tablaProveedor from @cuentasPorPagar where idCuenta=@id) is not null)		
--					begin
--						select @update = '  update ' + (select servidor from @cuentasPorPagar where idCuenta=@id) + '.dbo.' + (select tablaProveedor from @cuentasPorPagar where idCuenta=@id )+
--						 ' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + 
--						 ''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO = ''' + (select facturaProveedor from @cuentasPorPagar where idCuenta=@id) + '''  '	

--						select @updateBanorte = '  update  '+@dbProveedor+'.dbo.'+(select tablaProveedor from @cuentasPorPagar where idCuenta=@id) +
--						 ' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + 
--						 ''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO = ''' + case when @nuevaFactura = '' then 
--						(select facturasinCeros from @cuentasPorPagar where idCuenta=@id) else @nuevaFactura end + '''  '	
--					end 
--			end								
--	END
--	end
--	print @update
--	print @updateBanorte
--	execute (@update)
--	execute(@updateBanorte)
--	select @id=@id+1	
--	end

	select * from @cuentasPorPagar
	--select * from @provisionBanorte

END
go

