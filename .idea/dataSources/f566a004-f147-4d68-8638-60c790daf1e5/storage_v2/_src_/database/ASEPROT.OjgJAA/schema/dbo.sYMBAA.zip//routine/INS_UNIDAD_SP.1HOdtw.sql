-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 22/05/2017
-- INS_UNIDAD_SP 'JL235826','3G1TA5CF0JL235826','Q15AT355',10,0,3,35,'PMX09299',0,'2008','Freightliner CL-120 MBE4000',1
-- =============================================
 CREATE PROCEDURE [dbo].[INS_UNIDAD_SP]
	@numeroEconomico NVARCHAR(50),
	@vin NVARCHAR(50),
	@gps NVARCHAR(50),
	@idTipoUnidad INT,
	@sustituto INT,
	@idOperacion INT,
	@idCentroTrabajo NUMERIC(18, 0),
	@placas NVARCHAR(50),
	@idZona INT,
	@modelo NVARCHAR(10),
	@combustible NVARCHAR(50),
	@verificada INT, 
	@verGps INT = 0, --YJH,
	@idOrigenUnidad INT = 1,
	@contratoUnidad VARCHAR(30) = NULL,
	@perdidaTotal BIT = 0
AS
BEGIN
	DECLARE @idUnidad INT
IF NOT EXISTS(SELECT numeroEconomico FROM Unidades WHERE idOperacion = @idOperacion AND numeroEconomico = @numeroEconomico)
	BEGIN
		INSERT INTO [Unidades] ([numeroEconomico]
           ,[vin]
           ,[gps]
           ,[idTipoUnidad]
           ,[sustituto]
           ,[idOperacion]
           ,[idCentroTrabajo]
           ,[placas]
           ,[idZona]
           ,[modelo]
           ,[combustible]
           ,[verificada]
		   ,[verGPS]
		   ,idOrigenUnidad
		   ,contratoUnidad
		   ,perdidaTotal
		   )
		VALUES(@numeroEconomico, 
			   @vin,
			   @gps,
			   @idTipoUnidad,
			   @sustituto,
			   @idOperacion,
			   @idCentroTrabajo,
			   @placas,
			   @idZona,
			   @modelo,
			   @combustible,
			   @verificada,
			   @verGPS,
			   @idOrigenUnidad,
			   CASE WHEN @contratoUnidad= '0' THEN '' ELSE @contratoUnidad END,
			   @perdidaTotal
			   )--YJH
			   --NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
		SET @idUnidad = @@IDENTITY 
		SELECT @idUnidad AS idUnidad

	END
	ELSE
	BEGIN
		SELECT 0 AS idUnidad
	END

END
go

