
-- =============================================
-- Description:	Busca talleres
-- =============================================
-- [SEL_TALLERES_SP] 538,75,NULL,'','',241,1
CREATE PROCEDURE [dbo].[SEL_TALLERES_SP] 
	 @idUsuario  NUMERIC(18,0) = 509
	,@idContratoOperacion NUMERIC(18,0) = 3
	,@idZona INT = null
	,@nombreTaller NVARCHAR(300) = ''
	,@servicios NVARCHAR(100) = ''
	,@idTipoUnidad INT = 67
	,@seguro		INT = 0
AS
BEGIN
	
	DECLARE @query NVARCHAR(MAX)=''	
	------Obtengo la ip del servidor donde se encuntra la BD Partidas
	
	-----------------------------------------------------------------
	------Obtengo las zonas que debo buscar en el SP si traigo datos
	DECLARE @esNumero INT = 0, @cadenaZonas NVARCHAR(100) = ''
	SET @esNumero = (SELECT ISNUMERIC(@idZona)) 
	IF(@esNumero = 1)
		BEGIN 
			DECLARE @numeroZonas INT = 0, @contador INT = 1, @idZonaTabla INT = 0, @queryNomZona NVARCHAR(MAX) = '', @queryIdZona NVARCHAR(MAX) = ''
			SET @queryNomZona = '  SELECT		COUNT(idZona) ' + char(13) + 
								'  FROM			.[Partidas].[dbo].[Zona] ' + char(13) + 
								'  WHERE		idZona = '+CONVERT(NVARCHAR(100),@idZona)+' OR idPadre = '+CONVERT(NVARCHAR(100),@idZona)+' ' + char(13) + 
								'' 
			DECLARE	@zonasTabla TABLE(numeroZonas INT);
			INSERT INTO @zonasTabla
			EXECUTE(@queryNomZona)
			SELECT @numeroZonas = numeroZonas FROM @zonasTabla
			SET @queryIdZona =  '  SELECT		idZona ' + char(13) + 
								'  FROM			.[Partidas].[dbo].[Zona] ' + char(13) + 
								'  WHERE		idZona = '+CONVERT(NVARCHAR(100),@idZona)+' OR idPadre = '+CONVERT(NVARCHAR(100),@idZona)+' ' + char(13) + 
								'' 
			DECLARE	@zonas TABLE(	ID INT IDENTITY(1,1)
									,idZona	INT		
								);
			INSERT INTO @zonas
			EXECUTE (@queryIdZona)
			
			--select * from @zonas
			WHILE (@contador <= @numeroZonas)
				BEGIN
					SELECT @idZona = idZona FROM @zonas WHERE ID = @contador
					SET @cadenaZonas = CONVERT(NVARCHAR(100),@idZona) + ',' + @cadenaZonas
					SET @contador = @contador + 1
					PRINT @contador
				END
			  PRINT @cadenaZonas
			  SET @cadenaZonas = LEFT(@cadenaZonas, LEN(@cadenaZonas) - 1)
			  PRINT @cadenaZonas 
		END
	ELSE
		BEGIN
			SET @cadenaZonas = ''
		END	


	declare @idRol numeric(18,0), @idOperacion numeric(18,0)
	
	SELECT      @idRol = idCatalogoRol, @idOperacion = idOperacion
	FROM        Usuarios u 
	inner join ContratoOperacionUsuario COU on COU.idUsuario = U.idUsuario
	inner join ContratoOperacion CO on COU.idContratoOperacion = CO.idContratoOperacion
	WHERE		u.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	----------------------------------------------------------------
	--concatenacion de zonas asignadas
	DECLARE @idCOU numeric(18,0)
	select @idCOU = COU.idContratoOperacionUsuario from Usuarios U 
	inner join ContratoOperacionUsuario COU on COU.idUsuario = U.idUsuario
	where U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	declare @zonasAsignadas table (idZona int)

	insert into @zonasAsignadas
	select idZona from ContratoOperacionUsuarioZona COUZ
	where COUZ.idContratoOperacionUsuario = @idCOU
	
	declare @zonaSelect int 
	declare @stringZonasAsignadas varchar(max) = ' '

	DECLARE zonas_cursor CURSOR FOR  
	SELECT idZona
	from @zonasAsignadas

	OPEN zonas_cursor;  
 
	FETCH NEXT FROM zonas_cursor into @zonaSelect;  

	WHILE @@FETCH_STATUS = 0  
	BEGIN 		
		set @stringZonasAsignadas = @stringZonasAsignadas + convert(varchar(max),@zonaSelect) + ','
		
		
		FETCH NEXT FROM zonas_cursor into @zonaSelect;   
	END  

	CLOSE zonas_cursor;  
	DEALLOCATE zonas_cursor;  	

			declare @longitudDos  int = (len(@stringZonasAsignadas) -1)
			declare @cantZonas int = (select count(*) from @zonasAsignadas)

			if @cantZonas > 0
			begin
				SET @stringZonasAsignadas = SUBSTRING (@stringZonasAsignadas, 1, @longitudDos)
				print 'Zonas Asignadas'
				print @stringZonasAsignadas
			end

	declare @consultaPrincipal table(idProveedor int, nombreComercial varchar(max), matriz varchar(max), idTaller int, razonSocial varchar(max), RFC varchar(max), direccion varchar(max), especialidad varchar(max))--, partidas VARCHAR(500)

		SET @query = 'SELECT	DISTINCT P.idProveedor AS idProveedor' + char(13) + 
			'		,P.nombreComercial' + char(13) + 
			'		,PENC.razonSocial AS matriz' + char(13) + 
			'		,P.idProveedor idTaller' + char(13) + 
			'		,P.razonSocial' + char(13) + 
			'		,P.RFC ' + char(13) + 
			--'		,especialidad' + char(13) + 
			--'		,Z.idZona AS idZona' + char(13) +
			'		,P.direccion' + char(13) + 
			'		--,(SELECT [dbo].[SEL_ESPECIALIDADES_TALLER_FN](PE.idProveedor)) AS especialidad '+ char(13) +
			'       ,'''' AS especialidad '+ char(13) +
			--'		,[dbo].[concatena_partidas_fn](P.idProveedor) '+ char(13) +
			'FROM	[dbo].[ContratoOperacion] CO' + char(13) +  
			'		INNER JOIN .[Partidas].[dbo].[ContratoProveedor] CPRO ON CPRO.idContrato = CO.idContrato' + char(13) +
			'		INNER JOIN .[Partidas].[dbo].[Proveedor] P ON P.idProveedor = CPRO.idProveedor' + char(13) +
			'		INNER JOIN .[Partidas].[dbo].[ProveedorEncabezado] PENC ON P.idProveedorEncabezado = PENC.idProveedorEncabezado' + char(13) +
			'		 JOIN .[Partidas].[dbo].Unidad U ON U.idUnidad = ' + convert(varchar(max),@idTipoUnidad ) + char(13) +
			'        JOIN [Partidas].[dbo].ProveedorTipoCombustible tc on tc.idTipoCombustible = u.idTipoCombustible and tc.idProveedor = P.idProveedor '  + char(13) +
			'		LEFT JOIN .[Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = P.idProveedor' + char(13) +
			'		LEFT JOIN .[Partidas].[dbo].[Especialidad] E ON E.idEspecialidad = PE.idEspecialidad' + char(13) +
			'		INNER JOIN .[Partidas].[dbo].[ContratoProveedorZona] CPROZ ON CPROZ.idContratoProveedor = CPRO.idContratoProveedor' + char(13) +
			'		INNER JOIN .[Partidas].[dbo].[Zona] Z ON Z.idZona = CPROZ.idZona' + char(13) +
			'		INNER JOIN .[Partidas].[dbo].[NivelZona] NZ ON Z.idNivelZona = NZ.idNivelZona' + char(13) +
			'		WHERE	idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+ char(13) + 
			'		AND P.estatus= 1 ' +
			'		AND P.idProveedor NOT IN (SELECT PGP.IdProveedor FROM ParametrosGeneralProveedor PGP WHERE IdParametroGeneral=10 AND Estatus=1) ' + char(13) + 
			'		AND CAST(P.idProveedor AS VARCHAR(10))+''|''+CAST(CO.IdOperacion AS VARCHAR(10)) NOT IN (SELECT CAST(IdProveedor AS VARCHAR(10))+''|''+CAST(IdOperacion AS VARCHAR(10)) 
					FROM ParametrosGeneralOperacionProveedor WHERE Estatus=1 AND IdParametroGeneral=11) ' + char(13) + 		
			--'		AND Z.idZona'+ (CASE WHEN @cadenaZonas = '' THEN  ' = Z.idZona' ELSE  ' IN ('+@cadenaZonas+')' END ) + char(13) + 
			--'		AND not Z.idPadre = 0 ' + char(13) +
			'		--AND E.idEspecialidad'+ (CASE WHEN @servicios = '' THEN  ' = E.idEspecialidad' ELSE  ' IN ('+@servicios+')' END ) + char(13) +
			'		'+ (CASE WHEN @nombreTaller = '' THEN  '' ELSE  'AND P.razonSocial LIKE ''%'+@nombreTaller+'%''' END ) + char(13) + 
			'' 

			IF(@seguro = 1)
			BEGIN
				SET @query = @query + 'UNION  SELECT	DISTINCT P.idProveedor AS idProveedor' + char(13) + 
				'		,P.nombreComercial' + char(13) + 
				'		,PENC.razonSocial AS matriz' + char(13) + 
				'		,P.idProveedor idTaller' + char(13) + 
				'		,P.razonSocial' + char(13) + 
				'		,P.RFC ' + char(13) + 
				'		,P.direccion' + char(13) + 
				'		--,(SELECT [dbo].[SEL_ESPECIALIDADES_TALLER_FN](PE.idProveedor)) AS especialidad '+ char(13) +
				'       ,'''' AS especialidad '+ char(13) +
				'FROM	[dbo].[ContratoOperacion] CO' + char(13) +  
				'		INNER JOIN .[Partidas].[dbo].[ContratoProveedor] CPRO ON CPRO.idContrato = CO.idContrato' + char(13) +
				'		INNER JOIN .[Partidas].[dbo].[Proveedor] P ON P.idProveedor = CPRO.idProveedor' + char(13) +
				'		INNER JOIN .[Partidas].[dbo].[ProveedorEncabezado] PENC ON P.idProveedorEncabezado = PENC.idProveedorEncabezado' + char(13) +
				'		 JOIN .[Partidas].[dbo].Unidad U ON U.idUnidad = ' + convert(varchar(max),@idTipoUnidad ) + char(13) +
				'        JOIN [Partidas].[dbo].ProveedorTipoCombustible tc on tc.idTipoCombustible = u.idTipoCombustible and tc.idProveedor = P.idProveedor '  + char(13) +
				'		LEFT JOIN .[Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = P.idProveedor' + char(13) +
				'		LEFT JOIN .[Partidas].[dbo].[Especialidad] E ON E.idEspecialidad = PE.idEspecialidad' + char(13) +
				'		WHERE	idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+ char(13) + 
				'		AND P.estatus= 1 ' +
				'		AND P.idProveedorEncabezado IN (SELECT PGP.IdProveedor FROM ParametrosGeneralProveedor PGP WHERE IdParametroGeneral=26 AND Estatus=1) ' + char(13) + 
				'		--AND E.idEspecialidad'+ (CASE WHEN @servicios = '' THEN  ' = E.idEspecialidad' ELSE  ' IN ('+@servicios+')' END ) + char(13) +
				'		'+ (CASE WHEN @nombreTaller = '' THEN  '' ELSE  'AND P.razonSocial LIKE ''%'+@nombreTaller+'%''' END ) + char(13) + 
				'' 
			END 

	declare @filtroZonas varchar(max) = ''
	declare @filtroProveedores varchar(max) = ''
	declare	@filtroSeguro varchar (max) = ''

	IF(@seguro = 0)
		BEGIN
			SET @filtroSeguro = '		AND P.idProveedorEncabezado NOT IN (SELECT idProveedor FROM SISCOV3.proveedor.proveedorSeguro WHERE activo = 1)' 
		END

	if @idRol <> 4
	begin
		if @idRol <> 2
		begin
			if @idRol <> 9
				BEGIN
					--select * from @consultaPrincipal
					--where idZona in (select idZona from @zonasAsignadas)
					--if (@longitudDos > 0)
					--begin
					set @filtroZonas = '	AND Z.idZona in ('+ @stringZonasAsignadas+ ')' + char(13)
					--end
				END
		end
		--else
		--begin
		--	--select * from @consultaPrincipal

		--end
	end
	else
	begin
		--select * from @consultaPrincipal
		--where idProveedor in (select idProveedor from @tablaProveedoresAsignados)
		set @filtroProveedores = '	AND P.idProveedor IN (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idOperacion)+'))'+ char(13)
	end

	declare @QueryString varchar(max) = @query + @filtroZonas + @filtroProveedores + @filtroSeguro

	print @QueryString

	insert into @consultaPrincipal
	EXECUTE (@QueryString)

	select * from @consultaPrincipal
	
END

go

grant execute, view definition on SEL_TALLERES_SP to DevOps
go

