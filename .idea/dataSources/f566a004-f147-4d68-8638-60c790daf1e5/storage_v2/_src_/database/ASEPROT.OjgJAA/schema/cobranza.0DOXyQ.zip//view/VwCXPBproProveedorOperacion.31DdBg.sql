
CREATE VIEW [cobranza].[VwCXPBproProveedorOperacion]
AS
	SELECT   
Nombre AS PROVEEDOR,  
rfc AS RFCPROVEEDOR,
SUM(IMPORTE) AS IMPORTE,  
(SUM(IMPORTE) - SUM(SALDO)) AS IMPORTEPAGADO,
SUM(SALDO) AS SALDO, 
'PROCESO-COBRANZA' AS ESTATUS,
descripcion AS OPERACION,
idContratoOperacion 
FROM  
(  
select                
rtrim(ltrim(PER_PATERNO + ' ' + PER_MATERNO + ' ' + PER_NOMRAZON)) as Nombre,       
pp.RFC,         
'IMPORTE' = CASE CARTERA.PAR_IDMODULO                                             
when 'CXP'                                             
then ccp_abono-ccp_cargo                                             
else ccp_cargo-ccp_abono                                            
end,                  
'SALDO' = CASE CARTERA.PAR_IDMODULO                                            
when 'CXP'                                            
then ccp_abono-ccp_cargo + (Select isnull(sum(CCP_ABONO-CCP_CARGO),0)                                         
from [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 as MOVIMIENTO  
WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO       
--from [BPro].[vWVIS_CONCAR01_GAAutoExpress] as MOVIMIENTO  WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                     
AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                     
AND MOVIMIENTO.CCP_DOCORI<>'S')                                            
else ccp_CARGO-ccp_ABONO+(Select isnull(sum(CCP_CARGO-CCP_ABONO),0)                     
from [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO       
--from [BPro].[vWVIS_CONCAR01_GAAutoExpress] as MOVIMIENTO WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                
AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA AND  MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                
AND MOVIMIENTO.CCP_DOCORI<>'S')                                
end,
PC.descripcion, 
CO.idContratoOperacion 
--       ,     
--     ADEO.OTE_FACTURACOMPRA,   
--ADEO.OTE_IDPROVEEDOR   
FROM [192.168.20.29].[GAAutoExpress].[dbo].VIS_CONCAR01 AS DOCUMENTO   
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as CARTERA ON CCP_CARTERA = CARTERA.PAR_IDENPARA AND CARTERA.PAR_TIPOPARA='CARTERA' and CARTERA.PAR_IDENPARA = 'AE57'  
INNER JOIN [192.168.20.29].[GA_Corporativa].[dbo].PER_PERSONAS ON CCP_IDPERSONA = PER_IDPERSONA  
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].pnc_parametr as TIMO ON CCP_TIPODOCTO = TIMO.PAR_IDENPARA AND TIMO.PAR_TIPOPARA = 'TIMO'   
LEFT OUTER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_VTAFI ON VTE_DOCTO = CCP_IDDOCTO AND VTE_CONSECUTIVO = CCP_CONSPOL AND VTE_STATUS <> 'C'
INNER JOIN [192.168.20.29].[GAAutoExpress].[dbo].ADE_ORDSERENC ADEO  ON CCP_IDDOCTO = ADEO.OTE_FACTURACOMPRA AND CCP_IDPERSONA = ADEO.OTE_IDPROVEEDOR   
INNER JOIN Cotizaciones C ON C.numeroCotizacion = ADEO.OTE_ORDENPEMEX COLLATE Modern_Spanish_CI_AS  
INNER JOIN facturaCotizacion FC ON FC.idCotizacion = C.idCotizacion  AND C.idEstatusCotizacion = 3
INNER JOIN Partidas..Proveedor PP ON PP.idProveedor = C.idTaller  
INNER JOIN Ordenes O ON C.idOrden = O.idOrden AND O.idEstatusOrden IN(5,6,7,8) --AND O.idContratoOperacion = 37  
INNER JOIN CONTRATOOPERACION CO ON CO.IDCONTRATOOPERACION = O.IDCONTRATOOPERACION AND O.idContratoOperacion not in(8)
INNER JOIN Partidas..Contrato PC ON PC.IDCONTRATO = CO.IDCONTRATO 
WHERE CCP_DOCORI = 'S'  and CCP_TIPODOCTO = 'FAC'  
) AS A GROUP BY A.Nombre, A.descripcion, A.idContratoOperacion, A.rfc

go

