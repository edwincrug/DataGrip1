
-- ==========================================================================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 16/05/2017
-- ==========================================================================================
-- --[dbo].[SEL_NIVEL_ZONAS_CLIENTE_SP] 3
CREATE PROC [dbo].[SEL_NIVEL_ZONAS_CLIENTE_SP]
	@idContratoOperacion numeric(18,0)
AS
BEGIN
	declare @bdPartidas varchar(max) = (select nombreBD from [dbo].[Parametros] where [idParametros] = 1)
	declare @server varchar(max) = (select [ipServidor] from [dbo].[Parametros] where [idParametros] = 1)
	declare @consulta varchar(max) = ''
	--SET @server = '['+@server + ']'
	
	SET @consulta = 'SELECT NivZo.idNivelZona' + char(13) + 
					'FROM  .Partidas.dbo.Contrato AS Con INNER JOIN' + char(13) + 
					'	   .Partidas.dbo.Licitacion AS Li ON Con.idLicitacion = Li.idLicitacion INNER JOIN' + char(13) + 
					'	   .Partidas.dbo.Cliente AS Cli ON Li.idCliente = Cli.idCliente INNER JOIN' + char(13) + 
					'	   .Partidas.dbo.NivelZona AS NivZo ON Cli.idCliente = NivZo.idCliente' + char(13) + 
					'WHERE  Con.idContrato IN (SELECT ConOp.idContrato' + char(13) + 
					'						FROM ContratoOperacion AS ConOp' + char(13) + 
					'						WHERE ConOp.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+')' + char(13) + 
					''
	print @consulta
	EXECUTE (@consulta)

END

go

