

/*
	Fecha			Autor			Descripción
	27-Jun-2018		José Etmanuel	Se crea el SP que regresa las promociones de un usuario
	
	[Banorte].[GET_PROMOCIONES_CANJEADAS] 747
*/

CREATE PROCEDURE [Banorte].[GET_PROMOCIONES_CANJEADAS] 
 @idUsuario INT
AS
BEGIN

	SELECT distinct
		PC.idPromocion, 
		P.nombrePromocion as descripcion , 
		T.Nombre as nombreTienda, 
		fechaTermino as fechaVigencia,
		fechaCanjeo,
		T.Img as logo

	FROM [Banorte].[PromocionesCodigosDet] AS PCD
	INNER JOIN [PromocionesCodigos] AS PC on PC.Codigo = PCD.Codigo 
	INNER JOIN [Banorte].[Promociones] as P on P.id = PC.IdPromocion
	INNER JOIN [Banorte].[PromocionesSuc] AS S on S.[idPromociones] = P.id
	INNER JOIN [Banorte].[Patrocinador] as T on T.[Id] = S.PatrocinadorId
	WHERE PC.IdUsuario = @idUsuario
	
END

go

grant execute, view definition on Banorte.GET_PROMOCIONES_CANJEADAS to DevOps
go

