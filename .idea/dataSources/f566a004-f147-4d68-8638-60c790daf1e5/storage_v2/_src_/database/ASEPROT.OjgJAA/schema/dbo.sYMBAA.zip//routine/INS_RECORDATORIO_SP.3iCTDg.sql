--select * from Recordatorio

-- [INS_RECORDATORIO_SP] 'uno', '03/017/2017',5, 3,10

CREATE PROCEDURE [dbo].[INS_RECORDATORIO_SP]
  @texto NVARCHAR(1000),
  @fecha NVARCHAR(50),
  @idUsuario INT,
  @idContratoOperacion INT,
  @idRecordatorio INT = 0


AS
BEGIN

	IF @idRecordatorio > 0
		BEGIN
			
			UPDATE Recordatorio 
			SET
				texto = @texto,
				fecha = @fecha
			WHERE idRecordatorio = @idRecordatorio
			SELECT @idRecordatorio
			
		END
	ELSE
		BEGIN 
		 
		  INSERT INTO Recordatorio VALUES(@texto,@fecha,1,@idUsuario,@idContratoOperacion,GETDATE())
		  SELECT @@IDENTITY

		END
END

go

