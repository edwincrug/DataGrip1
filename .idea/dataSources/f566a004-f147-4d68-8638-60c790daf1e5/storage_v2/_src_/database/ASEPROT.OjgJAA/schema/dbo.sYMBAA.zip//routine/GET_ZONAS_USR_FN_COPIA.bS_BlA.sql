
--}SELECT * FROM [dbo].[GET_ZONAS_USR_FN_COPIA]('234,633,716,717,718,828,885,967,992,993,1478,1489,1526,1629,1955,1996')
CREATE FUNCTION [dbo].[GET_ZONAS_USR_FN_COPIA](@idContratoOperacionUsuario VARCHAR(MAX))

returns @zonasAsignadas  Table (idZona INT)

as 

begin

DECLARE @valores VARCHAR(1000)
	declare @idRol int
	select @idRol = idCatalogoRol from ContratoOperacionUsuario where idContratoOperacionUsuario in (SELECT Item FROM splitstring(@idContratoOperacionUsuario, ',') )
	--print @idRol
	--select * from ContratoOperacionUsuario  where idContratoOperacionUsuario in 

	if (@idRol = 1 or @idRol = 3)
		begin
			insert into @zonasAsignadas
			select idZona from ContratoOperacionUsuarioZona COUZ
			where COUZ.idContratoOperacionUsuario in (SELECT Item FROM splitstring(@idContratoOperacionUsuario, ',') )
			
		end
	else if (@idRol = 4)
		begin
			insert into @zonasAsignadas
			select distinct CPZ.idZona
			from ContratoOperacionUsuarioProveedor COUP
			inner join ContratoOperacionUsuario COU on COU.idContratoOperacionUsuario = COUP.idContratoOperacionUsuario
			inner join ContratoOperacion CO on CO.idContratoOperacion = COU.idContratoOperacion
			inner join Partidas..Contrato C on C.idContrato = CO.idContrato
			inner join Partidas..ContratoProveedor CP on CP.idContrato = C.idContrato and CP.idProveedor = COUP.idProveedor
			inner join Partidas..ContratoProveedorZona CPZ on CPZ.idContratoProveedor = CP.idContratoProveedor
			where COUP.idContratoOperacionUsuario in (SELECT Item FROM splitstring(@idContratoOperacionUsuario, ',') )

			
				

				
		end
	else if (@idRol = 2)
		begin
			insert into @zonasAsignadas
			select    distinct  idZona
			from ContratoOperacionUsuarioZona 
			where idContratoOperacionUsuarioZona  in (SELECT Item FROM splitstring(@idContratoOperacionUsuario, ',') )
			

		
		
		--select idZona from ContratoOperacionUsuarioZona where idContratoOperacionUsuarioZona  in (SELECT Item FROM splitstring('234,633,716,717,718,828,885,967,992,993,1478,1489,1526,1629,1955,1996', ',') )

		end

	return 

end
--USE [ASEPROT]
--GO
--/****** Object:  UserDefinedFunction [dbo].[GET_ZONAS_USR_FN_COPIA]    Script Date: 13/08/2018 04:24:08 p. m. ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO


----}SELECT * FROM [dbo].[GET_ZONAS_USR_FN_COPIA](146)
--ALTER FUNCTION [dbo].[GET_ZONAS_USR_FN_COPIA](@idContratoOperacionUsuario VARCHAR(MAX))

--returns @zonasAsignadas  Table (idZona INT)

--as 

--begin


--	declare @idRol int, @idCO int
--	select @idRol = idCatalogoRol, @idCO = idContratoOperacion from ContratoOperacionUsuario where idContratoOperacionUsuario in (SELECT Item FROM splitstring(@idContratoOperacionUsuario, ',') )
	
--	if (@idRol = 1 or @idRol = 3)
--		begin
--			insert into @zonasAsignadas
--			select idZona from ContratoOperacionUsuarioZona COUZ
--			where COUZ.idContratoOperacionUsuario in (SELECT Item FROM splitstring(@idContratoOperacionUsuario, ',') )
			
--		end
--	else if (@idRol = 4)
--		begin
--			insert into @zonasAsignadas
--			select distinct CPZ.idZona
--			from ContratoOperacionUsuarioProveedor COUP
--			inner join ContratoOperacionUsuario COU on COU.idContratoOperacionUsuario = COUP.idContratoOperacionUsuario
--			inner join ContratoOperacion CO on CO.idContratoOperacion = COU.idContratoOperacion
--			inner join Partidas..Contrato C on C.idContrato = CO.idContrato
--			inner join Partidas..ContratoProveedor CP on CP.idContrato = C.idContrato and CP.idProveedor = COUP.idProveedor
--			inner join Partidas..ContratoProveedorZona CPZ on CPZ.idContratoProveedor = CP.idContratoProveedor
--			where COUP.idContratoOperacionUsuario in (SELECT Item FROM splitstring(@idContratoOperacionUsuario, ',') )

			
				

				
--		end
--	else if (@idRol = 2)
--		begin
--			insert into @zonasAsignadas
--			select      z.idZona
--			from		ContratoOperacion CO 
--						inner join Partidas.dbo.Contrato AS Con ON CO.idContrato = Con.idContrato 
--						inner join Partidas.dbo.Licitacion AS Li ON Con.idLicitacion = Li.idLicitacion 
--						inner join Partidas.dbo.Cliente AS Cli ON Li.idCliente = Cli.idCliente 
--						inner join Partidas.dbo.NivelZona AS NivZo ON Cli.idCliente = NivZo.idCliente 
--						inner join Partidas.dbo.Zona AS Z ON z.idNivelZona = NivZo.idNivelZona
--			where CO.idContratoOperacion  in (SELECT Item FROM splitstring(@idContratoOperacionUsuario, ',') )

			
			
		

--		end

--	return 

--end
go

