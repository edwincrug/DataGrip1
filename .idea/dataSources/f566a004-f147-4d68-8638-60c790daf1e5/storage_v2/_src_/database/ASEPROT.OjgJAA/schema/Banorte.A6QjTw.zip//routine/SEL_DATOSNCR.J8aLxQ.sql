-- =============================================
-- Author:		<YJH>
-- Create date: <2019/06/13>
-- Description:	<Obtiene campos para el reporte de utilidades>
-- [Banorte].[SEL_DATOSNCR] 1, 84001
-- -- Author:		JJSY
-- Update date: <2019/09/19>
-- Description:	<Obtiene campos para el reporte de utilidades Para Talleres Tambien>
-- [Banorte].[SEL_DATOSNCR] 5, 96047 
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_DATOSNCR]
	@idMarca int, 
	@idOrden int
AS
BEGIN	
	SET NOCOUNT ON;


	 DECLARE @montoNCR DECIMAL(10,2), @porcentajeNCR FLOAT,  @TALLERES INT , @numSiniestro NVARCHAR(25)
	
	IF EXISTS( 

	SELECT * FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SC 
	INNER JOIN RefaccionMultiMarca.Operacion.CotizacionTaller CT ON SC.idSiniestro= CT.idSiniestro
	where SC.idOrden = @idOrden)
		BEGIN
			SET @TALLERES =1;
		END
	ELSE
		BEGIN
			SET @TALLERES = 0;
		END
		
	IF (@TALLERES = 0) 
	BEGIN
		SELECT  
			@montoNCR=ISNULL(montoNCR,0), 
			@porcentajeNCR=ISNULL(porcentajeNCR,0) 
		FROM ASEPROT.dbo.[SEL_VALNCRREFAC_FN](@idOrden, @idMarca)
	END
   ELSE 
   BEGIN
    SET @numSiniestro = (SELECT S.numeroReclamo FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SC 
												inner join RefaccionMultimarca.Operacion.Siniestro S on SC.idSiniestro = S.id
	                                            where SC.idOrden = @idOrden)
		SELECT  
			@montoNCR=ISNULL(montoNCR,0), 
			@porcentajeNCR=ISNULL(porcentajeNCR,0) 
		FROM ASEPROT.[dbo].[SEL_VALNCRTALLER_FN] ( @numSiniestro , @idMarca)
	END
	
	SELECT 
		@porcentajeNCR real, 
		@montoNCR importe,
		ISNULL(ISNULL(SUM(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00) - ISNULL(SUM(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00),0) + ISNULL(@montoNCR,0) utilidad,
		CASE WHEN (ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0) = 0) then 0 else ((((ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)-ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00)) + ISNULL(@montoNCR,0)) * 100) / ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)) end margen
	FROM ASEPROT.dbo.Ordenes O
		JOIN ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden
		JOIN ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
	WHERE O.idOrden = @idOrden and CD.idEstatusPartida IN(2,3)


 --   DECLARE @montoNCR DECIMAL(10,2), @porcentajeNCR FLOAT
	
	--SELECT  
	--	@montoNCR=ISNULL(montoNCR,0), 
	--	@porcentajeNCR=ISNULL(porcentajeNCR,0) 
	--FROM ASEPROT.dbo.[SEL_VALNCRREFAC_FN](@idOrden, @idMarca)

	--SELECT 
	--	@porcentajeNCR real, 
	--	@montoNCR importe,
	--	ISNULL(ISNULL(SUM(ISNULL(CD.venta,0) * ISNULL(CD.solicitadasOrg,0)),0.00) - ISNULL(SUM(ISNULL(CD.costo,0) * ISNULL(CD.solicitadasOrg,0)),0.00),0) + ISNULL(@montoNCR,0) utilidad,
	--	CASE WHEN (ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.solicitadasOrg,0)),0) = 0) then 0 else ((((ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.solicitadasOrg,0)),0.00)-ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.solicitadasOrg,0)),0.00)) + ISNULL(@montoNCR,0)) * 100) / ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.solicitadasOrg,0)),0.00)) end margen
	--FROM ASEPROT.dbo.Ordenes O
	--	JOIN ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden
	--	JOIN ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
	--WHERE O.idOrden = @idOrden and CD.idEstatusPartida IN(2,3)


	--SELECT 
	--	@porcentajeNCR real, 
	--	@montoNCR importe,
	--	ISNULL(ISNULL(SUM(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00) - ISNULL(SUM(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00),0) + ISNULL(@montoNCR,0) utilidad,
	--	CASE WHEN (ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0) = 0) then 0 else ((((ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)-ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00)) + ISNULL(@montoNCR,0)) * 100) / ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)) end margen
	--FROM ASEPROT.dbo.Ordenes O
	--	JOIN ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden
	--	JOIN ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
	--WHERE O.idOrden = @idOrden and CD.idEstatusPartida IN(2,3)

END
go

grant execute, view definition on Banorte.SEL_DATOSNCR to DevOps
go

