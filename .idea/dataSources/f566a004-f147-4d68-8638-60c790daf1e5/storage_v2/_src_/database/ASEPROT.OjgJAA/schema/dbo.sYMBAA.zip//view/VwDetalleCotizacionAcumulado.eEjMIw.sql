
CREATE VIEW [dbo].[VwDetalleCotizacionAcumulado]
AS
SELECT O.idOrden, ISNULL(SUM(ISNULL(CD.venta, 0) * ISNULL(CD.cantidad, 0)), 0) AS MontoCotizacionDetalle
FROM     dbo.Ordenes AS O INNER JOIN
                  dbo.Cotizaciones AS C ON C.idOrden = O.idOrden INNER JOIN
                  dbo.CotizacionDetalle AS CD ON CD.idCotizacion = C.idCotizacion
 WHERE CD.idEstatusPartida IN(1,2) 
	     AND C.idEstatusCotizacion IN(1,2,3)
GROUP BY O.idOrden
go

