





CREATE VIEW [cobranza].[VwCotizacionProvInvoiceD]
AS
SELECT --top 10
       C.numeroCotizacion, 
       C.idCotizacion, 
	   GAE.OTE_IDPROVEEDOR,
	   GAE.OTE_ORDENPEMEX,
	   FC.numFactura

      FROM Ordenes O 
	  
	  INNER join [dbo].[Cotizaciones] C
	  ON O.[idOrden] = c.[idOrden]

inner JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]  GAE
        ON GAE.OTE_ORDENANDRADE = o.numerooRDEN COLLATE Modern_Spanish_CS_AS

LEFT JOIN FacturaCotizacion FC
        ON FC.idCotizacion=C.idCotizacion

		where GAE.OTE_IDPROVEEDOR is not null
		  and  FC.numFactura is not null

		  UNION ALL
		  SELECT --top 10
       C.numeroCotizacion, 
       C.idCotizacion, 
	   GAE.OTE_IDPROVEEDOR,
	   GAE.OTE_ORDENPEMEX,
	   FC.numFactura

      FROM Ordenes O 
	  
	  INNER join [dbo].[Cotizaciones] C
	  ON O.[idOrden] = c.[idOrden]

inner JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC]  GAE
        ON GAE.OTE_ORDENANDRADE = o.numerooRDEN COLLATE Modern_Spanish_CS_AS

LEFT JOIN FacturaCotizacion FC
        ON FC.idCotizacion=C.idCotizacion

		where GAE.OTE_IDPROVEEDOR is not null
		  and  FC.numFactura is not null

go

