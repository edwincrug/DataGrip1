-- =============================================
--Fecha Creación: 23/01/19
--Autor: Miguel Angel Reyes Xinaxtle
--Descripción: obtener las preguntas para sisco movil por aplicacion
--[Mobile].[SEL_PREGUNTAS_SP] 1
-- =============================================
CREATE PROCEDURE [Mobile].[SEL_PREGUNTAS_SP]
	@idTipoPregunta int
AS

BEGIN

	SELECT 
		idPregunta
		,pregunta
		,respuesta
	FROM Mobile.Pregunta
	WHERE idTipoPregunta = @idTipoPregunta
		AND estatus = 1

END

go

grant execute, view definition on Mobile.SEL_PREGUNTAS_SP to DevOps
go

