-- ==========================================================================================
-- Author:		J Armando Garcia Arroyo
-- Create date: 08/08/2019
-- Description:	Store para insertar el codigo SAP
-- ==========================================================================================
CREATE PROCEDURE [dbo].[INS_CODIGOSAP_SP]
	@numeroSAP VARCHAR(MAX),
    @idOrden NUMERIC(20,0),
    @idUsuario NUMERIC(20,0),
	@idEstatusOrden NUMERIC(20,0)
AS  
BEGIN
	IF NOT EXISTS (SELECT 1 FROM CodigoSap WHERE idOrden=@idOrden)
	BEGIN
		INSERT INTO CodigoSap VALUES(@numeroSAP,@idOrden,@idUsuario,GETDATE(),@idEstatusOrden); 
		SELECT @@IDENTITY LastInsertId;
	END
	ELSE
	BEGIN
		UPDATE CodigoSap SET numeroSap=@numeroSAP
		WHERE idOrden=@idOrden
	END
END
go

