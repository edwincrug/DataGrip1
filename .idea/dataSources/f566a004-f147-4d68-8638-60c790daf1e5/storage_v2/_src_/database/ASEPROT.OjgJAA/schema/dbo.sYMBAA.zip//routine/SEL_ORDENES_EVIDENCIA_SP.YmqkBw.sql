-- =============================================
-- Description:	Busca todas las órdenes existentes
-- NOTA: Falta verificar el usuario, su rol y el tipo de operación 
-- =============================================
-- [dbo].[SEL_ORDENES_EVIDENCIA_SP] 57

CREATE PROCEDURE [dbo].[SEL_ORDENES_EVIDENCIA_SP]
@idContratoOperacion INT,
@fechaInicio VARCHAR(MAX) = NULL,
@fechaFin VARCHAR(MAX) = NULL,
@ordenes NVARCHAR(MAX) = NULL,
@accion INT=0
AS
BEGIN
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; -- turn it on

SET DATEFORMAT DMY;
IF @accion = 0
BEGIN
EXEC [192.168.20.18].ASEPROT.[dbo].[SEL_ORDENES_EVIDENCIA_SP] @idContratoOperacion ,@fechaInicio ,@fechaFin ,@ordenes , @accion
END

IF @accion = 1
BEGIN
	SELECT DISTINCT
	Orden.consecutivoOrden
	,Orden.[idOrden]
	,[numeroOrden]
	,Orden.fechaCreacionOden 
	,(SELECT nombreEstatusOrden FROM EstatusOrdenes EO WHERE EO.idEstatusOrden=Orden.idEstatusOrden) as estatus
	,U.vin
	,U.numeroEconomico
	, (SELECT MA.nombre FROM .[Partidas].dbo.Unidad UNI
	INNER JOIN .[Partidas].dbo.TipoUnidad TU ON UNI.idTipoUnidad = TU.idTipoUnidad
	INNER JOIN .[Partidas].dbo.SubMarca SM ON UNI.idSubMarca = SM.idSubMarca
	INNER JOIN .[Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca
	WHERE UNI.idUnidad = U.idTipoUnidad) AS marca
	,CAST(0 AS BIT) AS seleccionado
	FROM [dbo].[Ordenes] Orden
	INNER JOIN Unidades U ON U.idUnidad=Orden.idUnidad
	INNER JOIN dbo.Evidencias E ON E.idOrdenServicio=Orden.idOrden
	WHERE Orden.idContratoOperacion=@idContratoOperacion
	and Orden.idEstatusOrden<>13
	and (SELECT COUNT(*) FROM DBO.Evidencias E WHERE E.idOrdenServicio=Orden.idOrden)>0
	AND fechaCreacionOden >= CAST(@fechaInicio AS DATE) AND fechaCreacionOden < DATEADD(d,1,CAST(@fechaFin AS DATE))
	and E.rutaEvidencia NOT LIKE '%/Factura/%'
	ORDER BY Orden.idOrden
END

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED; -- turn it off
END
go

