

/*
	Objetivo trae las promociones para la página responsiva las promociones para la app se traen en [GET_PROMOCIONES]

	Fecha			Autor			Descripción
	27-Jun-2018		José Etmanuel	Se crea el SP que regresa las promociones genrales
	
	[Banorte].[GET_PROMOCIONES_PAG] 
*/

CREATE PROCEDURE [Banorte].[GET_PROMOCIONES_PAG] 
	@tipoApp varchar(50) = 'APP'
AS
BEGIN

	SELECT *, '' as promociones FROM [Banorte].[CatalogoTipoPromocion]
	WHERE status = 1
	Order by [order];
	

	SELECT * FROM [Banorte].[Promociones] 
	WHERE  fechaInicio <= GETDATE()
	AND fechaTermino >= GETDATE()
	AND estatus = 1
	AND aplicaPara = @tipoApp

	SELECT * FROM [Banorte].[Promociones]  WHERE [idTipoPromocion] = 0 AND [aplicaPara] = @tipoApp;
END

go

grant execute, view definition on Banorte.GET_PROMOCIONES_PAG to DevOps
go

