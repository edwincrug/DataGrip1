
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 11/05/2017
-- Description:	Inserta el Token para el numero de orden
-- ==========================================================================================

CREATE PROCEDURE [dbo].[APP_GUARDAR_TOKEN]
    @token NVARCHAR(50),
    @Vigencia NVARCHAR(250),
	@ubicacionToken NVARCHAR(50),
	@datosMovil NVARCHAR(250),
	@numeroOrden NVARCHAR(15),
	@idUsuario numeric(18,0),
	@idOrdenServicio numeric(18,0),
	@origenToken NVARCHAR(6),
	@idEstatusOrden numeric(18,0),
	@idCotizacion NUMERIC(18,0)
AS
BEGIN
	DECLARE @Validar numeric( 18,0 )
	DECLARE @Orden NVARCHAR(15)
	DECLARE @Test NVARCHAR(250)
	DECLARE @Tiempo FLOAT(50) 	
	
	-- Se valida si hay Token Activos y se ponen como inactivos para dar entrada a uno nuevo
	SET @Orden = @numeroOrden
	
	SET @Validar = ( SELECT COUNT(idToken) TotalToken 
						FROM [Token]			TOK 
						INNER JOIN [Ordenes]	ORD ON TOK.idOrdenServicio = ORD.idOrden 
						WHERE numeroOrden = @Orden
							AND estatusToken = 1  );
	
	SET @Tiempo = CONVERT(float,@Vigencia) / 86400
	
	DECLARE @idOperacion INT = (SELECT idOperacion FROM Ordenes ORD
								INNER JOIN ContratoOperacion CON ON ORD.idContratoOperacion = CON.idContratoOperacion
								WHERE idOrden = 4176);
	IF( @idOperacion != 3 ) -- Solo Pemex
		BEGIN
			UPDATE [Token] SET estatusToken = 0 WHERE idToken IN ( SELECT idToken FROM [Token] TOK INNER JOIN [Ordenes] ORD ON TOK.idOrdenServicio = ORD.idOrden WHERE numeroOrden = @Orden AND estatusToken = 1 );
		END
	ELSE 
		BEGIN
			DECLARE @idZona INT = ( SELECT idZona FROM Ordenes WHERE idOrden = @idOrdenServicio );
			DECLARE @idPerfil INT = (SELECT idPerfil FROM ClientePerfilZona WHERE idUsuario = @idUsuario AND idZona = @idZona);
	
			UPDATE [Token] SET estatusToken = 0 WHERE idToken IN ( 
																	SELECT TOK.idToken FROM [Token] TOK 
																	INNER JOIN [Ordenes] ORD ON TOK.idOrdenServicio = ORD.idOrden 
																	INNER JOIN [ClientePerfilZona] CPZ ON CPZ.idUsuario = TOK.idUsuario AND CPZ.idZona = ORD.idZona
																	WHERE idOrden = @idOrdenServicio AND estatusToken = 1 AND CPZ.idPerfil = @idPerfil
																  );
		END
	
	--IF ( @Validar <> 0 )
	--BEGIN
	--	UPDATE [dbo].[Token] SET estatusToken = 0 WHERE idToken IN ( SELECT idToken FROM [dbo].[Token] TOK INNER JOIN [dbo].[Ordenes] ORD ON TOK.idOrdenServicio = ORD.idOrden WHERE numeroOrden = @Orden AND estatusToken = 1 )
	--END
	
	-- Se inserta el token	
	INSERT INTO [Token] (
		token, 
		ubicacionToken,
		datosMovil,
		fechaHora,
		vigenciaToken,
		idUsuario,
		idOrdenServicio,
		origenToken,
		idEstatusOrden,
		idCotizacion
	) 
	VALUES (
		@token,
		@ubicacionToken,
		@datosMovil,
		CURRENT_TIMESTAMP,
		CURRENT_TIMESTAMP + @Tiempo,
		@idUsuario,
		@idOrdenServicio,
		@origenToken,
		@idEstatusOrden,
		@idCotizacion
	)

	SELECT @@IDENTITY LastInsertId, @Validar Test, @Validar Total, CURRENT_TIMESTAMP + @Tiempo Segundos
END
go

