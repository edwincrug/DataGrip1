

-- =============================================
-- Author:		
-- Create date: 
-- Description:	
--Test: [report].[INS_EC_DETALLEGAAUTOEXPRESSIII]
--select * from report.INS_EC_DETALLEGAAUTOEXPRESSIII
-- =============================================

CREATE PROCEDURE [report].[INS_EC_DETALLEGAAUTOEXPRESSIII]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE FROM report.EC_DETALLEGAAutoexpressIII
	INSERT INTO report.EC_DETALLEGAAutoexpressIII
	select DISTINCT
		cont.idOperacion,
		ISNULL(ose.OTE_FACTURACOMPRA, 'XXXX') FACTURA, 
		ord.idOrden,
		ord.numeroOrden,
		--cot.idCotizacion,
		enc.idBPRO,
		pe.razonSocial,
		ROUND((select (ISNULL(SUM(costo * cantidad),0)) * [dbo].[fnFactorIVA_Orden](ord.idOrden ,1) from CotizacionDetalle where idCotizacion = cot.idCotizacion),2) TOTALSISCO,
		ISNULL(VSC.SALDO,ROUND((select (ISNULL(SUM(costo * cantidad),0)) * [dbo].[fnFactorIVA_Orden](ord.idOrden ,1) from CotizacionDetalle where idCotizacion = cot.idCotizacion),2)) SALDO,
		est.idEstatusOrden IDESTATUSORDEN,
		est.nombreEstatusOrden ESTATUSORDEN,
		GETDATE()
	from Ordenes ord
	inner join Cotizaciones cot on ord.idOrden = cot.idOrden
	inner join Partidas..Proveedor p on cot.idTaller = p.idProveedor
	inner join Partidas..ProveedorEncabezado pe on p.idProveedorEncabezado = pe.idProveedorEncabezado
	inner join Partidas..ProveedorEncabezadoEmpresa enc on pe.idProveedorEncabezado = enc.idProveedorEncabezado and enc.idEmpresa = 1 
	inner join ContratoOperacion cont on cont.idContratoOperacion = ord.idContratoOperacion	
	inner join EstatusOrdenes est on est.idEstatusOrden = ord.idEstatusOrden
	full outer join [192.168.20.29].GAAutoexpressIII.dbo.ADE_ORDSERENC ose on ose.OTE_ORDENANDRADE = ord.numeroOrden collate MODERN_SPANISH_CI_AS and ose.OTE_IDPROVEEDOR = enc.idBPRO
	left join [ASEPROT].[cobranza].[VwInvoiceProvSaldoBPRO_GAAutoexpressIII] VSC on VSC.CCP_IDPERSONA = ose.OTE_IDPROVEEDOR and VSC.CCP_IDDOCTO collate MODERN_SPANISH_CI_AS = ose.OTE_FACTURACOMPRA collate MODERN_SPANISH_CI_AS
	where cot.idTaller <> 0 and cont.idContratoOperacion in(47) 
	order by PE.RAZONSOCIAL
END
go

