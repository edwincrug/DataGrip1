-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- [dbo].[EXT_FACTURA_BANREGIO_BPRO_PROVEEDOR_SP] 1
CREATE PROCEDURE [dbo].[EXT_FACTURA_BANREGIO_BPRO_PROVEEDOR_SP] 
	-- Add the parameters for the stored procedure here
	@isProduction NUMERIC(18,0)
AS
BEGIN
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @idOrden NUMERIC(18,0)
	DECLARE @idOperacion NUMERIC(18,0)
	DECLARE @idContratoOperacion NUMERIC(18,0)
	DECLARE @idUsuario NUMERIC(18,0) =551
	DECLARE @numeroOrden NVARCHAR(100)
	DECLARE @max NUMERIC(18,0)
	--////////////////////////////////
	DECLARE @idProveedor NUMERIC(18,0)
	DECLARE @server NVARCHAR(100)
	DECLARE @db NVARCHAR(100)
	--////////////////////////////////
	DECLARE @queryText NVARCHAR(MAX)
	DECLARE @tableTemp TABLE (val INT)
	DECLARE @queryM NVARCHAR(MAX)
	DECLARE @queryH NVARCHAR(MAX)
	DECLARE @queryC NVARCHAR(MAX)
	DECLARE @OTD_IDENT NVARCHAR(MAX)
	DECLARE @existe INT = 0
	DECLARE @proveedorInterno NUMERIC(18,0)
	--////////////////////////////////
	DECLARE @idDatosCopade INT
	DECLARE @idDatosCopadeOrden INT
	DECLARE @idOrdenAgrupada INT
	DECLARE @idOrdenAgrupadaDetalle INT
	DECLARE @numero NVARCHAR(100)
	DECLARE @OTE_IDPROVEEDOR NUMERIC(18,0)
	DECLARE @OTR_IDPEDIDOFOT NUMERIC(18,0)
	DECLARE @OTE_IDPROVEEDORBANREGIO NUMERIC(18,0) = 265485
	DECLARE @QUERYORDENGLOBAL NVARCHAR(MAX)
	--////////////////////////////////

	DECLARE cursor_refacturacion CURSOR FOR
	SELECT numeroOrden FROM Refacturacion WHERE estatus=0

	OPEN cursor_refacturacion  
	FETCH NEXT FROM cursor_refacturacion INTO @numeroOrden
	WHILE @@FETCH_STATUS = 0  
		BEGIN 

		SELECT @idOrden=idOrden, 
			   @idContratoOperacion=idContratoOperacion 
		FROM Ordenes 
		WHERE numeroOrden = @numeroOrden

		SELECT @idOperacion=idOperacion FROM ContratoOperacion WHERE idContratoOperacion = @idContratoOperacion

		  --Actualiza el trabajo de estatus y inserta en BPRO
		  SELECT @idCotizacion = MIN(C.idCotizacion) 
		  FROM Cotizaciones C 
		  WHERE C.idOrden = @idOrden AND idTaller <> 0 

		  SELECT @proveedorInterno = proveedorInterno
		  FROM ContratoOperacionFacturacion 
		  WHERE idContratoOperacion = @idContratoOperacion
		
		BEGIN
					IF(@isProduction = 1)
						BEGIN
							SELECT 
									@server = SERVER,
									@db = DBProduccion
							FROM ContratoOperacionFacturacion COF 
							inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
							WHERE CO.idContratoOperacion =  @idContratoOperacion
						END
					ELSE
						BEGIN
							SELECT 
									@server=SERVER,
									@db=DB
							FROM ContratoOperacionFacturacion COF 
							inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
							WHERE CO.idContratoOperacion =  @idContratoOperacion
						END

					IF(@idContratoOperacion = 14)
						BEGIN
							SET @queryText = 'SELECT CASE WHEN EXISTS(SELECT 1 FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''') THEN 1 ELSE 0 END ' 
							INSERT INTO @tableTemp EXEC(@queryText) 
							SET @existe = (SELECT TOP 1 val FROM @tableTemp)

							IF(@existe = 1)
								BEGIN	
									SET @OTD_IDENT = 'SELECT OTE_IDENT FROM '+@server+'.'+@db+'.[dbo].[ADE_ORDSERENC] WHERE [OTE_ORDENANDRADE] = '''+@numeroOrden+''' '
									SELECT @OTE_IDPROVEEDOR = OTE_IDPROVEEDOR, @OTR_IDPEDIDOFOT = OTE_IDENT  FROM [192.168.20.29].[GAAUTOEXPRESS].[DBO].[ADE_ORDSERENC] WHERE OTE_ORDENANDRADE = @numeroOrden
									PRINT @numeroOrden
									PRINT @OTR_IDPEDIDOFOT
									PRINT @OTE_IDPROVEEDOR
									PRINT @OTE_IDPROVEEDORBANREGIO
									INSERT INTO HistorialProveedorBanRegio VALUES(@numeroOrden, @OTE_IDPROVEEDOR, @OTR_IDPEDIDOFOT)

									UPDATE [192.168.20.29].[GAAUTOEXPRESS].[DBO].[ADE_ORDSERENC]
									SET
									OTE_IDPROVEEDOR = @OTE_IDPROVEEDORBANREGIO
									WHERE OTE_ORDENANDRADE = @numeroOrden
									
									--UPDATE Refacturacion
									--SET estatus=1
									--WHERE numeroOrden = @numeroOrden
								END
							ELSE
								BEGIN
									SELECT 0 Success, 'ORDEN NO EXISTE EN BPRO' Msg
								END
						END
				END	
			FETCH NEXT FROM cursor_refacturacion INTO @numeroOrden
		END  
	CLOSE cursor_refacturacion  
	DEALLOCATE cursor_refacturacion
END
go

