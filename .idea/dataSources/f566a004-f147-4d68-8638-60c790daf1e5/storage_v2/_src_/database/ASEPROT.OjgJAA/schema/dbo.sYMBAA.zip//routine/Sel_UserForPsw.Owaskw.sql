-- =============================================
-- Author:		Lisandro Martínez
-- Create date: 19/10/2018

-- =============================================
CREATE PROCEDURE [dbo].[Sel_UserForPsw]
	@username varchar(50),
	@password varchar(MAX)
AS
BEGIN
	declare @id int = 0, @msj varchar(50), @fehcaTemp date;
	IF EXISTS(SELECT * FROM [Seguridad].[Catalogo].[Users] where UserName /*COLLATE Latin1_General_CS_AS*/ = @username and 
			CONVERT(NVARCHAR(MAX), DECRYPTBYPASSPHRASE(N'Password Secret!', [Password])) /*COLLATE Latin1_General_CS_AS*/ = @password)
	BEGIN
		set @id = (select Id from [Seguridad].[Catalogo].[Users] WHERE UserName = @username)
		EXEC [dbo].[Sel_Valida_Pass] @id, @msj OUTPUT, @fehcaTemp output
		--SELECT 1 as authorized, @msj AS msj, @id AS userID, @fehcaTemp as fechaCad;
	END
	ELSE
	BEGIN
		IF EXISTS(SELECT * FROM [Seguridad].[Catalogo].[Users] where UserName /*COLLATE Latin1_General_CS_AS*/ = @username and 
			[Password]/*COLLATE Latin1_General_CS_AS*/ = @password)
			BEGIN
				set @id = (select Id from [Seguridad].[Catalogo].[Users] WHERE UserName = @username)
				EXEC [dbo].[Sel_Valida_Pass] @id, @msj OUTPUT, @fehcaTemp output
				--SELECT 1 as authorized, @msj AS msj, @id AS userID, @fehcaTemp as fechaCad;
			END
			ELSE
			BEGIN
				SELECT 0 as authorized
			END
		
	END
END



--select *
--from [dbo].[HistorialLogin]
--where idUsuario = 534

--update [dbo].[HistorialLogin]
--set FechaFin = GETDATE()
--where idUsuario = 534
--and FechaFin is null
go

