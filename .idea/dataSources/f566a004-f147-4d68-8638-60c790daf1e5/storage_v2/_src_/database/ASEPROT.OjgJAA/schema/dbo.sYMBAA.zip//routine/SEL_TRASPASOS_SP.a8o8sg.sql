
CREATE PROCEDURE [dbo].[SEL_TRASPASOS_SP]
	@idpresupuestoDestino as int
AS
BEGIN

	SELECT *,
		(select folioPresupuesto from Presupuestos where idPresupuesto =  TP.idpresupuestoOrigen) folioOrigen,
		(select folioPresupuesto from Presupuestos where idPresupuesto =  TP.idpresupuestoDestino) folioDestino 
		
	 FROM traspasopresupuesto TP
	WHERE idpresupuestoDestino =@idpresupuestoDestino	

END

go

