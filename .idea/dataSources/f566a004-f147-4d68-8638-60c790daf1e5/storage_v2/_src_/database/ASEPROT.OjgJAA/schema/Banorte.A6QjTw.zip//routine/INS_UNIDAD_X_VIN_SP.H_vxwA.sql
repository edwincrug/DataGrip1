
-- =============================================
 CREATE PROCEDURE [Banorte].[INS_UNIDAD_X_VIN_SP]
 --EXEC [dbo].[INS_UNIDAD_X_VIN_SP] '3HAMMAAR8AL245637',174,0,19,'ZH97170',302,'2010',1,1
	@vin NVARCHAR(50),
	@idTipoUnidad INT,
	@sustituto INT,
	@idOperacion INT,
	@placas NVARCHAR(50),
	@idZona INT,
	@modelo NVARCHAR(10),
	@combustible NVARCHAR(50),
	@verificada INT,
	@kilometraje INT
AS

BEGIN
	DECLARE @idUnidad INT,
	@idCatalogoTipoServicio INT=2
	IF NOT EXISTS(SELECT vin FROM Unidades WHERE idOperacion = @idOperacion AND vin = @vin)
	BEGIN
		INSERT INTO [Unidades] (
			[vin]
			,[idTipoUnidad]
			,[sustituto]
			,[idOperacion]
			,[placas]
			,[idZona]
			,[modelo]
			,[combustible]
			,[verificada]
			,[Kilometraje_Actual]
			)
		VALUES( 
				@vin,
				@idTipoUnidad,
				@sustituto,
				@idOperacion,
				@placas,
				@idZona,
				@modelo,
				@combustible,
				@verificada,
				@kilometraje
				)
		SET @idUnidad = @@IDENTITY 
		--SELECT @idUnidad AS idUnidad

	END
	ELSE
	BEGIN

		SELECT @idUnidad = idUnidad FROM Unidades WHERE idOperacion = @idOperacion AND vin = @vin

		update Unidades 
		set placas = @placas, Kilometraje_Actual = @kilometraje
		where idUnidad = @idUnidad and idOperacion = @idOperacion
		
	END
	SELECT @idUnidad AS idUnidad
END
go

grant execute, view definition on Banorte.INS_UNIDAD_X_VIN_SP to DevOps
go

