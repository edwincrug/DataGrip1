-- =============================================
-- Description: Busca todos los documentos relacionados a la orden
-- NOTA: 
-- [SEL_DETALLE_ORDEN_DOCUMENTACION_SP] @numeroOrden = '100010'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DETALLE_ORDEN_DOCUMENTACION_SP]
@idUsuario INT = 0,
@numeroOrden varchar(50) = ''
AS
BEGIN
	SELECT * 
	FROM DocumentosOrdenes DocOr
	INNER JOIN CatalogoDocumentos CatDoc ON CatDoc.idCatalogoDocumento = DocOr.idCatalogoDocumento 
	INNER JOIN Ordenes Ord ON Ord.idOrden = DocOr.idOrden
	WHERE Ord.numeroOrden = @numeroOrden

END

go

