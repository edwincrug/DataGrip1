--   [UPD_CANCELA_ORDEN_SP] 23, 8 
CREATE PROC [dbo].[UPD_CANCELA_ORDEN_SP]
	@idUsuario numeric(18,0),
	@idOrden numeric(18,0)
AS
BEGIN
    DECLARE @idOrdenes NUMERIC(18,0)
	DECLARE @existeOrden NUMERIC(18,0)
	DECLARE @cantidadCotizaciones NUMERIC(18,0)
	DECLARE @cantidadCotizacionesAutorizadas NUMERIC(18,0)
	DECLARE @pendientes NUMERIC(18,0)
	DECLARE @autorizadas NUMERIC(18,0)
	DECLARE @rechazadas NUMERIC(18,0)
	DECLARE @idAutorizacion INT
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @max NUMERIC(18,0)
	DECLARE @existePresupuesto NUMERIC(18,0)
	DECLARE @existePresupuestoEspecial NUMERIC(18,0)

	SET @idOrdenes = (SELECT idOrden FROM Ordenes where idOrden = @idOrden)
	SELECT @existeOrden = COUNT(1) FROM Ordenes WHERE idOrden = @idOrden


	IF(@existeOrden > 0)
	BEGIN
		SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden
		SELECT @max = MAX(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden
		WHILE(@idCotizacion <= @max)
			BEGIN	
				--ACTUALIZA LA COTIZACIÓN A rechazada
				UPDATE Cotizaciones SET idEstatusCotizacion = 4 WHERE idCotizacion = @idCotizacion

				INSERT INTO [dbo].[HistorialEstatusCotizacion]([fechaInicial], [fechaFinal], [idCotizacion], [idUsuario], [idEstatusCotizacion])
				VALUES (GETDATE(), GETDATE(), @idCotizacion, @idUsuario, 4)

				--ACTUALIZA EL DETALLE DE LA COTIZACIÓN A rechazada
				UPDATE CotizacionDetalle SET idEstatusPartida = 3 WHERE idCotizacion = @idCotizacion
		
				SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden AND idCotizacion > @idCotizacion
			END
		
		  --REALIZA EL CONTEO DEL NÚMERO DE COTIZACIONES EN LA ORDEN
		SELECT @pendientes = X.pendientes, 
			   @autorizadas = X.autorizadas, 
			   @rechazadas =  X.rechazadas 
		FROM (SELECT 
				pendientes = (SELECT COUNT(C.idEstatusCotizacion)
					FROM Ordenes O
					JOIN Cotizaciones C ON C.idOrden = O.idOrden
					WHERE O.idOrden = @idOrden AND C.idEstatusCotizacion IN (1,2)),
				autorizadas = (SELECT  COUNT(C.idEstatusCotizacion)
					FROM Ordenes O
					JOIN Cotizaciones C ON C.idOrden = O.idOrden
					WHERE O.idOrden = @idOrden AND C.idEstatusCotizacion IN (3)),
				rechazadas = (SELECT  COUNT(C.idEstatusCotizacion)
					FROM Ordenes O
					JOIN Cotizaciones C ON C.idOrden = O.idOrden
					WHERE O.idOrden = @idOrden AND C.idEstatusCotizacion IN (4)))X

	IF(@pendientes = 0 AND @autorizadas = 0)
		BEGIN
			--ACTUALIZA LA ORDEN A Orden cancelada
		    UPDATE Ordenes SET idEstatusOrden = 13 WHERE idOrden = @idOrden
			
			--Poner fecha final en el estatus anterior
			Update [dbo].[HistorialEstatusOrden] set fechaFinal= GETDATE() where idOrden= @idOrden and fechaFinal is null

			-- DEJA RASTRO EN HISTORIALPROCESO
			INSERT INTO [dbo].[HistorialEstatusOrden]([idOrden], [idEstatusOrden], [fechaInicial], [fechaFinal], [idUsuario])
			VALUES(@idOrden, 13, GETDATE(), null, @idusuario)


			 --Valora si existen registro en la tabla presupuestos 
			SELECT @existePresupuesto= COUNT(*) FROM PresupuestoOrden where idOrden= @idOrden 

			IF(@existePresupuesto >0)
			BEGIN
			DECLARE @idOrdenPresupuesto numeric(18,0)
			DECLARE @idPresupuesto numeric(18,0)

			--Se crea un cursor el cual itera sobre los registros que están en la tabla de presupuestos
			DECLARE PresupuestoInfo CURSOR FOR SELECT idOrden,idPresupuesto FROM PresupuestoOrden WHERE idOrden=@idOrden 
			
			--Se abre el cursor 
			OPEN PresupuestoInfo 
			FETCH NEXT FROM PresupuestoInfo INTO @idOrdenPresupuesto, @idPresupuesto
			--Se inicia el ciclo
			WHILE @@fetch_status= 0
				BEGIN
				--Inserta el registro en bitacora por cada registro a borrar
				INSERT INTO Bitacora (IdUsuario, fechaBitacora, tabla, idOrden, operacion) VALUES (@idusuario, GETDATE(), 'PresupuestoOrden', @idOrdenPresupuesto, 'Eliminado del presupuesto numero ' +Cast( @idPresupuesto as varchar(25)))
				
				FETCH NEXT FROM PresupuestoInfo INTO @idOrdenPresupuesto, @idPresupuesto
				END
				--Se cierra y se libera el cursor
			CLOSE PresupuestoInfo
			DEALLOCATE PresupuestoInfo


				---Eliminar registro en Presupuesto Orden
				DELETE FROM PresupuestoOrden WHERE idOrden= @idOrden
			END
			--Valida si existe registros en la tabla presupuestos especiales
			SELECT @existePresupuestoEspecial = COUNT(*) FROM OrdenesPresupuestoEspecial where idOrden= @idOrden
			
			IF(@existePresupuestoEspecial >0)
			BEGIN
			DECLARE @idPresupuestoEspecial numeric(18,0)
			DECLARE @idOrdenPresupuestoEspecial numeric(18,0)
			--Se crea el cursor el cual itera sobre los registros que están en la tabla de Presupuestos especiales
			DECLARE PresupuestoEspecialInfo CURSOR FOR SELECT idOrdenPresupuestoEspecial, idOrden FROM OrdenesPresupuestoEspecial WHERE idOrden= @idORden
			--Se abre el cursor
			OPEN PresupuestoEspecialInfo 
			
			FETCH NEXT FROM PresupuestoEspecialInfo INTO @idPresupuestoEspecial,@idOrdenPresupuestoEspecial
			
			--Se inicia el ciclo
			WHILE @@fetch_status= 0
				BEGIN
					--inserta en bitacora por cada registro que contiene la tabla
					INSERT INTO Bitacora(IdUsuario, fechaBitacora, tabla, idOrden, operacion) VALUES (@idusuario, GETDATE(), 'OrdenesPresupuestoEspecial', @idOrdenPresupuestoEspecial, 'Eliminado del presupuesto especial ' + Cast(@idPresupuestoEspecial as varchar(25)))
					
					FETCH NEXT FROM PresupuestoEspecialInfo INTO @idPresupuestoEspecial,@idOrdenPresupuestoEspecial
				END
				--Se cierra y libera el cursor
			CLOSE PresupuestoEspecialInfo
			DEALLOCATE PresupuestoEspecialInfo

				--Elimina registros en OrdenesPresupuestoEspecial
				DELETE FROM OrdenesPresupuestoEspecial where idOrden= @idOrden
			END


			SELECT @@IDENTITY
		END
	END 
	--SELECT 'La orden no existe'
END

/*
		select * from [dbo].[EstatusCotizaciones]
		select * from [dbo].[EstatusOrdenes]
		select * from [dbo].[EstatusPartida]
		select * from Cotizaciones
		select * from CotizacionDetalle
		select * from ordenes
		select * from AutorizacionCotizacion
		select * from HistorialEstatusOrden
		select * from [HistorialEstatusCotizacion]
*/

/*
-- ==========================================================================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 22/05/2017
-- UPD_CANCELA_ORDEN_SP 25, 266
-- ==========================================================================================
ALTER PROCEDURE [dbo].[UPD_CANCELA_ORDEN_SP]
	@idUsuario numeric(18,0),
	@idOrden numeric(18,0)
AS
BEGIN
	    DECLARE @idcotizacion numeric(18,0)
		DECLARE Detalle_Cursor2 CURSOR FOR 
		SELECT idCotizacion FROM Cotizaciones WHERE idOrden = @idOrden

		OPEN Detalle_Cursor2
		FETCH NEXT FROM Detalle_Cursor2 INTO @idCotizacion

	WHILE @@FETCH_STATUS = 0 
		BEGIN
			IF ((SELECT COUNT(idCotizacion) FROM Cotizaciones WHERE idCotizacion = @idCotizacion) > 0)
			BEGIN
				DECLARE	@estatusActualCoti INT = (SELECT idEstatusCotizacion FROM Cotizaciones WHERE idCotizacion = @idCotizacion)
		
				IF (@estatusActualCoti = 1)
					BEGIN
						--update fecha fin al status anterior de la cotización en el historial
						UPDATE [dbo].[HistorialEstatusCotizacion]
						SET [fechaFinal] = GETDATE()
						WHERE idCotizacion = @idcotizacion and (idEstatusCotizacion = 1 and fechaFinal is null)

						INSERT INTO [dbo].[HistorialEstatusCotizacion]([fechaInicial],[fechaFinal], [idCotizacion], [idUsuario], [idEstatusCotizacion])
						VALUES (GETDATE(), GETDATE(), @idcotizacion, @idusuario, 2)
					END
				ELSE IF (@estatusActualCoti = 2)
					BEGIN
						--update fecha fin al status anterior de la cotización en el historial
						UPDATE [dbo].[HistorialEstatusCotizacion]
						SET [fechaFinal] = GETDATE()
						WHERE idCotizacion = @idcotizacion and (idEstatusCotizacion = 2 and fechaFinal is null)
					END
		

				--pasar la cotización al estatus de cancelado (4)
				UPDATE Cotizaciones
				SET idEstatusCotizacion = 4
				WHERE idCotizacion = @idcotizacion

				--agregar al historial de la cotización el estatus de cancelado
				INSERT INTO [dbo].[HistorialEstatusCotizacion]([fechaInicial], [fechaFinal], [idCotizacion], [idUsuario], [idEstatusCotizacion])
				VALUES (GETDATE(), GETDATE(), @idcotizacion, @idusuario, 4)


				DECLARE @idAutorizacionCot numeric(18,0) = (SELECT [idAutorizacionCotizacion] 
														FROM [dbo].[AutorizacionCotizacion] 
														WHERE [idCotizacion]  = @idcotizacion)

				IF (@idAutorizacionCot IS NULL)
					BEGIN
						INSERT INTO [dbo].[AutorizacionCotizacion]
								   ([fechaAutorizacion], [idCotizacion])
							 VALUES
								   (GETDATE(), @idcotizacion)

						SET @idAutorizacionCot = @@IDENTITY
					END
				ELSE
					BEGIN
						UPDATE [dbo].[AutorizacionCotizacion]
						SET [fechaAutorizacion] = GETDATE()
						WHERE [idCotizacion] = @idcotizacion
					END


				--rechazar todas las partidas de la cotización
				UPDATE [dbo].[CotizacionDetalle]
				SET [idEstatusPartida] = 3
				WHERE [idCotizacion] = @idcotizacion
				
				DECLARE @idDetCot numeric(18,0)
				DECLARE Detalle_Cursor CURSOR FOR 
				SELECT idCotizacionDetalle 
				FROM [dbo].[CotizacionDetalle] 
				WHERE [idCotizacion] = @idcotizacion
				OPEN Detalle_Cursor

				FETCH NEXT FROM Detalle_Cursor INTO @idDetCot

				WHILE @@FETCH_STATUS = 0 
				BEGIN
					DECLARE @idDetalleAut  numeric(18,0) = (select [idDetalleAutorizacionCotizacion] from [dbo].[DetalleAutorizacionCotizacion] where [idCotizacionDetalle] = @idDetCot)

					IF (@idDetalleAut is null)
						BEGIN
							--INSERT
								INSERT INTO [dbo].[DetalleAutorizacionCotizacion]
										   ([fechaAutorizacion], [idUsuario], [idAprobacionCotizacion], [idEstatusAutorizacion], [idCotizacionDetalle])
									 VALUES
										   (GETDATE(), @idUsuario, @idAutorizacionCot, 3, @idDetCot)
						END
					ELSE
						BEGIN
							--UPDATE
								UPDATE [dbo].[DetalleAutorizacionCotizacion]
								   SET [fechaAutorizacion] = GETDATE()
									  ,[idUsuario] = @idusuario     
									  ,[idEstatusAutorizacion] = 3      
								 WHERE [idDetalleAutorizacionCotizacion] = @idDetalleAut
						END

					FETCH NEXT FROM Detalle_Cursor INTO @idDetCot
				END
			FETCH NEXT FROM Detalle_Cursor2 INTO @idcotizacion
		END
				CLOSE Detalle_Cursor; 
				DEALLOCATE Detalle_Cursor; 
		CLOSE Detalle_Cursor2; 
		DEALLOCATE Detalle_Cursor2; 

		--DECLARE @idOrden numeric(18,0) = (select idOrden from Cotizaciones coti where coti.idCotizacion = @idcotizacion)
		
		/*DECLARE @totalCotActivas int = (select count(*) 
										from [dbo].[Ordenes] Ord
										inner join [dbo].[Cotizaciones] Coti ON Coti.idOrden = Ord.idOrden
										where Coti.idEstatusCotizacion not in (4)
										and Ord.idOrden = @idOrden)*/

		--IF (@totalCotActivas = 0)
			--BEGIN
				--si ya no tiene cotizaciones activas (todas canceladas) se cambia la orden a estatus cancelado(10)
				UPDATE [dbo].[Ordenes]
				   SET [idEstatusOrden] = 10
				 WHERE idOrden = idOrden

				 UPDATE [dbo].HistorialEstatusOrden
					SET fechaFinal = GETDATE()
				  WHERE idOrden = @idOrden and fechaFinal is null

				  INSERT INTO [dbo].[HistorialEstatusOrden]
							   ([idOrden], [idEstatusOrden], [fechaInicial], [fechaFinal], [idUsuario])
						 VALUES
							   (@idOrden, 10, GETDATE(), GETDATE(), @idusuario)
				SELECT @idOrden
			--END
	END
END*/
go

