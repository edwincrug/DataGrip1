CREATE function [dbo].[fnNombreZona] (
	@idZona numeric(18,0),
	@idAux int
)
RETURNS VARCHAR(500)
as
begin

--DECLARE @idZona int=742

DECLARE @retorno VARCHAR(500)
DECLARE @idPadre int,@idPadrePadre int,@idNivelZona int
DECLARE @nombreZona VARCHAR(MAX)='',@nombrePadre VARCHAR(MAX)='',@nombreOficina VARCHAR(MAX)=''

SELECT @idPadre=Z.idPadre,@idNivelZona=Z.idNivelZona,@nombreZona= /*ISNULL(NZ.etiqueta,'')+': '+*/nombre FROM Partidas.dbo.Zona Z
	LEFT JOIN Partidas.dbo.NivelZona NZ ON NZ.idNivelZona=Z.idNivelZona
WHERE idZona=@idZona

SELECT @nombrePadre=/*ISNULL(NZ.etiqueta,'')+': '+*/NOMBRE,@idPadrePadre=Z.idPadre FROM Partidas.dbo.Zona Z
	LEFT JOIN Partidas.dbo.NivelZona NZ ON NZ.idNivelZona=Z.idNivelZona
WHERE idZona=@idPadre

SELECT @nombreOficina=/*ISNULL(NZ.etiqueta,'')+': '+*/ISNULL(nombre,'') FROM Partidas.dbo.Zona Z
	LEFT JOIN Partidas.dbo.NivelZona NZ ON NZ.idNivelZona=Z.idNivelZona
WHERE idZona=@idPadrePadre

SELECT @retorno=
CASE WHEN @nombreOficina<>'' THEN ISNULL(@nombreOficina+' / ','') ELSE '' END
+CASE WHEN @nombrePadre<>'' THEN ISNULL(@nombrePadre+' / ','') ELSE '' END
+ISNULL(@nombreZona,'') 

IF @idAux = 1
BEGIN
SET @retorno = ISNULL(@nombrePadre,'') 
END

IF @idAux = 2
BEGIN
SET @retorno = ISNULL(@nombreZona,'') 
END

IF @idAux = 3
BEGIN
SET @retorno = ISNULL(@nombreOficina,'') 
END

RETURN @retorno

end
go

