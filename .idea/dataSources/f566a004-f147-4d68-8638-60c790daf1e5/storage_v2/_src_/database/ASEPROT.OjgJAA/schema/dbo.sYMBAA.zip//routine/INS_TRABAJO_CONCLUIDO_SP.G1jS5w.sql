
-- ==========================================================================================
-- Author:		Uriel Godínez Martínez
-- Create date: 18/05/2016
-- Description:	Store que registra un trabajo como concluido (después de órden por pagar)

-- Author:		Carlos Adolfo Martinez Diosdado
-- Create date: 15/08/2016
-- Description:	Store que inserta a DatosCopadeOrden
--[INS_TRABAJO_CONCLUIDO_SP] '86425,',39402,3,1
-- ==========================================================================================
CREATE PROC [dbo].[INS_TRABAJO_CONCLUIDO_SP]
	@idOrden NVARCHAR(max),
	@idDatosCopade NUMERIC(18,0),
	@idContratoOperacion numeric(18,0) = null,
	@isProduction numeric(18,0) = null
AS
BEGIN

DECLARE @factorIVA decimal(18,2)

--    --DECLARE @idContratoOperacion numeric(18)=null
--	DECLARE @Query NVARCHAR(MAX) = ''
--	DECLARE @Base NVARCHAR(MAX) = ''	
--	DECLARE @idOrdenAux as numeric(18,0)
--	DECLARE @delimiter CHAR(1)=',' 
--    DECLARE @start INT, @end INT 
--	SELECT @start = 1, @end = CHARINDEX(@delimiter, @idOrden)
--	IF @start < LEN(@idOrden) + 1 BEGIN 
--        IF @end = 0  
--            SET @end = LEN(@idOrden) + 1
--            set @idOrdenAux=cast ((SUBSTRING(@idOrden, @start, @end - @start))as numeric(18,0)) 
--    END 

--	select @idContratoOperacion=idContratoOperacion from Ordenes where idOrden=@idOrdenAux
	
--	/*si es produccion*/
--	SELECT @base = cast(SERVER+'.'+DBProduccion as nvarchar(max))
--	FROM ContratoOperacionFacturacion COF 
--		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
--	WHERE CO.idContratoOperacion = @idContratoOperacion
	 
	
--	/*si es desarrollo*/
--	/*
--	SELECT @base = cast(SERVER+'.'+DB as nvarchar(max))
--	FROM ContratoOperacionFacturacion COF 
--		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
--	WHERE CO.idOperacion = @idContratoOperacion 
--	*/


--	set @query='
--	DECLARE @idOrden NVARCHAR(500)=cast(''' +@idOrden+''' as NVARCHAR)
--	DECLARE @idDatosCopade NUMERIC(18,0)='+cast(@idDatosCopade as nvarchar)+'
--	DECLARE @numeroOrden NVARCHAR(200)
--	DECLARE @xmlCopade NVARCHAR(MAX)
--	DECLARE @Posicion NUMERIC(18,0)
--	DECLARE @Orden NUMERIC(18,0)
--	DECLARE @idOrdenAgrupada NUMERIC(18,0)
--	DECLARE @idSiguiente NVARCHAR(MAX)
--	DECLARE @idDatosCopadeOrden NUMERIC(18,0)
--	DECLARE @numeroOrdenAgrupada NVARCHAR(200)

--    INSERT INTO OrdenAgrupada VALUES (''TA-''+ replace(replace(convert(VARCHAR(19), getdate(), 11) + convert(VARCHAR(19), getdate(), 108),''/'',''''),'':'',''''),
--	                                 GETDATE(), 
--									 1)
--	SET @idOrdenAgrupada = (SELECT @@IDENTITY AS ''idOrdenAgrupada'')

--WHILE patindex(''%,%'' , @idOrden) <> 0
--BEGIN
--  SELECT @Posicion =  patindex(''%,%'' ,@idOrden) 
--  SELECT @Orden = left(@idOrden, @Posicion - 1)
--  SET @Orden = CONVERT (numeric(18,0),@Orden)
--			UPDATE Ordenes
--		    SET idEstatusOrden = 14
--			WHERE idOrden = @Orden
            
--			update HistorialEstatusOrden 
--			set fechaFinal=GETDATE()
--			where idOrden=@Orden and idEstatusOrden=8
			
--			INSERT INTO HistorialEstatusOrden
--			VALUES (@Orden,14, GETDATE(),null, 529)

--  			INSERT INTO DatosCopadeOrden 
--			VALUES(@idDatosCopade, @Orden, GETDATE())

--			SET @idDatosCopadeOrden = (SELECT @@IDENTITY AS ''idDatosCopadeOrden'')
--			select *from OrdenAgrupadaDetalle
--			INSERT INTO OrdenAgrupadaDetalle(idOrdenAgrupada, idDatosCopadeOrden, fechaAsignacion)
--		    VALUES (@idOrdenAgrupada, @idDatosCopadeOrden, GETDATE())
			
--			SELECT @numeroOrdenAgrupada=numero FROM OrdenAgrupada WHERE idOrdenAgrupada=@idOrdenAgrupada
--		    SELECT @xmlCopade=xmlCopade FROM DatosCopade WHERE idDatosCopade=@idDatosCopade

--			SELECT @numeroOrden=numeroOrden FROM Ordenes WHERE idOrden=@Orden

--			UPDATE '+@base+'.[dbo].[ADE_ORDSERENC]
--            SET OTE_ORDENGLOBAL=@numeroOrdenAgrupada
--            WHERE OTE_ORDENANDRADE=@numeroOrden

--		SELECT @idOrden = stuff(@idOrden, 1, @Posicion, '''')
--	END

--	INSERT INTO '+@base+'.[dbo].[ADE_COPADE](COP_ORDENGLOBAL,COP_COPADE,COP_CVEUSU,COP_FECHOPE,COP_HORAOPE,COP_IDDOCTO,COP_STATUS)
--	VALUES (@numeroOrdenAgrupada,@xmlCopade,''GMI'', CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(VARCHAR(8),GETDATE(),108),NULL,''1'')
	
--	SELECT ''1'' as id
	
--	'
--	EXECUTE SP_EXECUTESQL @query
--	--select @Query

	
	DECLARE @Base NVARCHAR(MAX) = ''	
	DECLARE @queryString NVARCHAR(MAX) = ''
	DECLARE @queryInsert NVARCHAR(MAX) = ''
	DECLARE @FechaVCra VARCHAR(10) = ''
	DECLARE @FechaCra VARCHAR(10) = ''
	DECLARE @numCopade VARCHAR(50) = ''
	DECLARE @SubtotalCopadeConsolidada DECIMAL(18,2)
	DECLARE @queryupdateEncLet NVARCHAR(MAX)

	if (@isProduction = 1)
		begin
			SELECT @Base = cast(COF.[SERVER]+'.'+DBProduccion as nvarchar(max))
			FROM ContratoOperacionFacturacion COF 
			WHERE COF.idContratoOperacion = @idContratoOperacion
		end
	else
		begin
			SELECT @Base = cast(COF.[SERVER]+'.'+DB as nvarchar(max))
			FROM ContratoOperacionFacturacion COF 
			WHERE COF.idContratoOperacion = @idContratoOperacion 
		end
	
	DECLARE @idOrdenAgrupada NUMERIC(18,0)
	DECLARE @numeroOrdenAgrupada NVARCHAR(200)
	DECLARE @numeroOrden NVARCHAR(200)
	DECLARE @xmlCopade NVARCHAR(MAX)
	DECLARE @Posicion NUMERIC(18,0)
	DECLARE @Trabajo NUMERIC(18,0)
	DECLARE @idDatosCopadeOrden NUMERIC(18,0)

	INSERT INTO OrdenAgrupada VALUES ('TA-'+ replace(replace(convert(VARCHAR(19), getdate(), 11) 
	+ CONVERT(VARCHAR(15),@idDatosCopade) +
	convert(VARCHAR(19), getdate(), 108),'/',''),':',''),GETDATE(),1) 

	SET @idOrdenAgrupada = (SELECT @@IDENTITY AS 'idOrdenAgrupada')
	PRINT 'idOrdenAgrupada'
	PRINT @idOrdenAgrupada
	PRINT 'IDORDE'
	PRINT @idOrden
WHILE patindex('%,%' , @idOrden) <> 0
BEGIN
  SELECT @Posicion =  patindex('%,%' , @idOrden)
  SELECT @Trabajo = left(@idOrden, @Posicion - 1)
  SET @Trabajo = CONVERT (numeric(18,0),@Trabajo)
			
			--SELECT @factorIVA = [dbo].[fnFactorIVA_Orden](O.idOrden ,1) from Ordenes O
			--WHERE O.idOrden=@Trabajo

			IF NOT EXISTS(SELECT TOP(1)* FROM DatosCopadeOrden WHERE idOrden = @Trabajo)
			BEGIN
				UPDATE Ordenes 
		    SET idEstatusOrden = 14
			WHERE idOrden = @Trabajo

			UPDATE HistorialEstatusOrden 
			set fechaFinal=GETDATE()
			where idOrden=@Trabajo and idEstatusOrden=8
			
			INSERT INTO HistorialEstatusOrden
			VALUES (@Trabajo, 14, GETDATE(),null, 529)

  			INSERT INTO DatosCopadeOrden 
			VALUES(@idDatosCopade, @Trabajo, GETDATE())
			PRINT 'IDIDATOSCOPADE'
			PRINT @idDatosCopade
			SET @idDatosCopadeOrden = (SELECT @@IDENTITY AS 'idDatosCopadeOrden')

			INSERT INTO OrdenAgrupadaDetalle (idOrdenAgrupada, idDatosCopadeOrden, fechaAsignacion)
		    VALUES (@idOrdenAgrupada, @idDatosCopadeOrden, GETDATE())
			
			SELECT @numeroOrdenAgrupada=numero FROM OrdenAgrupada WHERE idOrdenAgrupada=@idOrdenAgrupada
		    SELECT @xmlCopade=REPLACE(xmlCopade,'''',''), @numCopade = numeroCopade, @FechaCra = CONVERT(varchar(10), fechaRecepcionCopade, 103), @FechaVCra = CONVERT(varchar(10), DATEADD(DAY, 90, fechaRecepcionCopade), 103) 
			FROM DatosCopade WHERE idDatosCopade=@idDatosCopade
			
			SELECT @numeroOrden=numeroOrden FROM Ordenes WHERE idOrden=@Trabajo
			
			set @queryString = '
			UPDATE '+@Base+'.[dbo].[ADE_ORDSERENC]
            SET OTE_ORDENGLOBAL='''+@numeroOrdenAgrupada+'''
            WHERE OTE_ORDENANDRADE='''+@numeroOrden+'''
            '

            EXECUTE SP_EXECUTESQL @queryString
			

			--SET @queryupdateEncLet = 'UPDATE B
			--		SET B.OTE_DESGLOSE = ''A''
			--		FROM '+@Base+'.dbo.ADE_ORDSERENC B
			--		INNER JOIN 
			--		(SELECT OTE_ORDENGLOBAL, 
			--		CASE
			--			 WHEN count(OTE_ORDENGLOBAL) > 1 THEN 
			--				 1 END S 
			--		FROM '+@Base+'.dbo.ADE_ORDSERenc group by OTE_ORDENGLOBAL) A ON A.S is not null AND A.OTE_ORDENGLOBAL = ' + ''''+@numeroOrdenAgrupada+''''
            
			--EXECUTE SP_EXECUTESQL @queryupdateEncLet

			DECLARE @queryText NVARCHAR(MAX) = ''
			SET @queryText = '
			SELECT OTE_IDPROVEEDOR FROM '+@Base+'.[dbo].[ADE_ORDSERENC] 
            WHERE OTE_ORDENANDRADE='''+@numeroOrden+'''
            '
			print @queryText
			declare @tabletemp table(val int)
			insert into @tabletemp exec(@queryText) 

			SELECT @idOrden = stuff(@idOrden, 1, @Posicion, '')
		END
			ELSE
			BEGIN
				BREAK;
			END
	END
	
	PRINT @Base

	set @queryInsert = '
	INSERT INTO '+@Base+'.[dbo].[ADE_COPADE](COP_ORDENGLOBAL,COP_COPADE,COP_CVEUSU,COP_FECHOPE,COP_HORAOPE,COP_IDDOCTO,COP_STATUS)
	VALUES ('''+@numeroOrdenAgrupada+''','''+@xmlCopade+''',''GMI'', CONVERT(VARCHAR(10),GETDATE(),103),CONVERT(VARCHAR(8),GETDATE(),108),NULL,''1'')
	'	
	PRINT @queryInsert
	EXECUTE SP_EXECUTESQL @queryInsert

	IF ((select top 1 val from @tabletemp) = 2073 and @idContratoOperacion = 3)
		BEGIN
			EXEC INS_TRABAJO_CONCLUIDO_CONCAR_SP @numCopade, @FechaCra, @FechaVCra, @numeroOrden, @idContratoOperacion, @isProduction
		END
	ELSE IF((select top 1 val from @tabletemp) = 263867 and @idContratoOperacion = 3)
		BEGIN
			EXEC INS_TRABAJO_CONCLUIDO_CONCAR_CAM_EUROP_SP @numCopade, @FechaCra, @FechaVCra, @numeroOrden, @idContratoOperacion, @isProduction
		END
	ELSE IF((select top 1 val from @tabletemp) = 84814 and @idContratoOperacion = 3)
		BEGIN
			EXEC INS_TRABAJO_CONCLUIDO_CONCAR_TOTAL_PARTS_SP @numCopade, @FechaCra, @FechaVCra, @numeroOrden, @idContratoOperacion, @isProduction
		END
	ELSE IF EXISTS (SELECT PG.IdParametroGeneral FROM ParametrosGeneral PG
				INNER JOIN ParametrosGeneralOperacion PGO ON PG.IdParametroGeneral = PGO.IdParametroGeneral
				INNER JOIN ContratoOperacion CO ON PGO.IdOperacion = CO.IdOperacion
				WHERE CO.IdContratoOperacion = @idContratoOperacion AND PG.IdParametroGeneral = 2 AND PG.Estatus = 1 AND PGO.Estatus = 1) 
		BEGIN
			-- Facturación consolidada para operaciones sin copades y sin presupuesto
			SET @SubtotalCopadeConsolidada = (
			SELECT 
				SUM(TOTAL.venta)
				FROM
					(SELECT 
						(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, 107, 2)) AS venta
							FROM DATOSCOPADE DC
							INNER JOIN DATOSCOPADEORDEN DCO ON DCO.IDDATOSCOPADE = DC.IDDATOSCOPADE
							INNER JOIN ORDENES O ON O.IdOrden = DCO.IdOrden
							WHERE DC.IDDATOSCOPADE = @idDatosCopade
						)AS TOTAL
			)
			
			UPDATE DATOSCOPADE SET SUBTOTAL = @SubtotalCopadeConsolidada, TOTAL = (@SubtotalCopadeConsolidada*1.16) WHERE IDDATOSCOPADE = @idDatosCopade
		END
	SELECT '1' as id
	
END

go

