--   [UPD_CANCELA_ORDEN_SP] 23, 8 
CREATE PROC [dbo].[EXT_UPD_CANCELA_ORDEN_SP]
	@idUsuario numeric(18,0),
	@idOrden numeric(18,0)
AS
BEGIN
    DECLARE @idOrdenes NUMERIC(18,0)
	DECLARE @existeOrden NUMERIC(18,0)
	DECLARE @cantidadCotizaciones NUMERIC(18,0)
	DECLARE @cantidadCotizacionesAutorizadas NUMERIC(18,0)
	DECLARE @pendientes NUMERIC(18,0)
	DECLARE @autorizadas NUMERIC(18,0)
	DECLARE @rechazadas NUMERIC(18,0)
	DECLARE @idAutorizacion INT
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @max NUMERIC(18,0)
	DECLARE @existePresupuesto NUMERIC(18,0)
	DECLARE @existePresupuestoEspecial NUMERIC(18,0)
	DECLARE @existeDocumento  NUMERIC(18,0)

	SET @idOrdenes = (SELECT idOrden FROM Ordenes where idOrden = @idOrden)
	SELECT @existeOrden = COUNT(1) FROM Ordenes WHERE idOrden = @idOrden

	IF NOT EXISTS(SELECT idOrden FROM Ordenes where idOrden = @idOrden AND idEstatusOrden = 13)
	 BEGIN
		IF(@existeOrden > 0)
		BEGIN
			SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden
			SELECT @max = MAX(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden
			WHILE(@idCotizacion <= @max)
				BEGIN	
					--ACTUALIZA LA COTIZACIÓN A rechazada
					UPDATE Cotizaciones SET idEstatusCotizacion = 4 WHERE idCotizacion = @idCotizacion

					--ELIMINA DE FACTURA COTIZACION
					DELETE FROM ASEPROT.dbo.facturaCotizacion where idCotizacion = @idCotizacion 

					INSERT INTO [dbo].[HistorialEstatusCotizacion]([fechaInicial], [fechaFinal], [idCotizacion], [idUsuario], [idEstatusCotizacion])
					VALUES (GETDATE(), GETDATE(), @idCotizacion, @idUsuario, 4)

					--ACTUALIZA EL DETALLE DE LA COTIZACIÓN A rechazada
					UPDATE CotizacionDetalle SET idEstatusPartida = 3 WHERE idCotizacion = @idCotizacion
		
					SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden AND idCotizacion > @idCotizacion
				END
		
			  --REALIZA EL CONTEO DEL NÚMERO DE COTIZACIONES EN LA ORDEN
			SELECT @pendientes = X.pendientes, 
				   @autorizadas = X.autorizadas, 
				   @rechazadas =  X.rechazadas 
			FROM (SELECT 
					pendientes = (SELECT COUNT(C.idEstatusCotizacion)
						FROM Ordenes O
						JOIN Cotizaciones C ON C.idOrden = O.idOrden
						WHERE O.idOrden = @idOrden AND C.idEstatusCotizacion IN (1,2)),
					autorizadas = (SELECT  COUNT(C.idEstatusCotizacion)
						FROM Ordenes O
						JOIN Cotizaciones C ON C.idOrden = O.idOrden
						WHERE O.idOrden = @idOrden AND C.idEstatusCotizacion IN (3)),
					rechazadas = (SELECT  COUNT(C.idEstatusCotizacion)
						FROM Ordenes O
						JOIN Cotizaciones C ON C.idOrden = O.idOrden
						WHERE O.idOrden = @idOrden AND C.idEstatusCotizacion IN (4)))X

		IF(@pendientes = 0 AND @autorizadas = 0)
			BEGIN
				--REXE
				DECLARE @idEsatusOrden int = 0

				set @idEsatusOrden = (SELECT idEstatusOrden FROM Ordenes WHERE idOrden = @idOrden)

				INSERT INTO OrdenesCanceladas VALUES (@idOrden, GETDATE(),@idusuario,@idEsatusOrden,1)
				--REXE

				--ACTUALIZA LA ORDEN A Orden cancelada
				UPDATE Ordenes SET idEstatusOrden = 13 WHERE idOrden = @idOrden
			
				--Poner fecha final en el estatus anterior
				Update [dbo].[HistorialEstatusOrden] set fechaFinal= GETDATE() where idOrden= @idOrden and fechaFinal is null

				-- DEJA RASTRO EN HISTORIALPROCESO
				INSERT INTO [dbo].[HistorialEstatusOrden]([idOrden], [idEstatusOrden], [fechaInicial], [fechaFinal], [idUsuario])
				VALUES(@idOrden, 13, GETDATE(), null, @idusuario)

				--Valora si existen registros en tabla de documentoOrden

				SELECT @existeDocumento= COUNT(*) FROM ASEPROT.DBO.DocumentosOrdenes where idOrden= @idOrden 
				IF(@existeDocumento >0)
				BEGIN
				---Eliminar registro en DocumentoOrden
					DELETE FROM ASEPROT.DBO.DocumentosOrdenes where idOrden= @idOrden 
				END

				 --Valora si existen registro en la tabla presupuestos 
				SELECT @existePresupuesto= COUNT(*) FROM PresupuestoOrden where idOrden= @idOrden 

				IF(@existePresupuesto >0)
				BEGIN
				DECLARE @idOrdenPresupuesto numeric(18,0)
				DECLARE @idPresupuesto numeric(18,0)

				--Se crea un cursor el cual itera sobre los registros que están en la tabla de presupuestos
				DECLARE PresupuestoInfo CURSOR FOR SELECT idOrden,idPresupuesto FROM PresupuestoOrden WHERE idOrden=@idOrden 
			
				--Se abre el cursor 
				OPEN PresupuestoInfo 
				FETCH NEXT FROM PresupuestoInfo INTO @idOrdenPresupuesto, @idPresupuesto
				--Se inicia el ciclo
				WHILE @@fetch_status= 0
					BEGIN
					--Inserta el registro en bitacora por cada registro a borrar
					INSERT INTO Bitacora (IdUsuario, fechaBitacora, tabla, idOrden, operacion) VALUES (@idusuario, GETDATE(), 'PresupuestoOrden', @idOrdenPresupuesto, 'Eliminado del presupuesto numero ' +Cast( @idPresupuesto as varchar(25)))
				
					FETCH NEXT FROM PresupuestoInfo INTO @idOrdenPresupuesto, @idPresupuesto
					END
					--Se cierra y se libera el cursor
				CLOSE PresupuestoInfo
				DEALLOCATE PresupuestoInfo


					---Eliminar registro en Presupuesto Orden
					DELETE FROM PresupuestoOrden WHERE idOrden= @idOrden
				END
				--Valida si existe registros en la tabla presupuestos especiales
				SELECT @existePresupuestoEspecial = COUNT(*) FROM OrdenesPresupuestoEspecial where idOrden= @idOrden
			
				IF(@existePresupuestoEspecial >0)
				BEGIN
				DECLARE @idPresupuestoEspecial numeric(18,0)
				DECLARE @idOrdenPresupuestoEspecial numeric(18,0)
				--Se crea el cursor el cual itera sobre los registros que están en la tabla de Presupuestos especiales
				DECLARE PresupuestoEspecialInfo CURSOR FOR SELECT idOrdenPresupuestoEspecial, idOrden FROM OrdenesPresupuestoEspecial WHERE idOrden= @idORden
				--Se abre el cursor
				OPEN PresupuestoEspecialInfo 
			
				FETCH NEXT FROM PresupuestoEspecialInfo INTO @idPresupuestoEspecial,@idOrdenPresupuestoEspecial
			
				--Se inicia el ciclo
				WHILE @@fetch_status= 0
					BEGIN
						--inserta en bitacora por cada registro que contiene la tabla
						INSERT INTO Bitacora(IdUsuario, fechaBitacora, tabla, idOrden, operacion) VALUES (@idusuario, GETDATE(), 'OrdenesPresupuestoEspecial', @idOrdenPresupuestoEspecial, 'Eliminado del presupuesto especial ' + Cast(@idPresupuestoEspecial as varchar(25)))
					
						FETCH NEXT FROM PresupuestoEspecialInfo INTO @idPresupuestoEspecial,@idOrdenPresupuestoEspecial
					END
					--Se cierra y libera el cursor
				CLOSE PresupuestoEspecialInfo
				DEALLOCATE PresupuestoEspecialInfo

					--Elimina registros en OrdenesPresupuestoEspecial
					DELETE FROM OrdenesPresupuestoEspecial where idOrden= @idOrden
				END


				SELECT @@IDENTITY
			END
		END 
	END
SELECT 10;
END
go

