
CREATE PROCEDURE [Banorte].[SEL_TALLER_SP] --18, '','GASOLINA', '', 6
--EXECUTE [Banorte].[SEL_TALLER_SP]  18, '','GASOLINA', '', 6
	 @idContratoOperacion INT
	,@Taller VARCHAR(50) = ''
	,@TipoCombustible VARCHAR(30) = ''
	,@Estado VARCHAR(30) = ''
	,@Zona VARCHAR(30) = ''
AS
BEGIN

--////////////////BUSQUEDA POR TALLER ///////////////////
	IF @Taller != '' and @TipoCombustible != '' and @Zona != ''
		BEGIN
			SELECT DISTINCT
			UPPER(PP.idProveedor) as Id
			,UPPER(PP.nombreComercial + ' - ' + PP.razonSocial) as Nombre
			,UPPER(PP.direccion) as Direccion
			--,UPPER(PPE.estado) as Estado
			,UPPER(PTC.tipoCombustible) as TipoCombustible
			,PP.mail
			,PP.isGenerico
			,PP.numInterlocutor
			 FROM [Partidas].[dbo].[Proveedor] PP
			--INNER JOIN partidas..ProveedorEncabezado PPE ON PP.idProveedorEncabezado = PPE.idProveedorEncabezado
			INNER JOIN partidas..[ProveedorEspecialidadCombustible] PPC ON PPC.idProveedor = PP.idProveedor
			INNER JOIN partidas..[TipoCombustible] PTC ON PTC.idTipoCombustible = PPC.idTipoCombustible
			INNER JOIN ASEPROT.dbo.ContratoOperacion CO ON CO.idContratoOperacion=@idContratoOperacion
			INNER JOIN Partidas.dbo.Contrato C ON C.idContrato = CO.idContrato
			INNER JOIN Partidas.dbo.ContratoProveedor CP on CP.idContrato = C.idContrato and CP.idProveedor=PP.idProveedor
			INNER JOIN Partidas.dbo.ContratoProveedorZona CPZ on CP.idContratoProveedor = CPZ.idContratoProveedor
			WHERE PP.nombreComercial like '%' + @Taller + '%'
			AND CPZ.idZona = @Zona			
			and PTC.tipoCombustible = @TipoCombustible  
			and pp.isGenerico = 1
		END

--////////////////BUSQUEDA POR TIPO DE COMBUSTIBLE ///////////////////

	IF @Taller = '' and @TipoCombustible != '' and @Zona != ''
		BEGIN
			SELECT DISTINCT
			UPPER(PP.idProveedor) as Id
			,UPPER(PP.nombreComercial  + ' - ' + PP.razonSocial) as Nombre
			,UPPER(PP.direccion) as Direccion
			--,UPPER(PPE.estado) as Estado
			,UPPER(PTC.tipoCombustible) as TipoCombustible
			,PP.mail
			,PP.isGenerico
			,PP.numInterlocutor
			 FROM [Partidas].[dbo].[Proveedor] PP
			--INNER JOIN partidas..ProveedorEncabezado PPE ON PP.idProveedorEncabezado = PPE.idProveedorEncabezado
			INNER JOIN partidas..[ProveedorEspecialidadCombustible] PPC ON PPC.idProveedor = PP.idProveedor
			INNER JOIN partidas..[TipoCombustible] PTC ON PTC.idTipoCombustible = PPC.idTipoCombustible
			INNER JOIN ASEPROT.dbo.ContratoOperacion CO ON CO.idContratoOperacion=@idContratoOperacion
			INNER JOIN Partidas.dbo.Contrato C ON C.idContrato = CO.idContrato
			INNER JOIN Partidas.dbo.ContratoProveedor CP on CP.idContrato = C.idContrato and CP.idProveedor=PP.idProveedor
			INNER JOIN Partidas.dbo.ContratoProveedorZona CPZ on CP.idContratoProveedor = CPZ.idContratoProveedor
			WHERE CPZ.idZona = @Zona			
			and PTC.tipoCombustible = @TipoCombustible  
			and pp.isGenerico = 1
		END
END


go

grant execute, view definition on Banorte.SEL_TALLER_SP to DevOps
go

