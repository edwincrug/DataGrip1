
/*
	Objetivo: Acutalizar el campo de factura en la tabla de códigosde promoción desde BPro

	Fecha			Autor			Descripción
	27-JuL-2018		José Etmanuel	Se crea el SP 
	31-Jul-2018		José Etmanuel	Cambio la salida por una variable OUTPUT

	declare @ok int;
	EXEC [Banorte].[APP_FACTURAR_CODIGO_BPRO] 816765,'N0023032','UIDD654DSDS',@ok OUTPUT
	SELECT @ok status
*/

CREATE PROCEDURE [Banorte].[APP_FACTURAR_CODIGO_BPRO] 
	@codigo varchar(max),
	@idOrdenBpro varchar(max),
	@UIDD varchar(max),
	@status int OUTPUT 
AS   
BEGIN
	SET @status = 0;

	IF EXISTS (SELECT * FROM [Banorte].[PromocionesCodigosDet] WHERE  [Codigo]= @codigo AND [IdOrdenBpro] = @idOrdenBpro AND isnull(BCancelBpro,0) != 1)
	BEGIN
		PRINT 'Código actualizado';
		SET @status = 1;
		
		UPDATE [Banorte].[PromocionesCodigosDet] 
			SET  [FacturaBpro]= @UIDD
		WHERE  [Codigo]= @codigo AND [IdOrdenBpro] = @idOrdenBpro AND  isnull(BCancelBpro,0) != 1
	END
	
	ELSE
	BEGIN
		PRINT 'No se encontró el código con esa órden';
	END
END
go

grant execute, view definition on Banorte.APP_FACTURAR_CODIGO_BPRO to DevOps
go

