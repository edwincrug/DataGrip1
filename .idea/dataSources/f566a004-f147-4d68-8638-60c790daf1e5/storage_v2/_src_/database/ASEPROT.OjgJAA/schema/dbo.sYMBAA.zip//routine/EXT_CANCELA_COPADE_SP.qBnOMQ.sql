
CREATE PROCEDURE [dbo].[EXT_CANCELA_COPADE_SP] --'5015290943'
@numeroCopade nvarchar(50)

AS
BEGIN

DECLARE @idDatosCopade INT
DECLARE @idDatosCopadeOrden INT
DECLARE @idOrdenAgrupada INT
DECLARE @idOrdenAgrupadaDetalle INT
DECLARE @numero NVARCHAR(100)

	IF EXISTS (SELECT idDatosCopade FROM DatosCopade WHERE numeroCopade=@numeroCopade)
		BEGIN
			SELECT @idDatosCopade=idDatosCopade FROM DatosCopade WHERE numeroCopade=@numeroCopade
			SELECT @idDatosCopadeOrden=idDatosCopadeOrden FROM DatosCopadeOrden WHERE idDatosCopade=@idDatosCopade
			SELECT @idOrdenAgrupadaDetalle=idOrdenAgrupadaDetalle, @idOrdenAgrupada=idOrdenAgrupada FROM OrdenAgrupadaDetalle where idDatosCopadeOrden=@idDatosCopadeOrden
			SELECT @numero=numero FROM OrdenAgrupada WHERE idOrdenAgrupada=@idOrdenAgrupada

			DELETE FROM OrdenAgrupadaDetalle
			WHERE idDatosCopadeOrden=@idDatosCopadeOrden

			DELETE FROM OrdenAgrupada
			WHERE idOrdenAgrupada=@idOrdenAgrupada

			DELETE FROM DatosCopadeOrden
			WHERE idDatosCopade=@idDatosCopade

			DELETE FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_COPADE]
		    WHERE COP_ORDENGLOBAL=@numero

		END
	ELSE
		BEGIN
			 PRINT 'LA EL NUMERO DE COPADE NO EXISTE'
		END
END

go

