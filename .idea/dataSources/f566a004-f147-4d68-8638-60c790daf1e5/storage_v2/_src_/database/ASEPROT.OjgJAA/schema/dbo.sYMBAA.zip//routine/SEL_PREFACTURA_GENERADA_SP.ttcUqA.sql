CREATE PROCEDURE [dbo].[SEL_PREFACTURA_GENERADA_SP] (
	@idUsuario numeric(18,0),
	@idContratoOperacion numeric(20) = null,
	@isProduction numeric(20) = null,
	@idZona int = null,
	@idEjecutivoFiltro INT = null,
	@fechaIni varchar(max) = null,--'2017/10/01 00:00:00',
	@fechaFin varchar(max) = null--'2017/10/30 23:59:59'
)
as
begin

	DECLARE @isProveedor NUMERIC(18,0)
	DECLARE @select NVARCHAR(MAX) = ''
	DECLARE	@join	NVARCHAR(MAX) = ''
	DECLARE	@where  NVARCHAR(MAX) = ''
	DECLARE	@query  NVARCHAR(MAX) = ''
	DECLARE	@usuario  NVARCHAR(MAX) = ''
	SELECT  @isProveedor = case idCatalogoTipoUsuarios 
	                       when 4 then 1
	                       else 0 
	                       end 
	from Usuarios where idUsuario=@idUsuario 

	DECLARE	@server  NVARCHAR(MAX) = ''
		DECLARE	@db  NVARCHAR(MAX) = ''		

		IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server = SERVER,
				@db = DBProduccion			
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idContratoOperacion =  @idContratoOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idContratoOperacion =  @idContratoOperacion
	END


	SET @select =
	
	'
			SELECT DISTINCT (SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+cast(@idContratoOperacion as varchar)+')) AS nombreCliente ,
			dc.idDatosCopade As idCopade,
			dc.numeroCopade As numeroCopade,
			dc.ordensurtimiento As ordenSurtimiento,
			dc.numeroEstimacion As numeroEstimaicon,
			dc.descripcion As descripcion,
			dc.subTotal As subTotal,
			dc.total As Total,
			ade.COP_IDDOCTO,
			dc.fechaRecepcionCopade As fechaCopade,
			(SELECT [dbo].[SEL_TALLERES_COPADE_FN](dco.idDatosCopade)) AS taller

				FROM '+@server+'.'+@db+'.[dbo].[ADE_COPADE] ade
			inner join OrdenAgrupada OA on OA.numero = ade.COP_ORDENGLOBAL COLLATE SQL_Latin1_General_CP1_CI_AS
			inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
			inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
			inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
			inner join Ordenes o on o.idOrden = dco.idOrden and o.idContratoOperacion = '+cast(@idContratoOperacion as varchar)


 IF(@isProveedor = 1)
		BEGIN
			SET @join =
				' inner join Cotizaciones c on c.idOrden=o.idOrden '

			SET @where = 
				' 
				 where c.idTaller in (
                            select coup.idProveedor from ContratoOperacionUsuario cou 
                                  join ContratoOperacionUsuarioProveedor coup on cou.idContratoOperacionUsuario=coup.idContratoOperacionUsuario and cou.idUsuario ='+CONVERT(varchar(20), @idUsuario)+'
	             ) 
				and O.idZona = COALESCE('+COALESCE(convert(varchar(max),@idZona),'NULL')+', O.idZona)
				and O.idUsuario = COALESCE(' + COALESCE(convert(varchar(max),@idEjecutivoFiltro),'NULL')+ ',O.idUsuario)
				and dc.fechaRecepcionCopade between COALESCE(' + COALESCE(''''+@fechaIni+'''', 'NULL') + ',dc.fechaRecepcionCopade) and COALESCE(' + COALESCE(''''+@fechaFin+'''', 'NULL') + ',dc.fechaRecepcionCopade)'
				
		END
	ELSE 
		BEGIN
			SET @where = ' 
			where ade.COP_STATUS = 1 
			and O.idZona = COALESCE('+COALESCE(convert(varchar(max),@idZona),'NULL')+', O.idZona)
			and O.idUsuario = COALESCE(' + COALESCE(convert(varchar(max),@idEjecutivoFiltro),'NULL')+ ',O.idUsuario)
			and dc.fechaRecepcionCopade between COALESCE(' + COALESCE(''''+@fechaIni+'''', 'NULL') + ',dc.fechaRecepcionCopade) and COALESCE(' + COALESCE(''''+@fechaFin+'''', 'NULL') + ',dc.fechaRecepcionCopade)'
				
		END
	
	SET @query = @select+@join+@where
	EXECUTE SP_EXECUTESQL @query 
	print @query

	END





	/*

	SELECT
		cli.razonSocial AS cliente,
		ord.consecutivoOrden AS consecutivo,
		ord.numeroOrden AS numeroOrden,
		coi.numeroCotizacion AS numeroCotizacion,
		--Cecos
		'000134' as ordenPago,
		'43256' as ceco,
		--columnas de proveeor
		'F01' as facturaProveedor,
		0.00 as montoFacturaProveedor,
		0.00 as saldoFacturaProveedor,
		--columnas de cliente
		'A001' as facturaCliente,
		0.00 as montoFacturaCliente,
		0.00 as abonoFacturaCliente,
		0.00 as saldoFacturaCliente,
		0.00 as fechaPagoFacturaCliente,
		---
		uni.numeroEconomico AS economico,
		uni.placas AS placas,
		--zonas dinámicas
		'' AS proveedor,
		tor.nombreTipoORden AS tipoOrden,
		'' AS centroTrabajo,
		'' AS provision,
		'' AS ventasiniva,
		eor.nombreEstatusOrden AS estatus
	FROM
		Ordenes ord
	LEFT JOIN EstatusOrdenes eor ON eor.idEstatusOrden = ord.idEstatusOrden
	LEFT JOIN Cotizaciones coi ON coi.idOrden = ord.idOrden
	LEFT JOIN Partidas.dbo.Proveedor pro ON pro.idProveedor = coi.idTaller
	LEFT JOIN dbo.ContratoOperacion cop ON cop.idContratoOperacion = ord.idContratoOperacion
	LEFT JOIN Partidas.dbo.Contrato con ON con.idContrato = cop.idContrato
	LEFT JOIN Partidas.dbo.Licitacion lic ON lic.idLicitacion = con.idLicitacion
	LEFT JOIN Partidas.dbo.Cliente cli ON cli.idCliente = lic.idCliente
	LEFT JOIN dbo.Unidades uni ON uni.idUnidad = ord.idUnidad
	LEFT JOIN [dbo].[CatalogoTipoOrden] tor ON tor.idTipoOrden = ord.idTipoOrden --JOIN CECOS
	WHERE
		ord.idOrden = 99999

end



	*/
go

