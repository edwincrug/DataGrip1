
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORTE_PROVEEDOR_DISPERSION_SP]
	-- Add the parameters for the stored procedure here
	@fechaInicial as VARCHAR(max) = null,
    @fechaFinal as VARCHAR(max) = NULL
AS
BEGIN
	SELECT 
		'0' as idProveedor,
		'1' AS Proveedor,
		'2' as Costo,
		'3' as PorcentajeCosto,
		'4' as Venta,
		'5' as PorcentajeVenta,
		'6' as Cantidad,
		'7' as PorcentajeServicio
	from ContratoOperacionUsuarioProveedor
END
go

