-- =============================================
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- [DEL_MODULO_SP]
-- =============================================
 CREATE PROCEDURE [dbo].[DEL_MODULO_SP]
	@idModulo NUMERIC(18, 0)
AS
BEGIN

	DELETE FROM Modulos
	WHERE idModulo=@idModulo

	SELECT 1
			
END



go

