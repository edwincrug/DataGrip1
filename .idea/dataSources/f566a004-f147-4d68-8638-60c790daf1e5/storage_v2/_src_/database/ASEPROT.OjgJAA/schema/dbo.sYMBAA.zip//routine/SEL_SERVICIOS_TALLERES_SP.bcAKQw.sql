-- =============================================
-- Description:	Obtiene los servicios(especialidades) que pueden dar los talleres para el tipo de unidad y el tipo de contrato 
-- =============================================
-- [dbo].[SEL_SERVICIOS_TALLERES_SP] @idUsuario = 2,  @numeroEconomico = '1633010407099'
CREATE PROCEDURE [dbo].[SEL_SERVICIOS_TALLERES_SP] 
	@idUsuario  NUMERIC(18,0),
	@numeroEconomico NVARCHAR(30)
AS
BEGIN
	DECLARE @idUnidad INT  
	SELECT @idUnidad = idUnidad
	  FROM [dbo].[Unidades]
	 WHERE numeroEconomico = @numeroEconomico
	------Obtengo la ip del servidor donde se encuntra la BD Partidas
	DECLARE @query NVARCHAR(MAX)=''
	
	-----------------------------------------------------------------	
	SET @query = 'IF(EXISTS(SELECT	*' + char(13) + 
				 '			FROM	[dbo].[Unidades] UNI' + char(13) + 
				 '					INNER JOIN [dbo].[ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion' + char(13) + 
				 '					INNER JOIN .[Partidas].[dbo].[ContratoUnidad] CU ON CU.idContrato = CP.idContrato' + char(13) + 
				 '					INNER JOIN .[Partidas].[dbo].[Unidad] UNIP ON UNIP.idUnidad = CU.idUnidad' + char(13) + 
				 '					INNER JOIN .[Partidas].[dbo].[TipoUnidad] TU ON TU.idTipoUnidad = UNIP.idTipoUnidad' + char(13) + 
				 '					INNER JOIN .[Partidas].[dbo].[ProveedorTipoUnidad] PTU ON TU.idTipoUnidad = PTU.idTipoUnidad' + char(13) + 
				 '					INNER JOIN .[Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = PTU.idProveedor' + char(13) + 
				 '					INNER JOIN .[Partidas].[dbo].[Especialidad] E ON E.idEspecialidad = PE.idEspecialidad		' + char(13) + 
				 '			WHERE	UNI.idUnidad = '+CONVERT(varchar(100), @idUnidad)+ char(13) + 
				 '			))' + char(13) + 
				 '	BEGIN' + char(13) + 
				 '		SELECT DISTINCT	E.idEspecialidad AS idServicio,' + char(13) + 
				 '				E.especialidad AS nombreServicio,' + char(13) + 
				 '				1 AS respuesta' + char(13) + 
				 '		FROM	[dbo].[Unidades] UNI' + char(13) + 
				 ' 				INNER JOIN [dbo].[ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion' + char(13) + 
				 '				INNER JOIN .[Partidas].[dbo].[ContratoUnidad] CU ON CU.idContrato = CP.idContrato' + char(13) + 
				 '				INNER JOIN .[Partidas].[dbo].[Unidad] UNIP ON UNIP.idUnidad = CU.idUnidad' + char(13) + 
				 '				INNER JOIN .[Partidas].[dbo].[TipoUnidad] TU ON TU.idTipoUnidad = UNIP.idTipoUnidad' + char(13) + 
				 '				INNER JOIN .[Partidas].[dbo].[ProveedorTipoUnidad] PTU ON TU.idTipoUnidad = PTU.idTipoUnidad' + char(13) + 
				 '				INNER JOIN .[Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = PTU.idProveedor' + char(13) + 
				 '				INNER JOIN .[Partidas].[dbo].[Especialidad] E ON E.idEspecialidad = PE.idEspecialidad		' + char(13) + 
				 '		WHERE	UNI.idUnidad = '+CONVERT(varchar(100), @idUnidad)+ char(13) + 
				 '	END' + char(13) + 
				 'ELSE' + char(13) + 
				 '	BEGIN' + char(13) + 
				 '		SELECT	0 AS respuesta,' + char(13) + 
				 '				'+char(39)+'No se encontraron servicios para la unidad'+char(39)+' AS mensaje' + char(13) + 
				 '	END	' + char(13) + 
				 ''
				 print @query
	EXECUTE(@query)
		
END

go

