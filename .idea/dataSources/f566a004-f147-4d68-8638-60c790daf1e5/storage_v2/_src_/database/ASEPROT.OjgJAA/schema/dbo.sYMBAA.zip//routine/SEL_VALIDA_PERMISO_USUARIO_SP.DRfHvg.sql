-- =============================================
-- Author:		Jose Armando Garcia Arroyo
-- Create date: 20/12/2019
-- [SEL_VALIDA_PERMISO_USUARIO_SP] 538,'',14
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDA_PERMISO_USUARIO_SP] 
	@idUsuario INT,
	@datos VARCHAR(MAX) = NULL,
	@accion INT

AS
BEGIN
DECLARE @permiso INT = 0

IF @accion = 14 /*Reporte Ordenes Costo Inventario*/
BEGIN
	DECLARE @aplicaUsuario INT

	SET @aplicaUsuario = CASE WHEN (SELECT COUNT(*) FROM ParametrosGeneralUsuario WHERE IdParametroGeneral=14 AND
						IdUsuario=@idUsuario)>0 THEN 1 ELSE 0 END

	IF @aplicaUsuario = 1
	BEGIN
	SET @permiso = 1
	END
END

SELECT @permiso AS tienePermiso

END

--INSERT INTO ParametrosGeneralUsuario
--SELECT 14,538,GETDATE(),58,2,1
--select * from ParametrosGeneralUsuario
go

