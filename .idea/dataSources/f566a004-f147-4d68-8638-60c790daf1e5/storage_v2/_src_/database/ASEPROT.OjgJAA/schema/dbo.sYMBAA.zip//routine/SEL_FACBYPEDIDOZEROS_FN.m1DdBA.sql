 --SELECT [dbo].[SEL_FACBYPEDIDOZEROS_FN](6364, 8, 42322)
 CREATE FUNCTION [dbo].[SEL_FACBYPEDIDOZEROS_FN] ( @idPedidoBpro int, @idMarca int, @idCliente int)
returns varchar(max)
as 
begin
	
	DECLARE @factura varchar(max) = '';
	IF @idMarca =1 --NISSAN
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAZM_Zaragoza].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAZM_Zaragoza].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente

	END 
	ELSE IF @idMarca=2 --GM
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAAS_Satelite].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAS_Satelite].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente

	END 
	ELSE IF @idMarca=3 --Ford
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAAAF_Viga].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAAF_Viga].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=4 --Suzuki
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAAU_Universidad].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAU_Universidad].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=5 --Hyundai
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAHyundai].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAHyundai].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=6 --CRA
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.31].[GACRA_Cuautitlan].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.31].[GACRA_Cuautitlan].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=7 --Honda
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAHondaZaragoza].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAHondaZaragoza].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=8 --Volkswagen
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.31].[GADLA_VW].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.31].[GADLA_VW].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=9 --Seat
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.31].[GADLA_SEAT].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.31].[GADLA_SEAT].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=11 --Chevrolet
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAAA_Azcapo].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAA_Azcapo].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=12 --Chrysler
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAAutoAngarTlahuac].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAutoAngarTlahuac].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente

		if(@factura is null or @factura='')
		begin 
			select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
			from [192.168.20.29].GAAutoAngarTepepan.DBO.[PAR_PEDMOST] AS p
			inner join [192.168.20.29].GAAutoAngarTepepan.DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
			WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
		end 
	END
	ELSE IF @idMarca=13 --Hyundai Cam
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAVC_Hyundai].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAVC_Hyundai].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	ELSE IF @idMarca=16 --Mitsubishi
	BEGIN 
		select  @factura=((LEFT(PMM_REF2, LEN(PMM_REF2) - PATINDEX('%[a-z]%', REVERSE(PMM_REF2)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000),
            PATINDEX('%[^0-9.-]%', SUBSTRING(PMM_REF2, PATINDEX('%[0-9.-]%', PMM_REF2), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GAAutoAngarMitsu].DBO.[PAR_PEDMOST] AS p
		inner join [192.168.20.29].[GAAutoAngarMitsu].DBO.[ADE_VTACFD] F ON F.VDE_DOCTO = P.PMM_REF2 
		WHERE P.PMM_NUMERO=@idPedidoBpro and P.PMM_IDCLIENTE = @idCliente
	END
	
	return @factura
end
 go

