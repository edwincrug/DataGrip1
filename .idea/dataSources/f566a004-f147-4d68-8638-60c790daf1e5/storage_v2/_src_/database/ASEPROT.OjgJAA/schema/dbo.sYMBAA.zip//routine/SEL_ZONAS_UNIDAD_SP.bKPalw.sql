-- =============================================
-- Author:		Sahirely Yam
-- Create date: 26 07 2017
-- =============================================
create PROCEDURE [dbo].[SEL_ZONAS_UNIDAD_SP]
	@idUnidad int
AS
BEGIN
	
	SET NOCOUNT ON;

	DECLARE @zonas table(idZona int)
	
	insert into @zonas 
	select idZona
	from UnidadesZona
	where idUnidad = @idUnidad	

	SELECT		Z.idZona, Z.nombre, Z.idPadre, NZ.idNivelZona, NZ.orden, NZ.etiqueta
	FROM		Partidas..Zona Z INNER JOIN
				Partidas..NivelZona NZ ON Z.idNivelZona = NZ.idNivelZona
	WHERE		Z.idZona IN (SELECT idZona FROM @zonas)
	ORDER BY	NZ.orden				

END
go

