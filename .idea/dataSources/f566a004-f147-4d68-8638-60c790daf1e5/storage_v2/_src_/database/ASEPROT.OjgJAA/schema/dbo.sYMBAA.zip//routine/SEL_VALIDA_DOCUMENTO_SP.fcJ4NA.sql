
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 06/06/2017
-- Description:	Store para la Validacion de Token
-- [SEL_VALIDA_DOCUMENTO_SP] '03-1632012972999-000138',1
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_VALIDA_DOCUMENTO_SP]
	@numeroOrden VARCHAR(50),
	@idCatalogoDocumento NUMERIC(18,0)
AS   
BEGIN
	
	DECLARE @idOrden NUMERIC(18,0)
		SET @idOrden = (SELECT idOrden FROM Ordenes WHERE numeroOrden = @numeroOrden)
	DECLARE @idCatalogoTipoOrdenServicio INT = (SELECT idCatalogoTipoOrdenServicio FROM Ordenes WHERE idOrden = @idOrden)
	IF(@idCatalogoTipoOrdenServicio = 1)
		BEGIN
			SELECT 1 AS ID
		END
	ELSE
		BEGIN
			SELECT [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](@idOrden, @idCatalogoDocumento, 0) AS ID
		END
END
go

