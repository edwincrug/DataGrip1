

--SELECT idContratoOperacionUsuario,descripcion FROM dbo.[GET_CONTRATOPERACION_USR_FN](120)

CREATE FUNCTION [dbo].[GET_CONTRATOPERACION_USR_FN](@idUsiario int)

returns @operacionesAsignadas  Table (Id int identity(1,1),idContratoOperacionUsuario INT,descripcion varchar(100),Zonas VARCHAR(MAX))
as 

begin

	

	DECLARE @valores VARCHAR(1000)
	insert into @operacionesAsignadas

		SELECT 
			COU.idContratoOperacionUsuario
			,C.descripcion,''
		FROM ContratoOperacionUsuario COU 
			JOIN ContratoOperacion CO ON CO.idContratoOperacion = COU.idContratoOperacion
			JOIN Partidas..Contrato C ON C.idContrato = CO.idContrato
			JOIN Operaciones O ON O.idOperacion = CO.idOperacion
		WHERE COU.idUsuario = @idUsiario

		DECLARE @i int = 1,@n int = (SELECT COUNT(*) FROM @operacionesAsignadas),@cadena VARCHAR(MAX)=''
		
		WHILE @i<=@n
		BEGIN

		IF(@cadena='')
		BEGIN
		SET @cadena = @cadena + (select CAST(idContratoOperacionUsuario AS varchar(25)) from @operacionesAsignadas WHERE Id=@i)
		END
		ELSE
		BEGIN
		SET @cadena = @cadena + ',' + (select CAST(idContratoOperacionUsuario AS varchar(25)) from @operacionesAsignadas WHERE Id=@i)
		END
		SET @i= @i+1
		END

		UPDATE @operacionesAsignadas SET Zonas=@cadena
				
		RETURN


END
go

