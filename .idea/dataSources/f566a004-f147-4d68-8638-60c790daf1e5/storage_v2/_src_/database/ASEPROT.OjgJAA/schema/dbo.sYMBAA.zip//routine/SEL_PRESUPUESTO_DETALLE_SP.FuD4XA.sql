-- [SEL_PRESUPUESTO_DETALLE_SP] 2
CREATE PROCEDURE  [dbo].[SEL_PRESUPUESTO_DETALLE_SP]
@idPresupuesto  INT

AS
BEGIN
	SELECT 
			PO.idPresupuesto, 
			PO.idOrden, 
			PO.fechaAlta, 
			OS.idOrden,
			OS.fechaCreacionOden,
			OS.numeroOrden,
			OS.consecutivoOrden,
			OS.comentarioOrden,
			OS.idZona,
			OS.idUnidad,
			OS.idContratoOperacion,
			OS.idUsuario,
			OS.idCentroTrabajo,
			U.numeroEconomico,
			P.presupuesto,
			(select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) montoTraspaso,
			P.folioPresupuesto,
			EO.nombreEstatusOrden,
			Z.nombre AS nombreZona,
			(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
				FROM [dbo].[Cotizaciones] C 
				INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
				INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
				INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
			WHERE O.idOrden = OS.idOrden 
			AND CO.idContratoOperacion = OS.idContratoOperacion 
			AND CD.idEstatusPartida IN(2) 
			AND C.idEstatusCotizacion IN(3))venta,			
			(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
				FROM [dbo].[Cotizaciones] C 
				INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
				INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
				INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
			WHERE O.idOrden = OS.idOrden  
			AND CO.idContratoOperacion = OS.idContratoOperacion 
			AND CD.idEstatusPartida IN(2) 
			AND C.idEstatusCotizacion IN(3))costo
			--(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, 1, 4)) AS costo,
			--(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, 1, 4)) AS venta
	FROM PresupuestoOrden PO
	JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto 
	JOIN Ordenes OS ON OS.idOrden =  PO.idOrden
	JOIN EstatusOrdenes EO ON EO.idEstatusOrden = OS.idEstatusOrden
	LEFT JOIN [Partidas].[dbo].[Zona] Z ON OS.idZona = Z.idZona
	JOIN Unidades U ON U.idUnidad = OS.idUnidad
	WHERE PO.idPresupuesto = @idPresupuesto

END

go

