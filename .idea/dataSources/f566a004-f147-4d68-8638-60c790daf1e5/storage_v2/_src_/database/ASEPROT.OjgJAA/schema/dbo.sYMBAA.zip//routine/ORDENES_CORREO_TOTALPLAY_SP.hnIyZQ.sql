
CREATE PROCEDURE [dbo].[ORDENES_CORREO_TOTALPLAY_SP]
AS

DECLARE @Resultado TABLE(numeroOrden VARCHAR(MAX),numeroCotizacion VARCHAR(MAX),numeroEmpleado VARCHAR(MAX),zona VARCHAR(MAX),placas VARCHAR(MAX)
,vin VARCHAR(MAX),descripcion VARCHAR(MAX),nombreEstatusPartida VARCHAR(MAX),nombreEstatusOrden VARCHAR(MAX),fechaCreacionOden VARCHAR(MAX)
,fechaFinal VARCHAR(MAX),tiempo VARCHAR(MAX),ventaPartida VARCHAR(MAX),venta VARCHAR(MAX),iva VARCHAR(MAX),total VARCHAR(MAX),observaciones VARCHAR(MAX))

INSERT INTO @Resultado
SELECT O.numeroOrden
,C.numeroCotizacion
,isnull(E.numeroEmpleado, 'N/A') as numeroEmpleado
,PZ.nombre AS zona
,U.placas
,U.vin
,P.descripcion
,EP.nombreEstatusPartida
,EO.nombreEstatusOrden
,ISNULL(CONVERT(VARCHAR(50),O.fechaCreacionOden,105)+ ' '+CONVERT(VARCHAR(50),O.fechaCreacionOden,108),'#N/A') AS fechaCreacionOden
--,isnull(cast(heo.fechaFinal as varchar),'N/A') as fechaFinal
,ISNULL(CONVERT(VARCHAR(50),heo.fechaFinal,105)+ ' '+CONVERT(VARCHAR(50),heo.fechaFinal,108),'#N/A') AS fechaFinal
,ISNULL(CAST((SELECT DATEDIFF(day,O.fechaCreacionOden,heo.fechaFinal )) AS VARCHAR(20)),'#N/A') AS tiempo
,isnull(cast(CD.venta*CD.cantidad  as varchar),'#N/A') AS ventaPartida
,isnull(cast(Tot.venta  as varchar),'#N/A') AS venta
,isnull(cast(Tot.venta * .16  as varchar),'#N/A') AS iva
,isnull(cast(Tot.venta + Tot.venta * .16  as varchar),'#N/A') AS total
,STUFF((SELECT ' // '+U.[nombreCompleto] +': ' + N.[descripcionNota]  FROM Notas N 
INNER JOIN [dbo].[Usuarios] AS U ON U.[idUsuario] = N.[idUsuario]
WHERE N.idOrden=O.idOrden
ORDER BY N.idNota FOR XML PATH('')),1,4,'') AS observaciones
FROM Ordenes O
INNER JOIN EstatusOrdenes EO ON O.idEstatusOrden = EO.idEstatusOrden
INNER JOIN Cotizaciones C ON O.idOrden=C.idOrden
INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
INNER JOIN Partidas..Partida P ON P.idPartida = CD.idPartida
LEFT JOIN OrdenEmpleado OE ON O.idOrden = OE.idOrden
LEFT JOIN Empleados E ON OE.idEmpleado = E.idEmpleado
INNER JOIN Partidas..Zona PZ ON O.idZona = PZ.idZona
INNER JOIN EstatusPartida EP ON CD.idEstatusPartida = EP.idEstatusPartida 
INNER JOIN Unidades U 
ON O.idUnidad = U.idUnidad
LEFT JOIN HistorialEstatusOrden HEO ON O.idOrden = HEO.idOrden AND  HEO.idEstatusOrden =6
LEFT JOIN [report].[VwOrdenTotales] Tot ON  Tot.idOrden = o.idOrden
WHERE O.idContratoOperacion = 44
GROUP BY O.numeroOrden,E.numeroEmpleado,PZ.nombre ,U.placas,U.vin, P.descripcion,EP.nombreEstatusPartida,EO.nombreEstatusOrden,
O.fechaCreacionOden,Tot.venta,heo.fechaFinal,C.numeroCotizacion
,C.idCotizacion,O.idUsuario,CD.venta*CD.cantidad,O.idOrden

SELECT 
*
--,[dbo].[fnNotasXOrden](numeroOrden) AS observaciones
,[dbo].[fnCorreosTOTALPLAY]() AS Email 
--,'jgarcia@bism.com.mx' as Email
FROM @Resultado

go

