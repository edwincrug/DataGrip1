-- =============================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 08/06/2017
-- SELECT [dbo].[SEL_OPERACION_TIENE_PRESUPUESTO](43413)
-- @resultado = 0 LA OPERACION NO MANEJA PRESUPUESTO
-- @resultado = 1 LA OPERACION MANEJA PRESUPUESTO TIENE SALDO POR CENTRO DE TRABAJO
-- @resultado = 2 LA OPERACION MANEJA PRESUPUESTO NO TIENE SALDO POR CENTRO DE TRABAJO
-- @resultado = 3 LA OPERACION NO TIENE UN PRESUPUESTO NO EXISTE  POR CENTRO DE TRABAJO
-- @resultado = 4 LA OPERACION NO TIENE UN PRESUPUESTO NO TIENE ACTIVO  POR CENTRO DE TRABAJO
-- =============================================
CREATE FUNCTION [dbo].[SEL_OPERACION_TIENE_PRESUPUESTO](@idOrden  NUMERIC(18,0))

RETURNS INT
AS
BEGIN
		DECLARE @resultado INT = 0
		DECLARE @manejaPresupuesto INT = (SELECT OP.presupuesto 
										  FROM [dbo].[Ordenes] O
										  JOIN [dbo].[ContratoOperacion] CO ON CO.idContratoOperacion = O.idContratoOperacion
										  JOIN [dbo].[Operaciones] OP ON OP.idOperacion = CO.idOperacion
											WHERE O.idOrden = @idOrden)										
		IF (@manejaPresupuesto = 0)
			BEGIN
				SET @resultado = 0
			END
		ELSE
			BEGIN
				DECLARE  @idCentroTrabajo int = 0

				SELECT @idCentroTrabajo=idCentroTrabajo 
				FROM Ordenes
				WHERE idOrden = @idOrden
				
				IF EXISTS(SELECT 1 FROM Presupuestos WHERE idCentroTrabajo=@idCentroTrabajo)
					BEGIN
						DECLARE @saldos TABLE  (IDB INT IDENTITY(1,1),
												presupuesto NUMERIC(18,2),
												utilizado NUMERIC(18,2))

						IF NOT EXISTS (SELECT 1 FROM  OrdenesPresupuestoEspecial where idOrden = @idOrden)
							BEGIN
								INSERT INTO @saldos 
								SELECT presupuesto
								+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto)  presupuesto,	
															
										(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 										
										+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
										FROM PresupuestoOrden PO
										--JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto
										JOIN Ordenes O ON O.idOrden = PO.idOrden
										JOIN Cotizaciones C ON C.idOrden = O.idOrden
										JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion										
										--JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON CPVenta.idPartida = CD.idPartida 
										WHERE  O.idCentroTrabajo = @idCentroTrabajo AND PO.idPresupuesto = P.idPresupuesto AND CD.idEstatusPartida IN(1,2) AND C.idEstatusCotizacion IN(1,2,3))utilizado
								FROM Presupuestos P
								LEFT JOIN dbo.TraspasoPresupuesto TP on TP.idPresupuestoOrigen = P.idPresupuesto 
								WHERE idCentroTrabajo=@idCentroTrabajo AND idEstatusPresupuesto = 1
							END
						ELSE
							BEGIN
								INSERT INTO @saldos 
								SELECT presupuesto
								+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoDestino = P.idPresupuesto)  presupuesto,								
										(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
										+ (select isnull(sum(isnull(Monto,0)),0) from traspasopresupuesto where idpresupuestoOrigen = P.idPresupuesto) 
										FROM PresupuestoOrden PO
										JOIN Ordenes O ON O.idOrden = PO.idOrden
										JOIN Cotizaciones C ON C.idOrden = O.idOrden
										JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
										WHERE PO.idOrden = P.idPresupuesto AND CD.idEstatusPartida IN(1,2) AND C.idEstatusCotizacion IN(1,2,3))utilizado
								FROM Presupuestos P
								LEFT JOIN dbo.TraspasoPresupuesto TP on TP.idPresupuestoOrigen = P.idPresupuesto 
								INNER JOIN OrdenesPresupuestoEspecial ORDpe ON P.idPresupuesto = ORDpe.idPresupuesto and ORDpe.idOrden = @idOrden
								WHERE idCentroTrabajo=@idCentroTrabajo AND P.idEstatusPresupuesto = 4
							END

						DECLARE @venta decimal(18,2)
						SELECT @venta = ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						FROM Cotizaciones C JOIN Ordenes O ON O.idOrden = C.idOrden 
						JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
						--JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON CPVenta.idPartida = CD.idPartida 
						WHERE O.idOrden = @idOrden AND CD.idEstatusPartida in (1,2)

						DECLARE @SaldoRestante DECIMAL(18,2) = (SELECT (presupuesto - utilizado) FROM @saldos)

						IF EXISTS(SELECT * FROM Presupuestos WHERE idCentroTrabajo=@idCentroTrabajo AND idEstatusPresupuesto=1)
							BEGIN
								IF(@venta <= @SaldoRestante)
									BEGIN
										-- TIENE SALDO
										SET @resultado = 1
									END
								ELSE
									BEGIN
										-- NO TIENE SALDO 2
										SET @resultado = 2
									END
							END
						ELSE
							BEGIN
								-- PRESUPUESTO NO TIENE ACTIVO 4
								SET @resultado = 2
							END

					END
				ELSE
					BEGIN
						-- PRESUPUESTO NO EXISTE 3
						SET @resultado = 2
					END

			END
		RETURN @resultado
END

/*
SELECT OP.presupuesto 
		FROM [dbo].[Ordenes] O
		JOIN [dbo].[ContratoOperacion] CO ON CO.idContratoOperacion = O.idContratoOperacion
		JOIN [dbo].[Operaciones] OP ON OP.idOperacion = CO.idOperacion
		WHERE O.idOrden = 105

	SELECT idCentroTrabajo 
	FROM Ordenes
	WHERE idOrden = 209

	SELECT presupuesto,
			(SELECT ISNULL(SUM((ISNULL(CPVenta.venta,0) * ISNULL(CD.cantidad,0))),0) 
			FROM PresupuestoOrden PO
			--JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto
			JOIN Ordenes O ON O.idOrden = PO.idOrden
			JOIN Cotizaciones C ON C.idOrden = O.idOrden
			JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
			JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON CPVenta.idPartida = CD.idPartida 
			WHERE  O.idCentroTrabajo = 4 AND CD.idEstatusPartida IN(1,2) AND C.idEstatusCotizacion IN(1,2,3))utilizado
	FROM Presupuestos 
	WHERE idCentroTrabajo=4 AND idEstatusPresupuesto = 1

	SELECT ISNULL(SUM((ISNULL(CPVenta.venta,0) * ISNULL(CD.cantidad,0))),0) 
	FROM Cotizaciones C JOIN Ordenes O ON O.idOrden = C.idOrden 
	JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
	JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON CPVenta.idPartida = CD.idPartida 
	WHERE O.idOrden = @idOrden AND CD.idEstatusPartida in (1,2)

*/
go

