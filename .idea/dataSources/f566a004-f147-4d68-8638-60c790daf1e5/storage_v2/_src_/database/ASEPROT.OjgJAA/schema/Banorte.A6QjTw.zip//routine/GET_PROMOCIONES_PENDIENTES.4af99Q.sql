

/*
	Fecha			Autor			Descripción
	27-Jun-2018		José Etmanuel	Se crea el SP que regresa las promociones de un usuario
	
	[Banorte].[GET_PROMOCIONES_PENDIENTES] 743
*/

CREATE PROCEDURE [Banorte].[GET_PROMOCIONES_PENDIENTES] 
 @idUsuario INT
AS
BEGIN

	SELECT distinct PC.idPromocion, 
		P.nombrePromocion as descripcion, 
		T.Nombre as nombreTienda, 
		P.fechaTermino as fechaVigencia,
		T.Img as logo
	FROM [PromocionesCodigos] AS PC
	INNER JOIN [Banorte].[Promociones] as P on P.id = PC.IdPromocion
	INNER JOIN [Banorte].[PromocionesSuc] AS S on S.[idPromociones] = P.id
	INNER JOIN [Banorte].[Patrocinador] as T on T.[Id] = S.PatrocinadorId
	WHERE IdUsuario = @idUsuario
	AND Aplicadas<NumeroMaximo
	AND P.fechaTermino >= GETDATE()
	
END

go

grant execute, view definition on Banorte.GET_PROMOCIONES_PENDIENTES to DevOps
go

