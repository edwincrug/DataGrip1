/*
	Objetivo: Devuelve el usaurio de un Token activo
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	02/07/18		JEHR	Creación del SP

	*/
CREATE proc [Banorte].[VALIDA_DATOS]
	@idUsuario int,
	@token varchar(175) = null
as
begin
	DECLARE @nombreUsuario VARCHAR(MAX),
			@contrasenia VARCHAR(MAX)
	;

	SELECT @nombreUsuario=[nombreUsuario], @contrasenia = contrasenia FROM Usuarios WHERE [idUsuario] = @idUsuario;

	EXEC [Banorte].[VALIDA_LOGIN] @nombreUsuario, @contrasenia, @token;
end
go

grant execute, view definition on Banorte.VALIDA_DATOS to DevOps
go

