  
-- ==========================================================================================  
-- Author:  Alejandro Grijalva Antonio  
-- Create date: 29/05/2017  
-- Description: Se obtienen las cotizaciones de una orden   
-- ==========================================================================================  
-- SEL_COTIZACIONES_ORDEN_SP @numeroOrden ='01-2810044-142',@estatus = '2'  
-- SEL_COTIZACIONES_ORDEN_SP @numeroOrden ='03-1674072067099-000122',@estatus = '2'  
-- SEL_COTIZACIONES_ORDEN_SP @numeroOrden = '01-2210035-5', @estatus = '3'  
-- SEL_COTIZACIONES_ORDEN_SP @numeroOrden = '01-1110057-31', @estatus = 1  
-- estatus=1&numeroOrden=03-1674072067099-000122&usuario=23  
-- SEL_COTIZACIONES_ORDEN_SP '01-1620097-380','3',107,1  
-- SEL_COTIZACIONES_ORDEN_SP '03-10398-25717','3',509,3
-- SEL_COTIZACIONES_ORDEN_SP '57-PMX08105-35990','1',538,57
CREATE PROCEDURE [dbo].[SEL_COTIZACIONES_ORDEN_SP]  
 @numeroOrden NVARCHAR(250),  
 @estatus NVARCHAR(50),  
 @idUsuario INT,  
 @idContratoOperacion INT  
  
AS     
BEGIN  
 DECLARE @idOperacion int = (select idOperacion from ContratoOperacion where idContratoOperacion = @idContratoOperacion) 
 DECLARE @estatusOrden int = (select idEstatusOrden from Ordenes where numeroOrden = @numeroOrden)  
 IF(@estatusOrden = 8)  
 SET @estatus = '3'  
 IF(@estatusOrden = 4)  
 SET @estatus = '1,2'
 IF(@estatusOrden = 3)  
 SET @estatus = '1'  
  
 DECLARE @query NVARCHAR(MAX) = ''  
 DECLARE @where NVARCHAR(MAX) = ''  
 -- IF (@estatusOrden != 4)  
 IF (@estatusOrden != 0)  
  BEGIN   
   SET @query='SELECT COTI.* '  
  END  
 ELSE  
  BEGIN  
   SET @query='SELECT TOP 1 COTI.* '  
  END  
  
 IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 4  
  BEGIN  
   SET @where = ' '  
  END  
 ELSE  
  BEGIN  
   SET @where = ' AND COTI.idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+CONVERT(varchar(10), @idUsuario)+', '+CONVERT(varchar(10), @idOperacion)+')) '  
  END  
	IF EXISTS(select preAprobacion from Operaciones WHERE idOperacion=@idOperacion AND preAprobacion=0)
		BEGIN
		   SET @query= @query + ',(SELECT [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](ORD.idOrden,3,COTI.ConsecutivoCotizacion)) AS factura,   
			 ORD.idTaller AS idTaller,  
			 P.nombreComercial AS nombreTaller,  
			 P.razonSocial AS razonSocial,  
			 P.direccion AS direccion,  
			 ISNULL(Z.nombre, '''') AS nombreZona,  
			 USU.nombreCompleto,  
			 EC.nombreEstatusCotizacion AS nombreEstatusCotizacion,  
			 (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0)   
			  FROM [dbo].[Cotizaciones] C        INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion         INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.
		idContratoOperacion  
			 WHERE C.idCotizacion = COTI.idCotizacion  
			 AND CD.idEstatusPartida IN(1,2)) AS sumaCosto,  
			 (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
			  FROM [dbo].[Cotizaciones] C        INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion         INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.
		idContratoOperacion  
			 WHERE C.idCotizacion = COTI.idCotizacion  
			 AND CD.idEstatusPartida IN(1,2)) AS sumaVenta,  
			 -- TOTAL DE VENTA ORIGINAL
			 (SELECT SUM(d.OTD_PRECIOUNITARIOVENTA * d.OTD_CANTIDAD) FROM [dbo].[DescuentoIntegraBPro] d
			 inner join [dbo].[Cotizaciones] C  on d.idCotizacion = c.idCotizacion
			 INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion and d.idCotizacionDetalle = cd.idCotizacionDetalle        
			  INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       
			  INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion  
			 WHERE C.idCotizacion = COTI.idCotizacion 
			 AND CD.idEstatusPartida IN(1,2)) as sumaVentaOrignal,
			 -- TOTAL DE VENTA DESCUENTO
			 (SELECT SUM(d.Descuento * d.OTD_CANTIDAD) FROM [dbo].[DescuentoIntegraBPro] d
			 inner join [dbo].[Cotizaciones] C  on d.idCotizacion = c.idCotizacion
			 INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion and d.idCotizacionDetalle = cd.idCotizacionDetalle        
			  INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       
			  INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion  
			 WHERE C.idCotizacion = COTI.idCotizacion 
			 AND CD.idEstatusPartida IN(1,2)) as sumaVentaDescuento,
			 (select nombreCentroTrabajo from CentroTrabajos where idCentroTrabajo= ORD.idCentroTrabajo ) centroTrabajo,
			 CASE 
				WHEN FC.idFacturaCotizacion IS NOT NULL THEN 1 
				ELSE 0 END facturaCotizacion ,
				CASE WHEN
				(SELECT COUNT(*) FROM [dbo].[CotizacionDetalle] CODE
				INNER JOIN [Partidas].[dbo].[Partida] PART ON CODE.idPartida = PART.idPartida
				WHERE COTI.idCotizacion = CODE.idCotizacion AND PART.partida=''Salida.Falso'')>0
				AND (SELECT COUNT(*) FROM ParametrosGeneralUsuario where IdParametroGeneral=25 and idUsuario='+CAST(@idUsuario AS VARCHAR(MAX))+')>0
					THEN 1 ELSE 0 END
					AS AplicaModSalFalso
		   FROM [dbo].[Ordenes] ORD  
			 INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden 
			 LEFT JOIN facturaCotizacion FC ON FC.idCotizacion = COTI.idCotizacion 
			 INNER JOIN [dbo].[Usuarios] USU ON COTI.idUsuario = USU.idUsuario  
			 INNER JOIN [dbo].[EstatusCotizaciones] EC ON EC.idEstatusCotizacion = COTI.idEstatusCotizacion  
			 LEFT JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = COTI.idTaller  
			 LEFT JOIN [Partidas].[dbo].[Zona] Z ON Z.idZona = ORD.idZona  
		   WHERE ORD.numeroOrden = '''+@numeroOrden+''' AND COTI.idEstatusCotizacion IN('+@estatus+') ' + @where + '  
		   ORDER BY COTI.[consecutivoCotizacion] ASC' 
		END
	ELSE
		BEGIN
		
		   SET @query= @query + ',(SELECT [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](ORD.idOrden,3,COTI.ConsecutivoCotizacion)) AS factura,   
			 ORD.idTaller AS idTaller,  
			 P.nombreComercial AS nombreTaller,  
			 P.razonSocial AS razonSocial,  
			 P.direccion AS direccion,  
			 ISNULL(Z.nombre, '''') AS nombreZona,  
			 USU.nombreCompleto,  
			 EC.nombreEstatusCotizacion AS nombreEstatusCotizacion,  
			 (SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0)   
			  FROM [dbo].[Cotizaciones] C        INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion         INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.
		idContratoOperacion  
			 WHERE C.idCotizacion = COTI.idCotizacion  
			 AND CD.idEstatusPartida IN(1,2)) AS sumaCosto,  
			 (SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0)   
			  FROM [dbo].[Cotizaciones] C        INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion         INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.
		idContratoOperacion  
			 WHERE C.idCotizacion = COTI.idCotizacion  
			 AND CD.idEstatusPartida IN(1,2)) AS sumaVenta,  
			 -- TOTAL DE VENTA ORIGINAL
			 (SELECT SUM(d.OTD_PRECIOUNITARIOVENTA * d.OTD_CANTIDAD) FROM [dbo].[DescuentoIntegraBPro] d
			 inner join [dbo].[Cotizaciones] C  on d.idCotizacion = c.idCotizacion
			 INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion and d.idCotizacionDetalle = cd.idCotizacionDetalle        
			  INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       
			  INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion  
			 WHERE C.idCotizacion = COTI.idCotizacion 
			 AND CD.idEstatusPartida IN(1,2)) as sumaVentaOrignal,
			 -- TOTAL DE VENTA DESCUENTO
			 (SELECT SUM(d.Descuento * d.OTD_CANTIDAD) FROM [dbo].[DescuentoIntegraBPro] d
			 inner join [dbo].[Cotizaciones] C  on d.idCotizacion = c.idCotizacion
			 INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion and d.idCotizacionDetalle = cd.idCotizacionDetalle        
			  INNER JOIN [dbo].[Ordenes] O ON C.idOrden = O.idOrden       
			  INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion  
			 WHERE C.idCotizacion = COTI.idCotizacion 
			 AND CD.idEstatusPartida IN(1,2)) as sumaVentaDescuento,
			 (select nombreCentroTrabajo from CentroTrabajos where idCentroTrabajo= ORD.idCentroTrabajo ) centroTrabajo,
			 ISNULL(PA.idPreaprobacion,0) AS PreAprobacion,
			 PA.fecha AS fechaLiberador,
			 ISNULL((SELECT distinct U.nombreCompleto FROM Preaprobacion P JOIN Usuarios U ON U.idUsuario = P.idUsuario WHERE P.idCotizacion = COTI.idCotizacion),'''') AS usuarioLiberador,
			 CASE 
				WHEN FC.idFacturaCotizacion IS NOT NULL THEN 1 
				ELSE 0 END facturaCotizacion,
			CASE WHEN
				(SELECT COUNT(*) FROM [dbo].[CotizacionDetalle] CODE
				INNER JOIN [Partidas].[dbo].[Partida] PART ON CODE.idPartida = PART.idPartida
				WHERE COTI.idCotizacion = CODE.idCotizacion AND PART.partida=''Salida.Falso'')>0
				AND (SELECT COUNT(*) FROM ParametrosGeneralUsuario where IdParametroGeneral=25 and idUsuario='+CAST(@idUsuario AS VARCHAR(MAX))+')>0
					THEN 1 ELSE 0 END
					AS AplicaModSalFalso
		   FROM [dbo].[Ordenes] ORD  
			 INNER JOIN [dbo].[Cotizaciones] COTI ON COTI.idOrden = ORD.idOrden  
			  LEFT JOIN facturaCotizacion FC ON FC.idCotizacion = COTI.idCotizacion 
			 LEFT JOIN Preaprobacion PA ON PA.idCotizacion = COTI.idCotizacion
			 INNER JOIN [dbo].[Usuarios] USU ON COTI.idUsuario = USU.idUsuario  
			 INNER JOIN [dbo].[EstatusCotizaciones] EC ON EC.idEstatusCotizacion = COTI.idEstatusCotizacion  
			 LEFT JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = COTI.idTaller  
			 LEFT JOIN [Partidas].[dbo].[Zona] Z ON Z.idZona = ORD.idZona  
		   WHERE ORD.numeroOrden = '''+@numeroOrden+''' AND COTI.idEstatusCotizacion IN('+@estatus+') ' + @where + '  
		   ORDER BY COTI.[consecutivoCotizacion] ASC'
		END
  print @query
  EXECUTE(@query)  
    
END

go

grant execute, view definition on SEL_COTIZACIONES_ORDEN_SP to DevOps
go

