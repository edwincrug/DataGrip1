-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Test: SEL_REPORTE_OPERACIONES_INTEGRA_SP 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORTE_OPERACIONES_INTEGRA_SP]
	-- Add the parameters for the stored procedure here
	@idContratoOperacion		numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select 
		con.descripcion,
		ord.numeroOrden,
		coalesce(edo.nombreEstado, 'SIN REGIÓN')		'region',
		eso.nombreEstatusOrden		estatusOrden,
		heo.fechaFinal,
		heo.fechaInicial,
		DATEDIFF( day, coalesce(heo.fechaInicial, getdate()), coalesce( heo.fechaFinal, getdate() ) )		numDias,
		isnull(sum(cd.venta * cd.cantidad),0)				ventaOrden,
		isnull(sum(cd.costo * cd.cantidad),0)				costoOrden,
		isnull(sum(cd.costo * cd.cantidad),0) * 0.16		IVAOrden,
		isnull(sum(cd.costo * cd.cantidad),0) * 1.16		totalOrden,
		--(select ASEPROT.dbo.SEL_PARTIDAS_ORDEN_FN(ord.idOrden)) descripcionPartida,
		case 
			when opte.tiempoEnEspera is null then 0
			when GETDATE() > DATEADD( hour, convert( int, substring( opte.tiempoEnEspera, 0, 3 ) ), heo.fechaInicial ) 
				then DATEDIFF(DAY, DATEADD(hour, convert(int, substring(opte.tiempoEnEspera, 0, 3 ) ), heo.fechaInicial), getdate())
			else 0
		end     as tiempoDesfasado
	from Partidas.dbo.Contrato con 
		inner join SISCOReportServices.dbo.Contrato co on co.idContrato = con.idContrato
		inner join ASEPROT.dbo.ContratoOperacion cop on cop.idContrato = con.idContrato 
		inner join ASEPROT.dbo.Ordenes ord on ord.idContratoOperacion = cop.idContratoOperacion 
		left join ASEPROT.Gerente.EstadoZona eszo on eszo.idZona = ord.idZona and eszo.idContratoOperacion = cop.idContratoOperacion and eszo.estatus = 0
		left join ASEPROT.Gerente.Estados edo on edo.idEstados = eszo.idEstado  and edo.estatus = 0
		left join ASEPROT.dbo.Cotizaciones coti on coti.idOrden = ord.idOrden and coti.idEstatusCotizacion in (1,2,3) and coti.idTaller =
			case when ord.idEstatusOrden = 1 then 0
				else coti.idTaller
			end
		left join ASEPROT.dbo.CotizacionDetalle cd on cd.idCotizacion = coti.idCotizacion and cd.idEstatusPartida in (1,2)
		left join ASEPROT.dbo.EstatusOrdenes eso on eso.idEstatusOrden = ord.idEstatusOrden
		left join ASEPROT.dbo.HistorialEstatusOrden heo on heo.idEstatusOrden = eso.idEstatusOrden and heo.idOrden = ord.idOrden
		left join Partidas.dbo.partida par on par.idPartida = cd.idPartida
		left join ASEPROT.dbo.OperacionTiempoEnEspera opte on opte.idOperacion = cop.idOperacion and opte.idEstatusOrden = ord.idEstatusOrden
		left join ASEPROT.dbo.Operaciones oper on oper.idOperacion = cop.idOperacion and oper.tiempoAsignado = 1
	where --con.idContrato not in (10,20, 25,26,31)--in(1,4,21,7,5,30,8,27,41,34,35,13,23,19,49)
		ord.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)
	group by con.descripcion, ord.numeroOrden, edo.nombreEstado, eso.nombreEstatusOrden, ord.idOrden, heo.fechaFinal, heo.fechaInicial, opte.tiempoEnEspera
	order by con.descripcion, eso.nombreEstatusOrden, numDias
END
go

