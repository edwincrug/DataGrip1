-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- INS_DETALLE_MODULO_SP 1,'7','12:34'
-- =============================================
 CREATE PROCEDURE [dbo].[INS_DETALLE_MODULO_SP]
	 @idModulo INT,
	 @detalle NVARCHAR (MAX),
	 @idOperacion INT
	 --@tiempoAsignado NVARCHAR (100) = NULL
AS
BEGIN
	
	DECLARE @idDetalleModulo INT,
			@idCatalogoDetalleModulo INT,
			@lnuPosComa INT


			WHILE LEN(@detalle) > 0
				BEGIN 
					SET @lnuPosComa = CHARINDEX(',', @detalle) -- Busca el caracter a separador
					IF (@lnuPosComa = 0)
						BEGIN 
							SET @idCatalogoDetalleModulo = @detalle
							SET @detalle = '' 
						END
						ELSE 
						BEGIN
							SET @idCatalogoDetalleModulo = SUBSTRING(@detalle, 1, @lnuPosComa - 1)
							SET @detalle = SUBSTRING(@detalle, @lnuPosComa + 1, LEN(@detalle))
							--print convert (int, @idCatalogoDetalleModulo)
								IF NOT EXISTS(SELECT 1 FROM DetalleModulo WHERE idModulo=@idModulo AND idCatalogoDetalleModulo=@idCatalogoDetalleModulo AND idOperacion = @idOperacion) 
									BEGIN
											INSERT INTO [DetalleModulo] (
												[idModulo],
												[idCatalogoDetalleModulo],
												[activo],
												[idOperacion])

											VALUES(
											@idModulo,
											convert (int, @idCatalogoDetalleModulo),
											1,
											@idOperacion)
									END
								--ELSE
									--BEGIN
										--UPDATE [DetalleModulo] 
										--SET activo = 2
										--WHERE idModulo=@idModulo AND idCatalogoDetalleModulo=@idCatalogoDetalleModulo
									--END
						END

				END

			SET @idDetalleModulo = @@IDENTITY 
			SELECT @idDetalleModulo AS idDetalleModulo
		
END


go

