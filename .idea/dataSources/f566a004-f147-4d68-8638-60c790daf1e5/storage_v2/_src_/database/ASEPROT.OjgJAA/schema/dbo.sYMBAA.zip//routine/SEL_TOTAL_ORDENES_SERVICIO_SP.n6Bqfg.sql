-- [SEL_TOTAL_ORDENES_SERVICIO_SP] @fechaInicial='',@fechaFin='',@fechaEspecifico='',@fechaMes='',@numeroOrden='',@idZona=0, @idEjecutivo=0, @idUsuario=168, @idContratoOperacion=1, @tipoConsulta=1
--[SEL_TOTAL_ORDENES_SERVICIO_SP] @fechaInicial='',@fechaFin='',@fechaEspecifico='',@fechaMes='',@numeroOrden='',@idZona=0, @idEjecutivo=46, @idUsuario=23, @idContratoOperacion=3, @tipoConsulta=1
--[SEL_TOTAL_ORDENES_SERVICIO_SP] @fechaInicial='',@fechaFin='',@fechaEspecifico='',@fechaMes='',@numeroOrden='',@idZona=0, @idEjecutivo=0, @idUsuario=107, @idContratoOperacion=1, @tipoConsulta=2
--[SEL_TOTAL_ORDENES_SERVICIO_SP] @fechaInicial='',@fechaFin='',@fechaEspecifico='',@fechaMes='',@numeroOrden='',@idZona=0, @idEjecutivo=0, @idUsuario=232, @idContratoOperacion=3, @tipoConsulta=1
--fechaEspecifico=&fechaFin=&fechaInicial=&fechaMes=&idContratoOperacion=3&idEjecutivo=46&idUsuario=23&idZona=0&numeroOrden=&tipoConsulta=1
CREATE PROCEDURE [dbo].[SEL_TOTAL_ORDENES_SERVICIO_SP] 
@fechaInicial VARCHAR(MAX) = '', -- OPCIONAL
@fechaFin VARCHAR(MAX) = '', -- OPCIONAL
@fechaEspecifico VARCHAR(MAX) ='', --OPCIONAL
@fechaMes VARCHAR(max) = '', -- OPCIONAL
@numeroOrden VARCHAR(50) = '', --OPCIONAL
@idZona NUMERIC(18,0)= 0, -- OPCIONAL
@idEjecutivo INT = 0, --OPCIONAL
@idUsuario INT = 475, --LOGGEADO SIEMPRE
@idContratoOperacion INT = 3, --SIEMPRE
@tipoConsulta INT = 1 --SIEMPRE

AS
BEGIN

	DECLARE @zona NVARCHAR(MAX)= '', @zonas NVARCHAR(MAX)= '', @zonaminas NVARCHAR(MAX) = ' ', @plusZona NVARCHAR(MAX) = ' ', @query  NVARCHAR(MAX) = '', @usuario NVARCHAR(MAX) = '', @join NVARCHAR(MAX) = ''
	DECLARE @ipServidorPartidas NVARCHAR(300)='', @anio VARCHAR(10), @mes VARCHAR(10), @fechaprimer VARCHAR(10), @fechaFinal VARCHAR(10), @fechaFinx VARCHAR(10)
	SELECT @ipServidorPartidas = ipServidor FROM [dbo].[Parametros] where nombreBD='Partidas'
	DECLARE @queryText VARCHAR(MAX)

	IF(@fechaMes != '')
	BEGIN
		SET @fechaFinx = @fechaMes
		SET @anio = YEAR(@fechaFinx)
		SET @mes  = MONTH(@fechaFinx)
		SET @fechaprimer = '0'+@mes+'/01/'+@anio
		SET @fechaFinal =  CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@fechaMes))),DATEADD(mm,1,@fechaMes)),103)
	END

	DECLARE @idCatalogoRol INT,  @idCOU numeric(18,0), @idOperacion numeric(18,0)
	select @idCOU = COU.idContratoOperacionUsuario, @idCatalogoRol = COU.idCatalogoRol, @idOperacion = CO.idOperacion
	from Usuarios U 
	inner join ContratoOperacionUsuario COU on COU.idUsuario = U.idUsuario
	inner join ContratoOperacion CO on COU.idContratoOperacion = CO.idContratoOperacion
	where U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	declare @zonasAsignadas table (idZona int)

	insert into @zonasAsignadas
	select idZona from ContratoOperacionUsuarioZona COUZ
	where COUZ.idContratoOperacionUsuario = @idCOU

   IF(@idCatalogoRol <> 2 AND @idEjecutivo = 0)
		BEGIN
		    IF(@idCatalogoRol <> 4)
				BEGIN
					SET @join =' JOIN [ContratoOperacionUsuario] COU ON COU.idContratoOperacion = ConOpe.idContratoOperacion
								 --JOIN [ContratoOperacionUsuarioZona] COUZ ON COUZ.idContratoOperacionusuario = COU.idContratoOperacionusuario '

					SET @usuario = ' AND COU.idUsuario = '+CAST(@idUsuario AS NVARCHAR(30))+' AND COU.idContratoOperacion  = ' + CONVERT(NVARCHAR(100),@idContratoOperacion) +' '
				END
			ELSE
				BEGIN
					SET @join = '  '

					if (@tipoConsulta = 1)
						begin
							SET @usuario =  ' AND (SELECT CASE WHEN exists ( select 1 from Cotizaciones C where C.idOrden = Orden.idOrden and C.idTaller in '+
											'(	SELECT        COUP.idProveedor' + char(13) + 
												'FROM          ContratoOperacionUsuario COU ' + char(13) + 
												'INNER JOIN ContratoOperacionUsuarioProveedor COUP on COUP.idContratoOperacionUsuario =  COU.idContratoOperacionUsuario' + char(13) + 
												'WHERE COU.idUsuario = '+ convert(varchar(5), @idUsuario) +' and COU.idContratoOperacion = '+ convert(varchar(50),@idContratoOperacion) +')'+
											' ) THEN ' +char(39)+'true'+char(39)+ ' ELSE '+char(39)+ 'false'+char(39)+' END ) = '+char(39)+'true'+char(39)  
						end 
					else 
						begin
							if (@tipoConsulta = 2)
								begin
									set @usuario  = ' AND Coti.idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idOperacion)+')) '
								end
							else
								begin
									set @usuario = ' AND (SELECT CASE WHEN exists ( select 1 from Cotizaciones C where C.idOrden = Orden.idOrden and C.idEstatusCotizacion in (3) and C.idTaller in '+
													'(	SELECT        COUP.idProveedor' + char(13) + 
														'FROM          ContratoOperacionUsuario COU ' + char(13) + 
														'INNER JOIN ContratoOperacionUsuarioProveedor COUP on COUP.idContratoOperacionUsuario =  COU.idContratoOperacionUsuario' + char(13) + 
														'WHERE COU.idUsuario = '+ convert(varchar(5), @idUsuario) +' and COU.idContratoOperacion = '+ convert(varchar(50),@idContratoOperacion) +')'+
													' ) THEN ' +char(39)+'true'+char(39)+ ' ELSE '+char(39)+ 'false'+char(39)+' END ) = '+char(39)+'true'+char(39)  
								end
						end

				END
		END
	ELSE IF(@idCatalogoRol = 2 AND @idEjecutivo != 0)
		BEGIN 
				SET @join =' LEFT JOIN [ContratoOperacionUsuario] COU ON COU.idUsuario = Orden.idUsuario'

				SET @usuario = ' AND orden.idUsuario = '+CAST(@idEjecutivo AS NVARCHAR(30))+' AND COU.idContratoOperacion  = ' + CONVERT(NVARCHAR(100),@idContratoOperacion) +' '
		END

	declare @groupBy varchar(max) = ''
					

	DECLARE @todo TABLE  (IDB INT IDENTITY(1,1),
							idOrden INT,
							idGarantia INT,
							numeroOrden NVARCHAR(MAX),
							conjuntoEstatus INT,
							fechaCita DATETIME,
							fechaCreacionOden  DATETIME,
							fechaInicioTrabajo DATETIME,
							fechaEstatusActual DATETIME,
							comentarioOrden NVARCHAR(MAX),
							numeroEconomico NVARCHAR(MAX),
							consecutivoOrden NVARCHAR(MAX),
							requiereGrua INT,
							descripcionEstadoUnidad NVARCHAR(MAX),
							idZona INT,
							nombreZona NVARCHAR(MAX),
							idUnidad INT,
							nombreCliente  NVARCHAR(MAX),
							idEstatusOrden INT,
							nombreEstatusOrden NVARCHAR(MAX),
							idContratoOperacion INT,
							idUsuario INT, 
							nombreUsuario NVARCHAR(MAX),
							idCatalogoTipoOrdenServicio INT,
							nombreTipoOrdenServicio NVARCHAR(MAX),
							idTipoOrden INT,
							nombreTipoORden NVARCHAR(MAX),
							estadistica  NVARCHAR(MAX),
							porcentaje  NVARCHAR(MAX),
							marcaUnidad NVARCHAR(MAX),
							modeloUnidad NVARCHAR(MAX),
							nombreTaller  NVARCHAR(MAX),
							idEstatusCotizacion INT,
							idCotizacion INT,
							nombreEstatusCotizacion NVARCHAR(MAX),
							numeroCotizacion NVARCHAR(MAX),
							tienePresupuesto INT,
							motivoPresupuesto NVARCHAR(MAX),
							tiempoEspera NVARCHAR(max),
							venta NUMERIC (18,2),
							costo NUMERIC (18,2))
	IF @tipoConsulta = 1
		BEGIN
			SET @queryText = 
				'SELECT distinct' + char(13) + 
				'Orden.[idOrden]' + char(13) + 
				',Orden.[idGarantia] AS idGarantia' + char(13) + 
				',[numeroOrden]' + char(13) + 
				','''' AS conjuntoEstatus' + char(13) + 
				',[fechaCita] as fecha' + char(13) + 
				',convert(datetime, DATEADD(HH,5,fechaCreacionOden)) as fechaCreacionOden' + char(13) + 
				',fechaInicioTrabajo' + char(13) + 
				',Histo.fechaInicial AS fechaEstatusActual' + char(13) + 
				',comentarioOrden' + char(13) + 
				',Uni.[numeroEconomico]' + char(13) + 
				',[consecutivoOrden] AS consecutivoOrden' + char(13) + 
				',[requiereGrua]' + char(13) + 
				',EstadoUni.descripcionEstadoUnidad' + char(13) + 
				',zona.[idZona]' + char(13) + 
				',zona.nombre' + char(13) + 
				',Uni.[idUnidad]' + char(13) + 
				',(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente' + char(13) + 
				',EtsOrden.[idEstatusOrden]' + char(13) + 
				',EtsOrden.[nombreEstatusOrden]' + char(13) + 
				',ConOpe.[idContratoOperacion]' + char(13) + 
				',Usu.[idUsuario]' + char(13) + 
				',Usu.nombreCompleto' + char(13) + 
				',CaTiOrSe.[idCatalogoTipoOrdenServicio]' + char(13) + 
				',CaTiOrSe.[nombreTipoOrdenServicio]' + char(13) + 
				',CaTiOr.[idTipoOrden]' + char(13) + 
				',CaTiOr.nombreTipoORden ' + char(13) + 
				','+char(39)+''+char(39)+' AS estadistica ' + char(13) + 
				','+char(39)+''+char(39)+' AS porcentaje ' + char(13) + 
				',MA.[nombre] AS marca' + char(13) + 
				',UNIP.[anio] AS modelo' + char(13) + 
				','+char(39)+''+char(39)+' AS nombreTaller ' + char(13) + 
				' ,'+char(39)+''+char(39)+' AS idEstatusCotizacion ' + char(13) +
				' ,'+char(39)+''+char(39)+' AS idCotizacion ' + char(13) +
				' ,'+char(39)+''+char(39)+' AS nombreEstatusCotizacion ' + char(13) + 
				' ,'+char(39)+''+char(39)+' AS numeroCotizacion ' + char(13) +
				','+char(39)+''+char(39)+' AS tienePresupuesto '+ char(13) +
				',(SELECT [dbo].[SEL_VALIDA_ESTATUS_PRESUPUESTO_FN](Orden.idOrden)) AS motivoPresupuesto '+ char(13) +
				',(SELECT [dbo].[SEL_TIEMPO_ASIGNADO_TRANSCURRIDO](Orden.idOrden)) AS tiempoEsperaTranscurrido '+ char(13) +
				',(SELECT [dbo].[SEL_PRECIO_VENTA_FN](Orden.idOrden, Orden.idContratoOperacion, 1,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS venta '+ char(13) + --, Orden.idContratoOperacion, 1
				',(SELECT [dbo].[SEL_PRECIO_COSTO_FN](Orden.idOrden, Orden.idContratoOperacion, 1,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS costo '+ char(13) +
			'FROM [dbo].[Ordenes] Orden' + char(13) + 
			'INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad' + char(13) + 
			'INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad' + char(13) + 
			'INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND ' + char(13) + 
			'INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion' + char(13) + 
			'INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario' + char(13) + 
			' '+ @join +' ' + char(13) + 
			'INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio' + char(13) +  
			'LEFT JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) +
			'INNER JOIN [Partidas].[dbo].[Unidad] UNIP ON UNIP.[idUnidad] = Uni.[idTipoUnidad]' + char(13) + 
			'INNER JOIN [Partidas].dbo.SubMarca SM ON UNIP.idSubMarca = SM.idSubMarca' + char(13) + 
			'INNER JOIN [Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca' + char(13) + 
			'INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden' + char(13) + 
			'INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden' + char(13) + 
			'LEFT JOIN [dbo].[PreCancelacionOrdenes] precancelaciones ON precancelaciones.idOrden= Orden.idOrden'+char(13)+
			'WHERE Orden.idEstatusOrden IN (1,2)' + char(13) +'AND precancelaciones.idOrden IS NULL' +char(13)+'AND Orden.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+'' + char(13) + '' 
	END
ELSE
	BEGIN
	IF @tipoConsulta = 2
		BEGIN
			print 'Aprobaciones'
			SET @queryText = 
			'SELECT DISTINCT' + char(13) + 
				'Orden.[idOrden] AS idOrden' + char(13) + 
				',Orden.[idGarantia] AS idGarantia' + char(13) + 
				',[numeroOrden] AS numeroOrden' + char(13) + 
				','''' AS conjuntoEstatus' + char(13) + 
				',[fechaCita] as fechaCita' + char(13) + 
				',convert(datetime,  DATEADD(HH,5,fechaCreacionOden)) as fechaCreacionOden ' + char(13) + 
				',fechaInicioTrabajo AS fechaInicioTrabajo' + char(13) + 
				',Histo.fechaInicial AS fechaEstatusActual' + char(13) + 
				',comentarioOrden AS comentarioOrden' + char(13) + 
				',Uni.[numeroEconomico] AS numeroEconomico' + char(13) + 
				',[consecutivoOrden] AS consecutivoOrden' + char(13) + 
				',[requiereGrua] AS requiereGrua' + char(13) + 
				',EstadoUni.descripcionEstadoUnidad AS descripcionEstadoUnidad' + char(13) + 
				',zona.[idZona] AS idZona' + char(13) + 
				',zona.nombre AS nombreZona' + char(13) + 
				',Uni.[idUnidad] AS idUnidad' + char(13) + 
				',(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente ' + char(13) + 
				',EtsOrden.[idEstatusOrden] AS idEstatusOrden' + char(13) + 
				',EtsOrden.[nombreEstatusOrden] AS nombreEstatusOrden' + char(13) + 
				',ConOpe.[idContratoOperacion] AS idContratoOperacion' + char(13) + 
				',Usu.[idUsuario] AS idUsuario' + char(13) + 
				',Usu.nombreCompleto AS nombreUsuario' + char(13) + 
				',CaTiOrSe.[idCatalogoTipoOrdenServicio] AS idCatalogoTipoOrdenServicio' + char(13) + 
				',CaTiOrSe.[nombreTipoOrdenServicio] AS nombreTipoOrdenServicio' + char(13) + 
				',CaTiOr.[idTipoOrden] AS idTipoOrden' + char(13) + 
				',CaTiOr.nombreTipoORden AS nombreTipoORden' + char(13) + 
				',(SELECT [dbo].[SEL_ESTADISTICA_APROBACION_FT](Coti.[idCotizacion])) AS estadistica ' + char(13) + 
				',(SELECT [dbo].[SEL_PORCENTAJE_APROBACION_FT](Coti.[idCotizacion])) AS porcentaje ' + char(13) + 
				',MA.[nombre] AS marca' + char(13) + 
				',UNIP.[anio] AS modelo' + char(13) +  
				','+char(39)+''+char(39)+' AS nombreTaller ' + char(13) + 
				',Coti.[idEstatusCotizacion] AS idEstatusCotizacion ' + char(13) +
				',Coti.[idCotizacion] AS idCotizacion ' + char(13) +
				',EstCoti.[nombreEstatusCotizacion] AS nombreEstatusCotizacion ' + char(13) + 
				',Coti.[numeroCotizacion] AS numeroCotizacion ' + char(13) +
				',(SELECT [dbo].[SEL_OPERACION_TIENE_PRESUPUESTO](Orden.idOrden)) AS tienePresupuesto '+ char(13) +
				',(SELECT [dbo].[SEL_VALIDA_ESTATUS_PRESUPUESTO_FN](Orden.idOrden)) AS motivoPresupuesto '+ char(13) +
				',(SELECT [dbo].[SEL_TIEMPO_ASIGNADO_TRANSCURRIDO](Orden.idOrden)) AS tiempoEsperaTranscurrido '+ char(13) +
				', ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) '+ char(13) +
				--',(SELECT [dbo].[SEL_PRECIO_VENTA_FN](Orden.idOrden, Orden.idContratoOperacion, 2,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS venta '+ char(13) + --, Orden.idContratoOperacion, 2
				', ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) '+ char(13) +
				--',(SELECT [dbo].[SEL_PRECIO_COSTO_FN](Orden.idOrden, Orden.idContratoOperacion, 2,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS costo '+ char(13) +
			'FROM [dbo].[Ordenes] Orden' + char(13) + 
			'INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad' + char(13) + 
			'INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad' + char(13) + 
			'INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND ' + char(13) + 
			'INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion' + char(13) + 
			'INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio' + char(13) + 
			'LEFT JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) +
			'INNER JOIN [Partidas].[dbo].[Unidad] UNIP ON UNIP.[idUnidad] = Uni.[idTipoUnidad]' + char(13) + 
			'INNER JOIN [Partidas].dbo.SubMarca SM ON UNIP.idSubMarca = SM.idSubMarca' + char(13) + 
			'INNER JOIN [Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca' + char(13) +  
			'INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden' + char(13) + 
			'INNER JOIN [dbo].[Cotizaciones] Coti ON Orden.idOrden = Coti.idOrden' + char(13) + 
			'INNER JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = Coti.idCotizacion' + char(13) + 
			'INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Coti.idUsuario' + char(13) + 
			' '+ @join +' ' + char(13) + 
			'INNER JOIN [dbo].[EstatusCotizaciones] EstCoti ON EstCoti.[idEstatusCotizacion] = Coti.[idEstatusCotizacion]' + char(13) +
			'INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden' + char(13) + 
			--'LEFT JOIN [Partidas].[dbo].[Proveedor] provee ON provee.idProveedor = Coti.idTaller' + char(13) +
			' AND (Orden.idEstatusOrden  IN (4, 5))' + char(13) + 
			' AND (Coti.idEstatusCotizacion IN(1,2))' + char(13) +
			' AND (CD.idEstatusPartida IN(1,2))' + char(13) +
			' AND Orden.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+ ' ' 
			
			set @groupBy = ' GROUP BY Orden.idOrden, Orden.idGarantia, Orden.numeroOrden, Orden.fechaCita, Orden.fechaCreacionOden, Orden.fechaInicioTrabajo, Histo.fechaInicial, Orden.comentarioOrden, Uni.[numeroEconomico], [consecutivoOrden], [requiereGrua], EstadoUni.descripcionEstadoUnidad, zona.[idZona], zona.nombre, Uni.[idUnidad], EtsOrden.[idEstatusOrden], EtsOrden.[nombreEstatusOrden], ConOpe.[idContratoOperacion], Usu.[idUsuario] , Usu.nombreCompleto, CaTiOrSe.[idCatalogoTipoOrdenServicio], CaTiOrSe.[nombreTipoOrdenServicio], CaTiOr.[idTipoOrden], CaTiOr.nombreTipoORden, MA.[nombre], UNIP.[anio], Coti.[idEstatusCotizacion], Coti.[idCotizacion], EstCoti.[nombreEstatusCotizacion], Coti.[numeroCotizacion]'

		END
	ELSE
		BEGIN
			print 'ordenes de servicio'
			SET @queryText = 
			'SELECT distinct' + char(13) + 
				'Orden.[idOrden] AS idOrden' + char(13) + 
				',Orden.[idGarantia] AS idGarantia' + char(13) + 
				',[numeroOrden] AS numeroOrden' + char(13) + 
				',CASE WHEN EtsOrden.[idEstatusOrden] = 6 THEN ''1'' WHEN EtsOrden.[idEstatusOrden] = 7 THEN ''1''  ELSE ''0'' END AS conjuntoEstatus' + char(13) +  
				',[fechaCita] as fechaCita' + char(13) + 
				',convert(datetime,  DATEADD(HH,5,fechaCreacionOden)) as fechaCreacionOden ' + char(13) + 
				',convert(datetime,  DATEADD(HH,5,fechaInicioTrabajo)) AS fechaInicioTrabajo' + char(13) + 
				',Histo.fechaInicial AS fechaEstatusActual' + char(13) + 
				',comentarioOrden AS comentarioOrden' + char(13) + 
				',Uni.[numeroEconomico] AS numeroEconomico' + char(13) + 
				',[consecutivoOrden] AS consecutivoOrden' + char(13) + 
				',[requiereGrua] AS requiereGrua' + char(13) + 
				',EstadoUni.descripcionEstadoUnidad AS descripcionEstadoUnidad' + char(13) + 
				',zona.[idZona] AS idZona' + char(13) + 
				',zona.nombre AS nombreZona' + char(13) + 
				',Uni.[idUnidad] AS idUnidad' + char(13) + 
				',(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente ' + char(13) + 
				',EtsOrden.[idEstatusOrden] AS idEstatusOrden' + char(13) + 
				',CASE WHEN Orden.idGarantia = 1 AND EtsOrden.[idEstatusOrden] = 5 THEN ''En Proceso - Garantia'' ELSE EtsOrden.[nombreEstatusOrden] END AS nombreEstatusOrden' + char(13) + 
				',ConOpe.[idContratoOperacion] AS idContratoOperacion' + char(13) + 
				',Usu.[idUsuario] AS idUsuario' + char(13) + 
				',Usu.nombreCompleto AS nombreUsuario' + char(13) + 
				',CaTiOrSe.[idCatalogoTipoOrdenServicio] AS idCatalogoTipoOrdenServicio' + char(13) + 
				',CaTiOrSe.[nombreTipoOrdenServicio] AS nombreTipoOrdenServicio' + char(13) + 
				',CaTiOr.[idTipoOrden] AS idTipoOrden' + char(13) + 
				',CaTiOr.nombreTipoORden AS nombreTipoORden' + char(13) + 
				','+char(39)+''+char(39)+' AS estadistica ' + char(13) + 
				','+char(39)+''+char(39)+' AS porcentaje ' + char(13) + 
				',MA.[nombre] AS marca' + char(13) + 
				',UNIP.[anio] AS modelo' + char(13) +  
				','+char(39)+''+char(39)+' AS nombreTaller ' + char(13) +
				','+char(39)+''+char(39)+' AS idEstatusCotizacion ' + char(13) +
				','+char(39)+''+char(39)+' AS idCotizacion ' + char(13) +
				','+char(39)+''+char(39)+' AS nombreEstatusCotizacion ' + char(13) + 
				','+char(39)+''+char(39)+' AS numeroCotizacion ' + char(13) +
				','+char(39)+''+char(39)+' AS tienePresupuesto '+ char(13) +
				','+char(39)+''+char(39)+' AS motivoPresupuesto '+ char(13) +
				',(SELECT [dbo].[SEL_TIEMPO_ASIGNADO_TRANSCURRIDO](Orden.idOrden)) AS tiempoEsperaTranscurrido '+ char(13) +
				--',0 AS venta '+ char(13) +
				--',0 AS costo '+ char(13) +
				',(SELECT [dbo].[SEL_PRECIO_VENTA_FN](Orden.idOrden, Orden.idContratoOperacion, 3,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS venta '+ char(13) + --, Orden.idContratoOperacion, 3
				',(SELECT [dbo].[SEL_PRECIO_COSTO_FN](Orden.idOrden, Orden.idContratoOperacion, 3,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS costo '+ char(13) +
			'FROM [dbo].[Ordenes] Orden' + char(13) + 
			'INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad' + char(13) + 
			'INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad' + char(13) + 
			'INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND ' + char(13) + 
			'INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion' + char(13) + 
			'INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario' + char(13) + 
			' '+ @join +' ' + char(13) + 
			'INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio' + char(13) + 
			'LEFT JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona' + char(13) + 
			'INNER JOIN [Partidas].[dbo].[Unidad] UNIP ON UNIP.[idUnidad] = Uni.[idTipoUnidad]' + char(13) + 
			'INNER JOIN [Partidas].dbo.SubMarca SM ON UNIP.idSubMarca = SM.idSubMarca' + char(13) + 
			'INNER JOIN [Partidas].dbo.Marca MA ON MA.idMarca = SM.idMarca' + char(13) +
			'INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden' + char(13) + 
			'INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden' + char(13) + 
			'WHERE histo.idEstatusOrden  in (5,6,7)' + char(13) + 'AND Orden.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+'' + char(13) + '' 

		END
	END


IF(@IdZona != 0)
BEGIN
	DECLARE @idPrueba int = 0
	DECLARE @idPadre int = 0
	DECLARE @VariableTabla TABLE ( --ID INT IDENTITY(1,1),
								idZona INT, 
								idPadre INT, 
								nombreNivel NVARCHAR(150),
								nombre NVARCHAR(150))

	INSERT INTO @VariableTabla (idZona, idPadre,nombreNivel,nombre) 
	SELECT Zona.idZona, Zona.idPadre, NivelZ.etiqueta AS nombreNivel, Zona.nombre 
	FROM Partidas.dbo.Zona AS Zona
		INNER JOIN Partidas.dbo.NivelZona AS NivelZ
		ON Zona.idNivelZona = NivelZ.idNivelZona
		WHERE idZona = @IdZona

	DECLARE @VariableTablaXXX TABLE (idZona INT)

	INSERT INTO @VariableTablaXXX(idZona)
	SELECT Zona.idZona FROM Partidas.dbo.Zona AS Zona
	INNER JOIN Partidas.dbo.NivelZona as NivelZ
	ON Zona.idNivelZona = NivelZ.idNivelZona
    WHERE Zona.idPadre in(@IdZona)

	WHILE (@IdZona != @idPrueba)
		BEGIN
			SET @idPrueba = @IdZona
			DECLARE nivel CURSOR FOR
				SELECT Zona.idZona FROM Partidas.dbo.Zona AS Zona
						INNER JOIN Partidas.dbo.NivelZona as NivelZ
						ON Zona.idNivelZona = NivelZ.idNivelZona
				WHERE Zona.idZona in(SELECT idZona FROM @VariableTablaXXX)

					OPEN nivel
					FETCH NEXT FROM nivel INTO @idZona
						WHILE @@FETCH_STATUS = 0
						BEGIN
								INSERT INTO @VariableTabla (idZona,idPadre,nombreNivel,nombre) 
								SELECT Zona.idZona, Zona.idPadre, NivelZ.etiqueta AS nombreNivel, Zona.nombre 
								FROM Partidas.dbo.Zona AS Zona
									INNER JOIN Partidas.dbo.NivelZona as NivelZ ON Zona.idNivelZona = NivelZ.idNivelZona
									WHERE Zona.idZona = @idZona

								INSERT INTO @VariableTablaXXX 
								SELECT idZona 
								FROM @VariableTabla 
								WHERE idZona NOT IN(SELECT idZona FROM @VariableTablaXXX) 

								INSERT INTO @VariableTablaXXX
								SELECT idZona 
								FROM Partidas.dbo.Zona 
								WHERE idPadre IN(SELECT idZona FROM @VariableTablaXXX) AND idZona NOT IN(SELECT idZona FROM @VariableTabla) AND idZona NOT IN(SELECT idZona FROM @VariableTablaXXX)

							FETCH NEXT FROM nivel INTO @idZona
						END
					CLOSE nivel
					DEALLOCATE nivel
			END 
				DECLARE contact_cursor CURSOR FOR
			SELECT DISTINCT idZona FROM @VariableTabla

			OPEN contact_cursor  
			FETCH NEXT FROM contact_cursor INTO @idZona
			WHILE @@FETCH_STATUS = 0  
				BEGIN 

				SET @zonaminas =(SELECT TOP 1 idZona FROM @VariableTabla where idZona=@idZona)
				SET @plusZona = @plusZona + @zonaminas + ', '

				FETCH NEXT FROM contact_cursor INTO @idZona
				END  
			CLOSE contact_cursor  
			DEALLOCATE contact_cursor

			IF((@plusZona IS NOT NULL) AND @plusZona != '')
		SET @zonas= SUBSTRING (@plusZona, 1, Len(@plusZona) - 1 )
			SET @zona = ' AND (CONVERT(NVARCHAR(100), Orden.idZona) IN( '+ @zonas +' )) '

			SET @query = @queryText + @zona + @usuario + @groupBy
	
	END
	ELSE
	BEGIN
			SET @query = @queryText + @usuario + @groupBy
	END

	--select @queryText 
	INSERT INTO @todo 
	EXECUTE SP_EXECUTESQL @query
	print @query

	IF @idCatalogoRol <> 2
	begin
		IF @idCatalogoRol <> 4
		begin
			SELECT *, CONVERT (VARCHAR,fechaCreacionOden,103) as x
			FROM @todo 
			WHERE ((@fechaInicial = '')OR(fechaCreacionOden BETWEEN CONVERT (VARCHAR,@fechaInicial,103) AND  CONVERT (VARCHAR,@fechaFin,103)))
					AND ((@fechaMes = '')OR(fechaCreacionOden BETWEEN CONVERT(VARCHAR,@fechaprimer,103) AND CONVERT(DATETIME,@fechaFinal,103)))
					AND((@fechaEspecifico = '')OR( CONVERT (DATE,fechaCreacionOden) =  Convert(DATE,@fechaEspecifico)))
					AND idZona in (select idZona from @zonasAsignadas)
		end
		else
		begin
			SELECT *, CONVERT (VARCHAR,fechaCreacionOden,103) as x
			FROM @todo 
			WHERE ((@fechaInicial = '')OR(fechaCreacionOden BETWEEN CONVERT (VARCHAR,@fechaInicial,103) AND  CONVERT (VARCHAR,@fechaFin,103)))
					AND ((@fechaMes = '')OR(fechaCreacionOden BETWEEN CONVERT(VARCHAR,@fechaprimer,103) AND CONVERT(DATETIME,@fechaFinal,103)))
					AND((@fechaEspecifico = '')OR( CONVERT (DATE,fechaCreacionOden) =  Convert(DATE,@fechaEspecifico)))
					--AND idZona in (select idZona from @zonasAsignadas)
		end
	end
	else
	begin
		SELECT *, CONVERT (VARCHAR,fechaCreacionOden,103) as x
		FROM @todo 
		WHERE ((@fechaInicial = '')OR(fechaCreacionOden BETWEEN CONVERT (VARCHAR,@fechaInicial,103) AND  CONVERT (VARCHAR,@fechaFin,103)))
				AND ((@fechaMes = '')OR(fechaCreacionOden BETWEEN CONVERT(VARCHAR,@fechaprimer,103) AND CONVERT(DATETIME,@fechaFinal,103)))
				AND((@fechaEspecifico = '')OR( CONVERT (DATE,fechaCreacionOden) =  Convert(DATE,@fechaEspecifico)))
	end
			
END
go

