
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_ESTATUS_IDBPRO_FN](@numeroOrden NVARCHAR(100), @idOperacion NUMERIC(18,0), @isProduction NUMERIC(18,0))

RETURNS INT
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result INT;
	
	IF(@isProduction = 1)
		BEGIN
			IF(@idOperacion IN(1,2))
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					--FROM [GATPartsToluca].[dbo].[ADE_ORDSERENC]
					FROM [192.168.20.29].[GATPartsToluca].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
			ELSE IF (@idOperacion = 28 ) --Banorte 20-Dev, 28-Prod
				BEGIN 
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					--FROM [GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]
					FROM [192.168.20.29].[GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					--FROM [GAAutoExpress].[dbo].[ADE_ORDSERENC]
					FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
		END
	ELSE
		BEGIN
			IF(@idOperacion IN(1,2))
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					FROM [GATPartsToluca_P].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
			ELSE IF (@idOperacion = 20 ) --Banorte 20-Dev, 28-Prod
				BEGIN 
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					FROM [GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
				ELSE
				BEGIN
					SET @Result =ISNULL((SELECT TOP 1 OTE_STATUS 
					FROM [GAAutoExpressprueba].[dbo].[ADE_ORDSERENC]
					WHERE OTE_ORDENANDRADE=@numeroOrden),7)
				END
		END

	RETURN @Result;
	
END

go

