-- =============================================
-- Author:		Sahirely Yam
-- Create date: 29 08 2017
-- EXEC [dbo].[SEL_ORDENES_BY_CENTRO_TRABAJO_SP] 34, 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ORDENES_BY_CENTRO_TRABAJO_SP]
		@idCentroTrabajo int,
		@idContratoOperacion int
AS
BEGIN
	SET NOCOUNT ON;

	select	ORD.idOrden
			, consecutivoOrden
			, numeroOrden
			, fechaCreacionOden as fechaCreacionOrden
			, EO.nombreEstatusOrden as estatus
			, ORD.comentarioOrden as comentario
			, CT.nombreCentroTrabajo
			, isnull(sum(isnull(COTDET.venta,0) * isnull(COTDET.cantidad,0)),0) as venta
			, isnull(sum(isnull(COTDET.costo,0) * isnull(COTDET.cantidad,0)),0) as costo
		from Ordenes ORD 
		inner join ContratoOperacion CONTOPE on CONTOPE.idContratoOperacion = ORD.idContratoOperacion
		inner join Cotizaciones COTI on COTI.idOrden = ORD.idOrden
		inner join CotizacionDetalle COTDET on COTDET.idCotizacion = COTI.idCotizacion
		inner join EstatusOrdenes EO on ORD.idEstatusOrden = EO.idEstatusOrden
		inner join CentroTrabajos CT on CT.idCentroTrabajo = ORD.idCentroTrabajo and CONTOPE.idOperacion = CT.idOperacion
		where	ORD.idCentroTrabajo = @idCentroTrabajo 
				and ORD.idContratoOperacion = @idContratoOperacion
				and COTI.idEstatusCotizacion in (1,2,3) 
				and COTDET.idEstatusPartida in (1,2) 
				and ORD.idEstatusOrden in (1,2,3,4)		
				and ORD.idOrden not in (select idOrden from OrdenesPresupuestoEspecial)
		group by ORD.idOrden, consecutivoOrden, numeroOrden, fechaCreacionOden, nombreEstatusOrden, comentarioOrden, nombreCentroTrabajo

END
go

