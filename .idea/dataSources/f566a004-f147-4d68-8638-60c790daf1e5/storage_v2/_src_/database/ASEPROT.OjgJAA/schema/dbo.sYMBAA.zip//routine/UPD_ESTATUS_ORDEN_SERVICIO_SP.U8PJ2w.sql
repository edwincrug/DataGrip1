
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 06/06/2017
-- Description:	Stored para cambiar de estatus la Orden
-- ==========================================================================================

CREATE PROCEDURE [dbo].[UPD_ESTATUS_ORDEN_SERVICIO_SP] --28915,158
    @idOrden NUMERIC(10,0),
    @idUsuario NUMERIC(12,0)
AS   
	DECLARE @idHistorico NUMERIC(15,0);
	DECLARE @Estatus NUMERIC(15,0);
	DECLARE @NuevoEstatus NUMERIC(15,0);

	-- SET @idOrden   = 11;
	-- SET @idUsuario = 2;
	SET @Estatus   = (SELECT idEstatusOrden FROM Ordenes WHERE idOrden = @idOrden);

	IF( @Estatus IS NOT NULL )
		BEGIN
			IF( (@Estatus >= 5 AND @Estatus <= 7) OR @Estatus = 3 )
				BEGIN
					SET @idHistorico = (SELECT TOP 1 idHistorialEstatusOrden FROM HistorialEstatusOrden WHERE idOrden = @idOrden AND idEstatusOrden = @Estatus ORDER BY idHistorialEstatusOrden DESC );
			
					IF( @idHistorico IS NOT NULL )
						BEGIN
							SET @NuevoEstatus = ( @Estatus + 1 )
							-- Aquí debe ocurrir la magia
							UPDATE HistorialEstatusOrden SET fechaFinal = CURRENT_TIMESTAMP WHERE idHistorialEstatusOrden = @idHistorico;
							INSERT INTO HistorialEstatusOrden VALUES( @idOrden, @NuevoEstatus, CURRENT_TIMESTAMP, NULL, @idUsuario );
							UPDATE Ordenes SET idEstatusOrden = @NuevoEstatus WHERE idOrden = @idOrden;
							SELECT Success = 1, Msg = 'Se cambio el estatus de la Orden correctamente';
						END
					ELSE
						BEGIN
							SELECT Success = 0, Msg = 'El registro esta corrumpo, no se encontro ';
						END	
				END
			ELSE
				BEGIN
					SELECT Success = 0, Msg = 'El SP solo funciona para las Ordenes en estatus 5, 6 y 7, y tu orden se encuentra en estatus ' + CONVERT(VARCHAR(10),@Estatus);
				END	
		END
	ELSE
		BEGIN
			SELECT Success = 0, Msg = 'No se ha encontrado la Orden que buscaba';
		END
go

grant execute, view definition on UPD_ESTATUS_ORDEN_SERVICIO_SP to DevOps
go

