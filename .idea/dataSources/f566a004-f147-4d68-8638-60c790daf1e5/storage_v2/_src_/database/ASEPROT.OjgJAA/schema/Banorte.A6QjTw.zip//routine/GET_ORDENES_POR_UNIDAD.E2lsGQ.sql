



/*
	Fecha			Autor			Descripción
	21-May-2018		José Etmanuel	Trae las ordenes de una unidad
*/

CREATE proc [Banorte].[GET_ORDENES_POR_UNIDAD]
@idUnidad int =0
as 
Begin

  select o.idOrden,
         o.fechaCita,
         o.numeroOrden,
		 isnull(ctos.Servicio,o.comentarioOrden) as servicio,
		 case o.idEstatusOrden when 1 then 'Nueva sin Taller'
		                       when 2 then 'Nueva con Taller'
							   when 3 then 'En Taller'
							   when 4 then 'En Taller'
							   when 5 then 'En Taller'
							   when 6 then 'Termino de Trabajo'
							   when 7 then 'Entrega'
							   end as Estatus
  from Ordenes o 
  join [ServiosAppMiAuto] ctos on o.idCatalogoTipoOrdenServicio=ctos.idServicio
  where o.idCatalogoTipoOrdenServicio=2 and o.idEstatusOrden<>13 and o.idUnidad=@idUnidad
end

go

grant execute, view definition on Banorte.GET_ORDENES_POR_UNIDAD to DevOps
go

