CREATE VIEW [cobranza].[VwFechaInicialHistorialStatusOrden]
AS
select max(FechaInicial) as FechaInicial, idOrden, idEstatusOrden 
from HistorialEstatusOrden
Group by idOrden, idEstatusOrden
go

