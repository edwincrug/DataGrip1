










CREATE VIEW [report].[VwReporteAntiguedadSaldosA]
AS
			  SELECT CLI.nombreComercial as [Cliente]
			         ,ORD.idOrden
							,ORD.consecutivoOrden
							,ORD.numeroOrden
							,U.numeroEconomico
							,ORD.idZona							
							,[dbo].[SEL_TALLERES_ORDEN_FN](ORD.idOrden) talleres
							--,convert(numeric(18,2),ISNULL(sum(ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0)),0.00)) costo
							--,convert(numeric(18,2),ISNULL(sum(ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0)),0.00)) venta
							,[VOT].costo
							,[VOT].venta
							,ORD.comentarioOrden descripcion				
							,EO.nombreEstatusOrden as estatus
							,EO.idEstatusOrden as idEstatus
							--,'' folioCertificado
							--,'' copade
							,ORD.fechaCreacionOden as fechaCreacionOrden        
							--,COTI.fechaCotizacion as fechaCotizacion
							--,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =4) as fechaAprobacion
							,VOSD4.[FechaMax] as [fechaAprobacion]     
							--,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =5)  as fechaProceso
							,VOSD5.[FechaMax] as [fechaProceso]     
							--,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =6)  as fechaTerminoTrabajo
							,VOSD6.[FechaMax] as [fechaTerminoTrabajo]     
							--,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =7)  as fechaSalida
							--,(select top 1  fechaInicial from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =8)  as [fechaDeFinalizacion]
							,VOSD7.[FechaMax] as [fechaSalidaV]  
							,VOSD8.[FechaMax] as [fechadeFinalizacionV]        
							----,getdate()  fechaCertificado
							--,case when (select top 1 DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) <= 30 then 1 else 0 end as   dias_0_30
							,case when VOSDO.Dias <= 30 then 1 else 0 end as   dias_0_30
							--,case when (select top 1  DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) between 31 and 45  then 1 else 0 end as dias_31_45
							,case when VOSDO.Dias between 31 and 45  then 1 else 0 end as dias_31_45
							--,case when (select top 1  DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) between 36 and 60  then 1 else 0 end as dias_46_60
							,case when VOSDO.Dias between 36 and 60  then 1 else 0 end as dias_46_60
							--,case when (select top 1  DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) > 60  then 1 else 0 end as dias_mas_60
							,case when VOSDO.Dias > 60  then 1 else 0 end as dias_mas_60
							--,(select top 1  DATEDIFF (day,fechaInicial,getdate()) from HistorialEstatusOrden where idOrden = ORD.idOrden  and idEstatusOrden =ORD.idEstatusOrden) dias
							,VOSDO.Dias [dias]
							,ltrim(VOSDO.Dias)+' dias' [diasD]
							,[dbo].[SEL_ZONAS_NAME_FN](ORD.idZona) as zonasConcatenadas
							,zp.nombre as nombrePadre
							,Z.nombre as nombreZona
							,TU.tipo AS tipoUnidad
							,TC.tipoCombustible as tipoCombustible
							, M.nombre AS marca
							,SM.nombre as subMarca
							,U.modelo as modelo		 			
							,PO.[folio] as [folio]
							,P.[folioPresupuesto] as [folioPresupuesto]
							,OPE.idOperacion
							,ORD.idEstatusOrden
					FROM Ordenes ORD
						INNER JOIN Unidades U on U.idUnidad = ORD.idUnidad
						INNER JOIN EstatusOrdenes EO on EO.idEstatusOrden = ORD.idEstatusOrden
						INNER JOIN CatalogoTiposOrdenServicio CTOS on CTOS.idCatalogoTipoOrdenServicio = ORD.idCatalogoTipoOrdenServicio
					--	INNER JOIN Cotizaciones COTI on COTI.idOrden = ORD.idOrden
					--	INNER JOIN CotizacionDetalle CD on CD.idCotizacion = COTI.idCotizacion
						INNER JOIN ContratoOperacion CO on CO.idContratoOperacion = ORD.idContratoOperacion
						INNER JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
						INNER JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
						INNER JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
						INNER JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
						INNER JOIN Partidas..Zona Z on Z.idZona = ORD.idZona
						INNER JOIN Partidas..Zona Zp on Zp.idZona = z.idPadre
						INNER JOIN Partidas..Unidad PU on PU.idUnidad= U.idTipoUnidad
						INNER JOIN Partidas..TipoUnidad TU on TU.idTipoUnidad= PU.idTipoUnidad
						INNER JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible 
						INNER JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
						INNER JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
						LEFT JOIN  [dbo].[PresupuestoOrden] PO ON PO.[idOrden] = ORD.[idOrden]
						LEFT JOIN  [dbo].[Presupuestos] P ON P.[idPresupuesto] = PO.[idPresupuesto]
						--LEFT JOIN  --[ASEPROT].[report].[VwOrdenStatusMaxDate] 
						LEFT JOIN  [report].[VwOrdenStatusMaxDate] VOSD4 ON VOSD4.[idOrden] = ORD.[idOrden]  and VOSD4.[idEstatusOrden] = 4 
						LEFT JOIN  [report].[VwOrdenStatusMaxDate] VOSD5 ON VOSD5.[idOrden] = ORD.[idOrden]  and VOSD5.[idEstatusOrden] = 5
						LEFT JOIN  [report].[VwOrdenStatusMaxDate] VOSD6 ON VOSD6.[idOrden] = ORD.[idOrden]  and VOSD6.[idEstatusOrden] = 6
						LEFT JOIN  [report].[VwOrdenStatusMaxDate] VOSD7 ON VOSD7.[idOrden] = ORD.[idOrden]  and VOSD7.[idEstatusOrden] = 7
						LEFT JOIN  [report].[VwOrdenStatusMaxDate] VOSD8 ON VOSD8.[idOrden] = ORD.[idOrden]  and VOSD8.[idEstatusOrden] = 8
						LEFT JOIN  [report].[VwOrdenStatusMaxDateDias] VOSDO ON VOSDO.[idOrden] = ORD.[idOrden]  and VOSDO.[idEstatusOrden] = ORD.[idEstatusOrden] 
						LEFT JOIN  [report].[VwOrdenTotales] VOT ON VOT.[idOrden] = ORD.[idOrden]
					WHERE ORD.idEstatusOrden not in (13) 
				    --WHERE ORD.idEstatusOrden not in (9,10,11,12,13) 
					  --AND CD.idEstatusPartida in( 1,2) 
					  --AND coti.idEstatusCotizacion in (1,2,3) 
					 ---AND OPE.idOperacion = 3

					--GROUP BY ORD.idOrden,
					--	CLI.nombreComercial,
					--	ORD.consecutivoOrden,
					--	ORD.numeroOrden,
					--	U.numeroEconomico,
					--	ORD.idZona,
					--	ORD.fechaCreacionOden,
					--	EO.nombreEstatusOrden,
					--	CTOS.nombreTipoOrdenServicio,
					--	OPE.porcentajeUtilidad,
					--	COTI.fechaCotizacion,
					--	ORD.comentarioOrden,
					--	ORD.idEstatusOrden,
					--	Z.nombre,
					--	EO.idEstatusOrden, 
					--	TU.tipo,
					--	TC.tipoCombustible,
					--	M.nombre,
					--	SM.nombre,
					--	U.modelo,
					--	PO.[folio],
					--    P.[folioPresupuesto],
					--	VOSD4.[FechaMax],
					--	VOSD5.[FechaMax],
					--	VOSD6.[FechaMax],
					--	VOSD7.[FechaMax],
					--	VOSDO.[Dias],
					--    OPE.idOperacion,
					--    ORD.idEstatusOrden
go

