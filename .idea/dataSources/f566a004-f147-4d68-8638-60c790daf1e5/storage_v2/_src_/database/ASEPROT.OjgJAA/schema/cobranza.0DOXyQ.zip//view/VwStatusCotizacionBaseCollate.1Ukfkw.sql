/* DROP VIEW [cobranza].[VwStatusCotizacionBaseCollate]
 SELECT * from [cobranza].[VwStatusCotizacionBaseCollate]
 RECORDS  32,834    TIME 6:28
 RECORDS  20,077    TIME 0:00
COLLATE Modern_Spanish_CI_AS*/
CREATE VIEW cobranza.VwStatusCotizacionBaseCollate
AS
SELECT     VwCPI.idCotizacion, VwCPI.numFactura, VwIPS.CCP_IDDOCTO AS NumFacturaF, CASE WHEN (VwIPS.[SALDO]) < 0.01 THEN NULL ELSE (VwIPS.[SALDO]) 
                      END AS DeudaDia
FROM         cobranza.VwCotizacionProvInvoiceDef AS VwCPI INNER JOIN
                      cobranza.InvoiceProvSaldoBPRO_GAAutoExpressC AS VwIPS ON VwIPS.CCP_IDPERSONA = VwCPI.idProveedor AND VwIPS.CCP_IDDOCTO = VwCPI.numFactura
go

