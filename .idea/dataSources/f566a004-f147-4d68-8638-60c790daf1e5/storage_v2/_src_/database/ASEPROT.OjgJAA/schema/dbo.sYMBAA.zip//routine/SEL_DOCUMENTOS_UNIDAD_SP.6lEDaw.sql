/*-------------------------------
select * from contratooperacionfacturacion
select * from contratooperacion
[SEL_DOCUMENTOS_UNIDAD_SP] '0075', 6
[SEL_DOCUMENTOS_UNIDAD_SP] '3', 12
select * from unidades where vin ='3VW2K1AJ2JM234040'
select * from unidades where vin ='3C6TRVCG2EE118825'
select * from unidades where vin ='3C4NJCCBXJT148095'
select * from unidades where vin ='3C6TRVCG5EE118608'
-------------------------------*/
 CREATE PROCEDURE [dbo].[SEL_DOCUMENTOS_UNIDAD_SP]
	@numeroEconomico NVARCHAR(1000),
	@idOperacion INT
AS
BEGIN

	DECLARE @vin NVARCHAR(100) = (select vin from Unidades where numeroEconomico=@numeroEconomico AND idOperacion=@idOperacion)
	DECLARE @server NVARCHAR(200) = 'http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'

		SELECT * FROM(SELECT TOP 1 LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, @server+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT CONVERT(VARCHAR(100), UP.valor, 126) FROM [Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite, '4' Estructura
		FROM [Flotillas].[dbo].[ListaDocumentos] LD
			JOIN [Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento
		WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin AND LD.idDocumento in(23) AND LD.vin NOT IN(SELECT CConVIN FROM [Flotillas].[dbo].[Contribuciones_Datos] WHERE CConVIN=LD.vin AND CConTipo IS NULL AND CConIdTipoPago = 4)
		ORDER BY LD.consecutivo DESC) AS polizaSeguros
	UNION
		SELECT * FROM(SELECT TOP 1 LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, @server+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT CONVERT(VARCHAR(100), UP.valor, 126) FROM [Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite, '2' Estructura
		FROM [Flotillas].[dbo].[ListaDocumentos] LD
			JOIN [Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento
		WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin AND LD.idDocumento in(22) AND LD.vin NOT IN(SELECT CConVIN FROM [Flotillas].[dbo].[Contribuciones_Datos] WHERE CConVIN=LD.vin AND CConTipo IS NULL AND CConIdTipoPago = 2)
		ORDER BY LD.consecutivo DESC) AS pagoVerificacion
	UNION
		SELECT * FROM(SELECT TOP 1 LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, @server+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT CONVERT(VARCHAR(100), UP.valor, 126) FROM [Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite, '1' Estructura
		FROM [Flotillas].[dbo].[ListaDocumentos] LD
			JOIN [Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento
		WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin AND LD.idDocumento in(31) AND LD.vin NOT IN(SELECT CConVIN FROM [Flotillas].[dbo].[Contribuciones_Datos] WHERE CConVIN=LD.vin AND CConTipo IS NULL AND CConIdTipoPago = 1)
		ORDER BY LD.consecutivo DESC) AS tenencia
	UNION
		SELECT * FROM(SELECT TOP 1 LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, @server+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT CONVERT(VARCHAR(100), UP.valor, 126) FROM [Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite, '2' Estructura
		FROM [Flotillas].[dbo].[ListaDocumentos] LD
			JOIN [Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento 
		WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin AND LD.idDocumento in(36) AND LD.vin NOT IN(SELECT CConVIN FROM [Flotillas].[dbo].[Contribuciones_Datos] WHERE CConVIN=LD.vin AND CConTipo IS NULL AND CConIdTipoPago = 2)
		ORDER BY LD.consecutivo DESC) AS verificacion
	UNION 
		SELECT * FROM(SELECT TOP 1 CD.CConVIN AS vin, CASE WHEN CConIdTipoPago=1 THEN 31 WHEN CConIdTipoPago=2 THEN 22 WHEN CConIdTipoPago=4 THEN 23 ELSE CConIdContribucion END AS idDocumento, CD.CConUrlArchivo  AS valor, CDArchConsecutivo AS consecutivo, CTP.TipPConcepto AS nombre, CTP.TipPAlias AS descripcion, REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS tipo, @server +CD.CConVIN+'/'+CONVERT(NVARCHAR(100),CD.CConIdContribucion)+ISNULL('_'+CONVERT(NVARCHAR(100),CDArchConsecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS ruta,  CONVERT(VARCHAR(100), CD.CConFechaVigencia, 126) AS FechaLimite, '1' Estructura
		FROM [Flotillas].[dbo].[Contribuciones_Datos] CD
			JOIN [Flotillas].[dbo].[Contribuciones_TipoPago] CTP ON CTP.TipPIdTipoPago = CD.CConIdTipoPago
			JOIN [Flotillas].[dbo].[Contribuciones_Datos_Archivos] CDA ON CDA.CDArchIdContribucion = CD.CConIdContribucion
		WHERE CD.CConTipo IS NULL AND CD.CConVIN = @vin AND CD.CConIdTipoPago = 1
		ORDER BY CDA.CDArchValor DESC) tenencia
	UNION 
		SELECT * FROM(SELECT TOP 1 CD.CConVIN AS vin, CASE WHEN CConIdTipoPago=1 THEN 31 WHEN CConIdTipoPago=2 THEN 22 WHEN CConIdTipoPago=4 THEN 23 ELSE CConIdContribucion END AS idDocumento, CD.CConUrlArchivo  AS valor, CDArchConsecutivo AS consecutivo, CTP.TipPConcepto AS nombre, CTP.TipPAlias AS descripcion, REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS tipo, @server +CD.CConVIN+'/'+CONVERT(NVARCHAR(100),CD.CConIdContribucion)+ISNULL('_'+CONVERT(NVARCHAR(100),CDArchConsecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS ruta, CONVERT(VARCHAR(100), CD.CConFechaVigencia, 126) AS FechaLimite, '2' Estructura
		FROM [Flotillas].[dbo].[Contribuciones_Datos] CD
			JOIN [Flotillas].[dbo].[Contribuciones_TipoPago] CTP ON CTP.TipPIdTipoPago = CD.CConIdTipoPago
			JOIN [Flotillas].[dbo].[Contribuciones_Datos_Archivos] CDA ON CDA.CDArchIdContribucion = CD.CConIdContribucion
		WHERE CD.CConTipo IS NULL AND CD.CConVIN = @vin AND CD.CConIdTipoPago = 2
		ORDER BY CDA.CDArchValor DESC) pagoVerificacion
	UNION 
		SELECT * FROM(SELECT TOP 1 CD.CConVIN AS vin, CASE WHEN CConIdTipoPago=1 THEN 31 WHEN CConIdTipoPago=2 THEN 22 WHEN CConIdTipoPago=4 THEN 23 ELSE CConIdContribucion END AS idDocumento, CD.CConUrlArchivo  AS valor, CDArchConsecutivo AS consecutivo, CTP.TipPConcepto AS nombre, CTP.TipPAlias AS descripcion, REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS tipo, @server +CD.CConVIN+'/'+CONVERT(NVARCHAR(100),CD.CConIdContribucion)+ISNULL('_'+CONVERT(NVARCHAR(100),CDArchConsecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS ruta, CONVERT(VARCHAR(100), CD.CConFechaVigencia, 126) AS FechaLimite, '4' Estructura
		FROM [Flotillas].[dbo].[Contribuciones_Datos] CD
			JOIN [Flotillas].[dbo].[Contribuciones_TipoPago] CTP ON CTP.TipPIdTipoPago = CD.CConIdTipoPago
			JOIN [Flotillas].[dbo].[Contribuciones_Datos_Archivos] CDA ON CDA.CDArchIdContribucion = CD.CConIdContribucion
		WHERE CD.CConTipo IS NULL AND CD.CConVIN = @vin AND CD.CConIdTipoPago = 4
		ORDER BY CDA.CDArchValor DESC) polizaSeguros            
/*
	DECLARE @vin NVARCHAR(100) = (select vin from Unidades where numeroEconomico=@numeroEconomico AND idOperacion=@idOperacion)
	DECLARE @server NVARCHAR(200) = 'http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'

		SELECT * FROM(SELECT TOP 1 LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, @server+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT UP.valor FROM [192.168.20.3].[Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite, '0' Estructura
		FROM [192.168.20.3].[Flotillas].[dbo].[ListaDocumentos] LD
			JOIN [192.168.20.3].[Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento
		WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin AND LD.idDocumento in(23) 
		ORDER BY LD.consecutivo DESC) AS polizaSeguros
	UNION
		SELECT * FROM(SELECT TOP 1 LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, @server+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT UP.valor FROM [192.168.20.3].[Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite, '0' Estructura
		FROM [192.168.20.3].[Flotillas].[dbo].[ListaDocumentos] LD
			JOIN [192.168.20.3].[Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento
		WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin AND LD.idDocumento in(22)
		ORDER BY LD.consecutivo DESC) AS pagoVerificacion
	UNION
		SELECT * FROM(SELECT TOP 1 LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, @server+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT UP.valor FROM [192.168.20.3].[Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite, '0' Estructura
		FROM [192.168.20.3].[Flotillas].[dbo].[ListaDocumentos] LD
			JOIN [192.168.20.3].[Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento
		WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin AND LD.idDocumento in(31)
		ORDER BY LD.consecutivo DESC) AS tenencia
	UNION
		SELECT * FROM(SELECT TOP 1 LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, @server+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT UP.valor FROM [192.168.20.3].[Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite, '0' Estructura
		FROM [192.168.20.3].[Flotillas].[dbo].[ListaDocumentos] LD
			JOIN [192.168.20.3].[Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento
		WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin AND LD.idDocumento in(36)
		ORDER BY LD.consecutivo DESC) AS verificacion
	UNION 
		SELECT * FROM(SELECT TOP 1 CD.CConVIN AS vin, CASE WHEN CConIdTipoPago=1 THEN 31 WHEN CConIdTipoPago=2 THEN 22 WHEN CConIdTipoPago=4 THEN 23 ELSE CConIdContribucion END AS idDocumento, CD.CConUrlArchivo  AS valor, CDArchConsecutivo AS consecutivo, CTP.TipPConcepto AS nombre, CTP.TipPAlias AS descripcion, REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS tipo, @server +CD.CConVIN+'/'+CONVERT(NVARCHAR(100),CD.CConIdContribucion)+ISNULL('_'+CONVERT(NVARCHAR(100),CDArchConsecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS ruta, CD.CConFechaVigencia AS FechaLimite, '1' Estructura
		FROM [192.168.20.71].[Flotillas].[dbo].[Contribuciones_Datos] CD
			JOIN [192.168.20.71].[Flotillas].[dbo].[Contribuciones_TipoPago] CTP ON CTP.TipPIdTipoPago = CD.CConIdTipoPago
			JOIN [192.168.20.71].[Flotillas].[dbo].[Contribuciones_Datos_Archivos] CDA ON CDA.CDArchIdContribucion = CD.CConIdContribucion
		WHERE CD.CConTipo IS NULL AND CD.CConVIN = @vin AND CD.CConIdTipoPago = 1
		ORDER BY CDA.CDArchValor DESC) tenencia
	UNION 
		SELECT * FROM(SELECT TOP 1 CD.CConVIN AS vin, CASE WHEN CConIdTipoPago=1 THEN 31 WHEN CConIdTipoPago=2 THEN 22 WHEN CConIdTipoPago=4 THEN 23 ELSE CConIdContribucion END AS idDocumento, CD.CConUrlArchivo  AS valor, CDArchConsecutivo AS consecutivo, CTP.TipPConcepto AS nombre, CTP.TipPAlias AS descripcion, REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS tipo, @server +CD.CConVIN+'/'+CONVERT(NVARCHAR(100),CD.CConIdContribucion)+ISNULL('_'+CONVERT(NVARCHAR(100),CDArchConsecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS ruta, CD.CConFechaVigencia AS FechaLimite, '1' Estructura
		FROM [192.168.20.71].[Flotillas].[dbo].[Contribuciones_Datos] CD
			JOIN [192.168.20.71].[Flotillas].[dbo].[Contribuciones_TipoPago] CTP ON CTP.TipPIdTipoPago = CD.CConIdTipoPago
			JOIN [192.168.20.71].[Flotillas].[dbo].[Contribuciones_Datos_Archivos] CDA ON CDA.CDArchIdContribucion = CD.CConIdContribucion
		WHERE CD.CConTipo IS NULL AND CD.CConVIN = @vin AND CD.CConIdTipoPago = 2
		ORDER BY CDA.CDArchValor DESC) pagoVerificacion
	UNION 
		SELECT * FROM(SELECT TOP 1 CD.CConVIN AS vin, CASE WHEN CConIdTipoPago=1 THEN 31 WHEN CConIdTipoPago=2 THEN 22 WHEN CConIdTipoPago=4 THEN 23 ELSE CConIdContribucion END AS idDocumento, CD.CConUrlArchivo  AS valor, CDArchConsecutivo AS consecutivo, CTP.TipPConcepto AS nombre, CTP.TipPAlias AS descripcion, REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS tipo, @server +CD.CConVIN+'/'+CONVERT(NVARCHAR(100),CD.CConIdContribucion)+ISNULL('_'+CONVERT(NVARCHAR(100),CDArchConsecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS ruta, CD.CConFechaVigencia AS FechaLimite, '1' Estructura
		FROM [192.168.20.71].[Flotillas].[dbo].[Contribuciones_Datos] CD
			JOIN [192.168.20.71].[Flotillas].[dbo].[Contribuciones_TipoPago] CTP ON CTP.TipPIdTipoPago = CD.CConIdTipoPago
			JOIN [192.168.20.71].[Flotillas].[dbo].[Contribuciones_Datos_Archivos] CDA ON CDA.CDArchIdContribucion = CD.CConIdContribucion
		WHERE CD.CConTipo IS NULL AND CD.CConVIN = @vin AND CD.CConIdTipoPago = 4
		ORDER BY CDA.CDArchValor DESC) polizaSeguros
*/

/*	DECLARE @vin NVARCHAR(100) = (select vin from Unidades where numeroEconomico=@numeroEconomico AND idOperacion=@idOperacion)
	DECLARE @idUnidad NVARCHAR(100) = (select idUnidad from Unidades where numeroEconomico=@numeroEconomico AND idOperacion=@idOperacion)

  declare @placas varchar(max)='';-- 13
  declare @tarjetaDeCirculacion varchar(max)='';-- 19
  declare @PólizaDeSeguros varchar(max)='';--23
  declare @PagoVerificación varchar(max)='';-- 22
  declare @Tenencia varchar(max)='';--31
  declare @Verificación varchar(max)='';--36
  --declare @vin varchar(max)='';
  declare @extencion varchar(max)='';
  declare @fechaVigenciaPólizaSeguro varchar(max)='';
  declare @fechaVigenciaTenencia varchar(max)='';
  declare @fechaVerificación varchar(max)='';


  --set @vin=(select vin from Unidades where idUnidad=@idUnidad)

  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=13)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,13)
     set @placas='http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'+@vin+'/'+@extencion;
  END
  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=19)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,19)
     set @tarjetaDeCirculacion='http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'+@vin+'/'+@extencion;
  END
  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=23)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,23)
     set @PólizaDeSeguros='http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'+@vin+'/'+@extencion;   
  END
  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=22)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,22)
     set @PagoVerificación='http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'+@vin+'/'+@extencion;
  END
  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=31)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,31)
     set @Tenencia='http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'+@vin+'/'+@extencion;
  END
  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=36)
  BEGIN
     select @extencion=[dbo].[extencionArchivo](@idUnidad,36)
     set @Verificación='http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'+@vin+'/'+@extencion;
  END
  /*fechaVigenciaPólizaSeguro*/
  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=48)
  BEGIN
      
	  IF not EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=48 and valor like '%GMT%')
      BEGIN
	      set @fechaVigenciaPólizaSeguro=(select convert(date,valor,103) from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=48);
      END
	  ELSE
	  BEGIN
	      set @fechaVigenciaPólizaSeguro=(select convert(date, SUBSTRING(valor,12,4)+case SUBSTRING(valor,5,3) when 'jan' then '01'
                                 when 'feb' then '02'
								 when 'mar' then '03'
								 when 'apr' then '04'
								 when 'may' then '05'
								 when 'jun' then '06'
								 when 'jul' then '07'
								 when 'aug' then '08'
								 when 'sep' then '09'
								 when 'oct' then '10'
								 when 'nov' then '11'
								 else '12'
                                 end+SUBSTRING(valor,9,2)
								 ,103
								)
          from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin  where u.idUnidad=@idUnidad and idDocumento=48)
	  END
  END
  /*fechaVerificación*/
  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=50)
  BEGIN
     
	 IF not EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=50 and valor like '%GMT%')
	 BEGIN
	 set @fechaVerificación=(select convert(date, valor,103) from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=50);
     END
	 ELSE
	 BEGIN 
	      set @fechaVerificación=(select convert(date, SUBSTRING(valor,12,4)+case SUBSTRING(valor,5,3) when 'jan' then '01'
                                 when 'feb' then '02'
								 when 'mar' then '03'
								 when 'apr' then '04'
								 when 'may' then '05'
								 when 'jun' then '06'
								 when 'juñ' then '07'
								 when 'aug' then '08'
								 when 'sep' then '09'
								 when 'oct' then '10'
								 when 'nov' then '11'
								 else '12'
                                 end+SUBSTRING(valor,9,2)

								 ,103)
          from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin  where u.idUnidad=@idUnidad and idDocumento=50)
	 END
  END
  /*fechaVigenciaTenencia*/
  IF EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=49)
  BEGIN

     IF not EXISTS (select idDocumento from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=49 and valor like '%GMT%')
	 BEGIN
	 set @fechaVigenciaTenencia=(select convert(date,valor,103) from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin where u.idUnidad=@idUnidad and idDocumento=49);
     END
	 ELSE

	 BEGIN
	      set @fechaVigenciaTenencia=(select convert(date, SUBSTRING(valor,12,4)+case SUBSTRING(valor,5,3) when 'jan' then '01'
                                 when 'feb' then '02'
								 when 'mar' then '03'
								 when 'apr' then '04'
								 when 'may' then '05'
								 when 'jun' then '06'
								 when 'juñ' then '07'
								 when 'aug' then '08'
								 when 'sep' then '09'
								 when 'oct' then '10'
								 when 'nov' then '11'
								 else '12'
                                 end+SUBSTRING(valor,9,2)

								 ,103)
          from FlotillasMIAUTO..UnidadPropiedad fup join Unidades u on u.vin=fup.vin  where u.idUnidad=@idUnidad and idDocumento=49)

	 END
  END
  
  Declare @fechaVigenciaPólizaSeguroVencida int=0;
  Declare @fechaVerificaciónVencida int=0;
  Declare @fechaVigenciaTenenciaVencida int=0;
  
  if(cast(@fechaVigenciaPólizaSeguro as date)>=getdate()) set @fechaVigenciaPólizaSeguroVencida=1;
  if(cast(@fechaVerificación as date)>=getdate()) set @fechaVerificaciónVencida=1;
  if(cast(@fechaVigenciaTenencia as date)>=getdate()) set @fechaVigenciaTenenciaVencida=1;

  select @placas as placas,
         @tarjetaDeCirculacion as tarjetaDeCirculacion,
		 @PólizaDeSeguros as PolizaDeSeguros,
		 @PagoVerificación as PagoVerificacion,
		 @Tenencia as Tenencia,
		 @Verificación as Verificacion,
		 /*fecha Vigencia Póliza Seguro*/
		 @fechaVigenciaPólizaSeguro as fechaVigenciaPolizaSeguro,
		 @fechaVigenciaPólizaSeguroVencida as fechaVigenciaPolizaSeguroVencida,
		 /*fecha Verificación*/
		 @fechaVerificación as fechaVerificacion,
		 @fechaVerificaciónVencida as fechaVerificacionVencida,
		 /*fecha Vigencia Tenencia*/
		 @fechaVigenciaTenencia as fechaVigenciaTenencia,
		 @fechaVigenciaTenenciaVencida as fechaVigenciaTenenciaVencida,
		 case when @placas = '' OR  @tarjetaDeCirculacion = '' OR @PólizaDeSeguros = '' OR  @PagoVerificación = '' OR @Tenencia = '' OR  @Verificación = ''  THEN '0' ELSE '1' END AS BanderaDoc
*/
	/*
	SELECT LD.vin, LD.idDocumento, LD.valor, ISNULL(CONVERT(NVARCHAR(100),LD.consecutivo),'1') AS consecutivo, C.nombre, C.descripcion, REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS tipo, 'http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/'+LD.vin+'/'+CONVERT(NVARCHAR(100),LD.idDocumento)+ISNULL('_'+CONVERT(NVARCHAR(100),LD.consecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(LD.valor), CHARINDEX('.', REVERSE(LD.valor))-1 )) AS ruta, (SELECT UP.valor FROM [Flotillas].[dbo].[UnidadPropiedad] UP JOIN [Flotillas].[dbo].[CatalogoDocumentoFecha] CDF ON CDF.idUnidadPropiedad = UP.idDocumento WHERE UP.VIN = LD.VIN AND CDF.idListaDocumentos = LD.idDocumento) AS FechaLimite
	FROM [Flotillas].[dbo].[ListaDocumentos] LD
	JOIN [Flotillas].[dbo].[Catalogo] C ON C.valor = LD.idDocumento
	WHERE LD.valor LIKE '%.%' AND LD.VIN = @vin --AND LD.idDocumento in(23,22,31,36)
	*/
	/*
	SELECT CD.CConVIN AS vin, CASE WHEN CConIdTipoPago=1 THEN 31 WHEN CConIdTipoPago=2 THEN 22 WHEN CConIdTipoPago=4 THEN 23 ELSE CConIdContribucion END AS idDocumento, CD.CConUrlArchivo  AS valor, CDArchConsecutivo AS consecutivo, CTP.TipPConcepto AS nombre, CTP.TipPAlias AS descripcion, REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS tipo, 'http://189.204.141.193/FlotillaCartaFacturaApi/Documentos/' +CD.CConVIN+'/'+CONVERT(NVARCHAR(100),CD.CConIdContribucion)+ISNULL('_'+CONVERT(NVARCHAR(100),CDArchConsecutivo),'')+ '.' +REVERSE(LEFT(REVERSE(CDA.CDArchValor), CHARINDEX('.', REVERSE(CDA.CDArchValor))-1 )) AS ruta, CD.CConFechaVigencia AS FechaLimite, '1' Estructura
		FROM [192.168.20.71].[Flotillas].[dbo].[Contribuciones_Datos] CD
			JOIN [192.168.20.71].[Flotillas].[dbo].[Contribuciones_TipoPago] CTP ON CTP.TipPIdTipoPago = CD.CConIdTipoPago
			JOIN [192.168.20.71].[Flotillas].[dbo].[Contribuciones_Datos_Archivos] CDA ON CDA.CDArchIdContribucion = CD.CConIdContribucion
		WHERE CD.CConTipo IS NULL AND CD.CConVIN = '3G1TB5CF2HL128221'
		ORDER BY CDA.CDArchValor DESC
	*/
END
go

