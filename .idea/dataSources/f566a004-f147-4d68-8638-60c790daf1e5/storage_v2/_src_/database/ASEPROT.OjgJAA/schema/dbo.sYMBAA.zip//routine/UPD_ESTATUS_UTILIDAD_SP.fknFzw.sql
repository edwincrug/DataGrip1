create PROCEDURE [dbo].[UPD_ESTATUS_UTILIDAD_SP]
@idOrden VARCHAR(50)

AS
BEGIN

	UPDATE [dbo].[AprobacionesUtilidad]
	SET estatusAprobacion = 2
	WHERE idOrden = @idOrden

	SELECT 1

END

go

