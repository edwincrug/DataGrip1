-- =============================================
-- Description:	Busca todas las acciones relacionadas a la orden
-- NOTA: 
-- [SEL_DETALLE_ORDEN_ACCIONES_SP] @numeroOrden ='100010'
-- =============================================

CREATE PROCEDURE [dbo].[SEL_DETALLE_ORDEN_ACCIONES_SP]
@idUsuario INT = 0,
@numeroOrden varchar(50) = ''
AS
BEGIN
	SELECT * 
	FROM Acciones Acc
	INNER JOIN Ordenes Ord ON Acc.idOrden = Ord.idOrden
	INNER JOIN Recordatorios Recor ON Recor.idAccion = Acc.idAccion
	WHERE Ord.numeroOrden = @numeroOrden

END

go

