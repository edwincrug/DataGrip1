-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03 11 2017
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ORDEN_DESCONTADA_OSUR_SP]
	@idOrden numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (SELECT 1 FROM PresupuestoOrden WHERE idOrden = @idOrden)
		BEGIN
			SELECT 1 as descontado
		END
	ELSE
		BEGIN
			SELECT 0 as descontado
		END

END
go

