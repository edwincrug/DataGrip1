-- =============================================
-- Description:	Obtiene las ordenes de servicio en proceso es decir que no esten canceladas o finalizadas
-- =============================================
-- [SEL_ORDENES_ACTUAL_SP] @idUsuario = 509, @economico = '10182', @idContratoOperacion=3
-- [SEL_ORDENES_ACTUAL_SP] @idUsuario = 2, @economico = '1632012972999'
-- [SEL_ORDENES_ACTUAL_SP] @idUsuario = 538, @economico = 10937, @idContratoOperacion = 3
CREATE PROCEDURE [dbo].[SEL_ORDENES_ACTUAL_SP] 
	@idUsuario NUMERIC(18,0),
	@economico NVARCHAR(50),
	@idContratoOperacion INT = 0
AS
BEGIN
	--Obtendo el id de la Unidad
	DECLARE @idUnidad INT
	SELECT @idUnidad=idUnidad 
	FROM Unidades U 
	inner join ContratoOperacion co on co.idOperacion = u.idOperacion
	WHERE numeroEconomico = @economico and co.idContratoOperacion = @idContratoOperacion

	-----------------------------------------------------------------------------------
	--Verifico si la unidad tiene Ordenes de serevicio en proceso  
	-- respuesta = 0 <-- No tiene Ordenses de servicio en proceso 
	-- respuesta = 1 <-- Tiene Ordenes de Servicio en Proceso 
	-----------------------------------------------------------------------------------

	DECLARE @idCatalogoRol INT 
	DECLARE @idOperacion INT
	DECLARE @query  NVARCHAR(MAX) = ''
	DECLARE @usuario NVARCHAR(MAX) = '' 
	DECLARE @join NVARCHAR(MAX) = ''
	DECLARE @queryText VARCHAR(MAX)
	DECLARE @idContratoOperacionUsuario INT

	SELECT @idCatalogoRol=COU.idCatalogoRol , @idOperacion = CO.idOperacion,@idContratoOperacionUsuario=COU.idContratoOperacionUsuario
		FROM [dbo].[ContratoOperacionUsuario] COU
		JOIN [dbo].[CatalogoRoles] CR ON CR.idCatalogoRol = COU.idCatalogoRol
		JOIN [dbo].[ContratoOperacion] CO ON CO.idContratoOperacion = COU.idContratoOperacion 
	WHERE idUsuario = @idUsuario and CO.idContratoOperacion = @idContratoOperacion

	   IF(@idCatalogoRol <> 2)
		BEGIN
		    IF(@idCatalogoRol <> 4)
				BEGIN
				    --SET @join = ' '
					SET @join =' JOIN [ContratoOperacionUsuario] COU ON COU.idContratoOperacion = ConOpe.idContratoOperacion 
								 JOIN [ContratoOperacionUsuarioZona] COUZ ON COUZ.idContratoOperacionusuario = COU.idContratoOperacionusuario '

					SET @usuario = ' AND COU.idUsuario = '+CAST(@idUsuario AS NVARCHAR(30))+' AND COU.idContratoOperacion  = ' + CONVERT(NVARCHAR(100),@idContratoOperacion) +' AND COUZ.idZona = O.idZona and o.idOrden not in(select idOrden from Cotizaciones where idTaller=689)'
					--SET @usuario = ' AND COU.idZona IN(SELECT idZona FROM [ContratoOperacionUsuarioZona] WHERE COU.idContratoOperacionusuario = idContratoOperacionusuario) AND COU.idUsuario = '+CAST(@idUsuario AS NVARCHAR(30))+' AND COU.idContratoOperacion  = ' + CONVERT(NVARCHAR(100),@idContratoOperacion) +' '

					IF @idCatalogoRol = 9
					BEGIN
					SET @join =' JOIN [ContratoOperacionUsuario] COU ON COU.idContratoOperacion = ConOpe.idContratoOperacion 
									JOIN [ContratoOperacionUsuarioGerente] COUG 
										JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias AND EG.estatus=0
										JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado AND EZ.estatus=0 
									ON COUG.idContratoOperacionusuario = COU.idContratoOperacionusuario  '

				   SET @usuario = ' AND COU.idUsuario = '+CAST(@idUsuario AS NVARCHAR(30))+' AND COU.idContratoOperacion  = ' + CONVERT(NVARCHAR(100),@idContratoOperacion) +' AND EZ.idZona = O.idZona '
				   END
				END
			ELSE
				BEGIN
					--SET @join = ' JOIN ContratoOperacionUsuario COU ON COU.idContratoOperacion = ConOpe.idContratoOperacion JOIN ContratoOperacionUsuarioProveedor COUP ON COUP.idContratoOperacionUsuario = COU.idContratoOperacionUsuario '
					SET @usuario = ' AND (((SELECT CASE WHEN exists (select 1 from Cotizaciones C where C.idOrden = O.idOrden and C.idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idOperacion)+'))) THEN 1 ELSE 0 END ) = 1) or (O.idUsuario = '+CONVERT(varchar(max),@idUsuario)+') )'
				END
		END
		
	IF(EXISTS(SELECT 1 FROM [dbo].[Ordenes] WHERE idUnidad = @idUnidad AND NOT idEstatusOrden IN (12,13)))
		BEGIN 
		SET @queryText = 
			'SELECT DISTINCT
				   O.idOrden AS idOrden,
				   fechaCreacionOden AS fechaCreacionOrden,
				   fechaCita AS FechaCita,
				   numeroOrden AS numeroOrden,
				   comentarioOrden AS descripcion,
				   idCatalogoEstadoUnidad AS idEstadoUnidad,
				   O.idUsuario AS idUsuario,
				   U.nombreCompleto AS nombreCompleto,
				   O.idCatalogoTipoOrdenServicio AS idTipoOrden,
				   CTO.nombreTipoOrdenServicio AS tipoOrden,
				  (CASE WHEN (O.idEstatusOrden = 5) AND ((CASE WHEN '+convert(varchar(max),@idCatalogoRol)+' = 4 
																THEN (SELECT CASE WHEN exists (select 1 from Cotizaciones C where C.idOrden = O.idOrden and C.idEstatusCotizacion in (1,2) and C.idTaller in (select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN]('+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idOperacion)+'))) THEN 1 ELSE 0 END )
																ELSE  (SELECT CASE WHEN exists (select 1 from Cotizaciones C where C.idOrden = O.idOrden and C.idEstatusCotizacion in (1,2)) THEN 1 ELSE 0 END ) END) = 1) THEN 4 ELSE O.idEstatusOrden END) idEstatusOrden,
				  (CASE WHEN O.idEstatusOrden = 1 THEN ''Sin Taller'' WHEN O.idEstatusOrden = 2 THEN ''Con Taller'' ELSE EO.nombreEstatusOrden END) AS estatusOrden,
				  1 AS respuesta,
				  [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, ' + CONVERT(NVARCHAR(100),@idContratoOperacion) +', 3, '+CAST(@idUsuario AS NVARCHAR(30))+', '+convert(varchar(max),@idCatalogoRol)+') costo,
				  [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, ' + CONVERT(NVARCHAR(100),@idContratoOperacion) +', 3, '+CAST(@idUsuario AS NVARCHAR(30))+', '+convert(varchar(max),@idCatalogoRol)+') precio,
				  --nombreComercial AS nombreTaller,
				  --razonSocial AS razonSocial,
				  --P.idProveedor,
				  --P.direccion AS direccion,
				  HEO.fechaInicial AS ultimaModificacion
			 FROM [dbo].[Ordenes] O
				  INNER JOIN [dbo].[EstatusOrdenes] AS EO ON O.idEstatusOrden = EO.idEstatusOrden
				  INNER JOIN [dbo].[Usuarios] AS U ON U.idUsuario = O.idUsuario
				  INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = O.idContratoOperacion
				  ' + @join + '
				  LEFT JOIN [dbo].[CatalogoTiposOrdenServicio] CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
				  LEFT JOIN [dbo].[Cotizaciones] C ON C.idOrden = O.idOrden
				  LEFT JOIN [dbo].[CotizacionDetalle] CD ON CD.idCotizacion = C.idCotizacion
				  --LEFT JOIN [Partidas].[dbo].[Proveedor] P ON P.idProveedor = O.idTaller
				  INNER JOIN [dbo].[HistorialEstatusOrden] HEO ON HEO.idOrden = O.idOrden AND HEO.idEstatusOrden = O.idEstatusOrden AND fechaFinal IS NULL
			WHERE idUnidad = ' +  CONVERT(NVARCHAR(100),@idUnidad) + ' AND NOT O.idEstatusOrden IN (12,13)  AND ConOpe.idContratoOperacion = ' + CONVERT(NVARCHAR(100),@idContratoOperacion)
			/*GROUP BY O.[idOrden], [fechaCreacionOden], [fechaCita], [numeroOrden], [comentarioOrden], [idCatalogoEstadoUnidad]
					,O.[idUsuario], U.nombreCompleto, O.idCatalogoTipoOrdenServicio, CTO.nombreTipoOrdenServicio, O.[idEstatusOrden], nombreEstatusOrden
					,nombreComercial, razonSocial, P.direccion, HEO.fechaInicial*/
			SET @query = @queryText + @usuario
			EXECUTE SP_EXECUTESQL @query
			print @query
		END
	ELSE 
		BEGIN
		--Poner aqui mensaje en caso de que no haya ordenes
			SELECT 0 AS respuesta, '' AS mensaje	   
		END
END
go

