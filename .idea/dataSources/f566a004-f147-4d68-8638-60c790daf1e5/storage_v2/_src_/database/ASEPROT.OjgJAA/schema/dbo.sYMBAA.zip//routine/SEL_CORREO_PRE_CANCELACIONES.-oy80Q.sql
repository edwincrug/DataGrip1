CREATE PROCEDURE [dbo].[SEL_CORREO_PRE_CANCELACIONES]
	@tipoConsulta int,
	@idOrden numeric(18,0),
	@idUsuario numeric(18,0)
AS
BEGIN
	DECLARE @html NVARCHAR(max)=''
	DECLARE @texto nvarchar(500)
	DECLARE @numeroOrden NVARCHAR(500)
	SELECT @numeroOrden= numeroOrden FROM Ordenes where idOrden= @idOrden
	DECLARE @nombreCompleto NVARCHAR(max)
	SELECT @nombreCompleto= nombreCompleto from Usuarios where  idUsuario= @idUsuario
	IF @tipoConsulta=1
		BEGIN
	SET @texto= 'Pre-cancelación'
		END
		ELSE
		BEGIN 
		SET @texto = 'Cancelacion'
		END
	SET @html='
	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
	<body>
		<div style="font-family: Arial;">
			<div style="font-size: 16px;color: #0489B1;margin-left: 10px; text-align: center;">
					<h3>Notificación de '+ @texto+' de la orden '+ @numeroOrden +' </h3>
				</div>
				<div style="font-family: sans-serif;font-size: 14px;color: #2F4F4F;margin-left: 50px;">
			
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Acción: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ @texto +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px;margin-top: 10px;">
					Por el Usuario: <span  style="font-size: 14px;color: #000000;">'+ @nombreCompleto +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Número de  Orden: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ @numeroOrden +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Fecha Proceso: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ CONVERT(VARCHAR(24),GETDATE(), 120 ) +'</span>
				</div>
		</div>
	</body>
	</html> '


	
	
	DECLARE @correosTabla TABLE(id INT IDENTITY(1,1), correo VARCHAR(500))

	DECLARE @aux INT = 1, @max DECIMAL (18,0) = 0		
	DECLARE @correos VARCHAR(MAX) = ''

	DECLARE @idContratoOperacion INT
	SELECT @idContratoOperacion=idContratoOperacion FROM Ordenes WHERE idOrden=@idOrden

	IF @idContratoOperacion<>32
	BEGIN
	INSERT INTO @correosTabla 
	SELECT correoElectronico from Usuarios where idUsuario IN(
	SELECT DISTINCT idUsuario FROM HistorialEstatusOrden WHERE idOrden= @idOrden)
	END
	ELSE
	BEGIN
	INSERT INTO @correosTabla
	SELECT correoElectronico FROM Usuarios WHERE idUsuario IN(1122,1123,1124,1434) /*CONFIG PARA ATLAS COPCO*/
	END		
		
	INSERT INTO @correosTabla	
	SELECT correoElectronico from Usuarios where idUsuario = @idUsuario

		SELECT @max = MAX(id), @aux = MIN(id) FROM @correosTabla

		WHILE(@aux <= @max)
		BEGIN 
			SELECT @correos = @correos + ',<' + correo + '>' FROM @correosTabla
			WHERE id = @aux
		
			SET @aux = @aux + 1
		END

	SET @correos = SUBSTRING(@correos,2,LEN(@correos))

	SELECT 'noreply@centraldeoperaciones.com' correoDe, @correos correoPara, 
		   @html bodyhtml
END
--GO
--BEGIN TRAN

--EXEC [dbo].[SEL_CORREO_PRE_CANCELACIONES] 1,69653,988
--EXEC [dbo].[SEL_CORREO_PRE_CANCELACIONES] 1,70221,988

--ROLLBACK TRAN
go

