-- =============================================
-- Create date: 15/06/2017
-- Description:	
-- [SEL_APROBACION_DE_UTILIDAD_SP] 
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_APROBACION_DE_UTILIDAD_SP]
	
AS
BEGIN
	
	SELECT 
		AU.margenAprobacion,
		AU.fechaAprobacion,
		O.idOrden,
		O.numeroOrden,
		O.ComentarioOrden,
		O.idEstatusOrden,
		EO.nombreEstatusOrden,
		U.numeroEconomico,
		(SELECT SUM((ISNULL(CPVenta.venta,0) * ISNULL(CD.cantidad,0))) FROM Cotizaciones C JOIN Ordenes ORD ON ORD.idOrden = C.idOrden JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON CPVenta.idPartida = CD.idPartida WHERE ORD.idOrden = O.idOrden AND CD.idEstatusPartida in (1,2)) AS PrecioCliente,
		(SELECT SUM((ISNULL(PPCosto.costo,0) * ISNULL(CD.cantidad,0))) FROM Cotizaciones C JOIN Ordenes ORD ON ORD.idOrden = C.idOrden JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion JOIN [Partidas].[dbo].[ProveedorPartida] PPCosto ON PPCosto.idPartida = CD.idPartida WHERE ORD.idOrden = O.idOrden AND CD.idEstatusPartida in (1,2)) AS PrecioTaller,
		PR.nombreComercial,
		(SELECT
			SUM((ISNULL(CPVenta.venta,0) * ISNULL(CD.cantidad,0)))-SUM((ISNULL(PPCosto.costo,0) * ISNULL(CD.cantidad,0)))
		FROM Ordenes ORD 
		JOIN Cotizaciones C ON C.idOrden = ORD.idOrden 
		JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
		JOIN [Partidas].[dbo].[ProveedorPartida] PPCosto ON PPCosto.idPartida = CD.idPartida 
		JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON CPVenta.idPartida = CD.idPartida
		WHERE ORD.idOrden = O.idOrden AND CD.idEstatusPartida in (1,2)) utilidad--,
		/*(SELECT
			((((ISNULL(CPVenta.venta,0) * ISNULL(CD.cantidad,0))-(ISNULL(PPCosto.costo,0) * ISNULL(CD.cantidad,0)))* 100)/(ISNULL(CPVenta.venta,0) * ISNULL(CD.cantidad,0)))
		FROM Ordenes ORD 
		JOIN Cotizaciones C ON C.idOrden = ORD.idOrden 
		JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
		JOIN [Partidas].[dbo].[ProveedorPartida] PPCosto ON PPCosto.idPartida = CD.idPartida 
		JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON CPVenta.idPartida = CD.idPartida
		WHERE ORD.idOrden = O.idOrden AND CD.idEstatusPartida in (1,2)) margen*/
		--((CD.venta * CD.cantidad)-(CD.costo * CD.cantidad)) utilidad--,
		--((((CD.venta * CD.cantidad)-(CD.costo * CD.cantidad))* 100)/(CD.venta * CD.cantidad)) margen
	FROM AprobacionesUtilidad AU
	JOIN Ordenes O ON O.idOrden = AU.idOrden
	JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
	JOIN unidades U ON U.idUnidad = O.idUnidad
	LEFT JOIN [Partidas].[dbo].[Proveedor] PR ON PR.idProveedor = O.idTaller
	WHERE AU.estatusAprobacion = 1 AND EO.idEstatusOrden <> 10
	--JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
	--JOIN Operaciones OS ON OS.idOperacion = CO.idOperacion
	--JOIN Cotizaciones C ON C.idOrden = O.idOrden
	--JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	--JOIN [Partidas].[dbo].[ProveedorPartida] PPCosto ON PPCosto.idPartida = CD.idPartida
	--JOIN [Partidas].[dbo].[ContratoPartida] CPVenta ON CPVenta.idPartida = CD.idPartida
	--JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
END
go

