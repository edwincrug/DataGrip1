-- =============================================
-- Author:		Sahirely Yam
-- Create date: 21 08 2017
-- SELECT [dbo].[SEL_TALLERES_ORDEN_FN](432)
-- =============================================
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_TALLERES_ORDEN_FN](@idOrden INT)

RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @talleres NVARCHAR(MAX) = ' ';
	DECLARE @nombreComercial NVARCHAR(MAX) = ' ';
	DECLARE @Result NVARCHAR(MAX) = ' ';

	DECLARE contact_cursor CURSOR FOR
	select distinct nombreComercial 
	from Cotizaciones C
	inner join Partidas..Proveedor P on P.idProveedor = C.idTaller and c.idestatuscotizacion not in(4,5)
	where idOrden = @idOrden

	OPEN contact_cursor  
	FETCH NEXT FROM contact_cursor INTO @talleres
	WHILE @@FETCH_STATUS = 0  
		BEGIN 

		--SET @talleres =(SELECT idTaller FROM Taller where idTaller=@idTaller)
		SET @nombreComercial = @nombreComercial + @talleres + ' - '

		FETCH NEXT FROM contact_cursor INTO @talleres
		END  
	CLOSE contact_cursor  
	DEALLOCATE contact_cursor

	IF((@nombreComercial IS NOT NULL) AND @nombreComercial != '')
		SET @Result= SUBSTRING (@nombreComercial, 1, Len(@nombreComercial) - 1 )

	RETURN @Result;
	
END
go

