

/*
	Fecha			Autor			Descripción
	21-May-2018		José Etmanuel	Se crea el SP que devuelve los datos de una unidad
	22-May-2018		José Etmanuel	Agrego Póliza y descripcion
	23-May-2018		José Etmanuel	Agrego marca

	*---  Pruebas
	[Banorte].[GET_UNIDADES_X_UNI] 5350
*/

CREATE proc [Banorte].[GET_UNIDADES_X_UNI]
@idUnidad int=0
as
begin


	declare @vin varchar(max) = (select top 1 vin from Unidades as uni inner join [dbo].[usuarioUnidadContratoOperacion] as rel on rel.[idUnidad] = uni.[idUnidad] where rel.idUnidad = @idUnidad)
	create table #marca ( id int, vin3 varchar(3),marca varchar(max), idmarca int, pais varchar(max), modelyear varchar(4), Modelo varchar(max))
	insert into #marca 
		EXEC [RefaccionMultiMarca].[Catalogo].[SEL_MarcaVin_SP] @vin 

	Declare @idOrden int,
			@noOrden varchar(max);

	select top 1 @idOrden = idOrden, @noOrden =numeroOrden from Ordenes o where idUnidad=@idUnidad and idEstatusOrden<>13 and not exists (select *from calificacionTaller where idOrden=o.idOrden) order by fechaCreacionOden desc;

	select 
		uni.[idUnidad]
      ,[numeroEconomico]
      ,[vin]
      ,[gps]
      ,[idTipoUnidad]
      ,[idOperacion]
      ,[placas]
      ,[idZona]
      ,[modelo]
      ,[combustible]
      ,uni.[idUsuario]
      ,[fecha]
      ,[Kilometraje_Actual]
	  ,[noPoliza]
	  ,[descripcion]
	  ,@idOrden as idOrden
	  ,@noOrden as noOrden
	  ,(select top 1 marca from #marca) as marca
	 from Unidades as uni
	inner join [dbo].[usuarioUnidadContratoOperacion] as rel on rel.[idUnidad] = uni.[idUnidad]
	where rel.idUnidad = @idUnidad

	

print @idOrden;

 SELECT case  e.[idEstatusOrden] when 1 then 1
		                                   when 2 then 2
										   when 3 then 3
										   when 4 then 3
										   when 5 then 3
										   when 6 then 4
										   else 5 end as idEstatus
				, [fechaInicial] 
	
  FROM [HistorialEstatusOrden] h
  inner join [EstatusOrdenes] as e on e.[idEstatusOrden] = h.[idEstatusOrden]
  where h.idOrden = @idOrden

  create table #talleres (
	idProveedor int,nombreComercial varchar(max),idTaller int, razonSocial varchar(max), RFC varchar(20), direccion varchar(max), latitud  varchar(max), longitud  varchar(max), calificacionTaller float
  )
  insert into #talleres
	SELECT	DISTINCT P.idProveedor AS idProveedor
		,P.nombreComercial
		,P.idProveedor idTaller
		,P.razonSocial
		,P.RFC 
		,P.direccion
		,P.latitud
		,P.longitud
		,isnull(Rank,0) as calificacionTaller
		--,z.nombre
FROM	[dbo].[ContratoOperacion] CO
		INNER JOIN .[Partidas].[dbo].[ContratoProveedor] CPRO ON CPRO.idContrato = CO.idContrato
		INNER JOIN .[Partidas].[dbo].[Proveedor] P ON P.idProveedor = CPRO.idProveedor
		INNER JOIN .[Partidas].[dbo].Unidad U ON U.idUnidad =  (select idTipoUnidad from Unidades where idUnidad=@idUnidad)
        INNER JOIN [Partidas].[dbo].ProveedorTipoCombustible tc on tc.idTipoCombustible = u.idTipoCombustible and tc.idProveedor = P.idProveedor 
		INNER JOIN .[Partidas].[dbo].[ContratoProveedorZona] CPROZ ON CPROZ.idContratoProveedor = CPRO.idContratoProveedor
		INNER JOIN .[Partidas].[dbo].[Zona] Z ON Z.idZona = CPROZ.idZona --and CPROZ.idZona=@idZona
		INNER JOIN .[Partidas].[dbo].[NivelZona] NZ ON Z.idNivelZona = NZ.idNivelZona
		INNER JOIN usuarioUnidadContratoOperacion uucop on uucop.idContratoOperacion=co.idContratoOperacion
		LEFT JOIN rankTaller on P.idProveedor=idTaller 
 where   len(P.latitud)>0 and len(P.longitud)>0
	

  select idProveedor,nombreComercial,t.idTaller,razonSocial,RFC,direccion,latitud,longitud,calificacionTaller from Ordenes  as o 
  inner join #talleres as t on o.idTaller = t.idTaller
  where idUnidad=@idUnidad and idEstatusOrden<>13 and not exists (select *from calificacionTaller where idOrden=o.idOrden) 
  order by fechaCreacionOden desc

  drop table #talleres ;


end
go

grant execute, view definition on Banorte.GET_UNIDADES_X_UNI to DevOps
go

