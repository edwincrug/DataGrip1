-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Test: SEL_REPORTE_OPERACIONES_INTEGRA_2_SP @idContratoOperacion = 84
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORTE_OPERACIONES_INTEGRA_2_SP]
	-- Add the parameters for the stored procedure here
	@idContratoOperacion		numeric(18,0)=NULL,
	@idEstado					numeric(18,0)=NULL,
	@idGerencia					numeric(18,0)=NULL,
	@idSeguro					numeric(18,0)=NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if(@idSeguro is not null)
	begin
		select 
			isnull(agru.ID, 1)					idContrato,
			isnull(agru.Descr, 'Banorte')		descripcion,
			ord.numeroOrden,
			isnull(est.idEstados, 0) idEstados,
			COALESCE(est.nombreEstado, 'SIN ESTADO CONFIGURADO')		'region',
			isnull(ger.idGerencias, 0) idGerencia,
			isnull(ger.nombreGerencia, 'SIN GERENCIA CONFIGURADA') nombreGerencia,
			eso.idEstatusOrden			idEstatusOrden,
			eso.nombreEstatusOrden		estatusOrden,
			heo.fechaFinal,
			heo.fechaInicial,
			DATEDIFF( day, heo.fechaInicial, coalesce( heo.fechaFinal, getdate() ) )		numDias,
			isnull(sum(cd.venta * cd.cantidad),0)				ventaOrden,
			isnull(sum(cd.costo * cd.cantidad),0)				costoOrden,
			isnull(sum(cd.costo * cd.cantidad),0) * 0.16		IVAOrden,
			isnull(sum(cd.costo * cd.cantidad),0) * 1.16		totalOrden,
			case when ( sum(cd.costo * cd.cantidad) = 0 or sum(cd.costo * cd.cantidad) is null ) and ( sum(cd.venta * cd.cantidad) = 0 or sum(cd.venta * cd.cantidad) is null ) then 0
				when sum(cd.costo * cd.cantidad) is null or sum(cd.costo * cd.cantidad) = 0 then 1
				when sum(cd.venta * cd.cantidad) is null or sum(cd.venta * cd.cantidad) = 0 then -1
				else cast( isnull(sum(cd.venta * cd.cantidad),0) / isnull(sum(cd.costo * cd.cantidad),0) - 1 as decimal(18,4))
			end porcentajeUtilidad,
			(select ASEPROT.dbo.SEL_PARTIDAS_ORDEN_FN(ord.idOrden)) descripcionPartida,
			case 
				when opte.tiempoEnEspera is null then 0
				when GETDATE() > DATEADD( hour, convert( int, substring( opte.tiempoEnEspera, 0, 3 ) ), heo.fechaInicial ) 
					then DATEDIFF(DAY, DATEADD(hour, convert(int, substring(opte.tiempoEnEspera, 0, 3 ) ), heo.fechaInicial), getdate())
				else 0
			end     as tiempoDesfasado
		from Partidas.dbo.Contrato con 
			inner join ASEPROT.dbo.ContratoOperacion cop on cop.idContrato = con.idContrato     
			inner join ASEPROT.dbo.Operaciones oper on oper.idOperacion = cop.idOperacion
			inner join ASEPROT.dbo.Ordenes ord on ord.idContratoOperacion = cop.idContratoOperacion  
			left join ASEPROT.dbo.UnidadAgrupador ua on ord.idUnidad = ua.idUnidad
			left join ASEPROT.dbo.Agrupador agru on ua.idAgrupador = agru.Id  
			left join ASEPROT.dbo.CatalogoTiposOrdenServicio ctos on ctos.idCatalogoTipoOrdenServicio = ord.idCatalogoTipoOrdenServicio
			left join ASEPROT.dbo.Cotizaciones coti on coti.idOrden = ord.idOrden and coti.idEstatusCotizacion in(1,2,3) and coti.idTaller =     
				case when ord.idEstatusOrden = 1 then 0    
				else coti.idTaller    
				end
			left join ASEPROT.dbo.CotizacionDetalle cd on cd.idCotizacion = coti.idCotizacion and cd.idEstatusPartida in (1,2)    
			left join ASEPROT.dbo.EstatusOrdenes eso on eso.idEstatusOrden = ord.idEstatusOrden
			left join ASEPROT.Gerente.EstadoZona ez on ez.idZona = ord.idZona and ez.idContratoOperacion = cop.idContratoOperacion
			left join ASEPROT.Gerente.Estados est on est.idEstados = ez.idEstado
			left join ASEPROT.Gerente.EstadoGerencia ege on ege.idEstado = est.idEstados
			left join ASEPROT.Gerente.Gerencias ger on ger.idGerencias = ege.idGerencia
			left join ASEPROT.dbo.HistorialEstatusOrden heo on heo.idEstatusOrden = eso.idEstatusOrden and heo.idOrden = ord.idOrden    
			left join ASEPROT.dbo.OperacionTiempoEnEspera opte on opte.idOperacion = oper.idOperacion and opte.idEstatusOrden = ord.idEstatusOrden
		where ord.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)   
			 and (ctos.Seguro = 1 or ctos.Seguro is null)
			and coalesce(agru.ID, 1) = @idSeguro
		group by con.idContrato, con.descripcion, ord.idOrden, ord.numeroOrden, est.idEstados, est.nombreEstado, ger.idGerencias, ger.nombreGerencia, heo.fechaFinal, heo.fechaInicial, opte.tiempoEnEspera, agru.Id, agru.Descr, eso.idEstatusOrden, eso.nombreEstatusOrden, cop.idContratoOperacion
	end
	else
	begin
	-- Insert statements for procedure here
		select distinct
			con.idContrato,
			case when con.idContrato = 37 then 
				case when ord.idZona = 3548 then con.descripcion + ' Refacciones'
					else con.descripcion + ' Siniestros'
				end
				else con.descripcion
			end descripcion, 
			ord.numeroOrden,
			isnull(est.idEstados, 0) idEstados,
			COALESCE(est.nombreEstado, 'SIN ESTADO CONFIGURADO')		'region',
			isnull(ger.idGerencias, 0) idGerencia,
			isnull(ger.nombreGerencia, 'SIN GERENCIA CONFIGURADA') nombreGerencia,
			eso.idEstatusOrden			idEstatusOrden,
			eso.nombreEstatusOrden		estatusOrden,
			heo.fechaFinal,
			heo.fechaInicial,
			DATEDIFF( day, heo.fechaInicial, coalesce( heo.fechaFinal, getdate() ) )		numDias,
			isnull(sum(cd.venta * cd.cantidad),0)				ventaOrden,
			isnull(sum(cd.costo * cd.cantidad),0)				costoOrden,
			isnull(sum(cd.costo * cd.cantidad),0) * 0.16		IVAOrden,
			isnull(sum(cd.costo * cd.cantidad),0) * 1.16		totalOrden,
			case when ( sum(cd.costo * cd.cantidad) = 0 or sum(cd.costo * cd.cantidad) is null ) and ( sum(cd.venta * cd.cantidad) = 0 or sum(cd.venta * cd.cantidad) is null ) then 0
				when sum(cd.costo * cd.cantidad) is null or sum(cd.costo * cd.cantidad) = 0 then 1
				when sum(cd.venta * cd.cantidad) is null or sum(cd.venta * cd.cantidad) = 0 then -1
				else cast( isnull(sum(cd.venta * cd.cantidad),0) / isnull(sum(cd.costo * cd.cantidad),0) - 1 as decimal(18,4))
			end porcentajeUtilidad,
			(select ASEPROT.dbo.SEL_PARTIDAS_ORDEN_FN(ord.idOrden)) descripcionPartida,
			case 
				when opte.tiempoEnEspera is null then 0
				when GETDATE() > DATEADD( hour, convert( int, substring( opte.tiempoEnEspera, 0, 3 ) ), heo.fechaInicial ) 
					then DATEDIFF(DAY, DATEADD(hour, convert(int, substring(opte.tiempoEnEspera, 0, 3 ) ), heo.fechaInicial), getdate())
				else 0
			end     as tiempoDesfasado
			--pro.razonSocial
		from Partidas.dbo.Contrato con 
			--inner join SISCOReportServices.dbo.Contrato co on co.idContrato = con.idContrato
			inner join ASEPROT.dbo.ContratoOperacion cop on cop.idContrato = con.idContrato 
			inner join ASEPROT.dbo.Ordenes ord on ord.idContratoOperacion = cop.idContratoOperacion 
			left join ASEPROT.dbo.Cotizaciones coti on coti.idOrden = ord.idOrden and coti.idEstatusCotizacion in (1,2,3) and coti.idTaller =
				case when ord.idEstatusOrden = 1 then 0
					else coti.idTaller
				end
			--left join Partidas.dbo.Proveedor pro on pro.idProveedor = coti.idTaller
			left join ASEPROT.dbo.CotizacionDetalle cd on cd.idCotizacion = coti.idCotizacion and cd.idEstatusPartida in (1,2)
			left join ASEPROT.dbo.EstatusOrdenes eso on eso.idEstatusOrden = ord.idEstatusOrden
			left join ASEPROT.dbo.HistorialEstatusOrden heo on heo.idEstatusOrden = eso.idEstatusOrden and heo.idOrden = ord.idOrden
			left join ASEPROT.Gerente.EstadoZona ez on ez.idZona = ord.idZona and ez.idContratoOperacion = cop.idContratoOperacion
			left join ASEPROT.Gerente.Estados est on est.idEstados = ez.idEstado
			left join ASEPROT.Gerente.EstadoGerencia ege on ege.idEstado = est.idEstados
			left join ASEPROT.Gerente.Gerencias ger on ger.idGerencias = ege.idGerencia
			left join ASEPROT.dbo.Operaciones oper on oper.idOperacion = cop.idOperacion and oper.tiempoAsignado = 1
			left join ASEPROT.dbo.OperacionTiempoEnEspera opte on opte.idOperacion = oper.idOperacion and opte.idEstatusOrden = ord.idEstatusOrden
		where cop.idContratoOperacion = coalesce(@idContratoOperacion, cop.idContratoOperacion)
			and coalesce(est.idEstados,0) = coalesce(@idEstado, est.idEstados,0)
			and ord.idEstatusOrden in(1,2,3,4, 5, 6, 7, 8, 10)
			AND COALESCE(ger.idGerencias, 0) = coalesce(@idGerencia, ger.idGerencias, 0)
		group by con.idContrato, con.descripcion, ord.numeroOrden, ger.idGerencias, ger.nombreGerencia, est.idEstados, est.nombreEstado, eso.idEstatusOrden, eso.nombreEstatusOrden, ord.idOrden, ord.idZona, heo.fechaFinal, heo.fechaInicial, opte.tiempoEnEspera--, pro.razonSocial
	end
end
go

