
-- =============================================
-- Author:		<YJH>
-- Create date: <09/04/19>
-- Description:	<1. inserta partidas
--               2. Inserta N cotizaciones
--               3. Inserta el detalle de las cotizaciones
--               4. Inserta la orden>
/*
[Banorte].[INS_ORDEN_COTIZACIONES] @idTipoUnidad=186, @idContratoUnidad=748, @idUsuarioPartidas = 59, @partidas = '<parte><idTipoPartida>1</idTipoPartida><partida> GORRA BASEBALL UNISEX ROJO SEAT   ANTRA                                        </partida><marca>8</marca><noParte>6H1084300  GAD             </noParte><descripcion> GORRA BASEBALL UNISEX ROJO SEAT   ANTRA</descripcion><precioCompraR>197.91</precioCompraR><precioCompraMano>197.91</precioCompraMano><precioVenta>160.31</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>true</isBackorder><idCotizacion>1</idCotizacion></parte><parte><idTipoPartida>1</idTipoPartida><partida>ASIDERO                                                                         </partida><marca>8</marca><noParte>2H5829505FGRU       </noParte><descripcion>ASIDERO                                                                         </descripcion><precioCompraR>1646.7</precioCompraR><precioCompraMano>1646.7</precioCompraMano><precioVenta>1333.83</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>2</idCotizacion></parte><parte><idTipoPartida>1</idTipoPartida><partida>CAJA RETRO                                                                      </partida><marca>8</marca><noParte>6K1857508FGRU              </noParte><descripcion>CAJA RETRO                                                                      </descripcion><precioCompraR>1556.88</precioCompraR><precioCompraMano>1556.88</precioCompraMano><precioVenta>1261.07</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>true</isBackorder><idCotizacion>1</idCotizacion></parte>',
@idUnidad= 7109, @comentario='', @idZona=308, @taller=1184, @idUsuario= 710, @idBproTaller= 1220, @idEstatusCotizacion=3, @idTipoCotizacion=1
*/
-- =============================================
CREATE PROCEDURE [Banorte].[INS_ORDEN_COTIZACIONES]
@idTipoUnidad int,
@idContratoUnidad int, 
@idUsuarioPartidas int,
@partidas XML, 

@idUnidad NUMERIC(18,0), 	
@comentario VARCHAR(500),
@idZona  NUMERIC(18,0),	
@taller INT, 
@idUsuario  NUMERIC(18,0),
@idBproTaller INT=0,
@idTipoOrdenServicio NUMERIC(18,0)=1,

@idEstatusCotizacion int,
@idTipoCotizacion int
AS
BEGIN

	--Tipos de partida
	DECLARE 
		@idEspecialidad int = 20,
		@idClasificacion int = 1, 
		@idSubClasificacion int =1, 
		@idPartida int=0, 
		@idContratoPartida int=0,
		@count int

	--Tipos ordenes
	DECLARE 	
		@idEstadoUnidad NUMERIC(18,0) = 2,
		@grua INT = 0,
		@idCentroTrabajo INT=0,
		@estatusOrden INT =5,
		------------------
		@idOperacion NUMERIC(18,0),	
		@idContratoOperacion NUMERIC(18,0), 
		@consecutivoOrden INT,
		@idOrden INT, 
		@numeroOrden varchar(20)

	DECLARE 
		@cotizacionesIns as table (idCotizacion int, numeroCotizacion nvarchar(20), idCotizacionS int, tipo bit)		

	DECLARE @idEstatusPartida INT = 2

	declare @partes as table (idUnidad int , idTipoPartida int, partida nvarchar (50), marca nvarchar (200), noParte nvarchar (200),
			 descripcion nvarchar (max), idContratoUnidad int, precioCompraR decimal(18,2), precioCompraMano decimal(18,2), 
			 precioVenta decimal(18,2), tiempo nvarchar(8), isBackorder int, idPartida int, idCotizacion int, cantidad int);
		
	BEGIN TRY
		BEGIN TRAN TranInsertaOrden

		INSERT INTO @partes 
			(idUnidad, idTipoPartida, partida, marca, noParte, descripcion, idContratoUnidad, 
			precioCompraR, precioCompraMano, precioVenta, tiempo, isBackorder, idCotizacion, cantidad)
		   SELECT 
		    @idTipoUnidad, x.value('idTipoPartida[1]', 'INT'), x.value('partida[1]', 'nvarchar(50)'),
			x.value('marca[1]', 'nvarchar(200)'), x.value('noParte[1]', 'nvarchar(200)'), x.value('descripcion[1]', 'nvarchar(max)'), 		
			@idContratoUnidad, x.value('precioCompraR[1]', 'decimal(18,2)'), x.value('precioCompraMano[1]', 'decimal(18,2)'),
			x.value('precioVenta[1]', 'decimal(18,2)'), x.value('tiempo[1]', 'nvarchar(7)'), x.value('isBackorder[1]', 'bit'),
			x.value('idCotizacion[1]', 'int'), x.value('cantidad[1]', 'int')
		   FROM @partidas.nodes('//parte') partidas(x)				
		
		--1. Inserta partidas
		MERGE Partidas.dbo.Partida AS target  
		USING @partes AS source 
		ON (target.noParte = source.noParte and target.idUnidad = source.idUnidad)  			
		WHEN NOT MATCHED THEN  
			INSERT (idUnidad, idTipoPartida, idEspecialidad, idPartidaClasificacion, idPartidaSubClasificacion, partida, marca, noParte, 
			        descripcion, foto, instructivo, estatus)  
			VALUES (source.idUnidad, source.idTipoPartida, @idEspecialidad, @idClasificacion, @idSubClasificacion, source.partida,
				    source.marca, source.noParte, source.descripcion,'', '', 1)		
		;
				
		UPDATE @partes SET idPartida = PP.idPartida FROM @partes AS P
			INNER JOIN Partidas.dbo.Partida AS PP ON P.noParte = PP.noParte and P.idUnidad = PP.idUnidad			

		MERGE Partidas.dbo.ContratoPartida AS target  
		USING @partes AS source 
		ON (target.idPartida = source.idPartida and target.idContratoUnidad = source.idContratoUnidad)  			
		WHEN NOT MATCHED THEN  
			INSERT (idContratoUnidad, idPartida, venta, fecha, idUsuario, precio1, precio2, precio3, precio4, precio5, precio6, precio7,
			        precioMano, precioRefaccion, precioLubricante, tiempo, precio7Respaldo)
			VALUES (source.idContratoUnidad, source.idPartida, source.precioVenta, GETDATE(), @idUsuarioPartidas, source.precioCompraR,
			        source.precioCompraR, source.precioCompraR, source.precioCompraR, source.precioCompraR, source.precioCompraR, 
					source.precioCompraR, source.precioCompraMano, source.precioCompraR, 0.00, CAST(source.tiempo AS TIME), 0.00)
		;
		
		--2. Insertar Orden 
		
		--Obtengo los datos necesarios de la unidad para formar el numero de la orden para el campo [numeroOrden]
		SELECT @idOperacion = UNI.idOperacion, @idContratoOperacion = CP.idContratoOperacion
		FROM [Unidades] UNI
		INNER JOIN [ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion
		WHERE idUnidad = @idUnidad

		--Obtengo el consecutivo para formar el numero de la orden 
		IF (EXISTS(SELECT TOP 1 consecutivoOrden FROM ASEPROT.dbo.Ordenes WHERE idContratoOperacion = @idContratoOperacion))		
			SET @consecutivoOrden = (SELECT TOP 1 consecutivoOrden FROM ASEPROT.dbo.Ordenes WHERE idContratoOperacion = @idContratoOperacion ORDER BY consecutivoOrden DESC) +1		
		ELSE 		
			SET @consecutivoOrden = 1					

		select @numeroOrden = ISNULL(RIGHT('00' + CAST(@idContratoOperacion AS varchar(2)), 2),'S/N')  + '-' + ISNULL(convert(varchar(max),@idUnidad),'S/N') + '-' + ISNULL(RIGHT( CAST(@consecutivoOrden AS varchar(6)), 6),'S/N')

		INSERT INTO ASEPROT.dbo.Ordenes 
			([fechaCreacionOden], [fechaCita], [fechaInicioTrabajo], [numeroOrden], [consecutivoOrden]
			,[comentarioOrden], [requiereGrua], [idCatalogoEstadoUnidad], [idZona], [idUnidad]
			,[idContratoOperacion], [idUsuario], [idCatalogoTipoOrdenServicio], [idTipoOrden]
			,[idEstatusOrden], [idCentroTrabajo], [idTaller], [idGarantia], [motivoGarantia], [idBproProveedor])
		    values (GETDATE(), GETDATE(), GETDATE(),
			@numeroOrden,
			@consecutivoOrden, @comentario, @grua, @idEstadoUnidad, @idZona, @idUnidad, @idContratoOperacion,
			@idUsuario, @idTipoOrdenServicio, 1, @estatusOrden, @idCentroTrabajo, @taller, 0, '', @idBproTaller)
			
		SET @idOrden = @@IDENTITY
		
		declare @id int = 1
		while (@id < = @estatusOrden)
		begin 
			INSERT INTO ASEPROT.dbo.HistorialEstatusOrden (idOrden, idEstatusOrden, fechaInicial, fechaFinal, idUsuario)
			VALUES (@idOrden, @id,GETDATE(), GETDATE(), @idUsuario)	
			set @id = @id + 1;
		end 
		
		-- 3. Inserta cotizaciones 

		set @id=1; 
		declare @len int, @consecutivoCotizacion int, @idCotizacion int, @idAutorizacionCot int, @idC int=1
		select @len= COUNT(distinct idCotizacion) from @partes 
		
		while (@id < = @len)
		begin 
			set @consecutivoCotizacion=0
			set @idCotizacion=0
			set @idAutorizacionCot=0
			set @idC=1

			IF (EXISTS(SELECT TOP 1 consecutivoCotizacion FROM ASEPROT.dbo.Cotizaciones WHERE idOrden = @idOrden))			
				SET @consecutivoCotizacion = (SELECT TOP 1 consecutivoCotizacion FROM ASEPROT.dbo.Cotizaciones WHERE idOrden = @idOrden ORDER BY consecutivoCotizacion DESC) +1
			ELSE
				SET @consecutivoCotizacion = 1			
			
			INSERT INTO ASEPROT.dbo.Cotizaciones 
			(fechaCotizacion, idTaller, idUsuario, idEstatusCotizacion, idOrden, numeroCotizacion, consecutivoCotizacion,
			idCatalogoTipoOrdenServicio, idPreorden, idBproProveedor, idTipoCotizacion) VALUES
			(GETDATE(), @taller, @idUsuario, @idEstatusCotizacion, @idOrden, @idOrden+'-'+CONVERT (varchar(5), @consecutivoCotizacion),
			@consecutivoCotizacion,@idTipoOrdenServicio,null, @idBproTaller, @idTipoCotizacion)
		
			SET @idCotizacion = @@IDENTITY 
			
			while (@idC <= @idEstatusCotizacion)
			begin 
				INSERT INTO ASEPROT.dbo.HistorialEstatusCotizacion (fechaInicial,idCotizacion,idUsuario,idEstatusCotizacion)
				VALUES (GETDATE(), @idCotizacion, @idUsuario, @idC)			
				
				set @idC = @idC + 1;
			end 			

			INSERT INTO ASEPROT.dbo.AutorizacionCotizacion (fechaNotificacion, fechaAutorizacion, idCotizacion)
			VALUES (GETDATE(), GETDATE(), @idCotizacion)
			
			SET @idAutorizacionCot = @@IDENTITY
			
			--4. Inserta detalle de cotizacion 
			INSERT INTO ASEPROT.dbo.CotizacionDetalle				
				select @idCotizacion, precioCompraR, cantidad, precioVenta, idPartida, @idEstatusPartida, 0, cantidad, null, null
				       ,precioCompraMano, null, null, null from @partes where idCotizacion = @id				 
			
			INSERT INTO ASEPROT.dbo.DetalleAutorizacionCotizacion 
			select GETDATE(), @idUsuario, @idAutorizacionCot, @idEstatusPartida, idCotizacionDetalle from ASEPROT.dbo.CotizacionDetalle where idCotizacion = @idCotizacion							

			insert into @cotizacionesIns 
			select idCotizacion, numeroCotizacion, @id, (select top 1 isBackorder from @partes where idCotizacion = @id) 
				from ASEPROT.dbo.Cotizaciones where idCotizacion = @idCotizacion

			set @id= @id+1;
		end

		select @idOrden as idOrden, @numeroOrden as numeroOrden 
		select * from @cotizacionesIns

		COMMIT TRAN TranInsertaOrden			

	END TRY
	BEGIN CATCH
		ROLLBACK TRAN TranInsertaProvision
		SELECT ERROR_NUMBER() AS Number,
	           ERROR_SEVERITY() AS Severity,
			   ERROR_STATE() AS [State],
			   ERROR_PROCEDURE() AS [Procedure],
			   ERROR_LINE() AS Line,
			   ERROR_MESSAGE() AS [Message]
	END CATCH	
END
go

