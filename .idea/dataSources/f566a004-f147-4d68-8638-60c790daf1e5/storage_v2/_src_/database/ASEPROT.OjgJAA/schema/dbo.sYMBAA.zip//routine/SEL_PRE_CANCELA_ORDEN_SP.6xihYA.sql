
CREATE PROCEDURE [dbo].[SEL_PRE_CANCELA_ORDEN_SP]
	@idOperacion int
AS
BEGIN

	DECLARE @idContratoOperacion int = (select idContratoOperacion from ContratoOperacion where idOperacion = @idOperacion) 

	SELECT
	(SELECT [dbo].[SEL_NOMBRE_CLIENTE](ORDEN.idContratoOperacion)) AS nombreCliente,
	ORDEN.consecutivoOrden as consecutivoOrden, 
	ORDEN.numeroOrden as numeroOrden,
	PRECA.idOrden as idOrden,
	uni.numeroEconomico as numeroEconomico,
	zona.nombre as zonaNombre, 
	catalogoServicios.nombreTipoOrdenServicio as nombreTipoDeServicio,
	convert(datetime, DATEADD(HH,5,ORDEN.fechaCreacionOden)) as fechaCreacionOrden, 
	ORDEN.fechaCita as fechaCita, 
	ORDEN.comentarioOrden as comentarioOrden, 
	EstOrden.nombreEstatusOrden as nombreEstatusOrden,
	(SELECT nombreCompleto FROM Usuarios where idusuario= ORDEN.idUsuario)	as idUsuarioAgendo, 
	preDetalle.fechaCancelacion, 
	(SELECT nombreCompleto FROM Usuarios where idUsuario = preDetalle.idUsuario)as usuarioCancelacion,
	preDetalle.comentarioPreCancelacion as comentarios
	FROM preCancelacionOrdenes  PRECA
	LEFT JOIN Ordenes ORDEN ON ORDEN.idOrden= PRECA.idOrden
	LEFT JOIN PreCancelacionDetalle preDetalle on preDetalle.idCancelacion = PRECA.idCancelacion 
	LEFT JOIN EstatusOrdenes EstOrden ON EstOrden.idEstatusOrden= ORDEN.idEstatusOrden
	LEFT JOIN Usuarios usu ON usu.idUsuario= preDetalle.idUsuario 
	LEFT JOIN Unidades uni ON uni.idUnidad = ORDEN.idUnidad
	LEFT JOIN [Partidas].[dbo].[Zona] zona ON zona.idZona= ORDEN.idZona
	LEFT JOIN CatalogoTiposOrdenServicio catalogoServicios ON catalogoServicios.idCatalogoTipoOrdenServicio= ORDEN.idCatalogoTipoOrdenServicio
	where ORDEN.idContratoOperacion= @idContratoOperacion
END
go

