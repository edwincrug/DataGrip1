-- =============================================
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- [INS_DETALLE_APROBACION_PARTIDA_SP]
-- =============================================
 CREATE PROCEDURE [dbo].[INS_DETALLE_APROBACION_PARTIDA_SP]
	@idOperacionContrato INT,
	@idPartida INT,
	@nivel INT
AS
BEGIN
	DECLARE @OperacionContrato INT

	IF @nivel <> 0
		BEGIN
			IF NOT EXISTS (SELECT 1 FROM DetalleOperacionAprobacionPartida WHERE idOperacionContrato=@idOperacionContrato AND idPartida=@idPartida) 
				BEGIN
					INSERT INTO DetalleOperacionAprobacionPartida VALUES(@idOperacionContrato,@idPartida,@nivel)
					SET @OperacionContrato = 1
				END
			ELSE
				BEGIN
					UPDATE DetalleOperacionAprobacionPartida
					SET nivel=@nivel
					WHERE idOperacionContrato=@idOperacionContrato AND idPartida=@idPartida

					SET @OperacionContrato = 2
				END

			IF NOT EXISTS (SELECT 1 FROM OperacionAprobacion WHERE idOperacionContrato = @idOperacionContrato)
				BEGIN
					INSERT INTO OperacionAprobacion values (@idOperacionContrato,2)
				END
			ELSE
				BEGIN
					update OperacionAprobacion set idCatalogoTipo = 2 where idOperacionContrato = @idOperacionContrato
				END
		END
	ELSE
		BEGIN
			IF EXISTS (SELECT 1 FROM DetalleOperacionAprobacionPartida WHERE idOperacionContrato=@idOperacionContrato AND idPartida=@idPartida)
				BEGIN
					DELETE FROM DetalleOperacionAprobacionPartida WHERE idOperacionContrato = @idOperacionContrato AND idPartida = @idPartida

					SET @OperacionContrato = 3
				END
		END
							
	SELECT @OperacionContrato
END


go

