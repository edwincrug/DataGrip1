 --SELECT [dbo].[SEL_ORDBYPEDIDOZEROS_TFN]('6364',12)
 CREATE FUNCTION [dbo].[SEL_ORDBYPEDIDOZEROS_TFN] ( @numSiniestro nvarchar(max), @idMarca int)
returns varchar(max)
as 
begin
	
	DECLARE @factura varchar(max) = '';
	IF @idMarca =1 --NISSAN
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAZM_Zaragoza].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAZM_Zaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'

	END 
	ELSE IF @idMarca=2 --GM
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAAS_Satelite].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAS_Satelite].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END 
	ELSE IF @idMarca=3 --Ford
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAAAF_Body].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAAF_Body].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=4 --Suzuki
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAAU_Universidad].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAU_Universidad].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=5 --Hyundai
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAHyundai].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAHyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	/*ELSE IF @idMarca=6 --CRA
	BEGIN 
		select @factura=((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GACRA_Cuautitlan].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GACRA_Cuautitlan].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		SO.ore_idSiniestro = @numSiniestro and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END*/
	ELSE IF @idMarca=7 --Honda
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAHondaZaragoza].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAHondaZaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=8 --Volkswagen
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.31].[GADLA_VW].[dbo].SER_ORDEN SO
		inner join [192.168.20.31].[GADLA_VW].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where-- ORE_DOCTO like '%41628%'
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'

	END
	ELSE IF @idMarca=9 --Seat
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.31].[GADLA_SEAT].[dbo].SER_ORDEN SO
		inner join [192.168.20.31].[GADLA_SEAT].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=11 --Chevrolet
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAAA_Azcapo].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAA_Azcapo].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=12 --Chrysler
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAAutoAngarTlahuac].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAutoAngarTlahuac].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'

		if(@factura='' or @factura is null)
		begin 
			select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
			Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
			PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
			from [192.168.20.29].GAAutoAngarTepepan.[dbo].SER_ORDEN SO
			inner join [192.168.20.29].GAAutoAngarTepepan.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
			(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
		end
	END
	ELSE IF @idMarca=13 --Hyundai Cam
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAVC_Hyundai].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAVC_Hyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=16 --Mitsubishi
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].[GAAutoAngarMitsu].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAutoAngarMitsu].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=22 --Nissan Abasto
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+((LEFT(ORE_IDORDEN, LEN(ORE_IDORDEN) - PATINDEX('%[a-z]%', REVERSE(ORE_IDORDEN)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(ORE_IDORDEN, PATINDEX('%[0-9.-]%', ORE_IDORDEN), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) +''''
		from [192.168.20.29].GAZM_Abasto.[dbo].SER_ORDEN SO
		inner join [192.168.20.29].GAZM_Abasto.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	
	select @factura= STUFF(@factura, 1, 1, '')
	
	return @factura
end
 go

