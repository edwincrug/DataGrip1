-- =============================================
-- Author:		<YJH>
-- Create date: <18/07/2018>
-- Description:	<Cancela una cotizacion>
-- [Banorte].[CANCELA_COTIZACION] 47560,677
-- Modify: Christian Ochoa Nicolas
-- Modify date: 25-09-2018
-- Modify description: Si la cotización es unica en la orden cancela la orden de igual manera
-- =============================================
CREATE PROCEDURE [Banorte].[CANCELA_COTIZACION] 
	@idCotizacion int, 
	@idUsuario int
AS
BEGIN
	DECLARE @idEstatusCancela INT = 4,
		@idEstatusActual INT =0,
		@hasFactura INT=0,
		@fecha DATE = GETDATE(),
		@idOrden INT,
		@totalCotizaciones INT,
		@estatusCancela INT

	SELECT @idEstatusActual= idEstatusCotizacion, @idOrden = idOrden FROM Cotizaciones WHERE idCotizacion=@idCotizacion
	SELECT @totalCotizaciones = COUNT(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden AND idEstatusCotizacion <> 4

	SELECT @hasFactura= [dbo].[SEL_ORDEN_TIENE_DOCUMENTO_FT](idOrden,3,ConsecutivoCotizacion) FROM Cotizaciones WHERE idCotizacion = @idCotizacion


	IF(@hasFactura=0 and @idEstatusActual <>@idEstatusCancela)
	BEGIN
		UPDATE Cotizaciones SET idEstatusCotizacion=@idEstatusCancela WHERE idCotizacion = @idCotizacion
		INSERT INTO HistorialEstatusCotizacion (fechaInicial, fechaFinal, idCotizacion,idUsuario,idEstatusCotizacion)
		VALUES (@fecha, @fecha, @idCotizacion, @idUsuario, @idEstatusCancela)
		SELECT @estatusCancela = @@IDENTITY
		IF (@totalCotizaciones > 1)
		BEGIN
			SELECT @estatusCancela AS estatusCancela
		END
		ELSE
		BEGIN
			EXEC [dbo].[EXT_UPD_CANCELA_ORDEN_SP] @idUsuario, @idOrden
		END
	END
	ELSE
	BEGIN
		SELECT 1 AS estatusCancela
	END

END
go

grant execute, view definition on Banorte.CANCELA_COTIZACION to DevOps
go

