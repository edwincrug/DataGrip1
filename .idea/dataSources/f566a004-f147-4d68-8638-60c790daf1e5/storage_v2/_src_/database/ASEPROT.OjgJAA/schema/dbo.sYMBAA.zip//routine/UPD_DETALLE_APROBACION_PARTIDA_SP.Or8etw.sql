-- =============================================
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- [UPD_DETALLE_APROBACION_PARTIDA_SP]
-- =============================================
 CREATE PROCEDURE [dbo].[UPD_DETALLE_APROBACION_PARTIDA_SP]
	@idOperacionContrato NUMERIC(18, 0),
	@nivel NUMERIC(18, 0),
	@idPartida NUMERIC(18, 0)
AS
BEGIN

	UPDATE DetalleOperacionAprobacionPartida 
	SET nivel=@nivel
	WHERE idOperacionContrato=@idOperacionContrato AND idPartida=@idPartida
		
END


go

