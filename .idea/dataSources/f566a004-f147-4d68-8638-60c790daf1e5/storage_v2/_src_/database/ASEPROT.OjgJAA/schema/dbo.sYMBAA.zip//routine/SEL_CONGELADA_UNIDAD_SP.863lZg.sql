
-- =============================================
-- Author:		
-- Create date: 28 10 2019
-- [SEL_CONGELADA_UNIDAD_SP] 1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_CONGELADA_UNIDAD_SP]
	@idOperacion NUMERIC(18,0),
	@idUnidad NUMERIC(18,0)

AS
BEGIN

	SET NOCOUNT ON;

	SELECT 
	U.IDOPERACION,
	U.IDUNIDAD,
	UR.ESTATUS
	FROM Unidades U
	LEFT JOIN UNIDADRESTRICCION UR ON UR.IDUNIDAD = U.IDUNIDAD
	WHERE U.idOperacion = @idOperacion AND U.IDUNIDAD = @idUnidad
		
END
go

