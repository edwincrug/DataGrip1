-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 28/05/2017
-- Description:	Obtiene el catalogo de modulos operativos
-- SEL_DATOS_OPERACION_SP @idOperacion=1, @tipo='Default'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DATOS_OPERACION_SP]
	@idOperacion INT
AS
BEGIN
	
			SELECT idOperacion,
					idCatalogoTipoOperacion,
					manejoUtilidad,
					porcentajeUtilidad,
					presupuesto,
					geolocalizacion,
					tiempoAsignado,
					verificacionVehicular,
					idEstatusOperacion,
					formaPago,
					comentarioCotizacion,
					sustituto,
					codigoCita,
					levantamientoInicial,
					apariencia,
					documentoCobranza
			FROM Operaciones WHERE idOperacion = @idOperacion
		
END


go

