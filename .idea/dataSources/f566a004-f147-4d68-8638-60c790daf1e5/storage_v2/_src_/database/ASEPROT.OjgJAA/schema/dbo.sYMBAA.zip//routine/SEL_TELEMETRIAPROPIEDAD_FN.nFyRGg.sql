-- =============================================
-- Author:		Sahirely Yam
-- Create date: 21 08 2017
-- SELECT [dbo].[SEL_TELEMETRIAPROPIEDAD_FN](2, 'odometer')
-- =============================================
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_TELEMETRIAPROPIEDAD_FN](@deviceid INT, @propiedad varchar(MAX))

RETURNS VARCHAR(MAX)
AS
BEGIN

	DECLARE @Result VARCHAR(MAX) 
		,@atributo nvarchar(max)
		,@protocol varchar(MAX)

	declare @tbl_atributos as table(
		idAtributo int identity(1,1),
		atributo nvarchar(50),
		valor nvarchar(200)
	)


	select top 1 @protocol = protocol from [TRACKER].[Tracker].[dbo].[tc_positions] where deviceId = @deviceId
	--PRINT @protocol

	IF (@protocol = 'cellocator')
	BEGIN
		SET @atributo = STUFF(
			(	
				SELECT top 1 ',' + attributes
				from [TRACKER].[Tracker].[dbo].[tc_positions]
				where deviceId = @deviceId
					and  [attributes] LIKE '%{"type":11%'
				order by devicetime desc
				FOR XML PATH(''), TYPE
			).value('.', 'NVARCHAR(MAX)'), 1, 1, ''
		)
	END
	ELSE
	BEGIN
		SET @atributo = STUFF(
			(	
				SELECT top 1 ',' + attributes
				from [TRACKER].[Tracker].[dbo].[tc_positions]
				where deviceId = @deviceId
				and attributes like '%odometer%'
				order by devicetime desc
				FOR XML PATH(''), TYPE
			).value('.', 'NVARCHAR(MAX)'), 1, 1, ''
		)
	END


	--select @atributo

	insert into @tbl_atributos
	select a.atributo, a.valor
	from(
		select replace(SUBSTRING([Name] , 1, CHARINDEX(':', [Name], 0) - 1 ), '"', '') as atributo
			,replace(SUBSTRING([Name], CHARINDEX(':', [Name], 0) + 1, LEN([Name]) ), '"', '') as valor
		from avl..splitstring(REPLACE( REPLACE( @atributo, '}', '' ), '{', ''),',')
		where [Name] like '%:%'
	) a
	where a.atributo = @propiedad

	--select * from @tbl_atributos

	
	SET @Result = (select tbl.valor 
	from @tbl_atributos tbl
		inner join
		(
			select atributo, min(idAtributo) idAtributo
			from @tbl_atributos
			group by atributo
		) a on a.idAtributo = tbl.idAtributo
	where tbl.atributo in(
		@propiedad
	))

	RETURN @Result;
	
END
go

