
--========================================================================
-- CREATE AUTH: Carlos Adolfo Martinez Diosdado
-- CREATE DATE: 26/12/2016
-- CREATE DESC: Devuelve la ultima ubicacion de la unidad
-- [Sustituto].[SEL_UBICACION_UNIDAD_SP] 1
--========================================================================
CREATE PROC [Sustituto].[SEL_UBICACION_UNIDAD_SP]
	@idUnidad INT
AS
BEGIN

set @idunidad = 3875 -- For test Alcabelu Remove in Production 

--DECLARE @numEconomico nvarchar(50)

--SELECT @numEconomico=numEconomico FROM Unidad WHERE idUnidad=@idUnidad

	SELECT 
	   TOP 1 
	     *
	  FROM  [Casanova].[dbo].[Localizacion] L

	  JOIN  [Casanova].[dbo].[Unidad] U 
	    ON  U.[idUnidad] = L.[idUnidad]

	  JOIN  [Unidades] UU 
	    ON  UU.[vin] = U.[vin]

  	  WHERE UU.[idUnidad]=@idUnidad

   ORDER BY [idLocalizacion] DESC

END 

---FOR INFORMATION AND GET ID FOR TEST
--- ALCABELU

--select * from [GPS].[LonLatUnique] L
--inner join [Casanova].[dbo].[Unidad] U ON U.idUnidad = L.idUnidad

--select *
--from Unidades
--where vin = '3N1AB7AD1HL652443'
go

