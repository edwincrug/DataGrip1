CREATE PROCEDURE [Banorte].[SEL_Siniestro_Orden_SP] 
  @idOrden int,
  @idOperacion int
	AS 
BEGIN
declare @idTipoOrden int 

select @idTipoOrden = idCatalogoTipoOrdenServicio  from Ordenes where idOrden = @idOrden 

if (@idTipoOrden=1)
begin
	select OS.numeroReclamo,OS.numeroPoliza,OS.versionSiniestro,U.Vin,M.Marca,U.versionVehiculo,U.Submarca,T.transmision,U.color,U.tipoVehiculo
		  ,SU.placas,Su.combustible,CONVERT(INT, OS.esSurtido) AS Surtido
	from RefaccionMultiMarca.Relacion.UnidadSiniestroOrden S
		left JOIN RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC ON S.idSiniestro = Soc.idSiniestro AND S.orden = SOC.idOrden
		INNER JOIN RefaccionMultiMarca.Operacion.Cotizacion C ON SOC.idCotizacion = C.idCotizacion
		INNER JOIN RefaccionMultiMarca.Operacion.siniestro OS On OS.idunidad = S.idUnidad AND OS.id = SOC.idSiniestro
		INNER JOIN RefaccionMultiMarca.Operacion.unidad U On U.id = S.idunidad
		INNER JOIN RefaccionMultiMarca.Catalogo.Marca M On M.idMarca = U.Marca
		left JOIN RefaccionMultiMarca.Catalogo.Transmision T On T.id=U.transmision
		INNER JOIN UNIDADES SU On U.vin = Su.vin
	where S.orden = @idOrden and SU.idOperacion=@idOperacion
end 
else 
begin 
	select OS.numeroReclamo,OS.numeroPoliza,OS.versionSiniestro,U.Vin,M.Marca,U.versionVehiculo,U.Submarca,T.transmision,U.color,U.tipoVehiculo
		  ,SU.placas,Su.combustible,CONVERT(INT, OS.esSurtido) AS Surtido
	from RefaccionMultiMarca.Relacion.UnidadSiniestroOrden S
		--left JOIN RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC ON S.idSiniestro = Soc.idSiniestro AND S.orden = SOC.idOrden
		--INNER JOIN RefaccionMultiMarca.Operacion.Cotizacion C ON SOC.idCotizacion = C.idCotizacion
		INNER JOIN RefaccionMultiMarca.Operacion.siniestro OS On OS.idunidad = S.idUnidad AND OS.id = S.idSiniestro
		INNER JOIN RefaccionMultiMarca.Operacion.unidad U On U.id = S.idunidad
		INNER JOIN RefaccionMultiMarca.Catalogo.Marca M On M.idMarca = U.Marca
		left JOIN RefaccionMultiMarca.Catalogo.Transmision T On T.id=U.transmision
		INNER JOIN UNIDADES SU On U.vin = Su.vin
	where S.orden = @idOrden and SU.idOperacion=@idOperacion	
end 
END

go

grant execute, view definition on Banorte.SEL_Siniestro_Orden_SP to DevOps
go

