
/*
	Objetivo: Actualiza partidas rechazadas desde SISRE

	Fecha			Autor			Descripción
	31/07/2018		YJH				Creacion del SP
	07/08/2018		José Etmanuel	Se modifico Para rechazos parciales
	*---  Pruebas
	
*/

-- Banorte.Rechaza_Piezas <piezas><pieza><idCotizacion>47748</idCotizacion><noParte>71712-52R00-ZMW</noParte></pieza></piezas>
CREATE PROCEDURE [Banorte].[Rechaza_Piezas]
	@piezas XML
AS
BEGIN

	CREATE TABLE ##tempRechazos(idCotizacion NUMERIC(18,0), noRechazadas NUMERIC(18,0), idPartida NUMERIC(18,0))

	INSERT INTO ##tempRechazos 
		(idCotizacion,noRechazadas,idPartida)
       SELECT 
	    x.value('idCotizacion[1]', 'INT') AS idCotizacion, 
		x.value('cantidad[1]', 'INT') AS noRechazadas, 
		(SELECT P.idPartida FROM Partidas.dbo.Partida P JOIN CotizacionDetalle CD ON CD.idPartida = P.idPartida WHERE P.noParte=x.value('noParte[1]', 'nvarchar(max)') AND CD.idCotizacion = x.value('idCotizacion[1]', 'INT') ) as idPartida
       FROM @piezas.nodes('//pieza') partidas(x)
		
	/*select * from CotizacionDetalle CD
	inner join Partidas.dbo.Partida P on CD.idPartida = P.idPartida
	where CD.idCotizacion=@idCotizacion and P.noParte=@noParte

	update CotizacionDetalle set isRechazada=1 where idCotizacionDetalle=@idCotizacionDetalle*/

	
	MERGE CotizacionDetalle AS target  
    USING ##tempRechazos AS source 
    ON (target.idPartida = source.idPartida and target.idCotizacion = source.idCotizacion and target.cantidad > 0)  
    WHEN MATCHED THEN   
        UPDATE SET 
			target.cantidad = ( target.cantidad - source.noRechazadas),
			target.rechazadas = source.noRechazadas
    OUTPUT $action;

	drop table ##tempRechazos
END
go

grant execute, view definition on Banorte.Rechaza_Piezas to DevOps
go

