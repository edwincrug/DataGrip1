/*
SELECT * FROM Ordenes WHERE idOrden=232
SELECT * FROM Cotizaciones WHERE idOrden=232 
SELECT * FROM facturaCotizacion
select * from Cotizaciones where idCotizacion=78
select * from [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERENC]
SELECT * FROM Ordenes WHERE numeroOrden='01-1430023-249'
*/
-- [SEL_VALIDA_FACTURA_COTIZACION_SP] 40184, 677, 20, 0
CREATE PROCEDURE [dbo].[SEL_VALIDA_FACTURA_COTIZACION_SP]
	 @idOrden NUMERIC(18,0), --106 -- 25 -- o  11
	 @idUsuario NUMERIC(18,0),
	 @idOperacion NUMERIC(18,0),
	 @cantidad int = 0
AS
BEGIN

	DECLARE @numeroOrden NVARCHAR(100)
	DECLARE @proveedorInterno NUMERIC(18,0)
	
	SELECT @numeroOrden=numeroOrden FROM Ordenes WHERE idOrden=@idOrden

	SELECT @proveedorInterno = CO.proveedorInterno
		FROM ContratoOperacion C
		INNER JOIN ContratoOperacionFacturacion CO ON CO.idContratoOperacion = C.idContratoOperacion
		WHERE idOperacion = @idOperacion

	if ((select case when not exists (select 1 from Cotizaciones C1 where C1.idEstatusCotizacion = 3 AND C1.idOrden = @idOrden and C1.idTaller in (select idProveedor from Partidas..Proveedor  where razonSocial like '%TOTAL PARTS AND COMPONENTS%') AND @proveedorInterno = 1) then 1 else 0 end) = 1)
	--si el taller de la cotizacion no es total parts
	BEGIN
		IF (@cantidad = 0)
		BEGIN
			IF NOT EXISTS(SELECT TOP 1 idProveedorEncabezado FROM Partidas..Proveedor WHERE idProveedor IN(SELECT idTaller FROM Cotizaciones WHERE idOrden=@idOrden AND idTaller <> 0) AND idProveedorEncabezado IS NULL)
			BEGIN
				DECLARE @Espera NUMERIC(18,0) = (SELECT COUNT(idCotizacion) FROM Cotizaciones COTI 
				                                INNER JOIN EstatusCotizaciones EST ON COTI.idEstatusCotizacion = EST.idEstatusCotizacion 
												WHERE idOrden = @idOrden AND COTI.idEstatusCotizacion IN (1,2));

				IF( @Espera <> 0 )
				BEGIN
					SELECT success = 0, msg = 'Aún hay cotizaciones en espera, no se puede continuar con el proceso'
				END
				ELSE
				BEGIN
					DECLARE @Validaciones TABLE(Aprobadas INT, Facturas INT);
					INSERT INTO @Validaciones(Aprobadas, Facturas) SELECT 
								(SELECT COUNT(idCotizacion) FROM Cotizaciones COTI WHERE idOrden = @idOrden AND COTI.idEstatusCotizacion IN (3) ) as Aprobadas,
								(SELECT COUNT(idFacturaCotizacion) FROM FacturaCotizacion FC INNER JOIN Cotizaciones COTI ON FC.idCotizacion = COTI.idCotizacion WHERE idOrden = @idOrden AND COTI.idEstatusCotizacion IN (3)) as Facturas;
					
					DECLARE @Ultima NUMERIC(18,0) = (SELECT CAST(CASE WHEN Aprobadas = Facturas THEN 1 ELSE 0 END AS bit) as Ultima FROM @Validaciones);
			
					IF( @Ultima = 0 )
					BEGIN
						SELECT success = 0, msg = 'Aun tienes facturas por subir'
					END
					ELSE
					BEGIN
						SELECT success = 1, msg = 'Procesando petición'
					END
				END
			END
			ELSE
			BEGIN
				SELECT success = 0, msg = 'El proveedor no esta dado de alta'
			END
		END
		ELSE
		BEGIN
			SELECT success = 2, msg = 'Provisionado'
		END							
	END
	ELSE
	-- si el taller es total parts
	BEGIN
		print 'entra en 2'
		declare @idProveedor int = (select top 1 idTaller from Cotizaciones where idOrden = @idOrden and idEstatusCotizacion not in (4,5))
	
		IF (@cantidad = 0)
		BEGIN
			IF NOT EXISTS(SELECT TOP 1 idProveedorEncabezado FROM Partidas..Proveedor WHERE idProveedor IN(SELECT idTaller FROM Cotizaciones WHERE idOrden=@idOrden AND idTaller <> 0) AND idProveedorEncabezado IS NULL)
			BEGIN
				DECLARE @Espera2 NUMERIC(18,0) = (SELECT COUNT(idCotizacion) FROM Cotizaciones COTI 
												INNER JOIN EstatusCotizaciones EST ON COTI.idEstatusCotizacion = EST.idEstatusCotizacion 
												WHERE idOrden = @idOrden AND COTI.idEstatusCotizacion IN (1,2));

				IF( @Espera2 <> 0 )
				BEGIN
					SELECT success = 0, msg = 'Aún hay cotizaciones en espera, no se puede continuar con el proceso'
				END
				ELSE
				BEGIN
					SELECT success = 1, msg = 'Procesando petición'
				END
			END
			ELSE
			BEGIN
				SELECT success = 0, msg = 'El proveedor no esta dado de alta'
			END
		END
		ELSE
		BEGIN
			SELECT success = 2, msg = 'Provisionado'
		END
	END
END
go

