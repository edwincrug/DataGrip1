    
-- =============================================    
-- Author:  <Jose Luis Lozada Guerrero>    
-- Create date: <30/12/2019>    
-- Description: <Procedimiento para obtener los datos de una orden >    
/* 
	DECLARE @err varchar(max)   
	EXEC SEL_ORDENES_PF_SP 
		@err = @err out
	print 'Error: ' + @err

*/    
    
-- =============================================    

CREATE PROCEDURE [dbo].[SEL_ORDENES_PF_SP]
	@idUsuario	int = null,
	@err varchar(max) out
AS    
BEGIN    

	select distinct 
		ord.idOrden, 
		ord.numeroOrden,
		sum(isnull(cotdet.cantidad,0) * isnull(cotdet.costo,0)) costo,
		sum(isnull(cotdet.cantidad,0) * isnull(cotdet.venta,0)) venta,
		dbo.[SEL_PRECIO_COSTO_COT_FN](cot.idCotizacion,37,1,0,0) costoFN,
		dbo.[SEL_PRECIO_VENTA_COT_FN](cot.idCotizacion,37,1,0,0) ventaFN


	from Ordenes ord
	inner join Cotizaciones cot on cot.idOrden = ord.idOrden
	inner join CotizacionDetalle cotdet on cotdet.idCotizacion = cot.idCotizacion
	where 
		ord.idEstatusOrden between 4 and 12
		and cot.idEstatusCotizacion not in (4)
		and cotdet.idEstatusPartida = 2
		and ord.idContratoOperacion = 37
		and ord.idOrden > 107293	
	group by 
		ord.idOrden, 
		ord.numeroOrden,
		cot.idCotizacion
	order by idOrden
END
go

