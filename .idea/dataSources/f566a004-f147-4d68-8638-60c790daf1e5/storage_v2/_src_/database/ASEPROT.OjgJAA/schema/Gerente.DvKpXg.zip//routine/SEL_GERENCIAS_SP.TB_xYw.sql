 CREATE PROCEDURE [Gerente].[SEL_GERENCIAS_SP]

AS
BEGIN
	SELECT 
		G.idGerencias,
		G.nombreGerencia,
		G.descripcionGerencia,
		G.fechaAlta,
		G.idUsuario,
		U.nombreCompleto
	FROM [Gerente].[Gerencias] G
	JOIN [dbo].[Usuarios] U ON U.idUsuario = G.idUsuario
	WHERE G.estatus = 0
	ORDER BY G.idGerencias DESC
END


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.SEL_GERENCIAS_SP to DevOps
 go

