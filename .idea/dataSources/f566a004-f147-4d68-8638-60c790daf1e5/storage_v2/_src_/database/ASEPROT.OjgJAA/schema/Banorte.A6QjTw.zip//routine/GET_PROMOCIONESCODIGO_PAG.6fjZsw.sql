

/*
	Objetivo: Trae los datos de una promoción, con el código

	Fecha			Autor			Descripción
	29-Oct-2018		José Etmanuel	Se crea el SP 
	
	[Banorte].[GET_PROMOCIONESCODIGO_PAG] 
*/

CREATE PROCEDURE [Banorte].[GET_PROMOCIONESCODIGO_PAG] 
	@codigo varchar(50)
AS
BEGIN
	IF EXISTS (
		SELECT * FROM 
		[dbo].PromocionesCodigos AS PC
		INNER JOIN [Banorte].Promociones AS TP ON TP.id = PC.IdPromocion
		INNER JOIN [dbo].Usuarios AS US ON US.idUsuario = PC.IdUsuario
		WHERE PC.Codigo = @codigo
	)
	BEGIN
		SELECT *,1 as ok FROM 
			[dbo].PromocionesCodigos AS PC
			INNER JOIN [Banorte].Promociones AS TP ON TP.id = PC.IdPromocion
			INNER JOIN [dbo].Usuarios AS US ON US.idUsuario = PC.IdUsuario
			WHERE PC.Codigo = @codigo
	END
	ELSE
	BEGIN
		SELECT 0 as ok, 'Código no encontrado' as msg;
	END
END

go

grant execute, view definition on Banorte.GET_PROMOCIONESCODIGO_PAG to DevOps
go

