CREATE PROCEDURE [Mobile].[SEL_Catalogo_SP]
	@idCatalogo int
AS
BEGIN

	SELECT idCatalogo, valor FROM Mobile.Catalogo WHERE idCatalogo = @idCatalogo

END
go

grant execute, view definition on Mobile.SEL_Catalogo_SP to DevOps
go

