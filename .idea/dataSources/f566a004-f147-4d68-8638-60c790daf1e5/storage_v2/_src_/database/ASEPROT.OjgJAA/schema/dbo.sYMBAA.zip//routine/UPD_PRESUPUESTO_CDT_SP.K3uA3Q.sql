
CREATE PROCEDURE  [dbo].[UPD_PRESUPUESTO_CDT_SP]
	@idPresupuesto INT = NULL,
	@idCentroTrabajo INT = NULL

AS
BEGIN

	IF EXISTS(SELECT 1 FROM [dbo].[Presupuestos] WHERE idCentroTrabajo = @idCentroTrabajo AND idEstatusPresupuesto = 1)
	BEGIN
		UPDATE [dbo].[Presupuestos] SET idEstatusPresupuesto = 2 WHERE idPresupuesto= (SELECT idPresupuesto FROM [dbo].[Presupuestos] WHERE idCentroTrabajo = @idCentroTrabajo AND idEstatusPresupuesto = 1) AND idCentroTrabajo = @idCentroTrabajo
	END

	UPDATE [dbo].[Presupuestos] SET idEstatusPresupuesto = 1 WHERE idPresupuesto=@idPresupuesto AND idCentroTrabajo = @idCentroTrabajo

	SELECT 1

END
go

