
-- =============================================
-- Description:	Obtiene las ordenes de servicio en proceso es decir que no esten canceladas o finalizadas
-- =============================================
-- [SEL_ORDENES_ATRASO_SP] @idUsuario = 766, @idContratoOperacion = 3

CREATE PROCEDURE [dbo].[SEL_ORDENES_ATRASO_SP]
	@idUsuario NUMERIC(18,0) = 0,
	@idContratoOperacion NVARCHAR(50) = 0,
	@idRol INT
AS
BEGIN

		DECLARE @tipoUsuario INT
		DECLARE @idOpera INT
		DECLARE @preLibera BIT

		SELECT @tipoUsuario=idCatalogoTipoUsuarios FROM Usuarios WHERE idUsuario=@idUsuario
		/*IF(@tipoUsuario <> 3)
			IF(@tipoUsuario = 9)
				SET @idUsuario = @idUsuario		
			ELSE
				SET @idUsuario = 168*/
		IF(@tipoUsuario = 2)
			SET @idUsuario = 168

		SELECT @idOpera = idOperacion FROM ContratoOperacion WHERE idContratoOperacion = @idContratoOperacion

		SELECT @preLibera = preAprobacion FROM Operaciones WHERE idOperacion = @idOpera

		DECLARE @idCOU NUMERIC(18,0) = [dbo].[GET_CONTRATO_OPERACION_USR_FN](@idUsuario,@idOpera)

		DECLARE @zonasAsignadas TABLE (idZona INT)
		IF(@idRol = 3 OR @idRol = 2)
			BEGIN
				INSERT INTO @zonasAsignadas 
				SELECT idZona FROM [dbo].[GET_ZONAS_USR_FN](@idCOU)
			END
		ELSE IF(@idRol = 9)
			BEGIN
				INSERT INTO @zonasAsignadas
				SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
					JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
					JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
				WHERE EG.estatus=0 AND EZ.estatus=0 
				AND COUG.idContratoOperacionUsuario=@idCOU AND EZ.idContratoOperacion= @idContratoOperacion
			END

	IF (@preLibera = 1)
		BEGIN
			
			DECLARE @ttemp TABLE(NUM INT)
	
			INSERT INTO @ttemp
			SELECT COUNT(consecutivo) AS NUM FROM (
				SELECT 
					O.idOrden AS consecutivo,
					O.numeroOrden,
					O.consecutivoOrden,
					Z.nombre,
					(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes] ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(1,2) 
					AND C.idEstatusCotizacion IN(1,2,3)) costo,
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes] ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(1,2) 
					AND C.idEstatusCotizacion IN(1,2,3)) venta,
					O.comentarioOrden,
					EO.nombreEstatusOrden,
					A.texto,
					HEO.fechaInicial,
					DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
					[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
					DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
				FROM Ordenes O
				JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
				LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
				LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
				JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
				WHERE O.idContratoOperacion = @idContratoOperacion 
				AND O.idEstatusOrden IN (1,2,3,6,7,8)--4,5,
				AND O.idZona IN (select idZona from @zonasAsignadas)) X
			WHERE horasTranscurrido > 24
			
			INSERT INTO @ttemp
			SELECT COUNT(consecutivo) AS NUM FROM (
				SELECT DISTINCT
					O.idOrden AS consecutivo,
					O.numeroOrden,
					O.consecutivoOrden,
					Z.nombre,
					(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes] ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(1,2) 
					AND C.idEstatusCotizacion IN(1,2,3)) costo,
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes] ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(1,2) 
					AND C.idEstatusCotizacion IN(1,2,3)) venta,
					O.comentarioOrden,
					EO.nombreEstatusOrden,
					A.texto,
					HEO.fechaInicial,
					DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
					[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
					DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
				FROM Ordenes O
				JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
				LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
				LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0)
				INNER JOIN Preaprobacion PA ON PA.idCotizacion in (select idCotizacion from Cotizaciones where idOrden = O.idOrden) 
				JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
				WHERE O.idContratoOperacion = @idContratoOperacion 
				AND O.idEstatusOrden IN (4,5)
				AND O.idZona IN (select idZona from @zonasAsignadas)) X
			WHERE horasTranscurrido > 24

			SELECT SUM(NUM) AS NUM FROM @ttemp
		END
	ELSE
		BEGIN
			
			SELECT COUNT(consecutivo) AS NUM FROM (
				SELECT 
					O.idOrden AS consecutivo,
					O.numeroOrden,
					O.consecutivoOrden,
					Z.nombre,
					(SELECT ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes] ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(1,2) 
					AND C.idEstatusCotizacion IN(1,2,3)) costo,
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes] ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(1,2) 
					AND C.idEstatusCotizacion IN(1,2,3)) venta,
					O.comentarioOrden,
					EO.nombreEstatusOrden,
					A.texto,
					HEO.fechaInicial,
					DATEADD (dd, 1, HEO.fechaInicial) AS fecha,
					[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoTranscurrido,
					DATEDIFF (hh, HEO.fechaInicial , GETDATE()) horasTranscurrido 
				FROM Ordenes O
				JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
				LEFT JOIN Partidas..Zona Z ON Z.idZona = O.idZona
				LEFT JOIN Acciones A ON A.idEstatusOrden = O.idEstatusOrden AND A.idOrden = O.idOrden AND A.idEstatusOrden NOT IN(0) 
				JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
				WHERE O.idContratoOperacion = @idContratoOperacion 
				AND O.idEstatusOrden IN (1,2,3,4,5,6,7,8)
				AND O.idZona IN (select idZona from @zonasAsignadas)) X
			WHERE horasTranscurrido > 24
		END

END
	/*IF(EXISTS(
				SELECT COUNT(idAccion) AS NUM
				FROM Acciones A
				JOIN EstatusAccion EA ON EA.idEstatusAccion = A.idEstatusAccion
				INNER JOIN Ordenes O ON A.idOrden = O.idOrden
				WHERE (O.idZona in(SELECT z.idZona 
				FROM ContratoOperacionUsuarioZona z 
				join ContratoOperacionUsuario c on z.idContratoOperacionUsuario = c.idContratoOperacionUsuario  
				where c.idUsuario= @idUsuario)) AND 
					  (O.idContratoOperacion = @idContratoOperacion) AND 
				      (datediff (day,A.fecha,getdate()) >= 0)
					  AND O.idEstatusOrden NOT IN (12, 13)
			))
		BEGIN 
			SELECT COUNT(idAccion) AS NUM
				FROM Acciones A
				JOIN EstatusAccion EA ON EA.idEstatusAccion = A.idEstatusAccion
				INNER JOIN Ordenes O ON A.idOrden = O.idOrden
				WHERE (O.idZona in(SELECT z.idZona 
				FROM ContratoOperacionUsuarioZona z 
				join ContratoOperacionUsuario c on z.idContratoOperacionUsuario = c.idContratoOperacionUsuario  
				where c.idUsuario= @idUsuario)) AND 
					  (O.idContratoOperacion = @idContratoOperacion) AND 
				      (datediff (day,A.fecha,getdate()) >= 0) 
					  AND O.idEstatusOrden NOT IN (12, 13)
		END
	ELSE 
		BEGIN
			SELECT 0 AS NUM
		END */

	-----------------------------------------------------------------------------------
/*	IF(EXISTS(
				SELECT      COUNT(nombrePlan) AS NUM
				FROM        Acciones INNER JOIN
							Ordenes ON Acciones.idOrden = Ordenes.idOrden
				WHERE		(Ordenes.idUsuario = @idUsuario) AND (Ordenes.idContratoOperacion = @idContratoOperacion) AND (datediff (day,Acciones.fechaAccion,getdate()) > 0)
				GROUP BY nombrePlan
			))
		BEGIN 
			SELECT      COUNT(nombrePlan) AS NUM
				FROM        Acciones INNER JOIN
							Ordenes ON Acciones.idOrden = Ordenes.idOrden
				WHERE		(Ordenes.idUsuario = @idUsuario) AND (Ordenes.idContratoOperacion = @idContratoOperacion) AND (datediff (day,Acciones.fechaAccion,getdate()) > 0)
				GROUP BY nombrePlan
		END
	ELSE 
		BEGIN
			SELECT 0 AS NUM
	END */

	--USE [ASEPROT]
go

