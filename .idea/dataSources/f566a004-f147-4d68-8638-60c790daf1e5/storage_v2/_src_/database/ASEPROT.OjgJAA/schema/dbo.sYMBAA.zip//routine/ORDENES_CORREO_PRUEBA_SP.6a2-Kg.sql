
-- ==========================================================================================
-- DATE:   04/10/2016
-- DESC:   Modificacion al Store que devuelve todas las ordenes facturadas
-- [ORDENES_CORREO_PRUEBA_SP]
-- ==========================================================================================
CREATE procedure [dbo].[ORDENES_CORREO_PRUEBA_SP] 

as
begin
DECLARE @Consulta2 TABLE(IdC int identity(1,1), idContratoOperacion INT, idorden INT, Estatus NVARCHAR(100),Operacion NVARCHAR(100),NZ INT, Zona NVARCHAR(100),ZonaPadre NVARCHAR(100),Orden NVARCHAR(100),idZona INT, Proveedor NVARCHAR(max)
,tiempoRetraso NVARCHAR(max), venta float,hojaTrabajo NVARCHAR(max),idUsuariosAsignados NVARCHAR (max),ExisteU INT)

DECLARE @usuariosTemp TABLE(IdU int identity(1,1),idZonaU int, idUsuario INT, correoElectronico VARCHAR(100),nombreCompleto NVARCHAR(100))
INSERT INTO @usuariosTemp
EXEC [dbo].[SEL_ZONAS_CORREO_SP] 

INSERT INTO @Consulta2

SELECT distinct
O.idContratoOperacion
,O.idOrden
,EO.nombreEstatusOrden AS Estatus
,pc.descripcion AS Operacion
,Z.idNivelZona AS NZ
,z.nombre AS Zona
,case when Z.idNivelZona in(3,6) then z.nombre 
else (SELECT nombre FROM [Partidas].[dbo].[Zona] ZON WHERE ZON.idZona=Z.idPadre)
end AS ZonaPadre
,O.numeroOrden AS Orden
,o.idZona
,(SELECT [dbo].[SEL_TALLERES_ORDEN_FN](O.idOrden)) AS Proveedor
,[dbo].[diferenciaTiempo](HEO.fechaInicial) tiempoRetraso
,(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
		FROM [dbo].[Cotizaciones] C 
				INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
				INNER JOIN [dbo].[Ordenes] ORD ON C.idOrden = ORD.idOrden
				INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
		WHERE ORD.idOrden = O.idOrden 
			AND CO.idContratoOperacion = O.idContratoOperacion
			AND CD.idEstatusPartida IN(1,2) 
			AND C.idEstatusCotizacion IN(1,2,3)) venta
,(CASE 
     WHEN ( O.idContratoOperacion IN  (2,4,5,6,7,10,11,12,13,16,17,18,19,20,21,22,23,24,25,26,27,28) and EO.idEstatusOrden > 5 ) THEN o.numeroOrden
                                            ELSE isnull(PO.folio, 'S/N')
											
 END)  as hojaTrabajo
 ,(SELECT [dbo].[SEL_USUARIOS_ORDEN_FN](O.idOrden)) AS idUsuariosAsignados,NULL


FROM Ordenes O
JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
LEFT JOIN PresupuestoOrden PO on O.idOrden =PO.idOrden
INNER JOIN [Partidas].[dbo].[Zona] Z on O.idZona = Z.idZona or O.idOrden = z.idPadre
INNER JOIN [ASEPROT].[dbo].[ContratoOperacion] CO on O.idContratoOperacion =CO.idContratoOperacion
INNER JOIN [PartidAS].[dbo].[Contrato] PC on Co.idContrato= PC.idContrato
JOIN HistorialEstatusOrden HEO ON HEO.idEstatusOrden = O.idEstatusOrden AND HEO.idOrden = O.idOrden
where  O.idEstatusOrden in (1,4,5,6,7,8)  and O.idZona IN(SELECT idZonaU FROM @usuariosTemp) --= @idZona
ORDER BY Estatus ASC

DECLARE @Consulta22 TABLE(Id int identity(1,1),IdC int, idContratoOperacion INT, idorden INT, Estatus NVARCHAR(100),Operacion NVARCHAR(100),NZ INT, Zona NVARCHAR(100),ZonaPadre NVARCHAR(100),Orden NVARCHAR(100),idZona INT, Proveedor NVARCHAR(max)
,tiempoRetraso NVARCHAR(max), venta float,hojaTrabajo NVARCHAR(max),idUsuariosAsignados NVARCHAR (max),ExisteU INT,idU int,IdZonaU int,IdUsuario int,correoElectronico NVARCHAR(100),nombreCompleto NVARCHAR(100))

--select idUsuario,correoElectronico,nombreCompleto from usuarios where  idCatalogoTipoUsuarios = 3 --and nombreCompleto like @nombreZona

insert into @Consulta22
SELECT * FROM @Consulta2 CC
INNER JOIN @usuariosTemp UU ON UU.idZonaU=CC.idZona



--DECLARE @iC int=1, @nC int =(SELECT COUNT(*) FROM @Consulta22),@idUsuariosAsignados VARCHAR(MAX)
--DECLARE @encontrado int,@idUsuario VARCHAR(50)

--WHILE @iC<=@nC
--BEGIN
--SELECT @idUsuario=CAST(idUsuario AS VARCHAR(50)),@idUsuariosAsignados=CAST(idUsuariosAsignados AS VARCHAR(MAX)) FROM @Consulta22 WHERE Id=@iC
--SET @encontrado = CHARINDEX(@idUsuario,@idUsuariosAsignados)  
--UPDATE @Consulta22 SET ExisteU=@encontrado
--WHERE Id=@iC

--SET @iC = @iC +1
--END

update @Consulta22
set correoElectronico= 'jsantibanez@bism.com.mx'


DELETE @Consulta22
WHERE ExisteU=0


---OMITE USUARIOS CCDEMOS
update @Consulta22
set correoElectronico= ''
where IdUsuario in (108,112)

DELETE @Consulta22
WHERE ISNULL(correoElectronico,'')=''



SELECT *
 FROM @Consulta22
 ORDER BY Estatus,Operacion ASC

end
go

