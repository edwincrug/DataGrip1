-- =============================================
-- Author:		Jose Armando Garcia Arroyo
-- Create date: 19/12/2019
-- [SEL_VALIDA_APLICA_PROVISION_SP] 538,123848
-- =============================================
CREATE PROCEDURE [dbo].[SEL_VALIDA_APLICA_PROVISION_SP] 
	@idUsuario INT,
	@idOrden INT

AS
BEGIN

DECLARE @aplicaUsuario INT, @aplicaOrden INT, @permiso INT = 0

SET @aplicaUsuario = CASE WHEN (SELECT COUNT(*) FROM ParametrosGeneralUsuario WHERE IdParametroGeneral=13 AND
					IdUsuario=@idUsuario)>0 THEN 1 ELSE 0 END

SET @aplicaOrden = CASE WHEN (SELECT COUNT(*) FROM ParametrosGeneralOrden PGO 
					INNER JOIN Ordenes O ON O.idOrden = PGO.IdOrden
					INNER JOIN [192.168.20.29].[GAAutoexpress].[DBO].[ADE_ORDSERENC] A_O ON A_O.OTE_ORDENANDRADE COLLATE Modern_Spanish_CI_AS = O.numeroOrden
					WHERE A_O.OTE_GENERA NOT IN ('G') AND PGO.IdParametroGeneral=12 AND PGO.IdOrden=@idOrden)>0 THEN 1 ELSE 0 END

IF @aplicaUsuario = 1 AND @aplicaOrden = 1
BEGIN
SET @permiso = 1
END

SELECT @permiso AS tienePermiso

END

go

