











CREATE VIEW [cobranza].[VwStatusCotizacionAA]
AS
SELECT 
       --DISTINCT
      -- VwCPI.[numeroCotizacion]
      VwCPI.[idCotizacion]
     -- ,VwCPI.[OTE_IDPROVEEDOR]
     -- ,VwCPI.[numFactura] 
	 -- ,VwIPS.[NumFactura] as [NumFacturaF]
	 -- ,VwIPS.[idProveedor]
	  ,CASE WHEN sum(VwIPS.[DeudaDia]) < 0
	   THEN 0
	   ELSE sum(VwIPS.[DeudaDia])
	   END AS [DeudaDia]

  FROM [cobranza].[VwCotizacionProvInvoiceE] VwCPI

INNER JOIN [cobranza].[VwInvoiceProvSaldoDia] VwIPS
        ON VwIPS.[NumFactura] = VwCPI.[numFactura] COLLATE Modern_Spanish_CI_AS
      -- AND VwIPS.[idProveedor] = VwCPI.[OTE_IDPROVEEDOR]

--WHERE VwIPS.[idProveedor] = VwCPI.[OTE_IDPROVEEDOR]

group by VwCPI.[idCotizacion]

go

