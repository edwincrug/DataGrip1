-- [Banorte].[UPD_ESTATUS_ORDENES] 0, 18, '8'
-- [Banorte].[UPD_ESTATUS_ORDENES] 18, ''
CREATE PROC [Banorte].[UPD_ESTATUS_ORDENES]
	@idContratoOperacion numeric(20) = null,
	@xmlOrdenes xml
as
BEGIN
	DECLARE @estatusPrefactura int=9, @estatusEnviadas int =10, @estatusFinalizadas int = 12, @estatusAbonadas int =11

	DECLARE @ordenesIn AS TABLE (id [int] IDENTITY(1,1), numeroOrden nvarchar(max), idEstatusBpro int)
	
	DECLARE @ordenesOut AS TABLE (id [int] IDENTITY(1,1), idOrden int, idEstatusBpro int) 	

	insert into @ordenesIn
		SELECT x.y.value('numeroOrden[1]', 'nvarchar(100)') , x.y.value('idEstatusBpro[1]', 'int') 
		FROM @xmlOrdenes.nodes('ordenes/orden') x(y)   
	
	insert into @ordenesOut
	select distinct O.idOrden,Oin.idEstatusBpro from Ordenes O
		inner join @ordenesIn Oin on O.numeroOrden = Oin.numeroOrden
		inner join DatosCopadeOrden dco on dco.idOrden = O.idOrden
		inner join OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
		inner join OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
	where O.idContratoOperacion=@idContratoOperacion and (Oin.idEstatusBpro=3 and o.idEstatusOrden not in (12,13)) 
		  or (Oin.idEstatusBpro=4 and o.idEstatusOrden not in (11,13)) or(Oin.idEstatusBpro=2 and 
		  o.idEstatusOrden not in (10,13))or(Oin.idEstatusBpro=1 and o.idEstatusOrden not in (9,13))
		  and o.idOrden not in (select ordenesFuera.idOrden from (
				select distinct o.idOrden,count(a.idEstatusBpro) count from Ordenes O
					inner join @ordenesIn a on a.numeroOrden=O.numeroOrden
					inner join DatosCopadeOrden dco on dco.idOrden = O.idOrden
					inner join OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
					inner join OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
				where O.idContratoOperacion=@idContratoOperacion
				group by o.idorden having count(a.idEstatusBpro)>1) ordenesFuera)
				
	Declare @id int, @count int, @idEstatuscopade int, @idOrden int, @cant int=0
	Set @id=1
	select @count=count(*)from @ordenesOut
	while @id<=@count
	begin 		
		select @idEstatuscopade=idEstatusBpro, @idOrden=idOrden from @ordenesOut where id=@id
		
		if (@idEstatuscopade=1)--Pre Factura 9
		begin		
			set @cant=@cant +1;
			update Ordenes set idEstatusOrden=@estatusPrefactura where idOrden=@idOrden
			update HistorialEstatusOrden set fechaFinal=GETDATE() where idHistorialEstatusOrden=
			(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)

			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=@estatusPrefactura)
			begin
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,@estatusPrefactura,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end		
		end
		if (@idEstatuscopade=2) --Enviadas 10
		begin
			set @cant=@cant +1;
			update Ordenes set idEstatusOrden=@estatusEnviadas where idOrden=@idOrden
			update HistorialEstatusOrden set fechaFinal=GETDATE() where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
			
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=@estatusEnviadas)
			begin
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,@estatusEnviadas,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end		
		end
		if (@idEstatuscopade=3)--Finalizadas 12
		begin	 
			set @cant=@cant +1;
			update Ordenes set idEstatusOrden=@estatusFinalizadas where idOrden=@idOrden
			update HistorialEstatusOrden set fechaFinal=GETDATE() where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
				
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=@estatusFinalizadas)
			begin 
				insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,@estatusFinalizadas,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
			end					
		end 
		if (@idEstatuscopade=4)
		begin
			set @cant=@cant +1;
			update Ordenes set idEstatusOrden=@estatusAbonadas where idOrden=@idOrden
			update HistorialEstatusOrden set fechaFinal=GETDATE() where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
			
			if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=@estatusAbonadas)
			begin 
			insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
				select top 1 @idOrden,@estatusAbonadas,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc			
			end 
		end

		select @id=@id+1
	end
	select @cant as actualizadas
END
go

grant execute, view definition on Banorte.UPD_ESTATUS_ORDENES to DevOps
go

