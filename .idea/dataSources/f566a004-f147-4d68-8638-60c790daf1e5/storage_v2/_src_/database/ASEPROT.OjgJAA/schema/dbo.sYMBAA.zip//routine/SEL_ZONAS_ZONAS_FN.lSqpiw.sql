
-- =============================================
-- Author:		Sahirely Yam
-- Create date: 21 08 2017
-- SELECT [dbo].[SEL_ZONAS_ZONAS_FN](122)
-- =============================================
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_ZONAS_ZONAS_FN](@idUsuario INT)

RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @talleres NVARCHAR(MAX) = ' ';
	--DECLARE @nombreComercial NVARCHAR(MAX) = ' ';
	DECLARE @idZona NVARCHAR(MAX) = ' ';
	DECLARE @Result NVARCHAR(MAX) = ' ';

	DECLARE contact_cursor CURSOR FOR
	--select distinct nombreComercial 
	--from Cotizaciones C
	--inner join Partidas..Proveedor P on P.idProveedor = C.idTaller
	--where idOrden = @idOrden


	SELECT Z.idZona
		   --Z.nombre,
		   --NZ.idNivelZona, 
		   --NZ.etiqueta, 
		   --Z.idPadre
	FROM ContratoOperacionUsuarioZona UZ 
		INNER JOIN ContratoOperacionUsuario C ON UZ.idContratoOperacionUsuario = C.idContratoOperacionUsuario  
		INNER JOIN Partidas.dbo.Zona Z ON UZ.idZona = Z.idZona
		INNER JOIN Partidas.dbo.nivelZona NZ  ON NZ.idNivelZona = Z.idNivelZona
	where c.idUsuario= 122
		AND Z.estatus = 1 
		--AND  C.idContratoOperacion = @idContratoOperacion


	OPEN contact_cursor  
	FETCH NEXT FROM contact_cursor INTO @talleres
	WHILE @@FETCH_STATUS = 0  
		BEGIN 

		--SET @talleres =(SELECT idTaller FROM Taller where idTaller=@idTaller)
		SET @idZona = @idZona + @talleres + ','

		FETCH NEXT FROM contact_cursor INTO @talleres
		END  
	CLOSE contact_cursor  
	DEALLOCATE contact_cursor

	IF((@idZona IS NOT NULL) AND @idZona != '')
		SET @Result= SUBSTRING (@idZona, 1, Len(@idZona) - 1 )

	RETURN @Result;
	
END
go

