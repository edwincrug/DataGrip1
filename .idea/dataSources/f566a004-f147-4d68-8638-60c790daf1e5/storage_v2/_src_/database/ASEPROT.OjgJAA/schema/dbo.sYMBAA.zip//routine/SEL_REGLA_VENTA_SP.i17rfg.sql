
-- ==========================================================================================
-- Author:		Edgar Mendoza
-- Create date: 12/03/2020
-- Description:	
-- Test: [dbo].[SEL_REGLA_VENTA_SP] 
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_REGLA_VENTA_SP]
    @idContratoOperacion INT
AS   
	BEGIN
		IF EXISTS(
					SELECT 
						idContratoOperacion
					FROM [dbo].[Regla_Venta]
					WHERE idContratoOperacion = @idContratoOperacion
					AND activo = 1
				)
			BEGIN
				SELECT cast(1 as bit) respuesta
			END

		ELSE
			BEGIN
				SELECT cast(0 as bit) respuesta
			END
		
	END
go

