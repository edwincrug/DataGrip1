-- [SEL_HISTORICO_ORDEN] '65740013643'
/*
no esta
10177325284
SELECT idOrden FROM Ordenes WHERE numeroOrden = '03-9299-34402'
si esta
13058706652
SELECT idOrden FROM Ordenes WHERE numeroOrden = '13058706652'
*/
--[dbo].[SEL_HISTORICO_ORDEN] '03-9299-34402'

CREATE PROCEDURE [dbo].[SEL_HISTORICO_ORDEN] --'1163635310831'
	@numOrden varchar(50)
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @idEstatusNA int =15

	DECLARE @totalEstatus INT  = (SELECT COUNT(*) FROM  [dbo].[HistorialEstatusOrden] HO 
												  INNER JOIN [dbo].Ordenes AS Ord ON HO.idOrden = Ord.idOrden
												  WHERE Ord.numeroOrden = @numOrden and HO.idEstatusOrden not in (@idEstatusNA,16))
   DECLARE @idOrden INT

   SET @idOrden = (SELECT idOrden FROM Ordenes WHERE numeroOrden = @numOrden)

	IF (@totalEstatus <= 9)
	BEGIN
		SET @totalEstatus = 9
	END

	/*SELECT HO.idEstatusOrden,
		   EO.nombreEstatusOrden, 
		   HO.idUsuario,
		   Us.nombreCompleto,  
		   DATEADD(hh, 5, HO.fechaInicial) as fecha,  
		   convert(float,100) / convert(float,@totalEstatus) AS PorcentajeTotal
	FROM [dbo].[HistorialEstatusOrden] AS HO 
		INNER JOIN [dbo].Ordenes AS Ord ON HO.idOrden = Ord.idOrden
		INNER JOIN [dbo].[EstatusOrdenes] AS EO ON EO.idEstatusOrden = HO.idEstatusOrden 
		INNER JOIN [dbo].[Usuarios] AS Us ON HO.idUsuario = Us.idUsuario 
	WHERE Ord.numeroOrden =  @numOrden*/

	SELECT  --HO.idEstatusOrden,
				case 
			when HO.idEstatusOrden = 1 then 1 
			when HO.idEstatusOrden = 2 then 2 
			when HO.idEstatusOrden = 3 then 3
			when HO.idEstatusOrden = 4 then 4
			when HO.idEstatusOrden = 5 then 5
			when HO.idEstatusOrden = 6 then 6
			when HO.idEstatusOrden = 7 then 7
			when HO.idEstatusOrden = 8 then 8
			--when HO.idEstatusOrden = 14 then 9
			when HO.idEstatusOrden = 9 then 9
			when HO.idEstatusOrden = 10 then 10
			when HO.idEstatusOrden = 11 then 11
			when HO.idEstatusOrden = 12 then 12
			when HO.idEstatusOrden = 13 then 13 
			end idEstatusOrden,
           EO.nombreEstatusOrden,
           HO.idUsuario,
           Us.nombreCompleto,
		   	case 
			when HO.idEstatusOrden = 1 then Ord.idOrden 
			when HO.idEstatusOrden = 2 then Ord.idOrden
			when HO.idEstatusOrden = 3 then Ord.idOrden
			when HO.idEstatusOrden = 4 then Ord.idOrden
			when HO.idEstatusOrden = 5 then Ord.idOrden
			when HO.idEstatusOrden = 6 then Ord.idOrden
			when HO.idEstatusOrden = 7 then Ord.idOrden
			when HO.idEstatusOrden = 8 then Ord.idOrden
			--when HO.idEstatusOrden = 14 then 9
			when HO.idEstatusOrden = 9 then Ord.idOrden
			when HO.idEstatusOrden = 10 then Ord.idOrden
			--when HO.idEstatusOrden = 11 then HO.idUsuario
			when HO.idEstatusOrden = 11 AND Ord.numeroOrden NOT IN(SELECT O.numeroOrden FROM [OrdenGlobalAbono] OGA join OrdenAgrupada OA on OA.numero = OGA.numeroOrdenGlobal COLLATE SQL_Latin1_General_CP1_CI_AS join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade join Ordenes o on o.idOrden = dco.idOrden) AND ORD.idEstatusOrden <= 11 then 0 
			when HO.idEstatusOrden = 11 AND Ord.numeroOrden IN(SELECT O.numeroOrden FROM [OrdenGlobalAbono] OGA join OrdenAgrupada OA on OA.numero = OGA.numeroOrdenGlobal COLLATE SQL_Latin1_General_CP1_CI_AS join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade join Ordenes o on o.idOrden = dco.idOrden) OR ORD.idEstatusOrden = 12 then Ord.idOrden
			when HO.idEstatusOrden = 12 then Ord.idOrden
			when HO.idEstatusOrden = 13 then Ord.idOrden
			end idOrden,   
           --Ord.idOrden,
           HO.fechaInicial as fecha,
		   ISNULL(DATEDIFF(DAY, HO.fechaInicial, HO.fechaFinal),0) as dias
    FROM [dbo].[EstatusOrdenes] AS EO
        inner JOIN [dbo].[HistorialEstatusOrden] AS HO  ON EO.idEstatusOrden = HO.idEstatusOrden 
        left JOIN [dbo].Ordenes AS Ord ON HO.idOrden = Ord.idOrden
        left JOIN [dbo].[Usuarios] AS Us ON HO.idUsuario = Us.idUsuario 
    WHERE Ord.idOrden =  @idOrden AND EO.idEstatusOrden not in (13,14, @idEstatusNA,16)
union 
select 
             -- EO.idEstatusOrden,
	   				case 
			when EO.idEstatusOrden = 1 then 1 
			when EO.idEstatusOrden = 2 then 2 
			when EO.idEstatusOrden = 3 then 3
			when EO.idEstatusOrden = 4 then 4
			when EO.idEstatusOrden = 5 then 5
			when EO.idEstatusOrden = 6 then 6
			when EO.idEstatusOrden = 7 then 7
			when EO.idEstatusOrden = 8 then 8
			--when EO.idEstatusOrden = 14 then 9
			when EO.idEstatusOrden = 9 then 9
			when EO.idEstatusOrden = 10 then 10
			when EO.idEstatusOrden = 11 then 11
			when EO.idEstatusOrden = 12 then 12
			when EO.idEstatusOrden = 13 then 13 
			end idEstatusOrden,
       EO.nombreEstatusOrden, 
       0 idUsuario,
       '' nombreCompleto, 
       0 idOrden,
       '' fecha,
	   '' as dias
    FROM [dbo].[EstatusOrdenes] AS EO
    WHERE EO.idEstatusOrden not in (select idEstatusOrden from [HistorialEstatusOrden] where idOrden = @idOrden)
   -- AND EO.idEstatusOrden > (select TOP 1 idEstatusOrden from [HistorialEstatusOrden] where idOrden = @idOrden ORDER BY idEstatusOrden DESC)
	AND EO.idEstatusOrden  not in (13,14,@idEstatusNA,16)
END
go

