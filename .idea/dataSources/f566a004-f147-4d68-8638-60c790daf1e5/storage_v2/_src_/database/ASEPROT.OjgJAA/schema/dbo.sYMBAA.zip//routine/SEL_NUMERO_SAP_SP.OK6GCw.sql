

-- ==========================================================================================
-- Author:		
-- Create date: 24/10/2019
-- Description:	Store que obtiene las copades sin asignación

-- [SEL_NUMERO_SAP_SP] 57,124
-- [SEL_NUMERO_SAP_SP] 57,85
-- ==========================================================================================

CREATE PROC [dbo].[SEL_NUMERO_SAP_SP]
	@idContratoOperacion numeric(18,0)
	,@idTerminal numeric(18,0) = 0
	AS

		DECLARE @idPadre INT

		select @idPadre = idpadre from Partidas..zona where idzona = @idTerminal

	--For Test of Performance 
	SET transaction isolation level read uncommitted

	IF @idPadre = 0
		BEGIN

			SELECT 
			U.numeroEconomico Economico,
			O.numeroOrden NumeroOrden,
			ISNULL(CS.numeroSap,'S/N') NumeroSap,
			pp.Partida,
			pp.NoParte,
			pp.Descripcion,
			cd.Cantidad,
			CD.venta VentaUnitaria,
			EO.nombreEstatusOrden Estatus,
			PPR.razonSocial Proveedor,
			pzp.nombre Gerencia,--Gerencia
			pz.nombre TAD--Terminal
			FROM Ordenes O
			LEFT JOIN CodigoSap CS ON CS.idOrden = O.idOrden
			INNER JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
			INNER JOIN Partidas..Zona PZ ON PZ.idZona = O.idZona
			INNER JOIN Partidas..Zona PZP ON PZP.idZona = PZ.idPadre
			INNER JOIN Unidades U ON O.idUnidad = U.idUnidad
			INNER JOIN Cotizaciones C ON C.idOrden = O.idOrden and c.idEstatusCotizacion not in(4,5)
			LEFT JOIN Partidas..Proveedor PPR ON PPR.idProveedor = C.idTaller
			INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion and cd.idEstatusPartida not in(3,4)
			INNER JOIN Partidas..Partida PP ON PP.idPartida = CD.idPartida
			WHERE O.idContratoOperacion = @idContratoOperacion 
			and PZP.idZona = @idTerminal
			order by Gerencia, TAD, o.IdOrden
	
	END
	ELSE
		BEGIN

			SELECT 
			PZ.idzona,
			PZP.idzona,
			U.numeroEconomico Economico,
			O.numeroOrden NumeroOrden,
			ISNULL(CS.numeroSap,'S/N') NumeroSap,
			pp.Partida,
			pp.NoParte,
			pp.Descripcion,
			cd.Cantidad,
			CD.venta VentaUnitaria,
			EO.nombreEstatusOrden Estatus,
			PPR.razonSocial Proveedor,
			pzp.nombre Gerencia,--Gerencia
			pz.nombre TAD--Terminal
			FROM Ordenes O
			LEFT JOIN CodigoSap CS ON CS.idOrden = O.idOrden
			INNER JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
			INNER JOIN Partidas..Zona PZ ON PZ.idZona = O.idZona
			INNER JOIN Partidas..Zona PZP ON PZP.idZona = PZ.idPadre
			INNER JOIN Unidades U ON O.idUnidad = U.idUnidad
			INNER JOIN Cotizaciones C ON C.idOrden = O.idOrden and c.idEstatusCotizacion not in(4,5)
			LEFT JOIN Partidas..Proveedor PPR ON PPR.idProveedor = C.idTaller
			INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion and cd.idEstatusPartida not in(3,4)
			INNER JOIN Partidas..Partida PP ON PP.idPartida = CD.idPartida
			WHERE O.idContratoOperacion = @idContratoOperacion 
			and PZ.idZona = @idTerminal 
			order by Gerencia, TAD, o.IdOrden
	
	END
	--select * from Partidas..Zona where nombre = 'centro'
go

