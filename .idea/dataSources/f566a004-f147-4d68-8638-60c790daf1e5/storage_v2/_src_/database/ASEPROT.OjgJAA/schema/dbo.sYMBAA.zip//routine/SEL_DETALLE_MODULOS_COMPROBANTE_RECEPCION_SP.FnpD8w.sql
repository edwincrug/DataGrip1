--- [SEL_DETALLE_MODULOS_COMPROBANTE_RECEPCION_SP] 7,'01-2110144-98'
CREATE PROCEDURE [dbo].[SEL_DETALLE_MODULOS_COMPROBANTE_RECEPCION_SP]
@idCatalogoModuloComprobante INT,
@numeroOrden AS VARCHAR(250)
AS
BEGIN
/*
SELECT 
	CaDeMoCo.idCatalogoModuloComprobante,
	CaMoCoRe.entradaDatos,
	CaDeMoCo.idCatalogoDetalleModuloComprobante	,
	CaDeMoCo.nombreCatalogoDetalleModuloComprobante,
	CaDeMoCo.rutaImagen,
	CaDeMoCo.consecutivo	
 FROM [dbo].[CatalogoModuloComprobanteRecepcion] CaMoCoRe
INNER JOIN [dbo].[CatalogoDetalleModuloComprobante] CaDeMoCo ON CaDeMoCo.idCatalogoModuloComprobante = CaMoCoRe.idCatalogoModuloComprobante
WHERE CaDeMoCo.idCatalogoModuloComprobante = @idCatalogoModuloComprobante
*/

declare @dataTable as table

(
	idCatalogoModuloComprobante int,
	entradaDatos int,
	idCatalogoDetalleModuloComprobante int,
	nombreCatalogoDetalleModuloComprobante  varchar(250),
	rutaImagen varchar(250),
	consecutivo int
)

insert into @dataTable 

SELECT 
	CaDeMoCo.idCatalogoModuloComprobante,
	CaMoCoRe.entradaDatos,
	CaDeMoCo.idCatalogoDetalleModuloComprobante	,
	CaDeMoCo.nombreCatalogoDetalleModuloComprobante,
	CaDeMoCo.rutaImagen,
	CaDeMoCo.consecutivo	
 FROM [dbo].[CatalogoModuloComprobanteRecepcion] CaMoCoRe
INNER JOIN [dbo].[CatalogoDetalleModuloComprobante] CaDeMoCo ON CaDeMoCo.idCatalogoModuloComprobante = CaMoCoRe.idCatalogoModuloComprobante
WHERE CaDeMoCo.idCatalogoModuloComprobante = @idCatalogoModuloComprobante



	IF(@idCatalogoModuloComprobante = 7)
	BEGIN
			DECLARE @dataTableImages AS TABLE(directorio  VARCHAR(250))

				INSERT INTO @dataTableImages
					SELECT directorio descripcionCompleta				
					FROM TipoUnidadRecepcion 
					WHERE   idtipounidad  IN
					(
							SELECT idtipounidad  FROM Partidas..Unidad  PU WHERE idUnidad  in
							(
									SELECT CASE WHEN EXISTS
										(
												SELECT  1 
												FROM Ordenes o INNER JOIN  Unidades u 
												ON  o.idUnidad=u.idUnidad 
												WHERE numeroOrden = @numeroOrden  
										)
									THEN
										(	
											SELECT  idtipounidad 
											FROM Ordenes o INNER JOIN  Unidades u 
											ON  o.idUnidad=u.idUnidad 
											WHERE numeroOrden = @numeroOrden 
										)
									ELSE
										999
									END
							) 			
					)

	
	
					UPDATE @dataTable 
					SET rutaImagen = 'http://189.204.141.193:5101/img/'+ directorio + rutaImagen 
					FROM  @dataTableImages as dti  
					WHERE idCatalogoModuloComprobante = 7
					

	END

SELECT  * FROM  @dataTable 

END

go

