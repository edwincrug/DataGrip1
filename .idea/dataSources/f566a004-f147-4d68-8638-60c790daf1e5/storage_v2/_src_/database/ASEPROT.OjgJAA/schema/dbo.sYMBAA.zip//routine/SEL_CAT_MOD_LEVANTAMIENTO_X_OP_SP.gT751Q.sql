-- ==========================================================================================
-- DATE:   04/10/2016
-- DESC:   Modificacion al Store que CATALOGOS DE MODULO DE LEVANTAMIENTO POR OPERACION
-- [SEL_CAT_MOD_LEVANTAMIENTO_X_OP_SP] '1,2,3,4,5,6,7,8,9,10,11,12'
-- ==========================================================================================
create PROCEDURE [dbo].[SEL_CAT_MOD_LEVANTAMIENTO_X_OP_SP] (
	@idsCatalogoModuloLevantamiento varchar(100)
)
as
begin
	DECLARE @Ids_Cat_MLevantamiento table(Id numeric(18,0))

	set @idsCatalogoModuloLevantamiento = @idsCatalogoModuloLevantamiento+',';
	with cte as
	(
		select SUBSTRING(@idsCatalogoModuloLevantamiento,1,charindex(',',@idsCatalogoModuloLevantamiento,1)-1) as val, SUBSTRING(@idsCatalogoModuloLevantamiento,charindex(',',@idsCatalogoModuloLevantamiento,1)+1,len(@idsCatalogoModuloLevantamiento)) as rem 
		UNION ALL
		select SUBSTRING(a.rem,1,charindex(',',a.rem,1)-1)as val, SUBSTRING(a.rem,charindex(',',a.rem,1)+1,len(A.rem)) 
		from cte a where LEN(a.rem)>=1
	) insert into @Ids_Cat_MLevantamiento select val from cte


	SELECT 
		idCatalogoModuloLevantamientoDetalle,
		nombreModuloLevantamientoDetalle,
		consecutivo
	FROM CatalogoModuloLevantamientoDetalle 
	WHERE idCatalogoModuloLevantamiento IN 
	(SELECT Id from @Ids_Cat_MLevantamiento)
	
end
go

