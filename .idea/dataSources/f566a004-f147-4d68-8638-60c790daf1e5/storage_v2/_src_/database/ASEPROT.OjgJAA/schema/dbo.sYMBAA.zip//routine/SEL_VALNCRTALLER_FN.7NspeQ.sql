 --SELECT * from [dbo].[SEL_VALNCRTALLER_FN]('6364', 13)
CREATE FUNCTION [dbo].[SEL_VALNCRTALLER_FN] ( @numSiniestro nvarchar(max), @idMarca int)
returns @values table(montoNCR DECIMAL(10,2), porcentajeNCR float)
as 
begin
	--chevrolet, suzuki, mitsu, chr
	declare @montoNCR DECIMAL(10,2)
	declare @porcentajeNCR float

	IF @idMarca =1 --NISSAN
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAZM_Zaragoza].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAZM_Zaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAZM_Zaragoza].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END 
	ELSE IF @idMarca=2 --GM
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAAS_Satelite].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAS_Satelite].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAAS_Satelite].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END 
	ELSE IF @idMarca=3 --Ford
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAAAF_Body].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAAF_Body].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAAAF_Body].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=4 --Suzuki
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAAU_Universidad].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAU_Universidad].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAAU_Universidad].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=5 --Hyundai
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAHyundai].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAHyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAHyundai].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END	
	ELSE IF @idMarca=7 --Honda
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAHondaZaragoza].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAHondaZaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAHondaZaragoza].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=8 --Volkswagen
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.31].[GADLA_VW].[dbo].SER_ORDEN SO
		inner join [192.168.20.31].[GADLA_VW].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.31].[GADLA_VW].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=9 --Seat
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.31].[GADLA_SEAT].[dbo].SER_ORDEN SO
		inner join [192.168.20.31].[GADLA_SEAT].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.31].[GADLA_SEAT].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=11 --Chevrolet
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAAA_Azcapo].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAA_Azcapo].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAAA_Azcapo].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=12 --Chrysler
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAAutoAngarTlahuac].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAutoAngarTlahuac].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAAutoAngarTlahuac].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'

		if (@porcentajeNCR is null or @porcentajeNCR=0)
		begin 
			select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(ISNULL(BMOV9.MOV_HABER,0)),0)
			from [192.168.20.29].GAAutoAngarTepepan.[dbo].SER_ORDEN SO
			inner join [192.168.20.29].GAAutoAngarTepepan.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
			inner join [192.168.20.29].GAAutoAngarTepepan.dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012020 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''			
			where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
		end
	END
	ELSE IF @idMarca=13 --Hyundai Cam
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAVC_Hyundai].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAVC_Hyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAVC_Hyundai].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=16 --Mitsubishi
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].[GAAutoAngarMitsu].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAutoAngarMitsu].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].[GAAutoAngarMitsu].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idMarca=22 --Nissan Abasto
	BEGIN 
		select @porcentajeNCR=max(SO.ORE_porcentajeNCR), @montoNCR=ISNULL(SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ),0) 
		from [192.168.20.29].GAZM_Abasto.[dbo].SER_ORDEN SO
		inner join [192.168.20.29].GAZM_Abasto.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  
		inner join [192.168.20.29].GAZM_Abasto.dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=AV.VTE_DOCTO and CC.CCP_TIPODOCTO='APNCBON'
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO =''
		left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
		where (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	
	insert into @values (montoNCR,porcentajeNCR) values( @montoNCR, @porcentajeNCR)

	--select montoNCR, porcentajeNCR from @values
	return 
end
 go

