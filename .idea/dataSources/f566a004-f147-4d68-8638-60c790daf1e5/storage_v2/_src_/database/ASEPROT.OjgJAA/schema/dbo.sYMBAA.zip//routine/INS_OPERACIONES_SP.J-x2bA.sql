
--
-- =============================================
-- Author:		Gibran
-- Description:	Inserta una nueva Operación
-- [INS_OPERACIONES_SP]@idCatalogoTipoOperacion = 1  ,@manejoUtilidad = 0,@porcentajeUtilidad = 0.0,@geolocalizacion = 0,@estatusOperacion = 1 ,@formaPago = 1, @presupuesto = 1, @centros='CD,MX,', @idOperacion=6, @idcentros ='3,4,'
-- =============================================

 CREATE PROCEDURE [dbo].[INS_OPERACIONES_SP]
 @idCatalogoTipoOperacion  int = NULL
,@manejoUtilidad  int = NULL
,@porcentajeUtilidad decimal(18, 4)
,@geolocalizacion bit = NULL
,@tiempoAsignado int = NULL
,@estatusOperacion  int = NULL
,@formaPago nvarchar(MAX) = NULL
,@presupuesto int = NULL
,@centros nvarchar(MAX) = NULL
,@idOperacion INT = 0
,@idcentros nvarchar(MAX) = NULL
,@verificacion int = NULL
,@comentarioCotizacion int = NULL
,@sustituto int = NULL
,@codigoCita int = NULL
,@levantamientoInicial int = NULL
,@apariencia int = NULL
,@documentoCobranza int = NULL

AS
BEGIN

DECLARE @nombreCentro nvarchar(50),
		@idCentroTrabajo nvarchar(50),
		@lnuPosComa int,
		@lnuPosComa2 int

	

		IF NOT EXISTS (SELECT idOperacion FROM Operaciones WHERE idOperacion = @idOperacion)
			BEGIN
				INSERT INTO [Operaciones] (
									   [idCatalogoTipoOperacion]
									  ,[manejoUtilidad]
									  ,[porcentajeUtilidad]
									  ,[geolocalizacion]
									  ,[tiempoAsignado]
									  ,[idEstatusOperacion]
									  ,[formaPago]
									  ,[presupuesto]
									  ,[verificacionVehicular]
									  ,[comentarioCotizacion]
									  ,[sustituto]
									  ,[codigoCita]
									  ,[levantamientoInicial]
									  ,[apariencia]
									  ,[documentoCobranza])
								VALUES( 
								 @idCatalogoTipoOperacion  
								,@manejoUtilidad 
								,@porcentajeUtilidad 
								,@geolocalizacion
								,@tiempoAsignado 
								,@estatusOperacion  
								,@formaPago
								,@presupuesto
								,@verificacion
								,@comentarioCotizacion
								,@sustituto
								,@codigoCita
								,@levantamientoInicial
								,@apariencia
								,@documentoCobranza)
					SET @idOperacion = @@IDENTITY 
				END
			ELSE
				BEGIN
					UPDATE Operaciones
						SET 
							idCatalogoTipoOperacion = @idCatalogoTipoOperacion,
							manejoUtilidad = @manejoUtilidad,
							porcentajeUtilidad = @porcentajeUtilidad,
							geolocalizacion = @geolocalizacion,
							tiempoAsignado = @tiempoAsignado,
							idEstatusOperacion = @estatusOperacion,
							formaPago = @formaPago,
							presupuesto = @presupuesto,
							verificacionVehicular = @verificacion,
							comentarioCotizacion = @comentarioCotizacion,
							sustituto = @sustituto,
							codigoCita = @codigoCita,
							levantamientoInicial = @levantamientoInicial,
							apariencia = @apariencia,
							documentoCobranza = @documentoCobranza
						WHERE idOperacion=@idOperacion;
				END


				IF @presupuesto =1
					BEGIN
						WHILE LEN(@centros) > 0
							BEGIN 
								SET @lnuPosComa = CHARINDEX(',', @centros) -- Busca el caracter a separador
								SET @lnuPosComa2 = CHARINDEX(',', @idcentros)
								IF (@lnuPosComa = 0)
									BEGIN 
										SET @nombreCentro = @centros
										SET @centros = ''

										SET @idCentroTrabajo = @idcentros
										SET @idcentros = '' 
									END
									ELSE 
									BEGIN
										SET @nombreCentro = SUBSTRING(@centros, 1, @lnuPosComa - 1)
										SET @centros = SUBSTRING(@centros, @lnuPosComa + 1, LEN(@centros))
										PRINT @centros
										SET @idCentroTrabajo = SUBSTRING(@idcentros, 1, @lnuPosComa2 - 1)
										SET @idcentros = SUBSTRING(@idcentros, @lnuPosComa2 + 1, LEN(@idcentros))
										PRINT @idcentros
										print convert (int, @idCentroTrabajo)
											IF NOT EXISTS(SELECT idCentroTrabajo FROM CentroTrabajos WHERE idCentroTrabajo = convert (int,@idCentroTrabajo))
												BEGIN
													print 'ENTRA'
														INSERT INTO [CentroTrabajos] (
															[nombreCentroTrabajo]
															,[idOperacion]
															,[extra1])
														VALUES(
														
														@nombreCentro 
														,@idOperacion
														,null)
												END
											ELSE
												BEGIN
													PRINT convert (int,@idCentroTrabajo)
													UPDATE [CentroTrabajos]
														SET nombreCentroTrabajo = @nombreCentro
														WHERE idCentroTrabajo = convert (int,@idCentroTrabajo)
												END
									END

							END
			
					
					END

			
				SELECT @idOperacion AS idOperacion
END

go

