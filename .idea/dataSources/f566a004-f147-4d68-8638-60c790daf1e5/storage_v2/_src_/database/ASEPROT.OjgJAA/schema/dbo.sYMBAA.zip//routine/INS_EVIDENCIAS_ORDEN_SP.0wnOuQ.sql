

CREATE PROCEDURE [dbo].[INS_EVIDENCIAS_ORDEN_SP]
@nombreEvidencia VARCHAR(150) ,
@descripcionEvidencia VARCHAR(150),
@rutaEvidencia VARCHAR(150)='a',
@idOrden NUMERIC(18,0),
@idCotizacion NUMERIC(18,0)=0,
@idUsuario		INT = 0
AS
BEGIN
	--DECLARE @idOrden NUMERIC(18,0)
	--SET @idOrden = (SELECT idOrden FROM Ordenes WHERE numeroOrden = @numeroOrden )
	
	INSERT INTO [Evidencias] (nombreEvidencia, descripcionEvidencia, rutaEvidencia, idOrdenServicio, idCotizacion, fecha, idUsuario)
	VALUES (@nombreEvidencia, @descripcionEvidencia, @rutaEvidencia, @idOrden, @idCotizacion, GETDATE(), @idUsuario)
	SELECT @@IDENTITY AS idEvidencia;
	
END
go

