

CREATE VIEW [GPS].[LastReportUnit]
AS
   Select max(Fecha_loc) as [Fecha_Loc_Last],        
		 idUnidad
  from    [Casanova].[dbo].[Localizacion]
  group by idUnidad
  --order by idUnidad
go

grant select, view definition on GPS.LastReportUnit to DevOps
go

