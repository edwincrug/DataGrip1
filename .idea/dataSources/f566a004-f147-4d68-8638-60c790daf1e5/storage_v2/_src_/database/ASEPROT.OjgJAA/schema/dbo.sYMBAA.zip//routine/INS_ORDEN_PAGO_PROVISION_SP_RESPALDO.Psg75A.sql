
-- [INS_ORDEN_PAGO_PROVISION_SP] 109,12
-- select * from FacturaCotizacion
CREATE PROC [dbo].[INS_ORDEN_PAGO_PROVISION_SP_RESPALDO]
@idOrden NUMERIC(18,0),
@idUsuario NUMERIC(18,0),
@idOperacion NUMERIC(18,0),
@isProduction NUMERIC(18,0)

AS
BEGIN
	DECLARE @idCotizacion NUMERIC(18,0)
	DECLARE @max NUMERIC(18,0)
    DECLARE @fecha NVARCHAR(30)
	DECLARE @numFactura nvarchar(50)
	DECLARE @UUID nvarchar(50)
	DECLARE @XMLFactura nvarchar(MAX)
	DECLARE @totalFactura decimal(18, 2)

	BEGIN
	  --Actualiza el trabajo de estatus y inserta en BPRO
		IF NOT EXISTS ( SELECT C.idCotizacion, FC.idCotizacion 
						FROM  Cotizaciones C 
						LEFT JOIN FacturaCotizacion FC ON C.idCotizacion = FC.idCotizacion 
						WHERE idOrden = @idOrden AND FC.idCotizacion IS NULL AND C.idEstatusCotizacion IN(1,2,3))  
			BEGIN 
				-- SELECT * FROM AprobacionProvision
				IF NOT EXISTS(SELECT 1 FROM AprobacionProvision WHERE idOrden = @idOrden)
					BEGIN
						INSERT INTO AprobacionProvision VALUES (@idOrden, GETDATE(), @idUsuario, 0)
					END

				SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden
				SELECT @max = MAX(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden
				SELECT @fecha=fechaCreacionOden FROM Ordenes WHERE idOrden = @idOrden
					 WHILE(@idCotizacion <= @max)
						BEGIN	
							SELECT @numFactura=numFactura, @UUID=uuid, @XMLFactura=xml, @totalFactura=total FROM FacturaCotizacion WHERE idCotizacion=@idCotizacion
							EXEC INS_ORDEN_ENCABEZADO_SP @idCotizacion, @fecha, @numFactura, @UUID, @XMLFactura, @totalFactura, @idUsuario, @idOperacion, @isProduction
							SELECT @idCotizacion = MIN(idCotizacion) FROM Cotizaciones WHERE idOrden = @idOrden AND idCotizacion > @idCotizacion
						END
					 SELECT 1 Proceso
			END
		ELSE 
			BEGIN
				SELECT 0 Proceso
			END 	
	END
END
go

