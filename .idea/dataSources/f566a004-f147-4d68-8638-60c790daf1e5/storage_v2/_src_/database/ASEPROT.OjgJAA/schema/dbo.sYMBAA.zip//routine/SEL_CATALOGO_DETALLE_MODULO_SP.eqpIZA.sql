-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 25/05/2017
-- Description:	Obtiene el catalogo de detalle del modulo operativo
-- SEL_CATALOGO_DETALLE_MODULO_SP 3,2
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_CATALOGO_DETALLE_MODULO_SP]
	@idModulo INT,
	@idOperacion INT
AS
BEGIN
	
  SELECT CDM.idCatalogoDetalleModulo, 
		 CDM.nombreDetalleModulo,
		 CASE  WHEN  (SELECT DM.idDetalleModulo FROM DetalleModulo DM WHERE DM.idCatalogoDetalleModulo = CDM.idCatalogoDetalleModulo AND DM.idOperacion = @idOperacion) IS NULL THEN 'false' ELSE 'true' END as verificar,
		 (SELECT DM2.idDetalleModulo FROM DetalleModulo DM2 WHERE DM2.idCatalogoDetalleModulo = CDM.idCatalogoDetalleModulo AND DM2.idOperacion = @idOperacion) idDetalleModulo
	FROM CatalogoDetalleModulo CDM
	--LEFT JOIN DetalleModulo DM ON DM.idCatalogoDetalleModulo = CDM.idCatalogoDetalleModulo
	INNER JOIN CatalogoModulos CM ON CDM.idCatalogoModulos = CM.idCatalogoModulos
	INNER JOIN Modulos M ON CM.idCatalogoModulos = M.idCatalogoModulo
	WHERE 
	CDM.activo = 1 
	AND	 M.idModulo = @idModulo
	--AND	DM.idOperacion = @idOperacion

END
--4
--select * from [dbo].[DetalleModulo]
--idDetalleModulo	idModulo	idCatalogoDetalleModulo	activo
--1	17	7	1

go

