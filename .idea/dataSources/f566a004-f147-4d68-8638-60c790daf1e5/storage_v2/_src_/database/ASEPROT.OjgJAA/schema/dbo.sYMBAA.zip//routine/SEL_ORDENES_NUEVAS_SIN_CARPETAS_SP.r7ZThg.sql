-- =============================================
-- Author:		Sahirely Yam
-- Create date: 25 10 2017
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ORDENES_NUEVAS_SIN_CARPETAS_SP]
	
AS
BEGIN
	
	SET NOCOUNT ON;

	select idOrden from Ordenes where idEstatusOrden in (1,2)
END
go

