
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 31/05/2017
-- Description:	Devuelve los resultados del cuadrante de Ordenes por Cobrar en el Dashboard
-- ==========================================================================================
--[dbo].[SEL_DASHBOARD_ORDENES_COBRAR_SP] 20,null,538
CREATE PROCEDURE [dbo].[SEL_DASHBOARD_ORDENES_COBRAR_SP]
    @idOperacion NUMERIC(20,0), 
    @idZona NUMERIC( 20,0 ) = 0,
	@idUsuario NUMERIC(18,0) = NULL,
	@isProduction int = 1
AS
	BEGIN

	IF @idOperacion in (1,2)
	BEGIN
		EXECUTE [SEL_DASHBOARD_ORDENES_COBRAR_GATPARTSTOLUCA_SP] @idOperacion,@idZona,@idUsuario,@isProduction
	END
	ELSE IF @idOperacion = 16
	BEGIN
		EXECUTE [dbo].[SEL_DASHBOARD_ORDENES_COBRAR_ETGLOBAL_SP] @idOperacion,@idZona,@idUsuario,@isProduction
	END
	ELSE IF @idOperacion=28 -- Banorte
	BEGIN
		EXECUTE [SEL_DASHBOARD_ORDENES_COBRAR_BANORTE_SP] @idOperacion,@idZona,@idUsuario,@isProduction
	END
	ELSE IF @idOperacion IN (56,60) -- Banorte
	BEGIN
		EXECUTE [SEL_DASHBOARD_ORDENES_COBRAR_GATPartsArrenda_SP] @idOperacion,@idZona,@idUsuario,@isProduction
	END
	ELSE IF @idOperacion IN (51,52,54,55)
	BEGIN
		EXECUTE [SEL_DASHBOARD_ORDENES_COBRAR_GATPartsASE_SP] @idOperacion,@idZona,@idUsuario,@isProduction
	END
	ELSE
	BEGIN
		EXECUTE [SEL_DASHBOARD_ORDENES_COBRAR_GAAutoExpress_SP] @idOperacion,@idZona,@idUsuario,@isProduction
	END
	END
go

