CREATE FUNCTION [dbo].[concatena_partidas_fn]
(
	@idProveedor INT
)
RETURNS VARCHAR(500)
AS
BEGIN
	
	DECLARE @aux INT = 1
	DECLARE @cadenaAux VARCHAR(500) = ''
	DECLARE @idPartida NUMERIC(18,0) = 0 
	
	DECLARE @partidas TABLE(id INT IDENTITY(1,1), idPartida NUMERIC(18,0)) 	
	
	INSERT INTO @partidas
	SELECT PAR.idPartida FROM Partidas..ProveedorPartida PAR
	JOIN Partidas..ProveedorCotizacion PACOT ON PAR.idProveedorCotizacion = PACOT.idProveedorCotizacion 
	WHERE PACOT.idProveedor = @idProveedor
	--SELECT idPartida FROM [Partidas].[dbo].[ProveedorPartida] WHERE idProveedorCotizacion = @idProveedor
	
	WHILE(@aux <= (SELECT MAX(id) FROM @partidas))
	BEGIN

		SELECT @idPartida = idPartida FROM @partidas WHERE id = @aux 
		
		SET @cadenaAux = @cadenaAux + ',{"idPartida":"' + CONVERT(VARCHAR(10), @idPartida) + '"}'
		SET @aux = @aux + 1
	END				
	
	/*
	IF @idProveedor = 29
	SET @cadenaAux =  '[{"idPartida":"4"},{"idPartida":"3"}]'

	IF @idProveedor = 30
	SET @cadenaAux ='[{"idPartida":"5"},{"idPartida":"6"},{"idPartida":"11"},{"idPartida":"12"},{"idPartida":"13"}]'

	IF @idProveedor = 31
	SET @cadenaAux ='[{"idPartida":"1"},{"idPartida":"6"},{"idPartida":"7"},{"idPartida":"11"},{"idPartida":"12"},{"idPartida":"13"}]'
	RETURN @cadenaAux
	*/
	
	RETURN '[' + SUBSTRING(@cadenaAux,2,500) + ']'

END
go

