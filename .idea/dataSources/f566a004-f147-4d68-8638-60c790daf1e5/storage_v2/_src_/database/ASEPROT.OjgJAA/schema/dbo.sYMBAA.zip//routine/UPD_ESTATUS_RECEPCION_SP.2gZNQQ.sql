
-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03/06/2017
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ESTATUS_RECEPCION_SP]-- 829, 41282
@idUsuario INT,
@idOrden INT

AS
BEGIN
		IF NOT EXISTS(SELECT 1 FROM [dbo].[Ordenes] WHERE idOrden = @idOrden AND idEstatusOrden=3)
		BEGIN
			DECLARE @idestatusanterior int = (select [idEstatusOrden] from [dbo].[Ordenes] where idOrden = @idOrden )
			
			if (@idestatusanterior != 3)
			begin
				update [HistorialEstatusOrden]
				set fechaFinal=getdate()
				where idOrden=@idOrden and idEstatusOrden = @idestatusanterior

				UPDATE Ordenes
				SET idEstatusOrden=3
				WHERE idOrden = @idOrden

				insert into [HistorialEstatusOrden] values (@idOrden,3, GETDATE(),NULL, @idUsuario)
			end
		END
				IF NOT EXISTS(SELECT 1 FROM [dbo].[DocumentosOrdenes] WHERE idOrden = @idOrden)
				BEGIN
					DECLARE @ruta NVARCHAR(700) = 'http:\\192.168.20.9:5301\orden\' + CONVERT(VARCHAR(50), @idOrden) + '\comprobanteRecepcion\ComprobanteRecepcion.pdf'
					INSERT INTO DocumentosOrdenes VALUES(@ruta, GETDATE(), @idOrden, 1, NULL)
				END

		IF @@ROWCOUNT > 0
			BEGIN
				SELECT 1 AS RES

			END

END
go

