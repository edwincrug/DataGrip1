CREATE FUNCTION [dbo].[fnZonaXZona]
(    
      @idZona INT
)
RETURNS @zonas TABLE (
      idZona INT
)
AS
BEGIN
DECLARE @idCliente INT, @idNivelZona INT,@orden INT, @totalNiveles INT

SELECT @idNivelZona=idNivelZona FROM Partidas..Zona
where idZona=@idZona

SELECT @idCliente=idCliente,@orden =orden from Partidas..NivelZona
where idNivelZona=@idNivelZona

SELECT @totalNiveles=COUNT(*) from Partidas..NivelZona
where idCliente=@idCliente

DECLARE @zonasC TABLE (idZona INT)

INSERT INTO @zonasC
SELECT idZona FROM Partidas..Zona WHERE idZona=@idZona

WHILE @orden<=@totalNiveles
BEGIN

INSERT INTO @zonasC
SELECT Z.idZona FROM Partidas..Zona Z
WHERE Z.idPadre IN(
SELECT Zs.idZona FROM @zonasC Zs
)

SET @orden = @orden + 1
END 

INSERT INTO @zonas
SELECT DISTINCT idZona FROM @zonasC

RETURN
END
go

