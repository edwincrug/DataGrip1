
--test 
-- EXEC [GPS].[SEL_GPS_LOCATION_SP]	 28916 ,534
CREATE PROCEDURE [GPS].[SEL_GPS_LOCATION_SP]	
	@idOrden numeric(18,0),
	@idUsuario numeric(18,0)
AS
BEGIN
	
	declare @Vin Nvarchar(50)
	declare @lat Nvarchar(50)
	declare @long Nvarchar(50)


	select @vin = vin
	from dbo.Ordenes O
	inner join Unidades U
	   on O.idUnidad = U.idUnidad
	where O.idOrden = @idOrden

	Select 'vin'   
		,@vin


    select 
	   top 1
	       @lat = lat, @long = long
	  from [Casanova].[dbo].[Localizacion] l

	 inner join [Casanova].[dbo].[Unidad] U
	        on L.idunidad = U.[idUnidad]

	where U.[vin] = @vin
	  order by [fecha_loc] desc

   
	  select @lat as [lat], @long as [long]


END
go

grant execute, view definition on GPS.SEL_GPS_LOCATION_SP to DevOps
go

