/*
JAGA
FUNCION PARA SABER QUE BACKGROUD SE LE APLICA A LAS FILAS
21/09/2018
*/
CREATE FUNCTION [dbo].[fnColorBackgroudFila](@idOrden INT, @numeroOrden VARCHAR(50), @idContratoOperacion INT)
Returns VARCHAR(MAX)
AS
BEGIN 
--DECLARE @idOrden INT INT = 72256
--		, @numeroOrden VARCHAR(50) = '57-PMX11630-1263'
--		, @idContratoOperacion INT = 57

--SET DATEFORMAT DMY

DECLARE @color VARCHAR(25)='', @fechaCreacion DATETIME, @fechaAplica DATETIME,@ordenAplica VARCHAR(50),@idColor	INT

SELECT @fechaCreacion = fechaCreacionOden FROM Ordenes WHERE idOrden=@idOrden

SELECT @fechaAplica=fechaAplica FROM Ordenescolores WHERE idContratoOperacion=@idContratoOperacion AND aplicaFecha=1 AND estatus=1 
				AND CAST(CONVERT(VARCHAR(25),@fechaCreacion,103) AS DATETIME)<=CAST(CONVERT(VARCHAR(25),fechaAplica,103) AS DATETIME)
SELECT @ordenAplica=numeroOrden FROM Ordenescolores WHERE idContratoOperacion=@idContratoOperacion AND numeroOrden=@numeroOrden AND estatus=1

IF (@ordenAplica IS NOT NULL)
BEGIN
	SET @idColor = (SELECT TOP 1 idColor FROM Ordenescolores WHERE idContratoOperacion=@idContratoOperacion AND numeroOrden=@numeroOrden AND estatus=1)
	SELECT @color = codigoCSS from dbo.ColoresBackground WHERE idColoresBackground = @idColor
END

IF (@fechaAplica IS NOT NULL AND @ordenAplica IS NULL)
BEGIN
	SET @idColor = (SELECT TOP 1 idColor FROM Ordenescolores WHERE idContratoOperacion=@idContratoOperacion AND aplicaFecha=1 AND estatus=1 AND @fechaCreacion<=fechaAplica)
	SELECT @color = codigoCSS from dbo.ColoresBackground WHERE idColoresBackground = @idColor
END

RETURN @color
END
go

