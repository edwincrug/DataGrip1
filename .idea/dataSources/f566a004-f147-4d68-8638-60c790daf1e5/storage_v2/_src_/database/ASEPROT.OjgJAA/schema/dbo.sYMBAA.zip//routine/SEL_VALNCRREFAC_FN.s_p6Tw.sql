 --select * from ASEPROT.dbo.[SEL_VALNCRREFAC_FN](64779, 1)
  --select * from ASEPROT.dbo.[SEL_VALNCRREFAC_FN](64779, 1)
   --select * from ASEPROT.dbo.[SEL_VALNCRREFAC_FN](64779, 12)
CREATE FUNCTION [dbo].[SEL_VALNCRREFAC_FN] ( @idOrden int, @idMarca int)
returns @values table(montoNCR DECIMAL(10,2), porcentajeNCR float)
as 
begin
	--chevrolet, suzuki, mitsu, chr
	declare @montoNCR DECIMAL(10,2)
	declare @porcentajeNCR float
	IF @idMarca =1 --NISSAN
	BEGIN 
		select @porcentajeNCR=Max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAZM_Zaragoza].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAZM_Zaragoza].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END 
	ELSE IF @idMarca=2 --GM
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAAS_Satelite].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAAS_Satelite].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END 
	ELSE IF @idMarca=3 --Ford
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAAAF_Viga].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAAAF_Viga].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=4 --Suzuki
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAAU_Universidad].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAAU_Universidad].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=5 --Hyundai
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAHyundai].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAHyundai].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=6 --CRA
	BEGIN 	
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.31].[GACRA_Cuautitlan].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.31].[GACRA_Cuautitlan].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=7 --Honda
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAHondaZaragoza].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAHondaZaragoza].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=8 --Volkswagen
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.31].[GADLA_VW].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.31].[GADLA_VW].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=9 --Seat
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.31].[GADLA_SEAT].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.31].[GADLA_SEAT].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=11 --Chevrolet
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAAA_Azcapo].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAAA_Azcapo].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=12 --Chrysler
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAAutoAngarTlahuac].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAAutoAngarTlahuac].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)

		if (@porcentajeNCR=0 or @porcentajeNCR is null)
		begin			
			select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(BMOV9.MOV_HABER) from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
				inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
				inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
				inner join [192.168.20.29].GAAutoAngarTepepan.DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
				inner join [192.168.20.29].GAAutoAngarTepepan.dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
				left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012020 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
				inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
			where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
		end
	END
	ELSE IF @idMarca=13 --Hyundai Cam
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAVC_Hyundai].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAVC_Hyundai].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END
	ELSE IF @idMarca=16 --Mitsubishi
	BEGIN 
		select @porcentajeNCR=max(PP.pre_porcentajeNCR), @montoNCR=SUM(case when BMOV9.MOV_HABER is null then ISNULL(BMOV8.MOV_HABER,0.0) else ISNULL(BMOV9.MOV_HABER,0.0) end ) 
		from RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC 
			inner join ASEPROT.dbo.Cotizaciones C on SOC.idCotizacionSISCO = C.idCotizacion
			inner join [192.168.20.29].PortalRefacciones.dbo.pre_pedidoref PP on PP.pre_idcotizacion = SOC.idCotizacion
			inner join [192.168.20.29].[GAAutoAngarMitsu].DBO.[PAR_PEDMOST] AS p on PP.pre_pedidobpro = P.PMM_NUMERO and P.PMM_IDCLIENTE = PP.pre_idcliente
			inner join [192.168.20.29].[GAAutoAngarMitsu].dbo.VIS_CONCAR01 CC on CC.CCP_IDDOCTO=P.PMM_REF2 and CC.CCP_TIPODOCTO='APNCBON'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012019 BMOV9 on BMOV9.MOV_OBSERVA =CC.CCP_REFER and BMOV9.MOV_TIPODOCTO ='' AND BMOV9.MOV_CONCEPTO like '%'+CC.CCP_IDDOCTO+'%'
			left join [192.168.20.29].GAAutoExpressBanorte.dbo.con_movdet012018 BMOV8 on BMOV8.MOV_OBSERVA =CC.CCP_REFER and BMOV8.MOV_TIPODOCTO =''
			inner join ASEPROT.Banorte.ConfiguracionProvision CP on CP.idMarca= @idMarca
		where SOC.idOrden=@idOrden and convert(date, CC.CCP_FECHOPE, 103) >= convert(date, CP.fechaCambio)
	END		
	
	insert into @values (montoNCR,porcentajeNCR) values( @montoNCR, @porcentajeNCR)

	--select montoNCR, porcentajeNCR from @values
	return 
end
 go

