-- select [fnAplicaPorcentajeIntegra]
CREATE FUNCTION [dbo].[fnAplicaPorcentajeIntegra](@monto decimal(18,2), @IdOperacion int,@aux int)

RETURNS DECIMAL(18,2)
AS
BEGIN

DECLARE @montoRetorno decimal(18,2), @porcentaje decimal(18,2)

SELECT @porcentaje=pg.Valor FROM ParametrosGeneral pg
inner join ParametrosGeneralOperacion pgo on pgo.IdParametroGeneral = pgo.IdParametroGeneral
WHERE pg.IdParametroGeneral IN(6) AND pgo.idOperacion=@IdOperacion

IF ISNULL(@porcentaje,0)>0
BEGIN
	SET @montoRetorno = @monto + (@monto * @porcentaje)
END
ELSE
BEGIN
	SET @montoRetorno = @monto
END

RETURN @montoRetorno
END
go

