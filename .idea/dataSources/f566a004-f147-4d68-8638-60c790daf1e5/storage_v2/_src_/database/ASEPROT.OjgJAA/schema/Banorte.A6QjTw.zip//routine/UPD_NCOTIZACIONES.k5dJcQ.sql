
-- =============================================
-- Author:		<YJH>
-- Create date: <09/04/19>
-- Description:	<Inserta o Actualiza las cotizaciones>
/*
[Banorte].[UPD_NCOTIZACIONES] @idTipoUnidad=186, @idContratoUnidad=748, @idUsuarioPartidas = 59, @partidas = '<parte><idTipoPartida>1</idTipoPartida><partida>REVESTIMIE                                        </partida><marca>8</marca><noParte>6K4867011CSHDZ             </noParte><descripcion>REVESTIMIE                                        </descripcion><precioCompraR>2575.1</precioCompraR><precioCompraMano>2575.1</precioCompraMano><precioVenta>2085.83</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>2</idCotizacion><idCotizacionSisco>0</idCotizacionSisco><editCotizacion>false</editCotizacion></parte><parte><idTipoPartida>1</idTipoPartida><partida> PASSAT 2013                                      </partida><marca>8</marca><noParte>1325M3JGP62                </noParte><descripcion> PASSAT 2013                                      </descripcion><precioCompraR>17.42</precioCompraR><precioCompraMano>17.42</precioCompraMano><precioVenta>14.11</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>2</idCotizacion><idCotizacionSisco>0</idCotizacionSisco><editCotizacion>false</editCotizacion></parte><parte><idTipoPartida>1</idTipoPartida><partida> LITERATURA PASSAT 2016                           </partida><marca>8</marca><noParte>561012762AA
      </noParte><descripcion> LITERATURA PASSAT 2016                           </descripcion><precioCompraR>215.62</precioCompraR><precioCompraMano>215.62</precioCompraMano><precioVenta>174.65</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>2</idCotizacion><idCotizacionSisco>0</idCotizacionSisco><editCotizacion>false</editCotizacion></parte><parte><idTipoPartida>1</idTipoPartida><partida>REVESTIMIE                                        </partida><marca>8</marca><noParte>6K4867011CSHDZ             </noParte><descripcion>REVESTIMIE                                        </descripcion><precioCompraR>2575.1</precioCompraR><precioCompraMano>2575.1</precioCompraMano><precioVenta>2085.83</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>1</idCotizacion><idCotizacionSisco>54809</idCotizacionSisco><editCotizacion>false</editCotizacion><borrar>true</borrar></parte><parte><idTipoPartida>1</idTipoPartida><partida> PASSAT 2013                                      </partida><marca>8</marca><noParte>1325M3JGP62                </noParte><descripcion> PASSAT 2013                                      </descripcion><precioCompraR>17.42</precioCompraR><precioCompraMano>17.42</precioCompraMano><precioVenta>14.11</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>1</idCotizacion><idCotizacionSisco>54809</idCotizacionSisco><editCotizacion>false</editCotizacion><borrar>true</borrar></parte><parte><idTipoPartida>1</idTipoPartida><partida> LITERATURA PASSAT 2016                           </partida><marca>8</marca><noParte>561012762AA                </noParte><descripcion> LITERATURA PASSAT 2016                           </descripcion><precioCompraR>215.62</precioCompraR><precioCompraMano>215.62</precioCompraMano><precioVenta>174.65</precioVenta><tiempo>00:00:00</tiempo><cantidad>1</cantidad><isTemporal>true</isTemporal><isBackorder>false</isBackorder><idCotizacion>1</idCotizacion><idCotizacionSisco>54809</idCotizacionSisco><editCotizacion>false</editCotizacion><borrar>true</borrar></parte>',
@idUsuario= 710, @idEstatusCotizacion=3, @idTipoCotizacion=1, @idOrden= 43991
*/
-- =============================================
CREATE PROCEDURE [Banorte].[UPD_NCOTIZACIONES]
	@idTipoUnidad int,
	@idContratoUnidad int, 
	@idUsuarioPartidas int,
	@partidas XML, 	
	@idOrden int,
	@idUsuario  NUMERIC(18,0),
	@idEstatusCotizacion int,
	@idTipoCotizacion int
AS
BEGIN
	BEGIN TRY
		BEGIN TRAN TranInsertaOrden
		-- DECLARO VARIABLES
		DECLARE @idEspecialidad INT = 20,
		@idClasificacion INT = 1, 
		@idSubClasificacion INT =1, 
		@taller INT, 
		@idBproTaller INT,
		@idTipoOrdenServicio NUMERIC(18,0)=1,
		@idEstatusPartida INT = 2,
		@len INT, 
		@lenBKO INT,
		@consecutivoCotizacion INT, 
		@idCotizacion INT, 
		@idCotizacionNew INT, 
		@idAutorizacionCot INT, 
		@idC INT=1,
		@idCS INT,
		@numeroOrden NVARCHAR(100)
		SELECT TOP 1 @idCotizacion = x.value('idCotSCO[1]', 'INT')
		FROM @partidas.nodes('//parte') partidas(x)

		SELECT 
			@taller= idTaller, 
			@idBproTaller= idBproProveedor, 
			@idTipoOrdenServicio = idCatalogoTipoOrdenServicio,
			@numeroOrden=numeroOrden
		FROM ASEPROT.dbo.Ordenes WHERE idOrden = @idOrden	

		DECLARE @cotizacionesIns as table (idCotizacion int, numeroCotizacion nvarchar(20), idCotizacionS int, tipo bit)		

		DECLARE @partes as TABLE (idUnidad int , idTipoPartida int, partida nvarchar (50), marca nvarchar (200), noParte nvarchar (200),
			 descripcion nvarchar (max), idContratoUnidad int, precioCompraR decimal(18,2), precioCompraMano decimal(18,2), 
			 precioVenta decimal(18,2), tiempo nvarchar(8), isBackorder int, idPartida int, idCotizacion int, cantidad int,
			 idCotizacionSisco int, editCotizacion bit);
		-- INSERTA PARTES
		INSERT INTO @partes 
			(idUnidad, idTipoPartida, partida, marca, noParte, descripcion, idContratoUnidad, precioCompraR, precioCompraMano, precioVenta,
			 tiempo, isBackorder, idCotizacion, cantidad, idCotizacionSisco, editCotizacion)
		   SELECT 
		    @idTipoUnidad, x.value('idTipoPartida[1]', 'INT'), x.value('partida[1]', 'nvarchar(50)'),
			x.value('marca[1]', 'nvarchar(200)'), x.value('noParte[1]', 'nvarchar(200)'), x.value('descripcion[1]', 'nvarchar(max)'), 		
			@idContratoUnidad, x.value('precioCompraR[1]', 'decimal(18,2)'), x.value('precioCompraMano[1]', 'decimal(18,2)'),
			x.value('precioVenta[1]', 'decimal(18,2)'), x.value('tiempo[1]', 'nvarchar(7)'), x.value('isBackorder[1]', 'bit'),
			x.value('idCotizacion[1]', 'int'), x.value('cantidad[1]', 'int'), x.value('idCotizacionSisco[1]', 'int'), 
			x.value('editCotizacion[1]', 'bit')
		   FROM @partidas.nodes('//parte') partidas(x)

		--1. Inserta partidas
		MERGE Partidas.dbo.Partida AS target  
		USING @partes AS source 
		ON (target.noParte = source.noParte and target.idUnidad = source.idUnidad)
		WHEN NOT MATCHED THEN  
			INSERT (idUnidad, idTipoPartida, idEspecialidad, idPartidaClasificacion, idPartidaSubClasificacion, partida, marca, noParte, 
			        descripcion, foto, instructivo, estatus)  
			VALUES (source.idUnidad, source.idTipoPartida, @idEspecialidad, @idClasificacion, @idSubClasificacion, source.partida,
				    source.marca, source.noParte, source.descripcion,'', '', 1);
		--2. Busca ID partidas
		UPDATE P SET P.idPartida = PP.idPartida FROM @partes AS P
			INNER JOIN Partidas.dbo.Partida AS PP ON P.noParte = PP.noParte and P.idUnidad = PP.idUnidad
			INNER JOIN ASEPROT.dbo.CotizacionDetalle CD ON CD.idPartida = PP.idPartida
		WHERE CD.idCotizacion=@idCotizacion
		
		--3. Inserta ContratoPartida
		MERGE Partidas.dbo.ContratoPartida AS target  
		USING @partes AS source 
		ON (target.idPartida = source.idPartida and target.idContratoUnidad = source.idContratoUnidad and source.idPartida <> 0 )
		WHEN NOT MATCHED THEN  
			INSERT (idContratoUnidad, idPartida, venta, fecha, idUsuario, precio1, precio2, precio3, precio4, precio5, precio6, precio7,
			        precioMano, precioRefaccion, precioLubricante, tiempo, precio7Respaldo)
			VALUES (source.idContratoUnidad, source.idPartida, source.precioVenta, GETDATE(), @idUsuarioPartidas, source.precioCompraR,
			        source.precioCompraR, source.precioCompraR, source.precioCompraR, source.precioCompraR, source.precioCompraR, 
					source.precioCompraR, source.precioCompraMano, source.precioCompraR, 0.00, CAST(source.tiempo AS TIME), 0.00);

	-- 4. Inserta cotizaciones y/o actualiza cotizaciones
	-- ESTA PARTE YA ESTA VALIDADO EN CODIGO
	--IF((SELECT count(*) FROM ASEPROT.dbo.CotizacionDetalle WHERE idCotizacion = @idCotizacion)=0)
	--	BEGIN 
	--		-- borrar relaciones sisre
	--		INSERT INTO @cotizacionesIns 
	--		SELECT idCotizacion, numeroCotizacion, consecutivoCotizacion, 0 
	--		FROM ASEPROT.dbo.Cotizaciones WHERE idCotizacion = @idCotizacion

	--		DELETE FROM ASEPROT.dbo.AutorizacionCotizacion WHERE idCotizacion= @idCotizacion
	--		DELETE FROM ASEPROT.dbo.HistorialEstatusCotizacion WHERE idCotizacion=@idCotizacion
	--		--DELETE FROM ASEPROT.dbo.CotizacionDetalle WHERE idCotizacion = @idCotizacion
	--		DELETE FROM ASEPROT.dbo.Cotizaciones WHERE idCotizacion = @idCotizacion
					
	--		SELECT @idCS = idCotizacion FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion WHERE idCotizacionSISCO= @idCotizacion
				
	--		DELETE FROM RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion WHERE idCotizacion = @idCS
	--		DELETE FROM RefaccionMultiMarca.Operacion.CotizacionDetalle WHERE idCotizacion = @idCS								
	--		DELETE FROM RefaccionMultiMarca.Operacion.Cotizacion WHERE idCotizacion = @idCS				
	--	END
	--ELSE
	--	BEGIN
			IF EXISTS(SELECT TOP 1 isBackorder FROM @partes WHERE isBackorder=0)
				BEGIN
					SELECT @len = COUNT(distinct noParte) FROM @partes 
					SELECT @lenBKO = COUNT(distinct noParte) FROM @partes WHERE isBackorder=0
					IF(@len = @lenBKO)
						BEGIN

							MERGE ASEPROT.dbo.CotizacionDetalle AS target  			
							USING (SELECT precioCompraR, cantidad, precioVenta, idPartida, precioCompraMano, editCotizacion from @partes)
							 AS SOURCE (precioCompraR, cantidad, precioVenta, idPartida, precioCompraMano, editCotizacion)
							ON (target.idPartida = source.idPartida and target.idCotizacion = @idCotizacion)
							WHEN MATCHED THEN   
								UPDATE SET costo = source.precioCompraR, venta=source.precioVenta, cantidad=source.cantidad, solicitadasOrg= source.cantidad				
							WHEN NOT MATCHED BY SOURCE and (target.idCotizacion = @idCotizacion) THEN		
								DELETE
							WHEN NOT MATCHED THEN  
								INSERT (idCotizacion, costo, cantidad, venta, idPartida, idEstatusPartida, rechazadas, solicitadasOrg, precioLista)  
								VALUES (@idCotizacion, source.precioCompraR, source.cantidad, source.precioVenta, source.idPartida, @idEstatusPartida, 0,
										source.cantidad, source.precioCompraMano);

							--INSERT INTO @cotizacionesIns 
							--SELECT idCotizacion, numeroCotizacion, consecutivoCotizacion, 0 
							--FROM ASEPROT.dbo.Cotizaciones WHERE idCotizacion = @idCotizacion
						END
					ELSE
						BEGIN
							IF EXISTS(SELECT TOP 1 consecutivoCotizacion FROM ASEPROT.dbo.Cotizaciones WHERE idOrden = @idOrden)			
								BEGIN
									SET @consecutivoCotizacion = (SELECT TOP 1 consecutivoCotizacion FROM ASEPROT.dbo.Cotizaciones WHERE idOrden = @idOrden ORDER BY consecutivoCotizacion DESC) +1
								END
							ELSE
								BEGIN
									SET @consecutivoCotizacion = 1
								END			
					
							INSERT INTO ASEPROT.dbo.Cotizaciones 
								(fechaCotizacion, idTaller, idUsuario, idEstatusCotizacion, idOrden, numeroCotizacion, consecutivoCotizacion,
								idCatalogoTipoOrdenServicio, idPreorden, idBproProveedor, idTipoCotizacion) 
							VALUES
								(GETDATE(), @taller, @idUsuario, @idEstatusCotizacion, @idOrden, @numeroOrden+'-'+CONVERT (varchar(5), @consecutivoCotizacion),
								@consecutivoCotizacion,@idTipoOrdenServicio,null, @idBproTaller, @idTipoCotizacion)
		
							SET @idCotizacionNew = (SELECT IDENT_CURRENT('ASEPROT.dbo.Cotizaciones'))
		
							WHILE (@idC <= @idEstatusCotizacion)
									BEGIN 
										INSERT INTO ASEPROT.dbo.HistorialEstatusCotizacion (fechaInicial,idCotizacion,idUsuario,idEstatusCotizacion)
										VALUES (GETDATE(), @idCotizacionNew, @idUsuario, @idC)			
					
										SET @idC = @idC + 1;
									END 

							INSERT INTO ASEPROT.dbo.AutorizacionCotizacion (fechaNotificacion, fechaAutorizacion, idCotizacion)
							VALUES (GETDATE(), GETDATE(), @idCotizacionNew)

							INSERT INTO ASEPROT.dbo.CotizacionDetalle(idCotizacion,costo,cantidad,venta,idPartida,idEstatusPartida,rechazadas,solicitadasOrg,idCotizacionDetalleOrg,idCotizacionOrg,precioLista,diasEntrega,idMotivoDevolucion,recibidas)
							SELECT @idCotizacionNew,costo,cantidad,venta,idPartida,idEstatusPartida,rechazadas,solicitadasOrg,idCotizacionDetalleOrg,idCotizacionOrg,precioLista,diasEntrega,idMotivoDevolucion,recibidas 
							FROM ASEPROT.dbo.CotizacionDetalle WHERE idCotizacion = @idCotizacion AND idPartida IN(SELECT idPartida FROM @partes WHERE isBackorder=0)

							MERGE ASEPROT.dbo.CotizacionDetalle AS target  			
							USING (SELECT precioCompraR, cantidad, precioVenta, idPartida, precioCompraMano, editCotizacion from @partes)
							 AS SOURCE (precioCompraR, cantidad, precioVenta, idPartida, precioCompraMano, editCotizacion)
							ON (target.idPartida = source.idPartida and target.idCotizacion = @idCotizacion)
							WHEN MATCHED THEN   
								UPDATE SET costo = source.precioCompraR, venta=source.precioVenta, cantidad=source.cantidad, solicitadasOrg= source.cantidad				
							WHEN NOT MATCHED BY SOURCE and (target.idCotizacion = @idCotizacion) THEN		
								DELETE
							WHEN NOT MATCHED THEN  
								INSERT (idCotizacion, costo, cantidad, venta, idPartida, idEstatusPartida, rechazadas, solicitadasOrg, precioLista)  
								VALUES (@idCotizacion, source.precioCompraR, source.cantidad, source.precioVenta, source.idPartida, @idEstatusPartida, 0,
										source.cantidad, source.precioCompraMano);

							DELETE DAC FROM ASEPROT.dbo.DetalleAutorizacionCotizacion DAC
							JOIN ASEPROT.dbo.CotizacionDetalle CD ON CD.idCotizacionDetalle = DAC.idCotizacionDetalle
							WHERE CD.idCotizacion = @idCotizacion AND CD.idPartida IN(SELECT idPartida FROM @partes WHERE isBackorder=0) 			

							DELETE FROM ASEPROT.dbo.CotizacionDetalle WHERE idCotizacion = @idCotizacion AND idPartida IN(SELECT idPartida FROM @partes WHERE isBackorder=0)

							--INSERT INTO @cotizacionesIns 
							--SELECT idCotizacion, numeroCotizacion, consecutivoCotizacion, 0 
							--FROM ASEPROT.dbo.Cotizaciones WHERE idCotizacion = @idCotizacionNew

						END
				END
			ELSE
				BEGIN
			
					MERGE ASEPROT.dbo.CotizacionDetalle AS target  			
					USING (SELECT precioCompraR, cantidad, precioVenta, idPartida, precioCompraMano, editCotizacion from @partes)
					 AS SOURCE (precioCompraR, cantidad, precioVenta, idPartida, precioCompraMano, editCotizacion)
					ON (target.idPartida = source.idPartida and target.idCotizacion = @idCotizacion)
					WHEN MATCHED THEN   
						UPDATE SET costo = source.precioCompraR, venta=source.precioVenta, cantidad=source.cantidad, solicitadasOrg= source.cantidad				
					WHEN NOT MATCHED BY SOURCE and (target.idCotizacion = @idCotizacion) THEN		
						DELETE
					WHEN NOT MATCHED THEN  
						INSERT (idCotizacion, costo, cantidad, venta, idPartida, idEstatusPartida, rechazadas, solicitadasOrg, precioLista)  
						VALUES (@idCotizacion, source.precioCompraR, source.cantidad, source.precioVenta, source.idPartida, @idEstatusPartida, 0,
								source.cantidad, source.precioCompraMano);

					--INSERT INTO @cotizacionesIns 
					--SELECT idCotizacion, numeroCotizacion, consecutivoCotizacion, 1
					--FROM ASEPROT.dbo.Cotizaciones WHERE idCotizacion = @idCotizacion
				END
		--END

		SELECT C.idCotizacion, C.numeroCotizacion, C.consecutivoCotizacion, 1
		FROM ASEPROT.dbo.Cotizaciones C 
		WHERE C.idOrden=@idOrden

		SELECT C.idCotizacion,P.noParte 
		FROM ASEPROT.dbo.Cotizaciones C 
		JOIN ASEPROT.dbo.CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
		JOIN Partidas.dbo.Partida P on P.idPartida = CD.idPartida
		WHERE C.idOrden=@idOrden

		COMMIT TRAN TranInsertaOrden			

	END TRY
	BEGIN CATCH
		ROLLBACK TRAN TranInsertaOrden
		SELECT ERROR_NUMBER() AS Number,
	           ERROR_SEVERITY() AS Severity,
			   ERROR_STATE() AS [State],
			   ERROR_PROCEDURE() AS [Procedure],
			   ERROR_LINE() AS Line,
			   ERROR_MESSAGE() AS [Message]
	END CATCH	
END
go

