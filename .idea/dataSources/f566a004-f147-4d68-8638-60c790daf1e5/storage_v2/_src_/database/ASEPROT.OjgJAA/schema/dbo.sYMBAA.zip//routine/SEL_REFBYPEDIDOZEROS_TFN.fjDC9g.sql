 --SELECT [dbo].[SEL_ORDBYPEDIDOZEROS_TFN]('6364', 12, 42322)
 CREATE FUNCTION [dbo].[SEL_REFBYPEDIDOZEROS_TFN] ( @numSiniestro nvarchar(max), @idMarca int, @nombreTipoOrdenServicio nvarchar(max))
returns varchar(max)
as 
begin

	DECLARE @factura varchar(max) = '';

	IF(@nombreTipoOrdenServicio = 'Refacciones')
		BEGIN
			IF @idMarca =1 --NISSAN
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAZM_Zaragoza].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAZM_Zaragoza].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAZM_Zaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'

			END 
			ELSE IF @idMarca=2 --GM
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAS_Satelite].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAS_Satelite].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAS_Satelite].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END 
			ELSE IF @idMarca=3 --Ford
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAAF_Body].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAAF_Body].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAAF_Body].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
			ELSE IF @idMarca=4 --Suzuki
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAU_Universidad].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAU_Universidad].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAU_Universidad].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
			ELSE IF @idMarca=5 --Hyundai
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAHyundai].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAHyundai].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAHyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
			/*ELSE IF @idMarca=6 --CRA
			BEGIN 
				select @factura=((LEFT(ORD_TAREFERENCIA, LEN(ORD_TAREFERENCIA) - PATINDEX('%[a-z]%', REVERSE(ORD_TAREFERENCIA)) + 1))+
				Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORD_TAREFERENCIA, PATINDEX('%[0-9.-]%', ORD_TAREFERENCIA), 8000),
				PATINDEX('%[^0-9.-]%', SUBSTRING(ORD_TAREFERENCIA, PATINDEX('%[0-9.-]%', ORD_TAREFERENCIA), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
				from [192.168.20.29].[GACRA_Cuautitlan].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GACRA_Cuautitlan].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORD_TAREFERENCIA  where
				SO.ore_idSiniestro = @numSiniestro and ore_status = 'I' and AV.VTE_STATUS = 'I'
			END*/
			ELSE IF @idMarca=7 --Honda
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAHondaZaragoza].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAHondaZaragoza].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAHondaZaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
			ELSE IF @idMarca=8 --Volkswagen
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.31].[GADLA_VW].[dbo].SER_ORDEN SO
				inner join [192.168.20.31].[GADLA_VW].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.31].[GADLA_VW].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where-- ORE_DOCTO like '%41628%'
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'

			END
			ELSE IF @idMarca=9 --Seat
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.31].[GADLA_SEAT].[dbo].SER_ORDEN SO
				inner join [192.168.20.31].[GADLA_SEAT].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.31].[GADLA_SEAT].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
			ELSE IF @idMarca=11 --Chevrolet
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAA_Azcapo].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAA_Azcapo].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAA_Azcapo].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
			ELSE IF @idMarca=12 --Chrysler
			BEGIN 
				select @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAutoAngarTlahuac].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAutoAngarTlahuac].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAutoAngarTlahuac].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'

				if(@factura is null or @factura='')
				begin 
					select @factura = ORD_TAREFERENCIA
					from [192.168.20.29].GAAutoAngarTepepan.[dbo].SER_ORDEN SO
					inner join [192.168.20.29].GAAutoAngarTepepan.[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
					inner join [192.168.20.29].GAAutoAngarTepepan.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
					(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
				end
			END
			ELSE IF @idMarca=13 --Hyundai Cam
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAVC_Hyundai].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAVC_Hyundai].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAVC_Hyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
			ELSE IF @idMarca=16 --Mitsubishi
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAutoAngarMitsu].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAutoAngarMitsu].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAutoAngarMitsu].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
			ELSE IF @idMarca=22 --Nissan Abasto
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].GAZM_Abasto.[dbo].SER_ORDEN SO
				inner join [192.168.20.29].GAZM_Abasto.[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].GAZM_Abasto.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC='RE'
			END
		END
	ELSE
		BEGIN
			IF @idMarca =1 --NISSAN
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAZM_Zaragoza].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAZM_Zaragoza].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAZM_Zaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'

			END 
			ELSE IF @idMarca=2 --GM
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAS_Satelite].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAS_Satelite].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAS_Satelite].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END 
			ELSE IF @idMarca=3 --Ford
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAAF_Body].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAAF_Body].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAAF_Body].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
			ELSE IF @idMarca=4 --Suzuki
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAU_Universidad].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAU_Universidad].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAU_Universidad].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
			ELSE IF @idMarca=5 --Hyundai
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAHyundai].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAHyundai].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAHyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
			/*ELSE IF @idMarca=6 --CRA
			BEGIN 
				select @factura=((LEFT(ORD_TAREFERENCIA, LEN(ORD_TAREFERENCIA) - PATINDEX('%[a-z]%', REVERSE(ORD_TAREFERENCIA)) + 1))+
				Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(ORD_TAREFERENCIA, PATINDEX('%[0-9.-]%', ORD_TAREFERENCIA), 8000),
				PATINDEX('%[^0-9.-]%', SUBSTRING(ORD_TAREFERENCIA, PATINDEX('%[0-9.-]%', ORD_TAREFERENCIA), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
				from [192.168.20.29].[GACRA_Cuautitlan].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GACRA_Cuautitlan].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORD_TAREFERENCIA  where
				SO.ore_idSiniestro = @numSiniestro and ore_status = 'I' and AV.VTE_STATUS = 'I'
			END*/
			ELSE IF @idMarca=7 --Honda
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAHondaZaragoza].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAHondaZaragoza].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAHondaZaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
			ELSE IF @idMarca=8 --Volkswagen
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.31].[GADLA_VW].[dbo].SER_ORDEN SO
				inner join [192.168.20.31].[GADLA_VW].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.31].[GADLA_VW].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where-- ORE_DOCTO like '%41628%'
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'

			END
			ELSE IF @idMarca=9 --Seat
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.31].[GADLA_SEAT].[dbo].SER_ORDEN SO
				inner join [192.168.20.31].[GADLA_SEAT].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.31].[GADLA_SEAT].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
			ELSE IF @idMarca=11 --Chevrolet
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAA_Azcapo].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAA_Azcapo].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAA_Azcapo].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
			ELSE IF @idMarca=12 --Chrysler
			BEGIN 
				select @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAutoAngarTlahuac].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAutoAngarTlahuac].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAutoAngarTlahuac].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'

				if(@factura is null or @factura='')
				begin 
					select @factura = ORD_TAREFERENCIA
					from [192.168.20.29].GAAutoAngarTepepan.[dbo].SER_ORDEN SO
					inner join [192.168.20.29].GAAutoAngarTepepan.[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
					inner join [192.168.20.29].GAAutoAngarTepepan.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
					(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
				end
			END
			ELSE IF @idMarca=13 --Hyundai Cam
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAVC_Hyundai].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAVC_Hyundai].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAVC_Hyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
			ELSE IF @idMarca=16 --Mitsubishi
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].[GAAutoAngarMitsu].[dbo].SER_ORDEN SO
				inner join [192.168.20.29].[GAAutoAngarMitsu].[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].[GAAutoAngarMitsu].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
			ELSE IF @idMarca=22 --Nissan Abasto
			BEGIN 
				select TOP 1 @factura = ORD_TAREFERENCIA
				from [192.168.20.29].GAZM_Abasto.[dbo].SER_ORDEN SO
				inner join [192.168.20.29].GAZM_Abasto.[dbo].SER_ORDENDET DET ON DET.ORD_IDORDEN = SO.ORE_IDORDEN
				inner join [192.168.20.29].GAZM_Abasto.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = DET.ORD_TAREFERENCIA  where
				(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) AND ORD_CLASIFIC!='RE'
			END
		END
	--select @factura= STUFF(@factura, 1, 1, '')
	
	return @factura
end
 go

