CREATE procedure dbo.INS_ORDEN_PAGO_SP (
	@idUsuario numeric(18,0)
	,@folio as nvarchar(200)
	,@fecha datetime
	,@monto decimal(18,0)
)
as
begin

	INSERT INTO dbo.OrdenPago
		(folio, fecha, monto, idEstatusOrdenPago, fechaCarga)
	VALUES 
		(@folio,@fecha,@monto , 1, GETDATE());
		
		SELECT @@IDENTITY

end
go

