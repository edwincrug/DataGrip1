-- =============================================
-- Create date: 03/10/2017
-- Description:	Stored que consulta ordenes con estatus 1 Citas sin taller
-- [SEL_OPE_CITAS_CON_TALLER_SP] 3,312,'',0
-- =============================================

 CREATE PROCEDURE [dbo].[SEL_OPE_CITAS_CON_TALLER_SP]
	@idContratoOperacion INT = 3,
	@idUsuario INT = 312, 
	@numeroOrden VARCHAR(50) = '',
	@idZona int = null,
	@idEjecutivoFiltro INT = null,
	@fechaIni varchar(max) = null,--'2017/09/01 00:00:00',
	@fechaFin varchar(max) = null--'2017/09/30 23:59:59'
		
AS
BEGIN

	SET NOCOUNT ON;  
	SET DATEFORMAT DMY;
 
	DECLARE @idCatalogoRol INT  
	DECLARE @idContratoOperacionUsuario INT
	DECLARE @idContratoOperacionUsuarioEjecutivo INT
	DECLARE @idOperacion INT
	DECLARE @select NVARCHAR(MAX) = '' 
	DECLARE @where NVARCHAR(MAX) = '' 
	DECLARE @query NVARCHAR(MAX) = ''
	DECLARE @join NVARCHAR(MAX) = ''
	DECLARE @usuario NVARCHAR(MAX) = '' 
	DECLARE @zonas NVARCHAR(MAX) = ''
	DECLARE @zonasEjecutivo NVARCHAR(MAX) = ''

	SELECT @idContratoOperacionUsuario = COU.idContratoOperacionUsuario, @idCatalogoRol = COU.idCatalogoRol, @idOperacion = CO.idOperacion
	FROM Usuarios U 
		JOIN ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
		JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
	WHERE U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	;WITH ALLZonas(idZona)
	AS (SELECT idZona FROM ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario) 
	SELECT @zonas=idZona FROM ALLZonas

	IF(@idCatalogoRol <> 2)
		BEGIN
		    IF(@idCatalogoRol <> 4)
				BEGIN
					IF(@idCatalogoRol <> 9)
						BEGIN
							SET @usuario  = 'AND Z.idZona in (SELECT idZona FROM ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = '+ convert(varchar(5), @idContratoOperacionUsuario) +') and o.idOrden not in(select idOrden from Cotizaciones where idTaller=689) '
						END
					ELSE
						BEGIN
							SET @usuario  = 'AND Z.idZona in (SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
												JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
												JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
											WHERE EG.estatus=0 AND EZ.estatus=0 
											AND COUG.idContratoOperacionUsuario='+ convert(varchar(5), @idContratoOperacionUsuario) +' AND EZ.idContratoOperacion='+ convert(varchar(5), @idContratoOperacion) +') '
						END
				END
			ELSE
				BEGIN
					set @usuario = ' AND (SELECT CASE WHEN EXISTS (SELECT 1 FROM Cotizaciones C where C.idOrden = O.idOrden and C.idEstatusCotizacion in (1) AND C.idTaller in '+
									'(SELECT COUP.idProveedor' + char(13) + 
										'FROM ContratoOperacionUsuario COU ' + char(13) + 
										'INNER JOIN ContratoOperacionUsuarioProveedor COUP ON COUP.idContratoOperacionUsuario =  COU.idContratoOperacionUsuario' + char(13) + 
										'WHERE COU.idUsuario = '+ convert(varchar(5), @idUsuario) +' and COU.idContratoOperacion = '+ convert(varchar(50),@idContratoOperacion) +')'+
									' ) THEN ' +char(39)+'true'+char(39)+ ' ELSE '+char(39)+ 'false'+char(39)+' END ) = '+char(39)+'true'+char(39)  

				END
		END

	
	SET @select = 
		'SELECT 
		(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente,
		O.consecutivoOrden,
		O.numeroOrden,
		U.numeroEconomico,
		Z.nombre AS nombreZona,
		CTO.nombreTipoOrdenServicio AS nombreTipoOrdenServicio,
		O.fechaCreacionOden,
		CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <=''12/11/2018'' and O.idEstatusOrden in (1,2,3,4) THEN 1
		ELSE 0 END
		AS aplicaFondo,	
		O.comentarioOrden AS comentarioOrden,
		EO.nombreEstatusOrden AS nombreEstatusOrden,
		UR.nombreCompleto AS nombreUsuario,
		(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 1,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS venta,
		(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 1,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS costo,
		DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEspera,
		O.idOrden,
		Z.idZona
	FROM Ordenes O
		JOIN Unidades U ON U.idUnidad = O.idUnidad
		JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
		JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
		JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
		JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
		LEFT JOIN PreCancelacionOrdenes PC ON PC.idOrden = O.idOrden
		JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
		JOIN Partidas..Zona Z ON Z.idZona = O.idZona '

	SET @where = 'WHERE CO.idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+' AND O.idEstatusOrden = 2 AND PC.idOrden IS NULL 
					AND O.idZona = COALESCE('+COALESCE(convert(varchar(max),@idZona),'NULL')+', O.idZona)
					AND O.idUsuario = COALESCE(' + COALESCE(convert(varchar(max),@idEjecutivoFiltro),'NULL')+ ',O.idUsuario)
					AND O.fechaCreacionOden between COALESCE(' + COALESCE(''''+@fechaIni+'''', 'NULL') + ',O.fechaCreacionOden) and COALESCE(' + COALESCE(''''+@fechaFin+'''', 'NULL') + ',O.fechaCreacionOden)'

	IF(@numeroOrden != '')
	  BEGIN
		SET @numeroOrden =' AND O.numeroOrden like ''%'+@numeroOrden+'%'''
	  END

	SET @query = @select + @where + @usuario + @numeroOrden
	print @query
	EXECUTE SP_EXECUTESQL @query

END

/****** Object:  StoredProcedure [dbo].[SEL_OPE_CITAS_EN_TALLER_SP]    Script Date: 12/07/2017 23:19:08 ******/
SET ANSI_NULLS ON


--USE [ASEPROT]
go

