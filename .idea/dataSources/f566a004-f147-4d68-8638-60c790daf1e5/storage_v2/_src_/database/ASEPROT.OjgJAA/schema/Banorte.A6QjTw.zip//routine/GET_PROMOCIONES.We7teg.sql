/*
	Objetivo:  Obtiene las promociones del catalogo de promociones para la APP mobil, cuando das clic en cada TIPO de promocion
	Fecha			Autor			Descripción
	14-May-2018		Eric Arturo Reyes Xinaxtle	Se crea el SP que regresa las promociones genrales
	26-Jul-2018		José Etmanuel	Se documentan los cambios,
									se agrega tipoApp de la aplicación,
									se agrega el nombre de la sucursal,
									se agrega promoción "en blanco" y estatus...
	
	[Banorte].[GET_PROMOCIONES] 3
*/

CREATE PROCEDURE [Banorte].[GET_PROMOCIONES] 
	@idTipoPromocion INT,
	@tipoApp varchar(50) = 'APP'
AS
BEGIN
	
	IF NOT EXISTS (SELECT distinct p.id as idPromocion
				FROM Banorte.Promociones P
				INNER JOIN [Banorte].[PromocionesSuc] AS S ON S.[idPromociones] = P.id
				INNER JOIN [Banorte].[Patrocinador] PAT ON PAT.Id = s.[PatrocinadorId]
				INNER JOIN [Banorte].[Sucursales] SUC ON SUC.[PatrocinadorId] = S.[PatrocinadorId] AND SUC.[Id] = S.[SucursalId]
				INNER JOIN [Banorte].[CatalogoTipoPromocion] T ON T.[id] = P.idTipoPromocion
				WHERE  fechaInicio <= GETDATE()
				AND fechaTermino >= GETDATE()
				AND estatus = 1
				AND idTipoPromocion = @idTipoPromocion
				AND aplicaPara = @tipoApp
			)
	BEGIN
		
		DECLARE @PatName varchar(100),
				@PatImg varchar(max)
		SELECT TOP 1 @PatName=[Nombre], @PatImg=[Img] from [Banorte].[Patrocinador];

		SELECT 
			0 as idPromocion, 
			getdate() as fechaVigencia, 
			getdate() as fechaInicio,
			(select Descripcion from [Banorte].[CatalogoTipoPromocion] where id = @idTipoPromocion) as titulo, 
			DBO.Get_Tiempo_Restante(getdate())as tiempoRestante, 
			@PatName as patrocinador, 
			'CDMX' AS localidad, 
			'', 
			'' AS descripcion, 
			@PatImg as logo,
			(SELECT [urlImagen] FROM [Banorte].[Promociones] where [idTipoPromocion] = 0 and [aplicaPara] = @tipoApp) as img, -- el 0 refiere a la promo sin promocion 
			'' as Sucursal,
			0 as b_aplicaCodigo

	END
	ELSE
	BEGIN

		SELECT 
			distinct p.id as idPromocion, 
			fechaTermino as fechaVigencia, 
			fechaInicio,
			T.Descripcion as titulo, 
			DBO.Get_Tiempo_Restante(fechaTermino)as tiempoRestante, 
			PAT.nombre as patrocinador, 
			'CDMX'  AS localidad,  -- La localidad no debe ir a este nivel
			restricciones, 
			nombrePromocion AS descripcion, 
			PAT.Img as logo,
			p.urlImagen as img,
			1 as b_aplicaCodigo
		FROM Banorte.Promociones P
		INNER JOIN [Banorte].[PromocionesSuc] AS S ON S.[idPromociones] = P.id
		INNER JOIN [Banorte].[Patrocinador] PAT ON PAT.Id = s.[PatrocinadorId]
	--	INNER JOIN [Banorte].[Sucursales] SUC ON SUC.[PatrocinadorId] = S.[PatrocinadorId] AND SUC.[Id] = S.[SucursalId]
		INNER JOIN [Banorte].[CatalogoTipoPromocion] T ON T.[id] = P.idTipoPromocion
		WHERE  fechaInicio <= GETDATE()
		AND fechaTermino >= GETDATE()
		AND estatus = 1
		AND idTipoPromocion = @idTipoPromocion
		AND aplicaPara = @tipoApp
	END
END

go

grant execute, view definition on Banorte.GET_PROMOCIONES to DevOps
go

