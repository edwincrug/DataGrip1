-- =============================================
-- Description:	Busca talleres
-- =============================================
--SEL_TALLERES_SP @idUsuario=133, @idContratoOperacion =1, @idZona=52, @nombreTaller='', @servicios=1
CREATE PROCEDURE [dbo].[SEL_TALLERES_SP_MODIFICADO] 
	 @idUsuario  NUMERIC(18,0) = 2
	,@idContratoOperacion NUMERIC(18,0) = 1
	,@idZona INT = NULL
	,@nombreTaller NVARCHAR(300) = ''
	,@servicios NVARCHAR(100) = ''
AS
BEGIN
	
	DECLARE @query NVARCHAR(MAX)=''	
	------Obtengo la ip del servidor donde se encuntra la BD Partidas
	
	-----------------------------------------------------------------
	------Obtengo las zonas que debo buscar en el SP si traigo datos
	DECLARE @esNumero INT = 0, @cadenaZonas NVARCHAR(100) = ''
	SET @esNumero = (SELECT ISNUMERIC(@idZona)) 
	IF(@esNumero = 1)
		BEGIN 
			DECLARE @numeroZonas INT = 0, @contador INT = 1, @idZonaTabla INT = 0, @queryNomZona NVARCHAR(MAX) = '', @queryIdZona NVARCHAR(MAX) = ''
			SET @queryNomZona = '  SELECT		COUNT(idZona) ' + char(13) + 
								'  FROM			.[Partidas].[dbo].[Zona] ' + char(13) + 
								'  WHERE		idZona = '+CONVERT(NVARCHAR(100),@idZona)+' OR idPadre = '+CONVERT(NVARCHAR(100),@idZona)+' ' + char(13) + 
								'' 
			DECLARE	@zonasTabla TABLE(numeroZonas INT);
			INSERT INTO @zonasTabla
			EXECUTE(@queryNomZona)
			SELECT @numeroZonas = numeroZonas FROM @zonasTabla
			SET @queryIdZona =  '  SELECT		idZona ' + char(13) + 
								'  FROM			.[Partidas].[dbo].[Zona] ' + char(13) + 
								'  WHERE		idZona = '+CONVERT(NVARCHAR(100),@idZona)+' OR idPadre = '+CONVERT(NVARCHAR(100),@idZona)+' ' + char(13) + 
								'' 
			DECLARE	@zonas TABLE(	ID INT IDENTITY(1,1)
									,idZona	INT		
								);
			INSERT INTO @zonas
			EXECUTE (@queryIdZona)
			--select * from @zonas
			WHILE (@contador <= @numeroZonas)
				BEGIN
					SELECT @idZona = idZona FROM @zonas WHERE ID = @contador
					SET @cadenaZonas = CONVERT(NVARCHAR(100),@idZona) + ',' + @cadenaZonas
					SET @contador = @contador + 1
					PRINT @contador
				END
			  PRINT @cadenaZonas
			  SET @cadenaZonas = LEFT(@cadenaZonas, LEN(@cadenaZonas) - 1)
			  PRINT @cadenaZonas 
		END
	ELSE
		BEGIN
			SET @cadenaZonas = ''
		END	
	--select * from @zonas
	--PRINT @numeroZonas

	--select * from @zonasTabla
	--print @queryNomZona
	--SET @numeroZonas = EXECUTE(@queryNomZona)
	---------------------------------------------------------------- 
	SET @query = 'SELECT	DISTINCT PE.idProveedor AS idProveedor' + char(13) + 
		'		,P.nombreComercial' + char(13) + 
		'		,P.idProveedor idTaller' + char(13) + 
		'		,P.razonSocial' + char(13) + 
		'		,P.RFC ' + char(13) + 
		--'		,especialidad' + char(13) + 
		'		,Z.idZona AS idZona' + char(13) +
		'		,P.direccion' + char(13) + 
		'		,(SELECT [dbo].[SEL_ESPECIALIDADES_TALLER_FN](PE.idProveedor)) AS especialidad '+ char(13) +
		'FROM	[dbo].[ContratoOperacion] CO' + char(13) +  
		'		INNER JOIN .[Partidas].[dbo].[ContratoProveedor] CPRO ON CPRO.idContrato = CO.idContrato' + char(13) +
		'		INNER JOIN .[Partidas].[dbo].[Proveedor] P ON P.idProveedor = CPRO.idProveedor' + char(13) +
		'		INNER JOIN .[Partidas].[dbo].[ProveedorEspecialidad] PE ON PE.idProveedor = P.idProveedor' + char(13) +
		'		INNER JOIN .[Partidas].[dbo].[Especialidad] E ON E.idEspecialidad = PE.idEspecialidad' + char(13) +
		'		INNER JOIN .[Partidas].[dbo].[ContratoProveedorZona] CPROZ ON CPROZ.idContratoProveedor = CPRO.idContratoProveedor' + char(13) +
		'		INNER JOIN .[Partidas].[dbo].[Zona] Z ON Z.idZona = CPROZ.idZona' + char(13) +
		'		INNER JOIN .[Partidas].[dbo].[NivelZona] NZ ON Z.idNivelZona = NZ.idNivelZona' + char(13) +
		'WHERE	idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+ char(13) + 
		--'		AND Z.idZona = COALESCE('+ISNULL(CONVERT(NVARCHAR(100),@idZona),'NULL')+', Z.idZona) ' + char(13) + 
		'		AND Z.idZona'+ (CASE WHEN @cadenaZonas = '' THEN  ' = Z.idZona' ELSE  ' IN ('+@cadenaZonas+')' END ) + char(13) + 
		'		AND E.idEspecialidad'+ (CASE WHEN @servicios = '' THEN  ' = E.idEspecialidad' ELSE  ' IN ('+@servicios+')' END ) + char(13) +
		'		'+ (CASE WHEN @nombreTaller = '' THEN  '' ELSE  'AND P.razonSocial like '''+@nombreTaller+'''' END ) + char(13) + 
		'' 
		
	EXECUTE (@query)
END
go

