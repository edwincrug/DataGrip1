-- ==========================================================================================
-- Author:		Anel Candi Pérez Pérez 
-- Create date: 27/12/2016
-- Description:	Stored que seleccciona los motivo de un sustituto
-- [SEL_MOTIVO_SUSTITUTO_SP] 
-- ==========================================================================================
CREATE PROCEDURE [Sustituto].[SEL_MOTIVO_SUSTITUTO_SP]

AS
BEGIN
	SELECT * FROM[Sustituto].MotivoSustituto
END
go

