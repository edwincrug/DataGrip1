-- =============================================
-- Create date: 02/06/2017
-- Description:	Obtiene el tipo de aprobacion!!!
-- SEL_TIPO_APROBACION_SP
-- =============================================
 create PROCEDURE [dbo].[SEL_TIPO_APROBACION_SP]

AS
BEGIN

	SELECT * FROM CatalogoTipoAprobaciones

END


go

