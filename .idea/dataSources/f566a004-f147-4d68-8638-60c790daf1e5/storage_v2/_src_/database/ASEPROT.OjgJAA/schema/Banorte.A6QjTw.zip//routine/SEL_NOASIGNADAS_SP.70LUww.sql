-- =============================================
-- Author:		YJH
-- Create date: 2019/02/14
-- Description:	Obtiene las ordenes con estatus no asignada
-- [Banorte].[SEL_NOASIGNADAS_SP] 677,18
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_NOASIGNADAS_SP]
@idUsuario int,--507
@idcontratooperacion int = NULL,
--FILTROS
@idEjecutivo					INT = 0,--125
@idZona							INT = NULL,
@fechaIni						VARCHAR(MAX) = NULL,
@fechaFin						VARCHAR(MAX) = NULL,
@err							VARCHAR(500) = NULL	OUTPUT

AS
BEGIN
	BEGIN TRY
	DECLARE @idCatalogoRol					INT
	DECLARE @idContratoOperacionUsuario		INT	

	declare @idContratoOperacionBan int = 0 

	select @idContratoOperacionBan= valor from ASEPROT.Banorte.Parametros where id=2

	DECLARE @tblCitasGeneral as table(
		nombreCliente						VARCHAR(max),
		consecutivoOrden					INT,
		numeroOrden							VARCHAR(max),
		numeroEconomico						VARCHAR(max),
		nombreZona							VARCHAR(max),
		nombreTipoOrdenServicio				VARCHAR(max),
		fechaCreacionOden					DATETIME,
		aplicaFondo							INT,	
		comentarioOrden						VARCHAR(max),
		idEstatusOrden						INT,
		conjuntoEstatus						VARCHAR(30),
		idGarantia							INT,
		nombreEstatusOrden					VARCHAR(max),
		nombreUsuario						VARCHAR(max),
		venta								float,
		costo								float,
		tiempoEspera						INT,
		idOrden								INT,
		idZona								INT,
		seguro								BIT,		
		Taller nvarchar(100)
	)

	DECLARE @tblCitasZona as table(
		nombreCliente						VARCHAR(max),
		consecutivoOrden					INT,
		numeroOrden							VARCHAR(max),
		numeroEconomico						VARCHAR(max),
		nombreZona							VARCHAR(max),
		nombreTipoOrdenServicio				VARCHAR(max),
		fechaCreacionOden					DATETIME,
		aplicaFondo							INT,	
		comentarioOrden						VARCHAR(max),
		idEstatusOrden						INT,
		conjuntoEstatus						VARCHAR(30),
		idGarantia							INT,
		nombreEstatusOrden					VARCHAR(max),
		nombreUsuario						VARCHAR(max),
		venta								float,
		costo								float,
		tiempoEspera						INT,
		idOrden								INT,
		idZona								INT,
		seguro								BIT,
		Taller nvarchar(100)
	)
	
	SELECT 
			
			@idCatalogoRol = COU.idCatalogoRol, 
			@idContratoOperacionUsuario = COU.idContratoOperacionUsuario
		FROM ASEPROT.dbo.Usuarios U 
			JOIN ASEPROT.dbo.ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
		WHERE 
			U.idUsuario = @idUsuario 
			and COU.idContratoOperacion = @idcontratooperacion
	

	INSERT INTO @tblCitasGeneral 
	SELECT 
			(SELECT descripcion FROM PARTIDAS..CONTRATO PCO where idContrato =(SELECT idContrato 
																				FROM ASEPROT..contratoOperacion 
																				WHERE idContratoOperacion = O.idContratoOperacion)
																				)AS nombreCliente,
			O.consecutivoOrden,
			O.numeroOrden,
			U.numeroEconomico,
			Z.nombre AS nombreZona,
			CTO.nombreTipoOrdenServicio AS nombreTipoOrdenServicio,
			O.fechaCreacionOden,
			CASE WHEN O.fechaCreacionOden <='12/11/2018' THEN 1
			ELSE 0 END
			AS aplicaFondo,	
			O.comentarioOrden AS comentarioOrden,
			O.idEstatusOrden,
			'0',
			O.idGarantia,
			EO.nombreEstatusOrden AS nombreEstatusOrden,
			UR.nombreCompleto AS nombreUsuario,
			(SELECT [SISCOV3].dbo.[SEL_ORDEN_PRECIOVENTA_FN](O.idOrden, 1,@idUsuario)) AS venta,
			(SELECT [SISCOV3].[dbo].[SEL_ORDEN_PRECIOCOSTO_FN](O.idOrden, 1, @idUsuario)) AS costo,
			0 As tiempoEspera,
			O.idOrden,
			Z.idZona,
			CASE
				WHEN O.idCatalogoTipoOrdenServicio in (4,5,6,7,8,9) 
						OR O.idCatalogoTipoOrdenServicio IS NULL THEN 1
				ELSE 0
			END
			,case when @idContratoOperacion = @idContratoOperacionBan then 
			ASEPROT.[dbo].[SEL_PROVEEDORREFAC_ORDEN_FN](O.idOrden) else 
					'' end 
		FROM ASEPROT.dbo.Ordenes O
			inner JOIN ASEPROT.dbo.Unidades U ON U.idUnidad = O.idUnidad
			inner JOIN ASEPROT.dbo.EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
			inner JOIN ASEPROT.dbo.CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio			
			inner JOIN ASEPROT.dbo.Usuarios UR ON UR.idUsuario = O.idUsuario
			inner JOIN Partidas..Zona Z ON Z.idZona = O.idZona 		
			WHERE 
				O.idEstatusOrden = 15 
				and O.idContratoOperacion=@idcontratooperacion
				--parametro zona
				AND O.idZona = COALESCE(@idZona, O.idZona)
				AND fechaCreacionOden between COALESCE(@fechaIni, fechaCreacionOden) 
				and COALESCE(@fechaFin, fechaCreacionOden)

	

	--APLICACION DE FILTROS
	
	PRINT '2) APLCIACION DE FILTRO POR EJECUTIVO: '	
	IF ( @idEjecutivo = 0) 
	BEGIN
		PRINT '* NO APLICADO'
		INSERT INTO @tblCitasZona 
		SELECT * FROM @tblCitasGeneral
	END
	ELSE
		BEGIN
			PRINT '* APLICADO: ' + 'idEjecutivo: ' + CONVERT(varchar,@idEjecutivo)
			INSERT INTO @tblCitasZona 
			SELECT * 
			FROM @tblCitasGeneral as tblGral 
			WHERE tblGral.idZona in(
										SELECT z.idZona  
										FROM ASEPROT.[dbo].[ContratoOperacionUsuarioZona] Z
										INNER JOIN ASEPROT.dbo.contratooperacionusuario COU on cou.idcontratooperacionusuario = z.idcontratooperacionusuario
										INNER JOIN ASEPROT.dbo.contratooperacion co on co.idContratoOperacion = cou.idcontratooperacion
										WHERE 
											--co.idcontratooperacion= @idcontratooperacion r
											cou.idUsuario = @idEjecutivo
									)
		END
	-- si es proveedor
	IF(@idCatalogoRol = 4)
		BEGIN
			select * 
			from @tblCitasZona tblZona 
			where tblZona.idOrden in(
										SELECT ctz.idOrden 
										FROM ASEPROT.dbo.Cotizaciones ctz
										where ctz.idOrden = tblZona.idOrden 
										AND ctz.idTaller in (
																SELECT cop.idProveedor
																FROM ASEPROT.dbo.ContratoOperacionUsuario cou 
																INNER JOIN ASEPROT.dbo.ContratoOperacionUsuarioProveedor cop ON cop.idContratoOperacionUsuario =  cou.idContratoOperacionUsuario
																WHERE cou.idUsuario = @idUsuario
																and cou.idContratoOperacion = @idcontratooperacion
																)
									)
		END
		-- si es rol gerente de zona
	ELSE IF(@idCatalogoRol = 9)
		BEGIN
				SELECT * 
				FROM @tblCitasZona tblZ 
				WHERE tblZ.idZona in ( 
										SELECT ezo.idZona 
										FROM ASEPROT.dbo.[ContratoOperacionUsuarioGerente] cog
										JOIN ASEPROT.[Gerente].[EstadoGerencia] esg ON esg.idGerencia = cog.idGerencias
										JOIN ASEPROT.[Gerente].[EstadoZona] ezo ON ezo.idEstado = esg.idEstado
										INNER JOIN ASEPROT.dbo.ContratoOperacionUsuario cou on cou.idContratoOperacionUsuario = cog.idContratoOperacionUsuario and cou.idContratoOperacion = @idcontratooperacion
										WHERE 
											esg.estatus=0 --activo
											AND ezo.estatus=0 --activo
											AND cou.idUsuario = @idUsuario
									)
		END
		--si es admin
	ELSE IF(@idCatalogoRol = 2 )
		BEGIN
			select * from @tblCitasZona
		END
		-- rol diferente
	ELSE
		BEGIN
			SELECT * FROM @tblCitasZona 
			 WHERE idZona in (  
								SELECT idZona 
								FROM ASEPROT.dbo.ContratoOperacionUsuarioZona 
								WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario  
							)
		END

	END TRY

	BEGIN CATCH
		set  @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
	END CATCH

	PRINT 'OUT = ' +  @err
	RETURN
END
go

grant execute, view definition on Banorte.SEL_NOASIGNADAS_SP to DevOps
go

