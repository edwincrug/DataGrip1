-- =============================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 24/05/2017
-- =============================================
CREATE PROCEDURE [dbo].[INS_NOTA] 
	@nota varchar(MAX) = NULL,
	@numOrden varchar(max),
	@idUsuario numeric(18,0),
	@idEstatusOrden int
AS
BEGIN
	SET NOCOUNT ON;

	IF @nota is not null AND @nota != ''
	BEGIN
		declare @idOrden numeric(18,0) 
		set @idOrden = (select idOrden from [dbo].[Ordenes] where [numeroOrden] = @numOrden)

		INSERT INTO [dbo].[Notas]
					([descripcionNota],[idOrden],[idUsuario],[fechaNota],[idEstatusOrden])
			 VALUES (@nota, @idOrden, @idUsuario, GETDATE(), @idEstatusOrden)
	END	 

	SELECT N.[idUsuario], U.[nombreCompleto], N.[descripcionNota] AS texto, DATEADD(hh, 5, N.[fechaNota]) AS fecha, EO.[nombreEstatusOrden] AS nombreEstatus
	FROM   [dbo].[Notas] AS N
			INNER JOIN [dbo].[Usuarios] AS U ON U.[idUsuario] = N.[idUsuario]
			INNER JOIN [dbo].[Ordenes] AS O ON N.idOrden = O.idOrden 
			INNER JOIN [dbo].[EstatusOrdenes] AS EO ON EO.idEstatusOrden = N.idEstatusOrden
	WHERE  O.numeroOrden = @numOrden
	ORDER BY [fechaNota]
END

go

