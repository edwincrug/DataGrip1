-- =============================================
-- Description:	Crea una nueva cotización e inserta en la tala historial cotizaciones
-- NOTA:  
-- [INS_COTIZACION_NUEVA_SP]@idTaller = 1,@idUsuario = 2, @idEstatusCotizacion = 1,@idOrden = 11
-- =============================================
CREATE PROCEDURE [dbo].[INS_COTIZACION_NUEVA_SP]
 @idTaller NUMERIC(18,0),
 @idUsuario NUMERIC(18,0),
 @idEstatusCotizacion INT,
 @idOrden varchar(50),
 @idCatalogoTipoOrdenServicio INT,
 @existeTaller INT = 0,
 @idBproTaller int =0, 
 @idTipoCotizacion int = 0
 --@idContratoOperacion INT
 AS
 BEGIN
 IF(@existeTaller = 0)
	BEGIN
		DECLARE @fechaCotizacion DATETIME
		DECLARE @idCotizacion NUMERIC(18,0)
		DECLARE @idOrden2 NUMERIC(18,0), @consecutivoCotizacion INT
		SET @idOrden2 = (SELECT idOrden FROM Ordenes WHERE numeroOrden = @idOrden )
		SET @fechaCotizacion = SYSDATETIME()

		IF (EXISTS(SELECT TOP 1 consecutivoCotizacion FROM [dbo].[Cotizaciones] WHERE idOrden = @idOrden2))
					BEGIN
						SET @consecutivoCotizacion = (SELECT TOP 1 consecutivoCotizacion FROM [dbo].[Cotizaciones] WHERE idOrden = @idOrden2 ORDER BY consecutivoCotizacion DESC) +1
						SET @idUsuario = (SELECT TOP 1 U.idUsuario FROM [dbo].Cotizaciones C INNER JOIN [dbo].Usuarios U ON U.idUsuario = C.idUsuario WHERE C.idOrden = @idOrden2)
					END
				ELSE 
					BEGIN
						SET @consecutivoCotizacion = 1
					END

		if (@idBproTaller = 0 )
		begin
			INSERT INTO [dbo].[Cotizaciones] (fechaCotizacion, idTaller, idUsuario, idEstatusCotizacion, idOrden, numeroCotizacion,
			consecutivoCotizacion, idCatalogoTipoOrdenServicio, idPreorden)
			VALUES(@fechaCotizacion, @idTaller, @idUsuario, @idEstatusCotizacion, @idOrden2,@idOrden+'-'+CONVERT (varchar(5), 
			@consecutivoCotizacion), @consecutivoCotizacion,@idCatalogoTipoOrdenServicio,null)
		end
		else 
		begin	
						
			
			DECLARE @idOperacion INT = (select idContratoOperacion from ASEPROT.dbo.ordenes where idorden = @idOrden2)
			
			if (@idOperacion = 26)
			begin
			
		
			INSERT INTO [dbo].[Cotizaciones] (fechaCotizacion, idTaller, idUsuario, idEstatusCotizacion, idOrden, numeroCotizacion,
			consecutivoCotizacion, idCatalogoTipoOrdenServicio, idPreorden, idBproProveedor, idTipoCotizacion)
			VALUES(@fechaCotizacion, @idTaller, @idUsuario, @idEstatusCotizacion, @idOrden2,@idOrden+'-'+CONVERT (varchar(5), 
			@consecutivoCotizacion), @consecutivoCotizacion,@idCatalogoTipoOrdenServicio,null, @idBproTaller, @idTipoCotizacion)

			end
			else 
			begin	
					
			INSERT INTO [dbo].[Cotizaciones] (fechaCotizacion, idTaller, idUsuario, idEstatusCotizacion, idOrden, numeroCotizacion,
			consecutivoCotizacion, idCatalogoTipoOrdenServicio, idPreorden, idBproProveedor, idTipoCotizacion)
			VALUES(@fechaCotizacion, @idTaller, @idUsuario, @idEstatusCotizacion, @idOrden2,@idOrden+'-'+CONVERT (varchar(5), 
			@consecutivoCotizacion), @consecutivoCotizacion,@idCatalogoTipoOrdenServicio,null, @idBproTaller, @idTipoCotizacion)
			end

		end
		SET @idCotizacion = @@IDENTITY 

		INSERT INTO [dbo].[HistorialEstatusCotizacion]
			(fechaInicial,idCotizacion,idUsuario,idEstatusCotizacion)
		VALUES (@fechaCotizacion, @idCotizacion, @idUsuario, @idEstatusCotizacion)

		SELECT @idCotizacion AS idCotizacion, @idOrden+'-'+CONVERT (varchar(5), @consecutivoCotizacion) as numeroCotizacion, 'Se creo nueva cotización' AS mensaje
	END
ELSE
	BEGIN
		UPDATE [dbo].[Cotizaciones] 
		SET idTaller = @idTaller
		WHERE idCotizacion = @existeTaller

		SELECT 1 AS respuesta, 'Se actualizo correctamente la cotizacion' AS mensaje
	END
  
END
--select * from [dbo].[Cotizaciones]
--select * from [dbo].[HistorialEstatusCotizacion]

go

