-- ==========================================================================================
-- Author:		Anel Candi Pérez Pérez 
-- Create date: 27/12/2016
-- Description:	Stored que seleccciona las unidades sustituto disponibles
-- [Sustituto].[SEL_UNIDAD_SUSTITUTO_SP] '1110049',1, 1
-- [Sustituto].[SEL_UNIDAD_SUSTITUTO_SP] '9299',0, 8
-- [Sustituto].[SEL_UNIDAD_SUSTITUTO_SP] '1',0, 1
-- ==========================================================================================
CREATE PROCEDURE [Sustituto].[SEL_UNIDAD_SUSTITUTO_SP]
	@numEconomico NVARCHAR(50),
	@tipo NUMERIC(18,0),
	@idContratoOperacion int
AS
BEGIN
	DECLARE @idUnidad NUMERIC(18,0)
	DECLARE @idOperacion NUMERIC(18,0)

	SELECT @idOperacion=idOperacion FROM ContratoOperacion WHERE idContratoOperacion=@idContratoOperacion

	DECLARE contact_cursor CURSOR FOR
	SELECT idUnidad FROM [dbo].[Unidades] 
    WHERE ([numeroEconomico] like '%'+@numEconomico+'%'
	  OR [vin] LIKE '%'+@numEconomico+'%' 
	  OR [modelo] LIKE '%'+@numEconomico+'%')
	  AND idOperacion = @idOperacion
	--WHERE ([numeroEconomico] like '%'+@numEconomico+'%' 
	--	  OR marca LIKE '%'+@numEconomico+'%' 
	--	  OR modeloMarca LIKE '%'+@numEconomico+'%' 
	--	  OR factura LIKE '%'+@numEconomico+'%')
	
	IF OBJECT_ID( N'tempdb..#tablaTemporal') IS NOT NULL
		DROP TABLE #tablaTemporal;

	CREATE TABLE #tablaTemporal([numeroEconomico] NVARCHAR(50),								
								modelo NVARCHAR(50),
								submarca NVARCHAR(350),
								marca NVARCHAR(350),
								combustible NVARCHAR(50),
								placas NVARCHAR(50),
								sustituto numeric(18, 0),
								idUnidad numeric(18, 0), 
								vin NVARCHAR(50), 
								verGPS int
								)

	OPEN contact_cursor  
	FETCH NEXT FROM contact_cursor INTO @idUnidad
	WHILE @@FETCH_STATUS = 0  
		BEGIN 
			IF(@tipo = 0)
				BEGIN
				     INSERT INTO #tablaTemporal([numeroEconomico],												
												modelo,
												submarca,
												marca,
												combustible,
												placas,
												sustituto,
												idUnidad, 
												vin,
												verGPS												
												)
				     SELECT [numeroEconomico], 
							modelo,
							SM.nombre submarca,
							M.nombre marca,
							combustible,
							placas, 
							sustituto, 
							U.idUnidad, 
							vin, 
							verGPS
					FROM [dbo].[Unidades] U
					JOIN Partidas..Unidad UP ON U.idTipoUnidad = UP.idUnidad
					JOIN Partidas..SubMarca SM ON SM.idSubMarca = up.idSubMarca
					JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
					WHERE sustituto = 0
						AND U.[idUnidad]=@idUnidad
				END
			ELSE
				BEGIN 
					 INSERT INTO #tablaTemporal([numeroEconomico],												
												 modelo,
												 submarca,
												 marca,
												 combustible,
												 placas,
												 sustituto,
												 idUnidad,
												 vin, 
												 verGPS											 
												 )
				     SELECT [numeroEconomico], 
							modelo,
							SM.nombre submarca,
							M.nombre marca,
							combustible,
							placas, 
							sustituto, 
							U.idUnidad, 
							vin, 
							verGPS
					 FROM [dbo].[Unidades] U
					JOIN Partidas..Unidad UP ON U.idTipoUnidad = UP.idUnidad
					JOIN Partidas..SubMarca SM ON SM.idSubMarca = up.idSubMarca
					JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
					WHERE sustituto = 1 
					  AND U.idUnidad=@idUnidad 
				END
		FETCH NEXT FROM contact_cursor INTO @idUnidad
		END  
	CLOSE contact_cursor  
	DEALLOCATE contact_cursor

	IF(@tipo = 0)
		BEGIN
			SELECT * FROM #tablaTemporal T
			WHERE T.idUnidad NOT IN (SELECT [idUnidad] FROM [sustituto].[UnidadSustituto] WHERE estatus=0)
		END
	ELSE
		BEGIN 
		   	SELECT * FROM #tablaTemporal T
			WHERE T.idUnidad NOT IN (SELECT [idSustitutoUni] FROM [sustituto].[UnidadSustituto] WHERE estatus=0)
		END

	end
go

