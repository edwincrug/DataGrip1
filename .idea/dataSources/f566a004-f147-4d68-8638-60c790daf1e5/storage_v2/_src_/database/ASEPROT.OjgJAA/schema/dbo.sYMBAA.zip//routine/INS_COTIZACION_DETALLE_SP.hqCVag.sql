-- =============================================
-- Description:	Crea agrega los detalles de la cotización 
-- NOTA:  
-- [INS_COTIZACION_DETALLE_SP]@idTaller = 1,@idUsuario = 2, @idEstatusPartida = 1,@idOrden = 11

-- =============================================
/*
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición: Guarda los datos de las aplicaciones que acceden al sistema
	14/08/18		JEHR	Cambio el insert into cotizacion detalle para incluir las columnas
*/
  CREATE PROCEDURE [dbo].[INS_COTIZACION_DETALLE_SP]
  @idCotizacion NUMERIC(18,0),
  @costo DECIMAL(18,4),
  @cantidad INT,
  @venta DECIMAL(18,4) = 0,
  @idPartida NUMERIC(18,0),
  @idEstatusPartida INT
  AS
  BEGIN
	DECLARE @idCotizacionDetalle NUMERIC(18,0)
	
		IF NOT EXISTS( SELECT idCotizacionDetalle FROM [CotizacionDetalle] WHERE idCotizacion = @idCotizacion AND idPartida = @idPartida)
			BEGIN
				INSERT INTO [CotizacionDetalle]
					([idCotizacion],[costo],[cantidad],[venta],[idPartida],[idEstatusPartida])
					VALUES(@idCotizacion,@costo, @cantidad, @venta, @idPartida, @idEstatusPartida)
					SET @idCotizacionDetalle = @@IDENTITY
				SELECT @idCotizacionDetalle AS idCotizacionDetalle, 'Se agrego detalle' AS mensaje
			END
		ELSE
			BEGIN 
				UPDATE [CotizacionDetalle] 
					SET cantidad = @cantidad ,
						costo = @costo,
						venta = @venta,
						idEstatusPartida = @idEstatusPartida
					WHERE idCotizacion = @idCotizacion AND idPartida = @idPartida
				SELECT @idCotizacion AS idCotizacionDetalle, 'Se actualizo detalle' AS mensaje
			END 
  END

go

