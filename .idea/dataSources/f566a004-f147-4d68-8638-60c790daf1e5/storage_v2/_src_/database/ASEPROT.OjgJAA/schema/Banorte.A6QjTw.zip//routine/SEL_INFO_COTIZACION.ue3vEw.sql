-- =============================================
-- Author: YJH
-- Create date: 2018/12/10
-- Description: Obtiene datos de la cotizacion
-- EXEC Banorte.SEL_INFO_COTIZACION 53991
-- Modify: Christian Ochoa Nicolas
-- Modify date: 01/03/2019
-- Modify desc: Obtiene los datos de la cotización no importando si es de mano de obra o refacciones
-- Modify: Christian Ochoa Nicolas
-- Modify date: 13/03/2019
-- Modify desc: Obtiene los datos de la cotización conjuntando mano de obra y refacciones
-- Banorte.SEL_INFO_COTIZACION @cotizaciones = '<cotizaciones><cotizacion><idCotizacion>54434</idCotizacion></cotizacion><cotizacion><idCotizacion>54435</idCotizacion></cotizacion></cotizaciones>'
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_INFO_COTIZACION]
	@cotizaciones XML,
	@idCotizacion INT
AS
BEGIN	
	SET NOCOUNT ON;

	DECLARE @cotizacionTable TABLE (idCotizacion INT)

	INSERT INTO @cotizacionTable (idCotizacion)
	SELECT I.N.value('(idCotizacion)[1]', 'INT')
	FROM @cotizaciones.nodes('/cotizaciones/cotizacion') I(N)

	DECLARE @subtotal NUMERIC(18,2)

	SELECT @subtotal = SUM(cantidad * costo)
	FROM Cotizaciones C
	INNER JOIN @cotizacionTable CT
	ON C.idCotizacion = CT.idCotizacion
	INNER JOIN CotizacionDetalle CD
	ON C.idCotizacion = CD.idCotizacion
	AND CT.idCotizacion = CD.idCotizacion

	SELECT numeroCotizacion
		, consecutivoCotizacion
		, @subtotal AS subtotal
	FROM Cotizaciones C
	WHERE idCotizacion = @idCotizacion

	SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.SEL_INFO_COTIZACION to DevOps
go

