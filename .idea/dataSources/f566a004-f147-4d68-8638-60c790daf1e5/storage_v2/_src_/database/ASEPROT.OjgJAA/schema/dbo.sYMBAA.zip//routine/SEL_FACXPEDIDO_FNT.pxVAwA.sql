 /*
 EXEC
	SELECT * FROM ASEPROT.dbo.SEL_FACXPEDIDO_FNT('64779','64779', 13)
 */
 CREATE FUNCTION [dbo].[SEL_FACXPEDIDO_FNT] (@numSiniestro NVARCHAR(MAX), @ore_idorden nvarchar(max), @idSucursal INT)
 RETURNS @values TABLE(factura NVARCHAR(100), montoFactura DECIMAL(10,2), fechaFactura NVARCHAR(100))
AS 
BEGIN
	DECLARE @factura NVARCHAR(100)
	DECLARE @montoFactura DECIMAL(10,2)
	DECLARE @fechaFactura NVARCHAR(100)

	IF @idSucursal =5 --NISSAN
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAZM_Zaragoza].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAZM_Zaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden

	END 
	ELSE IF @idSucursal=10 --GM
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAAS_Satelite].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAAS_Satelite].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END 
	ELSE IF @idSucursal=11 --Ford
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAAAF_Body].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAAAF_Body].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=15 --Suzuki
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAAU_Universidad].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAAU_Universidad].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=8 --Hyundai
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAHyundai].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAHyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	/*ELSE IF @idMarca=6 --CRA
	BEGIN 
		select @factura=((LEFT(VTE_DOCTO, LEN(VTE_DOCTO) - PATINDEX('%[a-z]%', REVERSE(VTE_DOCTO)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(VTE_DOCTO, PATINDEX('%[0-9.-]%', VTE_DOCTO), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(VTE_DOCTO, PATINDEX('%[0-9.-]%', VTE_DOCTO), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GACRA_Cuautitlan].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GACRA_Cuautitlan].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		SO.ore_idSiniestro = @numSiniestro and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END*/
	ELSE IF @idSucursal=9 --Honda
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAHondaZaragoza].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAHondaZaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=2 --Volkswagen
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.31].[GADLA_VW].[dbo].SER_ORDEN SO
		JOIN [192.168.20.31].[GADLA_VW].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden

	END
	ELSE IF @idSucursal=3 --Seat
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.31].[GADLA_SEAT].[dbo].SER_ORDEN SO
		JOIN [192.168.20.31].[GADLA_SEAT].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=14 --Chevrolet
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAAA_Azcapo].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAAA_Azcapo].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=13 --Chrysler
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAAutoAngarTlahuac].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAAutoAngarTlahuac].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
		
		if(@factura is null or @factura='')
		begin 
			SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
			FROM [192.168.20.29].GAAutoAngarTepepan.[dbo].SER_ORDEN SO
			JOIN [192.168.20.29].GAAutoAngarTepepan.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
			WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
		end
	END
	ELSE IF @idSucursal= 7 --Hyundai Cam
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAVC_Hyundai].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAVC_Hyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=6 --Mitsubishi
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].[GAAutoAngarMitsu].[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].[GAAutoAngarMitsu].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=16 --Nissan Abasto
	BEGIN 
		SELECT @factura=AV.VTE_DOCTO, @montoFactura=AV.VTE_TOTAL, @fechaFactura=AV.VTE_FECHDOCTO
		FROM [192.168.20.29].GAZM_Abasto.[dbo].SER_ORDEN SO
		JOIN [192.168.20.29].GAZM_Abasto.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN
		WHERE (SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' AND AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	
	INSERT INTO @values (factura,montoFactura,fechaFactura) values( @factura, @montoFactura, @fechaFactura)

	RETURN
END
 go

