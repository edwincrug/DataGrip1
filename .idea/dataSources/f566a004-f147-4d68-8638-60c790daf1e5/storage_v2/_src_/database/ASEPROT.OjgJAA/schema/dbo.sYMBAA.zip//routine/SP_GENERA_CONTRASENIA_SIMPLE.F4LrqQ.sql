-- =============================================
-- Author:		<Javier Grijalva>
-- Create date: <05 de Octubre de 2020>
-- Description:	<Genera Contraseñas simples>

/*
DECLARE @R INT, @pass VARCHAR(10)
EXEC @R=SP_GENERA_CONTRASENIA_SIMPLE @p=1, @PASS=@pass OUT 
SELECT @R, @pass

DECLARE @pass VARCHAR(10)
EXEC SP_GENERA_CONTRASENIA_SIMPLE @p=1, @PASS=@pass OUT 
SELECT @pass
*/

-- =============================================
CREATE PROCEDURE [dbo].[SP_GENERA_CONTRASENIA_SIMPLE] 
	@p INT,
	@PASS nvarchar(max) output
AS
BEGIN		

		DECLARE
		@len INT = 8,
		@min TINYINT = 48,
		@range TINYINT = 74,
		@exclude VARCHAR(50) = '0:;<=>?@O[]`^\/',
		@output NVARCHAR(50) 
		 
		DECLARE @char CHAR
		SET @output = ''
		
		WHILE ( @len > 0 )
		BEGIN
			SELECT @char = CHAR(round(rand() * @range + @min, 0))
			IF (charindex(@char, @exclude) = 0 )
			BEGIN
				SET @output += @char
				SET @len = @len - 1
			END	 
		END
		DECLARE @posicion INT
		DECLARE @cambiar CHAR 
		
		SELECT @posicion = FLOOR(RAND()*(8-2+1)+2)
		
		SELECT @cambiar = SUBSTRING(@output, @posicion, 1)
		SELECT @output = REPLACE (@output, @cambiar, '*')
		SELECT @output = REPLACE (@output, '_', 'a')		

		SET @PASS = @output
		--select @output
		
	RETURN @p--@PASS

END
go

