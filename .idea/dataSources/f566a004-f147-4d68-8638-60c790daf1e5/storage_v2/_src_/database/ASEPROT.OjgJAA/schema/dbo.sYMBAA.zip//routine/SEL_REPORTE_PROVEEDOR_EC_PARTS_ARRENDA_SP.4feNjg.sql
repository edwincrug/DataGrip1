

-- =============================================
-- Author:		
-- Create date: <07/11/2017>
-- Description:	<Estado de cuenta por proveedor>
-- =============================================
--[SEL_REPORTE_PROVEEDOR_EC_PARTS_ARRENDA_SP] 1
CREATE PROCEDURE [dbo].[SEL_REPORTE_PROVEEDOR_EC_PARTS_ARRENDA_SP]
	@idOperacion	numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here	
	CREATE TABLE #ESTADODECUENTAASE(
	nombreOperacion     nvarchar(500),
	idProveedor				numeric(18,0),
	nombreComercial		nvarchar(500),
	concepto				nvarchar(200),
	total					decimal(18,2))

--****************************************************************************************************************
--***********************************************TOTAL TRABAJADO**************************************************
--****************************************************************************************************************

INSERT INTO #ESTADODECUENTAASE
select distinct
	'SISCO',
	R.idProveedor,
	R.NOMBRECOMERCIAL,
	'TRABAJADO',
	SUM(R.TOTAL)
from report.EC_DETALLEGAT_PARTSARRENDA R
where 
	R.IDESTATUSORDEN NOT IN (1,2,3,4,13)
	and R.idOperacion = @idOperacion
GROUP BY R.IDPROVEEDOR,R.NOMBRECOMERCIAL

--****************************************************************************************************************
--***********************************************POR FACTURAR*****************************************************
--****************************************************************************************************************

INSERT INTO #ESTADODECUENTAASE
select distinct
	'SISCO',
	R.IDPROVEEDOR,
	R.NOMBRECOMERCIAL,
	'POR FACTURAR',
	SUM(R.TOTAL)
from report.EC_DETALLEGAT_PARTSARRENDA R
where 
	R.IDESTATUSORDEN NOT IN (1,2,3,4,13) AND 
	R.FACTURA IS NULL --unicamente lo que tenemos en SISCO
	and R.idOperacion = @idOperacion
GROUP BY R.IDPROVEEDOR,R.NOMBRECOMERCIAL

--****************************************************************************************************************
--***********************************************PAGADO***********************************************************
--****************************************************************************************************************

INSERT INTO #ESTADODECUENTAASE
select distinct
	'SISCO',
	R.IDPROVEEDOR,
	R.NOMBRECOMERCIAL,
	'PAGADO',
	SUM(R.TOTAL)
from report.EC_DETALLEGAT_PARTSARRENDA R
where 
	R.IDESTATUSORDEN IN (12)-- not in 1,2,3,4,13
	AND R.SALDO = 0
	and R.idOperacion = @idOperacion
GROUP BY R.IDPROVEEDOR,R.NOMBRECOMERCIAL

--****************************************************************************************************************
--*****************************************FACTURADO NO PAGADO***********************************************
--****************************************************************************************************************

INSERT INTO #ESTADODECUENTAASE
select distinct
	'SISCO',
	R.IDPROVEEDOR,
	R.NOMBRECOMERCIAL,
	'FACTURADO',
	SUM(R.TOTAL)
from report.EC_DETALLEGAT_PARTSARRENDA R
where 
	R.IDESTATUSORDEN NOT IN (1,2,3,4,11,12,13)
	AND R.SALDO >0
	and R.idOperacion = @idOperacion AND factura NOT IN('S/F')
GROUP BY R.IDPROVEEDOR,R.NOMBRECOMERCIAL



--****************************************************************************************************************
--*****************************************FACTURAS ABONADAS******************************************************
--****************************************************************************************************************

INSERT INTO #ESTADODECUENTAASE
select distinct
	'SISCO',
	R.IDPROVEEDOR,
	R.NOMBRECOMERCIAL,
	'FACTURAS ABONADAS',
	SUM(R.TOTAL)
from report.EC_DETALLEGAT_PARTSARRENDA R

inner join DatosCopadeOrden DCO on DCO.idOrden = R.idOrden
inner join OrdenAgrupadaDetalle OAD on OAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
inner join OrdenAgrupada OA on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
inner join OrdenGlobalAbono OGA on OGA.numeroOrdenGlobal = OA.numero
where 
	R.IDESTATUSORDEN IN (11)
	AND R.SALDO >0
	and R.idOperacion = @idOperacion
GROUP BY R.IDPROVEEDOR,R.NOMBRECOMERCIAL

--****************************************************************************************************************
--*****************************************SELECCION DE ABONOS****************************************************
--****************************************************************************************************************

INSERT INTO #ESTADODECUENTAASE
select distinct
	'SISCO',
	R.IDPROVEEDOR,
	R.NOMBRECOMERCIAL,
	'SELECCION ABONOS',
	SUM(R.TOTAL)
from report.EC_DETALLEGAT_PARTSARRENDA R

inner join DatosCopadeOrden DCO on DCO.idOrden = R.idOrden
inner join OrdenAgrupadaDetalle OAD on OAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
inner join OrdenAgrupada OA on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
left join OrdenGlobalAbono OGA on OGA.numeroOrdenGlobal = OA.numero
where 
	R.IDESTATUSORDEN IN (11)
	AND R.SALDO >0
	and OGA.numeroOrdenGlobal is null
	and R.idOperacion = @idOperacion
GROUP BY R.IDPROVEEDOR,R.NOMBRECOMERCIAL

--****************************************************************************************************************
--**********************************************FINALIZADO********************************************************
--****************************************************************************************************************

INSERT INTO #ESTADODECUENTAASE
select distinct
	'SISCO',
	R.IDPROVEEDOR,
	R.NOMBRECOMERCIAL,
	'FINALIZADO',
	SUM(R.TOTAL)
from report.EC_DETALLEGAT_PARTSARRENDA R
where 
	R.IDESTATUSORDEN IN (12)
	AND R.SALDO >0
	and R.idOperacion = @idOperacion
GROUP BY R.IDPROVEEDOR,R.NOMBRECOMERCIAL

--****************************************************************************************************************
--****************************************************************************************************************
--****************************************************************************************************************

	SELECT 
	--P.idProveedor,
	--P.razonSocial,
	'SISCO' as nombreOperacion,
	idProveedor idProveedor,
	nombreComercial razonSocial,
	--ISNULL([POR FACTURAR],0) + ISNULL([POR FACTURAR],0) + ISNULL([FACTURADO],0) + ISNULL([PAGADO],0) + ISNULL([SELECCION ABONOS],0) + ISNULL([FACTURAS ABONADAS],0),
	ISNULL([TRABAJADO],0) 'TRABAJADO',
	ISNULL([POR FACTURAR],0) 'POR FACTURAR',
	ISNULL([PAGADO],0) 'PAGADO',
	ISNULL([FACTURADO],0) 'FACTURADO',	
	ISNULL([SELECCION ABONOS],0) 'SELECCION ABONOS',
	ISNULL([FACTURAS ABONADAS],0) 'FACTURAS ABONADAS',
	ISNULL([FINALIZADO],0) 'FINALIZADO'
FROM 
(select idProveedor, nombreComercial, concepto, total from #ESTADODECUENTAASE) as Result
PIVOT(
	SUM(TOTAL) FOR concepto in ([TRABAJADO],[POR FACTURAR],[FACTURADO],[PAGADO],[SELECCION ABONOS],[FACTURAS ABONADAS], [FINALIZADO]) 
) as PivotResult
ORDER BY nombreComercial


DROP TABLE #ESTADODECUENTAASE


	/*
	CREATE TABLE #ESTADODECUENTA(
		idProveedor numeric(18,0),
		concepto	nvarchar(200),
		total		decimal(18,2))

	--****************************************************************************************************************
	--***********************************************TOTAL ABONADAS***************************************************
	--****************************************************************************************************************
	INSERT INTO #ESTADODECUENTA
	SELECT
		C.idTaller, 'FACTURAS ABONADAS' , SUM(FC.total)
	FROM Ordenes O
	inner join ContratoOperacion CO on O.idContratoOperacion = CO.idContratoOperacion
	inner join Cotizaciones C on O.idOrden = C.idOrden
	inner join DatosCopadeOrden DCO on DCO.idOrden = O.idOrden
	inner join OrdenAgrupadaDetalle OAD on OAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
	inner join OrdenAgrupada OA on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
	inner join OrdenGlobalAbono OGA on OGA.numeroOrdenGlobal = OA.numero
	inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
  left join [cobranza].[VwStatusCotizacionBase] VSC ON VSC.[idCotizacion] = C.idCotizacion
	where 
		C.idTaller<>0
		and CO.idOperacion = @idOperacion
		and O.idEstatusOrden = 11
		and VSC.[DeudaDia] is not null
	group by C.idTaller
	
	--****************************************************************************************************************
	--********************************************SELECCION ABONOS****************************************************
	--****************************************************************************************************************


	INSERT INTO #ESTADODECUENTA
	SELECT
		C.idTaller, 'SELECCION ABONOS' , SUM(FC.total)
	FROM Ordenes O
	inner join ContratoOperacion CO on O.idContratoOperacion = CO.idContratoOperacion
	inner join Cotizaciones C on O.idOrden = C.idOrden
	inner join DatosCopadeOrden DCO on DCO.idOrden = O.idOrden
	inner join OrdenAgrupadaDetalle OAD on OAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
	inner join OrdenAgrupada OA on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
	left join OrdenGlobalAbono OGA on OGA.numeroOrdenGlobal = OA.numero
	inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
  inner join [cobranza].[VwStatusCotizacionBase] VSC ON VSC.[idCotizacion] = C.idCotizacion
	where 
		C.idTaller<>0
		and CO.idOperacion = @idOperacion
		and O.idEstatusOrden = 11
		and VSC.[DeudaDia] is not null
		and OGA.numeroOrdenGlobal is null
	group by C.idTaller

	--****************************************************************************************************************
	--***********************************************TOTAL PAGADO*****************************************************
	--****************************************************************************************************************
	INSERT INTO #ESTADODECUENTA
	SELECT
		C.idTaller, 'PAGADO' , SUM(FC.total)
	FROM Ordenes O
	inner join ContratoOperacion CO on O.idContratoOperacion = CO.idContratoOperacion
	inner join Cotizaciones C on O.idOrden = C.idOrden
	inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
	LEFT JOIN [cobranza].[VwStatusCotizacionBase] VSC ON VSC.[idCotizacion] = C.idCotizacion
	where 
		C.idTaller <> 0
		and CO.idOperacion = @idOperacion
		and O.idEstatusOrden NOT IN (13)
		and VSC.[DeudaDia] is null
	group by C.idTaller
	
	--****************************************************************************************************************
	--*********************************************TOTAL FACTURADO****************************************************
	--****************************************************************************************************************
	INSERT INTO #ESTADODECUENTA
	SELECT
		C.idTaller, 'FACTURADO' , SUM(FC.total)
	FROM Ordenes O
	inner join ContratoOperacion CO on O.idContratoOperacion = CO.idContratoOperacion
	inner join Cotizaciones C on O.idOrden = C.idOrden
	inner join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
	LEFT JOIN [cobranza].[VwStatusCotizacionBase] VSC ON VSC.[idCotizacion] = C.idCotizacion
	where 
		C.idTaller <> 0
		and CO.idOperacion = @idOperacion
		and O.idEstatusOrden NOT IN (11,13)
		and VSC.[DeudaDia] is not null
	group by C.idTaller

	--****************************************************************************************************************
	--***********************************************TOTAL X FACTURAR*************************************************
	--****************************************************************************************************************
	INSERT INTO #ESTADODECUENTA
	SELECT
		C.idTaller, 'POR FACTURAR' , SUM(CD.costo)
	FROM Ordenes O
	inner join ContratoOperacion CO on O.idContratoOperacion = CO.idContratoOperacion
	inner join Cotizaciones C on O.idOrden = C.idOrden
	inner join CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion  
	left join facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
	where 
		C.idTaller <> 0
		and CO.idOperacion = @idOperacion
		and O.idEstatusOrden IN (5,6,7,8,9,10)
		and FC.idCotizacion is null
	group by C.idTaller	

	--****************************************************************************************************************
	--***********************************************TOTALIZADO***************************************************
	--****************************************************************************************************************

	INSERT INTO #ESTADODECUENTA
	SELECT 
		C.idTaller, 'TRABAJADO', SUM(CD.COSTO)
	FROM Ordenes O 
	inner join ContratoOperacion CO on O.idContratoOperacion = CO.idContratoOperacion
	INNER JOIN Cotizaciones C on O.idOrden = C.idOrden
	inner join CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
	where 
		O.idEstatusOrden in (5,6,7,8,9,10,11,12,14)
		and C.idTaller<>0
		and CO.idOperacion = @idOperacion
	group by C.idTaller

	--****************************************************************************************************************
	--****************************************************************************************************************
	--****************************************************************************************************************

		SELECT 
		P.idProveedor,
		P.razonSocial,
		--ISNULL([POR FACTURAR],0) + ISNULL([POR FACTURAR],0) + ISNULL([FACTURADO],0) + ISNULL([PAGADO],0) + ISNULL([SELECCION ABONOS],0) + ISNULL([FACTURAS ABONADAS],0),
		ISNULL([TRABAJADO],0) 'TRABAJADO',
		ISNULL([POR FACTURAR],0) 'POR FACTURAR',
		ISNULL([FACTURADO],0) 'FACTURADO',
		ISNULL([PAGADO],0) 'PAGADO',
		ISNULL([SELECCION ABONOS],0) 'SELECCION ABONOS',
		ISNULL([FACTURAS ABONADAS],0) 'FACTURAS ABONADAS'
	FROM 
	(select idProveedor, concepto, total from #ESTADODECUENTA) as Result
	PIVOT(
		SUM(TOTAL) FOR concepto in ([TRABAJADO],[POR FACTURAR],[FACTURADO],[PAGADO],[SELECCION ABONOS],[FACTURAS ABONADAS]) 
	) as PivotResult
	inner join Partidas.dbo.Proveedor P on PivotResult.idProveedor = P.idProveedor
	ORDER BY P.razonSocial


	DROP TABLE #ESTADODECUENTA*/

END
go

