-- [SEL_NOTIFICACION_RECORDATORIO_SP] 'Recuerda que tienes un trabajo pendiente', '2017-06-11 04:30:00.000', 27, 109, '2017-06-09 12:34:33.110'
CREATE PROCEDURE [dbo].[SEL_NOTIFICACION_RECORDATORIO_SP]
	@texto NVARCHAR(1000), 
	@fecha DATETIME, 
	@idUsuario INT, 
	@fechaAlta DATETIME

AS

BEGIN
	DECLARE @html NVARCHAR(MAX) = ''
	DECLARE @cadena NVARCHAR(MAX) = ''
	DECLARE @nombreCompleto NVARCHAR(500) = ''
	DECLARE @numeroOrden NVARCHAR(500) = ''

	SELECT 
		 @nombreCompleto = nombreCompleto,
		 @cadena = correoElectronico
	FROM Usuarios 
	WHERE idUsuario=@idUsuario

	SET @html='
	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
	<body>
		<div style="font-family: Arial;">
			<div style="font-size: 16px;color: #0489B1;margin-left: 10px; text-align: center;">
					<h3>Recordatorio para ' + @nombreCompleto + ' </h3>
				</div>
				<div style="font-family: sans-serif;font-size: 14px;color: #2F4F4F;margin-left: 50px;">
			
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Recordatorio: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ @texto +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Fecha Recordatorio: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ CONVERT(VARCHAR(24),@fecha, 120 )  +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px;margin-top: 10px;">
					Usuario: <span  style="font-size: 14px;color: #000000;">'+ @nombreCompleto +'</span>
				</div>
				<div style="font-size: 14px;color: #0489B1;margin-left: 10px; margin-top: 10px;">
					Fecha Creación Recordatorio: <span  style="font-size: 14px;color: #000000; margin-top: 10px;">'+ CONVERT(VARCHAR(24),@fechaAlta, 120 ) +'</span>
				</div>
		</div>
	</body>
	</html> '

EXEC msdb.dbo.sp_send_dbmail 
		@profile_name='SMTPCallCenterTalleres',
		@recipients=@cadena,
		@subject = 'Notificación  de Recordatorios.',
		@body = @html,
		@importance= 'High',
		@body_format = 'HTML'
	SELECT enviado = 1

/*
	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name='SMTPCallCenterTalleres',
		@recipients='adolfo.martinez@grupoandrade.com.mx',
		@subject ='hola',
		@body = @html,
		@reply_to= 'adolfo.martinez@grupoandrade.com.mx',
		@copy_recipients = 'adolfo.martinez@grupoandrade.com.mx',
		@importance= 'High',
		@body_format = 'HTML'

	SELECT enviado = 1
*/
END
go

