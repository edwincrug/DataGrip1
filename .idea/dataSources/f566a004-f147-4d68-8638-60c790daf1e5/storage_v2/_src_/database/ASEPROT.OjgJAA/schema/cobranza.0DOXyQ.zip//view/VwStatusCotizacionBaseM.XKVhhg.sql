


CREATE VIEW [cobranza].[VwStatusCotizacionBaseM]
AS
SELECT 
     
      VwCPI.[idCotizacion]     
     ,VwCPI.[numFactura] 
	 ,VwIPS.[NumFactura] as [NumFacturaF]	 
	  --,CASE WHEN (VwIPS.[DeudaDia]) < 0.01
	  -- THEN NULL
	  -- ELSE (VwIPS.[DeudaDia])
	  -- END AS [DeudaDia]
	  ,VwIPS.[DeudaDia] as [DeudaDia] 

  FROM [cobranza].[VwCotizacionProvInvoiceDef] VwCPI

INNER JOIN [cobranza].[VwInvoiceProvSaldoDiaDef] VwIPS
        ON VwIPS.[NumFactura]  COLLATE Modern_Spanish_CI_AS = VwCPI.[numFactura] COLLATE Modern_Spanish_CI_AS

go

