
CREATE PROCEDURE [Banorte].[SEL_TALLERBYID] 
	 @idTaller INT
AS
BEGIN
SELECT DISTINCT
			UPPER(PP.idProveedor) as Id
			,UPPER(PP.nombreComercial) as Nombre
			,UPPER(PP.direccion) as Direccion
			,PP.mail
			,PP.isGenerico
			,PP.numInterlocutor
			 FROM [Partidas].[dbo].[Proveedor] PP
			 where PP.idProveedor =@idTaller
END
go

grant execute, view definition on Banorte.SEL_TALLERBYID to DevOps
go

