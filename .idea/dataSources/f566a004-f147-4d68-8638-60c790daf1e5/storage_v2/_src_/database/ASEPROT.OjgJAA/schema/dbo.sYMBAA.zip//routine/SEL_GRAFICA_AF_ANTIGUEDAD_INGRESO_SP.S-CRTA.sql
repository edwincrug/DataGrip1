-- [dbo].[SEL_GRAFICA_AF_ANTIGUEDAD_INGRESO_SP]  3
CREATE PROCEDURE [dbo].[SEL_GRAFICA_AF_ANTIGUEDAD_INGRESO_SP]
 @idContratoOperacion numeric(18,0)
AS
BEGIN

DECLARE @idOperacion as numeric(18,0)
SELECT @idOperacion = idOperacion FROM ContratoOperacion where idContratoOperacion = @idContratoOperacion

SELECT  
		'30' as label
		,(
			select count(1) as total 
				from(
					select  ISNULL(datediff(DAY,max(ord.fechaCita),GETDATE()), 121) dias, uni.idUnidad
					from Unidades uni
					left join Ordenes ord on ord.idUnidad = uni.idUnidad and ord.idEstatusOrden in(5,6,7,8,9,10,11,12)  
					group by uni.idUnidad
					having ISNULL(datediff(DAY,max(ord.fechaCita),GETDATE()), 121) between 0 and 30
				) as DATA
				INNER JOIN Unidades unn ON unn.idUnidad = DATA.idUnidad
				WHERE 
					unn.idOperacion = @idOperacion 
				
		) as value
		union all
		select 
		'60' as label
	,(
	
			select count(1) as total 
					from(
						select  ISNULL(datediff(DAY,max(ord.fechaCita),GETDATE()), 121) dias, uni.idUnidad
						from Unidades uni
						left join Ordenes ord on ord.idUnidad = uni.idUnidad and ord.idEstatusOrden in(5,6,7,8,9,10,11,12)  
						group by uni.idUnidad
						having ISNULL(datediff(DAY,max(ord.fechaCita),GETDATE()), 121) between 31 and 60
					) as DATA
					INNER JOIN Unidades unn ON unn.idUnidad = DATA.idUnidad
					WHERE 
						unn.idOperacion = @idOperacion 
				
				
		) as value
		union all
		select 
		'90' as label
	,(
					select count(1) as total 
						from(
							select  ISNULL(datediff(DAY,max(ord.fechaCita),GETDATE()), 121) dias, uni.idUnidad
							from Unidades uni
							left join Ordenes ord on ord.idUnidad = uni.idUnidad and ord.idEstatusOrden in(5,6,7,8,9,10,11,12)  
							group by uni.idUnidad
							having ISNULL(datediff(DAY,max(ord.fechaCita),GETDATE()), 121) between 61 and 90
						) as DATA
						INNER JOIN Unidades unn ON unn.idUnidad = DATA.idUnidad
						WHERE 
							unn.idOperacion = @idOperacion 
		) as value
		union all
			select  
		'120' as label
,(
				select count(1) as total 
				from(
					select  ISNULL(datediff(DAY,max(ord.fechaCita),GETDATE()), 121) dias, uni.idUnidad
					from Unidades uni
					left join Ordenes ord on ord.idUnidad = uni.idUnidad and ord.idEstatusOrden in(5,6,7,8,9,10,11,12)  
					group by uni.idUnidad
					having ISNULL(datediff(DAY,max(ord.fechaCita),GETDATE()), 121) >= 91
				) as DATA
				INNER JOIN Unidades unn ON unn.idUnidad = DATA.idUnidad
				WHERE 
					unn.idOperacion = @idOperacion 
) as value


END
go

