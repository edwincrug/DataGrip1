-- =============================================
-- Author:		<YJH>
-- Create date: <2018/10/23>
-- Description:	<Actualiza fecha promesa de pago y comentarios de cuentas por cobrar de Genericos>
-- [BANORTE].[UPD_FECHAPROMESAPAGO_GENERICOS] 26, 1
-- =============================================

CREATE PROCEDURE [Banorte].[UPD_FECHAPROMESAPAGO_GENERICOS]
	@idContratoOperacion int,
	@isProduction int 	 
AS
BEGIN
	DECLARE @dbBanorte NVARCHAR(MAX)

	DECLARE @facturasProveedor as TABLE ( idOrden int, numeroOrden nvarchar(200), numeroReclamo nvarchar(200), 
		facturaProveedor nvarchar(max), idCotizacion int, servidor nvarchar(100),  facturaCeros nvarchar(100))

	DECLARE @pedidosEntregados as TABLE ( idOrden int, pedidosEntregados int, totalPedidos int) 
	
	DECLARE @doctosTable as TABLE (valeInicial int, valeFinal int, factura int, entrega int, idCotizacion int, fechaEvidenciaCompleta DateTime null, provisionado varchar(100), idOrden int)
	
	DECLARE @provisionBanorte AS TABLE (idProvision [int] IDENTITY(1,1), idOrden int, numeroOrden nvarchar(max),
	                                    numeroReclamo nvarchar(max), facturaBanorte nvarchar(max), fechaProvision datetime, 
										fechaPromesa datetime, contraRecibo nvarchar(200), fechaContraRecibo datetime, fechaFactura datetime) 	

	DECLARE @cuentasPorPagar AS TABLE (idCuenta [int] IDENTITY(1,1) , idOrden int, numeroOrden nvarchar(max), numeroReclamo nvarchar(max), facturaBanorte nvarchar(max), fechaProvision datetime, fechaPromesa datetime, facturaProveedor nvarchar(max), servidor nvarchar(100), comentario nvarchar(max), comentarioBanorte nvarchar(max), tablaProveedor nvarchar(100), facturasinCeros nvarchar(max))

	DECLARE @dbProveedor NVARCHAR(100)

	IF(@isProduction = 1)
	    BEGIN
		    SELECT @dbBanorte= SERVER+'.'+DBProduccion
			FROM ASEPROT.dbo.ContratoOperacionFacturacion 
			WHERE idContratoOperacion =  @idContratoOperacion			
		END
	ELSE
		BEGIN
	        SELECT @dbBanorte=DB
			FROM ASEPROT.dbo.ContratoOperacionFacturacion
			WHERE idContratoOperacion = @idContratoOperacion							
		END

	insert into @facturasProveedor
		select O.idOrden, O.numeroOrden, S.numeroReclamo, FC.numFactura, C.idCotizacion, 
		'[192.168.20.29]',
		SUBSTRING(FC.numFactura, 0, PATINDEX('%[0-9]%', FC.numFactura)) +
        REPLICATE('0', ((11-PATINDEX('%[0-9]%', FC.numFactura)) - LEN(SUBSTRING(FC.numFactura, PATINDEX('%[0-9]%', FC.numFactura), len(FC.numFactura)-PATINDEX('%[0-9]%', FC.numFactura))))) + SUBSTRING(FC.numFactura, PATINDEX('%[0-9]%', FC.numFactura), len(FC.numFactura)-PATINDEX('%[0-9]%', FC.numFactura)+1)
		--(SELECT [dbo].[SEL_FACBYPEDIDO_FN](PREF.pre_pedidobpro, M.idMarca, PREF.pre_idcliente))
	from ASEPROT.dbo.Ordenes O
	inner join ASEPROT.dbo.Cotizaciones C on C.idOrden = O.idOrden and C.idEstatusCotizacion = 3
	inner join ASEPROT.DBO.facturaCotizacion FC on FC.idCotizacion = C.idCotizacion
	inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden and SOC.idCotizacionSISCO= C.idCotizacion
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
	inner join RefaccionMultiMarca.Operacion.Cotizacion OC on OC.idCotizacion = SOC.idCotizacion
	inner join RefaccionMultiMarca.[Seguridad].[UsuarioModuloSeguridad] UMS ON UMS.idUsuario = OC.idUsuario and UMS.idProveedorGenerico=1
	inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
	inner join RefaccionMultiMarca.Catalogo.Marca M on M.idMarca = U.marca
	where  O.idContratoOperacion=@idContratoOperacion and UMS.idProveedorGenerico=1--and U.marca  not in (16, 17,20, 21,19) --Mitsubishi,Toyota, Mazda, Renault, BMW
	--and O.numeroOrden ='26-12599-569'
	order by O.idOrden		
		
	insert into @pedidosEntregados
		select O.idOrden, 1, 1
	from ASEPROT.dbo.Ordenes O				
	where  O.idContratoOperacion=@idContratoOperacion -- and O.numeroOrden ='26-11951-118'
	group by O.idOrden
	
	insert into @doctosTable
	select 
		ISNULL((select top 1 1 from aseprot..evidencias  where idordenservicio=FP.idOrden and descripcionEvidencia='ValeInicial'),0) valeInicial,
		ISNULL((select top 1 1 from aseprot..evidencias  where idordenservicio=FP.idOrden and descripcionEvidencia='ValeFinal'),0) valeFinal,
		ISNULL((select top 1 1 from aseprot..facturaCotizacion  where idCotizacion = FP.idCotizacion),0) factura,
		1 entrega,
		FP.idCotizacion,
		(select MAX(fechaInicial) from aseprot..HistorialEstatusOrden where idOrden = FP.idOrden and idEstatusOrden = 8) fechaEvidenciaCompleta,
		(CASE WHEN PE.pedidosEntregados = 0 THEN 'Pendiente Entrega' ELSE 
			CASE WHEN PE.totalPedidos > PE.pedidosEntregados THEN 'Entrega Parcial' ELSE 'Entrega Total' END END) provisionado,
		FP.idOrden
	from @facturasProveedor FP
	inner join @pedidosEntregados PE on PE.idOrden = FP.idOrden
	where FP.facturaCeros is not null
	
	insert into @provisionBanorte
		select distinct O.idOrden, O.numeroOrden, S.numeroReclamo, AC.COP_IDDOCTO,
		convert(datetime, C.fechaContrarecibo, 103),
		dateadd(day,30,convert(datetime, C.fechaContrarecibo, 103)) as fechaPromesa, 
		C.numeroContraRecibo, convert(datetime, C.fechaContrarecibo, 103), convert(datetime, CC.CCP_FECHADOCTO, 103)
	from ASEPROT.dbo.Ordenes O
	left join [192.168.20.29].[GAAutoExpressBanorte].dbo.ADE_COPADE AC on O.numeroOrden = AC.COP_ORDENGLOBAL COLLATE Modern_Spanish_CI_AS
	--left join [GAAutoExpressBanorte].dbo.ADE_COPADE AC on O.numeroOrden = AC.COP_ORDENGLOBAL COLLATE Modern_Spanish_CI_AS
	left join [192.168.20.29].[GAAutoExpressBanorte].dbo.[Con_Car012018] CC on AC.COP_IDDOCTO = CC.CCP_IDDOCTO
	inner join RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion SOC on SOC.idOrden = O.idOrden
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = SOC.idSiniestro
	left join ASEPROT.dbo.DatosCopade D on D.numeroCopade = O.numeroOrden
	left join [ASEPROT].[dbo].[ContrareciboDatosCopade] CDC on CDC.idDatosCopade = D.idDatosCopade
	left join [ASEPROT].[dbo].[Contrarecibo] C on C.idContrarecibo =CDC.idContrarecibo
	where O.idContratoOperacion=@idContratoOperacion 
	--and O.numeroOrden ='26-12599-569'
	 order by O.numeroOrden

	insert into @cuentasPorPagar  	
		select  FP.idOrden, FP.numeroOrden, FP.numeroReclamo, PB.facturaBanorte, PB.fechaProvision, PB.fechaPromesa, 
		FP.facturaCeros, FP.servidor,------Agencia
		'Siniestro ' + FP.numeroReclamo  + ' Orden ' + FP.numeroOrden + ' «SISRE: ' + 
		cast(DT.valeInicial + DT.valeFinal + DT.factura +
		--(case when DT.provisionado ='Entrega Total' then DT.factura else 0 end)	
		+ DT.entrega as varchar) + '/4 Documentos' +
		SUBSTRING((case when DT.valeInicial = 1 then ' Vale Inicial,' else '' end + 
		           case when DT.valeFinal = 1 then ' Vale Final,' else '' end + 
				   case when DT.factura = 1 then ' Factura,' else '' end + 
				   case when DT.entrega = 1 then ' Entrega,' else '' end), 0, 
				   len((case when DT.valeInicial = 1 then ' Vale Inicial,' else '' end + 
				   case when DT.valeFinal = 1 then ' Vale Final,' else '' end + 
				   case when DT.factura = 1 then ' Factura,' else '' end + 
				   case when DT.entrega = 1 then ' Entrega,' else '' end))) + 
		(CASE WHEN DT.fechaEvidenciaCompleta is not null THEN ';Fecha Evidencia Completada: ' + 
		CONVERT(VARCHAR(10), DT.fechaEvidenciaCompleta, 103) ELSE '' END) + 
		'; Factura Banorte: '+ ISNULL(PB.facturaBanorte, 'NO Provisionada') + ' Fecha: '+ convert(nvarchar(MAX), ISNULL(PB.fechaFactura,''),103)
		+'; ' + DT.provisionado +
		(case when PB.contraRecibo is not null 
		then '; Contra Recibo: ' + PB.contraRecibo  + ', Fecha: ' + convert(nvarchar(MAX), PB.fechaProvision, 103) 
		 else '' end )
		 + '»',-----Banorte
		 'Siniestro ' + FP.numeroReclamo  + ' Orden ' + FP.numeroOrden + 
		(case when PB.contraRecibo is not null 
		then '; Contra Recibo: ' + PB.contraRecibo  + ', Fecha: ' + convert(nvarchar(MAX), PB.fechaProvision, 103) 
		 else '' end ) ,		 
		  '', FP.facturaProveedor
	from @doctosTable DT
	inner join @facturasProveedor FP on FP.idOrden = DT.idOrden  and FP.idCotizacion = DT.idCotizacion
	left join @provisionBanorte PB on PB.idOrden = FP.idOrden
	group by FP.numeroOrden, FP.idCotizacion, FP.numeroReclamo , DT.valeInicial, DT.valeFinal, DT.factura, DT.entrega, 
		     DT.fechaEvidenciaCompleta, DT.provisionado, PB.facturaBanorte,  FP.idOrden, FP.servidor, FP.facturaCeros, 
			 PB.fechaProvision, PB.fechaPromesa, FP.facturaProveedor, PB.contraRecibo, PB.fechaContraRecibo, PB.fechaFactura
	order by FP.numeroOrden

Declare @id int,
        @count int

Set @id=1
select @count=count(*)from @cuentasPorPagar
declare @update nvarchar(max) =''
declare @updateBanorte nvarchar(max) =''
declare @query nvarchar(max) =''
declare @anio nvarchar(20) = ''
---------------------------------ACTUALIZAR CUENTAS POR PAGAR -----------------

while @id<=@count
begin	
if ((select facturaBanorte from @cuentasPorPagar where idCuenta=@id) is not null)
begin
	select @query = 'SELECT @anio=Vcc_AnNo FROM '+ (select servidor from @cuentasPorPagar where idCuenta=@id) +'.[GAAutoExpressBanorte].[dbo].[VIS_CONCAR01] 
		WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO = ''' +(select facturaBanorte from @cuentasPorPagar where idCuenta=@id) + ''''
	

	EXEC SP_EXECUTESQL 
        @Query  = @query
      , @Params = N'@anio nvarchar(100) OUTPUT'
      , @anio = @anio OUTPUT	

	if(@anio<>'')
	BEGIN
		update @cuentasPorPagar set tablaProveedor = (select tabla FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio)
		where idCuenta=@id
		IF(@isProduction = 1)		
				SELECT @dbProveedor=server+'.'+db FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio			
		ELSE			
			SELECT @dbProveedor=db FROM ASEPROT.dbo.ConCar WHERE idContratoOperacion=@idContratoOperacion AND fecha=@anio								

		if((select tablaProveedor from @cuentasPorPagar where idCuenta=@id) is not null and (select fechaPromesa from @cuentasPorPagar where idCuenta=@id) is not null)
			begin			
				if((select comentario from @cuentasPorPagar where idCuenta=@id) is not null and (select comentario from @cuentasPorPagar where idCuenta=@id) <> '')
				select @updateBanorte ='  update '+@dbProveedor+'.dbo.'+(select tablaProveedor from @cuentasPorPagar where idCuenta=@id) +
				' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + ''', CCP_FECHPROMPAG= ''' +
				CONVERT(VARCHAR(15), (select fechaPromesa from @cuentasPorPagar where idCuenta=@id), 103)  +
				''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO = ''' + (select facturasinCeros from @cuentasPorPagar where idCuenta=@id) + ''' '	

				if((select comentarioBanorte from @cuentasPorPagar where idCuenta=@id) is not null and (select comentarioBanorte from @cuentasPorPagar where idCuenta=@id) <> '')
				select @update = 'update '+@dbBanorte+'.dbo.'+(select tablaProveedor from @cuentasPorPagar where idCuenta=@id) +
				' set CCP_OBSGEN = '''+ (select comentarioBanorte from @cuentasPorPagar where idCuenta=@id) + ''', CCP_FECHPROMPAG= ''' +
				CONVERT(VARCHAR(15), (select fechaPromesa from @cuentasPorPagar where idCuenta=@id), 103)  +
				''' where CCP_TIPODOCTO = ''FAC'' and CCP_IDDOCTO='''+(select facturaBanorte from @cuentasPorPagar where idCuenta=@id)+''''
			end
		else
			begin 		
				if((select tablaProveedor from @cuentasPorPagar where idCuenta=@id) is not null)		
					begin						
						if((select comentario from @cuentasPorPagar where idCuenta=@id) is not null and (select comentario from @cuentasPorPagar where idCuenta=@id) <> '')
						select @updateBanorte = '  update  '+@dbProveedor+'.dbo.'+(select tablaProveedor from @cuentasPorPagar where idCuenta=@id) +
						 ' set CCP_OBSGEN = '''+ (select comentario from @cuentasPorPagar where idCuenta=@id) + 
						 ''' where CCP_TIPODOCTO=''FAC'' and CCP_IDDOCTO = ''' + (select facturasinCeros from @cuentasPorPagar where idCuenta=@id) + '''  '	

						if((select comentarioBanorte from @cuentasPorPagar where idCuenta=@id) is not null and (select comentarioBanorte from @cuentasPorPagar where idCuenta=@id) <> '')
						 select @update = 'update '+@dbBanorte+'.dbo.'+(select tablaProveedor from @cuentasPorPagar where idCuenta=@id) +
						' set CCP_OBSGEN = '''+ (select comentarioBanorte from @cuentasPorPagar where idCuenta=@id) + 
						''' where CCP_TIPODOCTO = ''FAC'' and CCP_IDDOCTO='''+(select facturaBanorte from @cuentasPorPagar where idCuenta=@id)+''''
					end 
			end								
	END
	end
	print @update
	print @updateBanorte
	execute (@update)
	execute(@updateBanorte)
	select @id=@id+1	
	end

	select * from @cuentasPorPagar

END

go

grant execute, view definition on Banorte.UPD_FECHAPROMESAPAGO_GENERICOS to DevOps
go

