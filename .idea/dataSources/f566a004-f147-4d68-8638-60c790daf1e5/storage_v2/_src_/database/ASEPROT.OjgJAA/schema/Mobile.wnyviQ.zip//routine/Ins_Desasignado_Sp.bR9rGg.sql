-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 08/08/2018
-- Description:	Actualizar la unidad por id, solo para unidades registradas en app banorte
-- EXEC [ASEPROT].[Mobile].Ins_Desasignado_Sp 4991,123
-- =============================================
CREATE PROCEDURE [Mobile].Ins_Desasignado_Sp
	@idUnidad				int
	,@idUsuario				int
AS

BEGIN

	IF EXISTS (SELECT 
		uuco.idUsuario
		,uuco.idUnidad
		,u.vin
		,u.placas
		,u.noPoliza
		,u.descripcion
		,GETDATE() desasignado
		,0 visto
	FROM [ASEPROT].[dbo].[usuarioUnidadContratoOperacion] uuco 
		INNER JOIN [ASEPROT].[dbo].[Unidades] u ON uuco.idUnidad = u.idUnidad
		INNER JOIN [ASEPROT].[dbo].[Usuarios] us ON uuco.idUsuario = us.idUsuario
	WHERE uuco.idUnidad = @idUnidad
		AND u.idUnidad = @idUnidad
		AND uuco.idUsuario <> @idUsuario)
	BEGIN

		INSERT INTO [ASEPROT].[Mobile].[UsuarioUnidadContratoOperacionDesAsignado] 
		(
			idUsuario
			,idUnidad
			,vin
			,placas
			,noPoliza
			,descripcion
			,desasignado
			,visto
		)
		SELECT 
			uuco.idUsuario
			,uuco.idUnidad
			,u.vin
			,u.placas
			,u.noPoliza
			,u.descripcion
			,GETDATE() desasignado
			,0 visto
		FROM [ASEPROT].[dbo].[usuarioUnidadContratoOperacion] uuco 
			INNER JOIN [ASEPROT].[dbo].[Unidades] u ON uuco.idUnidad = u.idUnidad
			INNER JOIN [ASEPROT].[dbo].[Usuarios] us ON uuco.idUsuario = us.idUsuario
		WHERE uuco.idUnidad = @idUnidad
			AND u.idUnidad = @idUnidad
			AND uuco.idUsuario <> @idUsuario

	END

END
go

grant execute, view definition on Mobile.Ins_Desasignado_Sp to DevOps
go

