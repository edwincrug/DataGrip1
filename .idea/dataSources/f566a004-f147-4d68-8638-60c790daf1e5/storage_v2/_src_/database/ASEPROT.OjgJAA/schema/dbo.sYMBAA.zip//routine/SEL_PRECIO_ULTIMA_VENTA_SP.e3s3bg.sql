-- =============================================
-- Author:		Sistemas
-- Create date: 13 12 2017
-- SEL_PRECIO_ULTIMA_VENTA_SP 
-- =============================================
CREATE PROCEDURE [dbo].[SEL_PRECIO_ULTIMA_VENTA_SP]
	@idOrden INT,
	@idPartida INT,
	@idContratoOperacion INT
	 
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @idUnidad INT 
	SELECT @idUnidad = idUnidad FROM Ordenes WHERE idOrden=@idOrden 

	SELECT TOP 1 CD.venta, C.fechaCotizacion, O.numeroOrden FROM Ordenes O
		JOIN Cotizaciones C on C.idOrden = O.idOrden
		JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	WHERE CD.idPartida = @idPartida 
		AND O.idContratoOperacion = @idContratoOperacion 
		AND  O.idUnidad = @idUnidad
	ORDER BY C.fechaCotizacion DESC
END

go

