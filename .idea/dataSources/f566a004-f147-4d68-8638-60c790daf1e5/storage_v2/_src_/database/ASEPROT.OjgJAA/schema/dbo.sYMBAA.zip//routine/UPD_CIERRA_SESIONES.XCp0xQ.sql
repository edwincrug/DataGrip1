-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03/06/2017
-- =============================================
CREATE PROCEDURE [dbo].[UPD_CIERRA_SESIONES] 
AS
BEGIN
	UPDATE [dbo].[HistorialLogin]
	SET FechaFin = GETDATE()
	WHERE FechaFin IS NULL
END
go

