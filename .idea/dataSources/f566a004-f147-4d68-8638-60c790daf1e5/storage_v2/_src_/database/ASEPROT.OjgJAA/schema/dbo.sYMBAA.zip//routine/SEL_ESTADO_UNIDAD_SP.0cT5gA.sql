CREATE PROCEDURE [dbo].[SEL_ESTADO_UNIDAD_SP] 

AS
BEGIN

	SELECT idCatalogoEstadoUnidad, descripcionEstadoUnidad
	FROM CatalogoEstadoUnidad

END
go

