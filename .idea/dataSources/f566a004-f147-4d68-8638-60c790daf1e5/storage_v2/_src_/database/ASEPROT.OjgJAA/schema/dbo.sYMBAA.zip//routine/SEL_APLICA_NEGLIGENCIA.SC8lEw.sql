-- =============================================
-- Description:	Obtengo si aplica para el boton de negligencia
-- =============================================
-- [dbo].[SEL_APLICA_NEGLIGENCIA] 48
CREATE PROCEDURE [dbo].[SEL_APLICA_NEGLIGENCIA]
@idOperacion numeric(18,0)
AS
BEGIN
SELECT [IdParametroGeneralOperacion],IdParametroGeneral
FROM [ASEPROT].[dbo].[ParametrosGeneralOperacion] WHERE IdParametroGeneral=9 AND IdOperacion = @idOperacion
END
go

