-- =============================================
-- Author:		Sahirely Yam
-- Create date: 28 12 2017
-- =============================================
CREATE PROCEDURE [dbo].[EXT_INS_CONTRATO_OPERACION_USUARIO_GERENTE_SP]
	@idContratoOperacionUsuario int,
	@idGerencias int
AS
BEGIN
	
	IF (EXISTS (SELECT 1 FROM ContratoOperacionUsuario WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario))
		BEGIN
			
			IF NOT EXISTS (SELECT 1 FROM [ContratoOperacionUsuarioGerente] WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario)
				BEGIN					
					
					INSERT INTO [ContratoOperacionUsuarioGerente] VALUES(@idContratoOperacionUsuario, @idGerencias)
					
					SELECT 2 as respuesta, 'Se asigno correctamente la versión del sistema para el usuario.' as mensaje					
					
				END
			ELSE 
				BEGIN
					
					UPDATE [ContratoOperacionUsuarioGerente] SET idGerencias = @idGerencias WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario
					
					SELECT 1 as respuesta, 'Se actualizó correctamente la versión del sistema para el usuario.' as mensaje
				END
			
		END
	ELSE
		BEGIN
			SELECT 0 as respuesta, 'No se pudo asignar la operación ya que los datos son erroneos.' as mensaje
		END
		
END
go

