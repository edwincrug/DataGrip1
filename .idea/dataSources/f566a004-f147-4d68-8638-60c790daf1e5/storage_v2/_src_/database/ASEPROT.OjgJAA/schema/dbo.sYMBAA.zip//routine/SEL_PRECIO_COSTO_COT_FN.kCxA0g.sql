-- select [dbo].[SEL_PRECIO_COSTO_COT_FN](6,1,4)
CREATE FUNCTION [dbo].[SEL_PRECIO_COSTO_COT_FN](@idCotizacion INT, @idContratoOperacion INT, @tipoConsulta INT, @idUsuario INT, @idRol INT)

RETURNS NUMERIC(18,2)
AS
BEGIN
DECLARE @costo NUMERIC(18,2) = 0
DECLARE @numero TABLE(estatusCotizacion int, estatusPartida int)

IF(@tipoConsulta = 1)
insert @numero values(1, 1)
IF(@tipoConsulta = 2)
insert @numero values(1, 1)
insert @numero values(2, 2)
IF(@tipoConsulta = 3)
insert @numero values(3, 2)
IF(@tipoConsulta = 4)
insert @numero values(2, 1)
insert @numero values(3, 2)


if (@idRol <> 4)
	begin	

		SELECT @costo=ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			--INNER JOIN [Partidas].[dbo].[Partida] P	ON CD.idPartida = P.idPartida
			--INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
			--INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		WHERE CD.idCotizacion = @idCotizacion 
		--AND CO.idContratoOperacion = @idContratoOperacion
		AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
		AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero)	
	
	end
else
	begin

		declare @idOperacion INT = (select idOperacion from ContratoOperacion where idContratoOperacion = @idContratoOperacion)

		declare @tablaProveedoresAsignados table(idProveedor int)
		insert into @tablaProveedoresAsignados
		select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)

		SELECT @costo=ISNULL(SUM((ISNULL(CD.costo,0) * ISNULL(CD.cantidad,0))),0) 
			FROM [dbo].[Cotizaciones] C 
			INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
			--INNER JOIN [Partidas].[dbo].[Partida] P	ON CD.idPartida = P.idPartida
			--INNER JOIN [dbo].[Ordenes]	O ON C.idOrden = O.idOrden
			--INNER JOIN [dbo].[ContratoOperacion] CO ON O.idContratoOperacion = CO.idContratoOperacion
		WHERE CD.idCotizacion = @idCotizacion 
		--AND CO.idContratoOperacion = @idContratoOperacion
		AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
		AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero)	
		AND C.idTaller in (select idProveedor from @tablaProveedoresAsignados)

	end
	
	
	RETURN @costo

END

/* SELECT @costo=ISNULL(SUM((ISNULL(PPCosto.costo,0) * ISNULL(CD.cantidad,0))),0) 
		FROM Cotizaciones C JOIN Ordenes O ON O.idOrden = C.idOrden 
		JOIN [Ordenes] _ORD ON C.idOrden = _ORD.idOrden
		JOIN [ContratoOperacion]	CO ON _ORD.idContratoOperacion = CO.idContratoOperacion
		JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
		JOIN [Partidas].[dbo].[Proveedor] _PRO ON C.idTaller = _PRO.idProveedor
		JOIN [Partidas].[dbo].[ProveedorCotizacion]	_PROCO  ON _PROCO.idProveedor = _PRO.idProveedor
		JOIN [Partidas].[dbo].[ProveedorPartida] PPCosto ON PPCosto.idPartida = CD.idPartida 
	WHERE O.idOrden = @idOrden 
	AND CO.idContratoOperacion = @idContratoOperacion
	AND CD.idEstatusPartida IN(select estatusPartida from @numero) 
	AND C.idEstatusCotizacion IN(select estatusCotizacion from @numero)	
*/
	/* ISNULL((SELECT SUM( _PROPA.costo * _CODE.cantidad ) as SumaCosto
			FROM [CotizacionDetalle] _CODE
			INNER JOIN [Cotizaciones] _COTI	ON _CODE.idCotizacion = _COTI.idCotizacion
			INNER JOIN [Ordenes] _ORD ON _COTI.idOrden = _ORD.idOrden
			INNER JOIN [ContratoOperacion]	_COPE ON _ORD.idContratoOperacion = _COPE.idContratoOperacion
			INNER JOIN [Partidas].[dbo].[Proveedor]	_PRO ON _COTI.idTaller = _PRO.idProveedor
			INNER JOIN [Partidas].[dbo].[ProveedorCotizacion] _PROCO ON _PROCO.idProveedor = _PRO.idProveedor
			INNER JOIN [Partidas].[dbo].[ProveedorPartida] _PROPA ON _CODE.idPartida = _PROPA.idPartida AND _PROCO.idProveedorCotizacion = _PROPA.idProveedorCotizacion
			WHERE _COTI.idEstatusCotizacion = 3 
				AND _CODE.idEstatusPartida = 2 AND _ORD.idZona = @idZona
				AND _COPE.idContratoOperacion = @idOperacion AND _ORD.idEstatusOrden = @idEstatusOrden), 0.00)*/
go

