/* [INS_RELACION_ORDENAGRUPADA_INTEGRA_SP] 5  13 11 */
CREATE PROCEDURE [dbo].[INS_RELACION_ORDENAGRUPADA_INTEGRA_SP]
	@idContratoOperacion INT
 as
DECLARE @numOrden varchar(50), @idOrden numeric(18,0);  
DECLARE COPADE_C CURSOR FOR  
SELECT O.numeroOrden, O.idOrden
FROM [192.168.20.29].[GAAutoExpress].[dbo].[ADE_COPADE] ADE
INNER JOIN Ordenes O on ADE.COP_ORDENGLOBAL = O.numeroOrden COLLATE Modern_Spanish_CS_AS
where O.idEstatusOrden in (8) AND O.idContratoOperacion = @idContratoOperacion
OPEN COPADE_C;  
FETCH NEXT FROM COPADE_C
INTO @numOrden, @idOrden;  
WHILE @@FETCH_STATUS = 0  
BEGIN
    if not exists (select 1 from Ordenes O inner join datosCopadeOrden DCO on DCO.idOrden = O.idOrden where numeroOrden = @numOrden)
    begin
            declare @subtotal numeric(18,2)
                    ,@total numeric(18,2)
                    ,@IVA numeric(18,2)
					,@factorIVA numeric(18,2)
                    ,@descripcion varchar(100)
                    ,@contrato varchar(150)
                    ,@ordenSurtimiento varchar(50)
                    ,@numEstimacion varchar(250)
                    ,@idCO numeric(18,0)
                    ,@idDatosCopade numeric(18,0)
                    ,@idDatosCopadeOrden numeric(18,0)
                    ,@idOrdenAgrupada numeric(18,0)
                    ,@idOrdenAgrupadaDetalle numeric(18,0)
            select @subtotal = sum(ISNULL(venta,0.00) * cantidad), @descripcion = CLI.nombreComercial + ' | ' + Z.nombre + ' | ' + U.numeroEconomico, @contrato = CON.numero, @ordenSurtimiento = '00000', @numEstimacion = O.numeroOrden, @idCO = O.idContratoOperacion
            ,@factorIVA = .16
			from Ordenes O
            inner join Cotizaciones C on O.idOrden = C.idOrden
            inner join CotizacionDetalle CD on CD.idCotizacion = C.idCotizacion
            inner join ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
            inner join Partidas..Contrato CON on CO.idContrato = CON.idContrato
            inner join Partidas..Licitacion L on L.idLicitacion = CON.idLicitacion
            inner join Partidas..Cliente CLI on CLI.idCliente = L.idCliente
            --inner join PresupuestoOrden PO on PO.idOrden = O.idOrden
            --inner join Presupuestos P on P.idPresupuesto = PO.idPresupuesto
            inner join Unidades U on U.idUnidad = O.idUnidad
            inner join Partidas..Zona Z on Z.idZona = O.idZona
            --LEFT join Partidas..Zona ZP on ZP.idZona = Z.idPadre 
            where numeroOrden = @numOrden and idEstatusPartida = 2 AND O.idContratoOperacion=@idContratoOperacion
            group by O.idOrden, CLI.nombreComercial, CON.numero, O.idContratoOperacion, Z.nombre, U.numeroEconomico, O.numeroOrden
            set @IVA = @subtotal * @factorIVA 
            set @total = @subtotal + @IVA
            INSERT INTO [dbo].[DatosCopade]
            VALUES (@subtotal, @total, 'MXN', 1, @descripcion, @subtotal, 'SER', @subtotal, 0, @IVA, 'IVA', @IVA, @factorIVA*100, @contrato, @ordenSurtimiento, @numEstimacion, null, null, 0,
                    null, @numOrden, null, GETDATE(), GETDATE(), null, @idCO)
            set @idDatosCopade = @@IDENTITY
            INSERT INTO [dbo].[DatosCopadeOrden]
            VALUES (@idDatosCopade, @idOrden, GETDATE())
            set @idDatosCopadeOrden = @@IDENTITY
            INSERT INTO [dbo].[OrdenAgrupada]
            VALUES(@numOrden, GETDATE(), 1)
            set @idOrdenAgrupada = @@IDENTITY
            INSERT INTO [dbo].[OrdenAgrupadaDetalle]
            VALUES (@idOrdenAgrupada, @idDatosCopadeOrden, GETDATE())
            set @idOrdenAgrupadaDetalle = @@IDENTITY
            print 'SE INSERTO LA COPADE PARA EL NÚMERO DE ORDEN: ' + @numOrden
        end
    else
        begin
            print 'YA EXISTE COPADE PARA EL NÚMERO DE ORDEN: ' + @numOrden
        end
    FETCH NEXT FROM COPADE_C
    INTO @numOrden, @idOrden;    
END  
CLOSE COPADE_C;  
DEALLOCATE COPADE_C;

go

