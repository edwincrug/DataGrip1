

CREATE view [Conciliacion].[SiscoData]

AS

SELECT O.[idOrden]
      ,O.[numeroOrden]
      ,O.[idContratoOperacion]
      ,O.[idUsuario]
      ,O.[idEstatusOrden]
	  ,EO.[nombreEstatusOrden]
      ,O.[idTaller] as [idTallerOrden]
	  ,C.[idCotizacion]
	  ,C.[numeroCotizacion]
	  ,C.[idEstatusCotizacion]
	  ,EC.[nombreEstatusCotizacion]
	  ,C.[idTaller] as [idTallerCotizacion]
	  ,p.nombreComercial
	  ,p.razonSocial
	  ,pe.idBPRO
	  ,FC.numFactura
	  ,FC.subTotal
	  ,FC.total

  FROM [dbo].[Ordenes] O
  
  INNER JOIN [dbo].[EstatusOrdenes] EO
          ON O.[idEstatusOrden] = EO.[idEstatusOrden]
		   
  INNER JOIN [dbo].[Cotizaciones]  C
          ON C.[idOrden] = O.[idOrden]

  INNER JOIN [dbo].[EstatusCotizaciones] EC
          ON EC.[idEstatusCotizacion] = C.[idEstatusCotizacion]

  INNER JOIN Partidas..Proveedor p 
         ON p.idProveedor = C.idTaller 

 INNER JOIN Partidas..ProveedorEncabezadoEmpresa pe 
         ON pe.idProveedorEncabezado = p.idProveedorEncabezado 		
		AND pe.idEmpresa = 1

 --INNER JOIN  [dbo].[facturaCotizacion] FC
 LEFT OUTER JOIN [dbo].[facturaCotizacion] FC
          ON  FC.[idCotizacion]  = C.[idCotizacion]
go

grant select, view definition on Conciliacion.SiscoData to DevOps
go

