CREATE PROCEDURE [dbo].[SEL_ORDEN_X_COPADE_SP] (
	@idContratoOperacion INT=3,
	@idCopade numeric(18,0)
)
AS
BEGIN

	SELECT 
		(SELECT [dbo].[SEL_NOMBRE_CLIENTE](CONVERT(NVARCHAR(100),@idContratoOperacion))) AS nombreCliente,
		O.consecutivoOrden,
		O.numeroOrden,
		U.numeroEconomico,
		Z.nombre AS nombreZona,
		CTO.nombreTipoOrdenServicio AS nombreTipoOrdenServicio,
		O.fechaCreacionOden,	
		O.comentarioOrden,
		O.idEstatusOrden,
		O.idGarantia,
		EO.nombreEstatusOrden,
		O.idOrden,
		Z.idZona
	FROM Ordenes O
		JOIN Unidades U ON U.idUnidad = O.idUnidad
		JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
		JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
		JOIN Partidas..Zona Z ON Z.idZona = O.idZona
		JOIN DatosCopadeOrden DCO ON DCO.idOrden = O.idOrden
	WHERE
		DCO.idDatosCopade = @idCopade
END
go

