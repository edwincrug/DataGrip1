
-- ==========================================================================================
-- Author:		Sahirely Yam
-- Create date: 09/10/2017
-- Description:	Store que registra los datos de la COPADE
-- ==========================================================================================

CREATE PROC [dbo].[INS_DATOS_COPADE_SP]
	@subTotal DECIMAL(18,2),
	@total DECIMAL(18,2),	
	@moneda NVARCHAR(20),	
	@cantidad DECIMAL(18,4),	
	@descripcion NVARCHAR(250),	
	@importeConcepto DECIMAL(18,2),	
	@unidad NVARCHAR(50),	
	@valorUnitario DECIMAL(18,2),
	@totalImpuestosRetenidos DECIMAL(18,2),	
	@totalImpuestosTrasladados DECIMAL(18,2),	
	@impuesto NVARCHAR(30),	
	@importeTraslado DECIMAL(18,2),
	@tasa DECIMAL(18,2),	
	@contrato NVARCHAR(150),
	@ordenSurtimiento NVARCHAR(250),	
	@numeroEstimacion NVARCHAR(250),	
	@numeroAcreedor NVARCHAR(200),	
	@gestor NVARCHAR(150),
	@finiquito NVARCHAR(150),	
	@posicionap NVARCHAR(150),
	@numeroCopade NVARCHAR(250),
	@ejercicio NVARCHAR(150),
	@fechaRecepcionCopade NVARCHAR(20) = NULL,
	@xmlCopade NVARCHAR(MAX),
	@idContratoOperacion DECIMAL(18,0)
AS

	IF(SUBSTRING(@xmlCopade,1,1) = 'ÿ')
	   BEGIN
		SET @xmlCopade = SUBSTRING(@xmlCopade,2,LEN(@xmlCopade))
       END

	IF EXISTS (SELECT numeroCopade FROM DatosCopade WHERE numeroCopade =  @numeroCopade  ) 
		BEGIN
			SELECT id= 0 -- YA SE ENCUENTRA UN REGISTRO PARA LA COPADE
		END
	ELSE
		BEGIN
			INSERT INTO DatosCopade(subTotal,
							total,
							moneda,
							cantidad,
							descripcion,
							importeConcepto,
							unidad,
							valorUnitario,
							totalImpuestosRetenidos,
							totalImpuestosTrasladados,
							impuesto,
							importeTraslado,
							tasa,
							contrato,
							ordenSurtimiento,
							numeroEstimacion,
							numeroAcreedor,
							gestor,
							finiquito,
							posicionap,
							numeroCopade,
							ejercicio,
							fechaCarga,
							fechaRecepcionCopade,
							xmlCopade,
							idContratoOperacion)
							VALUES
							(
							@subTotal,
							@total,	
							@moneda,	
							@cantidad,	
							@descripcion,	
							@importeConcepto,	
							@unidad,	
							@valorUnitario,
							@totalImpuestosRetenidos,	
							@totalImpuestosTrasladados,	
							@impuesto,	
							@importeTraslado,
							@tasa,	
							@contrato,
							@ordenSurtimiento,	
							@numeroEstimacion,	
							@numeroAcreedor,	
							@gestor,
							@finiquito,	
							@posicionap,
							@numeroCopade,
							@ejercicio,
							GETDATE(),
							@fechaRecepcionCopade,
							@xmlCopade,
							@idContratoOperacion
							)
				SELECT id = @@IDENTITY 
		END


go

