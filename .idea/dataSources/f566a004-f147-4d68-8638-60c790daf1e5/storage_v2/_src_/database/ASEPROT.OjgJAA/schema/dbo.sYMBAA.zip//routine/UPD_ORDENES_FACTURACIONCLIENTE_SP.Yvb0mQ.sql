-- =============================================
-- Author:		<Javier Grijalva>
-- Create date: <08 de Diciembre del 2020>
-- Description:	<Actualiza las ordenes de servicio de SISCO a Factura Enviada al Cliente en función de la facturación al cliente final.>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_ORDENES_FACTURACIONCLIENTE_SP]

AS
BEGIN

	DECLARE @CONT INT = 1
	DECLARE @TOPE INT = 0
	DECLARE @IDUSUARIO INT
	DECLARE @IDORDEN INT
	DECLARE @RESPUESTA AS TABLE (estatus int, mensaje nvarchar(100))

	SELECT @TOPE= COUNT(*)
	FROM ASEPROT.dbo.FACTURASCOPADEORDENES

	IF (@TOPE >= 1)
	BEGIN

		WHILE (@CONT <= @TOPE)
		BEGIN
			IF NOT EXISTS (
				SELECT * FROM ASEPROT.dbo.FACTURASCOPADEORDENES FCO
				INNER JOIN ASEPROT.dbo.HistorialEstatusOrden HO ON HO.idOrden = FCO.idOrden
				WHERE HO.idEstatusOrden = 10	
				AND FCO.RowNumber = @CONT
			)
			BEGIN

				SELECT 
					@IDUSUARIO = HO.idUsuario,
					@IDORDEN = HO.idOrden
				FROM ASEPROT.dbo.FACTURASCOPADEORDENES FCO
				INNER JOIN ASEPROT.dbo.HistorialEstatusOrden HO ON HO.idOrden = FCO.idOrden
				WHERE HO.idEstatusOrden = 8	
				AND FCO.RowNumber = @CONT
				--SELECT @IDUSUARIO
				--SELECT @IDORDEN

				--SE ACTUALIZA A ESTATUS 9
				UPDATE ASEPROT.dbo.Ordenes
				SET idEstatusOrden = 9
				WHERE idOrden = @IDORDEN

				IF NOT EXISTS (SELECT idHistorialEstatusOrden FROM ASEPROT.dbo.HistorialEstatusOrden WHERE idEstatusOrden = 9 AND idOrden = @IDORDEN)
				BEGIN
					INSERT INTO ASEPROT.dbo.HistorialEstatusOrden
					VALUES (@IDORDEN, 9, GETDATE(), GETDATE(), @IDUSUARIO)
				END

				INSERT INTO @RESPUESTA
				EXEC ASEPROT.[dbo].[EXT_UPD_AVANZA_ORDEN_SP] @IDORDEN, @IDUSUARIO	
		
				INSERT INTO ASEPROT.dbo.BitacoraActualizaOrden
				SELECT 
					GETDATE() AS fechaActulizacion,
					@IDORDEN AS idOrden,
					@IDUSUARIO AS idUsuario,
					10 AS idEstatusActualizado

			END	
	
			--SELECT FCO.RowNumber, O.*, HO.* FROM ASEPROT.dbo.FACTURASCOPADEORDENES FCO
			--	INNER JOIN ASEPROT.dbo.HistorialEstatusOrden HO ON HO.idOrden = FCO.idOrden
			--	INNER JOIN ASEPROT.dbo.Ordenes O ON O.idOrden = FCO.idOrden
			--	WHERE FCO.RowNumber = @CONT
			--	AND HO.idEstatusOrden =10

			SET @CONT = @CONT +1
		END
		SELECT 'SE ACTUALIZARON '+ CAST(@TOPE AS nvarchar) + ' REGISTROS A ESTATUS 10' as msg
	END 
	ELSE
		SELECT 'NO HAY REGISTROS POR ACTUALIZAR ESTATUS 10' as msg
	
END
go

