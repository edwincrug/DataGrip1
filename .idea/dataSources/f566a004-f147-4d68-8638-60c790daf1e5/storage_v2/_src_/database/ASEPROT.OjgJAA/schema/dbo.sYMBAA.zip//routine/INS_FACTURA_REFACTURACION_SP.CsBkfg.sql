-- =============================================
-- Author:		J Armando Garcia Arroyo
-- Create date:  06/12/2018
-- Description:	Verifica las ordenes para Refacturacion y mete las facturas en blanco
-- [dbo].[INS_FACTURA_REFACTURACION_SP]
-- =============================================

CREATE PROC [dbo].[INS_FACTURA_REFACTURACION_SP]
AS
BEGIN
	
SET DATEFORMAT DMY

DECLARE @ordenes TABLE(Id int identity(1,1),numeroOrden VARCHAR(50),idOrden int)

INSERT INTO @ordenes
select numeroOrden 
,(SELECT TOP 1 O.idOrden FROM Ordenes AS O WHERE O.numeroOrden=R.numeroOrden)
from Refacturacion AS R
WHERE R.estatus=0

DECLARE   
@idCotizacion NUMERIC(18,0),
@numeroCotizacion VARCHAR(MAX),
@idOrden NUMERIC(18,0),
@numFactura VARCHAR(MAX)='N/A',
@uuid VARCHAR(MAX)='N/A',
@fechaFactura DATETIME=getdate(),
@subTotal DECIMAL(18,2)=0,
@descuento DECIMAL(18,2) = null,
@iva DECIMAL(18,2)=0,
@total DECIMAL(18,2)=0,
@idUsuario NUMERIC(18,0)=793,
@xml VARCHAR(MAX)='N/A',
@rfcEmisor VARCHAR(MAX)='N/A',
@rfcReceptor VARCHAR(MAX)='N/A',
@ruta VARCHAR(MAX)='N/A'

DECLARE @cotizaciones TABLE(id int identity(1,1),idCotizacion int,idOrden int,numeroCotizacion VARCHAR(50))

INSERT INTO @cotizaciones
SELECT C.idCotizacion,O.idOrden,C.numeroCotizacion FROM Cotizaciones AS C
INNER JOIN @ordenes AS O ON O.idOrden=C.idOrden
WHERE C.idEstatusCotizacion=3

DECLARE @i int =1,@n int = (SELECT COUNT(*) FROM @cotizaciones)

WHILE @i<=@n
BEGIN

	SELECT @idCotizacion = idCotizacion,@idOrden=idOrden,@numeroCotizacion=numeroCotizacion FROM @cotizaciones WHERE id=@i

	EXEC [dbo].[INS_FACTURA_COTIZACION_SP] @idCotizacion,@numFactura,@uuid,@fechaFactura,@subTotal,NULL,
	@iva,@total,@idUsuario,@xml,@rfcEmisor,@rfcReceptor

	EXEC [dbo].[INS_FACTURA_SP] @ruta,@idOrden,@idCotizacion

	INSERT INTO CotizacionFCA
	SELECT @idCotizacion,@numeroCotizacion,GETDATE()

	SET @i=@i+1
END

update [dbo].[Refacturacion] SET estatus=1
WHERE [numeroOrden] IN(
SELECT numeroOrden FROM @ordenes
)

SELECT 'OK'

END
--GO
--BEGIN TRAN

--EXEC [INS_FACTURA_REFACTURACION_SP]

--select * from Refacturacion

--SELECT * FROM CotizacionFCA

--ROLLBACK TRAN
go

