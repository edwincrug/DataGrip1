
CREATE PROCEDURE [Banorte].[UPD_ORDEN_COTIZACION_SP] 
	@idOrden INT, 	
	@idCotizacion INT,
	@idZona  INT,	
	@idTaller INT

AS
BEGIN

	--Ordenes
	IF (EXISTS(SELECT top 1 idOrden from Ordenes  where idOrden = @idOrden))
		BEGIN
			select @idZona= idZona from ASEPROT.dbo.Ordenes where idOrden = @idOrden 

			--Update Ordenes
			--set idZona = @idZona--, idTaller = @idTaller
			--where idOrden = @idOrden 
		END

	--Cotizaciones
	/*IF (EXISTS(SELECT TOP 1 idCotizacion from Cotizaciones where  idCotizacion = @idCotizacion))
		BEGIN
			Update Cotizaciones
			set  idTaller = @idTaller
			where idCotizacion = @idCotizacion
		END*/
	
END


go

grant execute, view definition on Banorte.UPD_ORDEN_COTIZACION_SP to DevOps
go

