-- =============================================
-- Author: YJH
-- Create date: 2019/07/08
-- Description: Obtiene los datos de ordenes de refacciones y mano de obra
-- [Banorte].[SEL_ESTATUSORDENES]  0, 241310,'','26-44605-11964',26,'2020-001-139663-1'
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_ESTATUSORDENES]
	@idOrdenMO INT,
	@idOrdenRef INT,
	@numeroOrdenMO VARCHAR(30),
	@numeroOrdenRef VARCHAR(30),
	@idContratoOperacion INT,
	@numeroReclamo VARCHAR(100)	
AS
BEGIN
	SET NOCOUNT ON;	
	BEGIN TRY
		DECLARE @idEstatus INT, @descripcion VARCHAR(100), @numeroContraRecibo VARCHAR(100), @fechaContraRecibo VARCHAR(100)

		DECLARE @fecha VARCHAR(100), @hora VARCHAR(100), @factura VARCHAR(100), @anho VARCHAR(100), @server VARCHAR(100), @base VARCHAR(100)
			  , @tabla VARCHAR(100), @ordenGlobal VARCHAR(100), @fechaPagoFactura VARCHAR(100)
		
		DECLARE @commandQuery VARCHAR(MAX)
		DECLARE @ipBD VARCHAR(30)
		SELECT @ipBD = '[' + CONVERT(VARCHAR(30), ConnectionProperty('local_net_address')) + ']'

		---ESTATUS MANO DE OBRA
		SELECT @idEstatus = O.idEstatusOrden , @descripcion = EO.nombreEstatusOrden FROM Ordenes O
		INNER JOIN EstatusOrdenes EO ON O.idEstatusOrden=EO.idEstatusOrden 
		WHERE O.idOrden = @idOrdenMO

		SELECT @numeroContraRecibo = ISNULL(C.numeroContraRecibo, ''), @fechaContraRecibo = ISNULL(CONVERT(VARCHAR(24), c.fechaContrarecibo, 103),'') FROM Ordenes O
		LEFT JOIN DatosCopade D ON D.numeroCopade = O.numeroOrden
		LEFT JOIN ContrareciboDatosCopade CDC ON CDC.idDatosCopade = D.idDatosCopade
		LEFT JOIN Contrarecibo C ON C.idContrarecibo = CDC.idContrarecibo
		WHERE O.idOrden = @idOrdenMO
					
		SELECT @idEstatus AS idEstatusMO, @descripcion AS descripcionMO, @numeroContraRecibo AS numeroContraReciboMO, @fechaContraRecibo AS fechaContraReciboMO

		--ESTATUS REFACCIONES
		select @descripcion='', @numeroContraRecibo ='', @fechaContraRecibo ='', @idEstatus= 0

		SELECT @idEstatus = O.idEstatusOrden , @descripcion = EO.nombreEstatusOrden FROM Ordenes O
		INNER JOIN EstatusOrdenes EO ON O.idEstatusOrden=EO.idEstatusOrden 
		WHERE O.idOrden = @idOrdenRef

		SELECT @numeroContraRecibo = ISNULL(C.numeroContraRecibo, ''), @fechaContraRecibo = ISNULL(CONVERT(VARCHAR(24), c.fechaContrarecibo, 103),'') FROM Ordenes O
		LEFT JOIN DatosCopade D ON D.numeroCopade = O.numeroOrden
		LEFT JOIN ContrareciboDatosCopade CDC ON CDC.idDatosCopade = D.idDatosCopade
		LEFT JOIN Contrarecibo C ON C.idContrarecibo = CDC.idContrarecibo
		WHERE O.idOrden = @idOrdenRef
					
		SELECT @idEstatus AS idEstatusRef, @descripcion AS descripcionRef, @numeroContraRecibo AS numeroContraReciboRef, @fechaContraRecibo AS fechaContraReciboRef

		--Agregar ip del 29 para autoexpressbanorte
		--FACTURACION MANO DE OBRA
		SELECT @server = ISNULL([server], ''), @base = ISNULL([db], ''), @tabla = ISNULL([tabla], '') FROM ASEPROT.dbo.ConCar
		WHERE fecha = @anho AND idContratoOperacion = @idContratoOperacion

		if (@numeroOrdenMO is not null)
		SELECT @fecha = ISNULL(COP_FECHOPE, ''), @hora = ISNULL(COP_HORAOPE, ''), @factura = ISNULL(COP_IDDOCTO, ''), @anho = ISNULL(Vcc_Anno, '')
		     , @ordenGlobal = ISNULL(COP_ORDENGLOBAL, ''), @fechaPagoFactura = RefaccionMultiMarca.Operacion.FN_FechaPagoFactura(ACO.COP_IDDOCTO)
		FROM [192.168.20.29].GAAutoExpressBanorte.dbo.ADE_COPADE ACO
		left JOIN [192.168.20.29].GAAutoExpressBanorte.dbo.VIS_CONCAR01 VCC ON ACO.COP_IDDOCTO = VCC.CCP_IDDOCTO  AND CCP_TIPODOCTO = 'FAC'
		WHERE ACO.COP_ORDENGLOBAL = @numeroOrdenMO				

		IF (@server = '')
		BEGIN
			SELECT 1 AS Number, @fecha AS fechaMO, @ordenGlobal AS ordenProvisionMO, @factura AS facturaMO, '' AS fechaDoctoMO, @fechaPagoFactura AS fechaPagoFacturaMO
		END
		ELSE 
		BEGIN
			IF (@ipBD = @server)
			BEGIN
				IF(@fecha = '' OR @factura = '' OR @base = '' OR @tabla = '' OR @fecha IS NULL OR @factura IS NULL OR @base IS NULL OR @tabla IS NULL OR @ordenGlobal = '' OR @ordenGlobal IS NULL OR @fechaPagoFactura = '' OR @fechaPagoFactura IS NULL)
				BEGIN
					SELECT 1 AS Number, @fecha AS fechaMO, @ordenGlobal AS ordenProvisionMO, @factura AS facturaMO, '' AS fechaDoctoMO, @fechaPagoFactura AS fechaPagoFacturaMO
				END
				ELSE 
				BEGIN
					SET @commandQuery = 'SELECT 1 AS Number, ''' + @fecha + ''' AS fechaMO, ''' + @ordenGlobal + ''' AS ordenProvisionMO, ''' + @factura + ''' AS facturaMO, ''' + @fechaPagoFactura + ''' AS fechaPagoFacturaMO, CCP_FECHADOCTO AS fechaDoctoMO FROM ' + @base + '.[dbo].' + @tabla + ' WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO = ''' + @factura + ''''
					EXECUTE(@commandQuery)
				END
			END
			ELSE
			BEGIN
				IF(@fecha = '' OR @factura = '' OR @base = '' OR @tabla = '' OR @server = '' OR @fecha IS NULL OR @factura IS NULL OR @base IS NULL OR @tabla IS NULL OR @server IS NULL OR @ordenGlobal = '' OR @ordenGlobal IS NULL OR @fechaPagoFactura = '' OR @fechaPagoFactura IS NULL)
				BEGIN
					SELECT 1 AS Number, @fecha AS fechaMO, @ordenGlobal AS ordenProvisionMO, @factura AS facturaMO, '' AS fechaDoctoMO, @fechaPagoFactura AS fechaPagoFacturaMO
				END
				ELSE
				BEGIN
					SET @commandQuery = 'SELECT 1 AS Number, ''' + @fecha + ''' AS fechaMO, ''' + @ordenGlobal + ''' AS ordenProvisionMO, ''' + @factura + ''' AS facturaMO, ''' + @fechaPagoFactura + ''' AS fechaPagoFacturaMO, CCP_FECHADOCTO AS fechaDoctoMO FROM ' + @server + '.' + @base + '.[dbo].' + @tabla + ' WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO = ''' + @factura + ''''
					EXECUTE(@commandQuery)
				END
			END
		END

		--FACTURACION REFACCIONES

		SELECT @fecha ='', @hora ='', @factura ='', @anho ='', @ordenGlobal ='', @fechaPagoFactura =''
		
		if (@numeroOrdenRef is not null)
		SELECT @fecha = ISNULL(COP_FECHOPE, ''), @hora = ISNULL(COP_HORAOPE, ''), @factura = ISNULL(COP_IDDOCTO, ''), @anho = ISNULL(Vcc_Anno, '')
		     , @ordenGlobal = ISNULL(COP_ORDENGLOBAL, ''), @fechaPagoFactura = RefaccionMultiMarca.Operacion.FN_FechaPagoFactura(ACO.COP_IDDOCTO)
		FROM [192.168.20.29].GAAutoExpressBanorte.dbo.ADE_COPADE ACO
		left JOIN [192.168.20.29].GAAutoExpressBanorte.dbo.VIS_CONCAR01 VCC ON ACO.COP_IDDOCTO = VCC.CCP_IDDOCTO  AND CCP_TIPODOCTO = 'FAC'
		WHERE ACO.COP_ORDENGLOBAL = @numeroOrdenRef		

		IF (@server = '')
		BEGIN
			SELECT 1 AS Number, @fecha AS fechaRef, @ordenGlobal AS ordenProvisionRef, @factura AS facturaRef, '' AS fechaDoctoRef, @fechaPagoFactura AS fechaPagoFacturaRef
		END
		ELSE 
		BEGIN
			IF (@ipBD = @server)
			BEGIN
				IF(@fecha = '' OR @factura = '' OR @base = '' OR @tabla = '' OR @fecha IS NULL OR @factura IS NULL OR @base IS NULL OR @tabla IS NULL OR @ordenGlobal = '' OR @ordenGlobal IS NULL OR @fechaPagoFactura = '' OR @fechaPagoFactura IS NULL)
				BEGIN
					SELECT 1 AS Number, @fecha AS fechaRef, @ordenGlobal AS ordenProvisionRef, @factura AS facturaRef, '' AS fechaDoctoRef, @fechaPagoFactura AS fechaPagoFacturaRef
				END
				ELSE 
				BEGIN
					SET @commandQuery = 'SELECT 1 AS Number, ''' + @fecha + ''' AS fechaRef, ''' + @ordenGlobal + ''' AS ordenProvisionRef, ''' + @factura + ''' AS facturaRef, ''' + @fechaPagoFactura + ''' AS fechaPagoFacturaRef, CCP_FECHADOCTO AS fechaDoctoRef FROM ' + @base + '.[dbo].' + @tabla + ' WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO = ''' + @factura + ''''
					EXECUTE(@commandQuery)
				END
			END
			ELSE
			BEGIN
				IF(@fecha = '' OR @factura = '' OR @base = '' OR @tabla = '' OR @server = '' OR @fecha IS NULL OR @factura IS NULL OR @base IS NULL OR @tabla IS NULL OR @server IS NULL OR @ordenGlobal = '' OR @ordenGlobal IS NULL OR @fechaPagoFactura = '' OR @fechaPagoFactura IS NULL)
				BEGIN
					SELECT 1 AS Number, @fecha AS fechaRef, @ordenGlobal AS ordenProvisionRef, @factura AS facturaRef, '' AS fechaDoctoRef, @fechaPagoFactura AS fechaPagoFacturaRef
				END
				ELSE
				BEGIN
					SET @commandQuery = 'SELECT 1 AS Number, ''' + @fecha + ''' AS fechaRef, ''' + @ordenGlobal + ''' AS ordenProvisionRef, ''' + @factura + ''' AS facturaRef, ''' + @fechaPagoFactura + ''' AS fechaPagoFacturaRef, CCP_FECHADOCTO AS fechaDoctoRef FROM ' + @server + '.' + @base + '.[dbo].' + @tabla + ' WHERE CCP_TIPODOCTO = ''FAC'' AND CCP_IDDOCTO = ''' + @factura + ''''
					EXECUTE(@commandQuery)
				END
			END
		END


		--EVIDENCIAS
		
		SELECT DISTINCT DT.idDocumentoTaller, DT.documento, CASE WHEN DT.multiArchivo = 1
			THEN (SELECT CAST(COUNT(1) AS VARCHAR) FROM 
				RefaccionMultiMarca.Operacion.DocumentoTallerOrden WHERE idDocumentoTaller = DT.idDocumentoTaller AND vigente = 1 AND (idOrden = @idOrdenMO OR idOrden = @idOrdenRef )) 
				ELSE DTO.ruta 
			END ruta
			, DT.fase, DT.idEstatusOrden, DT.orden
		FROM RefaccionMultiMarca.Catalogo.DocumentoTaller DT
			LEFT JOIN RefaccionMultiMarca.Operacion.DocumentoTallerOrden DTO ON DT.idDocumentoTaller = DTO.idDocumentoTaller and DTO.vigente = 1 AND DT.multiArchivo != 1 AND  (DTO.idOrden = @idOrdenMO OR DTO.idOrden = @idOrdenRef)
			LEFT JOIN Seguridad.Catalogo.Users U ON DTO.idUsuario = U.Id
		WHERE DT.activo = 1
		ORDER BY DT.orden

		---ORDEN DE SERVICIO
		DECLARE @ore_idorden VARCHAR(100)
		DECLARE @idSiniestro INT

		DECLARE @dbName VARCHAR(100)
		DECLARE @dbIP VARCHAR(100)
		DECLARE @idMarca INT
		DECLARE @idSucursal INT
		select @commandQuery =''


		DECLARE @ipServer VARCHAR(100)
		SELECT @ipServer = CONVERT(VARCHAR(30), ConnectionProperty('local_net_address'))

		SELECT @dbName =  
		case when U.marca=12 then (case when cast(S.fechaAccidente as date) < '2020-11-17' then 'GAAutoAngarTlahuac' else cs.nameBaseDatos end) else cs.nameBaseDatos end
		
		, @dbIP = CS.ipBaseDatos, @idMarca = M.idMarca ,@idSucursal=CT.idSucursal, @ore_idorden = CT.ore_idorden, @idSiniestro = S.id
		FROM RefaccionMultiMarca.Operacion.Siniestro S
		JOIN RefaccionMultiMarca.[Operacion].[CotizacionTaller] CT ON CT.idSiniestro = S.id 
		INNER JOIN RefaccionMultiMarca.Operacion.Unidad U ON S.idUnidad = U.id
		INNER JOIN RefaccionMultiMarca.Catalogo.Marca M ON U.marca = M.idMarca
		INNER JOIN RefaccionMultiMarca.Relacion.Configuracion_Sucursal CS ON CT.idSucursal=CS.idSucursal
		WHERE S.numeroReclamo = @numeroReclamo AND CT.idOrdenRefaccion = @idOrdenRef

		SELECT @dbName =  
		case when U.marca=12 then (case when cast(S.fechaAccidente as date) < '2020-11-17' then 'GAAutoAngarTlahuac' else cs.nameBaseDatos end) else cs.nameBaseDatos end
		
		, @dbIP = CS.ipBaseDatos, @idMarca = M.idMarca ,@idSucursal=CT.idSucursal, @ore_idorden = CT.ore_idorden, @idSiniestro = S.id
		FROM RefaccionMultiMarca.Operacion.Siniestro S
		JOIN RefaccionMultiMarca.[Operacion].[CotizacionTaller] CT ON CT.idSiniestro = S.id 
		INNER JOIN RefaccionMultiMarca.Operacion.Unidad U ON S.idUnidad = U.id
		INNER JOIN RefaccionMultiMarca.Catalogo.Marca M ON U.marca = M.idMarca
		INNER JOIN RefaccionMultiMarca.Relacion.Configuracion_Sucursal CS ON CT.idSucursal=CS.idSucursal
		WHERE S.numeroReclamo = @numeroReclamo AND CT.idOrdenRefaccion = @idOrdenRef

		--DECLARE @ipServer VARCHAR(100)
		--SELECT @ipServer = CONVERT(VARCHAR(30), ConnectionProperty('local_net_address'))

		--SELECT @dbName = M.dbNameSalida, @dbIP = M.serveSalida, @idMarca = M.idMarca, @ore_idorden = CT.ore_idorden, @idSiniestro = S.id
		--FROM RefaccionMultiMarca.Operacion.Siniestro S
		--JOIN RefaccionMultiMarca.[Operacion].[CotizacionTaller] CT ON CT.idSiniestro = S.id 
		--INNER JOIN RefaccionMultiMarca.Operacion.Unidad U ON S.idUnidad = U.id
		--INNER JOIN RefaccionMultiMarca.Catalogo.Marca M ON U.marca = M.idMarca
		--WHERE S.numeroReclamo = @numeroReclamo AND CT.idOrdenRefaccion = @idOrdenRef

		--IF(@dbName IS NOT NULL)
		--BEGIN
		--	IF (@ipServer = @dbIP)
		--	BEGIN
		--		SET @commandQuery = 'SELECT ORE_IDORDEN, 1 AS Number FROM ' + @dbName + '.dbo.SER_ORDEN WHERE ORE_NUMSINIESTRO = ''' + @numeroReclamo + ''' OR ORE_IDSINIESTRO = ''' + @numeroReclamo + ''''
		--	END
		--	ELSE 
		--	BEGIN
		--		SET @commandQuery = 'SELECT ORE_IDORDEN, 1 AS Number FROM [' + @dbIP + ']' + '.' + @dbName + '.dbo.SER_ORDEN WHERE ORE_NUMSINIESTRO = ''' + @numeroReclamo + ''' OR ORE_IDSINIESTRO = ''' + @numeroReclamo + ''''			
		--	END

		--	PRINT @commandQuery
		--	EXECUTE(@commandQuery)
		--END
		--ELSE
		--BEGIN
		--	SELECT -1 AS Number, 'No se encontraron datos del reclamo' AS [Message]
		--END
		print @dbName
IF(@dbName IS NOT NULL)
	BEGIN
		IF NOT EXISTS (SELECT 
							idSiniestro 
						FROM [RefaccionMultiMarca].[Operacion].[CotizacionTaller]
						WHERE idSiniestro=@idSiniestro
						GROUP BY idSiniestro
						HAVING COUNT(idSiniestro) > 1)
			BEGIN
			print @idSucursal
				IF(@idSucursal = 11) 
					BEGIN
						SET @dbName = 'GAAAF_Body'
					END
						IF (@ipServer = @dbIP)
						BEGIN
							SET @commandQuery = 'SELECT ORE_IDORDEN, 1 AS Number FROM ' + @dbName + '.dbo.SER_ORDEN WHERE ORE_NUMSINIESTRO = ''' + @numeroReclamo + ''' OR ORE_IDSINIESTRO = ''' + @numeroReclamo + ''''
						END
						ELSE 
						BEGIN
							SET @commandQuery = 'SELECT ORE_IDORDEN, 1 AS Number FROM [' + @dbIP + ']' + '.' + @dbName + '.dbo.SER_ORDEN WHERE ORE_NUMSINIESTRO = ''' + @numeroReclamo + ''' OR ORE_IDSINIESTRO = ''' + @numeroReclamo + ''''			
						END

					PRINT @commandQuery
					EXECUTE(@commandQuery)
			END
		ELSE
			BEGIN
				IF(@ore_idorden IS NOT NULL)
					BEGIN
						IF(@idSucursal = 11) 
						BEGIN
							SET @dbName = 'GAAAF_Body'
						END
							IF (@ipServer = @dbIP)
							BEGIN
								SET @commandQuery = 'SELECT ORE_IDORDEN, 1 AS Number FROM ' + @dbName + '.dbo.SER_ORDEN WHERE (ORE_NUMSINIESTRO = ''' + @numeroReclamo + ''' OR ORE_IDSINIESTRO = ''' + @numeroReclamo + ''') AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX(''%[0]%'',ORE_IDORDEN), 20), PATINDEX(''%[^0]%'',SUBSTRING(ORE_IDORDEN, PATINDEX(''%[0]%'',ORE_IDORDEN), 20)), 20) = ''' + @ore_idorden + ''' '
							END
							ELSE 
							BEGIN
								SET @commandQuery = 'SELECT ORE_IDORDEN, 1 AS Number FROM [' + @dbIP + ']' + '.' + @dbName + '.dbo.SER_ORDEN WHERE (ORE_NUMSINIESTRO = ''' + @numeroReclamo + ''' OR ORE_IDSINIESTRO = ''' + @numeroReclamo + ''') AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX(''%[0]%'',ORE_IDORDEN), 20), PATINDEX(''%[^0]%'',SUBSTRING(ORE_IDORDEN, PATINDEX(''%[0]%'',ORE_IDORDEN), 20)), 20) = ''' + @ore_idorden + '''  '	
								--PRINT @commandQuery	
							END

						PRINT @commandQuery
						EXECUTE(@commandQuery)
					END
				ELSE
					BEGIN
						SELECT -1 AS Number, 'No se encontro la orden de servicio BPRO!' AS [Message]
					END
			END
	END
ELSE
	BEGIN
		SELECT -1 AS Number, 'No se encontraron los datos del servidor!' AS [Message]
	END


	END TRY 	
	BEGIN CATCH	
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

