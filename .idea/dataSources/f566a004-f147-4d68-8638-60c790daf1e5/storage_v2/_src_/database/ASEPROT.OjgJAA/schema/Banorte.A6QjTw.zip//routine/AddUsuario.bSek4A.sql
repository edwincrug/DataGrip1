
-- =============================================
-- Autor: Miguel Angel Reyes
-- Fecha: 09/08/2018
-- Login para los usuarios de sisco dentro de la aplicacion movil
-- [Banorte].[AddUsuario] 510
-- =============================================
CREATE PROCEDURE [Banorte].[AddUsuario]
	@idUsuario		varchar(50)
AS
BEGIN

	IF EXISTS (select idUsuario from usuarios where idUsuario = @idUsuario)
	BEGIN
		IF EXISTS (select id from Banorte.UsuariosMiAuto where idUsuario = @idUsuario)
		BEGIN
			select 2 estatus, 'El usuario ya esta registrado' mensaje
		END
		ELSE
		BEGIN
			select 1 estatus, 'El usuario se registro de forma correcta' mensaje
			INSERT INTO Banorte.UsuariosMiAuto VALUES (GETDATE(),0,@idUsuario)
		END

		select 
			u.idUnidad
			,u.numeroEconomico numero
			,u.vin
			,u.placas
			,u.frente 
			,u.modelo
			,tu.tipo marca
		from unidades u 
			inner join ContratoOperacion co on u.idOperacion = co.idOperacion
			inner join ContratoOperacionUsuario cou on co.idContratoOperacion = cou.idContratoOperacion
			left join [Partidas].dbo.tipounidad tu on tu.idTipoUnidad = u.idTipoUnidad
		where cou.idUsuario = @idUsuario
	END
	ELSE
	BEGIN
		select 0 estatus, 'El usuario no existe' mensaje
	END

END
go

grant execute, view definition on Banorte.AddUsuario to DevOps
go

