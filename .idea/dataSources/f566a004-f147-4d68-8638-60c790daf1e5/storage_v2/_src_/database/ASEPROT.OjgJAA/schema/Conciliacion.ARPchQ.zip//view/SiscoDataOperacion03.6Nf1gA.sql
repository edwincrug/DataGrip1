

CREATE view [Conciliacion].[SiscoDataOperacion03]

AS

SELECT SD.[idOrden]
      ,SD.[numeroOrden]
      ,SD.[idContratoOperacion]
      ,SD.[idUsuario]
      ,SD.[idEstatusOrden]
      ,SD.[nombreEstatusOrden]
      ,SD.[idTallerOrden]
      ,SD.[idCotizacion]
      ,SD.[numeroCotizacion]
      ,SD.[idEstatusCotizacion]
      ,SD.[nombreEstatusCotizacion]
      ,SD.[idTallerCotizacion]
      ,SD.[nombreComercial]
      ,SD.[razonSocial]
      ,SD.[idBPRO]
	  ,SD.numFactura
	  ,SD.subTotal
	  ,SD.total
  FROM [Conciliacion].[SiscoData] SD


  --INNER JOIN  [dbo].[facturaCotizacion] FC
  --        ON  FC.[idCotizacion]  = SD.[idCotizacion]

  WHERE  SD.[idContratoOperacion] = 3
go

grant select, view definition on Conciliacion.SiscoDataOperacion03 to DevOps
go

