


CREATE VIEW [cobranza].[VwStatusCotizacion]
AS
SELECT [idCotizacion]
      ,[numFactura]
      ,[NumFacturaF]
      ,[DeudaDia]
  FROM [ASEPROT].[cobranza].[VwStatusCotizacionBase]
  where [DeudaDia] > 0
go

