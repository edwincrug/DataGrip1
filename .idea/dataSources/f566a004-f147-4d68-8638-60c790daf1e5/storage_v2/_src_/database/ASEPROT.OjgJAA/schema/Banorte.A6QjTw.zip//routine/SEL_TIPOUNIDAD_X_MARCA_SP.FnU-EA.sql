
CREATE PROCEDURE [Banorte].[SEL_TIPOUNIDAD_X_MARCA_SP] 
--EXEC [dbo].[SEL_TIPOUNIDAD_X_MARCA_SP] 'PRUEBA5',2
	@Marca VARCHAR(50),
	@idContratoOperacion int
AS
BEGIN

DECLARE 
@idTipoUnidad int,
@idUnidad int,
@idContratounidad int,
@idContrato int =0




	IF EXISTS(
		SELECT	* FROM partidas..TipoUnidad TU
		WHERE TU.TIPO like '%' + @Marca + '%'
		)
		BEGIN
			SELECT	U.idUnidad as idUnidad,
			 TU.TIPO as TipoUnidad,
			 PC.idContratoUnidad as idContratoUnidad
			 FROM partidas.dbo.TipoUnidad TU
			 INNER JOIN partidas.dbo.unidad U ON U.idTipoUnidad = TU.idTipoUnidad
			 INNER JOIN partidas.dbo.ContratoUnidad PC ON PC.idUnidad = U.idUnidad
			WHERE TU.TIPO like '%' + @Marca + '%'
		END

	ELSE
		BEGIN
		select @idContrato=idContrato from ASEPROT.dbo.ContratoOperacion where idContratoOperacion=@idContratoOperacion
		--///////////////////////INSERTA NUEVO TIPO DE UNIDAD ////////////////////////////////
			INSERT INTO partidas..TipoUnidad
			--OUTPUT INSERTED.idTipoUnidad
			VALUES(@Marca, 1)
			set @idTipoUnidad = @@IDENTITY


			--///////////////////////INSERTA NUEVA UNIDAD ////////////////////////////////

			INSERT INTO Partidas.dbo.Unidad
            (idTipoCombustible, 
			idTipoUnidad, 
			idSubMarca, 
             idCilindros, 
			 anio, 
             version, 
			 foto, 
			 estatus 
		--	 idServicio, 
		--	 idTServicio
			 ) 
			 --OUTPUT INSERTED.idUnidad
			 values 
            (1,
			@idTipoUnidad,
			57,
            1,
			NULL, 
            NULL,
			'',
			1
	--		0,
	--		0
			)

			set @idUnidad = @@IDENTITY
			
			INSERT INTO [Partidas].[dbo].[ContratoUnidad]
			--OUTPUT INSERTED.idContratoUnidad
			VALUES
			(
			@idContrato,
			@idUnidad
			)

			set @idContratoUnidad = @@IDENTITY

			Select @idUnidad as idUnidad, @idContratoUnidad as idContratoUnidad
		END
END


go

grant execute, view definition on Banorte.SEL_TIPOUNIDAD_X_MARCA_SP to DevOps
go

