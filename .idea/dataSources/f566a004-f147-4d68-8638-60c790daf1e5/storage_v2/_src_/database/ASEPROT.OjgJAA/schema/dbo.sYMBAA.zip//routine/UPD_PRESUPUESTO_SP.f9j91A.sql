
CREATE PROCEDURE  [dbo].[UPD_PRESUPUESTO_SP]
	@idPresupuesto INT = NULL,
	@nuevoPresupuesto NUMERIC(18,2) = NULL,
	@idUsuario NUMERIC(18,0),
	@idContratoOperacion NUMERIC(18,0)

AS
BEGIN
	DECLARE @idSoporte NUMERIC(18,0) = 11
	DECLARE @presupuesto NUMERIC(18,2) = (SELECT presupuesto FROM Presupuestos WHERE idPresupuesto =@idPresupuesto)
    DECLARE @descripcion NVARCHAR(100) = 'Actualiza Presupuesto, Presupuesto Viejo: '+ convert(nvarchar(100),@presupuesto)+ ' Presupuesto Nuevo: '+ convert(nvarchar(100),@nuevoPresupuesto)

	INSERT INTO LogSoporte VALUES(@idPresupuesto, @idUsuario, @idContratoOperacion, GETDATE(), @idSoporte, @descripcion,null)

	UPDATE Presupuestos
	SET presupuesto=@nuevoPresupuesto
	WHERE idPresupuesto=@idPresupuesto

	SELECT 1

END

go

