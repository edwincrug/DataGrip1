-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 10/10/2018
-- Description:	Valida la existencia de una unidad con el vin
-- EXEC [ASEPROT].[Mobile].Sel_Vin_Sp '3AEVS4020WM013062'
-- =============================================
CREATE PROCEDURE [Mobile].[Sel_Vin_Sp]
	@vin				varchar(17)
AS

BEGIN

	SELECT 
		count(idUnidad) [unidades],
		CASE count(idUnidad) WHEN  0 THEN 'Unidad libre'
		ELSE 'El vehículo ha sido registrado previamente en la plataforma, ¿Desea asignarlo a esta cuenta?'
		END [mensaje]
	FROM [dbo].[Unidades] 
	WHERE vin = @vin
	
END
go

grant execute, view definition on Mobile.Sel_Vin_Sp to DevOps
go

