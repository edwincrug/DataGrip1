-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03/06/2017
-- =============================================
CREATE PROCEDURE [dbo].[UPD_HISTORICO_LOGIN]
	@idUsuario numeric(18,0)
AS
BEGIN
	UPDATE [dbo].[HistorialLogin]
	SET	   [FechaFin] = GETDATE()
	WHERE  [idUsuario] = @idUsuario and [FechaFin] IS NULL
END
go

