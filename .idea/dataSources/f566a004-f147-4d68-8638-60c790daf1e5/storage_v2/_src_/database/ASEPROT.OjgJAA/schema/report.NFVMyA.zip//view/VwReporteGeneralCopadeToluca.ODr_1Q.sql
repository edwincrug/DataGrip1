



CREATE VIEW [report].[VwReporteGeneralCopadeToluca]
AS

   SELECT
   DISTINCT 
            o.idOrden,
	     	a.COP_IDDOCTO
			
      FROM  DatosCopadeOrden dco 
inner join  OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
inner join  OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
inner join  Ordenes o on o.idOrden=dco.idOrden
inner join  [192.168.20.29].[GATPartsToluca].dbo.ADE_COPADE a on a.COP_ORDENGLOBAL=oa.numero COLLATE Latin1_General_CI_AS

go

