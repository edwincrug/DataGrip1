
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 06/06/2017
-- Description:	Store para la Validacion de Token
-- [dbo].[SEL_VALIDA_TOKEN_SP] 'ase',125
-- ==========================================================================================

CREATE PROCEDURE [dbo].[SEL_VALIDA_TOKEN_SP]
    @Token VARCHAR(MAX),
    @idOrden VARCHAR(MAX)
AS   
	-- DECLARE @Token VARCHAR(MAX);
	-- DECLARE @idOrden VARCHAR(MAX);

	-- SET @idOrden = 11;
	-- SET @Token = '1428517F';

	DECLARE @ExisteToken NUMERIC(15,0);
	DECLARE @Vigencia NUMERIC(15,0);
	DECLARE @IdToken NUMERIC(15,0);
	
	DECLARE @idoperacion int=0;
	SELECT  @idoperacion = idContratoOperacion FROM Ordenes WHERE idOrden = @idOrden;
	
	DECLARE @validacionPorToken NUMERIC(1,0);
	SET @validacionPorToken = ( SELECT validacionPorToken FROM ContratoOperacionFacturacion COF
									INNER JOIN ContratoOperacion CO ON COF.idContratoOperacion = CO.idContratoOperacion
									WHERE co.idContratoOperacion = @idoperacion );
	
	SET @ExisteToken = (SELECT COUNT(idToken) FROM Token WHERE idOrdenServicio = @idOrden AND token = @Token);

	IF( @ExisteToken <> 0 )
		BEGIN
			SET @Vigencia = (SELECT COUNT(idToken) FROM Token WHERE idOrdenServicio = @idOrden AND token = @Token AND CURRENT_TIMESTAMP < vigenciaToken AND estatusToken = 1); 
			
			IF( @Vigencia <> 0 )
				BEGIN
					SET @IdToken = (SELECT idToken FROM Token WHERE idOrdenServicio = @idOrden AND token = @Token AND CURRENT_TIMESTAMP < vigenciaToken AND estatusToken = 1); 
					IF(@validacionPorToken = 2)
						BEGIN
							UPDATE Token SET estatusToken = 2 WHERE idToken = @IdToken;
							-- print ''
						END
					SELECT Success = @Vigencia, Msg = 'El Token que proporcionó es Válido.';
				END
			ELSE
				BEGIN
					SELECT Success = @Vigencia, Msg = 'El Token que proporcionó ya ha caducado.';
				END
			
		END
	ELSE
		BEGIN
			 -- SELECT Success = @ExisteToken, Msg = 'No existe el Token que proporcionó para la Orden';
			 SELECT Success = 0, Msg = 'El Token que proporcionó no es Válido.';
		END
go

