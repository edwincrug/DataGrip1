/* -------------------------------------
-- [SEL_REPORTE_UNIDAD_OPERATIVOS_DETALLE_SP] 354
 ------------------------------------- */
CREATE PROCEDURE [dbo].[SEL_REPORTE_UNIDAD_OPERATIVOS_DETALLE_SP]
	@idUnidad INT
AS
BEGIN
	SET NOCOUNT ON;
	--DECLARE @idOperacion INT=(SELECT idOperacion FROM ContratoOperacion WHERE idContratoOperacion=@idContratoOperacion)
	SELECT
		U.numeroEconomico,
		U.vin,
		U.idOperacion,
		U.idCentroTrabajo,
		U.placas,
		U.modelo,
		U.combustible,
		U.verificada,
		TU.tipo,
		TC.tipoCombustible,
		SM.nombre subMarca,
		M.nombre Marca,
		Z.nombre,
		CT.nombreCentroTrabajo,
		o.numeroOrden,
		CTOS.nombreTipoOrdenServicio,
		CEU.descripcionEstadoUnidad,
		(SELECT [dbo].[SEL_TIPO_EVENTO_FN](O.idOrden)) evento,
		(SELECT TOP 1  ISNULL(fechaInicial, GETDATE()) FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3) AS fechaEntrada, 
		(SELECT TOP 1  ISNULL(fechaInicial, GETDATE())  FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 7) AS fechaEntrega,
		(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 8) AS fechaEntregaUsuario,
		O.fechaCreacionOden,
		O.fechaCita,
		DATEDIFF (day, (SELECT TOP 1  ISNULL(fechaInicial, GETDATE())  FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3), (SELECT TOP 1  ISNULL(fechaInicial, GETDATE())  FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 7)) AS diferenciaDias,
		DATEDIFF (hour, (SELECT TOP 1  ISNULL(fechaInicial, GETDATE())  FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3), (SELECT TOP 1  ISNULL(fechaInicial, GETDATE())  FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 7)) AS diferenciaHoras
	FROM Ordenes O
	JOIN CatalogoTiposOrdenServicio CTOS ON CTOS.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
	JOIN CatalogoEstadoUnidad CEU ON CEU.idCatalogoEstadoUnidad = O.idCatalogoEstadoUnidad
	JOIN Unidades U ON U.idUnidad = O.idUnidad
	JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
	JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
	JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
	JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
	JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
	JOIN Partidas..Zona Z ON Z.idZona = U.idZona
	LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
	WHERE u.idUnidad = @idUnidad
	AND O.idEstatusOrden NOT IN(13)
	--O.idContratoOperacion = @idContratoOperacion AND
	--O.idCatalogoTipoOrdenServicio = COALESCE(@idCatalogoTipoOrdenServicio, O.idCatalogoTipoOrdenServicio) AND
	--O.idCatalogoEstadoUnidad = COALESCE(@idCatalogoEstadoUnidad, O.idCatalogoEstadoUnidad) AND
	--O.idZona = COALESCE(@idZona,U.idZona) AND
	--O.fechaCreacionOden BETWEEN COALESCE(@fechaInicial,O.fechaCreacionOden) AND COALESCE (@fechaFinal,O.fechaCreacionOden)	
	UNION
		SELECT 		
		U.numeroEconomico,
		U.vin,
		U.idOperacion,
		U.idCentroTrabajo,
		U.placas,
		U.modelo,
		U.combustible,
		U.verificada,
		TU.tipo,
		TC.tipoCombustible,
		SM.nombre subMarca,
		M.nombre Marca,
		Z.nombre,
		CT.nombreCentroTrabajo,
		O.numeroOrden,
		'Unidad Fuera de Operación' AS nombreTipoOrdenServicio,
		'Parada' AS descripcionEstadoUnidad,
		 MS.Descripcion evento,
		 ISNULL(US.fecha, GETDATE()) AS fechaEntrada, 
		 ISNULL(US.fechaSalida, GETDATE()) AS fechaEntrega,
		 US.fechaSalida AS fechaEntregaUsuario,
		 US.fecha AS fechaCreacionOden,
		 US.fecha AS fechaCita,
		 DATEDIFF (day, ISNULL(US.fecha, GETDATE()), ISNULL(US.fechaSalida, GETDATE())) AS diferenciaDias,
		 DATEDIFF (hour, ISNULL(US.fecha, GETDATE()), ISNULL(US.fechaSalida, GETDATE())) AS diferenciaHoras
	FROM [Sustituto].[UnidadSustituto] US
		JOIN [Sustituto].[MotivoSustituto] MS ON MS.idMotivo = US.idMotivo
		JOIN Unidades U ON U.idUnidad = US.idUnidad
		JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad
		JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad
		JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible
		JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca
		JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
		JOIN Partidas..Zona Z ON Z.idZona = U.idZona
		LEFT JOIN CentroTrabajos CT ON CT.idCentroTrabajo = U.idCentroTrabajo
		LEFT JOIN Ordenes O ON O.numeroOrden = US.numeroOrden
	WHERE U.idUnidad = @idUnidad
	--U.idOperacion = @idOperacion AND
	--US.estatus = COALESCE(@idCatalogo, US.estatus) AND
	--U.idZona = COALESCE(@idZona,U.idZona) AND
	--US.fecha BETWEEN COALESCE(@fechaInicial,US.fecha) AND COALESCE (@fechaFinal,US.fecha)
END
/*
SELECT * FROM Unidades
SELECT * FROM Ordenes where idContratoOperacion = 1 and idEstatusOrden NOT IN(13)
SELECT * FROM CatalogoTiposOrdenServicio
SELECT * FROM CatalogoEstadoUnidad
SELECT * FROM CatalogoTipoOrden
select * from [Sustituto].[UnidadSustituto]
*/


go

