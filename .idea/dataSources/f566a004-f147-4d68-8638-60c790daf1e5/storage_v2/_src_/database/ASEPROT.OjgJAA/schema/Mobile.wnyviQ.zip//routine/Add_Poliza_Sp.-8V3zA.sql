-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 08/08/2018
-- Description:	Actualizar la unidad por id, solo para unidades registradas en app banorte
-- EXEC [Mobile].[Add_Poliza_Sp] 123456,'123456'
-- =============================================
CREATE PROCEDURE [Mobile].[Add_Poliza_Sp]
(
	@idUnidad					int
	,@poliza					VARCHAR(20)=null
)
AS
	DECLARE
	@idPoliza					int=0

BEGIN

	IF(@poliza IS NOT NULL)
	BEGIN

		IF EXISTS (SELECT idUnidad FROM [dbo].[Unidades] WHERE idUnidad = @idUnidad)
		BEGIN

			SELECT @idPoliza = id 
			FROM [Mobile].[Poliza] 
			WHERE idUnidad = @idUnidad

			IF(@idPoliza > 0)
			BEGIN
				UPDATE [Mobile].[Poliza] SET numero = @poliza, estatus = 1
				WHERE id = @idPoliza

				INSERT INTO [Mobile].[PolizaHistorial] VALUES(@poliza, GETDATE(),@idPoliza)

				PRINT 'La unidad ya existe, solo se actualizo la poliza'
			END
			ELSE
			BEGIN

				INSERT INTO [Mobile].[Poliza] VALUES(@poliza, 1, @idUnidad)

				INSERT INTO [Mobile].[PolizaHistorial] VALUES(@poliza, GETDATE(),@@IDENTITY)

				PRINT 'La unidad ya existe, se inserto la poliza'
			END

		END
		ELSE
		BEGIN

			PRINT 'La unidad no existe'

		END

	END
	ELSE
	BEGIN

		UPDATE [Mobile].[Poliza] SET estatus = 0 WHERE idUnidad = @idUnidad

	END

	

END
go

grant execute, view definition on Mobile.Add_Poliza_Sp to DevOps
go

