
CREATE PROCEDURE SEL_MODULOS_COMPROBANTE_RECEPCION_SP
@idTipoUnidad INT
AS
BEGIN
SELECT * FROM [dbo].[CatalogoModuloComprobanteRecepcion] CaMoCoRe
WHERE idTipoUnidad = @idTipoUnidad
END

go

