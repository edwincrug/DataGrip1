-- ==========================================================================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 22/05/2017
-- ==========================================================================================
CREATE PROCEDURE [dbo].[UPD_CANCELA_COTIZACION_SP]
	@idusuario numeric(18,0),
	@idcotizacion numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;
	IF ((SELECT COUNT(*) FROM Cotizaciones where idCotizacion = @idcotizacion) > 0)
	BEGIN

		DECLARE	@estatusActualCoti INT = (SELECT idEstatusCotizacion FROM dbo.Cotizaciones WHERE idCotizacion = @idcotizacion)
		
		IF (@estatusActualCoti = 1)
			BEGIN
				--update fecha fin al status anterior de la cotización en el historial
				UPDATE [dbo].[HistorialEstatusCotizacion]
				SET [fechaFinal] = GETDATE()
				WHERE idCotizacion = @idcotizacion and (idEstatusCotizacion = 1 and fechaFinal is null)

				INSERT INTO [dbo].[HistorialEstatusCotizacion]([fechaInicial],[fechaFinal], [idCotizacion], [idUsuario], [idEstatusCotizacion])
				VALUES (GETDATE(), GETDATE(), @idcotizacion, @idusuario, 2)
			END
		ELSE IF (@estatusActualCoti = 2)
			BEGIN
				--update fecha fin al status anterior de la cotización en el historial
				UPDATE [dbo].[HistorialEstatusCotizacion]
				SET [fechaFinal] = GETDATE()
				WHERE idCotizacion = @idcotizacion and (idEstatusCotizacion = 2 and fechaFinal is null)
			END
		

		--pasar la cotización al estatus de cancelado (4)
		UPDATE [dbo].[Cotizaciones]
		SET [idEstatusCotizacion] = 4
		WHERE [idCotizacion] = @idcotizacion

		--agregar al historial de la cotización el estatus de cancelado
		INSERT INTO [dbo].[HistorialEstatusCotizacion]([fechaInicial], [fechaFinal], [idCotizacion], [idUsuario], [idEstatusCotizacion])
		VALUES (GETDATE(), GETDATE(), @idcotizacion, @idusuario, 4)


		DECLARE @idAutorizacionCot numeric(18,0) = (SELECT [idAutorizacionCotizacion] 
												FROM [dbo].[AutorizacionCotizacion] 
												WHERE [idCotizacion]  = @idcotizacion)

		IF (@idAutorizacionCot IS NULL)
			BEGIN
				INSERT INTO [dbo].[AutorizacionCotizacion]
						   ([fechaAutorizacion], [idCotizacion])
					 VALUES
						   (GETDATE(), @idcotizacion)

				SET @idAutorizacionCot = @@IDENTITY
			END
		ELSE
			BEGIN
				UPDATE [dbo].[AutorizacionCotizacion]
				SET [fechaAutorizacion] = GETDATE()
				WHERE [idCotizacion] = @idcotizacion
			END


		--rechazar todas las partidas de la cotización
		UPDATE [dbo].[CotizacionDetalle]
		SET [idEstatusPartida] = 3
		WHERE [idCotizacion] = @idcotizacion
				
		DECLARE @idDetCot numeric(18,0)
		DECLARE Detalle_Cursor CURSOR FOR 
		SELECT idCotizacionDetalle 
		FROM [dbo].[CotizacionDetalle] 
		WHERE [idCotizacion] = @idcotizacion
		OPEN Detalle_Cursor

		FETCH NEXT FROM Detalle_Cursor INTO @idDetCot

		WHILE @@FETCH_STATUS = 0 
		BEGIN
			DECLARE @idDetalleAut  numeric(18,0) = (select [idDetalleAutorizacionCotizacion] from [dbo].[DetalleAutorizacionCotizacion] where [idCotizacionDetalle] = @idDetCot)

			IF (@idDetalleAut is null)
				BEGIN
					--INSERT
						INSERT INTO [dbo].[DetalleAutorizacionCotizacion]
								   ([fechaAutorizacion], [idUsuario], [idAprobacionCotizacion], [idEstatusAutorizacion], [idCotizacionDetalle])
							 VALUES
								   (GETDATE(), @idUsuario, @idAutorizacionCot, 3, @idDetCot)
				END
			ELSE
				BEGIN
					--UPDATE
						UPDATE [dbo].[DetalleAutorizacionCotizacion]
						   SET [fechaAutorizacion] = GETDATE()
							  ,[idUsuario] = @idusuario     
							  ,[idEstatusAutorizacion] = 3      
						 WHERE [idDetalleAutorizacionCotizacion] = @idDetalleAut
				END

			FETCH NEXT FROM Detalle_Cursor INTO @idDetCot
		END

		DECLARE @idOrden numeric(18,0) = (select idOrden from Cotizaciones coti where coti.idCotizacion = @idcotizacion)
		
		DECLARE @totalCotActivas int = (select count(*) 
										from [dbo].[Ordenes] Ord
										inner join [dbo].[Cotizaciones] Coti ON Coti.idOrden = Ord.idOrden
										where Coti.idEstatusCotizacion not in (4)
										and Ord.idOrden = @idOrden)

		IF (@totalCotActivas = 0)
			BEGIN
				--si ya no tiene cotizaciones activas (todas canceladas) se cambia la orden a estatus cancelado(10)
				UPDATE [dbo].[Ordenes]
				   SET [idEstatusOrden] = 13
				 WHERE idOrden = @idOrden

				 UPDATE [dbo].HistorialEstatusOrden
					SET fechaFinal = GETDATE()
				  WHERE idOrden = @idOrden and fechaFinal is null

				  INSERT INTO [dbo].[HistorialEstatusOrden]
							   ([idOrden], [idEstatusOrden], [fechaInicial], [fechaFinal], [idUsuario])
						 VALUES
							   (@idOrden, 13, GETDATE(), GETDATE(), @idusuario)
			END
	END

		DECLARE @preorden INT = NULL 
		SELECT @preorden = idPreorden 
		FROM   Cotizaciones 
		WHERE  idCotizacion = @idcotizacion 

		IF( @preorden IS NOT NULL )
		BEGIN
			UPDATE CotizacionDetalle  
			SET idCotizacion =  @preorden,
			idEstatusPartida = 1 
			WHERE  idCotizacion =@idcotizacion 
		END
END
go

