
CREATE VIEW GPS.tPosition
AS

SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition01]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition02]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition03]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition04]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition05]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition06]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition07]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition08]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition09]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition10]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition11]
UNION ALL
SELECT [positionID], [carID], [gpsTime], [pointed], [lo], [la], [speed], [direction], [status], [alarm], [mileage], [alarmHandle], [opUserID], [remark], [temperature], [fuel], [input1], [input2], [input3], [input4], [input5], [output1], [output2], [output3], [output4], [output5], [stopflag], [isstop]
FROM [192.168.20.110].[8833test].[dbo].[tPosition12]
go

grant select, view definition on GPS.tPosition to DevOps
go

