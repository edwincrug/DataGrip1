-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 18/05/2017
-- Description:	Obtiene los tipos de operación
-- SEL_FORMA_TIPO_DE_OPERACION_SP
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_FORMA_TIPO_DE_OPERACION_SP]

AS
BEGIN
  

	SELECT idTipoOperacion, 
		nombreTipoOperacion 
	FROM CatalogoTipoOperacion
  
  
END

go

