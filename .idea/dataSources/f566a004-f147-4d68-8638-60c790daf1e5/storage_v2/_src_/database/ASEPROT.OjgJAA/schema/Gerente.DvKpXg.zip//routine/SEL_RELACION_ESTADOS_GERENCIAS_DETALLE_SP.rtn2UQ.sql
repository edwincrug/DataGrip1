 CREATE PROCEDURE [Gerente].[SEL_RELACION_ESTADOS_GERENCIAS_DETALLE_SP] 
	@idGerencia INT
AS
BEGIN
	SELECT 
		EG.idEstadoGerencia,
		E.nombreEstado, 
		E.descripcionEstado, 
		--G.nombreGerencia, 
		--G.descripcionGerencia,
		EG.fechaAlta,
		U.nombreCompleto,
		E.idEstados
		--G.idGerencias
	FROM [Gerente].[EstadoGerencia] EG
	JOIN [Gerente].[Estados] E ON E.idEstados = EG.idEstado
	JOIN [Gerente].[Gerencias] G ON G.idGerencias = EG.idGerencia
	JOIN [Usuarios] U ON U.idUsuario = EG.idUsuario
	WHERE EG.estatus=0 AND EG.idGerencia = @idGerencia
END


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.SEL_RELACION_ESTADOS_GERENCIAS_DETALLE_SP to DevOps
 go

