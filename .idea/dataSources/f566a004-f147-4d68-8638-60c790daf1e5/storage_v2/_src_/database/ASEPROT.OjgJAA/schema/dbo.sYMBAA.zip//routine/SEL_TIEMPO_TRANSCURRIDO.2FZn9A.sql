
CREATE FUNCTION [dbo].[SEL_TIEMPO_TRANSCURRIDO](
@fecha datetime
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @minutos int
	DECLARE @horas int
	DECLARE @dias int
	DECLARE @semanas int
	DECLARE	@time int 
	DECLARE @tiempo NVARCHAR(500)

	set @time = datediff(MINUTE,@fecha, getdate()) ;

    
    SET @semanas = ((( @time/60)/24)/7);

	SET @dias = ((( @time/60)/24)%7);
	
	SET @horas = (( @time / 60) % 24);

	SET @minutos = (@time % 60);
	
	IF (@semanas>0)
	 SET @tiempo = CAST(@semanas as NVARCHAR(10))+' semanas ' + CAST(@dias as NVARCHAR(10))+ ' días ' + RIGHT('00' + CAST(@horas AS varchar(2)), 2) + ':' + RIGHT('00' + CAST(@minutos AS varchar(2)), 2);

    ELSE IF (@dias>0)
	 SET @tiempo = CAST(@dias as NVARCHAR(10))+ ' días ' + RIGHT('00' + CAST(@horas AS varchar(2)), 2) + ':' + RIGHT('00' + CAST(@minutos AS varchar(2)), 2);  
	  
	ELSE IF (@horas>0)
	 SET @tiempo = RIGHT('00' + CAST(@horas AS varchar(2)), 2) + ':' + RIGHT('00' + CAST(@minutos AS varchar(2)), 2);   

	ELSE IF (@minutos > 0)
	 SET @tiempo = '00:' + RIGHT('00' + CAST(@minutos AS varchar(2)), 2); 
	ELSE
		 SET @tiempo = '00:00' 

    RETURN @tiempo ;
END

go

