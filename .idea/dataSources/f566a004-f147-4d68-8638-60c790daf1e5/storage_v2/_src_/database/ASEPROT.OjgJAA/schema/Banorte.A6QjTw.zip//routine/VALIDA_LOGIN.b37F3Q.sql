/*
	Objetivo: Devuelve el usaurio de un Token activo
	
	------ Versionamiento
	Fecha DD/MM/AA	Autor	Descrición
	22/05/18		JEHR	Creación del SP

	------ Pruebas
	[Banorte].[VALIDA_LOGIN] 'joseetmanuel@gmail.com', 'tumama', null
*/
CREATE proc [Banorte].[VALIDA_LOGIN]
@nombreUsuario varchar(max),
@contrasenia varchar(max),
@token varchar(175)
as
begin

	declare @status int = 0,
			@msg varchar(max) = 'Error: Sql, no se pudo login'

	--select @status as [status], @msg as [msg], @nombreUsuario as us, @contrasenia as psw
	print @nombreUsuario;
	if isnull(@nombreUsuario,'') = ''
	begin 
		SET @status = 0;
		SET @msg = 'Error: Nombre de usuario vacio'
		select @status as [status], @msg as [msg]
	end 
	else
	begin
		if isnull(@contrasenia,'') = ''
		begin 
			SET @status = 0;
			SET @msg = 'Error: Contraseña vacia'
			select @status as [status], @msg as [msg]
		end 
		else
		begin
			DECLARE
				@idUsuario INT,
				@idUnidad INT
			;

			select @idUsuario = [idUsuario] from Usuarios where nombreUsuario=@nombreUsuario and contrasenia=@contrasenia

			if ISNULL(@idUsuario,'') != ''
			begin

				IF(@token IS NOT NULL)
				BEGIN
					IF EXISTS (SELECT id FROM [Mobile].[Usuario] WHERE idUsuario = @idUsuario)
					BEGIN
						IF NOT EXISTS (SELECT id FROM [Mobile].[Usuario] WHERE idUsuario = @idUsuario AND token = @token)
						UPDATE [Mobile].[Usuario] SET token = @token, alta = GETDATE() WHERE idUsuario = @idUsuario
					END
					ELSE
					BEGIN
						INSERT INTO [Mobile].[Usuario] VALUES(@idUsuario,GETDATE(),@token)
					END
				END

				SET @status = 1;
				select 
					 [idUsuario]
					,[nombreUsuario]
					,[nombreCompleto]
					,[correoElectronico]
					,[telefonoUsuario]
					, @status as [status]
					, '' as unidades
					, 0 as doc_vencidos
					, ( SELECT count ( distinct p.id) as idPromocion
						FROM Banorte.Promociones P
						INNER JOIN [Banorte].[PromocionesSuc] AS S ON S.[idPromociones] = P.id
						INNER JOIN [Banorte].[Patrocinador] PAT ON PAT.Id = s.[PatrocinadorId]
						INNER JOIN [Banorte].[Sucursales] SUC ON SUC.[PatrocinadorId] = S.[PatrocinadorId] AND SUC.[Id] = S.[SucursalId]
						INNER JOIN [Banorte].[CatalogoTipoPromocion] T ON T.[id] = P.idTipoPromocion
						WHERE  fechaInicio <= GETDATE()
						AND fechaTermino >= GETDATE()
						AND estatus = 1
					)as promociones
					, 
					(
						SELECT COUNT( distinct PC.idPromocion)
						FROM [PromocionesCodigos] AS PC
						INNER JOIN [Banorte].[Promociones] as P on P.id = PC.IdPromocion
						INNER JOIN [Banorte].[PromocionesSuc] AS S on S.[idPromociones] = P.id
						INNER JOIN [Banorte].[Patrocinador] as T on T.[Id] = S.PatrocinadorId
						WHERE IdUsuario = @idUsuario
						AND Aplicadas<NumeroMaximo
						AND P.fechaTermino >= GETDATE()

					) as misPrimociones
					, (select count(codigo) from PromocionesCodigos where IdUsuario = @idUsuario)
					verPromociones
					, '' as promociones_car
				from Usuarios u 
				where  [idUsuario] = @idUsuario

				Select 
					r.[idUnidad]
					,u.[descripcion] as alias
					--,u.[noPoliza] as noPoliza
					,p.[numero] noPoliza
					,u.[vin] as serie
					,u.[placas]
					,u.[frente] as foto 
				from [dbo].[usuarioUnidadContratoOperacion] as r
					INNER JOIN [dbo].[Unidades] as u on u.[idUnidad] = r.[idUnidad]
					LEFT JOIN (SELECT id, numero, estatus, idUnidad FROM [Mobile].[Poliza] WHERE estatus = 1) p
					ON u.idUnidad = p.idUnidad
					--LEFT JOIN [Mobile].[Poliza] p ON u.[idUnidad] = p.[idUnidad]
					where r.[idUsuario] = @idUsuario
				ORDER BY [fecha] DESC;

				--Select [img], [id],  [Descripcion] as nombre FROM [Banorte].[CatalogoTipoPromocion];
				EXEC [Mobile].[Sel_TipoPromociones_Total_Sp] @idUsuario

			end
			else
			begin
				SET @status = 0;
				SET @msg = 'Error: No coincide usuario y contraseña'
				select @status as [status], @msg as [msg]
			end
		end
	end
end
go

grant execute, view definition on Banorte.VALIDA_LOGIN to DevOps
go

