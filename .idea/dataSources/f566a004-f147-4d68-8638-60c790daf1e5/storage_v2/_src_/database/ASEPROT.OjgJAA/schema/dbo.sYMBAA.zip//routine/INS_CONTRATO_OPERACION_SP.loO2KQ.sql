-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 18/05/2017
-- Description:	Inserta la relacion de operacion con el contrato de la licitación
-- INS_CONTRATO_OPERACION_SP 3, 1
-- =============================================
 CREATE PROCEDURE [dbo].[INS_CONTRATO_OPERACION_SP]
	 @idOperacion nvarchar(50)
	,@idContrato nvarchar(50)
AS
BEGIN
	
  DECLARE @idContratoOperacion INT

  IF EXISTS(SELECT idOperacion FROM Operaciones WHERE idOperacion = @idOperacion)
	BEGIN
	  
		IF NOT EXISTS (SELECT idOperacion FROM ContratoOperacion WHERE idOperacion = @idOperacion)
			BEGIN
				INSERT INTO [ContratoOperacion] (
					[idOperacion]
					,[idContrato])
				VALUES(
				@idOperacion 
				,@idContrato)

				SET @idContratoOperacion = @@IDENTITY 
			END
		ELSE
			BEGIN
				UPDATE [ContratoOperacion] 
					SET idContrato = @idContrato 
					WHERE idOperacion = @idOperacion

				SELECT @idContratoOperacion = idContratoOperacion 
					FROM [ContratoOperacion]
					WHERE idOperacion = @idOperacion

			END

			SELECT @idContratoOperacion AS idContratoOperacion
		
	END
  
  
END


go

