
create PROCEDURE [dbo].[SEL_ORDEN_ESPECIAL_TIENE_PAGO_COMPLETO_SP]
@idpresupuestoEspecial AS INT
AS
BEGIN


	IF NOT EXISTS(select * from OrdenesPresupuestoEspecial where idpresupuesto=@idpresupuestoEspecial )
		BEGIN
			SELECT 1 AS result
		END
	ELSE IF EXISTS(  
				SELECT *,PO.idPresupuesto
				FROM PresupuestoOrden   PO 
				RIGHT JOIN  OrdenesPresupuestoEspecial OPE
				ON PO.idOrden = OPE.idOrden 
				WHERE OPE.idpresupuesto=@idpresupuestoEspecial 
				AND PO.idPresupuestoOrden IS NULL
			 )
	BEGIN
	   SELECT 0 AS result
	END
	ELSE
	BEGIN
		SELECT 1 AS result
	END
END
go

