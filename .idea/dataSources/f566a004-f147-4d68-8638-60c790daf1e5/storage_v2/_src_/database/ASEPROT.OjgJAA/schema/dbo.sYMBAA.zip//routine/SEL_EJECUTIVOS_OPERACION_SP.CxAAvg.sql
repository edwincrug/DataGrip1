-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 05/07/2017
-- Description:	
-- [SEL_EJECUTIVOS_OPERACION_SP] 3
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_EJECUTIVOS_OPERACION_SP]
	@idContratoOperacion INT,
	@idRol INT
AS
BEGIN
	
	IF(@idRol != 2)
		BEGIN
			SELECT US.nombreCompleto, US.idUsuario 
				FROM Usuarios US
				INNER JOIN ContratoOperacionUsuario COU ON US.idUsuario = COU.idUsuario
			WHERE COU.idCatalogoRol = @idRol AND COU.idContratoOperacion = @idContratoOperacion
		END
	ELSE
	   BEGIN
			SELECT US.nombreCompleto, US.idUsuario 
				FROM Usuarios US
				INNER JOIN ContratoOperacionUsuario COU ON US.idUsuario = COU.idUsuario
			WHERE COU.idCatalogoRol = 3 AND COU.idContratoOperacion = @idContratoOperacion
	   END
END



go

