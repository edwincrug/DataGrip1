/*
JAGA
FUNCION PARA EXTRAER LOS CORREOS PARA ATT
21/09/2018
*/
CREATE FUNCTION [dbo].[fnNotasXOrden](@numeroOrden VARCHAR(100))
Returns VARCHAR(MAX)
AS
BEGIN 

DECLARE @result varchar(8000) = ''

DECLARE @Notas TABLE(id int identity(1,1),nombreCompleto VARCHAR(200),descripcionNota VARCHAR(8000))

INSERT INTO @Notas
SELECT U.[nombreCompleto],N.[descripcionNota] 
FROM   [dbo].[Notas] AS N
			INNER JOIN [dbo].[Usuarios] AS U ON U.[idUsuario] = N.[idUsuario]
			INNER JOIN [dbo].[Ordenes] AS O ON N.idOrden = O.idOrden 
			--INNER JOIN [dbo].[EstatusOrdenes] AS EO ON EO.idEstatusOrden = N.idEstatusOrden
	WHERE  O.numeroOrden = @numeroOrden

DECLARE @i int =1, @n int = (SELECT COUNT(*) FROM @Notas)
DECLARE @nombre VARCHAR(200),@nota VARCHAR(8000),@separador VARCHAR(10)=''

IF @n>0
BEGIN
	WHILE @i<=@n
	BEGIN

	SELECT @nombre=nombreCompleto,@nota=descripcionNota FROM @Notas WHERE id=@i

	SET @result = @result + @separador + @nombre +': ' + @nota

	SET @separador = ' //'

	SET @i = @i +1
	END
END

RETURN @result
END
go

