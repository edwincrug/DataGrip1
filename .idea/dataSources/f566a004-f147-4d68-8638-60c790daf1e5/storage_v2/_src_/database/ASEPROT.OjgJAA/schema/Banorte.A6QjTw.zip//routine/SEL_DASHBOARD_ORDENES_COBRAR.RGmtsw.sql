

-- ==========================================================================================
-- Author:		YJH
-- Create date: 2018/01/21
-- Description:	Devuelve los resultados del cuadrante de Ordenes por Cobrar en el Dashboard
-- ==========================================================================================
-- [Banorte].[SEL_DASHBOARD_ORDENES_COBRAR] 20, null, 677
CREATE PROCEDURE [Banorte].[SEL_DASHBOARD_ORDENES_COBRAR]
@idOperacion NUMERIC(20,0),
@idZona NUMERIC( 20,0 )= NULL,
@idUsuario NUMERIC(18,0) = NULL
AS
BEGIN

DECLARE @Cobranza TABLE( idEstatus NUMERIC(18), promedio NUMERIC(18), Monto NUMERIC(18,2), MontoCosto NUMERIC(18,2), numeroOrden nvarchar(100));

DECLARE @idContratoOperacionUsuario int;

DECLARE @rolUsuario int = [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion)

DECLARE @idEstatusOrden NUMERIC(13) = 8;
WHILE (@idEstatusOrden < 13)
	BEGIN
		IF @rolUsuario <> 2
			BEGIN
				IF @rolUsuario <> 4
					BEGIN
					--------------------CLIENTE-------------------------------						
					SELECT @idContratoOperacionUsuario = COU.idContratoOperacionUsuario
					FROM Usuarios U 
						JOIN ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
						JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
					WHERE U.idUsuario = @idUsuario and CO.idOperacion = @idOperacion

					IF @idEstatusOrden = 8
						BEGIN
						INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
							((select @idEstatusOrden as id,  
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,							
							isnull(venta,0) as venta,
							isnull(costo,0) as costo,
							numeroOrden
							from (select								
								(SELECT [dbo].[SEL_NOMBRE_CLIENTE](O.idContratoOperacion)) AS nombreCliente,
								O.consecutivoOrden,
								O.numeroOrden,
								U.numeroEconomico,
								Z.nombre AS nombreZona,
								CTO.nombreTipoOrdenServicio,
								O.fechaCreacionOden,	
								O.comentarioOrden,
								EO.nombreEstatusOrden,
								UR.nombreCompleto,
								(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS venta,
								(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS costo,
								DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEsperaTranscurrido,
								O.idOrden,
								Z.idZona
							FROM Ordenes O
								JOIN Unidades U ON U.idUnidad = O.idUnidad
								JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
								JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
								JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
								JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
								JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
								JOIN Partidas..Zona Z ON Z.idZona = O.idZona 
								WHERE CO.idOperacion = @idOperacion AND O.idEstatusOrden = @idEstatusOrden 
								AND Z.idZona in (SELECT idZona FROM ContratoOperacionUsuarioZona 
								WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario) 
						)as sel group by venta, costo, numeroOrden))
						END
					IF @idEstatusOrden = 9
						BEGIN						
					------------------------PREFACTURA INI-------------------------
					INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
							((select @idEstatusOrden as id, 
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							isnull(total,0) as venta,
							isnull(subtotal,0) as costo
							,numeroOrden
							from (SELECT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
								dc.numeroCopade As numeroCopade,
								dc.ordensurtimiento As ordenSurtimiento,
								dc.numeroEstimacion As numeroEstimaicon,
								dc.descripcion As descripcion,
								dc.subTotal As subTotal,
								dc.total As Total,
								O.numeroOrden,
								dc.fechaRecepcionCopade As fechaCopade
									FROM OA 
								inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
								inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
								inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
								inner join Ordenes o on o.idOrden = dco.idOrden 
								inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion 
								where co.idOperacion = @idOperacion and O.idEstatusOrden = @idEstatusOrden
					)as sel))
					------------------------PREFACTURA END-------------------------
					END	
					IF @idEstatusOrden = 10
						BEGIN
						------------------------ENVIADAS Ini-------------------------
						INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
							((select @idEstatusOrden as id, 
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,							
							isnull(total,0) as venta,
							isnull(subtotal,0) as costo
							,numeroOrden
							from (SELECT DISTINCT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
										dc.numeroCopade,dc.ordensurtimiento,
										dc.numeroEstimacion,dc.descripcion,
										dc.subTotal as subtotal,
										dc.total,dc.fechaRecepcionCopade
										,O.numeroOrden
									FROM OrdenAgrupada OA 
										inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
										inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
										inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
										inner join Ordenes o on o.idOrden = dco.idOrden 
										inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
										where O.idEstatusOrden=@idEstatusOrden and co.idOperacion = @idOperacion )as sel group by total, subtotal, numeroOrden))
						------------------------ENVIADAS Ini-------------------------
						END					
					IF @idEstatusOrden = 12
						BEGIN
					------------------------ENVIADAS Ini-------------------------
					INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
							((select @idEstatusOrden as id, 
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							isnull(total,0) as venta,
							isnull(subtotal,0) as costo
							,numeroOrden
							from (SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
								dc.numeroCopade,
								dc.ordensurtimiento,
								dc.numeroEstimacion,
								dc.descripcion,
								dc.subTotal,
								dc.total,
								dc.fechaRecepcionCopade
								,O.numeroOrden
								FROM OrdenAgrupada OA
								inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
								inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
								inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
								inner join Ordenes o on o.idOrden = dco.idOrden 
								inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
								inner join Partidas..Zona z on z.idZona = o.idZona
								inner join Unidades u on u.idUnidad = o.idUnidad
								inner join CatalogoTipoOrden t on t.idTipoOrden = o.idTipoOrden
								inner join EstatusOrdenes e on e.idEstatusOrden = o.idEstatusOrden
									where O.idEstatusOrden = @idEstatusOrden
											and co.idOperacion = @idOperacion
											and o.idZona in(
											select distinct idZona from ContratoOperacionUsuarioZona couz 
																	join ContratoOperacionUsuario cou on cou.idContratoOperacionUsuario=couz.idContratoOperacionUsuario
											where idUsuario = @idUsuario
											)
						)as sel group by numeroOrden, total, subtotal))
					------------------------ENVIADAS Ini-------------------------
					END
					--------------------CLIENTE-------------------------------
					END
				ELSE
					BEGIN
					--------------------PROVEDOR-------------------------------
					IF @idEstatusOrden = 8
						BEGIN
						INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
							((select @idEstatusOrden as id,
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																				FROM HistorialEstatusOrden HEO													
																					inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																					INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																				WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
							isnull(venta,0) as venta,
							isnull(costo,0) as costo
							,numeroOrden
							from (SELECT 
									(SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente,
									O.consecutivoOrden,
									O.numeroOrden,
									U.numeroEconomico,
									Z.nombre AS nombreZona,
									CTO.nombreTipoOrdenServicio,
									O.fechaCreacionOden,	
									O.comentarioOrden,
									EO.nombreEstatusOrden,
									UR.nombreCompleto,
									(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS venta,
									(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS costo,
									DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEsperaTranscurrido,
									O.idOrden,
									Z.idZona
								FROM Ordenes O
									JOIN Unidades U ON U.idUnidad = O.idUnidad
									JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
									JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
									JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
									JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
									JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
									JOIN Partidas..Zona Z ON Z.idZona = O.idZona WHERE CO.idOperacion = @idOperacion 
									AND O.idEstatusOrden = @idEstatusOrden 
									AND (SELECT CASE WHEN EXISTS (SELECT 1 FROM Cotizaciones C where C.idOrden = O.idOrden and C.idEstatusCotizacion in (3) AND C.idTaller in (SELECT COUP.idProveedor
										FROM ContratoOperacionUsuario COU 
										INNER JOIN ContratoOperacion CO on CO.idContratoOperacion = COU.idContratoOperacion
										INNER JOIN ContratoOperacionUsuarioProveedor COUP ON COUP.idContratoOperacionUsuario =  COU.idContratoOperacionUsuario
										WHERE COU.idUsuario = @idUsuario and CO.idOperacion = @idOperacion) ) THEN 'true' ELSE 'false' END ) = 'true') as tab1  group by numeroOrden, venta, costo))
						END
					IF @idEstatusOrden = 9
					BEGIN					
					------------------------PREFACTURA INI-------------------------
					INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
					((select @idEstatusOrden as id,  
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					isnull(total,0) as venta,
					isnull(subtotal,0) as costo
					,numeroOrden
					from (SELECT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
						dc.numeroCopade As numeroCopade,
						dc.ordensurtimiento As ordenSurtimiento,
						dc.numeroEstimacion As numeroEstimaicon,
						dc.descripcion As descripcion,
						dc.subTotal As subTotal,
						dc.total As Total,						
						dc.fechaRecepcionCopade As fechaCopade
						,O.numeroOrden
							FROM OrdenAgrupada OA 
						inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
						inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
						inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
						inner join Ordenes o on o.idOrden = dco.idOrden 
						inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion 
						inner join Cotizaciones c on c.idOrden=o.idOrden  
										where co.idOperacion = @idOperacion and O.idEstatusOrden = @idEstatusOrden and c.idTaller in (
												select coup.idProveedor from ContratoOperacionUsuario cou 
														join ContratoOperacionUsuarioProveedor coup on cou.idContratoOperacionUsuario=coup.idContratoOperacionUsuario and cou.idUsuario = @idUsuario
										) ) as tab1  group by numeroOrden, total, subtotal))
					------------------------PREFACTURA END-------------------------
					END	
					IF @idEstatusOrden = 10
					BEGIN
					------------------------ENVIADAS Ini-------------------------
					INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
					((select @idEstatusOrden as id,  
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,					
					isnull(total,0) as venta,
					isnull(subtotal,0) as costo
					,numeroOrden
					from (SELECT DISTINCT
						(SELECT [dbo].[SEL_NOMBRE_CLIENTE](O.idContratoOperacion)) nombreCliente,
						DC.numeroCopade,
						ISNULL(DC.ordenSurtimiento, 'SIN SURTIMIENTO')as folio,
						ISNULL(DC.total,0) total,
						Z.nombre,						
						DC.descripcion,						
						DC.idDatosCopade,						
						TA.idOrdenAgrupada,
						DC.fechaRecepcionCopade,
						DC.subTotal,
						DC.numeroEstimacion
						,O.numeroOrden
						FROM DatosCopade DC 
						JOIN DatosCopadeOrden DCO ON DCO.idDatosCopade = DC.idDatosCopade
						JOIN Ordenes O ON O.idOrden = DCO.idOrden 
						JOIN ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
						JOIN Cotizaciones C ON C.idOrden = O.idOrden
						LEFT JOIN FacturaCotizacion FCO ON FCO.idCotizacion = C.idCotizacion
						JOIN Unidades U ON U.idUnidad=O.idUnidad
						JOIN Partidas..Zona Z ON Z.idZona = O.idZona
						JOIN OrdenAgrupadaDetalle TAD ON TAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
						JOIN OrdenAgrupada TA ON TA.idOrdenAgrupada = TAD.idOrdenAgrupada
						where co.idOperacion = @idOperacion and O.idEstatusOrden = @idEstatusOrden and c.idTaller in (
											select coup.idProveedor from ContratoOperacionUsuario cou 
													join ContratoOperacionUsuarioProveedor coup on cou.idContratoOperacionUsuario=coup.idContratoOperacionUsuario and cou.idUsuario = @idUsuario
									) ) as tab1  group by numeroOrden, total, subtotal))
						 							
					------------------------ENVIADAS Ini-------------------------
					END					
					IF @idEstatusOrden = 12
					BEGIN
					------------------------ENVIADAS Ini-------------------------
					INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
					((select @idEstatusOrden as id, 
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,					
					isnull(total,0) as venta,
					isnull(subtotal,0) as costo
					,numeroOrden
					from (SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
						dc.numeroCopade,
						dc.ordensurtimiento,
						dc.numeroEstimacion,
						dc.descripcion,
						dc.subTotal,
						dc.total,
						dc.fechaRecepcionCopade
						,O.numeroOrden
						FROM OrdenAgrupada OA
						inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
						inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
						inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
						inner join Ordenes o on o.idOrden = dco.idOrden 
						inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
						inner join Partidas..Zona z on z.idZona = o.idZona
						inner join Unidades u on u.idUnidad = o.idUnidad
						inner join CatalogoTipoOrden t on t.idTipoOrden = o.idTipoOrden
						inner join EstatusOrdenes e on e.idEstatusOrden = o.idEstatusOrden
							where co.idOperacion = @idOperacion and O.idEstatusOrden = @idEstatusOrden
								and o.idOrden in(
								select distinct idOrden from Cotizaciones where idTaller in(
									select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario,@idOperacion)
								)) ) as tab1  group by numeroOrden, total, subtotal))
					------------------------ENVIADAS Ini-------------------------
					END
					--------------------PROVEDOR-------------------------------
					END
			END
		ELSE
			BEGIN
			------------------------admin INI------------------------------
			IF @idEstatusOrden = 8
				BEGIN				
				------------------------por cobrar Ini-------------------------
				INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
					((select @idEstatusOrden as id, 
							(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio FROM HistorialEstatusOrden HEO													
								inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
								INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
							WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					isnull(venta,0) as venta,
					isnull(costo,0) as costo
					,numeroOrden
					from (SELECT DISTINCT
							(SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente,
							O.consecutivoOrden,
							O.numeroOrden,
							U.numeroEconomico,
							Z.nombre AS nombreZona,
							CTO.nombreTipoOrdenServicio,
							O.fechaCreacionOden,	
							O.comentarioOrden,
							EO.nombreEstatusOrden,
							UR.nombreCompleto,
							(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS venta,
							(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 3, @idUsuario, @rolUsuario)) AS costo,
							DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEsperaTranscurrido,
							O.idOrden,
							Z.idZona
						FROM Ordenes O
							JOIN Unidades U ON U.idUnidad = O.idUnidad
							JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
							JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
							JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
							JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
							JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
							JOIN Partidas..Zona Z ON Z.idZona = O.idZona WHERE CO.idOperacion = @idOperacion AND O.idEstatusOrden = @idEstatusOrden ) as tab1 ))
				------------------------por cobrar Fin-------------------------			
				END		
			IF @idEstatusOrden = 9
				BEGIN				
				------------------------PREFACTURA INI-------------------------
				INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
					((select @idEstatusOrden as id,  
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					isnull(total,0) as venta,
					isnull(subtotal,0) as costo
					,numeroOrden
					from 
					(	 SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,

						dc.numeroCopade As numeroCopade,
						dc.ordensurtimiento As ordenSurtimiento,
						dc.numeroEstimacion As numeroEstimaicon,
						dc.descripcion As descripcion,
						dc.subTotal As subTotal,
						dc.total As Total,
						O.numeroOrden,
						dc.fechaRecepcionCopade As fechaCopade
							FROM OrdenAgrupada OA
						inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
						inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
						inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
						inner join Ordenes o on o.idOrden = dco.idOrden 
						inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
						where co.idOperacion = @idOperacion and O.idEstatusOrden=@idEstatusOrden ) as sel  group by numeroOrden, total, subtotal))
				------------------------PREFACTURA END-------------------------
				END	
			IF @idEstatusOrden = 10
				BEGIN
				------------------------ENVIADAS Ini-------------------------
				INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
					((select @idEstatusOrden as id, 
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					isnull(total,0) as venta,
					isnull(subtotal,0) as costo
					,numeroOrden
					from 
					(	 SELECT DISTINCT (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,
								dc.numeroCopade,dc.ordensurtimiento,
								dc.numeroEstimacion,dc.descripcion,
								dc.subTotal as subtotal,
								dc.total,dc.fechaRecepcionCopade
								,O.numeroOrden
							FROM OrdenAgrupada OA
								inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
								inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
								inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
								inner join Ordenes o on o.idOrden = dco.idOrden  
								inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
								where co.idOperacion = @idOperacion and O.idEstatusOrden=@idEstatusOrden ) as sel  group by numeroOrden, total, subtotal))
				------------------------ENVIADAS Ini-------------------------
				END
			IF @idEstatusOrden = 11
				BEGIN
				------------------------ABONADAS Ini-------------------------
				INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
					((select @idEstatusOrden as id,
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP) ) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					ISNULL(total,0) as venta,
					ISNULL(subtotal,0) as costo
					,numeroOrden
					from 
					(	SELECT DISTINCT
							(SELECT [dbo].[SEL_NOMBRE_CLIENTE](O.idContratoOperacion)) nombreCliente,
							DC.numeroCopade,
							ISNULL(DC.ordenSurtimiento, 'SIN SURTIMIENTO')as folio,								
							ISNULL(DC.total,0) total,							
							Z.nombre,
							DC.descripcion,
							DC.idDatosCopade,
							TA.idOrdenAgrupada,
							DC.fechaRecepcionCopade,
							DC.subTotal,
							DC.numeroEstimacion
							,O.numeroOrden
							FROM DatosCopade DC 
							JOIN DatosCopadeOrden DCO ON DCO.idDatosCopade = DC.idDatosCopade
							JOIN Ordenes O ON O.idOrden = DCO.idOrden 
							JOIN ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
							JOIN Cotizaciones C ON C.idOrden = O.idOrden
							LEFT JOIN FacturaCotizacion FCO ON FCO.idCotizacion = C.idCotizacion
							JOIN Unidades U ON U.idUnidad=O.idUnidad
							JOIN Partidas..Zona Z ON Z.idZona = O.idZona
							JOIN OrdenAgrupadaDetalle TAD ON TAD.idDatosCopadeOrden = DCO.idDatosCopadeOrden
							JOIN OrdenAgrupada TA ON TA.idOrdenAgrupada = TAD.idOrdenAgrupada
							where CO.idOperacion = @idOperacion and O.idEstatusOrden=@idEstatusOrden
							 AND O.numeroOrden IN (SELECT numeroOrdenGlobal FROM OrdenGlobalAbono)) as sel  group by numeroOrden, total, subtotal))
				------------------------ABONADAS Ini-------------------------
				END
			IF @idEstatusOrden = 12
				BEGIN
				------------------------PAGADAS Ini-------------------------
				INSERT INTO @Cobranza ( idEstatus, promedio, Monto, MontoCosto, numeroOrden) 
					((select @idEstatusOrden as id,  
					(SELECT AVG( DATEDIFF(hour, HEO.fechaInicial, CURRENT_TIMESTAMP)) Promedio
																		FROM HistorialEstatusOrden HEO													
																			inner join Ordenes ORD ON ORD.idOrden = HEO.idOrden 
																			INNER JOIN ContratoOperacion COP ON ORD.idContratoOperacion = COP.idContratoOperacion
																		WHERE HEO.idEstatusOrden = @idEstatusOrden and COP.idOperacion = @idOperacion) as prom,
					ISNULL(total,0) as venta,
					ISNULL(subtotal,0) as costo
					,numeroOrden
					from 
					(	SELECT distinct (SELECT [dbo].[SEL_NOMBRE_CLIENTE](o.idContratoOperacion)) AS nombreCliente ,		
							dc.numeroCopade,
							dc.ordensurtimiento,
							dc.numeroEstimacion,
							dc.descripcion,
							dc.subTotal,							
							dc.total,
							dc.fechaRecepcionCopade
							,O.numeroOrden
							FROM OrdenAgrupada OA
							inner join OrdenAgrupadaDetalle OAD on OAD.idOrdenAgrupada = OA.idOrdenAgrupada
							inner join DatosCopadeOrden dco on dco.idDatosCopadeOrden = oad.idDatosCopadeOrden
							inner join DatosCopade dc on dc.idDatosCopade = dco.idDatosCopade
							inner join Ordenes o on o.idOrden = dco.idOrden 
							inner join ContratoOperacion co on co.idContratoOperacion = o.idContratoOperacion
							inner join Partidas..Zona z on z.idZona = o.idZona
							inner join Unidades u on u.idUnidad = o.idUnidad
							inner join CatalogoTipoOrden t on t.idTipoOrden = o.idTipoOrden
							inner join EstatusOrdenes e on e.idEstatusOrden = o.idEstatusOrden
								where co.idOperacion = @idOperacion and O.idEstatusOrden=@idEstatusOrden ) as sel  group by numeroOrden, total, subtotal))
				------------------------PAGADAS Ini-------------------------
				END
			------------------------admin END------------------------------
			END			
						
	SET @idEstatusOrden = @idEstatusOrden + 1;
	END

select max(idEstatus) as idEstatus, (SELECT nombreEstatusOrden FROM EstatusOrdenes WHERE idEstatusOrden = idEstatus) as estatus

,(CASE idEstatus WHEN 8 THEN '#ffa8ff' WHEN 9 THEN '#be8cff'  WHEN 10 THEN '#b75ad1' WHEN 11 THEN '#852985' WHEN 12 THEN '#5b165b' ELSE '#1c001c' END) as color
from @Cobranza group by idEstatus

SELECT idEstatus,  isnull(promedio,0) as promedio, Monto,  MontoCosto, numeroOrden FROM @Cobranza;


END

go

grant execute, view definition on Banorte.SEL_DASHBOARD_ORDENES_COBRAR to DevOps
go

