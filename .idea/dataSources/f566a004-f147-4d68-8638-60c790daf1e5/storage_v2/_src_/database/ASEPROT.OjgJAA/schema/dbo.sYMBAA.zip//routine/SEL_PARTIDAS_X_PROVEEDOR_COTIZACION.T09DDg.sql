-- =============================================
-- Author:		Sahirely Yam
-- Create date: 17/07/2017
-- =============================================
-- EXECUTE [dbo].[SEL_PARTIDAS_X_PROVEEDOR_COTIZACION]  267, 89
CREATE PROCEDURE [dbo].[SEL_PARTIDAS_X_PROVEEDOR_COTIZACION] 
	@idProveedor INT,
	@idCotizacion INT
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @tipoUniDeCoti int
	
	select @tipoUniDeCoti = U.idTipoUnidad
	from Cotizaciones C
	inner join Ordenes O on C.idOrden = O.idOrden
	inner join Unidades U on O.idUnidad = U.idUnidad
	where C.idCotizacion = @idCotizacion

	SELECT PAR.idPartida FROM Partidas..ProveedorPartida PAR
	JOIN Partidas..ProveedorCotizacion PACOT ON PAR.idProveedorCotizacion = PACOT.idProveedorCotizacion 
	WHERE PACOT.idProveedor = @idProveedor
		and PACOT.idUnidad = @tipoUniDeCoti

END
go

