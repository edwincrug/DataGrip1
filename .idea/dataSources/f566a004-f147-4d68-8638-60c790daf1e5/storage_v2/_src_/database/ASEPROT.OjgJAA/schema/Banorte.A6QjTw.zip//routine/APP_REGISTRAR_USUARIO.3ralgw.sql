/*
	Fecha			Autor			Descripción
	21-May-2018		José Etmanuel	Se crea el SP que Registra un usuario
	21-May-2018		José Etmanuel	Separo al usuario de la unidad
	22-May-2018		José Etmanuel	Agreago status
									1 = Registrado
									2 = Error no se pudo registrar
									3 = Usuario ya registrado
	05-Jun-2018		José Etmanuel	Agreago update y regreso los datos del usuario
	26-06-2018		Jesús Santibañez Modifico campos que son editables de usuario
	27-Jun-2018		José Etmanuel	Modifico para regresar lo mismo que el Login
*/

CREATE proc [Banorte].[APP_REGISTRAR_USUARIO]
@idUsuario int = 0,
@nombreUsuario varchar(max) = '',
@contrasenia varchar(max) = '',
@telefonoUsuario varchar(max),
@nombreCompleto varchar(max),
@correoElectronico varchar(max) ='',
@token varchar(175) = null,
@nuevaContrasena bit = 0,
@passwordActual		varchar(10) = ''
as
begin
	declare @idUsuarioEsc int,
			@mensaje varchar(max)= 'Error desconocido',
			@status int = 2;

	if isnull(@nombreCompleto,'') = ''  or isnull(@telefonoUsuario,'') = '' 
	begin 
		SET @mensaje= 'No se puede registrar el usuario datos vacios';
		select @status as [status], @mensaje as [msg], @idUsuario as idUsuario
	end
	else
	begin
		if exists (select * from Usuarios where idUsuario = @idUsuario)
		begin

			IF (@nuevaContrasena = 1)
			BEGIN
				IF EXISTS (SELECT idUsuario FROM Usuarios WHERE idUsuario = @idUsuario AND contrasenia = @passwordActual)
				BEGIN
					Update Usuarios
					SET
						nombreCompleto = @nombreCompleto
						,contrasenia = @contrasenia
						,telefonoUsuario = @telefonoUsuario
					where idUsuario = @idUsuario

					select  @nombreUsuario =[nombreUsuario]
						,@contrasenia = contrasenia
					from Usuarios u  where idUsuario = @idUsuario
			
					EXEC [Banorte].[VALIDA_LOGIN] @nombreUsuario, @contrasenia, NULL
				END
				ELSE
				BEGIN
					select 2 as [status], 'La contraseña anterior no coincide' as [msg], @idUsuarioEsc as idUsuario
				END
			END
			ELSE
			BEGIN
				Update Usuarios
				SET
					nombreCompleto = @nombreCompleto
					,telefonoUsuario = @telefonoUsuario
				where idUsuario = @idUsuario

				set @mensaje='Usuario Actualizado ' + cast(@idUsuario as varchar(max));
				SET @status = 1;

				select  @nombreUsuario =[nombreUsuario]
						,@contrasenia = contrasenia
					from Usuarios u  where idUsuario = @idUsuario
			
				EXEC [Banorte].[VALIDA_LOGIN] @nombreUsuario, @contrasenia, NULL
			END

		end
		else
		begin
			if exists (select * from Usuarios where nombreUsuario = @nombreUsuario) 
			begin
				set @mensaje='El nombre de usuario ya está registrado';
				select @idUsuarioEsc=idUsuario from Usuarios where nombreUsuario = @nombreUsuario
				SET @status = 3;
				select @status as [status], @mensaje as [msg], @idUsuarioEsc as idUsuario
			end
			else
			begin
				INSERT INTO [dbo].[Usuarios]([nombreUsuario],[contrasenia],[idCatalogoTipoUsuarios],[nombreCompleto],[correoElectronico],[telefonoUsuario])
					VALUES(@nombreUsuario,@contrasenia,6,@nombreCompleto,@correoElectronico,@telefonoUsuario);
				set @idUsuarioEsc = (select @@IDENTITY);
				set @mensaje='Usuario Registrado ' + cast(@idUsuarioEsc as varchar(max));
				SET @status = 1;

				IF(@token IS NOT NULL)
				BEGIN
					INSERT INTO [Mobile].[Usuario] VALUES(@idUsuarioEsc,GETDATE(),@token)
				END

				EXEC [Banorte].[VALIDA_LOGIN] @nombreUsuario, @contrasenia, @token
			end
		end
	end
end
go

grant execute, view definition on Banorte.APP_REGISTRAR_USUARIO to DevOps
go

