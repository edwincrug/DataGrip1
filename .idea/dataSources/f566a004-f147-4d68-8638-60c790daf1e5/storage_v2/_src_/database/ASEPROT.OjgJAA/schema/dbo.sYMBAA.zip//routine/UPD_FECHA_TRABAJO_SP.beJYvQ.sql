
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 05/06/2017
-- Description:	Con esto se guarda la fecha real de trabajos
-- ==========================================================================================

CREATE PROCEDURE [dbo].[UPD_FECHA_TRABAJO_SP]
    @idOrden NUMERIC(20,0),
    @fechaInicio VARCHAR(MAX)
AS   
	DECLARE @Comp NUMERIC(20,0);
	
	--DECLARE @idOrden NUMERIC(20,0);
	--SET @idOrden = 10;

	--SELECT idOrden FROM Ordenes WHERE idOrden = @idOrden
	SET @Comp = (SELECT idOrden FROM Ordenes WHERE idOrden = @idOrden);
	-- SELECT @Comp

	IF( @Comp IS NULL )
		BEGIN
			SELECT Success = 0, Msg = 'No existe el idOrden que especificó';
		END
	ELSE
		BEGIN
			UPDATE Ordenes SET fechaInicioTrabajo = CONVERT(Datetime, @fechaInicio, 120) WHERE idOrden = @idOrden;
			SELECT Success = 1, Msg = 'Se actualizo correctamente';
		END
go

