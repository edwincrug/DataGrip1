
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 16/05/2017
-- Description:	Store para los parametros usados en la aplicación
-- ==========================================================================================

CREATE PROCEDURE [dbo].[APP_SETTINGS]
    
AS   
	-- Variables para los KPI's de mejorar
	DECLARE @kpi1 numeric(3,0)
	DECLARE @kpi2 numeric(3,0)
	DECLARE @kpi3 numeric(3,0)
	DECLARE @kpi4 numeric(3,0)
	DECLARE @kpi5 numeric(3,0)
	-- Variables para los KPI's de premiar
	DECLARE @kpi6 numeric(3,0)
	DECLARE @kpi7 numeric(3,0)
	DECLARE @kpi8 numeric(3,0)
	DECLARE @kpi9 numeric(3,0)
	DECLARE @kpi10 numeric(3,0)
	-- Variables para la vigencia del token
	DECLARE @Vigencia numeric(18,0)

	-- SETEAMOS VALORES: Estos valores deberan cambiar manualmente
	SET @kpi1 = 1;
	SET @kpi2 = 2;
	SET @kpi3 = 3;
	SET @kpi4 = 4;
	SET @kpi5 = 5;

	SET @kpi6 = 6;
	SET @kpi7 = 7;
	SET @kpi8 = 8;
	SET @kpi9 = 9;
	SET @kpi10 = 10;

	SET @Vigencia = 120;

	SELECT 
		kpi1_id = @kpi1,
		kpi1_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi1),
		kpi2_id = @kpi2,
		kpi2_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi2),
		kpi3_id = @kpi3,
		kpi3_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi3),
		kpi4_id = @kpi4,
		kpi4_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi4),
		kpi5_id = @kpi5,
		kpi5_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi5),
		kpi6_id = @kpi6,
		kpi6_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi6),
		kpi7_id = @kpi7,
		kpi7_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi7),
		kpi8_id = @kpi8,
		kpi8_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi8),
		kpi9_id = @kpi9,
		kpi9_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi9),
		kpi10_id = @kpi10,
		kpi10_name = (SELECT nombreKpi FROM CatalogoKPI WHERE idCatalogoKpi = @kpi10),
		vigencia = @Vigencia



go

