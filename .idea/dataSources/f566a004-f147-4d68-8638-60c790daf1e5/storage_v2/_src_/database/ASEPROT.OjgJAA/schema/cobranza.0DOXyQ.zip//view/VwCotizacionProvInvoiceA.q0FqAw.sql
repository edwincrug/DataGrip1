









CREATE VIEW [cobranza].[VwCotizacionProvInvoiceA]
AS
SELECT --top 10
       distinct
       C.numeroCotizacion, 
       C.idCotizacion, 
	   GAE.OTE_IDPROVEEDOR,
	   GAE.OTE_ORDENPEMEX,
	   FC.numFactura

      FROM Ordenes O  --with (nolock)
	  
	  INNER join [dbo].[Cotizaciones] C --with (nolock)
	  ON O.[idOrden] = c.[idOrden]

inner JOIN [192.168.20.29].[GAAutoExpressBanorte].[dbo].[ADE_ORDSERENC]  GAE --with (nolock)
        ON GAE.OTE_ORDENANDRADE = O.numerooRDEN COLLATE Modern_Spanish_CS_AS

inner JOIN FacturaCotizacion FC
        ON FC.idCotizacion=C.idCotizacion

--		where GAE.OTE_IDPROVEEDOR is not null
--		  and  FC.numFactura is not null
	UNION ALL	
	SELECT --top 10
       distinct
       C.numeroCotizacion, 
       C.idCotizacion, 
	   GAE.OTE_IDPROVEEDOR,
	   GAE.OTE_ORDENPEMEX,
	   FC.numFactura

      FROM Ordenes O  --with (nolock)
	  
	  INNER join [dbo].[Cotizaciones] C --with (nolock)
	  ON O.[idOrden] = c.[idOrden]

inner JOIN [192.168.20.29].[GAAutoExpress].[dbo].[ADE_ORDSERENC]  GAE --with (nolock)
        ON GAE.OTE_ORDENANDRADE = O.numerooRDEN COLLATE Modern_Spanish_CS_AS

inner JOIN FacturaCotizacion FC
        ON FC.idCotizacion=C.idCotizacion

--		where GAE.OTE_IDPROVEEDOR is not null
--		  and  FC.numFactura is not null

go

