-- =============================================
-- Author:		Miguel Angel Reyes Xinaxtle
-- Create date: 29/10/2018
-- Description:	Obtener los mensajes de los usuarios desasignados por unidad
-- EXEC [Mobile].[Sel_DesasignadosUnidad_Sp] 747, 1
-- =============================================
CREATE PROCEDURE [Mobile].[Sel_DesasignadosUnidad_Sp]
	@idUsuario			int,
	@idUnidad			int
AS
BEGIN

	SELECT 
		id
		,idUsuario
		,idUnidad
		,vin
		,placas
		,noPoliza
		,descripcion
		,desasignado
		,visto
	FROM [ASEPROT].[Mobile].[UsuarioUnidadContratoOperacionDesAsignado] 
	WHERE idUsuario = @idUsuario
		AND idUnidad = @idUnidad
		AND visto = 0

END
go

grant execute, view definition on Mobile.Sel_DesasignadosUnidad_Sp to DevOps
go

