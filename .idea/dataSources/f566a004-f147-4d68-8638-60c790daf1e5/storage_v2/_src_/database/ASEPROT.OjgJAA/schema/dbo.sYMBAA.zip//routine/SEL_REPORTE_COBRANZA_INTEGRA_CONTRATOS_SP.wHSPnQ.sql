-- =============================================
-- Author:		Edwin CRUZ
-- Create date: 2020-02-07
-- Description:	Obtiene la lista de ordenes facturadas pendientes de pago con descuento
-- =============================================
CREATE PROCEDURE [dbo].[SEL_REPORTE_COBRANZA_INTEGRA_CONTRATOS_SP]
	-- Add the parameters for the stored procedure here
AS
BEGIN

  SELECT 
	con.idContrato
	,con.descripcion
  FROM [Partidas].[dbo].[Contrato] con
  INNER JOIN [Partidas].[dbo].Licitacion lic ON lic.idLicitacion = con.idLicitacion
  INNER JOIN ASEPROT.[dbo].[ContratoOperacion] cop ON cop.idContrato = con.idContrato
  INNER JOIN ASEPROT.[dbo].[Operaciones]  ope ON ope.idOperacion = cop.idOperacion
  WHERE
	lic.idClienteFinal = 5
	AND con.idContrato <> 8
	AND con.estatus = 1
	AND lic.estatus = 1
	AND ope.idEstatusOperacion = 1


END
go

