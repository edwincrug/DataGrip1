/*
 Objetivo: Verirficar el estatus de un código en BPro

 Fecha			Autor			Descripción
 31-Jul-2018	José Etmanuel	Se crea el SP 

 [Banorte].[APP_Estatus_CODIGO_BPRO] 
 @codigo = 816765,
 @idOrdenBpro = 'N0023032',
 @RFCAgencia  = 'AUN14022117H9'
*/


CREATE PROCEDURE [Banorte].[APP_Estatus_CODIGO_BPRO] 
 @codigo varchar(max),
 @idOrdenBpro varchar(max),
 @RFCAgencia varchar(max)
AS   
BEGIN
	declare @sobran int = 0,
	   @mensaje varchar(max)= 'Código NO aplicado',
	   @status int = 0,
	   @idCanjeo int = 0,
	   @idPoliza varchar(50)
	   ;

	 IF EXISTS (SELECT TOP 1 * FROM [Banorte].[PromocionesCodigosDet] WHERE  [Codigo]= @codigo AND [IdOrdenBpro] = @idOrdenBpro AND [RFCagencia] = @RFCAgencia AND isnull(BCancelBpro,0) = 0)
	 BEGIN

		SELECT TOP 1 @sobran= ISNULL([NumeroMaximo] - [Aplicadas],0), @idPoliza = [IdPoliza]
		FROM [PromocionesCodigos] AS PC
		INNER JOIN [Banorte].[Promociones] as P on P.id = PC.IdPromocion
		WHERE [Codigo] = @codigo
		AND Aplicadas<NumeroMaximo
		AND P.fechaTermino >= GETDATE()

		SET @mensaje = 'Código válido, APLICADO';
		SET @status = 1;
  
   
	END
 
	Select @status as status, @mensaje as msg,  @sobran as sobran;
END
go

grant execute, view definition on Banorte.APP_Estatus_CODIGO_BPRO to DevOps
go

