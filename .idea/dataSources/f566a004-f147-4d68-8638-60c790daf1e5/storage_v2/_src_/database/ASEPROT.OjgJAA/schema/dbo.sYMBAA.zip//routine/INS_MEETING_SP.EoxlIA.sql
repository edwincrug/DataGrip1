-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INS_MEETING_SP]
	-- Add the parameters for the stored procedure here
	@joinURL nvarchar(200),
	@hostURL nvarchar(MAX),
	@meetingid nvarchar(9),
	@maxParticipants int,
	@uniqueMeetingId nvarchar(9),
	@conferenceCallInfo nvarchar(50),
	@estatus nvarchar(50),
	@asunto  nvarchar(200),	
	@idUsuario					numeric(18,0),
	@jsonUsuariosSelected		nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @idMeeting AS INT

    -- Insert statements for procedure here
	INSERT INTO Meeting(joinURL,hostURL,meetingid,maxParticipants,uniqueMeetingId,conferenceCallInfo,estatus, asunto, fecha, idUsuario)
	values (@joinURL,@hostURL,@meetingid,@maxParticipants,@uniqueMeetingId,@conferenceCallInfo,@estatus, @asunto, GETDATE(), @idUsuario)

	set @idMeeting = @@IDENTITY

	DECLARE @evidencia varchar(500)
	DECLARE @parent AS INT
		
		--CREAMOS TABLA TEMPORAL PARA EL JSON
		CREATE TABLE #JSONEvidencias(
			element_id numeric(18,0),
			secuenceNo numeric(18,0),
			parent_ID numeric(18,0),
			Object_ID numeric(18,0),
			NAME nvarchar(MAX),
			StringValue nvarchar(MAX),
			ValueType nvarchar(MAX)
		)
		--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
		INSERT INTO #JSONEvidencias
		SELECT * FROM parseJSON(@jsonUsuariosSelected)
		--Insertar cotizaciones
		DECLARE _cursor CURSOR FOR 
		SELECT Object_ID FROM #JSONEvidencias
		WHERE 
		Object_ID IS NOT NULL
		AND ValueType = 'object' 
		ORDER BY Object_ID

		OPEN _cursor 
		FETCH NEXT FROM _cursor INTO @parent
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			SELECT @evidencia = REPLACE(StringValue,'"','')  FROM #JSONEvidencias
			WHERE 
				parent_ID = @parent
				AND NAME = 'id'
				AND Object_ID IS NULL
			INSERT INTO MeetingParticipante( idMeeting, idUsuario) values (@idMeeting,@evidencia)
			FETCH NEXT FROM _cursor INTO @parent
		END
		CLOSE _cursor
		DEALLOCATE _cursor
		DROP TABLE #JSONEvidencias

	select @idMeeting 'idMeeting'

END
go

