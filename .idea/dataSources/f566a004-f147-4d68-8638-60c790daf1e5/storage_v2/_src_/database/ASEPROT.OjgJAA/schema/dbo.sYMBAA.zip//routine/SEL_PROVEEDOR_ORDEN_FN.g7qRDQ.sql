-- =============================================
-- Author: YJH
-- Create date: 2019/03/08
-- SELECT [dbo].[SEL_PROVEEDOR_ORDEN_FN](43765)
-- =============================================
-- Add the parameters for the function here
CREATE FUNCTION [dbo].[SEL_PROVEEDOR_ORDEN_FN](@idOrden INT)

RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @nombreComercial NVARCHAR(MAX) = '- ';
	DECLARE @Result NVARCHAR(MAX) = ' ';

	select top 1 @nombreComercial= P.nombreComercial
	from RefaccionMultiMarca.Relacion.UnidadSiniestroOrden USO
	inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = USO.idSiniestro
	inner join RefaccionMultiMarca.Operacion.CotizacionTaller CT on CT.idSiniestro = S.id
	inner join RefaccionMultiMarca.Catalogo.Proveedor P on P.idProveedor = CT.idProveedor
	where USO.orden = @idOrden


	IF((@nombreComercial IS NOT NULL) AND @nombreComercial != '- ')
		SET @Result= @nombreComercial
	else 
	begin 
		select  top 1 @nombreComercial=P.nombreComercial from RefaccionMultiMarca.Relacion.UnidadSiniestroOrden USO
		inner join RefaccionMultiMarca.Operacion.Siniestro S on S.id = USO.idSiniestro
		inner join RefaccionMultiMarca.Operacion.Unidad U on U.id = S.idUnidad
		inner join RefaccionMultiMarca.Catalogo.Marca M on  M.idMarca = U.marca
		inner join RefaccionMultiMarca.Relacion.Configuracion_Sucursal CS on Cs.idMarca = M.idMarca	
		inner join RefaccionMultiMarca.Catalogo.Proveedor P on P.idProveedor = CS.idProveedor
		where USO.orden = @idOrden

		IF((@nombreComercial IS NOT NULL) AND @nombreComercial != '')
			SET @Result= @nombreComercial
	end
	

	RETURN @Result;			
	
END
go

