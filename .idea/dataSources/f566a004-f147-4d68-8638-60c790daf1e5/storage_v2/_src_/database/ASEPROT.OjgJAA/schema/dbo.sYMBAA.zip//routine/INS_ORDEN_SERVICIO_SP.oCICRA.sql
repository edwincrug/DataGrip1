-- =============================================
-- Description:	Inserta una nueva Orden de Servicio  
-- =============================================
/*	
	[dbo].[INS_ORDEN_SERVICIO_SP]	@idUnidad = 2, 
									@idUsuario = 26,
									@idTipoOrdenServicio = 2,
									@idEstadoUnidad = 1,
									@grua = 1,
									@fechaCita = '25/05/2017 00:00:00.000',
									@comentario = 'Prueba de creación de Órdenes de Servicio Adolfo',
									@idZona = 1,
									@taller = 0,
									@especialidades = '4,3,2,' 

   [dbo].[INS_ORDEN_SERVICIO_SP]	@idUnidad = 4, 
									@idUsuario = 23,
									@idTipoOrdenServicio = 3,
									@idEstadoUnidad = 1,
									@grua = 0,
									@fechaCita = '24/06/2017 00:00:00.000',
									@comentario = 'cita 3',
									@idZona = 1,
									@taller = 1,
									@especialidades = '2,'
*/
CREATE PROCEDURE [dbo].[INS_ORDEN_SERVICIO_SP] 
	@idUnidad NUMERIC(18,0), 
	@idUsuario  NUMERIC(18,0),
	@idTipoOrdenServicio NUMERIC(18,0),
	@idEstadoUnidad NUMERIC(18,0),
	@grua INT,
	@fechaCita NVARCHAR(MAX),
	@comentario VARCHAR(500),
	@idZona  NUMERIC(18,0),
	@taller INT,
	@especialidades NVARCHAR(MAX),
	@idCentroTrabajo INT
AS
BEGIN

	--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	--Comprueba que el usuario tiene los permisos necesarios para crear la orden de servicio de la unidad
	--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	IF(EXISTS(	SELECT *
				 FROM [Unidades] UNI with(nolock)
					  INNER JOIN [ContratoOperacion] CP with(nolock) ON UNI.idOperacion = CP.idOperacion
					  INNER JOIN [ContratoOperacionUsuario] COU with(nolock) ON CP.idContratoOperacion = COU.idContratoOperacion AND COU.idUsuario = @idUsuario
				WHERE idUnidad = @idUnidad)
			  )
		BEGIN

			DECLARE @idOperacion NUMERIC(18,0), @numeroEconomico VARCHAR(50), @idContratoOperacion NUMERIC(18,0), @consecutivoOrden INT, @estatusOrden INT
			--Obtengo los datos necesarios de la unidad para formar el numero de la orden para el campo [numeroOrden]
			SELECT @idOperacion = UNI.idOperacion,
				   @numeroEconomico = numeroEconomico,
				   @idContratoOperacion = CP.idContratoOperacion
			  FROM [Unidades] UNI with(nolock)
				   INNER JOIN [ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion
			 WHERE idUnidad = @idUnidad

			--Obtengo el consecutivo para formar el numero de la orden 
			IF (EXISTS(SELECT TOP 1 consecutivoOrden FROM [Ordenes] with(nolock) WHERE idContratoOperacion = @idContratoOperacion))
				BEGIN
					SET @consecutivoOrden = (SELECT TOP 1 consecutivoOrden FROM [Ordenes] WHERE idContratoOperacion = @idContratoOperacion ORDER BY consecutivoOrden DESC) +1
				END
			ELSE 
				BEGIN
					SET @consecutivoOrden = 1
				END

			
			--Si el usuario no selecciono taller el estatus de la orden debe crearce con 1  
			--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			--Si @taller = 0 significa que no se ha seleccionado un taller para la orden de servicio por lo cual el idEstatusOrden debe nacer en 1
			--Si @taller = 1 significa que se selecciono un taller para la orden de servicio por lo cual el idEstatusOrden debe nacer en 2 
			--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			SET @estatusOrden = (CASE WHEN @taller = 0 THEN 1 ELSE 2 END)	
			DECLARE @numeroOrden VARCHAR(50) = (select 
											CASE WHEN @idContratoOperacion<100 THEN 
											ISNULL(RIGHT('00' + CAST(@idContratoOperacion AS varchar(2)), 2),'S/N')  
											ELSE
											ISNULL(RIGHT('00' + CAST(@idContratoOperacion AS varchar(3)), 3),'S/N')  
											END
											+ '-' + ISNULL(convert(varchar(max),@numeroEconomico),'S/N') 
											+ '-' + ISNULL(RIGHT( CAST(@consecutivoOrden AS varchar(6)), 6),'S/N'))
			
			DECLARE @idOrdenServicio INT, @idGrua INT
			IF NOT EXISTS(Select top(1) numeroOrden FROM ORDENES WHERE NUMEROORDEN = @numeroOrden)
			BEGIN
			INSERT INTO [Ordenes] ( [fechaCreacionOden]
											,[fechaCita]
											,[fechaInicioTrabajo]
											,[numeroOrden]
											,[consecutivoOrden]
											,[comentarioOrden]
											,[requiereGrua]
											,[idCatalogoEstadoUnidad]
											,[idZona]
											,[idUnidad]
											,[idContratoOperacion]
											,[idUsuario]
											,[idCatalogoTipoOrdenServicio]
											,[idTipoOrden]
											,[idEstatusOrden]
											,[idCentroTrabajo]
											,[idTaller]
											,[idGarantia]
											,[motivoGarantia])
			SELECT	GETDATE(),
					@fechaCita,
					NULL,
					@numeroOrden,
					@consecutivoOrden,
					@comentario,
					@grua,
					@idEstadoUnidad,
					@idZona,
					@idUnidad,
					@idContratoOperacion,
					@idUsuario,
					@idTipoOrdenServicio,
					1,
					@estatusOrden,
					@idCentroTrabajo,
					@taller,
					0,
					''
			SET @idOrdenServicio = @@IDENTITY
			INSERT INTO [HistorialEstatusOrden] (	[idOrden]
													,[idEstatusOrden]
													,[fechaInicial]
													,[fechaFinal]
													,[idUsuario] )
			VALUES(@idOrdenServicio,@estatusOrden,GETDATE(),NULL,@idUsuario)

			--Especialidades
			print 'Especialidades'
			 DECLARE @idEspecialidad INT,
					 @idEspecialidadOrden INT,
					 @lnuPosComa int

					WHILE  LEN(@especialidades)> 0
						BEGIN
							SET @lnuPosComa = CHARINDEX(',', @especialidades ) 
							IF ( @lnuPosComa!=0 )
							BEGIN
								SET @idEspecialidad = Substring( @especialidades , 1  , @lnuPosComa-1)
								SET @especialidades = Substring( @especialidades , @lnuPosComa + 1 , LEN(@especialidades))
							END
								IF NOT EXISTS (SELECT 1 FROM [EspecialidadOrden] WHERE [idEspecialidad] = @idEspecialidad AND [idOrden] = @idOrdenServicio) 
									BEGIN	
										print 'Especialidades insert'
										INSERT INTO [EspecialidadOrden] (
													 [idEspecialidad]
													,[idOrden]
													,[estatus])
												VALUES(
												 @idEspecialidad
												,@idOrdenServicio
												,1)
									END
						END

				IF @comentario IS NOT NULL
					BEGIN
						INSERT INTO [dbo].[Notas]
							([descripcionNota],[idOrden],[idUsuario],[fechaNota],[idEstatusOrden])
						VALUES (@comentario, @idOrdenServicio, @idUsuario, GETDATE(), @estatusOrden)
					END

			DECLARE @numeroOrdenes INT = 0;
			SELECT @numeroOrdenes = COUNT(idOrden) FROM [Ordenes] with(nolock) WHERE idUnidad = @idUnidad AND idEstatusOrden = @estatusOrden
			PRINT 'Numero de Ordenes Insertadas'
			PRINT @numeroOrdenes 
							SELECT 1 AS respuesta,
								   'La Orden de Servicio se inserto correctamente' AS mensaje,
								   @idOrdenServicio AS idOrden,
								   numeroOrden AS numeroOrden
							FROM   Ordenes with(nolock) WHERE idOrden =	@idOrdenServicio
				END
				SELECT 1 AS respuesta
		END
	ELSE
		BEGIN
			print 'No se tienen los permisos necesarios para agendar una orden de servicio'
		END
END


go

