
CREATE PROCEDURE [dbo].[SEL_RECORDATORIO_MONITOREO_SP] 
	
AS
BEGIN

DECLARE @idRecordatorio NUMERIC(18,0)
DECLARE @texto NVARCHAR(1000)
DECLARE @fecha DATETIME
DECLARE @idEstatus INT
DECLARE @idUsuario INT
DECLARE @idOrden INT
DECLARE @fechaAlta DATETIME
DECLARE @horasRecordatorio INT

/*
	SELECT --TOP 1
		 idRecordatorio,
		 texto,
		 fecha,
		 idEstatus,
		 idUsuario,
		 idOrden,
		 fechaAlta,
		 (SELECT DATEDIFF(HH, fecha, GETDATE()) horasRecordatorio)
	FROM [dbo].[Recordatorio]
	WHERE idEstatus=1

	select * from Usuarios

	UPDATE Recordatorio
	SET idEstatus=1

*/
	SELECT TOP 1
		@idRecordatorio = idRecordatorio,
		@texto = texto,
		@fecha = fecha,
		@idEstatus = idEstatus,
		@idUsuario = idUsuario,
		--@idOrden = idOrden,
		@fechaAlta = fechaAlta,
		@horasRecordatorio = (SELECT DATEDIFF(HH, fecha, GETDATE()) horasRecordatorio)
	FROM [dbo].[Recordatorio]
	WHERE idEstatus=1

	--SELECT @idRecordatorio, @texto, @fecha, @idEstatus, @idUsuario, @idOrden, @fechaAlta, @horasRecordatorio

	IF(@horasRecordatorio = -1)
		BEGIN
			UPDATE [dbo].[Recordatorio]
			SET idEstatus=1
			WHERE idRecordatorio=@idRecordatorio

			--EXEC [SEL_NOTIFICACION_RECORDATORIO_SP] @texto, @fecha, @idUsuario, @fechaAlta
		END
END

go

