-- =============================================
-- Description:	Actualiza la Orden de Servicio 
-- =============================================
/*[dbo].[UPD_ORDEN_DERVICIO_SP] @idOrden = 128,
								@idUnidad = 5, 
								@idUsuario = 22,
								@idTipoOrdenServicio = 2,
								@idEstadoUnidad = 1,
								@grua = 0,
								@fechaCita = '02/05/2017 00:00:00.000',
								@comentario = 'Prueba de creación de Órdenes de Servicio Editada',
								@idZona = 17,
								@taller = 1
*/
CREATE PROCEDURE [dbo].[UPD_ORDEN_DERVICIO_SP]
	@idOrden NUMERIC(18,0), 
	@idUnidad NUMERIC(18,0),
	@idUsuario  NUMERIC(18,0),
	@idTipoOrdenServicio NUMERIC(18,0),
	@idEstadoUnidad NUMERIC(18,0),
	@grua INT,
	@fechaCita NVARCHAR(MAX),
	@comentario VARCHAR(500),
	@idZona  NUMERIC(18,0),
	@taller INT,
	@idCentroTrabajo INT
AS
BEGIN
	DECLARE @tallerOrden INT, @gruaOrden INT
	DECLARE @idHistorialOrdenServicio INT, @estatusOrden INT
	SELECT @tallerOrden = idTaller, @gruaOrden = requiereGrua, @estatusOrden = idEstatusOrden FROM Ordenes WHERE idOrden = @idOrden
	SELECT @tallerOrden
	IF(@gruaOrden = @grua)
		BEGIN
			IF(@tallerOrden = 0 AND @taller != 0)
				BEGIN					
					PRINT 'Cambiare el estatus a 2'
					UPDATE Ordenes
					SET [fechaCita] = @fechaCita
						,[comentarioOrden] = @comentario
						,[requiereGrua] = @grua
						,[idCatalogoEstadoUnidad] = @idEstadoUnidad
						,[idZona] = @idZona
						,[idCatalogoTipoOrdenServicio] = @idTipoOrdenServicio
						,[idEstatusOrden] = 2
						,[idTaller] = @taller
						,[idCentroTrabajo] = @idCentroTrabajo
					WHERE idOrden = @idOrden
					--SELECT * FROM Ordenes WHERE idOrden = @idOrden
					SELECT @idHistorialOrdenServicio = idHistorialEstatusOrden FROM HistorialEstatusOrden WHERE idOrden = @idOrden AND fechaFinal IS NULL
					UPDATE HistorialEstatusOrden
					SET fechaFinal = GETDATE()
					WHERE idHistorialEstatusOrden = @idHistorialOrdenServicio
					INSERT INTO [dbo].[HistorialEstatusOrden] (	[idOrden]
																				,[idEstatusOrden]
																				,[fechaInicial]
																				,[fechaFinal]
																				,[idUsuario] )
					VALUES(@idOrden,2,GETDATE(),NULL,@idUsuario)
					SELECT	1 AS respuesta
							,'Se cambio la Orden de Servicio de Sin taller a Con taller' AS mensaje
				END
			ELSE 
				BEGIN
					PRINT 'Solo cambiare la orden sin cambiar estatus'
					UPDATE Ordenes
					SET [fechaCita] = @fechaCita
						,[comentarioOrden] = @comentario
						,[requiereGrua] = @grua
						,[idCatalogoEstadoUnidad] = @idEstadoUnidad
						,[idZona] = @idZona
						,[idCatalogoTipoOrdenServicio] = @idTipoOrdenServicio
						,[idTaller] = @taller
						,[idCentroTrabajo] = @idCentroTrabajo
					WHERE idOrden = @idOrden
					SELECT	1 AS respuesta
							,'Se actualizo la Orden de Servicio' AS mensaje
				END
			
		END
	ELSE
		BEGIN
			IF(@grua = 0)
				BEGIN
					DECLARE @idOrdenGrua INT
					PRINT 'Tengo que cambiar la orden de grua a cancelada' 
					SELECT @idOrdenGrua = idOrden FROM Ordenes WHERE idUnidad =@idUnidad  AND idEstatusOrden IN (1,2) AND idTipoOrden = 2
					UPDATE Ordenes
					SET idEstatusOrden = 10
					WHERE idUnidad = @idUnidad AND idEstatusOrden IN (1,2) AND idTipoOrden = 2
				END
			ELSE IF(@grua = 1)
				BEGIN
					------------------------------------------------------------------------------------------------------------------
					--Variables para poder insertar la Orden de Servicio Tipo Grua
					------------------------------------------------------------------------------------------------------------------
					DECLARE @idOperacion NUMERIC(18,0), @numeroEconomico VARCHAR(50), @idContratoOperacion NUMERIC(18,0), @consecutivoOrden INT
					--Obtengo los datos necesarios de la unidad para formar el numero de la orden para el campo [numeroOrden]
					SELECT @idOperacion = UNI.idOperacion,
						   @numeroEconomico = numeroEconomico,
						   @idContratoOperacion = CP.idContratoOperacion
					  FROM [dbo].[Unidades] UNI
						   INNER JOIN [dbo].[ContratoOperacion] CP ON UNI.idOperacion = CP.idOperacion
					 WHERE idUnidad = @idUnidad

					--Obtengo el consecutivo para formar el numero de la orden 
					IF (EXISTS(SELECT TOP 1 consecutivoOrden FROM [dbo].[Ordenes] WHERE idContratoOperacion = @idContratoOperacion))
						BEGIN
							SET @consecutivoOrden = (SELECT TOP 1 consecutivoOrden FROM [dbo].[Ordenes] WHERE idContratoOperacion = @idContratoOperacion ORDER BY consecutivoOrden DESC) +1
						END
					ELSE 
						BEGIN
							SET @consecutivoOrden = 1
						END
					------------------------------------------------------------------------------------------------------------------
					------------------------------------------------------------------------------------------------------------------
					INSERT INTO [dbo].[Ordenes] ( [fechaCreacionOden]
															,[fechaCita]
															,[fechaInicioTrabajo]
															,[numeroOrden]
															,[consecutivoOrden]
															,[comentarioOrden]
															,[requiereGrua]
															,[idCatalogoEstadoUnidad]
															,[idZona]
															,[idUnidad]
															,[idContratoOperacion]
															,[idUsuario]
															,[idCatalogoTipoOrdenServicio]
															,[idTipoOrden]
															,[idEstatusOrden]
															,[idCentroTrabajo]
															,[idTaller])
						SELECT	GETDATE(),
								@fechaCita,
								NULL,
								(select ISNULL(RIGHT('00' + CAST(@idOperacion AS varchar(2)), 2),'S/N')  
								+ '-' + ISNULL(convert(varchar(max),@numeroEconomico),'S/N') 
								+ '-' + ISNULL(RIGHT('000000' + CAST(@consecutivoOrden AS varchar(6)), 6),'S/N')),
								@consecutivoOrden,
								@comentario,
								@grua,
								@idEstadoUnidad,
								@idZona,
								@idUnidad,
								@idContratoOperacion,
								@idUsuario,
								@idTipoOrdenServicio,
								2,
								@estatusOrden,
								@idCentroTrabajo,
								@taller
						DECLARE @idGrua INT
						SET @idGrua = @@IDENTITY
						INSERT INTO [dbo].[HistorialEstatusOrden] (	[idOrden]
																				,[idEstatusOrden]
																				,[fechaInicial]
																				,[fechaFinal]
																				,[idUsuario] )
						VALUES(@idGrua,@estatusOrden,GETDATE(),NULL,@idUsuario)
				END
			IF(@tallerOrden = 0 AND @taller != 0)
				BEGIN					
					PRINT 'Cambiare el estatus a 2'
					UPDATE Ordenes
					SET [fechaCita] = @fechaCita
						,[comentarioOrden] = @comentario
						,[requiereGrua] = @grua
						,[idCatalogoEstadoUnidad] = @idEstadoUnidad
						,[idZona] = @idZona
						,[idCatalogoTipoOrdenServicio] = @idTipoOrdenServicio
						,[idEstatusOrden] = 2
						,[idTaller] = @taller
						,[idCentroTrabajo] = @idCentroTrabajo
					WHERE idOrden = @idOrden
					--SELECT * FROM Ordenes WHERE idOrden = @idOrden
					SELECT @idHistorialOrdenServicio = idHistorialEstatusOrden FROM HistorialEstatusOrden WHERE idOrden = @idOrden AND fechaFinal IS NULL
					UPDATE HistorialEstatusOrden
					SET fechaFinal = GETDATE()
					WHERE idHistorialEstatusOrden = @idHistorialOrdenServicio
					INSERT INTO [dbo].[HistorialEstatusOrden] (	[idOrden]
																				,[idEstatusOrden]
																				,[fechaInicial]
																				,[fechaFinal]
																				,[idUsuario] )
					VALUES(@idOrden,2,GETDATE(),NULL,@idUsuario)
					SELECT	1 AS respuesta
							,'Se cambio la Orden de Servicio de Sin taller a Con taller' AS mensaje
				END
			ELSE 
				BEGIN
					PRINT 'Solo cambiare la orden sin cambiar estatus'
					UPDATE Ordenes
					SET [fechaCita] = @fechaCita
						,[comentarioOrden] = @comentario
						,[requiereGrua] = @grua
						,[idCatalogoEstadoUnidad] = @idEstadoUnidad
						,[idZona] = @idZona
						,[idCatalogoTipoOrdenServicio] = @idTipoOrdenServicio
						,[idTaller] = @taller
						,[idCentroTrabajo] = @idCentroTrabajo
					WHERE idOrden = @idOrden
					SELECT	1 AS respuesta
							,'Se actualizo la Orden de Servicio' AS mensaje
				END
			
			
		END 
	
END
go

