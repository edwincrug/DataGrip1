



CREATE proc [Banorte].[APP_GET_CITAS_SERVICIOS]
	@idUnidad int = 0
as
begin

	select * from [dbo].[ServiosAppMiAuto]
/*
declare @ContratoOperacion int,


		@TipoUnidad int;
   -- select idServicio,Servicio from ServiosAppMiAuto
 
	select @ContratoOperacion=co.idContratoOperacion, @TipoUnidad=uni.idTipoUnidad from unidades uni join ContratoOperacion co on co.idOperacion=uni.idOperacion where uni.idUnidad=@idUnidad;
	SELECT Top 50 [idPartida] as idServicio ,[descripcion] as Servicio,[foto] as imagen
	FROM [Partidas]..[Partida] where idUnidad = @TipoUnidad and idEspecialidad = 11;

*/
end


go

grant execute, view definition on Banorte.APP_GET_CITAS_SERVICIOS to DevOps
go

