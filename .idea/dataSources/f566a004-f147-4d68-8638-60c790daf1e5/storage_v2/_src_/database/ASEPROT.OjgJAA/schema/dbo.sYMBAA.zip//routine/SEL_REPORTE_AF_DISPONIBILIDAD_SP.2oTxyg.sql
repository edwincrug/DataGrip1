    
-- =============================================    
-- Author:  <Edgar Mendoza Gomez>    
-- Create date: <12/11/2018>    
-- Description: <SP para ver disponibilidad de unidades>    
-- Test: [dbo].[SEL_REPORTE_AF_DISPONIBILIDAD_SP] 8,'2019-01-01', '2019-12-05'    
-- ============== Versionamiento ================    
/*    
 Fecha   Autor   Descripción    
     
*/    
-- =============================================    
    
CREATE PROCEDURE [dbo].[SEL_REPORTE_AF_DISPONIBILIDAD_SP] 
 @idOperacion INT,    
 @fechaInicio DATE,    
 @fechaFin   DATE    
     
AS    
BEGIN    
 SET NOCOUNT ON;    
    
 SET LANGUAGE SPANISH    
    
 CREATE TABLE #encabezado(    
 idUnidad int ,    
 numeroEconomico nvarchar(100),    
 placas nvarchar(100),    
 tipo nvarchar(100),    
 tipoCombustible nvarchar(200),    
 marca nvarchar(200),    
 subMarca varchar(200),    
 modelo varchar(10),    
 vin nvarchar(100),    
 zona nvarchar(200),    
 dDisponibles int,    
 dTaller int,    
 estatus nvarchar(30),   
 tipoServicio varchar(100) 
    
)    
 INSERT INTO #encabezado    
 SELECT    
  U.idUnidad,    
  U.numeroEconomico,    
  U.placas,    
  TU.tipo,    
  TC.tipoCombustible,    
  M.nombre,    
  SM.nombre,    
  U.modelo,    
  U.vin,    
  Z.nombre ,   
  (DATEDIFF(day, @fechaInicio, @fechaFin) + 1) -(SELECT ISNULL(ABS(sum(hora)/24),0) 
													FROM report.unidades_DiasTaller RUDT    
													WHERE RUDT.idUnidad = U.idUnidad    
													AND CONVERT(date,RUDT.fecha) between @fechaInicio and @fechaFin    
             )  dDisponibles,    
  (SELECT    ISNULL(ABS(sum(hora)/24),0) 
	FROM report.unidades_DiasTaller RUDT    
   WHERE RUDT.idUnidad = U.idUnidad    
   AND CONVERT(date,RUDT.fecha) between @fechaInicio and @fechaFin    
  ),    
    
  CASE WHEN U.idUnidad = (SELECT TOP 1 idUnidad from report.unidades_DiasTaller WHERE (fecha >= convert(date,GETDATE() -1)) and idUnidad = U.idUnidad order by fecha desc) THEN 'NO DISPONIBLE'    
  ELSE 'DISPONIBLE' END,
  (SELECT top 1 nombreTipoOrdenServicio from [CatalogoTiposOrdenServicio]  CTO
		INNER JOIN Ordenes Ord On Ord.idCatalogoTipoOrdenServicio = CTO.idCatalogoTipoOrdenServicio
		LEFT JOIN [HistorialEstatusOrden] hisI ON hisI.idOrden = ord.idOrden and hisI.idEstatusOrden = 3   
		LEFT JOIN [HistorialEstatusOrden] hisF ON hisF.idOrden = ord.idOrden and hisF.idEstatusOrden = 6   
	WHERE Ord.idUnidad = U.idUnidad
	AND (((hisI.fechaInicial between @fechaInicio and @fechaFin)  
	AND (hisF.fechaInicial >= @fechaFin OR hisF.fechaInicial IS NULL))     
	OR (hisI.fechaInicial < @fechaInicio and ( hisF.fechaInicial  between @fechaInicio and @fechaFin) )   
	OR (hisI.fechaInicial >= @fechaInicio and hisF.fechaInicial <= @fechaFin)     
	OR (hisI.fechaInicial < @fechaInicio and ISNULL(hisF.fechaInicial,GETDATE()) > @fechaFin)    )           
	order by Ord.idOrden desc)  
      
 FROM Unidades U    
  INNER JOIN Partidas..Unidad PU ON PU.idUnidad = U.idTipoUnidad    
  INNER JOIN Partidas..TipoUnidad TU ON TU.idTipoUnidad = PU.idTipoUnidad    
  INNER JOIN Partidas..TipoCombustible TC ON TC.idTipoCombustible = PU.idTipoCombustible    
  INNER JOIN Partidas..SubMarca SM ON SM.idSubMarca = PU.idSubMarca    
  INNER JOIN Partidas..Marca M ON M.idMarca = SM.idMarca    
  INNER JOIN Partidas..Zona Z ON Z.idZona = U.idZona    
 WHERE U.idOperacion= @idOperacion    
    
  CREATE TABLE #detalle(    
   idUnidad int,    
   numeroOrden varchar(50),    
   dias int,    
   consecutivo int,    
   tipo varchar(50),    
   fechaCita varchar(50),    
   comentarios varchar(2000),    
   idEstatus int,    
   nombreEstatus varchar(50),    
   idOrden int,
   fechaSolicitud		varchar(50),
   fechaAsignacion		varchar(50),
   fechaTaller			varchar(50),
   fechaAprobacion		varchar(50),
   fechaEntrega			varchar(50)
    
  )    
    
  INSERT INTO #detalle    
  SELECT     
   U.idUnidad,    
   O.numeroOrden,    
      CASE       
	  WHEN (hisI.fechaInicial between @fechaInicio and @fechaFin)  and ( hisF.fechaInicial >= @fechaFin OR hisF.fechaInicial IS NULL) THEN DATEDIFF(day, hisI.fechaInicial, @fechaFin) + 1  
	  WHEN (hisI.fechaInicial < @fechaInicio and ( hisF.fechaInicial  between @fechaInicio and @fechaFin)) THEN DATEDIFF(day, @fechaInicio, hisF.fechaInicial) + 1
	  WHEN  (hisI.fechaInicial >= @fechaInicio and hisF.fechaInicial <= @fechaFin) THEN DATEDIFF(day, hisI.fechaInicial, hisF.fechaInicial) + 1
	  WHEN ( hisI.fechaInicial < @fechaInicio and ISNULL(hisF.fechaInicial,GETDATE()) > @fechaFin) THEN DATEDIFF(day, @fechaInicio, @fechaFin)   + 1    
	  END as enTaller,    
    
   O.consecutivoOrden,     
   CTO.nombreTipoOrdenServicio AS nombreTipoOrdenServicio,    
   O.fechaCita,     
   O.comentarioOrden,    
   O.idEstatusOrden,    
   EO.nombreEstatusOrden,    
   O.idOrden ,
   CONVERT(VARCHAR,O.fechaCreacionOden,103) + ' '  + convert(VARCHAR(8), O.fechaCreacionOden, 14),
   CONVERT(VARCHAR,(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 2),103) + ' '  + convert(VARCHAR(8), (SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 2), 14) AS fechaNuevaTaller, 
	CONVERT(VARCHAR,(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3),103) + ' '  + convert(VARCHAR(8), (SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 3), 14) AS fechaEntrada, 
	CONVERT(VARCHAR,(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 5),103) + ' '  + convert(VARCHAR(8), (SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 5), 14) AS fechaProceso,  
	CONVERT(VARCHAR,(SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 6),103) + ' '  + convert(VARCHAR(8), (SELECT TOP 1  fechaInicial FROM HistorialEstatusOrden WHERE idOrden = O.idOrden  and idEstatusOrden = 6), 14) AS fechaEntrega  
  FROM Unidades U    
  INNER JOIN #encabezado E ON E.idUnidad = U.idUnidad     
  INNER JOIN Ordenes O ON E.idUnidad = O.idUnidad    
  INNER JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden    
  LEFT JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio    
    
  LEFT JOIN [HistorialEstatusOrden] hisI ON hisI.idOrden = o.idOrden and hisI.idEstatusOrden = 3   
  LEFT JOIN [HistorialEstatusOrden] hisF ON hisF.idOrden = o.idOrden and hisF.idEstatusOrden = 6    
    
  WHERE         ( ((hisI.fechaInicial between @fechaInicio and @fechaFin)  and (hisF.fechaInicial >= @fechaFin 
  OR hisF.fechaInicial IS NULL))     or (hisI.fechaInicial < @fechaInicio and ( hisF.fechaInicial  between @fechaInicio and @fechaFin) )   
   
 or (hisI.fechaInicial >= @fechaInicio and hisF.fechaInicial <= @fechaFin)     or (hisI.fechaInicial < @fechaInicio and ISNULL(hisF.fechaInicial,GETDATE()) > @fechaFin)    )           
       
    
    
  select distinct *,'' as detalle, '' as rango from #encabezado order by dTaller desc    
  select distinct * from #detalle order by idUnidad    
  select DATEDIFF(day, @fechaInicio, @fechaFin) + 1 as rango;  
    
  drop table #encabezado    
  drop table #detalle     
END

go

