-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [SEL_ATRIBUTO_FN]
(
	-- Add the parameters for the function here
	@atributos nvarchar(max),
	@atributo nvarchar(100)
)
RETURNS nvarchar(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @valor nvarchar(100) = ''

	DECLARE @JSON AS TABLE(
		element_id numeric(18,0),
		secuenceNo numeric(18,0),
		parent_ID numeric(18,0),
		Object_ID numeric(18,0),
		NAME nvarchar(MAX),
		StringValue nvarchar(MAX),
		ValueType nvarchar(MAX)
	)

	IF(@atributos IS NOT NULL)
	BEGIN
	------------------SE AGREGAN LAS UNIDADES DE LA SOLICITUD----------------
		INSERT INTO @JSON
		SELECT * FROM dbo.parseJSON(@atributos)


		SELECT TOP 1 @valor = REPLACE(StringValue,'"','') FROM @JSON
		WHERE NAME = @atributo --AND Object_ID IS NOT NULL
	END
	ELSE
	BEGIN
		SET @valor = ''
	END
	-- Return the result of the function
	RETURN @valor

END



go

