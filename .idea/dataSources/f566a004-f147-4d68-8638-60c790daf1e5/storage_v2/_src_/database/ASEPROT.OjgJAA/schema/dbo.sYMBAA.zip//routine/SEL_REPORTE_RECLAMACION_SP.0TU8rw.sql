-- =============================================
-- Create date: 23/08/2017
-- Description:	Obtiene todas las formas de pago
-- [SEL_REPORTE_RECLAMACION_SP] null,3,1
-- =============================================
 CREATE PROCEDURE [dbo].[SEL_REPORTE_RECLAMACION_SP]
    @idZona INT = NULL,
	@anexo INT = NULL,
	@idContratoOperacion INT = NULL
AS
BEGIN
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- INFORMACION DE TRABAJOS CON CERTIFICADO GENERADO Y SIN CARGA DE CERTIFICADO POR CLIENTE HASTA EL MOMENTO CON DIFERIENCIA DE DIAS --
-- Anexo 1 - Reportes de conformidad generados por callcenter sin firma del cliente	
	IF(@anexo = 1)
	BEGIN
	SELECT * FROM(
		SELECT *, DATEDIFF (dd, fechaMaxFirma, GETDATE())  as DiasAtraso  FROM (
				SELECT 
					O.consecutivoOrden Consecutivo,
					CLI.nombreComercial as Cliente,
					O.numeroOrden NoOrden,
					O.idEstatusOrden,
					O.idOrden,
					U.numeroEconomico NoEconomico, 
					Z.nombre Zona,
					Z.idZona idZona,
					1 AS idAnexo,
					OPE.idOperacion,
					CO.idContratoOperacion,
					O.numeroOrden folioCertificado,
					--ISNULL('RC-GLR' + SUBSTRING(Z.zona, 1, 1) + '-' + TAR.numTAR + '-' + RIGHT('0000' + CONVERT(VARCHAR(4), CZ.numeroConsecutivo),4) + '-' + CONVERT(varchar(10), YEAR(OS.fechaFinal)), 'Sin Folio') folioCertificado,
					PO.fechaAlta FechaGeneracionCertificado,
					(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idEstatusOrden=8 AND idOrden=O.idOrden) fechaCargaCertificadoCliente,
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes]	ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3))AS precioOrden,
						DATEADD (dd, 4, PO.fechaAlta) as fechaMaxFirma	
				FROM Ordenes O 
					JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
					JOIN Unidades U ON U.idUnidad = O.idUnidad
					JOIN Partidas..Zona Z ON Z.idZona = O.idZona
					JOIN ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
					JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
					JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
					JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
					JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
					JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden 
					LEFT JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto)ANEXO1
					WHERE 
							idZona = COALESCE(@idZona, idZona) 
					 AND idContratoOperacion = @idContratoOperacion
					 AND idEstatusOrden IN (7))W
			WHERE DiasAtraso > 3
			ORDER BY DiasAtraso DESC
	END 
 --//////////////////////////////////////////////////////////////////////////////////////////////--
-- INFORMACION DE TRABAJOS CON CERTIFICADO GENERADO Y CARGA DE CERTIFICADO PERO SIN COPADE DE CLIENTE CON DIFERIENCIA DE DIAS --
-- Anexo 2 - Reportes de conformidad firmados sin COPADE
	IF(@anexo = 2)
	BEGIN
	SELECT * FROM(
		SELECT *, DATEDIFF (dd, fechaMaxFirma, GETDATE())  as DiasAtraso FROM (
				SELECT 
					O.consecutivoOrden Consecutivo,
					CLI.nombreComercial as Cliente,
					O.numeroOrden NoOrden,
					O.idEstatusOrden,
					O.idOrden,
					U.numeroEconomico NoEconomico, 
					Z.nombre Zona,
					Z.idZona idZona,
					1 AS idAnexo,
					OPE.idOperacion,
					CO.idContratoOperacion,
					--DC.numeroCopade AS Copade,
					O.numeroOrden folioCertificado,
					--ISNULL('RC-GLR' + SUBSTRING(Z.zona, 1, 1) + '-' + TAR.numTAR + '-' + RIGHT('0000' + CONVERT(VARCHAR(4), CZ.numeroConsecutivo),4) + '-' + CONVERT(varchar(10), YEAR(OS.fechaFinal)), 'Sin Folio') folioCertificado,
					PO.fechaAlta FechaGeneracionCertificado,
					(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idEstatusOrden=8 AND idOrden=O.idOrden) fechaCargaCertificadoCliente,
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes]	ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3))AS precioOrden,
						DATEADD (dd, 10, PO.fechaAlta) as fechaMaxFirma	
				FROM Ordenes O 
					JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
					JOIN Unidades U ON U.idUnidad = O.idUnidad
					JOIN Partidas..Zona Z ON Z.idZona = O.idZona
					JOIN ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
					JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
					JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
					JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
					JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
					JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden 
					LEFT JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto)ANEXO2
				/*FROM Trabajo T 
					JOIN Estatus E ON E.idEstatus = T.idEstatus
						LEFT JOIN DatosCopadeOrden DCO ON DCO.idTrabajo = T.idTrabajo
						LEFT JOIN DatosCopade DC ON DC.idDatosCopade = DCO.idDatosCopade 
					JOIN Cita CT ON CT.idCita = T.idCita
					JOIN Unidad U ON U.idUnidad = CT.idUnidad
					JOIN Tar TAR ON TAR.idTar = U.idTAR
					JOIN Taller TA ON TA.idTaller = CT.idTaller
					JOIN Zona Z on Z.idZona = TAR.idZona
					JOIN ConsecutivoZona CZ ON CZ.idTrabajo = T.idTrabajo 
					LEFT JOIN Osur OS ON OS.idOsur = CZ.idOsur*/
					WHERE
					        --Copade IS NULL AND 
							idZona = COALESCE(@idZona, idZona) 
					AND idContratoOperacion = @idContratoOperacion
					AND idEstatusOrden=8 
					)W
			WHERE DiasAtraso > 3
			ORDER BY DiasAtraso DESC
	END
	--//////////////////////////////////////////////////////////////////////////////////////////////--
-- INFORMACION DE TRABAJOS QUE NO TIENEN OSUR CON DIFERIENCIA DE DIAS --
-- Anexo 3 - Reportes de conformidad no generado por falta de OSUR
/*
SELECT * FROM Osur
SELECT * from TerminoOsur 
SELECT * from ConsecutivoZona 
*/
	IF(@anexo = 3)
	BEGIN
	SELECT * FROM(
		SELECT *, DATEDIFF (dd, fechaMaxFirma, fechaCargaCertificadoCliente)  as DiasAtraso FROM (
				SELECT 
					O.consecutivoOrden Consecutivo,
					CLI.nombreComercial as Cliente,
					O.numeroOrden NoOrden,
					O.idEstatusOrden,
					O.idOrden,
					U.numeroEconomico NoEconomico, 
					Z.nombre Zona,
					Z.idZona idZona,
					3 AS idAnexo,
					OPE.idOperacion,
					CO.idContratoOperacion,
					O.numeroOrden folioCertificado,
					--ISNULL('RC-GLR' + SUBSTRING(Z.zona, 1, 1) + '-' + TAR.numTAR + '-' + RIGHT('0000' + CONVERT(VARCHAR(4), CZ.numeroConsecutivo),4) + '-' + CONVERT(varchar(10), YEAR(OS.fechaFinal)), 'Sin Folio') folioCertificado,
					--TRO.fecha FechaGeneracionCertificado,
					PO.fechaAlta FechaGeneracionCertificado,
					(SELECT TOP 1 fechaInicial FROM HistorialEstatusOrden WHERE idEstatusOrden=8 AND idOrden=O.idOrden) fechaCargaCertificadoCliente,
					--(SELECT fecha FROM Osur WHERE estatus=1 AND idTAR = TAR.idTar AND orden = (SELECT TOP 1 orden + 1 FROM TerminoOsur T JOIN Osur O ON O.idOsur = T.idOsur WHERE T.idTAR = TAR.idTar AND T.idOsur=O.idOsur))fechaCargaCertificadoCliente,
					--(SELECT idOsur FROM Osur WHERE estatus=1 AND idTAR = TAR.idTar AND orden = (SELECT TOP 1 orden + 1 FROM TerminoOsur T JOIN Osur O ON O.idOsur = T.idOsur WHERE T.idTAR = TAR.idTar AND T.idOsur=O.idOsur)) idOsur,
					(SELECT ISNULL(SUM((ISNULL(CD.venta,0) * ISNULL(CD.cantidad,0))),0) 
						FROM [dbo].[Cotizaciones] C 
						INNER JOIN [dbo].[CotizacionDetalle] CD ON C.idCotizacion = CD.idCotizacion  
						INNER JOIN [dbo].[Ordenes]	ORD ON C.idOrden = ORD.idOrden
						INNER JOIN [dbo].[ContratoOperacion] CO ON ORD.idContratoOperacion = CO.idContratoOperacion
					WHERE ORD.idOrden = O.idOrden 
					AND CO.idContratoOperacion = @idContratoOperacion
					AND CD.idEstatusPartida IN(2) 
					AND C.idEstatusCotizacion IN(3))AS precioOrden,
						--DATEADD (dd, 1, TRO.fecha) as fechaMaxFirma	
					DATEADD (dd, 1, PO.fechaAlta) as fechaMaxFirma	
			FROM Ordenes O 
					JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
					JOIN Unidades U ON U.idUnidad = O.idUnidad
					JOIN Partidas..Zona Z ON Z.idZona = O.idZona
					JOIN ContratoOperacion CO on CO.idContratoOperacion = O.idContratoOperacion
					JOIN Operaciones OPE on OPE.idOperacion = CO.idOperacion
					JOIN Partidas..Contrato C on C.idContrato = CO.idContrato
					JOIN Partidas..Licitacion L on L.idLicitacion = C.idLicitacion
					JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
					JOIN PresupuestoOrden PO ON PO.idOrden = O.idOrden 
					LEFT JOIN Presupuestos P ON P.idPresupuesto = PO.idPresupuesto)ANEXO3
				/*FROM TerminoOsur TRO
				    JOIN Trabajo T ON T.idTrabajo = TRO.idTrabajo
					JOIN Estatus E ON E.idEstatus = T.idEstatus
					JOIN Cita CT ON CT.idCita = T.idCita
					JOIN Unidad U ON U.idUnidad = CT.idUnidad
					JOIN Tar TAR ON TAR.idTar = U.idTAR
					JOIN Taller TA ON TA.idTaller = CT.idTaller
					JOIN Zona Z on Z.idZona = TAR.idZona
					LEFT JOIN ConsecutivoZona CZ ON CZ.idTrabajo = T.idTrabajo 
					LEFT JOIN Osur OS ON OS.idOsur = CZ.idOsur)ANEXO3*/
					WHERE 
						    idZona = COALESCE(@idZona, idZona)
						AND idContratoOperacion = @idContratoOperacion
							--AND fechaCargaCertificadoCliente IS NOT NULL
							--AND idOsur NOT IN (SELECT idOsur FROM anexo3)
						)W
			WHERE DiasAtraso > 1
			ORDER BY DiasAtraso DESC
	END

END
go

