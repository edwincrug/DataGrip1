
/*
	Fecha			Autor			Descripción
	28-Jun-2018		José Etmanuel	Se crea el SP que regresa los de preguntas
	
*/

CREATE PROCEDURE [Banorte].[GET_PREGUNTAS]
	@idPreguntaFrecuente INT
AS
BEGIN
	SELECT * 
	FROM [Banorte].[Preguntas]
	WHERE [TipoPreguntasId] = @idPreguntaFrecuente
END


go

grant execute, view definition on Banorte.GET_PREGUNTAS to DevOps
go

