--   [SEL_TOTAL_ORDENES_SERVICIO_SP] @fechaInicial='2017/05/21',@fechaFin = '2017/06/28',@idContratoOperacion = 2,@idZona = 1,@tipoConsulta = 2
--  [SEL_TOTAL_ORDENES_SERVICIO_SP]@tipoConsulta = 1
CREATE PROCEDURE [dbo].[SEL_CONSULTA_ORDENES_SP_Pruebas]
@idContratoOperacion INT,
@idZona NUMERIC(18,0) = NULL,
@idEjecutivo NUMERIC(18,0) = NULL,
@fechaMes NUMERIC(18,0) = NULL,
@fechaInicial VARCHAR(MAX) = NULL, 
@fechaFin VARCHAR(MAX) = NULL,
@fechaEspecifico varchar(MAX) = NULL,
@NumOrden varchar(50) = null,
@porOrden bit, 
@tipoConsulta INT
AS
BEGIN
print @fechaFin
	IF @tipoConsulta = 1
	BEGIN
				SELECT 
					  Orden.[idOrden]
					  ,[numeroOrden]
					  ,[fechaCita] as fecha
					  ,convert(datetime, fechaCreacionOden, 103) as fechaCreacionOden
					  ,fechaInicioTrabajo
					  ,Histo.fechaInicial AS fechaEstatusActual
					  ,comentarioOrden
					  ,Uni.[numeroEconomico]
					  ,[requiereGrua]
					  ,EstadoUni.[idCatalogoEstadoUnidad]
					  ,EstadoUni.descripcionEstadoUnidad
					  ,zona.[idZona]
					  ,zona.nombre
					  ,Uni.[idUnidad]
					  ,(SELECT [dbo].[SEL_NOMBRE_CLIENTE](@idContratoOperacion)) AS nombreCliente
					  ,[consecutivoOrden]
					  ,EtsOrden.[idEstatusOrden]
					  ,EtsOrden.[nombreEstatusOrden]
					  ,ConOpe.[idContratoOperacion]
					  ,Usu.[idUsuario]
					  ,Usu.nombreUsuario
					  ,CaTiOrSe.[idCatalogoTipoOrdenServicio]
					  ,CaTiOrSe.[nombreTipoOrdenServicio]
					  ,CaTiOr.[idTipoOrden]
					  ,CaTiOr.nombreTipoORden 
			FROM [dbo].[Ordenes] Orden
						INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad
						INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad
						INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND 
						INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion
						INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario
						INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio
						INNER JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona
						INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden
						INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden
			WHERE		Orden.idEstatusOrden IN (1,2)
						AND Orden.idContratoOperacion = @idContratoOperacion
						AND ((@fechaInicial = '')OR(Histo.fechaInicial BETWEEN CONVERT (VARCHAR,@fechaInicial,103) AND  CONVERT (VARCHAR,@fechaFin,103)))
						AND ((@idZona = 0)OR(Orden.idZona = @idZona))
						--AND ((@fechaEspecifico = '')OR(Histo.fechaInicial = CONVERT(VARCHAR,@fechaEspecifico,103)))

	END
ELSE
	BEGIN
		IF @tipoConsulta = 2
			BEGIN
			DECLARE @select NVARCHAR(MAX) = '',
			@condiciones NVARCHAR(MAX) = ''
			print 'Aprobaciones'
					SET @select = 
					'SELECT
						  Orden.[idOrden] AS idOrden
						  ,Coti.idCotizacion
						  ,(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+convert(varchar(max),@idContratoOperacion)+')) AS nombreCliente 
						  ,[consecutivoOrden] AS consecutivoOrden
						  ,[numeroOrden] AS numeroOrden
						  ,Uni.[numeroEconomico] AS numeroEconomico
						  ,zona.[idZona] AS idZona
						  ,zona.nombre AS nombreZona
						  ,'''' AS nombreTaller
						  ,CaTiOr.[idTipoOrden] AS idTipoOrden
						  ,CaTiOr.nombreTipoORden AS nombreTipoOrden
						  ,Coti.numeroCotizacion AS numeroAprobacion
						  ,''FORD'' AS marcaUnidad
						  ,''F-150'' AS modeloUnidad
						  ,Coti.[idEstatusCotizacion] 
						  ,EtsCoti.[nombreEstatusCotizacion]
						  ,Usu.[idUsuario] AS idUsuario
						  ,Usu.[nombreCompleto]
						  ,(SELECT [dbo].[SEL_ESTADISTICA_APROBACION_FT](Orden.idOrden)) AS estadistica 
						  ,(SELECT [dbo].[SEL_PORCENTAJE_APROBACION_FT](Orden.idOrden)) AS porcentaje 
						  ,Ope.presupuesto
						  ,[fechaCita] as fechaCita
						  ,convert(datetime, fechaCreacionOden, 103) as fechaCreacionOden 
						  ,fechaInicioTrabajo AS fechaInicioTrabajo
						  ,Histo.fechaInicial AS fechaEstatusActual
						  ,comentarioOrden AS comentarioOrden
						  ,[requiereGrua] AS requiereGrua
						  ,EstadoUni.descripcionEstadoUnidad AS descripcionEstadoUnidad						  
						  ,Uni.[idUnidad] AS idUnidad						  
						  ,EtsOrden.[idEstatusOrden] AS idEstatusOrden
						  ,EtsOrden.[nombreEstatusOrden] AS nombreEstatusOrden
						  ,ConOpe.[idContratoOperacion] AS idContratoOperacion						  
						  ,CaTiOrSe.[idCatalogoTipoOrdenServicio] AS idCatalogoTipoOrdenServicio
						  ,CaTiOrSe.[nombreTipoOrdenServicio] AS nombreTipoOrdenServicio
					FROM [dbo].[Ordenes] Orden
						INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad
						INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad
						INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND 						
						INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion
						INNER JOIN [dbo].[Operaciones] Ope ON ConOpe.idOperacion = Ope.idOperacion
						INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario
						INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio
						INNER JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona
						INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden
						INNER JOIN [ASEPROT].[dbo].[Cotizaciones] Coti ON Orden.idOrden = Coti.idOrden
						INNER JOIN [dbo].[EstatusCotizaciones] as EtsCoti ON EtsCoti.idEstatusCotizacion = Coti.idEstatusCotizacion
						INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden
					WHERE Orden.idEstatusOrden  = 4 AND (Coti.idEstatusCotizacion = 1 OR Coti.idEstatusCotizacion = 2)
						AND Orden.idContratoOperacion = ' + convert(varchar(max),@idContratoOperacion)


						IF (@porOrden = 1 and (@numorden is not null))
						BEGIN
							SET @condiciones = ' AND Orden.numeroOrden like ''%' + @numorden + '%'''
						END

						ELSE IF (@porOrden = 0)
						BEGIN
							IF (@idzona is not null and @idZona != 0)
							BEGIN
								SET @condiciones = @condiciones + ' AND Orden.idZona = ' + convert(varchar(max),@idzona)
							END
						END

						DECLARE @query NVARCHAR(MAX) = @select + @condiciones
						PRINT @query
						EXECUTE SP_EXECUTESQL @query

						--AND ((@fechaInicial = '')OR(Histo.fechaInicial BETWEEN CONVERT (VARCHAR,@fechaInicial,103) AND  CONVERT (VARCHAR,@fechaFin,103)))
						--AND ((@idZona = 0)OR(Orden.idZona = @idZona))
						--AND ((@fechaEspecifico = '')OR(Histo.fechaInicial = CONVERT(VARCHAR,@fechaEspecifico,103)))
			END
		ELSE
			BEGIN
			print 'ordenes de servicio'
				SELECT 
				  Orden.[idOrden] AS idOrden
						  ,[numeroOrden] AS numeroOrden
						  ,[fechaCita] as fechaCita
						  ,convert(datetime, fechaCreacionOden, 103) as fechaCreacionOden 
						  ,fechaInicioTrabajo AS fechaInicioTrabajo
						  ,Histo.fechaInicial AS fechaEstatusActual
						  ,comentarioOrden AS comentarioOrden
						  ,Uni.[numeroEconomico] AS numeroEconomico
						  ,[consecutivoOrden] AS consecutivoOrden
						  ,[requiereGrua] AS requiereGrua
						  ,EstadoUni.descripcionEstadoUnidad AS descripcionEstadoUnidad
						  ,zona.[idZona] AS idZona
						  ,zona.nombre AS nombreZona
						  ,Uni.[idUnidad] AS idUnidad
						  ,(SELECT [dbo].[SEL_NOMBRE_CLIENTE](@idContratoOperacion)) AS nombreCliente 
						  ,EtsOrden.[idEstatusOrden] AS idEstatusOrden
						  ,EtsOrden.[nombreEstatusOrden] AS nombreEstatusOrden
						  ,ConOpe.[idContratoOperacion] AS idContratoOperacion
						  ,Usu.[idUsuario] AS idUsuario
						  ,Usu.nombreUsuario AS nombreUsuario
						  ,CaTiOrSe.[idCatalogoTipoOrdenServicio] AS idCatalogoTipoOrdenServicio
						  ,CaTiOrSe.[nombreTipoOrdenServicio] AS nombreTipoOrdenServicio
						  ,CaTiOr.[idTipoOrden] AS idTipoOrden
						  ,CaTiOr.nombreTipoORden AS nombreTipoORden
						  ,'FORD' AS marcaUnidad
						  ,'F-150' AS modeloUnidad
						  ,'' AS nombreTaller 
					FROM [dbo].[Ordenes] Orden
						INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad
						INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad
						INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND 
						INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion
						INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario
						INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio
						INNER JOIN [Partidas].[dbo].[Zona] zona ON Orden.idZona = zona.idZona
						INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden
						INNER JOIN [DBO].[HistorialEstatusOrden] Histo ON Histo.idOrden = Orden.idOrden AND Histo.fechaFinal is null AND Orden.idEstatusOrden = Histo.idEstatusOrden
					WHERE histo.idEstatusOrden  in (5,6,7)
						AND Orden.idContratoOperacion = @idContratoOperacion
						AND ((@fechaInicial = '')OR(Histo.fechaInicial BETWEEN CONVERT (VARCHAR,@fechaInicial,103) AND  CONVERT (VARCHAR,@fechaFin,103)))
					   AND ((@idZona = 0)OR(Orden.idZona = @idZona))
			END
	END
END
go

