-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 11-03-2019
-- Description: Actualiza el siniestro 
-- Banorte.UPD_ORDENSINIESTRO @numeroReclamoAnterior = '', @numeroReclamoNuevo = ''
-- =============================================
CREATE PROCEDURE [Banorte].[UPD_ORDENSINIESTRO]
	@numeroReclamoAnterior VARCHAR(30),
	@numeroReclamoNuevo VARCHAR(30)
AS
BEGIN

SET NOCOUNT ON;
	BEGIN TRY
		BEGIN TRAN TrnSiniestroUpd

		UPDATE OrdenSiniestro
		SET idSiniestro = @numeroReclamoNuevo
		WHERE idSiniestro = @numeroReclamoAnterior

		COMMIT TRAN TrnSiniestroUpd

		SELECT 1 AS Number

	END TRY
	BEGIN CATCH
		ROLLBACK TRAN TrnSiniestroUpd
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.UPD_ORDENSINIESTRO to DevOps
go

