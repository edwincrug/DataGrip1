
-- ==========================================================================================
-- Author:	    Jordan Gómez Domínguez
-- Create date: 26/09/2018
-- Description:	Store que obtiene las órdenes pendientes por cobrar
-- [SEL_COTIZACION_FT_FFEC_SP] 538, 14, 1
-- ==========================================================================================

CREATE PROC [dbo].[SEL_COTIZACION_FT_FFEC_SP]
@idUsuario numeric(18,0),
@idContratoOperacion numeric(18,0),
@idDatosFactura numeric(18,0) = null

AS
BEGIN
	
	DECLARE @idOperacion int = (SELECT idContratoOperacion FROM ContratoOperacion WHERE idContratoOperacion = @idContratoOperacion)
    DECLARE @rolUsuario int = [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion)
	DECLARE @Query nvarchar(MAX) = ''

	set @Query = 'SELECT DISTINCT * FROM '
	+ '( '
	+ 'SELECT '
	+ '(SELECT [dbo].[SEL_NOMBRE_CLIENTE](O.idContratoOperacion)) AS Cliente, '
	+ 'DFF.Folio, '
	+ 'DFF.SubTotal, '
	+ 'DFF.Total, '
	+ 'DFF.FechaCarga, '
	+ 'DFF.FechaFactura, '
	+ 'O.numeroOrden as NumeroOrden, '
	+ 'EO.nombreEstatusOrden EstatusOrden, '
	+ '(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3, '+ CONVERT(varchar(30),@idUsuario)+', '+CONVERT(varchar(30),@rolUsuario)+')) AS VentaOrden, '
	+ '(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 3, '+ CONVERT(varchar(30),@idUsuario)+', '+CONVERT(varchar(30),@rolUsuario)+')) AS CostoOrden, '
	+ 'C.numeroCotizacion as NumeroCotizacion, '
	+ '(SELECT [dbo].[SEL_PRECIO_VENTA_COT_FN](C.idCotizacion, O.idContratoOperacion, 3, '+ CONVERT(varchar(30),@idUsuario)+', '+CONVERT(varchar(30),@rolUsuario)+')) AS VentaCotizacion, '
	+ '(SELECT [dbo].[SEL_PRECIO_COSTO_COT_FN](C.idCotizacion, O.idContratoOperacion, 3, '+ CONVERT(varchar(30),@idUsuario)+', '+CONVERT(varchar(30),@rolUsuario)+')) AS CostoCotizacion, '
	+ 'PP.razonSocial Taller '
	+ 'FROM DatosFacturaFec DFF '
	+ 'INNER JOIN DatosFacturaFecCotizacion DFFC ON DFF.IdDatosFacturaFec = DFFC.IdDatosFacturaFec '
	+ 'INNER JOIN Cotizaciones C ON C.idCotizacion = DFFC.idCotizacion '
	+ 'INNER JOIN Ordenes O ON O.idOrden = C.IdOrden '
	+ 'INNER JOIN EstatusOrdenes EO ON O.idEstatusOrden = EO.idEstatusOrden '
	+ 'INNER JOIN Partidas..Proveedor PP ON C.idTaller = PP.idProveedor '
	+ 'WHERE DFF.IdContratoOperacion = ' + CONVERT(varchar(30),@idContratoOperacion) 

	IF(@idDatosFactura IS NOT NULL)
		BEGIN
			set @Query += ' AND DFF.IdDatosFacturaFec = ' + CONVERT(varchar(30),@idDatosFactura) 
		END
	set @Query +=  ') '
	+ 'AS OrdenFtFacturaFec '

	exec(@Query)
	
END
go

