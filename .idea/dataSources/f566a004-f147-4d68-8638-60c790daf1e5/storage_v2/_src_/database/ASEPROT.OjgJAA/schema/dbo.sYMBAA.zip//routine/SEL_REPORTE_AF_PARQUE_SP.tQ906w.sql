
--[SEL_REPORTE_AF_PARQUE_SP] 3
CREATE PROCEDURE [dbo].[SEL_REPORTE_AF_PARQUE_SP]
   @idContratoOperacion numeric(18,0)
AS
BEGIN
	
		declare @idCliente numeric(18,0)

		select 
			@idCliente = L.idCliente
		from ContratoOperacion CO
		inner join Partidas.dbo.Contrato C on CO.idContrato = C.idContrato
		inner join Partidas.dbo.Licitacion L on C.idLicitacion = L.idLicitacion
		where CO.idContratoOperacion = @idContratoOperacion

		print @idCliente


		Select 
			uni.idUnidad
			,znn.nombre as unidadOperativa
			,Partidas.dbo.SEL_UNIDAD_CADENA_FN(uni.idTipoUnidad) as tipoUnidad
			,'http://189.204.141.193:5101/partidas/' + udd.foto as foto
			,numeroEconomico
			,placas
			,(select count(1)
					from Ordenes ord
					where ord.idUnidad = uni.idUnidad
						and ord.idEstatusOrden in(5,6,7,8,9,10,11,12)) as servicios
			,(select SUM([dbo].[SEL_PRECIO_VENTA_FN](ord.idOrden,@idContratoOperacion,2,2,1))
					from Ordenes ord
					where ord.idUnidad = uni.idUnidad
						and ord.idEstatusOrden in(5,6,7,8,9,10,11,12)) as monto
		from 	
			Unidades uni
			inner join ContratoOperacion co on co.idOperacion = uni.idOperacion
			inner join Partidas.dbo.Unidad udd ON udd.idUnidad = uni.idTipounidad
			left join Partidas.dbo.Zona znn on znn.idZona = uni.idZona
			where co.idContratoOperacion = @idContratoOperacion
		order by 7 desc
			
	
END
go

