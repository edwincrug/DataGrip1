

/*
	Fecha			Autor			Descripción
	21-May-2018		José Etmanuel	Se crea el SP que Cambia el número de póliza

	*---  Pruebas
	
*/

CREATE proc [Banorte].[UPDATE_POL_X_UNI]
	@idUnidad int=0,
	@poliza varchar(100)
as
begin
	update Unidades 
		SET noPoliza =@poliza
		Where idUnidad = @idUnidad;
	
	select 'ok' as ok;
end
go

grant execute, view definition on Banorte.UPDATE_POL_X_UNI to DevOps
go

