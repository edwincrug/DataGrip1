 --SELECT [dbo].[SEL_FACBYPEDIDO_FN](6364, 8, 42322)
 CREATE FUNCTION [dbo].[SEL_FACBYPEDIDO2_TFN_COMPLEMENTO] (@numSiniestro nvarchar(max), @ore_idorden nvarchar(max), @idSucursal int)
returns varchar(max)
as 
begin
	--chevrolet, suzuki, mitsu, chr
	DECLARE @factura varchar(max) = '';
	IF @idSucursal =5 --NISSAN
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAZM_Zaragoza].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAZM_Zaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden

	END 
	ELSE IF @idSucursal=10 --GM
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAAS_Satelite].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAS_Satelite].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END 
	ELSE IF @idSucursal=11 --Ford
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAAAF_Body].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAAF_Body].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=15 --Suzuki
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAAU_Universidad].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAU_Universidad].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=8 --Hyundai
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAHyundai].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAHyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	/*ELSE IF @idMarca=6 --CRA
	BEGIN 
		select @factura=((LEFT(VTE_DOCTO, LEN(VTE_DOCTO) - PATINDEX('%[a-z]%', REVERSE(VTE_DOCTO)) + 1))+
		Replace(REPLACE(LTRIM(REPLACE(Replace((LEFT(SUBSTRING(VTE_DOCTO, PATINDEX('%[0-9.-]%', VTE_DOCTO), 8000),
        PATINDEX('%[^0-9.-]%', SUBSTRING(VTE_DOCTO, PATINDEX('%[0-9.-]%', VTE_DOCTO), 8000) + 'X') -1)), ' ','*'),'0', ' ')), ' ', '0'),'*',' ')) 
		from [192.168.20.29].[GACRA_Cuautitlan].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GACRA_Cuautitlan].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		SO.ore_idSiniestro = @numSiniestro and ore_status = 'I'
	END*/
	ELSE IF @idSucursal=9 --Honda
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAHondaZaragoza].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAHondaZaragoza].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=2 --Volkswagen
	BEGIN 
		
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.31].[GADLA_VW].[dbo].SER_ORDEN SO
		inner join [192.168.20.31].[GADLA_VW].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where-- ORE_DOCTO like '%41628%'
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden

	END
	ELSE IF @idSucursal=3 --Seat
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.31].[GADLA_SEAT].[dbo].SER_ORDEN SO
		inner join [192.168.20.31].[GADLA_SEAT].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=14 --Chevrolet
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAAA_Azcapo].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAA_Azcapo].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=13 --Chrysler
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAAutoAngarTlahuac].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAutoAngarTlahuac].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden

		if(@factura is null or @factura ='')
		begin 
			select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
			from [192.168.20.29].GAAutoAngarTepepan.[dbo].SER_ORDEN SO
			inner join [192.168.20.29].GAAutoAngarTepepan.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
			(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
		end
	END
	ELSE IF @idSucursal= 7 --Hyundai Cam
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAVC_Hyundai].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAVC_Hyundai].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=6 --Mitsubishi
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].[GAAutoAngarMitsu].[dbo].SER_ORDEN SO
		inner join [192.168.20.29].[GAAutoAngarMitsu].[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=16 --Nissan Abasto
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].GAZM_Abasto.[dbo].SER_ORDEN SO
		inner join [192.168.20.29].GAZM_Abasto.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I' AND SUBSTRING(SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20), PATINDEX('%[^0]%',SUBSTRING(ORE_IDORDEN, PATINDEX('%[0]%',ORE_IDORDEN), 20)), 20) = @ore_idorden
	END
	ELSE IF @idSucursal=19 --Suzuki Cuautitlan
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +CAST(AV.VTE_DOCTO AS varchar(max))
		from [192.168.20.29].GAAU_Cuautitlan.[dbo].SER_ORDEN SO
		inner join [192.168.20.29].GAAU_Cuautitlan.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	ELSE IF @idSucursal=18 --Suzuki Pedregal
	BEGIN 
		select @factura = COALESCE(@factura + ', ', '') +  ''''+CAST(AV.VTE_DOCTO AS varchar(max))+''''
		from [192.168.20.29].GAAU_Pedregal.[dbo].SER_ORDEN SO
		inner join [192.168.20.29].GAAU_Pedregal.[dbo].[ADE_VTAFI] AV on AV.vte_referencia1 = SO.ORE_IDORDEN  where
		(SO.ore_idSiniestro = @numSiniestro or SO.ore_numSiniestro = @numSiniestro) and ore_status = 'I' and AV.VTE_STATUS = 'I'
	END
	
	select @factura= STUFF(@factura, 1, 1, '')

	return @factura
end
 go

