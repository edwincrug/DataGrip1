-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 21-03-2019
-- Description: Obtiene los datos de la orden
-- BANORTE.SEL_ESTATUSORDENCONTRARECIBO  40303
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_ESTATUSORDENCONTRARECIBO]
	@idOrden INT	
AS
BEGIN
	SET NOCOUNT ON;	
	BEGIN TRY 
		DECLARE @idEstatus INT
			, @descripcion VARCHAR(100)
			, @numeroContraRecibo VARCHAR(100)
			, @fechaContraRecibo VARCHAR(100)

		SELECT @idEstatus = O.idEstatusOrden
			, @descripcion = EO.nombreEstatusOrden
		FROM Ordenes O
		INNER JOIN EstatusOrdenes EO
		ON O.idEstatusOrden=EO.idEstatusOrden
		WHERE O.idOrden = @idOrden

		SELECT @numeroContraRecibo = ISNULL(C.numeroContraRecibo, '')
			, @fechaContraRecibo = ISNULL(CONVERT(VARCHAR(24), c.fechaContrarecibo, 103),'')
		FROM Ordenes O
		LEFT JOIN DatosCopade D
		ON D.numeroCopade = O.numeroOrden
		LEFT JOIN ContrareciboDatosCopade CDC 
		ON CDC.idDatosCopade = D.idDatosCopade
		LEFT JOIN Contrarecibo C 
		ON C.idContrarecibo = CDC.idContrarecibo
		WHERE O.idOrden = @idOrden
					
		SELECT @idEstatus AS idEstatus, @descripcion AS descripcion, @numeroContraRecibo AS numeroContraRecibo, @fechaContraRecibo AS fechaContraRecibo

	END TRY 	
	BEGIN CATCH	
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

	SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.SEL_ESTATUSORDENCONTRARECIBO to DevOps
go

