-- =============================================
-- Description:	Obtengo si aplica para el boton de negligencia
-- =============================================
-- [dbo].[SEL_APLICA_CARGA_ASOCIACIONES] 48
CREATE PROCEDURE [dbo].[SEL_APLICA_CARGA_ASOCIACIONES]
@idOperacion numeric(18,0)
AS
BEGIN

SELECT COUNT(*) AS Aplica FROM (
SELECT IdOperacion FROM ParametrosGeneralOperacion WHERE IdParametroGeneral = 2 AND Estatus=1
UNION ALL
SELECT 58 
) AS R
WHERE R.IdOperacion=@idOperacion

END
go

