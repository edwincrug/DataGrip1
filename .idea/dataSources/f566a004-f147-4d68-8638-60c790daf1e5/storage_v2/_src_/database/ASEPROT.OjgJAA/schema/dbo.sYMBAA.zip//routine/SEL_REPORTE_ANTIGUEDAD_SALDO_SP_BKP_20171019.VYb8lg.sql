-- [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP]  1
-- [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP]  3
CREATE procedure  [dbo].[SEL_REPORTE_ANTIGUEDAD_SALDO_SP_BKP_20171019] 

@idOperacion as int = null,
@fechaInicial as varchar(25) =NULL,
@fechaFinal as varchar(25)= NULL,
@taller as varchar(150)= NULL,
@idCallcenter as int=NULL,
@idEstatus as int= NULL,
@idZona as int=NULL,
@numeroOrden varchar(50) = NULL

AS
BEGIN
		DECLARE @zonasAsignadas TABLE (idZona INT)
		INSERT INTO @zonasAsignadas values(@idZona)

		IF(@idCallcenter IS NOT NULL)
		BEGIN
			DECLARE @idCOU NUMERIC(18,0) = [dbo].[GET_CONTRATO_OPERACION_USR_FN](@idCallcenter ,@idOperacion)		
			INSERT INTO @zonasAsignadas 
			SELECT idZona FROM [dbo].[GET_ZONAS_USR_FN](@idCOU)			
		END

		IF(@idCallcenter IS NULL AND  @idZona IS NULL)
		BEGIN
			INSERT INTO @zonasAsignadas 			
			SELECT Z.idZona FROM ContratoOperacion CO
			INNER JOIN Partidas..Contrato C ON CO.idContrato= C.idContrato
			INNER JOIN Partidas..Licitacion L ON l.idLicitacion = c.idLicitacion
			INNER JOIN Partidas..NivelZona NZ ON l.idCliente = NZ.idCliente
			INNER JOIN Partidas..Zona Z ON NZ.idNivelZona = Z.idNivelZona
			WHERE idOperacion=@idOperacion 
		END

		Declare @SumCosto NUMERIC(18,4)
		Declare @SumVenta NUMERIC(18,4)

		--SELECT  @SumCosto = sum(costo), @SumVenta = sum(Venta)
		--FROM 	[report].[VwReporteAntiguedadSaldos]	
			
		--WHERE	fechaCreacionOrden 
		--BETWEEN isnull(@fechaInicial,convert(datetime,'1/1/1800')) 
		--AND		isnull(@fechaFinal,convert(datetime,'1/1/2500'))
		--AND		(@taller IS NULL OR talleres like '%'+ @taller +'%') 
		--AND		(@idEstatus IS NULL OR idEstatus=@idEstatus ) 
		--AND		(@numeroOrden IS NULL OR numeroOrden like '%'+ @numeroOrden+ '%') 
		--AND		idZona IN (select idZona from @zonasAsignadas)
		--AND     [idOperacion] = @idOperacion
		--AND     [idEstatusOrden] < 13





		SELECT  
		        [Cliente]
			   ,VRA.[idOrden]
               ,[consecutivoOrden]
               ,[numeroOrden]
               ,[numeroEconomico]
               ,[idZona]
               ,[talleres]
               ,[costo]
               ,[venta]
               ,[descripcion]
               ,[estatus]
               ,[idEstatus]
               ,[fechaCreacionOrden]
               ,[fechaAprobacion]
               ,[fechaProceso]
               ,[fechaTerminoTrabajo]
               ,[fechaSalidaV]
               ,[fechadeFinalizacionV]
               ,[dias_0_30]
               ,[dias_31_45]
               ,[dias_46_60]
               ,[dias_mas_60]
               ,[dias]
               ,[diasD]
               ,[zonasConcatenadas]
               ,[nombrePadre]
               ,[nombreZona]
               ,[tipoUnidad]
               ,[tipoCombustible]
               ,[marca]
               ,[subMarca]
               ,[modelo]
               ,[folio]
               ,[folioPresupuesto]
               ,[idOperacion]
               ,[idEstatusOrden] 
			   ,VRC.[COP_IDDOCTO] as numCop
		FROM 	[report].[VwReporteAntiguedadSaldos] VRA	
  INNER JOIN    [report].[VwReporteGeneralCopadeUnique] VRC
          ON    VRA.idOrden = VRC.idOrden
			
		WHERE	fechaCreacionOrden 
		BETWEEN isnull(@fechaInicial,convert(datetime,'1/1/1800')) 
		AND		isnull(@fechaFinal,convert(datetime,'1/1/2500'))
		AND		(@taller IS NULL OR talleres like '%'+ @taller +'%') 
		AND		(@idEstatus IS NULL OR idEstatus=@idEstatus ) 
		AND		(@numeroOrden IS NULL OR numeroOrden like '%'+ @numeroOrden+ '%') 
		AND		idZona IN (select idZona from @zonasAsignadas)
		AND     [idOperacion] = @idOperacion
		AND     [idEstatusOrden] < 13
		

		
END
go

