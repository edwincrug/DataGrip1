-- =============================================
-- Description:	Busca todas las órdenes existentes
-- NOTA: Falta verificar el usuario, su rol y el tipo de operación 
-- =============================================
-- [dbo].[SEL_ORDENES_SP]

CREATE PROCEDURE [dbo].[SEL_ORDENES_SP]
AS
BEGIN

	SELECT 
	  Orden.[idOrden]
      ,[numeroOrden]
      ,[fechaCita] as fecha
	  ,convert(datetime, fechaCreacionOden, 103) as fechaCreacionOden
      ,fechaInicioTrabajo
	  ,comentarioOrden
      ,Uni.[numeroEconomico]
      ,[requiereGrua]
      ,EstadoUni.[idCatalogoEstadoUnidad]
	  ,EstadoUni.descripcionEstadoUnidad
      ,[idZona]
      ,Uni.[idUnidad]
	  ,[consecutivoOrden]
      ,EtsOrden.[idEstatusOrden]
	  ,EtsOrden.[nombreEstatusOrden]
      ,ConOpe.[idContratoOperacion]
      ,Usu.[idUsuario]
	  ,Usu.nombreUsuario
      ,CaTiOrSe.[idCatalogoTipoOrdenServicio]
	  ,CaTiOrSe.[nombreTipoOrdenServicio]
      ,CaTiOr.[idTipoOrden]
	  ,CaTiOr.nombreTipoORden 
	FROM [dbo].[Ordenes] Orden
	INNER JOIN [dbo].[CatalogoEstadoUnidad] EstadoUni ON EstadoUni.idCatalogoEstadoUnidad = Orden.idCatalogoEstadoUnidad
	INNER JOIN [dbo].[Unidades] Uni ON Uni.idUnidad = Orden.idUnidad
	--INNER JOIN [dbo].[OrdenEstatusOrden] OrdeEsOr ON OrdeEsOr.idEstatusOrden = orden.idOrden
	INNER JOIN [dbo].[EstatusOrdenes] EtsOrden ON EtsOrden.idEstatusOrden = Orden.idEstatusOrden --AND 
	INNER JOIN [dbo].[ContratoOperacion] ConOpe ON ConOpe.idContratoOperacion = Orden.idContratoOperacion
	INNER JOIN [dbo].[Usuarios] Usu ON usu.idUsuario = Orden.idUsuario
	INNER JOIN [dbo].[CatalogoTiposOrdenServicio] CaTiOrSe ON CaTiOrSe.idCatalogoTipoOrdenServicio = Orden.idCatalogoTipoOrdenServicio
	--INNER JOIN [dbo].[Acciones] Acc ON Acc.idAccion = Orden.idAccion
	INNER JOIN [dbo].[CatalogoTipoOrden] CaTiOr ON CaTiOr.idTipoOrden = Orden.idTipoOrden
	--WHERE EtsOrden.idEstatusOrden IN (2,1)
END


go

