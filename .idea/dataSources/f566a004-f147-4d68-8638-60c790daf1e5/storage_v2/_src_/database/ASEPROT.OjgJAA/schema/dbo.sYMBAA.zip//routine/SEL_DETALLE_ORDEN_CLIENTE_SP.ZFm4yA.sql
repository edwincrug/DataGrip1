-- =============================================
-- Description:	Busca los detalles del cliente relacionado con la orden
-- NOTA: 
-- [SEL_DETALLE_ORDEN_CLIENTE_SP] @numeroOrden ='100010'
-- =============================================
CREATE PROCEDURE [dbo].[SEL_DETALLE_ORDEN_CLIENTE_SP]
@idUsuario INT = 0,
@numeroOrden VARCHAR(50) = ''
AS
BEGIN
	select CLI.*
	from Ordenes ORD
	INNER JOIN ContratoOperacion CONTOPE on CONTOPE.idContratoOperacion = ORD.idContratoOperacion 
	INNER JOIN Partidas..Contrato CONT on CONTOPE.idContrato = CONT.idContrato
	INNER JOIN Partidas..Licitacion L on L.idLicitacion = CONT.idLicitacion
	INNER JOIN Partidas..Cliente CLI on CLI.idCliente = L.idCliente
	where numeroOrden = @numeroOrden
END

go

