-- =============================================
-- Author:		LQMA 
-- Create date: 05/06/2017
-- INS_USUARIO_SP '1633010407010','16260516-0010',0,3,0,3,1,'GFE450' 
-- =============================================
 CREATE PROCEDURE [dbo].[INS_USUARIO_SP]
	@nombreUsuario VARCHAR(50) = '',
	@contrasenia VARCHAR(50) = '',
	@idCatalogoTipoUsuarios INT = null,
	@nombreCompleto VARCHAR(50) = '',
	@correoElectronico VARCHAR(50) = '',
	@telefonoUsuario VARCHAR(50) = '',
	@extensionUsuario VARCHAR(50) = '',
	@empresa VARCHAR(50) = '',
	@contratoOp int = null,
	@idCatalogoRol int = null
AS
BEGIN
	
  DECLARE @idUsuario NUMERIC(18,0) = 0
  
--IF NOT EXISTS(SELECT numeroEconomico FROM Unidades WHERE idOperacion = @idOperacion AND numeroEconomico = @numeroEconomico)
--	BEGIN
		  INSERT INTO [Usuarios] (
				nombreUsuario,
				contrasenia,
				idCatalogoTipoUsuarios,
				nombreCompleto,
				correoElectronico,
				telefonoUsuario,
				extensionUsuario,
				empresa)
			VALUES(
				@nombreUsuario,
				@contrasenia,
				@idCatalogoTipoUsuarios,
				@nombreCompleto,
				@correoElectronico,
				@telefonoUsuario,
				@extensionUsuario,
				@empresa)

			SET @idUsuario = @@IDENTITY 


			IF (@contratoOp IS NOT NULL AND @idCatalogoRol IS NOT NULL)
				BEGIN					
					INSERT INTO [dbo].[ContratoOperacionUsuario]
							   ([idContratoOperacion]
							   ,[idUsuario]
							   ,[idCatalogoRol])
						 VALUES
							   (@contratoOp
							   ,@idUsuario
							   ,@idCatalogoRol)
				END

			SELECT @idUsuario AS idUsuario
		
	--END
  
  
END


go

