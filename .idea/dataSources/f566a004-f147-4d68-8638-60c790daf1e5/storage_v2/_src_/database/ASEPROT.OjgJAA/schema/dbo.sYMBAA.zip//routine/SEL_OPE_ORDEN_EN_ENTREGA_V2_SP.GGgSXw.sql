-- =============================================
-- Author:		Edgar mendoza
-- Create date: 2018/11/29
-- Description:	Obtiene las ordenes con estatus en entrega
-- [SEL_OPE_ORDEN_EN_ENTREGA_V2_SP] 538,57, @estatus = null
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OPE_ORDEN_EN_ENTREGA_V2_SP]
@idUsuario int,--507
@idContratoOperacion int = NULL,
--FILTROS
@idEjecutivoFiltro				INT = 0,--125
@idZona							INT = NULL,
@fechaIni						VARCHAR(MAX) = NULL,
@fechaFin						VARCHAR(MAX) = NULL,
@estatus						INT = NULL,
@err							VARCHAR(500) = NULL	OUTPUT

AS
BEGIN
	BEGIN TRY
	declare @idCatalogoRol int
	declare @idContratoOperacionUsuario int
	declare @esAgrupador bit = 0
	declare @tokenRequerido  int = 0 

	declare @idContratoOperacionBan int = 0 

	select @idContratoOperacionBan= valor from Banorte.Parametros where id=2
	SELECT @tokenRequerido = validacionportoken from dbo.ContratoOperacionFacturacion where idcontratooperacion = @idContratoOperacion

	CREATE TABLE #UNIDADES(
	idUnidad int)

	declare @tblCitasGeneral as table(
		nombreCliente varchar(max),
		consecutivoOrden int,
		numeroOrden varchar(max),
		numeroEconomico varchar(max),
		nombreZona varchar(max),
		nombreTipoOrdenServicio varchar(max),
		fechaCreacionOden datetime,
		aplicaFondo VARCHAR(30),	
		comentarioOrden varchar(max),
		idEstatusOrden int,
		conjuntoEstatus varchar(30),
		nombreEstatusOrden varchar(max),
		nombreUsuario varchar(max),
		venta float,
		costo float,
		tiempoEspera int,
		idOrden int,
		idZona int,
		estatusToken VARCHAR(30),
		seguro bit
		,Taller nvarchar(100)
	)

	declare @tblCitasZona as table(
		nombreCliente varchar(max),
		consecutivoOrden int,
		numeroOrden varchar(max),
		numeroEconomico varchar(max),
		nombreZona varchar(max),
		nombreTipoOrdenServicio varchar(max),
		fechaCreacionOden datetime,
		aplicaFondo VARCHAR(30),	
		comentarioOrden varchar(max),
		idEstatusOrden int,
		conjuntoEstatus varchar(30),
		nombreEstatusOrden varchar(max),
		nombreUsuario varchar(max),
		venta float,
		costo float,
		tiempoEspera int,
		idOrden int,
		idZona int,
		estatusToken VARCHAR(30),
		seguro bit
		,Taller nvarchar(100)
	)


	IF EXISTS (SELECT 1 FROM .UsuarioAgrupador where idUsuario = @idUsuario)
	BEGIN
		set @esAgrupador = 1
	--EN CASO DE QUE SEA POR AGRUPADOR
		insert into #UNIDADES
		SELECT
			uniagr.idUnidad
		FROM [dbo].UnidadAgrupador uniagr
		inner join [dbo].Agrupador agr on agr.Id = uniagr.idAgrupador
		inner join [dbo].UsuarioAgrupador usuagr on usuagr.idAgrupador = agr.Id

		where idUsuario = @idUsuario

	END
	ELSE 
	BEGIN
		--EN CASO DE QUE SEA POR OPERACION
		SELECT 
			@esAgrupador = 0,
			@idCatalogoRol = COU.idCatalogoRol, 
			@idContratoOperacionUsuario = COU.idContratoOperacionUsuario
		FROM dbo.Usuarios U 
			JOIN dbo.ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
		WHERE 
			U.idUsuario = @idUsuario 
			and COU.idContratoOperacion = @idcontratooperacion

		insert into #UNIDADES
		select distinct uni.idUnidad
		from [dbo].Unidades uni
		inner join [dbo].Operaciones ope on uni.idOperacion = ope.idOperacion
		inner join [dbo].ContratoOperacion conope on conope.idOperacion = ope.idOperacion
		where 
			conope.idContratoOperacion = @idContratoOperacion
	END



	--select * from #UNIDADES

	insert into @tblCitasGeneral 
	SELECT 
			(SELECT descripcion FROM PARTIDAS..CONTRATO PCO where idContrato =(SELECT idContrato 
																				FROM .contratoOperacion 
																				WHERE idContratoOperacion = O.idContratoOperacion)
																				)AS nombreCliente,
			O.consecutivoOrden,
			O.numeroOrden,
			U.numeroEconomico,
			Z.nombre AS nombreZona,
			CTO.nombreTipoOrdenServicio AS nombreTipoOrdenServicio,
			O.fechaCreacionOden,
			--CASE WHEN CAST(CONVERT(VARCHAR(25),O.fechaCreacionOden,103) AS DATETIME) <='12/11/2018' THEN 1
			CASE WHEN O.fechaCreacionOden <='12/11/2018' THEN 'rowAzulDark'
			ELSE '' END
			AS aplicaFondo,	
			O.comentarioOrden AS comentarioOrden,
			O.idEstatusOrden,
			'1',
			EO.nombreEstatusOrden AS nombreEstatusOrden,
			UR.nombreCompleto AS nombreUsuario,
			(SELECT [dbo].[SEL_ORDEN_PRECIOVENTA_FN](O.idOrden, 1,@idUsuario)) AS venta,
			(SELECT [dbo].[SEL_ORDEN_PRECIOCOSTO_FN](O.idOrden, 1, @idUsuario)) AS costo,
			DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEspera,
			O.idOrden,
			Z.idZona,
			CASE
				WHEN @tokenRequerido = 1 THEN
					[dbo].[cadena_un_Token] (O.numeroOrden)
				ELSE
					SUBSTRING(CONVERT(VARCHAR(30),[dbo].[cadenaToken](O.numeroOrden)),3,100)
			END,
			--SUBSTRING(CONVERT(VARCHAR(30),[dbo].[cadenaToken](O.numeroOrden)),3,100),
			--substring([dbo].[cadenaToken](O.numeroOrden), 3, 100) AS estatusToken
			CASE
				WHEN O.idCatalogoTipoOrdenServicio in (4,5,6,7,8,9) 
						OR O.idCatalogoTipoOrdenServicio IS NULL THEN 1
				ELSE 0
			END
			,case when @idContratoOperacion = @idContratoOperacionBan then 
								[dbo].[SEL_PROVEEDORREFAC_ORDEN_FN](O.idOrden) else 
							'' end  as Taller
		FROM dbo.Ordenes O
			--LEFT JOIN dbo.OrdenesColores OC 
			--	LEFT JOIN dbo.ColoresBackground CB ON CB.idColoresBackground=OC.idColor
			--ON OC.numeroOrden=O.numeroOrden AND OC.idContratoOperacion=O.idContratoOperacion
			INNER JOIN dbo.Unidades U ON U.idUnidad = O.idUnidad
			INNER JOIN dbo.EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
			--JOIN dbo.ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
			INNER JOIN dbo.CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
			INNER JOIN dbo.HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
			LEFT JOIN dbo.PreCancelacionOrdenes PC ON PC.idOrden = O.idOrden
			INNER JOIN dbo.Usuarios UR ON UR.idUsuario = O.idUsuario
			INNER JOIN Partidas..Zona Z ON Z.idZona = O.idZona 
		
			WHERE 
				U.idUnidad in (select * from #UNIDADES)
				AND O.idEstatusOrden IN(6,7) 
				AND PC.idOrden IS NULL 
				--parametro zona
				AND O.idZona = COALESCE(@idZona, O.idZona)
				AND fechaCreacionOden between COALESCE(@fechaIni, fechaCreacionOden) and COALESCE(@fechaFin, fechaCreacionOden)
				AND O.idContratoOperacion NOT IN(8) --LINEA QUITA AFO SOPORT
	return
	drop table #UNIDADES

	--APLICACION DE FILTROS



	if ( @idEjecutivoFiltro = 0) 
	begin
		insert into @tblCitasZona select * from @tblCitasGeneral
	end
	else
	begin
		insert into @tblCitasZona select * from @tblCitasGeneral as tblGral where tblGral.idZona in(
					select z.idZona  from [dbo].[ContratoOperacionUsuarioZona] Z
						inner join dbo.contratooperacionusuario COU on cou.idcontratooperacionusuario = z.idcontratooperacionusuario
						inner join dbo.contratooperacion co on co.idContratoOperacion = cou.idcontratooperacion
						where 
							--co.idcontratooperacion= @idcontratooperacion r
							cou.idUsuario = @idEjecutivoFiltro
				)
	end
	-- si es proveedor
	if(@idCatalogoRol = 4)
		begin
			select * from @tblCitasZona tblZona where 
				tblZona.idOrden in(
					SELECT ctz.idOrden FROM dbo.Cotizaciones ctz
						where ctz.idOrden = tblZona.idOrden 
						AND ctz.idTaller in (
							SELECT cop.idProveedor
								FROM dbo.ContratoOperacionUsuario cou 
								INNER JOIN dbo.ContratoOperacionUsuarioProveedor cop ON cop.idContratoOperacionUsuario =  cou.idContratoOperacionUsuario
								WHERE cou.idUsuario = @idUsuario
								and cou.idContratoOperacion = @idcontratooperacion
							)
				)
		end
		-- si es rol gerente de zona
	else if(@idCatalogoRol = 9)
		begin
				select * from @tblCitasZona tblZ where tblZ.idZona in ( 
				SELECT ezo.idZona FROM dbo.[ContratoOperacionUsuarioGerente] cog
					JOIN [Gerente].[EstadoGerencia] esg ON esg.idGerencia = cog.idGerencias
					JOIN [Gerente].[EstadoZona] ezo ON ezo.idEstado = esg.idEstado
					INNER JOIN dbo.ContratoOperacionUsuario cou on cou.idContratoOperacionUsuario = cog.idContratoOperacionUsuario and cou.idContratoOperacion = @idcontratooperacion
					WHERE 
						esg.estatus=0 --activo
						AND ezo.estatus=0 --activo
						AND cou.idUsuario = @idUsuario
			)
		end
		--si es admin
	else if(@idCatalogoRol = 2 or @esAgrupador=1)
		begin
			select * from @tblCitasZona
			where idEstatusorden = ISNULL(@estatus, idEstatusOrden)
		end
		-- rol diferente
	else
		begin
			select * from @tblCitasZona 
			where idZona in (
				SELECT idZona FROM dbo.ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario
			)
		end

	END TRY

	BEGIN CATCH
		set  @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()
	END CATCH

	PRINT 'OUT = ' +  @err
	RETURN
END
go

