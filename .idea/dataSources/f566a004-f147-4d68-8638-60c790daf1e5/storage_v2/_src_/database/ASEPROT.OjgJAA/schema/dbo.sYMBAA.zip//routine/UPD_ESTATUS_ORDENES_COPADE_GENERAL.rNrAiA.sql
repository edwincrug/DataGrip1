--[UPD_ESTATUS_ORDENES_COPADE_GENERAL] 1, '3,57'
CREATE PROC [dbo].[UPD_ESTATUS_ORDENES_COPADE_GENERAL]

@isProduction numeric(20) = null,
@idsContratoOperacion nvarchar(MAX) = null

as
DECLARE	@server  VARCHAR(max) = ''
DECLARE	@db  VARCHAR(max) = ''	
DECLARE	@historicoBase  VARCHAR(max) = ''	
declare @idContratoOperacion numeric(18,0)
DECLARE @Ids_ContratoOperacion table(Id numeric(18,0))
declare @query varchar(max)= ''
set @idsContratoOperacion = @idsContratoOperacion+',';
with cte as
(
	select SUBSTRING(@idsContratoOperacion,1,charindex(',',@idsContratoOperacion,1)-1) as val, SUBSTRING(@idsContratoOperacion,charindex(',',@idsContratoOperacion,1)+1,len(@idsContratoOperacion)) as rem 
	UNION ALL
	select SUBSTRING(a.rem,1,charindex(',',a.rem,1)-1)as val, SUBSTRING(a.rem,charindex(',',a.rem,1)+1,len(A.rem)) 
	from cte a where LEN(a.rem)>=1
) insert into @Ids_ContratoOperacion select val from cte

--SELECT Id FROM @Ids_ContratoOperacion

DECLARE COPADE_C CURSOR FOR  
SELECT Id
FROM @Ids_ContratoOperacion
OPEN COPADE_C;  
FETCH NEXT FROM COPADE_C
INTO @idContratoOperacion;  
WHILE @@FETCH_STATUS = 0  
BEGIN


IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server = SERVER,
				@db = DBProduccion		
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idContratoOperacion =  @idContratoOperacion
	END
ELSE 
	BEGIN
		SELECT 
				@server=SERVER,
				@db = DB
		FROM ContratoOperacionFacturacion COF 
		inner join ContratoOperacion CO on CO.idContratoOperacion = COF.idContratoOperacion
		WHERE CO.idContratoOperacion =  @idContratoOperacion
	END
IF (@idContratoOperacion=3 OR @idContratoOperacion =15 OR @idContratoOperacion =57 OR @idContratoOperacion =36)
BEGIN
  SET @historicoBase='14'
END
ELSE
BEGIN 
  SET @historicoBase='8'
END

set @query = ''
set @query = '
DECLARE @idOrden AS numeric(18)
DECLARE @idEstatuscopade AS numeric(18)
DECLARE ordenCursor CURSOR FOR select distinct o.idOrden,a.COP_STATUS
from DatosCopadeOrden dco 
     inner join OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
     inner join OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
     inner join Ordenes o on o.idOrden=dco.idOrden
     inner join  '+@server+'.'+@db+'.dbo.ADE_COPADE a on a.COP_ORDENGLOBAL=oa.numero COLLATE Latin1_General_CI_AS
where 
(a.COP_STATUS=3 and o.idEstatusOrden not in (12,13)) or (a.COP_STATUS=4 and o.idEstatusOrden not in (11,13))
 or(a.COP_STATUS=2 and o.idEstatusOrden not in (10,13))or(a.COP_STATUS=1 and o.idEstatusOrden not in (9,13))
  and o.idOrden not in
(
select ordenesFuera.idOrden from
(
select distinct o.idOrden,count(a.COP_STATUS) count
from DatosCopadeOrden dco 
     inner join OrdenAgrupadaDetalle oad on oad.idDatosCopadeOrden=dco.idDatosCopadeOrden
     inner join OrdenAgrupada oa on oa.idOrdenAgrupada=oad.idOrdenAgrupada
     inner join Ordenes o on o.idOrden=dco.idOrden
     inner join  '+@server+'.'+@db+'.dbo.ADE_COPADE a on a.COP_ORDENGLOBAL=oa.numero COLLATE Latin1_General_CI_AS
  group by o.idorden having count(a.COP_STATUS)>1) ordenesFuera
)
OPEN ordenCursor
FETCH NEXT FROM ordenCursor INTO @idOrden,@idEstatuscopade 
WHILE @@fetch_status = 0
BEGIN

	 if (@idEstatuscopade=1)
	 begin
	 if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden='+@historicoBase+')
	 begin
		update Ordenes
		set idEstatusOrden=9 
		where idOrden=@idOrden

		update HistorialEstatusOrden
		  set fechaFinal=GETDATE()
		where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
		
	    if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=14)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,14,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

		insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		select top 1 @idOrden,9,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
	 end
	 end
	 if (@idEstatuscopade=2)
	 begin

	 if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden='+@historicoBase+')
	 begin

		update Ordenes
		set idEstatusOrden=10
		where idOrden=@idOrden

		update HistorialEstatusOrden
		  set fechaFinal=GETDATE()
		where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)
		
		insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		select top 1 @idOrden,10,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
	 end
	 end
	 if (@idEstatuscopade=3)
	 begin
	 if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden='+@historicoBase+')
	 begin

		update Ordenes
		set idEstatusOrden=12 
		where idOrden=@idOrden

		update HistorialEstatusOrden
		  set fechaFinal=GETDATE()
		where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)

		if not exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden=11)
		begin 
		     insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		     select top 1 @idOrden,11,fechaFinal,GETDATE(),529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
		end

		insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		select top 1 @idOrden,12,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
	 end
	 end 

	 if (@idEstatuscopade=4)
	 begin

	 if exists(select *from HistorialEstatusOrden where idOrden=@idOrden and idEstatusOrden='+@historicoBase+')
	 begin
	    print @idOrden

		update Ordenes
		set idEstatusOrden=11 
		where idOrden=@idOrden

		update HistorialEstatusOrden
		  set fechaFinal=GETDATE()
		where idHistorialEstatusOrden=(select top 1 idHistorialEstatusOrden from HistorialEstatusOrden where idOrden=@idOrden and fechaFinal is null)

		insert into HistorialEstatusOrden(idOrden,idEstatusOrden,fechaInicial,fechaFinal,idUsuario)
		select top 1 @idOrden,11,fechaFinal,null,529 from HistorialEstatusOrden where idOrden=@idOrden order by fechaFinal desc
	 end
	 end
    FETCH NEXT FROM ordenCursor INTO @idOrden, @idEstatuscopade 
END
CLOSE ordenCursor
DEALLOCATE ordenCursor
'
--EXECUTE SP_EXECUTESQL @query
EXEC (@query)
print @query

FETCH NEXT FROM COPADE_C
INTO @idContratoOperacion;    
END  
CLOSE COPADE_C;  
DEALLOCATE COPADE_C;
go

