/*
SELECT * FROM [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERenc]
SELECT * FROM [192.168.20.31].[GATPartsToluca_P].[dbo].[ADE_ORDSERdet]
select * from Cotizaciones where numeroCotizacion='01-3110073-126-2'
[INS_ORDEN_DETALLE_S3_SP] 51557,4,1,16,1
*/
CREATE PROCEDURE [dbo].[INS_ORDEN_DETALLE_S3_SP]
	@idCotizacion NUMERIC(18,0) = 0,
	@idEncabezado NUMERIC(18,0) = 0,	
	@tipoDetalle SMALLINT = 1,-- 1: servicio, 2: refacciones
	@idOperacion NUMERIC(18,0),
	@isProduction NUMERIC(18,0)
AS
BEGIN	

DECLARE @server NVARCHAR(100)
DECLARE @db NVARCHAR(100)
DECLARE	@query NVARCHAR(MAX)
DECLARE @idContratoOperacion VARCHAR(5)
DECLARE @nombreOperacion NVARCHAR(100)
DECLARE @taller NVARCHAR(300)
DECLARE @vin NVARCHAR(30)
DECLARE	@queryInsertDet NVARCHAR(MAX)
DECLARE	@numFact VARCHAR(50)
DECLARE @marca varchar(100)
DECLARE @submarca varchar(100)
DECLARE @modelo varchar(100)
DECLARE @placas varchar(100)
DECLARE @noOrden varchar(100)
DECLARE @actualizaObs NVARCHAR(MAX)
DECLARE @empleado NVARCHAR(100)
DECLARE @noEco NVARCHAR(100)
DECLARE @idOrden numeric(18,0)
DECLARE @folioPresupuesto NVARCHAR(100)
DECLARE @queryupdateEncLet NVARCHAR(MAX)

SELECT @idContratoOperacion=idContratoOperacion FROM ContratoOperacion WHERE idOperacion=@idOperacion
SELECT @noOrden = O.numeroOrden FROM Cotizaciones C
		INNER JOIN Ordenes O ON O.idOrden = C.idOrden
		WHERE C.idCotizacion = @idCotizacion


IF(@isProduction = 1)
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DBProduccion
		FROM ContratoOperacionFacturacion 
		WHERE idContratoOperacion=@idContratoOperacion
	END
ELSE
	BEGIN
		SELECT 
				@server=SERVER,
				@db=DB
		FROM ContratoOperacionFacturacion 
		WHERE idContratoOperacion=@idContratoOperacion
	END

    IF(@tipoDetalle = 1) -- SERVICIO
		BEGIN
			SET @query = 'INSERT INTO [dbo].[ADE_ORDSERDET](
						[OTD_IDENT],
						[OTD_CONSECUTIVO],
						[OTD_DESCRIPCION],
						[OTD_CANTIDAD],
						[OTD_PRECIOUNITARIOCOMPRA],
						[OTD_SUBTOTALUNITARIO],
						[OTD_IVAUNITARIO],
						[OTD_TOTALUNITARIO],
						[OTD_PRECIOUNITARIOVENTA],
						[OTD_FECHOPE],
						[OTD_HORAOPE],
						[OTD_FAMILIA])
				SELECT 				   
					   '+CAST(@idEncabezado AS NVARCHAR(30))+',
					   ROW_NUMBER() OVER(ORDER BY O.idOrden DESC) AS Row,
					   P.descripcion, --OTD_DESCRIPCION
					   CAST(CD.cantidad AS NVARCHAR(MAX)), --OSD_CANTIDAD				   
					   CAST(CD.costo AS NVARCHAR(MAX)), --OTD_PRECIOUNITARIOCOMPRA
					   CAST(CAST((CD.cantidad * CD.costo) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_SUBTOTALUNITARIO
					   CAST(CAST((CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_IVAUNITARIO
					   CAST(CAST((CD.cantidad * CD.costo) + (CD.cantidad * (CD.costo * [dbo].[fnFactorIVA_Orden](O.idOrden ,0))) AS DECIMAL(18,2)) AS NVARCHAR(MAX)), --OTD_TOTALUNITARIO
					   CAST(CD.venta AS NVARCHAR(MAX)),--OTD_PRECIOUNITARIOVENTA
					   CONVERT(VARCHAR(10),GETDATE(),103), --fecha de la base
					   CONVERT(VARCHAR(8),GETDATE(),108), --hora de la base
					   ''''
				   	FROM Ordenes O
						JOIN Cotizaciones C ON C.idOrden  = O.idOrden 
						JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion 
						JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
						WHERE C.idCotizacion = '+CAST(@idCotizacion AS NVARCHAR(30))+' AND CD.idEstatusPartida IN(2) AND C.idEstatusCotizacion IN(3)
						GROUP BY C.numeroCotizacion, O.idOrden, CD.cantidad, CD.costo, CD.venta, P.descripcion, CD.idPartida'

			EXECUTE SP_EXECUTESQL @query

			SET @queryupdateEncLet = 'UPDATE B
					SET B.OTE_DESGLOSE = ''A''
					FROM dbo.ADE_ORDSERENC B
					INNER JOIN 
					(SELECT OTE_ORDENGLOBAL, 
					CASE
						 WHEN count(OTE_ORDENGLOBAL) > 1 THEN 
							 1 END S 
					FROM dbo.ADE_ORDSERenc group by OTE_ORDENGLOBAL) A ON A.S is not null AND A.OTE_ORDENGLOBAL = ' + ''''+@noOrden+''''
            
			EXECUTE SP_EXECUTESQL @queryupdateEncLet

			IF(@idOperacion = 15)
				BEGIN
					SELECT @noEco = U.numeroEconomico, @noOrden = O.numeroOrden, @idOrden = O.idOrden 
					FROM Cotizaciones C
					INNER JOIN Ordenes O ON O.idOrden = C.idOrden
					INNER JOIN Unidades U ON O.idUnidad = U.idUnidad
					WHERE C.idCotizacion = @idCotizacion

					SELECT @vin = U.vin, @placas = U.placas FROM Cotizaciones C
					INNER JOIN Ordenes O ON O.idOrden = C.idOrden
					INNER JOIN Unidades U ON O.idUnidad = U.idUnidad
					INNER JOIN Partidas..Unidad TU ON TU.idUnidad = U.idTipoUnidad
					INNER JOIN Partidas..SubMarca SM ON SM.idSubMarca = TU.idSubMarca
					INNER JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
					WHERE C.idCotizacion = @idCotizacion

					SELECT @empleado = E.numeroEmpleado
					FROM OrdenEmpleado OE 
					INNER JOIN Empleados E ON OE.idEmpleado = E.idEmpleado
					WHERE OE.idOrden = @idOrden

					SELECT @folioPresupuesto = folioPresupuesto FROM PresupuestoOrden PO
					INNER JOIN Presupuestos P ON PO.idPresupuesto = P.idPresupuesto
					WHERE IDORDEN = @idOrden

					SET @actualizaObs = 'UPDATE dbo.[ADE_ORDSERENC]
					SET OTE_OBSERVACIONES =''SERVICIO DE MANTENIMIENTO GENERAL PARA FLOTILLA DE VEHICULOS DE TODAS LAS MARCAS No. Orden SISCO: ' + @noOrden + '''+ '' / Orden de compra: ' +  @folioPresupuesto + ''' + '' / No. Empleado: ' +  @empleado + '''+ '' / No. Economico: ' +  @noEco + ''' + '' / VIN: ' + @vin + '''+ '''  + ''' + '' / Placas: ' + @placas + '''
					WHERE OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '';

						--SET @actualizaObs = 'UPDATE ' + @server + '.' + @db + '.dbo.[ADE_ORDSERENC]
						--SET OTE_OBSERVACIONES = ''No. Orden SISCO: ' + @noOrden + '''+ '' / Orden de compra: ' +  @folioPresupuesto + ''' + '' / No. Empleado: ' +  @empleado + '''+ '' / No. Economico: ' +  @noEco + ''' + '' / VIN: ' + @vin + '''+ '''  + ''' + '' / Placas: ' + @placas + '''
						--WHERE OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '';

					EXECUTE SP_EXECUTESQL @actualizaObs

				END
			ELSE IF (@idOperacion = 14)
				BEGIN
									    
					SELECT @nombreOperacion = PC.descripcion FROM ContratoOperacion CO 
					INNER JOIN ContratoOperacionFacturacion COF ON CO.idContratoOperacion = COF.idContratoOperacion
					INNER JOIN PARTIDAS..Contrato PC ON PC.idContrato = CO.idContrato
					WHERE CO.idOperacion = @idOperacion

					SELECT @taller = P.razonSocial FROM Cotizaciones C 
					INNER JOIN Partidas..Proveedor P ON P.idProveedor = C.idTaller
					WHERE idCotizacion = @idCotizacion

					SELECT @vin = U.vin, @placas = U.placas, @modelo = U.modelo, @marca = M.nombre, @submarca = SM.nombre FROM Cotizaciones C
					INNER JOIN Ordenes O ON O.idOrden = C.idOrden
					INNER JOIN Unidades U ON O.idUnidad = U.idUnidad
					INNER JOIN Partidas..Unidad TU ON TU.idUnidad = U.idTipoUnidad
					INNER JOIN Partidas..SubMarca SM ON SM.idSubMarca = TU.idSubMarca
					INNER JOIN Partidas..Marca M ON M.idMarca = SM.idMarca
					WHERE C.idCotizacion = @idCotizacion

					SELECT @numFact = numFactura FROM facturaCotizacion WHERE idCotizacion = @idCotizacion

					SET @actualizaObs = 'UPDATE dbo.[ADE_ORDSERENC]
					SET OTE_OBSERVACIONES = ''' + @nombreOperacion + '''+ '' //' +  @vin + ''' + '' //' + @taller + '''+ '' //' + @numFact + ''' + '' //' + @noOrden +''' + ''//'+ @marca +''' + '' //'+ @submarca +' '' + '' //' + @modelo + ''' + '' //'+ @placas +'''
					WHERE OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '';

					EXECUTE SP_EXECUTESQL @actualizaObs

					--SET @queryInsertDet = 'INSERT INTO ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET]
					--SELECT 
					--E.OTE_IDENT,
					--MAX(D.OTD_CONSECUTIVO) + 1,
					--''' + @nombreOperacion + '''+ '' //' +  @vin + ''' + '' //' + @taller + '''+ '' //' + @numFact + ' //'' + Cast(E.OTE_ORDENANDRADE as nvarchar(max)) + '' //'+ @marca +''' + '' //'+ @submarca +' '' + '' //' + @modelo + ''' + '' //'+ @placas +''',
					--1,
					--0,
					--0,
					--0,
					--0,
					--0,
					--CONVERT(VARCHAR,GETDATE(),103),
					--CONVERT(VARCHAR,GETDATE(),108),
					--NULL 
					--FROM ' + @server + '.' + @db + '.dbo.[ADE_ORDSERENC] E
					--inner join ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET] D on E.OTE_IDENT = D.OTD_IDENT
					--WHERE D.OTD_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '
					--GROUP BY E.OTE_IDENT,E.OTE_ORDENANDRADE'
			
					--PRINT @queryInsertDet

					--EXECUTE SP_EXECUTESQL @queryInsertDet	
				END 
			ELSE IF(@idOperacion = 6 OR @idOperacion = 12 OR @idOperacion = 7 OR @idOperacion = 8  OR @idOperacion = 18 OR @idOperacion = 20 OR @idOperacion = 5 OR @idOperacion = 32 OR @idOperacion = 25 OR @idOperacion = 26  OR @idOperacion = 23 OR @idOperacion = 38 OR @idOperacion = 13  OR @idOperacion = 41 OR @idOperacion = 30 OR @idOperacion = 44 OR @idOperacion = 36 OR @idOperacion = 46
			OR @idOperacion = 62 OR @idOperacion = 65 OR @idOperacion = 66 OR @idOperacion = 67 OR @idOperacion = 68 OR @idOperacion = 69 OR @idOperacion = 70 OR @idOperacion = 71 OR @idOperacion = 72 OR @idOperacion = 73
			OR @idOperacion = 74 OR @idOperacion = 75 OR @idOperacion = 76 OR @idOperacion = 77 OR @idOperacion = 78 OR @idOperacion = 79 OR @idOperacion = 80 OR @idOperacion = 81 OR @idOperacion = 82 OR @idOperacion = 83 OR @idOperacion = 84
			OR @idOperacion = 86 OR @idOperacion = 85 OR @idOperacion = 87 OR @idOperacion = 88 OR @idOperacion = 89 OR @idOperacion = 90 OR @idOperacion = 91 OR @idOperacion = 92 OR @idOperacion = 93
			OR @idOperacion = 94 OR @idOperacion = 95 OR @idOperacion = 97 OR @idOperacion = 96 OR @idOperacion = 98 OR @idOperacion = 99 OR @idOperacion = 100 OR @idOperacion = 101 OR @idOperacion = 102 OR @idOperacion = 49)
				BEGIN				    

					SELECT @nombreOperacion = PC.descripcion FROM ContratoOperacion CO 
					INNER JOIN ContratoOperacionFacturacion COF ON CO.idContratoOperacion = COF.idContratoOperacion
					INNER JOIN PARTIDAS..Contrato PC ON PC.idContrato = CO.idContrato
					WHERE CO.idOperacion = @idOperacion

					SELECT @taller = P.razonSocial FROM Cotizaciones C 
					INNER JOIN Partidas..Proveedor P ON P.idProveedor = C.idTaller
					WHERE idCotizacion = @idCotizacion

					SELECT @vin = U.vin, @noOrden = O.numeroOrden FROM Cotizaciones C
					INNER JOIN Ordenes O ON O.idOrden = C.idOrden
					INNER JOIN Unidades U ON O.idUnidad = U.idUnidad
					WHERE C.idCotizacion = @idCotizacion

					SELECT @numFact = numFactura FROM facturaCotizacion WHERE idCotizacion = @idCotizacion
					
					SET @actualizaObs = 'UPDATE dbo.[ADE_ORDSERENC]
					SET OTE_OBSERVACIONES = ''' + @nombreOperacion + '''+ '' //' +  @vin + ''' + '' //' + @taller + '''+ '' //' + @numFact + ''' + '' //' + @noOrden +'''
					WHERE OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '';

					EXECUTE SP_EXECUTESQL @actualizaObs
					--SET @queryInsertDet = 'INSERT INTO ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET]
					--SELECT 
					--E.OTE_IDENT,
					--MAX(D.OTD_CONSECUTIVO) + 1,
					--''' + @nombreOperacion + '''+ '' //' +  @vin + ''' + '' //' + @taller + '''+ '' //' + @numFact + ' //'' + Cast(E.OTE_ORDENANDRADE as nvarchar(max)),
					--1,
					--0,
					--0,
					--0,
					--0,
					--0,
					--CONVERT(VARCHAR,GETDATE(),103),
					--CONVERT(VARCHAR,GETDATE(),108),
					--NULL 
					--FROM ' + @server + '.' + @db + '.dbo.[ADE_ORDSERENC] E
					--inner join ' + @server + '.' + @db + '.dbo.[ADE_ORDSERDET] D on E.OTE_IDENT = D.OTD_IDENT
					--WHERE D.OTD_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '
					--GROUP BY E.OTE_IDENT,E.OTE_ORDENANDRADE'
			
					--PRINT @queryInsertDet

					--EXECUTE SP_EXECUTESQL @queryInsertDet	
					
				END
			ELSE IF(@idOperacion = 33 OR @idOperacion = 35 OR @idOperacion = 45)
				BEGIN
					SELECT @noEco = U.numeroEconomico, @noOrden = O.numeroOrden 
					FROM Cotizaciones C
					INNER JOIN Ordenes O ON O.idOrden = C.idOrden
					INNER JOIN Unidades U ON O.idUnidad = U.idUnidad
					WHERE C.idCotizacion = @idCotizacion

					SET @actualizaObs = 'UPDATE dbo.[ADE_ORDSERENC]
					SET OTE_OBSERVACIONES = '' ORDEN: ' + @noOrden + ' ECO:' +  @noEco + '''
					WHERE OTE_IDENT = ' + CAST(@idEncabezado AS NVARCHAR(30)) + '';

					EXECUTE SP_EXECUTESQL @actualizaObs
				END 
		END
END
go

