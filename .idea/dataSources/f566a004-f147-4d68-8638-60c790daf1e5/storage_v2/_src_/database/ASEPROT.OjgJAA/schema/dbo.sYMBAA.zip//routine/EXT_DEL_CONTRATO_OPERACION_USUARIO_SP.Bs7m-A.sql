-- =============================================
-- Author:		Sahirely Yam
-- Create date: 29 12 2017
-- =============================================
CREATE PROCEDURE [dbo].[EXT_DEL_CONTRATO_OPERACION_USUARIO_SP]
	@idContratoOperacionUsuario int
AS
BEGIN
	IF @idContratoOperacionUsuario is not null
		BEGIN
			IF EXISTS(SELECT 1 FROM ContratoOperacionUsuario WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario)
				BEGIN
					DELETE FROM ContratoOperacionUsuario WHERE idContratoOperacionUsuario = @idContratoOperacionUsuario
					SELECT 1 AS respuesta, 'se eliminó la Operación para el usuario exitosamente' mensaje
				END	
			ELSE
				BEGIN
					SELECT 2 AS	respuesta, 'no existe la Operación seleccionada para el Usuario' mensaje
				END
		END
	ELSE
		BEGIN
			SELECT 0 AS respuesta, 'la Operación del Usuario es inválida' mensaje
		END
END
go

