
-- =============================================
CREATE PROCEDURE [Banorte].[UPD_COTIZACIONES]
	@detalle XML,
	@idUsuario int
 AS
 BEGIN
  
 DECLARE
  @idCotizacionDetalle NUMERIC(18,0),
  @costo DECIMAL(18,4),
  @cantidad INT,
  @venta DECIMAL(18,4) = 0,
  @idEstatusPartida INT = 2,

  @idCotizacion NUMERIC(18,0),
  @idPartida NUMERIC(18,0),
  @count int,
  @idAutorizacionCot int,
  @idCotDetalle numeric(18,0)

	declare @tempDetalle as table(idTemp int, idCotizacion NUMERIC(18,0),costo DECIMAL(18,4),
                               cantidad INT, venta DECIMAL(18,4), idPartida NUMERIC(18,0), 
		                       idEstatusPartida INT, precioLista DECIMAL(18,4), diasEntrega int)
	DECLARE @SummaryOfChanges TABLE(idDetalle INT, Accion VARCHAR(20)); 

	INSERT INTO @tempDetalle 
		(idTemp, idCotizacion, costo, cantidad, venta, idPartida, idEstatusPartida, precioLista, diasEntrega)
       SELECT 
	    x.value('idTemp[1]', 'INT') AS idTemp, x.value('idCotizacion[1]', 'NUMERIC(18,0)') AS idCotizacion,
	    x.value('costo[1]', 'DECIMAL(18,4)') AS costo, x.value('cantidad[1]', 'INT') AS cantidad,
		x.value('venta[1]', 'DECIMAL(18,4)') AS venta, x.value('idPartida[1]', 'NUMERIC(18,0)') AS idPartida, 
		x.value('idEstatusPartida[1]', 'INT') AS idEstatusPartida,
		x.value('precioLista[1]', 'DECIMAL(18,4)') AS precioLista,
		x.value('diasEntrega[1]', 'INT') AS diasEntrega
       FROM @detalle.nodes('//cotizacion') detalle(x)	

	SELECT TOP 1 @idCotizacion = idCotizacion FROM @tempDetalle

	select @idAutorizacionCot= idAutorizacionCotizacion from [dbo].[AutorizacionCotizacion] where idCotizacion= @idCotizacion
	

	 SET NOCOUNT ON;  

    MERGE CotizacionDetalle AS target  
    USING @tempDetalle AS source 
    ON (target.idPartida = source.idPartida and target.idCotizacion = source.idCotizacion)  
    WHEN MATCHED THEN   
        UPDATE SET costo = source.costo, venta=source.venta, cantidad=source.cantidad, 
		solicitadasOrg= source.cantidad, diasEntrega = source.diasEntrega
	WHEN NOT MATCHED BY SOURCE and target.idCotizacion = @idCotizacion THEN		
		DELETE
		--DELETE FROM Partidas.dbo.Partida WHERE idPartida=target.idPartida		
	WHEN NOT MATCHED THEN  
		INSERT (idCotizacion, costo, cantidad, venta, idPartida, idEstatusPartida, solicitadasOrg, precioLista, diasEntrega)  
		VALUES (source.idCotizacion, source.costo, source.cantidad, source.venta, source.idPartida, 
		@idEstatusPartida, source.cantidad, source.precioLista, source.diasEntrega)
    OUTPUT Inserted.idCotizacionDetalle, $action INTO @SummaryOfChanges;  

	--delete from Partidas.dbo.Partida where idPartida = (select idPartida from @SummaryOfChanges) and noParte like 'TMP%'
	
	-- Query the results of the table variable.  
	SELECT *  FROM @SummaryOfChanges;  
	
  END

go

grant execute, view definition on Banorte.UPD_COTIZACIONES to DevOps
go

