
CREATE PROCEDURE [dbo].[EXT_INTEGRA_COTIZACION_SP] --31960, '93011,93004', 510, 3
	@idCotizacion INT,
	@idCotizacionDetalle NVARCHAR(max),
	@idUsuario INT,
	@idContratoOperacion INT

AS
BEGIN

DECLARE @idUsuarioOperacion INT
DECLARE @idOrden INT
DECLARE @descripcion NVARCHAR(100)
DECLARE @idSoporte NUMERIC(18,0) = 8

	SELECT @idOrden = idOrden FROM Cotizaciones WHERE idCotizacion = @idCotizacion

	SET @idUsuarioOperacion = (SELECT TOP 1 CO.idUsuario FROM Ordenes O
		JOIN ContratoOperacionUsuario CO ON CO.idContratoOperacion = O.idContratoOperacion
		JOIN ContratoOperacionUsuarioZona COZ ON COZ.idContratoOperacionUsuario = CO.idContratoOperacionUsuario
		JOIN Partidas..Zona Z ON Z.idZona = COZ.idZona AND Z.idZona = O.idZona
	WHERE CO.idUsuario IN(119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150) AND
	O.idOrden = @idOrden AND CO.idContratoOperacion= @idContratoOperacion)

	IF(@idCotizacionDetalle != '0')
		BEGIN
			IF EXISTS(SELECT 1 FROM Cotizaciones WHERE idCotizacion = @idCotizacion)
					BEGIN

					DECLARE @update NVARCHAR(MAX)

						set @update = ' UPDATE CotizacionDetalle
						SET idCotizacion = ' + CONVERT(VARCHAR(MAX), @idCotizacion)+ ' 
						WHERE idCotizacionDetalle IN ('+@idCotizacionDetalle+') '

						EXECUTE SP_EXECUTESQL @update

						SELECT Success = 1, Msg = 'La cotizacion fue acumulada';

					END
				ELSE
					BEGIN
						SELECT Success = 0, Msg = 'La cotizacion no existe';
					END
		END
	ELSE
		BEGIN

			SET @descripcion='Cancela cotizacion por integracion'
			UPDATE Cotizaciones SET idEstatusCotizacion = 4 WHERE idCotizacion = @idCotizacion

			INSERT INTO [dbo].[HistorialEstatusCotizacion]([fechaInicial], [fechaFinal], [idCotizacion], [idUsuario], [idEstatusCotizacion])
			VALUES (GETDATE(), GETDATE(), @idCotizacion, @idUsuarioOperacion, 4)

			INSERT INTO LogSoporte VALUES(@idOrden, @idUsuario, @idContratoOperacion, GETDATE(), @idSoporte, @descripcion, @idCotizacion)

			SELECT Success = 1, Msg = 'La cotizacion fue cancelada';

		END
END
/*
select * from Ordenes where numeroOrden='03-10923-29362'

select * from Cotizaciones where idOrden=30810

select * from CotizacionDetalle where idCotizacion=31960

select * from LogSoporte

update Cotizaciones
set idEstatusCotizacion=1
where idCotizacion=31969

select * from HistorialEstatusCotizacion where idCotizacion=31969

delete from HistorialEstatusCotizacion where idHistorialEstatusCotizacion=62187
*/
go

