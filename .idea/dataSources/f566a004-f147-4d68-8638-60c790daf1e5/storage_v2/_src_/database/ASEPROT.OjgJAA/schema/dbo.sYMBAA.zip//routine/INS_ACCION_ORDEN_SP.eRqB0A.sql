

CREATE PROCEDURE INS_ACCION_ORDEN_SP

  @nombreAccion VARCHAR(50),
  @fechaAccion VARCHAR(50),
  @idUsuario INT,
  @numeroOrden VARCHAR(50),
  @recordatorio INT
AS
BEGIN
  DECLARE @idOrden NUMERIC(18,0), @consecutivoCotizacion INT
  SET @idOrden = (SELECT idOrden FROM Ordenes WHERE numeroOrden = @idOrden )
  INSERT INTO [dbo].[Acciones] VALUES(@nombreAccion,@nombreAccion,@fechaAccion,1,@idUsuario,@idOrden,@recordatorio)

END
go

