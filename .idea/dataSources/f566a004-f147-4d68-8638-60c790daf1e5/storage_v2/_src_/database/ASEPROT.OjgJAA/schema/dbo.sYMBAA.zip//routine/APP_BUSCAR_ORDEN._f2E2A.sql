
-- ==========================================================================================
-- Author:		Alejandro Grijalva Antonio
-- Create date: 11/05/2017
-- Description:	Store para la búsqueda del Número de Orden
-- ==========================================================================================

CREATE PROCEDURE [dbo].[APP_BUSCAR_ORDEN]
    @numeroOrden VARCHAR(MAX)
AS   
BEGIN
	DECLARE @idEstatusOrden NUMERIC(18,0)
	DECLARE @idOrden NUMERIC(18,0)
	DECLARE @idOperacion NUMERIC(18,0)
	
	SET @idEstatusOrden = ( SELECT idEstatusOrden FROM [Ordenes] WHERE numeroOrden = @numeroOrden );
	SET @idOperacion = ( SELECT OPE.idOperacion 
						 FROM [Ordenes]						ORD
						 INNER JOIN [ContratoOperacion]		COP ON ORD.idContratoOperacion = COP.idContratoOperacion
						 INNER JOIN [Operaciones]			OPE ON OPE.idOperacion = COP.idOperacion
						 WHERE numeroOrden = @numeroOrden );
	
	
	IF ( @idEstatusOrden IS NULL )
		BEGIN
			SELECT 0 Success, 'La Orden que busca no se encuentra registrada.' Msg
		END
	ELSE 
		BEGIN
			SET @idOrden = ( SELECT idOrden FROM [Ordenes] WHERE numeroOrden = @numeroOrden );
	
			IF ( @idEstatusOrden = 6 ) -- ( Admin ) -> Término de Trabajo
				BEGIN
					SELECT 
						1 Success,
						'Admin :: Estatus : Termino de Trabajo' Msg,
						@idEstatusOrden idEstatusOrden,
						@idOrden idOrden,
						0 Calificacion,
						@idOperacion Operacion
				END
			ELSE IF ( @idEstatusOrden = 5 ) -- ( Admin ) -> Término de Trabajo
				BEGIN
					SELECT 
						1 Success, 
						6 idEstatusOrden,
						@idOrden idOrden,
						0 Calificacion,
						'Cliente :: Estatus : Entrega.' Msg,
						@idOperacion Operacion
				END
			ELSE IF ( @idEstatusOrden = 7 ) -- ( Cliente ) -> Entrega
				BEGIN
					SELECT 
						1 Success, 
						@idEstatusOrden idEstatusOrden,
						@idOrden idOrden,
						1 Calificacion,
						'Cliente :: Estatus : Entrega.' Msg,
						@idOperacion Operacion
				END
			ELSE
				BEGIN
					SELECT 0 Success, 'No cuenta con los privilegios necesarios para realizar el Token' Msg
				END
		END
END

go

