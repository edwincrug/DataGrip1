--[Banorte].[UPD_COBRANZA_REFACCIONES_SP_V1] 42797, 677, 18, 0, '<pedidos><pedido><pre_idpedidoref>1992</pre_idpedidoref><pre_idcotizacion>2</pre_idcotizacion><pre_pedidobpro>20000</pre_pedidobpro><spe_idsituacionpedido>2</spe_idsituacionpedido></pedido></pedidos>'
CREATE PROCEDURE [Banorte].[UPD_COBRANZA_REFACCIONES_SP_V1] 
	@idOrden NUMERIC(18,0), 		
	@idUsuario  NUMERIC(18,0), 	
	@idContratoOperacion int,
	@cantidadNumCompra int, 
	@xmlPedidoRef XML
AS
BEGIN
	DECLARE @estatusOrden INT =8
	declare @hasFactura numeric
	declare @hasValeI numeric
	declare @hasValeF numeric
	declare @hasDocumentos numeric
	declare @Entregado numeric
	declare @idTipoOrden int 
	declare @tipoOrdenRefT int =10
	declare @tipoOrdenMOT int =11
	declare @idEstatusCobranza int = 8
	declare @idEstatusOrden int

	declare @estatusDocumentos int =0

	select @idTipoOrden=idCatalogoTipoOrdenServicio, @idEstatusOrden= idEstatusOrden from Ordenes where idOrden=@idOrden
	
	IF (@idEstatusOrden < @idEstatusCobranza )
	BEGIN
		update Cotizaciones set idEstatusCotizacion=3 where idOrden=@idOrden and idEstatusCotizacion<> 4
		IF (@idTipoOrden=@tipoOrdenRefT or @idTipoOrden=@tipoOrdenMOT)
		begin 
			EXECUTE [Banorte].[SEL_ESTATUS_AVANCE_MIXTA_FN] @idOrden, @hasFactura output, @hasDocumentos output

			IF (@hasFactura=1 and @hasDocumentos=1)
				select @estatusDocumentos=1
			else 
				select @estatusDocumentos=0
			
			set @Entregado=1 
		end 
		else 
		begin 
			EXECUTE [Banorte].[SEL_ESTATUS_AVANCE_FN] @idOrden, @idContratoOperacion, @cantidadNumCompra, @hasFactura output, @hasValeI output, @hasValeF output
			IF (@hasFactura=1 and @hasValeI>0 and @hasValeF>0 )
				select @estatusDocumentos=1
			else 
				select @estatusDocumentos=0

			EXECUTE [Banorte].[ObtenerStatusDespacho_FN] @idOrden, @xmlPedidoRef, @Entregado output
		end 
			
		--SELECT @hasFactura as hasFactura,  @hasValeI as valeInicial, @hasValeF as valeFinal
		--select @estatusDocumentos, @Entregado

		IF (@estatusDocumentos=1 and @Entregado=1)
		BEGIN	
			IF (@idEstatusOrden <> @idEstatusCobranza)
			BEGIN			
				UPDATE Ordenes SET idEstatusOrden=@idEstatusCobranza WHERE idOrden=@idOrden

				declare @id int =@idEstatusOrden
		
				while (@id <= @idEstatusCobranza)
				begin 
					INSERT INTO [HistorialEstatusOrden] (idOrden, idEstatusOrden, fechaInicial, fechaFinal, idUsuario)
						VALUES (@idOrden, @id,GETDATE(), GETDATE(), @idUsuario)
					
					select @id = @id+1
				end

				select 1 as Estatus, 'Se actualizó la orden correctamente' as descripcion
			END	
			ELSE 
			BEGIN 
				SELECT 0 as Estatus, 'La orden ya se encuentra en cobranza' as descripcion
			END 			
	END
	ELSE
	BEGIN
		select -1 as Estatus, 'Falta evidencia o no se han entregado pedidos' as descripcion
	END

	END
	ELSE
	BEGIN
		select 1 as Estatus, 'Se actualizó la orden correctamente' as descripcion
	END
			
END



go

grant execute, view definition on Banorte.UPD_COBRANZA_REFACCIONES_SP_V1 to DevOps
go

