
-- EXEC [SEL_CORREO_UTILIDAD_SP] 484, 137, 600
-- EXEC [dbo].[SEL_CORREO_UTILIDAD_SOPORTE_SP] '01-1910093-956', 1
CREATE PROCEDURE [dbo].[SEL_CORREO_UTILIDAD_SOPORTE_SP]
	@numOrden nvarchar(50),
	@idContratoOperacion NUMERIC(18,0)
	

AS
BEGIN


declare @idUsuario int
declare @idOrden int
declare @idCotizacion int




set @idUsuario = (select TOP 1 CO.idUsuario from Ordenes O
    JOIN ContratoOperacionUsuario CO ON CO.idContratoOperacion = O.idContratoOperacion
    JOIN ContratoOperacionUsuarioZona COZ ON COZ.idContratoOperacionUsuario = CO.idContratoOperacionUsuario
    --JOIN Usuarios U ON U.idUsuario = CO.idUsuario
    JOIN Partidas..Zona Z ON Z.idZona = COZ.idZona AND Z.idZona = O.idZona
    WHERE CO.idUsuario IN(119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150) AND
    O.numeroOrden = @numOrden AND CO.idContratoOperacion= @idContratoOperacion)


select @idOrden = idOrden
from ordenes
where numeroOrden = @numOrden


select 
   top 1
       @idCotizacion = idCotizacion
  from Cotizaciones
 where idOrden = @idOrden
   and idEstatusCotizacion = 3
 order by idCotizacion desc

--select @idUsuario
--select @idOrden
--select @idCotizacion

exec [dbo].[SEL_CORREO_UTILIDAD_SP]  @idOrden, @idUsuario, @idCotizacion





END

/*  SELECT *
	FROM Ordenes O
	JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
	JOIN Operaciones OS ON OS.idOperacion = CO.idOperacion
	JOIN Cotizaciones C ON C.idOrden = O.idOrden
	JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
	JOIN [Partidas].[dbo].[ProveedorPartida] PP ON PP.idPartida = CD.idPartida
	JOIN [Partidas].[dbo].[ContratoPartida] CP ON CP.idPartida = CD.idPartida
	JOIN [Partidas].[dbo].[Partida] P ON P.idPartida = CD.idPartida
	WHERE C.idCotizacion = 123 */


go

