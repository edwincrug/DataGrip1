-- =============================================
-- Author: YJH
-- Create date: 2018/12/26
-- Description: Obtiene las cotizaciones sisre relacionadas a una orden 
-- EXEC Banorte.SEL_COTIZACION_SISRE 42846
-- =============================================
CREATE PROCEDURE [Banorte].[SEL_COTIZACION_SISRE] 
	@idOrden INT = 0
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
	DECLARE @values nvarchar(max) = '';

	select @values = COALESCE(@values + ',', '') +  CAST(idCotizacion AS varchar(max)) from
	RefaccionMultiMarca.Relacion.SiniestroOrdenCotizacion
	where idOrden = @idOrden

	select @values= STUFF(@values, 1, 1, '')
	
	select @values as cotizaciones

	END TRY
	BEGIN CATCH		
		SELECT ERROR_NUMBER() AS Number,
			ERROR_SEVERITY() AS Severity,
			ERROR_STATE() AS [State],
			ERROR_PROCEDURE() AS [Procedure],
			ERROR_LINE() AS Line,
			ERROR_MESSAGE() AS [Message]
	END CATCH

    SET NOCOUNT OFF;
END
go

grant execute, view definition on Banorte.SEL_COTIZACION_SISRE to DevOps
go

