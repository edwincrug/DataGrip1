-- ==========================================================================================
-- DATE:   04/10/2016
-- DESC:   Modificacion al Store que CATALOGOS DE MODULO DE LEVANTAMIENTO POR OPERACION
-- [SEL_CAT_MOD_LEVANTAMIENTO_DETALLES_SP] '1,2,3,4,5,6,7,8,9,10,11,12', 15, 5212
-- ==========================================================================================
CREATE PROCEDURE [dbo].[SEL_CAT_MOD_LEVANTAMIENTO_DETALLES_SP] (
	@idsCatalogoModuloLevantamiento varchar(100),
	@idOperacion int,
	@idUnidad int 
)
as
begin
	DECLARE @Ids_Cat_MLevantamiento table(Id numeric(18,0))
	DECLARE @rutaImagen NVARCHAR(100) = 'http://189.204.141.193:5101'
	DECLARE @idTipoUnidad INT
	--SELECT @idUnidad=idUnidad, @idContratooperacion=idContratooperacion, @numeroOrden= numeroOrden
	--FROM Ordenes WHERE idOrden=@idOrden

	SELECT @idTipoUnidad=UP.idTipoUnidad
		FROM Unidades U
		JOIN Partidas..Unidad UP ON UP.idUnidad = U.idTipoUnidad
		WHERE U.idUnidad=@idUnidad

	IF NOT EXISTS(SELECT * FROM TipoUnidadRecepcion WHERE idTipounidad = @idTipoUnidad) SET @idTipoUnidad = 999

	set @idsCatalogoModuloLevantamiento = @idsCatalogoModuloLevantamiento+',';
	with cte as
	(
		select SUBSTRING(@idsCatalogoModuloLevantamiento,1,charindex(',',@idsCatalogoModuloLevantamiento,1)-1) as val, SUBSTRING(@idsCatalogoModuloLevantamiento,charindex(',',@idsCatalogoModuloLevantamiento,1)+1,len(@idsCatalogoModuloLevantamiento)) as rem 
		UNION ALL
		select SUBSTRING(a.rem,1,charindex(',',a.rem,1)-1)as val, SUBSTRING(a.rem,charindex(',',a.rem,1)+1,len(A.rem)) 
		from cte a where LEN(a.rem)>=1
	) insert into @Ids_Cat_MLevantamiento select val from cte



	SELECT 
		idCatalogoModuloLevantamientoDetalle,
		idCatalogoModuloLevantamiento, 
		nombreModuloLevantamientoDetalle,
		CASE 
			WHEN idCatalogoModuloLevantamientoDetalle = 31 THEN (SELECT  @rutaImagen +  derecha FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad)
			WHEN idCatalogoModuloLevantamientoDetalle = 32 THEN (SELECT  @rutaImagen +  frente FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad)
			WHEN idCatalogoModuloLevantamientoDetalle = 33 THEN (SELECT  @rutaImagen +  arriba FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad)
			WHEN idCatalogoModuloLevantamientoDetalle = 34 THEN (SELECT  @rutaImagen +  atras FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad)
			WHEN idCatalogoModuloLevantamientoDetalle = 35 THEN (SELECT  @rutaImagen +  izquierda FROM TipoUnidadRecepcion WHERE idtipounidad  = @idTipoUnidad)
			ELSE rutaImagen
		END AS rutaImagen,
		consecutivo
	FROM 
		CatalogoModuloLevantamientoDetalle 
	WHERE idCatalogoModuloLevantamiento IN 
	(SELECT Id from @Ids_Cat_MLevantamiento)
	
end
go

