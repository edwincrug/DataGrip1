-- =============================================
-- Author:		Sahirely Yam
-- Create date: 24 10 2017
-- Description:	sp para regresar las ordenes del estatus cancelado a el estatus anterior
-- =============================================
CREATE PROCEDURE [dbo].[EXT_RESUCITADOR_DE_ORDENES_SP]
	@numeroOrden varchar(max)
AS
BEGIN

	declare @idOrden numeric(18,0), @estatus int, @idHistorial int

	select top 1 @idOrden = O.idOrden, @estatus = HEO.idEstatusOrden, @idHistorial = HEO.idHistorialEstatusOrden
	from Ordenes O
	inner join HistorialEstatusOrden HEO on HEO.idOrden = O.idOrden
	where numeroOrden = @numeroOrden and HEO.idEstatusOrden not in (13)
	order by HEO.idEstatusOrden desc

	if (@idOrden is null)
		begin
			print 'No se encontró el número de orden: ' + @numeroOrden
		end
	else
		begin
			if (@estatus is null)
				begin
					print 'No se puede actualizar el estatus de la orden por que no se recuperó el último estatus activo'
				end
			else
				begin
				
					print 'se actualizará el estatus de la orden ' + @numeroOrden + ' a : ' + convert(varchar(2), @estatus)
					update Ordenes set idEstatusOrden = @estatus where idOrden = @idOrden

					print 'se actualizará el la fecha final del nuevo estatus de la orden: ' + @numeroOrden
					update HistorialEstatusOrden set fechaFinal = null where idHistorialEstatusOrden = @idHistorial

					print 'se eliminará el estatus anterior de cancelado de la orden ' + @numeroOrden
					delete from HistorialEstatusOrden where idOrden = @idOrden and idEstatusOrden = 13

					IF (@estatus >= 6)
						BEGIN
							print 'se actualizará el presupuesto orden'
							execute [UPD_REGENERA_PRESUPUESTO_ORDEN_SP] @numeroOrden
						END

					DECLARE @idCotizacion numeric(18,0)

					DECLARE cotizaciones_cursor CURSOR FOR  
							select idCotizacion
							from Cotizaciones C 
							where C.idOrden = @idOrden;  

					OPEN cotizaciones_cursor;  

					FETCH NEXT FROM cotizaciones_cursor  
					INTO @idCotizacion;  
 
					WHILE @@FETCH_STATUS = 0  
						BEGIN  

							IF exists (select 1 from Cotizaciones where idPreorden = @idCotizacion)
								BEGIN
									print 'se actualizará el estatus de la preorden: ' + convert(varchar(max), @idCotizacion)
									update Cotizaciones set idEstatusCotizacion = 5 where idCotizacion = @idCotizacion
								END
							ELSE
								BEGIN
									IF (@estatus > 4)
										BEGIN
											--Cuando la orden ya fue Aprobada

											print 'se actualizará el estatus de las partidas de la cotización: ' + + convert(varchar(max), @idCotizacion) + ' a 2'
											update CotizacionDetalle set idEstatusPartida = 2 where idCotizacion = @idCotizacion

											print 'se actualizará el estatus de la cotización: ' + convert(varchar(max), @idCotizacion) + ' a 3'
											update Cotizaciones set idEstatusCotizacion = 3 where idCotizacion = @idCotizacion

											print 'se reestablecerá el historial de la cotización: ' + convert(varchar(max), @idCotizacion)
											delete from HistorialEstatusCotizacion where idCotizacion = @idCotizacion and idEstatusCotizacion not in (1)
										
											if ((select fechaFinal from HistorialEstatusCotizacion where idCotizacion = @idCotizacion and idEstatusCotizacion = 1)  is null)
												begin
													print 'se actualizará la fecha final del estatus 1'
													update HistorialEstatusCotizacion set fechaFinal = fechaInicial where idCotizacion = @idCotizacion and idEstatusCotizacion = 1
												end

											insert into HistorialEstatusCotizacion
											select HEC.fechaFinal, HEC.fechaFinal, HEC.idCotizacion, U.idUsuario, EC.idEstatusCotizacion
											from HistorialEstatusCotizacion HEC
											cross join EstatusCotizaciones EC 
											cross join Usuarios U
											where EC.idEstatusCotizacion not in (1,4,5)
											and  HEC.idCotizacion = @idCotizacion
											and U.nombreUsuario = 'usuario.soporte'

										END
									ELSE
										BEGIN
											--Cuando la orden no ha sido Aprobada

											print 'se actualizará el estatus de las partidas de la cotización: ' + convert(varchar(max), @idCotizacion) + ' a 1'
											update CotizacionDetalle set idEstatusPartida = 1 where idCotizacion = @idCotizacion

											print 'se actualizará el estatus de la cotización: ' + convert(varchar(max), @idCotizacion) + ' a 1'
											update Cotizaciones set idEstatusCotizacion = 1 where idCotizacion = @idCotizacion

											print 'se reestablecerá el historial de la cotización: ' + convert(varchar(max), @idCotizacion)
											delete from HistorialEstatusCotizacion where idCotizacion = @idCotizacion and idEstatusCotizacion not in (1)

										END
								END

							FETCH NEXT FROM cotizaciones_cursor  
							INTO @idCotizacion;  
 
						END  

					CLOSE cotizaciones_cursor;  
					DEALLOCATE cotizaciones_cursor;  

				end
		end

END
go

