
-- =============================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 30/05/2017
-- [SEL_OPERACIONES_USUARIO_LOGIN_SP] 538
-- [SEL_OPERACIONES_USUARIO_LOGIN_SP] 2346
-- =============================================
CREATE PROCEDURE [dbo].[SEL_OPERACIONES_USUARIO_LOGIN_SP] 
	@idUsuario numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

				DECLARE @Users TABLE  (IDu INT IDENTITY(1,1)
									,[idContratoOperacion] int
									,[idOperacion] int
									,[idCatalogoTipoUsuarios] int
									,[manejoUtilidad] int
									,[porcentajeUtilidad] decimal(18,4)
									,[presupuesto] int
									,[geolocalizacion] int
									,[idEstatusOperacion] int
									,[tiempoAsignado] int
									,[idRol] int
									,[nombreRol] varchar(max)
									,nombreCompleto varchar(max)
									,versionSystem int
									,[idContrato] int
									,formaPago varchar(max)
									,verificacionVehicular int
									,comentarioCotizacion int
									,sustituto int
									,codigoCita int
									,validacionPorToken int
									,levantamientoInicial bit
									,apariencia int
									,documentoCobranza int
									,preAprobacion bit
									,usuarioValidador int
									,verGPS int
									,formatoTesoreria bit
									,preCancelaOrden int
									,cancelaOrden int
									,cancelaCotizacion int
									,modificaTaller int
									,panelSoporte int
									)


				INSERT INTO @Users SELECT ISNULL(ContOpUs.[idContratoOperacion],0)
						,ISNULL(ContOpe.[idOperacion],0)
						,ISNULL([idCatalogoTipoUsuarios], 0)
						,ISNULL(Ope.[manejoUtilidad],0)
						,ISNULL(Ope.[porcentajeUtilidad],0)
						,ISNULL(Ope.[presupuesto],0)
						,ISNULL(Ope.[geolocalizacion],0)
						,ISNULL(Ope.[idEstatusOperacion],1)
						,ISNULL(Ope.[tiempoAsignado],0)
						,CASE Usuarios.idCatalogoTipoUsuarios WHEN 5 THEN 5 ELSE ISNULL(ContOpUs.[idCatalogoRol],0) END 
						,CASE Usuarios.idCatalogoTipoUsuarios WHEN 5 THEN 'Configurador' ELSE ISNULL(CatRol.[nombreCatalogoRol],'') END
						,nombreCompleto
						,ISNULL(COUV.idCatalogoVersion,1) AS versionSystem
						,ISNULL(ContOpe.idContrato,0)
						,ISNULL(Ope.formaPago,'')
						,ISNULL(Ope.verificacionVehicular,0)
						,ISNULL(Ope.comentarioCotizacion,0)
						,ISNULL(Ope.sustituto,0)
						,ISNULL(Ope.codigoCita,0)
						,ISNULL(( SELECT validacionPorToken 
									FROM ContratoOperacionFacturacion COF
									INNER JOIN ContratoOperacion CO ON COF.idContratoOperacion = CO.idContratoOperacion
									WHERE idOperacion = ContOpe.idOperacion ), 0)
						,ISNULL(Ope.levantamientoInicial, 0)
						,ISNULL(Ope.apariencia, 1)
						,ISNULL(Ope.documentoCobranza, 0)
						,ISNULL(Ope.preAprobacion, 0)
						,ISNULL(COUL.idCatalogoLiberacion,0)
						--,(IF (Ope.geolocalizacion=1)--ContOpUs.verGPS
						,(SELECT CASE WHEN 
						               geolocalizacion = 0 
									  THEN 0 
									  ELSE ContOpUs.verGPS END AS verGPS )--FROM Operaciones where idOperacion=Ope.idOperacion)
						,Ope.formatoTesoreria
						,ISNULL(PreCanOrd.Estatus,0)
						,ISNULL(CanOrd.Estatus,0)
						,ISNULL(CanCot.Estatus,0)
						,ISNULL(ActPro.Estatus,0)
						,ISNULL(Pan.Estatus,0)
					FROM [dbo].[Usuarios] 
					LEFT JOIN [dbo].[ContratoOperacionUsuario] AS ContOpUs ON ContOpUs.idUsuario = Usuarios.idUsuario
					LEFT JOIN [dbo].[ContratoOperacionUsuarioVersion] COUV ON COUV.idContratoOperacionUsuario = ContOpUs.idContratoOperacionUsuario
					LEFT JOIN [dbo].[ContratoOperacionUsuarioLiberacion] COUL ON COUL.idContratoOperacionUsuario = ContOpUs.idContratoOperacionUsuario
					LEFT JOIN [dbo].[ContratoOperacion] AS ContOpe ON ContOpe.idContratoOperacion = ContOpUs.idContratoOperacion
					LEFT JOIN [dbo].[Operaciones] AS Ope ON Ope.idOperacion = ContOpe.idOperacion
					LEFT JOIN [dbo].[CatalogoRoles] AS CatRol ON CatRol.idCatalogoRol = ContOpUs.idCatalogoRol
					LEFT JOIN [dbo].[ParametrosGeneralUsuario] AS PreCanOrd ON PreCanOrd.IdUsuario = ContOpUs.idUsuario AND PreCanOrd.IdOperacion = Ope.idOperacion AND PreCanOrd.IdParametroGeneral IN(19) AND PreCanOrd.Estatus = 1 --parametro precancela ordenes
					LEFT JOIN [dbo].[ParametrosGeneralUsuario] AS CanOrd ON CanOrd.IdUsuario = ContOpUs.idUsuario AND CanOrd.IdOperacion = Ope.idOperacion AND CanOrd.IdParametroGeneral IN(20) AND CanOrd.Estatus = 1 --parametro cancela ordenes
					LEFT JOIN [dbo].[ParametrosGeneralUsuario] AS CanCot ON CanCot.IdUsuario = ContOpUs.idUsuario AND CanCot.IdOperacion = Ope.idOperacion AND CanCot.IdParametroGeneral IN(22) AND CanCot.Estatus = 1 --parametro cancela cotizacion
					LEFT JOIN [dbo].[ParametrosGeneralUsuario] AS ActPro ON ActPro.IdUsuario = ContOpUs.idUsuario AND ActPro.IdOperacion = Ope.idOperacion AND ActPro.IdParametroGeneral IN(24) AND ActPro.Estatus = 1 --parametro modificación taller
					LEFT JOIN [dbo].[ParametrosGeneralUsuario] AS Pan ON Pan.IdUsuario = ContOpUs.idUsuario AND Pan.IdOperacion = Ope.idOperacion AND Pan.IdParametroGeneral IN(23) AND Pan.Estatus = 1 --parametro accesoa panel de control
					WHERE Usuarios.idUsuario = @idUsuario

					SELECT US.*
							,ISNULL(LIC.idLicitacion,0) AS idLicitacion
							,ISNULL(LIC.nombre,'') AS nombreLicitacion
							,ISNULL(CON.idContrato,0) AS idContrato
							,ISNULL(CL.razonSocial,'') AS razonSocial
							,ISNULL(CON.fechaInicio,'') AS fechaInicio
							,ISNULL(CON.fechaFin, '') AS fechafin
							,ISNULL(CON.descripcion, '')  AS nombreOperacion
							,ISNULL(US.validacionPorToken, 0)  AS validacionPorToken
							,([dbo].[GET_USUARIO_RESTRICCION_FN](@idUsuario ,US.idOperacion)) AS usuarioRestriccion
					FROM @Users as US 
					LEFT JOIN .[Partidas].dbo.Contrato CON ON CON.idContrato = US.idContrato
					LEFT JOIN .[Partidas].dbo.Licitacion LIC ON CON.idLicitacion = LIC.idLicitacion
					LEFT JOIN .[Partidas].dbo.cliente CL ON CL.idCliente = LIC.idCliente 
					WHERE idEstatusOperacion = 1 order by nombreOperacion

END
go

