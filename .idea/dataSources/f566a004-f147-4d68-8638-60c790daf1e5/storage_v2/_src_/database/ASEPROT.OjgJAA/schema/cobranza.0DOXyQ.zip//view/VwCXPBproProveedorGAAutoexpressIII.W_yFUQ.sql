



CREATE VIEW [cobranza].[VwCXPBproProveedorGAAutoexpressIII]
AS
	SELECT 
	GA.CCP_IDPERSONA as idProveedor, 
	GA.Nombre as razonSocial, 
	SUM(GA.IMPORTE) as importe, 
	SUM(GA.SALDO) as saldo 
	FROM [cobranza].[VwInvoiceProvSaldoBPRO_GAAutoexpressIII] GA 
	WHERE GA.MODULO = 'CXP' --AND GA.CCP_IDPERSONA NOT IN(1)
	GROUP BY GA.CCP_IDPERSONA, GA.Nombre

go

