
create FUNCTION  [dbo].[GET_TRASPASO_PRESUPUESTO_FN]
(	
	@idPresupuesto  INT,
	 @esOrigen BIT
)
RETURNS numeric(18,4)

AS
	BEGIN
	DECLARE @monto numeric(18,4) =0
	
	
	IF(@esOrigen = 1)
	BEGIN
			IF EXISTS(select monto from TraspasoPresupuesto where idPresupuestoOrigen=@idPresupuesto)
				BEGIN
					SELECT @monto= monto from TraspasoPresupuesto where idPresupuestoOrigen=@idPresupuesto		
				END
				ELSE
				BEGIN
					SET @monto = 0
				END
	END
	ELSE
		BEGIN
			IF EXISTS(select monto from TraspasoPresupuesto where idPresupuestoDestino=@idPresupuesto)
				BEGIN
					SELECT @monto=monto from TraspasoPresupuesto where idPresupuestoDestino=@idPresupuesto			
				END
				ELSE
				BEGIN
					SET @monto = 0
				END
	END

	return @monto

END

go

