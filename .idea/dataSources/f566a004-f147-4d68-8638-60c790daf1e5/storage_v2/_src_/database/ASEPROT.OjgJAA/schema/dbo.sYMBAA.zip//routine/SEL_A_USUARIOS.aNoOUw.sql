
-- =============================================
-- Author:		<Lisandro Martínez>
-- Create date: <13/08/2018>
-- Description:	<SP para obtener los usuarios a migrar a seguridad>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_A_USUARIOS]
AS
BEGIN
	SELECT 
		U.idUsuario,
		U.nombreUsuario,
		U.contrasenia,
		U.nombreCompleto,
		ISNULL(U.correoElectronico, '')
	FROM Usuarios U
	order by idUsuario
END
go

