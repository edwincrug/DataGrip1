-- =============================================
-- Create date: 22/05/2017
-- Description:	Inserta el detalle de un modulo default
-- [INS_DETALLE_APROBACION_MONTO_SP]
-- =============================================
 CREATE PROCEDURE [dbo].[INS_DETALLE_APROBACION_MONTO_SP]
	@idOperacionContrato NUMERIC(18, 0),
	@montoDe NUMERIC(18, 2),
	@montoA NUMERIC(18, 2),
	@montoMax NUMERIC(18, 2),
	@nivel NUMERIC(18, 0)
AS
BEGIN
	DECLARE @OperacionContrato INT

	IF NOT EXISTS (SELECT 1 FROM DetalleOperacionAprobacionMonto WHERE idOperacionContrato=@idOperacionContrato AND nivel = @nivel) 
			BEGIN
				INSERT INTO DetalleOperacionAprobacionMonto
					 VALUES(@idOperacionContrato,@montoDe,@montoA, @montoMax, @nivel)

				IF not Exists (select * from OperacionAprobacion where idOperacionContrato = @idOperacionContrato)
					begin
						INSERT INTO [dbo].[OperacionAprobacion]
										   ([idOperacionContrato]
										   ,[idCatalogoTipo])
									 VALUES
										   (@idOperacionContrato
										   ,1)
					end
				else
					begin
						UPDATE [dbo].[OperacionAprobacion]
							   SET [idCatalogoTipo] = 1
							 WHERE idOperacionContrato = @idOperacionContrato
					end
				
				SET @OperacionContrato = 1
			END
		ELSE
			BEGIN
				UPDATE DetalleOperacionAprobacionMonto 
					SET montoA = @montoA, montoDe=@montoDe, montoMax = @montoMax 
					WHERE nivel = @nivel AND idOperacionContrato = @idOperacionContrato
					 
				SET @OperacionContrato = 2
			END
	SELECT @OperacionContrato
	--select * from [dbo].[DetalleOperacionAprobacionMonto]
	--select * from [dbo].[DetalleOperacionAprobacionPartida]
		
END


go

