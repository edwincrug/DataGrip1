
-- ==========================================================================================
-- Author:		Jose Armando Garcia Arroyo
-- Create date: 15/07/2020
-- ==========================================================================================
-- [dbo].[SEL_PROVEEDOR_PERMISO_NUEVACITA_SP] 74515, 988
CREATE PROC [dbo].[SEL_PROVEEDOR_PERMISO_NUEVACITA_SP]
@idUsuario numeric(18,0)

AS
BEGIN

SELECT COUNT(*) AS Aplica FROM ContratoOperacionUsuarioProveedor COUP
WHERE COUP.idProveedor IN(
SELECT idProveedor FROM [vwProveedoresNuevaCita]
)
AND COUP.idContratoOperacionUsuario IN(
SELECT ContratoOperacionUsuario.idContratoOperacionUsuario FROM ContratoOperacionUsuario WHERE IdUsuario=@idUsuario
)

END
go

