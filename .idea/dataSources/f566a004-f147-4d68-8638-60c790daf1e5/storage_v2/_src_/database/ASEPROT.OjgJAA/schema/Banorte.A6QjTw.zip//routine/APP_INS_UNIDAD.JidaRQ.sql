/*
	Fecha			Autor			Descripción
	18-May-2018		Jose Armando	Se crea el SP que Registra un usuario
	21-May-2018		José Etmanuel	Agrego Bitácora
	22-May-2018		José Etmanuel	Agrago validaciones e inserción de relación
									Agrego Póliza
	27-Jun-2018     Jesús Santibañez Se agregan parametros para la inserción 
	27-Jun-2018     Jesús Santibañez Se RESPONDE IGUAL QUE EL LOGIN
	14-Ago-2018		José Etmanuel	Agrago variable de parametros para idOperacion

	EXEC [Banorte].[APP_INS_UNIDAD] 'imagenT','mi cocher','1234','TJHKS3D63752085','T3dKK3','105'
*/

 CREATE PROCEDURE [Banorte].[APP_INS_UNIDAD]
	@idUsuario INT,
	@nombreFisico nvarchar(max) = null,
	@alias NVARCHAR (max),
	@poliza varchar(100) = null,
	@vin NVARCHAR(50),
	@placas NVARCHAR(50),
	@idZona INT ='739', --302 desarrollo -- 739 produccion
	@combustible NVARCHAR(50) = 'GASOLINA',
	@tipoUnidad INT = '64',	--17 desarrollo 64 produccion
	@descripcion varchar(max) = ''
AS
BEGIN
	DECLARE @idUnidad		INT,
			@idPoliza		int = 0,
			@modelo			VARCHAR(10),
			@nombreUsuario	varchar(100), 
			@contrasenia	varchar(100)	
	IF(@poliza = 'null')
	BEGIN
		SET @poliza = NULL
	END	
	SELECT  @nombreUsuario = nombreUsuario, @contrasenia = contrasenia FROM Usuarios WHERE idUsuario =@idUsuario

	SET @modelo = (SELECT modelyear FROM [RefaccionMultiMarca].[Catalogo].[VinModelYear] WHERE Vin10=LEFT(SUBSTRING(@vin,10,10),1))

	if exists ( select  * from Unidades where vin = @vin)
	begin
		if exists ( select idUnidad from Unidades where vin = @vin and idTipoUnidad =@tipoUnidad)
		begin
			SET @idUnidad =  (select idUnidad from Unidades where vin = @vin)

			if exists (select * from usuarioUnidadContratoOperacion where idUsuario = @idUsuario and idUnidad = @idUnidad)
			begin
				SELECT @idUnidad AS idUnidad, 0 as status, 'Ya tienes registrada la unidad' as msg
			end 
			else
			begin

				EXEC [ASEPROT].[Mobile].Ins_Desasignado_Sp @idUnidad,@idUsuario
				
				insert into [dbo].[usuarioUnidadContratoOperacion]
				values(@idUsuario,@idUnidad,17) 

				update Unidades set
					descripcion = @alias
					,noPoliza = @poliza
					,placas = @placas
					,frente = @nombreFisico
				where idUnidad = @idUnidad

				--Inserta la poliza

				EXEC [Mobile].[Add_Poliza_Sp] @idUnidad, @poliza

				--EXEC [Banorte].[VALIDA_LOGIN] @nombreUsuario, @contrasenia

				SELECT @idUnidad AS idUnidad, 2 as status, 'La unidad ya existe, se mostrara la información ya insertada' as msg

				Select u.[idUnidad]
					,u.[descripcion] alias
					--,u.[noPoliza] noPoliza
					,p.[numero] noPoliza
					,u.[vin] serie
					,u.[placas]
					,u.[frente] foto 
				from [dbo].[Unidades] u 
				LEFT JOIN (SELECT id, numero, estatus, idUnidad FROM [Mobile].[Poliza] WHERE estatus = 1) p
				ON u.idUnidad = p.idUnidad
				--LEFT JOIN [Mobile].[Poliza] p ON u.idUnidad = p.idUnidad 
				where u.idUnidad = @idUnidad

			end

			if exists (select * from usuarioUnidadContratoOperacion where idUsuario <> @idUsuario and idUnidad = @idUnidad)
			begin
				delete usuarioUnidadContratoOperacion where idUsuario <> @idUsuario and idUnidad = @idUnidad
			end
		end
		else
		begin
			SELECT @idUnidad AS idUnidad, 0 as status, 'La unidad ya existe en otra flotilla.' as msg
		end
	end
	else
	begin
		DECLARE @idOperacion INT = CAST((select top 1 [Valor] FROM [Banorte].[Parametros] WHERE Id = 1) AS INT);
		INSERT INTO [Unidades] (
			[vin]
			,[placas]
			,[idZona]
			,[combustible]
			,idTipoUnidad
			,modelo
			,noPoliza
			,descripcion
			,sustituto
			,idOperacion
			,fecha
			,frente
		)
		VALUES (
			@vin
			,@placas
			,@idZona
			,@combustible
			,@tipoUnidad
			,@modelo
			,@poliza
			,@alias
			,0
			,@idOperacion
			,getdate()
			,@nombreFisico
		)
		SET @idUnidad = @@IDENTITY 

		UPDATE [Unidades]
			SET [numeroEconomico] = @idUnidad
			WHERE  idUnidad = @idUnidad;

		insert into [dbo].[usuarioUnidadContratoOperacion]
			values(@idUsuario,@idUnidad,@idOperacion);

		--inserta la poliza
		
		EXEC [Mobile].[Add_Poliza_Sp] @idUnidad, @poliza

		INSERT INTO [Flotillas].[dbo].[LicitacionUnidad]([vin], [idLicitacion], [estatus])
                VALUES(@vin, 30, 'En Proceso'); -- Para banorte es la 22 en PRUEBAS, 30 EN PROD
			
		--EXEC [Banorte].[VALIDA_LOGIN] @nombreUsuario, @contrasenia

		SELECT @idUnidad AS idUnidad, 1 as status, 'La unidad se agregó de forma correcta' as msg

				Select u.[idUnidad]
					,u.[descripcion] alias
					--,u.[noPoliza] noPoliza
					,p.[numero] noPoliza
					,u.[vin] serie
					,u.[placas]
					,u.[frente] foto 
				from [dbo].[Unidades] u 
				LEFT JOIN (SELECT id, numero, estatus, idUnidad FROM [Mobile].[Poliza] WHERE estatus = 1) p
				ON u.idUnidad = p.idUnidad
				--LEFT JOIN [Mobile].[Poliza] p ON u.idUnidad = p.idUnidad 
				where u.idUnidad = @idUnidad
				
	end
END
go

grant execute, view definition on Banorte.APP_INS_UNIDAD to DevOps
go

