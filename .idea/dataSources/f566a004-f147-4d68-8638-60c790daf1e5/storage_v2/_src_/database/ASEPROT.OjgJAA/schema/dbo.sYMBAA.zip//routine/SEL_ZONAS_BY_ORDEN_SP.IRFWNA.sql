-- =============================================
-- Author:		Sahirely Yam
-- Create date: 21 08 2017
-- =============================================
create PROCEDURE [dbo].[SEL_ZONAS_BY_ORDEN_SP] 
	@idOrden int
AS
BEGIN
	SET NOCOUNT ON;

	declare @idPadre numeric(18,0), @idZona numeric(18,0)
	declare @Zonas table(idZona numeric(18,0), nombreZona varchar(max), etiqueta varchar(max), orden numeric(18,0))

	select @idZona = Z.idZona, @idPadre = idPadre from ordenes O inner join Partidas..Zona Z on Z.idZona = O.idZona where idOrden = @idOrden

	WHILE @idZona <> 0
	   BEGIN
			insert @Zonas
			select idZona, Z.nombre, NZ.etiqueta, NZ.orden
			from Partidas..Zona Z
			inner join Partidas..NivelZona NZ on Z.idNivelZona = NZ.idNivelZona and Z.idZona = @idZona

			set @idZona = @idPadre
			select @idPadre = idPadre from Partidas..Zona where idZona = @idZona
	   END

	select * from @Zonas ORDER BY orden
END
go

