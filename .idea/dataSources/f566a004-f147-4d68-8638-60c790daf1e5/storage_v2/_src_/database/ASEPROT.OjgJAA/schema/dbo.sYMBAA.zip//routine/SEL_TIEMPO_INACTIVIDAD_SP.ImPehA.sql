-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 19/05/2017
-- Description:	Obtiene los contratos de la BD.Partidas que no estan ligados con una operación
-- SEL_CONTRATOS_SP 5
-- =============================================
 create PROCEDURE [dbo].[SEL_TIEMPO_INACTIVIDAD_SP]

AS
BEGIN
	SELECT * FROM TiempoInactividad
END


go

