

/*
	Fecha			Autor			Descripción
	21-May-2018		José Etmanuel	Se crea el SP que muestra las unidades de un usuario
	22-May-2018		José Etmanuel	Agrego Póliza y descripcion
	23-May-2018		José Etmanuel	Agrego marca

	-- Pruebas
	[Banorte].[APP_CITAS_GET_UNIDADES] 715
*/
CREATE proc [Banorte].[APP_CITAS_GET_UNIDADES]
@idUsuario int=0
as
begin

	declare @vin varchar(max) = (select top 1 vin from Unidades as uni inner join [dbo].[usuarioUnidadContratoOperacion] as rel on rel.[idUnidad] = uni.[idUnidad] where rel.idUsuario = @idUsuario)
	create table #marca ( id int, vin3 varchar(3),marca varchar(max), idmarca int, pais varchar(max), modelyear varchar(4), Modelo varchar(max))
	insert into #marca 
		EXEC [RefaccionMultiMarca].[Catalogo].[SEL_MarcaVin_SP] @vin 

	
	select 
		uni.[idUnidad]
      ,[numeroEconomico]
      ,[vin]
      ,[gps]
      ,[idTipoUnidad]
      ,[idOperacion]
      ,[placas]
      ,[idZona]
      ,[modelo]
      ,[combustible]
      ,uni.[idUsuario]
      ,[fecha]
      ,[Kilometraje_Actual]
	  ,[noPoliza]
	  ,[descripcion]
	  ,(select top 1 marca from #marca) as marca

	 from Unidades as uni
	inner join [dbo].[usuarioUnidadContratoOperacion] as rel on rel.[idUnidad] = uni.[idUnidad]
	where rel.idUsuario = @idUsuario
end
go

grant execute, view definition on Banorte.APP_CITAS_GET_UNIDADES to DevOps
go

