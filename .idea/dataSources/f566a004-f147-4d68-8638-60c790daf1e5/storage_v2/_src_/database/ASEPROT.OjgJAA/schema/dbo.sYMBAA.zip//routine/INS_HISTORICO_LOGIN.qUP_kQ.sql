-- =============================================
-- Author:		Sahirely Yam
-- Create date: 03/06/2017
-- =============================================
CREATE PROCEDURE [dbo].[INS_HISTORICO_LOGIN]
	@idUsuario numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [dbo].[HistorialLogin]([idUsuario],[FechaInicio])
    VALUES (@idUsuario, GETDATE())

	select @@IDENTITY as idSesion
	
END
go

