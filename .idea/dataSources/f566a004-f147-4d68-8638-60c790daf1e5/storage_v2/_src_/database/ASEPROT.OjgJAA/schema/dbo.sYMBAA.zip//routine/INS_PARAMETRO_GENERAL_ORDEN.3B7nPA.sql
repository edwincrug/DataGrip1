-- =============================================
-- Description:	Obtengo si aplica para el boton de negligencia
-- =============================================
-- [dbo].[INS_PARAMETRO_GENERAL_ORDEN] 9,678
CREATE PROCEDURE [dbo].[INS_PARAMETRO_GENERAL_ORDEN]
@IdParametroGeneral numeric(18,0),
@IdOrden numeric(18,0)
AS
BEGIN

INSERT INTO [ASEPROT].[dbo].ParametrosGeneralOrden
SELECT @IdParametroGeneral,@IdOrden,GETDATE(),1

SELECT *
FROM [ASEPROT].[dbo].ParametrosGeneralOrden 
WHERE IdParametroGeneralOrden = @@IDENTITY

END
--GO
--BEGIN TRAN
--EXEC [dbo].[INS_PARAMETRO_GENERAL_ORDEN] 9, 1
--ROLLBACK TRAN
go

