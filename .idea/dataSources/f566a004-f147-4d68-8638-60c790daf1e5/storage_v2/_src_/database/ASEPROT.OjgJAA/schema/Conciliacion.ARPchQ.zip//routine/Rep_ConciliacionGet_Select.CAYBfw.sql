-- =============================================
-- Author:		Luis ALvarez del Castillo Bermudez
-- Create date: 2017 12 December 27 Wednesday Week 51
-- Description:	obtener las conciliaciones SISCO vs BRPO y BRPO vs SISCO
-- EXEC [Conciliacion].[Rep_ConciliacionGet_Select]
-- Time  01:42 Seconds 2018 January 10
-- Modificacion 2018 01 January 15
-- Se agrega estatus Orden 14
-- Modificacion 2018 01 January 19
-- Se agrega fecha de generacion en tablas y select de tablas
-- =============================================
CREATE PROCEDURE [Conciliacion].[Rep_ConciliacionGet_Select]
	-- Add the parameters for the stored procedure here	
	--<@Param1, sysname, @p1> <Datatype_For_Param1, , int> = <Default_Value_For_Param1, , 0>, 
	--<@Param2, sysname, @p2> <Datatype_For_Param2, , int> = <Default_Value_For_Param2, , 0>
	--@numeroOrden varchar(20) = null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	-- STEP 00  Elimino las tablas
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Conciliacion].[SiscoBpro]') AND type in (N'U'))
    BEGIN
	     DROP TABLE [Conciliacion].[SiscoBpro]
    END

	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Conciliacion].[BproSisco]') AND type in (N'U'))
    BEGIN
	     DROP TABLE [Conciliacion].[BproSisco]
    END

    -- Insert statements for procedure here
	-- SELECT 'SISCO vc BPRO'
	
	SELECT SD.[idOrden]
      ,SD.[numeroOrden]
      ,SD.[idContratoOperacion]
      ,SD.[idUsuario]
      ,SD.[idEstatusOrden]
      ,SD.[nombreEstatusOrden]
      ,SD.[idTallerOrden]
      ,SD.[idCotizacion]
      ,SD.[numeroCotizacion]
      ,SD.[idEstatusCotizacion]
      ,SD.[nombreEstatusCotizacion]
      ,SD.[idTallerCotizacion]
      ,SD.[nombreComercial]
      ,SD.[razonSocial]
      ,SD.[idBPRO]
      ,SD.[numFactura]
      ,SD.[subTotal]
	  ,SD.[total]

	  ,BP.[MODULO]     
      ,BP.[DES_TIPODOCTO]
      ,BP.[CCP_IDDOCTO]     
      ,BP.[CCP_IDPERSONA]
      ,BP.[Nombre]
	  ,BP.[IMPORTE]
      ,BP.[SALDO]

	  ,getdate() as [FechaRegistro]

  INTO [Conciliacion].[SiscoBpro]
  FROM [Conciliacion].[SiscoDataOperacion03] SD
  
  LEFT OUTER JOIN [ASEPROT].[cobranza].[VwInvoiceProvSaldoBPRO_GAAutoExpress] BP
  
               ON BP.[CCP_IDPERSONA] = SD.[idBPRO]
              AND BP.[CCP_IDDOCTO] = SD.[numFactura]

  WHERE  SD.idEstatusOrden in (5,6,7,8,9,10,11,12,13,14)

  ORDER BY SD.idOrden, SD.idCotizacion





  ---------------------------------------
  ----------------------------------------
  --- de BPRO to Sisco

  --SELECT 'BPRO vs SISCO'


  SELECT 
      
	   BP.[MODULO]     
      ,BP.[DES_TIPODOCTO]
	  ,BP.[CCP_IDPERSONA]
      ,BP.[Nombre]
      ,BP.[CCP_IDDOCTO]           
	  ,BP.[IMPORTE]
      ,BP.[SALDO]

      ,SD.[idOrden]
      ,SD.[numeroOrden]
      ,SD.[idContratoOperacion]
      ,SD.[idUsuario]
      ,SD.[idEstatusOrden]
      ,SD.[nombreEstatusOrden]
      ,SD.[idTallerOrden]
      ,SD.[idCotizacion]
      ,SD.[numeroCotizacion]
      ,SD.[idEstatusCotizacion]
      ,SD.[nombreEstatusCotizacion]
      ,SD.[idTallerCotizacion]
      ,SD.[nombreComercial]
      ,SD.[razonSocial]
      ,SD.[idBPRO]
      ,SD.[numFactura]
      ,SD.[subTotal]
	  ,SD.[total]
	    
	  ,getdate() as [FechaRegistro]

  
  INTO [Conciliacion].[BproSisco]
  FROM [ASEPROT].[cobranza].[VwInvoiceProvSaldoBPRO_GAAutoExpress] BP
    
  LEFT OUTER JOIN [Conciliacion].[SiscoDataOperacion03] SD
                 ON BP.[CCP_IDPERSONA] = SD.[idBPRO]
                AND BP.[CCP_IDDOCTO] = SD.[numFactura]

     WHERE  SD.idEstatusOrden in (5,6,7,8,9,10,11,12,13,14)

  ORDER BY CCP_IDPERSONA, CCP_IDDOCTO



  SELECT 'SISCO vc BPRO'


  SELECT [idOrden]
      ,[numeroOrden]
      ,[idContratoOperacion]
      ,[idUsuario]
      ,[idEstatusOrden]
      ,[nombreEstatusOrden]
      ,[idTallerOrden]
      ,[idCotizacion]
      ,[numeroCotizacion]
      ,[idEstatusCotizacion]
      ,[nombreEstatusCotizacion]
      ,[idTallerCotizacion]
      ,[nombreComercial]
      ,[razonSocial]
      ,[idBPRO]
      ,[numFactura]
      ,[subTotal]
      ,[total]
      ,[MODULO]
      ,[DES_TIPODOCTO]
      ,[CCP_IDDOCTO]
      ,[CCP_IDPERSONA]
      ,[Nombre]
      ,[IMPORTE]
      ,[SALDO]
     -- ,[FechaRegistro]
  FROM [Conciliacion].[SiscoBpro]


    SELECT ' BPRO vs SISCO'


SELECT [MODULO]
      ,[DES_TIPODOCTO]
      ,[CCP_IDPERSONA]
      ,[Nombre]
      ,[CCP_IDDOCTO]
      ,[IMPORTE]
      ,[SALDO]
      ,[idOrden]
      ,[numeroOrden]
      ,[idContratoOperacion]
      ,[idUsuario]
      ,[idEstatusOrden]
      ,[nombreEstatusOrden]
      ,[idTallerOrden]
      ,[idCotizacion]
      ,[numeroCotizacion]
      ,[idEstatusCotizacion]
      ,[nombreEstatusCotizacion]
      ,[idTallerCotizacion]
      ,[nombreComercial]
      ,[razonSocial]
      ,[idBPRO]
      ,[numFactura]
      ,[subTotal]
      ,[total]
--      ,[FechaRegistro]
  FROM [Conciliacion].[BproSisco]





END
go

grant execute, view definition on Conciliacion.Rep_ConciliacionGet_Select to DevOps
go

