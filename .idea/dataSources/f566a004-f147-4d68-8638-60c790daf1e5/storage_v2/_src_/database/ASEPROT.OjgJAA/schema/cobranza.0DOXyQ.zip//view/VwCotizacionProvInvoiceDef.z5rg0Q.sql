

--DROP VIEW [cobranza].[VwCotizacionProvInvoiceDef]
CREATE VIEW [cobranza].[VwCotizacionProvInvoiceDef]
AS

-- SELECT * FROM [cobranza].[VwCotizacionProvInvoiceDef]
-- Records 21573  TIME 1 Seconds  2017 12 20

SELECT distinct
       [idOrden]
      ,[numeroCotizacion]
      ,[idCotizacion]  
      ,[numFactura]
	  ,[idProveedor]
	  --,OTE_IDPROVEEDOR as [idProveedor]
	 -- select top 10 *
  FROM [cobranza].[VwCotizacionProvInvoiceBase]

go

