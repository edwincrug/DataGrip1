-- =============================================
-- Author:		Sahirely Yam
-- Create date: 13 09 2017
-- =============================================
-- exec [dbo].[SEL_PERSONAS_MODIFICAR_KM_GPS] 510, 200
CREATE PROCEDURE [dbo].[SEL_PERSONAS_MODIFICAR_KM_GPS]
AS
BEGIN

	SET NOCOUNT ON;

	select  
	ISNULL(Nombre,'')+ISNULL(' '+[Apellido Paterno],'')+ISNULL(' '+[Apellido Materno],'') AS name,
	Correo AS email
	from ParametrosGeneralPersona 
	where IdParametroGeneral = 21 AND Estatus=1

END
go

