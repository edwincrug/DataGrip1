
-- ==========================================================================================
-- Author:		Jordan Gómez Dominguez
-- Create date: 08/03/2019
-- ==========================================================================================
-- [dbo].[SEL_USUARIOS_AVISO_ENTREGA_SP] 74515, 988
CREATE PROC [dbo].[SEL_USUARIOS_AVISO_ENTREGA_SP]
@idOrden numeric(18,0),
@idUsuario numeric(18,0)

AS
BEGIN

	DECLARE @idContratoOperacion numeric(18,0)
	DECLARE @correos TABLE(id INT IDENTITY(1,1), destinatarios VARCHAR(max))
	DECLARE @nivel numeric(18,0)
	DECLARE @idZonaOrden numeric(18,0)
	DECLARE @idZonaEstado numeric(18,0)
	DECLARE @idZonaOficina numeric(18,0)
	DECLARE @correoDestinatario nvarchar(max) = ''
	DECLARE @aux INT = 1, @max DECIMAL (18,0) = 0
	DECLARE @cuerpoCorreo nvarchar(max) = ''
	DECLARE @fechaCreacionOrden datetime
	DECLARE @fechaAviso datetime
	DECLARE @numeroOrden nvarchar(30) = ''
	DECLARE @numeroEconomico nvarchar(30) = ''
	DECLARE @textoPlano nvarchar(max) = ''
	DECLARE @vin VARCHAR(100)=''

	SELECT 
		@idContratoOperacion = CO.idContratoOperacion,
		@numeroOrden = O.numeroOrden,
		@numeroEconomico = U.numeroEconomico,
		@vin = U.vin
	FROM Ordenes O 
		INNER JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
		INNER JOIN Unidades U ON U.idUnidad = O.idUnidad
	WHERE O.idOrden = @idOrden

		SELECT 
		@nivel = PNZ.orden,
		@idZonaOrden = PZ.idZona,
		@fechaCreacionOrden = O.fechaCreacionOden
	FROM Ordenes O 
		INNER JOIN Partidas..Zona PZ ON PZ.idZona = O.idZona 
		INNER JOIN Partidas..NivelZona PNZ ON PZ.idNivelZona = PNZ.idNivelZona
	WHERE O.idOrden = @idOrden

	SET @idZonaEstado = @idZonaOrden
	SET @idZonaOficina = @idZonaOrden

	IF @idContratoOperacion = 37
	BEGIN
	INSERT INTO @correos
	SELECT U.correoElectronico FROM Ordenes O
	INNER JOIN Usuarios U ON U.idUsuario = O.idUsuario
	WHERE O.idOrden = @idOrden


	IF(@nivel = 1)
	BEGIN
		SELECT 
			@idZonaEstado = PZE.idZona 
		FROM Partidas..Zona PZO
			INNER JOIN Partidas..Zona PZE ON PZE.idPadre = PZO.idZona
		WHERE PZO.idZona = @idZonaOrden
	END
	ELSE IF(@nivel = 2)
	BEGIN
		SELECT 
			@idZonaOficina = PZO.idZona
		FROM Partidas..Zona PZE
			INNER JOIN Partidas..Zona PZO ON PZO.idZona = PZE.idPadre
		WHERE PZE.idZona = @idZonaOrden
	END
	ELSE IF(@nivel = 3)
	BEGIN
		SELECT 
			@idZonaEstado = PZE.idZona, 
			@idZonaOficina = PZO.idZona
		FROM Partidas..Zona PZC
			INNER JOIN Partidas..Zona PZE ON PZE.idZona = PZC.idPadre
			INNER JOIN Partidas..Zona PZO ON PZO.idZona = PZE.idPadre
		WHERE PZC.idZona = @idZonaOrden
	END

	INSERT INTO @correos
	SELECT 
		DISTINCT U.correoElectronico 
	FROM ContratoOperacionUsuarioZona COUZ
	INNER JOIN ContratoOperacionUsuario COU ON COU.idContratoOperacionUsuario = COUZ.idContratoOperacionUsuario 
	INNER JOIN Partidas..Zona PZ ON PZ.idZona = COUZ.idZona 
	INNER JOIN Usuarios U ON COU.idUsuario = U.idUsuario
	WHERE COU.idContratoOperacion = @idContratoOperacion AND idCatalogoTipoUsuarios = 1 AND idCatalogoRol = 1 
	AND U.empresa = 'PF' AND PZ.idZona IN (@idZonaEstado,@idZonaOficina) AND U.correoElectronico NOT IN(SELECT destinatarios FROM @correos)

	INSERT INTO @correos
	SELECT correoElectronico FROM Usuarios WHERE idUsuario IN
	(1430,1537,1347,1349,1348,1429,538) AND correoElectronico NOT IN(SELECT destinatarios FROM @correos)
	END
	ELSE
	BEGIN
		IF @idContratoOperacion = 17
		BEGIN
		INSERT INTO @correos
		SELECT correoElectronico FROM [dbo].[CatalogoCorreosAvisoEntrega]
		WHERE idContratoOperacion=@idContratoOperacion AND activo=1 AND idZona IN (-1)
		END

		IF @idContratoOperacion = 19
		BEGIN
		INSERT INTO @correos
		SELECT correoElectronico FROM [dbo].[CatalogoCorreosVIN_AvisoEntrega]
		WHERE Vin=@vin AND activo=1
		UNION ALL
		SELECT correoElectronico FROM [dbo].[Usuarios]
		WHERE idUsuario IN(885, 1030, 1272, 649)
		END

		IF @idContratoOperacion = 55
		BEGIN
		INSERT INTO @correos
		--SELECT 'brandon.gomez@grupoandrade.com.mx'
		SELECT 'controlvehiculardt@gmail.com'
		END

		IF @idContratoOperacion = 36
		BEGIN
		INSERT INTO @correos
		SELECT correoElectronico FROM [dbo].[CatalogoCorreosAvisoEntrega]
		WHERE idContratoOperacion=@idContratoOperacion AND activo=1 AND idZona IN (@idZonaOrden)
		END
	END

	SELECT @max = MAX(id), @aux = MIN(id) FROM @correos

	WHILE(@aux <= @max)
	BEGIN 
		SELECT @correoDestinatario = @correoDestinatario + ',<' + destinatarios + '>' FROM @correos
		WHERE id = @aux
	
		SET @aux = @aux + 1
	END

	SET @correoDestinatario = SUBSTRING(@correoDestinatario,2,LEN(@correoDestinatario))
	SET @fechaAviso = (SELECT GETDATE())

	SET @cuerpoCorreo = '
		<!DOCTYPE html> <html lang="es"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body>
			<div style="font-family: Arial;">
				<div style="font-size: 16px;color: #0489B1;margin-left: 10px; text-align: center;">
					<h1>Aviso de entrega</h1>
				</div>
				<div style="font-family: Arial;font-size: 14px; text-align: justify;">
					<p>Derivado de su solicitud de fecha '+ convert(nvarchar(MAX), @fechaCreacionOrden, 20) +', referente a la orden de servicio '+@numeroOrden+' del económico
					'+@numeroEconomico+' le notificamos que la unidad se encuentra lista para su recolección a partir de '+ convert(nvarchar(MAX), @fechaAviso, 20) +'.
					</p>
					<br> 
					<br> 
					<p>Sin otro particular, quedo a sus ordenes</p>
				</div>
			</div>
		</body></html> '
	
	SET @textoPlano = 'Derivado de su solicitud de fecha '+ convert(nvarchar(MAX), @fechaCreacionOrden, 20) +', referente a la orden de servicio '+@numeroOrden+' del económico '+@numeroEconomico+' le notificamos que la unidad se encuentra lista para su recolección a partir de '+ convert(nvarchar(MAX), @fechaAviso, 20) + '.'

	IF @idUsuario<>-1000 AND @idUsuario<>988
	BEGIN
	INSERT INTO BitacoraAvisoEntrega VALUES (@idOrden, GETDATE(), @idUsuario)
	END
	
	--IF @idUsuario=988
	--BEGIN
	--SET @correoDestinatario = '<brandon.gomez@grupoandrade.com.mx>,<jgarcia@bism.com.mx>'
	--END

	SELECT 'noreply@centraldeoperaciones.com' correoDe, @correoDestinatario correoPara, @cuerpoCorreo bodyHtml, @textoPlano textoPlano

END
--GO
--BEGIN TRAN

--EXEC [SEL_USUARIOS_AVISO_ENTREGA_SP] 79986,988
--EXEC [SEL_USUARIOS_AVISO_ENTREGA_SP] 74515,988
--EXEC [SEL_USUARIOS_AVISO_ENTREGA_SP] 77665,988

--ROLLBACK TRAN
go

