

-- =============================================
-- Create date: 06/12/2017
-- Description:	ELIMINA DATOS COPADE
-- [EXT_DEL_DATOS_COPADE_SP] 7501, 538, 3
-- User : Jordan Gomez
-- =============================================
 CREATE PROCEDURE [dbo].[EXT_DEL_DATOS_COPADE_SP]
	@idDatosCopade INT,
	@idUsuario INT,
	@idContratoOperacion INT
	
AS
BEGIN

DECLARE @query NVARCHAR(MAX)
	BEGIN
		SET @query = 'INSERT INTO LogSoporte (
			idOrden,
			idUsuario,
			idContratoOperacion,
			fecha,
			idSoporte,
			descripcion
			)
		SELECT 
			0,
			'+CAST(@idUsuario AS NVARCHAR(30))+',
			DC.idContratoOperacion,
			getdate(),
			10,
			''Eliminar copade''
		FROM DatosCopade DC 
		WHERE DC.idContratoOperacion = ' + CAST(@idContratoOperacion AS NVARCHAR(30)) + ' AND DC.idDatosCopade = '+CAST(@idDatosCopade AS NVARCHAR(30)) 
		
		--PRINT @query

		EXECUTE SP_EXECUTESQL @query

		DELETE FROM DatosCopade where idDatosCopade = CAST(@idDatosCopade AS NVARCHAR(30)) AND idContratoOperacion = CAST(@idContratoOperacion AS NVARCHAR(30));
	
		SELECT @idContratoOperacion AS idContratoOperacion
	END		
END
go

