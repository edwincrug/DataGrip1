-- select [dbo].[fnFactorIVA_ZONA] (1317)
CREATE FUNCTION [dbo].[fnFactorIVA_ZONA](@idZona INT)

RETURNS DECIMAL(18,2)
AS
BEGIN

DECLARE @factorIVA DECIMAL(18,2)=0,@fechaCreacionOrden DATETIME,@idContratoOperacion INT

IF @idZona IS NOT NULL
BEGIN
SELECT @factorIVA = PG.Valor FROM [dbo].[ParametrosGeneralZona] PGZ 
	INNER JOIN [dbo].[ParametrosGeneral] PG 
		INNER JOIN ParametrosGeneralHistorial PGH ON PG.IdParametroGeneral=PGH.IdParametroGeneral
	ON PG.IdParametroGeneral = PGZ.IdParametroGeneral
WHERE PGZ.idZona=@idZona

END
ELSE
BEGIN
SET @factorIVA = 0.16
END

RETURN @factorIVA
END
--GO
--SELECT [dbo].[fnFactorIVA_Orden](65778,0)
--SELECT [dbo].[fnFactorIVA_Orden](66839,0)

--SELECT * FROM Ordenes
--where idOrden in(66839,65778)
go

