

CREATE VIEW [Report].[VwOrdenStatusMaxDate]
AS
select Max(fechaInicial) as [FechaMax],
       idOrden,
	   idEstatusOrden
  from HistorialEstatusOrden 
  group by idOrden,
	   idEstatusOrden
go

