CREATE PROCEDURE [dbo].[INS_FACTURA_COTIZACION_SP]
    @idCotizacion NUMERIC(18,0),
    @numFactura VARCHAR(MAX),
    @uuid VARCHAR(MAX),
    @fechaFactura DATETIME,
    @subTotal DECIMAL(18,2),
    @descuento DECIMAL(18,2) = null,
    @iva DECIMAL(18,2),
    @total DECIMAL(18,2),
    @idUsuario NUMERIC(18,0),
    @xml VARCHAR(MAX),
    @rfcEmisor VARCHAR(MAX),
    @rfcReceptor VARCHAR(MAX),
    @retenido DECIMAL(18,2) = null,
    @tasaOCuota DECIMAL(18,2) = null,
	@tasaIVA DECIMAL(18,2) = null
AS

DECLARE 
    @idContratoOperacion	INT,
    @porcVenta				FLOAT,
    @ID INT,
	@costoCotizacion NUMERIC(18,2),
	@diferencia NUMERIC(18,2) = 0,
	@totalPartidas NUMERIC(18,0) = 0,
	@descuentoPartida NUMERIC(18,4) = 0
BEGIN
	
	IF(@tasaIVA IS NULL)
	BEGIN 
		SET @tasaIVA = .16
	END

	IF(@xml='N/A')
	BEGIN 
		SET @subTotal = (SELECT SUM(costo * cantidad) FROM CotizacionDetalle WHERE idEstatusPartida<>4 AND idCotizacion=@idCotizacion)
		SET @iva = CAST((@subTotal * @tasaIVA) AS DECIMAL(18,2))
		SET @total = @subTotal + CAST((@subTotal * @tasaIVA) AS DECIMAL(18,2))
	END

    IF NOT EXISTS (SELECT 1
    FROM FacturaCotizacion
    WHERE idCotizacion=@idCotizacion)
    BEGIN
        INSERT INTO FacturaCotizacion
            (
            [idCotizacion]
            ,[numFactura]
            ,[uuid]
            ,[fechaFactura]
            ,[subTotal]
            ,[iva]
            ,[total]
            ,[fechaAlta]
            ,[idUsuario]
            ,[xml]
            ,[rfcEmisor]
            ,[rfcReceptor]
            ,[descuento]
            ,[retenido]
            ,[tasaOCuota]
			,[tasaIVA]
            )
        VALUES
            (
                @idCotizacion
                ,@numFactura
                ,@uuid
                ,@fechaFactura
                ,@subTotal
                ,@iva
                ,@total
                ,GETDATE()
                ,@idUsuario
                ,@xml
                ,@rfcEmisor
                ,@rfcReceptor
                ,@descuento
                ,@retenido
                ,@tasaOCuota
				,@tasaIVA
            );
        SELECT lastId = @@IDENTITY;

    END
    ELSE
    BEGIN

        INSERT INTO facturaCotizacionHistorial
            (
            [idFacturaCotizacion]
            ,[idCotizacion]
            ,[numFactura]
            ,[uuid]
            ,[fechaFactura]
            ,[subTotal]
            ,[iva]
            ,[total]
            ,[fechaAlta]
            ,[idUsuario]
            ,[xml]
            ,[rfcEmisor]
            ,[rfcReceptor]
            ,[descuento]
            ,[retenido]
            ,[tasaOCuota]
			,[tasaIVA]
            )
        SELECT *
        FROM facturaCotizacion
        WHERE idCotizacion = @idCotizacion

        UPDATE FacturaCotizacion
            SET [numFactura]=@numFactura
            ,[uuid]=@uuid
            ,[fechaFactura]=@fechaFactura
            ,[subTotal]=@subTotal
            ,[iva]=@iva
            ,[total]=@total
            ,[fechaAlta]=GETDATE()
            ,[idUsuario]=@idUsuario
            ,[xml]=@xml
            ,[rfcEmisor]=@rfcEmisor
            ,[rfcReceptor]=@rfcReceptor
            ,[descuento] = @descuento
            ,[retenido] = @retenido
            ,[tasaOCuota] = @tasaOCuota
			,[tasaIVA] = @tasaIVA
        WHERE idCotizacion = @idCotizacion
		
        IF EXISTS (SELECT 1
        FROM Cotizaciones C
            INNER JOIN ParametrosGeneralOrden PGO ON PGO.idOrden = C.idOrden
            INNER JOIN ParametrosGeneral PG ON PG.IdParametroGeneral = PGO.IdParametroGeneral
        WHERE C.idCotizacion=@idCotizacion AND PG.IdParametroGeneral = 12)
        BEGIN
            UPDATE A_O SET
                A_O.OTE_FACTURACOMPRA = @numFactura
            FROM [192.168.20.29].[GaAutoexpress].[dbo].[ADE_ORDSERENC] A_O
                INNER JOIN Cotizaciones C ON C.NUMEROCOTIZACION COLLATE SQL_Latin1_General_CP1_CI_AS = A_O.OTE_ORDENPEMEX
            WHERE C.idCotizacion = @idCotizacion
        END

        SELECT @ID=idFacturaCotizacion
        FROM FacturaCotizacion
        WHERE idCotizacion=@idCotizacion

        SELECT lastId = @ID;
    END

    SELECT 
	@idContratoOperacion = O.idContratoOperacion
	,@costoCotizacion = CC.costo
    FROM Cotizaciones C
        INNER JOIN Ordenes O ON O.idOrden = C.idOrden
		INNER JOIN [report].[VwCostoCotizacionSinCancelar] CC ON CC.idCotizacion = C.idCotizacion
    WHERE C.idCotizacion = @idCotizacion
	
    IF EXISTS(SELECT 
				idContratoOperacion
				FROM [dbo].[Regla_Venta] RV
				WHERE idContratoOperacion = @idContratoOperacion 
				AND activo = 1) 
    BEGIN

        SET @porcVenta = (SELECT porcentajeVenta
							FROM [dbo].[Regla_Venta] RV
							WHERE idContratoOperacion = @idContratoOperacion AND activo = 1)

        UPDATE CotizacionDetalle
            SET venta = costo / @porcVenta
        WHERE idCotizacion = @idCotizacion
    END

	SET @diferencia = @costoCotizacion - (@subTotal - ISNULL(@descuento, 0))

	IF(@diferencia > 1 AND @xml<>'N/A')
	BEGIN

		set @descuentoPartida = @diferencia / @costoCotizacion;

		INSERT INTO HistorialCotizacionDetalle
		SELECT
		CD.idCotizacionDetalle
		,@idUsuario
		,CD.costo
		,CD.venta
		,GETDATE()
		,CD.cantidad
		,CD.idEstatusPartida
		,'Carga de factura'
		FROM COTIZACIONES C 
		INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
		WHERE C.IDCOTIZACION = @idCotizacion and CD.idEstatusPartida NOT IN(3,4)

		UPDATE CD SET 
		CD.costo = CD.costo - (cd.costo*@descuentoPartida) 
		FROM COTIZACIONES C 
		INNER JOIN CotizacionDetalle CD ON CD.idCotizacion = C.idCotizacion
		WHERE C.IDCOTIZACION = @idCotizacion and CD.idEstatusPartida NOT IN(3,4)

	END
	
END
go

