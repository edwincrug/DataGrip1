
-- ==========================================================================================
-- Author:		Iralda Sahirely Yam Llanes
-- Create date: 16/05/2017
-- ==========================================================================================
-- [dbo].[SEL_ZONAS_SP] @idContratoOperacion = 1, @idNivel=2, @idUsuario = 1 
CREATE PROC [dbo].[SEL_ZONAS_SP]
	@idContratoOperacion numeric(18,0),
	@idNivel numeric(18, 0),
	@idUsuario numeric(18,0)
AS
BEGIN
	
	declare @bdPartidas varchar(max) = (select nombreBD from [dbo].[Parametros] where [idParametros] = 1)
	declare @consulta varchar(max) = ''

	declare @idCOU numeric(18,0), @idRol numeric(18,0)

	select @idCOU = COU.idContratoOperacionUsuario, @idRol = COU.idCatalogoRol from Usuarios U 
	inner join ContratoOperacionUsuario COU on COU.idUsuario = U.idUsuario
	where U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	declare @zonasAsignadas table (idZona int)
	declare @zonasContrato table(etiqueta varchar(max), idZona int, nombre varchar(max), idPadre int, orden int)

	if @idRol <> 4
	begin
		if @idRol <> 9
			begin
				insert into @zonasAsignadas
				select idZona from ContratoOperacionUsuarioZona COUZ
				where COUZ.idContratoOperacionUsuario = @idCOU
			end
		else
			begin
				insert into @zonasAsignadas
						SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
							JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
							JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
						WHERE EG.estatus=0 AND EZ.estatus=0 
						AND COUG.idContratoOperacionUsuario=@idCOU
			end
	end
	else
	begin
		insert into @zonasAsignadas
		select distinct CPZ.idZona
		from ContratoOperacionUsuarioProveedor COUP
		inner join ContratoOperacionUsuario COU on COU.idContratoOperacionUsuario = COUP.idContratoOperacionUsuario
		inner join ContratoOperacion CO on CO.idContratoOperacion = COU.idContratoOperacion
		inner join Partidas..Contrato C on C.idContrato = CO.idContrato
		inner join Partidas..ContratoProveedor CP on CP.idContrato = C.idContrato and CP.idProveedor = COUP.idProveedor
		inner join Partidas..ContratoProveedorZona CPZ on CPZ.idContratoProveedor = CP.idContratoProveedor
		where COUP.idContratoOperacionUsuario = @idCOU
	end

	set @consulta = 
	'SELECT      NivZo.etiqueta, z.idZona, z.nombre, z.idPadre, NivZo.orden
	FROM		'+@bdPartidas+'.dbo.Contrato AS Con INNER JOIN
				'+@bdPartidas+'.dbo.Licitacion AS Li ON Con.idLicitacion = Li.idLicitacion INNER JOIN
				'+@bdPartidas+'.dbo.Cliente AS Cli ON Li.idCliente = Cli.idCliente INNER JOIN
				'+@bdPartidas+'.dbo.NivelZona AS NivZo ON Cli.idCliente = NivZo.idCliente INNER JOIN
				'+@bdPartidas+'.dbo.Zona AS Z ON z.idNivelZona = NivZo.idNivelZona
	WHERE z.idNivelZona = ' +convert(varchar(max),@idNivel)+
	' AND Con.idContrato IN (SELECT ConOp.idContrato
							FROM ContratoOperacion AS ConOp 
							WHERE ConOp.idContratoOperacion = '+convert(varchar(max),@idContratoOperacion)+') 
	ORDER BY z.nombre' + char(13)

	print @consulta
	insert into @zonasContrato  EXEC (@consulta)
	
	if @idRol <> 2
	begin
		select * from @zonasContrato ZC
		where ZC.idZona IN (select idZona from @zonasAsignadas) 		
	end
	else
	begin
		select * from @zonasContrato
	end
END

go

