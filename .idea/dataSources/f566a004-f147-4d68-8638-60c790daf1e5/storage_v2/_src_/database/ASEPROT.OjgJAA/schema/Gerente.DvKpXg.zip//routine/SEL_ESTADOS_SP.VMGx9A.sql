 CREATE PROCEDURE [Gerente].[SEL_ESTADOS_SP] 
	@idContratoOperacion INT

AS
BEGIN
	IF(@idContratoOperacion <> 0)
		BEGIN
			SELECT 
				E.idEstados,
				E.nombreEstado,
				E.descripcionEstado,
				E.fechaAlta,
				E.idUsuario,
				U.nombreCompleto
			FROM [Gerente].[Estados] E
			JOIN [dbo].[Usuarios] U ON U.idUsuario = E.idUsuario
			WHERE E.estatus = 0 
			/*AND E.idEstados NOT IN(SELECT idEstado FROM [Gerente].[EstadoZona] WHERE idContratoOperacion = @idContratoOperacion AND estatus = 0)*/
			ORDER BY E.idEstados DESC
		END
	ELSE
		BEGIN
			SELECT 
				E.idEstados,
				E.nombreEstado,
				E.descripcionEstado,
				E.fechaAlta,
				E.idUsuario,
				U.nombreCompleto
			FROM [Gerente].[Estados] E
			JOIN [dbo].[Usuarios] U ON U.idUsuario = E.idUsuario
			WHERE E.estatus = 0 
			ORDER BY E.idEstados DESC
		END
END


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.SEL_ESTADOS_SP to DevOps
 go

