-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>[SEL_COTIZACION_ABONADOS_SELECT_SP] 518,3,1
-- TEST Proveedor   [SEL_COTIZACION_ABONADOS_SELECT_SP] 107,3,1
--  TEST Proveedor   [SEL_COTIZACION_ABONADOS_SELECT_SP] 363,3,1
-- =============================================
CREATE PROCEDURE [dbo].[SEL_COTIZACION_ABONADOS_SELECT_SP_BKP_20171219] --9
(
	@idUsuario numeric(18,0),
	@idContratoOperacion numeric(18,0),
	@isProduction numeric(18,0),	
	@idZona int = null,
	@idEjecutivoFiltro INT = null,
	@fechaIni varchar(max) = null,--'2017/09/01 00:00:00',
	@fechaFin varchar(max) = null--'2017/09/30 23:59:59'
)
	
AS
BEGIN
	
	IF(@idContratoOperacion = 3)
		BEGIN
			EXEC [dbo].[SEL_COTIZACION_ABONADOS_SELECT_GAAutoExpress_SP] @idUsuario, @idContratoOperacion, @isProduction, @idZona, @idEjecutivoFiltro, @fechaIni, @fechaFin
		END
	ELSE
		BEGIN
			EXEC [dbo].[SEL_COTIZACION_ABONADOS_SELECT_GATPartsToluca_SP] @idUsuario, @idContratoOperacion, @isProduction, @idZona, @idEjecutivoFiltro, @fechaIni, @fechaFin	
		END

	
	END
go

