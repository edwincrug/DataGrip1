
--exec [cobranza].[INS_InvoiceProvSaldoBPRO_GAAutoExpessC_SP] 
CREATE PROCEDURE [cobranza].[INS_InvoiceProvSaldoBPRO_GAAutoExpessC_SP] 
	
AS
BEGIN

--IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[cobranza].[InvoiceProvSaldoBPRO_GAAutoExpressC]') AND type in (N'U'))
--   BEGIN
--		DROP TABLE [cobranza].[InvoiceProvSaldoBPRO_GAAutoExpressC]
--   END

--SELECT [CCP_IDDOCTO]
--      ,[CCP_IDPERSONA]
--      ,[SALDO]
--  INTO [cobranza].[InvoiceProvSaldoBPRO_GAAutoExpressC]
--  FROM [cobranza].[VwInvoiceProvSaldoBPRO_GAAutoExpressC]
	print 'en construcción'
  END
go

