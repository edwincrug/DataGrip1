-- =============================================
-- Create date: 03/10/2017
-- Description:	Stored que consulta ordenes con estatus 1 Citas sin taller
-- [SEL_OPE_ORDEN_TOKEN_SP] 57,538,'',0
-- =============================================

 CREATE PROCEDURE [dbo].[SEL_OPE_ORDEN_TOKEN_SP]
	@idContratoOperacion INT = 3,
	@idUsuario INT = 489, 
	@numeroOrden VARCHAR(50) = '',
	@idEjecutivo INT = 0
		
AS
BEGIN

	SET NOCOUNT ON;  
 
	DECLARE @idCatalogoRol INT  
	DECLARE @idContratoOperacionUsuario INT
	DECLARE @idContratoOperacionUsuarioEjecutivo INT
	DECLARE @idOperacion INT
	DECLARE @select NVARCHAR(MAX) = '' 
	DECLARE @where NVARCHAR(MAX) = '' 
	DECLARE @query NVARCHAR(MAX) = ''
	DECLARE @and NVARCHAR(MAX) = ''
	DECLARE @join NVARCHAR(MAX) = ''
	DECLARE @usuario NVARCHAR(MAX) = '' 
	DECLARE @zonas NVARCHAR(MAX) = ''
	DECLARE @zonasEjecutivo NVARCHAR(MAX) = ''
	DECLARE @SERCH NVARCHAR(MAX) = ''
	DECLARE @cliente NVARCHAR(MAX) = ''
	
	SELECT @idContratoOperacionUsuario = COU.idContratoOperacionUsuario, @idCatalogoRol = COU.idCatalogoRol, @idOperacion = CO.idOperacion
	FROM Usuarios U 
		JOIN ContratoOperacionUsuario COU ON COU.idUsuario = U.idUsuario
		JOIN ContratoOperacion CO ON COU.idContratoOperacion = CO.idContratoOperacion
	WHERE U.idUsuario = @idUsuario and COU.idContratoOperacion = @idContratoOperacion

	IF(@idCatalogoRol <> 2 AND @idEjecutivo = 0)
		BEGIN
		    IF(@idCatalogoRol <> 4)
				BEGIN
					IF(@idCatalogoRol <> 9)
						BEGIN
							 SET @usuario  = 'AND idZona in (SELECT idZona FROM ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = '+ convert(varchar(5), @idContratoOperacionUsuario) +') '
						END
					ELSE
						BEGIN
							SET @usuario  = 'AND idZona in (SELECT EZ.idZona FROM [ContratoOperacionUsuarioGerente] COUG
												JOIN [Gerente].[EstadoGerencia] EG ON EG.idGerencia = COUG.idGerencias
												JOIN [Gerente].[EstadoZona] EZ ON EZ.idEstado = EG.idEstado
											WHERE EG.estatus=0 AND EZ.estatus=0 
											AND COUG.idContratoOperacionUsuario='+ convert(varchar(5), @idContratoOperacionUsuario) +' AND EZ.idContratoOperacion='+ convert(varchar(5), @idContratoOperacion) +') '
						END
				END
			ELSE
				BEGIN
					set @usuario = ' AND (SELECT CASE WHEN EXISTS (SELECT 1 FROM Cotizaciones C where C.idOrden = O.idOrden and C.idEstatusCotizacion in (3) AND C.idTaller in '+
									'(SELECT COUP.idProveedor' + char(13) + 
										'FROM ContratoOperacionUsuario COU ' + char(13) + 
										'INNER JOIN ContratoOperacionUsuarioProveedor COUP ON COUP.idContratoOperacionUsuario =  COU.idContratoOperacionUsuario' + char(13) + 
										'WHERE COU.idUsuario = '+ convert(varchar(5), @idUsuario) +' and COU.idContratoOperacion = '+ convert(varchar(50),@idContratoOperacion) +')'+
									' ) THEN ' +char(39)+'true'+char(39)+ ' ELSE '+char(39)+ 'false'+char(39)+' END ) = '+char(39)+'true'+char(39)  

				END
		END
	ELSE IF(@idCatalogoRol = 2 AND @idEjecutivo != 0)
		BEGIN 
			SET @usuario  = 'AND idZona in (SELECT idZona FROM ContratoOperacionUsuarioZona WHERE idContratoOperacionUsuario = '+ convert(varchar(5), @idContratoOperacionUsuario) +') '
		END
	
	SET @select = 
		'
		SELECT * FROM(
		SELECT 
		(SELECT [dbo].[SEL_NOMBRE_CLIENTE]('+CONVERT(NVARCHAR(100),@idContratoOperacion)+')) AS nombreCliente,
		O.consecutivoOrden,
		O.numeroOrden,
		U.numeroEconomico,
		Z.nombre AS nombreZona,
		CTO.nombreTipoOrdenServicio AS nombreTipoOrdenServicio,
		O.fechaCreacionOden,	
		O.comentarioOrden,
		O.idEstatusOrden,
		''1'' AS conjuntoEstatus,
		EO.nombreEstatusOrden,
		'+convert(varchar(max),@idUsuario)+' as idUsuario,
		(select top 1 idUsuario from [dbo].[ClientePerfilZona] where idZona = o.idZona and idPerfil = 1 and co.idOperacion = idOperacion) as super,
		(select top 1 correoElectronico from [dbo].[ClientePerfilZona] cp join Usuarios u on u.idUsuario = cp.idUsuario where idZona = o.idZona and idPerfil = 1 and co.idOperacion = idOperacion) as supercorreo,
		(select top 1 idUsuario from [dbo].[ClientePerfilZona] where idZona = o.idZona and idPerfil = 2 and co.idOperacion = idOperacion) as mante,	
		(select top 1 correoElectronico from [dbo].[ClientePerfilZona] cp join Usuarios u on u.idUsuario = cp.idUsuario where idZona = o.idZona and idPerfil = 2 and co.idOperacion = idOperacion) as mantecorreo,
		UR.nombreCompleto,
		UR.correoElectronico,
		(SELECT [dbo].[SEL_PRECIO_VENTA_FN](O.idOrden, O.idContratoOperacion, 3,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS venta,
		(SELECT [dbo].[SEL_PRECIO_COSTO_FN](O.idOrden, O.idContratoOperacion, 3,'+convert(varchar(max),@idUsuario)+', '+convert(varchar(max),@idCatalogoRol)+')) AS costo,
		DATEDIFF (Day, HE.fechaInicial, GETDATE()) As tiempoEspera,
		O.idOrden,
		Z.idZona,
		substring([dbo].[cadenaToken](O.numeroOrden), 3, 100) AS estatusToken,
		CO.idContratoOperacion
	FROM Ordenes O
		JOIN Unidades U ON U.idUnidad = O.idUnidad
		JOIN EstatusOrdenes EO ON EO.idEstatusOrden = O.idEstatusOrden
		JOIN ContratoOperacion CO ON CO.idContratoOperacion = O.idContratoOperacion
		JOIN CatalogoTiposOrdenServicio CTO ON CTO.idCatalogoTipoOrdenServicio = O.idCatalogoTipoOrdenServicio
		JOIN HistorialEstatusOrden HE ON HE.idEstatusOrden = O.idEstatusOrden AND HE.idOrden = O.idOrden
		JOIN Usuarios UR ON UR.idUsuario = O.idUsuario
		JOIN Partidas..Zona Z ON Z.idZona = O.idZona)x '

	SET @where = 'WHERE estatusToken <> ''0'' AND idContratoOperacion = '+CONVERT(NVARCHAR(100),@idContratoOperacion)+' AND idEstatusOrden IN(7,8) '

	IF(@idCatalogoRol = 1)
		BEGIN	 
			IF EXISTS(select 1 from [dbo].[ClientePerfilZona] WHERE idUsuario = @idUsuario AND idPerfil = 1)
				BEGIN
					SET @SERCH = 'Superintendente'
				END
			ELSE IF EXISTS(select 1 from [dbo].[ClientePerfilZona] WHERE idUsuario = @idUsuario AND idPerfil = 2)
				BEGIN
					SET @SERCH = 'Mantenimiento'
				END
			SET @cliente = ' AND estatusToken LIKE ''%'+@SERCH+'%'' '
		END

	IF(@numeroOrden != '' AND @numeroOrden != '12345')
	  BEGIN
		SET @and =' AND numeroOrden like ''%'+@numeroOrden+'%'''
	  END

	SET @query = @select + @where + @usuario + @and + @cliente
	print @query
	EXECUTE SP_EXECUTESQL @query

END


--USE [ASEPROT]
go

