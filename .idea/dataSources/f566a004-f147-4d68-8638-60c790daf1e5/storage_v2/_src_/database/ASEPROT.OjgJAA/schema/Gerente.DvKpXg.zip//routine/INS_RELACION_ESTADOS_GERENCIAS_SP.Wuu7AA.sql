 CREATE PROCEDURE [Gerente].[INS_RELACION_ESTADOS_GERENCIAS_SP]
	@idEstadoGerencia INT,
 	@idEstado INT,
	@idGerencia INT,
	@idUsuario INT,
	@cancela INT

AS
BEGIN

	IF(@cancela = 0)
		BEGIN 
			IF(@idEstadoGerencia = 0)
				BEGIN 
					IF NOT EXISTS(SELECT 1 FROM [Gerente].[EstadoGerencia] WHERE idEstado=@idEstado AND idGerencia=@idGerencia AND estatus=0)
						BEGIN
							INSERT [Gerente].[EstadoGerencia]
							VALUES(@idEstado,@idGerencia,GETDATE(),@idUsuario,0)

							SELECT 'El registro se ha guardado correctamente!' msg, 1 estatus

						END
					ELSE
						BEGIN
							SELECT 'La Estado y Gerencia a registrar ya existe!' msg, 0 estatus
						END
				END
			ELSE
				BEGIN
				IF NOT EXISTS(SELECT 1 FROM [Gerente].[EstadoGerencia] WHERE idEstado=@idEstado AND idGerencia=@idGerencia AND estatus=0)
					BEGIN
						UPDATE [Gerente].[EstadoGerencia]
						SET idEstado=@idEstado,idGerencia=@idGerencia,idUsuario=@idUsuario
						WHERE idEstadoGerencia=@idEstadoGerencia

						SELECT 'El registro se ha guardado correctamente!' msg, 1 estatus

					END
				ELSE
					BEGIN
						SELECT 'La Estado y Gerencia a registrar ya existe!' msg, 0 estatus
					END

				END
		END
	ELSE
		BEGIN
			UPDATE [Gerente].[EstadoGerencia]
			SET estatus=1
			WHERE idEstadoGerencia=@idEstadoGerencia

			SELECT 'El registro se ha cancelado correctamente!' msg, 1 estatus

		END
END


--USE [ASEPROT]
 go

 grant execute, view definition on Gerente.INS_RELACION_ESTADOS_GERENCIAS_SP to DevOps
 go

