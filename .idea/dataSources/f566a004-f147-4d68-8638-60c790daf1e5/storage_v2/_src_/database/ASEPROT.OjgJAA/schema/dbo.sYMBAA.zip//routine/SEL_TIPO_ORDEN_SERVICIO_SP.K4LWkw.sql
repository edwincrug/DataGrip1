create PROCEDURE [dbo].[SEL_TIPO_ORDEN_SERVICIO_SP] 

AS
BEGIN

	SELECT idCatalogoTipoOrdenServicio, nombreTipoOrdenServicio
	FROM CatalogoTiposOrdenServicio

END
go

