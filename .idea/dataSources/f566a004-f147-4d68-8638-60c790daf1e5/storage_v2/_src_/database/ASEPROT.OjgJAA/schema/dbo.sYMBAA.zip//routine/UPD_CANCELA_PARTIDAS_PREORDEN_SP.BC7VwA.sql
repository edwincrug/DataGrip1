-- =============================================
-- Author:		Sahirely Yam
-- Create date: 25 07 2017
-- =============================================
create PROCEDURE [dbo].[UPD_CANCELA_PARTIDAS_PREORDEN_SP] 
	@idCotizacion numeric(18,0),
	@idPartida numeric(18,0)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY  
		UPDATE [dbo].[CotizacionDetalle]
		SET [idEstatusPartida] = 4
		WHERE [idCotizacion] = @idCotizacion and [idPartida] = @idPartida

		SELECT 'Se canceló la partida de la PreOrden' msg
	END TRY  
	BEGIN CATCH  
		 SELECT 'No se pudo cancelar la partida de la PreOrden' msg 
	END CATCH 
    

END
go

