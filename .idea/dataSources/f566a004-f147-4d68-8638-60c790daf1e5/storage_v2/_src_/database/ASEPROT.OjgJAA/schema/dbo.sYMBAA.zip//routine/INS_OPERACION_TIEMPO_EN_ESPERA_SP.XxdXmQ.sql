-- =============================================
-- Author:		Anel Candi Pérez Pérez
-- Create date: 18/05/2017
-- Description:	Inserta la relacion de operacion con el contrato de la licitación
-- INS_CONTRATO_OPERACION_SP 3, 1
-- =============================================
 CREATE PROCEDURE [dbo].[INS_OPERACION_TIEMPO_EN_ESPERA_SP]
	 @idOperacion int
	,@idEstatusOrden int
	,@tiempoEnEspera nvarchar(50)
AS
BEGIN

	IF NOT EXISTS (SELECT 1 FROM OperacionTiempoEnEspera WHERE idOperacion=@idOperacion AND idEstatusOrden=@idEstatusOrden)
		  BEGIN
			 INSERT INTO OperacionTiempoEnEspera VALUES(@idOperacion,@idEstatusOrden,@tiempoEnEspera)
				SELECT 1
		  END
	  ELSE
		  BEGIN
			  UPDATE OperacionTiempoEnEspera
			  SET tiempoEnEspera=@tiempoEnEspera
			  WHERE idOperacion=@idOperacion AND idEstatusOrden=@idEstatusOrden
				SELECT 2
		  END
END


go

