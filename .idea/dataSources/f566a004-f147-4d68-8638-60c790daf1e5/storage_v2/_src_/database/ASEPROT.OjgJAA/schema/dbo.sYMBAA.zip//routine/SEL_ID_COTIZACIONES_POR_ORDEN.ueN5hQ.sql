-- EXEC [dbo].[SEL_ID_COTIZACIONES_POR_ORDEN] '01-3010245-120',109,1
CREATE PROCEDURE [dbo].[SEL_ID_COTIZACIONES_POR_ORDEN]
	@numOrden varchar(50),
	@idUsuario INT,
	@idContratoOperacion INT
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @idOperacion int = (select idOperacion from ContratoOperacion where idContratoOperacion = @idContratoOperacion)

	IF [dbo].[GET_USUARIO_ROL_ID_FN] (@idUsuario,@idOperacion) <> 4
		BEGIN
			SELECT 
				idCotizacion, 
				numeroCotizacion, 
				CASE idEstatusCotizacion WHEN 1 THEN 0 WHEN 2 THEN 50 WHEN 3 THEN 100 WHEN 4 THEN 100 END AS Porcentaje
			FROM [dbo].[Cotizaciones] 
			INNER JOIN Ordenes AS Ord ON Ord.idOrden = Cotizaciones.idOrden
			WHERE Ord.numeroOrden = @numOrden
			ORDER BY consecutivoCotizacion
		END
	ELSE
		BEGIN
			declare @tablaProveedoresAsignados table(idProveedor int)
			insert into @tablaProveedoresAsignados
			select idProveedor from [dbo].[GET_PROVEEDORES_ASIGNADOS_FN](@idUsuario, @idOperacion)

			SELECT 
				idCotizacion, 
				numeroCotizacion, 
				CASE idEstatusCotizacion WHEN 1 THEN 0 WHEN 2 THEN 50 WHEN 3 THEN 100 WHEN 4 THEN 100 END AS Porcentaje
			FROM [dbo].[Cotizaciones] C
			INNER JOIN Ordenes AS Ord ON Ord.idOrden = C.idOrden
			WHERE Ord.numeroOrden = @numOrden AND (C.idEstatusCotizacion IN(5)
			OR C.idTaller in (select idProveedor from @tablaProveedoresAsignados))
			ORDER BY consecutivoCotizacion
		END
END

go

