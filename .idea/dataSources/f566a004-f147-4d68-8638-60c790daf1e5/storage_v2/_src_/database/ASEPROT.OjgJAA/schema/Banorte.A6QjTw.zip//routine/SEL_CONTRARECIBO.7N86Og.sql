-- =============================================
-- Author: Christian Ochoa Nicolas
-- Create date: 27-02-2019
-- Description: Obtiene el contra recibo a partir de una orden
-- Banorte.SEL_CONTRARECIBO 38594
-- =============================================
CREATE PROCEDURE Banorte.SEL_CONTRARECIBO
	@idOrden NUMERIC
AS
BEGIN
	SELECT C.numeroContraRecibo
		, CONVERT(VARCHAR(24), c.fechaContrarecibo, 103) AS fechaContraRecibo
	FROM Ordenes O
	LEFT JOIN DatosCopade D ON D.numeroCopade = O.numeroOrden
	LEFT JOIN ContrareciboDatosCopade CDC ON CDC.idDatosCopade = D.idDatosCopade
	LEFT JOIN Contrarecibo C ON C.idContrarecibo = CDC.idContrarecibo
	WHERE O.idOrden = @idOrden
END


go

grant execute, view definition on Banorte.SEL_CONTRARECIBO to DevOps
go

