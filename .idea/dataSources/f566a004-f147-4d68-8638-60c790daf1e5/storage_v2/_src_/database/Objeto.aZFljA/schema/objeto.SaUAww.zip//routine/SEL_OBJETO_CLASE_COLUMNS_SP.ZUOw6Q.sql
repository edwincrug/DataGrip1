-- =============================================
-- Author: Adolfo Martinez
-- Create date: 05-07-2019
-- Description: Consulta devuelve solicitudes dependiendo el paso
-- ============== Versionamiento ================
-- EXEC [objeto].[SEL_OBJETO_CLASE_COLUMNS_SP] 'ASE0508051B6','185','43','Automovil',1,''	
-- =============================================
CREATE PROCEDURE [objeto].[SEL_OBJETO_CLASE_COLUMNS_SP]
	@rfcEmpresa				VARCHAR(13),
	@idCliente				INT,
	@numeroContrato         VARCHAR(50),
	@idClase				VARCHAR(10),
	@idUsuario				INT,
	@err					VARCHAR(500)OUTPUT
AS


BEGIN

	DECLARE @columnas TABLE(caption VARCHAR(100),datafield VARCHAR(100),datatype VARCHAR(100),orden INT, bloque INT)

	insert into @columnas values('Id','idObjeto','String',1,1)
	insert into @columnas values('Foto Principal','FotoPrincipal','Foto',2,1)
	insert into @columnas SELECT caption,campo,tipoDato,orden,2 FROM Common.reporte.Objeto WHERE idClase=@idClase ORDER BY orden ASC
	insert into @columnas values('ID GPS','ID GPS','String',1,3)
	insert into @columnas values('Estatus objeto','estatus','String',2,3)

	SELECT * FROM @columnas ORDER BY bloque,orden ASC

END
go

