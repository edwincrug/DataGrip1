-- ==================================	===========
-- Author:		<Sandra Gil Rosales>
-- Create date: <24-06-2019>
-- Description:	<Obtener los registros de un operador especifico >
	/*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [operador].[SEL_OPERADOR_DATOSPORID_SP] 
	@idUsers = 6109,
	@numContrato = '123PEMEX',
	@idUsuario = 2 ,
	@err = @salida OUTPUT;
	SELECT @salida
*/
-- =========================================r====
CREATE PROCEDURE [operador].[SEL_OPERADOR_DATOSPORID_SP] 
@idUsers				int,
@numContrato			varchar (50),
@idUsuario				int,
@err					varchar(max) OUTPUT

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	 SET @err = '';

    -- Insert statements for procedure here
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [idUsers]
      ,[idEstatus]
	  ,us.PrimerNombre
	  ,us.SegundoNombre
	  , us.PrimerApellido
	  , us.SegundoApellido
	  , us.Avatar
      ,op.[fechaRegistro]
      ,op.[idPais]
      ,op.[idEstado]
      ,op.[idMunicipio]
      ,[codigoPostal]
      ,op.[idTipoAsentamiento]
      ,[asentamiento]
      ,op.[idTipoVialidad]
      ,[vialidad]
      ,[numeroExterior]
      ,[numeroInterior]
      ,[latitud]
      ,[longitud]
      ,op.[idUsuario]
      ,[activo]
	  , p.nombre AS paisNombre
	  , es.nombre AS estadoNombre
	  , mun.nombre AS municipioNombre
	  , ase.nombre AS asentamientoTipo
	  , tv.nombre AS vialidadTipo
	  ,op.idTipo
  FROM [Objeto].[operador].[Operador] AS op 
 LEFT JOIN Seguridad.Catalogo.Users AS us ON op.idUsers = us.Id
 LEFT JOIN Common.direccion.Pais AS p ON op.idPais = p.idPais
 LEFT JOIN Common.direccion.Estado AS es ON op.idEstado = es.idEstado AND op.idPais = es.idPais
 LEFT JOIN Common.direccion.Municipio AS mun 
		ON op.idEstado = mun.idEstado AND op.idPais = mun.idPais AND op.idMunicipio = mun.idMunicipio
LEFT JOIN Common.direccion.TipoAsentamiento as ase ON op.idTipoAsentamiento = ase.idTipoAsentamiento
LEFT JOIN Common.direccion.TipoVialidad AS tv ON op.idTipoVialidad = tv.idTipoVialidad
WHERE op.activo = 1 AND idUsers = @idUsers

SELECT [idUsers]
      ,oa.[idTipoObjeto]
      ,oa.[idObjeto]
      ,[idAsignacion]
      ,[fechaAsignacion]
      ,[odometroAsignacion]
      ,[idFileAsignacion]
      ,[fechaEntrega]
      ,[odometroEntrega]
      ,[idFileEntrega]
	  , CASE WHEN [fechaEntrega] IS NULL  THEN 'Asignado'
		ELSE 'Entregado' END AS estatus
	  ,[verGps]
  FROM [Objeto].[operador].[Asignacion] AS oa
  LEFT JOIN [Cliente].[contrato].[Objeto] AS co ON oa.idTipoObjeto = co.idTipoObjeto AND oa.idObjeto = co.idObjeto
  WHERE [idUsers] = @idUsers AND  co.numeroContrato = @numContrato
  ORDER BY oa.idTipoObjeto, oa.idObjeto, oa.fechaAsignacion

END
go

