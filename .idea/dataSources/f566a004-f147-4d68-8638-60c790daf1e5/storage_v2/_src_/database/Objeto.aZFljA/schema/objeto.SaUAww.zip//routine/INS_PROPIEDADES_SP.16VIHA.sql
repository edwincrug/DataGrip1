-- =============================================
-- Author:		Sandra Gil Rosales
-- Create date: 12/09/2019
-- Description:Insertar una propiedad, clase, contrato o general
-- =============================================
/*
	Objetivo: Inserta una módulo

	------TEST
		*- Testing...
	EXEC
	[objeto].[INS_PROPIEDADES_SP]

@idClase= 'Automovil',
@idCliente= 92,
@numeroContrato= '0001',
@rfcEmpresa= 'ASE0508051B6',
@idPadre= 0,
@idTipoDato= 'Numeric',
@idTipoValor= 'Unico',
@obligatorio= true,
@orden= 3,
@activo= 1,
@posicion= 2,
@propiedad= 'contrato',
@valor= 'propiedadContrato'

	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición

*/
CREATE PROCEDURE [objeto].[INS_PROPIEDADES_SP]
	@idClase			varchar(13) = NULL ,
    @idCliente			INT = 0,
	@numeroContrato		nvarchar(10) = NULL,
	@rfcEmpresa			varchar(13) = NULL ,
	@idPadre			INT,
	@idTipoDato			nvarchar(10),
	@idTipoValor		nvarchar(10),
	@obligatorio		bit,
	@orden				INT,
	@activo				bit,
	@posicion			INT,
	@propiedad			nvarchar(10),
	@valor				nvarchar(250),
	@idUsuario			INT,
	@err				varchar(max) OUTPUT
		
AS
BEGIN
	
	DECLARE @msj		varchar(50) = '', 
			@VC_ErrorMessage	VARCHAR(4000)	= '',
			@VC_ThrowMessage	VARCHAR(100)	= 'An error has occured on [INS_PROPIEDADES]:',
			@VC_ErrorSeverity	INT = 0,
			@VC_ErrorState		INT = 0,
			@status		int = 0,
			@propiedadId	int = 0

/********************************************* INSERTA EN TABLA DE PROPIEDADES *********************/

	IF EXISTS(SELECT * FROM ( SELECT [idPropiedadClase] ,[valor] ,'clase'AS prop, activo
									FROM [Objeto].[objeto].[PropiedadClase]
								  UNION ALL
									SELECT [idPropiedadGeneral] ,[valor] ,'general', activo
									FROM [Objeto].[objeto].[PropiedadGeneral]
								  UNION ALL
									  SELECT [idPropiedadContrato] ,[valor] ,'contrato' , activo
									  FROM [Objeto].[objeto].[PropiedadContrato] ) propiedades
					WHERE LOWER(Valor) = LOWER(@valor) AND prop = @propiedad AND activo = 1)
		BEGIN
			SET @msj = 'El nombre de la propiedad ya existe';
			SET @propiedadId = (SELECT idPropiedadClase FROM ( SELECT [idPropiedadClase] ,[valor] ,'clase' AS prop
									FROM [Objeto].[objeto].[PropiedadClase]
								  UNION ALL
									SELECT [idPropiedadGeneral] ,[valor] ,'general'
									FROM [Objeto].[objeto].[PropiedadGeneral]
								  UNION ALL
									  SELECT [idPropiedadContrato] ,[valor] ,'contrato' 
									  FROM [Objeto].[objeto].[PropiedadContrato] ) propiedades
							WHERE LOWER(Valor) = LOWER(@valor))
		END
	ELSE
		BEGIN TRY
			BEGIN TRANSACTION INS_PROPIEDADES
			-- propiedad general
			IF @propiedad = 'general'
				BEGIN
				INSERT INTO [objeto].[PropiedadGeneral]
				VALUES
					(CASE WHEN (@idTipoValor = 'Unico' OR @idTipoValor = 'Etiqueta') THEN NULL
							ELSE @idPadre
							END
					,@idTipoValor
					,@idTipoDato
					,CASE WHEN (@idTipoValor = 'Unico' OR @idTipoValor = 'Etiqueta') THEN @valor
						ELSE (SELECT TOP 1 agrupador FROM [objeto].[PropiedadGeneral] WHERE idPropiedadGeneral = @idPadre)
						END
					,@valor
					,@obligatorio
					,@orden
					,@activo
					,@posicion)

				set @status = 1;
				SET @propiedadId = SCOPE_IDENTITY();
				SET @msj = 'La propiedad se agrego correctamente';
				END 
			-- propiedad clase
			IF @propiedad = 'clase'
				BEGIN
				INSERT INTO [objeto].[PropiedadClase]
				VALUES
					(@idClase
					,CASE WHEN (@idTipoValor = 'Unico' OR @idTipoValor = 'Etiqueta') THEN NULL
							ELSE @idPadre
							END
					,@idTipoValor
					,@idTipoDato
					,CASE WHEN (@idTipoValor = 'Unico' OR @idTipoValor = 'Etiqueta') THEN @valor
						ELSE (SELECT TOP 1 agrupador FROM [objeto].[PropiedadClase] WHERE idPropiedadClase = @idPadre)
						END
					,@valor
					,@obligatorio
					,@orden
					,@activo
					,@posicion)
				set @status = 1;
				SET @propiedadId = SCOPE_IDENTITY();
				SET @msj = 'La propiedad se agrego correctamente';
				END 
			-- propiedad contrato
			IF @propiedad = 'contrato'
				BEGIN
				INSERT INTO [objeto].[PropiedadContrato]
				VALUES
					(@rfcEmpresa
					,@idCliente
					,@numeroContrato
					,CASE WHEN (@idTipoValor = 'Unico' OR @idTipoValor = 'Etiqueta') THEN NULL
							ELSE @idPadre
							END
					,@idTipoValor
					,@idTipoDato
					,CASE WHEN (@idTipoValor = 'Unico' OR @idTipoValor = 'Etiqueta') THEN @valor
							ELSE (SELECT TOP 1 agrupador FROM [objeto].[PropiedadContrato] WHERE idPropiedadContrato = @idPadre)
							END
					,@valor
					,@obligatorio
					,@orden
					,@activo
					,@posicion)

				set @status = 1;
				SET @propiedadId = SCOPE_IDENTITY();
				SET @msj = 'La propiedad se agrego correctamente';
				END 



			COMMIT TRANSACTION INS_PROPIEDADES
		END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION INS_PROPIEDADES
				SET @msj = 'Error al registar la propiedad';
				SET @VC_ErrorMessage = {
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage)
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
			END
		END CATCH
	SELECT 
		@msj				AS [Message], 
		@status				AS [Insertado],
		@propiedadId			AS [PropiedadId];

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

