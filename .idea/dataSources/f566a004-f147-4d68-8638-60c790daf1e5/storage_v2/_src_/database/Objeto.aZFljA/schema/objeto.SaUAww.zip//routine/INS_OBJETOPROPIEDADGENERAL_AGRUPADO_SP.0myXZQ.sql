
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <20-03-2019>
-- Description:	<insercion en las tablas de objeto propiedades>
-- =============================================
/*
	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC  [objeto].[ObjetoPropiedadClase],
		[objeto].[ObjetoPropiedadContrato],
		[objeto].[ObjetoPropiedadGeneral]
		@idObjeto = 2,

		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [objeto].[INS_OBJETOPROPIEDADGENERAL_AGRUPADO_SP]
	@idObjeto				int,
	@vigencia				datetime = NULL,
	@typeTable				int,
	@err					varchar(max) OUTPUT,
-- INSERT TABLA PROPIEDADCLASE
	@idPropiedadClase		int,
	@valorPCl				nvarchar(500),
	@activoPCl				bit,
-- INSERT TABLA PROPIEDADCONTRATO
	@idPropiedadContrato	int,
	@valorPC				nvarchar(500),
	@activoPC				bit,
-- INSERT TABLA PROPIEDADGENERAL
	@idPropiedadGeneral		int,
	@valorPG				nvarchar(500),
	@activoPG				bit


AS
BEGIN TRY
     BEGIN TRANSACTION
	 SET @err = '';
	 IF (@typeTable = 1)
	 BEGIN
			INSERT INTO [objeto].[ObjetoPropiedadContrato]
           ([idObjeto]
           ,[idPropiedadContrato]
           ,[valor]
           --,[vigencia]
           ,[activo])
     VALUES
           (@idObjeto
           ,@idPropiedadContrato
           ,@valorPC
           --,@vigencia
           ,@activoPC)
	 END
    ELSE IF (@typeTable = 2)
	BEGIN
	 INSERT INTO [objeto].[ObjetoPropiedadClase]
           ([idObjeto]
           ,[idPropiedadClase]
           ,[valor]
           --,[vigencia]
           ,[activo])
		VALUES
           (@idObjeto
           ,@idPropiedadClase
           ,@valorPCl
           --,@vigencia
           ,@activoPCl)
	 END
    ELSE IF (@typeTable = 3)
	 BEGIN
	INSERT INTO [objeto].[ObjetoPropiedadGeneral]
           ([idObjeto]
           ,[idPropiedadGeneral]
           ,[valor]
           --,[vigencia]
           ,[activo])
		VALUES
           (@idObjeto
           ,@idPropiedadGeneral
           ,@valorPG
           --,@vigencia
           ,@activoPG)
	END
	RETURN SCOPE_IDENTITY();
END TRY
BEGIN CATCH
ROLLBACK TRANSACTION
END CATCH
go

