-- =============================================
-- Author:		José Etmanuel Hernández Rejón 
-- Create date: 23/04/2019
-- Description:	Obtiene el listado de documentos por objeto
-- =============================================
/*
	Fecha:03/06/2019		Sandra Gil Rosales 
	* Modificación de columnas y se agregaron tablas para ser  modificadas y consultadas 
												
	--2019

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [objeto].[INS_OBJETODOCUMENTO_SP]
		@tipo = 'clase',
		@idClase = 'Automovil',
		@idTipoObjeto = 92,
		@idDocumento = 25,
		@idObjeto = 82,
		@idTipoDocumento = '.jpg',
		@idFileServer= null,
		@idLineaCaptura= null,
		@vigencia = '2019-04-01',
		@valor = '',
		@costo = 0,
		@costoPagado = true,
		@idEstado = 02,
		@idUsuario = 6077,
		@err = @salida OUTPUT;
	
*/
-- =============================================

CREATE PROCEDURE [objeto].[INS_OBJETODOCUMENTO_SP]
	@tipo				VARCHAR(30),
	@idClase			VARCHAR (10),
	@idTipoObjeto		INT,
	@idDocumento		INT,
	@idObjeto			INT,
	@idTipoDocumento	VARCHAR(20),
	@idFileServer		INT = NULL,
	@vigencia			DATETIME,
	@valor				VARCHAR(500),
	@costo				VARCHAR(200)= NULL,
	@idEstado			INT,
	@comentario			varchar(max) = NULL,
	@idUsuario			INT,
-- variables para la tabla de costos
	@costoPagado		BIT = false,
	@idConcepto			INT = 0,
	@idLineaCaptura		INT = 0,
	@idFacturaPDF		INT = 0,
	@idFacturaXML		INT =  0,
	@err				varchar(max) OUTPUT
AS 
BEGIN

	SET @err = '';
	DECLARE @idCostoDocumentoGeneral INT;
	DECLARE @idCostoDocumentoClase INT;
	DECLARE @idCostoDocumentoContrato INT;
	DECLARE @activo INT = 1;
	DECLARE @version INT;

	IF @tipo = 'general'
	BEGIN
		SELECT @version = (isnull((select top 1 [version] from [documento].[DocumentoObjetoGeneral] 
								where  [idDocumentoGeneral] =@idDocumento 
									AND [idClase] = @idClase
									AND [idTipoObjeto] = @idTipoObjeto
									AND [idObjeto]=@idObjeto 
								order by [version] desc),-1) +1)
	-- Insertamos el costo de el documento
	IF (@idConcepto > 0 AND @costo is not null )
	BEGIN
	SET @version = isnull((select top 1 [version] 
				from [documento].[DocumentoObjetoGeneral] 
				where [idDocumentoGeneral]=@idDocumento AND [idObjeto]=@idObjeto 
				order by [version] desc),-1) +1  

	INSERT INTO [documento].[CostoDocumentoGeneral]
			   ([idDocumentoGeneral]
			   ,[idClase]
			   ,[idTipoObjeto]
			   ,[idObjeto]
			   ,[version]
			   ,[idConcepto]
			   ,[costo]
			   ,[idLineaCaptura]
			   ,[idFacturaPDF]
			   ,[idFacturaXML]
			   ,[idUsuario]
			   ,[activo]
			   ,[pagado])
		 VALUES
			   (@idDocumento
			   ,@idClase
			   ,@idTipoObjeto
			   ,@idObjeto
			   ,@version				   
			   ,@idConcepto
			   ,@costo
			   ,@idLineaCaptura
			   ,@idFacturaPDF
			   ,@idFacturaXML
			   ,@idUsuario
			   ,@activo
			   ,@costoPagado)
		SET @idCostoDocumentoGeneral = @@IDENTITY  
		END

		INSERT INTO [documento].[DocumentoObjetoGeneral]
				   ([idDocumentoGeneral]
				   ,[idClase]
				   ,[idTipoObjeto]
				   ,[idObjeto]
				   ,[version]
				   ,[idTipoDocumento]
				   ,[idFileServer]
				   ,[vigencia]
				   ,[valor]
				   ,[idUsuario]
				   ,[fecha]
				   ,[idCostoDocumentoGeneral]
				   ,[idEstado]
				   ,[comentario])
			 VALUES
				   (@idDocumento
				   ,@idClase
				   ,@idTipoObjeto
				   ,@idObjeto
				   ,@version
				   ,@idTipoDocumento
				   ,@idFileServer
				   ,@vigencia
				   ,@valor
				   ,@idUsuario
				   ,GETDATE()
				   ,@idCostoDocumentoGeneral
				   ,@idEstado
				   ,@comentario)
-- validamos si esta propiedad ya esta guardada si es asi solo actualizamos el usuario 
		IF NOT EXISTS (SELECT op.idObjeto FROM [Objeto].[objeto].[ObjetoPropiedadGeneral] as op
		LEFT JOIN [Objeto].[objeto].[PropiedadGeneral] as p ON op.idPropiedadGeneral = p.idPropiedadGeneral
				WHERE op.idClase = @idClase AND  op.idTipoObjeto = @idTipoObjeto 
				AND op.idObjeto = @idObjeto AND op.valor = @idDocumento 
				AND p.idTipoDato = 'Documento' AND op.activo = 1 AND p.activo = 1 ) 
			BEGIN
		-- Guardar en la tabla de propiedades General 
				INSERT INTO [objeto].[ObjetoPropiedadGeneral]
						   ([idPropiedadGeneral]
						   ,[idClase]
						   ,[idTipoObjeto]
						   ,[idObjeto]
						   ,[valor]
						   ,[idUsuario]
						   ,[activo])	
					(SELECT  [idPropiedadGeneral]
							,@idClase
							,@idTipoObjeto
							,@idObjeto
							,@idDocumento
							,@idUsuario
							,@activo
							FROM
							[Objeto].[objeto].[PropiedadGeneral]
								WHERE idTipoDato = 'Documento' AND valor = ( SELECT [nombre]
								FROM [Objeto].[documento].[DocumentoGeneral]
								WHERE idDocumentoGeneral = @idDocumento))

			END
	END ELSE
	IF @tipo = 'clase'
	BEGIN
	SELECT @version = (isnull((select top 1 [version] from [documento].[DocumentoObjetoClase] 
								where  [idDocumentoClase]=@idDocumento 
									AND [idClase] = @idClase
									AND [idTipoObjeto] = @idTipoObjeto
									AND [idObjeto]=@idObjeto 
								order by [version] desc),-1) +1)
	-- Insertamos el costo de el documento clase
		IF (@idConcepto > 0 AND @costo is not null )
			BEGIN
			
				INSERT INTO [documento].[CostoDocumentoClase]
						   ([idDocumentoClase]
						   ,[idClase]
						   ,[idTipoObjeto]
						   ,[idObjeto]
						   ,[version]
						   ,[idConcepto]
						   ,[costo]
						   ,[idLineaCaptura]
						   ,[idFacturaPDF]
						   ,[idFacturaXML]
						   ,[idUsuario]
						   ,[activo]
						   ,[pagado])
					 VALUES
						   (@idDocumento
							,@idClase
							,@idTipoObjeto
							,@idObjeto
							,@version			   
						   ,@idConcepto
						   ,@costo
						   ,@idLineaCaptura
						   ,@idFacturaPDF
						   ,@idFacturaXML
						   ,@idUsuario
						   ,@activo
						   ,@costoPagado)
					SET @idCostoDocumentoClase = @@IDENTITY
			END	
				INSERT INTO [documento].[DocumentoObjetoClase]
						   ([idDocumentoClase]
						   ,[idClase]
						   ,[idTipoObjeto]
						   ,[idObjeto]
						   ,[version]
						   ,[idTipoDocumento]
						   ,[idFileServer]
						   ,[vigencia]
						   ,[valor]
						   ,[idUsuario]
						   ,[fecha]
						   ,[idCostoDocumentoClase]
						   ,[idEstado]
						   ,[comentario])
					 VALUES
						   (@idDocumento
						   ,@idClase
						   ,@idTipoObjeto
						   ,@idObjeto
						   ,@version
						   ,@idTipoDocumento
						   ,ISNULL(@idFileServer,17268)
						   ,@vigencia
						   ,@valor
						   ,@idUsuario
						   ,GETDATE()
						   ,@idCostoDocumentoClase
						   ,@idEstado
						   ,@comentario
						   )
-- validamos si esta propiedad ya esta guardada si es asi solo actualizamos el usuario 
		IF NOT EXISTS (SELECT op.idObjeto FROM [Objeto].[objeto].[ObjetoPropiedadClase] as op
		LEFT JOIN [Objeto].[objeto].[PropiedadClase] as p ON op.idPropiedadClase = p.idPropiedadClase
				WHERE op.idClase = @idClase AND  op.idTipoObjeto = @idTipoObjeto 
				AND op.idObjeto = @idObjeto AND op.valor = @idDocumento 
				AND p.idTipoDato = 'Documento' AND op.activo = 1 AND p.activo = 1 ) 
			BEGIN
			-- buscamos el nombre de la propiedad para insertar en la tabla de propiedades
			INSERT INTO [objeto].[ObjetoPropiedadClase]
					   ([idClase]
					   ,[idPropiedadClase]
					   ,[idTipoObjeto]
					   ,[idObjeto]
					   ,[valor]
					   ,[idUsuario]
					   ,[activo])
				(SELECT  [idClase]
					,[idPropiedadClase]
					,@idTipoObjeto
					,@idObjeto
					,@idDocumento
					,@idUsuario
					,@activo
					FROM
					[Objeto].[objeto].[PropiedadClase]
						WHERE idTipoDato = 'Documento' AND valor = ( SELECT [nombre]
						FROM [Objeto].[documento].[DocumentoClase]
						WHERE idDocumentoClase = @idDocumento))
			END

	END ELSE
	IF @tipo = 'contrato'
	BEGIN
	SELECT @version = (isnull((select top 1 [version] from [documento].[DocumentoObjetoContrato] 
						where  [idDocumentoContrato] =@idDocumento 
							AND [idClase] = @idClase
							AND [idTipoObjeto] = @idTipoObjeto
							AND [idObjeto]=@idObjeto 
						order by [version] desc),-1) +1)
	-- Insertamos el costo de el documento
	IF (@idConcepto > 0 AND @costo is not null  )
	BEGIN
	INSERT INTO [documento].[CostoDocumentoContrato]
			   ([idDocumentoContrato]
			   ,[idClase]
			   ,[idTipoObjeto]
			   ,[idObjeto]
			   ,[version]
			   ,[idConcepto]
			   ,[costo]
			   ,[idLineaCaptura]
			   ,[idFacturaPDF]
			   ,[idFacturaXML]
			   ,[idUsuario]
			   ,[activo]
			   ,[pagado])
		 VALUES
				(@idDocumento
				,@idClase
				,@idTipoObjeto
				,@idObjeto
				,@version				   
				,@idConcepto
				,@costo
				,@idLineaCaptura
				,@idFacturaPDF
				,@idFacturaXML
				,@idUsuario
				,@activo
				,@costoPagado)
		SET @idCostoDocumentoContrato = @@IDENTITY
		END

		INSERT INTO [documento].[DocumentoObjetoContrato]
				   ([idDocumentoContrato]
				   ,[idClase]
				   ,[idTipoObjeto]
				   ,[idObjeto]
				   ,[version]
				   ,[idTipoDocumento]
				   ,[idFileServer]
				   ,[vigencia]
				   ,[valor]
				   ,[idUsuario]
				   ,[fecha]
				   ,[idEstado]
				   ,[idCostoDocumentoContrato]
				   ,[comentario])
			 VALUES
				   (@idDocumento
				   ,@idClase
				   ,@idTipoObjeto
				   ,@idObjeto
				   ,@version
				   ,@idTipoDocumento
				   ,@idFileServer
				   ,@vigencia
				   ,@valor
				   ,@idUsuario
				   ,GETDATE()
				   ,@idEstado
				   ,@idCostoDocumentoContrato
				   ,@comentario
				   )
-- validamos si esta propiedad ya esta guardada si es asi solo actualizamos el usuario 
		IF NOT EXISTS (SELECT op.idObjeto FROM [Objeto].[objeto].[ObjetoPropiedadContrato] as op
		LEFT JOIN [Objeto].[objeto].[PropiedadContrato] as p ON op.idPropiedadContrato = p.idPropiedadContrato
				WHERE op.idClase = @idClase AND  op.idTipoObjeto = @idTipoObjeto 
				AND op.idObjeto = @idObjeto AND op.valor = @idDocumento 
				AND p.idTipoDato = 'Documento' AND op.activo = 1 AND p.activo = 1 ) 
			BEGIN
		-- guardar en la tabla propiedades objeto contrato 
			INSERT INTO [objeto].[ObjetoPropiedadContrato]
					   ([rfcEmpresa]
					   ,[idCliente]
					   ,[numeroContrato]
					   ,[idPropiedadContrato]
					   ,[idClase]
					   ,[idTipoObjeto]
					   ,[idObjeto]
					   ,[valor]
					   ,[idUsuario]
					   ,[activo])
			(SELECT  rfcEmpresa
					,idCliente
					,numeroContrato
					,idPropiedadContrato
					,@idClase
					,@idTipoObjeto
					,@idObjeto
					,@idDocumento
					,@idUsuario
					,@activo
					FROM
					[Objeto].[objeto].[PropiedadContrato]
						WHERE idTipoDato = 'Documento' AND valor = ( SELECT [nombre]
						FROM [Objeto].[documento].[DocumentoContrato]
						WHERE idDocumentoContrato = @idDocumento))
			END

	END
	
	IF (@@ERROR = 0)

		BEGIN

		DECLARE @llave VARCHAR(MAX) = '{"idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '","idTipoObjeto":"' + CAST(@idTipoObjeto AS VARCHAR(50)) + 
		'","idFileServer":"' + CAST(@idFileServer AS VARCHAR(50)) + '"}'

			EXEC [evento].[evento].[INS_EVENTO]
			@accion = 1
			,@modulo = 171
			,@gerencia = 1
			,@llave = @llave
			,@origen = NULL
			,@applicationId = 11
			,@idEstado = NULL
			,@idContratoZona = NULL
			,@idUsuario = @idUsuario
			,@err = ''
		END

	select 'ok' as ok;
END


go

