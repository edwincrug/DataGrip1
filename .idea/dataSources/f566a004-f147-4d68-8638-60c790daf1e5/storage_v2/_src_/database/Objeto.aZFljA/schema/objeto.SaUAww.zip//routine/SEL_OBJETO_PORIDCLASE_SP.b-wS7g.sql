-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <19-03-2019>
-- Description:	<Obtener los registros de los objetos junto con el tipo de 
-- objeto por el tipo clase >
-- =============================================

/*

	------ Versionamiento
	Fecha 		Autor	Descrición

	testing

		[objeto].[SEL_OBJETO_PORIDCLASE_SP] 'Automovil', '43',99, 6036,null
		[objeto].[SEL_OBJETO_PORIDCLASE_SP] 'Automovil', '43',185, 4482,null

		select * from cliente.cliente.contrato ORDER BY NOMBRE ASC where NOMBRE LIKE ''
*/

CREATE PROCEDURE [objeto].[SEL_OBJETO_PORIDCLASE_SP]
      @idClase				varchar(20),
	  @numeroContrato		varchar(50),
	  @idCliente			int,
	  @idUsuario			int = null,
	  @err					varchar(max) OUTPUT
AS
BEGIN
	DECLARE @TablaZonaFinal	VARCHAR(50)= 'tmpZonas_'+CAST(@idUsuario AS VARCHAR)+CAST(DATEPART(MINUTE,GETDATE()) AS VARCHAR)+CAST(DATEPART(SECOND,GETDATE()) AS VARCHAR) 
	DECLARE @tmpObjeto		VARCHAR(50)= 'tmpObjeto_'+CAST(@idUsuario AS VARCHAR)+CAST(DATEPART(MINUTE,GETDATE()) AS VARCHAR)+CAST(DATEPART(SECOND,GETDATE()) AS VARCHAR) 
	DECLARE @tmpTipoObjeto	VARCHAR(50)= 'tmpTipoObjeto_'+CAST(@idUsuario AS VARCHAR)+CAST(DATEPART(MINUTE,GETDATE()) AS VARCHAR)+CAST(DATEPART(SECOND,GETDATE()) AS VARCHAR) 

	IF OBJECT_ID('tempdb..#propiedadesTipoObjeto') IS NOT NULL DROP TABLE #propiedadesTipoObjeto
	IF OBJECT_ID('tempdb..#propiedadesOrdenasTipoObjeto') IS NOT NULL DROP TABLE #propiedadesOrdenasTipoObjeto
	IF OBJECT_ID('tempdb..#propiedadesObjeto') IS NOT NULL DROP TABLE #propiedadesObjeto
	IF OBJECT_ID('tempdb..#tablaDatosZonas') IS NOT NULL DROP TABLE #tablaDatosZonas

	--*************************************************************************** ZONA OBJETO ******************************************************
	DECLARE @sq				VARCHAR(MAX)= '',
			@camposPivotKey	VARCHAR(200)= 'idTIpoObjetoZona,idObjetoZona',
			@camposIndex	VARCHAR(200)= '[idTIpoObjetoZona],',
			@camposPivot	VARCHAR(300)= ISNULL(STUFF((SELECT ',' + QUOTENAME(descripcion) 
														FROM	Common.gerencia.ContratoNivel 
														WHERE	idCliente=@idCliente and numeroContrato=@numeroContrato and activo =1 ORDER BY orden ASC  FOR XML PATH('')),1,1,''),'sinCoinicidencia')
	
	CREATE TABLE #tablaDatosZonas(idTipoObjetoZona INT, idObjetoZona INT,agrupador VARCHAR(100),valor VARCHAR(100),orden INT)
	
	;WITH	catalogos AS(
	SELECT	cco.idTipoObjeto					idTipoObjetoZona,
			cco.idObjeto						idObjetoZona,
			cz.descripcionNivel					agrupador,
			ISNULL(cz.descripcion,'')		valor,
			cz.idPadre						idPadre,
			cz.orden						orden
	FROM	cliente.contrato.Objeto cco
	INNER	JOIN [Common].[gerencia].[SEL_ZONAS_CONTRATOS_VW] cz ON cz.rfcEmpresa=cco.rfcEmpresa AND cz.idCliente=cco.idCliente AND  cz.numeroContrato=cco.numeroContrato AND cz.idContratoZona=cco.idContratoZona
	WHERE	cco.idClase = @idClase 
	AND		cco.activo	= 1 
	AND		cz.idCliente=@idCliente 
	AND		cz.numeroContrato=@numeroContrato
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	SELECT	cat.idTipoObjetoZona			idTipoObjetoZona,
			cat.idObjetoZona				idObjetoZona,
			prc.descripcionNivel					agrupador,
			ISNULL(prc.descripcion,'')		valor,
			prc.idPadre						idPadre,
			prc.orden						orden
	FROM	[Common].[gerencia].[SEL_ZONAS_CONTRATOS_VW] prc 
	INNER	JOIN catalogos cat ON cat.idPadre = prc.idContratoZona 
	WHERE	prc.idCliente=@idCliente AND prc.numeroContrato=@numeroContrato	AND prc.activo = 1)

	INSERT INTO #tablaDatosZonas
	SELECT	cat.idTIpoObjetoZona,cat.idObjetoZona,cat.agrupador,cat.valor,cat.orden
	FROM	catalogos cat 
	order	by cat.idObjetoZona asc

	SET @sq ='SELECT r.* INTO ' + @TablaZonaFinal + ' FROM (select '+@camposPivotKey+',agrupador,valor from #tablaDatosZonas) AS tx PIVOT (max(valor) for agrupador in ('+@camposPivot+')) as r '
	EXEC(@sq)

	--*************************************************************************** END ZONA OBJETO ******************************************************
	SET @sq = ' CREATE NONCLUSTERED INDEX [idx_1001] ON [dbo].['+@TablaZonaFinal+'] '
	SET @sq +=' ([idObjetoZona] ASC) '
	SET @sq +=' INCLUDE('+@camposIndex+@camposPivot+') WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY] '
	print @sq
	EXEC(@sq)
    --*************************************************************************** PROPIEDADES TIPO OBJETO ******************************************************
	
	CREATE TABLE #propiedadesTipoObjeto(
	idTipoObjeto		int,
	agrupador			varchar(500),
	valor				varchar(250),
	orden				int,
	posicion			int,
	ordenFinal			INT
)

/**********************************************************************************************************************
******************************************************CATALOGOS Y AGRUPADORES******************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with catalogos as(
	select	
		tob.idTipoObjeto				idTipoObjeto,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from 
	partida.tipoobjeto.TipoObjeto tob
	inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tob.idTipoObjeto = tpg.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1
	inner join partida.integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	where 
		prg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		and tob.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idTipoObjeto				idTipoObjeto,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from partida.tipoobjeto.PropiedadGeneral prg 
	inner join partida.integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	inner join catalogos cat on cat.idPadre = prg.idPropiedadGeneral
	and prg.activo = 1
	)
	insert into #propiedadesTipoObjeto
	select 
		cat.idTipoObjeto,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

--PROPIEDADES DE CLASE
;with catalogos as(
	select
		tob.idTipoObjeto				idTipoObjeto,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from 
	partida.tipoobjeto.TipoObjeto tob
	inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tob.idTipoObjeto = tpc.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.idClase = @idClase and prc.activo = 1
	where 
		prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		and tob.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idTipoObjeto				idTipoObjeto,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.tipoobjeto.PropiedadClase prc 
	inner join catalogos cat on cat.idPadre = prc.idPropiedadClase 
	WHERE prc.activo = 1
	)
	insert into #propiedadesTipoObjeto
	select 
		cat.idTIpoObjeto,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

	
/**********************************************************************************************************************
*********************************************************TAGS**********************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with tags as(
	select	
		tob.idTipoObjeto				idTipoObjeto,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prg.valor,'')			valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from 
	partida.tipoobjeto.TipoObjeto tob
	inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tob.idTipoObjeto = tpg.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1
	where prg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	and tob.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idTipoObjeto				idTipoObjeto,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prg.valor,'')			valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from partida.tipoobjeto.PropiedadGeneral prg 
	inner join tags tag on tag.idPadre = prg.idPropiedadGeneral
	WHERE prg.activo = 1
	)
	insert into #propiedadesTipoObjeto
	select distinct 
		idTipoObjeto,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idTipoObjeto = tags. idTipoObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

--PROPIEDADES CLASE
;with tags as(
	select	
		tob.idTipoObjeto				idTipoObjeto,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.tipoobjeto.TipoObjeto tob
	inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tob.idTipoObjeto = tpc.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.idClase = @idClase and prc.activo = 1
	where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	and tob.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idTipoObjeto				idTipoObjeto,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.tipoobjeto.PropiedadClase prc 
	inner join tags tag on tag.idPadre = prc.idPropiedadClase
	and prc.activo = 1
	)
	insert into #propiedadesTipoObjeto
	select distinct 
		idTipoObjeto,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idTipoObjeto = tags.idTipoObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

/**********************************************************************************************************************
***************************************************VALORES FIJOS*******************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
INSERT INTO #propiedadesTipoObjeto
select 
	pto.idTipoObjeto		idTipoObjeto,
	prg.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	tpg.valor				valor,
	prg.orden						orden,
	prg.posicion					posicion,
	0								ordenFinal
from partida.tipoobjeto.TipoObjeto pto 
inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tpg.idTipoObjeto = pto.idTipoObjeto
inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral and prg.activo = 1
where
	prg.idTipoValor = 'Unico'
	and pto.idClase = @idClase
	and pto.activo = 1

--PROPIEDADES DE CLASE
INSERT INTO #propiedadesTipoObjeto
select 
	pto.idTipoObjeto				idTipoObjeto,
	prc.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	tpc.valor				valor,
	prc.orden						orden,
	prc.posicion					posicion,
	1								ordenFinal
from partida.tipoobjeto.TipoObjeto pto 
inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tpc.idTipoObjeto = pto.idTipoObjeto
inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase and prc.idClase = @idClase and prc.activo = 1
where
	prc.idTipoValor = 'Unico'
	and pto.idClase = @idClase
	and pto.activo = 1



/**********************************************************************************************************************
******************************************************PIVOTE***********************************************************
**********************************************************************************************************************/
declare 
	@columnsNameTipoObjeto varchar(max) = ''

create table #propiedadesTipoObjetoOrdenas
	(
		agrupador			varchar(500),
		ordenFinal			int,
		posicion			int,
		orden				int
	)
insert into #propiedadesTipoObjetoOrdenas
select distinct 
	pr.agrupador,
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)
from #propiedadesTipoObjeto pr group by pr.agrupador order by 
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)


SET @columnsNameTipoObjeto = ISNULL(STUFF((SELECT ',' + QUOTENAME(prg.agrupador) 
						FROM #propiedadesTipoObjetoOrdenas prg 
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,''),'sinCoinicidencia')




--**************************************************************** PROPIEDADES DE OBJETO ***********************************************************************

--creamos tabla temporal para insertar las propiedades del tipo objeto dependiendo del tipo de valor
create table #propiedadesObjeto(
	idObjeto			int,
	idTipoObjeto		int,
	agrupador			varchar(500),
	valor				varchar(250),
	orden				int,
	posicion			int,
	ordenFinal			INT
)

/**********************************************************************************************************************
******************************************************CATALOGOS Y AGRUPADORES******************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with catalogos as(
	select	
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		oprg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		oprg.valor						valor,
		oprg.idPadre					idPadre,
		oprg.orden						orden,
		oprg.posicion					posicion,
		0								ordenFinal
	from 
	[Objeto].[objeto].[Objeto] obj 
	left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase 
	left join partida.tipoObjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.ObjetoPropiedadGeneral otpg on otpg.idObjeto = obj.idObjeto
	inner join objeto.objeto.PropiedadGeneral oprg on otpg.idPropiedadGeneral = oprg.idPropiedadGeneral and oprg.activo = 1
	inner join objeto.integridad.TipoDato otpd on otpd.idTipoDato = oprg.idTipoDato
	where 
		oprg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		and cco.numeroContrato = @numeroContrato
		and cco.idCliente = @idCliente
		and obj.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idObjeto					idObjeto,
		cat.idTipoObjeto				idTipoObjeto,
		oprg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		oprg.valor						valor,
		oprg.idPadre					idPadre,
		oprg.orden						orden,
		oprg.posicion					posicion,
		0								ordenFinal
	from objeto.objeto.PropiedadGeneral oprg 
	inner join objeto.integridad.TipoDato otpd on otpd.idTipoDato = oprg.idTipoDato 
	inner join catalogos cat on cat.idPadre = oprg.idPropiedadGeneral
	and oprg.activo = 1
	)
	insert into #propiedadesObjeto
	select 
		cat.idObjeto,
		cat.idTipoObjeto,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

--PROPIEDADES DE CLASE
;with catalogos as(
	select
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		oprc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre					idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from 
	objeto.objeto obj
	left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
	left join partida.tipoobjeto.TipoObjeto tob On tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objetoPropiedadClase otpc on obj.idObjeto = otpc.idObjeto
	inner join objeto.PropiedadClase oprc on otpc.idPropiedadClase = oprc.idPropiedadClase and oprc.idClase = @idClase and oprc.activo = 1
	where 
		oprc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		and cco.numeroContrato = @numeroContrato
		and cco.idCliente = @idCliente
		and obj.activo = 1
		
		
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idObjeto					idObjeto,
		cat.idTipoObjeto				idTipoObjeto,
		oprc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.PropiedadClase oprc 
	inner join catalogos cat on cat.idPadre = oprc.idPropiedadClase 
	WHERE oprc.activo = 1
	)
	insert into #propiedadesObjeto
	select 
		cat.idObjeto,
		cat.idTipoObjeto,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

--PROPIEDADES DE CONTRATO
;with catalogos as(
	select
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		oprc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre					idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from 
	objeto.objeto obj
	left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
	left join partida.tipoobjeto.TipoObjeto tob On tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objetoPropiedadContrato otpc on obj.idObjeto = otpc.idObjeto
	inner join objeto.PropiedadContrato oprc on otpc.idPropiedadContrato = oprc.idPropiedadContrato and oprc.activo = 1 and oprc.numeroContrato = @numeroContrato and oprc.idCliente = @idCliente
	AND otpc.idCliente = oprc.idCliente
	where 
		oprc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		and cco.numeroContrato = @numeroContrato
		and cco.idCliente = @idCliente
		
		and obj.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idObjeto					idObjeto,
		cat.idTipoObjeto				idTipoObjeto,
		oprc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.PropiedadContrato oprc 
	inner join catalogos cat on cat.idPadre = oprc.idPropiedadContrato 
	WHERE oprc.activo = 1
	and oprc.numeroContrato = @numeroContrato
	and idCliente = @idCliente
	)
	insert into #propiedadesObjeto
	select 
		cat.idObjeto,
		cat.idTipoObjeto,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

	
/**********************************************************************************************************************
*********************************************************TAGS**********************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with tags as(
	select	
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		oprg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprg.valor,'')			valor,
		oprg.idPadre						idPadre,
		oprg.orden						orden,
		oprg.posicion					posicion,
		0								ordenFinal
	from 
	objeto.objeto obj
	left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
	left join partida.tipoobjeto.TipoObjeto tob On tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.objetoPropiedadGeneral otpg on obj.idObjeto = otpg.idObjeto
	inner join objeto.objeto.PropiedadGeneral oprg on otpg.idPropiedadGeneral = oprg.idPropiedadGeneral and oprg.activo = 1
	where oprg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	and cco.numeroContrato = @numeroContrato
	and cco.idCliente = @idCliente
	and obj.activo = 1
	and oprg.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idObjeto					idObjeto,
		tag.idTipoObjeto				idTipoObjeto,
		oprg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprg.valor,'')			valor,
		oprg.idPadre						idPadre,
		oprg.orden						orden,
		oprg.posicion					posicion,
		0								ordenFinal
	from objeto.objeto.PropiedadGeneral oprg 
	inner join tags tag on tag.idPadre = oprg.idPropiedadGeneral
	WHERE oprg.activo = 1
	)
	insert into #propiedadesObjeto
	select distinct 
		idObjeto,
		idTipoObjeto,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idObjeto = tags.idObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

--PROPIEDADES CLASE
;with tags as(
	select	
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		oprc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto obj 
	left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
	left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.objetoPropiedadClase otpc on obj.idObjeto = otpc.idObjeto
	inner join objeto.objeto.PropiedadClase oprc on otpc.idPropiedadClase = oprc.idPropiedadClase and oprc.idClase = @idClase and oprc.activo = 1 
	where oprc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	and cco.numeroContrato = @numeroContrato
	and cco.idCliente = @idCliente
	and obj.activo = 1
	and oprc.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idObjeto					idObjeto,
		tag.idTipoObjeto				idTipoObjeto,
		oprc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto.PropiedadClase oprc 
	inner join tags tag on tag.idPadre = oprc.idPropiedadClase
	and oprc.activo = 1
	)
	insert into #propiedadesObjeto
	select distinct 
		idObjeto,
		idTipoObjeto,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idObjeto = tags.idObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags


--PROPIEDADES CONTRATO
;with tags as(
	select	
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		oprc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto obj 
	left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
	left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.objetoPropiedadContrato otpc on obj.idObjeto = otpc.idObjeto
	inner join objeto.objeto.PropiedadContrato oprc on otpc.idPropiedadContrato = oprc.idPropiedadContrato and oprc.activo = 1 and oprc.numeroContrato = @numeroContrato and oprc.idCliente = @idCliente
	AND  oprc.idCliente = otpc.idCliente
	where oprc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	and obj.activo = 1
	and cco.numeroContrato = @numeroContrato
	and cco.idCliente = @idCliente

	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idObjeto					idObjeto,
		tag.idTipoObjeto				idTipoObjeto,
		oprc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto.PropiedadContrato oprc 
	inner join tags tag on tag.idPadre = oprc.idPropiedadContrato
	and oprc.activo = 1
	and oprc.numeroContrato = @numeroContrato
	and idCliente = @idCliente
	)
	insert into #propiedadesObjeto
	select distinct 
		idObjeto,
		idTipoObjeto,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idObjeto = tags.idObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags


--/**********************************************************************************************************************
--***************************************************VALORES FIJOS*******************************************************
--**********************************************************************************************************************/
----PROPIEDADES GENERALES
INSERT INTO #propiedadesObjeto
select 
	obj.idObjeto					idObjeto,
	tob.idTipoObjeto				idTipoObjeto,
	oprg.valor						agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	CASE 
		WHEN oprg.idTipoDato in ('Image', 'Pdf', 'Documento' )  THEN (SELECT valor 
																		FROM Common.configuracion.configuracion 
																		where nombre = 'fileServer') + (select path from FileServer.documento.Documento where idDocumento = otpg.valor) 
		ELSE otpg.valor	END			valor,
	oprg.orden						orden,
	oprg.posicion					posicion,
	0								ordenFinal
from objeto.objeto obj 
left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
inner join objeto.objeto.ObjetoPropiedadGeneral otpg on otpg.idObjeto = obj.idObjeto
inner join objeto.objeto.PropiedadGeneral oprg on otpg.idPropiedadGeneral = oprg.idPropiedadGeneral and oprg.activo = 1
where
	oprg.idTipoValor = 'Unico'
	and cco.numeroContrato = @numeroContrato
	and cco.idCliente = @idCliente
	and tob.idClase = @idClase
	and obj.activo = 1

--PROPIEDADES DE CLASE
INSERT INTO #propiedadesObjeto
select 
	obj.idObjeto					idObjeto,
	tob.idTipoObjeto				idTipoObjeto,
	oprc.valor						agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	CASE 
		WHEN oprc.idTipoDato in ('Image', 'Pdf', 'Documento' )  THEN (SELECT valor 
																		FROM Common.configuracion.configuracion 
																		where nombre = 'fileServer') + (select path from FileServer.documento.Documento where idDocumento = otpc.valor) 
		ELSE otpc.valor	END			valor,
	oprc.orden						orden,
	oprc.posicion					posicion,
	1								ordenFinal
from objeto.objeto obj 
left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
inner join objeto.objeto.ObjetoPropiedadClase otpc on otpc.idObjeto = obj.idObjeto
inner join objeto.objeto.PropiedadClase oprc on otpc.idPropiedadClase = oprc.idPropiedadClase and oprc.idClase = @idClase and oprc.activo = 1
where
	oprc.idTipoValor = 'Unico' AND oprc.idTipoDato != 'Documento'
	and cco.numeroContrato = @numeroContrato
	and cco.idCliente = @idCliente
	and tob.idClase = @idClase
	and obj.activo = 1

	--PROPIEDADES DE CLASE DOCUMENTOS 
	INSERT INTO #propiedadesObjeto
	select 
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		oprc.valor						agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
		(SELECT TOP 1 [valor] 
		FROM [Objeto].[documento].[DocumentoObjetoClase] odd
		WHERE odd.idDocumentoClase = otpc.valor AND odd.idObjeto = obj.idObjeto AND odd.idTipoObjeto = obj.idTipoObjeto
		ORDER BY version DESC)						valor,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto obj 
	left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
	left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.ObjetoPropiedadClase otpc on otpc.idObjeto = obj.idObjeto
	inner join objeto.objeto.PropiedadClase oprc on otpc.idPropiedadClase = oprc.idPropiedadClase and oprc.idClase = @idClase and oprc.activo = 1

	where
	oprc.idTipoValor = 'Unico' AND oprc.idTipoDato = 'Documento'
	and cco.numeroContrato = @numeroContrato
	and cco.idCliente = @idCliente
	and tob.idClase = @idClase
	and obj.activo = 1

	--PROPIEDADES DE CONTRATO
	INSERT INTO #propiedadesObjeto
	select 
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		oprc.valor						agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
		otpc.valor						valor,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto obj 
	left join [Cliente].[contrato].[Objeto] cco on obj.idObjeto = cco.idObjeto AND obj.idTipoObjeto = cco.idTipoObjeto AND obj.idClase = cco.idClase
	left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.ObjetoPropiedadContrato otpc on otpc.idObjeto = obj.idObjeto
	inner join objeto.objeto.PropiedadContrato oprc on otpc.idPropiedadContrato = oprc.idPropiedadContrato and oprc.activo = 1 and oprc.numeroContrato = @numeroContrato and oprc.idCliente = @idCliente
	AND oprc.idCliente = oprc.idCliente
	WHERE	oprc.idTipoValor	= 'Unico'
	and		cco.numeroContrato	= @numeroContrato
	and		cco.idCliente		= @idCliente
	and		tob.idClase			= @idClase
	and		obj.activo			= 1
	
	/**********************************************************************************************************************
	******************************************************PIVOTE***********************************************************
	**********************************************************************************************************************/

	DECLARE @columnsNameObjeto VARCHAR(MAX) = ''

	CREATE TABLE #propiedadesOrdenasObjeto(	agrupador			VARCHAR(500),
											ordenFinal			INT,
											posicion			INT,
											orden				INT)

	INSERT INTO #propiedadesOrdenasObjeto
	SELECT  DISTINCT pr.agrupador,MIN(pr.ordenFinal),MIN(pr.posicion),MIN(pr.orden)
	FROM	#propiedadesObjeto pr GROUP BY pr.agrupador ORDER BY MIN(pr.ordenFinal),MIN(pr.posicion),MIN(pr.orden)

	SET @columnsNameObjeto = ISNULL(STUFF((SELECT ',' + QUOTENAME(prg.agrupador) FROM #propiedadesOrdenasObjeto prg FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,''),'sinCoinicidencia')

	SET @sq =  ' SELECT	* INTO ' + @tmpTipoObjeto + ' FROM (SELECT 	idTipoObjeto, agrupador, valor from #propiedadesTipoObjeto) t  pivot (max(valor) for agrupador in (' + @columnsNameTipoObjeto + ')) AS resultado '
	SET @sq += ' SELECT	* INTO ' + @tmpObjeto	  + ' FROM (select PO.idObjeto,PO.idTipoObjeto,PO.agrupador,valor,case when o.activo = 1 then ''ACTIVO'' ELSE ''INACTIVO'' END AS activo, EO.nombre as ''estatus objeto'' '
	SET @sq += ' FROM	#propiedadesObjeto PO inner join objeto.objeto O on po.idObjeto = o.idObjeto inner join Cliente.contrato.objeto CO on CO.idObjeto = o.idObjeto AND CO.numeroContrato = ''' + @numeroContrato + ''' AND CO.idCliente = ' + CAST(@idCliente AS VARCHAR(100)) + ' inner join [Cliente].[contrato].[ObjetoEstatus] '
	SET @sq += ' EO on EO.idObjetoEstatus = CO.idObjetoEstatus) t  pivot (	max(valor)for agrupador in (' + @columnsNameObjeto + ')) AS resultado ' 
	EXEC (@sq)
	
	SET @sq = ' CREATE NONCLUSTERED INDEX [idx_1001] ON [dbo].['+@tmpObjeto+']([idTipoObjeto] ASC,[idObjeto] ASC)INCLUDE([activo],[estatus objeto],'+@columnsNameObjeto+') WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]'
	EXEC(@sq)

	IF OBJECT_ID(@tmpObjeto, 'U') IS NOT NULL  
		BEGIN
			set @sq = '
			SELECT	CASE 
					WHEN dg.idFileServer IS NOT NULL THEN (select valor from Common.configuracion.configuracion where nombre = ''fileServer'')+(select top 1 path from FileServer.documento.documento where idDocumento = dg.idFileServer)
					ELSE (select valor from Common.configuracion.configuracion where nombre = ''fileServer'')+(select top 1 path from FileServer.documento.documento where idDocumento = TOB.Foto) END AS fotoPrincipal,
					CASE WHEN S.idObjetoSustituto IS NULL THEN 0
					ELSE 1 END sustitutoAsignado,
					TOB.*,z.*,O.*
					,isnull((	SELECT SUM(isnull(costo,0)) AS costo 
								FROM solicitud.[solicitud].[SolicitudCotizacionPartida] SCP
								INNER JOIN Solicitud.solicitud.Solicitud S ON S.idSolicitud = SCP.idSolicitud
								WHERE idObjeto = O.idObjeto AND idEstatusCotizacionPartida = ''APROBADA''
								AND S.idEstatusSolicitud = ''ACTIVA''
								AND (S.idFase = ''Proceso'' OR S.idFase = ''Entrega'' OR S.idFase = ''Cobranza'')),0) as costo
					,isnull((	SELECT SUM(isnull(venta,0)) AS venta
								FROM solicitud.[solicitud].[SolicitudCotizacionPartida] SCP
								INNER JOIN Solicitud.solicitud.Solicitud S ON S.idSolicitud = SCP.idSolicitud
								WHERE idObjeto = O.idObjeto AND idEstatusCotizacionPartida = ''APROBADA''
								AND S.idEstatusSolicitud = ''ACTIVA''
								AND (S.idFase = ''Proceso'' OR S.idFase = ''Entrega'' OR S.idFase = ''Cobranza'')),0) as venta
			FROM	' + @tmpTipoObjeto + ' TOB 
			INNER	JOIN ' + @tmpObjeto +' O ON TOB.idTipoObjeto = O.idTipoObjeto
			INNER	JOIN ' + @TablaZonaFinal	+'  Z on z.idObjetoZona = o.idObjeto
			LEFT	JOIN [objeto].[Sustituto] S ON S.idObjetoSustituto = O.idObjeto AND S.idTipoObjetoSustituto = O.idTipoObjeto
			--LEFT	JOIN documento.documentoobjetogeneral dg ON dg.idObjeto  = O.idObjeto
			OUTER APPLY 
			(SELECT TOP 1 *
			FROM documento.documentoobjetogeneral dg
			WHERE dg.idObjeto  = O.idObjeto
			ORDER BY dg.version DESC
			) AS dg
			ORDER BY O.idObjeto'
			PRINT @sq
			EXEC (@sq)
		END


	IF OBJECT_ID(@TablaZonaFinal, 'U') IS NOT NULL  
		BEGIN
			SET @sq='DROP TABLE '+@TablaZonaFinal 
			EXEC (@sq)	
		END

	IF OBJECT_ID(@tmpTipoObjeto, 'U') IS NOT NULL  
		BEGIN
			SET @sq='DROP TABLE '+@tmpTipoObjeto 
			EXEC (@sq)	
		END

	IF OBJECT_ID(@tmpObjeto, 'U') IS NOT NULL  
		BEGIN
			SET @sq='DROP TABLE '+@tmpObjeto 
			EXEC (@sq)	
		END

	drop table #propiedadesObjeto
	drop table #propiedadesOrdenasObjeto
	drop table #propiedadesTipoObjeto
	drop table #propiedadesTipoObjetoOrdenas
END


go

