-- =============================================
-- Author:		<ARTURO LOPEZ CORONA>
-- Create date: <16/05/2019>
-- Description:	<SP de Prueba>
-- Objeto.SEL_NOTIFICION_DATOS_INS 1
-- =============================================
CREATE PROCEDURE [objeto].[SEL_NOTIFICION_DATOS_INS]
	-- Add the parameters for the stored procedure here
	@err				VARCHAR(500) = NULL OUTPUT,
	@idUSuario		INT = NULL,
	@llave int
AS
BEGIN
	BEGIN TRY
		-- Insert statements for procedure here
		SELECT 1 llave, 'Objeto' modulo
		union
		SELECT 2 llave, 'Objeto' modulo
	END TRY  
	BEGIN CATCH  
		set  @err = 'Linea ' + CONVERT(VARCHAR,ERROR_LINE()) + ': ' + ERROR_MESSAGE()  
	END CATCH  
  
	PRINT 'OUT = ' +  @err  
	RETURN  
END
go

