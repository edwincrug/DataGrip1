-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <24-09-2019>
-- Description:	<Obtener los registros de los agrupadores permitidos>

	/*- Testing...

	EXEC [documento].[SEL_AGRUPADOR_SP]
	@err = null

*/

CREATE PROCEDURE [documento].[SEL_AGRUPADOR_SP]
	@idUsuario			int = null,
	@err				NVARCHAR(500) = '' OUTPUT
AS
BEGIN

	 SELECT [IdAgrupador]
			,[Nombre]
			,[icono]
			,[idUsuario]
			,[activo]
		FROM [Objeto].[documento].[Agrupador]
		WHERE activo = 1 
		ORDER BY Nombre

END
go

