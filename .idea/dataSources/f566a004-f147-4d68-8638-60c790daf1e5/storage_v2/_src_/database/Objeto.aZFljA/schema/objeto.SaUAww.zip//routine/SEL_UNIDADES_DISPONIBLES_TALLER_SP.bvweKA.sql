-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<13/06/2019>
-- Description:	<Obtener las unidades disponibles y en taller>
-- =============================================
-- EXEC [objeto].[SEL_UNIDADES_DISPONIBLES_TALLER_SP] 'Automovil', 'ASE0508051B6', 92, '0001'
-- =============================================
CREATE PROCEDURE [objeto].[SEL_UNIDADES_DISPONIBLES_TALLER_SP]
(
    @idClase                varchar(10)
    ,@rfcEmpresa            varchar(13)
    ,@idCliente             int
    ,@numeroContrato        varchar(50)
	,@idUsuario			int=NULL
	,@err				NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN

    SELECT
        SOPCV.[idObjeto]
    , SOPCV.[idClase]
    , SOPCV.[idTipoObjeto]
    , SOPCV.[VIN]
    , SOPCV.[color]
    , SOPCV.[repuve]
    , SOPCV.[numeroEconomico]
    , SDCUVV.[valor] placa
    , SOPCV.[numeroEconomicoExt]
    , SOPCV.[verificada]
    , SOPCV.[ultimoServicio]
    , SOPCV.[kilometraje]
    , SOPCV.[modelo]
    , STOGV.[idImagen]
    , STOCV.[marca]
    , STOCV.[submarca]
    , STOCV.[cilindros]
    , STOCV.[combustible]
    , CC.[rfcEmpresa]
    , CC.[idCliente]
    , CC.[numeroContrato]
    --, SOCV.[sustituto]
    --, SOCV.[GPS]
    --, SOCV.[descripcion]
    --, SOCV.[verGPS]
    , COALESCE(SUM(SSPTV.[totalVenta]), 0) totalVenta
    , VOD.[deviceid] idDispositivo
	, VOD.[uniqueid]
	, SOCKET.[socketVersion]
    --, SEEV.[type] dispositivoEstatus
    --, SEDV.[desconectado]
    --, COALESCE(SEAV.[countAlarms], 0) alarmas
    --, COALESCE(AIO.[tipo], 'sedan') tipo
    FROM [Cliente].[cliente].[Contrato] CC
        INNER JOIN [Cliente].[contrato].[Objeto] CO
        ON CC.[numeroContrato] = CO.[numeroContrato]
        AND CC.idCliente = CO.idCliente
            AND CC.rfcEmpresa = CO.rfcEmpresa
        INNER JOIN [Objeto].[objeto].[Objeto] OO
        ON CO.[idClase] = OO.[idClase]
            AND CO.[idTipoObjeto] = OO.[idTipoObjeto]
            AND CO.[idObjeto] = OO.[idObjeto]
        LEFT JOIN [Cliente].[contrato].[SEL_UNIDADES_EN_TALLER_VW] SUETV
        ON CO.[rfcEmpresa] = SUETV.[rfcEmpresa]
            AND CO.[idCliente] = SUETV.[idCliente]
            AND CO.[numeroContrato] = SUETV.[numeroContrato]
            AND CO.[idClase] = SUETV.[idClase]
            AND CO.[idTipoObjeto] = SUETV.[idTipoObjeto]
            AND CO.[idObjeto] = SUETV.[idObjeto]
            AND CO.[idContratoZona] = SUETV.[idContratoZona]
            AND CO.[idObjetoEstatus] = SUETV.[idObjetoEstatus]
        INNER JOIN [objeto].[SEL_OBJETOS_PROPIEDAD_CLASE_VW] SOPCV
        ON SOPCV.idClase = CO.idClase
            AND SOPCV.idObjeto = CO.idObjeto
            AND SOPCV.idTipoObjeto = CO.idTipoObjeto
        LEFT JOIN [Partida].[tipoobjeto].[SEL_TIPO_OBJETO_GENERAL_VW] STOGV
        ON SOPCV.[idTipoObjeto] = STOGV.[idTipoObjeto]
            AND SOPCV.[idClase] = STOGV.[idClase]
        INNER JOIN [Partida].[tipoobjeto].[SEL_TIPO_OBJETO_CLASE_VW] STOCV
        ON STOCV.[idTipoObjeto] = SOPCV.[idTipoObjeto]
            AND STOCV.[idClase] = SOPCV.[idClase]
        --LEFT JOIN [Objeto].[objeto].[SEL_OBJETO_CONTRATO_VW] SOCV
        --ON SOPCV.idObjeto = SOCV.idObjeto
        LEFT JOIN [Objeto].[documento].[SEL_PLACA_ULTIMA_VERSION_VW] SDCUVV
        ON SOPCV.[idObjeto] = SDCUVV.[idObjeto]
            AND SOPCV.[idClase] = SDCUVV.[idClase]
            AND SOPCV.[idTipoObjeto] = SDCUVV.[idTipoObjeto]
        LEFT JOIN (
			SELECT
				[idObjeto]
				,[idClase]
				,[idTipoObjeto]
				,[totalVenta]
			FROM [Solicitud].[solicitud].[SEL_SOLICITUD_PARTIDA_TOTALES_VW]
			WHERE [idEstatusSolicitud] = 'ACTIVA'
			) SSPTV
			ON SOPCV.[idObjeto] = SSPTV.[idObjeto]
            AND SOPCV.[idClase] = SSPTV.[idClase]
            AND SOPCV.[idTipoObjeto] = SSPTV.[idTipoObjeto]
        LEFT JOIN [AVL].[vehiculo].[ObjetoDispositivo] VOD
        ON VOD.[rfcEmpresa] = CO.[rfcEmpresa]
            AND VOD.[idCliente] = CO.[idCliente]
            AND VOD.[numeroContrato] = CO.[numeroContrato]
            AND VOD.[idClase] = CO.[idClase]
            AND VOD.[idTipoObjeto] = CO.[idTipoObjeto]
            AND VOD.[idObjeto] = CO.[idObjeto]
		LEFT JOIN [AVL].[vehiculo].[SEL_UNIDAD_SOCKET_VW] SOCKET
		ON VOD.[deviceid] = SOCKET.[id]
			AND VOD.[uniqueid] = SOCKET.[uniqueid]
        --LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_ESTATUS_VW] SEEV
        --ON SEEV.[deviceid] = VOD.[deviceid]
        --LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_DESCONECTADO_VW] SEDV
        --ON SEDV.[deviceid] = VOD.[deviceid]
        --LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_ALARMAS_VW] SEAV
        --ON SEAV.[deviceid] = VOD.[deviceid]
        --LEFT JOIN [AVL].[integridad].[objeto] AIO
        --ON AIO.[rfcEmpresa] = VOD.[rfcEmpresa]
        --    AND AIO.[idCliente] = VOD.[idCliente]
        --    AND AIO.[numeroContrato] = VOD.[numeroContrato]
        --    AND AIO.[idClase] = VOD.[idClase]
        --    AND AIO.[idTipoObjeto] = VOD.[idTipoObjeto]
        --    AND AIO.[idObjeto] = VOD.[idObjeto]
    WHERE CC.[numeroContrato] = @numeroContrato
        AND CC.[idCliente] = @idCliente
        AND CC.rfcEmpresa = @rfcEmpresa
        AND CC.idClase = @idClase
        AND OO.[idClase] = @idClase
        AND OO.[activo] = 1
        AND SUETV.[idObjeto] IS NULL
    GROUP BY SOPCV.[idObjeto]
        , SOPCV.[idClase]
        , SOPCV.[idTipoObjeto]
        , SOPCV.[VIN]
        , SOPCV.[color]
        , SOPCV.[repuve]
        , SOPCV.[numeroEconomico]
        , SDCUVV.[valor]
        , SOPCV.[numeroEconomicoExt]
        , SOPCV.[verificada]
        , SOPCV.[ultimoServicio]
        , SOPCV.[kilometraje]
        , SOPCV.[modelo]
        , STOGV.[idImagen]
        , STOCV.[marca]
        , STOCV.[submarca]
        , STOCV.[cilindros]
        , STOCV.[combustible]
        , CC.[rfcEmpresa]
        , CC.[idCliente]
        , CC.[numeroContrato]
        --, SOCV.[sustituto]
        --, SOCV.[GPS]
        --, SOCV.[descripcion]
        --, SOCV.[verGPS]
        , VOD.[deviceid]
		, VOD.[uniqueid]
		, SOCKET.[socketVersion]
        --, SEEV.[type]
        --, SEDV.[desconectado]
        --, SEAV.[countAlarms]
        --, AIO.[tipo]

    SELECT
        SOPCV.[idObjeto]
    , SOPCV.[idClase]
    , SOPCV.[idTipoObjeto]
    , SOPCV.[VIN]
    , SOPCV.[color]
    , SOPCV.[repuve]
    , SOPCV.[numeroEconomico]
    , SDCUVV.[valor] placa
    , SOPCV.[numeroEconomicoExt]
    , SOPCV.[verificada]
    , SOPCV.[ultimoServicio]
    , SOPCV.[kilometraje]
    , SOPCV.[modelo]
    , STOGV.[idImagen]
    , STOCV.[marca]
    , STOCV.[submarca]
    , STOCV.[cilindros]
    , STOCV.[combustible]
    , SUETV.[rfcEmpresa]
    , SUETV.[idCliente]
    , SUETV.[numeroContrato]
    --, SOCV.[sustituto]
    --, SOCV.[GPS]
    --, SOCV.[descripcion]
    --, SOCV.[verGPS]
    , COALESCE(SUM(SSPTV.[totalVenta]), 0) totalVenta
    , VOD.[deviceid] idDispositivo
	, VOD.[uniqueid]
	, SOCKET.[socketVersion]
    --, SEEV.[type] dispositivoEstatus
    --, SEDV.[desconectado]
    --, COALESCE(SEAV.[countAlarms], 0) alarmas
    --, COALESCE(AIO.[tipo], 'sedan') tipo
    FROM [Cliente].[contrato].[SEL_UNIDADES_EN_TALLER_VW] SUETV
        INNER JOIN [objeto].[SEL_OBJETOS_PROPIEDAD_CLASE_VW] SOPCV
        ON SUETV.[idClase] = SOPCV.[idClase]
            AND SUETV.[idTipoObjeto] = SOPCV.[idTipoObjeto]
            AND SUETV.[idObjeto] = SOPCV.[idObjeto]
        LEFT JOIN [Partida].[tipoobjeto].[SEL_TIPO_OBJETO_GENERAL_VW] STOGV
        ON SOPCV.[idTipoObjeto] = STOGV.[idTipoObjeto]
            AND SOPCV.[idClase] = STOGV.[idClase]
        INNER JOIN [Partida].[tipoobjeto].[SEL_TIPO_OBJETO_CLASE_VW] STOCV
        ON STOCV.[idTipoObjeto] = SOPCV.[idTipoObjeto]
            AND STOCV.[idClase] = SOPCV.[idClase]
        --LEFT JOIN [Objeto].[objeto].[SEL_OBJETO_CONTRATO_VW] SOCV
        --ON SOPCV.idObjeto = SOCV.idObjeto
        LEFT JOIN [Objeto].[documento].[SEL_PLACA_ULTIMA_VERSION_VW] SDCUVV
        ON SOPCV.[idObjeto] = SDCUVV.[idObjeto]
            AND SOPCV.[idClase] = SDCUVV.[idClase]
            AND SOPCV.[idTipoObjeto] = SDCUVV.[idTipoObjeto]
        LEFT JOIN (
			SELECT
				[idObjeto]
				,[idClase]
				,[idTipoObjeto]
				,[totalVenta]
			FROM [Solicitud].[solicitud].[SEL_SOLICITUD_PARTIDA_TOTALES_VW]
			WHERE [idEstatusSolicitud] = 'ACTIVA'
			) SSPTV
        ON SOPCV.[idObjeto] = SSPTV.[idObjeto]
            AND SOPCV.[idClase] = SSPTV.[idClase]
            AND SOPCV.[idTipoObjeto] = SSPTV.[idTipoObjeto]
        LEFT JOIN [AVL].[vehiculo].[ObjetoDispositivo] VOD
        ON VOD.[rfcEmpresa] = SUETV.[rfcEmpresa]
            AND VOD.[idCliente] = SUETV.[idCliente]
            AND VOD.[numeroContrato] = SUETV.[numeroContrato]
            AND VOD.[idClase] = SUETV.[idClase]
            AND VOD.[idTipoObjeto] = SUETV.[idTipoObjeto]
            AND VOD.[idObjeto] = SUETV.[idObjeto]
		LEFT JOIN [AVL].[vehiculo].[SEL_UNIDAD_SOCKET_VW] SOCKET
		ON VOD.[deviceid] = SOCKET.[id]
			AND VOD.[uniqueid] = SOCKET.[uniqueid]
        --LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_ESTATUS_VW] SEEV
        --ON SEEV.[deviceid] = VOD.[deviceid]
        --LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_DESCONECTADO_VW] SEDV
        --ON SEDV.[deviceid] = VOD.[deviceid]
        --LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_ALARMAS_VW] SEAV
        --ON SEAV.[deviceid] = VOD.[deviceid]
        --LEFT JOIN [AVL].[integridad].[objeto] AIO
        --ON AIO.[rfcEmpresa] = VOD.[rfcEmpresa]
        --    AND AIO.[idCliente] = VOD.[idCliente]
        --    AND AIO.[numeroContrato] = VOD.[numeroContrato]
        --    AND AIO.[idClase] = VOD.[idClase]
        --    AND AIO.[idTipoObjeto] = VOD.[idTipoObjeto]
        --    AND AIO.[idObjeto] = VOD.[idObjeto]
    WHERE SUETV.[numeroContrato] = @numeroContrato
        AND SUETV.[idCliente] = @idCliente
        AND SUETV.idClase = @idClase
        AND SUETV.rfcEmpresa = @rfcEmpresa
    GROUP BY SOPCV.[idObjeto]
        , SOPCV.[idClase]
        , SOPCV.[idTipoObjeto]
        , SOPCV.[VIN]
        , SOPCV.[color]
        , SOPCV.[repuve]
        , SOPCV.[numeroEconomico]
        , SDCUVV.[valor]
        , SOPCV.[numeroEconomicoExt]
        , SOPCV.[verificada]
        , SOPCV.[ultimoServicio]
        , SOPCV.[kilometraje]
        , SOPCV.[modelo]
        , STOGV.[idImagen]
        , STOCV.[marca]
        , STOCV.[submarca]
        , STOCV.[cilindros]
        , STOCV.[combustible]
        , SUETV.[rfcEmpresa]
        , SUETV.[idCliente]
        , SUETV.[numeroContrato]
        --, SOCV.[sustituto]
        --, SOCV.[GPS]
        --, SOCV.[descripcion]
        --, SOCV.[verGPS]
        , VOD.[deviceid]
		, VOD.[uniqueid]
		, SOCKET.[socketVersion]
        --, SEEV.[type]
        --, SEDV.[desconectado]
        --, SEAV.[countAlarms]
        --, AIO.[tipo]
END



go

