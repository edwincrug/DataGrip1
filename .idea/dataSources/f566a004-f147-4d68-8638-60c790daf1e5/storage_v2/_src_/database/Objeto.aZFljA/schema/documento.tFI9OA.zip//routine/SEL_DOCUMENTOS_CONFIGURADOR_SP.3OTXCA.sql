-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <23-03-2019>
-- Description:	<Obtener los registros de los tipos de documentos
-- de los tres tipos , generales, clase y contrato
-- agregando los tipos de datos y valores>

	/*- Testing...

	EXEC [documento].[SEL_DOCUMENTOS_CONFIGURADOR_SP]
	@idClase = 'Automovil',
	@idCliente = 92,
	@err = null

*/

CREATE PROCEDURE [documento].[SEL_DOCUMENTOS_CONFIGURADOR_SP]
	@idClase			varchar(10),
	@idCliente			int = null,
    @numeroContrato		varchar(50) = null,
	@idUsuario			int = null,
	@err				NVARCHAR(500) = '' OUTPUT
AS
BEGIN

	 SELECT 
		[idDocumentoGeneral] AS id
		,[nombre]
		,[idAgrupador]
		,[tiposPermitidos]
		,[obligatorio]
		,[vigencia]
		,[valor]
		,[aplicaCosto]
		,[orden]
		,[idUsuario]
		,[activo]
		,[aplicaEstado]
		,[aplicaComentario]
		,'general' AS propiedad
  FROM [Objeto].[documento].[DocumentoGeneral]
	WHERE activo = 1
	ORDER BY nombre asc, orden desc 


	SELECT 
		[idDocumentoClase] AS id
		,[idClase]
		,[nombre]
		,[idAgrupador]
		,[tiposPermitidos]
		,[vigencia]
		,[obligatorio]
		,[valor]
		,[aplicaCosto]
		,[orden]
		,[idUsuario]
		,[activo]
		,[aplicaEstado]
		,[aplicaComentario]
		,'clase' AS propiedad
  FROM [Objeto].[documento].[DocumentoClase]
	WHERE idClase = @idClase AND activo = 1
	ORDER BY nombre asc, orden desc 

	SELECT 
		[idDocumentoContrato] AS id
		,[nombre]
		,[idAgrupador]
		,[tiposPermitidos]
		,[vigencia]
		,[obligatorio]
		,[valor]
		,[aplicaCosto]
		,[orden]
		,[idUsuario]
		,[activo]
		,[aplicaEstado]
		,[aplicaComentario]
		,[idCliente]
		,[numeroContrato]
		,'contrato' AS propiedad
	FROM [Objeto].[documento].[DocumentoContrato]
		WHERE idCliente = @idCliente AND activo = 1
		ORDER BY nombre asc, orden desc 
		
END
go

