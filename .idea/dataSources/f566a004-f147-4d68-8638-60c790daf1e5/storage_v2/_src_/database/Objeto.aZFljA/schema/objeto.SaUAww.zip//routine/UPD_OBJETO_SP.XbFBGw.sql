
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <19-03-2019>
-- Description:	<Modificar la tabla objeto segun el tipo de objeto>
-- =============================================
/*
	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [objeto].[UPD_OBJETO_SP] 
		@idObjeto = 2,

		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [objeto].[UPD_OBJETO_SP]
	@idObjeto				int,
	@idTipoObjeto			int,
	@descripcion			nvarchar(500),
	@activo					bit,
	@idUsuario				int = null,
	@err					varchar(max) OUTPUT

AS
BEGIN
	SET @err = '';
	--IF si realizar un update de valor o un inserrt
	/*If EXISTS (SELECT idObjeto FROM [objeto].[Objeto]
				WHERE idObjeto = @idObjeto 
				AND activo = 1 )
				*/
	UPDATE [objeto].[Objeto]
	SET
		[idTipoObjeto] = @idTipoObjeto
		--,[descripcion] = @descripcion
		,[activo] = @activo	
		WHERE idObjeto = @idObjeto AND activo = 1

	SELECT idObjeto FROM [objeto].[Objeto] WHERE idObjeto = @idObjeto
END
go

