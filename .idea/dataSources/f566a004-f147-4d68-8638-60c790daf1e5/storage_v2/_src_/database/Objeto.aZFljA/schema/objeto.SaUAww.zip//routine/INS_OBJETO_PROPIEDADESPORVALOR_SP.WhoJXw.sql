
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <29-05-2019>
-- Description:	<Insertar un objeto cn sus propiedadespor medio de el valor de la propiedad>
-- =============================================
/*
	*** Versionamiento
	Fecha 		Autor	Descripción 
	29-may-2019	SGIL	Agregando versionamiento,
						y contrato obligatorio como idUsuario
	*- Testing...

	EXEC [objeto].[INS_OBJETO_PROPIEDADESPORVALOR_SP]
		71
		,'Automovil'
		,32
		,'DIC0503123MD3'
		,78
		,'123PEMEX'
		,2
		,'<propiedades><propiedad><nombreProp>VIN</nombreProp><valor>3N6AD33A7JK900319</valor></propiedad>
		<propiedad><nombreProp>Año</nombreProp><valor>2019</valor></propiedad>
		</propiedades>'
		,null

*/
-- =============================================
CREATE PROCEDURE [objeto].[INS_OBJETO_PROPIEDADESPORVALOR_SP] 
	@idTipoObjeto			int,
	@idClase				varchar(10),
	@idZona					int,
	@idCosto				int,
	-- Datos del contrato
	@rfcEmpresa				varchar(13),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	-- Bitacora de usuario
	@UserId					int,
	@propiedades			XML,
	@err					varchar(max) OUTPUT

AS
BEGIN TRY
BEGIN TRANSACTION

	SET @err = '';
	DECLARE @idObjeto INT;
-- guardar en un atbla temporal N propiedades
	DECLARE @tbl_propiedades AS TABLE(
	_row                    INT IDENTITY(1,1),
	nombreProp				NVARCHAR(250),
	valorProp                   NVARCHAR(500)
	)

	INSERT INTO @tbl_propiedades(nombreProp, valorProp)

    SELECT
        ParamValues.col.value('nombreProp[1]','nvarchar(250)'),
        ParamValues.col.value('valor[1]','nvarchar(500)')
        FROM @propiedades.nodes('propiedades/propiedad') AS ParamValues(col)

	DECLARE @cont INT = 1
				
	-- Insertamos el Objeto
	INSERT INTO [objeto].[Objeto]
			([idClase]
           ,[idTipoObjeto]
           ,[idUsuario]
           ,[activo])
		VALUES
			(@idClase
			,@idTipoObjeto
			,@UserId
			,1);

	SET @idObjeto = @@IDENTITY

	BEGIN
	-- Lo damos de alta en un contrato
		INSERT INTO [Cliente].[contrato].[Objeto]
				([rfcEmpresa]
			   ,[idCliente]
			   ,[numeroContrato]
			   ,[idClase]
			   ,[idTipoObjeto]
			   ,[idObjeto]
				,[idContratoZona]
				,[idObjetoEstatus]
				,[idUsuario]
				,[activo]
				,idCentroCosto)
			VALUES
				(@rfcEmpresa
				,@idCliente
				,@numeroContrato
				,@idClase
				,@idTipoObjeto
				,@idObjeto
				,@idZona
				,'ACT'
				,@UserId
				,1
				,@idCosto)
	
		-- SELECT @idObjeto AS idObjeto;
	END
-- insercion en las tablas segun el tipo de propiedad
   WHILE((SELECT COUNT(*) FROM @tbl_propiedades)>= @cont)
    BEGIN
        DECLARE @nombreProp NVARCHAR(250);
		DECLARE @propiedad NVARCHAR(250);
		DECLARE @idProp NVARCHAR(250);
		DECLARE @tipoVal NVARCHAR(250);

       SELECT @nombreProp = nombreProp
        FROM @tbl_propiedades 
        WHERE _row = @cont

		SELECT TOP 1 @idProp = idProp FROM (
											SELECT idPropiedadGeneral as idProp 
											FROM [objeto].[PropiedadGeneral]
											WHERE valor = @nombreProp
											UNION ALL
											SELECT idPropiedadClase
											FROM [objeto].[PropiedadClase]
											WHERE valor = @nombreProp
											UNION ALL
											SELECT idPropiedadContrato 
											FROM [objeto].[PropiedadContrato]
											WHERE valor = @nombreProp
											) as tbl1

			SELECT TOP 1 @tipoVal = idTipoValor FROM (
											SELECT idTipoValor
											FROM [objeto].[PropiedadGeneral]
											WHERE valor = @nombreProp
											UNION ALL
											SELECT idTipoValor
											FROM [objeto].[PropiedadClase]
											WHERE valor = @nombreProp
											UNION ALL
											SELECT idTipoValor 
											FROM [objeto].[PropiedadContrato]
											WHERE valor = @nombreProp
											) as tbl1	

			SELECT TOP 1 @propiedad = propiedad FROM (
											SELECT 'general' as propiedad 
											FROM [objeto].[PropiedadGeneral]
											WHERE valor = @nombreProp
											UNION ALL
											SELECT 'clase'
											FROM [objeto].[PropiedadClase]
											WHERE valor = @nombreProp
											UNION ALL
											SELECT 'contrato' 
											FROM [objeto].[PropiedadContrato]
											WHERE valor = @nombreProp
											) as tbl1

				IF(@propiedad = 'general')
					BEGIN
						INSERT INTO [objeto].[ObjetoPropiedadGeneral]
						SELECT
							CASE
							WHEN (@tipoVal != 'Unico') THEN (SELECT TOP 1 idPropiedadGeneral 
															FROM PropiedadGeneral WHERE valor = valorProp )
							ELSE @idProp
							END,
						@idClase,
						@idTipoObjeto,
						@idObjeto,
						CASE 
							WHEN (@tipoVal != 'Unico') THEN ''
							ELSE valorProp
							END,
						@UserId,
						1
						FROM @tbl_propiedades
						WHERE _row = @cont
					END

				ELSE IF(@propiedad = 'clase')
					BEGIN
						INSERT INTO [objeto].[ObjetoPropiedadClase]
						SELECT
						@idClase,
						CASE
							WHEN (@tipoVal != 'Unico') THEN (SELECT TOP 1 idPropiedadClase 
															FROM PropiedadClase WHERE valor = valorProp )
							ELSE @idProp
							END,
							@idTipoObjeto,
							@idObjeto,
						CASE 
							WHEN (@tipoVal != 'Unico') THEN ''
							ELSE valorProp
							END,
							@UserId,
							1
						FROM @tbl_propiedades
						WHERE _row = @cont

					END
				ELSE IF(@propiedad = 'contrato')
					BEGIN
						INSERT INTO [objeto].[ObjetoPropiedadContrato]
						SELECT
							@rfcEmpresa,
							@idCliente,
							@numeroContrato,
						CASE
							WHEN (@tipoVal != 'Unico') THEN (SELECT TOP 1 idPropiedadContrato 
															FROM PropiedadContrato WHERE valor = valorProp )
							ELSE @idProp
							END,
							@idClase,
							@idTipoObjeto,
							@idObjeto,
						CASE 
							WHEN (@tipoVal != 'Unico') THEN ''
							ELSE valorProp
							END,
							@UserId,
							1
						FROM @tbl_propiedades
						WHERE _row = @cont
					END
				SET @cont = @cont + 1


END
			SELECT idObjeto, idTipoObjeto FROM [objeto].[Objeto]
			WHERE idObjeto = @idObjeto
	SET @err = 'El Objeto se registro correctamente.'
	COMMIT
END TRY

BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH
go

