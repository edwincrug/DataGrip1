-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <13-06-2019>
-- Description:	<Obtiene propiedades de objeto y sus documentos >
-- =============================================

/*

	------ Versionamiento
	Fecha 		Autor	Descrición
	 13/08/2019	José Etmanuel	Agregando clase a la función Objeto.objeto.getPropiedadObjeto
 
	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [documento].[SEL_DOCUMENTO_REPORTE_SP]  'Automovil',6036, @salida OUTPUT;
	SELECT @salida AS salida;
*/

CREATE PROCEDURE [documento].[SEL_DOCUMENTO_REPORTE_SP]
      @idClase				varchar(20),
	  @idUsuario			INT,	
	  @err					varchar(max) OUTPUT

AS

BEGIN
	Select *
				 from(
					SELECT 
						TOB.idTipoObjeto,
						(select [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](TOB.idTipoObjeto,'Submarca','Automovil')) as marca,
						OPC.idPropiedadClase,
						PC.valor,
						SPEC.nombre SPEC
					from partida.tipoobjeto.tipoobjeto TOB
					LEFT JOIN objeto.objeto Obj ON OBJ.idTipoObjeto = TOB.idTIpoObjeto
					LEFT JOIN [objeto].[ObjetoPropiedadClase] OPC ON OPC.idObjeto = OBJ.idObjeto
					INNER JOIN [objeto].[PropiedadClase] PC ON PC.idPropiedadClase = OPC.idPropiedadClase AND idPadre = 5
					LEFT JOIN cliente.contrato.Equipamiento EQU on EQU.idObjeto = OBJ.idObjeto
					LEFT JOIN [CLIENTE].[contrato].[SPEC] SPEC ON SPEC.idSpec = EQU.idSpec AND SPEC.activo = 1
					WHERE TOB.activo = 1
					AND TOB.idClase = @idClase) a
	GROUP BY a.idTipoObjeto, a.marca, a.idPropiedadClase, a.valor, a.SPEC


/**********************************************OBJETOS ****************************************************************/

	IF OBJECT_ID('tempdb..#datos') IS NOT NULL
		BEGIN
			DROP TABLE #datos
		END

	DECLARE @columnsName varchar(max) = ''

	SET @columnsName = STUFF((SELECT ',' + QUOTENAME(nombre) 
						FROM [documento].[DocumentoClase] where idClase = @idClase and activo = 1
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')


	SELECT
		O.idObjeto,
		TOB.idTipoObjeto,
		(SELECT [objeto].objeto.[getPropiedadObjeto](O.idObjeto,'Año', 'clase',@idClase)) as modelo,
		(SELECT [objeto].objeto.[getPropiedadObjeto](O.idObjeto,'VIN', 'clase',@idClase)) as vin,
		(SELECT [partida].[tipoobjeto].[SEL_TIPOOBJETO_NOMBRE_FN](TOB.idTipoObjeto,'Submarca',@idClase)) as marca,
		DC.nombre,
		CASE WHEN DOC.idDocumentoClase is null OR DOC.idDocumentoClase = 0 THEN 0 ELSE 1 END as doc
	INTO #datos
	FROM objeto.objeto.objeto O
	LEFT JOIN partida.tipoObjeto.tipoObjeto TOB ON TOB.idTipoObjeto = O.idTipoObjeto
	LEFT JOIN [documento].[DocumentoObjetoClase] DOC ON DOC.idObjeto = O.idObjeto
	LEFT JOIN [documento].[DocumentoClase] DC ON DC.idDocumentoClase = DOC.idDocumentoClase
	WHERE O.activo = 1
	AND O.idClase = @idClase
	GROUP BY o.idObjeto, tob.idTipoObjeto, DC.nombre, DOC.idDocumentoClase
	ORDER BY O.idObjeto, TOB.idTipoObjeto
	

	declare @query varchar(max)
	set @query = '

	select * 
	from #datos 
	PIVOT (max(doc) for nombre in(' + @columnsName + ')) AS tblPiv'

	execute (@query)

END

go

