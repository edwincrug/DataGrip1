-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<13/06/2019>
-- Description:	<Obtener los documentos por idobjeto>
-- =============================================
-- EXEC [objeto].[SEL_DOCUMENTOS_SP] 'Automovil', 100, 250, 221, '205'
-- =============================================
CREATE PROCEDURE [objeto].[SEL_DOCUMENTOS_SP]
    (
    @idClase				varchar(10)
    ,@idTipoObjeto			int
    ,@idObjeto				int
	,@idCliente				int
	,@numeroContrato		VARCHAR(50)
	,@idUsuario				int=NULL
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS
DECLARE
	@multas					INT=0
	,@documentosVencidos	INT=0
BEGIN

	SELECT 
        @multas = COUNT(DDOC.[idDocumentoClase])
    FROM [Objeto].[documento].[DocumentoObjetoClase] DDOC
    INNER JOIN [Objeto].[documento].[CostoDocumentoClase] DCDC
        ON DDOC.[idDocumentoClase] = DCDC.[idDocumentoClase]
        AND DDOC.[idClase] = DCDC.[idClase]
        AND DDOC.[idTipoObjeto] = DCDC.[idTipoObjeto]
        AND DDOC.[idObjeto] = DCDC.[idObjeto]
        AND DDOC.[version] = DCDC.[version]
    WHERE DDOC.[idClase] = @idClase
        AND DCDC.[idClase] = @idClase
        AND DDOC.[idTipoObjeto] = @idTipoObjeto
        AND DCDC.[idTipoObjeto] = @idTipoObjeto
        AND DDOC.[idObjeto] = @idObjeto
        AND DCDC.[idObjeto] = @idObjeto
        AND DCDC.activo = 1
        AND DCDC.pagado = 0

	SELECT
		@documentosVencidos = SUM(1)
    FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW] SDCUVV
    WHERE SDCUVV.idClase = @idClase
        AND SDCUVV.idTipoObjeto = @idTipoObjeto
        AND SDCUVV.idObjeto = @idObjeto
		AND SDCUVV.[vigencia] < GETDATE()

	SELECT COALESCE(@multas + @documentosVencidos, 0) documentosVencidos

	EXEC [objeto].[SEL_DOCUMENTOS_AGRUPADO_SP] 'general', @idClase, @idTipoObjeto, @idObjeto,@idCliente,@numeroContrato

	EXEC [objeto].[SEL_DOCUMENTOS_AGRUPADO_SP] 'documentacion', @idClase, @idTipoObjeto, @idObjeto,@idCliente,@numeroContrato

	EXEC [objeto].[SEL_DOCUMENTOS_AGRUPADO_SP] 'entrega', @idClase, @idTipoObjeto, @idObjeto,@idCliente,@numeroContrato

	EXEC [objeto].[SEL_MULTAS_SP] @idClase, @idTipoObjeto, @idObjeto

    --SELECT 
    --    placa.[version] placaVersion
    --    ,placa.[idFileServer] placaIdFileServer
    --    ,placa.[vigencia] placaVigencia
    --    ,COALESCE(placa.[placaEsCaduco], 0) placaEsCaduco
    --    ,placa.[valor] placaValor
    --    ,tarjeta.[version] tarjetaVersion
    --    ,tarjeta.[idFileServer] tarjetaIdFileServer
    --    ,tarjeta.[vigencia] tarjetaVigencia
    --    ,COALESCE(tarjeta.[tarjetaEsCaduco], 0) tarjetaEsCaduco
    --    ,tarjeta.[valor] tarjetaValor
    --    ,tenencia.[version] tenenciaVersion
    --    ,tenencia.[idFileServer] tenenciaIdFileServer
    --    ,tenencia.[vigencia] tenenciaVigencia
    --    ,COALESCE(tenencia.[tenenciaEsCaduco], 0) tenenciaEsCaduco
    --    ,tenencia.[valor] tenenciaValor
    --    ,poliza.[version] polizaVersion
    --    ,poliza.[idFileServer] polizaIdFileServer
    --    ,poliza.[vigencia] polizaVigencia
    --    ,COALESCE(poliza.[polizaEsCaduco], 0) polizaEsCaduco
    --    ,poliza.[valor] polizaValor
    --    ,verificacion.[version] verificacionVersion
    --    ,verificacion.[idFileServer] verificacionIdFileServer
    --    ,verificacion.[vigencia] verificacionVigencia
    --    ,COALESCE(verificacion.[verificacionEsCaduco], 0) verificacionEsCaduco
    --    ,verificacion.[valor] verificacionValor
    --    ,multa.[multas]
    --FROM

    --(SELECT
    --    SDCUVV.[version] 
    --    , SDCUVV.[idFileServer] 
    --    , SDCUVV.[vigencia] 
    --    , CASE 
    --        WHEN SDCUVV.[vigencia] IS NULL THEN 0
    --        WHEN SDCUVV.[vigencia] < GETDATE() THEN 1
    --        ELSE 0
    --    END placaEsCaduco
    --    , SDCUVV.[valor] 
    --FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW] SDCUVV
    --WHERE SDCUVV.idClase = @idClase
    --    AND SDCUVV.idTipoObjeto = @idTipoObjeto
    --    AND SDCUVV.idObjeto = @idObjeto
    --    AND SDCUVV.idDocumentoClase = 18) placa
    --FULL OUTER JOIN
    --(SELECT
    --    SDCUVV.[version] 
    --    , SDCUVV.[idFileServer] 
    --    , SDCUVV.[vigencia] 
    --    , CASE 
    --        WHEN SDCUVV.[vigencia] IS NULL THEN 0
    --        WHEN SDCUVV.[vigencia] < GETDATE() THEN 1
    --        ELSE 0
    --    END tarjetaEsCaduco
    --    , SDCUVV.[valor] 
    --FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW] SDCUVV
    --WHERE SDCUVV.idClase = @idClase
    --    AND SDCUVV.idTipoObjeto = @idTipoObjeto
    --    AND SDCUVV.idObjeto = @idObjeto
    --    AND SDCUVV.idDocumentoClase = 20) tarjeta
    --ON 1=1
    --FULL OUTER JOIN
    --(SELECT
    --    SDCUVV.[version]
    --    , SDCUVV.[idFileServer]
    --    , SDCUVV.[vigencia]
    --    , CASE 
    --        WHEN SDCUVV.[vigencia] IS NULL THEN 0
    --        WHEN SDCUVV.[vigencia] < GETDATE() THEN 1
    --        ELSE 0
    --    END tenenciaEsCaduco
    --    , SDCUVV.[valor]
    --FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW] SDCUVV
    --WHERE SDCUVV.idClase = @idClase
    --    AND SDCUVV.idTipoObjeto = @idTipoObjeto
    --    AND SDCUVV.idObjeto = @idObjeto
    --    AND SDCUVV.idDocumentoClase = 21) tenencia
    --ON 1=1
    --FULL OUTER JOIN
    --(SELECT
    --    SDCUVV.[version]
    --    , SDCUVV.[idFileServer]
    --    , SDCUVV.[vigencia]
    --    , CASE 
    --        WHEN SDCUVV.[vigencia] IS NULL THEN 0
    --        WHEN SDCUVV.[vigencia] < GETDATE() THEN 1
    --        ELSE 0
    --    END polizaEsCaduco
    --    , SDCUVV.[valor]
    --FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW] SDCUVV
    --WHERE SDCUVV.idClase = @idClase
    --    AND SDCUVV.idTipoObjeto = @idTipoObjeto
    --    AND SDCUVV.idObjeto = @idObjeto
    --    AND SDCUVV.idDocumentoClase = 24) poliza
    --ON 1=1
    --FULL OUTER JOIN
    --(SELECT
    --    SDCUVV.[version]
    --    , SDCUVV.[idFileServer]
    --    , SDCUVV.[vigencia]
    --    , CASE 
    --        WHEN SDCUVV.[vigencia] IS NULL THEN 0
    --        WHEN SDCUVV.[vigencia] < GETDATE() THEN 1
    --        ELSE 0
    --    END verificacionEsCaduco
    --    , SDCUVV.[valor]
    --FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW] SDCUVV
    --WHERE SDCUVV.idClase = @idClase
    --    AND SDCUVV.idTipoObjeto = @idTipoObjeto
    --    AND SDCUVV.idObjeto = @idObjeto
    --    AND SDCUVV.idDocumentoClase = 23) verificacion
    --ON 1=1
    --FULL OUTER JOIN
    --(SELECT 
    --    COUNT(DDOC.[idDocumentoClase]) multas
    --FROM [Objeto].[documento].[DocumentoObjetoClase] DDOC
    --INNER JOIN [Objeto].[documento].[CostoDocumentoClase] DCDC
    --    ON DDOC.[idDocumentoClase] = DCDC.[idDocumentoClase]
    --    AND DDOC.[idClase] = DCDC.[idClase]
    --    AND DDOC.[idTipoObjeto] = DCDC.[idTipoObjeto]
    --    AND DDOC.[idObjeto] = DCDC.[idObjeto]
    --    AND DDOC.[version] = DCDC.[version]
    --WHERE DDOC.[idClase] = @idClase
    --    AND DCDC.[idClase] = @idClase
    --    AND DDOC.[idTipoObjeto] = @idTipoObjeto
    --    AND DCDC.[idTipoObjeto] = @idTipoObjeto
    --    AND DDOC.[idObjeto] = @idObjeto
    --    AND DCDC.[idObjeto] = @idObjeto
    --    AND DCDC.activo = 1
    --    AND DCDC.pagado = 0
    --) multa
    --ON 1=1

END
go

