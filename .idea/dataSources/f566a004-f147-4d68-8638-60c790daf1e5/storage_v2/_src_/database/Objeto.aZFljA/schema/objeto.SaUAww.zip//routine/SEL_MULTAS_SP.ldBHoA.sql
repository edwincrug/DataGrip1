-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<13/06/2019>
-- Description:		<Obtener los multas de las unidades>
-- =============================================
-- EXEC [objeto].[SEL_MULTAS_SP] 'Automovil', 100, 250
-- =============================================
CREATE PROCEDURE [objeto].[SEL_MULTAS_SP]
(
    @idClase				varchar(10)
    ,@idTipoObjeto			int
    ,@idObjeto				int
	,@idUsuario				int=NULL
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN

	SELECT 
		DDOC.[idDocumentoClase]
		,DDOC.[idClase]
		,DDOC.[idTipoObjeto]
		,DDOC.[idObjeto]
		,DDOC.[idFileServer]
		,DDOC.[fecha]
		,DDOC.[idEstado]
		,DDOC.[comentario]
		,DCDC.[version]
		,DCDC.[costo]
		,U.[UserName] userName
		,U.[PrimerNombre]
		,U.[SegundoNombre]
		,U.[PrimerApellido]
		,U.[SegundoApellido]
		,U.[Email]
		,U.[Celular]
	FROM [Objeto].[documento].[DocumentoObjetoClase] DDOC
	LEFT JOIN [Objeto].[documento].[CostoDocumentoClase] DCDC
		ON DDOC.[idDocumentoClase] = DCDC.[idDocumentoClase]
		AND DDOC.[idClase] = DCDC.[idClase]
		AND DDOC.[idTipoObjeto] = DCDC.[idTipoObjeto]
		AND DDOC.[idObjeto] = DCDC.[idObjeto]
		AND DDOC.[version] = DCDC.[version]
	LEFT JOIN [Seguridad].[Catalogo].[Users] U
		ON DDOC.[idUsuario] = U.[id]
	WHERE DDOC.[idClase] = @idClase
		AND DCDC.[idClase] = @idClase
		AND DDOC.[idTipoObjeto] = @idTipoObjeto
		AND DCDC.[idTipoObjeto] = @idTipoObjeto
		AND DDOC.[idObjeto] = @idObjeto
		AND DCDC.[idObjeto] = @idObjeto
		AND DCDC.activo = 1
		AND DCDC.pagado = 0
	ORDER BY [version] DESC

END
go

