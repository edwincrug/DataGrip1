-- =============================================
-- Author:		Edgar Mendoza
-- Create date: 12/07/2019
-- Description:	
-- Test:	SELECT  [documento].[SEL_DocumentoObjetoClase_FN](241,100,'2019')
-- =============================================
CREATE FUNCTION [documento].[SEL_DocumentoObjetoClase_FN]
(
	@idObjeto		INT,
	@idTipoObjeto	INT,
	@valor			VARCHAR(50)
)
RETURNS VARCHAR(500)
AS
BEGIN
	DECLARE @VC_RESULT VARCHAR(500) = ''

	SELECT 
		@VC_RESULT=
		CASE
		WHEN (select TOP 1 CAST(idDocumentoClase AS VARCHAR(50)) from [documento].[DocumentoObjetoClase] DC
				INNER JOIN [objeto].[PropiedadClase] OPC ON OPC.idPropiedadClase = PC.idPropiedadClase
				WHERE idObjeto = PC.idObjeto AND idTipoObjeto = PC.idTipoObjeto AND CAST(idDocumentoClase AS VARCHAR(50)) = PC.valor AND idTipoDato = 'Documento'
				 ORDER BY DC.version DESC) = PC.valor
		THEN (select TOP 1 valor from [documento].[DocumentoObjetoClase] where idObjeto = PC.idObjeto AND idTipoObjeto = PC.idTipoObjeto AND CAST(idDocumentoClase AS VARCHAR(50)) = PC.valor  ORDER BY version DESC) 
		ELSE valor END
	FROM
	[objeto].[ObjetoPropiedadClase] PC
	WHERE
	idObjeto = @idObjeto
	AND idtipoobjeto = @idTipoObjeto
	AND pc.valor = @valor
	AND PC.activo = 1

	RETURN @VC_RESULT

END
go

