-- =============================================
-- Author:		Gerardo Zamudio
-- Create date: 23/04/2019
-- Description:	Edita los valores de un documento
-- =============================================
/*
	Fecha:03/06/2019		Sandra Gil Rosales 
												
	--2019

	*- Testing...
	EXEC [objeto].[UPD_OBJETODOCUMENTO_SP]
		@tipo				= 'clase'
		,@idClase			= 'Automovil'
		,@idTipoObjeto		= 109
		,@idDocumento		= 18
		,@idObjeto			= 13924
		,@idFileServer		= 24387
		,@vigencia			= '2020-09-25'
		,@valor				= 'bonita'
		,@costo				= ''
		,@idEstado			= 02
		,@comentario		= '' 
		,@idUsuario			= 6115
		,@costoPagado		= 0
		,@idConcepto		= 0 
		,@idLineaCaptura	= 0
		,@idFacturaPDF		= 0
		,@idFacturaXML		= 0
		,@err				= ''
	
*/
-- =============================================

create PROCEDURE [objeto].[UPD_OBJETODOCUMENTO_SP]
	@tipo				VARCHAR(30),
	@idClase			VARCHAR (10),
	@idTipoObjeto		INT,
	@idDocumento		INT,
	@idObjeto			INT,
	@idFileServer		INT = NULL,
	@vigencia			DATETIME,
	@valor				VARCHAR(500),
	@costo				VARCHAR(200)= NULL,
	@idEstado			INT,
	@comentario			varchar(max) = NULL,
	@idUsuario			INT,
-- variables para la tabla de costos
	@costoPagado		BIT = false,
	@idConcepto			INT = 0,
	@idLineaCaptura		INT = 0,
	@idFacturaPDF		INT = 0,
	@idFacturaXML		INT =  0,
	@err				varchar(max) OUTPUT
AS 
BEGIN

	SET @err = '';
	DECLARE @idCostoDocumentoGeneral INT;
	DECLARE @idCostoDocumentoClase INT;
	DECLARE @idCostoDocumentoContrato INT;
	DECLARE @activo INT = 1;
	DECLARE @version INT;
	DECLARE
		@VC_ErrorMessage	VARCHAR(4000)	= '',
		@VC_ThrowMessage	VARCHAR(100)	= 'Ocurrio un error en el stored: [INS_OBJETODOCUMENTO_SP]:',
		@VC_ErrorSeverity	INT = 0,
		@VC_ErrorState		INT = 0
	 BEGIN TRY 
		BEGIN TRANSACTION [INS_OBJETODOCUMENTO_SP]
			IF @tipo = 'general'
			BEGIN
				IF (@idConcepto > 0 AND @costo is not null )
				BEGIN
					PRINT 'COSTO'
				--INSERT INTO [documento].[CostoDocumentoGeneral]
				--		   ([idDocumentoGeneral]
				--		   ,[idClase]
				--		   ,[idTipoObjeto]
				--		   ,[idObjeto]
				--		   ,[version]
				--		   ,[idConcepto]
				--		   ,[costo]
				--		   ,[idLineaCaptura]
				--		   ,[idFacturaPDF]
				--		   ,[idFacturaXML]
				--		   ,[idUsuario]
				--		   ,[activo]
				--		   ,[pagado])
				--	 VALUES
				--		   (@idDocumento
				--		   ,@idClase
				--		   ,@idTipoObjeto
				--		   ,@idObjeto
				--		   ,@version				   
				--		   ,@idConcepto
				--		   ,@costo
				--		   ,@idLineaCaptura
				--		   ,@idFacturaPDF
				--		   ,@idFacturaXML
				--		   ,@idUsuario
				--		   ,@activo
				--		   ,@costoPagado)
				--	SET @idCostoDocumentoGeneral = @@IDENTITY  
					END

				UPDATE [documento].[DocumentoObjetoGeneral]
					SET vigencia = @vigencia
						,valor = @valor
						,idEstado = @idEstado
						,comentario = @comentario
				WHERE idDocumentoGeneral = @idDocumento
					AND idClase = @idClase
					AND idTipoObjeto = @idTipoObjeto
					AND idObjeto = @idObjeto
					AND idFileServer = @idFileServer
			
			END ELSE
			IF @tipo = 'clase'
			BEGIN
				IF (@idConcepto > 0 AND @costo is not null )
					BEGIN
						PRINT 'COSTO'
						--INSERT INTO [documento].[CostoDocumentoClase]
						--		   ([idDocumentoClase]
						--		   ,[idClase]
						--		   ,[idTipoObjeto]
						--		   ,[idObjeto]
						--		   ,[version]
						--		   ,[idConcepto]
						--		   ,[costo]
						--		   ,[idLineaCaptura]
						--		   ,[idFacturaPDF]
						--		   ,[idFacturaXML]
						--		   ,[idUsuario]
						--		   ,[activo]
						--		   ,[pagado])
						--	 VALUES
						--		   (@idDocumento
						--			,@idClase
						--			,@idTipoObjeto
						--			,@idObjeto
						--			,@version			   
						--		   ,@idConcepto
						--		   ,@costo
						--		   ,@idLineaCaptura
						--		   ,@idFacturaPDF
						--		   ,@idFacturaXML
						--		   ,@idUsuario
						--		   ,@activo
						--		   ,@costoPagado)
						--	SET @idCostoDocumentoClase = @@IDENTITY
					END	
				print 'holi'
				UPDATE [documento].[DocumentoObjetoClase]
					SET vigencia = @vigencia
						,valor = @valor
						,comentario = @comentario
						,idEstado = @idEstado
				WHERE idDocumentoClase = @idDocumento
					  AND idClase = @idClase
					  AND idTipoObjeto = @idTipoObjeto
					  AND idObjeto = @idObjeto
					  AND idFileServer = @idFileServer
			END ELSE
			IF @tipo = 'contrato'
			BEGIN
			IF (@idConcepto > 0 AND @costo is not null  )
			BEGIN
				PRINT 'COSTO'
				--INSERT INTO [documento].[CostoDocumentoContrato]
				--	   ([idDocumentoContrato]
				--	   ,[idClase]
				--	   ,[idTipoObjeto]
				--	   ,[idObjeto]
				--	   ,[version]
				--	   ,[idConcepto]
				--	   ,[costo]
				--	   ,[idLineaCaptura]
				--	   ,[idFacturaPDF]
				--	   ,[idFacturaXML]
				--	   ,[idUsuario]
				--	   ,[activo]
				--	   ,[pagado])
				-- VALUES
				--		(@idDocumento
				--		,@idClase
				--		,@idTipoObjeto
				--		,@idObjeto
				--		,@version				   
				--		,@idConcepto
				--		,@costo
				--		,@idLineaCaptura
				--		,@idFacturaPDF
				--		,@idFacturaXML
				--		,@idUsuario
				--		,@activo
				--		,@costoPagado)
				--SET @idCostoDocumentoContrato = @@IDENTITY
			END
				UPDATE [documento].[DocumentoObjetoContrato]
					SET vigencia = @vigencia
						,valor = @valor
						,idEstado = @idEstado
						,comentario = @comentario
				WHERE idDocumentoContrato = @idDocumento
					  AND idClase = @idClase
					  AND idTipoObjeto = @idTipoObjeto
					  AND idObjeto = @idObjeto
					  AND idFileServer = @idFileServer
			
			END
	
			IF (@@ERROR = 0)

				BEGIN

				DECLARE @llave VARCHAR(MAX) = '{"idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '","idTipoObjeto":"' + CAST(@idTipoObjeto AS VARCHAR(50)) + 
				'","idFileServer":"' + CAST(@idFileServer AS VARCHAR(50)) + '"}'

					EXEC [evento].[evento].[INS_EVENTO]
					@accion = 1
					,@modulo = 171
					,@gerencia = 1
					,@llave = @llave
					,@origen = NULL
					,@applicationId = 11
					,@idEstado = NULL
					,@idContratoZona = NULL
					,@idUsuario = @idUsuario
					,@err = ''
				END

			select 'ok' as ok;
		COMMIT TRANSACTION [INS_OBJETODOCUMENTO_SP]
		END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION [INS_OBJETODOCUMENTO_SP]
				SET @VC_ErrorMessage = { 
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage
					) 
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
				SET @err = @VC_ErrorMessage;
			END
		END CATCH
    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

