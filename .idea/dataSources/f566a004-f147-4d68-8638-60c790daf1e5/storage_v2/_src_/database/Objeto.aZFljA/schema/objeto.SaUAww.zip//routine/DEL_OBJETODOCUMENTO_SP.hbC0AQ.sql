-- =============================================
-- Author:		José Etmanuel Hernández Rejón 
-- Create date: 23/04/2019
-- Description:	Marcar como eliminado un documento
-- =============================================
/*
	Fecha:12/07/2019		Autor		Descripción 
	--2019				Sandra Gil Rosales Se cambio el concepto, ya no se versionara, ahora se elimina completamente de la tabla 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [objeto].[DEL_OBJETODOCUMENTO_SP]
		@idClase = 'Automovil',
		@idTipoObjeto = 71,
		@idObjeto = 171,
		@tipo = 'general',
		@idDocumento = 25,
		@idUsuario = 2,
		@version = 3,
		@err = @salida OUTPUT;
	
*/
-- =============================================

CREATE PROCEDURE [objeto].[DEL_OBJETODOCUMENTO_SP]
	@idClase			VARCHAR(30),
	@idTipoObjeto		INT,
	@idObjeto			INT,
	@tipo				VARCHAR(30),
	@idDocumento		INT,
	@version			INT = NULL,
	@idUsuario			INT,
	@err				varchar(max) OUTPUT
AS
	BEGIN TRY
	BEGIN TRANSACTION

	SET @err = '';	
	IF (@tipo = 'general') 
		BEGIN

			--SELECT * 
			DELETE FROM [documento].[DocumentoObjetoGeneral]
			WHERE  idClase = @idClase AND idTipoObjeto = @idTipoObjeto AND idObjeto = @idObjeto AND idDocumentoGeneral = @idDocumento AND version = @version
		
			-- borramos los costos si tiene 
			-- SELECT * 
			DELETE FROM [documento].[CostoDocumentoGeneral]
			WHERE  idClase = @idClase AND idTipoObjeto = @idTipoObjeto AND idObjeto = @idObjeto AND idDocumentoGeneral = @idDocumento AND version = @version

		END
		ELSE IF (@tipo = 'clase') 
		BEGIN
		
			--SELECT *  
			DELETE FROM [Objeto].[documento].[DocumentoObjetoClase]
			WHERE   idClase = @idClase AND idTipoObjeto = @idTipoObjeto AND idObjeto = @idObjeto AND idDocumentoClase = @idDocumento AND version = @version
			--SELECT *  
			DELETE FROM [documento].[CostoDocumentoClase]
			WHERE  idClase = @idClase AND idTipoObjeto = @idTipoObjeto AND idObjeto = @idObjeto AND idDocumentoClase = @idDocumento AND version = @version
		
		END
		ELSE IF (@tipo = 'contrato') 
		BEGIN
			
			--SELECT *  
			DELETE FROM [Objeto].[documento].[DocumentoObjetoContrato]
			WHERE idClase = @idClase AND idTipoObjeto = @idTipoObjeto AND idObjeto = @idObjeto AND idDocumentoContrato = @idDocumento AND version = @version
			--SELECT *  
			DELETE FROM [documento].[CostoDocumentoContrato]
			WHERE   idClase = @idClase AND idTipoObjeto = @idTipoObjeto AND idObjeto = @idObjeto AND idDocumentoContrato = @idDocumento AND version = @version     
		
		END
	SET @err = 'El documento se ha borrado correctamente.'
	COMMIT
END TRY

BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH
go

