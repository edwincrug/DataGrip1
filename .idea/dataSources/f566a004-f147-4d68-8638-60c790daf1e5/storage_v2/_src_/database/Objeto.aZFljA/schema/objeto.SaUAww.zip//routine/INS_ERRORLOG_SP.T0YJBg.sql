CREATE PROCEDURE [objeto].[INS_ERRORLOG_SP]
(
	@placa 					varchar(8),
	@estado 				int,
	@error 					varchar(500)
)
AS
BEGIN

	INSERT objeto.LogMultas
		(
			placa,
			estado,
			fecha,
			error
		)
 	VALUES
		(
			@placa,
			@estado,
			getdate(),
			@error
		)

	SELECT @@IDENTITY idLog

END

go

