
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <11-04-2019>
-- Description:	<Insertar un objeto>
-- =============================================
/*
	*** Versionamiento
	Fecha 			Autor	Descripción 
	21/05/2019		JEHR	Agregando versionamiento,y contrato obligatorio como idUsuario
	29/07/2019		JEHR	Agregando versionamiento,y contrato obligatorio como idUsuario
	05/05/2019		JLLG	Se agrego el parametro idVersion
	*- Testing...

	EXEC [objeto].[INS_OBJETO_SP]

@activo= true
,@idCentroCosto= ""
,@idClase= 'Automovil'
,@idCliente= 216
,@idObjetoActual= '0'
,@idObjetoEstatus= 'ACT'
,@idTipoObjeto= 109
,@idVersion= 1
,@idZona= 13994
,@numeroContrato= '128'
,@rfcEmpresa= 'ASE0508051B6'
,@vin= '1234567890'
,@vinRepetido: 'true'
,@idusuario = 6115
,@err = ''

	EXEC [objeto].[INS_OBJETO_SP]
	@idClase = 'Automovil',
	@idTipoObjeto = 858,
	@idVersion = 0,
	@idObjetoActual = 0,
	@rfcEmpresa = 'ASE0508051B6',
	@idCliente = 185,
	@numeroContrato = '43',
	@idUsuario = 6119,
	@activo = 1,
	@idZona = 6752,
	@idCentroCosto = '',
	@idObjetoEstatus = 'ACT',
	@vinRepetido = 0,
	@vin = 'VIN00001',
	@err = ''



*/
-- =============================================
CREATE PROCEDURE [objeto].[INS_OBJETO_SP]
	@idClase				varchar(10),
	@idTipoObjeto			int,
	@idVersion				int,
	@idObjetoActual			int = NULL,
	-- Datos del contrato
	@rfcEmpresa				varchar(13),
	@idCliente				int,
	@numeroContrato			nvarchar(50),
	-- Bitacora de usuario
	@idUsuario				int,
	@activo					bit = 1,
	@idZona					int,
	@idCentroCosto			int,
	@idObjetoEstatus		varchar(3) = 'ACT',
	@vinRepetido			BIT = 0,
	@vin					VARCHAR(100) = NULL,
	@err					varchar(max) OUTPUT

AS
	BEGIN TRY
	BEGIN TRANSACTION

	SET @err = '';	
	DECLARE @idObjeto INT;
	DECLARE @estatus NVARCHAR(50)

	--IF @idVersion=0 SET @idVersion=NULL
	
	--Si se trata de 'pérdida total' o 'robo' vamos a eliminar las relaciones de los dispositivos instalados
	IF ( @idObjetoEstatus IN ('PT','ROB') )
	BEGIN

		IF EXISTS ( SELECT 1 FROM Inventario.inventario.ObjetoGPSSIM WHERE idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjeto )
		BEGIN
			
			SELECT @estatus = e.nombre FROM Cliente.contrato.ObjetoEstatus e where idObjetoEstatus = @idObjetoEstatus
			--Se actualiza la relación en el AVL (Objeto-Dispositivo)
			--SELECT ODIS.*
			UPDATE ODIS SET activo = 0
			FROM Inventario.inventario.ObjetoGPSSIM OG
				INNER JOIN Inventario.inventario.GPSSIM GS ON GS.idGPSSIM = OG.idGPSSIM
				INNER JOIN Inventario.inventario.Inventario INV ON INV.idInventario = GS.idInventarioGPS --OR INV.idInventario = GS.idInventarioSIM
				INNER JOIN AVL.vehiculo.ObjetoDispositivo ODIS ON ODIS.idObjeto = OG.idObjeto
			WHERE OG.idObjeto = @idObjetoActual
				AND OG.idTipoObjeto = @idTipoObjeto
				AND OG.activo = 1
		

			--Se actualiza el inventario
			--SELECT INV.*
			UPDATE INV SET activo = 0, fechaBaja = GETDATE()
			FROM Inventario.inventario.ObjetoGPSSIM OG
				INNER JOIN Inventario.inventario.GPSSIM GS ON GS.idGPSSIM = OG.idGPSSIM
				INNER JOIN Inventario.inventario.Inventario INV ON INV.idInventario = GS.idInventarioGPS OR INV.idInventario = GS.idInventarioSIM
			WHERE OG.idObjeto = @idObjetoActual
				AND OG.idTipoObjeto = @idTipoObjeto
				AND OG.activo = 1


			--Se actualiza GPSSIM (desvinculación GPS-SIM)
			--SELECT GS.* 
			UPDATE GS SET estatus = 0, fechaBaja = GETDATE()
			FROM Inventario.inventario.ObjetoGPSSIM OG
				INNER JOIN Inventario.inventario.GPSSIM GS ON GS.idGPSSIM = OG.idGPSSIM
			WHERE OG.idObjeto = @idObjetoActual
				AND OG.idTipoObjeto = @idTipoObjeto
				AND OG.activo = 1


			--Se actualiza el ObjetoGPSSIM (desvinculación Objeto-GPSSIM)
			--SELECT OG.* 
			UPDATE OG SET activo = 0, fechaBaja = GETDATE(), observaciones = @estatus
			FROM Inventario.inventario.ObjetoGPSSIM OG
			WHERE OG.idObjeto = @idObjetoActual
				AND OG.idTipoObjeto = @idTipoObjeto
				AND OG.activo = 1

			--SELECT *
			DELETE opc
			FROM objeto.objeto.ObjetoPropiedadClase opc
				INNER JOIN objeto.objeto.PropiedadClase pc ON pc.idPropiedadClase = opc.idPropiedadClase
			WHERE opc.idObjeto = @idObjetoActual
				AND pc.valor = 'ID GPS'

		END

	END
	
	------------------------------------------------------------------- SI EL VIN YA ESTA REGISTRADO -------------------------------------------------------------------
	IF (@vinRepetido = 1)
		BEGIN
			DECLARE @idTipoObjetoRepetido	INT,
					@rfcEmpresaRepetido		VARCHAR(13),
					@idClienteRepetido		INT,
					@numeroContratoRepetido	VARCHAR(10)

			SELECT TOP 1 @idObjeto = PC.idObjeto, 
						@idTipoObjetoRepetido = PC.idTipoObjeto,
						@rfcEmpresaRepetido = CO.rfcEmpresa,
						@idClienteRepetido = CO.idCliente,
						@numeroContratoRepetido = CO.numeroContrato
					FROM objeto.ObjetoPropiedadClase  PC
							INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
							INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
							INNER JOIN  objeto.PropiedadClase p on p.idPropiedadClase = PC.idPropiedadClase 
							WHERE PC.valor = @VIN
							AND p.agrupador = 'VIN'
							AND O.activo = 1
							and co.idObjetoEstatus = 'ACT'
		------------------------------------------------------------------- SI QUIEREN CAMBIAR EL VIN POR OTRO TIPO DE UNIDAD DIFERENTE -------------------------------------------------------------------
			IF(@idTipoObjeto != @idTipoObjetoRepetido)
			BEGIN
			PRINT 'AAA'
				SET @err = 'El tipo de unidad seleccionado es diferente al ya registrado.'
				UPDATE [Cliente].[contrato].[Objeto] SET idObjetoEstatus = 'INA' 
				WHERE rfcEmpresa = @rfcEmpresaRepetido 
				AND idCliente = @idClienteRepetido
				AND numeroContrato = @numeroContratoRepetido
				AND idObjeto = @idObjeto
				AND idTipoObjeto = @idTipoObjetoRepetido
				AND idObjetoEstatus = 'ACT'
				UPDATE objeto.Objeto
					SET activo = 0 
				WHERE idObjeto = @idObjeto
					AND idTipoObjeto = @idTipoObjetoRepetido
				------------------------------------------ SI APENAS SE VA A ADAR DE ALTA EL OBJETO INSERTAMOS UN REGISTRO NUEVO CON ESE VIN, DE LO CONTRARIO SOLO ACTUALIZAMOS ------------------------------------------
				IF EXISTS(SELECT 
							1
							FROM Cliente.contrato.Objeto
							WHERE rfcEmpresa = @rfcEmpresa
								AND idCliente = @idCliente
								AND numeroContrato = @numeroContrato
								AND idClase = @idClase
								AND idTipoObjeto = @idTipoObjeto
								AND idObjeto = @idObjetoActual)
				BEGIN
				PRINT 'BBB'
						UPDATE [Cliente].[contrato].[Objeto]
						SET idContratoZona = @idZona
							,idObjetoEstatus = @idObjetoEstatus
							,idUsuario = @idUsuario
							,activo = 1
							,idCentroCosto = @idCentroCosto
						WHERE   rfcEmpresa =			@rfcEmpresa
								AND idCliente =			@idCliente
								AND numeroContrato =	@numeroContrato
								AND idClase =			@idClase
								AND idTipoObjeto =		@idTipoObjeto
								AND idObjeto =			@idObjetoActual
						SELECT @idObjetoActual idObjeto, @idTipoObjeto idTipoObjeto

				END
				ELSE
				BEGIN
				PRINT 'CCC'
					SET @vinRepetido = 0
					EXEC [objeto].[INS_OBJETO_SP]
						@idClase,
						@idTipoObjeto,
						@idVersion,
						@idObjetoActual,
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idUsuario,
						@activo,
						@idZona,
						@idCentroCosto,
						@idObjetoEstatus,
						@vinRepetido,
						@vin,
						''
					SELECT 'nueva' nuevaUnidad
				END
			END
			ELSE
			BEGIN
			------------------------------------------------------------------- SI EL VIN PERTENECE AL MISMO TIPO DE UNIDAD -------------------------------------------------------------------
				print 111
				IF EXISTS(SELECT 1 FROM objeto.ObjetoPropiedadClase PC
					INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
					INNER JOIN objeto.PropiedadClase p on p.idPropiedadClase = PC.idPropiedadClase
					INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
					WHERE PC.valor = @VIN
					and co.rfcEmpresa = @rfcEmpresa
					AND co.idCliente = @idCliente
					AND co.numeroContrato = @numeroContrato
					AND CO.activo = 1
					AND O.activo = 1
					AND p.agrupador = 'VIN'
					AND CO.idObjetoEstatus = 'ACT')
				BEGIN
				------------------------------------------------------------------- SI EL VIN PERTENECE AL MISMO CONTRATO -------------------------------------------------------------------
				print 222
					UPDATE [Cliente].[contrato].[Objeto] SET idObjetoEstatus = 'INA' 
					WHERE rfcEmpresa = @rfcEmpresaRepetido 
					AND idCliente = @idClienteRepetido
					AND numeroContrato = @numeroContratoRepetido
					AND idObjeto = @idObjeto
					AND idTipoObjeto = @idTipoObjetoRepetido
					AND idObjetoEstatus = 'ACT'
					--UPDATE objeto.Objeto
					--	SET activo = 0 
					--WHERE idObjeto = @idObjeto
						--AND idTipoObjeto = @idTipoObjetoRepetido
					IF (@idObjetoActual = 0)
					BEGIN
					print 333
						--SET @vinRepetido = 0
						--EXEC [objeto].[INS_OBJETO_SP]
						--	@idClase,
						--	@idTipoObjeto,
						--	@idVersion,
						--	@idObjetoActual,
						--	@rfcEmpresa,
						--	@idCliente,
						--	@numeroContrato,
						--	@idUsuario,
						--	@activo,
						--	@idZona,
						--	@idCentroCosto,
						--	@idObjetoEstatus,
						--	@vinRepetido,
						--	@vin,
						--	''
						--SELECT 'nueva' nuevaUnidad
						INSERT	[Cliente].[contrato].[Objeto] (rfcEmpresa,
																	idCliente,
																	numeroContrato,
																	idClase,
																	idTipoObjeto,
																	idObjeto,
																	idContratoZona,
																	idObjetoEstatus,
																	idUsuario,
																	activo,
																	idCentroCosto)
						select
							@rfcEmpresa,
							@idCliente,
							@numeroContrato,
							@idClase,
							@idTipoObjeto,
							@idObjeto,
							@idZona,
							@idObjetoEstatus,
							@idUsuario,
							1,
							@idCentroCosto

						SELECT @idObjeto idObjeto, @idTipoObjeto idTipoObjeto
					END
					ELSE
					BEGIN
						IF EXISTS(SELECT 
									1
									FROM Cliente.contrato.Objeto
									WHERE rfcEmpresa = @rfcEmpresa
										AND idCliente = @idCliente
										AND numeroContrato = @numeroContrato
										AND idClase = @idClase
										AND idTipoObjeto = @idTipoObjeto
										AND idObjeto = @idObjetoActual)
						BEGIN
						print 444
								UPDATE [Cliente].[contrato].[Objeto]
								SET idContratoZona = @idZona
									,idObjetoEstatus = @idObjetoEstatus
									,idUsuario = @idUsuario
									,activo = 1
									,idCentroCosto = @idCentroCosto
								WHERE   rfcEmpresa = @rfcEmpresa
										AND idCliente = @idCliente
										AND numeroContrato = @numeroContrato
										AND idClase = @idClase
										AND idTipoObjeto = @idTipoObjeto
										AND idObjeto = @idObjetoActual
								SELECT @idObjetoActual idObjeto, @idTipoObjeto idTipoObjeto
						END
						ELSE
						BEGIN
						print 555
							INSERT	[Cliente].[contrato].[Objeto] (rfcEmpresa,
																	idCliente,
																	numeroContrato,
																	idClase,
																	idTipoObjeto,
																	idObjeto,
																	idContratoZona,
																	idObjetoEstatus,
																	idUsuario,
																	activo,
																	idCentroCosto)
							select
								@rfcEmpresa,
								@idCliente,
								@numeroContrato,
								@idClase,
								@idTipoObjeto,
								@idObjetoActual,
								@idZona,
								@idObjetoEstatus,
								@idUsuario,
								1,
								@idCentroCosto

							SELECT @idObjetoActual idObjeto, @idTipoObjeto idTipoObjeto
						END
					END
				END
				ELSE
				BEGIN
				------------------------------------------------------------------- SI EL VIN PERTENECE A OTRO CONTRATO CON MISMO TIPO OBJETO -------------------------------------------------------------------
				print 666
				UPDATE [Cliente].[contrato].[Objeto] SET idObjetoEstatus = 'INA' 
				WHERE rfcEmpresa = @rfcEmpresaRepetido 
				AND idCliente = @idClienteRepetido
				AND numeroContrato = @numeroContratoRepetido
				AND idObjeto = @idObjeto
				AND idTipoObjeto = @idTipoObjetoRepetido
				AND idObjetoEstatus = 'ACT'

				IF EXISTS(SELECT 
							1
							FROM Cliente.contrato.Objeto
							WHERE rfcEmpresa = @rfcEmpresa
								AND idCliente = @idCliente
								AND numeroContrato = @numeroContrato
								AND idClase = @idClase
								AND idTipoObjeto = @idTipoObjeto
								AND idObjeto = @idObjeto)
				BEGIN
				------------------------------------------------------------------- SI EL OBJETO YA ESTA REGISTRADO EN LA TABLA CONTRATO.OBJETO Y ESTA INACTIVO SE ACTIVA -------------------------------------------------------------------
				print 777
						UPDATE [Cliente].[contrato].[Objeto]
						SET idContratoZona = @idZona
							,idObjetoEstatus = @idObjetoEstatus
							,idUsuario = @idUsuario
							,activo = 1
							,idCentroCosto = @idCentroCosto
						WHERE   rfcEmpresa = @rfcEmpresa
								AND idCliente = @idCliente
								AND numeroContrato = @numeroContrato
								AND idClase = @idClase
								AND idTipoObjeto = @idTipoObjeto
								AND idObjeto = @idObjeto
						SELECT @idObjeto idObjeto, @idTipoObjeto idTipoObjeto
				END
				ELSE
				BEGIN
				print 888
					------------------------------------------------------------------- SI EL OBJETO NO ESTA REGISTRADO EN LA TABLA CONTRATO.OBJETO -------------------------------------------------------------------
					INSERT	[Cliente].[contrato].[Objeto] (rfcEmpresa,
															idCliente,
															numeroContrato,
															idClase,
															idTipoObjeto,
															idObjeto,
															idContratoZona,
															idObjetoEstatus,
															idUsuario,
															activo,
															idCentroCosto)
					select
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idClase,
						@idTipoObjeto,
						@idObjeto,
						@idZona,
						@idObjetoEstatus,
						@idUsuario,
						1,
						@idCentroCosto

					SELECT @idObjeto idObjeto, @idTipoObjeto idTipoObjeto
					
				END
			END

		END
	END

	ELSE
		BEGIN

			IF EXISTS (SELECT idObjeto FROM [objeto].[Objeto] WHERE idObjeto = @idObjetoActual AND idTipoObjeto != @idTipoObjeto AND idClase = @idClase) 
				BEGIN
				print 1
					-- Insertamos el Objeto
					INSERT INTO [objeto].[Objeto]([idClase],[idTipoObjeto],[idVersion],[idUsuario],[activo])
					VALUES(@idClase,@idTipoObjeto,@idVersion,@idUsuario,@activo);

					SET @idObjeto = @@IDENTITY
	
					-- Editamos al Cliente y su asociacion con el objeto y
					INSERT	[Cliente].[contrato].[Objeto] (rfcEmpresa,
															idCliente,
															numeroContrato,
															idClase,
															idTipoObjeto,
															idObjeto,
															idContratoZona,
															idObjetoEstatus,
															idUsuario,
															activo,
															idCentroCosto)
					VALUES(
						@rfcEmpresa,
						@idCliente,
						@numeroContrato,
						@idClase,
						@idTipoObjeto,
						@idObjeto,
						@idZona,
						@idObjetoEstatus,
						@idUsuario,
						1,
						@idCentroCosto)
					

					--update [Cliente].[contrato].[Objeto] set activo = 0
					--WHERE	idObjeto		= @idObjetoActual 
					--AND		idClase			= @idClase

					-- verificamoso si tienen un costo asociado a los documentos 
					IF EXISTS (	SELECT	idCostoDocumentoGeneral, idTipoObjeto, idObjeto, version 
								FROM	[documento].[CostoDocumentoGeneral] 
								WHERE	idObjeto	= @idObjetoActual 
								AND		idClase		= @idClase )
						BEGIN	
							INSERT	[documento].[CostoDocumentoGeneral] 
							SELECT	[idDocumentoGeneral],[idClase],@idTipoObjeto,@idObjeto,[version],[idConcepto],[costo],[idLineaCaptura],[idFacturaPDF],[idFacturaXML],[idUsuario],[activo],[pagado] 
							FROM	[documento].[CostoDocumentoGeneral] 
							WHERE	idObjeto = @idObjetoActual 
							AND		idClase = @idClase
							-- modificamos las tablas de los documentos asociados a el objeto anterior

							UPDATE	[documento].[DocumentoObjetoGeneral]
							SET		idTipoObjeto = b.idTipoObjeto,idObjeto = b.idObjeto,idCostoDocumentoGeneral = b.idCostoDocumentoGeneral
							FROM	[documento].[CostoDocumentoGeneral] AS b 
							WHERE	b.idObjeto  = @idObjeto AND b.idTipoObjeto	= @idTipoObjeto AND [documento].[DocumentoObjetoGeneral].version = b.version 
							AND		[documento].[DocumentoObjetoGeneral].idClase			= @idClase
							AND		[documento].[DocumentoObjetoGeneral].idDocumentoGeneral = b.idDocumentoGeneral
							AND		[documento].[DocumentoObjetoGeneral].idObjeto			= @idObjetoActual

							UPDATE	[documento].[DocumentoObjetoGeneral]
							SET		idTipoObjeto	= @idTipoObjeto,
									idObjeto		= @idObjeto
							WHERE	idObjeto		= @idObjetoActual 
							AND		idClase			= @idClase 
							AND		idCostoDocumentoGeneral IS NULL
						END
					ELSE
						BEGIN 
		   					UPDATE	[documento].[DocumentoObjetoGeneral]
							SET		idTipoObjeto	= @idTipoObjeto,
									idObjeto		= @idObjeto
							WHERE	idObjeto		= @idObjetoActual 
							AND		idClase			= @idClase
						END

					-- verificamoso si tienen un costo asociado a los documentos  clase
					IF EXISTS (SELECT idCostoDocumentoClase, idTipoObjeto, idObjeto, version FROM [documento].[CostoDocumentoClase] WHERE idObjeto = @idObjetoActual AND idClase = @idClase )
						BEGIN
							INSERT	[documento].[CostoDocumentoClase] 
							SELECT	[idDocumentoClase],[idClase],@idTipoObjeto,@idObjeto,[version],[idConcepto],[costo],[idLineaCaptura],[idFacturaPDF],[idFacturaXML],
									[idUsuario],[activo],[pagado] 
							FROM	[documento].[CostoDocumentoClase] 
							WHERE	idObjeto	= @idObjetoActual 
							AND		idClase		= @idClase

							UPDATE	[documento].[DocumentoObjetoClase] 
							SET		idTipoObjeto			= @idTipoObjeto,
									idObjeto				= @idObjeto,
									idCostoDocumentoClase	= b.idCostoDocumentoClase
							FROM	[documento].[CostoDocumentoClase] AS b 
							WHERE	b.idObjeto		= @idObjeto 
							AND		b.idTipoObjeto	= @idTipoObjeto 
							AND		[documento].[DocumentoObjetoClase].version	= b.version 
							AND		[documento].[DocumentoObjetoClase].idClase	= @idClase
							AND		[documento].[DocumentoObjetoClase].idDocumentoClase = b.idDocumentoClase
							AND		[documento].[DocumentoObjetoClase].idObjeto			= @idObjetoActual

							UPDATE	[documento].[DocumentoObjetoClase]
							SET		idTipoObjeto			= @idTipoObjeto,
									idObjeto				= @idObjeto
							WHERE	idObjeto				= @idObjetoActual 
							AND		idClase					= @idClase 
							AND		idCostoDocumentoClase	IS NULL

						END
					ELSE 
						BEGIN
		   					UPDATE	[documento].[DocumentoObjetoClase]
							SET		idTipoObjeto= @idTipoObjeto,
									idObjeto	= @idObjeto
							WHERE	idObjeto	= @idObjetoActual 
							AND		idClase		= @idClase
						END
					-- verificamoso si tienen un costoi asociado a los documentos  clase
					IF EXISTS (	SELECT	idCostoDocumentoContrato, idTipoObjeto, idObjeto, version 
								FROM	[documento].[CostoDocumentoContrato] 
								WHERE	idObjeto = @idObjetoActual AND idClase = @idClase )
						BEGIN
							INSERT	[documento].[CostoDocumentoContrato] 
							SELECT	[idDocumentoContrato],[idClase],@idTipoObjeto,@idObjeto,[version],[idConcepto],[costo],[idLineaCaptura],[idFacturaPDF],
									[idFacturaXML],[idUsuario],[activo],[pagado] 
							FROM	[documento].[CostoDocumentoContrato] 
							WHERE	idObjeto	= @idObjetoActual 
							AND		idClase		= @idClase

							UPDATE	[documento].[DocumentoObjetoContrato]
							SET		idTipoObjeto	= b.idTipoObjeto,
									idObjeto		= b.idObjeto,
									idCostoDocumentoContrato = b.idCostoDocumentoContrato
							FROM	[documento].[CostoDocumentoContrato] AS b 
							WHERE	b.idObjeto		= @idObjeto 
							AND		b.idTipoObjeto	= @idTipoObjeto 
							AND		[documento].[DocumentoObjetoContrato].version = b.version 
							AND		[documento].[DocumentoObjetoContrato].idClase = @idClase
							AND		[documento].[DocumentoObjetoContrato].idDocumentoContrato = b.idDocumentoContrato
							AND		[documento].[DocumentoObjetoContrato].idObjeto = @idObjetoActual

							UPDATE	[documento].[DocumentoObjetoContrato]
							SET		idTipoObjeto = @idTipoObjeto,
									idObjeto	= @idObjeto
							WHERE	idObjeto	= @idObjetoActual 
							AND		idClase		= @idClase 
							AND		idCostoDocumentoContrato IS NULL

							SELECT	idObjeto, idTipoObjeto 
							FROM	[documento].[DocumentoObjetoContrato] 
							WHERE	idObjeto  = @idObjeto 
							AND		idTipoObjeto = @idTipoObjeto 
						END
					ELSE 
						BEGIN
							UPDATE	[documento].[DocumentoObjetoContrato]
							SET		idTipoObjeto = @idTipoObjeto,
									idObjeto	= @idObjeto
							WHERE	idObjeto	= @idObjetoActual 
							AND		idClase		= @idClase
						END
			

					-- modificamos las tablas de los documentos asociados a el objeto anterior
					-- borramos los anteriores
	   
					DELETE FROM [documento].[CostoDocumentoClase]
					WHERE idObjeto = @idObjetoActual AND idClase = @idClase
		   
					DELETE FROM [documento].[CostoDocumentoGeneral]
					WHERE idObjeto = @idObjetoActual AND idClase = @idClase

					DELETE FROM [documento].[CostoDocumentoContrato]
					WHERE idObjeto = @idObjetoActual AND idClase = @idClase       

					SELECT idObjeto, idTipoObjeto FROM [objeto].[Objeto]
					WHERE idObjeto = @idObjeto AND idTipoObjeto = @idTipoObjeto

				END
			ELSE IF EXISTS (SELECT idObjeto FROM [objeto].[Objeto] WHERE idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjeto AND idClase = @idClase and idVersion=@idVersion) 
				BEGIN
				print 2

					update Objeto.objeto.Objeto set activo = @activo where idObjeto	= @idObjetoActual 
					AND		idClase		= @idClase
					-- Editamos al Cliente y su asociacion con el objeto y
					UPDATE	[Cliente].[contrato].[Objeto]
					SET		[idUsuario]			= @idUsuario,
							[idContratoZona]	= @idZona,
							[idCentroCosto]		= @idCentroCosto,
							idObjetoEstatus		= @idObjetoEstatus
					WHERE	idObjeto	= @idObjetoActual 
					AND		idClase		= @idClase
					and numeroContrato = @numeroContrato
					and rfcEmpresa = @rfcEmpresa
					and idCliente = @idCliente

					SELECT	idObjeto, idTipoObjeto 
					FROM	[objeto].[Objeto]
					WHERE	idObjeto	= @idObjetoActual 
					AND		idTipoObjeto= @idTipoObjeto
				END
			ELSE IF EXISTS (SELECT idObjeto FROM [objeto].[Objeto] WHERE idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjeto AND idClase = @idClase and (ISNULL(idVersion,0)<>@idVersion OR @idVersion = '')) 
				BEGIN
				print 3
					-- Editamos al Cliente y su asociacion con el objeto y
					UPDATE	[objeto].[objeto].[Objeto]
					SET		idVersion		= @idVersion,
							activo			= @activo
					WHERE	idObjeto		= @idObjetoActual 
					AND     idTipoObjeto	= @idTipoObjeto 
					AND		idClase			= @idClase

					UPDATE	[Cliente].[contrato].[Objeto]
					SET		[idUsuario]			= @idUsuario,
							[idContratoZona]	= @idZona,
							[idCentroCosto]		= @idCentroCosto,
							idObjetoEstatus		= @idObjetoEstatus
					WHERE	idObjeto	= @idObjetoActual 
					AND		idClase		= @idClase
					and numeroContrato = @numeroContrato
					and rfcEmpresa = @rfcEmpresa
					and idCliente = @idCliente

					SELECT	idObjeto, idTipoObjeto 
					FROM	[objeto].[Objeto]
					WHERE	idObjeto	= @idObjetoActual 
					AND		idTipoObjeto= @idTipoObjeto

					SELECT	idObjeto, idTipoObjeto 
					FROM	[objeto].[Objeto]
					WHERE	idObjeto	= @idObjetoActual 
					AND		idTipoObjeto= @idTipoObjeto
				END
			ELSE 
				BEGIN
				print 4
					-- Insertamos el Objeto
					

					INSERT INTO [objeto].[Objeto]([idClase],[idTipoObjeto],[idVersion],[idUsuario],[activo])
					VALUES(@idClase,@idTipoObjeto,@idVersion,@idUsuario,@activo);

					

					SET @idObjeto = @@IDENTITY
					-- SELECT @idObjeto AS idObjeto;
					-- Lo damos de alta en un contrato 
					INSERT INTO [Cliente].[contrato].[Objeto]([rfcEmpresa],[idCliente],[numeroContrato],[idClase],[idTipoObjeto],[idObjeto],[idContratoZona],[idObjetoEstatus],[idUsuario],[activo],[idCentroCosto])
					VALUES(@rfcEmpresa,@idCliente,@numeroContrato,@idClase,@idTipoObjeto,@idObjeto,@idZona,@idObjetoEstatus,@idUsuario,1,@idCentroCosto)


					--INSERT INTO [Solicitud].[integridad].[ContratoObjeto] VALUES(
					--	@rfcEmpresa,
					--	@idCliente,
					--	@numeroContrato,
					--	@idObjeto,
					--	@idTipoObjeto,
					--	@idClase
					--);

					SELECT idObjeto, idTipoObjeto FROM [objeto].[Objeto] WHERE idObjeto = @idObjeto AND idTipoObjeto = @idTipoObjeto

					IF (@@ERROR = 0)
						BEGIN
							DECLARE @llave VARCHAR(MAX) = '{"idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '","idClase":"' + @idClase + '","rfcEmpresa":"' + @rfcEmpresa + '","idCliente":"' + 
							CAST(@idCliente AS VARCHAR(50)) + '","numeroContrato":"' + @numeroContrato + '"}'

							EXEC [evento].[evento].[INS_EVENTO]
							@accion = 1
							,@modulo = 170
							,@gerencia = 1
							,@llave = @llave
							,@origen = NULL
							,@applicationId = 11
							,@idEstado = NULL
							,@idContratoZona = NULL
							,@idUsuario = @idUsuario
							,@err = ''
						END
				END
			SET @err = 'El Objeto se registro correctamente.'
		END
	COMMIT
END TRY

BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH

go

