
-- =============================================
-- Author: Andres Farias
-- Create date: 25-06-2019
-- Description: 
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [objeto].[SEL_OBJETO_ESPECIALIDADES_SP]  'Automovil', 6077, '123PEMEX', 78, 7, 3,
	@salida OUTPUT;
	SELECT @salida AS salida;

*/
-- =============================================
CREATE PROCEDURE [objeto].[SEL_OBJETO_ESPECIALIDADES_SP] 
	@idClase				varchar(50),
	@idUsuario				INT,
	@numeroContrato			varchar(50) = NULL,
	@idCliente				int = NULL,
	@idObjeto				int ,
	@idTipoObjeto			int ,
	@err					varchar(500) OUTPUT
AS


BEGIN

	DECLARE @salida varchar(max) ='';

	select 
	resumen.especialidad,
	sum(resumen.cantidad) eventos,
	sum(resumen.Costo) total
		from (
		select
			par.idPartida,
			[Partida].[partida].[getPropiedadPartida]  (par.idPartida, 'Especialidad', 'clase') Especialidad,
			count(par.idPartida)*cotpar.cantidad cantidad,
			sum(cotpar.cantidad*cotpar.costo) Costo
		from [Solicitud].[solicitud].SolicitudObjeto so
		inner join [Solicitud].solicitud.solicitud s on
			s.idSolicitud=so.idSolicitud and
			s.idTipoSolicitud = so.idTipoSolicitud and
			s.numeroContrato = so.numeroContrato and
			s.idCliente = so.idCliente and
			s.idClase = so.idClase
		
		inner join [Solicitud].fase.SolicitudEstatusPaso sep on
			sep.idSolicitud = so.idSolicitud and
			sep.numeroContrato = so.numeroContrato and
			sep.idCliente = so.idCliente and
			sep.idClase = so.idClase

		inner join [Solicitud].solicitud.SolicitudCotizacion coti on
			coti.idSolicitud = so.idSolicitud and
			coti.numeroContrato = so.numeroContrato and
			coti.idCliente = so.idCliente and
			coti.idClase = so.idClase
		
		left join [Solicitud].solicitud.SolicitudCotizacionPartida cotpar on
			cotpar.idCotizacion = coti.idCotizacion
			and cotpar.idEstatusCotizacionPartida not in ('CANCELADA','RECHAZADA') and
			cotpar.numeroContrato = coti.numeroContrato and
			cotpar.idCliente = coti.idCliente and
			cotpar.idClase = coti.idClase

		inner join [Solicitud].fase.Fase fas on
			sep.idFase=fas.idFase
		inner join partida.partida.partida par on 
			par.idPartida = cotpar.idPartida and
			par.idTipoObjeto = cotpar.idTipoObjeto and
			par.idClase = cotpar.idClase
		where
			sep.fechaSalida is null and
			so.idObjeto = @idObjeto and
			so.idTipoObjeto = @idTipoObjeto and
			so.idClase = @idClase and
			so.idCliente = @idCliente and
			so.numeroContrato = @numeroContrato
		group by
			par.idPartida,
			cotpar.cantidad
		) resumen
		group by resumen.Especialidad
END

go

