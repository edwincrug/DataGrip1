-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener los campos de clase de los objetos(unidades)>
-- =============================================
-- SELECT 
    -- [idDocumentoClase]
    -- ,[idClase]
    -- ,[idTipoObjeto]
    -- ,[idObjeto]
    -- ,[version]
    -- ,[idTipoDocumento]
    -- ,[idFileServer]
    -- ,[vigencia]
    -- ,[valor]
    -- ,[idUsuario]
    -- ,[fecha]
    -- ,[idCostoDocumentoClase]
    -- ,[idEstado]
    -- ,[comentario]
-- FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW]
-- =============================================
CREATE VIEW [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW]
AS

SELECT 
    DDOC.[idDocumentoClase]
    ,DDOC.[idClase]
    ,DDOC.[idTipoObjeto]
    ,DDOC.[idObjeto]
    ,DDOC.[version]
    ,DDOC.[idTipoDocumento]
    ,DDOC.[idFileServer]
    ,DDOC.[vigencia]
    ,DDOC.[valor]
    ,DDOC.[idUsuario]
    ,DDOC.[fecha]
    ,DDOC.[idCostoDocumentoClase]
    ,DDOC.[idEstado]
    ,DDOC.[comentario]
FROM [Objeto].[documento].[DocumentoObjetoClase] DDOC
INNER JOIN 
(SELECT 
    idDocumentoClase
    ,idClase
    ,idTipoObjeto
    ,idObjeto
    ,MAX(version) versionActual
FROM [Objeto].[documento].[DocumentoObjetoClase]
GROUP BY idDocumentoClase
    ,idClase
    ,idTipoObjeto
    ,idObjeto) DA
    ON DA.idDocumentoClase = DDOC.idDocumentoClase
    AND DA.idClase = DDOC.idClase
    AND DA.idTipoObjeto = DDOC.idTipoObjeto
    AND DA.idObjeto = DDOC.idObjeto
    AND DA.versionActual = DDOC.version
go

