-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <17/09/2019>
-- Description:	<Notifica cuando un documento vence>
-- =============================================
/*
	Fecha:		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [documento].[SEL_DOCUMENTO_NOTIFICAVIGENCIA_SP]
	
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [documento].[SEL_DOCUMENTO_NOTIFICAVIGENCIA_SP]

AS

BEGIN

	IF OBJECT_ID('tempdb..#General') IS NOT NULL
			BEGIN
				DROP TABLE #General
			END

	IF OBJECT_ID('tempdb..#Clase') IS NOT NULL
			BEGIN
				DROP TABLE #Clase
			END

	IF OBJECT_ID('tempdb..#Contrato') IS NOT NULL
			BEGIN
				DROP TABLE #Contrato
			END

/************************************** GENERAL *************************************/

	SELECT
	ROW_NUMBER() OVER(ORDER BY idDocumentoGeneral ASC) AS Row#,
	*
	INTO #General
	FROM(	select distinct
				G.idDocumentoGeneral, 
				G.idClase, 
				G.idTipoObjeto, 
				G.idObjeto, 
				(select top 1 vigencia from [documento].[DocumentoObjetoGeneral] where idTipoObjeto = G.idTIpoObjeto and idobjeto = G.idObjeto order by version desc) vigencia
			from [documento].[DocumentoObjetoGeneral] G
			INNER JOIN [objeto].[Objeto] O ON G.idObjeto = O.idObjeto 
			AND G.idTipoObjeto = O.idTipoObjeto
			AND O.activo = 1
			) T
	ORDER BY idDocumentoGeneral, idTipoObjeto, idObjeto

/************************************** CLASE *************************************/

	SELECT 
	ROW_NUMBER() OVER(ORDER BY idDocumentoClase ASC) AS Row#,
	* 
	INTO #Clase
	FROM (
			select  distinct
				C.idDocumentoClase, 
				C.idClase, 
				C.idTipoObjeto, 
				C.idObjeto, 
				(select top 1 vigencia from [documento].[DocumentoObjetoClase] where idTipoObjeto = c.idTIpoObjeto and idobjeto = c.idObjeto order by version desc) vigencia
			from [documento].[DocumentoObjetoClase] C
			INNER JOIN [objeto].[Objeto] O ON C.idObjeto = O.idObjeto 
			AND C.idTipoObjeto = O.idTipoObjeto
			AND O.activo = 1
			) T
	ORDER BY idDocumentoClase, idTipoObjeto, idObjeto


/************************************** CONTRATO *************************************/

	select  
		ROW_NUMBER() OVER(ORDER BY idDocumentoContrato ASC) AS Row#,
		CON.idDocumentoContrato, 
		CON.idClase, 
		CON.idTipoObjeto, 
		CON.idObjeto, 
		CON.vigencia, 
		CON.version
	INTO #Contrato
	from [documento].[DocumentoObjetoContrato]	 CON
	INNER JOIN [objeto].[Objeto] O ON CON.idObjeto = O.idObjeto 
	AND CON.idTipoObjeto = O.idTipoObjeto
	AND O.activo = 1
	ORDER BY idDocumentoContrato, idTipoObjeto, idObjeto


	--select * from #general
	--select * from #clase
	--select * from #contrato


	DECLARE @contadorGeneral	int = 1
	DECLARE @contadorClase		int = 1
	DECLARE @contadorContrato	int = 1

	DECLARE
		@idDocumentoGeneral		INT,
		@idDocumentoClase		INT,
		@idDocumentoContrato	INT,
		@idClase				VARCHAR(10),
		@idTipoObjeto			INT,
		@idObjeto				INT,
		@llave					VARCHAR(MAX) 


	/************************************************ DOCUMENTO GENERAL ***************************************/


		WHILE ( SELECT count(idDocumentoGeneral) FROM #General) > @contadorGeneral
		BEGIN  
			IF(SELECT ISNULL(vigencia,GETDATE()) FROM #General WHERE Row# = @contadorGeneral) < GETDATE()
				BEGIN

					SELECT
						@idDocumentoGeneral	= idDocumentoGeneral		
						,@idClase = idClase				
						,@idTipoObjeto = idTipoObjeto			
						,@idObjeto = idObjeto	
					FROM #General WHERE Row# = @contadorGeneral		
					
					SET @llave = '{"idDocumentoGeneral":"' + CAST(@idDocumentoGeneral AS VARCHAR(50)) + '","idClase":"' + @idClase 
					+ '","idTipoObjeto":"' + CAST(@idTipoObjeto AS VARCHAR(50)) + '","idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '"}'	

					EXEC [evento].[evento].[INS_EVENTO]
					@accion = 3
					,@modulo = 171
					,@gerencia = 1
					,@llave = @llave
					,@origen = NULL
					,@applicationId = 11
					,@idEstado = NULL
					,@idContratoZona = NULL
					,@idUsuario = NULL
					,@err = ''

					
				END

			SET @contadorGeneral = @contadorGeneral + 1
		END

	/************************************************ DOCUMENTO CLASE ***************************************/


		WHILE ( SELECT count(idDocumentoClase) FROM #Clase) > @contadorClase
		BEGIN  
			IF(SELECT ISNULL(vigencia,GETDATE()) FROM #Clase WHERE Row# = @contadorClase) < GETDATE()
				BEGIN
					

					SELECT
						@idDocumentoClase	= idDocumentoClase		
						,@idClase = idClase				
						,@idTipoObjeto = idTipoObjeto			
						,@idObjeto = idObjeto	
					FROM #Clase WHERE Row# = @contadorClase		
					
					SET @llave = '{"idDocumentoClase":"' + CAST(@idDocumentoClase AS VARCHAR(50)) + '","idClase":"' + @idClase 
					+ '","idTipoObjeto":"' + CAST(@idTipoObjeto AS VARCHAR(50)) + '","idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '"}'	

					EXEC [evento].[evento].[INS_EVENTO]
					@accion = 3
					,@modulo = 171
					,@gerencia = 1
					,@llave = @llave
					,@origen = NULL
					,@applicationId = 11
					,@idEstado = NULL
					,@idContratoZona = NULL
					,@idUsuario = NULL
					,@err = ''

					
				END

			SET @contadorClase = @contadorClase + 1
		END


	/************************************************ DOCUMENTO CONTRATO ***************************************/


		WHILE ( SELECT count(idDocumentoContrato) FROM #Contrato) > @contadorContrato
		BEGIN  
			IF(SELECT ISNULL(vigencia,GETDATE()) FROM #Contrato WHERE Row# = @contadorContrato) < GETDATE()
				BEGIN

					
					SELECT
						@idDocumentoContrato	= idDocumentoContrato		
						,@idClase = idClase				
						,@idTipoObjeto = idTipoObjeto			
						,@idObjeto = idObjeto	
					FROM #Contrato WHERE Row# = @contadorContrato		
					
					SET @llave = '{"idDocumentoContrato":"' + CAST(@idDocumentoContrato AS VARCHAR(50)) + '","idClase":"' + @idClase 
					+ '","idTipoObjeto":"' + CAST(@idTipoObjeto AS VARCHAR(50)) + '","idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '"}'	

					EXEC [evento].[evento].[INS_EVENTO]
					@accion = 3
					,@modulo = 171
					,@gerencia = 1
					,@llave = @llave
					,@origen = NULL
					,@applicationId = 11
					,@idEstado = NULL
					,@idContratoZona = NULL
					,@idUsuario = NULL
					,@err = ''

					
				END

			SET @contadorContrato = @contadorContrato + 1
		END

END

go

