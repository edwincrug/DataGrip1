-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<13/06/2020>
-- Description:	<Obtener la informacion del gps de las unidades>
-- =============================================
-- EXEC [objeto].[SEL_ESTATUS_GPS_UNIDADES_SP] 'Automovil', 'AAN910409135', 104, 'INTEGRA02',9054
-- =============================================
CREATE PROCEDURE [objeto].[SEL_ESTATUS_GPS_UNIDADES_SP]
(
    @idClase                varchar(10)
    ,@rfcEmpresa            varchar(13)
    ,@idCliente             int
    ,@numeroContrato        varchar(50)
	,@deviceid				int
	,@idUsuario				int=NULL
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN

	SELECT
		VOD.[deviceid]
		,SEEV.[type] dispositivoEstatus
		,SEDV.[desconectado]
		,COALESCE(SEAV.[countAlarms], 0) alarmas
		,COALESCE(NULLIF(AIO.[tipo],''), 'sedan') tipo
	FROM [AVL].[vehiculo].[ObjetoDispositivo] VOD
    LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_ESTATUS_VW] SEEV
		ON SEEV.[deviceid] = VOD.[deviceid]
    LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_DESCONECTADO_VW] SEDV
		ON SEDV.[deviceid] = VOD.[deviceid]
    LEFT JOIN [AVL].[vehiculo].[SEL_EVENTS_ALARMAS_VW] SEAV
		ON SEAV.[deviceid] = VOD.[deviceid]
    LEFT JOIN [AVL].[integridad].[objeto] AIO
		ON AIO.[rfcEmpresa] = VOD.[rfcEmpresa]
        AND AIO.[idCliente] = VOD.[idCliente]
        AND AIO.[numeroContrato] = VOD.[numeroContrato]
        AND AIO.[idClase] = VOD.[idClase]
        AND AIO.[idTipoObjeto] = VOD.[idTipoObjeto]
        AND AIO.[idObjeto] = VOD.[idObjeto]
	WHERE VOD.[numeroContrato] = @numeroContrato
        AND VOD.[idCliente] = @idCliente
        AND VOD.[rfcEmpresa] = @rfcEmpresa
        AND VOD.[idClase] = @idClase
		AND VOD.[deviceid] = @deviceid
		AND VOD.[activo] = 1

END
go

