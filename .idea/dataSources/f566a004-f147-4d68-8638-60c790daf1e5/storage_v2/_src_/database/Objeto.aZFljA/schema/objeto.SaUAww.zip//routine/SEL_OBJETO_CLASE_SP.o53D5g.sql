-- =============================================
-- Author: Adolfo Martinez
-- Create date: 05-07-2019
-- Description: Consulta devuelve solicitudes dependiendo el paso
-- ============== Versionamiento ================
-- EXEC [objeto].[SEL_OBJETO_CLASE_SP] 'ASE0508051B6','185','43','Automovil',1,''
-- =============================================
CREATE PROCEDURE [objeto].[SEL_OBJETO_CLASE_SP]
	@rfcEmpresa				VARCHAR(13),
	@idCliente				INT,
	@numeroContrato         VARCHAR(50),
	@idClase				VARCHAR(10),
	@idUsuario				INT,
	@err					VARCHAR(500)OUTPUT
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		-- SQL dinamico
		DECLARE @v_sq			NVARCHAR(MAX)

		--tablas usadas
		DECLARE	@TablaObjeto			VARCHAR(50)
		--columnas de cada tabla
		DECLARE	@camposPivotObjeto		VARCHAR(1000),
				@camposPivotVista		VARCHAR(2000),
				@camposPivotKey			VARCHAR(MAX),
				@camposComprobantes		VARCHAR(1000)=''
		--Manejo de errores
		DECLARE @ErrorMessage			NVARCHAR(4000),
				@ErrorSeverity			INT,
				@ErrorState				INT
		PRINT '1'
		/*PROPIEDADES DINAMICAS [OBJETO Y TIPO DE OBJETO]*/
		BEGIN
			DECLARE @tObjeto TABLE(idTipoObjeto INT, idObjeto INT)
			IF OBJECT_ID('tempdb..#tablaDatosObjeto')IS NOT NULL DROP TABLE #tablaDatosObjeto
			CREATE TABLE #tablaDatosObjeto([idTipoObjeto] [int] NULL, [idObjeto] [int] NULL, [agrupador] [varchar](250) NULL, [valor] [varchar](500) NULL)
		
			SET @TablaObjeto='TxObjeto_'+CAST(CAST(RAND(CHECKSUM(NEWID()))*10000000 AS INT) AS VARCHAR)

			/*Modificar el query que llena la tabla @tObjeto al integrar en sp para que tome los filtros de la consulta general*/
			INSERT	INTO @tObjeto (idTipoObjeto, idObjeto)
			SELECT DISTINCT CO.idTipoObjeto,CO.idObjeto FROM Objeto.[objeto].[Objeto] O
			JOIN cliente.contrato.Objeto CO ON CO.idClase=O.idClase AND CO.idTipoObjeto=O.idTipoObjeto AND CO.idObjeto=O.idObjeto AND CO.activo	= 1 AND CO.idObjetoEstatus='ACT'
			--[Cliente].[contrato].[ObjetoEstatus] EO.idObjetoEstatus = CO.idObjetoEstatus ACTIVO ESTATUS OBJETO
			WHERE CO.rfcEmpresa=@rfcEmpresa AND CO.idCliente=@idCliente AND CO.numeroContrato=@numeroContrato AND CO.idClase=@idClase AND O.activo=1


			SET		@camposPivotObjeto	= ISNULL(STUFF((SELECT ',' + QUOTENAME(campo) FROM Common.reporte.objeto WHERE idClase=@idClase ORDER BY orden ASC  FOR XML PATH('')),1,1,''),'sinCoinicidencia')
			SET		@camposPivotKey		= 'idTIpoObjeto as Key_idTipoObjeto,idObjeto as Key_idObjeto' 
			SET 	@camposPivotObjeto 	= REPLACE(@camposPivotObjeto,' ','_')

			INSERT INTO #tablaDatosObjeto(idTipoObjeto,idObjeto,agrupador,valor) 
			SELECT	s.idTipoObjeto,s.idObjeto,tc.campo,
					[objeto].[objeto].[getPropiedadObjeto](case when tc.tipoObjeto='idTipoObjeto' then s.idTipoObjeto else s.idObjeto end, tc.campo, tc.tipoPropiedad,@idClase) 
			FROM	@tObjeto s,(SELECT campo,tipoPropiedad,tipoObjeto,orden FROM Common.reporte.Objeto (NOLOCK) WHERE idClase=@idClase) tc ORDER	BY tc.orden ASC
	
			SET @v_sq='SELECT r.* INTO '+ @TablaObjeto +' FROM (select '+@camposPivotKey+',agrupador,valor from #tablaDatosObjeto) AS tx PIVOT (max(valor) for agrupador in ('+@camposPivotObjeto+')) as r '
			EXEC SP_EXECUTESQL @v_sq

			--SET @v_sq='	CREATE CLUSTERED INDEX [idx0001_'+@TablaObjeto+'] ON [dbo].['+@TablaObjeto+']([Key_idTipoObjeto],[Key_idObjeto])'
			--EXEC SP_EXECUTESQL @v_sq
         END
		 PRINT '2'
		SET @camposPivotVista	=  '(select valor from Common.configuracion.configuracion where nombre = ''fileServer'')+(select top 1 path from FileServer.documento.documento where idDocumento = (select [objeto].[getPropiedadObjeto]  (O.key_idTipoObjeto, ''Foto'', ''tipoGeneral'', ''Automovil''))) FotoPrincipal,O.key_idTipoObjeto idTipoObjeto,O.key_idObjeto idObjeto,''Activo'' estatus,'
		SET @camposPivotObjeto	=	REPLACE(REPLACE(@camposPivotObjeto,'[','O.'),']','')
		 SET @v_sq=''
		 SET @v_sq+=' SELECT '+@camposPivotVista+@camposPivotObjeto
		 SET @v_sq+=' FROM '+ @TablaObjeto +' O '
		PRINT '3'
		EXEC SP_EXECUTESQL @v_sq

		IF OBJECT_ID(@TablaObjeto, 'U') IS NOT NULL  
			BEGIN
				SET @v_sq='DROP TABLE '+@TablaObjeto 
				EXEC SP_EXECUTESQL @v_sq
			END
		PRINT '4'
	END TRY
	BEGIN CATCH
		IF OBJECT_ID(@TablaObjeto, 'U') IS NOT NULL  
			BEGIN
				SET @v_sq='DROP TABLE '+@TablaObjeto 
				EXEC SP_EXECUTESQL @v_sq
			END

		IF OBJECT_ID('tempdb..#tablaDatosObjeto')	IS NOT NULL DROP TABLE #tablaDatosObjeto

		SELECT	@ErrorMessage	= ERROR_MESSAGE(),
				@ErrorSeverity	= ERROR_SEVERITY(),
				@ErrorState		= ERROR_STATE();

		RAISERROR	(	@ErrorMessage, -- Message text.
						@ErrorSeverity, -- Severity.
						@ErrorState -- State.
					);
	END CATCH
	SET NOCOUNT OFF;

END


go

