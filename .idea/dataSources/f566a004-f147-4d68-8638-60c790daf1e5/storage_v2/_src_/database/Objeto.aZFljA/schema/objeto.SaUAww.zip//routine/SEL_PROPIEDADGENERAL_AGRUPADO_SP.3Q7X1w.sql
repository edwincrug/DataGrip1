-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <22-03-2019>
-- Description:	<Obtener los registros de las propiedades 
-- de los otres tipos , generales, clase y contrato
-- agregando loso tipos d e datos y valores>

	/*- Testing...
	DECLARE @err nvarchar(500) ='' ;
	EXEC [objeto].[SEL_PROPIEDADGENERAL_AGRUPADO_SP] 
	@idClase = 'Automovil',
	@idCliente = 221,
	@numeroContrato = '205',
	@idUsuario = 6115,
	@err = OUTPUT
	SELECT @err;
*/
-- =============================================
CREATE PROCEDURE [objeto].[SEL_PROPIEDADGENERAL_AGRUPADO_SP]
	@idClase			varchar(10),
	@idCliente			int = null,
    @numeroContrato		varchar(50) = null,
	@idUsuario			int = null,
	@err				NVARCHAR(500) = '' OUTPUT
AS
BEGIN

DECLARE @propiedades AS TABLE(
								id				INT,
								idPadre			INT,
								valor			NVARCHAR(500),
								arreglo			NVARCHAR(500),
								idClase			NVARCHAR(500),
								idTipoValor		NVARCHAR(20),
								idTipoDato		NVARCHAR(20),
								propiedad		NVARCHAR(50),
								idPropiedad		INT,
								obligatorio		BIT,
								orden			INT,
								posicion		INT
								)

	INSERT INTO @propiedades
	 SELECT 
		idPropiedadGeneral	as id
		,ISNULL(idPadre,0)	 as idPadre
		,valor	
		,'' as arreglo
		,'' idClase
		,idTipoValor
		,idTipoDato
		,'general' propiedad
		,1 idPropiedad
		,obligatorio
		,orden
		,posicion
	FROM
	[objeto].[PropiedadGeneral]
	WHERE  activo = 1

	UNION ALL

	SELECT 
		idPropiedadClase	as id
		,ISNULL(idPadre,0)	 as idPadre
		,valor	
		,'' as arreglo
		,idClase
		,idTipoValor
		,idTipoDato
		,'clase' propiedad
		,2 idPropiedad
		,obligatorio
		,orden
		,posicion
	FROM [objeto].[PropiedadClase]
	WHERE idClase = @idClase  AND activo = 1

		UNION ALL

	SELECT 
		idPropiedadContrato	as id
		,ISNULL(idPadre,0)	 as idPadre
		,valor	
		,'' as arreglo
		,'' idClase
		,idTipoValor
		,idTipoDato
		,'contrato' propiedad
		,3 idPropiedad
		,obligatorio
		,orden
		,posicion
	FROM [objeto].[PropiedadContrato]
	WHERE idCliente= @idCliente 
	AND numeroContrato= @numeroContrato AND activo = 1

	SELECT * FROM @propiedades
	ORDER BY idPropiedad asc,posicion asc, orden  

		
END
go

