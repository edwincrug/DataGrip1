-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <15-03-2019>
-- Description:	<Obtener todas las propiedades  de el objeto por medio de su id>

/*

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [objeto].[SEL_OBJETOPROPIEDADGENERAL_AGRUPADO_SP]
		@idObjeto = 7,
		@err = @salida OUTPUT;
	SELECT @salida

*/
-- =============================================
CREATE PROCEDURE [objeto].[SEL_OBJETOPROPIEDADGENERAL_AGRUPADO_SP]
	@idObjeto				int,
	@idUsuario				int = null,
	@err					varchar(max) OUTPUT
AS

BEGIN	
	 SET @err = '';
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
((SELECT 1 as tablaP
	  ,[idObjeto]
      ,[idPropiedadContrato]
      ,[valor]
      --,[vigencia]
  FROM [objeto].[ObjetoPropiedadContrato]
  WHERE [objeto].[ObjetoPropiedadContrato].[idObjeto] = @idObjeto )
  UNION
(SELECT 2 as tablaP
	  ,[idObjeto]
      ,[idPropiedadClase]
      ,[valor]
      --,[vigencia]
  FROM [objeto].[ObjetoPropiedadClase]
  WHERE [objeto].[ObjetoPropiedadClase].[idObjeto] = @idObjeto))
  UNION
  (SELECT 3 as tablaP
	  ,[idObjeto]
      ,[idPropiedadGeneral]
      ,[valor]
      --,[vigencia]

  FROM [objeto].[ObjetoPropiedadGeneral]
  WHERE [objeto].[ObjetoPropiedadGeneral].[idObjeto] = @idObjeto
  )

END
go

