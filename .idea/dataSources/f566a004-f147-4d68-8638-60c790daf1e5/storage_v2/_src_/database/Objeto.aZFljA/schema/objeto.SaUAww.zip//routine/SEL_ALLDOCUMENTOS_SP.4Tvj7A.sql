-- =============================================
-- Author:		José Etmanuel Hernández Rejón 
-- Create date: 23/04/2019
-- Description:	Obtiene el listado de documentos por objeto
-- =============================================
/*
	Fecha:04/06/2019		Autor Sandra Gil Rosales
	Descripción : se agregaron campos de costo y estado 
	Fecha:01/07/2019		Autor Sandra Gil Rosales
	Descripción : se agregaron campos de  la tabla [Solicitud].[gestoria].[Concepto]
	--2019

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [objeto].[SEL_ALLDOCUMENTOS_SP]
		@idObjeto = 7,
		@UserId = 2,
		@idClase='Automovil',
		@idCliente=78,
		@numeroContrato='123PEMEX', 
		@err = @salida OUTPUT;
	SELECT @salida

*/
-- =============================================

CREATE PROCEDURE [objeto].[SEL_ALLDOCUMENTOS_SP]
	@idObjeto	int,
	@UserId		int,
	@idClase	varchar(10) = null,
	@idCliente  int = null,
	@numeroContrato nvarchar(50) = null,
	@err		varchar(max) OUTPUT
AS
BEGIN
	-- Dataset 0; Parametros
	SELECT
	   isnull(obj.version,0) version
	  ,1 as ordenTipo
	  ,[orden]
	  ,'general' as tipo
	  ,[idAgrupador]
	  ,doc.[idDocumentoGeneral] AS id
	  ,null AS idClase
	  ,null as idCliente
	  ,null as numeroContrato
	  ,[tiposPermitidos]
      ,doc.[nombre]
	  ,sgc.idConcepto
	  ,sgc.renovable
	  ,sgc.idPeriodicidad
	  ,sgc.reembolsable
	  ,sgc.idFile
	  ,sgc.[%Costo]
      ,[obligatorio]
      ,doc.[vigencia]
      ,doc.[valor]
      ,[aplicaCosto]
	  ,[aplicaEstado]
	  ,[aplicaComentario]
      ,doc.[idUsuario]
      ,doc.[activo]
	  ,obj.idTipoDocumento AS datoTipo
	  ,obj.idFileServer AS datoIdFileServer
	  ,obj.vigencia AS datoVigencia
	  ,obj.valor AS datoValor
	  ,costog.costo AS datoCosto
	  ,costog.pagado AS costoPagado
	  ,costog.idLineaCaptura AS datoLineaCaptura
	  ,costog.idFacturaPDF AS datoFacturaPDF
	  ,costog.idFacturaXML AS datoFacturaXML
	  ,estado.idEstado AS datoEstado
	  ,obj.comentario AS datoComentario
	  ,CONVERT(varchar(16), obj.fecha,20) AS fechaModificacion
	  ,usr.[UserName] AS usuario
	  ,usr.[PrimerNombre] AS uPrimerNombre
      ,usr.[SegundoNombre] AS uSegundoNombre
      ,usr.[PrimerApellido] AS uPrimerApellido
      ,usr.[SegundoApellido] AS uSegundoApellido
	  ,usr.Avatar AS uAvatar
	 FROM [documento].[DocumentoGeneral] AS doc
	  LEFT JOIN [documento].[DocumentoObjetoGeneral] obj
		ON doc.idDocumentoGeneral = obj.idDocumentoGeneral AND (isnull(idObjeto,0) = 0 or  idObjeto = @idObjeto) 
		LEFT JOIN [documento].[CostoDocumentoGeneral] costog
		ON obj.idCostoDocumentoGeneral = costog.idCostoDocumentoGeneral
		LEFT JOIN [Common].[direccion].[Estado]  estado
		ON  obj.idEstado = estado.idEstado
	  LEFT JOIN Seguridad.Catalogo.Users AS usr
	    ON obj.[idUsuario] = usr.Id
		-- funcionalidad concepto
		LEFT JOIN [Solicitud].[gestoria].[Concepto] AS sgc ON sgc.nombre = doc.[nombre]
	-- WHERE 
	UNION
	SELECT 
	   isnull(obj.version,0) version
	  ,2 as ordenTipo
	  ,[orden]
	  ,'clase' as tipo
	  ,[idAgrupador]
	  ,doc.[idDocumentoClase] AS id
	  ,doc.[idClase]
	  ,null as idCliente
	  ,null as numeroContrato
	  ,[tiposPermitidos]
      ,doc.[nombre]
	  ,sgc.idConcepto
	  ,sgc.renovable
	  ,sgc.idPeriodicidad
	  ,sgc.reembolsable
	  ,sgc.idFile
	  ,sgc.[%Costo]
      ,[obligatorio]
      ,doc.[vigencia]
      ,doc.[valor]
      ,[aplicaCosto]
	  ,[aplicaEstado]
	  ,[aplicaComentario]
      ,doc.[idUsuario]
      ,doc.[activo]
	  ,obj.idTipoDocumento AS datoTipo
	  ,obj.idFileServer AS datoIdFileServer
	  ,obj.vigencia AS datoVigencia
	  ,obj.valor AS datoValor
	  ,costoc.costo AS datoCosto
	  ,costoc.pagado AS costoPagado
	  ,costoc.idLineaCaptura AS datoLineaCaptura
	  ,costoc.idFacturaPDF AS datoFacturaPDF
	  ,costoc.idFacturaXML AS datoFacturaXML
	  ,estado.idEstado AS datoEstado
	  ,obj.comentario AS datoComentario
	  ,CONVERT(varchar(16), obj.fecha,20) AS fechaModificacion
	  ,usr.[UserName] AS usuario
	  ,usr.[PrimerNombre] AS UPrimerNombre
      ,usr.[SegundoNombre] AS USegundoNombre
      ,usr.[PrimerApellido] AS UPrimerApellido
      ,usr.[SegundoApellido] AS USegundoApellido
	  ,usr.Avatar AS uAvatar
  	  FROM [documento].[DocumentoClase] doc
	  LEFT JOIN [documento].[DocumentoObjetoClase] obj
		ON doc.idDocumentoClase = obj.idDocumentoClase  AND (isnull(idObjeto,0) = 0 or  idObjeto = @idObjeto) 
		LEFT JOIN [documento].[CostoDocumentoClase] costoc
		ON obj.idCostoDocumentoClase = costoc.idCostoDocumentoClase
		LEFT JOIN [Common].[direccion].[Estado]  estado
		ON  obj.idEstado = estado.idEstado
	  LEFT JOIN Seguridad.Catalogo.Users AS usr
	    ON obj.[idUsuario] = usr.Id
	-- funcionalidad concepto
		LEFT JOIN [Solicitud].[gestoria].[Concepto] AS sgc ON sgc.nombre = doc.[nombre] AND doc.idClase = sgc.idClase
	  WHERE (isnull(@idClase,'') = '' or doc.idClase = @idClase) 
  UNION
	SELECT 
	   isnull(obj.version,0) version
	  ,3 as ordenTipo
	  ,[orden]
	  ,'contrato' as tipo
	  ,[idAgrupador]
	  ,doc.[idDocumentoContrato] AS id
	  ,null AS idClase
	  ,[idCliente]
	  ,[numeroContrato]
	  ,[tiposPermitidos]
      ,doc.[nombre]
	  ,sgc.idConcepto
	  ,sgc.renovable
	  ,sgc.idPeriodicidad
	  ,sgc.reembolsable
	  ,sgc.idFile
	  ,sgc.[%Costo]
      ,[obligatorio]
      ,doc.[vigencia]
      ,doc.[valor]
      ,[aplicaCosto]
	  ,[aplicaEstado]
	  ,[aplicaComentario]
      ,doc.[idUsuario]
      ,doc.[activo]
	  ,obj.idTipoDocumento AS datoTipo
	  ,obj.idFileServer AS datoIdFileServer
	  ,obj.vigencia AS datoVigencia
	  ,obj.valor AS datoValor
	  ,costoCon.costo AS datoCosto
	  ,costoCon.pagado AS costoPagado
	  ,costoCon.idLineaCaptura AS datoLineaCaptura
	  ,costoCon.idFacturaPDF AS datoFacturaPDF
	  ,costoCon.idFacturaXML AS datoFacturaXML
	  ,estado.idEstado AS datoEstado
	  ,obj.comentario AS datoComentario
	  ,CONVERT(varchar(16), obj.fecha,20) AS fechaModificacion
	  ,usr.[UserName] AS usuario
	  ,usr.[PrimerNombre] AS UPrimerNombre
      ,usr.[SegundoNombre] AS USegundoNombre
      ,usr.[PrimerApellido] AS UPrimerApellido
      ,usr.[SegundoApellido] AS USegundoApellido
	  ,usr.Avatar AS uAvatar
	 FROM[documento].[DocumentoContrato] doc
	  LEFT JOIN [documento].[DocumentoObjetoContrato] obj
		ON doc.idDocumentoContrato = obj.idDocumentoContrato  AND (isnull(idObjeto,0) = 0 or  idObjeto = @idObjeto)
		LEFT JOIN [documento].[CostoDocumentoContrato] costoCon
		ON obj.idCostoDocumentoContrato = costoCon.idCostoDocumentoContrato
		LEFT JOIN [Common].[direccion].[Estado]  estado
		ON  obj.idEstado = estado.idEstado
	  LEFT JOIN Seguridad.Catalogo.Users AS usr
	    ON obj.[idUsuario] = usr.Id
	-- funcionalidad concepto
	LEFT JOIN [Solicitud].[gestoria].[Concepto] AS sgc ON sgc.nombre = doc.[nombre]
	 WHERE (isnull(@idCliente,0) =  0 or idCliente = @idCliente) AND (isnull(@numeroContrato,'') = ''or  numeroContrato = @numeroContrato)  and doc.activo = 1
	 ORDER BY ordenTipo,orden, isnull(obj.version,0) DESC

	 SELECT [IdAgrupador] AS idAgrupador
      ,[Nombre] AS nombre
      ,[icono] AS icono
	FROM [Objeto].[documento].[Agrupador]

END
go

