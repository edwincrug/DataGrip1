-- ==================================	===========
-- Author:		<Sandra Gil Rosales>
-- Create date: <24-06-2019>
-- Description:	<Obtener los registros de los objetos junto con el tipo de objeto>
	/*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [operador].[DEL_OPERADOR_SP] 
	@idUsuario = 3 ,
	@data = '<Ids>
		<idUsers>2</idUsers></Ids>',
	@err = @salida OUTPUT;
	SELECT @salida
*/
-- =============================================
CREATE PROCEDURE [operador].[DEL_OPERADOR_SP] 
@data					XML,
@idUsuario				int,
@err					varchar(max) OUTPUT
AS
BEGIN TRY
	BEGIN TRANSACTION
		SET NOCOUNT OFF;
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		SET @err = '';
		DECLARE @Ids TABLE (
		_row		INT IDENTITY(1,1),
		idUsers			INT
		);

    INSERT INTO @Ids (idUsers)
    SELECT
		ParamValues.col.value('idUsers[1]','int')
        FROM @data.nodes('Ids') AS ParamValues(col);

    DECLARE @cont		INT = 1;

	WHILE((SELECT COUNT(*) FROM @Ids)>= @cont)
--inicio de while
	BEGIN
			DECLARE @idUsers				INT;

			SELECT @idUsers= idUsers
			FROM @Ids
			WHERE _row = @cont
		
			BEGIN	
				UPDATE [operador].[Operador]
					SET [idUsuario] = @idUsuario
						,[activo] = 0
					WHERE [idUsers] = @idUsers;
				Select 'Eliminado' as ok;
			END
	SET @cont = @cont + 1
	END
--termino de while
	Select 'Eliminado' as ok;
		SET NOCOUNT OFF;
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
			COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
go

