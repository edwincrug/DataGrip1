-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<06/07/2019>
-- Description:	    <Obtener las solicitudes en proceso e historico>
-- =============================================
-- EXEC [objeto].[SEL_SOLICITUDES_HISTORIAL_PROCESO_SP] 'Automovil', 'ASE0508051B6', 92, '0001', 241
-- =============================================
CREATE PROCEDURE [objeto].[SEL_SOLICITUDES_HISTORIAL_PROCESO_SP]
(
    @idClase                varchar(10)
    ,@rfcEmpresa            varchar(13)
    ,@idCliente             int
    ,@numeroContrato        varchar(50)
    ,@idObjeto              int
    ,@idUsuario			    int=NULL
    ,@err				    varchar(500) = '' OUTPUT
)
AS
BEGIN

    -- EN PROCESO
    SELECT
        SSZV.[idSolicitud]
        ,SSZV.[idTipoSolicitud]
        ,SSZV.[idClase]
        ,SSZV.[rfcEmpresa]
        ,SSZV.[idCliente]
        ,SSZV.[numeroContrato]
        ,SSZV.[idContratoZona]
        ,SSZV.[idContratoNivel]
        ,SSZV.[zona]
        ,SSZV.[numeroOrden]
        ,SSZV.[idObjeto]
        ,SSZV.[idTipoObjeto]
        ,STS.[nombre] tipoSolicitud
        ,FSEP.idPaso
        ,FSEP.idFase
    FROM [Solicitud].[solicitud].[SEL_SOLICITUD_ZONA_VW] SSZV
    INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON SSZV.[idTipoSolicitud] = STS.[idTipoSolicitud]
            AND SSZV.[idClase] = STS.[idClase]
    INNER JOIN [Solicitud].[fase].[SolicitudEstatusPaso] FSEP
        ON FSEP.[idSolicitud] = SSZV.[idSolicitud]
            AND FSEP.[idClase]  = SSZV.[idClase]
            AND FSEP.[rfcEmpresa] = SSZV.[rfcEmpresa]
            AND FSEP.[idCliente] = SSZV.[idCliente]
            AND FSEP.[numeroContrato] = SSZV.[numeroContrato]
            AND FSEP.[idTipoSolicitud] = SSZV.[idTipoSolicitud]
    WHERE SSZV.[idClase] = @idClase
        AND SSZV.[rfcEmpresa] = @rfcEmpresa
        AND SSZV.[idCliente] = @idCliente
        AND SSZV.[numeroContrato] = @numeroContrato
		AND SSZV.[idEstatusSolicitud] = 'ACTIVA'
        AND FSEP.[fechaSalida] IS NULL
        AND FSEP.[idEstatus] = 1
        AND FSEP.idFase IN ('Solicitud', 'Aprobacion', 'Proceso')
        AND SSZV.idObjeto = @idObjeto
    ORDER BY SSZV.[idSolicitud] DESC

    -- HISTORIAL
    SELECT
        SSZV.[idSolicitud]
        ,SSZV.[idTipoSolicitud]
        ,SSZV.[idClase]
        ,SSZV.[rfcEmpresa]
        ,SSZV.[idCliente]
        ,SSZV.[numeroContrato]
        ,SSZV.[idContratoZona]
        ,SSZV.[idContratoNivel]
        ,SSZV.[zona]
        ,SSZV.[numeroOrden]
        ,SSZV.[idObjeto]
        ,SSZV.[idTipoObjeto]
        ,STS.[nombre] tipoSolicitud
        ,FSEP.idPaso
        ,FSEP.idFase
    FROM [Solicitud].[solicitud].[SEL_SOLICITUD_ZONA_VW] SSZV
    INNER JOIN [Solicitud].[solicitud].[TipoSolicitud] STS
        ON SSZV.[idTipoSolicitud] = STS.[idTipoSolicitud]
            AND SSZV.[idClase] = STS.[idClase]
    INNER JOIN [Solicitud].[fase].[SolicitudEstatusPaso] FSEP
        ON FSEP.[idSolicitud] = SSZV.[idSolicitud]
            AND FSEP.[idClase]  = SSZV.[idClase]
            AND FSEP.[rfcEmpresa] = SSZV.[rfcEmpresa]
            AND FSEP.[idCliente] = SSZV.[idCliente]
            AND FSEP.[numeroContrato] = SSZV.[numeroContrato]
            AND FSEP.[idTipoSolicitud] = SSZV.[idTipoSolicitud]
    WHERE SSZV.[idClase] = @idClase
        AND SSZV.[rfcEmpresa] = @rfcEmpresa
        AND SSZV.[idCliente] = @idCliente
        AND SSZV.[numeroContrato] = @numeroContrato
		AND SSZV.[idEstatusSolicitud] = 'ACTIVA'
        AND FSEP.[fechaSalida] IS NULL
        AND FSEP.[idEstatus] = 1
        AND FSEP.idFase IN ('Entrega', 'Cobranza')
        AND SSZV.idObjeto = @idObjeto
    ORDER BY SSZV.[idSolicitud] DESC

END
go

