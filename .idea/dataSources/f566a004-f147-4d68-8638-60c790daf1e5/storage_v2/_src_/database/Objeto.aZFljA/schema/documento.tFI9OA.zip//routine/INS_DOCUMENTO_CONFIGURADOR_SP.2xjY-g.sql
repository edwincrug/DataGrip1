-- =============================================
-- Author:		Sandra Gil Rosales
-- Create date: 23/09/2019
-- Description:Insertar un tipo de documento, clase, contrato o general
-- =============================================
/*
	Objetivo: Inserta un tipo de documento

	------TEST
		*- Testing...
	EXEC
	[documento].[INS_DOCUMENTO_CONFIGURADOR_SP]

@idClase= 'Automovil',
@idCliente= 92,
@numeroContrato= '0001',
@rfcEmpresa= 'ASE0508051B6',
@idPadre= 0,
@idTipoDato= 'Numeric',
@idTipoValor= 'Unico',
@obligatorio= true,
@orden= 3,
@activo= 1,
@posicion= 2,
@propiedad= 'contrato',
@valor= 'propiedadContrato'

	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición

*/
CREATE PROCEDURE [documento].[INS_DOCUMENTO_CONFIGURADOR_SP]
	@idClase			varchar(13) = NULL ,
    @idCliente			INT = 0,
	@numeroContrato		nvarchar(10) = NULL,
	@rfcEmpresa			varchar(13) = NULL ,
	@idAgrupador		varchar(50),
	@tiposPermitidos	varchar(100),
	@obligatorio		bit,
	@vigencia			bit,
	@valor				bit,
	@aplicaCosto		bit,
	@orden				int,
	@aplicaEstado		bit,
	@aplicaComentario	bit,
	@propiedad			nvarchar(10),
	@nombre				nvarchar(250),
	@idUsuario			INT,
	@err				varchar(max) OUTPUT
		
AS
BEGIN
	
	DECLARE @msj				varchar(50) = '', 
			@VC_ErrorMessage	VARCHAR(4000)	= '',
			@VC_ThrowMessage	VARCHAR(100)	= 'An error has occured on [INS_DOCUMENTO_CONFIGURADOR_SP]:',
			@VC_ErrorSeverity	INT = 0,
			@VC_ErrorState		INT = 0,
			@status				int = 0,
			@documentoId		int = 0,
			@activo				int = 1

/********************************************* INSERTA EN TABLA DE PROPIEDADES *********************/

	IF EXISTS(SELECT * FROM ( SELECT [idDocumentoClase] ,[nombre] ,'clase' AS prop, activo
									  FROM [Objeto].[documento].[DocumentoClase]
								  UNION ALL
									SELECT [idDocumentoGeneral] ,[nombre] ,'general', activo
									FROM [Objeto].[documento].[DocumentoGeneral]
								  UNION ALL
									  SELECT [idDocumentoContrato] ,[nombre] ,'contrato' , activo
									  FROM [Objeto].[documento].[DocumentoContrato] ) propiedades
					WHERE LOWER(nombre) = LOWER(@nombre) AND prop = @propiedad AND activo = 1)
		BEGIN
			SET @msj = 'El nombre de el tipo de documento ya existe';
			SET @documentoId = (SELECT [idDocumentoClase]  FROM ( SELECT [idDocumentoClase] ,[nombre] ,'clase' AS prop, activo
									  FROM [Objeto].[documento].[DocumentoClase]
								  UNION ALL
									SELECT [idDocumentoGeneral] ,[nombre] ,'general', activo
									FROM [Objeto].[documento].[DocumentoGeneral]
								  UNION ALL
									  SELECT [idDocumentoContrato] ,[nombre] ,'contrato' , activo
									  FROM [Objeto].[documento].[DocumentoContrato] ) propiedades
					WHERE LOWER(nombre) = LOWER(@nombre) AND prop = @propiedad AND activo = 1)
		END
	ELSE
		BEGIN TRY
			BEGIN TRANSACTION INS_DOCUMENTO_CONFIGURADOR_SP
			-- documento general
			IF @propiedad = 'general'
				BEGIN
				INSERT INTO [documento].[DocumentoGeneral]
				VALUES
				   (@nombre
				   ,@idAgrupador
				   ,@tiposPermitidos
				   ,@obligatorio
				   ,@vigencia
				   ,@valor
				   ,@aplicaCosto
				   ,@orden
				   ,@idUsuario
				   ,@activo
				   ,@aplicaEstado
				   ,@aplicaComentario)

				set @status = 1;
				SET @documentoId = SCOPE_IDENTITY();
				SET @msj = 'El tipo documento se agrego correctamente';
				END 
			-- documento clase
			IF @propiedad = 'clase'
				BEGIN
				INSERT INTO [documento].[DocumentoClase]
				VALUES
				   (@idClase
				   ,@nombre
				   ,@idAgrupador
				   ,@tiposPermitidos
				   ,@obligatorio
				   ,@vigencia
				   ,@valor
				   ,@aplicaCosto
				   ,@orden
				   ,@idUsuario
				   ,@activo
				   ,@aplicaEstado
				   ,@aplicaComentario)
				set @status = 1;
				SET @documentoId = SCOPE_IDENTITY();
				SET @msj = 'El tipo documento se agrego correctamente';
				END 
			-- documento contrato
			IF @propiedad = 'contrato'
				BEGIN
				INSERT INTO [documento].[DocumentoContrato]
				VALUES
					(@idCliente
					,@numeroContrato
					,@nombre
					,@idAgrupador
					,@tiposPermitidos
					,@obligatorio
					,@vigencia
					,@valor
					,@aplicaCosto
					,@orden
					,@idUsuario
					,@activo
					,@aplicaEstado
					,@aplicaComentario)

				set @status = 1;
				SET @documentoId = SCOPE_IDENTITY();
				SET @msj = 'El tipo documento se agrego correctamente';
				END 



			COMMIT TRANSACTION INS_DOCUMENTO_CONFIGURADOR_SP
		END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION INS_DOCUMENTO_CONFIGURADOR_SP
				SET @msj = 'Error al registar el tipo documento';
				SET @VC_ErrorMessage = {
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage)
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
			END
		END CATCH
	SELECT 
		@msj				AS [Message], 
		@status				AS [Insertado],
		@documentoId		AS [DocumentoId];

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

