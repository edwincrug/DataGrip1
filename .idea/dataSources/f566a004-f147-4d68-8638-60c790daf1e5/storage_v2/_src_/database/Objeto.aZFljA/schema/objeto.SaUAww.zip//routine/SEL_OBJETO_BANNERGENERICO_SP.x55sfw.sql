-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <06-08-2019>
-- Description:	<Propiedades para Banner Generico>
-- =============================================

/*

	------ Versionamiento
	Fecha 		Autor	Descrición

	testing

		[objeto].[SEL_OBJETO_BANNERGENERICO_SP] 'Papeleria', '01P',189,'AAN910409135',13429, 105, 6077,null
*/

CREATE PROCEDURE [objeto].[SEL_OBJETO_BANNERGENERICO_SP]
      @idClase				varchar(20),
	  @numeroContrato		varchar(50) = '',
	  @idCliente			int = 0,
	  @rfcEmpresa			varchar(13) = '',
	  @idObjeto				int = 0,
	  @idTipoObjeto			int,
	  @idUsuario			int = null,
	  @err					varchar(max) OUTPUT
AS
BEGIN

	SELECT 
	campo,
	Objeto.objeto.getPropiedadObjeto(@idTipoObjeto, BG.campo, BG.tipoPropiedad, BG.idClase ) as valor
	FROM [common].[tipoObjeto].[BannerGenerico] BG

	SELECT 
	campo,
	Objeto.objeto.getPropiedadObjeto(@idObjeto, BG.campo, BG.tipoPropiedad, BG.idClase ) as valor
	FROM [common].[objeto].[BannerGenerico] BG

	select 22275 idFileServer
	/*
	SELECT TOP 1  idFileServer 
				from documento.documentoobjetogeneral 
				WHERE idObjeto = @idObjeto AND idClase = @idClase AND idTipoObjeto = @idTipoObjeto
				ORDER BY fecha desc
				*/
END

go

