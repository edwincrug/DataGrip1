
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <28-06-2019>
-- Description:	<Insertar un operador>
-- =============================================
/*
	*** Versionamiento
	Fecha 		Autor	Descripción 
	21-may-2019	
	*- Testing...

	EXEC [operador].[UPD_ASIGNACION_OPERADOR_SP]
		1
		,null
		,null
		,null
		,2
		,null
*/
-- =============================================
CREATE PROCEDURE [operador].[UPD_ASIGNACION_OPERADOR_SP]
	@idAsignacion			int
	,@fechaEntrega			datetime
	,@odometroEntrega		nchar(10)
	,@idFileEntrega			int
	,@idUsuario				int
	,@verGps				bit
	,@err					varchar(max) OUTPUT

AS
	BEGIN TRY
	BEGIN TRANSACTION

	SET @err = '';	
		
	-- Hacemos un Update de las fechas de entrega por Operador

UPDATE [operador].[Asignacion]
   SET 
      [fechaEntrega] = @fechaEntrega
      ,[odometroEntrega] = @odometroEntrega
      ,[idFileEntrega] = @idFileEntrega
      ,[idUsuario] = @idUsuario
	  ,[verGps] = @verGps
 WHERE idAsignacion = @idAsignacion

 IF (@@ERROR = 0)

		BEGIN

		DECLARE @llave VARCHAR(MAX) = '{"idAsignacion":"' + CAST(@idAsignacion AS VARCHAR(50)) + '"}'

			EXEC [evento].[evento].[INS_EVENTO]
			@accion = 2
			,@modulo = 237
			,@gerencia = 1
			,@llave = @llave
			,@origen = NULL
			,@applicationId = 11
			,@idEstado = NULL
			,@idContratoZona = NULL
			,@idUsuario = @idUsuario
			,@err = ''
		END

	COMMIT
END TRY

BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH

go

