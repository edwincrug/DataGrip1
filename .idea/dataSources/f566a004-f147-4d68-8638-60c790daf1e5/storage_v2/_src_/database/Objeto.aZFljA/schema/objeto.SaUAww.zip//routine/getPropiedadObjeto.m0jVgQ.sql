--
-- =============================================    
-- Author:  José Etmanuel    
-- Create date: 11/04/2019    
-- Description: Resolver el valor de una propiedad dinamica de un objeto     
-- =============================================    
/*    
 ------ Versionamiento    
 Fecha			Autor      Descrición    
 22/05/2019		Alan Rosales Chávez   Cuando se busca en la documentacion del objeto, cuando no tienen valor, se devuelvo el id del documento   
 25/07/2017		José Etmanuel Agregando le cast a la corrección anterior

     
 *- Testing...    
    select [objeto].[getPropiedadObjeto]  (250, 'Foto Frente', 'documentoClaseFile','Automovil')
*/    
CREATE FUNCTION [objeto].[getPropiedadObjeto]    
 (    
  @idObjeto int
  ,@propiedad varchar(max)
  ,@tipoPropiedad varchar(20)
  ,@idClase varchar(20)
)    
RETURNS varchar(500)    
AS    
BEGIN    
 DECLARE @result varchar(500)
  DECLARE @ApValor BIT, @idDocumento INT
--- Buscando en las propiedades de los objetos  
 IF @tipoPropiedad  = 'general'    
  BEGIN    
   SET @result = (    
    SELECT    
  CASE WHEN idTipoValor = 'Unico' THEN    
   Opc.valor    
  ELSE    
   PC.valor    
  END as valor    
    FROM [Objeto].[objeto].[ObjetoPropiedadGeneral] Opc    
    inner join  [Objeto].[objeto].[PropiedadGeneral] PC on PC.idPropiedadGeneral = opc.idPropiedadGeneral    
    where idObjeto = @idObjeto AND agrupador = @propiedad  AND idClase = @idClase  
    );    
  END    
  IF @tipoPropiedad  = 'clase'    
  BEGIN    
   SET @result = (    
    SELECT    
  CASE WHEN idTipoValor = 'Unico' THEN    
   Opc.valor    
  ELSE    
   CASE WHEN  PC.valor = @propiedad THEN  
    ''  
   ELSE  
    PC.valor    
   END  
  END as valor    
    FROM [Objeto].[objeto].[ObjetoPropiedadClase] Opc    
    inner join  [Objeto].[objeto].[PropiedadClase] PC on PC.idPropiedadClase = opc.idPropiedadClase    
    where idObjeto = @idObjeto AND agrupador = @propiedad AND Opc.idClase = @idClase  
    );    
  END    
  IF @tipoPropiedad  = 'contrato'    
  BEGIN    
   SET @result = (    
    SELECT    
  CASE WHEN idTipoValor = 'Unico' THEN    
   Opc.valor    
  ELSE    
   PC.valor    
  END as valor    
    FROM [Objeto].[objeto].[ObjetoPropiedadContrato] Opc    
    inner join  [Objeto].[objeto].[PropiedadContrato] PC on PC.idPropiedadContrato = opc.idPropiedadContrato    
    where idObjeto = @idObjeto AND agrupador = @propiedad  AND idClase = @idClase  
    );    
  END    
    
 --- ====== Tipos de objetos    
 IF @tipoPropiedad  = 'tipoGeneral'    
  BEGIN    
   SET @result = (    
  SELECT CASE WHEN idTipoValor = 'Unico' THEN    
    P.valor    
   ELSE    
    TIP.valor    
   END as valor    
   FROM [Partida].[tipoobjeto].[TipoObjetoPropiedadGeneral] AS P    
   INNER JOIN [Partida].[tipoobjeto].[PropiedadGeneral]AS TIP ON TIP.idPropiedadGeneral = p.idPropiedadGeneral     
   WHERE agrupador = @propiedad AND idTipoObjeto =  @idObjeto AND idClase = @idClase  
    );    
  END    
  IF @tipoPropiedad  = 'tipoClase'    
  BEGIN    
   IF @propiedad  = 'Marca'    
   BEGIN    
    SET @result = (    
    SELECT valor    
     FROM  [Partida].[tipoobjeto].[PropiedadClase] where    
     idPropiedadClase =  (    
     SELECT top 1 idPadre    
    FROM [Partida].[tipoobjeto].[PropiedadClase] AS P    
    INNER JOIN [Partida].[tipoobjeto].[TipoObjetoPropiedadClase] AS TIP ON TIP.idPropiedadClase = p.idPropiedadClase     
    WHERE agrupador = 'Submarca' AND idTipoObjeto = @idObjeto)  AND idClase = @idClase  
  );    
   END    
   ELSE    
   BEGIN    
    SET @result = (    
   SELECT CASE WHEN idTipoValor = 'Unico' THEN    
    P.valor    
   ELSE    
    TIP.valor    
   END as valor    
   FROM [Partida].[tipoobjeto].[TipoObjetoPropiedadClase] AS P    
   INNER JOIN [Partida].[tipoobjeto].[PropiedadClase]AS TIP ON TIP.idPropiedadClase = p.idPropiedadClase     
   WHERE agrupador = @propiedad AND idTipoObjeto =  @idObjeto  AND P.idClase = @idClase AND TIP.idClase = @idClase  
  );    
   END    
  END    
    
 --- ====== Documentos    
    
  IF @tipoPropiedad  = 'documentoGeneral'    
  BEGIN
	SELECT top 1 @idDocumento=[idDocumentoGeneral], @ApValor = valor FROM [documento].[DocumentoGeneral] where nombre = @propiedad 

	SET @result = (    
		SELECT top 1 case when @ApValor=0 then cast(idFileServer as varchar(500)) else [valor] end valor FROM [Objeto].[documento].[DocumentoObjetoGeneral]    
			where  [idObjeto]= @idObjeto AND  [idDocumentoGeneral]= @idDocumento  AND idClase = @idClase  
			order by version desc    
		);    
  END
  IF @tipoPropiedad  = 'documentoClase'    
  BEGIN    
	SELECT top 1 @idDocumento=[idDocumentoClase], @ApValor = valor FROM [documento].[DocumentoClase] where nombre = @propiedad AND idClase = @idClase 
    SET @result = (    
		SELECT top 1 case when @ApValor=0 then cast(idFileServer as varchar(500)) else [valor] end valor FROM [Objeto].[documento].[DocumentoObjetoClase]    
			where  [idObjeto]= @idObjeto AND  [idDocumentoClase]= @idDocumento AND idClase = @idClase  
			order by version desc    
		);    
  END    
  IF @tipoPropiedad  = 'documentoContrato'    
  BEGIN    
	SELECT top 1 @idDocumento=[idDocumentoClase], @ApValor = valor FROM [documento].[DocumentoClase] where nombre = @propiedad AND idClase = @idClase 
    
	SET @result = (    
		SELECT top 1 case when @ApValor=0 then cast(idFileServer as varchar(500)) else [valor] end valor FROM [Objeto].[documento].[DocumentoObjetoContrato]    
			where  [idObjeto]= @idObjeto AND  [idDocumentoContrato]= @idDocumento AND idClase = @idClase  
			order by version desc    
    );    
  END    


  IF @tipoPropiedad  = 'documentoGeneralFile'    
  BEGIN   
   
   SET @result =  FileServer.documento.urlFileServer((   
    SELECT top 1 case when idFileServer is null then cast(idFileServer as varchar(500)) else idFileServer end idFileServer FROM [Objeto].[documento].[DocumentoObjetoGeneral]    
  where  [idObjeto]= @idObjeto AND  [idDocumentoGeneral]= (     
   SELECT top 1 [idDocumentoGeneral] FROM [documento].[DocumentoGeneral] where nombre = @propiedad  AND idClase = @idClase 
  )   AND idClase = @idClase  
  order by version desc    
    ));    
  END    
  IF @tipoPropiedad  = 'documentoClaseFile'    
  BEGIN    
   SET @result =  FileServer.documento.urlFileServer((    
    SELECT top 1 case when idFileServer is null then cast(idFileServer as varchar(500)) else idFileServer end idFileServer FROM [Objeto].[documento].[DocumentoObjetoClase]    
  where  [idObjeto]= @idObjeto AND  [idDocumentoClase]= (     
   SELECT top 1 [idDocumentoClase] FROM [documento].[DocumentoClase] where nombre = @propiedad  AND idClase = @idClase    
  )   AND idClase = @idClase  
  order by version desc    
    ));    
  END    
  IF @tipoPropiedad  = 'documentoContratoFile'    
  BEGIN    
   SET @result =  FileServer.documento.urlFileServer((    
    SELECT top 1 case when idFileServer is null then cast(idFileServer as varchar(500)) else idFileServer end idFileServer FROM [Objeto].[documento].[DocumentoObjetoContrato]    
  where  [idObjeto]= @idObjeto AND  [idDocumentoContrato]= (     
   SELECT top 1 [idDocumentoContrato] FROM [documento].[DocumentoContrato] where nombre = @propiedad   AND idClase = @idClase  
  )   AND idClase = @idClase  
  order by version desc    
    ));    
  END 
    
  RETURN @result    
    
END
go

