
-- =============================================
-- Author:		<EDGAR MENDOZA>
-- Create date: <04/07/2019>
-- Description:	<ACTUALIZA de Integridades>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	05-08-2019  JLLG	Agregando variables, try catch y comentarios
*/
CREATE TRIGGER [objeto].[UPD_OBJETO_TG] 
   ON  [objeto].[Objeto]
   AFTER UPDATE
AS 
BEGIN
	--ACTUALIZAMOS INTEGRIDADES
	DECLARE @IdUsuario			INT,
			@idClase			VARCHAR(10),
			@idTipoObjeto		INT,
			@idObjeto			INT,
			@idClaseDel			VARCHAR(10),
			@idTipoObjetoDel	INT,
			@idObjetoDel		INT,
			@VC_ThrowTable		VARCHAR(300) = '';

	SELECT TOP 1 @idClaseDel=idClase,@idTipoObjetoDel=idTipoObjeto,@idObjetoDel=idObjeto,@idUsuario=IdUsuario FROM DELETED
	SELECT TOP 1 @idClase=idClase,@idTipoObjeto=idTipoObjeto,@idObjeto=idObjeto,@idUsuario=IdUsuario FROM INSERTED

	BEGIN TRANSACTION
		BEGIN TRY 
			--ACTUALIZAMOS INTEGRIDADES
			SET @VC_ThrowTable = '[Cliente].[integridad].[Objeto]';
			
			UPDATE	[Cliente].[integridad].[Objeto]
			SET		idClase		=	@idClase,
					idTipoOjeto	=	@idTipoObjeto,
					idObjeto	=	@idObjeto
			WHERE	idClase		=	@idClaseDel
			AND		idTipoOjeto =	@idTipoObjeto
			AND		idObjeto	=	@idObjeto

			--Solicitud
			SET @VC_ThrowTable = '[Solicitud].[integridad].[Objeto]';
			UPDATE	[Solicitud].[integridad].[Objeto]
			SET		idClase		=	@idClase,
					idTipoObjeto=	@idTipoObjeto,
					idObjeto	=	@idObjeto
			WHERE	idClase		=	@idClaseDel
			AND		idTipoObjeto =	@idTipoObjeto
			AND		idObjeto	=	@idObjeto

			COMMIT TRANSACTION;
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION;
			EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
		END CATCH
END
go

