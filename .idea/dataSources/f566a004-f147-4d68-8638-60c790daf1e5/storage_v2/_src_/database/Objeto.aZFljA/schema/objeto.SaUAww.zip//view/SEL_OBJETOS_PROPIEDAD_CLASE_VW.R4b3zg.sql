
-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener los campos de clase de los objetos(unidades)>
-- =============================================
-- SELECT 
    -- [idObjeto]
    -- ,[idClase]
    -- ,[idTipoObjeto]
    -- ,[VIN]
    -- ,[color]
    -- ,[repuve] 
    -- ,[numeroEconomico] 
    -- ,[placa] 
    -- ,[numeroEconomicoExt] 
    -- ,[verificada] 
    -- ,[ultimoServicio] 
    -- ,[kilometraje] 
    -- ,[modelo]
-- FROM [objeto].[SEL_OBJETOS_PROPIEDAD_CLASE_VW]
-- =============================================
CREATE VIEW [objeto].[SEL_OBJETOS_PROPIEDAD_CLASE_VW]
AS

SELECT 
    [idObjeto]
    ,[idClase]
    ,[idTipoObjeto]
    ,[VIN]
    ,[color]
    ,[Repuve] repuve
    ,[NumeroEconomico] numeroEconomico
    ,[Placa] placa
    ,[NumeroEconomicoExt] numeroEconomicoExt
    ,[Verificada] verificada
    ,[UltimoServicio] ultimoServicio
    ,[KilometrajeAct] kilometraje
    ,[Año] modelo
	,[Entrega] entrega
FROM
(
    SELECT 
        OO.idObjeto
        ,OO.idClase
        ,OO.idTipoObjeto
        ,OOPC.valor
        ,OPC.agrupador
    FROM [Objeto].[objeto].[Objeto] OO
    INNER JOIN [Objeto].[objeto].[ObjetoPropiedadClase] OOPC
        ON OO.idClase = OOPC.idClase
        AND OO.idObjeto = OOPC.idObjeto
        AND OO.idTipoObjeto = OOPC.idTipoObjeto
    INNER JOIN [Objeto].[objeto].[PropiedadClase] OPC
        ON OPC.[idClase] = OOPC.[idClase]
        AND OPC.[idPropiedadClase] = OOPC.[idPropiedadClase]
    WHERE OPC.idTipoValor = 'Unico'
        AND OOPC.activo = 1

    UNION

    SELECT 
        OO.idObjeto
        ,OO.idClase
        ,OO.idTipoObjeto
        ,OPC.valor
        ,OPC.agrupador
    FROM [Objeto].[objeto].[Objeto] OO
    INNER JOIN [Objeto].[objeto].[ObjetoPropiedadClase] OOPC
        ON OO.idClase = OOPC.idClase
        AND OO.idObjeto = OOPC.idObjeto
        AND OO.idTipoObjeto = OOPC.idTipoObjeto
    INNER JOIN [Objeto].[objeto].[PropiedadClase] OPC
        ON OPC.[idClase] = OOPC.[idClase]
        AND OPC.[idPropiedadClase] = OOPC.[idPropiedadClase]
    INNER JOIN [Objeto].[objeto].[PropiedadClase] PP
        ON OPC.idClase = PP.idClase
        AND OPC.idPadre = PP.idPropiedadClase
    WHERE OPC.[agrupador] IN ('Año')
        AND OOPC.activo = 1
) T
    PIVOT
    (	
        MAX(valor)
        FOR agrupador in (
            [VIN]
            ,[color]
            ,[Repuve]
            ,[NumeroEconomico]
            ,[Placa]
            ,[NumeroEconomicoExt]
            ,[Verificada]
            ,[UltimoServicio]
            ,[KilometrajeAct]
            ,[Año]
			,[Entrega])
    ) AS resultado
go

