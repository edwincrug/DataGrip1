
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <24-06-2019>
-- Description:	<Insertar un operador>
-- =============================================
/*
	*** Versionamiento
	Fecha 				Autor							Descripción 
	21-may-2019	
	20/09/2019			Gerardo Zamudio Gonzalez		Agregando campo tipo
	*- Testing...

	EXEC [operador].[INS_OPERADOR_SP]
		3
		,1
		,'MXN'
		,'03'
		,'009'
		,'00984'
		,21
		,'Frac. 23'
		,4
		,'priv.moctezuma'
		,204
		,102
		,null
		,null
		,2
		,1
		,null
*/
-- =============================================
CREATE PROCEDURE [operador].[INS_OPERADOR_SP]
	@idUsers				int
	,@idEstatus				int
	,@idPais				varchar(3)
	,@idEstado				varchar(2)
	,@idMunicipio			varchar(5)
	,@codigoPostal			nchar(5)
	,@idTipoAsentamiento	nchar(2)
	,@asentamiento			nchar(500)
	,@idTipoVialidad		int
	,@vialidad				nchar(500)
	,@numeroExterior		nchar(250)
	,@numeroInterior		nchar(250)
	,@latitud				nchar(20)
	,@longitud				nchar(20)
	,@idUsuario				int
	,@activo				bit = 1
	,@idTipo					varchar(20)
	,@err					varchar(max) OUTPUT

AS
	BEGIN TRY
	BEGIN TRANSACTION

	SET @err = '';		

	IF EXISTS (SELECT idUsers FROM [operador].[Operador]
				WHERE idUsers = @idUsers) 
BEGIN
	-- Editamos al Operador
		UPDATE [operador].[Operador]
		   SET [idEstatus] = @idEstatus
			  ,[idPais] = @idPais
			  ,[idEstado] = @idEstado
			  ,[idMunicipio] = @idMunicipio
			  ,[codigoPostal] = @codigoPostal
			  ,[idTipoAsentamiento] = @idTipoAsentamiento
			  ,[asentamiento] = @asentamiento
			  ,[idTipoVialidad] = @idTipoVialidad
			  ,[vialidad] = @vialidad
			  ,[numeroExterior] = @numeroExterior
			  ,[numeroInterior] = @numeroInterior
			  ,[latitud] = @latitud
			  ,[longitud] = @longitud
			  ,[idUsuario] = @idUsuario
			  ,[activo] = @activo
			  ,[idTipo] = @idTipo
		 WHERE idUsers = @idUsers
END
ELSE
BEGIN
	-- Insertamos el Operador
INSERT INTO [operador].[Operador]
           ([idUsers]
           ,[idEstatus]
           ,[idPais]
           ,[idEstado]
           ,[idMunicipio]
           ,[codigoPostal]
           ,[idTipoAsentamiento]
           ,[asentamiento]
           ,[idTipoVialidad]
           ,[vialidad]
           ,[numeroExterior]
           ,[numeroInterior]
           ,[latitud]
           ,[longitud]
           ,[idUsuario]
           ,[activo]
		   ,[idTipo])
     VALUES
           (@idUsers
           ,@idEstatus
           ,@idPais
           ,@idEstado
           ,@idMunicipio
           ,@codigoPostal
           ,@idTipoAsentamiento
           ,@asentamiento
           ,@idTipoVialidad
           ,@vialidad
           ,@numeroExterior
           ,@numeroInterior
           ,@latitud
           ,@longitud
           ,@idUsuario
           ,@activo
		   ,@idTipo)
END
	SELECT idUsers FROM [operador].[Operador]
	WHERE idUsers = @idUsers

	SET @err = 'El Operador se registro correctamente.'
	COMMIT
END TRY

BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH

go

