
-- ==================================	===========
-- Author:		<Sandra Gil Rosales>
-- Create date: <24-06-2019>
-- Description:	<Obtener los registros de los operadores >
	/*- Testing...	
	DECLARE @salida varchar(max) ;
	EXEC [operador].[SEL_ASIGNACION_PORIDOBJETO_SP] 
	@idUsuario = 2 ,
	@idObjeto = 26850,
	@idTipoObjeto = 544,
	@err = @salida OUTPUT;
	SELECT @salida

*/
-- =============================================
CREATE PROCEDURE [operador].[SEL_ASIGNACION_PORIDOBJETO_SP] 
@idUsuario				int,
@idObjeto				int,
@idTipoObjeto			int,
@idClase				varchar(10) = 'Automovil',
@err					varchar(max) OUTPUT

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	 SET @err = '';

    -- Insert statements for procedure here
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT distinct op.[idUsers]
      ,[idEstatus]
	  ,us.PrimerNombre
	  ,us.SegundoNombre
	  , us.PrimerApellido
	  , us.SegundoApellido
	  , us.Avatar
	  ,us.Celular
	  ,us.Email
      ,op.[fechaRegistro]
      ,op.[idPais]
      ,op.[idEstado]
      ,op.[idMunicipio]
      ,[codigoPostal]
      ,op.[idTipoAsentamiento]
      ,[asentamiento]
      ,op.[idTipoVialidad]
      ,[vialidad]
      ,[numeroExterior]
      ,[numeroInterior]
      ,[latitud]
      ,[longitud]
      ,op.[idUsuario]
      ,op.[activo]
	  , p.nombre AS paisNombre
	  , es.nombre AS estadoNombre
	  , mun.nombre AS municipioNombre
	  , ase.nombre AS asentamientoTipo
	  , tv.nombre AS vialidadTipo
	  , asig.[idTipoObjeto]
      , asig.[idObjeto]
      , asig.[idAsignacion]
      , asig.[fechaAsignacion]
      , asig.[odometroAsignacion]
      , asig.[idFileAsignacion]
      , asig.[fechaEntrega]
      , asig.[odometroEntrega]
      , asig.[idFileEntrega]
	  , asig.[verGps]
	  , CASE WHEN asig.[fechaEntrega] = (SELECT  MIN(oa.fechaEntrega)  
					FROM [Objeto].[operador].[Asignacion] as oa
					WHERE CONVERT(date, oa.[fechaEntrega]) > CONVERT (date, GETDATE()) AND oa.idObjeto = @idObjeto 
					AND oa.idTipoObjeto = @idTipoObjeto) THEN 'Vigente'
			WHEN (CONVERT(date, asig.[fechaEntrega]) > CONVERT (date, GETDATE()) AND asig.[fechaEntrega] != (SELECT  MIN(oa.fechaEntrega)  FROM [Objeto].[operador].[Asignacion] AS oa
				WHERE CONVERT(date, oa.[fechaEntrega]) > CONVERT (date, GETDATE()) AND oa.idObjeto = @idObjeto 
					AND oa.idTipoObjeto = @idTipoObjeto)) THEN 'Asignada'

		ELSE 'Entregado' END AS vigencia
        ,COALESCE(SSOV.[horas], 0) horas
        ,COALESCE(OA.idOperadorActivo, 0) activoOperador
  FROM [Objeto].[operador].[Operador] AS op 
 -- left join 
 LEFT JOIN Seguridad.Catalogo.Users AS us ON op.idUsers = us.Id
 LEFT JOIN Common.direccion.Pais AS p ON op.idPais = p.idPais
 LEFT JOIN Common.direccion.Estado AS es ON op.idEstado = es.idEstado AND op.idPais = es.idPais
 LEFT JOIN Common.direccion.Municipio AS mun 
		ON op.idEstado = mun.idEstado AND op.idPais = mun.idPais AND op.idMunicipio = mun.idMunicipio
LEFT JOIN Common.direccion.TipoAsentamiento as ase ON op.idTipoAsentamiento = ase.idTipoAsentamiento
LEFT JOIN Common.direccion.TipoVialidad AS tv ON op.idTipoVialidad = tv.idTipoVialidad
LEFT JOIN [Objeto].[operador].[Asignacion] AS asig ON op.idUsers = asig.idUsers
LEFT JOIN [Objeto].[objeto].[Objeto] AS oo ON asig.idObjeto = oo.idObjeto AND asig.idTipoObjeto = oo.idTipoObjeto
LEFT JOIN [AVL].[vehiculo].[SEL_SESIONES_OBJETO_VW] SSOV 
    ON asig.idObjeto = SSOV.idObjeto
    AND asig.idTipoObjeto = SSOV.idTipoObjeto
    AND OO.idClase = SSOV.idClase
    AND op.idUsers = SSOV.idUsers
LEFT JOIN [AVL].[vehiculo].[ObjetoDispositivo] VOD
    ON VOD.idClase = OO.idClase
    AND VOD.idObjeto = OO.idObjeto
    AND VOD.idTipoObjeto = OO.idTipoObjeto
LEFT JOIN [AVL].[vehiculo].[OperadorActivo] OA
    ON OA.idDispositivo = VOD.deviceid
    AND op.idUsers = OA.idUsers
WHERE op.activo = 1  AND asig.idObjeto = @idObjeto AND asig.idTipoObjeto =  @idTipoObjeto
AND oo.idClase = @idClase

ORDER BY asig.[fechaAsignacion] DESC

END


go

