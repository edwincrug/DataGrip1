-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <12/04/2019>
-- Description:	<Elimina uno o mas elementos de las tablas 
-- ObjetoPropiedadGeneral
-- ObjetoPropiedadClase
-- ObjetoPropiedadContrato>
-- =============================================
/*
*- Testing...
DECLARE @salida varchar(max) ;
EXEC [objeto].[DEL_OBJETOPROPIEDADGENERAL_AGRUPADO_SP]
@idPropiedades = '<Ids>
<idObjeto>15</idObjeto>
</Ids>',
@err = @salida OUTPUT;
SELECT @salida AS salida;
*/
-- =============================================
	CREATE PROCEDURE [objeto].[DEL_OBJETOPROPIEDADGENERAL_AGRUPADO_SP]
		@idPropiedades	xml,	
		@idUsuario		INT = NULL,
		@err			varchar(max) OUTPUT
		AS
		BEGIN TRY
		BEGIN TRANSACTION

			SET NOCOUNT OFF;
			SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			SET @err = '';
			DECLARE @Ids TABLE (id INT);

			INSERT INTO @Ids
			SELECT 
				I.N.value('.', 'INT')
			FROM @idPropiedades.nodes('/Ids/idObjeto') I(N);
		BEGIN
			UPDATE [objeto].[ObjetoPropiedadGeneral]
				SET
				[activo] = 0, [idUsuario] = @idUsuario
				WHERE [idObjeto] in (select id from @Ids);
		END
		BEGIN
			UPDATE [objeto].[ObjetoPropiedadClase]
				SET
				[activo] = 0, [idUsuario] = @idUsuario
				WHERE [idObjeto] in (select id from @Ids);
		END
		BEGIN
			UPDATE [objeto].[ObjetoPropiedadContrato]
				SET
				[activo] = 0, [idUsuario] = @idUsuario
				WHERE [idObjeto] in (select id from @Ids);
		END
			Select 'Eliminado' as ok;
		SET NOCOUNT OFF;
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
			COMMIT
		END TRY

		BEGIN CATCH
			ROLLBACK
		END CATCH
go

