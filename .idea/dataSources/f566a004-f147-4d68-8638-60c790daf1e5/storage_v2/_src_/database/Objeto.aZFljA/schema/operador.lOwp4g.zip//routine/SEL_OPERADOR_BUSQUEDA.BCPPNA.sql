-- =============================================
-- Author:		Sandra Gil Rosales
-- Create date: 28/06/2019
-- Description:	Consulta de operadores (con opción de jerarquia)
-- store base: [Operacion].[Get_User_Busqueda] 

/* Testing:
   DECLARE @salida varchar(max) ='' ;
   EXEC [Operador].[SEL_OPERADOR_BUSQUEDA]
	'san',
	4, --4 ES JEFE DE 5 Y 7, 5 ES JEFE DE 6,7 Y 8, 7 ES JEFE DE 9 Y 10
	0,
	@salida OUTPUT
*/

-- ============== Versionamiento ================
/*
	Fecha			Autor					Descripción 
	

*/

CREATE PROCEDURE [operador].[SEL_OPERADOR_BUSQUEDA]
	@busqueda				varchar(250),
	--PARAMETROS PARA EL TIPO DE BUSQUEDA DE PARQUE VEHICULAR POR CONTRATO
	@idUsuario				int,
	@buscarPorJerarquia		bit,
	-----------------------------------------------------------------------
	@err			VARCHAR(max) OUTPUT
AS
BEGIN
-- variable temporal para el estatus aun no definido 
	DECLARE @idEstatus INT;
	SET @idEstatus = 1;

	if (@buscarPorJerarquia=0)
	BEGIN
		SELECT
			ISNULL(usu.Id,'')					Id,
			ISNULL(usu.PrimerNombre,'')			PrimerNombre,
			ISNULL(usu.SegundoApellido,'')		SegundoNombre,
			ISNULL(usu.PrimerApellido,'')		PrimerApellido,
			ISNULL(usu.SegundoApellido,'')		SegundoApellido,
			ISNULL(usu.Email,'')				Email,
			ISNULL(doc.path,'')					Foto,
			ISNULL(usu.Avatar, 0)				IdAvatar
		FROM Seguridad.Catalogo.Users usu
		left join [FileServer].[documento].documento doc on doc.idDocumento = usu.Avatar
		RIGHT JOIN [operador].[Operador] AS oo ON oo.idUsers = usu.Id AND oo.activo = @idEstatus
		where
			(
				
				usu.PrimerNombre like '%' + @busqueda + '%' or
				isnull(usu.SegundoNombre,'') like '%' + @busqueda + '%' or
				isnull(usu.PrimerApellido,'') like '%' + @busqueda + '%' or
				isnull(usu.SegundoApellido,'') like '%' + @busqueda + '%'
			) and usu.EstatusId=1
	END
	else if (@buscarPorJerarquia=1)
	begin
		declare @tbl_usuarios_jerarquia as table(
			idUsuario int
		)

		;WITH USU
		AS
		(
			SELECT DISTINCT
				jef.UserId,
				jef.Jefe
			FROM Seguridad.Relacion.Users_Jefe jef    
			where jef.Jefe = @idUsuario
			UNION ALL
			SELECT
				jef2.UserId,
				jef2.Jefe
			FROM Seguridad.Relacion.Users_Jefe jef2 
			inner join USU us on jef2.Jefe = us.UserId
		)
		INSERT INTO @tbl_usuarios_jerarquia
		SELECT UserId FROM USU group by UserId

		INSERT INTO @tbl_usuarios_jerarquia VALUES(@idUsuario)

		--YA QUE TENEMOS TODOS LOS USUARIOS QUE PUEDE VER EL JEFE BUSCAMOS COINCIDENCIAS
		SELECT
			ISNULL(usu.Id,'')					Id,
			ISNULL(usu.PrimerNombre,'')			PrimerNombre,
			ISNULL(usu.SegundoApellido,'')		SegundoNombre,
			ISNULL(usu.PrimerApellido,'')		PrimerApellido,
			ISNULL(usu.SegundoApellido,'')		SegundoApellido,
			ISNULL(usu.Email,'')				Email,
			ISNULL(doc.path,'')					Foto,
			ISNULL(usu.Avatar, 0)				IdAvatar
		FROM Seguridad.Catalogo.Users usu
		inner join @tbl_usuarios_jerarquia jer on usu.Id = jer.idUsuario
		left join [FileServer].[documento].documento doc on doc.idDocumento = usu.Avatar
		RIGHT JOIN [operador].[Operador] AS oo ON oo.idUsers = usu.Id AND oo.activo = @idEstatus
		where
			(
				
				usu.PrimerNombre like '%' + @busqueda + '%' or
				isnull(usu.SegundoNombre,'') like '%' + @busqueda + '%' or
				isnull(usu.PrimerApellido,'') like '%' + @busqueda + '%' or
				isnull(usu.SegundoApellido,'') like '%' + @busqueda + '%'
			) and usu.EstatusId=1

	end
END
go

