-- ==================================	===========
-- Author:		<Gerardo Zamudio González>
-- Create date: <20-09-2019>
-- Description:	<Obtener los Tipos de operadores >
	/*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [operador].[SEL_TIPO_SP] 
		@err = @salida OUTPUT;
	SELECT @salida
*/
-- =============================================
CREATE PROCEDURE [operador].[SEL_TIPO_SP] 
@idUsuario				int,
@err					varchar(max) OUTPUT

AS
BEGIN
	SET @err = '';
	SELECT 
		idTipo
		,nombre
	FROM [operador].[Tipo]

END
go

