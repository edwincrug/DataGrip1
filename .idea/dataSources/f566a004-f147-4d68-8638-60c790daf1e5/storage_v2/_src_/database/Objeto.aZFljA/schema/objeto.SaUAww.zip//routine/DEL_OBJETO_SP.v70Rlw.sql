
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <19-03-2019>
-- Description:	<Borrado Logico de campo de la tabla objetos>
-- =============================================
/*
modificado: 11-06-2019 Sandra Gil Rosales
	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [objeto].[DEL_OBJETO_SP] 
	@IdUsuario = 2,
		@data = '<Ids><idObjeto>317</idObjeto><idClase>Automovil</idClase><idTipo>99</idTipo></Ids>',
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [objeto].[DEL_OBJETO_SP] 
	@data				XML,
	@idUsuario				INT,
	@err				varchar(max) OUTPUT
AS

BEGIN TRY
		BEGIN TRANSACTION

			SET NOCOUNT OFF;
			SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
			SET @err = '';
			DECLARE @Ids TABLE (
			_row		INT IDENTITY(1,1),
			id			INT,
			idClase		varchar (10),
			idTipo		INT
			);

    INSERT INTO @Ids (id,
					idClase,
					idTipo)
    SELECT
		ParamValues.col.value('idObjeto[1]','int'),
		ParamValues.col.value('idClase[1]','nvarchar(10)'),
		ParamValues.col.value('idTipo[1]','int')
        FROM @data.nodes('Ids') AS ParamValues(col);

    DECLARE @cont			INT = 1,
			@idsObjetos		VARCHAR(50)

	WHILE((SELECT COUNT(*) FROM @Ids)>= @cont)
--inicio de while
	BEGIN
			DECLARE @id				INT;
			DECLARE @idClase		NVARCHAR(10);
			DECLARE @idTipo			INT;

			SELECT @id= id,
					@idClase = idClase,
					@idTipo = idTipo
			FROM @Ids
			WHERE _row = @cont

			SET @idsObjetos = ISNULL(@idsObjetos,'') + CAST(@id AS VARCHAR(50)) + ','
		
			BEGIN	
				UPDATE [objeto].[Objeto]
					SET 
						activo = 0, idUsuario = @idUsuario
					WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;
				Select 'Eliminado' as ok;
			END
			-- tablas de propiedades
			BEGIN
				UPDATE [objeto].[ObjetoPropiedadGeneral]
					SET
					[activo] = 0, [idUsuario] = @idUsuario
					WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;
			END
			BEGIN
				UPDATE [objeto].[ObjetoPropiedadClase]
					SET
					[activo] = 0, [idUsuario] = @idUsuario
					WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;
			END
			BEGIN
				UPDATE [objeto].[ObjetoPropiedadContrato]
					SET
					[activo] = 0, [idUsuario] = @idUsuario
					WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;
			END
			-- tabla de cliente 
			BEGIN
			UPDATE [Cliente].[contrato].[Objeto]
			SET	[idUsuario] = @idUsuario
				,[activo] = 0
			WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;
			END
			-- tablas de documentos 
			BEGIN
				DELETE FROM [documento].[DocumentoObjetoClase]
				WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;

				DELETE FROM [documento].[DocumentoObjetoContrato]
				WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;

				DELETE FROM [documento].[DocumentoObjetoGeneral]
				WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;
			END
			-- tablas de costos
			BEGIN
				DELETE FROM [documento].[CostoDocumentoClase]
				WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;

				DELETE FROM [documento].[CostoDocumentoContrato]
				WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;

				DELETE FROM [documento].[CostoDocumentoGeneral]
				WHERE idObjeto  = @id AND idTipoObjeto = @idTipo AND idClase = @idClase ;
			END


	SET @cont = @cont + 1

	IF (@@ERROR = 0)

		BEGIN

		DECLARE @llave VARCHAR(MAX) = '{"idObjeto":"' + @idsObjetos + '"}'

			EXEC [evento].[evento].[INS_EVENTO]
			@accion = 3
			,@modulo = 105
			,@gerencia = 1
			,@llave = @llave
			,@origen = NULL
			,@applicationId = 11
			,@idEstado = NULL
			,@idContratoZona = NULL
			,@idUsuario = @idUsuario
			,@err = ''
		END
	END
--termino de while

	Select 'Eliminado' as ok;
		SET NOCOUNT OFF;
		SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
			COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
go

