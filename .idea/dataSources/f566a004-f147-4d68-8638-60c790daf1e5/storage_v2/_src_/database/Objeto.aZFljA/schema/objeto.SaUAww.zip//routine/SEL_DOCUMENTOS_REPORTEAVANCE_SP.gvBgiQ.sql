-- =============================================
-- Author:		<Alan Rosales>
-- Create date: <10-09-2019>
-- Description:	<Obtener reporte de avance de control documental>
	/*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [objeto].[SEL_DOCUMENTOS_REPORTEAVANCE_SP] 	
		'Automovil'
		,'ASE0508051B6'		
		,92
		,'0001'
		,6119
		,@salida
	SELECT @salida AS salida;
*/	
-- =============================================
CREATE PROCEDURE [objeto].[SEL_DOCUMENTOS_REPORTEAVANCE_SP] 	
	@idClase				varchar(10),
	@rfcEmpresa				varchar(13),
	@idCliente				int = null,
    @numeroContrato			varchar(50) = null,
	@idUsuario				int = null,
	@err					varchar(500)OUTPUT
AS
BEGIN

	IF OBJECT_ID('tempdb..#documentacion') IS NOT NULL
	BEGIN
		DROP TABLE #documentacion
	END

	declare @totalUnidades int
	select 
		@totalUnidades = count(obj.idObjeto)
	from [objeto].[Objeto] obj
	inner join cliente.contrato.Objeto conobj on conobj.idObjeto=obj.idObjeto
	WHERE 
			obj.activo=1
			and conobj.rfcEmpresa=@rfcEmpresa and conobj.idCliente=@idCliente and conobj.numeroContrato=@numeroContrato

	create table #documentacion (
		idObjeto		int,
		idTipoObjeto	int,
		idDocumento		int,
		nombreDocumento	varchar(500),
		cargado			bit
		)

	INSERT INTO #documentacion
	select distinct
		res.idObjeto,
		res.idTipoObjeto,
		res.idDocumentoGeneral,
		res.nombre,
		case when objgen.idDocumentoGeneral is null then 0 else 1 end Cargado
	from 
	(
		select distinct
			obj.idObjeto,
			obj.idTipoObjeto,
			docgen.idDocumentoGeneral,
			docgen.nombre		
		from [objeto].[Objeto] obj
		inner join cliente.contrato.Objeto conobj on conobj.idObjeto=obj.idObjeto,
		[documento].[DocumentoGeneral] docgen
		WHERE 
			obj.activo=1
			and conobj.rfcEmpresa=@rfcEmpresa and conobj.idCliente=@idCliente and conobj.numeroContrato=@numeroContrato
			and docgen.activo=1
			and docgen.obligatorio=1
	) res
	left join [documento].[DocumentoObjetoGeneral] objgen on objgen.idDocumentoGeneral = res.idDocumentoGeneral and objgen.idObjeto = res.idObjeto


	insert into #documentacion
	select distinct
		res.idObjeto,
		res.idTipoObjeto,
		res.idDocumentoClase,
		res.nombre,
		case when objcla.idObjeto is null then 0 else 1 end Cargado
	from 
	(
		select distinct
			obj.idObjeto,
			obj.idTipoObjeto,
			doccla.idDocumentoClase,
			doccla.nombre
		from [objeto].[Objeto] obj
		inner join cliente.contrato.Objeto conobj on conobj.idObjeto=obj.idObjeto,
		[documento].[DocumentoClase] doccla
		WHERE 
			obj.activo=1
			and conobj.rfcEmpresa=@rfcEmpresa and conobj.idCliente=@idCliente and conobj.numeroContrato=@numeroContrato
			and doccla.activo=1
			and doccla.obligatorio=1
			and doccla.idAgrupador in ('documentacion','general') and doccla.idClase=@idClase
	) res
	left join [documento].[DocumentoObjetoClase] objcla on objcla.idDocumentoClase = res.idDocumentoClase and objcla.idObjeto=res.idObjeto
	
	/**salidas para el reporte*/
	--1. Total de documentos por rubro	
	select  
		doc.idDocumento,
		doc.nombreDocumento,
		sum(case doc.cargado when 1 then 1 else 0 end) totalEntregado,
		@totalUnidades totalUnidades
	from #documentacion doc
	group by 
		doc.idDocumento,doc.nombreDocumento
	order by doc.nombreDocumento
	
	--2. Totales por estatus
	select 
		res2.Estatus estatus,
		count(res2.Estatus) total
	from (
	select 
	case 
		when res.total=0 then 'PENDIENTE'
		when res.total between 0 and  @totalUnidades then 'EN PROCESO'
		else 'FINALIZADO'
	end Estatus,
	(res.total/convert(float,@totalUnidades))*100 porcentajeAvance	
	from 
	(
		select  
			doc.idDocumento,
			doc.nombreDocumento,
			sum(case doc.cargado when 1 then 1 else 0 end) total
		from #documentacion doc
		group by 
			doc.idDocumento,doc.nombreDocumento
	) res) res2
	group by res2.Estatus

	--3. Totales por marca
	select 
		[Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,'Clase','tipoClase', tob.idClase) Clase,
		sum(case doc.cargado when 1 then 1 else 0 end) totalEntregado,
		(select count(1) from #documentacion) totalDocumentos
	from #documentacion doc
	inner join [Partida].tipoobjeto.TipoObjeto tob on doc.idTipoObjeto = tob.idTipoObjeto and idClase='Automovil'
	where doc.cargado=1
	group by
		[Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,'Clase','tipoClase', tob.idClase)
		

	--3. Totales detalle por marca
	declare @columnsNameTipoObjeto varchar(max)
	SET @columnsNameTipoObjeto = STUFF((SELECT ',' + QUOTENAME(prg.nombreDocumento) 
						FROM (select  
								doc.nombreDocumento
							from #documentacion doc
							group by 
								doc.idDocumento,doc.nombreDocumento
							) prg 
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')

	declare @queryObjeto varchar(max)

	set @queryObjeto = '
	select * from (select 
		 [Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,''Clase'',''tipoClase'', tob.idClase) Clase
		,[Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,''Marca'',''tipoClase'', tob.idClase) Marca
		,[Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,''Submarca'',''tipoClase'', tob.idClase) Submarca
		,0 Modelo
		,doc.nombreDocumento
		,count(doc.idDocumento) totalDocumentos
		,0 Cantidad
	from #documentacion doc
	inner join [Partida].tipoobjeto.TipoObjeto tob on doc.idTipoObjeto = tob.idTipoObjeto and idClase=''Automovil'' 
	where doc.cargado=1
	group by
		[Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,''Clase'',''tipoClase'', tob.idClase)
		,[Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,''Marca'',''tipoClase'', tob.idClase)
		,[Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,''Submarca'',''tipoClase'', tob.idClase)
		,[Objeto].Objeto.getPropiedadObjeto(tob.idTipoObjeto,''Año'',''tipoClase'', tob.idClase)
		,doc.nombreDocumento
	) as T
	Pivot ( sum(totalDocumentos) for nombreDocumento in(
		'+ @columnsNameTipoObjeto +'
	)) as PVT'
	execute (@queryObjeto)

	
	-- obtener los objetos por tipo de objeto
	select 
		DOC.idObjeto,
		[Objeto].Objeto.getPropiedadObjeto(DOC.idTipoObjeto,'Clase','tipoClase', O.idClase) Clase,
		[Objeto].Objeto.getPropiedadObjeto(DOC.idTipoObjeto,'Marca','tipoClase', O.idClase) Marca,
		[Objeto].Objeto.getPropiedadObjeto(DOC.idTipoObjeto,'Submarca','tipoClase', O.idClase) Submarca,
		[Objeto].Objeto.getPropiedadObjeto(O.idObjeto,'VIN','clase', O.idClase) VIN
		,[Objeto].Objeto.getPropiedadObjeto(O.idObjeto,'Año','clase', O.idClase) Modelo
		,[Objeto].Objeto.getPropiedadObjeto(O.idObjeto,'NumeroEconomico','clase', O.idClase) NumeroEconomico
		,DOC.cargado
		,DOC.nombreDocumento
	from #documentacion DOC
	inner join Objeto.Objeto O on O.idObjeto = DOC.idObjeto
								and O.idTipoObjeto = DOC.idTipoObjeto
	where O.activo = activo
	order by DOC.idObjeto

	drop table #documentacion
END

go

