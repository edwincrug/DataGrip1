
-- =============================================
-- Author:		Andres Farias
-- Create date: <19-06-2019>
-- Description:	<Obtener la telemetria de un objeto>
-- =============================================

/*

	------ Versionamiento
	Fecha 		Autor	Descrición

	testing

	[gps].[SEL_OBJETO_TELEMETRIA_PORVIN_SP] @VIN='VIN07067', @fechaInicio = '2019/05/25'
*/

CREATE PROCEDURE [gps].[SEL_OBJETO_TELEMETRIA_PORVIN_SP]
@idClase				varchar(20) = NULL,
@idUsuario				int = null,
@VIN					varchar(13),
@fechaInicio			date,
@err					varchar(max) = '' OUTPUT

AS

BEGIN
	set language español
	DECLARE @tbl_kilometros_por_dia AS TABLE(
		_row int identity(1, 1),
		fecha date,
		dia int,
		feriado bit,
		finSemana bit,
		kilometros float,
		promedioFlotilla float
	);

	-- Kilometraje
	SELECT 
	35573 as kilometraje,
	80 as capaciadadTanque,
	75 as temperaturaMotor,
	12 as voltaje,
	40.5 as rendimento

	-- Alarmas
	SELECT 50 as DesaceleracionBrusca,
		30 ACCapagado,
		100 ACCencendido,
		20 AceleracionBrusca,
		20 DispositivoDesconectado,
		50 DispositivoConectado,
		20 GiroBrusco,
		100 Remolque

	-- kilometros recorridos
	INSERT INTO @tbl_kilometros_por_dia(
				fecha,
				dia,
				feriado,
				finSemana,
				kilometros,
				promedioFlotilla
				)values('15-05-2019',15,0,0, 20, 20),
				('16-05-2019',16,0,0, 30, 30),
				('17-05-2019',17,0,0, 60, 40),
				('18-05-2019',18,0,1, 40, 30),
				('19-05-2019',19,0,1, 23, 20),
				('12-05-2019',20,0,0, 45, 60),
				('21-05-2019',21,1,0, 56, 40),
				('22-05-2019',22,0,0, 32, 30),
				('23-05-2019',23,0,0, 45, 40),
				('24-05-2019',24,0,0, 43, 40),
				('25-05-2019',25,0,1, 56, 20),
				('26-05-2019',26,0,1, 90, 100),
				('27-05-2019',27,0,0, 43, 29),
				('28-05-2019',28,0,0, 21, 30),
				('29-05-2019',29,0,0, 56, 23),
				('30-05-2019',30,0,0, 10, 30),
				('31-05-2019',31,0,0, 15, 40),
				('01-06-2019',01,0,1, 40, 10),
				('02-06-2019',02,0,1, 20, 20),
				('03-06-2019',03,0,0, 50, 40),
				('04-06-2019',04,0,0, 30, 30),
				('05-06-2019',05,0,0, 40, 40),
				('06-06-2019',06,0,0, 21, 32),
				('07-06-2019',07,1,0, 30, 30),
				('08-06-2019',08,0,1, 90, 40),
				('09-06-2019',09,0,1, 80, 29),
				('10-06-2019',10,0,0, 40, 50),
				('11-06-2019',11,0,0, 60, 20),
				('12-06-2019',12,0,0, 78, 30),
				('13-06-2019',13,1,0, 56, 20),
				('14-06-2019',14,0,0, 34, 10),
				('15-06-2019',15,0,1, 20, 30)

	SELECT * FROM @tbl_kilometros_por_dia

END

go

