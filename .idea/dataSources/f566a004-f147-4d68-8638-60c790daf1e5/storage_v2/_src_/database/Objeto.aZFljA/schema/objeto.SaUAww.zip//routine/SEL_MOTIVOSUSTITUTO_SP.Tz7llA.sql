
-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <23-07-2019>
-- Description:	<Obtener propiedades de sustituto>
-- =============================================

/*
	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [objeto].[SEL_MOTIVOSUSTITUTO_SP] 6077,
	
	@salida OUTPUT;
	SELECT @salida AS salida;

	------ Versionamiento
	Fecha 		Autor	Descrición

	
*/

CREATE PROCEDURE [objeto].[SEL_MOTIVOSUSTITUTO_SP] 
      
	  @idUsuario			INT,
	  @err					varchar(max) OUTPUT
AS
BEGIN

	select 
	* 
	from [objeto].[MotivoSustituto]
  
END

go

