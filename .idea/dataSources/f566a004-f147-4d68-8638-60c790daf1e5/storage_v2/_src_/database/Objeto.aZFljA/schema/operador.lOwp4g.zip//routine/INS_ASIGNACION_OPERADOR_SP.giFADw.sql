
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <24-06-2019>
-- Description:	<Insertar un operador>
-- =============================================
/*
	*** Versionamiento
	Fecha 		Autor	Descripción 
	21-may-2019	
	*- Testing...

	EXEC [operador].[INS_ASIGNACION_OPERADOR_SP]
		2
		,70
		,40
		,null
		,567800
		,'00984'
		,null
		,null
		,null
		,2
		,null
*/
-- =============================================
CREATE PROCEDURE [operador].[INS_ASIGNACION_OPERADOR_SP]
	@idUsers				int
	,@idTipoObjeto			int
	,@idObjeto				int
	,@fechaAsignacion		datetime
	,@odometroAsignacion	nchar(10)
	,@idFileAsignacion		int
	,@fechaEntrega			datetime
	,@odometroEntrega		nchar(10)
	,@idFileEntrega			int
	,@idUsuario				int
	,@verGps				bit
	,@err					varchar(max) OUTPUT

AS
	BEGIN TRY
	BEGIN TRANSACTION

	SET @err = '';	
	DECLARE @idAsignacion INT;		
	-- Insertamos la Asignación por Operador
INSERT INTO [operador].[Asignacion]
           ([idUsers]
           ,[idTipoObjeto]
           ,[idObjeto]
           ,[fechaAsignacion]
           ,[odometroAsignacion]
           ,[idFileAsignacion]
           ,[fechaEntrega]
           ,[odometroEntrega]
           ,[idFileEntrega]
           ,[idUsuario]
		   ,[verGps])
     VALUES
           (@idUsers
           ,@idTipoObjeto
			,@idObjeto
			,@fechaAsignacion
			,@odometroAsignacion
			,@idFileAsignacion
			,@fechaEntrega
			,@odometroEntrega
			,@idFileEntrega
			,@idUsuario
			,@verGps)



	SET @idAsignacion = @@IDENTITY

	IF (@@ERROR = 0)

		BEGIN

		DECLARE @llave VARCHAR(MAX) = '{"idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '","idTipoObjeto":"' + CAST(@idTipoObjeto AS VARCHAR(50)) + '","Operador":"' + 
		CAST(@idUsers AS VARCHAR(50)) + '"}'

			EXEC [evento].[evento].[INS_EVENTO]
			@accion = 1
			,@modulo = 240
			,@gerencia = 1
			,@llave = @llave
			,@origen = NULL
			,@applicationId = 11
			,@idEstado = NULL
			,@idContratoZona = NULL
			,@idUsuario = @idUsuario
			,@err = ''
		END

	COMMIT
END TRY

BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH

go

