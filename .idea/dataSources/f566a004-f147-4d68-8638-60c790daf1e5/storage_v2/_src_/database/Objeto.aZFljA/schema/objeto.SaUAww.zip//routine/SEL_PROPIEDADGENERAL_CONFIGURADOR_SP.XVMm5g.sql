-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <22-03-2019>
-- Description:	<Obtener los registros de las propiedades 
-- de los otres tipos , generales, clase y contrato
-- agregando loso tipos d e datos y valores>

	/*- Testing...

	EXEC [objeto].[SEL_PROPIEDADGENERAL_CONFIGURADOR_SP]
	@idClase = 'Automovil',
	@idCliente = 92,
	@err = null

*/

CREATE PROCEDURE [objeto].[SEL_PROPIEDADGENERAL_CONFIGURADOR_SP]
	@idClase			varchar(10),
	@idCliente			int = null,
    @numeroContrato		varchar(50) = null,
	@idUsuario			int = null,
	@err				NVARCHAR(500) = '' OUTPUT
AS
BEGIN

	 SELECT 
		idPropiedadGeneral	as id
		,ISNULL(idPadre,0)	 as idPadre
		,valor	
		,'' as arreglo
		,'' idClase
		,idTipoValor
		,idTipoDato
		,agrupador
		,'general' propiedad
		,1 idPropiedad
		,obligatorio
		,orden
		,posicion
		,activo
		,@numeroContrato
		,@idCliente
	FROM
	[objeto].[PropiedadGeneral]
	WHERE activo = 1
	ORDER BY idPropiedad asc,posicion asc, orden desc 


	SELECT 
		idPropiedadClase	as id
		,ISNULL(idPadre,0)	 as idPadre
		,valor	
		,'' as arreglo
		,idClase
		,idTipoValor
		,idTipoDato
		,agrupador
		,'clase' propiedad
		,2 idPropiedad
		,obligatorio
		,orden
		,posicion
		,activo
		,@numeroContrato
		,@idCliente
	FROM [objeto].[PropiedadClase]
	WHERE idClase = @idClase AND activo = 1
	ORDER BY idPropiedad asc,posicion asc, orden desc 

	SELECT 
			idPropiedadContrato	as id
			,ISNULL(idPadre,0)	 as idPadre
			,valor	
			,'' as arreglo
			,'' idClase
			,idTipoValor
			,idTipoDato
			,agrupador
			,'contrato' propiedad
			,3 idPropiedad
			,obligatorio
			,orden
			,posicion
			,activo
			,numeroContrato
			,idCliente
		FROM [objeto].[PropiedadContrato]
		WHERE idCliente = @idCliente AND activo = 1
		ORDER BY idPropiedad asc,posicion asc, orden desc 

		
END
go

