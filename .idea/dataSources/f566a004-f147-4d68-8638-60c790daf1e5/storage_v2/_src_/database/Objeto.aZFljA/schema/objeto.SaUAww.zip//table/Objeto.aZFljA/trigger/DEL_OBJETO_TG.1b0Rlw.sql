
-- =============================================
-- Author:		<EDGAR MENDOZA>
-- Create date: <04/07/2019>
-- Description:	<ELIMINA de Integridades>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	05-08-2019  JLLG	Agregando variables, try catch y comentarios
*/
CREATE TRIGGER [objeto].[DEL_OBJETO_TG] 
   ON  [objeto].[Objeto]
   AFTER DELETE
AS 
BEGIN
	--ELIMINAMOS INTEGRIDADES
	DECLARE @IdUsuario			INT,
			@idClase			VARCHAR(10),
			@idTipoObjeto		INT,
			@idObjeto			INT,
			@VC_ThrowTable		VARCHAR(300) = '';

	SELECT TOP 1 @idClase=idClase,@idTipoObjeto=idTipoObjeto,@idObjeto=idObjeto,@idUsuario=IdUsuario FROM DELETED

	BEGIN TRANSACTION
		BEGIN TRY 
			--Cliente
			SET @VC_ThrowTable = '[Cliente].[integridad].[Objeto]';
			DELETE FROM [Cliente].[integridad].[Objeto] 
			WHERE	idClase		= @idClase
			AND		idTipoOjeto = @idTipoObjeto
			AND		idObjeto	= @idObjeto

			--Solicitud
			SET @VC_ThrowTable = '[solicitud].[integridad].[Objeto]';
			DELETE FROM [solicitud].[integridad].[Objeto] 
			WHERE	idClase			= @idClase
			AND		idTipoObjeto	= @idTipoObjeto
			AND		idObjeto		= @idObjeto

			COMMIT TRANSACTION;
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION;
			EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
		END CATCH
END
go

