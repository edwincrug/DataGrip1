
-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <23-05-2019>
-- Description:	<Obtener las propiedades de objeto por id>
-- =============================================

/*

	------ Versionamiento
	Fecha 		Autor	Descrición
	 13/08/2019	José Etmanuel	Agregando clase a la función Objeto.objeto.getPropiedadObjeto
	 22/08/2019	SGIL	Los datos varian segun el nombre de las propiedades de clase (cambio de nombres de propiedades)
 
	testing

	[objeto].[SEL_OBJETO_PORID_SP] @idClase='Automovil',@rfcEmpresa = 'ASE0508051B6', 
	@numeroContrato='132',@idObjeto= 4314, @idTipoObjeto = 126, @idUsuario= 6115,@idCliente=185, @err = null

	select * from cliente.cliente.contrato where nombre like '%sedena%'

*/

CREATE PROCEDURE [objeto].[SEL_OBJETO_PORID_SP]

@idClase				varchar(20) = NULL,
@numeroContrato			varchar(50) = NULL,
@idCliente				int = 78,
@rfcEmpresa				varchar(13),
@idObjeto				int ,
@idTipoObjeto			int ,
@idUsuario				int = null,
@err					varchar(max) OUTPUT

AS

BEGIN

DECLARE @objetoSolicitud BIT

IF OBJECT_ID('tempdb..#tmpTipoObjeto') IS NOT NULL
		BEGIN
			DROP TABLE #tmpTipoObjeto
		END

IF OBJECT_ID('tempdb..#tmpObjeto') IS NOT NULL
	BEGIN
		DROP TABLE #tmpObjeto
	END

IF OBJECT_ID('tempdb..#propiedadesTipoObjeto') IS NOT NULL
	BEGIN
		DROP TABLE #propiedadesTipoObjeto
	END

IF OBJECT_ID('tempdb..#propiedadesOrdenasTipoObjeto') IS NOT NULL
	BEGIN
		DROP TABLE #propiedadesOrdenasTipoObjeto
	END

IF OBJECT_ID('tempdb..#propiedadesObjeto') IS NOT NULL
	BEGIN
		DROP TABLE #propiedadesObjeto
	END


    --*************************************************************************** PROPIEDADES TIPO OBJETO ******************************************************
create table #propiedadesTipoObjeto(
	idTipoObjeto		int,
	agrupador			varchar(500),
	valor				varchar(250),
	orden				int,
	posicion			int,
	ordenFinal			INT
)

/**********************************************************************************************************************
******************************************************CATALOGOS Y AGRUPADORES******************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with catalogos as(
	select	
		tob.idTipoObjeto				idTipoObjeto,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from 
	partida.tipoobjeto.TipoObjeto tob
	inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tob.idTipoObjeto = tpg.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
	inner join partida.integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	where 
		prg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		and tob.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idTipoObjeto				idTipoObjeto,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		prg.valor						valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from partida.tipoobjeto.PropiedadGeneral prg 
	inner join partida.integridad.TipoDato tpd on tpd.idTipoDato = prg.idTipoDato 
	inner join catalogos cat on cat.idPadre = prg.idPropiedadGeneral
	and prg.activo = 1
	)
	insert into #propiedadesTipoObjeto
	select 
		cat.idTipoObjeto,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null


--PROPIEDADES DE CLASE
;with catalogos as(
	select
		tob.idTipoObjeto				idTipoObjeto,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from 
	partida.tipoobjeto.TipoObjeto tob
	inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tob.idTipoObjeto = tpc.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
	where 
		prc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		and tob.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idTipoObjeto				idTipoObjeto,
		prc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.tipoobjeto.PropiedadClase prc 
	inner join catalogos cat on cat.idPadre = prc.idPropiedadClase 
	WHERE prc.activo = 1
	)
	insert into #propiedadesTipoObjeto
	select 
		cat.idTIpoObjeto,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

	--select * from #propiedadesTipoObjeto
/**********************************************************************************************************************
*********************************************************TAGS**********************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with tags as(
	select	
		tob.idTipoObjeto				idTipoObjeto,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prg.valor,'')			valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from 
	-- select * from
	partida.tipoobjeto.TipoObjeto tob
	inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tob.idTipoObjeto = tpg.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
	where prg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	and tob.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idTipoObjeto				idTipoObjeto,
		prg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prg.valor,'')			valor,
		prg.idPadre						idPadre,
		prg.orden						orden,
		prg.posicion					posicion,
		0								ordenFinal
	from partida.tipoobjeto.PropiedadGeneral prg 
	inner join tags tag on tag.idPadre = prg.idPropiedadGeneral
	WHERE prg.activo = 1
	)
	insert into #propiedadesTipoObjeto
	select distinct 
		idTipoObjeto,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idTipoObjeto = tags. idTipoObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

--PROPIEDADES CLASE
;with tags as(
	select	
		tob.idTipoObjeto				idTipoObjeto,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from 
	-- select * from 
	partida.tipoobjeto.TipoObjeto tob
	inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tob.idTipoObjeto = tpc.idTipoObjeto
	inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
	where prc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	and tob.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idTipoObjeto				idTipoObjeto,
		prc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(prc.valor,'')			valor,
		prc.idPadre						idPadre,
		prc.orden						orden,
		prc.posicion					posicion,
		1								ordenFinal
	from partida.tipoobjeto.PropiedadClase prc 
	inner join tags tag on tag.idPadre = prc.idPropiedadClase
	and prc.activo = 1
	)
	insert into #propiedadesTipoObjeto
	select distinct 
		idTipoObjeto,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idTipoObjeto = tags.idTipoObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

/**********************************************************************************************************************
***************************************************VALORES FIJOS*******************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
INSERT INTO #propiedadesTipoObjeto
select 
	pto.idTipoObjeto		idTipoObjeto,
	prg.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	tpg.valor				valor,
	prg.orden						orden,
	prg.posicion					posicion,
	0								ordenFinal
from 
-- select * from 
partida.tipoobjeto.TipoObjeto pto 
inner join partida.tipoobjeto.TipoObjetoPropiedadGeneral tpg on tpg.idTipoObjeto = pto.idTipoObjeto
inner join partida.tipoobjeto.PropiedadGeneral prg on tpg.idPropiedadGeneral = prg.idPropiedadGeneral
where
	prg.idTipoValor = 'Unico'
	and pto.idClase = @idClase
	and pto.activo = 1

--PROPIEDADES DE CLASE
INSERT INTO #propiedadesTipoObjeto
select 
	pto.idTipoObjeto		idTipoObjeto,
	prc.valor				agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	tpc.valor				valor,
	prc.orden				orden,
	prc.posicion			posicion,
	1								ordenFinal
from 
-- select * from 
partida.tipoobjeto.TipoObjeto pto 
inner join partida.tipoobjeto.TipoObjetoPropiedadClase tpc on tpc.idTipoObjeto = pto.idTipoObjeto
inner join partida.tipoobjeto.PropiedadClase prc on tpc.idPropiedadClase = prc.idPropiedadClase
where
	prc.idTipoValor = 'Unico'
	and pto.idClase = @idClase
	and pto.activo = 1



/**********************************************************************************************************************
******************************************************PIVOTE***********************************************************
**********************************************************************************************************************/
declare 
	@columnsNameTipoObjeto varchar(max) = ''

create table #propiedadesTipoObjetoOrdenas
	(
		agrupador			varchar(500),
		ordenFinal			int,
		posicion			int,
		orden				int
	)
insert into #propiedadesTipoObjetoOrdenas
select distinct 
	pr.agrupador,
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)
from #propiedadesTipoObjeto pr group by pr.agrupador order by 
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)


SET @columnsNameTipoObjeto = STUFF((SELECT ',' + QUOTENAME(prg.agrupador) 
						FROM #propiedadesTipoObjetoOrdenas prg 
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')



--**************************************************************** PROPIEDADES DE OBJETO ***********************************************************************

--creamos tabla temporal para insertar las propiedades del tipo objeto dependiendo del tipo de valor
create table #propiedadesObjeto(
	idObjeto			int,
	idTipoObjeto		int,
	idVersion			int,
	agrupador			varchar(500),
	valor				varchar(250),
	orden				int,
	posicion			int,
	ordenFinal			INT
)

/**********************************************************************************************************************
******************************************************CATALOGOS Y AGRUPADORES******************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with catalogos as(
	select	
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		obj.idVersion					idVersion,
		oprg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		oprg.valor						valor,
		oprg.idPadre					idPadre,
		oprg.orden						orden,
		oprg.posicion					posicion,
		0								ordenFinal
	from 
	-- select * from 
	[Objeto].[objeto].[Objeto] obj 
	left join partida.tipoObjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.ObjetoPropiedadGeneral otpg on otpg.idObjeto = obj.idObjeto
	inner join objeto.objeto.PropiedadGeneral oprg on otpg.idPropiedadGeneral = oprg.idPropiedadGeneral
	inner join objeto.integridad.TipoDato otpd on otpd.idTipoDato = oprg.idTipoDato
	where 
		oprg.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		--and obj.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idObjeto					idObjeto,
		cat.idTipoObjeto				idTipoObjeto,
		cat.idVersion					idVersion,
		oprg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		oprg.valor						valor,
		oprg.idPadre					idPadre,
		oprg.orden						orden,
		oprg.posicion					posicion,
		0								ordenFinal
	from 
	-- select * from 
	objeto.objeto.PropiedadGeneral oprg 
	inner join objeto.integridad.TipoDato otpd on otpd.idTipoDato = oprg.idTipoDato 
	inner join catalogos cat on cat.idPadre = oprg.idPropiedadGeneral
	and oprg.activo = 1
	)
	insert into #propiedadesObjeto
	select 
		cat.idObjeto,
		cat.idTipoObjeto,
		cat.idVersion,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

--PROPIEDADES DE CLASE
;with catalogos as(
	select
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		obj.idVersion					idVersion,
		oprc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre					idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from 
	-- select * from 
	objeto.objeto obj
	left join partida.tipoobjeto.TipoObjeto tob On tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objetoPropiedadClase otpc on obj.idObjeto = otpc.idObjeto
	inner join objeto.PropiedadClase oprc on otpc.idPropiedadClase = oprc.idPropiedadClase
	where 
		oprc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		--and obj.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idObjeto					idObjeto,
		cat.idTipoObjeto				idTipoObjeto,
		cat.idVersion					idVersion,
		oprc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from 
	-- select * from 
	objeto.PropiedadClase oprc 
	inner join catalogos cat on cat.idPadre = oprc.idPropiedadClase 
	WHERE oprc.activo = 1
	)
	insert into #propiedadesObjeto
	select 
		cat.idObjeto,
		cat.idTipoObjeto,
		cat.idVersion,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

--PROPIEDADES DE CONTRATO
;with catalogos as(
	select
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		obj.idVersion					idVersion,
		oprc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre					idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from 
	-- select * from 
	objeto.objeto obj
	left join partida.tipoobjeto.TipoObjeto tob On tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objetoPropiedadContrato otpc on obj.idObjeto = otpc.idObjeto
	inner join objeto.PropiedadContrato oprc on otpc.idPropiedadContrato = oprc.idPropiedadContrato
	where 
		oprc.idTipoValor in ('Catalogo','Agrupador') --SOLO APLICA PARA CATALOGOS Y AGRUPADORES
		and tob.idClase = @idClase
		and oprc.numeroContrato = @numeroContrato
		and oprc.idCliente = @idCliente
		and oprc.rfcEmpresa = @rfcEmpresa
		--and obj.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		cat.idObjeto					idObjeto,
		cat.idTipoObjeto				idTipoObjeto,
		cat.idVersion					idVersion,
		oprc.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from 
	-- select * from
	objeto.PropiedadContrato oprc 
	inner join catalogos cat on cat.idPadre = oprc.idPropiedadContrato 
	WHERE oprc.activo = 1
	and oprc.numeroContrato = @numeroContrato
	and oprc.idCliente = @idCliente
	and oprc.rfcEmpresa = @rfcEmpresa
	and idCliente = @idCliente
	)
	insert into #propiedadesObjeto
	select 
		cat.idObjeto,
		cat.idTipoObjeto,
		cat.idVersion,
		cat.agrupador,
		cat.valor,
		cat.orden,
		cat.posicion,
		cat.ordenFinal
	from catalogos cat 
	where 
		cat.idPadre is not null

	
/**********************************************************************************************************************
*********************************************************TAGS**********************************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES
;with tags as(
	select	
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		obj.idVersion					idVersion,
		oprg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprg.valor,'')			valor,
		oprg.idPadre					idPadre,
		oprg.orden						orden,
		oprg.posicion					posicion,
		0								ordenFinal
	from
	-- select * from 
	objeto.objeto obj
	left join partida.tipoobjeto.TipoObjeto tob On tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.objetoPropiedadGeneral otpg on obj.idObjeto = otpg.idObjeto
	inner join objeto.objeto.PropiedadGeneral oprg on otpg.idPropiedadGeneral = oprg.idPropiedadGeneral
	where oprg.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	--and obj.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idObjeto					idObjeto,
		tag.idTipoObjeto				idTipoObjeto,
		tag.idVersion					idVersion,
		oprg.agrupador					agrupador, --PARA CATALOGOS Y AGRUPADORES SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprg.valor,'')			valor,
		oprg.idPadre					idPadre,
		oprg.orden						orden,
		oprg.posicion					posicion,
		0								ordenFinal
	from objeto.objeto.PropiedadGeneral oprg 
	inner join tags tag on tag.idPadre = oprg.idPropiedadGeneral
	WHERE oprg.activo = 1
	)
	insert into #propiedadesObjeto
	select distinct 
		idObjeto,
		idTipoObjeto,
		idVersion,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idObjeto = tags.idObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags

--PROPIEDADES CLASE
;with tags as(
	select	
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		obj.idVersion					idVersion,
		oprc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto obj 
	left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.objetoPropiedadClase otpc on obj.idObjeto = otpc.idObjeto
	inner join objeto.objeto.PropiedadClase oprc on otpc.idPropiedadClase = oprc.idPropiedadClase
	where oprc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	--and obj.activo = 1
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idObjeto					idObjeto,
		tag.idTipoObjeto				idTipoObjeto,
		tag.idVersion					idVersion,
		oprc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto.PropiedadClase oprc 
	inner join tags tag on tag.idPadre = oprc.idPropiedadClase
	and oprc.activo = 1
	)
	insert into #propiedadesObjeto
	select distinct 
		idObjeto,
		idTipoObjeto,
		idVersion,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idObjeto = tags.idObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags


--PROPIEDADES CONTRATO
;with tags as(
	select	
		obj.idObjeto					idObjeto,
		tob.idTipoObjeto				idTipoObjeto,
		obj.idVersion					idVersion,
		oprc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto obj 
	left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
	inner join objeto.objeto.objetoPropiedadContrato otpc on obj.idObjeto = otpc.idObjeto
	inner join objeto.objeto.PropiedadContrato oprc on otpc.idPropiedadContrato = oprc.idPropiedadContrato
	where oprc.idTipoValor in ('Etiqueta') --SOLO APLICA PARA TAGS
	and tob.idClase = @idClase
	--and obj.activo = 1
	and oprc.numeroContrato = @numeroContrato
	and oprc.idCliente = @idCliente
	and oprc.rfcEmpresa = @rfcEmpresa
	UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
	select
		tag.idObjeto					idObjeto,
		tag.idTipoObjeto				idTipoObjeto,
		tag.idVersion					idVersion,
		oprc.agrupador					agrupador, --PARA TAGS SE TOMA EL CAMPO 'AGRUPADOR'
		isnull(oprc.valor,'')			valor,
		oprc.idPadre						idPadre,
		oprc.orden						orden,
		oprc.posicion					posicion,
		1								ordenFinal
	from objeto.objeto.PropiedadContrato oprc 
	inner join tags tag on tag.idPadre = oprc.idPropiedadContrato
	and oprc.activo = 1
	and oprc.numeroContrato = @numeroContrato
	and idCliente = @idCliente
	and oprc.rfcEmpresa = @rfcEmpresa
	)
	insert into #propiedadesObjeto
	select distinct 
		idObjeto,
		idTipoObjeto,
		idVersion,
		agrupador,
		(
	SELECT STUFF(
	
		(SELECT ', ' + valor
		FROM tags tagsAux
		WHERE tagsAux.idPadre is not null and tagsAux.idObjeto = tags.idObjeto and tagsAux.agrupador = tags.agrupador
		FOR XML PATH ('')),
	1,1, '') ) as valor, orden, posicion, ordenFinal from tags


--/**********************************************************************************************************************
--***************************************************VALORES FIJOS*******************************************************
--**********************************************************************************************************************/
----PROPIEDADES GENERALES
INSERT INTO #propiedadesObjeto
select 
	obj.idObjeto					idObjeto,
	tob.idTipoObjeto				idTipoObjeto,
	obj.idVersion					idVersion,
	oprg.valor						agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	otpg.valor						valor,
	oprg.orden						orden,
	oprg.posicion					posicion,
	0								ordenFinal
from objeto.objeto obj 
left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
inner join objeto.objeto.ObjetoPropiedadGeneral otpg on otpg.idObjeto = obj.idObjeto
inner join objeto.objeto.PropiedadGeneral oprg on otpg.idPropiedadGeneral = oprg.idPropiedadGeneral
where
	oprg.idTipoValor = 'Unico'
	and tob.idClase = @idClase
	--and obj.activo = 1

--PROPIEDADES DE CLASE
INSERT INTO #propiedadesObjeto
select 
	obj.idObjeto					idObjeto,
	tob.idTipoObjeto				idTipoObjeto,
	obj.idVersion					idVersion,
	oprc.valor						agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	otpc.valor						valor,
	oprc.orden						orden,
	oprc.posicion					posicion,
	1								ordenFinal
from objeto.objeto obj 
left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
inner join objeto.objeto.ObjetoPropiedadClase otpc on otpc.idObjeto = obj.idObjeto
inner join objeto.objeto.PropiedadClase oprc on otpc.idPropiedadClase = oprc.idPropiedadClase
where
	oprc.idTipoValor = 'Unico'
	and tob.idClase = @idClase
	--and obj.activo = 1
	--REXE
	--and oprc.activo = 1
	--REXE

--PROPIEDADES DE CONTRATO
INSERT INTO #propiedadesObjeto
select 
	obj.idObjeto					idObjeto,
	tob.idTipoObjeto				idTipoObjeto,
	obj.idVersion					idVersion,
	oprc.valor						agrupador, --PARA VALORES FIJOS SE TOMA EL CAMPO 'AGRUPADOR'
	otpc.valor						valor,
	oprc.orden						orden,
	oprc.posicion					posicion,
	1								ordenFinal
from objeto.objeto obj 
left join partida.tipoobjeto.TipoObjeto tob on tob.idTipoObjeto = obj.idTipoObjeto
inner join objeto.objeto.ObjetoPropiedadContrato otpc on otpc.idObjeto = obj.idObjeto
inner join objeto.objeto.PropiedadContrato oprc on otpc.idPropiedadContrato = oprc.idPropiedadContrato
where
	oprc.idTipoValor = 'Unico'
	and tob.idClase = @idClase
	and obj.activo = 1
	and oprc.numeroContrato = @numeroContrato
	and oprc.idCliente = @idCliente
	and oprc.rfcEmpresa = @rfcEmpresa



/**********************************************************************************************************************
******************************************************PIVOTE***********************************************************
**********************************************************************************************************************/
declare 
	@columnsNameObjeto varchar(max) = ''

--select * from #propiedadesObjeto order by ordenFinal, posicion, orden

create table #propiedadesOrdenasObjeto
	(
		agrupador			varchar(500),
		ordenFinal			int,
		posicion			int,
		orden				int
	)
insert into #propiedadesOrdenasObjeto
select distinct 
	pr.agrupador,
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)
from #propiedadesObjeto pr group by pr.agrupador order by 
	min(pr.ordenFinal),
	min(pr.posicion),
	min(pr.orden)


SET @columnsNameObjeto = STUFF((SELECT ',' + QUOTENAME(prg.agrupador) 
						FROM #propiedadesOrdenasObjeto prg 
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')




/******************************************************** DOCUMENTOS *******************************************************/


DECLARE 
	@placa varchar(100),
	@placavigencia date,
	@placaIdFile int, 
	@estatusPlaca varchar(20),
	@tarjetaCirculacionVigencia date,
	@tarjetaCirculacionIdFile int,
	@estatustarjetaCirculacion varchar(20),
	@tenenciaVigencia date,
	@tenenciaIdFile int,
	@estatustenencia varchar(20),
	@verificacionVigencia date,
	@verificacionIdFile int,
	@estatusVerificacion varchar(20),
	@seguroVigencia varchar(10),
	@seguroIdFile int,
	@estatusSeguro varchar(20),
	@multaVigencia date,
	@multaIdFile int,
	@multaAdeudo varchar(50),
	@color varchar (50),
	@usuarioPlacas varchar (100),
	@fechaPlacas varchar(10),
	@usuarioTC varchar (100),
	@fechaTC varchar(10),
	@usuarioTenencia varchar (100),
	@fechaTenencia varchar(10),
	@usuarioSeguro varchar (100),
	@fechaSeguro varchar(10),
	@usuarioV varchar (100),
	@fechaV varchar(10),
	@usuarioMulta varchar (100),
	@fechaMulta varchar(10)


-- DATOS DE PLACA

SELECT TOP 1
	@placa = DOC.valor, 
	@placavigencia = DOC.vigencia,
	@placaIdFile = DOC.idFileServer,
	@estatusPlaca = CASE 
	WHEN GETDATE() > DOC.vigencia THEN 'Vencida'
	ELSE 'Vigente' END,
	@usuarioPlacas = SU.PrimerNombre +' '+ SU.SegundoNombre + ' ' + SU.PrimerApellido,
	@fechaPlacas = DOC.fecha
	from [documento].[DocumentoObjetoClase] DOC
	INNER JOIN documento.DocumentoClase DC ON DC.idDocumentoClase = DOC.idDocumentoClase
	INNER JOIN Seguridad.Catalogo.Users SU ON SU.Id = DOC.idUsuario
	where DC.nombre = 'Placa' 
	and DOC.idObjeto = @idObjeto
	and DOC.idTipoObjeto = @idTipoObjeto
	ORDER BY version desc

-- TARJETA DE CIRCULACION

SELECT TOP 1
	@tarjetaCirculacionVigencia = DOC.vigencia,
	@tarjetaCirculacionIdFile = DOC.idFileServer,
	@estatusTarjetaCirculacion = CASE
	WHEN GETDATE() > DOC.vigencia THEN 'Vencida'
	ELSE 'Vigente' END,
	@usuarioTC = SU.PrimerNombre +' '+ SU.SegundoNombre + ' ' + SU.PrimerApellido,
	@fechaTC = DOC.fecha
	from [documento].[DocumentoObjetoClase] DOC
	INNER JOIN documento.DocumentoClase DC ON DC.idDocumentoClase = DOC.idDocumentoClase
	INNER JOIN Seguridad.Catalogo.Users SU ON SU.Id = DOC.idUsuario
	where DC.nombre = 'Tarjeta de Circulación' 
	and DOC.idObjeto = @idObjeto
	and DOC.idTipoObjeto = @idTipoObjeto
	ORDER BY version desc

-- TENENCIA

SELECT TOP 1
	@tenenciaVigencia = DOC.vigencia,
	@tenenciaIdFile = DOC.idFileServer,
	@estatusTenencia = CASE 
	WHEN GETDATE() > DOC.vigencia THEN 'Vencida'
	ELSE 'Vigente' END,
	@usuarioTenencia = SU.PrimerNombre +' '+ SU.SegundoNombre + ' ' + SU.PrimerApellido,
	@fechaTenencia = DOC.fecha
	from [documento].[DocumentoObjetoClase] DOC
	INNER JOIN documento.DocumentoClase DC ON DC.idDocumentoClase = DOC.idDocumentoClase
	INNER JOIN Seguridad.Catalogo.Users SU ON SU.Id = DOC.idUsuario
	where DC.nombre = 'Tenencia' 
	and DOC.idObjeto = @idObjeto
	and DOC.idTipoObjeto = @idTipoObjeto
	ORDER BY version desc

-- VERIFICACION

SELECT TOP 1
	@verificacionVigencia = DOC.vigencia,
	@verificacionIdFile = DOC.idFileServer,
	@estatusVerificacion = CASE 
	WHEN GETDATE() > DOC.vigencia THEN 'Vencida'
	ELSE 'Vigente' END,
	@usuarioV = SU.PrimerNombre +' '+ SU.SegundoNombre + ' ' + SU.PrimerApellido,
	@fechaV = DOC.fecha
	from [documento].[DocumentoObjetoClase] DOC
	INNER JOIN documento.DocumentoClase DC ON DC.idDocumentoClase = DOC.idDocumentoClase
	INNER JOIN Seguridad.Catalogo.Users SU ON SU.Id = DOC.idUsuario
	where DC.nombre = 'Verificación Ambiental' 
	and DOC.idObjeto = @idObjeto
	and DOC.idTipoObjeto = @idTipoObjeto
	ORDER BY version desc

-- SEGURO

SELECT TOP 1
	@seguroVigencia = DOC.vigencia,
	@seguroIdFile = DOC.idFileServer,
	@estatusSeguro = CASE 
	WHEN GETDATE() > DOC.vigencia THEN 'Vencida'
	ELSE 'Vigente' END,
	@usuarioSeguro = SU.PrimerNombre +' '+ SU.SegundoNombre + ' ' + SU.PrimerApellido,
	@fechaSeguro = DOC.fecha
	from [documento].[DocumentoObjetoClase] DOC
	INNER JOIN documento.DocumentoClase DC ON DC.idDocumentoClase = DOC.idDocumentoClase
	INNER JOIN Seguridad.Catalogo.Users SU ON SU.Id = DOC.idUsuario
	where DC.nombre = 'Póliza de Seguro' 
	and DOC.idObjeto = @idObjeto
	and DOC.idTipoObjeto = @idTipoObjeto
	ORDER BY version desc

-- MULTA
	
SELECT TOP 1
	@multaVigencia = a.vigencia,
	@multaIdFile = a.idFileServer,
	@multaAdeudo = costo,
	@usuarioMulta = SU.PrimerNombre +' '+ SU.SegundoNombre + ' ' + SU.PrimerApellido,
	@fechaMulta = a.fecha
	from [documento].[DocumentoObjetoClase] AS a
	left join [documento].[CostoDocumentoClase] AS b on a.idCostoDocumentoClase = b.idCostoDocumentoClase AND a.idDocumentoClase = b.idDocumentoClase AND a.idObjeto = b.idObjeto
	INNER JOIN documento.DocumentoClase DC ON DC.idDocumentoClase = a.idDocumentoClase
	INNER JOIN Seguridad.Catalogo.Users SU ON SU.Id = a.idUsuario
	where DC.nombre = 'Multa' 
	and a.idObjeto = @idObjeto
	and a.idTipoObjeto = @idTipoObjeto
	ORDER BY a.version desc

-- COLOR 

SELECT TOP 1
	@color = pcol.valor
  FROM [Objeto].[objeto].[PropiedadClase] pcol	
  LEFT JOIN [Objeto].[objeto].[ObjetoPropiedadClase] opcol
  ON pcol.idClase = opcol.idClase AND pcol.idPropiedadClase = opcol.idPropiedadClase
  WHERE pcol.valor = 'Color' AND pcol.activo = 1  
  AND opcol.idObjeto = @idObjeto 
  AND idTipoObjeto = @idTipoObjeto  
  AND pcol.idClase = @idClase


	declare @queryObjeto varchar(max)
	set @queryObjeto = '
						select
							*
						INTO #tmpTipoObjeto
						from
						(select idTipoObjeto, agrupador, valor from #propiedadesTipoObjeto) t  
						pivot
						(	
							max(valor)
							for agrupador in (' + @columnsNameTipoObjeto + ')
						) AS resultado

						select
							*
						INTO #tmpObjeto
						from
						(select idObjeto,idTipoObjeto,idVersion, agrupador, valor from #propiedadesObjeto) t  
						pivot
						(	
							max(valor)
							for agrupador in (' + @columnsNameObjeto + ')
						) AS resultado

						IF OBJECT_ID(''tempdb..#tmpObjeto'') IS NOT NULL
							BEGIN
								SELECT 
								CASE
								WHEN (SELECT TOP 1 idFileServer 
										from documento.documentoobjetogeneral dog
										inner join documento.documentogeneral dg on dg.iddocumentogeneral = dog.iddocumentogeneral
										WHERE idObjeto = o.idObjeto  and dg.nombre = ''Foto Principal'' 
										ORDER BY fecha desc) IS NOT NULL THEN (SELECT TOP 1 idFileServer 
																					from documento.documentoobjetogeneral dog
																					inner join documento.documentogeneral dg on dg.iddocumentogeneral = dog.iddocumentogeneral
																					WHERE idObjeto = o.idObjeto  and dg.nombre = ''Foto Principal'' 
																					ORDER BY fecha desc)

								WHEN TOB.Foto IS NOT NULL THEN TOB.Foto
								ELSE 19906 END
								 AS fotoPrincipal,
								 CO.idContratoZona,
								 CO.idCentroCosto,
								 CZ.descripcion as zona,
								 (select activo from objeto.objeto where idObjeto = O.idObjeto) as activoObjeto,
								 CO.idObjetoEstatus as estatusObjeto,
								 ''' + ISNULL(@placa,'') +''' as Placas,
								 ''' + CAST(ISNULL(@placaVigencia,'') AS VARCHAR(50)) +''' as placaVigencia,
								 ' +  CAST(ISNULL(@placaIdFile,'') AS VARCHAR(50)) +' as placaIdFile,
								 ''' + ISNULL(@estatusPlaca,'') +''' as estatusPlaca,
								 ''' + CAST(ISNULL(@tarjetaCirculacionVigencia,'') AS VARCHAR(50)) +''' as tarjetaCirculacionVigencia,
								 ' + CAST(ISNULL(@tarjetaCirculacionIdFile,'') AS VARCHAR(50)) +' as tarjetaCirculacionIdFile,
								 ''' + ISNULL(@estatusTarjetaCirculacion,'') +''' as estatusTarjetaCirculacion,
								 ''' + CAST(ISNULL(@tenenciaVigencia,'') AS VARCHAR(50)) +''' as tenenciaVigencia,
								 ' + CAST(ISNULL(@tenenciaIdFile,'') AS VARCHAR(50)) +' as tenenciaIdFile,
								 ''' + ISNULL(@estatusTenencia,'') +''' as estatusTenencia, 
								 ''' + CAST(ISNULL(@verificacionVigencia,'') AS VARCHAR(50)) +''' as verificacionVigencia,
								 ' + CAST(ISNULL(@verificacionIdFile,'') AS VARCHAR(50)) +' as verificacionIdFile,
								 ''' + ISNULL(@estatusVerificacion,'') +''' as estatusVerificacion,
								 ''' + ISNULL(@seguroVigencia,'') +''' as seguroVigencia,
								 ' + CAST(ISNULL(@seguroIdFile,'') AS VARCHAR(50)) +' as seguroIdFile,
								 ''' + ISNULL(@estatusSeguro,'') +''' as estatusSeguro,
								 ''' + CAST(ISNULL(@multaVigencia,'') AS VARCHAR(50)) +''' as multaVigencia,
								 ' + CAST(ISNULL(@multaIdFile,'') AS VARCHAR(50)) +' as multaIdFile,
								 ''' + ISNULL(@multaAdeudo,'') +''' as multaAdeudo,
								 ''' + ISNULL(@color,'') +''' as color,
								''' + ISNULL(@usuarioPlacas,'') +''' as usuarioPlacas,
								''' + ISNULL(@fechaPlacas,'') +''' as fechaPlacas,
								''' + ISNULL(@usuarioTC,'') +''' as usuarioTarjetaCirculacion,
								''' + ISNULL(@fechaTC,'') +''' as fechaTarjetaCirculacion,
								''' + ISNULL(@usuarioTenencia,'') +''' as usuarioTenencia,
								''' + ISNULL(@fechaTenencia,'') +''' as fechaTenencia,
								''' + ISNULL(@usuarioSeguro,'') +''' as usuarioSeguro,
								''' + ISNULL(@fechaSeguro,'') +''' as fechaSeguro,
								''' + ISNULL(@usuarioV,'') +''' as usuarioVerificacion,
								''' + ISNULL(@fechaV,'') +''' as fechaVerificacion,
								''' + ISNULL(@usuarioMulta,'') +''' as usuarioMulta,
								''' + ISNULL(@fechaMulta,'') +''' as fechaMulta,
								sv.id as idDeviced,
					
								--datos de telemetria
								200 as Kilometraje,
								1427 as kimetrosPromedioPorMes,
								20 as diasPromedioPorMes,
								12 as ultimoRecorrido,
								19.3320935 as latitud,
								-99.2083881 as longitud,

								-- Para fotos del objeto
								(select [objeto].[getPropiedadObjeto]  (' + CAST(@idObjeto AS VARCHAR(50)) +', ''Foto Frente'', ''documentoClase'',''' + CAST(@idClase AS VARCHAR(50)) +''')) as fotoFrente,
								(select [objeto].[getPropiedadObjeto]  (' + CAST(@idObjeto AS VARCHAR(50)) +', ''Foto Derecho'', ''documentoClase'',''' + CAST(@idClase AS VARCHAR(50)) +''')) as fotoDerecho,
								(select [objeto].[getPropiedadObjeto]  (' + CAST(@idObjeto AS VARCHAR(50)) +', ''Foto Izquierda'', ''documentoClase'',''' + CAST(@idClase AS VARCHAR(50)) +''')) as fotoIzquierda,
								(select [objeto].[getPropiedadObjeto]  (' + CAST(@idObjeto AS VARCHAR(50)) +', ''Foto Trasera'', ''documentoClase'',''' + CAST(@idClase AS VARCHAR(50)) +''')) as fotoTrasera,

								CASE
									WHEN SV.socketVersion = 1 THEN ''Socket1''
									WHEN SV.socketVersion = 2 THEN ''Socket2''
								END versionSocket,
								(select top 1 * from(SELECT lastupdate FROM [TRACKER].[Tracker_Socket1].[dbo].[tc_devices] where uniqueid = odi.uniqueid--
								union all
								SELECT lastupdate FROM [TRACKER].[Tracker_Socket2].[dbo].[tc_devices] where uniqueid = odi.uniqueid)--
								as fecha order by lastupdate desc) as lastUpdate
								,sv.uniqueid idUnique
								,*
								from #tmpTipoObjeto TOB 
								INNER JOIN #tmpObjeto O ON TOB.idTipoObjeto = O.idTipoObjeto
								LEFT JOIN  cliente.contrato.Objeto CO ON CO.idObjeto = O.idObjeto and CO.idTipoObjeto = O.idTipoObjeto
								LEFT JOIN [Cliente].[contrato].[ObjetoEstatus] OE ON OE.idObjetoEstatus = CO.idObjetoEstatus
								LEFT JOIN [Common].[gerencia].[ContratoZona] CZ ON CZ.idContratoZona = CO.idContratoZona
								LEFT JOIN [AVL].[vehiculo].[ObjetoDispositivo] odi ON odi.idObjeto = O.idObjeto
								LEFT JOIN [TRACKER].[AVL].[vehiculo].[SEL_DEVICES_SOCKET_VERSION_VW] SV ON SV.uniqueid = odi.uniqueid
								LEFT JOIN [TRACKER].[GPS].[inventario].GPS gps ON gps.deviceID = odi.uniqueid
								LEFT JOIN [TRACKER].[GPS].[catalogo].[GPSModelo] gmod on gmod.idGPSModelo = gps.idGPSModelo
								WHERE O.idObjeto =' + CAST(@idObjeto AS VARCHAR(100)) + ' AND CO.numeroContrato =' + CAST(@numeroContrato AS VARCHAR(100)) + '  AND O.idTipoObjeto=' + CAST(@idTipoObjeto AS VARCHAR(100)) + '
								order by O.idObjeto
							END
						
						'

execute (@queryObjeto)
SELECT geolocalizacion FROM Cliente.cliente.Contrato WHERE rfcEmpresa = @rfcEmpresa AND idCliente = @idCliente AND numeroContrato = @numeroContrato

IF(EXISTS(SELECT * FROM Solicitud.solicitud.SolicitudObjeto where idObjeto = @idObjeto and idTipoObjeto = @idTipoObjeto))
	BEGIN
		SET @objetoSolicitud = 1
		SELECT @objetoSolicitud
	END
ELSE
	BEGIN
		SET @objetoSolicitud = 0
		SELECT @objetoSolicitud
	END

--select * into propiedadesObjeto from  #propiedadesObjeto
--select * into propiedadesOrdenasObjeto from  #propiedadesOrdenasObjeto
--select * into propiedadesTipoObjeto from  #propiedadesTipoObjeto
--select * into propiedadesTipoObjetoOrdenas from  #propiedadesTipoObjetoOrdenas

drop table #propiedadesObjeto
drop table #propiedadesOrdenasObjeto
drop table #propiedadesTipoObjeto
drop table #propiedadesTipoObjetoOrdenas

END
/*
select * from propiedadesObjeto
select * from propiedadesOrdenasObjeto
select * from propiedadesTipoObjeto
select * from propiedadesTipoObjetoOrdenas
*/

go

