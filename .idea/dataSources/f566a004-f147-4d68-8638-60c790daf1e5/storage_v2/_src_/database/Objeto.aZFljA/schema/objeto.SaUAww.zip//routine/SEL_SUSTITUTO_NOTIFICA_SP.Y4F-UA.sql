
-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <18-09-2019>
-- Description:	Notificacion cuando se libera un sustituto
-- =============================================

/*
	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [objeto].[SEL_SUSTITUTO_NOTIFICA_SP] 
	
	@salida OUTPUT;
	SELECT @salida AS salida;

	------ Versionamiento
	Fecha 		Autor	Descrición

	
*/

CREATE PROCEDURE [objeto].[SEL_SUSTITUTO_NOTIFICA_SP] 


AS

BEGIN



	IF OBJECT_ID('tempdb..#sustitutos') IS NOT NULL
			BEGIN
			DROP TABLE #sustitutos
			END

	SELECT 
		ROW_NUMBER() OVER(ORDER BY idSustituto ASC) AS Row#
		,idSustituto
		,idClase
	INTO #sustitutos
	from [objeto].[Sustituto]
	WHERE notificacionLiberacion = 0
	AND idUsuarioLiberacion is not null

	DECLARE 
		@contador					INT = 1
		,@idSustituto				INT
		,@idClase					VARCHAR(10)



	WHILE ( SELECT count(idSustituto) FROM #sustituto) > @contador
			BEGIN  
			


				Select 
					@idSustituto = idSustituto
					,@idClase = idClase
				FROM #sustituto 
				WHERE Row# = @contador

				DECLARE @llave VARCHAR(MAX) = '{"idSustituto":"' + @idSustituto + '","idClase":"' + @idClase + '"}'

				EXEC [evento].[evento].[INS_EVENTO]
				@accion = 3
				,@modulo = 247
				,@gerencia = 1
				,@llave = @llave
				,@origen = NULL
				,@applicationId = 11
				,@idEstado = NULL
				,@idContratoZona = NULL
				,@idUsuario = NULL
				,@err = ''

				UPDATE [objeto].[Sustituto] SET notificacionLiberacion = 1 WHERE idSustituto = @idSustituto
				

				SET @contador = @contador + 1
			END  

END
go

