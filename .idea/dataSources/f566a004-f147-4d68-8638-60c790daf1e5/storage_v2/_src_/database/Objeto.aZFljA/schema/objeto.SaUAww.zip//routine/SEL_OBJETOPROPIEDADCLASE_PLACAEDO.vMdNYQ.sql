
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <30-05-2019>
-- Description:	< Seleccionar las placas de los vehiculos activos por un Estado especifico>
-- =============================================
/*
	*** Versionamiento
	Fecha 		Autor	Descripción 
	21-may-2019	JEHR	Agregando versionamiento,
						y contrato obligatorio como idUsuario

	24-jun-2019 EAMG	Se quita el filtro por estado
	*- Testing...

	EXEC [objeto].[SEL_OBJETOPROPIEDADCLASE_PLACAEDO]
	6077
	,null

*/
-- =============================================
CREATE PROCEDURE [objeto].[SEL_OBJETOPROPIEDADCLASE_PLACAEDO]
	@idUsuario			int = null,
	@err				varchar(max) OUTPUT

AS
BEGIN

	SELECT
	'Clase' tipo,
	docClase.idClase,
	docClase.idTipoObjeto,
	(SELECT idDocumentoClase from [Objeto].[documento].[DocumentoClase] WHERE nombre = 'Multa') idDocumento,
	docClase.idObjeto,
	docClase.idTipoDocumento,
	docClase.valor placa,
	(SELECT idConcepto from [Solicitud].[gestoria].[Concepto] WHERE nombre = 'Multas') idConcepto 
	FROM 
	[Objeto].[documento].[DocumentoObjetoClase] docClase
	LEFT JOIN [Objeto].[documento].[DocumentoClase] AS clase ON docClase.idDocumentoClase = clase.idDocumentoClase
	LEFT JOIN [Objeto].[objeto].[Objeto] AS objeto ON objeto.idObjeto = docClase.idObjeto
	WHERE clase.nombre =  'Placa' 
	AND objeto.activo = 1

END

go

