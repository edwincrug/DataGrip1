-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <24-09-2019>
-- Description:	<Obtener los registros de los tipos de documentos . extensiones>

	/*- Testing...

	EXEC [documento].[SEL_TIPODOCUMENTO_SP]
	@err = null

*/

CREATE PROCEDURE [documento].[SEL_TIPODOCUMENTO_SP]
	@idUsuario			int = null,
	@err				NVARCHAR(500) = '' OUTPUT
AS
BEGIN

	 SELECT [idTipoDocumento]
			,[descripcion]
			,[idUsuario]
			,[activo]
		FROM [Objeto].[documento].[TipoDocumento]
		WHERE activo = 1 
		ORDER BY idTipoDocumento

END
go

