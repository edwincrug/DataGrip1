-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <04/07/2019>
-- Description:	<Alta de Integridades>
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	05-08-2019  JLLG	Agregando variables, try catch y comentarios
*/
CREATE TRIGGER [objeto].[INS_OBJETO_TG] 
   ON  [objeto].[Objeto]
   AFTER INSERT
AS 
BEGIN
	--INSERTAMOS INTEGRIDADES
	DECLARE @IdUsuario			INT,
			@idClase			VARCHAR(10),
			@idTipoObjeto		INT,
			@idObjeto			INT,
			@VC_ThrowTable		VARCHAR(300) = '';
	SELECT TOP 1 @idClase=idClase,@idTipoObjeto=idTipoObjeto,@idObjeto=idObjeto,@idUsuario=IdUsuario FROM INSERTED
	
	BEGIN TRANSACTION
		BEGIN TRY 
			-- inserto en integridad de clientes
			SET @VC_ThrowTable = '[Cliente].[integridad].[Objeto]';
			INSERT INTO [Cliente].[integridad].[Objeto]
			VALUES(@idClase,@idTipoObjeto,@idObjeto)
			
			-- inserto en integridad de solicitud
			SET @VC_ThrowTable = '[Solicitud].[integridad].[Objeto]';
			INSERT INTO [Solicitud].[integridad].[Objeto]
			VALUES(@idClase,@idTipoObjeto,@idObjeto)

			COMMIT TRANSACTION;
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION;
			EXECUTE [Common].[log].[INS_Trigger_Error_SP] @VC_ThrowTable, @IdUsuario
		END CATCH
	
END
go

