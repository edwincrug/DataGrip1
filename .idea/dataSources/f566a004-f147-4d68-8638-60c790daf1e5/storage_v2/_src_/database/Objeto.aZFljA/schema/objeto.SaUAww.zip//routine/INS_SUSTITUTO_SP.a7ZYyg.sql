
-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <24-07-2019>
-- Description:	Insertar sustituto
-- =============================================

/*
	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [objeto].[INS_SUSTITUTO_SP] 
	2,
	'prueba',
	'prueba',
	'2019-07-24T00:00:00',
	'<objetosSustituto><objetoSustituto><idObjetoSustituto>243</idObjetoSustituto><idTipoObjetoSustituto>100</idTipoObjetoSustituto></objetoSustituto><objetoSustituto><idObjetoSustituto>269</idObjetoSustituto><idTipoObjetoSustituto>100</idTipoObjetoSustituto></objetoSustituto></objetosSustituto>',
	'Automovil',
	241,
	100,
	6077,
	@salida OUTPUT;
	SELECT @salida AS salida;

	------ Versionamiento
	Fecha 		Autor	Descrición

	
*/

CREATE PROCEDURE [objeto].[INS_SUSTITUTO_SP] 

		@motivo						INT,
		@noOrden					VARCHAR(50),
		@comentarios				VARCHAR(MAX),
		@fecha						DATETIME,
		@idObjetoSustituto			INT,
		@idTipoObjetoSustituto		INT,
		@idClase					VARCHAR(10),
		@idObjeto					INT,
		@idTipoObjeto				INT,
		@idUsuario					INT,
		@err						varchar(max) OUTPUT
AS
BEGIN



	INSERT INTO [objeto].[Sustituto]

	SELECT
		@idClase,
		@idTipoObjeto, 
		@idObjeto,
		@idTipoObjetoSustituto,
		@idObjetoSustituto,
		@motivo,
		@noOrden,
		@fecha,
		@comentarios,
		NULL,
		NULL,
		@idUsuario,
		NULL,
		0
	


	IF (@@ERROR = 0)
		BEGIN

		DECLARE @llave VARCHAR(MAX) = '{"idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '","idTipoObjeto":"' + CAST(@idTipoObjeto AS VARCHAR(50)) + 
		'","idClase":"' + @idClase + '","idObjetoSustituto":"' + CAST(@idObjetoSustituto AS VARCHAR(50)) + '","idTipoObjetoSustituto":"' + CAST(@idTipoObjetoSustituto AS VARCHAR(50)) + '"}'

		EXEC [evento].[evento].[INS_EVENTO]
		@accion = 1
		,@modulo = 247
		,@gerencia = 1
		,@llave = @llave
		,@origen = NULL
		,@applicationId = 11
		,@idEstado = NULL
		,@idContratoZona = NULL
		,@idUsuario = @idUsuario
		,@err = ''
		END


END

go

