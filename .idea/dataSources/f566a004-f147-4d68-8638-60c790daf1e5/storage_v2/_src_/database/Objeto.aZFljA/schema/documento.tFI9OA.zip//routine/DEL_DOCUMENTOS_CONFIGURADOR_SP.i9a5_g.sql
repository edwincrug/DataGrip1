-- =============================================
-- Author:		Sandra Gil Rosales
-- Create date: 23/09/2019
-- Description:Borrado logico de los tipos de documentos, clase, contrato o general
-- =============================================
/*
	Objetivo: Cambiar estatus activo por inactivo

	------TEST
		*- Testing...
	EXEC
	[documento].[DEL_DOCUMENTOS_CONFIGURADOR_SP]
		@data= '<Ids>
		<idDoc>9</idDoc>
		<prop>general</prop>
		</Ids>',
		@idUsuario = 2 ,
		@err = ''

	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición

*/
CREATE PROCEDURE [documento].[DEL_DOCUMENTOS_CONFIGURADOR_SP]
	@data				XML,
	@idUsuario			INT,
	@err				varchar(max) OUTPUT
		
AS
BEGIN
	
	DECLARE @msj		varchar(50) = '', 
			@VC_ErrorMessage	VARCHAR(4000)	= '',
			@VC_ThrowMessage	VARCHAR(100)	= 'An error has occured on [DEL_DOCUMENTOS_CONFIGURADOR_SP]:',
			@VC_ErrorSeverity	INT = 0,
			@VC_ErrorState		INT = 0,
			@status				int = 0,
			@activo				int = 0,
			@propiedad			nvarchar(10) = (SELECT I.N.value('.','nvarchar(10)')
												FROM @data.nodes('/Ids/prop') AS I(N))

	DECLARE @tbl_propiedades AS TABLE(
        idDocumento			INT
    )

	INSERT INTO @tbl_propiedades
    SELECT
        I.N.value('.','int')
        FROM @data.nodes('/Ids/idDoc') AS I(N);

/*********************************************BORRADO LOGICO EN TABLA DE PROPIEDADES *********************/
		BEGIN TRY
			BEGIN TRANSACTION DEL_DOCUMENTOS_CONFIGURADOR_SP			
			-- propiedad general
			IF @propiedad = 'general'
				BEGIN
					--DELETE FROM [documento].[DocumentoGeneral]
					UPDATE [documento].[DocumentoGeneral]
						SET [activo] = 0
						WHERE idDocumentoGeneral IN (SELECT idDocumento from @tbl_propiedades)
	
				set @status = 1;
				SET @msj = 'El tipo de documento se elimino correctamente';
				END 
			-- propiedad clase
			IF @propiedad = 'clase'
				BEGIN
				--DELETE FROM [documento].[DocumentoClase]
				UPDATE [documento].[DocumentoClase]
					SET [activo] = 0
					WHERE idDocumentoClase IN (SELECT idDocumento from @tbl_propiedades)

				set @status = 1;
				SET @msj = 'El tipo de documento se elimino correctamente';
				END 
			-- propiedad contrato
			IF @propiedad = 'contrato'
				BEGIN
				--DELETE FROM [documento].[DocumentoContrato]
				UPDATE [documento].[DocumentoContrato]
					SET [activo] = 0
					WHERE idDocumentoContrato IN (SELECT idDocumento from @tbl_propiedades) 
				set @status = 1;
				SET @msj = 'El tipo de documento se elimino correctamente';
				END 

			COMMIT TRANSACTION DEL_DOCUMENTOS_CONFIGURADOR_SP
		END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION DEL_DOCUMENTOS_CONFIGURADOR_SP
				SET @msj = 'Error al eliminar el tipo de documento';
				SET @VC_ErrorMessage = {
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage)
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
			END
		END CATCH
	SELECT 
		@msj				AS [Message], 
		@status				AS [Eliminado];

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

