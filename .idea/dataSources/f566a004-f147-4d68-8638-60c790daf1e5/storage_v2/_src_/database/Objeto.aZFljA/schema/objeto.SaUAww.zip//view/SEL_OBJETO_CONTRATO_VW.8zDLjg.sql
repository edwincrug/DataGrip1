-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener los campos de clase de los objetos(unidades)>
-- =============================================
-- SELECT 
    -- [rfcEmpresa]
    -- ,[idCliente]
    -- ,[numeroContrato]
    -- ,[idObjeto]
    -- ,[sustituto] 
    -- ,[GPS]
    -- ,[descripcion] 
    -- ,[verGPS] 
-- FROM [Objeto].[objeto].[SEL_OBJETO_CONTRATO_VW]
-- =============================================
CREATE VIEW [objeto].[SEL_OBJETO_CONTRATO_VW]
AS

SELECT 
    [rfcEmpresa]
    ,[idCliente]
    ,[numeroContrato]
    ,[idObjeto]
    ,[Sustituto] sustituto
    ,[GPS]
    ,[Descripcion] descripcion
    ,[VerGPS] verGPS
FROM
(
SELECT 
    OPC.[rfcEmpresa]
    ,OPC.[idCliente]
    ,OPC.[numeroContrato]
    ,OPC.[agrupador]
    ,OOPC.[valor]
    ,OOPC.[idObjeto]
FROM [Objeto].[objeto].[PropiedadContrato] OPC
INNER JOIN [Objeto].[objeto].[ObjetoPropiedadContrato] OOPC
    ON OPC.[rfcEmpresa] = OOPC.[rfcEmpresa]
    AND OPC.[idCliente] = OOPC.[idCliente]
    AND OPC.[numeroContrato] = OOPC.[numeroContrato]
    AND OPC.[idPropiedadContrato] = OOPC.[idPropiedadContrato]
WHERE OPC.[activo] = 1
    AND OOPC.[activo] = 1
) T
    PIVOT
    (	
        MAX(valor)
        FOR agrupador in ([Sustituto],[GPS],[Descripcion],[VerGPS])
    ) AS resultado

go

