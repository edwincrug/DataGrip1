
-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <24-06-2019>
-- Description:	< Borra multas que no tengan valor>
-- =============================================
/*
	*** Versionamiento 
	Fecha:01-07-2019 12:00		Autor Sandra Gil Rosales
	Descripción : se agrego la restriccion de borrar por un objeto especifico 
	 y por el momento solo aplicable para el tipo de documento Multa (por parametro)
	--2019

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [objeto].[DEL_OBJETOPROPIEDADCLASE_MULTA_SP]
	@idClase = 'Automovil',
	@idTipoObjeto = 92,
	@idObjeto = 82,
	@idUsuario = 2,
	@err = @salida OUTPUT;

*/
-- =============================================
CREATE PROCEDURE [objeto].[DEL_OBJETOPROPIEDADCLASE_MULTA_SP]
	@idClase			VARCHAR (10),
	@idTipoObjeto		INT,
	@idObjeto			INT,
	@idUsuario			int = null,
	-- solo aplicable para el tipo de documento Multa
	@nombreDocumento	VARCHAR(20) = 'Multa',
	@err				varchar(max) OUTPUT

AS
BEGIN
	-- SELECT *
	DELETE [Objeto].[documento].[DocumentoObjetoClase]
	FROM 
	[Objeto].[documento].[DocumentoObjetoClase] docClase
	LEFT JOIN [Objeto].[documento].[DocumentoClase] AS clase ON docClase.idDocumentoClase = clase.idDocumentoClase
	LEFT JOIN [Objeto].[objeto].[Objeto] AS objeto ON objeto.idObjeto = docClase.idObjeto
	WHERE clase.nombre = @nombreDocumento
	AND objeto.activo = 1 
	-- un objeto especifico 
	AND objeto.idClase = @idClase AND objeto.idTipoObjeto = @idTipoObjeto AND objeto.idObjeto = @idObjeto
	AND (docClase.valor IS NULL OR docClase.valor = '')

	DELETE  [documento].[CostoDocumentoClase]
	FROM [documento].[CostoDocumentoClase] AS costo
  LEFT JOIN [Objeto].[documento].[DocumentoObjetoClase] docClase ON docClase.idCostoDocumentoClase = costo.idCostoDocumentoClase
	AND docClase.idClase = costo.idClase AND  docClase.idTipoObjeto = costo.idTipoObjeto AND docClase.idObjeto = costo.idObjeto  
  LEFT JOIN [Objeto].[documento].[DocumentoClase] AS clase ON costo.idDocumentoClase = clase.idDocumentoClase
  WHERE clase.nombre = @nombreDocumento
	AND costo.activo = 1 
	-- un objeto especifico 
	AND costo.idClase = @idClase AND costo.idTipoObjeto = @idTipoObjeto AND costo.idObjeto = @idObjeto
	AND (docClase.valor IS NULL OR docClase.valor = '')

END

go

