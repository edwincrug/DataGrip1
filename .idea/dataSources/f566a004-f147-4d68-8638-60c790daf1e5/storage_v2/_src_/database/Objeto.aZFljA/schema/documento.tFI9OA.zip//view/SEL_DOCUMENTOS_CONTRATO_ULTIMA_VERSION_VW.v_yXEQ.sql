
-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener los campos de clase de los objetos(unidades)>
-- =============================================
-- SELECT 
    -- [idDocumentoContrato]
    -- ,[idClase]
    -- ,[idTipoObjeto]
    -- ,[idObjeto]
    -- ,[version]
    -- ,[idTipoDocumento]
    -- ,[idFileServer]
    -- ,[vigencia]
    -- ,[valor]
    -- ,[idUsuario]
    -- ,[fecha]
    -- ,[idCostoDocumentoContrato]
    -- ,[idEstado]
    -- ,[comentario]
-- FROM [documento].[SEL_DOCUMENTOS_CONTRATO_ULTIMA_VERSION_VW]
-- =============================================
CREATE VIEW [documento].[SEL_DOCUMENTOS_CONTRATO_ULTIMA_VERSION_VW]
AS

SELECT 
    DDOC.[idDocumentoContrato]
    ,DDOC.[idClase]
    ,DDOC.[idTipoObjeto]
    ,DDOC.[idObjeto]
    ,DDOC.[version]
    ,DDOC.[idTipoDocumento]
    ,DDOC.[idFileServer]
    ,DDOC.[vigencia]
    ,DDOC.[valor]
    ,DDOC.[idUsuario]
    ,DDOC.[fecha]
    ,DDOC.[idCostoDocumentoContrato]
    ,DDOC.[idEstado]
    ,DDOC.[comentario]
FROM [Objeto].[documento].[DocumentoObjetoContrato] DDOC
INNER JOIN 
(SELECT 
    idDocumentoContrato
    ,idClase
    ,idTipoObjeto
    ,idObjeto
    ,MAX(version) versionActual
FROM [Objeto].[documento].[DocumentoObjetoContrato]
GROUP BY idDocumentoContrato
    ,idClase
    ,idTipoObjeto
    ,idObjeto) DA
    ON DA.idDocumentoContrato = DDOC.idDocumentoContrato
    AND DA.idClase = DDOC.idClase
    AND DA.idTipoObjeto = DDOC.idTipoObjeto
    AND DA.idObjeto = DDOC.idObjeto
    AND DA.versionActual = DDOC.version
go

