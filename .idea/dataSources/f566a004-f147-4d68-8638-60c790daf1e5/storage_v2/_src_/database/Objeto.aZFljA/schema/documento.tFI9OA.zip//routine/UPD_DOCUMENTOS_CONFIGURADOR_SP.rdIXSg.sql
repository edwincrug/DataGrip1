-- =============================================
-- Author:		Sandra Gil Rosales
-- Create date: 23/09/2019
-- Description:Actualiza un tipo de documento, clase, contrato o general
-- =============================================
/*
	Objetivo: Inserta una módulo

	------TEST
		*- Testing...
	EXEC
	[documento].[UPD_DOCUMENTOS_CONFIGURADOR_SP]
		@idCliente= 92,
		@numeroContrato= "0001",
		@rfcEmpresa = 'ASE0508051B6',
		@propiedad= "general",
		@idDocumento = 9 ,
		@nombre	= 'Foto General',
		@idAgrupador = 'documentacion',
		@tiposPermitidos=	'.png',
		@obligatorio	=	0,
		@vigencia		=	0,
		@valor			=	0,
		@aplicaCosto	=	0,
		@orden			=	0,
		@idUsuario		=	0,
		@aplicaEstado	=	0,
		@aplicaComentario=	1,
		@err=''


	------ Versionamiento
	Fecha DD/MM/AA		Autor				Descrición

*/
CREATE PROCEDURE [documento].[UPD_DOCUMENTOS_CONFIGURADOR_SP]
	@idClase			varchar(13) = NULL ,
    @idCliente			INT = 0,
	@numeroContrato		nvarchar(10) = NULL,
	@rfcEmpresa			varchar(13) = NULL ,
	@propiedad			varchar(13),
	@idDocumento		INT,
	@nombre				varchar(100),
	@idAgrupador		varchar(50),
	@tiposPermitidos	varchar(100),
	@obligatorio		bit,
	@vigencia			bit,
	@valor				bit,
	@aplicaCosto		bit,
	@orden				int,
	@idUsuario			int,
	@aplicaEstado		bit,
	@aplicaComentario	bit,
	@err				varchar(max) OUTPUT
		
AS
BEGIN
	
	DECLARE @msj				varchar(50) = '', 
			@VC_ErrorMessage	VARCHAR(4000)	= '',
			@VC_ThrowMessage	VARCHAR(100)	= 'An error has occured on [UPD_DOCUMENTOS_CONFIGURADOR_SP]:',
			@VC_ErrorSeverity	INT = 0,
			@VC_ErrorState		INT = 0,
			@status				int = 0,
			@documentoId		int = 0,
			@activo				int = 1

/*********************************************  modificar tablas de propiedades *********************/

	IF NOT EXISTS(SELECT * FROM ( SELECT [idDocumentoClase] ,[nombre] ,'clase' AS prop
									FROM [Objeto].[documento].[DocumentoClase]
								  UNION ALL
									SELECT [idDocumentoGeneral] ,[nombre] ,'general'
									FROM [Objeto].[documento].[DocumentoGeneral]
								  UNION ALL
									  SELECT [idDocumentoContrato] ,[nombre] ,'contrato' 
									  FROM [Objeto].[documento].[DocumentoContrato] ) propiedades
					WHERE idDocumentoClase = @idDocumento)
		BEGIN
			SET @msj = 'El nombre de el tipo de documento no existe';
			SET @documentoId = 0
		END
	ELSE
		BEGIN TRY
			BEGIN TRANSACTION UPD_DOCUMENTOS_CONFIGURADOR_SP
			-- propiedad general
			IF @propiedad = 'general'
				BEGIN
					UPDATE [documento].[DocumentoGeneral]
					   SET [nombre] = @nombre
						  ,[idAgrupador] = @idAgrupador
						  ,[tiposPermitidos] = @tiposPermitidos
						  ,[obligatorio] = @obligatorio
						  ,[vigencia] = @vigencia
						  ,[valor] =  @valor
						  ,[aplicaCosto] = @aplicaCosto
						  ,[orden] = @orden
						  ,[idUsuario] = @idUsuario
						  ,[activo] = @activo
						  ,[aplicaEstado] = @aplicaEstado
						  ,[aplicaComentario] = @aplicaComentario
					 WHERE idDocumentoGeneral = @idDocumento
				set @status = 1;
				SET @documentoId = (SELECT idDocumentoGeneral FROM [documento].[DocumentoGeneral] WHERE idDocumentoGeneral = @idDocumento);
				SET @msj = 'El documento se actualizo correctamente';
				END 
			-- propiedad clase
			IF @propiedad = 'clase'
				BEGIN
					UPDATE [documento].[DocumentoClase]
					   SET [idClase] = @idClase
						  ,[nombre] = @nombre
						  ,[idAgrupador] = @idAgrupador
						  ,[tiposPermitidos] = @tiposPermitidos
						  ,[obligatorio] = @obligatorio
						  ,[vigencia] = @vigencia
						  ,[valor] = @valor
						  ,[aplicaCosto] = @aplicaCosto
						  ,[orden] = @orden
						  ,[idUsuario] = @idUsuario
						  ,[activo] = @activo
						  ,[aplicaEstado] = @aplicaEstado
						  ,[aplicaComentario] = @aplicaComentario
						  WHERE idDocumentoClase = @idDocumento 
				set @status = 1;
				SET @documentoId =  (SELECT idDocumentoClase FROM [documento].[DocumentoClase] WHERE idDocumentoClase = @idDocumento);
				SET @msj = 'El documento se actualizo correctamente';
				END 
			-- propiedad contrato
			IF @propiedad = 'contrato'
				BEGIN
				UPDATE [documento].[DocumentoContrato]
				   SET [idCliente] = @idCliente
						,[numeroContrato] = @numeroContrato
						  ,[nombre] = @nombre
						  ,[idAgrupador] = @idAgrupador
						  ,[tiposPermitidos] = @tiposPermitidos
						  ,[obligatorio] = @obligatorio
						  ,[vigencia] = @vigencia
						  ,[valor] = @valor
						  ,[aplicaCosto] = @aplicaCosto
						  ,[orden] = @orden
						  ,[idUsuario] = @idUsuario
						  ,[activo] = @activo
						  ,[aplicaEstado] = @aplicaEstado
						  ,[aplicaComentario] = @aplicaComentario
						  WHERE idDocumentoContrato = @idDocumento 

				set @status = 1;
				SET @documentoId =  (SELECT idDocumentoContrato FROM [documento].[DocumentoContrato] WHERE idDocumentoContrato = @idDocumento);
				SET @msj = 'El documento se actualizo correctamente';
				END 

			COMMIT TRANSACTION UPD_DOCUMENTOS_CONFIGURADOR_SP
		END TRY
		BEGIN CATCH
			SELECT  
				@VC_ErrorMessage	= ERROR_MESSAGE(),
				@VC_ErrorSeverity	= ERROR_SEVERITY(),
				@VC_ErrorState		= ERROR_STATE();
			BEGIN
				ROLLBACK TRANSACTION UPD_DOCUMENTOS_CONFIGURADOR_SP
				SET @msj = 'Error al actualizar el tipo documento';
				SET @VC_ErrorMessage = {
					fn CONCAT(
						@VC_ThrowMessage,
						@VC_ErrorMessage)
				}
				RAISERROR (
					@VC_ErrorMessage, 
					@VC_ErrorSeverity, 
					@VC_ErrorState
				);
			END
		END CATCH
	SELECT 
		@msj				AS [Message], 
		@status				AS [Actualizado],
		@documentoId		AS [DocumentoId];

    SET NOCOUNT OFF;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END
go

