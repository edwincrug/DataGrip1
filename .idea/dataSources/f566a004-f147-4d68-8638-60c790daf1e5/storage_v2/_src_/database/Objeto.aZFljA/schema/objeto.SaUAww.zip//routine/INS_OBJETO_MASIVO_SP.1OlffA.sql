-- ================================== ===========  
-- Author:  <Sandra Gil Rosales>  
-- Create date: <23-05-2019>  
-- sd  
-- Description: <Insercion de los objetos de forma masiva>  
/*  
 *- Testing...  
   
 EXEC [objeto].[INS_OBJETO_MASIVO_SP]  
  '<datos><propiedades><propiedad><id>0</id><idIns>0</idIns><idClase>Automovil</idClase><clase>general</clase><idProp>1</idProp><vigencia/><valor>Activo</valor><idZona>355</idZona></propiedad><propiedad><id>0</id><idIns>0</idIns><idClase>Automovil</idClas
e><clase>clase</clase><idProp>1</idProp><vigencia/><valor>888888884</valor><idZona>355</idZona></propiedad><propiedad><id>0</id><idIns>0</idIns><idClase>Automovil</idClase><clase>clase</clase><idProp>42</idProp><vigencia/><valor>12345</valor><idZo…ns>0</i
dIns><idClase>Automovil</idClase><clase>clase</clase><idProp>54</idProp><vigencia/><valor/><idZona>355</idZona></propiedad><propiedad><id>0</id><idIns>0</idIns><idClase>Automovil</idClase><clase>contrato</clase><idProp>10</idProp><vigencia/><valor/><idZon
a>355</idZona></propiedad></propiedades><objeto><id>0</id><idTipoObjeto>109</idTipoObjeto><rfcEmpresa>AAN910409135</rfcEmpresa><idCliente>221</idCliente><numeroContrato>205</numeroContrato><idZona>355</idZona><idCosto/></objeto></datos>',  
  'Concatenar',  
  6036,  
  null  
  
  */  
-- =============================================  
CREATE PROCEDURE [objeto].[INS_OBJETO_MASIVO_SP]   
 @propiedades   XML,  
 @idTipoAccion   nvarchar(50),  
 @idUsuario     int,  
 @err     varchar(max) OUTPUT  
  
AS  
BEGIN TRY  
BEGIN TRANSACTION  
  
print 1  
 SET @err = '';  
 DECLARE @idObjeto INT,  
   @idsObjetos VARCHAR(250)  

 declare @tbl_xml as TABLE(
	[xml] XML
   )
  
 DECLARE @tbl_propiedades AS TABLE(  
	_row				INT IDENTITY(1,1),  
	[index]				INT,  
	idClase				NVARCHAR(250),  
	clase				NVARCHAR(100),  
	idProp				INT,  
	valor               NVARCHAR(500),  
	vigencia			DATETIME,  
	id					INT ,
	validaVin			BIT NULL
 )  
  
 DECLARE @tbl_objetos AS TABLE(  
	_row                    INT IDENTITY(1,1),  
	[index]					INT,  
	id						INT,  
	idTipoObjeto			INT,  
	rfcEmpresa				NVARCHAR(20),  
	idCliente				INT,  
	numeroContrato          NVARCHAR(50),  
	idObjeto				INT,  
	idZona					INT,  
	idCosto					INT  ,
	validaVin				BIT NULL
 )  
  
  
 BEGIN    
     insert into @tbl_xml  (xml) values (@propiedades)
  -- tabla temporal para guardar los datos de el objeto  
     INSERT INTO @tbl_objetos ([index],  
         idTipoObjeto,  
         rfcEmpresa,  
         idCliente,  
                                 numeroContrato,  
         id,  
         idObjeto,  
         idZona,  
         idCosto)  
   
     SELECT  
   ParamValues.value('id[1]','int'),  
   ParamValues.value('idTipoObjeto[1]','nvarchar(250)'),  
   ParamValues.value('rfcEmpresa[1]','nvarchar(100)'),  
   ParamValues.value('idCliente[1]','int'),  
         ParamValues.value('numeroContrato[1]','nvarchar(500)'),  
   CASE WHEN @idTipoAccion = 'Actualizar' THEN ParamValues.value('idIns[1]','int')  
   ELSE 0 END  
   ,0  
   ,ParamValues.value('idZona[1]','int')  
   ,ParamValues.value('idCosto[1]','int')  
   --FROM @propiedades.nodes('datos/objeto') AS ParamValues(col)  
   FROM @tbl_xml
		CROSS APPLY xml.nodes('/datos/objeto') t(ParamValues)
   
  -- tabla temporal para guardar las propiedades  
     INSERT INTO @tbl_propiedades([index],  
         idClase,  
         clase,  
         idProp,   
         valor,  
         vigencia,  
         id)  
   
     SELECT  
	   ParamValues.col.value('id[1]','int'),  
	   ParamValues.col.value('idClase[1]','nvarchar(250)'),  
	   ParamValues.col.value('clase[1]','nvarchar(100)'),  
	   ParamValues.col.value('idProp[1]','int'),  
			 ParamValues.col.value('valor[1]','nvarchar(500)'),  
	   ParamValues.col.value('vigencia[1]','datetime'),  
	   CASE WHEN @idTipoAccion = 'Actualizar' THEN ParamValues.col.value('idIns[1]','int')  
	   ELSE 0 END  
     FROM @propiedades.nodes('datos/propiedades/propiedad') AS ParamValues(col)  
	 WHERE ParamValues.col.value('clase[1]','nvarchar(250)') != 'Tipo Objeto' 
   
	DECLARE @row INT = 1, @contador int;
	
	DECLARE @vinesTabla TABLE
	(
		id INT IDENTITY(1,1),  
		vin varchar(100),
		[index] int,
		idObjeto int
	)

	DECLARE @agrupador AS VARCHAR(100)

	INSERT INTO @vinesTabla
	SELECT 
		valor,
		[index],
		id
	FROM @tbl_propiedades where idProp = 1

	DECLARE @propiedad NVARCHAR(250);  
	DECLARE @valor NVARCHAR(250);  
	DECLARE @idClaseActual NVARCHAR(250);  
	DECLARE @idTipoValor NVARCHAR(250);  
	DECLARE @idPropiedad INT;  
	DECLARE @id    INT;
   
  --select * from @tbl_objetos  
  --select * from @tbl_propiedades  
   
     DECLARE @cont  INT = 1,  
    @contObj INT = 1,  
    @index  INT = 0  

	DECLARE @nombreContrato varchar (max), @idObjetoVin int
   
  --SI EL TIPO DE ACCION ES REEMPLAZAR, todos los objetos se borraran, creando nuevos objetos  
  IF (@idTipoAccion = 'Reemplazar')  
  BEGIN  
   --BORRAMOS PROPIEDADES  
   DELETE pro  
   FROM objeto.ObjetoPropiedadGeneral pro  
   INNER JOIN objeto.Objeto o on pro.idObjeto = o.idObjeto  
   WHERE o.idObjeto = @idObjeto  
   DELETE pro  
   FROM objeto.ObjetoPropiedadClase pro  
   INNER JOIN objeto.Objeto o on pro.idObjeto = o.idObjeto  
   WHERE o.idObjeto = @idObjeto  
   DELETE pro  
   FROM objeto.ObjetoPropiedadContrato pro  
   INNER JOIN objeto.Objeto o on pro.idObjeto = o.idObjeto  
   WHERE o.idObjeto = @idObjeto  
   ----BORRAMOS DOCUMENTOS Y COSTOS   
   --DELETE FROM [documento].[DocumentoObjetoClase]  
   --DELETE FROM [documento].[DocumentoObjetoContrato]  
   --DELETE FROM [documento].[DocumentoObjetoGeneral]  
   
   --DELETE FROM [documento].[CostoDocumentoClase]  
   --DELETE FROM [documento].[CostoDocumentoContrato]  
   --DELETE FROM [documento].[CostoDocumentoGeneral]  
   
   --BORRAMOS EL OBJETO  
   DELETE FROM objeto.Objeto WHERE idObjeto = @idObjeto  
   -- Asignamos el comportamiento de 'Concatenar para que se guarden los nuevos objetos'  
    
   SET @idTipoAccion = 'Concatenar'  
  END  
   
  
  
  --ACCION ACTUALIZAR  
  IF(@idTipoAccion = 'ACTUALIZAR')  
  BEGIN     
	IF ((SELECT TOP 1 idClase FROM @tbl_propiedades ) = 'Automovil')
	BEGIN

		SET @contador = (select count(*) from @vinesTabla)
		WHILE(@row <= @contador)
		BEGIN
		------------ VALIDAMOS QUE SI UN VIN EXISTE SEA DEL OBJETO QUE SE VA A ACTUALIZAR, DE LO CONTRARIO NO SE VA A ACTUALIZAR ------------
			IF EXISTS(SELECT 
						* 
					   FROM objeto.ObjetoPropiedadClase OPC
							INNER JOIN objeto.PropiedadClase P on P.idPropiedadClase = OPC.idPropiedadClase
							INNER JOIN objeto.Objeto O ON O.idObjeto = OPC.idObjeto
							INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = O.idObjeto
						WHERE O.activo = 1
							  AND CO.activo = 1
							  AND CO.idObjetoEstatus = 'ACT'
							  AND OPC.idPropiedadClase = 1
							  AND P.agrupador = 'VIN'
							  AND OPC.valor = (SELECT vin FROM @vinesTabla VT WHERE id = @row))
			BEGIN
				IF EXISTS(SELECT 
								1 
							FROM objeto.ObjetoPropiedadClase PC
								INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
								INNER JOIN objeto.PropiedadClase p on p.idPropiedadClase = PC.idPropiedadClase
								INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
							WHERE PC.valor = (SELECT vin FROM @vinesTabla VT WHERE id = @row)
								AND CO.rfcEmpresa = (SELECT 
														rfcEmpresa 
													 FROM @vinesTabla VT 
														  INNER JOIN @tbl_objetos OB ON OB.[index] = VT.[index]
													 WHERE VT.id = @row)
								AND CO.idCliente = (SELECT 
														idCliente 
													 FROM @vinesTabla VT 
														  INNER JOIN @tbl_objetos OB ON OB.[index] = VT.[index]
													 WHERE VT.id = @row)
								AND CO.numeroContrato = (SELECT 
														numeroContrato 
													 FROM @vinesTabla VT 
														  INNER JOIN @tbl_objetos OB ON OB.[index] = VT.[index]
													 WHERE VT.id = @row)
								AND CO.activo = 1
								AND O.activo = 1
								AND p.agrupador = 'VIN'
								AND CO.idObjetoEstatus = 'ACT'
								and co.idTipoObjeto = (SELECT 
														idTipoObjeto 
													 FROM @vinesTabla VT 
														  INNER JOIN @tbl_objetos OB ON OB.[index] = VT.[index]
													 WHERE VT.id = @row)
								and co.idObjeto = (SELECT 
														VT.idObjeto 
													 FROM @vinesTabla VT 
														  INNER JOIN @tbl_objetos OB ON OB.[index] = VT.[index]
													 WHERE VT.id = @row))
				BEGIN
					update @tbl_propiedades SET validaVin = 1 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
					update @tbl_objetos SET validaVin = 1 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
				END
				ELSE
				BEGIN
					SELECT 
						@idObjetoVin = OPC.idObjeto,
						@nombreContrato = C.nombre
					FROM objeto.ObjetoPropiedadClase OPC
						INNER JOIN objeto.PropiedadClase P on P.idPropiedadClase = OPC.idPropiedadClase
						INNER JOIN objeto.Objeto O ON O.idObjeto = OPC.idObjeto
						INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = O.idObjeto
						INNER JOIN Cliente.cliente.Contrato C ON C.numeroContrato = CO.numeroContrato AND C.idCliente = CO.idCliente AND C.rfcEmpresa = CO.rfcEmpresa
					WHERE O.activo = 1
							AND CO.activo = 1
							AND CO.idObjetoEstatus = 'ACT'
							AND OPC.idPropiedadClase = 1
							AND P.agrupador = 'VIN'
							AND OPC.valor = (SELECT vin FROM @vinesTabla VT WHERE id = @row)
					update @tbl_propiedades SET validaVin = 0 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
					update @tbl_objetos SET validaVin = 0 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
					SET @err = 'Este vin ya esta registrado: ' + (SELECT vin FROM @vinesTabla WHERE id = @row)+ '. En el contrato: '+@nombreContrato+' con el idObjeto: '+CONVERT(VARCHAR(50),@idObjetoVin)
				END
			END
			ELSE
			BEGIN
				update @tbl_propiedades SET validaVin = 1 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
				update @tbl_objetos SET validaVin = 1 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
			
			END
		
			SET @row = @row + 1
		END

		DELETE FROM objeto.objeto.ObjetoPropiedadClase WHERE idObjeto in( select distinct id from @tbl_propiedades WHERE validaVin = 1)  
   
		WHILE((SELECT COUNT(*) FROM @tbl_objetos WHERE validaVin = 1)>= @contObj)  
		BEGIN  
      
		--SE ACTUALIZA LA TABLA OBJETO  
		UPDATE [Cliente].[contrato].[Objeto] SET idContratoZona = (SELECT idZona from @tbl_objetos WHERE _row = @contObj AND validaVin = 1)  
		WHERE idObjeto =(select id from @tbl_propiedades WHERE _row = @contObj AND validaVin = 1)  
   
		SET @contObj = @contObj + 1  
		END  
   
		-- empezamos la insercion de las propiedades  
		WHILE((SELECT COUNT(*) FROM @tbl_propiedades WHERE validaVin = 1)>= @cont)  
		BEGIN    
   
		-- buscar en la union de  las tablas de propiedades, para identificar el id a insertar  
		--IF(@index != (Select [index] from @tbl_propiedades WHERE _row = @cont))  
		SELECT   
		@id = id,  
		@propiedad = clase,   
		@idPropiedad = idProp,  
		@idClaseActual = idClase  
		FROM @tbl_propiedades prop  
		WHERE _row = @cont   
			and validaVin = 1
  
		IF (@propiedad = 'general')  
		BEGIN  
			SELECT @idTipoValor = (SELECT TOP 1 * FROM (  
					SELECT idTipoValor   
					FROM objeto.PropiedadGeneral  
					WHERE idPropiedadGeneral = prop.idProp  
					) as tbl1  
					),  
			@valor = ( SELECT  idPropiedadGeneral from objeto.PropiedadGeneral WHERE valor = prop.valor)  
			FROM @tbl_propiedades prop  
			WHERE _row = @cont  
			and validaVin = 1
		END  
		ELSE IF (@propiedad = 'clase')  
		BEGIN  
			SELECT @idTipoValor = (SELECT TOP 1 * FROM (  
					SELECT idTipoValor   
					FROM objeto.PropiedadClase  
					WHERE idPropiedadClase = prop.idProp  
					) as tbl1  
					),  
			@valor = ( SELECT  idPropiedadClase from objeto.PropiedadClase WHERE valor = prop.valor)  
			FROM @tbl_propiedades prop  
			WHERE _row = @cont   
			and validaVin = 1
		END  
		ELSE  
		BEGIN  
			SELECT @idTipoValor = (SELECT TOP 1 * FROM (  
					SELECT idTipoValor   
					FROM objeto.PropiedadContrato  
					WHERE idPropiedadContrato = prop.idProp  
					) as tbl1  
					),  
			@valor = ( SELECT  idPropiedadContrato from objeto.PropiedadContrato WHERE valor = prop.valor)  
			FROM @tbl_propiedades prop  
			WHERE _row = @cont  
			and validaVin = 1
		END  
		-- termino de la union de las tablas     
   
		IF(@propiedad = 'general')  
		BEGIN  
			IF (@idTipoValor = 'Unico')  
			BEGIN  
			update pro   
			set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont and validaVin = 1)  
			from objeto.ObjetoPropiedadGeneral pro  
			where  
			pro.idObjeto = @id  
			and idPropiedadGeneral = @idPropiedad  
			END   
			ELSE IF (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
			BEGIN  
			--EN CASO DE QUE SEA CATALOGO O AGRUPADOR  
			--buscamos el id de la propiedad con base al nombre del agrupador  
			select   
			@idPropiedad = (SELECT idPropiedadGeneral FROM objeto.PropiedadGeneral   
			WHERE valor = @valor AND agrupador =  @propiedad AND idTipoValor = @idTipoValor )  
			from @tbl_propiedades where _row = @cont
			and validaVin = 1
   
			update pro   
			set  
			pro.idPropiedadGeneral = @valor,  
			pro.valor = ''  
			from objeto.ObjetoPropiedadGeneral pro  
			where  
			pro.idObjeto= @id  
			and idPropiedadGeneral = @idPropiedad  
			END  
		END  
		-- acciones para tabla objeto propiedadesClase  
		ELSE IF(@propiedad = 'clase')  
		BEGIN  
			IF (@idTipoValor = 'Unico')  
			BEGIN  
			IF( @idPropiedad = 42)  
			BEGIN   
			IF NOT EXISTS(SELECT 1 FROM objeto.objeto.ObjetoPropiedadClase where idObjeto = @id and idPropiedadClase = 42)  
			BEGIN  
			INSERT INTO objeto.ObjetoPropiedadClase (idClase  
			,idPropiedadClase  
			,idTipoObjeto  
			,idObjeto  
			,valor  
			,idUsuario  
			,activo  
			)  
			SELECT  
			@idClaseActual  
			,42  
			,(SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] and validaVin = 1)  
			,@id  
			,18  
			,@idUsuario  
			,1  
			FROM @tbl_propiedades AS prop  
			WHERE _row = @cont  
			and validaVin = 1
			END  
   
			INSERT INTO [Objeto].[documento].[DocumentoObjetoClase]  
			SELECT  
			18,  
			(SELECT TOP 1 idClase FROM @tbl_objetos WHERE [index] = prop.[index] and validaVin = 1),  
			(SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] and validaVin = 1)  
			,id  
			,CASE  
				WHEN NOT EXISTS (SELECT max([version]) FROM [Objeto].[documento].[DocumentoObjetoClase] WHERE idDocumentoClase = 18 AND idObjeto = @id) THEN 0  
				WHEN (SELECT max([version]) FROM [Objeto].[documento].[DocumentoObjetoClase] WHERE idDocumentoClase = 18 AND idObjeto = @id) IS NULL THEN 0  
				ELSE (SELECT max([version]) FROM [Objeto].[documento].[DocumentoObjetoClase] WHERE idDocumentoClase = 18 AND idObjeto = @id) + 1 END  
			,'.jpg'  
			,(SELECT idDocumento FROM Common.configuracion.DocumentoDefault WHERE descripcion = 'placa')  
			,NULL  
			,valor  
			,@idUsuario  
			,GETDATE()  
			,NULL  
			,NULL  
			,NULL  
			FROM @tbl_propiedades AS prop  
			WHERE _row = @cont  
			and validaVin = 1
			END  
			ELSE  
			BEGIN  
			IF NoT EXISTS(SELECT 1 FROM objeto.objeto.ObjetoPropiedadClase where idObjeto = @id and idPropiedadClase = @idPropiedad)  
			BEGIN  
			INSERT INTO objeto.ObjetoPropiedadClase  
			SELECT  
				@idClaseActual  
				,@idPropiedad  
				,(SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] and validaVin = 1)  
				,@id  
				,(select valor FROM @tbl_propiedades where _row = @cont and validaVin = 1)  
				,@idUsuario  
				,1  
			FROM @tbl_propiedades AS prop  
			WHERE _row = @cont  
			and validaVin = 1
			END  
			END  
			END  
			ELSE IF (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
			BEGIN   
   
			SET @AGRUPADOR = (SELECT agrupador FROM objeto.propiedadClase WHERE idPropiedadClase = @valor)  
        
			SELECT  @idClaseActual,@idTipoValor, @agrupador, @valor valor  
   
			IF NOT EXISTS(SELECT 1 FROM objeto.objeto.ObjetoPropiedadClase WHERE idObjeto = @id and idPropiedadClase = @idPropiedad)  
			BEGIN  
			INSERT INTO objeto.objeto.ObjetoPropiedadClase  
			SELECT  
			@idClaseActual  
			,@valor  
			,(SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] and validaVin = 1)  
			,@id  
			,''  
			,@idUsuario  
			,1  
			FROM @tbl_propiedades AS prop  
			WHERE _row = @cont  
			and validaVin = 1
			END  
			END  
		END  
		-- acciones para tabla objeto propiedadesContrato  
		ELSE IF(@propiedad = 'contrato')  
		BEGIN  
			IF (@idTipoValor = 'Unico')  
			BEGIN  
			update pro   
			set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont and validaVin = 1)  
			from objeto.ObjetoPropiedadContrato pro  
			where  
			pro.idObjeto = @id--@idObjeto--AQUI TENIA ESTE VALOR HAY QUE VALIDAR SI ES CORRECTO O NO  
			and idPropiedadContrato = @idPropiedad  
        
			END  
			ELSE IF (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
			BEGIN  
			--EN CASO DE QUE SEA CATALOGO O AGRUPADOR  
			--buscamos el id de la propiedad con base al nombre del agrupador  
			SELECT @idPropiedad = (SELECT idPropiedadContrato FROM objeto.PropiedadContrato  
			WHERE valor = @valor AND agrupador =  @propiedad    
			AND idTipoValor = @idTipoValor)  
			FROM @tbl_propiedades where _row = @cont   and validaVin = 1
   
			UPDATE pro   
			SET pro.idPropiedadContrato = @valor,  
			pro.valor = ''  
			FROM objeto.ObjetoPropiedadContrato pro  
			WHERE  
			pro.idObjeto = @id--@idObjeto--AQUI TENIA ESTE VALOR HAY QUE VALIDAR SI ES CORRECTO O NO  
			and idPropiedadContrato = @idPropiedad  
			END  
		END  
		SET @cont = @cont + 1  
		END  
  


	END
	ELSE
	BEGIN
		
	   DELETE FROM objeto.objeto.ObjetoPropiedadClase WHERE idObjeto in( select distinct id from @tbl_propiedades)  
   
	   WHILE((SELECT COUNT(*) FROM @tbl_objetos)>= @contObj)  
	   BEGIN  
      
		--SE ACTUALIZA LA TABLA OBJETO  
		UPDATE [Cliente].[contrato].[Objeto] SET idContratoZona = (SELECT idZona from @tbl_objetos WHERE _row = @contObj)  
		WHERE idObjeto =(select id from @tbl_propiedades WHERE _row = @contObj)  
   
		SET @contObj = @contObj + 1  
	   END  
   
	   -- empezamos la insercion de las propiedades  
	   WHILE((SELECT COUNT(*) FROM @tbl_propiedades)>= @cont)  
	   BEGIN   
   
		-- buscar en la union de  las tablas de propiedades, para identificar el id a insertar  
		--IF(@index != (Select [index] from @tbl_propiedades WHERE _row = @cont))  
		SELECT   
		@id = id,  
		@propiedad = clase,   
		@idPropiedad = idProp,  
		@idClaseActual = idClase  
		FROM @tbl_propiedades prop  
		WHERE _row = @cont   
  
		IF (@propiedad = 'general')  
		BEGIN  
		 SELECT @idTipoValor = (SELECT TOP 1 * FROM (  
				 SELECT idTipoValor   
				 FROM objeto.PropiedadGeneral  
				 WHERE idPropiedadGeneral = prop.idProp  
				 ) as tbl1  
				 ),  
		 @valor = ( SELECT  idPropiedadGeneral from objeto.PropiedadGeneral WHERE valor = prop.valor)  
		 FROM @tbl_propiedades prop  
		 WHERE _row = @cont   
		END  
		ELSE IF (@propiedad = 'clase')  
		BEGIN  
		 SELECT @idTipoValor = (SELECT TOP 1 * FROM (  
				 SELECT idTipoValor   
				 FROM objeto.PropiedadClase  
				 WHERE idPropiedadClase = prop.idProp  
				 ) as tbl1  
				 ),  
		 @valor = ( SELECT  idPropiedadClase from objeto.PropiedadClase WHERE valor = prop.valor)  
		 FROM @tbl_propiedades prop  
		 WHERE _row = @cont   
		END  
		ELSE  
		BEGIN  
		 SELECT @idTipoValor = (SELECT TOP 1 * FROM (  
				 SELECT idTipoValor   
				 FROM objeto.PropiedadContrato  
				 WHERE idPropiedadContrato = prop.idProp  
				 ) as tbl1  
				 ),  
		 @valor = ( SELECT  idPropiedadContrato from objeto.PropiedadContrato WHERE valor = prop.valor)  
		 FROM @tbl_propiedades prop  
		 WHERE _row = @cont   
		END  
		-- termino de la union de las tablas     
   
		IF(@propiedad = 'general')  
		BEGIN  
		 IF (@idTipoValor = 'Unico')  
		 BEGIN  
		  update pro   
		   set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont)  
		  from objeto.ObjetoPropiedadGeneral pro  
		  where  
		   pro.idObjeto = @id  
		   and idPropiedadGeneral = @idPropiedad  
		 END   
		 ELSE IF (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
		 BEGIN  
		  --EN CASO DE QUE SEA CATALOGO O AGRUPADOR  
		  --buscamos el id de la propiedad con base al nombre del agrupador  
		  select   
		   @idPropiedad = (SELECT idPropiedadGeneral FROM objeto.PropiedadGeneral   
		   WHERE valor = @valor AND agrupador =  @propiedad AND idTipoValor = @idTipoValor )  
		  from @tbl_propiedades where _row = @cont  
   
		  update pro   
		   set  
			pro.idPropiedadGeneral = @valor,  
			pro.valor = ''  
		  from objeto.ObjetoPropiedadGeneral pro  
		  where  
		   pro.idObjeto= @id  
		   and idPropiedadGeneral = @idPropiedad  
		 END  
		END  
		-- acciones para tabla objeto propiedadesClase  
		ELSE IF(@propiedad = 'clase')  
		BEGIN  
		 IF (@idTipoValor = 'Unico')  
		 BEGIN  
		  IF( @idPropiedad = 42)  
		  BEGIN   
		   IF NOT EXISTS(SELECT 1 FROM objeto.objeto.ObjetoPropiedadClase where idObjeto = @id and idPropiedadClase = 42)  
		   BEGIN  
			INSERT INTO objeto.ObjetoPropiedadClase (idClase  
			,idPropiedadClase  
			,idTipoObjeto  
			,idObjeto  
			,valor  
			,idUsuario  
			,activo  
			)  
			SELECT  
			@idClaseActual  
			,42  
			,(SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
			,@id  
			,18  
			,@idUsuario  
			,1  
			FROM @tbl_propiedades AS prop  
			WHERE _row = @cont  
		   END  
   
		   INSERT INTO [Objeto].[documento].[DocumentoObjetoClase]  
		   SELECT  
			18,  
			(SELECT TOP 1 idClase FROM @tbl_objetos WHERE [index] = prop.[index]),  
			(SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
			,id  
			,CASE  
			 WHEN NOT EXISTS (SELECT max([version]) FROM [Objeto].[documento].[DocumentoObjetoClase] WHERE idDocumentoClase = 18 AND idObjeto = @id) THEN 0  
			 WHEN (SELECT max([version]) FROM [Objeto].[documento].[DocumentoObjetoClase] WHERE idDocumentoClase = 18 AND idObjeto = @id) IS NULL THEN 0  
			 ELSE (SELECT max([version]) FROM [Objeto].[documento].[DocumentoObjetoClase] WHERE idDocumentoClase = 18 AND idObjeto = @id) + 1 END  
			,'.jpg'  
			,(SELECT idDocumento FROM Common.configuracion.DocumentoDefault WHERE descripcion = 'placa')  
			,NULL  
			,valor  
			,@idUsuario  
			,GETDATE()  
			,NULL  
			,NULL  
			,NULL  
		   FROM @tbl_propiedades AS prop  
		   WHERE _row = @cont  
		  END  
		  ELSE  
		  BEGIN  
		   IF NoT EXISTS(SELECT 1 FROM objeto.objeto.ObjetoPropiedadClase where idObjeto = @id and idPropiedadClase = @idPropiedad)  
		   BEGIN  
			INSERT INTO objeto.ObjetoPropiedadClase  
			SELECT  
			 @idClaseActual  
			 ,@idPropiedad  
			 ,(SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
			 ,@id  
			 ,(select valor FROM @tbl_propiedades where _row = @cont)  
			 ,@idUsuario  
			 ,1  
			FROM @tbl_propiedades AS prop  
			WHERE _row = @cont  
		   END  
		  END  
		 END  
		 ELSE IF (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
		 BEGIN    
		  SET @AGRUPADOR = (SELECT agrupador FROM objeto.propiedadClase WHERE idPropiedadClase = @valor)  
        
		  SELECT  @idClaseActual,@idTipoValor, @agrupador, @valor valor  
   
		  IF NOT EXISTS(SELECT 1 FROM objeto.objeto.ObjetoPropiedadClase WHERE idObjeto = @id and idPropiedadClase = @idPropiedad)  
		  BEGIN  
		   INSERT INTO objeto.objeto.ObjetoPropiedadClase  
		   SELECT  
			@idClaseActual  
			,@valor  
			,(SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
			,@id  
			,''  
			,@idUsuario  
			,1  
		   FROM @tbl_propiedades AS prop  
		   WHERE _row = @cont  
		  END  
		 END  
		END  
		-- acciones para tabla objeto propiedadesContrato  
		ELSE IF(@propiedad = 'contrato')  
		BEGIN  
		 IF (@idTipoValor = 'Unico')  
		 BEGIN  
		  update pro   
		   set pro.valor = (select valor FROM @tbl_propiedades where _row = @cont)  
		  from objeto.ObjetoPropiedadContrato pro  
		  where  
		   pro.idObjeto = @id--@idObjeto--AQUI TENIA ESTE VALOR HAY QUE VALIDAR SI ES CORRECTO O NO  
		   and idPropiedadContrato = @idPropiedad  
        
		 END  
		 ELSE IF (@idTipoValor = 'Catalogo' or @idTipoValor = 'Agrupador')  
		 BEGIN  
		  --EN CASO DE QUE SEA CATALOGO O AGRUPADOR  
		  --buscamos el id de la propiedad con base al nombre del agrupador  
		  SELECT @idPropiedad = (SELECT idPropiedadContrato FROM objeto.PropiedadContrato  
		  WHERE valor = @valor AND agrupador =  @propiedad    
		   AND idTipoValor = @idTipoValor)  
		  FROM @tbl_propiedades where _row = @cont  
   
		  UPDATE pro   
		  SET pro.idPropiedadContrato = @valor,  
		   pro.valor = ''  
		  FROM objeto.ObjetoPropiedadContrato pro  
		  WHERE  
		   pro.idObjeto = @id--@idObjeto--AQUI TENIA ESTE VALOR HAY QUE VALIDAR SI ES CORRECTO O NO  
		   and idPropiedadContrato = @idPropiedad  
		 END  
		END  
		SET @cont = @cont + 1  
	   END  
	END
  END  
  --TERMINA ACCION ACTUALIZAR  



  --ACCION CONCATENAR  
  IF(@idTipoAccion = 'Concatenar')  
  BEGIN  

	DECLARE @propiedadC NVARCHAR(250);  
	DECLARE @valorC NVARCHAR(250);  
	DECLARE @idClaseActualC NVARCHAR(250);  
	DECLARE @idTipoValorC NVARCHAR(250);  
	DECLARE @idPropiedadC INT;  
	DECLARE @idC    INT;  

	IF ((SELECT TOP 1 idClase FROM @tbl_propiedades ) = 'Automovil')
	BEGIN

		SET @contador = (select count(*) from @vinesTabla)
		WHILE(@row <= @contador)
		BEGIN
			IF EXISTS(SELECT 
						* 
					   FROM objeto.ObjetoPropiedadClase OPC
							INNER JOIN objeto.PropiedadClase P on P.idPropiedadClase = OPC.idPropiedadClase
							INNER JOIN objeto.Objeto O ON O.idObjeto = OPC.idObjeto
							INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = O.idObjeto
						WHERE O.activo = 1
							  AND CO.activo = 1
							  AND CO.idObjetoEstatus = 'ACT'
							  AND OPC.idPropiedadClase = 1
							  AND P.agrupador = 'VIN'
							  AND OPC.valor = (SELECT vin FROM @vinesTabla VT WHERE id = @row))
			BEGIN
				update @tbl_propiedades SET validaVin = 0 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
				update @tbl_objetos SET validaVin = 0 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)

				SELECT 
					@idObjetoVin = OPC.idObjeto,
					@nombreContrato = C.nombre
				FROM objeto.ObjetoPropiedadClase OPC
					INNER JOIN objeto.PropiedadClase P on P.idPropiedadClase = OPC.idPropiedadClase
					INNER JOIN objeto.Objeto O ON O.idObjeto = OPC.idObjeto
					INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = O.idObjeto
					INNER JOIN Cliente.cliente.Contrato C ON C.numeroContrato = CO.numeroContrato AND C.idCliente = CO.idCliente AND C.rfcEmpresa = CO.rfcEmpresa
				WHERE O.activo = 1
						AND CO.activo = 1
						AND CO.idObjetoEstatus = 'ACT'
						AND OPC.idPropiedadClase = 1
						AND P.agrupador = 'VIN'
						AND OPC.valor = (SELECT vin FROM @vinesTabla VT WHERE id = @row)
				SET @err = 'Este vin ya esta registrado: ' + (SELECT vin FROM @vinesTabla WHERE id = @row)+ '. En el contrato: '+@nombreContrato+' con el idObjeto: '+CONVERT(VARCHAR(50),@idObjetoVin)
			END
			ELSE
			BEGIN
				update @tbl_propiedades SET validaVin = 1 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
				update @tbl_objetos SET validaVin = 1 WHERE [index] = (SELECT [index] FROM @vinesTabla VT WHERE id = @row)
			
			END
		
			SET @row = @row + 1
		END

	   WHILE((SELECT COUNT(*) FROM @tbl_objetos WHERE validaVin = 1)>= @contObj)  
	   BEGIN  
		-- Insertamos el Objeto  
		INSERT INTO [objeto].[Objeto]  
		  ([idClase]  
			,[idTipoObjeto]  
			,[idUsuario]  
			,[activo])  
		 SELECT  
		  (SELECT TOP 1 idClase FROM @tbl_propiedades ),  
		  idTipoObjeto,  
		  @idUsuario,  
		  1  
		 FROM @tbl_objetos  
		 WHERE _row = @contObj 
				AND validaVin = 1
   
		SET @idObjeto = @@IDENTITY  
   
		SET @idsObjetos = ISNULL(@idsObjetos, '') + ',' + CAST(@idObjeto AS VARCHAR(50))  
   
		-- Lo damos de alta en un contrato  
		INSERT INTO [Cliente].[contrato].[Objeto]  
		   ([rfcEmpresa]  
		   ,[idCliente]  
		   ,[numeroContrato]  
		   ,[idClase]  
		   ,[idTipoObjeto]  
		   ,[idObjeto]  
		   ,[idContratoZona]  
		   ,[idObjetoEstatus]  
		   ,[idUsuario]  
		   ,[activo]  
		   ,[idCentroCosto])  
		 SELECT  
		  rfcEmpresa,  
		  idCliente,  
		  numeroContrato,  
		  (SELECT TOP 1 idClase FROM @tbl_propiedades ),  
		  idTipoObjeto,  
		  @idObjeto,  
		  idZona,  
		  'ACT',  
		  @idUsuario,  
		  1,  
		  idCosto  
		 FROM @tbl_objetos  
		 WHERE _row = @contObj  
			   AND validaVin = 1
   
		 UPDATE @tbl_objetos  
		  SET idObjeto = @idObjeto  
		 WHERE _row = @contObj 
			   AND validaVin = 1
      
   
		SET @contObj = @contObj + 1  
	   END--TERMINA WHILE  
   
	   -- empezamos la insercion de las propiedades  
	   WHILE((SELECT COUNT(*) FROM @tbl_propiedades WHERE validaVin = 1)>= @cont)  
	   BEGIN  
		-- buscar en la union de  las tablas de propiedades, para identificar el id a insertar  
		SELECT   
		@idC = id,  
		@propiedadC = clase,   
		@idPropiedadC = idProp,  
		@idClaseActualC = idClase  
		FROM @tbl_propiedades prop  
		WHERE _row = @cont   
			  AND validaVin = 1
  
		IF (@propiedadC = 'general')  
		BEGIN  
		 SELECT @idTipoValorC = (SELECT TOP 1 * FROM (  
				 SELECT idTipoValor   
				 FROM objeto.PropiedadGeneral  
				 WHERE idPropiedadGeneral = prop.idProp  
				 ) as tbl1  
				 ),  
		 @valorC = ( SELECT  idPropiedadGeneral from objeto.PropiedadGeneral WHERE valor = prop.valor)  
		 FROM @tbl_propiedades prop  
		 WHERE _row = @cont   
			   AND validaVin = 1
		END  
		ELSE IF (@propiedadC = 'clase')  
		BEGIN  
		 SELECT @idTipoValorC = (SELECT TOP 1 * FROM (  
				 SELECT idTipoValor   
				 FROM objeto.PropiedadClase  
				 WHERE idPropiedadClase = prop.idProp  
				 ) as tbl1  
				 ),  
		 @valorC = ( SELECT idPropiedadClase from objeto.PropiedadClase WHERE valor = prop.valor)  
		 FROM @tbl_propiedades prop  
		 WHERE _row = @cont  
			   AND validaVin = 1
		END  
		ELSE  
		BEGIN  
		 SELECT @idTipoValorC = (SELECT TOP 1 * FROM (  
				 SELECT idTipoValor   
				 FROM objeto.PropiedadContrato  
				 WHERE idPropiedadContrato = prop.idProp  
				 ) as tbl1  
				 ),  
		 @valorC = ( SELECT  idPropiedadContrato from objeto.PropiedadContrato WHERE valor = prop.valor)  
		 FROM @tbl_propiedades prop  
		 WHERE _row = @cont   
			   AND validaVin = 1
		END  
		-- termino de la union de las tablas     
   
		IF(@propiedadC = 'general')  
		BEGIN  
		 INSERT INTO objeto.ObjetoPropiedadGeneral  
		 SELECT  
		  @idPropiedadC,  
		  (SELECT TOP 1 idClase FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		  (SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		  (SELECT TOP 1 idObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		  CASE   
		   WHEN (@idTipoValorC != 'Unico') THEN ''  
		   ELSE valor  
		  END valor,  
		  @idUsuario,  
		  1  
		 FROM @tbl_propiedades AS prop  
		 WHERE _row = @cont 
			   AND validaVin = 1
		END  
		-- acciones para tabla objeto propiedadesClase  
		ELSE IF(@propiedadC = 'clase')  
		BEGIN   
		 IF( @idPropiedadC = 42)  
		 BEGIN  
		  IF NOT EXISTS (SELECT 1 FROM objeto.ObjetoPropiedadClase WHERE idObjeto = @IDC AND idPropiedadClase = 42)  
		  BEGIN  
		   INSERT INTO objeto.ObjetoPropiedadClase (idClase  
			,idPropiedadClase  
			,idTipoObjeto  
			,idObjeto  
			,valor  
			,idUsuario  
			,activo  
			)  
			SELECT  
			@idClaseActualC  
			,42  
			,(SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1)  
			,(SELECT idObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1)  
			,18  
			,@idUsuario  
			,1  
		   FROM @tbl_propiedades AS prop  
		   WHERE _row = @cont 
				AND validaVin = 1
   
		  END  
         
		  INSERT INTO [Objeto].[documento].[DocumentoObjetoClase]  
		  SELECT  
		   18,  
		   (SELECT TOP 1 idClase FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		   (SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1)  
		   ,(SELECT idObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
		   ,0  
		   ,'.jpg'  
		   ,(SELECT idDocumento FROM Common.configuracion.DocumentoDefault WHERE descripcion = 'placa')  
		   ,NULL  
		   ,valor  
		   ,@idUsuario  
		   ,GETDATE()  
		   ,NULL  
		   ,NULL  
		   ,NULL  
		  FROM @tbl_propiedades AS prop  
		  WHERE _row = @cont  
				AND validaVin = 1
		 END  
       
		 ------------INSERTAR EL AÑO  
		 ELSE IF(@idPropiedadC = 5)  
		  BEGIN  
		   IF NOT EXISTS (SELECT   
				1   
			   FROM objeto.ObjetoPropiedadClase   
			   WHERE idObjeto = @IDC   
			   AND idPropiedadClase = @valorC)  
			BEGIN  
			 INSERT INTO objeto.ObjetoPropiedadClase  
			 SELECT  
			  @idClaseActualC  
			  ,@valorC  
			  ,(SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1)  
			  ,(SELECT TOP 1 idObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1)  
			  ,(select valor FROM @tbl_propiedades where _row = @cont AND validaVin = 1)  
			  ,@idUsuario  
			  ,1  
			 FROM @tbl_propiedades AS prop  
			 WHERE _row = @cont  
					AND validaVin = 1
			END  
		  END  
  
		 ELSE  
		 BEGIN  
		  IF NoT EXISTS(SELECT 1 FROM objeto.objeto.ObjetoPropiedadClase where idObjeto = @idC and idPropiedadClase = @idPropiedadC)  
		  BEGIN  
   
		   INSERT INTO objeto.ObjetoPropiedadClase  
		   SELECT  
			@idClaseActualC  
			,@idPropiedadC  
			,(SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1)  
			,(SELECT TOP 1 idObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1)  
			,(select valor FROM @tbl_propiedades where _row = @cont AND validaVin = 1)  
			,@idUsuario  
			,1  
		   FROM @tbl_propiedades AS prop  
		   WHERE _row = @cont  
				AND validaVin = 1
		  END  
		 END  
		END  
		-- acciones para tabla objeto propiedadesContrato  
		ELSE IF(@propiedadC = 'contrato')  
		BEGIN  
		 INSERT INTO objeto.ObjetoPropiedadContrato  
		 SELECT  
		 (SELECT rfcEmpresa FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		 (SELECT idCliente FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		 (SELECT numeroContrato FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		 @idPropiedadC,  
		 (SELECT idClase FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		 (SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		 (SELECT idObjeto FROM @tbl_objetos WHERE [index] = prop.[index] AND validaVin = 1),  
		  CASE   
		   WHEN (@idTipoValorC != 'Unico') THEN ''  
		   ELSE valor  
		  END valor,  
		  @idUsuario,  
		  1  
		 FROM @tbl_propiedades AS prop  
		 WHERE _row = @cont  
				AND validaVin = 1
   
		 SELECT @idPropiedadC  
		END  
		SET @cont = @cont + 1  
	   END  
  
	END
	ELSE
	BEGIN
		WHILE((SELECT COUNT(*) FROM @tbl_objetos)>= @contObj)  
	   BEGIN  
	    -- Insertamos el Objeto  
	    INSERT INTO [objeto].[Objeto]  
	      ([idClase]  
	        ,[idTipoObjeto]  
	        ,[idUsuario]  
	        ,[activo])  
	     SELECT  
	      (SELECT TOP 1 idClase FROM @tbl_propiedades ),  
	      idTipoObjeto,  
	      @idUsuario,  
	      1  
	     FROM @tbl_objetos  
	     WHERE _row = @contObj  
   
	    SET @idObjeto = @@IDENTITY  
   
	    SET @idsObjetos = ISNULL(@idsObjetos, '') + ',' + CAST(@idObjeto AS VARCHAR(50))  
   
	    -- Lo damos de alta en un contrato  
	    INSERT INTO [Cliente].[contrato].[Objeto]  
	       ([rfcEmpresa]  
	       ,[idCliente]  
	       ,[numeroContrato]  
	       ,[idClase]  
	       ,[idTipoObjeto]  
	       ,[idObjeto]  
	       ,[idContratoZona]  
	       ,[idObjetoEstatus]  
	       ,[idUsuario]  
	       ,[activo]  
	       ,[idCentroCosto])  
	     SELECT  
	      rfcEmpresa,  
	      idCliente,  
	      numeroContrato,  
	      (SELECT TOP 1 idClase FROM @tbl_propiedades ),  
	      idTipoObjeto,  
	      @idObjeto,  
	      idZona,  
	      'ACT',  
	      @idUsuario,  
	      1,  
	      idCosto  
	     FROM @tbl_objetos  
	     WHERE _row = @contObj  
   
	     UPDATE @tbl_objetos  
	      SET idObjeto = @idObjeto  
	     WHERE _row = @contObj  
      
   
	    SET @contObj = @contObj + 1  
	   END--TERMINA WHILE  
   
	   -- empezamos la insercion de las propiedades  
	   WHILE((SELECT COUNT(*) FROM @tbl_propiedades)>= @cont)  
	   BEGIN     
	    -- buscar en la union de  las tablas de propiedades, para identificar el id a insertar  
	    SELECT   
	    @idC = id,  
	    @propiedadC = clase,   
	    @idPropiedadC = idProp,  
	    @idClaseActualC = idClase  
	    FROM @tbl_propiedades prop  
	    WHERE _row = @cont   
  
	    IF (@propiedadC = 'general')  
	    BEGIN  
	     SELECT @idTipoValorC = (SELECT TOP 1 * FROM (  
	             SELECT idTipoValor   
	             FROM objeto.PropiedadGeneral  
	             WHERE idPropiedadGeneral = prop.idProp  
	             ) as tbl1  
	             ),  
	     @valorC = ( SELECT  idPropiedadGeneral from objeto.PropiedadGeneral WHERE valor = prop.valor)  
	     FROM @tbl_propiedades prop  
	     WHERE _row = @cont   
	    END  
	    ELSE IF (@propiedadC = 'clase')  
	    BEGIN  
	     SELECT @idTipoValorC = (SELECT TOP 1 * FROM (  
	             SELECT idTipoValor   
	             FROM objeto.PropiedadClase  
	             WHERE idPropiedadClase = prop.idProp  
	             ) as tbl1  
	             ),  
	     @valorC = ( SELECT idPropiedadClase from objeto.PropiedadClase WHERE valor = prop.valor)  
	     FROM @tbl_propiedades prop  
	     WHERE _row = @cont   
	    END  
	    ELSE  
	    BEGIN  
	     SELECT @idTipoValorC = (SELECT TOP 1 * FROM (  
	             SELECT idTipoValor   
	             FROM objeto.PropiedadContrato  
	             WHERE idPropiedadContrato = prop.idProp  
	             ) as tbl1  
	             ),  
	     @valorC = ( SELECT  idPropiedadContrato from objeto.PropiedadContrato WHERE valor = prop.valor)  
	     FROM @tbl_propiedades prop  
	     WHERE _row = @cont   
	    END  
	    -- termino de la union de las tablas     
   
	    IF(@propiedadC = 'general')  
	    BEGIN  
	     INSERT INTO objeto.ObjetoPropiedadGeneral  
	     SELECT  
	      @idPropiedadC,  
	      (SELECT TOP 1 idClase FROM @tbl_objetos WHERE [index] = prop.[index]),  
	      (SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index]),  
	      (SELECT TOP 1 idObjeto FROM @tbl_objetos WHERE [index] = prop.[index]),  
	      CASE   
	       WHEN (@idTipoValorC != 'Unico') THEN ''  
	       ELSE valor  
	      END valor,  
	      @idUsuario,  
	      1  
	     FROM @tbl_propiedades AS prop  
	     WHERE _row = @cont  
	    END  
	    -- acciones para tabla objeto propiedadesClase  
	    ELSE IF(@propiedadC = 'clase')  
	    BEGIN   
	     IF( @idPropiedadC = 42)  
	     BEGIN  
	      IF NOT EXISTS (SELECT 1 FROM objeto.ObjetoPropiedadClase WHERE idObjeto = @IDC AND idPropiedadClase = 42)  
	      BEGIN  
	       INSERT INTO objeto.ObjetoPropiedadClase (idClase  
	        ,idPropiedadClase  
	        ,idTipoObjeto  
	        ,idObjeto  
	        ,valor  
	        ,idUsuario  
	        ,activo  
	        )  
	        SELECT  
	        @idClaseActualC  
	        ,42  
	        ,(SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
	        ,(SELECT idObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
	        ,18  
	        ,@idUsuario  
	        ,1  
	       FROM @tbl_propiedades AS prop  
	       WHERE _row = @cont  
   
	      END  
         
	      INSERT INTO [Objeto].[documento].[DocumentoObjetoClase]  
	      SELECT  
	       18,  
	       (SELECT TOP 1 idClase FROM @tbl_objetos WHERE [index] = prop.[index]),  
	       (SELECT TOP 1 idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
	       ,(SELECT idObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
	       ,0  
	       ,'.jpg'  
	       ,(SELECT idDocumento FROM Common.configuracion.DocumentoDefault WHERE descripcion = 'placa')  
	       ,NULL  
	       ,valor  
	       ,@idUsuario  
	       ,GETDATE()  
	       ,NULL  
	       ,NULL  
	       ,NULL  
	      FROM @tbl_propiedades AS prop  
	      WHERE _row = @cont  
	     END  
       
	     ------------INSERTAR EL AÑO  
	     ELSE IF(@idPropiedadC = 5)  
	      BEGIN  
	       IF NOT EXISTS (SELECT   
	            1   
	           FROM objeto.ObjetoPropiedadClase   
	           WHERE idObjeto = @IDC   
	           AND idPropiedadClase = @valorC)  
	        BEGIN  
	         INSERT INTO objeto.ObjetoPropiedadClase  
	         SELECT  
	          @idClaseActualC  
	          ,@valorC  
	          ,(SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
	          ,(SELECT TOP 1 idObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
	          ,(select valor FROM @tbl_propiedades where _row = @cont)  
	          ,@idUsuario  
	          ,1  
	         FROM @tbl_propiedades AS prop  
	         WHERE _row = @cont  
	        END  
	      END  
  
	     ELSE  
	     BEGIN  
	      IF NoT EXISTS(SELECT 1 FROM objeto.objeto.ObjetoPropiedadClase where idObjeto = @idC and idPropiedadClase = @idPropiedadC)  
	      BEGIN  
   
	       INSERT INTO objeto.ObjetoPropiedadClase  
	       SELECT  
	        @idClaseActualC  
	        ,@idPropiedadC  
	        ,(SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
	        ,(SELECT TOP 1 idObjeto FROM @tbl_objetos WHERE [index] = prop.[index])  
	        ,(select valor FROM @tbl_propiedades where _row = @cont)  
	        ,@idUsuario  
	        ,1  
	       FROM @tbl_propiedades AS prop  
	       WHERE _row = @cont  
	      END  
	     END  
	    END  
	    -- acciones para tabla objeto propiedadesContrato  
	    ELSE IF(@propiedadC = 'contrato')  
	    BEGIN  
	     INSERT INTO objeto.ObjetoPropiedadContrato  
	     SELECT  
	     (SELECT rfcEmpresa FROM @tbl_objetos WHERE [index] = prop.[index]),  
	     (SELECT idCliente FROM @tbl_objetos WHERE [index] = prop.[index]),  
	     (SELECT numeroContrato FROM @tbl_objetos WHERE [index] = prop.[index]),  
	     @idPropiedadC,  
	     (SELECT idClase FROM @tbl_objetos WHERE [index] = prop.[index]),  
	     (SELECT idTipoObjeto FROM @tbl_objetos WHERE [index] = prop.[index]),  
	     (SELECT idObjeto FROM @tbl_objetos WHERE [index] = prop.[index]),  
	      CASE   
	       WHEN (@idTipoValorC != 'Unico') THEN ''  
	       ELSE valor  
	      END valor,  
	      @idUsuario,  
	      1  
	     FROM @tbl_propiedades AS prop  
	     WHERE _row = @cont  
   
	     SELECT @idPropiedadC  
	    END  
	    SET @cont = @cont + 1  
	   END  
	END

  END  
  --TERMINA ACCION CONCATENAR  
 END   
 IF (@@ERROR = 0)  
 BEGIN  
   
  DECLARE @llave VARCHAR(MAX) = '{"idObjetos":"' + @idsObjetos  + '"}'  
   
   EXEC [evento].[evento].[INS_EVENTO]  
   @accion = 1  
   ,@modulo = 191  
   ,@gerencia = 1  
   ,@llave = @llave  
   ,@origen = NULL  
   ,@applicationId = 11  
   ,@idEstado = NULL  
   ,@idContratoZona = NULL  
   ,@idUsuario = @idUsuario  
   ,@err = ''  
 END  
   
 SELECT @idObjeto AS idObjeto;  
 --SET @err = 'El Vehiculo se registro correctamente.'  
 COMMIT  
END TRY  
  
BEGIN CATCH  
    SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'  
 SELECT @err  
ROLLBACK  
END CATCH
go

