-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <05-04-2019>
-- Description:	<Obtener todas las propiedades  de el objeto por medio de su id>
	/*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [objeto].[SEL_OBJETOPROPIEDADGENERAL_DINAMICO_SP] 274,'Automovil',92, '0001', 6036,null
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [objeto].[SEL_OBJETOPROPIEDADGENERAL_DINAMICO_SP] 
	@idObjeto				int,
	@idClase				varchar(10),
	@idCliente				int = null,
    @numeroContrato			varchar(50) = null,
	@idUsuario				int = null,
	@err					varchar(500)OUTPUT
AS


BEGIN

create table #propiedades(
	propiedad		varchar(500),
	idPropiedad		varchar(250),
	valor			varchar(250),
	idTipoDato		varchar(250),
	idPadre			int
)

/**********************************************************************************************************************
******************************************************CATALOGOS Y AGRUPADORES******************************************
**********************************************************************************************************************/
--PROPIEDADES GENERALES

	;with catalogos as(
		select 
		(Select valor from objeto.PropiedadGeneral  where idPropiedadGeneral = pg.idpadre) as propiedad,
		CAST(TPG.idPropiedadGeneral AS VARCHAR(250)) as idPropiedad,
		pg.valor,
		idPadre,
		pg.idTipoDato
		from objeto.ObjetoPropiedadGeneral TPG
		LEFT JOIN objeto.PropiedadGeneral PG ON PG.idpropiedadGeneral = TPG.idpropiedadGeneral
		where idTipoValor in  ('Catalogo','Agrupador')
		and TPG.idObjeto = @idObjeto

		UNION ALL	
		select
			prg.valor,
			cat.idPropiedad,
			cat.valor,
			prg.idPadre,
			cat.idTipoDato
		from objeto.PropiedadGeneral prg 
		inner join catalogos cat on cat.idPadre = prg.idPropiedadGeneral
		WHERE prg.activo = 1
		)

		insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			valor,
			idTipoDato,
			idPadre
		from catalogos cat 

--PROPIEDADES CONTRATO

	;with catalogos as(
		select 
		(Select valor from objeto.PropiedadContrato  where idPropiedadContrato = pco.idpadre) as propiedad,
		CAST(TPCO.idPropiedadContrato AS VARCHAR(250)) as idPropiedad,
		pco.valor,
		idPadre,
		pco.idTipoDato
		from objeto.ObjetoPropiedadContrato TPCO
		LEFT JOIN objeto.PropiedadContrato PCO ON PCO.idPropiedadContrato = TPCO.idPropiedadContrato
		where idTipoValor in  ('Catalogo','Agrupador')
		and TPCO.idObjeto = @idObjeto AND PCO.idCliente = @idCliente AND PCO.numeroContrato = @numeroContrato

		UNION ALL	
		select
			prco.valor,
			cat.idPropiedad,
			cat.valor,
			prco.idPadre,
			cat.idTipoDato
		from objeto.PropiedadContrato  prco 
		inner join catalogos cat on cat.idPadre = prco.idPropiedadContrato
		WHERE prco.activo = 1 AND prco.idCliente = @idCliente AND prco.numeroContrato = @numeroContrato
		)

		insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			valor,
			idTipoDato,
			idPadre
		from catalogos cat 

	-- OBJETO PROPIEDADES DE CLASE

	;with catalogos as(

		select 
		(Select valor from objeto.PropiedadClase where idPropiedadClase = pc.idpadre) as propiedad,
		CAST(tpc.idPropiedadClase AS VARCHAR(250)) as idPropiedad,
		pc.valor,
		idPadre,
		pc.idTipoDato
		from objeto.ObjetoPropiedadClase TPC
		LEFT JOIN objeto.PropiedadClase PC ON PC.idpropiedadClase = tpc.idpropiedadclase
		where idTipoValor in  ('Catalogo','Agrupador')
		and TPC.idObjeto = @idObjeto AND pc.idClase = @idClase

		UNION ALL	
	--HACEMOS LA RECURSIVIDAD PARA OBTENER TODOS LOS NIVELES DEL CATALOGO O DEL AGRUPADOR
		select
			prc.valor,
			cat.idPropiedad,
			cat.valor,
			prc.idPadre,
			cat.idTipoDato
		from objeto.PropiedadClase prc 
		inner join catalogos cat on cat.idPadre = prc.idPropiedadClase 
		WHERE prc.activo = 1 AND prc.idClase = @idClase


	 )
		insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			valor,
			idTipoDato,
			idPadre
		from catalogos cat 


	--/**********************************************************************************************************************
	--*********************************************************TAGS**********************************************************
	--**********************************************************************************************************************/

	--PROPIEDADES GENERALES

	;with tags as(

		select 
		(Select valor from objeto.PropiedadGeneral where idPropiedadGeneral = pg.idpadre) as propiedad,
		CAST(tpg.idPropiedadGeneral AS VARCHAR(250)) as idPropiedad,
		pg.valor,
		idPadre,
		pg.idTipoDato
		from objeto.ObjetoPropiedadGeneral TPG
		LEFT JOIN objeto.PropiedadGeneral PG ON PG.idpropiedadGeneral = tpg.idpropiedadGeneral
		where idTipoValor ='Etiqueta'
		and TPG.idObjeto = @idObjeto

		UNION ALL	
		select
			prg.valor,
			tag.idPropiedad,
			tag.valor,
			prg.idPadre,
			tag.idTipoDato
		from objeto.PropiedadGeneral prg 
		inner join tags tag on tag.idPadre = prg.idPropiedadGeneral
		WHERE prg.activo = 1

	 )

		insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			(
			SELECT STUFF(
	
				(SELECT ', ' + valor
				FROM tags tagsAux
				WHERE tagsAux.idPadre is null 
				FOR XML PATH ('')),
			1,1, '') ) as valor,
			idTipoDato,
			idPadre
		from tags tags 

		
	--PROPIEDADES CONTRATOS

	;with tags as(

		select 
		(Select valor from objeto.PropiedadContrato where idPropiedadContrato = pco.idpadre) as propiedad,
		CAST(tpco.idPropiedadContrato AS VARCHAR(250)) as idPropiedad,
		pco.valor,
		idPadre,
		pco.idTipoDato
		from objeto.ObjetoPropiedadContrato TPCO
		LEFT JOIN objeto.PropiedadContrato PCO ON PCO.idPropiedadContrato= tpco.idPropiedadContrato
		where idTipoValor ='Etiqueta'
		and TPCO.idObjeto = @idObjeto AND PCO.idCliente = @idCliente AND PCO.numeroContrato = @numeroContrato

		UNION ALL	
		select
			prco.valor,
			tag.idPropiedad,
			tag.valor,
			prco.idPadre,
			tag.idTipoDato
		from objeto.PropiedadContrato prco 
		inner join tags tag on tag.idPadre = prco.idPropiedadContrato 
		WHERE prco.activo = 1 AND prco.idCliente = @idCliente AND prco.numeroContrato = @numeroContrato

	 )

		insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			(
			SELECT STUFF(
	
				(SELECT ', ' + valor
				FROM tags tagsAux
				WHERE tagsAux.idPadre is null 
				FOR XML PATH ('')),
			1,1, '') ) as valor,
			idTipoDato,
			idPadre
		from tags tags 

	--PROPIEDADES DE CLASE
	;with tags as(

		select 
		(Select valor from objeto.PropiedadClase where idPropiedadClase = pc.idpadre) as propiedad,
		CAST(tpc.idPropiedadClase AS VARCHAR(250)) as idPropiedad,
		pc.valor,
		idPadre,
		pc.idTipoDato
		from objeto.ObjetoPropiedadClase TPC
		LEFT JOIN objeto.PropiedadClase PC ON PC.idpropiedadClase = tpc.idpropiedadclase
		where idTipoValor ='Etiqueta'
		and TPC.idObjeto = @idObjeto AND pc.idClase = @idClase
		
		
		UNION ALL	
		select
			prc.valor,
			tag.idPropiedad,
			tag.valor,
			prc.idPadre,
			tag.idTipoDato
		from objeto.PropiedadClase prc 
		inner join tags tag on tag.idPadre = prc.idPropiedadClase 
		WHERE prc.activo = 1 AND prc.idClase = @idClase


	 )

		insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			(
			SELECT STUFF(
	
				(SELECT ', ' + valor
				FROM tags tagsAux
				WHERE tagsAux.idPadre is null 
				FOR XML PATH ('')),
			1,1, '') ) as valor,
			idTipoDato,
			idPadre
		from tags tags 
	
	--/**********************************************************************************************************************
	--***************************************************VALORES FIJOS*******************************************************
	--**********************************************************************************************************************/

	----PROPIEDADES GENERALES

	;with fijos as(

		select 
		pg.valor propiedad,
		tpg.valor as idPropiedad,
		tpg.valor as valor,
		idPadre,
		pg.idTipoDato
		from objeto.ObjetoPropiedadGeneral TPG
		LEFT JOIN objeto.PropiedadGeneral PG ON PG.idpropiedadGeneral = tpg.idpropiedadGeneral
		where idTipoValor ='Unico'
		and TPG.idObjeto = @idObjeto

		
		UNION ALL	
		select
			prg.valor,
			idPropiedad,
			fijo.valor,
			prg.idPadre,
			fijo.idTipoDato
		from objeto.PropiedadGeneral prg 
		inner join fijos fijo on fijo.idPadre = prg.idPropiedadGeneral
		WHERE prg.activo = 1

	 )

	 insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			valor,
			idTipoDato,
			idPadre
		from fijos fijos 

----PROPIEDADES Contrato

	;with fijos as(

		select 
		pco.valor propiedad,
		tpco.valor as idPropiedad,
		tpco.valor as valor,
		idPadre,
		pco.idTipoDato
		from objeto.ObjetoPropiedadContrato TPCO
		LEFT JOIN objeto.PropiedadContrato PCO ON PCO.idPropiedadContrato = tpco.idPropiedadContrato
		where idTipoValor ='Unico'
		and TPCO.idObjeto = @idObjeto AND PCO.idCliente = @idCliente AND PCO.numeroContrato = @numeroContrato

		
		UNION ALL	
		select
			prco.valor,
			idPropiedad,
			fijo.valor,
			prco.idPadre,
			fijo.idTipoDato
		from objeto.PropiedadContrato prco 
		inner join fijos fijo on fijo.idPadre = prco.idPropiedadContrato
		WHERE prco.activo = 1 AND prco.idCliente = @idCliente AND prco.numeroContrato = @numeroContrato

	 )

	 insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			valor,
			idTipoDato,
			idPadre
		from fijos fijos 

	--PROPIEDADES DE CLASE

	;with fijos as(

		select 
		pc.valor propiedad,
		tpc.valor as idPropiedad,
		tpc.valor as valor,
		idPadre,
		pc.idTipoDato
		from objeto.ObjetoPropiedadClase TPC
		LEFT JOIN objeto.PropiedadClase PC ON PC.idpropiedadClase = tpc.idpropiedadclase
		where idTipoValor ='Unico' AND  idTipoDato != 'Documento'
		and TPC.idObjeto = @idObjeto AND pc.idClase = @idClase

		UNION ALL	
		
		select 
		pc.valor propiedad,
		DOC.valor as idPropiedad,
		DOC.valor as valor,
		idPadre,
		pc.idTipoDato
		from objeto.ObjetoPropiedadClase TPC
		LEFT JOIN objeto.PropiedadClase PC ON PC.idpropiedadClase = tpc.idpropiedadclase
		LEFT JOIN ( 
		SELECT doc1.[idDocumentoClase]
      ,doc1.[idClase]
      ,doc1.[idObjeto]
	  , doc1.valor
	  , doc1.version
		FROM [Objeto].[documento].[DocumentoObjetoClase] doc1 
		RIGHT JOIN (SELECT [idDocumentoClase],[idClase],[idObjeto],MAX([version]) as ultimo
			FROM [Objeto].[documento].[DocumentoObjetoClase]
			GROUP BY [idDocumentoClase] ,[idClase],[idObjeto]) doc2  ON doc1.[idDocumentoClase] = doc2.[idDocumentoClase]
			AND doc1.[idClase] = doc2.[idClase]  AND doc1.[idObjeto] = doc2.[idObjeto] AND doc1.version = doc2.ultimo )DOC 
		ON tpc.valor = DOC.idDocumentoClase AND TPC.idObjeto = DOC.idObjeto	
		where idTipoValor ='Unico'  AND idTipoDato = 'Documento'
		and TPC.idObjeto = @idObjeto AND pc.idClase = @idClase
		UNION ALL

		select
			prg.valor,
			idPropiedad,
			fijo.valor,
			prg.idPadre,
			fijo.idTipoDato
		from objeto.PropiedadClase prg 
		inner join fijos fijo on fijo.idPadre = prg.idPropiedadClase
		WHERE prg.activo = 1 AND prg.idClase = @idClase


	 )

		insert into #propiedades
		select 
			propiedad,
			idPropiedad,
			valor,
			idTipoDato,
			idPadre
		from fijos fijos 

	select 
		propiedad,
		idPropiedad,
		valor,
		idTipoDato
	from #propiedades
	where idPadre is null

	 drop table #propiedades
END

go

