

-- =============================================
--Fecha Creación: 16/12/19
--Autor: Miguel Angel Reyes Xinaxtle
--Descripción: Obtener placas para tarea de multas
--documento.[SEL_MULTA_SP]
-- =============================================
CREATE PROCEDURE [documento].[SEL_MULTA_SP]
AS
BEGIN

    SELECT  
        [idDocumentoClase]
        ,[idClase]
        ,[idTipoObjeto]
        ,[idObjeto]
        ,[version]
        ,[idTipoDocumento]
        ,[idFileServer]
        ,[vigencia]
        ,[valor]
        ,[idUsuario]
        ,[fecha]
        ,[idCostoDocumentoClase]
        ,[idEstado]
        ,[comentario]
    FROM [documento].[SEL_PLACA_ULTIMA_VERSION_VW]

END

go

