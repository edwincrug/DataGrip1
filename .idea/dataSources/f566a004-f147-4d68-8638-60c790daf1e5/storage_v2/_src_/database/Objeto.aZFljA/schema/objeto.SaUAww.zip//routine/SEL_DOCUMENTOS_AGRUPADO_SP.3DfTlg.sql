-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<13/06/2019>
-- Description:		<Obtener los documentos por idobjeto agrupados>
-- =============================================
-- EXEC [objeto].[SEL_DOCUMENTOS_AGRUPADO_SP] 'general', 'Automovil', 117, 10558, 221, '205'
-- =============================================
CREATE PROCEDURE [objeto].[SEL_DOCUMENTOS_AGRUPADO_SP]
(
	@idAgrupador			varchar(20)
    ,@idClase				varchar(10)
    ,@idTipoObjeto			int
    ,@idObjeto				int
	,@idCliente				int
	,@numeroContrato		VARCHAR(50)
	,@idUsuario				int=NULL
	,@err					NVARCHAR(500) = '' OUTPUT
)
AS
BEGIN
	--DOCUMENTOS DE CLASE
	SELECT 
		ODDC.[idDocumentoClase]
		,ODDC.[idClase]
		,ODDC.[nombre]
		,ODDC.[idAgrupador]
		,ODDC.[vigencia] tieneVigencia
		,ODDC.[orden]
		,@idTipoObjeto [idTipoObjeto]
		,@idObjeto [idObjeto]
		,SDCUVV.[idFileServer]
		,SDCUVV.[vigencia]
		,SDCUVV.[valor]
		,SDCUVV.[fecha]
		,SDCUVV.[UserName] userName
		,SDCUVV.[PrimerNombre]
		,SDCUVV.[SegundoNombre]
		,SDCUVV.[PrimerApellido]
		,SDCUVV.[SegundoApellido]
		,SDCUVV.[Email]
		,SDCUVV.[Celular]
		,'clase' as tipo
	FROM [Objeto].[documento].[DocumentoClase] ODDC
	LEFT JOIN (
	SELECT
		UV.[idDocumentoClase]
		,UV.[idClase]
		,UV.[idTipoObjeto]
		,UV.[idObjeto]
		,UV.[idFileServer]
		,UV.[vigencia]
		,UV.[valor]
		,UV.[fecha]
		,UV.[idUsuario]
		,U.[UserName]
		,U.[PrimerNombre]
		,U.[SegundoNombre]
		,U.[PrimerApellido]
		,U.[SegundoApellido]
		,U.[Email]
		,U.[Celular]
	FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW] UV
		LEFT JOIN [Seguridad].[Catalogo].[Users] U
	ON UV.[idUsuario] = U.[id]
	WHERE UV.[idClase] = @idClase
		AND UV.[idTipoObjeto] = @idTipoObjeto
		AND UV.[idObjeto] = @idObjeto
	) SDCUVV
		ON ODDC.idDocumentoClase = SDCUVV.idDocumentoClase
		AND ODDC.idClase = SDCUVV.idClase
	WHERE ODDC.idAgrupador = @idAgrupador
		AND ODDC.idClase = @idClase
	--ORDER BY ODDC.orden

	UNION
	--DOCUMENTOS GENERAL
	SELECT 
		ODDC.[idDocumentoGeneral]
		,@idClase idClase
		,ODDC.[nombre]
		,ODDC.[idAgrupador]
		,ODDC.[vigencia] tieneVigencia
		,ODDC.[orden]
		,@idTipoObjeto [idTipoObjeto]
		,@idObjeto [idObjeto]
		,SDCUVV.[idFileServer]
		,SDCUVV.[vigencia]
		,SDCUVV.[valor]
		,SDCUVV.[fecha]
		,SDCUVV.[UserName] userName
		,SDCUVV.[PrimerNombre]
		,SDCUVV.[SegundoNombre]
		,SDCUVV.[PrimerApellido]
		,SDCUVV.[SegundoApellido]
		,SDCUVV.[Email]
		,SDCUVV.[Celular]
		,'general' as tipo
	FROM [Objeto].[documento].[DocumentoGeneral] ODDC
	LEFT JOIN (
	SELECT
		UV.[idDocumentoGeneral]
		--,UV.[idClase]
		,UV.[idTipoObjeto]
		,UV.[idObjeto]
		,UV.[idFileServer]
		,UV.[vigencia]
		,UV.[valor]
		,UV.[fecha]
		,UV.[idUsuario]
		,U.[UserName]
		,U.[PrimerNombre]
		,U.[SegundoNombre]
		,U.[PrimerApellido]
		,U.[SegundoApellido]
		,U.[Email]
		,U.[Celular]
	FROM [documento].[SEL_DOCUMENTOS_GENERAL_ULTIMA_VERSION_VW] UV
		LEFT JOIN [Seguridad].[Catalogo].[Users] U
	ON UV.[idUsuario] = U.[id]
	WHERE UV.[idClase] = @idClase
		AND UV.[idTipoObjeto] = @idTipoObjeto
		AND UV.[idObjeto] = @idObjeto
	) SDCUVV
		ON ODDC.idDocumentoGeneral = SDCUVV.idDocumentoGeneral
		--AND ODDC.idClase = SDCUVV.idClase
	WHERE ODDC.idAgrupador = @idAgrupador
		--AND ODDC.idClase = @idClase
	--ORDER BY ODDC.orden

	UNION

	SELECT 
		ODDC.[idDocumentoContrato]
		,@idClase idClase
		,ODDC.[nombre]
		,ODDC.[idAgrupador]
		,ODDC.[vigencia] tieneVigencia
		,ODDC.[orden]
		,@idTipoObjeto [idTipoObjeto]
		,@idObjeto [idObjeto]
		,SDCUVV.[idFileServer]
		,SDCUVV.[vigencia]
		,SDCUVV.[valor]
		,SDCUVV.[fecha]
		,SDCUVV.[UserName] userName
		,SDCUVV.[PrimerNombre]
		,SDCUVV.[SegundoNombre]
		,SDCUVV.[PrimerApellido]
		,SDCUVV.[SegundoApellido]
		,SDCUVV.[Email]
		,SDCUVV.[Celular]
		,'contrato' as tipo
	FROM [Objeto].[documento].[DocumentoContrato] ODDC
	LEFT JOIN (
	SELECT
		UV.[idDocumentoContrato]
		,UV.[idClase]
		,UV.[idTipoObjeto]
		,UV.[idObjeto]
		,UV.[idFileServer]
		,UV.[vigencia]
		,UV.[valor]
		,UV.[fecha]
		,UV.[idUsuario]
		,U.[UserName]
		,U.[PrimerNombre]
		,U.[SegundoNombre]
		,U.[PrimerApellido]
		,U.[SegundoApellido]
		,U.[Email]
		,U.[Celular]
	FROM [documento].[SEL_DOCUMENTOS_CONTRATO_ULTIMA_VERSION_VW] UV
		LEFT JOIN [Seguridad].[Catalogo].[Users] U
	ON UV.[idUsuario] = U.[id]
	WHERE UV.[idClase] = @idClase
		AND UV.[idTipoObjeto] = @idTipoObjeto
		AND UV.[idObjeto] = @idObjeto
	) SDCUVV
		ON ODDC.idDocumentoContrato = SDCUVV.idDocumentoContrato
		--AND ODDC.idClase = SDCUVV.idClase
	WHERE ODDC.idAgrupador = @idAgrupador
		AND ODDC.idCliente = @idCliente
		AND ODDC.numeroContrato = @numeroContrato
		--AND ODDC.idClase = @idClase
	ORDER BY ODDC.orden


END
go

