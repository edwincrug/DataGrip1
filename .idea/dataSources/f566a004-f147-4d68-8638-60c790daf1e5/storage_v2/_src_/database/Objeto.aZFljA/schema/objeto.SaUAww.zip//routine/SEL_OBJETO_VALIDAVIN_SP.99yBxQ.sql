-- =============================================
-- Author:		<Edgar Mendoza>
-- Create date: <02-09-2020>
-- Description:	<Valida si existe VIN>
-- =============================================
/*


	EXEC [objeto].[SEL_OBJETO_VALIDAVIN_SP] '1234567890', '128', 219, 'ASE0508051B6', 12932, 123, 6115, ''


*/
-- =============================================
create PROCEDURE [objeto].[SEL_OBJETO_VALIDAVIN_SP]
	@VIN					VARCHAR(250),
	@numeroContrato			VARCHAR(10),
	@idCliente				INT,
	@rfcEmpresa				VARCHAR(13),
	@idObjeto				int,
	@idTipoObjeto			int,
	@idUsuario				INT,
	@err					varchar(max) OUTPUT

AS
	BEGIN 

		IF EXISTS(SELECT 1 FROM objeto.ObjetoPropiedadClase PC
					INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
					INNER JOIN objeto.PropiedadClase p on p.idPropiedadClase = PC.idPropiedadClase
					INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
					WHERE PC.valor = @VIN
					AND CO.rfcEmpresa = @rfcEmpresa
					AND CO.idCliente = @idCliente
					AND CO.numeroContrato = @numeroContrato
					AND CO.activo = 1
					AND O.activo = 1
					AND p.agrupador = 'VIN'
					AND CO.idObjetoEstatus = 'ACT')
			BEGIN
			IF EXISTS(SELECT 1 FROM objeto.ObjetoPropiedadClase PC
					INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
					INNER JOIN objeto.PropiedadClase p on p.idPropiedadClase = PC.idPropiedadClase
					INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
					WHERE PC.valor = @VIN
					AND CO.rfcEmpresa = @rfcEmpresa
					AND CO.idCliente = @idCliente
					AND CO.numeroContrato = @numeroContrato
					AND CO.activo = 1
					AND O.activo = 1
					AND p.agrupador = 'VIN'
					AND CO.idObjetoEstatus = 'ACT'
					and co.idTipoObjeto = @idTipoObjeto
					and co.idObjeto = @idObjeto)
				BEGIN
					PRINT 'Es valido'
				END
			ELSE
				BEGIN
					--SET @err = 'El VIN ya se encuentra registrado en este contrato. Favor de validar.'
					SELECT 'El VIN ya se encuentra registrado en este contrato. Si continuas de dara de baja definitiva esa unidad. ' mensaje
				END
			END

		ELSE
			BEGIN
				IF EXISTS(SELECT 1 FROM objeto.ObjetoPropiedadClase  PC
							INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
							INNER JOIN  objeto.PropiedadClase p on p.idPropiedadClase = PC.idPropiedadClase 
							INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
							WHERE PC.valor = @VIN
							AND p.agrupador = 'VIN'
							AND O.activo = 1
							AND CO.idObjetoEstatus = 'ACT')
					BEGIN
					
						DECLARE @idTipoObjetoRepetido	INT,
								@rfcEmpresaRepetido		VARCHAR(13),
								@idClienteRepetido		INT,
								@numeroContratoRepetido	VARCHAR(10)

						SELECT TOP 1 @idObjeto = PC.idObjeto, 
									@idTipoObjetoRepetido = PC.idTipoObjeto,
									@rfcEmpresaRepetido = CO.rfcEmpresa,
									@idClienteRepetido = CO.idCliente,
									@numeroContratoRepetido = CO.numeroContrato
								FROM objeto.ObjetoPropiedadClase  PC
										INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
										INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
										INNER JOIN  objeto.PropiedadClase p on p.idPropiedadClase = PC.idPropiedadClase 
										WHERE PC.valor = @VIN
										AND p.agrupador = 'VIN'
										AND O.activo = 1
										and co.idObjetoEstatus = 'ACT'

						IF(@idTipoObjeto != @idTipoObjetoRepetido)
						BEGIN
							--SET @err = 'El tipo de unidad seleccionado es diferente al ya registrado.'
							SELECT 
								'El VIN ya existe en el contrato ' + nombre + ' con una unidad diferente a la que quiere registrar. ' mensaje
							FROM objeto.ObjetoPropiedadClase PC
							INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
							INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
							INNER JOIN Cliente.cliente.Contrato C ON C.numeroContrato = CO.numeroContrato AND C.rfcEmpresa = CO.rfcEmpresa AND C.idCliente = CO.idCliente
							WHERE valor = @VIN
							AND CO.activo = 1
							AND O.activo = 1
							AND C.activo = 1
							AND CO.idObjetoEstatus = 'ACT'
						END
						ELSE
						BEGIN
							SELECT 
								'El VIN ya existe en el contrato ' + nombre + '. ' mensaje
							FROM objeto.ObjetoPropiedadClase PC
							INNER JOIN objeto.objeto O ON O.idObjeto = PC.idObjeto
							INNER JOIN Cliente.contrato.Objeto CO ON CO.idObjeto = PC.idObjeto
							INNER JOIN Cliente.cliente.Contrato C ON C.numeroContrato = CO.numeroContrato AND C.rfcEmpresa = CO.rfcEmpresa AND C.idCliente = CO.idCliente
							WHERE valor = @VIN
							AND CO.activo = 1
							AND O.activo = 1
							AND C.activo = 1
							AND CO.idObjetoEstatus = 'ACT'
						END
					END

				ELSE
					BEGIN
						PRINT 'El VIN  no existe.'
					END
				
			END

	END

go

