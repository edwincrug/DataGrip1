-- =============================================
-- Author:		Sandra Gil Rosales
-- Create date: 28/06/2019
-- Description:	Consulta de operadores (con opción de jerarquia)
-- store base: [Operacion].[Get_User_Busqueda] 

/* Testing:
   DECLARE @salida varchar(max) ='' ;
   EXEC  [operador].[SEL_OBJETO_BUSQUEDA]
	'201',
	0,
	@salida OUTPUT
*/
-- ============== Versionamiento ================
/*
	Fecha			Autor					Descripción 
	

*/

CREATE PROCEDURE [operador].[SEL_OBJETO_BUSQUEDA]
	@busqueda				varchar(250),
	--PARAMETROS PARA EL TIPO DE BUSQUEDA DE PARQUE VEHICULAR POR CONTRATO
	@numContrato				varchar(10),
	@idUsuario				int,
	-----------------------------------------------------------------------
	@err			VARCHAR(max) OUTPUT
AS
BEGIN
-- variable temporal para el estatus aun no definido 
	DECLARE @idEstatus INT;
	SET @idEstatus = 1;

	BEGIN
SELECT * FROM (	SELECT opc.[idClase]
      ,opc.[idTipoObjeto]
      ,opc.[idObjeto]
      ,opc.[valor]
      ,opc.[idUsuario]
      ,opc.[activo]
	  , CASE WHEN opc.valor = '' THEN valorProp
		ELSE opc.valor END AS propiedades
	  ,op.*
	  , odg2.idFileServer
	  FROM [Objeto].[objeto].[ObjetoPropiedadClase] AS opc
	  INNER JOIN [Cliente].[contrato].[Objeto] as cco  ON opc.idTipoObjeto = cco.idTipoObjeto AND opc.idObjeto = cco.idObjeto AND cco.numeroContrato = @numContrato
	  LEFT JOIN (SELECT [idPropiedadClase]
		  ,[valor] AS valorProp
	  FROM [Objeto].[objeto].[PropiedadClase]
	  WHERE idClase = 'Automovil' AND activo = 1 ) AS  op
	  ON op.idPropiedadClase = opc.idPropiedadClase
	  LEFT JOIN (SELECT  dog.idTipoDocumento
			,dog.idTipoObjeto
			,dog.idObjeto
			, MAX(dog.version) AS idVersion
			FROM [Objeto].[documento].[DocumentoObjetoGeneral] dog
			LEFT JOIN [Objeto].[documento].[DocumentoGeneral] dg 
			ON dog.idDocumentoGeneral = dg.idDocumentoGeneral AND dg.nombre = 'Foto Principal'
			GROUP BY dog.idTipoObjeto ,dog.idObjeto, dog.idTipoDocumento) AS pf
	ON opc.idTipoObjeto = pf.idTipoObjeto AND  opc.idObjeto = pf.idObjeto
	LEFT JOIN [Objeto].[documento].[DocumentoObjetoGeneral] AS odg2 
	ON odg2.idTipoObjeto = opc.idTipoObjeto AND opc.idObjeto = odg2.idObjeto AND odg2.idTipoDocumento = pf.idTipoDocumento AND odg2.version = pf.idVersion
	  WHERE opc.activo = 1 AND (opc.valor = '' OR valorProp = 'VIN' OR valorProp = 'Placa' )) AS buscador

		WHERE propiedades like '%' + @busqueda + '%' OR 
		isnull([idObjeto],'') like '%' + @busqueda + '%' 
		END

END
go

