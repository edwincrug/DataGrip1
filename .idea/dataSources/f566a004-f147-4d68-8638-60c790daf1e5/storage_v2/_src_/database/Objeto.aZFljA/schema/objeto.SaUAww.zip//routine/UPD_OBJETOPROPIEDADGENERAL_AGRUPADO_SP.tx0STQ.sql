
-- =============================================
-- Author:		<Sandra Gil Rosales>
-- Create date: <01-04-2019>
-- Description:	<Modificar la tabla objeto segun el tipo de objeto>
-- =============================================
/*
	*- Testing...

DECLARE @err varchar(max) ='' ;
EXEC [objeto].[UPD_OBJETOPROPIEDADGENERAL_AGRUPADO_SP]
@propiedades = '<propiedades><propiedad><valor>2</valor><idPropiedad>1</idPropiedad><propiedadDes>general</propiedadDes><idTipoValor>Catalogo</idTipoValor></propiedad><propiedad><valor>3N1CN7AD1LK407155</valor><idPropiedad>1</idPropiedad><propiedadDes>clase</propiedadDes><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>7</valor><idPropiedad>5</idPropiedad><propiedadDes>clase</propiedadDes><idTipoValor>Catalogo</idTipoValor></propiedad><propiedad><valor>rgb(255,255,255)</valor><idPropiedad>2</idPropiedad><propiedadDes>clase</propiedadDes><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>567</valor><idPropiedad>4</idPropiedad><propiedadDes>clase</propiedadDes><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>2020-05-15T09:17:45-05:00</valor><idPropiedad>53</idPropiedad><propiedadDes>clase</propiedadDes><idTipoValor>Unico</idTipoValor></propiedad><propiedad><valor>2</valor><idPropiedad>54</idPropiedad><propiedadDes>clase</propiedadDes><idTipoValor>Unico</idTipoValor></propiedad></propiedades>',
@idObjeto = 12141,
@idTipoObjeto = 122,
@idObjetoActual = '12141',
@idTipoObjetoAct = '122',
@idClase = 'Automovil',
@rfcEmpresa = 'ASE0508051B6',
@idCliente = 216,
@numeroContrato = '127',
@UserId = 6115,
@err = OUTPUT;
SELECT @err AS salida;

	SELECT * FROM [objeto].[ObjetoPropiedadGeneral] WHERE idObjeto = 169
	SELECT * FROM  [objeto].[ObjetoPropiedadClase] WHERE idObjeto = 169
	SELECT * FROM [objeto].[ObjetoPropiedadContrato] WHERE idObjeto = 169



*/
-- =============================================
CREATE PROCEDURE [objeto].[UPD_OBJETOPROPIEDADGENERAL_AGRUPADO_SP]
-- variables de el objeto
@idObjeto			int,
@idTipoObjeto		int,
@idObjetoActual		int,
@idTipoObjetoAct	int,
-- variables de el cliente y usuario
@idClase			varchar(10),
@UserId				int,
@rfcEmpresa			varchar(13),
@idCliente			int,
@numeroContrato		nvarchar(50),
@activo				int = 1,
@propiedades		XML,
@err				NVARCHAR(500) OUTPUT
	AS
	BEGIN TRY
	BEGIN TRANSACTION

    DECLARE @tbl_propiedades AS TABLE(
        _row                    INT IDENTITY(1,1),
        propiedadDes			NVARCHAR(250),
        idPropiedad				INT,
        valor                   NVARCHAR(500),
		idTipoValor				NVARCHAR(250)
    )

	--		IF @idTipoObjetoAct IS NULL THEN SET @idTipoObjetoAct = @idTipoObjeto; END IF;
	--		IF @idObjetoActua IS NULL THEN SET @idObjetoActua = @idObjeto; END IF;

-- borramos tambien el objeto de la tabla objeto por si es un update 
       IF( @idObjeto <> @idObjetoActual OR @idTipoObjeto <> @idTipoObjetoAct)
			BEGIN
			update [objeto].[Objeto]
				set activo = 0
			WHERE idObjeto = @idObjeto
					AND idTipoObjeto = @idTipoObjeto AND idClase = @idClase
	   select 11111111111111111111111
			END
			else
				begin
					DELETE FROM [objeto].[ObjetoPropiedadGeneral]  WHERE idObjeto = @idObjeto AND idTipoObjeto = @idTipoObjeto AND idClase = @idClase 
	
					DELETE FROM [objeto].[ObjetoPropiedadClase]    WHERE idObjeto = @idObjeto AND idTipoObjeto = @idTipoObjeto AND idClase = @idClase
	
					DELETE FROM [objeto].[ObjetoPropiedadContrato] WHERE idObjeto = @idObjeto AND idTipoObjeto = @idTipoObjeto AND idClase = @idClase
				end

			print 2
    INSERT INTO @tbl_propiedades(propiedadDes,
								idPropiedad,
                                valor,
								idTipoValor)

    SELECT
        ParamValues.col.value('propiedadDes[1]','nvarchar(250)'),
        ParamValues.col.value('idPropiedad[1]','int'),
        ParamValues.col.value('valor[1]','nvarchar(500)'),
		ParamValues.col.value('idTipoValor[1]','NVARCHAR(250)')
        FROM @propiedades.nodes('propiedades/propiedad') AS ParamValues(col)

	DECLARE @cont INT = 1
	print 4
    WHILE((SELECT COUNT(*) FROM @tbl_propiedades)>= @cont)

    BEGIN
        DECLARE @propiedad NVARCHAR(250);
		DECLARE @valor NVARCHAR(500);
		DECLARE @idPropiedad INT;
       SELECT @propiedad = propiedadDes,
			@idPropiedad = idPropiedad,
			@valor = valor
        FROM @tbl_propiedades 
        WHERE _row = @cont
	-- variables para el update en la tabla de documentos 
		DECLARE @idDocumentoG  INT;
		DECLARE @idDocumentoClase  INT;
		DECLARE @idDocumentoContrato  INT;

		SET @idDocumentoG = ( SELECT idDocumentoGeneral FROM objeto.objeto.PropiedadGeneral AS a  
			LEFT JOIN [Objeto].[documento].[DocumentoGeneral] AS b  ON 
			a.valor = b.nombre
			WHERE idPropiedadGeneral = @idPropiedad AND idTipoDato = 'Documento')

		SET @idDocumentoClase = (SELECT idDocumentoClase FROM objeto.objeto.PropiedadClase AS a  
			LEFT JOIN [Objeto].[documento].[DocumentoClase] AS b  ON 
			a.idClase= b.idClase AND a.valor = b.nombre
			WHERE idPropiedadClase = @idPropiedad AND idTipoDato = 'Documento' AND a.idClase = @idClase)
						
		SET @idDocumentoContrato = (SELECT idDocumentoContrato FROM objeto.objeto.PropiedadContrato AS a  
			LEFT JOIN [Objeto].[documento].[DocumentoContrato] AS b  ON 
			a.idCliente= b.idCliente AND a.numeroContrato = b.numeroContrato AND a.valor = b.nombre
			WHERE idPropiedadContrato = @idPropiedad AND idTipoDato = 'Documento' 
			AND a.idCliente = @idCliente AND a.numeroContrato = @numeroContrato)

-- UPDATE a las tablas de documentos solo si hay una propiedad de ellos 
				UPDATE [Objeto].[documento].[DocumentoObjetoGeneral]
				   SET 
						[valor] = @valor
					WHERE idDocumentoGeneral = @idDocumentoG AND idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjetoAct
						AND idClase = @idClase AND version = (
						SELECT TOP 1 version 
						FROM [Objeto].[documento].[DocumentoObjetoGeneral]
						WHERE idDocumentoGeneral =  @idDocumentoG AND idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjetoAct
						AND idClase = @idClase
						ORDER BY version DESC)

				UPDATE [Objeto].[documento].[DocumentoObjetoClase]
					SET 
						[valor] = @valor
					WHERE idDocumentoClase = @idDocumentoClase AND idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjetoAct
						AND idClase = @idClase AND version = (
						SELECT TOP 1 version 
						FROM [Objeto].[documento].[DocumentoObjetoClase]
						WHERE idDocumentoClase =  @idDocumentoClase AND idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjetoAct
						AND idClase = @idClase
						ORDER BY version DESC)

				UPDATE [Objeto].[documento].[DocumentoObjetoContrato]
					SET 
						[valor] = @valor
				WHERE idDocumentoContrato = @idDocumentoContrato AND idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjetoAct
						AND idClase = @idClase AND version = (
						SELECT TOP 1 version 
						FROM [Objeto].[documento].[DocumentoObjetoContrato]
						WHERE idDocumentoContrato = @idDocumentoContrato AND idObjeto = @idObjetoActual AND idTipoObjeto = @idTipoObjetoAct
						AND idClase = @idClase
						ORDER BY version DESC)

-- INSERT a las propiedades de los objetos 
       IF(@propiedad = 'general')
			BEGIN
				DECLARE @valorG varchar(500);
				IF (@idDocumentoG > 0)
					BEGIN
					SET @valorG =  @idDocumentoG;
					END
				ELSE 
					BEGIN
					SET @valorG =  @valor;
					END

				INSERT INTO [objeto].[ObjetoPropiedadGeneral]
				SELECT
					CASE
						WHEN ((SELECT TOP 1 idTipoValor FROM @tbl_propiedades WHERE _row = @cont) != 'Unico') THEN valor
						ELSE idPropiedad
						END,
						@idClase,
						@idTipoObjetoAct,
						@idObjetoActual,
					CASE 
						WHEN ((SELECT TOP 1 idTipoValor FROM @tbl_propiedades WHERE _row = @cont) != 'Unico') THEN ''
						ELSE @valorG
						END,
						@UserId,
						@activo
				FROM @tbl_propiedades
				WHERE _row = @cont
			END

        ELSE IF(@propiedad = 'clase')
            BEGIN
			DECLARE @valorIns varchar(500);
				IF (@idDocumentoClase > 0)
					BEGIN
					SET @valorIns =  @idDocumentoClase;
					END
				ELSE 
					BEGIN
					SET @valorIns =  @valor;
					END

				INSERT INTO [objeto].[ObjetoPropiedadClase]
				SELECT
					@idClase,
					CASE 
						WHEN ((SELECT TOP 1 idTipoValor FROM @tbl_propiedades WHERE _row = @cont) != 'Unico') THEN valor
						ELSE idPropiedad
						END,
					@idTipoObjetoAct,
					@idObjetoActual,
					CASE
						WHEN ((SELECT TOP 1 idTipoValor FROM @tbl_propiedades WHERE _row = @cont) != 'Unico') THEN ''
						ELSE @valorIns
						END,
					@UserId,
					@activo
				FROM @tbl_propiedades
				WHERE _row = @cont

            END
        ELSE IF(@propiedad = 'contrato')
            BEGIN
				DECLARE @valorCon varchar(500);
				IF (@idDocumentoContrato > 0)
					BEGIN
					SET @valorCon =  @idDocumentoContrato;
					END
				ELSE 
					BEGIN
					SET @valorCon =  @valor;
					END

				INSERT INTO [objeto].[ObjetoPropiedadContrato]
				SELECT
					@rfcEmpresa,
					@idCliente,
					@numeroContrato,
					CASE 
						WHEN ((SELECT TOP 1 idTipoValor FROM @tbl_propiedades WHERE _row = @cont) != 'Unico') THEN valor
						ELSE idPropiedad
						END,
					@idClase,
					@idTipoObjetoAct,
					@idObjetoActual,
					CASE
						WHEN ((SELECT TOP 1 idTipoValor FROM @tbl_propiedades WHERE _row = @cont) != 'Unico') THEN ''
						ELSE @valorCon
						END,
					@UserId,
					@activo
				FROM @tbl_propiedades
				WHERE _row = @cont
            END
        SET @cont = @cont + 1
	END

	
	DECLARE @llave VARCHAR(MAX) = '{"idObjeto":"' + CAST(@idObjeto AS VARCHAR(50)) + '","idClase":"' + @idClase + '","rfcEmpresa":"' + @rfcEmpresa + '","idCliente":"' + 
	CAST(@idCliente AS VARCHAR(50)) + '","numeroContrato":"' + @numeroContrato + '"}'

		EXEC [evento].[evento].[INS_EVENTO]
		@accion = 2
		,@modulo = 172
		,@gerencia = 1
		,@llave = @llave
		,@origen = NULL
		,@applicationId = 11
		,@idEstado = NULL
		,@idContratoZona = NULL
		,@idUsuario = @UserId
		,@err = ''


	SET @err = 'El Usuario se registro correctamente.'
	COMMIT
END TRY

BEGIN CATCH
        SET @err = 'Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.'
		SELECT @err
ROLLBACK
END CATCH

/*	SELECT * FROM [objeto].[ObjetoPropiedadGeneral] 
				WHERE idObjeto = @idObjeto 
				AND activo = 1
END*/
go

