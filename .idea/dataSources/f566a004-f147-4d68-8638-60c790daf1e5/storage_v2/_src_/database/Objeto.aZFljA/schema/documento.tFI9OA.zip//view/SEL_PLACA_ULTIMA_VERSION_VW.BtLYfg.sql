-- =============================================
-- Author:			<Miguel Angel Reyes Xinaxtle>
-- Create date: 	<03/06/2019>
-- Description:	    <Vista para obtener las placas reales>
-- =============================================
-- SELECT 
    -- [idDocumentoClase]
    -- ,[idClase]
    -- ,[idTipoObjeto]
    -- ,[idObjeto]
    -- ,[version]
    -- ,[idTipoDocumento]
    -- ,[idFileServer]
    -- ,[vigencia]
    -- ,[valor]
    -- ,[idUsuario]
    -- ,[fecha]
    -- ,[idCostoDocumentoClase]
    -- ,[idEstado]
    -- ,[comentario]
-- FROM [documento].[SEL_PLACA_ULTIMA_VERSION_VW]
-- =============================================
CREATE VIEW [documento].[SEL_PLACA_ULTIMA_VERSION_VW]
AS

SELECT 
    [idDocumentoClase]
    ,[idClase]
    ,[idTipoObjeto]
    ,[idObjeto]
    ,[version]
    ,[idTipoDocumento]
    ,[idFileServer]
    ,[vigencia]
    ,[valor]
    ,[idUsuario]
    ,[fecha]
    ,[idCostoDocumentoClase]
    ,[idEstado]
    ,[comentario]
FROM [documento].[SEL_DOCUMENTOS_CLASE_ULTIMA_VERSION_VW]
WHERE [idDocumentoClase] = 18
go

