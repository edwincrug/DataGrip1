
CREATE procedure [dbo].[DEL_PROVEEDOR_ENCABEZADO_DOCUMENTO_SP] (
	@idProveedorEncabezadoDocumento numeric(18,0)
	
)
as
begin

	DELETE 
		FROM ProveedorEncabezadoDocumento 
	where idProveedorEncabezadoDocumento = @idProveedorEncabezadoDocumento
           
    SELECT @idProveedorEncabezadoDocumento

end
go

