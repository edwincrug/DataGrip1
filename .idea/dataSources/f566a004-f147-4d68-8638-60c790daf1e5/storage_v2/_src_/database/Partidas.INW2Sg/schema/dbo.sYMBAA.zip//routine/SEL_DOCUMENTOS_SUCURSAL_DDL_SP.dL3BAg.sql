
CREATE procedure [dbo].[SEL_DOCUMENTOS_SUCURSAL_DDL_SP] 
as
begin

	SELECT
		idDocumento as value,
		descripcion as label
	FROM
		dbo.Documento doc
	WHERE
		doc.estatus = 1
		and doc.idTipoDocumento = 2

end
go

