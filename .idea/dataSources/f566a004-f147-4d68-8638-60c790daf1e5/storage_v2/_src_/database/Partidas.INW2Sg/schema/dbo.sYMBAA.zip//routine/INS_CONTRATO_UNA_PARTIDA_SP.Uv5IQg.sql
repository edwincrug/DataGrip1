CREATE procedure [dbo].[INS_CONTRATO_UNA_PARTIDA_SP] (
	@idUsuario numeric(18,0),
	@idUnidad numeric(18,0),
	@idContrato numeric(18,0),
	@json nvarchar(max)
)
as
begin


	DECLARE @venta as decimal(18,2)
	DECLARE @ventaTotalizada as decimal(18,2)
	DECLARE @idContratoUnidad as decimal(18,2)
	DECLARE @idPartida as decimal(18,2)


	DECLARE
		@precio1			decimal(18,2),
		@precio2			decimal(18,2),
		@precio3			decimal(18,2),
		@precio4			decimal(18,2),
		@precio5			decimal(18,2),
		@precio6			decimal(18,2),
		@precio7			decimal(18,2),
		@precioMano			decimal(18,2),
		@precioRefaccion	decimal(18,2),
		@precioLubricante	decimal(18,2),
		@tiempo				time(7),
		@precioLlanta	decimal(18,2),
		@precioHojalateria	decimal(18,2)
	
	SELECT @idContratoUnidad = idContratoUnidad FROM ContratoUnidad WHERE idUnidad = @idUnidad AND idContrato = @idContrato
	
	--CREAMOS TABLA TEMPORAL PARA EL JSON
	CREATE TABLE #JSON(
		element_id numeric(18,0),
		secuenceNo numeric(18,0),
		parent_ID numeric(18,0),
		Object_ID numeric(18,0),
		NAME nvarchar(MAX),
		StringValue nvarchar(MAX),
		ValueType nvarchar(MAX)
	)

	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@json)

	--Insertar cotizaciones
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 
	SELECT Object_ID FROM #JSON
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idPartida = REPLACE(StringValue,'"','')  FROM #JSON
			WHERE 
			parent_ID = @parent
			AND NAME = 'id'
			AND Object_ID IS NULL
		
			
		SELECT @venta = REPLACE(StringValue,'"','')  FROM #JSON
			WHERE 
			parent_ID = @parent
			AND NAME = 'v'
			AND Object_ID IS NULL
		
		SELECT @precio1 = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'p1'
			AND Object_ID IS NULL

		SELECT @precio2 = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'p2'
			AND Object_ID IS NULL

		SELECT @precio3 = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'p3'
			AND Object_ID IS NULL

		SELECT @precio4 = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'p4'
			AND Object_ID IS NULL

		SELECT @precio5 = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'p5'
			AND Object_ID IS NULL
		SELECT @precio6 = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'p6'
			AND Object_ID IS NULL
		SELECT @precio7 = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'p7'
			AND Object_ID IS NULL

		SELECT @precioMano = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'pM'
			AND Object_ID IS NULL

			SELECT @precioRefaccion = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'pR'
			AND Object_ID IS NULL

		SELECT @precioLubricante = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'pL'
			AND Object_ID IS NULL

		SELECT @tiempo = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 't'
			AND Object_ID IS NULL

		SELECT @precioLlanta = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'pLl'
			AND Object_ID IS NULL

		SELECT @precioHojalateria = REPLACE(StringValue,'"','') FROM #JSON
			WHERE
			parent_ID = @parent
			AND NAME = 'pH'
			AND Object_ID IS NULL

		set @ventaTotalizada = ISNULL(@precioMano,0) + ISNULL(@precioRefaccion,0) + ISNULL(@precioLubricante,0) + ISNULL(@precioLlanta,0) + ISNULL(@precioHojalateria,0)


		if not exists (select 1 from ContratoPartida where idContratoUnidad = @idContratoUnidad and idPartida = @idPartida)
		begin
			INSERT INTO dbo.ContratoPartida
				(idContratoUnidad, idPartida, venta, fecha, idUsuario,precio1,precio2,precio3,precio4,precio5,precio6,precio7, precioMano, precioRefaccion, precioLubricante, tiempo, precioLlanta, precioHojalateria)
			VALUES 
				( @idContratoUnidad, @idPartida, @venta,  GETDATE(), @idUsuario,@precio1,@precio2,@precio3,@precio4,@precio5, @precio6,@precio7, @precioMano,  @precioRefaccion, @precioLubricante, @tiempo, @precioLlanta, @precioHojalateria)
		end
		else
		begin

		IF @idContrato = 46
		BEGIN
			SET @venta = @ventaTotalizada
		END

			update dbo.ContratoPartida
				set 
					venta = @venta,
					fecha = GETDATE(),
					precio1 = @precio1,
					precio2 = @precio2,
					precio3 = @precio3,
					precio4 = @precio4,
					precio5 = @precio5,
					precio6 = @precio6,
					precio7 = @precio7,
					precioMano = @precioMano,
					precioRefaccion = @precioRefaccion,
					precioLubricante = @precioLubricante,
					tiempo = @tiempo,
					precioLlanta = @precioLlanta,
					precioHojalateria = @precioHojalateria
				where 
					idContratoUnidad = @idContratoUnidad 
					and idPartida = @idPartida
		end
		FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	
	SELECT @idContratoUnidad as idContratoUnidad


end
go

