CREATE PROCEDURE [dbo].[INS_PROVEEDOR_TIPO_UNIDAD_SP] (
	@idProveedor numeric(18,0),
	@json nvarchar(max)
)
as
begin

	DECLARE @idTipoUnidad AS numeric(18,0)
	
	--Insertar cotizaciones
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 

	SELECT Object_ID FROM parseJSON(@json)
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idTipoUnidad = REPLACE(StringValue,'"','')  FROM parseJSON(@json)
			WHERE 
			parent_ID = @parent
			AND NAME = 'idTipoUnidad'
			AND Object_ID IS NULL
	
		INSERT INTO dbo.ProveedorTipoUnidad
			(idProveedor, idTipoUnidad)
		VALUES 
			(@idProveedor , @idTipoUnidad);
	
	FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	
	SELECT @idProveedor as idProveedor

end
go

