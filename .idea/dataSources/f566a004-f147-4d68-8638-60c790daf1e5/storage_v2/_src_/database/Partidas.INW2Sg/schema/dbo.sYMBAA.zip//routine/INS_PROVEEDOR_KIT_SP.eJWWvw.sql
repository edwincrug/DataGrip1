CREATE procedure [dbo].[INS_PROVEEDOR_KIT_SP] (
	@idProveedorCotizacion numeric(18,0),
	@idUsuario numeric(18,0),
	@json nvarchar(max)
)
as
begin


	DECLARE @costoPieza as decimal(18,2)
	DECLARE @costoMano as decimal(18,2)
	DECLARE @tiempo as time(7)
	DECLARE @idKit as decimal(18,2)
	
	--Insertar cotizaciones
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 

	SELECT Object_ID FROM parseJSON(@json)
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idKit = REPLACE(StringValue,'"','')  FROM parseJSON(@json)
			WHERE 
			parent_ID = @parent
			AND NAME = 'idKit'
			AND Object_ID IS NULL
			
		SELECT @costoPieza = REPLACE(StringValue,'"','')  FROM parseJSON(@json)
			WHERE 
			parent_ID = @parent
			AND NAME = 'costoPieza'
			AND Object_ID IS NULL
	
		SELECT @costoMano = REPLACE(StringValue,'"','')  FROM parseJSON(@json)
			WHERE 
			parent_ID = @parent
			AND NAME = 'costoMano'
			AND Object_ID IS NULL
			
		SELECT @tiempo = REPLACE(StringValue,'"','')  FROM parseJSON(@json)
			WHERE 
			parent_ID = @parent
			AND NAME = 'tiempo'
			AND Object_ID IS NULL
	
			
		IF( EXISTS(SELECT 1 FROM dbo.ProveedorKit WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idKit = @idKit) ) BEGIN
	
			UPDATE
				dbo.ProveedorKit
			SET
				costoPieza = @costoPieza,
				costoMano = @costoMano,
				costo = (@costoPieza + @costoMano),
				tiempo = @tiempo,
				fecha = GETDATE(),
				idUsuario = @idUsuario,
				idPartidaEstatus = 3
			WHERE 
				idProveedorCotizacion = @idProveedorCotizacion 
				AND  idKit = @idKit
		END
		ELSE BEGIN
		
			INSERT INTO dbo.ProveedorKit
				(idProveedorCotizacion, idKit, costoPieza, costoMano, costo, tiempo, fecha, idUsuario, idPartidaEstatus)
			VALUES 
				(@idProveedorCotizacion, @idKit, @costoPieza,@costoMano, (@costoPieza + @costoMano), @tiempo, GETDATE(), @idUsuario, 2)
		
		END
	
	FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	
	
	UPDATE
		dbo.ProveedorCotizacion
	SET
		idCotizacionEstatus = 2
	WHERE 
		idProveedorCotizacion = @idProveedorCotizacion
	
	SELECT @idProveedorCotizacion as idProveedorCotizacion


end
go

