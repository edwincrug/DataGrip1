CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_ESPECIALIDAD_SP] (
	@idProveedor numeric(18,0)
)
as
begin

	SELECT
		esp.idEspecialidad,
		esp.especialidad
	FROM
		dbo.Especialidad esp
	WHERE 
		esp.estatus = 1
		and idEspecialidad not in(
			SELECT
				pes.idEspecialidad
			FROM
				dbo.ProveedorEspecialidad pes
			WHERE 
				pes.idProveedor = @idProveedor
		) 
		

end
go

