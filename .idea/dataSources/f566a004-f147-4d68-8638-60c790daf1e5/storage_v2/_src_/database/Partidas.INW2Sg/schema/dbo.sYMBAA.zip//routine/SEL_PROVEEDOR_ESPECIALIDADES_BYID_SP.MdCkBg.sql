-- =============================================
-- Author:		<Alan Rosales>
-- Create date: <09/08/2017 13:46:00>
-- Description:	<Seleccion de Combustibles Aplicables para el proveedor>
-- =============================================
--SEL_PROVEEDOR_ESPECIALIDADES_BYID_SP 313
CREATE PROCEDURE SEL_PROVEEDOR_ESPECIALIDADES_BYID_SP
	-- Add the parameters for the stored procedure here
	@idProveedor	numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	select 
		PE.idEspecialidad,
		PE.idTipoCombustible,
		E.especialidad,
		TC.tipoCombustible
	from  ProveedorEspecialidadCombustible PE
	inner join Especialidad E on PE.idEspecialidad=E.idEspecialidad
	inner join TipoCombustible TC on PE.idTipoCombustible=TC.idTipoCombustible
	where PE.idProveedor = @idProveedor
	order by TC.idTipoCombustible
END
go

