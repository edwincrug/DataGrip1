--[dbo].[SEL_MARCADOR_SP] 1
CREATE procedure [dbo].[SEL_MARCADOR_SP] (  
 @idUsuario numeric(18,0)  
)  
as  
begin  
      SELECT   
        latitud as lat,  
        longitud as lng,  
        cast(idProveedor as nvarchar(10)) as label,  
        pe.razonSocial as nombre,  
        direccion as direccion,  
		pro.idProveedorEncabezado,
		pro.idProveedor,
	    categoria,  
        clasificacion,  
        pe.logo  
       FROM dbo.Proveedor pro left join Categoria cat on pro.idCategoria = cat.idCategoria  
   left join ProveedorClasificacion pc on pc.idProveedorClasificacion = pro.idProveedorClasificacion  
   left join ProveedorEncabezado pe on pe.idProveedorEncabezado = pro.idproveedorencabezado  
      WHERE pro.estatus = 1  
     
  
end
go

