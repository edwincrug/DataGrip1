CREATE procedure [dbo].[SEL_TIPO_UNIDAD_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		idTipoUnidad as value,
		tipo as label
	FROM
		dbo.TipoUnidad
	WHERE
		estatus = 1

end
go

