


CREATE procedure [dbo].[INS_PROVEEDOR_SUCURSAL_DOCUMENTO_SP] (
	@idProveedor numeric(18,0),
	@idDocumento numeric(18,0),
	@archivo nvarchar(500)
)
as
begin

	INSERT INTO [dbo].[ProveedorDocumento]
           ([idProveedor]
           ,[idDocumento]
           ,[archivo]
		   ,[fechaCarga])
     VALUES
           (@idProveedor
           ,@idDocumento
           ,REPLACE(@archivo,'"','')
		   ,GETDATE())
           
     SELECT @@IDENTITY

end
go

