CREATE PROCEDURE [dbo].[DEL_MARCA_SP] (
	@idMarca numeric(18,0)
)
as
begin

	DELETE FROM dbo.Marca WHERE idMarca = @idMarca
	
	SELECT @idMarca

end
go

