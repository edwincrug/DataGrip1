CREATE PROCEDURE [dbo].[SEL_CILINDROS_DDL_SP] 
	@idUsuario numeric(18,0)
AS
BEGIN

	SELECT [idCilindros] as value
		  ,[cilindros] as label
	  FROM [dbo].[Cilindros]


END
go

