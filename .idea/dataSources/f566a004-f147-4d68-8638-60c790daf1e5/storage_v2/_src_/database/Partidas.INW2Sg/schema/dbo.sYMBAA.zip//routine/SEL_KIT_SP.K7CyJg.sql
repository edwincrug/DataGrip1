CREATE PROCEDURE [dbo].[SEL_KIT_SP] (
	@idUsuario numeric(18,0),
	@idUnidad numeric(18,0)
)
as
begin

	SELECT
		idKit,
		idUnidad,
		partida,
		descripcion,
		instructivo,
		(select count(1) from KitPartida where idKit = kit.idKit ) as partidas,
		estatus
	FROM
		dbo.Kit kit
	Where 
		estatus = 1
		AND idUnidad = @idUnidad


end
go

