CREATE procedure [dbo].[UPD_LICITACION_SP](
	@idLicitacion numeric(18,0),
	@idCliente numeric(18,0),
	@idClienteFinal numeric(18,0),
	@idEmpresa numeric(18,0),
	@folio nvarchar(50),
	@nombre nvarchar(200),
	@descripcion nvarchar(500),
	@fechaInicio datetime
)
as
begin
		
	UPDATE
		dbo.Licitacion
	SET
		idCliente = @idCliente,
		idClienteFinal = @idClienteFinal,
		idEmpresa = @idEmpresa,
		folio = @folio,
		nombre = @nombre,
		descripcion = @descripcion,
		fechaInicio = @fechaInicio
	WHERE 
		idLicitacion = @idLicitacion
		
	SELECT @idLicitacion

end
go

