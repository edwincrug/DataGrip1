CREATE PROCEDURE [dbo].[INS_PROVEEDOR_ZONA_SP] (
	@idUsuario numeric(18,0),
	@idContratoProveedor numeric(18,0),
	@json as nvarchar(max)
)
as
begin

	--Elimino la selección previa
	DELETE FROM dbo.ContratoProveedorZona WHERE idContratoProveedor = @idContratoProveedor

	DECLARE @idZona AS numeric(18,0)

	--CREAMOS TABLA TEMPORAL PARA EL JSON
	CREATE TABLE #JSON(
		element_id numeric(18,0),
		secuenceNo numeric(18,0),
		parent_ID numeric(18,0),
		Object_ID numeric(18,0),
		NAME nvarchar(MAX),
		StringValue nvarchar(MAX),
		ValueType nvarchar(MAX)
	)

	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@json)
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 
	SELECT Object_ID FROM #JSON
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
			SELECT @idZona = REPLACE(StringValue,'"','')  FROM #JSON
			WHERE 
			parent_ID = @parent
			AND NAME = 'IdZona'
			AND Object_ID IS NULL
	
			INSERT INTO dbo.ContratoProveedorZona
				( idContratoProveedor, idZona)
			VALUES 
				( @idContratoProveedor , @idZona)
		FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	



	SELECT @idContratoProveedor
	
end
go

