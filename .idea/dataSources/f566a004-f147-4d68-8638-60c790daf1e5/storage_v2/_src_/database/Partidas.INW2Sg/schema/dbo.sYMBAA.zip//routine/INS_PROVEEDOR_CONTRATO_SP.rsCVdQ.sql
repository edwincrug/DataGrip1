/*
SP Para carga Masiva de proveedores desde la seccion de contratos
JAGA 04/10/2019
*/
CREATE procedure [dbo].[INS_PROVEEDOR_CONTRATO_SP] (
	@idContrato numeric(18,0),
	@idProveedor numeric(18,0),
	@auxiliar int = 0
)
as
begin

	IF EXISTS(SELECT * FROM Proveedor WHERE idProveedor=@idProveedor)
	BEGIN
		IF NOT EXISTS(SELECT * FROM ContratoProveedor WHERE idProveedor=@idProveedor AND idContrato=@idContrato)
		begin
		INSERT INTO ContratoProveedor
		SELECT @idContrato,@idProveedor

		SELECT @@IDENTITY AS id, 'Se inserto Correctamente' AS Respuesta
		end
		else
		BEGIN
		SELECT -1000 AS id, 'Ya Existe' AS Respuesta
		END
	END
	ELSE
	BEGIN
	SELECT -1 AS id, 'El proveedor con id ' + CAST(@idProveedor AS VARCHAR(10)) + ' no existe' AS Respuesta
	END
END
go

