CREATE PROCEDURE [dbo].[SEL_CLIENTE_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	
	SELECT
		idCliente as value,
		razonSocial + ' - ' + nombreComercial + ' - RFC: ' + rfc  as label
	FROM
		dbo.Cliente
	WHERE
		estatus = 1

end
go

