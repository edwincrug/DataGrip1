CREATE procedure [dbo].[SEL_KIT_PARTIDAS_SP] (
	@idKit numeric(18,0)
	,@idProveedorCotizacion numeric(18,0) = NULL
)
as
begin

	SELECT distinct
		par.idPartida,
		esp.idEspecialidad,
		esp.especialidad,
		cl1.idPartidaClasificacion,
		cl1.clasificacion,
		cl2.idPartidaSubClasificacion,
		cl2.subClasificacion,
		partida,
		noParte,
		par.descripcion,
		kpa.cantidad,
		par.foto,
		par.instructivo
	FROM
		dbo.KitPartida kpa
		LEFT JOIN dbo.Partida par ON par.idPartida = kpa.idPartida
		LEFT JOIN dbo.Unidad uni ON uni.idUnidad = par.idUnidad
		LEFT JOIN ProveedorCotizacion pco ON pco.idUnidad = uni.idUnidad
		LEFT JOIN ProveedorPartida ppa ON ppa.idPartida = par.idPartida AND ppa.idProveedorCotizacion = pco.idProveedorCotizacion
		LEFT JOIN dbo.Especialidad esp ON esp.idEspecialidad = par.idEspecialidad
		LEFT JOIN PartidaClasificacion cl1 ON cl1.idPartidaClasificacion = par.idPartidaClasificacion
		LEFT JOIN PartidaSubClasificacion cl2 ON cl2.idPartidaSubClasificacion = par.idPartidaSubClasificacion
		LEFT JOIN PartidaEstatus pes ON pes.idPartidaEstatus = ppa.idPartidaEstatus
	WHERE 
		par.estatus = 1
		and kpa.idKit = @idKit
	--	and pco.idProveedorCotizacion = COALESCE( @idProveedorCotizacion, pco.idProveedorCotizacion)
		

end
go

