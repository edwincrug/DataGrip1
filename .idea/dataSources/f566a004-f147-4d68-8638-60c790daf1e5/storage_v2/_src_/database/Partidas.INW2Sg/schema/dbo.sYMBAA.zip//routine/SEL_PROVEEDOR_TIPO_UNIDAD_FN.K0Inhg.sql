create function [dbo].[SEL_PROVEEDOR_TIPO_UNIDAD_FN] (
	@idProveedor numeric(18,0)
)
RETURNS nvarchar(max)
as
begin

	DECLARE @result nvarchar(max)
	
	SET @result = ''
	
	SELECT @result = @result + tun.tipo + ' | ' 
	FROM dbo.Proveedor pro
		LEFT JOIN dbo.ProveedorTipoUnidad ptu ON ptu.idProveedor = pro.idProveedor
		LEFT JOIN dbo.TipoUnidad tun ON tun.idTipoUnidad = ptu.idTipoUnidad
	 WHERE  pro.idProveedor = @idProveedor
	 
	select @result = substring(@result, 0, len(@result) - 1) 
	
	return @result

end
go

