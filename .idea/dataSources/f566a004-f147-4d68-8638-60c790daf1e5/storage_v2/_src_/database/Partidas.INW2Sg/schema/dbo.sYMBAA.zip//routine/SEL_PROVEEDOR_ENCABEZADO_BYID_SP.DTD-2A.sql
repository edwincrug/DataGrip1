CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_ENCABEZADO_BYID_SP] (
	@idProveedorEncabezado numeric(18,0)
)
as
begin

	SELECT				
		pro.[idProveedorEncabezado]
	      ,[nombreComercial]
	      ,[razonSocial]
	      ,[RFC]
	      ,[contacto]
	      ,[telefono]
	      ,[mail]
	      ,fechaInicio
	      ,isnull(cat.[idCategoria],0) as idCategoria
		, cat.categoria
		,dbo.SEL_PROVEEDOR_ENCABEZADO_ESPECIALIDAD_FN(pro.idProveedorEncabezado) especialidades
		--,dbo.SEL_PROVEEDOR_TIPO_UNIDAD_FN(pro.idProveedorEncabezado) tipoUnidad
	      ,[idProveedorClasificacion]
	      ,[idProveedorSubClasificacion]
	       ,isnull(pro.[tipoPersona],'FIS') as tipoPersona
		,pro.[pais] 
		,pro.[estado] 
		,pro.[ciudad]
		,pro.[delegacion] 
		,pro.[colonia] 
		,pro.[calle]
		,pro.[numInt] 
		,pro.[numExt] 
		,pro.[cp] 
		,pro.[lada]
		,pro.logo

	FROM
		dbo.ProveedorEncabezado pro
		LEFT JOIN Categoria cat ON cat.idCategoria = pro.idCategoria
		--LEFT JOIN ProveedorDatosFiscales pdf ON pdf.idProveedor = pro.idProveedorEncabezado
		--LEFT JOIN ProveedorEncabezadoDatosFiscales pdf ON pdf.idProveedorEncabezado = pro.idProveedorEncabezado
	WHERE 
		pro.estatus = 1
		AND pro.idProveedorEncabezado = @idProveedorEncabezado
		
		

end
go

