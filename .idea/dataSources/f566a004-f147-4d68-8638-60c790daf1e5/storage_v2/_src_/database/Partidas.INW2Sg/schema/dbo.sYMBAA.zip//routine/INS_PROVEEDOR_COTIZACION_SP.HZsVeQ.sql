CREATE procedure [dbo].[INS_PROVEEDOR_COTIZACION_SP] (
	@idProveedor numeric(18,0),
	@idUnidad numeric(18,0),
	@idUsuario numeric(18,0)
)
as
begin

DECLARE @idProveedorCotizacion INT,@existeIdProveedor INT

SET @idProveedorCotizacion = (SELECT TOP 1 idProveedorCotizacion FROM ProveedorCotizacion WHERE idProveedor=@idProveedor and idUnidad=@idUnidad)
SET @existeIdProveedor = (SELECT COUNT(*) FROM Proveedor WHERE idProveedor=@idProveedor)

IF @existeIdProveedor>0 
BEGIN
	IF @idProveedorCotizacion IS NOT NULL
	BEGIN
	UPDATE ProveedorCotizacion
	SET fecha=GETDATE(), idCotizacionEstatus=3
	WHERE idProveedorCotizacion=@idProveedorCotizacion

	INSERT [dbo].[ProveedorCotizacionBitacora]
	SELECT idProveedorCotizacion,idProveedor,idUnidad,GETDATE(),idCotizacionEstatus,@idUsuario,'ACTUALIZÓ' FROM ProveedorCotizacion
	WHERE idProveedorCotizacion=@idProveedorCotizacion

	END
	ELSE
	BEGIN
	INSERT INTO ProveedorCotizacion(idProveedor, idUnidad, fecha, idCotizacionEstatus)
	SELECT @idProveedor,@idUnidad,GETDATE(),3
	SET @idProveedorCotizacion = (SELECT TOP 1 idProveedorCotizacion FROM ProveedorCotizacion WHERE idUnidad=@idUnidad AND idProveedor=@idProveedor ORDER BY idProveedorCotizacion DESC)
	INSERT [dbo].[ProveedorCotizacionBitacora]
	SELECT idProveedorCotizacion,idProveedor,idUnidad,GETDATE(),idCotizacionEstatus,@idUsuario,'INSERTÓ' FROM ProveedorCotizacion
	WHERE idProveedorCotizacion=@idProveedorCotizacion

	END

	SELECT @idProveedorCotizacion as idProveedorCotizacion
END
ELSE
BEGIN
SELECT -100 as idProveedorCotizacion
END

end
go

