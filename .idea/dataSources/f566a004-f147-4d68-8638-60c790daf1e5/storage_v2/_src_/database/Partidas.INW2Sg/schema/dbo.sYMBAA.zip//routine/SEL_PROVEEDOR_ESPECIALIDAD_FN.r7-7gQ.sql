create function [dbo].[SEL_PROVEEDOR_ESPECIALIDAD_FN] (
	@idProveedor numeric(18,0)
)
RETURNS nvarchar(max)
as
begin

	DECLARE @result nvarchar(max)
	
	SET @result = ''
	
	SELECT @result = @result + esp.especialidad + ' | ' 
	FROM dbo.Proveedor pro
		LEFT JOIN dbo.ProveedorEspecialidad pes ON pes.idProveedor = pro.idProveedor
		LEFT JOIN dbo.Especialidad esp ON esp.idEspecialidad = pes.idEspecialidad
	 WHERE  pro.idProveedor = @idProveedor
	 
	select @result = substring(@result, 0, len(@result) - 1) 
	
	return @result

end
go

