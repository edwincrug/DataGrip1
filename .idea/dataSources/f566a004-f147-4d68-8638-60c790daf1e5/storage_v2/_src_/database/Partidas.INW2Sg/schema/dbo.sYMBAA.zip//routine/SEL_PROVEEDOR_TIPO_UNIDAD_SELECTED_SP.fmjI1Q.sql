CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_TIPO_UNIDAD_SELECTED_SP] (
	@idProveedor numeric(18,0)
)
as
begin

	SELECT
		ptu.idProveedorTipoUnidad,
		ptu.idProveedor,
		ptu.idTipoUnidad,
		tun.tipo
	FROM
		dbo.ProveedorTipoUnidad ptu
		LEFT JOIN dbo.TipoUnidad tun ON tun.idTipoUnidad = ptu.idTipoUnidad
	WHERE 
		tun.estatus = 1
		and ptu.idProveedor = @idProveedor
		

end
go

