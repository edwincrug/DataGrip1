CREATE PROCEDURE [dbo].[INS_PROCESA_CARGADOCUMENTO_SP]
	--@idCargaDocumento numeric(18,0),
	--@nombreArchivo VARCHAR(MAX),
	--@idUsuario numeric(18,0)
AS
BEGIN
--DECLARE @nombreArchivo VARCHAR(MAX)='Layout_Costos.xlsx'
DECLARE @idCargaDocumentoE numeric(18,0)
BEGIN TRY

	DECLARE @CargaDocumentos TABLE(id int identity(1,1),[idCargaDocumento] numeric(18,0), [nombreArchivo] VARCHAR(MAX), [idUsuario] numeric(18,0))

	INSERT INTO @CargaDocumentos
	SELECT idCargaDocumento,nombreArchivo,idUsuario FROM CargaDocumento WHERE idEstatusCargaMasiva= 1 
	ORDER BY idCargaDocumento

	DECLARE @i int = 1, @n int =(SELECT COUNT(*) FROM @CargaDocumentos)
	DECLARE @idCargaDocumento numeric(18,0), @nombreArchivo VARCHAR(MAX), @idUsuario numeric(18,0)
	
	WHILE @i<= @n
	BEGIN

	SELECT @idCargaDocumento=idCargaDocumento,@nombreArchivo=nombreArchivo, @idUsuario=idUsuario  FROM @CargaDocumentos WHERE id=@i
	SET @idCargaDocumentoE = @idCargaDocumento

		IF OBJECT_ID('tempdb..#DatosExcel') IS NOT NULL
		DROP TABLE #DatosExcel

		CREATE TABLE #DatosExcel(id int identity(1,1), idCargaDocumentoDetalle int, IdSucursal NUMERIC(18,0),IdUnidad NUMERIC(18,0),IdPartida NUMERIC(18,0), CostoPieza MONEY, CostoMano MONEY, Costo MONEY)

		IF EXISTS(SELECT * FROM CargaDocumento WHERE idEstatusCargaMasiva=2)
		BEGIN
		 SELECT 'Existe archivo en proceso' AS Respuesta
		END
		ELSE
		BEGIN

		/*SE EXTRAEN LOS DATOS DEL ARCHIVO EXCEL Y SE GUARDAN EN UNA TABLA DEL SERVIDOR .18*/
		EXEC [192.168.20.18].[Partidas].[dbo].[SEL_DATOS_CARGADOCUMENTO_SP]  @nombreArchivo, @idCargaDocumento

		/*SE CONSULTAN LOS REGISTROS Y SE GUARDAN EN UNA TABLA TEMPORAL*/
		INSERT INTO #DatosExcel
		SELECT * FROM [192.168.20.18].[Partidas].[dbo].[CargaDocumentoDetalle]

		IF (SELECT COUNT(*) FROM #DatosExcel)>0
		BEGIN
			/*SE PONE EN PROCESO EL ARCHIVO*/
			UPDATE CargaDocumento SET idEstatusCargaMasiva=2 WHERE idCargaDocumento=@idCargaDocumento
		END

		--SELECT * FROM @DatosExcel
		--DECLARE @i int= (SELECT MIN(id) FROM #DatosExcel), @n int= (SELECT COUNT(*) FROM #DatosExcel)
		DECLARE @IdSucursal NUMERIC(18,0),@IdUnidad NUMERIC(18,0),@IdPartida NUMERIC(18,0), @CostoPieza MONEY, @CostoMano MONEY, @Costo MONEY

		DECLARE @idProveedorCotizacion INT,@idProveedorPartida INT,@existePartida INT

			DECLARE DatosExcel CURSOR FOR SELECT IdSucursal, IdUnidad,IdPartida, CostoPieza, CostoMano, Costo FROM #DatosExcel
			OPEN DatosExcel
			FETCH NEXT FROM DatosExcel INTO @IdSucursal ,@IdUnidad ,@IdPartida, @CostoPieza, @CostoMano , @Costo 
			WHILE @@fetch_status = 0
			BEGIN
			
				/*SE VERIFICA QUE EXISTE RELACIÓN ENTRE PROVEEDOR - UNIDAD Y PARTIDA - UNIDAD*/
				SET @idProveedorCotizacion = (SELECT TOP 1 idProveedorCotizacion FROM ProveedorCotizacion WHERE idProveedor=@IdSucursal and idUnidad=@idUnidad)
				SET @idProveedorPartida = (SELECT idProveedorPartida FROM dbo.ProveedorPartida WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idPartida = @idPartida)
				SET @existePartida = (SELECT COUNT(idPartida) FROM Partida WHERE idPartida=@idPartida AND idUnidad=@idUnidad)

				IF @idProveedorCotizacion IS NOT NULL AND @existePartida>0
				BEGIN
					IF @idProveedorPartida IS NOT NULL
					BEGIN 
						UPDATE PP 
						SET	costoPieza = @costoPieza,
						costoMano = @costoMano,
						costo = (@costoPieza + @costoMano),
						fecha = GETDATE(),
						idUsuario = @idUsuario,
						idPartidaEstatus = 4
						FROM dbo.ProveedorPartida PP WITH (NOLOCK)
						WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idPartida = @idPartida

						INSERT INTO [dbo].[ProveedorPartidaBitacoraMasiva]
						SELECT @IdSucursal,@IdUnidad,@IdPartida, @CostoPieza, @CostoMano , @Costo, GETDATE(), @idUsuario,@idCargaDocumento,'REGISTRO ACTUALIZADO'

						--SELECT @idProveedorPartida AS IdProveedorPartida

					END
					ELSE 
					BEGIN
						INSERT INTO dbo.ProveedorPartida
							(idProveedorCotizacion, idPartida, costoPieza, costoMano, costo, tiempo, fecha, idUsuario, idPartidaEstatus)
						VALUES 
							(@idProveedorCotizacion, @idPartida, @costoPieza,@costoMano, @costo, 0, GETDATE(), @idUsuario, 4)

						SET @idProveedorPartida = (SELECT @@IDENTITY)

						INSERT INTO [dbo].[ProveedorPartidaBitacoraMasiva]
						SELECT @IdSucursal,@IdUnidad,@IdPartida, @CostoPieza, @CostoMano , @Costo, GETDATE(), @idUsuario,@idCargaDocumento,'REGISTRO INSERTADO'

						--SELECT @idProveedorPartida AS IdProveedorPartida
		
					END
				END
				ELSE
				BEGIN
					IF @idProveedorCotizacion IS NULL
					BEGIN
						INSERT INTO [dbo].[ProveedorPartidaBitacoraMasiva]
						SELECT @IdSucursal,@IdUnidad,@IdPartida, @CostoPieza, @CostoMano , @Costo, GETDATE(), @idUsuario,@idCargaDocumento,'NO EXISTE RELACIÓN PROVEEDOR - UNIDAD'
					END
					IF @existePartida =0
					BEGIN
						INSERT INTO [dbo].[ProveedorPartidaBitacoraMasiva]
						SELECT @IdSucursal,@IdUnidad,@IdPartida, @CostoPieza, @CostoMano , @Costo, GETDATE(), @idUsuario,@idCargaDocumento,'NO EXISTE RELACIÓN UNIDAD - PARTIDA'
					END
				END

				FETCH NEXT FROM DatosExcel INTO @IdSucursal ,@IdUnidad ,@IdPartida, @CostoPieza, @CostoMano , @Costo 
			END
			CLOSE DatosExcel
			DEALLOCATE DatosExcel

			IF (SELECT COUNT(*) FROM #DatosExcel)>0
			BEGIN
				/*SE PONE FINALIZADO EL ARCHIVO*/
				UPDATE CargaDocumento SET idEstatusCargaMasiva=3, fechaFinalizacion=GETDATE() WHERE idCargaDocumento=@idCargaDocumento
			END

		END
		DROP TABLE #DatosExcel
		SET @i = @i +1
	END

	IF EXISTS(SELECT * FROM CargaDocumento WHERE idEstatusCargaMasiva=1 AND idCargaDocumento NOT IN(SELECT idCargaDocumento FROM CargaDocumentoError))
	BEGIN
		EXEC [dbo].[INS_PROCESA_CARGADOCUMENTO_SP]
	END
END TRY  
BEGIN CATCH 

	INSERT INTO [dbo].[CargaDocumentoError]
	SELECT @idCargaDocumentoE,GETDATE(),ERROR_MESSAGE(),ERROR_NUMBER()

	SELECT  
    ERROR_NUMBER() AS NumError  
    ,ERROR_SEVERITY() AS Gravedad
    ,ERROR_MESSAGE() AS MensajeError;
END CATCH 

END
go

