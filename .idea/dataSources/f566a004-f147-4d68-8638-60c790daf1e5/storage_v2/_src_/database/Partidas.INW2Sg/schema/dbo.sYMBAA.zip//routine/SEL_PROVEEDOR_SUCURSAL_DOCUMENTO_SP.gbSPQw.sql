
create procedure [dbo].[SEL_PROVEEDOR_SUCURSAL_DOCUMENTO_SP] (
	@idProveedor numeric(18,0)
)
as
begin

	SELECT
		idProveedorDocumento,
		idProveedor,
		pdo.idDocumento,
		doc.descripcion,
		archivo
	FROM
		dbo.ProveedorDocumento pdo
		LEFT JOIN Documento doc ON doc.idDocumento = pdo.idDocumento
	WHERE
		idProveedor = @idProveedor
		and doc.idTipoDocumento = 2


end
go

