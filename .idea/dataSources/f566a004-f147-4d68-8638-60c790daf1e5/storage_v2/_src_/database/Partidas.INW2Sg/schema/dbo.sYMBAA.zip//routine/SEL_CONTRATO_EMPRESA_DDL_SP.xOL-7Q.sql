CREATE procedure [dbo].[SEL_CONTRATO_EMPRESA_DDL_SP]
as
begin

		SELECT
		idEmpresa as value,
		razonSocial as label
	FROM
		Empresa
	
end
go

