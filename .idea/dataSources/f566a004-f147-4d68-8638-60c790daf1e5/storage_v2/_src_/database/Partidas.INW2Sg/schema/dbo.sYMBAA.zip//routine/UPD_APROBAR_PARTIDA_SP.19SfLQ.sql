create procedure [dbo].[UPD_APROBAR_PARTIDA_SP] (
	@idUsuario numeric(18,0),
	@idProveedorCotizacion numeric(18,0),
	@idPartida numeric(18,0),
	@respuesta smallint
)
as
begin

				
	UPDATE
		dbo.ProveedorPartida
	SET
		idPartidaEstatus = @respuesta
	WHERE 
		idProveedorCotizacion = @idProveedorCotizacion
		AND idPartida = @idPartida
		
	SELECT @idProveedorCotizacion

end
go

