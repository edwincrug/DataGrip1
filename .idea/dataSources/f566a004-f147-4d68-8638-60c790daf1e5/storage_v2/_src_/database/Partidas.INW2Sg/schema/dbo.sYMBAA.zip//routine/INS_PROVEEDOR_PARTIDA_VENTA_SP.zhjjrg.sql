CREATE procedure [dbo].[INS_PROVEEDOR_PARTIDA_VENTA_SP] (
	@idContrato numeric(18,0),
	@idUnidad numeric(18,0),
	@idUsuario numeric(18,0),
	@idPartida numeric(18,0),
	@precioRefaccion decimal(18,2),
	@precioMano decimal(18,2),
	@precioVenta decimal(18,2),
	@precioLubricante decimal(18,2)
)
as
begin

--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; -- turn it on

DECLARE @existeContratoUnidad int,@idContratoUnidad INT
DECLARE @idContratoPartida INT

SELECT @existeContratoUnidad=COUNT(*) FROM ContratoUnidad
WHERE idUnidad=@idUnidad and idContrato=@idContrato

SELECT @idContratoUnidad=idContratoUnidad FROM ContratoUnidad
WHERE idUnidad=@idUnidad and idContrato=@idContrato

IF @existeContratoUnidad=0
BEGIN
PRINT 'SE INSERTA CONTRATO ' +@idContrato+' - '+@idUnidad
INSERT INTO ContratoUnidad
SELECT @idContrato,@IdUnidad
SET @idContratoUnidad = (SELECT @@IDENTITY)
END

SET @idContratoPartida=(SELECT idContratoPartida FROM ContratoPartida
WHERE idPartida=@IdPartida AND idContratoUnidad=@idContratoUnidad)

IF @idContratoPartida IS NULL
BEGIN
--PRINT 'SE INSERTA '+ CAST(@IdPartida AS VARCHAR(500)) + ' ' + CAST(@idContratoUnidad AS VARCHAR(500))
INSERT INTO ContratoPartida (idContratoUnidad, idPartida, venta, fecha, idUsuario, precio1, precio2, precio3, precio4, precio5, precio6, precio7, precioMano, precioRefaccion, precioLubricante, tiempo, precio7Respaldo)
SELECT @idContratoUnidad,@IdPartida,@PrecioVenta,GETDATE(),@idUsuario,0,0,0,0,0,0,0,@PrecioMano, @PrecioRefaccion,@PrecioLubricante,'00:00:00.0000000',0
SET @idContratoPartida = (SELECT @@IDENTITY)
INSERT INTO [dbo].[ContratoPartidaBitacora]
SELECT @idContratoPartida,@idContratoUnidad,@IdPartida,@PrecioVenta,GETDATE(),@idUsuario,0,0,0,0,0,0,0,@PrecioMano, @PrecioRefaccion,@PrecioLubricante,'00:00:00.0000000',0,'INSERTÓ'

END
ELSE
BEGIN
--PRINT 'SE ACTUALIZA '+ CAST(@idContratoPartida AS VARCHAR(500))
UPDATE ContratoPartida 
SET venta=@PrecioVenta,precioMano=@PrecioMano,precioRefaccion=@PrecioRefaccion,precioLubricante= @PrecioLubricante
WHERE idContratoPartida=@idContratoPartida
INSERT INTO [dbo].[ContratoPartidaBitacora]
SELECT @idContratoPartida,@idContratoUnidad,@IdPartida,@PrecioVenta,GETDATE(),@idUsuario,0,0,0,0,0,0,0,@PrecioMano, @PrecioRefaccion,@PrecioLubricante,'00:00:00.0000000',0,'ACTUALIZÓ'

END

SELECT @idContratoPartida AS idContratoPartida

--SET TRANSACTION ISOLATION LEVEL READ COMMITTED; -- turn it off

end
--GO
--BEGIN TRAN
--SELECT 0
--ROLLBACK TRAN
go

