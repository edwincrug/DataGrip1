
-- =============================================
-- Author:		<Armando Garcia>
-- Create date: <08/09/2020>
-- Description:	<Inserta la lista de documentos carga masiva>
-- =============================================
CREATE PROCEDURE [dbo].[INS_LISTA_CARGADOCUMENTO_SP]
	-- Add the parameters for the stored procedure here
	@IdCargaDocumento numeric(18,0) = NULL
	,@nombreArchivo VARCHAR (MAX) = NULL
	,@nombreArchivoUsuario VARCHAR (MAX) = NULL
	, @idTipoCarga numeric(18,0) = NULL
	, @idUsuario numeric(18,0)
	, @accion INT
AS
BEGIN

	SET NOCOUNT ON;

	/*SE INSERTA REGISTRO NUEVO*/
	IF @accion = 1
	BEGIN
		INSERT INTO [dbo].[CargaDocumento] ([nombreArchivo], [idEstatusCargaMasiva], [fechaCarga], [fechaFinalizacion], [idTipoCarga], [idUsuario], [error], [nombreArchivoUsuario])
		SELECT @nombreArchivo, 1, GETDATE(),NULL,@idTipoCarga,@idUsuario,'', @nombreArchivoUsuario
		SELECT @@IDENTITY AS IdCargaDocumento

		/*SI CAE UN REGISTRO DESPUES DE LAS 7 REALIZA EL PROCESO DE INSERCIÓN*/
		--IF DATEPART(HOUR, GETDATE())>=18
		--BEGIN
		--	EXEC [dbo].[INS_PROCESA_CARGADOCUMENTO_SP] --@@IDENTITY, @nombreArchivo, @idUsuario
		--END
	END

	/*SE USA PARA CANCELAR LA CARGA DEL DOCUMENTO*/
	IF @accion = 2
	BEGIN
		UPDATE [CargaDocumento] SET idEstatusCargaMasiva=4 WHERE idCargaDocumento=@IdCargaDocumento
		SELECT @IdCargaDocumento
	END
END
go

