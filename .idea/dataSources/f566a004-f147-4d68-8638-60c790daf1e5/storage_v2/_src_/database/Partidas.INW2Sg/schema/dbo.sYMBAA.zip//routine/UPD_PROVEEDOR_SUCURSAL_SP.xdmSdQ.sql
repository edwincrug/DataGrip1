-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UPD_PROVEEDOR_SUCURSAL_SP](
	-- Add the parameters for the stored procedure here
	@idProveedor					numeric(18,0),
	@idProveedorEncabezado			numeric(18,0),
	@nombreComercial				nvarchar(200),
	@razonSocial					nvarchar(500),
	@RFC							nvarchar(20),
	@contacto						nvarchar(200),
	@telefono						nvarchar(200),
	@mail							nvarchar(200),
	@fechaInicio					datetime,
	@idCategoria					numeric(18,0),
	@idProveedorClasificacion		numeric(18,0),
	@idProveedorSubClasificacion	numeric(18,0), 
	@direccion						nvarchar(500),
	@latitud						nvarchar(50), 
	@longitud						nvarchar(50), 
	@poligono						nvarchar(200),

	--
	@JSONCombustible			varchar(max),
	@JSONDIESEL					varchar(max),
	@JSONGasolina				varchar(max)
	)
AS
BEGIN
	
	UPDATE dbo.Proveedor
	SET nombreComercial = @nombreComercial,
		razonSocial = @razonSocial,
		RFC = @RFC,
		contacto = @contacto,
		telefono = @telefono,
		mail = @mail,
		idCategoria = @idCategoria,
		idProveedorClasificacion = @idProveedorClasificacion,
		idProveedorSubClasificacion = @idProveedorSubClasificacion,
		direccion = @direccion,
		latitud = @latitud,
		longitud = @longitud,
		poligono = @poligono
	where idProveedor = @idProveedor
		and idProveedorEncabezado = @idProveedorEncabezado

	CREATE TABLE #JSON(
		element_id numeric(18,0),
		secuenceNo numeric(18,0),
		parent_ID numeric(18,0),
		Object_ID numeric(18,0),
		NAME nvarchar(MAX),
		StringValue nvarchar(MAX),
		ValueType nvarchar(MAX)
	)

	--ELIMINAMOS ProveedorTipoCombustible
	DELETE FROM ProveedorTipoCombustible where idProveedor = @idProveedor
	--ELIMINAMOS ProveedorEspecialidadCombustible
	DELETE FROM ProveedorEspecialidadCombustible where idProveedor=@idProveedor

	
	--PRIMERO INSERTAMOS LOS COMBUSTIBLES
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@JSONCombustible)
	
	insert into ProveedorTipoCombustible
	select @idProveedor, StringValue from #JSON where NAME = 'value'


	--ELIMINAMOS Y AHORA METEMOS LAS ESPECIALIDADES DIESEL
	DELETE FROM #JSON
	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@JSONDIESEL)

	insert into ProveedorEspecialidadCombustible
	select @idProveedor, StringValue, 1 from #JSON where NAME = 'value'


	--ELIMINAMOS Y AHORA METEMOS LAS ESPECIALIDADES Gasolina
	DELETE FROM #JSON
	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@JSONGasolina)

	insert into ProveedorEspecialidadCombustible
	select @idProveedor, StringValue, 2 from #JSON where NAME = 'value'


    -- Insert statements for procedure here
	SELECT * from Proveedor where idProveedor = @idProveedor
END
go

