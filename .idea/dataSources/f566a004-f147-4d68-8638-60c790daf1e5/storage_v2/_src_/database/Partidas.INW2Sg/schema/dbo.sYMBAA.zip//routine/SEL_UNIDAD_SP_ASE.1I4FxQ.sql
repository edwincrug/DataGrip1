--SEL_UNIDAD_SP_ASE 1
CREATE procedure [dbo].[SEL_UNIDAD_SP_ASE] (
	@idUsuario numeric(18,0),
	@idOperacion numeric(18,0)
)
as
begin

	SELECT
		unis.idUnidad,
		uni.idUnidad as idTipoUnidad,
		cast(uni.idUnidad as nvarchar(10)) + '/' + tco.tipoCombustible + '/' + tip.tipo + '/'  + mar.nombre + '/' + sma.nombre  + '/' + cil.cilindros as tipoUnidad,
		unis.[numeroEconomico],
		unis.[vin],
		unis.[placas],
		unis.[modelo],
		unis.frente,
		unis.derecho,
		unis.izquierdo,
		unis.atras,
		unis.tarjeta,
		unis.repuve,
		unis.placavin,
		/*NUEVOS CAMPOS*/
		unis.verificacionAmbiental,
		unis.fechaVencimientoVerificacionAmbiental,
		unis.verificacionFisicoMecanica,
		unis.fechaVencimientoVerificacionFisicoMecanica,
		unis.refrendo,
		unis.fechaVencimientoRefrendo,
		unis.tenencia,
		fechaVencimientoTenencia,
		/**/
		unis.autorizacion,
		usus.nombreCompleto,
		CONVERT(NVARCHAR(10),unis.fecha,103) as fecha,
		(select idPadre from Zona where idZona = unis.idZona) as idSucursal,
		unis.idZona as idUnidadOperativa
		--(select Z.idZona from ASEPROT.dbo.UnidadesZona UZ inner join Zona Z on UZ.idZona = Z.idZona where  uz.idUnidad= unis.idUnidad and Z.idNivelZona=1) as idSucursal,
		--(select Z.idZona from ASEPROT.dbo.UnidadesZona UZ inner join Zona Z on UZ.idZona = Z.idZona where  uz.idUnidad= unis.idUnidad and Z.idNivelZona=2) as idUnidadOperativa
	FROM
		dbo.Unidad uni
		LEFT JOIN TipoUnidad tip ON tip.idTipoUnidad = uni.idTipoUnidad
		LEFT JOIN SubMarca sma ON sma.idSubmarca = uni.idSubMarca
		LEFT JOIN Marca mar ON mar.idMarca = sma.idMarca
		LEFT JOIN TipoCombustible tco ON tco.idTipoCombustible = uni.idTipoCombustible
		LEFT JOIN Cilindros cil ON cil.idCilindros = uni.idCilindros
		LEFT JOIN ASEPROT.dbo.Unidades unis ON unis.idTipoUnidad = uni.idUnidad
		--LEFT JOIN UnidadASE uas ON uas.numeroEconomico = unis.numeroEconomico
		LEFT JOIN ASEPROT.[dbo].[Usuarios] usus ON usus.idUsuario = unis.idUsuario
	WHERE unis.verificada = 1
	and unis.idOperacion = @idOperacion

end
go

