create procedure [dbo].[UPD_CLIENTE_SP] (
	@idCliente numeric(18,0),
	@nombreComercial nvarchar(200),
	@razonSocial nvarchar(200),
	@rfc nvarchar(20),
	@direccion nvarchar(200),
	@telefono nvarchar(50)
)
as
begin

	UPDATE
		dbo.Cliente
	SET
		nombreComercial =@nombreComercial,
		razonSocial = @razonSocial,
		rfc = @rfc,
		direccion = @direccion,
		telefono = @telefono
	WHERE 
		idCliente = @idCliente
		
	SELECT @idCliente 

end
go

