CREATE procedure [dbo].[SEL_CONTRATO_UNIDAD_DDL_SP] (
	@idUsuario numeric(18,0),
	@idContrato numeric(18,0)
)
as
begin

		SELECT
		cun.idUnidad as value,
		cast(cun.idUnidad as nvarchar(10)) + '/' +
		 tco.tipoCombustible + '/' + tip.tipo + '/'  + mar.nombre + '/' + sma.nombre  + '/' + cil.cilindros as label
	FROM
		dbo.ContratoUnidad cun
		LEFT JOIN dbo.Unidad uni ON uni.idUnidad = cun.idUnidad
		LEFT JOIN TipoUnidad tip ON tip.idTipoUnidad = uni.idTipoUnidad
		LEFT JOIN TipoCombustible tco ON tco.idTipoCombustible = uni.idTipoCombustible
		LEFT JOIN Cilindros cil ON cil.idCilindros = uni.idCilindros
		LEFT JOIN SubMarca sma ON sma.idSubmarca = uni.idSubMarca
		LEFT JOIN Marca mar ON mar.idMarca = sma.idMarca
	WHERE 
		uni.estatus= 1
		AND cun.idContrato = @idContrato
	order by tco.tipoCombustible, tip.tipo,  mar.nombre,  sma.nombre, cil.cilindros
end
go

