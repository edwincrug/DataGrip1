-- =============================================
-- Author:		<Alan Rosales>
-- Create date: <09/08/2017 13:46:00>
-- Description:	<Seleccion de Datos Fiscales para el proveedor>
-- =============================================
--SEL_PROVEEDOR_ESPECIALIDADES_BYID_SP 313
CREATE PROCEDURE SEL_PROVEEDOR_DATOSFISCALES_BYID_SP
	-- Add the parameters for the stored procedure here
	@idProveedor	numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	select 
		PD.*
	from ProveedorDatosFiscales PD 
	where PD.idProveedor=@idProveedor

END
go

