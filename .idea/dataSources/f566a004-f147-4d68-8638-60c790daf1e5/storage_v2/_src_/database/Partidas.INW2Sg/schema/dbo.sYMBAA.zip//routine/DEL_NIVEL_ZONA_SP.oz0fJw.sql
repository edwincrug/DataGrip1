create procedure [dbo].[DEL_NIVEL_ZONA_SP] (
	@idNivelZona numeric(18,0)
)
as
begin

	DELETE FROM dbo.NivelZona WHERE idNivelZona = @idNivelZona
	
	SELECT @idNivelZona

end
go

