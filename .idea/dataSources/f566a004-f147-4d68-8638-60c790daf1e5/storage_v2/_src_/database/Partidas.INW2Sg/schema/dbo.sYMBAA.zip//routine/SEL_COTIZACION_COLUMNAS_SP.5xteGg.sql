CREATE procedure [dbo].[SEL_COTIZACION_COLUMNAS_SP] (
	@idUsuario numeric(18,0),
	@idProveedorCotizacion numeric(18,0)
)
as
begin

	SELECT
		'C' + CAST(pro.idProveedor AS NVARCHAR(10)) as field,
		pro.razonSocial as header,
		'150px' as width
	FROM
		dbo.ProveedorCotizacion pco
		LEFT JOIN dbo.Proveedor pro ON pro.idProveedor = pco.idProveedor
	WHERE 
		pco.idUnidad in(
		SELECT idUnidad FROM dbo.ProveedorCotizacion pcox WHERE pcox.idProveedorCotizacion = @idProveedorCotizacion
	)
	AND pco.idProveedor NOT IN (SELECT pcoy.idProveedor 
								FROM  dbo.ProveedorCotizacion pcoy 
								WHERE pcoy.idProveedorCotizacion = @idProveedorCotizacion  )

end
go

