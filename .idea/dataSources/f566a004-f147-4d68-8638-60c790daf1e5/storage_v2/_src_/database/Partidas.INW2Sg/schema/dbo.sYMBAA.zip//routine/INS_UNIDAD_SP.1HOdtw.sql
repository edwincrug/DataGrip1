CREATE PROCEDURE [dbo].[INS_UNIDAD_SP] (
	@idTipoCombustible numeric(18,0)
	,@idTipoUnidad numeric(18,0)
	,@idSubMarca numeric(18,0)
	,@idCilindros numeric(18,0)
	,@foto nvarchar(100)
)
as
begin
	

	INSERT INTO dbo.Unidad
		(idTipoCombustible, idTipoUnidad, idSubMarca, idCilindros,foto,estatus)
	VALUES 
		( @idTipoCombustible, @idTipoUnidad,@idSubMarca, @idCilindros, REPLACE(@foto,'"',''), 1);
	
		
	SELECT @@IDENTITY
end
go

