CREATE procedure [dbo].[UPD_CONTRATO_SP] (
	@idContrato numeric(18,0),
	@numero nvarchar(50),
	@descripcion nvarchar(500),
	@fechaInicio datetime,
	@fechaFin datetime,
	@estatus smallint,
	@jsonUnidades nvarchar(max),
	@jsonProveedores nvarchar(max)
)
as
begin

	UPDATE dbo.Contrato
		SET 
			numero=@numero, 
			descripcion = @descripcion,
			fechaInicio = @fechaInicio,
			fechaFin = @fechaFin,
			estatus = @estatus
	where idContrato = @idContrato

	
	--Inserto Unidades
	DECLARE @idUnidad AS numeric(18,0)
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 

	SELECT Object_ID FROM parseJSON(@jsonUnidades)
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idUnidad = REPLACE(StringValue,'"','')  FROM parseJSON(@jsonUnidades)
			WHERE 
			parent_ID = @parent
			AND NAME = 'idUnidad'
			AND Object_ID IS NULL
	
		--AL ACTUALIZAR UNICAMENTE INSERTAMOS EL CONTRATO CUANDO LA UNIDAD NO EXISTE	
		if not exists (select * from ContratoUnidad where idUnidad = @idUnidad and idContrato=@idContrato)
		begin
			INSERT INTO dbo.ContratoUnidad
				( idContrato, idUnidad)
			VALUES 
				( @idContrato, @idUnidad)
		end
	FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	
	
	--Inserto Proveedor
	DECLARE @idProveedor AS numeric(18,0)
	DECLARE @parent2 AS INT
	DECLARE _cursor2 CURSOR FOR 

	SELECT Object_ID FROM parseJSON(@jsonProveedores)
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor2 
	FETCH NEXT FROM _cursor2 INTO @parent2
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idProveedor = REPLACE(StringValue,'"','')  FROM parseJSON(@jsonProveedores)
			WHERE 
			parent_ID = @parent2
			AND NAME = 'idProveedor'
			AND Object_ID IS NULL
	
		IF NOT EXISTS (SELECT * FROM ContratoProveedor where idProveedor = @idProveedor and idContrato = @idContrato)
		BEGIN
			INSERT INTO dbo.ContratoProveedor
			(idContrato, idProveedor)
		VALUES 
			( @idContrato, @idProveedor)
		END
		
	
	FETCH NEXT FROM _cursor2 INTO @parent2
	END 
	CLOSE _cursor2 
	DEALLOCATE _cursor2
	
	SELECT @idContrato as idContrato
	
end
go

