create procedure [dbo].[INS_NIVEL_ZONA_SP] (
	@idCliente numeric(18,0),
	@etiqueta nvarchar(200),
	@orden smallint
)
as
begin

	INSERT INTO Partidas.dbo.NivelZona
		(idCliente, etiqueta, orden)
	VALUES 
		(@idCliente, @etiqueta, @orden);
		
	SELECT @@IDENTITY

end
go

