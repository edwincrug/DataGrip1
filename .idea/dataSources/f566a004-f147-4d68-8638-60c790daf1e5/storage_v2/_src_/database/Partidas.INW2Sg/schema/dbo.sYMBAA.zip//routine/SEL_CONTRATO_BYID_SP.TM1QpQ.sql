--SEL_CONTRATO_BYID_SP '1'
CREATE procedure [dbo].[SEL_CONTRATO_BYID_SP] (
	@idContrato numeric(18,0)
	
)
as
begin

	SELECT
		idContrato,
		con.idLicitacion,
		cli.idCliente,
		cli.nombreComercial as cliente,
		lic.folio as folioLicitacion,
		lic.nombre as nombreLicitacion,
		con.numero as numeroContrato,
		con.descripcion as descripcionContrato,
		convert(nvarchar(10),con.fechaInicio,103) as fechaInicioTXT,
		con.fechaInicio,
		convert(nvarchar(10),con.fechaFin,103) as fechaFinTXT,
		con.fechaFin,
		(select COUNT(1) from dbo.ContratoUnidad cun WHERE cun.idContrato = con.idContrato ) as unidades,
		(select COUNT(1) from dbo.ContratoProveedor cpo WHERE cpo.idContrato = con.idContrato ) as proveedores,
		con.estatus
	FROM
		dbo.Contrato con
		LEFT JOIN Licitacion lic ON lic.idLicitacion = con.idLicitacion
		LEFT JOIN Cliente cli ON cli.idCliente = lic.idCliente
	WHERE 
		idContrato = @idContrato

end
go

