create procedure [dbo].[DEL_ZONA_SP] (
	@idZona numeric(18,0)
)
as
begin

	DELETE FROM dbo.Zona WHERE idZona = @idZona 
	
	SELECT @idZona 

end
go

