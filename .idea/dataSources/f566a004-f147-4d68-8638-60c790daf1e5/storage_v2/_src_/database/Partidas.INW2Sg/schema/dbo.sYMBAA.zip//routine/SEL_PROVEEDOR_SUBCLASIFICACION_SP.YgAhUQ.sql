create procedure [dbo].[SEL_PROVEEDOR_SUBCLASIFICACION_SP] (
	@idCategoria numeric(18,0)
)
as
begin

	SELECT
		idProveedorSubClasificacion as value,
		subClasificacion as label
	FROM
		dbo.ProveedorSubClasificacion
	WHERE
		idCategoria = @idCategoria
		and estatus = 1

end
go

