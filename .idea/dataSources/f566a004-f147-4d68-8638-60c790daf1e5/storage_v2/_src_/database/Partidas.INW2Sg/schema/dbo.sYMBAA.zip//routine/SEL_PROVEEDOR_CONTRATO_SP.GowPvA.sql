CREATE procedure [dbo].[SEL_PROVEEDOR_CONTRATO_SP] (
	@idUsuario numeric(18,0),
	@idContrato numeric(18,0)
)
as
begin

	SELECT
		cpr.idContratoProveedor as value,
		cast(pro.idProveedor as nvarchar(10)) + ' / ' + pro.razonSocial + ' / ' + pro.nombreComercial  as label 
	FROM
		dbo.ContratoProveedor cpr
		LEFT JOIN dbo.Proveedor pro ON pro.idProveedor = cpr.idProveedor
	WHERE 
		cpr.idContrato = @idContrato
	ORDER BY
		pro.nombreComercial, pro.razonSocial

end
go

