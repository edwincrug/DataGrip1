CREATE FUNCTION [dbo].[SEL_NOPARTIDA_KIT_FN] (
	@idUnidad numeric(18,0)
)
RETURNS NVARCHAR(20)
as
begin

	DECLARE @NOPARTIDA AS nvarchar(20)
	
	SELECT  @NOPARTIDA =  'K-' + UPPER(SUBSTRING ( mar.nombre ,1 , 3 ) + SUBSTRING ( sma.nombre ,1 , 3 ) + SUBSTRING ( uni.anio ,3 , 2 )) + '.' +
		RIGHT('000' + Ltrim(Rtrim(CAST(((SELECT isNULL(MAX(idKit),0) FROM Kit) + 1) AS NVARCHAR(10)))),3)
	FROM Unidad uni
		LEFT JOIN SubMarca sma ON sma.idSubMarca = uni.idSubMarca
		LEFT JOIN Marca mar ON mar.idMarca = sma.idMarca
	WHERE uni.idUnidad =  @idUnidad

	RETURN @NOPARTIDA
	
end
go

