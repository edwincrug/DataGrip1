



CREATE VIEW [dbo].[vwUsuarioAgregarUnidad]
AS
SELECT idUsuario = 19 
UNION
SELECT idUsuario = 1 
UNION 
SELECT idUsuario = 44 
UNION
SELECT idUsuario = 45 
UNION
SELECT idUsuario = 38 
UNION
SELECT idUsuario = 39
UNION
SELECT idUsuario = 76

go

