create procedure [dbo].[DEL_CLIENTE_SP] (
	@idCliente numeric(18,0)
)
as
begin

	DELETE FROM Partidas.dbo.Cliente WHERE idCliente = @idCliente
	
	SELECT @idCliente

end
go

