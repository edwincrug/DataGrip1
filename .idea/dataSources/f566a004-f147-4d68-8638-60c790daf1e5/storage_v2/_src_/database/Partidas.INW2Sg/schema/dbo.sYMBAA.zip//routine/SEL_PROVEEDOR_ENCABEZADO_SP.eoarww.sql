CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_ENCABEZADO_SP] 
as
begin

	SELECT 
		pro.idProveedorEncabezado,
		pro.nombreComercial,
		pro.razonSocial,
		pro.RFC,
		convert(nvarchar(10),pro.fechaInicio,103) as fechaInicio,
		pro.idCategoria,
		cat.categoria,
		dbo.SEL_PROVEEDOR_ENCABEZADO_ESPECIALIDAD_FN(pro.idProveedorEncabezado) especialidades,
		--dbo.SEL_PROVEEDOR_TIPO_UNIDAD_FN(p.idProveedor) tipoUnidad,
		pro.calle,
		pro.estatus,
		pro.contacto,
		pro.logo,
		pro.mail,
		usu.usuario,
		usu.password
	FROM
		ProveedorEncabezado pro 
		--LEFT JOIN dbo.Proveedor p ON pro.idProveedorEncabezado = P.idProveedorEncabezado
		LEFT JOIN Categoria cat ON cat.idCategoria = pro.idCategoria
		LEFT JOIN UsuarioProveedor cpr ON cpr.idProveedor = pro.idProveedorEncabezado
		LEFT JOIN Usuario usu ON usu.idUsuario = cpr.idUsuario
	WHERE 
		pro.estatus = 1
		
		--and dbo.SEL_PROVEEDOR_ENCABEZADO_ESPECIALIDAD_FN(pro.idProveedorEncabezado) is  null

end
go

