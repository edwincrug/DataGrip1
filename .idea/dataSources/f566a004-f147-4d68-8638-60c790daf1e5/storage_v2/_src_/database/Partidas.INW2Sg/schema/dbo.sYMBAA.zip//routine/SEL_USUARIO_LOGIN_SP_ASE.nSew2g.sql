
CREATE PROCEDURE [dbo].[SEL_USUARIO_LOGIN_SP_ASEII] 
	@usuario as nvarchar(50),
	@password as nvarchar(50)
AS
BEGIN

	SELECT TOP (1000) [idUsuario]
		  ,[nombreUsuario]
		  ,[contrasenia]
		  ,[idCatalogoTipoUsuarios]
		  ,[nombreCompleto]
		  ,[correoElectronico]
		  ,[telefonoUsuario]
		  ,[extensionUsuario]
		  ,[empresa]
	  FROM [ASEPROT].[dbo].[Usuarios]
	WHERE 
	nombreUsuario = @usuario
	and contrasenia = @password


END

go

