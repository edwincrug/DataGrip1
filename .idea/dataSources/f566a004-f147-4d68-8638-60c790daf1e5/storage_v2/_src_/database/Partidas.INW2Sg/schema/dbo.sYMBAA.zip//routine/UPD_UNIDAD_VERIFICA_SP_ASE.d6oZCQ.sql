
CREATE PROCEDURE [dbo].[UPD_UNIDAD_VERIFICA_SP_ASE]
	@numeroEconomico	NVARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE ASEPROT.dbo.Unidades
	SET 
		verificada = 0 
		,fecha = NULL
		,frente = NULL 
		,derecho = NULL 
		,izquierdo = NULL 
		,atras = NULL
		,tarjeta = NULL 
		,autorizacion = NULL
		,repuve = NULL
		,placavin = NULL
	WHERE 
		numeroEconomico=@numeroEconomico
		
	SELECT @numeroEconomico
END
go

