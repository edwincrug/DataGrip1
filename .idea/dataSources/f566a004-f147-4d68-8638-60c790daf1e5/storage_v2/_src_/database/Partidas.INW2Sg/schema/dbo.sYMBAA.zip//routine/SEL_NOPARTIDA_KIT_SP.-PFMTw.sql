create procedure [dbo].[SEL_NOPARTIDA_KIT_SP] (
	@idUnidad numeric(18,0)
)
as
begin

	SELECT dbo.SEL_NOPARTIDA_KIT_FN(@idUnidad) as partida

end
go

