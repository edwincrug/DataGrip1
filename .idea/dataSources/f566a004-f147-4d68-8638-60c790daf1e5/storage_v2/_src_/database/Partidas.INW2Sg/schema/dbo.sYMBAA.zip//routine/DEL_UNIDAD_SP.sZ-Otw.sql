CREATE procedure [dbo].[DEL_UNIDAD_SP] (
	@idUnidad numeric(18,0)
)
as
begin

	DELETE FROM dbo.Unidad WHERE idUnidad = @idUnidad
	
	SELECT @idUnidad

end
go

