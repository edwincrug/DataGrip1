create procedure [dbo].[INS_CLIENTE_SP] (
	@nombreComercial nvarchar(200),
	@razonSocial nvarchar(200),
	@rfc nvarchar(20),
	@direccion nvarchar(200),
	@telefono nvarchar(50)
	
)
as
begin

	INSERT INTO dbo.Cliente
		( nombreComercial, razonSocial, rfc, direccion, telefono, estatus )
	VALUES 
		(@nombreComercial, @razonSocial, @rfc, @direccion, @telefono, 1)
		
	SELECT @@IDENTITY

end
go

