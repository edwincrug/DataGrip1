CREATE procedure [dbo].[DEL_PROVEEDOR_SP] (
	@idProveedor numeric(18,0)
)
as
begin

	--DELETE FROM dbo.Proveedor WHERE idProveedor = @idProveedor
	
	SELECT 1

end
go

