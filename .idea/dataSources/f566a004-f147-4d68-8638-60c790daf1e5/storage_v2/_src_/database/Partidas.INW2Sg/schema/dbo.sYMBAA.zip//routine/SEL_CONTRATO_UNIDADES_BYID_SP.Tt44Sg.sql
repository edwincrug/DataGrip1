--SEL_CONTRATO_UNIDADES_BYID_SP 1
CREATE PROCEDURE [dbo].[SEL_CONTRATO_UNIDADES_BYID_SP]
	@idContrato	numeric(18,0)
AS
BEGIN
	select
		CU.idUnidad,
		TU.tipo tipoUnidad,
		M.nombre marca,
		SM.nombre subMarca,
		(select count(1) from dbo.ProveedorCotizacion pco where pco.idCotizacionEstatus = 3 and pco.idUnidad = U.idUnidad) listasPrecio

	from ContratoUnidad CU 
	inner join Unidad U on CU.idUnidad = U.idUnidad
	inner join TipoUnidad TU on U.idTipoUnidad = TU.idTipoUnidad
	inner join Submarca SM on SM.idSubmarca = U.idSubmarca
	inner join Marca M on SM.idMarca = M.idMarca
	where idContrato=@idContrato and U.estatus=1
END
go

