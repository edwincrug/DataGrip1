CREATE procedure [dbo].[SEL_PROVEEDOR_ZONA_SP] (
	@idUsuario numeric(18,0),
	@idContratoProveedor numeric(18,0)
)
as
begin

	select 
		zon.idZona,
		nzo.orden as nivel,
		idPadre,
		nombre,
		zon.idNivelZona
	from Zona zon
	LEFT JOIN NivelZona nzo ON nzo.idNivelZona = zon.idNivelZona 
	LEFT JOIN dbo.ContratoProveedorZona cpz ON cpz.idZona = zon.idZona
	WHERE 
		cpz.idContratoProveedor = @idContratoProveedor
		
	order by orden

end
go

