CREATE procedure [dbo].[CLONAR_PARTIDA_SP] (
	@idPartidaClonar numeric(18,0),
	@idTipoUnidadDestino numeric(18,0),
	@idTipoUnidadOrigen numeric(18,0),
	@idUsuario numeric(18,0)
)
as
begin

DECLARE @idPartidaNueva numeric(18,0),@existePartida INT,@noParte nvarchar(MAX)

IF @idPartidaClonar <> -1000
BEGIN
SELECT @noParte=noParte FROM Partida WHERE idPartida=@idPartidaClonar

SET @existePartida = (SELECT COUNT(*) FROM Partida WHERE idUnidad=@idTipoUnidadDestino AND noParte=@noParte)

IF @existePartida=0
	BEGIN
	INSERT INTO Partida
	SELECT @idTipoUnidadDestino, [idTipoPartida], [idEspecialidad]
	, [idPartidaClasificacion], [idPartidaSubClasificacion]
	, (SELECT dbo.SEL_NOPARTIDA_FN(@idTipoUnidadDestino))
	, [marca], [noParte], [descripcion], [foto], [instructivo], [estatus] , @idUsuario,GETDATE(),'CLON INDIVIDUAL' 
	FROM Partida
	WHERE idPartida=@idPartidaClonar
	SET @idPartidaNueva=(SELECT @@IDENTITY)
	INSERT INTO PartidaTipoOrdenServicio
	SELECT @idPartidaNueva,idCatalogoTipoOrdenServicio FROM PartidaTipoOrdenServicio WHERE idPartida=@idPartidaClonar
	
	END
END
ELSE
BEGIN

DECLARE @totalPartidas int,@i int=1,@IdPartida numeric(18,0)
SET @totalPartidas = (SELECT COUNT(*) FROM Partida WHERE idUnidad=@idTipoUnidadOrigen)

DECLARE @Partidas TABLE (id int identity(1,1),IdPartida numeric(18,0))

INSERT INTO @Partidas
SELECT idPartida FROM Partida
WHERE idUnidad=@idTipoUnidadOrigen

WHILE @i<=@totalPartidas
BEGIN

SELECT @IdPartida=idPartida FROM @Partidas
WHERE id=@i

SELECT @noParte=noParte FROM Partida WHERE idPartida=@IdPartida

SET @existePartida = (SELECT COUNT(*) FROM Partida WHERE idUnidad=@idTipoUnidadDestino AND noParte=@noParte)

IF @existePartida=0
	BEGIN
	INSERT INTO Partida
	SELECT @idTipoUnidadDestino, [idTipoPartida], [idEspecialidad]
	, [idPartidaClasificacion], [idPartidaSubClasificacion]
	, (SELECT dbo.SEL_NOPARTIDA_FN(@idTipoUnidadDestino))
	, [marca], [noParte], [descripcion], [foto], [instructivo], [estatus], @idUsuario,GETDATE(),'CLON MASIVA'  
	FROM Partida
	WHERE idPartida = @IdPartida
	SET @idPartidaNueva=(SELECT @@IDENTITY)
	INSERT INTO PartidaTipoOrdenServicio
	SELECT @idPartidaNueva,idCatalogoTipoOrdenServicio FROM PartidaTipoOrdenServicio WHERE idPartida=@IdPartida
	
	END
SET @i = @i +1

END
END

SELECT * FROM Partida
WHERE idPartida=@idPartidaNueva

end
--GO
--BEGIN TRAN

--SELECT * FROM Partida
--where idUnidad=196 AND idPartida=739017

--EXEC [dbo].[CLONAR_PARTIDA_SP] 739017,196,19 
--EXEC [dbo].[CLONAR_PARTIDA_SP] -1000,186,188

--SELECT * FROM Partida
--where idUnidad=196 AND noParte='SER-RES'
--ROLLBACK TRAN
go

