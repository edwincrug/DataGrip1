CREATE PROCEDURE [dbo].[SEL_LICITACION_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		idLicitacion,
		cli.idCliente,
		cli.nombreComercial as cliente,
		lic.idClienteFinal,
		clf.nombreComercial as clienteFinal,
		lic.idEmpresa as idEmpresa,
		folio,
		nombre,
		descripcion,
		convert(nvarchar(10),fechaInicio,103) as fechaInicioCompleta,
		fechaInicio,
		lic.estatus
	FROM
		dbo.Licitacion lic
		LEFT JOIN Cliente cli ON cli.idCliente = lic.idCliente
		LEFT JOIN Cliente clf ON clf.idCliente = lic.idClienteFinal
	WHERE 
		lic.estatus = 1


end
go

