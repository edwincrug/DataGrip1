create procedure [dbo].[SEL_PROVEEDOR_COTIZACION_BYID_SP] (
	@idProveedorCotizacion numeric(18,0)
)
as
begin

	SELECT
		idProveedorCotizacion,
		idProveedor,
		idUnidad,
		fecha,
		idCotizacionEstatus
	FROM
		dbo.ProveedorCotizacion pco
	WHERE 
		pco.idProveedorCotizacion = @idProveedorCotizacion

end
go

