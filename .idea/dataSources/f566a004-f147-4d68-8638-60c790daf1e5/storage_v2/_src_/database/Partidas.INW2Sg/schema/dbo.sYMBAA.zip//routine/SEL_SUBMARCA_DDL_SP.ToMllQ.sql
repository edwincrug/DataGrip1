CREATE PROCEDURE [dbo].[SEL_SUBMARCA_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin
	
	SELECT
		idSubMarca as value,
		mar.nombre + ' - ' + sub.nombre as label
	FROM
		dbo.SubMarca sub
		LEFT JOIN dbo.Marca mar ON mar.idMarca = sub.idMarca
	WHERE sub.estatus = 1

end
go

