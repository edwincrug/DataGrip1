CREATE procedure [dbo].[UPD_APROBAR_PARTIDA_PENDIENTES_SP] (  
 @idUsuario numeric(18,0),  
 @idProveedorCotizacion numeric(18,0)
)  
as  
begin  
 
 UPDATE  
  dbo.ProveedorPartida  
 SET  
  idPartidaEstatus = 4  
 WHERE   
  idProveedorCotizacion = @idProveedorCotizacion  
  AND idPartidaEstatus=2    
 SELECT @idProveedorCotizacion  

 update ProveedorCotizacion set idCotizacionEstatus = 3 where idProveedorCotizacion = @idProveedorCotizacion
  
end
go

