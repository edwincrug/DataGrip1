--SEL_CONTRATO_PROVEEDORES_BYID_SP 1
CREATE PROCEDURE [dbo].[SEL_CONTRATO_PROVEEDORES_BYID_SP]
	@idContrato	numeric(18,0)
AS
BEGIN
	SELECT
		pro.idProveedor,
		nombreComercial,
		razonSocial,
		RFC,
		convert(nvarchar(10),fechaInicio,103) as fechaInicio,
		pro.idCategoria,
		cat.categoria,
		dbo.SEL_PROVEEDOR_ESPECIALIDAD_FN(pro.idProveedor) especialidades,
		dbo.SEL_PROVEEDOR_TIPO_UNIDAD_FN(pro.idProveedor) tipoUnidad,
		direccion,
		latitud,
		longitud,
		poligono,
		pro.estatus,
		pro.contacto,
		pro.mail,
		usu.usuario,
		usu.password
	FROM
		ContratoProveedor CP
		inner join dbo.Proveedor pro on CP.idProveedor=pro.idProveedor
		LEFT JOIN Categoria cat ON cat.idCategoria = pro.idCategoria
		LEFT JOIN UsuarioProveedor cpr ON cpr.idProveedor = pro.idProveedor
		LEFT JOIN Usuario usu ON usu.idUsuario = cpr.idUsuario
	WHERE 
		pro.estatus = 1
		and idContrato = @idContrato
END
go

