CREATE procedure [dbo].[SEL_TIPO_COMBUSTIBLE_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin
	
	select 
		idTipoCombustible as value,
		tipoCombustible as label,
		tipoCombustible as text
	from 
		TipoCombustible
	

end
go

