
CREATE procedure [dbo].[SEL_PROVEEDOR_ENCABEZADO_DOCUMENTO_SP] (
	@idProveedorEncabezado numeric(18,0)
)
as
begin

	SELECT
		idProveedorEncabezadoDocumento,
		idProveedorEncabezado,
		pdo.idDocumento,
		doc.descripcion,
		folio,
		vigencia,
		convert(nvarchar(10),vigencia,103) as vigenciaTXT,
		fechaCarga,
		convert(nvarchar(10),fechaCarga,103) as fechaCargaTXT,
		archivo
	FROM
		dbo.ProveedorEncabezadoDocumento pdo
		LEFT JOIN Documento doc ON doc.idDocumento = pdo.idDocumento
	WHERE
		idProveedorEncabezado = @idProveedorEncabezado
		and doc.idTipoDocumento = 1

end
go

