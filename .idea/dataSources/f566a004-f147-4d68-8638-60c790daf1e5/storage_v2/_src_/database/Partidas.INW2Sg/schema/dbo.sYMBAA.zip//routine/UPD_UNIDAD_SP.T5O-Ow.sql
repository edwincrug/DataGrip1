CREATE PROCEDURE [dbo].[UPD_UNIDAD_SP] (
	@idUnidad numeric(18,0),
	@idTipoCombustible numeric(18,0),
	@idTipoUnidad numeric(18,0),
	@idSubMarca numeric(18,0),
	@idCilindros numeric(18,0),
	@foto nvarchar(100)

)
as
begin

		
	UPDATE
		dbo.Unidad
	SET
		idTipoUnidad = @idTipoUnidad,
		idTipoCombustible=@idTipoCombustible,
		idSubMarca = @idSubMarca,
		idCilindros = @idCilindros,
		foto = REPLACE(@foto,'"','')
	WHERE 
		idUnidad = @idUnidad

	
	SELECT @idUnidad
	
end
go

