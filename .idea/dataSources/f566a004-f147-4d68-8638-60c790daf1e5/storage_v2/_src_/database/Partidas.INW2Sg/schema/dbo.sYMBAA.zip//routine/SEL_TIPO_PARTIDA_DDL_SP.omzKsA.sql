-- =============================================
-- Author:		<Alan Rosales>
-- Create date: <26/07/2017>
-- Description:	<DDL ProveedorClasificacion>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_TIPO_PARTIDA_DDL_SP]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT 
		TP.idTipoPartida 'value',
		TP.tipoPartida 'label'
	FROM TipoPartida TP
END
go

