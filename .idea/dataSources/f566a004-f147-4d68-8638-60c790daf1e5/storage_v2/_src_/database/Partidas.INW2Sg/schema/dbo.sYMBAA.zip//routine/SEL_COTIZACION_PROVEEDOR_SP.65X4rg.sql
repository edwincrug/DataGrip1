CREATE procedure [dbo].[SEL_COTIZACION_PROVEEDOR_SP] (
	@idUsuario numeric(18,0),
	@idProveedor numeric(18,0)
)
as
begin



	SELECT
		pco.idProveedorCotizacion,
		pco.idProveedor,
		uni.idUnidad,
		convert(nvarchar(19),pco.fecha,103) as fechaTXT,
		pco.fecha,
		pco.idCotizacionEstatus,
		ces.estatus,
		tip.idTipoUnidad,
		tip.tipo as tipoUnidad,
		tco.tipoCombustible,
		tco.idTipoCombustible,
		cil.cilindros,
		cil.idCilindros,
		sma.nombre as subMarca,
		sma.idSubMarca,
		mar.nombre as marca,
		foto as foto,
		(select count(1) from dbo.ProveedorCotizacion pco where pco.idCotizacionEstatus = 3 and pco.idUnidad = uni.idUnidad) as listasPrecio
	FROM
		dbo.ProveedorCotizacion pco
		LEFT JOIN dbo.CotizacionEstatus ces ON ces.idCotizacionEstatus = pco.idCotizacionEstatus		
		LEFT JOIN Unidad uni ON uni.idUnidad = pco.idUnidad
		LEFT JOIN TipoUnidad tip ON tip.idTipoUnidad = uni.idTipoUnidad
		LEFT JOIN SubMarca sma ON sma.idSubmarca = uni.idSubMarca
		LEFT JOIN Marca mar ON mar.idMarca = sma.idMarca
		LEFT JOIN TipoCombustible tco ON tco.idTipoCombustible = uni.idTipoCombustible
		LEFT JOIN Cilindros cil ON cil.idCilindros = uni.idCilindros

	WHERE 
		pco.idProveedor = @idProveedor


end
go

