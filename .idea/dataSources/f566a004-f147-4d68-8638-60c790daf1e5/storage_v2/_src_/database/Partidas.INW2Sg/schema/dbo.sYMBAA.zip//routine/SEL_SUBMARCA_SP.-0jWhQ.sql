CREATE PROCEDURE [dbo].[SEL_SUBMARCA_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		sub.idSubMarca,
		sub.idMarca,
		mar.nombre as marca,
		sub.nombre as subMarca,
		sub.estatus 
	FROM
		dbo.SubMarca sub
		LEFT JOIN dbo.Marca mar ON mar.idMarca = sub.idMarca
	WHERE 
		sub.estatus = 1

end
go

