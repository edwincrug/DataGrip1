CREATE procedure [dbo].[INS_PROVEEDOR_SP] (
	@nombreComercial nvarchar(200),
	@razonSocial nvarchar(500),
	@RFC nvarchar(13),
	@contacto nvarchar(200), --nuevo
	@telefono nvarchar(200), --nuevo
	@mail nvarchar(200), --nuevo
	@fechaInicio datetime,
	@idCategoria numeric(18,0),
	@idProveedorClasificacion numeric(18,0), --nuevo
	--@idProveedorSubClasificacion numeric(18,0), --nuevo
	@direccion nvarchar(500),
	@latitud nvarchar(50),
	@longitud nvarchar(50),
	@poligono nvarchar(200) = NULL,
	@jsonCombustible varchar(max),
	@jsonEspecialidad varchar(max),
	--NUEVOS PARAMETROS PARA INGRESAR DATOS FISCALES
	@tipoPersona nvarchar(3),
    @pais nvarchar(150),
    @estado nvarchar(150),
    @ciudad nvarchar(150),
    @delegacion nvarchar(150),
    @colonia nvarchar(150),
    @calle  nvarchar(150),
    @numInt nvarchar(150),
    @numExt nvarchar(150),
    @cp nvarchar(5),
	@lada nvarchar(10)
)
as
begin
	
	/*declare @idProveedorBP  numeric(18,0)
	--VERIFICAMOS SI EXISTE EL RFC EN BPRO
	IF NOT EXISTS (SELECT * FROM [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS] where ltrim(rtrim(PER_RFC)) = @RFC)
	BEGIN
	--SE REGISTRA TALLER EN BPRO  
		INSERT INTO [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]  
		(  
		 PER_RFC, 
		 PER_TIPO, 
		 PER_NOMRAZON, 
		 PER_TELEFONO1, 
		 PER_EMAIL,  
		 PER_PAIS, 
		 PER_ESTADO, 
		 PER_CIUDAD, 
		 PER_DELEGAC, 
		 PER_COLONIA,  
		 PER_CALLE1, 
		 PER_NUMEXTER, 
		 PER_CODPOS, 
		 PER_CVEUSU, 
		 PER_FECHOPE,  
		 PER_STATUS, 
		 PER_LADA, 
		 PER_FECING, 
		 PER_HORING, 
		 PER_CVEUSUING  
		)  
	   VALUES  
		(  
		 @RFC, 
		 SUBSTRING(@tipoPersona,1,10), 
		 substring(@razonSocial,1,150), 
		 SUBSTRING(@telefono,1,18), 
		 substring(@mail,1,70),  
		 substring(@pais,1,10), 
		 substring(@estado,1,10), 
		 substring(@ciudad,1,40), 
		 substring(@delegacion,1,60),
		 substring(@colonia,1,150),  
		 substring(@calle,1,70), 
		 substring(@numExt,1,20), 
		 @cp, 
		 'GMI', 
		 CONVERT(varchar, GETDATE(), 103),  
		 'ACTIVO', 
		 substring(@Lada,1,6), 
		 CONVERT(varchar, GETDATE(), 103),   
		 SUBSTRING(CONVERT(varchar, GETDATE(), 108), 1, 5), 
		 1  
		)
		--OBTENEMOS EL IDProveedor DE BPRO
	SET @idProveedorBP = (SELECT MAX(PER_IDPERSONA) FROM [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]) 
	END
	ELSE
	BEGIN
		----OBTENEMOS EL IDProveedor DE BPRO POR RFC
		SET @idProveedorBP = (SELECT PER_IDPERSONA FROM [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS] where PER_RFC = @RFC) 
			--SE ACTUALIZA TALLER EN BPRO  
		UPDATE [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]  
		SET 
			PER_TIPO = @tipoPersona, 
			PER_TELEFONO1 = SUBSTRING(@telefono,1,18), 
			PER_EMAIL = @mail,   
			PER_CVEUSU = 'GMI', --VERIFICAR SI VA A CAMBIAR
			PER_FECHOPE = CONVERT(varchar, GETDATE(), 103),  
			PER_STATUS = 'ACTIVO', --VERIFICAR SI VA A CAMBIAR
			PER_LADA = substring(@lada,1,6),   
			PER_FECING = CONVERT(varchar, GETDATE(), 103),   
			PER_HORING = SUBSTRING(CONVERT(varchar, GETDATE(), 108), 1, 5),   
			PER_CVEUSUING = 1  
		WHERE PER_IDPERSONA = @idProveedorBP  
	END

	INSERT INTO dbo.Proveedor
		(nombreComercial, razonSocial, RFC, contacto, telefono, mail, fechaInicio, idCategoria, idProveedorClasificacion,  direccion, latitud, longitud, poligono, estatus, idBPRO)
	VALUES 
		(@nombreComercial, @razonSocial, @RFC, @contacto, @telefono, @mail, @fechaInicio, @idCategoria, @idProveedorClasificacion, @direccion, @latitud, @longitud, @poligono, 1 , @idProveedorBP);
		
	DECLARE @idProveedor numeric(18,0) 
	set @idProveedor = @@IDENTITY


	--Temporal en lo que queda la edición de contratos
	INSERT INTO ContratoProveedor(idContrato, idProveedor)
	VALUES (1, @idProveedor)


	--se registran los datos fiscales
	if not exists(select * from ProveedorDatosFiscales where idProveedor=@idProveedor)
	begin
	insert into ProveedorDatosFiscales([idProveedor],[tipoPersona],[Pais],[Estado],[Ciudad],[Delegacion],[Colonia],[Calle],[NumInt],[NumExt],[CP],[Lada])
	values(@idProveedor, @tipoPersona, @pais , @estado, @ciudad, @delegacion, @colonia, @calle, @numInt, @numExt, @cp, @lada)
	end
	else
	begin
		update ProveedorDatosFiscales set
	   [tipoPersona] = @tipoPersona
      ,[Pais] = @pais
      ,[Estado] = @estado
      ,[Ciudad] = @ciudad 
      ,[Delegacion] = @delegacion
      ,[Colonia] = @colonia
      ,[Calle] = @calle
      ,[NumInt] = @numInt
      ,[NumExt] = @numExt
      ,[CP] = @cp
	  ,[Lada] = @lada
	where idProveedor = @idProveedor
	end



	--CREAMOS TABLA TEMPORAL PARA EL JSON
	CREATE TABLE #JSON(
		element_id numeric(18,0),
		secuenceNo numeric(18,0),
		parent_ID numeric(18,0),
		Object_ID numeric(18,0),
		NAME nvarchar(MAX),
		StringValue nvarchar(MAX),
		ValueType nvarchar(MAX)
	)
	
	--PRIMERO INSERTAMOS LOS COMBUSTIBLES
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@jsonCombustible)
	
	insert into ProveedorTipoCombustible
	select distinct @idProveedor, StringValue from #JSON where NAME = 'idTipoCombustible'


	--ELIMINAMOS Y AHORA METEMOS LAS ESPECIALIDADES
	DELETE FROM #JSON
	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@jsonEspecialidad)

	declare 
	@idTipoCombustible numeric(18,0),
	@idEspecialidad numeric(18,0)

	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 
	SELECT Object_ID FROM #JSON
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		select @idTipoCombustible =  StringValue from #JSON where parent_ID = @parent and Name='idTipoCombustible' AND Object_ID IS NULL
		select @ideSPECIALIDAD = StringValue from #JSON where parent_ID = @parent and Name='idEspecialidad' AND Object_ID IS NULL
		
		insert into ProveedorEspecialidadCombustible values(@idProveedor,@idEspecialidad,@idTipoCombustible)

		FETCH NEXT FROM _cursor INTO @parent
	end
	CLOSE _cursor 
	DEALLOCATE _cursor

	DROP TABLE #JSON
	
	--INSERTAMOS A (PROVEEDORCOTIZACION) PARA TODAS LAS UNIDADES QUE APLIQUEN EL COMBUSTIBLE
	insert into ProveedorCotizacion
	select 
		@idProveedor,
		U.idUnidad,
		GETDATE(),
		3
	from Unidad U 
	inner join ProveedorTipoCombustible PTC on PTC.idTipoCombustible = U.idTipoCombustible
	where PTC.idProveedor = @idProveedor

	--YA QUE TENEMOS LA COTIZACION ISNERTAMOS LOS COSTOS POR PARTIDA (PROVEEDORPARTIDA)
	insert into ProveedorPartida
	SELECT
		pc.idProveedorCotizacion,
		p.idPartida,
		0,
		0,
		0,
		'0',
		GETDATE(),
		1,
		4
	FROM ProveedorCotizacion pc
	INNER JOIN Unidad U on pc.idUnidad = U.idUnidad
	inner join Partida P on P.idUnidad = U.idUnidad
	where pc.idProveedor=@idProveedor*/
	
	SELECT '' as idProveedor
end

go

