CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_TIPO_UNIDAD_SP] (
	@idProveedor numeric(18,0)
)
as
begin

	SELECT
		tun.idTipoUnidad,
		tun.tipo
	FROM
		 dbo.TipoUnidad tun
	WHERE 
		tun.estatus = 1
		and tun.idTipoUnidad not in(
				SELECT
					ptu.idTipoUnidad
				FROM
					dbo.ProveedorTipoUnidad ptu
				WHERE 
					ptu.idProveedor = @idProveedor
		) 
		

end
go

