create procedure [dbo].[UPD_APROBAR_COTIZACION_SP] (
	@idUsuario numeric(18,0),
	@idProveedorCotizacion numeric(18,0),
	@respuesta smallint
)
as
begin

	UPDATE
		dbo.ProveedorCotizacion
	SET
		idCotizacionEstatus = @respuesta
	WHERE 
		idProveedorCotizacion = @idProveedorCotizacion
		
	SELECT @idProveedorCotizacion

end
go

