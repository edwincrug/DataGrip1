create procedure [dbo].[DEL_LICITACION_SP] (
	@idLicitacion numeric(18,0)
)
as
begin

	DELETE FROM dbo.Licitacion WHERE idLicitacion = @idLicitacion

	SELECT @idLicitacion
	
end
go

