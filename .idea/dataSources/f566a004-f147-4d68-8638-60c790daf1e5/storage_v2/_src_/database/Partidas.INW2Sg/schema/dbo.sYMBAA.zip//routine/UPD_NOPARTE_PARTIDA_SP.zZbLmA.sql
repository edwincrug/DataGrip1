CREATE PROCEDURE [dbo].[UPD_NOPARTE_PARTIDA_SP] (
	@idPartida numeric(18,0),
	@idUnidad numeric(18,0),
	@noParte nvarchar(200),
	@noParteNuevo nvarchar(200),
	@idUsuario numeric(18,0)
)
as
begin

	INSERT INTO [PartidaBitacora]
	SELECT @idPartida,@idUnidad,(SELECT TOP 1 noParte FROM Partida WHERE idPartida=@idPartida),@noParteNuevo,GETDATE(),@idUsuario
		
	UPDATE dbo.Partida
	SET noParte = @noParteNuevo
	WHERE idPartida = @idPartida AND idUnidad=@idUnidad
	
	SELECT @idPartida idPartida
	
end
go

