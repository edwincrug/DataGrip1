CREATE procedure [dbo].[SEL_ZONA_CONTRATO_SP] (
	@idUsuario numeric(18,0),
	@idContrato numeric(18,0),
	@idContratoProveedor numeric(18,0)
)
as
begin

	select 
		zon.idZona,
		nzo.orden as nivel,
		idPadre,
		nombre,
		zon.idNivelZona,
		CASE WHEN cpz.idZona IS NULL THEN 0 ELSE 1 END as selected
	from Zona zon
	LEFT JOIN NivelZona nzo ON nzo.idNivelZona = zon.idNivelZona 
	LEFT JOIN ContratoProveedorZona cpz ON cpz.idZona = zon.idZona AND cpz.idContratoProveedor = @idContratoProveedor
	WHERE 
		nzo.idCliente in(
			select idCliente
			FROM Licitacion lic 
			LEFT JOIN dbo.Contrato con ON con.idLicitacion = lic.idLicitacion
			WHERE con.idContrato =  @idContrato
		)
	order by orden

end
go

