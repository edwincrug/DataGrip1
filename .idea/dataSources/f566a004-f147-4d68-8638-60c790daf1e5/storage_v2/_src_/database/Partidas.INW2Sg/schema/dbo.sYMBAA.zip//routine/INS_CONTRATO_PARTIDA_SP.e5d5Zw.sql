CREATE procedure [dbo].[INS_CONTRATO_PARTIDA_SP] (
	@idUsuario numeric(18,0),
	@idUnidad numeric(18,0),
	@idContrato numeric(18,0),
	@json nvarchar(max)
)
as
begin


	DECLARE @venta as decimal(18,2)
	DECLARE @ventaTotalizada as decimal(18,2)
	DECLARE @idContratoUnidad as decimal(18,2)
	DECLARE @idPartida as decimal(18,2)


	DECLARE
		@precio1			decimal(18,2)=0,
		@precio2			decimal(18,2)=0,
		@precio3			decimal(18,2)=0,
		@precio4			decimal(18,2)=0,
		@precio5			decimal(18,2)=0,
		@precio6			decimal(18,2)=0,
		@precio7			decimal(18,2)=0,
		@precioMano			decimal(18,2),
		@precioRefaccion	decimal(18,2),
		@precioLubricante	decimal(18,2),
		@tiempo				time(7)
	
	SELECT @idContratoUnidad = idContratoUnidad FROM ContratoUnidad WHERE idUnidad = @idUnidad AND idContrato = @idContrato
	
	DECLARE @DatosGenerales TABLE(id int identity(1,1),Datos NVARCHAR(MAX))
	DECLARE @DatosPartida TABLE(id int identity(1,1),idPartida decimal(18,2),venta decimal(18,2)
	,precioMano	decimal(18,2),precioRefaccion decimal(18,2),precioLubricante decimal(18,2),tiempo time(7))
	
	INSERT INTO @DatosGenerales
	SELECT Item FROM [dbo].[SplitString](@json,'?')
	
	DECLARE @i int =1, @n int =(SELECT COUNT(*) FROM @DatosGenerales),@Datos NVARCHAR(MAX)
	
	WHILE @i<=@n
	BEGIN 
	SELECT @Datos = Datos FROM @DatosGenerales WHERE id=@i
	SELECT @idPartida = Item FROM [dbo].[SplitString](@Datos,'|') WHERE Position = 1
	SELECT @venta = Item FROM [dbo].[SplitString](@Datos,'|') WHERE Position = 2
	SELECT @precioMano = Item FROM [dbo].[SplitString](@Datos,'|') WHERE Position = 3
	SELECT @precioRefaccion = Item FROM [dbo].[SplitString](@Datos,'|') WHERE Position = 4
	SELECT @precioLubricante = Item FROM [dbo].[SplitString](@Datos,'|') WHERE Position = 5
	SELECT @tiempo = Item FROM [dbo].[SplitString](@Datos,'|') WHERE Position = 6


		set @ventaTotalizada = ISNULL(@precioMano,0) + ISNULL(@precioRefaccion,0) + ISNULL(@precioLubricante,0)


		if not exists (select 1 from ContratoPartida where idContratoUnidad = @idContratoUnidad and idPartida = @idPartida)
		begin
			INSERT INTO dbo.ContratoPartida
				(idContratoUnidad, idPartida, venta, fecha, idUsuario,precio1,precio2,precio3,precio4,precio5,precio6,precio7, precioMano, precioRefaccion, precioLubricante, tiempo)
			VALUES 
				( @idContratoUnidad, @idPartida, @venta,  GETDATE(), @idUsuario,0,0,0,0,0, 0,0, @precioMano,  @precioRefaccion, @precioLubricante, @tiempo)
		end
		else
		begin
			update dbo.ContratoPartida
				set 
					venta = @venta,
					fecha = GETDATE(),
					precio1 = @precio1,
					precio2 = @precio2,
					precio3 = @precio3,
					precio4 = @precio4,
					precio5 = @precio5,
					precio6 = @precio6,
					precio7 = @precio7,
					precioMano = @precioMano,
					precioRefaccion = @precioRefaccion,
					precioLubricante = @precioLubricante,
					tiempo = @tiempo
				where 
					idContratoUnidad = @idContratoUnidad 
					and idPartida = @idPartida
		end
	SET @i = @i + 1
	END
	
	SELECT @idContratoUnidad as idContratoUnidad

end
go

