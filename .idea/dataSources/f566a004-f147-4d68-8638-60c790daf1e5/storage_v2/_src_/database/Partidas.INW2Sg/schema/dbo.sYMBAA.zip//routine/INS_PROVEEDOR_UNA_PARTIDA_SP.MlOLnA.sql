CREATE procedure [dbo].[INS_PROVEEDOR_UNA_PARTIDA_SP] (
	@idProveedorCotizacion numeric(18,0),
	@idUsuario numeric(18,0),
	@idPartida numeric(18,0),
	@costoPieza decimal(18,2),
	@costoMano decimal(18,2),
	@tiempo INT
)
as
begin
	
		IF( EXISTS(SELECT 1 FROM dbo.ProveedorPartida WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idPartida = @idPartida) ) BEGIN
	
			UPDATE
				dbo.ProveedorPartida
			SET
				costoPieza = @costoPieza,
				costoMano = @costoMano,
				costo = (@costoPieza + @costoMano),
				tiempo = @tiempo,
				fecha = GETDATE(),
				idUsuario = @idUsuario
				--idPartidaEstatus = 3
			WHERE 
				idProveedorCotizacion = @idProveedorCotizacion 
				AND  idPartida = @idPartida
		END
		ELSE BEGIN
		
			INSERT INTO dbo.ProveedorPartida
				(idProveedorCotizacion, idPartida, costoPieza, costoMano, costo, tiempo, fecha, idUsuario, idPartidaEstatus)
			VALUES 
				(@idProveedorCotizacion, @idPartida, @costoPieza,@costoMano, (@costoPieza + @costoMano), @tiempo, GETDATE(), @idUsuario, 2)
		
		END
	

	--UPDATE
	--	dbo.ProveedorCotizacion
	--SET
	--	idCotizacionEstatus = 2
	--WHERE 
	--	idProveedorCotizacion = @idProveedorCotizacion

	--*******************************************************************************************************
	--BLOQUE TEMPORAL PARA ACTUALIZAR LAS COTIZACIONES APLICABLES PARA ESE PROVEEDOR
	--*******************************************************************************************************

	DECLARE @idProveedor numeric(18,0)	
	select TOP 1 @idProveedor = idProveedor from ProveedorCotizacion where idProveedorCotizacion=@idProveedorCotizacion 

	UPDATE CD
		set CD.costo = PP.costo
	from ASEPROT.dbo.CotizacionDetalle CD
	inner join ASEPROT.dbo.Cotizaciones C on C.idCotizacion = CD.idCotizacion
	inner join ProveedorPartida PP on PP.idPartida = CD.idPartida
	where C.idTaller = @idProveedor
	and PP.idProveedorCotizacion = @idProveedorCotizacion 
	and CD.costo = 0

	SELECT @idProveedorCotizacion as idProveedorCotizacion


end
go

