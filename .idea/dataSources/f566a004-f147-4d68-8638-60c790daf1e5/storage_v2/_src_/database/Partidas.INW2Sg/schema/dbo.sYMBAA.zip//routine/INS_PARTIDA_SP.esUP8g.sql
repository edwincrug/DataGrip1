
--[dbo].[INS_PARTIDA_SP] 1,1,1,1,1,'123','nissan','123','hola','foto','123', '<tiposOrdenes><tipoOrden><idTipoOrden>4</idTipoOrden></tipoOrden><tipoOrden><idTipoOrden>5</idTipoOrden></tipoOrden></tiposOrdenes>'

-- [dbo].[INS_PARTIDA_SP] 1,1,1,1,1,'123','nissan','123','hola','foto','123','<tiposOrdenes><tipoOrden><idTipoOrden>7</idTipoOrden></tipoOrden></tiposOrdenes>'


CREATE PROCEDURE [dbo].[INS_PARTIDA_SP] (
	@idUnidad numeric(18,0),
	@idTipoPartida numeric(18,0),
	@idEspecialidad numeric(18,0),
	@idPartidaClasificacion numeric(18,0),
	@idPartidaSubClasificacion numeric(18,0),
	@partida nvarchar(50),
	@marca	nvarchar(50),
	@noParte nvarchar(200),
	@descripcion nvarchar(500),
	@foto nvarchar(50),
	@instructivo nvarchar(50),
	@idUsuario numeric(18,0),
	@tiposOrdenes XML
)
AS
BEGIN
	DECLARE
	@idPartida			INT=0

	INSERT INTO [dbo].[Partida]
		(idUnidad
		,idTipoPartida
		,idEspecialidad
		,idPartidaClasificacion
		,idPartidaSubClasificacion
		,partida
		,marca
		,noParte
		,descripcion
		,foto
		,instructivo
		,estatus
		,idUsuario
		,fechaActualizacion
		,origen)
	VALUES 
		(@idUnidad
		,@idTipoPartida
		,@idEspecialidad 
		,@idPartidaClasificacion
		,@idPartidaSubClasificacion 
		,@partida
		,@marca
		,@noParte
		,@descripcion
		,REPLACE(@foto,'"','')
		,REPLACE(@instructivo,'"','')
		, 1
		,@idUsuario
		,GETDATE()
		,'INDIVIDUAL');

	SET @idPartida = @@IDENTITY

	IF(@tiposOrdenes IS NOT NULL)
	BEGIN
	
		DECLARE @tiposOrdenesT as TABLE(id int identity(1, 1), idTipoOrden int);
		INSERT INTO @tiposOrdenesT(idTipoOrden) 
			SELECT ParamValues.col.value('idTipoOrden[1]','int')
				FROM @tiposOrdenes.nodes('tiposOrdenes/tipoOrden') as ParamValues(col)
				
		INSERT INTO [dbo].[PartidaTipoOrdenServicio]
		SELECT 
			@idPartida
			,idTipoOrden 
		FROM @tiposOrdenesT
	
	END
	
	SELECT @idPartida idPartida
	
END
go

