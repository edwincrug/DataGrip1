CREATE FUNCTION [dbo].[SplitString]
(    
      @Input NVARCHAR(MAX),
      @Character CHAR(1)
)
RETURNS @Output TABLE (
      Item NVARCHAR(1000),
      Position INT
)
AS
BEGIN
      DECLARE @StartIndex INT, @EndIndex INT,@Position INT = 1
      
      SET @StartIndex = 1
      IF SUBSTRING(@Input, LEN(@Input) - 1, LEN(@Input)) <> @Character
      BEGIN
            SET @Input = @Input + @Character
      END
      WHILE CHARINDEX(@Character, @Input) > 0
      BEGIN
            SET @EndIndex = CHARINDEX(@Character, @Input)
            INSERT INTO @Output(Item, Position)
            SELECT SUBSTRING(@Input, @StartIndex, @EndIndex - 1),@Position
            SET @Input = SUBSTRING(@Input, @EndIndex + 1, LEN(@Input))
            SET @Position = @Position +1
      END
      RETURN
END
go

