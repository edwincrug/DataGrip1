
CREATE procedure [dbo].[INS_PROVEEDOR_ENCABEZADO_DOCUMENTO_SP] (
	@idUsuario numeric(18,0),
	@idProveedorEncabezado numeric(18,0),
	@idDocumento numeric(18,0),
	@folio nvarchar(100),
	@vigencia datetime,
	@archivo nvarchar(500)
)
as
begin

	INSERT INTO [dbo].[ProveedorEncabezadoDocumento]
           ([idProveedorEncabezado]
           ,[idDocumento]
           ,[folio]
           ,[vigencia]
           ,[fechaCarga]
           ,[archivo])
     VALUES
           (@idProveedorEncabezado
           ,@idDocumento
           ,@folio
           ,@vigencia
           ,GETDATE()
           ,REPLACE(@archivo,'"',''))
           
     SELECT @@IDENTITY

end
go

