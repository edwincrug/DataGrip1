CREATE procedure [dbo].[SEL_EMPRESA_PROVEEDOR_ENCABEZADO_SP] (
	@idProveedorEncabezado numeric(18,0)
)
as
begin

	select  nombreComercial,  
			razonSocial, 
			idBPRO
	from Empresa e 
	inner join ProveedorEncabezadoEmpresa pee on e.idEmpresa = pee.idEmpresa 
	where idProveedorEncabezado = @idProveedorEncabezado

end
go

