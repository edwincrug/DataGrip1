CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_ESPECIALIDAD_SELECTED_SP] (
	@idProveedor numeric(18,0)
)
as
begin

	SELECT
		pes.idProveedorEspecialidad,
		pes.idEspecialidad,
		esp.especialidad
	FROM
		dbo.ProveedorEspecialidad pes
		LEFT JOIN dbo.Especialidad esp ON esp.idEspecialidad = pes.idEspecialidad
	WHERE 
		esp.estatus = 1
		and pes.idProveedor = @idProveedor
		

end
go

