-- =============================================  
-- Author:  <Alan Rosales>  
-- Create date: <26/07/2017>  
-- Description: <DDL ProveedorClasificacion>  
-- =============================================  
CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_CLASIFICACION_DDL_SP]  
 -- Add the parameters for the stored procedure here  
 @idCategoria numeric(18,2)  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
  select 0 value, 'Todos' label
  union all
    -- Insert statements for procedure here  
 SELECT   
  PC.idProveedorClasificacion 'value',  
  PC.clasificacion 'label'  
 FROM ProveedorClasificacion PC  
 WHERE PC.idCategoria = @idCategoria  
END
go

