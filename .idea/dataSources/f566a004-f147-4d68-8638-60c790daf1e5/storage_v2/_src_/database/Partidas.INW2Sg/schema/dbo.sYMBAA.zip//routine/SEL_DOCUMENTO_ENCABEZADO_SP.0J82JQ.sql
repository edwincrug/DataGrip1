
CREATE procedure [dbo].[SEL_DOCUMENTO_ENCABEZADO_SP] 
as
begin

	SELECT
		idProveedorEncabezadoDocumento,
		idProveedorEncabezado,
		pdo.idDocumento,
		doc.descripcion,
		folio,
		vigencia,
		convert(nvarchar(10),vigencia,103) as vigenciaTXT,
		fechaCarga,
		convert(nvarchar(10),fechaCarga,103) as fechaCargaTXT,
		archivo
	FROM
		dbo.ProveedorEncabezadoDocumento pdo
		LEFT JOIN Documento doc ON doc.idDocumento = pdo.idDocumento
	where pdo.idDocumento in (4,5,13,2)
	and doc.idTipoDocumento = 1

end
go

