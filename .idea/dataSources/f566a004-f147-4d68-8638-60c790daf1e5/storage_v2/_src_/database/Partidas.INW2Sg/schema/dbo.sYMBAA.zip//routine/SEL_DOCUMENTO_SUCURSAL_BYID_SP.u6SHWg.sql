
create procedure [dbo].[SEL_DOCUMENTO_SUCURSAL_BYID_SP] (
	@idProveedor		numeric(18,0)
)
as
begin

	SELECT
		idProveedorDocumento,
		idProveedor,
		pdo.idDocumento,
		doc.descripcion,
		archivo
	FROM
		dbo.ProveedorDocumento pdo
		LEFT JOIN Documento doc ON doc.idDocumento = pdo.idDocumento
	where 
		doc.idTipoDocumento = 2
		and pdo.idProveedor = @idProveedor

end
go

