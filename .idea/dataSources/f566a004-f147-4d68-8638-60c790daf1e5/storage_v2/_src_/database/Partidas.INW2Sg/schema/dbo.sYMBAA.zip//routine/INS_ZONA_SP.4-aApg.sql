CREATE procedure [dbo].[INS_ZONA_SP] (
	@idNivelZona numeric(18,0),
	@idPadre numeric(18,0),
	@nombre nvarchar(200)
)
as
begin
	
	INSERT INTO Partidas.dbo.Zona
		(idNivelZona, idPadre, nombre, estatus)
	VALUES 
		(@idNivelZona ,@idPadre , @nombre, 1)
	
SELECT @@IDENTITY

end
go

