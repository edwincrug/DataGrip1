CREATE function [dbo].[SEL_PROVEEDOR_ENCABEZADO_ESPECIALIDAD_FN] (
	@idProveedor numeric(18,0)
)
RETURNS nvarchar(max)
as
begin

	DECLARE @result nvarchar(max)
	
	SET @result = ''
	
	SELECT @result = @result + esp.especialidad + ' | ' 
	FROM dbo.ProveedorEncabezado pro
		LEFT JOIN dbo.ProveedorEncabezadoespecialidad pes ON pes.idProveedorEncabezado = pro.idProveedorEncabezado
		LEFT JOIN dbo.Especialidad esp ON esp.idEspecialidad = pes.idEspecialidad
	 WHERE  pro.idProveedorEncabezado = @idProveedor
	 
	select @result = substring(@result, 0, len(@result) - 1) 
	
	return @result

end
go

