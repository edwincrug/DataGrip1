--SEL_USUARIO_LOGIN_SP 'alan','alan'  
CREATE PROCEDURE [dbo].[SEL_USUARIO_LOGIN_SP]   
 @usuario as nvarchar(50),  
 @password as nvarchar(50)  
AS  
BEGIN  
  
 SELECT 
	U.[idUsuario]  
    ,U.[nombre]  
    ,U.[usuario]  
    ,U.[password]
	,U.[correoElectronico]  
    ,U.[idPerfil]  
    ,U.[estatus]
	,ISNULL(UP.idProveedor,0) idProveedor
	,P.descripcion AS perfil
   FROM [dbo].[Usuario] U 
   left join UsuarioProveedor UP on U.idUsuario = UP.idUsuario
   LEFT JOIN Perfil P ON P.idPerfil=U.idPerfil
 WHERE   
 usuario = @usuario  
 and [password] = @password  
 and U.estatus=1
  
END

go

