CREATE function [dbo].[SEL_PROVEEDOR_ENCABEZADO_TIPO_UNIDAD_FN] (
	@idProveedor numeric(18,0)
)
RETURNS nvarchar(max)
as
begin

	DECLARE @result nvarchar(max)
	
	SET @result = ''
	
	SELECT @result = @result + tun.tipo + ' | ' 
	FROM dbo.ProveedorEncabezado pro
		LEFT JOIN dbo.ProveedorTipoUnidad ptu ON ptu.idProveedor = pro.idProveedorEncabezado
		LEFT JOIN dbo.TipoUnidad tun ON tun.idTipoUnidad = ptu.idTipoUnidad
	 WHERE  pro.idProveedorEncabezado = @idProveedor
	 
	select @result = substring(@result, 0, len(@result) - 1) 
	
	return @result

end
go

