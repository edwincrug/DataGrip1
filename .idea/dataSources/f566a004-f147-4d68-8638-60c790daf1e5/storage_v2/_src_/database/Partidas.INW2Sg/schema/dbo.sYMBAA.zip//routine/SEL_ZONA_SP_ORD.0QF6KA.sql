CREATE procedure [dbo].[SEL_ZONA_SP_ORD] (
	@idUsuario numeric(18,0),
	@idCliente numeric(18,0)
)
as
begin

	select idZona, nzo.orden as nivel, idPadre, case when nombre ='Edo México' then 'Estado de México' else nombre end nombre, zon.idNivelZona, zon.referencia from Zona zon
		LEFT JOIN NivelZona nzo ON nzo.idNivelZona = zon.idNivelZona 
	WHERE  nzo.idCliente = @idCliente
	order by nombre asc

end
go

