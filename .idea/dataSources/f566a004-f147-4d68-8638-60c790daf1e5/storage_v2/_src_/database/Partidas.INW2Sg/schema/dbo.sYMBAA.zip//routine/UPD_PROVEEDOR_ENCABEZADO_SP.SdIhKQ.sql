CREATE procedure [dbo].[UPD_PROVEEDOR_ENCABEZADO_SP] (
	@idProveedorEncabezado numeric(18,0),
	@nombreComercial nvarchar(200),
	@razonSocial nvarchar(500),
	@RFC nvarchar(13),
	@contacto nvarchar(200), --nuevo
	@telefono nvarchar(200), --nuevo
	@mail nvarchar(200), --nuevo
	--@fechaInicio datetime,
	@idCategoria numeric(18,0),
	@idProveedorClasificacion numeric(18,0), --nuevo
	--@idProveedorSubClasificacion numeric(18,0), --nuevo
	
	--NUEVOS PARAMETROS PARA INGRESAR DATOS FISCALES
	@tipoPersona nvarchar(3),
    @pais nvarchar(150),
    @estado nvarchar(150),
    @ciudad nvarchar(150),
    @delegacion nvarchar(150),
    @colonia nvarchar(150),
    @calle  nvarchar(150),
    @numInt nvarchar(150),
    @numExt nvarchar(150),
    @cp nvarchar(5),
	@lada nvarchar(10),
	--NUEVO PARAMETRO PARA LOGO DE PROVEEDOR
	@logo	nvarchar(50)
)
as
begin
	
	declare @idProveedorBP  numeric(18,0),
			@SQLString nvarchar(max),
			 @ParmDefinition nvarchar(max),
			 @ParmInsert nvarchar(max),
			 @ParmUpdate nvarchar(max),
			 @idPersona numeric(18,0), 
			 @dir varchar(200),
			 @server  varchar(200),
			 @DBProduccion  varchar(200),
			 @idEmpresa    numeric(18,0)
	--VERIFICAMOS SI EXISTE EL RFC EN BPRO
	/*IF NOT EXISTS (SELECT * FROM [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS] where ltrim(rtrim(PER_RFC)) = @RFC)
	BEGIN
	--SE REGISTRA TALLER EN BPRO  
		INSERT INTO [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]  
		(  
		 PER_RFC, 
		 PER_TIPO, 
		 PER_NOMRAZON, 
		 PER_TELEFONO1, 
		 PER_EMAIL,  
		 PER_PAIS, 
		 PER_ESTADO, 
		 PER_CIUDAD, 
		 PER_DELEGAC, 
		 PER_COLONIA,  
		 PER_CALLE1, 
		 PER_NUMEXTER, 
		 PER_CODPOS, 
		 PER_CVEUSU, 
		 PER_FECHOPE,  
		 PER_STATUS, 
		 PER_LADA, 
		 PER_FECING, 
		 PER_HORING, 
		 PER_CVEUSUING  
		)  
	   VALUES  
		(  
		 @RFC, 
		 SUBSTRING(@tipoPersona,1,10), 
		 substring(@razonSocial,1,150), 
		 SUBSTRING(@telefono,1,18), 
		 substring(@mail,1,70),  
		 substring(@pais,1,10), 
		 substring(@estado,1,10), 
		 substring(@ciudad,1,40), 
		 substring(@delegacion,1,60),
		 substring(@colonia,1,150),  
		 substring(@calle,1,70), 
		 substring(@numExt,1,20), 
		 @cp, 
		 'GMI', 
		 CONVERT(varchar, GETDATE(), 103),  
		 'ACTIVO', 
		 substring(@Lada,1,6), 
		 CONVERT(varchar, GETDATE(), 103),   
		 SUBSTRING(CONVERT(varchar, GETDATE(), 108), 1, 5), 
		 1  
		)
		--OBTENEMOS EL IDProveedor DE BPRO
	SET @idProveedorBP = (SELECT MAX(PER_IDPERSONA) FROM [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]) 
	END
	ELSE
	BEGIN
		----OBTENEMOS EL IDProveedor DE BPRO POR RFC
		SET @idProveedorBP = (SELECT PER_IDPERSONA FROM [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS] where PER_RFC = @RFC) 
			--SE ACTUALIZA TALLER EN BPRO  
		UPDATE [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]  
		SET 
			PER_TIPO = @tipoPersona, 
			PER_TELEFONO1 = SUBSTRING(@telefono,1,18), 
			PER_EMAIL = @mail,   
			PER_CVEUSU = 'GMI', --VERIFICAR SI VA A CAMBIAR
			PER_FECHOPE = CONVERT(varchar, GETDATE(), 103),  
			PER_STATUS = 'ACTIVO', --VERIFICAR SI VA A CAMBIAR
			PER_LADA = substring(@lada,1,6),   
			PER_FECING = CONVERT(varchar, GETDATE(), 103),   
			PER_HORING = SUBSTRING(CONVERT(varchar, GETDATE(), 108), 1, 5),   
			PER_CVEUSUING = 1  
		WHERE PER_IDPERSONA = @idProveedorBP  
	END
	*/

	CREATE TABLE #Empresa(
		idEmpresa numeric(18,0),
		RFCEmpresa   varchar(20),
		[Server]	 varchar(200),
		DBProduccion   varchar(200)
	)
	
	create table #serverPersona(
		per_idpersona   numeric(18,0),
		idEmpresa		numeric(18,0)
	)
	
	insert into #Empresa
	select idEmpresa, rfc, [server], DBProduccion from Empresa where [server] is not null and DBProduccion is not null
	
	SET @ParmDefinition = N'@RFCAux varchar(20), @per_idpersona varchar(30) OUTPUT';
	set @ParmInsert = N'@RFCAux nvarchar(13),
						@tipoPersonaAux nvarchar(3),
						@razonSocialAux	nvarchar(500),
						@telefonoAux nvarchar(200),
						@mailAux nvarchar(200),
						@paisAux nvarchar(150),
						@estadoAux nvarchar(150),
						@ciudadAux nvarchar(150),
						@delegacionAux nvarchar(150),
						@coloniaAux nvarchar(150),
						@calleAux nvarchar(150),
						@numExtAux nvarchar(150),
						@cpAux nvarchar(5),
						@LadaAux nvarchar(10),
						@idProveedorBPAux  numeric(18,0) OUTPUT';
	set @ParmUpdate = N'@RFCAux nvarchar(13),
						@tipoPersonaAux nvarchar(3),
						@razonSocialAux	nvarchar(500),
						@telefonoAux nvarchar(200),
						@mailAux nvarchar(200),
						@paisAux nvarchar(150),
						@estadoAux nvarchar(150),
						@ciudadAux nvarchar(150),
						@delegacionAux nvarchar(150),
						@coloniaAux nvarchar(150),
						@calleAux nvarchar(150),
						@numExtAux nvarchar(150),
						@cpAux nvarchar(5),
						@LadaAux nvarchar(10),
						@idProveedorBPAux  numeric(18,0) OUTPUT';


	DECLARE _cursor CURSOR FOR 
	SELECT idEmpresa, [server], DBProduccion FROM #Empresa order by idEmpresa
	
	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @idEmpresa, @server, @DBProduccion
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		set @dir = @server + '.' + @DBProduccion
		--set @dir = '[Partidas]'
		SET @SQLString = N'SELECT top 1 @per_idpersona =  per_idpersona
		   FROM ' + @dir + '.dbo.per_personas
		   WHERE per_rfc = @RFCAux'; 
		EXECUTE sp_executesql @SQLString, @ParmDefinition, @rfcAux = @rfc, @per_idpersona=@idPersona OUTPUT;  
		--SELECT @idPersona;

		if @idPersona is not null
		begin
			/*update en GA*/
			set @SQLString = N'update ' + @dir + '.dbo.per_personas set
					PER_TIPO = @tipoPersonaAux, 
					PER_TELEFONO1 = SUBSTRING(@telefonoAux,1,18), 
					PER_EMAIL = @mailAux,   
					PER_CVEUSU = ''GMI'', --VERIFICAR SI VA A CAMBIAR
					PER_FECHOPE = CONVERT(varchar, GETDATE(), 103),  
					PER_STATUS = ''ACTIVO'', --VERIFICAR SI VA A CAMBIAR
					PER_LADA = substring(@ladaAux,1,6),   
					PER_FECING = CONVERT(varchar, GETDATE(), 103),   
					PER_HORING = SUBSTRING(CONVERT(varchar, GETDATE(), 108), 1, 5),   
					PER_CVEUSUING = 1  
				WHERE PER_IDPERSONA = @idProveedorBPAux';

			EXECUTE sp_executesql @SQLString, @ParmInsert, 
					@rfcAux = @rfc,
					@tipoPersonaAux = @tipoPersona,
					@razonSocialAux = @razonSocial,
					@telefonoAux = @telefono,
					@mailAux = @mail,
					@paisAux = @pais,
					@estadoAux = @estado,
					@ciudadAux = @ciudad,
					@delegacionAux = @delegacion,
					@coloniaAux = @colonia,
					@calleAux = @calle,
					@numExtAux = @numExt,
					@cpAux = @cp,
					@LadaAux = @Lada,
					@idProveedorBPAux=@idPersona;

			insert into #serverPersona
			select @idPersona, @idEmpresa
		end
		else
		begin
			/*insert en GA*/
			set @SQLString = N'insert into ' + @dir + '.dbo.per_personas (PER_RFC, 
				 PER_TIPO, 
				 PER_NOMRAZON, 
				 PER_TELEFONO1, 
				 PER_EMAIL,  
				 PER_PAIS, 
				 PER_ESTADO, 
				 PER_CIUDAD, 
				 PER_DELEGAC, 
				 PER_COLONIA,  
				 PER_CALLE1, 
				 PER_NUMEXTER, 
				 PER_CODPOS, 
				 PER_CVEUSU, 
				 PER_FECHOPE,  
				 PER_STATUS, 
				 PER_LADA, 
				 PER_FECING, 
				 PER_HORING, 
				 PER_CVEUSUING)
				 VALUES(
					 @RFCAux, 
					 SUBSTRING(@tipoPersonaAux,1,10), 
					 substring(@razonSocialAux,1,150), 
					 SUBSTRING(@telefonoAux,1,18), 
					 substring(@mailAux,1,70),  
					 substring(@paisAux,1,10), 
					 substring(@estadoAux,1,10), 
					 substring(@ciudadAux,1,40), 
					 substring(@delegacionAux,1,60),
					 substring(@coloniaAux,1,150),  
					 substring(@calleAux,1,70), 
					 substring(@numExtAux,1,20), 
					 @cpAux,
					 ''GMI'', 
					 CONVERT(varchar, GETDATE(), 103),  
					 ''ACTIVO'', 
					 substring(@LadaAux,1,6), 
					 CONVERT(varchar, GETDATE(), 103),   
					 SUBSTRING(CONVERT(varchar, GETDATE(), 108), 1, 5), 
					 1  
					) 					
					SET @idProveedorBPAux = (SELECT MAX(PER_IDPERSONA) FROM ' + @dir + '.[dbo].[PER_PERSONAS]) '
				EXECUTE sp_executesql @SQLString, @ParmInsert, 
						@rfcAux = @rfc,
						@tipoPersonaAux = @tipoPersona,
						@razonSocialAux = @razonSocial,
						@telefonoAux = @telefono,
						@mailAux = @mail,
						@paisAux = @pais,
						@estadoAux = @estado,
						@ciudadAux = @ciudad,
						@delegacionAux = @delegacion,
						@coloniaAux = @colonia,
						@calleAux = @calle,
						@numExtAux = @numExt,
						@cpAux = @cp,
						@LadaAux = @Lada,
						@idProveedorBPAux = @idProveedorBP OUTPUT;

			insert into #serverPersona
			select @idProveedorBP, @idEmpresa
		end
		
		set @idpersona = null
		
		select * from #serverPersona
		print @SQLString
		
		FETCH NEXT FROM _cursor INTO @idEmpresa, @server, @DBProduccion
	END
	CLOSE _cursor
	DEALLOCATE _cursor

	
	UPDATE dbo.ProveedorEncabezado
		SET nombreComercial = @nombreComercial, 
		razonSocial = @razonSocial, 
		RFC = @RFC, 
		contacto = @contacto, 
		telefono =@telefono, 
		mail = @mail,
		--fechaInicio = @fechaInicio, 
		idCategoria = @idCategoria, 
		idProveedorClasificacion = @idProveedorClasificacion,
		tipoPersona = @tipoPersona,
		Pais = @pais,
		Estado = @estado,
		Ciudad = @ciudad,
		Delegacion = @delegacion,
		Colonia = @colonia,
		Calle = @calle,
		NumInt = @numInt,
		NumExt = @numExt,
		CP = @cp,
		Lada = @lada,
		logo = @logo
	WHERE 
		idProveedorEncabezado = @idProveedorEncabezado

		
	declare @per_persona numeric(18,0);
	DECLARE _cursor CURSOR FOR 
	SELECT idEmpresa, per_idpersona FROM #serverPersona

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @idEmpresa, @per_persona
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		if not exists (select * from ProveedorEncabezadoEmpresa where idEmpresa = @idEmpresa and idProveedorEncabezado = @idProveedorEncabezado)
		begin
			insert into ProveedorEncabezadoEmpresa (idEmpresa, idProveedorEncabezado, idBPRO)
			values(@idEmpresa, @idProveedorEncabezado, @per_persona)
		end

		FETCH NEXT FROM _cursor INTO @idEmpresa, @per_persona
	END
	CLOSE _cursor
	DEALLOCATE _cursor
		
	drop table #Empresa
	drop table #serverPersona
	
	SELECT @idProveedorEncabezado
end

go

