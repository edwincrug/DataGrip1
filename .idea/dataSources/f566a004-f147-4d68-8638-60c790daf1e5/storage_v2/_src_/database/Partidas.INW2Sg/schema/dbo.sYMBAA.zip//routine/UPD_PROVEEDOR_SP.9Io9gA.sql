CREATE procedure [dbo].[UPD_PROVEEDOR_SP] (
	@idProveedor numeric(18,0),
	@nombreComercial nvarchar(200),
	@razonSocial nvarchar(500),
	@RFC nvarchar(20),
	@contacto nvarchar(200), --nuevo
	@telefono nvarchar(200), --nuevo
	@mail nvarchar(200), --nuevo
	@fechaInicio datetime,
	@idCategoria numeric(18,0),
	@idProveedorClasificacion numeric(18,0), --nuevo
	@direccion nvarchar(500),
	@latitud nvarchar(50),
	@longitud nvarchar(50),
	@poligono nvarchar(200),
	@jsonCombustible varchar(max),
	@jsonEspecialidad varchar(max),
	--NUEVOS PARAMETROS PARA INGRESAR DATOS FISCALES
	@tipoPersona nvarchar(50),
	@pais nvarchar(150),
	@estado nvarchar(150),
	@ciudad nvarchar(150),
	@delegacion nvarchar(150),
	@colonia nvarchar(150),
	@calle  nvarchar(150),
	@numInt nvarchar(150),
	@numExt nvarchar(150),
	@cp nvarchar(5),
	@lada nvarchar(10)
)
as
begin
	
	/*--obtenemos el idProveedor de BP
	--OBTENEMOS EL IDProveedor DE BPRO
	declare @idProveedorBP  numeric(18,0)
	--VALIDAMOS SI EXISTE EN BPRO
	IF EXISTS (SELECT * FROM [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS] where PER_RFC = @RFC)
	BEGIN
		select @idProveedorBP = PER_IDPERSONA from [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS] where PER_RFC = @RFC
		--SE ACTUALIZA TALLER EN BPRO  
		UPDATE [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]  
		SET 
			PER_TIPO = @tipoPersona, 
			PER_TELEFONO1 = SUBSTRING(@telefono,1,18), 
			PER_EMAIL = @mail,   
			PER_CVEUSU = 'GMI', --VERIFICAR SI VA A CAMBIAR
			PER_FECHOPE = CONVERT(varchar, GETDATE(), 103),  
			PER_STATUS = 'ACTIVO', --VERIFICAR SI VA A CAMBIAR
			PER_LADA = @lada,   
			PER_FECING = CONVERT(varchar, GETDATE(), 103),   
			PER_HORING = SUBSTRING(CONVERT(varchar, GETDATE(), 108), 1, 5),   
			PER_CVEUSUING = 1  
		WHERE PER_IDPERSONA = @idProveedorBP  
	END
	else
	begin
		INSERT INTO [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]  
		(  
		 PER_RFC, 
		 PER_TIPO, 
		 PER_NOMRAZON, 
		 PER_TELEFONO1, 
		 PER_EMAIL,  
		 PER_PAIS, 
		 PER_ESTADO, 
		 PER_CIUDAD, 
		 PER_DELEGAC, 
		 PER_COLONIA,  
		 PER_CALLE1, 
		 PER_NUMEXTER, 
		 PER_CODPOS, 
		 PER_CVEUSU, 
		 PER_FECHOPE,  
		 PER_STATUS, 
		 PER_LADA, 
		 PER_FECING, 
		 PER_HORING, 
		 PER_CVEUSUING  
		)  
	   VALUES  
		(  
		 @RFC, 
		 SUBSTRING(@tipoPersona,1,10), 
		 substring(@razonSocial,1,150), 
		 SUBSTRING(@telefono,1,18), 
		 substring(@mail,1,70),  
		 substring(@pais,1,10), 
		 substring(@estado,1,10), 
		 substring(@ciudad,1,40), 
		 substring(@delegacion,1,60),
		 substring(@colonia,1,150),  
		 substring(@calle,1,70), 
		 substring(@numExt,1,20), 
		 @cp, 
		 'GMI', 
		 CONVERT(varchar, GETDATE(), 103),  
		 'ACTIVO', 
		 substring(@Lada,1,6), 
		 CONVERT(varchar, GETDATE(), 103),   
		 SUBSTRING(CONVERT(varchar, GETDATE(), 108), 1, 5), 
		 1  
		)
		--OBTENEMOS EL IDProveedor DE BPRO
		SET @idProveedorBP = (SELECT MAX(PER_IDPERSONA) FROM [192.168.20.31].[GATPartsToluca].[dbo].[PER_PERSONAS]) 
	end

	--ACTUALIZAMOS PROVEEDOR
	UPDATE
		dbo.Proveedor
	SET
		nombreComercial = @nombreComercial,
		razonSocial = @razonSocial,
		RFC = @RFC,
		contacto  = @contacto,
		telefono = @telefono,
		mail = @mail,
		fechaInicio = @fechaInicio,
		idCategoria = @idCategoria,
		idProveedorClasificacion=@idProveedorClasificacion,
		direccion = @direccion,
		latitud = @latitud,
		longitud = @longitud,
		poligono = @poligono,
		idBPRO = @idProveedorBP
	WHERE 
	idProveedor = @idProveedor

	if exists (select * from ProveedorDatosFiscales where idProveedor=@idProveedor)
	begin
	--ACTUALIZAMOS DATOS FISCALES
	update ProveedorDatosFiscales set
	   [tipoPersona] = @tipoPersona
      ,[Pais] = @pais
      ,[Estado] = @estado
      ,[Ciudad] = @ciudad 
      ,[Delegacion] = @delegacion
      ,[Colonia] = @colonia
      ,[Calle] = @calle
      ,[NumInt] = @numInt
      ,[NumExt] = @numExt
      ,[CP] = @cp
	  ,[Lada] = @lada
	where idProveedor = @idProveedor
	end
	else
	begin
		insert into ProveedorDatosFiscales([idProveedor],[tipoPersona],[Pais],[Estado],[Ciudad],[Delegacion],[Colonia],[Calle],[NumInt],[NumExt],[CP],[Lada])
		values(@idProveedor, @tipoPersona, @pais , @estado, @ciudad, @delegacion, @colonia, @calle, @numInt, @numExt, @cp, @lada)
	end

	
	
	--CREAMOS TABLA TEMPORAL PARA EL JSON
	CREATE TABLE #JSON(
		element_id numeric(18,0),
		secuenceNo numeric(18,0),
		parent_ID numeric(18,0),
		Object_ID numeric(18,0),
		NAME nvarchar(MAX),
		StringValue nvarchar(MAX),
		ValueType nvarchar(MAX)
	)
	--ELIMINAMOS ProveedorTipoCombustible
	DELETE FROM ProveedorTipoCombustible where idProveedor = @idProveedor
	--ELIMINAMOS ProveedorEspecialidadCombustible
	DELETE FROM ProveedorEspecialidadCombustible where idProveedor=@idProveedor


	--PRIMERO INSERTAMOS LOS COMBUSTIBLES
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@jsonCombustible)
	
	insert into ProveedorTipoCombustible
	select distinct @idProveedor, StringValue from #JSON where NAME = 'idTipoCombustible'


	--ELIMINAMOS Y AHORA METEMOS LAS ESPECIALIDADES
	DELETE FROM #JSON
	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@jsonEspecialidad)

	declare 
	@idTipoCombustible numeric(18,0),
	@idEspecialidad numeric(18,0)

	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 
	SELECT Object_ID FROM #JSON
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		select @idTipoCombustible =  StringValue from #JSON where parent_ID = @parent and Name='idTipoCombustible' AND Object_ID IS NULL
		select @ideSPECIALIDAD = StringValue from #JSON where parent_ID = @parent and Name='idEspecialidad' AND Object_ID IS NULL
		
		insert into ProveedorEspecialidadCombustible values(@idProveedor,@idEspecialidad,@idTipoCombustible)

		FETCH NEXT FROM _cursor INTO @parent
	end
	CLOSE _cursor 
	DEALLOCATE _cursor

	DROP TABLE #JSON

	SELECT @idProveedor*/
	
	select '' as idProveedor
end
go

