
-- =============================================
-- Author:		<Armando Garcia>
-- Create date: <08/09/2020>
-- Description:	<Obtiene la lista de documentos carga masiva>
-- =============================================
CREATE PROCEDURE [dbo].[SEL_LISTA_CARGADOCUMENTO_SP]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT
	CD.[idCargaDocumento], 
	CD.[nombreArchivo], 
	CD.[idEstatusCargaMasiva], 
	CD.[fechaCarga], 
	CD.[fechaFinalizacion], 
	CD.[idTipoCarga],
	TC.[TipoCarga],
	CD.[idUsuario],
	ECM.[EstatusCargaMasiva],
	CD.error,
	CD.nombreArchivoUsuario,
	tieneDetalles = (SELECT COUNT(*) FROM [dbo].[ProveedorPartidaBitacoraMasiva] PPBM WHERE PPBM.[idCargaDocumento]=CD.[idCargaDocumento] AND PPBM.comentario not like 'REGISTRO%')
	FROM [dbo].[CargaDocumento] CD
	INNER JOIN TipoCarga TC ON TC.[idTipoCarga] = CD.[idTipoCarga]
	INNER JOIN [dbo].[EstatusCargaMasiva] ECM ON ECM.idEstatusCargaMasiva = CD.idEstatusCargaMasiva
	ORDER BY CD.idCargaDocumento
END
go

