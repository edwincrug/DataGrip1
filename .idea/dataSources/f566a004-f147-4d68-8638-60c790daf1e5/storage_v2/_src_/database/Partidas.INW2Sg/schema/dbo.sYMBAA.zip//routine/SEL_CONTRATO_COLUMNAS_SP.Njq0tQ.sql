CREATE procedure [dbo].[SEL_CONTRATO_COLUMNAS_SP] (
	@idUsuario numeric(18,0),
	@idContrato numeric(18,0)
)
as
begin

	SELECT
		'C' + CAST(pro.idProveedor AS NVARCHAR(10)) as field,
		pro.razonSocial as header,
		'150px' as width
	FROM
		dbo.ContratoProveedor cpr
		LEFT JOIN dbo.Proveedor pro ON pro.idProveedor = cpr.idProveedor
	WHERE 
		cpr.idContrato = @idContrato

end
go

