CREATE PROCEDURE [dbo].[UPD_PARTIDA_SP] (
	@idPartida numeric(18,0),
	@idUnidad numeric(18,0),
	@idTipoPartida numeric(18,0),
	@idEspecialidad numeric(18,0),
	@idPartidaClasificacion numeric(18,0),
	@idPartidaSubClasificacion numeric(18,0),
	@partida nvarchar(50),
	@marca nvarchar(50),
	@noParte nvarchar(200),
	@descripcion nvarchar(MAX),
	@foto nvarchar(50),
	@instructivo nvarchar(50),
	@tiposOrdenes XML
)
as
begin

	
	UPDATE
		dbo.Partida
	SET
		
		--idUnidad = @idUnidad,
		idTipoPartida = @idTipoPartida,
		idEspecialidad = @idEspecialidad,
		idPartidaClasificacion = @idPartidaClasificacion,
		idPartidaSubClasificacion = @idPartidaSubClasificacion,
		partida =@partida,
		marca = @marca,
		noParte = @noParte,
		descripcion = @descripcion,
		foto = REPLACE(@foto,'"',''),
		instructivo = REPLACE(@instructivo,'"','')
	WHERE 
		idPartida = @idPartida

	IF(@tiposOrdenes IS NOT NULL)
	BEGIN

		delete from [dbo].[PartidaTipoOrdenServicio] where idPartida = @idPartida
	
		DECLARE @tiposOrdenesT as TABLE(id int identity(1, 1), idTipoOrden int);
		INSERT INTO @tiposOrdenesT(idTipoOrden) 
			SELECT ParamValues.col.value('idTipoOrden[1]','int')
				FROM @tiposOrdenes.nodes('tiposOrdenes/tipoOrden') as ParamValues(col)
				
		INSERT INTO [dbo].[PartidaTipoOrdenServicio]
		SELECT 
			@idPartida
			,idTipoOrden 
		FROM @tiposOrdenesT
	
	END
	
	SELECT @idPartida idPartida

	
end
go

