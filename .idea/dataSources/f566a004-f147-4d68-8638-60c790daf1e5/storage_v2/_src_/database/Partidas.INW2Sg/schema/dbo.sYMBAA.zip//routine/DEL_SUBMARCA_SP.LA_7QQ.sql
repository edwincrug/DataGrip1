CREATE PROCEDURE [dbo].[DEL_SUBMARCA_SP] (
	@idSubMarca numeric(18,0)
)
as
begin

	DELETE FROM dbo.SubMarca WHERE idSubMarca = @idSubMarca
	
	SELECT @idSubMarca
	
end
go

