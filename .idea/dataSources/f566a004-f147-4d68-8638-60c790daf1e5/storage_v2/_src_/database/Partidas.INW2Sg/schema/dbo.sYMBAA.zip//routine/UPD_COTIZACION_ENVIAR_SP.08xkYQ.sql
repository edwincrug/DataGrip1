CREATE procedure [dbo].[UPD_COTIZACION_ENVIAR_SP] (
	@idUsuario numeric(18,0),
	@idProveedorCotizacion numeric(18,0)
)
as
begin

	UPDATE ProveedorCotizacion SET idCotizacionEstatus = 4 WHERE idProveedorCotizacion = @idProveedorCotizacion

	SELECT @idProveedorCotizacion
	
end
go

