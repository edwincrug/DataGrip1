-- =============================================  
-- Author:  <Alan Rosales>  
-- Create date: <07/12/2017>  
-- Description: <>  
-- Test: SEL_ZONA_ALL_SP  
-- =============================================  
CREATE PROCEDURE [dbo].[SEL_ZONA_ALL_SP]  
AS  
BEGIN  
   
 select   
  C.nombreComercial nombre,  
  ISNULL(C.logo,'') logo,
  '' direccion,  
  '' latitud,  
  '' longitud,  
  (9990 + idCliente) idZona,  
  0 idPadre,  
  1 orden,  
  2 maxOrden  
 from Cliente C  
  
 union all  
  
 select    
  Z.nombre as nombre,  
  ISNULL((select CAux.logo from Cliente CAux where CAux.idCliente = NZ.idCliente),'') logo,
  case   
   when NZ.orden = (select MAX(orden) from NivelZona where idCliente = C.idCliente) then ISNULL(Z.direccion,'')  
   else ''  
  END direccion,  
  case   
   when NZ.orden = (select MAX(orden) from NivelZona where idCliente = C.idCliente) then ISNULL(Z.latitud,'')  
   else ''  
  END latitud,  
  case   
   when NZ.orden = (select MAX(orden) from NivelZona where idCliente = C.idCliente) then ISNULL(Z.longitud,'')  
   else ''  
  END longitud,  
  Z.idZona,  
  case   
   when Z.idPadre =0 then   
    9990 + C.idCliente  
   else Z.idPadre   
  end idPadre,  
  NZ.orden,  
  (select MAX(orden) from NivelZona where idCliente = C.idCliente) maxOrden  
 from Cliente C  
 inner join NivelZona NZ on NZ.idCliente = C.idCliente  
 inner join Zona Z on NZ.idNivelZona=Z.idNivelZona  
   
END
go

