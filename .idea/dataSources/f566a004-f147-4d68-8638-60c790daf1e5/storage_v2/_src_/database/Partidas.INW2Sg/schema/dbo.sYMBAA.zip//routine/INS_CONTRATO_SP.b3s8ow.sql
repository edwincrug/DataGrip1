create procedure [dbo].[INS_CONTRATO_SP] (
	@idLicitacion numeric(18,0),
	@numero nvarchar(50),
	@descripcion nvarchar(500),
	@fechaInicio datetime,
	@fechaFin datetime,
	@jsonUnidades nvarchar(max),
	@jsonProveedores nvarchar(max),
	@idUsuario numeric(18,0)
)
as
begin

	INSERT INTO dbo.Contrato
		( idLicitacion, numero, descripcion, fechaInicio, fechaFin, estatus)
	VALUES 
		( @idLicitacion,@numero, @descripcion, @fechaInicio, @fechaFin, 1);

	DECLARE @idContrato as numeric(18,0)
	SET @idContrato = @@IDENTITY
	
	--Inserto Unidades
	DECLARE @idUnidad AS numeric(18,0)
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 

	SELECT Object_ID FROM parseJSON(@jsonUnidades)
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idUnidad = REPLACE(StringValue,'"','')  FROM parseJSON(@jsonUnidades)
			WHERE 
			parent_ID = @parent
			AND NAME = 'idUnidad'
			AND Object_ID IS NULL
	
			
		--Inserto Unidad
		INSERT INTO dbo.ContratoUnidad
			( idContrato, idUnidad)
		VALUES 
			( @idContrato, @idUnidad);
	
	FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	
	
	--Inserto Proveedor
	DECLARE @idProveedor AS numeric(18,0)
	DECLARE @parent2 AS INT
	DECLARE _cursor2 CURSOR FOR 

	SELECT Object_ID FROM parseJSON(@jsonProveedores)
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor2 
	FETCH NEXT FROM _cursor2 INTO @parent2
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idProveedor = REPLACE(StringValue,'"','')  FROM parseJSON(@jsonProveedores)
			WHERE 
			parent_ID = @parent2
			AND NAME = 'idProveedor'
			AND Object_ID IS NULL
	
			
		INSERT INTO dbo.ContratoProveedor
			(idContrato, idProveedor)
		VALUES 
			( @idContrato, @idProveedor);
	
	FETCH NEXT FROM _cursor2 INTO @parent2
	END 
	CLOSE _cursor2 
	DEALLOCATE _cursor2
	
	SELECT @idContrato as idContrato
	
end
go

