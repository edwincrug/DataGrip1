CREATE procedure [dbo].[INS_LICITACION_SP] (
	@idCliente numeric(18,0),
	@idClienteFinal numeric(18,0),
	@idEmpresa numeric(18,0),
	@folio nvarchar(50),
	@nombre nvarchar(200),
	@descripcion nvarchar(500),
	@fechaInicio datetime
)
as
begin

	INSERT INTO dbo.Licitacion
		( idCliente, idClienteFinal, idEmpresa, folio, nombre, descripcion, fechaInicio, estatus)
	VALUES 
		( @idCliente, @idClienteFinal, @idEmpresa, @folio, @nombre, @descripcion, @fechaInicio, 1);
		
	SELECT @@IDENTITY

end
go

