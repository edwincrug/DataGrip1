CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		Pro.idProveedorEncabezado,
		pro.idProveedor,
		isnull(nombreComercial, '') nombreComercial,
		razonSocial,
		RFC,
		convert(nvarchar(10),fechaInicio,103) as fechaInicio,
		pro.idCategoria,
		cat.categoria,
		dbo.SEL_PROVEEDOR_ESPECIALIDAD_FN(pro.idProveedor) especialidades,
		dbo.SEL_PROVEEDOR_TIPO_UNIDAD_FN(pro.idProveedor) tipoUnidad,
		pro.idProveedorClasificacion,
		isnull(pc.clasificacion, 'Sin Clasificacion') clasificacion,
		pro.idProveedorSubClasificacion,
		isnull(direccion, '') direccion,
		isnull(telefono, '') telefono,
		latitud,
		longitud,
		poligono,
		pro.estatus,
		isnull(pro.contacto, '') contacto,
		(select top 1 archivo from ProveedorDocumento pd where idProveedor = pro.idproveedor and pd.idDocumento = 14 ) fotoFachada,
		isnull(pro.mail, '') mail,
		usu.usuario,
		usu.password
	FROM
		dbo.Proveedor pro
		LEFT JOIN Categoria cat ON cat.idCategoria = pro.idCategoria
		LEFT JOIN UsuarioProveedor cpr ON cpr.idProveedor = pro.idProveedor
		LEFT JOIN Usuario usu ON usu.idUsuario = cpr.idUsuario
		LEFT JOIN ProveedorClasificacion pc on pc.idProveedorClasificacion = pro.idProveedorClasificacion
		
	WHERE 
		pro.estatus = 1
		
		

end
go

