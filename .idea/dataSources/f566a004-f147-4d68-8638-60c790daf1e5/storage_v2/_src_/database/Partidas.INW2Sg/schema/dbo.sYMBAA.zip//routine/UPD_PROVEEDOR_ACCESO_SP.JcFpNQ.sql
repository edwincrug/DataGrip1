CREATE PROCEDURE [dbo].[UPD_PROVEEDOR_ACCESO_SP] (
	@idProveedor numeric(18,0),
	@nombre nvarchar(200),
	@mail nvarchar(200),
	@usuario nvarchar(50),
	@password nvarchar(50)
)
as
begin

	declare @idUsuario numeric(18,0)

	if EXISTS(select 1 from UsuarioProveedor WHERE idProveedor = @idProveedor ) begin	
		
		select @idUsuario = idUsuario FROM UsuarioProveedor where idProveedor = @idProveedor
		
		UPDATE Usuario 
		SET
			usuario = @usuario,
			password = @password,
			nombre = @nombre
		WHERE idUsuario = @idUsuario
		
	end
	else begin
			
		INSERT INTO Partidas.dbo.Usuario
			(nombre, usuario, password, idPerfil, estatus)
		VALUES 
			(@nombre, @usuario, @password,2 ,1 );	
			
		SELECT @idUsuario = @@IDENTITY
	
		INSERT INTO Partidas.dbo.UsuarioProveedor
			(idUsuario, idProveedor)
		VALUES 
			(@idUsuario , @idProveedor);
	
	end
	
		UPDATE ProveedorEncabezado SET
			contacto = @nombre,
			mail = @mail
		WHERE 
			idProveedorEncabezado = @idProveedor
	
	declare @body nvarchar(max)
	set @body = '<div style="font-weight:bold; font-size:16px;"> Estimado Proveedor:  </div><br><br>'
	set @body = @body + '<div style=" font-size:14px;"> A continuación encontrará el acceso a nuestro portal de cotización de partidas  </div> <br><br>'
	set @body = @body + '<div style="font-size:13px;"> <b> URL de acceso: </b>  http://35.165.2.64:4200 </div> <br>'
	set @body = @body + '<div style="font-size:13px;"> <b> Usuario: </b> ' + @usuario + '  </div> <br>'
	set @body = @body + '<div style="font-size:13px;"> <b> Password: </b> ' + @password + '  </div> <br><br><br>'
	set @body = @body + '<div style="font-size:14px;"> Dentro de la sección "Cotizar" Encontrará las unidades/partidas para las que requerimos su cotización.  </div><br>'
	set @body = @body + '<div style="font-size:14px;"> Para dudas o comentarios favor de ponerse en contacto con jennifer.paramo@aexpress.com.mx  </div><br><br><br>'
	set @body = @body + '<div style="font-size:14px;"> Saludos.  </div>'
	
	--Enviamos el correo electrónico
	exec msdb.dbo.sp_send_dbmail 
	@profile_name = 'SMTPCallCenterTalleres',
	@recipients = @mail, 
	@subject = 'Acceso a Portal de Proveedores',
	@body_format = 'HTML',
	@body = @body
	  
	SELECT @idProveedor

end
go

