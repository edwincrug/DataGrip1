CREATE procedure [dbo].[SEL_COTIZACION_SP] (
	@idUsuario numeric(18,0),
	@idUnidad numeric(18,0)
)
as
begin

	SELECT
		pco.idProveedorCotizacion,
		pco.idProveedor,
		pro.nombreComercial + '/' + pro.razonSocial as razonSocial,
		pro.idCategoria,
		cat.categoria,
		dbo.SEL_PROVEEDOR_ESPECIALIDAD_FN(pro.idProveedor) especialidades,
		dbo.SEL_PROVEEDOR_TIPO_UNIDAD_FN(pro.idProveedor) tipoUnidad,
		pco.idUnidad,
		convert(nvarchar(19),pco.fecha,103) as fechaTXT,
		pco.fecha,
		pco.idCotizacionEstatus,
		ces.estatus
	FROM
		dbo.ProveedorCotizacion pco
		LEFT JOIN dbo.CotizacionEstatus ces ON ces.idCotizacionEstatus = pco.idCotizacionEstatus
		LEFT JOIN Proveedor pro ON pro.idProveedor = pco.idProveedor
		LEFT JOIN Categoria cat ON cat.idCategoria = pro.idCategoria
		LEFT JOIN Unidad uni ON uni.idUnidad = pco.idUnidad
	WHERE 
		pco.idUnidad = 	@idUnidad


end
go

