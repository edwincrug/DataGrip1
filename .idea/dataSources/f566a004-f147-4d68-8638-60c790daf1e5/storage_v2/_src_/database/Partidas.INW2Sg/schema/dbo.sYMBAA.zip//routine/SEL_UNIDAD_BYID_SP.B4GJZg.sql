create procedure [dbo].[SEL_UNIDAD_BYID_SP] (
	@idUnidad numeric(18,0)
)
as
begin

	SELECT
		idUnidad,
		tip.idTipoUnidad,
		tip.tipo as tipoUnidad,
		uni.anio,
		uni.version,
		sma.nombre as subMarca,
		sma.idSubMarca,
		mar.nombre as marca,
		--'http://localhost:4500/uploads/' + foto as fotoURL,
		foto as foto,
		uni.estatus
	FROM
		dbo.Unidad uni
		LEFT JOIN TipoUnidad tip ON tip.idTipoUnidad = uni.idTipoUnidad
		LEFT JOIN SubMarca sma ON sma.idSubmarca = uni.idSubMarca
		LEFT JOIN Marca mar ON mar.idMarca = sma.idMarca
	WHERE 
		uni.estatus= 1
		AND idUnidad = @idUnidad

end
go

