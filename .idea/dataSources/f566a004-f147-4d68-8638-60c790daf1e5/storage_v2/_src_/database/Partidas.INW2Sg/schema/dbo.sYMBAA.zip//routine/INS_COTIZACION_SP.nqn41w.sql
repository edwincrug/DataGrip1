create procedure [dbo].[INS_COTIZACION_SP] (
	@idUsuario numeric(18,0),
	@idUnidad numeric(18,0),
	@json nvarchar(max)
)
as
begin


	DECLARE @Proveedor AS numeric(18,0)
	
	--Insertar proveedores
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 

	SELECT Object_ID FROM parseJSON(@json)
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @Proveedor = REPLACE(StringValue,'"','')  FROM parseJSON(@json)
			WHERE 
			parent_ID = @parent
			AND NAME = 'idProveedor'
			AND Object_ID IS NULL
	
		INSERT INTO dbo.ProveedorCotizacion
			( idProveedor, idUnidad, fecha, idCotizacionEstatus)
		VALUES 
			( @Proveedor , @idUnidad, GETDATE(), 1);
	
	FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	
	SELECT @idUnidad as idUnidad
	
	
	

end
go

