
CREATE PROCEDURE [dbo].[SEL_UNIDAD_OPERATIVA_SP_ASE]
	@idZona as numeric(18,0)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT 
		nombre as label,
		idZona as value
	FROM
		Zona
	WHERE 
		idNivelZona = 2
		AND idPadre = @idZona

END
go

