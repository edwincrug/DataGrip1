CREATE procedure [dbo].[SEL_ZONA_SP] (
	@idUsuario numeric(18,0),
	@idCliente numeric(18,0)
)
as
begin

	select 
		idZona,
		nzo.orden as nivel,
		idPadre,
		nombre,
		zon.idNivelZona,
		zon.referencia
	from Zona zon
	LEFT JOIN NivelZona nzo ON nzo.idNivelZona = zon.idNivelZona 
	WHERE nzo.idCliente = @idCliente
	AND zon.estatus=1
	order by orden

end
go

