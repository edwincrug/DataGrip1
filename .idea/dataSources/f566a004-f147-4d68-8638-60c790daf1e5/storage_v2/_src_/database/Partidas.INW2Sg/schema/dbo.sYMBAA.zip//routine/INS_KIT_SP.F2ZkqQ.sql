CREATE PROCEDURE [dbo].[INS_KIT_SP] (
	@idUnidad numeric(18,0),
	@partida nvarchar(50),
	@descripcion nvarchar(500),
	@instructivo nvarchar(50),
	@json nvarchar(max)
)
as
begin

	INSERT INTO Partidas.dbo.Kit
		(idUnidad, partida, descripcion, instructivo, estatus)
	VALUES 
		(@idUnidad, @partida, @descripcion, REPLACE(@instructivo,'"','') , 1);
		
	DECLARE @idKit as numeric(18,0)
	DECLARE @idPartida as numeric(18,0)
	DECLARE @cantidad as decimal(18,2)
	SELECT @idKit = @@IDENTITY
	
	--Insertar partidas
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 

	SELECT Object_ID FROM parseJSON(@json)
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idPartida = REPLACE(StringValue,'"','')  FROM parseJSON(@json)
			WHERE 
			parent_ID = @parent
			AND NAME = 'idPartida'
			AND Object_ID IS NULL

	SELECT @cantidad = REPLACE(StringValue,'"','')  FROM parseJSON(@json)
			WHERE 
			parent_ID = @parent
			AND NAME = 'cantidad'
			AND Object_ID IS NULL
	
		INSERT INTO Partidas.dbo.KitPartida
			( idKit, idPartida, cantidad)
		VALUES 
			( @idKit , @idPartida, @cantidad);
	
	FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	
	SELECT @idKit as idKit

end
go

