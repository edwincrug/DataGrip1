CREATE PROCEDURE [dbo].[INS_SUBMARCA_SP] (
	@idMarca numeric(18,0),
	@subMarca nvarchar(200)
)
as
begin

	INSERT INTO  dbo.SubMarca
		( idMarca, nombre, estatus)
	VALUES 
		(@idMarca, @subMarca, 1)
		
		
	SELECT @@IDENTITY


end
go

