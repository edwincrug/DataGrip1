CREATE FUNCTION [dbo].SEL_UNIDAD_CADENA_FN   
( 
	@idUnidad numeric(18,0)
)  
RETURNS nvarchar(500)  
    BEGIN   
        DECLARE @cadena nvarchar(500)  
				
						SELECT
						 @cadena = cast(idUnidad as nvarchar(10)) + '/' +
						 tco.tipoCombustible + '/' + tip.tipo + '/'  + mar.nombre + '/' + sma.nombre  + '/' + cil.cilindros 
					FROM
						dbo.Unidad uni
						LEFT JOIN TipoUnidad tip ON tip.idTipoUnidad = uni.idTipoUnidad
						LEFT JOIN TipoCombustible tco ON tco.idTipoCombustible = uni.idTipoCombustible
						LEFT JOIN Cilindros cil ON cil.idCilindros = uni.idCilindros
						LEFT JOIN SubMarca sma ON sma.idSubmarca = uni.idSubMarca
						LEFT JOIN Marca mar ON mar.idMarca = sma.idMarca
					WHERE 
						uni.idUnidad = @idUnidad
						
        RETURN @cadena
    END
go

