
CREATE procedure [dbo].[DEL_PROVEEDOR_SUCURSAL_DOCUMENTO_SP] (
	@idProveedorDocumento numeric(18,0)
	
)
as
begin

	DELETE 
		FROM ProveedorDocumento 
	where idProveedorDocumento = @idProveedorDocumento
           
    SELECT @idProveedorDocumento

end
go

