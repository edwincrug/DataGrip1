--SEL_CONTRATO_PARTIDAS_SP 1,67,68
CREATE procedure [dbo].[SEL_CONTRATO_PARTIDAS_SP] (
	@idUsuario numeric(18,0),
	@idUnidad numeric(18,0),
	@idContrato numeric(18,0)
)
as
begin

	DECLARE @SQL as NVARCHAR(max)
	SET @SQL = ''
	SET @SQL += 'SELECT  
		esp.idEspecialidad,
		esp.especialidad,
		cl1.idPartidaClasificacion,
		cl1.clasificacion,
		cl2.idPartidaSubClasificacion,
		par.idTipoPartida,
		ISNULL(TP.tipoPartida,'''') tipoPartida,
		cl2.subClasificacion,
		partida,
		marca,
		REPLACE(REPLACE(noParte,'','',''''),'':'','''') noParte,
		ASEPROT.dbo.[fnReemplazaASCII_Partidas] (REPLACE(REPLACE(REPLACE(REPLACE(par.descripcion,'','',''''),'':'',''''),''""'',''"''),''"'',''""'')) descripcion,
		par.foto,
		par.instructivo, 
		ISNULL(cpa.venta,0.00) as venta, 
		ISNULL(cpa.precio1,0.00) as precio1,
		ISNULL(cpa.precio2,0.00) as precio2,
		ISNULL(cpa.precio3,0.00) as precio3,
		ISNULL(cpa.precio4,0.00) as precio4,
		ISNULL(cpa.precio5,0.00) as precio5,
		ISNULL(cpa.precio6,0.00) as precio6,
		ISNULL(cpa.precio7,0.00) as precio7,
		ISNULL(cpa.precioMano,0.00) as precioMano,
		ISNULL(cpa.precioRefaccion,0.00) as precioRefaccion,
		ISNULL(cpa.precioLubricante,0.00) as precioLubricante,
		ISNULL(cpa.tiempo,''00:00:00'') as tiempo,
		ISNULL(cpa.precioLlanta, 0.00) as precioLlanta,
		ISNULL(cpa.precioHojalateria, 0.00) as precioHojalateria,

		'
	
	/*	
	DECLARE @idProveedor AS numeric(18,0)
	--Obtengo los proveedores
	DECLARE _cursor CURSOR FOR 
	SELECT
		pro.idProveedor
	FROM
		dbo.ContratoProveedor cpr
		LEFT JOIN dbo.Proveedor pro ON pro.idProveedor = cpr.idProveedor
	WHERE 
		cpr.idContrato = @idContrato
		
	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @idProveedor
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SET @SQL +=' (SELECT ISNULL(ppaw.costo,0.00) FROM  dbo.ProveedorCotizacion pcow 
				LEFT JOIN dbo.ProveedorPartida ppaw ON ppaw.idProveedorCotizacion = pcow.idProveedorCotizacion  
				WHERE (ppaw.idPartida = par.idPartida OR ppaw.idPartida is null) and pcow.idProveedor = ' + CAST(@idProveedor AS NVARCHAR(10)) + ' ) as C' + CAST(@idProveedor AS NVARCHAR(10)) + ' ,'
	
	FETCH NEXT FROM _cursor INTO @idProveedor
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	*/
	/*
	--ANALISIS DE COSTOS
	SET @SQL += ' 
		(select  ISNULL(min(PP.costo),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costo>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) minimo, '
		
	SET @SQL += ' 
		(select  ISNULL(MAX(PP.costo),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costo>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) maximo, '

	SET @SQL += ' 
		(select  ISNULL((SUM(PP.costo) / COUNT(*)),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costo>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) promedio, '
     */


	 set @SQL += '0 minimo, 0 maximo, 0 promedio, '
	 set @SQL += '0 minimoPieza, 0 maximoPieza, 0 promedioPieza, 0 minimoMano, 0 maximoMano, 0 promedioMano, 0 minimoTiempo, 0 maximoTiempo, 0 promedioTiempo,'
	 /*
	--ANALISIS DE COSTOS DESGLOZADOS
	--PIEZA
	SET @SQL += ' 
		(select  ISNULL(min(PP.costoPieza),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costoPieza>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) minimoPieza, '  
	
	SET @SQL += ' 
		(select  ISNULL(max(PP.costoPieza),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costoPieza>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) maximoPieza, '
	SET @SQL += ' 
		(select  ISNULL((SUM(PP.costoPieza) / COUNT(*)),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costoPieza>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) promedioPieza, '
	--MANO
	SET @SQL += ' 
		(select  ISNULL(min(PP.costoMano),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costoMano>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) minimoMano, '  
	
	SET @SQL += ' 
		(select  ISNULL(max(PP.costoMano),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costoMano>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) maximoMano, '
	SET @SQL += ' 
		(select  ISNULL((SUM(PP.costoMano) / COUNT(*)),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.costoMano>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) promedioMano, '

	--TIEMPO
	SET @SQL += ' 
		(select  ISNULL(min(PP.tiempo),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.tiempo > 0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) minimoTiempo, '

	SET @SQL += ' 
		(select  ISNULL(max(PP.tiempo),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.tiempo > 0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) maximoTiempo, '

	SET @SQL += ' 
		(select  ISNULL((SUM(PP.tiempo) / COUNT(*)),0)
			from ProveedorCotizacion PC	
			inner join ProveedorPartida PP on PC.idProveedorCotizacion=PP.idProveedorCotizacion 
			where 
				PP.idPartida = Par.idPartida and 
				PP.tiempo>0 and
				PC.idProveedor in (select idProveedor from ContratoProveedor WHERE idContrato = ' + CONVERT(NVARCHAR(10),@idContrato) + '
		)) promedioTiempo, '
	*/
	/*
	SET @SQL += ' (SELECT MIN(ISNULL(ppaw.costo,0.00)) FROM  dbo.ProveedorCotizacion pcow 
					LEFT JOIN dbo.ProveedorPartida ppaw ON ppaw.idProveedorCotizacion = pcow.idProveedorCotizacion  
					WHERE (ppaw.idPartida = par.idPartida OR ppaw.idPartida is null)  
					AND pcow.idProveedor in(
						select idProveedor from ContratoProveedor WHERE idContrato = ' + CAST( @idContrato as NVARCHAR(10)) + '
					)
					AND ISNULL(ppaw.costo,0.00) > 0 ) as minimo , '
		
	SET @SQL += ' (SELECT MAX(ISNULL(ppaw.costo,0.00)) FROM  dbo.ProveedorCotizacion pcow 
					LEFT JOIN dbo.ProveedorPartida ppaw ON ppaw.idProveedorCotizacion = pcow.idProveedorCotizacion  
					WHERE (ppaw.idPartida = par.idPartida OR ppaw.idPartida is null)  
					AND pcow.idProveedor in(
						select idProveedor from ContratoProveedor WHERE idContrato = ' + CAST( @idContrato as NVARCHAR(10)) + '
					)
					AND ISNULL(ppaw.costo,0.00) > 0 ) as maximo , '
					
	SET @SQL += ' (SELECT (SUM(ISNULL(ppaw.costo,0.00)) / 
		 				( SELECT COUNT(1)
					  FROM  dbo.ProveedorCotizacion pcow 
								LEFT JOIN dbo.ProveedorPartida ppaw ON ppaw.idProveedorCotizacion = pcow.idProveedorCotizacion  
								WHERE (ppaw.idPartida = par.idPartida OR ppaw.idPartida is null) 
								AND pcow.idProveedor in(
									select idProveedor from ContratoProveedor WHERE idContrato = ' + CAST( @idContrato as NVARCHAR(10)) + '
								)
								AND ISNULL(ppaw.costo,0.00) > 0 ))
					  FROM  dbo.ProveedorCotizacion pcow 
								LEFT JOIN dbo.ProveedorPartida ppaw ON ppaw.idProveedorCotizacion = pcow.idProveedorCotizacion  
								WHERE (ppaw.idPartida = par.idPartida OR ppaw.idPartida is null) 
								AND pcow.idProveedor in(
									select idProveedor from ContratoProveedor WHERE idContrato = ' + CAST( @idContrato as NVARCHAR(10)) + '
								)
								AND ISNULL(ppaw.costo,0.00) > 0 ) as promedio, '
								*/
	SET @SQL +=' par.idPartida  FROM
		dbo.Partida par
		LEFT JOIN dbo.Unidad uni ON uni.idUnidad = par.idUnidad
		LEFT JOIN dbo.Especialidad esp ON esp.idEspecialidad = par.idEspecialidad
		LEFT JOIN PartidaClasificacion cl1 ON cl1.idPartidaClasificacion = par.idPartidaClasificacion
		LEFT JOIN PartidaSubClasificacion cl2 ON cl2.idPartidaSubClasificacion = par.idPartidaSubClasificacion
		LEFT JOIN ContratoUnidad cun ON cun.idUnidad = uni.idUnidad 
		LEFT JOIN ContratoPartida cpa ON cpa.idContratoUnidad = cun.idContratoUnidad and cpa.idPartida = par.idPartida
		LEFT JOIN TipoPartida TP on par.idTipoPartida = TP.idTipoPartida
	 WHERE 
		uni.idUnidad = ' +  CAST(@idUnidad as NVARCHAR(10)) + '
		AND cun.idContrato = ' + CAST( @idContrato  as NVARCHAR(10)) + '
		AND par.estatus = 1  ORDER BY par.idPartida'
		
	print @SQL
	EXEC sp_executesql @SQL

	

end
go

