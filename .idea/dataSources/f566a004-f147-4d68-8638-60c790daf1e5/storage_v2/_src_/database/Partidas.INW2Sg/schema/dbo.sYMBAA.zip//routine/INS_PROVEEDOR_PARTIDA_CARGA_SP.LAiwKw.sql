CREATE procedure [dbo].[INS_PROVEEDOR_PARTIDA_CARGA_SP] (
	@idProveedor numeric(18,0),
	@idUnidad numeric(18,0),
	@idUsuario numeric(18,0),
	@idPartida numeric(18,0),
	@costoPieza decimal(18,2),
	@costoMano decimal(18,2),
	@costo decimal(18,2)
)
as
begin

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; -- turn it on

DECLARE @idProveedorCotizacion INT,@idProveedorPartida INT,@existePartida INT

SET @idProveedorCotizacion = (SELECT TOP 1 idProveedorCotizacion FROM ProveedorCotizacion WHERE idProveedor=@idProveedor and idUnidad=@idUnidad)
SET @idProveedorPartida = (SELECT idProveedorPartida FROM dbo.ProveedorPartida WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idPartida = @idPartida)
SET @existePartida = (SELECT COUNT(idPartida) FROM Partida WHERE idPartida=@idPartida AND idUnidad=@idUnidad)

IF @idProveedorCotizacion IS NOT NULL AND @existePartida>0
BEGIN
	IF @idProveedorPartida IS NOT NULL
	BEGIN
		BEGIN TRY  
		UPDATE PP 
		SET	costoPieza = @costoPieza,
		costoMano = @costoMano,
		costo = (@costoPieza + @costoMano),
		fecha = GETDATE(),
		idUsuario = @idUsuario,
		idPartidaEstatus = 4
		FROM dbo.ProveedorPartida PP WITH (NOLOCK)
		WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idPartida = @idPartida

		INSERT INTO [dbo].[ProveedorPartidaBitacora]
		SELECT idProveedorPartida,idProveedorCotizacion,@idPartida,@costoPieza,@costoMano,@costo,0,idPartidaEstatus,GETDATE(),@idUsuario,'ACTUALIZÓ' 
		FROM ProveedorPartida
		WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idPartida = @idPartida

		SELECT @idProveedorPartida AS IdProveedorPartida
		END TRY  
		BEGIN CATCH  
		EXECUTE [dbo].[INS_PROVEEDOR_PARTIDA_CARGA_SP] @idProveedor ,@idUnidad ,@idUsuario,@idPartida,@costoPieza,@costoMano,@costo
		END CATCH;

	END
	ELSE 
	BEGIN
		INSERT INTO dbo.ProveedorPartida
			(idProveedorCotizacion, idPartida, costoPieza, costoMano, costo, tiempo, fecha, idUsuario, idPartidaEstatus)
		VALUES 
			(@idProveedorCotizacion, @idPartida, @costoPieza,@costoMano, @costo, 0, GETDATE(), @idUsuario, 4)

		SET @idProveedorPartida = (SELECT @@IDENTITY)

		INSERT INTO [dbo].[ProveedorPartidaBitacora]
		SELECT @idProveedorPartida,idProveedorCotizacion,@idPartida,@costoPieza,@costoMano,@costo,0,idPartidaEstatus,GETDATE(),@idUsuario,'INSERTÓ' FROM ProveedorPartida
		WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idPartida = @idPartida

		SELECT @idProveedorPartida AS IdProveedorPartida
		
	END
END
ELSE
BEGIN
		INSERT INTO [dbo].[ProveedorPartidaBitacora]
		SELECT -100,-100,@idPartida,@costoPieza,@costoMano,@costo,0,2,GETDATE(),@idUsuario,'SIN ACCIÓN' 
		SELECT -100 AS IdProveedorPartida

END

SET TRANSACTION ISOLATION LEVEL READ COMMITTED; -- turn it off

end
--GO
--BEGIN TRAN

--EXEC [dbo].[INS_PROVEEDOR_PARTIDA_CARGA_SP] 163,143,56,2915338,$876.85,$310.65,$1187.50
--EXEC [dbo].[INS_PROVEEDOR_PARTIDA_CARGA_SP] 259,73,56,85382,540.35,714.13,1254.48
--
--EXEC [dbo].[INS_PROVEEDOR_PARTIDA_CARGA_SP] 259,73,56,85382,540.35,714.13,1254.48

--SELECT * FROM ProveedorPartida
--where  idPartida=85382

----SELECT * FROM [dbo].[ProveedorCotizacionBitacora]
--SELECT * FROM [dbo].[ProveedorPartidaBitacora]

--ROLLBACK TRAN
go

