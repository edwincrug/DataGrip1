CREATE PROCEDURE [dbo].[SEL_NIVEL_ZONA_SP] (
	@idUsuario numeric(18,0),
	@idCliente numeric(18,0)
)
as
begin

	SELECT
		idNivelZona,
		idCliente,
		etiqueta,
		orden
	FROM
		dbo.NivelZona
	WHERE
		idCliente = @idCliente
	ORDER BY orden asc

end
go

