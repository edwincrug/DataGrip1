CREATE PROCEDURE [dbo].[SEL_PROVEEDOR_BYID_SP] (
	@idProveedor numeric(18,0)
)
as
begin

	SELECT				
		pro.[idProveedor]
	      ,[nombreComercial]
	      ,[razonSocial]
	      ,[RFC]
	      ,[contacto]
	      ,[telefono]
	      ,[mail]
	      ,fechaInicio
	      ,cat.[idCategoria]
		, cat.categoria
		,dbo.SEL_PROVEEDOR_ESPECIALIDAD_FN(pro.idProveedor) especialidades
		,dbo.SEL_PROVEEDOR_TIPO_UNIDAD_FN(pro.idProveedor) tipoUnidad
	      ,pro.[idProveedorClasificacion]
		  ,pc.clasificacion proveedorClasificacion
	      ,[idProveedorSubClasificacion]
	      ,[direccion]
	      ,[latitud]
	      ,[longitud]
	      ,[poligono]
	      ,[idBPRO]
	      ,pro.[estatus]
		,[tipoPersona] 
		,[pais] 
		,[estado] 
		,[ciudad]
		,[delegacion] 
		,[colonia] 
		,[calle]
		,[numInt] 
		,[numExt] 
		,[cp] 
		,[lada] 

	FROM
		dbo.Proveedor pro
		LEFT JOIN Categoria cat ON cat.idCategoria = pro.idCategoria
		LEFT JOIN ProveedorDatosFiscales pdf ON pdf.idProveedor = pro.idProveedor
		LEFT JOIN ProveedorClasificacion pc on pc.idProveedorClasificacion = pro.idProveedorClasificacion
	WHERE 
		pro.estatus = 1
		AND pro.idProveedor = @idProveedor
		
		

end
go

