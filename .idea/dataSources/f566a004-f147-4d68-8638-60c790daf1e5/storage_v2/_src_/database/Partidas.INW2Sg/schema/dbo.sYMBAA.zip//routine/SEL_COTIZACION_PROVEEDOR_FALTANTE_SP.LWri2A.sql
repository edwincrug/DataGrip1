CREATE PROCEDURE [dbo].[SEL_COTIZACION_PROVEEDOR_FALTANTE_SP] (
	@idUsuario numeric(18,0),
	@idUnidad numeric(18,0)
)
as
begin

	select 
	    idProveedor,
		razonSocial,
		nombreComercial,
		RFC 
	FROM 
		Proveedor pro
	WHERE
		pro.estatus = 1
		AND pro.idProveedor not in(
		
			select idProveedor FROM dbo.ProveedorCotizacion WHERE idUnidad = @idUnidad
		)

end
go

