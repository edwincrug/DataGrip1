CREATE PROCEDURE [dbo].[SEL_MARCA_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	
	SELECT
		idMarca as value,
		nombre as label
	FROM
		dbo.Marca
	WHERE estatus = 1

end
go

