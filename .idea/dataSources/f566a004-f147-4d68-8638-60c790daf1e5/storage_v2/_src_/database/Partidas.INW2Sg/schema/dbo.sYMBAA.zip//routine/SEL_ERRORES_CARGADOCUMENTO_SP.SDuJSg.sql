
-- =============================================
-- Author:		<Armando Garcia>
-- Create date: <08/09/2020>
-- Description:	<Obtiene la lista de documentos carga masiva>
--[dbo].[SEL_ERRORES_CARGADOCUMENTO_SP] 3,2
-- =============================================
CREATE PROCEDURE [dbo].[SEL_ERRORES_CARGADOCUMENTO_SP]
	@idCargaDocumento numeric(18,0),
	@accion INT
AS
BEGIN

	SET NOCOUNT ON;

	IF @accion = 1
	BEGIN
		SELECT 
		idCargaDocumento,fecha,
		CASE 
		WHEN idError IN (7306,7314) THEN 'POSIBLEMENTE EL ARCHIVO CARGADO NO CUENTE CON LAS HOJAS REQUERIDAS'
		ELSE error END
		AS error
		FROM CargaDocumentoERROR
		   WHERE idCargaDocumento=@idCargaDocumento
	END
	IF @accion = 2
	BEGIN
		SELECT  DISTINCT
		PPBM.idCargaDocumento
		,(SELECT MIN(fecha) FROM ProveedorPartidaBitacoraMasiva PPBM2
		WHERE PPBM2.idProveedor=PPBM.idProveedor AND PPBM2.idUnidad=PPBM.idUnidad
		) as fecha
		,error = PPBM.comentario + ' //' + ' IdProveedor: '+CAST(PPBM.[idProveedor] AS VARCHAR(MAX)) + ' IdUnidad: '+CAST(PPBM.[idUnidad] AS VARCHAR(MAX))
		FROM ProveedorPartidaBitacoraMasiva PPBM
		 WHERE PPBM.idCargaDocumento=@idCargaDocumento
		 AND PPBM.comentario ='NO EXISTE RELACIÓN PROVEEDOR - UNIDAD'
		 UNION ALL
		 SELECT  DISTINCT
		PPBM.idCargaDocumento
		,(SELECT MIN(fecha) FROM ProveedorPartidaBitacoraMasiva PPBM2
		WHERE PPBM2.idUnidad=PPBM.idUnidad AND PPBM2.idPartida=PPBM.idPartida
		) as fecha
		,error = PPBM.comentario + ' //' + ' IdUnidad: '+CAST(PPBM.[idUnidad] AS VARCHAR(MAX)) + ' idPartida: '+CAST(PPBM.[idPartida] AS VARCHAR(MAX))
		FROM ProveedorPartidaBitacoraMasiva PPBM
		 WHERE PPBM.idCargaDocumento=@idCargaDocumento
		 AND PPBM.comentario ='NO EXISTE RELACIÓN UNIDAD - PARTIDA'
	END
END
go

