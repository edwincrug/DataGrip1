CREATE procedure [dbo].[SEL_COTIZACION_KITS_APROBAR_SP] (
	@idUsuario numeric(18,0),
	@idProveedorCotizacion numeric(18,0)
)
as
begin

	DECLARE @SQL as NVARCHAR(max)
	SET @SQL = ''
	SET @SQL += 'SELECT
		kit.partida,
		kit.descripcion,
		kit.instructivo,
		ISNULL(pki.costoPieza,0.00) as costoPieza,  
		ISNULL(pki.costoMano,0.00) as costoMano,  
		ISNULL(pki.costo,0.00) as costo,  '
		
	DECLARE @idProveedor AS numeric(18,0)
	--Obtengo los proveedores
	DECLARE _cursor CURSOR FOR 
	SELECT
		pro.idProveedor
	FROM
		dbo.ProveedorCotizacion pco
		LEFT JOIN dbo.Proveedor pro ON pro.idProveedor = pco.idProveedor
	WHERE 
		pco.idUnidad in(
		SELECT idUnidad FROM dbo.ProveedorCotizacion pcox 
		WHERE pcox.idProveedorCotizacion = @idProveedorCotizacion 
	)
	AND pco.idProveedor NOT IN (SELECT pcoy.idProveedor 
								FROM  dbo.ProveedorCotizacion pcoy 
								WHERE pcoy.idProveedorCotizacion = @idProveedorCotizacion  )
	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @idProveedor
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SET @SQL += ' (SELECT ISNULL(pkiw.costo,0.00) FROM  dbo.ProveedorCotizacion pcow 
				LEFT JOIN dbo.ProveedorKit pkiw ON pkiw.idProveedorCotizacion = pcow.idProveedorCotizacion  
				WHERE (pkiw.idKit = kit.idKit OR pkiw.idKit is null) 
				and pcow.idProveedor = ' + CAST(@idProveedor AS NVARCHAR(10)) + ' 
				and pcow.idUnidad = uni.idUnidad ) as C' + CAST(@idProveedor AS NVARCHAR(10)) + ' ,'
	
	FETCH NEXT FROM _cursor INTO @idProveedor
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
					
	SET @SQL += '(SELECT MIN(ISNULL(pkiw.costo,0.00)) FROM  dbo.ProveedorCotizacion pcow 
				LEFT JOIN dbo.ProveedorKit pkiw ON pkiw.idProveedorCotizacion = pcow.idProveedorCotizacion   
					WHERE (pkiw.idKit = kit.idKit OR pkiw.idKit is null)
					AND pcow.idUnidad = uni.idUnidad 
					AND ISNULL(pkiw.costo,0.00) > 0 ) as minimo,'
					
	SET @SQL += ' (SELECT MAX(ISNULL(pkiw.costo,0.00)) FROM  dbo.ProveedorCotizacion pcow 
				LEFT JOIN dbo.ProveedorKit pkiw ON pkiw.idProveedorCotizacion = pcow.idProveedorCotizacion   
					WHERE (pkiw.idKit = kit.idKit OR pkiw.idKit is null)
					AND pcow.idUnidad = uni.idUnidad 
					AND ISNULL(pkiw.costo,0.00) > 0 ) as maximo, '
					
	SET @SQL += ' (SELECT (SUM(ISNULL(pkiw.costo,0.00)) /
				(SELECT COUNT(1) 
				FROM  dbo.ProveedorCotizacion pcow 
				LEFT JOIN dbo.ProveedorKit pkiw ON pkiw.idProveedorCotizacion = pcow.idProveedorCotizacion   
					WHERE (pkiw.idKit = kit.idKit OR pkiw.idKit is null)
					AND pcow.idUnidad = uni.idUnidad 
					AND ISNULL(pkiw.costo,0.00) > 0 ))
			FROM  dbo.ProveedorCotizacion pcow 
				LEFT JOIN dbo.ProveedorKit pkiw ON pkiw.idProveedorCotizacion = pcow.idProveedorCotizacion   
					WHERE (pkiw.idKit = kit.idKit OR pkiw.idKit is null)
					AND pcow.idUnidad = uni.idUnidad 
					AND ISNULL(pkiw.costo,0.00) > 0 ) as promedio,	'
		
	SET @SQL +='kit.idKit,
			pes.idPartidaEstatus,
			pes.estatus as partidaEstatus
	FROM
		dbo.Kit kit
		LEFT JOIN dbo.Unidad uni ON uni.idUnidad = kit.idUnidad
		LEFT JOIN ProveedorCotizacion pco ON pco.idUnidad = uni.idUnidad
		LEFT JOIN ProveedorKit pki ON pki.idKit = kit.idKit AND pki.idProveedorCotizacion = pco.idProveedorCotizacion
		LEFT JOIN PartidaEstatus pes ON pes.idPartidaEstatus = pki.idPartidaEstatus
	WHERE
		kit.estatus = 1
		and pco.idProveedorCotizacion = @idProveedorCotizacion
		'
		
	EXEC sp_executesql @SQL,  N'@idProveedorCotizacion INT', @idProveedorCotizacion 

	

end
go

