create procedure [dbo].[DEL_PARTIDA_SP] (
	@idPartida numeric(18,0)
)
as
begin

	DELETE FROM dbo.Partida WHERE idPartida = @idPartida
	
	SELECT @idPartida

end
go

