CREATE PROCEDURE [dbo].[SEL_CLASIFICACION_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

		SELECT
			idPartidaClasificacion as value,
			clasificacion + ' - ' + descripcion as label
		FROM
			dbo.PartidaClasificacion
		WHERE 
			estatus = 1

end
go

