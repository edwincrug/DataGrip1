CREATE procedure [dbo].[SEL_DOCUMENTOS_ENCABEZADO_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		idDocumento as value,
		descripcion as label
	FROM
		dbo.Documento doc
	WHERE
		doc.estatus = 1
		and doc.idTipoDocumento = 1

end
go

