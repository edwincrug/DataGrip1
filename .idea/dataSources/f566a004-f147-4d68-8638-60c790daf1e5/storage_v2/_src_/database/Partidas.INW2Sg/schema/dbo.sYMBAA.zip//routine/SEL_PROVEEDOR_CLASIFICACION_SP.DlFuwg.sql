create procedure [dbo].[SEL_PROVEEDOR_CLASIFICACION_SP] (
	@idCategoria numeric(18,0)
)
as
begin

	SELECT
		idProveedorClasifiacion as value,
		clasificacion as label
	FROM
		dbo.ProveedorClasificacion
	WHERE 
		idCategoria = @idCategoria
		and estatus = 1

end
go

