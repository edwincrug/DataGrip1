CREATE procedure [dbo].[SEL_COTIZACION_KITS_SP] (
	@idUsuario numeric(18,0),
	@idProveedorCotizacion numeric(18,0)
)
as
begin

	SELECT
		kit.idKit,
		partida,
		kit.descripcion,
		kit.instructivo,
		ISNULL(pki.costo,0.00) as costo,
		ISNULL(pki.costoPieza,0.00) as costoPieza,
		ISNULL(pki.costoMano,0.00) as costoMano,
		ISNULL(CONVERT(NVARCHAR(10),pki.tiempo,108),'00:00') as tiempo,
		pes.idPartidaEstatus,
		isnull(pes.estatus, 'Sin Asignar') as partidaEstatus,
		(select count(1) from KitPartida where idKit = kit.idKit ) as partidas
	FROM
		dbo.Kit kit
		LEFT JOIN dbo.Unidad uni ON uni.idUnidad = kit.idUnidad
		LEFT JOIN ProveedorCotizacion pco ON pco.idUnidad = uni.idUnidad
		LEFT JOIN ProveedorKit pki ON pki.idKit = kit.idKit AND pki.idProveedorCotizacion = pco.idProveedorCotizacion
		LEFT JOIN PartidaEstatus pes ON pes.idPartidaEstatus = pki.idPartidaEstatus
	WHERE 
		kit.estatus = 1
		and pco.idProveedorCotizacion = @idProveedorCotizacion
		

end
go

