--[dbo].[SEL_UNIDAD_DDL_SP] @idUsuario = 0
CREATE procedure [dbo].[SEL_UNIDAD_DDL_SP] (  
 @idUsuario numeric(18,0)
)  
as  
begin  


  
  SELECT  
  uni.idUnidad as value,  
  cast(uni.idUnidad as nvarchar(10)) + '/' +  
   tco.tipoCombustible + '/' + tip.tipo + '/'  + mar.nombre + '/' + sma.nombre  + '/' + cil.cilindros as label  
 FROM  
  dbo.Unidad uni  
  LEFT JOIN TipoUnidad tip ON tip.idTipoUnidad = uni.idTipoUnidad  
  LEFT JOIN TipoCombustible tco ON tco.idTipoCombustible = uni.idTipoCombustible  
  LEFT JOIN Cilindros cil ON cil.idCilindros = uni.idCilindros  
  LEFT JOIN SubMarca sma ON sma.idSubmarca = uni.idSubMarca  
  LEFT JOIN Marca mar ON mar.idMarca = sma.idMarca  
  
 WHERE   
  uni.estatus= 1  
 order by tco.tipoCombustible, tip.tipo,  mar.nombre,  sma.nombre, cil.cilindros  
end
go

