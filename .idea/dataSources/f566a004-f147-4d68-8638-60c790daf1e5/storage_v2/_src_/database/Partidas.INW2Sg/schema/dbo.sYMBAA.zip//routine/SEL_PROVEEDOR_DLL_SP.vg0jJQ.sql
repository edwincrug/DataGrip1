CREATE procedure [dbo].[SEL_PROVEEDOR_DLL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		idProveedor as value,
	        cast(idProveedor as nvarchar(10)) + ' / ' + nombreComercial + ' / ' + razonSocial as label
	FROM
		dbo.Proveedor pro
	WHERE 
		pro.estatus = 1

	ORDER BY
		pro.nombreComercial, pro.razonSocial

end
go

