CREATE PROCEDURE [dbo].[SEL_SUBCLASIFICACION_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

		SELECT
			idPartidaSubClasificacion as value,
			subClasificacion + ' - ' + descripcion as label
		FROM
			dbo.PartidaSubClasificacion
		WHERE 
			estatus = 1

end
go

