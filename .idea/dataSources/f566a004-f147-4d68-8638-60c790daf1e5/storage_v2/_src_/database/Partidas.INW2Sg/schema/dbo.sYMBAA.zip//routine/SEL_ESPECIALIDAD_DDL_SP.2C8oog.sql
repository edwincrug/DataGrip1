CREATE procedure [dbo].[SEL_ESPECIALIDAD_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

		
	SELECT
		idEspecialidad as value,
		especialidad as label,
		especialidad as text
	FROM
		dbo.Especialidad
		
	WHERE 
	estatus = 1


end
go

