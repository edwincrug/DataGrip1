CREATE procedure [dbo].[SEL_CATEGORIA_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		idCategoria as value,
		categoria as label
	FROM
		dbo.Categoria
	WHERE 
		estatus = 1

end
go

