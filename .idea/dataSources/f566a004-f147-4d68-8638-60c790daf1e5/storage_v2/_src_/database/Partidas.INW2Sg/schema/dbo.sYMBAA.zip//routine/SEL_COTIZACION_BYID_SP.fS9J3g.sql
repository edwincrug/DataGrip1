create procedure [dbo].[SEL_COTIZACION_BYID_SP] (
	@idProveedorCotizacion numeric(18,0)
)
as
begin

	SELECT
		idProveedorCotizacion,
		idProveedor,
		idUnidad,
		fecha,
		idCotizacionEstatus
	FROM
		dbo.ProveedorCotizacion
	WHERE
		idProveedorCotizacion = @idProveedorCotizacion

end
go

