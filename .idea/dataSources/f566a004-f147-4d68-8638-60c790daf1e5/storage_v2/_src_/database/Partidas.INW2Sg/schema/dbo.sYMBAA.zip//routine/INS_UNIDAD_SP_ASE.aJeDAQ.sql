CREATE PROCEDURE [dbo].[INS_UNIDAD_SP_ASE] 
	-- Add the parameters for the stored procedure here
	@idUsuario numeric(18,0)
	--,@idOperacion numeric(18,0)
	,@idTipoUnidad numeric(18,0)
	,@idSucursal numeric(18,0)
	,@idUnidadOperativa numeric(18,0)
	,@numeroEconomico nvarchar(50)
	,@vin nvarchar(50)
	,@placas nvarchar(50)
	,@modelo nvarchar(50)
	,@frente nvarchar(150)
	,@derecho nvarchar(150)
	,@izquierdo nvarchar(150)
	,@atras nvarchar(150)
	,@tarjeta nvarchar(150)
	,@autorizacion nvarchar(150)
	,@repuve NVARCHAR(150)
	,@placavin NVARCHAR(150)
	,@verificacionAmbiental NVARCHAR(150) = NULL
	,@fechaVencimientoVerificacionAmbiental date = null
	,@verificacionFisicoMecanica NVARCHAR(150) = NULL
	,@fechaVencimientoVerificacionFisicoMecanica date = null
	,@refrendo NVARCHAR(150) = NULL
	,@fechaVencimientoRefrendo date = null
	,@tenencia NVARCHAR(150) = NULL
	,@fechaVencimientoTenencia date = null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--declare variables here
	DECLARE 
		@IdUnidad NUMERIC(18,2),
		@Combustible nvarchar(200)

	--OBTEENMOS EL TIPO DE COMBUSTIBLE
	SELECT @Combustible = TC.tipoCombustible
	FROM Unidad U
	inner join TipoCombustible TC ON U.idTipoCombustible = TC.idTipoCombustible
	WHERE idUnidad = @IdUnidad


    -- Insert statements for procedure here
	IF EXISTS( SELECT 1 FROM ASEPROT.dbo.Unidades WHERE LTRIM(RTRIM(numeroEconomico)) = LTRIM(RTRIM(@numeroEconomico)) ) BEGIN
		--get IdUnidad from table
		SELECT @IdUnidad = idUnidad FROM ASEPROT.dbo.Unidades WHERE numeroEconomico=@numeroEconomico
		


		UPDATE  ASEPROT.[dbo].[Unidades]
		   SET 
			  [vin] = @vin
			  ,[gps] = 0
			  --,[idTipoUnidad] = @idTipoUnidad
			  ,[sustituto] = 0
			  ,[idOperacion] = 1
			  ,[idCentroTrabajo] = 1
			  ,[placas] = @placas
			  ,[idZona] = @idUnidadOperativa
			  ,[modelo] = @modelo
			  ,[combustible] =  @Combustible
			  ,[idUsuario] = @idUsuario
			  ,[fecha] = GETDATE()
			  ,[frente] =  case  when REPLACE(@frente,'"','') is NULL  then [frente] when REPLACE(@frente,'"','') = '' then [frente] else REPLACE(@frente,'"','') end
			  ,[derecho] =  case when  REPLACE(@derecho,'"','') is null then [derecho] when REPLACE(@derecho,'"','') = '' then [derecho] else REPLACE(@derecho,'"','') end
			  ,[izquierdo] =  case when REPLACE(@izquierdo,'"','') is null then [izquierdo] when REPLACE(@izquierdo,'"','') = '' then [izquierdo] else REPLACE(@izquierdo,'"','') end
			  ,[atras] =  case when REPLACE(@atras,'"','') is null then [atras] when REPLACE(@atras,'"','') = '' then [atras] else REPLACE(@atras,'"','') end
			  ,[tarjeta] =  case when REPLACE(@tarjeta,'"','') is null then [tarjeta] when REPLACE(@tarjeta,'"','') = '' then [tarjeta] else REPLACE(@tarjeta,'"','') end
			  ,[autorizacion] =  case when REPLACE(@autorizacion,'"','') is null then [autorizacion] when REPLACE(@autorizacion,'"','') = '' then [autorizacion] else REPLACE(@autorizacion,'"','') end
			  ,[verificada]=1
			  ,[repuve] =  case when REPLACE(@repuve,'"','') is null then [repuve] when REPLACE(@repuve,'"','')  = '' then [repuve] else REPLACE(@repuve,'"','') end
			  ,[placavin] =  case when REPLACE(@placavin,'"','') is null then [placavin] when REPLACE(@placavin,'"','') = '' then [placavin] else REPLACE(@placavin,'"','') end
			  
			  ,[verificacionAmbiental] = case when REPLACE(@verificacionAmbiental,'"','') is null then [verificacionAmbiental] when REPLACE(@verificacionAmbiental,'"','') = '' then [verificacionAmbiental] else REPLACE(@verificacionAmbiental,'"','') end
			  ,[fechaVencimientoVerificacionAmbiental] = case when @fechaVencimientoVerificacionAmbiental is null then [fechaVencimientoVerificacionAmbiental] when @fechaVencimientoVerificacionAmbiental='' then [fechaVencimientoVerificacionAmbiental] else @fechaVencimientoVerificacionAmbiental end

			  ,[verificacionFisicoMecanica] = case when REPLACE(@verificacionFisicoMecanica,'"','') is null then [verificacionFisicoMecanica] when REPLACE(@verificacionFisicoMecanica,'"','') = '' then [verificacionFisicoMecanica] else REPLACE(@verificacionFisicoMecanica,'"','') end
			  ,[fechaVencimientoVerificacionFisicoMecanica] = case when @fechaVencimientoVerificacionFisicoMecanica is null then [fechaVencimientoVerificacionFisicoMecanica] when @fechaVencimientoVerificacionFisicoMecanica='' then [fechaVencimientoVerificacionFisicoMecanica] else @fechaVencimientoVerificacionFisicoMecanica end

			  ,[refrendo] = case when REPLACE(@refrendo,'"','') is null then [refrendo] when REPLACE(@refrendo,'"','')  = '' then [refrendo] else REPLACE(@refrendo,'"','') end
			  ,[fechaVencimientoRefrendo] = case when @fechaVencimientoRefrendo is null then [fechaVencimientoRefrendo] when @fechaVencimientoRefrendo='' then [fechaVencimientoRefrendo] else @fechaVencimientoRefrendo end

			  ,[tenencia] = case when REPLACE(@tenencia,'"','') is null then [tenencia] when REPLACE(@tenencia,'"','')  = '' then [tenencia] else REPLACE(@tenencia,'"','') end
			  ,[fechaVencimientoTenencia] = case when @fechaVencimientoTenencia is null then [fechaVencimientoTenencia] when @fechaVencimientoTenencia='' then [fechaVencimientoTenencia] else @fechaVencimientoTenencia end
		 WHERE 
			[numeroEconomico] = LTRIM(RTRIM(@numeroEconomico))

	END
	ELSE BEGIN
		
		INSERT INTO ASEPROT.[dbo].[Unidades]
			   ([numeroEconomico]
			   ,[vin]
			   ,[gps]
			   ,[idTipoUnidad]
			   ,[sustituto]
			   ,[idOperacion]
			   ,[idCentroTrabajo]
			   ,[placas]
			   ,[idZona]
			   ,[modelo]
			   ,[combustible]
			   ,[idUsuario]
			   ,[fecha]
			   ,[frente]
			   ,[derecho]
			   ,[izquierdo]
			   ,[atras]
			   ,[tarjeta]
			   ,[autorizacion]
			   ,[verificada]
			   ,[repuve]
			   ,[placavin]
			   ,[verificacionAmbiental]
			   ,[fechaVencimientoVerificacionAmbiental])
		 VALUES
			   (LTRIM(RTRIM(@numeroEconomico))
			   ,@vin
			   ,''
			   , @idTipoUnidad
			   ,NULL
			   ,1
			   ,1
			   , @placas
			   , 1
			   ,@modelo
			   ,@Combustible
			   ,@idUsuario
			   ,GETDATE()
			   ,REPLACE(@frente,'"','')
			   ,REPLACE(@derecho,'"','')
			   ,REPLACE(@izquierdo,'"','')
			   ,REPLACE(@atras,'"','')
			   ,REPLACE(@tarjeta,'"','')
			   ,REPLACE(@autorizacion,'"','')
			   ,1
			   ,REPLACE(@repuve,'"','')
			   ,REPLACE(@placavin,'"','')
			   ,REPLACE(@verificacionAmbiental,'"','')
			   ,REPLACE(@fechaVencimientoVerificacionAmbiental,'"',''))
			   
			   --get id from identity
			   SET @IdUnidad = SCOPE_IDENTITY()
	END
	
	-- insert statement for UnidadZona	
	DELETE FROM ASEPROT.dbo.UnidadesZona WHERE idUnidad  = @IdUnidad
	-- 1.1 INSERT IdSucursal
	INSERT INTO ASEPROT.dbo.UnidadesZona 
	(
		-- idUnidadZonas -- this column value is auto-generated
		idUnidad,
		idZona
	)
	VALUES
	(
		@IdUnidad,
		@idSucursal
	)
	-- 1.2 INSERT idUnidadOperativa
	INSERT INTO ASEPROT.dbo.UnidadesZona 
	(
		-- idUnidadZonas -- this column value is auto-generated
		idUnidad,
		idZona
	)
	VALUES
	(
		@IdUnidad,
		@idUnidadOperativa
	)
	
	
	/*
	IF EXISTS(SELECT 1 FROM UnidadASE WHERE numeroEconomico = @numeroEconomico ) BEGIN

		UPDATE [dbo].[UnidadASE]
		   SET [idUsuario] = @idUsuario
			  ,[fecha] = GETDATE()
			  ,[frente] =  REPLACE(@frente,'"','') 
			  ,[derecho] =  REPLACE(@derecho,'"','') 
			  ,[izquierdo] =  REPLACE(@izquierdo,'"','')
			  ,[atras] =  REPLACE(@atras,'"','')
			  ,[tarjeta] = REPLACE(@tarjeta,'"','') 
			  ,[autorizacion] = REPLACE(@autorizacion,'"','') 
		 WHERE 
		 numeroEconomico = @numeroEconomico


	END
	ELSE BEGIN

		INSERT INTO [dbo].[UnidadASE]
			   ([idUsuario]
			   ,[numeroEconomico]
			   ,[fecha]
			   ,[frente]
			   ,[derecho]
			   ,[izquierdo]
			   ,[atras]
			   ,[tarjeta]
			   ,[autorizacion])
		 VALUES
			   (@idUsuario
			   ,@numeroEconomico
			   ,GETDATE()
			   ,REPLACE(@frente,'"','') 
			   ,REPLACE(@derecho,'"','') 
			   , REPLACE(@izquierdo,'"','')
			   , REPLACE(@atras,'"','')
			   ,REPLACE(@tarjeta,'"','') 
			   ,REPLACE(@autorizacion,'"',''))

	END
	*/


	SELECT @numeroEconomico as eco

END
go

