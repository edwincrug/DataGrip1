CREATE PROCEDURE [dbo].[SEL_LICITACION_DDL_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		idLicitacion as value,
		cli.razonSocial + ' | Folio: ' + folio + ' - ' + lic.nombre  as label
		,CASE WHEN (SELECT COUNT(*) FROM vwUsuarioAgregarUnidad WHERE idUsuario=@idUsuario)>0 THEN 1 ELSE 0 END AS puedeAgregarUnidad
		,CASE WHEN (SELECT COUNT(*) FROM vwUsuarioAgregarProveedor WHERE idUsuario=@idUsuario)>0 THEN 1 ELSE 0 END AS puedeAgregarProveedor
	FROM
		dbo.Licitacion lic
		LEFT JOIN Cliente cli ON cli.idCliente = lic.idCliente
		LEFT JOIN Cliente clf ON clf.idCliente = lic.idClienteFinal
	WHERE 
		lic.estatus = 1

end
go

