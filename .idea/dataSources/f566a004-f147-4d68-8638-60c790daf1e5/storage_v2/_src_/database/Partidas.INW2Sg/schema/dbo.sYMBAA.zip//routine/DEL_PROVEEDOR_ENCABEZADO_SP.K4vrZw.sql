CREATE procedure [dbo].[DEL_PROVEEDOR_ENCABEZADO_SP] (
	@idProveedorEncabezado numeric(18,0)
)
as
begin

	DELETE FROM dbo.ProveedorEncabezado WHERE idProveedorEncabezado = @idProveedorEncabezado
	
	SELECT @idProveedorEncabezado

end
go

