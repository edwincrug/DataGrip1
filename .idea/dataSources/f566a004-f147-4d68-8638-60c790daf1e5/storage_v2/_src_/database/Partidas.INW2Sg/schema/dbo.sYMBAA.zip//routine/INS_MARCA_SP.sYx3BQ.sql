CREATE PROCEDURE [dbo].[INS_MARCA_SP] (
	@marca nvarchar(200)
)
as
begin

	
	INSERT INTO dbo.Marca
		(nombre, estatus)
	VALUES 
		(@marca, 1 );
		
	SELECT @@IDENTITY
end
go

