CREATE PROCEDURE [dbo].[SEL_MARCA_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	
	SELECT
		idMarca,
		nombre as marca,
		estatus
	FROM
		dbo.Marca

end
go

