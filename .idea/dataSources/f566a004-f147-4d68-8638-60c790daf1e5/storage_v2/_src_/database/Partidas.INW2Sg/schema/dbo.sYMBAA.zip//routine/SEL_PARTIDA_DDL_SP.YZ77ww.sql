create procedure [dbo].[SEL_PARTIDA_DDL_SP] (
	@idUsuario numeric(18,0),
	@idUnidad numeric(18,0)
)
as
begin

	SELECT
		idPartida as value,
		partida + ' ' + noParte + ' ' + par.descripcion as label
	FROM
		dbo.Partida par
		LEFT JOIN dbo.Unidad uni ON uni.idUnidad = par.idUnidad
		LEFT JOIN dbo.Especialidad esp ON esp.idEspecialidad = par.idEspecialidad
		LEFT JOIN TipoUnidad tip ON tip.idTipoUnidad = uni.idTipoUnidad
		LEFT JOIN SubMarca sma ON sma.idSubmarca = uni.idSubMarca
		LEFT JOIN Marca mar ON mar.idMarca = sma.idMarca
		LEFT JOIN PartidaClasificacion cl1 ON cl1.idPartidaClasificacion = par.idPartidaClasificacion
		LEFT JOIN PartidaSubClasificacion cl2 ON cl2.idPartidaSubClasificacion = par.idPartidaSubClasificacion
	WHERE 
		par.estatus = 1
		AND uni.idUnidad = @idUnidad

end
go

