CREATE procedure [dbo].[SEL_CLIENTE_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT
		idCliente,
		nombreComercial,
		razonSocial,
		rfc,
		direccion,
		telefono,
		estatus
	FROM
		dbo.Cliente;

end
go

