CREATE procedure [dbo].[INS_PROVEEDOR_PARTIDA_BY_COTIZACION_SP] (
	@idProveedorCotizacion numeric(18,0),
	@idUsuario numeric(18,0)
)
as
begin
			
	INSERT INTO dbo.ProveedorPartida
		(idProveedorCotizacion, idPartida, costoPieza, costoMano, costo, tiempo, fecha, idUsuario, idPartidaEstatus)
	SELECT
		@idProveedorCotizacion,
		par.idPartida,
		0,
		0,
		0,
		0,
		GETDATE(),
		@idUsuario,
		2
	FROM
		dbo.Partida par
		LEFT JOIN dbo.Unidad uni ON uni.idUnidad = par.idUnidad
		LEFT JOIN ProveedorCotizacion pco ON pco.idUnidad = uni.idUnidad
		LEFT JOIN ProveedorPartida ppa ON ppa.idPartida = par.idPartida AND ppa.idProveedorCotizacion = pco.idProveedorCotizacion
		
	WHERE 
		par.estatus = 1
		and pco.idProveedorCotizacion = @idProveedorCotizacion
		and idProveedorPartida is null
		
	
	--*******************************************************************************************************
	--BLOQUE TEMPORAL PARA ACTUALIZAR LAS COTIZACIONES APLICABLES PARA ESE PROVEEDOR
	--*******************************************************************************************************

	DECLARE @idProveedor numeric(18,0)	
	select TOP 1 @idProveedor = idProveedor from ProveedorCotizacion where idProveedorCotizacion=@idProveedorCotizacion 

	UPDATE CD
		set CD.costo = PP.costo
	from ASEPROT.dbo.CotizacionDetalle CD
	inner join ASEPROT.dbo.Cotizaciones C on C.idCotizacion = CD.idCotizacion
	inner join ProveedorPartida PP on PP.idPartida = CD.idPartida
	where C.idTaller = @idProveedor
	and PP.idProveedorCotizacion = @idProveedorCotizacion 
	and CD.costo = 0

	update ProveedorCotizacion set  idCotizacionEstatus = 2 where idProveedorCotizacion = @idProveedorCotizacion

	SELECT @idProveedorCotizacion as idProveedorCotizacion



end
go

