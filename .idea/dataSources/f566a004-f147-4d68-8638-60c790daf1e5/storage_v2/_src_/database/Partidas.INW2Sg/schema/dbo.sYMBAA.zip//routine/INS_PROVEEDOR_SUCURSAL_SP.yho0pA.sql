-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- INS_PROVEEDOR_SUCURSAL_SP '[{"value":9,"label":"Suspensión","text":"Suspensión"},{"value":8,"label":"Enfriamiento","text":"Enfriamiento"}]'
CREATE PROCEDURE [dbo].[INS_PROVEEDOR_SUCURSAL_SP] (
	-- Add the parameters for the stored procedure here
	@idProveedorEncabezado			numeric(18,0),
	@nombreComercial				nvarchar(200),
	@razonSocial					nvarchar(500),
	@RFC							nvarchar(20),
	@contacto						nvarchar(200),
	@telefono						nvarchar(200),
	@mail							nvarchar(200),
	@fechaInicio					datetime,
	@idCategoria					numeric(18,0),
	@idProveedorClasificacion		numeric(18,0),
	@idProveedorSubClasificacion	numeric(18,0), 
	@direccion						nvarchar(500),
	@latitud						nvarchar(50), 
	@longitud						nvarchar(50), 
	@poligono						nvarchar(200),

	--
	@JSONCombustible			varchar(max),
	@JSONDIESEL					varchar(max),
	@JSONGasolina				varchar(max)
	
)
AS
BEGIN
	
	INSERT INTO dbo.Proveedor (idProveedorEncabezado, nombreComercial, razonSocial, RFC, contacto, telefono, mail, fechaInicio, 
		idCategoria, idProveedorClasificacion, idProveedorSubClasificacion, direccion, latitud, longitud, poligono, idBPRO, estatus)
	VALUES (@idProveedorEncabezado, @nombreComercial, @razonSocial, @RFC, @contacto, @telefono, @mail, @fechaInicio, @idCategoria,
		@idProveedorClasificacion, @idProveedorSubClasificacion, @direccion, @latitud, @longitud, @poligono, 1, 1)

	DECLARE @idProveedor numeric(18,0) 
	set @idProveedor = @@IDENTITY

    CREATE TABLE #JSON(
		element_id numeric(18,0),
		secuenceNo numeric(18,0),
		parent_ID numeric(18,0),
		Object_ID numeric(18,0),
		NAME nvarchar(MAX),
		StringValue nvarchar(MAX),
		ValueType nvarchar(MAX)
	)
	
	--PRIMERO INSERTAMOS LOS COMBUSTIBLES
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@JSONCombustible)
	
	insert into ProveedorTipoCombustible
	select @idProveedor, StringValue from #JSON where NAME = 'value'


	--ELIMINAMOS Y AHORA METEMOS LAS ESPECIALIDADES DIESEL
	DELETE FROM #JSON
	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@JSONDIESEL)

	insert into ProveedorEspecialidadCombustible
	select @idProveedor, StringValue, 1 from #JSON where NAME = 'value'


	--ELIMINAMOS Y AHORA METEMOS LAS ESPECIALIDADES Gasolina
	DELETE FROM #JSON
	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@JSONGasolina)

	insert into ProveedorEspecialidadCombustible
	select @idProveedor, StringValue, 2 from #JSON where NAME = 'value'
	
	
	SELECT * from Proveedor
END
go

