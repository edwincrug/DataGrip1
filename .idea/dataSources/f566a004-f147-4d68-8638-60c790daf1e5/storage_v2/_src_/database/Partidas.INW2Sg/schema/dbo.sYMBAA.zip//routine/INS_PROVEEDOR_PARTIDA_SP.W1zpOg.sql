CREATE procedure [dbo].[INS_PROVEEDOR_PARTIDA_SP] (
	@idProveedorCotizacion numeric(18,0),
	@idUsuario numeric(18,0),
	@json nvarchar(max)
)
as
begin


	/*DECLARE @costoPieza as decimal(18,2)
	DECLARE @costoMano as decimal(18,2)*/
	--DECLARE @tiempo as int
	DECLARE @idPartida as decimal(18,2)


	--CREAMOS TABLA TEMPORAL PARA EL JSON
	CREATE TABLE #JSON(
		element_id numeric(18,0),
		secuenceNo numeric(18,0),
		parent_ID numeric(18,0),
		Object_ID numeric(18,0),
		NAME nvarchar(MAX),
		StringValue nvarchar(MAX),
		ValueType nvarchar(MAX)
	)
	--INSERTAMOS EL JSON A UNA TABLA TEMPORAL
	INSERT INTO #JSON
	SELECT * FROM parseJSON(@json)




	--Insertar cotizaciones
	DECLARE @parent AS INT
	DECLARE _cursor CURSOR FOR 
	SELECT Object_ID FROM #JSON
	WHERE 
	Object_ID IS NOT NULL
	AND ValueType = 'object' 
	ORDER BY Object_ID

	OPEN _cursor 
	FETCH NEXT FROM _cursor INTO @parent
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		
		SELECT @idPartida = REPLACE(StringValue,'"','')  FROM #JSON
			WHERE 
			parent_ID = @parent
			AND NAME = 'idPartida'
			AND Object_ID IS NULL
			
		/*SELECT @costoPieza = REPLACE(StringValue,'"','')  FROM #JSON
			WHERE 
			parent_ID = @parent
			AND NAME = 'costoPieza'
			AND Object_ID IS NULL
	
		SELECT @costoMano = REPLACE(StringValue,'"','')  FROM #JSON
			WHERE 
			parent_ID = @parent
			AND NAME = 'costoMano'
			AND Object_ID IS NULL
			
		SELECT @tiempo = REPLACE(StringValue,'"','')  FROM #JSON
			WHERE 
			parent_ID = @parent
			AND NAME = 'tiempo'
			AND Object_ID IS NULL*/
	
			
		IF( EXISTS(SELECT 1 FROM dbo.ProveedorPartida WHERE idProveedorCotizacion = @idProveedorCotizacion AND  idPartida = @idPartida) ) BEGIN
	
			UPDATE
				dbo.ProveedorPartida
			SET
				costoPieza = 0,
				costoMano = 0,
				costo = 0,
				tiempo = 0,
				fecha = GETDATE(),
				idUsuario = @idUsuario
				--idPartidaEstatus = 3
			WHERE 
				idProveedorCotizacion = @idProveedorCotizacion 
				AND  idPartida = @idPartida
		END
		ELSE BEGIN
		
			INSERT INTO dbo.ProveedorPartida
				(idProveedorCotizacion, idPartida, costoPieza, costoMano, costo, tiempo, fecha, idUsuario, idPartidaEstatus)
			VALUES 
				(@idProveedorCotizacion, @idPartida, 0,0, 0, 0, GETDATE(), @idUsuario, 2)
		
		END
	
	FETCH NEXT FROM _cursor INTO @parent
	END 
	CLOSE _cursor 
	DEALLOCATE _cursor
	
	


	--UPDATE
	--	dbo.ProveedorCotizacion
	--SET
	--	idCotizacionEstatus = 2
	--WHERE 
	--	idProveedorCotizacion = @idProveedorCotizacion

	--*******************************************************************************************************
	--BLOQUE TEMPORAL PARA ACTUALIZAR LAS COTIZACIONES APLICABLES PARA ESE PROVEEDOR
	--*******************************************************************************************************

	DECLARE @idProveedor numeric(18,0)	
	select TOP 1 @idProveedor = idProveedor from ProveedorCotizacion where idProveedorCotizacion=@idProveedorCotizacion 

	UPDATE CD
		set CD.costo = PP.costo
	from ASEPROT.dbo.CotizacionDetalle CD
	inner join ASEPROT.dbo.Cotizaciones C on C.idCotizacion = CD.idCotizacion
	inner join ProveedorPartida PP on PP.idPartida = CD.idPartida
	where C.idTaller = @idProveedor
	and PP.idProveedorCotizacion = @idProveedorCotizacion 
	and CD.costo = 0

	SELECT @idProveedorCotizacion as idProveedorCotizacion


end
go

