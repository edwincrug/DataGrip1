-- =============================================
-- Author:		Uriel Hernandez
-- Create date: 06/11/2020
-- Description:	Obtiene los tipos de direccion
-- =============================================
/*
	Fecha:		Autor	Descripción 
	

	*- Testing...
	EXEC [direccion].[SEL_TIPODIRECCION_SP]
*/
-- =============================================
CREATE PROCEDURE [direccion].[SEL_TIPODIRECCION_SP]
	@err					varchar(max) = '' OUTPUT,
	@idUsuario				INT = null
AS

BEGIN	
	
	SELECT * FROM [direccion].[TipoDireccion] WHERE activo = 1 ORDER BY [idTipoDireccion]
END
go

