

-- =============================================
-- Author: Uriel Hernandez
-- Create date: 06/11/2020
-- Description: Consulta que devuelve los estados
-- ============== Versionamiento ================
/*
	Fecha		Autor	Descripción 
	

	*- Testing...
	DECLARE @salida varchar(max) ='' ;
	EXEC [direccion].[SEL_ESTADOS_SP] 6036, @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE  PROCEDURE [direccion].[SEL_ESTADOS_SP] 
	@idUsuario			INT,
	@err				NVARCHAR(500) OUTPUT
AS
BEGIN

SELECT [idPais]
	  ,[idEstado]
      ,[nombre]
      ,[idUsuario]
  FROM [Common].[direccion].[Estado]
		
END
go

