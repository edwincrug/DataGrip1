CREATE PROC [dbo].[insertarProceso] 
	@IdTarea INT,
	@ClaveInvocaTarea NVARCHAR(10)
as
BEGIN
    BEGIN TRAN Tadd
    BEGIN TRY
		DECLARE @IdEstatusProceso INT
		DECLARE @IdProceso INT
		DECLARE @totalPasos INT
		DECLARE @descInvocaTarea NVARCHAR(75)
		SELECT  @IdEstatusProceso=(SELECT IdEstatusProceso FROM EstatusProcesos WHERE clave='ENE')
		SELECT  @descInvocaTarea=(SELECT Descripcion FROM InvocaTareas WHERE clave=@ClaveInvocaTarea)
		SELECT @totalPasos=(SELECT COUNT(IdPaso) FROM pasos WHERE Estatus=1 and IdTarea=@IdTarea)
		IF(@totalPasos=0)
			BEGIN
				--Salida del SP
				SELECT 0 Estatus,'No existen pasos.' Mensaje,0 IdProceso
				ROLLBACK TRAN Tadd
			END
		ELSE
			BEGIN
			--Insertar Procesos
			INSERT INTO Procesos(IdGrupoTarea,IdTarea,IdEstatusProceso,GrupoTarea,Tarea,Horario,TipoHorario,Prioridad,NotificaInicio,DestinatarioInicio,NotificaFin,DestinatarioFin,NotificaError,DestinatarioError,Observaciones,ClaveInvocaTarea,FechaHoraAlta) 
				SELECT gt.IdGrupoTarea,t.IdTarea,@IdEstatusProceso IdEstatusProceso,gt.Descripcion 'GruposTareas',t.Nombre 'Tarea',@descInvocaTarea Horario,'' TipoHorario,t.Prioridad,t.NotificaInicio,t.DestinatarioInicio,t.NotificaFin,t.DestinatarioFin,t.NotificaError,t.DestinatarioError,'' observaciones,@ClaveInvocaTarea,GETDATE() FechaHoraAlta 
				FROM  Tareas t  
					INNER JOIN GruposTareas gt ON t.idGrupoTarea=gt.idGrupoTarea  
				WHERE t.Estatus=1 AND t.IdTarea=@IdTarea

			SELECT @IdProceso=(SELECT MAX(IdProceso) FROM Procesos)
			--Insertar Bitacora de Proceso
			INSERT INTO Bitacora(Accion,Comentario,GrupoTarea,Tarea,Prioridad,Paso,TipoPaso,Horario,TipoHorario,EstatusProceso,FechaHora,IdProceso,IdProcesoPaso,IdUsuario)
				SELECT 'AGREGAR PROCESO SP' Accion,'' Comentario,p.GrupoTarea ,p.Tarea,p.Prioridad,'' Paso,'' TipoPaso,'' Horario,'' TipoHorario,'En Espera' EstatusProceso,GETDATE() FechaHoraAlta,@IdProceso IdProceso,'' IdProcesoPaso, 0 IdUsuarioAlta
				FROM procesos p 
				WHERE p.IdPRoceso=@IdProceso
			--Insertar ProcesosPasos
			INSERT INTO ProcesosPasos  (IdProceso,IdPaso,IdEstatusProceso,Paso,Ordenamiento,TipoPaso,ClaveTipoPaso,ApliProc,Comando,sTipoComando,sNombre,sTipoSalida,saRutaSalida,saDelimitador,eDestinatario,eAsunto,eMensaje,eAliasEmisor,eCC,eCCO,eArchivo,fHost,fUsuario,fContrasenia,fAccion,fRutaRemota,fRutaLocal,fModoTransferencia,fProtocolo,cAccion,cOrigen,cDestino,Observaciones,TiempoEspera)
				SELECT @IdProceso IdProceso,p.IdPaso,@IdEstatusProceso IdEstatusProceso,p.Nombre,p.Ordenamiento,tp.Descripcion,tp.Clave,p.ApliProc,p.Comando,p.sTipoComando,p.sNombre,p.sTipoSalida,p.saRutaSalida,p.saDelimitador,p.eDestinatario,p.eAsunto,p.eMensaje,p.eAliasEmisor,p.eCC,p.eCCO,p.eArchivos,p.fHost,p.fUsuario,p.fContrasenia,p.fAccion,p.fRutaRemota,p.fRutaLocal,p.fModoTransferencia,p.fProtocolo,p.cAccion,p.cOrigen,p.cDestino,'' Observaciones,p.TiempoEspera 
				FROM pasos p 
					INNER JOIN TiposPasos  tp ON p.IdTipoPaso=tp.IdTipoPaso 
				WHERE p.idTarea=@IdTarea AND p.Estatus=1 AND tp.Estatus=1 
				ORDER BY ordenamiento
			--Insertar Bitacora de ProcesosPasos
			INSERT INTO Bitacora(Accion,Comentario,GrupoTarea,Tarea,Prioridad,Paso,TipoPaso,Horario,TipoHorario,EstatusProceso,FechaHora,IdProceso,IdProcesoPaso,IdUsuario)
			SELECT 'AGREGAR PROCESO PASO SP' Accion,'' Comentario,p.GrupoTarea ,p.Tarea,p.Prioridad,pp.Paso,pp.TipoPaso,'' Horario,'' TipoHorario,'En Espera' EstatusProceso,GETDATE() FechaHoraAlta,@IdProceso IdProceso,pp.IdProcesoPaso,0 IdUsuarioAlta 
				FROM procesospasos pp
				INNER JOIN Procesos p ON pp.IdProceso=p.IdProceso 
				WHERE p.IdPRoceso=@IdProceso ORDER BY pp.Ordenamiento
			--Salida del SP
	        SELECT 1 Estatus, 'El registro se agregó correctamente.' Mensaje,@IdProceso IdProceso
			COMMIT TRAN Tadd
			END
    END TRY
    BEGIN CATCH
		--Salida del SP
        SELECT -1 Estatus,('Ocurrio un Error: ' + ERROR_MESSAGE() + ' en la línea ' + CONVERT(NVARCHAR(255), ERROR_LINE() ) + '.') Mensaje, 0 IdPRoceso
        ROLLBACK TRAN Tadd
    END CATCH
END
go

