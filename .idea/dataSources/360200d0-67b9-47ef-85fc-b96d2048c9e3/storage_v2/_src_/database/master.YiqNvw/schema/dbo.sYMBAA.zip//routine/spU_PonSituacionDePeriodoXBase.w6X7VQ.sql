/*
Establece la situacion de un periodo en la base de BPRO que se le pasa como parámetro
si el parametro @sMes es vacio '' entonces la situacion la establece para todo el año.
Si se quiere abrir un periodo ya abierto no hace nada, idem si se quiere cerrar un periodo ya cerrado.


declare @anio char(4);declare @mes char(2);declare @dia char(2);declare @len int;declare @situa char(7);declare @situa1 char(7)
set @anio='2018';set @mes='';set @dia='';set @len = 4;set @situa ='ABIERTO';set @situa1 ='CERRADO'
  
use GAZM_Zaragoza
select DB_NAME(),* from PNC_PARAMETR 
where par_tipopara='MCERRCON' AND substring(PAR_IDENPARA,1,@len) = @anio+@mes+@dia -- AND PAR_DESCRIP2 =@situa

Execute Centralizacionv2.dbo.spU_PonSituacionDePeriodoXBase 'GAZM_Zaragoza','ABIERTO','2018','08',0
*/

CREATE PROCEDURE [dbo].[spU_PonSituacionDePeriodoXBase](@sBase varchar(50), @sSITUACION varchar(30), @sAnio varchar(4), @sMes varchar(2),@iResultado int OUTPUT) --with recompile
 AS
declare
@iIndice int,
@sTabla varchar(200),
@situa varchar(20),
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500)

begin 
set nocount on

DECLARE @db_id int;  
DECLARE @object_id int;  
SET @db_id = DB_ID(@sBase);  
set @sTabla = @sBase + '.dbo.PNC_PARAMETR' 
SET @object_id = OBJECT_ID(@sTabla);  

--print 'El id de la tabla:' + convert(varchar(50),@object_id)

IF @db_id IS NULL   
  BEGIN;  
    PRINT N'No se encuentra la Base de datos: ' + @sBase; 
	select @iResultado = 1 
  END;  
ELSE IF @object_id IS NULL  
  BEGIN;  
    PRINT N'La base de datos: ' +  @sBase + ' No tiene la tabla PNC_PARAMETR';  
	select @iResultado = 2
  END;  
ELSE  
  BEGIN; 
			Declare @saux_aniomes varchar(6) = '';
			Declare @sLen varchar(1) = '';
			select @saux_aniomes = ltrim(rtrim(@sAnio)) + ltrim(rtrim(@sMes));
			select @sLen = Convert(char(1),len(@saux_aniomes));
			Declare @sPAR_IDENPARA varchar(10) = '';

       		set @sQ = N'Select @ssPAR_IDENPARA = PAR_IDENPARA from ' + @sTabla
		    set @sQ = @sQ + N' where par_tipopara=' + char(39) +  'MCERRCON' + char(39) + ' AND substring(PAR_IDENPARA,1,' + @sLen + ') = ' + char(39) + @sAnio + @sMes + char(39)
			if @sSITUACION  = 'CERRADO'
			  begin
			  set @situa = 'ABIERTO'			
			  end
			if @sSITUACION  = 'ABIERTO'
			  begin
			  set @situa = 'CERRADO'			  
			  end   
			  set @sQ = @sQ + N' and PAR_DESCRIP2=' + char(39) +  @situa + char(39)

		    set @sParmDefinition = N'@ssPAR_IDENPARA varchar(10) OUTPUT'
			--print @sQ
			--print @sParmDefinition
			execute sp_executesql @sQ,@sParmDefinition,@ssPAR_IDENPARA = @sPAR_IDENPARA OUTPUT
			if (@sPAR_IDENPARA <> '')
			begin
				set @sQ = N'UPDATE ' + @sTabla + ' SET PAR_DESCRIP2=' + char(39) + @sSITUACION + char(39) 
				set @sQ = @sQ + N' where par_tipopara=' + char(39) + 'MCERRCON' + char(39) + ' AND substring(PAR_IDENPARA,1,' + @sLen + ') = ' + char(39) + @sAnio+@sMes + char(39)
			    set @sQ = @sQ + N' AND PAR_DESCRIP2 = ' + char(39) +  @situa + char(39)	    		
				execute sp_executesql @sQ
				select @iResultado = 0;
				if @sLen = '6'
				begin
				   print 'Se estableció la situacion del periodo: ' + @sPAR_IDENPARA + ' de ' + @sTabla + ' en ' + @sSITUACION  
                end
				if @sLen = '4'
				begin
				   print 'Se estableció la situacion del periodo: ' + @sAnio + ' de ' + @sTabla + ' en ' + @sSITUACION  
                end				 
			end
			else
			begin
			  print 'No se encontró el parámetro:' + @sQ
			  print 'No se actualizó NADA'
			  select @iResultado = 3
			end    
  END;  

Return @iResultado

set nocount off
end
go

