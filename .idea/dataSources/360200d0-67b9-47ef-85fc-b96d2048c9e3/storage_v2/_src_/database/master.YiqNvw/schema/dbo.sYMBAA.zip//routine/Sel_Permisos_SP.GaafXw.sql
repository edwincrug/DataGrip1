-- ==========================================================================================
-- Author:	 Irving solorio Garcia
-- Create date:  21/04/2018
-- Description:	 Inserta los catalogos
-- [dbo].[Sel_Permisos_SP] 93310
-- ==========================================================================================

CREATE PROCEDURE [dbo].[Sel_Permisos_SP]
	@idpersona int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @PROV int
SET @PROV =@idpersona

--CHEVROLET-----------------------------------------------------------------------------------
select empresa,convert(bit,cuenta) cuenta from (
SELECT 'CHEVROLET AZCAPO' empresa, (select count(rol_idpersona) FROM GAAA_Azcapo.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'CHEVROLET PERISUR' empresa, (select count(rol_idpersona) FROM GAAA_PERISUR.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta 
union all
SELECT 'CHEVROLET TEPEPAN' empresa, (select count(rol_idpersona) FROM GAAA_Tepepan.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'GMC ESMERALDA' empresa, (select count(rol_idpersona) FROM GAAS_Esmeralda.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'GMC PEDREGAL' empresa, (select count(rol_idpersona) FROM GAAS_Pedregal.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'GMC SATELITE' empresa, (select count(rol_idpersona) FROM GAAS_Satelite.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'PEUGEOT MIRAMONTES' empresa, (select count(rol_idpersona) FROM GAAT_Peugeot.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'SUZUKI CUAUTITLAN' empresa, (select count(rol_idpersona) FROM GAAU_Cuautitlan.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'SUZUKI PEDREGAL' empresa, (select count(rol_idpersona) FROM GAAU_Pedregal.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'SUZUKI UNIVERSIDAD' empresa, (select count(rol_idpersona) FROM GAAU_Universidad.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'AUTOANGAR ERMITA' empresa, (select count(rol_idpersona) FROM GAAutoAngar.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'AUTOANGAR MITSU' empresa, (select count(rol_idpersona) FROM GAAutoAngarMitsu.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'AUTOANGAR TEPEPAN' empresa, (select count(rol_idpersona) FROM GAAutoAngarTepepan.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'AUTOANGAR TLAHUAC' empresa, (select count(rol_idpersona) FROM GAAutoAngarTlahuac.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'INFINITI PEDREGAL' empresa, (select count(rol_idpersona) FROM GADVAP_Pedregal.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'HYUNDAI CUAUTITLAN' empresa, (select count(rol_idpersona) FROM GAHyundai.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'HYUNDAI ECATEPEC' empresa, (select count(rol_idpersona) FROM GAHyundaiEcatepec.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'GAZM_Abasto' empresa, (select count(rol_idpersona) FROM GAZM_Abasto.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'GAZM_FAerea' empresa, (select count(rol_idpersona) FROM GAZM_FAerea.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
union all
SELECT 'GAZM_Zaragoza' empresa, (select count(rol_idpersona) FROM GAZM_Zaragoza.DBO.PER_ROLES WHERE ROL_IDPERSONA = @PROV AND ROL_ROL = 'PROTER') cuenta
) x


END
go

