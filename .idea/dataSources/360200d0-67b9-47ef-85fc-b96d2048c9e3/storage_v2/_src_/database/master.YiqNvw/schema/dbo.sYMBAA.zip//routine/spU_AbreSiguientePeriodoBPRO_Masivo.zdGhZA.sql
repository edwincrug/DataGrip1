/*

Busca todas las bases de datos que tiene un servidor.
Barre una a una estas bases validando si tiene o no la tabla PNC_PARAMETR
Identifica el primer día del siguiente mes y si la BD tiene la tabla PNC_PARAMETR
lo pone ABIERTO.

Esta pensado en que se ejecute bajo una tarea programada el último día de cada mes
a las 23:55 p.m.

Declare @iError int = 0 ;
Execute master.dbo.spU_AbreSiguientePeriodoBPRO_Masivo @iError OUTPUT
print Convert(char(2),@iError);

--PARA CUANDO NO TIENE DECLARADO EL PARAMETRO
--insert into GAZM_Abasto.dbo.PNC_PARAMETR (PAR_TIPOPARA, PAR_IDENPARA,         PAR_IDMODULO, PAR_DESCRIP1,PAR_DESCRIP2,PAR_DESCRIP3,PAR_DESCRIP4,PAR_DESCRIP5,PAR_STATUS,PAR_IMPORTE1,PAR_IMPORTE2,PAR_IMPORTE3,PAR_IMPORTE4,PAR_IMPORTE5,PAR_FECHA1, PAR_FECHA2, PAR_FECHA3,PAR_HORA1, PAR_HORA2, PAR_HORA3, PAR_CVEUSU, PAR_FECHOPE, PAR_HORAOPE)
Select PAR_TIPOPARA, '2019' + substring(PAR_IDENPARA,5,4), PAR_IDMODULO, PAR_DESCRIP1,PAR_DESCRIP2,PAR_DESCRIP3,PAR_DESCRIP4,PAR_DESCRIP5,PAR_STATUS,PAR_IMPORTE1,PAR_IMPORTE2,PAR_IMPORTE3,PAR_IMPORTE4,PAR_IMPORTE5,PAR_FECHA1, PAR_FECHA2, PAR_FECHA3,PAR_HORA1, PAR_HORA2, PAR_HORA3, PAR_CVEUSU, PAR_FECHOPE, PAR_HORAOPE from GAZM_Abasto.dbo.PNC_PARAMETR where par_tipopara='MCERRCON' AND substring(PAR_IDENPARA,1,4) = '2018' 

--VIENDO COMO QUEDARON LOS REGISTROS
Select * from GAZM_Abasto.dbo.PNC_PARAMETR where par_tipopara='MCERRCON' AND substring(PAR_IDENPARA,1,4) = '2019' 
*/

CREATE PROCEDURE [dbo].[spU_AbreSiguientePeriodoBPRO_Masivo](@iResultado int OUTPUT) --with recompile
 AS
declare
@sBase varchar(200),
@situa varchar(20),
@sQ nvarchar(1500),
@sParmDefinition nvarchar(500)

begin 
set nocount on


CREATE TABLE #BasesDeDatosEnEsteServidor
(
  POSICION [int] IDENTITY (1, 1), 
  nombreBD varchar(300)
)

insert into #BasesDeDatosEnEsteServidor (nombreBD)
SELECT name FROM sys.databases  where state_desc = 'ONLINE';  

Declare @iIndice int = 1;
Declare @iTope int = 0;
Declare @sAuxFecha varchar(10);
Declare @sHoy varchar(10);
Declare @sAnio varchar(4);
Declare @sMes varchar(2);
Declare @sUltimoDiaMesActual varchar(10);

declare @mydate datetime
set dateformat dmy;
SELECT @mydate = GETDATE();

select @iTope = Isnull(Max(POSICION),0) from #BasesDeDatosEnEsteServidor

--queda en formato dd/mm/yyyy
SELECT @sAuxFecha = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@mydate))-1),DATEADD(mm,1,@mydate)),103) --, 'Primer día del mes siguiente'
select @sAnio = substring(@sAuxFecha,7,4);
select @sMes = substring(@sAuxFecha,4,2);

--print 'fecha del primer dia del mes siguiente:' + @sAuxFecha
--print 'Anio: ' + @sAnio
--print 'Mes: ' + @sMes

SELECT @sUltimoDiaMesActual = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@mydate))),DATEADD(mm,1,@mydate)),103) --, ultimo día del mes actual
SELECT @sHoy = CONVERT(VARCHAR(25),@mydate,103) --AS Date_Value, 'Hoy' AS Date_Type

if (ltrim(rtrim(@sUltimoDiaMesActual)) = ltrim(rtrim(@sHoy)) )
begin
			WHILE  (@iIndice <= @iTope)    ---EXISTS (Select * from #Pagas)		
				 begin
						SET ROWCOUNT 1 
			   				Select @sBase=nombreBD FROM #BasesDeDatosEnEsteServidor where POSICION = @iIndice		     						
	  					SET ROWCOUNT 0                               
						Declare @iErrorLocal int = 0;

						Execute [master].[dbo].[spU_PonSituacionDePeriodoXBase]  @sBase,'ABIERTO',@sAnio,@sMes,@iErrorLocal OUTPUT
						if (@iErrorLocal=0)
						  begin
							print 'Se abrio el periodo: ' + @sBase + ' ' + @sAnio+@sMes 
						  end
						else
						  begin
							print 'No se abrio periodo: ' + @sBase + ' ' + @sAnio + @sMes
						  end
						select @iResultado = @iResultado + @iErrorLocal; 
						select @iIndice = @iIndice + 1; 		    
				 end -- Del while principal sobre cada Base de Datos.
end
 else
   begin
     print 'Hoy: ' + @sHoy + ' no es el último día del mes : ' + @sUltimoDiaMesActual + ' no se hizo nada'
   end
Return @iResultado

set nocount off
end
go

