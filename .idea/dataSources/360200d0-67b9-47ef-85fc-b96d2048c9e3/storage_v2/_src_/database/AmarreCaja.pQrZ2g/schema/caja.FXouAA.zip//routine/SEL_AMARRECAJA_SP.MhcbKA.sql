
-- =============================================
-- Author:		<Uriel Hernandez>
-- Create date: <22/10/2020>
-- Description:	<Obtiene el historial de amarre de caja>
-- =============================================
/*
	-- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [caja].[SEL_AMARRECAJA_SP] @idusuario = 20, @produccion = 0,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;
*/
-- =============================================
CREATE PROCEDURE [caja].[SEL_AMARRECAJA_SP]
	@idUsuario				int,
	@produccion				BIT = 0,
	@err					varchar(max) OUTPUT
AS

BEGIN

	SET @err = '';
	DECLARE @BD VARCHAR(100),
	@Sql NVARCHAR(MAX)

	IF(@produccion = 1)
		BEGIN
			SELECT
			@BD = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 1
		AND nombre = 'bpro'
		END

	ELSE
		BEGIN

			SELECT
				@BD = servidor
			FROM [common].[bpro].[servidorBPRO]
			WHERE idambiente = 2
			AND nombre = 'bpro'
		END

	DECLARE  @sucursales TABLE (idSucursal INT, nombre VARCHAR(100), IP VARCHAR(100), BD VARCHAR(100), observaciones VARCHAR(100),idEmpresa INT, estatus INT)
	DECLARE  @empresas TABLE (idEmpresa INT, nombre VARCHAR(100),observaciones VARCHAR(100),  estatus INT)
	DECLARE @permisos TABLE (idEmpresa INT, idSucursal INT)
	
	INSERT INTO @sucursales 
	EXEC [bpro].[SEL_SUCURSALES_SP] 
		@idUsuario = @idUsuario,
		@produccion  = @produccion,
		@err = ''

	INSERT INTO @empresas 
	EXEC [bpro].[SEL_EMPRESAS_SP]
		@idUsuario = @idUsuario,
		@produccion  = @produccion,
		@err = ''



	SET @Sql = 'select 
					O.EMP_IDEMPRESA,
					O.SUC_IDSUCURSAL
				from seguridad.catalogo.usuario U
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[cat_usuarios] UB ON LTRIM(RTRIM(UB.usu_nombreusu)) = LEFT(username,( CHARINDEX(''@'', USERNAME) -1)) COLLATE Modern_Spanish_CI_AS
				INNER JOIN ' + @BD + '.[ControlAplicaciones].[dbo].[eqv_organigrama] O ON O.usu_usuario = ub.usu_idusuario
				WHERE id = ' +  CAST(@idusuario AS VARCHAR(50)) 
	print @sql
	INSERT INTO @permisos
	EXEC sp_executesql @Sql

	SELECT * FROM(
			SELECT 
				ama.[idSucursal] 
				,(SELECT DISTINCT observaciones FROM @sucursales WHERE idSucursal = ama.idSucursal) sucursal
				,(SELECT DISTINCT idEmpresa FROM @sucursales WHERE idSucursal = ama.idSucursal) AS idEmpresa
				,(SELECT DISTINCT nombre FROM @empresas WHERE idEmpresa = (SELECT idEmpresa FROM  @sucursales  WHERE idSucursal = ama.idSucursal)) empresa
				,(SELECT REPLACE((SUBSTRING(username,1,(CHARINDEX('@',[userName])))),'@','') FROM Seguridad.catalogo.Usuario where id = @idUsuario) AS usuarioBPRO
				,ama.[folio]
				,ama.[fecha]
				,ama.[token]
				,[tihabpc] AS totalIngresadoHoyABancosPorCaja
				,[stipd] AS saldoTotalIngresosPorDepositar
				,[scfdcTotal] AS saldoContableFinalDeCajaTotal
				,[scfdcHoy] AS saldoContableFinalDeCajaHoy
				,[scfdcPendiente] AS saldoContableFinalDeCajaPendiente
				,[dcdcTotal] AS diferenciaContableDeCajaTotal
				,[dcdcHoy] AS diferenciaContableDeCajaHoy
				,[dcdcPendiente] AS diferenciaContableDeCajaPendiente
				,(SELECT REPLACE((SUBSTRING(username,1,(CHARINDEX('@',[userName])))),'@','') FROM Seguridad.catalogo.Usuario where id = AA.idUsuario) AS usuarioContraloria
				,AA.fecha AS fechaContraloria
			FROM [caja].[Amarre] ama 
			LEFT JOIN [caja].[AmarreAprobador] AA ON AA.folio = ama.folio) T
			INNER JOIN @permisos P ON P.idSucursal = T.idSucursal AND P.idEmpresa = T.idEmpresa
			ORDER BY fecha DESC

END

go

