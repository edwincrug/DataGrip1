
-- =============================================
-- Author:		<Antonio Guerra>
-- Create date: <24/10/2020>
-- Description:	<Obtiene sucursales>
-- =============================================
/*
	Fecha		Autor	Descripción 

	*- Testing...
	DECLARE @salida varchar(max) ;
	EXEC [bpro].[SEL_AMARRECAJA_HOY_SP]
	@produccion = 1,
	@idEmpresa = 4,
	@idSucursal = 6,
		@idUsuario = 45,
		@err = @salida OUTPUT;
	SELECT @salida AS salida;

*/

-- =============================================
CREATE PROCEDURE [bpro].[SEL_AMARRECAJA_HOY_SP]
	@produccion				BIT,
	@idEmpresa				INT,
	@idSucursal				INT,
	@idUsuario				int,
	@err					varchar(max) OUTPUT
AS

BEGIN
	SET @err = '';

	DECLARE @tablaDet VARCHAR(100) = 'CON_MOVDET01' + (Select CAST(year(getdate()) AS VARCHAR(50)))
	DECLARE @tablaCtas VARCHAR(100) = 'CON_CTAS01' + (Select CAST(year(getdate()) AS VARCHAR(50)))
	DECLARE @tablaPol VARCHAR(100) = 'CON_POL01' + (Select CAST(year(getdate()) AS VARCHAR(50)))
	DECLARE @tablaCncar VARCHAR(100) = 'CON_CAR01' + (Select CAST(year(getdate()) AS VARCHAR(50)))
	DECLARE @Sql NVARCHAR(MAX);
	DECLARE @SqlAbonos NVARCHAR(MAX);
	DECLARE @server VARCHAR(100),
			@BDSucursal VARCHAR(100),
			@consecutivoCOntable VARCHAR(100)
	DECLARE @ABONOS TABLE (CTA_NUMCTA VARCHAR(100),POL_TIPO VARCHAR(100),MOV_CONCEPTO VARCHAR(250),MOV_HABER FLOAT,mov_fechope VARCHAR(50))
	DECLARE @ANTICIPOSANTERIORES TABLE (CCP_IDDOCTO VARCHAR(100),
										MOV_NUMCTA VARCHAR(100),
										POL_TIPO VARCHAR(100),
										MOV_CONCEPTO VARCHAR(250),
										MOV_DEBE FLOAT,
										MOV_FECHOPE VARCHAR(100),
										DOCUMENTO VARCHAR(100))
	DECLARE @ANTICIPOSHOY TABLE (CCP_IDDOCTO VARCHAR(100),
										MOV_NUMCTA VARCHAR(100),
										POL_TIPO VARCHAR(100),
										MOV_CONCEPTO VARCHAR(250),
										MOV_DEBE FLOAT,
										MOV_FECHOPE VARCHAR(100),
										DOCUMENTO VARCHAR(100))

	IF(@produccion = 1)
		BEGIN
			SELECT
			@server = servidor
		FROM [common].[bpro].[servidorBPRO]
		WHERE idambiente = 1
		AND nombre = 'bpro'
		END

	ELSE
		BEGIN

			SELECT
				@server = servidor
			FROM [common].[bpro].[servidorBPRO]
			WHERE idambiente = 2
			AND nombre = 'bpro'
		END


	DECLARE @sqlCommand NVARCHAR(4000)
	DECLARE @fechaHoy DATE = (SELECT CONVERT(DATE,DATEADD(DAY,-1,GETDATE()),103))
	DECLARE @idEmpresaSTR VARCHAR(5)


	SET @sqlCommand = 'SELECT @consecutivoCOntable = consecutivo_contable, @BDSucursal = nombre_base
	FROM ' +  @server + '.Centralizacionv2.DBO.DIG_CAT_BASES_BPRO 
	WHERE emp_idempresa = @idEmpresa
	AND suc_idsucursal = @idSucursal'
	EXEC sp_executesql @sqlCommand, N'@idEmpresa INT, @idSucursal INT, @consecutivoCOntable VARCHAR(100) OUTPUT, @BDSucursal VARCHAR(100) OUTPUT',
	@idEmpresa = @idEmpresa,@idSucursal = @idSucursal, @consecutivoCOntable = @consecutivoCOntable OUTPUT, @BDSucursal = @BDSucursal OUTPUT

	SET @consecutivoCOntable = (SELECT RIGHT('0000'+ISNULL(@consecutivoCOntable,''),4))
	SET @idEmpresaSTR = (SELECT RIGHT('00'+ISNULL(CAST(@idEmpresa AS VARCHAR(5)),''),2))

	--SET @SQLABONOS = ' SELECT CTA_NUMCTA,POL_TIPO,MOV_CONCEPTO,MOV_HABER,mov_fechope
	--					  FROM ' + @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaCtas) + ' AS CTAS,'
	--								+ @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaPol) + ' AS POL, '
	--								+ @server + '.[GAAU_Concentra].[DBO].'  + QUOTENAME(@tablaDet)+ ' AS DET '
	--					  + ' WHERE CTA_NUMCTA = MOV_NUMCTA 
	--						  AND POL_TIPO = MOV_TIPOPOL 
	--						  AND POL_CONSECUTIVO = MOV_CONSPOL 
	--						  AND POL_MES = MOV_MES 
	--						  AND MOV_NUMCTA = ''1100-0010-' + @consecutivoCOntable + '-0001''
	--						  AND POL_TIPO like (''saldo%'')'

	--print @SQLABONOS

	--INSERT INTO @ABONOS
	--EXEC sp_executesql @SQLABONOS

	----SELECT * FROM @ABONOS


	--/********************************************************** PAGOS HOY ************************************************************/

	-- SET @Sql = ' SELECT 
	--					POL_REFERENCIA1,
	--					CTA_NUMCTA,
	--					POL_TIPO,
	--					MOV_CONCEPTO,
	--					MOV_DEBE,
	--					mov_fechope,
	--					CASE WHEN POL_REFERENCIA1 != '''' THEN POL_REFERENCIA1 ELSE SUBSTRING(MOV_CONCEPTO,CHARINDEX(''.'', MOV_CONCEPTO)+1,11)END DOCUMENTO
	--				FROM ' + @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaCtas) + ' AS CTAS,'
	--						+ @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaPol) + ' AS POL, '
	--						+ @server + '.[GAAU_Concentra].[DBO].'  + QUOTENAME(@tablaDet)+ ' AS DET '
	--				+ ' WHERE CTA_NUMCTA = MOV_NUMCTA 
	--					AND POL_TIPO = MOV_TIPOPOL 
	--					AND POL_CONSECUTIVO = MOV_CONSPOL 
	--					AND POL_MES = MOV_MES 
	--					AND MOV_NUMCTA = ''1100-0010-' + @consecutivoCOntable + '-0001''
	--					AND  CONVERT(DATE,DET.MOV_FECHOPE,103) = ''' + CAST(@fechaHoy AS VARCHAR(50)) 
	--					+ ''' AND POL_TIPO like (''ic%'') '

	--print @sql
	--INSERT INTO @ANTICIPOSHOY
	--EXEC sp_executesql @Sql

	--SELECT 
	--H.*,
	--A.mov_haber ABONO,
	--CASE WHEN A.MOV_HABER IS NULL THEN H.MOV_DEBE ELSE H.MOV_DEBE - A.MOV_HABER END   PENDIENTE,
	--A.MOV_FECHOPE FECHAABONO,
	--CASE WHEN CCP_IDDOCTO = '' THEN DOCUMENTO ELSE '' END FACTURA
	--FROM 
	--@ANTICIPOSHOY H
	--LEFT join @ABONOS A ON A.mov_concepto like '%' + H.DOCUMENTO + '%'
	--ORDER BY CONVERT(DATE,H.MOV_FECHOPE,103)  DESC,DOCUMENTO



	
	--/********************************************************** PAGOS ANTERIORES ************************************************************/

	-- SET @Sql = ' SELECT 
	--					POL_REFERENCIA1,
	--					CTA_NUMCTA,
	--					POL_TIPO,
	--					MOV_CONCEPTO,
	--					MOV_DEBE,
	--					mov_fechope,
	--					CASE WHEN POL_REFERENCIA1 != '''' THEN POL_REFERENCIA1 ELSE SUBSTRING(MOV_CONCEPTO,CHARINDEX(''.'', MOV_CONCEPTO)+1,11)END DOCUMENTO
	--				FROM ' + @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaCtas) + ' AS CTAS,'
	--						+ @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaPol) + ' AS POL, '
	--						+ @server + '.[GAAU_Concentra].[DBO].'  + QUOTENAME(@tablaDet)+ ' AS DET '
	--				+ ' WHERE CTA_NUMCTA = MOV_NUMCTA 
	--					AND POL_TIPO = MOV_TIPOPOL 
	--					AND POL_CONSECUTIVO = MOV_CONSPOL 
	--					AND POL_MES = MOV_MES 
	--					AND MOV_NUMCTA = ''1100-0010-' + @consecutivoCOntable + '-0001''
	--					AND  CONVERT(DATE,DET.MOV_FECHOPE,103) < ''' + CAST(@fechaHoy AS VARCHAR(50)) 
	--					+ ''' AND POL_TIPO like (''ic%'') '

	--print @sql
	--INSERT INTO @ANTICIPOSANTERIORES
	--EXEC sp_executesql @Sql

	--SELECT 
	--H.*,
	--A.mov_haber ABONO,
	--CASE WHEN A.MOV_HABER IS NULL THEN H.MOV_DEBE ELSE H.MOV_DEBE - A.MOV_HABER END   PENDIENTE,
	--A.MOV_FECHOPE FECHAABONO,
	--CASE WHEN CCP_IDDOCTO = '' THEN DOCUMENTO ELSE '' END FACTURA
	--FROM 
	--@ANTICIPOSANTERIORES H
	--LEFT join @ABONOS A ON A.mov_concepto like '%' + H.DOCUMENTO + '%'
	--ORDER BY CONVERT(DATE,H.MOV_FECHOPE,103)  DESC,DOCUMENTO


SET @Sql = 'SELECT DISTINCT 
					DET.MOV_NUMCTA
					,DET.MOV_CONCEPTO
					,DET.MOV_DEBE
					,CONVERT(DATE,DET.MOV_FECHOPE,103) AS MOV_FECHOPE
					,MOVABONO.MOV_HABER AS ABONO
					,MOVABONO.MOV_FECHOPE AS FECHAABONO
					,CASE WHEN MOVABONO.MOV_HABER IS NULL THEN DET.MOV_DEBE ELSE DET.MOV_DEBE - MOVABONO.MOV_HABER END PENDIENTE
					,PAR_DESCRIP1  AS CONCEPTO
					,CASE WHEN CAR.CCP_GRUPO1 = '''' THEN CAR.CCP_IDDOCTO ELSE '''' END CCP_IDDOCTO
					,CAR.CCP_GRUPO1 FACTURA			
				FROM ' + @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaCtas) + ' AS CTAS,'
				+ @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaPol) + ' AS POL, '
				+ @server + '.[GAAU_Concentra].[DBO].'  + QUOTENAME(@tablaDet)+ ' AS DET '
	+ ' LEFT join '  + @server + '.GAAU_Concentra.DBO.' + QUOTENAME(@tablaCncar) +' AS CAR ON CAR.CCP_CONSPOL = det.mov_conspol AND CCP_TIPODOCTO IN (''ANT'', ''PAU'') AND CAR.CCP_FECHOPE = DET.MOV_FECHOPE '
	+ ' LEFT JOIN '  + @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaDet) +' AS MOVABONO ON MOVABONO.MOV_NUMCTA = DET.MOV_NUMCTA AND MOVABONO.MOV_CONCEPTO LIKE ''TRANSFERIR INGRESOS DE CAJA/'' + CAR.CCP_IDDOCTO + ''%'''
	+ ' LEFT JOIN '  + @server + '.' +  @BDSucursal + '.[dbo].[VIS_CONCARTOT01] VC ON VC.CCP_IDDOCTO = CAR.CCP_IDDOCTO AND VC.CCP_TIPODOCTO IN (''ANT'', ''ANTCAN'', ''PAU'') '
	+ ' LEFT JOIN '  + @server + '.' +  @BDSucursal + '.[dbo].[VIS_CONCARDETATOT01] VIS ON VIS.CCD_CONSCARTERA = CAR.CCP_CONSCARTERA AND VIS.VCD_ANNO = VC.VCC_ANNO  AND VIS.CCD_TIPOPAGO IN (''02'',''108'',''109'', ''40'', ''44'',''EF'')  AND VCD_EMPRESA = ' + @idEmpresaSTR 
	+ ' LEFT JOIN '  + @server + '.' +  @BDSucursal + '.[dbo].PNC_PARAMETR P ON  P.PAR_IDENPARA = VIS.CCD_TIPOPAGO AND P.PAR_TIPOPARA = ''FP'''
	+ ' WHERE CONVERT(DATE,DET.MOV_FECHOPE,103) = ''' + CAST(@fechaHoy AS VARCHAR(50)) 
	+ ''' AND  DET.MOV_NUMCTA LIKE ''1100-0010-' + @consecutivoCOntable + '-0001''
		AND CTA_NUMCTA = DET.MOV_NUMCTA 
		AND  POL_TIPO = DET.MOV_TIPOPOL 
		AND  POL_CONSECUTIVO = DET.MOV_CONSPOL 
		AND POL_TIPO = CAR.CCP_TIPOPOL 
		AND  POL_MES = DET.MOV_MES 
		AND car.ccp_iddocto is not null 
		AND DET.MOV_CONCEPTO LIKE ''Fac.%'' 
		ORDER BY CONVERT(DATE,DET.MOV_FECHOPE,103)  DESC,CCP_IDDOCTO, CAR.CCP_GRUPO1  '
	print @sql
	EXEC sp_executesql @Sql

SET @Sql = 'SELECT DISTINCT top 1000
					DET.MOV_NUMCTA
					,DET.MOV_CONCEPTO
					,DET.MOV_DEBE
					,CONVERT(DATE,DET.MOV_FECHOPE,103) AS MOV_FECHOPE
					,MOVABONO.MOV_HABER AS ABONO
					,MOVABONO.MOV_FECHOPE AS FECHAABONO
					,CASE WHEN MOVABONO.MOV_HABER IS NULL THEN DET.MOV_DEBE ELSE DET.MOV_DEBE - MOVABONO.MOV_HABER END PENDIENTE
					,PAR_DESCRIP1  AS CONCEPTO
					,CASE WHEN CAR.CCP_GRUPO1 = '''' THEN CAR.CCP_IDDOCTO ELSE '''' END CCP_IDDOCTO
					,CAR.CCP_GRUPO1 FACTURA			
				FROM ' + @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaCtas) + ' AS CTAS,'
				+ @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaPol) + ' AS POL, '
				+ @server + '.[GAAU_Concentra].[DBO].'  + QUOTENAME(@tablaDet)+ ' AS DET '
	+ ' LEFT join '  + @server + '.GAAU_Concentra.DBO.' + QUOTENAME(@tablaCncar) +' AS CAR ON CAR.CCP_CONSPOL = det.mov_conspol AND CCP_TIPODOCTO IN (''ANT'', ''PAU'') AND CAR.CCP_FECHOPE = DET.MOV_FECHOPE '
	+ ' LEFT JOIN '  + @server + '.[GAAU_Concentra].[DBO].' + QUOTENAME(@tablaDet) +' AS MOVABONO ON MOVABONO.MOV_NUMCTA = DET.MOV_NUMCTA AND CAR.CCP_FECHOPE = MOVABONO.MOV_FECHOPE AND MOVABONO.MOV_CONCEPTO LIKE ''TRANSFERIR INGRESOS DE CAJA/'' + CAR.CCP_IDDOCTO + ''%'''
	+ ' LEFT JOIN '  + @server + '.' +  @BDSucursal + '.[dbo].[VIS_CONCARTOT01] VC ON VC.CCP_IDDOCTO = CAR.CCP_IDDOCTO AND VC.CCP_TIPODOCTO IN (''ANT'', ''ANTCAN'', ''PAU'') '
	+ ' LEFT JOIN '  + @server + '.' +  @BDSucursal + '.[dbo].[VIS_CONCARDETATOT01] VIS ON VIS.CCD_CONSCARTERA = CAR.CCP_CONSCARTERA AND VIS.VCD_ANNO = VC.VCC_ANNO  AND VIS.CCD_TIPOPAGO IN (''02'',''108'',''109'', ''40'', ''44'',''EF'')  AND VCD_EMPRESA = ' + @idEmpresaSTR 
	+ ' LEFT JOIN '  + @server + '.' +  @BDSucursal + '.[dbo].PNC_PARAMETR P ON  P.PAR_IDENPARA = VIS.CCD_TIPOPAGO AND P.PAR_TIPOPARA = ''FP'''
	+ ' WHERE CONVERT(DATE,DET.MOV_FECHOPE,103) < ''' + CAST(@fechaHoy AS VARCHAR(50)) 
	+ ''' AND  DET.MOV_NUMCTA LIKE ''1100-0010-' + @consecutivoCOntable + '-0001''
		AND CTA_NUMCTA = DET.MOV_NUMCTA 
		AND  POL_TIPO = DET.MOV_TIPOPOL 
		AND  POL_CONSECUTIVO = DET.MOV_CONSPOL 
		AND POL_TIPO = CAR.CCP_TIPOPOL 
		AND  POL_MES = DET.MOV_MES 
		AND car.ccp_iddocto is not null 
		AND DET.MOV_CONCEPTO LIKE ''Fac.%'' 
		ORDER BY CONVERT(DATE,DET.MOV_FECHOPE,103)  DESC,CCP_IDDOCTO, CAR.CCP_GRUPO1 '
	print @sql
	EXEC sp_executesql @Sql
END

go

