create view [dbo].[CON_CFDI012018] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012018;
go

