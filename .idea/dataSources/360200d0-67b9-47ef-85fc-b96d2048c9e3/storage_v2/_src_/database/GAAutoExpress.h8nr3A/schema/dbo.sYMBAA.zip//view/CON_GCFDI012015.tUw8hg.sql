create view [CON_GCFDI012015] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012015]
go

