create view [dbo].[CON_CARDETACON012015] as select * from GAAutoexpressConcentra.dbo.CON_CARDETACON012015;
go

