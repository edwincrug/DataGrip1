create view [dbo].[CON_CARCON012015] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012015;
go

