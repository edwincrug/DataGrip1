create view [dbo].[CON_POLFIJ012017] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012017;
go

