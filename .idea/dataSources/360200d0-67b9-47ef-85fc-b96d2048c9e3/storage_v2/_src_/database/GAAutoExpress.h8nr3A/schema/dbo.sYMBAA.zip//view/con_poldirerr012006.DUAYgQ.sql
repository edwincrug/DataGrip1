create view [dbo].[con_poldirerr012006] as select * from GAAutoexpressConcentra.dbo.con_poldirerr012006;
go

