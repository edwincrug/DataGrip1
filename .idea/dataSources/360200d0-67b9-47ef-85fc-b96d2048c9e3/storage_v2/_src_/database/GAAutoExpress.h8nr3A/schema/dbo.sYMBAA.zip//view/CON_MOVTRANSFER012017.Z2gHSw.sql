create view [dbo].[CON_MOVTRANSFER012017] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012017;
go

