create view [dbo].[CON_MOVDETfij012006] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETfij012006;
go

