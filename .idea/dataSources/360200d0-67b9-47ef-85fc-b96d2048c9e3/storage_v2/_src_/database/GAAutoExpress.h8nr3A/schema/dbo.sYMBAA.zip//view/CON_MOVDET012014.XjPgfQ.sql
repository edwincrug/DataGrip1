create view [dbo].[CON_MOVDET012014] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012014;
go

