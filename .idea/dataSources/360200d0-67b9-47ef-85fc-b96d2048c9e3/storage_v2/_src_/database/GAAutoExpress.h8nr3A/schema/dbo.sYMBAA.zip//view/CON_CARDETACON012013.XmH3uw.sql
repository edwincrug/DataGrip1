create view [dbo].[CON_CARDETACON012013] as select * from GAAutoexpressConcentra.dbo.CON_CARDETACON012013;
go

