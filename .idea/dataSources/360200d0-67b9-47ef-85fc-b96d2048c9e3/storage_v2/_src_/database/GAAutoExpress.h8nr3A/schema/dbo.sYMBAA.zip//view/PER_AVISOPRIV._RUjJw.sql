create view [dbo].[PER_AVISOPRIV] as select * from GAAutoexpressConcentra.dbo.PER_AVISOPRIV;
go

