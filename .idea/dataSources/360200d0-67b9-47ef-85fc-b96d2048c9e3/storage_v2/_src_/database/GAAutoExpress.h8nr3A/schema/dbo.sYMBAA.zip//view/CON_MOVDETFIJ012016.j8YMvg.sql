create view [dbo].[CON_MOVDETFIJ012016] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012016;
go

