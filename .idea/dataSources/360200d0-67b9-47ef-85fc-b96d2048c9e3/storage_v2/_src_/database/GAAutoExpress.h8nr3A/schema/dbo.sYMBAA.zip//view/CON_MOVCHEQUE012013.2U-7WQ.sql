create view [dbo].[CON_MOVCHEQUE012013] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012013;
go

