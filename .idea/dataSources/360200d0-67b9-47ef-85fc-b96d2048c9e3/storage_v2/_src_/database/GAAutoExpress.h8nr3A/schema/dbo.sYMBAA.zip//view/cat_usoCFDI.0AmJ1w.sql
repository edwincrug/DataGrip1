create view [dbo].[cat_usoCFDI] as select * from GAAutoexpressConcentra.dbo.cat_usoCFDI;
go

