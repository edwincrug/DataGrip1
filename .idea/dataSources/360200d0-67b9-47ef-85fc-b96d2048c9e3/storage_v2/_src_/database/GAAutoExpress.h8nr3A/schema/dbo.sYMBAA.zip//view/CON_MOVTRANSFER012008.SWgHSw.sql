create view [dbo].[CON_MOVTRANSFER012008] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012008;
go

