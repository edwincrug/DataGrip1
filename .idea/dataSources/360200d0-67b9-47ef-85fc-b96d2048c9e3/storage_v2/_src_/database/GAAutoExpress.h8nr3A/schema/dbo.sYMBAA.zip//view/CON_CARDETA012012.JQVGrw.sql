create view [dbo].[CON_CARDETA012012] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012012;
go

