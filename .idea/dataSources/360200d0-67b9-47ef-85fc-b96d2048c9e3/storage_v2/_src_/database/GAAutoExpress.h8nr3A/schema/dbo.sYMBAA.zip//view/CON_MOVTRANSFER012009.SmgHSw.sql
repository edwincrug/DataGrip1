create view [dbo].[CON_MOVTRANSFER012009] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012009;
go

