create view [dbo].[CON_CARCON012014] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012014;
go

