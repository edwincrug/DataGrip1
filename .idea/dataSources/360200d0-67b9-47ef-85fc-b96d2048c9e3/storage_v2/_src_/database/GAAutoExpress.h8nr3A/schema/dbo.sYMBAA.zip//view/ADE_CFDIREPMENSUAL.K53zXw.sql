create view [dbo].[ADE_CFDIREPMENSUAL] as select * from GAAutoexpressConcentra.dbo.ADE_CFDIREPMENSUAL;
go

