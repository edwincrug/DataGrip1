create view [dbo].[CON_POL012017] as select * from GAAutoexpressConcentra.dbo.CON_POL012017;
go

