create view [dbo].[CON_CARDETA012011] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012011;
go

