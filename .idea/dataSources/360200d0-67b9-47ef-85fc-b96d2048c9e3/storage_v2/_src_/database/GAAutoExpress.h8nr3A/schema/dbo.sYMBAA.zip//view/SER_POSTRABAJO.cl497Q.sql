create view [dbo].[SER_POSTRABAJO] as select * from GAAutoexpressConcentra.dbo.SER_POSTRABAJO;
go

