create view [dbo].[CON_MOVCHEQUE012008] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012008;
go

