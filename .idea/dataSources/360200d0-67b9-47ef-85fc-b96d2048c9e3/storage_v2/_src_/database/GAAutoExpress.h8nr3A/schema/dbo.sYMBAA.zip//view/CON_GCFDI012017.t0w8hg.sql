create view [dbo].[CON_GCFDI012017] as select * from GAAutoexpressConcentra.dbo.CON_GCFDI012017;
go

