create view [CON_GCFDI012012] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012012]
go

