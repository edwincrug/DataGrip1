create view [dbo].[CON_POL012011] as select * from GAAutoexpressConcentra.dbo.CON_POL012011;
go

