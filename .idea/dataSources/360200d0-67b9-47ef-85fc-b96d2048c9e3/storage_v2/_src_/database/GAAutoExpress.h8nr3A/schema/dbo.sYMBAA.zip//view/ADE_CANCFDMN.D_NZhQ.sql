create view [dbo].[ADE_CANCFDMN] as select * from GAAutoexpressConcentra.dbo.ADE_CANCFDMN;
go

