create view [dbo].[CON_POLDIRERR012010] as select * from GAAutoexpressConcentra.dbo.CON_POLDIRERR012010;
go

