create view [dbo].[SER_PQTOTS] as select * from GAAutoexpressConcentra.dbo.SER_PQTOTS;
go

