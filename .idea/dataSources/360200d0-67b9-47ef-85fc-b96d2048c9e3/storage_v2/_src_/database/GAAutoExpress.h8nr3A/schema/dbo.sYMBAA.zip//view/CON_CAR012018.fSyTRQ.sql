create view [dbo].[CON_CAR012018] as select * from GAAutoexpressConcentra.dbo.CON_CAR012018;
go

