create view [dbo].[UNI_PLANBONIDET] as select * from GAAutoexpressConcentra.dbo.UNI_PLANBONIDET;
go

