create view [dbo].[ADE_CANCFD] as select * from GAAutoexpressConcentra.dbo.ADE_CANCFD;
go

