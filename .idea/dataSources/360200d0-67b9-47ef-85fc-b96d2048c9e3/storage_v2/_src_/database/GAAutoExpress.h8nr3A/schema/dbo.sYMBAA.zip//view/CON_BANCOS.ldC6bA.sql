create view [dbo].[CON_BANCOS] as select * from GAAutoexpressConcentra.dbo.CON_BANCOS;
go

