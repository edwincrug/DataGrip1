create view [dbo].[CON_MOVTRANSFER012012] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012012;
go

