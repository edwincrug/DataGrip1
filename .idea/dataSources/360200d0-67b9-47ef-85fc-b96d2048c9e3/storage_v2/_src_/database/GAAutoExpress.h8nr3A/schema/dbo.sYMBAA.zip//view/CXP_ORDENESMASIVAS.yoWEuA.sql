CREATE VIEW [dbo].[CXP_ORDENESMASIVAS] AS SELECT odm_idordenmasiva, odm_idsucursal, odm_idproveedor, odm_areaafectacion, odm_observaciones, odm_tipocomprobante, odm_fechaorden , odm_fechaaplicacion , odm_fechaproceso , odm_estatus , odm_ordencompra , odm_anticipos , odm_cantidadanticipo , odm_porcentajeanticipo , odm_fechaanticipo , odm_sinflujoiva , odm_esseminuevo FROM GAAutoexpressConcentra.dbo.[CXP_ORDENESMASIVAS]
go

