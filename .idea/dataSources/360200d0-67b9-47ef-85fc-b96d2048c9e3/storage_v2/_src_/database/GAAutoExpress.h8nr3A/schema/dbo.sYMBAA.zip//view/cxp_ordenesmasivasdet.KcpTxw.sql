Create View [dbo].[cxp_ordenesmasivasdet] as select * from [GAAutoexpressConcentra].dbo.cxp_ordenesmasivasdet
go

