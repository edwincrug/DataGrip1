create view [dbo].[CON_POLfij012006] as select * from GAAutoexpressConcentra.dbo.CON_POLfij012006;
go

