CREATE procedure Carga_BIMega as                                        
DECLARE @EMPRESA  AS VARCHAR(10),                                        
 @HOY    as datetime                                        
SELECT @EMPRESA = '1'                                        
-- Sustituir la fecha por el dia que se requiere calcular                                        
                  
SELECT @HOY=convert(Varchar(10),getdate(),103)                                        
--SELECT @HOY=CONVERT(datetime,'08/10/2007',103)                                        
                                        
DECLARE @FECHA_ID  as decimal(9, 0),                                        
        @CONSECUTIVO  as int,                                        
 @CONCEPTO1     as varchar(30),                                        
 @CONCEPTO2  AS varchar(30),                                        
 @MONTO1   as decimal(18, 2),                                        
 @MONTO2   as decimal(18, 2),                                        
 @MONTO3   as decimal(18, 2),                                        
 @MONTO4   as decimal(18, 2),                                        
 @MONTO5   as decimal(18, 2),                                        
 @MONTO6   as decimal(18, 2),                               
 @MONTO7   as decimal(18, 2),                                        
 @NMES    as int,                                        
 @NANIO    as int,                                        
 @MES   AS varchar(210),                                        
 @TMPMONTO1   as decimal(18, 2),                                        
 @TMPMONTOCA1   as decimal(18, 2),                                        
 @TMPMONTOCP1   as decimal(18, 2),                                        
 @MONTO1_C   as decimal(18, 2),                                        
 @TMPMONTO1_C   as decimal(18, 2),                                        
 @COSTOHOY1   as decimal(18, 2),                                        
 @COSTOHOYCA1   as decimal(18, 2),                                        
 @COSTOHOYCP1   as decimal(18, 2),                                        
 @COSTOHOY1_C   as decimal(18, 2),                                        
 @TMPMONTO2   as decimal(18, 2),                                        
 @TMPMONTOCA2   as decimal(18, 2),                                        
 @TMPMONTOCP2   as decimal(18, 2),                                        
 @COSTOHOY2   as decimal(18, 2),                                        
 @COSTOHOYCA2   as decimal(18, 2),                                        
 @COSTOHOYCP2   as decimal(18, 2),                                        
 @COSTOHOY2_C   as decimal(18, 2),                                        
 @MONTO2_C   as decimal(18, 2),                                        
 @TMPMONTO2_C   as decimal(18, 2),                                        
 @GRUPO   as varchar(30),                                        
 @COSTOhoySER  as decimal(18, 2),                                        
 @COSTOmesSER   as decimal(18, 2),                                        
 @COSTOhoySER2  as decimal(18, 2),                                        
 @COSTOmesSER2   as decimal(18, 2),                                  
 @MONTOcan   as decimal(18, 2)                                       
                                        
TRUNCATE TABLE BIMega                                        
SELECT @NANIO=datepart(yyyy,@HOY)                                        
SELECT @NMES=datepart(mm,@HOY)                                        
SELECT @mes=case @NMES  when 1 then 'Enero'                                        
       when 2 then 'Febrero'                                        
       when 3 then 'Marzo'                                        
       when 4 then 'Abril'                                        
       when 5 then 'Mayo'                                        
       when 6 then 'Junio'                                        
       when 7 then 'Julio'                                        
     when 8 then 'Agosto'                                        
       when 9 then 'Septiembre'                     
       when 10 then 'Octubre'                                        
       when 11 then 'Noviembre'                                   
       when 12 then 'Diciembre'                                        
END                 
SELECT @FECHA_ID=ISNULL(convert(dec(9),                                        
right('00' + rtrim(convert(char(2),datepart(dd,@HOY))),2)+                                        
right('00' + rtrim(convert(char(2),@NMES)),2)+                                        
convert(char(4),@NANIO)),99)                                        
                                        
-- UNIDADES NUEVAS/ Unidades vendidas en cantidad                          
SELECT @CONSECUTIVO=1,@CONCEPTO1='1.UNIDADES NUEVAS',@CONCEPTO2='1.UNIDADES FACTURADAS (cant)'                                        
-- Venta del dia                                        
 SELECT @MONTO1=count(*),@TMPMONTO1=sum(isnull(VTE_VTABRUT-PEN_ISAN,0)),                                        
 @COSTOHOY1=sum(isnull(VEH_IMPFACTPLAN/1.15,0))                                        
 FROM dbo.ADE_VTAFI,dbo.SER_VEHICULO,dbo.UNI_PEDIUNI                                        
 WHERE convert(datetime,vte_fechdocto)=@HOY                                        
 AND VTE_TIPODOCTO='A'                                        
 AND VEH_NUMSERIE=VTE_SERIE                                        
 AND PEN_IDPEDI=VTE_REFERENCIA1                                        
 IF @@ROWCOUNT=0                                        
  SELECT @MONTO1=0,@TMPMONTO1=0,@COSTOHOY1=0                                        
 SELECT @MONTO1=isnull(@MONTO1,0)                                        
-- Venta mensual                                        
 SELECT @MONTO2=count(*),@TMPMONTO2=sum(isnull(VTE_VTABRUT-PEN_ISAN,0)),                                        
 @COSTOHOY2=sum(isnull(VEH_IMPFACTPLAN/1.15,0))                                        
 FROM dbo.ADE_VTAFI,dbo.SER_VEHICULO,dbo.UNI_PEDIUNI                                        
 WHERE datepart(mm,convert(datetime,vte_fechdocto))=@NMES                                        
 AND   datepart(yyyy,convert(datetime,vte_fechdocto))=@NANIO                                        
 AND VTE_TIPODOCTO='A'                                        
 AND VEH_NUMSERIE=VTE_SERIE                                        
 AND PEN_IDPEDI=VTE_REFERENCIA1                                        
 IF @@ROWCOUNT=0                                        
  SELECT @MONTO2=0,@TMPMONTO2=0,@COSTOHOY2=0                                        
 SELECT @MONTO2=isnull(@MONTO2,0)                                        
                                        
SELECT @MONTO3=0                                        
SELECT @MONTO4=0                                        
SELECT @MONTO5=0                                        
SELECT @MONTO6=0                                        
SELECT @MONTO7=0                              
INSERT INTO BIMega                                        
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                        
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                        
                                        
--------------------CANCELACIONES ACTUALES                                        
    
SELECT @CONSECUTIVO=@CONSECUTIVO+1,@CONCEPTO1='1.UNIDADES NUEVAS',@CONCEPTO2='1.1.CANCELADAS ACTUALES (cant)'                                        
 SELECT @MONTO1=count(*),    
        @TMPMONTOCA1=isnull(sum(isnull(VTE_VTABRUT-PEN_ISAN,0)),0),                                        
        @COSTOHOYCA1=isnull(sum(isnull(VEH_IMPFACTPLAN/1.15,0)),0)                                        
 FROM dbo.ADE_VTAFI,dbo.SER_VEHICULO,dbo.UNI_PEDIUNI                                        
 WHERE convert(datetime,vte_fechdocto)=@hoy                                        
 AND   convert(datetime,vte_fechope)=@hoy                                        
 AND VTE_TIPODOCTO='A'                                        
 AND VTE_STATUS='C'                                        
 AND VEH_NUMSERIE=VTE_SERIE                                        
 AND PEN_IDPEDI=VTE_REFERENCIA1                                        
 IF @@ROWCOUNT=0                                        
  SELECT @MONTO1=0,@TMPMONTOCA1=0,@COSTOHOYCA1=0                                        
 SELECT @MONTO1=isnull(@MONTO1,0)                                        
                                        
 SELECT @MONTO2=count(*),    
 @TMPMONTOCA2=isnull(sum(isnull(VTE_VTABRUT-PEN_ISAN,0)),0),                                        
  @COSTOHOYCA2=isnull(sum(isnull(VEH_IMPFACTPLAN/1.15,0)),0)                                        
 FROM dbo.ADE_VTAFI,dbo.SER_VEHICULO,dbo.UNI_PEDIUNI                                        
 WHERE datepart(mm,convert(datetime,vte_fechdocto))=@NMES                                        
 AND   datepart(yyyy,convert(datetime,vte_fechdocto))=@NANIO                                        
 AND   datepart(mm,convert(datetime,vte_fechope))=@NMES                                        
 AND   datepart(yyyy,convert(datetime,vte_fechope))=@NANIO                   
 AND VTE_TIPODOCTO='A'                                        
 AND VTE_STATUS='C'                                        
 AND VEH_NUMSERIE=VTE_SERIE                                        
 AND PEN_IDPEDI=VTE_REFERENCIA1                                        
 IF @@ROWCOUNT=0                                       
  SELECT @MONTO2=0,@TMPMONTOCA2=0,@COSTOHOYCA2=0                                        
 SELECT @MONTO2=isnull(@MONTO2,0)                                        
                                        
SELECT @MONTO1=-1*@MONTO1                                        
SELECT @MONTO2=-1*@MONTO2                                        
SELECT @MONTO3=0                                        
SELECT @MONTO4=0                                        
SELECT @MONTO5=0                                        
SELECT @MONTO6=0                                  
SELECT @MONTO7=0                                  
INSERT INTO BIMega                                        
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                        
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                        
                                        
--CANCELADAS ANTERIORES                                        
SELECT @CONSECUTIVO=@CONSECUTIVO+1,@CONCEPTO1='1.UNIDADES NUEVAS',@CONCEPTO2='1.2.CANCELADAS ANTERIORES (cant)'                                        
 SELECT @MONTO1=count(*),@TMPMONTOCP1=sum(isnull(VTE_VTABRUT-PEN_ISAN,0)),                                        
 @COSTOHOYCP1=sum(isnull(VEH_IMPFACTPLAN/1.15,0))                                        
 FROM dbo.ADE_VTAFI,dbo.SER_VEHICULO,dbo.UNI_PEDIUNI                         
 WHERE convert(datetime,vte_fechdocto)<>@hoy                                        
 AND   convert(datetime,vte_fechope)=@hoy                                        
 AND VTE_TIPODOCTO='A'                                        
 AND VTE_STATUS='C'                                        
 AND VEH_NUMSERIE=VTE_SERIE                                        
 AND PEN_IDPEDI=VTE_REFERENCIA1                                        
 IF @@ROWCOUNT=0                                        
  SELECT @MONTO1=0,@TMPMONTOCP1=0,@COSTOHOYCP1=0                                        
 SELECT @MONTO1=isnull(@MONTO1,0)                                        
                                        
 SELECT @MONTO2=count(*),@TMPMONTOCP2=sum(isnull(VTE_VTABRUT-PEN_ISAN,0)),                                        
 @COSTOHOYCP2=sum(isnull(VEH_IMPFACTPLAN/1.15,0))                             
 FROM dbo.ADE_VTAFI,dbo.SER_VEHICULO,dbo.UNI_PEDIUNI                                        
 WHERE datepart(mm,convert(datetime,vte_fechdocto))<>@NMES                                 
 AND   datepart(mm,convert(datetime,vte_fechope))=@NMES                                        
 AND   datepart(yyyy,convert(datetime,vte_fechope))=@NANIO                                        
 AND VTE_TIPODOCTO='A'                                        
 AND VTE_STATUS='C'                            
 AND VEH_NUMSERIE=VTE_SERIE                                        
 AND PEN_IDPEDI=VTE_REFERENCIA1                                        
 IF @@ROWCOUNT=0                                        
  SELECT @MONTO2=0,@TMPMONTOCP2=0,@COSTOHOYCP2=0                                        
 SELECT @MONTO2=isnull(@MONTO2,0)                                        
      
SELECT @MONTO1=-1*@MONTO1                                        
SELECT @MONTO2=-1*@MONTO2                                        
SELECT @MONTO3=0                                        
SELECT @MONTO4=0                                        
SELECT @MONTO5=0                                        
SELECT @MONTO6=0                                        
SELECT @MONTO7=0                                        
INSERT INTO BIMega                                        
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                        
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                        
                                        
------------------------------------------------                                    
-- UNIDADES NUEVAS/ Unidades vendidas en pesos                                        
SELECT @CONCEPTO1='1.UNIDADES NUEVAS',@CONCEPTO2='2.UNIDADES FACTURADAS $'                                        
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                        
SELECT @MONTO1=@TMPMONTO1                                        
SELECT @MONTO2=@TMPMONTO2 - @TMPMONTOCA2                                  
SELECT @MONTO3=@TMPMONTO1-@COSTOHOY1                                        
SELECT @MONTO4=(@TMPMONTO2-@COSTOHOY2)-(@TMPMONTOCA2-@COSTOHOYCA2)                            
SELECT @MONTO5=0                                        
SELECT @MONTO6=0                                        
SELECT @MONTO7=0                                        
INSERT INTO BIMega                                        
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                        
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                        
                                        
--------------------CANCELACIONES ACTUALES $                                        
SELECT @CONCEPTO1='1.UNIDADES NUEVAS',@CONCEPTO2='2.1.CANCELADAS ACTUALES $'                                        
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                        
SELECT @MONTO1=-1*@TMPMONTOCA1                                        
SELECT @MONTO2=-1*@TMPMONTOCA2                                        
SELECT @MONTO3=-1*(@TMPMONTOCA1-@COSTOHOYCA1)                                        
SELECT @MONTO4=-1*(@TMPMONTOCA2-@COSTOHOYCA2)                                       
SELECT @MONTO5=0                                        
SELECT @MONTO6=0                                        
SELECT @MONTO7=0                                        
INSERT INTO BIMega                                        
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                        
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                        
                                        
--------------------CANCELACIONES ANTERIORES $                                        
SELECT @CONCEPTO1='1.UNIDADES NUEVAS',@CONCEPTO2='2.2.CANCELADAS ANTERIORES $'                                        
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                   
SELECT @MONTO1=-1*@TMPMONTOCP1                                        
SELECT @MONTO2=-1*@TMPMONTOCP2                                        
SELECT @MONTO3=-1*(@TMPMONTOCP1-@COSTOHOYCP1)                                        
SELECT @MONTO4=-1*(@TMPMONTOCP2-@COSTOHOYCP2)                                        
SELECT @MONTO5=0                                        
SELECT @MONTO6=0                                        
SELECT @MONTO7=0                                        
INSERT INTO BIMega                                        
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                        
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                        
      
      
                                                        
-------------------------------- REFACCIONES                                                
if exists (select * from dbo.sysobjects where id =                                          
--object_id(N'[dbo].[DIAVENTAS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)                           
object_id(N'[DIAVENTAS]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)                           
DROP TABLE DIAVENTAS                                   
CREATE TABLE [DIAVENTAS] (                              
 [orden] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vte_docto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vte_status] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [cliente] [varchar] (350) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vendedor] [varchar] (350) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [par_descrip1] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vte_fechdocto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vte_iva] [decimal](18, 5) NULL ,                              
 [vte_total] [decimal](18, 5) NULL ,                              
 [factor] [numeric](18, 0) NULL ,                              
 [costo] [decimal](18, 5) NULL ,                              
 [almacen] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [descuento] [decimal](18, 5) NULL ,                              
 [pordes] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [cveusu] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [fechope] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [horaope] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [tipodocto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [docto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL                               
) ON [PRIMARY]                              
                              
--Inserto primero todas la facturas emitidas por el departamento de refacciones no me importa el status                              
insert into DIAVENTAS                              
select case when substring(vte_docto,1,1) in ('s','c') then isnull(vte_referencia1,'') else isnull(vte_referencia2,'') end as orden,                               
substring(vte_docto,1,1) + convert(varchar,convert(int,substring(vte_docto,2,(len(vte_docto))))) as vte_docto, vte_status,                               
rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)) as cliente, ''                               
as vendedor, mov.par_descrip1, vte_fechdocto, sum(mod_impiva) as vte_iva, sum(mod_total) as vte_total, -1 as factor,                               
sum(mod_cunprom * mod_cantidad) as costo, alm.par_descrip1 as almacen, sum (mod_descto1) as descuento, '' as pordes,                               
'MEGA', convert(varchar(10),getdate(),103), convert(varchar(8),getdate(),108),vte_tipodocto,vte_docto                               
from ade_vtafi, par_movtos, par_movdet, per_personas as a, pnc_parametr mov, pnc_parametr alm                               
where mov_tipomov = mod_tipomov and mov_numero = mod_numero and mov_tipomov = vte_referencia1 and convert(varchar, mov_numero) = vte_referencia2                               
and vte_idcliente = a.per_idpersona and mov.par_tipopara = 'mp' and substring(mov.par_descrip2,1,1) = 'v' and mov_tipomov = mov.par_idenpara                               
and alm.par_tipopara = 'sa' and mod_idalmacen = alm.par_idenpara                               
AND datepart(mm,convert(datetime,vte_fechdocto))=@NMES                                                
AND datepart(yyyy,convert(datetime,vte_fechdocto))=@NANIO                                     
and vte_status <> '' and vte_docto = mov_refer1 group by vte_docto, vte_status, rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)),                               
vte_fechdocto, mov.par_descrip1, vte_total, vte_referencia1,                               
vte_referencia2, alm.par_descrip1, vte_tipodocto, vte_docto order by vte_docto, vte_status,rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno))                              
                              
--Se insertan las facturas de de refacciones emitidas por el departemento de servicio                              
insert into DIAVENTAS                              
select case when substring(vte_docto,1,1) in ('s','c') then isnull(vte_referencia1,'') else isnull(vte_referencia2,'') end as orden,                               
substring(vte_docto,1,1) + convert(varchar,convert(int,substring(vte_docto,2,(len(vte_docto))))) as vte_docto, vte_status,                              
rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)) as cliente, ''                               
as vendedor, mov.par_descrip1, vte_fechdocto, sum(mod_impiva) as vte_iva, sum(mod_total) as vte_total, -1 as factor,                               
sum(mod_cunprom * mod_cantidad) as costo, alm.par_descrip1 as almacen, sum (mod_descto1) as descuento, '' as pordes,                               
'MEGA', convert(varchar(10),getdate(),103), convert(varchar(8),getdate(),108),vte_tipodocto,vte_docto                               
from ade_vtafi, par_movtos, par_movdet, per_personas as a, pnc_parametr mov, pnc_parametr alm                               
where vte_referencia1 = mov_refer3 and vte_docto = mov_refer1 and mov_tipomov = mod_tipomov and mov_numero = mod_numero and                               
mov_tipomov = mov.par_idenpara and vte_idcliente = a.per_idpersona                               
and mov.par_tipopara = 'mp' and substring(mov.par_descrip2,1,1) = 'v' and alm.par_tipopara = 'sa' and mod_idalmacen = alm.par_idenpara                               
and vte_docto like 's%'AND datepart(mm,convert(datetime,vte_fechdocto))=@NMES AND datepart(yyyy,convert(datetime,vte_fechdocto))=@NANIO                                     
group by vte_docto, vte_status, rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)),                              
vte_fechdocto, mov.par_descrip1, vte_total, vte_referencia1,                               
vte_referencia2, alm.par_descrip1, vte_tipodocto, vte_docto order by vte_docto, vte_status,rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno))                              
                    
if exists (select * from dbo.sysobjects where id =                                          
object_id(N'[FACORDREFDES]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)                                          
DROP TABLE FACORDREFDES                               
CREATE TABLE [FACORDREFDES] (                              
 [orden] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vte_docto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [factor] [numeric](18, 0) NULL ,                              
 [cliente] [varchar] (350) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vendedor] [varchar] (350) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vte_status] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [movimiento] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [almacen] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [fechope] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [tipodocto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [docto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [cveusu] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [descuento] [decimal](18, 5) NULL ,                              
 [iva] [decimal](18, 5) NULL                               
) ON [PRIMARY]                              
                              
insert into facordrefdes                               
select a.orden, a.vte_docto, a.factor,a.cliente,a.vendedor,a.vte_status,a.par_descrip1, a.almacen, a.fechope, a.tipodocto, a.docto,                               
'MEGA', 0, 0 from diaventas as a, pnc_parametr where substring(orden,1,1) = par_idenpara and par_tipopara = 'to' and                               
cveusu = 'MEGA' and a.factor = '-1'                              
                              
update diaventas                               
set diaventas.vte_total = diaventas.vte_total + (select sum(vtd_preciounitario)                               
from ade_vtafi as b, ade_vtafidet, facordrefdes as a       where diaventas.tipodocto = a.tipodocto and diaventas.docto = a.docto and diaventas.factor = '-1' and b.vte_tipodocto = vtd_tipodocto and                               
b.vte_docto = vtd_iddocto and b.vte_tipodocto = a.tipodocto and b.vte_docto = a.docto                               
and vtd_tipodocto = a.tipodocto and vtd_iddocto = a.docto  and vtd_clasific = 'red' and a.cveusu = 'MEGA' and                               
diaventas.cveusu = a.cveusu                               
group by a.orden, a.vte_docto, a.factor, a.cliente, a.vendedor,a.vte_status,a.movimiento, a.almacen, a.fechope, a.tipodocto, a.docto)                               
from ade_vtafi as b, facordrefdes as a,ade_vtafidet                               
where diaventas.tipodocto = a.tipodocto and diaventas.docto = a.docto and b.vte_tipodocto = vtd_tipodocto and                               
b.vte_docto = vtd_iddocto and b.vte_tipodocto = a.tipodocto and b.vte_docto = a.docto                               
and vtd_tipodocto = a.tipodocto and vtd_iddocto = a.docto  and vtd_clasific = 'red' and a.cveusu = 'MEGA'                              
and diaventas.cveusu = a.cveusu and diaventas.factor = '-1'                              
                              
update diaventas                              
set diaventas.vte_iva= diaventas.vte_iva + (select round((sum(vtd_preciounitario) * b.vte_ivaplicado) / 100,2)                               
from ade_vtafi as b, ade_vtafidet, facordrefdes as a                               
where diaventas.tipodocto = a.tipodocto and diaventas.docto = a.docto and diaventas.factor = '-1' and b.vte_tipodocto = vtd_tipodocto and                               
b.vte_docto = vtd_iddocto and b.vte_tipodocto = a.tipodocto and b.vte_docto = a.docto                               
and vtd_tipodocto = a.tipodocto and vtd_iddocto = a.docto  and vtd_clasific = 'red' and a.cveusu = 'MEGA' and                               
diaventas.cveusu = a.cveusu group by a.orden, a.vte_docto, a.factor, a.cliente, a.vendedor,a.vte_status,a.movimiento,                               
a.almacen, a.fechope, a.tipodocto, a.docto,b.vte_ivaplicado)                               
from ade_vtafi as b, facordrefdes as a,ade_vtafidet                         
where diaventas.tipodocto = a.tipodocto and diaventas.docto = a.docto and b.vte_tipodocto = vtd_tipodocto and                               
b.vte_docto = vtd_iddocto and b.vte_tipodocto = a.tipodocto and b.vte_docto = a.docto                               
and vtd_tipodocto = a.tipodocto and vtd_iddocto = a.docto  and vtd_clasific = 'red' and a.cveusu = 'MEGA' and                               
diaventas.cveusu = a.cveusu and diaventas.factor = '-1'                              
                              
--Ahora se insertan las devoluciones por parte del departamento de refacciones y servicio                              
insert into diaventas                               
select case when substring(I.vte_docto,1,1) in ('s','c') then isnull(I.vte_referencia1,'') else isnull(I.vte_referencia2,'') end as orden,                               
substring(I.vte_docto,1,1) + convert(varchar,convert(int,substring(I.vte_docto,2,(len(I.vte_docto))))) as vte_docto, I.vte_status,                               
rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)) as cliente, '',                               
mov.par_descrip1, C.vte_fechdocto, sum(mod_impiva) as vte_iva, sum(mod_total) as vte_total, 1 as factor,                               
sum(mod_cunprom * mod_cantidad) as costo, alm.par_descrip1 as almacen, sum (mod_descto1) as descuento, '' as pordes,                               
'MEGA', convert(varchar(10),getdate(),103), convert(varchar(8),getdate(),108),I.vte_tipodocto,I.vte_docto                               
from ade_vtafi as I, ade_vtafi as C, par_movtos, par_movdet, per_personas as a, pnc_parametr mov, pnc_parametr alm                               
where mov_tipomov = mod_tipomov and mov_numero = mod_numero and I.vte_docto = mov_refer1 and I.vte_docto = C.vte_referencia3 and                               
C.vte_referencia3 = I.vte_docto and I.vte_idcliente = a.per_idpersona and mov.par_tipopara = 'mp'                               
and mov_tipomov = mov.par_idenpara and alm.par_tipopara = 'sa' and mod_idalmacen = alm.par_idenpara                               
and mov_tipomov in (select  par_descrip3 from pnc_parametr where par_tipopara = 'mp' and par_status = 'a' and substring(par_descrip2,1,1) = 'v')                              
AND datepart(mm,convert(datetime,C.vte_fechdocto))=@NMES AND datepart(yyyy,convert(datetime,C.vte_fechdocto))=@NANIO                               
and I.vte_status = 'c' group by I.vte_docto, I.vte_status, rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)),                               
C.vte_fechdocto, mov.par_descrip1, I.vte_total, I.vte_referencia1,                               
I.vte_referencia2, alm.par_descrip1, I.vte_tipodocto, I.vte_docto  order by vte_docto, I.vte_status, rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)),                               
C.vte_fechdocto, mov.par_descrip1                              
                              
if exists (select * from dbo.sysobjects where id =                                          
object_id(N'[FACORDREFDES]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)                                          
DROP TABLE FACORDREFDES                               
CREATE TABLE [FACORDREFDES] (                        
 [orden] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vte_docto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [factor] [numeric](18, 0) NULL ,                              
 [cliente] [varchar] (350) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vendedor] [varchar] (350) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [vte_status] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [movimiento] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [almacen] [varchar] (60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [fechope] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                      
 [tipodocto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [docto] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [cveusu] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,                              
 [descuento] [decimal](18, 5) NULL ,                              
 [iva] [decimal](18, 5) NULL                     
) ON [PRIMARY]                              
                              
insert into facordrefdes                               
select a.orden, a.vte_docto, a.factor,a.cliente,a.vendedor,a.vte_status,a.par_descrip1, a.almacen, a.fechope, a.tipodocto, a.docto,                               
'MEGA', 0, 0 from par_diaventas as a, pnc_parametr where substring(orden,1,1) = par_idenpara and par_tipopara = 'to' and                               
cveusu = 'MEGA' and a.factor = '1'                              
                              
update diaventas                               
set diaventas.vte_total = diaventas.vte_total + (select sum(vtd_preciounitario)                               
from ade_vtafi as b, ade_vtafidet,facordrefdes as a                               
where diaventas.tipodocto = a.tipodocto and diaventas.docto = a.docto and diaventas.factor = '1' and b.vte_tipodocto = vtd_tipodocto and                               
b.vte_docto = vtd_iddocto and b.vte_tipodocto = a.tipodocto and b.vte_docto = a.docto                               
and vtd_tipodocto = a.tipodocto and vtd_iddocto = a.docto  and vtd_clasific = 'red' and a.cveusu = 'MEGA' and                               
diaventas.cveusu = a.cveusu                               
group by a.orden, a.vte_docto, a.factor, a.cliente, a.vendedor,a.vte_status,a.movimiento, a.almacen, a.fechope, a.tipodocto, a.docto)                               
from ade_vtafi as b, facordrefdes as a,ade_vtafidet                               
where diaventas.tipodocto = a.tipodocto and diaventas.docto = a.docto and b.vte_tipodocto = vtd_tipodocto and                               
b.vte_docto = vtd_iddocto and b.vte_tipodocto = a.tipodocto and b.vte_docto = a.docto                               
and vtd_tipodocto = a.tipodocto and vtd_iddocto = a.docto  and vtd_clasific = 'red' and a.cveusu = 'MEGA'                              
and diaventas.cveusu = a.cveusu and diaventas.factor = '1'                              
                              
update diaventas                               
set diaventas.vte_iva= diaventas.vte_iva + (select round((sum(vtd_preciounitario) * b.vte_ivaplicado) / 100,2)                               
from ade_vtafi as b, ade_vtafidet, facordrefdes as a                               
where diaventas.tipodocto = a.tipodocto and diaventas.docto = a.docto and diaventas.factor = '1' and b.vte_tipodocto = vtd_tipodocto and                               
b.vte_docto = vtd_iddocto and b.vte_tipodocto = a.tipodocto and b.vte_docto = a.docto                               
and vtd_tipodocto = a.tipodocto and vtd_iddocto = a.docto and vtd_clasific = 'red' and a.cveusu = 'MEGA' and                               
diaventas.cveusu = a.cveusu group by a.orden, a.vte_docto, a.factor, a.cliente, a.vendedor,a.vte_status,a.movimiento,                               
a.almacen, a.fechope, a.tipodocto, a.docto,b.vte_ivaplicado)                               
from ade_vtafi as b, facordrefdes as a,ade_vtafidet                               
where diaventas.tipodocto = a.tipodocto and diaventas.docto = a.docto and b.vte_tipodocto = vtd_tipodocto and                               
b.vte_docto = vtd_iddocto and b.vte_tipodocto = a.tipodocto and b.vte_docto = a.docto                               
and vtd_tipodocto = a.tipodocto and vtd_iddocto = a.docto  and vtd_clasific = 'red' and a.cveusu = 'MEGA' and                
diaventas.cveusu = a.cveusu and diaventas.factor = '1'                              
                              
insert into diaventas                               
select case when substring(I.vte_docto,1,1) in ('s','c') then isnull(I.vte_referencia1,'') else isnull(I.vte_referencia2,'') end as orden,                               
substring(I.vte_docto,1,1) + convert(varchar,convert(int,substring(I.vte_docto,2,(len(I.vte_docto))))) as vte_docto, I.vte_status,                               
rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)) as cliente, '',                               
mov.par_descrip1, C.vte_fechdocto, sum(mod_impiva) as vte_iva, sum(mod_total) as vte_total, 1 as factor,                               
sum(mod_cunprom * mod_cantidad) as costo, alm.par_descrip1 as almacen, sum (mod_descto1) as descuento, '' as pordes,                    
'MEGA', convert(varchar(10),getdate(),103), convert(varchar(8),getdate(),108),I.vte_tipodocto,I.vte_docto                               
from ade_vtafi as I, ade_vtafi as C, par_movtos, par_movdet, per_personas as a, pnc_parametr mov, pnc_parametr alm                               
where mov_tipomov = mod_tipomov and mov_numero = mod_numero and I.vte_docto = mov_refer1 and I.vte_docto = C.vte_referencia3 and                               
C.vte_referencia3 = I.vte_docto and I.vte_idcliente = a.per_idpersona and mov.par_tipopara = 'mp'                               
and mov_tipomov = mov.par_idenpara and alm.par_tipopara = 'sa' and mod_idalmacen = alm.par_idenpara                               
and mov_tipomov in (select  par_descrip3 from pnc_parametr where par_tipopara = 'mp' and par_status = 'a' and substring(par_descrip2,1,1) = 'v')                   
AND datepart(mm,convert(datetime,C.vte_fechdocto))=@NMES AND datepart(yyyy,convert(datetime,C.vte_fechdocto))=@NANIO                              
and convert(varchar,mov_tipomov) = C.vte_referencia1 and convert(varchar,mov_numero) = C.vte_referencia2 and I.vte_status = 'i'                               
group by I.vte_docto, I.vte_status, rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)),                               
C.vte_fechdocto, mov.par_descrip1, I.vte_total, I.vte_referencia1,                               
I.vte_referencia2, alm.par_descrip1, I.vte_tipodocto, I.vte_docto  order by vte_docto, I.vte_status, rtrim(ltrim(a.per_nomrazon + ' ' + a.per_paterno + ' ' + a.per_materno)),                               
C.vte_fechdocto, mov.par_descrip1                              
                              
update diaventas                              
set vte_total=vte_total*-1, vte_iva=vte_iva*-1,costo=costo*-1                              
where factor=1                              
                              
update diaventas                              
set costo=costo*-1                              
where factor=-1                              
                              
SELECT @CONCEPTO1='2.REFACCIONES',@CONCEPTO2='REFACCIONES'                                                
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                                
                                  
SELECT @MONTO4=0                                  
                                  
-- Venta del dia                                                
                                              
select @MONTO1=sum(vte_total)  from diaventas as a ,pnc_parametr as b                              
where a.par_descrip1 =b.par_descrip1                              
and  b.par_tipopara='MP'                               
and (b.par_descrip2='VM' or b.par_descrip2='DV'or par_descrip2='VT' or par_descrip2='DT')                              
AND convert(datetime,vte_fechdocto,103)=@HOY                                 
                                  
IF @@ROWCOUNT=0                                      
SELECT @MONTO1=0                                                
                                  
-- Venta del mes                                                
                                  
SELECT @MONTO2=0, @MONTO5=0                                   
                              
select @MONTO2=sum(vte_total)  from diaventas as a ,pnc_parametr as b                              
where a.par_descrip1 =b.par_descrip1                              
and  b.par_tipopara='MP'                               
and (b.par_descrip2='VM' or b.par_descrip2='DV'or par_descrip2='VT' or par_descrip2='DT')                              
AND datepart(mm,convert(datetime,vte_fechdocto))=@NMES                                                
AND datepart(yyyy,convert(datetime,vte_fechdocto))=@NANIO                             
                                              
IF @@ROWCOUNT=0                                                
 SELECT @MONTO2=0                                    
                                                
-- Utilidades del dia         
select @COSTOHOY1=sum(costo)  from diaventas as a ,pnc_parametr as b                              
where a.par_descrip1 =b.par_descrip1                              
and  b.par_tipopara='MP'                               
and (b.par_descrip2='VM' or b.par_descrip2='DV'or par_descrip2='VT' or par_descrip2='DT')                              
AND convert(datetime,vte_fechdocto)=@HOY                                              
                                              
IF @@ROWCOUNT=0                                                
 SELECT @COSTOHOY1=0                                                
SELECT @MONTO3=@MONTO1-@COSTOHOY1                                                
                              
-- Utilidades del mes                                                
select @COSTOHOY2=sum(costo)  from diaventas as a ,pnc_parametr as b                              
where a.par_descrip1 =b.par_descrip1                              
and  b.par_tipopara='MP'           
and (b.par_descrip2='VM' or b.par_descrip2='DV'or par_descrip2='VT' or par_descrip2='DT')                              
AND datepart(mm,convert(datetime,vte_fechdocto))=@NMES                                                
AND datepart(yyyy,convert(datetime,vte_fechdocto))=@NANIO                                      
                                              
IF @@ROWCOUNT=0                                                
 SELECT @COSTOHOY2=0                                                
SELECT @MONTO4=@MONTO2-@COSTOHOY2                                                          
SELECT @MONTO5=0                                                
SELECT @MONTO6=0                                                
SELECT @MONTO7=0                                                
INSERT INTO BIMega                                                
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                                
                                                           
-- VER SI FALTA AGREGAR LA VENTA DE REFACCIONES POR SERVICIO                                                
                         
-- SERVICIO / Mano de obra                                        
SELECT @CONCEPTO1='3.SERVICIO',@CONCEPTO2='1.MANO DE OBRA'                                                
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                                
-- VENTA DEL DIA                                            
                                           
sELECT @MONTO1=isnull(sum(ISNULL(VTD_PRECIOUNITARIO,0)),0)                                            
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto not LIKE  'C%'                                                
AND vtd_CLASIFIC not in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                           
AND VTE_tipodocTO=VTD_tipodocTO                                             
AND convert(datetime,VTE_FECHDOCTO)=@HOY                                          
AND ORd_clasific IN ('MO','TT')                                                     
IF @@ROWCOUNT=0                                                
SELECT @MONTO1=0                                              
                               
             
sELECT @MONTOcan=isnull(sum(ISNULL(VTD_PRECIOUNITARIO,0)),0)                                            
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto  LIKE  'C%'             
AND vtd_CLASIFIC not in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                               
AND VTE_tipodocTO=VTD_tipodocTO                                             
AND convert(datetime,VTE_FECHDOCTO)=@HOY                                          
AND ORd_clasific IN ('MO','TT')                                                     
IF @@ROWCOUNT=0                                                
SELECT @MONTOcan=0                                              
                                          
                                    
SELECT @MONTO1= @MONTO1 - @MONTOcan                                          
                                           
-- VENTA DEL MES                                     
sELECT @MONTO2=isnull(sum(ISNULL(VTD_PRECIOUNITARIO,0)),0)                                            
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto not LIKE  'C%'                                               
AND vtd_CLASIFIC not in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                               
AND VTE_tipodocTO=VTD_tipodocTO                                             
 AND datepart(mm,convert(datetime,VTE_FECHDOCTO))=@NMES                                                
 AND datepart(yyyy,convert(datetime,VTE_FECHDOCTO))=@NANIO                                                
AND ORd_clasific IN ('MO','TT')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @MONTO2=0                                             
                                          
sELECT @MONTOcan=isnull(sum(ISNULL(VTD_PRECIOUNITARIO,0)),0)                                               
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto  LIKE  'C%'                                              
AND vtd_CLASIFIC not in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                              
AND VTE_tipodocTO=VTD_tipodocTO                                              
 AND datepart(mm,convert(datetime,VTE_FECHDOCTO))=@NMES                                                
 AND datepart(yyyy,convert(datetime,VTE_FECHDOCTO))=@NANIO                                       
AND ORd_clasific IN ('MO','TT')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @MONTOcan=0                                            
                                          
SELECT @MONTO2=@MONTO2-@MONTOcan                                          
                         
   -- UTILIDADES DEL DIA Y DEL MES                                               
-- utilidad DEL DIA                                                
 SELECT @COSTOhoySER=isnull(sum(ISNULL(VTD_costo,0)),0)                                              
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                      
and VTE_docto not LIKE  'C%'                                                
AND vtd_CLASIFIC not in('RE','RED')                             
and VTD_PRECIOUNITARIO>0                                            
AND VTE_tipodocTO=VTD_tipodocTO                                                
 AND convert(datetime,VTE_FECHDOCTO)=@HOY                                                
AND ORd_clasific IN ('MO','TT')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @COSTOhoySER=0                              
                 
                                          
SELECT @MONTOcan=isnull(sum(ISNULL(VTD_costo,0)),0)                                                
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto  LIKE  'C%'                                                
AND vtd_CLASIFIC not in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                             
AND VTE_tipodocTO=VTD_tipodocTO                                               
 AND convert(datetime,VTE_FECHDOCTO)=@HOY                                                
AND ORd_clasific IN ('MO','TT')                               
 IF @@ROWCOUNT=0                                                
  SELECT @MONTOcan=0                                            
                                          
SELECT @COSTOhoySER= @COSTOhoySER - @MONTOcan                                              
                                            
SELECT @MONTO3=@MONTO1 - @COSTOhoySER                                                
                                              
-- utilidad DEL MES                                                
 SELECT @COSTOmesSER=isnull(sum(ISNULL(VTD_costo,0)),0)                                                   
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                    
WHERE ORD_IDORDEN=ORE_IDORDEN                               
AND ORD_IDORDEN=VTE_REFERENCIA1                   
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto not LIKE  'C%'                                                
AND vtd_CLASIFIC not in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                             
AND VTE_tipodocTO=VTD_tipodocTO                                    
AND datepart(mm,convert(datetime,VTE_FECHDOCTO))=@NMES                                                
 AND datepart(yyyy,convert(datetime,VTE_FECHDOCTO))=@NANIO                                                
 AND ORd_clasific IN ('MO','TT')                                                  
 IF @@ROWCOUNT=0                                                
  SELECT @COSTOmesSER=0                                                
                                                                                        
 SELECT @MONTOcan=isnull(sum(ISNULL(VTD_costo,0)),0)                                            
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                  
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_DOCTO LIKE 'S%'                                             
and VTE_docto  LIKE 'C%'                                                
AND vtd_CLASIFIC not in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                            
AND VTE_tipodocTO=VTD_tipodocTO                                              
 AND datepart(mm,convert(datetime,VTE_FECHDOCTO))=@NMES                                                
 AND datepart(yyyy,convert(datetime,VTE_FECHDOCTO))=@NANIO                                                
AND ORd_clasific IN ('MO','TT')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @MONTOcan=0                                                
                                          
SELECT @COSTOmesSER=@COSTOmesSER - @MONTOcan                                              
                                          
SELECT @MONTO4=@MONTO2-@COSTOmesSER                                                
                                                
SELECT @MONTO5=0                                                
SELECT @MONTO6=0                                                
SELECT @MONTO7=0                                                
INSERT INTO BIMega                         
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                                
                                                
            
                                                
--servicio / refacciones                        
SELECT @CONCEPTO1='3.SERVICIO',@CONCEPTO2='2.REFACCIONES'                                                
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                                
-- VENTA DEL DIA                                            
                             
sELECT @MONTO1=isnull(sum(ISNULL(VTD_PRECIOUNITARIO,0)),0)                                            
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto not LIKE  'C%'                                                
AND vtd_CLASIFIC  in('RE','RED')                                 
and VTD_PRECIOUNITARIO>0                                               
AND VTE_tipodocTO=VTD_tipodocTO                                             
AND convert(datetime,VTE_FECHDOCTO)=@HOY                                          
AND ORd_clasific IN ('RE')                                                     
IF @@ROWCOUNT=0                                                
SELECT @MONTO1=0                                              
                                          
sELECT @MONTOcan=isnull(sum(ISNULL(VTD_PRECIOUNITARIO,0)),0)                                            
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                             
AND VTD_IDDOCTO=VTE_DOCTO       
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto  LIKE  'C%'                                                
AND vtd_CLASIFIC  in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                               
AND VTE_tipodocTO=VTD_tipodocTO                                             
AND convert(datetime,VTE_FECHDOCTO)=@HOY                                          
AND ORd_clasific IN ('RE')                                                     
IF @@ROWCOUNT=0                                                
SELECT @MONTOcan=0                                              
                                          
                                          
SELECT @MONTO1= @MONTO1 - @MONTOcan              
                                           
-- VENTA DEL MES                                                
sELECT @MONTO2=isnull(sum(ISNULL(VTD_PRECIOUNITARIO,0)),0)                                            
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                 
and VTE_docto not LIKE  'C%'                                        
AND vtd_CLASIFIC  in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                               
AND VTE_tipodocTO=VTD_tipodocTO                                             
 AND datepart(mm,convert(datetime,VTE_FECHDOCTO))=@NMES                                                
 AND datepart(yyyy,convert(datetime,VTE_FECHDOCTO))=@NANIO                              
AND ORd_clasific IN ('RE')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @MONTO2=0                                             
                                          
sELECT @MONTOcan=isnull(sum(ISNULL(VTD_PRECIOUNITARIO,0)),0)                                               
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto  LIKE  'C%'                                                
AND vtd_CLASIFIC  in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                              
AND VTE_tipodocTO=VTD_tipodocTO                                              
 AND datepart(mm,convert(datetime,VTE_FECHDOCTO))=@NMES                                                
 AND datepart(yyyy,convert(datetime,VTE_FECHDOCTO))=@NANIO                                       
AND ORd_clasific IN ('RE')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @MONTOcan=0                                            
                                          
SELECT @MONTO2=@MONTO2-@MONTOcan                                          
                                          
   -- UTILIDADES DEL DIA Y DEL MES                                               
-- utilidad DEL DIA                                                
 SELECT @COSTOhoySER=isnull(sum(ISNULL(VTD_costo,0)),0)                                              
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto not LIKE  'C%'                                                
AND vtd_CLASIFIC  in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                            
AND VTE_tipodocTO=VTD_tipodocTO                                                
 AND convert(datetime,VTE_FECHDOCTO)=@HOY                                                
AND ORd_clasific IN ('RE')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @COSTOhoySER=0                                            
                                          
                                          
SELECT @MONTOcan=isnull(sum(ISNULL(VTD_costo,0)),0)                                                
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto  LIKE  'C%'                                                
AND vtd_CLASIFIC  in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0       
AND VTE_tipodocTO=VTD_tipodocTO                                               
 AND convert(datetime,VTE_FECHDOCTO)=@HOY                                                
AND ORd_clasific IN ('RE')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @MONTOcan=0                                            
                                          
SELECT @COSTOhoySER= @COSTOhoySER - @MONTOcan                                              
                                            
SELECT @MONTO3=@MONTO1 - @COSTOhoySER                                                
                                              
-- utilidad DEL MES                                                
 SELECT @COSTOmesSER=isnull(sum(ISNULL(VTD_costo,0)),0)                                                   
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                               
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_tipodocTO LIKE 'S%'                                                
and VTE_docto not LIKE  'C%'                                                
AND vtd_CLASIFIC  in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                             
AND VTE_tipodocTO=VTD_tipodocTO                               
AND datepart(mm,convert(datetime,VTE_FECHDOCTO))=@NMES                                                
 AND datepart(yyyy,convert(datetime,VTE_FECHDOCTO))=@NANIO                                                
AND ORd_clasific IN ('RE')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @COSTOmesSER=0                                                
                                                
                                          
 SELECT @MONTOcan=isnull(sum(ISNULL(VTD_costo,0)),0)                                            
FROM ser_orden,dbo.SER_ORDENDET,dbo.ADE_VTAFI,dbo.ADE_VTAFIDET                                                
WHERE ORD_IDORDEN=ORE_IDORDEN                                                
AND ORD_IDORDEN=VTE_REFERENCIA1                                                
AND VTD_IDDOCTO=VTE_DOCTO                                                
AND VTD_CONSE=ORD_CONSE                                                
AND VTE_DOCTO LIKE 'S%'                                             
and VTE_docto  LIKE 'C%'                                                
AND vtd_CLASIFIC  in('RE','RED')                                          
and VTD_PRECIOUNITARIO>0                                            
AND VTE_tipodocTO=VTD_tipodocTO                                              
 AND datepart(mm,convert(datetime,VTE_FECHDOCTO))=@NMES                                                
 AND datepart(yyyy,convert(datetime,VTE_FECHDOCTO))=@NANIO                                                
AND ORd_clasific IN ('RE')                                                     
 IF @@ROWCOUNT=0                                                
  SELECT @MONTOcan=0                                                
                                          
SELECT @COSTOmesSER=@COSTOmesSER - @MONTOcan                                              
                                          
SELECT @MONTO4=@MONTO2-@COSTOmesSER                                                
                                                
SELECT @MONTO5=0                                                
SELECT @MONTO6=0                                
SELECT @MONTO7=0                                                
INSERT INTO BIMega                                                
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                         
                        
             
-- INVENTARIO DE UNIDADES                                                
SELECT @CONSECUTIVO=11                                                
SELECT @CONCEPTO1='4.INVENTARIO UNIDADES',@CONCEPTO2='INVENTARIO UNIDADES'                                                
                                                
-- Unidades en inventario                                                
SELECT @MONTO1=COUNT(*)                                                
FROM SER_VEHICULO                                                
WHERE VEH_NOINVENTA>0                                                
-- AND VEH_SITUACION not in ('VEN','SVEN')                                                
-- Falta ver si salen las que estan en TRANSITO (TRA) transito y pedidas NO                                                
AND VEH_SITUACION     in ('DIS','FIS','PED','SEP')                                                
AND LTRIM(VEH_STIPADQUI)=''                                                
IF @@ROWCOUNT=0                                                
 SELECT @MONTO1=0                                                
                                                
-- Valor del inventario de unidades $                                                
SELECT @MONTO2=sum(isnull(VEH_IMPFACTPLAN,0))                                                
FROM SER_VEHICULO                                                
WHERE VEH_NOINVENTA>0                                                
-- AND VEH_SITUACION not in ('VEN','SVEN')                                                
-- Falta ver si salen las que estan en TRANSITO (TRA) transito y pedidas NO                                                
AND VEH_SITUACION     in ('DIS','FIS','PED','SEP')                                                
AND LTRIM(VEH_STIPADQUI)=''                                                
IF @@ROWCOUNT=0                                                
 SELECT @MONTO2=0                                                
                                                
-- Dias Piso                                     
SELECT @MONTO3=0                                                
                            
SELECT @MONTO4=0                                                
SELECT @MONTO5=0                 
SELECT @MONTO6=0                                                
SELECT @MONTO7=0                                                
INSERT INTO BIMega                                                
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                                
                                                
-- INVENTARIO DE REFACCIONES                                                
-- Existencia puede ser: (alm_existen-ALM_APARTADA-ALM_PROCESO)                                                
SELECT @CONCEPTO1='5.REFACCIONES',@CONCEPTO2='REFACCIONES'                                                
SELECT @CONSECUTIVO=12                                                
-- VALORIZADO A COSTO PROMEDIO                                                
SELECT @MONTO1=SUM(ISNULL((alm_ctoprom)*(alm_existen-alm_apartada-alm_proceso),0))                                             
FROM dbo.PAR_ALMACEN,dbo.PAR_PARTES                                                
WHERE PTS_IDPARTE=ALM_IDPARTE                                                
IF @@ROWCOUNT=0                                                
 SELECT @MONTO1=0                                                
-- OBSOLETO A COSTO PROMEDIO                                                
SELECT @MONTO2=SUM(ISNULL((alm_ctoprom)*(alm_existen-alm_apartada-alm_proceso),0))                                             
FROM dbo.PAR_ALMACEN,dbo.PAR_PARTES                                                
WHERE PTS_IDPARTE=ALM_IDPARTE                                                
AND ALM_CLASIFICA='OBSOLETO'                                                
IF @@ROWCOUNT=0                                                
 SELECT @MONTO2=0                                                
                                                
SELECT @MONTO3=0                                                
SELECT @MONTO4=0                                                
SELECT @MONTO5=0                                                
SELECT @MONTO6=0                                                
SELECT @MONTO7=0          
INSERT INTO BIMega              
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                      
  
  
  
-- SERVICIO/ ORDENES INGRESADAS mano de obra                                                
SELECT @CONCEPTO1='6.SERVICIO',@CONCEPTO2='1.ORDENES INGRESADAS MANO DE OBRA'                                                
SELECT @CONSECUTIVO=13                                                
-- DEL DIA                                                
SELECT @MONTO1=COUNT(*) FROM SER_ORDEN                                                
WHERE CONVERT(DATETIME,ORE_FECHAORD)=@HOY                                                
AND SUBSTRING(ORE_IDORDEN,1,1) IN                                                
(SELECT par_idenpara FROM pnc_parametr WHERE PAR_TIPOPARA='TO' AND PAR_DESCRIP1 NOT LIKE '%HOJ% Y %PIN%')                                                
IF @@ROWCOUNT=0                                                
 SELECT @MONTO1=0                                                
-- DEL MES MANO DE OBRA                                                
SELECT @MONTO2=COUNT(*) FROM SER_ORDEN                                                
WHERE DATEPART(mm,CONVERT(DATETIME,ORE_FECHAORD))=@NMES                                                
AND DATEPART(yyyy,CONVERT(DATETIME,ORE_FECHAORD))=@NANIO                                                
AND SUBSTRING(ORE_IDORDEN,1,1) IN                                                
(SELECT par_idenpara FROM pnc_parametr WHERE PAR_TIPOPARA='TO' AND PAR_DESCRIP1 NOT LIKE '%HOJ% Y %PIN%')                                                
IF @@ROWCOUNT=0                                                
 SELECT @MONTO2=0                          
                                              
                                     
SELECT @MONTO3=0                                                
SELECT @MONTO4=0                                                
SELECT @MONTO5=0                                                
SELECT @MONTO6=0                                                
SELECT @MONTO7=0                            
INSERT INTO BIMega                                                
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                       
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                                
                                                
                                                
-- SERVICIO/ ORDENES ABIERTAS                                                
SELECT @CONCEPTO1='6.SERVICIO',@CONCEPTO2='2.ORDENES ABIERTAS MANO DE OBRA'                                                
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                         
-- DEL DIA                                                
SELECT @MONTO1=COUNT(*) FROM SER_ORDEN                                                
WHERE ORE_STATUS='A'                                                
AND CONVERT(DATETIME,ORE_FECHAORD)=@HOY                                                
AND SUBSTRING(ORE_IDORDEN,1,1) IN                                                
(SELECT par_idenpara FROM pnc_parametr WHERE PAR_TIPOPARA='TO' AND PAR_DESCRIP1 NOT LIKE '%HOJ% Y %PIN%')                                                
IF @@ROWCOUNT=0                                                
 SELECT @MONTO1=0                                                
-- DEL MES                         
SELECT @MONTO2=COUNT(*) FROM SER_ORDEN                                                
WHERE ORE_STATUS='A'                 
--AND DATEPART(mm,CONVERT(DATETIME,ORE_FECHAORD))=@NMES                                                
--AND DATEPART(yyyy,CONVERT(DATETIME,ORE_FECHAORD))=@NANIO                                                
AND SUBSTRING(ORE_IDORDEN,1,1) IN                                                
(SELECT par_idenpara FROM pnc_parametr WHERE PAR_TIPOPARA='TO' AND PAR_DESCRIP1 NOT LIKE '%HOJ% Y %PIN%')                                                
IF @@ROWCOUNT=0                                            
 SELECT @MONTO2=0                                                
                               
SELECT @MONTO3=0                                            
SELECT @MONTO4=0                                                
SELECT @MONTO5=0                                                
SELECT @MONTO6=0                                                
SELECT @MONTO7=0                                                
INSERT INTO BIMega                                          
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                                
                                                                  
                                                
------------------------------- C A R T E R A ---------------------------------------------------                                                
SELECT @CONSECUTIVO=25                                               
                                        
--exec Cuadra_BIMega                                        
                                                
if exists (select * from dbo.sysobjects where id =                                          
object_id(N'[dbo].[bi_tmpcartera]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)                                                
 DROP TABLE dbo.bi_tmpcartera                                                
CREATE TABLE [bi_tmpcartera] (                                                
 [grupo] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS,                                                
 [cartera] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS,                                                
 [saldo] [decimal](18, 5) NULL,                                                
 [dias] [decimal](18, 5) NULL,                                                
 [diasvencidos] [decimal](18, 5) NULL                                                
) ON [PRIMARY]                                                
                                                
-- CARTERA/ ENGANCHES                                                
SELECT @CONCEPTO1='7.CARTERA',@CONCEPTO2='1.GPO GARANTIAS'                                                
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                                
SELECT @GRUPO='GARANTIAS'                                                
                                    
INSERT INTO bi_tmpcartera(grupo,cartera,saldo,dias,diasvencidos)                                                
SELECT @GRUPO,par_idenpara,                                                
 'SALDO' = CASE par_idmodulo WHEN 'CXC'                                                
  THEN ccp_cargo-ccp_abono+(SELECT ISNULL(SUM(CCP_CARGO-CCP_ABONO),0) FROM vis_concar01 AS MOVIMIENTO                                                
   WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                               
   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA                                                
   AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                                
   AND MOVIMIENTO.CCP_DOCORI<>'S'                                                
   AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY)                                                
  ELSE ccp_abono-ccp_cargo+(SELECT ISNULL(SUM(CCP_ABONO-CCP_CARGO),0) FROM vis_concar01 AS MOVIMIENTO                                                
   WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                                
   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA                                                
   AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                                
   AND MOVIMIENTO.CCP_DOCORI<>'S'                                                
   AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY)                                                
  END,                     
 'DIAS' = CASE WHEN ISDATE(ccp_fechven)=1                
  THEN DATEDIFF(DAY,@HOY,CONVERT(DATETIME,ccp_fechven,103)) else 0 end,                                                
 'DIASVENCIDOS' = CASE WHEN ISDATE(ccp_fechven) = 1                                                
  THEN DATEDIFF(DAY,CONVERT(DATETIME,ccp_fechven,103),@HOY)  else 0 end                                                
FROM vis_concar01 AS DOCUMENTO,pnc_parametr ,per_personas                                               
WHERE ccp_docori='S'                                                
AND par_tipopara='CARTERA' AND ccp_cartera*=par_idenpara                  
AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY                                                
-- REVISAR LAS CLAVES DE LAS CARTERAS Y PONER LAS CORRESPONDIENTES AL GRUPO (PARAMETRO: CARTERA)                                                
AND ccp_cartera IN ('G')                                     
and ccp_idpersona = per_idpersona                                    
                                               
                                                
-- SI CAMPO DIAS ES POSITIVO EL SALDO ES POR VENCER              
-- SI CAMPO DIAS ES NEGATIVO EL SALDO ES VENCIDO                                                
-- saldototal                                                
SELECT @monto1=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE grupo=@GRUPO                                                
-- porvencer                                                
SELECT @monto2=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias>0 and saldo > 0 AND grupo=@GRUPO                                                
-- vencidos1a30                                                
SELECT @monto3=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN  0 and 30 AND grupo=@GRUPO                                                
-- vencidos31a60                                                
SELECT @monto4=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN 31 and 60 AND grupo=@GRUPO                         
-- vencidos61a90                                           
SELECT @monto5=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN 61 and 90 AND grupo=@GRUPO                                                
-- totalvencidos                                                
SELECT @monto6=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 AND saldo > 0 and grupo=@GRUPO                                               
--total anticipos no aplicados                                      
SELECT @monto7=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE  saldo< 0 and grupo=@GRUPO                                                
                                                
INSERT INTO BIMega                                                
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                     
                                       
-- CARTERA/ DOCS X COBRAR AUTOS NUEVOS                                                
                                        
SELECT @CONCEPTO1='7.CARTERA',@CONCEPTO2='2.GPO SERVICIO'                                                
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                                
SELECT @GRUPO='SERVICIO'                                                
                                                
INSERT INTO bi_tmpcartera(grupo,cartera,saldo,dias,diasvencidos)                                                
SELECT @GRUPO,par_idenpara,                                                
 'SALDO' = CASE par_idmodulo WHEN 'CXC'                                                
  THEN ccp_cargo-ccp_abono+(SELECT ISNULL(SUM(CCP_CARGO-CCP_ABONO),0) FROM vis_concar01 AS MOVIMIENTO                                                
   WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                  
   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA                                                
   AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                                
   AND MOVIMIENTO.CCP_DOCORI<>'S'                                                
   AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY)                                                
  ELSE ccp_abono-ccp_cargo+(SELECT ISNULL(SUM(CCP_ABONO-CCP_CARGO),0) FROM vis_concar01 AS MOVIMIENTO                                                
   WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                                
   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA                                                
   AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                                
   AND MOVIMIENTO.CCP_DOCORI<>'S'                                                
   AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY)                                                
  END,                                                
 'DIAS' = CASE WHEN ISDATE(ccp_fechven)=1              
  THEN DATEDIFF(DAY,@HOY,CONVERT(DATETIME,ccp_fechven,103)) else 0 end,                                  
 'DIASVENCIDOS' = CASE WHEN ISDATE(ccp_fechven) = 1                                                
  THEN DATEDIFF(DAY,CONVERT(DATETIME,ccp_fechven,103),@HOY)  else 0 end                                                
FROM vis_concar01 AS DOCUMENTO,pnc_parametr  ,per_personas                                              
WHERE ccp_docori='S'                                                
AND par_tipopara='CARTERA' AND ccp_cartera*=par_idenpara                      
AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY                                                
-- REVISAR LAS CLAVES DE LAS CARTERAS Y PONER LAS CORRESPONDIENTES AL GRUPO (PARAMETRO: CARTERA)                                                
AND CCP_CARTERA IN ('S')                                                
and ccp_idpersona = per_idpersona                                      
                                                
-- SI CAMPO DIAS ES POSITIVO EL SALDO ES POR VENCER                                                
-- SI CAMPO DIAS ES NEGATIVO EL SALDO ES VENCIDO                                                
-- saldototal                                                
SELECT @monto1=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE grupo=@GRUPO                                                
-- porvencer                                                
SELECT @monto2=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias>0 and saldo > 0 AND grupo=@GRUPO                                                
-- vencidos1a30                                                
SELECT @monto3=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN  0 and 30 AND grupo=@GRUPO                                                
-- vencidos31a60                                                
SELECT @monto4=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN 31 and 60 AND grupo=@GRUPO                                                
-- vencidos61a90                                                
SELECT @monto5=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN 61 and 90 AND grupo=@GRUPO                                                
-- totalvencidos                
SELECT @monto6=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 AND saldo > 0 and grupo=@GRUPO                   
--total anticipos no aplicados                                      
SELECT @monto7=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE  saldo< 0 and grupo=@GRUPO                                               
                                        
INSERT INTO BIMega                                                
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                                
                                                
-- CARTERA/ SERVICIO Y REFACCIONES                                                
SELECT @CONCEPTO1='7.CARTERA',@CONCEPTO2='3.VEHICULOS MENUDEO'                                                
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                                
SELECT @GRUPO='AUTOS NUEVOS'                                                
                                                
INSERT INTO bi_tmpcartera(grupo,cartera,saldo,dias,diasvencidos)                                                
SELECT @GRUPO,par_idenpara,                                                
 'SALDO' = CASE par_idmodulo WHEN 'CXC'                                                
  THEN ccp_cargo-ccp_abono+(SELECT ISNULL(SUM(CCP_CARGO-CCP_ABONO),0) FROM vis_concar01 AS MOVIMIENTO                                                
   WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                                
   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA                
   AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                                
   AND MOVIMIENTO.CCP_DOCORI<>'S'                                                
   AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY)                                                
  ELSE ccp_abono-ccp_cargo+(SELECT ISNULL(SUM(CCP_ABONO-CCP_CARGO),0) FROM vis_concar01 AS MOVIMIENTO                                                
   WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                                
   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA                                                
   AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                                
   AND MOVIMIENTO.CCP_DOCORI<>'S'                                                
   AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY)                                                
  END,                              
 'DIAS' = CASE WHEN ISDATE(ccp_fechven)=1                                                
  THEN DATEDIFF(DAY,@HOY,CONVERT(DATETIME,ccp_fechven,103)) else 0 end,                                                
 'DIASVENCIDOS' = CASE WHEN ISDATE(ccp_fechven) = 1                                                
  THEN DATEDIFF(DAY,CONVERT(DATETIME,ccp_fechven,103),@HOY) else 0 end                                                
FROM vis_concar01 AS DOCUMENTO,pnc_parametr  ,per_personas                                              
WHERE ccp_docori='S'                                          
AND par_tipopara='CARTERA' AND ccp_cartera*=par_idenpara                                                
AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY                                                
-- REVISAR LAS CLAVES DE LAS CARTERAS Y PONER LAS CORRESPONDIENTES AL GRUPO (PARAMETRO: CARTERA)                                                
AND CCP_CARTERA IN ('N')                                                
and ccp_idpersona = per_idpersona                                    
                                    
-- SI CAMPO DIAS ES POSITIVO EL SALDO ES POR VENCER                                                
-- SI CAMPO DIAS ES NEGATIVO EL SALDO ES VENCIDO                                                
-- saldototal                                                
-- saldototal                                                
SELECT @monto1=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE grupo=@GRUPO          
-- porvencer                                                
SELECT @monto2=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias>0 and saldo > 0 AND grupo=@GRUPO                                                
-- vencidos1a30                            
SELECT @monto3=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN  0 and 30 AND grupo=@GRUPO                                                
-- vencidos31a60                                                
SELECT @monto4=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN 31 and 60 AND grupo=@GRUPO                                                
-- vencidos61a90                                                
SELECT @monto5=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN 61 and 90 AND grupo=@GRUPO                                                
-- totalvencidos                                                
SELECT @monto6=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 AND saldo > 0 and grupo=@GRUPO                                               
--total anticipos no aplicados                                      
SELECT @monto7=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE  saldo< 0 and grupo=@GRUPO                                             
                                                
INSERT INTO BIMega                                                
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,               
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                        
                                                
-- CARTERA/ CHEQUES DEVUELTOS                                                
SELECT @CONCEPTO1='7.CARTERA',@CONCEPTO2='4.GPO REFACCIONES'                                                
SELECT @CONSECUTIVO=@CONSECUTIVO+1                                                
SELECT @GRUPO='REFACCIONES'                                            
                                                
INSERT INTO bi_tmpcartera(grupo,cartera,saldo,dias,diasvencidos)                                                
SELECT @GRUPO,par_idenpara,                                                
 'SALDO' = CASE par_idmodulo WHEN 'CXC'            THEN ccp_cargo-ccp_abono+(SELECT ISNULL(SUM(CCP_CARGO-CCP_ABONO),0) FROM vis_concar01 AS MOVIMIENTO                                                
   WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                                
   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA                                                
   AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                                
   AND MOVIMIENTO.CCP_DOCORI<>'S'                                                
   AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY)                             
  ELSE ccp_abono-ccp_cargo+(SELECT ISNULL(SUM(CCP_ABONO-CCP_CARGO),0) FROM vis_concar01 AS MOVIMIENTO                                                
   WHERE MOVIMIENTO.CCP_IDDOCTO=DOCUMENTO.CCP_IDDOCTO                                                
   AND MOVIMIENTO.CCP_IDPERSONA=DOCUMENTO.CCP_IDPERSONA            
   AND MOVIMIENTO.CCP_CARTERA=DOCUMENTO.CCP_CARTERA                                                
   AND MOVIMIENTO.CCP_DOCORI<>'S'                                                
   AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY)                                                
  END,                                                
 'DIAS' = CASE WHEN ISDATE(ccp_fechven)=1                                                
  THEN DATEDIFF(DAY,@HOY,CONVERT(DATETIME,ccp_fechven,103)) else 0 end,                                                
 'DIASVENCIDOS' = CASE WHEN ISDATE(ccp_fechven) = 1                                                
  THEN DATEDIFF(DAY,CONVERT(DATETIME,ccp_fechven,103),@HOY)  else 0 end                                                
FROM vis_concar01 AS DOCUMENTO,pnc_parametr  ,per_personas                                              
WHERE ccp_docori='S'                                  
AND par_tipopara='CARTERA' AND ccp_cartera*=par_idenpara                                                
AND CONVERT(DATETIME,ccp_fechadocto,103) <= @HOY                                                
-- REVISAR LAS CLAVES DE LAS CARTERAS Y PONER LAS CORRESPONDIENTES AL GRUPO (PARAMETRO: CARTERA)                                                
AND CCP_CARTERA IN ('R')                                                
and ccp_idpersona = per_idpersona                                    
                                                
-- SI CAMPO DIAS ES POSITIVO EL SALDO ES POR VENCER                                                
-- SI CAMPO DIAS ES NEGATIVO EL SALDO ES VENCIDO                                                
-- saldototal                                                
SELECT @monto1=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE grupo=@GRUPO                                                
-- porvencer                                                
SELECT @monto2=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias>0 and saldo > 0 AND grupo=@GRUPO                                                
-- vencidos1a30                                                
SELECT @monto3=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN  0 and 30 AND grupo=@GRUPO                                                
-- vencidos31a60                                                
SELECT @monto4=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN 31 and 60 AND grupo=@GRUPO                                                
-- vencidos61a90                                                
SELECT @monto5=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 and saldo > 0 AND diasvencidos  BETWEEN 61 and 90 AND grupo=@GRUPO                                                
-- totalvencidos                                                
SELECT @monto6=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE dias<=0 AND saldo > 0 and grupo=@GRUPO                                               
--total anticipos no aplicados                                  
SELECT @monto7=ISNULL(SUM(saldo),0) FROM bi_tmpcartera WHERE  saldo< 0 and grupo=@GRUPO                                                 
                                                
INSERT INTO BIMega                                                
VALUES(@EMPRESA,@FECHA_ID,@CONSECUTIVO,@CONCEPTO1,@CONCEPTO2,                                                
@MONTO1,@MONTO2,@MONTO3,@MONTO4,@MONTO5,@MONTO6,@MONTO7)                                                
                                                
-- COPIA A LA MISMA TABLA DE LA BD BIMega                                                
TRUNCATE TABLE BIMega..BIMega                                                
INSERT INTO BIMega..BIMega SELECT * FROM BIMega



go

