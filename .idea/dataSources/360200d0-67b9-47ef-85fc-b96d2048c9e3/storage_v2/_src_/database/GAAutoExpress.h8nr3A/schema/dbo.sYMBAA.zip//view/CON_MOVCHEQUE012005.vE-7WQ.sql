create view [dbo].[CON_MOVCHEQUE012005] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012005;
go

