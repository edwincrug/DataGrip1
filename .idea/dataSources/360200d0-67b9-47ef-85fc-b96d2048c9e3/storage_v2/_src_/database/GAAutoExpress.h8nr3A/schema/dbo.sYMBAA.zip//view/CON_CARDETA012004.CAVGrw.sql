create view [dbo].[CON_CARDETA012004] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012004;
go

