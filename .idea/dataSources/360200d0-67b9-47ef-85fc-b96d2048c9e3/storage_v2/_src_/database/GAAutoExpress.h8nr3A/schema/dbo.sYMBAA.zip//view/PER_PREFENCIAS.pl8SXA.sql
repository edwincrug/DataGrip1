create view [dbo].[PER_PREFENCIAS] as select * from GAAutoexpressConcentra.dbo.PER_PREFENCIAS;
go

