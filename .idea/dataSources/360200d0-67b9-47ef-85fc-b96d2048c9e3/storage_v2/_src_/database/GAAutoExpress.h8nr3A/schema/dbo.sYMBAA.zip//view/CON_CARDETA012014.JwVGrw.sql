create view [dbo].[CON_CARDETA012014] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012014;
go

