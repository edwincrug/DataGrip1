create view [dbo].[CON_CAR012015] as select * from GAAutoexpressConcentra.dbo.CON_CAR012015;
go

