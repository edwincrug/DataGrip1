create view [dbo].[SER_PQOPERACIONES] as select * from GAAutoexpressConcentra.dbo.SER_PQOPERACIONES;
go

