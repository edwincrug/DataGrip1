create view [dbo].[CON_POL012018] as select * from GAAutoexpressConcentra.dbo.CON_POL012018;
go

