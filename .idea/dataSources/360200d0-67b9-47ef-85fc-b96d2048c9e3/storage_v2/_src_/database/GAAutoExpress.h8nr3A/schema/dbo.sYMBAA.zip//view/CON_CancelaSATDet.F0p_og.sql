CREATE VIEW [dbo].[CON_CancelaSATDet] AS SELECT * FROM GAAutoexpressConcentra.dbo.CON_CancelaSATDet
go

