create view [dbo].[CON_CARCON012011] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012011;
go

