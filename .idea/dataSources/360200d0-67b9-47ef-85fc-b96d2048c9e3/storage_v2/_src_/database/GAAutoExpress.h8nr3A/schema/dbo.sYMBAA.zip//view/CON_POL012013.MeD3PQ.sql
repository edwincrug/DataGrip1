create view [dbo].[CON_POL012013] as select * from GAAutoexpressConcentra.dbo.CON_POL012013;
go

