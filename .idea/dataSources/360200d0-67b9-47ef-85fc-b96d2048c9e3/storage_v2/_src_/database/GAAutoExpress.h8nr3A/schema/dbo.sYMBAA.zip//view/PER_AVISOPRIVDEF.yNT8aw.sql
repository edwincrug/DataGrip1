create view [dbo].[PER_AVISOPRIVDEF] as select * from GAAutoexpressConcentra.dbo.PER_AVISOPRIVDEF;
go

