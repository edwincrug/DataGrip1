create view [dbo].[CON_CFDI012013] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012013;
go

