create view [dbo].[CON_MOVCHEQUE012016] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012016;
go

