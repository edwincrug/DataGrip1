create view [dbo].[CON_CFDI012015] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012015;
go

