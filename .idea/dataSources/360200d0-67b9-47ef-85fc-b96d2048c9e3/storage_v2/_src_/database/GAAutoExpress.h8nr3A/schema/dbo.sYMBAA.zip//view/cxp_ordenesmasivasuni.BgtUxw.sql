CREATE VIEW cxp_ordenesmasivasuni AS SELECT * FROM GAAutoexpressConcentra.dbo.cxp_ordenesmasivasuni
go

