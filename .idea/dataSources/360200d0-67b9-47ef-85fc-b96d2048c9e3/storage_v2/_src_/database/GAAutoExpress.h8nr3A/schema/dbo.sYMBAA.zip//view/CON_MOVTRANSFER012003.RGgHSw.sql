create view [dbo].[CON_MOVTRANSFER012003] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012003;
go

