create view [dbo].[CON_CFDI012004] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012004;
go

