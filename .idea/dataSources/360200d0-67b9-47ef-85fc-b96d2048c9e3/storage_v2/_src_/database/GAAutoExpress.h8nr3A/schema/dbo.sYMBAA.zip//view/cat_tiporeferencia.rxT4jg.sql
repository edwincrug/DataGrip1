
CREATE VIEW [dbo].[cat_tiporeferencia] AS SELECT * From  GAAutoexpressConcentra.dbo.cat_tiporeferencia
go

