create view [dbo].[PER_OBSERVACIONES] as select * from GAAutoexpressConcentra.dbo.PER_OBSERVACIONES;
go

