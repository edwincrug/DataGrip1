create view [dbo].[CON_CAR012014] as select * from GAAutoexpressConcentra.dbo.CON_CAR012014;
go

