create view [dbo].[CON_MOVDETFIJ012015] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012015;
go

