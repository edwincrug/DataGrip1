create view [dbo].[con_poldirerr012007] as select * from GAAutoexpressConcentra.dbo.con_poldirerr012007;
go

