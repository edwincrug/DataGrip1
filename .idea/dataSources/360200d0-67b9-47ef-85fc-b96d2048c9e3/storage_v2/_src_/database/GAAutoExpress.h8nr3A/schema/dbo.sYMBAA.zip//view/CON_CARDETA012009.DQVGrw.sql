create view [dbo].[CON_CARDETA012009] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012009;
go

