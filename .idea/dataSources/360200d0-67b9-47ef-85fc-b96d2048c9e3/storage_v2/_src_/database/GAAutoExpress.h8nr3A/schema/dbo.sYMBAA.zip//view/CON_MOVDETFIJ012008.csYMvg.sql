create view [dbo].[CON_MOVDETFIJ012008] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012008;
go

