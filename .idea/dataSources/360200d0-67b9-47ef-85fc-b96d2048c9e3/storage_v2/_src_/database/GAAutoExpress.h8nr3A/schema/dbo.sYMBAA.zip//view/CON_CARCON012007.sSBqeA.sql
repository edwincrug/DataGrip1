create view [dbo].[CON_CARCON012007] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012007;
go

