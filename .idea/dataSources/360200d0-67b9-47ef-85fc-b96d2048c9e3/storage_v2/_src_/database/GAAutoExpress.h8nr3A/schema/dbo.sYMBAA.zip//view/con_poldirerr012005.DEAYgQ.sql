create view [dbo].[con_poldirerr012005] as select * from GAAutoexpressConcentra.dbo.con_poldirerr012005;
go

