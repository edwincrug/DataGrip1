CREATE VIEW [dbo].[VISTA_CONSULTA_ASEGURADORAS]
AS
SELECT     TOP 100 PERCENT dbo.PAR_MOVTOS.Mov_Refer1, dbo.PAR_MOVTOS.Mov_Fechfac, 
                      A.PER_NOMRAZON + ' ' + A.PER_PATERNO + ' ' + A.PER_MATERNO AS Personas, dbo.PAR_MOVDET.Mod_Idparte, dbo.PAR_PARTES.PTS_DESPARTE, 
                      dbo.PAR_MOVDET.Mod_Cantidad * - 1 AS Cantidad, dbo.PAR_MOVDET.Mod_PCosVta, dbo.PAR_MOVDET.Mod_Total, 
                      MONTH(dbo.PAR_MOVTOS.Mov_Fechfac) AS Mes, YEAR(dbo.PAR_MOVTOS.Mov_Fechfac) AS Ano, A.PER_IDPERSONA AS [Id persona]
FROM         dbo.PAR_MOVTOS INNER JOIN
                      dbo.ADE_VTAFI ON dbo.PAR_MOVTOS.Mov_Refer1 = dbo.ADE_VTAFI.VTE_DOCTO INNER JOIN
                      dbo.PAR_MOVDET ON dbo.PAR_MOVTOS.Mov_Numero = dbo.PAR_MOVDET.Mod_Numero AND 
                      dbo.PAR_MOVTOS.Mov_TipoMov = dbo.PAR_MOVDET.Mod_TipoMov INNER JOIN
                      dbo.PER_PERSONAS A ON dbo.ADE_VTAFI.VTE_IDCLIENTE = A.PER_IDPERSONA INNER JOIN
                      dbo.PNC_PARAMETR MOV ON dbo.PAR_MOVTOS.Mov_TipoMov = MOV.PAR_IDENPARA INNER JOIN
                      dbo.PAR_PARTES ON dbo.PAR_MOVDET.Mod_Idparte = dbo.PAR_PARTES.PTS_IDPARTE INNER JOIN
                      dbo.PNC_PARAMETR GPO ON dbo.PAR_PARTES.PTS_GRUPO = GPO.PAR_IDENPARA
WHERE     (MOV.PAR_TIPOPARA = 'MP') AND (MOV.PAR_DESCRIP2 IN ('VM', 'VT')) AND (GPO.PAR_TIPOPARA = 'GP') AND 
                      (dbo.PAR_MOVDET.Mod_Idalmacen = 'GEN') AND (dbo.PAR_MOVTOS.Mov_TipoMov IN ('66', '70')) AND (dbo.ADE_VTAFI.VTE_STATUS = 'I') AND 
                      (A.PER_IDPERSONA <> 0)
ORDER BY CONVERT(datetime, dbo.PAR_MOVTOS.Mov_Fechfac)
go

