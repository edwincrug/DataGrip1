create view [dbo].[CON_MOVDET012007] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012007;
go

