create view [dbo].[CON_CFDI012003] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012003;
go

