create view [dbo].[ade_CfdiFolioRelacionado] as select * from GAAutoexpressConcentra.dbo.ade_CfdiFolioRelacionado;
go

