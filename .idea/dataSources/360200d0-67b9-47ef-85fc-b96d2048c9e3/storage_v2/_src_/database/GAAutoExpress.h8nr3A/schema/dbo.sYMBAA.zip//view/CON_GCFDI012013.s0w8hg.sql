create view [CON_GCFDI012013] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012013]
go

