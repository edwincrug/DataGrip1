create view [dbo].[CON_CARCON012017] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012017;
go

