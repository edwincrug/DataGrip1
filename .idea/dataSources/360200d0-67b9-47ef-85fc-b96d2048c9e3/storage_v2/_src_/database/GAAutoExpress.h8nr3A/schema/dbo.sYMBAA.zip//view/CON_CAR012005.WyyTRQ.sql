create view [dbo].[CON_CAR012005] as select * from GAAutoexpressConcentra.dbo.CON_CAR012005;
go

