create view [dbo].[CON_CFDI012012] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012012;
go

