create view [dbo].[ADE_CFDIREPMENDET] as select * from GAAutoexpressConcentra.dbo.ADE_CFDIREPMENDET;
go

