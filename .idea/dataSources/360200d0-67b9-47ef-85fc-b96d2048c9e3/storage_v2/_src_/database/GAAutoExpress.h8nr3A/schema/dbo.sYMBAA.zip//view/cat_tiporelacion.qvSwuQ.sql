create view [dbo].[cat_tiporelacion] as select * from GAAutoexpressConcentra.dbo.cat_tiporelacion;
go

