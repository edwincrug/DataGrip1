create view [dbo].[CON_CARCON012003] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012003;
go

