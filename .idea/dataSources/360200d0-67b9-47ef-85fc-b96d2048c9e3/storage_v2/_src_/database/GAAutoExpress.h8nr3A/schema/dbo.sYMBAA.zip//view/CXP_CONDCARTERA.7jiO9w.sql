create view [dbo].[CXP_CONDCARTERA] as select * from GAAutoexpressConcentra.dbo.CXP_CONDCARTERA;
go

