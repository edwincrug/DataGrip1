CREATE VIEW [dbo].[vstAvcXStt1] AS SELECT sc.* FROM PYM_SEGCITAS sc INNER JOIN vstAvcXStt0 vas ON vas.Seg_Csvo = sc.Seg_Csvo
go

