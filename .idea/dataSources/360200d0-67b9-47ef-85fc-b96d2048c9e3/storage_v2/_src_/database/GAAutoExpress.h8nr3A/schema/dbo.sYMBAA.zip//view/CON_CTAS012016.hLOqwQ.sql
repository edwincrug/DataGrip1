create view [dbo].[CON_CTAS012016] as select * from GAAutoexpressConcentra.dbo.CON_CTAS012016;
go

