create view [dbo].[CON_CARDETACON012004] as select * from GAAutoexpressConcentra.dbo.CON_CARDETACON012004;
go

