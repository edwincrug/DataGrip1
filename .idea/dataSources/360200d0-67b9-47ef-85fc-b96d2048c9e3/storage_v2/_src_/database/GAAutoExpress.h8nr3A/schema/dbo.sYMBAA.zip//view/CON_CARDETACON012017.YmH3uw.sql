create view [dbo].[CON_CARDETACON012017] as select * from GAAutoexpressConcentra.dbo.CON_CARDETACON012017;
go

