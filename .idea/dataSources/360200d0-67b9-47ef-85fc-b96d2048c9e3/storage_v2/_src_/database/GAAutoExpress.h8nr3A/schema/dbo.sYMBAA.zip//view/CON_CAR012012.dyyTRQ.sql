create view [dbo].[CON_CAR012012] as select * from GAAutoexpressConcentra.dbo.CON_CAR012012;
go

