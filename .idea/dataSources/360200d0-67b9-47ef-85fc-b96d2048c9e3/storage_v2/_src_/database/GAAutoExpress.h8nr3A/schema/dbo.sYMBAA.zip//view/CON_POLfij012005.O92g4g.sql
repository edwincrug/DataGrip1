create view [dbo].[CON_POLfij012005] as select * from GAAutoexpressConcentra.dbo.CON_POLfij012005;
go

