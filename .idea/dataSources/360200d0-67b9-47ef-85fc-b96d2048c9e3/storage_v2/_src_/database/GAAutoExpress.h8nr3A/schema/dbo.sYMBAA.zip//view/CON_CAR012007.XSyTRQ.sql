create view [dbo].[CON_CAR012007] as select * from GAAutoexpressConcentra.dbo.CON_CAR012007;
go

