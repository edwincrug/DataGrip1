create view [dbo].[PAR_REEMPLAZOS] as select * from GAAutoexpressConcentra.dbo.PAR_REEMPLAZOS;
go

