create view [dbo].[CXP_CONDCRED] as select * from GAAutoexpressConcentra.dbo.CXP_CONDCRED;
go

