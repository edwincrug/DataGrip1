create view [dbo].[CON_CATCTASSAT] as select * from GAAutoexpressConcentra.dbo.CON_CATCTASSAT;
go

