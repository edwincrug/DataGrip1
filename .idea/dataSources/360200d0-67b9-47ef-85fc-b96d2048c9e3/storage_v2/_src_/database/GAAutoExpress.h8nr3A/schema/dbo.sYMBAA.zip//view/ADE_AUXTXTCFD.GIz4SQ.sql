create view [dbo].[ADE_AUXTXTCFD] as select * from GAAutoexpressConcentra.dbo.ADE_AUXTXTCFD;
go

