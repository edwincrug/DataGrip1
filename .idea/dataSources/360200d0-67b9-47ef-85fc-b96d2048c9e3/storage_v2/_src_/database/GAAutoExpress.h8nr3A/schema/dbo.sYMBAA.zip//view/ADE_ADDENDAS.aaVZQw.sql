create view [dbo].[ADE_ADDENDAS] as select * from GAAutoexpressConcentra.dbo.ADE_ADDENDAS;
go

