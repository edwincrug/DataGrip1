create view [dbo].[CON_MOVDET012013] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012013;
go

