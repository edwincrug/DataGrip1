create view [dbo].[CON_MOVCHEQUE012009] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012009;
go

