create view [dbo].[CON_MOVDET012011] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012011;
go

