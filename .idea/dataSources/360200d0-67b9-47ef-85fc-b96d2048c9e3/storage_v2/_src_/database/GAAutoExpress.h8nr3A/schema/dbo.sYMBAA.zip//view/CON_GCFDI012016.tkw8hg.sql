create view [dbo].[CON_GCFDI012016] as select * from GAAutoexpressConcentra.dbo.CON_GCFDI012016;
go

