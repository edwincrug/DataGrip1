create view [dbo].[CON_POL012016] as select * from GAAutoexpressConcentra.dbo.CON_POL012016;
go

