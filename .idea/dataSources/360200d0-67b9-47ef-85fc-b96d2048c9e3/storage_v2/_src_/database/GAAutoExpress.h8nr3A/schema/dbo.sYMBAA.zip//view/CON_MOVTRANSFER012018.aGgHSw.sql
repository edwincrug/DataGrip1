create view [dbo].[CON_MOVTRANSFER012018] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012018;
go

