create view [dbo].[CON_CARDETACON012007] as select * from GAAutoexpressConcentra.dbo.CON_CARDETACON012007;
go

