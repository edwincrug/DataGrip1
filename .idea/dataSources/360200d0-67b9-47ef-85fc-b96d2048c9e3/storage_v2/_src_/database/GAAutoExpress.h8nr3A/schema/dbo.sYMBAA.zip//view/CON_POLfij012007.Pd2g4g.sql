create view [dbo].[CON_POLfij012007] as select * from GAAutoexpressConcentra.dbo.CON_POLfij012007;
go

