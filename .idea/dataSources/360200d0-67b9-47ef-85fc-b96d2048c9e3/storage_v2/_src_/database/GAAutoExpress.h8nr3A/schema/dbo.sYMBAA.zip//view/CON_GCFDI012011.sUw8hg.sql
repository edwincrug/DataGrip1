create view [CON_GCFDI012011] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012011]
go

