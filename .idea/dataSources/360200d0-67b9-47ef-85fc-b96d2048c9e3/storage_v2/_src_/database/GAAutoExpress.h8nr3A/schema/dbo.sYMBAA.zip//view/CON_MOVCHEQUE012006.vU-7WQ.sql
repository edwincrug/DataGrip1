create view [dbo].[CON_MOVCHEQUE012006] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012006;
go

