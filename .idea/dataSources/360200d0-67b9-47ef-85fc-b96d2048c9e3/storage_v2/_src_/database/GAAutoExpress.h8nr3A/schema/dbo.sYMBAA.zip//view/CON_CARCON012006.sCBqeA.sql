create view [dbo].[CON_CARCON012006] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012006;
go

