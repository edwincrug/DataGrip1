create view [dbo].[CON_MOVTRANSFER012004] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012004;
go

