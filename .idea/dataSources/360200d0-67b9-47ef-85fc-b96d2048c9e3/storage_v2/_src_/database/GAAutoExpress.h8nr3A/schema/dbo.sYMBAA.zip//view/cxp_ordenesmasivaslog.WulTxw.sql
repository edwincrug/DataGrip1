Create View [dbo].[cxp_ordenesmasivaslog] as select * from [GAAutoexpressConcentra].dbo.cxp_ordenesmasivaslog
go

