create view [dbo].[CON_MOVDETFIJ012013] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012013;
go

