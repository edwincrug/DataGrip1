create view [dbo].[CON_POL012005] as select * from GAAutoexpressConcentra.dbo.CON_POL012005;
go

