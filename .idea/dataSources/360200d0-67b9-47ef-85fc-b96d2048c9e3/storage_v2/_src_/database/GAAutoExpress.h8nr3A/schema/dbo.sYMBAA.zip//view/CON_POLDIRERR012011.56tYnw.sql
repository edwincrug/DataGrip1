create view [dbo].[CON_POLDIRERR012011] as select * from GAAutoexpressConcentra.dbo.CON_POLDIRERR012011;
go

