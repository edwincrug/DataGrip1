create view [dbo].[CON_MOVDETFIJ012011] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012011;
go

