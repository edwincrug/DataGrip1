create view [dbo].[CON_CARCON012009] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012009;
go

