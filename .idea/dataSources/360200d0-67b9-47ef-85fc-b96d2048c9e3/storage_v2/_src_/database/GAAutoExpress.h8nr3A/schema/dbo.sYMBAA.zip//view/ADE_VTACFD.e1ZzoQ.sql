create view [dbo].[ADE_VTACFD] as select * from GAAutoexpressConcentra.dbo.ADE_VTACFD;
go

