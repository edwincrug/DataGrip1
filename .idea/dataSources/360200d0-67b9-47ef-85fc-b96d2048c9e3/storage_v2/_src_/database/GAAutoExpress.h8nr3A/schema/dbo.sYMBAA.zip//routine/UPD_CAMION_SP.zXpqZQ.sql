


CREATE procedure [dbo].[UPD_CAMION_SP] (
	@idCamion numeric(18,0),
	@idModelo numeric(18,0),
	@idTipoCamion numeric(18,0),
	@vin nvarchar(50),
	@motor nvarchar(50),
	@placa nvarchar(50),
	@rendimiento decimal(18,2),
	@idCaja numeric(18,0),
	@idTransmision numeric(18,0),
	@idCilindros numeric(18,0),
	@idCombustible numeric(18,0),
	@tanque nvarchar(50)
)
as
begin

	UPDATE
		dbo.Camion
	SET
		idModelo = @idModelo,
		idTipoCamion = @idTipoCamion,
		vin = @vin,
		motor = @motor,
		placa = @placa,
		rendimiento = @rendimiento,
		idTransmision = @idTransmision,
		idCilindros = @idCilindros,
		idCombustible = @idCombustible,
		tanque = @tanque
	WHERE 
		idCamion = @idCamion

	IF (@idCaja IS NOT NULL) BEGIN
		UPDATE CamionCaja SET estatus = 2 WHERE idCaja = @idCaja
		INSERT INTO dbo.CamionCaja
			(idCamion, idCaja, estatus,fecha)
		VALUES 
			(@idCamion, @idCaja , 1 , GETDATE())
	END
	
	SELECT @idCamion
	
end

go

