create view [dbo].[CON_CARDETA012018] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012018;
go

