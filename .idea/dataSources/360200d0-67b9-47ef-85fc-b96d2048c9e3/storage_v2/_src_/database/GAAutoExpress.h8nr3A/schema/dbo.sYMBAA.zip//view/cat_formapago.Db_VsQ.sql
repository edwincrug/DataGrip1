create view [dbo].[cat_formapago] as select * from GAAutoexpressConcentra.dbo.cat_formapago;
go

