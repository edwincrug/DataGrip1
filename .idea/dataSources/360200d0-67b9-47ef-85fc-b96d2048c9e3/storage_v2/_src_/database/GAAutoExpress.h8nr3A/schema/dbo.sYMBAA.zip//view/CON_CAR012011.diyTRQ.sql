create view [dbo].[CON_CAR012011] as select * from GAAutoexpressConcentra.dbo.CON_CAR012011;
go

