create view [dbo].[CON_MOVCHEQUE012017] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012017;
go

