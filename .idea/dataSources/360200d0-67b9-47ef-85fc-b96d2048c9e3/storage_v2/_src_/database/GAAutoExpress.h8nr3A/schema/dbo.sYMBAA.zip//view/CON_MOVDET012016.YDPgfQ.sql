create view [dbo].[CON_MOVDET012016] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012016;
go

