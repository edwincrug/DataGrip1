create view [dbo].[CON_MOVDET012005] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012005;
go

