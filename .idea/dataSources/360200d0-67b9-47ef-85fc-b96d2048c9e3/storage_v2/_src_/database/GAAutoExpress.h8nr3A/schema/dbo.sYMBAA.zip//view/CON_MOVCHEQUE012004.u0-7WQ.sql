create view [dbo].[CON_MOVCHEQUE012004] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012004;
go

