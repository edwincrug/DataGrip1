create view [dbo].[CON_POL012006] as select * from GAAutoexpressConcentra.dbo.CON_POL012006;
go

