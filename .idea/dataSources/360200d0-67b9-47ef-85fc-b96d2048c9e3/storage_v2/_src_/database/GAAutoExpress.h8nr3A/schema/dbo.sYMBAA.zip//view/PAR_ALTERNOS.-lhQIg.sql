create view [dbo].[PAR_ALTERNOS] as select * from GAAutoexpressConcentra.dbo.PAR_ALTERNOS;
go

