create view [dbo].[CON_CAR012010] as select * from GAAutoexpressConcentra.dbo.CON_CAR012010;
go

