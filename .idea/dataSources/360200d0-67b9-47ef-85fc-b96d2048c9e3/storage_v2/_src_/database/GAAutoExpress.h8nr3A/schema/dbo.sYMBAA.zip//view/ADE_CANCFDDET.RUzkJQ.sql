create view [dbo].[ADE_CANCFDDET] as select * from GAAutoexpressConcentra.dbo.ADE_CANCFDDET;
go

