
create view [dbo].[VISTA_PROSPINT] as    
SELECT                PER_IDPERSONA AS [Número],PER_NOMRAZON AS[Nombre],PER_PATERNO AS [Paterno],PER_MATERNO AS 
[Materno],         isnull((SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA='EO' AND PAR_IDENPARA=PER_ESTADO),'') AS [Estado],
         isnull (PER_CIUDAD,'') AS [Ciudad],         isnull (PER_DELEGAC,'') AS [Delegación],         PER_COLONIA AS [Colonia],         
         isnull (PER_CODPOS,'') AS [C.P.],         isnull (PER_OBSERVACIONES,'') AS [Marca],        isnull((SELECT PAR_DESCRIP1 
         FROM PNC_PARAMETR WHERE PAR_TIPOPARA='PA' AND PAR_IDENPARA=ROL_ROL),'') AS [Roles],        isnull((SELECT PAR_DESCRIP2 
         FROM PNC_PARAMETR WHERE PAR_TIPOPARA='PP' AND PRE_IDENPARA = PAR_IDENPARA),'') AS [Preferencias]          
         FROM           GA_Corporativa.DBO.PER_PERSONAS,        PER_ROLES,        PER_PREFENCIAS                
         WHERE               PER_IDPERSONA=ROL_IDPERSONA        AND        PRE_IDPERSONA=PER_IDPERSONA        
         AND         ROL_ESTATUS=1    ---(2)Graba archivo de scripts  
go

