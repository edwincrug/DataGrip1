/*
 =============================================
 Author:		Tajín Salarich
 Create date:	06/08/2013
 Description:	Datos detallados de la venta de unidades nuevas
 Version:		1.0.0
 =============================================
 */
CREATE VIEW [dbo].[VDS_DETVENTAVEHICULOS]
AS

SELECT
	-- Control
	DVH_CLAVE idDetVtaClave,
	DVH_IDPERSONA idPErsona,
	DVH_DOCTO Docto,
	
	-- Venta
	ISNULL(DVH_COMISIONVEH,0) VentaComision,
	ISNULL(DVH_IDVENDEDORVEH,'') VentaIDVendedor,
	ISNULL(DVH_VEHACAMBIO,0) VentaVehiculoACambio,
	ISNULL(DVH_SEMINUEVOCERT,0) VentaSeminuevoCertificado,
	
	-- Financiamiento
	ISNULL(DVH_FINANCIAMIENTO,0) Finan,
	ISNULL(DVH_FECHAINIFIN,'') FinanIniFecha,
	ISNULL(DVH_PLAZOFIN,0) FinanPlazo,
	ISNULL(DVH_FINANCIERA,'') FinanFinanciera,
	ISNULL(DVH_PLANFIN,'') FinanPlan,
	ISNULL(DVH_NUMCONTRATO,'') FinanNoContrato,
	ISNULL(DVH_COMISIONFIN,0) FinanComision,
	ISNULL(DVH_IDVENDEDORFIN,'') FinanIDVendedor,
	
	-- Seguro
	ISNULL(DVH_SEGURO,0) Seguro,
	ISNULL(DVH_FECHASEG,'') SeguroIniFecha,
	ISNULL(DVH_PLAZOASEG,0) SeguroPlazo,
	ISNULL(DVH_ASEGURADORA,'') SeguroAseguradora,
	ISNULL(DVH_TIPOPOLI,'') SeguroTipoPoliza,
	ISNULL(DVH_NUMPOLI,'') SeguroNoPoliza,
	ISNULL(DVH_CVESEGURO,'') SeguroClave,
	ISNULL(DVH_SEGREGALO,0) SeguroRegalado,
	ISNULL(DVH_FORMAPAGOSEG,'') SeguroFormaPago,
	ISNULL(DVH_COMISIONASEG,0) SeguroComision,
	ISNULL(DVH_IDVENDEDORASEG,'') SeguroIDVendedor,
	
	-- Garantías
	ISNULL(DVH_FECHGARANDEFEN,'') GarantiaDefADefFecha,
	ISNULL(DVH_KMGARANDEFEN,0) GarantiaDefADefKm,
	ISNULL(DVH_FECHGARANMOTRIZ,'') GarantiaTrenMotizFecha,
	ISNULL(DVH_KMGARANMOTRIZ,0) GarantiaTrenMotizKm,
	ISNULL(DVH_FECHGARANMOTOR,'') GarantiaMotorFecha,
	ISNULL(DVH_KMGARANMOTOR,0) GarantiaMotorKm,
	
	-- Garantía extendida
	ISNULL(DVH_GARANEXT,0) GarExt,
	ISNULL(DVH_TIPOGARAN,'') GarExtTipo,
	ISNULL(DVH_REFERENCIAGARAN,'') GarExtReferencia,
	ISNULL(DVH_GARANREG,0) GarExtRegalado,
	ISNULL(DVH_FORMAPAGOGAN,'') GarExtFormaPago,
	ISNULL(DVH_MONTOGARAN,0) GarExtMonto,
	ISNULL(DVH_KILOMETRAJEGARAN,0) GarExtKm,
	ISNULL(DVH_FECHAINIGARAN,'') GarExtIniFecha,
	ISNULL(DVH_PLAZOGARAN,0) GarExtPlazo,
	ISNULL(DVH_COMISIONGARAN,0) GarExtComision,
	ISNULL(DVH_IDVENDEDORGARAN,'') GarExtIDVendedor
FROM
	UNI_DETVENTAVEHICULOS
go

