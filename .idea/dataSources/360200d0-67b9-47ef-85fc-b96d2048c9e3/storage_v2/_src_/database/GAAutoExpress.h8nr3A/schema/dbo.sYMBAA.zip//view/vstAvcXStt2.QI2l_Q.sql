CREATE VIEW [dbo].[vstAvcXStt2] AS SELECT pa.Pra_CveAge, pa.Pra_IdPersona, pp.Per_NomRazon + ' ' + pp.Per_Paterno + '' + pp.Per_Materno AS NomPros, isNull(vas.Seg_TipoSeg,'SIN SEGUIMIENTO') AS Seg_TipoSeg, pa.Pra_FecAlta, vas.seg_Fecha, vas.seg_Actividad, pa.Pra_Estatus FROM PYM_PROSPECACT pa LEFT OUTER JOIN vstAvcXStt1 vas ON pa.Pra_IdPersona = vas.SEG_PROSPECTO LEFT OUTER JOIN Per_Personas pp ON pp.Per_IdPersona = pa.Pra_IdPersona
go

