create view [dbo].[SER_PQPARTES] as select * from GAAutoexpressConcentra.dbo.SER_PQPARTES;
go

