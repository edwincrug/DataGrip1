create view [dbo].[CON_MOVDETfij012005] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETfij012005;
go

