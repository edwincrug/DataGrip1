create view [dbo].[CON_POL012007] as select * from GAAutoexpressConcentra.dbo.CON_POL012007;
go

