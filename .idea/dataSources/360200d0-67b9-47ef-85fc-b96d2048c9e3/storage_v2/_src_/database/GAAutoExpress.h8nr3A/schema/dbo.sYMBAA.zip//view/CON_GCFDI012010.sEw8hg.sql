create view [CON_GCFDI012010] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012010]
go

