
CREATE VIEW [dbo].[cxp_ordencompra]  AS  SELECT oce_folioorden, oce_iddivision, oce_idempresa, oce_idsucursal, oce_iddepartamento, oce_idtipoorden, oce_numcotizacion, oce_numeroflotilla, oce_imposicionplanta, oce_fechaorden, oce_horaorden, oce_importetotal, oce_idusuario, oce_motivocancelacion, oce_motivorechazo, sod_idsituacionorden, oce_anticipo, oce_cantidadanticipo, oce_porcentajeanticipo, oce_idusuariomovimiento, oce_idproveedor, oce_uuid, oce_factura, oce_consefolio, oce_foliopadre, oce_imptotalrecibido, oce_antaplicado, oce_numerolote, oce_txtgenerado, oce_idtipomoneda, oce_fechafactura, oce_fechapagounidad, oce_numautorizaplanta, oce_fechapagoanticipo, oce_polanticipo,oce_numsiniestro, oce_ordenglobal, oce_tareferencia,oce_foliointerno  FROM cuentasxpagar.dbo.cxp_ordencompra

go

