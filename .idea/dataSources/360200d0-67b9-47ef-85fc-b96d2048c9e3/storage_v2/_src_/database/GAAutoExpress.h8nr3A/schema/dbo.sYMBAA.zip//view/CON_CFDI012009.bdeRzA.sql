create view [dbo].[CON_CFDI012009] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012009;
go

