CREATE VIEW [dbo].[vstConPolDirErrAcAn] AS SELECT * FROM Con_PolDirErr012006
go

