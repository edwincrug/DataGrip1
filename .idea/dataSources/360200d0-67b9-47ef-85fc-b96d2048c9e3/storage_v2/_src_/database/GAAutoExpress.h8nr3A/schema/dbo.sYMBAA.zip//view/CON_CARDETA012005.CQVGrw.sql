create view [dbo].[CON_CARDETA012005] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012005;
go

