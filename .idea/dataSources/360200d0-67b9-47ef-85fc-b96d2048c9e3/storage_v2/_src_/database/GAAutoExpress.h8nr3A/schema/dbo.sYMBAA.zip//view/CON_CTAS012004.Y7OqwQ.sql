create view [dbo].[CON_CTAS012004] as select * from GAAutoexpressConcentra.dbo.CON_CTAS012004;
go

