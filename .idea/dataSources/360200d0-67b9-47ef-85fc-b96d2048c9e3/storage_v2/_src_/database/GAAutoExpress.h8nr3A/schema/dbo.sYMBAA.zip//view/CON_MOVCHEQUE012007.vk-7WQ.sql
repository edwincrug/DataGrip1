create view [dbo].[CON_MOVCHEQUE012007] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012007;
go

