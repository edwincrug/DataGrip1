create view [dbo].[CON_CTAS012003] as select * from GAAutoexpressConcentra.dbo.CON_CTAS012003;
go

