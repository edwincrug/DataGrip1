create view [dbo].[CON_CAR012013] as select * from GAAutoexpressConcentra.dbo.CON_CAR012013;
go

