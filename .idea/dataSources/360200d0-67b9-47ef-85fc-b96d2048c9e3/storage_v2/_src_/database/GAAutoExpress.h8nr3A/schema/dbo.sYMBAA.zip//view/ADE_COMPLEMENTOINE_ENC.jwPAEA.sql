create view [dbo].[ADE_COMPLEMENTOINE_ENC] as select * from GAAutoexpressConcentra.dbo.ADE_COMPLEMENTOINE_ENC;
go

