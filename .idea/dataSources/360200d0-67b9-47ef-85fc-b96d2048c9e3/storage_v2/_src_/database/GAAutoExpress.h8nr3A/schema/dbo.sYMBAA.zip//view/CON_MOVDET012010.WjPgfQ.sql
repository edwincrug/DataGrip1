create view [dbo].[CON_MOVDET012010] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012010;
go

