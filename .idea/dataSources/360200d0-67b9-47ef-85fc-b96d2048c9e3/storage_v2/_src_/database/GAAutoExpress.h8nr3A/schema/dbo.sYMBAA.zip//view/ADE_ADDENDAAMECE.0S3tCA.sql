create view [dbo].[ADE_ADDENDAAMECE] as select * from GAAutoexpressConcentra.dbo.ADE_ADDENDAAMECE;
go

