create view [dbo].[ADE_CFDEMIREC] as select * from GAAutoexpressConcentra.dbo.ADE_CFDEMIREC;
go

