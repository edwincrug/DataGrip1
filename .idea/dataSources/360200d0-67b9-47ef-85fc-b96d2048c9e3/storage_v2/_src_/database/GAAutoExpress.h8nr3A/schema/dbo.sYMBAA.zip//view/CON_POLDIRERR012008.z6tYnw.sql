create view [dbo].[CON_POLDIRERR012008] as select * from GAAutoexpressConcentra.dbo.CON_POLDIRERR012008;
go

