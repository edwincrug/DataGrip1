create view [dbo].[CON_MOVCHEQUE012014] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012014;
go

