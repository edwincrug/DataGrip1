create view [dbo].[CON_CFDI012006] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012006;
go

