create view [dbo].[CON_MOVTRANSFER012013] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012013;
go

