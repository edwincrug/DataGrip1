create view [dbo].[UNI_PLANBONI] as select * from GAAutoexpressConcentra.dbo.UNI_PLANBONI;
go

