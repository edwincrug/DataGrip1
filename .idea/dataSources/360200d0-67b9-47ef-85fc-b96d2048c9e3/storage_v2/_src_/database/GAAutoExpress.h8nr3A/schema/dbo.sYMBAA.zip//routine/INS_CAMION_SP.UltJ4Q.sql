


CREATE PROCEDURE [dbo].[INS_CAMION_SP] (
	@idModelo numeric(18,0),
	@idTipoCamion numeric(18,0),
	@vin nvarchar(50),
	@motor nvarchar(50),
	@placa nvarchar(50),
	@rendimiento  decimal(18,2),
	@idCaja numeric(18,0),
	@idTransmision numeric(18,0),
	@idCilindros numeric(18,0),
	@idCombustible numeric(18,0),
	@tanque nvarchar(50)
)
as
begin

	INSERT INTO dbo.Camion
		( idModelo, idTipoCamion, vin, motor, placa, rendimiento, estatus, idTransmision, idCilindros, idCombustible, tanque)
	VALUES 
		(@idModelo ,@idTipoCamion , @vin, @motor,@placa, @rendimiento, 1, @idTransmision, @idCilindros, @idCombustible, @tanque)
		
	DECLARE @idCamion as numeric(18,0)
	SELECT @idCamion = @@IDENTITY
		
	IF (@idCaja IS NOT NULL) BEGIN
		INSERT INTO dbo.CamionCaja
			(idCamion, idCaja, estatus,fecha)
		VALUES 
			(@idCamion, @idCaja , 1 , GETDATE())
	END
	
	SELECT @@IDENTITY

end
go

