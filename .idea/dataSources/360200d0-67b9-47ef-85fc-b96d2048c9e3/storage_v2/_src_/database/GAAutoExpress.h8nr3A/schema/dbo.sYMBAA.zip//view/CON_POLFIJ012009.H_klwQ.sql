create view [dbo].[CON_POLFIJ012009] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012009;
go

