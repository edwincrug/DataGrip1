create view [dbo].[cat_claveunidad] as select * from GAAutoexpressConcentra.dbo.cat_claveunidad;
go

