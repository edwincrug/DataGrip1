create view [dbo].[CON_POLFIJ012008] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012008;
go

