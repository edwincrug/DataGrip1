CREATE VIEW [dbo].[sicop_qry_catalogo_modelos]
AS
SELECT     UNC_IDCATALOGO AS Clave_modelo, UNC_DESCRIPCION AS Nombre_Modelo, UNC_PRECLISTA AS Precio_Modelo
FROM         dbo.UNI_CATALOGO

