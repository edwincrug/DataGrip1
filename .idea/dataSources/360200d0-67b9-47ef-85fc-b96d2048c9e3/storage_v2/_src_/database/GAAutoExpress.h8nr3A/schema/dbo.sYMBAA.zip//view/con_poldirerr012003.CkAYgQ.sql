create view [dbo].[con_poldirerr012003] as select * from GAAutoexpressConcentra.dbo.con_poldirerr012003;
go

