create view [CON_GCFDI012005] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012005]
go

