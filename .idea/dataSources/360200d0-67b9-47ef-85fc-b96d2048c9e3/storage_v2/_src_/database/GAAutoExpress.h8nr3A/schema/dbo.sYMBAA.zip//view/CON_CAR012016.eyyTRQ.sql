create view [dbo].[CON_CAR012016] as select * from GAAutoexpressConcentra.dbo.CON_CAR012016;
go

