create view [dbo].[CON_CAR012008] as select * from GAAutoexpressConcentra.dbo.CON_CAR012008;
go

