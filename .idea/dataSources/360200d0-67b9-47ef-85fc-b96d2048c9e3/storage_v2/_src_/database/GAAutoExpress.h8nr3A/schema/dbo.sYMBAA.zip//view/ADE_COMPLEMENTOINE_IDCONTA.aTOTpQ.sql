create view [dbo].[ADE_COMPLEMENTOINE_IDCONTA] as select * from GAAutoexpressConcentra.dbo.ADE_COMPLEMENTOINE_IDCONTA;
go

