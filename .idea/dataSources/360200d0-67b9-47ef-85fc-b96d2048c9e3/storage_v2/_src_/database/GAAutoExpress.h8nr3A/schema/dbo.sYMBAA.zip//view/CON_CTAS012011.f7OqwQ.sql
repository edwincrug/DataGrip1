create view [dbo].[CON_CTAS012011] as select * from GAAutoexpressConcentra.dbo.CON_CTAS012011;
go

