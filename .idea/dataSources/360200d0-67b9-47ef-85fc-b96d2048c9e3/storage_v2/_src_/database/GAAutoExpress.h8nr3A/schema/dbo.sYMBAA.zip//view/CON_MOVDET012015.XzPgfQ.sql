create view [dbo].[CON_MOVDET012015] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012015;
go

