create view [dbo].[ADE_COMPLEMENTOEXP_ENC] as select * from GAAutoexpressConcentra.dbo.ADE_COMPLEMENTOEXP_ENC;
go

