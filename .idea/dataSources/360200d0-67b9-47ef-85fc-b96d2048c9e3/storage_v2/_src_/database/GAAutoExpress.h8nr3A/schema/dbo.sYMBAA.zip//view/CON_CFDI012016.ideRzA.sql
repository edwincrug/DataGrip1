create view [dbo].[CON_CFDI012016] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012016;
go

