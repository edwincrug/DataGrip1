create view [dbo].[CON_CFDI012014] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012014;
go

