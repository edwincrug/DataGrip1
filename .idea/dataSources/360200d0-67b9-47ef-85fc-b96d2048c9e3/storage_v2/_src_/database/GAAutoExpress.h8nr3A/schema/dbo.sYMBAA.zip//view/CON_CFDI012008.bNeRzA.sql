create view [dbo].[CON_CFDI012008] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012008;
go

