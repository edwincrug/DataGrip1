
CREATE VIEW [dbo].[CON_CancelaSATEnc] AS SELECT * FROM GAAutoexpressConcentra.dbo.CON_CancelaSATEnc
go

