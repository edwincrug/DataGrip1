create view [dbo].[CON_MOVCHEQUE012011] as select * from GAAutoexpressConcentra.dbo.CON_MOVCHEQUE012011;
go

