create view [dbo].[con_poldirerr012004] as select * from GAAutoexpressConcentra.dbo.con_poldirerr012004;
go

