create view [CON_GCFDI012008] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012008]
go

