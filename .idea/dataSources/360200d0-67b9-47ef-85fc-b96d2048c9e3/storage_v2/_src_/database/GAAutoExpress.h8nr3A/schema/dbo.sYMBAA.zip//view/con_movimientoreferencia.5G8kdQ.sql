CREATE VIEW [dbo].[con_movimientoreferencia] AS SELECT * From GAAutoexpressConcentra.dbo.con_movimientoreferencia
go

