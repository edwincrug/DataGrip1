create view [dbo].[ADE_COMPLEMENTOINE_ENTIDAD] as select * from GAAutoexpressConcentra.dbo.ADE_COMPLEMENTOINE_ENTIDAD;
go

