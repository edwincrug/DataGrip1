CREATE VIEW [dbo].[vstAvcXStt3] AS SELECT Seg_TipoSeg, count(Seg_TipoSeg) AS CantStt FROM vstAvcXStt2 GROUP BY Seg_TipoSeg
go

