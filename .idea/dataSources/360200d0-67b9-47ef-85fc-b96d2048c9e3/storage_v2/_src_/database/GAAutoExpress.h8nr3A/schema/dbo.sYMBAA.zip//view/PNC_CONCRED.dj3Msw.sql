create view [dbo].[PNC_CONCRED] as select * from GAAutoexpressConcentra.dbo.PNC_CONCRED;
go

