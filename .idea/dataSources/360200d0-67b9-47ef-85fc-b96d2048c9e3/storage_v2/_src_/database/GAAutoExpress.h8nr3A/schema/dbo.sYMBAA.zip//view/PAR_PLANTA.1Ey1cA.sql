create view [dbo].[PAR_PLANTA] as select * from GAAutoexpressConcentra.dbo.PAR_PLANTA;
go

