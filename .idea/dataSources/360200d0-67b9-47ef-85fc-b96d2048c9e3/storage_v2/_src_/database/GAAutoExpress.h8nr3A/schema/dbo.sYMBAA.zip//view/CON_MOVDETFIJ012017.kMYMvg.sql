create view [dbo].[CON_MOVDETFIJ012017] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012017;
go

