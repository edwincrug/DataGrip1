create view [dbo].[CON_POL012008] as select * from GAAutoexpressConcentra.dbo.CON_POL012008;
go

