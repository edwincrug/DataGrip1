
Create VIEW [dbo].[SER_PAQUESER] as select * from GAAutoexpressConcentra.[dbo].SER_PAQUESER
go

