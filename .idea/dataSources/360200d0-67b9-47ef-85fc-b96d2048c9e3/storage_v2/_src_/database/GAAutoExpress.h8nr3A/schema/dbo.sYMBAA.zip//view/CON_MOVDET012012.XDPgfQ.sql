create view [dbo].[CON_MOVDET012012] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012012;
go

