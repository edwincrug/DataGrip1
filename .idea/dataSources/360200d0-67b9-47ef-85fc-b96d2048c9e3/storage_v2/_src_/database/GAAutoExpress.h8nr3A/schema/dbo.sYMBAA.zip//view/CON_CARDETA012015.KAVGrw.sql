create view [dbo].[CON_CARDETA012015] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012015;
go

