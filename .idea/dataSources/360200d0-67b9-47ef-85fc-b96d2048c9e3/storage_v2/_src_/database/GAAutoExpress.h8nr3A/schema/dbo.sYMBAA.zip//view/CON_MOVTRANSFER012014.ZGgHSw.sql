create view [dbo].[CON_MOVTRANSFER012014] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012014;
go

