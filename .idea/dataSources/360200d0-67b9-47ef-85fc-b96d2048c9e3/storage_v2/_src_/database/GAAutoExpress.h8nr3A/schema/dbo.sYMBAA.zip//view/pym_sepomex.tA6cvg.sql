create view [dbo].[pym_sepomex] as select * from GAAutoexpressConcentra.dbo.pym_sepomex;
go

