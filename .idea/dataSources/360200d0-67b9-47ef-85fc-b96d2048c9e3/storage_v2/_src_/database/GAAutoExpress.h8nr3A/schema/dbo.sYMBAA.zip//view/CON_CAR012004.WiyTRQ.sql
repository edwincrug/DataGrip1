create view [dbo].[CON_CAR012004] as select * from GAAutoexpressConcentra.dbo.CON_CAR012004;
go

