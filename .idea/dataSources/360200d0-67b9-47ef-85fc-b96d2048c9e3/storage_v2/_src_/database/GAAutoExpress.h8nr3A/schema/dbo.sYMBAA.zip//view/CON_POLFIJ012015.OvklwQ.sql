create view [dbo].[CON_POLFIJ012015] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012015;
go

