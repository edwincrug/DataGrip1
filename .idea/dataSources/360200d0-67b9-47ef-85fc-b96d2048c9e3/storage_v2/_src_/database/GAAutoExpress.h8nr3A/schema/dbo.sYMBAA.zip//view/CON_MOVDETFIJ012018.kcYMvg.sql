create view [dbo].[CON_MOVDETFIJ012018] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012018;
go

