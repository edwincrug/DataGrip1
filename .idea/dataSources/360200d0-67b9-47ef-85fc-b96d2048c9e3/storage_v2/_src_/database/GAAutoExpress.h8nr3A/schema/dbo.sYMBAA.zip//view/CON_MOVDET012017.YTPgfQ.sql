create view [dbo].[CON_MOVDET012017] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012017;
go

