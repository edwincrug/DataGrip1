create view [dbo].[UNI_CATADETA] as select * from GAAutoexpressConcentra.dbo.UNI_CATADETA;
go

