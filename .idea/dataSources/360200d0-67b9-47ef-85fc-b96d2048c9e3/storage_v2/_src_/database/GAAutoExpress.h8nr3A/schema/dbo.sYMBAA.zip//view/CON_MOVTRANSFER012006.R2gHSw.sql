create view [dbo].[CON_MOVTRANSFER012006] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012006;
go

