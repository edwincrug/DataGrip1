create view [dbo].[PAR_LINEASDET] as select * from GAAutoexpressConcentra.dbo.PAR_LINEASDET;
go

