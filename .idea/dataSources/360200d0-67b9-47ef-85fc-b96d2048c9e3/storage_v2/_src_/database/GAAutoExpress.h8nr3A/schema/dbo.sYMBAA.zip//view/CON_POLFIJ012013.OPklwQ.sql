create view [dbo].[CON_POLFIJ012013] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012013;
go

