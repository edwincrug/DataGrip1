create view [dbo].[CON_MOVTRANSFER012011] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012011;
go

