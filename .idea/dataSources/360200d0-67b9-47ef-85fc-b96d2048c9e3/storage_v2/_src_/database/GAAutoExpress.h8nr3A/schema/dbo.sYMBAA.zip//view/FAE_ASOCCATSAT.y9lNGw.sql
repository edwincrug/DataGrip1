create view [dbo].[FAE_ASOCCATSAT] as select * from GAAutoexpressConcentra.dbo.FAE_ASOCCATSAT;
go

