create view [dbo].[ADE_CFDITIMBRADO] as select * from GAAutoexpressConcentra.dbo.ADE_CFDITIMBRADO;
go

