create view [CON_GCFDI012014] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012014]
go

