create view [dbo].[CON_CARDETA012006] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012006;
go

