
create view [dbo].[PAR_PARTES] as select * from GAAutoexpressConcentra.dbo.PAR_PARTES;
go

