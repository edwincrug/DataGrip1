


CREATE PROCEDURE [dbo].[SEL_CAMION_SP] (
	@idUsuario numeric(18,0)
)
as
begin

	SELECT 
		cam.idCamion,
		cam.idModelo,
		mod.anio as modelo,
		mod.tonelaje,
		sma.idSubMarca,
		sma.nombre as subMarca,
		mar.idMarca,
		mar.nombre as marca,
		cam.idTipoCamion,
		tca.tipo as tipoCamion,
		cam.vin,
		cam.motor,
		cam.placa,
		cam.rendimiento,
		cam.estatus,
		cca.idCaja,
		case when caj.vin is null then 'NO' else 'SI' end as caja,
		caj.placa as placacaja,
		tra.idTransmision,
		tra.transmision,
		cil.idCilindros,
		cil.cilindros,
		com.idCombustible,
		com.combustible,
		cam.tanque
	FROM
		dbo.Camion cam
	LEFT JOIN dbo.Modelo mod ON mod.idModelo = cam.idModelo
	LEFT JOIN dbo.SubMarca sma ON sma.idSubMarca = mod.idSubmarca
	LEFT JOIN dbo.Marca mar ON mar.idMarca = sma.idMarca
	LEFT JOIN dbo.TipoCamion tca ON tca.idTipoCamion = cam.idTipoCamion
	LEFT JOIN dbo.CamionCaja cca ON cca.idCamion = cam.idCamion AND cca.estatus = 1
	LEFT JOIN dbo.Caja caj ON caj.idCaja = cca.idCaja
	LEFT JOIN dbo.Transmision tra on tra.idTransmision = cam.idTransmision
	LEFT JOIN dbo.Cilindros cil on cil.idCilindros = cam.idCilindros
	LEFT JOIN dbo.Combustible com on com.idCombustible = cam.idCombustible
	WHERE 
		cam.estatus = 1

end
go

