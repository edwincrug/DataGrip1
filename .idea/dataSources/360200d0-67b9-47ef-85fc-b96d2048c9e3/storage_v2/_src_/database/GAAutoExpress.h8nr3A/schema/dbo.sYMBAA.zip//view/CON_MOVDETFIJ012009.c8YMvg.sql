create view [dbo].[CON_MOVDETFIJ012009] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012009;
go

