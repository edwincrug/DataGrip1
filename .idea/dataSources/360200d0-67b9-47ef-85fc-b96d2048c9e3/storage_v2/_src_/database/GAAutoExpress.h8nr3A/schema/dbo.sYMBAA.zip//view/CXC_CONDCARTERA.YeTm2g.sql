create view [dbo].[CXC_CONDCARTERA] as select * from GAAutoexpressConcentra.dbo.CXC_CONDCARTERA;
go

