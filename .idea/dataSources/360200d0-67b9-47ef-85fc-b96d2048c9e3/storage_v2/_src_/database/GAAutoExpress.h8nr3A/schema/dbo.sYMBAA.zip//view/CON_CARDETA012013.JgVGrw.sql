create view [dbo].[CON_CARDETA012013] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012013;
go

