create view [dbo].[CXC_CONDCRED] as select * from GAAutoexpressConcentra.dbo.CXC_CONDCRED;
go

