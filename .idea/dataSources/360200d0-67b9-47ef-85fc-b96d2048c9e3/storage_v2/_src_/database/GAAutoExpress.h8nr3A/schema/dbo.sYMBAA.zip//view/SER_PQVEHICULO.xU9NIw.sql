create view [dbo].[SER_PQVEHICULO] as select * from GAAutoexpressConcentra.dbo.SER_PQVEHICULO;
go

