create view [dbo].[CON_CARDETA012010] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012010;
go

