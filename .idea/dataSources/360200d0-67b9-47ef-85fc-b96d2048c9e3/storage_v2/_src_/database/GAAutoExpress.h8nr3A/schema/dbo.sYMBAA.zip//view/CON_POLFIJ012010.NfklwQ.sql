create view [dbo].[CON_POLFIJ012010] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012010;
go

