create view [dbo].[CON_CARCON012018] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012018;
go

