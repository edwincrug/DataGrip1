create view [dbo].[CON_CFDI012017] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012017;
go

