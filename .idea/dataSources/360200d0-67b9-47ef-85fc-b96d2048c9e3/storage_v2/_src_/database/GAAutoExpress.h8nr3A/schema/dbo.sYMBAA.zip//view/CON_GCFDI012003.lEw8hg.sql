create view [CON_GCFDI012003] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012003]
go

