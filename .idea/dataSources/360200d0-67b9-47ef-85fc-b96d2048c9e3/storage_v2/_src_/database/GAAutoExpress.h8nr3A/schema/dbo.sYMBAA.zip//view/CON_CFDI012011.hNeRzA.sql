create view [dbo].[CON_CFDI012011] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012011;
go

