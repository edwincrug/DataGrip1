create view [dbo].[ADE_ADDENDASCONFIG] as select * from GAAutoexpressConcentra.dbo.ADE_ADDENDASCONFIG;
go

