create view [dbo].[CON_CARDETACON012016] as select * from GAAutoexpressConcentra.dbo.CON_CARDETACON012016;
go

