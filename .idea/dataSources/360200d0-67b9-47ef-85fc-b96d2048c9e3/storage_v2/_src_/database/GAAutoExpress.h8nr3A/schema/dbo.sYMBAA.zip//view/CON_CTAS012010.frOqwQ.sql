create view [dbo].[CON_CTAS012010] as select * from GAAutoexpressConcentra.dbo.CON_CTAS012010;
go

