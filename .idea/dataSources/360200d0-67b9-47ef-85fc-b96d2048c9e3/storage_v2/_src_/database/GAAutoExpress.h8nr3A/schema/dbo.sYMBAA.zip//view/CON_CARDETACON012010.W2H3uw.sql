create view [dbo].[CON_CARDETACON012010] as select * from GAAutoexpressConcentra.dbo.CON_CARDETACON012010;
go

