create view [dbo].[PER_UNIFICA] as select * from GAAutoexpressConcentra.dbo.PER_UNIFICA;
go

