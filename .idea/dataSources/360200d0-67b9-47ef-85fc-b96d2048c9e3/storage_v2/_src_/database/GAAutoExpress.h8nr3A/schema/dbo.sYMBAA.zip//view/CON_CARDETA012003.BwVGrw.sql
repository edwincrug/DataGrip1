create view [dbo].[CON_CARDETA012003] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012003;
go

