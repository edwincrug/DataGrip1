create view [dbo].[CON_CARDETA012017] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012017;
go

