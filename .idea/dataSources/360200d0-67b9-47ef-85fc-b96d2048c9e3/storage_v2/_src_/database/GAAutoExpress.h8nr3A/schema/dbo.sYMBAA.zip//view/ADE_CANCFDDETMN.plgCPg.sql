create view [dbo].[ADE_CANCFDDETMN] as select * from GAAutoexpressConcentra.dbo.ADE_CANCFDDETMN;
go

