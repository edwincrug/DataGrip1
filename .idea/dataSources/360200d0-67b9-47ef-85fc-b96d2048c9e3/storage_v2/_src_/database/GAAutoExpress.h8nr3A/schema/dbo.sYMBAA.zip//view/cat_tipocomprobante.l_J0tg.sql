create view [dbo].[cat_tipocomprobante] as select * from GAAutoexpressConcentra.dbo.cat_tipocomprobante;
go

