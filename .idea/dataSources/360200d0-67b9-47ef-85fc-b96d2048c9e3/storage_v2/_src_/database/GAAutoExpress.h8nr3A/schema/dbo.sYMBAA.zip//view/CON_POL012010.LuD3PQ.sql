create view [dbo].[CON_POL012010] as select * from GAAutoexpressConcentra.dbo.CON_POL012010;
go

