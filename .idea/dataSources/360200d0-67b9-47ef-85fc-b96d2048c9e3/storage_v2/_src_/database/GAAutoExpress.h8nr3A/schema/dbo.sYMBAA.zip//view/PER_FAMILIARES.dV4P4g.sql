create view [dbo].[PER_FAMILIARES] as select * from GAAutoexpressConcentra.dbo.PER_FAMILIARES;
go

