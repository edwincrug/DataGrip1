create view [dbo].[SER_PQACTALLER] as select * from GAAutoexpressConcentra.dbo.SER_PQACTALLER;
go

