create view [dbo].[CON_CARDETACON012018] as select * from GAAutoexpressConcentra.dbo.CON_CARDETACON012018;
go

