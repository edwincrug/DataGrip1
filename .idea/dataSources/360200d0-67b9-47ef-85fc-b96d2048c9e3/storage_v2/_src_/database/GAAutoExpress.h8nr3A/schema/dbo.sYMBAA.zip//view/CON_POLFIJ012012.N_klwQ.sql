create view [dbo].[CON_POLFIJ012012] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012012;
go

