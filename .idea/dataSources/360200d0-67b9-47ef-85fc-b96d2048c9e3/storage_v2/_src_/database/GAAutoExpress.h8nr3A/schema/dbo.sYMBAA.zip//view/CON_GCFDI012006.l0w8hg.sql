create view [CON_GCFDI012006] as select * from [GAAutoexpressConcentra].dbo.[CON_GCFDI012006]
go

