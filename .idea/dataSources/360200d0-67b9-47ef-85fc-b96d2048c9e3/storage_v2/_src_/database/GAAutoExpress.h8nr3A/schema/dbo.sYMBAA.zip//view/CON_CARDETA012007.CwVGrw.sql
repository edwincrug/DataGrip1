create view [dbo].[CON_CARDETA012007] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012007;
go

