create view [dbo].[CON_CAR012017] as select * from GAAutoexpressConcentra.dbo.CON_CAR012017;
go

