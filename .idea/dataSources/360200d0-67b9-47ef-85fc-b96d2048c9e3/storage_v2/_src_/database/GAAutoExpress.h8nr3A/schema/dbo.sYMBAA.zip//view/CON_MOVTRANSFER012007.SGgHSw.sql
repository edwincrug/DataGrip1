create view [dbo].[CON_MOVTRANSFER012007] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012007;
go

