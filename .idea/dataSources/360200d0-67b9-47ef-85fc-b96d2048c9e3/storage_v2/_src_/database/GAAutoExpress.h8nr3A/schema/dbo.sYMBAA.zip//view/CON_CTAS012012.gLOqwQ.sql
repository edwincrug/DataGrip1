create view [dbo].[CON_CTAS012012] as select * from GAAutoexpressConcentra.dbo.CON_CTAS012012;
go

