create view [dbo].[CON_CATPOLSAT] as select * from GAAutoexpressConcentra.dbo.CON_CATPOLSAT;
go

