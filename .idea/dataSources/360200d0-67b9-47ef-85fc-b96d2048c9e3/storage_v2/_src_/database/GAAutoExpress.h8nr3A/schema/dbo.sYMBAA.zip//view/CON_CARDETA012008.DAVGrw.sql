create view [dbo].[CON_CARDETA012008] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012008;
go

