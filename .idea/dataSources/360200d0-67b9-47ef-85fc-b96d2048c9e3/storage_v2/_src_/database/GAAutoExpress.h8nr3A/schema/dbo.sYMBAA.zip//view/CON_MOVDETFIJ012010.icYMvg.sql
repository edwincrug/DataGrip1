create view [dbo].[CON_MOVDETFIJ012010] as select * from GAAutoexpressConcentra.dbo.CON_MOVDETFIJ012010;
go

