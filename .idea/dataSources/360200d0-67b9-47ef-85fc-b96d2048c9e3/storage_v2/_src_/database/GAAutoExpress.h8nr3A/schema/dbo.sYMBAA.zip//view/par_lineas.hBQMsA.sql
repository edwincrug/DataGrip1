create view [dbo].[par_lineas] as select * from GAAutoexpressConcentra.dbo.par_lineas
go

