create view [dbo].[CON_POLFIJ012018] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012018;
go

