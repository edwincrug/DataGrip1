create view [dbo].[CON_MOVDET012008] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012008;
go

