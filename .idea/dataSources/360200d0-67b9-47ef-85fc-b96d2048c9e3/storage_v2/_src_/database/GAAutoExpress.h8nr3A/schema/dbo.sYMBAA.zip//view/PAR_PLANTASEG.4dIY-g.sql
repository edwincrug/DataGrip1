create view [dbo].[PAR_PLANTASEG] as select * from GAAutoexpressConcentra.dbo.PAR_PLANTASEG;
go

