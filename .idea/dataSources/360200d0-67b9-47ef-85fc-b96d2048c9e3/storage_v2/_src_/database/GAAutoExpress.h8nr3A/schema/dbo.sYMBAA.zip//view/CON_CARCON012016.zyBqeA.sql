create view [dbo].[CON_CARCON012016] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012016;
go

