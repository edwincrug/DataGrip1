create view [dbo].[CON_POL012012] as select * from GAAutoexpressConcentra.dbo.CON_POL012012;
go

