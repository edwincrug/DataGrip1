/*
***************************************************************************************************************
**		Nombre del SP 	: 	sp_ordenesdegastocentralizadas 
**		Fecha creación	: 	07/05/2020
**		Elaboró			: 	IGM
**		Modificación	:	Fecha				Responsable		Descripción
**							13/05/2020			IGM				Actualización
**							21/05(2020			IGM				Validación de que se tenga detalle en pre_pedidogastosdet
**							12/06/2020			JRHD			Agregar campo de área de afectación y persona que autoriza
**		Descripción		: 	
**		Datos de entrada:   @pedido 	- Indica el número de pedido							
**		Datos de salida	:	@msg = 0	- La transacción fue exitosa, 1 - Existío un error
**							@TextoMsg	- Indica el mensaje de error generado. Si todo es correcto regresa valor nulo
**							
**		
***************************************************************************************************************
*/
--USE [GAAutoExpress]

CREATE  PROCEDURE sp_ordenesdegastocentralizadas
    @pedido		AS	int					-- El número de pedido	
--	@msg		AS int OUTPUT,			-- 0 - La transacción fue exitosa, 1 - Existío un error
--	@TextoMsg	AS VARCHAR(500) OUTPUT	-- Mensaje del error que genera.
AS
BEGIN
	declare @vPER_RFC					AS varchar(50)
--	declare @msg						AS int
--	declare @TextoMsg					AS varchar(500)
	
	declare @oce_folioorden				AS	varchar(50)
	declare @oce_iddivision				AS	int
	declare @oce_idempresa				AS	int
	declare @oce_idsucursal				AS	int
	declare	@oce_iddepartamento			AS	int
	declare @oce_tipoorden				AS	int
	declare	@oce_importetotal			AS  decimal(18,6)
	declare	@oce_idproveedor			AS	int
	declare @oce_consefolio				AS	int
	declare	@oce_importetotalrecibido	AS  decimal(18,6)
	declare @oce_idusuario				AS	int
	declare @oce_situacionorden			AS	int

	declare	@proceso					AS  varchar(4)	
	declare @agencia					AS	varchar(25)
	declare	@cantidaddetalle			AS	int
	declare @Idusuarioaut               As varchar(20)
	
	
    SET NOCOUNT ON;

	/*
	========================================
	==  Validamos que haya detalle en la tabla pre_pedidogastosdet
	========================================
	*/

	select @cantidaddetalle = count(*)
	from	[cuentasxpagar].[dbo].[pre_pedidogastosdet]  
	where	 ppg_idprepedidogastos = @pedido  
  
	IF @cantidaddetalle >= 1 -- Se cuenta con registros de detalle
	BEGIN
		/*
		========================================
		==  Consulta de valores tabla cxp_ordencompra
		========================================
		*/

		----------------------------------------
		-- Columna oce_folioorden
		----------------------------------------

		select 
			@oce_folioorden = 
			(
				select cd.div_nombrecto
				from [ControlAplicaciones].[dbo].[cat_divisiones] cd
				where cd.div_iddivision in
					(select cs.div_iddivision
					from [ControlAplicaciones].[dbo].[cat_sucursales] cs
					where cs.suc_idsucursal= ppg_idsucursal)
			) + '-' +
			(
				select ce.emp_nombrecto	
				from [ControlAplicaciones].[dbo].[cat_empresas] ce
				where ce.emp_idempresa in
					(select cs.emp_idempresa
					from [ControlAplicaciones].[dbo].[cat_sucursales] cs
					where cs.suc_idsucursal= ppg_idsucursal)
			) +  '-' +
			(
				select cs.suc_nombrecto
				from [ControlAplicaciones].[dbo].[cat_sucursales] cs
				where cs.suc_idsucursal= ppg_idsucursal
			) +  '-' +
			'OT' +  '-' +
			'PE' +  '-' +
			(
				select cast((isnull(max(oce_consefolio),0) + 1) as varchar(10))
				from cxp_ordencompra
				where oce_idempresa in 
					(select cs.emp_idempresa
					from [ControlAplicaciones].[dbo].[cat_sucursales] cs
					where cs.suc_idsucursal= ppg_idsucursal)
				and oce_idtipoorden in 
					(select cto.tip_idtipoorden
					from [cuentasxpagar].[dbo].[cat_tiposorden] cto
					where cto.tip_nombrecorto = 'PE' )
			)
		from [cuentasxpagar].[dbo].[pre_pedidogastos]
		where ppg_idprepedidogastos = @pedido

		----------------------------------------
		-- Columna oce_iddivision
		----------------------------------------

		select 
			@oce_iddivision = 
			(
				select cd.div_iddivision
				from [ControlAplicaciones].[dbo].[cat_divisiones] cd
				where cd.div_iddivision in
					(select cs.div_iddivision
					from [ControlAplicaciones].[dbo].[cat_sucursales] cs
					where cs.suc_idsucursal= ppg_idsucursal )
			) 
		from [cuentasxpagar].[dbo].[pre_pedidogastos]
		where ppg_idprepedidogastos = @pedido


		----------------------------------------
		-- Columna para la sumatoria de los importe total
		----------------------------------------

		select 
			@oce_importetotal = 
			(
				select (sum((ppd_cantidad * ppd_preciounitario) - ppd_descuento) * (ppg_tasaiva / 100)) + sum((ppd_cantidad * ppd_preciounitario) - ppd_descuento)
				from [cuentasxpagar].[dbo].[pre_pedidogastosdet] pgd
				where pg.ppg_idprepedidogastos = pgd.ppg_idprepedidogastos
			) 
		from [cuentasxpagar].[dbo].[pre_pedidogastos] pg
		where ppg_idprepedidogastos = @pedido

		----------------------------------------
		-- Columna para la sumatoria de los importe total recibido
		----------------------------------------

		select 
			@oce_importetotalrecibido = 
			(
				select (sum((ppd_cantidad * ppd_preciounitario) - ppd_descuento) * (ppg_tasaiva / 100)) + sum((ppd_cantidad * ppd_preciounitario) - ppd_descuento)
				from [cuentasxpagar].[dbo].[pre_pedidogastosdet] pgd
				where pg.ppg_idprepedidogastos = pgd.ppg_idprepedidogastos
			) 
		from [cuentasxpagar].[dbo].[pre_pedidogastos] pg
		where ppg_idprepedidogastos = @pedido



		----------------------------------------
		-- Columna oce_idempresa, oce_idsucursal, oce_idpproveedor, oce_idproveedor
		----------------------------------------

		select 
			@oce_idempresa				=	ppg_idempresa,
			@oce_idsucursal				=	ppg_idsucursal,
			@oce_idproveedor			=	ppg_idproveedor,
			@oce_idusuario				=	ppg_usuariogenera
		from [cuentasxpagar].[dbo].[pre_pedidogastos]
		where ppg_idprepedidogastos = @pedido

		----------------------------------------
		-- Columna oce_iddepartamento
		----------------------------------------

		select	@oce_iddepartamento = cd.dep_iddepartamento 
		from	[ControlAplicaciones].[dbo].[cat_departamentos] cd,
				[cuentasxpagar].[dbo].[pre_pedidogastos] pg
		where	pg.ppg_idprepedidogastos = @pedido
		and		pg.ppg_idempresa	= cd.emp_idempresa
		and		pg.ppg_idsucursal	= cd.suc_idsucursal
		and		cd.dep_nombrecto = 'OT'


		----------------------------------------
		-- Columna oce_tipoorden
		----------------------------------------

		select 
			@oce_tipoorden = 
			(
				select cto.tip_idtipoorden
				from [cuentasxpagar].[dbo].[cat_tiposorden] cto
				where cto.tip_nombrecorto = 'PE' 
			)

		from [cuentasxpagar].[dbo].[pre_pedidogastos]
		where ppg_idprepedidogastos = @pedido
	
	
		----------------------------------------
		-- Columna oce_idsituacionorden
		----------------------------------------

		select @oce_situacionorden = sod_idsituacionorden
		from [cuentasxpagar].[dbo].[cat_situacionorden]
		where  sod_nombrecto = 'PEAUT'


		----------------------------------------
		-- Columna oce_consefolio
		----------------------------------------

		select 
			@oce_consefolio = 
			(
				select isnull(max(oce_consefolio),0) + 1
				from cxp_ordencompra
				where oce_idempresa in 
					(select cs.emp_idempresa
					from [ControlAplicaciones].[dbo].[cat_sucursales] cs
					where cs.suc_idsucursal= ppg_idsucursal)
				and oce_idtipoorden in 
					(select cto.tip_idtipoorden
					from [cuentasxpagar].[dbo].[cat_tiposorden] cto
					where cto.tip_nombrecorto = 'PE' )
			)

		from [cuentasxpagar].[dbo].[pre_pedidogastos]
		where ppg_idprepedidogastos = @pedido

       -----------------------------------------------
	   ----Id usuario aurtoriza
	   ----------------------------------------------

	  set  @IdUsuarioaut= (select top 1 eqv_usubusiness from ControlAplicaciones.dbo.eqv_organigrama
	   INNER JOIN cuentasxpagar.dbo.pre_pedidogastos on usu_usuario = ppg_idusuarioautoriza)
	  
  
		BEGIN TRY
	
			BEGIN TRANSACTION
	
			/*
			========================================
			==  Insercción valores de la tabla cxp_ordencompra
			========================================
			*/

				INSERT INTO [cuentasxpagar].[dbo].[cxp_ordencompra]
				(
					oce_folioorden,
					oce_iddivision,
					oce_idempresa,
					oce_idsucursal,
					oce_iddepartamento,
					oce_idtipoorden,			
					oce_numeroflotilla,
					oce_imposicionplanta,
					oce_fechaorden,	
					oce_horaorden,		
					oce_importetotal,				
					oce_idusuario,
					sod_idsituacionorden,			
					oce_anticipo,				
					oce_cantidadanticipo,
					oce_porcentajeanticipo,				
					oce_idusuariomovimiento,
					oce_idproveedor,			
					oce_factura,				
					oce_consefolio,				
					oce_imptotalrecibido,			
					oce_idtipomoneda,			
					oce_fechafactura,				
					oce_escentralizada
				
				)
				VALUES
				(
					@oce_folioorden,
					@oce_iddivision,
					@oce_idempresa,
					@oce_idsucursal,
					@oce_iddepartamento,
					@oce_tipoorden,				
					0,
					0,				
					CONVERT (date, GETDATE()),
					CONVERT (time, GETDATE()),	
					@oce_importetotal,
					@oce_idusuario,
					@oce_situacionorden,
					0,
					0,
					0,
					@oce_idusuario,
					@oce_idproveedor,
					@oce_folioorden,
					@oce_consefolio,
					@oce_importetotalrecibido,
					'PE',
					GETDATE(),
					1
				)


			/*
			========================================
			==  Inserta valores en la tabla cxp_detalleotrosconceptos (Nota: en esta tabla hay mas de 1 registro
			==	asociado
			========================================
			*/

				INSERT INTO [cuentasxpagar].[dbo].[cxp_detalleotrosconceptos]
				(
					otc_cantidad,
					otc_cantidadrecibida,
					otc_cveusurecep,
					otc_producto,
					otc_preuni,
					otc_preuniinicial,
					otc_descuento,
					otc_iva,
					otc_total,
					otc_totalinicial,
					oce_folioorden,
					otc_cveusu,
					otc_fechope,
					otc_poriva,
					otc_retiva,
					otc_retisr,
					otc_iddocto,
					otc_idsituacionordendet,
					otc_fechapromentrega,
					otc_horapromentrega,
					otc_cantidaddiferencia,
					otc_consecutivo,
					otc_saldocuentames,
					otc_presupuestomes,
					otc_excedentemes,
					otc_saldocuentaanio,
					otc_presupuestoanio,
					otc_excedenteanio,
					otc_comentarios,
					otc_concepto,
					otc_nopedido
				)
				SELECT	pgd.ppd_cantidad,
					0,
					pg.ppg_usuariogenera,
					pgd.ppd_producto,
					pgd.ppd_preciounitario,
					pgd.ppd_preciounitario,
					pgd.ppd_descuento,
					((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento) * (pg.ppg_tasaiva / 100),
					((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento) * (pg.ppg_tasaiva / 100) + ((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento),
					((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento) * (pg.ppg_tasaiva / 100) + ((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento),
					@oce_folioorden,
					pg.ppg_usuariogenera,
					pg.ppg_fechaorden,
					pg.ppg_tasaiva,
					0,
					0,
					'',
					@oce_situacionorden,
					pg.ppg_fechaorden,
					CONVERT (time, GETDATE()),
					0,
					ROW_NUMBER() OVER(ORDER BY @oce_folioorden ASC),
					0,
					0,
					0,
					0,
					0,
					0,
					pg.ppg_observaciones,
					'',
					(
						select max(poc_idpedido) + 1
						from [con_pedotros]
					)

				FROM	[cuentasxpagar].[dbo].[pre_pedidogastosdet] pgd,
						[cuentasxpagar].[dbo].[pre_pedidogastos] pg
				WHERE	pgd.ppg_idprepedidogastos = pg.ppg_idprepedidogastos
				AND		pgd.ppg_idprepedidogastos = @pedido



			/*
			========================================
			==  Inserta valores en la tabla cxp_movimientosorden
			========================================
			*/

				INSERT INTO [cuentasxpagar].[dbo].[cxp_movimientosorden]
				(
					mov_idusuariomovimiento,
					mov_fechamovimiento,
					mov_horamovimiento,
					oce_folioorden,
					sod_idsituacionorden
				)
				SELECT	ppg_usuariogenera,
						ppg_fechaorden,
						CONVERT (time, GETDATE()),
						@oce_folioorden,
						@oce_situacionorden

				FROM	[cuentasxpagar].[dbo].[pre_pedidogastos]
				WHERE	ppg_idprepedidogastos = @pedido

	
			/*
			========================================
			==  Inserta valores en la tabla  con_pedotros
			========================================
			*/

				INSERT INTO [con_pedotros]
				(
					poc_area,
					poc_solarea,
					poc_autoarea,
					poc_factura,
					poc_status,
					poc_fecfactura,
					poc_fecorden,
					poc_subtotal,
					poc_iva,
					poc_descuento,
					poc_total,
					poc_proveedor,
					poc_poriva,
					poc_observaciones,
					poc_cvusuario,
					poc_fechope,
					poc_idcancela,
					POC_IDFACTUR,
					POC_FECFACTUR,
					poc_ieps,
					poc_comprobante,
					POC_TPOCAMB,
					POC_IDMONEDA,
					poc_folioorden,
					poc_anticipo,
					poc_cantidadanticipo,
					poc_porcentajeanticipo,
					POC_ESCENTRALIZADA			
				)
				SELECT	
					ppg_areaafectacion,
					'',
					@IdUsuarioAut,
					@oce_folioorden,
					'SOL',
					convert(varchar(10),ppg_fechaorden,103),
					convert(varchar(10),ppg_fechaorden,103),
					(
						select 
						(
							select sum(pgd.ppd_cantidad * pgd.ppd_preciounitario)
							from [cuentasxpagar].[dbo].[pre_pedidogastosdet] pgd
							where pg.ppg_idprepedidogastos = pgd.ppg_idprepedidogastos
						) 
						from [cuentasxpagar].[dbo].[pre_pedidogastos] pg
						where pg.ppg_idprepedidogastos = @pedido
					),
					(
						select 
						(
							select sum(pgd.ppd_cantidad * pgd.ppd_preciounitario) * (pg.ppg_tasaiva / 100)
							from [cuentasxpagar].[dbo].[pre_pedidogastosdet] pgd
							where pg.ppg_idprepedidogastos = pgd.ppg_idprepedidogastos
						) 
						from [cuentasxpagar].[dbo].[pre_pedidogastos] pg
						where pg.ppg_idprepedidogastos = @pedido
					),

					(
						select 
						(
							select sum(pgd.ppd_descuento)
							from [cuentasxpagar].[dbo].[pre_pedidogastosdet] pgd
							where pg.ppg_idprepedidogastos = pgd.ppg_idprepedidogastos
						) 
						from [cuentasxpagar].[dbo].[pre_pedidogastos] pg
						where pg.ppg_idprepedidogastos = @pedido
					),
					@oce_importetotal,
					ppg_idproveedor,
					ppg_tasaiva,
					ppg_observaciones,
					(
						select 
						(
							select o.eqv_usubusiness
							from [ControlAplicaciones].[dbo].[eqv_organigrama] o
							where o.usu_usuario =  ppg_usuariogenera
							and		emp_idempresa =  ppg_idempresa 
							and		suc_idsucursal = ppg_idsucursal
						)
						from [cuentasxpagar].[dbo].[pre_pedidogastos]
						where ppg_idprepedidogastos = @pedido
					),
					convert(varchar(10),ppg_fechaorden,103),
					'',
					(
						select 
						(
							select o.eqv_usubusiness
							from [ControlAplicaciones].[dbo].[eqv_organigrama] o
							where o.usu_usuario =  ppg_usuariogenera
							and		emp_idempresa =  ppg_idempresa 
							and		suc_idsucursal = ppg_idsucursal
						)
						from [cuentasxpagar].[dbo].[pre_pedidogastos]
						where ppg_idprepedidogastos = @pedido
					),
					'',
					0,
					1,
					0,
					'PE',
					@oce_folioorden,
					0,
					0,
					0,
					1
				FROM	[cuentasxpagar].[dbo].[pre_pedidogastos]
				WHERE	ppg_idprepedidogastos = @pedido


			/*
			========================================
			==  Inserta valores en la tabla  con_pedotrosdet
			========================================
			*/

				INSERT INTO [con_pedotrosdet]
				(
					pod_idpedido,
					pod_area,
					pod_cantidad,
					pod_producto,
					pod_preuni,
					pod_descuento,
					pod_iva,
					pod_total,
					pod_cvuusu,
					pod_fechope,
					pod_poriva,
					pod_retiva,
					pod_retisr,
					POD_IDTERCERO,
					POD_IDDOCTO,
					pod_Consecutivo,
					pod_folioorden,
					pod_cantidadrecibida,
					pod_cantidaddiferencia,
					pod_cveusurecep,
					pod_preuniinicial,
					pod_totalinicial,
					pod_idsituacionordendet,
					pod_saldocuentames,
					pod_presupuestomes,
					pod_excedentemes,
					pod_saldocuentaanio,
					pod_presupuestoanio,
					pod_excedenteanio,
					pod_retced
				)

				SELECT	
					(
						select	poc_idpedido
						from	[dbo].[con_pedotros]
						where	poc_factura = @oce_folioorden
					),
					'',
					pgd.ppd_cantidad,
					pgd.ppd_producto,
					pgd.ppd_preciounitario,
					pgd.ppd_descuento,
					((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento) * (pg.ppg_tasaiva / 100),
					((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento) * (pg.ppg_tasaiva / 100) + ((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento),
					(
						select 
						(
							select o.eqv_usubusiness
							from [ControlAplicaciones].[dbo].[eqv_organigrama] o
							where o.usu_usuario =  ppg_usuariogenera
							and		emp_idempresa =  ppg_idempresa 
							and		suc_idsucursal = ppg_idsucursal
						)
						from [cuentasxpagar].[dbo].[pre_pedidogastos]
						where ppg_idprepedidogastos = @pedido
					),
					pg.ppg_fechaorden,
					pg.ppg_tasaiva,
					0,
					0,
					0,
					'',
					ROW_NUMBER() OVER(ORDER BY @oce_folioorden ASC),
					@oce_folioorden,
					0,
					0,
					ppg_usuariogenera,
					pgd.ppd_preciounitario,
					((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento) * (pg.ppg_tasaiva / 100) + ((pgd.ppd_cantidad * pgd.ppd_preciounitario) - pgd.ppd_descuento),
					@oce_situacionorden,
					0,
					0,
					0,
					0,
					0,
					0,
					0 

					FROM	[cuentasxpagar].[dbo].[pre_pedidogastosdet] pgd,
							[cuentasxpagar].[dbo].[pre_pedidogastos] pg
					WHERE	pgd.ppg_idprepedidogastos = pg.ppg_idprepedidogastos
					AND		pgd.ppg_idprepedidogastos = @pedido



			/*
			========================================
			==  Actualizamos el resultado correcto
			========================================
			*/

			
			UPDATE [cuentasxpagar].[dbo].[pre_pedidogastos]
			SET		ppg_estatus = 1, 
					ppg_fechaproceso = GETDATE(),
					ppg_ordencompra			= @oce_folioorden
			WHERE	ppg_idprepedidogastos	= @pedido

	
		
			COMMIT TRANSACTION

			select '0' as Repuesta 
		
		
	--			print ERROR_MESSAGE()
	--			SET @TextoMsg = ERROR_MESSAGE()
	--			SET @msg = 0
	--			return @msg
	--			return @TextoMsg
			
		END TRY		
    
		BEGIN CATCH
 			ROLLBACK TRANSACTION

			/*
			========================================
			==  Actualizamos el resultado con errores
			========================================
			*/
			
			UPDATE [cuentasxpagar].[dbo].[pre_pedidogastos]
			SET		ppg_estatus = 2, 
					ppg_fechaproceso = GETDATE(),
					ppg_ordencompra			= @oce_folioorden
			WHERE	ppg_idprepedidogastos	= @pedido

			/*
			========================================
			==  Actualizamos el log con el error
			========================================
			*/

			INSERT INTO [cuentasxpagar].[dbo].[pre_pedidogastoslog]
				(
					ppl_descripcionerror,
					ppl_fechaerror,
					ppl_horaerror,
					ppg_idprepedidogastos						
				)
				VALUES
				(		
					ERROR_MESSAGE(),
					CONVERT (date, GETDATE()),
					CONVERT (time, GETDATE()),
					@pedido	
				)


			select '1' as Repuesta 


	--		print ERROR_MESSAGE()
	--		SET @TextoMsg = ERROR_MESSAGE()
	--		SET @msg = 1
	--		return @msg
	--		return @TextoMsg
		 END CATCH
	 END

	 IF @cantidaddetalle = 0 -- No tiene detalle
	 BEGIN
		INSERT INTO [cuentasxpagar].[dbo].[pre_pedidogastoslog]
		(
			ppl_descripcionerror,
			ppl_fechaerror,
			ppl_horaerror,
			ppg_idprepedidogastos						
		)
		VALUES
		(		
			'El pedido no cuenta con detalle!',
			CONVERT (date, GETDATE()),
			CONVERT (time, GETDATE()),
			@pedido	
		)

		select '1' as Repuesta 
	 END

END
go

