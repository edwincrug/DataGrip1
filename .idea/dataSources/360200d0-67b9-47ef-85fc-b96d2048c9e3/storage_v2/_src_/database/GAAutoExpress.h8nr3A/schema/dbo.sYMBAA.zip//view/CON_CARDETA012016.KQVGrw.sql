create view [dbo].[CON_CARDETA012016] as select * from GAAutoexpressConcentra.dbo.CON_CARDETA012016;
go

