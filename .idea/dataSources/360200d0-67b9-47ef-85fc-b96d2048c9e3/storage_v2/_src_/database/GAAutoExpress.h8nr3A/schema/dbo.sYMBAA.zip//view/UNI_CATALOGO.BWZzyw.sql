create view [dbo].[UNI_CATALOGO] as select * from GAAutoexpressConcentra.dbo.UNI_CATALOGO;
go

