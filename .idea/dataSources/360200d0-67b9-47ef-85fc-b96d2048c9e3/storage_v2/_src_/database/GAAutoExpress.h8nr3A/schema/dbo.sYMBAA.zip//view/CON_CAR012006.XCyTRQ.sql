create view [dbo].[CON_CAR012006] as select * from GAAutoexpressConcentra.dbo.CON_CAR012006;
go

