create view [dbo].[ADE_VTACFDDET] as select * from GAAutoexpressConcentra.dbo.ADE_VTACFDDET;
go

