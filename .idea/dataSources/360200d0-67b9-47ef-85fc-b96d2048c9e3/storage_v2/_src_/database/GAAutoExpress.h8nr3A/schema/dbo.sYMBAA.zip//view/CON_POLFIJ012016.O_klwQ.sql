create view [dbo].[CON_POLFIJ012016] as select * from GAAutoexpressConcentra.dbo.CON_POLFIJ012016;
go

