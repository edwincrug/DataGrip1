create view [dbo].[CON_CAR012003] as select * from GAAutoexpressConcentra.dbo.CON_CAR012003;
go

