create view [dbo].[CON_POL012015] as select * from GAAutoexpressConcentra.dbo.CON_POL012015;
go

