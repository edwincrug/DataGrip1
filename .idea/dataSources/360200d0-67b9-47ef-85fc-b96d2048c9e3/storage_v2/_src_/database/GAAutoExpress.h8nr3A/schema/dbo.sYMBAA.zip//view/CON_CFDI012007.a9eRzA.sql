create view [dbo].[CON_CFDI012007] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012007;
go

