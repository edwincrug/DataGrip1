create view [dbo].[ADE_CFDREPMENSUAL] as select * from GAAutoexpressConcentra.dbo.ADE_CFDREPMENSUAL;
go

