create view [dbo].[ADE_COMPLEMENTOEXP_DET] as select * from GAAutoexpressConcentra.dbo.ADE_COMPLEMENTOEXP_DET;
go

