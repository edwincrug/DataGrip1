create view [dbo].[CON_GCFDI012018] as select * from GAAutoexpressConcentra.dbo.CON_GCFDI012018;
go

