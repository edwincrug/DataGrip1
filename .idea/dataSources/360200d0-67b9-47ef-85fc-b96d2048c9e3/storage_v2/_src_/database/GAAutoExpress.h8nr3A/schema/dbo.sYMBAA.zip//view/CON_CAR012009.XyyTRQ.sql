create view [dbo].[CON_CAR012009] as select * from GAAutoexpressConcentra.dbo.CON_CAR012009;
go

