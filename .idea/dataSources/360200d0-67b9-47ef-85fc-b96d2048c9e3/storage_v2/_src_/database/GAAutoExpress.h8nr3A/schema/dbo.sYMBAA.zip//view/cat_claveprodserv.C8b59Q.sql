create view [dbo].[cat_claveprodserv] as select * from GAAutoexpressConcentra.dbo.cat_claveprodserv;
go

