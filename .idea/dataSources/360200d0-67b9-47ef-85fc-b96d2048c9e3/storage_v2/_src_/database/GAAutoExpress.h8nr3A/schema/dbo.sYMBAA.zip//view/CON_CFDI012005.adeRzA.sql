create view [dbo].[CON_CFDI012005] as select * from GAAutoexpressConcentra.dbo.CON_CFDI012005;
go

