create view [dbo].[ADE_VTACFDDETMN] as select * from GAAutoexpressConcentra.dbo.ADE_VTACFDDETMN;
go

