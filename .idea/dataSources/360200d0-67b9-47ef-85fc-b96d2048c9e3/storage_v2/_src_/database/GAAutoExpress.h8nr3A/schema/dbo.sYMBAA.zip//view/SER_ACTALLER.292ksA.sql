create view [dbo].[SER_ACTALLER] as select * from GAAutoexpressConcentra.dbo.SER_ACTALLER;
go

