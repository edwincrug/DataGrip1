create view [dbo].[CON_MOVDET012006] as select * from GAAutoexpressConcentra.dbo.CON_MOVDET012006;
go

