create view [dbo].[UNI_CATACOLOR] as select * from GAAutoexpressConcentra.dbo.UNI_CATACOLOR;
go

