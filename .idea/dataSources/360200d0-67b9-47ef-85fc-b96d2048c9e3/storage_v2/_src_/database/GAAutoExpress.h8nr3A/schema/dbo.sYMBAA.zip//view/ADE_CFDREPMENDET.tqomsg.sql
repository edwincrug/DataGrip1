create view [dbo].[ADE_CFDREPMENDET] as select * from GAAutoexpressConcentra.dbo.ADE_CFDREPMENDET;
go

