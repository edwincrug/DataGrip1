create view [dbo].[CON_MOVTRANSFER012016] as select * from GAAutoexpressConcentra.dbo.CON_MOVTRANSFER012016;
go

