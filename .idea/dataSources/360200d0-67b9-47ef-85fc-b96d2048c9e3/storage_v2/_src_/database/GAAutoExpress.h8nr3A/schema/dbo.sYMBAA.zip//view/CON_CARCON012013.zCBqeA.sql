create view [dbo].[CON_CARCON012013] as select * from GAAutoexpressConcentra.dbo.CON_CARCON012013;
go

