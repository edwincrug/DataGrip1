create view [dbo].[CON_MOVDETfij012007] as select * from GATPartsConcen.dbo.CON_MOVDETfij012007
go

