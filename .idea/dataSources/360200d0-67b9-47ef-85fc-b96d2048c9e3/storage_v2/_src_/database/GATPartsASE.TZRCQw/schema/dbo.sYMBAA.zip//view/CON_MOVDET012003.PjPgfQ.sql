create view [dbo].[CON_MOVDET012003] as select * from GATPartsConcen.dbo.CON_MOVDET012003
go

