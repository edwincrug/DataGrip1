---(13)
create view [dbo].[ADE_CFDI] as select * from GATPartsConcen.dbo.ADE_CFDI
go

