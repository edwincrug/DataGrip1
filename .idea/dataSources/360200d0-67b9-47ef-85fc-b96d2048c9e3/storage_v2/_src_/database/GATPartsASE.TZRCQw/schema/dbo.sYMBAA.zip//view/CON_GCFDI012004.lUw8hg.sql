create view [dbo].[CON_GCFDI012004] as select * from [GATPartsConcen].dbo.[CON_GCFDI012004]
go

