create view [dbo].[PAR_ALTERNOS] as select * from GATPartsConcen.dbo.PAR_ALTERNOS
go

