CREATE VIEW [dbo].[cat_claveprodserv] AS Select * From GATPartsConcen.dbo.cat_claveprodserv
go

