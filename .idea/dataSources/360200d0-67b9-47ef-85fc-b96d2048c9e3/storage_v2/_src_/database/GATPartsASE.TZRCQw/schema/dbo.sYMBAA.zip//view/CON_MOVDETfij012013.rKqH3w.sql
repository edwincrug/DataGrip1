create view [dbo].[CON_MOVDETfij012013] as select * from GATPartsConcen.dbo.CON_MOVDETfij012013
go

