create view [dbo].[CON_GCFDI012006] as select * from [GATPartsConcen].dbo.[CON_GCFDI012006]
go

