---(7)
create view [dbo].[ADE_CFDEMIREC] as select * from GATPartsConcen.dbo.ADE_CFDEMIREC
go

