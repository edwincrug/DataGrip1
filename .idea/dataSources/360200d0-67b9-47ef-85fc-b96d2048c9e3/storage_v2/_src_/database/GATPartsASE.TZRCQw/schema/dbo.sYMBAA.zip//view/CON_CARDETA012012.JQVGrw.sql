create view [dbo].[CON_CARDETA012012] as select * from GATPartsConcen.dbo.CON_CARDETA012012
go

