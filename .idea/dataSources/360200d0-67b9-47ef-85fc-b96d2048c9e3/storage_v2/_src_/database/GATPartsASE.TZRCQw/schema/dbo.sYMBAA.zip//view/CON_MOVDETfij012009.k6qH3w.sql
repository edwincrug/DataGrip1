create view [dbo].[CON_MOVDETfij012009] as select * from GATPartsConcen.dbo.CON_MOVDETfij012009
go

