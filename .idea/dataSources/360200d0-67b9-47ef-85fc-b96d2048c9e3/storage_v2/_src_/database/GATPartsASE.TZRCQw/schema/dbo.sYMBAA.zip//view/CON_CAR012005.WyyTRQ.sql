create view [dbo].[CON_CAR012005] as select * from GATPartsConcen.dbo.CON_CAR012005
go

