create view [dbo].[CON_CARCON012012] as select * from GATPartsConcen.dbo.CON_CARCON012012
go

