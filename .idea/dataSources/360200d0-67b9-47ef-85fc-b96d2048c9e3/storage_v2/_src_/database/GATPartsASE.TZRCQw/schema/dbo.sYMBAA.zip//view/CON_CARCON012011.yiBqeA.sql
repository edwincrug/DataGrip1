create view [dbo].[CON_CARCON012011] as select * from GATPartsConcen.dbo.CON_CARCON012011
go

