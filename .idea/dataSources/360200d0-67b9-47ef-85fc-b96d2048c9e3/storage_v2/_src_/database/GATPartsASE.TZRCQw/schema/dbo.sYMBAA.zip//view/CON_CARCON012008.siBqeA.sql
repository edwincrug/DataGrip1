create view [dbo].[CON_CARCON012008] as select * from GATPartsConcen.dbo.CON_CARCON012008
go

