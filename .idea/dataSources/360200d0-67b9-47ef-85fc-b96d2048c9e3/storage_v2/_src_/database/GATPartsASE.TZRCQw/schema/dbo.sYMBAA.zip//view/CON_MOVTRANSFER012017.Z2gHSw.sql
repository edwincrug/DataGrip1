create view [dbo].[CON_MOVTRANSFER012017] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012017
go

