create view [dbo].[SER_RECALLSDET] as select * from GATPartsConcen.dbo.SER_RECALLSDET
go

