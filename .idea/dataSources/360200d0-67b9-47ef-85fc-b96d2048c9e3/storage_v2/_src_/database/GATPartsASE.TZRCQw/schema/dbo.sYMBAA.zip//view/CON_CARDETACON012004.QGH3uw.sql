create view [dbo].[CON_CARDETACON012004] as select * from GATPartsConcen.dbo.CON_CARDETACON012004
go

