---(13)
create view [dbo].[ADE_CFDITIMBRADO] as select * from GATPartsConcen.dbo.ADE_CFDITIMBRADO
go

