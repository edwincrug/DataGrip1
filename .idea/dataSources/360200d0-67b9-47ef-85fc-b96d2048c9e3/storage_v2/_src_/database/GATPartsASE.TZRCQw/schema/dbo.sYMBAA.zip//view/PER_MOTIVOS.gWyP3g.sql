create view [dbo].[PER_MOTIVOS] as select * from GATPartsConcen.dbo.PER_MOTIVOS
go

