create view [dbo].[CON_MOVTRANSFER012003] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012003
go

