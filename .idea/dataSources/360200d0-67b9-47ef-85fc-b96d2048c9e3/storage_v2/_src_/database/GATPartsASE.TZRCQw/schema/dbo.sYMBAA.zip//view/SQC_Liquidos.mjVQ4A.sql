create view [dbo].[SQC_Liquidos] as select * from [GATPartsConcen].[dbo].[SQC_Liquidos]
go

