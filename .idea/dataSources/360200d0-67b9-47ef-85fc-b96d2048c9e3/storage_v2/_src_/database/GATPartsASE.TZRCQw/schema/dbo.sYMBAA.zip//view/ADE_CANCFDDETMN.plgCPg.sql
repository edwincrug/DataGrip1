---(6)
create view [dbo].[ADE_CANCFDDETMN] as select * from GATPartsConcen.dbo.ADE_CANCFDDETMN
go

