create view [dbo].[CON_CTAS012003] as select * from GATPartsConcen.dbo.CON_CTAS012003
go

