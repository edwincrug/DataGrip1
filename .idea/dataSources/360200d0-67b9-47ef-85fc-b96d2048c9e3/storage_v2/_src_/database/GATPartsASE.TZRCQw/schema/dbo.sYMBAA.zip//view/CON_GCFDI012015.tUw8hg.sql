create view [dbo].[CON_GCFDI012015] as select * from [GATPartsConcen].dbo.[CON_GCFDI012015]
go

