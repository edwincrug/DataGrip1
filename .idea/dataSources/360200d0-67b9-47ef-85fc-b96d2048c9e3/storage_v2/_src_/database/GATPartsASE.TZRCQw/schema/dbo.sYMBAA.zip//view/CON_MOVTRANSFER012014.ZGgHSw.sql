create view [dbo].[CON_MOVTRANSFER012014] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012014
go

