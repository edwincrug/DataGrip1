create view [dbo].[CON_POL012007] as select * from GATPartsConcen.dbo.CON_POL012007
go

