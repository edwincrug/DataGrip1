create view [dbo].[ser_recallscampañas] as select * from GATPartsConcen.dbo.ser_recallscampañas
go

