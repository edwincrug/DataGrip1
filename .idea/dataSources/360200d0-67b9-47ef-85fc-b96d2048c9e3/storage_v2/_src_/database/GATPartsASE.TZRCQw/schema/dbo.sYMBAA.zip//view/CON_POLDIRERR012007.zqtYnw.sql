create view [dbo].[CON_POLDIRERR012007] as select * from GATPartsConcen.dbo.CON_POLDIRERR012007
go

