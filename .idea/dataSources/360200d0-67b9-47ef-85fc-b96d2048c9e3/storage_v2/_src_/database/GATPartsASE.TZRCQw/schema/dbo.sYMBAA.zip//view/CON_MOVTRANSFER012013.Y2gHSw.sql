create view [dbo].[CON_MOVTRANSFER012013] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012013
go

