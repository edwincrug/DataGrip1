create view [dbo].[SER_PAQOPE] as select * from GATPartsConcen.dbo.SER_PAQOPE
go

