create view [dbo].[SER_RECALLSRANGOSVIN] as select * from GATPartsConcen.dbo.SER_RECALLSRANGOSVIN
go

