create view [dbo].[SER_PAQUETES] as select * from GATPartsConcen.dbo.SER_PAQUETES
go

