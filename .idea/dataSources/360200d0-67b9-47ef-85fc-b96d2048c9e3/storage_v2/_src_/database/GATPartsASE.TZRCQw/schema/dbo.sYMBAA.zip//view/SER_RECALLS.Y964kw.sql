create view [dbo].[SER_RECALLS] as select * from GATPartsConcen.dbo.SER_RECALLS
go

