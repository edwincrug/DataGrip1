create view [dbo].[ADE_VTACFD] as select * from GATPartsConcen.dbo.ADE_VTACFD
go

