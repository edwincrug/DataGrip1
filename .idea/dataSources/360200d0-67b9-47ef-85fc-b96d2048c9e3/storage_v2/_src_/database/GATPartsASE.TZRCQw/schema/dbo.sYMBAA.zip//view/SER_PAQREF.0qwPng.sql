create view [dbo].[SER_PAQREF] as select * from GATPartsConcen.dbo.SER_PAQREF
go

