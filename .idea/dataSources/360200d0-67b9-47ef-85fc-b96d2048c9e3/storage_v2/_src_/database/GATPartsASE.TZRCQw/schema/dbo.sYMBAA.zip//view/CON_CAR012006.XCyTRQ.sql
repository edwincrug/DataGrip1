create view [dbo].[CON_CAR012006] as select * from GATPartsConcen.dbo.CON_CAR012006
go

