create view [dbo].[CON_CAR012009] as select * from GATPartsConcen.dbo.CON_CAR012009
go

