create view [dbo].[CON_POLfij012009] as select * from GATPartsConcen.dbo.CON_POLfij012009
go

