CREATE View [dbo].[vstAgentesG1] AS SELECT 0 AS NumAge, 'Todos'AS NomAge
go

