create view [dbo].[CON_CARDETACON012007] as select * from GATPartsConcen.dbo.CON_CARDETACON012007
go

