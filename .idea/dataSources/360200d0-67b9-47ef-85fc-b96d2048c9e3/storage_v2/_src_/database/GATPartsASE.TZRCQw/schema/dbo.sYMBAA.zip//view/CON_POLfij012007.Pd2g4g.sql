create view [dbo].[CON_POLfij012007] as select * from GATPartsConcen.dbo.CON_POLfij012007
go

