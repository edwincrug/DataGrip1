---(11)
create view [dbo].[ADE_ADDENDAAMECE] as select * from GATPartsConcen.dbo.ADE_ADDENDAAMECE
go

