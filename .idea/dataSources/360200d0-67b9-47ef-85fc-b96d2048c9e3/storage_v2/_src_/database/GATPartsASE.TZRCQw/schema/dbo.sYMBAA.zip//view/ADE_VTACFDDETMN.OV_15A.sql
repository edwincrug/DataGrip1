---(2)
create view [dbo].[ADE_VTACFDDETMN] as select * from GATPartsConcen.dbo.ADE_VTACFDDETMN
go

