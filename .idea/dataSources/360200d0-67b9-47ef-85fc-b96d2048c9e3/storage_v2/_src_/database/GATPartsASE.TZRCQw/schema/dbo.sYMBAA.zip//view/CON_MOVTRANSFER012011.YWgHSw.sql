create view [dbo].[CON_MOVTRANSFER012011] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012011
go

