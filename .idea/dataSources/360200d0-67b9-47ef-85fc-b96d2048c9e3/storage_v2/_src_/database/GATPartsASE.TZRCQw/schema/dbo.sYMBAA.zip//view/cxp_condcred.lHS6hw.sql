create view [dbo].[cxp_condcred] as select * from GATPartsConcen.dbo.cxp_condcred
go

