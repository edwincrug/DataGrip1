create view [dbo].[CON_CARDETACON012013] as select * from GATPartsConcen.dbo.CON_CARDETACON012013
go

