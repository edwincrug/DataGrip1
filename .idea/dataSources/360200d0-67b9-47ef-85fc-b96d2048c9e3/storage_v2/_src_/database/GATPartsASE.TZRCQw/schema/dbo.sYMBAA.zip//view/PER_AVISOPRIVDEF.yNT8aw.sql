create view [dbo].[PER_AVISOPRIVDEF] as select * from GATPartsConcen.dbo.PER_AVISOPRIVDEF
go

