create view [dbo].[CON_CFDI012015] as select * from [GATPartsConcen].dbo.[con_cfdi012015]
go

