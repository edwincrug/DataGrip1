CREATE VIEW [dbo].[sicop_qry_inventario]
AS
SELECT 'No se' AS [No Pedido], 
    VEH_CATALOGO AS [Clave Modelo], 
    VEH_NUMSERIE AS [No de Vin], 
    VEH_NOMOTOR AS [No de Motor], 
    VEH_NOPEDIMTO AS [Numero de Pedimento de Importación], 
    VEH_UBICACION AS [Ubicación de la unidad], 
    RTRIM(STR(VEH_NOINVENTA)) AS [Número de Inventario], 
    VEH_ORGUNIDAD AS Origen, VEH_ANMODELO AS Año, 
    VEH_COLOEXTE AS [Clave color Ext], 
    VEH_COLOINTE AS [Clave color Inte], 0 AS Autodemo, 
    0 AS [Demo Pagado], 
    VEH_SITUACION AS [Apartado Disponible], 
    VEH_FECREMISION AS [Fecha de entrada a Patio]
FROM SER_VEHICULO
go

