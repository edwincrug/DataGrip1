create view [dbo].[CON_CARDETACON012010] as select * from GATPartsConcen.dbo.CON_CARDETACON012010
go

