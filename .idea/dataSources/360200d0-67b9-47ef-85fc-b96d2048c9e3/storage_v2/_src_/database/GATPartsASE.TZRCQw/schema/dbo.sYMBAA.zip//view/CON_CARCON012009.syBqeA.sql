create view [dbo].[CON_CARCON012009] as select * from GATPartsConcen.dbo.CON_CARCON012009
go

