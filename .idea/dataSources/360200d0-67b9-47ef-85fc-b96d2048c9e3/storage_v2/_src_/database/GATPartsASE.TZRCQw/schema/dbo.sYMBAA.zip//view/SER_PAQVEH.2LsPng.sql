create view [dbo].[SER_PAQVEH] as select * from GATPartsConcen.dbo.SER_PAQVEH
go

