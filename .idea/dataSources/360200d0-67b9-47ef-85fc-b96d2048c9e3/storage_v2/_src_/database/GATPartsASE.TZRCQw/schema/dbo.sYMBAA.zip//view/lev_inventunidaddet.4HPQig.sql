CREATE VIEW [dbo].[lev_inventunidaddet]  AS  SELECT   liu_idinventuni, caa_idacce, liu_cantfisica, liu_observ, lid_iddetalle, liu_nombreeviden, liu_ruta, liu_idtipodocto, cea_idestadoacc, liu_cantdanada  FROM CUENTASPORCOBRAR.dbo.lev_inventunidaddet
go

