create view [dbo].[CON_POLDIRERR012011] as select * from GATPartsConcen.dbo.CON_POLDIRERR012011
go

