create view [dbo].[SQC_Partes2] as select * from [GATPartsConcen].[dbo].[SQC_Partes2]
go

