create view [dbo].[UNI_PLANBONIDET] as select * from GATPartsConcen.dbo.UNI_PLANBONIDET
go

