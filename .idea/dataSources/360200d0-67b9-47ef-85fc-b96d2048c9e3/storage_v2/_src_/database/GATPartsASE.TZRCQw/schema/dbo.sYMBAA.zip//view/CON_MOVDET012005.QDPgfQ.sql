create view [dbo].[CON_MOVDET012005] as select * from GATPartsConcen.dbo.CON_MOVDET012005
go

