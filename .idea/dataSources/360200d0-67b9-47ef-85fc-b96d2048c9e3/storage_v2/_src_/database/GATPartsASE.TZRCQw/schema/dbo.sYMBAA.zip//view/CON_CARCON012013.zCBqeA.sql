create view [dbo].[CON_CARCON012013] as select * from GATPartsConcen.dbo.CON_CARCON012013
go

