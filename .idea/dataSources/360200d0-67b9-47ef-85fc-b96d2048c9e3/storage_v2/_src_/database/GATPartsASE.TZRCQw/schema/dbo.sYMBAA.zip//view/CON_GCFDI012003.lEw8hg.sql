create view [dbo].[CON_GCFDI012003] as select * from [GATPartsConcen].dbo.[CON_GCFDI012003]
go

