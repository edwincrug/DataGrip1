create view [dbo].[CON_GCFDI012008] as select * from [GATPartsConcen].dbo.[CON_GCFDI012008]
go

