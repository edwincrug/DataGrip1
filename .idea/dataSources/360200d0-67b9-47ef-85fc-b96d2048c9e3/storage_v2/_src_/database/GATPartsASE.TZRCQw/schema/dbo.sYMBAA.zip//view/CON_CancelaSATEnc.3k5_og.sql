
CREATE VIEW [dbo].[CON_CancelaSATEnc] AS SELECT * FROM GATPartsConcen.dbo.CON_CancelaSATEnc
go

