Create View [dbo].[cxp_ordenesmasivasdet] as select * from [GATPartsConcen].dbo.cxp_ordenesmasivasdet
go

