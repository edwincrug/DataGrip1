create view [dbo].[CON_MOVDET012010] as select * from GATPartsConcen.dbo.CON_MOVDET012010
go

