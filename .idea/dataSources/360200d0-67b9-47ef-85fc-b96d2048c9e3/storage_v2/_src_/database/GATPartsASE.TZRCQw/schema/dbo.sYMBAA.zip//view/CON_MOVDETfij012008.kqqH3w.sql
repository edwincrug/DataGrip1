create view [dbo].[CON_MOVDETfij012008] as select * from GATPartsConcen.dbo.CON_MOVDETfij012008
go

