create view [dbo].[CON_POLfij012011] as select * from GATPartsConcen.dbo.CON_POLfij012011
go

