create view [dbo].[CON_MOVTRANSFER012016] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012016
go

