create view [dbo].[CON_POLfij012010] as select * from GATPartsConcen.dbo.CON_POLfij012010
go

