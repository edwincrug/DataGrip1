create view [dbo].[CON_GCFDI012009] as select * from [GATPartsConcen].dbo.[CON_GCFDI012009]
go

