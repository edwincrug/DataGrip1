---(3)
create view [dbo].[ADE_CANCFD] as select * from GATPartsConcen.dbo.ADE_CANCFD
go

