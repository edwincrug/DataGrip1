create view [dbo].[PER_AVISOPRIV] as select * from GATPartsConcen.dbo.PER_AVISOPRIV
go

