---(13)
create view [dbo].[ADE_ADDENDASCONFIG] as select * from GATPartsConcen.dbo.ADE_ADDENDASCONFIG
go

