CREATE VIEW [dbo].[con_movimientoreferencia]
AS
SELECT   *
FROM         GATPartsConcen.dbo.con_movimientoreferencia
go

