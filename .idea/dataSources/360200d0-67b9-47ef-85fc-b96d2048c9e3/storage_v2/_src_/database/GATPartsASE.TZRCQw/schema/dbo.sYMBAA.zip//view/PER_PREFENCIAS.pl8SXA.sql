create view [dbo].[PER_PREFENCIAS] as select * from GATPartsConcen.dbo.PER_PREFENCIAS
go

