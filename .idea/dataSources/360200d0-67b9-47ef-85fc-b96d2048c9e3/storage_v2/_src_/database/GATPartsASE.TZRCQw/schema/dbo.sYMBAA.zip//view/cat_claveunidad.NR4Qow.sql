CREATE VIEW [dbo].[cat_claveunidad] AS Select * From GATPartsConcen.dbo.cat_claveunidad
go

