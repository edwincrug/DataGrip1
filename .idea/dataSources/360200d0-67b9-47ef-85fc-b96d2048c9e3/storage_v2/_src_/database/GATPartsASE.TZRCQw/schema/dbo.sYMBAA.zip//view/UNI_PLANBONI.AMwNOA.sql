create view [dbo].[UNI_PLANBONI] as select * from GATPartsConcen.dbo.UNI_PLANBONI
go

