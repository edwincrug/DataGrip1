CREATE VIEW [dbo].[cat_tiporeferencia]
AS
SELECT    *
FROM        GATPartsConcen.dbo.cat_tiporeferencia
go

