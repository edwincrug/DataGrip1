create view [dbo].[CON_CTAS012007] as select * from GATPartsConcen.dbo.CON_CTAS012007
go

