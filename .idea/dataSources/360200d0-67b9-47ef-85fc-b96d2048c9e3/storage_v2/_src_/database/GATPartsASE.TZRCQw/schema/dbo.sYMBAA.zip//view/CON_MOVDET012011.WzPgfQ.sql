create view [dbo].[CON_MOVDET012011] as select * from GATPartsConcen.dbo.CON_MOVDET012011
go

