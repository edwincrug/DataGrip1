create view [dbo].[CON_MOVTRANSFER012008] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012008
go

