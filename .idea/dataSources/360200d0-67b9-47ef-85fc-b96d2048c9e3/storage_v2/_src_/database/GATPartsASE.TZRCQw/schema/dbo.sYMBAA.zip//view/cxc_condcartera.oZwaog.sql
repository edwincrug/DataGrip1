create view [dbo].[cxc_condcartera] as select * from GATPartsConcen.dbo.cxc_condcartera
go

