create view [dbo].[PAR_PLANTA] as select * from GATPartsConcen.dbo.PAR_PLANTA
go

