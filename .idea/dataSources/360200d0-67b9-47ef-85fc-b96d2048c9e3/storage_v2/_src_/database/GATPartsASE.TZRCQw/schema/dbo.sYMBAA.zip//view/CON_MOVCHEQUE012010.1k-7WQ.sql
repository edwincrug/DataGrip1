create view [dbo].[CON_MOVCHEQUE012010] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012010
go

