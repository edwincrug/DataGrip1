CREATE VIEW cxp_ordenesmasivaslog
AS
SELECT        oml_idordenesmasivaslog, oml_descripcionerror, oml_fechaerror, oml_estatus, odm_idordenmasiva
FROM            [GATPartsConcen].DBO.cxp_ordenesmasivaslog
go

