create view [dbo].[CON_CAR012013] as select * from GATPartsConcen.dbo.CON_CAR012013
go

