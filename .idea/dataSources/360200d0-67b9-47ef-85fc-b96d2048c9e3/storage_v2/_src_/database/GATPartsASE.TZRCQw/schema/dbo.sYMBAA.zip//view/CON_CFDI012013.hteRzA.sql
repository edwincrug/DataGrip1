create view [dbo].[CON_CFDI012013] as select * from [GATPartsConcen].dbo.[con_cfdi012013]
go

