create view [dbo].[CON_MOVDET012013] as select * from GATPartsConcen.dbo.CON_MOVDET012013
go

