---(4)
create view [dbo].[ADE_CANCFDDET] as select * from GATPartsConcen.dbo.ADE_CANCFDDET
go

