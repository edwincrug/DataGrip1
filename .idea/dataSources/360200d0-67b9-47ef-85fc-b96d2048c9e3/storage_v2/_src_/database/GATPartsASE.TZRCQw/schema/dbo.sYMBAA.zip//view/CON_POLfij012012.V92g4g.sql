create view [dbo].[CON_POLfij012012] as select * from GATPartsConcen.dbo.CON_POLfij012012
go

