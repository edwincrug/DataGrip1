create view [dbo].[CON_CTAS012010] as select * from GATPartsConcen.dbo.CON_CTAS012010
go

