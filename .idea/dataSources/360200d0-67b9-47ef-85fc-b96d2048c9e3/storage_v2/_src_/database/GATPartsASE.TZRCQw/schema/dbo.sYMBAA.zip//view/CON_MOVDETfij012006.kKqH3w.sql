create view [dbo].[CON_MOVDETfij012006] as select * from GATPartsConcen.dbo.CON_MOVDETfij012006
go

