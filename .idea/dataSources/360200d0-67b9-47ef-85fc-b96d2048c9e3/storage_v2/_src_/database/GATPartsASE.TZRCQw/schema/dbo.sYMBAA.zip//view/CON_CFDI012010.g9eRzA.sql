create view [dbo].[CON_CFDI012010] as select * from [GATPartsConcen].dbo.[con_cfdi012010]
go

