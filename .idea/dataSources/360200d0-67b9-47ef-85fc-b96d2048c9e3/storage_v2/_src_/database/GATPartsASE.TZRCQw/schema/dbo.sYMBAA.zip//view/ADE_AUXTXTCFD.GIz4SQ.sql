---(8)
create view [dbo].[ADE_AUXTXTCFD] as select * from GATPartsConcen.dbo.ADE_AUXTXTCFD
go

