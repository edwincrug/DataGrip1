create view [dbo].[CON_CFDI012007] as select * from [GATPartsConcen].dbo.[con_cfdi012007]
go

