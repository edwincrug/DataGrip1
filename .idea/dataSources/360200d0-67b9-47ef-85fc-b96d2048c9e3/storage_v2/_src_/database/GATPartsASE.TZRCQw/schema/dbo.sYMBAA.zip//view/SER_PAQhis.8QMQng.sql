create view [dbo].[SER_PAQhis] as select * from GATPartsConcen.dbo.SER_PAQhis
go

