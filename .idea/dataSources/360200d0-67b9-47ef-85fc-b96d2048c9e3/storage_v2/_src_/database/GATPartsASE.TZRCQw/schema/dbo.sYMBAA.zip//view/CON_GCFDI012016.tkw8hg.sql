create view [dbo].[CON_GCFDI012016] as select * from GATPartsConcen.dbo.CON_GCFDI012016
go

