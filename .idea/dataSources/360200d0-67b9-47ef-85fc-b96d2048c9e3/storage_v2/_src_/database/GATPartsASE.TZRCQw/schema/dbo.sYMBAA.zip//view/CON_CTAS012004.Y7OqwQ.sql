create view [dbo].[CON_CTAS012004] as select * from GATPartsConcen.dbo.CON_CTAS012004
go

