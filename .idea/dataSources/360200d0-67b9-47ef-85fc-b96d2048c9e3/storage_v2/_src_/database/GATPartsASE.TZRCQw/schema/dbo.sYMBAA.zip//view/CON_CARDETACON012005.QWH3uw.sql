create view [dbo].[CON_CARDETACON012005] as select * from GATPartsConcen.dbo.CON_CARDETACON012005
go

