create view [dbo].[CON_MOVCHEQUE012008] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012008
go

