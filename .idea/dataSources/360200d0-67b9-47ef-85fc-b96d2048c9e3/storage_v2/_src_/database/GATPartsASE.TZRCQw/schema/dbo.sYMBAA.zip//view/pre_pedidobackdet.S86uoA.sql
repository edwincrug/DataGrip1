CREATE VIEW [dbo].[pre_pedidobackdet]
AS
SELECT pbk_idpedidobackdet, pbk_codigoparte, pbk_cantidad, pbk_estatus, pbk_fecha, pre_idpedidoref, pbk_idcotizacion
FROM [192.168.20.29].PortalRefacciones.dbo.pre_pedidobackdet

go

