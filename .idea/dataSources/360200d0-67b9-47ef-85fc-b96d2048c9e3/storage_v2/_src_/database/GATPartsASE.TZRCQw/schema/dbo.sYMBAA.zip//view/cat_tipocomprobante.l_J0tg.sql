CREATE VIEW [dbo].[cat_tipocomprobante] AS Select * From GATPartsConcen.dbo.cat_tipocomprobante
go

