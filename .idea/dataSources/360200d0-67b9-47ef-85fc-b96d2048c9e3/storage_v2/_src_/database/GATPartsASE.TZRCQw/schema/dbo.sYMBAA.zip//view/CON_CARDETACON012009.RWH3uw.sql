create view [dbo].[CON_CARDETACON012009] as select * from GATPartsConcen.dbo.CON_CARDETACON012009
go

