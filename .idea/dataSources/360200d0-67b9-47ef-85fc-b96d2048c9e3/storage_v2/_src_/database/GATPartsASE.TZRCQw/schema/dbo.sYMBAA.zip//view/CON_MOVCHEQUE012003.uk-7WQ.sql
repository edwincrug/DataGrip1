create view [dbo].[CON_MOVCHEQUE012003] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012003
go

