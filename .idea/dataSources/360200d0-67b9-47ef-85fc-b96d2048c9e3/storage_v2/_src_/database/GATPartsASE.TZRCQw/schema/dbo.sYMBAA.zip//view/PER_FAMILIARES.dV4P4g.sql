create view [dbo].[PER_FAMILIARES] as select * from GATPartsConcen.dbo.PER_FAMILIARES
go

