create view [dbo].[CON_POL012005] as select * from GATPartsConcen.dbo.CON_POL012005
go

