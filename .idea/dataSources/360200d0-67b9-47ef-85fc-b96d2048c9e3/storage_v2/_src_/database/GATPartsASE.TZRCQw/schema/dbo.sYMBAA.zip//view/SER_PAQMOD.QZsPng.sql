create view [dbo].[SER_PAQMOD] as select * from GATPartsConcen.dbo.SER_PAQMOD
go

