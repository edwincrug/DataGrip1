create view [dbo].[PAR_LINEAS] as select * from GATPartsConcen.dbo.PAR_LINEAS
go

