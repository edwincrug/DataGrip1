CREATE VIEW [dbo].[cli_condicionescredito]
AS
SELECT 
ccc_idclientecondicion, ccc_idempresa, ccc_idsucursal, ccc_iddepartamento, ccc_idcliente, ccc_idfechaalta, ccc_idusualta, ccc_estatus, tbq_idtipobloqueo
FROM         [GA_Corporativa].dbo.cli_condicionescredito
go

