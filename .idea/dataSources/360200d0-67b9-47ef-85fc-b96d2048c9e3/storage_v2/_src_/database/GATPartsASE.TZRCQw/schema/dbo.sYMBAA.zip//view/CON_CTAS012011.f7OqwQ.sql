create view [dbo].[CON_CTAS012011] as select * from GATPartsConcen.dbo.CON_CTAS012011
go

