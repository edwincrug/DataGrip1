create view [dbo].[CON_CARDETA012003] as select * from GATPartsConcen.dbo.CON_CARDETA012003
go

