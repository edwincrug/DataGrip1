create view [dbo].[SQC_Tipo_Vehiculos] as select * from [GATPartsConcen].[dbo].[SQC_Tipo_Vehiculos]
go

