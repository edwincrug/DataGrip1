create view [dbo].[CON_MOVDET012008] as select * from GATPartsConcen.dbo.CON_MOVDET012008
go

