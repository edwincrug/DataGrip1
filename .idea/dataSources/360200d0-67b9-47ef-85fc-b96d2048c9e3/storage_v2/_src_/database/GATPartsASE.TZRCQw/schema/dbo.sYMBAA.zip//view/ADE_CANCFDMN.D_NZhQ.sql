---(5)
create view [dbo].[ADE_CANCFDMN] as select * from GATPartsConcen.dbo.ADE_CANCFDMN
go

