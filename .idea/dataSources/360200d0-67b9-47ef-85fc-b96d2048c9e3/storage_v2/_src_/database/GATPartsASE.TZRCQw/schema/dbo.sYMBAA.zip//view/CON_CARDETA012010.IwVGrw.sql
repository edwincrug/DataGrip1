create view [dbo].[CON_CARDETA012010] as select * from GATPartsConcen.dbo.CON_CARDETA012010
go

