create view [dbo].[CON_CARDETA012009] as select * from GATPartsConcen.dbo.CON_CARDETA012009
go

