CREATE VIEW [dbo].[FAE_ASOCCATSAT] AS Select * From GATPartsConcen.dbo.FAE_ASOCCATSAT
go

