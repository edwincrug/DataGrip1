create view [dbo].[CON_POL012011] as select * from GATPartsConcen.dbo.CON_POL012011
go

