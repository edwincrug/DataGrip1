---(12)
create view [dbo].[ADE_ADDENDAS] as select * from GATPartsConcen.dbo.ADE_ADDENDAS
go

