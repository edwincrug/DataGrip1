create view [dbo].[CON_GCFDI012010] as select * from [GATPartsConcen].dbo.[CON_GCFDI012010]
go

