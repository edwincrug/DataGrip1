create view [dbo].[PYM_SEPOMEX] as select * from GATPartsConcen.dbo.PYM_SEPOMEX
go

