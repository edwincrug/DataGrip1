create view [dbo].[CON_CAR012010] as select * from GATPartsConcen.dbo.CON_CAR012010
go

