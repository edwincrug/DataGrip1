CREATE VIEW [dbo].[unp_bitoperaciones]
AS 
SELECT upb_idbitacora, upb_error, upb_fecha, upp_consulta, upe_idunificacion 
FROM GA_Corporativa.dbo.unp_bitoperaciones
go

