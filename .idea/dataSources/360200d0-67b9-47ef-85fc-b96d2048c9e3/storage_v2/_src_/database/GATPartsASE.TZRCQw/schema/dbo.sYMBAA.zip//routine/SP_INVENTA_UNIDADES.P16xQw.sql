
CREATE PROC SP_INVENTA_UNIDADES
AS
--BORRA REGISTROS ACTUALES
DELETE FROM BI_INVENTARIO_UNIDADES 

--INSERTA SEMINUEVOS
SELECT DISTINCT(veh_numserie),TipoUnidad = 'SEMINUEVOS',veh_noinventa as Inventario,VEH_COLOINTE,VEH_COLOEXTE,
VEH_ANMODELO,VEH_TIPOAUTO as DescModelo,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'MCAV' AND PAR_IDENPARA = VEH_SMARCA) AS Marca,Segmento='',
(SELECT PAR_DESCRIP1 FROM pnc_parametr WHERE PAR_TIPOPARA = 'CVE' AND PAR_IDENPARA = VEH_STIPO) AS Tipo,
Catalogo='',CarLine='',veh_puertas,veh_cilindros,UNC_POTENCIA='',veh_combustible,veh_capacidad,VEH_QCTRANSMISION,
(select par_descrip1 from pnc_parametr where PAR_TIPOPARA = 'UBI' and PAR_IDENPARA = VEH_UBICACION) as Ubicacion,
Tipomotor = VEH_QCTIPOMOTOR,NoMotor=VEH_NOMOTOR,veh_orgunidad as Procedencia,VEH_NOFACTPLAN,VEH_FECREMISION,
veh_nopedimtoext as NumPedimento,veh_fecpedimtoext as FechaPedimento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'TIPOCOMPRA' AND PAR_IDENPARA = veh_tipocompra) AS TipoCompra,
VEH_FECRETIRO as fecha_asignacion,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
DiasInventa=DATEDIFF(DAY,CONVERT(DATETIME,SUBSTRING(VEH_SFECADQUI,7,4) + SUBSTRING(VEH_SFECADQUI,4,2) + SUBSTRING(VEH_SFECADQUI,1,2)),GETDATE()),
PrecioLista=VEH_SIMPPVTA,inventario_final=0,COSTO_SIN_IVA = VEH_SSUBTOTAL,
valor_inventario=VEH_SSUBTOTAL+VEH_SCTOACOND,VEH_SCTOACOND,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'SN' AND PAR_IDMODULO = 'UNI' AND PAR_IDENPARA = VEH_SITUACION) AS Situacion,Unidades=1
INTO #INV_SEMINUEVOS
FROM 
ser_vehiculo V , pnc_parametr P ,pnc_parametr PP WHERE V.VEH_SMARCA = P.PAR_IDENPARA AND P.PAR_IDMODULO = 'UNI' 
AND P.PAR_TIPOPARA = 'MCAV' AND V.VEH_SITUACION IN ('SFIS','SPED','SSINI','STRAN','SSEP')
AND PP.PAR_TIPOPARA =  'UBI' AND V.VEH_UBICACION = PP.PAR_IDENPARA

SELECT *,RANGO = CASE 
WHEN DiasInventa <= 45 THEN 'De 1 a 45'
WHEN DiasInventa BETWEEN 46 AND 90 THEN 'De 46 a 90' 
WHEN DiasInventa BETWEEN 91 AND 120 THEN 'De 91 a 120'
WHEN DiasInventa BETWEEN 120 AND 360 THEN 'De 121 a 360'
WHEN DiasInventa > 360 THEN 'Mas de 360' END,
ORDEN = CASE 
WHEN DiasInventa <= 45 THEN 1
WHEN DiasInventa BETWEEN 46 AND 90 THEN 2
WHEN DiasInventa BETWEEN 91 AND 120 THEN 3
WHEN DiasInventa BETWEEN 120 AND 360 THEN 4
WHEN DiasInventa > 120 THEN 5 END
INTO #INV_SEMINUEVOS1 FROM #INV_SEMINUEVOS

INSERT INTO BI_INVENTARIO_UNIDADES
SELECT * FROM #INV_SEMINUEVOS1



------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
--INSERTA NUEVOS
Select DISTINCT(veh_numserie),TipoUnidad = 'NUEVOS',veh_noinventa as Inventario,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_colointe = col_clave and col_tipo = 'interior') as ColorInterior,
(select col_descripcion from uni_catacolor where veh_catalogo = col_catalogo and veh_anmodelo = col_modelo and veh_coloexte = col_clave and col_tipo = 'exterior') as ColorExterior,
veh_anmodelo as Modelo,veh_tipoauto as DescModelo,
(select par_descrip1 from pnc_parametr where par_tipopara = 'MCAV' and par_idenpara = unc_marca) as Marca,
(select par_descrip1 from pnc_parametr where par_tipopara = 'LNA' and par_idenpara = unc_linea) as Segmento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA='CVE' AND PAR_IDENPARA = uni_catalogo.UNC_CLASE) as subtipo_unidad,
UNC_IDCATALOGO,
CarLine = (select PAR_DESCRIP1 from PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'CLI' AND PAR_IDENPARA = uni_catalogo.UNC_FAMILIA),
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'PTA' AND PAR_IDENPARA = unc_ptas) as Puertas,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'CIL' AND PAR_IDENPARA = unc_cilindros) as cilindros,UNC_POTENCIA,
(select par_descrip1 from pnc_parametr where par_tipopara = 'CMB'and par_idenpara = unc_combustible) as Combustible,
unc_capacidad as Capacidad,
(select par_descrip1 from pnc_parametr where par_tipopara = 'TRS' and par_idenpara = unc_transmision) as Transmision,
(select par_descrip1 from pnc_parametr where PAR_TIPOPARA = 'UBI' and PAR_IDENPARA = VEH_UBICACION) as Ubicacion,
unc_tipomotor as Tipomotor,NoMotor=VEH_NOMOTOR,veh_orgunidad as Procedencia,VEH_NOFACTPLAN,VEH_FECREMISION,
veh_nopedimtoext as NumPedimento,veh_fecpedimtoext as FechaPedimento,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE  PAR_TIPOPARA = 'TIPOCOMPRA' AND PAR_IDENPARA = veh_tipocompra) AS TipoCompra,
VEH_FECRETIRO as fecha_asignacion,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_IDMODULO = 'UNI' AND PAR_TIPOPARA = 'FINAN' AND PAR_IDENPARA = VEH_FINANCIERA) AS financiera,
DiasInventa=DATEDIFF(DAY,CONVERT(DATETIME,SUBSTRING(VEH_FECREMISION,7,4) + SUBSTRING(VEH_FECREMISION,4,2) + SUBSTRING(VEH_FECREMISION,1,2)),GETDATE()),
PrecioLista=UNC_PRECLISTA,inventario_final=0,
COSTO_SIN_IVA = ROUND((VEH_IMPFACTPLAN/CONVERT(FLOAT,'1.' + ISNULL(VEH_IVACOM,1))),2),
valor_inventario= ROUND((VEH_IMPFACTPLAN/CONVERT(FLOAT,'1.' + ISNULL(VEH_IVACOM,1))),2),VEH_SCTOACOND,
(SELECT PAR_DESCRIP1 FROM PNC_PARAMETR WHERE PAR_TIPOPARA = 'SN' AND PAR_IDMODULO = 'UNI' AND PAR_IDENPARA = VEH_SITUACION) AS Situacion,Unidades=1
INTO #INV_NUEVOS 
FROM ser_vehiculo,uni_catalogo,UNI_VEHDETA 
where unc_idcatalogo = veh_catalogo and unc_modelo = veh_anmodelo AND VHD_NOSERIE = VEH_NUMSERIE AND
VEH_SITUACION IN ('FIS','PED','SEP','SINI','TRAN','DEMO') AND VHD_FACT='S'

SELECT *,RANGO = CASE 
WHEN DiasInventa <= 45 THEN 'De 1 a 45'
WHEN DiasInventa BETWEEN 46 AND 90 THEN 'De 46 a 90' 
WHEN DiasInventa BETWEEN 91 AND 120 THEN 'De 91 a 120'
WHEN DiasInventa BETWEEN 120 AND 360 THEN 'De 121 a 360'
WHEN DiasInventa > 360 THEN 'Mas de 360' END,
ORDEN = CASE 
WHEN DiasInventa <= 45 THEN 1
WHEN DiasInventa BETWEEN 46 AND 90 THEN 2
WHEN DiasInventa BETWEEN 91 AND 120 THEN 3
WHEN DiasInventa BETWEEN 120 AND 360 THEN 4
WHEN DiasInventa > 120 THEN 5 END
INTO #INV_NUEVOS1 FROM #INV_NUEVOS

INSERT INTO BI_INVENTARIO_UNIDADES
SELECT * FROM #INV_NUEVOS1
go

