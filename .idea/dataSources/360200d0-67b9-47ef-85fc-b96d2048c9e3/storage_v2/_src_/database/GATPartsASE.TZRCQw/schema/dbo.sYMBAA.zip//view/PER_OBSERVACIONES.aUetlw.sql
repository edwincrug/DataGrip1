create view [dbo].[PER_OBSERVACIONES] as select * from GATPartsConcen.dbo.PER_OBSERVACIONES
go

