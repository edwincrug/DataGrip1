create view [dbo].[CON_CARCON012005] as select * from GATPartsConcen.dbo.CON_CARCON012005
go

