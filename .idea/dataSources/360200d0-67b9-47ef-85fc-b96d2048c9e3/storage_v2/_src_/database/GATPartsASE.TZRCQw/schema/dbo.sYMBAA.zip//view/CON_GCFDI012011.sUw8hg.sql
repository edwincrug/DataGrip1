create view [dbo].[CON_GCFDI012011] as select * from [GATPartsConcen].dbo.[CON_GCFDI012011]
go

