create view [dbo].[CON_CTAS012009] as select * from GATPartsConcen.dbo.CON_CTAS012009
go

