create view [dbo].[CON_MOVCHEQUE012007] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012007
go

