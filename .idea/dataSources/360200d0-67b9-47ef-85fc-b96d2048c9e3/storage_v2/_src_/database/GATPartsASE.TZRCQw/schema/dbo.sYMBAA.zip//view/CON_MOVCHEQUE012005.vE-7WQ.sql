create view [dbo].[CON_MOVCHEQUE012005] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012005
go

