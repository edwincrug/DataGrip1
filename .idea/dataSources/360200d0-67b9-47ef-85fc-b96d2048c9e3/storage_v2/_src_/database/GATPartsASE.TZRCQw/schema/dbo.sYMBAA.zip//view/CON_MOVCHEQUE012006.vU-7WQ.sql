create view [dbo].[CON_MOVCHEQUE012006] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012006
go

