create view [dbo].[CON_CFDI012011] as select * from [GATPartsConcen].dbo.[con_cfdi012011]
go

