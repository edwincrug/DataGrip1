create view [dbo].[CON_MOVCHEQUE012004] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012004
go

