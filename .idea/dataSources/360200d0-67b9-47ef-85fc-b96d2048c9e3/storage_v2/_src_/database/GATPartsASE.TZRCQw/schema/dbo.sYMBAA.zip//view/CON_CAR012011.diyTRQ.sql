create view [dbo].[CON_CAR012011] as select * from GATPartsConcen.dbo.CON_CAR012011
go

