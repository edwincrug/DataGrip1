create view [dbo].[CON_CFDI012006] as select * from [GATPartsConcen].dbo.[con_cfdi012006]
go

