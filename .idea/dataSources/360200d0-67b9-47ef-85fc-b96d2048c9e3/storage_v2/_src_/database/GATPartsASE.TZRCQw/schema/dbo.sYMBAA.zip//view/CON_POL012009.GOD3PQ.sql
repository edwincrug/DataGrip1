create view [dbo].[CON_POL012009] as select * from GATPartsConcen.dbo.CON_POL012009
go

