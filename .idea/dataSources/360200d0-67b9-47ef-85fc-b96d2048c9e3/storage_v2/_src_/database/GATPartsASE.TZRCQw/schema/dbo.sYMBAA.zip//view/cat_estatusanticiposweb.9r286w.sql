---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE VIEW [dbo].[cat_estatusanticiposweb] AS 
(
SELECT 
cea_idestatusanticiposweb, cea_nombrecorto, cea_nombre, cea_descripcion, cea_idusuarioalta, cea_fechaalta, cea_idusuariomodifica, cea_fechamodifica, cea_estatus
FROM cuentasporcobrar.dbo.cat_estatusanticiposweb);
go

