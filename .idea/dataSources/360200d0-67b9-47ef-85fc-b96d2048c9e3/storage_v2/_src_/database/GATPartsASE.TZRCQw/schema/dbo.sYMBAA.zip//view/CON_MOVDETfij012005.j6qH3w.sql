create view [dbo].[CON_MOVDETfij012005] as select * from GATPartsConcen.dbo.CON_MOVDETfij012005
go

