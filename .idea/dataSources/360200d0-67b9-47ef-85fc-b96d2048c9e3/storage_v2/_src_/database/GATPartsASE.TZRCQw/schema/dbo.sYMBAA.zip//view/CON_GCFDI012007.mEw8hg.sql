create view [dbo].[CON_GCFDI012007] as select * from [GATPartsConcen].dbo.[CON_GCFDI012007]
go

