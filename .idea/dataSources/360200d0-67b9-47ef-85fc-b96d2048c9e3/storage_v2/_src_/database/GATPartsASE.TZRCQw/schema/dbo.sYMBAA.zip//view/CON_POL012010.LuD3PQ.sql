create view [dbo].[CON_POL012010] as select * from GATPartsConcen.dbo.CON_POL012010
go

