create view [dbo].[CON_CFDI012009] as select * from [GATPartsConcen].dbo.[con_cfdi012009]
go

