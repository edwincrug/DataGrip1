create view [dbo].[CON_CARDETA012004] as select * from GATPartsConcen.dbo.CON_CARDETA012004
go

