CREATE VIEW [dbo].[cat_formapago] AS Select * From GATPartsConcen.dbo.cat_formapago

