create view [dbo].[cxp_condcartera] as select * from GATPartsConcen.dbo.cxp_condcartera
go

