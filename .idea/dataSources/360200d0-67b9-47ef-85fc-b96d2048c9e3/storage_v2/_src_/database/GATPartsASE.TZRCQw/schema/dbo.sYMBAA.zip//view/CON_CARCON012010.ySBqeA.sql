create view [dbo].[CON_CARCON012010] as select * from GATPartsConcen.dbo.CON_CARCON012010
go

