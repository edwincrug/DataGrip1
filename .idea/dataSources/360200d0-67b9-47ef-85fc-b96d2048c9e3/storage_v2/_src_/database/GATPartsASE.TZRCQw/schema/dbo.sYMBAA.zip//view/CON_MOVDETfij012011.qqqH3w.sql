create view [dbo].[CON_MOVDETfij012011] as select * from GATPartsConcen.dbo.CON_MOVDETfij012011
go

