create view [dbo].[CON_MOVCHEQUE012012] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012012
go

