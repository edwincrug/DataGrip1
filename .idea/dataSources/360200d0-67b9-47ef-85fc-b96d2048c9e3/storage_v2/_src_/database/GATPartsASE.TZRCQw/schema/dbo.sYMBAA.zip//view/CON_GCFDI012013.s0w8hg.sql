create view [dbo].[CON_GCFDI012013] as select * from [GATPartsConcen].dbo.[CON_GCFDI012013]
go

