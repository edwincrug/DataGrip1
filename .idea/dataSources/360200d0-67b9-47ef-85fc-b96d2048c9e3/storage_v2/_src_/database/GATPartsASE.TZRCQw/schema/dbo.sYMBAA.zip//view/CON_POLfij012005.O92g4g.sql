create view [dbo].[CON_POLfij012005] as select * from GATPartsConcen.dbo.CON_POLfij012005
go

