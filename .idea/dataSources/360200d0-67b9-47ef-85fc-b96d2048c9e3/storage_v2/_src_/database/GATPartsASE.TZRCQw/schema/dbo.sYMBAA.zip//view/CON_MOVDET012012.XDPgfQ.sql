create view [dbo].[CON_MOVDET012012] as select * from GATPartsConcen.dbo.CON_MOVDET012012
go

