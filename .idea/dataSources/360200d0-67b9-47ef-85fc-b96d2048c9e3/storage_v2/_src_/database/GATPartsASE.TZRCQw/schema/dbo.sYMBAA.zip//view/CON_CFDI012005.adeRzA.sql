create view [dbo].[CON_CFDI012005] as select * from [GATPartsConcen].dbo.[con_cfdi012005]
go

