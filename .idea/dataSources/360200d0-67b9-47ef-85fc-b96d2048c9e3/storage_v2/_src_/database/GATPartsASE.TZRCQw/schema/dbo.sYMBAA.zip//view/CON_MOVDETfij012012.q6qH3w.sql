create view [dbo].[CON_MOVDETfij012012] as select * from GATPartsConcen.dbo.CON_MOVDETfij012012
go

