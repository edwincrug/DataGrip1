create view [dbo].[CON_POLfij012008] as select * from GATPartsConcen.dbo.CON_POLfij012008
go

