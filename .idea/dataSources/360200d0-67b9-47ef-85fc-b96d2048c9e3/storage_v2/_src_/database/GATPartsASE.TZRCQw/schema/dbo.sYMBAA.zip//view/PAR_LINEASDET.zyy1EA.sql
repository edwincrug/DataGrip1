create view [dbo].[PAR_LINEASDET] as select * from GATPartsConcen.dbo.PAR_LINEASDET
go

