create view [dbo].[CON_CARCON012004] as select * from GATPartsConcen.dbo.CON_CARCON012004
go

