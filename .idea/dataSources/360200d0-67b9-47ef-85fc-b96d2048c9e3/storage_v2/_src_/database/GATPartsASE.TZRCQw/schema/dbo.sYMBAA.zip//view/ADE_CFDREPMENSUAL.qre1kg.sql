---(9)
create view [dbo].[ADE_CFDREPMENSUAL] as select * from GATPartsConcen.dbo.ADE_CFDREPMENSUAL
go

