CREATE VIEW [dbo].[cat_tiporelacion] AS Select * From GATPartsConcen.dbo.cat_tiporelacion
go

