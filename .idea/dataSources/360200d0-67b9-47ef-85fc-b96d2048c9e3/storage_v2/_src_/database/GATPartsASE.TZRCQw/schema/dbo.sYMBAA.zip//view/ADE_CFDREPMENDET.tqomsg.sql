---(10)
create view [dbo].[ADE_CFDREPMENDET] as select * from GATPartsConcen.dbo.ADE_CFDREPMENDET
go

