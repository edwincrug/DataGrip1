create view [dbo].[CON_CARDETA012007] as select * from GATPartsConcen.dbo.CON_CARDETA012007
go

