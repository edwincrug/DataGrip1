create view [dbo].[CON_MOVCHEQUE012009] as select * from GATPartsConcen.dbo.CON_MOVCHEQUE012009
go

