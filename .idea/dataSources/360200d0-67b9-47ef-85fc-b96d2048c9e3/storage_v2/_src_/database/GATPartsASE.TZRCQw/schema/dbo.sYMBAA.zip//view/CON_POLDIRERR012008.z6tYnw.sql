create view [dbo].[CON_POLDIRERR012008] as select * from GATPartsConcen.dbo.CON_POLDIRERR012008
go

