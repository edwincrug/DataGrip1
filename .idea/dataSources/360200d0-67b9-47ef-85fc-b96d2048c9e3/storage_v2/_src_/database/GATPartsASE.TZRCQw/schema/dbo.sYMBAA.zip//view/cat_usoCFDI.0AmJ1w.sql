CREATE VIEW [dbo].[cat_usoCFDI] AS Select * From GATPartsConcen.dbo.cat_usoCFDI
go

