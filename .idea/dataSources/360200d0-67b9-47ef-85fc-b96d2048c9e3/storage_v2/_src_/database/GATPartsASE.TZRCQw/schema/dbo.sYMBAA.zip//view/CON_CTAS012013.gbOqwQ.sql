create view [dbo].[CON_CTAS012013] as select * from GATPartsConcen.dbo.CON_CTAS012013
go

