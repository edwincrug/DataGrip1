create view [dbo].[CON_CARDETA012013] as select * from GATPartsConcen.dbo.CON_CARDETA012013
go

