create view [dbo].[CON_MOVTRANSFER012006] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012006
go

