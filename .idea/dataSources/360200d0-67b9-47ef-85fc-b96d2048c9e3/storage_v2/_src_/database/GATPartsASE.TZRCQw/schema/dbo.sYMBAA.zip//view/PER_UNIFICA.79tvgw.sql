create view [dbo].[PER_UNIFICA] as select * from GATPartsConcen.dbo.PER_UNIFICA
go

