create view [dbo].[PAR_REEMPLAZOS] as select * from GATPartsConcen.dbo.PAR_REEMPLAZOS
go

