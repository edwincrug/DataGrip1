create view [dbo].[CON_POLDIRERR012004] as select * from GATPartsConcen.dbo.CON_POLDIRERR012004
go

