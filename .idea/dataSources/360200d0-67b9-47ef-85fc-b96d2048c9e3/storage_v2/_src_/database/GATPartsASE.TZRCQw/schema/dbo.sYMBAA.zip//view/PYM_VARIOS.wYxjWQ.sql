create view [dbo].[PYM_VARIOS] as select * from GATPartsConcen.dbo.PYM_VARIOS
go

