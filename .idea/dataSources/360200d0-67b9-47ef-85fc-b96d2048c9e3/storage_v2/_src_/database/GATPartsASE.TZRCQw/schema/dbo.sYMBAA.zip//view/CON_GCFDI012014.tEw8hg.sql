create view [dbo].[CON_GCFDI012014] as select * from [GATPartsConcen].dbo.[CON_GCFDI012014]
go

