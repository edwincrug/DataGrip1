create view [dbo].[CON_POLfij012013] as select * from GATPartsConcen.dbo.CON_POLfij012013
go

