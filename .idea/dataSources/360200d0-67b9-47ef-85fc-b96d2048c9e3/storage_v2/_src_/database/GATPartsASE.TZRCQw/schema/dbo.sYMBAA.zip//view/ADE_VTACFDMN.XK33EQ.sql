---(1)
create view [dbo].[ADE_VTACFDMN] as select * from GATPartsConcen.dbo.ADE_VTACFDMN
go

