create view [dbo].[CON_MOVTRANSFER012012] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012012
go

