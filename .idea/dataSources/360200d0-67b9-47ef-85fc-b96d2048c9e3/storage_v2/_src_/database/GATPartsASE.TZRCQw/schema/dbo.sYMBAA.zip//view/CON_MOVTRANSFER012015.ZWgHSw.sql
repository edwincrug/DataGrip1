create view [dbo].[CON_MOVTRANSFER012015] as select * from GATPartsConcen.dbo.CON_MOVTRANSFER012015
go

