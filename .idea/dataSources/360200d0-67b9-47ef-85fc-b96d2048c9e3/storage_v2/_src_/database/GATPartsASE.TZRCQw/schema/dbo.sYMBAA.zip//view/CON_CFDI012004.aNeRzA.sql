create view [dbo].[CON_CFDI012004] as select * from [GATPartsConcen].dbo.[con_cfdi012004]
go

