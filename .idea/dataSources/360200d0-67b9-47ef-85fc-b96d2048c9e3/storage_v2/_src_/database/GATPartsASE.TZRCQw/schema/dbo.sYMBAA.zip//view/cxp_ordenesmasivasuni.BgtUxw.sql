CREATE VIEW cxp_ordenesmasivasuni AS SELECT * FROM GATPartsConcen.dbo.cxp_ordenesmasivasuni
go

