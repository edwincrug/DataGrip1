
CREATE PROC SP_ORDEN_SERVICIO 
AS

DELETE FROM BI_ORDENES_SERVICIO

SELECT * INTO #ORDENES_INICIAL FROM(
SELECT DISTINCT ORE_NUMSERIE,ORE_IDCATALOGO,ORE_IDASESOR,ORE_STATUS,ORE_QCCOLOEXTE,
ORE_FECHAORD,ORE_IDCLIENTE,ORE_OBSERVACIONES=SUBSTRING(ORE_OBSERVACIONES,1,280),ORE_MARCA,ORE_IDORDEN,ORE_NOPLACAS,ORE_FECHAPROM,ORD_STATUS,ORD_IDORDEN,
ORD_CONSE,TOR.PAR_DESCRIP1 FROM SER_ORDEN INNER JOIN SER_ORDENDET ON ORE_IDORDEN = ORD_IDORDEN left outer join 
PNC_PARAMETR as TOR on substring(ORE_IDORDEN,1,1) = TOR.PAR_IDENPARA and TOR.PAR_TIPOPARA = 'TO' WHERE ORE_STATUS NOT IN 
('I','C') AND CONVERT(DATETIME,ORE_FECHAORD,103) <= CONVERT(DATETIME,GETDATE(),103)) as OrdenesServicio


select convert(varchar(10),idorden_servicio) as idorden_servicio,convert(varchar(8),fecha_orden_servicio) as 
fecha_orden_servicio,convert(varchar(50),idcliente) as idcliente,convert(varchar(100),nombre_cliente) as nombre_cliente,
convert(varchar(250),descripcion) as descripcion,convert(varchar(50),asesor_servicio) as asesor_servicio,
convert(varchar(50),unidad) as unidad,convert(varchar(50),tipo_unidad) as tipo_unidad,convert(varchar(50),subtipo_unidad) 
as subtipo_unidad,convert(varchar(50),marca) as marca,convert(varchar(50),modelo) as modelo,convert(varchar(50),
tipo_del_modelo) as tipo_del_modelo,convert(varchar(50),color) as color,convert(numeric(4,0),anio) as anio,
convert(varchar(50),num_serie) as num_serie,convert(varchar(50),codigo_barras) as codigo_barras,convert(varchar(10),placas)
as placas,convert(varchar(8),fecha_compromiso) as fecha_compromiso,convert(varchar(50),estatus) as estatus,
convert(varchar(100),nombre_estatus) as nombre_estatus,convert(varchar(8),fecha_cancelacion) as fecha_cancelacion,
convert(varchar(8),fecha_entrega) as fecha_entrega,PAR_DESCRIP1 AS PAR_DESCRIP1
INTO #IPIN_SER_ORDENES1
from (select DISTINCT ORE_IDORDEN 
as idorden_servicio,REPLACE(ORE_FECHAORD,'/','') as fecha_orden_servicio,ORE_IDCLIENTE as idcliente,
substring(RTRIM(LTRIM(ISNULL(per_nomrazon,'') + ' ' + isnull(per_paterno,'') + ' ' + isnull(per_materno,''))),1,100) as 
nombre_cliente,substring(replace(replace(ore_observaciones,char(10),''),char(13),''),1,250) as descripcion,
convert(int,ASE.PAR_IMPORTE5) as asesor_servicio,'ND' as unidad,isnull(TIPO.PAR_DESCRIP1,'') as tipo_unidad,
substring(isnull(LINEA.PAR_DESCRIP1,''),1,50) as subtipo_unidad,substring(ORE_MARCA,1,50) as marca,
substring(VEH_QCTIPOAUTO,1,50) as modelo,'ND' tipo_del_modelo,substring(isnull(COLEX.PAR_DESCRIP1,''),1,50) as 
color,VEH_QCMODELO as anio,ORE_NUMSERIE as num_serie,'ND' as codigo_barras,substring(ORE_NOPLACAS,1,10) as placas,
REPLACE(ORE_FECHAPROM,'/','') as fecha_compromiso,SUBSTRING(ORE_STATUS,1,1) as estatus,
substring(isnull(STATU.PAR_DESCRIP1,''),1,100) as nombre_estatus,'ND' as fecha_cancelacion,'ND' as fecha_entrega,
#ORDENES_INICIAL.PAR_DESCRIP1
From #ORDENES_INICIAL inner join PER_PERSONAS on ORE_IDCLIENTE = PER_IDPERSONA left outer join SER_VEHICULO on 
ORE_NUMSERIE = VEH_NUMSERIE left outer join UNI_CATALOGO on ORE_IDCATALOGO = UNC_IDCATALOGO AND VEH_QCMODELO = 
UNC_MODELO left outer join PNC_PARAMETR as TIPO on UNC_CLASE = TIPO.PAR_IDENPARA and TIPO.PAR_TIPOPARA = 'CVE' 
left outer join PNC_PARAMETR as ASE on ORE_IDASESOR = ASE.PAR_IDENPARA and ASE.PAR_TIPOPARA = 'AS' left outer join 
PNC_PARAMETR as LINEA on UNC_LINEA = LINEA.PAR_IDENPARA AND LINEA.PAR_TIPOPARA = 'LNA' left outer join PNC_PARAMETR as 
STATU on ORE_STATUS = STATU.PAR_IDENPARA and STATU.PAR_TIPOPARA = 'SO' left outer join PNC_PARAMETR as COLEX on 
ORE_QCCOLOEXTE = COLEX.PAR_IDENPARA and COLEX.PAR_TIPOPARA = 'COE') as INTERNO

SELECT *,antiguedad_orden=
DATEDIFF(day, CONVERT(DATETIME,SUBSTRING(fecha_compromiso,1,2) + '/' + 
SUBSTRING(fecha_compromiso,3,2) + '/' + SUBSTRING(fecha_compromiso,5,4)), GETDATE()),
dias_orden=
DATEDIFF(day, CONVERT(DATETIME,SUBSTRING(fecha_orden_servicio,1,2) + '/' + 
SUBSTRING(fecha_orden_servicio,3,2) + '/' + SUBSTRING(fecha_orden_servicio,5,4)), GETDATE()),
Asesor=(SELECT RTRIM(LTRIM(ISNULL(per_nomrazon,'') + ' ' + isnull(per_paterno,'') + ' ' + isnull(per_materno,'')))FROM PER_PERSONAS WHERE PER_IDPERSONA = asesor_servicio)
INTO #IPIN_SER_ORDENES FROM #IPIN_SER_ORDENES1

--PREFACTURADAS
INSERT INTO BI_ORDENES_SERVICIO
SELECT *,STA='PI', NOMBRE_STA= 'PREFACTURADA' FROM #IPIN_SER_ORDENES 
WHERE idorden_servicio IN(SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL WHERE ORE_STATUS = 'T')

DELETE FROM #ORDENES_INICIAL WHERE ORE_IDORDEN IN(
SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL WHERE ORE_STATUS = 'T')

--ABIERTAS
INSERT INTO BI_ORDENES_SERVICIO
SELECT *, STA='A', NOMBRE_STA= 'ABIERTA'  FROM #IPIN_SER_ORDENES WHERE idorden_servicio IN(
SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'S' AND ORE_IDORDEN NOT IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'T') AND ORE_IDORDEN NOT IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'X'))


DELETE FROM #ORDENES_INICIAL WHERE ORE_IDORDEN IN(
SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'S' AND ORE_IDORDEN NOT IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'T') AND ORE_IDORDEN NOT IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'X'))


--TERMINDAS
INSERT INTO BI_ORDENES_SERVICIO
SELECT *, STA='T', NOMBRE_STA= 'TERMINADAS' FROM #IPIN_SER_ORDENES WHERE idorden_servicio IN(
SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'T' AND ORE_IDORDEN NOT IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'S') AND ORE_IDORDEN NOT IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'X'))


DELETE FROM #ORDENES_INICIAL WHERE ORE_IDORDEN IN(
SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'T' AND ORE_IDORDEN NOT IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'S') AND ORE_IDORDEN NOT IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'X'))

-------------------------
INSERT INTO BI_ORDENES_SERVICIO
SELECT *, STA='T', NOMBRE_STA= 'TERMINADAS' FROM #IPIN_SER_ORDENES WHERE idorden_servicio IN(
SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'T' AND ORE_IDORDEN IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'X'))


DELETE FROM #ORDENES_INICIAL WHERE ORE_IDORDEN IN(
SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'T' AND ORE_IDORDEN IN
(SELECT ORE_IDORDEN FROM #ORDENES_INICIAL WHERE ORD_STATUS = 'X'))

--PROCESO

INSERT INTO BI_ORDENES_SERVICIO
SELECT *, STA='P', NOMBRE_STA= 'EN PROCESO' FROM #IPIN_SER_ORDENES WHERE idorden_servicio IN(
SELECT DISTINCT(ORE_IDORDEN) FROM #ORDENES_INICIAL)

go

