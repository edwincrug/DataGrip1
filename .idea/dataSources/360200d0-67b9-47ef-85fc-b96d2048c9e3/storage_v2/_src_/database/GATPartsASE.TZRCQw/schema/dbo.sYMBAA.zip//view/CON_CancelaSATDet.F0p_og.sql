CREATE VIEW [dbo].[CON_CancelaSATDet] AS SELECT * FROM GATPartsConcen.dbo.CON_CancelaSATDet
go

