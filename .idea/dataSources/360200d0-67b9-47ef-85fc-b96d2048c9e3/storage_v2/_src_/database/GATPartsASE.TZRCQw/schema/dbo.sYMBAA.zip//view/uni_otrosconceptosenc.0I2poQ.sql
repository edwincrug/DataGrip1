
CREATE VIEW [dbo].[uni_otrosconceptosenc]
AS
SELECT     uoc_idotrosconceptosenc, uoc_fechaalta, uoc_formapago, uoc_observaciones, uoc_tasaiva, uoc_tipooperacion,
uoc_idusuarioalta, uoc_idusuariomodifica, uoc_fechamodifica, ceo_idestatusotrosconceptos, uoc_estatus, ucu_idcotizacion,
uoc_idpedidobpro, uaw_idanticipoweb, ucu_idcotizacionpost,uoc_cveusocfdi
FROM       CUENTASPORCOBRAR.dbo.uni_otrosconceptosenc


go

