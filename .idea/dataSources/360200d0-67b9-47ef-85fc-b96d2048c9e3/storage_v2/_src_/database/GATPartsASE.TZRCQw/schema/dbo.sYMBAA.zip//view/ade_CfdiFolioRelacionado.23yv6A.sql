CREATE VIEW [dbo].[ade_CfdiFolioRelacionado] AS SELECT * FROM GATPartsConcen.dbo.ade_CfdiFolioRelacionado
go

